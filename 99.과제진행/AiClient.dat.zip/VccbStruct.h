/**
 * @file        VccbStruct.h
 * @brief       Structure Definition of VCCB
 *
 * @author      Access S/W Lab.
 * @date        2018/05/05
 * @version
 */

#ifndef VCCB_VccbStruct_H_
#define VCCB_VccbStruct_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "VccbAiEngine.h"

typedef enum
{
    e_VCCB_ACPF_VNF,
    e_VCCB_ACPF_CNF,
    e_VCCB_NVGNB
} VccbSystem_type;

typedef enum
{
    e_TargetXN_Handover,  // Source GNB to Target GNB
    e_TargetXN_RRE,       // Old GNB to Target GNB
    e_Snode_MnToSrcSn,    // From MN to SN.
    e_Snode_MnToTgtSn,    // From MN to SN (Inter-SN Mobility).
    e_Snode_SnToMn,       // From SN to MN.
    e_Snode_SnToTgtMn,    // From SN to MN.(Inter-MN Mobility).
    e_TargetXN_initValue,
    e_TargetXN_RRCResume,
    e_TargetXN_XnReleaseForRRE // Release of Src GNB for Inter gNB HO or Src GNB for Inter gNB RRE during RRE
} enumTargetXnInfo_type;

typedef enum
{
    Not_Changed,
    Changed
} enumChangeState_type;

typedef enum
{
    Not_Decision,
    Decision
} enumDecisionState_type;

typedef enum
{
    e_UpmRequiresCalculation,   // Represents an action that requires calculation.
    e_UpmTurnsOffOperation,     // Represents an action that turns off an operation.
    e_UpmDoesNothing,           // Represents an action that does nothing.
} enumUpmAction_type;

typedef enum
{
    DataForwarding_Proposal,  // HO Case (Source GNB), DC-addition(MN) DC-release(SN)
    DataForwarding_Accept    // HO Case (Target GNB), DC-addition(SN) DC-release(MN)
} enumDataForwardingState_type;

typedef enum
{
    e_Valid_Ok,
    e_Invalid_unknown,
    e_Invalid_no_use,
    e_Invalid_PointerAddress,
    e_Invalid_UnknownNodeType,
    e_Invalid_OutOfValidRange,
    e_Invalid_MoudlaIsNotZero
} enumValidNodeCause_type;

/*
 name : enumBitMask32_type (unsigned int)
 For type conversion according to the bit field,
 make it constant and use it. This is to avoid hard coding.
*/
typedef enum
{
    e_BitMask_1bit   = 0x00000001U, /* 0x00000001 : 00000000 00000000 00000000 00000001 */
    e_BitMask_2bit   = 0x00000003U, /* 0x00000003 : 00000000 00000000 00000000 00000011 */
    e_BitMask_3bit   = 0x00000007U, /* 0x00000007 : 00000000 00000000 00000000 00000111 */
    e_BitMask_4bit   = 0x0000000FU, /* 0x0000000F : 00000000 00000000 00000000 00001111 */
    e_BitMask_5bit   = 0x0000001FU, /* 0x0000001F : 00000000 00000000 00000000 00011111 */
    e_BitMask_6bit   = 0x0000003FU, /* 0x0000003F : 00000000 00000000 00000000 00111111 */
    e_BitMask_7bit   = 0x0000007FU, /* 0x0000007F : 00000000 00000000 00000000 01111111 */
    e_BitMask_8bit   = 0x000000FFU, /* 0x000000FF : 00000000 00000000 00000000 11111111 */
    e_BitMask_9bit   = 0x000001FFU, /* 0x000001FF : 00000000 00000000 00000001 11111111 */
    e_BitMask_10bit  = 0x000003FFU, /* 0x000003FF : 00000000 00000000 00000011 11111111 */
    e_BitMask_11bit  = 0x000007FFU, /* 0x000007FF : 00000000 00000000 00000111 11111111 */
    e_BitMask_12bit  = 0x00000FFFU, /* 0x00000FFF : 00000000 00000000 00001111 11111111 */
    e_BitMask_13bit  = 0x00001FFFU, /* 0x00001FFF : 00000000 00000000 00011111 11111111 */
    e_BitMask_14bit  = 0x00003FFFU, /* 0x00003FFF : 00000000 00000000 00111111 11111111 */
    e_BitMask_15bit  = 0x00007FFFU, /* 0x00007FFF : 00000000 00000000 01111111 11111111 */
    e_BitMask_16bit  = 0x0000FFFFU, /* 0x0000FFFF : 00000000 00000000 11111111 11111111 */
    e_BitMask_17bit  = 0x0001FFFFU, /* 0x0001FFFF : 00000000 00000001 11111111 11111111 */
    e_BitMask_18bit  = 0x0003FFFFU, /* 0x0003FFFF : 00000000 00000011 11111111 11111111 */
    e_BitMask_19bit  = 0x0007FFFFU, /* 0x0007FFFF : 00000000 00000111 11111111 11111111 */
    e_BitMask_20bit  = 0x000FFFFFU, /* 0x000FFFFF : 00000000 00001111 11111111 11111111 */
    e_BitMask_21bit  = 0x001FFFFFU, /* 0x001FFFFF : 00000000 00011111 11111111 11111111 */
    e_BitMask_22bit  = 0x003FFFFFU, /* 0x003FFFFF : 00000000 00111111 11111111 11111111 */
    e_BitMask_23bit  = 0x007FFFFFU, /* 0x007FFFFF : 00000000 01111111 11111111 11111111 */
    e_BitMask_24bit  = 0x00FFFFFFU, /* 0x00FFFFFF : 00000000 11111111 11111111 11111111 */
    e_BitMask_25bit  = 0x01FFFFFFU, /* 0x01FFFFFF : 00000001 11111111 11111111 11111111 */
    e_BitMask_26bit  = 0x03FFFFFFU, /* 0x03FFFFFF : 00000011 11111111 11111111 11111111 */
    e_BitMask_27bit  = 0x07FFFFFFU, /* 0x07FFFFFF : 00000111 11111111 11111111 11111111 */
    e_BitMask_28bit  = 0x0FFFFFFFU, /* 0x0FFFFFFF : 00001111 11111111 11111111 11111111 */
    e_BitMask_29bit  = 0x1FFFFFFFU, /* 0x1FFFFFFF : 00011111 11111111 11111111 11111111 */
    e_BitMask_30bit  = 0x3FFFFFFFU, /* 0x3FFFFFFF : 00111111 11111111 11111111 11111111 */
    e_BitMask_31bit  = 0x7FFFFFFFU, /* 0x7FFFFFFF : 01111111 11111111 11111111 11111111 */
    e_BitMask_32bit  = 0xFFFFFFFFU, /* 0xFFFFFFFF : 11111111 11111111 11111111 11111111 */

} enumBitMask32_type;

/*
 name : enumSpecificBitMask32_type
 Many cases can be covered with enumBitMask_type, but if there is a common rule for a certain structure,
 common settings can be provided through this enum.
 Therefore, an enum structure that can change them in batches is additionally provided.
*/
typedef enum
{
    e_BitMask_MccMnc = e_BitMask_12bit,

} enumSpecificBitMask32_type;

/*
 name : enumBitMask64_type (unsigned int long)
 For type conversion according to the bit field,
 make it constant and use it. This is to avoid hard coding.
*/
typedef enum
{
    e_BitMask64_1bit   = 0x0000000000000001UL, /* 0x00000000 0x00000001 : 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000001 */
    e_BitMask64_2bit   = 0x0000000000000003UL, /* 0x00000000 0x00000003 : 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000011 */
    e_BitMask64_3bit   = 0x0000000000000007UL, /* 0x00000000 0x00000007 : 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000111 */
    e_BitMask64_4bit   = 0x000000000000000FUL, /* 0x00000000 0x0000000F : 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00001111 */
    e_BitMask64_5bit   = 0x000000000000001FUL, /* 0x00000000 0x0000001F : 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00011111 */
    e_BitMask64_6bit   = 0x000000000000003FUL, /* 0x00000000 0x0000003F : 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00111111 */
    e_BitMask64_7bit   = 0x000000000000007FUL, /* 0x00000000 0x0000007F : 00000000 00000000 00000000 00000000 00000000 00000000 00000000 01111111 */
    e_BitMask64_8bit   = 0x00000000000000FFUL, /* 0x00000000 0x000000FF : 00000000 00000000 00000000 00000000 00000000 00000000 00000000 11111111 */
    e_BitMask64_9bit   = 0x00000000000001FFUL, /* 0x00000000 0x000001FF : 00000000 00000000 00000000 00000000 00000000 00000000 00000001 11111111 */
    e_BitMask64_10bit  = 0x00000000000003FFUL, /* 0x00000000 0x000003FF : 00000000 00000000 00000000 00000000 00000000 00000000 00000011 11111111 */
    e_BitMask64_11bit  = 0x00000000000007FFUL, /* 0x00000000 0x000007FF : 00000000 00000000 00000000 00000000 00000000 00000000 00000111 11111111 */
    e_BitMask64_12bit  = 0x0000000000000FFFUL, /* 0x00000000 0x00000FFF : 00000000 00000000 00000000 00000000 00000000 00000000 00001111 11111111 */
    e_BitMask64_13bit  = 0x0000000000001FFFUL, /* 0x00000000 0x00001FFF : 00000000 00000000 00000000 00000000 00000000 00000000 00011111 11111111 */
    e_BitMask64_14bit  = 0x0000000000003FFFUL, /* 0x00000000 0x00003FFF : 00000000 00000000 00000000 00000000 00000000 00000000 00111111 11111111 */
    e_BitMask64_15bit  = 0x0000000000007FFFUL, /* 0x00000000 0x00007FFF : 00000000 00000000 00000000 00000000 00000000 00000000 01111111 11111111 */
    e_BitMask64_16bit  = 0x000000000000FFFFUL, /* 0x00000000 0x0000FFFF : 00000000 00000000 00000000 00000000 00000000 00000000 11111111 11111111 */
    e_BitMask64_17bit  = 0x000000000001FFFFUL, /* 0x00000000 0x0001FFFF : 00000000 00000000 00000000 00000000 00000000 00000001 11111111 11111111 */
    e_BitMask64_18bit  = 0x000000000003FFFFUL, /* 0x00000000 0x0003FFFF : 00000000 00000000 00000000 00000000 00000000 00000011 11111111 11111111 */
    e_BitMask64_19bit  = 0x000000000007FFFFUL, /* 0x00000000 0x0007FFFF : 00000000 00000000 00000000 00000000 00000000 00000111 11111111 11111111 */
    e_BitMask64_20bit  = 0x00000000000FFFFFUL, /* 0x00000000 0x000FFFFF : 00000000 00000000 00000000 00000000 00000000 00001111 11111111 11111111 */
    e_BitMask64_21bit  = 0x00000000001FFFFFUL, /* 0x00000000 0x001FFFFF : 00000000 00000000 00000000 00000000 00000000 00011111 11111111 11111111 */
    e_BitMask64_22bit  = 0x00000000003FFFFFUL, /* 0x00000000 0x003FFFFF : 00000000 00000000 00000000 00000000 00000000 00111111 11111111 11111111 */
    e_BitMask64_23bit  = 0x00000000007FFFFFUL, /* 0x00000000 0x007FFFFF : 00000000 00000000 00000000 00000000 00000000 01111111 11111111 11111111 */
    e_BitMask64_24bit  = 0x0000000000FFFFFFUL, /* 0x00000000 0x00FFFFFF : 00000000 00000000 00000000 00000000 00000000 11111111 11111111 11111111 */
    e_BitMask64_25bit  = 0x0000000001FFFFFFUL, /* 0x00000000 0x01FFFFFF : 00000000 00000000 00000000 00000000 00000001 11111111 11111111 11111111 */
    e_BitMask64_26bit  = 0x0000000003FFFFFFUL, /* 0x00000000 0x03FFFFFF : 00000000 00000000 00000000 00000000 00000011 11111111 11111111 11111111 */
    e_BitMask64_27bit  = 0x0000000007FFFFFFUL, /* 0x00000000 0x07FFFFFF : 00000000 00000000 00000000 00000000 00000111 11111111 11111111 11111111 */
    e_BitMask64_28bit  = 0x000000000FFFFFFFUL, /* 0x00000000 0x0FFFFFFF : 00000000 00000000 00000000 00000000 00001111 11111111 11111111 11111111 */
    e_BitMask64_29bit  = 0x000000001FFFFFFFUL, /* 0x00000000 0x1FFFFFFF : 00000000 00000000 00000000 00000000 00011111 11111111 11111111 11111111 */
    e_BitMask64_30bit  = 0x000000003FFFFFFFUL, /* 0x00000000 0x3FFFFFFF : 00000000 00000000 00000000 00000000 00111111 11111111 11111111 11111111 */
    e_BitMask64_31bit  = 0x000000007FFFFFFFUL, /* 0x00000000 0x7FFFFFFF : 00000000 00000000 00000000 00000000 01111111 11111111 11111111 11111111 */
    e_BitMask64_32bit  = 0x00000000FFFFFFFFUL, /* 0x00000000 0xFFFFFFFF : 00000000 00000000 00000000 00000000 11111111 11111111 11111111 11111111 */
    e_BitMask64_33bit  = 0x00000001FFFFFFFFUL, /* 0x00000001 0xFFFFFFFF : 00000000 00000000 00000000 00000001 11111111 11111111 11111111 11111111 */
    e_BitMask64_34bit  = 0x00000003FFFFFFFFUL, /* 0x00000003 0xFFFFFFFF : 00000000 00000000 00000000 00000011 11111111 11111111 11111111 11111111 */
    e_BitMask64_35bit  = 0x00000007FFFFFFFFUL, /* 0x00000007 0xFFFFFFFF : 00000000 00000000 00000000 00000111 11111111 11111111 11111111 11111111 */
    e_BitMask64_36bit  = 0x0000000FFFFFFFFFUL, /* 0x0000000F 0xFFFFFFFF : 00000000 00000000 00000000 00001111 11111111 11111111 11111111 11111111 */
    e_BitMask64_37bit  = 0x0000001FFFFFFFFFUL, /* 0x0000001F 0xFFFFFFFF : 00000000 00000000 00000000 00011111 11111111 11111111 11111111 11111111 */
    e_BitMask64_38bit  = 0x0000003FFFFFFFFFUL, /* 0x0000003F 0xFFFFFFFF : 00000000 00000000 00000000 00111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_39bit  = 0x0000007FFFFFFFFFUL, /* 0x0000007F 0xFFFFFFFF : 00000000 00000000 00000000 01111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_40bit  = 0x000000FFFFFFFFFFUL, /* 0x000000FF 0xFFFFFFFF : 00000000 00000000 00000000 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_41bit  = 0x000001FFFFFFFFFFUL, /* 0x000001FF 0xFFFFFFFF : 00000000 00000000 00000001 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_42bit  = 0x000003FFFFFFFFFFUL, /* 0x000003FF 0xFFFFFFFF : 00000000 00000000 00000011 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_43bit  = 0x000007FFFFFFFFFFUL, /* 0x000007FF 0xFFFFFFFF : 00000000 00000000 00000111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_44bit  = 0x00000FFFFFFFFFFFUL, /* 0x00000FFF 0xFFFFFFFF : 00000000 00000000 00001111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_45bit  = 0x00001FFFFFFFFFFFUL, /* 0x00001FFF 0xFFFFFFFF : 00000000 00000000 00011111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_46bit  = 0x00003FFFFFFFFFFFUL, /* 0x00003FFF 0xFFFFFFFF : 00000000 00000000 00111111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_47bit  = 0x00007FFFFFFFFFFFUL, /* 0x00007FFF 0xFFFFFFFF : 00000000 00000000 01111111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_48bit  = 0x0000FFFFFFFFFFFFUL, /* 0x0000FFFF 0xFFFFFFFF : 00000000 00000000 11111111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_49bit  = 0x0001FFFFFFFFFFFFUL, /* 0x0001FFFF 0xFFFFFFFF : 00000000 00000001 11111111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_50bit  = 0x0003FFFFFFFFFFFFUL, /* 0x0003FFFF 0xFFFFFFFF : 00000000 00000011 11111111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_51bit  = 0x0007FFFFFFFFFFFFUL, /* 0x0007FFFF 0xFFFFFFFF : 00000000 00000111 11111111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_52bit  = 0x000FFFFFFFFFFFFFUL, /* 0x000FFFFF 0xFFFFFFFF : 00000000 00001111 11111111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_53bit  = 0x001FFFFFFFFFFFFFUL, /* 0x001FFFFF 0xFFFFFFFF : 00000000 00011111 11111111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_54bit  = 0x003FFFFFFFFFFFFFUL, /* 0x003FFFFF 0xFFFFFFFF : 00000000 00111111 11111111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_55bit  = 0x007FFFFFFFFFFFFFUL, /* 0x007FFFFF 0xFFFFFFFF : 00000000 01111111 11111111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_56bit  = 0x00FFFFFFFFFFFFFFUL, /* 0x00FFFFFF 0xFFFFFFFF : 00000000 11111111 11111111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_57bit  = 0x01FFFFFFFFFFFFFFUL, /* 0x01FFFFFF 0xFFFFFFFF : 00000001 11111111 11111111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_58bit  = 0x03FFFFFFFFFFFFFFUL, /* 0x03FFFFFF 0xFFFFFFFF : 00000011 11111111 11111111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_59bit  = 0x07FFFFFFFFFFFFFFUL, /* 0x07FFFFFF 0xFFFFFFFF : 00000111 11111111 11111111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_60bit  = 0x0FFFFFFFFFFFFFFFUL, /* 0x0FFFFFFF 0xFFFFFFFF : 00001111 11111111 11111111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_61bit  = 0x1FFFFFFFFFFFFFFFUL, /* 0x1FFFFFFF 0xFFFFFFFF : 00011111 11111111 11111111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_62bit  = 0x3FFFFFFFFFFFFFFFUL, /* 0x3FFFFFFF 0xFFFFFFFF : 00111111 11111111 11111111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_63bit  = 0x7FFFFFFFFFFFFFFFUL, /* 0x7FFFFFFF 0xFFFFFFFF : 01111111 11111111 11111111 11111111 11111111 11111111 11111111 11111111 */
    e_BitMask64_64bit  = 0xFFFFFFFFFFFFFFFFUL, /* 0xFFFFFFFF 0xFFFFFFFF : 11111111 11111111 11111111 11111111 11111111 11111111 11111111 11111111 */

} enumBitMask64_type;

/*
 name : enumSpecificBitMask64_type
 Many cases can be covered with enumBitMask_type, but if there is a common rule for a certain structure,
 common settings can be provided through this enum.
 Therefore, an enum structure that can change them in batches is additionally provided.
*/
typedef enum
{
    e_BitMask64_XXX = e_BitMask64_12bit, // Temp

} enumSpecificBitMask64_type;

// Refactoring, for nrdc/nedc
typedef union
{
#define MN_Term_MCG_Bearer      0x11 // CellGroup_Mcg, TermPoint_Mn
#define MN_Term_SPLIT_Bearer    0x31 // CellGroup_Both , TermPoint_Mn
#define SN_Term_SCG_Bearer      0x22 // CellGroup_Scg , TermPoint_Sn
#define SN_Term_SPLIT_Bearer    0x32 // CellGroup_Both , TermPoint_Sn

#define IS_VALID_NrdcBearerType(_bearerType)  ((_bearerType).val == MN_Term_MCG_Bearer || (_bearerType).val == MN_Term_SPLIT_Bearer || \
        (_bearerType).val == SN_Term_SCG_Bearer || (_bearerType).val == SN_Term_SPLIT_Bearer)
#define IS_VALID_NrdcBearerTermPoint(_termPoint) ((_termPoint) > TermPoint_Begin && (_termPoint) < TermPoint_End)
#define IS_VALID_NrdcBearerCellGroup(_cellGroup) ((_cellGroup) > CellGroup_Begin && (_cellGroup) < CellGroup_End)
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// TBD, Not supported currently
#define MN_Term_SCG_Bearer      0x21 // CellGroup_Scg | TermPoint_Mn
#define SN_Term_MCG_Bearer      0x12 // CellGroup_Mcg | TermPoint_Sn

// This is a bearerType that is intended to be temporarily set for a very short time before determining the final bearerType during HO.
#define SN_Term_Undetermined    0x02 // 0 | TermPoint_Sn // Intermediate bearerType
#define MN_Term_Undetermined    0x01 // 0 | TermPoint_Mn // Intermediate bearerType
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define MAX_BEARER_TYPE         4
#define INIT_BEARER_TYPE        0 // 0xff
#define SN_Term_Default_Bearer  SN_Term_SPLIT_Bearer
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define IS_MN_TERM(_rDrb)        ((_rDrb).bearerType.termPoint == TermPoint_Mn)
#define IS_SN_TERM(_rDrb)        ((_rDrb).bearerType.termPoint == TermPoint_Sn)
#define IS_MN_TERM_SPLIT(_rDrb)  ((_rDrb).bearerType.val == MN_Term_SPLIT_Bearer)
#define IS_SN_TERM_SPLIT(_rDrb)  ((_rDrb).bearerType.val == SN_Term_SPLIT_Bearer)
#define IS_SN_TERM_SCG(_rDrb)    ((_rDrb).bearerType.val == SN_Term_MCG_Bearer)
#define IS_SPLIT_BEARER(_rDrb)   ((_rDrb).bearerType.cellGroup == CellGroup_Both)
#define IS_BearerType_Changing(_rDrb) (IS_VALID_NrdcBearerType((_rDrb).reqBearerType) && (_rDrb).reqBearerType.val != (_rDrb).bearerType.val)
    struct
    {
        // This simply indicates the bearerType for drb and does not directly indicate the resource status of up or du
        // for example)
        // MN_Term_SPLIT_Bearer(termPoint:1 , cellGroup: 3)
        // => in MN, the DRB of UP has two Legs but that of DU has a CellGroup as MCG.
        // => in SN, the DRB of UP doesn't have any Legs but that of DU has a CellGrop as SCG.
        uint8_t termPoint :4, /* 1:TermPoint_Mn, 2:TermPoint_Sn */
                cellGroup :4; /* 1:CellGroup_Mcg, 2:CellGroup_Scg, 3:CellGroup_Both */
    };
    uint8_t val;
} nrdcBearer_type;
/*----------------------------------------------------------------------------
 * Define    :    Include Header Files
 * ---------------------------------------------------------------------------
 */
/**
 * @brief timer information
 */
typedef struct
{
    int id;                    /**< timer id */
    int val;                   /**< timer value */
    uint16_t type;             /**< timer type */
    uint16_t contextId;        /**< UE context ID */
    uint16_t transactionId;    /**< transaction ID */
    uint16_t port;             /**< port */
    int8_t retryCnt;           /**< retry count */
    uint8_t reserved[3];       /**< reserved field */
    struct timeval attachTime; /**< timer attached time*/
} timerInfo_type;

typedef struct
{
    bool isRunning;
    struct timespec startTime;
} Stopwatch_type;

/**
 * @brief This is a structure for QCI value type
 */
typedef struct
{
    uint16_t oldQCI;                  /**< oldQCI for QCI Change Case */
    uint16_t QCI;                     /**< QCI */
    uint16_t priority;                /**< priority */
    enumResource_type gbrType;        /**< resource type: GBR, NON GBR */
    enumPaketDelayBudget_type PDB;    /**< packet delay budget(PDB) */
    enumPaketErrorLossRate_type PELR; /**< packet error loss rate(PELR) */
} qCIValue_type;

typedef struct plmnIdInfo_s
{
    ConfStatus shmStatus;  // shmStatus_type
    uint32_t plmnIndex;
    union
    {
        uint32_t longId;
        s2_type s2;
    };
    uint16_t reserved1;
    uint16_t reserved2;
} plmnIdInfo_type;

/**
 * @brief This is a structure for service available info
 */
typedef struct
{
    plmnId_type plmn;
    uint8_t status;
    uint8_t saAvailability;
    uint8_t reserved[2]; // padding
} serviceAvailInfo_type;

/**
 * @brief intra-gNB cell NBR
 */
typedef struct
{
    uint16_t targetCellId;
} intraGnbNbr_type;

/**
 * @brief external(Xn) gNB cell NBR
 */
typedef struct
{
    uint32_t tgtNbrGnbCellIdx; /**< Index of nbrGnbCellInfo_type nbrGnbCell[MAX_NBR_GNB_CELL_PER_GNB] */
} interGnbNbr_type;

/**
 * @brief X2 neighbor eNB information
 */
typedef struct
{
    uint8_t status; /**< EQUIP/N_EQUIP */
    uint32_t enbId;
    plmnId_type         enbPlmn;
    /* -- not used
    uint8_t             numPlmn;
    plmnIdInfo_type     plmnIndexInfo[MAX_PLMN_INDEX];
    */
    // TODO: For Blind SgNB Addition
    uint16_t mappingF1Idx;
    enumUsage_type x2apLinkState;
} x2NbrInfo_type;

/**
 * @brief Amf Set Information in Xn neighbor GNB information
 */
#define MAX_AMF_SET_INFO 16
typedef struct
{
    struct
    {
        uint8_t amfPlmnMcc  : 1;
        uint8_t amfPlmnMnc  : 1;
        uint8_t amfRegionId : 1;
        uint8_t reserved    : 5;
    } present;

    /* Mandatory */
    uint8_t status; /* N_EQUIP, EQUIP */

    /* Optional */
    uint8_t amfRegionId;  // 0 .. 255;
    uint8_t reserved;
    plmnId_type amfPlmn;
} amfSetInformation_type;

/**
 * @brief neighbor eNB cell information
 */
typedef struct
{
    uint8_t status;      /**< EQUIP/N_EQUIP */
    uint8_t bandwidthDl; /** enumEutraAllowedMeasBandwidth_type */
    uint8_t bandwidthUl; /** enumEutraAllowedMeasBandwidth_type */
    int8_t nedc_support; /** -1(not configured), 0(Not support), 1(Support) */
    uint8_t nonNeighbor;
    uint16_t cellId;     /**< INTEGER (0..255) */
    uint16_t pci;        /**< INTEGER (0..503) */
    uint16_t tac;        /**< INTEGER (0..65535) - 16 bits */
    uint32_t enbId;      /**< INTEGER (0..1048575) */
    uint32_t earfcnDl;   /**< INTEGER (0..262143) */
    uint32_t earfcnUl;   /**< INTEGER (0..262143) */
    plmnId_type plmn;
    plmnIdInfo_type cellPlmnInfo[MAX_NUM_PLMN_LTE];
} nbrEnbCellInfo_type;

typedef struct
{
    uint16_t cellNum;
    uint16_t bandNr;
} cellSelection_type;

/**
 * @brief neighbor target cell information for HO
 */
typedef struct
{
    uint8_t tgtIntraCellSelected_flag;          // flag for intra cell selection
    uint8_t tgtInterCellSelected_flag;          // flag for inter cell selection
    uint16_t bestIntraIdx;                      // Index of intra cell for bestIntraCells table
    uint16_t bestInterIdx;                      // Index of inter cell for bestInterCells table
    uint16_t prevPciNr;                         // value of pci number for previously checked cell
    uint16_t pciMrIdx;                          // nbrCellIdx for which inter cell with given pci was selected
    cellSelection_type targetIntraCell;         // selected target intra cell
    uint32_t targetInterCellNum;                // selected target inter cell number
    int32_t maxCellRank;                        // max value of cell rank for cell nbrs
    int32_t currentCellRank;                    // rank value for currently checked cell
    cellSelection_type bestIntraCells[MAX_NBR_PER_CELL];  // table of best intra cells selected
    uint32_t bestInterCells[MAX_NBR_PER_CELL];  // table of best inter cells selected
} tgtCellSelectionContextInfo_type;

/**
 * @brief Xn neighbor GNB information
 */
typedef enum
{
    ngRanNode_GnbType = 0,   // gnb-type
    ngRanNode_ngEnbType = 1  // ng-enb-type
} enumNgRanNodeType;

typedef struct
{
    // Warning : This internal value is not valid for Intra-gNB.

    amfSetInformation_type amfSetInfo[MAX_AMF_SET_INFO];  // 0 .. 15
    MdsIp_Type remoteIpAddress;
} xnNbrExtension_type;

typedef struct
{
    // This structure scope handles the Intra-gNB behavior of FnVCCB_GetXnNbrInfo. (Intra-gNB OK, Inter-gNB OK)
    struct
    {
        struct
        {
            uint8_t ngRanNodeId : 1;
            uint8_t plmnMcc     : 1;
            uint8_t plmnMnc     : 1;
            uint8_t reserved    : 5;
        } present;

        /* Mandatory */
        uint8_t status; /* N_EQUIP, EQUIP */
        uint8_t xnapLinkState   : 1;
        uint8_t isSamsungVendor : 1;
        uint8_t reserved        : 6;

        int8_t ngRanNodeType;

        /* Optional */
        union
        {
            gnbId_type gnbId;
            enbId_type enbId;
        };

        plmnId_type plmn;
    };

    // This structure scope not handles the Intra-gNB behavior of FnVCCB_GetXnNbrInfo. (Intra-gNB NOK, Inter-gNB OK)
    xnNbrExtension_type extension;
} xnNbrInfo_type;

typedef struct
{
    struct
    {
        uint8_t gnbId      : 1;
        uint8_t gnbPlmnMcc : 1;
        uint8_t gnbPlmnMnc : 1;
        uint8_t reserved   : 5;
    } present;

    /* Mandatory */
    uint8_t status; /* N_EQUIP, EQUIP */
    gnbId_type gnbId;
    plmnId_type gnbPlmn;

} xnHoBlackNbrInfo_type;

typedef struct
{
    uint8_t status;       // N_EQUIP, EQUIP
    int8_t serviceState;  // OpState_unknown: -1, OpState_disabled: 0, OpState_enabled: 1
    uint16_t taiSupportCnt;
    uint16_t gNBIdx;
    uint8_t samsungVendorInd : 1;
    uint8_t reserved         : 7;
    uint32_t gNBId;  // This DB is the GNB ID of Serving GNB.
    uint32_t tac[MAX_XN_TAI_SUPPORT_COUNT];
    uint32_t plmn[MAX_XN_TAI_SUPPORT_COUNT];
    uint32_t sNssai[MAX_XN_TAI_SUPPORT_COUNT];
} xnTaiInfo_type;

typedef struct
{
    uint16_t sNssaiCnt;
    uint32_t sNssai[MAX_XN_TAI_SUPPORT_COUNT];
} sNssaiList_type;

typedef struct
{
    uint8_t status; /**< EQUIP/N_EQUIP */
    uint16_t cellNum;
} cellInDu_type;

typedef struct
{
    // SVR X.Y.Z-abcd PKG version
    //    - X: Major package digit
    //    - Y: Minor package digit between major packages
    //    - Z: Temporary package digit like trial and demo
    //    - ab: Applied patch number  (It can start from "00")
    //    - cd: Applied emergency patch number
    //
    // For example: 22.B.0-0100
    char text[MAX_SW_VERSION_LEN+1];
} swVersionRaw_type;


typedef struct
{
    uint32_t xyz;
    swVersionRaw_type raw;
} swVersion_type;

/**
 * @brief gnbDu (endPointF1/DU overload) information
 */
typedef struct
{
    uint8_t status; /**< EQUIP/N_EQUIP (confd) */
    uint64_t gnbDuId;
    uint32_t gNBIdx;
    uint8_t nrofCells;
    cellInDu_type cellInDu[MAX_CELL_PER_DU];
    uint8_t boardType;  // enumBoardType
    enumOverloadInfo_type overloadStatus;
    uint8_t rrcVersion[3];
    swVersion_type swVersion;
    uint8_t pldStatus; /**< EQUIP/N_EQUIP (pld) */
} gnbDuInfo_type;

typedef struct
{
    uint8_t ulRohcEnabled;
    uint8_t symmetricRohcEnabled;
    struct ulRohcConfig_s
    {
        uint8_t ulRohcMaxSession;
        uint8_t useProfile006;
        uint8_t drbContinueRohc;
    } ulRohcConfig;
    struct symmetricRohcConfig_s
    {
        uint8_t symmetricRohcMaxSession;
        uint8_t useProfile000;
        uint8_t useProfile001;
        uint8_t useProfile002;
        uint8_t useProfile004;
        uint8_t contRohcContextSupport;
    } symmetricRohcConfig;

    uint8_t reserved;
} rohCConfig_type;

typedef struct
{
    uint8_t ehcSupportEnabled;                //header-compression-oper
    struct ehcConfig_s
    {
        uint16_t ehcMaxSession_ul;     //max_context_ul
        uint16_t ehcMaxSession_dl;     //max_context_dl
        uint8_t ehcContextContinue_ul; // ehc-context-continue-ul
        uint8_t ehcContextContinue_dl; // ehc-context-continue-dl
        uint8_t ehc_CIDlength;         //context-length
        uint8_t reserved;
    } ehcConfig;

} ehcConfig_type;

typedef struct
{
    uint8_t instantMrResyncCellChangeFlag;
    uint8_t directResyncFlag;
    uint8_t suspendResumeFlag;
} failureCauseType_type;

typedef struct
{
    uint8_t weightFactor;
    int32_t suspendTimer;
} suspendTimerPerQci_type;

typedef struct  // NEDC_SCG_FAILURE_20C
{
    enumNeDcScgFailureHandlingOptionType_type handlingOption;
} neDcFailHandlingOptType_type;

typedef struct
{
    neDcFailHandlingOptType_type nedc_failureCauseType[MAX_NEDC_SCG_FAIL_CAUSE_TYPE];  // NEDC_SCG_FAILURE_20C
    failureCauseType_type failureCauseType[MAX_SCG_FAIL_CAUSE_TYPE];
    suspendTimerPerQci_type suspendTimerPerQci[MAX_QCI_VALUE];
    int16_t defaultTimerValue;
    uint8_t defaultWeightFactorValue;
    uint8_t dynamicSelectionCriteria;  // YANG enum: RSRQ/RSRP
    uint8_t rsrpThreshold;
    uint8_t rsrqThreshold;
} scgFailureHandlingInfo_type;

// SVR22B SCG Failure
typedef struct
{
    enumNrDcScgFailureHandlingOption_type nrdcFailureOption[NRDC_SCG_FAIL_CAUSE_TYPE_MAX + 1];
    int32_t suspendTimer;
    uint8_t allowSNAdditionUECustomSignature;
    uint8_t blockedGnbSupport;  // SVR23A SCG Failure
} scgFailureHandlingInfoNrDc_type;

/**
 * @brief FGR-CC0413 QoS flow to DRB mapping
 */
typedef struct
{
    uint8_t sst;
    uint32_t sd;
    uint32_t status;
} SliceSupportedInfo_type;
typedef struct
{
    plmnId_type plmn;
    uint32_t status;
} PlmnSupportedInfo_type;

typedef struct
{
    uint8_t status;
    uint8_t qos5qi;            // 0 means 'not used', 1~255
    uint8_t arpPriorityLevel;  // 0 means 'not used', 1~15
    SliceSupportedInfo_type sliceInfo[MAX_SLICE_INFO_PER_DRB];
    PlmnSupportedInfo_type plmnInfo[MAX_PLMN_INFO_PER_DRB];
} dedicatedQosFlowGroup_type;

typedef struct
{
    uint8_t status;
    uint8_t qos5qi;            // 0 means 'not used', 1~255
    uint8_t arpPriorityLevel;  // 0 means 'not used', 1~15
    uint8_t qosFlowGroupId;    // 1~31
    SliceSupportedInfo_type sliceInfo[MAX_SLICE_INFO_PER_DRB];
    PlmnSupportedInfo_type plmnInfo[MAX_PLMN_INFO_PER_DRB];

} mappingRule_type;

typedef struct
{
    dedicatedQosFlowGroup_type dedicatedQosFlowGroupInfo[MAX_DEDICATED_QOS_FLOW_GROUP_INDEX];
    mappingRule_type mappingRuleInfo[MAX_MAPPING_RULE_INDEX];
    uint16_t isSliceMappingSupported;
    uint16_t isPlmnMappingSupported;
    uint16_t reserved;
} qosDrbMappingConf_type;

typedef struct TraceId_s
{
    unsigned char data[3];
} TraceId_type;

typedef struct TraceReference_s
{
    plmnId_type plmn;
    TraceId_type traceId;
} TraceReference_type;

/**
 * @brief SPID Information
 */
typedef struct
{
    uint8_t spidInUseFlag;
    uint32_t spCellArfcn[MAX_SSB_FREQ_PER_SPID];  // Sorted
    uint16_t numSpCellArfcn;
    uint32_t sCellArfcn[MAX_SSB_FREQ_PER_SPID];  // Sorted
    uint16_t numSCellArfcn;
} spidBasedServingCellSelectionEntries_type;

typedef struct
{
    spidBasedServingCellSelectionEntries_type
        spidBasedServingCellSelectionEntries[MAX_SPID_VALUE +
                                             1];  // Defaults stored under index 0, SPID values from 1 to 256.
    uint8_t spidBasedForPlmnEnable;
} spidInfo_type;

typedef enum
{
    choice_event_l1_rsrp_option = 0,
    choice_event_l1_rsrq_option = 1,
    choice_event_l1_sinr_option = 2,
} enumEventL1ThresholdOption_type;

typedef enum
{
  VOMA_UNKNOWN = 0,
  VOMA_PREPARATION_REQ, // UP ONLY
  VOMA_PREPARATION, // UP ONLY
  VOMA_START_REQ,
  VOMA_STARTED,
  VOMA_STOP_REQ,
  VOMA_STOPPED
} vomaActivationStatus_type;

typedef struct
{
  vomaActivationStatus_type duStatus;
  vomaActivationStatus_type upStatus;
} vomaDrbStatus_type;

/**
 * @brief Helper structure to hold IPs or FQDN
 */
typedef struct
{
    MdsAddr_Type ip;  // MdsIp_Type can be one of three, MDS_IPV4 = 4 , MDS_IPV6 = 6, TCE_FQDN = 0xFF
    char fqdn[MAX_TRACE_TCE_URI_LEN];
} TceAddress_type;


typedef struct
{
    uint8_t hysteresis;
    uint8_t timeToTrigger;
    enumEventL1ThresholdOption_type thresholdOption;
    union uThreshold
    {
        uint8_t rsrp;
        uint8_t rsrq;
        uint8_t sinr;
    } threshold;
} loggedMdtEventL1_type;

/**
 * @brief MDT Configuration structure
 *        FGR-SO1101 NR Minimization of Drive Tests (NR MDT)
 */
typedef struct
{
    TceAddress_type tceAddress;
    uint8_t tceId;
    uint8_t anonymizationLevel;  // enumMdtAnonymization
    uint8_t ignoreUeConsent;     // bool, TRUE = 1, confD : ignore-ue-consent

    struct
    {
        uint8_t functionOnOff;  // bool, TRUE = 1

        struct
        {
            struct
            {
                struct
                {
                    uint8_t activation;        // bool, TRUE = 1
                    uint8_t reportingTrigger;  // enumMdtReportingTrigger_type
                } specific;

                uint8_t activationExistingRrm;        // bool, TRUE = 1
                uint8_t gnssPositioning;              // bool, TRUE = 1
                uint8_t gnssTargetUeSelectionMethod;  // enumM1GnssTargetUeSelectionMethod_type
            } m1;

            struct
            {
                uint8_t activation;  // bool, TRUE = 1
            } m2;

            struct
            {
                uint8_t activation;        // bool, TRUE = 1
                uint8_t collectionPeriod;  // m5-m6: enumMdtTraceCollectPeriod, m7: minutes 1-60
                uint8_t linksToLog;        // enumMdtTraceDir_type
            } m4, m5, m6, m7;

        } measurements;

    } immediate;

    struct sLogged
    {
        uint8_t functionOnOff;  // bool, TRUE = 1
        uint8_t loggingDuration;  // enum access-enum-logging-duration
        uint8_t loggingInterval;  // enum access-enum-logging-interval
        uint8_t reportType;       // enum access-enum-logging-report-type
        uint8_t areaScopeType;    // enum access-enum-logging-area-scope

        struct sAreaScope
        {
            struct sCell  // YANG list mdt-cell-list
            {
                uint32_t tac;           // YANG mdt-tac
                uint64_t cellIdentity;  // YANG mdt-cell-identity
                plmnId_type plmn;       // YANG access-s5gtype:plmn-identity
                uint8_t status;         // EQUIP / N_EQUIP
            } cell[MAX_MDT_CELLS_IN_AREA];

            struct sTacList  // YANG list mdt-tac-list
            {
                uint32_t tac;    // YANG mdt-tac
                uint8_t status;  // EQUIP / N_EQUIP
            } tac[MAX_MDT_TACS_IN_AREA];

            struct sTaiList  // YANG list mdt-tai-list
            {
                plmnId_type plmn;  // YANG access-s5gtype:plmn-identity
                uint32_t tac;      // YANG mdt-tac
                uint8_t status;    // EQUIP / N_EQUIP
            } tai[MAX_MDT_TAIS_IN_AREA];
        } scope;

        struct sNbrInterFreqCellList  // YANG list mdt-neighbor-inter-freq-cell-list
        {
            uint32_t dlFreq;  // YANG dl-freq
            struct pciList    // YANG list pci-list
            {
                uint32_t pci;    // YANG pci
                uint8_t status;  // EQUIP / N_EQUIP
            } pciList[MAX_MDT_NEIGHBOR_CELL_PCIS];
            uint8_t status;  // EQUIP / N_EQUIP
        } nbrInterFreqCell[MAX_MDT_NEIGHBOR_INTER_FREQ_CELLS];

        loggedMdtEventL1_type eventL1;
    } logged;

} MdtSessionConfiguration_type;

/**
 * @brief Trace Session configuration structure
 *        FGR-TA0103 Cell traffic trace
 *        FGR-SO1101 NR Minimization of Drive Tests (NR MDT)
 */
typedef struct
{
    traceReference_type cellTraceReference;           // confD : mcc, mnc, trace-id
    uint32_t cellTRSR[MAX_UE_PER_CELL_TRACE_SESSION]; // if TRSR asigned entry contain ID of call otherwise set >= MAX_CALL_NUM_VCCB
    uint16_t pldCellIndex;                            // cellIdx of PLDCellStatus for quick access
    uint16_t cellTrsrAllocIdx;                        // TRSR allocation index for this session
    uint16_t allocatedTRSRCount;                      // total number (per cell) of UEs with active cell or mdt or both
    uint8_t traceSessJobOnOff;                        // confD : enabled/disabled
    struct timespec lastAuditTime;

    struct
    {
        uint8_t statuses;                  // BIT FIELD
        plmnId_type plmn[MAX_PLMN_INDEX];  // confD : target-plmns
    } targetPlmns;

    struct
    {
        uint16_t cellTraceUeCountCpc;           // current number of UE allocated for this session (cell) on this CPC only
        uint16_t cellMaxUeNum;                  // confD : maximum number of traced UEs for cell
        uint8_t cellTraceAllowedFlag;           // PLDCellStatus : cellTraceAllowedFlag. VTMB controls this flag based on current
                                                // number of Cell Trace Recording Sessions
        uint8_t traceDepth;                     // confD : trace detail level
        uint8_t interfaces;                     // confD : interfaces to monitor
        uint8_t throughputAndRfTraceOnOff;      // UE Throughput & RF Trace activation
                                                // copy of same global (GlobalTraceInfo_type) field value
                                                // updated only at (re)start of trace session
        TceAddress_type tce1Address;            // confD : tce-ip-address-1
        TceAddress_type tce2Address;            // confD : tce-ip-address-2
        uint8_t tce1Id;                           // tceId from predefined-tce list.
        uint8_t tce2Id;                           // tceId from predefined-tce list.
    } trace;

    struct
    {
        uint16_t immediateMdtUeCountCpc;
        uint16_t loggedMdtUeCountCpc;
        uint8_t immediateMdtAllowedFlag;
        uint8_t loggedMdtAllowedFlag;
        MdtSessionConfiguration_type mdtSessionConfiguration;
    } mdt;

    struct
    {
        uint8_t immediate : 1;
        uint8_t logged    : 1;
        uint8_t trace     : 1;
        uint8_t rlf       : 1;
        uint8_t rcef      : 1;
    } managementJobType;

} ManagementTraceSessionPerCell_type;

typedef struct  {
    uint16_t immediateMdtUeCountCpc;
    uint16_t loggedMdtUeCountCpc;
} SignalingMdtUeCountersPerCell_type;

/**
 * @brief Trace Predefined global servers
 */
typedef struct
{
    uint8_t status;
    TceAddress_type server;
    MdsIp_Type tceIpFromFqdn;
} PredefinedTceServers_type;

typedef struct
{
    uint32_t sentIpcMsgsCount;
    uint32_t droppedIpcMsgsCount;
} TraceMessageCounters_type;

typedef struct
{
    uint8_t usage;
    uint16_t index;
} RfspSpidIndex_type;

typedef struct
{
    uint8_t filteringOnOff;
    RfspSpidIndex_type spids[TRACE_RFSP_SPID_FILTERING_SIZE];
    RfspSpidIndex_type rfsps[TRACE_RFSP_SPID_FILTERING_SIZE];
} RfspSpidFilteringConfiguration_type;

typedef struct
{
    uint32_t statuses;                               // bit i: entry equipped
    char tac[MAX_IMEI_TAC_INDEX][IMEI_TAC_BUF_SIZE]; // tac[i]: -> TAC
    uint8_t count;                                   // actual count of TAC entries
} AllowedImeiTacList_type;

#define TRACE_AUDIT_HIST_SIZE 3

/**
 * @brief Global Trace feature configuration structure
 *        FGR-TA0103 Cell traffic trace
 *        FGR-SO1101 NR Minimization of Drive Tests (MDT)
 */
typedef struct
{
    uint8_t cellTraceOnOff;   // confd: common-management/trace-configuration/cell-trace-configuration/cell-trace-onoff
    uint8_t overloadOnOff;    // confd: common-management/trace-configuration/overload-onoff
    uint8_t stopThreshold;    // confd: common-management/trace-configuration/stop-resume-thresholds
    uint8_t resumeThreshold;  // confd: common-management/trace-configuration/stop-resume-thresholds
    uint16_t loggedRetrieveTimer;   // common-management/trace-configuration/mdt-configuration/logged-mdt-retrieve-timer
    uint16_t acpfTraceAllowedFlag;  // PLDTraceStatus: acpfTraceAllowedFlag. VTMB controls this flag based on current
                                    // total number of Trace Recording Sessions
    uint32_t maxAcpfTracesNum;      // confd: common-management/trace-configuration/acpf-max-traces-number
    uint32_t msgAggregatedSize;     // number of bytes of aggregted Trace IPC messages sent to VTMB in single bundle
    uint32_t msgAggregatedTime;     // tmout for aggregation buffer flush
    uint8_t traceDisabledDueOverload;
    uint8_t pldLimitCheck;          // check CPC UE limit using PLD flag distributed by VTMB
    uint8_t acpfCpcCnt;             // number of CPC in ACPF
    uint8_t reportingType;
    uint8_t deactTimer;             // value in seconds, used to calculate time window after which deactivation of trace will be
                                    // called after trace feature deactivation by db entry state change (trace-session-on-off = OFF)
    uint8_t a2DeltaThrOnOff;        // confd: common-management/trace-configuration/mdt-configuration/apply-delta-threshold-for-mdt-purpose-event-a2-onoff
#ifdef __CNF__
    TraceMessageCounters_type msgCountersPerThread[VCCB_CALL_THREAD_NUM][VCCB_MAX_POD_ID_NUM];
#else
    TraceMessageCounters_type msgCountersPerThread[VCCB_CALL_THREAD_NUM];
#endif
    PredefinedTceServers_type predefinedTceServers[TCE_MAX_NUMBER];  // common-management/trace-configuration/predefined-tce

#ifdef __CNF__
    uint8_t operationalCtpNum; //Multiple CTP
#endif

    uint8_t m6MeasOnOff;            // confd: common-management/trace-configuration/mdt-configuration/m6-ul-pdcp-delay-ue-measurement-onoff

    struct management_s
    {
        uint32_t totalMgtUeCountCpc;    // total number of management trace related sessions (Cell Trace, UeThr, Immediate and Logged mdt)
        struct
        {
            uint8_t selectionRate;                      // common-management/trace-configuration/mdt-configuration/mdt-selection-rate
            uint8_t loggedSelectionRate;                // common-management/trace-configuration/mdt-configuration/logged-mdt-selection-rate
            uint8_t imeiTacFilterOnOff;                 // common-management/trace-configuration/mdt-configuration/mdt-imei-tac-filter/imei-tac-filter-onoff
            AllowedImeiTacList_type allowedImeiTacList; // common-management/trace-configuration/mdt-configuration/mdt-imei-tac-filter/allowed-imei-tac-list
        } mdt;

        uint8_t auditTimer;                 // value in minutes, period after which cell trace audit will be triggered
        uint8_t throughputAndRfTraceOnOff;  // common-management/trace-configuration/cell-trace-configuration/throughput-and-rf-trace-onoff
        uint32_t cellTraceUeCountCpc;       // number of CTT UE allocated in CPC (all cell)

        RfspSpidFilteringConfiguration_type rfspSpidFiltering;

        struct traceAuditHist_s
        {
            uint8_t head;
            struct entry_s
            {
                time_t tv_sec;
                uint16_t rmCnt;
                uint16_t cellNum;
            } entry [TRACE_AUDIT_HIST_SIZE];
        } traceAuditHist;

        uint8_t gnssBasedM1TransmissionOnOff;   // common-management/trace-configuration/mdt-configuration/gnss-based-m1-transmission-onoff

    } management;

    struct
    {
        uint16_t totalSigUeCountCpc;    // total number of signaling trace related sessions (Cell Trace, UeThr, Immediate and Logged mdt)
        uint8_t sigTraceAllowedFlag;    // PLDTraceStatus: sigTraceAllowedFlag.   VTMB controls this flag based on
                                        // current total number of Trace Recording Sessions
        struct
        {
            uint16_t traceUeCountCpc;           // current number of UEs traced under UE Trace feature on this CPC only

            uint8_t nsaSignalingTraceOnOff;     // common-management/trace-configuration/signaling-trace-configuration/nsa-signaling-trace-onoff
            uint8_t tceReplacementOnOff;        // common-management/trace-configuration/signaling-trace-configuration/tce-replacement-onoff
            uint8_t endcX2TraceOnOff;           // common-management/trace-configuration/signaling-trace-configuration/endc-x2c-interface-trace-onoff
            uint8_t throughputAndRfTraceOnOff;  // common-management/trace-configuration/signaling-trace-configuration/throughput-and-rf-trace-onoff
            uint8_t nrdcSignalingTraceOnOff;    // common-management/trace-configuration/signaling-trace-configuration/nrdc-signaling-trace-onoff
            uint8_t nrdcSnXnTraceOnOff;         // common-management/trace-configuration/signaling-trace-configuration/nrdc-sn-xnc-interface-trace-onoff
        } trace;

        struct
        {
            uint8_t mdtOnOff; // common-management/trace-configuration/mdt-configuration/signaling-mdt-onoff
        } mdt;

    } signaling;
} GlobalTraceInfo_type;

/**
 * @brief Local Trace operational structure common for CELL and UE trace
 *        for build and send Trace Msg to VTMB
 */
typedef struct
{
    enumTrace_type traceType;            // UE/CELL
    enumDirection direction;             // Rx/Tx Indicator of collected Msg
    uint16_t pldCellIndex;               // cellIdx of PLDCellStatus for quick access
    uint16_t cellNum;                    // CellNum of selected Cell
    uint32_t cellId;                     // CellId  of selected Cell
    uint32_t gnbId;                      // gnbId   of selected Cell
    uint16_t crnti;                      // crnti   of selected Cell
    int32_t msgId;                       // Id        of collected Msg
    uint32_t sourceLength;               // length    of Collected Msg
    char *ptSourceMsg;                   // handler   to Collected Msg
    uint16_t traceRSR;                   // Trace Recording Session Reference
    traceReference_type traceReference;  // Trace Reference
    uint8_t traceInterface;              // Interface of Collected Msg
    uint8_t traceDepth;                  // Trace Depth information
    uint8_t mdtTceId;
    uint8_t tce1Id;
    uint8_t tce2Id;
    uint16_t traceRSNumCPC;  // current number of Trace Recording Sessions (UE or Cell depends on traceType field) on
                             // this CPC
    uint16_t traceUeNumCPC;  // current number of Trace UEs (Cell or Signalling) on this CPC
    uint16_t endPointIdx;    // identifier of UP
    uint8_t configTraceType; // enumTraceType
    uint8_t mdtType;         // enumJobType
    uint16_t msgSeqNum;      // number of already sent trace msg
} LocalTraceConfig_type;



typedef struct
{
    uint8_t indepGapEnabledEndc;
    uint8_t indepGapEnabledNr;
    struct
    {
        uint8_t enabled;
        int32_t timer;  // alternate-gap-timer, [100, 65535]ms, default 1000ms
    } alternateMeasGapConfig;
    uint8_t needForGapsNrEnabled;
    uint8_t needForGapsNrBandFilterBitmap[(MAX_NUM_NR_BAND + 7) / 8];
    uint8_t fr2GaplessFr1PcellEnabled;
    uint8_t needForGapsNrTdoaEnabled;
    uint8_t statUeMgrpPref; // enum, enumMGapStatUeMgrpPref_type
} measGap_type;

typedef struct
{
    uint8_t usage;    // CI_no_use/CI_use
    uint8_t enabled;  // FLAG_ON/FLAG_OFF
    uint16_t rfsp;    // 1 ~ 256
} periodicMeasRfspBased;

typedef struct
{
    uint8_t enabled;
    uint8_t snAdditionPurposeEnabled;
    uint8_t caScellAdditionPurposeEnabled;
    int32_t deactTimer;  // deactivation-timer, [100, 65535]ms, default 1000ms
    int32_t reactTimer;  // reactivation-timer, [100, 65535]ms, default 5000ms
    periodicMeasRfspBased rfspBased[MAX_PLMN_INDEX][MAX_RFSP_INDEX];
} periodicA4Meas_type;

typedef struct
{
    uint8_t saFphoPurposeA4Enabled;     // pcell-freq-prioritization-handover-purpose-A4-enabled
    uint8_t saFphoPurposeA5Enabled;     // pcell-freq-prioritization-handover-purpose-A5-enabled
    uint8_t endcSpidInterFHoA4Enabled;  // en-dc-spid-inter-frequency-nr-pscell-change-purpose-A4-enabled
    uint8_t endcSpidInterFHoA5Enabled;  // en-dc-spid-inter-frequency-nr-pscell-change-purpose-A5-enabled
    uint8_t scellAddEnabled;            // scell-addition-purpose-enabled (SA, NRDC)
    uint8_t rfspBasedFeatureEnabled;    // rfsp-based-feature-enabled (SA, NRDC)
    uint8_t endcSpidScellAddEnabled;    // en-dc-sn-spid-scell-addition-purpose-enabled
    uint8_t maxRepetitionCount;         // max-repetition-count [0, 255]
    int32_t deactTimer;                 // deactivation-timer, [1, 65535]s, default 10s
    int32_t reactTimer;                 // reactivation-timer, [1, 65535]s, default 300s
    periodicMeasRfspBased rfspBased[MAX_PLMN_INDEX][MAX_RFSP_INDEX];
    uint8_t endcSpidScellAddList[MAX_SPID_ARR_ELEM_SIZE_IN_BIT];    // en-dc-sn-spid-scell-addition-purpose-list
} longPeriodicMeas_type;

typedef enum
{
    choice_rsrp = 0,
    choice_rsrq = 1,
    choice_sinr = 2
} enumMeasTriggerQuantityChoice;


typedef enum
{
    EUTRA_RlfReport = 0,
    NR_RlfReport = 1
} enumRlfReportChoice;

typedef enum
{
    sonConfig_failureInd = 0,
    sonConfig_handoverRpt = 1,
    interSysSonConfig_failureInd = 2,
    interSysSonConfig_handoverRpt = 3
} enumSonConfigChoice;

typedef struct
{
    enumMeasTriggerQuantityChoice choice;
    uint8_t threshold;
} thresholdPerPurpose_type;

typedef struct
{
    uint8_t spidEnable                     : 1;
    uint8_t ulPrimaryPathSwitchFlagPerSpid : 1;
    uint8_t a1LegSwitchStatus              : 1;
    uint8_t a2LegSwitchStatus              : 1;
    uint8_t reserved                       : 4;
    thresholdPerPurpose_type a1LegSwitch;
    thresholdPerPurpose_type a2LegSwitch;
} spidThreshold_type;

typedef struct
{
    uint8_t featureEnabled;  // YANG: mobility-config-gnb/.../feature-enabled
    uint32_t timer;          // YANG: mobility-config-gnb/.../timer
} featureEnabledAndTimer_type;

typedef struct
{
    uint8_t featureEnabled;
    uint16_t threshold;
} featureEnabledAndThreshold_type;

// XNAP_radio_connection_with_UE_lost, DL RLF Cause
typedef struct  // NEDC_SCG_FAILURE_20C
{
    enumNeDcScgFailCause_type failType;
} neDcScgFailureInfoEutraResult_type;

typedef struct  // NEDC_SCG_FAILURE_20C
{
    uint8_t support;  // FALSE. TRUE
    uint8_t reserved;
    uint16_t time;
} nedc_BlackCellConfig_type;

typedef struct
{  // NEDC_SCG_FAILURE_20C
    uint16_t state;
    uint64_t ci;
    uint32_t longId;  // PLMN
    uint32_t enbId;
    long endTime;  // If the cell is a black cell
} blacklistedCell_type;

typedef struct
{  // NEDC_SCG_FAILURE_20C
    uint8_t numBlackCells;
    blacklistedCell_type blacklist[MAX_BLACK_CELL];
} blacklistedCellInfo_type;

typedef struct
{                     // NEDC_SCG_FAILURE_20C
    uint16_t status;  // EQUIP or N_EQUIP
    uint16_t nbrIdx;
    uint32_t enbId;
    cgi_type eutraCgi;  // 28bit EUTRA Cell Identifier : 20 bit ng-eNB ID, 8 bit Cell ID
} neDcPsCellInfo_type;

typedef enum
{
    e_SliceAware_Partial_Mobility_Mode1 =
        0,  // partial-mobility-mode1: Intra-NR Handover is triggered when every slice supported target cell.
    e_SliceAware_Partial_Mobility_Mode2 =
        1,  // partial-mobility-mode2: Intra-NR Handover is triggered when at least one slice supported target cell.
    e_SliceAware_Partial_Mobility_Mode3 =
        2,  // partial-mobility-mode3: auto mode (SVR26B FGR-MC1021)
    e_SliceAware_MaxOfRange
} enumSliceAwareMobilityMode_type;

typedef struct
{
    int16_t rfsp;   // -1 or 1..256 , -1 means not_configured (YANG union)
    int16_t sst;    // -1 or 0..255
    uint32_t sd;    // 0..16777214 or 16777215 (not configured)
} prioritySliceInfo_type;

typedef enum
{
    sliceAwareAutomodeState_init = 0,
    sliceAwareAutomodeState_running,
    sliceAwareAutomodeState_expired,
} enumSliceAwareAutomodeState_type;

typedef enum
{
    prioritySliceAwareState_init = 0,
    prioritySliceAwareState_active,
    prioritySliceAwareState_notSupported,
    prioritySliceAwareState_expired,
} enumPrioritySliceAwareState_type;

typedef struct
{
    timerInfo_type prioritySliceTimer;
    timerInfo_type autoModeTimer;
} sliceAwareUeInfo_type;

typedef struct
{
    uint8_t usage;
    uint32_t ssbFreq;
    uint8_t thresholdRsrp;
    uint8_t thresholdRsrq;
    uint8_t thresholdSinr;
} endcPscellSelectionThreshold_type;

typedef enum
{
    sc_Macro_Enb_Id_Length = 20,
    sc_Home_Enb_Id_Length = 28,
} enumSmallCellEnbIdLength_type;

typedef struct
{
    uint8_t saToNsaBorderMobilitySupport : 1;
    uint8_t saToNsaEfemtoMobilitySupport : 1;
    uint8_t voNRBorderMobilitySupport    : 1;
    uint16_t blindRedirectionTimer;
} saToNsaBorderMobility_type;

#define MAX_SPECIFIC_SLICE_INFO_ENTRIES 2 // SVR25B FGR-MC1021::FR100

typedef struct
{
    uint8_t usage;
    uint32_t sstSd;
} specificSliceInfo_type;

typedef struct
{
    uint8_t usage;
    uint8_t modeOption; // 26A FR160 specific-slice-aware-option > lte-only, nr-first
    uint16_t mrWaitTimer;
    uint16_t nrPriorityTimer; // 26A FR161 nr-priority-timer
    specificSliceInfo_type sliceInfo[MAX_SPECIFIC_SLICE_INFO_ENTRIES];
} specificSliceConfig_type; //FGR-CC3101, FGR-CC0102, FGR-CC0103, FGR-MC1021

typedef struct
{
    uint8_t mobilityMode;  // FGR-MC1021 SVR21B : Slice Aware Mobility Control, enumSliceAwareMobilityMode_type
    uint8_t targetSliceAwareEnabled; //FGR-MC1021:FR60 off/on
    uint16_t sliceAwareModeChangeTimer;  // ms, YANG slice-aware-mode-change-timer (100..65535)
    prioritySliceInfo_type prioritySliceInfo;
    specificSliceConfig_type specificSliceConfig;
} sliceAware_type;

typedef struct
{
    uint16_t ltmBlockedTimer;               // 100 - 65535ms
    uint16_t cellSwitchPreparationTimer;    // 100 - 65535ms
    uint16_t cellSwitchTimer;               // 100 - 65535ms
} ltmGnbConfig_type;

typedef struct
{
    uint8_t pingPongAvoidanceCause; // enumPingPongAvoidanceCause_type
    uint8_t useForOnDemandHO; // 26A FR80
    uint8_t useForTrafficBasedEutraHO; // 26A FR60
    uint8_t useForMultiCarrierOperation;
    uint8_t useForUlStatusBasedMobility;
    uint8_t restrictionTimer; /**< FR530: YANG enum min5(0)..min180(6), default min30(3) */
} pingPongAvoidanceConfig_type;

typedef struct
{
    uint8_t endcRejectRequestNoCellAboveThreshold;
    uint8_t allowIntraSnInterPlmnChange;
    uint8_t smallCellEnbIdLength;           // FGR-MC1028 24A FR10, enumSmallCellEnbIdLength_type
    uint8_t rfspTransmitIratHoSwitch;  // IRAT_HO_24A Whether to transmit the RFSP value to LTE
    uint8_t rsrpThresholdForCaAwareByA2; // SVR24A FGR-MC1022 FR120
    uint8_t ueBasedCgiReportingForHandoverGbr; // SVR24B FGR-MC1007 FR161, reportCgiGbrSwitch_type
    uint8_t ueBasedCgiReportingForEndcPscellChangeGbr; // FGR-CC5001 FR237, reportCgiGbrSwitch_type
    uint8_t partialSuccessForMultipleDrbEnabled; // SVR25A FGR-MC1009 FR199
    uint8_t interVendorIntraNrHandoverAllowed;
    bool isSnSelectionUsingSelectedBandCombSnSupportNrdc; // FGR-CC5201, FR650.CACP.SR1.HD2
    bool endcSnReleaseOnPscellChangeMrIgnored;      // FGR-CC5001 FR83
    bool endcSnReleaseOnPscellChangeMrIgnoredUnknownPci; // FGR-CC5001 FR84
    bool endcRejectMcgMobWhileWaitingForMnResponse; // FGR-CC5001 FR500.
    bool registerNrSmallCellAsNeighbor;     // FGR-MC1028 24A FR11
    bool registerEutraSmallCellAsNeighbor;  // FGR-MC1028 24A FR11
    bool interVendorEndcHandoverSupport;    // FGR-CC5001 FR242, off/on
    uint16_t smallCellGnbIdLength;          // FGR-MC1028 24A FR10
    uint32_t callReleaseTimerByUplinkStatusIndication;   // FGR-MC1029, FGR-CC5001 FR152
    endcPscellSelectionThreshold_type endcPscellSelectionThreshold[MAX_ENDC_PSCELL_SELECTION_THRESHOLD_ENTRIES];
    featureEnabledAndThreshold_type pdcpBufferBasedFr2PSCellChange;
    saToNsaBorderMobility_type saToNsaBorderMobility; // FGR-MC1007 FR380
    sliceAware_type sliceAware;
    ltmGnbConfig_type ltmConfig;
    pingPongAvoidanceConfig_type pingPongAvoidanceConfig;

    // FGR-CC5001 FR75, FR77 - Frequency Priority (FP) based inter-frequency PScell change.
    struct NsaFreqPrioInterFreq
    {
        bool freqPrioScellToPScellSwitchFlag : 1; // fp-based-inter-frequency-scell-to-pscell-switch-enabled
        bool freqPrioPSCellChangeFlag        : 1; // fp-based-inter-frequency-pscell-change-enabled
        bool freqA1ActivationFlag            : 1; // fp-based-inter-frequency-a1-activation-enabled
        bool spidPrioPSCellChangeFlag        : 1; // spid-based-inter-frequency-pscell-change-enabled
    } nsaFreqPrioInterFreq;

    struct PlmnSupportEntries
    {
        bool usage : 1;
        NsaFreqPrioInterFreq nsaFreqPrioInterFreq;
    } plmnSupportEntries[MAX_PLMN_INDEX]; // plmn-support-entries
} gnbMobilityConfig_type;

typedef struct
{
    uint8_t priority;
    uint8_t subpriorityUsage;
    uint8_t subpriority;
} priorityOfCarrier_type;

typedef struct
{
    uint8_t svcGrpId;
    uint32_t usage                                       : 1;
    uint32_t numOfChoCandidateCell                       : 4;
    uint32_t trafficBasedNrToEutraHOSupport              : 1;
    uint32_t nrToEutraHandoverNotAllowed                 : 1;
    uint32_t loadBalancingHandoverAllowed                : 1;
    uint32_t timerBasedMrBasedInterRatRedirectionSupport : 1;   // SVR24B FGR-MC1007 FR391
    uint32_t mrBasedRedirectionTimer                     : 16;  // SVR24B FGR-MC1007 FR391
    uint32_t preventingRfspSpecificDeltaCfg              : 1;   // SVR25A FGR-MC1023 FR50
    uint32_t pccChangeAllowed                            : 1;   // SVR25B FGR-CC5500 FR20
    uint32_t serviceBasedFreqPrioritySupport             : 1;   // SVR25B FGR-MC1022 FR210
    uint32_t restrictTrafficBasedNrToEutraHOPerUe        : 1;   // SVR25B FGR-MC1024 FR20
    uint32_t reserved1                                   : 2;
    uint8_t numOfLtmCandidateCell;                              // SVR25B FGR-MC1034 FR10

    struct SvcBasedImld_s
    {
        uint16_t svcBasedIdleLbAllowed                  : 1;
        uint16_t operationMode                          : 1;  // operation-mode-for-idle-load-balancing
        uint16_t redCapUeSwitch                         : 1;  // redcap-idle-load-balancing-switch
        uint16_t autoModeRsuType                        : 1;  // resource-mode-option-for-idle-lb-auto-mode
        uint16_t redCapUeAutoModeRsuType                : 1;  // resource-mode-option-for-idle-lb-redcap-auto-mode
        uint16_t reserved                               : 11;

        priorityOfCarrier_type maxPriorityOfNonZeroDistRatioCarrier;
        priorityOfCarrier_type maxPriorityOfZeroDistRatioCarrier;
    } imlb; // FGR-LC0709

} SvcGrpBasedCfg_type;  // 23B FGR-MC1019

// 1. SA Service Configuration Structure
typedef struct
{
    uint8_t  plmn_index;            // key: 0..7
    uint8_t  service_sa_index;      // key: 0..31
    uint8_t  service_sa_usage;      // 0=not-use, 1=use

    /* service-sa-profile (0 = wildcard / list not configured) */
    uint8_t  numSlice;
    uint8_t  numQos5qi;
    uint8_t  numArp;
    uint8_t  numRfsp;
    uint8_t  numUeType;

    struct {
        uint32_t sstSd;
    } slice[MAX_SVC_CONFIG_8];                      // max 8
    uint8_t  qos_5qi[MAX_SVC_CONFIG_16];            // max 16
    uint8_t  arp[MAX_SVC_CONFIG_8];                 // max 8
    uint16_t rfsp[MAX_SVC_CONFIG_8];                // max 8
    uint8_t  ue_type[MAX_SVC_CONFIG_UE_TYPE];       // max 3 (0=normal, 1=redcap, 2=eRedCap)
} svcCfgSa_type;

// 2. ENDC Service Configuration Structure
typedef struct
{
    uint8_t  plmn_index;            // key: 0..7
    uint8_t  service_endc_index;    // key: 0..15 (YANG range)
    uint8_t  service_endc_usage;    // 0=not-use, 1=use

    /* service-endc-profile (0 = wildcard / list not configured) */
    uint8_t  numSpid;
    uint8_t  numQosQci;
    uint8_t  numArp;

    uint16_t spid[MAX_SVC_CONFIG_8];                // max 8
    uint8_t  qos_qci[MAX_SVC_CONFIG_8];             // max 8
    uint8_t  arp[MAX_SVC_CONFIG_8];                 // max 8
} svcCfgEndc_type;

// 3. Matched Entry Structure
typedef struct
{
    uint8_t plmn_index;
    uint8_t service_index;
} svcCfgMatchEntry_type;

// 4. Matched Result Structure
typedef struct
{
    uint8_t count;
    svcCfgMatchEntry_type entries[MAX_SVC_SA_ENTRIES];
} svcCfgMatchResult_type;

typedef struct
{
    uint8_t usage;
    uint8_t qos5qi;
} qos5qiEntry_type;

typedef struct
{
    uint8_t usage;
    uint32_t sstSd;
    qos5qiEntry_type qos5qiEntries[MAX_SVC_GRP_CONFIG_5QI_NUM];
} sliceFiveqiEntry_type;

typedef struct
{
    sliceFiveqiEntry_type sliceFiveqi[MAX_SVC_GRP_CONFIG_SLICE_NUM];
} sliceFiveqiRule_type;

typedef struct
{
    uint8_t usage;
    uint32_t sstSd;
} sliceEntry_type;

typedef struct
{
    sliceEntry_type slice[MAX_SVC_GRP_CONFIG_SLICE_NUM];
} sliceRule_type;

typedef struct
{
    qos5qiEntry_type qos5qiEntries[MAX_SVC_GRP_CONFIG_5QI_NUM];
} qos5qiRule_type;

typedef struct
{
    uint8_t usage;
    uint8_t arpValue;  // 1...15(MAX_ARP_LEVEL - 1)
} arpEntry_type;

typedef struct
{
    arpEntry_type arp[MAX_SVC_GRP_CONFIG_ARP_NUM];
} arpRule_type;

typedef struct
{
    uint8_t usage;
    uint8_t arpValue;  // 1...15(MAX_ARP_LEVEL - 1)
    qos5qiEntry_type qos5qiEntries[MAX_SVC_GRP_CONFIG_5QI_NUM];
} ArpFiveqiEntry_type;

typedef struct
{
    ArpFiveqiEntry_type arpFiveqi[MAX_SVC_GRP_CONFIG_ARP_NUM];
} arpFiveqiRule_type;

typedef struct svcGrpCfg_s
{
    enumUsage_type usage;
    uint8_t svcGrpId;  // 1...MAX_SVC_GRP_CONFIG_ID(32)
    uint8_t plmnIndex; // 0...7
    uint8_t priority;  // 0...7
    uint8_t ueType;    // 0:Normal, 1:RedCap, 2:All (25A FR11)
    uint8_t ruleOption;
    union
    {
        sliceFiveqiRule_type sliceFiveqiRule;
        sliceRule_type sliceRule;
        qos5qiRule_type qos5qiRule;
        arpRule_type arpRule;
        arpFiveqiRule_type arpFiveqiRule;
    } u;
} svcGrpCfg_type; // 23B FGR-MC1019

typedef struct
{
    uint32_t sstSd;
    uint8_t qos5qiMap[MAX_5QI_VALUE];
    uint8_t arpMap[MAX_ARP_LEVEL];
    uint8_t arpQos5qiMap[MAX_5QI_VALUE][MAX_ARP_LEVEL];

} serviceGroupMappingInfo_type;

typedef struct
{
    uint8_t priority[MAX_SVC_GRP_DB_NUM];
} serviceGroupPriorities_type;

typedef struct
{
    /*
     * @brief   t312-r16 timer values
     */
    uint8_t timerT312 : 7;
    uint8_t useT312   : 1;
} timerT312_type;

typedef struct operatorFreqForRedir_s
{
    uint8_t usage       : 1;
    uint32_t ssbFreq;
} operatorFreqForRedir_type;

/**
 * @brief Global gNB Id information
 */
typedef struct {
    plmnId_type plmn;
    gnbId_type gnbId;
} vccbGlobalGnbId_type;

// NR_CONN_MC_23B - manages overloaded target gNB list while HO
typedef struct
{
    vccbGlobalGnbId_type tgtGnbId;
    time_t endTime;  // HO restriction time to the overloaded tgt gNB
} overloadedHoTgtGnb_type;

#define MAX_OVERLOADED_TGT_GNB    (uint16_t)(64 + 1)
typedef struct
{
    uint16_t start, end;
    overloadedHoTgtGnb_type tgtGnbInfo[MAX_OVERLOADED_TGT_GNB];
} overloadedHoTgtGnbList_type;

//FGR-CC5200:FR483
typedef struct
{
    uint8_t usage;  // enumUsage_type
#define MAX_CAC_BACKOFF_TIME_VAL_SEC 7200
    uint16_t backoff_timer_val;  // 1..7200 sec, default 10 sec
} CacBackOff_type;

typedef struct
{
    // nr-dc related parameters
    uint8_t pscellSelectionMethod;
    uint8_t allowOtherVendorSn;
    uint8_t allowOtherVendorMn;
    uint8_t remove_meas_add_reject;                    // FGR-CC5200:FR482
    uint8_t check_strict_sd;                           // FGR-CC5200:FR90
    uint8_t ulPrimaryPathDataStallPreventionFlag;  // FGR-CC5202:FR310
    uint16_t randomAccessTimer;
    uint8_t supportPdcchBlindDetection;  // FGR-CC5200:FR900
    CacBackOff_type cacBackOff;              // FGR-CC5200:FR483
    uint8_t forcedAddMeasCfg;                // FGR-CC5200 FR147
    uint8_t checkNonGbrResourceOfferedIe;    // FGR-CC5200 FR103
    uint8_t supportPartialSuccess;           // SVR25B FGR-CC5200 FR1050
    uint8_t allowedBcFilterMnBc;             // SVR25A Patch FGR-RC0100
    uint8_t mnBcReselection;                 // SVR26A FGR-CC5208
    uint8_t measureOrderingEnable;
    uint8_t capacityOptionForMeasureOrdering;

    struct nrdc2nrcaLB_s
    {  // FGR-CC5200:FR1010
        uint8_t usage;
        uint16_t capacityThreshold;
        uint16_t bwThreshold;
    } nrdc2nrcaLB;
} NrdcGnbConfig_type;

typedef struct
{
    uint32_t setupUecontextReleaseServicetype           : 1; /* On/Off */  // SVR26A FGR-CC3401 FR190
    uint32_t setupUecontextReleaseDuidServicetype : 1;               /* On/Off */
    uint32_t setupActiveUecontextReleaseServicetype     : 1; /* On/Off */  // SVR26A FGR-CC3401 FR170
    uint32_t setupDrbReleaseServicetype                 : 1; /* On/Off */  // SVR26A FGR-CC3401 FR180
    uint32_t setupDrbReleaseDuidServicetype       : 1;               /* On/Off */
    uint32_t activityInfoServicetype                    : 1; /* On/Off */  // SVR26A FGR-CC3401 FR200
    uint32_t setupActiveDrbReleaseServicetype     : 1; /* On/Off */  // SVR25B FGR-CC3401 FR160
    uint32_t hoEutranFreqOutServicetype           : 1;               /* On/Off */
    uint32_t nrdcCtxRelServiceTypeOnOff           : 1;               /* On/Off */
    uint32_t nrdcUlPathChangeServiceTypeOnOff     : 1;               /* On/Off */
    uint32_t handoverInterFreqOutServicetypeOnoff : 1;               /* On/Off */
    uint32_t handoverIntraFreqOutServicetypeOnoff : 1;               /* On/Off */
    uint32_t handoverOutServicetypeOnoff          : 1; /* On/Off */  // SVR25B FGR-MC1009 FR531
    uint32_t handoverInServicetypeOnoff           : 1; /* On/Off */  // SVR25B FGR-MC1009 FR541
    uint32_t redirEutranOutServiceTypeOnOff       : 1; /* On/Off */  // SVR25B FGR-MC3001 FR231
    uint32_t redirNrOutServiceTypeOnOff           : 1; /* On/Off */  // SVR25B FGR-MC3000 FR311
    uint32_t hoEutranOutServiceType               : 1; /* On/Off */  // SVR25B FGR-MC3002 FR108
    uint32_t hoEutranOutFallbackServiceType       : 1; /* On/Off */  // SVR25B FGR-MC3002 FR109
    uint32_t hoEutranInServicetype                : 1; /* On/Off */  // SVR25B FGR-MC3002 FR133
    uint32_t rrcReestablishServiceTypeOnOff       : 1; /* On/Off */  // SVR26A FGR-CC0102 FR460
    uint32_t qosFlowSetupServicetypeOnoff         : 1; /* On/Off */  // SVR26B FGR-CC3101 FR2010
    uint32_t qosFlowModifyServicetypeOnoff        : 1; /* On/Off */  // SVR26B FGR-CC3101 FR2011
    uint32_t initialDrbSetupServicetypeOnoff      : 1; /* On/Off */  // SVR26B FGR-CC3101 FR2020
    uint32_t drbSetupServicetypeOnoff             : 1; /* On/Off */  // SVR26B FGR-CC3101 FR2021
    uint32_t handoverFreqOutTriggerQuantityOnoff  : 1; /* On/Off */  // SVR26B FGR-MC1007 FR870
    uint32_t handoverEutranFreqOutTriggerQuantityOnoff : 1; /* On/Off */  // SVR26B FGR-MC1007 FR860
} serviceTypeCounterInfo_type;

typedef struct
{
    uint8_t usage    : 1;
    uint8_t reserved : 7;
    uint8_t plmnIndex;
    uint16_t rfsp;
} PlmnRfspBasedControlList_type;

typedef struct
{
    uint8_t usage;
    plmnId_type plmn;
    uint8_t sst;
    uint32_t sd;
    uint8_t qos5qi;
    uint8_t dlPdcpDuplicationOnOff;
} pdcpDuplicationConfig_type;

typedef struct
{
    uint8_t thresholdRsrp;
    uint8_t thresholdRsrq;
} UlInterferenceCellSelectionThresholds_type;

typedef struct
{
    uint8_t pdcpDuplicationOnOff;
    pdcpDuplicationConfig_type pdcpDuplicationConfig[MAX_PDCP_DUPLICATION_CONFIG];
} pdcpDuplication_type;

typedef struct Fr2UplinkGapControl_s
{
    bool controlSwitch;
} Fr2UplinkGapControl_type;

typedef struct
{
    uint8_t usage;      // TRUE/FALSE indicating whether spid is filled.
    uint8_t qciKey;     // QCI key of qci-and-spid-based-statistic-support-entries.
    uint16_t spidKey;   // SPID key of qci-and-spid-based-statistic-support-entries.
} qciAndSpidStatSup_type;

typedef struct vnbConfig_s
{
    /* GNB Config */
    uint8_t sysType;   // eSysType
    uint8_t cellType;  // VrrmCell_type
    char userLabel[MAX_USER_LABEL_LENGTH + 1];
    char gnbName[MAX_GNB_NAME_LENGTH + 1];

    scgFailureHandlingInfo_type scgFailureHandlingInfo;          // NEDC_SCG_FAILURE_20C - NEDC case inside as well
    scgFailureHandlingInfoNrDc_type scgFailureHandlingInfoNrDc;  // NRDC_SCG_FAILURE
    spidInfo_type spidInfoPerPlmn[MAX_PLMN_INDEX];               // indexed by plmn index
    uint8_t spidBasedServingCellSelectionEnable;
    uint8_t pscellSelectionMethod;

    NrdcGnbConfig_type nrdc;

    uint8_t nrAmbrOnOff;  // default value : FLAG_ON
    uint8_t nrSliceMbrOnOff;  // default value : VCCB_FLAG_OFF
    uint8_t amfRelocationOption;
    uint8_t suspendResumeFlag;  // suspend and resume operation in case of SCG failure

    uint8_t thresholdRSRPForSCGFailure;  // 0 ~ 127
    uint8_t mrBasedSuspendResumeEnable;
    uint8_t inactivityTimerInterworkingInSuspend;
    uint8_t neighborPriorityForScgResync; // ENDC SCG Failure, 26A FR107
    uint8_t notUseSRB3ForIntraDuHo;
    measGap_type measGap;
    periodicA4Meas_type periodicA4Measurement;
    longPeriodicMeas_type longPeriodicMeas;
    uint8_t ignoreSrb3SupportUeCapa;            // 0:Operate according to srb3_support, 1:Not support srb3
    uint8_t maxIntegrityFailCount;              // trigger release if the number of integrity failures is same this.
    uint8_t maxMgapReTriggerCountENDC;          // 0 ~ 3
    uint8_t maxMgapReTriggerCountNRDC;          // 0 ~ 3
    uint8_t packetInspectionBasedUlPathSwitch;  // default value : FLAG_OFF
    uint8_t qciBasedUlSplitThSwitch;            // default value : FLAG_OFF
    uint16_t arpBasedUlPathSwitchTimerValue;    // 0~3600 seconds. Set by: itscp_vccb set ArpBasedUlPathSwitchTimerValue [gnbNum:0~7] [seconds:0~3600]

    /* Data Forwarding */
    uint8_t uplinkForward;
    uint8_t downlinkForward;
    uint8_t sourceUlForward;
    uint8_t sourceDlForward;
    uint8_t interSysDirectDataFwd;
    uint8_t interSysDirectDataFwdTgt;
    uint8_t intraNrSrcIndirectFwdPreference;

    uint8_t fixPscellSelection;
    uint8_t lteUlSplitThresholdFlag;
    uint8_t lteUlSplitThreshold;
    uint8_t fullConfigSelection;

    uint8_t ulConfiguration;  // X2_UL_UE_Configuration_type
    uint8_t forcePrimaryPathFlag;
    uint8_t forceUlSplitThresholdFlag;
    uint8_t forcePrimaryPath;
    uint8_t forceUlSplitThreshold;

    uint8_t useCmdTypeBeforeFix;  // Will be removed
    uint8_t epsFallbackSwitch;
    uint8_t epsFallbackVoNrFailSwitch_Redirection;
    uint8_t epsFallbackVoNrFailSwitch_HO;           // SVR25B FGR-SV0201 FR290
    uint8_t fallbackToRrcEstab;
    uint8_t fallbackRedirectionMethod;           // fallback-redirection-method YANG
    uint8_t emergencyFallbackRedirectionMethod;  // emergency-fallback-redirection-method
    uint8_t emergencyFallbackVoNrFailSwitch;     // emergency-vonr-fallback-switch
    uint8_t voNrOrEpsfbOption;                   // enumVoNrOrEpsFbOption_type
    uint8_t supportServiceGroupBasedIntraRatBlindRedirection        : 1;
    uint8_t supportServiceGroupBasedInterRatBlindRedirection        : 1;
    uint8_t supportOperatorFreqBasedIntraRatBlindRedirection        : 1;
    operatorFreqForRedir_type operatorFreqListForRedir[MAX_OPERATOR_REDIR_FREQ_INDEX];
    uint8_t onlyNrScgStopResume;
    uint8_t snTermMcgBearerSupport;
    uint8_t snTermMcgBearerSnInitSupport;

    uint8_t spidThresholdEnabled;
    uint8_t targetCellBandwidthMode;  // enumSaHandoverTargetCellBandwidthMode
    uint8_t blindRedirectionMode;     // enumSaHandoverBlindRedirectionMode
    uint8_t alignMeasIdWithMeasObjectId;
    uint8_t ulRrcSegmentAllowed;
    uint8_t ulSegmentWithRrcComplete;
    uint8_t ueCapaEnquiry3Step;
    uint8_t forceMgapRelSnAdd;
    uint8_t nrdcSrb3Switch;
    uint8_t srb3Support;
    uint8_t cacRejectCause;
    uint8_t noneNrcgiCellsFoundDuringAddReq;
    uint8_t nrDlTdoaSmtc1Config;
    uint8_t cellBarredRejectCause;
    uint8_t endcAddWithSwitchingOffCells;

    uint8_t qosMonitoringSupport;
    uint8_t trafficBasedHoSupport;
    uint8_t trafficBasedHoMeasRelTimerUsage;

    uint8_t nasReflectiveQosUsage;
    uint8_t hoVoicePriority; // FGR-MC1009 FR220 PDU session request while Inter-gNB HO;
    uint8_t guamiTypeAmfSelectionOnOff; // [FGR-CC6001] AMF Selection and Load Balancing FR100
    uint8_t allowCallProcessingDuringRlfDetected; // 26A FGR-CC3101 (allow-call-processing-during-rlf-detected)

    qosDrbMappingConf_type qosDrbMappingConf;

    featureEnabledAndTimer_type endcFr2MeasureableSettings;
    featureEnabledAndTimer_type endcForcedRestriction;
    featureEnabledAndTimer_type forcedRestriction;
    nedc_BlackCellConfig_type blackCellInfo;  // NEDC_SCG_FAILURE_20C

    gnbMobilityConfig_type gnbMobilityConfig;

    SvcGrpBasedCfg_type svcGrpBasedCfg[MAX_SVC_GRP_DB_NUM]; // 23B FGR-MC1019
    svcGrpCfg_type svcGrpCfg[MAX_SVC_GRP_DB_NUM];   // 23B FGR-MC1019

    svcCfgSa_type svcCfgSaEntries[MAX_SVC_SA_ENTRIES];         // 32
    svcCfgEndc_type svcCfgEndcEntries[MAX_SVC_ENDC_ENTRIES];   // 16

    timerT312_type T312;       // FGR-MC1018 Fast_RLF_Recovery

    uint32_t supportedSPIDforStatistic[MAX_SPID_ARR_SIZE];  // list supported SPIDs for UE_NUM statistic configurable by
                                                            // spid-based-statistic-support-entries yang param list

    // FGR-CC5000 Basic Operation for EN-DC
    uint32_t statEndcAddDetailedCpFail[StatEndcAddCpFail_MAX_STAT]; // FR:TBD: Internal stats for detailed EndcAddCpFail cases
    uint32_t statEndcAddDetailedSpCellSelFail[StatEndcSpCellSelFail_MAX_STAT]; // FR:RBD Internal stats for detailed SPCellSelFail cases
    time_t resetTimeStatEndcAddDetailedCpFail;
    time_t resetTimeStatEndcAddSpCellSelFail;

    uint8_t f1RrcDeliveryReportOnOff;  // Dl Nas Ack
    uint8_t xnStatusTransferEnhancementOnOff;
    uint8_t supportRreDuringUeCapaEnquiry;
    uint8_t discardCapaFromAmfOnOff;  // Discard UE Capa from AMF

    uint8_t ulPrimaryPathDataStallPreventionFlag;  // ON/OFF
    uint16_t randomAccessTimerValue;
    uint8_t nrdcToEndcHoSupport; // IRAT_HO_CTRL_CONSID_24A

    featureEnabledAndTimer_type restrictHoToOverloadedGnb; // NR_CONN_MC_23B

    uint8_t scgUeHistoryHandlingOnOff; // FGR-CC5201, 24B, FR480.CACP.SR1.HD1.DD1

    qciAndSpidStatSup_type qciAndSpidStatSup[MAX_QCI_AND_SPID_SIZE];

    uint8_t qciSpidStatSupBitMap[MAX_QCI_VALUE][MAX_SPID_BITMAP_BYTES];

    uint8_t debugUlPathForceRandValueFlag;
    uint8_t forceUlPathRandValue;
    uint8_t recommendedCellNumForPaging;
    uint8_t allowVonrWithRfspPerGnb;
    PlmnRfspBasedControlList_type plmnRfspBasedVonrControlList[MAX_PLMN_RFSP_BASED_CONTROL_LIST];
    serviceTypeCounterInfo_type serviceTypeCounterConfig;
    pdcpDuplication_type pdcpDuplication; //FGR-BC0310 PDCP Duplication
    UlInterferenceCellSelectionThresholds_type ulInterferenceCellSelectionThresholds;
    Fr2UplinkGapControl_type fr2UplinkGapControl;
} gnbConfig_type;

typedef struct
{
    uint16_t year;
    uint8_t mon;
    uint8_t mday;
    uint8_t hour;
    uint8_t min;
    uint8_t sec;
    uint16_t millisec;
} vccbTimeInfo_type;

typedef struct
{
    uint8_t upgradeStatus;  // upgradeStatus_type type
} vccbPldCpcState_type;     // From PLDCPCUsageState

typedef struct
{
    uint8_t vmCallCacUsage;
    uint16_t maxCallCountPerVm;
    ConfStatus shmStatus;  // shmStatus_type
} vmCacInfo_type;

typedef struct vmDBInfo_s
{
    uint16_t unitType;  // eUnitType
    uint16_t unitId;
    uint16_t assignedVmCallCount;
    uint16_t isMultiCPC;
    vmCacInfo_type cac;
} vmDBInfo_type;

typedef struct
{
    enumIntegrityAlgo_type integrityEaPrior;
    enumCipherAlgo_type cipherEaPrior;
    uint16_t isNia0SupForNonEmergency;
    uint16_t isUpDrbIntegrityProtectionSupported;
    uint16_t isNia0SupportedInGnb;
    uint16_t isEventNia0Supported;
    uint16_t reserved;

} VccbSecurityDBInfo_type;

typedef struct
{
    uint32_t priority;
    enumPrioritizedBitRate_type PBR;
    enumBucketSizeDuration_type bucketSizeDuration;
    uint16_t groudId;
    uint16_t nonGBRPFWeight;
} logicalChDBInfo_type;

typedef struct
{
    struct{
        uint32_t ulRohcEnabled        : 1;
        uint32_t symmetricRohcEnabled : 1;
        uint32_t isDrbContinueRohcPossible : 1;
        uint32_t reserved             : 29;
    }rohc_m;

    uint8_t ulRohcEnabled;    /**< ulOnlyRoHC enabled >     */
    uint16_t ulRohcMaxSession; /**< ulOnlyRoHC MaxSessions > */
    uint8_t symmetricRohcEnabled;
    uint16_t symmetricRohcMaxSession;
    uint8_t useProfile000;              /**< useProfile000 usage >    */
    uint8_t useProfile001;              /**< useProfile001 usage >    */
    uint8_t useProfile002;              /**< useProfile002 usage >    */
    uint8_t useProfile003;              /**< useProfile003 usage >    */
    uint8_t useProfile004;              /**< useProfile004 usage >    */
    uint8_t useProfile006;              /**< useProfile006 usage >    */
    uint8_t useProfile101;              /**< useProfile101 usage >    */
    uint8_t useProfile102;              /**< useProfile102 usage >    */
    uint8_t useProfile103;              /**< useProfile103 usage >    */
    uint8_t useProfile104;              /**< useProfile104 usage >    */
    uint8_t drbContinueRohcEnabled;     /**< PDCP Drb ContinueRohcEnabled usage >    */
    uint32_t isDrbContinueRohcPossible; /**< PDCP Drb ContinueRohcEnabled possible >    */
} pdcpRohcConf_type;

typedef struct
{
    struct{
        uint8_t ehcSetupPossible          : 1;
        uint8_t isEhcCtxtContinuePossible : 1;
        uint8_t isEhcDrbCtxtContinue_dl   : 1;
        uint8_t isEhcDrbCtxtContinue_ul   : 1;
        uint8_t reserved                  : 4;
    }ehc_m;

    uint8_t ehcEnabled;
    uint16_t ehcMaxSession_ul;
    uint16_t ehcMaxSession_dl;
    uint8_t ehcDrbContextContinue_ul;
    uint8_t ehcDrbContextContinue_dl;
    uint8_t ehc_CIDlength;
} pdcpEhcConf_type;

typedef struct
{
    union
    {
        struct
        {
            uint32_t prev                 : 2;  // NR_PDCP_PREV_FLAG_FROM_OTHER_GNB, NR_PDCP_PREV_FLAG_FROM_EXIST_DRB
            uint32_t pdcpSnSizeDl         : 1;
            uint32_t pdcpSnSizeUl         : 1;
            uint32_t discardTimerUl       : 1;
            uint32_t discardTimerDl       : 1;
            uint32_t ulDataSplitThreshold : 1;  // 22A B6G+A6G
            uint32_t tReorderingUl        : 1;  // 22A B6G+A6G
            uint32_t tReorderingDl        : 1;  // 22A B6G+A6G
            uint32_t outOfOrderDelivery   : 1;
            uint32_t reestablishPdcp    : 1;

            // E1 Only
            uint32_t pdcpVersionChangeInd : 1;
            // RRC Only
            uint32_t statusReportRequired : 1;
            // reserve
            uint32_t reserved                  : 19;
        };
        uint32_t value;
    } present;
} pdcpPrevFlagInfo_type;

typedef struct
{
    struct
    {
        uint32_t pdcpSnSizeUl          : 1;
        uint32_t pdcpSnSizeDl          : 1;
        uint32_t discardTimer          : 1;
        uint32_t headerCompression     : 1;
        uint32_t integrityProtection   : 1;
        uint32_t statusReportRequired  : 1;
        uint32_t outOfOrderDelivery    : 1;
        uint32_t rlcMode               : 1;
        uint32_t tReorderingTimer      : 1;
        uint32_t pdcpDuplication       : 1;
        uint32_t pdcpReestablishment   : 1;
        uint32_t pdcpDataRecovery      : 1;
        uint32_t duplicationActivation : 1;
        uint32_t ulDataSplitThreshold  : 1;
        uint32_t ethernet_headerCompression : 1;
    } m;  // present flag

    enumPdcpSnSize_type pdcpSnSizeDl;           /**< PDCP SN size */
    enumPdcpSnSize_type pdcpSnSizeUl;           /**< PDCP SN size */
    enumPdcpDiscardTimer_type discardTimerUl;   /**< PDCP discard timer for UL */
    enumPdcpDiscardTimerDl_type discardTimerDl; /**< PDCP discard timer for DL */
    uint8_t rlcMode;
    uint8_t ulDataSplitThreshold;        // B6G+A6G
    uint8_t ulDataSplitThresholdFr1Fr2;  // For NR-DC only
    uint8_t tReorderingUl;               // B6G+A6G
    uint8_t tReorderingDl;               // B6G+A6G
    uint8_t tReorderingUlSplitFr1Fr2;
    uint8_t tReorderingDlSplitFr1Fr2;
    uint8_t outOfOrderDelivery;
    uint8_t reestablishPdcp;              /**< PDCP Re-establishment usage >    */
    uint8_t statusReportRequired;         /**< PDCP status report required flag */
    uint32_t pdcpVersionChangeInd;        /**< PDCP version change indication from LTE to NR */
    pdcpRohcConf_type headerCompression;  // FGR-BC0311/FGR-BC0312 : ULRoHC/SymmetricRoHC
    pdcpEhcConf_type ethernetCompression; // FGR-BC0314 : Ethernet Header Compression
    uint8_t isPdcpConfigured;
} pdcpConfigInfo_type;

typedef struct
{
    pdcpConfigInfo_type pdcpDBInfo;
    logicalChDBInfo_type logicalChDBInfo;
} rbDBInfo_type;

typedef struct
{
    ConfStatus shmSrbStatus;  // shmStatus_type
    qCIValue_type qciValue;   // Caution here priority reference PLDSrbLogicalCHInfoFunc
    rbDBInfo_type srbDB;
} srbDBInfo_type;

typedef struct
{
    uint32_t assignedCount;
    uint32_t eNBId;
} enDcStatCountPerEnb_type;

typedef struct cellConfig_s
{
    /* Cell Config */
    uint8_t cellShutDownFlag;
    uint8_t drbAllocMode;
    uint8_t measObjUpdateFlag;
    uint8_t measConfigUpdateFlag;

    /* Cell Call Count */
    uint32_t assignedCellCallCount;  // do not move - HAS
    uint32_t assignedNonDssUeCount;
    uint32_t assignedLoggedMdtCapableUeCount;
    /* DRB Count */
    uint32_t assignedDrbCount[MAX_QCI_VALUE];  // do not move - HAS

    uint32_t assignedULOnlyRoHCCellCallCount;
    uint32_t assignedULOnlyRoHCErabCount[MAX_QCI_VALUE];

    /* DRB Count for 5QI */
    uint32_t assignedDrbCount5QiRrcConn[MAX_5QI_VALUE];
    uint32_t assignedDrbCount5QiRrcInact[MAX_5QI_VALUE];

    uint32_t assignedCellRrcConnectionCount;
    uint32_t assignedCellRrcInactiveCount;
    uint32_t assignedULOnlyRoHCCellCallCountSA;
    uint32_t assignedULOnlyRoHCDrbCountRrcConn[MAX_5QI_VALUE];
    uint32_t assignedULOnlyRoHCDrbCountRrcInact[MAX_5QI_VALUE];
    uint32_t assignedSymmRoHCCellCallCount;
    uint32_t assignedSymmRoHCDrbCountRrcConn[MAX_5QI_VALUE];
    uint32_t assignedSymmRoHCDrbCountRrcInact[MAX_5QI_VALUE];
    uint32_t vonrEmerCellRrcConnectionCount;
    uint32_t vonrEmerCellRrcInactiveCount; /* Not Support in 23A */
    uint32_t assignedCellPC1RrcConnectionCount;
    uint32_t assignedCellPC15RrcConnectionCount;
    uint32_t assignedCellPC2RrcConnectionCount;

    /* For Multi-PLMN */
    /* DRB Count for 5QI for Multi PLMN : MOCN */
    uint32_t assignedDrbCount5QiWithPlmnRrcConn[MAX_5QI_VALUE][MAX_PLMN_INDEX];
    uint32_t assignedDrbCount5QiWithPlmnRrcInact[MAX_5QI_VALUE][MAX_PLMN_INDEX];

    uint32_t assignedDrbCountWithPlmnSliceRrcConn[MAX_SLICE_STAT_YANG_INDEX_BUFFER];
    uint32_t assignedDrbCountWithPlmnSliceRrcInact[MAX_SLICE_STAT_YANG_INDEX_BUFFER];

    /* Cell Call Count for Multi PLMN */
    uint32_t assignedCellRrcConnectionCountWithPlmn[MAX_PLMN_INDEX];
    uint32_t assignedCellRrcInactiveCountWithPlmn[MAX_PLMN_INDEX];
    uint32_t assignedCellRrcConnectionCountWithRfsp[MAX_RFSP_CONN_STAT_BUFFER][MAX_PLMN_INDEX];
    uint32_t assignedCellRrcInactiveCountWithRfsp[MAX_RFSP_CONN_STAT_BUFFER][MAX_PLMN_INDEX];
    uint32_t assignedNonDssUeCountWithPlmn[MAX_PLMN_INDEX];
    uint32_t assignedNonDssUeCountWithRfsp[MAX_RFSP_CONN_STAT_BUFFER][MAX_PLMN_INDEX];

    /*For EN-DC calls */
    uint32_t assignedEnDcDrbCountWithPlmn[MAX_QCI_VALUE][MAX_PLMN_INDEX];
    uint32_t assignedCellEnDcCallCount[MAX_PLMN_INDEX];
    uint32_t assignedCellEnDcCallCountPerSPID[MAX_PLMN_INDEX][MAX_SPID_VALUE + 1];  // including 0 for calls without
                                                                                    // SPID
    uint32_t assignedEnDcCellCallCountForStat;
    uint32_t assignedSwitchOffOngoingEnDcCellCallCount; // FGR-CC5000 FR3530
    uint32_t assignedNonDssEnDcUeCount;
    uint32_t assignedNonDssEnDcUeCountWithPlmn[MAX_PLMN_INDEX];
    uint32_t assignedNonDssEnDcUeCountPerSPID[MAX_PLMN_INDEX]
                                             [MAX_SPID_VALUE + 1];  // including 0 for calls without SPID;
    enDcStatCountPerEnb_type enDcCellCallCountPerEnbForStat[MAX_ENB_PER_GNB_CU_CP];
    enDcStatCountPerEnb_type enDcCellNonDssUeCountPerEnbForStat[MAX_ENB_PER_GNB_CU_CP];

    /*For EN-DC DRB Count */
    uint32_t assignedEnDcDrbCount[MAX_QCI_VALUE];

    /*For EN-DC SN init bearer type change */
    uint32_t statEndcSNinitErabChgCount[MAX_QCI_VALUE][StatEndcErabMod_MAX_STAT];

    /* Cell CAC */
    // uint32_t          maxCellCallCount;
    // FGR-CC5200:FR760 FR780
    uint32_t assignedCellNrdcSnConnInfoMnCount[MAX_RFSP_CONN_STAT_BUFFER][MAX_PLMN_INDEX];
    uint32_t assignedCellNrdcSnConnInfoSnCount[MAX_RFSP_CONN_STAT_BUFFER][MAX_PLMN_INDEX];
    // FGR-CC5200:FR740 FR750
    uint32_t assignedNrdcSnTermDrbConnCount[MAX_5QI_VALUE][MAX_PLMN_INDEX];

    /* RedCap UE */
    uint32_t assignedRedCapCellRrcConnectionCountWithPlmn[MAX_PLMN_INDEX];
    uint32_t assignedRedCapCellRrcInactiveCountWithPlmn[MAX_PLMN_INDEX];
    uint32_t assignedRedCapNonDssUeCountWithPlmn[MAX_PLMN_INDEX];
    uint32_t assignedRedCapDrbCount5QiWithPlmnRrcConn[MAX_5QI_VALUE][MAX_PLMN_INDEX];
    uint32_t assignedRedCapDrbCount5QiWithPlmnRrcInact[MAX_5QI_VALUE][MAX_PLMN_INDEX];

} cellConfig_type;

typedef struct commonPhyInfo_s
{
    struct commonPhyCellSelect_s
    {
        int8_t qRxlevmin;              // = -70~22
        uint8_t qRxlevminoffsetUsage;  // enumUsage_type
        uint8_t qRxlevminoffset;       // = 1~8
        uint8_t pMaxUsage;             // enumUsage_type
        int8_t pMax;                   // = -30~33
        uint8_t rel9SelInfoUsage;      // enumUsage_type
        int8_t qQualMin;               // =-34~-3
        uint8_t qQualMinOffsetUsage;   // enumUsage_type
        uint8_t qQualMinOffset;        // =1~8
        uint8_t qQualMinWbUsage;       // enumUsage_type
        int8_t qQualMinWb;             // =-34~-3
    } cellSelectionInfo;

    struct commonPhyCellScheduling_s
    {
        uint16_t xSibPeriod;
        uint16_t reserved;
        uint8_t defaultConfigId;
        uint8_t accessRelatedConfigUsage;
    } sibSchedulingInfo;

    struct commonPhyCellUeTimerConst_s
    {
        uint8_t t300;     // enumT300_type
        uint8_t t301;     // enumT301_type
        uint8_t t302;     // enumT302_type
        uint8_t t304;     // enumT304_type
        uint8_t ccoT304;  // enumCCOT304_type
        uint8_t t310;     // enumT310_type
        uint8_t t311;     // enumT311_type
        uint8_t t312;     // enumT311_type
        uint8_t t320;     // enumT320_type
        uint8_t t325;     // enumT325_type
        uint8_t n310;     // enumN310_type
        uint8_t n311;     // enumN311_type
    } ueTimerConst;

    struct commonPhyTimeAlignCommon_s
    {
        uint16_t timeAlignmentTimerCommon;
        uint16_t taSendExpire;
        uint16_t nTacBlock;
        short targetTa;
        uint16_t maxTa;
        uint16_t flagToIirFiltering;
        uint16_t windowSizeToIir;
        uint16_t thresholdPreambleTa;
    } TimeAlignmentConf;

    struct
    {
        uint16_t beamConfigurationForRu0;
        uint16_t beamConfigurationForRu1;
        uint16_t beamConfigurationForRu2;
        uint16_t beamConfigurationForRu3;
        uint16_t thresholdBrsrpDlDiff;
        uint8_t brsrpBeamChangeMarginBsi;
        uint8_t brsrpBeamChangeMarginBri;
        uint16_t noOfBrsrpInBri;
        uint16_t noOfBrsrpInBsi;
        uint16_t configurationBrrs;
        uint16_t noOfMaxReTxforChangeBsi;
        uint16_t filterWindowBeam;
        uint16_t initialBrrsTriggerEnable;
        uint16_t resetBsiInformation;
        uint16_t thresholdRsrpUlDiff;
        uint16_t servingBeamBrrsEnable;
        uint16_t servingBeamChangeMethod;
        uint16_t thresholdSinrUlDiff;
        uint16_t timerBrrsTriggerProhibit;
        uint16_t timerBrrsTriggerProhibit2;
        uint16_t timerServingChangeProhibit;
        uint16_t maxNoOfBeamsPerRu;
        uint16_t sfbcTxModeForBrs;
        uint16_t transmitPeriodBrs;
        uint16_t processIdBrrs;
        uint16_t allowBarRequest;
        uint8_t timerProhibitBar;
        uint8_t beamTriggeringRsrpOffset;
    } AnalogBeamConf;

    struct
    {
        uint16_t preambleformat;
        uint16_t prachConfiguration;
        uint16_t rootForRa;
        uint16_t preambleInitialReceivedTargetPower;
        uint16_t powerRampingStep;
        uint16_t noOfRaPreamble;
        uint16_t raResponseWindowSize;
        uint16_t preambleTransMax;
        uint16_t macContentionResolutionTimer;
        uint16_t backoffIndicatorSetup;
        uint16_t backoffIndex;
        uint16_t maxWaitPreamble;
        uint16_t maxReleaseRnti;
        uint16_t nMcsMsg3;
        uint16_t nNumRbMsg3;
        uint16_t rsrpOnOff;
        uint16_t nBsiRar;
        uint16_t dualPcrsRar;
    } RandomAccessConf;

    struct
    {
        uint8_t maxHarqTxDl;
        uint8_t maxHarqTxMsg4;
        uint8_t maxHarqTxUl;
        uint8_t maxHarqTxMsg3;
        uint8_t dlHarqBitmapSize;
    } HarqConf;

    struct
    {
        uint16_t nSymbolConfiguration;
        uint16_t reserved;
    } DlControlRrcConf;

    struct
    {
        uint16_t csiRsResourceConfig[4];
        uint16_t srsBandwidth;
        uint16_t srsNumCs;
        uint16_t srsPeriod;
        short csiRsPc[4];
        uint8_t modeDmrs;
        uint8_t srsGroupHoppingEnabled;
        uint8_t srsSequenceHoppingEnabled;
        uint8_t srsSequenceShiftPattern;
    } RefSigConf;

    struct
    {
        uint16_t alpha;
        uint16_t accumulationEnabled;
        uint16_t chi;
        uint16_t deltaMcsEnable;
        int deltaPreambleMsg3;
        uint16_t dlPathlossChange;
        uint16_t filterWindowPucch;
        uint16_t filterWindowPusch;
        uint16_t maxPucchSinrTarget;
        uint16_t minUlSinrTarget;
        uint16_t maxUlSinrTargetQpsk;
        uint16_t maxUlSinrTarget16Qam;
        uint16_t maxUlSinrTarget64Qam;
        uint16_t nominalMaxTxPower;
        uint16_t periodicPhrTimer;
        int pONominalPusch;
        int pONominalPucch;
        uint16_t powerSrsOffsetIndex;
        uint16_t prohibitPhrTimer;
        uint16_t puschPowerCtrlMargin;
        uint16_t rangePucchPowerControl;
        uint16_t deltaTxd;
        uint16_t filterCoefficient;
        uint16_t tpcCommandPrach;
        uint16_t tpcPrachAdaptation;
    } UlPowerControlConf;

    struct
    {
        uint8_t betaOffsetCQIIndex;
        uint8_t betaOffsetRIIndex;
        uint8_t betaOffsetBSIIndex;
        uint8_t betaOffsetBRIIndex;
        uint8_t betaOffsetCQIIndexML;
        uint8_t betaOffsetRIIndexML;
        uint8_t betaOffsetBSIIndexML;
        uint8_t betaOffsetBRIIndexML;
        uint8_t betaOffsetBSIrarIndexML;
    } UlUciConf;

} commonPhyInfo_type;

typedef struct
{
    uint16_t cellNum;
    uint8_t status;
    uint8_t reserved;
} servNbrInfo_type;

/**
 * @brief QoS CAC information
 */
typedef struct
{
    uint8_t qosCacOption;                   /**< QoS CAC option */
    uint8_t qosCacPolicy;                   /**< QoS CAC policy */
    uint32_t sumDlGBR[MAX_QCI_VALUE];       /**< sum of DL GBR for each QCI */
    uint32_t sumUlGBR[MAX_QCI_VALUE];       /**< sum of UL GBR for each QCI */
    uint32_t totERABcnt[MAX_QCI_VALUE];     /**< total XRAB count for each QCI */
    uint32_t arpPriority[MAX_QCI_PRIORITY]; /**< ARP priority for each QCI */
} qosCacInfo_type;

/**
 * @brief cell PLMN configuration
 */
typedef struct
{
    uint16_t plmnActiveCallCnt;                          /**< active call count in a PLMN */
    uint16_t plmnAssignCellCallCnt;                      /**< assigned cell call count in a PLMN */
    uint16_t plmnAssignCallForCommonShare;               /**< assigned call count shared commonly in a PLMN */
    uint16_t plmnAssignCellCallCntOther[MAX_PLMN_INDEX]; /**< assigned cell call counter to other PLMN */
    uint16_t plmnAssignCommonCallCnt;                    /**< assigned common call count in a PLMN */

    uint16_t plmnAssignDrbCnt;                      /**< assigned DRB count in a PLMN */
    uint16_t plmnAssignDrbForCommonShare;           /**< assigned DRB count shared commonly in a PLMN */
    uint16_t plmnAssignDrbCntOther[MAX_PLMN_INDEX]; /**< assigned DRB count to other PLMN */
    uint16_t plmnAssignCommonDrbCnt;                /**< assigned common DRB count in a PLMN */
    qosCacInfo_type plmnQosCacInfo;                 /**< QoS CAC information */

    uint32_t plmnTotalAssignDrbCnt; /**< myplmn+otherplmn+common */

    /* PLMN */
    uint16_t plmnCellCacUsage;        /**< CELL CAC usage in a PLMN */
    uint32_t plmnMaxCellCallCnt;      /**< MAX cell call count in a PLMN */
    float plmnCallCacThreshForNormal; /**< call CAC normal threshold in a PLMN */
    float plmnCallCacThreshForEmerHo; /**< call CAC emergency/handover threshold in a PLMN */
    uint16_t plmnDrbCacUsage;         /**< DRB CAC usage in a PLMN */
    uint32_t plmnMaxDrbCnt;           /**< MAX DRB count in a PLMN */
    float plmnDrbCacThreshForNormal;  /**< DRB CAC normal threshold in a PLMN */
    float plmnDrbCacThreshForEmerHo;  /**< DRB CAC emergency/handover threshold in a PLMN */
    uint16_t plmnQosCacOption;        /**< QoS CAC option in a PLMN */
    uint16_t plmnQosCacPolicy;        /**< QoS CAC policy in a PLMN */
    uint16_t plmnEstimationOpt;       /**< estimation option in a PLMN */
    uint16_t plmnPreemptionFlag;      /**< preemption flag in a PLMN */
    uint32_t plmnQciDrbCacUsage;      /**< QCI DRB CAC usage in a PLMN */
    uint32_t plmnPartialCacUsage;     /**< partial CAC usage in a PLMN */
} cellPlmnConfig_type;

typedef struct
{
    uint8_t numOfPLMN;
    // uint8_t numOfSnssaiPerPlmnCnt[MAX_PLMN_INDEX];
    uint32_t servedPlmn[MAX_PLMN_INDEX];
    uint32_t supportedSnssaiGrpCntPerPlmn[MAX_PLMN_INDEX];
    uint32_t supportedSnssaiGrp[MAX_PLMN_INDEX][MAX_SNSSAI_GRP_PER_PLMN_CELL];
    uint32_t supportedSnssaiGrpLength[MAX_PLMN_INDEX][MAX_SNSSAI_GRP_PER_PLMN_CELL];
    // uint32_t supportedSnssai[MAX_PLMN_INDEX][MAX_SNSSAI_PER_PLMN];
} cellPlmnInfo_type;

typedef struct
{
    uint8_t status;        // EQUIP, N_EQUIP
    uint8_t updateStatus;  // 0: Release, 1: Keep
    uint16_t reserved;
    uint32_t servedPlmn;
} cellPlmnIndexInfo_type;

#define MAX_SR_CONF_BAND 8
#define MAX_SR_CONF_CYC  12
#define MAX_SR_CONF_OCC  2

/*** measurements ***/
#define INVALID_OBJECT_ID             0xFF
#define MAX_NR_OF_OBJECT_ID           20
#define MAX_NR_OF_REPORT_CONFIG_ID    40
#define MAX_NR_OF_MEAS_ID             64
#define MAX_NR_OF_QUANTITY_CONFIG     2
#define MAX_NR_OF_CELLS_TO_MEASURE    32
#define MAX_EUTRA_OF_CELLS_TO_MEASURE 32

#define MAX_NR_OF_EUTRA_REDIRECTION 8

/* CSI-RS measurements are not used in SVR18.3
 * so defines below are set to 1 to avoid memory waste.
 * Set them to a different value when needed. */
#define MAX_NR_OF_CSI_RS_CELLS_RRM     1
#define MAX_NR_OF_CSI_RS_RESOURCES_RRM 1

#define MAX_NR_OF_OBJECT_ID_DB         21
#define INTRAFREQ_OBJECT_IDX           (MAX_NR_OF_OBJECT_ID_DB - 1)
#define START_CBRS_OBJECT_IDX          15
#define END_CBRS_OBJECT_IDX            20
#define MAX_MEAS_OBJECT_PRIORITY       31
#define MAX_NR_OF_REPORT_CONFIG_ID_DB  64
#define MAX_NR_OF_SPEC_MEAS_MO_INDEXES 8

#define MAX_NR_OF_OBJECTEUTRA_ID_DB         20
#define MAX_NR_OF_REPORT_CONFIGIR_ID_DB     64
#define MAX_NR_UE_SPECIFIC_REPORT_CONFIG_DB 32

#define MAX_NR_OF_SERVING_CELLS_EUTRA 32

#define MAX_CELL_MEAS_EUTRA 32

#define MAX_MEAS_SLOTS_LENGTH_IN_BYTES 10
#define MAX_NUM_OF_PCIS_SMTC2          64

#define REPORT_TYPE_RECEIVED_FROM_MN 100

#define ALL_MEASOBJECT_SELECTION 0xFFFFFFFF

#define MAX_NR_OF_SA_BLACKLIST_CELLS_SETS        20
#define UNKNOWN_IDX_IN_SA_BLACKLIST_CELLS_SETS   0xFF
#define MAX_NR_OF_ENDC_BLACKLIST_CELLS_SETS      10
#define UNKNOWN_IDX_IN_ENDC_BLACKLIST_CELLS_SETS 0xFF
#define MAX_NR_OF_PCI_RANGES                     8

typedef enum
{
    scg_RbConfig = 0,
    mcg_RbConfig = 1
} enumSrcRbConfig;

typedef enum
{
    smtc_periodicity_sf5 = 0,
    smtc_periodicity_sf10 = 1,
    smtc_periodicity_sf20 = 2,
    smtc_periodicity_sf40 = 3,
    smtc_periodicity_sf80 = 4,
    smtc_periodicity_sf160 = 5
} enumSmtcPeriodicity;

typedef enum
{
    smtc_duration_sf1 = 0,
    smtc_duration_sf2 = 1,
    smtc_duration_sf3 = 2,
    smtc_duration_sf4 = 3,
    smtc_duration_sf5 = 4
} enumSmtcDuration;

typedef enum
{
    qOffset_minus_24 = 0,
    qOffset_minus_22 = 1,
    qOffset_minus_20 = 2,
    qOffset_minus_18 = 3,
    qOffset_minus_16 = 4,
    qOffset_minus_14 = 5,
    qOffset_minus_12 = 6,
    qOffset_minus_10 = 7,
    qOffset_minus_8 = 8,
    qOffset_minus_6 = 9,
    qOffset_minus_5 = 10,
    qOffset_minus_4 = 11,
    qOffset_minus_3 = 12,
    qOffset_minus_2 = 13,
    qOffset_minus_1 = 14,
    qOffset_0 = 15,
    qOffset_plus_1 = 16,
    qOffset_plus_2 = 17,
    qOffset_plus_3 = 18,
    qOffset_plus_4 = 19,
    qOffset_plus_5 = 20,
    qOffset_plus_6 = 21,
    qOffset_plus_8 = 22,
    qOffset_plus_10 = 23,
    qOffset_plus_12 = 24,
    qOffset_plus_14 = 25,
    qOffset_plus_16 = 26,
    qOffset_plus_18 = 27,
    qOffset_plus_20 = 28,
    qOffset_plus_22 = 29,
    qOffset_plus_24 = 30
} enumQOffsetRange;

typedef enum
{
    subcarrierSpacing_kHz15 = 0,
    subcarrierSpacing_kHz30 = 1,
    subcarrierSpacing_kHz60 = 2,
    subcarrierSpacing_kHz120 = 3,
    subcarrierSpacing_kHz240 = 4,
    subcarrierSpacing_spare3 = 5,
    subcarrierSpacing_spare2 = 6,
    subcarrierSpacing_spare1 = 7
} enumSubcarrierSpacing;

typedef enum
{
    ssbToMeasure_shortBitmap = 0,
    ssbToMeasure_mediumBitmap = 1,
    ssbToMeasure_longBitmap = 2
} enumSSBToMeasure;

typedef enum
{
    nrOfPrbs_size24 = 0,
    nrOfPrbs_size48 = 1,
    nrOfPrbs_size96 = 2,
    nrOfPrbs_size192 = 3,
    nrOfPrbs_size264 = 4
} enumNrOfPrbs;

typedef enum
{
    density_d1 = 0,
    density_d3 = 1
} enumDensity;

typedef enum
{
    slotConfigLength_ms4 = 0,
    slotConfigLength_ms5 = 1,
    slotConfigLength_ms10 = 2,
    slotConfigLength_ms20 = 3,
    slotConfigLength_ms40 = 4
} enumSlotConfigLength;

typedef enum
{
    fdaChoice_row1 = 0,
    fdaChoice_row2 = 1
} enumFdaChoice;

typedef enum
{
    ChoPreparation_EventA3,
    ChoPreparation_EventA5,
    ChoPreparation_EventA4
} enumChoPreparationEvent_type;

typedef enum
{
    ChoExecutionCond1_EventA3,
    ChoExecutionCond1_EventA5
} enumChoExecutionCond1Event_type;

typedef enum
{
    ChoExecutionCond2_NotUse,
    ChoExecutionCond2_EventA3,
    ChoExecutionCond2_EventA5
} enumChoExecutionCond2Event_type;

typedef enum
{
    PSCellChange_EventA3 = 0,
    PSCellChange_EventA5 = 1,
    PSCellChange_EventA4 = 2
} enumNRPSCellChangeEventType;

typedef enum
{
    fpInterFreqPscellChange_EventA4 = 0,
    fpInterFreqPscellChange_EventA5 = 1
} enumFpInterFreqPscellChangeEvent_type;

typedef enum
{
    IntraNrHandover_EventA3 = 0,
    IntraNrHandover_EventA5 = 1,
    IntraNrHandover_EventA4 = 2
} enumIntraNrHandoverEventType;

typedef enum
{
    InterRatHandover_EventB1 = 0,
    InterRatHandover_EventB2 = 1
} enumInterRatHandoverEventType;

// pcell-freq-prioritization-handover-event-type
typedef enum
{
    pcellFreqPriorityHandover_EventA4 = 0,
    pcellFreqPriorityHandover_EventA5 = 1
} enumPcellFreqPriorityHandoverEventType;

typedef enum
{
    trafficBasedHandover_EventB1 = 0,
    trafficBasedHandover_EventB2 = 1
} enumTrafficBasedHandoverEventType;

typedef enum
{
    eutraAllowedMeasBandwidth_mbw6 = 0,
    eutraAllowedMeasBandwidth_mbw15,
    eutraAllowedMeasBandwidth_mbw25,
    eutraAllowedMeasBandwidth_mbw50,
    eutraAllowedMeasBandwidth_mbw75,
    eutraAllowedMeasBandwidth_mbw100
} enumEutraAllowedMeasBandwidth_type;

typedef enum
{
    eutraQOffsetRange_noUse = -1,
    eutraQOffsetRange_minus_24 = 0,
    eutraQOffsetRange_minus_22 = 1,
    eutraQOffsetRange_minus_20 = 2,
    eutraQOffsetRange_minus_18 = 3,
    eutraQOffsetRange_minus_16 = 4,
    eutraQOffsetRange_minus_14 = 5,
    eutraQOffsetRange_minus_12 = 6,
    eutraQOffsetRange_minus_10 = 7,
    eutraQOffsetRange_minus_8 = 8,
    eutraQOffsetRange_minus_6 = 9,
    eutraQOffsetRange_minus_5 = 10,
    eutraQOffsetRange_minus_4 = 11,
    eutraQOffsetRange_minus_3 = 12,
    eutraQOffsetRange_minus_2 = 13,
    eutraQOffsetRange_minus_1 = 14,
    eutraQOffsetRange_0 = 15,
    eutraQOffsetRange_plus_1 = 16,
    eutraQOffsetRange_plus_2 = 17,
    eutraQOffsetRange_plus_3 = 18,
    eutraQOffsetRange_plus_4 = 19,
    eutraQOffsetRange_plus_5 = 20,
    eutraQOffsetRange_plus_6 = 21,
    eutraQOffsetRange_plus_8 = 22,
    eutraQOffsetRange_plus_10 = 23,
    eutraQOffsetRange_plus_12 = 24,
    eutraQOffsetRange_plus_14 = 25,
    eutraQOffsetRange_plus_16 = 26,
    eutraQOffsetRange_plus_18 = 27,
    eutraQOffsetRange_plus_20 = 28,
    eutraQOffsetRange_plus_22 = 29,
    eutraQOffsetRange_plus_24 = 30
} enumEutraQOffsetRange;

typedef enum
{
    reportInterval_ms120 = 0,
    reportInterval_ms240 = 1,
    reportInterval_ms480 = 2,
    reportInterval_ms640 = 3,
    reportInterval_ms1024 = 4,
    reportInterval_ms2048 = 5,
    reportInterval_ms5120 = 6,
    reportInterval_ms10240 = 7,
    reportInterval_ms20480 = 8,
    reportInterval_ms40960 = 9,
    reportInterval_min1 = 10,
    reportInterval_min6 = 11,
    reportInterval_min12 = 12,
    reportInterval_min30 = 13
} enumReportInterval;

typedef enum
{
    reportAmount_r1 = 0,
    reportAmount_r2 = 1,
    reportAmount_r4 = 2,
    reportAmount_r8 = 3,
    reportAmount_r16 = 4,
    reportAmount_r32 = 5,
    reportAmount_r64 = 6,
    reportAmount_infinity = 7
} enumReportAmount;

typedef enum
{
    timeToTrigger_ms0 = 0,
    timeToTrigger_ms40 = 1,
    timeToTrigger_ms64 = 2,
    timeToTrigger_ms80 = 3,
    timeToTrigger_ms100 = 4,
    timeToTrigger_ms128 = 5,
    timeToTrigger_ms160 = 6,
    timeToTrigger_ms256 = 7,
    timeToTrigger_ms320 = 8,
    timeToTrigger_ms480 = 9,
    timeToTrigger_ms512 = 10,
    timeToTrigger_ms640 = 11,
    timeToTrigger_ms1024 = 12,
    timeToTrigger_ms1280 = 13,
    timeToTrigger_ms2560 = 14,
    timeToTrigger_ms5120 = 15
} enumTimeToTrigger;

typedef enum
{
    periodicalPurpose_nrppa = 0,
    periodicalPurpose_mdt = 1,
    periodicalPurpose_ueMeasForSon = 2,
    periodicalPurpose_scellRelease = 3,
    periodicalPurpose_mdtM6ulPdcpDelay = 4
} enumPeriodicalPurpose;

typedef enum
{
    AIR_CONDITION_FOR_UL_CA_LOW = 0,
    AIR_CONDITION_FOR_UL_CA_HIGH = 1
} enumAirConditionUlCa_type;

typedef enum
{
    a1Purpose_deactivateInterFrequency = 0,
    a1Purpose_scgFailureRecovery = 1,
    a1Purpose_inNRULCoverage_ueUlSplitSup = 2,
    a1Purpose_inNRULCoverage_ueUlSplitNotSup = 3,
    a1Purpose_FreqPrioScellToPScellSwitch = 4,
    a1Purpose_ActivateFpInterFrequency = 5,
    a1Purpose_ActivateSpidInterFrequency = 6,
    a1Purpose_saDeactivateMeasureGap = 10,
    a1Purpose_caAwareHandover = 11,
    a1Purpose_PcellFreqPriorHandover = 12,
    a1Purpose_nedcInNRULCoverage_ueUlSplitSup = 20,
    a1Purpose_nedcInNRULCoverage_ueUlSplitNotSup = 21,

    a1Purpose_nrdcDeactivateInterFrequency = 30,
    a1Purpose_nrdcInPScellUlCoverage_ueUlSplitSup = 33,
    a1Purpose_nrdcInPScellUlCoverage_ueUlSplitNotSup = 34,

    a1Purpose_scellRecoveryInA6UeTxpowerEnh = 40,
    a1Purpose_configUlCa = 50
} enumA1Purpose;

typedef enum
{
    a2Purpose_activateInterFrequency = 0,
    a2Purpose_NRPSCellRelease = 1,
    a2Purpose_outOfNRULCoverage_ueUlSplitSup = 2,
    a2Purpose_outOfNRULCoverage_ueUlSplitNotSup = 3,
    a2Purpose_scellRelease = 4,
    a2Purpose_ScgFailureSuspend = 5,
    a2Purpose_spidPscellRelease = 6,
    a2Purpose_bearerChangeToMcg = 7,
    a2Purpose_blindInterRatRedirection = 10,
    a2Purpose_activate_inter_rat = 11,
    a2Purpose_activateInterFrequencyForSa = 12,
    a2Purpose_blindIntraNrRedirectionForSa = 13,
    a2Purpose_PcellFreqPriorHandover = 14,
    a2Purpose_caAwareHandover = 15, // SVR24A FGR-MC1022 FR120
    a2Purpose_nedcOutOfNRULCoverage_ueUlSplitSup = 20,
    a2Purpose_nedcOutOfNRULCoverage_ueUlSplitNotSup = 21,

    /* NR-DC SN */
    a2Purpose_nrdcActivateInterFrequency = 30,
    a2Purpose_nrdcNRPSCellRelease = 31,
    a2Purpose_nrdcOutOfPScellUlCoverage_ueUlSplitSup = 34,
    a2Purpose_nrdcOutOfPScellUlCoverage_ueUlSplitNotSup = 35,

    a2Purpose_mdt = 40,
    a2Purpose_triggerPeriodicMdt = 41,
    a2Purpose_scellReleaseInA6UeTxpowerEnh = 42,
    a2Purpose_deconfigUlCa = 50
} enumA2Purpose;

typedef enum
{
    a3Purpose_NRPSCellChange = 0,
    a3Purpose_SpidPrioPSCellChange = 1,
    a3Purpose_intraNrHandover = 10,
    a3Purpose_Comp = 20,

    a3Purpose_nrdcNrPSCellChange = 30,

    a3Purpose_ChoPreparation = 60,
    a3Purpose_ChoExecutionCond1 = 61,
    a3Purpose_ChoExecutionCond2 = 62,

    a3Purpose_LtmPreparation = 90  // TODO: Need to edit the value, when YANG is added.
} enumA3Purpose;

typedef enum
{
    a4Purpose_scellAddition = 0,
    a4Purpose_NRPSCellChange = 1,
    a4Purpose_SpidPrioPSCellChange = 2,
    a4Purpose_FreqPrioPSCellChange = 3,
    a4Purpose_EndcLbPscellChange = 4,

    a4Purpose_intraNrHandover = 10,
    a4Purpose_PcellPriorHandover = 11,

    a4Purpose_nrdcNrPSCellChange = 30,

    a4Purpose_NRLoadBalancing = 50,

    a4Purpose_ChoPreparation = 60,

    a4Purpose_NrdcAddition = 70,
    a4Purpose_NrDcResume = 80,

    a4Purpose_nrForcedHandoverDueToSpecificSliceAware = 100
} enumA4Purpose;

typedef enum
{
    a5Purpose_NRPSCellChange = 0,
    a5Purpose_FreqPrioPSCellChange = 1,
    a5Purpose_SpidPrioPSCellChange = 2,
    a5Purpose_EndcNrPscellChangeDuIndication = 3,
    a5Purpose_EndcLbPscellChange = 4,
    a5Purpose_EndcPscellChangeUlStatusIndBadUlQuality = 5,
    a5Purpose_EndcPscellChangeUlStatusIndTddInterference = 6,

    a5Purpose_intraNrHandover = 10,
    a5Purpose_intraNrOnDemandHandover = 11,  // ODF_HO_21B
    a5Purpose_intraNrRfspHandover = 12,
    a5Purpose_PcellPriorHandover = 13,
    a5Purpose_CapabilityAwareCarrierChange = 14,

    a5Purpose_intraNrDuTriggeredForcedHandover = 15,
    a5Purpose_forcedHandoverDueToBadUlQuality = 16,     // FGR-MC1029 SVR25B
    a5Purpose_forcedHandoverDueToTddInterference = 17,  // FGR-MC1029 SVR25B
    a5Purpose_forcedHandoverDueToLongRtpGap = 18,       // FGR-MC1029 SVR25B

    a5Purpose_nrdcNrPSCellChange = 30,
    a5Purpose_nrdcRfspPSCellChange = 31,

    a5Purpose_NRLoadBalancing = 50,
    a5Purpose_voNrNRLoadBalancing = 51,  // FGR-LC0712
    a5Purpose_SliceAwareLoadBalancingForRedCap = 52,  // FGR-LC0710

    a5Purpose_ChoPreparation = 60,
    a5Purpose_ChoExecutionCond1 = 61,
    a5Purpose_ChoExecutionCond2 = 62,

    a5Purpose_LtmPreparation = 90,
    a5Purpose_sliceAwareMobilityForAutoMode = 91,
    a5Purpose_sliceAwareMobilityForPrioritySlice = 92,
} enumA5Purpose;

typedef enum
{
    a6Purpose_sCellChange = 0,
    a6Purpose_comp = 1
} enumA6Purpose;

typedef enum
{
    reportCgiPurpose_ReportCgi = 0,
    reportCgiPurpose_ReportCgiEutra = 1,
    // reportCgiPurpose_ReportCgi_DuplicatedPCI = 2,
    // reportCgiPurpose_ReportCgiEutra_DuplicatedPCI = 3,
    reportCgiPurpose_ReportCgi_Handover = 2,
    reportCgiPurpose_ReportCgiEutra_Handover = 3,
    reportCgiMaxPurpose = 4
} enumReportCgiPurpose;

typedef enum
{
    b1Purpose_eutraHandover = 10,
    b1Purpose_NedcSnAddition = 11,
    b1Purpose_eutraRfspHandover = 12,
    b1Purpose_saPriortizationHandover = 13,
    b1Purpose_saEpsFallbackHandover = 14,
    b1Purpose_saEmergencyFallbackHandover = 15,
    b1Purpose_CapabilityAwareCarrierChange = 16,
    b1Purpose_trafficBasedHandover = 17,
    b1Purpose_mrsMrGathering = 18,
    b1Purpose_multiRatSelection = 19,
    b1Purpose_saToNsaBorderHandover = 20,
    b1Purpose_eutraForcedHandoverDueToUlPrbBlanking = 30,    // FGR-MC1029 SVR25B
    b1Purpose_eutraForcedHandoverDueToBadUlQuality = 31,     // FGR-MC1029 SVR25B
    b1Purpose_eutraForcedHandoverDueToTddInterference = 32,  // FGR-MC1029 SVR25B
    b1Purpose_eutraForcedHandoverDueToLongRtpGap = 33,       // FGR-MC1029 SVR25B
    b1Purpose_eutraForcedHandoverDueToSpecificSliceAware = 34, // FGR-MC1021:FR130 SVR25B PMB
    b1Purpose_iratRedirectionForAccessControl = 35, // FGR-MC1025 26A
    b1Purpose_loadBalancingIratHandover = 50,
} enumB1Purpose;

typedef enum
{
    b2Purpose_eutraHandover = 10,
    b2Purpose_eutraOnDemandHandover = 11,  // ODF_HO_21B
    b2Purpose_saEpsFallbackHandover = 12,
    b2Purpose_saEmergencyFallbackHandover = 13,
    b2Purpose_trafficBasedHandover = 14,
    b2Purpose_capabilityAwareCarrierChange = 16,
    b2Purpose_loadBalancingIratHandover = 50,
} enumB2Purpose;

typedef enum
{
    periodicalInterRATPurpose_nrppa = 0,
    periodicalInterRATPurpose_mdt = 1,
    periodicalInterRATPurpose_ueMeasForSon = 2,
} enumPeriodicalInterRatPurpose;

typedef enum
{
    MCG_mobility = 0,
    SCG_mobility = 1,
    SCG_failure = 2
} enumReceivedFromMNPurpose;

typedef enum
{
    measReport_periodical = 0,
    measReport_A1 = 1,
    measReport_A2 = 2,
    measReport_A3 = 3,
    measReport_A4 = 4,
    measReport_A5 = 5,
    measReport_A6 = 6,
    measReport_reportCGI = 7,
    measReport_B1Eutra = 8,
    measReport_B2Eutra = 9,
    measReport_reportCGIEutra = 10,
    measReport_periodicalInterRat = 11,

    measReport_unknown
} enumMeasurementReportType;

typedef struct
{
    // as of now it is empty as there is no report config inter rat specific parameters
    uint8_t dummy;  // C does not support empty structures
} periodicalReportConfigurationInterRat_type;

typedef enum
{
    measRatNr = 0,
    measRatEutra = 1,
    measRatUnknown = -1
} enumMeasRatType;

typedef enum
{
    RSType_SSB = 0,
    RSType_CSIRS = 1
} enumRSType;

typedef enum
{
    filterCoefficient_fc0 = 0,
    filterCoefficient_fc1 = 1,
    filterCoefficient_fc2 = 2,
    filterCoefficient_fc3 = 3,
    filterCoefficient_fc4 = 4,
    filterCoefficient_fc5 = 5,
    filterCoefficient_fc6 = 6,
    filterCoefficient_fc7 = 7,
    filterCoefficient_fc8 = 8,
    filterCoefficient_fc9 = 9,
    filterCoefficient_fc11 = 10,
    filterCoefficient_fc13 = 11,
    filterCoefficient_fc15 = 12,
    filterCoefficient_fc17 = 13,
    filterCoefficient_fc19 = 14,
} enumFilterCoefficient;

typedef enum
{
    choice_SSB = 0,
    choice_CSIRS = 1
} enumSMeasureChoice;

typedef enum
{
    ci_5g_Rpt_direct = 0,
    ci_5g_Rpt_change_of_serve_cell = 1,
    ci_5g_Rpt_UE_in_AoI = 2,
    ci_5g_Rpt_stop_change_of_serve_cell = 3,
    ci_5g_Rpt_stop_UE_in_AoI = 4,
    ci_5g_Rpt_cancel = 5,
} enumLocRptEvent_type;

typedef enum
{
    ci_Rpt_cell = 0
} enumLocRptArea_type;

// mr-triggering-dl-comp
// access-enum-mr-triggering-ul-comp
typedef enum
{
    COMP_OFF = 0,
    COMP_ON = 1,
    COMP_VoNR_ONLY = 2,
} enumCoMPOption_type;

typedef struct
{
    plmnId_type plmn;
    uint32_t tac;
} locRptAoITAIItem_type;

typedef struct
{
    // CELL IDENTITY [BIT STRING (SIZE(36))] + PLMN [ 3 OCTET ]
    uint64_t nGRAN_CgiBitStr;
} locRptAoICellItem_type;

typedef struct
{
    vccbGlobalGnbId_type globalRANNodeID;
} locRptAoIRANNodeItem_type;

typedef struct
{
    NGAP_LocationReportingReferenceID locationReportingReferenceID;
    NGAP_UEPresence uEPresence;
    // TAI
    unsigned short numAoITAI;
    // CELL
    unsigned short numAoICell;
    // RAN Node
    unsigned short numAoIRANNode;

    locRptAoITAIItem_type aOITAI[NG_MaxnoofTAIinAoI];
    locRptAoICellItem_type aOICell[NG_MaxnoofCellinAoI];
    locRptAoIRANNodeItem_type aOIRAN[NG_MaxnoofRANNodeinAoI];
} locRptAoIItem_type;

typedef struct
{
    uint8_t noofAoI;
    locRptAoIItem_type aoI[NG_MaxnoofAoI];
} locReqAoIList_type;

typedef NGAP_UEPresenceInAreaOfInterestList_type locRptAoIList_type;

typedef enum
{
    ci_Add_Loc_Info_OFF = 0,
    ci_Add_Loc_Info_PSCELL = 1
} enumAdditionalLocInfo_type;

typedef enum
{
    lbNrHandover_EventA4 = 0,
    lbNrHandover_EventA5 = 1
} enumLbNrHandoverEventType;

typedef enum
{
    PowerClass1dot5UeSupport_notUsage = 0,
    PowerClass1dot5UeSupport_fr1Usage = 1
} enumPowerClass1dot5UeSupport_type;

typedef enum
{
    PowerClass2UeSupport_notUsage = 0,
    PowerClass2UeSupport_fr1Usage = 1
} enumPowerClass2UeSupportType;

typedef enum
{
    PowerClass1UeSupport_notUsage = 0,
    PowerClass1UeSupport_fr2Usage = 2
} enumPowerClass1UeSupportType;

typedef enum
{
    Fr1PowerClass1UeSupport_notUsage = 0,
    Fr1PowerClass1UeSupport_Usage = 1
} enumFr1PowerClass1UeSupportType;

typedef struct
{
    uint8_t reportOn;                   // ENUM:: enumUsage_type CI_use, CI_no_use
    uint8_t eventType;                  // ENUM:: enumLocRptEvent_type
    uint8_t rptArea;                    // ENUM:: enumLocRptArea_type
    uint8_t additionalLocInfo;          // ENUM:: enumAdditionalLocInfo_type
    uint8_t isPagingReqForInactivity;   // TRUE/FALSE:: used for sending Location Report if paging is success
    locReqAoIList_type areaofInterest;  // struct :: locReqAoIList_type
} locRptInfo_type;

typedef enum enumLatitude
{
    trp_north = 0,
    trp_south = 1
} enumLatitude;

typedef enum enumAltitude
{
    trp_height = 0,
    trp_depth = 1
} enumAltitude;

typedef struct
{
    enumLatitude latitudeSign;
    unsigned int latitude;
    int longitude;
    enumAltitude directionOfAltitude;
    unsigned short altitude;
    unsigned short uncertaintySemi_major;
    unsigned short uncertaintySemi_minor;
    unsigned short orientationOfMajorAxis;
    unsigned short uncertaintyAltitude;
    unsigned short confidence;
    uint8_t geoCoordinatesPresent;
} TRPDirectNormalAccuracy_type;

typedef struct
{
    uint8_t rsrpFlag;
    uint8_t rsrqFlag;
    uint8_t sinrFlag;

    uint16_t rsrp; /* optional */
    uint16_t rsrq; /* optional */
    uint16_t sinr; /* optional */
} pMeasQuantityResults_type;

typedef struct
{
    uint8_t resultsSSB_CellFlag;

    pMeasQuantityResults_type resultsSSB_Cell; /* optional */
} pCellResults_type;

typedef struct
{
    uint8_t physCellIdFlag;
    uint16_t physCellId; /* optional */
    uint32_t arfcn;
    uint8_t isServingCell;

    /* measResult */
    pCellResults_type cellResults;
} pMeasResultNR_type;

typedef struct
{
    uint8_t physCellIdFlag;
    uint16_t physCellId; /* optional */
    uint32_t earfcn;

    /* measResult */
    pCellResults_type cellResults;
} pMeasResultEUTRA_type;

typedef struct
{
    uint8_t numCellReport;
    pMeasResultNR_type measResultNR[MAX_NUM_CELL_REPORT_NRPPA];
} pMeasResultListNR_type;

typedef struct
{
    uint8_t numCellReport;
    pMeasResultEUTRA_type measResultEUTRA[MAX_NUM_CELL_REPORT_NRPPA];
} pMeasResultListEUTRA_type;

typedef struct
{
    uint16_t alpha;
    uint16_t beta;
    uint16_t gamma;
} LCS_to_GCS_Translation_type;

typedef struct
{
    uint8_t zenithAoAFlag;
    uint8_t lCS_to_GCS_Flag;

    uint16_t azimuthAoA;
    uint16_t zenithAoA;
    LCS_to_GCS_Translation_type lCS_to_GCS_Translation;
} ulAoA_type;

typedef struct
{
    NGAP_RoutingID_type routingId;
    uint16_t NrPpaTransactionId;
    uint32_t lMFUeMeasurementId;
    uint8_t measurementPeriodicityPresent;
    uint8_t reportCharacteristics;
    uint8_t measurementPeriodicity;
    uint8_t numOfMeasuredQuantities;
    uint8_t measuredQuantitiesItem[63];
    uint8_t numOfIratMeasuredQuantities;
    uint8_t OtherRATMeasurementQuantitiesPresent;
    uint8_t iratMeasuredQuantitiesItem[63];
    uint8_t numOfWlanMeasuredQuantities;
    uint8_t wLanMeasuredQuantitiesItem[63];
    uint8_t isPagingRequiredForECID;
    uint8_t isMeasReportRequired;
    uint8_t isMeasConfigRequired;
    uint8_t isMeasGapConfiguredInOnDemand;  // For reverting MeasGap
    uint16_t ecidMeasId[MAX_MEAS_ID];       // reportAmount changes for On Demand
    uint8_t isMeasReportStored;             // reportAmount changes for On Demand; Ignore Subsequent MRs
    uint8_t isNrppaPosContextValid;
    uint8_t isNrTARequested; //NR Timing Advance requested from LMF
    uint16_t valueTimAdvNR;  //NR Timing Advance, INTEGER (0.. 7690)
    uint8_t isTimAdvReceived; //Whether Tim Adv is received from F1
    uint8_t isTriggerMeasReconfig; //Meas Reconfig may not be triggered if only TA is requested
    uint8_t isPcellFilled; //Flag to check if PCell Measurement RSRP/RSRQ is not received from UE MR
    uint8_t isNrAoARequested            : 1; // NR AoA requested from LMF
    uint8_t isAoAReceived               : 1; // AoA is received from F1
    uint8_t isMeasPeriodicityAoAPresent : 1; // AoA Periodicity received
    uint8_t isSRSConfigReceivedECID     : 1; // SRS configuration received from F1 during ECID.
    uint8_t isSRSConfigReceivedMultiRTT : 1; // SRS configuration received from F1 during MultiRTT.
    uint8_t aoANotReceivedInTime        : 1;
    uint8_t otherMeasNotReceivedInTime  : 1;
    uint8_t isF1EcidMeasFailureReceivedDuringSrsOn : 1;
    uint8_t measurementPeriodicityAoA;
    ulAoA_type valueAoANR;
    TRPDirectNormalAccuracy_type tRPDirectNormal;
    enumNrppaReportingTrigger_type nrppaReportingTrigger;
    pMeasResultListNR_type measResultCell;
    pMeasResultListEUTRA_type measResultCellEUTRA;
} NrPpaContext_type;

typedef struct
{
    F1_LocationMeasurementInformation encoded;
    unsigned char buff[MAX_BUF];
} NRRRC_LocationMeasurementInfo_type;

typedef struct
{
    enumLocationMeasurementIndication locationMeasIndStatus; // Off/SetupinProgress/Active/ReleaseinProgress
    NRRRC_LocationMeasurementInfo_type locationMeasInfo;
} NrDlTdoaContext_type;

typedef struct
{
    uint32_t nbrGnbCellIndex;
} NRCANbrCellAutoConfig_type;

typedef struct
{
    struct
    {
        uint8_t periodicity;  // enumSmtcPeriodicity
        uint8_t offset;
    } periodicityAndOffset;
    uint8_t duration;  // enumSmtcDuration
} smtc1_type;

typedef struct
{
    uint32_t ssbArfcn;
    smtc1_type smtc1;
} smtc1PerFreq_type;

typedef struct
{
    uint8_t usage;  // enumUsage_type
    uint8_t numPCIs;
    uint8_t smtc2Periodicity;  // enumSmtcPeriodicity
    uint16_t PCIs[MAX_NUM_OF_PCIS_SMTC2];
} smtc2_type;

typedef struct ssbMeasurementConfiguration_s
{
    uint8_t usage;         // enumUsage_type
    uint8_t ssbToMeasure;  // enumSSBToMeasure
    uint64_t ssbValue;
} ssbMeasurementConfiguration_type;

typedef struct freqBandInfo_s
{
    uint16_t status          : 1;
    uint16_t nRFrequencyBand : 15;  // INTEGER (1..1024)
} freqBandInfo_type;

typedef enum
{
    VCCB_CELLDIR_DLONLY = 0,
    VCCB_CELLDIR_ULONLY = 1,
    VCCB_CELLDIR_BOTH = 2,
    VCCB_CELLDIR_END
} enumCellDirection_type;

typedef enum
{
    VCCB_NBR_GNB_CELL_DEACTIVATE,
    VCCB_NBR_GNB_CELL_ACTIVATE
} enumVccbNbrGnbCellDeactivationInd_type;

// IRAT Redirection Forced Option.
typedef enum
{
    Redirection_Forced_None,
    Redirection_Forced_Blind,
    Redirection_Forced_MrBased
} enumInterRatRedirectionForcedOption_type;

// Check State for H/O or Redirect in Vonr Setup Fail
typedef enum
{
    CheckHoOrRedirect_OnPartialState,
    CheckHoOrRedirect_OnUeReleaseState
} enumCheckHoOrRedirectionState_type;

// Check Result for H/O or Redirect in Vonr Setup Fail
typedef enum
{
    CheckResult_NoCondition = 0x0,
    CheckResult_Ho          = 0x01,
    CheckResult_Redirect    = 0x02
} enumCheckHoOrRedirectionResult_type;

/**
 * @brief neighbor gNB cell information
 */
#define VCCB_MAX_NPN_ID_PER_NBR_GNB_CELL (12U)

typedef struct
{
    uint8_t status; /**< EQUIP/N_EQUIP */
    uint8_t nrScsDl;
    uint8_t nrScsUl;
    uint8_t configuredTacIndication;  // CONFIG_TAC_IND_21C - NRDC
    uint8_t cellDirection;            // NR_CONN_MC_23A  0:DlOnly, 1:UlOnly, 2:Both
    uint8_t voNrSupport;              // NR_CONN_MC_23B
    uint8_t fiveGsTacStatus;     /**< EQUIP/N_EQUIP */
    uint8_t configuredTacStatus; /**< EQUIP/N_EQUIP */
    uint8_t nonNeighbor;
    uint8_t deactivationIndication;     //enumVccbNbrGnbCellDeactivationInd_type, This parameter must be used only in the inter-gnb neighbor.
    union
    {
        struct
        {
            uint16_t saAvailable0 : 1;  // SVR25B, TRUE / FLASE
            uint16_t saAvailable1 : 1;
            uint16_t saAvailable2 : 1;
            uint16_t saAvailable3 : 1;
            uint16_t saAvailable4 : 1;
            uint16_t saAvailable5 : 1;
            uint16_t saAvailable6 : 1;
            uint16_t saAvailable7 : 1;
        };
        uint16_t saAvailable;
    };
    uint16_t nrbDl;
    uint16_t nrbUl;
    uint16_t bandwidthDl;
    uint16_t bandwidthUl;
    uint16_t cellId;             /**< INTEGER (0..16383) - 14 bits */
    uint16_t nrPci;              /**< INTEGER (0..1007) */
    uint16_t configuredTac;      /**< INTEGER (0..65535) - 16 bits */
    int16_t redcapBroadcastInfo;      // 0..255:Valid, -1:notConfigured // SVR23B FGR-MC1027 Connected mobility control for RedCap UE
    uint32_t nrArfcnDl;          /**< INTEGER (0..3279165) TDD:nrArfcn, FDD:nrArfcnDl*/
    uint32_t nrArfcnUl;          /**< INTEGER (0..3279165)*/
    uint32_t ssbArfcn;           /**< INTEGER (0..3279165) */
    uint32_t fiveGsTac;          /**< INTEGER (0..16777215) - 24 bits */
    enumUsage_type
        smtcStatus; /* 'no_use' means 'not configured'. if not configured, regards as same value with serving NR MO */
    vccbGlobalGnbId_type globalGnbId;
    plmnIdInfo_type cellPlmnInfo[MAX_PLMN_INDEX];
    uint64_t npnInfoPacked[VCCB_MAX_NPN_ID_PER_NBR_GNB_CELL];  // [63:60]=npnCount, [58]=hasType, [57]=hasPlmnIdx, [56]=hasId, [55:48]=plmnIdx, [47:44]=npnType, [43:0]=npnId
    freqBandInfo_type freqBandInfoList[MAX_FREQBAND_PER_CELL];
    smtc1_type smtc1;
    ssbMeasurementConfiguration_type ssbMeasurementConfiguration;

    //FGR-CC5200:FR483
    long cacBackOffTime;  // msec
} nbrGnbCellInfo_type;

/** Ordered NRCGI list length for inter-gNB neighbor extended identity (per nbrGnbCell slot). */
#define VCCB_NBR_GNB_CELL_CGI_LIST_LEN (3U)

/** Packed logical-cell NRCGI layout: [61]=hasPlmn, [60]=hasCi, [59:0] payload, where [59:24]=CI(36b), [23:0]=PLMN(24b). */
#define VCCB_LOGICAL_CELL_CGI_PLMN_BITS (24U)
#define VCCB_LOGICAL_CELL_CGI_CI_BITS (36U)
#define VCCB_LOGICAL_CELL_CGI_CI_SHIFT (VCCB_LOGICAL_CELL_CGI_PLMN_BITS)
#define VCCB_LOGICAL_CELL_CGI_CI_MASK ((1ULL << VCCB_LOGICAL_CELL_CGI_CI_BITS) - 1ULL)
#define VCCB_LOGICAL_CELL_CGI_PLMN_MASK ((1ULL << VCCB_LOGICAL_CELL_CGI_PLMN_BITS) - 1ULL)
#define VCCB_LOGICAL_CELL_CGI_CI_VALID_BIT (60U)
#define VCCB_LOGICAL_CELL_CGI_PLMN_VALID_BIT (61U)
#define VCCB_LOGICAL_CELL_CGI_PACKED_INVALID (0ULL)

/**
 * @brief Inter-gNB neighbor extended DB: ordered CGI list parallel to nbrGnbCell[slot].
 *        Base RF/config remains in nbrGnbCellInfo_type.
 */
typedef struct
{
    uint8_t validMask;        /**< Bit i set => packedCgiList[i] is valid (i < VCCB_NBR_GNB_CELL_CGI_LIST_LEN). */
    uint8_t relationCgiIndex; /**< Index into packedCgiList for relation/map CGI; 0xFF if not set. */
    uint8_t reserved[2];
    uint64_t packedCgiList[VCCB_NBR_GNB_CELL_CGI_LIST_LEN]; /**< Per entry: [61]=hasPlmn, [60]=hasCi, [59:24]=CI, [23:0]=PLMN. */
} nbrGnbCellCgiListExt_type;

/** Sentinel for nbrGnbCellCgiListExt_type::relationCgiIndex when not set / N/A. */
#define VCCB_NBR_GNB_CELL_CGI_LIST_REL_IDX_INVALID (0xFFU)

/**
 * Bit flags for getNbrGnbCellInfosByCellNbrIdx / getNbrGnbCellInfosByNbrIdx (OR together).
 * Bits not listed here are reserved for future use.
 */
#define VCCB_NBR_GNB_CELL_INFOS_F_EXT_USE_LIST (1U << 0)
#define VCCB_NBR_GNB_CELL_INFOS_F_EXT_INCL_INTRA (1U << 1)

/** Relation CGI only for nbrIdx; ignores ext list. */
#define VCCB_NBR_GNB_CELL_INFOS_QUERY_DEFAULT (0U)
/** Walk nbrGnbCellCgiListExt when populated; inter-gNB rows only. */
#define VCCB_NBR_GNB_CELL_INFOS_QUERY_EXT_CGI_LIST_INTER_ONLY (VCCB_NBR_GNB_CELL_INFOS_F_EXT_USE_LIST)
/** Walk ext list with intra + inter resolution. */
#define VCCB_NBR_GNB_CELL_INFOS_QUERY_EXT_CGI_LIST_ALL_IDENTITY \
    (VCCB_NBR_GNB_CELL_INFOS_F_EXT_USE_LIST | VCCB_NBR_GNB_CELL_INFOS_F_EXT_INCL_INTRA)

/** Packed NPN layout: [63:60]=npnCount, [58]=hasType, [57]=hasPlmnIdx, [56]=hasId, [55:48]=plmnIdx(8b), [47:44]=npnType(4b), [43:0]=npnId(44b). */
#define VCCB_NPN_INFO_ID_BITS (44U)
#define VCCB_NPN_INFO_ID_MASK ((1ULL << VCCB_NPN_INFO_ID_BITS) - 1ULL)
#define VCCB_NPN_INFO_TYPE_SHIFT (44U)
#define VCCB_NPN_INFO_TYPE_MASK (0xFULL)
#define VCCB_NPN_INFO_PLMN_IDX_SHIFT (48U)
#define VCCB_NPN_INFO_PLMN_IDX_MASK (0xFFULL)
#define VCCB_NPN_INFO_HAS_ID_BIT (56U)
#define VCCB_NPN_INFO_HAS_PLMN_IDX_BIT (57U)
#define VCCB_NPN_INFO_HAS_TYPE_BIT (58U)
#define VCCB_NPN_INFO_COUNT_SHIFT (60U)
#define VCCB_NPN_INFO_COUNT_MASK (0xFULL)
#define VCCB_NPN_INFO_PACKED_INVALID (0ULL)

/**
 * @brief neighbor cell information of resufed FR1 cells for FR2->FR1 HO
 */
typedef struct
{
    uint8_t status; /**< EQUIP/N_EQUIP */
    vccbGlobalGnbId_type globalGnbId;
    uint16_t cellId; /**< INTEGER (0..16383) - 14 bits */
} nbrRefusedFR1CellInfo_type;

typedef struct {
  uint8_t usage; // enumUsage_type

  struct {
    uint8_t length; // 1..80 bits
    char value[MAX_MEAS_SLOTS_LENGTH_IN_BYTES];
  } measurementSlots;

  uint8_t endSymbol;
} ssRssiMeasurementConfig_type;

typedef struct {
  ssbMeasurementConfiguration_type ssbMeasurementConfiguration;
  uint8_t usage; // enumUsage_type
  uint8_t deriveSSB_IndexFromCell;
  ssRssiMeasurementConfig_type ssRssiMeasurementConfig;
} ssbConfigMobilityDb_type;

typedef struct {
  ssbMeasurementConfiguration_type ssbMeasurementConfiguration;
  uint8_t usage; // enumUsage_type
  uint8_t deriveSSB_IndexFromCell;
} ssbConfigMobilityUe_type;

typedef struct
{
    uint16_t csi_RS_Index;

    struct
    {
        uint16_t slotConfigLength : 3;  // enumSlotConfigLength
        uint16_t value;
    } slotConfig;

    struct
    {
        uint8_t usage;  // enumUsage_type
        uint8_t ssbIndex;
        uint8_t isQuasiColocated;
    } associatedSsb;

    struct
    {
        uint16_t choice : 1;  // enumFdaChoice
        uint16_t value;
    } frequencyDomainAllocation;

    uint8_t firstOFDMSymbolInTimeDomain;
    uint16_t sequenceGenerationConfig;
} csi_rs_ResourceMobility_type;

typedef struct
{
    uint16_t pci;

    struct
    {
        uint8_t nrOfPrbs;  // enumNrOfPrbs
        uint16_t startPrb;
    } measurementBw;

    uint8_t density;  // enumDensity

    struct
    {
        uint8_t numItems;
        csi_rs_ResourceMobility_type items[MAX_NR_OF_CSI_RS_RESOURCES_RRM];
    } csi_rs_ResourceList_Mobility;
} csi_rs_CellMobility_type;

typedef struct {
  ssbConfigMobilityDb_type ssbConfigMobility;
  // csi rs is not supported yet
} referenceSignalConfigDb_type;

typedef struct {
  ssbConfigMobilityUe_type ssbConfigMobility;
  // csi rs is not supported yet
} referenceSignalConfigUe_type;

typedef struct
{
    struct
    {
        uint8_t usage;  // enumUsage_type
        uint8_t value;
    } thresholdRSRP;

    struct
    {
        uint8_t usage;  // enumUsage_type
        uint8_t value;
    } thresholdRSRQ;

    struct
    {
        uint8_t usage;  // enumUsage_type
        uint8_t value;
    } thresholdSINR;

} thresholdNR_type;

typedef struct
{
    uint16_t rsrpOffsetSSB    : 5;  // enumQOffsetRange
    uint16_t rsrqOffsetSSB    : 5;  // enumQOffsetRange
    uint16_t sinrOffsetSSB    : 5;  // enumQOffsetRange
} qOffsetSSBRangeList_type;

typedef enum
{
    notMatchedPlmn_allowed = 0,
    notMatchedPlmn_notAllowed = 1,
} notMatchedPlmnOption_type;

typedef struct
{
    uint16_t pci;
    qOffsetSSBRangeList_type cellIndividualOffset;
} cellToMeasure_type;

typedef struct
{
    uint8_t numItems;
    cellToMeasure_type items[MAX_NR_OF_CELLS_TO_MEASURE];
} cellsToMeasureList_type;

typedef struct
{
    enumUsage_type usage;
    uint16_t band;
} freqBand_type;

typedef struct
{
    freqBand_type freqBand[MAX_MEAS_FREQ_BAND_COMMON_NR_EUTRA];
} freqBandEutraList_type;

typedef struct
{
    freqBand_type freqBand[MAX_MEAS_FREQ_BAND_COMMON_NR_EUTRA];
} freqBandNrList_type;

typedef struct
{
    int8_t value_rsrp;
    int8_t value_rsrq;
    int8_t value_sinr;
} MeasQuantitiesValues_type;

typedef struct
{
    enumUsage_type usage;

    uint32_t ssbFrequency;
    uint8_t ssbSubcarrierSpacing;  // enumSubcarrierSpacing
    smtc1_type smtc1;
    bool
        operatorConfiguredSmtc1;  // NR_CONN_MC_21D - If Off, it can be a target even if the smtc1 setting is different.
    smtc2_type smtc2;
    referenceSignalConfigDb_type referenceSignalConfig;
    thresholdNR_type absThreshSS_BlocksConsolidation;
    thresholdNR_type nrdcPSCellSelection;          // MR-DC PScell selection threshold
    unsigned short nrofSS_BlocksToAverage;         // INTEGER (2..16), 0 - absent
    unsigned short quantityConfigIndex;
    qOffsetSSBRangeList_type offsetMO;
    uint8_t nrPSCellChangeEvent;     // enumNRPSCellChangeEventType
    uint8_t nrdcPSCellChangeEvent;   // enumNRPSCellChangeEventType
    uint8_t intraNrHandoverEvent;    // enumIntraNrHandoverEventType
    uint8_t choPreprationEvent;      // enumChoPreparationEvent_type
    uint8_t choExecutionCond1Event;  // enumChoExecutionCond1Event_type
    uint8_t choExecutionCond2Event;  // enumChoExecutionCond2Event_type
    uint8_t pcellFreqPriHoEvent;     // enumPcellFreqPriorityHandoverEventType
    uint8_t lbNrHandoverEvent;       // enumLbNrHandoverEventType
    uint8_t lbNrPscellChangeEvent;   // enumLbNrHandoverEventType, FGR-LC0708 FR10.
    freqBandNrList_type freqBandIndicatorDbList;
    uint16_t anrPriority;
    uint16_t supportedBandwidth;
    uint8_t saCapable;
    uint8_t moPriority;
    uint8_t psCellChangeOnlyIfCaPcc;
    bool supportOnDemandMobility;  // ../gutran-cu-cell-entries/meas-object-entries
                                   // ../gutran-cu-cell-entries/intra-frequency-meas-object // ODF_HO_21B
    enumPowerClass2UeSupportType pc2UeSupport;
    enumPowerClass1dot5UeSupport_type pc1dot5UeSupport;
    enumPowerClass1UeSupportType pc1UeSupport;
    enumFr1PowerClass1UeSupportType fr1Pc1UeSupport;
    uint8_t cbrsEnabled;
    uint8_t ltmAllowance;
    uint16_t weightUeMeas;  // 0..1000
    uint32_t umfsMaxNrCallCnt;
    uint32_t umfsMaxCbrsCallCnt;
    uint32_t umfsCurrentNrCallCnt;
    uint8_t loadBalancingThresholdGroup;
    uint8_t loadBalancingThresholdGroupPscellChange; // FGR-LC0708
    uint8_t redcapAccessAllowed; // SVR23B FGR-MC1027 Connected mobility control for RedCap UE
    int8_t smallCellPciListIndex; // -1 ~ (MAX_NR_SMALLCELL_PCI_ENTRIES - 1) // SM_CELL_HO_24A
    bool supportForcedMobilityByUplinkStatusIndication; // FGR-MC1029, FGR-CC5001 FR152
    bool caAwareScellToPcellChangeByA2HoAllowed; // SVR24A FGR-MC1022 FR120

    // FGR-LC0705:FR12
    uint16_t scgBandThresholdUeCapaNrdc;
    uint16_t numOfCellForNrdcMeasureOrdering;
    uint16_t requiredThresholdForNrdcUe;        // 0 ~ 100
    uint16_t requiredThresholdForNrdcDlCapa;    // 0 ~ 100
    uint16_t requiredThresholdForNrdcUlCapa;    // 0 ~ 100

    struct measRsrpThresholdLb_s
    {
        uint8_t rsrp;
        uint8_t rsrq;
        uint8_t measThresholdTypeLb;
    } measThresholdForIdleLB;

    uint8_t freqRestrictOptionForPingPongAvoidance; /**< enumPingPongAvoidanceRestrictOption_type, FR510 */

} measurementObjectNRBaseDb_type;

typedef struct
{
    uint16_t pciType  : 1;  // uint8_t only for memory saving purposes - in fact enumPciType_type.
    uint16_t pciRange : 4;
    uint16_t pciStart : 10;
} pciRange_type;

typedef struct
{
    uint8_t usage;
    pciRange_type pciRange;
} blackCellsElementDb_type;

typedef struct
{
    uint8_t pciRangeIndex;
    pciRange_type pciRange;
} blackCellsElementUe_type;

typedef struct
{
    uint8_t numItems;
    blackCellsElementUe_type rangeElements[MAX_NR_OF_PCI_RANGES];
} blackCellsUe_type;

typedef struct
{
    uint8_t cellIndexEutra;
    pciRange_type physCellIdRange;
} blackCellsEutraRange_type;

typedef struct
{
    uint8_t usage;  // enumUsage_type
    blackCellsEutraRange_type range;
} blackCellsEutraDb_type;

typedef struct
{
    uint8_t numItems;
    blackCellsEutraRange_type rangeElements[MAX_CELL_MEAS_EUTRA];
} blackCellsEutra_type;

typedef struct
{
    uint8_t usage;
    uint32_t ncdSsbArfcn;
    uint8_t ncdSsbSubcarrierSpacing;  // enumSubcarrierSpacing
    smtc1_type ncdSmtc1;
} ncdSsbInfo_type;

typedef struct
{
    uint8_t pciRangeIndex;
    // only single pci supported
    // extend if ranges are required
    uint16_t pci;
} pciRangeElement_type;

typedef struct
{
    pciRangeElement_type pciRanges[MAX_NR_OF_PCI_RANGES];
    uint8_t numOfPciRanges;
} pciRangeElements_type;

typedef struct
{
    uint32_t ssbFrequency;
    uint8_t ssbSubcarrierSpacing;  // enumSubcarrierSpacing
    ncdSsbInfo_type ncdSsbInfo;
    smtc1_type smtc1;
    smtc2_type smtc2;
    referenceSignalConfigUe_type referenceSignalConfig;
    thresholdNR_type absThreshSS_BlocksConsolidation;
    unsigned short nrofSS_BlocksToAverage;         // INTEGER (2..16), 0 - absent
    unsigned short quantityConfigIndex;
    int8_t smallCellPciListIndex; // -1 ~ (MAX_NR_SMALLCELL_PCI_ENTRIES - 1) // SM_CELL_HO_24A
    uint8_t smtc1Origin;  // enum measObjectSmtc1Origin_type
    qOffsetSSBRangeList_type offsetMO;
    uint8_t choExecutionCond1Event;  // enumChoExecutionCond1Event_type
    uint16_t freqBandIndicatorNR;    // INTEGER (1..1024), 0 - disabled
    timerT312_type T312;             // FGR-MC1018 Fast_RLF_Recovery
    uint8_t pc1UeSupport     : 2;
    uint8_t pc1dot5UeSupport : 1;
    uint8_t pc2UeSupport     : 1;
    uint8_t fr1Pc1UeSupport  : 1;
    uint8_t reserved         : 3;
    pciRangeElements_type allowedCells;
} minimalMeasObjectNRUe_type;

typedef struct
{
    minimalMeasObjectNRUe_type minimal;
    cellsToMeasureList_type cellsToMeasure;
    blackCellsUe_type blackCells;
} measurementObjectNRUe_type;

/**
 * @brief cell NBR information
 */
typedef struct
{
    uint8_t status; /**< EQUIP/N_EQUIP */
    uint8_t isHoAllowed;
    uint8_t isEndcHoAllowed; /** TRUE/FALSE **/
    uint8_t dssEnabled;
    uint16_t targetCellId; /** 0..16383 **/
    int8_t cioDelta;    /** -30..30 : YANG(cio-delta) **/
    int8_t cioDeltaHom;    /** -30..30 : YANG(cio-delta-hom) **/
    int8_t cioMinDelta; /** -30..0 : YANG(min-cio-delta) **/
    vccbGlobalGnbId_type targetGnbId;
    int32_t rank; /** -1..10000 **/
    uint32_t mrCount[VCCB_CALL_THREAD_NUM];
    qOffsetSSBRangeList_type cellIndividualOffset;
} nbrCellInfo_type;

/**
 * @brief cell EUTRA neighbor information
 */
typedef struct
{
    uint8_t status;                  /** EQUIP/N_EQUIP */
    uint8_t isHoAllowed;             /** TRUE/FALSE **/
    uint8_t cellIndOffset;           /** enumEutraQOffsetRange **/
    uint8_t qRxLevMinOffsetCell_use; /** EQUIP/N_EQUIP */
    uint8_t qRxLevMinOffsetCell;     /** 1..8 **/
    uint8_t qQualMinOffsetCell_use;  /** EQUIP/N_EQUIP */
    uint8_t qQualMinOffsetCell;      /** 1..8 **/
    uint32_t targetEnbId;            /** 0..1048575 **/
    plmnId_type plmn;                /** mcc, mnc **/
    uint16_t cellId;                 /** 0..255 **/
    int8_t isColocated;              /** TRUE/FALSE **/
    int32_t rank;                    /** -1,0..10000 **/
    int8_t cioDelta;                 /** -30..30 : YANG(cio-delta) **/
    uint32_t mrCount[VCCB_CALL_THREAD_NUM];
} nbrEutraCellInfo_type;

typedef struct
{
    uint8_t isHoAllowed;
    uint8_t cellIndOffset;           /** enumEutraQOffsetRange **/
    int8_t eutraSmallCellCio;             /** enumEutraQOffsetRange **/
    int8_t cioDelta;                 /** -60..60 : YANG(cio-delta + cio-delta-hom) **/
    // int8_t cio;  // enumEutraQOffsetRange
    uint8_t isSmallCellPci;
    uint16_t pci;
    int rank;
    cgi_type cgi;
    uint16_t idx;
    qOffsetSSBRangeList_type nrSmallCellCio;  // enumQOffsetRange
    qOffsetSSBRangeList_type cellIndividualOffset;  // enumQOffsetRange
} cellsToMeasInfo_type;

typedef struct
{
    int cellIndex;
    int internalIndex;
} eutraCellsToMeasIndexInfo_type;

typedef struct
{
    uint8_t cellIndexEUTRA;
    uint16_t pci;
    uint8_t cellIndividualOffset;  // enumEutraQOffsetRange
} eutra_cell_type;

typedef struct
{
    uint8_t numItems;
    eutra_cell_type items[MAX_EUTRA_OF_CELLS_TO_MEASURE];
} cellsToMeasureListEutra_type;

typedef enum
{
    plmnOption_notDefined = -1,
    plmnOption_allowed = 0,
    plmnOption_notAllowed = 1
} plmnOption_type;

typedef enum
{
    serviceGroupOption_notDefined = -1,
    serviceGroupOption_allowed = 0,
    serviceGroupOption_notAllowed = 1
} serviceGroupOption_type;

typedef struct
{
    uint8_t usage;    // enumUsage_type
    uint8_t svcGrpId;
    int8_t  option;   // serviceGroupOption_type
} EndcServiceGroupEntries;

typedef struct
{
    uint8_t usage;     // enumUsage_type
    uint8_t plmnIndex;
    int8_t  option;    // plmnOption_type
    EndcServiceGroupEntries endcServiceGroupEntries[MAX_ENDC_SVCGRP_ID];
} PlmnSupportEntries;

typedef struct
{
    uint8_t usage;             // enumUsage_type
    uint8_t svcGrpId;
    int8_t  option;            // serviceGroupOption_type
    uint8_t freqPriorityForSa; // SVR25B FGR-MC1022 FR200
} ServiceGroupEntries;

/**
 * @brief Type used by meas-object-entries, meas-object-eutra-entries, report-config-entries.
 *
 */
typedef struct
{
    uint8_t notMatchedPlmnOption; // notMatchedPlmnOption_type
    PlmnSupportEntries plmn/*SupportEntries*/[MAX_PLMN_INDEX];
    ServiceGroupEntries serviceGroupEntries[MAX_SVC_GRP_DB_NUM];
} PlmnBasedControl;

typedef enum
{
    FallbackHandover_EventB1 = InterRatHandover_EventB1,
    FallbackHandover_EventB2 = InterRatHandover_EventB2,
    FallbackHandover_UsingInterRatHoEvent = 2  // For Emergency/EPS Fallback
} enumFallbackHandoverEventType;

typedef struct
{
    uint8_t usage;  // enumUsage_type

    uint32_t carrierFreq;  // store value from DB
    enumEutraAllowedMeasBandwidth_type allowedMeasBandwidth;
    uint8_t presenceAntennaPort1;        // BOOL
    enumEutraQOffsetRange qOffsetRange;  // optional, not use if eutraQOffsetRange_noUse
    uint8_t widebandRSRQMeas;            // BOOL

    enumInterRatHandoverEventType interRatHandoverEvent;
    uint8_t epsFallbackHandoverEvent;       // enumFallbackHandoverEventType // FGR-SV0201_26A
    uint8_t emergencyFallbackHandoverEvent; // enumFallbackHandoverEventType // FGR-SV0202_26A
    uint8_t voiceSupportFlag;              // BOOL
    uint8_t emergencyFallbackSupportFlag;  // BOOL
    freqBandEutraList_type freqBandIndicatorDbList;
    uint8_t moPriorityEutra;
    bool supportOnDemandMobility;  // ../gutran-cu-cell-entries/meas-object-eutra-entries // ODF_HO_21B
    enumTrafficBasedHandoverEventType trafficBasedHandoverEvent;
    uint16_t weightUeMeas;  // 0..1000
    uint32_t umfsMaxEutraCallCnt;
    uint32_t umfsCurrentEutraCallCnt;
    enumInterRatHandoverEventType loadBasedIratHandoverEvent; // ../gutran-cu-cell-entries/meas-object-eutra-entries
    int8_t smallCellPciListIndex; // -1 ~ (MAX_EUTRA_SMALLCELL_PCI_ENTRIES - 1) // SM_CELL_HO_23B
    bool supportForcedMobilityByUplinkStatusIndication; // FGR-MC1029 SVR25B
    enumInterRatPccChangeEvent_type interRatPccChangeEventType;
    bool overlappingFreqBandIndicatorPriority; // FGR-CC3201:FR42
} measurementObjectEUTRABaseDb_type;

typedef struct
{
    uint32_t carrierFreq;            // store value from DB
    uint32_t overlappedCarrierFreq;  // store mapped earfcn, used to fill RRC
    enumEutraAllowedMeasBandwidth_type allowedMeasBandwidth;
    uint8_t presenceAntennaPort1;        // BOOL
    enumEutraQOffsetRange qOffsetRange;  // optional, not use if eutraQOffsetRange_noUse
    uint8_t widebandRSRQMeas;            // BOOL
    int8_t smallCellPciListIndex; // -1 ~ (MAX_EUTRA_SMALLCELL_PCI_ENTRIES - 1)
} minimalMeasObjectEUTRAUe_type;

typedef struct
{
    minimalMeasObjectEUTRAUe_type minimal;
    cellsToMeasureListEutra_type cellsToMeasureEutra;
    blackCellsEutra_type blackCells;
} measurementObjectEUTRAUe_type;

typedef struct
{
    int8_t ratType;  // enumMeasRatType
    union
    {
        minimalMeasObjectNRUe_type nr;
        minimalMeasObjectEUTRAUe_type eutra;
    } rat;
} minimalMeasObjectConfUe_type;

typedef struct
{
    int8_t ratType;  // enumMeasRatType
    union
    {
        measurementObjectNRUe_type nr;
        measurementObjectEUTRAUe_type eutra;
    } rat;
} measurementObjectConfUe_type;

typedef struct
{
    uint8_t usage      :1; // enumUsage_type
    uint8_t isTainted  :1; // enumVccbFlag
    uint8_t pending    :1; // enumVccbFlag
    uint8_t reserved   :5;

    uint8_t internalIdx;
    uint8_t objectId;

    measurementObjectConfUe_type conf;
} measurementObjectUe_type;

typedef struct
{
    uint8_t rsrp : 1;  // enumUsage_type
    uint8_t rsrq : 1;  // enumUsage_type
    uint8_t sinr : 1;  // enumUsage_type
} reportQuantity_type;

typedef struct
{
    uint16_t cellForWhichToReportCGI;
    uint8_t useAutonomousGaps_flag;
} reportCgiReportConfiguration_type;

typedef struct
{
    uint8_t reportAddNeighMeas                       : 1;
} periodicalReportConfigurationNR_type;

typedef struct
{
    uint8_t drbListSize;
    uint8_t drbList[MAX_MDT_M6_UL_PDCP_DELAY_DRB];
} periodicalReportUlPdcpDelayDrb_type;

typedef struct
{
    uint8_t useWhiteCellList;
    uint8_t reportAddNeighMeas                       : 1;
    periodicalReportUlPdcpDelayDrb_type ulPdcpDelay;
} periodicalReportConfigurationNRUe_type;

typedef enum
{
    choice_rsrp_option = 0,
    choice_rsrq_option = 1,
} enumTriggeringOption_type;

typedef struct
{
    // enable when redCap leaf has the value
    uint8_t isValidRsrp : 1;
    uint8_t isValidRsrq : 1;
    uint8_t isValidSinr : 1;
    // update the confd value for redCap
    int8_t valueRsrp;
    int8_t valueRsrq;
    int8_t valueSinr;
} MeasQuantitiesRedCapValues_type;

typedef struct
{
    MeasQuantitiesRedCapValues_type th1_values;
    MeasQuantitiesRedCapValues_type th2_values;
} MeasDoubleQuantitiesRedCapValues_type;

typedef struct
{
    uint8_t triggeringOption;  // enumTriggeringOption_type
    bool isTriggeringOptionSinr;
} quantityInfo_type;

typedef struct
{
    quantityInfo_type quantityInfo;
    MeasQuantitiesValues_type values;
} measTriggerQuantitySetDb_type;

typedef struct
{
    quantityInfo_type quantityInfo;
    MeasQuantitiesValues_type th1_values;
    MeasQuantitiesValues_type th2_values;
} measDoubleTriggerQuantitySetDb_type;

typedef enum
{
    TriggeringCriteriaOption_offsetOnly = 0,
    TriggeringCriteriaOption_thresholdOnly = 1,
    TriggeringCriteriaOption_both = 2,
} enumTriggeringCriteriaOption_type;

typedef struct
{
    uint8_t option;  // enumTriggeringCriteriaOption_type
    int8_t thresholdRsrp;
    int8_t thresholdRsrq;
    int8_t thresholdSinr;
} callControlConfigurationDb_type;

typedef struct
{
    uint8_t option;  // enumTriggeringCriteriaOption_type
    int8_t thresholdRsrp;
    int8_t thresholdRsrq;
    int8_t thresholdSinr;
} callControlConfigurationUe_type;

typedef enum
{
    quantity_set_rsrp_rsrq = 0,
    quantity_set_rsrp_sinr = 1,
    quantity_set_rsrp_rsrq_sinr = 2
} enumQuantitySet_type;

typedef struct
{
    uint8_t addNeighMeas                       : 1;
    uint8_t multipleMeasurementQuantitySupport : 1;
    uint8_t timeToTriggerScalingFactor         : 2; //enumTimeToTriggerScalingFactor
    union
    {
        struct
        {
            MeasQuantitiesRedCapValues_type redCapThreshold;
        } A1;
        struct
        {
            enumQuantitySet_type multipleTriggerQuantitySet;
            bool multipleTriggerFeatureEnabled;
            MeasQuantitiesRedCapValues_type redCapThreshold;
            bool multipleTimeToTriggerEnabled;
            uint8_t timeToTriggerRsrp                           : 4;  // enumTimeToTrigger
            uint8_t timeToTriggerRsrq                           : 4;  // enumTimeToTrigger
            uint8_t timeToTriggerSinr                           : 4;  // enumTimeToTrigger
        } A2;
        struct
        {
            callControlConfigurationDb_type callControlCfg;
            MeasQuantitiesRedCapValues_type redCapOffset;
            MeasQuantitiesRedCapValues_type callControlRedCapThreshold;
        } A3;
        struct
        {
            MeasQuantitiesRedCapValues_type redCapThreshold;
            bool useAllowedCellList;
        } A4;

        struct
        {
            MeasDoubleQuantitiesRedCapValues_type redCapThresholds;
        } A5;
    } event;
} eventBasedReportConfigurationExtensionNR_type;

// NOTE: Put fields unrelated to ue-specific-report-config-entries into eventBasedReportConfigurationExtensionNR_type struct above.
typedef struct
{
    uint8_t reportOnLeave                      : 1;  // BOOL
    uint8_t hysteresis                         : 5;  // INTEGER (0..30)
    uint8_t timeToTrigger                      : 4;  // enumTimeToTrigger
    union
    {
        struct
        {
            measTriggerQuantitySetDb_type a1_Threshold;
        } A1;

        struct
        {
            measTriggerQuantitySetDb_type a2_Threshold;
        } A2;

        struct
        {
            measTriggerQuantitySetDb_type a3_Offset;
        } A3;

        struct
        {
            measTriggerQuantitySetDb_type a4_Threshold;
        } A4;

        struct
        {
            measDoubleTriggerQuantitySetDb_type a5_Thresholds;
        } A5;

        struct
        {
            measTriggerQuantitySetDb_type a6_Offset;
            callControlConfigurationDb_type callControlCfg;
        } A6;
    } event;
} eventBasedReportConfigurationNR_type;

typedef struct
{
    uint8_t quantity;  // enumMeasTriggerQuantityChoice
    int8_t value;
} measTriggerUe_type;

typedef struct
{
    uint8_t quantity;  // enumMeasTriggerQuantityChoice
    int8_t th1_value;
    int8_t th2_value;
} measDoubleTriggerUe_type;

typedef struct
{
    uint8_t addNeighMeas                       : 1;
    uint8_t useT312                            : 1;
    uint8_t multipleMeasurementQuantitySupport : 1;
    uint8_t reportOnLeave                      : 1;  // BOOL
    uint8_t hysteresis                         : 5;  // INTEGER (0..30)
    uint8_t timeToTrigger                      : 4;  // enumTimeToTrigger
    union
    {
        struct
        {
            measTriggerUe_type a1_Threshold;
            measTriggerQuantitySetDb_type a1_ThresholdOrigin;
        } A1;

        struct
        {
            measTriggerUe_type a2_Threshold;
            measTriggerQuantitySetDb_type a2_ThresholdOrigin;
            bool multipleTriggerQuantityEnabled;
        } A2;

        struct
        {
            measTriggerUe_type a3_Offset;
            measTriggerQuantitySetDb_type a3_OffsetOrigin;
            callControlConfigurationUe_type callControlCfg;
        } A3;

        struct
        {
            measTriggerUe_type a4_Threshold;
            measTriggerQuantitySetDb_type a4_ThresholdOrigin;
            bool useAllowedCellList;
        } A4;

        struct
        {
            measDoubleTriggerUe_type a5_Thresholds;
            measDoubleTriggerQuantitySetDb_type a5_ThresholdsOrigin;
        } A5;

        struct
        {
            measTriggerUe_type a6_Offset;
            measTriggerQuantitySetDb_type a6_OffsetOrigin;
            callControlConfigurationUe_type callControlCfg;
        } A6;
    } event;
} eventBasedReportConfigurationNRUe_type;

typedef struct
{
    uint8_t timeToTriggerScalingFactor : 2; //enumTimeToTriggerScalingFactor
    union
    {
        struct
        {
            MeasQuantitiesRedCapValues_type redCapThreshold;
        } B1Eutra;

        struct
        {
            MeasDoubleQuantitiesRedCapValues_type redCapThresholds;
        } B2Eutra;
    } event;
    uint8_t mgrpPreference;
} eventBasedReportConfigurationExtensionInterRat_type;

// NOTE: Put fields unrelated to ue-specific-report-config-interrat-entries into eventBasedReportConfigurationExtensionInterRat_type struct above.
typedef struct
{
    uint8_t multipleMeasurementQuantitySupport : 1;
    uint8_t reportOnLeave                      : 1;  // BOOL
    uint8_t hysteresis                         : 5;  // INTEGER (0..30)
    uint8_t timeToTrigger                      : 4;  // enumTimeToTrigger
    union
    {
        struct
        {
            measTriggerQuantitySetDb_type b1_thresholdEUTRA;
        } B1Eutra;

        struct
        {
            measDoubleTriggerQuantitySetDb_type b2_thresholds;
        } B2Eutra;
    } event;
} eventBasedReportConfigurationInterRat_type;

typedef struct
{
    uint8_t multipleMeasurementQuantitySupport : 1;
    uint8_t reportOnLeave                      : 1;  // BOOL
    uint8_t hysteresis                         : 5;  // INTEGER (0..30)
    uint8_t timeToTrigger                      : 4;  // enumTimeToTrigger
    uint8_t mgrpPreference;
    union
    {
        struct
        {
            measTriggerUe_type b1_thresholdEUTRA;
            measTriggerQuantitySetDb_type b1_thresholdEUTRAOrigin;
        } B1Eutra;

        struct
        {
            measDoubleTriggerUe_type b2_thresholds;
            measDoubleTriggerQuantitySetDb_type b2_thresholdsOrigin;
        } B2Eutra;
    } event;
} eventBasedReportConfigurationInterRatUe_type;

typedef struct
{
    struct
    {
        uint8_t usage : 1;  // enumUsage_type
        reportQuantity_type reportQuantity;
    } reportQuantityRsIndexes;
    struct
    {
        uint8_t usage : 1;  // enumUsage_type
        uint8_t value : 6;  // INTEGER (1..32)
    } maxNrOfRsIndexesToReport;
    uint8_t includeBeamMeasurements       : 1;  // BOOLEAN
    uint8_t includeCommonLocationInfo_r16 : 1;  // ENUMERATED {true}
} reportConfigNRConfigSpec_type;

typedef union
{
    reportConfigNRConfigSpec_type nr;
} reportConfigConfigSpec_type;

typedef union
{
    reportCgiReportConfiguration_type reportCgi;
    periodicalReportConfigurationNR_type periodical;
    eventBasedReportConfigurationNR_type eventBased;
    reportCgiReportConfiguration_type reportCgiEutra;
    eventBasedReportConfigurationInterRat_type eventInterRat;
    periodicalReportConfigurationInterRat_type periodicalInterRat;
} reportConfigurationReportType_type;

typedef union
{
    eventBasedReportConfigurationExtensionNR_type eventBased;
    eventBasedReportConfigurationExtensionInterRat_type eventInterRat;
} reportConfigurationReportTypeExtension_type;

typedef union
{
    reportCgiReportConfiguration_type reportCgi;
    periodicalReportConfigurationNRUe_type periodical;
    eventBasedReportConfigurationNRUe_type eventBased;
    reportCgiReportConfiguration_type reportCgiEutra;
    eventBasedReportConfigurationInterRatUe_type eventInterRat;
    periodicalReportConfigurationInterRat_type periodicalInterRat;
} reportConfigUe_type;

typedef struct
{
    uint8_t usage;  // enumUsage_type
    uint8_t reportType;  // enumMeasurementReportType
    uint8_t reportPurpose;
    uint8_t useT312;
    uint8_t rsType;                 // enumRSType
    uint8_t reportInterval;         // enumReportInterval
    uint8_t reportAmount;           // enumReportAmount
    uint8_t reportAmountNrppa;      // enumReportAmount
    uint8_t reportAmountNrppaIrat;  // enumReportAmount
    reportQuantity_type reportQuantityCell;
    uint8_t maxReportCells;

    reportConfigConfigSpec_type rat;
    reportConfigurationReportType_type reportConfiguration;
    reportConfigurationReportTypeExtension_type reportConfigExtension;

    uint32_t measObjectSelection;  // bitmask: for which MeasObj this report is configured
} reportConfigurationBaseDb_type;

typedef struct
{
    bool usage;
    int8_t delta;
} optionalDelta_type;

typedef struct
{
    // for A1, A2, A3, A4, A5 th1, B2 th1
    optionalDelta_type trigger1Delta;
    // for A5 th2
    optionalDelta_type trigger2Delta;
} optionalDeltaPerTrigger_type;

typedef struct
{
    optionalDeltaPerTrigger_type pc1SavedDelta;
    optionalDeltaPerTrigger_type pc15SavedDelta;
    optionalDeltaPerTrigger_type pc2SavedDelta;
} fr1PowerClassSavedDeltas_type;

typedef struct
{
    fr1PowerClassSavedDeltas_type savedDeltas;
    bool isAssociatedWithPcellMeasObject;
} fr1PowerClassState_type;

typedef struct
{
    uint8_t reportType;  // enumMeasurementReportType
    uint8_t reportPurpose;
    uint8_t rsType;          // enumRSType
    uint8_t reportInterval;  // enumReportInterval
    uint8_t reportAmount;    // enumReportAmount
    uint8_t maxReportCells;
    reportQuantity_type reportQuantityCell;
    reportConfigConfigSpec_type rat;
    reportConfigUe_type reportConfiguration;
    fr1PowerClassState_type fr1PCState;

    uint32_t measObjectSelection;  // bitmask: for which MeasObj this report is configured
} reportConfigurationConfUe_type;

typedef struct
{
    uint8_t usage      :1; // enumUsage_type
    uint8_t isTainted  :1; // enumVccbFlag
    uint8_t pending    :1; // enumVccbFlag
    uint8_t reserved   :5;

    uint8_t internalIdx;
    uint8_t objectId;

    reportConfigurationConfUe_type conf;
} reportConfigurationInstalledUe_type;

typedef struct
{
    uint8_t usage      :1; // enumUsage_type
    uint8_t isTainted  :1; // enumVccbFlag
    uint8_t pending    :1; // enumVccbFlag
    uint8_t reserved   :5;

    uint8_t internalIdx;
    uint8_t objectId;

    reportConfigurationConfUe_type conf;
} reportConfigurationNewUe_type;

typedef struct
{
    bool doesMeasIdExpired;      // indicate that UE removes meas id related to periodical report config as it expired
    uint8_t numberOfReportsSent; // count of Measurement Report corelated with meas id
} measReportAdditionalInfo_type;

struct callInfo_s;
struct NRRRC_MeasurementReport;
typedef int16_t (*measReportCallback_type)(struct callInfo_s *ptCi, struct NRRRC_MeasurementReport *ptMsg,
    measurementObjectUe_type *pMeasObj, const reportConfigurationInstalledUe_type *pReportConfig, measReportAdditionalInfo_type* measurementReportInfo);

typedef struct
{
    uint8_t usage      :1; // enumUsage_type
    uint8_t isTainted  :1; // enumVccbFlag
    uint8_t pending    :1; // enumVccbFlag
    uint8_t reserved   :5;
    uint8_t internalIdx;

    uint8_t objectId;
    uint8_t measObjectId;
    uint8_t moNewItemIdx;
    uint8_t reportConfigId;
    uint8_t rcNewItemIdx;
    uint8_t numberOfReportsSent;  // 0..64, applies only for reportType periodical or cli-Periodical
    enumMeasReportCallbackId_type callbackFuncId;
} measurementIdentity_type;

typedef struct
{
    uint8_t usage;   // enumUsage_type
    uint8_t choice;  // enumSMeasureChoice
    uint8_t value;
} sMeasure_type;

typedef struct
{
    uint8_t filterCoefficientRSRP : 4;  // enumFilterCoefficient
    uint8_t filterCoefficientRSRQ : 4;  // enumFilterCoefficient
    uint8_t filterCoefficientSINR : 4;  // enumFilterCoefficient
} filterConfig_type;

typedef struct
{
    uint8_t usage : 1;  // enumUsage_type

    filterConfig_type ssbFilterConfig;
    filterConfig_type csRsFilterConfig;
} quantityConfigRS_type;

typedef struct
{
    uint8_t usage : 1;  // enumUsage_type

    quantityConfigRS_type quantityConfigCell;
    quantityConfigRS_type quantityConfigRS_Index;
} quantityConfigurationNR_type;

typedef struct
{
    uint8_t usage;  // enumUsage_type

    filterConfig_type filterConfig;
} quantityConfigurationEUTRA_type;

typedef struct
{
    quantityConfigurationNR_type nr[MAX_NR_OF_QUANTITY_CONFIG];
    quantityConfigurationEUTRA_type eutra;
} quantityConfiguration_type;

typedef struct maxPriorityFreqForRedir_s
{
    uint8_t maxPriority;
    uint8_t maxPriorityNum;
    uint16_t maxPriorityListIdx[MAX_NR_OF_OBJECT_ID_DB];
} maxPriorityFreqForRedir_type;

typedef struct
{
    uint8_t usage;
    uint8_t measObjIdx;
    int8_t a1InterFreqMeasDeactivationThresholdDelta;
    int8_t a2InterFreqMeasActivationThresholdDelta;
    int8_t a2PscellReleaseThresholdDelta;
    int8_t a3PscellChangeOffsetDelta;
    int8_t a3SpidInterFreqPscellChangeOffsetDelta;
    int8_t a4PscellChangeThresholdDelta;
    int8_t a4SpidInterFreqPscellChangeThresholDelta;
    int8_t a5PscellChangeThreshold1Delta;
    int8_t a5PscellChangeThreshold2Delta;
    int8_t a5SpidInterFreqPscellChangeThreshol1Delta;
    int8_t a5SpidInterFreqPscellChangeThreshol2Delta;
    int8_t a5PscellChangeDuIndicationTh1Delta; // FGR-CC5001 FR110
    int8_t a5PscellChangeDuIndicationTh2Delta; // FGR-CC5001 FR110
    int8_t a5PscellChangeUlStatusIndBadUlQualityTh1Delta; // FGR-CC5001 FR110
    int8_t a5PscellChangeUlStatusIndBadUlQualityTh2Delta; // FGR-CC5001 FR110
    int8_t a5PscellChangeUlStatusIndTddInterferenceTh1Delta; // FGR-CC5001 FR110
    int8_t a5PscellChangeUlStatusIndTddInterferenceTh2Delta; // FGR-CC5001 FR110
} mobilityMeasurementDelta_type;

typedef struct
{
    struct
    {
        uint8_t usage;
        struct
        {
            uint8_t usage;
            int8_t a2SpidReleaseThresholdOffset;
            mobilityMeasurementDelta_type measObjEntries[MAX_NR_OF_SPEC_MEAS_MO_INDEXES];
        } spidEntries[MAX_SPID_VALUE];
    } plmnEntries[MAX_PLMN_INDEX];
} specMeasConfig_type;

typedef struct
{
    uint8_t moPriority;
    uint8_t freqPriorityForSa;
    uint8_t freqPriorityForEndc;
    uint8_t spidFreqPriorityForEndc[MAX_SPID_VALUE];
    uint8_t spidInterFreqNrPSCellChangeEvent[MAX_SPID_VALUE];
    uint8_t fpInterFreqPscellChangeEvent;
    uint8_t redirFreqPriority       : 3; // 0..7
} plmnSupportEntriesMeasObjectNRSpecific_type;

typedef struct
{
    PlmnBasedControl plmnBasedControl;
    plmnSupportEntriesMeasObjectNRSpecific_type plmnSpecific[MAX_PLMN_INDEX];
} measurementObjectNRExtensionDb_type;

typedef struct
{
    uint8_t moPriorityEutra;
} plmnSupportEntriesMeasObjectEUTRASpecific_type;

typedef struct
{
    PlmnBasedControl plmnBasedControl;
    plmnSupportEntriesMeasObjectEUTRASpecific_type plmnSpecific[MAX_PLMN_INDEX];
} measurementObjectEUTRAExtensionDb_type;

typedef struct
{
    PlmnBasedControl plmnBasedControl;
} reportConfigurationExtensionDb_type;

typedef struct
{
    measurementObjectNRBaseDb_type base;
    measurementObjectNRExtensionDb_type extension;
} measurementObjectNRDb_type;

typedef struct
{
    measurementObjectEUTRABaseDb_type base;
    measurementObjectEUTRAExtensionDb_type extension;
} measurementObjectEUTRADb_type;

typedef struct
{
    reportConfigurationBaseDb_type base;
    reportConfigurationExtensionDb_type extension;
} reportConfigurationDb_type;

typedef struct
{
    uint16_t spidDefaultEndcIdx;
    uint16_t spidEndcIdx[MAX_SPID_VALUE];
} measurementObjectBlacklistCells_SpidRefs_type;

typedef struct
{
    uint16_t rfspDefaultSaIdx;
    uint16_t rfspSaIdx[MAX_RFSP_VALUE];
} measurementObjectBlacklistCells_RfspRefs_type;

typedef struct
{
    uint8_t usage;
    uint32_t ssbFreq;
    blackCellsElementDb_type blacklistCells[MAX_NR_OF_PCI_RANGES];
} measurementObjectBlacklistCells_Set_PerSsbFreq_type;

typedef struct
{
    uint8_t usage;
    measurementObjectBlacklistCells_Set_PerSsbFreq_type blacklistCellsPerSsbFreq[MAX_NR_OF_OBJECT_ID_DB];
} measurementObjectBlacklistCells_Set_type;

typedef struct
{
    uint8_t usage;  // enumUsage_type
    uint32_t carrierFreq;
    blackCellsEutraDb_type blacklistCells[MAX_CELL_MEAS_EUTRA];
} measurementObjectBlacklistCells_Set_PerCarrierFreq_type;

typedef struct
{
    measurementObjectBlacklistCells_Set_PerCarrierFreq_type blacklistCellsPerCarrierFreq[MAX_NR_OF_OBJECTEUTRA_ID_DB];
} measurementObjectBlacklistCells_Set_Eutra_type;

typedef enum
{
    moBlacklistCellsSaPreferredOption_followServiceGroup = 0,
    moBlacklistCellsSaPreferredOption_followRfsp = 1
} enumMoBlacklistCellsSaPreferredOption_type;

typedef struct
{
    uint8_t usage;
    uint8_t saPreferredOption; // enumMoBlacklistCellsSaPreferredOption_type
    measurementObjectBlacklistCells_SpidRefs_type spidRefs;
    measurementObjectBlacklistCells_RfspRefs_type rfspRefs;
} measurementObjectBlacklistCells_PlmnSupportEntry_type;

typedef struct
{
    uint16_t saIdx;
    uint8_t usage;
    uint8_t priority;
} measurementObjectBlacklistCells_ServiceGroupRefs_Entry_type;

typedef struct
{
    measurementObjectBlacklistCells_ServiceGroupRefs_Entry_type entries[MAX_SVC_GRP_DB_NUM];
} measurementObjectBlacklistCells_ServiceGroupConfig_type;

typedef struct
{
    struct
    {
        uint16_t defaultEndcIdx;
        uint16_t defaultSaIdx;
        measurementObjectBlacklistCells_PlmnSupportEntry_type plmnSupportEntries[MAX_PLMN_INDEX];
        measurementObjectBlacklistCells_ServiceGroupConfig_type serviceGroupConfig;
    } refs;

    measurementObjectBlacklistCells_Set_type endcBlacklistCellsSets[MAX_NR_OF_ENDC_BLACKLIST_CELLS_SETS];
    measurementObjectBlacklistCells_Set_type saBlacklistCellsSets[MAX_NR_OF_SA_BLACKLIST_CELLS_SETS];
    measurementObjectBlacklistCells_Set_Eutra_type eutraBlacklistCellsSet;
} measurementObjectBlacklistCells_type;

typedef struct
{
    struct ueReportConfig_s
    {
        bool allowedSvcGrpId[MAX_SVC_GRP_DB_NUM];
    } ueReportConfig;

    struct ueReportConfigEndc_s
    {
        struct
        {
            struct
            {
                uint8_t isAllowed;
            } svcGrp[MAX_ENDC_SVCGRP_ID];
        } plmn[MAX_PLMN_INDEX];
    } ueReportConfigEndc;

} ueReportConfigurationExtensionDb_type;

typedef struct
{
    reportConfigurationBaseDb_type base;
    ueReportConfigurationExtensionDb_type extension;
} ueReportConfigurationDb_type;

typedef struct
{
    measurementObjectNRDb_type measurementObjectsNRDb[MAX_NR_OF_OBJECT_ID_DB];
    measurementObjectEUTRADb_type measurementObjectsEUTRADb[MAX_NR_OF_OBJECTEUTRA_ID_DB];
    reportConfigurationDb_type reportConfigurationsDb[MAX_NR_OF_REPORT_CONFIG_ID_DB];
    reportConfigurationDb_type
        reportConfigInterRatDb[MAX_NR_OF_REPORT_CONFIGIR_ID_DB];  // MAX_NR_OF_REPORT_CONFIG_ID_DB
    sMeasure_type sMeasureConfig;
    quantityConfigurationNR_type quantityConfigurations[MAX_NR_OF_QUANTITY_CONFIG];
    quantityConfigurationEUTRA_type quantityConfigurationEUTRA;

    // ue specific report config DB
    ueReportConfigurationDb_type ueSpecificReportConfigurations[MAX_NR_OF_REPORT_CONFIG_ID_DB]
                                                               [MAX_NR_UE_SPECIFIC_REPORT_CONFIG_DB];
    ueReportConfigurationDb_type ueSpecificReportConfigInterRat[MAX_NR_OF_REPORT_CONFIGIR_ID_DB]
                                                               [MAX_NR_UE_SPECIFIC_REPORT_CONFIG_DB];
    smtc1_type smtc1ConfigurableIntraFreq;
    specMeasConfig_type specMeasConfig;
    measurementObjectBlacklistCells_type measObjectBlacklistCells;
    uint64_t mgrpPrefIRatBtmsk;
} measurementsData_type;

typedef struct
{
    uint8_t nrofPLMN_Identity;
    plmnId_type plmn_Identity[MAX_NUM_PLMN];
} PLMN_IdentityList_type;

typedef struct
{
    uint8_t trackingAreaCodeFlag;
    uint8_t ranacFlag;
    uint8_t gnbIdLengthFlag;

    uint8_t ranac;                       // INTEGER (0..255)
    uint8_t cellReservedForOperatorUse;  // ENUMERATED {reserved, notReserved}
    uint16_t gnbIdLength;                // INTEGER (22..32)
    uint32_t trackingAreaCode;           // BIT STRING (SIZE (24))
    uint64_t cellIdentity;               // BIT STRING (SIZE (36))
    PLMN_IdentityList_type plmn_IdentityList;
} PLMN_IdentityInfo_type;

typedef struct
{
    uint8_t nrofPLMN_IdentityInfo;
    PLMN_IdentityInfo_type plmn_IdentityInfo[MAX_NUM_PLMN];
} PLMN_IdentityInfoList_type;

typedef struct
{
    uint8_t cellBarred;  // NRRRC_barred = 0, NRRRC_notBarred = 1

} mibInfoCu_type;

typedef struct
{
    uint32_t               cag_Identity;                  // BIT STRING (SIZE (32))
    uint8_t                manualCAGselectionAllowedFlag; // set TRUE when manualCAGselectionAllowed is valid
    uint8_t                manualCAGselectionAllowed;     // NRRRC_true = 0
} CAG_IdentityInfo_type;

typedef struct
{
    uint8_t                nrofCAG_IdentityInfo; // 1..maxNPN-r16(12)
    CAG_IdentityInfo_type  cag_IdentityInfo[MAX_NUM_NRRRC_NPN];
} CAG_IdentityList_type;

typedef struct
{
    uint8_t                nrofNID;
    uint64_t               nid[MAX_NUM_NRRRC_NPN]; // NID-r16 ::= BIT STRING (SIZE (44))
} NID_List_type;

typedef struct
{
    uint8_t choice; // NRRRC_pni_npn_r16_chosen 1, NRRRC_snpn_r16_chosen 2
    union
    {
        CAG_IdentityList_type  cac_IdentityList;
        NID_List_type          nidList;           // Currently Not Support
    };
    plmnId_type     plmn_Identity;
} npnIdentity_type;

typedef struct
{
    uint8_t          nrofNPN_Identity; // 1..maxNPN-r16(12)
    npnIdentity_type npn_Identity[MAX_NUM_NRRRC_NPN];
} NPN_IdentityList_type;

typedef struct
{
    uint8_t ranacFlag;                   // set TRUE when ranac is valid
    uint8_t gnbIdLengthFlag;             // set TRUE when gnbIdLength is valid

    uint8_t ranac;                       // Optional. INTEGER (0..255)
    uint8_t cellReservedForOperatorUse;  // Mandatory. ENUMERATED {reserved, notReserved}

    uint16_t gnbIdLength;                // Optional. INTEGER (22..32)
    uint32_t trackingAreaCode;           // Mandatory. BIT STRING (SIZE (24))
    uint64_t cellIdentity;               // Mandatory. BIT STRING (SIZE (36))

    NPN_IdentityList_type npn_IdentityList; // 1..maxNPN-r16(12)
} NPN_IdentityInfo_type;

typedef struct
{
    uint8_t               nrofNPN_IdentityInfo;  // 0..maxNPN-r16(12)
    NPN_IdentityInfo_type npn_IdentityInfo[MAX_NUM_NRRRC_NPN];
} NPN_IdentityInfoList_type;

typedef struct
{
    uint8_t cellReservedForOtherUseFlag  : 1;
    uint8_t cellReservedForFutureUseFlag : 1;
    uint8_t reserved1                    : 6;

    PLMN_IdentityInfoList_type plmn_IdentityInfoList;
    NPN_IdentityInfoList_type  npn_IdentityInfoList;  // Optional
    uint8_t cellReservedForOtherUse  : 1;  // NRRRC_true = 0
    uint8_t cellReservedForFutureUse : 1;  // NRRRC_true = 0
    uint8_t isNpnOnlyCell            : 1;  // TRUE/FALSE
    uint8_t isCagCell                : 1;  // TRUE/FALSE
    uint8_t reserved2                : 4;

    uint32_t sib1Size;
    uint8_t sib1Data[MAX_F1_DU_SYSTEM_INFO_SIB1];

} sib1Info_type;

/**
 * @brief enum to describe Overload Alarm State
 */
typedef enum
{
    DRX_OFF = 0, /**< DRX OFF */
    DRX_ON       /**< DRX ON*/
} drxState_t;

typedef enum
{
    REPORTCGI_OFF = 0,
    REPORTCGI_FR1_ON,
    REPORTCGI_FR2_ON, /* only support FR1 in 21D*/
    REPORTCGI_FR1_FR2_ON
} reportCgiSwitch_type;

// FGS-SF0502 FR240, FR243 - container invalid-ncr-condition
typedef struct
{
    uint8_t outOfService        : 1; // Intra-gNB only
    uint8_t cellNotAvail        : 1;
    uint8_t unknownTgtId        : 1;
    uint8_t hoFailInTgt5GcNgran : 1;
    uint8_t hoPrepFailTimeOut   : 1;
} invalidNcrNotiConfig_type;

typedef struct
{
    invalidNcrNotiConfig_type invalidNcrCondition;
} anrGnbInfo_type;

typedef struct
{
    invalidNcrNotiConfig_type invalidEutraNcrCondition;
} iratAnrGnbInfo_type;

typedef struct
{
    uint8_t eutraReportCgiGbrSwitch; // 24B reportCgiGbrSwitch_type
    uint8_t epsFallbackMrSwitch; // enum-off-on; (SF0503)
    uint16_t anrSwitch;
    uint16_t eutraReportCgiSwitch;
    uint16_t eutraReportCgiNedcSwitch;
    uint16_t eutraReportCgiNrdcSwitch;
    uint16_t eutraAutonomousGapsSwitch;
    uint16_t eutraMobilityMrSwitch;
    uint16_t nedcAdditionMrSwitch;
    uint16_t ueBasedAnrSwitch;
    uint16_t longDrxCycle;
    uint16_t longDrxCycleGbr;
    uint8_t eutraNcrAddSchedUsageSwitch; // SVR25A FGS-SF0503 FR75
    uint8_t underusedNcrDeleteSwitch; // 25A FR170
    uint8_t invalidNcrDeleteSwitch; // 25A FR180
} iratAnrCellInfo_type;

typedef enum
{
    MEAS_TH_DISABLE = 0,
    MEAS_TH_RSRP,
    MEAS_TH_RSRQ
} measThreshold_type;

typedef struct
{
    uint8_t caMrSwitch;
    uint8_t underusedNcrDeleteSwitch; // SVR25A FR230
    uint8_t invalidNcrDeleteSwitch;
    uint8_t reportCgiGbrSwitch; // SVR24B FGS-SF0502 FR192, FR193, reportCgiGbrSwitch_type
    uint8_t ncrAddSchedUsageSwitch; // SVR25A FGS-SF0502 FR55
    uint16_t anrSwitch;
    reportCgiSwitch_type reportCgiSwitch;
    reportCgiSwitch_type reportCgiEndcSwitch;
    reportCgiSwitch_type reportCgiNrdcSwitch;
    reportCgiSwitch_type reportCgiNedcSwitch;
    uint16_t rreSwitch;
    uint16_t ueBasedAnrSwitch;
    uint16_t mnsSwitch;
    uint16_t mobilityMrSwitch;
    uint16_t nrdcAdditionMrSwitch;
    uint16_t autonomousGapsSwitch;
    uint16_t longDrxCycleFr1;
    uint16_t longDrxCycleFr2;
    uint16_t longDrxCycleFr1Gbr; // SVR24B FGS-SF0502 FR192, FR193
    uint16_t longDrxCycleFr2Gbr; // SVR24B FGS-SF0502 FR192, FR193
} anrCellInfo_type;

#define ANR_MNS_MAX_WEEK_DAY 7

typedef struct
{
    uint8_t hour;
    uint8_t duration;
    uint8_t schedule[ANR_MNS_MAX_WEEK_DAY];
} anrSchedule_type;

typedef struct
{
    uint8_t usage;
    uint16_t pci;
    uint32_t freq;
    time_t collectedTime;
} measPciInfo_type;

typedef struct
{
    union // 24B refactoring
    {
        struct
        {
            uint32_t reportCgiFlag        : 1;
            uint32_t reportCgiSnFlag      : 1;  // MN-SN Coordination, used only in MN
            uint32_t reportCgiDuplPci     : 1;
            uint32_t reportCgiNonNeighbor : 1;
            uint32_t autonomousGapsFlag   : 1;
            // [SVR23B] FR112.CACP.SR1.HD1.VCCB.DD3
            uint32_t rcvModRefuseFlag : 1;  // received X2_SgNBModificationRefuse
            uint32_t longDrxStatus    : 1;  // received X2_SgNBModificationRefuse
            uint32_t reportCgiFailByT321 : 1;
            uint32_t reportCgiFailByInvalidCgi  : 1;
        };
        uint32_t clearFlag;
    };
} reportCgiInfo_type;

typedef struct
{
    reportCgiInfo_type reportCgi;
    uint8_t ratType;  // enumAnrObjType :: nrType, eutraType
    uint8_t mrType;   // enumAnrMrType
    uint8_t reportType;     // SVR24B FGR-MC1007 FR391 enumMeasurementReportType
    uint8_t reportPurpose;  // SVR24B FGR-MC1007 FR391 enumB1Purpose enumB2Purpose
    uint8_t reportConfigQuantitySaHo; /* RSRP(choice_rsrp) / RSRQ(choice_rsrq) / SINR(choice_sinr) / 0xFF */
    uint16_t pci;
    uint16_t rsType;
    uint16_t longDrxValue;
    uint16_t servCellId;
    uint32_t freq;  // ssbFreq, earfcnDl
    uint8_t anrGbrUe;
    uint8_t reportCgiStatCollectRequired; // 26A NCGI Stat Collect Required
    uint8_t reportCgiTgtFreqType; // 26A enumNcgiReportTgtFreq_type
    timerInfo_type reportCgiTimer;  // T321
    timerInfo_type refuseRetryTimer;  // refuseRetryTimer
    measPciInfo_type nrMeasPciStatInfo[MAX_NR_OF_OBJECT_ID_DB];
    measPciInfo_type nrMeasMrCountInfo[MAX_NR_OF_OBJECT_ID_DB]; // SVR24B FGS-SF0502 FR234
    measPciInfo_type eutraMeasPciStatInfo[MAX_NR_OF_OBJECTEUTRA_ID_DB]; // SVR24B FGS-SF0503 FR500
    measPciInfo_type eutraMeasMrCountInfo[MAX_NR_OF_OBJECTEUTRA_ID_DB]; // SVR24B FGS-SF0503 FR172
} anrUeInfo_type;

// START OF UPM
#define MAX_VISITED_CELL_STAY_TIME_FOR_NR 45600
#define MAX_PINGPONG_HO_NBR               NG_MaxnoofCellsinUEHistoryInfo / 2

typedef enum
{
    E_UPM_Algorism,
    E_UPM_Statistics,
    E_MAX_OF_UPM_TYPE
} enumUpmProc_type;

typedef struct
{
    uint8_t rat;  // enumRAT_type
    uint8_t reserved[3];
    cgi_type cgi;
} upmCgi_type;

typedef struct
{
    // UPM Parameter
    uint8_t nbrCioMinUsage; /* ON(1) or OFF(0) : YANG(upm-stat-check-switch) */
    uint8_t upmSwitch;      /* ON(1) or OFF(0) */
    uint16_t hoTimeWindow;  /* 1 ... 4095 */

    uint8_t hoCount;          /* 1 ... 8 */
    uint8_t maxCioReduction;  /* 1 ... 30 */
    uint8_t cioInitialOffset; /* 0 ... 30 */
    uint8_t cioWeight;        /* 0 ... 30 */

    float hoTimer; /* 0.0 ... 100.0 */

} upmCellInfo_type;

typedef struct
{
    cgi_type cgi;              /* NRCGI Only - UPM Ping Poing Cell */
    uint8_t status        : 1; /* ON(1) or OFF(0) : Usage Of upmPingPongNbr_type */
    uint8_t cioUsage      : 1; /* ON(1) or OFF(0) : Usage Of cioOffset in upmPingPongNbr_type */
    uint8_t numPingPongHO : 6; /* 0 ... 63, but it is smaller than MAX_PINGPONG_HO_NBR. */
    uint8_t cioOffset;         /* 0 .. 30 */
    uint8_t reserved[2];       /* reserved */
} upmPingPongNbr_type;

typedef struct
{
    cgi_type targetCgi;      // NRCGI Only - UPM Service Cell
    uint16_t targetCellNum;  // NR CELL - UPM Service Cell
    uint8_t usage :1;
    uint8_t reserved;
    upmPingPongNbr_type nbr[MAX_PINGPONG_HO_NBR];
} upmAlgoInfoForCall_type;

typedef struct
{
    cgi_type targetCgi;  // NRCGI Only
    uint8_t upmStatFlag;
    uint8_t numPingPongHO;
    uint16_t upmStoreCellNum;
} upmStatInfoForCall_type;

typedef struct
{
    upmAlgoInfoForCall_type upmAlgoInfoInstalled;
    upmAlgoInfoForCall_type upmAlgoInfoNew;
    upmStatInfoForCall_type upmStatInfo;
} upmCallInfo_type;
// END OF UPM

typedef struct
{
    uint8_t ueMeasSchedule         : 1;  // OFF(0) / ON(1)
    uint8_t measUeTypeSetupRrc     : 2;  // OFF(0) / ON(1)
    uint8_t measUeTypeChangePscell : 1;  // OFF(0) / ON(1)
    uint8_t measUeTypeHandIn       : 1;  // OFF(0) / ON(1)
    uint8_t measHistogram          : 2;  // OFF(0) / ON(1)
    uint8_t measHistogramEutra     : 1;  // OFF(0) / ON(1)
    uint8_t measFaAutoUpdateSwitch : 1;  // OFF(0) / ON(1)
    uint8_t measThresholdLevelLb   : 1;  // cell(0) / cell-freq(1)

    uint8_t measUeTypeSetupDc[MAX_NR_LBM_CELL_CONFIGS]; // enumUmfsSetupDc_type
    uint8_t ueMeasTriggerThreshold;                 // 0..100
    uint8_t ueMeasRateNr[MAX_NR_LBM_CELL_CONFIGS];  // 0..100
    uint8_t ueMeasRateCbrs;                         // 0..100
    uint8_t ueMeasRateEutra;                        // 0..100
    uint16_t maxNrMeasHourly;                       // 0..1000
    uint16_t maxCbrsMeasHourly;                     // 0..1000
    uint16_t maxEutraMeasHourly;                    // 0..1000

    uint8_t measThresholdTypeLb;       // enumMeasThresholdTypeLb_type
    uint8_t measThresholdTypeAnr;      // enumMeasThresholdTypeAnr_type
    uint8_t measThresholdTypeIratAnr;  // enumMeasThresholdTypeAnr_type

    uint8_t measThresholdTypeIratEutraEs;       // enumMeasThresholdTypeIratEutraEs_type
    uint8_t measRsrpThresholdTypeIratEutraEs;   // 0..97
    uint8_t measRsrqThresholdTypeIratEutraEs;   // 0..34

    uint8_t measThresholdTypeCa;       // enumMeasThresholdTypeCa_type
    uint8_t measRsrpThresholdTypeCa;
    uint8_t measThresholdTypeCbrs;  // enumMeasThresholdTypeCbrs_type
    uint8_t measThresholdTypeFac;   // enumMeasThresholdTypeFac_type

    uint8_t measRsrpThresholdLb;    // 0 ~ 127
    uint8_t measRsrqThresholdLb;    // 0 ~ 127
    uint8_t measRsrpThresholdCbrs;  // 0 ~ 127

    int16_t measRsrpOffsetAnr;         // -30 ~ 30
    int16_t measRsrqOffsetAnr;         // -30 ~ 30
    int16_t measRsrpThresholdAnr;      // 0 ~ 127
    int16_t measRsrqThresholdAnr;      // 0 ~ 127
    uint8_t measRsrpThresholdIratAnr;  // 0 ~ 97
    uint8_t measRsrqThresholdIratAnr;  // 0 ~ 34
} measColocCellInfo_type;

typedef struct
{
    uint8_t measRateNR;
    uint8_t measRateCBRS;
    uint8_t measRateEUTRA;
} correctedNormalizedMeasRates_type;

typedef struct
{  // ODF_HO_21B
    bool onDemandHoSupport;
    bool includeEmergHpaOnOff;     // bool, TRUE = 1 ODF_HO_22C2_DISH
    bool includeMpsCall;            // SVR26B FR54
    enumEmergHpaModeForOnDemandMobility_type emergHpaMode; // ODF_HO_25A
    enumOpModeForOnDemandMobility_type operationMode;
    enumRatForOnDemandMobility_type preferRatForVoiceCall;
    enumRatForOnDemandMobility_type preferRatForDataCall;
    uint16_t timerForCallRelease;  // 100~65535, 5000ms by default
} onDemandMobilityControlInfo_type;

typedef struct
{
    uint8_t usage;
    uint8_t endcSvcGrpPriority;
    uint8_t qci;
} endcSvcGrpMeasurementsConfig_type;

// FGR-MC1400 SVR22C2 : Conditional Handover
typedef struct
{
    bool allowance;              // cho-allowance
    uint16_t f1AccessSuccess;    // candidate-cell-release-timer-target. f1-access-success,
    uint16_t xnHandoverSuccess;  // candidate-cell-release-timer-source. xn-ho-succes,
} conditionalHandoverConfig_type;

// Mobility for EN-DC FR184.
typedef struct
{
    int8_t thresholdRsrp;
    int8_t thresholdRsrq;
} endcPscellSelectionThresholdPerCell_type;

typedef struct
{
    struct
    {
        uint8_t usage;
        uint8_t dlCapacityThreshold;
        uint8_t ulCapacityThreshold;
    } loadBasedTargetSelection;
} forcedMobilityDueToUplinkStatusIndication_type;

typedef struct
{
    uint8_t eutraMeasureBasedMobility;
    uint8_t mobilityTriggerTimer;    // FGR-MC1007 SVR21B : NR Connected Mobility Control t4
    uint16_t waitTimerForFreqPrior;  // FGR-MC1007 SVR21B : NR Connected Mobility Control t5
    uint8_t restrictPscellChangeBwMismatch;
    uint8_t nrdcMobilityOption;  // enum enumMrdcYangFlag_type
    uint8_t nrToEndcHoSupport;
    uint8_t hoWithNonCaSupport;
    uint8_t ueBasedCgiReportingForHo; // Only for DuplicatedPciHO, Not for NonNbrCellHO
    uint8_t ueBasedCgiReportingForEndcPscellChange : 1; // FGR-CC5001 FR236, on/off
    uint8_t serviceBasedCellReselectSupport;
    uint16_t ltmCandidateReleaseTimerValue;
    bool eutraHandoverFollowA2;
    bool intraNrInterFreqHandoverFollowA2;
    uint8_t supportFreqPriorityBasedIntraRatBlindRedirection : 1;
    uint8_t followA2WithMultipleTriggerQuantitySupportNr     : 1;
    uint8_t followA2WithMultipleTriggerQuantitySupportEutra  : 1;
    uint8_t plmnBasedDedicatedPrioritySupport                : 1;  // FGR-MC1015 SVR25A FR100
    uint8_t ltmAllowance                                     : 1;  // FGR-MC1015 SVR25A FR100
    uint8_t multipleA1WithFollowA2Support                    : 1;
    uint16_t handoverPrepFailedTimer;
    struct
    {
        uint8_t usage;
        uint8_t restrictPscellChangeBwMismatch;
        uint8_t endcSvcGrpMeasurementConfigEnabled;
        uint8_t measConfigDeltaEnabled;
        uint8_t freqPrioMeasConfigDeltaEnabled;
        endcSvcGrpMeasurementsConfig_type endcSvcGrpMeasurementsConfig[MAX_ENDC_SVCGRP_ID];
    } plmn[MAX_PLMN_INDEX];
    conditionalHandoverConfig_type conditionalHandoverConfig;
    endcPscellSelectionThresholdPerCell_type endcPscellSelectionThreshold; // Mobility for EN-DC FR184.
    forcedMobilityDueToUplinkStatusIndication_type forcedMobilityDueToUplinkStatusIndication; // FGR-MC1029
} cellMobilityConfig;

typedef struct
{
    uint8_t freqPriMobilitySupport                  : 1;  // True or False
    uint8_t pcellFreqPrioritizationHoSupport        : 1;  // True or False
    uint8_t caAwareScellToPcellChangeSupport        : 1;  // True or False
    uint8_t saPrioritizationHandoverUsingTimer      : 1;  // True or False
    uint8_t a1BasedPcellFreqPrioritizationHoSupport : 1;  // True or False
    uint8_t caAwareScellToPcellChangeByA2Support    : 1;  // True or False SVR24A FGR-MC1022 FR120
    uint8_t cellLoadBasedTargetCellSelectionSupport : 1;  // True or False SVR25B FGR-MC1022 FR160
    uint8_t dlCapacityThreshold;                          // 0 ~ 100 SVR25B FGR-MC1022 FR160
    uint8_t ulCapacityThreshold;                          // 0 ~ 100 SVR25B FGR-MC1022 FR160
    uint8_t availableUeThreshold;                         // 0 ~ 100 SVR25B FGR-MC1022 FR160
} freqPriMobilityControlInfo_type;

typedef struct
{
    uint8_t usage;
    uint8_t useforNrdc;
    uint8_t useforNrca;
    vccbGlobalGnbId_type globalGnbId;
    uint16_t cellId;
    enumCaColocCellStatus_type auditDbColocCellStatus;
    enumCaColocCellStatus_type callCurrColocCellStatus;
    time_t timerExpireTime;
    uint8_t useForNrcaUl;
} colocCellEntries_type;

typedef struct
{
    uint8_t colocCellInfoUsage;
    uint16_t colocCellStateResetTimer;
    colocCellEntries_type colocCellEntries[MAX_COLOCCELL];
} cuColocCellInfo_type;

typedef struct
{
    uint8_t usage;
    cgi_type cgi;
    time_t timerExpireTime;
} omFailedCellInfo_type;

typedef union
{
    struct
    {
        uint16_t f_pduSessAmbr      :1, // up, du
                 f_pduSessType      :1, // up
                 f_ulNguTnl         :1, // up
                 f_networkInstance  :1,
                 f_qosFlowAddModRel :1, // up, du
                 f_dataFwdInfofromSrc:1, // up (forwarding proposal, src drb2Qos mapping)
                 f_drbAddModRel     :1, // up, du
                 f_commonNetworkInstance:1,
                 f_defalutDrbAllowed:1,
                 f_nonGbrResourceOffered:1,
                 f_securityIndication:1, // up
                 reserved           :5;
    };
    uint16_t val;
} mrdcPduSessEventFlag_type; // for pdu modification by SNodeModificationReq

typedef union
{
    struct
    {
        uint16_t f_mnUlPdcpTnl  :1, // up
                 f_drbQos       :1, // du
                 f_ulConfig     :1, // du
                 f_qosFlowsMappedtoDrb:1, // up, du
                 f_mnDlCgTnl    : 1,
                 f_scgDrbFail   : 1, // MN only, drb(pdu) fail in S-Node Addition Request Ack(SVR25B FGR-CC5200 FR1050)
                 reserved       :10;
    };
    uint16_t val;
} mrdcDrbEventFlag_type; // for drb modification by SNodeModificationReq, for nrdc drb partial

typedef union
{
    struct
    {
        uint16_t f_reserved  :16; // TBD
    };
    uint16_t val;
} mrdcQosFlowEventFlag_type; // for QosFlow modification by SNodeModificationReq

typedef struct
{
    union
    {
        mrdcPduSessEventFlag_type   pduSessEventFlag;
        mrdcDrbEventFlag_type       drbEventFlag;
        mrdcQosFlowEventFlag_type   qosFlowEventFlag; // TBD
    };
    uint32_t    respFlag;
} mrdcFlag_type;

typedef struct
{
    uint8_t nedcSupport;
    uint8_t nedcMode : 1;  // YANG enum : ne_dc_mode1(BLIND)/ne_dc_mode2(MR based)
} nedcCellInfo_type;

typedef struct
{
    uint8_t usage;
    uint16_t rfsp;
    uint8_t ulPrimaryPathSwitch;
} nrdcRfspBasedUlPathSwitchCtrl_type;

typedef struct
{
    uint8_t usage;
    uint8_t plmnIndex;
    uint16_t rfsp;
    uint8_t nrdcOprModeRfsp;  // mode1(0)~mode4(3)
} nrdcRfspBasedOprMode_type;

#define MAX_RFSP_INDEX_TIMES_TWO                 (MAX_RFSP_INDEX * 2)
#define MAX_NRDC_RFSP_BASED_OPRMODE_YANG_ENTRIES 10
typedef struct  // NRDC-BASIC
{
    uint8_t nrdcSupport;
    uint8_t nrdcOprMode;           // access_s5gtype_nr_dc_mode1 : 0(blind), access_s5gtype_nr_dc_mode2 : 1(mr based)
    uint8_t gnbConfVonrRegular;    // access_s5gtype_allowed: 0, access_s5gtype_not_allowed: 1
    uint8_t gnbConfVonrEmergency;  // access_s5gtype_allowed: 0, access_s5gtype_not_allowed: 1
    uint8_t nrdcUlPrimaryPathMode;
    uint8_t nrdcScgProbability;
    uint8_t rfspBasedEntriesCount;
    nrdcRfspBasedUlPathSwitchCtrl_type
        rfspBasedEntries[MAX_RFSP_INDEX_TIMES_TWO];  // array length is doubled to handled cached DB operations properly
    nrdcRfspBasedOprMode_type nrdcRfspBasedOprMode[MAX_NRDC_RFSP_BASED_OPRMODE_YANG_ENTRIES];
} NrdcCellInfo_type;

typedef struct
{
    uint8_t caAvailable;           // nr-carrier-aggregation/ca-available-type - access-enum-ca-available
    uint8_t allowCellBarredScell;  // nr-carrier-aggregation/allow-cell-barred-scell - true/false
    uint8_t scellFreqPrioProfileIdx;
    uint8_t caOperationModeCell;   // nr-carrier-aggregation/ca-available-type
    uint8_t ulScellChangeByMr;     // nr-carrier-aggregation/ul-scell-change-by-mr
}  NrCarrierAggregationInfo_type;

typedef struct
{
    uint8_t scellFreqPrioFlag;  // On/Off flag (0..1). 0 stands for Off.
    uint8_t status;             // EQUIP / N_EQUIP
    struct scellFreqPriority    // Yang list scell-frequency-priority-entries
    {
        uint32_t scellArfcn;                           // arfcn 0..3279165
        uint8_t status;                                // EQUIP / N_EQUIP
    } scellFreqPriorities[MAX_SCELL_FREQ_PRIORITIES];  // index is priority-1
} scellFreqPrioProfile_type;

typedef struct
{
    uint8_t qosClassIndicatorUsage;                                 // Yang leaf qos-class-indicator-usage
    uint8_t noOfQosClassIndicator;
    uint8_t qosClassIndicator[MAX_CA_CONTROL_QOS_CLASS_INDICATORS]; // Yang list qos-class-indicator (0..255)

    uint8_t bandIndicatorNrUsage;                                   // Yang leaf band-indicator-nr-usage
    uint8_t noOfBandIndicatorNr;
    uint16_t bandIndicatorNr[MAX_CA_CONTROL_BAND_INDICATOR_NR];     // Yang list band-indicator-nr (1..1024)

    uint8_t ueRatType; // enumUeRat_type: YANG: ue-rat-type

    uint8_t sliceIdIndicatorUsage; // YANG leaf slice-id-indicator-usage
    uint8_t noOfsliceIdEntries;
    SliceSupportedInfo_type sliceIdEntries[MAX_CA_NUM_SLICES]; // YANG leaf slice-id-entries

    uint8_t plmnIndicatorUsage; // YANG leaf plmn-indicator-usage
    uint8_t plmnIndicatorList; // YANG list plmn-indicator-list (each bit is mapped with plmnIndexInfo. MAX_PLMN_INDEX)

    uint8_t spidRfspIndicatorUsage;                                   // Yang leaf spid-rfsp-indicator-usage
    uint8_t noOfSpidRfspIndicator;
    uint16_t spidRfspIndicator[MAX_CA_CONTROL_SPID_RFSP_INDICATORS];  // Yang list spid-rfsp-indicator (1..256)
} nrCaControlCondition_type;

typedef struct
{
    int8_t caUsage;           // enumCaUsage_type: YANG: access-enum-ca-usage
    int8_t ulCaUsage;         // enumUlCaUsage_type: YANG: access-enum-ul-ca-usage

    uint8_t allowedScellBandListUsage; // YANG lesf allowed-scell-band-list-usage
    uint8_t noOfAllowedBandList;
    uint16_t allowedScellBandList[MAX_CA_NUM_ALLOWED_BANDS]; // YANG leaf allowed-scell-band-list
} nrCaControlOperation_type;

typedef struct
{
    uint8_t caIndexUsage;     // TRUE / FALSE: YANG leaf ca-index-usage
    uint8_t caIndexPriority; // YANG leaf ca-index-priority
    nrCaControlCondition_type condition; // YANG container condition
    nrCaControlOperation_type operation; // YANG container operation
} nrCaControl_type;

typedef struct
{
    uint8_t caOperationMode; // enumCaOperationMode
    uint8_t noOfBlockBandsSa;
    uint8_t noOfBlockBandsNsa;

    uint16_t blockBandsSa[MAX_CA_NUM_BLOCK_BANDS]; //1...1024
    uint16_t blockBandsNsa[MAX_CA_NUM_BLOCK_BANDS]; //1...1024

} operationMode_type;

typedef struct
{
    operationMode_type bandOperationMode[MAX_NUM_NR_BAND];  // index is band-1
    uint8_t plmnInfoCheck;
    uint8_t allowDssFreqScell;
    uint8_t a6UeTxpowerEnhancement;  // carrier-aggregation/a6-ue-txpower-enhancement: disable/enable
    uint8_t saCellCheckFlag;         // carrier-aggregation/sa-cell-check-flag: true/false
    uint8_t interGnbCaSupportFlag;   // carrier-aggregation/inter-gnb-ca-support-flag: true/false
    uint8_t caOnLtmUsage;            // carrier-aggregation/ca-on-ltm-usage: CI_use/CI_no_use
    double dl1LayerWeightFactor;
    double dl2LayerWeightFactor;
    double dl4LayerWeightFactor;
    uint8_t releaseCaA4ForVoNR;      // carrier-aggregation/release-ca-a4-for-vonr: true/false

    scellFreqPrioProfile_type
        scellFreqPrioProfiles[MAX_SCELL_FREQ_PRIORITY_PROFILES];  // YANG list scell-frequency-priority-profile-entries
    nrCaControl_type nrCaControlEntries[MAX_NR_CA_CONTROL_ENTRIES];  // YANG list nr-ca-control-entries

    uint8_t nrCaControlSortIdx[MAX_NR_CA_CONTROL_ENTRIES];  // SVR24B FGR-RC0100 FR124, ca-index-priority sorting result
    uint8_t f1SeUsage; // SVR25B Patch FR560, f1-se-usage: CI_use, CI_no_use
    uint8_t noNeedToDetectInvisibleScell; // no-need-to-detect-invisible-scell: true/false
} gnbCarrierAggregationInfo_type;

typedef struct  // NRDC
{
    uint8_t preferTypePrev;
    uint8_t preferType;
    uint8_t failoverCnt;
} MrdcTypePrefer_type;

typedef struct
{
    uint8_t nedcOperatorSpecificPowerAllocation;
    uint8_t nedcPowerOffsetNrFr1;
} nedcPowerConfig_type;

typedef struct
{
    uint16_t mnDlRatio;
    uint16_t mnUlRatio;
} nedcUeAmbrConfig_type;

typedef struct
{
    uint8_t usage;  // CI_use, CI_no_use
    uint8_t rsvd;
    uint16_t mnDlRatio;
    uint16_t mnUlRatio;
    uint16_t snDlRatio;
    uint16_t snUlRatio;
} nrdcUeAmbrConfig_type;

typedef struct
{
    uint8_t usage;
    uint8_t mnDlRatio;
    uint8_t mnUlRatio;
    uint8_t snDlRatio;
    uint8_t snUlRatio;
} nrdcUeSliceMbrConfig_type;

typedef struct
{  // for NEDC
    uint8_t present;
    union
    {
        struct
        {
            /*
    choice
        XNAP_radioNetwork_chosen 1
        XNAP_transport_chosen 2
        XNAP_protocol_chosen 3
        XNAP_misc_chosen 4
*/
            uint16_t choice : 8;
            uint16_t cause  : 8;
        };
        uint16_t causeInfo;
    };
} SNRejRelCauseInfo_type;

typedef struct
{
    ConfStatus shmStatus;  // shmStatus_type

    uint8_t fiveQi;
    uint8_t arp;
    int32_t bearerType;
} dualConnectivityControlInfo_type;

typedef struct
{
    int8_t maxBandwidthRequestedDl;  // (not-used(-1), 0, 1, 2, ... , 15)
    int8_t maxBandwidthRequestedUl;  // (not-used(-1), 0, 1, 2, ... , 15)
    uint8_t maxCarriersRequestedDl;  // (0(not-used), 1..32)
    uint8_t maxCarriersRequestedUl;  // (0(not-used), 1..32)
} ueCapaNrBandReqLimitInfo_type;

typedef struct
{
    int8_t caBandwidthClassDlEutra;  // (not-used(-1), 0, 1, 2, 3, 4, 5)
    int8_t caBandwidthClassUlEutra;  // (not-used(-1), 0, 1, 2, 3, 4, 5)
} ueCapaEutraBandReqLimitInfo_type;

// this type has only one band which is identifier of Samsung gNB.
typedef struct
{
    uint8_t  usage; // device-identification-request-filter (on/off)
    uint16_t band;
    ueCapaEutraBandReqLimitInfo_type eutraBandReqLimitInfo;
} DeviceIdentifyFilter_type;

typedef struct
{
    uint8_t usage;
    ueCapaNrBandReqLimitInfo_type nrBandReqLimitInfo;
    uint16_t band;
} ueCapaNrBandInfo_type;

typedef struct
{
    uint8_t usage;
    uint8_t bandBlockFlag;  // SVR26A FGR-CC3103
    uint16_t band;
    ueCapaEutraBandReqLimitInfo_type eutraBandReqLimitInfo;
} ueCapaEutraBandInfo_type;

typedef struct
{
    uint8_t requestSkipFallbackComb      : 1;  // True/False
    uint8_t requestReducedIntNonContComb : 1;  // True/False
    uint8_t requestedMaxccsDl;                 // 0, 2~32
    uint8_t requestedMaxccsUl;                 // 0, 2~32
} eutraCapaEnquiryReqLimitInfo_type;

typedef struct
{
    uint8_t srsSwitchingTimeRequest      : 1;  // TRUE/FALSE
    uint8_t uceRatRequestType            : 2;  // 0: All RAT, 1: NR, 2: NR and Eutra
    uint8_t fallbackGroupFiveRequest_r17 : 1;  // TRUE/FALSE  // // SVR26A FGR-CC3103
    uint8_t reserved                     : 4;
} ueCapabilityEnquiryOptionPara_type;

typedef struct
{
    uint8_t uplinkTxSwitchRequest : 1; // TRUE/FALSE
    uint8_t reserved : 7;
}ueCapabilityEnquiryOptionCellPara_type;

typedef struct
{
#define MAX_REQUEST_FILTER_NR_BAND    64
#define MAX_REQUEST_FILTER_EUTRA_BAND 64
    ueCapaNrBandInfo_type bandNR[MAX_REQUEST_FILTER_NR_BAND];
    ueCapaEutraBandInfo_type bandEUTRA[MAX_REQUEST_FILTER_EUTRA_BAND];
    DeviceIdentifyFilter_type  deviceIdentifyFilter;
    eutraCapaEnquiryReqLimitInfo_type eutraReqLimitInfo;
    ueCapabilityEnquiryOptionPara_type uceOptionInfo;
} capabilityRequestFilter_type;

typedef struct
{
    uint8_t usage;    // CI_use / CI_no_use
    uint8_t freqIdx;  // Sorting based on freqIdx if cellReselectionPriority and cellReselectionSubpriorityUsage equal
    uint8_t targetMeasObjectEntriesindex;     // 0 - 19
    uint8_t cellReselectionPriority;          // 0 - 7
    uint8_t cellReselectionSubpriorityUsage;  // CI_use / CI_no_use
    uint8_t
        cellReselectionSubpriority;  // NRRRC_CellReselectionSubPriority, enum values {oDot2 = 0, oDot4, oDot6, oDot8}
    uint8_t nrdcCellReselectionPriority;          // 0 - 7
    uint8_t nrdcCellReselectionSubpriorityUsage;  // CI_use / CI_no_use
    uint8_t nrdcCellReselectionSubpriority;  // NRRRC_CellReselectionSubPriority, enum values {oDot2 = 0, oDot4, oDot6,
                                             // oDot8}
} rfspFreqItem_type;

typedef enum
{
    cell_reselection = 1,
    handover = 2,
    both = 3,
    disable = 4
} controlOption_type;

typedef struct
{
    uint8_t supportNrdcPscellChange;
    uint8_t supportBlindInterRatRedirection;
    uint8_t supportMeasInterRatRedirection;
    uint8_t restrictDlQualityBasedIRatMobility;
    uint16_t handoverPrepFailedTimer;
} controlOptionExt_type;

typedef struct
{
    enumUsage_type usage;                                  // CI_no_use, CI_use
    uint16_t rfsp;                                         // 1 - 256
    controlOption_type controlOption;                      // 1 - 4
    rfspFreqItem_type nrFreqItems[MAX_NUM_RFSP_NR_FREQS];  // Index is nr-freq-index
    rfspFreqItem_type eutraFreqItems[MAX_NUM_RFSP_FREQS];  // Index is eutra-freq-index
    controlOptionExt_type controlOptionExt;                // For controlOption set as disable
} rfspBasedCtrl_type;

typedef struct
{
    enumUsage_type usage; /* CI_no_use, CI_use */
    plmnId_type plmn;
    rfspBasedCtrl_type rfspBasedCtrl[MAX_RFSP_INDEX];
    rfspBasedCtrl_type redcapRfspBasedCtrl[MAX_RFSP_INDEX];
} plmnRfspBasedCtrl_type;

typedef struct
{
    uint8_t t320;  // T320 timer NRRRC__enum149, enum values {min5, min10, min20, min30, min60, min120, min180}
    uint8_t rfspBasedCellReselectUsage;  // VCCB_FLAG_ON/OFF
    plmnRfspBasedCtrl_type plmnRfspBasedCtrl[MAX_PLMN_INDEX];
} cellRfspBasedCtrl_type;

typedef struct
{
    uint8_t usage;                         // CI_use / CI_no_use
    uint8_t targetMeasObjectType;          // intra-freq-mo / inter-freq-mo
    uint8_t targetMeasObjectEntriesindex;  // 0 - 19
    uint8_t dedicatedPriority;             // 0 - 7
    uint8_t dedicatedSubpriorityUsage;     // CI_use / CI_no_use
    uint8_t dedicatedSubpriority;          // 0 - 7
    uint8_t serviceUeDistRatio;            //
    uint8_t redcapUeDistRatio;             // redcap-ue-distribution-ratio
    uint8_t weightFactorForAutoMode;       // weight-in-automode-for-idle-load-balancing
    uint8_t weightFactorForRedCapAutoMode; // redcap-weight-in-automode-for-idle-load-balancing
} svcFreqNrItem_type;

typedef struct
{
    uint8_t usage;                              // CI_use / CI_no_use
    uint8_t targetMeasObjectEutraEntriesindex;  // 0 - 19
    uint8_t dedicatedPriority;                  // 0 - 7
    uint8_t dedicatedSubpriorityUsage;          // CI_use / CI_no_use
    uint8_t dedicatedSubpriority;               // 0 - 7
} svcFreqEutraItem_type;

typedef struct
{
    enumUsage_type usage;
    uint8_t svcGroupId;
    uint8_t t320;  // T320 timer NRRRC__enum149, enum values {min5, min10, min20, min30, min60, min120, min180}
    svcFreqNrItem_type nrFreqItems[MAX_NUM_SVC_FREQS];        // Index is nr-freq-index
    svcFreqEutraItem_type eutraFreqItems[MAX_NUM_SVC_FREQS];  // Index is eutra-freq-index
} SvcBasedCrpCtrl_type;

typedef struct
{
    int8_t deltaThRsrp;  // -30..30
    int8_t deltaThRsrq;  // -30..30
    int8_t deltaThSinr;  // -30..30
    MeasQuantitiesRedCapValues_type redcapThreshold; // SVR25A FGR-MC1023 FR12
} rfspDeltaTh_type;

typedef struct
{
    union
    {
        struct
        {
            rfspDeltaTh_type a1DeltaTh;
            rfspDeltaTh_type a2DeltaTh;
            rfspDeltaTh_type a3DeltaTh;
            rfspDeltaTh_type a4DeltaTh;
            rfspDeltaTh_type a5DeltaTh1;
            rfspDeltaTh_type a5DeltaTh2;
        };
        struct
        {
            rfspDeltaTh_type b1DeltaTh;
            rfspDeltaTh_type b2DeltaTh1;
            rfspDeltaTh_type b2DeltaTh2;
        };
    };
} rfspThresholdDelta_type;

typedef struct
{
    uint8_t usage;                         // CI_use / CI_no_use
    uint8_t targetMeasObjectEntriesindex;  // 0 - 19  // target-meas-object-type: not important
    rfspThresholdDelta_type deltaTh;
} rfspFreqItemSpecific_type;

typedef struct
{
    enumUsage_type usage;                                          /* CI_no_use, CI_use */
    uint16_t rfsp;                                                 // 1 - 256
    rfspFreqItemSpecific_type nrFreqItems[MAX_NUM_RFSP_FREQS];     // Index is nr-freq-index
    rfspFreqItemSpecific_type eutraFreqItems[MAX_NUM_RFSP_FREQS];  // Index is eutra-freq-index
} rfspBasedCtrlSpecific_type;

typedef struct
{
    enumUsage_type usage; /* CI_no_use, CI_use */
    uint16_t rfspIdx;
    rfspBasedCtrlSpecific_type rfspBasedCtrl[MAX_RFSP_INDEX];  // max count:10, key:rfsp(1..256)
} plmnRfspSpecificCtrl_type;

typedef struct
{
    uint8_t rfspSpecificUsage;                                       // VCCB_FLAG_ON/OFF (usage)
    uint8_t supportLbFpHoUsage;                                      // VCCB_FLAG_ON/OFF (support-lb-fp-ho)
    plmnRfspSpecificCtrl_type plmnRfspSpecificCtrl[MAX_PLMN_INDEX];  // (rfsp-based-control-list. key:plmn-index)
} cellRfspSpecificMeasCtrl_type;

typedef struct
{
    uint8_t usage;
    uint8_t targetMeasObjectEntriesIndex;
    uint8_t dedicatedPriority;
    uint8_t dedicatedSubpriorityUsage;
    uint8_t dedicatedSubpriority;
} plmnBasedFreqItem_type;

typedef struct
{
    enumUsage_type usage;
    uint8_t plmnIndex;
    plmnBasedFreqItem_type nrFreqItems[MAX_NUM_PLMN_BASED_FREQS];
    plmnBasedFreqItem_type eutraFreqItems[MAX_NUM_PLMN_BASED_FREQS];
} plmnBasedDedicatedPriority_type;

typedef enum
{
    loadEvalMode_resource = 0,
    loadEvalMode_ue = 1,
    loadEvalMode_effective_resource = 2
} enumLoadEvalMode_Type;

typedef struct
{
    uint8_t availRscThreshold;
    uint8_t availRscThreshold1;
    uint8_t availRscThreshold2;
    uint8_t availRscThreshold3;
    uint8_t ulCceFailureRateThreshold;
    uint8_t pdcchCceUsageThreshold;
    uint8_t targetUlCceFailureRateThreshold;
    uint8_t targetPdcchCceUsageThreshold;
} redCapUeLbInfo_type;

typedef struct
{
    uint8_t usage;
    enumLoadEvalMode_Type loadEvaluateMode;
    uint16_t mrWaitTimer;
    uint8_t availRscThreshold;
    uint8_t availRscThreshold1;
    uint8_t availRscThreshold2;
    uint8_t availRscThreshold3;
    uint8_t availUeThreshold;
    uint8_t availUeThreshold1;
    uint8_t availUeThreshold2;
    uint8_t availUeThreshold3;
    uint8_t availEffRscThreshold;
    uint8_t availEffRscThreshold1;
    uint8_t availEffRscThreshold2;
    uint8_t availEffRscThreshold3;
    int8_t rscDelta;              // FGR-LC0703 SVR26B FR190
    uint8_t ueDelta;
    int8_t effRscDelta;
    enumLbResourceModeOption_type resourceModeOption;
    uint8_t skipAvailableUeThreshold;
    bool targetCellSelectionStrongestOnly;
    uint8_t periodicLbSwitch;
    uint8_t pdcchCceBasedLoadEvaluateSupport;
    uint8_t ulCceFailureRateThreshold;
    uint8_t pdcchCceUsageThreshold;
    uint8_t targetUlCceFailureRateThreshold;
    uint8_t targetPdcchCceUsageThreshold;
    uint8_t redCapOperationMode;
    redCapUeLbInfo_type redCapUeLbInfo;
} connModeLBInfo_type;

#define MAX_5QI_ARP 10
typedef struct
{
    ConfStatus  shmStatus;
    uint8_t     fiveqiValue;
    uint8_t     fiveqiArpValue;
} fiveqiArp_type;

typedef struct
{
    ConfStatus shmStatus;
    uint32_t plmnIndex;
    emerArpOption_Type emerArpOption;
    uint8_t emerArpValue;
    fiveqiArp_type fiveqiArp[MAX_5QI_ARP];
} emergencyArpInfo_type;

typedef struct
{
    ConfStatus  shmStatus;
    uint8_t     fiveqiValue;
    uint8_t     fiveqiArpValue;
} mpsFiveqiArp_type;

typedef struct
{
    ConfStatus  shmStatus;
    uint8_t     plmnIndex;
    emerArpOption_Type mpsArpOption;
    uint8_t mpsArpValue;
    mpsFiveqiArp_type fiveqiArp[MAX_5QI_ARP];
} mpsCallInfo_type;

typedef struct
{
    ConfStatus  shmStatus;
    uint8_t     fiveqiValue;
    uint8_t     fiveqiArpValue;
} hpaFiveqiArp_type;

typedef struct
{
    ConfStatus  shmStatus;
    uint8_t     plmnIndex;
    emerArpOption_Type hpaArpOption;
    uint8_t hpaArpValue;
    hpaFiveqiArp_type fiveqiArp[MAX_5QI_ARP];
} hpaCallInfo_type;

typedef struct
{
    struct timespec lastUpdatedTime;
    measObjFaInfo_type measObjUeDistRatio[MAX_MEAS_OBJECT_ENTRIES + 1];
} VccbIdleMobilityInfo_type;

typedef struct
{
    enumUsage_type usage;
    uint8_t targetMeasObjectEntriesindex;

    uint8_t priority;
    uint8_t subpriorityUsage;
    uint8_t subpriority;

    float ueDistributionRatio; // float �야맘는지 고�볼�

    uint8_t ueDistributionRatioForNonPlmnMode;
    uint8_t ueDistributionRatioForPlmnMode[MAX_PLMN_INDEX];
    uint8_t ueDistributionRatioForCaProfileMode[MAX_CA_PROFILE_NUM];
    uint8_t ueDistributionRatioForRedCapUE; // ue_distribution_ratio_for_redcap_idle_load_balancing
    uint8_t weightFactorForAutoMode; // weight_in_automode_for_idle_load_balancing
    uint8_t weightFactorForRedCapAutoMode; // 26B weight-in-automode-for-redcap-idle-load-balancing

    uint16_t nrFreqSelectCnt[VCCB_CALL_THREAD_NUM];
} nrCellReselectInfo_type;

typedef struct
{
    uint8_t usage;
    uint8_t legacyModeFlag; // legacy-idle-lb-switch
    uint8_t plmnModeFlag; // distribution-ratio-per-plmn-switch
    uint8_t redCapFlag; // redcap-idle-load-balancing-switch

    uint8_t autoModeFlag; // operation-mode-for-idle-load-balancing 
    uint8_t normalUeAutoModeRsuType; // 26B resource-mode-option-for-idle-lb-auto-mode
    uint8_t redCapUeAutoModeRsuType; // 26B resource-mode-option-for-idle-lb-redcap-auto-mode
    VccbIdleMobilityInfo_type sonInfo;
    uint8_t isAutoModeUeDistRatioValid;
    uint8_t ueNumThresholdForAutoMode; // trigger-threshold-for-idle-load-balancing

    nrCellReselectInfo_type nrFreqItem[MAX_NUM_FREQ + 1];
} idleModeLBInfo_type;


typedef struct
{
    uint8_t     usage; // connected-load-balancing-to-lte-switch

    // connected-load-balancing-to-lte-info
    uint8_t     pdcchCceBasedLoadEvaluateSupport;
    uint8_t     loadEvaluateMode;
    uint8_t     resourceModeOption;
    uint8_t     availableResourceThreshold;
    uint8_t     availableUeThreshold;
    float       ulCceFailureRateThreshold;
    float       pdcchCceUsageThreshold;
    uint16_t    mrWaitTimer;
} connModeIratLbInfo_type;

typedef struct
{
    uint8_t usage; // vonr-load-balancing-switch

    // vonr-load-balancing-info
    uint8_t ulCceFailureRateThreshold;
    uint8_t targetUlCceFailureRateThreshold;
    uint8_t targetCellSelectionStrongestOnly; // FGR-LC0712 FR220 26A
    uint16_t mrWaitTimer;
} voNrLbInfo_type;

typedef struct
{
    uint8_t usage                 : 1; // ON/OFF
    uint8_t supportLbPscellChange : 1; // FGR-LC0708 FR34, ON/OFF
} spidLbSupportEntries_type;

typedef struct
{
    spidLbSupportEntries_type spidLbSupportEntries[MAX_SPID_VALUE];
} spidLbSupport_type;

typedef struct
{
    uint8_t usage;
    uint8_t ueDistributionRatioForNonPlmnMode;              // ue-distribution-ratio-for-idle-load-balancing
    uint8_t ueDistributionRatioForPlmnMode[MAX_PLMN_INDEX]; // plmn-0-ue-distribution-ratio, plmn-1-ue-distribution-ratio
    uint8_t weightFactorForAutoMode;                        // weight-in-automode-for-idle-load-balancing
} idleModeLbLbmParameterNrFreqDistRatio_type;

typedef struct
{
    int8_t availRscThreshold;
    int8_t availRscThreshold1;
    int8_t availRscThreshold2;
    int8_t availRscThreshold3;
    int8_t rscDelta;
} lbmConnModeLbEntry_type;

// /** LBM connected LB entry: resource-delta not set (YANG configured range is -100..100; FGR-LC0703 26B). */
#define LBM_CONN_MODE_LB_ENTRY_RSC_DELTA_NOT_SET ((int8_t)-128)

/** LBM config-load-balancing-for-nr-carriers resource-mode-option (FGR-LC0703 26B, access-enum-resource-mode-option-lbm) */
typedef enum
{
    LBM_RESOURCE_MODE_OPTION_NOT_CONFIGURED = -1, /* YANG: resource-mode-option-not-configured */
    LBM_RESOURCE_MODE_OPTION_MIN_DL_UL        = 0, /* YANG: resource-mode-option-min-dl-ul */
    LBM_RESOURCE_MODE_OPTION_DL               = 1, /* YANG: resource-mode-option-dl */
    LBM_RESOURCE_MODE_OPTION_UL               = 2, /* YANG: resource-mode-option-ul */
} enumResourceModeOptionLbm_type;

typedef struct
{
    /* config-load-balancing-for-nr-carriers */
    uint8_t usage;
    enumLoadEvalMode_Type loadEvaluateMode;
    enumResourceModeOptionLbm_type resourceModeOption;
    int8_t loadBalancingThresholdGroup[MAX_NR_OF_OBJECT_ID_DB];

    /* load-balancing-for-nr-carriers */
    lbmConnModeLbEntry_type lbmConnModeLbEntry[MAX_NR_LBM_CONFIG_ENTRIES];

} lbmConnModeLbInfo_type;

typedef struct
{
    struct idleLbInfoLbm_s
    {
        struct idleLbInfoLbmConfig_s
        {
            uint8_t usage;                     // idle-mobility-control-switch
            uint8_t legacyModeFlag;            // legacy-idle-lb-switch
            uint8_t ueNumThresholdForAutoMode; // trigger-threshold-for-idle-load-balancing
            uint8_t measThresholdTypeLb;       // meas-threshold-type-lb
            uint8_t measThresholdLevelLb;      // meas-threshold-level-lb
        } cellConfig;

        struct idleLbInfoLbmParameterSet_s
        {
            uint8_t usage;
            idleModeLbLbmParameterNrFreqDistRatio_type intraFreq;
            idleModeLbLbmParameterNrFreqDistRatio_type interFreq[MAX_NUM_FREQ];

            struct {
                uint8_t usage;
                uint8_t measObjectIndex;                                // meas-rsrp-threshold-lb
                uint8_t rsrp;                                           // meas-rsrp-threshold-lb
            } measThreshold[MAX_NR_OF_OBJECT_ID_DB];
        } parameterSet[MAX_NR_LBM_CONFIG_ENTRIES - 1]; // -1 is because it does not include NR_LBM_DISABLE

    } idleLbInfo;
    lbmConnModeLbInfo_type lbmConnModeLbInfo;
} cellLbmConfiguration_type;

/**
 * @brief Related feature: FGR-LC0708
 *
 */
typedef struct
{
    bool pscellChangeLbSwitch;
    bool pdcchCceBasedLoadEvaluateSupport;
    enumLoadEvalMode_Type loadEvaluateMode;
    uint16_t mrWaitTimer;
    int8_t rscDelta;
    int8_t ueDelta;
    int8_t effRscDelta;
    enumLbResourceModeOption_type resourceModeOption;
    int8_t skipAvailableUeThreshold;
    bool targetCellSelectionStrongestOnly;
    int8_t availRscThreshold[CONN_LB_THRESHOLD_GROUP_MAX];
    int8_t availUeThreshold[CONN_LB_THRESHOLD_GROUP_MAX];
    int8_t effAvailRscThreshold[CONN_LB_THRESHOLD_GROUP_MAX];
    int8_t ulCceFailureRateThreshold;
    int8_t pdcchCceUsageThreshold;
    int8_t targetUlCceFailureRateThreshold;
    int8_t targetPdcchCceUsageThreshold;
} PscellChangeLbInfo_type;

typedef struct
{
    idleModeLBInfo_type idleModeLbInfo;
    connModeLBInfo_type connModeLbInfo;
    uint8_t serviceBasedIdleLbSwitch;
    connModeIratLbInfo_type connModeIratLbInfo; // connected-load-balancing-to-lte-info
    voNrLbInfo_type voNrLbInfo; // FGR-LC0712
    spidLbSupport_type spidLbSupport; // FGR-LC0708 FR34
    cellLbmConfiguration_type lbmConfiguration;
    PscellChangeLbInfo_type pscellChangeLbInfo; // FGR-LC0708
} cellLbConfig_type;

typedef struct
{
    enumUsage_type usage;
    uint8_t index;
    uint8_t targetMeasObjectEntriesindex;
    uint8_t priority;
    uint8_t subpriorityUsage;
    uint8_t subpriority;
} eutraCellReselectInfo_type;

typedef struct
{
    int8_t a1ThDeltaRSRP;
    int8_t a1ThDeltaRSRQ;
    int8_t a2ThDeltaRSRP;
    int8_t a2ThDeltaRSRQ;
    int8_t a3OffsetDeltaRSRP;
    int8_t a3OffsetDeltaRSRQ;
    int8_t a4ThDeltaRSRP;
    int8_t a4ThDeltaRSRQ;
    int8_t a5Th1_DeltaRSRP;
    int8_t a5Th2_DeltaRSRP;
    int8_t a5Th1_DeltaRSRQ;
    int8_t a5Th2_DeltaRSRQ;
    int8_t b2Th1_DeltaRSRP;
    int8_t b2Th1_DeltaRSRQ;
} deltaThInfo_type;

typedef struct
{
    deltaThInfo_type deltaThPc1Info;
    deltaThInfo_type deltaThPc1dot5Info;
    deltaThInfo_type deltaThPc2Info;
} deltaThInfoFr1_type;

typedef struct
{
    deltaThInfo_type deltaThPc1Info;
} deltaThInfoFr2_type;

typedef struct
{
    deltaThInfoFr1_type fr1;  // FGR-CC4208
    deltaThInfoFr2_type fr2;  // FGR-CC4209
} deltaThMeasConfig_type;

/**
 * @brief [FGR-CC8001] DL PDCP traffic status monitoring control (NR)
 *        This structure is to store per cell traffic monitoring configuration from confd.
 */
typedef struct
{
    uint8_t usage;     // enumUsage_type
    uint8_t purpose;   // enumTrafficReportingPurpose_type : YANG: purpose
    uint16_t thAbove;  // YANG: traffic-monitoring-configuration : data-traffic-threshold
    uint16_t thBelow;  // YANG: traffic-monitoring-configuration : data-traffic-threshold-below
    uint32_t ulDataTrafficThreshold;
} TrafficMonitoringCfgDb_type;

/**
 * @brief [FGR-CC8001] DL PDCP traffic status monitoring control (NR)
 *        This structure is to store RFSP based per cell traffic monitoring configuration from confd.
 */
typedef struct
{
    uint8_t usage;      // enumUsage_type
    uint8_t plmnIndex;  // YANG: traffic-monitoring-configuration-rfsp : plmn-index
    uint16_t rfsp;      // YANG: traffic-monitoring-configuration-rfsp : rfsp-index
    uint8_t purpose;    // enumTrafficReportingPurpose_type : YANG: purpose
    uint8_t reserved;
    uint16_t threshold;  // YANG: traffic-monitoring-configuration-rfsp : data-traffic-threshold-rfsp
} TrafficMonitoringCfgRfspDb_type;

/**
 * @brief [FGR-CC8001] DL PDCP traffic status monitoring control (NR)
 *        This structure is to manage given Report Configuration installed on AUPF
 */
typedef struct
{
    uint8_t usage;       // enumUsage_type
    uint8_t purpose;     // enumTrafficReportingPurpose_type
    uint8_t condition;   // enumTrafficReportingCondition_type
    uint8_t reportId;    // assigned Report ID
    uint16_t threshold;  // configured threshold
    uint16_t startMonitoringThr; // start traffic monitoring threshold value
    uint8_t keepFlag;    // TRUE/FALSE indicate the difference b/w old new configuration
    uint8_t isReportedByAUPF;
} TrafficReportCfg_type;

/**
 * @brief [FGR-CC8001] DL PDCP traffic status monitoring control (NR)
 *        This structure is to manage Per DRB Report Configuration installed on AUPF
 */
typedef struct
{
    uint8_t isSameCfgFlag;  // Indicates if new DRB configuration is same as existing one installed on AUPF
    struct ReportCfgPerDRB_s
    {
        uint8_t usage            : 1;  // enumUsage_type
        uint8_t keepFlag         : 1;  // TRUE/FALSE indicate the difference b/w old new configuration
        uint8_t isReportedByAUPF : 1;
    } reportIdxList[MAX_TRF_MONITORING_CFG_PER_CALL];
} TrafficReportCfgDrb_type;

/**
 * @brief [FGR-CC5200] NR-DC Basic Operation (NR)
 *        During filling msg, this structure is used to indicate TrafficStatusRptCfg to be refreshed
 */
typedef union
{
    struct
    {
        uint16_t pduSessIdx;
        uint16_t drbIdx;
    };
    uint32_t value;
} ToBeRefreshedBitMap_type;

/**
 * @brief [FGR-CC8001] DL PDCP traffic status monitoring control (NR)
 *        This structure is keep Traffic Report Configuration in Call Info
 */
typedef struct
{
    uint8_t reportIdxAlloc;                        // idx of next entry to allocate (Round Robin allocator)
    ToBeRefreshedBitMap_type toBeRefreshedBitMap;  // for nrdc
    TrafficReportCfg_type trafficReportCfgList[MAX_TRF_MONITORING_CFG_PER_CALL];
    TrafficReportCfgDrb_type trafficReportDrbList[MAX_DRB_PER_CALL];
} TrafficMonitoringCfg_type;

typedef struct
{
    uint8_t pdcpFr2PscellChangeFlag;  // VCCB_FLAG_ON/VCCB_FLAG_OFF
    uint8_t TrfBasedNrToEutraHoFlag;  // VCCB_FLAG_ON/VCCB_FLAG_OFF
} TrafficMonitoringState_type;

typedef struct
{
    uint8_t load_based_fr2_band_selection_option;  // 0..1

    // FGR-LC0705:FR12
    uint8_t bandSelectionMode;              // capacity-based(0), event-based(1), fast-access-load-balancing(2)
    uint8_t scgBandCapacityOption;          // capacity-dl(0), capacity-ul(1), capacity-both(2)
    uint16_t scgBandThresholdEventTrigger;  // 0..32

    uint16_t mr_collection_timer;  // 0..6000 ms
    uint16_t loadTopN;              // 0..32
    uint16_t mrWaitingTimer;        // 0..6000 ms
} scgBandSelectionConfigYang_type;

typedef struct
{
    uint32_t ssbArfcn;
    uint32_t umfsCurrentCallCnt;
} cbrsCarrierInfo_type;

typedef enum
{
    CbrsCarrierInfoUpdateMode_gnbCellInfoBased = 0,
    CbrsCarrierInfoUpdateMode_gnbCellInfoAndMrReceivingFactorBased = 1,
} enumCbrsCarrierInfoUpdateMode_type;

typedef struct
{
    uint8_t cbrsCarrierUpdateEnabled;
    uint8_t cbrsCarrierInfoUpdateMode;  // enumCbrsCarrierInfoUpdateMode_type
    uint8_t numOfCbrsCarrierInfo;
    cbrsCarrierInfo_type cbrsCarrierInfo[MAX_CANDIDATE_CBRS_SSB_ARFCN_CNT];
} cbrsInfo_type;

typedef struct
{
    uint32_t ssbArfcn;
    uint32_t mrConfigCnt;
    uint32_t mrRcvdCnt;
} cbrsMrStat_type;

typedef struct
{
    cbrsMrStat_type cbrsMrStats[VCCB_CALL_THREAD_NUM][MAX_CANDIDATE_CBRS_SSB_ARFCN_CNT];
    uint8_t numOfCbrsMrStats[VCCB_CALL_THREAD_NUM];
} cbrsStats_type;

typedef struct
{
    uint8_t congestionState;
    uint8_t congestionStateSliceLoad;
    uint8_t congestionUlPathEnabled ;
    uint8_t ccceFailCongestionInThreshold;
    uint8_t ccceFailCongestionOutThreshold;
    uint8_t prbUsageCongestionInThreshold;
    uint8_t prbUsageCongestionOutThreshold;
    uint8_t ulDataSplitThresholdForCongestion; //enum
    uint8_t ulSliceLoadBasedUlPathSwitchingOnOff;
} ulPathCongestionBasedSwitching_type;

typedef struct
{
    uint8_t adaptationSwitch; // on/off
    uint8_t weightFactorNr;
    uint8_t weightFactorLte;
} ulPathScgAdaptation_type;

// SVR25B FGR-CC5300
/**
 * @brief cell Traffic Steering Configuration Entry
 */
typedef struct
{
    uint8_t usage;      /* CI_no_use/CI_use */
    double  min;        /**< traffic-steering-configuration/function-output-min */
    double  max;        /**< traffic-steering-configuration/function-output-max */
    double  variableA;  /**< traffic-steering-configuration/variable-a */
    double  variableB;  /**< traffic-steering-configuration/variable-b */
    double  variableC;  /**< traffic-steering-configuration/variable-c */
    double  variableD;  /**< traffic-steering-configuration/variable-d */
} trafficSteeringConfigEntry_type;

typedef enum
{
    tsmState_Disable = 0,
    tsmState_Enable = 1,
    tsmState_Fallback = 2,
} enum_tsmParaConfigState_type;

/**
 * @brief cell Traffic Steering Configuration
 */
typedef struct
{
    uint8_t state;              // PLDSonOpStatus::tsmParaConfigState, enum_tsmParaConfigState_type
    uint8_t configuredIndex;    // PLDSonOpStatus::tsmWindowState
    trafficSteeringConfigEntry_type configEntry[MAX_TSM_CONFIG_NUM];
} trafficSteeringConfig_type;

// SVR26A FGR-MC1026
typedef struct
{
    bool featureEnabled;
    struct
    {
        int8_t rsrp;
        int8_t rsrq;
        int8_t sinr;
    } a2DeltaThreshold;
} highSpeedUeMobility_type;

typedef enum
{
    ueSpeedState_Normal = 0,
    ueSpeedState_High = 1,
    ueSpeedState_Stationary = 2,
} enumUeSpeed_type;

// SVR26B FGR-MC1026
typedef struct
{
    bool highSpeedCellExcludedCell;
} ueSpeedStateMobilityConfig_type;

// SVR25B FGR-MC1050
typedef struct
{
    uint8_t usage:1;
    uint8_t dedicatedSubpriorityUsage:1;    // SVR26A FGR-MC1019
    uint8_t dedicatedPriority;              // SVR26A FGR-MC1019
    uint8_t dedicatedSubpriority;           // SVR26A FGR-MC1019
    uint8_t saFrequencyPriority;
    uint32_t ssbFreq;
} sammFreqPriority_type;

typedef struct
{
    uint8_t usage;
    uint16_t dlCapaTh;
    uint16_t ulCapaTh;
    uint16_t numUeTh;
    sammFreqPriority_type freqInfo[MAX_NUM_SAMM_FREQ];
} nrSammCellSvcGrpData_type;

typedef struct
{
    uint8_t usage;                                        // TODO:need to check 33? 32?
    nrSammCellSvcGrpData_type svcGrpData[MAX_SVC_GROUP_NUM];  // key means serviceGroup Id 1..32 (db is 0..31 service group id = index+1)
} nrSammParameterSet_type;

typedef struct
{
    uint8_t windowState;      // 0..1 PLDSonOpState::sammWindowState
    uint8_t paraConfigState;  // 0..2 enum_NrSammParaConfigState_type PLDSonOpState::sammParaConfigState
    nrSammParameterSet_type parameterSet[MAX_SAMM_OPER_WINDOW_INDEX][MAX_SAMM_PURPOSE];     // sa-samm-parameter-set
} nrSammCellConfig_type;

typedef struct
{
    uint8_t usage;  // enumUsage_type
    uint8_t svcGrpId;
} nrSammBlockCellSvcGrp_type;

typedef struct
{
    uint8_t usage;
    cgi_type cgi;
    nrSammBlockCellSvcGrp_type serviceGroupEntries[MAX_SVC_GRP_DB_NUM];  // 0..32
} nrSammBlockCellList_type;

typedef struct
{
    uint8_t cellLoadThSwitch              : 1;
    uint8_t blockCellForSvcSwitch         : 1;
    uint8_t svcGrpFrequencyPrioritySwitch : 1;
    uint8_t idleMobilityForServiceSwitch  : 1;

    nrSammBlockCellList_type blockCellList[MAX_NUM_SAMM_BLOCK_LIST];
} nrSammGnbConfiguration_type;

typedef struct
{
    bool specialBandChangeFlag;
} mfbiConfig_type;

// SVR26A FGR-SV0201 + VZW SVR25B P2
typedef struct
{
    uint8_t usage              : 1;
    uint8_t allowVonrPerRfsp   : 1;
    uint8_t allowEmergencyVonrPerRfsp : 1;
    uint8_t reserved           : 5;
    uint8_t plmnIndex;
    uint16_t rfsp;
} vonrControlRfspList_type;

typedef struct
{
    uint8_t usage;
    uint8_t vonrControlCommon;
    uint8_t emergencyVonrUsage;
    uint8_t emergencyVonrControlCommon;

    vonrControlRfspList_type   vonrControlRfspList[MAX_VONR_CONTROL_RFSP_LIST_PER_CELL];
} vonrControlInfoPerCell_type;

// SVR26B LBM FGR-LC0740
typedef struct
{
    int8_t thDeltaRsrp;
    int8_t thDeltaRsrq;
} lbmSpecificThDelta_type;

typedef struct
{
    uint8_t targetMeasObjectIndex;
    uint8_t usage;
    lbmSpecificThDelta_type a2ScellReleaseDelta;
    lbmSpecificThDelta_type a4ScellAdditionDelta;
} lbmSpecificMeasObject_type;

typedef struct
{
    lbmSpecificMeasObject_type mo[MAX_MEAS_OBJECT_ENTRIES];
} lbmSpecificTargetMeasObjectList_type;

typedef struct
{
    lbmSpecificTargetMeasObjectList_type
        moListPerLbmParameterSet[MAX_NR_LBM_CONFIG_ENTRIES - 1];  // -1 as for no LBM delta is simply not used
} lbmSpecificMeas_type;

typedef struct multipleBwInfo_s
{
    enum_multiBwServingCellType_type servingCellType;
    uint8_t multiBwCount;
    enum_multiBwUeType_type ueType[MAX_NR_CHANNEL_BW_LIST];
    uint32_t offsetToCarrierDL[MAX_NR_CHANNEL_BW_LIST];
    uint32_t carrierBandwidthDL[MAX_NR_CHANNEL_BW_LIST];
    uint32_t offsetToCarrierUL[MAX_NR_CHANNEL_BW_LIST];
    uint32_t carrierBandwidthUL[MAX_NR_CHANNEL_BW_LIST];
} multipleBwInfo_type;

typedef struct cellInfo_s
{
    cellConfig_type cfg;

    /* parameters read from confD (gutran-cu-cell-entries) */
    uint8_t status;  // ConfdStatus
    struct cgi_s
    {
        uint64_t ci;  // NR Cell Identity (36bits)
    } cgi;

    ueCapabilityEnquiryOptionCellPara_type uceCellOptionInfo;

    uint8_t isCellSSB;
    uint8_t nrUlCoverageMethod;  // enum: off/A1-A2/mac-detection
    uint8_t ulPrimaryPathMode;   // enum: initial-SCG/initial-MCG/initial-dynamic-RSRP-RSRQ/initial-probability-based
    ulPathCongestionBasedSwitching_type ulPathCongestionBased;
    uint8_t scgProbability;      // uint8 (0..100)
    ulPathScgAdaptation_type scgAdaptation;
    enumCoMPOption_type mrTriggeringUlComp;
    enumCoMPOption_type mrTriggeringDlComp;
    uint8_t preemptionWithRedirection;
    uint8_t interCellVipUeEvent; // [FGR-CC3502] VIP UE indication
    uint8_t allowVonrWithRfspPerCell;

    measurementsData_type measurementsData;
    cellRfspBasedCtrl_type cellRfspBasedCtrl;
    cellRfspSpecificMeasCtrl_type cellRfspSpecificMeasCtrl;

    SvcBasedCrpCtrl_type SvcBasedCrpCtrl[MAX_SVC_GROUP_NUM];    // 23B FGR-MC1019
    plmnBasedDedicatedPriority_type plmnBasedDedicatedPriority[MAX_PLMN_INDEX];  // 25A FGR-MC1015

    // FGR-LC0705:FR12
    uint32_t rsuTransId;

    // BTSP #TS2590I2 (VZW 25A)
    uint32_t gnbId;

    sonCellPrbRsc_type   cellRscInfo;
    sonCellSliceCac_type cellCacInfo;  // SVR23B FGR-L0706 NR Resource Status Reporting

    faMeasResult_type facMeasResult[MAX_MEAS_OBJECT_ENTRIES];            // Freq Auto Configuration

    ManagementTraceSessionPerCell_type traceSession;
    struct cellCollectorTraceInfo_s
    {
        uint8_t collectOnOff;       // bool, TRUE = 1
        uint8_t rlfFunctionOnOff;   // bool, TRUE = 1
        uint8_t rcefFunctionOnOff;  // bool, TRUE = 1
    } cellCollectorTraceInfo;
    SignalingMdtUeCountersPerCell_type signalingMdtUeCounters;

    anrCellInfo_type anrInfo;
    iratAnrCellInfo_type irat_anrInfo;
    upmCellInfo_type upmInfo;  // For F_UPM
    upmCellInfo_type psCellUpmInfo;  // For F_UPM
    measColocCellInfo_type measColocInfo;
    cellMobilityConfig mobilityConfig;

    nedcCellInfo_type nedcCellInfo;
    NrdcCellInfo_type nrdcCellInfo;  // NRDC-BASIC
    TrafficMonitoringCfgDb_type dlTrfStatusCfg[MAX_TRF_MONITORING_ENTRIES_DB];
    TrafficMonitoringCfgRfspDb_type trfMonitoringCfgRfsp[MAX_TRF_MONITORING_RFSP_ENTRIES_DB];
    scgBandSelectionConfigYang_type scgBandSelectionConfig;

    nedcPowerConfig_type nedcPowerConfig;
    uint8_t nedcNrUlCoverageMethod;  // YANG enum : off/A1-A2/mac-detection
    uint8_t nrdcNrUlCoverageMethod;  // YANG enum : off/A1-A2
    // mac-detection option will be treated as A1-A2 in SVR21D release
    uint8_t pdcpLatencyPreferredUlPrimaryPath; // YANG enum : scg/mcg

    cellLbConfig_type lbCfg;
    eutraCellReselectInfo_type eutraCellReselect[MAX_NUM_FREQ];

    cuColocCellInfo_type cuColocCellInfo;
    NrCarrierAggregationInfo_type nrCarrierAggregationInfo;
    omFailedCellInfo_type omFailedCells[MAX_CA_OM_FAILED_CELLS];
    uint8_t dssEnabled;                         // YANG boolean
    uint8_t imdInterferenceDetection;           // YANG boolean
    uint8_t imdInterferenceDetectionPerDuplex;  // YANG string

    /* deprioritisation YANG parameters */
    struct dssDeprioritisation_s
    {
        uint8_t flag;
        uint8_t type;
        uint8_t timer;
    } deprioritisation;

    /* parameters read when cell is being setup */
    uint16_t cellIdentity;
    uint8_t gnbNum;

    /* parameters read from user PLD (0x0077f007) */
    uint8_t pldState;     // status of user PLD (0x0077f007)
    uint16_t pldCellIdx;  // cellIdx of user PLD (0x0077f007)
    uint32_t tac;
    uint32_t configuredTac;
    uint8_t tacStatus;
    uint8_t configuredTacStatus;
    uint8_t serviceState;
    uint16_t endPointF1Index;  // range : 0~(MAX_GNB_DU_PER_GNB_CU_CP-1)
    uint16_t phyCellId;        // NR Physical Cell Id
    uint16_t nrScsDl;          // TDD:nrScs, FDD:nrScsDl
    uint16_t nRbDl;            // TDD:nRb, FDD:nRbDl
    uint8_t duplexMode;        // ci_DUPLEXTYPE_FDD(0)/TDD(1)
    uint32_t nrArfcnDl;        // INTEGER (0..3279165) TDD:nrArfcn, FDD:nrArfcnDl
    uint16_t nrScsUl;          // NR SCS UL(Sub Carrier Spacing UpLink)
    uint16_t nRbUl;            // Num RB UL
    uint32_t nrArfcnUl;        // INTEGER (0..3279165)
    uint32_t ssbArfcn;         // INTEGER (0..3279165)
    ncdSsbInfo_type  ncdSsbInfo;
    freqBandInfo_type freqBandInfoList[MAX_FREQBAND_PER_CELL];
    mibInfoCu_type mib;
    sib1Info_type sib1;
    cellPlmnInfo_type cellPlmn;
    cellPlmnIndexInfo_type cellPlmnIndexInfo[MAX_PLMN_INDEX];
    uint8_t ranacUsage;
    uint8_t ranac;

    //  uint64_t                duId;           /**< gNB-DU ID */ // NOT Updated.

    uint8_t priority;  // Cell Priority to select PSCell
    uint8_t isFilteredForLog        : 1;

    // FGR-CC3502 VIP UE indication, FGR-CC5003 UL Path Control in EN-DC
    struct cellUlPathVipUeTimerInfo
    {
        timerInfo_type timer;
        bool isRunning;
        pthread_mutex_t mutex;
    } ulPathVipUeTimer;
    bool isUlPathVipUeTimerRunning;  // FGR-CC3502 VIP UE indication, FGR-CC5003 UL Path Control in EN-DC
    timerInfo_type UlPathVipUeTimer;    // FGR-CC3502 VIP UE indication, FGR-CC5003 UL Path Control in EN-DC

    struct cellDBInfo_s
    {
        int caAvailableType;
        int caOperationMode;
        uint16_t plmnIndex;
    } cellDBInfo;

    nbrGnbCellInfo_type intraGnbNbrInfo;
    freqPriMobilityControlInfo_type fpMobilityControl;
    uint8_t switchingOffOngoing;
    uint8_t configuredTacIndication;                  // CONFIG_TAC_IND_21C
    uint8_t redcapBroadcastUsage;                     // SVR23B RedCap UE Usage
    uint8_t redcapBroadcastState;                     // SVR23B RedCap UE
    uint8_t supportRedCapDedicatedMeasurement;              // 0: False, 1: True

    onDemandMobilityControlInfo_type onDemandHoInfo;  // ODF_HO_21B

    deltaThMeasConfig_type deltaThMeasConfig;

    // CELL Profile
    struct profileDBInfo_s
    {
        uint8_t drxProfileIdx;
        uint8_t spidBasedUlPathSwitchingProfileIdx;
        uint8_t rrcSaTimerProfileIdx;    // 0 - 5
        uint8_t rrcEndcTimerProfileIdx;  // 0 - 0
        uint8_t pdcpProfileIdx;          // 0 - 31
        uint8_t endcInactivityTimerPerCellProfileIdx;  // 0 - 9
        uint8_t saDataInactivityProfileIdx ;  // 0 - 9
        uint8_t saDataInactivityProfileIdx_Redcap ;  // 0 - 9  // YANG: configuration-profile/sa-data-inactivity-profile-index-redcap
        uint8_t mcoProfileIndex;  // 0 - 63
    } profileDBInfo;

    cbrsInfo_type cbrsInfo;
    cbrsStats_type cbrsStats;

    struct pdcchConfig_s
    {
        uint8_t minBlindDetectionScg;  // 4..10
    } pdcchConfig;
    // FGR-CC5001 FR235
    uint8_t ulInterference; // 0: cleared, 1: interference
    // FGR-CC5000 Basic Operation for EN-DC
    uint32_t statEndcAddDetailedCpFail[StatEndcAddCpFail_MAX_STAT]; // FR:TBD: Internal stats for detailed EndcAddCpFail cases
    uint32_t statEndcAddDetailedSpCellSelFail[StatEndcSpCellSelFail_MAX_STAT]; // FR:RBD Internal stats for detailed SPCellSelFail cases
    time_t resetTimeStatEndcAddDetailedCpFail;
    time_t resetTimeStatEndcAddSpCellSelFail;

    // the variables from PLDCellStatus
    uint32_t numOfTotalSymbols;
    uint32_t numOfUlSymbols;
    uint32_t numOfDlSymbols;

    struct mco_s
    {
        bool interRatPccChangePerCell;
        uint16_t dlLowBwThresholdForInterRat;
        uint16_t ulLowBwThresholdForInterRat;
    } multiCarrierOperation;

#ifdef NEW_HOST_SIM
    struct mockTrafficSteeringConfig_s
    {
        bool enabled;
        double min;
        double max;
        double variableA;
        double variableB;
        double variableC;
        double variableD;
    } mockTrafficSteeringConfig;
#endif

    enumNrLbmConfigurationIndex_type nrLbmConfigurationIndex;
    nrSammCellConfig_type sammConfig;
    trafficSteeringConfig_type  tsmConfig;
    highSpeedUeMobility_type highSpeedUeMobility;  // SVR26A FGR-MC1026
    mfbiConfig_type mfbiConfig;
    vonrControlInfoPerCell_type vonrControlInfo;  // SVR26A FGR-SV0201
    ueSpeedStateMobilityConfig_type ueSpeedStateMobilityConfig; // SVR26B FGR-MC1026:110
    bool isCellHighSpeed;   // SVR26A FGR-MC1026:FR101, FGR-MC1032:FR100
    lbmSpecificMeas_type lbmSpecificMeasurementData;
    multipleBwInfo_type multiBwInfo;

    // ------------------- !!  PLEASE READ ABOUT THIS  !! -----------------------
    // Objects below this line are synched separately
    // by FnVCCB_BackupCellNbrInfo, FnVCCB_BackupCellEutraNbrInfo
    // If you want add items in VccbCellInfo_type, add above Nbr[] and eutraNbr[].
    // --------------------------------------------------------------------------
    nbrCellInfo_type Nbr[MAX_NBR_PER_CELL];
    nbrEutraCellInfo_type eutraNbr[MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL];
    // ------------------- !! PLEASE DON'T ADD IT BELOW !! ----------------------
} VccbCellInfo_type;

/**
 * @brief enum to describe Overload Alarm State
 */
typedef enum
{
    OL_CLEARED = 0, /**< No overload */
    OL_MINOR,       /**< Minor overload */
    OL_MAJOR,       /**< Major overload */
    OL_CRITICAL     /**< Critical overload */
} overloadAlarmState_t;

typedef struct
{
    uint8_t status;
    uint32_t enbCI;      // eNB CI (Including enbId), BIT STRING (SIZE (28))
    uint32_t gnbCellId;  // gNB Cell Identity (not include gnbId)
} manualMappingInfo_type;

typedef struct
{
    uint8_t status;
    uint16_t ueInactivityTimer;
    uint16_t drbInactivityTimerEntries[MAX_QCI_VALUE];
} spidBasedInactivityList;

typedef struct
{
    uint8_t status;
    uint16_t ueInactivityTimer;
    uint16_t drbInactivityTimerEntries[MAX_QCI_VALUE];
    spidBasedInactivityList spidBasedUserInactivityEntries[MAX_SPID_VALUE + 1];
} inactivityDataProfile_type;

#define MAX_NR_FR_NUM 2

typedef struct
{
    uint8_t rrcTimeToWait;              // rrc-time-to-wait
    uint8_t rrcTimeToWaitAmfReloc;      // rrc-time-to-wait-amf-reloc
    uint16_t rrcUeInformationResponse;  // rrc-ue-information-response

    uint8_t mobilityTriggeringTimer;  // NR CONNECTED MOBILITY T4

    uint16_t rrcMRWaitForRedirection;  // rrc-measurement-report-wait-for-redirection
    uint16_t internalRreTimeToWait;    // internal-reestablishment-time-to-wait
    uint16_t internalRreTimeToWaitForVonr;    // internal-reestablishment-time-to-wait

    uint16_t internalIratRedirectTimeForAccessControl;  // irat-redirection-time-for-access-control

    uint16_t f1UeContextSetup;         // f1-ue-context-setup
    uint16_t f1UeContextModification;  // f1-ue-context-modification
    uint16_t f1UeContextRelease;       // f1-ue-context-release
    // uint16_t f1AccessSuccess;          // f1-access-success, It is cell timer

    uint16_t e1BearerContextSetup;         // e1-bearer-context-setup
    uint16_t e1BearerContextModification;  // e1-bearer-context-modification
    uint16_t e1BearerContextRelease;       // e1-bearer-context-release

    uint16_t ngInitialContextSetup;      // ng-initial-context-setup
    uint16_t ngUeContextRelease;         // ng-ue-context-release
    uint16_t ngPathSwitch;               // ng-path-switch
    uint16_t ngPduSessionModifyConfirm;  // ng-pdu-session-modify-confirm
    uint16_t ngNrppaOndemand;            // ng-nrppa-ondemand

    uint16_t ngRelocPrep;  // ng-reloc-prep
    uint16_t xnRelocPrep;  // xn-reloc-prep

    uint16_t ngRelocOverall;  // ng-reloc-overall
    uint16_t xnRelocOverall;  // xb-reloc-overall

    uint16_t ngHandoverComplete;        // ng-handover-complete
    uint16_t xnHandoverComplete;        // xn-handover-complete
    uint16_t intraGnbHandoverComplete;  // intra-gnb-handover-complete

    uint16_t xnRetrieveUeContext;     // xn-retrieve-ue-context
    uint16_t xnUeContextRelease;      // xn-ue-context-release
    uint16_t xnSnInitSnModification;  // xn-sn-init-sn-modification
    uint16_t xnSnInitSnRelease;       // xn-sn-init-sn-release
    uint16_t xnSnChangeConfirm;       // xn-sn-change-confirm
    uint16_t xnSnAddition;            // xn-sn-addition
    uint16_t xnMnInitSnModification;  // xn-mn-init-sn-modification
    uint16_t xnMnInitSnRelease;       // xn-mn-init-sn-release
    uint16_t xnSnStatusTransfer;      // xn-sn-status-transfer
    // uint16_t xnHandoverSuccess;       // xn-ho-success, It is cell timer

    uint16_t iratMeasTimerForSaPriorization;   // irat-measurement-timer-for-sa-prioritization-using-wait-timer
    uint16_t waitTimerForHighestFreqPriority;  // NR CONNECTED MOBILITY T5

    uint32_t xnDcPrep;     // xn-dc-prep
    uint32_t xnDcOverall;  // xn-dc-overall

    uint32_t measRelTime;  // /timer-info/meas-rel-time // NR_CONN_MC_23A

    uint32_t x2DcOverall;                      // /timer-info/x2-dc-overall
    uint16_t x2SnStatusTransfer;               // /timer-info/x2-sn-status-transfer
    uint16_t x2UeContextRelease;               // /timer-info/x2-ue-context-release
    uint16_t x2SgNbReleaseConfirm;             // /timer-info/x2-sg-nb-release-confirm
    uint16_t endcE1BearerContextSetup;         // /timer-info/endc-e1-bearer-context-setup
    uint16_t endcE1BearerContextModification;  // /timer-info/endc-e1-bearer-context-modification
    uint16_t endcE1BearerContextRelease;       // /timer-info/endc-e1-bearer-context-release
    uint16_t endcF1UeContextSetup;             // /timer-info/endc-f1-ue-context-setup
    uint16_t endcF1UeContextRelease;           // /timer-info/endc-f1-ue-context-setup-release
    uint16_t endcF1UeContextModification;      // /timer-info/endc-f1-ue-context-setup-modification
    uint16_t cpLongCallDetectTime;             // /timer-info/cp-long-call-detect-time
} yangTimer_type;

typedef struct
{
    uint8_t usage;
    char profileName[MAX_RRC_SA_TIMER_PROFILE_NAME_LENGTH + 1];
    uint16_t rrcSetup;                            // rrc-setup
    uint16_t rrcReestablish;                      // rrc-reestablishment
    uint16_t rrcReconfig;                         // rrc-reconfig
    uint16_t rrcResume;                           // rrc-resume
    uint16_t rrcSecurityModeCommand;              // rrc-security-mode-command
    uint16_t rrcUeCapabilityEnquiry;              // rrc-ue-capability-enquiry
    uint16_t rrcUlInformationTransferTimeToWait;  // rrc-ul-information-transfer-time-to-wait
    uint16_t f1RrcDeliveryReportTimeToWait;       // f1-rrc-delivery-report-time-to-wait
} RrcSaTimerProfile_type;

typedef struct
{
    uint8_t usage;
    uint16_t rrcReconfig;  // rrc-reconfig
} RrcEndcTimerProfile_type;

typedef struct nasMessage_s
{
    uint16_t length;
    uint8_t data[MAX_NGAP_NAS_LEN];
} nasMessage_type;

typedef struct nasInformation_s
{
    uint16_t nasIndex;
    nasMessage_type nasMessage[VCCB_MAX_NAS_NUM];
} nasInformation_type;

/**
 * @brief mTMSI type
 */
#define MAX_5G_TMSI_LEN 4  // OCTET STRING (SIZE(4))
typedef struct
{
    uint32_t n;                    /**< FiveG_TMSI digit length */
    uint8_t data[MAX_5G_TMSI_LEN]; /**< FiveG_TMSI */
} tmsi_type;

/**
 * @brief fiveG-S-TMSI type
 */
typedef struct
{
    uint16_t amfSetPointer; /**< AMF SET ID(10)+AMF Pointer(6) */
    uint16_t reserved;      /**< reserved field */
    tmsi_type fiveGTmsi;    /**< fiveG_TMSI */
} fiveGTmsi_type;

#define MAX_RAND_VAL_LEN 5  // BIT STRING (SIZE (39))
typedef struct
{
    uint32_t n;                     /**< randomValue digit length */
    uint8_t data[MAX_RAND_VAL_LEN]; /**< randomValue */
} randomVal_type;

typedef uint16_t pci_type;   /**< PCI */
typedef uint16_t crnti_type; /**< CRNTI */
typedef uint64_t irnti_type; /**< IRNTI */

/**
 * @brief IMEI type
 */
typedef struct
{
    uint32_t n;        /**< IMEI digit length */
    uint8_t digit[16]; /**< Type Allocation Code (TAC) : 8 digits , Serial Number (SNR) : 6 digits,* Software Version
                          Number (SVN) : 2 digits */
} imei_type;

typedef struct
{
    uint32_t duUEid;
    uint16_t f1Idx;
} duHoInfo_type;

typedef struct
{
    uint32_t xnCallId;
    uint16_t xnIdx;
} xnInfo_type;

typedef struct
{
    uint64_t reestabCellIdentity;
    uint8_t keyGNB_Star[KEY_VNB_LENGTH];
    uint16_t shortMacI;
} reestablishNCellInfo_type;

#define MAX_OF_DU_RELEASE 4 //2 -> 4

typedef struct
{
    enumReestablishType_type reestablishType;

    uint16_t isTargetGnb:1;
    uint16_t isNrdcCall:1;
    uint16_t isIntraGnbPlmnChg:1;
    uint16_t reserved:13;

    plmnId_type swappedPlmn; // to recover swapped PLMN during IntraGnb RRE

    uint16_t rreGnbIdx;
    uint8_t rreMatchType;

    uint8_t firstOldCellFlag;
    uint16_t firstOldCellNum;
    uint16_t oldF1Idx;
    uint16_t oldCellNum;
    uint16_t oldCellBand;
    uint32_t oldDuUeId;
    uint8_t oldKeyGNB[KEY_VNB_LENGTH];

    uint16_t srcPhyCellId;
    uint16_t srcIntegrityAlgo;
    uint16_t srcCipherAlgo;
    crnti_type srcCRNTI;

    uint8_t numReestabNCell;
    reestablishNCellInfo_type reestabNCellInfo[MAX_CELL_PREPARED_FOR_HO + 1];

    uint8_t duReleaseCount;                          // count of duReleaseInfo
    duHoInfo_type duReleaseInfo[MAX_OF_DU_RELEASE];  // duReleaseInfo

    uint8_t xnReleaseCount;     // count of xnReleaseInfo
    xnInfo_type xnReleaseInfo;  // xnReleaseInfo

    uint8_t numRtrvUeCtxtReqSendToGnb;

    // received RRE message context
    uint16_t reestCause;
    crnti_type reestCRNTI;
    uint16_t reestPhysCellId;
    uint16_t reestShortMacI;
    cgi_type reestNewNRCGI;

    uint8_t reestCount_byReconfigFail;  // to prevent consecutive RRE by ReconfigFailure

    upmStatInfoForCall_type upmStatInfo;

} reestablishInfo_type;

typedef struct
{
    uint8_t isDRBIntegrityProtectionEnabled : 1;
    uint8_t isRRCResumeRequestReceived      : 1; // received RRCResumeRequest1 or XN_RetrieveUEContextRequest message context
    uint8_t ueContextRetrievalFail          : 1; // set true when the case1~3 shown above happens.
    uint8_t isRrcReleaseRelayed             : 1;
    uint8_t goingToRRCIdleFlag              : 1;
    uint8_t ranPaged                        : 1;
    uint8_t rrcFallBackFlag                 : 1; // to use not send paging when NG released when old VCCB job is released by intra-gNB fallback
    uint8_t fullConfigRequiredFlag          : 1; // to set fullConfig flag in RRCResume

    uint8_t actionInSNRelease               : 2; // to set drb inactivity timer to 1 forcibly while disconnecting SN
    uint8_t preventSNAddFlag                : 1; // to avoid continuous SN-addition while disconnecting SN
    uint8_t reserved                        : 5;

    crnti_type resumeCRNTI;

    uint16_t srcIntegrityAlgo;
    uint16_t srcCipherAlgo;
    uint16_t resumeMacI;
    uint16_t resumePhysCellId;

    uint32_t targetCellSsbArfcn;
    enumRRCResumeType_type resumeType;

    timerInfo_type timerXnRelocOverall;
    timerInfo_type timerWaitE1InactNoti;    // use 1.5sec

    irnti_type resumeIRNTI;  // uint64_t(use 40bits)
    cgi_type resumeNRCGI;
} RrcResumeInfo_type;

typedef struct
{
    uint8_t usage;        // CI_no_use/CI_use
    uint8_t priority;     // 1~3. Higher value means higher priority.
    uint8_t x2Reporting;  // enumx2Reproting_type (0: Noti, 1:Release_Required)
    uint8_t reserved;
} FreqBasedUserInactivityGroup_type;

typedef struct
{
    uint8_t usage;                // CI_no_use/CI_use
    uint8_t frequencyGroupIndex;  // 1~3
    uint32_t ssbArfcn;            // 0~3279165
} FreqBasedUserInactivityList_type;

typedef struct
{
    uint8_t featureSwitch;  // 0: disable, 1: enable.
    FreqBasedUserInactivityGroup_type
        freqGroup[VCCB_MAX_USER_INACT_FREQGROUP];  // index 0 : default Group, index 1~3 : Config Group.
    FreqBasedUserInactivityList_type freqList[VCCB_MAX_USER_INACT_FREQLIST];
} FreqBasedUserInactivityControl_type;

typedef struct
{
    uint8_t usage;               // CI_no_use/CI_use
    uint16_t rfsp;               // 1 ~ 256
    uint16_t ueInactivityTimer;  // rfsp-based-user-inactivity-entries/ue-inactivity-timer
    uint16_t drbInactivityTimerEntries[MAX_5QI_VALUE];
} rfspBasedInactivityList_type;

typedef struct
{
    // YANG: sa-data-inactivity-per-cell-profile-entries
    uint8_t usage; // CI_no_use/CI_use
    uint16_t ueInactivityTimer; // ue-inactivity-timer
    uint16_t drbInactivityTimerEntries[MAX_5QI_VALUE]; // drb-inactivity-timer-entries
    rfspBasedInactivityList_type rfspList[VCCB_MAX_USER_INACT_RFSP_LIST]; // rfsp-based-user-inactivity-entries
} saDataInactProfile_type;

typedef struct
{
    uint8_t featureSwitch;  // 0: disable, 1: enable
    rfspBasedInactivityList_type rfspList[VCCB_MAX_USER_INACT_RFSP_LIST];
} rfspBasedUserInactivityControl_type;

typedef struct
{
    uint8_t usage;     // ENUM:: enumUsage_type
    uint8_t ueIdType;  // ENUM:: enumUeIdType
    fiveGTmsi_type sTmsi;
    randomVal_type randVal;
    crnti_type cRNTI;
    IMSI_type imsi;

    irnti_type iRNTI;  // uint64_t(use 40bits)
    crnti_type suspendedCRNTI;
    uint16_t suspendedPCI;
} callUeId_type;

typedef struct
{
    uint16_t encryptionCapa; /* Bit Masking */
    uint16_t integrityCapa;  /* Bit Masking */

    struct
    {
        uint16_t encryptionCapa; /* Bit Masking */
        uint16_t integrityCapa;  /* Bit Masking */
    } eutra;

    // SAMSUNG SPECIFIC START
    XNAP_Z_IMSI_type zImsi;
    // SAMSUNG SPECIFIC END
} ueSecurityCapability_type;

typedef enum
{
    ci_maxROHC_Sessions_cs2 = 0,      /* display_name : "Max_2" yang_display_name       : "cs2" */
    ci_maxROHC_Sessions_cs4 = 1,      /* display_name : "Max_4" yang_display_name       : "cs4" */
    ci_maxROHC_Sessions_cs8 = 2,      /* display_name : "Max_8" yang_display_name       : "cs8" */
    ci_maxROHC_Sessions_cs12 = 3,     /* display_name : "Max_12" yang_display_name      : "cs12" */
    ci_maxROHC_Sessions_cs16 = 4,     /* display_name : "Max_16" yang_display_name      : "cs16" */
    ci_maxROHC_Sessions_cs24 = 5,     /* display_name : "Max_24" yang_display_name      : "cs24" */
    ci_maxROHC_Sessions_cs32 = 6,     /* display_name : "Max_32" yang_display_name      : "cs32" */
    ci_maxROHC_Sessions_cs48 = 7,     /* display_name : "Max_48" yang_display_name      : "cs48" */
    ci_maxROHC_Sessions_cs64 = 8,     /* display_name : "Max_64" yang_display_name      : "cs64" */
    ci_maxROHC_Sessions_cs128 = 9,    /* display_name : "Max_128" yang_display_name     : "cs128" */
    ci_maxROHC_Sessions_cs256 = 10,   /* display_name : "Max_256" yang_display_name     : "cs256" */
    ci_maxROHC_Sessions_cs512 = 11,   /* display_name : "Max_512" yang_display_name     : "cs512" */
    ci_maxROHC_Sessions_cs1024 = 12,  /* display_name : "Max_1024" yang_display_name    : "cs1024" */
    ci_maxROHC_Sessions_cs16384 = 13, /* display_name : "Max_16384" yang_display_name   : "cs16384" */
} enumMaxROHCsessions_type;

typedef enum
{
    ci_maxEHC_Sessions_cs2 = 0,         /* display_name : "Max_2" yang_display_name     : "cs2" */
    ci_maxEHC_Sessions_cs4 = 1,         /* display_name : "Max_4" yang_display_name     : "cs4" */
    ci_maxEHC_Sessions_cs8 = 2,         /* display_name : "Max_8" yang_display_name     : "cs8" */
    ci_maxEHC_Sessions_cs16 = 3,        /* display_name : "Max_16" yang_display_name    : "cs16" */
    ci_maxEHC_Sessions_cs32 = 4,        /* display_name : "Max_32" yang_display_name    : "cs32" */
    ci_maxEHC_Sessions_cs64 = 5,        /* display_name : "Max_64" yang_display_name    : "cs64" */
    ci_maxEHC_Sessions_cs128 = 6,       /* display_name : "Max_128" yang_display_name   : "cs128" */
    ci_maxEHC_Sessions_cs256 = 7,       /* display_name : "Max_256" yang_display_name   : "cs256" */
    ci_maxEHC_Sessions_cs512 = 8,       /* display_name : "Max_512" yang_display_name   : "cs512" */
    ci_maxEHC_Sessions_cs1024 = 9,      /* display_name : "Max_1024" yang_display_name  : "cs1024" */
    ci_maxEHC_Sessions_cs2048 = 10,     /* display_name : "Max_2048" yang_display_name  : "cs2048" */
    ci_maxEHC_Sessions_cs4096 = 11,     /* display_name : "Max_4096" yang_display_name  : "cs4096" */
    ci_maxEHC_Sessions_cs8192 = 12,     /* display_name : "Max_8192" yang_display_name  : "cs8192" */
    ci_maxEHC_Sessions_cs16384 = 13,    /* display_name : "Max_16384" yang_display_name : "cs16384" */
    ci_maxEHC_Sessions_cs32768 = 14,    /* display_name : "Max_32768" yang_display_name : "cs32768" */
    ci_maxEHC_Sessions_cs65536 = 15,    /* display_name : "Max_65536" yang_display_name : "cs65536" */
} enumMaxEHCsessions_type;

typedef struct
{
    BOOL profile0001;   /* RTP/UDP/IP */
    BOOL profile0002;   /* UDP/IP */
    BOOL profile0003;   /* ESP/IP */
    BOOL profile0004;   /* IP */
    BOOL profile0006;   /* TCP/IP */
    BOOL profile0101;   /* RTP/UDP/IP */
    BOOL profile0102;   /* UDP/IP */
    BOOL profile0103;   /* ESP/IP */
    BOOL profile0104;   /* IP */
    uint32_t reserved;  // future Extension
} profiles_type;

typedef struct
{
    profiles_type supportedROHCprofiles;
    uint8_t maxROHCsessions;            // ENUM:: enumMaxROHCsessions_type
    uint8_t continueRohcCapable;
    uint16_t ulOnlyRohcCapable    : 1;  // ENUM:: BOOL /FGR-BC0311
    uint16_t symmetricRohcCapable : 1;  // BOOL FGR-BC0312
    uint16_t curAllocatedSNRohcCidCalcFlag : 1;  // flag for already calculating current allocated SN RoHC CID
    uint16_t reserved             : 13;
    uint16_t tempAllocatedRohcCid;
    uint16_t curAllocatedRohcCid;
    uint16_t curAllocatedSNRohcCid;
    uint16_t isRetryDueToUPFailure;
} ueNrRohcCapability_type;

typedef struct
{
    uint8_t maxEHCsessions;       // ENUM:: enumMaxEHCsessions_type
    uint8_t ehcCapable;            // BOOL FGR-BC0314
    uint8_t continueEhcCapable;
    uint8_t jointEhcRoHcCapable;
    uint16_t tempAllocatedEhcCid;
    uint16_t curAllocatedEhcCid;
    uint16_t isEHCRetryDueToUPFailure;
} ueNrEhcCapability_type;

typedef struct ScsBitFlag_s
{
    uint8_t scs_15: 1;
    uint8_t scs_30: 1;
    uint8_t scs_60: 1;
    uint8_t scs_120: 1;
} scsBitFlag_type;

typedef struct
{
    uint16_t scs_15kHz;
    uint16_t scs_30kHz;
    uint16_t scs_60kHz;
    scsBitFlag_type scs_flag;
} fr1_type;

typedef struct
{
    uint8_t scs_60kHz;
    uint8_t scs_120kHz;
    scsBitFlag_type scs_flag;
} fr2_type;

typedef struct
{
    uint8_t fr_flag;  // ENUM:: enumFrequencyType_type
    union
    {
        fr1_type fr1;
        fr2_type fr2;
    } frType;
} channelBWs_type;

typedef struct
{
    uint16_t bandNR;
    uint8_t rateMatchingLTE_CRS                  : 1;  //     FLAG_ON / FLAG_OFF
    uint8_t isBandAllowedByBandCombinations      : 1;  //     FLAG_ON / FLAG_OFF
    uint8_t isBandSupportedAsPcellBand           : 1;  //     FLAG_ON / FLAG_OFF - UL and DL
    uint8_t isBandNrCaCapable                    : 1;  //     FLAG_ON / FLAG_OFF - UL and DL + other nr band in BC
    uint8_t isCondHandoverCapable                : 1;  //     FLAG_ON / FLAG_OFF
    uint8_t isCondHandoverFailureCapable         : 1;  //     FLAG_ON / FLAG_OFF
    uint8_t isCondHandoverTwoTriggerEventCapable : 1;  //     FLAG_ON / FLAG_OFF

    uint8_t ue_PowerClass       : 2;  //     enumUePowerClass_type
    uint8_t ue_PowerClass_v1610 : 2;  //     enumUePowerClass_v1610_type

    uint8_t channelBWs_DL_present_flag : 1; //     FLAG_ON / FLAG_OFF
    uint8_t channelBWs_UL_present_flag : 1; //     FLAG_ON / FLAG_OFF

    uint8_t rachEarlyTAMeasurement_r18 : 4;  // 1 ~ 8 SVR25B IoDT FGR-MC1034
    uint8_t ltmMCGIntraFreq_r18        : 1;  // FLAG_ON / FLAG OFF SVR26A FGR-MC1035:FR100
    uint8_t ltmBeamIndicationJointTCI_r18_present: 1;  // present SVR26B FGR-MC1034:FR100
    uint8_t ltmMacCeJointTCI_r18_present         : 1;  // present SVR26B FGR-MC1034:FR100
    uint8_t ul_GapFR2_r17              : 1;  // FLAG_ON / FLAG_OFF

    channelBWs_type channelBWs_DL;
    channelBWs_type channelBWs_UL;
    channelBWs_type channelBWs_DL_v1590;
    channelBWs_type channelBWs_UL_v1590;
} bandNrUeCapa_type;

typedef struct
{
    uint8_t sdPresent   : 1;
    uint8_t fNeedModify : 1;
    uint8_t reserved    : 6;

    union
    {
        struct
        {
#if __BYTE_ORDER == __LITTLE_ENDIAN
            uint32_t sd : 24;  // init 0xFFFFFF (The SD field has a reserved value "no SD value associated with the SST"
                               // defined as hexadecimal FFFFFF.)
            uint32_t sst : 8;
#else
            uint32_t sst : 8;
            uint32_t sd  : 24;
#endif
        };
        uint32_t sstSd;
    };
} callSNSSAI_type;

typedef struct
{
    uint8_t UECtxModAMBRPresent;
    uint8_t fNeedModify_aggrMbrDl : 1, fNeedModify_aggrMbrUl : 1, rsvd : 6;
    uint64_t aggrMbrDl; /* Aggregate Downlink Maximum Bit Rate */
    uint64_t aggrMbrUl; /* Aggregate Uplink Maximum Bit Rate */
    uint64_t subAmbrDl; /* Subscribed Aggregate Downlink Maximum Bit Rate */
    uint64_t subAmbrUl; /* Subscribed Aggregate Uplink Maximum Bit Rate */
} ambrInfo_type;

typedef struct
{
    callSNSSAI_type sNssai;
    uint64_t bitRateDl;
    uint64_t bitRateUl;
    uint8_t usage;
} ueSliceMbrList_type;

typedef struct
{
    ueSliceMbrList_type detSliceMbr[MAX_NR_OF_SLICE_MBR];  // determined Slice Maximum Bit Rate
    ueSliceMbrList_type subSliceMbr[MAX_NR_OF_SLICE_MBR];  // subscribed Slice Maximum Bit Rate
    ueSliceMbrList_type sliceGfbr[MAX_NR_OF_SLICE_MBR];    // Guaranteed Flow Bit Rate (for SA or NRDC MN)
    ueSliceMbrList_type sliceGfbrSN[MAX_NR_OF_SLICE_MBR];  // Guaranteed Flow Bit Rate (for NRDC SN)
    //NRDC
    uint64_t ueSliceMbrDlSN[MAX_NR_OF_SLICE_MBR];  // for SN
    uint64_t ueSliceMbrUlSN[MAX_NR_OF_SLICE_MBR];  // for SN
    uint64_t ueSliceMbrDlMN[MAX_NR_OF_SLICE_MBR];  // for MN
    uint64_t ueSliceMbrUlMN[MAX_NR_OF_SLICE_MBR];  // for MN
    nrdcUeSliceMbrConfig_type nrdcUeSliceMbrCfg;

    uint8_t fNeedModifySN           :1; // set when UE Slice Maximum Bit Rate List needs to be send to SN
    uint8_t isSliceMBRListProvided  :1; // set when UE Slice Maximum Bit Rate List is provided for the UE
    uint8_t fNeedModifyDl           :1; // set when UE Slice Maximum Bit Rate List needs to be send to UP
    uint8_t fNeedModifyUl           :1; // set when UE Slice Maximum Bit Rate List needs to be send to DU
    uint8_t ueCtxModSliceMBRPresent :1; // set when UE Slice Maximum Bit Rate List is provided in NG UeCtxtModReq
} sliceMbrInfo_type;

typedef struct
{
    uint8_t rfspPresent : 1;
    uint8_t rfspChanged : 1;                    // (default: FALSE)
    uint8_t subscriberProfileNeedMeasReconfig;  // ENUM:: BOOL
    uint16_t prevSubscriberProfile; // SubscriberProfileIDforRFP ::= INTEGER (1..256)
    union
    {
        uint16_t subscriberProfile;  // 9_2_25 TS 36473, SubscriberProfileIDforRFP ::= INTEGER (1..256)
        uint16_t indexToRFSP;                                 // 9_3_1_61 TS 38413, INTEGER (1..256, ...)
    };
} rfspInfo_type;

// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< NEDC
typedef struct
{
    uint8_t ratType;  // enumRAT_type : ci_eutra(0), ci_nr(5)
    uint8_t rsvd;
    uint16_t band;

    union
    {
        ueCapaNrBandReqLimitInfo_type nrBandReqLimitInfo;
        ueCapaEutraBandReqLimitInfo_type eutraBandReqLimitInfo;
    };
} freqBandFilter_type;

typedef struct
{
#define MAX_FREQBAND_FILTER 128
    uint16_t num;
    freqBandFilter_type band[MAX_FREQBAND_FILTER];
} freqBandListFilter_type;

// <<< NRDC
typedef struct
{
    enumUsage_type usage;

    uint8_t plmnIndex;
    uint8_t fiveQi;
    uint8_t arp;
    uint8_t rsvd;
    callSNSSAI_type sNssai;
    int8_t terminationPoint;
    int8_t mnBearerType;
    int8_t snBearerType;
} NrdcControlInfo_type;

typedef enum
{
    UL_TRF_MON_Start = 0,
    UL_TRF_MON_Stop
} enumUlTrafficMonitorCommand_type;

typedef struct
{
    uint32_t outstandingCellNum;
    uint8_t action;  // start:0, stop:1
    uint8_t present;
} NrdcUlTrafficStatusRptCfg_type;

typedef struct
{
    NrdcUlTrafficStatusRptCfg_type newItem;
    NrdcUlTrafficStatusRptCfg_type installedItem;
} NrdcUlTrafficMonitor_type;

typedef struct
{
    plmnId_type plmnId;
    callSNSSAI_type sNssai;
    uint8_t fiveQi;
    uint8_t arp;
} MrdcBearerTypeProperty_type;

typedef union
{
    struct
    {
        uint8_t omitEN_DC_present                    : 1;
        uint8_t includeNR_DC_present                 : 1;
        uint8_t includeNE_DC_present                 : 1;
        uint8_t uplinkTxSwitchRequest_r16_present    : 1;
        uint8_t fallbackGroupFiveRequest_r17_present : 1;  // SVR26A FGR-CC3103
        uint8_t rsvd                                 : 3;
    };
    uint8_t value;
} RequestFilterCommon_type;

typedef union
{
    struct
    {
        unsigned long long noofMnTermMcg    : 8;
        unsigned long long noofMnTermSplit  : 8;
        unsigned long long noofSnTermScg    : 8;
        unsigned long long noofSnTermSplit  : 8;
        unsigned long long noofMnTermScg    : 8; /* not used */
        unsigned long long noofSnTermMcg    : 8; /* not used */
        unsigned long long noofUnknownType  : 8;
        unsigned long long reserved         : 8;
    };
    unsigned long long value;
} nrdcBearerCnt_type;

typedef struct
{
    nrdcBearerCnt_type  selectedBearerCnt;
    nrdcBearerCnt_type  reqBearerCnt;
    nrdcBearerCnt_type  bearerCnt;
} MrdcBearerTypeCnt_type;
/// >>>

typedef struct
{
    uint8_t fr1fdd_FR1TDD_CA_SpCellOnFR1FDD_supported : 1;
    uint8_t fr1fdd_FR1TDD_CA_SpCellOnFR1TDD_supported : 1;
    uint8_t fr1fdd_FR2TDD_CA_SpCellOnFR1FDD_supported : 1;
    uint8_t usageSpCellPlacement                      : 1;
} carrierAggregationVariant_type;

typedef struct
{
    uint8_t dynamicHARQACKCodebookSupported : 1;
} PhyParametersCommon_type;

typedef struct
{
    union
    {
        struct
        {
            uint32_t pdcch_BlindDetectionCA : 1;
            uint32_t reserved               : 31;
        };

        uint32_t value;
    } present;

    uint16_t pdcch_BlindDetectionCA;
    // other parameters are TBD...
} PhyParametersFrxDiff_type;

typedef struct
{
    union
    {
        struct
        {
            uint32_t phyParametersCommonPresent : 1;
            uint32_t phyParametersFrxDiff       : 1;
            uint32_t reserved                   : 30;
        };

        uint32_t value;
    } present;

    PhyParametersCommon_type phyParametersCommon;
    PhyParametersFrxDiff_type phyParametersFrxDiff;
    // other parameters are TBD...
} PhyParameters_type;

typedef struct
{
    uint8_t splitSRB_WithOneUL_Path      : 1;
    uint8_t splitDRB_withUL_Both_MCG_SCG : 1;
    uint8_t srb3_support                 : 1;
} VccbUeGeneralParametersMrdcXddDiff_type;

typedef struct
{
    VccbUeGeneralParametersMrdcXddDiff_type general;
} VccbUeMrdcCapaAddXddMode_type;

/* Buffer to store various messages from DU/eNB */
typedef struct
{
    uint16_t numocts;
    uint8_t data[MAX_DAT_LEN];
} msgContainer_type;

typedef struct
{
    uint32_t numocts;
    uint8_t data[MSG_BIG_DAT_LEN];
} bigMsgContainer_type;

typedef struct
{
    unsigned short length; /* number of significant bits -> 64*/
    unsigned char value[MASKED_IMEISV_BUF_SIZE];
} VccbMaskedIMEISV_type;

typedef struct
{
    callUeId_type ueId;
    rfspInfo_type rfsp; /* RAT/Frequency Selection Priority */
    ambrInfo_type ambr;
    uint64_t aggrMbrDl;            /* Aggregate Downlink Maximum Bit Rate */
    uint64_t aggrMbrUl;            /* Aggregate Uplink Maximum Bit Rate */
    sliceMbrInfo_type sliceMbrInfo;
    uint32_t selectedPlmnIdentity; /* For Network Sharing */
    plmnId_type servedPlmn;
    plmnId_type selectedPlmnfromMN; /* NR-DC SN will use this attribute received from MN */
    reestablishInfo_type reestablishInfo;
    RrcResumeInfo_type rrcResumeInfo;

    uint8_t rrcTransactionId;    /* RRC Transaction ID(0~3) */
    uint8_t establishmentCause;  // ENUM:: enumEstablishmentCause_type

    // ueCapabilitiesRATcontainer_type           ueContainer5gra;
    ueSecurityCapability_type ueSecurityCapa;
    // uint8_t securityModFlag;
    struct VccbSourceSecurityAlgorithmConfig_s  // FGR BC0323 - Used for storing source security algorithm configuration
    {
        uint16_t srcIntegrityAlgo;
        uint16_t srcCipherAlgo;
        uint8_t sourceSecurityAlgoFlag;
        uint8_t reserved;
    } srcGnbSecurityAlgo;
    uint8_t securityModFlag;
    uint8_t snKeyChangeWOMnKeyChange;  // SN Key Change only without MN key change.
    uint8_t reserved;
    uint8_t duConfQuery;
    uint8_t
        scgConfigQuery;  // When NR is MN, control flag for requesting Config Query to S-Node (NE-DC: SeNB, NR-DC: SgNB)
    // uePhysicalCapability_type                 uePhyCapa;
    // ueRFCapability_type                       ueRFCapa;
    // ueMeasurementCapability_type              ueMeasCapa;
    // enumUeVendor_type                         ueVendor;
    uint8_t receivedUeCapaFlag;

    // TODO: need to design below DB : It's DB to relay to XN.
    // store it with NGAP LIB format
    struct VccbUeNgBuffer_s
    {
        struct
        {
            uint8_t redirectionVoiceFallbackPresent : 1;
        } m;

        uint8_t redirectionVoiceFallbackValue;
    } ngapBuf;
    // ---------------------------------------------------------

    struct VccbUeMaskedIMEISV_s
    {
        uint8_t maskedIMEISVPresent             : 1;
        VccbMaskedIMEISV_type maskedIMEISV;
    } imeisvBuf;
    // FGR-BC0311 : ULRoHC
    ueNrRohcCapability_type roHCCapability;
    // FGR-BC0314 : EHC
    ueNrEhcCapability_type ehcCapability;

    // UL RRC Segmentation
    // UE includes this IE in RRC Setup Complete if it supports ul rrc segmentation
    // 'ul_RRC_Segmentation_r16' in 'NRRRC_UE_NR_Capability_v1690'
    uint8_t ueSupportUlRrcSegment;

    struct VccbUeCapa_s
    {
        struct VccbNrCapa_s
        {
            struct VccbUeNrCapaPdcp_s
            {
                uint32_t outOfOrderDelivery : 1, shortSN : 1;
            } pdcp;

            struct VccbUeNrCapaRf_s
            {
                uint16_t srsSwitchingTimeRequested_present : 1;
                uint16_t bw90MHzSupportedDl                : 1;
                uint16_t bw90MHzSupportedUl                : 1;
                uint16_t extendedBand_n77_r16              : 1;
                uint16_t extendedBand_n77_2_r17            : 1;
                uint16_t reserved                          : 11;
                uint8_t nrOfBands;
                bandNrUeCapa_type supportedBandListNR[MAX_NUM_UECAPA_NR_BANDS];
            } rf;

            struct VccbUeNrCapaMeasAndMobCommon_s
            {
                uint32_t supportedGapPattern        : 22;
                uint8_t cgi_Reporting               : 1;
                uint8_t independentGapConfig        : 1;
                uint8_t eventB_MeasAndReport        : 1;
                uint8_t periodicEUTRA_MeasAndReport : 1;
                uint8_t eutra_cgi_Reporting         : 1;
                uint8_t eutra_cgi_Reporting_NRDC    : 1;
                uint8_t eutra_cgi_Reporting_NEDC    : 1;
                uint8_t handoverFDD_TDD             : 1;
                uint8_t handoverFR1_FR2             : 1;
                uint8_t nrNeedForGapReportingR16    : 1;
                uint8_t suppGapPatternNRonlyNEDCr16 : 1;
                uint8_t cgi_Reporting_NRDC          : 1;
                uint8_t cgi_Reporting_NEDC          : 1;
                uint8_t eutraAutonomousGapsR16      : 1;
                uint8_t eutraAutonomousGaps_NRDCR16 : 1;
                uint8_t eutraAutonomousGaps_NEDCR16 : 1;
                // Fast RLF Recovery related params - 3gpp: 38.331-g41
                uint8_t pscellT312_NR_DC    : 1;  // for NR-DC configuration
                uint8_t pcellT312_SA        : 1;  // for SA configuration
                uint8_t condHandoverFDD_TDD : 1;
                uint8_t condHandoverFR1_FR2 : 1;
                uint8_t reportAddNeighMeasForPeriodic : 1;
                uint8_t ltm_InterFreq_r18   : 1; // SVR26B FGR-MC1034:FR100
            } measAndMob;

            struct VccbUeNrCapaXdd_s
            {
                struct VccbUeNrCapaMeasAndMobXdd_s
                {
                    uint8_t eventA_MeasAndReport         : 1;
                    uint8_t intraAndInterF_MeasAndReport : 1;
                    uint8_t handoverLTE_5GC              : 1;
                    uint8_t handoverLTE_EPC              : 1;
                    uint8_t handoverInterF               : 1;
                } measAndMob;

                struct VccbUeNrCapaMacXdd_s
                {
                    uint32_t longDRX_Cycle : 1;
                } mac;
            } fddCapa, tddCapa;

            struct VccbUeNrCapaFrx_s
            {
                struct VccbUeNrCapaMeasAndMobFrx_s
                {
                    uint8_t handoverLTE_5GC       : 1;
                    uint8_t handoverLTE_EPC       : 1;
                    uint8_t handoverInterF        : 1;
                    uint8_t ss_SINR_Meas          : 1;
                    uint8_t nrAutonomousGaps      : 1;
                    uint8_t nrAutonomousGaps_ENDC : 1;
                    uint8_t nrAutonomousGaps_NRDC : 1;
                    uint8_t nrAutonomousGaps_NEDC : 1;
                } measAndMob;
            } fr1Capa, fr2Capa;

            struct VccbUeNrCapaEutraBand_s
            {
                uint8_t supportedBandListEutra[MAX_EUTRA_BAND_INDICATOR + 1];
                uint16_t numSupportedBand;
            } eutraBand;

            struct VccbUeNrCapaEutraParam_s
            {
                uint8_t mfbiEUTRA       : 1;
                uint8_t rsSINRMeasEUTRA : 1;
                uint8_t neDC            : 1;
                uint8_t nrHOToENDCr16   : 1;
            } eutraParam;

            // uint8_t eutraFreqMrdcSupport[MAX_NUM_FREQ];

            struct VccbUeNrCapaVoiceOverNRParam_s
            {
                uint8_t imsVoiceOverNR : 1;
                uint8_t fr1VoiceOverNR : 1;
                uint8_t fr2VoiceOverNR : 1;
            } voiceOverNRParam;
            struct VccbUeNrCapaImsParam_s
            {
                uint8_t voiceFallbackIndicationEPS_r16 : 1;
            } imsParam;

            freqBandListFilter_type appliedFreqBandList;

            uint8_t overheatingInd;
            uint8_t accessStratumRelease;  // NRRRC_AccessStratumRelease ver.

            struct VccbNrdcCapa_s  // NRDC
            {
                uint8_t independentGapConfig_support : 1;
                uint8_t nrdcSupport                  : 1;
                uint8_t splitDRB_withUL_Both_MCG_SCG : 1;
                uint8_t srb3_general                 : 1;
                uint8_t rsvd                         : 4;

                VccbUeMrdcCapaAddXddMode_type fddCapaAdd, tddCapaAdd;
            } nrdc;

            RequestFilterCommon_type requestFilterCommon;  // NRDC
            uint8_t rachReportR16;

            struct VccbNrPowerSavParam_s
            {
                uint8_t maxBWPreferenceInd            : 1;
                uint8_t fr1_maxBWPreferenceInd        : 1;
                uint8_t fr2_maxBWPreferenceInd        : 1;
                uint8_t maxCCPreferenceInd            : 1;
                uint8_t maxMIMOLayerPreferenceInd     : 1;
                uint8_t fr1_maxMIMOLayerPreferenceInd : 1;
                uint8_t fr2_maxMIMOLayerPreferenceInd : 1;
                uint8_t releasePreference_r16_support : 1;
            } powerSav;

            struct VccbUEBasedPerfMeasParameters_s
            {
                uint8_t loggedMeasurements : 1;
                uint8_t gnssLocation       : 1;
                uint8_t ulPdcpDelay        : 1;
            } ueBasedPerfMeasParam;
            carrierAggregationVariant_type carrierAggregationVariant;
            PhyParameters_type phyParameters;

            struct VccbUeNrCapaRadioPagingR17_s
            {
                uint8_t radioPagingR17_Flag : 1;
                uint8_t nrofFreqBandIndicatorNR;
                uint8_t bandFilter[(MAX_NUM_NR_BAND + 7) / 8]; // to filter bands that UE supports
            } radioPagingR17;

            struct VccbUeNrCapaMacCommon_s
            {
                uint8_t dummyPresent : 1;
                uint8_t reserved      : 7;
            } macCommon;

            uint8_t ulGapFR2PatternR17 : 4;
        } nr;

        struct VccbMrdcCapa_s
        {
            uint8_t cgi_Reporting                : 1;
            uint8_t independentGapConfig_support : 1;
            uint8_t pscellT312_EN_DC             : 1;
            uint8_t reserved                     : 5;

            VccbUeMrdcCapaAddXddMode_type tddCapaAdd;
            freqBandListFilter_type appliedFreqBandList;
            carrierAggregationVariant_type carrierAggregationVariant;

            struct VccbUeMrdcCapaRf_s
            {
                uint8_t srsSwitchingTimeRequested_present : 1;
                uint8_t reserved                          : 7;
            } rf;
            RequestFilterCommon_type requestFilterCommon; // MRDC
        } mrdc;

        struct VccbSavedInfo_s
        {
            uint8_t isAlreadyNrdcOverload                   :   1;
            uint8_t sendUplinkTxSwitchRequest_r16   :   1;
            uint8_t sendMrdcCapaInNrEutraMode     : 1;
            uint8_t isRetriedByDeviceIdentification      :   1;
            uint8_t isFailedToStoreSegment :  1;
            uint8_t reserved : 3;
            uint8_t uceRatSupportType;
        } savedInfo;

    } ueCapa;

    struct VccbRegisteredAmf_s
    {
        uint8_t amfIdentifierFlag;
        uint32_t amfIdentifier;  // R+S+P
    } registeredAmf;

    struct VccbNetworkSlice_s
    {
        uint8_t numSnssai;  // init 0
        callSNSSAI_type snssai[MAX_NUM_S_NSSAI_PER_CALL];
    } networkSlice;

    blacklistedCellInfo_type blacklistedCell;  // NEDC_SCG_FAILURE_20C

    union
    {
        uint8_t allowedBCListEutraBandIndiBitMap[MAX_EUTRA_BAND_INDICATOR / 8 + 1];
        uint8_t allowedBCListNrBandIndiBitMap[MAX_NUM_NR_BAND / 8 + 1];  // NRDC
    };

    struct VccbUeRrcInactiveInfo_s
    {
        uint8_t ability;                            // enumRRCInactiveAbility_type
        uint8_t resumeCause;                        // NRRRC_ResumeCause
        uint8_t numRtrvUeCtxtReqSendToGnb;          // inc by 1: Tx Xn_RetrieveUEContextReq, dec by 1: Rx
                                                    // Xn_RetrieveUEContextRsp or Xn_RetrieveUEContextFailure
        uint8_t ranPagingTxCount;
        uint8_t activityNotificationLevel;          // enumActivityNotifLvl_type
        uint8_t redCapActivityNotificationLevel;    // enumActivityNotifLvl_type
        uint8_t oldInactReportType;                 // NGAP_RRCInactiveTransitionReportRequest
        uint8_t newInactReportType;                 // NGAP_RRCInactiveTransitionReportRequest
        uint8_t singleReportByPathSwitch;           // enumRrcInactiveReportSingleStatus_type

        uint16_t pagingDrx;
        uint16_t t380;
        uint16_t ppi;
        uint16_t transitionReportedBy;              // msg_id which causes RRC Inactive Transition Report
        uint16_t numInactTAI;
        uint16_t extUEIdentityIndexValue;           // PEI

        UEIdentityIndexValue_type ueIdentityIndexValue; // 10bits

        timerInfo_type guardTimer;

        uint32_t lastUsedIRNTIUeId;

        struct VccbTaiListInactive_s
        {
            plmnId_type plmn;
            uint32_t    tac;
        } taiList[MAX_INACTIVE_TAI_NUM]; // 0..15
        uint8_t subGroupId; // PEI
        uint8_t edrxAbility;                        // enumRRCInactiveAbility_type (SVR25B)
        uint8_t nrPagingEDRXCycle;
        uint8_t nrPagingTimeWindow;
        uint8_t hashedUEIdentityIndexFlag;
        NGAP_HashedUEIdentityIndexValue_type hashedUEIdentityIndex;
    } RrcInactiveInfo;
    uint8_t mpsPriorityIndication;
    uint8_t guamiTypePresent;
    uint8_t guamiType;
} ueInfo_type;

typedef struct
{
    cgi_type cgi;
    uint32_t nrArfcn    : 22;  // 0..3279165
    uint32_t ssbArfcn   : 22;  // 0..3279165
    uint16_t bandNr     : 11;  // 0..1024, VLIB_GetFreqBandIndForCell
    uint8_t gnbIdLength : 6;   // 22..32
    uint8_t nrScsDl     : 3;   // 0..5, enumNrSubCarrierSpacing_type

    uint16_t pci        : 10;  // 0..1007
    uint8_t cellMoId    : 7;   // 0..64
    uint8_t sCellIndex  : 5;   // 1..31
    uint8_t newMoIdx    : 5;   // 0..MAX_NR_OF_OBJECT_ID
    uint8_t nrbDl       : 5;   // 0..29, enumNrSystemBandwidth_type
    uint8_t addRelCause : 4;   // 6 cases: CaSCellAddAtt_Total, CaSCellAddAtt_EventA4, CaSCellAddAtt_EventA6,
                           // CaSCellRel_OtherCause, CaSCellRel_EventA2, CaSCellRel_EventA6
    uint8_t ssbSubcarrierSpacing   : 3; // 0..5, enumNrSubCarrierSpacing_type
    uint8_t action                 : 3; // 0..4, enumSCellAction_type
    uint8_t state                  : 3; // 0..4, enumSCellState_type
    uint8_t followA2Quantity       : 2; // enumMeasTriggerQuantityChoice
    uint8_t shouldFollowA2Quantity : 1; // TRUE or FALSE
    uint8_t isCellSSB              : 1; // TRUE or FALSE
    uint8_t isActionQueued         : 1; // TRUE ("action" was not started)     - is set when VCCB receive MR which would
                                    // enqueue/trigger CA modification. FALSE("action" is currently proceed)- is set when
                                    // CA modification action is started.
    uint8_t sccFlag_cellMeasured   : 1; // TRUE when scell was measured and after SCC Gathering Timer
                                        // expire need to be send to DU
    uint8_t isUlBwSupported        : 1; // TRUE or FALSE
    uint8_t blind                  : 1; // TRUE(scell never measured) or FALSE(scell was measured by A4/A6/periodical)
    uint8_t ignoreNextPeriodic     : 1; // TRUE(do not release during next periodical MR handling) or FALSE

    uint8_t servCellSsbRsrp;    // 0..127, 255
    uint16_t bandwidthDl;
    uint16_t bandwidthUl;
    uint8_t sCellUlDlMode; // enumSCelLUlDlMode_type
    uint8_t useForNrcaUl;
    uint8_t airConditionForUlCa;  // enumAirConditionUlCa_type
} scellInfo_type;

typedef struct
{
    scellInfo_type ltmScells[MAX_SCELL_PER_CALL];
} ltmCaInfo_type;

typedef struct
{
    uint8_t numFailedCarrier;
    uint8_t currentFreeFailedCarrierPosition;
    uint8_t numFailedCell;
    uint8_t currentFreeFailedCellPosition;
    uint32_t failedCarrier[MAX_COLOCCELL];
    cgi_type failedCell[MAX_CELL_FAILED_IN_DU];
} duFailedSCellInfo_type;

typedef struct
{
    uint16_t caControlIdx           : 6;   // 0..MAX_NR_CA_CONTROL_ENTRIES
    uint16_t mode                   : 3;   // enumCaOperationMode
    uint16_t prevMode               : 3;   // enumCaOperationMode (for HO rollback/cancel)
    uint16_t shouldCaBeRestored     : 1;   // inform if Ca data should restored during HO rollback/cancel
    uint16_t componentCarriersLimit : 2;   // enumComponentCarriersLimit
    uint16_t lateCaMeasurements     : 1;   // ON/OFF inform if for CA late measurement should be used
    uint16_t isFR1FR2CaAvailable    : 1;   // TRUE/FALSE inform if FR1-FR2 CA is available for current call
    uint16_t mode2AnyScellReleased  : 1;   // TRUE/FALSE inform if any scell was released by A2 in CA-mode-2
    uint16_t scellsReleasedByVoNR   : 1;   // TRUE/FALSE inform if any scell was rejected by DU with cause CauseF1apRadioInteraction
    uint16_t suspendA4Meas          : 1;   // TRUE/FALSE inform if the current SCC is MAX BW. If TRUE, A4 MR for SCell ADD is not set.
    uint16_t prevSuspendA4Meas      : 1;   // suspendA4Meas for back-up
    uint16_t isPeriodicalOngoing    : 1;   // TRUE/FALSE inform if scell-release perioidcal measurement is ongoing
    uint16_t releaseCaA4ForVoNROn   : 1;   // TRUE/FALSE inform if VoNR setup. If TRUE, A4 MR for SCell ADD is not set.
    uint16_t ulScellChangeByMr    : 1;   // FR436: ul-scell-change-by-mr from last CA decision
    uint16_t reserved               : 8;   // to 32 bits

    uint16_t bandUsedForPCSelection;

    uint32_t totalMaxBw;                   // Max Total Bandwidth that a specific SpCell can have
    uint32_t prevTotalMaxBw;               // totalMaxBw for back-up

    timerInfo_type caPeriodicMeasTimer;
    duFailedSCellInfo_type failures;
    int8_t deviceAwareCaUsage;
    int8_t deviceAwareUlCaUsage;

} caInfo_type;

typedef struct
{
    cgi_type cgi;
    uint8_t gnbIdLength;
    uint16_t frequencyBand;
    uint16_t bandList[MAX_FREQBAND_PER_CELL];
    uint8_t bandListNum;
    enumDuplexMode_ForCall_type duplexMode;
    enumFrequencyRangeCa_type frequencyRange;
    uint32_t ssbArfcn;
    uint8_t tacStatus;
    bool isSsbCell;
    // for CC Contiguous checking
    uint32_t nrArfcnDl;
    uint8_t nrScsDl;
    uint8_t nRbDl;
    // MCO bandwidth
    uint16_t mcoBwDl;
    uint16_t mcoBwUl;
    // MCO Multiple Channel BW, only used for PCC/SCC
    uint16_t mcoMChAltBand;
    uint16_t mcoMChPrimaryBandBwDl;
    uint16_t mcoMChAltBandBwDl;
    uint8_t useForNrcaUl;
} caCellInfo_type;

typedef struct
{
    int32_t rank; // -1..10000
    union
    {
        uint16_t nbrIdx;
        uint16_t cellNum;
    };
    bool isNbr; // informs if nbrIdx is used
    bool isColocCell;
    bool isIntraDuCell;
    uint16_t frequencyBand;
    uint8_t servCellSsbRsrp;
} ScellCandidateFromMR_type;

/**
 * @brief CSL Connect Information params
 */
typedef struct
{
    // NSA
    vccbTimeInfo_type additionRequest;
    vccbTimeInfo_type additionRequestAck;
    vccbTimeInfo_type reconfigComplete;
    // SA
    vccbTimeInfo_type requestTime;
    vccbTimeInfo_type completeTime;
    uint32_t mNgRanUeXnapId;
    enumDcNodeType dcNodeType;
    gnbId_type dcPeerRanNodeGnbId;
    uint32_t sNgRanUeXnapId;

    // Common
    uint8_t conditionalHandoverFlag;  // Incoming Conditional Handover
    uint16_t cellNum;

    //New in SVR26A start
    uint8_t vonrReq;                    // Init: 0xFF, Range: 0~1
    uint8_t emergReq;                   // Init: 0xFF, Range: 0~1
    uint16_t nrdcAddVonr;               // Init: 0xFF, Range: 0~65534
    uint16_t nrdcRelVonr;               // Init: 0xFF, Range: 0~65534
    uint8_t nrdcStatus;                 // Init: 0xFF, Range: 0~1
    //New in SVR26A end

} CslConnectInfo_type;

typedef struct
{
    int16_t state;
    uint32_t callId;
    uint16_t msgId;
    uint16_t msgLength;
    enqueuedAction action;
    enumMsgQueueType_type msgQueueType_flag;
    union
    {
        uint8_t sctpMsg[MSG_DAT_LEN + SCTP_DATA_IND_HDR_LEN];  // MSG_QUEUE_TYPE_SCTP
        uint8_t rrcPacked[MAX_BUF + MSG_CHD_LEN];              // MSG_QUEUE_TYPE_RRC
        uint8_t msg[MSG_DAT_LEN + MSG_CHD_LEN];                // MSG_QUEUE_TYPE_ALL
    };
} msgQueueInfo_type;

typedef struct
{
    uint8_t assignFlag;
} cellErabCntFlag_type;

/**
 * brief flag type
 */
typedef struct
{
    uint32_t setupFlag;   /**< setup flag */
    uint32_t releaseFlag; /**< release flag */
    uint64_t respFlag;    /**< response flag */
} flag_type;

typedef enum
{
    ci_shall_not_trigger_pre_emption = 0,
    ci_may_trigger_pre_emption = 1
} enumPreemptionCapability_type;

typedef enum
{
    ci_not_pre_emptable = 0,
    ci_pre_emptable = 1
} enumPreemptionVulnerability_type;

/**
 * @brief This is a structure for ARP Information
 */
typedef struct
{
    uint16_t priority;                                /**< APR priority */
    uint16_t reserved;                                /**< reserved field */
    enumPreemptionCapability_type preemCapable;       /**< preemption capability */
    enumPreemptionVulnerability_type preemVulnerable; /**< preemption vulnerability */
} aRPInfo_type;

/**
 * @brief This is a structure for QoS parameter of each bearer
 */
typedef struct
{
    qCIValue_type qciValue; /**< QCI value structure */
    uint64_t ulGBR;         /**< UL GBR */
    uint64_t dlGBR;         /**< DL GBR */
    uint64_t ulMBR;         /**< UL MaxBR */
    uint64_t dlMBR;         /**< DL MaxBR */
    uint64_t maxMCGulGBR;   /**< max MCG Admittable UL GBR */
    uint64_t maxMCGdlGBR;   /**< max MCG Admittable DL GBR */
    uint64_t maxMCGulMBR;   /**< max MCG Admittable UL MaxBR */
    uint64_t maxMCGdlMBR;   /**< max MCG Admittable DL MaxBR */
    aRPInfo_type aRP;       /**< Allocation and Retention Priority */
} bearerQoSPara_type;

typedef struct
{
    uint8_t fNeedModify;
    uint16_t numTLAbit;
    uint8_t TLAddr[MAX_TLA_BYTE];
    uint32_t TEID;
} transportLayerInfo_type;

typedef struct
{
    uint8_t needSendFlag;
    uint8_t needRequestFlag;
    uint8_t pdcpVersionChangeInd;
    uint16_t dlForwardFlag;
    /* 0 : DL Data will not be forwarded */
    /* 1 : DL Data will be forwarded */
    uint16_t ulForwardFlag;
    /* 0 : UL Data will not be forwarded */
    /* 1 : UL Data will be forwarded */
    uint32_t ulSN;
    uint32_t dlSN;
    uint32_t ulHFN;
    uint32_t dlHFN;
    uint8_t ulRcvStatus[MAX_PDCP_RCV_STS];
} forwardingInfo_type;

typedef struct
{
    uint16_t logicalChId;
    uint16_t priority;
    enumPrioritizedBitRate_type PBR;
    enumBucketSizeDuration_type bucketSizeDuration;
    uint16_t groudId;
    uint16_t nonGbrPFweight;  // 0~15
    enumLoCh_type loChType;   // enumLoCh_type
} logicalCHInfo_type;

typedef struct
{
    uint8_t useFlag;  /**< TRUE, FALSE */
    time_t startTime; /**< UTC time when the recording of the Secondary RAT Data Volume was started */
    time_t endTime;   /**< UTC time when the recording of the Secondary RAT Data Volume was ended */
    uint64_t countUl; /**< Bytes transmitted UL via bearer */
    uint64_t countDl; /**< Bytes transmitted UL via bearer */
} dataUsageInfo_type;

typedef enum
{
    ci_default_drb_true = 0,
    ci_default_drb_false = 1
} enumDefaultDRB_type;

typedef enum
{
    ci_sdap_header_present = 0,
    ci_sdap_header_absent = 1
} enumSDAPHeader_type;

typedef struct
{
    uint8_t defaultDRB; /**< enumDefaultDRB_type */
    uint8_t headerUl;   /**< enumSDAPHeader_type */
    uint8_t headerDl;   /**< enumSDAPHeader_type */
} sdapDBInfo_type;

#define MAX_DATA_USAGE_REPORT_NUM 2

// PDCP Prev Flag Info
#define NR_PDCP_PREV_FLAG_NOT_PRESENT    0x00
#define NR_PDCP_PREV_FLAG_FROM_OTHER_GNB 0x01
#define NR_PDCP_PREV_FLAG_FROM_EXIST_DRB 0x03
#define NR_PDCP_PREV_FLAG_SET_ALL        0xFFFFFFFF
#define NR_PDCP_PREV_FLAG_SET_ZERO       0x00000000
#define NR_PDCP_PREV_FLAG_SET_PRESENT    0x01
// PDCP Info Update Option
#define NR_PDCP_UPDATE_SEMI_FINAL 0x01
#define NR_PDCP_UPDATE_FINAL      0x00

typedef struct
{
    uint8_t rbId;
    pdcpConfigInfo_type pdcpInfo;
    pdcpConfigInfo_type pdcpInfoPrev;               /**< For Backup */
    sdapDBInfo_type sdapInfo;
    sdapDBInfo_type sdapInfoPrev;  // in the current scope, just only to success the source cfg

    // ********* To Be Deleted *******
    pdcpPrevFlagInfo_type pdcpInfoPrevFlagInfo; /**< For Backup */
    uint8_t rlcMode;
    uint8_t rlcModePresent   : 1;
    uint8_t sdapInfoPrevFlag : 1;
    uint8_t reserved         : 6;
} rbPdcpSdapConfig_type; // L2 PDCP/SDAP sublayer parameters

typedef struct
{
    uint8_t usage;      // ENUM:: enumUsage_type
    uint8_t srbStatus;  // ENUM:: enumBearerStatus_type
    uint16_t transactionId;

    uint16_t srbIdx;

    timerInfo_type timer;
    flag_type flag;
    qCIValue_type qciValue;
    rbPdcpSdapConfig_type rbInfo;
    PdcpRbContext_type pdcpRbContext;
} callSRBInfo_type;

/**
 * @brief call fault type
 */
typedef struct
{
    uint8_t stateCmd;                     /**< VCCB call stateCmd ENUM:: enumStateCmd_type */
    uint16_t callFaultCause;              /**< call fault cause */
    uint32_t msgId;                       /**< message ID */
    char fnName[MAX_VCCB_STAT_FUNC_NAME]; /** function name that stores cause */

    uint16_t callState; /**< call state */
} callFault_type;

typedef struct
{
    // uint8_t establishmentCause;  // ENUM:: enumEstablishmentCause_type
    uint16_t e1Cause;
    uint16_t f1Cause;
    uint16_t x2Cause;
    uint16_t ngCause;
    uint16_t xnCause;
    callFault_type callFault;
} causeInfo_type;

typedef struct
{
    uint8_t establishmentCause;  // ENUM:: enumEstablishmentCause_type
    uint16_t e1Cause;
    uint16_t f1Cause;
    uint16_t x2Cause;
    uint16_t ngCause;
    uint16_t xnCause;

} drbCauseInfo_type;

typedef struct
{
    uint8_t usage;
    uint8_t erabIdx;
    uint16_t e1Idx;  // E1 end ponint index of serving AUPF

    enumBearerStatus_type erabStatus;
    enumBearerStatus_type prevErabStatus;
    // enumBearerStatus_type       pathSwitchRelStatus;

    uint8_t activityStatusPrev;
    uint8_t activityStatus;

    uint16_t transactionId;
    flag_type flag;

    uint8_t addSuccessFlagForStat;  // For not collecting ERAB_REL counter when ERAB Addition procedure failed

    uint8_t sgnbInitRelFlag;  // For checking DRB Required To Be Released by DU

    uint8_t callCountFlag;  // For STAT_DRB_NUM_PER_GNB statistic
    uint8_t cslAllocOrder;  // For DRB/PDU-related information sorting

    uint8_t eRABId;  // 0...15
    uint8_t dRBId;   // 1...32
    bearerQoSPara_type erabQos;
    bearerQoSPara_type erabQosPrev; /* For Backup */
    // minBrPara                   minimalBitrate;
    transportLayerInfo_type s1uDlInfo;
    transportLayerInfo_type s1uUlInfo;
    transportLayerInfo_type x2uDlInfo;
    transportLayerInfo_type x2uUlInfo;
    transportLayerInfo_type f1uDlInfo;
    transportLayerInfo_type f1uDlInfoPrev;
    transportLayerInfo_type f1uUlInfo;
    transportLayerInfo_type x2uForwardUlInfo;
    transportLayerInfo_type x2uForwardDlInfo;
    forwardingInfo_type snStatus;

#define MAX_VCCB_ERAB_FAMILY_TYPE 3  // STAT_ERAB_ADD_PER_GNB, STAT_ERAB_MOD_PER_GNB, STAT_ERAB_REL_PER_GNB
    struct erabStatInfo_s
    {
        uint8_t statType;
        uint8_t statState;
        struct timespec startTime;
        uint8_t attemptFlag[MAX_VCCB_ERAB_FAMILY_TYPE];
    } erabStatistic;

    rbPdcpSdapConfig_type rbInfo;


    uint16_t setupYear;
    uint8_t setupMon;
    uint8_t setupMday;
    uint8_t setupHour;
    uint8_t setupMin;
    uint8_t setupSec;

    Stopwatch_type holdTime;
    causeInfo_type cause;
    dataUsageInfo_type dataUsage[MAX_DATA_USAGE_REPORT_NUM]; /**< Store data usage reports */

    // for EN-DC
    uint8_t pDCPatSgNB;       // MN_Terminated, SN_Terminated
    uint8_t prevPDCPatSgNB;   // MN_Terminated, SN_Terminated
    uint8_t bearerType;       // enumBearerType: MCG_Bearer, SCG_Bearer, Split_Bearer
    uint8_t preveBearerType;  // enumBearerType: MCG_Bearer, SCG_Bearer, Split_Bearer

    uint8_t ulPdcpPath;      // UlPdcpPath_ScgShared, UlPdcpPath_McgShared, UlPdcpPath_ScgOnly, UlPdcpPath_McgOnly
    uint8_t ulPdcpPathPrev;  // UlPdcpPath_ScgShared, UlPdcpPath_McgShared, UlPdcpPath_ScgOnly, UlPdcpPath_McgOnly

    uint8_t ulPdcpPathToMod;  // UlConfigBearer_ModOn, UlConfigBearer_ModOff, UlConfigBearer_ModUnable

    uint8_t ulPdcpPathEnq;       // VCCB_FLAG_OFF, VCCB_FLAG_ON
    uint8_t ulPdcpPathEnqToSet;  // UlPdcpPath_ScgShared, UlPdcpPath_McgShared, UlPdcpPath_ScgOnly, UlPdcpPath_McgOnly

    uint8_t packetInspectionQciFlag;  // VCCB_FLAG_OFF, VCCB_FLAG_ON
    uint8_t dlTrafficAboveThldFlag;   // VCCB_FLAG_OFF, VCCB_FLAG_ON. Says if UP reported DL traffic above configured
                                      // threshold.
    uint8_t qosModFlag;      // VCCB_FLAG_OFF, VCCB_FLAG_ON. QOS modified by eNB.

    uint8_t prevDataSplitThreshold;
    uint8_t dataSplitThreshold;

} callERABInfo_type;

typedef struct
{
    uint8_t usage;      // ENUM:: enumUsage_type
    uint8_t numTLAbit;  // TODO leeyd uint16_t -> uint8_t
    uint16_t transactionId;
    timerInfo_type timer;
    flag_type flag;

    uint32_t sTEID;
    uint8_t TLAddr[MAX_TLA_BYTE];
    uint32_t destTEID;
} pathInfo_type;

typedef struct
{
    enumUsage_type usage; /* CI_no_use, CI_use */

    uint16_t hoGnbIdx;
    uint16_t transactionId;
    timerInfo_type timer;
    flag_type flag;

    vccbGlobalGnbId_type globalGnbId;
    cgi_type targetCellId;
    uint16_t targetPci;
    uint32_t targetSsbFrequency;
    uint32_t targetNrArfcn;
    uint32_t targetExtendedTac;

    uint32_t myVnbUeX2APId;
    uint32_t peerVnbUeX2APId;

    // uint16_t                    associateIdx;

    pathInfo_type dlPath[MAX_ERAB_PER_CALL];
    pathInfo_type ulPath[MAX_ERAB_PER_CALL];
} callGNBInfo_type;

/**
 * @brief Defines type of gNB-CU-CP initiated E1 procedures
 *        FGR-CC1105 Bearer Context Management via E1 : Multi Up per Call
 */
typedef enum
{
    E1Procedure_BearerContextSetup = 0,
    E1Procedure_BearerContextModification,
    E1Procedure_BearerContextRelease
} enumE1Procedure_type;

/**
 * @brief Defines different states of E1 procedures
 *        FGR-CC1105 Bearer Context Management via E1 : Multi Up per Call
 */
typedef struct VccbE1ConnectionBitFlag_s
{
    uint8_t isE1BearerContextEstablished : 1;  // set TRUE after Successful E1 BearerContextSetup procedure
    uint8_t isRequestSend : 1;  // set TRUE after send    E1 BearerContext Setup/Modification/Release Request message
    uint8_t isResponseReceived        : 1;  // set TRUE after receive Response message for above mentioned procedure
    uint8_t isSuccessResponseReceived : 1;  // set TRUE after receive positive Response message for above mentioned
                                            // procedure
    uint8_t isErrorDuringResponse : 1;  // set TRUE after ERROR   occurs during Store Success/Failure Response message.
                                        // CallRelease Needed
    uint8_t isPartialResponseReceived : 1;  // set TRUE when got PDU/DRB Partial Failure in Setup/Modification Response message.
    uint8_t isE1Reset : 1;  // set TRUE after receive RELEASE_BEARER (E1 Reset handled by VNMB). Related bearers release
                            // Needed
    uint8_t isE1ErrorIndReceived : 1; // set TRUE after receive E1 ErrorIndication with Cause IE related to wrong ID (i.e connection is no longer valid)
} VccbE1ConnectionBitFlag_type;

typedef struct
{
    // This structure is used to manage each state of a call, and it is processed by dividing it into bits.
    // ON_SGNB_ADD_REQ_FLAG(value);

    // Manages resource set up in call or resource information to be maintained.
    uint64_t setupFlag;

    //
    uint64_t releaseFlag;

    // VCCB manages the destination to be transmitted and received. (Req:VCCB to NE -> Resp:NE to VCCB)
    // Example: E1 Modification Request -> E1 Modification Response
    uint64_t respFlag;

    // VCCB manages the destination to receive and transmit. (Req:NE to VCCB -> Resp:VCCB to NE)
    // Example: Initial Context Request -> Inital Context Setup Failure
    uint64_t toRespFlag;

    // FGR-CC1105 Bearer Context Management via E1 : Multi Up per Call
    VccbE1ConnectionBitFlag_type e1Flag[MAX_CU_UP_PER_CALL];  // Index same as in endPoint_type.e1Idx[]
} vccbCallFlag_type;

typedef struct VccbCallBitFlag_s
{
    // 1st BitFlag #0~#7
    uint64_t isNeedSecurityFlow : 1;  // set TRUE if need SecurityModeCommand/Complete procedure is required and set
                                      // FALSE after sending SecurityModeCommand(default:FALSE)
    uint64_t isSgNBAddReqRejectNoRadioResourcesAvailableInTargetCell : 1;    // set TRUE when VCCB need to send SgNBAdditionReject with
                                              // "NoRadioResourcesAvailableInTargetCell" cause
    uint64_t isReceivedUeContextRelease       : 1;  // set TRUE if receive X2UeContextRelease and set FALSE after processing
    uint64_t isInterGnbRreConnection          : 1;  // set TRUE if inter Gnb RRE Connection
    uint64_t isPartialDrbForRreDuringHo       : 1;  // set TRUE if partial DRB need to be considered for RRE during Handover
    uint64_t isPartialDrbForRreDuringPduChg   : 1;  // set TRUE if partial DRB need to be considered for RRE during Pdu Change
    uint64_t isRRCRejectRequired        : 1;  // set TRUE before sending RRCSetup after receiving RRCSetupRequest
    uint64_t needSuspendXnFlag          : 1;  // Set to true when Rx XN Activity Noti. (inactive)

    // 1st BitFlag #8~#15
    uint64_t resumeRequestFlag          : 1;  // Set TRUE when receive resumeRequest message
    uint64_t emergencyUeBeforePduChange : 1;  // Set TRUE if Emergency UE at the time PDU change is triggered. Delta
                                              // processing position -> POINT #A : PDU Session Trigger, POINT #B PDU
                                              // Session Change Complete
    uint64_t isE1TxStopRequested : 1;  // Set TRUE when first E1 Bearer Mod Req with CellGroupToModify has been sent,
                                       // set False when E1 Bearer Mod procedure has been finished
    uint64_t needXnUAddrIndForSnTermSplit : 1;  // Set TRUE when update DL TNL Information of MCG Leg on SNTermSplit
                                                // bearer to SN.
    uint64_t isSCellReconfigRequired : 1;       // Set TRUE if:
                                           // - 'SCell Failed To Setup List' with 'Cause: MiscHardwareFailure' from DU,
                                           // - or for handover-with-non-ca-support functionality,
                                           // - or for SCell reconfiguration with alternative band
    uint64_t isXnSNStatusTransferReceived : 1;       // Set TRUE when SN receive XN_SNStatusTransfer from MN
                                                     // in SN_SNAdd/ModExec
    uint64_t needSendCallSetupRspWithFailedPCI : 1;  // Set TRUE when Cell Selection Failed due to below cell param
                                                     // 1) Cell Status, 2) serviceState, 3) switchingOffOngoing
                                                     // This parameter used only when sending CallSetupRsp to VNMB

    uint64_t existRequestforPduParaInPduModifyReq : 1;

    // 1st BitFlag #16~#23
    uint64_t notMatchedQosFlowIdInPduModifyReq    : 1;
    uint64_t existDrbPreemptionReqForOnlyDup      : 1;
    uint64_t stopUserInactivityByScgSuspend       : 1;
    uint64_t isInterRatHoIn : 1;  // Set TRUE when incoming Handover type is eps-to-5gs. Once set it lasts forever.

    uint64_t isDrbPreemptionCase          : 1;  // Set TRUE when DRB Preemption case
    uint64_t needE1DrbRemove              : 1;  // Set TRUE when DRB which need to be released from UP is exist.
    uint64_t isUeCapaIncludedCgConfigInfo : 1;  // Set TRUE when NRRRC_CG_ConfigInfo has UE Capability Info, so do not
                                                // need to fill CuToDuRrcInformation::UE-CapabilityRAT-ContainerList

    uint64_t isMcoLteAccessCase : 1;  // Set TRUE when temporary call is created by receiving bcInfoRequest from eNB

    // 1st BitFlag #24~#31
    uint64_t isSgNBAddReqRejectDuOverload : 1;  // set TRUE when VCCB need to send SgNBAdditionRequestReject with
                                                // "CauseX2apMiscControlProcessingOverload" cause

    uint64_t xNuAddrIndPendingState         : 1;

    uint64_t pduChangeActionByAmf : 1;  // Set TRUE when PDU Session Setup/Modify/Release is received from AMF.
    uint64_t isSgNBAddReqRejectTgtNotAllowed : 1;     // set TRUE when VCCB need to send SgNBAdditionReject with
                                                      // "CauseX2apRadioNetworkLayerTargetNotAllowed" cause
    uint64_t isSgNBAddReqRejectSwitchOffOngoing : 1; // FGR-CC5000. set TRUE when VCCB need to send SgNBAdditionReject with "CauseX2apRadioNetworkLayerSwitchOffOngoing" cause
    uint64_t isE1apDddsNotificationENDCReceived : 1;  // FGR-BC1202 FR 340
    uint64_t isRcvResetOnIntraNrdcSN : 1;  // in intra-nrdc situation, sn vccb received CallReleaseCommand due to reset
                                           // from vnmb
    uint64_t isReceivedNrCapaFlag : 1; // Set TRUE when received NR-Capability

    // 1st BitFlag #32~#39
    uint64_t rcvDlTrfStatusRptForNrdcAddition : 1;  // dl traffic monitoring
    uint64_t rcvUlTrfStatusRptForNrdcAddition : 1;  // ul traffic monitoring
    uint64_t addSCellListVoNRSetup : 1; // Set TRUE when existing SCell list has to be sent to DU during VoNR setup
    uint64_t startProcessOfReleaseSaCall : 1;   // It's set as true When Call Release Procession Triggered by VCCB_CallAutoRelease(VCCB_CALL_RELEASE_TRIGGER).
    uint64_t ueBasedInSessionFlagByE1  : 1;   // It's for SETUP_ACTIVE_UECONTEXT_RELEASE_DU_ID.
    uint64_t doNotReleaseExtMrdcUeCapa : 1;  // Set TRUE when MR-DC UE Capa is just copied in ptTmpCi. So do not release memory.
    uint64_t doNotReleaseExtNrUeCapa   : 1;  // Set TRUE when NR UE Capa is just copied in ptTmpCi. So do not release memory.
    uint64_t needToSendUeCapaCheckResponse  : 1;   // Set TRUE when send "UE CAPABILITY CHECK RESPONSE" to AMF

    // 1st BitFlag #40~#47
    uint64_t isUlTrfChkReportForIratHoReceived : 1; // Set when Ul Traffic Check Report for IRAT HO is received in F1 Private Message
    uint64_t doNotCalcTotalMaxBwForCa : 1; // Set when total MAX BW for CA calculation is not required. Used in VoNR case.
    uint64_t endcAdditionToNrcgiCell : 1; // FGR-CC5000. Set TRUE when chosen cell to EN-DC addition is Nrcgi cell or load-balanced from Nrcgi cell.
    uint64_t selectSpCellError : 1; // FGR-CC5000. Set TRUE when Select spCell selection procedure failed.
    uint64_t spCellSelCellBarredWithSwitchOff : 1; // FGR-CC5000. Set TRUE when cell is MIB barred and switchOffOngoing true.
    uint64_t isSCellChangedAllowedBand : 1; // FGR-RC0100 FR124. Set true when need to change Scell configuration because of changing of allowed-band-list.
    uint64_t isEndcUeCtxtReleaseDuringF1Setup : 1; // Set TRUE when UE context release is performed during F1 Setup procedure (for F1AP_UE_SETUP_CU_DU_ID stats only).
    uint64_t ueAttachedToSwitchingOffOngoingCell : 1; // FGR-CC5000 FR3530 Set true when ue is attached to switchingOffOngoing Cell.

    // 1st BitFlag #48~#55
    uint64_t isEndcSpCellSelectionProcedure : 1; // FGR-CC5000 FR2206 Set TRUE if EN-DC SPCell selection procedure is ongoing.
    uint64_t needToWaitForUeContextRelCmd : 1; // Already sent InitialContextSetupFailure before, but need to wait for UeContextReleaseCommand from AMF .
    uint64_t hasVoiceInRequestMsg : 1; // if Voice(5QI=1) is in PDU Session Setup/Modify request, then ON. (Temporary value)
    uint64_t isEndcForcedRestrictionTimerProcessing : 1; // FGR-LC0708 - set TRUE when processing forced mobility restiction timmer.
    uint64_t storeAndSendMsgInE1DrbPreemption : 1; // Set TRUE when E1 DRB Preemption Processing (for Store/Send E1 Message)
    uint64_t isNewE1DrbPreemptionRequest : 1;      // Set TRUE when New Valid E1 DRB Preemption request exist (for Store E1 Message)
    uint64_t isSnInitBearerChangeToMcgConfirmed : 1; // Set TRUE when MeNB confirm SgNB Modification procedure (SN init Split to Mcg bearer change)
    uint64_t activeUeContextRelease : 1; // Set TRUE when meet condition of collecting SETUP_ACTIVE_UECONTEXT_RELEASE

    // 1st BitFlag #56~#63
    uint64_t sentRelRequestToAmfByUserInact : 1; // Set TRUE when send UeContextReleaseRequest to AMF by user inactivity.
    uint64_t isInterRatHoRequiredByVonrSetupFail : 1; // SVR25B FGR-SV0201. Set TRUE when need to Inter-RAT H/O For EPS Fallback (5QI Setup Failure)
    uint64_t sentSmcOnInitialContextSetupRequest : 1; // SVR25B FGR-SV0201. Set TRUE when send Security Mode Command in InitialContextSetupRequest.
    uint64_t emergencyCallFlagJustUsingCnfUpgrade : 1; // SVR25B ARC-FG5403 Set TRUE in VCCM_CheckEmergencyCall() for just upgrading CNF
    uint64_t alreadyCollectStatInRelCmplState : 1; // Set true when collect stat(H/O Time) in STATE_Conn_RelCmpl
    uint64_t skipCslCheckBeforeRrcReconfig : 1;
    uint64_t noMoreActionForTriggeringHoByAllFailure : 1; // SVR25B FGR-CC3101. Set TRUE when no more action for triggering H/O by All Failure with Specific Slice Fail at Store Stage.
    uint64_t isPossibleRedirectionInBasicProcedure   : 1; // SVR25B FGR-CC3101. Set TRUE when VCCM_CheckAndDoCommonProcessForPduQosRequest() is called for Checking Redirection

    // 2nd BitFlag #0~#7
    uint64_t noMoreSaveNgIeByAllPduFailForSpecificSlice : 1; // SVR25B FGR-CC3101. Set TRUE when All Requested PDU are failed with Specific Slice in NG Store
    uint64_t rxF1apRadioRLFailure_RLC                   : 1; // SVR26A FGR-CC3101. Set TRUE when receive F1_UEContextModificationRequired_id with CauseF1apRadioRLFailure(RLC).
    uint64_t usingRlfRreWaitState                       : 1; // SVR26A FGR-CC3101. Set TRUE when allowCallProcessingDuringRlfDetected is OFF in VLIB_InitCallInfo()
    uint64_t rfspBlindRedirectionWithOutTimer : 1; // SVR26A FGR-MC1025. Set TRUE when DSS Fail or Timer is 0 in RFSP Blind Redirection.
    uint64_t isSgNBAddReqRejectedDueToDucting : 1;  // SVR26A FGR-CC5001 FR155. Set TRUE when VCCB need to send SgNBAdditionReject
                                                    // with "CauseX2apRadioNetworkLayerHoTargetNotAllowed" cause
    uint64_t ueSpeedState : 2; // enumUeSpeed_type, SVR26A FGR-MC1026
    uint64_t changeBandDuringIntraCellHo : 1; // SVR26A FGR-CC3201 FR130 Set TRUE when VCCB needs to change spCell band

    // 2nd BitFlag #8~#15
    uint64_t changeBandAfterPduSetup : 1; // SVR26A FGR-CC3201 FR130 Set TRUE when VCCB needs to change spCell band after PDU setup
    uint64_t mnBcReselectionFeatureOn  : 1; // SVR26A FGR-CC3201 FR130 Set TRUE when VCCB needs to change spCell band
    uint64_t isEmergencyCallByReqValInThisProcedure : 1;  // SVR25B Set TRUE when VCCB decide it as emergency call with requested value in InitialContextSetupRequest/PDU Session Setup/Modify.
    uint64_t isVonrRequestedInThisProcedure         : 1;  // SVR25B Set TRUE when VCCB received 5QI=1(Setup or Modify) in InitialContextSetupRequest/PDU Session Setup/Modify.
    uint64_t isQosReleaseInThisProcedure            : 1;  // SVR25B Set TRUE when VCCB received QosFlow Release in PDU Session Modify.
    uint64_t isEmergencyFallbackByAmf               : 1;  // SVR25B Set TRUE when Emergency Fallback is set by AMF in InitialContextSetupRequest/UeContextModificationRequest.
    uint64_t isQueueingByEmergencyCall              : 1;  // SVR25B Set TRUE when Queueing is done by Emergency Call(VoNR Fail) in InitialContextSetupRequest/PDU Session Setup/Modify.
    uint64_t needToSendForSeValue                   : 1;  // SVR25B Patch Set TRUE when VCCB transmits seValue to DU via F1 message.

    // 2nd BitFlag #16~#23
    uint64_t pc1Capable  : 1; // FGR-CC4208 Set true when ue is classified as FR1 power class 1 capable.
    uint64_t pc15Capable : 1; // FGR-CC4208 Set true when ue is classified as FR1 power class 1.5 capable.
    uint64_t pc2Capable  : 1; // FGR-CC4208 Set true when ue is classified as FR1 power class 2 capable.
    uint64_t isRrcSetupReqWithRrcSetupComplete      : 1;  // SVR26B FGR-CC3101. Set TRUE when VCCB received NRRRC_RrcSetupRequest_id with NRRRC_RrcSetupComplete_id (RRC DUP)
    uint64_t isCagCapableUe     : 1;  // SVR26B FGR-CC3101. Set TRUE when UE is CAG Capable in Storing MRL.
    uint64_t reserved : 43;

    // 2nd BitFlag #24~#31
    // 2nd BitFlag #32~#39
    // 2nd BitFlag #40~#47
    // 2nd BitFlag #48~#55
    // 2nd BitFlag #56~#63
} VccbCallBitFlag_type;

typedef struct
{
    uint8_t sEnbUeX2apIdPresent;  // For UE X2AP ID Alloc Fail
    uint8_t mEnbUeX2apIdExtensionPresent;
    uint8_t oldMenbUeX2apIdExtensionPresent;
    uint8_t newMenbUeX2apIdExtensionPresent;

    uint16_t mEnbUeX2apId;
    uint16_t oldMenbUeX2apId;  // for SnStatusTransfer
    uint16_t newMenbUeX2apId;  // for SnStatusTransfer
    uint8_t x2VendorInd;       // for SgNB Activity Notification
                               // 0: others, 1: samsungEnb
    uint8_t reserved;

    uint32_t sEnbUeX2apId;  // Range : 0~2^32-1
    int64_t mEnbUeX2apIdExtension;
    int64_t oldMenbUeX2apIdExtension;  // for SnStatusTransfer
    int64_t newMenbUeX2apIdExtension;  // for SnStatusTransfer
} callENBInfo_type;

typedef struct
{
    callENBInfo_type eNBInfo;
    uint16_t x2Idx;
} enbHoInfo_type;

typedef struct
{
    uint8_t sEnbUeXnapIdPresent;  // For UE XNAP ID Alloc Fail
    uint8_t xnVendorInd;          // for SgNB Activity Notification
    uint8_t reserved[2];

    uint32_t mGnbUeXnapId;
    uint32_t oldMgnbUeXnapId;  // for SnStatusTransfer
    uint32_t newMgnbUeXnapId;  // for SnStatusTransfer
                               // 0: others, 1: samsungGnb

    uint32_t sGnbUeXnapId;  // Range : 0~2^32-1
} callTmpGNBInfo_type;

typedef struct
{
    callTmpGNBInfo_type gNBInfo;
    uint16_t xnIdx;
} gnbHoInfo_type;

// TS 24.501
// Intra N1 mode NAS transparent container      : 9 octets
// S1 mode to N1 mode NAS transparent container : 10 octet
#define MAX_NASC_LEN 10

typedef struct
{
    uint16_t numocts;
    uint8_t data[MAX_NASC_LEN];
} securityNASCInfo_type;

typedef struct
{
    uint8_t sKgNB[KEY_VNB_LENGTH];
    uint8_t nextHop[KEY_VNB_LENGTH];
    uint16_t nCC;
    uint16_t newNCC;                      // next hop for inter gNB/RAT handover
    PdcpCallContext_type pdcpCtx;         // for PDCP-C / SRBs
    PdcpCallContext_type newPdcpCtx;      // for Intra Cell Handover
    uint8_t newSecurityContextChangeInd;  // key change indicator for Inter-gNB Handover
    securityNASCInfo_type nasc;
    int32_t snCounter;            // Init by -1, Increment before new key calculation.
    uint8_t snCounterChangeFlag;  // Set to TRUE in case snCounter is changed. Used to send the IE in RRC message.
} securityInfo_type;

// __B_ENDC__
// RRC
typedef struct
{
    uint8_t rxFlag;
    uint8_t isBigCapaFlag;
    uint16_t numocts;
    uint8_t data[MAX_UE_CAPA_ONE_RAT_LENGTH];  // 9000
} ueCapabilitiesRATcontainer_type;

#define MAX_OVERHEATING_ASSI_BUF 7

/* Buffer to store overheatingAssistance from eNB */
typedef struct
{
    uint32_t numocts;
    uint8_t data[MAX_OVERHEATING_ASSI_BUF];
} overheatingAssistanceBuf_type;

typedef struct
{
    uint8_t f1UeContextToRemove_flag;  // VCCB_FLAG_ON / VCCB_FLAG_OFF
} f1UeContextInfo_type;

/* candidateCellInfoListMN, candidateCellInfoListSN in dfcbCgConfigInfo_type */
typedef struct
{
    uint8_t rsrpFlag;
    uint8_t rsrqFlag;
    uint8_t sinrFlag;

    uint16_t rsrp; /* optional */
    uint16_t rsrq; /* optional */
    uint16_t sinr; /* optional */
} measQuantityResults_type;

/* measResultCellListSFTD in dfcbCgConfigInfo_type */
typedef struct
{
    uint16_t physCellId;
    uint16_t sfnOffsetResult;
    int16_t frameBoundaryOffsetResult;

    uint8_t rsrpResultFlag;
    uint16_t rsrpResult; /* optional */
} measResultCellSFTD_type;

typedef struct
{
    uint8_t nrofCellSFTD;
    measResultCellSFTD_type measResultCellSFTD[MAX_NUM_CELL_SFTD];
} measResultCellListSFTD_type;

/* scgFailureInfo in dfcbCgConfigInfo_type */
typedef struct
{
    uint8_t resultsSSB_CellFlag;
    uint8_t resultsCSI_RS_CellFlag;

    measQuantityResults_type resultsSSB_Cell;    /* optional */
    measQuantityResults_type resultsCSI_RS_Cell; /* optional */
} cellResults_type;

typedef struct
{
    uint8_t ssbResultsFlag;

    uint8_t ssbIndex;
    measQuantityResults_type ssbResults; /* optional */
} resultsPerSSB_Index_type;

typedef struct
{
    uint8_t nrofSSB;
    resultsPerSSB_Index_type resultsPerSSB_Index[MAX_NUM_SSB];
} resultsPerSSB_IndexList_type;

typedef struct
{
    uint8_t csi_RS_ResultsFlag;

    uint8_t csi_RS_Index;
    measQuantityResults_type csi_RS_Results; /* optional */
} resultsPerCSI_RS_Index_type;

typedef struct
{
    uint8_t nrofCSI_RS;
    resultsPerCSI_RS_Index_type resultsPerCSI_RS_Index[MAX_NUM_CSI_RS];
} resultsPerCSI_RS_IndexList_type;

typedef struct
{
    uint8_t resultsSSB_IndexesFlag;
    uint8_t resultsCSI_RS_IndexesFlag;

    resultsPerSSB_IndexList_type resultsSSB_Indexes;       /* optional */
    resultsPerCSI_RS_IndexList_type resultsCSI_RS_Indexes; /* optional */
} rsIndexResults_type;

typedef struct
{
    uint8_t nrofFreqBandIndicatorNR;
    uint16_t freqBandIndicatorNR[MAX_NUM_MULTIBANDS];
} multiFrequencyBandListNR_type;

typedef struct
{
    uint8_t nrofPLMN_Identity;
    plmnId_type plmn_Identity[MAX_NUM_PLMN_LTE];
} PLMN_IdentityListEUTRA_type;

typedef struct
{
    PLMN_IdentityListEUTRA_type plmn_IdentityList_eutra_epc;
    uint32_t trackingAreaCode_eutra_epc;  // BIT STRING (SIZE (16))
    uint32_t cellIdentity_eutra_epc;      // BIT STRING (SIZE (28))
} CellAccessRelatedInfo_EUTRA_EPC_type;

typedef struct
{
    unsigned short freqBandIndicator;
    uint8_t cgi_info_EPC_Flag;
    struct
    {
        CellAccessRelatedInfo_EUTRA_EPC_type cgi_info_EPC_legacy;
    } cgi_info_EPC; /* optional */
} CGI_InfoEutra_type;

typedef struct CGI_Info_Logging_type
{
    uint8_t tacFlag;

    plmnId_type plmn;
    uint64_t ci;
    uint32_t tac;  // optional;

} CGI_Info_Logging_type;

typedef struct
{
    uint8_t plmnIdentityEutra5gc_present     : 1;
    uint8_t trackingAreaCodeEutra5gc_present : 1;
    uint8_t cellIdentityEutra5gc_present     : 1;
    uint8_t plmnIdentityEutraEpc_present     : 1;
    uint8_t trackingAreaCodeEutraEpc_present : 1;
    uint8_t cellIdentityEutraEpc_present     : 1;

    plmnId_type plmnIdentityEutra5gc;   // VRIL_StoreNRRRC_plmn_Identity
    uint32_t trackingAreaCodeEutra5gc;  // VRIL_StoreNRRRC_TrackingAreaCodeEUTRA
    uint32_t cellIdentityEutra5gc;      // VRIL_StoreNRRRC_cellIdentityEUTRA
    plmnId_type plmnIdentityEutraEpc;   // VRIL_StoreNRRRC_plmn_Identity
    uint32_t trackingAreaCodeEutraEpc;  // VRIL_StoreNRRRC_TrackingAreaCodeEUTRA
    uint32_t cellIdentityEutraEpc;      // VRIL_StoreNRRRC_cellIdentityEUTRA
} CGI_InfoEutraLogging_type;

typedef struct
{
    uint8_t controlResourceSetZero;
    uint8_t searchSpaceZero;
} PDCCH_ConfigSIB1_type;

typedef struct
{
    uint8_t plmn_IdentityInfoList_Flag;
    uint8_t frequencyBandList_Flag;
    uint8_t noSIB1_Flag;

    PLMN_IdentityInfoList_type plmn_IdentityInfoList;
    multiFrequencyBandListNR_type frequencyBandList;
    struct
    {
        uint8_t ssb_SubcarrierOffset;
        PDCCH_ConfigSIB1_type pdcch_ConfigSIB1;
    } noSIB1;
} CGI_Info_type;

typedef struct
{
    uint8_t physCellIdFlag;
    uint8_t cgiInfoFlag;
    uint8_t isBestNbrResultFlag;

    uint16_t physCellId;   /* optional */
    uint16_t servCellId;   // SVR24A FGR-MC1022 FR150
    CGI_Info_type cgiInfo; /* optional */

    /* measResult */
    uint8_t rsIndexResultsFlag;

    cellResults_type cellResults;
    rsIndexResults_type rsIndexResults; /* optional */

} measResultNR_type;

typedef struct
{
    uint8_t nrofCellReport;
    measResultNR_type measResultNR[MAX_NUM_CELL_REPORT];
} measResultListNR_type;

typedef struct
{
    uint8_t ssbFrequency_Flag;
    uint8_t refFreqCSI_RS_Flag;
    uint8_t measResultServingCell_Flag;

    uint32_t ssbFrequency;                           /* optional */
    uint32_t refFreqCSI_RS;                          /* optional */
    measResultNR_type measResultServingCell;         /* optional */
    measResultListNR_type measResultNeighCellListNR; /* optional, measResultNeighCellListNR->nrofCellReport */
} measResult2NR_type;

typedef struct
{
    uint8_t nrofFreq;
    measResult2NR_type measResult2NR[MAX_NUM_FREQ];
} measResultList2NR_type;

typedef struct
{
    uint8_t cgiInfoFlag;

    uint16_t pci;
    CGI_InfoEutra_type cgiInfo; /* optional */
    measQuantityResults_type measResultEutra;
} measResultEUTRA_type;

typedef struct
{
    uint8_t numReportCell;
    uint32_t earfcnDl;
    measResultEUTRA_type measResult[MAX_NUM_CELL_REPORT];
} measResultNeighCellsEUTRA_type;

typedef struct
{
    uint8_t nrofCellReport;
    measResultNR_type measResultNR[MAX_NUM_CELL_REPORT + 1];  // MAX_NUM_CELL_REPORT + serving Cell
} measResultCandidateListForIdleLB_type;

typedef struct
{
    measResultList2NR_type measResultPerMOList;
} measResultSCG_Failure_type;

typedef struct
{
    uint8_t failureType;
    // measResultSCG_Failure_type      measSCG; // not used
} scgFailureInfo_type;

typedef struct
{
    uint8_t failureType_r16;
} scgFailureInfo_v1610_type;

typedef enum
{
    e_AllFreq = 0,
    e_FR1Freq = 1,
    e_FR2Freq = 2
} enumFrFreq_type;

/* configRestrictInfo in dfcbCgConfigInfo_type */
typedef struct
{
    uint32_t isSupportFR1Ca           : 1;
    uint32_t bandCombinationIndex     : 17;  // 1..65536
    uint32_t powerClassPresent        : 4;   // for NEDC
    uint32_t selectedBandEntryMNIndex : 8;   // for PCell
    uint32_t selectedBandEntryMNBitMap;
    uint8_t allowedFeatureSetsBitmask[16];  // 8 * 16 = 128 bits = MAX_NUM_FEATURESETSPERBAND
    uint8_t noofFreqBandIndi;
    uint16_t freqBandIndi[MAX_BANDS_PER_COMB];
} bandCombinationInfo_type;

typedef struct
{
    uint16_t nrofBandComb;
    uint16_t nrofBandCombFilteredSelectedBc;
    uint8_t powerClass;
    uint8_t mrdcType;
    uint16_t pcellBandIndi;
    uint16_t nrScsDl;
    uint16_t nrScsUl;
    uint16_t bandwidthDl;
    uint16_t bandwidthUl;
    uint32_t cellIdentity;

    bandCombinationInfo_type bandCombinationInfo[MAX_NUM_BAND_COMB];
    bandCombinationInfo_type bandCombinationInfoFilteredSelectedBc[MAX_NUM_BAND_COMB];
} bandCombinationInfoList_type;

typedef struct
{
    uint16_t nrofBaseBandProcComb;
    uint32_t bpcIndex[MAX_NUM_BASEBAND_PROC_COMB];
} bpcIndexList_type;

typedef struct
{
    uint8_t pMaxNR_FR1_Flag;
    uint8_t pMaxEUTRA_Flag;
    uint8_t pMaxUE_FR1_Flag;

    int16_t pMaxNR_FR1;  //(-30..33)
    int16_t pMaxEUTRA;   //(-30..33)
    int16_t pMaxUE_FR1;  //(-30..33)
} powerCoordination_FR1_type;

typedef struct
{
    uint16_t lowBound;
    uint16_t upBound;
} servCellIndexRangeSCG_type;

typedef struct
{
    uint16_t reducedCCsDL_r16;
    uint16_t reducedCCsUL_r16;
} ReducedMaxCCs_r16_type;

typedef struct
{
    uint8_t reducedBW_DL_r16;
    uint8_t reducedBW_UL_r16;
} ReducedMaxBW_FRx_r16_type;

typedef struct
{
    uint8_t reducedMIMO_LayersFRx_DL;
    uint8_t reducedMIMO_LayersFRx_UL;
} ReducedMaxMIMO_LayersFRx_type;

typedef struct
{
    uint16_t reducedMIMO_LayersFRx_DL;
    uint16_t reducedMIMO_LayersFRx_UL;
} MaxMIMO_LayersPreference_type;

typedef struct
{
    uint8_t isUpdated_Flag                          : 1;

    struct {
        uint8_t overheatingAssistance               : 1;
    } overheating_m;

    struct {
        uint8_t reducedMaxCCs                       : 1;
        uint8_t reducedMaxBW_FR1                    : 1;
        uint8_t reducedMaxBW_FR2                    : 1;
        uint8_t reducedMaxMIMO_LayersFR1            : 1;
        uint8_t reducedMaxMIMO_LayersFR2            : 1;
    } m;

    ReducedMaxCCs_r16_type reducedMaxCCs;
    ReducedMaxBW_FRx_r16_type reducedMaxBW_FR1;
    ReducedMaxBW_FRx_r16_type reducedMaxBW_FR2;
    ReducedMaxMIMO_LayersFRx_type reducedMaxMIMO_LayersFR1;
    ReducedMaxMIMO_LayersFRx_type reducedMaxMIMO_LayersFR2;
} OverheatingAssistance_type;

typedef struct
{
    uint8_t isUpdated_Flag                          : 1;

    struct {
        uint8_t maxCC_Preference                    : 1;
        uint8_t maxBW_Preference                    : 1;
        uint8_t maxMIMO_Preference                  : 1;
    } powersaving_m;

    struct {
        uint8_t reducedMaxCCs                       : 1;
        uint8_t reducedMaxBW_FR1                    : 1;
        uint8_t reducedMaxBW_FR2                    : 1;
        uint8_t reducedMaxMIMO_LayersFR1            : 1;
        uint8_t reducedMaxMIMO_LayersFR2            : 1;
    } m;

    ReducedMaxCCs_r16_type reducedMaxCCs;
    ReducedMaxBW_FRx_r16_type reducedMaxBW_FR1;
    ReducedMaxBW_FRx_r16_type reducedMaxBW_FR2;
    MaxMIMO_LayersPreference_type reducedMaxMIMO_LayersFR1;
    MaxMIMO_LayersPreference_type reducedMaxMIMO_LayersFR2;
} PowerSavingAssistance_type;

typedef struct
{
    uint8_t isUpdated_Flag                          : 1;
    uint8_t isF1ModSend_Flag                        : 1;
    uint8_t patternPreference_present               : 1;
    uint8_t patternPreference                       : 2; // 0..3
} UlGapFR2PreferenceAssistance_type;

typedef enum
{
    NR_RRC_TYPE_NO_ACTION = 0,
    NR_RRC_TYPE_SETUP_OR_MODI,
    NR_RRC_TYPE_RELEASE
} enumNrRrcSetRelease_type;

typedef struct
{
    uint8_t configured                      : 1;  // Flag On/Off
    uint8_t connectedReporting              : 1;  // Flag On/Off
    uint8_t releasePreferenceChangeFlag     : 2;  // for Only newConfig (enumNrRrcSetRelease_type)
    uint8_t releaseCallFlagByRxUeAssistInfo : 1;  // for Call Release.
    uint8_t releasePreferenceInactiveFlag   : 1;  // Flag On if NRRRC_inactive
    uint8_t reserved                        : 2;
    uint8_t releasePreferenceProhibitTimer_r16;  // NRRRC__enum195 (0..15)
} ueReleasePreferenceConfig_type;

typedef struct
{
    uint8_t configured : 1;  // Flag On/Off
    uint8_t changeFlag : 2;  // for Only newConfig (enumNrRrcSetRelease_type)
    uint8_t reserved   : 5;
    uint8_t prohibitTimer;
} ueNrRrcOtherConfigInfoIE_type;

typedef struct
{
    ueNrRrcOtherConfigInfoIE_type ueOverheatAssiConfig;
    ueNrRrcOtherConfigInfoIE_type ueMaxBWPrefConfig;
    ueNrRrcOtherConfigInfoIE_type ueMaxCCPrefConfig;
    ueNrRrcOtherConfigInfoIE_type ueMaxMIMOLayerPrefConfig;
    ueReleasePreferenceConfig_type ueRelPrefConfig;
    uint8_t ulGapFR2PreferenceConfig        : 1; // ON/OFF
} ueNrRrcOtherConfigInfo_type;

typedef struct
{
    ueNrRrcOtherConfigInfo_type currConfig;
    ueNrRrcOtherConfigInfo_type newConfig;
} ueNrRrcOtherConfig_type;

typedef struct
{
    union
    {
        struct
        {
            uint16_t allowedBC_ListMRDC_Flag : 1, powerCoordination_FR1_Flag : 1, servCellIndexRangeSCG_Flag : 1,
                maxMeasFreqsSCG_NR_Flag            : 1,
                maxIntraFreqMeasIdentitiesSCG_Flag : 1, maxInterFreqMeasIdentitiesSCG_Flag : 1,
                maxROHCsessionsSN_NR_Flag : 1, pdcchBlindDetectionSCG_Flag : 1, reserved : 8;
        };
        uint16_t value;
    };

    bandCombinationInfoList_type allowedBC_ListMRDC;
    powerCoordination_FR1_type powerCoordination_FR1;
    servCellIndexRangeSCG_type servCellIndexRangeSCG;
    uint8_t maxMeasFreqsSCG_NR;
    uint8_t maxIntraFreqMeasIdentitiesSCG;
    uint8_t maxInterFreqMeasIdentitiesSCG;
    uint8_t pdcchBlindDetectionSCG;
    uint16_t maxROHCsessionsSN;
} configRestrictInfoSCG_type;

/* drxInfoSCG in dfcbCgConfigInfo_type */
typedef struct
{
    uint16_t type; /* choice */
    uint16_t offset;
} drxLongCycleStartOffset_type;

typedef struct
{
    uint8_t drxShortCycle;
    uint16_t drxShortCycleTimer;
} shortDRX_type;

typedef struct
{
    uint8_t shortDRX_Flag;

    drxLongCycleStartOffset_type drxLongCycleStartOffset;
    shortDRX_type shortDRX;
} drxInfo_type;

/* measConfigMN in dfcbCgConfigInfo_type */
typedef struct
{
    uint8_t measuredFrequencyFlag;

    uint32_t measuredFrequency; /* optional */
} nrFreqInfo_type;

typedef struct
{
    uint8_t nrofMeasFreqsMN;
    nrFreqInfo_type nrFreqInfo[MAX_NUM_MEAS_FREQS_MN];
} nrFreqInfoList_type;

typedef struct
{
    struct
    {
        uint8_t refServCellIndicatorFlag : 1;
    } m;

    // mandatory IEs
    uint8_t gapOffset;  // INTEGER (0..159),
    uint8_t mgl  : 3;   // ENUMERATED {ms1dot5, ms3, ms3dot5, ms4, ms5dot5, ms6},
    uint8_t mgrp : 2;   // ENUMERATED {ms20, ms40, ms80, ms160},
    uint8_t mgta : 2;   // ENUMERATED {ms0, ms0dot25, ms0dot5}

    // optional IEs
    uint8_t refServCellIndicator;
} gapConfig_type;

typedef struct
{
    uint8_t flag;
    gapConfig_type gapConfig;
} measGapConfig_type;

typedef struct
{
    uint8_t measuredFrequenciesMN_Flag;
    uint8_t gapPurposeFlag;

    nrFreqInfoList_type measuredFrequenciesMN;
    measGapConfig_type measGapConfigFR1;
    measGapConfig_type measGapConfigFR2;
    uint8_t gapPurpose;
} measConfigMN_type;

typedef struct mGapCfgNode_s
{
    measGapConfig_type fr2;
    measGapConfig_type fr1;
    measGapConfig_type ue;
} mGapCfgNode_type;

typedef struct
{
    uint32_t ssbFrequency;
    uint8_t ssbSubcarrierSpacing;   // enumSubcarrierSpacing
    smtc1_type smtc1;
} measurementObjectNRDu_type;

typedef struct
{
    uint32_t overlappedCarrierFreq;  // store mapped earfcn, used to fill RRC
    uint8_t allowedMeasBandwidth;    // enumEutraAllowedMeasBandwidth_type
    uint8_t presenceAntennaPort1;    // BOOL
    uint8_t widebandRSRQMeas;        // BOOL
} measurementObjectEUTRADu_type;

typedef struct
{
    uint8_t objectId;      // 0-based, 0..63
    uint8_t ueObjectId;    // 0-based, 0..63, reference to UE configuration
    int8_t ratType;        // enumMeasRatType
    uint8_t local    : 1;  // BOOL, MO is originated on this gNB
    uint8_t snode    : 1;  // BOOL, MO is originated on SN - measuredFrequenciesSN
    uint8_t nrDlTdoa : 1;  // BOOL, MO is originated by NrDlTdoa

    union
    {
        measurementObjectNRDu_type nr;
        measurementObjectEUTRADu_type eutra;
    } rat;
} measurementObjectDu_type;

typedef struct
{
    measurementObjectDu_type items[MAX_NR_OF_OBJECT_ID_3GPP];
    uint8_t numItems;
} moListMgap_type;

typedef struct mGapDuData_s
{
    uint8_t moDuPreparedFlag     : 1;   // VCCB_FLAG_ON/OFF, SA only
    uint8_t moDuSentFlag         : 1;   // VCCB_FLAG_ON/OFF

    uint8_t mgrpPreference;
    uint8_t mrPurposeInfo;
    moListMgap_type moDuNew;
    mGapCfgNode_type mGapCfgNew;        // ENDC + SA (received from DU)
} mGapDuData_type;

typedef struct UlGapFr2Config_s
{
    uint8_t usage                           : 1; // ON/OFF
    uint8_t refFR2_ServCellAsyncCA_present  : 1; // ON/OFF
    uint8_t ugl                             : 2; // {ms0dot125, ms0dot25, ms0dot5, ms1}
    uint8_t ugrp                            : 2; // {ms5, ms20, ms40, ms160}
    uint8_t refFR2_ServCellAsyncCA          : 5; // 0..31
    uint8_t gapOffset;                           // 0..159
} UlGapFr2Config_type;

typedef struct
{
    uint8_t affectedCarrierFreqCombEUTRA_Flag;

    uint16_t numOfAffectedCarrierFreqCombEUTRA;
    uint16_t numOfAffectedCarrierFreqCombNR;
    uint32_t affectedCarrierFreqCombEUTRA[MAX_NR_OF_SERVING_CELLS_EUTRA];
    uint32_t affectedCarrierFreqCombNR[MAX_NR_OF_SERVING_CELLS];
} affectedCarrierFreqCombMRDC_type;

typedef struct
{
    uint8_t victimSystemType_gps;
    uint8_t victimSystemType_glonass;
    uint8_t victimSystemType_bds;
    uint8_t victimSystemType_galileo;
    uint8_t victimSystemType_wlan;
    uint8_t victimSystemType_bluetooth;
} victimSystemType_type;

typedef struct
{
    uint8_t affectedCarrierFreqCombMRDC_Flag;

    victimSystemType_type victimSystemType;
    uint8_t interferenceDirectionMRDC;
    affectedCarrierFreqCombMRDC_type affectedCarrierFreqCombMRDC;
} affectedCarrierFreqCombInfoListMRDC_type;

typedef struct
{
    uint8_t overheatingAssistanceSCG_r16_Flag;

    uint16_t numOfAffectedCarrierFreqCombInfoListMRDC;
    affectedCarrierFreqCombInfoListMRDC_type affectedCarrierFreqCombInfoListMRDC[MAX_NR_OF_COMB_IDC];
    overheatingAssistanceBuf_type overheatingAssistanceSCG_r16;
} mrdcAssistanceInfo_type;

typedef struct
{
    uint8_t type;        /* choice
                          * NRRRC_srb_Identity_chosen 1
                          * NRRRC_drb_Identity_chosen 2 */
    uint16_t rbIdentity; /* if type is NRRRC_srb_Identity_chosen : srbIdentity
                          * if type is NRRRC_drb_Identity_chosen : drbIdentity */
} servedRadioBearer_type;

typedef struct
{
    uint8_t type; /* choice
                   * NRRRC_am_chosen 1
                   * NRRRC_um_Bi_Directional_chosen 2
                   * NRRRC_um_Uni_Directional_UL_chosen 3
                   * NRRRC_um_Uni_Directional_DL_chosen 4 */
} rlcConfig_Full_type;

typedef struct
{
    uint8_t servedRadioBearer_Flag;
    uint8_t rlcConfig_Flag;

    uint16_t logicalChannelIdentity;
    servedRadioBearer_type servedRadioBearer; /* optional */
    rlcConfig_Full_type rlcConfig;            /* optional */
} rlcBearerConfig_Full_type;

typedef struct
{
    uint8_t useFlag[MAX_NUM_LC_ID];
    rlcBearerConfig_Full_type rlcBearerConfig[MAX_NUM_LC_ID];
} rlcBearerList_Full_type;

typedef struct
{
    uint8_t useFlag[MAX_NUM_SCELLS];
    // TODO
} sCellList_Full_type;

/**
 * @brief   Holds informations about current full CellGroupConfig
 */
typedef struct
{
    uint16_t cellGroupId;
    rlcBearerList_Full_type rlcBearerList;
} CellGroupConfig_Full_type;

// __B_ENDC__

typedef struct
{
    uint8_t earfcnDl_Flag;
    uint8_t earfcnUl_Flag;
    uint8_t trBWidth_Flag;

    unsigned int earfcnDl; /* optional */
    unsigned int earfcnUl; /* optional */
    unsigned int trBWidth; /* optional */
} ServCellInfoXcgEutra_type;

typedef struct
{
    ServCellInfoXcgEutra_type items[MAX_NR_OF_SERVING_CELLS_EUTRA];
    uint8_t numItems;
} ServCellInfoListMcgEutra_type;

#define MAX_UE_ASSISTANCE_INFORMATION_SCG_BUF 12

typedef struct
{
    uint32_t length;
    uint8_t data[MAX_UE_ASSISTANCE_INFORMATION_SCG_BUF];
} ueAssistanceInformationSCG_v1620_type;

typedef struct
{
    uint8_t  ph_Type1or3;
} PH_UplinkCarrier;

typedef struct
{
    uint8_t ph_SULFlag;
    uint8_t twoSRS_PUSCHRepetitionFlag;

    unsigned short servCellIndex;
    PH_UplinkCarrier ph_UL;
    PH_UplinkCarrier ph_SUL;
    uint8_t twoSRS_PUSCHRepetition;
} PHInfoDU_type;

typedef struct
{
    uint8_t numItems;
    PHInfoDU_type phInfoDU[MAX_NR_OF_SERVING_CELLS];
} PHTypeListDU_type;

typedef struct
{
    unsigned short freqBandIndicator;
    unsigned int carrierCenterFreq;
    unsigned short  carrierBandwidth;
    uint8_t subcarrierSpacing;
} FrequencyConfig;

typedef struct
{
    uint8_t dlFreqInfoFlag;
    uint8_t ulFreqInfoFlag;

    FrequencyConfig dl_FreqInfo;
    FrequencyConfig ul_FreqInfo;
} ServCellInfoXcgDU_type;

typedef struct
{
    uint8_t numItems;
    ServCellInfoXcgDU_type servCellInfoXcgDU[MAX_NR_OF_SERVING_CELLS];
} ServCellInfoListDU_type;

/* CgConfigInfo_type */
typedef struct
{
    // uint8_t                         ueContainerNR.rxFlag; /* move to callInfo_type for SA and NSA */
    // uint8_t                         ueContainerMRDC_Flag; /* move to callInfo_type for SA and NSA */
    uint8_t candidateCellInfoListMN_Flag;
    uint8_t candidateCellInfoListSN_Flag;
    uint8_t measResultCellListSFTD_Flag;
    uint8_t scgFailureInfoFlag;
    uint8_t scgFailureInfoFlag_v1610;
    uint8_t configRestrictInfoFlag;
    uint8_t drxInfoMCG_Flag;
    uint8_t measConfigMN_Flag;
    uint8_t sourceConfigSCG_Flag;
    uint8_t mrdcAssistanceInfoFlag;
    uint8_t ueAssistanceInformationSCG_v1620_Flag;

    // ueCapabilitiesRATcontainer_type ueContainerNR;          /* optional */ /* move to callInfo_type for SA and NSA */
    // ueCapabilitiesRATcontainer_type ueContainerMRDC;        /* optional */ /* move to callInfo_type for SA and NSA */
    // measResultList2NR_type          candidateCellInfoListMN;    /** < optional, Contains information regarding cells
    // that the master node suggests the target gNB to consider configuring. */ // not used, stored in ENV
    // measResultList2NR_type          candidateCellInfoListSN;    /** < optional, Contains information regarding cells
    // that the source node suggests the target gNB to consider configuring. */ // not used, stored in ENV
    measResultCellListSFTD_type measResultCellListSFTD; /** < optional, consists of SFN and radio frame boundary
                                                           difference between the PCell and an NR cell */
    scgFailureInfo_type scgFailureInfo;                 /* optional */
    scgFailureInfo_v1610_type scgFailureInfo_v1610;     /* optional */
    configRestrictInfoSCG_type configRestrictInfo;      /* optional */
    drxInfo_type drxInfoMCG;                            /* optional */
    measConfigMN_type measConfigMN;                     /* optional */
    mrdcAssistanceInfo_type mrdcAssistanceInfo;
    // servCellInfoListMcgEutra corresponds to first element of servCellInfoListMCG-EUTRA-r16 list (LTE PCell).
    ServCellInfoListMcgEutra_type servCellInfoListMcgEutra;
    ueAssistanceInformationSCG_v1620_type ueAssistanceInfoSCG_v1620;

} CgConfigInfo_type;

/**
 * @brief   Holds informations about current HO type
 */
typedef struct
{
    uint8_t rat;       /**< value of enumHoTypeRat */
    uint8_t nb;        /**< value of enumHoTypeNb */
    uint8_t du;        /**< value of enumHoTypeDu */
    uint8_t initiated; /**< value of enumHoTypeInitiated */
    uint8_t system;    /**< value of enumHoTypeSystemType */
    uint8_t interface; /**< value of enumHoTypeInterface */
} handoverType_type;

/**
 * @brief   Holds information after finished handover procedure
 */

typedef struct
{
    plmnId_type plmn;
    uint16_t numTac;
    union
    {
        uint16_t tac[X2_maxnoofForbTACs];       // X2:X2_maxnoofForbTACs
        uint32_t fiveGTac[NG_MaxnoofForbTACs];  // NG:NG_MaxnoofForbTACs, XN:XN_MaxnoofForbiddenTACs
    };
} forbiddenTA_type;

typedef struct
{
    plmnId_type plmn;
    uint16_t numTac;
    uint16_t firstValue;
    uint8_t diff[MAX_NUM_FORB_TA_COMPR_VAL];
} forbiddenTACompressed_type;

typedef struct
{
    plmnId_type plmn;
    uint16_t numTac;
    uint32_t firstValue;
    uint16_t diff[MAX_NUM_FORB_TA_COMPR_VAL_SA];
} forbidden5gTACompressed_type;

typedef struct
{
    plmnId_type plmn;
    uint8_t numLac;
    uint16_t lac[X2_maxnoofForbLACs];
} forbiddenLA_type;

// TODO : temp DB to relay the information when inter gnb xn handover.
// need to design
typedef struct
{
    plmnId_type plmn;

    struct {
        uint8_t RATRestrictionsExt_Present  : 1;
        uint8_t reserved                    : 7;
    } m;

    struct
    {
        uint8_t ratRestrictInfo;
    } base;

    struct
    {
        uint8_t primaryRatRestrictInfo;
        uint8_t secondaryRatRestrictInfo;
    } extension; // if RATRestrictionsExt_Present OPT_PRESENT, valid db

} ratRestrictions_type;

typedef struct
{
    uint8_t numTac;
    uint8_t tac[NG_MaxnoofAllowedAreas]
               [FIVEGS_TAC_OCT_LEN];  // NG:NG_MaxnoofAllowedAreas, NG_MaxnoofNonAllowedAreas, XN:XN_MaxnoofAllowedAreas
} allowedTac_type;

typedef struct
{
    plmnId_type plmn;
    allowedTac_type allowed;
    allowedTac_type not_allowed;
} serviceArea_type;

/* store CN type restriction Info for PLMN */
typedef struct
{
    uint8_t numRestrictPlmn;
    /*
    typedef enum NGAP__enum2 {
        NGAP_cn_Type_epc_forbidden = 0,
        NGAP_fiveGC_forbidden = 1
    } NGAP__enum2;
    */
    uint8_t cnTypeRestriction[NG_MaxnoofEPLMNs];  // This Value is NGAP Spec Defined. (NGAP__enum2)
    plmnId_type restrictPlmn[NG_MaxnoofEPLMNs];
} cnTypeRestrictForEplmn_type;

typedef struct
{
    uint8_t numNrAllowedPlmn;
    uint8_t numEutraAllowedPlmn;

    plmnId_type nrAllowedPlmn[NG_MaxnoofEPLMNsPlusOne];
    plmnId_type eutraAllowedPlmn[NG_MaxnoofEPLMNsPlusOne + 1];
} allwedPlmnList_type;

// --------------------------------------------------------------------

/**
 * @brief   Holds information for handover restriction list
 */
typedef struct
{
    uint8_t existFlag;
    uint8_t nrRestrictionType;
    plmnId_type servedPlmn;

    uint8_t numEplmn;
    uint16_t numForbidTaPlmn;
    // uint16_t                        numForbidLaPlmn; // not used

    plmnId_type ePlmn[X2_maxnoofEPLMNs];  // X2:X2_maxnoofEPLMNs, XN:XN_MaxnoofEPLMNs , NG:NG_MaxnoofEPLMNs
    forbiddenTA_type forbiddenTA[X2_maxnoofEPLMNsPlusOne];  // X2:X2_maxnoofEPLMNsPlusOne, XN:XN_MaxnoofPLMNs,
                                                            // NG:NG_MaxnoofEPLMNsPlusOne
    // forbiddenLA_type                forbiddenLA[X2_maxnoofEPLMNsPlusOne]; // not used
    uint8_t forbiddenRat;

    uint8_t numRatRestriction;
    ratRestrictions_type ratRestriction[NG_MaxnoofEPLMNsPlusOne];  // NG:NG_MaxnoofEPLMNsPlusOne, XN:XN_MaxnoofPLMNs

    uint8_t numServiceArea;
    serviceArea_type serviceArea[NG_MaxnoofEPLMNsPlusOne];  // NG:NG_MaxnoofEPLMNsPlusOne, XN:XN_MaxnoofPLMNs

    uint8_t lastEutraPlmnPresent;
    plmnId_type lastEutraPlmn;

    /* Core Network Type Restriction for Serving PLMN */
    uint8_t cnTypeRestrictForServingPlmn;  // true or false

    /* Core Network Type Restriction for Equivalent PLMNs */
    cnTypeRestrictForEplmn_type cnTypeRestrictForEplmn;

    /* Allowed PLMN List */
    allwedPlmnList_type allowedPlmnList[MaxRATRestriction];

} hoRestrictInfo_type;

typedef struct
{
    msgHdr_type msgHdr;
    uint16_t transactionId;
    uint16_t contextId;
    uint16_t reserved;
    uint16_t rrcPackedLength;
    uint8_t rrcPacked[MAX_BUF];
} rrcQueueingMessage_type;

typedef enum
{
    AMF_ASSIGN_FAIL_UNKNOWN_GUAMI_ID,
    AMF_ASSIGN_FAIL_INVALID_SET_ID,
} hoAmfAssignFaileCause_type;

typedef struct
{
    uint8_t existFlag;
    hoAmfAssignFaileCause_type cause;
    MdsIp_Type addr;
} hoAmfTnlAddrInfo_type;

/**
 * @brief   Holds compressed information for handover restriction list
 */
typedef struct
{
    uint8_t numRatRestriction;
    uint8_t numServiceArea;
    uint8_t existFlag;
    uint8_t nrRestrictionType;
    ratRestrictions_type ratRestriction[NG_MaxnoofEPLMNsPlusOne];
    serviceArea_type serviceArea[NG_MaxnoofEPLMNsPlusOne];
    plmnId_type servedPlmn;

    uint8_t numEplmn;
    uint16_t numForbidTaPlmn;

    plmnId_type ePlmn[X2_maxnoofEPLMNs];
    uint8_t forbiddenRat;

    uint8_t lastEutraPlmnPresent;
    plmnId_type lastEutraPlmn;

    /* Core Network Type Restriction for Serving PLMN */
    uint8_t cnTypeRestrictForServingPlmn;  // 'true' or 'false'

    /* Core Network Type Restriction for Equivalent PLMNs */
    cnTypeRestrictForEplmn_type cnTypeRestrictForEplmn;

    struct
    {                                                                              // HANDLE_5GC_MRL_CONTAINER_21B
        uint32_t length;                                                           // if length > 0, valid
        uint8_t value[XN_MAX_FIVE_GC_MOBILITY_RESTRICTION_LIST_CONTAINER_LENGTH];  // 2048 TODO_TODO
    } encoded;

    // ----------------------------------------------------------------
    // HAS VARIABLE SIZE BACKUP
    // Objects below this line are synced separately --- HAS VARIABLE PART */
    // sync only valid items
    // If you want add items, additional implementation required in ComLibUtility.c:FnVCCB_BackupCallInfo function
    // ---------------------------------------------------------------

    union
    {
        forbiddenTACompressed_type forbiddenTA[X2_maxnoofEPLMNsPlusOne];
        forbidden5gTACompressed_type forbidden5gTA[X2_maxnoofEPLMNsPlusOne];
    };

} hoRestrictInfoCompressed_type;

#define MAX_AMF_PLMN_PER_SUPPORTED_LIST 64
#define MAX_AMF_SET_PER_SUPPORTED_LIST  64

typedef struct
{
    unsigned int num_plmn;
    unsigned int num_set;

    struct
    {
        plmnId_type plmn;
    } amf_plmn[MAX_AMF_PLMN_PER_SUPPORTED_LIST];  // sizeof PLDAmfStatus::plmn

    struct
    {
        plmnId_type plmn;
        uint32_t region;
    } amf_set_info[MAX_AMF_SET_PER_SUPPORTED_LIST];  // sizeof PLDAmfStatus::plmn, amfInfo

} supportedAmfSetList_Type;

typedef struct
{
    plmnId_type plmn;
    uint32_t tac;

} selectedTAI_Type;

typedef struct
{
    unsigned int num_plmn;
    plmnId_type plmn[MAX_NUM_PLMN];

} allowedPlmnList_Type;

typedef enum
{
    intra5gs = 0,
    fivegs_to_eps = 1,
    eps_to_5gs = 2
} handover_Type;

// NR_CONN_MC_21D Start
typedef struct
{
    /* Optional */
    // uint32_t rS_IndexList_present   : 1;
    // uint32_t cgi_Info_present       : 1;
    // uint32_t reserved               : 30;

    uint16_t pci;
    measQuantityResults_type measResultCell;
    // struct RRC_MeasResultSSB_IndexList_r15_ *measResultRS_IndexList_r15;
    // RRC_CGI_InfoNR_r15 cgi_Info_r15
} measResultCellNR_type;

typedef struct
{
    uint32_t carrierFreq;  // ARFCN

    /* Optional */
    uint32_t sCell_present         : 1;  // OPT_PRESENT
    uint32_t bestNeighCell_present : 1;  // OPT_PRESENT
    uint32_t reserved              : 30;

    measResultCellNR_type sCell;
    measResultCellNR_type bestNeighCell;

} measResultServFreqNR_type;

// struct RRC_MeasResultServFreqListNR_r15_ *candidateCellInfoListNR_r15;
typedef struct
{
    uint8_t numResult;
    measResultServFreqNR_type measResultServFreqNR[MAX_NUM_SERVING_CELL];  // RRC_maxServCell_r13 : 32
} measResultServFreqListNR_type;                                           // RRC
// NR_CONN_MC_21D End

/**
 * @brief   store prev information for rollback when IntraGnbHandover cancel
 */
typedef struct
{
    uint8_t needToMeasForSaPriorHo;
    uint8_t rfspHoSupport;
    uint8_t iratMeasState;     // enumIRATMeasState
    uint8_t saIfMeasState;     // enumSaIFMeasState
    uint8_t lbIFMeasState;     // enumLbIFMeasState
    uint8_t forcedHoState;     // enumForcedHoRestrictionState_type
    uint8_t fpHoA1BasedState;  // enumA1BasedFpHoMeasState
    uint8_t iratLbHoTriggered;
    uint8_t iratLbHoState;
    uint8_t iratFollowA2Quantity;     // enumMeasTriggerQuantityChoice bitmap:RSRP(001),RSRQ(010),SINR(100) FGR-MC1007
                                      // SVR24B FR33, SVR25A FR34
    uint8_t intraNrFollowA2Quantity;  // enumMeasTriggerQuantityChoice SVR24B FGR-MC1007 FR33
                                      // bitmap:RSRP(001),RSRQ(010),SINR(100) FGR-MC1007 SVR24B FR33, SVR25A FR34
    uint8_t voNrLbState;              // enumVoNrLbState_type FGR-LC0712
    uint8_t saToNsaBorderHoMeas;
    uint8_t specificSliceForcedHoMeas; // enumSpecificSliceForHoMeas (26A: TRUE->enumSpecificSliceForHoMeas) need to configure specific slice HO meas
    uint8_t sliceAwareAutomodeState;   // enumSliceAwareAutomodeState_type
    uint8_t prioritySliceAwareState;   // enumPrioritySliceAwareState_type
} saMeasStateInfo_type;

typedef struct
{
    uint8_t a1ForFpPScellChgReceived;   // Whether or not A1 activation event was received for FP or SPID based FP after
                                        // PSCell change (Mobility ENDC FR 75-78)
    uint8_t nsaLbMeasState;             // NsaLbMeasState_enum
    uint8_t bearerChangeToMcgMeasFlag;  // VCCB_FLAG_ON/VCCB_FLAG_OFF
    uint8_t endcFr2MeasFlag;            // TRUE/FALSE
    enumIFMeasState ifMeasState;
} nsaMeasStateInfo_type;

typedef struct
{
    saMeasStateInfo_type saMeas;
    reportCgiInfo_type reportCgi;
    enumSrsConfigTriggered_type srsConfigTriggeredType;
} saPrevDbInfo_type;

typedef struct
{
    enumIFMeasState ifMeasState;
    reportCgiInfo_type reportCgi;
} nsaPrevDbInfo_type;

typedef struct
{
    uint16_t cellNum;  // cellNum of status
    timerInfo_type timer;
} saForcedHoRestrictionInfo_type;

typedef enum
{
    RCHO_Type_None = 0,
    RCHO_Type_duplicatePci = 1,
    RCHO_Type_nonNeighborCell = 2
} enumReportCgiHandoverType;

typedef struct
{
    uint8_t reportPurpose;
    uint8_t withMGap;  // NR_CONN_MC_21D
    uint8_t reportCgiHandoverType;    // enumReportCgiHandoverType
    uint8_t isDirectHandledMr;
    uint8_t reportConfigQuantitySaHo; /* RSRP(choice_rsrp) / RSRQ(choice_rsrq) / SINR(choice_sinr) / 0xFF */
    uint16_t priority;
    enumMeasurementReportType reportType;
    uint32_t cellNum;
    uint32_t frequency;
    uint32_t mrBufferUpdateCnt;

    timerInfo_type t4;  // HO triggering timer (timInternalHoTriggering_id)
    timerInfo_type t5;  // wait timer for the highest frequency priority MR (timInternalWaitHighestPriorityMr_id)
} callMrQueInfo_type;

typedef struct
{
    uint8_t reportPurpose;
    enumMeasurementReportType reportType;
} callMrQueInfoNsa_type;

#define MAX_DUPL_PCI_NBR_PER_CELL 8
typedef struct
{
    uint32_t cellNum;

    uint32_t frequency;
    enumMeasurementReportType reportType;
    uint8_t reportPurpose;
    uint8_t isReportCgiHandover; // duplicate PCI by default
    uint8_t isNonNeighborHandover;
    uint8_t qNumNbr;

    // additional information
    int priority;
    int priority_type;  // FP or RFSP
    uint8_t freqIdx;    // NRDC
    uint8_t pciIdx;     // NRDC
    uint16_t pci;      //for reportCgiHandoverInfo
    uint32_t freq;      //for reportCgiHandoverInfo
    // queue related DB?
    uint16_t qRelType[MAX_DUPL_PCI_NBR_PER_CELL];
    uint16_t qTargetCellNum[MAX_DUPL_PCI_NBR_PER_CELL];
    uint32_t qTargetCellBand[MAX_DUPL_PCI_NBR_PER_CELL];
    uint16_t qTargetNbrIdx[MAX_DUPL_PCI_NBR_PER_CELL];
    cgi_type qTargetNbrGnbCgi[MAX_DUPL_PCI_NBR_PER_CELL];
    enumMeasReportPriorAction_type action;
    uint8_t queueingFlag;
    uint8_t qWithMGap;  // NR_CONN_MC_21D - whether MR with MGAP or not
    selectedTAI_Type selectedTAI[MAX_DUPL_PCI_NBR_PER_CELL];
    int32_t qRank[MAX_DUPL_PCI_NBR_PER_CELL]; /** -1..10000 **/

    /* for Mobility For NR-DC */
    uint8_t reportConfigQuantitySaHo; /* RSRP(choice_rsrp) / RSRQ(choice_rsrq) / SINR(choice_sinr) / 0xFF */

    uint32_t mrBufferUpdateCnt;
} saMobilityMrInfo_type;

typedef struct {
    int16_t smallCellPciListIndex;
    uint8_t nonNeighborHOsupport;
    uint8_t reportType;
    uint8_t reportPurpose;
    uint8_t isMrsHo;                    // eutraType
    uint8_t checkTgtCellOvrloadFlag;    // nrType
} tgtSelectionParam_type;

typedef struct
{
    uint8_t usage;
    uint8_t freqIdx;    // NRDC
    uint8_t pciIdx;     // NRDC
    uint8_t reportConfigQuantitySaHo; /* RSRP(choice_rsrp) / RSRQ(choice_rsrq) / SINR(choice_sinr) / 0xFF */
    uint8_t relType;
    uint16_t pci;     //for reportCgiHandoverInfo
    /* for Mobility For NR-DC */

    uint32_t freq;    //for reportCgiHandoverInfo

    // queue related DB?
    uint8_t qNumNbr;
    uint16_t qRelType[MAX_DUPL_PCI_NBR_PER_CELL];
    uint16_t qTargetCellNum[MAX_DUPL_PCI_NBR_PER_CELL];
    uint32_t qTargetCellBand[MAX_DUPL_PCI_NBR_PER_CELL];
    uint16_t qTargetNbrIdx[MAX_DUPL_PCI_NBR_PER_CELL];
    cgi_type qTargetNbrGnbCgi[MAX_DUPL_PCI_NBR_PER_CELL];
    selectedTAI_Type selectedTAI[MAX_DUPL_PCI_NBR_PER_CELL];
    int32_t qRank[MAX_DUPL_PCI_NBR_PER_CELL]; /** -1..10000 **/
    uint32_t mrBufferUpdateCnt;
} saReportCgiHandoverInfo_type;


/**
 * @brief   Holds information for Inter MN HO w/s SN Change finalize purpose after X2 Reconfiguration Complete
 */
typedef struct
{
    uint8_t isFinalizeActive : 1;           // set TRUE for Inter MN HO w/o SN Change just after receiving
                                            // X2_Reconfiguration_Complete and set FALSE in other cases
    uint8_t isReceivedX2UeCxtRel : 1;       // set TRUE if receive X2UeContextRelease and set FALSE after processing for
                                            // Inter MN HO w/o SN Change
    uint8_t isReceivedF1UeCxtRelCompl : 1;  // set TRUE if receive F1_UEContextReleaseComplete from source DU and set
                                            // FALSE after processing for Inter MN HO w/o SN Change
    uint8_t hoDuType;
    callENBInfo_type srcENBInfo;
    uint16_t srcMnEndPointX2Idx;
    uint16_t srcDuEndPointF1Idx;
    uint32_t srcDuUEid;
    timerInfo_type timer;
} interMnHoFinalize_type;

typedef enum
{
    HoRptType_HoTooEarly = 0,
    HoRptType_HoToWrongCell = 1,
    HoRptType_InterSysPingPong = 2
} enumHoRptType;

typedef struct st_RanNodeIdType
{
    selectedTAI_Type selectedTai;
    vccbGlobalGnbId_type globalGnbId;
} RanNodeIdType;

#define MAX_VISITED_OCTET_STRING_DATA_LEN 28  // get from lte code (MAX_VISITED_UTRA_DATA)
typedef struct
{
    uint32_t numocts;
    uint8_t data[MAX_VISITED_OCTET_STRING_DATA_LEN];
} visitedOctetStringCellInfo_type;

typedef struct
{
    long length;
    unsigned char *value;
} octetStringType;

typedef struct
{
    struct
    {
        struct
        {
            // nr-RLF-Report-r16
            uint32_t previousPCellId            : 1;  // NRRRC_previousPCellId_r16_present
            uint32_t reconnectCellId            : 1;  // NRRRC_reconnectCellId_r16_present
            uint32_t timeUntilReconnection      : 1;  // NRRRC_timeUntilReconnection_16_present
            uint32_t reestablishmentCellId      : 1;  // NRRRC_reestablishmentCellId_r16_present
            uint32_t timeConnFailure            : 1;  // NRRRC_timeConnFailure_r16_present
            uint32_t measResultLastServCellRsrp : 1;  // TRUE : rsrp of measResultLastServCell-r16 exists [24A FGS-SF0509 FR100]
            uint32_t measResultNeighCellRsrp    : 1;  // TRUE : cell with strongest rsrp among measResultNeighCells-r16 exists [24A FGS-SF0509 FR100]
        } m;

        struct
        {
            uint32_t isNrPreviousPCellId     : 1;  // choice (TRUE : NR or FALSE : EUTRA) enumRlfReportChoice
            uint32_t isNrFailedPCellId_r16   : 1;  // choice (TRUE : NR or FALSE : EUTRA) enumRlfReportChoice
            uint32_t isNrReconnectCellId_r16 : 1;  // choice (TRUE : NR or FALSE : EUTRA) enumRlfReportChoice
            uint32_t isNrFailedCellGlobalId  : 1;  // choice (TRUE: cellGlobalId or FALSE : pci-arfcn)
        } c;


        // 1. nr-RLF-Report-r16
        CGI_Info_Logging_type nrPreviousCellId;  // previousPCellId-r16::nrPreviousCell-r16
        CGI_Info_Logging_type nrFailedPCellId;   // failedPCellId-r16-r16::nrPreviousCell-r16 ::cellGlobalId-r16

        uint8_t measResultLastServCellRsrp;  // measResultLastServCell_r16::rsrp
        uint8_t measResultNeighCellRsrp;     // RSRP of strongest cell among measResultNeighCells-r16
        uint16_t measResultNeighCellPci;     // PCI of strongest cell among measResultNeighCells-r16
        uint32_t measResultNeighCellSsbFreq; // SsbFreq of strongest cell among measResultNeighCells-r16

        uint16_t nrFailedPci;   // failedPCellId-r16-r16::nrFailedPCellId-r16 ::pci-arfcn-r16
        uint32_t nrFailedFreq;  // failedPCellId-r16-r16::nrFailedPCellId-r16 ::pci-arfcn-r16

        CGI_Info_Logging_type nrReconnectCellId;      // reconnectCellId-r16::nrReconnectCellId-r16
        CGI_Info_Logging_type reestablishmentCellId;  // reestablishmentCellId-r16::nrPreviousCell-r16

        CGI_InfoEutraLogging_type eutraPreviousCellId;
        CGI_InfoEutraLogging_type eutraFailedPCellId;
        CGI_InfoEutraLogging_type eutraReconnectCellId;

        uint32_t timeUntilReconnection;  // TimeUntilReconnection-16 :: INTEGER (0..172800)
        uint32_t timeConnFailure;        // INTEGER (0..1023)
        uint8_t connectionFailureType;   // connectionFailureType-r16 ENUMERATED {rlf, hof}
        uint32_t timeSinceFailure;
        uint16_t rlfCause;
        // TODO : locationInfo
        // TODO : noSuitableCellFound
        // TODO : ra-InformationCommon

        // 2. eutra_RLF_Report_r16
        CGI_InfoEutraLogging_type failedPCellIdEutra;
        octetStringType measResult;

    } rlf_report;  // get from rlf_report in message

    struct
    {
        struct {
            uint8_t rreConnRestabIndicator :1; // RRCConnReestab-Indicator IE
        } m;

        struct
        {
            uint16_t failureCellPCI;  // rre source pci
            uint16_t c_rnti;          // rre source crnti
            uint16_t shortMacI;       // rre source short mac-i
            uint8_t  rrcConnReestabIndicator; // rre cause from RRE req is delivered via RRC Conn Reestab Indicator via Xn Failure Ind wo RLF-Report
            cgi_type rreCellCGI;      // rre target cgi
            // cgi_type lastServingCellCGI;  // get from PCI, C-RNTI, shortMacI
        } rre;

    } failure_ind;

    struct
    {
        struct
        {
            uint8_t rreCellCGI : 1;  // set true it when CGI is nr CGI
        } m;

        uint8_t handoverReportType;
        uint16_t cause;  // Handover Cause
        cgi_type sourceCellCGI;
        cgi_type targetCellCGI;
        cgi_type rreCellCGI;  // C-ifHandoverReportType HoToWrongCell || CGI of cell where UE attempted re-establishment
        cgi_type targetCellInEutranCGI;
        uint16_t c_rnti;                                               // Source cell C-RNTI
        // Target cell in E-UTRAN
        // Mobility Information
        // UE RLF Report Container

    } ho_report;

    struct
    {
        struct
        {
            uint8_t rlfInfoAvailable : 1;  // update : After rreComplete or rrcSetupComplete
        } m;

        // RRCSetupComplete-v1610-IEs::ueMeasurementsAvailable-r16::rlf-InfoAvailable-r16
        // RRCReestablishmentComplete-v1610-IEs::ueMeasurementsAvailable-r16::rlf-InfoAvailable-r16
        cgi_type sourceCellCGI;  // update : VRIL_storeNRRRC_RrcReestablishmentRequest, used only for intra gNB RRE
        cgi_type targetCellCGI;  // update : VRIL_storeNRRRC_RrcReestablishmentRequest, used only for intra gNB RRE
        uint8_t rreCause;        // update : VRIL_storeNRRRC_RrcReestablishmentRequest

    } msg5;

    struct
    {
        cgi_type sourceCellCGI;                                        // update : ho start time
        cgi_type targetCellCGI;                                        // update : ho start time
        cgi_type targetCellCGIInEutran;                                // for IRAT MRO NG
        struct timespec timestamp;                                     // update : ho complete(rrcReconfigComplete)

        uint8_t hoInitiated;       // set only when trigger HO on source gNB

        uint8_t isA2Installed   : 1;
        uint8_t needToCheckLoad : 1;    //TRUE: CPU overload check is required. 26B FGS-SF0509:FR130, FGS-SF0510:FR180
        uint8_t isOverloaded    : 1;    //TRUE: CPU overload check result is overloaded. 26B FGS-SF0509:FR130, FGS-SF0510:FR180
        uint8_t reserved        : 5;
        uint16_t msgId;
    } ue;

    struct
    {
        RanNodeIdType sourceNodeInfo;
        RanNodeIdType targetNodeInfo;

        uint8_t isInterSystem;
        uint8_t choice;
        struct
        {
            uint8_t rcvdInterSysHO_UnnecessaryHO : 1;
            uint8_t earlyIRATHO                  : 1;  // FR50
            uint8_t reserved                     : 6;
        } m;

        struct
        {
            struct
            {
                uint8_t reestablishmentCellCgi : 1;
                uint8_t reserved     : 7;
            } m;

            enumHoRptType handoverReportType;
            uint16_t handoverCause;
            cgi_type sourceCellCgi;
            cgi_type targetCellCgi;
            cgi_type reestablishmentCellCgi;
            cgi_type targetCellInEutranCGI;
        } hoRpt;
    } sonInfo;

    struct
    {
        uint32_t isAble        :1;  //TRUE : available to send NG Son Configuration Transfer
        uint32_t hoReportType  :2;  //NGAP__enum7
        uint32_t reserved      :29;

        uint32_t tAC;
    } ableToSendNgSonConfigTransfer;

    uint32_t waitRrcUeInfoResp              :1;  // TRUE : MRO is waiting for RrcUeInformationResponse
    uint32_t isHoCmdTransmitted             :1;  // set true in VCCM_INTER_S_ProcHandoverFromPrepToExe
    uint32_t needPingPongHORpt              :1;
    uint32_t interSystemMeasConfigFlag      :1;  // set TRUE in FnVCCB_IncludeInterSysMeasConfig
    uint32_t hoTriggerType                  :3;  //set In/Out HO Cause
    uint32_t reserved                       :25;

    upmAlgoInfoForCall_type upmAlgoInfoInstalled;

    plmnId_type plmnForNgSelectedTai; // SVR23B FGS-SF0509(FR21)/FGS-SF0510(FR41)

    timerInfo_type waitUeInfoResp;
} mro_type;

// Basic information of retrieved RLF-Report-r16. This can be referred by MRO and MDT both
typedef struct
{
    uint8_t received                :1; // TRUE: RLF-Report-r16 retrieved via UE RRC Info Resp/Failure Ind/HO report
    uint8_t choice                  :1; // choice (1 : NR or 0 : EUTRA) enumRlfReportChoice

    uint8_t isLastServingCellValid  :1; // TRUE: LastServingCellId is valid
    uint8_t reserved                :5;
    CGI_Info_Logging_type LastServingCellId; // derived by connetionFailureType and one of failedPCellId or previousPCellId
    uint8_t *pDecoded;      // decoded nr-RLF-Report-r16
    crnti_type c_rnti;      // c-RNTI-r16. used to find UE context
} rlfReport_type;

/* Data forwarding common DB (PDU) */
// If information is added, it is necessary to review it from the viewpoint of Conditional Handover Feature.
// {{{
typedef struct
{
    transportLayerInfo_type ul;  // PDU forwarding tunnel
    transportLayerInfo_type dl;  // PDU forwarding tunnel
} PduDataFwdTunnel_type;
// }}}

/* Data forwarding common DB (QOS FLOW) */
// If information is added, it is necessary to review it from the viewpoint of Conditional Handover Feature.
// {{{
typedef struct
{
    uint8_t dlForwardProposed : 1;
    uint8_t dlForward         : 1;

    uint8_t ulForwardProposed : 1;
    uint8_t ulForward         : 1;

    uint8_t toBeForwardedList       : 1;
    uint8_t toBeForwardedListResult : 1;

    // TGT_RSP_BASED_QFI_DATA_FWD_21D
    uint8_t dlForwardAccepted : 1;  // from the target NG-RAN accept
    uint8_t ulForwardAccepted : 1;  // from the target NG-RAN accept
} QosFlowDataFwdInfo_type;
// }}}

/* Data forwarding common DB (DRB) */
// If information is added, it is necessary to review it from the viewpoint of Conditional Handover Feature.
// {{{
typedef struct
{
    transportLayerInfo_type ul;
    transportLayerInfo_type dl;
} DrbDataFwdTunnel_type;

typedef struct
{
    uint8_t needSendFlag;
    uint32_t ulSN;
    uint32_t dlSN;
    uint32_t ulHFN;
    uint32_t dlHFN;
} DrbPdcpSnStatus_type;

typedef struct
{
    DrbDataFwdTunnel_type gtpTunnel;
    DrbPdcpSnStatus_type snStatus;
} drbDataFwdInfo_type;
// }}}

/* Buffer to store various messages from DU/eNB */
typedef struct
{
    uint16_t numocts;
    // uint8_t data[MAX_HO_PREPARATION_INFO_SIZE]; // Move to External DB.
} hoPreparationInfoContainer_type;

/**
 * @brief hoCancelControlInfo_type
 *
 * This union defines the structure for hoCancelControlInfo_type.
 */
typedef union
{
    struct
    {
        /**
         * @brief needSnRelease
         *
         * This flag indicates whether the SN release is required when the handover cancel process is performed.
         */
        uint32_t needSnRelease      : 1;

        /**
         * @brief needCallReleaseWithoutHoCancelProcess
         *
         * This flag indicates whether the Call release is required when the handover cancel process is not performed.
         */
        uint32_t needCallReleaseWithoutHoCancelProcess  : 1;

        /**
         * @brief needServiceBorderBlindRediretion
         *
         * This flag indicates whether the service border blind redirection is required when the handover cancel process is not performed.
         */
        uint32_t needServiceBorderBlindRediretion : 1;
    };

    // warning : Do not use this FLAG yourself. This is an operation for initialization.
    //           This is to remove the unnecessary behavior of initializing whenever a new flag is added.
    uint32_t clearFlag;
} hoCancelControlInfo_type;

/**
 * @brief FGR-LC0708 Load based PSCell Change for EN-DC
 *        Related LB measurements state.
 *
 */
enum NsaLbMeasState_enum
{
    NSA_LB_MEAS_STATE_UNKNOWN = 0,
    NSA_LB_MEAS_STATE_ACTIVE,
    NSA_LB_MEAS_STATE_INACTIVE
};

/* FGR-MC1007 FR500~FR570: ping-pong avoidance NR frequency restriction */
typedef enum
{
    PPA_OFF = 0,
    PPA_NOT_RESTRICT = 1,
    PPA_RESTRICT = 2,
} enumPingPongAvoidanceRestrictStatus_type;

typedef enum
{
    RESTRICT_OPT_NONE = 0,
    RESTRICT_OPT_SSB_FREQ = 1,
    RESTRICT_OPT_BAND = 2,
    RESTRICT_OPT_FR_TYPE = 3,
    RESTRICT_OPT_DUPLEX_TYPE = 4,
    RESTRICT_OPT_ALL = 5,
} enumPingPongAvoidanceRestrictOption_type;

typedef struct
{
    uint8_t status:4; /**< enumPingPongAvoidanceRestrictStatus_type */
    uint8_t prevPpaRestrictFlag:1;
    uint8_t measObjIdx;
    cgi_type ncgi;
    uint32_t startTime;
    uint32_t restrictTime;
    uint32_t ssbFrequency;
} ppaRestrictInfo_type;

/**
 * @brief   Holds information for current handover procedure
 */
typedef struct
{
    uint16_t cause;
    uint8_t isTarget;  // TRUE, FALSE
    uint8_t isLbHo;     // FGR-LC0708
    uint8_t isIratLbHo; // SVR23B FGR-LC0711
    uint8_t isVoNrLbHo; // SVR24B FGR-LC0712 TRUE, FALSE
    uint8_t reserved3;
    uint8_t reportType;         // sahandover trigger reportType
    uint8_t reportPurpose;      // sahandover trigger reportPurpose
    handoverType_type hoType;
    uint8_t sgnbAddTrigInd;        // enumSgnbAddTrigInd Valid for SgNB Addition pro
    uint8_t choTriggerInd;         // Save the Trigger Cause of Handover Request for ConditionalHandover
    uint8_t endcHoRollbackActive;  // TRUE, FALSE
    uint16_t hoGnbIdx;             // Index of callGNBInfo_type gnbInfo[MAX_GNB_PER_CALL]
    uint16_t targetCellNum;        // For Intra-gNB Index
    uint16_t targetCellBand;       // For Intra-gNB Index
    uint16_t tgtNbrGnbCell;        // For Inter-gNB Index
    cgi_type cgi;
    duHoInfo_type targetDu;
    uint16_t cellIdentity;
    uint8_t targetcRNTIUsage;
    crnti_type targetcRNTI;
    uint32_t tgtSsbFreq;         // for interFreq Statistics
    plmnId_type tgtPlmn;         // for intrePlmn Statistics / EN-DC: target UE serving PLMN.
    Stopwatch_type rrcSpCellChgTime;
    uint8_t nsaLbMeasState; // NsaLbMeasState_enum

    uint16_t scgMeasResultList2NRSize;  // size of scgMeasResultList2NRPacked

    union
    {
        /* data */
        gnbHoInfo_type targetGnb;  // Valid if hoType.initiated == HO_TYPE_SA_MGNB_INTERMNHO // For NE-DC (SN)
        enbHoInfo_type targetEnb;  // Valid if hoType.initiated == HO_TYPE_MENB_INTERMNHO    // For EN-DC (SN)
    };

    selectedTAI_Type selectedTAI;

    struct
    {
        timerInfo_type e1;
        timerInfo_type f1;
        timerInfo_type xn;  // MR-DC (SNodeAddition, SNodeModification, ...)
        timerInfo_type spec;
    } timer;

    NGAP_NASSecurityParametersFromNGRAN_type
        nASSecurityParametersFromNGRAN;  // inter system inter rat handover security buffer

    uint32_t tArfcn;           // IRAT HO - gNB shall redirect the UE to the Target LTE frequency
    uint16_t phyCellId;        /**< INTEGER (0..1007) */
    uint8_t srcServingCellMO;  // store servingCellMO from source gNB, 0 - not present
    uint8_t mrWithMGap;        // Inter Frequency Handover with Measurement Gap // NR_CONN_MC_21D

    /* for HO Time */
    uint8_t HOTimeFlag;
    struct timespec HOtHoAck;
    struct timespec HOtReconfigCmpl;

    /* for Outgoing HO Time */ // IRAT_HO_23B
    uint8_t OutHOTimeFlag;
    struct timespec HOtHoRqd;
    struct timespec HOtUeCtxtRelCmpl;

    uint8_t reportConfigQuantitySaHo; /* RSRP(choice_rsrp) / RSRQ(choice_rsrq) / SINR(choice_sinr) / 0xFF */

    union
    {
        struct
        {
            /* 0 ~ 7 */
            uint64_t directFwdAvailable     : 1;
            uint64_t qDiscardMR             : 1;
            uint64_t needNgHO               : 1; /* TRUE: Priority is selected for Ng Handover. */
            uint64_t noCGConfigQuery        : 1; /* TRUE: MCG/SCG Cell Group Config query procedure not performed. */
            uint64_t ueContextKeptInd       : 1; /* TRUE: XN HandoverRequestAcknowledge includes UE Context Kept Indicator */
            uint64_t receivedCoresetId0     : 1; /* TRUE: The CORESETID in CellGroupConfig is 0 at least one. */
            uint64_t sendF1ModReqToTarget   : 1; /* TRUE: need to send F1ModReq to target DU. */
            uint64_t newUlTnlInfoRequired   : 1; /* TRUE: new UL TNL Information Required IE is transmitted */

            /* 8 ~ 15*/
            uint64_t hoUsingSRB3                : 1; /* TRUE: This indicates NR PSCell Change is processed through SRB3 */
            uint64_t ueContextRefInfo           : 1; /* TRUE: while HO with NR2EN-DC/EN-DC2NR */        // IRAT_HO_CTRL_CONSID_21D
            uint64_t sgNBUeX2apId               : 1; /* TRUE: SgNB UE X2AP ID is included in HO Request */  // IRAT_HO_CTRL_CONSID_21D
            uint64_t directDataFwdFromTarget    : 1; /* Direct forwarding tunnels from the target  */
            uint64_t MN_SnReleaseAfterHandover  : 1; /* TRUE: If it is necessary to release SN after handover, it should be On. */
            uint64_t conditionalHandover        : 1; /* TRUE: It becomes TRUE when PCELL is changed by Conditional Handover function. */
            uint64_t trafficBasedHoFlag         : 1;  /* TRUE: */
            uint64_t handoverExecutionFlag : 1; /* TRUE: Set when Handover Execution Phase */

            /* 16 ~ 23 */
            uint64_t interGnbSrcConnectionFlag : 1;  // TRUE : Indicates whether the target connection on the source side exists.
            uint64_t interGnbTgtConnectionFlag : 1;  // TRUE : Indicates whether the source connection of the target side exists.
            uint64_t nonNbrCell                : 1;  // TRUE : target is non-neighbor cell (like E-UTRA smallcell) // IRAT_HO_23B
            uint64_t gnbOverload               : 1;  // TRUE : gNB is overloaded // gNB Overload Control 23B
            uint64_t acceptUeInOverloadedGnb   : 1;  // TRUE : gNB is overloaded and UE is an emergency(or HPA, MPS) call // gNB Overload Control 23B, 26B
            uint64_t isVonrCall                : 1;  // TRUE : UE is VoNR call // HO_STAT_VoNR 23B
            uint64_t interRatPccHoFlag         : 1;  /* Indicates whether PCC Inter-RAT Handover */
            uint64_t pccChangeHoFlag           : 1;  /* Indicates whether PCC Change Handover */ // SVR23B_PCC_CHANGE

            /* 24 ~ 31 */
            uint64_t slbPccChangeHoFlag               : 1;  /* Indicates whether SB PCC Change Handover */
            uint64_t interRatMrsHoFlag                : 1;  /* Indicates whether MRS Inter-RAT Handover */ // SVR23B_MRS
            uint64_t sendableUeCapaMRDC               : 1;  /* TRUE: When ueContainerMRDC is capable of being sent */
            uint64_t internalFwdAvailable             : 1;  /* TRUE: Internal forwarding where gNB (SA) and SgNB (ENDC) are the same node */
            uint64_t allPduSessDirectFwdPathAvailable : 1; /* TRUE: All PDU Sessions includes Direct Path Available IE */
            uint64_t isSnInitMobilityInMn             : 1; /* TRUE: This value is set only in MRDC-MN and becomes ON when performing Sn Init Mobility. */
            uint64_t isVoNRBorderMobility             : 1; /* TRUE: This value is set when vonr service border condition ue trigger Intra NR handover */
            uint64_t needHoCancelForPdu               : 1; /* TRUE : Cancel ongoing inter gnb HO when STATE_INTER_Pre_DU_S state */

            /* 32 ~ 39 */
            uint64_t notSupportedVonr                      : 1; // TRUE: F1 Failure or F1 Resp w/ cause "Not supported QCI value" for 5QI 1
            uint64_t currentlyAllowPartial                 : 1; // true: allow partial over I/F currently. Set to true when HO starts; cannot be set to true again afterward, only to false
            uint64_t serviceBorderFlag                     : 1;    // true: service border mobility
            uint64_t sliceRejectionStats                   : 1; // true: E1/F1 fail cause is NotAvailableForTheSlice
            uint64_t ltmReleaseRequired                    : 1;  // true when LTM release required in inter gnb hand-in case
            uint64_t isLtmCellSwitch                       : 1;
            uint64_t isSpecificSliceForcedMobilityTargetUe : 1; // true: target UE to trigger specific slice border mobility
            uint64_t specificSliceForcedMobilityFlag       : 1; // TRUE: collect stat for specific slice border mobility

            /* 40 ~ 47 */
            uint64_t ltmHandover              : 1;
            uint64_t interDuHoWithoutSourceDu : 1; // TRUE: NSA inter-DU HO when source DU is released (e.g. after SN term Split -> SN term MCG).
            uint64_t isSliceLbHoForRedcap     : 1; // TRUE: Slice LB HO for RedCap UE

            uint64_t reserved : 21;
        };

        // warning : Do not use this FLAG yourself. This is an operation for initialization.
        //           This is to remove the unnecessary behavior of initializing whenever a new flag is added.
        uint64_t clearFlag;
    };

    hoCancelControlInfo_type cancelControl;
    mGapDuData_type mGapDuTarget;
    UlGapFr2Config_type ulGapFr2ConfigDu;
    ppaRestrictInfo_type ppaRestrictPrev; /**< FGR-MC1007 FR540: backup for HO cancel rollback */

    // ----------------------------------------------------------------
    // NON INITIALIZE PART
    //
    // 'measResultList2NRPacked' is a border mark
    // If you decide that initialization is necessary, declare it above 'measResultList2NRPacked'.
    // ----------------------------------------------------------------
    // mapped measResultList2NRSize
    uint8_t measResultList2NRPacked[MAX_MEASRESULTLIST2NR_SIZE];
    uint8_t scgMeasResultList2NRPacked[MAX_MEASRESULTLIST2NR_SIZE];

    /* length is initialized in VLIB_InitHoInfo. */
    hoPreparationInfoContainer_type hoPreparationInfo;

    vccbGlobalGnbId_type sourceNGRANNodeID;
} handoverInfo_type;

typedef enum
{
    /* Non-RACH - with RRC Reconfiguration Scenario */
    e_ChoApplyByConditionalHandoverCancel, /* By Conditional Handover Cancel */
    e_ChoApplyByReleaseTimerExpiry,        /* By Conditional Cell Release Timer Expiry */
    e_ChoApplyByReconfigQueue,             /* By Conditional Cell Release Queueing */

    /* RACH without RRC Reconfiguration Scenario */
    e_HandoverComplete,                       /* By Handover success after RACH */
    e_ChoApplyByConditionalHandoverExecution, /* By Conditional Handover Execution */
    e_ChoApplyByRRE,

    /* UE doing RRC release */
    e_ChoApplyByRRCSuspend, /* By RRC Release with SCG Suspend */
    e_ChoApplyByUeRelease,  /* By RRC Release */

    e_MaxOfCondition
} enumConditionalHandoverApplyScenarioType;

typedef enum
{
    e_HoTrigger_InitValue = 0,  // This value is not used.
    e_HoTrigger_ImmediateHandover,
    e_HoTrigger_ConditionalHandoverPrep,
    e_HoTrigger_ConditionalHandoverExec,
    e_HoTrigger_LtmHandoverPrep,
    e_HoTrigger_LtmHandoverExec,
} enumHandoverTriggerType;

typedef enum
{
    e_CondEvent_1,
    e_CondEvent_2,
    e_MaxNumOfCondExecutionCond
} condEvent_type;

typedef enum
{
    e_ChoTriggerCause_initiation,
    e_ChoTriggerCause_replace,
    e_ChoTriggerCause_Unknown,
} enumCHOtriggerCauseType;

typedef struct
{
    // Common
    uint32_t ssbFrequency;  // Only This Parameter, Fill Start Handover Function
    uint16_t bandNr;
    uint16_t reserved;

    // CondEvent
    uint8_t condEventMeasIdInstalled[MAX_NUM_OF_COND_EXECUTION_COND];
    uint8_t condEventMeasIdNew[MAX_NUM_OF_COND_EXECUTION_COND];

} conditionalCellMeasInfo_type;

typedef struct
{
    uint8_t usage       : 1;
    uint8_t condCellIdx : 7;  // my index in condCellList.

    // Setup   ::= Conditional Preparation Setup Flow
    // Idle    ::= Conditional Preparation Processing Complete
    // Modify  ::= Conditional Preparation Need Change (MeasConfig, ...)
    // Release ::= Conditional Preparation Release Flow

    uint8_t condStatus;  // Common_Idle, Common_Setup, Common_Modify Common_Release
    uint8_t statCause;   // S_Release determines the reason for execution. This is an operation for collecting
                        // statistics. enumChoStatType

    struct
    {
        uint8_t inter_gnb_s_connection_flag : 1;  // Indicates whether the target connection on the source side exists.
        uint8_t inter_gnb_t_connection_flag : 1;  // Indicates whether the source connection of the target side exists.
        uint8_t rrc_activation_flag         : 1;  // Indicates whether the resource is setup in the UE.
        uint8_t to_resp_cho_cancel          : 1;  // Record the time when Conditional Handover Cancel is required. (TODO :TO_RESP)
        uint8_t crntiUsage                  : 1;  // Usage of condCellInfo.crnti
        uint8_t collectableCandidateRelStat : 1;  // Manages whether CandidateRelStat is in the collectible state.
        uint8_t run_execution               : 1;  // Indicates that the CHO Execution procedure was performed.
        uint8_t to_be_release               : 1;  // Refers to the candidate group to be released. (queuing or timeout)
    } flag;

    cgi_type nrcgi;  // NRCGI of Target Cell

    pci_type pci;
    crnti_type crnti;  // Check sanity with flag.crntiUsage

    selectedTAI_Type selectedTAI;

    struct
    {
        uint8_t usage;      // use, no_use
        uint8_t interface;  // f1, xn, e1, ..
        uint16_t endIdx;    // 0 ..
        uint64_t neId;      // identity of ne (xnGnbIdx, duId, ...)
        uint64_t ueId;      // identity in ne (xnUeId, duUeId, ...)
    } endPointInfo[MAX_NUM_OF_ENDPOINTS_FOR_COND_CELL];

    // FR100.CACP.SR1.HD1 - DataForwarding
    struct
    {
        union
        {
            struct  // For SA - CHO & CPC
            {
                struct
                {
                    QosFlowDataFwdInfo_type info;
                } qosFlow[MAX_QOS_FLOW_PER_CALL];

                // pdu
                struct
                {
                    PduDataFwdTunnel_type tunnel;
                } pdu[MAX_PDU_SESS_PER_CALL];

                // drb
                struct
                {
                    DrbDataFwdTunnel_type tunnel;
                } drb[MAX_DRB_PER_SA_CALL];
            };

            struct  // For NSA - CPC
            {
                struct
                {
                    // TODO : CPC Feature
                    uint8_t reserved;
                } erab[MAX_ERAB_PER_CALL];
            };
        };
    } dataForward;

    // Statistics
    struct timespec tCondCellSetupCmpl;  // When RRCReconfigurationComplete(For CHO Add) is received

    // MeasInfo
    conditionalCellMeasInfo_type measInfo;

    // timer
    timerInfo_type condCellReleaseTimer;  // CHO candidate release timer - source/target side

} conditionalCellInfo_type;

typedef struct
{
    /* Conditional Handover Information Control Flag */
    struct
    {
        uint8_t to_be_blocklisted                 : 1;
        uint8_t stopAndConditionalHandoverTrigger : 1; /* TRUE: Stop the current procedure and perform Conditional
                                                          Handover. */
        uint8_t reserved1 : 6;
    } flag;
    uint8_t reserved;    // Padding Byte
    uint64_t currentCi;  // to check whether the cell is changed

    cgi_type targetCgi;                  // For Conditional Handover Execution
    struct timespec tXnHandoverSuccess;  // When XNHandoverSuccess is received

    /* Range : 0(OFF) ~ 8(MAX_NUM_COND_CELLS), Detail : Number of Cond Cell Lists */
    uint8_t numOfCellList;
    conditionalCellInfo_type cellList[MAX_NUM_COND_CELLS];
} conditionalHandoverInfo_type;

// This ENUM specifies the reason for handover occurrence and is the basis for statistics collection.
typedef enum
{
    HoPurpose_DLQuality,
    HoPurpose_Reserved
} enumHoPurpose_type;

typedef struct
{
    struct
    {
        unsigned dLCoordinationInformationPresent                : 1;
        unsigned id_NRCGIPresent                                 : 1;
        unsigned id_MeNBCoordinationAssistanceInformationPresent : 1;
    } m;

    X2_ECGI_type eUTRA_Cell_ID;
    X2_CoordinationInformation_type uLCoordinationInformation;
    X2_CoordinationInformation_type dLCoordinationInformation;
    X2_NRCGI_type id_NRCGI;
    X2_MeNBCoordinationAssistanceInformation_type id_MeNBCoordinationAssistanceInformation;
} MeNBResourceCoordinationInfo_type;  // X2_MeNBResourceCoordinationInformation_type

typedef struct
{
    uint8_t usage;
    uint8_t resetEventType;  // 23A_NRRetainability
    uint16_t e1Idx;
    uint16_t e1Cause;
    uint64_t aupfId;
    enumActivityStatus_type ueActivityStatus;
} CallAupf_type;

typedef struct
{
    // X2
    uint16_t x2Idx;
    uint32_t enbId;

    // F1
    uint16_t f1Idx;  // gutran-cu-cell/mapping-end-point-f1-index
    uint64_t gnbDuId;

    // NG
    uint16_t ngIdx;
    uint16_t ngTnlIdx;

    // XN
    uint16_t xnIdx;  // Using Handover / RRE / Resume
    uint32_t xnGnbId;

    // E1 - MultiUp per call
    uint16_t srvAupfNum;  // MultiUp per call support: Number of serving AUPFs
    CallAupf_type aupf[MAX_CU_UP_PER_CALL];
} endPoint_type;

typedef struct
{
    uint8_t flag[MAX_VCCB_FAMILY_TYPE];  // 0: no attempt, 1: attempt collected 2: prep succ 3: succ/fail collected
} vccbStat_type;

typedef struct
{
    // 4Byte
    cgi_type cgi; /**< Cell Global ID of visited cell */

    // 4Byte
    uint16_t pci;                    /**< Physical Cell ID of visited cell */
    uint8_t hoCausePresent;          /**< If reason of Handover is present */
    uint8_t stayTimeEnhancedPresent; /**< If stayTimeEnhanced is present */

    // 4Byte
    uint32_t stayTime; /**< Number of stay seconds in visited cell */

    // 4Byte
    uint8_t cellSize;          /**< Cell Size of visited cell(NGAP_CellSize) */
    uint8_t reserved1;         /**< Rserved */
    uint16_t stayTimeEnhanced; /**< Number of stay of 1/10th seconds in visited cell */

    uint16_t hoCause;     /**< Reason of Handover */
    uint8_t reserved2[2]; /**< Rserved */
} visitedNrCellInfo_type;

typedef struct
{
    uint8_t usage;   /**< ENUM:: enumUsage_type */
    uint8_t ratType; /**< Visited cell's RAT type ENUM:: enumRAT_type */

    union
    {
        visitedNrCellInfo_type nrCell; /**< 5G RAN cell information */
        visitedOctetStringCellInfo_type eutraCell;
        visitedOctetStringCellInfo_type utraCell;
        visitedOctetStringCellInfo_type geranCell;
    } uRat; /**< Cell information for each RAT */
} visitedCellInfo_type;

#define MAX_VISITED_CELL 16  // TODO : check the number of value is 15, serving is updated at pendingUeHistoryEntry
//#define MAX_VISITED_CELL    MAX_VISITED_CELL_CSL

typedef enum
{
    e_ScgUeHistoryInformationControl_Both,
    e_ScgUeHistoryInformationControl_NRDCOnly,
    e_ScgUeHistoryInformationControl_NEDCOnly,
    e_ScgUeHistoryInformationControl_Max
} scgUeHistoryInformationControl_type;

typedef struct
{
    struct timespec startTime;                          /**< Connection time in serving cell */
    uint8_t lastIdx;                                    /**< Index of last visited cell */
    visitedCellInfo_type pendingUeHistoryEntry;         /** Ue history Entry for started but not finished HO */
    uint8_t numVisitedCell;                             /**< Number of stored visited cells records */
    visitedCellInfo_type visitedCell[MAX_VISITED_CELL]; /**< Visited Cells list */
    ppaRestrictInfo_type ppaRestrict;                 /**< FGR-MC1007 NR mobility restriction (ping-pong avoidance) */
} ueHistoryInfo_type;

/*
    SVR24B, Mobility For NR-DC, SCG UE History Information Handling
    Structure that contains information about the most recently visited PSCell by a UE
*/
typedef struct
{
    union
    {
        struct
        {
            // Indicates whether the PSCell information is in use or not
            uint16_t usage              :1;
            // The index of the PSCell information in the 'ueHistoryInfo_type' structure
            uint16_t visitedCellIndex   :5;
            // Indicates whether the 'pSCellID' field is valid or not
            uint16_t pSCellID_Present   :1;
            // Indicates whether the PSCell information is still pending storage or not
            uint16_t isPendingEntry     :1;

            // Indicates whether the RatType of 'pSCellID', this value is 'ci_nr' or 'ci_eutra' by NGRAN-CGI
            uint16_t ratType            :4;
        };
        uint16_t clearFlags;
    };

    // The time the UE stayed (0..40950) in the PSCell
    uint16_t timeStay;

    // The ID of the PSCell
    cgi_type pSCellID;

} VccbLastVisitedPSCellInformation_type;

/*
    SVR24B, Mobility For NR-DC, SCG UE History Information Handling
    This structure stores information about PSCells (Secondary Serving Cells) that a UE has visited.
    When a UE visits a PSCell, its information is stored in a circular queue managed by this structure.
*/
typedef struct
{
    // Represents the index of the last written element in the circular queue
    uint8_t lastIndex;

    // Stores the number of stored PSCell information, which is capped at MAX_PSCELL_HISTORY_PER_CALL
    uint8_t numOfLastVisitedPSCell;

    // Currently Only Use UPM.
    VccbLastVisitedPSCellInformation_type pendingEntry;

    // Stores the actual PSCell information
    VccbLastVisitedPSCellInformation_type lastVisitedPSCellList[MAX_PSCELL_HISTORY_PER_CALL];

    // Contains additional information used to manage the PSCell information,
    // depending on whether the node is an MN or an SN
    union
    {
        struct
        {
            // Indicates whether the Non-DC Time Stamp is in use or not
            uint8_t isNonDcStartTimeValid   :1;

            // the 'nonDcStartTime' field stores the start time
            struct timespec nonDcStartTime;

        } mn; // For MN (Condition : not IS_MRDC_SN())

        struct
        {
            // Indicates whether the PSCell Active Time Stamp is in use or not
            uint8_t isPScellStartTimeValid        :1;

            // Indicates whether the PSCell Active Time Stamp needs to be updated or not.
            uint8_t isPScellStartTimeUpdateNeeded :1;

            // Indicated whether the PSCell List to be cleared or not.
            uint8_t isPSCellListClearNeeded       :1;

            // the 'pScellStartTime' field stores the start time,
            struct timespec pScellStartTime;

            // the 'mnInfo' array stores information about each MN,
            struct
            {
                // Indicates whether the PSCell Change History IE has been received or not.
                uint8_t isPSCellChangeHistoryIE_Received                :1;
                // Indicates whether the PSCell History Information Retrieve IE has been received or not.
                uint8_t isPSCellHistoryInformationRetrieveIE_Received   :1;
                // the MN's activation state using the 'enumMNodeState_type' enumeration.
                uint8_t mnActivationState                               :1;

            } mnInfo[MAX_MN];

        } sn; // For SN (Condition : IS_MRDC_SN())
    } u;

} VccbLastVisitedPSCellHandling_type;

typedef struct
{
    uint32_t frequencies[MAX_NUM_MEAS_FREQS_MN];
    uint8_t numItems;
} measuredFrequencies_type;

typedef struct
{
    uint32_t ssbFrequency;
    uint8_t ssbSubcarrierSpacing;  // enumSubcarrierSpacing
    smtc1_type smtc1;
} ssbMeasTiming_type;

typedef struct
{
    uint8_t configInstalledFlag : 1;  // FLAG_ON/OFF
    uint8_t configNewFlag       : 1;  // FLAG_ON/OFF
    uint8_t forceReconfig       : 1;  // FLAG_ON/OFF
    uint8_t f1CtxModFlag        : 1;  // FLAG_ON/OFF
    uint32_t intraFreqServCellIdBitmask;
    uint32_t intraFreqGapIndBitmask;
    uint8_t noGapInterFreqInfoBitmap[(MAX_NUM_NR_BAND + 7) / 8];
    uint8_t bandFilterNew[(MAX_NUM_NR_BAND + 7) / 8];
    uint8_t bandFilterInstalled[(MAX_NUM_NR_BAND + 7) / 8];
} needForGapNrUeData_type;

typedef struct mGapCallConfiguration_s
{
    measuredFrequencies_type freqSnInstalled, freqSnNew;    // ENDC + NRDC-SN + MRDC-MN
    mGapCfgNode_type mGapCfgSn;         // MRDC-MN (confirmed by SN)

    uint8_t mGapMnCtrlState;        // enumMGapStateFlag_type, ENDC + NRDC-SN
    uint8_t mGapLocalCtrlState;     // enumMGapStateFlag_type, ENDC + SA
    uint8_t mGapCfgSnSentFlag : 1;  // VCCB_FLAG_ON/OFF, MRDC-MN (sent to SN and not yet confirmed)
    uint8_t procRxRefuseFlag  : 1;  // VCCB_FLAG_ON/OFF, ENDC + NRDC-SN (rx SN Modification Refuse during SN init
                                    // mgap change)
    uint8_t endcFr2OnlyFlag : 1;    // VCCB_FLAG_ON/OFF, ENDC only (set when only FR2 m-gap are being changed)

    uint8_t mgrpPreference;
    uint8_t mrPurposeInfo;
    moListMgap_type moDuInstalled;
} mGapCallConfiguration_type;

typedef struct
{
    uint8_t tgtCellMoId;              // 1..64, 0 - value not set
    Arfcn_type tgtCellMoSsb;            // UNKNOWN_ARFCN - value not set

    uint8_t svcGrpChangeProcedure;      // 0 : svcGrpId should be used, 1 : during meas config procedure, svcGrpNewId should be used.
    uint8_t svcGrpId;
    uint8_t svcGrpNewId;               // Also used outside measurement reconfiguration

    struct measurementObjects_type
    {
        measurementObjectUe_type installedItems[MAX_NR_OF_OBJECT_ID];
    } measurementObjects;

    struct
    {
        reportConfigurationInstalledUe_type installedItems[MAX_NR_OF_REPORT_CONFIG_ID];
    } reportConfigurations;

    struct
    {
        measurementIdentity_type installedItems[MAX_NR_OF_MEAS_ID];
    } measurementIdentities;

    struct
    {
        sMeasure_type installedItem;
    } sMeasureConfig;

    struct
    {
        quantityConfiguration_type installedItem;
    } quantityConfigurations;

    mGapCfgNode_type mGapCfgInstalled;  // ENDC + SA (confirmed by UE)
    uint8_t lpmPurposeMask;

} measurementsConfiguration_type;

typedef struct
{
    uint8_t ltmMeasNeeded;                          // TRUE/FALSE.
    uint8_t queuedMeasReconfigAction;               // MeasReconfigPriorAction_type
    uint8_t lpmRepetitionCount;
    mGapCallConfiguration_type mGapConfiguration;
    mGapDuData_type mGapDu;

    struct s_PeriodicMeasurement_type
    {
        uint8_t state;                  // enumPeriodicMeasState_type
        uint8_t needRestartTimerFlag;   // VCCB_FLAG_ON/OFF
        timerInfo_type timer;
    } pa4m, lpm;

    struct s_AlternateMeasGap_type
    {
        uint8_t stateWithinPa4m;        // enumAltGapStateWithinPa4m_type
        uint8_t stateWithoutPa4m;       // enumAltGapStateWithoutPa4m_type
        uint8_t prev_stateWithoutPa4m;  // enumAltGapStateWithoutPa4m_type
        timerInfo_type timer;
    } altgap;

} measurementsConfigShared_type;

typedef struct
{
    uint16_t tgtCellNum;
    uint8_t tgtCellNewMoIdx;          // 0..MAX_NR_OF_OBJECT_ID-1, MAX_NR_OF_OBJECT_ID - value not set
    uint8_t measConfigReadyFlag;      // ON/OFF
    uint8_t lateFreqPrioMeas;         // TRUE/FALSE
    uint8_t lateLbMeas;               // TRUE/FALSE
    uint8_t caAwareMeasNeeded;        // TRUE/FALSE

    struct measurementObjectsProcedure_type
    {
        measurementObjectUe_type newItems[MAX_NR_OF_OBJECT_ID];
        uint64_t itemsToModify;
        uint64_t itemsToRemove;
        uint64_t foreignIdsToRemove;
        uint64_t idsToRemove;
        uint8_t numNewItems;
    } measurementObjects;

    struct
    {
        reportConfigurationNewUe_type newItems[MAX_NR_OF_REPORT_CONFIG_ID];
        uint64_t itemsToModify;
        uint64_t itemsToRemove;
        uint64_t foreignIdsToRemove;
        uint64_t idsToRemove;
        uint8_t numNewItems;
    } reportConfigurations;

    struct
    {
        measurementIdentity_type newItems[MAX_NR_OF_MEAS_ID];
        uint64_t foreignIdsToRemove;
        uint64_t itemsToRemove; // items overlaps with ids
        uint8_t numNewItems;
    } measurementIdentities;

    struct
    {
        uint8_t status;
        sMeasure_type newItem;
    } sMeasureConfig;

    struct
    {
        uint8_t statusNR, statusEUTRA;
        quantityConfiguration_type newItem;
    } quantityConfigurations;

    uint8_t pa4mAggregatedPerMiCnt;
    uint8_t lpmPurposeMask;

} measurementsProcedure_type;

typedef struct
{
    uint32_t selectedBC;                // INTEGER (1..65536), 0 - not set
    uint16_t bandUsedForPCSelection;    // INTEGER (1..1024), 0 - not set
    uint8_t selectedFS;                 // INTEGER (1..128), 0 - not set
    uint8_t selectedPowerClass;         // enumUeAllPowerClass_type

} duSelectionRelatedData_type;

typedef enum
{
    // TODO: need to modify the name after design
    ltm_init = 0,
    ltm_selectAsTargetCell,
    ltm_DuIsOngoing,   // TODO: modify the name : target cell configuration with du
    ltm_DuIsDone,      // TODO: modify the name : target cell configuration with du using setup msg
    ltm_PropIsOnging,  // TODO: modify the name : target cell configuration with du
    ltm_PropIsDone,  // TODO: modify the name : target cell configuration with du for current spcell (for first time???)
    ltm_RrcIsOngoing,  // TODO: modify the name : target cell configuration with du for current spcell (for first
                       // time???)
    ltm_RrcIsDone,  // TODO: modify the name : target cell configuration with du for current spcell (for first time???)
    ltm_installed,  // TODO: modify the name : target cell configuration with du using modify msg
    ltm_selectAsExecCell,  // TODO: modify the name
    ltm_TBD2,              // TODO: modify the name
    ltm_TBD3,              // TODO: modify the name

} ltmCellAction_type;

typedef struct
{
    mGapDuData_type mGapDuData[MAX_NUM_LTM_CELLS];
    measurementsConfiguration_type measConf[MAX_NUM_LTM_CELLS];
    measurementsProcedure_type measProc[MAX_NUM_LTM_CELLS];
    ltmCaInfo_type ltmCaInfo[MAX_NUM_LTM_CELLS];
    saMeasStateInfo_type saMeas[MAX_NUM_LTM_CELLS];
    reportCgiInfo_type reportCgi[MAX_NUM_LTM_CELLS];
    UlGapFr2Config_type ulGapFr2ConfigDu[MAX_NUM_LTM_CELLS];
    uint8_t ulGapFR2PreferenceConfig[(MAX_NUM_LTM_CELLS+7)/8];
} LtmProcRelatedData_type;

typedef struct
{
    struct
    {
        uint8_t usage      : 1;
        uint8_t ltmCellIdx : 7;  // my index in ltmCellList.

        uint8_t ltmStatus;  // enumCommonStatus_type -> Common_Idle, Common_Setup, Common_Modify Common_Release
        uint8_t ltmAction;  // ltmCellAction_type

        // noe yet
        uint8_t statCause;  // S_Release determines the reason for execution. This is an operation for collecting
                            // statistics. enumChoStatType

        union
        {
            struct
            {
                // used
                uint8_t receivedDuUeId : 1;  // Usage of condCellInfo.crnti
                uint8_t setup : 1;  // when the ue context setup request is transmitted, set up the setup flag as a picture.
                uint8_t release_in_progress : 1;  // If it is a candidate cell that needs to be released now, set it to true.
                uint8_t release_pending : 1;    // This flag must be released from the set candidate cell.

                // not yet
                uint8_t rrc_activation_flag         : 1;  // Indicates whether the resource is setup in the UE.
                uint8_t to_relase_du                : 1;  // Skip F1 UE Context Release Command for reset-triggered candidate release.
                uint8_t collectableCandidateRelStat : 1;  // Manages whether CandidateRelStat is in the collectible state.
                uint8_t run_execution               : 1;  // Indicates that the CHO Execution procedure was performed.
            } flag;
            uint8_t flag_uValue;
        } ;

        struct
        {
            union
            {
                struct
                {
                    // used
                    uint8_t prepAttempt  : 1;
                    uint8_t exeAttempt   : 1;
                    uint8_t released     : 1;
                    uint8_t releaseCause : 5;
                } flag;
                uint8_t flag_uValue;
            };
        } stat;

        duHoInfo_type du;
        // timerInfo_type timer;                // LTM candidate msg Resp Timer
        timerInfo_type ltmCellReleaseTimer;  // LTM candidate release timer
    } handle;

    // ----------------------------------------------------------------
    // NON BACKUP PART
    // Objects below this line are not replicated in HAS
    // If you want to add more non-replicatable fields do it AFTER this line
    // ----------------------------------------------------------------
    struct
    {
        cellSelection_type cellSelection;  // cellNum and band

        cgi_type nrcgi;  // NRCGI of Target Cell
        uint16_t cellIdentity;

        pci_type pci;
        crnti_type crnti;  // Check sanity with flag.crntiUsage

        struct
        {
            int ssbArfcn;
            int scs;
            int periodicity;

        } ssb;

        struct
        {
            // from du
            struct
            {
                // TBD : drbId ??
                transportLayerInfo_type f1uDlInfo;
            } drb[MAX_DRB_PER_SA_CALL];

        } tnlAddr;

        struct
        {
            uint8_t usage    : 1;
            uint8_t ssbIndex : 7;
            // pMeasQuantityResults_type measQuantityResults;
        } ssbIndexes[MAX_BEAM_FOR_LTM];

        duSelectionRelatedData_type duSelectionRelatedData;

    } data;
} ltmCellInfo_type;

typedef struct
{
    /* Ltm Control Flag */
    struct
    {
        uint8_t switchOver : 1;
        uint8_t ltmDuReleaseSent : 1;
        uint8_t isRachLessLtm  : 1;
    } flag;

    union
    {
        struct
        {
            // TODO: need to modify below flag as e1 handler state...
            uint8_t e1StopIsRequired   : 1;
            uint8_t e1StopWaiting      : 1;
            uint8_t e1ResumeIsRequired : 1;

            uint8_t f1DuCuCellSwitchNotiReceived : 1;
            uint8_t f1AccessSuccessReceived      : 1;
            uint8_t rrcCompleteReceived          : 1;
        };  // These flags are valid only during cell switch execution
            // (from DU-CU Cell Switch Notification ~ F1 Mod Req w/ RRC Complete Ind)
        uint8_t clearFlag;
    } cellSwitchFlag;
    uint8_t currCandidateCellIdx; // For making message, valid only during message creation
    uint8_t respFlag;

    uint8_t svcGrpId;    // It is updated when ltm candidate cell addition, and then it can be updated after pdusession changed.
    cgi_type targetCgi;  // For LTM Handover Execution

    // [TBD] F1 DuCuCellSwitchNotification
    // struct timespec tXnHandoverSuccess;  // When XNHandoverSuccess is received

    // [TODO] New Up resource.. It's up to UP resource feature..
    // struct
    // {
    //     uint8_t usage;      // use, no_use
    //     uint8_t interface;  // f1, xn, e1, ..
    //     uint16_t endIdx;    // 0 ..
    //     uint64_t neId;      // identity of ne (xnGnbIdx, duId, ...)
    //     uint64_t ueId;      // identity in ne (xnUeId, duUeId, ...)
    // } endPointInfo[1];

    /* Range : 0(OFF) ~ 8(MAX_NUM_LTM_CELLS), Detail : Number of Cond Cell Lists */
    uint8_t numOfCellList;
    ltmCellInfo_type cellList[MAX_NUM_LTM_CELLS];
    duHoInfo_type releasedDu[MAX_NUM_LTM_CELLS_EXCL_PCELL];

    // temp DB for unpack (need to remove...)
#if F_StandardConformance_AsnF1AP >= 180200
    struct
    {
        F1_EarlySyncInformation *pEarlySyncInformation;
        F1_LTMConfiguration *pLtmConfiguration;

        // F1_DUCUCellSwitchNotification
        F1_LTMCellSwitchInformation *pLTMCellSwitchInformation;
        F1_TAInformation_List *pTAInformation_List;

    } receivedF1Buffer;
#endif

    LtmProcRelatedData_type *ptProcRelatedData;
} ltmUeInfo_type;

typedef struct
{
    uint8_t usage; /**< ENUM:: enumUsage_type */
    uint16_t failureCause;
    cslScgFailureBeamMeas_type pCellBeamMeas;
    cslScgFailureBeamMeas_type sCellBeamMeas[MAX_NUM_SCELL_CSL];
    vccbTimeInfo_type failureTime;
    uint8_t suspendTimeState;
    uint8_t recoveryTimeFlag;
    vccbTimeInfo_type suspendTime;
    vccbTimeInfo_type recoveryTime;
} cslScgFailure_type;

typedef struct
{
    uint16_t lastIdx;
    uint16_t failureCount;
    cslScgFailure_type scgFailure[MAX_SCG_FAILURE_COUNT];
} scgFailureHistoryInfo_type;

typedef struct
{
    uint8_t receivedFlag;
    uint8_t pCellPresentFlag;
    vccbTimeInfo_type receivedTime;
    uint16_t reportType;
    uint8_t reportPurpose;
    uint16_t pci;  // Serving PCI of Last MR
    uint16_t rsrpServingCell;
    uint16_t rsrqServingCell;

    uint16_t numOfServBeam;
    cslBeamMeas_type servBeamMeas[MAX_BEAM_FOR_CSL];

    uint16_t numNeighborCell;
    cslCuCpAdjacentInfo_type adjacentInfo[MAX_NBR_CELL_CSL];
} cslMeasInfo_type;

typedef struct
{
    uint64_t sourceCellId;
    uint64_t holdingDuration;
    uint64_t totalHoldingDuration;
    uint16_t rreCount;
    uint16_t targetCellId;
    uint16_t pci;
    uint16_t rlfCause; // default : 0xFFFF, range:0~6
    uint8_t rrePendingFlag:1;
    uint8_t ueCtxtFetchResult:1;
    uint8_t fiveQiExistFlag:1;
    uint8_t reserved:5;
    uint8_t interFreqFlag;
    gnbId_type sourceGnbId;
    gnbId_type targetGnbId;
    cgi_type targetCgi;
    cgi_type sourceCgi;
    enumCslRreCase_type rreCase;
    enumCslRreResult_type result;
    struct timespec startTime;

    //New in SVR26A start
    uint8_t vonrRreFailCause;         // Init: 0xFF, Range: 0~28
    //New in SVR26A end
} cslRreInfo_type;

/* candidateCellListForSort is used temporary during processing. not a stored information. */
typedef struct
{
    uint16_t physCellId;
    uint16_t cellNum;
    uint16_t bandNr;
    uint8_t priority;  // VccbCellInfo_type > priority.
    uint8_t rsrpFlag;
    uint16_t rsrp;
    uint8_t rsrqFlag;
    uint8_t selectedCellPlmnIndex;  // Used only in NRDC SN
    uint16_t rsrq;
    uint32_t ueCount;  // VccbCellInfo_type > cfg > assignedCellCallCount
    uint8_t nrcgiCell;
} candidateCellForSort_type;

typedef struct
{
    uint8_t nrofCells;
    candidateCellForSort_type candidateCell[MAX_NUM_CANDIDATE_CELL_FOR_PSCELL];
} candidateCellListForSort_type;

// NRRRC__choice27
typedef struct
{
    uint8_t subMilliSeconds;
    uint8_t milliSeconds;  // NRRRC__enum79
} onDurationTime_type;

typedef struct
{

    uint8_t drxLongCycleStartOffsetType;  // choice28
    uint16_t drxLongCycleStartOffset;

    //In 23B PKG, following values are not used yet.
    onDurationTime_type drxOnDurationTimer;
    uint8_t drxInactivityTimer;  // NRRRC__enum81
    uint8_t drxHarqRttTimerDL;
    uint8_t drxHarqRttTimerUL;
    uint8_t drxRetransmissionTimerDL;  // NRRRC__enum82
    uint8_t drxRetransmissionTimerUL;  // NRRRC__enum82
    uint8_t shortDrxFlag;
    uint8_t drxShortCycle;  // NRRRC__enum80
    uint8_t drxShortCycleTimer;
    uint8_t drxSlotOffset;
} drxConfig_type;

typedef union
{
    uint16_t longCycleStartOffset;
    drxConfig_type drxConfig;
} VccbDrxConfigStoreData_type;

typedef enum
{
    VCCB_LONG_CYCLE_START_OFFSET = 0,
    VCCB_DRX_CONFIG_INFO
} enumDrxConfigStore_type;

typedef struct
{
    uint8_t isPresent;
    enumDrxConfigStore_type storeType;
    VccbDrxConfigStoreData_type storeData;
} VccbDrxConfigInfo_type;

typedef struct
{
    drxState_t status;
    enumSrsConfigTriggered_type srsConfigTriggeredType;
    uint8_t longCycle;  // NRRRC_drx_LongCycleStartOffset_ms10_chosen ..
    uint8_t shortCycle;
    drxState_t shortCycleStatus;
    uint8_t shortCycleTimer;

    uint8_t drxReleaseFlag;
    VccbDrxConfigInfo_type drxConfigInfo;
    VccbDrxConfigInfo_type backupDrxConfigInfo;
} cuCallDrxConfig_type;

typedef struct
{
    struct timespec X2_SgNBAdditionRequest;  // SgNBAdditionRequest
    struct timespec E1_BearerContextSetupRequest;
    struct timespec F1_UEContextSetupRequest;
    struct timespec E1_BearerContextModificationRequest;
    struct timespec F1_InitialULRRCMessageTransfer;  // NR Attach
    struct timespec NG_HandoverRequest;
    struct timespec XN_HandoverRequest;
    struct timespec XN_HandoverRequestAcknowledge;
    struct timespec XN_HandoverPreparationFailure;
    struct timespec XN_HandoverCancel;
    struct timespec XN_UEContextRelease;
} timeStampInfo_type;

typedef enum
{
    ci_integ_protect_required = 0,
    ci_integ_protect_preferred = 1,
    ci_integ_protect_not_needed = 2
} enumIntegProtectInd_type;

typedef enum
{
    ci_confiden_protect_required = 0,
    ci_confiden_protect_preferred = 1,
    ci_confiden_protect_not_needed = 2
} enumConfidenProtectInd_type;

typedef enum
{
    ci_integ_protect_performed = 0,
    ci_integ_protect_not_performed = 1
} enumIntegProtectResult_type;

typedef enum
{
    ci_confiden_protect_performed = 0,
    ci_confiden_protect_not_performed = 1
} enumConfidenProtectResult_type;

typedef enum
{
    ci_max_ip_rate_bitrate64kbs = 0,
    ci_max_ip_rate_max_ue_rate = 1,
} enumMaxIPrate_type;

typedef struct
{
    uint8_t integProtectInd;           /**< enumIntegProtectInd_type */
    uint8_t confidenProtectInd;        /**< enumConfidenProtectInd_type */
    uint8_t maxIPrate;                 /**< enumMaxIPrate_type */
    uint8_t maxIPrateDL;               /**< enumMaxIPrate_type */
    uint8_t securityInfoNotAvailable;  // Locally decided for UP DRB Integrity Protection Feature
    uint8_t maxIPrateDLPresent;
} securityIndication_type;

typedef struct
{
    uint8_t integrityProtectionResult;       /**< enumIntegProtectResult_type */
    uint8_t confidentialityProtectionResult; /**< enumConfidenProtectResult_type */
} securityResult_type;

typedef struct
{
    uint8_t perScalar;
    uint8_t perExponent;
} packetErrorRate_type;

typedef struct
{
    uint8_t fiveQi;

    uint8_t priorityLevelQosPresent            : 1;
    uint8_t averagingWindowPresent             : 1;
    uint8_t maximumDataBurstVolumePresent      : 1;
    uint8_t cnPacketDelayBudgetDownlinkPresent : 1;
    uint8_t cnPacketDelayBudgetUplinkPresent   : 1;
    uint8_t reserved1                          : 3;

    uint16_t priorityLevelQos;        // 1..127, ...
    uint16_t averagingWindow;         // 0..4096, ...
    uint16_t maximumDataBurstVolume;  // 0..4096, ...
    uint16_t cnPacketDelayBudgetDownlink;
    uint16_t cnPacketDelayBudgetUplink;
} nonDynamic5QIDesc_type;

typedef enum
{
    ci_delay_critical = 0,
    ci_non_delay_critical = 1,
} enumDelayCritical_type;

typedef struct
{
    uint8_t priorityLevel;
    uint16_t packetDelayBudget;
    packetErrorRate_type packetErrorRate;
    uint8_t delayCritical;     /**< enumDelayCritical_type */
    uint16_t averagingWindow;  // INTEGER (0..4095, ...)
} dynamic5QIDesc_type;

typedef struct
{
    uint8_t priorityLevel;
    uint8_t preemptionCapability;    /**< enumPreemptionCapability_type */
    uint8_t preemptionVulnerability; /**< enumPreemptionVulnerability_type */
} allocAndRetentPriority_type;

typedef enum
{
    ci_fc_trigger,
    ci_fc_du_init_trigger,
    ci_fc_sn_init_trigger,
    ci_fc_drb_remapping,
    ci_fc_drb_disable_datafwd,
    ci_fc_drb_reuse,

} enumFullConfigurationTag_type;

typedef struct
{
#define VCCB_FULL_CONFIG_ACTION         0x0000
#define VCCB_FULL_CONFIG_ACTION_DU_INIT 0x0001
#define VCCB_FULL_CONFIG_ACTION_SN_INIT 0x0002

    uint32_t action;            // use the bitmap. Need to update the meaning of BIT
    uint32_t drbId_disableFwd;  // use the bitmap. Bit#0 (drbId 1) .. Bit#31 (drbId 32)

    struct
    {
        // NRRRC_RRCReconfiguration_v1610 START ---
        // otherConfig_v1610 START
        uint32_t idc_AssistanceConfig_r16 : 1;
        uint32_t drx_PreferenceConfig_r16 : 1;
        // uint32_t maxBW_PreferenceConfig_r16:1;    // Remvoed by FGR-CC0104
        // uint32_t maxCC_PreferenceConfig_r16:1;    // Remvoed by FGR-CC0104
        // uint32_t maxMIMO_LayerPreferenceConfig_r16       : 1; // Remvoed by FGR-CC0104
        uint32_t minSchedulingOffsetPreferenceConfig_r16 : 1;
        // uint32_t releasePreferenceConfig_r16:1;   // From 22A
        // referenceTimePreferenceReporting_r16 (Need R)
        uint32_t btNameList_r16     : 1;
        uint32_t wlanNameList_r16   : 1;
        uint32_t sensorNameList_r16 : 1;
        uint32_t obtainCommonLocation_r16 :1; // (Need R)
        // sl_AssistanceConfigNR_r16 (Need R)
        // otherConfig_v1610 END

        // bap_Config_r16
        uint32_t bap_Config_r16 : 1;
        // iab_IP_AddressConfigurationList_r16
        // uint32_t iab_IP_AddressConfigurationList_r16:1; // how release it..
        // conditionalReconfiguration_r16
        // uint32_t conditionalReconfiguration_r16:1;  // how release it..
        // daps_SourceRelease_r16 (Need N)
        // t316_r16
        uint32_t t316_r16 : 1;
        // RRCReconfiguration_v1610_IEs_needForGapsConfigNR_r16 (from 21C)
        // onDemandSIB_Request_r16
        uint32_t onDemandSIB_Request_r16 : 1;
        // dedicatedPosSysInfoDelivery_r16 (Need N)
        // sl_ConfigDedicatedNR_r16
        uint32_t sl_ConfigDedicatedNR_r16 : 1;
        // sl_ConfigDedicatedEUTRA_Info_r16
        uint32_t sl_ConfigDedicatedEUTRA_Info_r16 : 1;
        // targetCellSMTC_SCG_r16 (Need S)
        //  NRRRC_RRCReconfiguration_v1610 END -----

        // NRRRC_RRCReconfiguration_v1700 START --- (23B)
        // otherConfig_v1700 START
        // ul_GapFR2_PreferenceConfig_r17;               // Need R
        uint32_t musim_GapAssistanceConfig_r17   : 1;    // Need M
        uint32_t musim_LeaveAssistanceConfig_r17 : 1;    // Need M
        uint32_t successHO_Config_r17            : 1;    // Need M
        // maxBW_PreferenceConfigFR2_2_r17;              // Cond maxBw
        // maxMIMO_LayerPreferenceConfigFR2_2_r17;       // Cond maxMIOMO
        // minSchedulingOffsetPreferenceConfigExt_r17;   // Cond minOffset
        uint32_t rlm_RelaxationReportingConfig_r17  : 1; // Need M
        uint32_t bfd_RelaxationReportingConfig_r17  : 1; // Need M
        // scg_DeactivationPreferenceConfig_r17;         // cond SCG
        uint32_t rrm_MeasRelaxationReportingConfig_r17 : 1;  // Need M
        uint32_t propDelayDiffReportConfig_r17         : 1;  // Need M
        // otherConfig_v1700 END

        uint32_t sl_L2RelayUE_Config_r17  : 1;        // Need M
        uint32_t sl_L2RemoteUE_Config_r17 : 1;        // Need M
        //    dedicatedPagingDelivery-r17             // Cond PagingRelay
        uint32_t needForGapNCSG_ConfigNR_r17    : 1;  // Need M
        uint32_t needForGapNCSG_ConfigEUTRA_r17 : 1;  // Need M
        //    scg-State-r17                           // Need N
        uint32_t musim_GapConfig_r17  : 1;            // Need M
        //    appLayerMeasConfig-r17                  // Need M (TBD: how release it)
        //    ue-TxTEG-RequestUL-TDOA-Config-r17      // Need M
        uint32_t ueTxTEG_RequestUL_TDOA_Config_r17 : 1;
        //    nonCriticalExtension
        //  NRRRC_RRCReconfiguration_v1700 END -----

#if F_StandardConformance_AsnNRRRC >= 180200
        // NRRRC_RRCReconfiguration_v1800 START --- (25A)
        // otherConfig_v1800 START
        uint32_t idc_AssistanceConfig_v1800 : 1;                // Need M
        uint32_t multiRx_PreferenceReportingConfigFR2_r18 : 1;  // Need M
        // aerial-FlightPathAvailabilityConfig-r18              // Need R
        uint32_t ul_TrafficInfoReportingConfig_r18 : 1;         // Need M
        // n3c-RelayUE-InfoReportConfig-r18                     // Need R
        uint32_t successPSCell_Config_r18 : 1;                  // Need M
        // sn-InitiatedPSCellChange-r18                         // Need R
        // musim-GapPriorityAssistanceConfig-r18                // Cond musimGapConfig (if musim-GapAssistanceConfig-r17 is configured)
        uint32_t musim_CapabilityRestrictionConfig_r18 : 1;     // Need M
        // otherConfig_v1800 END

        uint32_t needForInterruptionConfigNR_r18 : 1;              // Need M
        uint32_t aerial_Config_r18 : 1;                            // Need M
        uint32_t sl_IndirectPathAddChange_r18 : 1;                 // Need M
        uint32_t n3c_IndirectPathAddChange_r18 : 1;                // Need M
        uint32_t n3c_IndirectPathConfigRelay_r18 : 1;              // Need M
        uint32_t srs_PosResourceSetAggBW_CombinationList_r18 : 1;  // Need M
        uint32_t ltm_Config_r18 : 1;                               // Need M
        // nonCriticalExtension
        // NRRRC_RRCReconfiguration_v1800 END -----

#if F_StandardConformance_AsnNRRRC >= 183000
        // NRRRC_RRCReconfiguration_v1830 START ---
        // otherConfig_v1830 START
        // sl-PRS-AssistanceConfigNR-r18                             Need R
        uint32_t sl_PRS_AssistanceConfigNR_r18 : 1;                 // Need R
        // otherConfig_v1830 END
        // nonCriticalExtension SEQUENCE {} (empty)
        // NRRRC_RRCReconfiguration_v1830 END -----
#endif
#endif
    } interwork;

} fullConfiguration_type;

typedef struct
{
    uint8_t notificationControlPresent     : 1;
    uint8_t maximumPacketLossRateDLPresent : 1;
    uint8_t maximumPacketLossRateULPresent : 1;
    uint8_t reserved1                      : 5;

    uint8_t notificationControl;

    int64_t maximumFlowBitRateDL;
    int64_t maximumFlowBitRateUL;
    int64_t guaranteedFlowBitRateDL;
    int64_t guaranteedFlowBitRateUL;
    int64_t prevGuaranteedFlowBitRateDL;
    int64_t prevGuaranteedFlowBitRateUL;

    int64_t maximumPacketLossRateDL;
    int64_t maximumPacketLossRateUL;
} gbrQosInformation_type;

typedef enum
{
    ci_qos_char_non_dynamic_5qi = 1,
    ci_qos_char_dynamic_5qi = 2
} enumQosCharacteristics_type;

typedef enum
{
    subject_to_reflective_QoS = 0
} reflectiveQosAttribute_type;

typedef struct
{
    uint8_t qosCharacteristics;  // CHOICE QoS Characteristics //enumQosCharacteristics_type

    uint8_t gbrQosInformationPresent      : 1;
    uint8_t reflectiveQosAttributePresent : 1;
    uint8_t additionalQoSflowInfoPresent  : 1;
    uint8_t qosMonitoringRequestPresent   : 1;
    uint8_t reserved1                     : 4;

    enumQosMonitoringRequest_type qosMonitoringRequest;

    union
    {
        nonDynamic5QIDesc_type nonDyna;  // Non Dynamic 5QI Descriptor
        dynamic5QIDesc_type dynamic;     // Dynamic 5QI Descriptor
    };
    allocAndRetentPriority_type allocAndRetent;  // NG-RAN Allocation and Retention Priority
    gbrQosInformation_type gbrQosInfo;
    reflectiveQosAttribute_type reflectiveQosAttribute;
} qosFlowLevelQoSParam_type;

typedef enum
{
    e_ReleaseTriggerForFindAllCause = -1, /* This value is used for searching all causes regardless of the reason. */
    e_ReleaseTriggerNotRelease = 0,       /* Init Value */
    e_ReleaseTriggerByAmf,                /* Received Release List in PDU Session Modify/Release Command */
    e_ReleaseTriggerByPathSwitch,         /* Received Unsussful List in Path Switch Request Ack */
    e_ReleaseTriggerBySliceNotSupport,    /* Slice Not Support by Gnb (HO: Intra-Gnb, RRE: TODO)  */
    e_ReleaseTriggerByPreemption,         /* Received F1 Modification Required to Delete DRB */
    e_ReleaseTriggerByRanResetFromVnmb,   /* Received Reset by RAN (VNMB) 23A_NRRetainability */
    e_ReleaseTriggerByLinkFailureFromVnmb,/* Received Reset by LinkFailure (VNMB) // 23A_NRRetainability */
    e_ReleaseTriggerByUpFailureInMultiUP, /* In multi-up scenario one of serving UP is releasead/failed */
    e_ReleaseTriggerByDrbPartial,         /* DRB Partial during Handover */
    e_MaxOfReleaseTrigger
} releaseTrigger_type;

typedef struct
{
    uint16_t releaseCause;  // This value is equal to the CRR range.
    uint8_t triggerEvent;   // This value applies the reason for the release to occur. (ENUM:: releaseTrigger_type )
    uint8_t reserved;
} releaseInfo_type;

// DRB units stat types
typedef enum
{
    DRB_SETUP = 0,
    DRB_RELEASE_AND_ERASE = 1,
    NEDC_DRB_SETUP = 2,
    NEDC_DRB_MOD = 3,
    DRB_SETUP_PLMN_SNSSAI = 4,
    DRB_SETUP_IN_PDUSESSION_MODIFY = 5,
    INITIAL_DRB_SETUP = 6,
    INITIAL_DRB_SETUP_PLMN_SNSSAI = 7,
    DRB_SETUP_GLOBAL_ID_RFSP = 8,
    DRB_SETUP_PLMN_SNSSAI_5QI = 9,
    MAX_VCCB_DRB_STAT_FAMILY_TYPE = 10
} enumDRBstat_type;

// PDU units stat types
typedef enum
{
    PDU_SESSION_RESOURCE_SETUP_PLMN_SNSSAI = 0,
    PDU_SESSION_RESOURCE_MODIFY_PLMN_SNSSAI_RFSP = 1,
    PDU_SESSION_RESOURCE_SETUP_PLMN_SNSSAI_RFSP = 2,
    MAX_VCCB_PDU_STAT_FAMILY_TYPE = 3
} enumPDUstat_type;

// QosFlow units stat types
typedef enum
{
    QOS_FLOW_SETUP = 0,
    QOS_FLOW_SETUP_PLMN_SNSSAI = 1,
    QOS_FLOW_MODIFY_SERVICE_TYPE = 2,
    MAX_VCCB_QOS_FLOW_STAT_FAMILY_TYPE = 3
} enumQosFlowstat_type;

typedef struct
{
    uint8_t capableFlag : 1;        // On/Off :
                                    //     - Call:  (Basic   ) After sending InitialSetupResponse, set it ON.
                                    //              (H/O, RRE) After xxxxx, set it ON.
                                    //     - DRB :  (Basic   ) After Setup Procedure has done, set it ON.
    uint8_t inSessionFlagByE1 : 1;  // On/Off :
    uint8_t reserved          : 6;  // Reserved.
    uint8_t savedEventCategory;     // ENUM: enumCallDrb_RetainEventCategory_type
    uint16_t savedEventItem;        // ENUM: enumCallDrb_RetainEventItem_type

    uint8_t abnRelCause5qi;         // ENUM: enumAbnormalRelCause5qiCslType_type : SVR26A
    uint8_t reserved_1[3];
} retainStatInfo_type;

typedef struct
{
    uint8_t toBeReleased : 1;  // On/Off
    uint8_t toBeModified : 1;  // On/Off
    uint8_t reserved     : 6;
    uint16_t cause;
} preemptionInfo_type;

typedef struct
{
    uint16_t ecnMarkingState         : 3; // NOT_RECEIVED(0), RECEIVED(1), INVALID(2), VALID(3), SENT_TO_UP(4), SENT_TO_AMF(5).
                                          // Default value NOT_RECEIVED(0).
                                          // NOT_RECEIVED(0) - there was no data received from AMF or neighbor.
                                          // RECEIVED(1) - Valid ECN Marking received from AMF or Neighbor,
                                          // INVALID(2) - (Invalid ECN MARKING received from AMF or Neighbor -
                                          //               for example choice not filled to "NGAP_eCNMarkingAtRANRequest_chosen") or
                                          //              (not supported conditions, for example not supported bearers)
                                          // VALID(3) - (ECN Marking went through conditions verification. It's valid to be sent to UP)
                                          // SENT_TO_UP(4) - ECN Marking Request has been sent to UP.
                                          // SENT_TO_AMF(5) - ECN Marking Status has been sent to AMF
    uint16_t ecnMarkingChoice        : 2; // ECN_CHOICE_NONE(0), ECN_CHOICE_RAN(1), ECN_CHOICE_UPF(2), ECN_CHOICE_CONGESTION_INFORMATION(3)
    uint16_t ecnMarking              : 3; // UL, DL, Both, Stop
    uint16_t ecnMarkingStatusPresent : 2; // ECN_STATUS_NOT_RECEIVED(0), ECN_STATUS_RECEIVED(1), ECN_STATUS_MISSING(2). Default value ECN_STATUS_NOT_RECEIVED(0)
    uint16_t ecnMarkingStatus        : 1; // Active(0)/NotActive(1).
    uint16_t reserved                : 5;
} ecn_type;

typedef struct
{
    ecn_type ecn;
} qosFlowInfoExtension_type;

typedef struct
{
    uint8_t fiveQi;       // qosParam.nonDyna.fiveQi
    uint8_t arp;          // qosParam.allocAndRetent.priorityLevel
} savedQosFlowLevelQoSParam_type;

typedef struct
{
    uint8_t usage;
    uint8_t flowId;  // QoS Flow Identifier INTEGER (0 ..63)
    uint8_t prevQosFlowStatus;  // enumSABearerStatus_type
    uint8_t qosFlowStatus;      // enumSABearerStatus_type
    uint8_t firstReqStatusInThisProcedure;  // enumSABearerStatus_type

    uint8_t qosFlowSetupRequestItemeRABIDPresent : 1; // 0:not present, 1:present
    uint8_t isSDAPatSN                           : 1;
    uint8_t needToReconfigE1ByF1Fail             : 1; // Set TRUE when Status is changed to Fail by F1 so need to reconfig E1 Modification in DRB Partial.
                                                      // (S_Setup -> S_FailToSetup),  (Modify -> S_FailToModify)
    uint8_t needToResponseToAmf                  : 1; // Set TRUE when AMF request setup/modify of QosFlow. (Exclude Release)
    uint8_t rxNotSupportSlice                    : 1; // SVR25B FGR-CC3101. 5Set TRUE when Rx E/F1 Fail with slice fail cause or when VCCB not support Slice.
    uint8_t isSavedRequestedQosParam             : 1;  // It's set When QosParam is changed and saved requested val in PDUSessionResourceModifyRequest
    uint8_t isLteFallbackTriggered               : 1;  // SVR26B FGR-SV0201. Set TRUE when EPS/Emergency(gNB Initiated) Fallback set for IRAT Redirection or H/O.

    QosFlowDataFwdInfo_type dataFwdInfo;

    uint16_t drbIdxInCall;

    uint16_t failCause;  // root cause as a failure in processing.

    struct qosFlowStatInfo_s
    {
        // Each stats has two family types:Setup/Rel, and each state should be counted only once.
        uint8_t attemptFlag[MAX_VCCB_QOS_FLOW_STAT_FAMILY_TYPE];
    } qosFlowStatistic;

    preemptionInfo_type markedToBeReleasedQosFlow;  // Release Request Info by DRB Preemption.

    releaseInfo_type releaseInfo;

    retainStatInfo_type retainStat;  // Currently Only use capableFlag(23A)

    enumQosFlowMappingIndication_type qosFlowMappingIndication;

    long erabId;  // -1 is not used value. 0 ~ 15 : erabId range

    mrdcFlag_type mrdcFlag;  // for NRDC

    transportLayerInfo_type dataFwdErabInfo;

    qosFlowLevelQoSParam_type qosParam;

    qosFlowInfoExtension_type qosFlowInfoExtension;

    savedQosFlowLevelQoSParam_type requestedQosParam;   // It's valid only when isSavedRequestedQosParam is ON. It's not rollbacked when ModifyFail.
} qosFlowInfo_type;

typedef struct
{
    uint8_t usage;
    uint8_t dRBId;  // 1...32
    uint8_t pduIdxInCall;
    uint8_t numQoSFlowPerDRB;
    uint8_t cslAllocOrder;                        // For DRB/PDU-related information sorting

    uint8_t prevDrbStatus;                  // enumSABearerStatus_type
    uint8_t drbStatus;                      // enumSABearerStatus_type
    uint8_t firstReqStatusInThisProcedure;  // enumSABearerStatus_type
    uint8_t activityStatus;
    uint8_t needToReconfigE1ByF1Fail    : 1;    // Set TRUE when Status is changed to Fail by F1 so need to reconfig E1 Modification in DRB Rollback.
                                                // (S_Setup -> S_FailToSetup),  (Modify -> S_FailToModify)
    uint8_t rxNotSupportSlice           : 1;    // SVR25B FGR-CC3101. Set TRUE when Rx E1/F1 Fail with slice fail cause or when VCCB not support Slice.
    uint8_t rxDuNotSupportVoNr5qi       : 1;    // SVR26A FGR-CC3101. Set TRUE when Rx F1 Fail with specific cause (CauseF1apRadioNotSupportedQCI)
    uint8_t isLteFallbackTriggered      : 1;    // SVR26B FGR-SV0201. Set TRUE when EPS/Emergency(gNB Initiated) Fallback set for IRAT Redirection or H/O.

    union
    {
        struct{
            uint8_t needToSendTxStopByF1Partial_intraGnbOnlyUsed:1;  // Set to TRUE when it's in DBB Failed to be Setup/Modified List. Set to FALSE on sending E1_BearerContextModificationRequest(TX stop for Failed DRB). Used for Intra-gNB HO
            uint8_t needToReleaseAmfByF1Partial_intraGnbOnlyUsed:1;  // Set to TRUE when it's in DBB Failed to be Setup/Modified List. Set to FALSE on sending NG_PDUSessionResourceNotify. Used for Intra-gNB HO
            uint8_t alreadyReleasedByF1Partial_intraGnbOnlyUsed:1;   // Set to TRUE when on sending NG_PDUSessionResourceNotify. Set to FALSE when DRB usage is changed from no_use to use. Used for Intra-gNB HO
            uint8_t needToReconfigE1BySnFail:1;                      // Set to TRUE when SN partial detected. Set to FALSE on sending E1_BearerContextModificationRequest(Remove failed DRB). Used for NR-DC HO
            uint8_t reserved:4;
        };
        uint8_t partialFlag;
    };

    uint8_t drbReflectiveQosFlag;
    uint8_t mappingType;       // enumQosFlowDrbMapping_type
    uint8_t xnModReqUlPdcpConfigChangeFlag;
    uint8_t rlcStatus;
    uint8_t dlTrafficAboveThldFlag;  // VCCB_FLAG_OFF, VCCB_FLAG_ON. Says if UP reported DL traffic above configured
                                     // threshold.

    uint16_t qosFlowIndex[MAX_QOS_FLOW_PER_DRB];  // 0..63(MAX_QOS_FLOW_PER_CALL-1), init:0xFFFF
    uint16_t failCause;
    uint16_t drbQosIdxInCall;  // DRB QoS(one representative QoS flow of DRB) index in call
    uint16_t preemptionReqCellNum;

    rbPdcpSdapConfig_type rbInfo;

    drbCauseInfo_type cause;  // modify the name for memory (old name is causeInfo_type)
    retainStatInfo_type retainStat;
    retainStatInfo_type retainStatForAmfReq;

    transportLayerInfo_type f1uDlInfo;
    transportLayerInfo_type f1uUlInfo;
    drbDataFwdInfo_type dataFwdInfo;
    dataUsageInfo_type dataUsage[MAX_DATA_USAGE_REPORT_NUM]; /**< Store data usage reports */

    struct drbConnStat_s
    {
        // Flag for DRB CONN(RrcConn, RrcInact, RrcConnInact)
        uint8_t drbCountFlagOfRrcConn            : 1;  // for DRB Count in RRC Conn
        uint8_t drbCountFlagOfRrcInact           : 1;  // for DRB Count in RRC Inactive

        // RoHC drb count flag for RRC CONN/INACTIVE
        uint8_t UlRoHCdrbCountFlagRrcConn        : 1;  // for UL RoHC DRB Count in RRC Conn
        uint8_t UlRoHCdrbCountFlagRrcInact       : 1;  // for UL RoHC DRB Count in RRC Inact
        uint8_t SymmRoHCdrbCountFlagRrcConn      : 1;  // for Symmetric RoHC DRB Count in RRC Conn
        uint8_t SymmRoHCdrbCountFlagRrcInact     : 1;  // for Symmetric RoHC DRB Count in RRC Inact
        uint8_t drbCountFlagOfRedCapRrcConn      : 1;  // for DRB Count in RRC Conn of RedCap UE
        uint8_t drbCountFlagOfRedCapRrcInact     : 1;  // for DRB Count in RRC Inact of RedCap UE

        // EHC drb count flag for RRC CONN/INACTIVE
        uint8_t EHCdrbCountFlagRrcConn           : 1;  // for EHC DRB Count in RRC Conn
        uint8_t EHCdrbCountFlagRrcInact          : 1;  // for EHC DRB Count in RRC Inact

        // Index(CellNum, 5QI, PLMN) for DRB CONN(RrcConn, RrcInact)
        uint16_t
            markedCellNumForDrbConnStatOfRrcConn;       // cellNum which is previously counted for DRB_CONN 5Qi Statistics
        uint8_t marked5qiForDrbConnStatOfRrcConn;       // 5Qi value which is previously counted for DRB_CONN 5Qi Statistics
        uint8_t markedPlmnIdxForDrbConnStatOfRrcConn;   // Plmn Index value which is previously counted for DRB_CONN 5Qi
        uint8_t markedSliceIdxForDrbConnStatOfRrcConn;  // Slice Index value which is previously counted for DRB_CONN (PLMN+Slice:26A)

        uint8_t marked5qiForDrbConnStatOfRrcInact;      // 5Qi value which is previously counted for DRB_CONN 5Qi Statistics
        uint8_t markedPlmnIdxForDrbConnStatOfRrcInact;  // Plmn Index value which is previously counted for DRB_CONN 5Qi
        uint8_t markedSliceIdxForDrbConnStatOfRrcInact; // Slice Index value which is previously counted for DRB_CONN (PLMN+Slice:26A)
        uint16_t
            markedCellNumForDrbConnStatOfRrcInact;      // cellNum which is previously counted for DRB_CONN 5Qi Statistics

        uint16_t markedCellNumForUlRoHCDrbRrcConnStat; // cellNum which is previously counted for UL RoHC DRB_CONN Statistics
        uint16_t markedCellNumForSymmRoHCDrbRrcConnStat; // cellNum which is previously counted for Symmetric RoHC DRB_CONN Statistics
        uint8_t marked5qiForUlRoHCDrbRrcConnStat;      // 5Qi value which is previously counted for UL RoHC DRB_CONN 5Qi Statistics
        uint8_t marked5qiForSymmRoHCDrbRrcConnStat;      // 5Qi value which is previously counted for Symmetric RoHC DRB_CONN 5Qi Statistics
        uint8_t marked5qiForEHCDrbRrcConnStat;      // 5Qi value which is previously counted for EHC DRB_CONN 5Qi Statistics
        uint16_t markedCellNumForEHCDrbRrcConnStat; // cellNum which is previously counted for EHC DRB_CONN Statistics

        uint16_t markedCellNumForUlRoHCDrbRrcInactStat; // cellNum which is previously counted for UL RoHC DRB_CONN Statistics
        uint16_t markedCellNumForSymmRoHCDrbRrcInactStat; // cellNum which is previously counted for Symmetric RoHC DRB_CONN Statistics
        uint8_t marked5qiForUlRoHCDrbRrcInactStat;      // 5Qi value which is previously counted for UL RoHC DRB_CONN 5Qi Statistics
        uint8_t marked5qiForSymmRoHCDrbRrcInactStat;      // 5Qi value which is previously counted for Symmetric RoHC DRB_CONN 5Qi Statistics
        uint8_t marked5qiForEHCDrbRrcInactStat;      // 5Qi value which is previously counted for EHC DRB_CONN 5Qi Statistics
        uint16_t markedCellNumForEHCDrbRrcInactStat; // cellNum which is previously counted for EHC DRB_CONN Statistics

        // DRB Holding Time(RrcConn, RrcInact, RrcConnInact)
        Stopwatch_type drbHoldingTimeOfRrcConnInact;
        Stopwatch_type drbHoldingTimeOfRrcConn;
        Stopwatch_type drbHoldingTimeOfRrcInact;
        Stopwatch_type drbSetupTime;
    } drbConnStat;

    struct drbStatInfo_s
    {
        // Each stats has two family types:Setup/Rel, and each state should be counted only once.
        uint8_t attemptFlag[MAX_VCCB_DRB_STAT_FAMILY_TYPE];
    } drbStatistic;
    uint64_t qfiIdsToRelease;  // NG_HOREQ_PDU_QFI_DIFF_21B bitmap

    struct  // this anonymous structure should be referred if a procedure is related to MRDC
    {
        mrdcFlag_type mrdcFlag;

        uint8_t ulPdcpPath;      // enumUlPdcpPath
        uint8_t ulPdcpPathPrev;  // enumUlPdcpPath

        uint8_t ulPdcpPathToMod;  // enumUlConfigBearer

        uint8_t ulPdcpPathEnq;       // VCCB_FLAG_OFF, VCCB_FLAG_ON
        uint8_t ulPdcpPathEnqToSet;  // enumUlPdcpPath

        uint8_t prevSnDrbStatus;  // enumSABearerStatus_type
        uint8_t snDrbStatus;      // enumSABearerStatus_type

        // It is a valid DB at a specific point in time.
        // - FnVCCB_updateMrdcPrevInfo  : copy from current to prev.
        // - FnVCCB_restoreMrdcPrevInfo : copy from prev to current.
        uint8_t prevSelectedBearerTypeFrozenFlag;
        uint8_t selectedBearerTypeFrozenFlag;   // if selectedBearerType is decided, this should be set.

        nrdcBearer_type prevSelectedBearerType;
        nrdcBearer_type prevReqBearerType;
        nrdcBearer_type selectedBearerType;  // this will be selected according to YANG Configuration and should be
                                                // kept without change until drb is released.
        nrdcBearer_type reqBearerType;       // This is the bearer type of drb to be newly changed.

        nrdcBearer_type bearerType;  // This is copied from reqBearerType after the change of drb is completed(i.e,
                                        // after receiving rrcreconfigutaton complete).

#ifdef IPC_TEST
        uint8_t mCG_E1STOP      : 1; // Turns on/off when sending STOP/RESUME to E1. (MCG)
        uint8_t mCG_F1STOP      : 1; // TODO
        uint8_t sCG_E1STOP      : 1; // Turns on/off when sending STOP/RESUME to E1. (SCG)
        uint8_t sCG_F1STOP      : 1; // TODO
        uint8_t reserved1       : 1;
#endif

        union
        {
            struct
            {
                uint8_t oneTimeStateFlag : 1, needSnTermSplitMcgLegTobeReleased : 1,
                        needSnTermSplitSuccessionOfSrcSN : 1, needSnTermScgSuccessionOfSrcSN : 1, rsvd : 4;
            };
            uint8_t splitMcgLegCtrlFlag;
        };

        SNRejRelCauseInfo_type snRejRelCause;
        transportLayerInfo_type xNuDlInfo;
        transportLayerInfo_type xNuUlInfo;

        enumUlPrimaryPathMode ulPrimaryPathMode;
    };

    preemptionInfo_type markedToBeReleasedDrbByF1;  // Release Request Info by F1 DRB Preemption.
    preemptionInfo_type markedToBeReleasedDrbByE1;  // Release Request Info by E1 DRB Preemption.

    enumULUEConfiguration_type ulPdcpConfig;

    enumQosMonitoringRequest_type drbQosMonitoring;
    uint8_t qosMonitorActivated                 : 1;
    uint8_t isInSetupList                       : 1;    // 25A: use DC only.
                                                        // MN: When a request for MCG leg setup of a SN split bearer is received, isInSetupList is set to TRUE.
                                                        //     And when the MCG leg setup is completed, isInSetupList is initialized to FALSE.
                                                        // SN: When a request for SCG leg setup of a MN split bearer is received, isInSetupList is set to TRUE.
                                                        //     And when the SCG leg setup is completed, isInSetupList is initialized to FALSE.
    uint8_t                    reserved2                     : 6;
    qosFlowLevelQoSParam_type  termPointBasedDrbQos;    //  DB for DRB_QoS received from a peer node in an NRDC configured scenario
    vomaDrbStatus_type  vomaStatus;
    uint8_t pdcpDuplicationActive;   // flag to mark when PDCP Duplication was set as active for DRB
} callDRBInfo_type;

typedef struct
{
    callSNSSAI_type sNssai;
} savedPduParam_type;

typedef struct
{
    uint8_t usage;
    uint8_t pduSessId;
    uint8_t pduSessType;

    uint8_t prevPduSessStatus;              // enumSABearerStatus_type
    uint8_t pduSessStatus;                  // enumSABearerStatus_type
    uint8_t firstReqStatusInThisProcedure;  // enumSABearerStatus_type

    uint8_t activityStatusPrev;
    uint8_t activityStatus;

    uint8_t isBackedup                      : 1;   // Set TRUE when PDU Data is backed up. It's valid only in PDUModify_cmd.
    uint8_t needToReconfigE1ByF1Fail        : 1;   // Set TRUE when Status is changed to Fail by F1 so need to reconfig E1 Modification in DRB Partial.
                                                   // (S_Setup -> S_FailToSetup),  (Modify -> S_FailToModify)
    uint8_t needToGetBackup                 : 1;   // Set TRUE when PDU Modification Failure occurs for Rollback in DRB Partial
    uint8_t needToResponseToAmf             : 1;   // Increase count when AMF request setup/modify/release of PDU Session. (Include Release)

    uint8_t isSpecificSlice                 : 1;   // SVR25B FGR-CC3101. Set TRUE when PDU Slice is matched with specific Slice DB.
                                                   // It's valid when state is NOT S_Idle in RRCConnection_cmd/PDUSetup_cmd/PDUModify_cmd
    uint8_t specificSliceHasFailInNgStore   : 1;   // SVR25B FGR-CC3101. Set TRUE when PDU or QosFlow Fail in Specific Slice PDU in Ng/Vccb Store Stage.
    uint8_t rxNotSupportSlice               : 1;   // SVR25B FGR-CC3101. Set TRUE when Rx E/F1 Fail with slice fail cause or when VCCB not support Slice.

    uint8_t cslAllocOrder;                      // For DRB/PDU-related information sorting
    uint8_t flagUPIntegProtectIndReqOrPref;     // boolean

    uint8_t splitSessionIndicator;

    uint8_t nonGBRResourcesOffered;

    uint8_t numDRBPerPDUSess;
    uint8_t numQoSFlowPerPDUSess;

    uint8_t defaultGroupPresent;
    uint16_t mappingDrbIdxDefaultGroup;  // mapping default drb group idx

    uint8_t pduSessAmbrPresent : 1;
    uint8_t isE1Setupped       : 1;  // Indicates whether PDU is setupped in gNB-CU-UP which is in same CU
                                     // This will be set as true when receiving response from UP
    uint8_t fNeedModify_pduSessAmbrDL : 1;
    uint8_t fNeedModify_pduSessAmbrUL : 1;
    uint8_t alreadySentRelInfoToAmf     : 1;  // It's set in PDUSessionResourceNotify and PDUSessionReleaseResponse
    uint8_t alreadySentFailnfoToAmf     : 1;  // It's set in PDUSessionSetupResponse and InitialContextSetupResponse
    uint8_t isSavedRequestedPduParam    : 1;  // It's set When sNssai is changed and saved requested val in PDUSessionResourceModifyRequest
    uint8_t isLteFallbackTriggered      : 1;  // SVR26B FGR-SV0201. Set TRUE when EPS/Emergency(gNB Initiated) Fallback set for IRAT Redirection or H/O.

    struct
    {
        uint8_t notPossible : 1;  // 0:not present, 1:present
        uint8_t reserved    : 7;
    } dataForwarding;
    PduDataFwdTunnel_type nGuFwdTunnel;  // PDU forwarding tunnel
    uint32_t directFwdPathAvailable;

    struct pduStatInfo_s
    {
        // Each stats has two family types:Setup/Rel, and each state should be counted only once.
        uint8_t attemptFlag[MAX_VCCB_PDU_STAT_FAMILY_TYPE];
    } pduStatistic;

    uint16_t failCause;

    uint16_t e1Idx;

    releaseInfo_type releaseInfo;

    securityIndication_type securityInd;
    securityResult_type securityResult;

    SNRejRelCauseInfo_type snRejRelCause;

    enumPduSplitStatus splitStatus;

    preemptionInfo_type markedToBeReleasedPdu;  // Release Request Info by DRB Preemption.

    struct
    {
        enumPerformed_type integrityProtectionResult;
        enumPerformed_type confidentialityProtectionResult;
    } SecurityResult;

    callSNSSAI_type sNssai;
    savedPduParam_type  requestedPduParam; // It's valid only when isSavedRequestedPduParam is ON. It's not rollbacked when ModifyFail.

    uint64_t pduSessAmbrDL;
    uint64_t pduSessAmbrUL;

    flag_type flag;
    mrdcFlag_type mrdcFlag;

    uint16_t mappingRuleDrbIdx[MAX_MAPPING_RULE_INDEX];  // mapping rule drb index
    uint16_t drbIndex[MAX_DRB_PER_PDU_SESS];  // 0..15(MAX_DRB_PER_SA_CALL-1), init:0xFFFF
    uint16_t qosFlowIndex[MAX_QOS_FLOW_PER_PDU_SESS];  // 0..63(MAX_QOS_FLOW_PER_CALL-1), init:0xFFFF

    transportLayerInfo_type nGuDlInfo;    // UP Transport Layer Information in NG DL UP Transport Layer Information
    transportLayerInfo_type nGuUlInfo;    // UP Transport Layer Information in NG UL UP Transport Layer Information
    transportLayerInfo_type snNGuDlInfo;  // NG DL UP Transport Layer Information for SN terminated (NG-RAN Side)
    transportLayerInfo_type snNGuUlInfo;  // NG UL UP Transport Layer Information for SN terminated (UPF Side)
    transportLayerInfo_type sNDlFwdInfo;

    struct
    {
        transportLayerInfo_type addSnDlFwdInfo;
        uint8_t Qfi[MAX_QOS_FLOW_PER_PDU_SESS];
        uint8_t QfiCnt;
    } addSnDlFwdInfoList[NG_MaxnoofMultiConnectivitiesminus1];

#ifdef VCCB_IPC_TEST
    uint8_t reqCountOfQosFlowForCheck;      // Increase count when AMF request setup/modify of QosFlow. (Exclude Release)
#endif
} callPDUSessInfo_type;

typedef struct
{
    uint8_t ratType;  // ENUM:: enumRAT_type

    uint8_t nasPduPresent : 1;
    uint8_t reserved1     : 7;

    uint8_t numNasMsg;                             // Not Used in nasTransportInfo
                                                   // NAS-PDU of message should be filled first, if exist.
                                                   // PDU Session NAS-PDU should be filled after NAS-PDU of message.
    uint16_t nasIndex[VCCB_MAX_NAS_NUM_PER_CALL];  // In case of nasTransportInfo, index 0 DB is used only.

    uint16_t
        nasPduSessionId[VCCB_MAX_NAS_NUM_PER_CALL];  // It's for Partial Processing.
                                                     // 0~255  : PDU Session ID is for PDU Session NAS-PDU Info
                                                     // COMMON_NAS_PDU_SESSION_ID is for nasTransportInfo or NAS-PDU
                                                     // Info CANCELLED_NAS_PDU_SESSION_ID is for Partial Processing.
} nasInfo_type;

typedef struct
{
    uint8_t regionId;
    uint8_t pointer;
    uint16_t setId;
} amfIdentifier_type;

typedef struct
{
    plmnId_type plmn;
    amfIdentifier_type amf;
} ho_guami_type;

#define MAX_HO_FAILED_CALL_COUNT 8
// NR Connected Mobility
typedef struct
{
    uint8_t usage;
    uint8_t reserved1;
    uint16_t reserved2;
    cgi_type cgi;
    struct timeval failTime;
} failedCellInfo_type;

typedef struct
{
    failedCellInfo_type nrCell[MAX_HO_FAILED_CALL_COUNT];
    failedCellInfo_type eutraCell[MAX_HO_FAILED_CALL_COUNT];
} ho_failCell_list_type;

#define MAX_CHO_BLOCKED_CELL_COUNT 8
typedef struct
{
    failedCellInfo_type blockedCell[MAX_CHO_BLOCKED_CELL_COUNT];
} cho_block_list_type;

#define MAX_LTM_BLOCKED_CELL_COUNT 8
typedef struct
{
    failedCellInfo_type blockedCell[MAX_LTM_BLOCKED_CELL_COUNT];
} ltm_block_list_type;

typedef struct
{
    uint8_t meNBRscCoordFlag;      // MN(ENB) to SN(gNB)
    uint8_t sgNBRscCoordFlag;      // DU to CU
    uint8_t eNBCellIdChangedFlag;  // 1: eNB cell is changed, 0: not changed

    X2_MeNBResourceCoordinationInformation_type
        meNBRscCoord;  // MN(ENB) to SN(gNB) and CU to DU. used to ResourceCoordinationTransferContainer
    X2_SgNBResourceCoordinationInformation_type sgNBRscCoord;  // The information which received from DU
} rscCoordInfo_type;

typedef struct
{
    eNBCellInfo_type eNBCellInfo;  // User PLD to VCCB, CU to DU. used to ResourceCoordinationTransferInformation
} rscCoordInfo_Bkp_type;

typedef struct TRSR_s
{
    unsigned char data[2];
} TRSR_type;

typedef struct traceMdtStatus_s
{
    bool immediate;
    bool logged;
    bool uethr;
    bool trace;
} traceMdtStatus_type;

typedef struct SignalingTrace_s
{
    uint32_t duUEid; // Ue Id delivered in F1TraceStart, 0xFFFFFFFFF otherwise
    uint8_t nrdcSnActivationSentFlag;

    TraceReference_type traceReference;
    uint8_t tceId;
    TRSR_type traceRSR;

    struct traceActivationStatus_s
    {
        bool E1delivered;
        bool F1delivered;
    } traceActivationStatus;

    struct failureIndication_s
    {
        enumSigActFailResult cause;
        NGAP_Cause_type data;
        NGAP_NGRANTraceID traceId;
    } failureIndication;

    struct trace_s
    {
        enumTraceStatus traceStatus;
        universalTraceDepth_type traceDepth;
        uint8_t traceInterfaces;
        uint16_t msgSeqNum; // number of already sent trace msg
        uint8_t ueThroughputAndRfTraceFlag;
    } trace;

    struct mdt_s
    {
        enumMdtStatus mdtStatus;
        enumSigMdtTraceConfig mdt_Activation;
        uint8_t areaScopeType; //enumMdtAreaScope
        union area_u
        {
            struct cell_s
            {
                uint8_t numOfCell;
                cgi_type nrCgi[32];
            } cell;

            struct tac_s
            {
                uint8_t numOfTac;
                uint32_t TAC[32];
            } tac;

            struct tai_s
            {
                uint8_t numOfTai;
                struct tai_ss
                {
                    uint32_t tac;
                    plmnId_type plmn;
                } TAI[32];
            } tai;

        } areaScope;

        union mdt_u
        {
            struct immediate_s
            {
                struct
                {
                    uint8_t m1Flag : 1;
                    uint8_t m2Flag : 1;
                    uint8_t m4Flag : 1;
                    uint8_t m5Flag : 1;
                    uint8_t m6Flag : 1;
                    uint8_t m7Flag : 1;
                    uint8_t m1RrmFlag : 1;
                    uint8_t locationInfo : 1; // 7th bit not used so use for location storage: 1 - gnss, 0 - not used
                } measConfigFlags;

                struct m1Config_s
                {
                    uint8_t needUeConfig; // TRUE if configuration required
                    uint8_t reportingTrigger;
                    struct thresholdA2_s
                    {
                        uint8_t choice : 2;
                        union thresholdA2_u
                        {
                            uint16_t RSRP;
                            uint16_t RSRQ;
                            uint16_t SINR;
                        } threshold;
                    } thresholdA2;

                    struct periodicReporting_s
                    {
                        uint8_t reportAmount;     // enumMdtReportAmount (0-7)
                        enumMdtTraceReportInterval reportInterval;   // if 20480 or 40960 than Extended
                    } periodicReporting;

                    struct beamMeas_s
                    {
                        uint8_t includeBeamInd : 1;
                        uint8_t RSRP_RSRQ_SINR : 1;
                        uint8_t maxRepNum;
                    } beamMeasConfig;
                } m1Config;

                struct m45Config_s
                {
                    enumMdtTraceCollectPeriod period;
                    enumMdtTraceDir_type linksToLog;
                } m4Config, m5Config;

                struct m6Config_s
                {
                    uint8_t needUeConfig; // TRUE if configuration required
                    enumMdtReportAmount reportAmount;
                    enumMdtTraceReportInterval reportInterval;
                    enumMdtTraceDir_type linksToLog;
                } m6Config;

                struct m7Config_s
                {
                    uint8_t period; // 1-60 (mins)
                    enumMdtTraceDir_type linksToLog;
                } m7Config;

            } immediate;

            struct logged_s
            {
                uint8_t loggingInterval;
                uint8_t loggingDuration;
                uint8_t reportType; // enumMdtLoggingReportType // 0 - periodical , 1 - eventTrig_outOfCoverage, 2 - eventTrig_L1
                uint8_t areaScopeNeighCellCount; // 0 - option not present
                loggedMdtEventL1_type eventL1;

                struct nbrCellAreaScope_s
                {
                    struct nrFreqInfo_s
                    {
                        uint32_t arfcn;
                        uint8_t numOfFreqBand;
                        uint16_t frequencyBand[32]; // 1 - n1, 2 - n2 ...
                    } nrFreqInfo;

                    uint8_t numOfPci; // 0 - option not present
                    uint16_t pci[32];
                } nbrCellAreaScope[8];
            } logged;
        } config;

        struct signallingBasedPlmnList_s
        {
            uint8_t count;
            plmnId_type plmnList[16];
        } signallingBasedPlmnList;
    } mdt;

} SignalingTrace_type;

// <<<<<<<<<<<<<<<<<<<<<<< NEDC
typedef struct
{
    unsigned short dlSetId;
    unsigned short ulSetId;
} MrdcFeatureSet_type;

typedef struct
{
    unsigned short num;
    enumRAT_type ratType;
    MrdcFeatureSet_type featureSet[MAX_NUM_FEATURESETSPERBAND];
} MrdcFeatureSetPerBand_type;

typedef struct
{
    unsigned short num;
    MrdcFeatureSetPerBand_type featureSetPerBand[MAX_BANDS_PER_COMB];
} MrdcFeatureSetCombination_type;

typedef struct
{
    unsigned short num;
    MrdcFeatureSetCombination_type mrdcFeatureSetCombination[MAX_MRDC_FS_COMBS];
} MrdcFeatureSetCombinationList_type;

typedef struct
{
    uint8_t maxNumberMIMO_LayersPDSCH_present : 1;
    uint8_t channelBW_90mhz_present           : 1;
    uint8_t maxNumberMIMO_LayersPDSCH         : 2; /* enum NRRRC_MIMO_LayersDL */
    uint8_t rsvd                              : 4;

    // mandatory attributes
    //FGR-CC5200:FR150
    uint32_t supportedBandwidthDL_v1710   : 1;
    uint32_t supportedBandwidthDL_isFr2   : 1;
    uint32_t supportedBandWidthDL_value   : 8;
    uint32_t supportedSubcarrierSpacingDL : 8;
} FeatureSetDownlinkPerCC_type;

typedef struct
{
    uint16_t nrOfFeatureSetPerCCIds;
    uint16_t featureSetDownlinkPerCCIds[MAX_NR_OF_SERVING_CELLS];
} featureSetDownlink_type;

typedef struct
{
    uint8_t uePowerClassPerBandPerBCr17_present : 1;
    uint8_t uePowerClassPerBandPerBCr17 : 2; // NRRRC__enum184_2
} featureSetUplink_type;

typedef struct
{
    uint16_t nrOfFeatureSetsDownlink;
    featureSetDownlink_type featureSetsDownlink[MAX_NUM_DL_FEATURESET];

    uint16_t nrOfFeatureSetsDownlinkPerCC;
    FeatureSetDownlinkPerCC_type featureSetsDownlinkPerCC[MAX_NUM_FEATURESETS_PER_CC];

    uint16_t nrOfFeatureSetsUplink;
    featureSetUplink_type featureSetsUplink[MAX_NUM_UL_FEATURESET];

} FeatureSets_type;

typedef enum
{
    CA_BandwidthClassNR_NOT_SET,
    CA_BandwidthClassNR_a,
    CA_BandwidthClassNR_b,
    CA_BandwidthClassNR_c,
    CA_BandwidthClassNR_d,
    CA_BandwidthClassNR_e,
    CA_BandwidthClassNR_f,
    CA_BandwidthClassNR_g,
    CA_BandwidthClassNR_h,
    CA_BandwidthClassNR_i,
    CA_BandwidthClassNR_j,
    CA_BandwidthClassNR_k,
    CA_BandwidthClassNR_l,
    CA_BandwidthClassNR_m,
    CA_BandwidthClassNR_n,
    CA_BandwidthClassNR_o,
    CA_BandwidthClassNR_p,
    CA_BandwidthClassNR_q,
    CA_BandwidthClassNR_r2,
    CA_BandwidthClassNR_r3,
    CA_BandwidthClassNR_r4,
    CA_BandwidthClassNR_r5,
    CA_BandwidthClassNR_r6,
    CA_BandwidthClassNR_r7,
    CA_BandwidthClassNR_r8,
    CA_BandwidthClassNR_r9,
    CA_BandwidthClassNR_r10,
    CA_BandwidthClassNR_r11,
    CA_BandwidthClassNR_r12
} NrCaBandwidthClass;

typedef struct
{
    uint8_t ratType                           : 3;  // enumRAT_type, 0..5
    uint8_t nrCaBandwidthClassDL              : 5;  // enum NrCaBandwidthClass
    uint8_t nrCaBandwidthClassUL              : 5;  // enum NrCaBandwidthClass
    uint8_t numContiguousCcDL                 : 4;  // 1..12, 0 - if not present
    uint8_t numContiguousCcUL                 : 4;  // 1..12, 0 - if not present
    uint16_t freqBandIndicator;                     // 0..1024
} BandParameters_type;

typedef struct
{
    union
    {
        struct
        {
            uint8_t supportedNumberTAG_present:1;
            uint8_t reserved:7;
        };
        uint8_t present;
    };

    uint8_t supportedNumberTAG; // NRRRC__enum279
} CA_ParametersNR;

typedef struct
{
    union
    {
        struct
        {
            uint8_t simultaneousSRS_AssocCSI_RS_AllCC_present:1;
            uint8_t csi_RS_IM_ReceptionForFeedbackPerBandComb_present:1;
            uint8_t simultaneousCSI_ReportsAllCC_present:1;
            uint8_t reserved:5;
        };
        uint8_t present;
    };

    uint16_t simultaneousSRS_AssocCSI_RS_AllCC;

    struct csi_RS_IM_ReceptionForFeedbackPerBandComb
    {
        union
        {
            struct
            {
                uint8_t maxNumberSimultaneousNZP_CSI_RS_ActBWP_AllCC_present:1;
                uint8_t totalNumberPortsSimultaneousNZP_CSI_RS_ActBWP_AllCC_present:1;
                uint8_t reserved:6;
            };
            uint8_t present;
        };

        uint16_t maxNumberSimultaneousNZP_CSI_RS_ActBWP_AllCC;
        uint16_t totalNumberPortsSimultaneousNZP_CSI_RS_ActBWP_AllCC;
    } csi_RS_IM_ReceptionForFeedbackPerBandComb;

    uint16_t simultaneousCSI_ReportsAllCC;
} CA_ParametersNR_v1540;

typedef struct
{
    union
    {
        struct
        {
            uint8_t ca_ParametersNR_ForDC_present:1;
            uint8_t ca_ParametersNR_ForDC_v1540_present:1;
            uint8_t reserved:6;
        };
        uint8_t present;
    };

    CA_ParametersNR ca_ParametersNR_ForDC;
    CA_ParametersNR_v1540 ca_ParametersNR_ForDC_v1540;
} CA_ParametersNRDC;

typedef struct
{
    union
    {
        struct
        {
            uint8_t supportedCSI_RS_ResourceListAlt_r16_present:1;
            uint8_t reserved:7;
        };
        uint8_t present;
    };
} CodebookParameters_v1610;

typedef struct
{
    union
    {
        struct
        {
            uint8_t codebookParametersPerBC_r16_present:1;
            uint8_t reserved:7;
        };
        uint8_t present;
    };

    CodebookParameters_v1610 codebookParametersPerBC_r16;
} CA_ParametersNR_v1610;

typedef struct
{
    union
    {
        struct
        {
            uint8_t ca_ParametersNR_ForDC_v1610_present:1;
            uint8_t reserved:7;
        };
        uint8_t present;
    };

    CA_ParametersNR_v1610 ca_ParametersNR_ForDC_v1610;
} CA_ParametersNRDC_v1630;

typedef struct
{
    uint8_t num;  // 0..MAX_BANDS_PER_COMB(15)
    uint8_t powerClassNRPart; // NRRRC__enum298
    union
    {
        struct
        {
            uint8_t powerClass_present : 1, caParametersNRDC_present : 1, ne_DC_BC_present : 1, nedcOnly_present : 1,
                supportedNumberTAG_present : 1, caParametersNRDC_v1630_present : 1;

            //BandCombination-v1610
            uint8_t powerClassv1610 : 1, powerClassNRPart_present : 1;

            //BandCombination-v1720
            uint8_t higherPowerLimit_r17_present : 1;

            uint8_t reserved : 7;
        };
        uint16_t present;
    };

    uint16_t featureSetCombination;  // 0..1024
    BandParameters_type band[MAX_BANDS_PER_COMB];

    CA_ParametersNRDC caParametersNRDC;
    CA_ParametersNRDC_v1630 caParametersNRDC_v1630;
} BandCombination_type;

typedef struct
{
    uint16_t num;  // 0..MAX_BAND_COMBS(1024)
    BandCombination_type bandCombination[MAX_BAND_COMBS];
} bandCombinationList_type;

typedef struct
{
    uint8_t responseType;     // enumRrcReconfigurationCompleteTarget_type
    octetStringType message;  // used to pass Reconfiguration on XN link
} RrcReconfigurationCompleteBuff_type;

typedef struct
{
    union
    {
        uint32_t pScellFrequency;
        uint32_t pScellFrequencyEUTRA;
    };

    uint16_t phyId;        // T.B.D
    uint16_t servCellIdx;  // T.B.D

    struct
    {
        uint8_t present;
        union
        {
            cgi_type eCgi;   // for NEDC
            cgi_type nrCgi;  // for NRDC
        };
    } locationInfo;
} pSCellInfo_type;

typedef struct
{
    uint8_t requestedCellInfo_flag;
    uint16_t cellForWhichToReportCGI;
    uint32_t ssbFrequency;
} reportCgiRequest;  // CG-Config-v1540-IEs :: reportCGI-RequestNR

typedef enum
{
    SN_STATE_INACTIVE,
    SN_STATE_ACTIVE
} enumSNodeState_type;

typedef enum
{
    MN_STATE_INACTIVE,
    MN_STATE_ACTIVE
} enumMNodeState_type;

typedef struct
{
    union
    {
        struct
        {
            uint16_t usage : 1, mnNRCGI : 1, rsvd : 14;
        };
        uint16_t value;
    } m;

    cgi_type mnNRCGI;
} MNInfo_type;

typedef struct
{
    uint16_t epIdx;
    uint16_t nbrIdx;
    uint16_t state;  // 0:Inavtive, 1:Active

    union
    {
        struct
        {
            uint16_t ueXnAPID : 1, rsvd : 15;
        };
        uint16_t value;
    } m;

    uint32_t ueXnAPID;  // SN CallId

    pSCellInfo_type psCell;  // mn selects best cell when sends SNAdditionRequest and will be used for blackCell.
    pSCellInfo_type selectedPsCell;  // sn selects finally and the location information of SNAdditionAck will be stored.
    struct timeval additionTime;
    uint8_t nrofScellEarfcnDl;
    uint32_t scellEarfcnDl[MAX_NUM_SERVING_CELL - 1];  // scellFrequenciesSN-EUTRA
    uint8_t nrofScellNrArfcnDl;
    uint32_t scellNrArfcnDl[MAX_NUM_SERVING_CELL - 1];  // scellFrequenciesSN-NR
    uint8_t reportCgiRequest_flag;
    reportCgiRequest reportCgi;
} SNInfo_type;

typedef enum
{
    ci_scg_config_ue = 0,
    ci_scg_released_ue
} enumScgUeConfigure_type;

typedef enum
{
    MrdcHoWithoutSnChange = 0,
    MrdcHoWithSnRelease,
    MrdcHoWithSnChange
} enumMrdcHoScenario_type;

typedef enum
{
    MrdcMobilityYang_SnRelease = 0,
    MrdcMobilityYang_SnAddMod
} enumMrdcYangFlag_type;

typedef enum
{                                                       // This enumeration is for X2ModReq msg:
    X2ModReqS1UTunnelStatus_NoNeedToUpdate = 0,         // No modified E-RAB with S1-U Tunnel update
    X2ModReqS1UTunnelStatus_UpdatedOnly,                // Modified E-RAB with only S1-U Tunnel update
    X2ModReqS1UTunnelStatus_UpdatedDueToBearerTypeChg,  // Modified E-RAB with S1-U Tunnel update together with
                                                        // BearerChangeType
    X2ModReqS1UTunnelStatus_Error /* Error state when only S1-U Tunnel is updated in one E-RAB while
                                     S1-U Tunnel is also updated together with BearerChangeType in another.
                                     Another scenraio is when S1-U Tunnel is updated together with other updates
                                     within one E-RAB */
} enumX2ModReqS1UTunnelStatus_type;

typedef enum
{
    isF1AccSuccforPSCellExpected,
    isF1AccSuccforPSCellReceived,
    isDataActive,
    isStatsCollected
} enumNrdcCtxRelCtrlFlag_type;

typedef union
{
    struct
    {
        uint32_t code : 4,              /* SN_ADD_PROCEDURE : 1, SN_MOD_PROCEDURE : 2, SN_RELEASE_PROCEDURE : 3 */
            purpose : 8, initiator : 1, /* MN : 0, SN : 1 */
            snRelOprType : 8, rsvd : 11;
    };
    uint32_t value;
} mrdcProcedure_type;

typedef struct
{
    uint8_t mrdcSnRelMn[(STAT_MRDC_SN_REL_MN_END + 7) / 8];  // enumMrdcSnRelMnStatType STAT_NRDC_SN_REL_MN
    uint8_t mrdcSnRelSn[(STAT_MRDC_SN_REL_SN_END + 7) / 8];  // enumMrdcSnRelSnStatType STAT_NRDC_SN_REL_SN

    // FGR-CC5200:FR760 FR770 FR780 FR790
    struct NrdcSnConnInfoStats_s  // STAT_NRDC_SN_CONN_INFO_MN/STAT_NRDC_SN_CONN_INFO_SN
    {
        uint8_t connNoAvgUpdatedFlag : 1;  // this indicates if the count for connNoAvg has been already updated to
                                           // localStatsDB.
        uint8_t reserved : 7;

        uint8_t markedPlmnIdxForConnNoAvg;   // Plmn Index value which is previously counted for
                                             // NrdcMnConnNoAvg/NrdcSnConnNoAvg
        // uint16_t markedCellNumForConnNoAvg;
        uint16_t markedCellIdForConnNoAvg;   // cellId which is previously counted for
                                             // NrdcMnConnNoAvg/NrdcSnConnNoAvg
        uint16_t markedRfspForConnNoAvg;  // Rfsp Value which is previously counted for NrdcMnConnNoAvg/NrdcSnConnNoAvg

        Stopwatch_type setupTimeStopWatch;
        Stopwatch_type holdingTimeStopWatch;  // after setup completion
    } nrdcSnConnInfo;

    // FGR-CC5200:FR640
    struct NrdcCtxRelStat_s  // when ue is leaving pscell (during snRelease, mobility)
    {
        struct
        {
            uint64_t outstandingCellId;
            union
            {
                struct
                {
                    uint16_t isF1AccSuccforPSCellExpected : 1;
                    uint16_t isF1AccSuccforPSCellReceived : 1;  // this flag will be set if f1Access-success was
                                                                // received under the condition that the
                                                                // isF1AccSuccforPSCellExpected is on
                    uint16_t isDataActive     : 1;  // at least a DRB in E1BearerContextReleaseComplete is in-session
                    uint16_t isStatsCollected : 1;  // history whether nrdc_ctx_rel stats has already been
                                                    // collected to avoid duplicated collection during ho.
                    uint16_t reserved : 12;
                };
                uint16_t value;
            } flag;
        } ctrl;

        enumNrdcCtxRel_type releaseType;
    } nrdcCtxRel[MAX_SN];  // => for supporting intra-gnb HO

    // FGR-CC5200:FR641, FGR-CC5201:FR609, FGR-CC5203:FR231
    uint64_t nrdcCtxRelServiceType; // each bit is mapped to service-type-index(0~63) defined in FGR-CC0300 (MSB indicates index 0)
    uint8_t  isNrdcCtxRelServiceTypeValid : 1; // ON: nrdcCtxRelServiceType is valid
    uint8_t  reserved : 7;

} mrdcStatistic;

typedef struct
{                                // This structure will be used for master node on NEDC/NRDC
    uint8_t usage;               // CI_use, CI_no_use
    uint8_t ctrlCmd;             // T.B.D
    uint16_t prevState, prevCmd; /* T.B.D, If it is necessary to branch to B-procedure during A-procedure,
                                                       save the current state and cmd to go back A-procedure after
                                    finishing B-procedure. */

    int8_t ueCtxType;        // enumMrdcUeCtxType_type
    timerInfo_type xnTimer;  // this shall be used restrictively in case of that two timers is runing concurrently.
    mrdcProcedure_type procedure;  // this will be used for MN in the current scope and this variable shall be reset
                                   // wheneverr mrdc procedure is finalized.

    MNInfo_type MNInfo[MAX_MN]; // Used only in SN and refers to information about MN.
    SNInfo_type SNInfo[MAX_SN]; // Used only in MN and refers to information about SN.
    //
    uint64_t ueAmbrDlSN;  // for SN
    uint64_t ueAmbrUlSN;  // for SN
    uint64_t ueAmbrDlMN;  // for MN
    uint64_t ueAmbrUlMN;  // for MN

    // drxInfo_type              drxInfoSCG;// T.B.D, for NEDC when SN Change
    // drxCfg_type               drxCfgSCG; // for NRDC

    SNRejRelCauseInfo_type snRejCause;  // The reject cause of S-Node Addition Request Reject message from eNB.

    struct
    {
        uint32_t bandCombinationIndex;
        uint16_t requestedFeatureSets;
        uint32_t prevBandCombinationIndex;
        uint16_t prevRequestedFeatureSets;
    } selectedBC;

    // This db shall be cleared before store a received XN-message.
    union
    {
        struct
        {
            uint32_t f_cgCfg : 1, f_scgCellGrpCfg : 1, f_needForGaps : 1, f_selectedBC : 1, f_fullConfig : 1,
                f_locationInfo : 1, f_mrdcRscCoordInfo : 1, f_scgRBCfg : 1, f_xnModRqrd : 1, f_snStatus : 1,
                f_pdcpChg : 1, f_reportCgiRequestNr : 1, f_requestedCellInfo : 1, f_ulPathUsageInd : 1, rsvd : 18;
        };
        uint32_t value;
    } rcvXnInfoIndicator;

    union
    {
        struct
        {
            uint32_t f_scgCellGrpCfg : 1;  // From SN to MN (For SN Side)
            uint32_t f_scgRBCfg      : 1;  // From SN to MN (For SN Side)
            uint32_t rsvd            : 30;
        };
        uint32_t value;
    } sndXnInfoIndicator;

    // f_powerDistribution flag is set if powerDistributionUpdate is needed and powerCoordination should be send to
    // sNode and DU
    union
    {
        struct
        {
            uint32_t f_powerDistribution : 1, f_ueAmbr : 1, f_rfsp : 1, f_mrl : 1, f_ngUlUpInfo : 1,
                f_addiNgUlUpInfo : 1, rsvd : 26;
        };
        uint32_t value;
    } needModify;  // if needs SN Modification

    /* This should be cleared when SNAddition procedure is triggered.
       If SnAddition Procedure is failed, this flag will be checked to decide whether the message should be sent to
       release the resource*/
    // f_xn_tgtSnConn is for SN change
    union
    {
        struct
        {
            uint32_t f_xn_snConn : 1, f_xn_tgtSnConn : 1, f_e1_scgSetup : 1, f_f1_mrdcUeSetup : 1, f_uu_scgSetup : 1,
                rsvd : 27;
        };
        uint32_t value;
    } rscSetupFlag;

    /* e1 mrdc control flag */
    union
    {
        // This flages support the check point whether some specific IEs are candidates to be filled when sends
        // E1BearerModificationRequest. But this don't mean that E1BearerModificationReq always includes the IEs even if
        // the related flages is set. If both this flages is set and ptCi's information is proper to fill the related
        // IEs, then the rleated IEs will be filled.
        struct
        {  // to check whether DRB Modification is needed
            uint16_t f_scgAdd : 1, f_scgDel : 1, f_scgMod_xNuDlTnl : 1,
                f_scgMod_txStop           : 1, /*at mnTermSplit during SnRel*/
                f_scgMod_txResume         : 1, /*at mnTermSplit during SnRel*/
                f_mcgMod_txStop           : 1, /*during bearerChg(w/ change of pdcp termination point)*/
                f_mcgMod_txResume         : 1, /*during bearerChg(w/ change of pdcp termination point)*/
                f_mcgMod_dataFwdInfoReq   : 1, /*during bearerChg(w/ change of pdcp termination point)*/
                f_mcgMod_pdcpSNStatusReq  : 1, /*during bearerChg(w/ change of pdcp termination point)*/
                f_mcgMod_dataFwdInfo      : 1, /*during bearerChg(w/ change of pdcp termination point)*/
                f_mcgMod_pdcpSNStatusInfo : 1, /*during bearerChg(w/ change of pdcp termination point)*/
                f_mcgMod_f1uDlTnl         : 1, /* during bearer fallback */
                f_mcgMod_ulPathSwich : 1, rsvd : 3;
        };
        uint16_t value;
    } e1MrdcCtrlFlag[MAX_DRB_PER_SA_CALL];

    /* Cause to trigger the sNode Release Procedure */
    enumSNodeRelReasonType sNodeRelCause;

    /* Queued Cause to trigger the sNode Release Procedure from queued release action */
    enumSNodeRelReasonType queuedSNodeRelCause;

    /* Flag to determine whether SN Release Request to send  */
    uint32_t sNodeRelReqSkipSendFlag : 1;  // Skip sending if flag is set
    uint32_t sNodeRelRqrdRcvFlag     : 1;  // received SNodeReleaseRequired from SN

    /* This variable is used for motion control for NE-DC Mobility. */
    union
    {
        struct
        {
            uint32_t ueState : 1;  // enumScgUeConfigure_type
            uint32_t rsvd    : 31;
        };
        uint32_t value;
    } mobilityCfg;

    /* NRDC SCG Failure type */
    uint8_t queuedScgFailCauseInfo;  // NR_CONN_MC_21D

    mrdcStatistic stat;

    struct
    {
        uint16_t dlReducedCCsTransmittedToSgNB; // Used NR-DC MN only
        uint16_t ulReducedCCsTransmittedToSgNB; // Used NR-DC MN only
    } overheating;

//FGR-CC5200:FR481
#define NO_RECEIVE 0
#define MULTI_RECEIVE 0xffffffff
    cgi_type nrCgiReceivedFromMn;
    uint32_t cacRejectedBySnDu_Flag : 1; /* FGR-CC5200:FR481 This flag will be set at SN side during initial sn addition
                                            procedure. No need to reset because sn-call will be released after rejecting
                                            SNodeAdditionRequest*/
    uint32_t cacRejectedBySnUp_Flag : 1; /* FGR-CC5200:FR1030:SVR25A
                                            This flag will be set at SN side when E1 Bearer Context Setup fail
                                            by CauseE1apRadioNetworkLayerResourcesNotAvailableForTheSlice. */

    /////////////////////////////////////////////////////////////////////////////////////////////////////
    //  recommend> The variables of octetStringType should be positioned at end of mrdcInfo_type structure.
    //              Because these variables should be excluded from redundancy backup.
    //
    //  notice> If you want to add new variable of octetStringType,
    //          you must add the new variable to both VLIB_FreeBuffAllMrdcInfo() and
    //          VLIB_ReconfigMrdcInfoAfterSwitchOver
    //
    union
    {
        octetStringType candidateCellInfoListMN;        // NRDC
        octetStringType candidateCellInfoListMN_EUTRA;  // NEDC
    };

    octetStringType candidateCellInfoListSN;  // NRDC/NEDC

    octetStringType scgCellGrpConfig;  // NRDC(NR), EUTRA(EUTRA)
    octetStringType scgRBConfig;
    octetStringType measResultSCG_EUTRA;  // related to the delivery of SCGFailureInformation
    octetStringType measResultSCG_NRDC;   // SVR22B FGR-CC5203
    octetStringType uLInformationTransferMRDC;
    //////////////////////////////////////////////////////////////////////////////////////////////////
} mrdcInfo_type;  // nedc/nrdc

// >>>>>>>>>>>>>>>>>>>>>>>>>>>>

typedef struct
{
    uint32_t ssbFrequency;
    enumSubcarrierSpacing ssbSubcarrierSpacing;
    smtc1_type smtc1;
} redirectionInfoNr_type;

typedef struct
{
    uint32_t carrierFreq;
    uint32_t overlappedCarrierFreq;
} redirectionInfoEutra_type;

typedef struct
{
    uint8_t usage;  // CI_use, CI_no_use;
    redirectionInfoNr_type nr;
} cacTriggeredRedirectionInfo_type;

typedef struct
{
    enumRedirectionType_type redirType;

    timerInfo_type mrWaitTimer;

    union
    {
        redirectionInfoNr_type nr;
        redirectionInfoEutra_type eutra;
    } rat;

    uint8_t actualRedirectionMethod;     // enumRedirectionMethod_type. Actual method considering UE Capa and YANG
    uint8_t isEPSFallbackRequired  : 1;  // TRUE or FALSE. For EPS Fallback Feature
    uint8_t emergencyFallbackInd   : 1;  // TRUE or FALSE. For Emergency Fallback Feature
    uint8_t voiceFallbackIndicator : 1;  // TRUE or FALSE for 5QI=1 of EPS/Emergency Fallback
    uint8_t onDemandRedirect       : 1;  // TRUE or FALSE : triggering by OnDemand Forced Function
    uint8_t requestedByA2Blind     : 1;  // TRUE or FALSE : triggering by A2 Blind Redirection
    uint8_t rfspBasedBlind         : 1;  // TRUE or FALSE : triggering by RFSP based Inter-RAT Redirection
    uint8_t nonNeighbor            : 1;  // TRUE or FALSE : triggering by non-neighbor handover, target is redirection only mode cell FGR-MC1028 FR210
    uint8_t isSpecificSliceRejected: 1;  // TRUE or FALSE : For Slice Aware Mobility Control Feature

    uint8_t specificSliceRedirectInBasicSA  : 1;  // TRUE or FALSE : triggering by Specific Slice Fail in Basic SA. Separate variables to avoid competing conditions. SVR25B FGR-CC3101
    uint8_t reserved               : 7;  // reserved

    uint16_t specificSliceFailCause;       // saving Fail cause by Specific Slice Fail. SVR25B FGR-CC3101

} redirectionInfo_type;

typedef struct
{
    uint8_t dlDataFlag;                           // Set TRUE when RAN Paging is triggered by DL DATA msg
    uint8_t pagingTriggeredByDLNasTransportFlag;  // Set TRUE when RAN Paging is triggered by NGAP DL NAS TRANSPORT
    uint8_t exceptionalFlag;  // Set TRUE in case of E1/NG Reset and Idle Timeout in RRC_INACTIVE state
    uint8_t ngUeContextModFromQueue;
} ranPagingInfo_type;

typedef struct
{
    struct
    {
        uint16_t erabModify           : 1;  // erab Add/Mod/Rel for NSA
        uint16_t ambr                 : 1;  // UE AMBR
        uint16_t resourceCoordination : 1;  // IMD Harmonic/DPS
        uint16_t desiredActivity      : 1;
        uint16_t spidBasedIAT         : 1;
        uint16_t cgConfigInfoFwd      : 1;  // cgConfigInfo which need to forward to DU
        uint16_t measGap              : 1;  // cgConfigInfo > measConfigMN
        uint16_t allowedBC            : 1;  // cgConfigInfo > configRestrictInfo > allowedBC_ListMRDC
        uint16_t pduModify            : 1;  // PDU Add/Mod/Rel SA
        uint16_t rfsp                 : 1;
        uint16_t coreNetworkAssistance: 1;
        uint16_t sliceMbr             : 1;
        uint16_t releaseUPContext     : 1; // need to release UP Context when the last existing PDU session or DRB is deleted.
    } eventFlag;

    uint16_t selectedModProc;
} modificationProcedure_type;

typedef struct rrcPackBuff_s
{
    uint8_t buf[MAX_RRC_PDU_LENGTH];
    long len;
} rrcPackBuff_type;

/* RRC Segmentation Buffer */
typedef enum
{
    UL_DCCH_Message = 0,
    UE_NR_Capability,
    UE_MRDC_Capability,
    UE_EUTRA_Capability,
    UNKNOWN_SEGMENT_PDU_TYPE
} enumSegmentPdu_type;

typedef struct rrcSegBuf_s
{
    uint16_t usage;
    uint32_t callId;
    enumSegmentPdu_type segmentPduType;
    uint16_t numocts;
    uint8_t data[MAX_RRC_PDU_LENGTH];
} segmentPoolBuffer_type;

typedef struct rrcSegNode_s
{
    uint32_t maxPoolSize;
    uint32_t sizePerThread;
    uint32_t nextIndex[VCCB_CALL_THREAD_NUM];
    uint32_t availCnt[VCCB_CALL_THREAD_NUM];
} segmentPoolManager_type;

typedef struct
{
    uint8_t segCnt;
    uint8_t lastSegIdx;
    uint32_t capaLength;
    uint32_t segIndex[MAX_RRC_SEGMENT];  // pool index
} extUeCapaInfo_type;

/**
 *  * @brief X2 / XN neighbor Segmentation Support information
 *   */
typedef struct
{
    uint8_t status;        /**< EQUIP/N_EQUIP */
    uint32_t nodeId;       // remote-enb-id, remote-gnb-id
    plmnId_type nodePlmn;  // plmn-identity
} nodeNbrSegInfo_type;

typedef struct
{
    uint16_t num;
    uint16_t nrFreqBand[MAX_FREQBAND_FILTER];  // 128
} gnbSupportedBandInfo_type;

#define START_BAND_NUM_OF_FR2_NR    257
typedef struct
{
    uint8_t needEnquiryBitFlag;      // enumNrUeCapaRequestRat_type
    uint8_t needEnqurity3Step;       // ON/OFF
    uint8_t rxUeCapaInfoBitFlag;     // enumNrUeCapaRequestRat_type
    uint8_t sendToAmfFlag      : 1;  // ON/OFF
    uint8_t includeFr2InNrBand : 1;  // ON/OFF // SVR26A FGR-CC3103 - It's only valid in FillNRRRC_UECapabilityEnquiry() proceudre
    uint8_t reserved           : 6;
    timerInfo_type ueCapaInfoTimer;  // Waiting for UE Capa Information.
} ueCapaEnquiryInfo_type;

typedef struct
{
    uint8_t numAddMod;
    uint16_t addModFreqBandInfo[MAX_NR_CELL_FREQ_BAND_LIST];

    uint8_t numDel;
    uint8_t delFreqBandStatus[MAX_NR_CELL_FREQ_BAND_LIST];
    uint16_t delFreqBandInfo[MAX_NR_CELL_FREQ_BAND_LIST];
} cellBand_changedInfo_type;

typedef struct
{
    uint8_t rsrpFlag : 1;
    uint8_t rsrp     : 7;
    uint8_t rsrqFlag : 1;
    uint8_t rsrq     : 7;
} servingCellMeasInitialInfo_type;

typedef struct
{
    uint8_t ulPdcpPath;         // enumUlPdcpPath
    uint8_t ulPrimaryPathMode;  // enumUlPrimaryPathMode
    uint8_t nrUlCoverageState;  // enumNrUlCoverageState
    uint8_t qci128SwitchFlag;
} UlPathControlInfo_type;

typedef struct
{
    UlPathControlInfo_type prev, curr;
    bool ueCongestionState;
    bool revertUlPathChange;
    uint16_t prbUsageInformation;

    struct
    {
        uint8_t reserved         : 8;
    } flag;

} UlPathControl_type;

typedef struct ueMeasForSon_s
{
    uint32_t selectedNrArfcn;
    uint32_t selectedCbrsArfcn;
    uint32_t selectedEutraArfcn;
    timerInfo_type measTimer;
    timerInfo_type measDelayTimer;
    uint8_t ueMeasForSonState;  // enumUeMeasForSonState_type
} ueMeasForSon_type;

typedef struct
{
    uint8_t usage;
    uint8_t mrCollectedCnt;
    uint8_t enqueuedSnAddTriggerFlag : 1;
    uint8_t reserved                 : 7;
    timerInfo_type newBandMrWaitTimer;
    uint16_t fr2Band;
    octetStringType measResultList2NR;
} loadBasedNrdcScgBandSelection_type;

    // FGR-LC0705:FR12
typedef struct
{
    uint32_t rsuTransId;
    /* TBD
    uint8_t bandSelectionMode;
    uint8_t scgBandCapacityOption;
    uint8_t scgBandThresholdUeCapaNrdcPerMeasObj[MAX_NR_OF_OBJECT_ID_DB];
    uint16_t scgBandThresholdEventTrigger;
    */
    enumScgBandSelectionOprMode_type oprMode;
    uint32_t rsuTransIdForLb;
    double dlThForLb;
    double ulThForLb;
} nrdcScgBandSelectionMgmt_type;

typedef struct
{
    uint32_t savedSendingDlNasPdcpSn;
    uint16_t usingDlNasAck           : 1;  // Set TRUE when NAS AcK Configuration is true.
    uint16_t needToGoDequeueState    : 1;  // Set TRUE when have to go Dequeue procedure in AllState.
    uint16_t isInDequeueingProcedure : 1;  // Set TRUE when Only Dequeue procedure in
                                           // VCCM_HandleDequeuedDlNasDuringOtherNasProc()
    uint16_t reserved : 13;
} ueDlNasAckInfo_type;

// SVR23A FGR-CC5203 FR130: blocked-list SN
#define MAX_SN_BLOCKED_GNB_COUNT 8
typedef struct
{
    uint8_t usage;
    uint8_t currentIndex;
    uint8_t count;
    vccbGlobalGnbId_type blocklist[MAX_SN_BLOCKED_GNB_COUNT];
} NrdcScgBlockListInfo_type;

// for Multi-Carrier Operational FGR-CC5500 (PCC)
typedef struct
{
    uint16_t nbrIdx;
    uint16_t pci;
    uint32_t ssbArfcn;
} PccPscellCandidateInfo_type;

typedef struct
{
    uint16_t pcellSelectedBand;
    uint16_t scellAltBandTab[MAX_MCO_MFBI_CELLS];
    uint32_t scellAltBandNrArfcnTab[MAX_MCO_MFBI_CELLS];
    uint32_t effectiveBw;
    PccPscellCandidateInfo_type pscell;
} PccCandidateResult_type;

typedef struct
{
    uint8_t mrRcvPcellFlag : 1;
    uint8_t resultNum : 2;  // (1..MAX_PCC_RESULTS_PER_CANDIDATE(3))
    uint8_t mrRcvPscellMap : MAX_PCC_RESULTS_PER_CANDIDATE; // index is PSCell index in results
    uint8_t mrRcvAlternatePcellFlag: 1; // set when other cell than candidate will be measured with better signal (num is stored in alternateCellNum)
    uint16_t cellNum;
    uint16_t alternateCellNum;
    PccCandidateResult_type results[MAX_PCC_RESULTS_PER_CANDIDATE];
} PccCandidateInfo_type;

typedef struct
{
    cellSelection_type queuedHO_nbrSelection;
    uint8_t hoTriggerQuantity;
} PccHoData_type;

typedef struct
{
    Arfcn_type arfcn;
    CellPci_type measuredCellPcis[MAX_NUM_CELL_REPORT];
    uint8_t measuredCellRsrps[MAX_NUM_CELL_REPORT];
} FmPccChosenCc_type;

typedef struct
{
    uint8_t state : 4;  // enumPCCState_type
    uint8_t pccMode: 2; // enumPccMode_type
    uint8_t interRatState : 2;  // enumIRatPCCState_type
    uint8_t interRatConfigIndex; // 0 - 31
    uint16_t scellAltBandTab[MAX_MCO_MFBI_CELLS];
    uint32_t scellAltBandNrArfcnTab[MAX_MCO_MFBI_CELLS];
    uint16_t pscellNbrIdx;
    PccCandidateResult_type currCellResult;
    union
    {
        PccCandidateInfo_type candidate[MAX_PCC_CANDIDATES];
        PccHoData_type pccHoData;      // in case of triggering HO is queued (state == PCC_HOQueued)
    };
    FmPccChosenCc_type fmPccChosenCcs[MAX_MCO_FM_PCC_ARFCN];
    timerInfo_type pccTmr;
    timerInfo_type slbTmr;
    timerInfo_type interRatWaitingTmr;
} PccData_type;

// for Multi-Carrier Operational FGR-CC5500 (SCC)
typedef struct
{
    uint8_t state : 4; // enumSCCState_type
    uint8_t reserved : 4;

    uint32_t a4MrSetAndReceived;
    uint32_t a2MrReceived;

    uint16_t scellAltBand[MAX_MCO_MFBI_CELLS];          // Alternate Band of Candidate SCell Init:BAND_NOT_FOUND
    uint32_t scellAltBandSsbArfcn[MAX_MCO_MFBI_CELLS];  // When calculate MAX Total Scell BW and Specific Candidate SCell Band is alternate Band, if MAX BW,
                                                        // ssbArfcn of the Candidate SCell
                                                        // Init:UNKNOWN_ARFCN
    uint32_t totalMaxBw;        // MAX Total SCell BW of specific PCell Init:UNKNOWN_BANDWIDTH
    uint16_t calculatedBandNr;  // NR Band of PCell, When calculating Init:BAND_NOT_FOUND
    uint16_t calculatedCellNum; // CellNum of PCell, when calculating Init:MAX_CELL_NUM_VCCB
    timerInfo_type sccGatheringTimer;
    timerInfo_type sccMeasReactTimer;
} SccData_type;

typedef struct
{
    uint8_t state;
    uint32_t a4MrSetAndReceived;
    uint32_t a2MrReceived;
    uint32_t totalMaxBw;
    uint16_t scellAltBand[MAX_MCO_MFBI_CELLS];
    uint32_t scellAltBandSsbArfcn[MAX_MCO_MFBI_CELLS];
} PrevSccData_type;

// for Multi-Carrier Operation FGR-CC5500 (SpCell LB)
typedef unsigned __int128 McoLbCacheUeBcKey_type;

typedef struct
{
    uint8_t eligibleCcIdxBitmsk;    // 0 : unused entry
    uint8_t bestSpCellsBitmask;     // bitmask indicating PCells with max BW (within DU-band)
    uint8_t checkedSpCellsBitmask;  // bitmask indicating checked PCells (within DU-band)
    uint32_t bwDl;                  // max DL BW result for indicated best PCells
    uint32_t bwUl;                  // max UL BW result for indicated best PCells
    McoLbCacheUeBcKey_type ueBcKey; // md5 hash computed from (allowed) UE BCs
    time_t hitTime;                 // last hit time
} McoLbCacheResultEntry_type;

#define INVALID_CALL_ID 0xFFFFFFFF
#define INVALID_CPC_ID  0xFFFF
#define INVALID_GNB_ID  0xFFFFFFFF
#define INVALID_ENB_ID  0xFFFFFFFF

typedef struct
{
    struct
    {
        uint8_t isUseAllocDB : 1;
    } m;

    struct
    {
        int reserved;
    } info;

} extCallDbCtl_type;

//SVR23A MRS
typedef struct {
    uint16_t    measuredPci;  // Init:0xFFFF not measured, PCI in MR
    int8_t      measuredRsrp; // Init:-1 not measured, RSRP in MR
    int8_t      measuredRsrq; // Init:-1 not measured, RSRQ in MR
    int8_t      measuredSinr; // Init:-1 not measured, SINR in MR
    uint8_t     cgiExist;
    cgi_type    cgi;
} eutraGatheringMeasResult_type;

//SVR23A MRS
typedef struct {
    uint8_t     usage;         // CI_no_use: not configured, CI_use: configured
    uint8_t     numTargetCell; // 0 ~ MAX_CELL_REPORT(8), num of target cell in MR
    uint16_t    reserved;
    uint32_t    earfcnDl;
    eutraGatheringMeasResult_type measResult[MAX_NUM_CELL_REPORT];
} eutraGatheringMeasInfo_type;

//SVR23A MRS
typedef struct {
    uint8_t     measureInfoCnt;
    eutraGatheringMeasInfo_type measureInfo[MAX_NR_OF_OBJECTEUTRA_ID_DB];
} eutraGatheringInfo_type;

typedef struct
{
    uint8_t mrsState; // Default: MRS_Idle

    uint8_t rejectStatus   : 1; // Default : VCCB_FLAG_OFF
    uint8_t hoFlag         : 1; // Default : VCCB_FLAG_OFF
    uint8_t reserved       : 6; // Default : 0

    timerInfo_type responseWaitTimer;   // timX2_BcInformationResponse_id
    timerInfo_type interRatMrWaitTimer; // timInternalIratMeasForMrs_id
    timerInfo_type mrsMrGatheringTimer; // timMrsMrGatheringWaiting_id

    struct {
        uint16_t pci;       // 0...MAX_EUTRA_PHYSICAL_CELL_ID / Default : MAX_EUTRA_PHYSICAL_CELL_ID + 1
        uint16_t nbrIdx;    // 0...(MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL-1) / Default : MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL
        uint32_t earfcnDl;  // Default : 0
        cgi_type cgi;       // Default : 0
        uint8_t ratType;
        uint16_t bandCombinationIndex; // Default : 0
    } targetEutraInfo;

    eutraGatheringInfo_type eutraGatheringInfo;
    uint32_t mrsCheckFlag; // Indicate Eutra Obj received

} mrsInfo_type;

typedef struct
{
    uint8_t mrsState; // Default: MRS_Idle
    uint32_t mrsCheckFlag; // Indicate Eutra Obj received
} prevMrsInfo_type;

typedef struct
{
    uint8_t  onOff;  // enumVccbFlag
    uint8_t  cause;  // enumScgFailCauseInfo_type
    uint16_t cellId; // Saved cell-id to be the same for attempt and success stats.
} scgFailAttSuccStats_type;

/* SAMSUNG SPECIFIC START */
typedef struct
{
    uint16_t bandCombIndex;  // INTEGER(1..65536) -> 0..65535
    uint8_t  numOfFeatureSetPerBand;
    struct
    {
        uint8_t  index;  // INTEGER(1..128) -> 0..127
        uint16_t expectedThroughput;    // INTEGER(0..32767,...) -> 0..32767,...
    } featureSetEntry[MAX_NUM_SS_EXPECTED_TP_FEATURESET_ENTRY];

} SamsungExpectedTP_type;

typedef struct
{
    uint8_t                          numOfItems;
    SamsungExpectedTP_type item[MAX_NUM_SS_EXPECTED_TP_BANDCOMB];
} SamsungExpectedTPList_type;
/* SAMSUNG SPECIFIC END */

typedef struct
{
    uint8_t num; // number of failed candidate cells
    struct {
        uint16_t cellId;
        uint16_t spCellSelFailure; // enumStatEndcAddDetailedCpFail_type
        uint32_t arfcn;
    } SpCellSelFailPerCandidateCell[MAX_NUM_CELL_REPORT];
} SpCellSelFailStats_type;

#ifdef __CNF__  // CallTakeover
typedef struct
{
    uint32_t distCallId : CUCP_UEID_VCCB_CALL_ID_LEN;
    uint32_t distCode : CUCP_UEID_DIST_CODE_ID_LEN;
    uint32_t reserved   : 1;
    uint32_t debugTrace : 1;
} CuCpUeIdDetail_type;
#else
typedef struct
{
    uint32_t vccbCallId : CUCP_UEID_VCCB_CALL_ID_LEN;
    uint32_t cpcId : CUCP_UEID_CPC_ID_LEN;
    uint32_t debugTrace : 1;
} CuCpUeIdDetail_type;
#endif

typedef union
{
    CuCpUeIdDetail_type detail;
    uint32_t id;
} CuCpUeId_type;

typedef struct
{
    uint8_t  redCapUeFlag;         // 0 : False, 1 : True
    uint8_t  supportOfRedCap_r17;  // 0 : False, 1 : True                        (UE CAPA)
    uint8_t  supportOf16DRB;       // 0 : Not Support, 1 : Support               (UE CAPA)
    uint8_t  supportOf18bitPdcpSN; // 0 : Not Support(12bit), 1 : Support(18bit) (UE CAPA)
    uint8_t  isAttachFailedByRedCap;
} redCapUeInfo_type;

typedef struct
{
    timerInfo_type waitTimer; // FR20, FR460
    uint8_t triggerEvent:1; // TRUE : need to try attach wait timer
    uint8_t needMeasCfgForRedCap:1; // TRUE: need to configure A5 meas for RedCap UE
    uint8_t reserved:6;
    uint8_t tgtSliceIdx; // Range: 0 ~ MAX_ACTIVE_SLICE_NUM (0~(MAX_ACTIVE_SLICE_NUM-1): valid, MAX_ACTIVE_SLICE_NUM: default and invalid)
} sliceAwareLb_type; //SVR23B FGR-LC0710

typedef struct
{
    time_t timeStamp;                  // to compare with restrictedGnbLifeTime(debug cfg)
    vccbGlobalGnbId_type globalGnbId;  // global gnb-id
} RestrictedGnb_type;

typedef struct
{
#define MAX_RESTRICTED_GNB_BY_OVLD 7
    uint8_t isDisabled;  // controlled by debug command, default : 0
    uint8_t currIdx;     // to store new element
    uint8_t noofElm;     // for searching loop

    // if the new element is added, then it will be kept until overwritten by wrap around
    RestrictedGnb_type gnbList[MAX_RESTRICTED_GNB_BY_OVLD];

} NrdcSnRestrictedGnbsByOvld_type;

// FGR-CC5200:FR482
typedef struct
{
#define MAX_NRDC_ADD_CAC_REJECTED_FREQ 8
    uint8_t bitMask;                                        // usage
    uint8_t nextIdx;                                        // nextIdx = (nextIdx + 1) % MAX_CAC_REJECTED_FREQ
    uint16_t cellId;
    uint32_t ssbArfcnList[MAX_NRDC_ADD_CAC_REJECTED_FREQ];  // The ssb-arfcn of MR will be registered

    /* if SNodeAdditionRequestReject w/ cause:NoRadioResourcesAvailableInTarget for initial-addition
       rather than mobility is received from SN */
} NrdcAddCacRejectedFreq_type;

typedef struct
{
    // the targetUe value indicates the on-demand handover target.
    // If the cell is switching OffOngoing state and targetUe is being attached, targetUe is set to TRUE.
    // When the HO is triggered, it is unset.
    // If the triggered HO is canceled, the targetUe value is restored from prevTargetUe.
    uint8_t targetUe        : 1; /* TRUE: set meas. cfg for On Demand Handover */  // ODF_HO_21B
    uint8_t prevTargetUe    : 1; /* TRUE: set meas. cfg for On Demand Handover */  // ODF_HO_21B
    uint8_t hoTriggered     : 1; /* TRUE: the handover is triggered by onDemand MR */  // RETAIN_STAT_HO_21C
    uint8_t release         : 1; /* TRUE: the onDemand relese is triggered */          // RETAIN_STAT_HO_21C

    uint8_t reserved        : 4;
} onDemandHoInfo_type;

typedef struct
{
    uint32_t msgId;
    uint16_t releaseCause;
} callFaultForForcedRelease_type;

typedef struct
{
    timerInfo_type timer;
    callFaultForForcedRelease_type callFaultForForcedRelease;
    bool statusReasonTable[MAX_REASON_FORCED_MOBILITY]; // flag for every enumUlStatusMobilityReason_type value
    uint16_t lockedServCellNum;
    uint8_t ulStatusReasonTriggeredHandover; // enumUlStatusMobilityReason_type
    struct
    {
        uint8_t usage; // enumUsage_type
        uint16_t lockedServCellNum;
        callFaultForForcedRelease_type callFaultForForcedRelease;
        uint8_t ulStatusReason; // enumUlStatusMobilityReason_type
    } queuedForcedReleaseInfo;
    uint8_t measConfFilteringActive : 1; // 0 : False, 1 : True
    uint8_t intraNrHandoverTriggered : 1; // 0 : False, 1 : True
    uint8_t interRatHandoverTriggered : 1;  // 0 : False, 1 : True
    uint8_t redirectionTriggered : 1; // 0 : False, 1 : True
    uint8_t releaseTriggered : 1; // 0 : False, 1 : True
    uint8_t mrProcessing : 1; // 0 : False, 1 : True
    uint8_t startTimer : 1; // 0 : False, 1 : True
} uplinkStatusTriggeredMobilityInfo_type;

/* Partial DRB*/
typedef struct
{
    // After Receiving
    uint16_t finalFailCause;       // Save cause of PDU or SRB Fail when received Partial/All Failure for E1/F1 Interface.
    uint16_t semiFinalFailCause;   // Save cause of DRB Fail when received Partial/All Failure for E1/F1 Interface.
    uint16_t rxMsgIdForCallFault;  // Set Rx MsgId when received Partial Success Response in E1 Interface  (E1 Setup/Modify Response/Failure)

    // Before Sending
    uint8_t  requestedOption;      // Set value before sending E1/F1 Setup/Modification Request.
                                   // Depending on this value , operation can be different when when received Partial/All Failure for E1/F1 Interface.
                                   // PARTIAL_OPT_RETURN_SPECIFIC_VALUE, PARTIAL_OPT_SAVE_STATUS_OF_FAIL_BEAERER, PARTIAL_OPT_SAVE_PDU_AS_FAIL_IN_F1_FAIL
    // flag
    uint8_t preConditionSupport   : 1; // Set TRUE when pre-Coding of E1/F1 Partial Support is satisfied.

    // After Receiving
    uint8_t rxPartialResponse     : 1; // Set TRUE when received Partial Success Response in E1/F1 Interface  (E1/F1 Setup/Modify Response)
    uint8_t rxFailureMessage      : 1; // Set TRUE when received Failure Message in E1/F1 Interface (E1/F1 SetupFailure/Modification Failure)

    uint8_t rxDrbModifyOrRelFail  : 1; // Set TRUE when received DRB Modify/Release Failure in E1/F1 Interface
    uint8_t rxSrbFail             : 1; // Set TRUE when received SRB Failure in F1 Interface
    uint8_t isNotSupportSwVersion : 1; // Set TRUE if interface version is less than 24A ( if sWVersion < 24A )
    uint8_t oldDssCauseRelease    : 1; // backup ptCi->dssCauseRelease. Using it in F1 Interface.
    uint8_t reserved              : 1;
} VccbE1F1PartialInfo_type;

typedef struct
{
    uint8_t reqDrbModiOrRelExist             : 1; // Set TRUE if this procedure has DRB Modify or DRB Release in InitialContextSetup/PDU Session Setup/Modify
    uint8_t rxPartialOrFailureMessage        : 1; // Set TRUE if this procedure has E1/F1 Partial response or Failure Message . It will be used after procedure is done.
    uint8_t isMnNeedToModifySnBearerInPduModifyCmd : 1; // Set TRUE if NR-DC MN need to modify SN Bearer in PDU Session Modify Request Procedure.
    uint8_t isNrDcMnE1Setup                   : 1; // Set TRUE if NR-DC MN try to add first E1 Setup in PDU Session Setup/Moidffy Request after call setup.
    uint8_t rxXnPartialResponse               : 1; // Set TRUE when received Partial Success Response in Xn S-Node Addition Request Ack (SVR25B FGR-CC5200 FR1050)
    uint8_t reserved                                   :3;

    VccbE1F1PartialInfo_type e1f1Info[MAX_PARTIAL_INTERFACE];
} VccbDrbPartialInfo_type;
// Partial DRB END

typedef struct
{
    uint32_t ssbFreq;
    uint16_t bandIndiNR;
} frequencyAndBandIndiNR_type;

typedef struct
{
    frequencyAndBandIndiNR_type mR1st;
    frequencyAndBandIndiNR_type mR2nd;
} NrdcAdditionMrReceived_type;

typedef struct
{
    uint16_t cellIdentity;
    timerInfo_type timer;
} saToNsaBorderHoInfo_type;

typedef struct
{
    timerInfo_type timer;
    uint16_t cellIdentity;
    uint32_t mrCarrierFreq;
} timerBasedMrBasedRedirectInfo_type;

typedef struct
{
    uint8_t forcedMobilityCgiReport;
    uint16_t cellIdentity;
    timerInfo_type timer;
} specificSliceForcedHoInfo_type;

typedef struct
{
    uint8_t                 num;
    uint32_t                sstSd[MAX_SPECIFIC_SLICE_INFO_ENTRIES];
} reqSpecificSliceInfo_type;

typedef struct
{
    uint8_t       redCovCnt     : 2;
    uint8_t       redEpsFallCnt : 2;
    uint8_t       redEmFallCnt  : 2;
    uint8_t       redA2Cnt      : 2;
} cslRedirectionInfo_type;  // New in SVR25B

// SVR25A FGR-MC1007 FR790, FGR-MC1027 FR400, FGR-MC3002 FR190
typedef struct
{
    // inter system csl stat range is 0-128(VCCB_MOBILITY_INTER_RAT_STAT_CSL_MAX)
    // intra nr csl stat range is 0-255(VCCB_MOBILITY_INTRA_NR_STAT_CSL_MAX)
    // default value is 0
    uint8_t interSysLteAtt;
    uint8_t interSysLtePrepSucc;
    uint8_t interSysLteSucc;
    uint8_t interSysLteHandoverCancel;
    uint8_t interSysLteRre;

    uint8_t interSysLteAttEpsFallback;
    uint8_t interSysLtePrepSuccEpsFallback;
    uint8_t interSysLteSuccEpsFallback;
    uint8_t interSysLteHandoverCancelEpsFallback;
    uint8_t interSysLteRreEpsFallback;

    uint8_t interSysLteAttEmergencyFallback;
    uint8_t interSysLtePrepSuccEmergencyFallback;
    uint8_t interSysLteSuccEmergencyFallback;
    uint8_t interSysLteHandoverCancelEmergencyFallback;
    uint8_t interSysLteRreEmergencyFallback;

    uint8_t intraNrIntraFreqAtt;
    uint8_t intraNrIntraFreqPrepSucc;
    uint8_t intraNrIntraFreqSucc;
    uint8_t intraNrIntraFreqHandoverCancel;
    uint8_t intraNrIntraFreqRre;

    uint8_t intraNrInterFreqAtt;
    uint8_t intraNrInterFreqPrepSucc;
    uint8_t intraNrInterFreqSucc;
    uint8_t intraNrInterFreqHandoverCancel;
    uint8_t intraNrInterFreqRre;

    // Mobility 2
    uint8_t intraGnbHoAttCnt;                   // New in SVR25B
    uint8_t intraGnbHoPrepCnt;                  // New in SVR25B
    uint8_t intraGnbHoExecCnt;                  // New in SVR25B
    uint8_t intraGnbHoCancelCnt;                // New in SVR25B
    uint8_t intraGnbHoRreCnt;                   // New in SVR25B

    cslRedirectionInfo_type cslRedirection;     // New in SVR25B

    uint8_t interGnbXnHoAttCnt;                 // New in SVR25B
    uint8_t interGnbXnHoPrepCnt;                // New in SVR25B
    uint8_t interGnbXnHoExecCnt;                // New in SVR25B
    uint8_t interGnbXnHoCancelCnt;              // New in SVR25B
    uint8_t interGnbXnHoRreCnt;                 // New in SVR25B

    uint8_t interGnbNgHoAttCnt;                 // New in SVR25B
    uint8_t interGnbNgHoPrepCnt;                // New in SVR25B
    uint8_t interGnbNgHoExecCnt;                // New in SVR25B
    uint8_t interGnbNgHoCancelCnt;              // New in SVR25B
    uint8_t interGnbNgHoRreCnt;                 // New in SVR25B
} vccbCslMobilityInfo_type;

typedef struct
{
    // Mobility KPI  NSA
    uint8_t nsa_intraGnbHoAttCnt;                   // New in SVR25B
    uint8_t nsa_intraGnbHoPrepCnt;                  // New in SVR25B
    uint8_t nsa_intraGnbHoExecCnt;                  // New in SVR25B

    uint8_t nsa_interGnbX2HoAttCnt;                 // New in SVR25B
    uint8_t nsa_interGnbX2HoPrepCnt;                // New in SVR25B
    uint8_t nsa_interGnbX2HoExecCnt;                // New in SVR25B

} vccbCslMobilityInfo_nsa_type;

typedef struct
{
    uint8_t collectOrder;
    uint16_t fiveQi;
    uint8_t attempt;
    uint8_t success;
} drbSetupCsl_type;

#define MAX_BASIC_CALL_STAT_CSL  4
typedef struct
{
    uint8_t collectOrder;
    uint8_t rrcSetup_Attempt;
    uint8_t rrcSetup_Success;
    uint8_t initialContextSetup_Attempt;
    uint8_t initialContextSetup_Success;

    // New in SVR25 start
    uint8_t drbSetupTimeCount;          // New in SVR25B Init: 0xFF, range:0~128
    uint16_t drbSetupTimeTotal;         // New in SVR25B Init: 0xFFFF, range:0~65534
    uint16_t rrcSetupTime;              // New in SVR25B Init: 0xFFFF, range:0~65534
    // New in SVR25 end

    uint8_t initialDrbSetupStatNum;
    uint8_t drbSetupStatNum;
    drbSetupCsl_type initialDrbSetup[MAX_BASIC_CALL_STAT_CSL];
    drbSetupCsl_type drbSetup[MAX_BASIC_CALL_STAT_CSL];

    //New in SVR26A start
    uint8_t setupFailCause5qi1StatNum;                           // New in SVR26a Init: 0x00, range:0~MAX_BASIC_CALL_STAT_CSL
    uint16_t setupFailCause5Qi_1[MAX_BASIC_CALL_STAT_CSL];       // New in SVR26a Init: 0xFFFF, range:0~254
    //New in SVR26A end

} basicCallStatCslInfo_type;

#define MAX_RETAIN_STAT_CSL  4

typedef struct
{
    uint8_t collectOrder;
    uint16_t fiveQi;

    uint8_t drbRelTotal;
    uint8_t gnbInitAbnormal_Active;
    uint8_t gnbInitAbnormal_InActive;
    uint8_t amfInitAbnormal_Active;
    uint8_t amfInitAbnormal_InActive;
} drbRetainCsl_type;

// New in SVR25B start
typedef struct
{
    uint8_t ueRelTotal;                 // Init: 0xFF, Range: 0~128
    uint8_t gnbInitAbnormal_Active;     // Init: 0xFF, Range: 0~128
    uint8_t gnbInitAbnormal_InActive;   // Init: 0xFF, Range: 0~128
    uint8_t amfInitAbnormal_Active;     // Init: 0xFF, Range: 0~128
    uint8_t amfInitAbnormal_InActive;   // Init: 0xFF, Range: 0~128
} ueRetainCsl_type; // New in SVR25B
// New in SVR25B end

#define MAX_ABNORMAL_REL_CAUSE_5QI  5

typedef struct
{
    uint8_t collectOrder;
    uint8_t abnRelCause5qiNum;
    uint8_t reserved;
    uint8_t drbRetainStatNum;
    drbRetainCsl_type drbRetain[MAX_RETAIN_STAT_CSL];

    ueRetainCsl_type  ueRetain; // New in SVR25B

    uint8_t abnRelCause5Qi_1[MAX_ABNORMAL_REL_CAUSE_5QI];    // new in SVR26A - Init: 0xFF, Range: 0-31

} retainStatCslInfo_type;

#define MAX_SCELL_CA_CSL  7
typedef struct
{
    csl_cgi_type cslCgi;
    uint8_t caConfigCnt;
    uint8_t caDeConCnt;
    uint8_t caDeConRes;

    //New in SVR26A start
    uint8_t dlCaConfigVonrCnt;              // Init: 0xFF, Range: 0~128
    uint8_t dlCaDeConfigVonrCnt;            // Init: 0xFF, Range: 0~128
    uint8_t ulCaConfigVonrCnt;              // Init: 0xFF, Range: 0~128
    uint8_t ulCaDeConfigVonrCnt;            // Init: 0xFF, Range: 0~128
    //New in SVR26A end

} sCellCslInfo_type;    // New in SVR25B

typedef struct
{
    uint8_t state;
    uint16_t sCellIdx;
    csl_cgi_type cslCgi;
    uint8_t caConfigCnt;
    uint8_t caDeConCnt;
    uint8_t dlCaConfigVonrCnt;
    uint8_t dlCaDeConfigVonrCnt;
    uint8_t ulCaConfigVonrCnt;
    uint8_t ulCaDeConfigVonrCnt;
    uint8_t caDeConResTemp;
    uint8_t caDeConRes;
    struct timespec lastDeconTime;
} sCellCslInfoInternal_type;

typedef struct
{
    uint16_t sumTimeTotal;
    uint8_t cnt;
} hoInfoCsl_type; // New in SVR25B

typedef struct
{
    hoInfoCsl_type intraGnbHo;
    hoInfoCsl_type intraGnbVonrHo;
    hoInfoCsl_type interGnbXnHo;
    hoInfoCsl_type interGnbXnVonrHo;
    hoInfoCsl_type interGnbNgHo;
    hoInfoCsl_type interGnbNgVonrHo;
    hoInfoCsl_type incomingEuNrHo;
    hoInfoCsl_type incomingEuNrVonrHo;
    hoInfoCsl_type outNrEuVonrHo;
    hoInfoCsl_type outNrEuEpsHo;
} ho2CslInfo_type;  // New in SVR25B

typedef struct
{
  uint8_t reportType; // enumMeasurementReportType
  uint8_t reportPurpose;
} measurementReportInfo_type;

typedef struct
{
    uint8_t state;    // disabled when (currentTime - receivedTime) > MAX[gathering time of PCC/SCC change]
    uint8_t rsrp;     // RRC IE value 
    uint16_t cellIdentity;
    uint32_t seValue;   // SE value * 1000 (0..100000)
                        // INVALID_SE_VALUE * 1000 when inter-gNB cell
                        // if the value > 100000, invalid SE
    struct timespec receivedTime;
} mrCellInfo_type;

typedef enum vomaCallEvent_e
{
    VOMA_callSetup = 0,
    VOMA_drbSetup,
    VOMA_ngHo,
    VOMA_xnHo,
    VOMA_intraDuHo,
    VOMA_interDuHo,
    VOMA_rre,
    VOMA_intraCellHo,
    VOMA_drbRelease,
    VOMA_xnRetrieve,
    VOMA_unknown = 0xFF
} vomaCallEvent_type;

// SVR26A FGR-CC3103 IODT RACS(UE Radio Capability Signaling Optimization)
#define VCCB_INT_RACS_BIGMSG_MBOX_MAX_NUM   2
#define MAX_RACS_HOUR_AUDIT_CHECK_NUM       3

typedef struct {
    uint8_t     usage;
    uint8_t     amfIndex;       // for Only VNMB
    uint16_t    ueCapaIdLength;
    uint8_t     ueCapaID[MAX_UE_CAPA_ID_LEN];
    uint32_t    plmn_longId;
} racsCapaIdItem_type;

typedef struct {
    uint8_t     usage;
    uint8_t     reserved[3];
    uint32_t    length;
    uint8_t     value[MAX_PACKED_UE_CAPA_ALL_RAT_LENGTH];   // (9000 * 16) + 32
} racsCapaBufferItem_type;

typedef struct {
    uint16_t    racsCapaIdListNum;
    uint16_t    reserved;
    racsCapaIdItem_type     racsCapaIdList[MAX_UE_CAPA_ID_CNT];
    racsCapaBufferItem_type racsCapaBufferList[MAX_UE_CAPA_ID_CNT];
} VccbRacsInfo_type;

typedef struct {
    uint32_t            gnbId;
    uint8_t             gnbNum;
} VccbRacsGnbIdInfo_type;

// RACS END

typedef struct callInfo_s
{
    // ----------------------------------------------------------------
    // HAS FIXED SIZE BACKUP
    // Objects below this line are synced separately --- HAS FIXED PART */
    // sync only valid items
    // If you want add items, additional implementation required in ComLibUtility.c:FnVCCB_BackupCallInfo function
    // ---------------------------------------------------------------

    uint8_t usage;  // 0: no_use, 1: use
    uint8_t backupSeqNum_First;
    uint8_t stateCmd;
    uint8_t prevStateCmd;
    uint16_t transactionId;
    uint16_t recentMsgId;  // To discriminate a message for Call Fault
    extCallDbCtl_type extDb;

    enumCallType_type callType;

    enumVccbCallState_type state;
    enumVccbCallState_type prevFnState;
    uint8_t rRCState;     // enumRRCState_type
    uint8_t procForStat;  // enumProcForStat_type

    uint8_t dUinactivityMonitoring;
    uint8_t isEndcVipUe; // FGR-CC3502 VIP UE indication

    uint8_t myThreadId;
    uint8_t locationReporting_flag;  // VCCB_FLAG_OFF, VCCB_FLAG_ON

    uint32_t gnbCuUeId;  // For E1/F1/X2/XN/NG gnbCuUe Ap Id.
    uint32_t callId;     // CPC CP Call Id.
    uint32_t upCallId[MAX_CU_UP_PER_CALL];
    uint32_t auCallId;
    uint64_t ngCallId;
    uint64_t xnCallId;             // target xN AP Id
    uint32_t srcCuCpUeIdInterRATHo;// EN-DC to/from SA HO with same gNB
    time_t stateInitTime;

    vccbCallFlag_type flag;        // used when need flags(setupFlag,releaseFlag,respFlag)
    VccbCallBitFlag_type bitFlag;  // used when just need on/off bit flag

    // According to FR270 of Basic SA Feature, drbId which allocated once can not be reused.
    // So drbId will not be released from the drbIdPool once it is allocated.
    uint32_t drbIdPool;  // Controlled per bits

    ueInfo_type ueInfo;
    ueNrRrcOtherConfig_type ueNrRrcOtherConfig;
    cgi_type nRCGI;
    cgi_type eCGI;
    securityInfo_type security;
    // ngcInfo_type                NGC;            //

    uint16_t gnbNum;
    uint16_t servCellNum;
    uint16_t servCellBand;
    uint16_t servCellIndex;  // 0..31
    uint8_t servCellSsbRsrp; // 0..127, 255

    uint32_t gnbId;

    uint8_t numSRB;
    uint8_t numERAB;
    uint8_t numGNB;
    uint8_t numRelERAB;
    uint8_t numPDUSess;

    uint8_t srb3Idx;
    uint16_t rlfFailF1Cause;   // 23B: F1 Cause in RX F1 RLF Failure for Saving and Duplication
                               // It's valid only when ptCi->rlfHandlingTimer is ON.
    union
    {
        struct
        {
            uint8_t srb3Prohibited_AddDelMeasObj                : 1;
            uint8_t srb3Prohibited_ChangeSelBandFeatureSet      : 1;
            uint8_t srb3Prohibited_TriggeredCellGrpUpdatingByDU : 1;
            uint8_t srb3Phohibited_SuspendByScgFailure          : 1;
            uint8_t rsvd                                        : 4;
        };
        uint8_t srb3Prohibited;
    };

    uint8_t reestablishFlag;

    callSRBInfo_type srbInfo[MAX_SRB_PER_CALL];
    // callERABInfo_type           erabInfo[MAX_ERAB_PER_CALL];  -->> Move to below 'HAS VARIABLE SIZE BACKUP'

    vccbGlobalGnbId_type refusedTargetGnbId[MAX_REFUSED_TARGET_GNB_PER_CALL];
    nbrRefusedFR1CellInfo_type refusedTargetFR1CellsForFR2FR1HO[MAX_REFUSED_TARGET_FR1_CELLS_PER_CALL];

    struct CallAmfInfo_s
    {
        uint8_t needToSetRrcTimeToWaitAmfReloc : 1;
        uint8_t reserved1                      : 7;
        struct AmfReroute_s
        {
            uint16_t amfSetId;  // init NO_REROUTE_AMF_SET_ID(0xFFFF)
        } reroute;
    } amf;

    endPoint_type endPointInfo;
    enumAUPFSelectionMode_type aupfSelectionMode;  // Set in VLIB_InitCallInfo

    scellInfo_type sCell[MAX_SCELL_PER_CALL];
    scellInfo_type sCellDuConfig[MAX_SCELL_PER_CALL];
    caInfo_type caInfo;

    uint8_t qciGrpId;
    uint8_t qciGrpIdPrev;

    uint8_t reserved;

    struct rrcConnStat_s{
        uint8_t callCountFlag               : 1;  // For STAT_UE_NUM_PER_GNB statistic
        uint8_t rrcConnectionCountFlag      : 1;  // For STAT_RRC_CONN_INFO - ConnNoAvg statistic
        uint8_t rrcInactiveCountFlag        : 1;  // For STAT_RRC_CONN_INFO - InactiveNoAvg statistic
        uint8_t vonrEmerCountFlagOfRrcConn  : 1;  // For VONR_EMERGENCY_CONN_INFO - ConnNoAvg statistic
        uint8_t vonrEmerCountFlagOfRrcInact : 1;  // For VONR_EMERGENCY_CONN_INFO - Not Yet Defined.
        uint8_t vonrEmerCallFlag            : 1;  // For VONR_Emergency Call
        uint8_t redCapCountFlag             : 1;  // For RedCap UE
        uint8_t rrcConnectionPowerClassCountFlag : 1;  // For RRC_CONN_INFO_PC - ConnNoAvg statistic

        uint8_t redCapInactiveCountFlag     : 1;  // For RedCap UE for Inactive
        uint8_t reservedBit:7;
        uint8_t reservedByte;

        uint8_t markedPlmnIdxForRrcConnStat;   // Plmn Index value which is previously counted for RRC_CONN 5Qi Statistics
        uint8_t markedPlmnIdxForRrcInactiveStat;
        uint8_t markedPlmnIdxForNonDssUeStat;

        uint16_t markedCellNumForRrcConnStat;  // cellNum which is previously counted for RRC_CONN 5Qi Statistics
        uint16_t markedCellNumForRrcInactiveStat;
        uint16_t markedCellNumForLoggedMdtUeStat;
        uint16_t markedCellNumForNonDssUeStat;
        uint16_t markedCellNumForEnbNonDssUeStat;
        uint16_t markedCellNumForVonrEmerRrcConn;   // cellNum which is previously counted for VONR_EMERGENCY_CONN_INFO
        uint16_t markedCellNumForVonrEmerRrcInact; // cellNum which is previously counted for VONR_EMERGENCY_CONN_INFO (Currently Not Used in 23A)
        uint16_t markedCellNumForULOnlyRoHCRrcConnStat;
        uint16_t markedCellNumForSymmRoHCRrcConnStat;
        uint16_t markedCellNumForPowerClassRrcConnStat;

        uint16_t markedRfspForRrcConnStat;      // Rfsp Value which is previously counted for RRC_CONN Statistics (0 means No RFSP or Not Matched with Yang)
        uint16_t markedRfspForRrcInactiveStat;  // Rfsp Value which is previously counted for RRC_CONN Statistics (0 means No RFSP or Not Matched with Yang)
        uint16_t markedRfspForNonDssUeStat;     // Rfsp Value which is previously counted for RRC_CONN Statistics (0 means No RFSP or Not Matched with Yang)

        Stopwatch_type addProcTime;
        Stopwatch_type rrcEstabProcTime;
        Stopwatch_type ngEstabProcTime;
        Stopwatch_type rrcConnHoldingTime;
        Stopwatch_type rrcInactHoldingTime;
        Stopwatch_type rrcConnInactHoldingTime;
        Stopwatch_type rrcEndcConnHoldingTime;
    }rrcConnStat;

    // struct timespec             initialCtxtSetupReqTime;
    timerInfo_type timer;
    struct CallMultiTimer_s
    {
        timerInfo_type x2;
        timerInfo_type e1;
        timerInfo_type f1;
        timerInfo_type rrc;
        timerInfo_type ng;
        timerInfo_type xn;
        timerInfo_type spec;
    } callMultiTimer;
    timerInfo_type mgapReTriggerTimer;
    timerInfo_type forcedReleaseTimer;
    timerInfo_type scgSuspendResumeTimer;
    timerInfo_type scgSuspendSnRelTimer;        // SVR24B FGR-CC5203 FR63: wait SN release timer
    timerInfo_type secuModeCmpTimer;
    timerInfo_type rlfHandlingTimer;
    timerInfo_type endcFr2MeasTimer;
    timerInfo_type saPriorHOTimer;
    timerInfo_type lbMrTimer;
    timerInfo_type ulDedicatedMsgSegTimer;
    timerInfo_type caModTriggerTimer;
    timerInfo_type dlNasWaitingAckTimer;
    timerInfo_type longCallDetectionTimer;
    timerInfo_type trfBasedHoTimer;
    timerInfo_type redisExpireUpdateTimer;
    timerInfo_type iratLbMrWaitTimer;
    timerInfo_type voNrLbMrWaitTimer;  // SVR24B FGR-LC0712
    timerInfo_type nrppaTimer;         //Dedicated timer to send ECID Response
    timerInfo_type nrppaTimerAoA;      //Dedicated timer to send ECID Response for AoA

    struct timespec periodicLbGuardTimeStamp; // FGR-LC0703 FR220

    struct
    {
        // For RRCInactive and UserInactivity commonly
        uint8_t ue;
        uint8_t ueReported;
    } activityStatus;

    struct CallUserInactivity_s  // SVR18.3 FGR-CC0501 User Inactivity Timer Control
    {
        timerInfo_type sigInactivityTimer;
        timerInfo_type releaseTimer;
        enumUserInactivityState_type ueInactivityState;
        uint8_t activityNotificationLevel;
        uint8_t desiredNotiLevelChanged;
        uint8_t desiredActivityNotificationLevel;
        uint8_t rfspBasedControlFlag;
        uint16_t rfspVal;
        uint8_t isReleaseTimerTimeout;
        uint8_t featureEnabled;
        uint8_t dataInactivityPerCellOnOff; // Value is decided at VLIB_InitCallInfo()
        enumActivityStatus_type nrdcSN_UELevel_InactivityStatus;  // used in MN only
        enumActivityStatus_type ueLevelActivityReportSentToMN;    // used in NRDC-SN only
    } CallUserInactivity;

    uint8_t RelFlag;
    uint8_t RelCtxtKeptInd;
    uint8_t traceVoNR;
    uint8_t simCallFlag;

    // MdsAddr_Type                s1LoadBalanceAddr;

    callENBInfo_type eNBInfo;

    uint8_t nedcScgFailCauseInfo;  // enumNeDcScgFailCauseInfo_type, statistics index // NEDC_SCG_FAILURE_20C

    // ****** UE Capability Configurations **********
    ueCapaEnquiryInfo_type ueCapaEnquiry;

    ueCapabilitiesRATcontainer_type ueContainerNR;   /* moved from CgConfigInfo_type for SA and NSA */
    ueCapabilitiesRATcontainer_type ueContainerMRDC; /* moved from CgConfigInfo_type for SA and NSA */
    ueCapabilitiesRATcontainer_type ueContainerEUTRA;

    extUeCapaInfo_type ueContainerNR_Ext;
    extUeCapaInfo_type ueContainerMRDC_Ext;
    extUeCapaInfo_type ueContainerEUTRA_Ext;

    extUeCapaInfo_type ulRrcSegment;
    ueCapaID_type      ueCapaID;    // SVR26A FGR-CC3103 IODT RACS(UE Radio Capability Signaling Optimization)

    // for EN-DC
    uint8_t pDCPatSgNB;  // MN_Terminated, SN_Terminated
    uint8_t bearerType;  // MCG_Bearer, SCG_Bearer, Split_Bearer
    uint8_t cgConfigInfoFlag;
    uint8_t cellGroupConfigFullFlag;

    CgConfigInfo_type cgConfigInfo;  // CU to DU, ENB to gNB
    CellGroupConfig_Full_type cellGroupConfig_Full;

    rscCoordInfo_Bkp_type rscCoordBkp;

    measurementsConfiguration_type measurementsConfiguration;
    measurementsConfigShared_type measurementsConfigShared;
    saMeasStateInfo_type saMeas;
    nsaMeasStateInfo_type nsaMeas;
    needForGapNrUeData_type needForGapNrUeData;
    UlGapFr2Config_type ulGapFr2ConfigDu;
    UlGapFr2Config_type ulGapFr2ConfigUe;

    TrafficMonitoringCfg_type trafficMonitoringCfg;  // [FGR-CC8001] DL PDCP traffic status monitoring control (NR)
    TrafficMonitoringState_type trafficMonitoringState;

    union
    {
        callMrQueInfo_type    saHoMrQueueInfo;
        callMrQueInfoNsa_type nsaHoMrQueueInfo;
    };

    ueHistoryInfo_type ueHistory;
    uint8_t scgFailureFlag;
    uint8_t scgSuspendStateForMeas;
    uint8_t scgFailCauseInfo;                      // enumScgFailCauseInfo_type
    uint8_t scgSuspendState;                       // VCCB_FLAG_OFF, VCCB_FLAG_ON
    enumScgFailureRelease_type scgFailureRelease;  // enumScgFailureRelease_type
    scgFailAttSuccStats_type scgFailAttSuccStats;
    sCellCslInfoInternal_type sCellCsl[MAX_SCELL_CA_CSL];      // New in SVR25B
    uint8_t x2ModReqS1UTunnelStatus;
    uint8_t sCellCslRelCauseByCuTrigger;
    uint8_t emergencyRequestedForCsl;      // For CSL. Iniitialized as 0xFF at Only VLIB_InitCallInfo()
    uint8_t vonrRequestedForCsl;           // For CSL. Iniitialized as 0xFF at Only VLIB_InitCallInfo()

    // FGR-TA0201 Call Summary Logs
    struct Csl_s
    {
        CslConnectInfo_type connectInfo;  // [EN-DC] Call information, [SA] Connection Information Category.
                                          // (X2Addition/RRRConn/Xn,Ng Ho/Inter-gNB RRE)
        uint8_t useNextInitialMeas;       // [EN-DC] Mobility          [SA] Neighbor   Information Category.
        cslMeasInfo_type cslMeasInitialInfo;
        cslMeasInfo_type cslMeasLastInfo;
        enumCslCalEvent_type cslEvent;  // [EN-DC] Call information, [SA] Disconnection Information Category.
        uint8_t cslHoInterruptedByFail;
        uint8_t cslErabPduDrbAllocIdx;
        scgFailureHistoryInfo_type scgFailureHistory;  //[EN-DC] SCG Failure Information (UE-Detected) Category
        cslRreInfo_type cslRreInfo;
        vccbTimeInfo_type cslResumeTime;
        vccbCslMobilityInfo_type cslMobilityInfo; // SVR25A FGR-MC1007 FR790

        vccbCslMobilityInfo_nsa_type cslMobilityInfo_nsa; // SVR25B NSA Mobility kpi CSL

        retainStatCslInfo_type retainStatInfo;
        basicCallStatCslInfo_type basicCallStatInfo;

        sCellCslInfo_type sCellConfigInfo[MAX_SCELL_CA_CSL];      // New in SVR25B
        ho2CslInfo_type hoInfo;                 // New in SVR25B

    } cslInfo;

    struct QciCount_s
    {
        // FGR-CC5000 FR3590
        struct QciAttemptSuccessData_s
        {
            uint16_t qci;
            uint8_t attempt;
            uint8_t success;
        } QciAttemptSuccessData[MAX_QCI_HISTORY_STORING_CAPACITY];

        // FGR-CC5005 FR40
        struct LatestReleasedQci_s
        {
            uint16_t qci;
            uint8_t gNBInitiatedErabRelease;
            uint8_t gNBInitiatedAbnormalErabRelease;
            uint8_t gNBInitiatedAbnormalErabReleaseWithActiveBearer;
            uint8_t MeNBInitiatedErabRelease;
            uint8_t MeNBInitiatedAbnormalErabRelease;
            uint8_t MeNBInitiatedAbnormalErabReleaseWithActiveBearer;
        } LatestReleasedQci[MAX_QCI_HISTORY_STORING_CAPACITY];
    } qciCount;

    /********* BEGINNING of Trace/MDT related section ********/
    /** FGR-TA0103 Cell traffic trace                      **/
    /** FGR-TA0104 UE Throughput and RF Trace              **/
    /** FGR-SO1101 NR Minimization of Drive Tests (NR MDT) **/
    /********************************************************/
    struct Trace_s
    {
        struct TraceRecordingSession_s
        {
            uint32_t duUEid; // Ue Id delivered in F1TraceStart, 0xFFFFFFFFF otherwise
            uint16_t traceRecordingSessionReference;  // TRSR range: 0..65535 assigned for Cell Traffic Trace
            uint16_t traceCellNum;
            uint8_t traceStartF1DeliveryStatus; // TRUE/FALSE indicate if F1TraceStart has been already delivered to DU (Ue Throughput and MDT)
            uint8_t traceStartE1DeliveryStatus; // TRUE/FALSE indicate if E1TraceStart has been already delivered to UP (Ue Throughput and MDT)
            uint8_t cttForTraceDelivered; // TRUE if CellTrafficTrace message was delivered earlier that Conn state, FALSE otherwise
            uint16_t trsrAllocIdx; // index in Cell array, if TRSR not allocated set to MAX_UE_PER_CELL_TRACE_SESSION
            uint16_t msgSeqNum; // number of already sent trace msg
            enumUsage_type usage;  // CI_no_use, CI_use
            struct
            {
                uint8_t cellTraceFlag    : 1;  // Whether call is selected for Cell Traffic Trace
                uint8_t immediateMdtFlag : 1;  // Whether call is selected for Immediate MDT Trace
                uint8_t loggedMdtFlag    : 1;  // Whether call is selected for Logged MDT Trace
                uint8_t rlfOrRcefFlag    : 1;  // Whether call has RLF/RCEF MDT retrieval
                uint8_t ueThroughputAndRfTraceFlag : 1;
            } jobStatus;
        } session[MAX_TRACE_SESSION_ENTRY];

        uint8_t tracePLMNavailable;
        uint8_t traceActPostponed; // ON/OFF Indicates if trace activation shall be postponed due context not being setuped yet in up/du
        uint16_t isHoRrcReconfCmpleFlag;
        enumTraceRfspSpidStatus traceRfspSpidAllowed;

        // [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
        struct MDT_s
        {
            struct
            {
                uint8_t ueActFlag   : 1;  // ON/OFF Indicates if M1 measurement is active
                uint8_t ueActFlagM6 : 1;  // ON/OFF Indicates if M1 measurement is active
                uint8_t duActFlag   : 1;  // ON/OFF Indicates if DU related (M2,M5,M6 or M7) measurement is active
                uint8_t upActFlag   : 1;  // ON/OFF Indicates if UP related (M4 or M6) measurement is active
            } mdtStatus;
            struct
            {
                uint8_t rre : 1;
            } failure_ind;
            enumMdtReportingTrigger_type m1ReportingTrigger;  // Current state of reporting trigger
            uint8_t isPeriodicIRatByA2Active;
            uint8_t managementMdtAllowed;         // TRUE/FALSE 'Management Based MDT Allowed'   IE (NSA only)
            uint8_t updateConfigFlag;       // ON/OFF set if Logged MDT configuration should be send do UE
            uint8_t mdtPlmnCount;                 // number of elements -> if 0 UE consent not available
            plmnId_type
                managementMdtPlmnList[MAX_NUM_MDT_PLMNS];  // 'Management Based MDT PLMN List' IE from eNB/AMF/peer gNB
        } mdtInfo;

    } managementTraceInfo;

    SignalingTrace_type signalingTraceInfo;
    MdtRecordM6_UL_PDCP_Delay_type m6UlPdcpDelay;
    enumTraceMdtReportingStatusType traceReportingState;
    timerInfo_type traceTimer;
    enumTraceDbStopTrigger dbTriggeredTraceDeactType; // type of trace to deactivation triggered by db parameter change
    uint8_t mdtIsPeriodicByA2Active;   // TRUE/FALSE Indicates whehter A2 was already received
    uint8_t specificM1InstallOngoing;  // ON/OFF ongoing Reconfiguration procedure including dedicated M1 measurement configuration
#ifdef __CNF__
    uint16_t selectedCtp;
#endif
    struct collectorTraceInfo_s
    {
        uint8_t collectBothMeasLogAndRlf;     // ON/OFF set if meas logs and rlf logs can be retrieved together.
        uint8_t mdtLogMeasAvailableFlag;      // ON/OFF set if UE indicate logged MDT data availability
        uint8_t mdtConnEstFailAvailableFlag;  // ON/OFF set if UE indicate RCEF MDT data availability
        uint8_t mdtRlfAvailableFlag;          // ON/OFF set if UE indicate RLF MDT data availability
    } collectorTraceInfo;

    /********* END of Trace/MDT related section ********/

    cuCallDrxConfig_type drxCuInfo;

    uint8_t noCgConfigFlag;
    uint8_t noRabInX2Resp;
    uint8_t integrityFailCount;

    uint8_t mgapReTriggerCount;

    /* for debug Call Trace */
    uint8_t debugTrace;  // traceOn/Off

    uint8_t e1DataUsageReportCnt;

    duSelectionRelatedData_type duSelectionRelatedData;
    duSelectionRelatedData_type backupDuSelectionRelatedData;

    redirectionInfo_type redirectionInfo;

    ueDlNasAckInfo_type dlNasAckInfo;

    bool isUlPathSwitchEnabled;  // NRDC only
    uint8_t xnStatusTransferEnhancementOnOff;
    uint8_t supportRreDuringUeCapaEnquiry;

    UlPathControl_type ulPathControl;
    enumUlPdcpPathDataStallFunc isDataStallPreventionTriggerReceived;
    timerInfo_type dddsIndicationTimer;
    timerInfo_type f1AccessSuccessRachTimer;
    enumHighLatencyIndication HighLatencyIndication;
    bool changeTriggeredByE1PrivateMessage;

    anrUeInfo_type anrInfo;
    redCapUeInfo_type redCapUeInfo;

    ho_guami_type servedGuami;
    ho_guami_type gNBSelectedGuami;
    uint8_t gNBSelectedGumaiFlag;

    union
    {
        struct
        {
            callPDUSessInfo_type pduSess[MAX_PDU_SESS_PER_CALL];
            callDRBInfo_type drb[MAX_DRB_PER_SA_CALL];
            qosFlowInfo_type qosFlow[MAX_QOS_FLOW_PER_CALL];  // 8 PDU * 8 DRB * 1 QOS case
        };
        callERABInfo_type erabInfo[MAX_ERAB_PER_CALL];
    };

    //////////////////////////////////////////////////////////////////////////////////////////////////
    enumMrdcType_type prevSelectedMrdcType;    // MRDC_NEDC, MRDC_NRDC
    enumMrdcType_type selectedMrdcType;        // MRDC_NEDC, MRDC_NRDC
    uint8_t snAddFailCntWithSelectedMrdcType;  // TODO
    uint8_t blindModeSNAddReTrialCnt;
    mrdcInfo_type mrdcInfo;  // NEDC, the mrdcInfo should be memory pool scheme rather than structural variable to
                             // save memory size in the future.
    NrdcSnRestrictedGnbsByOvld_type restrictedGnbsforNrdcSn;
    NrdcAddCacRejectedFreq_type nrdcAddCacRejectedFreq;
    NrdcUlTrafficMonitor_type nrdcUlTrafficMonitorCtx;
    bool isNrdcDisabledByCpcOvld;  // if this para is true, NR-DC Addition procedure will be prohibited until call
                                   // context is kept.
    struct nrdc2nrcaLB_type
    {  // FGR-CC5200:FR1010
        uint8_t needRefresh : 1, needMeasReconfig : 1;
        uint8_t noOfEntries;
        uint32_t removedMeasFreq[MAX_NR_OF_OBJECT_ID];
    } nrdc2nrcaLBCtx;

    NrdcAdditionMrReceived_type nrdcAddA4MrReceived;
    bool isNrdcProhibitedByLtmHo; // nrdc/ca and ltm ho shall be performed exclusively.
    //////////////////////////////////////////////////////////////////////////////////////////////////

    // this is to save the information of F1_Private message from DU
    union
    {
        struct
        {
            uint32_t ulTrafficRptforNrdcDetected : 1,
                     ulTrafficRptForIratPccDetected: 1,
                     intraBandUlCaTriggered : 1,
                     forcedMobilityMode : 2,
                     ulstatusMobilityReason : 2,
                     ueSpeedIndicationReceived : 1,
                     ueSpeedIndication : 2, // enumUeSpeed_type
                     reserved : 22;
        };
        uint32_t value;
    } f1SamsungPrivateMessageInfo;

    uint8_t isULOnlyRoHCCall;  // true/false - true for atleast on erab with ulRohc ON else FALSE
    uint8_t isSymmRoHCCall;  // true/false - true for at least one drb with Symmetric Rohc else FALSE
    uint8_t dssCauseRelease: 1;   // set in case of RRC Release caused by failed validation of DSS
    uint16_t queuedMsgCount;

    uint16_t sCellCountForOverheating;
    OverheatingAssistance_type overheatingAssistance;
    PowerSavingAssistance_type preferenceConfigForPowersaving;
    UlGapFR2PreferenceAssistance_type ulGapFR2PreferenceAssistance;

    struct
    {
        enumNrDcScgFailureCause_type failType;
        enumScgSuspendResumeEvent_type event;
        enumScgSuspendResumeEvent_type prevEvent;      // SVR24B FR52 - save previous event
        uint8_t failAction;
        uint8_t scgMrIncluded                    : 1;
        uint8_t A4Configured                     : 1;
        uint8_t ueSignatureFlag                  : 1;
        uint8_t allowSNAdditionUECustomSignature : 1;  // default : ON
        uint8_t snRelFlag                        : 1;
        uint8_t preserveFlag                     : 1;
        uint8_t reserved                         : 2;
        uint16_t targetPsCellNum;
        uint16_t targetPsCellBand;
    } nrdcScgFailureInfo;

    ltmUeInfo_type ltmUeInfo;
    conditionalHandoverInfo_type condHoInfo;
    int8_t pMaxFR1;  // DU to CU, gNB to ENB, INTEGER (-30..33)
    uint8_t caOverloadedStatus;

    uint8_t sliceAwareLbDecisionCount; //SVR23B FGR-LC0710
    uplinkStatusTriggeredMobilityInfo_type ustmInfo;

    uint8_t ueInfoReqFlag; // [FGS-SF0505] NR RACH Parameter Optimization
    saToNsaBorderHoInfo_type saToNsaBorderHoInfo;
    timerBasedMrBasedRedirectInfo_type timerBasedMrBasedRedirectInfo;
    specificSliceForcedHoInfo_type specificSliceForcedHoInfo;
    reqSpecificSliceInfo_type reqSpecificSliceInfoForHo; // requested specific slice info at InitialContextSetupRequest, PDUSessionSetup/ModifyRequest

    // for Multi-Carrier Operational FGR-CC5500 (PCC)
    PccData_type pccData;
    mrCellInfo_type mrCellInfo[MAX_TSM_MR_CELL]; // FGR-CC5500 and FGR-RC0100
    uint8_t intraBandENDC_support;  // FGR-CC5501

    // FGR-TA0601 (VOMA)
    struct vomaInfo_s
    {
        bool vomaAllowed;
        bool includeCallInfo;
        bool delayE1start;
        uint8_t e1ModCnt;
        vomaCallEvent_type vomaEvent;
        uint8_t initTime[VOMA_INIT_TIME_LEN];
        uint8_t isHO;
    } vomaInfo;

    sliceAwareUeInfo_type sliceAwareInfo;
    // ----------------------------------------------------------------
    // ||  Please put the variables that need backup above
    // ----------------------------------------------------------------
    // ----------------------------------------------------------------
    // HAS VARIABLE SIZE BACKUP
    // Objects below this line are synced separately --- HAS VARIABLE PART */
    // sync only valid items
    // If you want add items, additional implementation required in ComLibUtility.c:FnVCCB_BackupCallInfo function
    // ---------------------------------------------------------------
    hoRestrictInfoCompressed_type hoRestrict;
    uint8_t backupSeqNum_last;
    locRptInfo_type locRpt;

    // ----------------------------------------------------------------
    // NON BACKUP PART
    // Objects below this line are not replicated in HAS
    // hoInfo is a border mark
    // If you want to add more non-replicatable fields do it AFTER hoInfo
    // ----------------------------------------------------------------

    causeInfo_type cause;
    handoverInfo_type hoInfo;
    saReportCgiHandoverInfo_type reportCgiHoInfo;
    callGNBInfo_type gnbInfo[MAX_GNB_PER_CALL];
    modificationProcedure_type modProcInfo;
    rscCoordInfo_type rscCoord;
    ranPagingInfo_type ranPagingInfo;
    mro_type mroInfo;
    rlfReport_type rlfReportInfo;
    interMnHoFinalize_type finalizeInterMnHo;
    measurementsProcedure_type measurementsProcedure;
    nasInfo_type nasInfo;          /* For Piggyback NAS Info */
    nasInfo_type nasTransportInfo; /* For DL,UL NAS Info */
    msgContainer_type cellGroupConfig;  // DU to CU, gNB to ENB
    f1UeContextInfo_type f1Info;

    saPrevDbInfo_type  saPrevInfo;
    nsaPrevDbInfo_type nsaPrevInfo;
    saForcedHoRestrictionInfo_type forcedHO;
    ho_failCell_list_type hoFailCellList;
    cho_block_list_type CHOBlockList;
    ltm_block_list_type ltmBlockList;

    vccbStat_type stat;
    retainStatInfo_type retainStat;
    retainStatInfo_type retainStatOfVonrEmer;
    callSRBInfo_type *ptSi;
    callERABInfo_type *ptTempRi;  // do not use db

    upmCallInfo_type upmInfo;

    enumPriorActionDuringSNInitSgNBMod_type queuedActionDuringSNInitSgNBMod;
    enqueuedAction actionQueue[ACTION_QUEUE_SIZE];
    uint16_t saveHoOrRedirectMsgId;     // SVR25B FGR-SV0201

    struct
    {
        uint8_t qRelDuringHoAction;     // enumRelDuringHoPriorAction_type - for queued Message During Handover.
        uint8_t qMrAction;              // enumMeasReportPriorAction_type  - for queued MR.
        uint16_t qRelType;              // for queued MR
        uint16_t qTargetNbrIdx;         // for queued MR
        uint16_t qTargetCellNum;        // for queued MR
        uint16_t qTargetCellBand;       // for queued MR
        cgi_type qTargetNbrGnbCgi;      // for queued MR
        uint8_t measResult2NRType;      // enumCandidateCellInfoList_type
        uint16_t measResultList2NRSize; // size of measResultList2NRPacked
        uint16_t qMsgId;                // msgId queued action
        uint16_t qRedirectionMsgId;     // msgId which triggered redirection
        uint16_t qHoFailureMsgId;       // msgId caused HO failure
    } qInfo;

    uint8_t transactionType;
    uint8_t synchInd;
    uint8_t maxRetransInd;
    uint8_t isWrongAppUeId;
    uint32_t drbIdsToRelease;  // bitmap

    // Used when the DRB ID is reused.
    // scenario 1) SA HandIn -> DRB ID Succession(ON)
    uint32_t drbIdsReuse;  // use the bitmap. Bit#0 (drbId 1) .. Bit#31 (drbId 32)

    timeStampInfo_type dbgTimeStamp;

    // full configuration
    fullConfiguration_type fullConfiguration;

    neDcPsCellInfo_type psCellInfo, recvPsCell;  // NEDC_SCG_FAILURE_20C
    uint8_t invalidLocInfoSN;                    // NEDC_SCG_FAILURE_20C

    uint8_t isNrPpaContextValid;
    NrPpaContext_type NrPpaContext;

    NrDlTdoaContext_type nrDlTdoaContext;

    uint16_t recentRcvdMsgEndPointIdx;

    /*NRDC Key Management*/
    uint64_t SNgNodeGnbIdNotSupportSecurityAlgo[MAX_REFUSED_TARGET_GNB_PER_CALL];  // Set to TRUE, if SN do not support
                                                                                   // required Algo;Applicable to one SN
                                                                                   // Node only
    uint8_t newSecurityKeyChangeIndSN;  // Set to TRUE after Intra Cell HO if NRDC is active
    uint8_t needBackupAfterStateAll;

    uint8_t nrdcScgFailCauseInfo;  // NRDC_SCG_FAILURE_21D
    NrdcScgBlockListInfo_type blockListInfo;

    int8_t caProfileIdx;  // FGR-LC0702 IMC

    // for Multi-Carrier Operational FGR-CC5500 (SCC)
    SccData_type sccData;
    PrevSccData_type prevSccData;

    mrsInfo_type mrsInfo;
    prevMrsInfo_type prevMrsInfo;

    servingCellMeasInitialInfo_type servingCellMeasInitialInfo;

    ueMeasForSon_type ueMeasForSon;  // FGS-SF0701

    cacTriggeredRedirectionInfo_type cacTriggeredRedirInfo;

    NRCANbrCellAutoConfig_type NRCANbrCellAutoConfig;

    loadBasedNrdcScgBandSelection_type loadBasedNrdcScgBandSelectInfo;
    long fastAccBoundaryTime;    // unit:msec, SVR26A:FGR-LC0705:FR20

    enumTrace_type traceType;

    uint8_t selectableUpsOverloadFlag;

    // FGR-CC5000 Basic Operation for EN-DC
    uint32_t unavailableCellIdAddReqFail; // FR:2810: EndcAddReject_SNCellUnavailable counter
    struct {
        uint32_t arfcn; // NR ARFCN of rejected cell
        uint8_t  spidFlag; // SgNBAddition reject due to spid or other reason
    } invalidCellSgNBAddReject; // FR:3130: Counter for SgNBAddition reject before SPCell selection
    SpCellSelFailStats_type spCellSelFailStats;
    enumStatEndcAddDetailedCpFail_type endcAddCpFailDetailCause; // FR:TBD Detailed cause of EndcAddCpFail scenario

    // FGR-LC0703 (FR33) - Check if the SALB has been performed only once since the UE access or Hand-In
    uint8_t saLbHoExecuted;

    //SamsungExpectedThroughputList
    SamsungExpectedTPList_type samsungExpectedTPList;
    uint8_t samsungExpectedTPListFlag;

    sliceAwareLb_type sliceAwareLbInfo; // SVF23B FGR-LC0710
    onDemandHoInfo_type onDemandInfo;
    VccbDrbPartialInfo_type drbPartialInfo; // No Need Backup

    // PH-Info and ServCellList from DU
    uint8_t servCellInfoListMCG_DUFlag;
    uint8_t phInfoListMCG_DUFlag;
    uint8_t servCellInfoListSCG_DUFlag;
    uint8_t phInfoListSCG_DUFlag;

    ServCellInfoListDU_type servCellInfoDuMcgList;
    PHTypeListDU_type phInfoDuMcgList;
    ServCellInfoListDU_type servCellInfoDuScgList;
    PHTypeListDU_type phInfoDuScgList;

    measurementReportInfo_type mrInfo;

#ifdef IPC_TEST
    struct
    {
        struct
        {
            uint8_t mcg_used; // 1 : used, 0 : not used
            uint8_t scg_used; // 1 : used, 0 : not used

            uint8_t mcg_dl_tx_stop; // 1 : stop, 0 : resume or no action
            uint8_t scg_dl_tx_stop; // 1 : stop, 0 : resume or no action

            union {
                struct {
                    uint8_t skip_init_event_recover_reest:1;  // cancel to conn ..
                    uint8_t skip_checker_event_recover_reest:1; // cancel to conn ..
                    uint8_t reserved:6;
                };
                uint8_t skip_event_recover_reest; // 1 ~ : use union bits, 0: no action
            };

            uint8_t up_recover_reest; // 2 : reest, 1 : recover, 0: no action
            uint8_t rrc_recover_reest; // 2 : reest, 1 : recover, 0: no action

            transportLayerInfo_type f1uUlInfo_mcg;
            transportLayerInfo_type f1uUlInfo_scg;

        } drb[MAX_DRB_ID_PER_CALL+1]; // DRB Id, 1 ~ 32 is used

        bool isSendtoVNMB;
        uint16_t endPointXnIdx;
        uint64_t xnUeId;
        bool rxSecurityFailure;
        bool pendingLtmReleaseInRrcReconfig;
    } checker;
#endif

    // ----------------------------------------------------------------
    // Please put the variables that do not require backup here
    // If you need backup, please put the variable before HAS VARIABLE SIZE BACKUP.
    // ----------------------------------------------------------------

#ifdef VCCB_IPC_TEST
    uint8_t reqCountOfPduForCheck;        // Increase count when AMF request setup/modify/release of PDU Session. (Include Release)
#endif
    uint8_t initialContextSetupRequestPresentFlag;  // FGR-CC1106 FR360

    VccbAiCallContext_type  aiCtx;      // per UE context for AI inference

} callInfo_type;

#ifdef __CNF__
typedef struct CompressedCallInfo_s
{
    char data[VCCB_LZ4_COMP_MAX_SIZE];
} CompressedCallInfo_type;
#endif

/**
 * brief
 */

typedef struct
{
    uint16_t timerName;    // Timer id
    uint16_t startCount;   // How many times this timer was started
    uint16_t cancelCount;  // How many times this timer was cancelled
    uint16_t tmoutCount;   // How many times this timer timed-out, and it was handled correctly

    uint32_t minElapseTime;  // Minimum running time in millisecond
    uint32_t maxElapseTime;  // Maximum running time in millisecond
    uint32_t totElapseTime;  // Total running time in millisecond
} vccbTimerStatInfo_type;

typedef struct
{
    // Includes information of statistics for each timer family
    vccbTimerStatInfo_type rrcTmInfo[VCCB_TimerStat_NRRRC_MAX];
    vccbTimerStatInfo_type x2TmInfo[VCCB_TimerStat_X2_MAX];
    vccbTimerStatInfo_type internalTmInfo[VCCB_TimerStat_INTERNAL_MAX];
    vccbTimerStatInfo_type bearerTmInfo[VCCB_TimerStat_BEARER_MAX];
    vccbTimerStatInfo_type ueTmInfo[VCCB_TimerStat_UE_MAX];
    vccbTimerStatInfo_type ngTmInfo[VCCB_TimerStat_NG_MAX];
    vccbTimerStatInfo_type xnTmInfo[VCCB_TimerStat_XN_MAX];
} vccbTimerStat_type;

typedef struct
{
    uint16_t bufferName;

    uint16_t allocCount;

    uint32_t minBufferSize;  // Minimum buffer size
    uint32_t maxBufferSize;  // Maximum buffer size
    uint32_t totBufferSize;  // Total   buffer size
    // uint32_t            avgBufferSize;        // Average buffer size
} vccbMemoryUsageInfo_type;

typedef struct
{
    vccbMemoryUsageInfo_type rrcUsageInfo;
    vccbMemoryUsageInfo_type f1UsageInfo;
    vccbMemoryUsageInfo_type x2UsageInfo;
    //    vccbMemoryUsageInfo_type   e1UsageInfo;
    vccbMemoryUsageInfo_type ueCapaInfo;
    vccbMemoryUsageInfo_type cgConfigInfo;                    // du to cu
    vccbMemoryUsageInfo_type callInfo[VCCB_CALL_THREAD_NUM];  // # of callThread
} vccbMemoryUsage_type;

/**
 * @brief gnb service type
 */
typedef struct
{
    uint16_t gnbNum;    /**< gnbNum */
    uint16_t reserved;  /**< reserved filed to delete */
    uint16_t nextIndex; /**< next index */
} gnbService_type;

typedef struct
{
    ConfStatus status; /**< EQUIP/N_EQUIP */
    uint32_t gnbId;
} gnbIdFromNum_type;

/**
 * @brief gNB num information
 */
typedef struct
{
    uint32_t assignedCount;                           /**< assigned gnb count */
    uint16_t headOffset;                              /**< head offset */
    gnbService_type svc[MAX_GNB_CU_CP_FUNCTION_PER_SYS];             /**< gnb service information */
    gnbIdFromNum_type gnbIdFromNum[MAX_GNB_CU_CP_FUNCTION_PER_SYS];  // array index is gnbNum
} gnbNumInfo_type;

typedef struct stateFnTable_s
{
    char name[MAX_LEN_OF_STATE_NAME];
    int16_t (*func)(callInfo_type *, message_type *, msgUnpack_type *);
} stateFnTable_type;

typedef struct
{
    uint8_t usedCellCount;
    uint16_t usedCellNum;
} pcidInfo_type;

#ifdef __CNF__
typedef struct
{
    uint32_t callId;
    int32_t distCode;
    enumBackupType_type backupType;
    uint8_t callThreadId;
    int bufferIndex;
    int len;
    enumVccbCallState_type state;
} extDbCallBackupQueueNode_type;

typedef struct
{
    redis_data_type dataType;
    uint32_t targetIdx;
    char *buff;
    int buffSize;
    int byString;
    int32_t startScore;  // for ZRANGEBYSCORE
    int32_t endScore;    // for ZRANGEBYSCORE
} redis_command_parameter_type;
#endif

typedef union
{
    union
    {
        msgCslCuCpNsa_type msgNsaCslDataNoti;
        msgCslCuCpSa_type msgSaCslDataNoti;
        msgTraceDataNoti_type msgTraceDataNoti;
        msgTraceStatus_type msgTraceStatus;
        msgCellCbrsCarrierMrCountReport_type cellCbrsCarrierMrCountReport;
        msgInternalUeCapaIDUpdate_type  internalUeCapaIDUpdateReq;      // Call Thread -> Racs Thread
        msgUeCapaInfo_type              msgUeCapaInfo;                  // Racs Thread -> VNMB
        msgUeCapaIDAudit_type           msgUeCapaIDAudit;               // Racs Thread -> VNMB
    } in;

    union
    {
        X2_SgNBAdditionRequestAcknowledge_type sgNBAdditionRequestAcknowledge;
        X2_SgNBAdditionRequestReject_type sgNBAdditionRequestReject;
        X2_SgNBReleaseRequestAcknowledge_type sgNBReleaseRequestAcknowledge;
        X2_SgNBReleaseRequestReject_type sgNBReleaseRequestReject;
        X2_SgNBReleaseRequired_type sgNBReleaseRequired;
        X2_SgNBModificationRequestAcknowledge_type sgNBModificationRequestAcknowledge;
        X2_SgNBModificationRequestReject_type sgNBModificationRequestReject;
        X2_SgNBModificationRequired_type sgNBModificationRequired;
        X2_SgNBChangeRequired_type sgNBChangeRequired;
        X2_SgNBActivityNotification_type sgNBActivityNotification;
        X2_SecondaryRATDataUsageReport_type secondaryRATDataUsageReport;
        X2_SNStatusTransfer_type sNStatusTransfer;
        X2_CellTrafficTrace_type cellTrafficTrace;
        X2_PrivateMessage_type privateMessage;
    } x2ap;

    union
    {
        F1_UEContextSetupRequestBuffer uEContextSetupRequest;
        F1_UEContextModificationRequestBuffer uEContextModificationRequest;
        F1_UEContextModificationConfirmBuffer uEContextModificationConfirmBuffer;
        F1_TraceStartBuffer traceStartRequest;
        F1_DeactivateTraceBuffer deactivateTraceRequest;
        F1_E_CIDMeasurementInitiationRequestBuffer ECIDMeasurementInitiationRequestBuffer;
    } f1ap;

    union
    {
        E1_BearerContextSetupRequestBuffer bearerContextSetupRequest;
        E1_BearerContextModificationRequestBuffer bearerContextModificationRequest;
        E1_BearerContextReleaseCommandBuffer bearerContextReleaseCommand;
        E1_BearerContextModificationConfirmBuffer bearerContextModificationConfirm;
        E1_ErrorIndicationBuffer errorIndication;
        E1_TraceStartBuffer traceStartRequest;
        E1_DeactivateTraceBuffer deactivateTraceRequest;
    } e1ap;

    union
    {
        NG_InitialUEMessageAllAmf_type initialUEMessage;
        NG_UplinkNASTransportAllAmf_type uplinkNASTransport;
        NG_NASNonDeliveryIndicationAllAmf_type nasNonDeliveryInd;
        NG_UECapabilityInfoIndicationAllAmf_type ueCapaInfoInd;
        NG_UERadioCapabilityCheckResponseAllAmf_type ueCapaCheckResponse;
        NG_InitialContextSetupResponseAllAmf_type initialCtxtSetupResponse;
        NG_InitialContextSetupFailureAllAmf_type initialCtxtSetupFailure;
        NG_PDUSessionResourceSetupResponse_type pduSessionSetupResponse;
        NG_PDUSessionResourceReleaseResponse_type pduSessionReleaseResponse;
        NG_PDUSessionResourceModifyResponse_type pduSessionModifyResponse;
        NG_PDUSessionResourceModifyIndication_type pduSessionModifyInd;
        NG_UEContextReleaseRequestAllAmf_type ueContextReleaseReq;
        NG_UEContextReleaseCompleteAllAmf_type ueContextReleaseComplete;
        NG_UEContextModificationResponseAllAmf_type ueContextModResponse;
        NG_UEContextModificationFailureAllAmf_type ueContextModFailure;
        NG_RRCInactiveTransitionReportAllAmf_type rrcInactiveTransitionReport;
        NG_CellTrafficTraceAllAmf_type cellTrafficTrace;
        /* 9.2.3  UE Mobility Management Messages */
        NG_HandoverRequiredGnbAmf_type handoverRequired;                     /* 9.2.3.1  HANDOVER REQUIRED */
        NG_HandoverRequestAcknowledgeGnbAmf_type handoverRequestAcknowledge; /* 9.2.3.5  HANDOVER REQUEST ACKNOWLEDGE */
        NG_HandoverFailureGnbAmf_type handoverFailure;                       /* 9.2.3.6  HANDOVER FAILURE */
        NG_HandoverNotifyGnbAmf_type handoverNotify;                         /* 9.2.3.7  HANDOVER NOTIFY */
        NG_PathSwitchRequestGnbAmf_type pathSwitchRequest;                   /* 9.2.3.8  PATH SWITCH REQUEST */
        NG_HandoverCancelGnbAmf_type handoverCancel;                         /* 9.2.3.11 HANDOVER CANCEL */
        NG_UplinkRANStatusTransferAllAmf_type snStatusTransfer;              /* 9.2.3.13 UPLINK RAN STATUS TRANSFER */
        /* -------------------------------------- */
        NG_LocationReportAllAmf_type locationReport;
        NG_LocationReportingFailureIndicationAllAmf_type locationReportingFailureInd;
        NG_TraceFailureIndicationAllAmf_type traceFailureIndication;
        NG_ErrorIndicationAllAll_type errorIndication;
        NG_PDUSessionResourceNotify_type pduSessionNotify;

        NG_UplinkRANConfigurationTransferAllAmf_type ranConfigurationTransfer;
        NG_UplinkUEAssociatedNRPPaTransportAllAmf_type ulUEAssociatedNRPPaTransport;
        NG_DownlinkUEAssociatedNRPPaTransportAmfAll_type dlUEAssociatedNRPPaTransport;
    } ngap;

    union
    {
        XN_HandoverRequest_type handoverRequest;
        XN_HandoverRequestAcknowledge_type handoverRequestAcknowledge;
        XN_HandoverPreparationFailure_type handoverPreparationFailure;
        XN_HandoverCancel_type handoverCancel;
        XN_ConditionalHandoverCancel_type conditionalHandoverCancel;
        XN_HandoverSuccess_type handoverSuccess;
        XN_SNStatusTransfer_type snStatusTransfer;
        XN_UEContextRelease_type ueContextRelease;
        XN_RetrieveUEContextRequest_type retrieveUEContextRequest;
        XN_RetrieveUEContextResponse_type retrieveUEContextResponse;
        XN_RetrieveUEContextFailure_type retrieveUEContextFailure;
        XN_XnUAddressIndication_type xnUAddressIndication;
        XN_RANPaging_type ranPaging;
        XN_FailureIndication_type failureIndication;
        XN_HandoverReport_type handoverReport;
        XN_TraceStart_type traceStart;
        XN_DeactivateTrace_type deactivateTrace;
        XN_CellTrafficTrace_type cellTrafficTrace;
        // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< NEDC
        XN_SNodeAdditionRequest_type sNodeAdditionRequest;
        XN_SNodeAdditionRequestReject_type sNodeAdditionRequestReject;
        XN_SNodeAdditionRequestAcknowledge_type sNodeAdditionRequestAcknowledge;
        XN_SNodeReconfigurationComplete_type sNodeReconfigurationComplete;
        XN_SNodeModificationRequest_type sNodeModificationRequest;
        XN_SNodeModificationRefuse_type sNodeModificationRefuse;
        XN_SNodeModificationConfirm_type sNodeModificationConfirm;
        XN_SNodeModificationRequired_type sNodeModificationRequired;
        XN_SNodeModificationRequestAcknowledge_type sNodeModificationRequestAcknowledge;
        XN_SNodeModificationRequestReject_type sNodeModificationRequestReject;
        XN_SNodeReleaseRequest_type sNodeReleaseRequest;
        XN_SNodeReleaseRequired_type sNodeReleaseRequired;
        XN_SNodeReleaseConfirm_type sNodeReleaseConfirm;
        XN_SNodeReleaseRequestAcknowledge_type sNodeReleaseRequestAcknowledge;
        XN_SNodeChangeConfirm_type sNodeChangeConfirm;
        XN_SNodeChangeRefuse_type sNodeChangeRefuse;
        XN_SNodeChangeRequired_type sNodeChangeRequired;
        XN_RRCTransfer_type rrcTransfer;
        XN_ActivityNotification_type activityNotification;
        // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } xnap;

} VccbMsgBuf_type;

typedef union
{
    msgUnpack_type buff;
#define VCCB_BIG_MSG_UNPACK_BUFF_SIZE (sizeof(VccbMsgBuf_type) + 1024)
    unsigned char bigBuff[VCCB_BIG_MSG_UNPACK_BUFF_SIZE];
} VccbBigMsgUnpack_type;

typedef struct
{
    UNPACK_TYPE_BODY
    unsigned char buff[sizeof(NRRRC_DRX_Config)];
} VccbDrxMsgUnpack_type;

typedef struct gnbEnvInfo_s
{
    uint16_t cellNum[MAX_CELL_IDENTITY];               // cellIdentity -> cellNum
    pcidInfo_type pcidInfo[MAX_PHYSICAL_CELL_ID + 1];  // 0 ... 1007
} gnbEnvInfo_type;

typedef struct VccbTimerAuditInfo_s
{
    uint16_t internalCallStatTimerAuditCnt;           // CFG->timer.internalCallStatTimer
    uint16_t systemMonitoringTimerAuditCnt;           // CFG->timer.systemMonitoringTimer
    uint16_t keepAliveTimerAuditCnt;                  // ENV->keepAliveInfo.keepAliveTimer
    uint16_t anrMrCountNotiTimerAuditCnt;             // CFG->timer.anrMrCountNotiTimer
    uint16_t internalOamAuditTimerAuditCnt;           // CFG->timer.internalOamAuditTimer
    uint16_t internalPldAuditTimerAuditCnt;           // CFG->timer.internalPldAuditTimer
    uint16_t realTimeSgnbAdditionTimerAuditCnt;       // CFG->timer.realTimeSgnbAdditionTimer
    uint16_t internalMcoSlbOpCountResetTimerAuditCnt; // CFG->timer.internalMcoSlbOpCountResetTimer
    uint16_t internalPLDCpuUtilReadPeriodicTimerAuditCnt;
    uint16_t internalUeCapaAuditToVnmbTimerAuditCnt;  // THREAD_INFO->racs.ueCapaAuditTimerToVnmb

    uint16_t internalCallStatTimerRecoveryCnt;
    uint16_t systemMonitoringTimerRecoveryCnt;
    uint16_t keepAliveTimerRecoveryCnt;
    uint16_t anrMrCountNotiTimerRecoveryCnt;
    uint16_t internalOamAuditTimerRecoveryCnt;
    uint16_t internalPldAuditTimerRecoveryCnt;
    uint16_t realTimeSgnbAdditionTimerRecoveryCnt;
    uint16_t internalMcoSlbOpCountResetTimerRecoveryCnt;
    uint16_t internalPLDCpuUtilReadPeriodicTimerRecoveryCnt;
    uint16_t internalUeCapaAuditToVnmbTimerRecoveryCnt;

} timerAuditInfo_type;

typedef struct VccbCfgCallAudit_s
{
    uint16_t usage             : 1;  // (Main) This flag determines whether to enable the call audit function.
    uint16_t switch_release_ue : 1;  // (Sub)  This flag determines whether to release ue by call audit.
    uint16_t switch_statistic  : 1;  // (Sub)  This flag determines whether statistics are collected by call audit.
    uint16_t reserved          : 13;

    unsigned int auditCheckTime;  // This value determines whether to select the audit target ue for how long the ue
                                  // maintains state by the call audit function.
    unsigned int currentTickTime;
    unsigned int maxReleaseCountPerThread;  // This is the maximum number of releases per thread at one time.

    uint32_t releaseStateCount[VCCB_CALL_THREAD_NUM][MAX_VCCB_STATE];  // If this value is selected as a call audit, the
                                                                       // selected status is recorded.
} VccbCfgCallAuditInfo_type;

typedef struct
{
    union
    {
        struct
        {
            // SA
            uint32_t EventScenario_SA_InterGnbHandover               : 1;
            uint32_t EventScenario_SA_InterGnbHandover_DuInit        : 1;
            uint32_t EventScenario_SA_IntraGnbInterDuHandover        : 1;
            uint32_t EventScenario_SA_IntraGnbIntraDuHandover        : 1;
            uint32_t EventScenario_SA_IntraGnbInterDuHandover_DuInit : 1;
            uint32_t EventScenario_SA_IntraGnbIntraDuHandover_DuInit : 1;
            uint32_t EventScenario_SA_InterGnbRRE                    : 1;
            uint32_t EventScenario_SA_IntraGnbRRE                    : 1;
            uint32_t EventScenario_SA_InterGnbResume_CuInit          : 1;
            uint32_t EventScenario_SA_IntraGnbResume_CuInit          : 1;
            uint32_t EventScenario_SA_InterGnbResume_DuInit          : 1;
            uint32_t EventScenario_SA_IntraGnbResume_DuInit          : 1;

            // NRDC-MN, NEDC-MN
            uint32_t EventScenario_MRDC_MN_InterGnbHandover               : 1;
            uint32_t EventScenario_MRDC_MN_InterGnbHandover_DuInit        : 1;
            uint32_t EventScenario_MRDC_MN_IntraGnbInterDuHandover        : 1;
            uint32_t EventScenario_MRDC_MN_IntraGnbIntraDuHandover        : 1;
            uint32_t EventScenario_MRDC_MN_IntraGnbInterDuHandover_DuInit : 1;
            uint32_t EventScenario_MRDC_MN_IntraGnbIntraDuHandover_DuInit : 1;
            uint32_t EventScenario_MRDC_MN_MnInit                         : 1; // Test purpose only(To send SnAddReq without sourceConfigSCG IE during mobility)
            uint32_t EventScenario_MRDC_MN_SnInit                         : 1; // Test purpose only(To pretend that RRCConfigIndication=full-config exists during mobility)

            // NRDC-SN
            uint32_t EventScenario_NRDC_SN_SNodeAddition              : 1;
            uint32_t EventScenario_NRDC_SN_SNodeAddition_DuInit       : 1;
            uint32_t EventScenario_NRDC_SN_IntraDuPSCellChange        : 1;
            uint32_t EventScenario_NRDC_SN_InterDuPSCellChange        : 1;
            uint32_t EventScenario_NRDC_SN_IntraDuPSCellChange_DuInit : 1;
            uint32_t EventScenario_NRDC_SN_InterDuPSCellChange_DuInit : 1;
            uint32_t EventScenario_MRDC_SN_SnInit                     : 1;  // Test puporse only(To set RRCConfigIndication to full-config during mobility)
            uint32_t EventScenario_MRDC_SN_MnInit                     : 1;  // Test puporse only(To pretend that sourceConfigSCG no exists during mobility)

            // ENDC-SN
            uint32_t EventScenario_NSA_SgNBAddition             : 1;
            uint32_t EventScenario_NSA_IntraDuPSCellChange      : 1;
            uint32_t EventScenario_NSA_InterDuPSCellChange      : 1;

            // reserved
        };

        // If any of the above EventScenario values are On, the action has a non-zero value.
        uint32_t SecnarioEvent_Usage;  // 0 is not use foced full config trigger, otherwise tirigger full config (detail
                                       // info is above EventScenario values)
    };
} VccbFullConfigScenario_type;

typedef struct VccbCfgFullConfig_s
{
    // option
    struct VccbCfgFullConfigPrint_s
    {
        uint8_t get_filter : 1;
        uint8_t set_filter : 1;

    } print;

    struct VccbCfgFullConfigDbg_s
    {
        // This flag determines whether to run Full Configuration only for specific events.
        VccbFullConfigScenario_type forcedTriggerScenario;

        uint32_t drb_remapping;
        uint32_t drb_disable_datafwd;
    } dbg;

    struct VccbCfgFullConfigSupport_s
    {
        VccbFullConfigScenario_type scenario;

        struct VccbCfgFullConfigFlag_s
        {
            uint32_t F_21B_PDCP_SN_12BIT         : 1;
            uint32_t F_21C_MRDC_UE               : 1;
            uint32_t F_21C_MRDC_UNSUPPORT_BEARER : 1;
            uint32_t F_22A_NSA_PROCEEDHO         : 1;  // TODO : 22C Refactoring
            uint32_t F_22A_NSA_NRADDITION        : 1;  // TODO : 22C Refactoring
            uint32_t F_22A_NRDC_PROCEEDHO        : 1;  // TODO : 22C Refactoring
            uint32_t F_22A_NRDC_NRADDITION       : 1;  // TODO : 22C Refactoring
            uint32_t F_reserved                  : 25;
        } flag;

    } support;

    // filter..?
    struct VccbCfgFullConfigFilter_s
    {
#define VCCB_MAX_NUM_FC_FILTER     20
#define VCCB_MAX_SIZE_FC_FUNC_NAME 52

        uint8_t num;
        uint8_t reserved[3];
        struct
        {
            char func_name[VCCB_MAX_SIZE_FC_FUNC_NAME];
            int line;
        } info[VCCB_MAX_NUM_FC_FILTER];

    } filter;

} VccbCfgFullConfig_type;

// typedef struct
// {
//     // struct {
//     // } mrdcCommonFlag;

//     struct
//     {
//         uint64_t MnInitMobilitySupport : 1;
//         uint64_t SnInitMobilitySupport : 1;
//         uint64_t reserved              : 62;
//     } nedcFlag;

//     struct
//     {
//         /* MN */
//         uint64_t MnInitMobilitySupportForMN : 1;
//         uint64_t SnInitMobilitySupportForMN : 1;
//         uint64_t reserved1                  : 30;

//         /* SN */
//         uint64_t MnInitMobilitySupportForSN : 1;
//         uint64_t SnInitMobilitySupportForSN : 1;
//         uint64_t reserved2                  : 30;
//     } nrdcFlag;

// } VccbCfgMrdcConfig_type;

typedef struct
{
    uint32_t gnbNbr;
    uint32_t cellNbr;
    uint32_t enbNbr;
    uint32_t cellEutraNbr;
} nbrReadCountInto_type;

typedef struct
{
    uint32_t readGnbNum;
    uint32_t readIdx;
} VccbNbrCellReadInfo_type;

typedef struct
{
    uint32_t gnbId;
    plmnId_type plmn;
} vccbNbrGnbKeyInfo_type;

typedef struct
{
    uint32_t readGnbNum;
    uint32_t readIdx;
    uint32_t numOfInstance;
    vccbNbrGnbKeyInfo_type key;
} VccbNbrGnbReadInfo_type;

// NBR_AUDIT_22B
#define VCCB_AUDIT_CHECK_BASE_TIME 600  // 1 min (100ms * 600 = 60sec)

typedef struct
{
    // On or Off
    uint8_t nbrAuditEnabled;  // Off by default

    // Audit Hour - full Sync
    uint8_t nbrAuditHour;       // AM 3 by default everyday
    uint8_t nbrAuditCheckHour;  // to check nbrAuditHour
    // Audit Flag - full Sync
    uint8_t nbrAuditFlag;                     // triggered or not  - On/Off
    uint8_t nbrAuditForceFlag;                // triggered by operator from itscp_vccb CLI
    time_t nbrAuditStart, nbrAuditEnd;        // time ticks
    time_t nbrAuditMinTime, nbrAuditMaxTime;  // time ticks

    // Sync Count executed
    uint32_t syncFullCnt;                                                 // Sync Count globally
    uint32_t syncGnbCnt[MAX_GNB_CU_CP_FUNCTION_PER_SYS];                                 // Sync Count on the gNB
    uint32_t curNbrGnbCellCnt[MAX_GNB_CU_CP_FUNCTION_PER_SYS];                           // Current NBR GNB cell count
    uint32_t curNbrEnbCellCnt[MAX_GNB_CU_CP_FUNCTION_PER_SYS];                           // Current NBR ENB cell count
#define MAX_NBR_AUDIT_CNT_NUM 2                                           // before & after
    uint32_t auditNbrGnbCellCnt[MAX_GNB_CU_CP_FUNCTION_PER_SYS][MAX_NBR_AUDIT_CNT_NUM];  // Current NBR ENB cell count
    uint32_t auditNbrEnbCellCnt[MAX_GNB_CU_CP_FUNCTION_PER_SYS][MAX_NBR_AUDIT_CNT_NUM];  // Current NBR ENB cell count

    // Sync for the specific gNB
    uint8_t needToReset[MAX_GNB_CU_CP_FUNCTION_PER_SYS];       // first delete all existing DBs and perform new update from ConfD
    uint8_t needToResetEnb[MAX_GNB_CU_CP_FUNCTION_PER_SYS];    // first delete all existing DBs and perform new update from ConfD
    uint8_t waitingTimeToSync;                  // sync 60 min by default (min) after detecting the full of DB
    uint16_t elapsedTimeMin[MAX_GNB_CU_CP_FUNCTION_PER_SYS];   // check elapsed time to the waitingTimeToSync
    uint32_t syncGnbResetCnt[MAX_GNB_CU_CP_FUNCTION_PER_SYS];  // Sync Count after clearing existing DB on the gNB
    uint32_t syncEnbResetCnt[MAX_GNB_CU_CP_FUNCTION_PER_SYS];  // Sync Count after clearing existing DB on the gNB

    // Updated after all NBR at booting time
    uint8_t initialNbrReadFlag;                            // first read work CFG->confd.nbrAudit.initialNbrReadFlag
    uint8_t initialReadNbrGnbCellFlag[MAX_GNB_CU_CP_FUNCTION_PER_SYS];    // first read work on the gNB
    uint8_t initialReadCellNbrFlag[MAX_GNB_CU_CP_FUNCTION_PER_SYS];       // first read work on the gNB
    uint8_t initialReadNbrEnbCellFlag[MAX_GNB_CU_CP_FUNCTION_PER_SYS];    // first read work on the gNB
    uint8_t initialReadCellEutraNbrFlag[MAX_GNB_CU_CP_FUNCTION_PER_SYS];  // first read work on the gNB

    // Audit Count at different case
    uint32_t misNbrGnbCellCnt[MAX_GNB_CU_CP_FUNCTION_PER_SYS];
    uint32_t misNbrEnbCellCnt[MAX_GNB_CU_CP_FUNCTION_PER_SYS];
    uint32_t misCellNbrCnt[MAX_CELL_PER_VNF];
    uint32_t misCellEutraNbrCnt[MAX_CELL_PER_VNF];

} VccbNbrReadAuditInfo_type;

typedef enum
{
    BE_CLEARED = 0,
    BE_CFM = 2,
    BE_EXIT = 3
} BlockExitState_t;

typedef struct
{
    uint8_t monitoringPeriod;
    uint8_t initialGuardTime; // default: 15 mins
    uint32_t callAttemptThreshold;
    uint8_t minorThreshold;
    uint8_t majorThreshold;
    uint8_t criticalThreshold;
    uint8_t recoveryUsage;

    uint8_t alarmSeverity;  // AlarmPerceivedSeverity(CRITICAL(1), MAJOR(2), MINOR(3), CLEARED(5))
    AlarmBodyTypeExp alarmBody;
    uint8_t criticalCount;  // 0~2
    struct timeval lastCheckTime;
    uint32_t prevCallAttemptCount[VCCB_CALL_THREAD_NUM];
    uint32_t prevCallSuccessCount[VCCB_CALL_THREAD_NUM];
    uint8_t observedThreshold;
} VccbCallSuccessRatioLowAlarm_type;

typedef struct
{
    uint8_t alarmEnabled;
    uint16_t minorThreshold;
    uint16_t majorThreshold;
    uint16_t criticalThreshold;
} VccbAlarmAttribute_type;

typedef struct
{
    VccbAlarmAttribute_type attribute;

    uint8_t alarmSeverity;  // AlarmPerceivedSeverity(CRITICAL(1), MAJOR(2), MINOR(3), CLEARED(5))
    AlarmBodyTypeExp alarmBody;
    uint16_t observedThreshold;
} VccbResourceThresholdExceededAlarmItemSingle_type;

typedef struct
{
    VccbAlarmAttribute_type attribute;

    uint8_t alarmSeverity[VCCB_CALL_THREAD_NUM];  // AlarmPerceivedSeverity(CRITICAL(1), MAJOR(2), MINOR(3), CLEARED(5))
    AlarmBodyTypeExp alarmBody[VCCB_CALL_THREAD_NUM];
    uint16_t observedThreshold[VCCB_CALL_THREAD_NUM];
} VccbResourceThresholdExceededAlarmItemPerThread_type;

typedef struct
{
    VccbAlarmAttribute_type attribute;

    uint8_t alarmSeverity[MAX_GNB_CU_CP_FUNCTION_PER_SYS];  // AlarmPerceivedSeverity(CRITICAL(1), MAJOR(2), MINOR(3),
                                                            // CLEARED(5))
    AlarmBodyTypeExp alarmBody[MAX_GNB_CU_CP_FUNCTION_PER_SYS];
    uint16_t observedThreshold[MAX_GNB_CU_CP_FUNCTION_PER_SYS];
} VccbResourceThresholdExceededAlarmItemPerGnb_type;

typedef struct
{
    uint8_t isConfigurationChanged;
    pthread_mutex_t isConfigurationChangedMutex;
    uint8_t featureEnabled;
    uint8_t monitoringPeriod;
    VccbResourceThresholdExceededAlarmItemSingle_type callContext;
    VccbResourceThresholdExceededAlarmItemPerThread_type messageQueue;
    VccbResourceThresholdExceededAlarmItemPerGnb_type irntiUeIdMap;
#ifdef __CNF__
    VccbResourceThresholdExceededAlarmItemPerThread_type contextBackupBuffer;
#endif
    struct timeval lastCheckTime;
} VccbResourceThresholdExceededAlarm_type;

typedef struct
{
    uint8_t alarmSeverity;
    AlarmBodyTypeExp alarmBody;
} VccbRedisAccessAlarm_type;

#define MAX_EXCLUDED_CRR_LIST   30

typedef struct
{
    uint8_t alarmEnabled;
    uint8_t monitoringPeriod;               // 3 ~ 20 minutes
    uint8_t abnormalReleaseRatioThreshold;  // 0 ~ 100 %
    uint8_t instantMonitoringPeriod;        // 2 sec
    uint32_t releasedCallThreshold;         // call count to determine alarm

    uint32_t prevCallReleaseCount[VCCB_CALL_THREAD_NUM];
    uint32_t currCallReleaseCount[VCCB_CALL_THREAD_NUM];
    uint32_t prevAbnormalCallReleaseCount[VCCB_CALL_THREAD_NUM];
    uint32_t currAbnormalCallReleaseCount[VCCB_CALL_THREAD_NUM];

    uint8_t instantCallDropHighCount;  // # of times the threshold has been exceeded (check alarm condition every 2 sec)
                                       // VCCB will raise alarm if this value is not '0' for each monitoringPeriod.
    uint8_t  excludedCrrCount;
    uint8_t  reserved;
    uint8_t  alarmSeverity;   // MAJOR(2), CLEARED(5)
    uint16_t excludedCRRList[MAX_EXCLUDED_CRR_LIST]; // 30

    AlarmBodyTypeExp alarmBody;
    struct timeval lastCheckTime;    // To measure time interval (5min) when feature on

 } VccbCallDropRatioHighAlarm_type;

#define MAX_SERVICE_TYPE_NUM    64

typedef struct {
    uint64_t mcc        :13;
    uint64_t mnc        :13;
    uint64_t sst        :9;
    uint64_t sd         :25;
    uint64_t reserved   :4;

    uint64_t fiveQi     :9;
    uint64_t rfsp       :10;
    uint64_t arp        :9;
    uint64_t ueType     :2;
    uint64_t reserved2  :34;
} ServiceTypeItemList;

typedef struct
{
    bool usage;
    union {
        ServiceTypeItemList ItemList;
        uint64_t            mask[2];
    };
} ServiceTypeList_type;

typedef struct
{
    timerInfo_type upgradeExistingCallRelWaitTimer;  // after lock, wait for release calls
    timerInfo_type upgradeEmergencyCallRelWaitTimer; // after ExistingCallRelWait, if emergencyCall exist, wait for these calls. configure by YANG
    timerInfo_type upgradeEmergencyCallCheckTimer;   // perodic timer for checking emergency call existence
    timerInfo_type upgradeTerminatingCallRelWaitTimer; // after All call releasing triggered, wait for signal processing and free resource.
    uint32_t upgradeAllCallRelWaitTimerValue; // 1000 ~ 65535
    uint8_t upgradeEmergencyCallRelWaitTimerValue; // 0 ~ 60 min (YANG)
    uint8_t receiveSIG1count;
    uint8_t receiveSIG2count;
    uint8_t receivedSignalType;
    uint16_t terminationCallReleaseWaitSeconds;     // "TERMINATION_CALL_REL_WAIT_SEC" : 0 ~ 600
    uint8_t reserved[2];
} VccbCnfUpgrade_type;

typedef struct
{
    VccbCallSuccessRatioLowAlarm_type callSuccessRatioLowAlarm;
    VccbResourceThresholdExceededAlarm_type resourceThresholdExceededAlarm;
    VccbCallDropRatioHighAlarm_type callDropRatioHighAlarm;
    int isNanoSupport;
#ifdef __CNF__
    VccbRedisAccessAlarm_type redisAccessAlarm;
    char buildTime[VCCB_BUILDTIME_LEN];
#endif
    VccbCnfUpgrade_type cnfUpgrade;

    // SVR24B FGR-CC0300 Service Type Configuration for Statistics
    uint8_t serviceTypeOnOff;
    uint8_t alarmCount;

    // SVR26A FGR-CC3103 IODT RACS(UE Radio Capability Signaling Optimization)
    uint8_t racsFunctionOnOff;

    // SVR26B OAMP-HA0201 vRAN VNF/CNF and Geo Redundancy
    uint8_t grStatus;

    ServiceTypeList_type serviceTypeList[MAX_SERVICE_TYPE_NUM];
} VccbAcpfInfo_type;

// DU and core Weight factors used to store factors from confddd
// which are used durng UP selection
typedef struct
{
    uint8_t usage;
    uint64_t cuUpId;
    struct
    {
        uint64_t start;
        uint64_t end;
    } duIdRange;
    uint16_t value;
} duWeightFactor_type;

typedef struct
{
    uint8_t usage;
    uint64_t cuUpId;
    struct ipv4_s
    {
        uint8_t prefixBitLen;
        unsigned int ip;
    } ipv4;
    struct ipv6_s
    {
        uint8_t prefixBitLen;
        uint8_t ip[ADDRLEN_IPV6];
    } ipv6;
    uint16_t value;
} coreWeightFactor_type;

typedef struct
{
    uint8_t amfNameLen;                  // length of amfName
    char amfName[MAX_AMF_NAME_LEN + 1];  // amf Name(150)
} AmfNameInfo_type;

typedef struct
{
    int relationId;
    uint32_t numOfAttribute;
    attributeInfo attInfo[DBI_MAX_LOOP_CNT_ATTR];
} vccbPldAttributeInfo_type;

typedef struct {
    union {
        struct {
            uint32_t ForgeResp_SnAddReqAck_5qi_1_fail             : 1;
            uint32_t ForgeResp_SnAddReqAck_bearerTypeChange       : 1;

            uint32_t reserved : 30;
        };

        uint32_t clearForgeRespFlag; // 0 menas no forge partial scenario
    };

} VccbCfgNrdcPartialHo_type;

#define DEFAULT_PERIODIC_LB_TIME                        65535 // sec
#define DEFAULT_PERIODIC_LB_GUARD_TIME                  500 // ms
#define DEFAULT_PERIODIC_LB_AVAILABLE_UE_PER_CELL       3  // 1..60
#define DEFAULT_PERIODIC_LB_AVAILABLE_UE_TOTAL_RRC_UE   30  // 1..600
#define MAX_PERIODIC_LB_TIME                            65535
#define MAX_PERIODIC_LB_GUARD_TIME                      65535
#define MAX_PERIODIC_LB_AVAILABLE_UE_PER_CELL           60
#define MAX_PERIODIC_LB_AVAILABLE_UE_TOTAL_RRC_UE       600
#define MAX_PERIODIC_LB_SEARCH_UE_PER_UE_SELECTION      10000
#define MAX_PERIODIC_LB_SELECTABLE_UE_PER_THREAD        10

typedef struct
{
    uint32_t numUe;
    uint32_t callId[MAX_PERIODIC_LB_SELECTABLE_UE_PER_THREAD];
} targetUeListInfo_type;

typedef struct
{
    uint16_t periodicLbTime;  // 2..65535(s)
    uint16_t periodicLbGuardTime;  // 100..65535(ms)
    uint8_t periodicLbUsage;
    uint8_t cntMaxAvailableUePerCell;  // 1..60
    uint8_t cntMaxAvailableTotalUe;  // 1..600
    uint8_t cntMaxAvailableUePerThread;  // 1..10
    uint32_t startUeIndex;
    uint16_t cntMaxSearchableUe;
    targetUeListInfo_type selectedUePerThread[VCCB_CALL_THREAD_NUM];
} periodicLbInfo_type; //SVR26A FGR-LC0703

// FGR-CC0351
typedef struct ImeisvFeatureSupport_s
{
    uint8_t vonrSupportPerImeisv : 1;
    uint8_t reserved : 7;
    /*
     * uint8_t vonrOnOff : 1;
     * uint8_t caOnOff: 1;
     * etc. ...
     * Increase the size of the variable if going over the maximum bits
     */
    int8_t caUsageForNsa;       // enumCaUsage_type
    int8_t caUsageForSa;        // enumCaUsage_type
    int8_t ulCaUsageForSa;      // enumUlCaUsage_type

} ImeisvFeatureSupport_type;

typedef struct ImeisvFeatureControlInformationEntry_s
{
    uint64_t maskedImeisv;
    ImeisvFeatureSupport_type featureSupport;
} ImeisvFeatureControlInformationEntry_type;

typedef struct ImeisvFeatureControlInformation_s
{
    bool featureControlEnabled;
    ImeisvFeatureControlInformationEntry_type entries[MAX_IMEISV_FEATURE_CONTROL_INFORMATION_ENTRIES];
    uint8_t noOfEntries;
} ImeisvFeatureControlInformation_type;

typedef struct VccbCfgInfo_s
{
    struct VccbConfdInfo_s
    {
        uint8_t state;                 // connection state of confD (disabled/enabled)
        uint8_t nbrStanby2ActiveFlag;  // this flag set to true when stanby2Active, set to false after readGnbNum,
                                       // readIdx (CFG->confd.gnbNbr, CFG->confd.cellNbr)
                                       //        uint8_t     getXeipFlag;            // FLAG_ON  : XEIP is written in
                                       //        YANG, and VCCB read that IP.
                                       // FLAG_OFF : XEIP is not yet written in YANG.
        uint32_t disconnectCount;      // number of disconnect with confD
        uint32_t connectCount;         // number of connect with confD. (means, reconnect)
        uint32_t configDataReadSkipCount;  // number of configuration data read skip count
        uint32_t retryReadConfigCount;     // Retry count for reading configuration data
        uint32_t retryReadOperCount;       // Retry count for reading operational data
        uint32_t retryGetXeipCount;        // Retry count for getting XEIP
        uint32_t cmcSwitchOverCount;
        int32_t subConfdCount;
        int32_t selectedSubConfdIndex; // 1~N

        struct dal_db_txid lastSuccessTxid;
        struct dal_db_txid newTxid;

        vccbTimeInfo_type yangConfDataReadStartTime;
        vccbTimeInfo_type yangConfDataReadEndTime;
        vccbTimeInfo_type yangOperDataReadStartTime;
        vccbTimeInfo_type yangOperDataReadEndTime;

        VccbNbrGnbReadInfo_type gnbNbr;
        VccbNbrGnbReadInfo_type enbNbr;
        VccbNbrCellReadInfo_type cellNbr;
        VccbNbrCellReadInfo_type cellEutraNbr;
        VccbNbrReadAuditInfo_type nbrAudit;  // NBR_AUDIT_22B

        HasActMainUnitState_Type hasMainUnitState;  // CMC state
#ifdef __CNF__
        HasAllUnitState_Type hasAllUnitState;  // Cnf Pod State
#endif
    } confd;

    struct VccbPldInfo_s
    {
        uint8_t state;  // connection state of pld (disabled/enabled)
        uint8_t isInitialReadDone;
        uint8_t numOfPld;
        uint8_t curAuditRelIdx;
        uint8_t needAuditWithHasBackup;  // TRUE only when changed STANDBY to ACTIVE
        uint8_t isInPldAuditProcessing;  // TRUE only when PLD Read by Audit

        uint32_t pldRelationReadSkipByFooCount;     // number of pld relation read skip by foo count
        uint32_t pldRelationReadSkipNVGNBCount;     // number of pld relation read skip by not NVGNB supported count
        uint32_t pldRelationReadSkipCNFCount;       // number of pld relation read skip by not CNF supported count
        uint32_t pldGetOptionalRelationFailCount;   // number of pld relation get optional fail count
        uint32_t pldGetMandatoryRelationFailCount;  // number of pld relation get mandatory fail count

        vccbTimeInfo_type pldDataReadStartTime;
        vccbTimeInfo_type pldDataReadEndTime;

        uint8_t numOfPldWithData;
        vccbPldAttributeInfo_type pldAttInfo[MAX_NUM_SUBSCRIBE_PLD];
    } pld;

    struct VccbCfgTimer_s
    {
        int value[MAX_VCCB_TIMER];

        timerInfo_type internalCallStatTimer;
        timerInfo_type anrMrCountPeriodicNotiTimer;
        timerInfo_type anrMrCountNotiTimer;
        timerInfo_type idleLbHFCntTimer;
        timerInfo_type internalOamAuditTimer;
        timerInfo_type internalPldAuditTimer;
        timerInfo_type realTimeSgnbAdditionTimer;
        timerInfo_type internalMcoSlbOpCountResetTimer; // SVR24A FGR-CC5500 FR12
        timerInfo_type peerInfoRspVnlbTimer;
        timerInfo_type peerInfoRspVnmbTimer;
        timerInfo_type internalAuditStbGnbNumInfoTimer;
        timerInfo_type internalPLDCpuUtilReadPeriodicTimer;
    } timer;

    time_t startTimeForRealTimeSgnbAdd;

    int64_t neId;  // ACPF ID
    char k8sNamespace[VCCB_MAX_K8S_NAMESPACE_NAME_LEN + 1];
#ifdef __CNF__
    char podNamePrefix[VCCB_MAX_CNF_PREFIX_LEN + 1];
#endif
    vmDBInfo_type vm;
    vccbPldCpcState_type pldCpcState;

    // SVR23B FGR-LC0302 : gNB Overload Control
    uint8_t overloadStatus; // CPC overload AlarmStatus
    uint8_t cpuLoad;        // (only CNF) FGR-LC0750 Data collection for AI driven call control
#ifdef __NVGNB__
        uint8_t overloadValue[MAX_DRLIB_NVGNB_CPU_NUM]; // overload Alarm Status for multi CPU
#endif

    gnbNumInfo_type gnbNumInfo;    // used to allocate gnbNum.
    uint16_t startCellNumToFindEmptyCell;
    GlobalTraceInfo_type globalTraceInfo;

    // caCombination_type      caCombination[MAX_5GRA_CA_COMB_SYSTEM]; //TODO

    struct VccbCfgPdcpUlGrantInfo_s
    {
        uint8_t time;        // gUlGrantTime;
        uint8_t time_rrc;    // gRrcUlGrantTime;
        uint8_t time_recfg;  // gRecUlGrantTime;
        uint8_t time_smcmd;  // gSmcUlGrantTime;

        uint8_t size;        // gUlGrantSize;
        uint8_t size_rrc;    // gRrcUlGrantSize;
        uint8_t size_recfg;  // gRecUlGrantSize;
        uint8_t size_smcmd;  // gSmcUlGrantSize;
    } ulGrant;

    struct VccbCfgInfoFlag_s
    {
        uint32_t preventToSend : 1,  // to prevent to send cfg update information(triggered by PLD chg) to other block
                                     // before getting dest ip.
            reserved : 1;
    } flag;

    HasUnitState_Type hasCpc;  // VNFC Redundancy feature

    /**
     * @brief Structure storing Overload Control related parameters
     */
    struct OverloadControl
    {
        bool overloadAction; // Information for the overload control functions per CPU(23B)
        overloadAlarmState_t overloadAlarmState; /**< Overload alarm state */
        int32_t
            overloadAcceptanceFactor[4]; /**< acceptanse factor used to calculate rejected calls in overload state */
        uint8_t waitTime;                /**< waitTime sent in RRC connection reject */

        struct UeSigCpuOverloadControl
        {
            uint8_t ueSigCpuOverloadAction;
            uint8_t pa4mOverloadThreshold;
            uint8_t lpmEndcOverloadThreshold;
            uint8_t mcoOverloadThreshold;
            uint8_t caOverloadThreshold;
            uint8_t rreOverloadThreshold;
            uint8_t ulRrcSegmentOverloadThreshold;
            uint8_t overloadedLevelSliceLb; //SVR23B FGR-LC0710
            uint8_t overloadedLevelNrdc; //SVR23B FGR-CC5200
            uint8_t overloadedLevelIntraNrLb; //SVR24A FGR-LC0703
            uint8_t overloadedLevelPscellChangeLb; // FGR-LC0708
            uint8_t overloadedLevelInterRatLb; //SVR24A FGR-LC0711
            uint8_t overloadedLevelVoNrLb; // FGR-LC0712
            uint8_t overloadedLevelMro; // FGS-SF0509
        } ueSigCpuOverloadControl;

        struct McoSlbOpCountOverloadControl
        {
            uint32_t maxCntPccChange;
            uint32_t maxCntSccChange;
            uint32_t maxCntMrs;
            uint32_t maxCntSlb;
        } mcoSlbOpCountOverloadControl;

    } overloadControl;

    /**
     * @brief Structure storing Time Sync Service parameters
     */
    struct timeSyncService_type
    {
        /**
         * @brief Structure storing Local Time Info parameters
         */
        struct localTimeInfo_type
        {
            uint8_t     summertimeAutosetStatus;
            int32_t     daylightSaveTime;
            int32_t     localTimeOffset;
            bool        timeOffsetIncluded;
            bool        systemTimeOffsetAdded;
        } localTimeInfo;
    } timeSyncService;

    uint32_t assignedCallCount;

    int32_t cslOption[CSL_MAX_SERVERS_NUMBER];
    uint8_t cslEnable;
    uint8_t cslImsiControl;
    uint8_t cslReportingType;

    enumActivityNotificationMode inactivityVendor;

    manualMappingInfo_type manualInfo[MAX_MANUAL_CONFIG];

    nasInformation_type nas;

    struct amfInfo_s
    {
        PLDAmfStatus pldAmfStatus[MAX_GNB_CU_CP_FUNCTION_PER_SYS][MAX_AMF_PER_GNB_CU_CP];
        PLDAmfPlmnInfo pldAmfPlmnInfo[MAX_GNB_CU_CP_FUNCTION_PER_SYS][MAX_AMF_PER_GNB_CU_CP];
        PLDAmfTnlStatus pldAmfTnlStatus[MAX_GNB_CU_CP_FUNCTION_PER_SYS][MAX_AMF_PER_GNB_CU_CP][MAX_TNL_PER_AMF];
        PLDAmfTnlSctpState pldAmfTnlSctpState[MAX_GNB_CU_CP_FUNCTION_PER_SYS][MAX_AMF_PER_GNB_CU_CP][MAX_TNL_PER_AMF];
        uint8_t amfN26Support[MAX_GNB_CU_CP_FUNCTION_PER_SYS][MAX_AMF_PER_GNB_CU_CP];
        AmfNameInfo_type amfNameInfo[MAX_GNB_CU_CP_FUNCTION_PER_SYS][MAX_AMF_PER_GNB_CU_CP];
        enumAMFSelectionMode_type amfSelectionMode;
        uint16_t dbgAmfIdx;
        uint16_t dbgTnlIdx;
    } amf;

    PLDEutraCellInfo pldEutraCellInfo[MAX_GNB_CU_CP_FUNCTION_PER_SYS][MAX_ENB_PER_GNB_CU_CP];

    uint8_t anrMrCountSendFlag;

    VccbDynamicFlagInfo_type foo;

    // full Configuration
    VccbCfgFullConfig_type fullConfig;

    // mrdc Configuration
    // VccbCfgMrdcConfig_type mrdcConfig;

    // Call Audit Configuration / Information
    VccbCfgCallAuditInfo_type callAuditInfo;

    // supported CA config NSA [PCell freq range][Pcell duplex mode][SCell freq range][SCell duplex mode][intra/inter
    // band CA]
    enumSupport_type allowedCaConfigNSA[FrequencyRangeCa_MAX][MAX_DUPLEX_MODE][FrequencyRangeCa_MAX][MAX_DUPLEX_MODE]
                                       [BandDependencyCa_MAX];

    // supported CA config SA [PCell freq range][Pcell duplex mode][SCell freq range][SCell duplex mode][intra/inter
    // band CA]
    enumSupport_type allowedCaConfigSA[FrequencyRangeCa_MAX][MAX_DUPLEX_MODE][FrequencyRangeCa_MAX][MAX_DUPLEX_MODE]
                                      [BandDependencyCa_MAX];

    duWeightFactor_type duWeightFactor[MAX_DU_WEIGHT_FACTOR_INDEX];
    coreWeightFactor_type coreWeightFactor[MAX_CORE_WEIGHT_FACTOR_INDEX];

    VccbAcpfInfo_type acpfInfo;
    uint32_t maxHasSync;

    struct VccbCfgMsgQueueCntInfo_s
    {
        uint32_t maxMsgCntPerThread;
        uint32_t maxMsgCntPerCall;
    } msgQueue;

    uint32_t ipPortCheckPeriod;
    uint8_t ipPortUpdateFlag;

    // /managed-element/qos/diffserv/management-traffic
    uint8_t syslogCslTraceDSCP;

    VccbCfgNrdcPartialHo_type nrdcPartialHo;

    periodicLbInfo_type periodicLbInfo; //SVR26A FGR-LC0703
    ImeisvFeatureControlInformation_type imeisvFeatControlInfo; // SVR26B FGR-CC0351

    uint32_t tickRestrictionTime; /**< FR530: 1 Hz tick, wraps at SECONDS_PER_THREE_DAYS */

} VccbCfgInfo_type;

#define VCCB_ODHO_UE_NUM_PER_THREAD (30 * 10)  // ODF_HO_21B

typedef struct
{  // ODF_HO_21B
    uint32_t numUe;
    uint32_t callId[VCCB_ODHO_UE_NUM_PER_THREAD];
    bool releaseFlag[VCCB_ODHO_UE_NUM_PER_THREAD];
} onDemandTargetUeListInfo_type;

typedef struct
{  // ODF_HO_21B
    // Periodic timer for load distribution of On-Demand Mobility processing.
    // Whenever the timer expires, the shutdown state for each cell are update and UEs are selected.
    // When all shutdown states are cleared, the timer is released.
    timerInfo_type ldTimerInMain;

    // Start index select UEs
    uint32_t startUeIndex;

    // The latest time that time expired.
    // It's for abnormal timer processing and does not update the time if abnormal.
    struct timespec lastExpiredTime;

    // shutdown time and call release timer expiration information
    struct
    {
        struct timespec shutdownTime;
        bool expiredFlag;
    } shutdownCellInfo[MAX_CELL_PER_VNF];

    // Load distribution control information : max ue per thread, max ue per cell, etc.
    // Debug command change function provided - using itscp_vccb command for optimized processing
    struct
    {
        // Maximum number of UEs selectable per cell
        uint32_t maxSelectedUePerCell;  // MAX_NUM_ODHO_UE_PER_CELL, default(30)

        // Maximum number of selectable UEs per thread
        uint32_t maxSelectedUePerThread;  // MAX_NUM_ODHO_UE_PER_THREAD, default(30)

        // Maximum number of UEs that can be checked per cycle :
        // Set as a multiple of the maximum number of selectable UEs per cycle
        uint8_t checkUeRatio;  // VCCB_ODHO_CHECK_UE_RATIO, default(10)

        // Load dist timer value
        uint32_t timerForLoadDist;  // VCCB_ODHO_LOAD_DIST_TIMER_VAL, 100(ms)
    } ldCtrlInfo;

    // Include callId(s) and mobility operation type for On-Demand Mobilit
    // If the releaseFlag value is TRUE, redirection is indicated, otherwise, Handover.
    onDemandTargetUeListInfo_type targetUeList[VCCB_CALL_THREAD_NUM];

} onDemandLoadDistInfo_type;

typedef struct VccbPodInfo_s
{
    uint8_t ipPortGetFailFlag;
    uint8_t nanoUpdateRequiredFlag;
    char svcName[VCCB_MAX_DNS_SUBDOMAIN_NAME_LEN + 1];
    enumRedundancyStateType redundancyState;
    enumOperationalStateType operState; // currently used only  for CTP pods
} PodInfo_type;

typedef struct
{
    uint8_t failedDueToRecoveryTargetParam;  // TRUE/FALSE, temporary used during processing

    uint16_t numOfFailed;
    uint16_t pciList[MAX_NUM_CANDIDATE_CELL_FOR_PSCELL];
} failedPCIInfo_type;

typedef struct VccbCallHasKeyInfo_s
{
    int hasKey;
    uint32_t firstCallId;
    uint32_t lastCallId;
    uint32_t allocatedCallCount;
} CallHasKeyInfo_type;

typedef struct VccbCellHasKeyInfo_s
{
    int hasKey;
    uint32_t firstCellNum;
    uint32_t lastCellNum;
    uint32_t allocatedCellCount;
} CellHasKeyInfo_type;

typedef struct drxConfig_s
{
    uint8_t status;
    uint8_t longCycle;       // 0 : FR1, 1 : FR2, F1_LongDRXCycleLength_ms10 ..
    uint8_t selectionOrder;  // 0..15, A smaller 'selection order' means higher priority(initial value =
    drxState_t drxConfigSetup;
    drxState_t shortDrxConfigSetup;
    uint8_t shortCycle;
    uint8_t shortCycleTimer;
    // UNKNOWN_SELECTION_ORDER)
} drxConfigCu_type;

// CELL PROFILE : DrxConfig
typedef struct drxConfigProfile
{
    uint8_t drxProfileIdx;
    uint8_t status;
    char drxProfileName[150];

    uint8_t drxArp2TypeActivation;
    uint8_t drxConfigFlagPerSpid;  // boolean
    uint8_t drxConfigFlagPerRfsp;  // boolean
    uint8_t drxConfigFlagPerRfspRedCap; // boolean
    uint8_t drxConfigFlagPer5qiRedCap;  // boolean
    uint8_t drxConfigFlagPerServiceGrp;  // boolean
    drxConfigCu_type drxEutranSpid[MAX_ELEM_DRX_PER_SPID + 1];
    drxConfigCu_type drxNgranRfsp[MAX_ELEM_DRX_PER_RFSP + 1];
    drxConfigCu_type drxNgranRfspRedCap[MAX_ELEM_DRX_PER_RFSP + 1];
    drxConfigCu_type drxConfigCuQci[MAX_QCI_VALUE];
    drxConfigCu_type drxConfigCu5qi[MAX_5QI_VALUE];
    drxConfigCu_type drxConfigCu5qiRedCap[MAX_5QI_VALUE];
    drxConfigCu_type drxConfigCuServiceGrp[MAX_SVC_GRP_DB_NUM];
} drxConfigProfile_type;

// CELL PROFILE : SpidUlPathSwitch
typedef struct SpidUlPathSwitchProfile
{
    uint8_t spidBasedUlPathSwitchingProfileIdx;
    uint8_t status;

    spidThreshold_type spidThreshold[MAX_SPID_VALUE];
} SpidUlPathSwitchProfile_type;

typedef struct pdcpInfo_s
{
    ConfStatus shmStatus;  // shmStatus_type
    uint8_t rlcMode;
    uint32_t discardTimerUl;
    uint32_t discardTimerDl;
    uint8_t statusReportRequired;  // boolean
    uint8_t snSizeDl;
    uint8_t snSizeUl;
    uint8_t outOfOrderDelivery;  // boolean
    uint8_t tReorderingUl;
    uint8_t tReorderingDl;
    uint8_t ulDataSplitThreshold;  // enum
    rohCConfig_type roHCConfig;

} pdcpInfoQci_type;

typedef struct pdcpInfo5qi_s
{
    ConfStatus shmStatus;  // shmStatus_type
    uint8_t rlcMode;
    uint32_t discardTimerUl;
    uint32_t discardTimerDl;
    uint8_t statusReportRequired;  // boolean
    uint8_t snSizeDl;
    uint8_t snSizeUl;
    uint8_t outOfOrderDelivery;  // boolean
    uint8_t tReorderingUl;
    uint8_t tReorderingDl;
    uint8_t tReorderingUlSplitFr1Fr2;
    uint8_t tReorderingDlSplitFr1Fr2;
    uint8_t srcDlFwd;
    uint8_t srcUlFwd;
    uint8_t tgtDlFwd;
    uint8_t tgtUlFwd;
    uint8_t ulDataSplitThreshold;        // enum
    uint8_t ulDataSplitThresholdFr1Fr2;  // 0~23, NRDC-BASIC
    uint8_t redCapSnSizeUl;
    uint8_t redCapSnSizeDl;
    rohCConfig_type roHCConfig;
    ehcConfig_type  ethernetCompression;
} pdcpInfo5qi_type;

typedef struct serviceBasedPdcpInfo5qi_s
{
    uint8_t status;         // EQUIP / N_EQUIP
    uint8_t serviceGroupId; // 1 ~ 32
    pdcpInfo5qi_type pdcpInfo;
} serviceBasedPdcpInfo5qi_type;

// CELL PROFILE : PdcpInfo
typedef struct pdcpProfile
{
    uint8_t status;
    uint8_t maxSessionMnRatio;     // 0 ~ 100 % : default 50%
    uint8_t maxSessionRohc;        // enum value : enumMaxROHCsessions_type
    uint8_t maxSessionUlOnlyRohc;  // enum Value : enumMaxROHCsessions_type
    pdcpInfoQci_type pdcpInfoQci[MAX_QCI_VALUE];
    pdcpInfo5qi_type pdcpInfo5qi[MAX_5QI_VALUE];

    serviceBasedPdcpInfo5qi_type    serviceBasedPdcpInfo[MAX_SVC_GRP_CONFIG_ID];  // 32
} pdcpProfile_type;

#ifdef __CNF__
typedef struct VccbExtDbUpdateFlag_s
{
    struct cfg_s
    {
        uint8_t gnbNumInfo;
        pthread_mutex_t gnbNumInfo_update;
    } cfg;
    uint8_t cell[MAX_CELL_PER_VNF];
    pthread_mutex_t cell_update[MAX_CELL_PER_VNF];
    uint8_t gnb[MAX_GNB_CU_CP_FUNCTION_PER_SYS];
    pthread_mutex_t gnb_update[MAX_GNB_CU_CP_FUNCTION_PER_SYS];
} VccbExtDbUpdataFlag_type;

typedef struct VccbEnvRedisConnectionInfo_s
{
    int readContextIdx;
    int isContextConnected[REDIS_MAX_CONTEXT_CNT];
    int serverUpTime[REDIS_MAX_CONTEXT_CNT];
    uint32_t redisCommandCount[REDIS_MAX_CONTEXT_CNT];
    int appendedCommandCount[REDIS_MAX_CONTEXT_CNT];
    int disConnectedCount[REDIS_MAX_CONTEXT_CNT];
    int redisAccessFailCnt;
    uint8_t redisAccessAlarmFlag;
    uint8_t firstConnectionFailFlag;
} VccbEnvRedisConnectionInfo_Type;

typedef struct VccbExtDbCallQueueInfo_s
{
    int32_t frontIdx;
    int32_t rearIdx;
    uint32_t dataSize;
    uint32_t maxEnqueueCnt;
    uint32_t queueOverCnt;
    uint32_t qFullCnt;
    extDbCallBackupQueueNode_type queue[VCCB_MAX_CALL_CTX_BACKUP_BUFF];
    uint32_t flushedCnt;
    pthread_mutex_t callQueueMutex;
} VccbExtDbCallQueueInfo_Type;

#define MAX_PASSWORD_COUNT 3
#define MAX_PASSWORD_STRING_LENGTH 50
typedef struct
{
    VccbEnvRedisConnectionInfo_Type restoreConnInfo;
    VccbEnvRedisConnectionInfo_Type backupConnInfo;
    VccbExtDbCallQueueInfo_Type callBackupQueue[VCCB_CALL_THREAD_NUM];
    VccbExtDbUpdataFlag_type redisUpdateFlag;
    uint8_t restoreCompletedFlag;

    // 0 : New, 1 : Old, 2 : Certificate
    uint8_t redisAccessKey[MAX_PASSWORD_COUNT][MAX_PASSWORD_STRING_LENGTH];
} redisDbInfo_type;

#endif
typedef struct
{
    uint8_t releasePreferenceOnOff;
    uint8_t releasePreferenceProhibitTimer;
    uint8_t connectedReportingUsage;
} ueReleasePreferenceGnbConfig_type;

typedef struct
{
    uint8_t usage;  // EQUIP, N_EQUIP
    uint16_t rfspVal;
} rfspConStatYang_type;

typedef struct
{
    struct tm tm;
    struct timeval tv;
} timeRecord_type;

typedef struct
{
    uint16_t count;
    uint16_t expectedThroughput[MAX_NUM_BAND_COMB];
} McoBandCombinationExpectedThroughputList_type;


// SVR26A FGR-CC3103 IODT RACS(UE Radio Capability Signaling Optimization)
typedef struct VccbRacsThreadInfo_s
{
    struct VccbRacsThreadBufferInfo_s
    {
        VccbMsgBuf_type     tx;
        bigMessage_type     rx;
    } buf;

    timerInfo_type      ueCapaAuditTimerToVnmb;
} VccbRacsThreadInfo_type;

// RACS END

typedef struct
{
    cgi_type    eutraCgi;
    uint16_t    eutraPci;
    uint32_t    eutraBandCombinationIndex;
    uint64_t    eutraExpectedThroughput;

    McoBandCombinationExpectedThroughputList_type expectedThroughputList;
    CgConfigInfo_type   cgConfigInfo;
} McoBcInfoRespCallThreadStore_type;

typedef X2_Buffer_type msgLargeUnpack_type;

typedef struct nrBand_IdleLB_type_s
{
    enumUsage_type usage;

    uint16_t freqBandIndicator;               // 0..1024
    int16_t nrCaBandwidthClassDL;  // 0..28 + in16_t for not-configured
    int16_t nrCaBandwidthClassUL;  // 0..28 + in16_t for not-configured
} nrBand_IdleLB_type;

typedef struct caProfile_type_s
{
    enumUsage_type usage;

    int8_t index;
    uint8_t profilePriority;
    uint8_t num;
    nrBand_IdleLB_type nrBandList[MAX_NR_BAND_IDLELB_NUM];
} caProfile_type;

// #ifdef __CNF__
typedef struct
{
    uint16_t distCode;
    uint8_t isAllocated;
    uint32_t callCountAllocated;
    uint32_t distCodeToVccbCallId[MAX_CALL_COUNT_PER_DISTCODE];
    uint64_t activeUeBitmap[MAX_NUM_ACTIVE_UE_ARRAY];
} DistCodeInfo_type;
// #endif

typedef struct
{
    uint8_t status;  // enumKeepAliveReqStatus_type
    uint8_t regReq;  // 0: Received KeepAliveRsp from VNMB, 1: Not yet receiving KeepAliveRsp from VNMB
    uint8_t regReqRequired;
    char swVer[SW_VER_STR_LENGTH];

    uint16_t reqSndCnt;
    uint16_t reqRcvCnt;
    uint16_t rspSndCnt;
    uint16_t rspRcvCnt;
    timerInfo_type keepAliveTimer;

    uint16_t lastSentCallAuditIndex; // CNF : lastSentDistCode, else : lastSentCallAuditIndex
    uint64_t activeUeBitmap[MAX_NUM_ACTIVE_UE_ARRAY];

    // VCLB <-> VCCB: KeepAlive via shared memory (VclbSts_type)
    uint32_t localVclbValidCheck;  // VclbSts_type.vclbValidCheck value updated every 1 sec
    uint8_t vclbValidFlag;         // FLAG_ON/FLAG_OFF
} KeepAliveInfo_type;

typedef struct
{
    uint16_t reqSndVnlbCnt;
    uint16_t reqSndVnmbCnt;
    uint16_t reqRcvVnlbCnt;
    uint16_t reqRcvVnmbCnt;
    uint16_t rspSndVnlbCnt;
    uint16_t rspSndVnmbCnt;
    uint16_t rspRcvVnlbCnt;
    uint16_t rspRcvVnmbCnt;
} peerBlockInfo_type;

typedef struct
{
    uint8_t usage;
    uint8_t redirectionOnlyMode; // SVR24B FGR-MC1028 FR10
    uint8_t cellIndividualOffset;
    uint16_t pciStart;  //(0 ~ 503)
    uint16_t pciEnd;    //(0 ~ 503)
} VccbEutraSmallCellPciRange_type;

typedef struct
{
    uint8_t usage;
    VccbEutraSmallCellPciRange_type pciRange[MAX_EUTRA_SMALLCELL_PCI_RANGE_ENTRIES];
} VccbEutraSmallCellPciList_type;

typedef struct
{
    uint8_t usage;
    uint8_t reserve;
    uint16_t pciStart;  //(0 ~ 1007)
    uint16_t pciEnd;    //(0 ~ 1007)
    qOffsetSSBRangeList_type cellIndividualOffset;
} VccbNrSmallCellPciRange_type;

typedef struct
{
    uint8_t usage;
    uint8_t reserve;
    VccbNrSmallCellPciRange_type pciRange[MAX_EUTRA_SMALLCELL_PCI_RANGE_ENTRIES];
} VccbNrSmallCellPciList_type;

typedef union {
    struct {
        uint16_t usage      :1;
        uint16_t isEutra    :1;
        uint16_t pduNum     :14;
        uint16_t length;
    };

    uint32_t transactionId;
} RrcUnpackMgrDBTransactionId_type;

typedef struct
{
    RrcUnpackMgrDBTransactionId_type id;
    msgUnpack_type data;
} RrcUnpackMgrDB_type; // For Unpacking RRC Message In ComRrcUnpackMgr.cpp

typedef struct VccbEnvInfo_s
{
#ifdef __NVGNB__
    struct VccbEnvNeInfo_s
    {
        uint16_t shelfId;
        int pbaId;  // PBA_ID_Type
        eUnitType unitType;
        int32_t cpuId;
    } neInfo;
#endif

    // #ifdef __CNF__
    DistCodeInfo_type distCodeInfo[MAX_DIST_CODE_PER_SYS];
    // #endif
    struct VccbEnvPodInfo_s
    {
        char podName[VCCB_MAX_POD_NAME_LENGTH + 1];
        PodInfo_type cip[VCCB_MAX_POD_ID_NUM];
        PodInfo_type csp[VCCB_MAX_POD_ID_NUM];
        PodInfo_type cmp[VCCB_MAX_POD_ID_NUM];
        PodInfo_type redis[VCCB_MAX_POD_ID_NUM];
        PodInfo_type snp;
        PodInfo_type ctp[VCCB_MAX_POD_ID_NUM];
    } podInfo;

    struct
    {
        timeRecord_type loadingStart;
        timeRecord_type loadingEnd;
        timeRecord_type shmCreateStart;
        timeRecord_type shmCreateEnd;
        timeRecord_type initBaseStart;
        timeRecord_type initBaseEnd;
        timeRecord_type subscribeDalStart;
        timeRecord_type subscribeDalEnd;
        timeRecord_type readCfgDataStart;
        timeRecord_type readCfgDataEnd;
        timeRecord_type readOpDataStart;
        timeRecord_type readOpDataEnd;
        timeRecord_type regiPldStart;
        timeRecord_type regiPldEnd;
        timeRecord_type initialReadPldStart;
        timeRecord_type initialReadPldEnd;
        timeRecord_type readRedisStart;
        timeRecord_type readRedisEnd;
        timeRecord_type initialNbrYangReadStart;
        timeRecord_type initialNbrYangReadEnd;
    } vccbInitTime;

    drlibNvgnbInfo_type drlibNvgnbInfo;
    drlibNvgnbDeployment_type drlibNvgnbDeployment;
    VnfDeploymentFlavorInfo_type vnfDeploymentFlavorInfo;
    CnfDeploymentFlavorInfo_type cnfDeploymentFlavorInfo;
    struct VccbDeploymentFlavorInfo_s
    {
        uint16_t maxCellNumPerAcpf;
        uint8_t vccbCoreNum;
        uint8_t vccbCallThreadNum;
        uint32_t vccbMaxCallNum;
        uint8_t vnmbCallThreadNum;
        uint8_t vnmbPagingThreadNum;
        uint8_t vclbDataThreadNum;
        uint8_t vupbCallThreadNum;
        uint8_t maxGnbNum;
    } deploymentFlavorInfo;

    KeepAliveInfo_type keepAliveInfo;
    peerBlockInfo_type peerBlockInfo;

    struct VccbEnvFlag_s
    {
        uint32_t interfaceStatus   : 1,  // gInterfaceStatusFlag
            isVccbRegisteredOnBPDM : 1,  // BPDM registration success
            reserved               : 1;
    } flag;

    struct VccbEnvHandle_s
    {
        int vccb;  // vccbUdpHd;
        int vccbExt;
        int vccbRedisRestore;
        int vccbCall[VCCB_CALL_THREAD_NUM];  // vccbCallHd[VCCB_CALL_THREAD_NUMVCCB_CALL_PORT_NUM]
        int vccbMgmt;                        // vccbMgmtHd;
        int vccbPld;                         // vccbPldHd;
        int vccbSubscribe;                   // vccb Yang Subscribe Sock;
        int vccbRead;                        // vccb Yang Read Sock;
        int vccbDalOperSocket;               // socket for operational data update
        int vccbKa;                          // for VCCB-VNMB KeepAlive message
        int vccbLog;                         // for VCCB Log
        int vccbNonUe;
        int vccbNonUeBigMsg;
        int vccbNonUeAsn1;
        int vccbStatistics;                  // for VCCB Statistics
        int vccbExtCallCslTrace[VCCB_CALL_THREAD_NUM]; // required to set separate DSCP value
        int vccbExtRacsBigMsg;               // for VNMB RACS(UE Capa ID)
        int vccbIntRacs;                     // for VCCB RACS(Timer)
        int vccbIntRacsBigMsg[VCCB_INT_RACS_BIGMSG_MBOX_MAX_NUM];  // for VCCB RACS(UE Capa ID)
    } handle;

    struct VccbEnvNanoPullHandle_s
    {
        int vccb;
        int vccbRedisRestore;
        int vccbCall[VCCB_CALL_THREAD_NUM];
        int vccbNonUe;
        int vccbNonUeAsn1;
        int vccbExtRacsBigMsg;               // for VNMB RACS(UE Capa ID)
        int vccbIntRacsBigMsg[VCCB_INT_RACS_BIGMSG_MBOX_MAX_NUM];  // for VCCB RACS(UE Capa ID)
    } nanoPullHandle;

    struct VccbEnvNanoPushHandle_s
    {
        int sctbF1[VCCB_MAX_HA_UNIT_NUM][MAX_GNB_CU_CP_FUNCTION_PER_SYS];              // MdsAddr_Type         SCTB_ADDR;
        int sctbX2[VCCB_MAX_HA_UNIT_NUM][MAX_GNB_CU_CP_FUNCTION_PER_SYS];              // MdsAddr_Type         SCTB_ADDR;
        int sctbNG[VCCB_MAX_HA_UNIT_NUM][MAX_GNB_CU_CP_FUNCTION_PER_SYS];              // MdsAddr_Type         SCTB_ADDR;
        int sctbXN[VCCB_MAX_HA_UNIT_NUM][MAX_GNB_CU_CP_FUNCTION_PER_SYS];              // MdsAddr_Type         SCTB_ADDR;
        int sctbE1[VCCB_MAX_HA_UNIT_NUM][MAX_GNB_CU_CP_FUNCTION_PER_SYS];              // MdsAddr_Type         SCTB_ADDR;
        int vclbF1[VCLB_DATA_THREAD_NUM];                               // MdsAddr_Type         VCLB_ADDR;
        int vnlb[VCCB_MAX_HA_UNIT_NUM];                                 // VNLB_ADDR
        int vnmb[VCCB_MAX_HA_UNIT_NUM];                                 // VNMB_ADDR        : For KeepAlive
        int vnmbCall[VCCB_MAX_HA_UNIT_NUM][VNMB_CALL_THREAD_NUM];       // VNMB_CALL_ADDR   : For Call Message
        int vnmbTransfer[VCCB_MAX_HA_UNIT_NUM];                         // VNMB_TRANSFER_ADDR  : For VNMB XN/NG Message
        int vnmbCbrs[VCCB_MAX_HA_UNIT_NUM];                             // VNMB_CBRS_ADDR    : For VNMB CBRS Message
        int vnmbPag[VCCB_MAX_HA_UNIT_NUM][VNMB_PAGING_THREAD_NUM];      // VNMB_PAGING_ADDR    : For RAN-Paging
        int bpdm;                                                       // BPDM address
        int osabAnr[VCCB_MAX_HA_UNIT_NUM];                              // OSAB Anr address
        int vcsb[VCCB_MAX_HA_UNIT_NUM];                                 // VCSB_ADDR        : For LoadBalancing
    #ifdef __CNF__
        int vtmb[VCCB_MAX_POD_ID_NUM];                                 // MdsAddr_Type         VTMB_ADDR;
        int vtmbMain[VCCB_MAX_POD_ID_NUM];                             // MdsAddr_Type         VTMB_MAIN_ADDR;
        int vtmbTrace[VCCB_MAX_POD_ID_NUM][MAX_VTMB_TRACE_THREAD_NUM]; // MdsAddr_Type         VTMB_ADDR_TRACE;
        int vtmbMdt[VCCB_MAX_POD_ID_NUM];
    #else
        int vtmb[VCCB_MAX_HA_UNIT_NUM];                                 // MdsAddr_Type         VTMB_ADDR;
        int vtmbMain[VCCB_MAX_HA_UNIT_NUM];                             // MdsAddr_Type         VTMB_MAIN_ADDR;
        int vtmbTrace[VCCB_MAX_HA_UNIT_NUM][MAX_VTMB_TRACE_THREAD_NUM]; // MdsAddr_Type         VTMB_ADDR_TRACE;
        int vtmbMdt[VCCB_MAX_HA_UNIT_NUM];
    #endif
        int vnmbExtRacsBigMsg[VCCB_MAX_HA_UNIT_NUM];                    // VNMB_RACS_BIGMSG_ADDR : for VNMB RACS Message
        int vccbIntRacsBigMsg[VCCB_INT_RACS_BIGMSG_MBOX_MAX_NUM];       // VCCB_RACS_BIGMSG_ADDR : for VCCB Internal RACS Message
    } nanoPushHandle;

    struct VccbEnvAddr_s
    {
        MdsAddr_Type vccb;                                           // MdsAddr_Type         VCCB_ADDR;
        MdsAddr_Type vccbExt;                                        // MdsAddr_Type         VCCB_ADDR;
        MdsAddr_Type rcvAddrMain;                                    // MdsAddr_Type         VCCB_ADDR;
        MdsAddr_Type vccbNonUe;                                      // MdsAddr_Type         VCCB_NONUE_ADDR;
        MdsAddr_Type vccbNonUeBigMsg;                                // MdsAddr_Type         VCCB_NONUE_BIGMSG_ADDR;
        MdsAddr_Type vccbNonUeAsn1;                                  // MdsAddr_Type         VCCB_NONUE_ASN1_ADDR;
        MdsAddr_Type rcvAddrNonUe;                                   // MdsAddr_Type
        MdsAddr_Type rcvAddrNonUeBigMsg;                             // MdsAddr_Type
        MdsAddr_Type rcvAddrNonUeAsn1;                               // MdsAddr_Type
        MdsAddr_Type rcvAddrCall[VCCB_CALL_THREAD_NUM];              // VCCB_CALL_ADDR[VCCB_CALL_THREAD_NUM];
        MdsAddr_Type vccbCall[VCCB_CALL_THREAD_NUM];                 // VCCB_CALL_ADDR[VCCB_CALL_THREAD_NUM];
        MdsAddr_Type vccbMgmt;                                       // MdsAddr_Type         VCCB_MGMT_ADDR;
        MdsAddr_Type vccbPld;                                        // MdsAddr_Type         VCCB_PLD_ADDR;
        MdsAddr_Type vccbKa;                                         // MdsAddr_Type         VCCB_KA_ADDR;
        MdsAddr_Type vccbLog;                                        // MdsAddr_Type         VCCB_LOG_ADDR;
        MdsAddr_Type rcvAddrLog;                                     // MdsAddr_Type         VCCB_LOG_ADDR;
        MdsAddr_Type vccbRedisRestore;
        MdsAddr_Type rcvAddrRedisRestore;
        MdsAddr_Type vccbStatistics;                                 // MdsAddr_Type         VCCB_STATISTICS_ADDR;

        MdsAddr_Type sctbE1[VCCB_MAX_HA_UNIT_NUM][MAX_GNB_CU_CP_FUNCTION_PER_SYS];  // MdsAddr_Type    SCTB_ADDR;
        MdsAddr_Type sctbF1[VCCB_MAX_HA_UNIT_NUM][MAX_GNB_CU_CP_FUNCTION_PER_SYS];  // MdsAddr_Type    SCTB_ADDR;
        MdsAddr_Type sctbX2[VCCB_MAX_HA_UNIT_NUM][MAX_GNB_CU_CP_FUNCTION_PER_SYS];  // MdsAddr_Type    SCTB_ADDR;
        MdsAddr_Type sctbNG[VCCB_MAX_HA_UNIT_NUM][MAX_GNB_CU_CP_FUNCTION_PER_SYS];  // MdsAddr_Type    SCTB_ADDR;
        MdsAddr_Type sctbXN[VCCB_MAX_HA_UNIT_NUM][MAX_GNB_CU_CP_FUNCTION_PER_SYS];  // MdsAddr_Type    SCTB_ADDR;
        MdsAddr_Type vnlb[VCCB_MAX_HA_UNIT_NUM];                                    // MdsAddr_Type    VNLB_ADDR;
        MdsAddr_Type vclbF1[VCLB_DATA_THREAD_NUM];                               // MdsAddr_Type    VCLB_ADDR;
#ifdef __CNF__
        MdsAddr_Type vtmb[VCCB_MAX_POD_ID_NUM];                                 // MdsAddr_Type    VTMB_ADDR;
        MdsAddr_Type vtmbMain[VCCB_MAX_POD_ID_NUM];                             // MdsAddr_Type    VTMB_MAIN_ADDR;
        MdsAddr_Type vtmbTrace[VCCB_MAX_POD_ID_NUM][MAX_VTMB_TRACE_THREAD_NUM]; // MdsAddr_Type    VTMB_ADDR_TRACE;
        MdsAddr_Type vtmbMdt[VCCB_MAX_POD_ID_NUM];
#else
        MdsAddr_Type vtmb[VCCB_MAX_HA_UNIT_NUM];                                 // MdsAddr_Type    VTMB_ADDR;
        MdsAddr_Type vtmbMain[VCCB_MAX_HA_UNIT_NUM];                             // MdsAddr_Type    VTMB_MAIN_ADDR;
        MdsAddr_Type vtmbTrace[VCCB_MAX_HA_UNIT_NUM][MAX_VTMB_TRACE_THREAD_NUM]; // MdsAddr_Type    VTMB_ADDR_TRACE;
        MdsAddr_Type vtmbMdt[VCCB_MAX_HA_UNIT_NUM];
#endif
        MdsAddr_Type vnmb[VCCB_MAX_HA_UNIT_NUM];                            // VNMB_ADDR        : For KeepAlive
        MdsAddr_Type vnmbCall[VCCB_MAX_HA_UNIT_NUM][VNMB_CALL_THREAD_NUM];  // VNMB_CALL_ADDR   : For Call Message
        MdsAddr_Type vnmbTransfer[VCCB_MAX_HA_UNIT_NUM];  // VNMB_TRANSFER_ADDR  : For VNMB XN/NG Message
        MdsAddr_Type vnmbPag[VCCB_MAX_HA_UNIT_NUM][VNMB_PAGING_THREAD_NUM];  // VNMB_PAGING_ADDR    : For RAN-Paging
        MdsAddr_Type vnmbCbrs[VCCB_MAX_HA_UNIT_NUM];    // VNMB_CBRS_ADDR    : For VNMB CBRS Message
        MdsAddr_Type vnmbRacsBigMsg[VCCB_MAX_HA_UNIT_NUM]; // VNMB_RACS_BIGMSG_ADDR
        MdsAddr_Type vupbCall[MAX_VUPB_CALL_THREAD_NUM];  // VUPB_CALL_ADDR
        MdsAddr_Type dfcbCall[MAX_DFCB_CALL_MBOX_NUM];  // DFCB_CALL_ADDR[MAX_DFCB_CALL_MBOX_NUM];
        MdsAddr_Type dfcbRRC[MAX_DFCB_CALL_MBOX_NUM];   // DFCB_RRC_ADDR[MAX_DFCB_CALL_MBOX_NUM];
        MdsAddr_Type dfcbMgmt;                          // DFCB_MGMT_ADDR;  : For AccessAndMobility Ind
        MdsAddr_Type bpdm;                              // BPDM address
        MdsAddr_Type osabAnr[VCCB_MAX_HA_UNIT_NUM];     // OSAB Anr address
        MdsAddr_Type vcsb[VCCB_MAX_HA_UNIT_NUM];        // VCSB_ADDR        : For LoadBalancing
        MdsAddr_Type swmStartAck;

        // RACS
        MdsAddr_Type vccbExtRacsBigMsg;                 // MdsAddr_Type         VCCB_EXT_RACS_BIGMSG_ADDR;
        MdsAddr_Type vccbIntRacs;                       // MdsAddr_Type         VCCB_INT_RACS_ADDR;
        MdsAddr_Type vccbIntRacsBigMsg[VCCB_INT_RACS_BIGMSG_MBOX_MAX_NUM]; // MdsAddr_Type  VCCB_INT_RACS_BIGMSG_ADDR[VCCB_INT_RACS_HANDLE_NUM];
        MdsAddr_Type rcvdAddrForRacs;

    } addr;

    callInfo_type *callInfo;
#ifdef __CNF__

    redisDbInfo_type redis;

    uint8_t isRestoredFromRedisDB;
    uint8_t shouldSkipReadingCellInfo;
#endif
    enumCnfHaSupport_type isSupportHA;

    struct VccbEnvFnTableInfo_s
    {
        stateFnTable_type state[MAX_VCCB_STATE + 1];  // gVCCB_STATE_FN[];
    } fnTable;

    struct VccbEnvAuditInfo_s
    {
        timerAuditInfo_type periodicTimer;
    } audit;

    // managed-element/administrative-state
    enumAdminState_type system_admin_state;  // ODF_HO_21B

    // managed-element/virtual-function/vnf/vnfc/vnfc-entries (VNF only)
    enumAdminState_type cpc_admin_state;  // ODF_HO_21B

    /* On-Demand mobility Control DB */
    onDemandLoadDistInfo_type onDemandLoadDistCtrl;  // ODF_HO_21B

    struct VccbHasInfo_s
    {
        CallHasKeyInfo_type callHasKeyInfo[VCCB_NUM_CALLINFO_CHUNKS];
        CellHasKeyInfo_type cellHasKeyInfo[VCCB_NUM_CELLINFO_CHUNKS];
    } hasInfo;

} VccbEnvInfo_type;

typedef struct VccbCallThreadBufferInfo_s
{
    VccbMsgBuf_type tx;
    bigMessage_type rx;

    // For compatibility between these Inter-ASN versions, a buffer for Packing/Unpacking the Containing PDU is
    // added.
    struct VccbCallThreadBufferContaining_s
    {
        struct
        {
            msgUnpack_type rrcReconfiguration[MAX_CELL_GROUP];
            msgUnpack_type measResultList2NR[MAX_CELL_GROUP];  // NRRRC_MeasResultList2NR
            msgUnpack_type scgRadioBearerConfig;
        } rx;

        struct
        {
            msgContainer_type rrcReconfiguration[MAX_CELL_GROUP];
            msgContainer_type radioBearerConfig[MAX_CELL_GROUP];
        } tx;
    } containing;

    msgContainer_type pdcpTx;

    struct VccbCallThreadBufUnpack_s
    {
        VccbBigMsgUnpack_type call;
        msgUnpack_type store;     // for 2nd depth (rrc in X2, rrc in F1, nrppa in ngap)
        bigmsgUnpack_type ueCapa; // 4096*900*2 (7.02MB)
        union // do not use simultaneously
        {
            msgUnpack_type rscCoord;  // for resourceCoordination info
            msgUnpack_type uAISourceScg; // for UEAssistanceiInforamtion during storing X2/XN AdditionRequest
            msgUnpack_type lppCoord; // for LPPLocationCoordinates in NRRRC_MeasurementReport/NRRRC_UEInformationResponse
            msgUnpack_type debug; // for debug purpose.
        };

        RrcUnpackMgrDB_type rrc; // For Unpacking RRC Message In ComRrcUnpackMgr.cpp

    } unpack;

    msgContainer_type rrcTx;
    bigMsgContainer_type bigRrcTx;
    msgContainer_type cellGroupConfig;
    SctpDataTransfer_type sctpTx;

    struct VccbCallThreadBufCandidateCellInfoListRxBuf_s
    {
        measResultList2NR_type candidateCellInfoListMN;
        measResultList2NR_type candidateCellInfoListSN;
        measResultList2NR_type candidateCellInfoListMN_SCG;  // TODO: temp DB. use the MN and SN DB
        // NR_CONN_MC_21D for candidateCellInfoListNR-r15 in rrm-config, measResultServFreqListNR_SCG stored
        measResultServFreqListNR_type candidateCellInfoListNR;
    } measResultList2NRRx;

    measResultNeighCellsEUTRA_type measResultListEutraRx;
    hoRestrictInfo_type hoRestrictInfo;
    rrcQueueingMessage_type rrcQueueingRx;
    hoAmfTnlAddrInfo_type hoAmfTnlAddrInfo;
    RrcReconfigurationCompleteBuff_type mrdcReconfigurationComplete;
    uint8_t mcoBcBandResultsCache[VCCB_MCO_BCBANDRESULTCACHE_BUF_SIZE];

    // EUTRA-NR capa
    bandCombinationList_type mrdcBandCombList;
    MrdcFeatureSetCombinationList_type mrdcFeatureSetCombList;
    uint32_t mrdcBuffStoredCallId;

    // NR capa
    FeatureSets_type featureSets;
    bandCombinationList_type nrBandCombList;
    MrdcFeatureSetCombinationList_type nrFeatureSetCombList;
    uint32_t nrBuffStoredCallId;
    // MRS 23A
    McoBcInfoRespCallThreadStore_type mcoBcInfoResp;

    //NR-DC ovld
    uint16_t ovldCandidatesCnt;
    uint16_t totalOvldCandidatesCnt;

    pdcpInfo5qi_type serviceBasedPdcpInfo;

    // Trace messages aggregation buffer and flush timer
#ifdef __CNF__
    msgAggregatedTraceDataNoti_type traceAggregationBuff[VCCB_MAX_POD_ID_NUM];
    timerInfo_type traceBuffFlushTimer[VCCB_MAX_POD_ID_NUM];
#else
    msgAggregatedTraceDataNoti_type traceAggregationBuff;
    timerInfo_type traceBuffFlushTimer;
#endif

#ifdef __CNF__
    CompressedCallInfo_type compressedCallInfo[VCCB_MAX_CALL_CTX_BACKUP_BUFF];
#endif

    // SVR26A FGR-CC3103 IODT RACS
    racsCapaIdItem_type         needToSendUeCapaIDToVnmb;       // For UE CAPA ID query to VNMB
    VccbRacsGnbIdInfo_type      racsGnbIdInfo;
    NGAP_UERadioCapability_type tempSavedCapaBuff;              // For UE CAPA Info Buffer In InitialContextSetupRequest

} VccbCallThreadBufferInfo_type;

typedef struct
{
    uint32_t rsuTransId;
    uint32_t numOfFreq;
    struct rscPerFreq_s
    {
        uint32_t ssbFreq;
        double avgAvailableRsc;
    } rscPerFreq[MAX_NR_OF_OBJECT_ID_DB];
} nrdcMeasIdOrderingMgmt_type;

typedef struct VccbCallThreadInfo_s
{
    VccbCallThreadBufferInfo_type buf;
    callInfo_type tempCallInfo;

    // For recovery Cell Parameter between CU and DU
    failedPCIInfo_type failedPCIInfoForRecovery;

    // FGR-LC0705:FR12
    nrdcScgBandSelectionMgmt_type nrdcScgBandSelMgmtPerCell[MAX_CELL_PER_VNF];
    nrdcMeasIdOrderingMgmt_type measIdOrderingMgmt[MAX_CELL_PER_VNF];

    // FGR-TA0103
#ifdef __CNF__
    uint8_t lastChosenCtp;
#endif
    NrCallMsgDelay_type callMsgDelay;
    timerInfo_type  ueCapaQueryToVnmbTimer;     // SVR26A FGR-CC3103 IODT RACS
} VccbCallThreadInfo_type;

typedef struct VccbMainThreadInfo_s
{
    struct VccbMainThreadBufferInfo_s
    {
        VccbMsgBuf_type tx;
        bigMessage_type rx;
    } buf;
} VccbMainThreadInfo_type;

typedef struct VccbNonUeThreadInfo_s
{
    struct VccbNonUeThreadBufferInfo_s
    {
        VccbMsgBuf_type tx;
        bigMessage_type rx;
    } buf;
} VccbNonUeThreadInfo_type;

typedef struct VccbNonUeAsn1ThreadInfo_s
{
    struct VccbNonUeAsn1ThreadBufferInfo_s
    {
        VccbMsgBuf_type tx;
        bigMessage_type rx;

        struct VccbNonUeAsn1ThreadBufUnpack_s
        {
            msgLargeUnpack_type first;
            msgUnpack_type second;   // for 2nd depth (rrc in X2, rrc in F1) of MainThread
            bigmsgUnpack_type third;  // for 3rd depth of MainThread
        } unpack;
        SctpDataTransfer_type sctpTx;

        struct VccbNonUeAsn1ThreadBufCandidateCellInfoListRxBuf_s
        {
            measResultList2NR_type candidateCellInfoList;  // general purpose buffer for measResultList on main thread
        } measResultList2NRRx;
        uint8_t mcoBcBandResultsCache[VCCB_MCO_BCBANDRESULTCACHE_BUF_SIZE];

        struct VccbMcoBcInfoReqStore_s
        {
            // EUTRA-NR capa
            bandCombinationList_type mrdcBandCombListBuff;
            MrdcFeatureSetCombinationList_type mrdcFeatureSetCombListBuff;

            // NR capa
            FeatureSets_type featureSetsBuff;
            bandCombinationList_type nrBandCombListBuff;
            MrdcFeatureSetCombinationList_type nrFeatureSetCombListBuff;

            McoBandCombinationExpectedThroughputList_type expectedThroughputList;
            int32_t storeStatus;  // sum of enumSamsungBcInfoRequestStoreStatus_type

            uint8_t mrsLoadConsideredFlag; // MRS 23B samsungMRSLoadConsidered
        } mcoBcInfoReqStore;
    } buf;
    callInfo_type tempCallInfo;
} VccbNonUeAsn1ThreadInfo_type;

typedef struct VccbPldThreadInfo_s
{
    struct VccbPldThreadBufferInfo_s
    {
        msgUnpack_type unpack;
    } buf;
} VccbPldThreadInfo_type;

typedef struct VccbEnvCandidateCellInfoListRxBuf_CallThread_s
{
    measResultList2NR_type candidateCellInfoListMN;
    measResultList2NR_type candidateCellInfoListSN;
    measResultList2NR_type candidateCellInfoListMN_SCG;  // TODO: temp DB. use the MN and SN DB
    // NR_CONN_MC_21D for candidateCellInfoListNR-r15 in rrm-config, measResultServFreqListNR_SCG stored
    measResultServFreqListNR_type candidateCellInfoListNR;
} VccbEnvCandidateCellInfoListNrRxBuf_CallThread_type;

typedef struct VccbEnvCandidateCellInfoListEutraRxBuf_CallThread_s
{
    measResultNeighCellsEUTRA_type measResultList;  // store measResultNeighCells
} VccbEnvCandidateCellInfoListEutraRxBuf_CallThread_type;

typedef struct // slice-aware-load-balancing-configuration (slice specific)
{
    uint8_t sliceTransmissionType; // slice-transmission-type
    uint16_t capacityThresholdDl; // slice-capacity-threshold-dl range:0~200
    uint16_t capacityThresholdUl; // slice-capacity-threshold-ul range:0~200
    uint16_t deltaCapacityThresholdDl; // delta-slice-capacity range:0~100
    uint16_t deltaCapacityThresholdUl; // delta-slice-capacity range:0~100
    uint16_t deltaCapacityThresholdRedcapDl; // delta-slice-capacity range:0~100
    uint16_t deltaCapacityThresholdRedcapUl; // delta-slice-capacity range:0~100
    uint16_t slaViolationSwitch; //sla-violation-switch
    uint8_t slaViolationThDl; // sla-violation-rate-threshold-dl range:0~200
    uint8_t slaViolationThUl; // sla-violation-rate-threshold-ul range:0~200
    int8_t slaViolationRateDeltaDl; // delta-sla-violation-rate-dl range:0~100
    int8_t slaViolationRateDeltaUl; // delta-sla-violation-rate-ul range:0~100
    uint8_t ulSliceCapaThreshUlPathSwitching; // ul-slice-capacity-threshold range:0~100
    uint8_t deltaUlSliceCapaUlPathSwitching ; // delta-ul-slice-capacity range:0~100
} sliceAwareLbConf_type;  //SVR24A FGR-LC0710

typedef struct
{
    uint8_t usage; // default: CI_no_use
    uint8_t plmnIndex;
    uint8_t priority; // slice-priority range:0~8 (0:invalid and default)

    uint8_t plmnIndex_exist : 1; // present, if plmn-index exists
    uint8_t sst_exist       : 1; // present, if slice-sst exists
    uint8_t reserved        : 6;
    
    callSNSSAI_type sNssai;
    sliceAwareLbConf_type sliceAwareLbConf;
} sliceLoadControlInfo_type; //SVR24A FGR-LC0710, FGR-CC5003

typedef struct qciSupport_s
{
    BOOL usage;
    uint16_t qciWeightFactor;
    uint8_t supportLbPscellChange; // FGR-LC0708 FR10.
} qciSupport_type;

typedef struct
{
    swVersion_type swVersion;
} AupfEtcInfo_type;

#define MAX_RESTRICTED_FREQ_ENTRIES_PER_TARGET 2
#define MAX_RESTRICTED_FREQ_ENTRIES 8

typedef enum
{
    ssbFrequenciesRestriction_n77_usa = 0,          // n77-usa
    ssbFrequenciesRestriction_n77_2_canada = 1      // n77-2-canada
} enumSsbFrequenciesRestriction_type;

typedef struct {
    uint8_t usage;
    enumSsbFrequenciesRestriction_type target;
    uint32_t ssbFreqEntries[MAX_RESTRICTED_FREQ_ENTRIES];
    uint8_t noOfSsbFreqEntries;
} SsbFreqPerTarget_type;

typedef struct {
    SsbFreqPerTarget_type ssbFreqEntriesPerTarget[MAX_RESTRICTED_FREQ_ENTRIES_PER_TARGET];
} restrictedSsbFrequencies_type;

#define MAX_NCD_FREQ_ENTRIES 4
#define MAX_CD_TO_NCD_MAPPING_ENTRIES 20

typedef struct {
    uint32_t ncdSsbFreq;
    smtc1_type ncdSmtc;
    uint8_t usage;
} NcdSsbFreqEntry_type;


typedef struct {
    uint32_t cdSsbFreq;
    NcdSsbFreqEntry_type ncdSsbFreqEntries[MAX_NCD_FREQ_ENTRIES];
    uint8_t usage;
} CdToNcdMappingEntry_type;

typedef struct {
    ConfStatus featureEnabled;
    CdToNcdMappingEntry_type cdToNcdMappingEntries[MAX_CD_TO_NCD_MAPPING_ENTRIES];
} NcdSsbConfig_type;

typedef struct {
    uint16_t            gNBIdx;
    uint16_t            endPointIdx;
    uint8_t             status;
    int8_t              serviceState;
    uint16_t            reserved1;
    uint32_t            gNBId;
    unsigned long       aupfId;
    uint8_t             overloadStatus;
    uint8_t             capacity;
    uint8_t             cnSupport;
    swVersion_type      swVersion;

    // below new from PLDAupfPlmnInfo
    uint8_t             statusPlmn;
    uint8_t             plmnCnt;
    uint32_t            plmn[MAX_E1_SUPPORTED_PLMN];
    //uint8_t             plmnCnt;
    //uint32_t            plmn[MAX_E1_SUPPORTED_PLMN];
    uint8_t             eutranQciPerPlmnCnt[MAX_E1_SUPPORTED_PLMN];
    uint16_t            eutranQci[MAX_E1_SUPPORTED_PLMN][MAX_EUTRAN_QCI_PER_PLMN];
    uint32_t            supportedSnssaiGrpCntPerPlmn[MAX_E1_SUPPORTED_PLMN];
    uint32_t            supportedSnssaiGrp[MAX_E1_SUPPORTED_PLMN][MAX_SNSSAI_GRP_PER_PLMN_AUPF];
    uint16_t            supportedSnssaiGrpLength[MAX_E1_SUPPORTED_PLMN][MAX_SNSSAI_GRP_PER_PLMN_AUPF];
} AupfStatusInfo_type;

typedef struct
{
    uint8_t  activityNotificationLevel;                 // YANG: inactivity-data-sa/inactivity-data-sa-redcap/activity-notification-level
    uint16_t signalingTimer;                            // YANG: inactivity-data-sa/inactivity-data-sa-redcap/signaling-timer
    uint16_t ueInactivityTimer;                         // YANG: inactivity-data-sa/inactivity-data-sa-redcap/ue-inactivity-timer
                                                                    // uses common-sa-ue-inactivity-timer;
    uint16_t drbInactivityTimerEntries[MAX_5QI_VALUE];  // YANG: inactivity-data-sa/inactivity-data-sa-redcap/drb-inactivity-timer-entries
                                                                    // uses common-sa-drb-inactivity-timer-entries;
    rfspBasedUserInactivityControl_type rfspControlInfo; //
                                                                    // rfspControlInfo.featureSwitch -> YANG: inactivity-data-sa/inactivity-data-sa-redcap/rfsp-based-user-inactivity
                                                                    // rfspControlInfo.rfspList[*]        -> YANG: inactivity-data-sa/inactivity-data-sa-redcap/rfsp-based-user-inactivity-entries
                                                                    // uses common-sa-rfsp-based-user-inactivity-entries;
} UserInactRedCap_type;

typedef struct MultiCarrierOperationProfileEntry_s
{
    char name[MAX_MCO_PROFILE_NAME_LENGTH];
    bool usage;
    struct MultiCarrierOperationConfigEntry_s
    {
        uint8_t configPriority;
        bool configUsage;
        struct MultiCarrierOperationConfigEntryCondition_s
        {
            bool rfspUsage;
            uint16_t rfsp[MAX_MCO_RFSP_ENTRIES];
            uint8_t noOfRfsp;
            bool serviceGroupUsage;
            uint8_t serviceGroupIndex[MAX_MCO_SERVICE_GROUP_ENTRIES];
            uint8_t noOfServiceGroupIndex;
        } condition;
        struct MultiCarrierOperationConfigEntryOperation_s
        {
            bool iratPccChgUsage;
            bool ulAwareThresholdUsageForIratPccChg;
            uint32_t ulTrafficThresholdForIratPccChg;
            int32_t ulBwThresholdForIratPccChg;
            bool dlAwareThresholdUsageForIratPccChg;
            uint16_t dlTrafficThresholdForIratPccChg;
            int32_t dlBwThresholdForIratPccChg;
        } operation;
    } configEntry[MAX_MCO_CONFIG_ENTRIES];
    uint8_t configEntrySortIdx[MAX_MCO_CONFIG_ENTRIES];
} multiCarrierOperationProfileEntry_type;

typedef struct sliceStatYang_s
{
    uint8_t usage; // EQUIP, N_EQUIP
    uint8_t plmnIndex;
    callSNSSAI_type sNssai;
} sliceStatYang_type;

// SVR26B FGR-CC3103 UE Capability Handling for NR and MR-DC
typedef struct
{
    uint8_t  usage;
    uint16_t triggerThresholdNg;
    uint16_t triggerThresholdXn;
    uint16_t triggerThresholdIrat;

    uint8_t  plmnReduceOn[MAX_PLMN_INDEX];
} ueCapaSizeReduceInfo_type;

typedef struct VccbGnbInfo_s
{
    gnbConfig_type cfg;
    gnbEnvInfo_type env;

    ConfStatus status;
    vccbGlobalGnbId_type globalGnbId;
    uint32_t randSeed;

    uint8_t dalReadFailFlag;
    uint8_t isConfdRestored;
    uint8_t pldActivationState;
    uint8_t serviceBasedPdcpOnOff;      // SVR25B JIO PH4 PDCP Function
    timeRecord_type confdRestoredTime;

    x2NbrInfo_type x2Nbr[MAX_ENB_PER_GNB_CU_CP]; /**< Size of MAX_ENB_PER_GNB_CU_CP */
    xnNbrInfo_type
        xnNbr[MAX_XN_NBR_PER_GNB]; /**< Size of MAX_XN_NBR_PER_GNB :: Please access Getter(FnVCCB_GetXnNbrInfo) */
    xnNbrInfo_type intraXnNbr;     /**< Size 1 :: Please access Getter(FnVCCB_GetXnNbrInfo) */
    xnHoBlackNbrInfo_type xnHoBlackList[MAX_XN_NBR_PER_GNB]; /**< Size of MAX_XN_NBR_PER_GNB */

    xnTaiInfo_type xnGnbInfo[MAX_XN_NBR_PER_GNB];  // PLDXnGnbStatus (TAI list Per End Point)
    xnTaiInfo_type gnbXnTaiInfo;                   // PLDGnbXnTaiInfo (TAI list Per Serving gNB)

    uint32_t nbrGnbIndexPos;
    nbrGnbCellInfo_type nbrGnbCell[MAX_NBR_GNB_CELL_PER_GNB];
    nbrGnbCellCgiListExt_type nbrGnbCellCgiListExt[MAX_NBR_GNB_CELL_PER_GNB];
    nbrGnbCellInfo_type nbrGnbCell_dummy;     // Dummy
    /**< Size of MAX_NBR_GNB_CELL_PER_GNB */  // move to std::map<cgi_type, nbrEnbCellInfo_type>
                                              // nbrGnbCell[MAX_GNB_CU_CP_FUNCTION_PER_SYS] due to neighbor structure change
    uint32_t nbrEnbIndexPos;
    nbrEnbCellInfo_type nbrEnbCell[MAX_NBR_ENB_CELL_PER_GNB];
    nbrEnbCellInfo_type nbrEnbCell_dummy;     // Dummy
    /**< Size of MAX_NBR_GNB_CELL_PER_GNB */  // move to std::map<cgi_type, nbrEnbCellInfo_type>
                                              // nbrEnbCell[MAX_GNB_CU_CP_FUNCTION_PER_SYS] due to neighbor structure change
    gnbDuInfo_type gnbDu[MAX_GNB_DU_PER_GNB_CU_CP];

    struct aupfInfo_s
    {
        // PLDAupfStatus gnbCuUp[MAX_GNB_CU_UP_PER_GNB_CU_CP];  // AUPF parameters shared by VNMB
        AupfStatusInfo_type gnbCuUp[MAX_GNB_CU_UP_PER_GNB_CU_CP];  // AUPF parameters shared by VNMB
        //AupfEtcInfo_type gnbCuUpEtcInfo[MAX_GNB_CU_UP_PER_GNB_CU_CP];
        enumAUPFSelectionMode_type aupfSelectionModeENDC;    // YANG: cu-up-selection-conf/endc-cu-up-selection-policy
        enumAUPFSelectionMode_type aupfSelectionModeSA;      // YANG: cu-up-selection-conf/cu-up-selection-policy
        enumAUPFSelectionMode_type
            aupfSelectionModeNRDCSN;  // YANG: cu-up-selection-conf/nrdc-sn-cu-up-selection-policy
        enumENDCAmbrAupfDistribution_type
            ambrAupfDistributionENDC;  // YANG: cu-up-selection-conf/endc-ue-dl-ambr-distribution-policy
        enumAmbrAupfDistribution_type
            ambrAupfDistributionSA;           // YANG: cu-up-selection-conf/ue-dl-ambr-distribution-policy
        uint8_t  allowOverloadedUpForHpaMpsBearers;
        uint16_t aupfSelectionRoundRobinIdx;  // operational idx for Debug mode only
    } aupf;

    yangTimer_type yangTimer;
    RrcSaTimerProfile_type rrcSaTimerProfile[MAX_RRC_SA_TIMER_PROFILE_PER_GNB];
    RrcEndcTimerProfile_type rrcEndcTimerProfile[MAX_RRC_ENDC_TIMER_PROFILE_PER_GNB];

    VccbSecurityDBInfo_type security;
    plmnIdInfo_type plmnIndexInfo[MAX_PLMN_INDEX];
    serviceAvailInfo_type serviceAvailInfo[MAX_PLMN_INDEX]; // YANG: gnb-cu-cp-function-entries/service-available-info

    struct UserInactivity_s
    {
        ConfStatus featureEnabled;                          // YANG: inactivity-data/feature-enabled
        uint16_t signalingTimer;                            // YANG: inactivity-data/signaling-timer
        uint8_t activityNotificationLevel;                  // YANG: inactivity-data/activity-notification-level
        uint8_t x2Reporting;                                // YANG: inactivity-data/x2-reporting
        uint16_t x2ReleaseTimer;                            // YANG: inactivity-data/x2-release-timer
        uint16_t ueInactivityTimer;                         // YANG: inactivity-data/ue-inactivity-timer
        uint16_t drbInactivityTimerEntries[MAX_QCI_VALUE];  // YANG: inactivity-data/drb-inactivity-timer-entries
        BOOL spidBasedUserInactivity;                       // YANG: inactivity-data/spid-based-user-inactivity
        spidBasedInactivityList spidBasedUserInactivityEntries[MAX_SPID_VALUE + 1];
        // YANG: inactivity-data/spid-based-user-inactivity-entries
        FreqBasedUserInactivityControl_type freqControlInfo;  // YANG: inactivity-data/frequency-based-control
        uint8_t perCellOnOff;                                 // YANG: inactivity-data/per-cell-onoff
        inactivityDataProfile_type inactivityDataProfileEntries[VCCB_MAX_USER_INACT_ENDC_PROFILES];
        // YANG: inactivity-data/inactivity-data-profile-entries
    } UserInactivity;

    struct UserInactivitySA_s
    {
        ConfStatus featureEnabled;          // YANG: inactivity-data-sa/feature-enabled
        uint16_t signalingTimer;            // YANG: inactivity-data-sa/signaling-timer
        uint8_t activityNotificationLevel;  // YANG: inactivity-data-sa/activity-notification-level
        uint8_t dataInactivityPerCellOnOff; // YANG: inactivity-data-sa/sa-data-inactivity-per-cell-onoff
        uint8_t nrPpaSignalingTimerEnabled; // YANG: inactivity-data-sa/nrppa-signaling-timer-enabled
        uint8_t reserved;
        uint16_t ueInactivityTimer;         // YANG: inactivity-data-sa/ue-inactivity-timer
        uint16_t drbInactivityTimerEntries[MAX_5QI_VALUE];  // YANG: inactivity-data-sa/drb-inactivity-timer-entries
        uint16_t pDUSessionInactivityTimerEntries
            [MAX_PDU_SESS_PER_CALL];  // YANG: inactivity-data-sa/pdu-session-inactivity-timer-entries
        rfspBasedUserInactivityControl_type rfspControlInfo;
        saDataInactProfile_type dataProfileInfo[VCCB_MAX_USER_INACT_SA_PROFILES];
        UserInactRedCap_type redCap;        // YANG : inactivity-data-sa/inactivity-data-sa-redcap
    } UserInactivitySA;

    struct UserInactivityNrdcSN_s
    {
        ConfStatus featureEnabled;          // YANG: inactivity-data-nrdc-sn/feature-enabled
        uint16_t signalingTimer;            // YANG: inactivity-data-nrdc-sn/signaling-timer
        uint8_t activityNotificationLevel;  // YANG: inactivity-data-nrdc-sn/activity-notification-level
        uint16_t xnReleaseTimer;            // YANG: inactivity-data-nrdc-sn/xn-release-timer
        uint16_t ueInactivityTimer;         // YANG: inactivity-data-nrdc-sn/ue-inactivity-timer
        uint16_t
            drbInactivityTimerEntries[MAX_5QI_VALUE];  // YANG: inactivity-data-nrdc-sn/drb-inactivity-timer-entries
        rfspBasedUserInactivityControl_type rfspControlInfo;
    } UserInactivityNrdcSN;

    struct VccbGnbRrcInactiveInfo_s
    {
        ConfStatus featureEnabled;
        enumActivityNotifLvl_type activityNotificationLevel;        // for normal UEs
        enumActivityNotifLvl_type redCapActivityNotificationLevel;  // for RedCap UEs
        uint16_t ranPagingCycle;
        uint16_t rrcIdleTimer;              // UE-level for normal UEs
        uint16_t rrcInactiveTimer;          // UE-level for normal UEs
        uint16_t resumeWaitTimer;           // RRCResume Wait Timer for normal UEs
        uint16_t redCapRrcIdleTimer;        // UE-level for RedCap UEs
        uint16_t redCapRrcInactiveTimer;    // UE-level for RedCap UEs
        uint16_t redCapResumeWaitTimer;     // RRCResume Wait Timer for RedCap UEs
        uint32_t ueIdIndex;
        uint8_t  ranPagingTxCount;
        uint8_t  edrxAllowed;
        uint8_t  ranEdrx;
        uint16_t t380;
        uint16_t drbInactiveTimerEntries[MAX_5QI_VALUE];        // drb-level (0..255) for normal UEs
        uint16_t drbIdleTimerEntries[MAX_5QI_VALUE];            // drb-level (0..255) for normal UEs
        uint16_t redCapDrbInactiveTimerEntries[MAX_5QI_VALUE];  // drb-level (0..255) for RedCap UEs
        uint16_t redCapDrbIdleTimerEntries[MAX_5QI_VALUE];      // drb-level (0..255) for RedCap UEs
    } RrcInactiveInfo;

    qciSupport_type qciSupport[MAX_QCI_VALUE];
    qciSupport_type perPlmnQciSupport[MAX_PLMN_INDEX][MAX_QCI_VALUE];

    gnbCarrierAggregationInfo_type carrierAggregationInfo;

    struct MultiCarrierOperation_s
    {
        uint8_t capabilityAwareCarrierChange;
        uint8_t fullMeasureBasedPccChange;
        uint8_t sccChange;
        int32_t mrGatheringTimer;
        int32_t sccMrGatheringTimer;
        int32_t measReactivationTimer;
        effectiveBandwidthOption_type effectiveBandwidthOption;
        bool multipleChannelBwUsage;
        uint8_t interRatPccChange;
        int32_t interRatPccChangeTimer;
        uint8_t multiRatCarrierChange;
        uint8_t trafficCheckInterRatPccChange;
        uint8_t sliceIdCheckInterRatPccChange;
        SliceSupportedInfo_type sliceIdEntries[MAX_MCO_SUPPORTED_SLICES];
        uint8_t ulTrafficCheckInterRatPccChange;
        uint8_t mfbiCheck;
        uint8_t mrsTrafficCheckFlag;
        int32_t mrsMrGatheringTimer;
        int32_t effectiveBandwidthOffsetLte;
        int32_t effectiveBandwidthOffsetEndc;
        uint16_t effectiveBandwidthOffsetPcc;
        int32_t sccMeasReactivationTimer;
    } multiCarrierOperation;

    struct MultiCarrierOperationConfiguration_s
    {
        multiCarrierOperationProfileEntry_type profileEntry[MAX_MCO_CONFIG_PROFILE_ENTRIES];
    } multiCarrierOperationConfig;

    drxConfigProfile_type drxConfigProfile[MAX_DRX_PROFILE];
    SpidUlPathSwitchProfile_type SpidUlPathSwitchProfile[MAX_SPID_UL_PATH_SWITCHING_PROFILE];

    pdcpProfile_type pdcpProfile[MAX_PDCP_INFO_PROFILE_PER_GNB];

    struct DssConfiguration_s
    {
        enumUsage_type dssUESupportControl;
        uint8_t dssBands[MAX_DSS_BANDS_ARR_SIZE];  // stored as binary array for fast band check
                                                   // (((dssBands[bandNumber-1) / 8] >> ((bandNumber-1) % 8)) & 0xFE)
    } dssConfiguration;

    BOOL qos5qiSupport[MAX_5QI_VALUE];
    BOOL perPlmnQos5qiSupport[MAX_PLMN_INDEX][MAX_5QI_VALUE];
    anrSchedule_type mnsScheduleInfo;

    dualConnectivityControlInfo_type dcControlInfo[MAX_DC_CONTROL_ENTRIES];
    NrdcControlInfo_type nrdcControlInfo[MAX_NRDC_CONTROL_ENTRIES];  // NRDC-BASIC
    nedcUeAmbrConfig_type nedcUeAmbrConfig;
    nrdcUeAmbrConfig_type nrdcUeAmbrConfig[MAX_PLMN_INDEX];
    nrdcUeSliceMbrConfig_type nrdcUeSliceMbrConfig[MAX_PLMN_INDEX];

    capabilityRequestFilter_type capabilityRequestFilter;
    gnbSupportedBandInfo_type supportedFreqBandInfo;

    PLDGnbBarringInfo pldGnbBarringInfo;

    emergencyArpInfo_type emerArpInfo[MAX_PLMN_INDEX];
    mpsCallInfo_type mpsCallInfo[MAX_PLMN_INDEX];
    hpaCallInfo_type hpaCallInfo[MAX_PLMN_INDEX];

    // (VNF, CNF, NVGNB) managed-element/gnb-cu-cp-function/gnb-cu-cp-function-entries
    enumAdminState_type gnb_admin_state;  // ODF_HO_21B

    struct UEOverheatingControl_s
    {
        enumUsage_type overheatingControlSwitch;
        uint8_t t345;
    } UEOverheatingControl;

    struct UEPowersavingControl_s
    {
        enumUsage_type bwPreferenceControlSwitch;
        uint8_t t346b;
        enumUsage_type ccPreferenceControlSwitch;
        uint8_t t346c;
        enumUsage_type mimoLayerPreferenceControlSwitch;
        uint8_t t346d;
    } UEPowersavingControl;

    struct nodeSegInfo_s
    {
        nodeNbrSegInfo_type x2NbrSegInfo[MAX_ENB_PER_GNB_CU_CP];
        nodeNbrSegInfo_type xnNbrSegInfo[MAX_XN_NBR_PER_GNB];
    } nodeSegInfo;

    ueReleasePreferenceGnbConfig_type ueRelPrefGnbConfig;
    rfspConStatYang_type rfspBasedCounterList[MAX_RFSP_CONN_STAT_YANG];
    sliceStatYang_type sliceStatCounterList[MAX_SLICE_STAT_YANG];

    struct mroInfo_s
    {
        uint16_t statSwitch;
        uint16_t tStoreUeCtxt;
        uint16_t cpdSwitch; //24A FGS-SF0509 FR210 (cpd : Coverage Problem Dection)
        uint8_t  cpdThRsrp; //24A FGS-SF0509 FR210
        uint8_t  cpdThRsrq; //24A FGS-SF0509 FR210
    } mroInfo;

    struct iratMroInfo_s
    {
        uint16_t statSwitch;
        uint16_t tStoreUeCtxt;
        uint16_t pingPongIratHoTimer;
        uint16_t ueMeasRate;
        uint16_t rsrp;
        uint16_t measDuration;
    } iratMroInfo;

    struct anrPlmnInfo_s
    {
        uint16_t plmnTranslationSwitch;
        plmnId_type rcvPlmn[MAX_PLMN_INDEX];  // received-first-plmn
        plmnId_type actPlmn;                  // actual-first-plmn
    } anrPlmnInfo;

    struct assignedENDCcallCount_s
    {
        uint32_t assignedENDCcallCountAtt;
        uint32_t assignedENDCcallCountSucc;
    } assignedENDCcallCount;

    struct idleMobilityControl_s
    {
        uint8_t caProfileBasedIdleLbSwitch; // ca-profile-based-idle-lb-switch
        caProfile_type caProfileList[MAX_CA_PROFILE_NUM];
        uint8_t periodForUeDistRatio;
        priorityOfCarrier_type maxPriorityOfNonZeroDistRatioCarrier;
        priorityOfCarrier_type maxPriorityOfZeroDistRatioCarrier;
    } idleMobilityControl;

    overloadedHoTgtGnbList_type overloadedTgtGnb;  // NR_CONN_MC_23B
    VccbEutraSmallCellPciList_type eutraSmallCellPciList[MAX_EUTRA_SMALLCELL_PCI_ENTRIES];
    VccbNrSmallCellPciList_type nrSmallCellPciList[MAX_NR_SMALLCELL_PCI_ENTRIES];

    struct sliceAwareLbInfo_s
    {
        uint16_t sliceLbswitch;
        uint16_t sliceLbSwitchForRedcap;
        int32_t waitTimerValue;
        int32_t mrWaitTimerValueForRedcap;
    } sliceAwareLbInfo; //SVR23B FGR-LC0710

    sliceLoadControlInfo_type sliceLoadControlInfo[MAX_ACTIVE_SLICE_NUM]; //SVR24A FGR-LC0710, FGR-CC5003

    restrictedSsbFrequencies_type restrictedSsbFrequencies;

    NcdSsbConfig_type ncdSsbConfig;
    nrSammGnbConfiguration_type sammConfig;

    struct VoMAconfiguration_s
    {
        uint8_t onOff;  // enumVccbFlag
        uint8_t plmnStatuses; // number of entries in allowedPlmnList
        plmnId_type allowedPlmnList[MAX_NUM_VOMA_PLMNS];  // VoMA PLMN List
    } vomaConfiguration;

    // FGS-SF0502 FR240, FR243
    anrGnbInfo_type     anrGnbInfo;
    iratAnrGnbInfo_type  iratAnrGnbInfo;

    // SVR26B FGR-CC3103 UE Capability Handling for NR and MR-DC
    ueCapaSizeReduceInfo_type ueCapaSizeReduceInfo;

} VccbGnbInfo_type;

/* Monitoring BHCA */
typedef struct VccbDbgMonitoringBhca_s
{
    // Increase when F1_InitialULRRCMessageTransfer is received
    uint32_t nrofAttemptSa[VCCB_CALL_THREAD_NUM];
    // Increase when NG_InitialContextSetupResponse is sent
    uint32_t nrofCompleteSa[VCCB_CALL_THREAD_NUM];
    // Increase when NG_UEContextReleaseCommand is received
    uint32_t nrofReleaseAttemptSa[VCCB_CALL_THREAD_NUM];
    // Increase when NG_UEContextReleaseComplete is sent
    uint32_t nrofReleaseCompleteSa[VCCB_CALL_THREAD_NUM];

    // Increase when SgNBAdditionRequest is received
    uint32_t nrofAttempt[VCCB_CALL_THREAD_NUM];
    // Increase when SgNBReconfigurationComplete is sent
    uint32_t nrofComplete[VCCB_CALL_THREAD_NUM];
    // Increase when SgNB_ReleaseCommand is received
    uint32_t nrofReleaseAttempt[VCCB_CALL_THREAD_NUM];
    // Increase when SgNB_ReleaseComplete is sent
    uint32_t nrofReleaseComplete[VCCB_CALL_THREAD_NUM];

    // Time between SgNBAdditionRequest and SgNBReconfigurationComplete.
    // This value is updated to max value.
    long tDiffAttCmplt[VCCB_CALL_THREAD_NUM];
    // Time between E1_BearerContextSetupRequest and E1_BearerContextSetupResponse.
    // This value is updated to max value.
    long tDiffE1BearerSetup[VCCB_CALL_THREAD_NUM];
    // Time between F1_UEContextSetupRequest and F1_UEContextSetupResponse.
    // This value is updated to max value.
    long tDiffF1UEContextSetup[VCCB_CALL_THREAD_NUM];
    // Time between E1_BearerContextModificationRequest and E1_BearerContextModificationResponse during Setup.
    // This value is updated to max value.
    long tDiffE1BearerMod[VCCB_CALL_THREAD_NUM];
    // Time between SgNBAdditionRequest and Release(PutCi).
    // This value is updated to max value.
    long tDiffCallDuration[VCCB_CALL_THREAD_NUM];

} VccbDbgMonitoringBhca_type;

/* Cell Status History */
typedef struct
{
    uint16_t pldCellIdx;  // pld idx
    uint8_t pldState;     // pld state
    uint8_t status;       // yang status
    uint16_t cause;       // enumCellStatusHistoryCause_type
    time_t updateTime;    // updated when state is changed
    uint32_t gNBId;
    uint16_t gnbNum;
    uint16_t cellId;
    uint16_t endPointF1Index;
    uint8_t cellInDuStatus;
    uint8_t pldCellSrvState;
    uint8_t pldGnbSrvState;
} VccbDbgUpdateCellStatusHistory_type;

typedef struct
{
    int16_t curIdx;     // default: -1
    uint8_t cycleFlag;  // off(0):first cycle. start from idx 0. on(1):start from the middle.
    VccbDbgUpdateCellStatusHistory_type update[MAX_HISTORY_NUM];  // 50
} VccbDbgCellStatusHistory_type;

typedef struct
{
    struct {
        uint8_t gnb         : 1; // TRUE or FALSE
        uint8_t cell        : 1; // TRUE or FALSE
    } flag;

    struct {
        uint32_t gnbId;
        uint16_t gnbNum;
    } gnbInfo;

    struct {
        uint8_t cellIdCount;
        uint16_t cellId[MAX_FILTERED_CELLID_NUM];
        uint8_t totalCellNumByGnb;
    } cellInfo;
} VccbDbgLogFilter_type;

typedef struct
{
    uint32_t mask;
#define NO_VCCB_LOG_ITSCP_UPLOAD 0x0001
#define NO_VCCB_LOG_ITSCP_PRINT  0x0002
#define NO_VCCB_LOG_DSH_PRINT    0x0004
    uint8_t logCtlFlag;          // off(0). on(1). Log Control Function On/Off                           default : on(1)
    uint8_t logCtlMask;          // 0:dsh+itscp+upload 1:dsh+itscp 5:itscp 7:no logging.                 default : 5
    uint8_t logStoreDebugTrace;  // on(1): store only call logs which is debugTrace on.                  default :
                                 // off(0)
    uint8_t logStoreDebugLevel;  // Debug Log store level.                                               default :
                                 // 2(PL_ERROR)
    uint8_t logStoreStatistics;  // off(0):not store statistics. on(1): store statistics log.            default : on(1)
    uint8_t logStoreStatMsgCnt;  // off(0):not store message count statistics. on(1): store log.         default :
                                 // off(0)
    uint8_t logStoreKeepAlive;  // off(0):not store keepalive msg on(1): store keepalive msg            default : off(0)
    uint8_t logStoreSctpMsg;    // off(0):not store sctpData message. on(1): store sctp msg.            default : off(0)
    uint8_t logStoreCsl;        // off(0):not store CslDataNoti message. on(1): store msg.              default : off(0)
    uint8_t logStoreTraceMsg;   // off(0):not store TraceDataNoti message. on(1): store msg.            default : off(0)
    uint8_t logStoreSonMsg;     // off(0):not store SonResourceStatusInd message. on(1): store msg.     default :
                                // off(0)
    uint8_t logStoreCallCountReport;  // off(0):not store Call count. on(1): store Call count log.            default :
                                      // on(1)
    uint8_t logMcoSlbOpCountResetTimer; // off(0): not store timInternalMcoSlbOperationCountResetTimer message. on(1): store msg
                                        // default: off(0)
    uint8_t logMscGen;          // off(0). on(1). Log Control Msc-Gen On/Off                            default : off(0)
    uint8_t logMscGenDebugLevel;// Debug Log store level.                                               default : 2(PL_ERROR)
    uint8_t logMsgGenInterfaceFilterForFlow;
    uint8_t logMsgGenInterfaceFilterForFlowContent;

    uint8_t logStoreStatThrdInternalMsg; // off(0): not store internal msg for statistics thread        default : off(0)
                                         // on(1): store internal msg for statistics thread

    VccbDbgLogFilter_type filter;
} VccbDbgLog_type;

#ifdef __NVGNB__
#define DEFAULT_MSG_QUEUEING_COUNT_PER_THREAD   600
#else
#define DEFAULT_MSG_QUEUEING_COUNT_PER_THREAD   3000
#endif
#define DEFAULT_MSG_QUEUEING_COUNT_PER_UE       6

#define MAX_MSG_QUEUEING_COUNT_PER_UE           DEFAULT_MSG_QUEUEING_COUNT_PER_UE
#define MAX_LOG_HIST_UE_MSG_QUEUEING_INFO       2

typedef struct
{
    uint32_t callId;
    struct timeval loggingTime;

    uint16_t requestMessageId;
    uint8_t  callType;
    uint8_t  stateCmd;
    uint16_t callState;
    uint16_t numQueueingMsg;
    uint16_t queueingMsgId[MAX_MSG_QUEUEING_COUNT_PER_UE];
    uint16_t queueingAction[MAX_MSG_QUEUEING_COUNT_PER_UE];
} callMsgQueueFullHistInfo_type;

typedef struct
{
    uint32_t numOfKey;                        // how many keys that msgQueueMap has
    uint32_t numOfCurMsgQueuePerThread;       // current Message Queue Size per thread

    uint32_t msgQueueFullCountPerThread;      // how many queue full occurred per thread
    uint32_t msgQueueFullCountPerUe;          // how many queue full occurred per UE

    uint32_t keyRemovedCountByAudit;          // how many keys removed by audit
    uint32_t curMsgQueuePerThreadAuditCount;  // how many numOfCurMsgQueuePerThread has been fixed by audit

    uint16_t peakMsgQueueCountByThread;       // peak queue size per thread
    uint16_t peakMsgQueueCountByAudit;        // peak queue size by audit thread

    uint16_t numOfHistoryOfUeQueueFull;       // history count when queue full occurred on UE
    callMsgQueueFullHistInfo_type ueMsgHistInfo[MAX_LOG_HIST_UE_MSG_QUEUEING_INFO];
} VccbDbgMsgQueueMapHistory_type;             // per thread

typedef enum
{
    MRDC_BUFF_CAUSE_NORMAL,
    MRDC_BUFF_CAUSE_NO_AVAIL_RESOURCE,  // for allocation
    MRDC_BUFF_CAUSE_INVALID_REQ,        // for free(bufferType or address alignment is invalid)
    MRDC_BUFF_CAUSE_INVALID_CALLID,     // for free(callId is mismatched with that of allocation)
    MRDC_BUFF_CAUSE_ALREADY_FREE,       // already free by previous action
    MRDC_BUFF_CAUSE_OTHER_FAILURE,      // etc
    MRDC_BUFF_CAUSE_END
} enumMrdcBuffCause_type;

typedef struct
{
    uint32_t attempt[VCCB_CALL_THREAD_NUM];
    uint32_t success[VCCB_CALL_THREAD_NUM];
    uint32_t fail[MRDC_BUFF_CAUSE_END];  // Check presence of failure. Not accureate due to multi thread env
} buffCtrlStatsType;

typedef struct VccbGnbAuditInfo_s
{
    uint16_t count;
    uint16_t srcGnb[MAX_GNB_CU_CP_FUNCTION_PER_SYS];
    uint16_t dstGnb[MAX_GNB_CU_CP_FUNCTION_PER_SYS];
    uint32_t targetGnbId[MAX_GNB_CU_CP_FUNCTION_PER_SYS];
    time_t auditTime;
} VccbGnbAuditInfo_type;

typedef struct VccbDbgGnbAuditHistoryInfo_s
{
    int16_t curIdx;     // default: -1
    uint8_t cycleFlag;  // off(0):first cycle. start from idx 0. on(1):start from the middle.
    VccbGnbAuditInfo_type auditHistory[MAX_HISTORY_NUM];

    uint16_t internalAuditStbGnbNumInfoCount; // timinternalAuditStbGnbNumInfo count (maxCount: 120);
} VccbDbgGnbAuditHistoryInfo_type;

typedef struct VccbTempGnbInfo_s
{
    // HAS backup area of GNBINFO that needs to be audit
    gnbEnvInfo_type env;
    gnbDuInfo_type gnbDu[MAX_GNB_DU_PER_GNB_CU_CP];
    gnbSupportedBandInfo_type supportedFreqBandInfo;
} VccbTempGnbInfo_type;

typedef struct
{
    buffCtrlStatsType allocStats[MAX_BUFF_TYPE_FOR_STATS];
    buffCtrlStatsType freeStats[MAX_BUFF_TYPE_FOR_STATS];
    struct
    {
        uint32_t attempt;
        uint32_t success;
        uint32_t fail[MRDC_BUFF_CAUSE_END];
    } freeStatsAudit[MAX_BUFF_TYPE_FOR_STATS];
} VccbDbgMrdcBuffStats_type;

/* PLD Audit History */
typedef struct
{
    int relId;
    int readResult;
    time_t updateTime;
} VccbDbgUpdatePldAuditHistory_type;

typedef struct
{
    int16_t curIdx;     // default: -1
    uint8_t cycleFlag;  // off(0):first cycle. start from idx 0. on(1):start from the middle.
    VccbDbgUpdatePldAuditHistory_type update[MAX_HISTORY_NUM];  // 50
} VccbDbgPldAuditHistory_type;

typedef struct
{
    int32_t callId;
    uint64_t dumpSize;
    struct timeval updateTime;
} VccbDbgUpdateHasDumpHistory_type;

typedef struct
{
    int16_t curIdx;     // default: -1
    uint8_t cycleFlag;  // off(0):first cycle. start from idx 0. on(1):start from the middle.
    VccbDbgUpdateHasDumpHistory_type update[MAX_HISTORY_NUM];  // 50
} VccbDbgHasDumpHistory_type;

typedef struct
{
    uint8_t isMainUnit : 1;  // TRUE=cmc, FALSE=cpc
    uint8_t isInitProc : 1;  // Update during Initial Procedure(Not by Notification)
    time_t updateTime;
    union
    {
        HasActMainUnitState_Type cmc;
        HasUnitState_Type cpc;
    };
} VccbHasInfo_type;

typedef struct
{
    int16_t curIdx;
    uint8_t cycleFlag;                          // off(0):first cycle. start from idx 0. on(1):start from the middle.
    VccbHasInfo_type hasHist[MAX_HISTORY_NUM];  // 50
} VccbDbgHasEventHistory_type;

typedef struct
{
    union
    {
        struct
        {
            uint8_t nedc : 1,
                    nrdc : 1,
                    rsvd : 6;
        };
        uint8_t value;
    } usage;

    servCellIndexRangeSCG_type nedc;
    servCellIndexRangeSCG_type nrdc;
} VccbDbgMrdcServCellIndexRangeSCG_type;

typedef struct
{
    uint32_t maxReceivedMrlSize;
} VccbDbgMrlInfo_type;

typedef struct VccbDbgInfo_s
{
    struct VccbDbgFlag_s
    {
        uint64_t checkSsbFreqFlag   : 1;  // 00
        uint64_t reserved           : 1;  // 01
        uint64_t errorInd           : 1;  // 02
        uint64_t fdebug_msg         : 1;  // 03
        uint64_t fdis_flow          : 1;  // 04
        uint64_t fdis_periodic_stat : 1;  // 05
        uint64_t fdis_port          : 1;  // 06
        uint64_t fdis_stat          : 1;  // 07
        uint64_t flog_flow          : 1;  // 08
        uint64_t flog_msgScreen     : 1;  // 09

        uint64_t manualFlag                           : 1;  // 10
        uint64_t printBitFlag                         : 1;  // 11
        uint64_t statusDebug                          : 1;  // 12
        uint64_t extDbDbug                            : 1;  // 13
        uint64_t extDbTestFlag                        : 1;  // 14
        uint64_t forcedIncludeRRC                     : 1;  // 15
        uint64_t isAlwaysFailVerificationOfResumeMacI : 1;  // 16 : If set TRUE, ResumeMacI verification always fails.
        uint64_t isDiscardRnaUpdateMessage            : 1;  // 17
        uint64_t isForcedChangeResumeCauseToRnaUpdate : 1;  // 18 : If set TRUE, ResumeCause in RRCResumeRequest1
                                                            // message is always recognized as RNA_Update.
        uint64_t isSkipFilterAppliedFreqBandList : 1;       // 19 : set TRUE if do not need to check
                                                            // appliedFreqBandListFilter(Capability)

        uint64_t isSkipSnssaiSelection         : 1;  // 20 : set TRUE if do not need to check supportedSNSSAI(Slice)
        uint64_t isSupportSCellReconfigAfterHO : 1;  // 21
        uint64_t logActionQueue                : 1;  // 22
        uint64_t logAnr                        : 1;  // 23
        uint64_t logE1                         : 1;  // 24
        uint64_t logFullConfig                 : 1;  // 25
        uint64_t logHoMrAction                 : 1;  // 26
        uint64_t logHoTargetSelection          : 1;  // 27
        uint64_t logHoTargetXnSelection        : 1;  // 28
        uint64_t logInitFlag                   : 1;  // 29

        uint64_t logIntraNrBW  : 1;  // 30
        uint64_t logMro        : 1;  // 31
        uint64_t logOnDemandHO : 1;  // 32
        uint64_t logOnFlow     : 1;  // 33
        uint64_t logPlmn       : 1;  // 34
        uint64_t logRelFunc    : 1;  // 35
        uint64_t logSliceAware : 1;  // 36
        uint64_t logTraceCsl   : 1;  // 37
        uint64_t logUpm        : 1;  // 38
        uint64_t logYang       : 1;  // 39

        uint64_t monitoringBhcaTimeDiff           : 1;  // 40
        uint64_t mroSkipFindNbrGnbCell            : 1;  // 41
        uint64_t nbrYangRead                      : 1;  // 42
        uint64_t noEnqueueDlNasDuringOtherNasProc : 1;  // 43
        uint64_t noEnqueueDuringHO                : 1;  // 44
        uint64_t noEnqueueDuringReconfigComplete  : 1;  // 45
        uint64_t noEnqueueDuringSNInitSgNBMod     : 1;  // 46
        uint64_t noHoBtwSaAndNsaCell              : 1;  // 47
        uint64_t noInterSnHandover                : 1;  // 48
        uint64_t pldAuditFlag                     : 1;  // 49

        uint64_t prioritizedMeasObjectIds           : 1;  // 50
        uint64_t refusedInterFr1TargetCell          : 1;  // 51
        uint64_t refusedIntraFr1TargetCell          : 1;  // 52
        uint64_t reuseDrbId                         : 1;  // 53
        uint64_t saHO_AlwaysRespFlagClearForStartHO : 1;  // 54 : It operates when you want to always turn off the flag
                                                          // during HO.
        uint64_t setAmbrUl_max                  : 1;      // 55
        uint64_t sliceAwareforSN                : 1;      // 56
        uint64_t logVoNrLb                      : 1;      // 57
        uint64_t logMeasurements                : 1;      // 58
        uint64_t tgtRspBasedQfiFwd              : 1;      // 59

        uint64_t checkInvalidBuffer                                  : 1;  // 60
        uint64_t logSrb3                                             : 1;  // 61
        uint64_t rollbackEndcInterDuHoWhenRejectByMn                 : 1;  // 62
        uint64_t logCsl                                              : 1;  // 63
        uint64_t forcedConditionalHandover                           : 1;  // 64
        uint64_t logTrfHo                                            : 1;  // 65
        uint64_t choSendF1ComplAfterReceivingAccesSsucessAndRrcCompl : 1;  // 66
        uint64_t choNotIncludeAttemptCondReconfig                    : 1;  // 68
        uint64_t logHoOverloadedTgtGnbMgmt                           : 1;  // 69
        uint64_t nonNbrHo                                            : 1;  // 70
        uint64_t drxConfig                                           : 1;  // 71
        uint64_t activeSnTermDrbSuccessionOfSrcSnInNrdcSN            : 1;  // 72
        uint64_t disabledCheckEmptySelectedTAI                       : 1;  // 73
        uint64_t keepIrntiUntilProcComplt                            : 1;  // 74
        uint64_t RrcUnpackMgr                                        : 1;  // 75
        uint64_t isSkipTimeCriticalMsg4Function                      : 1;  // 76
        uint64_t isSkipRedirectionCondition                          : 1;  // 77
        uint64_t nbrGnbCellExtCgiListTest                            : 1;  // 78 : test-only ext-CGI slot behavior flag
        // uint64_t reserved1                     : x;        // ~ 127 -- auto padding

        uint64_t reserved1;  // 128 ~ 191

        /* MRDC - 192 ~ 255 */
        uint64_t logMrdcAddition                                : 1;  // 192
        uint64_t logMrdcAllowedBCList                           : 1;  // 193
        uint64_t logMrdcBandCombList                            : 1;  // 194
        uint64_t logMrdcFsCombList                              : 1;  // 195
        uint64_t mrdcHO_NotExistMnTerm_IfSnRel_HoCancelAndSnRel : 1;  // 196 : If MN DRB not exist and 'HO with SN Rel',
                                                                      // HO Cancel -> SnRel.
        uint64_t mrdcHO_NotExistMnTerm_ToSnRelease_Inter        : 1;  // 197 : If MN DRB not exist, HO with SN Rel.
        uint64_t mrdcHO_HandoverTriggerStopAndToSnRelease_Intra : 1;  // 198 : Stop Handover and perform SN Release
                                                                      // procedure.
        uint64_t pdcchBlindDetectionSCG      : 1;                     // 201
        uint64_t triggerNgHO                 : 1;                     // 202
        uint64_t nrdcRreFallback             : 1;  // 203 - Intra gNB RRE for NRDC goes to fallback to RRC SETUP
        uint64_t logMrdcPreemption           : 1;  // 204
        uint64_t snNGuTnlUpdate              : 1;  // 205
        uint64_t mrdcScgFailureSuspendResume : 1;  // 206 -ON is NRDC SCG Failure Handling - Suspend, Resume Mode
        uint64_t logFreqBandList : 1;  // 207 - Print currently Supported Freq Band List Info for UCE / UCI Procedure.
        uint64_t mrdcScgFailureSuspendResumeNoF1Proc                     : 1;  // 208
        uint64_t mrdcScgFailureSuspendResumeAcceptSameTargetPSCell       : 1;  // 209
        uint64_t mrdcScgFailureSuspendResumePDCP                         : 1;  // 210
        uint64_t mrdcScgFailureSuspendResumeMeasConfig                   : 1;  // 211
        uint64_t mrdcScgFailureSuspendResumeMasterCellGroup              : 1;  // 212
        uint64_t mrdcScgFailureSuspendResumeSnMobility                   : 1;  // 213
        uint64_t forcelyUeNrCapaEnquiry                                  : 1;  // 214
        uint64_t forcelySetUeCapaSize                                    : 1;  // 216
        uint64_t disabledPartialUlNguUpTnlUpdatePerPDUSess               : 1;  // 217
        uint64_t logMcoBcBandPerm                                        : 1;  // 218
        uint64_t logMcoCheckBc                                           : 1;  // 219
        uint64_t logMcoUeCapa                                            : 1;  // 220
        uint64_t logCho                                                  : 1;  // 221
        uint64_t mrdcHO_IntraGnbHoCancelWithMRDC                         : 1;  // 222
        uint64_t logHandoverFailure                                      : 1;  // 223// 224
        uint64_t ignoreTransportRscUnavailableforPduSessModifyCfm        : 1;  // 224
        uint64_t mrdcHO_useSnModificationProcedure_duringMcgOnlyMobility : 1;  // 225 : false (use SN mobility procedure
                                                                               // without SN rach)
        uint64_t logMrs                     : 1;                               // 226
        uint64_t logUeCapaEnquiry           : 1;                               // 227
        uint64_t SNAdditionRejectE1Mod      : 1;                               // 228
        uint64_t SNAdditionUpFailTest       : 1;                               // 229
        uint64_t logCaExtended              : 1;                               // 230 : Carrier Aggregation extended loging
        uint64_t endcPmaxFR1                : 1;                               // 231
        uint64_t reserved2                  : 1;                               // 232
        uint64_t logSaLb                    : 1;                               // 233 : FGR-LC0703 (Load Balancing between FR1 Carriers)
        uint64_t logZimsiPrint              : 1;                               // 234
        uint64_t logStmsiPrint              : 1;                               // 235
        uint64_t logImeisvPrint             : 1;                               // 236
        uint64_t mcoLbOldAlgorithm          : 1;                               // 237
        uint64_t disableReuseDlForSnPdu     : 1;                               // 238
        uint64_t logMcoScc                  : 1;                               // 239
        uint64_t includePDCPConfigInRRCReconfig : 1;                           // 240
        uint64_t skipCheckUeRrcSegmentation : 1;                               // 241
        uint64_t logSliceLb                 : 1;                               // 242 : SVR23B FGR-LC0710
        uint64_t logUlPathControl           : 1;                               // 243
        uint64_t disable_RestrictingGnbTobeSnByOvld : 1;                       // 244 : to disable the functionality of preventing the gnb from being selected as NRDC-SN
        uint64_t mrdcHO_SnMobilityDuplicatePciReportCgiHandover : 1;           // 245 : to enable SN mobility duplicate PCI reportCGI handover
        uint64_t allowOtherVendorSn         : 1;                               // 246, if this flag is on, mn should allow nr-dc addition even if the candidated sn is otherVendor.
        uint64_t allowOtherVendorMn         : 1;                               // 247, if this flag is on, sn should accept nr-dc addition request from mn even if it is otherVendor.
        uint64_t logIratLb                  : 1;                               // 248 : SVR23B FGR-LC0711
        uint64_t nrdcHO_PSCellAlgorithmByOrigin :1;                            // 249 : Mobility For NR-DC (Default OFF)
        uint64_t reserved3                  : 1;                               // 250 : Deprecated since 26A
        uint64_t reportCgiHandoverNewAlgorithm  : 1;                           // 251 : use STATE_RLF_WaitRRE when VCCB receives RLF Failure.
        uint64_t logTraffic                 : 1;                               // 252
        uint64_t disabledSnReleaseWhenTriggeringHoWhileScgSuspend : 1;         // 253
        uint64_t disabledSnModRejectForQueryWhileScgSuspend :1;                // 254
        uint64_t forcedSpCellIndexation      : 1;                              // 255
        uint64_t forceSnModRejectOnce      :1;                                 // 256
        uint64_t logUplinkStatusTriggeredMobility    :1;                                 // 257
        uint64_t logDrbPartial               : 1;                              // 258
        uint64_t drbPartialFunctionDisable   : 1;                              // 259
        uint64_t logRedCap                   : 1;                              // 260
        uint64_t logMco                      : 1;                              // 261
        uint64_t logCa                       : 1;                              // 262
        uint64_t logFpMc                     : 1;                              // 263 : SVR24A FGR-MC1022
        uint64_t logNgUeCapaCheckReq         : 1;                              // 264
        uint64_t logRoHC                     : 1;                              // 266
        uint64_t getPldDataUsingOnlyDbiApi   : 1;                              // 267
        uint64_t DACC_forwardMaskedImeisv    : 1;                              // 268 : FGR-CC0351 / Device Aware Call Control / FR10 / Enabled by default.
        uint64_t triggerSnRelForcelyDuetoSnModFailforBearerTypeChg  : 1;       // 269
        uint64_t logNrdcBasic                : 1;                              // 270
        uint64_t notAllowedIntraCellHO_BasicHO  : 1;                           // 271
        uint64_t offF1RelCmpltRespFlagInAllState: 1;                           // 272
        uint64_t logAmfSelection                   : 1;                        // 273
        uint64_t applySnInitFullConfigInMn_24B     : 1;                        // 274
        uint64_t otherVendorNrdcTest                                : 1;       // 275
        uint64_t logIdleLB                         : 1;                        // 276
        uint64_t redirectionOnlyModeControlForFallBackMr            : 1;       // 277 : SVR24B FGR-MC1028
        uint64_t isSkipVpmCollect                  : 1;                        // 278
        uint64_t isSkipVpmUpdate                   : 1;                        // 279
        uint64_t logUeSpecReportCfg                : 1;                        // 280
        uint64_t logScgUeHistory                   : 1;                        // 281
        uint64_t logEHC                            : 1;                        // 282
        uint64_t logNcMc                           : 1;                        // 283 : SVR24B FGR-MC1007
        uint64_t taintMeasConfigAfterRRE           : 1;                        // 284
        uint64_t removeAllMeasConfigIdsAfterRRE    : 1;                        // 285
        uint64_t logMeasReportPrinter              : 1;                        // 286
        uint64_t sendXnUeCtxRelWoXnRelReq          : 1;                        // 287
        uint64_t logRrcReleaseInfo                 : 1;                        // 288
        uint64_t mcoLbCacheEnable                  : 1;                        // 289
        uint64_t isSkipHasDirectSync               : 1;                        // 290
        uint64_t logBasicStatCsl                   : 1;                        // 291
        uint64_t logRrcSegmentation                : 1;                        // 292
        uint64_t logNsaStatCsl                     : 1;                        // 293 : SVR25A FGR-CC5000 FR3590 && FGR-CC5005 FR40
        uint64_t statThreadUsage                   : 1;                        // 294
        uint64_t allowVonrApiTest                  : 1;                        // 295
        uint64_t logSecurityMode                   : 1;                        // 296
        uint64_t logRetainCsl                      : 1;                        // 297
        uint64_t logE1Preemption                   : 1;                        // 298
        uint64_t ltm_replaceChoMrAsLtm             : 1;                        // 299 : LTM or CHO
        uint64_t ltm_parallelOperation             : 1;                        // 300
        uint64_t logHoStatCsl                      : 1;                        // 301 : SVR25B FGR-MC1009 FR600
        uint64_t sendSecuModeCmdInF1CtxtSetupReq   : 1;                        // 302 : SVR25B FGR-CC3101 FR50
        uint64_t notAllowPduReqInUserInactRel      : 1;                        // 303 : SVR25B FGR-CC3101 FR98
        uint64_t intraGnbNbrSaAvailableCheckEnable : 1;                        // 303 : SVR25B FGR-CC3101 FR98
        uint64_t needSecurityModeCompleteForRedirection             : 1;       // 304 : SVR25B FGR-SV0201
        uint64_t isFailToRrcInactive_type01        : 1;                        // 305 : SVR25B FGR-CC0103
        uint64_t isFailToRrcInactive_type02        : 1;                        // 306 : SVR25B FGR-CC0103
        uint64_t logHoServiceType              : 1;                            // 307 : SVR25B FGR-MC1010
        uint64_t disableFullUeSliceMBR             : 1;                        // 308 : SVR25B FGR-CC0431
        uint64_t forcedFail_Security               : 1;                        // 309 : SVR25B FGR-CC3101
        uint64_t forcedFail_Dss                    : 1;                        // 310 : SVR25B FGR-CC3101
        uint64_t logHoFailedCellList               : 1;                        // 311
        uint64_t logAllowedBcMnFilter              : 1;                        // 312 : SVR25A Patch FGR-RC0100
        uint64_t logLtm                            : 1;                        // 313 : SVR25B PMB
        uint64_t ltmL1MrSupport                    : 1;                        // 314 : SVR25B PMB
        uint64_t logRrcConnStat                    : 1;                        // 315
        uint64_t logSaTrfMon                       : 1;                        // 316 : SVR25A P1
        uint64_t nrdcScgQuerySkip                  : 1;                        // 317
        uint64_t nrdcXnModNoScgRbConfig            : 1;                        // 318
        uint64_t nrdcMrControl                     : 1;                        // 319
        uint64_t logMnBcReselection                : 1;                        // 320
        uint64_t nrdcNoScgCellGrpCfg               : 1;                        // 321
        uint64_t logCaCsl                          : 1;                        // 322 SVR26A FGR-RC0100
        uint64_t logRacs                           : 1;                        // 323
        uint64_t logRacsTimer                      : 1;                        // 324

        uint64_t ltmCandAddModIncludeWoCellGroup   : 1;                        // 325
        uint64_t ltmCandidateModifyParallel        : 1;                        // 326
        uint64_t ltmCellSwitchExeResumeAnyMsg      : 1;                        // 327
        uint64_t ltmMultiUpSkip                    : 1;                        // 328
        uint64_t periodicLb                        : 1;                        // 329 SVR26A FGR-LC0703
        uint64_t logUmfs                           : 1;                        // 330 : FGS-SF0701 / UE Measurement for SON
        uint64_t logTsmDuIw                        : 1;                        // 331: FGR-CC5500 25B Patch
        uint64_t logEmergencyVonrCall              : 1;                        // 332 : SVR25B FGR-SV0202
        uint64_t logCaTsm                          : 1;                        // 333 : SVR25B Patch FGR-RC0100
        uint64_t cacRedirect_simTestVal            : 1;                        // 334 : SVR26B FGR-LC0707
        uint64_t logCandInfoPrint                  : 1;                        // 334
        uint64_t basicSa_SimTest                   : 1;                        // 335 : SVR26B FGR-CC3101
        uint64_t grStatusUsingFlag                 : 1;                        // 336 : SVR26B OAMP-HA0201
        uint64_t logValkeyAccess                   : 1;                        // 337
        // uint64_t reserved2                     : x;                    // -- auto padding
    } flag;

    struct VccbDbgValue_s
    {
#ifdef NEW_HOST_SIM
        uint16_t periodicFamilyToLog[MAX_FAMILIES_NUM];
#endif
        int32_t callIdForPartialDumpTest;
        int32_t mroDiffTime;
        uint8_t debugValueSRB3;
        uint8_t bufferInitByte;
        uint32_t restrictedGnbLifeTime;
        uint8_t mcoMaxMfbiCc;
        uint8_t scgUeHistoryInformationControl; /* scgUeHistoryInformationControl_type, 0: Both, 1: NRDC Only, 2: NEDC Only */
        uint32_t maxThreadCollectItem;
        uint32_t maxThreadUpdateItem;
        uint32_t testCommonVal; // This value will be used when debug flag (e.g., cacRedirect_simTestVal, basicSa_SimTest, etc.) is ON

#ifdef NEW_HOST_SIM
        struct {
            uint8_t sw:1;
            uint8_t val:7;
        } statTestMode_DUID, statTestMode_GLOBALID, statTestMode_CP;
#endif

    } value;

    VccbDbgLog_type log;

    /*RRC Empty Reconfiguration */
    struct VccbDbgEmptyRrcRecfg_s
    {
        uint32_t nSkipCount_bitmask;
        uint32_t nSkipCount_pktlen;
    } emptyRrcRecfg;

    uint16_t ignoreMrSpid;

    uint8_t localLevel;  // used for DSH debug
    uint16_t offsetPort;

    /* Host Simulation */
    char pldPath[50];  // gPldPath
    char subfix[10];   // subfix
    uint16_t enbType;  // gEnbType
    uint32_t enbId;    // gEnbId

    /* Monitoring BHCA */
    VccbDbgMonitoringBhca_type monitoringBhca;

    /* Log Fishing */
    struct VccbDbgLogFishing_s
    {
        struct timeval lastUploadTime;
        uint16_t minLogKeepingTime;             // LogFishing minimum log keeping time(minute)
        uint16_t maxRequestPerSecondPerThread;  // LogFishing maximum request count per second per thread
        uint16_t uploadPeriod;                  // LogFishing auto upload period(hour)
        uint8_t status;                         // LogFishing CRR ON/OFF status(VCCB_FLAG_ON or VCCB_FLAG_OFF)

    } logFishing;

#define MAX_TRACE_IMSI 10
#define MAX_IMSI_DIGIT 15

    struct imsiTraceInfo_s
    {
        uint8_t numOfImsi;
        uint8_t imsiIdx[MAX_TRACE_IMSI];
        /* length of IMSI digit: 14 or 15*/
        uint8_t IMSILen[MAX_TRACE_IMSI];
        uint8_t IMSI[MAX_TRACE_IMSI][MAX_IMSI_DIGIT];  // IMSI
        /* length of Z_IMSI digit(byte): 8*/
        uint8_t ZIMSILen[MAX_TRACE_IMSI];
        uint8_t ZIMSI[MAX_TRACE_IMSI][MAX_IMSI_BYTE];  // ZIMSI
    } imsiTraceInfo;

    /* Cell Status History */
    VccbDbgCellStatusHistory_type statusHist[MAX_CELL_PER_VNF];

    /* Msg Queue Map History */
    VccbDbgMsgQueueMapHistory_type msgQueueMapHist[VCCB_CALL_THREAD_NUM];

    MrdcTypePrefer_type mrdcTypePrefer;  // NRDC
    VccbDbgMrdcServCellIndexRangeSCG_type mrdcServCellIndexRangeSCG;
    VccbDbgMrdcBuffStats_type mrdcBuffCtrlStats;

    /* PLD Audit History */
    VccbDbgPldAuditHistory_type pldAuditHist;

    VccbDbgHasDumpHistory_type hasDumpHist;
    uint8_t confdRestoreTest;

    /* HAS Event History */
    VccbDbgHasEventHistory_type hasEventHist;

    /* UE Capability Information Control*/
    struct VccbDbgUeCapaControl_s
    {
        uint32_t nr_length;
        uint32_t mrdc_length;
        uint32_t eutra_length;
    } ueCapabilityControl;

    VccbDbgMrlInfo_type mrlInfo;
#ifdef IPC_TEST
    struct timespec jumpTime;
    int8_t isSetjumpTime;
    uint8_t checkGbrUe;    // SVR24B FGS-SF0502
    time_t diffTime;      // SVR24B FGS-SF0502
    uint8_t testPartialDrb; // SVR25A FGR-MC3002
    uint8_t testForcedReleaseRedCap; // SVR25A FGR-MC1025
    uint8_t testAmfSelection; // SVR25A FGR-CC6001
    uint8_t testInterGnbRREFallback; // SVR26A FGR-CC0102
    long testTimeValue;    // SVR26A FGR-LC0705
    long testCurrTime;     // SVR26A FGR-LC0705
#endif

    /* gNB Audit History */
    VccbDbgGnbAuditHistoryInfo_type gnbAuditHist;

} VccbDbgInfo_type;

/*
typedef struct VccbLocalStatCC_type_s
{
    uint32_t StatRRCReconfig[MAX_RRC_RECONFIG_TYPE][MAX_CACELL_PER_VNB];
    uint32_t StatCallDrop[MAX_CALL_DROP_TYPE][MAX_CACELL_PER_VNB];
    uint32_t StatXRABEstab[MAX_XRAB_ESTAB_TYPE][MAX_CACELL_PER_VNB];
    uint32_t StatXRABEstabAdd[MAX_XRAB_ESTAB_ADD_TYPE][MAX_CACELL_PER_VNB];
    uint32_t StatXRABErase[MAX_XRAB_ERASE_TYPE][MAX_CACELL_PER_VNB];
    uint32_t StatXRABRel[MAX_XRAB_REL_TYPE][MAX_CACELL_PER_VNB];
    uint32_t StatHoIntra[MAX_HO_INTRA_TYPE][MAX_CACELL_PER_VNB];
    uint32_t StatHoX2Out[MAX_HO_X2_OUT_TYPE][MAX_CACELL_PER_VNB + 1];   // Special size - last idx for unknown CAcellNum
    uint32_t StatHoX2In[MAX_HO_X2_IN_TYPE][MAX_CACELL_PER_VNB + 1];     // Special size - last idx for unknown CAcellNum
    uint32_t StatHoTime[MAX_HO_TIME_TYPE][MAX_CACELL_PER_VNB];
    uint32_t StatHoTriggeringSCell[MAX_HO_TRIGGERING_SCELL_TYPE][MAX_CACELL_PER_VNB];
    uint32_t StatHoTriggeringTCell[MAX_HO_TRIGGERING_TCELL_TYPE][MAX_CACELL_PER_VNB];
    uint32_t StatHoX2Ranking[MAX_HO_X2_RANKING_TYPE][MAX_EXTERNAL_VNB_PER_SYS];
    uint32_t StatDiscardedCall[MAX_DISCARDED_CALL_TYPE];
    uint32_t StatRejectedCall[MAX_REJECTED_CALL_TYPE];
} VccbLocalStatCC_type;
*/
typedef struct VccbStatMsg_Type_s
{
    uint32_t prevCount;
    uint32_t currCount;
} VccbStatMsg_Type;

typedef struct VccbNgrrcMsgStat_type_s
{
    /* NRRRC Message */
    VccbStatMsg_Type NRRRC_RrcReconfiguration;
    VccbStatMsg_Type NRRRC_MeasurementReport;
    VccbStatMsg_Type NRRRC_RrcReconfigurationComplete;
    VccbStatMsg_Type NRRRC_RrcSetup;
    VccbStatMsg_Type NRRRC_RrcReject;
    VccbStatMsg_Type NRRRC_RrcRelease;
    VccbStatMsg_Type NRRRC_SecurityModeCommand;
    VccbStatMsg_Type NRRRC_UECapabilityEnquiry;
    VccbStatMsg_Type NRRRC_RrcSetupRequest;
    VccbStatMsg_Type NRRRC_RrcSetupComplete;
    VccbStatMsg_Type NRRRC_SecurityModeComplete;
    VccbStatMsg_Type NRRRC_SecurityModeFailure;
    VccbStatMsg_Type NRRRC_UECapabilityInformation;
    VccbStatMsg_Type NRRRC_ULInformationTransferMRDC;   // NRDC
    VccbStatMsg_Type NRRRC_SCGFailureInformation;       // NRDC
    VccbStatMsg_Type NRRRC_SCGFailureInformationEUTRA;  // NEDC_SCG_FAILURE_20C
    VccbStatMsg_Type NRRRC_UEAssistanceInformation;
    VccbStatMsg_Type NRRRC_RrcReestablishmentRequest;
    VccbStatMsg_Type NRRRC_RrcReestablishment;
    VccbStatMsg_Type NRRRC_RrcReestablishmentComplete;
    VccbStatMsg_Type NRRRC_RrcResumeRequest1;
    VccbStatMsg_Type NRRRC_RrcResume;
    VccbStatMsg_Type NRRRC_RrcResumeComplete;
    VccbStatMsg_Type NRRRC_MobilityFromNRCommand;
    VccbStatMsg_Type NRRRC_UEInformationRequest;
    VccbStatMsg_Type NRRRC_UEInformationResponse;
    VccbStatMsg_Type NRRRC_ULDedicatedMessageSegment;
    VccbStatMsg_Type NRRRC_Others;

    /* E1AP Message */
    VccbStatMsg_Type E1_BearerContextSetupRequest;
    VccbStatMsg_Type E1_BearerContextSetupResponse;
    VccbStatMsg_Type E1_BearerContextSetupFailure;
    VccbStatMsg_Type E1_BearerContextModificationRequest;
    VccbStatMsg_Type E1_BearerContextModificationResponse;
    VccbStatMsg_Type E1_BearerContextModificationFailure;
    VccbStatMsg_Type E1_BearerContextModificationRequired;
    VccbStatMsg_Type E1_BearerContextModificationConfirm;
    VccbStatMsg_Type E1_BearerContextReleaseCommand;
    VccbStatMsg_Type E1_BearerContextReleaseComplete;
    VccbStatMsg_Type E1_BearerContextReleaseRequest;
    VccbStatMsg_Type E1_BearerContextInactivityNotification;
    VccbStatMsg_Type E1_DLDataNotification;
    VccbStatMsg_Type E1_DataUsageReport;
    VccbStatMsg_Type E1_TraceStart;
    VccbStatMsg_Type E1_DeactivateTrace;
    VccbStatMsg_Type E1_GNB_CU_UP_CounterCheckRequest;
    VccbStatMsg_Type E1_ULDataNotification;
    VccbStatMsg_Type E1_Reset;
    VccbStatMsg_Type E1_ResetAcknowledge;
    VccbStatMsg_Type E1_RxErrorIndication;
    VccbStatMsg_Type E1_TxErrorIndication;
    VccbStatMsg_Type E1_GNB_CU_UP_E1SetupRequest;
    VccbStatMsg_Type E1_GNB_CU_UP_E1SetupResponse;
    VccbStatMsg_Type E1_GNB_CU_UP_E1SetupFailure;
    VccbStatMsg_Type E1_GNB_CU_CP_E1SetupRequest;
    VccbStatMsg_Type E1_GNB_CU_CP_E1SetupResponse;
    VccbStatMsg_Type E1_GNB_CU_CP_E1SetupFailure;
    VccbStatMsg_Type E1_GNB_CU_UP_ConfigurationUpdate;
    VccbStatMsg_Type E1_GNB_CU_UP_ConfigurationUpdateAcknowledge;
    VccbStatMsg_Type E1_GNB_CU_UP_ConfigurationUpdateFailure;
    VccbStatMsg_Type E1_GNB_CU_CP_ConfigurationUpdate;
    VccbStatMsg_Type E1_GNB_CU_CP_ConfigurationUpdateAcknowledge;
    VccbStatMsg_Type E1_GNB_CU_CP_ConfigurationUpdateFailure;
    VccbStatMsg_Type E1_E1ReleaseRequest;
    VccbStatMsg_Type E1_E1ReleaseResponse;
    VccbStatMsg_Type E1_GNB_CU_UP_StatusIndication;
    VccbStatMsg_Type E1_Others;

    /* F1AP Message */
    VccbStatMsg_Type F1_ErrorIndication;
    VccbStatMsg_Type F1_UEContextSetupRequest;
    VccbStatMsg_Type F1_UEContextSetupResponse;
    VccbStatMsg_Type F1_UEContextSetupFailure;
    VccbStatMsg_Type F1_UEContextReleaseCommand;
    VccbStatMsg_Type F1_UEContextReleaseComplete;
    VccbStatMsg_Type F1_UEContextModificationRequest;
    VccbStatMsg_Type F1_UEContextModificationResponse;
    VccbStatMsg_Type F1_UEContextModificationFailure;
    VccbStatMsg_Type F1_UEContextModificationRequired;
    VccbStatMsg_Type F1_UEContextModificationConfirm;
    VccbStatMsg_Type F1_UEContextModificationRefuse;
    VccbStatMsg_Type F1_UEMobilityCommand;
    VccbStatMsg_Type F1_UEContextReleaseRequest;
    VccbStatMsg_Type F1_InitialULRRCMessageTransfer;
    VccbStatMsg_Type F1_DLRRCMessageTransfer;
    VccbStatMsg_Type F1_ULRRCMessageTransfer;
    VccbStatMsg_Type F1_PrivateMessage;
    VccbStatMsg_Type F1_AccessAndMobilityIndication;
    VccbStatMsg_Type F1_AccessSuccess;
    VccbStatMsg_Type F1_RRCDeliveryReport;
    VccbStatMsg_Type F1_TraceStart;
    VccbStatMsg_Type F1_DeactivateTrace;
    VccbStatMsg_Type F1_PositioningInformationRequest;
    VccbStatMsg_Type F1_PositioningInformationResponse;
    VccbStatMsg_Type F1_PositioningInformationFailure;
    VccbStatMsg_Type F1_E_CIDMeasurementInitiationRequest;
    VccbStatMsg_Type F1_E_CIDMeasurementInitiationResponse;
    VccbStatMsg_Type F1_E_CIDMeasurementInitiationFailure;
    VccbStatMsg_Type F1_E_CIDMeasurementFailureIndication;
    VccbStatMsg_Type F1_E_CIDMeasurementReport;
    VccbStatMsg_Type F1_E_CIDMeasurementTerminationCommand;
    VccbStatMsg_Type F1_PositioningInformationUpdate;
    VccbStatMsg_Type F1_DUCUCellSwitchNotification;
    VccbStatMsg_Type F1_CUDUCellSwitchNotification;
    VccbStatMsg_Type F1_CUDUMobilityInitiationRequest;
    VccbStatMsg_Type F1_Others;

    /* NGAP Message - SA */
    VccbStatMsg_Type NG_InitialUEMessage;
    VccbStatMsg_Type NG_InitialContextSetupResponse;
    VccbStatMsg_Type NG_InitialContextSetupFailure;
    VccbStatMsg_Type NG_UplinkNASTransport;
    VccbStatMsg_Type NG_UECapabilityInfoIndication;
    VccbStatMsg_Type NG_PDUSessionResourceSetupResponse;
    VccbStatMsg_Type NG_PDUSessionResourceReleaseResponse;
    VccbStatMsg_Type NG_PDUSessionResourceModifyResponse;
    VccbStatMsg_Type NG_UEContextReleaseRequest;
    VccbStatMsg_Type NG_UEContextReleaseComplete;
    VccbStatMsg_Type NG_UEContextModificationRequest;
    VccbStatMsg_Type NG_UEContextModificationResponse;
    VccbStatMsg_Type NG_UEContextModificationFailure;
    VccbStatMsg_Type NG_InitialContextSetupRequest;
    VccbStatMsg_Type NG_DownlinkNASTransport;
    VccbStatMsg_Type NG_PDUSessionResourceSetupRequest;
    VccbStatMsg_Type NG_PDUSessionResourceReleaseCommand;
    VccbStatMsg_Type NG_PDUSessionResourceModifyRequest;
    VccbStatMsg_Type NG_UEContextReleaseCommand;
    VccbStatMsg_Type NG_HandoverRequiredGnbAmf;
    VccbStatMsg_Type NG_HandoverRequestAmfgnb;
    VccbStatMsg_Type NG_HandoverRequestAcknowledgeGnbAmf;
    VccbStatMsg_Type NG_HandoverCommandAmfGnb;
    VccbStatMsg_Type NG_HandoverNotifyGnbAmf;
    VccbStatMsg_Type NG_HandoverPreparationFailureGnbAmf;
    VccbStatMsg_Type NG_HandoverFailureGnbAmf;
    VccbStatMsg_Type NG_HandoverCancelGnbAmf;
    VccbStatMsg_Type NG_HandoverCancelAcknowledgeAmfGnb;
    VccbStatMsg_Type NG_PathSwitchRequestGnbAmf;
    VccbStatMsg_Type NG_PathSwitchRequestAcknowledgeAmfGnb;
    VccbStatMsg_Type NG_PathSwitchRequestFailureAmfGnb;
    VccbStatMsg_Type NG_UEContextResumeRequestAllAmf;
    VccbStatMsg_Type NG_UEContextResumeResponseAmfAll;
    VccbStatMsg_Type NG_UEContextResumeFailureAmfAll;
    VccbStatMsg_Type NG_UEContextSuspendRequestAllAmf;
    VccbStatMsg_Type NG_UEContextSuspendResponseAmfAll;
    VccbStatMsg_Type NG_UEContextSuspendFailureAmfAll;
    VccbStatMsg_Type NG_PDUSessionResourceModifyIndication;
    VccbStatMsg_Type NG_PDUSessionResourceModifyConfirm;
    VccbStatMsg_Type NG_NASNonDeliveryIndication;
    VccbStatMsg_Type NG_PDUSessionResourceNotify;
    VccbStatMsg_Type NG_UERadioCapabilityCheckRequest;
    VccbStatMsg_Type NG_UERadioCapabilityCheckResponse;
    VccbStatMsg_Type NG_RerouteNASRequest;
    VccbStatMsg_Type NG_RRCInactiveTransitionReport;
    VccbStatMsg_Type NG_UETNLABindingRelease;
    VccbStatMsg_Type NG_DownlinkRANStatusTransfer;
    VccbStatMsg_Type NG_UplinkRANStatusTransfer;
    VccbStatMsg_Type NG_DownlinkUEAssociatedNRPPATransport;
    VccbStatMsg_Type NG_UplinkUEAssociatedNRPPATransport;
    VccbStatMsg_Type NG_TraceStart;
    VccbStatMsg_Type NG_TraceFailureIndication;
    VccbStatMsg_Type NG_DeactivateTrace;
    VccbStatMsg_Type NG_CellTrafficTrace;
    VccbStatMsg_Type NG_LocationReportControl;
    VccbStatMsg_Type NG_LocationReportFailureIndication;
    VccbStatMsg_Type NG_LocationReport;
    VccbStatMsg_Type NG_ErrorIndicationRX;
    VccbStatMsg_Type NG_ErrorIndicationTX;
    VccbStatMsg_Type NG_ErrorIndicationUnknownUEID_RX;
    VccbStatMsg_Type NG_ErrorIndicationUnknownUEID_TX;
    VccbStatMsg_Type NG_ErrorIndicationInconsistentRemoteUEID_RX;
    VccbStatMsg_Type NG_ErrorIndicationInconsistentRemoteUEID_TX;
    VccbStatMsg_Type NG_Others;

    /* X2AP Message - ENDC */
    VccbStatMsg_Type X2_ErrorIndication;
    VccbStatMsg_Type X2_SgNBAdditionRequest;
    VccbStatMsg_Type X2_SgNBAdditionRequestAcknowledge;
    VccbStatMsg_Type X2_SgNBAdditionRequestReject;
    VccbStatMsg_Type X2_SgNBReconfigurationComplete;
    VccbStatMsg_Type X2_SgNBModificationRequest;
    VccbStatMsg_Type X2_SgNBModificationRequestAcknowledge;
    VccbStatMsg_Type X2_SgNBModificationRequestReject;
    VccbStatMsg_Type X2_SgNBModificationRequired;
    VccbStatMsg_Type X2_SgNBModificationConfirm;
    VccbStatMsg_Type X2_SgNBModificationRefuse;
    VccbStatMsg_Type X2_SgNBReleaseRequest;
    VccbStatMsg_Type X2_SgNBReleaseRequestAcknowledge;
    VccbStatMsg_Type X2_SgNBReleaseRequestReject;
    VccbStatMsg_Type X2_SgNBReleaseRequired;
    VccbStatMsg_Type X2_SgNBReleaseConfirm;
    VccbStatMsg_Type X2_SgNBCounterCheckRequest;
    VccbStatMsg_Type X2_SgNBChangeRequired;
    VccbStatMsg_Type X2_SgNBChangeConfirm;
    VccbStatMsg_Type X2_SgNBChangeRefuse;
    VccbStatMsg_Type X2_RRCTransfer;
    VccbStatMsg_Type X2_SecondaryRATDataUsageReport;
    VccbStatMsg_Type X2_SgNBActivityNotification;
    VccbStatMsg_Type X2_UEContextRelease;
    VccbStatMsg_Type X2_Others;

    /* XN Message */
    VccbStatMsg_Type XN_SNodeAdditionRequest;
    VccbStatMsg_Type XN_SNodeAdditionRequestAcknowledge;
    VccbStatMsg_Type XN_HandoverRequest;
    VccbStatMsg_Type XN_HandoverRequestAcknowledge;
    VccbStatMsg_Type XN_HandoverPreparationFailure;
    VccbStatMsg_Type XN_HandoverCancel;
    VccbStatMsg_Type XN_UEContextRelease;
    VccbStatMsg_Type XN_SNodeModificationRequired;
    VccbStatMsg_Type XN_SNodeModificationConfirm;
    VccbStatMsg_Type XN_SNodeReleaseConfirm;
    VccbStatMsg_Type XN_SNodeReleaseReject;
    VccbStatMsg_Type XN_SNodeReleaseRequestAcknowledge;
    VccbStatMsg_Type XN_SNodeReleaseRequest;
    VccbStatMsg_Type XN_SNodeReleaseRequired;
    VccbStatMsg_Type XN_RRCTransfer;
    VccbStatMsg_Type XN_ActivityNotification;
    VccbStatMsg_Type XN_RetrieveUEContextRequest;
    VccbStatMsg_Type XN_RetrieveUEContextResponse;
    VccbStatMsg_Type XN_RetrieveUEContextFailure;
    VccbStatMsg_Type XN_SNodeAdditionRequestReject;
    VccbStatMsg_Type XN_SNodeChangeRequired;
    VccbStatMsg_Type XN_SNodeChangeConfirm;
    VccbStatMsg_Type XN_SNodeChangeRefuse;
    VccbStatMsg_Type XN_SNodeModificationRequest;
    VccbStatMsg_Type XN_SNodeModificationRequestAcknowledge;
    VccbStatMsg_Type XN_SNodeModificationRequestReject;
    VccbStatMsg_Type XN_SNodeModificationRefuse;
    VccbStatMsg_Type XN_SNodeReconfigurationComplete;
    VccbStatMsg_Type XN_SNStatusTransfer;
    VccbStatMsg_Type XN_XnUAddressIndication;
    VccbStatMsg_Type XN_HandoverSuccess;
    VccbStatMsg_Type XN_ConditionalHandoverCancel;
    VccbStatMsg_Type XN_EarlyStatusTransfer;
    VccbStatMsg_Type XN_RetrieveUEContextConfirm;
    VccbStatMsg_Type XN_PartialUEContextTransfer;
    VccbStatMsg_Type XN_PartialUEContextTransferAcknowledge;
    VccbStatMsg_Type XN_PartialUEContextTransferFailure;
    VccbStatMsg_Type XN_SNodeCounterCheckRequest;
    VccbStatMsg_Type XN_NotificationControlIndication;
    VccbStatMsg_Type XN_SecondaryRATDataUsageReport;
    VccbStatMsg_Type XN_TraceStart;
    VccbStatMsg_Type XN_DeactivateTrace;
    VccbStatMsg_Type XN_CellTrafficTrace;
    VccbStatMsg_Type XN_ScgFailureInformationReport;
    VccbStatMsg_Type XN_ScgFailureTransfer;
    VccbStatMsg_Type XN_ConditionalPScellChangeCancel;
    VccbStatMsg_Type XN_Others;

    /* Internal Message */
    VccbStatMsg_Type INT_CallSetupReq;
    VccbStatMsg_Type INT_CallSetupRsp[VNMB_CALL_THREAD_NUM];
    VccbStatMsg_Type INT_CallReleaseInd[VNMB_CALL_THREAD_NUM];
    VccbStatMsg_Type INT_CallReleaseCommand2;
    VccbStatMsg_Type INT_CallResourceChangeInd[VNMB_CALL_THREAD_NUM];
    VccbStatMsg_Type INT_CallEnbCellInfoReq[VNMB_CALL_THREAD_NUM];
    VccbStatMsg_Type INT_CallEnbCellInfoRsp[VNMB_CALL_THREAD_NUM];
    VccbStatMsg_Type INT_CallSetupReq1;
    VccbStatMsg_Type INT_CallSetupReq2;  // CauseCpInternalResourceAllocFail
    VccbStatMsg_Type INT_CallSetupReq3;  // Cac
    VccbStatMsg_Type INT_CallSetupReq4;  // Other
    VccbStatMsg_Type INT_CallSetupReq5;  // CauseCpInternalSaAllAmfNotService
    VccbStatMsg_Type INT_CallSetupReq6;  // Ovld
    VccbStatMsg_Type INT_CallSetupReq7;  // callInfo allocation fail
    VccbStatMsg_Type INT_CallSetupRsp1;
    VccbStatMsg_Type INT_CallSetupRsp2;
    VccbStatMsg_Type INT_NoCallSetupRsp;
    VccbStatMsg_Type INT_TriggOnDemandHO;  // ODF_HO_21B STAT
    VccbStatMsg_Type INT_TraceMsgCount;
    VccbStatMsg_Type INT_MdtMsgCount;
    VccbStatMsg_Type INT_PScellChange;

    /* Timer */
    VccbStatMsg_Type TIM_E1_BearerContextSetup;
    VccbStatMsg_Type TIM_E1_BearerContextModification;
    VccbStatMsg_Type TIM_E1_BearerContextRelease;
    VccbStatMsg_Type TIM_E1_SnStatusTransfer;

    VccbStatMsg_Type TIM_F1_UeContextSetup;
    VccbStatMsg_Type TIM_F1_UeContextRelease;
    VccbStatMsg_Type TIM_F1_UeContextModification;
    VccbStatMsg_Type TIM_F1_RrcDeliveryReport;

    VccbStatMsg_Type TIM_X2_DcOverall;
    VccbStatMsg_Type TIM_X2_SnStatusTransfer;
    VccbStatMsg_Type TIM_X2_UeContextRelease;
    VccbStatMsg_Type TIM_X2_SgNBReleaseConfirm;
    VccbStatMsg_Type TIM_X2_SgNBReleaseRequired;

    VccbStatMsg_Type TIM_XN_SnNodeReleaseAcknowledgment;

    VccbStatMsg_Type TIM_INT_UserInactivitySig;
    VccbStatMsg_Type TIM_INT_CallForcedRelease;
    VccbStatMsg_Type TIM_INT_MrPciCounter;
    VccbStatMsg_Type TIM_INT_ULSrbIntegrityFailure;

} VccbNrMsgStat_type;

typedef struct VccbHasStat_type_s
{
    uint32_t hasDirectSync_Att;
    uint32_t hasDirectSync_Succ;
    uint32_t hasDirectSync_Fail;
    unsigned long syncedSize;
} VccbHasStat_type;

typedef struct VccbMainTaskMsgStat_type_s
{
    uint32_t INT_CallReleaseCommand;
    uint32_t INT_CallReleaseCommand1;
    uint32_t INT_CellShuttingDown;  // ODF_HO_21B
} VccbMainTaskMsgStat_type;

typedef struct VccbHoDebugStat_type_s
{
    uint32_t ulNasOverWriteCnt;
    uint32_t triggerOnDemandRedirection;       // ODF_HO_21B
    uint32_t triggerOnDemandRedirectionFail;   // ODF_HO_21B
    uint32_t triggerOnDemandMeasReconfig;      // ODF_HO_21B
    uint32_t triggerOnDemandMeasReconfigFail;  // ODF_HO_21B
} VccbHoDebugStat_type;

typedef struct VccbLocalStatDuration_type_s
{
    uint32_t eventCount;
    uint64_t totalDuration;
    uint32_t minDuration;
    uint32_t maxDuration;
    uint32_t recentDuration;
} VccbLocalStatDuration_type;

typedef struct VccbLocalStatEventCount_type_s
{
    uint32_t callAttempt;
    uint32_t callSuccess;
} VccbLocalStatEventCount_type;

typedef struct VccbLocalMsgStatCount_type_s
{
    uint32_t prev;
    uint32_t curr;
} VccbLocalMsgStatCount_type;

typedef struct VccbLocalStat_type_s
{
    uint16_t updateFlag;
    struct timespec lastUpdateTime;
    VccbMainTaskMsgStat_type mainTaskMsgStat;            // For messages which are handled in Main Task
    VccbNrMsgStat_type nrMsgStat[VCCB_CALL_THREAD_NUM];  // For messages which are handled in Call Task
    vccbTimerStat_type timerStatInfo;
    VccbHasStat_type hasCallStat[VCCB_CALL_THREAD_NUM];
    VccbHasStat_type hasCallStat1[VCCB_CALL_THREAD_NUM];  // FnVCCB_BackupCallInfo()
    VccbHasStat_type hasComStat;                          // except CALL
    vccbMemoryUsage_type memoryUsageInfo;
    VccbHoDebugStat_type hoDebugStatInfo[VCCB_CALL_THREAD_NUM];
    VccbLocalStatDuration_type rRCSetupDuration[VCCB_CALL_THREAD_NUM];
    VccbLocalStatDuration_type rRCHoldingDuration[VCCB_CALL_THREAD_NUM];
    VccbLocalStatEventCount_type eventCount[VCCB_CALL_THREAD_NUM];
    uint32_t irntiRemovedCountByAudit;
    uint64_t callRelbyVnmbAudit[VCCB_CALL_THREAD_NUM];

    // Periodic Protocol Stat
    VccbLocalMsgStatCount_type localE1apCuCpMsgUe[MAX_GNB_CU_CP_FUNCTION_PER_SYS /*index1*/][MAX_GNB_CU_UP_PER_GNB_CU_CP /*epIdx*/][STAT_E1AP_CUCP_MSG_UE_END /*mType*/][VCCB_CALL_THREAD_NUM /*callThread*/];
    VccbLocalMsgStatCount_type localF1apCuMsgUe[MAX_GNB_CU_CP_FUNCTION_PER_SYS /*index1*/][STAT_F1AP_CU_MSG_UE_END /*mType*/][VCCB_CALL_THREAD_NUM /*callThread*/];
    VccbLocalMsgStatCount_type localNgapMsgUe[MAX_GNB_CU_CP_FUNCTION_PER_SYS /*index1*/][STAT_NGAP_MSG_UE_END /*mType*/][VCCB_CALL_THREAD_NUM /*callThread*/];
    VccbLocalMsgStatCount_type localRrcMsg[MAX_GNB_CU_CP_FUNCTION_PER_SYS /*index1*/][STAT_RRC_MSG_END /*mType*/][VCCB_CALL_THREAD_NUM /*callThread*/];

} VccbLocalStat_type;

typedef struct VccbFailCauseHist_s
{
    struct timeval loggingTime;

    int mFamily;
    int mType;
    unsigned long long index1;
    unsigned long long index2;

    char fnName[MAX_VCCB_STAT_FUNC_NAME]; /** function name that calls pmCC */

    uint32_t callId;     // ptCi->callId
    uint8_t stateCmd;    // ptCi->stateCmd
    uint16_t callState;  // ptCi->state

    uint8_t myThreadId;          // ptCi->myThreadId
    int16_t servCellNum;         // ptCi->servCellNum
    endPoint_type endPointInfo;  // ptCi->endPointInfo

    handoverType_type hoType;       // ptCi->hoInfo.hoType
    uint8_t isTarget;               // ptCi->hoInfo.isTarget
    uint16_t hoTargetCellNum;       // ptCi->hoInfo.targetCellNum
    uint32_t hoTargetCellIdentity;  // ptCi->hoInfo.cellIdentity
    uint64_t hoDuId;                // ptCi->hoInfo.targetDu.duId
    uint16_t hoF1Idx;               // ptCi->hoInfo.targetDu.f1Idx

    causeInfo_type cause;

} VccbFailCauseHist_type;

typedef struct VccbStatInfo_s
{
    pthread_mutex_t mutex_write;   // to handle access from multiple thread.
    pthread_mutex_t mutex_upload;  // this will be used when upload log using FTM.
    VccbLocalStat_type localStat;
    uint32_t lastStoredFailHistIndex;
    VccbFailCauseHist_type failCauseHist[MAX_VCCB_STAT_FAIL_HIST]; /** statistics fail cause history */
} VccbStatInfo_type;

typedef enum
{
    SHMLOG_MSG = 0x0001,          // shmLogMsgFlow_type    //00000000 00000001
    SHMLOG_EXTRA_DEBUG = 0x0002,  // Extra Debug Info      //00000000 00000010
    SHMLOG_STAT = 0x0004,         //                      //00000000 00000100
    SHMLOG_CRR = 0x0008,          //                      //00000000 00001000
    SHMLOG_STR = 0x0010,          //                      //00000000 00010000
    SHMLOG_RESERVED5 = 0x0020,    //                      //00000000 00100000
    SHMLOG_RESERVED6 = 0x0040,    //                      //00000000 01000000
    SHMLOG_RESERVED7 = 0x0080,    //                      //00000000 10000000
    SHMLOG_RESERVED8 = 0x0100,    //                      //00000001 00000000
    SHMLOG_RESERVED9 = 0x0200,    //                      //00000010 00000000
    SHMLOG_RESERVED10 = 0x0400,   //                      //00000100 00000000
    SHMLOG_RESERVED11 = 0x0800,   //                      //00001000 00000000
    SHMLOG_RESERVED12 = 0x1000,   //                      //00010000 00000000
    SHMLOG_RESERVED13 = 0x2000,   //                      //00100000 00000000
    SHMLOG_RESERVED14 = 0x4000,   //                      //01000000 00000000
    SHMLOG_MSCGEN     = 0x8000    //                      //10000000 00000000
} enumLogType;

typedef enum
{
    SHMLOG_INVALID_APID = 0x01,
    SHMLOG_INVALID_APUEID = 0x02
} enumShmLogInvalidFlagType;

typedef enum
{
    ANR_NBR_KNOWN = 0,
    ANR_NBR_UNKNOWN,
    ANR_EMPTY_NBR_RESULT,
} enumAnrNbrKnownType;

#define MACRO_VCCB_ANR_MR_COUNT_CELL_DATA_LENGTH                           \
    (sizeof(struct anrCgiType) /*srcCell*/ + sizeof(uint16_t) /*nbrCnt*/ + \
        sizeof(uint16_t) /*reserved*/) /*Size from OsabAnrCellMrData to data */

typedef struct
{
    uint16_t cellCnt;
    uint16_t reserved;
    OsabEnumAnrObjectType objType;

    // 'VccbMeasurementReportNotificationMsg.data' is continuous hexadecimal data of 'OsabAnrCellMrData'.
    // 'OsabAnrCellMrData.data' is continuous hexadecimal data of 'OsabAnrNbrMrData'.
    uint8_t data[MAX_ANR_MR_CNT_DATA_NUM];

} VccbMeasurementReportNotificationMsg;

typedef enum
{
    mrdcPciType_A =
        0,  // PCI#A : known PCI, XN is not connected, Inter-gNB NCR, (nrdc only) ne-dc-support = true or not configured
    mrdcPciType_B,  // PCI#B : unknown PCI
    mrdcPciType_EMPTY,
} enumMrdcAddtionPciType;

typedef struct
{
    uint8_t apType;       // E1AP/F1AP/X2AP or Internal
    uint8_t invalidFlag;  // apId : bit 0, apUeId : bit 1
    uint16_t assocIdx;
    uint64_t apId;  // UpId/DuId/eNBId/AMFId or PeerId
    uint64_t apUeId;     // UpUeId/DuUeId/MenbUeId or PeerUeId
} peerInfo_type;

typedef struct shmLogMsgFlow_s
{
    uint8_t direction;   // TX/RX
    peerInfo_type peer;  // PeerInfo

    uint16_t msgId;
    uint16_t descId;  // description Id.
    uint32_t msgLen;

    /* F1AP */
    uint16_t f1Idx;  // gutran-cu-cell/mapping-end-point-f1-index
    uint64_t gnbDuId;
    uint32_t duCallId;

    /* E1AP */
    uint16_t e1Idx;  // TODO:
    uint8_t upId;
    uint32_t upCallId;

    /* X2AP */
    uint16_t x2Idx;  // endpoint
    uint32_t enbId;
    uint16_t mEnbUeX2apId;

#ifdef VCCB_IPC_TEST
    union
    {
        struct
        {
            uint32_t autoMsgProcCmpl : 1;
        };

        uint32_t clearFlag;
    } sim;
#endif

} shmLogMsgFlow_type;

typedef struct
{
    uint16_t     usageOfNumKey; // CI_no_use/CI_use
    uint16_t     numKey;        // It's valid only when usageOfNumKey is CI_use.
    unsigned long long  keyList[MAX_VCCB_STAT_KEY_NUM];
} VccbPmKey_type;

typedef enum
{
    INT = 0,
    ULL,
    FLOAT
    // UINT,    // currently not supported
    // DOUBLE   // currently not supported
} enumVccbLogStatValType_type;

typedef struct VccbPmUpdateVal_s
{
    uint8_t uType; // enumVccbLogStatValType_type
    union
    {
        int updateValInt;
        unsigned long long updateValUll;
        float updateValFloat;
    } u;
} VccbPmUpdateVal_type;

typedef struct shmLogStatPm_s
{
    int pmCallType;     // PM_CC/PM_GUAGE/PM_SI opmCommonDefs.h
    int mFamily;
    int mType;
    VccbPmUpdateVal_type updateVal;
    unsigned long long  keyList[MAX_VCCB_STAT_KEY_NUM];
} shmLogStatPm_type;

typedef struct shmLogStr_s
{
    char brief[SHM_LOG_BRIEF_LEN];
    uint32_t detailInfoLen;  // detail informtaion is stored to VCCB_LOG_DATA.

    uint8_t debugLevel;  // PL_CRITICAL(1) ~ PL_COMMENT(5)
} shmLogStr_type;

typedef struct shmLogCallStr_s
{
    char brief[SHM_LOG_BRIEF_LEN];
    uint32_t detailInfoLen;  // detail informtaion is stored to VCCB_LOG_DATA.

    uint8_t debugLevel;  // PL_CRITICAL(1) ~ PL_COMMENT(5)

    // for CRR logging
    uint16_t crrId;
    uint16_t msgId;
    uint16_t callState;
    uint8_t stateCmd;
} shmLogCallStr_type;

typedef enum {
    e_ShmLogMscGenType_NotUsed,
    e_ShmLogMscGenType_String,
    e_ShmLogMscGenType_Reserved1,
    e_ShmLogMscGenType_Reserved2
} enumShmLogMscGen_type;

typedef struct shmLogMscGen_s
{
    uint8_t shmType    : 3; // enumShmLogMscGen_type
    uint8_t debugLevel : 3; // PL_CRITICAL(1) ~ PL_COMMENT(5)
    uint8_t reserved1  : 2;
    uint8_t reserved2  : 8;
    uint8_t reserved3  : 8;
    uint8_t reserved4  : 8;

    union
    {
        struct {
            char brief[SHM_LOG_BRIEF_LEN];
        } str; // if shmType == 1

        struct {
            char dummy;
        } rev1; // if shmType == 2

        struct {
            char dummy;
        } rev2; // if shmType == 3

    } u;

} shmLogMscGen_type;

typedef struct
{
    uint16_t crrId;
    uint16_t msgId;
    enumVccbCallState_type state;
    enumVccbCallState_type prevFnState;
    enumStateCmd_type stateCmd;
    enumStateCmd_type prevStateCmd;
} shmLogCRR_type;

typedef struct
{
    uint32_t vccbCallId;
    uint32_t cuCpUeId;
    uint8_t callType;     // enumCallType_type
    uint8_t dcType;       // enumdCType_type
    uint16_t state;       // enumVccbCallState_type
    uint8_t stateCmd;
    callUeId_type ueId;
    int16_t servCellNum;  // invalid cellNum : -1
    int16_t servPcid;     // NR Physical Cell Id. invalid : -1
    int16_t newCellNum;   // invalid cellNum : -1
    uint8_t traceVoNR;
    uint8_t debugTrace;   // traceOn/Off
    uint8_t ueType;       // ueType : 0 - Normal, 1 - RedCap, 2 - All
} LogMetaUe_type;

typedef struct shmLogMeta_s
{
    struct timeval loggingTime;
    uint8_t gnbNum;  // gnbNum is assigned by VCCB.
    uint8_t vmId;
    uint16_t type;  // enumLogType
    uint32_t dataOffset;
    uint32_t previousLogIndex;

    LogMetaUe_type ue;

    union
    {
        shmLogMsgFlow_type logMsgFlow;  // SHMLOG_MSG
        shmLogStatPm_type logStatPm;    // SHMLOG_STAT
        shmLogStr_type logStr;
        shmLogCallStr_type logCallStr;  // SHMLOG_CALLSTR_L1...
        shmLogCRR_type logCRR;
        shmLogMscGen_type logMscGen;
    } u;
} shmLogMeta_type;

typedef struct VccbLogInfo_s
{
    /* Message Log (include statistics, str.. ) */
    pthread_mutex_t mutex_write;   // to handle access from multiple thread.
    pthread_mutex_t mutex_upload;  // this will be used when upload log using FTM.
    uint32_t rIdx;                 // last index for realtime logging. - backup Previous wIdx if wIdx is rollover.
    uint32_t wIdx;                 // write index.
    shmLogMeta_type logMeta[MAX_SHM_LOG_CNT + 1];
    size_t logDataSize;
    char *data;
    uint32_t previousLogIndex[MAX_CALL_COUNT_PER_CPC];

} VccbLogInfo_type;

typedef struct VccbLogFishingEvent_s
{
    struct timeval lastLoggingTime;
    uint16_t eventId;
    enumLogFishingEventType_type eventType;
    uint8_t isLogging;
    uint32_t startLogIndex;
    uint32_t endLogIndex;
    uint32_t wIdx;
    uint32_t dataOffset;
    uint32_t occurrenceCount[VCCB_CALL_THREAD_NUM];
    uint32_t savedCount[VCCB_CALL_THREAD_NUM];
} VccbLogFishingEvent_type;

typedef struct VccbLogFishingInfo_s
{
    /* Message Log (include statistics, str.. ) */
    shmLogMeta_type logMeta[MAX_SHM_LOG_FISHING_CNT + 1];
    size_t logDataSize;
    char *data;
    VccbLogFishingEvent_type eventList[VCCB_MAX_LOG_FISHING_EVENT_COUNT];
    uint16_t eventCount;
    uint16_t crrEventCount;
    uint16_t manualEventCount;
    uint16_t eventListRecoveryCount;
    uint16_t shmLogDataInvalidCount;
    uint16_t bigMsgLenCount;
} VccbLogFishingInfo_type;

typedef struct segmentPoolInfo_s
{
    uint8_t rrcSegmentPoolRatio;
    segmentPoolBuffer_type *segmentPoolBuffer;
    segmentPoolManager_type segmentPoolManager; // Pool allocation information per Thread
} VccbSegmentPoolInfo_type;

typedef struct
{
    callPDUSessInfo_type pduSess[MAX_PDU_SESS_PER_CALL];
} VccbExtBackup_type;

typedef struct
{
    uint8_t isActive; // If FALSE, the CallThread does not process the message of the call and ignores it.
    uint8_t isReturningCall;  // Indicates a call that is returning after call takeover.

    struct
    {
        // The data received from the source gNB should be relayed.
        //   It should be received from the source gNB and delivered to the F1-DU.
        //   Since this process is passed through multiple states, it must be stored separately.
        uint8_t rrcHandoverPreparation[MAX_HO_PREPARATION_INFO_SIZE];
    } mobility;

    // SVR24B, Mobility For NR-DC, SCG UE History Information Handling
    VccbLastVisitedPSCellHandling_type uePscellHistory;

    VccbExtBackup_type  extBackup;  /* For PDU Session on DRB Partial */
} VccbNonBackupCallInfo_type;

typedef struct
{
    McoLbCacheResultEntry_type mcoLbCacheEntries[MAX_MCO_LB_CACHE_ENTRIES_PER_CELL];
    pthread_mutex_t mcoLbCacheMutex;
    pthread_mutex_t oMFailedScellsMutex;
} VccbNonBackupCellInfo_type;

// warning : This DB is not backed up. Please consider cases such as redundancy work.
//           In the case of callDB, it should not be accessed using temporary callInfo data other than 'ENV->callInfo'.
//           For tempcall, create a DB for tempcall and use it.
typedef struct VccbExternalInfo_s
{
    VccbNonBackupCallInfo_type *call;
    VccbNonBackupCellInfo_type *cell;

    // struct {
    // } gnb[0];

    // struct {
    // } feature;

} VccbExternalInfo_type;

typedef struct VccbThreadInfo_s
{
    VccbCallThreadInfo_type *call;
    VccbMainThreadInfo_type main;
    VccbPldThreadInfo_type pld;
    VccbNonUeThreadInfo_type nonUe;
    VccbNonUeAsn1ThreadInfo_type nonUeAsn1;
    VccbRacsThreadInfo_type racs;
} VccbThreadInfo_type;

typedef struct VccbInfo_s
{
    VccbCfgInfo_type *cfg;
    VccbCellInfo_type *cell; /**< Size of MAX_CELL_PER_VNF */
    VccbGnbInfo_type *gnb;
    VccbEnvInfo_type *env;
    VccbDbgInfo_type *dbg;
    VccbSegmentPoolInfo_type *capa;
    VccbExternalInfo_type external;
    VccbThreadInfo_type thread;

    VccbLogInfo_type *log;
    VccbLogFishingInfo_type *logFishing;
    VccbStatInfo_type *stat;

    VclbSts_type *vclbSts;
    VccbRacsInfo_type *racsInfo;

} VccbInfo_type;

typedef struct
{
    enum validation_result
    {
        VccbValidationSucceeded = 0,
        VccbValidationFailed = 1,
    } res;
    char str[VCCB_MAX_VALIDATION_ERR_LEN];
} VccbValidation_type;

/* NBR Cell TAI (PLMN + TAC) List */
typedef struct
{
    uint32_t tac;
    allowedPlmnList_Type plmnList;
} nbrTaiInfo_type;

/* Supported PLMN Information of NBR Cell that satisfies UE Allowed PLMN */
typedef struct
{
    uint16_t nbrIdx;
    uint16_t cellNum;  // NR-DC
    uint16_t cellBand;
    uint16_t pci;
    uint32_t freq;
    uint8_t freqIdx;   // NR-DC
    uint8_t pciIdx;    // NR-DC
    int rank;
    uint8_t isSpecificSliceFailed:1;
    nbrTaiInfo_type nbrTaiInfo;
    selectedTAI_Type selectedTAI;
    vccbGlobalGnbId_type globalGnbId;
    cgi_type selectedNbrGnbCgi;
} candidateNbrInformation_type;

/* Candidate Cells of satisfying handover conditions */
typedef struct
{
    uint16_t numNbr;
    int32_t maxRank;
    candidateNbrInformation_type nbrList[MAX_NBR_PER_CELL];
} candidateNbrList_type;

// For SN PScell selection ....
typedef struct
{
    uint16_t numNbr;
    candidateNbrInformation_type nbrList[MAX_NBR_PER_CELL];
} candidatePscellNbrList_type;

typedef struct
{
    bool skip_inter;
    int32_t maxRank;
    candidatePscellNbrList_type intraSn;
    candidatePscellNbrList_type interSn;
} SN_PscellSelectionCandidateNbrList_type;

/*----------------------------------------------------------------------------
 * Define    :    Internal Message Structure
 * ---------------------------------------------------------------------------
 */
/*
typedef struct
{
    messageHdr_type         hdr;
    uint16_t                callId;
    triggeredProcedure  procedureTriggered;
} msgInternalCallActionTrigger_type;
*/

#define MAX_NUM_OF_CALLS_IN_INTERNAL_CALL_RELEASE 16000
typedef struct
{
    messageHdr_type hdr;
    uint8_t cause;
    uint8_t reserved1;
    uint16_t numberOfCalls;
    uint32_t cuCpUeId[MAX_NUM_OF_CALLS_IN_INTERNAL_CALL_RELEASE];
} msgInternalCallRelease_type;

typedef struct
{
    messageHdr_type hdr;
    uint8_t stateCmd;    // enumStateCmd_type
    uint32_t state;      // enumVccbCallState_type
} msgInternalCallSetStateDebug_type;

typedef struct
{
    messageHdr_type hdr;
    uint16_t callId;
    uint16_t eventId;
} msgInternalLogFishingRequest_type;

typedef struct
{
    messageHdr_type hdr;
    msgContainer_type messageContents;
} msgInternalSendMeasReport_type;

typedef struct
{
    messageHdr_type hdr;
    uint16_t numOfDistCode;
    uint16_t distCodeToFree[MAX_DIST_CODE_PER_SYS];
} msgInternalCallFreeCommand_type;

typedef struct
{
    messageHdr_type hdr;
} msgInternalTimKeepAliveReq_type;

/*
 * @brief   Internal VCCB msg for User Inactivity Feature on/off notification
 * @details direction taskSub -> taskCall
 */
typedef struct
{
    messageHdr_type hdr;
    enumInternalUserInactivityUpdate cause;
    uint16_t gnbNum;
} msgInternalInactivityUpdate_type;

/*
 * @brief   Internal VCCB msg for MDT Feature on -> off notification
 * @details direction taskSub -> taskCall.
 */
typedef struct
{
    messageHdr_type hdr;
    uint16_t cellNum;
    uint16_t gnbNum;
    enumTraceDbStopTrigger stopTrigger;
} msgInternalStopTracingUpdate_type;

typedef struct
{
    uint8_t numRelQos;
    uint16_t relCause;
} numRelQosInfoInDRB_type;

// InternalTriggerOnDemandHo_id
typedef struct  // ODF_HO_21B
{
    messageHdr_type hdr;
    // empty body
} msgInternalTriggerOnDemandHo_type;

// InternalTriggerOnDemandHoMainToCall_id
typedef struct  // ODF_HO_21B
{
    messageHdr_type hdr;

    //    uint8_t bufIdx;
} msgInternalTriggerOnDemandHoMainToCall_type;

typedef struct
{
    messageHdr_type hdr;
} msgInternalTriggePeriodicLb_type;

typedef struct
{
    messageHdr_type hdr;
    //uint32_t callId;
} msgInternalTriggerPeriodicLbMainToCall_type;

typedef struct
{
    uint16_t numNr;
    uint16_t numEutra;
    plmnId_type nrAllowed[NG_MaxnoofEPLMNsPlusOne];
    plmnId_type eutraAllowed[NG_MaxnoofEPLMNsPlusOne];
} CandidateAllowedPlmnList_type;

typedef struct
{
    uint8_t num;
    uint8_t drbId[MAX_DRB_PER_SA_CALL];
    qosFlowLevelQoSParam_type drbQos[MAX_DRB_PER_SA_CALL];
} DRBQosListBuffer_type;

typedef enum
{
    e_BY_SWITCHOVER,
    e_BY_GNB_CREATION
} enumInternalPldReadRequestCause;

typedef struct
{
    messageHdr_type hdr;
    uint8_t requestCause;   // enumInternalPldReadRequestCause
    uint8_t isHasBackupRequired;
} msgInternalPLDReadRequest_type;

typedef struct
{
    uint16_t freqBandIndicator;
    uint16_t noofFsIdx;
    uint16_t fsIdx[MAX_NUM_FEATURESETSPERBAND];
} bandWithAvailableFSs_type;

typedef struct
{
    uint16_t noofBands;
    bandWithAvailableFSs_type  bands[MAX_BANDS_PER_COMB];
} AvailableFSsPerFSCombination_type;

typedef struct
{
    uint8_t changedFlag;
    uint8_t ueInactivityState;
    uint8_t sigInactivityTimerExit;
    uint8_t x2ReleaseTimerExist;
} UserInact_changeInfo_type;

typedef struct
{
    uint16_t band;
    uint32_t ssbArfcn;
    uint16_t sCellIndex;  //    ptCi->sCell[index];
    cgi_type cgi;
    bool ssbFlag;
    uint32_t nrArfcnDl;
    uint8_t nrScsDl;
    uint8_t nRbDl;
} SimpleSCellInfo_type;

typedef struct
{
    uint32_t nrArfcnDl;
    enumNrSubCarrierSpacing_type nrScsDl;
    enumNrSystemBandwidth_type nRbDl;
    enumNrSubCarrierSpacing_type nrScsUl;
    enumNrSystemBandwidth_type nRbUl;
    uint16_t bandwidthDl;
    uint16_t bandwidthUl;
} LBCellInfo_type;

typedef struct
{
    uint16_t measResultCellReportIdx;

    // FGR-LC0705:FR12
    uint32_t ssbArfcn;
    uint64_t nci;

    uint32_t availableResource;
} availResourcePerMeasResultCellReport_type;

typedef struct
{
    int16_t (*successFunction)(callInfo_type *);
    const char *strSuccessFunction;
    int16_t (*unSuccessFunction)(callInfo_type *, msgUnpack_type *);
} multiUpFunctionParameter_type;

typedef struct
{
    uint32_t ssbFreq;
    uint32_t mrCount;
    uint32_t measConfigCount;
} faMeasResultBuff_type;

typedef struct
{
    uint32_t gnbId;
    cgi_type nrCgi;
    uint8_t gnbNum;
    faMeasResultBuff_type faMeasResultBuff[MAX_MEAS_OBJECT_ENTRIES];

} faMeasResultCellBuff_type;

typedef struct
{
    uint16_t cellCount;
    faMeasResultCellBuff_type cellFaMeasResultBuff[MAX_CELL_PER_VNF];
} msgSonFaMeasInfoRspBuff_VccbVcsb_type;

typedef struct {
  enumMeasurementReportType reportType;
  uint8_t reportPurpose;
} reportTypeAndPurpose_type;

typedef struct
{
    uint32_t ssbArfcn;
    uint8_t numAvailUe;
    uint8_t nrScsDl;
    smtc1_type smtc1;
} colocCellbasedCandidateCell_type;

typedef struct
{
    uint8_t measObjIdx;
    uint8_t priority;
    uint8_t subpriorityUsage;
    uint8_t subpriority;
} tempCandidateFreqInfo_type;

typedef enum
{
    TX_NO_CONTROL = -1, /* TX No Control*/
    TX_STOP = 0,        /* E1_DL_TX_Stop_stop */
    TX_RESUME = 1       /* E1_DL_TX_Stop_resume */
} enumTxCtrltype;

// Debug for UE Capability Handling
typedef struct{
    uint16_t numNR;
    uint16_t numEUTRA;
    uint16_t bandNR[MAX_FREQBAND_PER_CELL];
    uint16_t bandEUTRA[MAX_FREQBAND_PER_CELL];
}FreqBandInfoList_type;

typedef struct {
    int ratType;
    int usage;
    uint8_t srsSwitchingTimeRequest_present:1;
    uint8_t deviceIdentification_present:1;
    uint8_t reserved : 6;

    FreqBandInfoList_type bandList;
}RatRequestList_type;

typedef struct{
    uint8_t mrdcRequest_present:1;
    uint8_t codebookTypeRequest_present:1;
    uint8_t uplinkTxSwitchRequest_present:1;
    uint8_t requestCellGrouping_present:1;
    uint8_t rrcSegAllowedR16_present:1;
    uint8_t reserved : 3;
}RatRequestExt_type;

typedef struct {
    int numRat;
    uint8_t capaEnquiryExt_present;
    RatRequestList_type CapaRatRequestList[3];
    RatRequestExt_type CapaEnquiryExt;
}CapaEnquiryInfo_type;

struct NRRRC_MeasResultList2NR_;
typedef struct {
    uint8_t threshold;    // Default : Maximum RSRP per frequency
    struct NRRRC_MeasResultList2NR_ *pMeasResultList2NR; // Default : Pointer of NRRRC_MeasResultList2NR_
}MeasMeasResult2NR_type;

// FGR-CC5200:FR760 FR770 FR780 FR790
typedef enum
{
    ConnInfoStatsCmd_Begin,
    ConnInfoStatsCmd_Increase,
    ConnInfoStatsCmd_Decrease,
    ConnInfoStatsCmd_Change,
    ConnInfoStatsCmd_SetupTimeStart,
    ConnInfoStatsCmd_SetupTimeStop,
    ConnInfoStatsCmd_HoldingTimeStart,
    ConnInfoStatsCmd_HoldingTimeStop,
    ConnInfoStatsCmd_End
} enumConnInfoStatsCmd_type;

// SVR24B FGS-SF0502 FR192, FR193
typedef enum
{
    REPORT_CGI_GBR_SWITCH_TYPE_OFF = 0,
    REPORT_CGI_GBR_SWITCH_TYPE_AUTONOMOUS_GAP = 1,
    REPORT_CGI_GBR_SWITCH_TYPE_DRX = 2,
    REPORT_CGI_GBR_SWITCH_TYPE_BOTH = 3,
    REPORT_CGI_GBR_SWITCH_TYPE_END
} reportCgiGbrSwitch_type;

typedef struct {
    uint8_t isRunning;      // TRUE, FALSE
    uint8_t isForSn;        // TRUE, FALSE
    uint8_t triggeredBy;   // enumInterRatTargetCellResult_type
} fallback_T321Info_type;

typedef struct
{
    pthread_t thread_id;
    bool subscribeTaskActivated;

    bool waitForTaskCompletion;

    unsigned int maxOfWaitTime;      // default value : 20, 2000ms
} confdBtCntl_type;

/**
 * @brief This file contains the definition of VccbReleaseCallSelectionCause_type structure.
 */
typedef struct VccbReleaseCallSelectionCause_type
{
    union
    {
        struct
        {
            /**
             * @brief This bit is set to 1 if the call is always selected.
             */
            uint64_t byAlwaysSelected : 1;

            /**
             * @brief This bit is set to 1 if the call is released due to serving end point index.
             * The serving end point index can be found in ptCi->endPointInfo.
                - E1 : ptCi->endPointInfo.aupf~
                - F1 : ptCi->endPointInfo.f1Idx
                - NG : ptCi->endPointInfo.ngIdx
                - XN : ptCi->endPointInfo.xnIdx
             */
            uint64_t byServingEndPointIdx : 1;

            /**
             * @brief This bit is set to 1 if the call is released due to XN link source MRDC SN.
             */
            uint64_t byXnSrcMrdcSn : 1;

            /**
             * @brief This bit is set to 1 if the call is released due to XN link target MRDC SN.
             */
            uint64_t byXnTgtMrdcSn : 1;

            /**
             * @brief This bit is set to 1 if the call is released due to XN link during XN HO.
             */
            uint64_t byXnDuringXnHo : 1;

            /**
             * @brief This bit is set to 1 if the call is released due to XN link during RRE.
             */
            uint64_t byXnDuringRRE : 1;

            /**
             * @brief This bit is set to 1 if the call is released due to XN link during resume.
             */
            uint64_t byXnDuringResume : 1;
        };
        uint64_t bitmask;
    };
} VccbReleaseCallSelectionCause_type;

enum MeasurementQuantityBitmask {
  MeasurementQuantityBitmask_None = 0,
  MeasurementQuantityBitmask_RSRP = 1 << choice_rsrp,
  MeasurementQuantityBitmask_RSRQ = 1 << choice_rsrq,
  MeasurementQuantityBitmask_SINR = 1 << choice_sinr
};

#ifndef NEW_HOST_SIM
#define MAX_STATISTICS_COLLECT_ITEM_PER_THREAD      800 // unsigned long long issue
#define MAX_STATISTICS_UPDATE_ITEM_PER_THREAD       100 // sizeof(VccbStatisticsTemporaryUpdate_type) = 576
#else
#define MAX_STATISTICS_COLLECT_ITEM_PER_THREAD      80
#define MAX_STATISTICS_UPDATE_ITEM_PER_THREAD       10
#endif

enum StatisticsItemUpdateMeasureType {
    e_StatMethod_Collect        = 0,
    e_StatMethod_Update         = 1,
    STATISTICS_METHOD_TYPE_MAX  = 2,

    e_Current_StatItemMsg       = 0,
    e_Previous_StatItemMsg      = 1,
    STATISTICS_MESSAGE_TIME_MAX = 2
};

typedef struct {
    uint32_t mFamily;
    uint32_t mType;
    unsigned long long key[MAX_VCCB_STAT_KEY_NUM];
    enumStatisticsValueType valueType;
    union {
        uint32_t uVal;
        uint64_t lVal;
        float    fVal;
    };
} VccbStatisticsTemporaryCollect_type;

#define VCCB_MAX_MTYPES             96
#define VCCB_MAX_STAT_THREAD_MTYPES 32

typedef struct {
    uint32_t mFamily;
    enumStatisticsValueType valueType;
    uint16_t numOfItem;
    unsigned long long key[MAX_VCCB_STAT_KEY_NUM];

    union   // below size 512 bytes
    {
        updateItemUINT  updateItemUintArr[VCCB_MAX_STAT_THREAD_MTYPES];
        updateItemULL   updateItemUllArr[VCCB_MAX_STAT_THREAD_MTYPES];
        updateItemFLOAT updateItemFloatArr[VCCB_MAX_STAT_THREAD_MTYPES];
    };
} VccbStatisticsTemporaryUpdate_type;


typedef struct
{
    messageHdr_type hdr;
    uint32_t  threadId;
    uint32_t  itemCount;
    VccbStatisticsTemporaryCollect_type  mItem[MAX_STATISTICS_COLLECT_ITEM_PER_THREAD];
} msgInternalStatisticsItemCollect_type;

typedef struct
{
    messageHdr_type hdr;
    uint32_t  threadId;
    uint32_t  itemCount;
    VccbStatisticsTemporaryUpdate_type  mItem[MAX_STATISTICS_UPDATE_ITEM_PER_THREAD];
} msgInternalStatisticsItemUpdate_type;

typedef struct
{
    timerInfo_type                          timer;
    msgInternalStatisticsItemCollect_type   msg;
} VccbStatisticsItemCollect_type;

typedef struct
{
    timerInfo_type                          timer;
    msgInternalStatisticsItemUpdate_type    msg;
} VccbStatisticsItemUpdate_type;

typedef struct
{
    uint8_t             fiveQi;                 // DRB 5qi
    uint8_t             includingRelTotal;      // ON: Include DrbRelTotal/UeRelTotal,   OFF: Exclude DrbRelTotal/UeRelTotal
    uint8_t             inSessionFlagByE1;      // On: Active,  OFF:Inactive
    uint8_t             gnbAmfInitType;         // enumRetainCslInit_type
    uint8_t             cslAbnormal;            // Abnormal Case for CSL
    uint8_t             abnRelCause5qi;         // enumAbnormalRelCause5qiCslType_type
} retainCslCollect_type;

typedef struct
{
    // AMF Request
    retainStatInfo_type   retainStatForAmfReq;
    // CSL
    retainCslCollect_type cslInfo;
} retainExtraInfo_type;

typedef enum
{
    NONE_RETAIN = 0,
    GNB_INIT_RETAIN = 1,
    AMF_INIT_RETAIN = 2
} enumRetainCslInit_type;


#ifdef __cplusplus
};
#endif
#endif  // VCCB_VccbStruct_H_
