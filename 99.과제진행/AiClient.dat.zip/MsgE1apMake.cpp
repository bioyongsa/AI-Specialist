#include "MsgE1apMake.h"
#include "MsgCommonMake.h"
#include "MsgCommonMake.hpp"

#include "ComInclude.h"
#include "ComLibUtility.h"
#include "ComAsnUtil.hpp"

#include "FeatCommon.h"
#include "FeatHo.h"
#include "FeatMrdc.h"
#include "FeatCallInfo.h"
#include "FeatCallProc.h"
#include "FeatFullConfig.h"
#include "FeatConditionalHo.h"
#include "FeatRbInfo.h"
#include "FeatUlPathControlENDC.h"
#include "FeatRrcInactive.h"
#include "FeatVoma.hpp"
#include "VccbAiClient.h"

#include "e1apPack.h"
#include "nrrrcUnpack.h"
#include "compat_glibc.h"

// 1. BEARER CONTEXT SETUP REQUEST        : VEIL_makeBearerContextSetupRequest
// 2. BEARER CONTEXT MODIFICATION REQUEST : VEIL_makeBearerContextModificationRequest
// 3. BEARER CONTEXT RELEAES COMMAND      : VEIL_makeBearerContextReleaseCommand

using asn::util::VCCB_ConnectLinkedList;
using asn::util::VCCB_GlobalAlloc;

int VEIL_checkE1_SCG_Release_For_SA_Mobility(callInfo_type *ptCi);
uint8_t VEIL_checkE1_UEDLMaximumProtectedDataRate_Existence(callInfo_type *ptci, E1_BitRate &bitRateValue);

int VEIL_fillE1_GTP_TEID(E1_GTP_TEID *ptGtpTei, uint32_t teid);
int VEIL_fillE1_TransportLayerAddress(E1_TransportLayerAddress *tla, const transportLayerInfo_type *ptTli);

// 22B_UserInactivity_FR214
int FnVCCB_FillNsaDrbInactivityTimerValue(
    callInfo_type *ptCi, E1_Inactivity_Timer *pTimer, callERABInfo_type *pERABInfo);

void FnVCCB_checkAndStoreDirectFwdPathAvailableInAllPduSess(callInfo_type *ptCi, const uint16_t endPointIdx);
int16_t VEIL_fillE1_SamsungCallInfo(callInfo_type& rCi, E1_SamsungCallInfo& rCallInfo);

template <typename T>
int16_t VEIL_AddE1ExtensionToLinkedList(callInfo_type *ptCi, bool isExtensionPresent,
            struct E1_ProtocolExtensionContainer_ **ppExtensionContainer, struct E1_ProtocolExtensionContainer_ *pBuffer,
            T value, E1_ProtocolIE_ID ieId, int pduNum);
/**
 *  @brief Checks the conditions for configuring PDCP Duplication.
 *  @param[in] ptCi (callInfo structure pointer)
 *  @param[in] pDRBInfo (DRB Info structure pointer)
 *  @return TRUE : PDCP Duplication can be configured  FALSE : PDCP Duplication not supported for this bearer
 */
bool FnVccb_PdcpDuplicationActivationDecision(callInfo_type *ptCi, callDRBInfo_type *pDRBInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(pDRBInfo);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);

    uint8_t  fiveQi = 0;
    uint32_t sstSd = 0xFFFFFFFF;
    callPDUSessInfo_type *ptPi = NULL;
    const gnbConfig_type *const pGnbCfg = &GNBINFO[ptCi->gnbNum].cfg;

    //if PDCP Duplication was marked as active previously, mark it as TRUE again
    if (pDRBInfo->pdcpDuplicationActive == TRUE)
    {
        return TRUE;
    }

    if (FALSE == pGnbCfg->pdcpDuplication.pdcpDuplicationOnOff)
    {
        return FALSE;
    }
        
    ptPi = &ptCi->pduSess[pDRBInfo->pduIdxInCall];
    if (ptPi->usage != CI_use)
    {
        return FALSE;
    }

    qosFlowInfo_type *const ptQi = &ptCi->qosFlow[pDRBInfo->drbQosIdxInCall];
    if (ptQi->usage != CI_use) 
    {
        return FALSE;
    }

    VLIB_getFiveQi(ptQi, &fiveQi);

    for (uint16_t loop=0; loop < MAX_PDCP_DUPLICATION_CONFIG; loop++)
    {
        if (CI_use != pGnbCfg->pdcpDuplication.pdcpDuplicationConfig[loop].usage)
        {
            continue;
        }

        sstSd = 0xFFFFFFFF;
#if __BYTE_ORDER == __LITTLE_ENDIAN
            sstSd = (static_cast<uint32_t>((pGnbCfg->pdcpDuplication.pdcpDuplicationConfig[loop].sst & 0xFF) << 24) |
                     (pGnbCfg->pdcpDuplication.pdcpDuplicationConfig[loop].sd & 0xFFFFFF));
#else
            sstSd = (((pGnbCfg->pdcpDuplication.pdcpDuplicationConfig[loop].sd & 0xFFFFFF) << 8) |
                     (pGnbCfg->pdcpDuplication.pdcpDuplicationConfig[loop].sst & 0xFF));
#endif

        if ((pGnbCfg->pdcpDuplication.pdcpDuplicationConfig[loop].plmn.s2.mcc == ptCi->ueInfo.servedPlmn.s2.mcc) &&
            (pGnbCfg->pdcpDuplication.pdcpDuplicationConfig[loop].plmn.s2.mnc == ptCi->ueInfo.servedPlmn.s2.mnc) &&
            (sstSd == ptPi->sNssai.sstSd) &&
            (pGnbCfg->pdcpDuplication.pdcpDuplicationConfig[loop].qos5qi == fiveQi) &&
            (pGnbCfg->pdcpDuplication.pdcpDuplicationConfig[loop].dlPdcpDuplicationOnOff == TRUE))

        {
            pDRBInfo->pdcpDuplicationActive = TRUE;
            return TRUE;
        }
    }
    return FALSE;
}

/**
 *  @brief Fill E1 bit string structure.
 *  @param[out] pAsn (target structure)
 *  @param[in] value (BitString to write - passed as Integer)
 *  @param[in] length (length of BitString in bits)
 *  @return GOOD : successful  ERROR : unsuccessful
 */
template <typename T>
int16_t FillE1_BitString(T *pAsn, uint64_t value, unsigned short length)
{
    VALID_E_POINT_CHECK_ERROR(pAsn);

    if (length > 64)
    {
        VCCB_PRINT_ERROR("ERROR: FillE1_BitString length overflow (%d) ERROR \n", length);
        return ERROR;
    }

    pAsn->length = length;  // in bits

    unsigned short reminder = length % 8;           // number of reminder btis to shift
    length = static_cast<unsigned short>((length + 7) / 8);                      // number of bytes
    unsigned char *tgt = pAsn->value + length - 1;  // right side of target strucutre

    if (reminder > 0)
    {
        value = value << (8 - reminder);  // align to left byte
    }
    for (unsigned i = 0; length > i; ++i)  // copy byte by byte starting from right side
    {
        *tgt = 0xFF & (value >> (i * 8));
        --tgt;
    }

    return GOOD;
}

#ifdef IPC_TEST
uint32_t teidToU32(const E1_GTP_TEID &src)
{
    AUTO_TRACE_FUNC;
    uint32_t TEID = 0;

    for (size_t i = 0; i < 4; i++) TEID = (TEID << 8) | src.value[i];

    return TEID;
}

/** Copy transport layer address value to a binary array
 * @return address length in bits */
uint16_t copyTlAddress(const E1_TransportLayerAddress &src, uint8_t *dst)
{
    AUTO_TRACE_FUNC;
    int calcLen = (src.length + 7) / 8;

    size_t addrLen = (size_t)MIN(MAX_TLA_BYTE, calcLen);
    memcpy(dst, src.value, addrLen);
    return static_cast<uint16_t>(8 * addrLen);
}

#include "log_util.h"
template <typename T>
void FnVCCB_CheckE1_DRBToSetupItem(callInfo_type &callInfo, callDRBInfo_type &drbInfo, T &drbToSetup)
{
    if (drbInfo.dRBId >= MAX_DRB_ID_PER_CALL + 1) return;

    // PDCP (recover, re-est)
    {
        auto pdcpConfig = drbToSetup.pDCP_Configuration;

        callInfo.checker.drb[drbInfo.dRBId].f1uUlInfo_mcg.numTLAbit = 0;
        callInfo.checker.drb[drbInfo.dRBId].f1uUlInfo_scg.numTLAbit = 0;

        if (pdcpConfig.bit_mask & E1_pDCP_DataRecovery_present)
        {
            callInfo.checker.drb[drbInfo.dRBId].up_recover_reest = 1;
            VCCB_PRINTF("[CHECKER] drbId(%d) %s recover\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
        }

        if (pdcpConfig.bit_mask & E1_pDCP_Reestablishment_present)
        {
            callInfo.checker.drb[drbInfo.dRBId].up_recover_reest = 2;
            VCCB_PRINTF("[CHECKER] drbId(%d) %s reest\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
        }
    }

    // used
    {
        auto list = drbToSetup.cell_Group_Information;

        for (;list; list = list->next)
        {
            auto *info = reinterpret_cast<E1_Cell_Group_Information_Item *>(&list->value);

            if (info->cell_Group_ID == 0)
            {
                callInfo.checker.drb[drbInfo.dRBId].mcg_used = true;
                VCCB_PRINTF("[CHECKER] drbId(%d) %s mcg used\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
            }

            if (info->cell_Group_ID == 1)
            {
                callInfo.checker.drb[drbInfo.dRBId].scg_used = true;
                VCCB_PRINTF("[CHECKER] drbId(%d) %s scg used\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
            }
        }
    }
}

void FnVCCB_CheckE1_DRBToModifyItem(callInfo_type &callInfo, callDRBInfo_type &drbInfo, E1_DRB_To_Modify_Item_NG_RAN &drbToModifyItem)
{
    if (drbInfo.dRBId >= MAX_DRB_ID_PER_CALL+1) return;

    // add
    if (drbToModifyItem.bit_mask & E1_DRB_To_Modify_Item_NG_RAN_cell_Group_To_Add_present)
    {
        auto list = drbToModifyItem.cell_Group_To_Add;

        for (; list; list = list->next)
        {
            auto *info = reinterpret_cast<E1_Cell_Group_Information_Item *>(&list->value);
            if (info->cell_Group_ID == 0)
            {
                callInfo.checker.drb[drbInfo.dRBId].mcg_used = true;
                callInfo.checker.drb[drbInfo.dRBId].f1uUlInfo_mcg.numTLAbit = 0;
                VCCB_PRINTF("[CHECKER] drbId(%d) %s mcg used\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
            }

            if (info->cell_Group_ID == 1)
            {
                callInfo.checker.drb[drbInfo.dRBId].scg_used = true;
                callInfo.checker.drb[drbInfo.dRBId].f1uUlInfo_scg.numTLAbit = 0;
                VCCB_PRINTF("[CHECKER] drbId(%d) %s scg used\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
            }
        }
    }

    // DRB level valid check
    if ((callInfo.checker.drb[drbInfo.dRBId].mcg_used != true) && 
        (callInfo.checker.drb[drbInfo.dRBId].scg_used != true))
    {
        VCCB_PRINTF("[CHECKER!!] drbId(%d) %s is removed\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
    }
    // leg level valid check
    else if (drbToModifyItem.bit_mask & E1_DRB_To_Modify_Item_NG_RAN_cell_Group_To_Modify_present)
    {
        auto list = drbToModifyItem.cell_Group_To_Modify;

        for (;list; list = list->next)
        {
            auto *info = reinterpret_cast<E1_Cell_Group_Information_Item *>(&list->value);

            if (info->cell_Group_ID == 0)
            {
                if (callInfo.checker.drb[drbInfo.dRBId].mcg_used != true)
                {
                    VCCB_PRINTF("[CHECKER!!] drbId(%d) %s mcg is not used\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
                }
            }

            if (info->cell_Group_ID == 1)
            {
                if (callInfo.checker.drb[drbInfo.dRBId].scg_used != true)
                {
                    VCCB_PRINTF("[CHECKER!!] drbId(%d) %s scg is not used\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
                }
            }
        }
    }

    // PDCP (recover, re-est)
    if (drbToModifyItem.bit_mask & E1_DRB_To_Modify_Item_NG_RAN_pDCP_Configuration_present)
    {
        auto pdcpConfig = drbToModifyItem.pDCP_Configuration;

        if (pdcpConfig.bit_mask & E1_pDCP_DataRecovery_present)
        {
            callInfo.checker.drb[drbInfo.dRBId].up_recover_reest = 1;
            VCCB_PRINTF("[CHECKER] drbId(%d) %s recover\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
        }

        if (pdcpConfig.bit_mask & E1_pDCP_Reestablishment_present)
        {
            callInfo.checker.drb[drbInfo.dRBId].up_recover_reest = 2;
            VCCB_PRINTF("[CHECKER] drbId(%d) %s reest\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
        }
    }

    // Stop
    if (drbToModifyItem.bit_mask & E1_DRB_To_Modify_Item_NG_RAN_cell_Group_To_Modify_present)
    {
        auto list = drbToModifyItem.cell_Group_To_Modify;

        for (;list; list = list->next)
        {
            auto *info = reinterpret_cast<E1_Cell_Group_Information_Item *>(&list->value);

            if (info->bit_mask & E1_dL_TX_Stop_present)
            {
                if (info->cell_Group_ID == 0)
                {
                    if (info->dL_TX_Stop == E1_DL_TX_Stop_stop)
                    {
                        callInfo.checker.drb[drbInfo.dRBId].mcg_dl_tx_stop = true;
                        VCCB_PRINTF("[CHECKER] drbId(%d) %s mcg Stop\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
                    }
                }

                if (info->cell_Group_ID == 1)
                {
                    if (info->dL_TX_Stop == E1_DL_TX_Stop_stop)
                    {
                        callInfo.checker.drb[drbInfo.dRBId].scg_dl_tx_stop = true;
                        VCCB_PRINTF("[CHECKER] drbId(%d) %s scg Stop\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
                    }
                }
            }
        }
    }

    // TNL
    if (drbToModifyItem.bit_mask & E1_DRB_To_Modify_Item_NG_RAN_dL_UP_Parameters_present)
    {
        auto list = drbToModifyItem.dL_UP_Parameters;

        for ( ; list; list = list->next)
        {
            auto *info = reinterpret_cast<E1_UP_Parameters_Item *>(&list->value);

            auto &upTnlInfo = info->uP_TNL_Information;
            if (upTnlInfo.choice == E1_gTPTunnel_chosen)
            {
                auto &tunnel = upTnlInfo.u.gTPTunnel;

                if (info->cell_Group_ID == 0)
                {
                    auto tempDb = callInfo.checker.drb[drbInfo.dRBId].f1uUlInfo_mcg;

                    auto &tnlDb = callInfo.checker.drb[drbInfo.dRBId].f1uUlInfo_mcg;

                    tnlDb.TEID = teidToU32(tunnel.gTP_TEID);
                    tnlDb.numTLAbit = copyTlAddress(tunnel.transportLayerAddress, tnlDb.TLAddr);
                    VCCB_PRINTF("[CHECKER] drbId(%d) %s mcg tnl received(%d) %0x8X\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state), tnlDb.numTLAbit, tnlDb.TEID);

                    if (tempDb.numTLAbit > 0)
                    {
                        if (tempDb.numTLAbit == tnlDb.numTLAbit)
                        {
                            if (tempDb.TEID == tnlDb.TEID)
                            {
                            }
                            else
                            {
                                if (callInfo.checker.drb[drbInfo.dRBId].mcg_dl_tx_stop == false)
                                {
                                    VCCB_PRINTF("[CHECKER!!] drbId(%d) %s mcg teid is updated\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
                                }
                            }
                        }
                        else
                        {
                            if (callInfo.checker.drb[drbInfo.dRBId].mcg_dl_tx_stop == false)
                            {
                                VCCB_PRINTF("[CHECKER!!] drbId(%d) %s mcg numTLAbit is updated\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
                            }
                        }
                    }
                }

                if (info->cell_Group_ID == 1)
                {
                    auto tempDb = callInfo.checker.drb[drbInfo.dRBId].f1uUlInfo_scg;

                    auto &tnlDb = callInfo.checker.drb[drbInfo.dRBId].f1uUlInfo_scg;

                    tnlDb.TEID = teidToU32(tunnel.gTP_TEID);
                    tnlDb.numTLAbit = copyTlAddress(tunnel.transportLayerAddress, tnlDb.TLAddr);
                    VCCB_PRINTF("[CHECKER] drbId(%d) %s scg tnl received(%d) %0x8X\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state), tnlDb.numTLAbit, tnlDb.TEID);

                    if (tempDb.numTLAbit > 0)
                    {
                        if (tempDb.numTLAbit == tnlDb.numTLAbit)
                        {
                            if (tempDb.TEID == tnlDb.TEID)
                            {
                            }
                            else
                            {
                                if (callInfo.checker.drb[drbInfo.dRBId].scg_dl_tx_stop == false)
                                {
                                    VCCB_PRINTF("[CHECKER!!] drbId(%d) %s scg teid is updated\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
                                }
                            }
                        }
                        else
                        {
                            if (callInfo.checker.drb[drbInfo.dRBId].scg_dl_tx_stop == false)
                            {
                                VCCB_PRINTF("[CHECKER!!] drbId(%d) %s scg numTLAbit is updated\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
                            }
                        }
                    }
                }
            }
        }
    }

    // Resume
    if (drbToModifyItem.bit_mask & E1_DRB_To_Modify_Item_NG_RAN_cell_Group_To_Modify_present)
    {
        auto list = drbToModifyItem.cell_Group_To_Modify;

        for (;list; list = list->next)
        {
            auto *info = reinterpret_cast<E1_Cell_Group_Information_Item *>(&list->value);

            if (info->bit_mask & E1_dL_TX_Stop_present)
            {
                if (info->cell_Group_ID == 0)
                {
                    if (info->dL_TX_Stop == E1_DL_TX_Stop_resume)
                    {
                        callInfo.checker.drb[drbInfo.dRBId].mcg_dl_tx_stop = false;
                        VCCB_PRINTF("[CHECKER] drbId(%d) %s mcg Resume\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
                    }
                }

                if (info->cell_Group_ID == 1)
                {
                    if (info->dL_TX_Stop == E1_DL_TX_Stop_resume)
                    {
                        callInfo.checker.drb[drbInfo.dRBId].scg_dl_tx_stop = false;
                        VCCB_PRINTF("[CHECKER] drbId(%d) %s scg Resume\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
                    }
                }
            }
        }
    }

    // remove
    if (drbToModifyItem.bit_mask & E1_DRB_To_Modify_Item_NG_RAN_cell_Group_To_Remove_present)
    {
        auto list = drbToModifyItem.cell_Group_To_Remove;

        for (;list; list = list->next)
        {
            auto *info = reinterpret_cast<E1_Cell_Group_Information_Item *>(&list->value);
            if (info->cell_Group_ID == 0)
            {
                // TBD: add the skip condition with used flag
                callInfo.checker.drb[drbInfo.dRBId].mcg_dl_tx_stop = false;
                callInfo.checker.drb[drbInfo.dRBId].mcg_used = false;
                VCCB_PRINTF("[CHECKER] drbId(%d) %s mcg removed\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
            }

            if (info->cell_Group_ID == 1)
            {
                // TBD: add the skip condition with used flag
                callInfo.checker.drb[drbInfo.dRBId].scg_dl_tx_stop = false;
                callInfo.checker.drb[drbInfo.dRBId].scg_used = false;
                VCCB_PRINTF("[CHECKER] drbId(%d) %s scg removed\n", drbInfo.dRBId, FnVCCB_GetStrStateName(callInfo.state));
            }
        }
    }
}

// E1_DRB_To_Remove_Item_NG_RAN
void FnVCCB_CheckE1_DRBToRemoveItemNGRAN(callInfo_type &rCall, callDRBInfo_type &rDrb, E1_DRB_To_Remove_Item_NG_RAN &drbToRemoveItem)
{
    (void) drbToRemoveItem; // not used yet
    rCall.checker.drb[rDrb.dRBId].mcg_used = false;
    rCall.checker.drb[rDrb.dRBId].scg_used = false;
}

void FnVCCB_CheckE1_PDUSessionResourceToRemoveItem(callInfo_type &rCall, callPDUSessInfo_type &rPdu)
{
    for (auto &rDrbIdxInCall : rPdu.drbIndex)
    {
        if (rDrbIdxInCall >= MAX_DRB_PER_SA_CALL) continue;

        auto &rDrb = rCall.drb[rDrbIdxInCall];

        // TODO: need to filter withterminated point. MN has the MN, SN DRB

        rCall.checker.drb[rDrb.dRBId].mcg_used = false;
        rCall.checker.drb[rDrb.dRBId].scg_used = false;
    }
}

// E1_PDU_Session_Resource_To_Remove_Item   
void FnVCCB_Check_BearerContextReleaseCommand(callInfo_type &rCall, uint16_t servingUpIdx)
{
    if (rCall.callType == E_CALLTYPE_NSA) return;

    for (auto &rPdu : rCall.pduSess)
    {
        if (rPdu.usage == false) continue;
        if (rPdu.isE1Setupped == false) continue;
        if (rPdu.e1Idx != servingUpIdx) continue;

        // remove drb db with PDU information
        FnVCCB_CheckE1_PDUSessionResourceToRemoveItem(rCall, rPdu);
    }
    // TODO: find the drb id list from pdu db
    // (void) drbToRemoveItem; // not used yet
}
#endif

VCCB_STATIC_INLINE
void FnVCCB_FillE1TxStopResume(callDRBInfo_type *ptDi, E1_Cell_Group_Information_Item *pCellGroupInfo, enumTxCtrltype txCtrl)
{
    VALID_E_POINT_CHECK_VOID(ptDi);
    VALID_E_POINT_CHECK_VOID(pCellGroupInfo);

#ifdef IPC_TEST
    auto fillStopResumeFlag = [&ptDi, &pCellGroupInfo, &txCtrl]()
    {
        auto cellGroupId = pCellGroupInfo->cell_Group_ID;

        if (cellGroupId == CellGroupId_MCG)
        {
            switch(txCtrl)
            {
                case TX_STOP:
                    ptDi->mCG_E1STOP = TRUE;
                    break;
                case TX_RESUME:
                    ptDi->mCG_E1STOP = FALSE;
                    break;
                default:
                    break;
            }
        }

        if (cellGroupId == CellGroupId_SCG)
        {
            switch(txCtrl)
            {
                case TX_STOP:
                    ptDi->sCG_E1STOP = TRUE;
                    break;
                case TX_RESUME:
                    ptDi->sCG_E1STOP = FALSE;
                    break;
                default:
                    break;
            }
        }
    };

    fillStopResumeFlag();
#endif

    switch(txCtrl)
    {
        default:
        case TX_NO_CONTROL:
            OFF_PRESENT_BIT(pCellGroupInfo->bit_mask, E1_dL_TX_Stop_present);
            return;

        case TX_STOP:
            pCellGroupInfo->bit_mask |= E1_dL_TX_Stop_present;
            pCellGroupInfo->dL_TX_Stop = E1_DL_TX_Stop_stop;
            return;

        case TX_RESUME:
            pCellGroupInfo->bit_mask |= E1_dL_TX_Stop_present;
            pCellGroupInfo->dL_TX_Stop = E1_DL_TX_Stop_resume;
            return;
    }
}

// 9.3.1.1 Message Type
// 9.3.1.2 Cause
// 9.3.1.3 Criticality Diagnostics
// 9.3.1.4 gNB-CU-CP UE E1AP ID
// 9.3.1.5 gNB-CU-UP UE E1AP ID
// 9.3.1.6 Time To wait
// 9.3.1.7 PLMN Identity
// 9.3.1.8 Slice Support List
// 9.3.1.9 S-NSSAI
/**
 * @brief fill SNSSAI
 * @attention function sets all bit_mask
 * @return      GOOD        : success fill
 * @return      ERROR       : fill error
 */
int VEIL_fillE1_SNSSAI(E1_SNSSAI *ptSnssai, callSNSSAI_type *ptQi_Snssai)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptSnssai);
    VALID_E_POINT_CHECK_ERROR(ptQi_Snssai);

    ptSnssai->bit_mask = 0;

    // SST - mandatory
    MACRO_PACK_OCTET(&ptSnssai->sST, 1, ptQi_Snssai->sst);  // OCTET STRING(1)

    // SD - optional
    if (ptQi_Snssai->sdPresent)
    {
        ptSnssai->bit_mask |= E1_sD_present;
        MACRO_PACK_OCTET(&ptSnssai->sD, 3, ptQi_Snssai->sd);  // OCTET STRING(3)
    }

    if (DBG->flag.logE1)
        VCCB_PRINT_DATA("[E1DBG] ptSnssai->sST.length:%d .value[0]:%d\n", ptSnssai->sST.length, ptSnssai->sST.value[0]);

    return GOOD;
}

// 9.3.1.10 Security Information
// 9.3.1.11 Cell Group Information
// 9.3.1.12 QoS Flow List
// 9.3.1.13 UP Parameters
// 9.3.1.14 NR CGI
// 9.3.1.15 gNB-CU-UP ID
// 9.3.1.16 DRB ID
// 9.3.1.17 E-UTRAN QoS
// 9.3.1.18 E-UTRAN Allocation and Retention Priority
// 9.3.1.19 GBR QoS Information
// 9.3.1.20 Bit Rate
int16_t VEIL_FillE1_BitRate(/*Out*/ E1_BitRate *ptOut, /*In*/ uint64_t inputValue)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptOut);

    switch (inputValue)
    {
        case 0 ... MAX_EXTENDED_BITRATE:
            *ptOut = (E1_BitRate)inputValue;
            return GOOD;

        default:
            VCCB_PRINT_ERROR(
                "BitRate: Invalid Range!! (range: 0~%ld, val:%llu)\n", MAX_EXTENDED_BITRATE, 1ULL * inputValue);
            return ERROR;
    }
}

// 9.3.1.21 PDU Session ID
// 9.3.1.22 PDU Session Type
// 9_3_1_23 Security Indication
void VEIL_FillE1_SecurityIndication(E1_SecurityIndication *p, securityIndication_type *pInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(p);
    VALID_E_POINT_CHECK_VOID(pInfo);

    p->bit_mask = 0;
    p->integrityProtectionIndication = static_cast<E1_IntegrityProtectionIndication>(pInfo->integProtectInd);
    p->confidentialityProtectionIndication =
        static_cast<E1_ConfidentialityProtectionIndication>(pInfo->confidenProtectInd);

    // This IE shall be present if the Integrity Protection Indication IE within the Security Indication IE is present
    // and set to required.
    if (pInfo->integProtectInd == ci_integ_protect_required)
    {
        p->bit_mask |= E1_maximumIPdatarate_present;
        p->maximumIPdatarate.bit_mask = 0;
        p->maximumIPdatarate.maxIPrate = static_cast<E1_MaxIPrate>(pInfo->maxIPrate);
    }
}

// 9.3.1.24 QoS Flow Identifier
// 9.3.1.25 QoS Flow QoS Parameters List
// 9.3.1.26 QoS Flow Level QoS Parameters
// 9.3.1.27 Non Dynamic 5QI Descriptor
// 9.3.1.28 Dynamic 5QI Descriptor
// 9.3.1.29 NG-RAN Allocation and Retention Priority
// 9.3.1.30 GBR QoS Flow Information
// 9.3.1.31 Security Algorithm
// 9.3.1.32 User Plane Security Keys
// 9.3.1.33 UL Configuration
// 9.3.1.34 gNB-CU-UP Cell Group Related Configuration
// 9.3.1.35 PDCP Count
// 9.3.1.36 NR CGI Support List
// 9.3.1.37 QoS Parameters Support List
// 9.3.1.38 PDCP Configuration
// 9.3.1.39 SDAP Configuration
// 9.3.1.40 ROHC Parameters
// 9.3.1.41 T-Reordering Timer
// 9.3.1.42 Discard Timer
// 9.3.1.43 UL Data Split Threshold
// 9.3.1.44 Data Usage Report List
// 9.3.1.45  Flow Failed List
// 9.3.1.46 Packet Loss Rate
// 9.3.1.47 Packet Delay Budget
// 9.3.1.48 Packet Error Rate
// 9.3.1.49 Averaging Window
// 9.3.1.50 Maximum Data Burst Volume
// 9.3.1.51 Priority Level
// 9.3.1.52 Security Result
// 9.3.1.53 Transaction ID
// 9_3_1_54 Inactivity timer
bool VEIL_check_E1_Inactivity_Timer(callInfo_type *ptCi, callPDUSessInfo_type *ptPi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptPi, false);

    if (IS_SUPPORT_RRC_INACTIVE(ptCi))
    {
        return false;
    }
    else if (ptCi->CallUserInactivity.activityNotificationLevel == activityNotifLvl_PDUSession)
    {
        return true;
    }

    return false;
}

bool VEIL_check_E1_Inactivity_Timer(callInfo_type *ptCi, callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    if (IS_SUPPORT_RRC_INACTIVE(ptCi))
    {
        if (IS_RRC_INACTIVE_DRB_LEVEL(ptCi))
        {
            return true;
        }
    }
    else if (ptCi->CallUserInactivity.activityNotificationLevel == activityNotifLvl_DRB)
    {
        return true;
    }

    return false;
}

int VEIL_fillE1_Inactivity_Timer(callInfo_type *ptCi, callPDUSessInfo_type *ptPi, E1_Inactivity_Timer *p)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptPi);
    VALID_E_POINT_CHECK_ERROR(p);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    // TODO: need to check the inactivity feature
    uint16_t pduSessionID = ptPi->pduSessId;

    if (pduSessionID >= MAX_PDU_SESS_PER_CALL)
    {
        return ERROR;
    }

    *p = GNBINFO[ptCi->gnbNum].UserInactivitySA.pDUSessionInactivityTimerEntries[pduSessionID];

    return GOOD;
}

void FnVCCB_GetCellNumForSaUserInactInE1Proc(const callInfo_type &rCall, uint16_t *pCellNum)
{
    AUTO_TRACE_FUNC;

    *pCellNum = rCall.servCellNum;

    // This function is for Only MN Side.
    if (IS_NRDC_SN(&rCall)) return;

    // Intra-gNB (H/O or RRE)
    if (rCall.stateCmd == IntraRatHO_cmd)
    {
        switch (rCall.state)
        {
            // H/O in MN. (TX_RESUME)
            case STATE_INTRA_DU_Complete:   // Intra-DU
            case STATE_INTER_DU_Complete:   // Inter-DU
                *pCellNum = rCall.hoInfo.targetCellNum;
                break;

            default:
                // Already set as rCall.servCellNum for source cell.
                break;
        }
    }
    // Intr-gNB RRE
    else if (FnVCCB_IsSaIntraGnbRreUE(rCall))
    {
        switch (rCall.state)
        {
            // RRE (STOP)
            case STATE_RRE_Ready:
                *pCellNum = rCall.ueInfo.reestablishInfo.firstOldCellNum;
                break;
            default:
                // Already set as rCall.servCellNum for target cell.
                break;
        }
    }
    return;
}

saDataInactProfile_type *FnVCCB_SA_GetProfileAddrForDataInactInE1Proc(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptCi);

    uint16_t gnbNum = ptCi->gnbNum;
    VCCB_CHECK_VALID_GNBNUM_NULL(gnbNum);
    
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    uint16_t cellNum = MAX_CELL_NUM_VCCB;
    uint16_t profileIdx = 0;

    /* Get Target CellNum for Intra-gNB H/O and RRE */
    FnVCCB_GetCellNumForSaUserInactInE1Proc(*ptCi, &cellNum);

    VCCB_CHECK_VALID_CELLNUM_NULL(cellNum);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    /* Get Cell Profile */
    SET_REDCAP_OR_NORM_VAL(ptCi, profileIdx, pCell->profileDBInfo.saDataInactivityProfileIdx_Redcap,
        pCell->profileDBInfo.saDataInactivityProfileIdx);
    if (profileIdx >= VCCB_MAX_USER_INACT_SA_PROFILES) return NULL;

    return (&pGnb->UserInactivitySA.dataProfileInfo[profileIdx]);
}

bool FnVCCB_GetDataInactTime_RFSP_DrbLevel_PerCell(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint16_t *pFindVal)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);
    VALID_E_POINT_CHECK_RET_VAL(pFindVal, false);

    uint16_t rfspIndex = 0;
    uint16_t isRfspUeLevelFound = 0;

    uint16_t drbQosIdxInCall = ptDi->drbQosIdxInCall;
    uint8_t qos5qi;
    qosFlowInfo_type *ptQi = NULL;
    saDataInactProfile_type *pDataProfile = NULL;
    rfspBasedInactivityList_type *pRfspList = NULL;

    if (IS_NRDC_SN(ptCi)) return false;

    /* Get Profile and Check Usage */
    pDataProfile = FnVCCB_SA_GetProfileAddrForDataInactInE1Proc(ptCi); // Redcap and normal UE
    if (pDataProfile == NULL) return false;
    if (pDataProfile->usage != CI_use) return false;

    /* Find RFSP and Fill DRB Value in Cell DB */
    for (rfspIndex = 0; rfspIndex < VCCB_MAX_USER_INACT_RFSP_LIST; rfspIndex++)
    {
        pRfspList = &pDataProfile->rfspList[rfspIndex];
        if ((pRfspList->usage == CI_use) && (pRfspList->rfsp == ptCi->CallUserInactivity.rfspVal))
        {
            *pFindVal = pRfspList->ueInactivityTimer; // Ue Level.
            isRfspUeLevelFound++;

            if ((drbQosIdxInCall < MAX_QOS_FLOW_PER_CALL) && (ptCi->qosFlow[drbQosIdxInCall].usage == CI_use))
            {
                ptQi = &ptCi->qosFlow[drbQosIdxInCall];
                VLIB_getFiveQi(ptQi, &qos5qi);

                if (pRfspList->drbInactivityTimerEntries[qos5qi] != 0)
                {
                    *pFindVal = pRfspList->drbInactivityTimerEntries[qos5qi];
                    return true;
                }
            }
            break;
        }
    }

    // RFSP UE Level in Cell DB.
    if (isRfspUeLevelFound)
    {
        // Already Updated findVal in for loop.
        return true;
    }

    // If Not Found, then using UE Level in Cell DB
    *pFindVal = pDataProfile->ueInactivityTimer; 
    
    return true;
}

bool FnVCCB_GetDataInactTime_RFSP_DrbLevel_PerGnb(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint16_t *pFindVal)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);
    VALID_E_POINT_CHECK_RET_VAL(pFindVal, false);

    uint16_t gnbNum = ptCi->gnbNum;
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(gnbNum, false);
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    uint16_t drbQosIdxInCall = ptDi->drbQosIdxInCall;
    uint8_t qos5qi;
    uint16_t rfspIndex = 0;
    uint16_t isRfspUeLevelFound = 0;
    qosFlowInfo_type *ptQi = NULL;
    rfspBasedUserInactivityControl_type *pRfspDB = NULL;
    rfspBasedInactivityList_type *pRfspList = NULL;

    if (IS_NRDC_SN(ptCi))
    {
        pRfspDB = &pGnb->UserInactivityNrdcSN.rfspControlInfo;
    }
    else
    {
        SET_REDCAP_OR_NORM_VAL(
            ptCi, pRfspDB, &pGnb->UserInactivitySA.redCap.rfspControlInfo, &pGnb->UserInactivitySA.rfspControlInfo);
    }

    /* Find RFSP and Fill DRB Value in gNB DB */
    for (rfspIndex = 0; rfspIndex < VCCB_MAX_USER_INACT_RFSP_LIST; rfspIndex++)
    {
        pRfspList = &pRfspDB->rfspList[rfspIndex];

        if ((pRfspList->usage == CI_use) && (pRfspList->rfsp == ptCi->CallUserInactivity.rfspVal))
        {
            // Update
            *pFindVal = pRfspList->ueInactivityTimer; // UE Level.
            isRfspUeLevelFound++;

            if ((drbQosIdxInCall < MAX_QOS_FLOW_PER_CALL) && (ptCi->qosFlow[drbQosIdxInCall].usage == CI_use))
            {
                ptQi = &ptCi->qosFlow[drbQosIdxInCall];
                VLIB_getFiveQi(ptQi, &qos5qi);

                if (pRfspList->drbInactivityTimerEntries[qos5qi] != 0)
                {
                    *pFindVal = pRfspList->drbInactivityTimerEntries[qos5qi];
                    return true;
                }
            }
            break;
        }
    }
    
    // RFSP UE Level in gNB DB.
    if (isRfspUeLevelFound)
    {
        // Already Updated findVal in for loop.
        return true;
    }

    // If Not Found, then using UE Level in gNB DB
    if (IS_NRDC_SN(ptCi))
    {
        *pFindVal = pGnb->UserInactivityNrdcSN.ueInactivityTimer;
    }
    else
    {
        SET_REDCAP_OR_NORM_VAL(
            ptCi, *pFindVal, pGnb->UserInactivitySA.redCap.ueInactivityTimer, pGnb->UserInactivitySA.ueInactivityTimer);
    }

    return true;
}

bool FnVCCB_GetaDataInactTime_DrbLevel_PerCell(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint16_t *pFindVal)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);
    VALID_E_POINT_CHECK_RET_VAL(pFindVal, false);

    uint16_t drbQosIdxInCall = ptDi->drbQosIdxInCall;
    uint8_t qos5qi;
    qosFlowInfo_type *ptQi = NULL;
    saDataInactProfile_type *pDataProfile = NULL;

    /* Support Only MN Side */
    if (IS_NRDC_SN(ptCi)) return false;

    /* Get Profile and Check Usage */
    pDataProfile = FnVCCB_SA_GetProfileAddrForDataInactInE1Proc(ptCi);
    if (pDataProfile == NULL) return false;
    if (pDataProfile->usage != CI_use) return false;

    /* Fill DRB Value in Cell DB */
    if ((drbQosIdxInCall < MAX_QOS_FLOW_PER_CALL) && (ptCi->qosFlow[drbQosIdxInCall].usage == CI_use))
    {
        ptQi = &ptCi->qosFlow[drbQosIdxInCall];
        VLIB_getFiveQi(ptQi, &qos5qi);

        if (pDataProfile->drbInactivityTimerEntries[qos5qi] != 0)
        {
            *pFindVal = pDataProfile->drbInactivityTimerEntries[qos5qi];
            return true;
        }
    }

    // If Not Found, then using UE Level in Cell DB
    *pFindVal = pDataProfile->ueInactivityTimer;
    return true;
}

bool FnVCCB_GetDataInactTime_DrbLevel_PerGnb(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint16_t *pFindVal)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);
    VALID_E_POINT_CHECK_RET_VAL(pFindVal, false);

    uint16_t gnbNum = ptCi->gnbNum;
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(gnbNum, false);
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    uint16_t drbQosIdxInCall = ptDi->drbQosIdxInCall;
    uint8_t qos5qi;
    qosFlowInfo_type *ptQi = NULL;

    /* Fill DRB Value in gNB DB */
    if ((drbQosIdxInCall < MAX_QOS_FLOW_PER_CALL) && (ptCi->qosFlow[drbQosIdxInCall].usage == CI_use))
    {
        ptQi = &ptCi->qosFlow[drbQosIdxInCall];
        VLIB_getFiveQi(ptQi, &qos5qi);

        if (IS_NRDC_SN(ptCi))
        {
            if (pGnb->UserInactivityNrdcSN.drbInactivityTimerEntries[qos5qi] != 0)
            {
                *pFindVal = pGnb->UserInactivityNrdcSN.drbInactivityTimerEntries[qos5qi];
                return true;
            }
        }
        else if (IS_REDCAP_UE(ptCi))
        {
            if (pGnb->UserInactivitySA.redCap.drbInactivityTimerEntries[qos5qi] != 0)
            {
                *pFindVal = pGnb->UserInactivitySA.redCap.drbInactivityTimerEntries[qos5qi];
                return true;
            }
        }
        else
        {
            if (pGnb->UserInactivitySA.drbInactivityTimerEntries[qos5qi] != 0)
            {
                *pFindVal = pGnb->UserInactivitySA.drbInactivityTimerEntries[qos5qi];
                return true;
            }
        }
    }

    // If Not Found, then using UE Level in gNB DB
    if (IS_NRDC_SN(ptCi))
    {
        *pFindVal = pGnb->UserInactivityNrdcSN.ueInactivityTimer;
    }
    else
    {
        SET_REDCAP_OR_NORM_VAL(
            ptCi, *pFindVal, pGnb->UserInactivitySA.redCap.ueInactivityTimer, pGnb->UserInactivitySA.ueInactivityTimer);
    }

    return true;
}

int VEIL_fillE1_Inactivity_Timer(callInfo_type *ptCi, callDRBInfo_type *ptDi, E1_Inactivity_Timer *p)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);
    VALID_E_POINT_CHECK_ERROR(p);

    uint16_t gnbNum = ptCi->gnbNum;
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    uint16_t drbQosIdxInCall = ptDi->drbQosIdxInCall;
    uint8_t qos5qi;
    qosFlowInfo_type *ptQi = NULL;

    if (IS_SUPPORT_RRC_INACTIVE(ptCi))
    {
        if ((drbQosIdxInCall < MAX_QOS_FLOW_PER_CALL) && (ptCi->qosFlow[drbQosIdxInCall].usage == CI_use))
        {
            ptQi = &ptCi->qosFlow[drbQosIdxInCall];
            VLIB_getFiveQi(ptQi, &qos5qi);

            const auto &call = *ptCi;
            int32_t defaultTimer = (int32_t)FnVCCB_GetRRCInactiveTimerValue(call, qos5qi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, defaultTimer, "FnVCCB_GetRRCInactiveTimerValue ERROR!\n");

            // AI 포인트①: AI Client가 추천하는 inactivityTimer 값 적용.
            // Fallback 상태거나 REDCAP/NRDC UE이면 defaultTimer 그대로 사용.
            *p = static_cast<E1_Inactivity_Timer>(VccbAiClient_RecommendInactivityTimer(ptCi, defaultTimer));

            return GOOD;
        }

        // in the invalid case, refer to the UE-inactivity-timer
        // SVR25B FGR-CC0103
        if (ptCi->ueInfo.rrcResumeInfo.actionInSNRelease == SN_REL_IN_RRC_INACTIVE_DECIDED && (not IS_NRDC_SN(ptCi)))
        {
            *p = static_cast<E1_Inactivity_Timer>(1);
        }
        else
        {
            *p = IS_REDCAP_UE(ptCi) ? pGnb->RrcInactiveInfo.redCapRrcInactiveTimer : pGnb->RrcInactiveInfo.rrcInactiveTimer;
        }
        return GOOD;
    }
    else  // Basic, NR-DC SN
    {
        uint16_t findVal = 0;
        bool status = false;

        if (ptCi->CallUserInactivity.rfspBasedControlFlag == ON)
        {
            // Find Value with Cell
            if ((!IS_NRDC_SN(ptCi)) && (ptCi->CallUserInactivity.dataInactivityPerCellOnOff))
            {
                // Refer Cell Profile DB
                status = FnVCCB_GetDataInactTime_RFSP_DrbLevel_PerCell(ptCi, ptDi, &findVal);
                if (status == true)
                {
                    *p = findVal;
                    return GOOD;
                }
                // If Not Found, keep going with GNB.
            }

            // Find Value with GNB
            status = FnVCCB_GetDataInactTime_RFSP_DrbLevel_PerGnb(ptCi, ptDi, &findVal);
            if (status == true)
            {
                *p = findVal;
                return GOOD;
            }
            // No Case, But Using pGnb->UserInactivitySA.ueInactivityTimer.
        }
        else
        {
            // Find Value with Cell
            if ((!IS_NRDC_SN(ptCi)) && (ptCi->CallUserInactivity.dataInactivityPerCellOnOff))
            {
                // Refer Cell Profile DB
                status = FnVCCB_GetaDataInactTime_DrbLevel_PerCell(ptCi, ptDi, &findVal);
                if(status == true)
                {
                    *p = findVal;
                    return GOOD;
                }
                // If Not Found, keep going with GNB.
            }

            // Find Value with GNB
            status = FnVCCB_GetDataInactTime_DrbLevel_PerGnb(ptCi, ptDi, &findVal);
            if(status == true)
            {
                *p = findVal;
                return GOOD;
            }
            // No Case, But Using pGnb->UserInactivitySA.ueInactivityTimer.
        }

        // No Case, But Using pGnb->UserInactivitySA.ueInactivityTimer.
        SET_REDCAP_OR_NORM_VAL(
            ptCi, *p, pGnb->UserInactivitySA.redCap.ueInactivityTimer, pGnb->UserInactivitySA.ueInactivityTimer);

        return GOOD;
    }
}

// 9.3.1.55 Paging Priority Indicator (PPI)
// 9.3.1.56 gNB-CU-UP Capacity
// 9.3.1.57 Maximum Integrity Protected Data Rate
// 9_3_1_58 PDCP SN Status Information
int VEIL_Check_IncludePdcpSN(callInfo_type *ptCi, callDRBInfo_type *pDRBInfo, bool *ptIncludeVersionChangeInd)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDRBInfo);
    VALID_E_POINT_CHECK_ERROR(ptIncludeVersionChangeInd);

    *ptIncludeVersionChangeInd = false;

    switch (ptCi->state)
    {
        case STATE_INTRA_DU_SnRelB:
        case STATE_INTER_DU_SnRelB:
        case STATE_INTRA_DU_Execution:  // Intra-gNB Intra-DU HO after sending reconfiguration
        case STATE_INTER_DU_Execution:  // Intra-gNB Inter-DU HO after sending reconfiguration
        case STATE_INTER_Exe_T:         // Inter-gNB XN/NG HO
        case STATE_Intra_Cell_Complete:      // Intra Cell HO after sending reconfiguration

            if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi))
            {
                *ptIncludeVersionChangeInd = true;
                // In the case of Full Configuration, since SN information is initialized, it is not checked whether the
                // existing SN is acquired.
                return GOOD;
            }
            else
            {
                if (ptCi->stateCmd == InterRatHO_cmd)
                {
                    *ptIncludeVersionChangeInd = true;
                    // Transmitted only when PDCP SN is acquired.
                    return GOOD;
                }

                if (pDRBInfo->dataFwdInfo.snStatus.needSendFlag == TRUE)
                {
                    // Transmitted only when PDCP SN is acquired.
                    return GOOD;
                }
            }
            break;

        case STATE_RRE_F1SetupMod:
            if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi))
            {
                if (!pDRBInfo->rbInfo.rlcModePresent || pDRBInfo->rbInfo.rlcMode != AM_RLC ||
                    (pDRBInfo->rbInfo.rlcModePresent && pDRBInfo->rbInfo.rlcMode == AM_RLC && pDRBInfo->dataFwdInfo.snStatus.needSendFlag == TRUE))
                {
                    *ptIncludeVersionChangeInd = true;
                    return GOOD;
                }
            }
            else
            {
                if (pDRBInfo->dataFwdInfo.snStatus.needSendFlag == TRUE)
                {
                    return GOOD;
                }
            }
            break;

        case STATE_RRE_RRCRecCmpl:      // Inter-gNB RRE
            if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi))
            {
                if (pDRBInfo->rbInfo.rlcModePresent && pDRBInfo->rbInfo.rlcMode == AM_RLC && pDRBInfo->dataFwdInfo.snStatus.needSendFlag == TRUE)
                {
                    *ptIncludeVersionChangeInd = true;
                    return GOOD;
                }
            }
            else
            {
                if (pDRBInfo->dataFwdInfo.snStatus.needSendFlag == TRUE)
                {
                    return GOOD;
                }
            }
            break;

        case STATE_SN_SNAddExec:
        case STATE_SN_SNAddComplt_F1E1Mod:
        case STATE_SN_SNModExec:
        case STATE_SN_SNModComplt_F1E1Mod:
            if (pDRBInfo->dataFwdInfo.snStatus.needSendFlag == TRUE)
            {
                // Transmitted only when PDCP SN is acquired.
                return GOOD;
            }
            break;

        default:
            break;
    }

    if (IS_NRDC_MN(ptCi) && IS_ON_E1_MRDC_CTRL_FLAG(pDRBInfo, mcgMod_pdcpSNStatusInfo))
    {
        return GOOD;
    }

    return ERROR;
}

void VEIL_fillE1_PDCP_SN_Status_Information(
    callInfo_type *ptCi, callDRBInfo_type *ptDi, E1_PDCP_SN_Status_Information *p, bool includeVersionChangeInd)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptDi);
    VALID_E_POINT_CHECK_VOID(p);

    p->bit_mask = 0;

    // pdcpStatusTransfer_UL
    p->pdcpStatusTransfer_UL.bit_mask = 0;

    // pdcpStatusTransfer_UL::receiveStatusofPDCPSDU : not support, always not present

    // pdcpStatusTransfer_UL::countValue
    p->pdcpStatusTransfer_UL.countValue.bit_mask = 0;
    if (includeVersionChangeInd == TRUE)
    {
        p->pdcpStatusTransfer_UL.countValue.pDCP_SN = 0;
        p->pdcpStatusTransfer_UL.countValue.hFN = 0;
    }
    else
    {
        p->pdcpStatusTransfer_UL.countValue.pDCP_SN = ptDi->dataFwdInfo.snStatus.ulSN;
        p->pdcpStatusTransfer_UL.countValue.hFN = ptDi->dataFwdInfo.snStatus.ulHFN;
    }

    // pdcpStatusTransfer_DL
    p->pdcpStatusTransfer_DL.bit_mask = 0;
    if (includeVersionChangeInd == TRUE)
    {
        p->pdcpStatusTransfer_DL.pDCP_SN = 0;
        p->pdcpStatusTransfer_DL.hFN = 0;
    }
    else
    {
        p->pdcpStatusTransfer_DL.pDCP_SN = ptDi->dataFwdInfo.snStatus.dlSN;
        p->pdcpStatusTransfer_DL.hFN = ptDi->dataFwdInfo.snStatus.dlHFN;
    }

    // PDCP version Change for UP
    if (includeVersionChangeInd == TRUE)
    {
        p->bit_mask |= E1_PDCP_SN_Status_Information_iE_Extension_present;
    }

    if (IS_LOG_TRAFFIC(ptCi))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[TRAFFIC, E1]: PDCP-SN-COUNT (DRB ID:%u, UL:%u/%u, DL:%u/%u), VerChgInd(%d)\n",
            ptDi->dRBId,
            (unsigned int)p->pdcpStatusTransfer_UL.countValue.pDCP_SN,
            (unsigned int)p->pdcpStatusTransfer_UL.countValue.hFN,
            (unsigned int)p->pdcpStatusTransfer_DL.pDCP_SN,
            (unsigned int)p->pdcpStatusTransfer_DL.hFN,
            (int)includeVersionChangeInd);
    }
}

int VEIL_fillE1_PDCP_SN_Status_Information_Setup(callInfo_type *ptCi, callDRBInfo_type *ptDi,
    E1_DRB_To_Setup_Mod_Item_NG_RAN *p,
    E1_BearerContextModificationRequestBuffer::PduSessToBeSetupModData::DrbToBeSetupModData *ptDrbToBeSetupModBuffer)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);
    VALID_E_POINT_CHECK_ERROR(p);
    VALID_E_POINT_CHECK_ERROR(ptDrbToBeSetupModBuffer);

    bool includeVersionChangeInd = false;

    if (VEIL_Check_IncludePdcpSN(ptCi, ptDi, &includeVersionChangeInd) == GOOD)
    {
        ptDi->dataFwdInfo.snStatus.needSendFlag = FALSE;

        p->bit_mask |= E1_DRB_To_Setup_Mod_Item_NG_RAN_pDCP_SN_Status_Information_present;

        E1_PDCP_VersionChangeInd *pPdcpVersionChangeInd = &ptDrbToBeSetupModBuffer->pdcpVersionChangeInd;
        *pPdcpVersionChangeInd = E1_PDCP_VersionChangeInd_true;

        p->pDCP_SN_Status_Information.iE_Extension = &ptDrbToBeSetupModBuffer->pdcpSnStatusInfoExt;
        p->pDCP_SN_Status_Information.iE_Extension->next = NULL;

        InsertE1_ExtensionContainerValue(p->pDCP_SN_Status_Information.iE_Extension, E1_id_PDCP_VersionChangeInd,
            E1_ignore, pPdcpVersionChangeInd, E1_PDCP_VersionChangeInd_PDU);

        VEIL_fillE1_PDCP_SN_Status_Information(ptCi, ptDi, &p->pDCP_SN_Status_Information, includeVersionChangeInd);
    }

    return GOOD;
}

int VEIL_fillE1_PDCP_SN_Status_Information_Modify(callInfo_type *ptCi, callDRBInfo_type *ptDi,
    E1_DRB_To_Modify_Item_NG_RAN *p,
    E1_BearerContextModificationRequestBuffer::PduSessToBeModData::DrbToBeModData *ptDrbToBeModBuffer)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);
    VALID_E_POINT_CHECK_ERROR(p);
    VALID_E_POINT_CHECK_ERROR(ptDrbToBeModBuffer);

    bool includeVersionChangeInd = false;

    if (VEIL_Check_IncludePdcpSN(ptCi, ptDi, &includeVersionChangeInd) == GOOD)
    {
        ptDi->dataFwdInfo.snStatus.needSendFlag = FALSE;

        p->bit_mask |= E1_pdcp_SN_Status_Information_present;

        E1_PDCP_VersionChangeInd *pPdcpVersionChangeInd = &ptDrbToBeModBuffer->pdcpVersionChangeInd;
        *pPdcpVersionChangeInd = E1_PDCP_VersionChangeInd_true;

        p->pdcp_SN_Status_Information.iE_Extension = &ptDrbToBeModBuffer->pdcpSnStatusInfoExt;
        p->pdcp_SN_Status_Information.iE_Extension->next = NULL;

        InsertE1_ExtensionContainerValue(p->pdcp_SN_Status_Information.iE_Extension, E1_id_PDCP_VersionChangeInd,
            E1_ignore, pPdcpVersionChangeInd, E1_PDCP_VersionChangeInd_PDU);

        VEIL_fillE1_PDCP_SN_Status_Information(ptCi, ptDi, &p->pdcp_SN_Status_Information, includeVersionChangeInd);
    }

    return GOOD;
}

bool VEIL_check_E1_PDCP_SN_Status_Request(callInfo_type *ptCi, callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    switch (ptCi->state)
    {
        // NR-DC MN or gNB ue
        case STATE_INTER_SeqNum_S:
            if (ptCi->hoInfo.hoType.system == HO_TYPE_INTRA_SYSTEM)
            {
                return true;
            }
            // No need to send pDCP-SN-Status-Request in case of IRAT HO
            return false;

        case STATE_RRE_S_F1ModQuery:
            return IS_SUPPORT_ENC_XNSNStatusTransfer(ptCi);

        case STATE_RRE_S_XnUAddInd:
            return !(IS_SUPPORT_ENC_XNSNStatusTransfer(ptCi));

        // NR-DC SN ue
        case STATE_SN_SNRelExec:
            if (IS_SUPPORT_ENC_XNSNStatusTransfer(ptCi))
            {
                break;
            }
            return true;

        case STATE_SN_SNModExec:
            // There is no data forwarding case for MCG mobility
            // TBD (bearerType change with MCG mobility shall be include it)
            if (FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_McgMobility) == true)
            {
                return false;
            }

            if (IS_SUPPORT_ENC_XNSNStatusTransfer(ptCi))
            {
                break;
            }
            return true;

        case STATE_SN_SNRelPrepare_F1Mod:
        case STATE_SN_SNModPrepare_F1Mod1:
            if (IS_SUPPORT_ENC_XNSNStatusTransfer(ptCi))
            {
                return true;
            }
            break;
            // Inter SN mobility Source SN
        case STATE_SN_INTER_SN_Exe:
            return true;

        /*Inter gNB RRC Resume*/
        case STATE_Inact_S_XnUAddrInd:
            return true;

        default:
            break;
    }
    if (IS_ON_E1_MRDC_CTRL_FLAG(ptDi, mcgMod_pdcpSNStatusReq))
    {
        return true;
    }

    return false;
}

// 9.3.1.59 QoS Flow Mapping List
// 9.3.1.60 QoS Flow Mapping Indication
// 9.3.1.61 PDCP SN Size
// 9.3.1.62 Network Instance
// 9.3.1.63 MR-DC Usage Information
// 9.3.1.64 MR-DC Data Usage Report List
// 9.3.1.65 gNB-DU ID
// 9.3.1.66 Common Network Instance
// 9.3.1.67 Activity Notification Level
// 9.3.1.68 Trace Activation
// 9.3.1.69 Subscriber Profile ID for RAT/Frequency priority
// 9.3.1.70 Additional RRM Policy Index
// 9.3.1.71 Retainability Measurements Information
// 9.3.1.72 TNL Available Capacity Indicator
// 9.3.1.73 HW Capacity Indicator
// 9.3.1.74 Redundant QoS Flow Indicator
// 9.3.1.75 TSC Traffic Characteristics
// 9.3.1.76 TSC Assistance Information
// 9.3.1.77 Periodicity
// 9.3.1.78 Burst Arrival Time
// 9.3.1.79 Extended Packet Delay Budget
// 9.3.1.80 Redundant PDU Session Information
// 9.3.1.81 QoS Mapping Information
// 9.3.1.82 NID
// 9.3.1.83 NPN Support Information
// 9.3.1.84 NPN Context Information
// 9.3.1.85 MDT Configuration
// 9.3.1.86 M4 Configuration
// 9.3.1.87 M6 Configuration
// 9.3.1.88 M7 Configuration
// 9.3.1.89 MDT PLMN List
// 9.3.1.90 EHC Parameters
// 9.3.1.91 DAPS Request Information
// 9.3.1.92 Early Forwarding COUNT Information
// 9.3.1.35 PDCP-SN and Hyper frame number of the first DL SDU that the source NG-RAN node forwards to the target NG-RAN
// node 9.3.1.35 PDCP-SN and Hyper frame number for which the target NG-RAN node should discard forwarded DL SDUs
// associated with lower values. 9.3.1.93 Alternative QoS Parameters Set List 9.3.1.94 Extended Slice Support List
// 9.3.1.95 Extended gNB-CU-CP Name
// 9.3.1.96 Extended gNB-CU-UP Name

// 9.3.1.102 UE Slice Maximum Bit Rate List
int16_t VEIL_FillE1_UESliceMaximumBitRateList(
    callInfo_type &rCi, E1_UESliceMaximumBitRateList &ueSliceMaximumBitRateList, bool isSetupCtxt)
{
    AUTO_TRACE_FUNC;

    int16_t status = BREAK;

    if (isSetupCtxt || VCCB_FLAG_ON == rCi.ueInfo.sliceMbrInfo.fNeedModifyDl)
    {
        uint8_t numSliceMBR = 0;
        uint64_t dlUeSliceMBR = MAX_EXTENDED_BITRATE;
        bool needNrdcSliceMbrDistribution =
            (IS_MRDC_MN(&rCi) && rCi.mrdcInfo.mobilityCfg.ueState != ci_scg_released_ue &&
                !(IS_NRDC_SNREL_INVOKED(&rCi) || rCi.stateCmd == MrdcSNAddPrepareFail_cmd ||
                    rCi.mrdcInfo.queuedSNodeRelCause != MrdcRelCause_NoCause));

        for (uint8_t index = 0; index < MAX_NR_OF_SLICE_MBR; index++)
        {
            if (CI_use != rCi.ueInfo.sliceMbrInfo.detSliceMbr[index].usage)
            {
                continue;
            }

            if (needNrdcSliceMbrDistribution)
            {
                dlUeSliceMBR = rCi.ueInfo.sliceMbrInfo.ueSliceMbrDlMN[index];
            }
            else
            {
                dlUeSliceMBR = rCi.ueInfo.sliceMbrInfo.detSliceMbr[index].bitRateDl;
            }

            ueSliceMaximumBitRateList[numSliceMBR].value.bit_mask = 0;

            status = static_cast<int16_t>(VEIL_fillE1_SNSSAI(&ueSliceMaximumBitRateList[numSliceMBR].value.sNSSAI,
                &rCi.ueInfo.sliceMbrInfo.detSliceMbr[index].sNssai));
            VCCB_RETURN_ON_CALL_ERROR(&rCi, status, "VEIL_fillE1_SNSSAI ERROR\n");

            status = VEIL_FillE1_BitRate(
                &ueSliceMaximumBitRateList[numSliceMBR].value.uESliceMaximumBitRateDL, dlUeSliceMBR);
            VCCB_RETURN_ON_CALL_ERROR(&rCi, status,
                "VEIL_FillE1_BitRate ERROR(val:%llu) in VEIL_FillE1_UESliceMaximumBitRateList!\n", 1ULL * dlUeSliceMBR);

            numSliceMBR++;
        }

        if (0 < numSliceMBR)
        {
            // Connect UE Slice Maximum Bit Rate List
            VCCB_RETURN_ON_CALL_ERROR(&rCi,
                VCCB_ConnectLinkedList(ueSliceMaximumBitRateList, static_cast<int>(numSliceMBR)),
                "VCCB_ConnectLinkedList failed in VEIL_FillE1_UESliceMaximumBitRateList -> UE Slice Maximum Bit Rate "
                "List!\n");

            return GOOD;
        }
    }

    return status;
}

// 9_3_2_1 UP Transport Layer Information
/**
 * @brief fill E1 uP_TNL_Information
 * @attention function sets all bit_mask
 * @param [in]  tli                 : transportLayerInfo_type ptr
 * @param [out] uP_TNL_Information  : E1_UP_TNL_Information buffer
 * @return      GOOD                : success fill
 * @return      ERROR               : fill error
 */
int VEIL_fillE1_UP_TNL_Information(E1_UP_TNL_Information *uP_TNL_Information, transportLayerInfo_type *tli)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(uP_TNL_Information);
    VALID_E_POINT_CHECK_ERROR(tli);

    int status;

    uP_TNL_Information->choice = E1_gTPTunnel_chosen;
    uP_TNL_Information->u.gTPTunnel.bit_mask = 0;
    status = VEIL_fillE1_TransportLayerAddress(&uP_TNL_Information->u.gTPTunnel.transportLayerAddress, tli);
    if (ERROR == status)
    {
        VCCB_PRINT_ERROR("VEIL_fillE1_TransportLayerAddress ERROR in VEIL_fillE1_UP_TNL_Information!\n");

        return ERROR;
    }
    status = VEIL_fillE1_GTP_TEID(&uP_TNL_Information->u.gTPTunnel.gTP_TEID, tli->TEID);
    if (ERROR == status)
    {
        VCCB_PRINT_ERROR("VEIL_fillE1_GTP_TEID ERROR in VEIL_fillE1_UP_TNL_Information!\n");

        return ERROR;
    }

    return GOOD;
}

// 9.3.2.2 CP Transport Layer Information
// 9_3_2_3 GTP-TEID
/**
 * @brief fill GTP TEID
 * @attention no bit_mask
 * @param [in]  teid        : teid from callERABInfo DB
 * @param [out] ptGtpTei    : E1_GTP_TEID Buffer
 * @return      GOOD        : success fill
 * @return      ERROR       : fill error
 */
int VEIL_fillE1_GTP_TEID(E1_GTP_TEID *ptGtpTei, uint32_t teid)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptGtpTei);

    ptGtpTei->length = 4;  // OCTET STRING(4)
    ptGtpTei->value[0] = static_cast<unsigned char>((teid >> 24) & 0x000000FF);
    ptGtpTei->value[1] = (teid >> 16) & 0x000000FF;
    ptGtpTei->value[2] = (teid >> 8) & 0x000000FF;
    ptGtpTei->value[3] = (teid)&0x000000FF;

    return GOOD;
}

// 9_3_2_4 Transport Layer Address
/**
 * @brief fill E1 Transport Layer Address
 * @attention no bit_mask
 * @param [in]  ptTli   : transportLayerInfo DB
 * @param [out] tla     : E1_TransportLayerAddress buffer
 * @return      GOOD    : success fill
 * @return      ERROR   : fill error
 */
int VEIL_fillE1_TransportLayerAddress(E1_TransportLayerAddress *tla, const transportLayerInfo_type *ptTli)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(tla);
    VALID_E_POINT_CHECK_ERROR(ptTli);

    tla->length = static_cast<unsigned short>(UMIN(ptTli->numTLAbit, MAX_TLA_BYTE * 8));
    tla->value = (unsigned char *)(ptTli->TLAddr);

    return GOOD;
}

// 9_3_2_5 Data Forwarding Information Request
bool VEIL_check_E1_PDU_Data_Forwarding_Information_request(callInfo_type *ptCi, callPDUSessInfo_type *ptPi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptPi, false);

    switch (ptCi->state)
    {
        /* MN ue state */
        case STATE_INTER_Pre_UP_T:                 // send pdu data forwarding tunnel request at target gNB
            if (InterRatHO_cmd == ptCi->stateCmd)  // only inter rat
            {
                return true;
            }
            break;
        case STATE_INTER_SeqNum_S:  // send pdu data forwarding tunnel for Serving
            if (IS_MRDC_MN(ptCi))
            {
                /// If there is more than one MN Term bearer, forwarding information must be transmitted to the MN UP.
                if (FnVCCB_IsAnyMnTermPerPDU(ptCi, ptPi, request_bearerType))
                {
                    return true;
                }
            }
            else
            {
                return true;
            }
            break;

            /* SN ue state */

            /* MN ue state */

        case STATE_SN_INTER_SN_Exe:
            return true;

        /*Inter gNB RRE*/
        case STATE_RRE_S_XnUAddInd:
            return true;

        /*Inter gNB RRC Resume*/
        case STATE_Inact_S_XnUAddrInd:
            return true;

        default:
            break;
    }

    return false;
}

void VEIL_fillE1_PDU_Data_Forwarding_Information_request(E1_Data_Forwarding_Information_Request *ptDataFwdInfo,
    E1_QoS_Flow_Mapping_List_ *ptQosFlowToBeModBuffer, callInfo_type *ptCi, callPDUSessInfo_type *pPDUSessInfo,
    uint8_t *numQoSFlow)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptDataFwdInfo);
    VALID_E_POINT_CHECK_VOID(ptQosFlowToBeModBuffer);
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pPDUSessInfo);
    VALID_E_POINT_CHECK_VOID(numQoSFlow);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    qosFlowInfo_type *ptQi = NULL;
    unsigned int loop = 0, qosFlowIdx = 0;

    // Forward Parameter
    int dlFwdEnabled = FALSE, ulFwdEnabled = FALSE;
    uint8_t dl = FALSE, ul = FALSE;

    enumDataForwardingState_type dataFwdState = FnVCCB_GetDataForwardingState(ptCi);

    // Init
    *numQoSFlow = 0;
    ptDataFwdInfo->bit_mask = 0;

    for (loop = 0; loop < MAX_QOS_FLOW_PER_PDU_SESS; loop++)
    {
        qosFlowIdx = pPDUSessInfo->qosFlowIndex[loop];

        if (qosFlowIdx >= MAX_QOS_FLOW_PER_CALL)  // Not yet allocated
            continue;

        ptQi = &ptCi->qosFlow[qosFlowIdx];

        if (CI_use != ptQi->usage) continue;

        if (IS_MRDC_MN(ptCi))
        {
            if (FnVCCB_IsNeedControl_SN_UP_ForQos(ptCi, ptQi)) continue;
#ifdef IPC_TEST
            if (ptQi->drbIdxInCall < MAX_DRB_PER_SA_CALL)
            {
                VCCB_PRINT_CALL_DATA(ptCi, "[qoS-Flows-Forwarded-On-Fwd-Tunnels] Pdu#%u QosFlow#%u Drb#%u\n",
                    pPDUSessInfo->pduSessId, ptQi->flowId, ptCi->drb[ptQi->drbIdxInCall].dRBId);
            }
#endif
        }

        VLIB_checkQosFlowForwardedOnTunnels(ptCi, pPDUSessInfo, ptQi, &dl, &ul, dataFwdState);

        if ((TRUE == dl) || (TRUE == ul))
        {
            E1_QoS_Flow_Mapping_List ptQosFlowMappingData = NULL;

            ptQosFlowMappingData = &ptQosFlowToBeModBuffer[*numQoSFlow];
            ptQosFlowMappingData->value.bit_mask = 0;
            ptQosFlowMappingData->value.qoS_Flow_Identifier = ptQi->flowId;

            // TGT_RSP_BASED_QFI_DATA_FWD_21D
            VCCB_PRINT_CALL_DATA(
                ptCi, "[TGT_QFI]: qoS_Flows_Forwarded_On_Fwd_Tunnels QFI(%d) dl(%d) ul(%d) \n", ptQi->flowId, dl, ul);

            // 9.3.1.60 QoS Flow Mapping Indication (TBD)

            ++(*numQoSFlow);
        }
        else
        {
            if (ptQi->drbIdxInCall >= MAX_DRB_PER_SA_CALL) continue;

            callDRBInfo_type* ptDi = &ptCi->drb[ptQi->drbIdxInCall];

            if (CI_use != ptDi->usage) continue;

            // E1_uL_Data_Forwarding_present
            if (ptDi->dataFwdInfo.gtpTunnel.ul.fNeedModify == 1 || ptDi->dataFwdInfo.gtpTunnel.dl.fNeedModify == 1)
            {
                if (IS_MRDC_MN(ptCi))
                {
                    if (FnVCCB_IsNeedControl_SN_UP_ForQos(ptCi, ptQi)) continue;
#ifdef IPC_TEST
                    VCCB_PRINT_CALL_DATA(ptCi, "[qoS-Flows-Forwarded-On-Fwd-Tunnels] Pdu#%u QosFlow#%u Drb#%u\n",
                        pPDUSessInfo->pduSessId, ptQi->flowId, ptCi->drb[ptQi->drbIdxInCall].dRBId);
#endif
                }
                E1_QoS_Flow_Mapping_List ptQosFlowMappingData = NULL;

                ptQosFlowMappingData = &ptQosFlowToBeModBuffer[*numQoSFlow];
                ptQosFlowMappingData->value.bit_mask = 0;
                ptQosFlowMappingData->value.qoS_Flow_Identifier = ptQi->flowId;

                // TGT_RSP_BASED_QFI_DATA_FWD_21D
                VCCB_PRINT_CALL_DATA(
                    ptCi, "[TGT_QFI]: qoS_Flows_Forwarded_On_Fwd_Tunnels QFI(%d) dl(%d) ul(%d) \n", ptQi->flowId, dl, ul);

                ++(*numQoSFlow);
            }
        }


        if (TRUE == dl) dlFwdEnabled = TRUE;

        if (TRUE == ul) ulFwdEnabled = TRUE;
    }

    if (*numQoSFlow)
    {
        E1_Data_Forwarding_Request dataFwdReq = E1_dL;

        ptDataFwdInfo->bit_mask |= E1_qoS_Flows_Forwarded_On_Fwd_Tunnels_present;
        ptDataFwdInfo->qoS_Flows_Forwarded_On_Fwd_Tunnels = ptQosFlowToBeModBuffer;

        if (ERROR == VCCB_ConnectLinkedList(ptDataFwdInfo->qoS_Flows_Forwarded_On_Fwd_Tunnels, static_cast<int>(*numQoSFlow)))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "VCCB_ConnectLinkedList failed in %s-> QoS Flow QoS Parameters List!\n", __func__);
            // pack fail case
            *numQoSFlow = 0;
            return;
        }

        if (dlFwdEnabled && ulFwdEnabled)
        {
            dataFwdReq = E1_Data_Forwarding_Request_both;
        }
        else
        {
            if (dlFwdEnabled)
            {
                dataFwdReq = E1_dL;
            }
            if (ulFwdEnabled)
            {
                dataFwdReq = E1_uL;
            }
        }

        ptDataFwdInfo->data_Forwarding_Request = dataFwdReq;

        if (IS_LOG_TRAFFIC(ptCi))
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[TRAFFIC, FWD]: UL:%s, DL:%s, BOTH:%s, PDU Forwarding Information Request (PDU ID:%u)\n",
                ((dataFwdReq == E1_uL) ? "O" : "X"),
                ((dataFwdReq == E1_dL) ? "O" : "X"),
                ((dataFwdReq == E1_Data_Forwarding_Request_both) ? "O" : "X"),
                pPDUSessInfo->pduSessId);
        }
    }
}

// 9_3_2_6 Data Forwarding Information
bool VEIL_check_E1_PDU_Data_Forwarding_Information(callInfo_type *ptCi, callPDUSessInfo_type *ptPi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptPi, false);

    // PDU setup
    switch (ptCi->state)
    {
        case STATE_INTRA_DU_SnRelB:
        case STATE_INTER_DU_SnRelB:
            return true;

        /* MN ue state */
        case STATE_INTER_SeqNum_S:
        {
            if (ptCi->hoInfo.directFwdAvailable && HO_TYPE_INTER_SYSTEM == ptCi->hoInfo.hoType.system && ptCi->hoInfo.directDataFwdFromTarget)
            {
                return false;
            }  // else
            return true;
        }

        /* SN ue state */

        default:
            break;
    }

    return false;
}

/****************************************************************************
 * @brief           This function distinguishes between cases where it is necessary to acquire DataForwarding or SeqNum
 *when DRB is released.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       ptDi : call DRB information / callDRBInfo_type
 * @return          true: need DataFowarding or SeqNum, false: not Need
 ****************************************************************************/
bool VEIL_check_E1_DRB_Data_Forwarding_Information(callInfo_type *ptCi, callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    switch (ptCi->state)
    {
        // NR-DC MN or gNB ue
        case STATE_INTER_SeqNum_S:
            if (ptCi->hoInfo.hoType.system == HO_TYPE_INTRA_SYSTEM)
            {
                return true;
            }
            // No need to send pDCP-SN-Status-Request in case of IRAT HO
            return false;
        case STATE_RRE_S_XnUAddInd:
            return true;

        // NR-DC SN ue
        case STATE_SN_SNRelExec:
            return true;

        case STATE_SN_SNModExec:

            // There is no data forwarding case for MCG mobility
            // TBD (bearerType change with MCG mobility shall be include it)
            if (FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_McgMobility) == true)
            {
                return false;
            }

            return true;

        // Inter SN mobility Source SN
        case STATE_SN_INTER_SN_Exe:
            return true;

        /*Inter gNB RRC Resume*/
        case STATE_Inact_S_XnUAddrInd:
            return true;

        default:
            break;
    }

    if (IS_ON_E1_MRDC_CTRL_FLAG(ptDi, mcgMod_dataFwdInfo))
    {
        return true;
    }

    return false;
}

int16_t FnVCCB_FillE1_DataForwardingToNgRanQosFlowInformationList(callInfo_type *ptCi,
    callPDUSessInfo_type *pPDUSessInfo, E1_BearerContextModificationRequestBuffer::PduSessToBeModData &buffer)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pPDUSessInfo);

    unsigned int qosFlowIdx = 0;
    qosFlowInfo_type *ptQi = NULL;
    uint8_t numQoSFlow = 0, dl = FALSE, ul = FALSE;

    enumDataForwardingState_type dataFwdState = FnVCCB_GetDataForwardingState(ptCi);

    for (unsigned int loop = 0; loop < MAX_QOS_FLOW_PER_PDU_SESS; loop++)
    {
        qosFlowIdx = pPDUSessInfo->qosFlowIndex[loop];

        if (qosFlowIdx >= MAX_QOS_FLOW_PER_CALL)  // Not yet allocated
            continue;

        ptQi = &ptCi->qosFlow[qosFlowIdx];

        if (CI_use != ptQi->usage) continue;

        if (IS_MRDC_MN(ptCi))
        {
            if (FnVCCB_IsNeedControl_SN_UP_ForQos(ptCi, ptQi)) continue;
#ifdef IPC_TEST
            if (ptQi->drbIdxInCall < MAX_DRB_PER_SA_CALL)
            {
                VCCB_PRINT_CALL_DATA(ptCi, "[qoS-Flows-Forwarded-On-Fwd-Tunnels] Pdu#%u QosFlow#%u Drb#%u\n",
                    pPDUSessInfo->pduSessId, ptQi->flowId, ptCi->drb[ptQi->drbIdxInCall].dRBId);
            }
#endif
        }

        VLIB_checkQosFlowForwardedOnTunnels(ptCi, pPDUSessInfo, ptQi, &dl, &ul, dataFwdState);

        if ((TRUE == dl) || (TRUE == ul))
        {
            E1_DataForwardingtoNG_RANQoSFlowInformationList ptNG_RANQoSFlowInformationData = NULL;

            ptNG_RANQoSFlowInformationData = &buffer.dataForwardingtoNG_RANQoSFlowInformationList[numQoSFlow];
            ptNG_RANQoSFlowInformationData->value.bit_mask = 0;
            ptNG_RANQoSFlowInformationData->value.qoS_Flow_Identifier = ptQi->flowId;

            // TGT_RSP_BASED_QFI_DATA_FWD_21D
            VCCB_PRINT_CALL_DATA(
                ptCi, "[TGT_QFI]: qoS_Flows_Forwarded_On_Fwd_Tunnels QFI(%d) dl(%d) ul(%d) \n", ptQi->flowId, dl, ul);

            // 9.3.1.60 QoS Flow Mapping Indication (TBD)

            ++numQoSFlow;
        }
    }

    if(numQoSFlow)
    {
        int status = GOOD;
        status = VCCB_ConnectLinkedList(buffer.dataForwardingtoNG_RANQoSFlowInformationList, static_cast<int>(numQoSFlow));
        VCCB_RETURN_ON_CALL_ERROR(
            ptCi, status, "fnConnectLinkedList failed Data Forwarding to NG-RAN QoS Flow Information List!\n");
    }
    else
    {
        VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "Skip E1_DataForwardingtoNG_RANQoSFlowInformationList there are no items in the list!\n");
        return BREAK;
    }

    buffer.pDataForwardingtoNGRANQoSFlowInformationList = buffer.dataForwardingtoNG_RANQoSFlowInformationList;

    return GOOD;
}

int16_t FnVCCB_FillE1_DataForwardingToNgRanQosFlowInformationListDrb(callInfo_type *ptCi,
    callDRBInfo_type *pDrbInfo, E1_BearerContextModificationRequestBuffer::PduSessToBeModData::DrbToBeModData &buffer)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDrbInfo);

    unsigned int qosFlowIdx = 0;
    qosFlowInfo_type *ptQi = NULL;
    uint8_t numQoSFlow = 0, dl = FALSE, ul = FALSE;

    for (unsigned int loop = 0; loop < MAX_QOS_FLOW_PER_DRB; loop++)
    {
        qosFlowIdx = pDrbInfo->qosFlowIndex[loop];

        if (qosFlowIdx >= MAX_QOS_FLOW_PER_CALL)  // Not yet allocated
            continue;

        ptQi = &ptCi->qosFlow[qosFlowIdx];

        if (CI_use != ptQi->usage) continue;

        if (IS_MRDC_MN(ptCi))
        {
            if (FnVCCB_IsNeedControl_SN_UP_ForQos(ptCi, ptQi)) continue;
#ifdef IPC_TEST
            if (ptQi->drbIdxInCall < MAX_DRB_PER_SA_CALL)
            {
                VCCB_PRINT_CALL_DATA(ptCi, "[qoS-Flows-Forwarded-On-Fwd-Tunnels] QosFlow#%u Drb#%u\n",
                    ptQi->flowId, ptCi->drb[ptQi->drbIdxInCall].dRBId);
            }
#endif
        }

        // E1_uL_Data_Forwarding_present
        if (pDrbInfo->dataFwdInfo.gtpTunnel.ul.fNeedModify == 1 || pDrbInfo->dataFwdInfo.gtpTunnel.dl.fNeedModify == 1)
        {
            if (IS_MRDC_MN(ptCi))
            {
                if (FnVCCB_IsNeedControl_SN_UP_ForQos(ptCi, ptQi)) continue;
            }
            E1_DataForwardingtoNG_RANQoSFlowInformationList ptNG_RANQoSFlowInformationData = NULL;

            ptNG_RANQoSFlowInformationData = &buffer.dataForwardingtoNG_RANQoSFlowInformationList[numQoSFlow];
            ptNG_RANQoSFlowInformationData->value.bit_mask = 0;
            ptNG_RANQoSFlowInformationData->value.qoS_Flow_Identifier = ptQi->flowId;
            // TGT_RSP_BASED_QFI_DATA_FWD_21D
            VCCB_PRINT_CALL_DATA(
                ptCi, "[TGT_QFI]: qoS_Flows_Forwarded_On_Fwd_Tunnels QFI(%d) dl(%d) ul(%d) \n", ptQi->flowId, dl, ul);

            ++numQoSFlow;
        }
    }

    if(numQoSFlow)
    {
        int status = GOOD;
        status = VCCB_ConnectLinkedList(buffer.dataForwardingtoNG_RANQoSFlowInformationList, static_cast<int>(numQoSFlow));
        VCCB_RETURN_ON_CALL_ERROR(
            ptCi, status, "fnConnectLinkedList failed Data Forwarding to NG-RAN QoS Flow Information List!\n");
    }
    else
    {
        VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "Skip E1_DataForwardingtoNG_RANQoSFlowInformationList there are no items in the list!\n");
        return BREAK;
    }

    buffer.pDataForwardingtoNGRANQoSFlowInformationList = buffer.dataForwardingtoNG_RANQoSFlowInformationList;

    return GOOD;
}

int VEIL_fillE1_PDU_Data_Forwarding_Information(callInfo_type *ptCi,
    E1_PDU_Session_Resource_To_Modify_Item *pduSessToModifyItem, callPDUSessInfo_type *pPDUSessInfo,
    E1_BearerContextModificationRequestBuffer::PduSessToBeModData *ptPduSessToBeModBuffer)
{
    AUTO_TRACE_FUNC;

    int status = GOOD;

    VALID_E_POINT_CHECK_ERROR(pduSessToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptPduSessToBeModBuffer);
    VALID_E_POINT_CHECK_ERROR(pPDUSessInfo);
    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint8_t needDataForwardingCheckDL = FALSE;
    uint8_t needDataForwardingCheckUL = FALSE;

    // in 20A PDU forwarding enabled for inter-rat and tunnels have to be provided to source UP only
    if (IS_NRDC_SN(ptCi))
    {
        needDataForwardingCheckDL = TRUE;
        needDataForwardingCheckUL = TRUE;
    }
    else if (InterRatHO_cmd == ptCi->stateCmd && False == ptCi->hoInfo.isTarget)
    {
        needDataForwardingCheckDL = TRUE;
    }
    else if (IntraRatHO_cmd == ptCi->stateCmd)
    {
        for (int qosFlowIdxIdx = 0; MAX_QOS_FLOW_PER_PDU_SESS > qosFlowIdxIdx; ++qosFlowIdxIdx)
        {
            uint16_t qosFlowIdx = pPDUSessInfo->qosFlowIndex[qosFlowIdxIdx];
            if (qosFlowIdx >= MAX_QOS_FLOW_PER_CALL)
            {
                continue;
            }

            qosFlowInfo_type qosFlowInfo = ptCi->qosFlow[qosFlowIdx];

            if (CI_use != qosFlowInfo.usage)
            {
                continue;
            }

            if (qosFlowInfo.dataFwdInfo.dlForwardAccepted)
            {
                uint16_t drbIdx = qosFlowInfo.drbIdxInCall;

                if (drbIdx >= MAX_DRB_PER_SA_CALL)
                {
                    continue;
                }
                callDRBInfo_type drbInfo = ptCi->drb[drbIdx];

                if (drbInfo.dataFwdInfo.gtpTunnel.dl.fNeedModify)
                {
                    continue;
                }

                needDataForwardingCheckDL = TRUE;
                break;
            }
        }
    }

    pduSessToModifyItem->pDU_Session_Data_Forwarding_Information.bit_mask = 0;

    uint8_t pduSessDataFwdDl = (TRUE == needDataForwardingCheckDL) && (1 == pPDUSessInfo->nGuFwdTunnel.dl.fNeedModify);
    uint8_t pduSessDataFwdUl = (TRUE == needDataForwardingCheckUL) && (1 == pPDUSessInfo->nGuFwdTunnel.ul.fNeedModify);
    // PDU Session level DL data forwarding UP TNL Information
    if (pduSessDataFwdDl)
    {
        pduSessToModifyItem->pDU_Session_Data_Forwarding_Information.bit_mask |= E1_dL_Data_Forwarding_present;

        status = VEIL_fillE1_UP_TNL_Information(
            &pduSessToModifyItem->pDU_Session_Data_Forwarding_Information.dL_Data_Forwarding,
            &pPDUSessInfo->nGuFwdTunnel.dl);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_UP_TNL_Information ERROR!\n");
    }

    // PDU Session level UL data forwarding UP TNL Information
    if (pduSessDataFwdUl)
    {
        pduSessToModifyItem->pDU_Session_Data_Forwarding_Information.bit_mask |= E1_uL_Data_Forwarding_present;

        status = VEIL_fillE1_UP_TNL_Information(
            &pduSessToModifyItem->pDU_Session_Data_Forwarding_Information.uL_Data_Forwarding,
            &pPDUSessInfo->nGuFwdTunnel.ul);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_UP_TNL_Information ERROR!\n");
    }

    // Data Forwarding to NG-RAN QoS Flow Information List
    if ((pduSessDataFwdDl || pduSessDataFwdUl) && GOOD == FnVCCB_FillE1_DataForwardingToNgRanQosFlowInformationList(ptCi, pPDUSessInfo, *ptPduSessToBeModBuffer))
    {
        pduSessToModifyItem->pDU_Session_Data_Forwarding_Information.bit_mask |=
            E1_Data_Forwarding_Information_iE_Extensions_present;

        InsertE1_ExtensionContainerValue(&ptPduSessToBeModBuffer->dataForwardingtoNGRANQoSFlowInformationListExt,
            E1_id_DataForwardingtoNG_RANQoSFlowInformationList, E1_ignore,
            &ptPduSessToBeModBuffer->pDataForwardingtoNGRANQoSFlowInformationList,
            E1_DataForwardingtoNG_RANQoSFlowInformationList_PDU);

        struct E1_ProtocolExtensionContainer_ *&container =
            pduSessToModifyItem->pDU_Session_Data_Forwarding_Information.iE_Extensions;
        container = &ptPduSessToBeModBuffer->dataForwardingtoNGRANQoSFlowInformationListExt;
        container->next = nullptr;

        if (pduSessToModifyItem->pDU_Session_Data_Forwarding_Information.bit_mask != 0)
        {
            pduSessToModifyItem->bit_mask |= E1_pDU_Session_Data_Forwarding_Information_present;

            if (IS_LOG_TRAFFIC(ptCi))
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[TRAFFIC, FWD]: PDU Forwarding Information (PDU ID:%u, UL:%s, DL:%s)\n",
                    pPDUSessInfo->pduSessId,
                    ((pduSessDataFwdUl) ? "O" : "X"),
                    ((pduSessDataFwdDl) ? "O" : "X"));
            }
        }
    }

    return status;
}

int VEIL_fillE1_Data_Forwarding_Information(
    callInfo_type *ptCi, callDRBInfo_type *ptDi, E1_Data_Forwarding_Information *p, E1_BearerContextModificationRequestBuffer::PduSessToBeModData::DrbToBeModData *ptDrbToBeModBuffer)
{
    int status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);
    VALID_E_POINT_CHECK_ERROR(p);
    VALID_E_POINT_CHECK_ERROR(ptDrbToBeModBuffer);

    p->bit_mask = 0;

    // E1_uL_Data_Forwarding_present
    if (ptDi->dataFwdInfo.gtpTunnel.ul.fNeedModify == 1)
    {
        status = VEIL_fillE1_UP_TNL_Information(&p->uL_Data_Forwarding, &ptDi->dataFwdInfo.gtpTunnel.ul);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_UP_TNL_Information ERROR in %s!\n", __func__);

        p->bit_mask |= E1_uL_Data_Forwarding_present;
    }

    // E1_dL_Data_Forwarding_present
    if (ptDi->dataFwdInfo.gtpTunnel.dl.fNeedModify == 1)
    {
        status = VEIL_fillE1_UP_TNL_Information(&p->dL_Data_Forwarding, &ptDi->dataFwdInfo.gtpTunnel.dl);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_UP_TNL_Information ERROR in %s!\n", __func__);

        p->bit_mask |= E1_dL_Data_Forwarding_present;
    }

    if (IS_LOG_TRAFFIC(ptCi))
    {
        if ((p->bit_mask & E1_uL_Data_Forwarding_present) || (p->bit_mask & E1_dL_Data_Forwarding_present))
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[TRAFFIC, FWD]: UL:%s, DL:%s, DRB Forwarding Information (DRB ID:%u)\n",
                ((p->bit_mask & E1_uL_Data_Forwarding_present) ? "O" : "X"),
                ((p->bit_mask & E1_dL_Data_Forwarding_present) ? "O" : "X"),
                ptDi->dRBId);
        }
    }

    // Data Forwarding to NG-RAN QoS Flow Information List
    if (GOOD == FnVCCB_FillE1_DataForwardingToNgRanQosFlowInformationListDrb(ptCi, ptDi, *ptDrbToBeModBuffer))
    {
        InsertE1_ExtensionContainerValue(&ptDrbToBeModBuffer->dataForwardingtoNGRANQoSFlowInformationListExt,
            E1_id_DataForwardingtoNG_RANQoSFlowInformationList, E1_ignore,
            &ptDrbToBeModBuffer->pDataForwardingtoNGRANQoSFlowInformationList,
            E1_DataForwardingtoNG_RANQoSFlowInformationList_PDU);

        struct E1_ProtocolExtensionContainer_ *&container = p->iE_Extensions;
        container = &ptDrbToBeModBuffer->dataForwardingtoNGRANQoSFlowInformationListExt;
        container->next = nullptr;

        if (p->bit_mask != 0)
        {
            p->bit_mask |= E1_Data_Forwarding_Information_iE_Extensions_present;
        }
    }
    ptDi->dataFwdInfo.gtpTunnel.ul.fNeedModify = 0;
    ptDi->dataFwdInfo.gtpTunnel.dl.fNeedModify = 0;

    return status;
}

// 9.3.2.7 Transport Network Layer Address Info
// 9.3.2.8 URI

// earch PDU

// 59. E1_id_UEDLAggregateMaximumBitRate
template <typename T>
int16_t VEIL_FillE1_id_UEDLAggregateMaximumBitRate(
    /*In*/ callInfo_type *ptCi,
    /*In*/ uint16_t endPointIdx,
    /*In*/ const char *ptFuncName,
    /*In*/ uint8_t needMrDcModify,
    /*Out*/ struct E1_ProtocolIE_Container_ *ptIeContainers,
    /*In*/ uint8_t maxIeCount,
    /*Out*/ unsigned int *ptIeCnt,
    /*Out*/ T *ptUeCtxtBuffer)
{
    AUTO_TRACE_FUNC;
    (void)needMrDcModify;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptFuncName);
    VALID_E_POINT_CHECK_ERROR(ptIeContainers);
    VALID_E_POINT_CHECK_ERROR(ptIeCnt);
    VALID_E_POINT_CHECK_ERROR(ptUeCtxtBuffer);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);

    if (maxIeCount <= *ptIeCnt)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "It cannot contain more than the maximum number(%d) of Protocol IEs (cur:%d) in %s.", maxIeCount, *ptIeCnt,
            ptFuncName);
        return ERROR;
    }

    int16_t status = GOOD;

    uint64_t dlAmbr = MAX_EXTENDED_BITRATE;

    if (GNBINFO[ptCi->gnbNum].cfg.nrAmbrOnOff == FLAG_OFF)
    {
        dlAmbr = MAX_EXTENDED_BITRATE;
    }
    else if (DOES_NEED_MRDC_UEAMBR_DISTRIBUTION(ptCi))
    {
        FnVCCB_ReproduceUeAMBRforMRDC(ptCi);
        dlAmbr = ptCi->mrdcInfo.ueAmbrDlMN;
        VCCB_PRINT_CALL_DATA(ptCi, ">>> MRDC_UEAMBR_DISTRIBUTION : dlAmbr(%llu)\n", 1ULL * dlAmbr);
    }
    else
    {
        status = VCCM_GetUeAmbrValue(ptCi, NULL, &dlAmbr);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_GetUeAmbrValue ERROR! in %s\n", ptFuncName);
        VCCM_RecalculateUeAmbrValueForMultiUp(ptCi, endPointIdx, &dlAmbr);  // multi UP scenario
    }

    uint8_t plmnIdx = MAX_PLMN_INDEX;
    VLIB_GetCellPlmnIdx(ptCi->ueInfo.servedPlmn.longId, ptCi->servCellNum, &plmnIdx);

    if (!IS_VALID_PLMNNUM(plmnIdx))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "VLIB_GetCellPlmnIdx is invalid range ERROR !! in %s, so plmnIdx 0 is applied\n", __FUNCTION__);
        plmnIdx = 0;
    }

    // Fill F1_BitRate Value.
    status = VEIL_FillE1_BitRate(&ptUeCtxtBuffer->ueDlAggregateMaximumDataRate, dlAmbr);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_FillE1_BitRate ERROR(val:%llu)! in %s\n", 1ULL * dlAmbr, ptFuncName);
    SET_NEED_TO_MODIFY_DL_UEAMBR(ptCi, VCCB_FLAG_OFF);

    // Add IE Container
    InsertE1_ContainerValue(&ptIeContainers[*ptIeCnt], E1_id_UEDLAggregateMaximumBitRate, E1_reject,
        &ptUeCtxtBuffer->ueDlAggregateMaximumDataRate, E1_BitRate_PDU);

    (*ptIeCnt)++;

    return GOOD;
}

template <typename T>
int16_t VEIL_FillE1_id_UEDLMaximumIntegrityProtectedDataRate(
    /*In*/ callInfo_type *ptCi,
    /*In*/ const char *ptFuncName,
    /*In*/ E1_BitRate bitRateValue,
    /*Out*/ struct E1_ProtocolIE_Container_ *ptIeContainers,
    /*In*/ uint8_t maxIeCount,
    /*Out*/ unsigned int *ptIeCnt,
    /*Out*/ T *ptUeCtxtBuffer)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptFuncName);
    VALID_E_POINT_CHECK_ERROR(ptIeContainers);
    VALID_E_POINT_CHECK_ERROR(ptIeCnt);
    VALID_E_POINT_CHECK_ERROR(ptUeCtxtBuffer);

    if (maxIeCount <= *ptIeCnt)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "It cannot contain more than the maximum number(%d) of Protocol IEs (cur:%d) in %s.", maxIeCount, *ptIeCnt,
            ptFuncName);
        return ERROR;
    }

    int16_t status = GOOD;

    // Fill F1_BitRate Value.
    status = VEIL_FillE1_BitRate(&ptUeCtxtBuffer->ueDlMaximumIntegrityProtectedDataRate, static_cast<uint64_t >(bitRateValue));
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, status, "VEIL_FillE1_BitRate ERROR(val:%llu)! in %s\n", 1ULL * static_cast<unsigned long long>(bitRateValue), ptFuncName);

    // Add IE Container

    InsertE1_ContainerValue(&ptIeContainers[*ptIeCnt], E1_id_UEDLMaximumIntegrityProtectedDataRate, E1_reject,
        &ptUeCtxtBuffer->ueDlMaximumIntegrityProtectedDataRate, E1_BitRate_PDU);

    (*ptIeCnt)++;
    return GOOD;
}

enum class enBearerCtxtMod_DrbToMod_status
{
    F1Setup,
    ScgFailure_UlPathSwitch,
    Mr_UlPathSwitch,
    E1_UlPathSwitch,
    DrbsModificationToRelease,
    HandoverResume,
    ERABReleaseTxStop,
    InterDUHandover,
    IntraDUHandover,
    SgNBAdditionAfterX2SNStatusTransfer,
    DlInfoNeedModifyAfterF1UECtxtSetupResp,
    ChangeTypeSplitToScg,
    ChangeTypeScgToSplit,
    ChangeTypeSplitToMcg,
    ChangeTypeMcgToSplit,
    ChangeTypeSplitToMcgConfirmed,
    E1ModificationResume,
    DesiredActivityNotification,
    FullConfigIndication,
    S1UTunnelUpdate,
    EndcHandoverRollback,
    TrafficMonitoring,
    QosMod,
    Unknown,
};

bool VEIL_getDrbToModItem_DrbsModificationToReleaseCondition(const callInfo_type *ptCi, const callERABInfo_type &erab)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    bool isErabInValidState = (erab.erabStatus != ERAB_Setup) && 
      (erab.erabStatus != ERAB_FailToSetup) &&
      (erab.erabStatus != ERAB_FailToModify) && 
      (erab.prevErabStatus != ERAB_FailToSetup);
      
    bool isReleaseAllowedState = (ptCi->state == STATE_DCSNRelRqrd) || 
                          (ptCi->state == STATE_DCSnChg_Prep) ||
                          (ptCi->state == STATE_DB2DBRF1Mod) || 
                          (ptCi->state == STATE_DCSnChg_F1TxStop);
                          
    bool isSgNbReleaseCondition = (ptCi->stateCmd == SgNBReleaseRequest_cmd) && 
                              !ptCi->bitFlag.isE1TxStopRequested;

    bool isDb2dbrEnbCondition = (ptCi->state == STATE_DB2DBRenb) && 
                            (erab.snStatus.needRequestFlag == FLAG_ON);
                             
    return (isErabInValidState && (isReleaseAllowedState || isSgNbReleaseCondition || isDb2dbrEnbCondition));
}

enBearerCtxtMod_DrbToMod_status VEIL_getDrbToModItem_Status(const callInfo_type *ptCi, const callERABInfo_type &erab)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, enBearerCtxtMod_DrbToMod_status::Unknown);
    if ((STATE_DCF1Setup_S == ptCi->state) && (ERAB_Setup == erab.prevErabStatus) && (ERAB_Modify == erab.erabStatus))
    {
        return enBearerCtxtMod_DrbToMod_status::F1Setup;
    }
    else if (ScgFailure_cmd == ptCi->stateCmd)
    {
        return enBearerCtxtMod_DrbToMod_status::ScgFailure_UlPathSwitch;
    }
    else if (MrUlPathSwitch_cmd == ptCi->stateCmd)
    {
        return enBearerCtxtMod_DrbToMod_status::Mr_UlPathSwitch;
    }
    else if (E1UlPathSwitch_cmd == ptCi->stateCmd)
    {
        return enBearerCtxtMod_DrbToMod_status::E1_UlPathSwitch;
    }
    else if (VEIL_getDrbToModItem_DrbsModificationToReleaseCondition(ptCi, erab))
    {
        return enBearerCtxtMod_DrbToMod_status::DrbsModificationToRelease;
    }
    else if ((STATE_DB == ptCi->state) && (IntraRatHO_cmd == ptCi->stateCmd) && (ERAB_Setup != erab.erabStatus) &&
             (HO_TYPE_INTER_DU != ptCi->hoInfo.hoType.du))
    {
        return enBearerCtxtMod_DrbToMod_status::IntraDUHandover;
    }
    else if (CHECK_MOD_EVENT_WITH_STATECMD(ptCi, erabModify) && (ERAB_Release == erab.erabStatus) &&
             (STATE_DCF1Mod_S != ptCi->state))
    {
        return enBearerCtxtMod_DrbToMod_status::ERABReleaseTxStop;
    }
    else if ((STATE_DCIntraDuHo_F1UeCtxMod == ptCi->state) || (STATE_DCInterDuHo_E1DrbModPrep == ptCi->state))
    {
        return enBearerCtxtMod_DrbToMod_status::FullConfigIndication;
    }
    else if ((STATE_DCIntraDuHo_RRCRecCmpl == ptCi->state) || (STATE_DCIntraDuHo_X2RecCmpl == ptCi->state) ||
             (STATE_DCIntraDuHo_X2SnStatus == ptCi->state) || (STATE_DCIntraDuHo_X2ModCnf == ptCi->state) ||
             (STATE_DCInterDuHo_RRCRecCmpl == ptCi->state) || (STATE_DCInterDuHo_X2RecCmpl == ptCi->state) ||
             (STATE_DCInterDuHo_X2SnStatus == ptCi->state) || (STATE_DCInterDuHo_X2ModCnf == ptCi->state) ||
             (STATE_DCNonDuHo_X2SnStatus == ptCi->state) || (STATE_DCNonDuHo_X2RecCmpl == ptCi->state))
    {
        return enBearerCtxtMod_DrbToMod_status::HandoverResume;
    }
    else if (STATE_DCInterDuHo_F1UeCtxSetReq == ptCi->state)
    {
        return enBearerCtxtMod_DrbToMod_status::InterDUHandover;
    }
    else if (FLAG_ON == erab.snStatus.needSendFlag)
    {
        return enBearerCtxtMod_DrbToMod_status::SgNBAdditionAfterX2SNStatusTransfer;
    }
    else if ((STATE_DCF1Mod_S == ptCi->state) &&
             ((FLAG_ON == erab.f1uDlInfo.fNeedModify) || (FLAG_ON == erab.x2uDlInfo.fNeedModify)))
    {
        return enBearerCtxtMod_DrbToMod_status::DlInfoNeedModifyAfterF1UECtxtSetupResp;
    }
    else if (((ERAB_Modify == erab.erabStatus) && (ERAB_Setup != erab.prevErabStatus)) &&
             ((STATE_DCMod_CompltInd == ptCi->state) || (STATE_DCUeMod_S == ptCi->state)))
    {
        return enBearerCtxtMod_DrbToMod_status::E1ModificationResume;
    }
    else if ((ERAB_Modify == erab.erabStatus) && (SCG_Bearer == erab.preveBearerType) &&
             (SPLIT_Bearer == erab.bearerType))
    {
        return enBearerCtxtMod_DrbToMod_status::ChangeTypeScgToSplit;
    }
    else if ((ERAB_Modify == erab.erabStatus) && (SPLIT_Bearer == erab.preveBearerType) &&
             (SCG_Bearer == erab.bearerType))
    {
        return enBearerCtxtMod_DrbToMod_status::ChangeTypeSplitToScg;
    }
    else if ((ERAB_Modify == erab.erabStatus) && (MCG_Bearer == erab.preveBearerType) &&
             (SPLIT_Bearer == erab.bearerType))
    {
        return enBearerCtxtMod_DrbToMod_status::ChangeTypeMcgToSplit;
    }
    else if ((ERAB_Modify == erab.erabStatus) && (SPLIT_Bearer == erab.preveBearerType) &&
             (MCG_Bearer == erab.bearerType))
    {
        if (ptCi->bitFlag.isSnInitBearerChangeToMcgConfirmed)
        {
            return enBearerCtxtMod_DrbToMod_status::ChangeTypeSplitToMcgConfirmed;
        }
        else
        {
            return enBearerCtxtMod_DrbToMod_status::ChangeTypeSplitToMcg;
        }
    }
    else if ((ERAB_Setup != erab.erabStatus) && (ptCi->CallUserInactivity.desiredNotiLevelChanged == TRUE) &&
             (ptCi->CallUserInactivity.desiredActivityNotificationLevel == desiredActivityNotifLvl_ERAB))
    {
        return enBearerCtxtMod_DrbToMod_status::DesiredActivityNotification;
    }
    else if ((STATE_DB == ptCi->state) && (FLAG_ON == erab.s1uUlInfo.fNeedModify) && (ERAB_Modify == erab.erabStatus))
    {
        return enBearerCtxtMod_DrbToMod_status::S1UTunnelUpdate;
    }
    else if ((IntraRatHO_cmd == ptCi->stateCmd) && (TRUE == ptCi->hoInfo.endcHoRollbackActive) &&
             (STATE_DCInterDuHo_F1SrcDuRecov == ptCi->state))
    {
        return enBearerCtxtMod_DrbToMod_status::EndcHandoverRollback;
    }
    else if ((erab.erabIdx < MAX_ERAB_PER_CALL) &&
             (FALSE == ptCi->trafficMonitoringCfg.trafficReportDrbList[erab.erabIdx].isSameCfgFlag))
    {
        return enBearerCtxtMod_DrbToMod_status::TrafficMonitoring;
    }
    else if (VCCB_FLAG_ON == erab.qosModFlag)
    {
        return enBearerCtxtMod_DrbToMod_status::QosMod;
    }
    else
    {
        return enBearerCtxtMod_DrbToMod_status::Unknown;
    }
}

// temp code for 21D
// bearerSetup will be handled at next state. this function could be removed from next PKG. Plz contact to HQ HO team to
// add the code
bool FnVCCB_IsBearerControlOnCurrentBearerType(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    switch(ptCi->state)
    {
        case STATE_INTRA_DU_E1Stop:
        case STATE_INTER_DU_E1Stop:
        case STATE_INTER_DU_Cancel:
        case STATE_INTRA_DU_Cancel:
            return true;

        default:
            return false;
    }
}

/**
 * @brief fill E1 NR Cell Identity buffer
 * @attention no bit_mask
 * @param [in] ci        : cell identity
 * @param [out] ciBuffer : cell identity buffer
 * @return GOOD  : successful fill
 * @return ERROR : failed fill
 */
int VEIL_fillE1_NR_CellIdentityBuffer(const uint64_t ci, uint8_t *ciBuffer)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ciBuffer);

    constexpr uint64_t WHOLE_BYTE_MASK = 0xFF;
    constexpr uint64_t SIGNIFICANT_HALF_BYTE_MASK = 0xF0;

    ciBuffer[0] = (ci >> 28) & WHOLE_BYTE_MASK;
    ciBuffer[1] = (ci >> 20) & WHOLE_BYTE_MASK;
    ciBuffer[2] = (ci >> 12) & WHOLE_BYTE_MASK;
    ciBuffer[3] = (ci >> 4) & WHOLE_BYTE_MASK;
    ciBuffer[4] = (ci << 4) & SIGNIFICANT_HALF_BYTE_MASK;

    return GOOD;
}

/**
 * @brief fill E1 NR Cell Identity
 * @attention   no bit_mask
 * @param [out] nrci    : NR Cell identity
 * @param [in] ciBuffer : cell identity buffere
 * @param [in] ci       : cell identity
 * @return GOOD  : successful fill
 * @return ERROR : failed fill
 */
int VEIL_fillE1_NR_CellIdentity(E1_NR_Cell_Identity &nrci, uint8_t *ciBuffer, const uint64_t ci)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ciBuffer);

    int status = VEIL_fillE1_NR_CellIdentityBuffer(ci, ciBuffer);
    if (ERROR == status)
    {
        VCCB_PRINT_ERROR("VEIL_fillE1_NR_CellIdentityBuffer ERROR!\n");

        return ERROR;
    }

    constexpr uint8_t CGI_CI_BITS_WIDTH = 36;
    nrci.length = CGI_CI_BITS_WIDTH;
    nrci.value = ciBuffer;

    return GOOD;
}

/**
 * @brief fill E1 PLMN Identity
 * @attention no bit_mask
 * @param [in]  plmn    : plmn from callInfo DB
 * @param [out] p       : ASN PLMN Identity
 * @return      GOOD    : success fill
 * @return       ERROR   : fill error
 */
int VEIL_fillE1_PLMN_Identity(E1_PLMN_Identity *p, plmnId_type plmn)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(p);

    E1_MakePLMN_Identity(&plmn, p);

    return GOOD;
}

/**
 * @brief fill E1 plmn and cell identities
 * @attention function sets all bit_mask
 * @param [in] ciBuffer : cell identity buffer
 * @param [in] cgi      : cell identity and plmn
 * @param [out] nrcgi   : NGNB CGI
 * @return GOOD  : successful fill
 * @return ERROR : failed fill
 */
int VEIL_fillE1_NRCGI(E1_NR_CGI &nrcgi, uint8_t *ciBuffer, const cgi_type &cgi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ciBuffer);

    nrcgi.bit_mask = 0;
    nrcgi.iE_Extensions = nullptr;

    int status = VEIL_fillE1_PLMN_Identity(&nrcgi.pLMN_Identity, cgi.plmn);
    if (ERROR == status)
    {
        VCCB_PRINT_ERROR("VEIL_fillE1_PLMN_Identity ERROR!\n");

        return ERROR;
    }

    status = VEIL_fillE1_NR_CellIdentity(nrcgi.nR_Cell_Identity, ciBuffer, cgi.ci);
    if (ERROR == status)
    {
        VCCB_PRINT_ERROR("VEIL_fillE1_NR_CellIdentity ERROR!\n");

        return ERROR;
    }

    return GOOD;
}

/**
 * @brief fill E1_SamsungCslStitchingInfoWithBuffer
 * @attention function sets all bit_mask
 * @param [in]  ptCi                              : callInfo DB
 * @param [out] samsungCslStitchingInfoWithBuffer : securityInformation buffer
 * @return GOOD  : successful fill
 * @return ERROR : failed fill
 */
int VEIL_fillE1_SamsungCslStitchingInfo(
    callInfo_type *ptCi, E1_SamsungCslStitchingInfoWithCIBuffer &samsungCslStitchingInfoWithCIBuffer)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    samsungCslStitchingInfoWithCIBuffer.samsungCslStitchingInfo.bit_mask = 0;

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    uint16_t cellNum = ptCi->servCellNum;

    // Intra-Gnb cell change
    if ((ptCi->stateCmd == IntraRatHO_cmd &&
               ((STATE_DCIntraDuHo_RRCRecCmpl == ptCi->state) || (STATE_DCIntraDuHo_X2RecCmpl == ptCi->state) || // NSA
                (STATE_DCIntraDuHo_X2SnStatus == ptCi->state) || (STATE_DCIntraDuHo_X2ModCnf == ptCi->state) ||
                (STATE_DCInterDuHo_RRCRecCmpl == ptCi->state) || (STATE_DCInterDuHo_X2RecCmpl == ptCi->state) ||
                (STATE_DCInterDuHo_X2SnStatus == ptCi->state) || (STATE_DCInterDuHo_X2ModCnf == ptCi->state) ||
                (STATE_DCNonDuHo_X2SnStatus == ptCi->state) || (STATE_DCNonDuHo_X2RecCmpl == ptCi->state) ||
                (STATE_INTRA_DU_Complete == ptCi->state) || (STATE_INTER_DU_Complete == ptCi->state) || // SA
                (STATE_SN_INTRA_DU_Complete == ptCi->state) || (STATE_SN_INTER_DU_Complete == ptCi->state))) || // NRDC
        (ptCi->stateCmd == IntraCellHO_cmd && ptCi->state == STATE_Intra_Cell_Complete))
    {
        const uint16_t f1Idx = ptCi->hoInfo.targetDu.f1Idx;
        VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->hoInfo.targetCellNum, MAX_CELL_NUM_VCCB);
        
        cellNum = ptCi->hoInfo.targetCellNum;
        samsungCslStitchingInfoWithCIBuffer.samsungCslStitchingInfo.cRnti = ptCi->hoInfo.targetcRNTI;
        samsungCslStitchingInfoWithCIBuffer.samsungCslStitchingInfo.gnbDuId = FnVCCB_GetDuId(ptCi->gnbNum, f1Idx);
    }
    else
    {
        samsungCslStitchingInfoWithCIBuffer.samsungCslStitchingInfo.cRnti = ptCi->ueInfo.ueId.cRNTI;
        samsungCslStitchingInfoWithCIBuffer.samsungCslStitchingInfo.gnbDuId = ptCi->endPointInfo.gnbDuId;
    }

    int status = VEIL_fillE1_NRCGI(samsungCslStitchingInfoWithCIBuffer.samsungCslStitchingInfo.cgi,
        samsungCslStitchingInfoWithCIBuffer.spCellCiBuffer, FnVCCB_GetNrcgiFromCellNum(cellNum));
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_NRCGI ERROR!\n");

    return GOOD;
}

/**
 * @brief fill SecurityInformation
 * @attention function sets all bit_mask
 * @param [in]  ptCi            : callInfo DB
 * @param [out] ptSecurityInfo  : securityInformation buffer
 * @return      GOOD            : success fill
 * @return      ERROR           : fill error
 */
int VEIL_fillE1_SecurityInformation(callInfo_type *ptCi, E1_SecurityInformation *ptSecurityInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptSecurityInfo);

    securityInformation_type *pSecurityInfo = NULL;

    if ((ptCi->stateCmd == IntraCellHO_cmd) && (ptCi->ueInfo.securityModFlag == VCCB_FLAG_ON) &&
        (VCCB_FLAG_OFF == ptCi->ueInfo.snKeyChangeWOMnKeyChange))
    {
        pSecurityInfo = &ptCi->security.newPdcpCtx.securityInfo;
    }
    else
    {
        pSecurityInfo = &ptCi->security.pdcpCtx.securityInfo;
    }

    ptSecurityInfo->bit_mask = 0;

    // Security Algorithm -> Ciphering Algorithm fill - mandatory
    ptSecurityInfo->securityAlgorithm.bit_mask = 0;
    ptSecurityInfo->securityAlgorithm.cipheringAlgorithm =
        static_cast<E1_CipheringAlgorithm>(pSecurityInfo->cipherAlgo);

    ptSecurityInfo->uPSecuritykey.bit_mask = 0;
    ptSecurityInfo->uPSecuritykey.encryptionKey.length = KEY_INT_CIP_LENGTH;
    ptSecurityInfo->uPSecuritykey.encryptionKey.value = pSecurityInfo->keyUpEnc;

    /* Security Algorithm -> Integrity Algorithm fill - optional*/
    ptSecurityInfo->securityAlgorithm.bit_mask = E1_integrityProtectionAlgorithm_present;
    ptSecurityInfo->securityAlgorithm.integrityProtectionAlgorithm =
        static_cast<E1_IntegrityProtectionAlgorithm>(pSecurityInfo->integrityAlgo);

    /* User Plane Security Keys -> Encryption Key fill - mandatory, Integrity Key fill - optional*/
    ptSecurityInfo->uPSecuritykey.bit_mask = E1_integrityProtectionKey_present;
    ptSecurityInfo->uPSecuritykey.integrityProtectionKey.length = KEY_INT_CIP_LENGTH;
    ptSecurityInfo->uPSecuritykey.integrityProtectionKey.value = pSecurityInfo->keyUpInt;

    return GOOD;
}

int VEIL_FillE1_QosChar_NonDynamic5QI(nonDynamic5QIDesc_type *ptDB, E1_Non_Dynamic5QIDescriptor *ptMsg)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptDB);
    VALID_E_POINT_CHECK_ERROR(ptMsg);

    ptMsg->bit_mask = 0;

    ptMsg->fiveQI = (long)ptDB->fiveQi;

    if (ptDB->priorityLevelQosPresent == OPT_PRESENT)
    {
        ptMsg->bit_mask |= E1_qoSPriorityLevel_present;
        ptMsg->qoSPriorityLevel = (long)ptDB->priorityLevelQos;
    }

    if (ptDB->averagingWindowPresent == OPT_PRESENT)
    {
        ptMsg->bit_mask |= E1_Non_Dynamic5QIDescriptor_averagingWindow_present;
        ptMsg->averagingWindow = (long)ptDB->averagingWindow;
    }

    if (ptDB->maximumDataBurstVolumePresent == OPT_PRESENT)
    {
        ptMsg->bit_mask |= E1_Non_Dynamic5QIDescriptor_maxDataBurstVolume_present;
        ptMsg->maxDataBurstVolume = (long)ptDB->maximumDataBurstVolume;
    }

    return GOOD;
}

void* FnVCCB_Fill_E1ECNMarkingOrCongestionInformation_Buffer(callInfo_type *ptCi, qosFlowInfo_type *ptQoSFlowInfo,
    enumE1F1procedure_type procedure, uint8_t pduIdxInCall, unsigned int numQoSFlow)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptCi);
    VALID_E_POINT_CHECK_NULL(ptQoSFlowInfo);
    VCCB_CHECK_E_RANGE_AND_NULL(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_NULL(pduIdxInCall, MAX_PDU_SESS_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_NULL(ptQoSFlowInfo->drbIdxInCall, MAX_DRB_PER_PDU_SESS);
    VCCB_CHECK_E_RANGE_AND_NULL(numQoSFlow, MAX_QOS_FLOW_PER_PDU_SESS);

    E1_ECNMarkingorCongestionInformationReportingRequest *ecnMarkingContainer = NULL;
    auto &e1SetupBuf = THREAD_INFO->call[ptCi->myThreadId].buf.tx.e1ap.bearerContextSetupRequest;
    auto &e1ModifyBuf = THREAD_INFO->call[ptCi->myThreadId].buf.tx.e1ap.bearerContextModificationRequest;

    switch (procedure)
    {
        case E1F1Setup: {            
            ecnMarkingContainer = &e1SetupBuf.pduSessToSetupData[pduIdxInCall].drbToSetupData[ptQoSFlowInfo->drbIdxInCall].ecnMarkingOrCongestion[numQoSFlow];
            break;
        }
        case E1F1Modify_SetupMod: {
            ecnMarkingContainer = &e1ModifyBuf.pduSessToSetupModData[pduIdxInCall].drbToSetupModData[ptQoSFlowInfo->drbIdxInCall].ecnMarkingOrCongestion[numQoSFlow];
            break;
        }
        case E1F1Modify_Modify: {
            ecnMarkingContainer = &e1ModifyBuf.pduSessToModData[pduIdxInCall].drbToModData[ptQoSFlowInfo->drbIdxInCall].ecnMarkingOrCongestion[numQoSFlow];
            break;
        }
        case E1F1Modify_Setup: {
            ecnMarkingContainer = &e1ModifyBuf.pduSessToModData[pduIdxInCall].drbToSetupData[ptQoSFlowInfo->drbIdxInCall].ecnMarkingOrCongestion[numQoSFlow];
            break;
        }
        default: {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_Get_E1ECNMarkingOrCongestionInformation_Value_Buffer unknown procedure(%i)\n", procedure);  
            return ecnMarkingContainer;
        }
    }

    memset(ecnMarkingContainer, 0, sizeof(E1_ECNMarkingorCongestionInformationReportingRequest));

    switch (ptQoSFlowInfo->qosFlowInfoExtension.ecn.ecnMarkingChoice)
    {
        case ECN_CHOICE_RAN:
        {
            ecnMarkingContainer->choice = E1_eCNMarkingatNGRAN_chosen;
            ecnMarkingContainer->u.eCNMarkingatNGRAN =
                static_cast<E1__enum1_8>(ptQoSFlowInfo->qosFlowInfoExtension.ecn.ecnMarking);
            break;
        }
        case ECN_CHOICE_UPF:
        {
            ecnMarkingContainer->choice = E1_eCNMarkingatUPF_chosen;
            ecnMarkingContainer->u.eCNMarkingatUPF =
                static_cast<E1__enum1_8>(ptQoSFlowInfo->qosFlowInfoExtension.ecn.ecnMarking);
            break;
        }
        case ECN_CHOICE_CONGESTION_INFORMATION:
        {
            ecnMarkingContainer->choice = E1_congestionInformation_chosen;
            ecnMarkingContainer->u.congestionInformation =
                static_cast<E1__enum1_8>(ptQoSFlowInfo->qosFlowInfoExtension.ecn.ecnMarking);
            break;
        }
        default:
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "FnVCCB_Get_E1ECNMarkingOrCongestionInformation_Value_Buffer unknown choice(%i)\n",
                ptQoSFlowInfo->qosFlowInfoExtension.ecn.ecnMarkingChoice);
            return NULL;
        }
    }

    return ecnMarkingContainer;
}

E1_ProtocolExtensionContainer_* FnVCCB_Get_E1ECNMarkingOrCongestionInformation_ExtContainer_Buffer(callInfo_type* ptCi, enumE1F1procedure_type procedure, uint8_t pduIdxInCall, uint16_t drbIdxInCall, unsigned int numQoSFlow)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptCi);
    VCCB_CHECK_E_RANGE_AND_NULL(pduIdxInCall, MAX_PDU_SESS_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_NULL(drbIdxInCall, MAX_DRB_PER_PDU_SESS);
    VCCB_CHECK_E_RANGE_AND_NULL(numQoSFlow, MAX_QOS_FLOW_PER_PDU_SESS);

    struct E1_ProtocolExtensionContainer_* pContainer = NULL;
    auto& e1SetupBuf = THREAD_INFO->call[ptCi->myThreadId].buf.tx.e1ap.bearerContextSetupRequest;
    auto& e1ModifyBuf = THREAD_INFO->call[ptCi->myThreadId].buf.tx.e1ap.bearerContextModificationRequest;

    switch(procedure)
    {
        case E1F1Setup: {
            pContainer = &e1SetupBuf.pduSessToSetupData[pduIdxInCall].drbToSetupData[drbIdxInCall].ecnMarkingOrCongestionBuf[numQoSFlow];
            break;
        }
        case E1F1Modify_SetupMod: {
            pContainer = &e1ModifyBuf.pduSessToSetupModData[pduIdxInCall].drbToSetupModData[drbIdxInCall].ecnMarkingOrCongestionBuf[numQoSFlow];
            break;
        }
        case E1F1Modify_Modify: {
            pContainer = &e1ModifyBuf.pduSessToModData[pduIdxInCall].drbToModData[drbIdxInCall].ecnMarkingOrCongestionBuf[numQoSFlow];
            break;
        }
        case E1F1Modify_Setup: {
            pContainer = &e1ModifyBuf.pduSessToModData[pduIdxInCall].drbToSetupData[drbIdxInCall].ecnMarkingOrCongestionBuf[numQoSFlow];
            break;
        }
        default: {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_Get_E1ECNMarkingOrCongestionInformation_ExtContainer_Buffer unknown procedure(%i)\n", procedure);  
        }
    }
    return pContainer;
}

/**
 * @brief fill E1 QoS Flow QoS Info Extension IEs
 * @attention function sets External IEs bit_mask
 * @param [in]  ptQoSFlowInfo       : qosFlowInfo_type DB
 * @param [out] ptQoSFlowParamItem  : E1_QoS_Flow_QoS_Parameter_Item buffer
 * @return      GOOD                : Success
 * @return      ERROR               : ERROR encountered.
 */
int FnVCCB_Fill_E1QoSFlowInfoExtension_ExtContainer(
    callInfo_type* ptCi, E1_QoS_Flow_QoS_Parameter_Item *ptQoSFlowParamItem, qosFlowInfo_type *ptQoSFlowInfo, enumE1F1procedure_type procedure, uint8_t pduIdxInCall, unsigned int numQoSFlow)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptQoSFlowParamItem);
    VALID_E_POINT_CHECK_ERROR(ptQoSFlowInfo);

    // O - ECN Marking Or Congestion Information Request
    if (ECN_MARKING_VALID == ptQoSFlowInfo->qosFlowInfoExtension.ecn.ecnMarkingState)
    {
        void *ecnMarkingContainer = FnVCCB_Fill_E1ECNMarkingOrCongestionInformation_Buffer(
            ptCi, ptQoSFlowInfo, procedure, pduIdxInCall, numQoSFlow);
        struct E1_ProtocolExtensionContainer_ *pContainer =
            FnVCCB_Get_E1ECNMarkingOrCongestionInformation_ExtContainer_Buffer(
                ptCi, procedure, pduIdxInCall, ptQoSFlowInfo->drbIdxInCall, numQoSFlow);
        if (NULL != ecnMarkingContainer && NULL != pContainer)
        {
            const bool isExtensionPresent =
                ptQoSFlowParamItem->bit_mask & E1_QoS_Flow_QoS_Parameter_Item_iE_Extensions_present;
            if (GOOD == VEIL_AddE1ExtensionToLinkedList(ptCi, isExtensionPresent, &ptQoSFlowParamItem->iE_Extensions,
                            pContainer, ecnMarkingContainer, E1_id_ECNMarkingorCongestionInformationReportingRequest,
                            E1_ECNMarkingorCongestionInformationReportingRequest_PDU))
            {
                ptQoSFlowParamItem->bit_mask |= E1_QoS_Flow_QoS_Parameter_Item_iE_Extensions_present;
                ptQoSFlowInfo->qosFlowInfoExtension.ecn.ecnMarkingState = ECN_MARKING_SENT_TO_UP;
            }
        }
    }
    // O - Next field - TBD

    return GOOD;
}

/**
 * @brief fill E1 QoS Flow QoS Parameters
 * @attention function sets all bit_mask
 * @param [in]  ptQoSFlowInfo       : qosFlowInfo_type DB
 * @param [out] ptQoSFlowParamItem  : E1_QoS_Flow_QoS_Parameter_Item buffer
 * @return      GOOD                : success fill
 * @return      ERROR               : error fill
 */
int VEIL_fillE1_QoSFlowItem(
        callInfo_type *ptCi, E1_QoS_Flow_QoS_Parameter_Item *ptQoSFlowParamItem, qosFlowInfo_type *ptQoSFlowInfo, uint8_t pduIdxInCall, unsigned int numQoSFlow, enumE1F1procedure_type procedure)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptQoSFlowParamItem);
    VALID_E_POINT_CHECK_ERROR(ptQoSFlowInfo);

    int status = GOOD;
    ptQoSFlowParamItem->bit_mask = 0;

    // QoS Flow Identifier - mandatory
    ptQoSFlowParamItem->qoS_Flow_Identifier = ptQoSFlowInfo->flowId;

    // QoS Flow Level QoS Parameters Fill - mandatory
    {
        ptQoSFlowParamItem->qoSFlowLevelQoSParameters.bit_mask = 0;
        if (ptQoSFlowInfo->qosParam.qosCharacteristics == ci_qos_char_non_dynamic_5qi)
        {
            ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.choice = E1_non_Dynamic_5QI_chosen;
    
            // Non Dynamic 5QI Descriptor -mandatory
            status = VEIL_FillE1_QosChar_NonDynamic5QI(&ptQoSFlowInfo->qosParam.nonDyna, 
                    &ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.u.non_Dynamic_5QI);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_FillE1_QosChar_NonDynamic5QI ERROR!!\n");

            if (DBG->flag.logE1)
                VCCB_PRINT_DATA(
                    "[E1DBG] qoSFlowLevelQoSParameters.qoS_Characteristics.choice:%d .u.non_Dynamic_5QI.fiveQI:%ld\n",
                    ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.choice,
                    ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.u.non_Dynamic_5QI.fiveQI);
        }
        else  // ci_qos_char_dynamic_5qi
        {
            ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.choice = E1_dynamic_5QI_chosen;
            // Dynamic 5QI Descriptor - mandatory
            ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.u.dynamic_5QI.bit_mask = 0;
            ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.u.dynamic_5QI.qoSPriorityLevel =
                static_cast<E1_QoSPriorityLevel>(ptQoSFlowInfo->qosParam.dynamic.priorityLevel);
            ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.u.dynamic_5QI.packetDelayBudget =
                static_cast<E1_PacketDelayBudget>(ptQoSFlowInfo->qosParam.dynamic.packetDelayBudget);

            ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.u.dynamic_5QI.packetErrorRate.bit_mask =
                0;
            ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.u.dynamic_5QI.packetErrorRate.pER_Scalar =
                static_cast<E1_PER_Scalar>(ptQoSFlowInfo->qosParam.dynamic.packetErrorRate.perScalar);
            ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.u.dynamic_5QI.packetErrorRate
                .pER_Exponent =
                static_cast<E1_PER_Exponent>(ptQoSFlowInfo->qosParam.dynamic.packetErrorRate.perExponent);

            // Delay Critical: This IE shall be present if the GBR QoS Flow Information IE is present in the QoS Flow
            // Level QoS Parameters IE. Averaging Window: This IE shall be present if the GBR QoS Flow Information IE is
            // present in the QoS Flow Level QoS Parameters IE.
            if (ptQoSFlowInfo->qosParam.gbrQosInformationPresent == OPT_PRESENT)
            {
                ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.u.dynamic_5QI.bit_mask |=
                    E1_delayCritical_present;
                ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.u.dynamic_5QI.delayCritical =
                    static_cast<E1__enum5>(ptQoSFlowInfo->qosParam.dynamic.delayCritical);

                ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.u.dynamic_5QI.bit_mask |=
                    E1_Dynamic5QIDescriptor_averagingWindow_present;
                ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.u.dynamic_5QI.averagingWindow =
                    ptQoSFlowInfo->qosParam.dynamic.averagingWindow;
            }

            if (DBG->flag.logE1)
                VCCB_PRINT_DATA(
                    "[E1DBG] qoSFlowLevelQoSParameters.qoS_Characteristics.choice:%d "
                    ".u.dynamic_5QI.qoSPriorityLevel:%ld .packetDelayBudget:%ld .packetErrorRate.pER_Scalar:%ld "
                    ".pER_Exponent:%ld\n",
                    ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.choice,
                    ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.u.dynamic_5QI.qoSPriorityLevel,
                    ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.u.dynamic_5QI.packetDelayBudget,
                    ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.u.dynamic_5QI.packetErrorRate
                        .pER_Scalar,
                    ptQoSFlowParamItem->qoSFlowLevelQoSParameters.qoS_Characteristics.u.dynamic_5QI.packetErrorRate
                        .pER_Exponent);
        }

        // NG-RAN Allocation and Retention Priority - mandatory
        ptQoSFlowParamItem->qoSFlowLevelQoSParameters.nGRANallocationRetentionPriority.bit_mask = 0;
        ptQoSFlowParamItem->qoSFlowLevelQoSParameters.nGRANallocationRetentionPriority.priorityLevel =
            ptQoSFlowInfo->qosParam.allocAndRetent.priorityLevel;
        ptQoSFlowParamItem->qoSFlowLevelQoSParameters.nGRANallocationRetentionPriority.pre_emptionCapability =
            static_cast<E1_Pre_emptionCapability>(ptQoSFlowInfo->qosParam.allocAndRetent.preemptionCapability);
        ptQoSFlowParamItem->qoSFlowLevelQoSParameters.nGRANallocationRetentionPriority.pre_emptionVulnerability =
            static_cast<E1_Pre_emptionVulnerability>(ptQoSFlowInfo->qosParam.allocAndRetent.preemptionVulnerability);
        if (DBG->flag.logE1)
            VCCB_PRINT_DATA(
                "[E1DBG] .nGRANallocationRetentionPriority.priorityLevel:%d .pre_emptionCapability:%d "
                ".pre_emptionVulnerability:%d\n",
                ptQoSFlowParamItem->qoSFlowLevelQoSParameters.nGRANallocationRetentionPriority.priorityLevel,
                ptQoSFlowParamItem->qoSFlowLevelQoSParameters.nGRANallocationRetentionPriority.pre_emptionCapability,
                ptQoSFlowParamItem->qoSFlowLevelQoSParameters.nGRANallocationRetentionPriority
                    .pre_emptionVulnerability);

        // GBR QoS Flow Information - optional
        // This IE shall be present for GBR QoS Flows only.
        if (ptQoSFlowInfo->qosParam.gbrQosInformationPresent == OPT_PRESENT)
        {
            ptQoSFlowParamItem->qoSFlowLevelQoSParameters.bit_mask |= E1_gBR_QoS_Flow_Information_present;
            ptQoSFlowParamItem->qoSFlowLevelQoSParameters.gBR_QoS_Flow_Information.bit_mask = 0;
            ptQoSFlowParamItem->qoSFlowLevelQoSParameters.gBR_QoS_Flow_Information.maxFlowBitRateDownlink =
                ptQoSFlowInfo->qosParam.gbrQosInfo.maximumFlowBitRateDL;
            ptQoSFlowParamItem->qoSFlowLevelQoSParameters.gBR_QoS_Flow_Information.maxFlowBitRateUplink =
                ptQoSFlowInfo->qosParam.gbrQosInfo.maximumFlowBitRateUL;
            ptQoSFlowParamItem->qoSFlowLevelQoSParameters.gBR_QoS_Flow_Information.guaranteedFlowBitRateDownlink =
                ptQoSFlowInfo->qosParam.gbrQosInfo.guaranteedFlowBitRateDL;
            ptQoSFlowParamItem->qoSFlowLevelQoSParameters.gBR_QoS_Flow_Information.guaranteedFlowBitRateUplink =
                ptQoSFlowInfo->qosParam.gbrQosInfo.guaranteedFlowBitRateUL;
        }

        // Reflective QoS Attribute - optional
        if (ptQoSFlowInfo->qosParam.reflectiveQosAttributePresent == OPT_PRESENT)
        {
            ptQoSFlowParamItem->qoSFlowLevelQoSParameters.bit_mask |= E1_reflective_QoS_Attribute_present;
            ptQoSFlowParamItem->qoSFlowLevelQoSParameters.reflective_QoS_Attribute =
                static_cast<E1__enum7>(ptQoSFlowInfo->qosParam.reflectiveQosAttribute);
        }
        // Additional QoS Flow Information - optional
        // RDI -optional
        // TBD
    }

    // QoS Flow Mapping Indication - optional
    // TBD

    // Qos Flow Info Extension - optional
    status = FnVCCB_Fill_E1QoSFlowInfoExtension_ExtContainer(ptCi, ptQoSFlowParamItem, ptQoSFlowInfo, procedure, pduIdxInCall, numQoSFlow);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_Fill_E1QoSFlowInfoExtension_ExtContainer ERROR - optional IE\n");
    }

    if (DBG->flag.logE1)
        VCCB_PRINT_DATA(
            "[E1DBG] ptQoSFlowParamItem->qoS_Flow_Identifier:%d\n", ptQoSFlowParamItem->qoS_Flow_Identifier);

    return GOOD;
}

struct qosRscIdx_type{
    uint8_t pduIdx;
    uint8_t drbIdx;
    uint8_t qosFlowIdx;
};

void* FnVCCB_Get_E1QosMonitoring_Value_Buffer(callInfo_type* ptCi, qosRscIdx_type qosIdxInfo, enumE1F1procedure_type procedure, enumQosMonitoringRequest_type val)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_NULL(ptCi);
    VCCB_CHECK_E_RANGE_AND_NULL(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    VCCB_CHECK_E_RANGE_AND_NULL(qosIdxInfo.pduIdx, MAX_PDU_SESS_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_NULL(qosIdxInfo.drbIdx, MAX_DRB_PER_PDU_SESS);
    // VCCB_CHECK_E_RANGE_AND_NULL(qosIdxInfo.qosFlowIdx, MAX_QOS_FLOW_PER_PDU_SESS);

    // typedef enum E1_QosMonitoringRequest {
    //     E1_QosMonitoringRequest_ul = 0,
    //     E1_QosMonitoringRequest_dl = 1,
    //     E1_QosMonitoringRequest_both = 2
    // } E1_QosMonitoringRequest;

    // typedef enum E1_QosMonitoringDisabled {
    //     E1_true = 0
    // } E1_QosMonitoringDisabled;    

    auto& e1SetupBuf = THREAD_INFO->call[ptCi->myThreadId].buf.tx.e1ap.bearerContextSetupRequest;
    auto& e1ModifyBuf = THREAD_INFO->call[ptCi->myThreadId].buf.tx.e1ap.bearerContextModificationRequest;
    static E1_QosMonitoringRequest* ptQosMonitoringRequest = NULL;
    static E1_QosMonitoringDisabled* ptQosMonitoringDisabled = NULL;

    switch (procedure)
    {
        case E1F1Setup:
            if (val == QOS_MONITORING_REQUEST_STOP)
            {
                ptQosMonitoringDisabled = &e1SetupBuf.pduSessToSetupData[qosIdxInfo.pduIdx].drbQosMonitoringDisabled[qosIdxInfo.drbIdx];
                *ptQosMonitoringDisabled = E1_true;
            }
            else
            {
                ptQosMonitoringRequest = &e1SetupBuf.pduSessToSetupData[qosIdxInfo.pduIdx].drbQosMonitoringRequest[qosIdxInfo.drbIdx];
                *ptQosMonitoringRequest = static_cast<E1_QosMonitoringRequest>(val);
            }
            break;
        case E1F1Modify_SetupMod:
            if (val == QOS_MONITORING_REQUEST_STOP)
            {
                ptQosMonitoringDisabled = &e1ModifyBuf.pduSessToSetupModData[qosIdxInfo.pduIdx].drbQosMonitoringDisabled[qosIdxInfo.drbIdx];
                *ptQosMonitoringDisabled = E1_true;
            }
            else
            {
                ptQosMonitoringRequest = &e1ModifyBuf.pduSessToSetupModData[qosIdxInfo.pduIdx].drbQosMonitoringRequest[qosIdxInfo.drbIdx];
                *ptQosMonitoringRequest = static_cast<E1_QosMonitoringRequest>(val);
            }
            break;
        case E1F1Modify_Modify:
            if (val == QOS_MONITORING_REQUEST_STOP)
            {
                ptQosMonitoringDisabled = &e1ModifyBuf.pduSessToModData[qosIdxInfo.pduIdx].drbQosMonitoringDisabled[qosIdxInfo.drbIdx];
                *ptQosMonitoringDisabled = E1_true;
            }
            else
            {
                ptQosMonitoringRequest = &e1ModifyBuf.pduSessToModData[qosIdxInfo.pduIdx].drbQosMonitoringRequest[qosIdxInfo.drbIdx];
                *ptQosMonitoringRequest = static_cast<E1_QosMonitoringRequest>(val);
            }
            break;
        default:
            return NULL;
    }

    // Return the address of the selected buffer
    if (val == QOS_MONITORING_REQUEST_STOP)
        return ptQosMonitoringDisabled;
    else
        return ptQosMonitoringRequest;
}

E1_ProtocolExtensionContainer_* FnVCCB_Get_E1QosMonitoring_ExtContainer_Buffer(callInfo_type* ptCi, qosRscIdx_type qosIdxInfo, enumE1F1procedure_type procedure, enumQosMonitoringRequest_type val, void* pQosMonitoringContainer)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_NULL(ptCi);
    VCCB_CHECK_E_RANGE_AND_NULL(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    VCCB_CHECK_E_RANGE_AND_NULL(qosIdxInfo.pduIdx, MAX_PDU_SESS_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_NULL(qosIdxInfo.drbIdx, MAX_DRB_PER_PDU_SESS);
    // VCCB_CHECK_E_RANGE_AND_NULL(qosIdxInfo.qosFlowIdx, MAX_QOS_FLOW_PER_PDU_SESS);

    struct E1_ProtocolExtensionContainer_* pContainer = NULL;
    auto& e1SetupBuf = THREAD_INFO->call[ptCi->myThreadId].buf.tx.e1ap.bearerContextSetupRequest;
    auto& e1ModifyBuf = THREAD_INFO->call[ptCi->myThreadId].buf.tx.e1ap.bearerContextModificationRequest;

    int pduNum = (val == QOS_MONITORING_REQUEST_STOP) ? E1_QosMonitoringDisabled_PDU : E1_QosMonitoringRequest_PDU;
    int pduName = (val == QOS_MONITORING_REQUEST_STOP) ? E1_id_QoSMonitoringDisabled : E1_id_QoSMonitoringRequest;
    switch(procedure)
    {
        case E1F1Setup:
                // ExtContainer
                pContainer = &e1SetupBuf.pduSessToSetupData[qosIdxInfo.pduIdx].drbQosMonitoringRequestBuf[qosIdxInfo.drbIdx];
                InsertE1_ExtensionContainerValue(pContainer, pduName, E1_ignore,
                    pQosMonitoringContainer, pduNum);
                break;
        case E1F1Modify_SetupMod:
                // ExtContainer
                pContainer = &e1ModifyBuf.pduSessToSetupModData[qosIdxInfo.pduIdx].drbQosMonitoringRequestBuf[qosIdxInfo.drbIdx];
                InsertE1_ExtensionContainerValue(pContainer, pduName, E1_ignore,
                    pQosMonitoringContainer, pduNum);
                break;
        case E1F1Modify_Modify:
                // ExtContainer
                pContainer = &e1ModifyBuf.pduSessToModData[qosIdxInfo.pduIdx].drbQosMonitoringRequestBuf[qosIdxInfo.drbIdx];
                InsertE1_ExtensionContainerValue(pContainer, pduName, E1_ignore,
                    pQosMonitoringContainer, pduNum);
                break;
            default:
                return NULL;      
    }
    return pContainer;
}

int16_t FnVCCB_Fill_QosMonitoringInfo_ForQosFlow_E1(callInfo_type* ptCi, qosFlowInfo_type* ptQi, E1_QosMonitoringRequest* ptQosMonitoringRequest, E1_QosMonitoringDisabled* ptQosMonitoringDisabled, struct E1_ProtocolExtensionContainer_ *pContainer, bool IsAlternativeForDRBQos)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR_PARAM2(ptCi, ptQi);
    VALID_E_POINT_CHECK_ERROR_PARAM3(ptQosMonitoringRequest, ptQosMonitoringDisabled, pContainer);

    enumQosMonitoringRequest_type qosMonitoring;

    if(IsAlternativeForDRBQos)
    {
        VCCB_CHECK_E_RANGE_AND_RETURN(ptQi->drbIdxInCall, MAX_DRB_PER_SA_CALL);
        qosMonitoring = ptCi->drb[ptQi->drbIdxInCall].drbQosMonitoring;
    }
    else
    {
        if (GNBINFO[ptCi->gnbNum].cfg.qosMonitoringSupport != VCCB_FLAG_ON)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "qosMonitoringSupport is not supported (YANG : qos-monitoring/feature-enable(%d))\n",
                GNBINFO[ptCi->gnbNum].cfg.qosMonitoringSupport);
            return BREAK;
        }

        if (ptQi->qosParam.qosMonitoringRequestPresent == OPT_NOT_PRESENT)
        {
            qosMonitoring = QOS_MONITORING_REQUEST_NOT_PRESENT;
        }
        else
        {
            qosMonitoring = ptQi->qosParam.qosMonitoringRequest;
        }
    }

    if (qosMonitoring == QOS_MONITORING_REQUEST_NOT_PRESENT) return BREAK;

    if ((ptQi->qosParam.qosMonitoringRequestPresent) || (IsAlternativeForDRBQos))
    {
        if (qosMonitoring != QOS_MONITORING_REQUEST_STOP)
        {
            *ptQosMonitoringRequest = static_cast<E1_QosMonitoringRequest>(qosMonitoring);
            InsertE1_ExtensionContainerValue(pContainer, E1_id_QoSMonitoringRequest, E1_ignore,
                ptQosMonitoringRequest, E1_QosMonitoringRequest_PDU);
        }
        else
        {
            *ptQosMonitoringDisabled = E1_true;
            InsertE1_ExtensionContainerValue(pContainer, E1_id_QoSMonitoringDisabled, E1_ignore,
                ptQosMonitoringDisabled, E1_QosMonitoringDisabled_PDU);
        }
        return GOOD;
    }

    return BREAK;
}

int16_t FnVCCB_Fill_QosMonitoringInfo_ForDrbQos_E1(callInfo_type* ptCi, callDRBInfo_type* ptDi, E1_QoSFlowLevelQoSParameters* pDrbQos, qosRscIdx_type qosIdxInfo, enumE1F1procedure_type procedure, enumQosMonitoringRequest_type qosVal) 
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);
    VALID_E_POINT_CHECK_ERROR(pDrbQos);    

    VCCB_CHECK_E_RANGE_AND_RETURN(qosIdxInfo.pduIdx, MAX_PDU_SESS_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(qosIdxInfo.drbIdx, MAX_DRB_PER_PDU_SESS);
    // VCCB_CHECK_E_RANGE_AND_RETURN(qosIdxInfo.qosFlowIdx, MAX_QOS_FLOW_PER_PDU_SESS);

    void* qosValContainer = NULL;    // E1_QosMonitoringRequest / E1_QosMonitoringDisabled
    struct E1_ProtocolExtensionContainer_* pExtContainer = NULL;

    qosValContainer = FnVCCB_Get_E1QosMonitoring_Value_Buffer(ptCi, qosIdxInfo, procedure, qosVal);
    if(qosValContainer == NULL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_Get_E1QosMonitoring_Value_Buffer ERROR\n");
        pDrbQos->bit_mask ^= E1_QoSFlowLevelQoSParameters_iE_Extensions_present;
        return ERROR;
    }

    pExtContainer = FnVCCB_Get_E1QosMonitoring_ExtContainer_Buffer(ptCi, qosIdxInfo, procedure, qosVal, qosValContainer);
    if(pExtContainer == NULL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_Get_E1QosMonitoring_ExtContainer_Buffer ERROR\n");
        pDrbQos->bit_mask ^= E1_QoSFlowLevelQoSParameters_iE_Extensions_present;
        return ERROR;
    }

    pDrbQos->bit_mask |= E1_QoSFlowLevelQoSParameters_iE_Extensions_present;
    pDrbQos->iE_Extensions = pExtContainer;
    return GOOD;
}

bool FnVCCB_Check_IsQosMonitoringPresent(callInfo_type &rCall, enumQosMonitoringRequest_type qosMonitoring)
{
    bool qosMonitoringPresent = false;
    if(qosMonitoring < QOS_MONITORING_REQUEST_NOT_PRESENT)
    {
        if ((GNBINFO[rCall.gnbNum].cfg.qosMonitoringSupport == VCCB_FLAG_OFF) && (qosMonitoring != QOS_MONITORING_REQUEST_STOP))
        {
            VCCB_PRINT_CALL_INFORMATIVE(&rCall, "qosMonitoringSupport is not supported (YANG : qos-monitoring/feature-enable(%d))\n",
                GNBINFO[rCall.gnbNum].cfg.qosMonitoringSupport);
        }
        else
        {
            qosMonitoringPresent = true;
        }
    }
    return qosMonitoringPresent;
}

/**
 * @brief fill E1 Drb QoS Parameters
 * @attention function sets all bit_mask
 * @param [in]  ptQoSFlowInfo       : qosFlowInfo_type DB
 * @param [out] ptQoSFlowLevelQoSParameters  : E1_QoSFlowLevelQoSParameters buffer
 * @return      GOOD                : success fill
 * @return      ERROR               : error fill
 */
int VEIL_fillE1_DrbQos(
        callInfo_type *ptCi, E1_QoSFlowLevelQoSParameters *ptQoSFlowLevelQoSParameters, qosFlowInfo_type *ptQoSFlowInfo, qosRscIdx_type qosIdxInfo, enumE1F1procedure_type procedure)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptQoSFlowLevelQoSParameters);
    VALID_E_POINT_CHECK_ERROR(ptQoSFlowInfo);

    if(ptQoSFlowInfo->usage != CI_use) return ERROR;
    VCCB_CHECK_E_RANGE_AND_RETURN(ptQoSFlowInfo->drbIdxInCall, MAX_DRB_PER_CALL);

    int status = GOOD;

    // QoS Characteristics - mandatory
    ptQoSFlowLevelQoSParameters->bit_mask = 0;

    // QoS Flow Level QoS Parameters Fill - mandatory
    if (ptQoSFlowInfo->qosParam.qosCharacteristics == ci_qos_char_non_dynamic_5qi)
    {
        ptQoSFlowLevelQoSParameters->qoS_Characteristics.choice = E1_non_Dynamic_5QI_chosen;
 
        // Non Dynamic 5QI Descriptor -mandatory
        status = VEIL_FillE1_QosChar_NonDynamic5QI(&ptQoSFlowInfo->qosParam.nonDyna, 
                &ptQoSFlowLevelQoSParameters->qoS_Characteristics.u.non_Dynamic_5QI);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_FillE1_QosChar_NonDynamic5QI ERROR!!\n");
        
        if (DBG->flag.logE1)
            VCCB_PRINT_DATA(
                "[E1DBG] qoSFlowLevelQoSParameters.qoS_Characteristics.choice:%d .u.non_Dynamic_5QI.fiveQI:%ld\n",
                ptQoSFlowLevelQoSParameters->qoS_Characteristics.choice,
                ptQoSFlowLevelQoSParameters->qoS_Characteristics.u.non_Dynamic_5QI.fiveQI);
    }
    else  // ci_qos_char_dynamic_5qi
    {
        ptQoSFlowLevelQoSParameters->qoS_Characteristics.choice = E1_dynamic_5QI_chosen;
        // Dynamic 5QI Descriptor - mandatory
        ptQoSFlowLevelQoSParameters->qoS_Characteristics.u.dynamic_5QI.bit_mask = 0;
        ptQoSFlowLevelQoSParameters->qoS_Characteristics.u.dynamic_5QI.qoSPriorityLevel =
            static_cast<E1_QoSPriorityLevel>(ptQoSFlowInfo->qosParam.dynamic.priorityLevel);
        ptQoSFlowLevelQoSParameters->qoS_Characteristics.u.dynamic_5QI.packetDelayBudget =
            static_cast<E1_PacketDelayBudget>(ptQoSFlowInfo->qosParam.dynamic.packetDelayBudget);

        ptQoSFlowLevelQoSParameters->qoS_Characteristics.u.dynamic_5QI.packetErrorRate.bit_mask = 0;
        ptQoSFlowLevelQoSParameters->qoS_Characteristics.u.dynamic_5QI.packetErrorRate.pER_Scalar =
            static_cast<E1_PER_Scalar>(ptQoSFlowInfo->qosParam.dynamic.packetErrorRate.perScalar);
        ptQoSFlowLevelQoSParameters->qoS_Characteristics.u.dynamic_5QI.packetErrorRate.pER_Exponent =
            static_cast<E1_PER_Exponent>(ptQoSFlowInfo->qosParam.dynamic.packetErrorRate.perExponent);

        // Delay Critical: This IE shall be present if the GBR QoS Flow Information IE is present in the QoS Flow Level
        // QoS Parameters IE. Averaging Window: This IE shall be present if the GBR QoS Flow Information IE is present
        // in the QoS Flow Level QoS Parameters IE.
        if (ptQoSFlowInfo->qosParam.gbrQosInformationPresent == OPT_PRESENT)
        {
            ptQoSFlowLevelQoSParameters->qoS_Characteristics.u.dynamic_5QI.bit_mask |= E1_delayCritical_present;
            ptQoSFlowLevelQoSParameters->qoS_Characteristics.u.dynamic_5QI.delayCritical =
                static_cast<E1__enum5>(ptQoSFlowInfo->qosParam.dynamic.delayCritical);

            ptQoSFlowLevelQoSParameters->qoS_Characteristics.u.dynamic_5QI.bit_mask |=
                E1_Dynamic5QIDescriptor_averagingWindow_present;
            ptQoSFlowLevelQoSParameters->qoS_Characteristics.u.dynamic_5QI.averagingWindow =
                ptQoSFlowInfo->qosParam.dynamic.averagingWindow;
        }

        if (DBG->flag.logE1)
            VCCB_PRINT_DATA(
                "[E1DBG] qoSFlowLevelQoSParameters.qoS_Characteristics.choice:%d .u.dynamic_5QI.qoSPriorityLevel:%ld "
                ".packetDelayBudget:%ld .packetErrorRate.pER_Scalar:%ld .pER_Exponent:%ld\n",
                ptQoSFlowLevelQoSParameters->qoS_Characteristics.choice,
                ptQoSFlowLevelQoSParameters->qoS_Characteristics.u.dynamic_5QI.qoSPriorityLevel,
                ptQoSFlowLevelQoSParameters->qoS_Characteristics.u.dynamic_5QI.packetDelayBudget,
                ptQoSFlowLevelQoSParameters->qoS_Characteristics.u.dynamic_5QI.packetErrorRate.pER_Scalar,
                ptQoSFlowLevelQoSParameters->qoS_Characteristics.u.dynamic_5QI.packetErrorRate.pER_Exponent);
    }

    // NG-RAN Allocation and Retention Priority - mandatory
    ptQoSFlowLevelQoSParameters->nGRANallocationRetentionPriority.bit_mask = 0;
    ptQoSFlowLevelQoSParameters->nGRANallocationRetentionPriority.priorityLevel =
        ptQoSFlowInfo->qosParam.allocAndRetent.priorityLevel;
    ptQoSFlowLevelQoSParameters->nGRANallocationRetentionPriority.pre_emptionCapability =
        static_cast<E1_Pre_emptionCapability>(ptQoSFlowInfo->qosParam.allocAndRetent.preemptionCapability);
    ptQoSFlowLevelQoSParameters->nGRANallocationRetentionPriority.pre_emptionVulnerability =
        static_cast<E1_Pre_emptionVulnerability>(ptQoSFlowInfo->qosParam.allocAndRetent.preemptionVulnerability);
    if (DBG->flag.logE1)
        VCCB_PRINT_DATA(
            "[E1DBG] .nGRANallocationRetentionPriority.priorityLevel:%d .pre_emptionCapability:%d "
            ".pre_emptionVulnerability:%d\n",
            ptQoSFlowLevelQoSParameters->nGRANallocationRetentionPriority.priorityLevel,
            ptQoSFlowLevelQoSParameters->nGRANallocationRetentionPriority.pre_emptionCapability,
            ptQoSFlowLevelQoSParameters->nGRANallocationRetentionPriority.pre_emptionVulnerability);

    // GBR QoS Flow Information - optional
    // This IE shall be present for GBR QoS Flows only.
    if (ptQoSFlowInfo->qosParam.gbrQosInformationPresent == OPT_PRESENT)
    {
        ptQoSFlowLevelQoSParameters->bit_mask |= E1_gBR_QoS_Flow_Information_present;
        ptQoSFlowLevelQoSParameters->gBR_QoS_Flow_Information.bit_mask = 0;
        ptQoSFlowLevelQoSParameters->gBR_QoS_Flow_Information.maxFlowBitRateDownlink =
            ptQoSFlowInfo->qosParam.gbrQosInfo.maximumFlowBitRateDL;
        ptQoSFlowLevelQoSParameters->gBR_QoS_Flow_Information.maxFlowBitRateUplink =
            ptQoSFlowInfo->qosParam.gbrQosInfo.maximumFlowBitRateUL;
        ptQoSFlowLevelQoSParameters->gBR_QoS_Flow_Information.guaranteedFlowBitRateDownlink =
            ptQoSFlowInfo->qosParam.gbrQosInfo.guaranteedFlowBitRateDL;
        ptQoSFlowLevelQoSParameters->gBR_QoS_Flow_Information.guaranteedFlowBitRateUplink =
            ptQoSFlowInfo->qosParam.gbrQosInfo.guaranteedFlowBitRateUL;
    }
    if (ptQoSFlowInfo->qosParam.reflectiveQosAttributePresent == OPT_PRESENT)
    {
        ptQoSFlowLevelQoSParameters->bit_mask |= E1_reflective_QoS_Attribute_present;
        ptQoSFlowLevelQoSParameters->reflective_QoS_Attribute =
            static_cast<E1__enum7>(ptQoSFlowInfo->qosParam.reflectiveQosAttribute);
    }

    // Reflective QoS Attribute - optional
    // Additional QoS Flow Information - optional
    // Paging Priority Indicator - optional
    // RDI -optional
    // E1_QoSFlowLevelQoSParameters_iE_Extensions
    // 5.1 F1_QosMonitoringRequest    

    // Decide QosMonitoring Value and Check YANG config
    callDRBInfo_type* ptDi = &ptCi->drb[ptQoSFlowInfo->drbIdxInCall];

    if(FnVCCB_Check_IsQosMonitoringPresent(*ptCi, ptDi->drbQosMonitoring))
    {
        if(GOOD != FnVCCB_Fill_QosMonitoringInfo_ForDrbQos_E1(ptCi, ptDi, ptQoSFlowLevelQoSParameters, qosIdxInfo, procedure, ptDi->drbQosMonitoring))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_Fill_QosMonitoringInfo_ForDrbQos_E1 ERROR\n");
            ptQoSFlowLevelQoSParameters->bit_mask ^= E1_QoSFlowLevelQoSParameters_iE_Extensions_present;
        }
        
    }

    return GOOD;
}

/**
 * @brief fill E1 SDAP Configuration Info
 * @attention function sets all bit_mask
 * @param [in]  pDRBInfo     : callDRBInfo DB
 * @param [in]  ptCi         : callInfo DB
 * @param [out] ptSdapConfig : E1_SDAP_Configuration buffer
 * @return      GOOD         : success fill
 * @return      ERROR        : error fill
 */
int VEIL_fillE1_SDAP_ConfigurationInfo(
    E1_SDAP_Configuration *ptSdapConfig, callInfo_type *ptCi, callDRBInfo_type *pDRBInfo)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptSdapConfig);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDRBInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    rbPdcpSdapConfig_type *pRbInfo = &(pDRBInfo->rbInfo);

    ptSdapConfig->bit_mask = 0;

    // Default DRB Fill - mandatory
    ptSdapConfig->defaultDRB = static_cast<E1_DefaultDRB>(pRbInfo->sdapInfo.defaultDRB);

    // SDAP Header UL Fill - mandatory
    ptSdapConfig->sDAP_Header_UL = static_cast<E1_SDAP_Header_UL>(pRbInfo->sdapInfo.headerUl);

    // SDAP Header DL Fill - mandatory
    ptSdapConfig->sDAP_Header_DL = static_cast<E1_SDAP_Header_DL>(pRbInfo->sdapInfo.headerDl);

    VCCB_PRINT_CALL_DATA(ptCi, "[E1DBG] ptSdapConfig->defaultDRB:%d sDAP_Header_UL:%d sDAP_Header_DL:%d\n",
        ptSdapConfig->defaultDRB, ptSdapConfig->sDAP_Header_UL, ptSdapConfig->sDAP_Header_DL);

    return GOOD;
}

uint8_t VEIL_checkE1_UEDLMaximumProtectedDataRate_Existence(callInfo_type *ptCi, E1_BitRate &bitrateValue)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_VALID_GNBNUM_FALSE(ptCi->gnbNum);

    if (GNBINFO[ptCi->gnbNum].security.isUpDrbIntegrityProtectionSupported == FALSE)
    {
        return FALSE;
    }

    bitrateValue = MAX_64kbs_BITRATE;
    uint8_t requiredIntegrity = FALSE;
   
    for (unsigned int loop = 0; loop < MAX_PDU_SESS_PER_CALL; loop++)
    {
        if (CI_use != ptCi->pduSess[loop].usage) continue;
        if (S_Setup != ptCi->pduSess[loop].pduSessStatus) continue;
        if (ptCi->pduSess[loop].securityInd.integProtectInd != E1_IntegrityProtectionIndication_required &&
            ptCi->pduSess[loop].securityInd.integProtectInd != E1_IntegrityProtectionIndication_preferred) continue;

        requiredIntegrity = TRUE;
        if (ptCi->pduSess[loop].securityInd.maxIPrateDLPresent && ptCi->pduSess[loop].securityInd.maxIPrateDL == ci_max_ip_rate_max_ue_rate)
        {
            bitrateValue = MAX_EXTENDED_BITRATE;
            return requiredIntegrity;
        }
    }
    

    return requiredIntegrity;
}

uint8_t FnVCCB_check_PDCP_Reestablishment_ForDRBToModifyItem(callInfo_type *ptCi, callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(ptDi);

    // It's SA ue function
    if (ptCi->callType == E_CALLTYPE_NSA) return FALSE;

    // check the condition
    switch (ptCi->stateCmd)
    {
        case RrcReestablish_cmd:
            return TRUE;

        case RRCSuspend_cmd:
            if (STATE_Inact_T_E1Mod == ptCi->state) return TRUE;
            break;

        case RRCResume_cmd:
            if (STATE_Inact_F1Mod == ptCi->state) return TRUE;
            break;

        case IntraCellHO_cmd:
            if (VCCB_FLAG_ON == ptCi->ueInfo.securityModFlag && VCCB_FLAG_OFF == ptCi->ueInfo.snKeyChangeWOMnKeyChange) return TRUE;
            break;

        case IntraRatHO_cmd:
            // Send it for inter gNB target
            if (ptCi->hoInfo.isTarget == TRUE)
            {
                return TRUE;
            }

            if (IS_NRDC_SN(ptCi))
            {
                if (VCCB_FLAG_ON == ptCi->ueInfo.securityModFlag) return TRUE;
            }

            if (IS_NRDC_MN(ptCi))
            {
                // DRB Type Change From 'SN Term XXX' To 'MN Term XXX'.
                if (FnVCCB_IsChangedTerminationPoint(ptCi, ptDi) == true)
                {
                    return TRUE;
                }
            }
            break;

        default:
            break;
    }

    return FALSE;
}

void  FnVCCB_EhcCtxtContinuePossible(callInfo_type *ptCi, callDRBInfo_type *pDRBInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pDRBInfo);

    pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_m.isEhcCtxtContinuePossible = FALSE;
    
    if(!IS_NON_DC(ptCi)) return;

    if ((FALSE == pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehcEnabled))
    {
        VCCB_PRINT_LOG_EHC(ptCi,
            "EHC Not Supported .Configured isEhcCtxtContinuePossible with value:(%d) \n",
                pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_m.isEhcCtxtContinuePossible);

      return;
    }
    pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_m.isEhcCtxtContinuePossible = pDRBInfo->rbInfo.pdcpInfo.reestablishPdcp&0x1U;

    if (((ptCi->hoInfo.hoType.nb == HO_TYPE_INTER_NB) && (ptCi->hoInfo.isTarget == TRUE)) ||
        ((ptCi->ueInfo.reestablishInfo.reestablishType == RRE_TYPE_INTER_GNB) &&
            (ptCi->ueInfo.reestablishInfo.isTargetGnb == TRUE)))

    {
        pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_m.isEhcCtxtContinuePossible = FALSE;
        VCCB_PRINT_LOG_EHC(
            ptCi, "EHC DRB Countine disabled due to PDCP Termination Point change  (inter GNB) \n");
    }
    else if ((RESUME_TYPE_INTER_GNB_TARGET == ptCi->ueInfo.rrcResumeInfo.resumeType &&
                 STATE_Inact_F1Mod == ptCi->state))
    {
        pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_m.isEhcCtxtContinuePossible = FALSE;
        VCCB_PRINT_LOG_EHC(
            ptCi, "EHC DRB Countine disabled due to PDCP Termination Point change(Inter GNB Resume) \n");
    }    

    return;
}

uint8_t FnVCCB_check_DrbContinueRohcPossible(callInfo_type *ptCi, callDRBInfo_type *pDRBInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(pDRBInfo);

    pDRBInfo->rbInfo.pdcpInfo.headerCompression.isDrbContinueRohcPossible = FALSE;

    if ((FALSE == pDRBInfo->rbInfo.pdcpInfo.headerCompression.ulRohcEnabled) ||
        (FALSE == pDRBInfo->rbInfo.pdcpInfo.headerCompression.symmetricRohcEnabled))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "(:ULRoHC) RoHC Not Supported ..Configured isDrbContinueRohcPossible with value : (%d)  \n",
            pDRBInfo->rbInfo.pdcpInfo.headerCompression.isDrbContinueRohcPossible);
        return TRUE;
    }
    pDRBInfo->rbInfo.pdcpInfo.headerCompression.isDrbContinueRohcPossible = pDRBInfo->rbInfo.pdcpInfo.reestablishPdcp;

    // In SVR21A NR RAN, Samsung's every inter-gNB scenario leads to the change of bearer termination point
    // Hence countue drb not send

    if (((ptCi->hoInfo.hoType.nb == HO_TYPE_INTER_NB) && (ptCi->hoInfo.isTarget == TRUE)) ||
        ((ptCi->ueInfo.reestablishInfo.reestablishType == RRE_TYPE_INTER_GNB) &&
            (ptCi->ueInfo.reestablishInfo.isTargetGnb == TRUE)))

    {
        pDRBInfo->rbInfo.pdcpInfo.headerCompression.isDrbContinueRohcPossible = FALSE;
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "(:ULRoHC) DRB Countine disabled due to PDCP Termination Point change  (inter GNB RRE) \n");
    }
    else if ((RESUME_TYPE_INTER_GNB_TARGET == ptCi->ueInfo.rrcResumeInfo.resumeType &&
                 STATE_Inact_F1Mod == ptCi->state))
    {
        pDRBInfo->rbInfo.pdcpInfo.headerCompression.isDrbContinueRohcPossible = FALSE;
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "(:ULRoHC) DRB Countine disabled due to PDCP Termination Point change(Inter GNB Resume) \n");
    }
    else if (IS_NRDC_MN(ptCi))
    {
        if (pDRBInfo->drbStatus == S_Setup &&
            (IS_NRDC_SNREL_INVOKED(ptCi) || ptCi->stateCmd == MrdcDrbBasedFallback_cmd))
        {
            pDRBInfo->rbInfo.pdcpInfo.headerCompression.isDrbContinueRohcPossible = FALSE;
            VCCB_PRINT_CALL_COMMENT(
                ptCi, "(:ULRoHC) DRB Countine disabled due to MR-DC (SN) PDCP Termination Point change \n");
        }
    }
    else if (IS_NRDC_SN(ptCi))
    {
        if (pDRBInfo->drbStatus == S_Setup)
        {
            pDRBInfo->rbInfo.pdcpInfo.headerCompression.isDrbContinueRohcPossible = FALSE;
            VCCB_PRINT_CALL_COMMENT(
                ptCi, "(:ULRoHC) DRB Countine disabled due to MR-DC (SN) PDCP Termination Point change \n");
        }
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "(:ULRoHC) Configured isDrbContinueRohcPossible with value : (%d)  \n",
        pDRBInfo->rbInfo.pdcpInfo.headerCompression.isDrbContinueRohcPossible);
    return TRUE;
}

uint8_t FnVCCB_check_PDCP_Reestablishment(callInfo_type *ptCi, callDRBInfo_type *pDRBInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(pDRBInfo);

    // It's SA ue function
    if (ptCi->callType == E_CALLTYPE_NSA) return FALSE;

    if (pDRBInfo->drbStatus == S_Setup)  // Operates when DRB Status is Setup.
    {
        // check the condition
        switch (ptCi->stateCmd)
        {
            case IntraRatHO_cmd:
                // Send it for inter gNB target
                if (ptCi->hoInfo.isTarget == TRUE)
                {
                    return TRUE;
                }
                break;

            case InterRatHO_cmd:  // FGR-MC1200 forwarding requirements
                break;

            case RrcReestablish_cmd:
                if (ptCi->ueInfo.reestablishInfo.isTargetGnb == TRUE)  // Inter gNB RRE, new gNB
                {
                    return TRUE;
                }
                break;
            case RRCSuspend_cmd:
                if (STATE_Inact_T_E1Mod == ptCi->state)
                {
                    return TRUE;
                }
                break;

            case RRCResume_cmd:
                if (STATE_Inact_F1Mod == ptCi->state)
                {
                    return TRUE;
                }
                break;

            default:
                break;
        }

        if (IS_NRDC_SN(ptCi))
        {
            return TRUE;
        }
        else if (IS_NRDC_MN(ptCi))
        {
            if ((IS_NRDC_SNREL_INVOKED(ptCi) && GET_MRDC_PROCEDURE_SNREL_OPRTYPE(ptCi) == MRDC_SNREL_OPR_XN_Fallback) ||
                ptCi->stateCmd == MrdcDrbBasedFallback_cmd)
            {
                return TRUE;
            }

            if (ptCi->stateCmd == IntraRatHO_cmd)  // TBD : review required in Basic Feature
            {
                // DRB Type Change From 'SN Term XXX' To 'MN Term XXX'.
                if (FnVCCB_IsChangedTerminationPoint(ptCi, pDRBInfo) == true)
                {
                    return TRUE;
                }
            }
        }

        return FALSE;
    }

    // pDRBInfo->drbStatus != S_Setup, Operates when DRB Status is not Setup.
    if (ptCi->stateCmd == RrcReestablish_cmd)
    {
        // TODO :: CHECK RRE Feature Owner
        // no action
    }
    else
    {
        if (FnVCCB_check_PDCP_Reestablishment_ForDRBToModifyItem(ptCi, pDRBInfo) == TRUE) return TRUE;
    }

    return FALSE;
}

/**
 * @brief fill certain portions of E1 PDCP Configuration Info
 * @param [in]  pRbInfo      : callRBInfo DB
 * @param [in]  ptCi         : callInfo DB
 * @param [out] ptPdcpConfig : E1_PDCP_Configuration buffer
 * @return      GOOD         : success fill
 * @return      ERROR        : error fill
 */
int VEIL_fillE1_EUTRAN_PDCP_ConfigurationInfo_SnSize_rlcMode(
    E1_PDCP_Configuration *ptPdcpConfig, callInfo_type *ptCi, rbPdcpSdapConfig_type *pRbInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptPdcpConfig);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pRbInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    // PDCP SN UL Size Fill - mandatory
    ptPdcpConfig->pDCP_SN_Size_UL = static_cast<E1_PDCP_SN_Size>(pRbInfo->pdcpInfo.pdcpSnSizeUl);

    // PDCP SN DL Size Fill - mandatory
    ptPdcpConfig->pDCP_SN_Size_DL = static_cast<E1_PDCP_SN_Size>(pRbInfo->pdcpInfo.pdcpSnSizeDl);

    // RLC mode Fill - mandatory
    uint8_t rlcMode = pRbInfo->rlcMode;
    switch (rlcMode)
    {
        case AM_RLC:
            ptPdcpConfig->rLC_Mode = E1_rlc_am;
            break;
        case UM_BI_RLC:
            ptPdcpConfig->rLC_Mode = E1_rlc_um_bidirectional;
            break;
        case UM_UNI_DL_RLC:
            ptPdcpConfig->rLC_Mode = E1_rlc_um_unidirectional_dl;
            break;
        case UM_UNI_UL_RLC:
            ptPdcpConfig->rLC_Mode = E1_rlc_um_unidirectional_ul;
            break;
        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "VEIL_fillE1_EUTRAN_PDCP_ConfigurationInfo: RLC mode fill ERROR !\n");

            return ERROR;
    }

    return GOOD;
}

/**
 * @brief fill certain portions of E1 PDCP Configuration Info
 * @param [in]  pRbInfo      : callRBInfo DB
 * @param [in]  ptCi         : callInfo DB
 * @param [out] ptPdcpConfig : E1_PDCP_Configuration buffer
 * @return      GOOD         : success fill
 * @return      ERROR        : error fill
 */
int VEIL_fillE1_PdcpMandatoryInfo(E1_PDCP_Configuration *ptPdcpConfig, callInfo_type *ptCi, rbPdcpSdapConfig_type *pRbInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptPdcpConfig);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pRbInfo);

    // PDCP SN UL Size Fill - mandatory
    ptPdcpConfig->pDCP_SN_Size_UL = static_cast<E1_PDCP_SN_Size>(pRbInfo->pdcpInfo.pdcpSnSizeUl);

    // PDCP SN DL Size Fill - mandatory
    ptPdcpConfig->pDCP_SN_Size_DL = static_cast<E1_PDCP_SN_Size>(pRbInfo->pdcpInfo.pdcpSnSizeDl);

    // RLC mode Fill - mandatory
    uint8_t rlcMode = pRbInfo->rlcMode;
    switch (rlcMode)
    {
        case AM_RLC:
            ptPdcpConfig->rLC_Mode = E1_rlc_am;
            break;
        case UM_BI_RLC:
            ptPdcpConfig->rLC_Mode = E1_rlc_um_bidirectional;
            break;
        case UM_UNI_DL_RLC:
            ptPdcpConfig->rLC_Mode = E1_rlc_um_unidirectional_dl;
            break;
        case UM_UNI_UL_RLC:
            ptPdcpConfig->rLC_Mode = E1_rlc_um_unidirectional_ul;
            break;
        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "VEIL_fillE1_PdcpMandatoryInfo: RLC mode fill ERROR !\n");

            return ERROR;
    }

    return GOOD;
}

void VEIL_fillE1_PDCP_ConfigurationInfoForRoHC(
    E1_PDCP_Configuration *ptPdcpConfig, rbPdcpSdapConfig_type *pRbInfo, uint8_t continueRohcCapable)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptPdcpConfig);
    VALID_E_POINT_CHECK_VOID(pRbInfo);

    //UL RoHC
    if ( OPT_PRESENT == pRbInfo->pdcpInfo.headerCompression.rohc_m.ulRohcEnabled )
    {
        if ((TRUE == pRbInfo->pdcpInfo.headerCompression.ulRohcEnabled) && 
            (TRUE == pRbInfo->pdcpInfo.headerCompression.useProfile006))
        {
            ptPdcpConfig->rOHC_Parameters.choice = E1_uPlinkOnlyROHC_chosen;
            ptPdcpConfig->rOHC_Parameters.u.uPlinkOnlyROHC.bit_mask = 0x00;
            ptPdcpConfig->rOHC_Parameters.u.uPlinkOnlyROHC.maxCID = pRbInfo->pdcpInfo.headerCompression.ulRohcMaxSession;

            /*
             * Bitmap with supported UE profiles, bit 0 (LSB 0) = profile0x0001, bit 1 = profile0x0002, bit 2 = profile0x0003,
             * bit 3 = profile0x0004, bit 4 = profile0x0006, bit 5 = profile0x0101, bit 6 = profile0x0102, bit 7 =
             * profile0x0103, bit 8 = profile0x0104.
             */
            ptPdcpConfig->rOHC_Parameters.u.uPlinkOnlyROHC.rOHC_Profiles = 0x01 << 4;

            if ((TRUE == pRbInfo->pdcpInfo.headerCompression.isDrbContinueRohcPossible) && (TRUE == continueRohcCapable) &&
               (TRUE == pRbInfo->pdcpInfo.headerCompression.drbContinueRohcEnabled))
            {
                ptPdcpConfig->rOHC_Parameters.u.uPlinkOnlyROHC.bit_mask |= E1_UplinkOnlyROHC_continueROHC_present;
                ptPdcpConfig->rOHC_Parameters.u.uPlinkOnlyROHC.continueROHC = E1_true_1;
            }
        }
    }
    // Symmetric RoHC
    else if (OPT_PRESENT == pRbInfo->pdcpInfo.headerCompression.rohc_m.symmetricRohcEnabled)
    {
        if ( TRUE == pRbInfo->pdcpInfo.headerCompression.symmetricRohcEnabled )
        {
            uint8_t rOhcProfile_bit_mask = 0x00;

            ptPdcpConfig->rOHC_Parameters.choice = E1_rOHC_chosen;
            ptPdcpConfig->rOHC_Parameters.u.rOHC.bit_mask = 0x00;
            ptPdcpConfig->rOHC_Parameters.u.rOHC.maxCID = pRbInfo->pdcpInfo.headerCompression.symmetricRohcMaxSession;

            (TRUE == pRbInfo->pdcpInfo.headerCompression.useProfile001) ? (rOhcProfile_bit_mask = rOhcProfile_bit_mask | 0x01)
                                                          : (rOhcProfile_bit_mask);
            (TRUE == pRbInfo->pdcpInfo.headerCompression.useProfile002) ? (rOhcProfile_bit_mask = rOhcProfile_bit_mask | 0x01 << 1)
                                                          : (rOhcProfile_bit_mask);
            (TRUE == pRbInfo->pdcpInfo.headerCompression.useProfile004) ? (rOhcProfile_bit_mask = rOhcProfile_bit_mask | 0x01 << 3)
                                                          : (rOhcProfile_bit_mask);

            ptPdcpConfig->rOHC_Parameters.u.rOHC.rOHC_Profiles = rOhcProfile_bit_mask;

            if ((pRbInfo->pdcpInfo.headerCompression.isDrbContinueRohcPossible == TRUE) &&
                (TRUE == pRbInfo->pdcpInfo.headerCompression.drbContinueRohcEnabled) &&
                (TRUE == continueRohcCapable))
            {
                ptPdcpConfig->rOHC_Parameters.u.rOHC.bit_mask |= E1_ROHC_continueROHC_present;
                ptPdcpConfig->rOHC_Parameters.u.rOHC.continueROHC = E1_true_1;
            }
        }
    }
}

/**
 * @brief check E1 DRB To Modify Item includes the E1_PDCP_Configuration
 * @param [in]  ptCi                                : callInfo DB
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_check_E1_DRBToModifyItem_PDCP_ConfigurationInfo(callInfo_type *ptCi, callDRBInfo_type *pDi)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDi);

    /* This function is for SA call */
    if (ptCi->callType != E_CALLTYPE_SA)
    {
        return ERROR;
    }

    /* SA handover case */
    if (ptCi->stateCmd == IntraRatHO_cmd)
    {
        switch (ptCi->state)
        {
            // For PDCP Data Recovery or Reestablishment
            case STATE_INTRA_DU_SnRelA:  // MN
            case STATE_INTER_DU_SnRelA:  // MN
                return GOOD;

            /* Intra DU handover, send the DL TX stop to UP */
            case STATE_INTRA_DU_E1Stop:     // MN
            case STATE_SN_INTRA_DU_E1Stop:  // SN
                if (ptCi->hoInfo.hoType.du == HO_TYPE_INTRA_DU)
                {
                    return GOOD;
                }
                break;

            /* Intra/Inter DU handover, send the DL TX resume to UP */
            case STATE_INTRA_DU_Cancel:     // MN
            case STATE_INTER_DU_Cancel:     // MN
            case STATE_SN_INTRA_DU_Cancel:  // SN
                return GOOD;

            /* Inter MN DU handover, send the DL TX stop to UP */
            case STATE_INTER_DU_Prepare:
                return GOOD;

            /* Inter SN DU handover, send the DL TX stop to UP with key change */
            case STATE_SN_INTER_DU_E1Stop:
                return GOOD;

            /* Inter SN DU handover, send the DL TX stop to UP without key change */
            case STATE_SN_INTER_DU_Exe:
                if (ptCi->ueInfo.securityModFlag == VCCB_FLAG_OFF)
                {
                    return GOOD;
                }
                break;

            case STATE_INTER_Pre_SN_T:
                if (IS_ON_E1_MRDC_CTRL_FLAG(pDi, scgDel))
                {
                    return ERROR;
                }
                break;

            // SN Init Inter-SN Mobility
            case STATE_MN_INTER_SN_E1Stop:  // MN
                if (pDi->bearerType.val == MN_Term_SPLIT_Bearer)
                {
                    return GOOD;
                }
                // no action
                break;

            default:
                break;
        }
    }
    /* SA handover PSCell Keep */
    if (ptCi->stateCmd == MrdcXnSNMod_cmd &&
        ((ptCi->state == STATE_Conn) &&
            FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_McgMobility) == true))
    {
        if (pDi->bearerType.val == SN_Term_SPLIT_Bearer)
        {
            return GOOD;
        }
    }

    if (MrdcSNModSnMobility_cmd == ptCi->stateCmd)
    {
        if (ptCi->state == STATE_MN_SNMob_TxStop)
        {
            if (pDi->bearerType.val == MN_Term_SPLIT_Bearer)
            {
                return GOOD;
            }
        }
    }

    if (ptCi->stateCmd == RrcReestablish_cmd)
    {
        switch (ptCi->state)
        {
            case STATE_RRE_Ready:
                if (((ptCi->ueInfo.reestablishInfo.reestablishType == RRE_TYPE_INTRA_DU) ||
                        (ptCi->ueInfo.reestablishInfo.reestablishType == RRE_TYPE_INTER_DU)) &&
                    GET_NGC_CONNECTION_FLAG(ptCi->flag.setupFlag))
                {
                    return GOOD;
                }
                break;

            default:
                break;
        }
    }

    /* SA resume case */
    if (((RRCResume_cmd == ptCi->stateCmd) && (STATE_Inact_F1Mod == ptCi->state)) ||
        ((RRCSuspend_cmd == ptCi->stateCmd) && (STATE_Inact_T_E1Mod == ptCi->state)))
    {
        return GOOD;
    }

    /* SA Intra Cell HO case */
    if (ptCi->stateCmd == IntraCellHO_cmd && VCCB_FLAG_ON == ptCi->ueInfo.securityModFlag) return GOOD;

    if ((IS_MRDC_MN(ptCi)) && (IS_ON_E1_MRDC_CTRL_FLAG(pDi, scgDel) || IS_ON_E1_MRDC_CTRL_FLAG(pDi, scgAdd)))
        return GOOD;

    /* don't include the PDCP_Configuration to UP */
    return ERROR;
}


/**
 * @brief fill E1 PDCP Configuration Info
 * @attention function sets all bit_mask
 * @param [in]  pDRBInfo     : callDRBInfo DB
 * @param [in]  ptCi         : callInfo DB
 * @param [out] ptPdcpConfig : E1_PDCP_Configuration buffer
 * @return      GOOD         : success fill
 * @return      ERROR        : error fill
 */
int VEIL_fillE1_DRBToModifyItem_PDCP_ConfigurationInfo(
    E1_BearerContextModificationRequestBuffer::PduSessToBeModData::DrbToBeModData *ptDrbToBeModBuffer , E1_PDCP_Configuration *ptPdcpConfig, callInfo_type *ptCi, callDRBInfo_type *pDRBInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptDrbToBeModBuffer);
    VALID_E_POINT_CHECK_ERROR(ptPdcpConfig);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDRBInfo);

    if (ERROR == FnVCCB_FillCallRbInfoPer5qi(ptCi, pDRBInfo, NR_PDCP_UPDATE_FINAL))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: FnVCCB_FillCallRbInfoPer5qi failed in %s. discard\n", __func__);
    }
    rbPdcpSdapConfig_type *pRbInfo = &(pDRBInfo->rbInfo);

    ptPdcpConfig->bit_mask = 0;

    uint32_t bit_mask = 0;
    // TS 38.463-g20
    // PDCP SN UL Size M
    // PDCP SN DL Size M
    // RLC mode    M
    if (ERROR == VEIL_fillE1_PdcpMandatoryInfo(ptPdcpConfig, ptCi, pRbInfo))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VEIL_fillE1_PdcpMandatoryInfo failed in %s\n", __func__);
        return ERROR;
    }

    // ROHC Parameters                          O (9_3_1_40)
    // TODO: make it with function


    // T-Reordering Timer                       O (9_3_1_41)
    bit_mask |= E1_t_ReorderingTimer_present;
    ptPdcpConfig->t_ReorderingTimer.bit_mask = 0;

    auto select_t_Reordering = [&ptCi, &pDRBInfo, &pRbInfo]() -> E1_T_Reordering
    {
        if (IS_NRDC_MN(ptCi) && FnVCCB_IsSplitPerDRB(ptCi, pDRBInfo, request_bearerType) == TRUE)
        {
            return (E1_T_Reordering)pRbInfo->pdcpInfo.tReorderingUlSplitFr1Fr2;
        }
        else if (IS_NRDC_SN(ptCi) && FnVCCB_IsSplitPerDRB(ptCi, pDRBInfo, current_bearerType) == TRUE)
        {
            return (E1_T_Reordering)pRbInfo->pdcpInfo.tReorderingUlSplitFr1Fr2;
        }
        return (E1_T_Reordering)pRbInfo->pdcpInfo.tReorderingUl;
    };

    ptPdcpConfig->t_ReorderingTimer.t_Reordering = select_t_Reordering();

    // Discard Timer                            O (9_3_1_42)

    // PDCP Duplication                         O Indicates whether PDCP duplication is to be configured for the DRB.
    //                                            This IE is ignored when the "Additional PDCP duplication
    //                                            Information" IE is present.

    // PDCP Re-establishment                    O Indicates PDCP entity re-establishment to be triggered as defined in
    // TS 38.323 [17]
    if (FnVCCB_check_PDCP_Reestablishment_ForDRBToModifyItem(ptCi, pDRBInfo))
    {
        bit_mask |= E1_pDCP_Reestablishment_present;
        ptPdcpConfig->pDCP_Reestablishment = E1_PDCP_Reestablishment_true;
        pRbInfo->pdcpInfo.reestablishPdcp = TRUE;

        pRbInfo->pdcpInfo.headerCompression.isDrbContinueRohcPossible = TRUE;
        FnVCCB_EhcCtxtContinuePossible(ptCi, pDRBInfo);

    }

    // Configure ROHC/VoNR during PDCP Re-establshment Secnario due to Security Context Change. Or during Intra gNB
    // Handover
    if (((TRUE == pRbInfo->pdcpInfo.headerCompression.symmetricRohcEnabled) ||
         (TRUE == pRbInfo->pdcpInfo.headerCompression.ulRohcEnabled)) &&
        ((TRUE == pRbInfo->pdcpInfo.reestablishPdcp) || IS_INTRA_GNB_HO()))
    {


        if (VLIB_PdcpReestabReqForRohcChange(ptCi, pDRBInfo))
        {
            bit_mask |= E1_pDCP_Reestablishment_present;
            ptPdcpConfig->pDCP_Reestablishment = E1_PDCP_Reestablishment_true;
            pRbInfo->pdcpInfo.reestablishPdcp = TRUE;
            pRbInfo->pdcpInfo.headerCompression.isDrbContinueRohcPossible = TRUE;
        }

        // Out Of Order Delivery - optional
        if (TRUE == pRbInfo->pdcpInfo.outOfOrderDelivery)
        {
            bit_mask |= E1_outOfOrderDelivery_present;
            ptPdcpConfig->outOfOrderDelivery = E1_OutOfOrderDelivery_true;
        }
        else  // ROHC Parameters - optional
        {
            /*
             * [Note] As per 3GPP TS 38.331, The total value of MAX_CIDs across all bearers for the UE should be less
             * than or equal to the value of maxNumberROHC-ContextSessions parameter as indicated by the UE. [Note] As
             * per 3GPP TS 38.331, gNB-CU-CP reconfigures headerCompression only upon reconfiguration involving PDCP
             * re-establishment. gNB-CU-CP configures headerCompression to notUsed when outOfOrderDelivery is
             * configured.
             */
            
            if (OPT_PRESENT == pRbInfo->pdcpInfo.m.headerCompression)
            {
                bit_mask |= E1_rOHC_Parameters_present;

                VEIL_fillE1_PDCP_ConfigurationInfoForRoHC(ptPdcpConfig, pRbInfo, ptCi->ueInfo.roHCCapability.continueRohcCapable);
            }
        }
    }

    // PDCP Data Recovery                       O Indicates PDCP data recovery to be triggered as defined in TS 38.323
    // [17]
    if (bit_mask & E1_pDCP_Reestablishment_present)
    {
        /* E1_pDCP_Reestablishment_present is higher priority then PDCP Data Recovery */
    }
    else
    {
        /* FR is ...
         * [Intra-gNB Handover without DRB's Security Key Change] [PDCP data recovery]
         *  gNB-CU-CP should indicate "PDCP data recovery" to both gNB-CU-UP and UE for an existing data radio bearer
         * during an intra-gNB handover that does not cause the security key change.
         * [MN Mobility with Intra PSCell Case] E1 Dl TX Stop is sent in Conn State.
         * */

        if (ptCi->stateCmd == IntraRatHO_cmd ||
            (IS_MRDC_MN(ptCi) && IS_ON_E1_MRDC_CTRL_FLAG(pDRBInfo, scgDel) &&
                !(ptCi->stateCmd == MrdcSNAddPrepareFail_cmd || ptCi->stateCmd == MrdcXnSNAdd_cmd)) ||
            (ptCi->stateCmd == MrdcXnSNMod_cmd &&
                ((ptCi->state == STATE_Conn) &&
                    FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_McgMobility) == true)))
        {
            bit_mask |= E1_pDCP_DataRecovery_present;
            ptPdcpConfig->pDCP_DataRecovery = E1_PDCP_DataRecovery_true;
        }

        if (ptCi->stateCmd == MrdcSNModSnMobility_cmd)
        {
            bit_mask |= E1_pDCP_DataRecovery_present;
            ptPdcpConfig->pDCP_DataRecovery = E1_PDCP_DataRecovery_true;
        }

        if (IntraCellHO_cmd == ptCi->stateCmd && STATE_Intra_Cell_E1Stop == ptCi->state)
        {
            bit_mask |= E1_pDCP_DataRecovery_present;
            ptPdcpConfig->pDCP_DataRecovery = E1_PDCP_DataRecovery_true;
        }
    }

    // Duplication Activation                   O Information on the initial state of  DL PDCP duplication

    // Out Of Order Delivery                    O Indicates whether or not outOfOrderDelivery specified in TS 38.323
    // [17] is configured.
    //                                            Out of order delivery is configured only when the radio bearer is
    //                                            established.

    // PDCP Status Report Indication            O For AM DRB, "downlink" indicates that the PDCP entity is configured
    // to send PDCP status report(s) to the UE,
    //                                            and "uplink" indicates that the UE is configured to send PDCP status
    //                                            report(s), as specified in TS 38.323 [17]. "both" indicates that
    //                                            both "downlink" and "uplink" should be applied.

    // Additional PDCP duplication Information  O Indicates the number of PDCP duplication configured when it is more
    // than 2 for the DRB

    // EHC Parameters                           O (9_3_1_90)

    if(IS_NON_DC(ptCi) && 
      (pDRBInfo->rbInfo.pdcpInfo.m.ethernet_headerCompression == OPT_PRESENT) &&
      (TRUE == pRbInfo->pdcpInfo.reestablishPdcp))
    {

        struct E1_ProtocolExtensionContainer_ *pContainerforPDCP = &ptDrbToBeModBuffer->pdcpConfigBuf;
        E1_EHC_Parameters *ptEhcParam = &ptDrbToBeModBuffer->ehcParam;

        ptEhcParam->bit_mask = 0x00;
        ptEhcParam->ehc_Common.bit_mask = 0;
        ptEhcParam->ehc_Common.ehc_CID_Length =  static_cast<E1__enum6>(pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_CIDlength);

        if (pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_m.isEhcCtxtContinuePossible)
        {
            ptEhcParam->ehc_Downlink.drb_ContinueEHC_DL = E1_drb_ContinueEHC_DL_false;
            ptEhcParam->ehc_Uplink.drb_ContinueEHC_UL = E1_drb_ContinueEHC_DL_false;

            if (ptCi->ueInfo.ehcCapability.continueEhcCapable == OPT_PRESENT)
            {
                if( pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_m.isEhcDrbCtxtContinue_dl == OPT_PRESENT)
                {
                    ptEhcParam->ehc_Downlink.drb_ContinueEHC_DL = E1_drb_ContinueEHC_DL_true;
                }
                if( pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_m.isEhcDrbCtxtContinue_ul == OPT_PRESENT)
                {
                    ptEhcParam->ehc_Uplink.drb_ContinueEHC_UL = E1_drb_ContinueEHC_DL_true;
                }
            }
           
            ptEhcParam->bit_mask |= E1_ehc_Downlink_present;
            ptEhcParam->bit_mask |= E1_ehc_Uplink_present;
            ptEhcParam->ehc_Downlink.bit_mask = 0x00;
            ptEhcParam->ehc_Uplink.bit_mask = 0x00;
            if(pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl>0)
            {
                struct E1_ProtocolExtensionContainer_ *pContainerforEhcDl = &ptDrbToBeModBuffer->ehcDLBuf;
                E1_MaxCIDEHCDL *ptEhcMaxCIDDL = &ptDrbToBeModBuffer->maxCidEhcDl;
                *ptEhcMaxCIDDL = (E1_MaxCIDEHCDL)pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl;
                InsertE1_ExtensionContainerValue(pContainerforEhcDl, E1_id_MaxCIDEHCDL, E1_ignore,ptEhcMaxCIDDL, E1_MaxCIDEHCDL_PDU);
                ptEhcParam->ehc_Downlink.bit_mask |= E1_EHC_Downlink_Parameters_iE_Extensions_present;
                ptEhcParam->ehc_Downlink.iE_Extensions = pContainerforEhcDl;
            }
        }
        else
        {
            if(pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl>0)
            {
                ptEhcParam->ehc_Downlink.drb_ContinueEHC_DL = E1_drb_ContinueEHC_DL_false;
                
                if(ptCi->ueInfo.ehcCapability.continueEhcCapable == OPT_PRESENT && 
                    pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_m.isEhcDrbCtxtContinue_dl == OPT_PRESENT)
                {
                    if (FnVCCB_check_PDCP_Reestablishment_ForDRBToModifyItem(ptCi, pDRBInfo) != TRUE)
                    {
                        ptEhcParam->ehc_Downlink.drb_ContinueEHC_DL = E1_drb_ContinueEHC_DL_true;
                    }
                }

                struct E1_ProtocolExtensionContainer_ *pContainerforEhcDl = &ptDrbToBeModBuffer->ehcDLBuf;
                E1_MaxCIDEHCDL *ptEhcMaxCIDDL = &ptDrbToBeModBuffer->maxCidEhcDl;
                *ptEhcMaxCIDDL = (E1_MaxCIDEHCDL)pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl;
                InsertE1_ExtensionContainerValue(pContainerforEhcDl, E1_id_MaxCIDEHCDL, E1_ignore,ptEhcMaxCIDDL, E1_MaxCIDEHCDL_PDU);
                ptEhcParam->ehc_Downlink.bit_mask = 0x00;
                ptEhcParam->ehc_Downlink.bit_mask |= E1_EHC_Downlink_Parameters_iE_Extensions_present;
                ptEhcParam->ehc_Downlink.iE_Extensions = pContainerforEhcDl;
                ptEhcParam->bit_mask |= E1_ehc_Downlink_present;
            }
        }

        InsertE1_ExtensionContainerValue(pContainerforPDCP, E1_id_EHC_Parameters, E1_ignore,ptEhcParam, E1_EHC_Parameters_PDU);
        bit_mask |= E1_PDCP_Configuration_iE_Extensions_present;
        ptPdcpConfig->iE_Extensions = pContainerforPDCP;
    }
       

    /* There is no optional parameters */
    if (bit_mask == 0)
    {
        return BREAK;
    }

    /* update the bit mask */
    ptPdcpConfig->bit_mask = static_cast<unsigned short>(bit_mask);

    if (IS_LOG_TRAFFIC(ptCi))
    {
        if (ptPdcpConfig->bit_mask & E1_pDCP_Reestablishment_present)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[TRAFFIC, PDCP-Config]: UP Reestablish! (DRB ID:%u)\n", pDRBInfo->dRBId);
        }
        if (ptPdcpConfig->bit_mask & E1_pDCP_DataRecovery_present)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[TRAFFIC, PDCP-Config]: UP DataRecovery! (DRB ID:%u)\n", pDRBInfo->dRBId);
        }
    }

    return GOOD;
}

int VEIL_fillE1_PDCP_ConfigurationInfo_SetupToMod(
    E1_BearerContextModificationRequestBuffer::PduSessToBeSetupModData::DrbToBeSetupModData *ptDrbToBeSetupModBuffer,
 E1_PDCP_Configuration *ptPdcpConfig, callInfo_type *ptCi, callDRBInfo_type *pDRBInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptDrbToBeSetupModBuffer);
    VALID_E_POINT_CHECK_ERROR(ptPdcpConfig);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDRBInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    rbPdcpSdapConfig_type *pRbInfo = &(pDRBInfo->rbInfo);

    ptPdcpConfig->bit_mask = 0;
    if (ERROR == VEIL_fillE1_PdcpMandatoryInfo(ptPdcpConfig, ptCi, pRbInfo))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VEIL_fillE1_PdcpMandatoryInfo failed in %s\n", __func__);
        return ERROR;
    }
    // PDCP Duplication - optional
    // PDCP Re-establishment - optional
    if (FnVCCB_check_PDCP_Reestablishment(ptCi, pDRBInfo) == TRUE)
    {
        pRbInfo->pdcpInfo.reestablishPdcp = TRUE;
        ptPdcpConfig->bit_mask |= E1_pDCP_Reestablishment_present;
        ptPdcpConfig->pDCP_Reestablishment = E1_PDCP_Reestablishment_true;
        VCCB_PRINT_CALL_COMMENT(ptCi, "(:ULRoHC) PDCP Re-establishment configured in E1 Interface\n");
    }
    FnVCCB_check_DrbContinueRohcPossible(ptCi, pDRBInfo);
    FnVCCB_EhcCtxtContinuePossible(ptCi, pDRBInfo);

    if ((TRUE == pRbInfo->pdcpInfo.headerCompression.ulRohcEnabled) ||
        (TRUE == pRbInfo->pdcpInfo.headerCompression.symmetricRohcEnabled))
    {
        // Out Of Order Delivery - optional
        if (TRUE == pRbInfo->pdcpInfo.outOfOrderDelivery)
        {
            ptPdcpConfig->bit_mask |= E1_outOfOrderDelivery_present;
            ptPdcpConfig->outOfOrderDelivery = E1_OutOfOrderDelivery_true;
        }
        else  // ROHC Parameters - optional
        {
            /*
             * [Note] As per 3GPP TS 38.331, The total value of MAX_CIDs across all bearers for the UE should be less
             * than or equal to the value of maxNumberROHC-ContextSessions parameter as indicated by the UE. [Note] As
             * per 3GPP TS 38.331, gNB-CU-CP reconfigures headerCompression only upon reconfiguration involving PDCP
             * re-establishment. gNB-CU-CP configures headerCompression to notUsed when outOfOrderDelivery is
             * configured.
             */

            if (OPT_PRESENT == pRbInfo->pdcpInfo.m.headerCompression)
            {
                ptPdcpConfig->bit_mask |= E1_rOHC_Parameters_present;

                VEIL_fillE1_PDCP_ConfigurationInfoForRoHC(ptPdcpConfig, pRbInfo, ptCi->ueInfo.roHCCapability.continueRohcCapable);
            }
        }
    }
    ptPdcpConfig->bit_mask |= E1_t_ReorderingTimer_present;
    ptPdcpConfig->t_ReorderingTimer.bit_mask = 0;

    auto select_t_Reordering = [&ptCi, &pDRBInfo, &pRbInfo]() -> E1_T_Reordering
    {
        if (IS_NRDC_MN(ptCi) && FnVCCB_IsSplitPerDRB(ptCi, pDRBInfo, request_bearerType) == TRUE)
        {
            return (E1_T_Reordering)pRbInfo->pdcpInfo.tReorderingUlSplitFr1Fr2;
        }
        else if (IS_NRDC_SN(ptCi) && FnVCCB_IsSplitPerDRB(ptCi, pDRBInfo, current_bearerType) == TRUE)
        {
            return (E1_T_Reordering)pRbInfo->pdcpInfo.tReorderingUlSplitFr1Fr2;
        }
        return (E1_T_Reordering)pRbInfo->pdcpInfo.tReorderingUl;
    };

    ptPdcpConfig->t_ReorderingTimer.t_Reordering = select_t_Reordering();

    // Discard Timer Fill - optional
    ptPdcpConfig->bit_mask |= E1_discardTimer_present;
    ptPdcpConfig->discardTimer = static_cast<E1_DiscardTimer>(pRbInfo->pdcpInfo.discardTimerDl);
    // UL Data Split Threshold - optional

    // PDCP Duplication - optional
    if(FnVccb_PdcpDuplicationActivationDecision(ptCi, pDRBInfo))
    {
        ptPdcpConfig->bit_mask |= E1_pDCP_Duplication_present;
        ptPdcpConfig->pDCP_Duplication = static_cast<E1_PDCP_Duplication>(E1_PDCP_Duplication_true);

        ptPdcpConfig->bit_mask |= E1_duplication_Activation_present;
        ptPdcpConfig->duplication_Activation = static_cast<E1_Duplication_Activation>(E1_Duplication_Activation_active);
    }

    // PDCP Data Recovery - optional
    if (ptPdcpConfig->bit_mask & E1_pDCP_Reestablishment_present)
    {
        /* E1_pDCP_Reestablishment_present is higher priority then PDCP Data Recovery */
    }
    else
    {
        // ..
    }

    if(IS_NON_DC(ptCi) && (pDRBInfo->rbInfo.pdcpInfo.m.ethernet_headerCompression == OPT_PRESENT))
    {
        struct E1_ProtocolExtensionContainer_ *pContainerforPDCP = &ptDrbToBeSetupModBuffer->pdcpConfigBuf;
        E1_EHC_Parameters *ptEhcParam = &ptDrbToBeSetupModBuffer->ehcParam;
        ptEhcParam->bit_mask = 0x00;
        ptEhcParam->ehc_Common.bit_mask = 0;
        ptEhcParam->ehc_Common.ehc_CID_Length =  static_cast<E1__enum6>(pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_CIDlength);

        if (pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_m.isEhcCtxtContinuePossible)
        {
            ptEhcParam->ehc_Downlink.drb_ContinueEHC_DL = E1_drb_ContinueEHC_DL_false;
            ptEhcParam->ehc_Uplink.drb_ContinueEHC_UL = E1_drb_ContinueEHC_DL_false;

            if (ptCi->ueInfo.ehcCapability.continueEhcCapable == OPT_PRESENT)
            {
                if( pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_m.isEhcDrbCtxtContinue_dl == OPT_PRESENT)
                {
                    ptEhcParam->ehc_Downlink.drb_ContinueEHC_DL = E1_drb_ContinueEHC_DL_true;
                }
                if( pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_m.isEhcDrbCtxtContinue_ul == OPT_PRESENT)
                {
                    ptEhcParam->ehc_Uplink.drb_ContinueEHC_UL = E1_drb_ContinueEHC_DL_true;
                }
            }

            ptEhcParam->bit_mask |= E1_ehc_Downlink_present;
            ptEhcParam->bit_mask |= E1_ehc_Uplink_present;
            ptEhcParam->ehc_Downlink.bit_mask = 0x00;
            ptEhcParam->ehc_Uplink.bit_mask = 0x00;
            if(pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl>0)
            {
                struct E1_ProtocolExtensionContainer_ *pContainerforEhcDl = &ptDrbToBeSetupModBuffer->ehcDLBuf;
                E1_MaxCIDEHCDL *ptEhcMaxCIDDL = &ptDrbToBeSetupModBuffer->maxCidEhcDl;
                *ptEhcMaxCIDDL = (E1_MaxCIDEHCDL)pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl;
                InsertE1_ExtensionContainerValue(pContainerforEhcDl, E1_id_MaxCIDEHCDL, E1_ignore,ptEhcMaxCIDDL, E1_MaxCIDEHCDL_PDU);
                ptEhcParam->ehc_Downlink.bit_mask |= E1_EHC_Downlink_Parameters_iE_Extensions_present;
                ptEhcParam->ehc_Downlink.iE_Extensions = pContainerforEhcDl;
            }
        }
        else
        {
            if(pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl>0)
            {
                ptEhcParam->ehc_Downlink.drb_ContinueEHC_DL = E1_drb_ContinueEHC_DL_false;

                if(ptCi->ueInfo.ehcCapability.continueEhcCapable == OPT_PRESENT &&
                    pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_m.isEhcDrbCtxtContinue_dl == OPT_PRESENT)
                {
                    if(FnVCCB_check_PDCP_Reestablishment(ptCi, pDRBInfo) != TRUE)
                    {
                        ptEhcParam->ehc_Downlink.drb_ContinueEHC_DL = E1_drb_ContinueEHC_DL_true;
                    }
                }

                struct E1_ProtocolExtensionContainer_ *pContainerforEhcDl = &ptDrbToBeSetupModBuffer->ehcDLBuf;
                E1_MaxCIDEHCDL *ptEhcMaxCIDDL = &ptDrbToBeSetupModBuffer->maxCidEhcDl;
                *ptEhcMaxCIDDL = (E1_MaxCIDEHCDL)pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl;
                InsertE1_ExtensionContainerValue(pContainerforEhcDl, E1_id_MaxCIDEHCDL, E1_ignore,ptEhcMaxCIDDL, E1_MaxCIDEHCDL_PDU);
                ptEhcParam->ehc_Downlink.bit_mask |= E1_EHC_Downlink_Parameters_iE_Extensions_present;
                ptEhcParam->ehc_Downlink.iE_Extensions = pContainerforEhcDl;
                ptEhcParam->bit_mask |= E1_ehc_Downlink_present;
            }
        }
     
        InsertE1_ExtensionContainerValue(pContainerforPDCP, E1_id_EHC_Parameters, E1_ignore,ptEhcParam, E1_EHC_Parameters_PDU);
        ptPdcpConfig->bit_mask |= E1_PDCP_Configuration_iE_Extensions_present;
        ptPdcpConfig->iE_Extensions = pContainerforPDCP;
    }

    VCCB_PRINT_CALL_DATA(ptCi, "[E1DBG] ptPdcpConfig->pDCP_SN_Size_UL:%d, pDCP_SN_Size_DL:%d rLC_Mode:%d\n",
        ptPdcpConfig->pDCP_SN_Size_UL, ptPdcpConfig->pDCP_SN_Size_DL, ptPdcpConfig->rLC_Mode);

    return GOOD;
}


/**
 * @brief fill E1 PDCP Configuration Info
 * @attention function sets all bit_mask
 * @param [in]  pDRBInfo     : callDRBInfo DB
 * @param [in]  ptCi         : callInfo DB
 * @param [out] ptPdcpConfig : E1_PDCP_Configuration buffer
 * @return      GOOD         : success fill
 * @return      ERROR        : error fill
 */
int VEIL_fillE1_PDCP_ConfigurationInfo(
    E1_BearerContextSetupRequestBuffer::PduSessToBeSetupData *ptPduSessToBeSetupBuffer , E1_PDCP_Configuration *ptPdcpConfig, callInfo_type *ptCi, callDRBInfo_type *pDRBInfo,uint16_t numDrb)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptPduSessToBeSetupBuffer);
    VALID_E_POINT_CHECK_ERROR(ptPdcpConfig);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDRBInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    DrbToBeSetupData *ptDrbToBeSetupBuffer = &ptPduSessToBeSetupBuffer->drbToSetupData[numDrb];
    rbPdcpSdapConfig_type *pRbInfo = &(pDRBInfo->rbInfo);

    ptPdcpConfig->bit_mask = 0;
    if (ERROR == VEIL_fillE1_PdcpMandatoryInfo(ptPdcpConfig, ptCi, pRbInfo))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VEIL_fillE1_PdcpMandatoryInfo failed in %s\n", __func__);
        return ERROR;
    }
    // PDCP Duplication - optional
    // PDCP Re-establishment - optional
    if (FnVCCB_check_PDCP_Reestablishment(ptCi, pDRBInfo) == TRUE)
    {
        pRbInfo->pdcpInfo.reestablishPdcp = TRUE;
        ptPdcpConfig->bit_mask |= E1_pDCP_Reestablishment_present;
        ptPdcpConfig->pDCP_Reestablishment = E1_PDCP_Reestablishment_true;
        VCCB_PRINT_CALL_COMMENT(ptCi, "(:ULRoHC) PDCP Re-establishment configured in E1 Interface\n");
    }

    FnVCCB_check_DrbContinueRohcPossible(ptCi, pDRBInfo);
    FnVCCB_EhcCtxtContinuePossible(ptCi, pDRBInfo);

    if ((TRUE == pRbInfo->pdcpInfo.headerCompression.ulRohcEnabled) ||
        (TRUE == pRbInfo->pdcpInfo.headerCompression.symmetricRohcEnabled))
    {
        // Out Of Order Delivery - optional
        if (TRUE == pRbInfo->pdcpInfo.outOfOrderDelivery)
        {
            ptPdcpConfig->bit_mask |= E1_outOfOrderDelivery_present;
            ptPdcpConfig->outOfOrderDelivery = E1_OutOfOrderDelivery_true;
        }
        else  // ROHC Parameters - optional
        {
            /*
             * [Note] As per 3GPP TS 38.331, The total value of MAX_CIDs across all bearers for the UE should be less
             * than or equal to the value of maxNumberROHC-ContextSessions parameter as indicated by the UE. [Note] As
             * per 3GPP TS 38.331, gNB-CU-CP reconfigures headerCompression only upon reconfiguration involving PDCP
             * re-establishment. gNB-CU-CP configures headerCompression to notUsed when outOfOrderDelivery is
             * configured.
             */
            
            if (OPT_PRESENT == pRbInfo->pdcpInfo.m.headerCompression)
            {
                ptPdcpConfig->bit_mask |= E1_rOHC_Parameters_present;

                VEIL_fillE1_PDCP_ConfigurationInfoForRoHC(ptPdcpConfig, pRbInfo, ptCi->ueInfo.roHCCapability.continueRohcCapable);
            }
        }
    }

    // T-Reordering Timer - optional
    // T-Reordering Timer Fill - optional
    ptPdcpConfig->bit_mask |= E1_t_ReorderingTimer_present;
    ptPdcpConfig->t_ReorderingTimer.bit_mask = 0;

    auto select_t_Reordering = [&ptCi, &pDRBInfo, &pRbInfo]() -> E1_T_Reordering
    {
        if (IS_NRDC_MN(ptCi) && FnVCCB_IsSplitPerDRB(ptCi, pDRBInfo, request_bearerType) == TRUE)
        {
            return (E1_T_Reordering)pRbInfo->pdcpInfo.tReorderingUlSplitFr1Fr2;
        }
        else if (IS_NRDC_SN(ptCi) && FnVCCB_IsSplitPerDRB(ptCi, pDRBInfo, current_bearerType) == TRUE)
        {
            return (E1_T_Reordering)pRbInfo->pdcpInfo.tReorderingUlSplitFr1Fr2;
        }
        return (E1_T_Reordering)pRbInfo->pdcpInfo.tReorderingUl;
    };

    ptPdcpConfig->t_ReorderingTimer.t_Reordering = select_t_Reordering();

    // Discard Timer Fill - optional
    ptPdcpConfig->bit_mask |= E1_discardTimer_present;
    ptPdcpConfig->discardTimer = static_cast<E1_DiscardTimer>(pRbInfo->pdcpInfo.discardTimerDl);
    // UL Data Split Threshold - optional
    // PDCP Duplication - optional

    // PDCP Data Recovery - optional
    if (ptPdcpConfig->bit_mask & E1_pDCP_Reestablishment_present)
    {
        /* E1_pDCP_Reestablishment_present is higher priority then PDCP Data Recovery */
    }
    else
    {
        // ..
    }

    // Duplication Activation - optional
    if(FnVccb_PdcpDuplicationActivationDecision(ptCi, pDRBInfo))
    {
        ptPdcpConfig->bit_mask |= E1_pDCP_Duplication_present;
        ptPdcpConfig->pDCP_Duplication = static_cast<E1_PDCP_Duplication>(E1_PDCP_Duplication_true);

        ptPdcpConfig->bit_mask |= E1_duplication_Activation_present;
        ptPdcpConfig->duplication_Activation = static_cast<E1_Duplication_Activation>(E1_Duplication_Activation_active);
    }

    // TBD
    if(IS_NON_DC(ptCi) && (pDRBInfo->rbInfo.pdcpInfo.m.ethernet_headerCompression == OPT_PRESENT))
    {
        struct E1_ProtocolExtensionContainer_ *pContainerforPDCP = &ptDrbToBeSetupBuffer->pdcpConfigBuf;
        E1_EHC_Parameters *ptEhcParam = &ptDrbToBeSetupBuffer->ehcParam;
        ptEhcParam->bit_mask = 0x00;
        ptEhcParam->ehc_Common.bit_mask = 0;
        ptEhcParam->ehc_Common.ehc_CID_Length =  static_cast<E1__enum6>(pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_CIDlength);

        if (pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_m.isEhcCtxtContinuePossible)
        {
            ptEhcParam->ehc_Downlink.drb_ContinueEHC_DL = E1_drb_ContinueEHC_DL_false;
            ptEhcParam->ehc_Uplink.drb_ContinueEHC_UL = E1_drb_ContinueEHC_DL_false;

            if (ptCi->ueInfo.ehcCapability.continueEhcCapable == OPT_PRESENT)
            {
                if( pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_m.isEhcDrbCtxtContinue_dl == OPT_PRESENT)
                {
                    ptEhcParam->ehc_Downlink.drb_ContinueEHC_DL = E1_drb_ContinueEHC_DL_true;
                }
                if( pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_m.isEhcDrbCtxtContinue_ul == OPT_PRESENT)
                {
                    ptEhcParam->ehc_Uplink.drb_ContinueEHC_UL = E1_drb_ContinueEHC_DL_true;
                }
            }

            ptEhcParam->bit_mask |= E1_ehc_Downlink_present;
            ptEhcParam->ehc_Downlink.bit_mask = 0x00;
            ptEhcParam->ehc_Uplink.bit_mask = 0;
            ptEhcParam->bit_mask |= E1_ehc_Uplink_present;

            if(pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl>0)
            {
                struct E1_ProtocolExtensionContainer_ *pContainerforEhcDl = &ptDrbToBeSetupBuffer->ehcDLBuf;
                E1_MaxCIDEHCDL *ptEhcMaxCIDDL = &ptDrbToBeSetupBuffer->maxCidEhcDl;
                *ptEhcMaxCIDDL = (E1_MaxCIDEHCDL)pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl;
                InsertE1_ExtensionContainerValue(pContainerforEhcDl, E1_id_MaxCIDEHCDL, E1_ignore,ptEhcMaxCIDDL, E1_MaxCIDEHCDL_PDU);
                ptEhcParam->ehc_Downlink.bit_mask |= E1_EHC_Downlink_Parameters_iE_Extensions_present;
                ptEhcParam->ehc_Downlink.iE_Extensions = pContainerforEhcDl;
            }
        }
        else
        {
            if(pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl>0)
            {
                ptEhcParam->ehc_Downlink.drb_ContinueEHC_DL = E1_drb_ContinueEHC_DL_false;

                if(ptCi->ueInfo.ehcCapability.continueEhcCapable == OPT_PRESENT &&
                    pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehc_m.isEhcDrbCtxtContinue_dl == OPT_PRESENT)
                {
                    if(FnVCCB_check_PDCP_Reestablishment(ptCi, pDRBInfo) != TRUE)
                    {
                        ptEhcParam->ehc_Downlink.drb_ContinueEHC_DL = E1_drb_ContinueEHC_DL_true;
                    }
                }

                struct E1_ProtocolExtensionContainer_ *pContainerforEhcDl = &ptDrbToBeSetupBuffer->ehcDLBuf;
                E1_MaxCIDEHCDL *ptEhcMaxCIDDL = &ptDrbToBeSetupBuffer->maxCidEhcDl;
                *ptEhcMaxCIDDL = (E1_MaxCIDEHCDL)pDRBInfo->rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl;
                InsertE1_ExtensionContainerValue(pContainerforEhcDl, E1_id_MaxCIDEHCDL, E1_ignore,ptEhcMaxCIDDL, E1_MaxCIDEHCDL_PDU);
                ptEhcParam->ehc_Downlink.bit_mask |= E1_EHC_Downlink_Parameters_iE_Extensions_present;
                ptEhcParam->ehc_Downlink.iE_Extensions = pContainerforEhcDl;
                ptEhcParam->bit_mask |= E1_ehc_Downlink_present;
            }
        }

        InsertE1_ExtensionContainerValue(pContainerforPDCP, E1_id_EHC_Parameters, E1_ignore,ptEhcParam, E1_EHC_Parameters_PDU);
        ptPdcpConfig->bit_mask |= E1_PDCP_Configuration_iE_Extensions_present;
        ptPdcpConfig->iE_Extensions = pContainerforPDCP;        
    }

    VCCB_PRINT_CALL_DATA(ptCi, "[E1DBG] ptPdcpConfig->pDCP_SN_Size_UL:%d, pDCP_SN_Size_DL:%d rLC_Mode:%d\n",
        ptPdcpConfig->pDCP_SN_Size_UL, ptPdcpConfig->pDCP_SN_Size_DL, ptPdcpConfig->rLC_Mode);

    return GOOD;
}

/**
 * @brief fill E1 PDCP Configuration Info for EUTRAN
 * @attention   function sets all bit_mask
 * @param [in]  pERABInfo    : eRabInfo DB
 * @param [in]  ptCi         : callInfo DB
 * @param [out] ptPdcpConfig : E1_PDCP_Configuration buffer
 * @return      GOOD         : success fill
 * @return      ERROR        : error fill
 */
int VEIL_fillE1_EUTRAN_PDCP_ConfigurationInfo(
    E1_PDCP_Configuration *ptPdcpConfig, callInfo_type *ptCi, callERABInfo_type *pERABInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptPdcpConfig);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    if (ERROR == FnVCCB_FillCallRbInfoPerQci(ptCi, pERABInfo, pERABInfo->erabQos.qciValue.QCI))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: FnVCCB_FillCallRbInfoPerQci failed in %s. discard\n", __func__);
    }
    rbPdcpSdapConfig_type *pRbInfo = &(pERABInfo->rbInfo);

    ptPdcpConfig->bit_mask = 0;

    uint8_t isContinueRohcPossible = FALSE;

    if (ERROR ==
        VEIL_fillE1_EUTRAN_PDCP_ConfigurationInfo_SnSize_rlcMode(ptPdcpConfig, ptCi, pRbInfo))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "ERROR: VEIL_fillE1_EUTRAN_PDCP_ConfigurationInfo_SnSize_rlcMode failed in %s\n", __func__);

        return ERROR;
    }

    // T-Reordering Timer Fill - optional
    ptPdcpConfig->bit_mask |= E1_t_ReorderingTimer_present;
    ptPdcpConfig->t_ReorderingTimer.bit_mask = 0;
    ptPdcpConfig->t_ReorderingTimer.t_Reordering = static_cast<E1_T_Reordering>(pRbInfo->pdcpInfo.tReorderingUl);

    if (IntraRatHO_cmd == ptCi->stateCmd)
    {
        if ((HO_TYPE_INTRA_NB == ptCi->hoInfo.hoType.nb) && (VCCB_FLAG_ON != ptCi->ueInfo.securityModFlag))
        {
            ptPdcpConfig->bit_mask |= E1_pDCP_DataRecovery_present;
            ptPdcpConfig->pDCP_DataRecovery = E1_PDCP_DataRecovery_true;
        }
        else
        {
            ptPdcpConfig->bit_mask |= E1_pDCP_Reestablishment_present;
            ptPdcpConfig->pDCP_Reestablishment = E1_PDCP_Reestablishment_true;
        }
    }
    else if (SPLIT_Bearer == pERABInfo->preveBearerType && pERABInfo->preveBearerType != pERABInfo->bearerType)
    {
        ptPdcpConfig->bit_mask |= E1_pDCP_DataRecovery_present;
        ptPdcpConfig->pDCP_DataRecovery = E1_PDCP_DataRecovery_true;
    }

    if (ERAB_Setup == pERABInfo->erabStatus)
    {
        // Discard Timer Fill - optional
        ptPdcpConfig->bit_mask |= E1_discardTimer_present;
        ptPdcpConfig->discardTimer = static_cast<E1_DiscardTimer>(pRbInfo->pdcpInfo.discardTimerDl);

        /*
         * [Note]
         * SamsungEnb : always set PDCP_Reestablishment.
         * OtherEnb   : follow below...
         *              - keep PDCP SN : if one of mcg-RB-Config and scg-RB-Config is set.
         *              - reset PDCP SN : if mcg-RB-Config and scg-RB-Config is not set.
         */
        if (ptCi->eNBInfo.x2VendorInd == 1)
        {
            //
            // SamsungEnb
            //
            pRbInfo->pdcpInfo.reestablishPdcp = TRUE;
            pRbInfo->pdcpInfo.headerCompression.isDrbContinueRohcPossible = TRUE;
        }
        else
        {
            //
            // OtherEnb
            //
            if (GET_DRB_SRC_MCG_CFG_FLAG(pERABInfo->flag.setupFlag) ||
                GET_DRB_SRC_SCG_CFG_FLAG(pERABInfo->flag.setupFlag))
            {
                pRbInfo->pdcpInfo.reestablishPdcp = TRUE;
                pRbInfo->pdcpInfo.headerCompression.isDrbContinueRohcPossible = TRUE;
            }
        }
    }

    // PDCP Reestablishment incase of Security Information Change
    if ((E_CALLTYPE_NSA == ptCi->callType) && (SgNBModification_cmd == ptCi->stateCmd) &&
        (VCCB_FLAG_ON == ptCi->ueInfo.securityModFlag))
    {
        pRbInfo->pdcpInfo.reestablishPdcp = TRUE;
        pRbInfo->pdcpInfo.headerCompression.isDrbContinueRohcPossible = TRUE;
    }

    if (TRUE == pRbInfo->pdcpInfo.reestablishPdcp)
    {
        ptPdcpConfig->bit_mask |= E1_pDCP_Reestablishment_present;
        ptPdcpConfig->pDCP_Reestablishment = E1_PDCP_Reestablishment_true;
    }
    // Out Of Order Delivery - optional
    if (TRUE == pRbInfo->pdcpInfo.outOfOrderDelivery)
    {
        ptPdcpConfig->bit_mask |= E1_outOfOrderDelivery_present;
        ptPdcpConfig->outOfOrderDelivery = E1_OutOfOrderDelivery_true;
    }
    else
    {
        if ((TRUE == pRbInfo->pdcpInfo.headerCompression.ulRohcEnabled) ||
            (TRUE == pRbInfo->pdcpInfo.headerCompression.symmetricRohcEnabled))
        {
            //[Note] As per 3GPP TS 38.331, gNB-CU-CP reconfigures headerCompression only upon reconfiguration involving
            // PDCP re-establishment. gNB-CU-CP configures headerCompression to notUsed when outOfOrderDelivery is
            // configured. continueRohcPossible is not required during ERAB Setup Secnario
            isContinueRohcPossible =
                (ERAB_Setup == pERABInfo->erabStatus) ? (FALSE) : (ptCi->ueInfo.roHCCapability.continueRohcCapable);

            if (OPT_PRESENT == pRbInfo->pdcpInfo.m.headerCompression)
            {
                ptPdcpConfig->bit_mask |= E1_rOHC_Parameters_present;

                VEIL_fillE1_PDCP_ConfigurationInfoForRoHC(ptPdcpConfig, pRbInfo, isContinueRohcPossible);
            }
        }
    }

    return GOOD;
}

/**
 * @brief fill E1 EUTRAN QoS
 * @attention function sets all bit_mask
 * @param [in]  ptCallERABInfo  : callERABInfo DB
 * @param [out] ptEutranQoS     : E1_EUTRAN_QoS buffer
 * @return      GOOD            : success fill
 * @return      ERROR           : error fill
 */
int VEIL_fillE1_EUTRAN_QoS(E1_EUTRAN_QoS *ptEutranQoS, const callERABInfo_type *ptCallERABInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptEutranQoS);
    VALID_E_POINT_CHECK_ERROR(ptCallERABInfo);

    ptEutranQoS->bit_mask = 0;

    // QCI Fill - mandatory
    ptEutranQoS->qCI = ptCallERABInfo->erabQos.qciValue.QCI;

    // E-UTRAN Allocation and Retention Priority Fill - mandatory
    ptEutranQoS->eUTRANallocationAndRetentionPriority.bit_mask = 0;
    ptEutranQoS->eUTRANallocationAndRetentionPriority.priorityLevel = ptCallERABInfo->erabQos.aRP.priority;
    ptEutranQoS->eUTRANallocationAndRetentionPriority.pre_emptionCapability =
        static_cast<E1_Pre_emptionCapability>(ptCallERABInfo->erabQos.aRP.preemCapable);
    ptEutranQoS->eUTRANallocationAndRetentionPriority.pre_emptionVulnerability =
        static_cast<E1_Pre_emptionVulnerability>(ptCallERABInfo->erabQos.aRP.preemVulnerable);

    // GBR QoS Information - optional
    if (ptCallERABInfo->erabQos.qciValue.gbrType == ci_GBR)
    {
        ptEutranQoS->bit_mask |= E1_gbrQosInformation_present;
        ptEutranQoS->gbrQosInformation.bit_mask = 0;
        ptEutranQoS->gbrQosInformation.e_RAB_MaximumBitrateDL = static_cast<E1_BitRate>(ptCallERABInfo->erabQos.dlMBR);
        ptEutranQoS->gbrQosInformation.e_RAB_MaximumBitrateUL = static_cast<E1_BitRate>(ptCallERABInfo->erabQos.ulMBR);
        ptEutranQoS->gbrQosInformation.e_RAB_GuaranteedBitrateDL = static_cast<E1_BitRate>(ptCallERABInfo->erabQos.dlGBR);
        ptEutranQoS->gbrQosInformation.e_RAB_GuaranteedBitrateUL = static_cast<E1_BitRate>(ptCallERABInfo->erabQos.ulGBR);
    }

    return GOOD;
}

namespace
{
/****************************************************************************
 * @brief    Function to fill source UL Configuration depending on Cell Group ID
 *           in case of EN-DC Intra SN Inter-DU handover rollback
 ****************************************************************************/
void VEIL_fillE1_RollbackUlConfiguration(callERABInfo_type *pERABInfo,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, int DRBnumber, int cellGroupListNum,
    enumCellGroupId cellGrpId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pERABInfo);
    VALID_E_POINT_CHECK_VOID(ptBearerModificationRequestBuffer);
    VCCB_CHECK_E_RANGE_AND_VOID(DRBnumber, MAX_ERAB_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_VOID(cellGroupListNum, MAX_NO_CELL_GROUPS);

    if (CellGroupId_MCG == cellGrpId)
    {
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask |=
            E1_Cell_Group_Information_Item_uL_Configuration_present;

        switch (pERABInfo->ulPdcpPath)
        {
            case UlPdcpPath_ScgShared:
                ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum]
                    .value.uL_Configuration = E1_shared;
                break;
            case UlPdcpPath_ScgOnly:
                ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum]
                    .value.uL_Configuration = E1_no_data;
                break;
            case UlPdcpPath_McgOnly:
            case UlPdcpPath_McgShared:
                ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum]
                    .value.uL_Configuration = E1_only;
                break;
            default:
                break;
        }
    }
    else if (CellGroupId_SCG == cellGrpId)
    {
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask |=
            E1_Cell_Group_Information_Item_uL_Configuration_present;

        switch (pERABInfo->ulPdcpPath)
        {
            case UlPdcpPath_ScgShared:
            case UlPdcpPath_ScgOnly:
                ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum]
                    .value.uL_Configuration = E1_only;
                break;
            case UlPdcpPath_McgShared:
                ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum]
                    .value.uL_Configuration = E1_shared;
                break;
            case UlPdcpPath_McgOnly:
                ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum]
                    .value.uL_Configuration = E1_no_data;
                break;
            default:
                break;
        }
    }
    else
    {
        VCCB_PRINT_ERROR("Invalid Cell Group Id(%d) in VEIL_fillE1_RollbackUlConfiguration ERROR!\n", cellGrpId);
    }
}
}  // end of anonymous namespace

/**
 * @brief fill E1 Cell Group To Modify DL TX Stop (status change) for Beaerer Context Modification Request
 * @attention function sets all bit_mask
 * @param [in]  statusChange                        : E1_DL_TX_Stop status enumeration
 * @param [in]  ptBearerModificationRequestBuffer   : E1_BearerContextModificationRequestBuffer buffer
 * @param [in]  pERABInfo                           : callERABInfo DB
 * @param [in]  DRBnumber                           : number of DRB item
 * @param [out] drbToModifyItem                     : E1_DRB_To_Modify_Item_EUTRAN buffer
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_fillE1_CellGroupToModifySetTxStatus(E1_DL_TX_Stop statusChange, E1_DRB_To_Modify_Item_EUTRAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, callInfo_type *ptCi,
    callERABInfo_type *pERABInfo, int DRBnumber)
{
    AUTO_TRACE_FUNC;

    int cellGroupListNum = 0;
    uint32_t nrArfcnDl;

    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(DRBnumber, MAX_ERAB_PER_CALL);

    drbToModifyItem->bit_mask = 0;

    // For notifying whether the connected cell is A6 or not.
    // During the handover process, resume is based on the target cell, stop is based on the serving cell.
    if ((statusChange == E1_DL_TX_Stop_resume) && (ptCi->stateCmd == IntraRatHO_cmd) &&
        (ptCi->hoInfo.hoType.nb == HO_TYPE_INTRA_NB) && (ptCi->hoInfo.targetCellNum < MAX_CELL_NUM_VCCB))
    {
        nrArfcnDl = CELLINFO[ptCi->hoInfo.targetCellNum].nrArfcnDl;
    }
    else
    {
        nrArfcnDl = CELLINFO[ptCi->servCellNum].nrArfcnDl;
    }

    if (SCG_Bearer == pERABInfo->bearerType || MCG_Bearer == pERABInfo->bearerType)
    {
        // SCG & MCG Bearer
        drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_EUTRAN_cell_Group_To_Modify_present;
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask =
            E1_dL_TX_Stop_present;
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.dL_TX_Stop =
            statusChange;
        switch (pERABInfo->bearerType)
        {
            case SCG_Bearer:
                ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.cell_Group_ID =
                    CellGroupId_SCG;
                break;
            case MCG_Bearer:
                ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.cell_Group_ID =
                    CellGroupId_MCG;
                break;
            default:
                break;
        }

        if (TRUE == IS_ENDC_HO_ROLLBACK_UL_PATH(ptCi, statusChange))
        {
            enumCellGroupId chosenCellGroupId = static_cast<enumCellGroupId>(
                ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.cell_Group_ID);
            VEIL_fillE1_RollbackUlConfiguration(
                pERABInfo, ptBearerModificationRequestBuffer, DRBnumber, cellGroupListNum, chosenCellGroupId);
        }

        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].next = nullptr;
        cellGroupListNum++;  // 1

        // Cell Group ID "3" is used for notifying A6G Cell to UP between Samsung gNB-CU-CP and gNB-CU-UP. (0: MCG,
        // 1:SCG, 2,3: Not Used in SPEC) This field should be filled when dL_TX_Stop(stop, resume) IE is sent to UP.
        if (nrArfcnDl >= MIN_A6_NR_ARFCN)  // A6G CASE
        {
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask =
                0;  // cell_Group_ID used only.
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.cell_Group_ID =
                CellGroupId_ForNotifyingA6G;
            cellGroupListNum++;  // 2

            // Connect Cell Group Information List
            if (ERROR == VCCB_ConnectLinkedList(
                             ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber], cellGroupListNum))
            {
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "ERROR: VCCB_ConnectLinkedList failed in VEIL_fillE1_CellGroupToModifySetTxStatus\n");

                return ERROR;
            }
        }

        drbToModifyItem->cell_Group_To_Modify = ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber];
    }
    else if (SPLIT_Bearer == pERABInfo->bearerType)
    {
        VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
        drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_EUTRAN_cell_Group_To_Modify_present;

        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask = 0;
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.cell_Group_ID =
            CellGroupId_MCG;

        /*  IS_ENDC_HO_Send_MCG_DlTxStop
            1. do not request DL Tx stop/resume for MCG during SN initiated intra-SgNB PScell change
            2. exclude requesting DL Tx stop for MCG in cell-Group-To-Modify in first E1 Modification (in STATE_DB)
               while changing bearer type from SCG to Split during HO
            3. include requesting DL Tx Stop for MCG when FullConfig HO is Triggered */
        if (IS_ENDC_HO_Send_MCG_DlTxStop(ptCi))
        {
            // MCG Bearer
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask |=
                E1_dL_TX_Stop_present;
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.dL_TX_Stop =
                statusChange;
        }

        if (TRUE == IS_ENDC_HO_SCGFailureResume_UL_PATH(ptCi, statusChange))
        {
            switch (pERABInfo->ulPdcpPath)
            {
                case UlPdcpPath_ScgShared:
                    ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask |=
                        E1_Cell_Group_Information_Item_uL_Configuration_present;
                    ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum]
                        .value.uL_Configuration = E1_shared;
                    break;
                case UlPdcpPath_ScgOnly:
                    ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask |=
                        E1_Cell_Group_Information_Item_uL_Configuration_present;
                    ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum]
                        .value.uL_Configuration = E1_no_data;
                    break;
                case UlPdcpPath_McgOnly:
                case UlPdcpPath_McgShared:
                    ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask |=
                        E1_Cell_Group_Information_Item_uL_Configuration_present;
                    ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum]
                        .value.uL_Configuration = E1_only;
                    break;
                default:
                    break;
            }
        }
        else if (TRUE == IS_ENDC_HO_ROLLBACK_UL_PATH(ptCi, statusChange))
        {
            // for MCG Cell Group in case of ENDC Inter-DU HO Rollback UL Path
            VEIL_fillE1_RollbackUlConfiguration(
                pERABInfo, ptBearerModificationRequestBuffer, DRBnumber, cellGroupListNum, CellGroupId_MCG);
        }

        if (0 != ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask)
        {
            // MCG Bearer
            cellGroupListNum++;  // 1
        }

        // Cell Group: SCG
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask =
            E1_dL_TX_Stop_present;
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.cell_Group_ID =
            CellGroupId_SCG;
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.dL_TX_Stop =
            statusChange;

        if (TRUE == IS_ENDC_HO_SCGFailureResume_UL_PATH(ptCi, statusChange))
        {
            switch (pERABInfo->ulPdcpPath)
            {
                case UlPdcpPath_ScgShared:
                case UlPdcpPath_ScgOnly:
                    ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask |=
                        E1_Cell_Group_Information_Item_uL_Configuration_present;
                    ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum]
                        .value.uL_Configuration = E1_only;
                    break;
                case UlPdcpPath_McgShared:
                    ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask |=
                        E1_Cell_Group_Information_Item_uL_Configuration_present;
                    ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum]
                        .value.uL_Configuration = E1_shared;
                    break;
                case UlPdcpPath_McgOnly:
                    ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask |=
                        E1_Cell_Group_Information_Item_uL_Configuration_present;
                    ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum]
                        .value.uL_Configuration = E1_no_data;
                    break;
                default:
                    break;
            }
        }
        else if (TRUE == IS_ENDC_HO_ROLLBACK_UL_PATH(ptCi, statusChange))
        {
            // for SCG Cell Group in case of ENDC Inter-DU HO Rollback UL Path
            VEIL_fillE1_RollbackUlConfiguration(
                pERABInfo, ptBearerModificationRequestBuffer, DRBnumber, cellGroupListNum, CellGroupId_SCG);
        }

        cellGroupListNum++;  // 2

        // Cell Group ID "3" is used for notifying A6G Cell to UP between Samsung gNB-CU-CP and gNB-CU-UP. (0: MCG,
        // 1:SCG, 2,3: Not Used in SPEC) This field should be filled when dL_TX_Stop(stop, resume) IE is sent to UP.
        if (nrArfcnDl >= MIN_A6_NR_ARFCN)  // A6G CASE
        {
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask =
                0;  // cell_Group_ID used only.
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.cell_Group_ID =
                CellGroupId_ForNotifyingA6G;
            cellGroupListNum++;  // 3
        }

        // Connect Cell Group To Modify List
        if (ERROR ==
            VCCB_ConnectLinkedList(ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber], cellGroupListNum))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "ERROR: VCCB_ConnectLinkedList failed in VEIL_fillE1_CellGroupToModifySetTxStatus\n");

            return ERROR;
        }

        drbToModifyItem->cell_Group_To_Modify = ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber];
    }
    else
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "BearerType error(%d)!\n", pERABInfo->bearerType);

        return ERROR;
    }

    return GOOD;
}

#define VEIL_FILL_E1_CELL_GROUP_ADD(cellGroupId)                                                                \
    {                                                                                                           \
        VCCB_CHECK_E_RANGE_AND_RETURN(DRBnumber, MAX_ERAB_PER_CALL);                                            \
        VCCB_CHECK_E_RANGE_AND_RETURN(cellGroupListNumAdd, MAX_NO_CELL_GROUPS);                                 \
        ptBearerModificationRequestBuffer->cellGroupToAdd[DRBnumber][cellGroupListNumAdd].value.bit_mask = 0;   \
        ptBearerModificationRequestBuffer->cellGroupToAdd[DRBnumber][cellGroupListNumAdd].value.bit_mask |=     \
            E1_Cell_Group_Information_Item_uL_Configuration_present | E1_rAT_Type_present;                      \
        ptBearerModificationRequestBuffer->cellGroupToAdd[DRBnumber][cellGroupListNumAdd].value.bit_mask |=     \
            E1_dL_TX_Stop_present;                                                                              \
        ptBearerModificationRequestBuffer->cellGroupToAdd[DRBnumber][cellGroupListNumAdd].value.cell_Group_ID = \
            cellGroupId;                                                                                        \
        ptBearerModificationRequestBuffer->cellGroupToAdd[DRBnumber][cellGroupListNumAdd].value.dL_TX_Stop =    \
            E1_DL_TX_Stop_stop;                                                                                 \
        if (CellGroupId_MCG == cellGroupId)                                                                     \
        {                                                                                                       \
            ptBearerModificationRequestBuffer->cellGroupToAdd[DRBnumber][cellGroupListNumAdd].value.rAT_Type =  \
                E1_RAT_Type_e_UTRA;                                                                             \
            if (ptCi->scgSuspendState || UlPdcpPath_McgOnly == pERABInfo->ulPdcpPath ||                         \
                UlPdcpPath_McgShared == pERABInfo->ulPdcpPath)                                                  \
            {                                                                                                   \
                ptBearerModificationRequestBuffer->cellGroupToAdd[DRBnumber][cellGroupListNumAdd]               \
                    .value.uL_Configuration = E1_only;                                                          \
            }                                                                                                   \
            else if ((TRUE == ptCi->ueInfo.ueCapa.mrdc.tddCapaAdd.general.splitDRB_withUL_Both_MCG_SCG) &&      \
                     ((NRRRC_UL_DataSplitThreshold_infinity != dataSplitThreshold) &&                           \
                         (FALSE == FnVCCB_PacketInspectionONQciBasedUlSplitThSwitchOFF(ptCi))))       \
            {                                                                                                   \
                ptBearerModificationRequestBuffer->cellGroupToAdd[DRBnumber][cellGroupListNumAdd]               \
                    .value.uL_Configuration = E1_shared;                                                        \
            }                                                                                                   \
            else                                                                                                \
            {                                                                                                   \
                ptBearerModificationRequestBuffer->cellGroupToAdd[DRBnumber][cellGroupListNumAdd]               \
                    .value.uL_Configuration = E1_no_data;                                                       \
            }                                                                                                   \
        }                                                                                                       \
        else                                                                                                    \
        {                                                                                                       \
            ptBearerModificationRequestBuffer->cellGroupToAdd[DRBnumber][cellGroupListNumAdd].value.rAT_Type =  \
                E1_RAT_Type_nR;                                                                                 \
            if (UlPdcpPath_McgOnly == pERABInfo->ulPdcpPath)                                                    \
            {                                                                                                   \
                ptBearerModificationRequestBuffer->cellGroupToAdd[DRBnumber][cellGroupListNumAdd]               \
                    .value.uL_Configuration = E1_no_data;                                                       \
            }                                                                                                   \
            else if (UlPdcpPath_McgShared == pERABInfo->ulPdcpPath)                                             \
            {                                                                                                   \
                ptBearerModificationRequestBuffer->cellGroupToAdd[DRBnumber][cellGroupListNumAdd]               \
                    .value.uL_Configuration = E1_shared;                                                        \
            }                                                                                                   \
            else                                                                                                \
            {                                                                                                   \
                ptBearerModificationRequestBuffer->cellGroupToAdd[DRBnumber][cellGroupListNumAdd]               \
                    .value.uL_Configuration = E1_only;                                                          \
            }                                                                                                   \
        }                                                                                                       \
        ptBearerModificationRequestBuffer->cellGroupToAdd[DRBnumber][cellGroupListNumAdd].next = nullptr;       \
        cellGroupListNumAdd++;                                                                                  \
        drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_EUTRAN_cell_Group_To_Add_present;                    \
        drbToModifyItem->cell_Group_To_Add = ptBearerModificationRequestBuffer->cellGroupToAdd[DRBnumber];      \
    }

#define VEIL_FILL_E1_CELL_GROUP_MOD(cellGroupId)                                                                   \
    {                                                                                                              \
        VCCB_CHECK_E_RANGE_AND_RETURN(DRBnumber, MAX_ERAB_PER_CALL);                                               \
        VCCB_CHECK_E_RANGE_AND_RETURN(cellGroupListNumMod, MAX_NO_CELL_GROUPS);                                    \
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.bit_mask = 0;   \
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.bit_mask |=     \
            E1_Cell_Group_Information_Item_uL_Configuration_present | E1_rAT_Type_present;                         \
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.bit_mask |=     \
            E1_dL_TX_Stop_present;                                                                                 \
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.cell_Group_ID = \
            cellGroupId;                                                                                           \
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.dL_TX_Stop =    \
            E1_DL_TX_Stop_stop;                                                                                    \
        if (CellGroupId_MCG == cellGroupId)                                                                        \
        {                                                                                                          \
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.rAT_Type =  \
                E1_RAT_Type_e_UTRA;                                                                                \
            if (ptCi->scgSuspendState || UlPdcpPath_McgOnly == pERABInfo->ulPdcpPath)                              \
            {                                                                                                      \
                ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod]               \
                    .value.uL_Configuration = E1_only;                                                             \
            }                                                                                                      \
            else if ((TRUE == ptCi->ueInfo.ueCapa.mrdc.tddCapaAdd.general.splitDRB_withUL_Both_MCG_SCG) &&         \
                     ((NRRRC_UL_DataSplitThreshold_infinity != dataSplitThreshold) &&                              \
                         (FALSE == FnVCCB_PacketInspectionONQciBasedUlSplitThSwitchOFF(ptCi))))          \
            {                                                                                                      \
                ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod]               \
                    .value.uL_Configuration = E1_shared;                                                           \
            }                                                                                                      \
            else                                                                                                   \
            {                                                                                                      \
                ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod]               \
                    .value.uL_Configuration = E1_no_data;                                                          \
            }                                                                                                      \
        }                                                                                                          \
        else                                                                                                       \
        {                                                                                                          \
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.rAT_Type =  \
                E1_RAT_Type_nR;                                                                                    \
            if (UlPdcpPath_McgOnly == pERABInfo->ulPdcpPath)                                                       \
            {                                                                                                      \
                ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod]               \
                    .value.uL_Configuration = E1_no_data;                                                          \
            }                                                                                                      \
            else                                                                                                   \
            {                                                                                                      \
                ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod]               \
                    .value.uL_Configuration = E1_only;                                                             \
            }                                                                                                      \
        }                                                                                                          \
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].next = nullptr;       \
        cellGroupListNumMod++;                                                                                     \
        drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_EUTRAN_cell_Group_To_Modify_present;                    \
        drbToModifyItem->cell_Group_To_Modify = ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber];   \
    }

#define VEIL_FILL_E1_CELL_GROUP_REMOVE(cellGroupId)                                                                \
    {                                                                                                              \
        VCCB_CHECK_E_RANGE_AND_RETURN(DRBnumber, MAX_ERAB_PER_CALL);                                               \
        VCCB_CHECK_E_RANGE_AND_RETURN(cellGroupListNumRem, MAX_NO_CELL_GROUPS);                                    \
        ptBearerModificationRequestBuffer->cellGroupToRemove[DRBnumber][cellGroupListNumRem].value.bit_mask = 0;   \
        ptBearerModificationRequestBuffer->cellGroupToRemove[DRBnumber][cellGroupListNumRem].value.cell_Group_ID = \
            cellGroupId;                                                                                           \
        ptBearerModificationRequestBuffer->cellGroupToRemove[DRBnumber][cellGroupListNumRem].next = nullptr;       \
        cellGroupListNumRem++;                                                                                     \
        drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_EUTRAN_cell_Group_To_Remove_present;                    \
        drbToModifyItem->cell_Group_To_Remove = ptBearerModificationRequestBuffer->cellGroupToRemove[DRBnumber];   \
    }

template <typename T>
int16_t FnVCCB_FillE1_ReportConfigList(callInfo_type *ptCi, uint8_t drbIdx, T &buffer, bool extension_exist,
    struct E1_ProtocolExtensionContainer_ *&container)
{
    VCCB_CHECK_E_RANGE_AND_RETURN(drbIdx, MAX_DRB_PER_CALL);
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (ERROR == VCCB_GlobalAlloc(buffer.pRptCfgList, MAX_TRF_MONITORING_CFG_PER_CALL))
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_GlobalAlloc failed in FnVCCB_FillE1_ReportConfigList!\n");
        return ERROR;
    }

    uint8_t cnt = 0;
    uint8_t repIdx = 0;
    for (const auto &reportCfg : ptCi->trafficMonitoringCfg.trafficReportDrbList[drbIdx].reportIdxList)
    {
        if (CI_use == reportCfg.usage &&
            repIdx < MAX_TRF_MONITORING_CFG_PER_CALL &&
            cnt < MAX_TRF_MONITORING_CFG_PER_CALL)
        {
            const auto &trfRepCfg = ptCi->trafficMonitoringCfg.trafficReportCfgList[repIdx];
            auto &repCfgListItemValue = buffer.pRptCfgList[cnt].value;
            repCfgListItemValue.bit_mask = 0;
            repCfgListItemValue.reportId = trfRepCfg.reportId;
            repCfgListItemValue.condition.bit_mask = 0;
            repCfgListItemValue.condition.iE_Extensions = NULL;

            switch (trfRepCfg.condition)
            {
                case THRESHOLD_ABOVE_condition:
                    repCfgListItemValue.condition.triggeringCondition.choice = E1_aboveThreshold_chosen;
                    repCfgListItemValue.condition.triggeringCondition.u.aboveThreshold.choice =
                        E1_numberOfQueuedPackets_chosen;
                    repCfgListItemValue.condition.triggeringCondition.u.aboveThreshold.u.numberOfQueuedPackets =
                        trfRepCfg.threshold;
                    break;

                case THRESHOLD_BELOW_condition:
                    repCfgListItemValue.condition.triggeringCondition.choice = E1_belowThreshold_chosen;
                    repCfgListItemValue.condition.triggeringCondition.u.belowThreshold.choice =
                        E1_numberOfQueuedPackets_chosen;
                    repCfgListItemValue.condition.triggeringCondition.u.belowThreshold.u.numberOfQueuedPackets =
                        trfRepCfg.threshold;
                    break;

                default:
                    VCCB_PRINT_CALL_ERROR(ptCi, "Invalid threshold condition - ERROR!\n");
                    return ERROR;
            }

            if (trfRepCfg.startMonitoringThr != std::numeric_limits<uint16_t>::max())
            {
                buffer.reportStartingCondition.choice = E1_numberOfQueuedPackets_chosen;
                buffer.reportStartingCondition.u.numberOfQueuedPackets = trfRepCfg.startMonitoringThr;

                InsertE1_ExtensionContainerValue(&buffer.extReportStartingCondition,
                    E1_id_SamsungDLTrafficStatusReportStartingCondition, E1_ignore, &buffer.reportStartingCondition,
                    E1_SamsungDLTrafficStatusReportThreshold_PDU);

                repCfgListItemValue.condition.iE_Extensions = &buffer.extReportStartingCondition;
                repCfgListItemValue.condition.bit_mask = E1_SamsungDLTrafficStatusReportCondition_iE_Extensions_present;
            }

            cnt++;
        }
        repIdx++;
    }

    if (0 < cnt)
    {
        if (GOOD != VCCB_ConnectLinkedList(buffer.pRptCfgList, static_cast<int>(cnt)))
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "VCCB_ConnectLinkedList failed in %s-> E1_SamsungDLTrafficStatusReportConfigListPerDRB!\n", __func__);
            return ERROR;
        }
    }
    else
    {
        // no configuration - set pointer to NULL
        buffer.pRptCfgList = nullptr;
    }

    InsertE1_ExtensionContainerValue(&buffer.dlTrafficStatusReportCfg,
        E1_id_SamsungDLTrafficStatusReportConfigListPerDRB, E1_ignore, &buffer.pRptCfgList,
        E1_SamsungDLTrafficStatusReportConfigListPerDRB_PDU);

    if (!extension_exist)
    {
        container = &buffer.dlTrafficStatusReportCfg;
        container->next = nullptr;
    }
    else
    {
        uint8_t max_loop = 0;
        while (container->next)
        {
            if (max_loop > 10)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "Protocolextension overflow %s!!\n", __func__);
                return ERROR;
            }
            container = container->next;
            max_loop++;
        }
        container->next = &buffer.dlTrafficStatusReportCfg;
        container->next->next = nullptr;
    }
    return GOOD;
}

/**
 * @brief fill E1 DRB To Setup Item EUTRAN for Bearer Context Setup Request Procedure
 * @attention   function sets all bit_mask
 * @param [in]      ptCi                        : callInfo DB
 * @param [in]      drbNum                      : ERAB index
 * @param [in]      drbNum                      : number of ERAB item
 * @param [in/out]  ptBearerSetupRequestBuffer  : E1_BearerContextSetupRequestBuffer buffer
 * @return          GOOD                        : success fill
 * @return          ERROR                       : fill error
 */
int VEIL_fillE1_DrbToSetupItemEUTRAN(callInfo_type *ptCi, uint8_t erabIdx, uint16_t erabNum,
    E1_BearerContextSetupRequestBuffer *ptBearerSetupRequestBuffer)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptBearerSetupRequestBuffer);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(erabIdx, MAX_ERAB_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(erabNum, MAX_ERAB_PER_CALL);

    int status = GOOD;
    int cellGroupListNum = 0;
    E1_DRB_To_Setup_Item_EUTRAN *drbToSetupItem = &ptBearerSetupRequestBuffer->drbToSetupList[erabNum].value;
    E1_BearerContextSetupRequestBuffer::DrbToBeSetupDataEutran *ptDrbToBeSetupBuffer =
        &ptBearerSetupRequestBuffer->drbToSetupData[erabNum];
    callERABInfo_type *pERABInfo = &ptCi->erabInfo[erabIdx];

    drbToSetupItem->bit_mask = 0;

    // DRB ID Fill - mandatory
    drbToSetupItem->dRB_ID = pERABInfo->dRBId;

    // PDCP Configuration Fill - mandatory (bitmasks set inside the fill function)
    status = VEIL_fillE1_EUTRAN_PDCP_ConfigurationInfo(&drbToSetupItem->pDCP_Configuration, ptCi, pERABInfo);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_EUTRAN_PDCP_ConfigurationInfo ERROR!\n");

    // E-UTRAN QoS Fill - mandatory (bitmasks set inside the fill function)
    status = VEIL_fillE1_EUTRAN_QoS(&drbToSetupItem->eUTRAN_QoS, pERABInfo);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_EUTRAN_QoS ERROR!\n");

    // S1 UL UP Transport Layer Information Fill - mandatory
    status = VEIL_fillE1_UP_TNL_Information(&drbToSetupItem->s1_UL_UP_TNL_Information, &pERABInfo->s1uUlInfo);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_UP_TNL_Information ERROR!\n");
    pERABInfo->s1uUlInfo.fNeedModify = 0;

    // Data Forwarding Information Request Fill - optional
    if (pERABInfo->snStatus.dlForwardFlag || pERABInfo->snStatus.ulForwardFlag)
    {
        drbToSetupItem->bit_mask |= E1_DRB_To_Setup_Item_EUTRAN_data_Forwarding_Information_Request_present;
        drbToSetupItem->data_Forwarding_Information_Request.bit_mask = 0;
    }

    if (pERABInfo->snStatus.dlForwardFlag && pERABInfo->snStatus.ulForwardFlag)
    {
        drbToSetupItem->data_Forwarding_Information_Request.data_Forwarding_Request = E1_Data_Forwarding_Request_both;
    }
    else if (pERABInfo->snStatus.ulForwardFlag)
    {
        drbToSetupItem->data_Forwarding_Information_Request.data_Forwarding_Request = E1_uL;
    }
    else if (pERABInfo->snStatus.dlForwardFlag)
    {
        drbToSetupItem->data_Forwarding_Information_Request.data_Forwarding_Request = E1_dL;
    }

    uint8_t dataSplitThreshold = 0;
    dataSplitThreshold = FnVCCB_GetUlDataSplitThreshold(ptCi, pERABInfo);

    // Cell Group Information Fill - mandatory
    if (SN_Terminated == pERABInfo->pDCPatSgNB)
    {
        if (SCG_Bearer == pERABInfo->bearerType)
        {
            ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.bit_mask =
                E1_Cell_Group_Information_Item_uL_Configuration_present | E1_rAT_Type_present;
            ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.cell_Group_ID = CellGroupId_SCG;
            ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.uL_Configuration = E1_only;
            ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.rAT_Type = E1_RAT_Type_nR;
            ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].next = nullptr;
            cellGroupListNum++;  // 1

            // Cell Group ID "3" is used for notifying A6G Cell to UP between Samsung gNB-CU-CP and gNB-CU-UP. (0: MCG,
            // 1:SCG, 2,3: Not Used in SPEC) This IE should be filled when setting DRB newly.
            if (CELLINFO[ptCi->servCellNum].nrArfcnDl >= MIN_A6_NR_ARFCN)  // A6G CASE
            {
                ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.bit_mask = 0;  // cell_Group_ID used only.
                ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.cell_Group_ID = CellGroupId_ForNotifyingA6G;
                cellGroupListNum++;  // 2

                // Connect Cell Group Information List
                status = VCCB_ConnectLinkedList(ptDrbToBeSetupBuffer->cellGroupList, cellGroupListNum);
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "ERROR: VCCB_ConnectLinkedList failed in "
                        "VEIL_fillE1_DrbToSetupItemEUTRAN->Cell Group Information!\n");
            }

            drbToSetupItem->cell_Group_Information = ptDrbToBeSetupBuffer->cellGroupList;
        }
        else if (SPLIT_Bearer == pERABInfo->bearerType)
        {
            // MCG Bearer
            ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.bit_mask =
                E1_Cell_Group_Information_Item_uL_Configuration_present | E1_rAT_Type_present;
            ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.cell_Group_ID = CellGroupId_MCG;
            if ((UlPdcpPath_McgOnly == pERABInfo->ulPdcpPath) || (UlPdcpPath_McgShared == pERABInfo->ulPdcpPath))
            {
                ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.uL_Configuration =
                    E1_only;  // UL Primary Path: MCG (infinte or not infinite)
            }
            else
            {
                if ((TRUE == ptCi->ueInfo.ueCapa.mrdc.tddCapaAdd.general.splitDRB_withUL_Both_MCG_SCG) &&
                    ((dataSplitThreshold != NRRRC_UL_DataSplitThreshold_infinity) &&
                        (FALSE == FnVCCB_PacketInspectionONQciBasedUlSplitThSwitchOFF(ptCi))))
                {
                    ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.uL_Configuration =
                        E1_shared;  // UL Primary Path: SCG (not infinite)
                }
                else
                {
                    ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.uL_Configuration =
                        E1_no_data;  // UL Primary Path: SCG (infinite)
                }
            }
            ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.rAT_Type = E1_RAT_Type_e_UTRA;
            cellGroupListNum++;  // 1

            // SCG Bearer
            ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.bit_mask =
                E1_Cell_Group_Information_Item_uL_Configuration_present | E1_rAT_Type_present;
            ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.cell_Group_ID = CellGroupId_SCG;
            if (UlPdcpPath_McgOnly == pERABInfo->ulPdcpPath)
            {
                ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.uL_Configuration =
                    E1_no_data;  // UL Primary Path: MCG (infinite)
            }
            else if (UlPdcpPath_McgShared == pERABInfo->ulPdcpPath)
            {
                if ((TRUE == ptCi->ueInfo.ueCapa.mrdc.tddCapaAdd.general.splitDRB_withUL_Both_MCG_SCG) &&
                    (dataSplitThreshold != NRRRC_UL_DataSplitThreshold_infinity))
                {
                    // UL Primary Path: MCG (not infinite)
                    ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.uL_Configuration = E1_shared;
                }
                else
                {
                    // UL Primary Path: MCG (infinite)
                    ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.uL_Configuration = E1_no_data;
                }
            }
            else
            {
                ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.uL_Configuration =
                    E1_only;  // UE Primary Path: SCG (infinte or not infinite)
            }
            ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.rAT_Type = E1_RAT_Type_nR;
            cellGroupListNum++;  // 2

            // Cell Group ID "3" is used for notifying A6G Cell to UP between Samsung gNB-CU-CP and gNB-CU-UP. (0: MCG,
            // 1:SCG, 2,3: Not Used in SPEC) This IE should be filled when setting DRB newly.
            if (CELLINFO[ptCi->servCellNum].nrArfcnDl >= MIN_A6_NR_ARFCN)  // A6G CASE
            {
                ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.bit_mask = 0;  // cell_Group_ID used only.
                ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.cell_Group_ID = CellGroupId_ForNotifyingA6G;
                cellGroupListNum++;  // 3
            }

            // Connect Cell Group Information List
            status = VCCB_ConnectLinkedList(ptDrbToBeSetupBuffer->cellGroupList, cellGroupListNum);
            VCCB_RETURN_ON_CALL_ERROR(
                    ptCi, status, "ERROR: VCCB_ConnectLinkedList failed in VEIL_fillE1_DrbToSetupItemEUTRAN->Cell " 
                    "Group Information!\n");

            drbToSetupItem->cell_Group_Information = ptDrbToBeSetupBuffer->cellGroupList;
        }
        else if (MCG_Bearer == pERABInfo->bearerType)
        {
            // MCG Bearer
            ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.bit_mask =
                E1_Cell_Group_Information_Item_uL_Configuration_present | E1_rAT_Type_present;
            ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.cell_Group_ID = CellGroupId_MCG;
            ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.uL_Configuration =
                E1_only;  // UE Primary Path: MCG (infinte or not infinite)
            ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].value.rAT_Type = E1_RAT_Type_e_UTRA;
            ptDrbToBeSetupBuffer->cellGroupList[cellGroupListNum].next = nullptr;
            cellGroupListNum++;  // 1

            drbToSetupItem->cell_Group_Information = ptDrbToBeSetupBuffer->cellGroupList;
        }
        else
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "BearerType error(%d)!\n", pERABInfo->bearerType);

            return ERROR;
        }
    }
    else
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "BearerType error pDCPatSgNB(%d)!\n", pERABInfo->pDCPatSgNB);

        return ERROR;
    }
    // DRB Inactivity Timer Fill - Optional
    // 22B_UserInactivity_FR214 Start
    if (GOOD == FnVCCB_FillNsaDrbInactivityTimerValue(ptCi, &drbToSetupItem->dRB_Inactivity_Timer, pERABInfo))
    {
        drbToSetupItem->bit_mask |= E1_DRB_To_Setup_Item_EUTRAN_dRB_Inactivity_Timer_present;
    }
    // 22B_UserInactivity_FR214 End

    // DRB DL traffic status configuration.
    if (FALSE == ptCi->trafficMonitoringCfg.trafficReportDrbList[erabIdx].isSameCfgFlag)
    {
        bool isExtensionPresent = drbToSetupItem->bit_mask & E1_DRB_To_Setup_Item_EUTRAN_iE_Extensions_present;
        status = FnVCCB_FillE1_ReportConfigList(ptCi, erabIdx, ptDrbToBeSetupBuffer->dlTrafficStatusReportEutran,
            isExtensionPresent, drbToSetupItem->iE_Extensions);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "Failed to fill DL traffic status report configuration.\n");

        if (GOOD == status)
        {
            drbToSetupItem->bit_mask |= E1_DRB_To_Setup_Item_EUTRAN_iE_Extensions_present;
        }
    }

    return GOOD;
}

void VEIL_fillE1_DrbToSetupModItemEUTRAN_Common(
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, uint8_t scgSuspendState,
    int DRBnumber, int cellGroupListNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptBearerModificationRequestBuffer);
    VCCB_CHECK_E_RANGE_AND_VOID(DRBnumber, MAX_ERAB_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_VOID(cellGroupListNum, MAX_NO_CELL_GROUPS);

    ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.bit_mask =
        E1_Cell_Group_Information_Item_uL_Configuration_present | E1_rAT_Type_present;
    ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.cell_Group_ID = CellGroupId_SCG;
    if (scgSuspendState)
    {
        ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.bit_mask |=
            E1_dL_TX_Stop_present;
        ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.uL_Configuration =
            E1_no_data;
        ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.dL_TX_Stop =
            E1_DL_TX_Stop_stop;
    }
    else
    {
        ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.uL_Configuration = E1_only;
    }
    ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.rAT_Type = E1_RAT_Type_nR;
    ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].next = nullptr;
}

int VEIL_fillE1_DrbToSetupModifyItem_Common(
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, callERABInfo_type *pERABInfo,
    int DRBnumber, int noofUPParameters, enumCellGroupId cellGrpId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(DRBnumber, MAX_ERAB_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(noofUPParameters, MAX_NO_UP_PARAMETERS);

    int status = GOOD;

    ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber][noofUPParameters].value.bit_mask = 0;
    ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber][noofUPParameters].value.cell_Group_ID = cellGrpId;
    if (CellGroupId_SCG == cellGrpId)
    {
        status = VEIL_fillE1_UP_TNL_Information(
            &ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber][noofUPParameters].value.uP_TNL_Information,
            &pERABInfo->f1uDlInfo);
    }
    else if (CellGroupId_MCG == cellGrpId)
    {
        status = VEIL_fillE1_UP_TNL_Information(
            &ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber][noofUPParameters].value.uP_TNL_Information,
            &pERABInfo->x2uDlInfo);
    }
    else
    {
        VCCB_PRINT_ERROR("VEIL_fillE1_DrbToSetupModifyItem_Common ERROR!\n");
        return ERROR;
    }

    if (ERROR == status)
    {
        VCCB_PRINT_ERROR("VEIL_fillE1_UP_TNL_Information ERROR in VEIL_fillE1_DrbToSetupModifyItem_Common!\n");
        return ERROR;
    }

    return GOOD;
}

/**
 * @brief fill E1 DRB To Setup Item EUTRAN for Bearer Context Modification Request Procedure
 * @attention   function sets all bit_mask
 * @param [in]      ptCi                              : callInfo DB
 * @param [in]      erabIdx                           : ERAB index
 * @param [in]      erabNum                           : ERAB number
 * @param [in/out]  ptBearerModificationRequestBuffer : E1_BearerContextModificationRequestBuffer buffer
 * @return          GOOD                              : success fill
 * @return          ERROR                             : fill error
 */
int VEIL_fillE1_DrbToSetupModItemEUTRAN(callInfo_type *ptCi, uint8_t erabIdx, uint16_t DRBnumber,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(erabIdx, MAX_ERAB_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(DRBnumber, MAX_ERAB_PER_CALL);

    int status = GOOD;
    int cellGroupListNum = 0;
    int noofUPParameters = 0;
    E1_DRB_To_Setup_Mod_Item_EUTRAN *drbToSetupModItem =
        &ptBearerModificationRequestBuffer->drbToSetupList[DRBnumber].value;
    callERABInfo_type *pERABInfo = &ptCi->erabInfo[erabIdx];

    drbToSetupModItem->bit_mask = 0;

    uint8_t dataSplitThreshold = 0;
    dataSplitThreshold = FnVCCB_GetUlDataSplitThreshold(ptCi, pERABInfo);

    // DRB ID Fill - mandatory
    drbToSetupModItem->dRB_ID = pERABInfo->dRBId;

    // PDCP Configuration Fill - mandatory (bitmasks set inside the fill function)
    status = VEIL_fillE1_EUTRAN_PDCP_ConfigurationInfo(&drbToSetupModItem->pDCP_Configuration, ptCi, pERABInfo);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_EUTRAN_PDCP_ConfigurationInfo ERROR!\n");

    // E-UTRAN QoS Fill - mandatory (bitmasks set inside the fill function)
    status = VEIL_fillE1_EUTRAN_QoS(&drbToSetupModItem->eUTRAN_QoS, pERABInfo);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_EUTRAN_QoS ERROR!\n");

    // S1 UL UP Transport Layer Information Fill - mandatory
    status = VEIL_fillE1_UP_TNL_Information(&drbToSetupModItem->s1_UL_UP_TNL_Information, &pERABInfo->s1uUlInfo);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_UP_TNL_Information ERROR!\n");

    // Data Forwarding Information Request Fill - optional
    if (pERABInfo->snStatus.dlForwardFlag || pERABInfo->snStatus.ulForwardFlag)
    {
        drbToSetupModItem->bit_mask |= E1_DRB_To_Setup_Mod_Item_EUTRAN_data_Forwarding_Information_Request_present;
        drbToSetupModItem->data_Forwarding_Information_Request.bit_mask = 0;
    }

    if (pERABInfo->snStatus.dlForwardFlag && pERABInfo->snStatus.ulForwardFlag)
    {
        drbToSetupModItem->data_Forwarding_Information_Request.data_Forwarding_Request =
            E1_Data_Forwarding_Request_both;
    }
    else if (pERABInfo->snStatus.ulForwardFlag)
    {
        drbToSetupModItem->data_Forwarding_Information_Request.data_Forwarding_Request = E1_uL;
    }
    else if (pERABInfo->snStatus.dlForwardFlag)
    {
        drbToSetupModItem->data_Forwarding_Information_Request.data_Forwarding_Request = E1_dL;
    }
    // DRB Inactivity Timer Fill - Optional
    // 22B_UserInactivity_FR214 Start
    if (GOOD == FnVCCB_FillNsaDrbInactivityTimerValue(ptCi, &drbToSetupModItem->dRB_Inactivity_Timer, pERABInfo))
    {
        drbToSetupModItem->bit_mask |= E1_DRB_To_Setup_Item_EUTRAN_dRB_Inactivity_Timer_present;
    }
    // 22B_UserInactivity_FR214 End

    // Cell Group Information Fill - mandatory
    if (SN_Terminated == pERABInfo->pDCPatSgNB)
    {
        if (SCG_Bearer == pERABInfo->bearerType)
        {
            VEIL_fillE1_DrbToSetupModItemEUTRAN_Common(
                ptBearerModificationRequestBuffer, ptCi->scgSuspendState, DRBnumber, cellGroupListNum);
            cellGroupListNum++;  // 1

            // Cell Group ID "3" is used for notifying A6G Cell to UP between Samsung gNB-CU-CP and gNB-CU-UP. (0: MCG,
            // 1:SCG, 2,3: Not Used in SPEC) This IE should be filled when setting DRB newly.
            if (CELLINFO[ptCi->servCellNum].nrArfcnDl >= MIN_A6_NR_ARFCN)  // A6G CASE
            {
                ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.bit_mask =
                    0;  // cell_Group_ID used only.
                ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.cell_Group_ID =
                    CellGroupId_ForNotifyingA6G;
                cellGroupListNum++;  // 2

                // Connect Cell Group Information List
                if (ERROR == VCCB_ConnectLinkedList(
                                 ptBearerModificationRequestBuffer->cellGroupList[DRBnumber], cellGroupListNum))
                {
                    VCCB_PRINT_CALL_ERROR(ptCi,
                        "ERROR: VCCB_ConnectLinkedList failed in "
                        "VEIL_fillE1_DrbToSetupModItemEUTRAN->Cell Group Information!\n");

                    return ERROR;
                }
            }

            drbToSetupModItem->cell_Group_Information = ptBearerModificationRequestBuffer->cellGroupList[DRBnumber];
        }
        else if (SPLIT_Bearer == pERABInfo->bearerType)
        {
            // MCG Bearer
            ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.bit_mask =
                E1_Cell_Group_Information_Item_uL_Configuration_present | E1_rAT_Type_present;
            ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.cell_Group_ID =
                CellGroupId_MCG;

            if ((ptCi->scgSuspendState) || (UlPdcpPath_McgOnly == pERABInfo->ulPdcpPath) ||
                (UlPdcpPath_McgShared == pERABInfo->ulPdcpPath))  // UL Primary Path: MCG (infinte or not infinite)
            {
                ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.uL_Configuration =
                    E1_only;
            }
            else
            {
                if ((TRUE == ptCi->ueInfo.ueCapa.mrdc.tddCapaAdd.general.splitDRB_withUL_Both_MCG_SCG) &&
                    ((dataSplitThreshold != NRRRC_UL_DataSplitThreshold_infinity) &&
                        (FALSE == FnVCCB_PacketInspectionONQciBasedUlSplitThSwitchOFF(ptCi))))
                {
                    ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum]
                        .value.uL_Configuration = E1_shared;  // UL Primary Path: SCG (not infinite)
                }
                else
                {
                    ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum]
                        .value.uL_Configuration = E1_no_data;  // UL Primary Path: SCG (infinite)
                }
            }
            ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.rAT_Type =
                E1_RAT_Type_e_UTRA;
            cellGroupListNum++;  // 1

            // SCG Bearer
            ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.bit_mask =
                E1_Cell_Group_Information_Item_uL_Configuration_present | E1_rAT_Type_present;
            ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.cell_Group_ID =
                CellGroupId_SCG;
            if (ptCi->scgSuspendState)
            {
                ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.bit_mask |=
                    E1_dL_TX_Stop_present;
                ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.uL_Configuration =
                    E1_no_data;
                ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.dL_TX_Stop =
                    E1_DL_TX_Stop_stop;
            }
            else if (UlPdcpPath_McgOnly == pERABInfo->ulPdcpPath)
            {
                ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.uL_Configuration =
                    E1_no_data;  // UL Primary Path: MCG (infinite)
            }
            else if (UlPdcpPath_McgShared == pERABInfo->ulPdcpPath)
            {
                if ((TRUE == ptCi->ueInfo.ueCapa.mrdc.tddCapaAdd.general.splitDRB_withUL_Both_MCG_SCG) &&
                    (dataSplitThreshold != NRRRC_UL_DataSplitThreshold_infinity))
                {
                    ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum]
                        .value.uL_Configuration = E1_shared;  // UL Primary Path: MCG (not infinite)
                }
                else
                {
                    ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum]
                        .value.uL_Configuration = E1_no_data;  // UL Primary Path: MCG (infinite)
                }
            }
            else
            {
                ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.uL_Configuration =
                    E1_only;  // UL Primary Path: SCG (infinite or not infinite)
            }
            ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.rAT_Type =
                E1_RAT_Type_nR;
            cellGroupListNum++;  // 2

            // Cell Group ID "3" is used for notifying A6G Cell to UP between Samsung gNB-CU-CP and gNB-CU-UP. (0: MCG,
            // 1:SCG, 2,3: Not Used in SPEC) This IE should be filled when setting DRB newly.
            if (CELLINFO[ptCi->servCellNum].nrArfcnDl >= MIN_A6_NR_ARFCN)  // A6G CASE
            {
                ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.bit_mask =
                    0;  // cell_Group_ID used only.
                ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.cell_Group_ID =
                    CellGroupId_ForNotifyingA6G;
                cellGroupListNum++;  // 3
            }

            // Connect Cell Group Information List
            if (ERROR ==
                VCCB_ConnectLinkedList(ptBearerModificationRequestBuffer->cellGroupList[DRBnumber], cellGroupListNum))
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "ERROR: VCCB_ConnectLinkedList failed in "
                    "VEIL_fillE1_DrbToSetupModItemEUTRAN->Cell Group Information!\n");

                return ERROR;
            }

            drbToSetupModItem->cell_Group_Information = ptBearerModificationRequestBuffer->cellGroupList[DRBnumber];
        }
        else if (MCG_Bearer == pERABInfo->bearerType)
        {
            ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.bit_mask =
                E1_Cell_Group_Information_Item_uL_Configuration_present | E1_rAT_Type_present;
            ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.cell_Group_ID =
                CellGroupId_MCG;

            if ((ptCi->scgSuspendState) || (UlPdcpPath_McgOnly == pERABInfo->ulPdcpPath) ||
                (UlPdcpPath_McgShared == pERABInfo->ulPdcpPath))  // UE Primary Path: MCG (infinte or not infinite)
            {
                ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.uL_Configuration =
                    E1_only;
            }
            else
            {
                if ((TRUE == ptCi->ueInfo.ueCapa.mrdc.tddCapaAdd.general.splitDRB_withUL_Both_MCG_SCG) &&
                    ((NRRRC_UL_DataSplitThreshold_infinity != dataSplitThreshold) &&
                        (FALSE == FnVCCB_PacketInspectionONQciBasedUlSplitThSwitchOFF(ptCi))))
                {
                    ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum]
                        .value.uL_Configuration = E1_shared;  // UE Primary Path: SCG (not infinite)
                }
                else
                {
                    ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum]
                        .value.uL_Configuration = E1_no_data;  // UE Primary Path: SCG (infinite)
                }
            }

            ptBearerModificationRequestBuffer->cellGroupList[DRBnumber][cellGroupListNum].value.rAT_Type =
                E1_RAT_Type_e_UTRA;
            cellGroupListNum++;  // 1

            // Connect Cell Group Information List
            // Call to ensure that ptBearerModificationRequestBuffer->cellGroupList[DRBnumber].next is set to NULL
            if (ERROR ==
                VCCB_ConnectLinkedList(ptBearerModificationRequestBuffer->cellGroupList[DRBnumber], cellGroupListNum))
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "ERROR: VCCB_ConnectLinkedList failed in "
                    "VEIL_fillE1_DrbToSetupModItemEUTRAN->Cell Group Information!\n");

                return ERROR;
            }

            drbToSetupModItem->cell_Group_Information = ptBearerModificationRequestBuffer->cellGroupList[DRBnumber];
        }
        else
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "BearerType error(%d)!\n", pERABInfo->bearerType);

            return ERROR;
        }
    }
    else
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "BearerType error pDCPatSgNB(%d)!\n", pERABInfo->pDCPatSgNB);

        return ERROR;
    }

    // DL UP Parameters Fill - optional
    if (SN_Terminated == pERABInfo->pDCPatSgNB && MCG_Bearer == pERABInfo->bearerType)
    {
        if (1 == pERABInfo->x2uDlInfo.fNeedModify)
        {
            if (ERROR == VEIL_fillE1_DrbToSetupModifyItem_Common(ptBearerModificationRequestBuffer, pERABInfo,
                             DRBnumber, noofUPParameters, CellGroupId_MCG))
            {
                VCCB_PRINT_ERROR(
                    "VEIL_fillE1_DrbToSetupModifyItem_Common ERROR in VEIL_fillE1_DrbToSetupModItemEUTRAN!\n");
                return ERROR;
            }
            noofUPParameters++;

            pERABInfo->x2uDlInfo.fNeedModify = 0;
        }
        else
        {
            VCCB_PRINT_ERROR("Missing mandatory parameters: MeNB DL GTP Tunnel Endpoint at MCG!\n");
            return ERROR;
        }

        if (noofUPParameters)
        {
            drbToSetupModItem->bit_mask |= E1_DRB_To_Setup_Mod_Item_EUTRAN_dL_UP_Parameters_present;
            // Connect UP Parameters List
            if (ERROR ==
                VCCB_ConnectLinkedList(ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber], noofUPParameters))
            {
                VCCB_PRINT_ERROR(
                    "ERROR: VCCB_ConnectLinkedList failed in VEIL_fillE1_DrbToModifyItem_dlUpParameters!\n");

                return ERROR;
            }

            drbToSetupModItem->dL_UP_Parameters = ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber];
        }
    }

    // DRB DL traffic status configuration.
    if (FALSE == ptCi->trafficMonitoringCfg.trafficReportDrbList[erabIdx].isSameCfgFlag)
    {
        bool isExtensionPresent = drbToSetupModItem->bit_mask & E1_DRB_To_Setup_Mod_Item_EUTRAN_iE_Extensions_present;

        status = FnVCCB_FillE1_ReportConfigList(ptCi, erabIdx,
            ptBearerModificationRequestBuffer->dlTrafficStatusReportEutran[DRBnumber], isExtensionPresent,
            drbToSetupModItem->iE_Extensions);
        VCCB_RETURN_ON_CALL_ERROR(
            ptCi, status, "[TRF MEAS] Failed to fill Eutran DL traffic status report configuration.\n");

        if (GOOD == status)
        {
            drbToSetupModItem->bit_mask |= E1_DRB_To_Setup_Mod_Item_EUTRAN_iE_Extensions_present;
        }
    }

    return GOOD;
}

/**
 * @brief fill E1 DRB To Modify Item EUTRAN for Beaerer Context Modification Request DlUpParameters IE
 * @attention function sets dL_UP_Parameters in mask
 * @param [in]  ptBearerModificationRequestBuffer   : E1_BearerContextModificationRequestBuffer buffer
 * @param [in]  pERABInfo                           : callERABInfo DB
 * @param [in]  DRBnumber                           : number of DRB item
 * @param [out] drbToModifyItem                     : E1_DRB_To_Modify_Item_EUTRAN buffer
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_fillE1_DrbToModifyItem_dlUpParameters(E1_DRB_To_Modify_Item_EUTRAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, callERABInfo_type *pERABInfo,
    int DRBnumber)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(DRBnumber, MAX_ERAB_PER_CALL);

    int noofUPParameters = 0;

    // DL UP Parameters Fill - optional
    if (1 == pERABInfo->f1uDlInfo.fNeedModify)
    {
        if (ERROR == VEIL_fillE1_DrbToSetupModifyItem_Common(
                         ptBearerModificationRequestBuffer, pERABInfo, DRBnumber, noofUPParameters, CellGroupId_SCG))
        {
            VCCB_PRINT_ERROR(
                "VEIL_fillE1_DrbToSetupModifyItem_Common ERROR in VEIL_fillE1_DrbToModifyItem_dlUpParameters!\n");
            return ERROR;
        }
        noofUPParameters++;

        pERABInfo->f1uDlInfo.fNeedModify = 0;
    }

    if (1 == pERABInfo->x2uDlInfo.fNeedModify)
    {
        if (ERROR == VEIL_fillE1_DrbToSetupModifyItem_Common(
                         ptBearerModificationRequestBuffer, pERABInfo, DRBnumber, noofUPParameters, CellGroupId_MCG))
        {
            VCCB_PRINT_ERROR(
                "VEIL_fillE1_DrbToSetupModifyItem_Common ERROR in VEIL_fillE1_DrbToModifyItem_dlUpParameters!\n");
            return ERROR;
        }
        noofUPParameters++;

        pERABInfo->x2uDlInfo.fNeedModify = 0;
    }

    if (noofUPParameters)
    {
        drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_EUTRAN_dL_UP_Parameters_present;
        // Connect UP Parameters List
        if (ERROR ==
            VCCB_ConnectLinkedList(ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber], noofUPParameters))
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in VEIL_fillE1_DrbToModifyItem_dlUpParameters!\n");

            return ERROR;
        }

        drbToModifyItem->dL_UP_Parameters = ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber];
    }
    return GOOD;
}

/**
 * @brief fill E1 DRB To Modify Item EUTRAN for Bearer Context Modification Request dRB_Inactivity_Timer IE
 * @attention function sets E1_DRB_To_Modify_Item_EUTRAN_dRB_Inactivity_Timer_present in mask
 * @param [in]  ptBearerModificationRequestBuffer   : E1_BearerContextModificationRequestBuffer buffer
 * @param [in]  pERABInfo                           : callERABInfo DB
 * @param [in]  ptCi                                : callInfo DB
 * @param [out] drbToModifyItem                     : E1_DRB_To_Modify_Item_EUTRAN buffer
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_fillE1_DrbToModifyItem_drbInactivityTimer(E1_DRB_To_Modify_Item_EUTRAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, callERABInfo_type *pERABInfo,
    callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    // DRB Inactivity Timer Fill - Optional
    // 22B_UserInactivity_FR214 Start
    if (GOOD == FnVCCB_FillNsaDrbInactivityTimerValue(ptCi, &drbToModifyItem->dRB_Inactivity_Timer, pERABInfo))
    {
        drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_EUTRAN_dRB_Inactivity_Timer_present;
    }
    // 22B_UserInactivity_FR214 End

    return GOOD;
}

/**
 * @brief fill E1 DRB To Modify Item EUTRAN for Bearer Context Modification Request after F1 UE Context Setup Response
 * @attention function sets all bit_mask besides dlUpParameters IE
 * @param [in]  ptBearerModificationRequestBuffer   : E1_BearerContextModificationRequestBuffer buffer
 * @param [in]  ptCi                                : callInfo DB
 * @param [in]  pERABInfo                           : callERABInfo DB
 * @param [in]  DRBnumber                           : number of DRB item
 * @param [out] drbToModifyItem                     : E1_DRB_To_Modify_Item_EUTRAN buffer
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_fillE1_DrbToModifyItemEUTRAN_Add(E1_DRB_To_Modify_Item_EUTRAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, callInfo_type *ptCi,
    callERABInfo_type *pERABInfo, int DRBnumber)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    int status = GOOD;

    drbToModifyItem->bit_mask = 0;

    // DRB ID Fill - mandatory
    drbToModifyItem->dRB_ID = pERABInfo->dRBId;

    // DL UP Parameters Fill - optional
    status = VEIL_fillE1_DrbToModifyItem_dlUpParameters(
        drbToModifyItem, ptBearerModificationRequestBuffer, pERABInfo, DRBnumber);
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, status, "VEIL_fillE1_DrbToModifyItem_dlUpParameters ERROR in VEIL_fillE1_DrbToModifyItemEUTRAN_Add!\n");

    status = VEIL_fillE1_DrbToModifyItem_drbInactivityTimer(
        drbToModifyItem, ptBearerModificationRequestBuffer, pERABInfo, ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status,
        "VEIL_fillE1_DrbToModifyItem_drbInactivityTimer ERROR in VEIL_fillE1_DrbToModifyItemEUTRAN_Add!\n");

    return GOOD;
}

/**
 * @brief fill E1 DRB To Modify Item EUTRAN for Bearer Context Modification Request after X2 SN Status Transfer
 * @attention function sets all bit_mask
 * @param [in]  ptCi            : callInfo DB
 * @param [in]  pERABInfo       : callERABInfo DB
 * @param [out] drbToModifyItem : E1_DRB_To_Modify_Item_EUTRAN buffer
 * @return      GOOD            : success fill
 * @return      ERROR           : fill error
 */
int VEIL_fillE1_DrbToModifyItemEUTRAN_SnStatus(E1_DRB_To_Modify_Item_EUTRAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, callInfo_type *ptCi,
    callERABInfo_type *pERABInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    drbToModifyItem->bit_mask = 0;

    // DRB ID Fill - mandatory
    drbToModifyItem->dRB_ID = pERABInfo->dRBId;

    // Initialize PDCP SN
    if (pERABInfo->snStatus.pdcpVersionChangeInd)
    {
        pERABInfo->snStatus.ulSN = 0;   // pdcp sn  initialize
        pERABInfo->snStatus.ulHFN = 0;  // pdcp HFN initialize

        pERABInfo->snStatus.dlSN = 0;   // pdcp sn  initialize
        pERABInfo->snStatus.dlHFN = 0;  // pdcp HFN initialize
    }

    // PDCP SN Status Information Fill - optional
    drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_EUTRAN_pDCP_SN_Status_Information_present;
    drbToModifyItem->pDCP_SN_Status_Information.bit_mask = 0;
    drbToModifyItem->pDCP_SN_Status_Information.pdcpStatusTransfer_UL.bit_mask = 0;
    drbToModifyItem->pDCP_SN_Status_Information.pdcpStatusTransfer_UL.countValue.bit_mask = 0;
    drbToModifyItem->pDCP_SN_Status_Information.pdcpStatusTransfer_UL.countValue.pDCP_SN = pERABInfo->snStatus.ulSN;
    drbToModifyItem->pDCP_SN_Status_Information.pdcpStatusTransfer_UL.countValue.hFN = pERABInfo->snStatus.ulHFN;
    drbToModifyItem->pDCP_SN_Status_Information.pdcpStatusTransfer_DL.bit_mask = 0;
    drbToModifyItem->pDCP_SN_Status_Information.pdcpStatusTransfer_DL.pDCP_SN = pERABInfo->snStatus.dlSN;
    drbToModifyItem->pDCP_SN_Status_Information.pdcpStatusTransfer_DL.hFN = pERABInfo->snStatus.dlHFN;

    // SAMSUNG SPECIFIC IE : TBD.
    if (pERABInfo->snStatus.pdcpVersionChangeInd && pERABInfo->erabIdx < MAX_ERAB_PER_CALL)
    {  // If PDCP Version Change is detected.
        E1_PDCP_VersionChangeInd *pPdcpVersionChangeInd =
            &ptBearerModificationRequestBuffer->pdcpVersionChangeInd[pERABInfo->erabIdx];
        *pPdcpVersionChangeInd = E1_PDCP_VersionChangeInd_true;

        drbToModifyItem->pDCP_SN_Status_Information.bit_mask |= E1_PDCP_SN_Status_Information_iE_Extension_present;
        drbToModifyItem->pDCP_SN_Status_Information.iE_Extension =
            &ptBearerModificationRequestBuffer->pdcpSnStatusInfoExt[pERABInfo->erabIdx];
        drbToModifyItem->pDCP_SN_Status_Information.iE_Extension->next = NULL;
        drbToModifyItem->pDCP_SN_Status_Information.iE_Extension->value.id = E1_id_PDCP_VersionChangeInd;
        drbToModifyItem->pDCP_SN_Status_Information.iE_Extension->value.criticality = E1_ignore;
        drbToModifyItem->pDCP_SN_Status_Information.iE_Extension->value.extensionValue.pduNum =
            E1_PDCP_VersionChangeInd_PDU;
        drbToModifyItem->pDCP_SN_Status_Information.iE_Extension->value.extensionValue.length = 0;
        drbToModifyItem->pDCP_SN_Status_Information.iE_Extension->value.extensionValue.encoded = NULL;
        drbToModifyItem->pDCP_SN_Status_Information.iE_Extension->value.extensionValue.decoded =
            (void *)pPdcpVersionChangeInd;
    }

    pERABInfo->snStatus.needSendFlag = FLAG_OFF;

    int status = VEIL_fillE1_DrbToModifyItem_drbInactivityTimer(
        drbToModifyItem, ptBearerModificationRequestBuffer, pERABInfo, ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status,
        "VEIL_fillE1_DrbToModifyItem_drbInactivityTimer ERROR in VEIL_fillE1_DrbToModifyItemEUTRAN_SnStatus!\n");

    return GOOD;
}

/**
 * @brief fill E1 DRB To Modify Item EUTRAN for Bearer Context Modification Request
 * @param [in]  ptCi            : callInfo DB
 * @param [in]  pERABInfo       : callERABInfo DB
 * @param [out] drbToModifyItem : E1_DRB_To_Modify_Item_EUTRAN buffer
 * @return      GOOD            : success fill
 * @return      ERROR           : fill error
 */
int VEIL_fillE1_DrbToModifyItemEUTRAN_DesiredActivityNotification(E1_DRB_To_Modify_Item_EUTRAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, callInfo_type *ptCi,
    callERABInfo_type *pERABInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);

    drbToModifyItem->bit_mask = 0;

    // DRB ID Fill - mandatory
    drbToModifyItem->dRB_ID = pERABInfo->dRBId;

    int status = VEIL_fillE1_DrbToModifyItem_drbInactivityTimer(
        drbToModifyItem, ptBearerModificationRequestBuffer, pERABInfo, ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status,
        "VEIL_fillE1_DrbToModifyItem_drbInactivityTimer ERROR in "
        "VEIL_fillE1_DrbToModifyItemEUTRAN_DesiredActivityNotification!\n");

    return GOOD;
}

/**
 * @brief fill E1 DRB To Modify Item EUTRAN for Bearer Context Modification Request
 * @attention function sets all bit_mask
 * @param [in]  ptBearerModificationRequestBuffer   : E1_BearerContextModificationRequestBuffer buffer
 * @param [in]  pERABInfo                           : callERABInfo DB
 * @param [in]  DRBnumber                           : number of DRB item
 * @param [out] drbToModifyItem                     : E1_DRB_To_Modify_Item_EUTRAN buffer
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_fillE1_DrbToModifyItemEUTRAN_ULPathSwitch(E1_DRB_To_Modify_Item_EUTRAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, callInfo_type *ptCi,
    callERABInfo_type *pERABInfo, int DRBnumber)
{
    AUTO_TRACE_FUNC;

    int cellGroupListNum = 0;
    uint8_t dataSplitThreshold = 0;

    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(DRBnumber, MAX_ERAB_PER_CALL);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);

    drbToModifyItem->bit_mask = 0;

    // DRB ID Fill - mandatory
    drbToModifyItem->dRB_ID = pERABInfo->dRBId;

    dataSplitThreshold = FnVCCB_GetUlDataSplitThreshold(ptCi, pERABInfo);

    // Cell Group To Modify Fill - optional
    if (SPLIT_Bearer == pERABInfo->bearerType)
    {
        if (VCCB_FLAG_ON == DBG->flag.logUlPathControl)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "DRBModMake DRBnumber %u ulPdcpPath %u \n",
                DRBnumber, pERABInfo->ulPdcpPath);
        }
        
        if ((UlPdcpPath_ScgOnly == pERABInfo->ulPdcpPath) || (UlPdcpPath_ScgShared == pERABInfo->ulPdcpPath))
        {
            // MCG Bearer
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask =
                E1_Cell_Group_Information_Item_uL_Configuration_present;
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.cell_Group_ID =
                CellGroupId_MCG;

            if ((TRUE == ptCi->ueInfo.ueCapa.mrdc.tddCapaAdd.general.splitDRB_withUL_Both_MCG_SCG) &&
                ((dataSplitThreshold != NRRRC_UL_DataSplitThreshold_infinity) &&
                    (UlPdcpPath_ScgShared == pERABInfo->ulPdcpPath) &&
                    (FALSE == FnVCCB_PacketInspectionONQciBasedUlSplitThSwitchOFF(ptCi))))
            {
                ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum]
                    .value.uL_Configuration = E1_shared;
            }
            else
            {
                ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum]
                    .value.uL_Configuration = E1_no_data;
            }
            cellGroupListNum++;  // 1

            // SCG Bearer
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask =
                E1_Cell_Group_Information_Item_uL_Configuration_present;
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.cell_Group_ID =
                CellGroupId_SCG;
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.uL_Configuration =
                E1_only;
            cellGroupListNum++;  // 2
        }
        else if ((UlPdcpPath_McgOnly == pERABInfo->ulPdcpPath) || (UlPdcpPath_McgShared == pERABInfo->ulPdcpPath))
        {
            // MCG Bearer
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask =
                E1_Cell_Group_Information_Item_uL_Configuration_present;
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.cell_Group_ID =
                CellGroupId_MCG;
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.uL_Configuration =
                E1_only;
            cellGroupListNum++;  // 1

            // SCG Bearer
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask =
                E1_Cell_Group_Information_Item_uL_Configuration_present;
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.cell_Group_ID =
                CellGroupId_SCG;

            if ((TRUE == ptCi->ueInfo.ueCapa.mrdc.tddCapaAdd.general.splitDRB_withUL_Both_MCG_SCG) &&
                (dataSplitThreshold != NRRRC_UL_DataSplitThreshold_infinity) &&
                (UlPdcpPath_McgShared == pERABInfo->ulPdcpPath))
            {
                ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum]
                    .value.uL_Configuration = E1_shared;
            }
            else
            {
                ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum]
                    .value.uL_Configuration = E1_no_data;
            }
            cellGroupListNum++;  // 2
        }

        // Cell Group ID "3" is used for notifying A6G Cell to UP between Samsung gNB-CU-CP and gNB-CU-UP. (0: MCG,
        // 1:SCG, 2,3: Not Used in SPEC) This field should be filled when dL_TX_Stop(stop, resume) IE is sent to UP.
        if (CELLINFO[ptCi->servCellNum].nrArfcnDl >= MIN_A6_NR_ARFCN)  // A6G CASE
        {
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask =
                0;  // cell_Group_ID used only.
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.cell_Group_ID =
                CellGroupId_ForNotifyingA6G;
            cellGroupListNum++;  // 3
        }

        if (0==ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][0].value.bit_mask)
        {
            drbToModifyItem->bit_mask = 0;
            return GOOD;
        }

        if (ERROR ==
            VCCB_ConnectLinkedList(ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber], cellGroupListNum))
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "ERROR: VCCB_ConnectLinkedList failed in "
                "VEIL_fillE1_DrbToModifyItemEUTRAN_ULPathSwitch->Cell Group To Modify!\n");

            return ERROR;
        }
    }
    else
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Doesn't support Primary Path Switch in case of BearerType(%u)\n", pERABInfo->bearerType);
        return GOOD;
    }

    // Connect Cell Group To Modify List
    drbToModifyItem->cell_Group_To_Modify = ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber];
    drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_EUTRAN_cell_Group_To_Modify_present;

    return GOOD;
}

/**
 * @brief fill E1 DRB To Modify Item EUTRAN for Bearer Context Modification Request after SCG Failure information
 * @attention function sets all bit_mask
 * @param [in]  ptBearerModificationRequestBuffer   : E1_BearerContextModificationRequestBuffer buffer
 * @param [in]  pERABInfo                           : callERABInfo DB
 * @param [in]  DRBnumber                           : number of DRB item
 * @param [out] drbToModifyItem                     : E1_DRB_To_Modify_Item_EUTRAN buffer
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_fillE1_DrbToModifyItemEUTRAN_SCGFailure_ULPathSwitch(E1_DRB_To_Modify_Item_EUTRAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, callInfo_type *ptCi,
    callERABInfo_type *pERABInfo, int DRBnumber)
{
    AUTO_TRACE_FUNC;

    int cellGroupListNum = 0;

    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(DRBnumber, MAX_ERAB_PER_CALL);

    drbToModifyItem->bit_mask = 0;

    // DRB ID Fill - mandatory
    drbToModifyItem->dRB_ID = pERABInfo->dRBId;

    // Cell Group To Modify Fill - optional
    if (SPLIT_Bearer == pERABInfo->bearerType)
    {
        // MCG Bearer
        if (!((UlPdcpPath_McgOnly == pERABInfo->ulPdcpPath) && (VCCB_FLAG_ON == ptCi->scgSuspendStateForMeas)))
        {
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask =
                E1_Cell_Group_Information_Item_uL_Configuration_present;
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.cell_Group_ID =
                CellGroupId_MCG;
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.uL_Configuration =
                E1_only;
            cellGroupListNum++;  // 1
        }

        // SCG Bearer
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask =
            E1_dL_TX_Stop_present;
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.cell_Group_ID =
            CellGroupId_SCG;
        if (!((UlPdcpPath_McgOnly == pERABInfo->ulPdcpPath) && (VCCB_FLAG_ON == ptCi->scgSuspendStateForMeas)))
        {
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask |=
                E1_Cell_Group_Information_Item_uL_Configuration_present;
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.uL_Configuration =
                E1_no_data;
        }
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.dL_TX_Stop =
            E1_DL_TX_Stop_stop;
        cellGroupListNum++;  // 2

        // Cell Group ID "3" is used for notifying A6G Cell to UP between Samsung gNB-CU-CP and gNB-CU-UP. (0: MCG,
        // 1:SCG, 2,3: Not Used in SPEC) This field should be filled when dL_TX_Stop(stop, resume) IE is sent to UP.
        if (CELLINFO[ptCi->servCellNum].nrArfcnDl >= MIN_A6_NR_ARFCN)  // A6G CASE
        {
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask =
                0;  // cell_Group_ID used only.
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.cell_Group_ID =
                CellGroupId_ForNotifyingA6G;
            cellGroupListNum++;  // 3
        }

        if (ERROR ==
            VCCB_ConnectLinkedList(ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber], cellGroupListNum))
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "ERROR: VCCB_ConnectLinkedList failed in "
                "VEIL_fillE1_DrbToModifyItemEUTRAN_SCGFailure_ULPathSwitch->Cell Group To Modify!\n");

            return ERROR;
        }
    }
    else if (SCG_Bearer == pERABInfo->bearerType)
    {
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask =
            E1_dL_TX_Stop_present;
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.cell_Group_ID =
            CellGroupId_SCG;
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.dL_TX_Stop =
            E1_DL_TX_Stop_stop;
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].next = nullptr;
        cellGroupListNum++;  // 1

        // Cell Group ID "3" is used for notifying A6G Cell to UP between Samsung gNB-CU-CP and gNB-CU-UP. (0: MCG,
        // 1:SCG, 2,3: Not Used in SPEC) This field should be filled when dL_TX_Stop(stop, resume) IE is sent to UP.
        if (CELLINFO[ptCi->servCellNum].nrArfcnDl >= MIN_A6_NR_ARFCN)  // A6G CASE
        {
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.bit_mask =
                0;  // cell_Group_ID used only.
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNum].value.cell_Group_ID =
                CellGroupId_ForNotifyingA6G;
            cellGroupListNum++;  // 2

            // Connect Cell Group Information List
            if (ERROR == VCCB_ConnectLinkedList(
                             ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber], cellGroupListNum))
            {
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "ERROR: VCCB_ConnectLinkedList failed in VEIL_fillE1_CellGroupToModifySetTxStatus\n");

                return ERROR;
            }
        }
    }

    // Connect Cell Group To Modify List
    drbToModifyItem->cell_Group_To_Modify = ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber];
    drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_EUTRAN_cell_Group_To_Modify_present;

    {
        int status = GOOD;
        status = VEIL_fillE1_DrbToModifyItem_drbInactivityTimer(
            drbToModifyItem, ptBearerModificationRequestBuffer, pERABInfo, ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status,
            "VEIL_fillE1_DrbToModifyItem_drbInactivityTimer ERROR in "
            "VEIL_fillE1_DrbToModifyItemEUTRAN_SCGFailure_ULPathSwitch!\n");
    }

    return GOOD;
}

/**
 * @brief fill E1 DRB To Modify Item EUTRAN for Bearer Context Modification Request - SgNB Release
 * @attention   set bit_mask before or inside called function - this function does not set needed bit_mask themselves
 * @param [in]  ptBearerModificationRequestBuffer   : E1_BearerContextModificationRequestBuffer buffer
 * @param [in]  pERABInfo                           : callERABInfo DB
 * @param [in]  DRBnumber                           : number of DRB item
 * @param [out] drbToModifyItem                     : E1_DRB_To_Modify_Item_EUTRAN buffer
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_fillE1_DrbToModifyItemEUTRAN_Release(E1_DRB_To_Modify_Item_EUTRAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, callInfo_type *ptCi,
    callERABInfo_type *pERABInfo, int DRBnumber)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);

    int status = GOOD;
    rbPdcpSdapConfig_type *pRbInfo = &(pERABInfo->rbInfo);

    // DRB ID Fill - mandatory
    drbToModifyItem->dRB_ID = pERABInfo->dRBId;

    // Send First E1 Bearer Modification Request for dL_TX_Stop
    if (STATE_DCSNRelRqrd == ptCi->state || STATE_DCSnChg_Prep == ptCi->state ||
        (SgNBReleaseRequest_cmd == ptCi->stateCmd && STATE_DB2DBRF1Mod != ptCi->state &&
            TRUE != ptCi->bitFlag.isE1TxStopRequested))
    {
        // Cell Group To Modify - optional (bitmasks set inside the VEIL_fillE1_CellGroupToModifySetTxStatus function)
        status = VEIL_fillE1_CellGroupToModifySetTxStatus(
            E1_DL_TX_Stop_stop, drbToModifyItem, ptBearerModificationRequestBuffer, ptCi, pERABInfo, DRBnumber);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_CellGroupToModifySetTxStatus ERROR!\n");
    }

    // Send Second E1 Bearer Modification Request for SN Status Tranfsfer
    if (STATE_DB2DBRF1Mod == ptCi->state || STATE_DCSnChg_F1TxStop == ptCi->state ||
        (STATE_DB2DBRenb == ptCi->state && FLAG_ON == pERABInfo->snStatus.needRequestFlag))
    {
        // Data Forwarding Information Response - optional
        if (1 == pERABInfo->x2uForwardUlInfo.fNeedModify || 1 == pERABInfo->x2uForwardDlInfo.fNeedModify)
        {
            drbToModifyItem->bit_mask |= E1_data_Forwarding_Information_present;
            drbToModifyItem->data_Forwarding_Information.bit_mask = 0;
        }

        if (1 == pERABInfo->x2uForwardUlInfo.fNeedModify)
        {
            drbToModifyItem->data_Forwarding_Information.bit_mask |= E1_uL_Data_Forwarding_present;
            status = VEIL_fillE1_UP_TNL_Information(
                &drbToModifyItem->data_Forwarding_Information.uL_Data_Forwarding, &pERABInfo->x2uForwardUlInfo);
            VCCB_RETURN_ON_CALL_ERROR(
                ptCi, status, "VEIL_fillE1_UP_TNL_Information ERROR in VEIL_fillE1_DrbToModifyItemEUTRAN_Release!\n");

            pERABInfo->x2uForwardUlInfo.fNeedModify = 0;
        }

        if (1 == pERABInfo->x2uForwardDlInfo.fNeedModify)
        {
            drbToModifyItem->data_Forwarding_Information.bit_mask |= E1_dL_Data_Forwarding_present;
            status = VEIL_fillE1_UP_TNL_Information(
                &drbToModifyItem->data_Forwarding_Information.dL_Data_Forwarding, &pERABInfo->x2uForwardDlInfo);
            VCCB_RETURN_ON_CALL_ERROR(
                ptCi, status, "VEIL_fillE1_UP_TNL_Information ERROR in VEIL_fillE1_DrbToModifyItemEUTRAN_Release!\n");

            pERABInfo->x2uForwardDlInfo.fNeedModify = 0;
        }

        // PDCP SN Status Request - optional
        if (AM_RLC == pRbInfo->rlcMode)
        {
            drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_EUTRAN_pDCP_SN_Status_Request_present;
            drbToModifyItem->pDCP_SN_Status_Request = E1_requested;
            pERABInfo->snStatus.needRequestFlag = FLAG_OFF;
        }
    }

    return GOOD;
}

/**
 * @brief fill E1 DRB To Modify Item EUTRAN for Bearer Context Modification Request - Inter/Intra HO
 * @attention   required correct bit_mask in drbToModifyItem
 * @param [in]  ptBearerModificationRequestBuffer   : E1_BearerContextModificationRequestBuffer buffer
 * @param [in]  pERABInfo                           : callERABInfo DB
 * @param [in]  DRBnumber                           : number of DRB item
 * @param [out] drbToModifyItem                     : E1_DRB_To_Modify_Item_EUTRAN buffer
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_fillE1_DrbToModifyItemEUTRAN_F1UDL(E1_DRB_To_Modify_Item_EUTRAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, callERABInfo_type *pERABInfo,
    int DRBnumber)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(DRBnumber, MAX_ERAB_PER_CALL);

    int noofUPParameters = 0;

    // DRB ID Fill - mandatory
    drbToModifyItem->dRB_ID = pERABInfo->dRBId;

    // DL UP Parameters Fill - optional
    if (1 == pERABInfo->f1uDlInfo.fNeedModify)
    {
        if (ERROR == VEIL_fillE1_DrbToSetupModifyItem_Common(
                         ptBearerModificationRequestBuffer, pERABInfo, DRBnumber, noofUPParameters, CellGroupId_SCG))
        {
            VCCB_PRINT_ERROR(
                "VEIL_fillE1_DrbToSetupModifyItem_Common ERROR in VEIL_fillE1_DrbToModifyItemEUTRAN_F1UDL!\n");
            return ERROR;
        }
        noofUPParameters++;

        pERABInfo->f1uDlInfo.fNeedModify = 0;
    }

    if (noofUPParameters)
    {
        drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_EUTRAN_dL_UP_Parameters_present;
        // Connect UP Parameters List
        if (ERROR ==
            VCCB_ConnectLinkedList(ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber], noofUPParameters))
        {
            VCCB_PRINT_ERROR(
                "ERROR: VCCB_ConnectLinkedList failed in VEIL_fillE1_DrbToSetupModifyItem_Common->DL UP Parameters!\n");

            return ERROR;
        }

        drbToModifyItem->dL_UP_Parameters = ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber];
    }

    return GOOD;
}

/**
 * @brief fill E1 DRB To Modify Item EUTRAN for Bearer Context Modification Request
 *        send OLD DL Tunnel information to UP for EN-DC Inter-DU Handover rollback operation
 * @attention   required correct bit_mask in drbToModifyItem
 * @param [in]  ptCi                                : call context
 * @param [in]  ptBearerModificationRequestBuffer   : E1_BearerContextModificationRequestBuffer buffer
 * @param [in]  pERABInfo                           : callERABInfo DB
 * @param [in]  DRBnumber                           : number of DRB item
 * @param [out] drbToModifyItem                     : E1_DRB_To_Modify_Item_EUTRAN buffer
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_fillE1_DrbToModifyItemEUTRAN_OldDlTunnel(callInfo_type *ptCi, E1_DRB_To_Modify_Item_EUTRAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, callERABInfo_type *pERABInfo,
    int DRBnumber)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(DRBnumber, MAX_ERAB_PER_CALL);

    int noofUPParameters = 0;
    int status = GOOD;

    // DRB ID Fill - mandatory
    drbToModifyItem->dRB_ID = pERABInfo->dRBId;

    // DL UP Parameters Fill - optional
    if (TRUE == pERABInfo->f1uDlInfoPrev.fNeedModify)
    {
        ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber][noofUPParameters].value.bit_mask = 0;
        ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber][noofUPParameters].value.cell_Group_ID =
            CellGroupId_SCG;
        status = VEIL_fillE1_UP_TNL_Information(
            &ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber][noofUPParameters].value.uP_TNL_Information,
            &pERABInfo->f1uDlInfoPrev);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_UP_TNL_Information ERROR!\n");

        noofUPParameters++;

        pERABInfo->f1uDlInfoPrev.fNeedModify = FALSE;
    }

    if (noofUPParameters)
    {
        drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_EUTRAN_dL_UP_Parameters_present;
        // Connect UP Parameters List
        if (ERROR ==
            VCCB_ConnectLinkedList(ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber], noofUPParameters))
        {
            VCCB_PRINT_ERROR(
                "ERROR: VCCB_ConnectLinkedList failed in VEIL_fillE1_DrbToSetupModifyItem_Common->DL UP Parameters!\n");

            return ERROR;
        }

        drbToModifyItem->dL_UP_Parameters = ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber];
    }

    return GOOD;
}

/**
 * @brief fill E1 DRB To Modify Item EUTRAN - X2UDL for Bearer Context Modification Request - Inter-MeNB HO Intra-gNB-DU
 * @attention required correct bit_mask in drbToModifyItem
 * @param [in]  ptBearerModificationRequestBuffer   : E1_BearerContextModificationRequestBuffer buffer
 * @param [in]  pERABInfo                           : callERABInfo DB
 * @param [in]  DRBnumber                           : number of DRB item
 * @param [out] drbToModifyItem                     : E1_DRB_To_Modify_Item_EUTRAN buffer
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_fillE1_DrbToModifyItemEUTRAN_X2UDL(E1_DRB_To_Modify_Item_EUTRAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, callERABInfo_type *pERABInfo,
    int DRBnumber)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);

    VCCB_CHECK_E_RANGE_AND_RETURN(DRBnumber, MAX_ERAB_PER_CALL);

    int noofUPParameters = 0, status = GOOD;

    // DL UP Parameters Fill - optional
    if (1 == pERABInfo->x2uDlInfo.fNeedModify)
    {
        ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber][noofUPParameters].value.bit_mask = 0;
        ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber][noofUPParameters].value.cell_Group_ID =
            CellGroupId_MCG;
        status = VEIL_fillE1_UP_TNL_Information(
            &ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber][noofUPParameters].value.uP_TNL_Information,
            &pERABInfo->x2uDlInfo);
        if (ERROR == status)
        {
            VCCB_PRINT_ERROR("VEIL_fillE1_UP_TNL_Information ERROR in VEIL_fillE1_DrbToModifyItemEUTRAN_X2UDL!\n");

            return ERROR;
        }
        noofUPParameters++;

        pERABInfo->x2uDlInfo.fNeedModify = 0;
    }

    if (noofUPParameters)
    {
        drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_EUTRAN_dL_UP_Parameters_present;
        // Connect UP Parameters List
        if (ERROR ==
            VCCB_ConnectLinkedList(ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber], noofUPParameters))
        {
            VCCB_PRINT_ERROR(
                "ERROR: VCCB_ConnectLinkedList failed in VEIL_fillE1_DrbToModifyItemEUTRAN_X2UDL->DL UP Parameters!\n");

            return ERROR;
        }

        drbToModifyItem->dL_UP_Parameters = ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber];
    }

    return GOOD;
}

/**
 * @brief fill E1 DRB To Modify Item EUTRAN - X2UDL and F1UDL for Bearer Context Modification Request - Inter-MeNB HO
 * Inter-gNB-DU
 * @attention required correct bit_mask in drbToModifyItem
 * @param [in]  ptBearerModificationRequestBuffer   : E1_BearerContextModificationRequestBuffer buffer
 * @param [in]  ptCi                                : callInfo DB
 * @param [in]  pERABInfo                           : callERABInfo DB
 * @param [in]  DRBnumber                           : number of DRB item
 * @param [out] drbToModifyItem                     : E1_DRB_To_Modify_Item_EUTRAN buffer
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_fillE1_DrbToModifyItemEUTRAN_F1UDLX2UDL(E1_DRB_To_Modify_Item_EUTRAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, callERABInfo_type *pERABInfo,
    int DRBnumber)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);

    VCCB_CHECK_E_RANGE_AND_RETURN(DRBnumber, MAX_ERAB_PER_CALL);

    int noofUPParameters = 0;

    // DRB ID Fill - mandatory
    drbToModifyItem->dRB_ID = pERABInfo->dRBId;

    // DL UP Parameters Fill - optional
    if (1 == pERABInfo->f1uDlInfo.fNeedModify)
    {
        if (ERROR == VEIL_fillE1_DrbToSetupModifyItem_Common(
                         ptBearerModificationRequestBuffer, pERABInfo, DRBnumber, noofUPParameters, CellGroupId_SCG))
        {
            VCCB_PRINT_ERROR(
                "VEIL_fillE1_DrbToSetupModifyItem_Common ERROR in VEIL_fillE1_DrbToModifyItemEUTRAN_F1UDLX2UDL!\n");
            return ERROR;
        }
        noofUPParameters++;

        pERABInfo->f1uDlInfo.fNeedModify = 0;
    }

    if (1 == pERABInfo->x2uDlInfo.fNeedModify)
    {
        if (ERROR == VEIL_fillE1_DrbToSetupModifyItem_Common(
                         ptBearerModificationRequestBuffer, pERABInfo, DRBnumber, noofUPParameters, CellGroupId_MCG))
        {
            VCCB_PRINT_ERROR(
                "VEIL_fillE1_DrbToSetupModifyItem_Common ERROR in VEIL_fillE1_DrbToModifyItemEUTRAN_F1UDLX2UDL!\n");
            return ERROR;
        }
        noofUPParameters++;

        pERABInfo->x2uDlInfo.fNeedModify = 0;
    }

    if (noofUPParameters)
    {
        drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_EUTRAN_dL_UP_Parameters_present;
        // Connect UP Parameters List
        if (ERROR ==
            VCCB_ConnectLinkedList(ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber], noofUPParameters))
        {
            VCCB_PRINT_ERROR(
                "ERROR: VCCB_ConnectLinkedList failed in VEIL_fillE1_DrbToModifyItemEUTRAN_F1UDLX2UDL->DL UP "
                "Parameters!\n");

            return ERROR;
        }

        drbToModifyItem->dL_UP_Parameters = ptBearerModificationRequestBuffer->dlUpParameters[DRBnumber];
    }

    return GOOD;
}

/**
 * @brief fill E1 DRB To Modify Item EUTRAN for Bearer Context Modification Request - Change S1U tunnel
 * @param [in]  pERABInfo                           : callERABInfo DB
 * @param [in]  ptCi                                : callInfo DB
 * @param [out] drbToModifyItem                     : E1_DRB_To_Modify_Item_EUTRAN buffer
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_fillE1_DrbToModifyItemS1UTunnel(
    E1_DRB_To_Modify_Item_EUTRAN *drbToModifyItem, callERABInfo_type *pERABInfo, callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);
    VALID_E_POINT_CHECK_ERROR(ptCi);

    // DRB ID Fill - mandatory
    drbToModifyItem->dRB_ID = pERABInfo->dRBId;
    // bit_mask zerod/reset in VEIL_fillE1_BearerContextMod_DrbToBeList
    // drbToModifyItem->bit_mask = 0;

    int status = GOOD;
    if (STATE_DB == ptCi->state)
    {
        // S1 UL UP Transport Layer Information
        status = VEIL_fillE1_UP_TNL_Information(&drbToModifyItem->s1_UL_UP_TNL_Information, &pERABInfo->s1uUlInfo);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_UP_TNL_Information ERROR!\n");

        drbToModifyItem->bit_mask |= E1_s1_UL_UP_TNL_Information_present;

        pERABInfo->s1uUlInfo.fNeedModify = 0;
    }
    return status;
}
/**
 * @brief fill E1 DRB To Modify Item EUTRAN for Bearer Context Modification Request - Change bearer type from SCG/MCG to
 * SPLIT
 * @attention   function sets all bit_mask besides dlUpParameters IE and drb inactivity timer flag
 * @param [in]  ptBearerModificationRequestBuffer   : E1_BearerContextModificationRequestBuffer buffer
 * @param [in]  pERABInfo                           : callERABInfo DB
 * @param [in]  DRBnumber                           : number of DRB item
 * @param [in]  ptCi                                : callInfo DB
 * @param [in]  cellGroupID                         : modification from SCG or MCG
 * @param [out] drbToModifyItem                     : E1_DRB_To_Modify_Item_EUTRAN buffer
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_fillE1_DrbToModifyItemScgMcgToSplit(E1_DRB_To_Modify_Item_EUTRAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, callERABInfo_type *pERABInfo,
    int DRBnumber, callInfo_type *ptCi, uint8_t cellGroupID)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(DRBnumber, MAX_ERAB_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    int status = GOOD;
    int cellGroupListNumAdd = 0, cellGroupListNumMod = 0;

    if (CellGroupId_MCG != cellGroupID && CellGroupId_SCG != cellGroupID)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Incorrect cellGroupId (%u) in VEIL_fillE1_DrbToModifyItemScgMcgToSplit!\n", cellGroupID);
        return ERROR;
    }

    if (ptCi->state == STATE_DB)  // only initial E1 Bearer Mod will carry change to transport tunnels
    {
        if (CellGroupId_SCG == cellGroupID && 1 != pERABInfo->x2uDlInfo.fNeedModify)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "meNB-DL-GTP-TEIDatMCG is absent - cannot switch to SPLIT !\n");
            return ERROR;
        }
        //Removed check for presence of s1_UL_UP_TNL_Information
        //Since MN Terminated bearers are not supported, this IE was always present before changing to SPLIT
    }
    uint8_t dataSplitThreshold = 0;
    dataSplitThreshold = FnVCCB_GetUlDataSplitThreshold(ptCi, pERABInfo);

    // DRB ID Fill - mandatory
    drbToModifyItem->dRB_ID = pERABInfo->dRBId;

    drbToModifyItem->bit_mask = 0;
    if (STATE_DCF1Setup_S != ptCi->state)
    {
        // PDCP Configuration Fill - optional (bitmasks set inside the fill function)
        status = VEIL_fillE1_EUTRAN_PDCP_ConfigurationInfo(&drbToModifyItem->pDCP_Configuration, ptCi, pERABInfo);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_EUTRAN_PDCP_ConfigurationInfo ERROR!\n");

        drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_EUTRAN_pDCP_Configuration_present;

        if (CellGroupId_MCG == cellGroupID)
        {
            VEIL_FILL_E1_CELL_GROUP_ADD(CellGroupId_SCG);
        }
        else
        {
            VEIL_FILL_E1_CELL_GROUP_ADD(CellGroupId_MCG);
        }
        VEIL_FILL_E1_CELL_GROUP_MOD(cellGroupID);
    }

    if ((STATE_DCF1Setup_S == ptCi->state) || (CellGroupId_SCG == cellGroupID))
    {
        status = VEIL_fillE1_DrbToModifyItem_dlUpParameters(
            drbToModifyItem, ptBearerModificationRequestBuffer, pERABInfo, DRBnumber);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status,
            "VEIL_fillE1_DrbToModifyItem_dlUpParameters ERROR in VEIL_fillE1_DrbToModifyItemScgMcgToSplit!\n");
    }
    // STATE_DB - S1 UL TNL update during SgNB modification.
    // STATE_DCInterDuHo_F1UeCtxSetReq - mCG mobility with "SN term MCG" -> "SN term Split" bearer type change.
    else if ((STATE_DB == ptCi->state) || ((STATE_DCInterDuHo_F1UeCtxSetReq == ptCi->state) && VCCB_NSA_IsInterDuNoScgHo(*ptCi)))
    {
        // S1 UL UP Transport Layer Information
        drbToModifyItem->bit_mask |= E1_s1_UL_UP_TNL_Information_present;

        status = VEIL_fillE1_UP_TNL_Information(&drbToModifyItem->s1_UL_UP_TNL_Information, &pERABInfo->s1uUlInfo);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_UP_TNL_Information ERROR!\n");

        pERABInfo->s1uUlInfo.fNeedModify = 0;
    }

    status = VEIL_fillE1_DrbToModifyItem_drbInactivityTimer(
        drbToModifyItem, ptBearerModificationRequestBuffer, pERABInfo, ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status,
        "VEIL_fillE1_DrbToModifyItem_drbInactivityTimer ERROR in VEIL_fillE1_DrbToModifyItemScgMcgToSplit!\n");

    return GOOD;
}

/**
 * @brief fill E1 DRB To Modify Item EUTRAN for Bearer Context Modification Request -
    when Split bearer changes to SCG bearer/ MCG bearer
 * @attention   function sets all bit_mask besides drb inactivity timer flag
 * @param [in]  ptBearerModificationRequestBuffer   : E1_BearerContextModificationRequestBuffer buffer
 * @param [in]  pERABInfo                           : callERABInfo DB
 * @param [in]  DRBnumber                           : number of DRB item
 * @param [in]  ptCi                                : callInfo DB
 * @param [in]  cellGroupID                         : modification to SCG or MCG
 * @param [out] drbToModifyItem                     : E1_DRB_To_Modify_Item_EUTRAN buffer
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_fillE1_DrbToModifyItemSplitToScgMcg(E1_DRB_To_Modify_Item_EUTRAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, callERABInfo_type *pERABInfo,
    int DRBnumber, callInfo_type *ptCi, uint8_t cellGroupID)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(DRBnumber, MAX_ERAB_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    int status = GOOD;
    int cellGroupListNumRem = 0, cellGroupListNumMod = 0;

    if (CellGroupId_MCG != cellGroupID && CellGroupId_SCG != cellGroupID)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Incorrect cellGroupId (%u) in VEIL_fillE1_DrbToModifyItemSplitToScgMcg!\n", cellGroupID);
        return ERROR;
    }

    uint8_t dataSplitThreshold = 0;
    dataSplitThreshold = FnVCCB_GetUlDataSplitThreshold(ptCi, pERABInfo);

    // DRB ID Fill - mandatory
    drbToModifyItem->dRB_ID = pERABInfo->dRBId;
    drbToModifyItem->bit_mask = 0;

    // PDCP Configuration Fill - optional (bitmasks set inside the fill function)
    status = VEIL_fillE1_EUTRAN_PDCP_ConfigurationInfo(&drbToModifyItem->pDCP_Configuration, ptCi, pERABInfo);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_EUTRAN_PDCP_ConfigurationInfo ERROR!\n");

    drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_EUTRAN_pDCP_Configuration_present;

    if (CellGroupId_MCG == cellGroupID)
    {
        VEIL_FILL_E1_CELL_GROUP_REMOVE(CellGroupId_SCG);
    }
    else
    {
        VEIL_FILL_E1_CELL_GROUP_REMOVE(CellGroupId_MCG);
    }

    VEIL_FILL_E1_CELL_GROUP_MOD(cellGroupID);

    status = VEIL_fillE1_DrbToModifyItem_drbInactivityTimer(
        drbToModifyItem, ptBearerModificationRequestBuffer, pERABInfo, ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status,
        "VEIL_fillE1_DrbToModifyItem_drbInactivityTimer ERROR in VEIL_fillE1_DrbToModifyItemSplitToScgMcg!\n");

    return GOOD;
}

/**
 * @brief add new MCG bearer in case of SCG to SPLIT bearer type change during HO
 * @attention function sets all bit_mask
 * @param [in]  ptBearerModificationRequestBuffer   : E1_BearerContextModificationRequestBuffer buffer
 * @param [in]  pERABInfo                           : callERABInfo DB
 * @param [in]  DRBnumber                           : number of DRB item
 * @param [out] drbToModifyItem                     : E1_DRB_To_Modify_Item_EUTRAN buffer
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_fillE1_CellGroupForBearerTypeChange(E1_DRB_To_Modify_Item_EUTRAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, callInfo_type *ptCi,
    callERABInfo_type *pERABInfo, int DRBnumber)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(DRBnumber, MAX_ERAB_PER_CALL);

    uint8_t dataSplitThreshold = 0;
    dataSplitThreshold = FnVCCB_GetUlDataSplitThreshold(ptCi, pERABInfo);

    if ((ERAB_Modify == pERABInfo->erabStatus) && (pERABInfo->preveBearerType != pERABInfo->bearerType))
    {
        if (SCG_Bearer == pERABInfo->preveBearerType && SPLIT_Bearer == pERABInfo->bearerType)
        {
            int cellGroupListNumAdd = 0;
            drbToModifyItem->dRB_ID = pERABInfo->dRBId;
            ptBearerModificationRequestBuffer->cellGroupToAdd[DRBnumber][cellGroupListNumAdd].value.bit_mask =
                E1_Cell_Group_Information_Item_uL_Configuration_present | E1_rAT_Type_present | E1_dL_TX_Stop_present;
            ptBearerModificationRequestBuffer->cellGroupToAdd[DRBnumber][cellGroupListNumAdd].value.dL_TX_Stop =
                E1_DL_TX_Stop_stop;
            VEIL_FILL_E1_CELL_GROUP_ADD(CellGroupId_MCG);

            // there is assumption that cellGroupToModify exists and there it contains SCG,
            // it was created by VEIL_fillE1_CellGroupToModifySetTxStatus which was called before this function
            if (!(drbToModifyItem->bit_mask & E1_DRB_To_Modify_Item_EUTRAN_cell_Group_To_Modify_present))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "No cell group to modify in modification request buffer!\n");
                return ERROR;
            }

            int cellGroupListNumMod = 0;
            while (MAX_NO_CELL_GROUPS > cellGroupListNumMod)
            {
                if (CellGroupId_SCG ==
                    ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod]
                        .value.cell_Group_ID)
                {
                    ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod]
                        .value.bit_mask |= E1_Cell_Group_Information_Item_uL_Configuration_present;
                    ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod]
                        .value.uL_Configuration = E1_only;
                    break;
                }
                ++cellGroupListNumMod;
            }
            if (MAX_NO_CELL_GROUPS <= cellGroupListNumMod)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "There is no SCG bearer in modification request buffer group to modify\n");
                return ERROR;
            }
        }
        else if (SPLIT_Bearer == pERABInfo->preveBearerType && SCG_Bearer == pERABInfo->bearerType)
        {
            if (E1_DRB_To_Modify_Item_EUTRAN_cell_Group_To_Remove_present ==
                (drbToModifyItem->bit_mask & E1_DRB_To_Modify_Item_EUTRAN_cell_Group_To_Remove_present))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "There are already bearers to be removed!\n");
                return ERROR;
            }
            int cellGroupListNumRem = 0;
            VEIL_FILL_E1_CELL_GROUP_REMOVE(CellGroupId_MCG);
        }
        else if (MCG_Bearer == pERABInfo->preveBearerType && SPLIT_Bearer == pERABInfo->bearerType)
        {
            VCCB_RETURN_ON_CALL_ERROR(ptCi,
                VEIL_fillE1_DrbToModifyItemScgMcgToSplit(
                    drbToModifyItem, ptBearerModificationRequestBuffer, pERABInfo, DRBnumber, ptCi, CellGroupId_MCG),
                "VEIL_fillE1_DrbToModifyItemScgMcgToSplit ERROR!\n");
        }
        else
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Wrong bearer type change!\n");
            return ERROR;
        }
    }
    return GOOD;
}

/**
 * @brief fill E1 DRB To Modify Item EUTRAN for Bearer Context Modification Request -
    send DL TX Stop = resume for Modified type bearers
 * @attention
 * @param [in]  ptBearerModificationRequestBuffer   : E1_BearerContextModificationRequestBuffer buffer
 * @param [in]  pERABInfo                           : callERABInfo DB
 * @param [in]  DRBnumber                           : number of DRB item
 * @param [in]  ptCi                                : callInfo DB
 * @param [out] drbToModifyItem                     : E1_DRB_To_Modify_Item_EUTRAN buffer
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_fillE1_DrbToModifyItemCellGroupResume(E1_DRB_To_Modify_Item_EUTRAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, callERABInfo_type *pERABInfo,
    int DRBnumber, callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(DRBnumber, MAX_ERAB_PER_CALL);

    int status = GOOD;
    int cellGroupListNumMod = 0;

    // DRB ID Fill - mandatory
    drbToModifyItem->dRB_ID = pERABInfo->dRBId;

    drbToModifyItem->bit_mask = 0;

    ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.bit_mask = 0;
    ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.bit_mask |=
        E1_dL_TX_Stop_present | E1_rAT_Type_present;

    if (SPLIT_Bearer != pERABInfo->bearerType)
    {
        if (MCG_Bearer == pERABInfo->bearerType)
        {
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.cell_Group_ID =
                CellGroupId_MCG;
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.rAT_Type =
                E1_RAT_Type_e_UTRA;
        }
        else
        {
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.cell_Group_ID =
                CellGroupId_SCG;
            ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.rAT_Type =
                E1_RAT_Type_nR;
        }
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.dL_TX_Stop =
            E1_DL_TX_Stop_resume;
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].next = nullptr;
        cellGroupListNumMod++;
    }
    else
    {
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.cell_Group_ID =
            CellGroupId_MCG;
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.rAT_Type =
            E1_RAT_Type_e_UTRA;
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.dL_TX_Stop =
            E1_DL_TX_Stop_resume;
        cellGroupListNumMod++;

        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.bit_mask = 0;
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.bit_mask |=
            E1_dL_TX_Stop_present | E1_rAT_Type_present;
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.cell_Group_ID =
            CellGroupId_SCG;
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.rAT_Type =
            E1_RAT_Type_nR;
        ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber][cellGroupListNumMod].value.dL_TX_Stop =
            E1_DL_TX_Stop_resume;
        cellGroupListNumMod++;

        VCCB_RETURN_ON_CALL_ERROR(ptCi,
            VCCB_ConnectLinkedList(
                ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber], cellGroupListNumMod),
            "ERROR: VCCB_ConnectLinkedList failed -> Cell Group List!!\n");
    }
    drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_EUTRAN_cell_Group_To_Modify_present;
    drbToModifyItem->cell_Group_To_Modify = ptBearerModificationRequestBuffer->cellGroupToModify[DRBnumber];

    status = VEIL_fillE1_DrbToModifyItem_drbInactivityTimer(
        drbToModifyItem, ptBearerModificationRequestBuffer, pERABInfo, ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status,
        "VEIL_fillE1_DrbToModifyItem_drbInactivityTimer ERROR in VEIL_fillE1_DrbToModifyItemCellGroupResume!\n");

    return GOOD;
}

/**
 * @brief fill E1 DRB To Remove Item EUTRAN
 * @attention function sets all bit_mask
 * @param [in]  pERABInfo       : callERABInfo DB
 * @param [out] drbToRemoveItem : E1_DRB_To_Remove_Item_EUTRAN buffer
 * @return      GOOD            : success fill
 * @return      ERROR           : fill error
 */
int VEIL_fillE1_DrbToRemoveItemEUTRAN(E1_DRB_To_Remove_Item_EUTRAN *drbToRemoveItem, callERABInfo_type *pERABInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(drbToRemoveItem);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);

    drbToRemoveItem->bit_mask = 0;

    // DRB ID Fill - mandatory
    drbToRemoveItem->dRB_ID = pERABInfo->dRBId;

    return GOOD;
}

/**
 * @brief fill E1 DRB Modified EUTRAN for Beaerer Context Modification Confirm
 * @attention function sets all bit_mask
 * @param [in]  ptBearerModConfirmBuffer        : E1_BearerContextModificationConfirmBuffer buffer
 * @param [in]  pERABInfo                       : callERABInfo DB
 * @param [in]  numErab                         : number of DRB item
 * @param [out] drbModListItem                  : E1_DRB_Confirm_Modified_Item_EUTRAN buffer
 * @return      GOOD                            : success fill
 * @return      ERROR                           : fill error
 */
int VEIL_fillE1_DrbModifiedItemEUTRAN(callInfo_type *ptCi, E1_DRB_Confirm_Modified_Item_EUTRAN *drbModListItem,
    E1_BearerContextModificationConfirmBuffer::DrbModifiedConfirmDataEutran *ptDrbModifiedConfirmBuffer,
    callERABInfo_type *pERABInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(drbModListItem);
    VALID_E_POINT_CHECK_ERROR(ptDrbModifiedConfirmBuffer);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);
    VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);

    drbModListItem->bit_mask = 0;

    uint8_t dataSplitThreshold = 0;
    dataSplitThreshold = FnVCCB_GetUlDataSplitThreshold(ptCi, pERABInfo);

    // DRB ID Fill - mandatory
    drbModListItem->dRB_ID = pERABInfo->dRBId;
    // DRB Cell Group Information - optional
    if (UlConfigBearer_ModUnable == pERABInfo->ulPdcpPathToMod)
    {
        drbModListItem->bit_mask |= E1_DRB_Confirm_Modified_Item_EUTRAN_cell_Group_Information_present;
        ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.bit_mask = 0;
        ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.bit_mask = 0;

        if (SPLIT_Bearer == pERABInfo->bearerType)
        {
            if (UlPdcpPath_ScgShared == pERABInfo->ulPdcpPathEnqToSet)
            {
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.bit_mask |=
                    E1_Cell_Group_Information_Item_uL_Configuration_present;
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.cell_Group_ID = CellGroupId_MCG;

                if ((TRUE == ptCi->ueInfo.ueCapa.mrdc.tddCapaAdd.general.splitDRB_withUL_Both_MCG_SCG) &&
                    ((dataSplitThreshold != NRRRC_UL_DataSplitThreshold_infinity) &&
                        (FALSE == FnVCCB_PacketInspectionONQciBasedUlSplitThSwitchOFF(ptCi))))
                {
                    ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.uL_Configuration = E1_shared;
                }
                else
                {
                    ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.uL_Configuration = E1_no_data;
                }

                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.bit_mask |=
                    E1_Cell_Group_Information_Item_uL_Configuration_present;
                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.cell_Group_ID = CellGroupId_SCG;
                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.uL_Configuration = E1_only;

                pERABInfo->ulPdcpPathToMod = UlConfigBearer_ModOff;
            }
            else if (UlPdcpPath_McgShared == pERABInfo->ulPdcpPathEnqToSet)  // MCG + not infinite
            {
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.bit_mask |=
                    E1_Cell_Group_Information_Item_uL_Configuration_present;
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.cell_Group_ID = CellGroupId_MCG;
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.uL_Configuration = E1_only;

                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.bit_mask |=
                    E1_Cell_Group_Information_Item_uL_Configuration_present;
                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.cell_Group_ID = CellGroupId_SCG;

                if ((TRUE == ptCi->ueInfo.ueCapa.mrdc.tddCapaAdd.general.splitDRB_withUL_Both_MCG_SCG) &&
                    ((dataSplitThreshold != NRRRC_UL_DataSplitThreshold_infinity)))
                {
                    ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.uL_Configuration = E1_shared;
                }
                else
                {
                    ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.uL_Configuration = E1_no_data;
                }

                pERABInfo->ulPdcpPathToMod = UlConfigBearer_ModOff;
            }
            else if (UlPdcpPath_McgOnly == pERABInfo->ulPdcpPathEnqToSet)
            {
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.bit_mask |=
                    E1_Cell_Group_Information_Item_uL_Configuration_present;
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.cell_Group_ID = CellGroupId_MCG;
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.uL_Configuration = E1_only;

                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.bit_mask |=
                    E1_Cell_Group_Information_Item_uL_Configuration_present;
                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.cell_Group_ID = CellGroupId_SCG;
                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.uL_Configuration = E1_no_data;

                pERABInfo->ulPdcpPathToMod = UlConfigBearer_ModOff;
            }

            if (ERROR == VCCB_ConnectLinkedList(ptDrbModifiedConfirmBuffer->cellGroupModified, 2))
            {
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "ERROR: VCCB_ConnectLinkedList failed in VEIL_fillE1_DrbModifiedItemEUTRAN\n");

                return ERROR;
            }
        }
        else if (SCG_Bearer == pERABInfo->bearerType)
        {
            ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.bit_mask |=
                E1_Cell_Group_Information_Item_uL_Configuration_present;
            ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.cell_Group_ID = CellGroupId_SCG;
            ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.uL_Configuration = E1_only;
            ptDrbModifiedConfirmBuffer->cellGroupModified[0].next = nullptr;
        }
        else  // MCG_Bearer == pERABInfo->bearerType
        {
            ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.bit_mask |=
                E1_Cell_Group_Information_Item_uL_Configuration_present;
            ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.cell_Group_ID = CellGroupId_MCG;
            ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.uL_Configuration = E1_only;
            ptDrbModifiedConfirmBuffer->cellGroupModified[0].next = nullptr;
        }

        if (0==ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.bit_mask)
        {
            drbModListItem->bit_mask = 0;
            return GOOD;
        }

        // Connect Cell Group To Modify List
        drbModListItem->cell_Group_Information = ptDrbModifiedConfirmBuffer->cellGroupModified;
        drbModListItem->bit_mask |= E1_DRB_Confirm_Modified_Item_EUTRAN_cell_Group_Information_present;
    }

    return GOOD;
}

/**
 * @brief fill E1 DRB To Modify Item EUTRAN for Bearer Context Modification Request
 *        Fill Status DL Traffic Status Monitoring list
 * @attention   required correct bit_mask in drbToModifyItem
 * @param [in]  ptCi                                : call context
 * @param [out] drbToModifyItem                     : E1_DRB_To_Modify_Item_EUTRAN buffer
 * @param [in]  ptBearerModificationRequestBuffer   : E1_BearerContextModificationRequestBuffer buffer
 * @param [in]  pERABInfo                           : callERABInfo DB
 * @param [in]  DRBnumber                           : number of DRB item
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_fillE1_DrbToModifyItemEUTRAN_DlTrafficStatusReport(callInfo_type *ptCi,
    E1_DRB_To_Modify_Item_EUTRAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer *ptBearerModificationRequestBuffer, callERABInfo_type *pERABInfo,
    int DRBnumber)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptBearerModificationRequestBuffer);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(DRBnumber, MAX_ERAB_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(pERABInfo->erabIdx, MAX_ERAB_PER_CALL);

    // DRB ID Fill - mandatory
    drbToModifyItem->dRB_ID = pERABInfo->dRBId;

    if (FALSE == ptCi->trafficMonitoringCfg.trafficReportDrbList[pERABInfo->erabIdx].isSameCfgFlag)
    {
        bool isExtensionPresent = drbToModifyItem->bit_mask & E1_DRB_To_Modify_Item_EUTRAN_iE_Extensions_present;
        int16_t status = FnVCCB_FillE1_ReportConfigList(ptCi, pERABInfo->erabIdx,
            ptBearerModificationRequestBuffer->dlTrafficStatusReportEutran[DRBnumber], isExtensionPresent,
            drbToModifyItem->iE_Extensions);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "Failed to fill DL traffic status report configuration.\n");

        if (GOOD == status)
        {
            drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_EUTRAN_iE_Extensions_present;
        }
    }
    return GOOD;
}

/**
 * @brief fill E1 Cause
 * @attention no bit_mask
 * @param [in]  e1Cause     : callInfo e1cCause
 * @param [out] ptCause     : E1_Cause buffer
 * @return      GOOD        : success fill
 * @return      ERROR       : fill error
 */
int VEIL_fillE1_Cause(uint16_t e1Cause, E1_Cause *ptCause)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCause);

    switch (e1Cause)
    {
        case CAUSE_BASE_E1AP_RADIONETWORK ...(CauseE1apRadioNetworkLayerEnd - 1):
            ptCause->choice = E1_radioNetwork_chosen;
            ptCause->u.radioNetwork = (static_cast<E1_CauseRadioNetwork>(e1Cause - CAUSE_BASE_E1AP_RADIONETWORK));
            break;
        case CAUSE_BASE_E1AP_TRANSPORT ...(CauseE1apTransportLayerEnd - 1):
            ptCause->choice = E1_transport_chosen;
            ptCause->u.transport = static_cast<E1_CauseTransport>(e1Cause - CAUSE_BASE_E1AP_TRANSPORT);
            break;
        case CAUSE_BASE_E1AP_PROTOCOL ...(CauseE1apProtocolEnd - 1):
            ptCause->choice = E1_protocol_chosen;
            ptCause->u.protocol = static_cast<E1_CauseProtocol>(e1Cause - CAUSE_BASE_E1AP_PROTOCOL);
            break;
        case CAUSE_BASE_E1AP_MISC ...(CauseE1apMiscEnd - 1):
            ptCause->choice = E1_misc_chosen;
            ptCause->u.misc = static_cast<E1_CauseMisc>(e1Cause - CAUSE_BASE_E1AP_MISC);
            break;
        default:
            ptCause->choice = E1_misc_chosen;
            ptCause->u.misc = static_cast<E1_CauseMisc>(CauseE1apMiscUnspecified - CAUSE_BASE_E1AP_MISC);
            VCCB_PRINT_ERROR("Invalid E1 Cause value(%d), so set MiscUnspecifiedFailure !!\n", e1Cause);
            return ERROR;
    }

    return GOOD;
}

uint8_t VEIL_checkE1_NeedToBearerModifiedItem(callInfo_type *ptCi, uint8_t bearerState)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    if (ptCi->callType == E_CALLTYPE_NSA) return FALSE;

    if (bearerState != S_Idle) return FALSE;

    switch (ptCi->stateCmd)
    {
        case IntraRatHO_cmd:
        case InterRatHO_cmd:  // IRAT_HO
            if (ptCi->hoInfo.isTarget == FALSE)
            {
                /* PDU or DRB State is not changed to Modify at Source gNB (include Intra/Inter gNB) */
                return TRUE;
            }
            break;

        case RrcReestablish_cmd:
            if (!IS_NRDC_MN(ptCi))
            {
                return TRUE;
            }
            // RRE for NRDC
            if (STATE_RRE_Ready == ptCi->state)  // tx-stop case
            {
                return TRUE;
            }
            return FALSE;

        case RRCResume_cmd:
            if (STATE_Inact_F1Mod == ptCi->state) return TRUE;
            if (RESUME_TYPE_INTER_GNB_SOURCE == ptCi->ueInfo.rrcResumeInfo.resumeType &&
                (STATE_Inact_Suspend == ptCi->state || STATE_Inact_ResumeReq == ptCi->state ||
                    STATE_Inact_S_XnUAddrInd == ptCi->state))
                return TRUE;
            break;

        case RRCSuspend_cmd:
            if (STATE_Inact_F1ModQuery == ptCi->state && IS_RRC_INACTIVE_DRB_LEVEL(ptCi)) return TRUE;
            if (STATE_Inact_T_E1Mod == ptCi->state) return TRUE;
            break;

        case IntraCellHO_cmd:
            return TRUE;

        case MrdcScgFailSuspend_cmd:
        case MrdcScgFailResume_cmd:
            return TRUE;

        default:
            break;
    }

    if (IS_SUPPORT_RRC_INACTIVE(ptCi))
    {
        if (IS_RRC_INACTIVE_DRB_LEVEL(ptCi) && IS_SUPPORT_TO_REL_PREF_RRC_INACTIVE(ptCi))
            return TRUE;

        if (ptCi->state == STATE_Conn &&
            ptCi->ueInfo.rrcResumeInfo.preventSNAddFlag &&
            ptCi->ueInfo.rrcResumeInfo.actionInSNRelease == SN_REL_IN_RRC_INACTIVE_DECIDED_AND_WAIT_INACTNOTI)
            return TRUE;
    }

    return FALSE;
}

int16_t FnVCCB_DoesNeedMrdcE1BearerModify_perDrb(callInfo_type *ptCi, callDRBInfo_type *pDi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(pDi);

    switch (ptCi->state)
    {
        case STATE_SNAddComplt_E1F1NGMod:
        case STATE_SNModComplt_E1F1NGMod:
            if (pDi->bearerType.val == MN_Term_MCG_Bearer && pDi->reqBearerType.termPoint == TermPoint_Sn)
            {
                return TRUE;
            }
            break;
        case STATE_INTRA_DU_SnRelB:
        case STATE_INTER_DU_SnRelB:
            if (pDi->bearerType.val == MN_Term_SPLIT_Bearer || pDi->bearerType.val == MN_Term_SCG_Bearer)
            {
                if (pDi->reqBearerType.val == MN_Term_MCG_Bearer)
                {
                    return TRUE;
                }
            }
            break;
        case STATE_Conn:
            if (ptCi->stateCmd == MrUlPathSwitch_cmd &&
                (pDi->bearerType.val == MN_Term_SPLIT_Bearer || pDi->bearerType.val == SN_Term_SPLIT_Bearer))
            {
                return TRUE;
            }
            break;
        case STATE_Intra_Cell_E1Stop:
        {
            return TRUE;
        }
        break;
        case STATE_RRE_RreCmpl:
        case STATE_RRE_F1SetupMod:
        case STATE_RRE_RRCRecCmpl:
        case STATE_RRE_Switch:
            if (IS_BearerType_Changing(*pDi))
            {
                if (pDi->reqBearerType.val == MN_Term_MCG_Bearer)
                {
                    return TRUE;
                }
            }
            break;
        default:
            break;
    }
    return FALSE;
}

int16_t FnVCCB_DoesNeedMrdcE1BearerModify(callInfo_type *ptCi, bool isDrbBased, void *pInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pInfo);
    if (isDrbBased)
    {  // a drb to be modified
        VALID_E_POINT_CHECK_ERROR(pInfo);
        callDRBInfo_type *pDi = (callDRBInfo_type *)pInfo;
        int drbIdx = static_cast<int>(pDi - ptCi->drb);  // offset

        if (drbIdx < 0)
        {
            VCCB_PRINT_ERROR("Invalid drbIdx(%d), pDi(%p), ptCi->drb(%p)\n", drbIdx, pDi, ptCi->drb);
            return ERROR;
        }

        VCCB_CHECK_E_RANGE_AND_RETURN(drbIdx, MAX_DRB_PER_SA_CALL);

        if (GET_E1_MRDC_CTRL_FLAG_VALUE(drbIdx))
        {
            return GOOD;
        }
    }
    else
    {  // pduSession to be modified by drb mod/rel ( drb addition will be handled in PDUChg procedure)
        callPDUSessInfo_type *pPi = (callPDUSessInfo_type *)pInfo;
        for (uint8_t index = 0; index < MAX_DRB_PER_PDU_SESS; index++)
        {
            uint16_t drbIdx = pPi->drbIndex[index];

            if (drbIdx >= MAX_DRB_PER_SA_CALL) continue;

            callDRBInfo_type *pDi = &ptCi->drb[drbIdx];

            if (GET_E1_MRDC_CTRL_FLAG_VALUE(drbIdx) || FnVCCB_DoesNeedMrdcE1BearerModify_perDrb(ptCi, pDi) == TRUE)
            {
                return GOOD;
            }
        }
    }

    return ERROR;
}

/****************************************************************************
 * @brief           This function supports the operation for determining in DRB units in the MRDC situation.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       ptDi : call DRB information / callDRBInfo_type
 * @return          Not_Decision(0), Decision(1)
 ****************************************************************************/
enumDecisionState_type FnVCCB_checkE1_NeedToBearerModifiedItemForMRDCForDRB(
    callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t *pRetVal)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, Not_Decision);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, Not_Decision);

    // drb to be modified

    // if (ptDi->drbStatus != S_Idle)
    //{
    //    return FALSE;
    //}

    if (ptCi->stateCmd == MrdcSNModSnMobility_cmd)
    {
        if (FnVCCB_IsMnTermScgLegPerDRB(ptCi, ptDi, request_bearerType) == true)
        {
            *pRetVal = TRUE;
            return Decision;
        }

        *pRetVal = FALSE;
        return Decision;
    }

    if (ptCi->stateCmd == RrcReestablish_cmd)
    {
        if (GOOD == FnVCCB_DoesNeedMrdcE1BearerModify_perDrb(ptCi, ptDi))
        {
            *pRetVal = TRUE;
            return Decision;
        }
        *pRetVal = FALSE;
        return Decision;
    }

    switch (ptCi->state)
    {
        case STATE_INTRA_DU_SnRelB:
        case STATE_INTER_DU_SnRelB:
            if (S_Setup == ptDi->drbStatus)
            {
                // It is already setup in STATE_INTRA_DU_SnRelA or STATE_INTER_DU_SnRelAE1Xn,
                // but it is a case that needs to be modified with DRB modified List IE,
                // so an exception operation is performed to add it to DRB modified List IE.
                *pRetVal = TRUE;
                return Decision;
            }
            break;

        default:
            // enter the next line
            break;
    }

    return Not_Decision;
}

uint8_t VEIL_checkE1_NeedToBearerModifiedItemForMRDC(callInfo_type *ptCi, void *ptInfo, bool isDrb)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(ptInfo);

    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        return FALSE;
    }

    if (!IsAvailable_MrdcInfo())
    {
        return FALSE;
    }

    if (true == isDrb)
    {  // drb to be modified

        uint8_t retVal = FALSE;

        if (FnVCCB_checkE1_NeedToBearerModifiedItemForMRDCForDRB(ptCi, (callDRBInfo_type *)ptInfo, &retVal) == Decision)
        {
            return retVal;  // TRUE or FALSE
        }
        if (STATE_Intra_Cell_E1Stop == ptCi->state)
        {
            return TRUE;
        }
    }
    else
    {  // pduSession to be modified by drb add/mod/rel

        callPDUSessInfo_type *ptPDUSession = NULL;

        ptPDUSession = (callPDUSessInfo_type *)ptInfo;

        // if (ptPDUSession->pduSessStatus != S_Idle)
        //{
        //    return FALSE;
        //}

        if (ptCi->stateCmd == MrdcSNModSnMobility_cmd)
        {
            if (FnVCCB_IsAnyMnTermScgLegPerPDU(ptCi, ptPDUSession, request_bearerType) == true) return TRUE;

            return FALSE;
        }
    }

    if (IS_NEDC_MN(ptCi))
    {
        switch (ptCi->stateCmd)
        {
            case MrdcE1ScgAdd_cmd:
            case MrdcE1ScgMod_DlPath_cmd:
            case MrdcSNAddPrepareFail_cmd:
            case MrdcE1ScgRel_cmd:
            case MrUlPathSwitch_cmd:
                return TRUE;

            case ReconfigComplete_cmd:
                if ((ptCi->state == STATE_SNRelExec) || (ptCi->state == STATE_SNModExec))
                {
                    return TRUE;
                }
                break;

            default:
                break;
        }
    }
    else if (IS_NRDC_MN(ptCi))
    {
        if (GOOD == FnVCCB_DoesNeedMrdcE1BearerModify(ptCi, isDrb, ptInfo))
        {
            return TRUE;
        }
        else if ((E1UlPathSwitch_cmd == ptCi->stateCmd) || (MrUlPathSwitch_cmd == ptCi->stateCmd))
        {
            return TRUE;
        }
    }

    return FALSE;
}

uint8_t FnVCCB_CheckE1_NeedToBearerModifiedItemForNRDC_SN(callInfo_type *ptCi, void *ptInfo, bool isDrb)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(ptInfo);

    uint16_t drbIdxInPdu;
    uint16_t drbIdxInCall;
    uint8_t needRelBearerModify = FALSE;

    callPDUSessInfo_type *ptPi = NULL;
    callDRBInfo_type *ptDi = NULL;

    if ((ptCi->callType != E_CALLTYPE_SA) || !IS_NRDC_SN(ptCi))
    {
        return FALSE;
    }

    if (TRUE == ptCi->bitFlag.isDrbPreemptionCase)
    {
        switch (ptCi->state)
        {
            case STATE_SN_SNModPrepare_XnModRqrd:  // For sending txStop
            case STATE_SN_SNModExec:               // For sending Data Forwarding Information
            case STATE_SN_SNModPrepare_F1Mod1:     // For sending PDSP SN Status Request
                needRelBearerModify = TRUE;
                break;
            default:
                break;
        }
    }

    if (true == isDrb)
    {  // drb to be modified
        ptDi = (callDRBInfo_type *)ptInfo;

        if ((needRelBearerModify == TRUE) && (ptDi->drbStatus == S_Release))
        {
            return TRUE;
        }

        if (ptDi->drbStatus != S_Idle)
        {
            return FALSE;
        }

        if (FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_McgMobility) == true)
        {
            // TODO: need to modify the code
            drbIdxInCall = static_cast<uint16_t>(ptDi - &ptCi->drb[0]);
            if (GET_E1_MRDC_CTRL_FLAG_VALUE(drbIdxInCall))
            {
                return TRUE;
            }
        }

        if ((ptDi->xNuDlInfo.fNeedModify == 1) || (ptDi->dataFwdInfo.snStatus.needSendFlag == TRUE))
        {
            return TRUE;
        }
    }
    else
    {  // pduSession to be modified by drb add/mod/rel
        ptPi = (callPDUSessInfo_type *)ptInfo;

        if ((needRelBearerModify == TRUE) && (ptPi->pduSessStatus == S_Release))
        {
            return TRUE;
        }

        if (ptPi->pduSessStatus != S_Idle)
        {
            return FALSE;
        }

        for (drbIdxInPdu = 0; drbIdxInPdu < MAX_DRB_PER_PDU_SESS; drbIdxInPdu++)
        {
            drbIdxInCall = ptPi->drbIndex[drbIdxInPdu];

            if (drbIdxInCall >= MAX_DRB_PER_SA_CALL) continue;

            ptDi = &ptCi->drb[drbIdxInCall];

            if (ptDi->usage != CI_use) continue;
            if (ptDi->drbStatus != S_Idle) continue;

            if ((ptDi->xNuDlInfo.fNeedModify == 1) || (ptDi->dataFwdInfo.snStatus.needSendFlag == TRUE))
            {
                return TRUE;
            }
        }

        if (FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_McgMobility) == true)
        {
            for (drbIdxInPdu = 0; drbIdxInPdu < MAX_DRB_PER_PDU_SESS; drbIdxInPdu++)
            {
                drbIdxInCall = ptPi->drbIndex[drbIdxInPdu];
                if (drbIdxInCall >= MAX_DRB_PER_SA_CALL) continue;

                ptDi = &ptCi->drb[drbIdxInCall];

                if (ptDi->usage != CI_use) continue;

                if (GET_E1_MRDC_CTRL_FLAG_VALUE(drbIdxInCall))
                {
                    return TRUE;
                }
            }
        }
    }

    switch (ptCi->stateCmd)
    {
        case MrdcSnNodeRelRequest_cmd:
        case MrdcSnNodeRelConfirm_cmd:
        case MrUlPathSwitch_cmd:
        case E1UlPathSwitch_cmd:
            return TRUE;

        default:
            break;
    }

    return FALSE;
}

int VEIL_checkE1_SCG_Release_For_SA_Mobility(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    if (!IsAvailable_MrdcInfo()) return FALSE;

    switch (ptCi->state)
    {
        case STATE_INTRA_DU_SnRelA:
        case STATE_INTER_DU_SnRelA:
            return TRUE;

        // Case of RRE
        case STATE_RRE_RreCmpl:
            if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
                return TRUE;
            else
                return FALSE;

        default:
            return FALSE;
    }
}

// This function is used for traffic control in Handover, RRE, INACT, and SCG Failure for SA UE.
VCCB_STATIC_INLINE
enumTxCtrltype VEIL_checkE1_DL_Tx_Stop_For_SA_Mobility(callInfo_type *ptCi, callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, TX_NO_CONTROL);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, TX_NO_CONTROL);

    if (ptCi->callType == E_CALLTYPE_NSA) return TX_NO_CONTROL;

    switch (ptCi->stateCmd)
    {
        case MrdcSNModSnMobility_cmd:  // SN Mobility
        case IntraRatHO_cmd:
        case InterRatHO_cmd:      // IRAT_HO
        case RrcReestablish_cmd:  // RRE
        case RRCResume_cmd:       // RRCResume
        case IntraCellHO_cmd:
        case MrdcScgFailSuspend_cmd:  // NRDC SCG Failure Handling
        case MrdcScgFailResume_cmd:   // NRDC SCG Failure Handling
            break;
        default:
            return TX_NO_CONTROL;
    }

    switch (ptCi->state)
    {
        // Handover in MN. (STOP)
        case STATE_INTRA_DU_E1Stop:     // Intra-DU
        case STATE_INTER_DU_Prepare:    // Inter-DU
        case STATE_INTER_Exe_S:         // Inter-gNB Source-gNB
            if (FnVCCB_IsFlagBasedE1ControlForHO(ptCi) == true)
                return TX_NO_CONTROL;

            return TX_STOP;

        // Handover in MN. (RESUME)
        case STATE_INTRA_DU_Cancel:       // Intra-DU
        case STATE_INTRA_DU_Complete:     // Intra-DU
        case STATE_INTER_DU_Complete:     // Inter-DU
            if (FnVCCB_IsFlagBasedE1ControlForHO(ptCi) == true)
                return TX_NO_CONTROL;
            else if(GET_NEED_SEND_TX_STOP_BY_FORCE(ptDi))
            {
                SET_NEED_SEND_TX_STOP_BY_FORCE(ptDi, FALSE); // end of life cycle
                return TX_STOP;
            }

            return TX_RESUME;

        case STATE_Ltm_Complete:
            if (ptCi->ltmUeInfo.cellSwitchFlag.e1StopIsRequired)
            {
                return TX_STOP;
            }
            else if (ptCi->ltmUeInfo.cellSwitchFlag.e1ResumeIsRequired)
            {
                return TX_RESUME;
            }
            break;

        case STATE_SN_INTRA_DU_Prepare:
            if (IS_SCG_RESUMING(ptCi))
                return TX_STOP;
            else
                break;

        // RRE (STOP)
        case STATE_RRE_Ready:  // Intra DU, Inter DU RRE, Inter gNB RRE for old call
            return TX_STOP;

        // RRE (RESUME)
        case STATE_RRE_RRCRecCmpl:       // Intra DU, Inter DU RRE
            if (FnVCCB_IsSaIntraGnbRreUE(*ptCi))
            {
                if (IS_SUPPORT_DRB_PARTIAL_FOR_RRE_DURING_HO(ptCi, ptDi))
                    return TX_STOP;

                return TX_RESUME;
            }
            break;

        case STATE_RRE_Switch:
            if (FnVCCB_IsSaIntraGnbRreUE(*ptCi))
            {
                if (IS_SUPPORT_DRB_PARTIAL_FOR_RRE_DURING_HO(ptCi, ptDi))
                    return TX_STOP;

                return TX_RESUME;
            }
            return TX_NO_CONTROL;

        // RRCResume - For Source gNB
        case STATE_Inact_Suspend:
        case STATE_Inact_ResumeReq:
            if (RESUME_TYPE_INTER_GNB_SOURCE == ptCi->ueInfo.rrcResumeInfo.resumeType) return TX_STOP;
            break;

        // Intra-Cell Handover (RESUME)
        case STATE_Intra_Cell_Complete:
            return TX_RESUME;

        // SCG Failure Handling for NR-DC
        case STATE_SN_SCGSuspend_Init:
        case STATE_MN_SCGSuspend_XnMod:
        case STATE_SN_SCGResume_Init:
        case STATE_MN_SCGResume_XnMod:
            return TX_STOP;

        // SCG Failure Handling for NR-DC
        case STATE_MN_SCGResume_F1ReconfigCmpl:
            return TX_RESUME;

        default:
            break;
    }

    // Intra Cell Handover
    if ((ptCi->stateCmd == IntraCellHO_cmd) && (ptCi->ueInfo.securityModFlag == VCCB_FLAG_ON))  // Intra Cell Handover
    {
        return TX_STOP;
    }

    return TX_NO_CONTROL;
}

int VEIL_checkE1_data_fwd_information_request_for_sa_mobility(callInfo_type *ptCi, callDRBInfo_type *pDrbInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDrbInfo);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);

    if (ptCi->callType == E_CALLTYPE_NSA) return ERROR;

    if (IS_NRDC_MN(ptCi) && IS_ON_E1_MRDC_CTRL_FLAG(pDrbInfo, mcgMod_dataFwdInfoReq))
    {
        return GOOD;
    }

    switch (ptCi->state)
    {
        case STATE_INTER_Pre_UP_T:   // Inter gNB target
        {
            if (InterRatHO_cmd != ptCi->stateCmd && IntraRatHO_cmd != ptCi->stateCmd) return ERROR;

            const gnbConfig_type *const pGnbCfg = &GNBINFO[ptCi->gnbNum].cfg;
            if (InterRatHO_cmd == ptCi->stateCmd && 
                (!ptCi->hoInfo.allPduSessDirectFwdPathAvailable || !pGnbCfg->interSysDirectDataFwdTgt)) return ERROR;
            break;
        }
        case STATE_INTRA_DU_SnRelA:  // Data forwarding from SN term to MN term duing Intra DU handover
        case STATE_INTER_DU_SnRelA:  // Data forwarding from SN term to MN term duing Inter DU handover
            if (ptCi->stateCmd != IntraRatHO_cmd) return ERROR;  // Inter-NR Only
            break;

        case STATE_Intra_Cell_SnRelA:  // Data forwarding from SN term to MN term during Intra Cell handover
            break;

        case STATE_RRE_RreCmpl:  // for RRE
            if (ptCi->stateCmd != RrcReestablish_cmd) return ERROR;
            break;

        case STATE_Inact_T_XnUeContextReq:  // for Inter gNB RRCResume
            if (ptCi->stateCmd != RRCResume_cmd && ptCi->stateCmd != RRCSuspend_cmd) return ERROR;
            break;

        case STATE_II:
            if (!(IS_NRDC_SN(ptCi) && ptCi->stateCmd == MrdcXnSNAdd_cmd)) return ERROR;
            break;

        case STATE_Conn:
            if (!(IS_NRDC_SN(ptCi) && ptCi->stateCmd == MrdcXnSNMod_cmd)) return ERROR;
            break;

        case STATE_INTER_Pre_SN_T:
            break;

        default:
            return ERROR;
    }

    /* TODO : check the DRB id is used with same value from serving or not */
    if (VCCB_GET_FULLCONFIGURATION_DRB(ptCi, ci_fc_drb_disable_datafwd, pDrbInfo->dRBId) == TRUE)
    {
        return ERROR;
    }

    return GOOD;
}

int VEIL_fillE1_DRB_Setup_Data_Forwarding_Information_request(E1_DRB_To_Setup_Item_NG_RAN *drbToSetupItem,
    DrbToBeSetupData *ptDrbToBeSetupBuffer, callInfo_type *ptCi, callDRBInfo_type *pDRBInfo)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(drbToSetupItem);
    VALID_E_POINT_CHECK_ERROR(ptDrbToBeSetupBuffer);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDRBInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    unsigned int loop = 0, numQoSFlow = 0;
    qosFlowInfo_type *ptQi = NULL;
    int dlFwdEnabled = FALSE, ulFwdEnabled = FALSE;
    E1_Data_Forwarding_Request dataFwdReq = E1_dL;

    E1_Data_Forwarding_Information_Request *ptDataFwdInfo = &drbToSetupItem->dRB_Data_Forwarding_Information_Request;
    E1_QoS_Flow_Mapping_List ptQosFlowMappingData = NULL;

    ptDataFwdInfo->bit_mask = 0;

    for (loop = 0; loop < MAX_QOS_FLOW_PER_DRB; loop++)
    {
        if (pDRBInfo->qosFlowIndex[loop] >= MAX_QOS_FLOW_PER_CALL)  // Not yet allocated
            continue;

        ptQi = &ptCi->qosFlow[pDRBInfo->qosFlowIndex[loop]];

        if (CI_use != ptQi->usage) continue;

        VCCB_PRINT_CALL_DATA(ptCi, "[E1DBG] ptCi->qosFlow[%d].usage is CI_use\n", pDRBInfo->qosFlowIndex[loop]);

        if (ptQi->dataFwdInfo.dlForward == TRUE) dlFwdEnabled = TRUE;

        if (ptQi->dataFwdInfo.ulForward == TRUE) ulFwdEnabled = TRUE;

        if ((ptQi->dataFwdInfo.dlForward == TRUE) || (ptQi->dataFwdInfo.ulForward == TRUE))
        {
            ptQosFlowMappingData = &ptDrbToBeSetupBuffer->dataForwardingInformationRequestData
                                        .qoS_Flows_Forwarded_On_Fwd_Tunnels[numQoSFlow];

            ptQosFlowMappingData->value.bit_mask = 0;
            ptQosFlowMappingData->value.qoS_Flow_Identifier = ptQi->flowId;

            // 9.3.1.60 QoS Flow Mapping Indication (TBD)

            ++numQoSFlow;
        }
    }

    if (numQoSFlow)
    {
        ptDataFwdInfo->bit_mask |= E1_qoS_Flows_Forwarded_On_Fwd_Tunnels_present;
        ptDataFwdInfo->qoS_Flows_Forwarded_On_Fwd_Tunnels =
            ptDrbToBeSetupBuffer->dataForwardingInformationRequestData.qoS_Flows_Forwarded_On_Fwd_Tunnels;

        if (ERROR == VCCB_ConnectLinkedList(ptDataFwdInfo->qoS_Flows_Forwarded_On_Fwd_Tunnels, static_cast<int>(numQoSFlow)))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "VCCB_ConnectLinkedList failed in %s-> QoS Flow QoS Parameters List!\n", __func__);

            return ERROR;
        }

        if (dlFwdEnabled && ulFwdEnabled)
        {
            dataFwdReq = E1_Data_Forwarding_Request_both;
        }
        else
        {
            if (dlFwdEnabled)
            {
                dataFwdReq = E1_dL;
            }
            if (ulFwdEnabled)
            {
                dataFwdReq = E1_uL;
            }
        }

        ptDataFwdInfo->data_Forwarding_Request = dataFwdReq;

        drbToSetupItem->bit_mask |= E1_DRB_To_Setup_Mod_Item_NG_RAN_dRB_Data_Forwarding_Information_Request_present;

        if (IS_LOG_TRAFFIC(ptCi))
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[TRAFFIC, FWD]: UL:%s, DL:%s, BOTH:%s, PDU Forwarding Information Request (DRB ID:%u)\n",
                ((dataFwdReq == E1_uL) ? "O" : "X"),
                ((dataFwdReq == E1_dL) ? "O" : "X"),
                ((dataFwdReq == E1_Data_Forwarding_Request_both) ? "O" : "X"),
                pDRBInfo->dRBId);
        }
    }

    return GOOD;
}

int VEIL_fillE1_DRB_Setup_Mod_Data_Forwarding_Information_request(E1_DRB_To_Setup_Mod_Item_NG_RAN *drbToSetupModItem,
    E1_BearerContextModificationRequestBuffer::PduSessToBeSetupModData::DrbToBeSetupModData *ptDrbToBeSetupModBuffer,
    callInfo_type *ptCi, callDRBInfo_type *pDRBInfo)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(drbToSetupModItem);
    VALID_E_POINT_CHECK_ERROR(ptDrbToBeSetupModBuffer);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDRBInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    unsigned int loop = 0, numQoSFlow = 0;
    qosFlowInfo_type *ptQi = NULL;
    int dlFwdEnabled = FALSE, ulFwdEnabled = FALSE;
    E1_Data_Forwarding_Request dataFwdReq = E1_dL;

    E1_Data_Forwarding_Information_Request *ptDataFwdInfo = &drbToSetupModItem->dRB_Data_Forwarding_Information_Request;
    E1_QoS_Flow_Mapping_List ptQosFlowMappingData = NULL;

    ptDataFwdInfo->bit_mask = 0;

    for (loop = 0; loop < MAX_QOS_FLOW_PER_DRB; loop++)
    {
        if (pDRBInfo->qosFlowIndex[loop] >= MAX_QOS_FLOW_PER_CALL)  // Not yet allocated
            continue;

        ptQi = &ptCi->qosFlow[pDRBInfo->qosFlowIndex[loop]];

        if (CI_use != ptQi->usage) continue;

        VCCB_PRINT_CALL_DATA(ptCi, "[E1DBG] ptCi->qosFlow[%d].usage is CI_use\n", pDRBInfo->qosFlowIndex[loop]);

        if (ptQi->dataFwdInfo.dlForward == TRUE) dlFwdEnabled = TRUE;

        if (ptQi->dataFwdInfo.ulForward == TRUE) ulFwdEnabled = TRUE;

        if ((ptQi->dataFwdInfo.dlForward == TRUE) || (ptQi->dataFwdInfo.ulForward == TRUE))
        {
            ptQosFlowMappingData = &ptDrbToBeSetupModBuffer->dataForwardingInformationRequestData
                                        .qoS_Flows_Forwarded_On_Fwd_Tunnels[numQoSFlow];

            ptQosFlowMappingData->value.bit_mask = 0;
            ptQosFlowMappingData->value.qoS_Flow_Identifier = ptQi->flowId;

            // 9.3.1.60 QoS Flow Mapping Indication (TBD)

            ++numQoSFlow;
        }
    }

    if (numQoSFlow)
    {
        ptDataFwdInfo->bit_mask |= E1_qoS_Flows_Forwarded_On_Fwd_Tunnels_present;
        ptDataFwdInfo->qoS_Flows_Forwarded_On_Fwd_Tunnels =
            ptDrbToBeSetupModBuffer->dataForwardingInformationRequestData.qoS_Flows_Forwarded_On_Fwd_Tunnels;

        if (ERROR == VCCB_ConnectLinkedList(ptDataFwdInfo->qoS_Flows_Forwarded_On_Fwd_Tunnels, static_cast<int>(numQoSFlow)))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "VCCB_ConnectLinkedList failed in %s-> QoS Flow QoS Parameters List!\n", __func__);

            return ERROR;
        }

        if (dlFwdEnabled && ulFwdEnabled)
        {
            dataFwdReq = E1_Data_Forwarding_Request_both;
        }
        else
        {
            if (dlFwdEnabled)
            {
                dataFwdReq = E1_dL;
            }
            if (ulFwdEnabled)
            {
                dataFwdReq = E1_uL;
            }
        }

        ptDataFwdInfo->data_Forwarding_Request = dataFwdReq;

        drbToSetupModItem->bit_mask |= E1_DRB_To_Setup_Item_NG_RAN_dRB_Data_Forwarding_Information_Request_present;
    }

    return GOOD;
}

int FnVCCB_FillCellGroupInformationBuffer_SADrbSetup(
    E1_Cell_Group_Information pBuffer, callInfo_type *ptCi, callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pBuffer);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);

    int cellGroupListNum = 0;

    if (IS_NRDC_SN(ptCi))
    {
        // Bearer Type | Primary Path| UL Split | UL Configuration (MCG) | UL Configuration (SCG)
        // ---------------------------------------------------------------------------------
        // SN-SCG      | SCG         | N/A      | N/A                    | only
        // SN-SPLIT    | SCG         | X        | no-data                | only
        // SN-SPLIT    | SCG         | O        | shared                 | shared

        switch (ptDi->selectedBearerType.val)
        {
            case SN_Term_SCG_Bearer:
                pBuffer[cellGroupListNum].value.bit_mask =
                    E1_Cell_Group_Information_Item_uL_Configuration_present | E1_rAT_Type_present;
                pBuffer[cellGroupListNum].value.cell_Group_ID = CellGroupId_SCG;
                pBuffer[cellGroupListNum].value.uL_Configuration = E1_only;
                pBuffer[cellGroupListNum].value.rAT_Type = E1_RAT_Type_nR;
                pBuffer[cellGroupListNum].next = nullptr;
                cellGroupListNum++;  // 1
                break;

            case SN_Term_SPLIT_Bearer:
                // MCG Bearer
                pBuffer[cellGroupListNum].value.bit_mask =
                    E1_Cell_Group_Information_Item_uL_Configuration_present | E1_rAT_Type_present;
                pBuffer[cellGroupListNum].value.cell_Group_ID = CellGroupId_MCG;
                {
                    E1_UL_Configuration ulConfig = E1_shared;
                    switch (ptDi->ulPdcpPath)
                    {
                        case UlPdcpPath_ScgShared:
                            ulConfig =
                                ((TRUE == FnVCCB_GetUeCapaSplitDRB_withUL_Both_MCG_SCG_NRDC(ptCi)) ? (E1_shared)
                                                                                                   : (E1_no_data));
                            break;
                        case UlPdcpPath_McgShared:
                        case UlPdcpPath_McgOnly:
                            ulConfig = E1_only;
                            break;
                        default:
                            ulConfig = E1_no_data;
                    }
                    pBuffer[cellGroupListNum].value.uL_Configuration = ulConfig;
                }
                pBuffer[cellGroupListNum].value.rAT_Type = E1_RAT_Type_nR;
                cellGroupListNum++;  // 1

                // SCG Bearer
                pBuffer[cellGroupListNum].value.bit_mask =
                    E1_Cell_Group_Information_Item_uL_Configuration_present | E1_rAT_Type_present;
                pBuffer[cellGroupListNum].value.cell_Group_ID = CellGroupId_SCG;

                {
                    E1_UL_Configuration ulConfig = E1_shared;
                    switch (ptDi->ulPdcpPath)
                    {
                        case UlPdcpPath_McgShared:
                            ulConfig =
                                ((TRUE == FnVCCB_GetUeCapaSplitDRB_withUL_Both_MCG_SCG_NRDC(ptCi)) ? (E1_shared)
                                                                                                   : (E1_no_data));
                            break;
                        case UlPdcpPath_ScgOnly:
                        case UlPdcpPath_ScgShared:
                            ulConfig = E1_only;
                            break;
                        default:
                            ulConfig = E1_no_data;
                    }
                    pBuffer[cellGroupListNum].value.uL_Configuration = ulConfig;
                }
                pBuffer[cellGroupListNum].value.rAT_Type = E1_RAT_Type_nR;
                cellGroupListNum++;  // 2

                // Connect Cell Group Information List
                if (ERROR == VCCB_ConnectLinkedList(pBuffer, cellGroupListNum))
                {
                    VCCB_PRINT_CALL_ERROR(
                        ptCi, "ERROR: VCCB_ConnectLinkedList failed in FnVCCB_FillCellGroupInformationSA\n");
                    return ERROR;
                }
                break;

            default:
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "Invalid selectedBearerType(%u) - drbId:%d!\n", ptDi->selectedBearerType.val, ptDi->dRBId);
                return ERROR;
        }
    }
    else  // Basic SA Call / NRDC_MN
    {
        pBuffer[cellGroupListNum].value.bit_mask = E1_rAT_Type_present;
        pBuffer[cellGroupListNum].value.rAT_Type = E1_RAT_Type_nR;
        pBuffer[cellGroupListNum].value.cell_Group_ID = CellGroupId_MCG;
        pBuffer[cellGroupListNum].next = nullptr;
        pBuffer[cellGroupListNum].value.bit_mask |= E1_Cell_Group_Information_Item_uL_Configuration_present;
        pBuffer[cellGroupListNum].value.uL_Configuration = E1_only;
        cellGroupListNum++;  // 1

        // UL Configuration - optional
        // DL TX Stop - optional

        if (IS_MRDC_MN(ptCi))
        {
            uint8_t reqBearerType = FnVCCB_getSaDrbBearerType(ptCi, ptDi, request_bearerType);

            // is MN split
            switch (reqBearerType)
            {
                case MN_Term_SPLIT_Bearer:
                {
                    cellGroupListNum = 0;  // reconfigure
                    pBuffer[cellGroupListNum].value.bit_mask = E1_rAT_Type_present;
                    pBuffer[cellGroupListNum].value.rAT_Type = E1_RAT_Type_nR;
                    pBuffer[cellGroupListNum].value.cell_Group_ID = CellGroupId_MCG;
                    pBuffer[cellGroupListNum].next = nullptr;

                    E1_UL_Configuration ulConfig = E1_shared;  // E1_only;
                    switch (ptDi->ulPdcpPath)
                    {
                        case UlPdcpPath_ScgShared:
                            ulConfig =
                                ((TRUE == FnVCCB_GetUeCapaSplitDRB_withUL_Both_MCG_SCG_NRDC(ptCi)) ? (E1_shared)
                                                                                                   : (E1_no_data));
                            break;
                        case UlPdcpPath_McgShared:
                        case UlPdcpPath_McgOnly:
                            ulConfig = E1_only;
                            break;
                        default:
                            ulConfig = E1_no_data;
                    }
                    pBuffer[cellGroupListNum].value.bit_mask |= E1_Cell_Group_Information_Item_uL_Configuration_present;
                    pBuffer[cellGroupListNum].value.uL_Configuration = ulConfig;
                    cellGroupListNum++;  // 1
                    ////////////////////////////////////////////////////////
                    pBuffer[cellGroupListNum].value.bit_mask = E1_rAT_Type_present;
                    pBuffer[cellGroupListNum].value.rAT_Type = E1_RAT_Type_nR;
                    pBuffer[cellGroupListNum].value.cell_Group_ID = CellGroupId_SCG;
                    pBuffer[cellGroupListNum].next = nullptr;

                    ulConfig = E1_shared;
                    switch (ptDi->ulPdcpPath)
                    {
                        case UlPdcpPath_ScgShared:
                            ulConfig = E1_only;
                            break;
                        case UlPdcpPath_McgShared:
                            ulConfig =
                                ((TRUE == FnVCCB_GetUeCapaSplitDRB_withUL_Both_MCG_SCG_NRDC(ptCi)) ? (E1_shared)
                                                                                                   : (E1_no_data));
                            break;
                        case UlPdcpPath_ScgOnly:
                            ulConfig = E1_only;
                            break;
                        default:
                            ulConfig = E1_no_data;
                    }
                    pBuffer[cellGroupListNum].value.bit_mask |= E1_Cell_Group_Information_Item_uL_Configuration_present;
                    pBuffer[cellGroupListNum].value.uL_Configuration = ulConfig;
                    cellGroupListNum++;  // 2

                    // DL TX Stop - optional
                    // RAT Type -optional
                }
                break;
                default:
                    break;
            }
        }

        if (ERROR == VCCB_ConnectLinkedList(pBuffer, cellGroupListNum))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_ConnectLinkedList failed in FnVCCB_FillCellGroupInformationSA\n");
            return ERROR;
        }
    }

    return GOOD;
}

bool VEIL_check_Data_Forwarding_Eutran_Information_List(callInfo_type *ptCi, callPDUSessInfo_type *ptPi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptPi, false);

    // Inter SN mobility Source SN
    if (((STATE_SN_SNRelExec != ptCi->state) && (STATE_INTER_SeqNum_S != ptCi->state)) ||
        (!GNBINFO[ptCi->gnbNum].cfg.interSysDirectDataFwd))
    {
        return false;
    }

    for (uint16_t &qosFlowIdx : ptPi->qosFlowIndex)
    {
        if (MAX_QOS_FLOW_PER_CALL <= qosFlowIdx)
        {
            continue;
        }

        qosFlowInfo_type qosFlow = ptCi->qosFlow[qosFlowIdx];
        if (CI_use != qosFlow.usage)
        {
            continue;
        }
        if (0 > qosFlow.erabId)
        {
            continue;
        }

        if (VCCB_FLAG_OFF == qosFlow.dataFwdErabInfo.fNeedModify)
        {
            continue;
        }

        uint8_t fiveQi = qosFlow.qosParam.nonDyna.fiveQi;
        pdcpInfo5qi_type *pPdcpInfo = NULL;
        pPdcpInfo = FnVCCB_GetPdcpInfo5qi(ptCi->servCellNum, ptCi->gnbNum, fiveQi);
        if (NULL == pPdcpInfo)
        {
            continue;
        }
        const uint8_t dbDLSrcEnabled = pPdcpInfo->srcDlFwd;
        const uint8_t dbULSrcEnabled = pPdcpInfo->srcUlFwd;

        if (dbDLSrcEnabled || dbULSrcEnabled)
        {
            return true;
        }
    }

    return false;
}

int16_t FnVCCB_FillE1_DataForwardingToEUTRANInformationList(callInfo_type *ptCi, callPDUSessInfo_type *ptPi,
    E1_BearerContextModificationRequestBuffer::PduSessToBeModData &buffer)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptPi);

    int16_t status = 0;
    int numItems = 0;

    uint8_t drbIdxNums[MAX_DRB_PER_SA_CALL] = {
        0,
    };

    for (long drbIdx = 0; (drbIdx < MAX_DRB_PER_SA_CALL) && (numItems < MAX_ERAB_PER_CALL); ++drbIdx)
    {
        int numQosFlow = 0;
        E1_DataForwardingtoE_UTRANInformationListItem *p_DataForwardingEutran =
            &buffer.dataForwardingtoEUTRANInformationList[numItems].value;

        for (uint16_t &qosIdx : ptPi->qosFlowIndex)
        {
            if (MAX_QOS_FLOW_PER_CALL <= qosIdx)
            {
                continue;
            }
            qosFlowInfo_type *ptQi = &ptCi->qosFlow[qosIdx];
            if (CI_use != ptQi->usage)
            {
                continue;
            }
            if (ptQi->drbIdxInCall != drbIdx)
            {
                continue;
            }
            if (VCCB_FLAG_OFF == ptQi->dataFwdErabInfo.fNeedModify)
            {
                continue;
            }

            uint8_t fiveQi = ptQi->qosParam.nonDyna.fiveQi;
            pdcpInfo5qi_type *pPdcpInfo = NULL;
            pPdcpInfo = FnVCCB_GetPdcpInfo5qi(ptCi->servCellNum, ptCi->gnbNum, fiveQi);
            if (NULL == pPdcpInfo)
            {
                continue;
            }
            if (N_EQUIP == pPdcpInfo->srcDlFwd)
            {
                continue;
            }

            if (MAX_DRB_PER_SA_CALL <= ptQi->drbIdxInCall)
            {
                continue;
            }

            // Skip SN term bearers
            callDRBInfo_type *ptDi = &ptCi->drb[ptQi->drbIdxInCall];
            if (IS_MRDC_MN(ptCi) && (FnVCCB_IsMnTermPerDRB(ptCi, ptDi, request_bearerType) == false))
            {
                continue;
            }
            else if (IS_NRDC_SN(ptCi) && (TermPoint_Sn != ptDi->bearerType.termPoint))
            {
                continue;
            }

            if (0 == drbIdxNums[drbIdx])
            {
                p_DataForwardingEutran->bit_mask = 0;
                p_DataForwardingEutran->iE_Extensions = NULL;

                status = static_cast<int16_t>(VEIL_fillE1_UP_TNL_Information(
                    &p_DataForwardingEutran->data_forwarding_tunnel_information, &ptQi->dataFwdErabInfo));
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_UP_TNL_Information ERROR in %s!\n", __func__);
            }
            ++drbIdxNums[drbIdx];

            E1_QoS_Flows_to_be_forwarded_Item *p_QoSFlowToBeForwarded =
                &buffer.dataFwdtoEUTRAN[numItems].qoSFlowstobeforwarded_List[numQosFlow].value;

            p_QoSFlowToBeForwarded->bit_mask = 0;
            p_QoSFlowToBeForwarded->iE_Extensions = NULL;
            p_QoSFlowToBeForwarded->qoS_Flow_Identifier = ptQi->flowId;
            ++numQosFlow;
        }

        if (0 == numQosFlow) continue;

        status = VCCB_ConnectLinkedList(buffer.dataFwdtoEUTRAN[numItems].qoSFlowstobeforwarded_List, numQosFlow);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "fnConnectLinkedList failed QoS Flows To Be Forwarded List!\n");

        p_DataForwardingEutran->qoS_Flows_to_be_forwarded_List =
            buffer.dataFwdtoEUTRAN[numItems].qoSFlowstobeforwarded_List;
        ++numItems;
    }

    if (0 < numItems)
    {
        status = VCCB_ConnectLinkedList(buffer.dataForwardingtoEUTRANInformationList, numItems);
        VCCB_RETURN_ON_CALL_ERROR(
            ptCi, status, "VCCB_ConnectLinkedList failed Data Forwarding to E-UTRAN Information!\n");
    }
    else
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Skip E1_id_DataForwardingtoE_UTRANInformationList there are no items in the list!\n");
        return ERROR;
    }

    buffer.pDataForwardingtoEUTRANInformationList = buffer.dataForwardingtoEUTRANInformationList;

    return GOOD;
}

/**
 * @brief fill E1 DRB To Setup Item for Bearer Context Setup Request Procedure
 * @attention function sets all bit_mask
 * @param [in]     ptCi                     : callInfo DB
 * @param [in]     drbIdx                   : DRB index in ptCi array
 * @param [in]     numDrb                   : DRB number in pdu session
 * @param [in/out] ptPduSessToBeSetupBuffer : E1_BearerContextSetupRequestBuffer::PduSessToBeSetupData
 * @return         GOOD                     : success fill
 * @return         ERROR                    : fill error
 */
int VEIL_fillE1_DRBToSetupItem(callInfo_type *ptCi, uint8_t drbIdx, uint16_t numDrb,
    E1_BearerContextSetupRequestBuffer::PduSessToBeSetupData *ptPduSessToBeSetupBuffer, enumE1F1procedure_type procedure)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptPduSessToBeSetupBuffer);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(drbIdx, MAX_DRB_PER_SA_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(numDrb, MAX_DRB_PER_PDU_SESS);

    int status = GOOD;
    callDRBInfo_type *pDRBInfo = &ptCi->drb[drbIdx];
    E1_DRB_To_Setup_Item_NG_RAN *drbToSetupItem = &ptPduSessToBeSetupBuffer->drbToSetupList[numDrb].value;
    DrbToBeSetupData *ptDrbToBeSetupBuffer = &ptPduSessToBeSetupBuffer->drbToSetupData[numDrb];
    uint16_t drbQosIdxInCall = pDRBInfo->drbQosIdxInCall;
    qosFlowInfo_type *ptQi = NULL;
    bool qosFlowMonitoringPresent = false;

    // Prepare : update the pack buffer to asn header
    drbToSetupItem->cell_Group_Information = ptDrbToBeSetupBuffer->cellGroupList;
    drbToSetupItem->qos_flow_Information_To_Be_Setup = ptDrbToBeSetupBuffer->qosFlowToBeSetupList;

    // Prepare : init bit_mask
    drbToSetupItem->bit_mask = 0;

    // 1. M - DRB ID (9_3_1_16)
    drbToSetupItem->dRB_ID = pDRBInfo->dRBId;

    // 2. M - SDAP Configuration (9_3_1_39)
    status = VEIL_fillE1_SDAP_ConfigurationInfo(&drbToSetupItem->sDAP_Configuration, ptCi, pDRBInfo);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_SDAP_ConfigurationInfo ERROR!\n");

    // 3. M - PDCP Configuration (9_3_1_38)
    status = VEIL_fillE1_PDCP_ConfigurationInfo(ptPduSessToBeSetupBuffer,&drbToSetupItem->pDCP_Configuration, ptCi, pDRBInfo,numDrb);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_PDCP_ConfigurationInfo ERROR!\n");

    // 4. M - Cell Group Information (9_3_1_11)
    status = FnVCCB_FillCellGroupInformationBuffer_SADrbSetup(ptDrbToBeSetupBuffer->cellGroupList, ptCi, pDRBInfo);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_FillCellGroupInformationBuffer_SADrbSetup ERROR!\n");

    // 5. M - QoS Flows Information To Be Setup (9_3_1_25)
    unsigned int loop = 0, numQoSFlow = 0;
    for (loop = 0; loop < MAX_QOS_FLOW_PER_DRB; loop++)
    {
        if (pDRBInfo->qosFlowIndex[loop] >= MAX_QOS_FLOW_PER_CALL)  // Not yet allocated
            continue;

        ptQi = &ptCi->qosFlow[pDRBInfo->qosFlowIndex[loop]];

        if (CI_use != ptQi->usage) continue;

        VCCB_PRINT_CALL_DATA(ptCi, "[E1DBG] ptCi->qosFlow[%d].usage is CI_use\n", pDRBInfo->qosFlowIndex[loop]);

        if (VLIB_IsCommonValidStateOfPduQosDrb(ptQi->qosFlowStatus) != GOOD)
        {
            continue;
        }

        // QoS Flow Item - mandatory
        status = VEIL_fillE1_QoSFlowItem(ptCi, &ptDrbToBeSetupBuffer->qosFlowToBeSetupList[numQoSFlow].value, ptQi, pDRBInfo->pduIdxInCall, numQoSFlow, procedure);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_QoSFlowItem ERROR!\n");

        // iE_Extensions - QoSFlowLevelQoSParameters-ExtIEs 
        // QosMonitoring
        E1_QosMonitoringRequest* ptQosMonitoringRequest = &ptPduSessToBeSetupBuffer->qosMonitoringRequest[numDrb][numQoSFlow];
        E1_QosMonitoringDisabled* ptQosMonitoringDisabled = &ptPduSessToBeSetupBuffer->qosMonitoringDisabled[numDrb][numQoSFlow];
        struct E1_ProtocolExtensionContainer_ *pContainer = &ptPduSessToBeSetupBuffer->qosMonitoringRequestBuf[numDrb][numQoSFlow];

        status = FnVCCB_Fill_QosMonitoringInfo_ForQosFlow_E1(ptCi, ptQi, ptQosMonitoringRequest, ptQosMonitoringDisabled, pContainer, false);
        if(status == GOOD)
        {
            ptDrbToBeSetupBuffer->qosFlowToBeSetupList[numQoSFlow].value.qoSFlowLevelQoSParameters.bit_mask |= E1_QoSFlowLevelQoSParameters_iE_Extensions_present;
            ptDrbToBeSetupBuffer->qosFlowToBeSetupList[numQoSFlow].value.qoSFlowLevelQoSParameters.iE_Extensions = pContainer;
            qosFlowMonitoringPresent = true;
        }
        ++numQoSFlow;
    }

    if (numQoSFlow == 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "No QFI in DRB To Setup List!\n");
        return ERROR;
    }

    // Connect QoS Flow QoS Parameters List
    status = VCCB_ConnectLinkedList(drbToSetupItem->qos_flow_Information_To_Be_Setup, static_cast<int>(numQoSFlow));
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, status, "VCCB_ConnectLinkedList failed in %s-> QoS Flow QoS Parameters List!\n", __func__);

    // 6. O - DRB Data forwarding information Request (9_3_2_5)
    if (VEIL_checkE1_data_fwd_information_request_for_sa_mobility(ptCi, pDRBInfo) == GOOD)
    {
        status = VEIL_fillE1_DRB_Setup_Data_Forwarding_Information_request(
            drbToSetupItem, ptDrbToBeSetupBuffer, ptCi, pDRBInfo);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_DRB_Data_Forwarding_Information_request ERROR!\n");
    }

    // 7. O - DRB Inactivity Timer (9_3_1_54)
    if (true == VEIL_check_E1_Inactivity_Timer(ptCi, pDRBInfo))
    {
        status = VEIL_fillE1_Inactivity_Timer(ptCi, pDRBInfo, &drbToSetupItem->dRB_Inactivity_Timer);
        if (status == GOOD)
        {
            drbToSetupItem->bit_mask |= E1_DRB_To_Setup_Item_NG_RAN_dRB_Inactivity_Timer_present;
        }
    }

    // 8. O - PDCP SN Status Information (9_3_1_58)

    // 9. O - DRB QoS (9_3_1_26)
    if (numQoSFlow > 1)
    {
        if (drbQosIdxInCall < MAX_QOS_FLOW_PER_CALL &&
            IS_VALID_NODE(QOSFLOW_NODE, ptCi, &(ptCi->qosFlow[drbQosIdxInCall])))
        {
            E1_QoSFlowLevelQoSParameters *pDrbQos = &ptDrbToBeSetupBuffer->drbQosItem;

            qosRscIdx_type qosIdxInfo;
            qosIdxInfo.pduIdx = pDRBInfo->pduIdxInCall;
            qosIdxInfo.drbIdx = drbIdx;
            qosIdxInfo.qosFlowIdx = static_cast<uint8_t>(drbQosIdxInCall);

            status = VEIL_fillE1_DrbQos(ptCi, pDrbQos, &ptCi->qosFlow[drbQosIdxInCall], qosIdxInfo, E1F1Setup);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_DrbQos ERROR!\n");

            drbToSetupItem->bit_mask |= E1_DRB_To_Setup_Item_NG_RAN_iE_Extensions_present;
            drbToSetupItem->iE_Extensions = &ptDrbToBeSetupBuffer->drbQos;
            drbToSetupItem->iE_Extensions->next = NULL;

            InsertE1_ExtensionContainerValue(
                drbToSetupItem->iE_Extensions, E1_id_DRB_QoS, E1_ignore, pDrbQos, E1_QoSFlowLevelQoSParameters_PDU);
        }
    }

    if(numQoSFlow == 1)
    {
        if((qosFlowMonitoringPresent == false) && (pDRBInfo->drbQosMonitoring == QOS_MONITORING_REQUEST_STOP))
        {
            // fill drbQosMonitor to remained qosflow (alternative)
            for(auto qosFlowIndex : pDRBInfo->qosFlowIndex)
            {
                if (qosFlowIndex >= MAX_QOS_FLOW_PER_CALL) continue;
                auto &qosFlow = ptCi->qosFlow[qosFlowIndex];

                if (CI_use != qosFlow.usage) continue;
                if (VLIB_IsCommonValidStateOfPduQosDrb(qosFlow.qosFlowStatus) != GOOD) continue;

                // fill drbQosMonitor to remained qosflow
                E1_QosMonitoringRequest* ptQosMonitoringRequest = &ptPduSessToBeSetupBuffer->qosMonitoringRequest[numDrb][0]; // qosFlowIdx is 0 when numQosFlow == 1 
                E1_QosMonitoringDisabled* ptQosMonitoringDisabled = &ptPduSessToBeSetupBuffer->qosMonitoringDisabled[numDrb][0];
                struct E1_ProtocolExtensionContainer_ *pContainer = &ptPduSessToBeSetupBuffer->qosMonitoringRequestBuf[numDrb][0];

                status = FnVCCB_Fill_QosMonitoringInfo_ForQosFlow_E1(ptCi, &qosFlow, ptQosMonitoringRequest, ptQosMonitoringDisabled, pContainer, true);
                if(status == GOOD)
                {
                    ptDrbToBeSetupBuffer->qosFlowToBeSetupList[0].value.qoSFlowLevelQoSParameters.bit_mask |= E1_QoSFlowLevelQoSParameters_iE_Extensions_present;
                    ptDrbToBeSetupBuffer->qosFlowToBeSetupList[0].value.qoSFlowLevelQoSParameters.iE_Extensions = pContainer;
                }
                break;
            }
        }
    }

    if (FALSE == ptCi->trafficMonitoringCfg.trafficReportDrbList[drbIdx].isSameCfgFlag)
    {
        bool isExtensionPresent = drbToSetupItem->bit_mask & E1_DRB_To_Setup_Item_NG_RAN_iE_Extensions_present;
        if (GOOD == FnVCCB_FillE1_ReportConfigList(
                        ptCi, drbIdx, *ptDrbToBeSetupBuffer, isExtensionPresent, drbToSetupItem->iE_Extensions))
        {
            drbToSetupItem->bit_mask |= E1_DRB_To_Setup_Item_NG_RAN_iE_Extensions_present;
        }
    }

    // 10. O - VoMA Request E1 (Samsung)
    if (ptCi->vomaInfo.vomaAllowed && 
        VOMA_UNKNOWN == pDRBInfo->vomaStatus.upStatus &&
        VLIB_VomaCheckDrb5QISupport(*ptCi, drbIdx))
    {
        ptDrbToBeSetupBuffer->vomaRequest = E1_preparation;
        pDRBInfo->vomaStatus.upStatus = VOMA_PREPARATION_REQ;
        if (ptCi->vomaInfo.e1ModCnt)
        {
            ptCi->vomaInfo.vomaEvent = VOMA_drbSetup;
        }

        bool isExtensionPresent = drbToSetupItem->bit_mask & E1_DRB_To_Setup_Item_NG_RAN_iE_Extensions_present;
        if (GOOD == VEIL_AddE1ExtensionToLinkedList(ptCi, isExtensionPresent, &drbToSetupItem->iE_Extensions,
                        &ptDrbToBeSetupBuffer->vomaRequestContainer, &ptDrbToBeSetupBuffer->vomaRequest,
                        E1_id_SamsungVOMAE1Request, E1_SamsungVOMAE1Request_PDU))
        {
            drbToSetupItem->bit_mask |= E1_DRB_To_Setup_Item_NG_RAN_iE_Extensions_present;
        }
    }

#ifdef IPC_TEST
    FnVCCB_CheckE1_DRBToSetupItem(*ptCi, *pDRBInfo, *drbToSetupItem);
#endif

    return status;
}

/**
 * @brief fill E1 DRB To Setup Item EUTRAN for Bearer Context Modification Request Procedure
 * @attention function sets all bit_mask
 * @param [in]  ptBearerModificationRequestBuffer   : E1_BearerContextModificationRequestBuffer buffer
 * @param [in]  pDRBInfo                            : callDRBInfo DB
 * @param [in]  ptCi                                : callInfo DB
 * @param [out] drbToSetupModItem                   : E1_DRB_To_Setup_Mod_Item_NG_RAN buffer
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_fillE1_DRBToSetupModItem(E1_DRB_To_Setup_Mod_Item_NG_RAN *drbToSetupModItem,
    E1_BearerContextModificationRequestBuffer::PduSessToBeSetupModData::DrbToBeSetupModData *ptDrbToBeSetupModBuffer,
    callInfo_type *ptCi, uint8_t drbIdx,
    E1_BearerContextModificationRequestBuffer::PduSessToBeSetupModData *ptPduSessToBeSetupModBuffer,
    unsigned int numDrb, enumE1F1procedure_type procedure)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(drbToSetupModItem);
    VALID_E_POINT_CHECK_ERROR(ptDrbToBeSetupModBuffer);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(drbIdx, MAX_DRB_PER_SA_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    int status = GOOD;
    callDRBInfo_type *pDRBInfo = &ptCi->drb[drbIdx];
    uint16_t drbQosIdxInCall = pDRBInfo->drbQosIdxInCall;
    qosFlowInfo_type *ptQi = NULL;
    bool qosFlowMonitoringPresent = false;

    // Prepare : update the pack buffer to asn header
    drbToSetupModItem->cell_Group_Information = ptDrbToBeSetupModBuffer->cellGroupList;
    drbToSetupModItem->flow_Mapping_Information = ptDrbToBeSetupModBuffer->flowMappingList;

    // Prepare : init bit_mask
    drbToSetupModItem->bit_mask = 0;

    // 1. M - DRB ID (9_3_1_16)
    drbToSetupModItem->dRB_ID = pDRBInfo->dRBId;

    // 2. M - SDAP Configuration (9_3_1_39)
    status = VEIL_fillE1_SDAP_ConfigurationInfo(&drbToSetupModItem->sDAP_Configuration, ptCi, pDRBInfo);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_SDAP_ConfigurationInfo ERROR!\n");

    // 3. M - PDCP Configuration (9_3_1_38)
    status = VEIL_fillE1_PDCP_ConfigurationInfo_SetupToMod(ptDrbToBeSetupModBuffer,&drbToSetupModItem->pDCP_Configuration, ptCi, pDRBInfo);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_PDCP_ConfigurationInfo_SetupToMod ERROR!\n");

    // 4. M - Cell Group Information (9_3_1_11)
    status = FnVCCB_FillCellGroupInformationBuffer_SADrbSetup(ptDrbToBeSetupModBuffer->cellGroupList, ptCi, pDRBInfo);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_FillCellGroupInformationBuffer_SADrbSetup ERROR!\n");

    // 5. M - QoS Flows Information To Be Setup (9_3_1_25)
    unsigned int loop = 0, numQoSFlow = 0;
    for (loop = 0; loop < MAX_QOS_FLOW_PER_DRB; loop++)
    {
        if (pDRBInfo->qosFlowIndex[loop] >= MAX_QOS_FLOW_PER_CALL)  // Not yet allocated
            continue;

        ptQi = &ptCi->qosFlow[pDRBInfo->qosFlowIndex[loop]];

        if (CI_use != ptQi->usage) continue;

        VCCB_PRINT_CALL_DATA(ptCi, "[E1DBG] ptCi->qosFlow[%d].usage is CI_use\n", pDRBInfo->qosFlowIndex[loop]);

        if (VLIB_IsCommonValidStateOfPduQosDrb(ptQi->qosFlowStatus) != GOOD)
        {
            continue;
        }

        // QoS Flow Item
        status = VEIL_fillE1_QoSFlowItem(ptCi, &ptDrbToBeSetupModBuffer->flowMappingList[numQoSFlow].value, ptQi, pDRBInfo->pduIdxInCall, numQoSFlow, procedure);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_QoSFlowItem ERROR!\n");

        E1_QosMonitoringRequest* ptQosMonitoringRequest = &ptPduSessToBeSetupModBuffer->qosMonitoringRequest[numDrb][numQoSFlow];
        E1_QosMonitoringDisabled* ptQosMonitoringDisabled = &ptPduSessToBeSetupModBuffer->qosMonitoringDisabled[numDrb][numQoSFlow];
        struct E1_ProtocolExtensionContainer_ *pContainer = &ptPduSessToBeSetupModBuffer->qosMonitoringRequestBuf[numDrb][numQoSFlow];

        status = FnVCCB_Fill_QosMonitoringInfo_ForQosFlow_E1(ptCi, ptQi, ptQosMonitoringRequest, ptQosMonitoringDisabled, pContainer, false);
        if(status == GOOD)
        {
            ptDrbToBeSetupModBuffer->flowMappingList[numQoSFlow].value.qoSFlowLevelQoSParameters.bit_mask |= E1_QoSFlowLevelQoSParameters_iE_Extensions_present;  
            ptDrbToBeSetupModBuffer->flowMappingList[numQoSFlow].value.qoSFlowLevelQoSParameters.iE_Extensions = pContainer;
            qosFlowMonitoringPresent = true;
        }
        ++numQoSFlow;
    }

    if (numQoSFlow == 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "No QFI in DRB To Setup List!\n");
        return ERROR;
    }

    // Connect QoS Flow QoS Parameters List
    status = VCCB_ConnectLinkedList(drbToSetupModItem->flow_Mapping_Information, static_cast<int>(numQoSFlow));
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, status, "VCCB_ConnectLinkedList failed in %s-> QoS Flow QoS Parameters List!\n", __func__);

    // 6. O - DRB Data forwarding information Request (9_3_2_5)
    if (VEIL_checkE1_data_fwd_information_request_for_sa_mobility(ptCi, pDRBInfo) == GOOD)
    {
        status = VEIL_fillE1_DRB_Setup_Mod_Data_Forwarding_Information_request(
            drbToSetupModItem, ptDrbToBeSetupModBuffer, ptCi, pDRBInfo);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_DRB_Data_Forwarding_Information_request ERROR!\n");
    }

    // 7. O - DRB Inactivity Timer (9_3_1_54)
    if (true == VEIL_check_E1_Inactivity_Timer(ptCi, pDRBInfo))
    {
        status = VEIL_fillE1_Inactivity_Timer(ptCi, pDRBInfo, &drbToSetupModItem->dRB_Inactivity_Timer);
        if (status == GOOD)
        {
            drbToSetupModItem->bit_mask |= E1_DRB_To_Setup_Mod_Item_NG_RAN_dRB_Inactivity_Timer_present;
        }
    }

    // 8. O - PDCP SN Status Information (9_3_1_58)
    status = VEIL_fillE1_PDCP_SN_Status_Information_Setup(ptCi, pDRBInfo, drbToSetupModItem, ptDrbToBeSetupModBuffer);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_PDCP_SN_Status_Information_Setup ERROR in %s!\n", __func__);

    // iE-Extensions : DRB-To-Setup-Mod-Item-NG-RAN-ExtIEs

    // 9. O - DRB QoS (9_3_1_26)
    if (numQoSFlow > 1)
    {
        if (drbQosIdxInCall < MAX_QOS_FLOW_PER_CALL &&
            IS_VALID_NODE(QOSFLOW_NODE, ptCi, &(ptCi->qosFlow[drbQosIdxInCall])))
        {
            E1_QoSFlowLevelQoSParameters *pDrbQos = &ptDrbToBeSetupModBuffer->drbQosItem;

            qosRscIdx_type qosIdxInfo;
            qosIdxInfo.pduIdx = pDRBInfo->pduIdxInCall;
            qosIdxInfo.drbIdx = drbIdx;
            qosIdxInfo.qosFlowIdx = static_cast<uint8_t>(drbQosIdxInCall);

            status = VEIL_fillE1_DrbQos(ptCi, pDrbQos, &ptCi->qosFlow[drbQosIdxInCall], qosIdxInfo, E1F1Modify_SetupMod);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_DrbQos ERROR!\n");

            drbToSetupModItem->bit_mask |= E1_DRB_To_Setup_Mod_Item_NG_RAN_iE_Extensions_present;
            drbToSetupModItem->iE_Extensions = &ptDrbToBeSetupModBuffer->drbQos;
            drbToSetupModItem->iE_Extensions->next = NULL;

            InsertE1_ExtensionContainerValue(
                drbToSetupModItem->iE_Extensions, E1_id_DRB_QoS, E1_ignore, pDrbQos, E1_QoSFlowLevelQoSParameters_PDU);
        }
    }

    if(numQoSFlow == 1)
    {
        // drbQos qosMonitor exist, but  qosflow qosMonitor doesn't exist
        if((qosFlowMonitoringPresent == false) && (pDRBInfo->drbQosMonitoring == QOS_MONITORING_REQUEST_STOP))
        {
            // fill drbQosMonitor to remained qosflow (alternative)
            if (drbQosIdxInCall < MAX_QOS_FLOW_PER_CALL &&
                IS_VALID_NODE(QOSFLOW_NODE, ptCi, &(ptCi->qosFlow[drbQosIdxInCall])))
            {
                auto &qosFlow = ptCi->qosFlow[drbQosIdxInCall];

                // fill drbQosMonitor to remained qosflow
                E1_QosMonitoringRequest* ptQosMonitoringRequest = &ptPduSessToBeSetupModBuffer->qosMonitoringRequest[numDrb][0]; // qosFlowIdx is 0 when numQosFlow == 1 
                E1_QosMonitoringDisabled* ptQosMonitoringDisabled = &ptPduSessToBeSetupModBuffer->qosMonitoringDisabled[numDrb][0];
                struct E1_ProtocolExtensionContainer_ *pContainer = &ptPduSessToBeSetupModBuffer->qosMonitoringRequestBuf[numDrb][0];

                status = FnVCCB_Fill_QosMonitoringInfo_ForQosFlow_E1(ptCi, &qosFlow, ptQosMonitoringRequest, ptQosMonitoringDisabled, pContainer, true);
                if(status == GOOD)
                {
                    ptDrbToBeSetupModBuffer->flowMappingList[0].value.qoSFlowLevelQoSParameters.bit_mask |= E1_QoSFlowLevelQoSParameters_iE_Extensions_present;
                    ptDrbToBeSetupModBuffer->flowMappingList[0].value.qoSFlowLevelQoSParameters.iE_Extensions = pContainer;
                }
            }
        }
    }    

    // DRB DL traffic status configuration.
    if (FALSE == ptCi->trafficMonitoringCfg.trafficReportDrbList[drbIdx].isSameCfgFlag)
    {
        bool isExtensionPresent = drbToSetupModItem->bit_mask & E1_DRB_To_Setup_Mod_Item_NG_RAN_iE_Extensions_present;
        if (GOOD == FnVCCB_FillE1_ReportConfigList(
                        ptCi, drbIdx, *ptDrbToBeSetupModBuffer, isExtensionPresent, drbToSetupModItem->iE_Extensions))
        {
            drbToSetupModItem->bit_mask |= E1_DRB_To_Setup_Mod_Item_NG_RAN_iE_Extensions_present;
        }
    }

    // VoMA Request E1 (Samsung)
    // SVR26A FGR-TA0601 VoMA CallEvent
    ptCi->vomaInfo.vomaEvent = VOMA_drbSetup;
    if (ptCi->vomaInfo.vomaAllowed && 
        VOMA_UNKNOWN == pDRBInfo->vomaStatus.upStatus &&
        VLIB_VomaCheckDrb5QISupport(*ptCi, drbIdx))
    {
        ptDrbToBeSetupModBuffer->vomaRequest = E1_preparation;
        pDRBInfo->vomaStatus.upStatus = VOMA_PREPARATION_REQ;

        bool isExtensionPresent = drbToSetupModItem->bit_mask & E1_DRB_To_Setup_Mod_Item_NG_RAN_iE_Extensions_present;
        if (GOOD == VEIL_AddE1ExtensionToLinkedList(ptCi, isExtensionPresent, &drbToSetupModItem->iE_Extensions,
                        &ptDrbToBeSetupModBuffer->vomaRequestContainer, &ptDrbToBeSetupModBuffer->vomaRequest,
                        E1_id_SamsungVOMAE1Request, E1_SamsungVOMAE1Request_PDU))
        {
            drbToSetupModItem->bit_mask |= E1_DRB_To_Setup_Mod_Item_NG_RAN_iE_Extensions_present;
        }
    }

#ifdef IPC_TEST
    FnVCCB_CheckE1_DRBToSetupItem(*ptCi, *pDRBInfo, *drbToSetupModItem);
#endif

    return status;
}

VCCB_STATIC_INLINE
void VEIL_decideE1_McgCellGroup_UlConfig(uint8_t ulPdcpPath, uint8_t ueCapa_splitDRB_withUL_Both_MCG_SCG,
    E1_UL_Configuration *ulConfig)
{
    VALID_E_POINT_CHECK_VOID(ulConfig);

    switch (ulPdcpPath)
    {
        case UlPdcpPath_ScgShared:
            *ulConfig = ((TRUE == ueCapa_splitDRB_withUL_Both_MCG_SCG) ? (E1_shared) : (E1_no_data));
            break;

        case UlPdcpPath_McgShared:
        case UlPdcpPath_McgOnly:
            *ulConfig = E1_only;
            break;
                                                                                                            
        default:
            *ulConfig = E1_no_data;
    }

    return;
}

VCCB_STATIC_INLINE
void VEIL_decideE1_ScgCellGroup_UlConfig(uint8_t ulPdcpPath, uint8_t ueCapa_splitDRB_withUL_Both_MCG_SCG,
    E1_UL_Configuration *ulConfig)
{
    VALID_E_POINT_CHECK_VOID(ulConfig);

    switch (ulPdcpPath)
    {
        case UlPdcpPath_McgShared:
            *ulConfig = ((TRUE == ueCapa_splitDRB_withUL_Both_MCG_SCG) ? (E1_shared) : (E1_no_data));
            break;

        case UlPdcpPath_ScgShared:
        case UlPdcpPath_ScgOnly:
            *ulConfig = E1_only;
            break;
                                                                                                            
        default:
            *ulConfig = E1_no_data;
    }

    return;
}

// This function is a function to control operation to add Cell Group Information.
int16_t VEIL_fill_Add_E1_Cell_Group_Information_Item(callInfo_type *ptCi, E1_DRB_To_Modify_Item_NG_RAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer::PduSessToBeModData::DrbToBeModData *ptDrbToBeModBuffer,
    callDRBInfo_type *pDRBInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptDrbToBeModBuffer);
    VALID_E_POINT_CHECK_ERROR(pDRBInfo);

    // Fill Present - Includes only SCG bearers, not MCG bearers.
    if (IS_ON_E1_MRDC_CTRL_FLAG(pDRBInfo, scgAdd) ||
        (S_Setup == pDRBInfo->snDrbStatus && ptCi->state == STATE_PDUChg_F1Mod))  // NEDC Modify case
    {
        E1_Cell_Group_Information_Item *pScgCellGroup = &ptDrbToBeModBuffer->cellGroupToAddList[0].value;
        uint8_t ueCapa_splitDRB_withUL_Both_MCG_SCG =
            ((IS_NEDC_MN(ptCi)) ? ptCi->ueInfo.ueCapa.mrdc.tddCapaAdd.general.splitDRB_withUL_Both_MCG_SCG
                                : FnVCCB_GetUeCapaSplitDRB_withUL_Both_MCG_SCG_NRDC(ptCi));

        drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_NG_RAN_cell_Group_To_Add_present;

        if (IS_NEDC_MN(ptCi))
        {
            pScgCellGroup->rAT_Type = E1_RAT_Type_e_UTRA;
        }
        else if (IS_NRDC_MN(ptCi))
        {
            pScgCellGroup->rAT_Type = E1_RAT_Type_nR;
        }
        else
        {
            OFF_PRESENT_BIT(drbToModifyItem->bit_mask, E1_DRB_To_Modify_Item_NG_RAN_cell_Group_To_Add_present);
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid UECtxType(%u) in %s!\n", ptCi->mrdcInfo.ueCtxType, __func__);
            return ERROR;
        }

        // Fill Contents
        pScgCellGroup->bit_mask = 0;
        pScgCellGroup->bit_mask |=
            E1_Cell_Group_Information_Item_uL_Configuration_present;
        pScgCellGroup->bit_mask |= E1_rAT_Type_present;

        pScgCellGroup->cell_Group_ID = CellGroupId_SCG;  // mandatory
        E1_UL_Configuration ulConfig = E1_only;
        
        VEIL_decideE1_ScgCellGroup_UlConfig(pDRBInfo->ulPdcpPath, ueCapa_splitDRB_withUL_Both_MCG_SCG, &ulConfig);
        pScgCellGroup->uL_Configuration = ulConfig;

        ptDrbToBeModBuffer->cellGroupToAddList[0].next = nullptr;

        drbToModifyItem->cell_Group_To_Add = ptDrbToBeModBuffer->cellGroupToAddList;

        if (IS_LOG_TRAFFIC(ptCi))
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[TRAFFIC, CellGroup]: SCG Add! (DRB ID:%u)\n", pDRBInfo->dRBId);
        }
    }

    return GOOD;
}

// This function is a function to control operation to remove Cell Group Information.
int16_t VEIL_fill_Remove_E1_Cell_Group_Information_Item(callInfo_type *ptCi,
    E1_DRB_To_Modify_Item_NG_RAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer::PduSessToBeModData::DrbToBeModData *ptDrbToBeModBuffer,
    callDRBInfo_type *pDRBInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptDrbToBeModBuffer);
    VALID_E_POINT_CHECK_ERROR(pDRBInfo);

    // Fill Present - Includes only SCG bearers, not MCG bearers.
    if (IS_ON_E1_MRDC_CTRL_FLAG(pDRBInfo, scgDel))  // during bearerType change
    {
        drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_NG_RAN_cell_Group_To_Remove_present;
    }
    else if (pDRBInfo->bearerType.val == MN_Term_SPLIT_Bearer)  // for NEDC/NRDC
    {
        if ((TRUE == VEIL_checkE1_SCG_Release_For_SA_Mobility(ptCi)) ||
            ((S_Release == pDRBInfo->snDrbStatus) && (STATE_PDUChg_F1Mod == ptCi->state)))  // for NEDC
        {
            drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_NG_RAN_cell_Group_To_Remove_present;
        }
    }

    // Fill Contents
    if (drbToModifyItem->bit_mask & E1_DRB_To_Modify_Item_NG_RAN_cell_Group_To_Remove_present)
    {
        ptDrbToBeModBuffer->cellGroupToRemList[0].value.bit_mask = 0;
        ptDrbToBeModBuffer->cellGroupToRemList[0].value.cell_Group_ID = CellGroupId_SCG;  // mandatory
        ptDrbToBeModBuffer->cellGroupToRemList[0].next = nullptr;

        drbToModifyItem->cell_Group_To_Remove = ptDrbToBeModBuffer->cellGroupToRemList;

        if (IS_LOG_TRAFFIC(ptCi))
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[TRAFFIC, CellGroup]: SCG Release! (DRB ID:%u)\n", pDRBInfo->dRBId);
        }

#ifdef IPC_TEST
        pDRBInfo->sCG_E1STOP = FALSE;
#endif
    }

    return GOOD;
}

VCCB_STATIC_INLINE
void VEIL_decideE1_DL_Tx_Stop(callInfo_type *ptCi,
    enumTxCtrltype *dlStopResume, callDRBInfo_type *pDRBInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(dlStopResume);
    VALID_E_POINT_CHECK_VOID(pDRBInfo);

    enumTxCtrltype dlTxIntegratedCtrl = VEIL_checkE1_DL_Tx_Stop_For_SA_Mobility(ptCi, pDRBInfo);

    // not use flagBasedControl
    dlStopResume[CellGroupId_MCG] = dlTxIntegratedCtrl;
    dlStopResume[CellGroupId_SCG] = dlTxIntegratedCtrl;

    if (dlTxIntegratedCtrl == TX_NO_CONTROL) // use flagBasedControl
    {
        // for mcg by Flag
        dlStopResume[CellGroupId_MCG] = TX_NO_CONTROL;
        if (IS_ON_E1_MRDC_CTRL_FLAG(pDRBInfo, mcgMod_txStop))
        {
            dlStopResume[CellGroupId_MCG] = TX_STOP;
        }
        else if (IS_ON_E1_MRDC_CTRL_FLAG(pDRBInfo, mcgMod_txResume))
        {
            dlStopResume[CellGroupId_MCG] = TX_RESUME;
        }

        // for scg by Flag
        dlStopResume[CellGroupId_SCG] = TX_NO_CONTROL;
        if (IS_ON_E1_MRDC_CTRL_FLAG(pDRBInfo, scgMod_txStop))
        {
            dlStopResume[CellGroupId_SCG] = TX_STOP;
        }
        else if (IS_ON_E1_MRDC_CTRL_FLAG(pDRBInfo, scgMod_txResume))
        {
            dlStopResume[CellGroupId_SCG] = TX_RESUME;
        }
    }

    return;
}

// This function is a function to control operation to Modify Cell Group Information.
int16_t VEIL_fill_Modify_E1_Cell_Group_Information_Item(callInfo_type *ptCi,
    E1_DRB_To_Modify_Item_NG_RAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer::PduSessToBeModData::DrbToBeModData *ptDrbToBeModBuffer,
    callDRBInfo_type *pDRBInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptDrbToBeModBuffer);
    VALID_E_POINT_CHECK_ERROR(pDRBInfo);

    int16_t status = GOOD;
    int modCnt = 0;

    enumTxCtrltype dlStopResume[MAX_CELL_GROUP] = { TX_NO_CONTROL, TX_NO_CONTROL };

    bool mcgCtrl = false, scgCtrl = false;
    uint8_t ueCapa_splitDRB_withUL_Both_MCG_SCG =
        ((IS_NEDC_MN(ptCi)) ? ptCi->ueInfo.ueCapa.mrdc.tddCapaAdd.general.splitDRB_withUL_Both_MCG_SCG
                            : FnVCCB_GetUeCapaSplitDRB_withUL_Both_MCG_SCG_NRDC(ptCi));

    FnVCCB_DecisionMrdc_E1CellGroupControlForDrb(ptCi, pDRBInfo, &mcgCtrl, &scgCtrl);

    // TX STOP/RESUME Control
    VEIL_decideE1_DL_Tx_Stop(ptCi, dlStopResume, pDRBInfo);

    // MCG Control
    if (mcgCtrl)
    {
        E1_Cell_Group_Information_Item *pMcgCellGroup = &ptDrbToBeModBuffer->cellGroupToModList[modCnt].value;
        pMcgCellGroup->bit_mask = 0;
        pMcgCellGroup->cell_Group_ID = CellGroupId_MCG;  // mandatory

        pMcgCellGroup->bit_mask |= E1_rAT_Type_present;
        pMcgCellGroup->rAT_Type = E1_RAT_Type_nR;

        if (dlStopResume[CellGroupId_MCG] != TX_NO_CONTROL)  // Handover and RRE
        {
            if (MrdcScgFailSuspend_cmd != ptCi->stateCmd && MrdcScgFailResume_cmd != ptCi->stateCmd)
            {
                // TX STOP/RESUME for MCG in MN
                FnVCCB_FillE1TxStopResume(pDRBInfo, pMcgCellGroup, dlStopResume[CellGroupId_MCG]);
            }

            // SVR22B FGR-CC5203
            SET_E1_CELL_GROUP_UL_CONFIG_FOR_SCG_HANDLING_MNTERM(pMcgCellGroup, E1_only);
        }

        if (IS_NRDC_MN(ptCi) &&
            (IS_ON_E1_MRDC_CTRL_FLAG(pDRBInfo, scgAdd) || IS_ON_E1_MRDC_CTRL_FLAG(pDRBInfo, scgDel)))
        {
            // 21C-IODT, primary is alway mcg and not changed
            // The ulConfiguration of scg has been set in VEIL_fill_Add_E1_Cell_Group_Information_Item api.
            pMcgCellGroup->bit_mask |=
                E1_Cell_Group_Information_Item_uL_Configuration_present;
            E1_UL_Configuration ulConfig = E1_only;

            if (IS_ON_E1_MRDC_CTRL_FLAG(pDRBInfo, scgAdd))
            {
                VEIL_decideE1_McgCellGroup_UlConfig(pDRBInfo->ulPdcpPath, ueCapa_splitDRB_withUL_Both_MCG_SCG, &ulConfig);
            }
            pMcgCellGroup->uL_Configuration = ulConfig;
        }
        else if ((pDRBInfo->ulPdcpPath != pDRBInfo->ulPdcpPathPrev) || (E1UlPathSwitch_cmd == ptCi->stateCmd) ||
                 (MrUlPathSwitch_cmd == ptCi->stateCmd) || (STATE_MN_SNMob_TxStop == ptCi->state) ||
                 (((STATE_INTER_DU_Prepare == ptCi->state) || (STATE_SNAddPrepare_XnAdd == ptCi->state)) &&
                 (MN_Term_SPLIT_Bearer == pDRBInfo->bearerType.val)))
        {
            pMcgCellGroup->bit_mask |=
                E1_Cell_Group_Information_Item_uL_Configuration_present;
            E1_UL_Configuration ulConfig = E1_only;

            if(MN_Term_MCG_Bearer != pDRBInfo->bearerType.val)
            {
                VEIL_decideE1_McgCellGroup_UlConfig(pDRBInfo->ulPdcpPath, ueCapa_splitDRB_withUL_Both_MCG_SCG, &ulConfig);
            }
            pMcgCellGroup->uL_Configuration = ulConfig;
        }

        // Data is packed only when there is an optional parameter.
        PRINT_E1_CELL_GROUP_TO_MODIFY_DL_TX_STOP(ptCi,
            ptDrbToBeModBuffer->cellGroupToModList[modCnt].value, CellGroupId_MCG);
        modCnt++;
    }

    // SCG Control
    if (scgCtrl && !IS_ON_E1_MRDC_CTRL_FLAG(pDRBInfo, scgDel))
    {
        E1_Cell_Group_Information_Item *pScgCellGroup = &ptDrbToBeModBuffer->cellGroupToModList[modCnt].value;
        pScgCellGroup->bit_mask = 0;
        pScgCellGroup->cell_Group_ID = CellGroupId_SCG;  // mandatory

        pScgCellGroup->bit_mask |= E1_rAT_Type_present;
        pScgCellGroup->rAT_Type = IS_NEDC_MN(ptCi) ? E1_RAT_Type_e_UTRA : E1_RAT_Type_nR;  

        if (dlStopResume[CellGroupId_SCG] != TX_NO_CONTROL)  // Handover and RRE
        {
            // TX STOP/RESUME for SCG in MN
            FnVCCB_FillE1TxStopResume(pDRBInfo, pScgCellGroup, dlStopResume[CellGroupId_SCG]);

            // SVR22B FGR-CC5203
            SET_E1_CELL_GROUP_UL_CONFIG_FOR_SCG_HANDLING_MNTERM(pScgCellGroup, E1_no_data);
        }

        if (IS_NRDC_MN(ptCi) &&
            (IS_ON_E1_MRDC_CTRL_FLAG(pDRBInfo, scgAdd) || IS_ON_E1_MRDC_CTRL_FLAG(pDRBInfo, scgDel)))
        {
            // 21C-IODT, primary is alway mcg and not changed
            // The ulConfiguration of scg has been set in VEIL_fill_Add_E1_Cell_Group_Information_Item api.
        }
        else if ((pDRBInfo->ulPdcpPath != pDRBInfo->ulPdcpPathPrev) || (E1UlPathSwitch_cmd == ptCi->stateCmd) ||
                 (MrUlPathSwitch_cmd == ptCi->stateCmd) || (STATE_MN_SNMob_TxStop == ptCi->state) ||
                 ((STATE_INTER_DU_Prepare == ptCi->state || STATE_SNAddPrepare_XnAdd == ptCi->state) &&
                (MN_Term_SPLIT_Bearer == pDRBInfo->bearerType.val)))
        {
            pScgCellGroup->bit_mask |= E1_Cell_Group_Information_Item_uL_Configuration_present;
            E1_UL_Configuration ulConfig = E1_shared;

            VEIL_decideE1_ScgCellGroup_UlConfig(pDRBInfo->ulPdcpPath, ueCapa_splitDRB_withUL_Both_MCG_SCG, &ulConfig);
            pScgCellGroup->uL_Configuration = ulConfig;
        }

        // Data is packed only when there is an optional parameter.
        PRINT_E1_CELL_GROUP_TO_MODIFY_DL_TX_STOP(ptCi,
            ptDrbToBeModBuffer->cellGroupToModList[modCnt].value, CellGroupId_SCG);
        modCnt++;
    }

    if (modCnt > 0)
    {
        drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_NG_RAN_cell_Group_To_Modify_present;
        drbToModifyItem->cell_Group_To_Modify = ptDrbToBeModBuffer->cellGroupToModList;

        status = VCCB_ConnectLinkedList(drbToModifyItem->cell_Group_To_Modify, modCnt);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status,
            "Fail, VCCB_ConnectLinkedList for cell_Group_To_Modify in %s!\n", __func__);
    }

#ifdef IPC_TEST
    for (uint16_t idx = 0; idx < modCnt; idx++)
    {
        if (ptDrbToBeModBuffer->cellGroupToModList[idx].value.bit_mask & E1_dL_TX_Stop_present)
        {
            auto groupId = ptDrbToBeModBuffer->cellGroupToModList[idx].value.cell_Group_ID;
            auto txStopResume = ptDrbToBeModBuffer->cellGroupToModList[idx].value.dL_TX_Stop;

            switch(groupId)
            {
                case CellGroupId_SCG:
                    pDRBInfo->sCG_E1STOP = (txStopResume == E1_DL_TX_Stop_stop ? TRUE : FALSE);
                    break;

                case CellGroupId_MCG:
                    pDRBInfo->mCG_E1STOP = (txStopResume == E1_DL_TX_Stop_stop ? TRUE : FALSE);
                    break;

                default:
                    break;
            }
        }
    }
#endif

    return status;
}

int16_t VEIL_fill_Modify_E1_Cell_Group_Information_Item_NRDC_SN(callInfo_type *ptCi,
    E1_DRB_To_Modify_Item_NG_RAN *drbToModifyItem,
    E1_BearerContextModificationRequestBuffer::PduSessToBeModData::DrbToBeModData *ptDrbToBeModBuffer,
    callDRBInfo_type *pDRBInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(drbToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptDrbToBeModBuffer);
    VALID_E_POINT_CHECK_ERROR(pDRBInfo);

    int status;
    int modCnt = 0;

    enumTxCtrltype dlStopResume[MAX_CELL_GROUP] = { TX_NO_CONTROL, TX_NO_CONTROL };

    bool mcgCtrl = false, scgCtrl = false;
    uint8_t ueCapa_splitDRB_withUL_Both_MCG_SCG = FnVCCB_GetUeCapaSplitDRB_withUL_Both_MCG_SCG_NRDC(ptCi);

    FnVCCB_DecisionMrdc_E1CellGroupControlForDrb(ptCi, pDRBInfo, &mcgCtrl, &scgCtrl);

    auto procFlagBasedControl = [&ptCi, &pDRBInfo, &dlStopResume]()
    {
        bool flagBasedControl = false;

        // for mcg by Flag
        if (IS_ON_E1_MRDC_CTRL_FLAG(pDRBInfo, mcgMod_txStop))
        {
            dlStopResume[CellGroupId_MCG] = TX_STOP;
            flagBasedControl = true;
        }
        else if (IS_ON_E1_MRDC_CTRL_FLAG(pDRBInfo, mcgMod_txResume))
        {
            dlStopResume[CellGroupId_MCG] = TX_RESUME;
            flagBasedControl = true;
        }

        // for scg by Flag
        if (IS_ON_E1_MRDC_CTRL_FLAG(pDRBInfo, scgMod_txStop))
        {
            dlStopResume[CellGroupId_SCG] = TX_STOP;
            flagBasedControl = true;
        }
        else if (IS_ON_E1_MRDC_CTRL_FLAG(pDRBInfo, scgMod_txResume))
        {
            dlStopResume[CellGroupId_SCG] = TX_RESUME;
            flagBasedControl = true;
        }

        return flagBasedControl;
    };

    // In SVR21C IODT, change of UL Configuration is not supported.
    switch (ptCi->stateCmd)
    {
        case MrdcSnNodeRelRequest_cmd:
        case MrdcSnNodeRelConfirm_cmd:
            if (ptCi->state != STATE_SN_SNRelPrepare_F1Mod && ptCi->state != STATE_SN_SNRelExec)
            {
                dlStopResume[CellGroupId_MCG] = TX_STOP;
                dlStopResume[CellGroupId_SCG] = TX_STOP;
                break; // Stop Processing
            }

            return GOOD; // No action

        case MrUlPathSwitch_cmd:
        case E1UlPathSwitch_cmd:
            dlStopResume[CellGroupId_MCG] = TX_NO_CONTROL;
            dlStopResume[CellGroupId_SCG] = TX_NO_CONTROL;
            break;

        case MrdcXnSNMod_cmd:
            if (ptCi->bitFlag.isDrbPreemptionCase && (ptCi->state == STATE_SN_SNModPrepare_XnModRqrd))
            {
                dlStopResume[CellGroupId_MCG] = TX_STOP;
                dlStopResume[CellGroupId_SCG] = TX_STOP;
                break;
            }
            else if ((ptCi->state == STATE_Conn) &&
                FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_McgMobility) == true)
            {
                procFlagBasedControl(); // No return value check required.
                break;
            }
            else
            {
                return GOOD;
            }

        default:
            {
                bool isUseFlagBasedControl = procFlagBasedControl();

                if (isUseFlagBasedControl == false)
                {
                    enumTxCtrltype dlTxIntegratedCtrl = VEIL_checkE1_DL_Tx_Stop_For_SA_Mobility(ptCi, pDRBInfo);
                    if ((dlTxIntegratedCtrl == TX_NO_CONTROL) && (ptCi->state != STATE_SN_INTRA_DU_Exe))
                    {
                        return GOOD; // No action
                    }

                    dlStopResume[CellGroupId_MCG] = dlTxIntegratedCtrl;
                    dlStopResume[CellGroupId_SCG] = dlTxIntegratedCtrl;
                }
            }

            break; // Stop/Resume Processing
    }

    // SCG Control
    if (scgCtrl)
    {
        E1_Cell_Group_Information_Item *pScgCellGroup = &ptDrbToBeModBuffer->cellGroupToModList[modCnt].value;

        bool nrdcScgSuspendUlConfFlag = false;
        pScgCellGroup->bit_mask = 0;
        pScgCellGroup->cell_Group_ID = CellGroupId_SCG;  // mandatory

        if (dlStopResume[CellGroupId_SCG] != TX_NO_CONTROL)
        {
            FnVCCB_FillE1TxStopResume(pDRBInfo, pScgCellGroup, dlStopResume[CellGroupId_SCG]);

            // In SVR21C IODT, change of UL Configuration is not supported.
            PRINT_E1_CELL_GROUP_TO_MODIFY_DL_TX_STOP(ptCi,
                ptDrbToBeModBuffer->cellGroupToModList[modCnt].value, CellGroupId_SCG);

            // SVR22B FGR-CC5203
            if (SN_Term_SPLIT_Bearer == pDRBInfo->bearerType.val)
            {
                if ((MrdcScgFailSuspend_cmd == ptCi->stateCmd && STATE_SN_SCGSuspend_Init == ptCi->state) ||
                    (MrdcScgFailResume_cmd == ptCi->stateCmd && STATE_SN_SCGResume_Init == ptCi->state ) ||
                    (IS_NRDC_HO_SCG_RESUME(ptCi)))
                {
                    pScgCellGroup->bit_mask |=
                        E1_Cell_Group_Information_Item_uL_Configuration_present;
                    pScgCellGroup->uL_Configuration = E1_no_data;
                    nrdcScgSuspendUlConfFlag = true;
                }
            }
        }

        if (FALSE == nrdcScgSuspendUlConfFlag &&
            ((pDRBInfo->ulPdcpPath != pDRBInfo->ulPdcpPathPrev) || (E1UlPathSwitch_cmd == ptCi->stateCmd) ||
                (MrUlPathSwitch_cmd == ptCi->stateCmd) || (ptCi->state == STATE_SN_INTRA_DU_Exe) ||
                (ptCi->state == STATE_SN_INTER_DU_Exe)))
        {
            pScgCellGroup->bit_mask |=
                E1_Cell_Group_Information_Item_uL_Configuration_present;
            E1_UL_Configuration ulConfig = E1_shared;

            VEIL_decideE1_ScgCellGroup_UlConfig(pDRBInfo->ulPdcpPath, ueCapa_splitDRB_withUL_Both_MCG_SCG, &ulConfig);
            pScgCellGroup->uL_Configuration = ulConfig;
        }
        modCnt++;
    }

    // MCG Control
    if (mcgCtrl)
    {
        E1_Cell_Group_Information_Item *pMcgCellGroup = &ptDrbToBeModBuffer->cellGroupToModList[modCnt].value;

        bool nrdcScgSuspendUlConfFlag = false;
        pMcgCellGroup->bit_mask = 0;
        pMcgCellGroup->cell_Group_ID = CellGroupId_MCG;  // mandatory

        if (dlStopResume[CellGroupId_MCG] != TX_NO_CONTROL)
        {
            if (MrdcScgFailSuspend_cmd != ptCi->stateCmd && MrdcScgFailResume_cmd != ptCi->stateCmd)
            {
                if (!IS_NRDC_HO_SCG_RESUME(ptCi))
                {
                    // TX STOP/RESUME for MCG in SN
                    FnVCCB_FillE1TxStopResume(pDRBInfo, pMcgCellGroup, dlStopResume[CellGroupId_MCG]);
                }
            }

            // In SVR21C IODT, change of UL Configuration is not supported.
            PRINT_E1_CELL_GROUP_TO_MODIFY_DL_TX_STOP(ptCi,
                ptDrbToBeModBuffer->cellGroupToModList[modCnt].value, CellGroupId_MCG);

            // SVR22B FGR-CC5203
            if (SN_Term_SPLIT_Bearer == pDRBInfo->bearerType.val)
            {
                if ((MrdcScgFailSuspend_cmd == ptCi->stateCmd && STATE_SN_SCGSuspend_Init == ptCi->state) ||
                    (MrdcScgFailResume_cmd == ptCi->stateCmd && STATE_SN_SCGResume_Init == ptCi->state) ||
                    (IS_NRDC_HO_SCG_RESUME(ptCi)))
                {
                    pMcgCellGroup->bit_mask |= E1_Cell_Group_Information_Item_uL_Configuration_present;
                    pMcgCellGroup->uL_Configuration = E1_only;
                    nrdcScgSuspendUlConfFlag = true;
                }
            }
        }
        if (FALSE == nrdcScgSuspendUlConfFlag &&
            ((pDRBInfo->ulPdcpPath != pDRBInfo->ulPdcpPathPrev) || (E1UlPathSwitch_cmd == ptCi->stateCmd) ||
                (MrUlPathSwitch_cmd == ptCi->stateCmd) || (ptCi->state == STATE_SN_INTRA_DU_Exe) ||
                (ptCi->state == STATE_SN_INTER_DU_Exe)))
        {
            pMcgCellGroup->bit_mask |=
                E1_Cell_Group_Information_Item_uL_Configuration_present;
            E1_UL_Configuration ulConfig = E1_only;

            VEIL_decideE1_McgCellGroup_UlConfig(pDRBInfo->ulPdcpPath, ueCapa_splitDRB_withUL_Both_MCG_SCG, &ulConfig);
            pMcgCellGroup->uL_Configuration = ulConfig;
        }
        modCnt++;
    }

    if (modCnt > 0)
    {
        drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_NG_RAN_cell_Group_To_Modify_present;
        drbToModifyItem->cell_Group_To_Modify = ptDrbToBeModBuffer->cellGroupToModList;

#ifdef IPC_TEST
        for (uint16_t idx = 0; idx < modCnt; idx++)
        {
            if (ptDrbToBeModBuffer->cellGroupToModList[idx].value.bit_mask & E1_dL_TX_Stop_present)
            {
                auto groupId = ptDrbToBeModBuffer->cellGroupToModList[idx].value.cell_Group_ID;
                auto txStopResume = ptDrbToBeModBuffer->cellGroupToModList[idx].value.dL_TX_Stop;

                switch(groupId)
                {
                    case CellGroupId_SCG:
                        pDRBInfo->sCG_E1STOP = (txStopResume == E1_DL_TX_Stop_stop ? TRUE : FALSE);
                        break;

                    case CellGroupId_MCG:
                        pDRBInfo->mCG_E1STOP = (txStopResume == E1_DL_TX_Stop_stop ? TRUE : FALSE);
                        break;

                    default:
                        break;
                }
            }
        }
#endif

        status = VCCB_ConnectLinkedList(drbToModifyItem->cell_Group_To_Modify, modCnt);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_ConnectLinkedList for cell_Group_To_Modify in %s!\n", __func__);
    }

    return GOOD;
}

// SVR24B [FGR-MC1400] Conditional Handover
template <typename T>
int16_t VEIL_AddE1ExtensionToLinkedList(callInfo_type *ptCi, bool isExtensionPresent,
            struct E1_ProtocolExtensionContainer_ **ppExtensionContainer, struct E1_ProtocolExtensionContainer_ *pBuffer,
            T value, E1_ProtocolIE_ID ieId, int pduNum)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ppExtensionContainer);
    VALID_E_POINT_CHECK_ERROR(pBuffer);

    InsertE1_ExtensionContainerValue(pBuffer, ieId, E1_ignore, value, pduNum);

    if (!(isExtensionPresent)) // new
    {
        (*ppExtensionContainer) = pBuffer;
        (*ppExtensionContainer)->next = nullptr;
    }
    else
    {
        struct E1_ProtocolExtensionContainer_ *pIter = (*ppExtensionContainer);
        VALID_E_POINT_CHECK_ERROR(pIter);

        while (pIter->next)
        {
            pIter = pIter->next;
        }

        pIter->next = pBuffer;
        pIter->next->next = nullptr;
    }

    return GOOD;
}

void FnVCCB_fillE1_DRBToModifyItem_VomaExtension(callInfo_type *ptCi, callDRBInfo_type *pDRBInfo, E1_DRB_To_Modify_Item_NG_RAN *drbToModifyItem, 
    E1_BearerContextModificationRequestBuffer::PduSessToBeModData::DrbToBeModData *ptDrbToBeModBuffer)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pDRBInfo);
    VALID_E_POINT_CHECK_VOID(drbToModifyItem);
    VALID_E_POINT_CHECK_VOID(ptDrbToBeModBuffer);

    if (VOMA_PREPARATION != pDRBInfo->vomaStatus.upStatus)
    {
        return;
    }

    if (ptCi->vomaInfo.delayE1start)
    {
        ptCi->vomaInfo.delayE1start = false;
    }
    else
    {
        bool insertExt = false;

        if (VOMA_STARTED == pDRBInfo->vomaStatus.duStatus)
        {
            ptDrbToBeModBuffer->vomaRequest = E1_SamsungVOMAE1Request_start;
            pDRBInfo->vomaStatus.upStatus = VOMA_START_REQ;
            insertExt = true;
        }

        if (VOMA_STOPPED == pDRBInfo->vomaStatus.duStatus)
        {
            ptDrbToBeModBuffer->vomaRequest = E1_SamsungVOMAE1Request_stop;
            pDRBInfo->vomaStatus.upStatus = VOMA_STOP_REQ;
            insertExt = true;
        }

        if (insertExt) // skip if DU does not respond yet
        {
            bool isExtensionPresent = drbToModifyItem->bit_mask & E1_DRB_To_Modify_Item_NG_RAN_iE_Extensions_present;
            if (GOOD == VEIL_AddE1ExtensionToLinkedList(ptCi, isExtensionPresent, &drbToModifyItem->iE_Extensions,
                        &ptDrbToBeModBuffer->vomaRequestContainer, &ptDrbToBeModBuffer->vomaRequest,
                        E1_id_SamsungVOMAE1Request, E1_SamsungVOMAE1Request_PDU))
            {
                drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_NG_RAN_iE_Extensions_present;
            }

            if (VOMA_STOP_REQ != pDRBInfo->vomaStatus.upStatus)
            {
                VLIB_Fill_VomaInitTime(&ptDrbToBeModBuffer->vomaInitTime, reinterpret_cast<uint8_t*>(ptCi->vomaInfo.initTime));
                isExtensionPresent = drbToModifyItem->bit_mask & E1_DRB_To_Modify_Item_NG_RAN_iE_Extensions_present;
                if (GOOD == VEIL_AddE1ExtensionToLinkedList(ptCi, isExtensionPresent, &drbToModifyItem->iE_Extensions,
                            &ptDrbToBeModBuffer->vomaInitTimeContainer, &ptDrbToBeModBuffer->vomaInitTime,
                            E1_id_SamsungVOMAE1InitTime, E1_SamsungVOMAE1InitTime_PDU))
                {
                    drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_NG_RAN_iE_Extensions_present;
                }
            }
        }
    }
}

/**
 * @brief fill E1 DRB To Modify Item for Bearer Context Modification Request Procedure
 * @attention function sets all bit_mask
 * @param [in]     ptCi                   : callInfo DB
 * @param [in]     drbIdx                 : DRB index in ptCi array
 * @param [in]     numDrb                 : DRB number in pdu session
 * @param [in/out] ptPduSessToBeModBuffer : E1_BearerContextModificationRequestBuffer::PduSessToBeModData
 * @return         GOOD                   : success fill
 * @return         ERROR                  : fill error
 */
int VEIL_fillE1_DRBToModifyItem(callInfo_type *ptCi, uint8_t drbIdx, uint16_t numDrb,
    E1_BearerContextModificationRequestBuffer::PduSessToBeModData *ptPduSessToBeModBuffer, bool isDlTrfStatusRptCfgOnly, enumE1F1procedure_type procedure)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptPduSessToBeModBuffer);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(drbIdx, MAX_DRB_PER_SA_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(numDrb, MAX_DRB_PER_PDU_SESS);

    int status = GOOD;
    callDRBInfo_type *pDRBInfo = &ptCi->drb[drbIdx];
    E1_DRB_To_Modify_Item_NG_RAN *drbToModifyItem = &ptPduSessToBeModBuffer->drbToModList[numDrb].value;
    E1_BearerContextModificationRequestBuffer::PduSessToBeModData::DrbToBeModData *ptDrbToBeModBuffer =
        &ptPduSessToBeModBuffer->drbToModData[numDrb];
    uint16_t drbQosIdxInCall = pDRBInfo->drbQosIdxInCall;
    qosFlowInfo_type *ptQi = NULL;
    bool qosFlowMonitoringPresent = false;

    // Prepare : update the pack buffer to asn header
    drbToModifyItem->dL_UP_Parameters = ptDrbToBeModBuffer->dlUpParamList;
    drbToModifyItem->flow_Mapping_Information = ptDrbToBeModBuffer->flowMappingList;

    // Prepare : init bit_mask
    drbToModifyItem->bit_mask = 0;

    // 1. M - DRB ID (9_3_1_16)
    drbToModifyItem->dRB_ID = pDRBInfo->dRBId;

    if (isDlTrfStatusRptCfgOnly)
    {
        VCCB_PRINT_CALL_DATA(
            ptCi, "[E1DBG] DRB <idx:%u, id:%u> will be filled with DlTrfStatusRptCfgOnly! \n", drbIdx, pDRBInfo->dRBId);
        goto FILL_DL_TRF_STATUS_RPT_CONFIG;
    }

    // 2. O - SDAP Configuration (9_3_1_39)
    if ((MrUlPathSwitch_cmd != ptCi->stateCmd) && (E1UlPathSwitch_cmd != ptCi->stateCmd))
    {
        status = VEIL_fillE1_SDAP_ConfigurationInfo(&drbToModifyItem->sDAP_Configuration, ptCi, pDRBInfo);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_SDAP_ConfigurationInfo ERROR!\n");
        drbToModifyItem->bit_mask |= E1_sDAP_Configuration_present;

        // 3. O - PDCP Configuration (9_3_1_38)
        if (VEIL_check_E1_DRBToModifyItem_PDCP_ConfigurationInfo(ptCi, pDRBInfo) == GOOD)
        {
            status = VEIL_fillE1_DRBToModifyItem_PDCP_ConfigurationInfo(ptDrbToBeModBuffer,
                &drbToModifyItem->pDCP_Configuration, ptCi, pDRBInfo);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_DRBToModifyItem_PDCP_ConfigurationInfo ERROR!\n");
            if (status == GOOD)
            {
                drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_NG_RAN_pDCP_Configuration_present;
            }
        }

        // 4. O - DRB Data forwarding information (9_3_2_6)
        if (true == VEIL_check_E1_DRB_Data_Forwarding_Information(ptCi, pDRBInfo))
        {
            status = VEIL_fillE1_Data_Forwarding_Information(
                ptCi, pDRBInfo, &drbToModifyItem->dRB_Data_Forwarding_Information, ptDrbToBeModBuffer);
            VCCB_RETURN_ON_CALL_ERROR(
                ptCi, status, "VEIL_fillE1_DRB_Data_Forwarding_Information ERROR in %s!\n", __func__);

            if (drbToModifyItem->dRB_Data_Forwarding_Information.bit_mask > 0)
            {
                drbToModifyItem->bit_mask |= E1_dRB_Data_Forwarding_Information_present;
            }
        }

        // 5. O - PDCP SN Status Request (ENUMERATED (requested, ...)
        if (true == VEIL_check_E1_PDCP_SN_Status_Request(ptCi, pDRBInfo))
        {
            drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_NG_RAN_pDCP_SN_Status_Request_present;
            drbToModifyItem->pDCP_SN_Status_Request = E1_requested;

            if (IS_NRDC(ptCi) &&
                !(pDRBInfo->rbInfo.rlcModePresent == OPT_PRESENT && pDRBInfo->rbInfo.rlcMode == AM_RLC))
            {
                OFF_PRESENT_BIT(drbToModifyItem->bit_mask, E1_DRB_To_Modify_Item_NG_RAN_pDCP_SN_Status_Request_present);
            }

            if (IS_LOG_TRAFFIC(ptCi))
            {
                if (drbToModifyItem->bit_mask & E1_DRB_To_Modify_Item_NG_RAN_pDCP_SN_Status_Request_present)
                {
                    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[TRAFFIC, E1]: PDCP-SN-STATUS-REQUEST (DRB ID:%u)\n", pDRBInfo->dRBId);
                }
            }
        }

        // 6. O - PDCP SN Status Information (9_3_1_58)
        status = VEIL_fillE1_PDCP_SN_Status_Information_Modify(ptCi, pDRBInfo, drbToModifyItem, ptDrbToBeModBuffer);
        VCCB_RETURN_ON_CALL_ERROR(
            ptCi, status, "VEIL_fillE1_PDCP_SN_Status_Information_Modify ERROR in %s!\n", __func__);

        // 7. O - DL UP Parameters (9_3_1_13)
        int noofUPParameters = 0;
        if (1 == pDRBInfo->f1uDlInfo.fNeedModify)
        {
            const enumCellGroupId cellGroupId = (IS_NRDC_SN(ptCi) ? (CellGroupId_SCG) : (CellGroupId_MCG));

            ptDrbToBeModBuffer->dlUpParamList[noofUPParameters].value.bit_mask = 0;
            ptDrbToBeModBuffer->dlUpParamList[noofUPParameters].value.cell_Group_ID = cellGroupId;

            status = VEIL_fillE1_UP_TNL_Information(
                &ptDrbToBeModBuffer->dlUpParamList[noofUPParameters].value.uP_TNL_Information, &pDRBInfo->f1uDlInfo);
            VCCB_RETURN_ON_CALL_ERROR(
                ptCi, status, "VEIL_fillE1_UP_TNL_Information for f1uDlInfo ERROR in %s!\n", __func__);
            noofUPParameters++;

            pDRBInfo->f1uDlInfo.fNeedModify = 0;

            if (IS_LOG_TRAFFIC(ptCi))
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[TRAFFIC, TNL]: F1 DL (DRB ID:%u, %s)\n", pDRBInfo->dRBId, (cellGroupId == CellGroupId_MCG ? "MCG" : "SCG"));
            }
        }

        if ((IS_ON_E1_MRDC_CTRL_FLAG(pDRBInfo, scgMod_xNuDlTnl) || IS_NRDC_SN(ptCi)) &&
            pDRBInfo->xNuDlInfo.fNeedModify == 1)  // for MRDC
        {
            const enumCellGroupId cellGroupId = (IS_NRDC_SN(ptCi) ? (CellGroupId_MCG) : (CellGroupId_SCG));

            ptDrbToBeModBuffer->dlUpParamList[noofUPParameters].value.bit_mask = 0;
            ptDrbToBeModBuffer->dlUpParamList[noofUPParameters].value.cell_Group_ID = cellGroupId;

            status = VEIL_fillE1_UP_TNL_Information(
                &ptDrbToBeModBuffer->dlUpParamList[noofUPParameters].value.uP_TNL_Information, &pDRBInfo->xNuDlInfo);
            VCCB_RETURN_ON_CALL_ERROR(
                ptCi, status, "VEIL_fillE1_UP_TNL_Information for xNuDlInfo ERROR in %s!\n", __func__);
            noofUPParameters++;

            pDRBInfo->xNuDlInfo.fNeedModify = 0;

            if (IS_LOG_TRAFFIC(ptCi))
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[TRAFFIC, TNL]: XN DL (DRB ID:%u, %s)\n", pDRBInfo->dRBId, (cellGroupId == CellGroupId_MCG ? "MCG" : "SCG"));
            }
        }

        if (noofUPParameters)
        {
            drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_NG_RAN_dL_UP_Parameters_present;

            // Connect UP Parameters List
            status = VCCB_ConnectLinkedList(drbToModifyItem->dL_UP_Parameters, noofUPParameters);
            VCCB_RETURN_ON_CALL_ERROR(
                ptCi, status, "VCCB_ConnectLinkedList failed in %s->DL UP Parameters!\n", __func__);
        }
    }

    // 8. O - Cell Group To Add (9_3_1_11)
    // 9. O - Cell Group To Modify (9_3_1_11)
    // 10. O - Cell Group To Remove (9_3_1_11)
    if (IS_NRDC_SN(ptCi))
    {
        // In case of NR-DC SN, Cell Group Add/Remove is not required.

        // Modify
        status = VEIL_fill_Modify_E1_Cell_Group_Information_Item_NRDC_SN(
            ptCi, drbToModifyItem, ptDrbToBeModBuffer, pDRBInfo);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fill_Modify_E1_Cell_Group_Information_Item_NRDC_SN Error!!\n");
    }
    else
    {
        // Add
        status = VEIL_fill_Add_E1_Cell_Group_Information_Item(ptCi, drbToModifyItem, ptDrbToBeModBuffer, pDRBInfo);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fill_Add_E1_Cell_Group_Information_Item Error!!\n");

        // Modify
        status = VEIL_fill_Modify_E1_Cell_Group_Information_Item(ptCi, drbToModifyItem, ptDrbToBeModBuffer, pDRBInfo);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fill_Modify_E1_Cell_Group_Information_Item Error!!\n");
    
        // Remove
        status = VEIL_fill_Remove_E1_Cell_Group_Information_Item(ptCi, drbToModifyItem, ptDrbToBeModBuffer, pDRBInfo);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fill_Remove_E1_Cell_Group_Information_Item Error!!\n");
    }

    if ((MrUlPathSwitch_cmd != ptCi->stateCmd) && (E1UlPathSwitch_cmd != ptCi->stateCmd))
    {
        // 11. O - Flow Mapping Information (9_3_1_25)
        unsigned int loop = 0, numQoSFlow = 0;
        for (loop = 0; loop < MAX_QOS_FLOW_PER_DRB; loop++)
        {
            if (pDRBInfo->qosFlowIndex[loop] >= MAX_QOS_FLOW_PER_CALL)  // Not yet allocated
                continue;

            ptQi = &ptCi->qosFlow[pDRBInfo->qosFlowIndex[loop]];
            if (CI_use != ptQi->usage) continue;

            if (VLIB_IsCommonValidStateOfPduQosDrb(ptQi->qosFlowStatus) != GOOD)
            {
                continue;
            }

            VCCB_PRINT_CALL_DATA(ptCi, "[E1DBG] ptCi->qosFlow[%d].usage is CI_use\n", pDRBInfo->qosFlowIndex[loop]);

            // QoS Flow Item
            status = VEIL_fillE1_QoSFlowItem(ptCi, &ptDrbToBeModBuffer->flowMappingList[numQoSFlow].value, ptQi, pDRBInfo->pduIdxInCall, numQoSFlow, procedure);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_QoSFlowItem ERROR!\n");

            E1_QosMonitoringRequest* ptQosMonitoringRequest = &ptPduSessToBeModBuffer->qosMonitoringRequest[numDrb][numQoSFlow];
            E1_QosMonitoringDisabled* ptQosMonitoringDisabled = &ptPduSessToBeModBuffer->qosMonitoringDisabled[numDrb][numQoSFlow];
            struct E1_ProtocolExtensionContainer_ *pContainer = &ptPduSessToBeModBuffer->qosMonitoringRequestBuf[numDrb][numQoSFlow];

            status = FnVCCB_Fill_QosMonitoringInfo_ForQosFlow_E1(ptCi, ptQi, ptQosMonitoringRequest, ptQosMonitoringDisabled, pContainer, false);
            if(status == GOOD)
            {
                ptDrbToBeModBuffer->flowMappingList[numQoSFlow].value.qoSFlowLevelQoSParameters.bit_mask |= E1_QoSFlowLevelQoSParameters_iE_Extensions_present;
                ptDrbToBeModBuffer->flowMappingList[numQoSFlow].value.qoSFlowLevelQoSParameters.iE_Extensions = pContainer;
                qosFlowMonitoringPresent = true;
            }
            ++numQoSFlow;
        }

        if (numQoSFlow)
        {
            drbToModifyItem->bit_mask |= E1_flow_Mapping_Information_present;

            // Connect QoS Flow QoS Parameters List
            status = VCCB_ConnectLinkedList(drbToModifyItem->flow_Mapping_Information, static_cast<int>(numQoSFlow));
            VCCB_RETURN_ON_CALL_ERROR(
                ptCi, status, "VCCB_ConnectLinkedList failed in %s-> QoS Flow QoS Parameters List!\n", __func__);
        }

        // 11. O - DRB Inactivity Timer (9_3_1_54)
        if (true == VEIL_check_E1_Inactivity_Timer(ptCi, pDRBInfo))
        {
            status = VEIL_fillE1_Inactivity_Timer(ptCi, pDRBInfo, &drbToModifyItem->dRB_Inactivity_Timer);
            if (status == GOOD)
            {
                drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_NG_RAN_dRB_Inactivity_Timer_present;
            }
        }

        // 12. O - DRB QoS (9_3_1_26)
        if ((numQoSFlow > 1) && (drbQosIdxInCall < MAX_QOS_FLOW_PER_CALL &&
                                    IS_VALID_NODE(QOSFLOW_NODE, ptCi, &(ptCi->qosFlow[drbQosIdxInCall]))))
        {
            E1_QoSFlowLevelQoSParameters *pDrbQos = &ptDrbToBeModBuffer->drbQosItem;

            qosRscIdx_type qosIdxInfo;
            qosIdxInfo.pduIdx = pDRBInfo->pduIdxInCall;
            qosIdxInfo.drbIdx = drbIdx;
            qosIdxInfo.qosFlowIdx = static_cast<uint8_t>(drbQosIdxInCall);

            status = VEIL_fillE1_DrbQos(ptCi, pDrbQos, &ptCi->qosFlow[drbQosIdxInCall], qosIdxInfo, E1F1Modify_Modify);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_DrbQos ERROR!\n");

            drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_NG_RAN_iE_Extensions_present;
            drbToModifyItem->iE_Extensions = &ptDrbToBeModBuffer->drbQos;
            drbToModifyItem->iE_Extensions->next = NULL;

            InsertE1_ExtensionContainerValue(
                drbToModifyItem->iE_Extensions, E1_id_DRB_QoS, E1_ignore, pDrbQos, E1_QoSFlowLevelQoSParameters_PDU);
        }

        if(numQoSFlow == 1)
        {
            if((qosFlowMonitoringPresent == false) && (pDRBInfo->drbQosMonitoring == QOS_MONITORING_REQUEST_STOP))
            {
                // fill drbQosMonitor to remained qosflow (alternative)
                for(auto qosFlowIndex : pDRBInfo->qosFlowIndex)
                {
                    if (qosFlowIndex >= MAX_QOS_FLOW_PER_CALL) continue;
                    auto &qosFlow = ptCi->qosFlow[qosFlowIndex];

                    if (CI_use != qosFlow.usage) continue;
                    if (VLIB_IsCommonValidStateOfPduQosDrb(qosFlow.qosFlowStatus) != GOOD) continue;
                    
                    E1_QosMonitoringRequest* ptQosMonitoringRequest = &ptPduSessToBeModBuffer->qosMonitoringRequest[numDrb][0]; // qosFlowIdx is 0 when numQosFlow == 1 
                    E1_QosMonitoringDisabled* ptQosMonitoringDisabled = &ptPduSessToBeModBuffer->qosMonitoringDisabled[numDrb][0];
                    struct E1_ProtocolExtensionContainer_ *pContainer = &ptPduSessToBeModBuffer->qosMonitoringRequestBuf[numDrb][0];

                    status = FnVCCB_Fill_QosMonitoringInfo_ForQosFlow_E1(ptCi, &qosFlow, ptQosMonitoringRequest, ptQosMonitoringDisabled, pContainer, true);
                    if(status == GOOD)
                    {
                        ptDrbToBeModBuffer->flowMappingList[0].value.qoSFlowLevelQoSParameters.bit_mask |= E1_QoSFlowLevelQoSParameters_iE_Extensions_present;
                        ptDrbToBeModBuffer->flowMappingList[0].value.qoSFlowLevelQoSParameters.iE_Extensions = pContainer;
                    }
                    break;
                }
            }        
        }

        // 13. O - Early Forwarding COUNT Request (ENUMERATED (First DL count, DL discarding, ...)
        // 14. O - Early Forwarding COUNT Information (9_3_1_92)
    }

FILL_DL_TRF_STATUS_RPT_CONFIG:
    if (FALSE == ptCi->trafficMonitoringCfg.trafficReportDrbList[drbIdx].isSameCfgFlag)
    {
        bool isExtensionPresent = drbToModifyItem->bit_mask & E1_DRB_To_Modify_Item_NG_RAN_iE_Extensions_present;
        if (GOOD == FnVCCB_FillE1_ReportConfigList(
                        ptCi, drbIdx, *ptDrbToBeModBuffer, isExtensionPresent, drbToModifyItem->iE_Extensions))
        {
            drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_NG_RAN_iE_Extensions_present;
        }
    }

    // SVR24B [FGR-MC1400] Conditional Handover
    if (drbToModifyItem->bit_mask & E1_dRB_Data_Forwarding_Information_present)
    {
        if ((ptCi->state == STATE_INTER_SeqNum_S) && IS_CHO(ptCi))
        {
            int pduNum              = E1_SamsungForwardType_PDU;
            E1_ProtocolIE_ID ieId   = E1_id_SamsungForwardType;
            ptDrbToBeModBuffer->samsungForwardType = E1_forward_by_cho;
            bool isExtensionPresent = drbToModifyItem->bit_mask & E1_DRB_To_Modify_Item_NG_RAN_iE_Extensions_present;
            if (GOOD == VEIL_AddE1ExtensionToLinkedList(ptCi, isExtensionPresent, &drbToModifyItem->iE_Extensions,
                            &ptDrbToBeModBuffer->samsungForwardTypeContainer, &ptDrbToBeModBuffer->samsungForwardType, ieId, pduNum))
            {
                drbToModifyItem->bit_mask |= E1_DRB_To_Modify_Item_NG_RAN_iE_Extensions_present;
            }
        }
    }

    // O - VoMA Request E1 (Samsung)
    // if DRB at modify list VoMA probably in preparation stage so start/stop UP base on DU state
    FnVCCB_fillE1_DRBToModifyItem_VomaExtension(ptCi, pDRBInfo, drbToModifyItem, ptDrbToBeModBuffer);

#ifdef IPC_TEST
    // add the checker..
    FnVCCB_CheckE1_DRBToModifyItem(*ptCi, *pDRBInfo, *drbToModifyItem);
#endif

    return status;
}

/**
 * @brief fill E1 DRB Modified Item for Bearer Context Modification Confirm
 * @attention function sets all bit_mask
 * @param [in]  ptDrbConfirmModifiedBuffer  : drbModifiedConfirmData buffer
 * @param [in]  pDRBInfo                    : callDRBInfo DB
 * @param [in]  ptCi                        : callInfo DB
 * @param [out] drbConfirmModItem           : E1_DRB_Confirm_Modified_Item_NG_RAN buffer
 * @return      GOOD                        : success fill
 * @return      ERROR                       : fill error
 */
int VEIL_fillE1_DRBModifiedItem(E1_DRB_Confirm_Modified_Item_NG_RAN *drbConfirmModItem,
    E1_BearerContextModificationConfirmBuffer::PduSessModifiedConfirmData::DrbModifiedConfirmData
        *ptDrbModifiedConfirmBuffer,
    callInfo_type *ptCi, callDRBInfo_type *pDRBInfo)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(drbConfirmModItem);
    VALID_E_POINT_CHECK_ERROR(ptDrbModifiedConfirmBuffer);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDRBInfo);

    drbConfirmModItem->bit_mask = 0;

    // DRB ID Fill - mandatory
    drbConfirmModItem->dRB_ID = pDRBInfo->dRBId;

    // DRB Cell Group Information - optional
    if (UlConfigBearer_ModUnable == pDRBInfo->ulPdcpPathToMod)
    {
        drbConfirmModItem->bit_mask |= E1_DRB_Confirm_Modified_Item_NG_RAN_cell_Group_Information_present;
        ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.bit_mask = 0;
        ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.bit_mask = 0;

        if (MN_Term_SPLIT_Bearer == pDRBInfo->bearerType.val)  // MRDC and NEDC jandled alike
        {
            if (UlPdcpPath_ScgShared == pDRBInfo->ulPdcpPathEnqToSet)
            {
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.bit_mask |=
                    E1_Cell_Group_Information_Item_uL_Configuration_present;
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.cell_Group_ID = CellGroupId_MCG;
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.uL_Configuration = E1_shared;

                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.bit_mask |=
                    E1_Cell_Group_Information_Item_uL_Configuration_present;
                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.cell_Group_ID = CellGroupId_SCG;
                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.uL_Configuration = E1_only;

                pDRBInfo->ulPdcpPathToMod = UlConfigBearer_ModOff;
            }
            else if (UlPdcpPath_McgShared == pDRBInfo->ulPdcpPathEnqToSet)
            {
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.bit_mask |=
                    E1_Cell_Group_Information_Item_uL_Configuration_present;
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.cell_Group_ID = CellGroupId_MCG;
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.uL_Configuration = E1_only;

                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.bit_mask |=
                    E1_Cell_Group_Information_Item_uL_Configuration_present;
                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.cell_Group_ID = CellGroupId_SCG;
                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.uL_Configuration = E1_shared;

                pDRBInfo->ulPdcpPathToMod = UlConfigBearer_ModOff;
            }
            else if (UlPdcpPath_ScgOnly == pDRBInfo->ulPdcpPathEnqToSet)
            {
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.bit_mask |=
                    E1_Cell_Group_Information_Item_uL_Configuration_present;
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.cell_Group_ID = CellGroupId_MCG;
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.uL_Configuration = E1_no_data;

                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.bit_mask |=
                    E1_Cell_Group_Information_Item_uL_Configuration_present;
                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.cell_Group_ID = CellGroupId_SCG;
                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.uL_Configuration = E1_only;

                pDRBInfo->ulPdcpPathToMod = UlConfigBearer_ModOff;
            }
            else if (UlPdcpPath_McgOnly == pDRBInfo->ulPdcpPathEnqToSet)
            {
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.bit_mask |=
                    E1_Cell_Group_Information_Item_uL_Configuration_present;
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.cell_Group_ID = CellGroupId_MCG;
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.uL_Configuration = E1_only;

                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.bit_mask |=
                    E1_Cell_Group_Information_Item_uL_Configuration_present;
                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.cell_Group_ID = CellGroupId_SCG;
                ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.uL_Configuration = E1_no_data;

                pDRBInfo->ulPdcpPathToMod = UlConfigBearer_ModOff;
            }
            if (ERROR == VCCB_ConnectLinkedList(ptDrbModifiedConfirmBuffer->cellGroupModified, 2))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_ConnectLinkedList failed in VEIL_fillE1_DRBModifiedItem\n");

                return ERROR;
            }
        }
        else if (MN_Term_MCG_Bearer == pDRBInfo->bearerType.val)
        {
            ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.bit_mask |=
                E1_Cell_Group_Information_Item_uL_Configuration_present;
            ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.cell_Group_ID = CellGroupId_MCG;
            ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.uL_Configuration = E1_only;
            ptDrbModifiedConfirmBuffer->cellGroupModified[0].next = nullptr;
        }
        else if (IS_MRDC(ptCi))
        {
            if (SN_Term_SPLIT_Bearer == pDRBInfo->bearerType.val)
            {
                if (UlPdcpPath_ScgShared == pDRBInfo->ulPdcpPathEnqToSet)
                {
                    ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.bit_mask |=
                        E1_Cell_Group_Information_Item_uL_Configuration_present;
                    ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.cell_Group_ID = CellGroupId_MCG;
                    ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.uL_Configuration = E1_shared;

                    ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.bit_mask |=
                        E1_Cell_Group_Information_Item_uL_Configuration_present;
                    ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.cell_Group_ID = CellGroupId_SCG;
                    ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.uL_Configuration = E1_only;

                    // pDRBInfo->ulPdcpPathToMod = UlConfigBearer_ModOff;
                }
                else if (UlPdcpPath_McgShared == pDRBInfo->ulPdcpPathEnqToSet)
                {
                    ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.bit_mask |=
                        E1_Cell_Group_Information_Item_uL_Configuration_present;
                    ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.cell_Group_ID = CellGroupId_MCG;
                    ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.uL_Configuration = E1_only;

                    ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.bit_mask |=
                        E1_Cell_Group_Information_Item_uL_Configuration_present;
                    ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.cell_Group_ID = CellGroupId_SCG;
                    ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.uL_Configuration = E1_shared;

                    pDRBInfo->ulPdcpPathToMod = UlConfigBearer_ModOff;
                }
                else if (UlPdcpPath_ScgOnly == pDRBInfo->ulPdcpPathEnqToSet)
                {
                    ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.bit_mask |=
                        E1_Cell_Group_Information_Item_uL_Configuration_present;
                    ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.cell_Group_ID = CellGroupId_MCG;
                    ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.uL_Configuration = E1_no_data;

                    ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.bit_mask |=
                        E1_Cell_Group_Information_Item_uL_Configuration_present;
                    ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.cell_Group_ID = CellGroupId_SCG;
                    ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.uL_Configuration = E1_only;

                    // pDRBInfo->ulPdcpPathToMod = UlConfigBearer_ModOff;
                }
                else if (UlPdcpPath_McgOnly == pDRBInfo->ulPdcpPathEnqToSet)
                {
                    ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.bit_mask |=
                        E1_Cell_Group_Information_Item_uL_Configuration_present;
                    ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.cell_Group_ID = CellGroupId_MCG;
                    ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.uL_Configuration = E1_only;

                    ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.bit_mask |=
                        E1_Cell_Group_Information_Item_uL_Configuration_present;
                    ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.cell_Group_ID = CellGroupId_SCG;
                    ptDrbModifiedConfirmBuffer->cellGroupModified[1].value.uL_Configuration = E1_no_data;
                }

                int16_t ret = VCCB_ConnectLinkedList(ptDrbModifiedConfirmBuffer->cellGroupModified, 2);
                VCCB_RETURN_ON_CALL_ERROR( // return ERROR
                        ptCi, ret, "ERROR: VCCB_ConnectLinkedList failed in VEIL_fillE1_DRBModifiedItem\n");

            }
            else if (SN_Term_SCG_Bearer == pDRBInfo->bearerType.val)
            {
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.bit_mask |=
                    E1_Cell_Group_Information_Item_uL_Configuration_present;
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.cell_Group_ID = CellGroupId_SCG;
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.uL_Configuration = E1_only;
                ptDrbModifiedConfirmBuffer->cellGroupModified[0].next = nullptr;
            }
        }
        else if (IS_NEDC(ptCi))
        {
            if (SN_Term_SCG_Bearer == pDRBInfo->bearerType.val || SN_Term_SPLIT_Bearer == pDRBInfo->bearerType.val)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "ERROR:VEIL_fillE1_DRBModifiedItem SN_Term_SCG_Bearer and SN_Term_SPLIT_Bearer are "
                    "not supported in NE-DC\n");
                return ERROR;
            }
        }

        if (0==ptDrbModifiedConfirmBuffer->cellGroupModified[0].value.bit_mask)
        {
            drbConfirmModItem->bit_mask = 0;
            return GOOD;
        }

        // Connect Cell Group To Modify List
        drbConfirmModItem->cell_Group_Information = ptDrbModifiedConfirmBuffer->cellGroupModified;
        drbConfirmModItem->bit_mask |= E1_DRB_Confirm_Modified_Item_NG_RAN_cell_Group_Information_present;
    }

    return GOOD;
}

/**
 * @brief fill E1 DRB To Remove Item
 * @attention function sets all bit_mask
 * @param [in]     rCall            : callInfo DB
 * @param [in]     rDrb             : drb DB
 * @param [in/out] rDrbToRelease    : buffer of E1_DRB_To_Remove_Item_NG_RAN
 */
void VEIL_fillE1_DRBToRemoveItemNGRAN(callInfo_type &rCall, callDRBInfo_type &rDrb,
        E1_DRB_To_Remove_Item_NG_RAN &rDrbToRelease)
{
    (void) rCall;

    rDrbToRelease.bit_mask = 0;
    rDrbToRelease.dRB_ID = rDrb.dRBId;

#ifdef IPC_TEST
    FnVCCB_CheckE1_DRBToRemoveItemNGRAN(rCall, rDrb, rDrbToRelease);
#endif
}

bool FnVCCB_is_E1_PDUSessToBeSetup(callInfo_type *ptCi, callPDUSessInfo_type *ptPi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptPi, false);

    if (IS_NRDC(ptCi))
    {
        if (IS_NRDC_SN(ptCi) && (FALSE == FnVCCB_ExistValidSNTermBearerInPdu(ptCi, ptPi))) return false;

        if (S_Setup == ptPi->pduSessStatus)
        {
            if (true == FnVCCB_IsBearerControlOnCurrentBearerType(ptCi))
            {
                return false;
            }

            return true;
        }
        else if ((S_Modify == ptPi->pduSessStatus) && (FALSE == ptPi->isE1Setupped))
        {
            VCCB_PRINT_CALL_DATA(ptCi, "[E1DBG] PDU TO be SETUP (pduSessStatus:%d, isE1Setupped:%d)\n",
                ptPi->pduSessStatus, ptPi->isE1Setupped);
            // MN CASE) SN-term Bearer only -> SN-term + MN-term Bearer
            // SN CASE) MN-term Bearer only -> MN-term + SN-term Bearer
            return true;
        }
    }
    else
    {
        if (S_Setup == ptPi->pduSessStatus)
        {
            return true;
        }
    }

    VCCB_PRINT_CALL_DATA(ptCi, "[E1DBG] pduSessId(%d) is not required to setup! (pduSessStatus:%d, isE1Setupped:%d)\n",
        ptPi->pduSessId, ptPi->pduSessStatus, ptPi->isE1Setupped);

    return false;
}

bool FnVCCB_CheckTermPointDrbExistInPdu(callInfo_type& rCall, callPDUSessInfo_type& rPdu)
{
    for(const auto& drbIdx : rPdu.drbIndex)
    {
        if (drbIdx >= MAX_DRB_PER_SA_CALL) continue;

        callDRBInfo_type& drb = rCall.drb[drbIdx];
        if (drb.usage != CI_use) continue;

        if(VLIB_IsCommonValidStateOfPduQosDrb(drb.drbStatus) != GOOD) continue;
        
        bool termPointDrbExist = false;
        if (IS_NRDC_SN(&rCall))
        {
            termPointDrbExist = FnVCCB_IsSnTermPerDRB(&rCall, &drb, request_bearerType);
        }
        else
        {
            termPointDrbExist = FnVCCB_IsMnTermPerDRB(&rCall, &drb, request_bearerType);
        }

        if (termPointDrbExist)
        {
            return true;
        }
    }

    return false;
}

bool FnVCCB_is_E1_PDUSessToBeRelease(callInfo_type *ptCi, callPDUSessInfo_type *ptPi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptPi, false);

    if (!ptPi->isE1Setupped)
    {
        // PDU Session is already released
        return false;
    }

    if (IS_NRDC_SN(ptCi) && (TRUE == ptCi->bitFlag.isDrbPreemptionCase))
    {
        switch (ptCi->state)
        {
            case STATE_SN_SNModPrepare_XnModRqrd:  // For sending txStop
            case STATE_SN_SNModExec:               // For sending Data Forwarding Information
            case STATE_SN_SNModPrepare_F1Mod1:     // For sending PDSP SN Status Request
                // Even if pduSessStatus is S_Release, PDU Release procedure should not perform in this state.
                return false;
            default:
                break;
        }
    }

    if (S_Release == ptPi->pduSessStatus)
    {
        return true;
    }

    switch (ptCi->state)
    {
        case STATE_SNAddComplt_E1F1NGMod:
        case STATE_SNModComplt_E1F1NGMod:
            if (FnVCCB_DoesPDUSessNeedTobeReleasedAtMnUp(ptCi, ptPi))
            {
                return true;
            }
            break;
        default:
            break;
    }

    // Check DRB Partial Rollback.
    // SVR25A FGR-MC1009 FR200
    if (IS_STATECMD_SUPPORT_DRB_PARTIAL(ptCi))
    {
        if ((ptPi->pduSessStatus == S_FailToSetup) ||
            ((ptPi->pduSessStatus == S_FailToModify) && (ptPi->firstReqStatusInThisProcedure == S_Setup)))
        {
            if (ptPi->needToReconfigE1ByF1Fail == TRUE)
            {
                return true;
            }
        }
        // SVR25B FGR-CC5200 FR1050
        else if (ptPi->pduSessStatus == S_Modify && ptPi->firstReqStatusInThisProcedure == S_Setup)
        {
            if(IS_NRDC(ptCi) && not FnVCCB_CheckTermPointDrbExistInPdu(*ptCi, *ptPi))
            {
                return true;
            }
        }
    }

    return false;
}

// 9_3_3_2 PDU Session Resource To Setup List
int VEIL_fillE1_PDUSessToSetupItem_DRBToSetupList(callInfo_type *ptCi, callPDUSessInfo_type *ptPi,
    E1_PDU_Session_Resource_To_Setup_Item *pduSessToSetupItem,
    E1_BearerContextSetupRequestBuffer::PduSessToBeSetupData *ptPduSessToBeSetupBuffer, enumE1F1procedure_type procedure)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptPi);
    VALID_E_POINT_CHECK_ERROR(pduSessToSetupItem);
    VALID_E_POINT_CHECK_ERROR(ptPduSessToBeSetupBuffer);

    int status;
    uint32_t loop = 0;
    uint16_t numDrb = 0;
    callDRBInfo_type *ptDi = NULL;

    for (loop = 0; loop < MAX_DRB_PER_PDU_SESS; loop++)
    {
        if (ptPi->drbIndex[loop] >= MAX_DRB_PER_SA_CALL)  // Not yet allocated
            continue;

        ptDi = &ptCi->drb[ptPi->drbIndex[loop]];

        if (CI_use != ptDi->usage) continue;
        if (S_Setup != ptDi->drbStatus) continue;

        if (IS_MRDC_MN(ptCi) && (FnVCCB_IsMnTermPerDRB(ptCi, ptDi, request_bearerType) == false))
        {
            VCCB_PRINT_CALL_DATA(ptCi, "[E1DBG] ptCi->drb[%d] is not MN Term Bearer\n", ptPi->drbIndex[loop]);
            continue;
        }
        else if (IS_NRDC_SN(ptCi) && (TermPoint_Sn != ptDi->bearerType.termPoint))
        {
            VCCB_PRINT_CALL_DATA(ptCi, "[E1DBG] ptCi->drb[%d] is not SN Term Bearer\n", ptPi->drbIndex[loop]);
            continue;
        }

        // DRB To Setup Item Fill - mandatory
        status = VEIL_fillE1_DRBToSetupItem(ptCi, static_cast<uint8_t>(ptPi->drbIndex[loop]), numDrb, ptPduSessToBeSetupBuffer, procedure);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_DRBToSetupItem ERROR!!\n");

        ++numDrb;
    }

    if (numDrb == 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "No DRB in pduSessToSetupItem!\n");
        return ERROR;
    }

    pduSessToSetupItem->dRB_To_Setup_List_NG_RAN = ptPduSessToBeSetupBuffer->drbToSetupList;

    // Connect DRB To Setup List
    status = VCCB_ConnectLinkedList(pduSessToSetupItem->dRB_To_Setup_List_NG_RAN, static_cast<int>(numDrb));
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_ConnectLinkedList failed in %s-> DRB To Setup List!\n", __func__);

    return GOOD;
}

int VEIL_fillE1_PDUSessToSetupItem(E1_PDU_Session_Resource_To_Setup_Item *pduSessToSetupItem,
    E1_BearerContextSetupRequestBuffer::PduSessToBeSetupData *ptPduSessToBeSetupBuffer, callInfo_type *ptCi,
    callPDUSessInfo_type *pPDUSessInfo)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pduSessToSetupItem);
    VALID_E_POINT_CHECK_ERROR(ptPduSessToBeSetupBuffer);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pPDUSessInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    int status = GOOD;

    pduSessToSetupItem->bit_mask = 0;

    // 1. M - PDU Session ID (9_3_1_21)
    pduSessToSetupItem->pDU_Session_ID = static_cast<E1_PDU_Session_ID>(pPDUSessInfo->pduSessId);

    // 2. M - PDU Session Type (9_3_1_22)
    pduSessToSetupItem->pDU_Session_Type = static_cast<E1_PDU_Session_Type>(pPDUSessInfo->pduSessType);

    // 3. M - S-NSSAI (9_3_1_9)
    status = VEIL_fillE1_SNSSAI(&pduSessToSetupItem->sNSSAI, &pPDUSessInfo->sNssai);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_SNSSAI ERROR\n");

    // 4. M - Security Indication (9_3_1_23)
    VEIL_FillE1_SecurityIndication(&pduSessToSetupItem->securityIndication, &pPDUSessInfo->securityInd);

    // 5. O - PDU Session Resource DL Aggregate Maximum Bit (9_3_1_20)
    // This IE shall be present when at least one non-GBR QoS Flows is being setup.
    if (VCCM_CheckNonGbrQosFlowInPduSession(ptCi, pPDUSessInfo) == TRUE)
    {
        pduSessToSetupItem->bit_mask |= E1_PDU_Session_Resource_To_Setup_Item_pDU_Session_Resource_DL_AMBR_present;
        pduSessToSetupItem->pDU_Session_Resource_DL_AMBR = static_cast<E1_BitRate>(pPDUSessInfo->pduSessAmbrDL);
    }

    // 6. M - NG UL UP Transport Layer Information (9_3_2_1)
    {
        status =
            VEIL_fillE1_UP_TNL_Information(&pduSessToSetupItem->nG_UL_UP_TNL_Information, &pPDUSessInfo->nGuUlInfo);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_UP_TNL_Information ERROR!\n");
    }

    // 7. O - PDU Session Data Forwarding Information Request (9_3_2_5)
    if (true == VEIL_check_E1_PDU_Data_Forwarding_Information_request(ptCi, pPDUSessInfo))
    {
        uint8_t numQoSFlow = 0;
        VEIL_fillE1_PDU_Data_Forwarding_Information_request(
            &pduSessToSetupItem->pDU_Session_Data_Forwarding_Information_Request,
            ptPduSessToBeSetupBuffer->qosToModList, ptCi, pPDUSessInfo, &numQoSFlow);

        if (numQoSFlow)
        {
            pduSessToSetupItem->bit_mask |=
                E1_PDU_Session_Resource_To_Setup_Item_pDU_Session_Data_Forwarding_Information_Request_present;
        }
    }

    // 8. O - PDU Session Inactivity Timer (9_3_1_54)
    if (true == VEIL_check_E1_Inactivity_Timer(ptCi, pPDUSessInfo))
    {
        status = VEIL_fillE1_Inactivity_Timer(ptCi, pPDUSessInfo, &pduSessToSetupItem->pDU_Session_Inactivity_Timer);
        if (status == GOOD)
        {
            pduSessToSetupItem->bit_mask |= E1_PDU_Session_Resource_To_Setup_Item_pDU_Session_Inactivity_Timer_present;
        }
    }

    // 9. O - Existing Allocated NG DL UP Transport Layer Information (9_3_2_1)
    if (1 == pPDUSessInfo->nGuDlInfo.fNeedModify)
    {
        pduSessToSetupItem->bit_mask |= E1_existing_Allocated_NG_DL_UP_TNL_Info_present;

        status = VEIL_fillE1_UP_TNL_Information(
            &pduSessToSetupItem->existing_Allocated_NG_DL_UP_TNL_Info, &pPDUSessInfo->nGuDlInfo);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_UP_TNL_Information ERROR!\n");

        pPDUSessInfo->nGuDlInfo.fNeedModify = 0;
    }

    // 10. O - Network Instance
    // 11. O - Common Network Instance

    // 12. M - DRB To Setup List
    status =
        VEIL_fillE1_PDUSessToSetupItem_DRBToSetupList(ptCi, pPDUSessInfo, pduSessToSetupItem, ptPduSessToBeSetupBuffer, E1F1Setup);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_PDUSessToSetupItem_DRBToSetupList ERROR!\n");

    // 13. O - Redundant NG UL UP Transport Layer Information (9_3_2_1)
    // 14. O - Redundant Common Network Instancer (9_3_1_66)
    // 15. O - Redundant PDU Session Informationr (9_3_1_80)

    return status;
}

// 9_3_3_10 PDU Session Resource To Setup Modification List
int VEIL_fillE1_PDUSessToSetupModItem_DRBToSetupList(callInfo_type *ptCi, callPDUSessInfo_type *ptPi,
    E1_PDU_Session_Resource_To_Setup_Mod_Item *pduSessToSetupModItem,
    E1_BearerContextModificationRequestBuffer::PduSessToBeSetupModData *ptPduSessToBeSetupModBuffer)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptPi);
    VALID_E_POINT_CHECK_ERROR(pduSessToSetupModItem);
    VALID_E_POINT_CHECK_ERROR(ptPduSessToBeSetupModBuffer);

    int status;
    uint32_t loop = 0;
    unsigned int numDrb = 0;
    callDRBInfo_type *ptDi = NULL;

    for (loop = 0; loop < MAX_DRB_PER_PDU_SESS; loop++)
    {
        uint8_t drbIdx = static_cast<uint8_t>(ptPi->drbIndex[loop]);
        if (ptPi->drbIndex[loop] >= MAX_DRB_PER_SA_CALL)  // Not yet allocated
            continue;

        ptDi = &ptCi->drb[ptPi->drbIndex[loop]];

        if (CI_use != ptDi->usage) continue;
        if (S_Setup != ptDi->drbStatus) continue;

        if (IS_MRDC_MN(ptCi) && (FnVCCB_IsMnTermPerDRB(ptCi, ptDi, request_bearerType) == false))
        {
            VCCB_PRINT_CALL_DATA(ptCi, "[E1DBG] ptCi->drb[%d] is not MN Term Bearer\n", ptPi->drbIndex[loop]);
            continue;
        }
        else if (IS_NRDC_SN(ptCi) && (TermPoint_Sn != ptDi->bearerType.termPoint))
        {
            VCCB_PRINT_CALL_DATA(ptCi, "[E1DBG] ptCi->drb[%d] is not SN Term Bearer\n", ptPi->drbIndex[loop]);
            continue;
        }

        // DRB To Setup Item Fill
        status = VEIL_fillE1_DRBToSetupModItem(&ptPduSessToBeSetupModBuffer->drbToSetupModList[numDrb].value,
            &ptPduSessToBeSetupModBuffer->drbToSetupModData[numDrb], ptCi, drbIdx, ptPduSessToBeSetupModBuffer, numDrb, E1F1Modify_SetupMod);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_DRBToSetupModItem ERROR!!\n");

        ++numDrb;
    }

    if (numDrb == 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "No DRB in pduSessToSetupModItem <pduSessId:%u,pduStatus:%d>!\n", ptPi->pduSessId,
            ptPi->pduSessStatus);
        return ERROR;
    }

    pduSessToSetupModItem->dRB_To_Setup_Mod_List_NG_RAN = ptPduSessToBeSetupModBuffer->drbToSetupModList;

    // Connect DRB To Setup List
    status = VCCB_ConnectLinkedList(pduSessToSetupModItem->dRB_To_Setup_Mod_List_NG_RAN, static_cast<int>(numDrb));
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_ConnectLinkedList failed in %s-> DRB To Setup Mod List!\n", __func__);

    return GOOD;
}

/**
 * @brief fill E1 PDU Session Resource To Setup Item for Bearer Context Modification Request Procedure
 * @attention function sets all bit_mask
 * @param [in]  ptBearerModificationRequestBuffer   : E1_BearerContextModificationRequestBuffer buffer
 * @param [in]  pPDUSessInfo                        : callPDUSessInfo DB
 * @param [in]  ptCi                                : callInfo DB
 * @param [out] pduSessToSetupModItem               : E1_PDU_Session_Resource_To_Setup_Mod_Item buffer
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_fillE1_PDUSessToSetupModItem(E1_PDU_Session_Resource_To_Setup_Mod_Item *pduSessToSetupModItem,
    E1_BearerContextModificationRequestBuffer::PduSessToBeSetupModData *ptPduSessToBeSetupModBuffer,
    callInfo_type *ptCi, callPDUSessInfo_type *pPDUSessInfo)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pduSessToSetupModItem);
    VALID_E_POINT_CHECK_ERROR(ptPduSessToBeSetupModBuffer);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pPDUSessInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    int status = GOOD;

    pduSessToSetupModItem->bit_mask = 0;

    // 1. M - PDU Session ID (9_3_1_21)
    pduSessToSetupModItem->pDU_Session_ID = pPDUSessInfo->pduSessId;

    // 2. M - PDU Session Type (9_3_1_22)
    pduSessToSetupModItem->pDU_Session_Type = static_cast<E1_PDU_Session_Type>(pPDUSessInfo->pduSessType);

    // 3. M - S-NSSAI (9_3_1_9)
    status = VEIL_fillE1_SNSSAI(&pduSessToSetupModItem->sNSSAI, &pPDUSessInfo->sNssai);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_SNSSAI ERROR\n");

    // 4. M - Security Indication (9_3_1_23)
    VEIL_FillE1_SecurityIndication(&pduSessToSetupModItem->securityIndication, &pPDUSessInfo->securityInd);

    // 5. O - PDU Session Resource DL Aggregate Maximum Bit (9_3_1_20)
    // This IE shall be present when non-GBR QoS Flows are setting up.
    if (VCCM_CheckNonGbrQosFlowInPduSession(ptCi, pPDUSessInfo) == TRUE)
    {
        pduSessToSetupModItem->bit_mask |= E1_pDU_Session_Resource_AMBR_present;
        pduSessToSetupModItem->pDU_Session_Resource_AMBR = static_cast<E1_BitRate>(pPDUSessInfo->pduSessAmbrDL);
    }

    // 6. M - NG UL UP Transport Layer Information (9_3_2_1)
    {
        status =
            VEIL_fillE1_UP_TNL_Information(&pduSessToSetupModItem->nG_UL_UP_TNL_Information, &pPDUSessInfo->nGuUlInfo);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_UP_TNL_Information ERROR!\n");
    }

    // 7. O - PDU Session Data Forwarding Information Request (9_3_2_5) : TBD

    // 8. O - PDU Session Inactivity Timer (9_3_1_54)
    if (true == VEIL_check_E1_Inactivity_Timer(ptCi, pPDUSessInfo))
    {
        status = VEIL_fillE1_Inactivity_Timer(ptCi, pPDUSessInfo, &pduSessToSetupModItem->pDU_Session_Inactivity_Timer);
        if (status == GOOD)
        {
            pduSessToSetupModItem->bit_mask |=
                E1_PDU_Session_Resource_To_Setup_Mod_Item_pDU_Session_Inactivity_Timer_present;
        }
    }

    // 9. O - Network Instance : TBD
    // 10. O - Common Network Instance: TBD

    // 11. M - DRB To Setup List
    status = VEIL_fillE1_PDUSessToSetupModItem_DRBToSetupList(
        ptCi, pPDUSessInfo, pduSessToSetupModItem, ptPduSessToBeSetupModBuffer);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_PDUSessToSetupModItem_DRBToSetupList ERROR!\n");

    // 12. O - Redundant NG UL UP Transport Layer Information (9_3_2_1)
    // 13. O - Redundant Common Network Instancer (9_3_1_66)

    return status;
}

bool FnVCCB_IsNeedUpdateMnTermScgLegTNL(callInfo_type *ptCi, callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    if (ptDi->f1uDlInfo.fNeedModify == 1) return true;
    if (ptDi->xNuDlInfo.fNeedModify == 1) return true;

    return false;
}

/**
 * @brief fill E1 PDU Session Resource To Modify Item for Beaerer Context Modification Request after F1 UE Context Setup
 * Response
 * @attention function sets all bit_mask
 * @param [in]  ptPduSessToBeModBuffer              : E1_BearerContextModificationRequestBuffer buffer
 * @param [in]  ptCi                                : callInfo DB
 * @param [in]  pPDUSessInfo                        : callPDUSessInfo DB
 * @param [in]  pduSessNumber                       : number of PDU Session Resource item
 * @param [out] pduSessToModifyItem                 : E1_PDU_Session_Resource_To_Modify_Item buffer
 * @return      GOOD                                : success fill
 * @return      ERROR                               : fill error
 */
int VEIL_PDUSessToModifyItem_Add_fillE1_DRB(callPDUSessInfo_type *pPDUSessInfo, callInfo_type *ptCi,
    E1_BearerContextModificationRequestBuffer::PduSessToBeModData *ptPduSessToBeModBuffer, unsigned int *numDrbAddp,
    unsigned int *numDrbModp, unsigned int *numDrbRelp)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptPduSessToBeModBuffer);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pPDUSessInfo);
    VALID_E_POINT_CHECK_ERROR(numDrbAddp);
    VALID_E_POINT_CHECK_ERROR(numDrbModp);
    VALID_E_POINT_CHECK_ERROR(numDrbRelp);

    int status = 0;
    unsigned int loop = 0;

    callDRBInfo_type *ptDi;

    AllowedStatus isSetupAllowed = Allowed;

    switch (ptCi->state)
    {
        case STATE_INTRA_DU_SnRelB:
        case STATE_INTER_DU_SnRelB:
            // E1 is sent after Setup has already been completed. (E1-> E1)
            isSetupAllowed = Not_Allowed;
            break;

        default:
            break;
    }

    for (loop = 0; loop < MAX_DRB_PER_PDU_SESS; loop++)
    {
        bool dlTrfStatusRptCfgOnly = false;
        uint8_t drbIdx = static_cast<uint8_t>(pPDUSessInfo->drbIndex[loop]);

        if (drbIdx >= MAX_DRB_PER_SA_CALL)  // Not yet allocated
            continue;

        ptDi = &ptCi->drb[drbIdx];

        if (CI_use != ptDi->usage) continue;

        if (IS_NRDC_SN(ptCi) && (TermPoint_Sn != ptDi->bearerType.termPoint)) continue;

        if (S_Setup == ptDi->drbStatus && isSetupAllowed == Allowed)
        {
            if (true == FnVCCB_IsBearerControlOnCurrentBearerType(ptCi))
            {
                continue;
            }

            // check the SN terminated bearer for MN
            if (IS_MRDC_MN(ptCi))
            {
                // STATE_INTRA_DU_SnRelB includes the PDU setup
                if (FnVCCB_IsMnTermPerDRB(ptCi, ptDi, request_bearerType) == false) continue;

                if (DBG->flag.SNAdditionRejectE1Mod)
                {
                    //MN_Term_MCG_Bearer doesn't need setup when PDU Modification due to SN Release
                    if (ptCi->stateCmd == IntraRatHO_cmd && ptDi->bearerType.val == MN_Term_MCG_Bearer &&
                        ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
                        continue;
                }
            }

            // DRB To Setup Item Fill
            status = VEIL_fillE1_DRBToSetupItem(ptCi, drbIdx, static_cast<uint16_t>(*numDrbAddp),
                reinterpret_cast<E1_BearerContextSetupRequestBuffer::PduSessToBeSetupData *>(ptPduSessToBeModBuffer), E1F1Modify_Setup);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_DRBToSetupItem ERROR!!\n");

            ++(*numDrbAddp);
        }
        else if (((S_FailToSetup == ptDi->drbStatus) || (S_FailToModify == ptDi->drbStatus)) &&
                (S_Setup == ptDi->firstReqStatusInThisProcedure)) 
        {
            if (TRUE == ptDi->needToReconfigE1ByF1Fail || TRUE == ptDi->needToReconfigE1BySnFail)
            {
                // DRB To Release Item Fill
                VEIL_fillE1_DRBToRemoveItemNGRAN(*ptCi, *ptDi, ptPduSessToBeModBuffer->drbToRemList[*numDrbRelp].value);

                ++(*numDrbRelp);

                ptDi->needToReconfigE1ByF1Fail = FALSE;
                ptDi->needToReconfigE1BySnFail = FALSE;
            }
        }
        else if ((S_Modify == ptDi->drbStatus) ||
                 (TRUE == VEIL_checkE1_NeedToBearerModifiedItem(ptCi, ptDi->drbStatus)) ||
                 (TRUE == VEIL_checkE1_NeedToBearerModifiedItemForMRDC(ptCi, (void *)ptDi, true)) ||
                 (TRUE == FnVCCB_CheckE1_NeedToBearerModifiedItemForNRDC_SN(ptCi, (void *)ptDi, true)) ||
                 (dlTrfStatusRptCfgOnly = NEED_DlTrfStatusRptCfg_TO_BE_REFRESHED_PER_DRB(
                      ptCi, drbIdx)))  // <= this condition check must be kept at end
        {
            // check the SN terminated bearer for MN
            if (IS_MRDC_MN(ptCi))
            {
                // DRB is S_Modify when INTER_DU_Prepare (F1_UEContextSetupResponse case...)
                uint8_t curBearerType = FnVCCB_getSaDrbBearerType(ptCi, ptDi, current_bearerType);
                uint8_t reqBearerType = FnVCCB_getSaDrbBearerType(ptCi, ptDi, request_bearerType);

                if (curBearerType == reqBearerType)
                {
                    if (IS_SN_TERM(*ptDi))
                    {
                        continue;   // There is no UP resource
                    }
                    if (IS_MN_TERM(*ptDi))
                    {
                        if (ptCi->state == STATE_INTRA_DU_SnRelB || ptCi->state == STATE_INTER_DU_SnRelB)
                            continue;   // Sending seqNum is required for SN term bearer

                        if (curBearerType == MN_Term_MCG_Bearer)
                        {
                            // MN Term MCG is not target to change.
                            if (ptCi->state == STATE_INTRA_DU_SnRelA || ptCi->state == STATE_INTER_DU_SnRelA) continue;

                            // For SN Key change without MN Key Change, we will skip MN Term MCG
                            if (VCCB_FLAG_ON == ptCi->ueInfo.snKeyChangeWOMnKeyChange) continue;
                        }
                    }
                }
                else
                {
                    switch (ptCi->state)
                    {
                        // DL TX Resume for MN term bearer
                        case STATE_INTRA_DU_Cancel:
                        case STATE_INTER_DU_Cancel:
                            if (IS_SN_TERM(*ptDi)) continue; 
                            break;

                            // Send seqNUm for SN term bearer
                        case STATE_INTRA_DU_SnRelB:
                        case STATE_INTER_DU_SnRelB:
                            if (IS_MN_TERM(*ptDi)) continue;
                            break;

                        default:
                            break;
                    }
                }
            }
            else if (IS_NRDC_SN(ptCi))
            {
                switch (ptCi->state)
                {
                    case STATE_SN_INTER_DU_Exe_MN:
                    case STATE_SN_INTRA_DU_Exe_MN:
                        // The above state machine is a procedure for updating TNL of MN Term Split and MN Term SCG.
                        // If there is no TNL to update, update is not performed.
                        if (FnVCCB_IsNeedUpdateMnTermScgLegTNL(ptCi, ptDi) == false) continue;
                        break;

                    default:
                        break;
                }
            }

            // DRB To Modify Item Fill
            status =
                VEIL_fillE1_DRBToModifyItem(ptCi, drbIdx, static_cast<uint16_t>(*numDrbModp), ptPduSessToBeModBuffer, dlTrfStatusRptCfgOnly, E1F1Modify_Modify);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_DRBToModifyItem ERROR!!\n");

            /* skip no information case */
            if (status == BREAK)
            {
                continue;
            }

            ++(*numDrbModp);
        }
        else if (ptDi->bearerType.val == MN_Term_MCG_Bearer && ptDi->reqBearerType.termPoint == TermPoint_Sn &&
                 (ptCi->state == STATE_SNAddComplt_E1F1NGMod || ptCi->state == STATE_SNModComplt_E1F1NGMod))
        {
            VEIL_fillE1_DRBToRemoveItemNGRAN(*ptCi, *ptDi, ptPduSessToBeModBuffer->drbToRemList[*numDrbRelp].value);

            ++(*numDrbRelp);

            VCCB_PRINT_CALL_DATA(
                ptCi, "DRB(Id:%u) is to be released by the change of PDCP Termination Point!!\n", ptDi->dRBId);
        }
        else if ((S_Release == ptDi->drbStatus))
        {
            // Already sent Drb Release Information to UP on previous E1 Modification.
            if (ptCi->state == STATE_PDUChg_F1Mod) continue;
            if (ptCi->state == STATE_RRE_Ready) continue;
            if (ptCi->state == STATE_RRE_RRCRecCmpl) continue;
            if (IS_NRDC_MN(ptCi) && (TermPoint_Sn == ptDi->bearerType.termPoint)) continue;
            if (IS_NRDC_SN(ptCi) && VCCB_IS_REMOVE_SKIP_STATE_IN_NRDC_SN(ptCi)) continue;

            // SVR26A FGR-TA0601 VoMA CallEvent
            ptCi->vomaInfo.vomaEvent = VOMA_drbRelease;
            ptDi->vomaStatus.upStatus = VOMA_UNKNOWN;
            ptDi->vomaStatus.duStatus = VOMA_UNKNOWN;
            // DRB To Release Item Fill
            VEIL_fillE1_DRBToRemoveItemNGRAN(*ptCi, *ptDi, ptPduSessToBeModBuffer->drbToRemList[*numDrbRelp].value);

            ++(*numDrbRelp);
        }
    }

    return GOOD;
}

// 9_3_3_11 PDU Session Resource To Modify List
int VEIL_fillE1_PDUSessToModifyItem_Add_DRBToSetupModifyReleaseList(callInfo_type *ptCi, callPDUSessInfo_type *ptPi,
    E1_PDU_Session_Resource_To_Modify_Item *pduSessToModifyItem,
    E1_BearerContextModificationRequestBuffer::PduSessToBeModData *ptPduSessToBeModBuffer)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptPi);
    VALID_E_POINT_CHECK_ERROR(pduSessToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptPduSessToBeModBuffer);

    int status;
    unsigned int numDrbAdd = 0, numDrbMod = 0, numDrbRel = 0;

    status =
        VEIL_PDUSessToModifyItem_Add_fillE1_DRB(ptPi, ptCi, ptPduSessToBeModBuffer, &numDrbAdd, &numDrbMod, &numDrbRel);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_PDUSessToModifyItem_Add_fillE1_DRB ERROR!\n");

    if (numDrbAdd)
    {
        pduSessToModifyItem->bit_mask |= E1_dRB_To_Setup_List_NG_RAN_present;
        pduSessToModifyItem->dRB_To_Setup_List_NG_RAN = ptPduSessToBeModBuffer->drbToSetupList;

        // Connect DRB To Setup List
        status = VCCB_ConnectLinkedList(pduSessToModifyItem->dRB_To_Setup_List_NG_RAN, static_cast<int>(numDrbAdd));
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_ConnectLinkedList failed in %s-> DRB To Setup List!\n", __func__);
    }

    if (numDrbMod)
    {
        pduSessToModifyItem->bit_mask |= E1_dRB_To_Modify_List_NG_RAN_present;
        pduSessToModifyItem->dRB_To_Modify_List_NG_RAN = ptPduSessToBeModBuffer->drbToModList;

        // Connect DRB To Modify List
        status = VCCB_ConnectLinkedList(pduSessToModifyItem->dRB_To_Modify_List_NG_RAN, static_cast<int>(numDrbMod));
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_ConnectLinkedList failed in %s-> DRB To Mod List!\n", __func__);
    }

    if (numDrbRel)
    {
        pduSessToModifyItem->bit_mask |= E1_dRB_To_Remove_List_NG_RAN_present;
        pduSessToModifyItem->dRB_To_Remove_List_NG_RAN = ptPduSessToBeModBuffer->drbToRemList;

        // Connect DRB To Release List
        status = VCCB_ConnectLinkedList(pduSessToModifyItem->dRB_To_Remove_List_NG_RAN, static_cast<int>(numDrbRel));
        VCCB_RETURN_ON_CALL_ERROR(
            ptCi, status, "VCCB_ConnectLinkedList failed in %s-> DRB To Remove List!\n", __func__);

        // SVR26A FGR-TA0601 VoMA CallEvent
        ptCi->vomaInfo.vomaEvent = VOMA_drbRelease;
    }

    return GOOD;
}

int FnVCCB_fillE1_SNSSAI_ieExtensions(
    struct E1_ProtocolExtensionContainer_ *ptIE, struct E1_SNSSAI *pSnssai, callSNSSAI_type *sNssai)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptIE);
    VALID_E_POINT_CHECK_ERROR(pSnssai);

    pSnssai->bit_mask = 0;

    // SST - mandatory
    MACRO_PACK_OCTET(&pSnssai->sST, 1, sNssai->sst);  // OCTET STRING(1)

    // SD - optional
    if (sNssai->sdPresent)
    {
        pSnssai->bit_mask |= E1_sD_present;
        MACRO_PACK_OCTET(&pSnssai->sD, 3, sNssai->sd);  // OCTET STRING(3)
    }

    InsertE1_ExtensionContainerValue(ptIE, E1_id_SNSSAI, E1_ignore, pSnssai, E1_SNSSAI_PDU);

    if (DBG->flag.logE1)
        VCCB_PRINT_DATA("[E1DBG] pSnssai->sST.length:%d .value[0]:%d\n", pSnssai->sST.length, pSnssai->sST.value[0]);

    return GOOD;
}

int VEIL_fillE1_PDUSessToModifyItem_Add(E1_PDU_Session_Resource_To_Modify_Item *pduSessToModifyItem,
    E1_BearerContextModificationRequestBuffer::PduSessToBeModData *ptPduSessToBeModBuffer, callInfo_type *ptCi,
    callPDUSessInfo_type *pPDUSessInfo)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pduSessToModifyItem);
    VALID_E_POINT_CHECK_ERROR(ptPduSessToBeModBuffer);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pPDUSessInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    int status = GOOD;
    int ieExtNum = 0;

    pduSessToModifyItem->bit_mask = 0;

    // 1. M - PDU Session Resource ID (9_3_1_21)
    pduSessToModifyItem->pDU_Session_ID = pPDUSessInfo->pduSessId;

    // 2. O - Security Indication (9_3_1_23)
    // There is no bit_mask before refactoring ...
    VEIL_FillE1_SecurityIndication(&pduSessToModifyItem->securityIndication, &pPDUSessInfo->securityInd);

    // 3. O - PDU Session Resource DL Aggregate Maximum Bit Rate (9_3_1_20)

    // This IE shall be present when at least one non-GBR QoS Flows is being setup.
    if (pPDUSessInfo->fNeedModify_pduSessAmbrDL && VCCM_CheckNonGbrQosFlowInPduSession(ptCi, pPDUSessInfo) == TRUE)
    {
        pduSessToModifyItem->bit_mask |= E1_PDU_Session_Resource_To_Modify_Item_pDU_Session_Resource_DL_AMBR_present;
        pduSessToModifyItem->pDU_Session_Resource_DL_AMBR = static_cast<E1_BitRate>(pPDUSessInfo->pduSessAmbrDL);
        pPDUSessInfo->fNeedModify_pduSessAmbrDL = 0;
    }

    // 4. O - NG UL UP Transport Layer Information (9_3_2_1)
    if (1 == pPDUSessInfo->nGuUlInfo.fNeedModify)
    {
        pduSessToModifyItem->bit_mask |= E1_nG_UL_UP_TNL_Information_present;

        status =
            VEIL_fillE1_UP_TNL_Information(&pduSessToModifyItem->nG_UL_UP_TNL_Information, &pPDUSessInfo->nGuUlInfo);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_FillE1_UP_TNL_Information ERROR!\n");

        pPDUSessInfo->nGuUlInfo.fNeedModify = 0;
    }

    // 5. O - PDU Session Data Forwarding Information Request (9_3_2_5)
    if (true == VEIL_check_E1_PDU_Data_Forwarding_Information_request(ptCi, pPDUSessInfo))
    {
        uint8_t numQoSFlow = 0;
        VEIL_fillE1_PDU_Data_Forwarding_Information_request(
            &pduSessToModifyItem->pDU_Session_Data_Forwarding_Information_Request, ptPduSessToBeModBuffer->qosToModList,
            ptCi, pPDUSessInfo, &numQoSFlow);

        if (numQoSFlow)
        {
            pduSessToModifyItem->bit_mask |=
                E1_PDU_Session_Resource_To_Modify_Item_pDU_Session_Data_Forwarding_Information_Request_present;
        }
    }

    // 6. O - PDU Session Data Forwarding Information (9_3_2_6)
    if (true == VEIL_check_E1_PDU_Data_Forwarding_Information(ptCi, pPDUSessInfo))
    {
        status = VEIL_fillE1_PDU_Data_Forwarding_Information(
            ptCi, pduSessToModifyItem, pPDUSessInfo, ptPduSessToBeModBuffer);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_PDU_Data_Forwarding_Information ERROR!\n");
    }

    // 7. O - PDU Session Inactivity Timer (9_3_1_54)
    if (true == VEIL_check_E1_Inactivity_Timer(ptCi, pPDUSessInfo))
    {
        status = VEIL_fillE1_Inactivity_Timer(ptCi, pPDUSessInfo, &pduSessToModifyItem->pDU_Session_Inactivity_Timer);
        if (status == GOOD)
        {
            pduSessToModifyItem->bit_mask |=
                E1_PDU_Session_Resource_To_Modify_Item_pDU_Session_Inactivity_Timer_present;
        }
    }

    // 8. O - Network Instance (9_3_1_66) : TBD

    // 9. O - DRB To Setup/Modify/Release List (bit mask is set at function)
    {
        status = VEIL_fillE1_PDUSessToModifyItem_Add_DRBToSetupModifyReleaseList(
            ptCi, pPDUSessInfo, pduSessToModifyItem, ptPduSessToBeModBuffer);
        VCCB_RETURN_ON_CALL_ERROR(
            ptCi, status, "VEIL_fillE1_PDUSessToModifyItem_Add_DRBToSetupModifyReleaseList ERROR!\n");
    }

    // 10. O - S-NSSAI (9_3_1_9)
    if ((ptCi->stateCmd == PDUModify_cmd) && (pPDUSessInfo->sNssai.fNeedModify == VCCB_FLAG_ON))
    {
        struct E1_ProtocolExtensionContainer_ *ptSNSSAI_Ext = &ptPduSessToBeModBuffer->sNSSAI_Ext;
        if (GOOD !=
            FnVCCB_fillE1_SNSSAI_ieExtensions(ptSNSSAI_Ext, &ptPduSessToBeModBuffer->sNSSAI, &pPDUSessInfo->sNssai))
        {
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_SNSSAI ERROR\n");
        }
        ptPduSessToBeModBuffer->pduSessToModData_Extensions[ieExtNum++] = *ptSNSSAI_Ext;
    }

    // 11. O - Redundant NG UL UP Transport Layer Information (9_3_2_1)
    // 12. O - Redundant common Network Instance (9_3_1_66)
    // 13. Data Forwarding to E-UTRAN Information List
    if (true == VEIL_check_Data_Forwarding_Eutran_Information_List(ptCi, pPDUSessInfo))
    {
        if (GOOD == FnVCCB_FillE1_DataForwardingToEUTRANInformationList(ptCi, pPDUSessInfo, *ptPduSessToBeModBuffer))
        {
            pduSessToModifyItem->bit_mask |= E1_PDU_Session_Resource_To_Modify_Item_iE_Extensions_present;
            struct E1_ProtocolExtensionContainer_ *ptDataForwarding_IE =
                &ptPduSessToBeModBuffer->dataForwardingtoEUTRANInformationListExt;

            InsertE1_ExtensionContainerValue(ptDataForwarding_IE, E1_id_DataForwardingtoE_UTRANInformationList,
                E1_ignore, &ptPduSessToBeModBuffer->pDataForwardingtoEUTRANInformationList,
                E1_DataForwardingtoE_UTRANInformationList_PDU);

            ptPduSessToBeModBuffer->pduSessToModData_Extensions[ieExtNum++] = *ptDataForwarding_IE;
        }
    }

    if (IS_LOG_TRAFFIC(ptCi))
    {
        if (pduSessToModifyItem->bit_mask & E1_PDU_Session_Resource_To_Modify_Item_pDU_Session_Data_Forwarding_Information_Request_present)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[TRAFFIC, FWD]: PDU Forwarding Information Request (PDU ID:%u)\n",
                pPDUSessInfo->pduSessId);
        }
    }

    if (ieExtNum > 0)
    {
        pduSessToModifyItem->bit_mask |= E1_PDU_Session_Resource_To_Modify_Item_iE_Extensions_present;
        status = GOOD;
        status = VCCB_ConnectLinkedList(ptPduSessToBeModBuffer->pduSessToModData_Extensions, ieExtNum);
        VCCB_RETURN_ON_CALL_ERROR(
            ptCi, status, "fnConnectLinkedList failed Data Forwarding to NG-RAN QoS Flow Information List!\n");
        pduSessToModifyItem->iE_Extensions = ptPduSessToBeModBuffer->pduSessToModData_Extensions;
    }

    if (pduSessToModifyItem->bit_mask == 0)
    {
        return BREAK;
    }

    return GOOD;
}

/**
 * @brief fill E1 PDU Session Resource To Remove Item
 * @attention function sets all bit_mask
 * @param [in]  rCall : callInfo_type DB
 * @param [in]  rPdu  : callPDUSessInfo DB
 * @param [out] rItem : E1_PDU_Session_Resource_To_Remove_Item buffer
 */
void VEIL_fillE1_PDUSessToRemoveItem(
    callInfo_type &rCall, callPDUSessInfo_type &rPdu, E1_PDU_Session_Resource_To_Remove_Item &rItem)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);

    rItem.bit_mask = 0;

    // PDU Sessioin ID Fill - mandatory
    rItem.pDU_Session_ID = rPdu.pduSessId;

    rPdu.isE1Setupped = false;

    // check if released PDU has configured VoMA
    for (uint8_t loop = 0; loop < MAX_DRB_PER_PDU_SESS; loop++)
    {
        if (rPdu.drbIndex[loop] >= MAX_DRB_PER_SA_CALL)
        {
            continue;
        }

        callDRBInfo_type *ptDi = &rCall.drb[rPdu.drbIndex[loop]];

        if ((CI_use == ptDi->usage) && (VOMA_STARTED == ptDi->vomaStatus.upStatus))
        {
            ptDi->vomaStatus.upStatus = VOMA_UNKNOWN;
            ptDi->vomaStatus.duStatus = VOMA_UNKNOWN;
            rCall.vomaInfo.vomaEvent = VOMA_drbRelease;
            break;
        }
    }

#ifdef IPC_TEST
    FnVCCB_CheckE1_PDUSessionResourceToRemoveItem(rCall, rPdu);
#endif
}

/**
 * @brief fill E1 PDU Session Resource Modified for Beaerer Context Modification Confirm
 * @attention function sets all bit_mask
 * @param [in]  ptBearerModConfirmBuffer        : E1_BearerContextModificationConfirmBuffer buffer
 * @param [in]  pPDUSessInfo                    : callPDUSessInfo DB
 * @param [in]  numPduSess                      : number of PDU Session Resource item
 * @param [out] pduSessModListItem              : E1_PDU_Session_Resource_Confirm_Modified_Item buffer
 * @return      GOOD                            : success fill
 * @return      ERROR                           : fill error
 */
int VEIL_fillE1_PDUSessModifiedItem(callInfo_type *ptCi,
    E1_PDU_Session_Resource_Confirm_Modified_Item *pduSessModListItem,
    E1_BearerContextModificationConfirmBuffer::PduSessModifiedConfirmData *ptPduSessModifiedConfirmBuffer,
    callPDUSessInfo_type *pPDUSessInfo)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pduSessModListItem);
    VALID_E_POINT_CHECK_ERROR(ptPduSessModifiedConfirmBuffer);
    VALID_E_POINT_CHECK_ERROR(pPDUSessInfo);

    callDRBInfo_type *ptDi = NULL;
    int status = GOOD;

    pduSessModListItem->bit_mask = 0;

    // PDU Session ID Fill - mandatory
    pduSessModListItem->pDU_Session_ID = pPDUSessInfo->pduSessId;

    // Fill DRB Modified List
    unsigned int numDrb = 0;
    for (uint8_t loop = 0; loop < MAX_DRB_PER_PDU_SESS; loop++)
    {
        if (pPDUSessInfo->drbIndex[loop] >= MAX_DRB_PER_SA_CALL)  // Not yet allocated
            continue;

        ptDi = &ptCi->drb[pPDUSessInfo->drbIndex[loop]];

        if ((CI_use != ptDi->usage) || (UlConfigBearer_ModOff == ptDi->ulPdcpPathToMod))
        {
            continue;
        }

        // DRB Modified Item Fill - mandatory
        status = VEIL_fillE1_DRBModifiedItem(&ptPduSessModifiedConfirmBuffer->drbModifiedList[numDrb].value,
            &ptPduSessModifiedConfirmBuffer->drbModifiedConfirmData[numDrb], ptCi, ptDi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_DRBModifiedItem ERROR!!\n");
        ++numDrb;
    }

    if (numDrb)
    {
        pduSessModListItem->bit_mask |= E1_dRB_Confirm_Modified_List_NG_RAN_present;
        pduSessModListItem->dRB_Confirm_Modified_List_NG_RAN = ptPduSessModifiedConfirmBuffer->drbModifiedList;
        if (ERROR == VCCB_ConnectLinkedList(pduSessModListItem->dRB_Confirm_Modified_List_NG_RAN, static_cast<int>(numDrb)))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_ConnectLinkedList failed in %s-> DRB Confirm Modified List!\n", __func__);
            return ERROR;
        }
    }

    return GOOD;
}

/**
 * @brief       Fill PDU Session Resource To Setup/Modify/Remove List
 * @details     fill all necessary fields and pack into ASN structure
 * @attention function sets all bit_mask
 * @param [in]  ptCi    : callInfo DB
 * @param [in]  ptBuf   : pointer of E1_BearerContextModificationRequestBuffer
 * @param [out] numPduSessAdd : number of PDU Session Resource ADD
 * @param [out] numPduSessMod : number of PDU Session Resource MOD
 * @param [out] numPduSessRem : number of PDU Session Resource REMOVE
 * @return      GOOD    : make BearerSetupRequest message
 * @return      ERROR   : can't make BearerSetupRequest message
 */
int VEIL_fillE1_BearerContextMod_PDUSessToBeList(callInfo_type *ptCi, E1_BearerContextModificationRequestBuffer *ptBuf,
    uint16_t srvUpIdx, uint32_t *ptNumPduSessAdd, uint32_t *ptNumPduSessMod, uint32_t *ptNumPduSessRem)
{
    if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ## %s\n", __func__);
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptBuf);
    VCCB_CHECK_E_RANGE_AND_RETURN(srvUpIdx, MAX_CU_UP_PER_CALL);
    VALID_E_POINT_CHECK_ERROR(ptNumPduSessAdd);
    VALID_E_POINT_CHECK_ERROR(ptNumPduSessMod);
    VALID_E_POINT_CHECK_ERROR(ptNumPduSessRem);

    int status, pduSessIdx = -1;
    uint32_t numPduSessAdd = 0, numPduSessMod = 0, numPduSessRem = 0;

    for (callPDUSessInfo_type &pduSess : ptCi->pduSess)
    {
        pduSessIdx++;

        if (CI_use != pduSess.usage || ptCi->endPointInfo.aupf[srvUpIdx].e1Idx != pduSess.e1Idx) continue;

        if (IS_NRDC_SN(ptCi) && (FALSE == FnVCCB_ExistSNTermBearerInPdu(ptCi, &pduSess))) continue;

        // Fill PDU Session Resource To Setup List if exists
        if (true == FnVCCB_is_E1_PDUSessToBeSetup(ptCi, &pduSess))
        {
            // skip it when all bearer type is SN terminated bearer
            if (IS_MRDC_MN(ptCi) && (false == FnVCCB_IsAnyMnTermPerPDU(ptCi, &pduSess, request_bearerType))) continue;

            // PDU Session Resource To Setup Item Fill - mandatory
            VCCB_RETURN_ON_CALL_ERROR(ptCi,
                VEIL_fillE1_PDUSessToSetupModItem(&ptBuf->pduSessToSetupList[numPduSessAdd].value,
                    &ptBuf->pduSessToSetupModData[numPduSessAdd], ptCi, &pduSess),
                "VEIL_fillE1_PDUSessToSetupModItem ERROR!\n");
            ++numPduSessAdd;

            ON_PDU_SESS_E1_SETUP_FLAG(pduSess.flag.respFlag);
            if (DBG->flag.logE1) VCCB_PRINT_CALL_DATA(ptCi, "[E1DBG] ON_PDU_SESS_E1_SETUP_FLAG %d\n", pduSess.pduSessId);
        }
        // Fill PDU Session Resource To Remove List if exists
        else if (true == FnVCCB_is_E1_PDUSessToBeRelease(ptCi, &pduSess))
        {
            if (IS_NRDC_SN(ptCi) && VCCB_IS_REMOVE_SKIP_STATE_IN_NRDC_SN(ptCi))
            {
                // Already sent PDU Release Information to UP on previous E1 Modification.
                continue;
            }

            VCCB_PRINT_CALL_DATA(ptCi, "VEIL_fillE1_PDUSessToRemoveItem()!\n");

            // PDU Session Resource To Remove Item Fill
            VEIL_fillE1_PDUSessToRemoveItem(*ptCi, pduSess, ptBuf->pduSessToRemoveList[numPduSessRem].value);
            ++numPduSessRem;
        }
        // Fill PDU Session Resource To Modify List if exists
        else if (pduSess.isE1Setupped &&
                ((S_Modify == pduSess.pduSessStatus) ||
                ((S_FailToModify == pduSess.pduSessStatus) && (S_Setup != pduSess.firstReqStatusInThisProcedure) && (pduSess.needToReconfigE1ByF1Fail)) ||
                (TRUE == VEIL_checkE1_NeedToBearerModifiedItem(ptCi, pduSess.pduSessStatus)) ||
                (TRUE == VEIL_checkE1_NeedToBearerModifiedItemForMRDC(ptCi, (void *)&pduSess, false)) ||
                (TRUE == FnVCCB_CheckE1_NeedToBearerModifiedItemForNRDC_SN(ptCi, (void *)&pduSess, false)) ||
                NEED_DlTrfStatusRptCfg_TO_BE_REFRESHED_PER_PDUSESS(ptCi, pduSessIdx)))
        {
            // PDU Session Resource To Modify Item Fill - mandatory
            status = VEIL_fillE1_PDUSessToModifyItem_Add(&ptBuf->pduSessToModifyList[numPduSessMod].value,
                &ptBuf->pduSessToModData[numPduSessMod], ptCi, &pduSess);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_PDUSessToModifyItem_Add ERROR!\n");

            if (status == BREAK)
            {
                continue;
            }
            ++numPduSessMod;
            ON_PDU_SESS_E1_MODIFY_FLAG(pduSess.flag.respFlag);
            if (DBG->flag.logE1) VCCB_PRINT_DATA("[E1DBG] ON_PDU_SESS_E1_MODIFY_FLAG\n");
        }
    }

    *ptNumPduSessAdd = numPduSessAdd;
    *ptNumPduSessMod = numPduSessMod;
    *ptNumPduSessRem = numPduSessRem;

    return GOOD;
}

uint8_t FnVCCB_Get_UserInactivity_PerCellProfileIdx(const callInfo_type &rCi, const VccbGnbInfo_type &rGnb)
{
    AUTO_TRACE_FUNC;

    if (rGnb.UserInactivity.perCellOnOff)
    {
        const uint16_t cellNum = (IntraRatHO_cmd == rCi.stateCmd && HO_TYPE_INTRA_NB == rCi.hoInfo.hoType.nb &&
                                  ((STATE_DCIntraDuHo_RRCRecCmpl == rCi.state) || (STATE_DCIntraDuHo_X2RecCmpl == rCi.state) ||
                                   (STATE_DCIntraDuHo_X2SnStatus == rCi.state) || (STATE_DCIntraDuHo_X2ModCnf == rCi.state) ||
                                   (STATE_DCInterDuHo_RRCRecCmpl == rCi.state) || (STATE_DCInterDuHo_X2RecCmpl == rCi.state) ||
                                   (STATE_DCInterDuHo_X2SnStatus == rCi.state) || (STATE_DCInterDuHo_X2ModCnf == rCi.state) ||
                                   (STATE_DCNonDuHo_X2SnStatus == rCi.state) || (STATE_DCNonDuHo_X2RecCmpl == rCi.state)))
            ? rCi.hoInfo.targetCellNum : rCi.servCellNum;

        VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, VCCB_MAX_USER_INACT_ENDC_PROFILES);
        const uint8_t profileIdx = CELLINFO[cellNum].profileDBInfo.endcInactivityTimerPerCellProfileIdx;

        if (profileIdx < VCCB_MAX_USER_INACT_ENDC_PROFILES &&
            rGnb.UserInactivity.inactivityDataProfileEntries[profileIdx].status != N_EQUIP)
        {
            return profileIdx;
        }
    }

    return VCCB_MAX_USER_INACT_ENDC_PROFILES;
}

bool FnVCCB_GetDataInactTime_UeLevel_PerCell(callInfo_type *ptCi, uint16_t *pFindVal)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pFindVal, false);

    uint16_t rfspIndex = 0;
    saDataInactProfile_type *pDataProfile = NULL;

    if (IS_NRDC_SN(ptCi)) return false;

    /* Get Profile and Check Usage */
    pDataProfile = FnVCCB_SA_GetProfileAddrForDataInactInE1Proc(ptCi);
    if (pDataProfile == NULL) return false;
    if (pDataProfile->usage != CI_use) return false;

    /* Find Cell Based Value */
    if (ptCi->CallUserInactivity.rfspBasedControlFlag == VCCB_FLAG_ON)
    {
        for (rfspIndex = 0; rfspIndex < VCCB_MAX_USER_INACT_RFSP_LIST; rfspIndex++)
        {
            if ((pDataProfile->rfspList[rfspIndex].usage == CI_use) &&
                (pDataProfile->rfspList[rfspIndex].rfsp  == ptCi->CallUserInactivity.rfspVal))
            {
                *pFindVal = pDataProfile->rfspList[rfspIndex].ueInactivityTimer;
                return true;
            }
        }
        // If not found, keep going with Non RFSP Value.
    }

    *pFindVal = pDataProfile->ueInactivityTimer;
    return true;
}

bool FnVCCB_GetDataInactTime_UeLevel_PerGnb(callInfo_type *ptCi, uint16_t *pFindVal)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pFindVal, false);

    uint16_t gnbNum = ptCi->gnbNum;
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(gnbNum, false);
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    rfspBasedUserInactivityControl_type *pRfspDB = NULL;

    if (IS_NRDC_SN(ptCi))
    {
        pRfspDB = &pGnb->UserInactivityNrdcSN.rfspControlInfo;
    }
    else
    {
        SET_REDCAP_OR_NORM_VAL(
            ptCi, pRfspDB, &pGnb->UserInactivitySA.redCap.rfspControlInfo, &pGnb->UserInactivitySA.rfspControlInfo);
    }

    /* Find gNB Based Value */
    if (ptCi->CallUserInactivity.rfspBasedControlFlag == VCCB_FLAG_ON)
    {
        // For updating latest timer value
        for (uint16_t rfspIndex = 0; rfspIndex < VCCB_MAX_USER_INACT_RFSP_LIST; rfspIndex++)
        {
            if ((pRfspDB->rfspList[rfspIndex].usage == CI_use) &&
                (pRfspDB->rfspList[rfspIndex].rfsp == ptCi->CallUserInactivity.rfspVal))
            {
                // Update or Overwrite Value.
                *pFindVal = pRfspDB->rfspList[rfspIndex].ueInactivityTimer;
                return true;
            }
        }
        // If not found, keep going with Non RFSP Value.
    }

    if (IS_NRDC_SN(ptCi))
    {
        *pFindVal = pGnb->UserInactivityNrdcSN.ueInactivityTimer;
    }
    else
    {
        SET_REDCAP_OR_NORM_VAL(
            ptCi, *pFindVal, pGnb->UserInactivitySA.redCap.ueInactivityTimer, pGnb->UserInactivitySA.ueInactivityTimer);
    }

    return true;
}

int FnVCCB_FillUeInactivityTimerValue(callInfo_type *ptCi, E1_Inactivity_Timer *pTimer)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pTimer);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        const uint16_t spId = ptCi->ueInfo.rfsp.subscriberProfile;
        const VccbGnbInfo_type &rGnb = GNBINFO[ptCi->gnbNum];
        const uint8_t profileIdx = FnVCCB_Get_UserInactivity_PerCellProfileIdx(*ptCi, rGnb);

        if (ptCi->bitFlag.stopUserInactivityByScgSuspend == TRUE)
        {
            *pTimer = 0;
        }
        else if (profileIdx < VCCB_MAX_USER_INACT_ENDC_PROFILES)
        {
            if (spId != 0xFFFF && spId <= MAX_SPID_VALUE && rGnb.UserInactivity.spidBasedUserInactivity &&
                rGnb.UserInactivity.inactivityDataProfileEntries[profileIdx].
                    spidBasedUserInactivityEntries[spId].status != N_EQUIP)
            {
                *pTimer = rGnb.UserInactivity.inactivityDataProfileEntries[profileIdx].
                    spidBasedUserInactivityEntries[spId].ueInactivityTimer;
            }
            else
            {
                *pTimer = rGnb.UserInactivity.inactivityDataProfileEntries[profileIdx].ueInactivityTimer;
            }
        }
        else if (spId != 0xFFFF && spId <= MAX_SPID_VALUE && rGnb.UserInactivity.spidBasedUserInactivity &&
                 rGnb.UserInactivity.spidBasedUserInactivityEntries[spId].status != N_EQUIP)
        {
            *pTimer = rGnb.UserInactivity.spidBasedUserInactivityEntries[spId].ueInactivityTimer;
        }
        else
        {
            *pTimer = rGnb.UserInactivity.ueInactivityTimer;
        }
    }
    else  // SA CALL
    {
        uint16_t findVal = 0;
        bool status = false;

        // Find Value with Cell
        if ((!IS_NRDC_SN(ptCi)) && (ptCi->CallUserInactivity.dataInactivityPerCellOnOff))
        {
            // Refer Cell Profile DB
            status = FnVCCB_GetDataInactTime_UeLevel_PerCell(ptCi, &findVal);
            if (status == true)
            {
                *pTimer = findVal;
                return GOOD;
            }
            // If cell profile is not exist, VCCB will use gNB DB.
        }

        // Find Value with GNB
        status = FnVCCB_GetDataInactTime_UeLevel_PerGnb(ptCi, &findVal);
        if (status == true)
        {
            *pTimer = findVal;
        }
        else // No Case
        {
            SET_REDCAP_OR_NORM_VAL(ptCi, *pTimer, GNBINFO[ptCi->gnbNum].UserInactivitySA.redCap.ueInactivityTimer,
                GNBINFO[ptCi->gnbNum].UserInactivitySA.ueInactivityTimer);
        }
    }

    return GOOD;
}

// 22B_UserInactivity_FR214 Start
int FnVCCB_FillNsaDrbInactivityTimerValue(
    callInfo_type *ptCi, E1_Inactivity_Timer *pTimer, callERABInfo_type *pERABInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pTimer);
    VALID_E_POINT_CHECK_ERROR(pERABInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    if (activityNotifLvl_DRB == FnVCCB_Get_UserInactivity_NotiLevel(ptCi))
    {
        constexpr uint16_t DRB_TIMER_NOT_DEFINED = 0;
        const uint16_t spId = ptCi->ueInfo.rfsp.subscriberProfile;
        const uint16_t qci = pERABInfo->erabQos.qciValue.QCI;
        const uint16_t arp = pERABInfo->erabQos.aRP.priority;
        const VccbGnbInfo_type &rGnb = GNBINFO[ptCi->gnbNum];
        const uint8_t profileIdx = FnVCCB_Get_UserInactivity_PerCellProfileIdx(*ptCi, rGnb);

        if (ptCi->bitFlag.stopUserInactivityByScgSuspend == TRUE)
        {
            *pTimer = 0;
        }
        else if (profileIdx < VCCB_MAX_USER_INACT_ENDC_PROFILES)
        {
            if (spId != 0xFFFF && spId <= MAX_SPID_VALUE && rGnb.UserInactivity.spidBasedUserInactivity &&
                rGnb.UserInactivity.inactivityDataProfileEntries[profileIdx].
                    spidBasedUserInactivityEntries[spId].status != N_EQUIP)
            {
                if (qci < MAX_QCI_VALUE &&
                    DRB_TIMER_NOT_DEFINED != rGnb.UserInactivity.inactivityDataProfileEntries[profileIdx].
                        spidBasedUserInactivityEntries[spId].drbInactivityTimerEntries[qci])
                {
                    *pTimer = rGnb.UserInactivity.inactivityDataProfileEntries[profileIdx].
                        spidBasedUserInactivityEntries[spId].drbInactivityTimerEntries[qci];
                }
                else
                {
                    *pTimer = rGnb.UserInactivity.inactivityDataProfileEntries[profileIdx].
                        spidBasedUserInactivityEntries[spId].ueInactivityTimer;
                }
            }
            else if (qci < MAX_QCI_VALUE &&
                     DRB_TIMER_NOT_DEFINED != rGnb.UserInactivity.inactivityDataProfileEntries[profileIdx].
                         drbInactivityTimerEntries[qci])
            {
                *pTimer = rGnb.UserInactivity.inactivityDataProfileEntries[profileIdx].drbInactivityTimerEntries[qci];
            }
            else
            {
                *pTimer = rGnb.UserInactivity.inactivityDataProfileEntries[profileIdx].ueInactivityTimer;
            }
        }
        else if (spId != 0xFFFF && spId <= MAX_SPID_VALUE && rGnb.UserInactivity.spidBasedUserInactivity &&
                 rGnb.UserInactivity.spidBasedUserInactivityEntries[spId].status != N_EQUIP)
        {
            if (TRUE == FOO.VF_UserInactivity_DrbLevelArp2Based && ARP_FOR_UIT == arp && qci < MAX_QCI_VALUE &&
                DRB_TIMER_NOT_DEFINED != rGnb.UserInactivity.spidBasedUserInactivityEntries[spId].
                    drbInactivityTimerEntries[QCI_FOR_UIT_ARP2])
            {
                *pTimer = rGnb.UserInactivity.spidBasedUserInactivityEntries[spId].drbInactivityTimerEntries[QCI_FOR_UIT_ARP2];
            }
            else if (qci < MAX_QCI_VALUE &&
                     DRB_TIMER_NOT_DEFINED != rGnb.UserInactivity.spidBasedUserInactivityEntries[spId].
                         drbInactivityTimerEntries[qci])
            {
                *pTimer = rGnb.UserInactivity.spidBasedUserInactivityEntries[spId].drbInactivityTimerEntries[qci];
            }
            else
            {
                *pTimer = rGnb.UserInactivity.spidBasedUserInactivityEntries[spId].ueInactivityTimer;
            }
        }
        else
        {
            if (TRUE == FOO.VF_UserInactivity_DrbLevelArp2Based && ARP_FOR_UIT == arp && qci < MAX_QCI_VALUE &&
                DRB_TIMER_NOT_DEFINED != rGnb.UserInactivity.drbInactivityTimerEntries[QCI_FOR_UIT_ARP2])
            {
                *pTimer = rGnb.UserInactivity.drbInactivityTimerEntries[QCI_FOR_UIT_ARP2];
            }
            else if (qci < MAX_QCI_VALUE && DRB_TIMER_NOT_DEFINED != rGnb.UserInactivity.drbInactivityTimerEntries[qci])
            {
                *pTimer = rGnb.UserInactivity.drbInactivityTimerEntries[qci];
            }
            else
            {
                *pTimer = rGnb.UserInactivity.ueInactivityTimer;
            }
        }
        return GOOD;
    }

    return BREAK;
}
// 22B_UserInactivity_FR214 End

/**
 * @brief fills E1 linksToLog basing on enumMdtTraceDir_type
 *
 * @param [in] traceDir     :
 * @param [out] linksToLog :
 * @return GOOD     :
 * @return ERROR    :
 */
int16_t VEIL_fill_E1_Links_to_log(enumMdtTraceDir_type traceDir, E1_Links_to_log &linksToLog)
{
    int16_t status = GOOD;
    switch (traceDir)
    {
        case mdt_trace_uplink:
            linksToLog = E1_Links_to_log_uplink;
            break;
        case mdt_trace_downlink:
            linksToLog = E1_Links_to_log_downlink;
            break;
        case mdt_trace_both:
            linksToLog = E1_both_uplink_and_downlink;
            break;
        default:
            status = ERROR;
            break;
    }

    return status;
}

/**
 * @brief fills m4Period basing on enumMdtTraceCollectPeriod
 *
 * @param [in] tracePeriod     :
 * @param [out] m4Period :
 * @return GOOD     :
 * @return ERROR    :
 */
int16_t VEIL_fill_E1_M4period(enumMdtTraceCollectPeriod tracePeriod, E1_M4period &m4Period)
{
    int16_t status = GOOD;
    switch (tracePeriod)
    {
        case mdt_period_ms1024:
            m4Period = E1_M4period_ms1024;
            break;
        case mdt_period_ms2048:
            m4Period = E1_M4period_ms2048;
            break;
        case mdt_period_ms5120:
            m4Period = E1_M4period_ms5120;
            break;
        case mdt_period_ms10240:
            m4Period = E1_M4period_ms10240;
            break;
        case mdt_period_min1:
            m4Period = E1_M4period_min1;
            break;
        default:
            status = ERROR;
            break;
    }
    return status;
}

/**
 * @brief fills m6ReportInterval basing on enumMdtTraceCollectPeriod
 *
 * @param [in] tracePeriod     :
 * @param [out] m6ReportInterval :
 * @return GOOD     :
 * @return ERROR    :
 */
int16_t VEIL_fill_E1_M6report_Interval(enumMdtTraceReportInterval tracePeriod, E1_M6report_Interval &m6ReportInterval)
{
    int16_t status = GOOD;
    switch (tracePeriod)
    {
        case mdt_reportInterval_ms120:
            m6ReportInterval = E1_M6report_Interval_ms120;
            break;
        case mdt_reportInterval_ms240:
            m6ReportInterval = E1_M6report_Interval_ms240;
            break;
        case mdt_reportInterval_ms480:
            m6ReportInterval = E1_ms480;
            break;
        case mdt_reportInterval_ms640:
            m6ReportInterval = E1_ms640;
            break;
        case mdt_reportInterval_ms1024:
            m6ReportInterval = E1_M6report_Interval_ms1024;
            break;
        case mdt_reportInterval_ms2048:
            m6ReportInterval = E1_M6report_Interval_ms2048;
            break;
        case mdt_reportInterval_ms5120:
            m6ReportInterval = E1_M6report_Interval_ms5120;
            break;
        case mdt_reportInterval_ms10240:
            m6ReportInterval = E1_M6report_Interval_ms10240;
            break;
        case mdt_reportInterval_ms20480:
            m6ReportInterval = E1_ms20480;
            break;
        case mdt_reportInterval_ms40960:
            m6ReportInterval = E1_ms40960;
            break;
        case mdt_reportInterval_min1:
            m6ReportInterval = E1_M6report_Interval_min1;
            break;
        case mdt_reportInterval_min6:
            m6ReportInterval = E1_min6;
            break;
        case mdt_reportInterval_min12:
            m6ReportInterval = E1_min12;
            break;
        case mdt_reportInterval_min30:
            m6ReportInterval = E1_min30;
            break;
        default:
            status = ERROR;
            break;
    }

    return status;
}

static int16_t fillMgtTraceActivationExt(callInfo_type* ptCi, E1_TraceActivationData* traceActivationData, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    int16_t status;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(traceActivationData);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type* const pCell = &CELLINFO[cellNum];
    ManagementTraceSessionPerCell_type* pSession = &pCell->traceSession;

    struct callInfo_type::Trace_s::TraceRecordingSession_s *pRecordingSession = getTraceSession(ptCi, cellNum, false);

    if (nullptr == pRecordingSession)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, trace_ctt, "Cannot get session for cellNum(%u)\n", cellNum);
        return ERROR;
    }

    if (VCCB_FLAG_ON == pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag)
    {
        traceActivationData->mdtConfiguration.mdt_Activation = E1_immediate_MDT_and_Trace;
    }
    else
    {
        traceActivationData->mdtConfiguration.mdt_Activation = E1_immediate_MDT_only;
    }

    // M4
    if (TRUE == pSession->mdt.mdtSessionConfiguration.immediate.measurements.m4.activation)
    {
        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.bit_mask |= E1_measurementFour_present;
        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementFour.bit_mask = 0;
        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementFour.iE_Extensions = NULL;
        traceActivationData->measurementsToActivate[MDT_MEASUREMENTS_TO_ACTIVATE_BYTE] |=
            MDT_MEASUREMENTS_TO_ACTIVATE_M4;

        status = VEIL_fill_E1_M4period(
            (enumMdtTraceCollectPeriod)pSession->mdt.mdtSessionConfiguration.immediate.measurements.m4.collectionPeriod,
            traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementFour.m4period);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fill_E1_M4period ERROR!\n");

        status = VEIL_fill_E1_Links_to_log(
            (enumMdtTraceDir_type)pSession->mdt.mdtSessionConfiguration.immediate.measurements.m4.linksToLog,
            traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementFour.m4_links_to_log);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "M4 VEIL_fill_E1_Links_to_log ERROR!\n");
    }

    // M6
    if (TRUE == pSession->mdt.mdtSessionConfiguration.immediate.measurements.m6.activation)
    {
        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.bit_mask |= E1_measurementSix_present;
        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementSix.bit_mask = 0;
        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementSix.iE_Extensions = NULL;
        traceActivationData->measurementsToActivate[MDT_MEASUREMENTS_TO_ACTIVATE_BYTE] |=
            MDT_MEASUREMENTS_TO_ACTIVATE_M6;

        status = VEIL_fill_E1_M6report_Interval(
            (enumMdtTraceReportInterval)pSession->mdt.mdtSessionConfiguration.immediate.measurements.m6.collectionPeriod,
            traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementSix.m6report_Interval);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fill_E1_M6report_Interval ERROR!\n");

        status = VEIL_fill_E1_Links_to_log(
            (enumMdtTraceDir_type)pSession->mdt.mdtSessionConfiguration.immediate.measurements.m6.linksToLog,
            traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementSix.m6_links_to_log);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "M6 VEIL_fill_E1_Links_to_log ERROR!\n");
    }

    // M7
    if (TRUE == pSession->mdt.mdtSessionConfiguration.immediate.measurements.m7.activation &&
        mdt_trace_downlink != pSession->mdt.mdtSessionConfiguration.immediate.measurements.m7.linksToLog)
    {
        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.bit_mask |= E1_measurementSeven_present;
        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementSeven.bit_mask = 0;
        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementSeven.iE_Extensions = NULL;
        traceActivationData->measurementsToActivate[MDT_MEASUREMENTS_TO_ACTIVATE_BYTE] |=
            MDT_MEASUREMENTS_TO_ACTIVATE_M7;

        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementSeven.m7period =
            pSession->mdt.mdtSessionConfiguration.immediate.measurements.m7.collectionPeriod;

        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementSeven.m7_links_to_log = E1_Links_to_log_uplink;
    }
    return GOOD;
}

static int16_t fillSigTraceActivationExt(callInfo_type* ptCi, E1_TraceActivationData* traceActivationData)
{
    AUTO_TRACE_FUNC;

    int16_t status;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(traceActivationData);

    struct SignalingTrace_type::mdt_s::mdt_u::immediate_s *immediate = &ptCi->signalingTraceInfo.mdt.config.immediate;

    if (VCCB_FLAG_ON == ptCi->signalingTraceInfo.trace.ueThroughputAndRfTraceFlag)
    {
        traceActivationData->mdtConfiguration.mdt_Activation = E1_immediate_MDT_and_Trace;
    }
    else
    {
        traceActivationData->mdtConfiguration.mdt_Activation = E1_immediate_MDT_only;
    }

    // M4
    if (TRUE == immediate->measConfigFlags.m4Flag)
    {
        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.bit_mask |= E1_measurementFour_present;
        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementFour.bit_mask = 0;
        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementFour.iE_Extensions = NULL;
        traceActivationData->measurementsToActivate[MDT_MEASUREMENTS_TO_ACTIVATE_BYTE] |=
            MDT_MEASUREMENTS_TO_ACTIVATE_M4;

        status = VEIL_fill_E1_M4period(immediate->m4Config.period,
            traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementFour.m4period);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fill_E1_M4period ERROR!\n");

        status = VEIL_fill_E1_Links_to_log(immediate->m4Config.linksToLog,
            traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementFour.m4_links_to_log);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "M4 VEIL_fill_E1_Links_to_log ERROR!\n");
    }

    // M6
    if (TRUE == immediate->measConfigFlags.m6Flag)
    {
        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.bit_mask |= E1_measurementSix_present;
        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementSix.bit_mask = 0;
        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementSix.iE_Extensions = NULL;
        traceActivationData->measurementsToActivate[MDT_MEASUREMENTS_TO_ACTIVATE_BYTE] |=
            MDT_MEASUREMENTS_TO_ACTIVATE_M6;

        status = VEIL_fill_E1_M6report_Interval(immediate->m6Config.reportInterval,
            traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementSix.m6report_Interval);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fill_E1_M6report_Interval ERROR!\n");

        status = VEIL_fill_E1_Links_to_log(immediate->m6Config.linksToLog,
            traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementSix.m6_links_to_log);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "M6 VEIL_fill_E1_Links_to_log ERROR!\n");
    }

    // M7
    if (TRUE == immediate->measConfigFlags.m7Flag &&
        mdt_trace_downlink != immediate->m7Config.linksToLog)
    {
        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.bit_mask |= E1_measurementSeven_present;
        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementSeven.bit_mask = 0;
        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementSeven.iE_Extensions = NULL;
        traceActivationData->measurementsToActivate[MDT_MEASUREMENTS_TO_ACTIVATE_BYTE] |=
            MDT_MEASUREMENTS_TO_ACTIVATE_M7;

        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementSeven.m7period =
            immediate->m7Config.period;

        traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementSeven.m7_links_to_log = E1_Links_to_log_uplink;
    }
    return GOOD;
}

int16_t VEIL_fillE1_TraceActivation_MdtConfiguration_Extension(callInfo_type *ptCi, E1_TraceActivationData *traceActivationData,
     uint16_t cellNum, int16_t& ieExtNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(traceActivationData);

    traceActivationData->mdtConfiguration.bit_mask = 0;
    traceActivationData->mdtConfiguration.mDTMode.choice = E1_immediateMDT_chosen;

    traceActivationData->measurementsToActivate[MDT_MEASUREMENTS_TO_ACTIVATE_BYTE] = 0;
    traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.bit_mask = 0;
    traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.iE_Extensions = NULL;
    traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementsToActivate.length = 8;  // Significant Bits
    traceActivationData->mdtConfiguration.mDTMode.u.immediateMDT.measurementsToActivate.value =
        traceActivationData->measurementsToActivate;


    if (Trace_Management == ptCi->traceType)
    {
        if (GOOD != fillMgtTraceActivationExt(ptCi, traceActivationData, cellNum))
        {
            return ERROR;
        }
    }
    else
    {
        if (GOOD != fillSigTraceActivationExt(ptCi, traceActivationData))
        {
            return ERROR;
        }
    }

    // 1. MDTConfiguration - Optional
    InsertE1_ExtensionContainerValue(&(traceActivationData->traceActivation_Extensions[ieExtNum++]),
        E1_id_MDTConfiguration, E1_ignore, &traceActivationData->mdtConfiguration, E1_MDT_Configuration_PDU);

    return GOOD;
}


int16_t VEIL_fillE1_TraceActivation_Uri_Extension(callInfo_type *ptCi, E1_TraceActivationData& traceActivationData,
        const char* uri, int16_t& ieExtNum)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(uri);

    auto uriLen = strlen(uri);

    if (uriLen < MAX_TCE_URI_LEN)
    {
        memcpy(traceActivationData.uRI_address, uri, uriLen);
        traceActivationData.uRI_address[uriLen] = '\0';
    }
    else
    {
        VCCB_PRINT_ERROR("%s: uri too long: ERROR for F1_ProtocolExtensionContainer!\n", __FUNCTION__);
        return ERROR;
    }

    traceActivationData.pt_uRI_address = static_cast<char*>(&(traceActivationData.uRI_address[0]));

    // 1. Uri  - Optional
    InsertE1_ExtensionContainerValue(&(traceActivationData.traceActivation_Extensions[ieExtNum]),
        E1_id_TraceCollectionEntityURI, E1_ignore, &traceActivationData.pt_uRI_address, E1_URIaddress_PDU);

    ieExtNum++;

    return GOOD;
}

int16_t VEIL_fillE1_TraceActivation(
    callInfo_type *ptCi, E1_TraceActivationData *traceActivationData, E1_TraceActivation *traceActivation, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    int16_t status;
    int16_t ieExtNum = 0;
    TceAddress_type *pTceAddr = nullptr;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(traceActivationData);
    VALID_E_POINT_CHECK_ERROR(traceActivation);
    // cellNum used only by Management, no range check needed
        
    traceActivation->bit_mask = 0;
    traceActivation->iE_Extensions = NULL;
    
    // 1. TraceID
    status = FillTraceID(ptCi, &traceActivation->traceID, cellNum, NULL);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FillTraceID for E1 ERROR!\n");

    // 2. InterfacesToTrace
    traceActivationData->interfacesToTraceBuffer[0] = 0;
    traceActivation->interfacesToTrace.length = 8;  // Significant Bits
    traceActivation->interfacesToTrace.value = traceActivationData->interfacesToTraceBuffer;

    // FGR-SO1101 NR Minimization of Drive Tests (NR MDT)
    // FGR-TA0104 UE Throughput and RF Trace
    if (Trace_Management == ptCi->traceType)
    {
        VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
        VccbCellInfo_type *pCell = &CELLINFO[cellNum];
        ManagementTraceSessionPerCell_type *pTraceSession = &pCell->traceSession;

        // 3.  Trace Depth
        // if only MDT use MDT IP and E1_maximumWithoutVendorSpecificExtension
        struct callInfo_type::Trace_s::TraceRecordingSession_s *pRecordingSession = getTraceSession(ptCi, cellNum, false);

        if (nullptr == pRecordingSession)
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, trace_ctt, "Cannot get session for cellNum(%u)\n", cellNum);
            return ERROR;
        }

        if (VCCB_FLAG_ON == pRecordingSession->jobStatus.immediateMdtFlag)
        {
            traceActivation->traceDepth = E1_maximumWithoutVendorSpecificExtension;
            pTceAddr = &pTraceSession->mdt.mdtSessionConfiguration.tceAddress;

            status = VEIL_fillE1_TraceActivation_MdtConfiguration_Extension(ptCi, traceActivationData, cellNum, ieExtNum);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_TraceActivation_MdtConfiguration_Extension ERROR!\n");
        }
        
        // if both MDT and UEThr active or only UEThr, use Trace TCE_IP1 and E1_maximum
        if (VCCB_FLAG_ON == pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag)
        {
            traceActivation->traceDepth = E1_maximum;
            pTceAddr = &pTraceSession->trace.tce1Address;
        }
    }
    else
    {
        // 3.  Trace Depth
        traceActivation->traceDepth = static_cast<E1_TraceDepth>(ptCi->signalingTraceInfo.trace.traceDepth);

        if (mdtImmediate == ptCi->signalingTraceInfo.mdt.mdtStatus)
        {
            // Extensions - only if MDT activated
            status = VEIL_fillE1_TraceActivation_MdtConfiguration_Extension(ptCi, traceActivationData, MAX_CELL_NUM_VCCB, ieExtNum);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_TraceActivation_MdtConfiguration_Extension ERROR!\n");
        }

        // Signaling will always have the IP configured in the predefined tce list.
        auto tceId = ptCi->signalingTraceInfo.tceId;
        if (tceId >= TCE_MAX_NUMBER)
        {
            VCCB_PRINT_TRACE_INFORMATIVE(ptCi, mdt_trace_all, "MDT TCE ip/fqdn not configured\n");
            return BREAK;
        }
        pTceAddr = &CFG->globalTraceInfo.predefinedTceServers[tceId].server;
        ptCi->signalingTraceInfo.traceActivationStatus.E1delivered = true;
    }

    traceActivation->traceCollectionEntityIPAddress.value = traceActivationData->tceIpAddressBuffer;
    //the traceCollectionEntityIPAddress is a BIT STRING (SIZE(1..160))
    traceActivation->traceCollectionEntityIPAddress.value[0] = 0;
    traceActivation->traceCollectionEntityIPAddress.length = 1;

    if (pTceAddr == NULL)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_trace_all, "pTceAddr is NULL!\n");
        return BREAK;
    }

    if (pTceAddr->ip.MdsIp.IpVer == MDS_IPV4 || pTceAddr->ip.MdsIp.IpVer == MDS_IPV6)
    {   
        // 4. TraceCollectionEntityIPAddress
        traceActivation->traceCollectionEntityIPAddress.value = traceActivationData->tceIpAddressBuffer;
        status = FillTransportLayerAddress(&traceActivation->traceCollectionEntityIPAddress, &pTceAddr->ip.MdsIp);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FillTransportLayerAddress ERROR!\n");
    }
    else if (pTceAddr->ip.MdsIp.IpVer == TCE_FQDN)
    {
        MdsIp_Type tceIpFromFqdn;
        status = VLIB_getTceIpFromFqdn(pTceAddr->fqdn, &tceIpFromFqdn);

        if (status == GOOD)
        {
            // 4. TransportLayerAddress
            // To keep backward compatibility
            status = FillTransportLayerAddress(&traceActivation->traceCollectionEntityIPAddress, &tceIpFromFqdn);
            VCCB_PRINT_WITHOUT_RETURN_ON_CALL_ERROR(ptCi, status, "ERROR FillTransportLayerAddress!\n");
        }
        else
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, mdt_trace_all, "[TRACE/MDT][SIG] IP from DNS is missing! fqdn [%s]\n", pTceAddr->fqdn);
        }

        // 5. TransportLayerAddress
        status = VEIL_fillE1_TraceActivation_Uri_Extension(ptCi, *traceActivationData, pTceAddr->fqdn, ieExtNum);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_TraceActivation_Uri_Extension ERROR!\n");
    }
    else
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, "[TRACE/MDT][SIG]", "Wrong TCE configuration ERROR!");
        return ERROR;
    }

    if (ieExtNum > 0)
    {
        status = VCCB_ConnectLinkedList(traceActivationData->traceActivation_Extensions, static_cast<int>(ieExtNum));
        VCCB_RETURN_ON_CALL_ERROR(
            ptCi, status, "VCCB_ConnectLinkedList failed in VEIL_fillE1_TraceActivation_Extensions msg!!\n");

        //  update the pointer value
        traceActivation->iE_Extensions = traceActivationData->traceActivation_Extensions;
    }

    // 6. Extensions
    // Signaling MDT not supported in SVR23A
    if (NULL != traceActivation->iE_Extensions)
    {
        traceActivation->bit_mask |= E1_TraceActivation_iE_Extensions_present;
    }

    return GOOD;
}

/**
 * @brief Fill Samsung specific IE
 *        TYPE Samsung-GlobalgNB-ID
 */
int16_t VEIL_fillE1_Samsung_GlobalgNB_ID(callInfo_type *ptCi, E1_Samsung_GlobalgNB_ID *pGnb,
    E1_SamsungNeCgInfoData::E1_SamsungNeCgInfoBuffer *pNeCgInfoBuffer)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pGnb);
    VALID_E_POINT_CHECK_ERROR(pNeCgInfoBuffer)
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    vccbGlobalGnbId_type *pGlobalGnbId = &GNBINFO[ptCi->gnbNum].globalGnbId;

    pGnb->bit_mask = 0;
    pGnb->iE_Extensions = NULL;

    // E1_PLMN_Identity plmn_id;
    int32_t status = VEIL_fillE1_PLMN_Identity(&pGnb->plmn_id, pGlobalGnbId->plmn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_PLMN_Identity ERROR!\n");

    // E1_Samsung_GNB_ID_Choice gnb_id
    pGnb->gnb_id.choice = E1_gnb_ID_chosen;
    pGnb->gnb_id.u.gnb_ID.value = &pNeCgInfoBuffer->gnbId[0];

    VCCB_CHECK_E_RANGE_AND_RETURN(pGlobalGnbId->gnbId.idLength, 33); // BIT STRING (SIZE(22..32))
    status = FillE1_BitString(&pGnb->gnb_id.u.gnb_ID, pGlobalGnbId->gnbId.id, pGlobalGnbId->gnbId.idLength);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FillE1_BitString ERROR!\n");

    return GOOD;
}

/**
 * @brief Check if there is at least one bearer utilizing cell on this gNB
 */
bool CheckSpCellExistence(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (E_CALLTYPE_SA == ptCi->callType)
    {
        if (IS_NRDC_SN(ptCi))
        {
            for (const callDRBInfo_type &drb : ptCi->drb)
            {
                if (CI_use != drb.usage)
                {
                    continue;
                }

                if (drb.bearerType.val == SN_Term_SCG_Bearer || drb.bearerType.val == SN_Term_SPLIT_Bearer)
                {
                    return true;
                }
            }
        }
        else
        {
            return true;
        }
    }
    else  // NSA
    {
        for (const callERABInfo_type &erab : ptCi->erabInfo)
        {
            if (CI_use != erab.usage)
            {
                continue;
            }
            if (erab.bearerType == SCG_Bearer || erab.bearerType == SPLIT_Bearer)
            {
                return true;
            }
        }
    }

    return false;
}

/**
 * @brief Fill Samsung specific IE
 *        TYPE Samsung-GlobalNG-RANCell-ID
 * @param [in]  ptCi            : callInfo DB
 * @param [out] pSpCell_ID      : E1_Samsung_GlobalNG_RANCell_ID buffer
 * @param [in]  pNeCgInfoBuffer : NeCgInfo buffer
 * @param [out] pSpCellNum      : SpCellNum
 * @param [in] cellChoice       : E1_nr_chosen / E1_e_utra_chosen / E1_Samsung_NG_RAN_Cell_Identity_choice_extension_chosen
 */
int16_t VEIL_fillE1_Samsung_GlobalNG_RANCell_ID(callInfo_type *ptCi, E1_Samsung_GlobalNG_RANCell_ID *pSpCell_ID,
    E1_SamsungNeCgInfoData::E1_SamsungNeCgInfoBuffer *pNeCgInfoBuffer, uint16_t *pSpCellNum, const int cellChoice)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pSpCell_ID);
    VALID_E_POINT_CHECK_ERROR(pNeCgInfoBuffer);
    VALID_E_POINT_CHECK_ERROR(pSpCellNum);

    *pSpCellNum = ptCi->servCellNum;

    // During Intra-gNB HO after NR RRCRconfigComplete form UE send new serving cell to UP
    if (  // NSA states
        (STATE_DCIntraDuHo_RRCRecCmpl == ptCi->state) || (STATE_DCIntraDuHo_X2RecCmpl == ptCi->state) ||
        (STATE_DCIntraDuHo_X2SnStatus == ptCi->state) || (STATE_DCIntraDuHo_X2ModCnf == ptCi->state) ||
        (STATE_DCInterDuHo_RRCRecCmpl == ptCi->state) || (STATE_DCInterDuHo_X2RecCmpl == ptCi->state) ||
        (STATE_DCInterDuHo_X2SnStatus == ptCi->state) || (STATE_DCInterDuHo_X2ModCnf == ptCi->state) ||
        (STATE_DCNonDuHo_X2SnStatus == ptCi->state) || (STATE_DCNonDuHo_X2RecCmpl == ptCi->state) ||
        // SA states
        (STATE_INTRA_DU_Complete == ptCi->state) || (STATE_INTER_DU_Complete == ptCi->state) ||
        (STATE_SN_INTRA_DU_Complete == ptCi->state) || (STATE_SN_INTER_DU_Complete == ptCi->state) ||
        (STATE_Ltm_Complete == ptCi->state && true == ptCi->ltmUeInfo.cellSwitchFlag.e1ResumeIsRequired))
    {
        *pSpCellNum = ptCi->hoInfo.targetCellNum;
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(*pSpCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[*pSpCellNum];

    pSpCell_ID->bit_mask = 0;
    pSpCell_ID->iE_Extensions = NULL;

    if (E1_nr_chosen == cellChoice)
    {
        // E1_PLMN_Identity plmn_id;
        plmnId_type plmnId;
        plmnId.longId = pCell->cellPlmn.servedPlmn[0];
        int32_t status = VEIL_fillE1_PLMN_Identity(&pSpCell_ID->plmn_id, plmnId);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_PLMN_Identity ERROR!\n");

        // E1_Samsung_NG_RAN_Cell_Identity ng_RAN_Cell_id
        pSpCell_ID->ng_RAN_Cell_id.choice = E1_nr_chosen;
        pSpCell_ID->ng_RAN_Cell_id.u.nr.value = &pNeCgInfoBuffer->cgi[0];
        status = FillE1_BitString(&pSpCell_ID->ng_RAN_Cell_id.u.nr, pCell->cgi.ci, NR_NCI_BITS_LEN);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FillE1_BitString ERROR!\n");
    }
    else if (E1_e_utra_chosen == cellChoice)
    {
        // E1_PLMN_Identity plmn_id;
        int32_t status = VEIL_fillE1_PLMN_Identity(&pSpCell_ID->plmn_id, ptCi->eCGI.plmn);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_PLMN_Identity ERROR!\n");

        // E1_Samsung_NG_RAN_Cell_Identity ng_RAN_Cell_id
        pSpCell_ID->ng_RAN_Cell_id.choice = E1_e_utra_chosen;
        pSpCell_ID->ng_RAN_Cell_id.u.e_utra.value = &pNeCgInfoBuffer->cgi[0];
        status = FillE1_BitString(&pSpCell_ID->ng_RAN_Cell_id.u.e_utra, ptCi->eCGI.ci, ECI_BIT_LENGTH);
           VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FillE1_BitString ERROR!\n");
    }
    // 26B E1_Samsung_NG_RAN_Cell_Identity_choice_extension_chosen filling not implemented yet

    return GOOD;
}

/**
 * @brief Fill Samsung specific IE
 *        TYPE SamsungCarrierInformation
 * @param [in]  ptCi                        : callInfo
 * @param [out] pSamsungCarrierInformation  : E1_SamsungCarrierInformation buffer
 * @param [in]  spCellNum                   : Cell Number
 **/
int16_t VEIL_fillE1_SamsungCarrierInformation(callInfo_type *ptCi, E1_Samsung_NE_CG_Information *pSamsungNECGInfo,
    E1_SamsungCarrierInformation *pSamsungCarrierInformation, uint16_t *pSpCellNum,
    struct E1_ProtocolExtensionContainer_ *pContainer)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pSamsungCarrierInformation);
    VALID_E_POINT_CHECK_ERROR(pSpCellNum);
    VCCB_CHECK_E_RANGE_AND_RETURN(*pSpCellNum, MAX_CELL_NUM_VCCB);
    VALID_E_POINT_CHECK_ERROR(pContainer);

    const VccbCellInfo_type *const pCell = &CELLINFO[*pSpCellNum];

    uint8_t duplexMode = pCell->duplexMode;
    uint32_t carrierFrequency = pCell->nrArfcnDl; // Lowest subcarrier - Point A
    uint16_t band = BAND_NOT_SET;
    uint16_t bw = pCell->intraGnbNbrInfo.bandwidthDl;

    /// gNB-CU-CP (VCCB) shall include Carrier Information of the current SpCell within NE and CellGroupInformation IE
    /// in BEARER CONTEXT SETUP/MODIFICATION REQUEST messages
    pSamsungCarrierInformation->duplexMode = duplexMode == ci_DUPLEXTYPE_TDD ? E1_tdd : E1_fdd;
    pSamsungCarrierInformation->bit_mask = E1_duplexMode_present;

    pSamsungCarrierInformation->carrierFrequency = carrierFrequency;
    pSamsungCarrierInformation->bit_mask |= E1_carrierFrequency_present;

    // During Intra-gNB HO after NR RRCRconfigComplete form UE send new serving cell to UP
    if (  // NSA states
        (STATE_DCIntraDuHo_RRCRecCmpl == ptCi->state) || (STATE_DCIntraDuHo_X2RecCmpl == ptCi->state) ||
        (STATE_DCIntraDuHo_X2SnStatus == ptCi->state) || (STATE_DCIntraDuHo_X2ModCnf == ptCi->state) ||
        (STATE_DCInterDuHo_RRCRecCmpl == ptCi->state) || (STATE_DCInterDuHo_X2RecCmpl == ptCi->state) ||
        (STATE_DCInterDuHo_X2SnStatus == ptCi->state) || (STATE_DCInterDuHo_X2ModCnf == ptCi->state) ||
        (STATE_DCNonDuHo_X2SnStatus == ptCi->state) || (STATE_DCNonDuHo_X2RecCmpl == ptCi->state) ||
        // SA states
        (STATE_INTRA_DU_Complete == ptCi->state) || (STATE_INTER_DU_Complete == ptCi->state) ||
        (STATE_SN_INTRA_DU_Complete == ptCi->state) || (STATE_SN_INTER_DU_Complete == ptCi->state) ||
        (STATE_Ltm_Complete == ptCi->state && true == ptCi->ltmUeInfo.cellSwitchFlag.e1ResumeIsRequired))
    {
        band = ptCi->hoInfo.targetCellBand;
    }
    else
    {
        band = ptCi->servCellBand;
    }

    if (band > BAND_NOT_SET && band <= MAX_NUM_NR_BAND)
    {
        pSamsungCarrierInformation->frequencyBand = band;
        pSamsungCarrierInformation->bit_mask |= E1_frequencyBand_present;
    }
   
    switch(pCell->nrScsDl)
    {
        case ci_Nr_scs15:
        case ci_Nr_scs30:
        case ci_Nr_scs60:
        case ci_Nr_scs120:
        {
            pSamsungCarrierInformation->subcarrierSpacing = static_cast<E1__enum2_1>(pCell->nrScsDl);
            pSamsungCarrierInformation->bit_mask |= E1_subcarrierSpacing_present;
            break;
        }
        case ci_Nr_scs240:
        default:
            // not supported in E1__enum2_1
            break;
    }
   
    if (bw > 0 && bw <= 275) // BW range supported in SamsungCarrierInformation asn definition
    {
        pSamsungCarrierInformation->bandwidth = bw;
        pSamsungCarrierInformation->bit_mask |= E1_bandwidth_present;
    }

    InsertE1_ExtensionContainerValue(pContainer, E1_id_SamsungCarrierInformation, E1_ignore, pSamsungCarrierInformation,
        E1_SamsungCarrierInformation_PDU);
    pSamsungNECGInfo->iE_Extensions = pContainer;
    pSamsungNECGInfo->bit_mask |= E1_Samsung_NE_CG_Information_iE_Extensions_present;

    return GOOD;
}

/**
 * @brief Fill Samsung specific IE
 *        TYPE SamsungNECGInformationList
 **/
int16_t VEIL_fillE1_SamsungNECGInformationList(callInfo_type *ptCi, E1_SamsungNeCgInfoData *pSamsungNeCgInfoBuffer,
    E1_SamsungCarrierInformation *pSamsungCarrierInformation, struct E1_ProtocolExtensionContainer_ *pContainer)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pSamsungNeCgInfoBuffer);
    VALID_E_POINT_CHECK_ERROR(pContainer);

    uint8_t numNECGIInfoElem = 0;

    // [0] serving Node
    E1_SamsungNECGInformationItem *pSamsungNECGInfoItem =
        &pSamsungNeCgInfoBuffer->samsungNECGInformationList[numNECGIInfoElem].value;
    pSamsungNECGInfoItem->choice = E1_servingNode_chosen;

    E1_Samsung_NE_CG_Information *pSamsungNECGInfo = &pSamsungNECGInfoItem->u.servingNode;

    pSamsungNECGInfo->bit_mask = 0;
    pSamsungNECGInfo->iE_Extensions = NULL;

    // E1_Samsung_GlobalNG_RANNode_ID - optional
    pSamsungNECGInfo->bit_mask |= E1_globalNG_RANNode_ID_present;
    pSamsungNECGInfo->globalNG_RANNode_ID.choice = E1_gNB_chosen;
    int16_t status = VEIL_fillE1_Samsung_GlobalgNB_ID(
        ptCi, &pSamsungNECGInfo->globalNG_RANNode_ID.u.gNB, &pSamsungNeCgInfoBuffer->buffer[numNECGIInfoElem]);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_Samsung_GlobalgNB_ID ERROR!\n");

    // E1_Cell_Group_ID cell_Group_ID - mandatory
    if (E_CALLTYPE_NSA == ptCi->callType || IS_NRDC_SN(ptCi))
    {
        pSamsungNECGInfo->cell_Group_ID = CellGroupId_SCG;
    }
    else
    {
        pSamsungNECGInfo->cell_Group_ID = CellGroupId_MCG;
    }

    // E1_Samsung_GlobalNG_RANCell_ID spCell_ID - optional
    if (true == CheckSpCellExistence(ptCi))
    {
        uint16_t spCellNum;

        pSamsungNECGInfo->bit_mask |= E1_spCell_ID_present;
        status = VEIL_fillE1_Samsung_GlobalNG_RANCell_ID(
            ptCi, &pSamsungNECGInfo->spCell_ID, &pSamsungNeCgInfoBuffer->buffer[numNECGIInfoElem], &spCellNum, E1_nr_chosen);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_Samsung_GlobalNG_RANCell_ID ERROR!\n");

        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "samsungCarrierInformation container index ERROR!\n");
        status = VEIL_fillE1_SamsungCarrierInformation(
            ptCi, pSamsungNECGInfo, pSamsungCarrierInformation, &spCellNum, pContainer);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_SamsungCarrierInformation ERROR!\n");
    }

    ++numNECGIInfoElem;

    // [1] peer Node
    if (E_CALLTYPE_NSA == ptCi->callType)
    {
        E1_SamsungNECGInformationItem *pSamsungNECGInfoItemPeer =
            &pSamsungNeCgInfoBuffer->samsungNECGInformationList[numNECGIInfoElem].value;
        pSamsungNECGInfoItemPeer->choice = E1_peerNode_chosen;

        E1_Samsung_NE_CG_Information *pSamsungNECGInfoPeer = &pSamsungNECGInfoItemPeer->u.peerNode;

        pSamsungNECGInfoPeer->bit_mask = 0;
        pSamsungNECGInfoPeer->iE_Extensions = NULL;

        // E1_Samsung_GlobalNG_RANNode_ID - optional

        // E1_Cell_Group_ID cell_Group_ID - mandatory
        pSamsungNECGInfoPeer->cell_Group_ID = CellGroupId_MCG;

        // E1_Samsung_GlobalNG_RANCell_ID spCell_ID - optional
        uint16_t spCellNum = MAX_CELL_NUM_VCCB;  // Not used in peer node,

        pSamsungNECGInfoPeer->bit_mask |= E1_spCell_ID_present;
        status = VEIL_fillE1_Samsung_GlobalNG_RANCell_ID(
            ptCi, &pSamsungNECGInfoPeer->spCell_ID, &pSamsungNeCgInfoBuffer->buffer[numNECGIInfoElem], &spCellNum, E1_e_utra_chosen);

        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_Samsung_GlobalNG_RANCell_ID ERROR!\n");
        ++numNECGIInfoElem;
    }

    status = VCCB_ConnectLinkedList(pSamsungNeCgInfoBuffer->samsungNECGInformationList, static_cast<int>(numNECGIInfoElem));
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, status, "fnConnectLinkedList failed - VEIL_fillE1_SamsungNECGInformationList!!\n");

    return GOOD;
}

/**
 * @brief check conditions for direct data forwarding
 * @param [in] rCi                                  : reference to callInfo
 * @param [in/out] directForwardingPathAvaliability : E1_BearerContextSetupRequestBuffer::directForwardingPathAvaliability
 */
bool FnVCCB_IsDirectForwardingPathAvailable(
    const callInfo_type &rCi, E1_DirectForwardingPathAvailability &directForwardingPathAvaliability)
{
    AUTO_TRACE_FUNC;

    switch (rCi.callType)
    {
        case E_CALLTYPE_SA:
            if (rCi.hoInfo.allPduSessDirectFwdPathAvailable ||
                (HO_TYPE_INTRA_SYSTEM == rCi.hoInfo.hoType.system && HO_TYPE_XN == rCi.hoInfo.hoType.interface) ||
                rCi.hoInfo.sgnbAddTrigInd == SgnbAddTrigInd_SnChange)
            {
                if (HO_TYPE_INTER_SYSTEM == rCi.hoInfo.hoType.system)
                {
                    VCCB_CHECK_VALID_GNBNUM_RET_VAL(rCi.gnbNum, false);
                    const gnbConfig_type *const pGnbCfg = &GNBINFO[rCi.gnbNum].cfg;

                    if (pGnbCfg->interSysDirectDataFwdTgt)
                    {
                        directForwardingPathAvaliability = E1_inter_system_direct_path_available;
                        return true;
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    directForwardingPathAvaliability = E1_intra_system_direct_path_available;
                    return true;
                }
            }
            break;

        case E_CALLTYPE_NSA:
            if (rCi.hoInfo.directFwdAvailable || rCi.hoInfo.internalFwdAvailable)
            {
                directForwardingPathAvaliability = E1_inter_system_direct_path_available;
                return true;
            }
            break;

        default:
            break;
    }
    return false;
}

/**
 * @brief check if internal data forwarding is possible and find the old UE context to get old gNB-CU-UP UE E1AP ID
 * @param [in] rCi                              : reference to callInfo
 * @param [in] directForwardingPathAvaliability : E1_BearerContextSetupRequestBuffer::directForwardingPathAvaliability
 * @param [in/out] gnbCuUpUeE1apId              : E1_BearerContextSetupRequestBuffer::gnbCuUpUeE1apId
 * @param [in] endPointIdx                      : index of UP
 */
bool FnVCCB_CheckInternalFwdConditionsAndGetOldCuUpUeId(const callInfo_type &rCi,
    E1_DirectForwardingPathAvailability directForwardingPathAvaliability, E1_GNB_CU_UP_UE_E1AP_ID &gnbCuUpUeE1apId,
    const uint16_t endPointIdx)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_FALSE(endPointIdx, MAX_CU_UP_PER_CALL);

    if (rCi.hoInfo.internalFwdAvailable)
    {
        if (INVALID_SRC_CALLID_FOR_IRAT_HO != rCi.srcCuCpUeIdInterRATHo && !rCi.hoInfo.directFwdAvailable &&
            E1_inter_system_direct_path_available == directForwardingPathAvaliability)
        {
            const callInfo_type *const pSrcCallInfo = FnVCCB_GetCallInUseByCuCpUeId(rCi.srcCuCpUeIdInterRATHo);
            if (pSrcCallInfo != NULL)
            {
                for (int srcCallSrvUpIdx = 0; srcCallSrvUpIdx < MAX_CU_UP_PER_CALL; ++srcCallSrvUpIdx)
                {
                    if ((CI_use == pSrcCallInfo->endPointInfo.aupf[srcCallSrvUpIdx].usage) &&
                        (endPointIdx == pSrcCallInfo->endPointInfo.aupf[srcCallSrvUpIdx].e1Idx))
                    {
                        gnbCuUpUeE1apId = pSrcCallInfo->upCallId[srcCallSrvUpIdx];
                        return true;
                    }
                }
            }
        }
    }
    return false;
}

/**
 * @brief       Make Elementary Procedure E1 Bearer Context Setup Request message
 * @details     fill all necessary fields and pack into ASN structure
 * @attention   function sets all bit_mask
 * @param [in]  ptCi    : callInfo DB
 * @param [in]  ptSctp  : SctpDataReq_type buffer
 * @return      GOOD    : make BearerSetupRequest message
 * @return      ERROR   : can't make BearerSetupRequest message
 */
int VEIL_makeBearerContextSetupRequest(callInfo_type *ptCi, SctpDataTransfer_type *ptSctp)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptSctp);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);

    int status = GOOD;
    unsigned int ieCnt = 0, sysCnt = 0, loop = 0;
    E1_BearerContextSetupRequest sendMsg, *ptMsg = &sendMsg;
    E1_BearerContextSetupRequestBuffer *ptBearerSetupRequestBuffer =
        &THREAD_INFO->call[ptCi->myThreadId].buf.tx.e1ap.bearerContextSetupRequest;
    E1_SamsungNECGInformationList pE1_SamsungNECGInformationList =
        ptBearerSetupRequestBuffer->samsungNeCgInfoBuffer.samsungNECGInformationList;
    E1_SubscriberProfileIDforRFP subscriberProfileIDforRFP = ptCi->ueInfo.rfsp.subscriberProfile;
    E1_SubscriberProfileIDforRFP indexToRFSP = ptCi->ueInfo.rfsp.indexToRFSP;
    E1_SamsungEmergencyBearerIncluded* pE1_SamsungEmergencyBearerIncluded = &ptBearerSetupRequestBuffer->samsungEmergencyBearerIncluded;

#define MAX_E1_IE_CNT_STP_REQ 22
    struct E1_ProtocolIE_Container_ ieContainers[MAX_E1_IE_CNT_STP_REQ]
    {
    };
    ptMsg->protocolIEs = ieContainers;

    E1_DRB_To_Setup_List_EUTRAN drbListBuff = ptBearerSetupRequestBuffer->drbToSetupList;
    E1_PDU_Session_Resource_To_Setup_List pduSessListBuff = ptBearerSetupRequestBuffer->pduSessToSetupList;
    E1_UESliceMaximumBitRateList ueSliceMBRListBuff = ptBearerSetupRequestBuffer->ueSliceMaximumBitRateList;
    E1_BitRate bitRate;

    FnVCCB_checkAndStoreDirectFwdPathAvailableInAllPduSess(ptCi, ptSctp->endPointIdx);

    // SVR26A FGR-TA0601 VoMA
    status = VLIB_VomaActivate(*ptCi, VOMA_callSetup);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[VoMA] Startup condition not fulfilled\n");
    }

    // 1. gNB-CU-CP UE E1AP ID - mandatory
    ptBearerSetupRequestBuffer->gnbCuCpUeE1apId = ptCi->gnbCuUeId;
    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_gNB_CU_CP_UE_E1AP_ID, E1_reject,
        &ptBearerSetupRequestBuffer->gnbCuCpUeE1apId, E1_GNB_CU_CP_UE_E1AP_ID_PDU);

    // 2. Security Information - mandatory
    status = VEIL_fillE1_SecurityInformation(ptCi, &ptBearerSetupRequestBuffer->securityInformation);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_SecurityInformation ERROR!\n");
    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_SecurityInformation, E1_reject,
        &ptBearerSetupRequestBuffer->securityInformation, E1_SecurityInformation_PDU);

    // 3. UE DL Aggregate Maximum BitRate - mandatory
    status = VEIL_FillE1_id_UEDLAggregateMaximumBitRate(ptCi, ptSctp->endPointIdx, __FUNCTION__, FALSE, ieContainers,
        GET_ARR_SIZE(ieContainers), &ieCnt, ptBearerSetupRequestBuffer);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_FillE1_id_UEDLAggregateMaximumBitRate ERROR!\n");

    // 4. UEDLMaximumIntegrityProtectedDataRate (optional)
    if (VEIL_checkE1_UEDLMaximumProtectedDataRate_Existence(ptCi, bitRate) == TRUE)
    {
        status = VEIL_FillE1_id_UEDLMaximumIntegrityProtectedDataRate(
            ptCi, __FUNCTION__, bitRate, ieContainers, GET_ARR_SIZE(ieContainers), &ieCnt, ptBearerSetupRequestBuffer);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_FillE1_id_UEDLMaximumIntegrityProtectedDataRate ERROR!\n");
    }

    // 5. Serving PLMN - mandatory
    status = VEIL_fillE1_PLMN_Identity(&ptBearerSetupRequestBuffer->servingPLMN, ptCi->ueInfo.servedPlmn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_PLMN_Identity ERROR!\n");
    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_Serving_PLMN, E1_ignore,
        &ptBearerSetupRequestBuffer->servingPLMN, E1_PLMN_Identity_PDU);

    // 6. Activity Notification Level (mandatory)
    // 7. UE Inactivity Timer (optional)
    if (IS_SUPPORT_RRC_INACTIVE(ptCi))
    {
        ptBearerSetupRequestBuffer->activityNotificationLevel =
            IS_REDCAP_UE(ptCi) ? 
            FnVCCB_FillActivityNotificationLevel(ptCi->ueInfo.RrcInactiveInfo.redCapActivityNotificationLevel):
            FnVCCB_FillActivityNotificationLevel(ptCi->ueInfo.RrcInactiveInfo.activityNotificationLevel);
        InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_ActivityNotificationLevel, E1_reject,
                &ptBearerSetupRequestBuffer->activityNotificationLevel, E1_ActivityNotificationLevel_PDU);

        // set the IATTimer1 (inactive timer)
        if (IS_RRC_INACTIVE_UE_LEVEL(ptCi))
        {
            // SVR25B FGR-CC0103
            if (ptCi->ueInfo.rrcResumeInfo.actionInSNRelease == SN_REL_IN_RRC_INACTIVE_DECIDED && (not IS_NRDC_SN(ptCi)))
            {
                ptBearerSetupRequestBuffer->ueInactivityTimer = 1;
            }
            else
            {
                ptBearerSetupRequestBuffer->ueInactivityTimer =
                    IS_REDCAP_UE(ptCi) ?
                    GNBINFO[ptCi->gnbNum].RrcInactiveInfo.redCapRrcInactiveTimer :
                    GNBINFO[ptCi->gnbNum].RrcInactiveInfo.rrcInactiveTimer;
            }
            InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_UE_Inactivity_Timer, E1_reject,
                    &ptBearerSetupRequestBuffer->ueInactivityTimer, E1_Inactivity_Timer_PDU);
        }
    }
    else
    {
        enumActivityNotifLvl_type selectedLevel = FnVCCB_Get_UserInactivity_NotiLevel(ptCi);
        switch (selectedLevel)
        {
            case activityNotifLvl_UE:
                {
                    ptBearerSetupRequestBuffer->activityNotificationLevel =
                        FnVCCB_FillActivityNotificationLevel(activityNotifLvl_UE);
                    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_ActivityNotificationLevel, E1_reject,
                            &ptBearerSetupRequestBuffer->activityNotificationLevel, E1_ActivityNotificationLevel_PDU);

                    status = FnVCCB_FillUeInactivityTimerValue(ptCi, &ptBearerSetupRequestBuffer->ueInactivityTimer);
                    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_FillUeInactivityTimerValue ERROR!\n");

                    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_UE_Inactivity_Timer, E1_reject,
                            &ptBearerSetupRequestBuffer->ueInactivityTimer, E1_Inactivity_Timer_PDU);
                }
                break;

            case activityNotifLvl_DRB:
                {
                    ptBearerSetupRequestBuffer->activityNotificationLevel =
                        FnVCCB_FillActivityNotificationLevel(activityNotifLvl_DRB);
                    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_ActivityNotificationLevel, E1_reject,
                            &ptBearerSetupRequestBuffer->activityNotificationLevel, E1_ActivityNotificationLevel_PDU);
                }
                break;

            default: // activityNotifLvl_PDUSession
                {
                    ptBearerSetupRequestBuffer->activityNotificationLevel =
                        FnVCCB_FillActivityNotificationLevel(activityNotifLvl_PDUSession);
                    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_ActivityNotificationLevel, E1_reject,
                            &ptBearerSetupRequestBuffer->activityNotificationLevel, E1_ActivityNotificationLevel_PDU);
                }
                break;
        }
    }

    // 8. BearerContextStatusChange (optional)

    // 9. Choice System - mandatory
    struct E1_ProtocolIE_Container_ choiceSystemContainer[3]{};
    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        ptBearerSetupRequestBuffer->choiceSystem.choice = E1_e_UTRAN_BearerContextSetupRequest_chosen;
        ptBearerSetupRequestBuffer->choiceSystem.u.e_UTRAN_BearerContextSetupRequest = choiceSystemContainer;

        InsertE1_ContainerValue(&choiceSystemContainer[sysCnt++], E1_id_DRB_To_Setup_List_EUTRAN, E1_reject,
            &drbListBuff, E1_DRB_To_Setup_List_EUTRAN_PDU);

        if (OPT_PRESENT == ptCi->ueInfo.rfsp.rfspPresent)
        {
            InsertE1_ContainerValue(&choiceSystemContainer[sysCnt++], E1_id_SubscriberProfileIDforRFP, E1_ignore,
                &subscriberProfileIDforRFP, E1_SubscriberProfileIDforRFP_PDU);
        }
    }
    else  // SA_CALL
    {
        ptBearerSetupRequestBuffer->choiceSystem.choice = E1_nG_RAN_BearerContextSetupRequest_chosen;
        ptBearerSetupRequestBuffer->choiceSystem.u.nG_RAN_BearerContextSetupRequest = choiceSystemContainer;

        InsertE1_ContainerValue(&choiceSystemContainer[sysCnt++], E1_id_PDU_Session_Resource_To_Setup_List, E1_reject,
            &pduSessListBuff, E1_PDU_Session_Resource_To_Setup_List_PDU);
        
        if (OPT_PRESENT == ptCi->ueInfo.rfsp.rfspPresent)
        {
            InsertE1_ContainerValue(&choiceSystemContainer[sysCnt++], E1_id_SubscriberProfileIDforRFP, E1_ignore,
                &indexToRFSP, E1_SubscriberProfileIDforRFP_PDU);
        }

        // Samsung NR RedCap UE Indication
        if ((TRUE == FOO.VF_BasicCallProcedureforRedCapUE) && IS_REDCAP_UE(ptCi) && (E_CALLTYPE_SA == ptCi->callType))
        {
            ptBearerSetupRequestBuffer->samsungNRRedCapUEIndication = E1_SamsungNRRedCapUEIndication_true;
            InsertE1_ContainerValue(&choiceSystemContainer[sysCnt++], E1_id_SamsungNRRedCapUEIndication, E1_ignore,
                &ptBearerSetupRequestBuffer->samsungNRRedCapUEIndication, E1_SamsungNRRedCapUEIndication_PDU);
        }
    }

    status = VCCB_ConnectLinkedList(choiceSystemContainer, static_cast<int>(sysCnt));
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "ERROR: VCCB_ConnectLinkedList failed for choice system container!!\n");

    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_System_BearerContextSetupRequest, E1_reject,
        &ptBearerSetupRequestBuffer->choiceSystem, E1_System_BearerContextSetupRequest_PDU);

    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        // DRB To Setup List Fill
        uint16_t numErab = 0;
        VLIB_PrepareQciAttemptSuccess(ptCi, ErabAddAtt);
        for (loop = 0; loop < MAX_ERAB_PER_CALL; loop++)
        {
            if (CI_use != ptCi->erabInfo[loop].usage || ERAB_Setup != ptCi->erabInfo[loop].erabStatus ||
                ptSctp->endPointIdx != ptCi->erabInfo[loop].e1Idx)
            {
                continue;
            }

            // Statistics Update
            ptCi->ptTempRi = &ptCi->erabInfo[loop];
            MACRO_STAT_PMCC_QCI(STAT_ERAB_ADD_PER_GNB, ErabAddAtt, ptCi, ptCi->ptTempRi, 0, 0, 0, 0);
            VLIB_PeggQciAttemptSuccess(ptCi, ptCi->erabInfo[loop].erabQos.qciValue.QCI, ErabAddAtt);

            // DRB To Setup Item Fill
            status = VEIL_fillE1_DrbToSetupItemEUTRAN(
                ptCi, ptCi->erabInfo[loop].erabIdx, numErab, ptBearerSetupRequestBuffer);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_DrbToSetupItemEUTRAN ERROR!!\n");
            ++numErab;
        }

        if (numErab)
        {
            // Connect DRB To Setup List
            status = VCCB_ConnectLinkedList(ptBearerSetupRequestBuffer->drbToSetupList, static_cast<int>(numErab));
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status,
                "ERROR: VCCB_ConnectLinkedList failed in VEIL_makeBearerContextSetupRequest-> DRB To Setup List!\n");
        }
        else
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "VEIL_makeBearerContextSetupRequest No DRB To Setup!! numErab:%d ERROR\n", numErab);
            return ERROR;
        }
    }
    else  // SA_CALL
    {
        // PDU Session Resource To Setup List Fill - mandatory
        unsigned int numPduSess = 0;
        for (loop = 0; loop < MAX_PDU_SESS_PER_CALL; loop++)
        {
            if ((CI_use != ptCi->pduSess[loop].usage) || (ptSctp->endPointIdx != ptCi->pduSess[loop].e1Idx))
            {
                VCCB_PRINT_CALL_DATA(ptCi,
                    "[E1DBG] pduSess[%d] is not considered for Bearer (e1Idx:%u) Setup. usage(%u), "
                    "pduSess.e1Idx(%u)\n",
                    loop, ptSctp->endPointIdx, ptCi->pduSess[loop].usage, ptCi->pduSess[loop].e1Idx);
                continue;
            }

            if (false == FnVCCB_is_E1_PDUSessToBeSetup(ptCi, &ptCi->pduSess[loop])) continue;

            if (IS_MRDC_MN(ptCi))
            {
                if (!FnVCCB_IsAnyMnTermPerPDU(ptCi, &ptCi->pduSess[loop], request_bearerType))
                {
                    VCCB_PRINT_CALL_DATA(ptCi, "[E1DBG] ptCi->pduSess[%d] is not include MNTerm bearer in %s!\n", loop, __func__);
                    continue;
                }
            }
            else if (IS_NRDC_SN(ptCi) && (FALSE == FnVCCB_ExistValidSNTermBearerInPdu(ptCi, &ptCi->pduSess[loop])))
            {
                VCCB_PRINT_CALL_DATA(ptCi, "[E1DBG] ptCi->pduSess[%d] is not include SNTerm bearer!\n", loop);
                continue;
            }

            // Statistics Update
            // TBD coding
            // ptCi->ptTempRi = &ptCi->erabInfo[loop];
            // MACRO_STAT_PMCC_QCI(STAT_ERAB_ADD_PER_GNB, ErabAddAtt, ptCi, ptCi->ptTempRi, 0, 0, 0, 0);

            // PDU Session Resource To Setup Item Fill - mandatory
            status = VEIL_fillE1_PDUSessToSetupItem(&ptBearerSetupRequestBuffer->pduSessToSetupList[numPduSess].value,
                &ptBearerSetupRequestBuffer->pduSessToSetupData[numPduSess], ptCi, &(ptCi->pduSess[loop]));
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_PDUSessToSetupItem ERROR!!\n");
            ++numPduSess;

            ON_PDU_SESS_E1_SETUP_FLAG(ptCi->pduSess[loop].flag.respFlag);
            if (DBG->flag.logE1) VCCB_PRINT_CALL_DATA(ptCi, "[E1DBG] ON_PDU_SESS_E1_SETUP_FLAG %d\n", ptCi->pduSess[loop].pduSessId);
        }

        if (numPduSess)
        {
            // Connect PDU Session Resource To Setup List
            status = VCCB_ConnectLinkedList(ptBearerSetupRequestBuffer->pduSessToSetupList, static_cast<int>(numPduSess));
            VCCB_RETURN_ON_CALL_ERROR(
                ptCi, status, "VCCB_ConnectLinkedList failed in %s-> PDU Session Resource To Setup List!\n", __func__);
        }
        else
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "VEIL_makeBearerContextSetupRequest No PduSess To Setup!! numPduSess:%d ERROR\n", numPduSess);
            return ERROR;
        }
    }

    //RoHC EHC Reset the Retry Flag
    ptCi->ueInfo.roHCCapability.isRetryDueToUPFailure  = FALSE;
    ptCi->ueInfo.ehcCapability.isEHCRetryDueToUPFailure = FALSE;

    // 10. RANUEID (optional)
    // 11. GNB-DU-ID (optional)
    if (true == CheckSpCellExistence(ptCi))
    {
        if (// NSA states
            (STATE_DCInterDuHo_RRCRecCmpl == ptCi->state) || (STATE_DCInterDuHo_X2RecCmpl == ptCi->state) ||
            (STATE_DCInterDuHo_X2SnStatus == ptCi->state) || (STATE_DCInterDuHo_X2ModCnf == ptCi->state) ||
            // SA states
            (STATE_INTER_DU_Complete == ptCi->state) || (STATE_SN_INTER_DU_Complete == ptCi->state) ||
            (STATE_Ltm_Complete == ptCi->state && true == ptCi->ltmUeInfo.cellSwitchFlag.e1ResumeIsRequired))
        {
            const uint16_t f1Idx = ptCi->hoInfo.targetDu.f1Idx;
            ptBearerSetupRequestBuffer->gnbDuId = FnVCCB_GetDuId(ptCi->gnbNum, f1Idx);
        }
        else
        {
            ptBearerSetupRequestBuffer->gnbDuId = ptCi->endPointInfo.gnbDuId;
        }
        
        InsertE1_ContainerValue(
            &ieContainers[ieCnt++], E1_id_GNB_DU_ID, E1_ignore, &ptBearerSetupRequestBuffer->gnbDuId, E1_GNB_DU_ID_PDU);
    }

    // 12. Trace Activation (optional)
    if (VCCB_FLAG_ON == ptCi->signalingTraceInfo.trace.ueThroughputAndRfTraceFlag ||
        mdtImmediate == ptCi->signalingTraceInfo.mdt.mdtStatus)
    {
        ptCi->traceType = Trace_Signaling;  // build based on Signaling trace config

        if(GOOD == VEIL_fillE1_TraceActivation(ptCi, &ptBearerSetupRequestBuffer->traceActivationData,
            &ptBearerSetupRequestBuffer->traceActivationData.traceActivation, MAX_CELL_NUM_VCCB))
        {
            InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_TraceActivation, E1_ignore,
                    &ptBearerSetupRequestBuffer->traceActivationData.traceActivation, E1_TraceActivation_PDU);
        }
        else
        {
            ptBearerSetupRequestBuffer->traceActivationData.traceActivation.bit_mask = 0;
            ptBearerSetupRequestBuffer->traceActivationData.traceActivation.iE_Extensions = NULL;
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_TraceActivation ERROR!\n");
        }
    }

    // -- SAMSUNG SPECIFIC START
    if (TRUE == FOO.VF_CallSummaryLogs_IncludingDataForStitching || TRUE == FOO.VF_CallSummaryLogs_SupportStitching)
    {
        // 13. Csl Stitching Info (optional)
        status =
            VEIL_fillE1_SamsungCslStitchingInfo(ptCi, ptBearerSetupRequestBuffer->samsungCslStitchingInfoWithCIBuffer);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_SamsungCslStitchingInfo ERROR!\n");

        InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_Samsung_Csl_Stitching_Info, E1_ignore,
            &ptBearerSetupRequestBuffer->samsungCslStitchingInfoWithCIBuffer.samsungCslStitchingInfo,
            E1_SamsungCslStitchingInfo_PDU);
    }

    // 14. IMSI
    if (0 < ptCi->ueInfo.ueId.imsi.n && ptCi->ueInfo.ueId.imsi.n <= MAX_IMSI_DIGIT)
    {
        status = ConvertImsiToZImsi_E(
            ptCi->debugTrace, (IMSI_type *)&ptCi->ueInfo.ueId.imsi, (ZIMSI_type *)&ptBearerSetupRequestBuffer->zImsi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_ConvertImsiToZImsi ERROR!\n");
        InsertE1_ContainerValue(
            &ieContainers[ieCnt++], E1_id_IMSI, E1_ignore, &ptBearerSetupRequestBuffer->zImsi, E1_Z_IMSI_PDU);
    }

    // 15. Insert Samsung-NE-CG-Information-List
    status = VEIL_fillE1_SamsungNECGInformationList(ptCi, &ptBearerSetupRequestBuffer->samsungNeCgInfoBuffer,
        &ptBearerSetupRequestBuffer->samsungCarrierInformationData.samsungCarrierInformation,
        &ptBearerSetupRequestBuffer->samsungCarrierInformationData.Container);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_SamsungNECGInformationList ERROR!\n");

    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_Samsung_NE_CG_Information_List, E1_ignore,
        &pE1_SamsungNECGInformationList, E1_SamsungNECGInformationList_PDU);
    // -- SAMSUNG SPECIFIC END


    // 16. CHO Initiation
    if (FnVCCB_IsConditionalHandoverUE(ptCi))
    {
        ptBearerSetupRequestBuffer->choInitiation = E1_CHOInitiation_true;

        InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_CHOInitiation, E1_reject,
            &ptBearerSetupRequestBuffer->choInitiation, E1_CHOInitiation_PDU);
    }

    // 17. Direct Forwarding Path Availability (9_3_1_98)
    if (FnVCCB_IsDirectForwardingPathAvailable(*ptCi, ptBearerSetupRequestBuffer->directForwardingPathAvaliability))
    {
        InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_DirectForwardingPathAvailability, E1_ignore,
            &ptBearerSetupRequestBuffer->directForwardingPathAvaliability, E1_DirectForwardingPathAvailability_PDU);

        // 18. gNB-CU-UP UE E1AP ID (9_3_1_5)
        if (FnVCCB_CheckInternalFwdConditionsAndGetOldCuUpUeId(*ptCi,
                ptBearerSetupRequestBuffer->directForwardingPathAvaliability,
                ptBearerSetupRequestBuffer->gnbCuUpUeE1apId, ptSctp->endPointIdx))
        {
            InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_gNB_CU_UP_UE_E1AP_ID, E1_ignore,
                &ptBearerSetupRequestBuffer->gnbCuUpUeE1apId, E1_GNB_CU_UP_UE_E1AP_ID_PDU);

            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[Forwarding]: Internal Forwarding proposed!\n");
            ptCi->hoInfo.directFwdAvailable = TRUE;
        }
    }

    // 19. SamsungEmergency Bearer Included
    if (ptCi->callType == E_CALLTYPE_SA &&
        ((VCCM_CheckEmergencyCall(ptCi) || VCCM_CheckMpsCall(ptCi) || VCCM_CheckHpaCall(ptCi))))
    {
        *pE1_SamsungEmergencyBearerIncluded = E1_included;
        InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_SamsungEmergencyBearerIncluded, E1_ignore,
            pE1_SamsungEmergencyBearerIncluded, E1_SamsungEmergencyBearerIncluded_PDU);
    }
    // -- SAMSUNG SPECIFIC END

    // 20. UE Slice Maximum Bit Rate List (9_3_1_102)
    if (VCCB_FLAG_ON == ptCi->ueInfo.sliceMbrInfo.isSliceMBRListProvided)
    {
        status = VEIL_FillE1_UESliceMaximumBitRateList(*ptCi, ueSliceMBRListBuff, true);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_FillE1_UESliceMaximumBitRateList ERROR!\n");
        if (GOOD == status)
        {
            InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_UESliceMaximumBitRateList, E1_ignore,
                &ueSliceMBRListBuff, E1_UESliceMaximumBitRateList_PDU);
        }
    }

    //  Connect list and pack msg
    VCCB_CHECK_E_RANGE_AND_RETURN(ieCnt, MAX_E1_IE_CNT_STP_REQ + 1);
    status = VCCB_ConnectLinkedList(ieContainers, static_cast<int>(ieCnt));
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, status, "VCCB_ConnectLinkedList failed in VEIL_makeBearerContextSetupRequest msg!!\n");

    long packLength = sizeof(ptSctp->data);
    if (ASN_OK != PackE1_AllMsg(ptMsg, E1_BearerContextSetupRequest_id, ptSctp->data, &packLength))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "PackE1_AllMsg ERROR in VEIL_makeBearerContextSetupRequest!!\n");

        return ERROR;
    }
    ptSctp->length = static_cast<uint32_t>(packLength);

    return status;
}

bool VEIL_NeedIncludeDrbToSetupItem_BearerCtxtMod(const callERABInfo_type &erab, const callInfo_type *const ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    return ((ERAB_Setup == erab.erabStatus) && (STATE_DCIntraDuHo_X2RecCmpl != ptCi->state) &&
            (STATE_DCIntraDuHo_X2SnStatus != ptCi->state) &&
            (STATE_DCSNRelRqrd != ptCi->state && SgNBReleaseRequest_cmd != ptCi->stateCmd) &&
            (STATE_DCInterDuHo_F1UeCtxSetReq != ptCi->state));
}

bool VEIL_NeedIncludeDrbToRemoveItem_BearerCtxtMod(const callERABInfo_type &erab, const callInfo_type *const ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    return ((ERAB_Release == erab.erabStatus && SgNBReleaseRequest_cmd != ptCi->stateCmd &&
                SgNBReleaseRequired_cmd != ptCi->stateCmd && SgNBReleaseConfirm_cmd != ptCi->stateCmd &&
                HO_TYPE_INTER_NB != ptCi->hoInfo.hoType.nb &&
                STATE_DCDuCfgQuery !=
                    ptCi->state &&  // do not include DRB-To-Remove-List in first E1 Modification for simultaneous erab
                                    // add and erab release during Inter-DU Inter MN HO w/o SN Change
                STATE_DCInterDuHo_F1UeCtxSetReq != ptCi->state &&
                STATE_DB != ptCi->state &&  // do not include DRB-To-Remove-List in first E1 Modification for erab
                                            // release during Intra-DU Inter MN HO w/o SN Change
                SgNBModification_cmd != ptCi->stateCmd &&
                SgnbInitBearerRelease_cmd !=
                    ptCi->stateCmd) ||  // send stop first, release later for modification-removed erabs
            (ERAB_Setup == erab.erabStatus &&
                (STATE_DCSNRelRqrd == ptCi->state || SgNBReleaseRequest_cmd == ptCi->stateCmd)) ||
            (ERAB_FailToSetup == erab.erabStatus &&
                STATE_DCF1Mod_S == ptCi->state));  // Remove DRB because of F1 Failure(DRB CAC)
}

/**
 * @brief      Check if given serving AUPF shall be released (all related
 *             ERABS/PDU sess are to Release)
 *             FGR-CC1109 Multi UP per Single UE
 * @param [in] ptCi : pointer to Ue Context
 * @return     true : AUPF shall     be released
 *            false : AUPF shall not be released
 */
bool VEIL_checkE1_NeedReleaseServingAupf(callInfo_type *ptCi, uint16_t servingUpIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(servingUpIdx, MAX_CU_UP_PER_CALL, false);

    if (E_CALLTYPE_NSA == ptCi->callType)
    {
        for (const callERABInfo_type &erab : ptCi->erabInfo)
        {
            if (CI_use == erab.usage && erab.e1Idx == ptCi->endPointInfo.aupf[servingUpIdx].e1Idx &&
                !VEIL_NeedIncludeDrbToRemoveItem_BearerCtxtMod(erab, ptCi))
            {
                return false;
            }
        }
    }
    else if (E_CALLTYPE_SA == ptCi->callType)
    {
        for (const callPDUSessInfo_type &pduSession : ptCi->pduSess)
        {
            if (CI_use == pduSession.usage && pduSession.e1Idx == ptCi->endPointInfo.aupf[servingUpIdx].e1Idx &&
                S_Release != pduSession.pduSessStatus)
            {
                return false;
            }
        }
    }
    return true;
}

/**
 * @brief       Fill DRB To Setup/Modify/Remove List
 * @details     fill all necessary fields and pack into ASN structure
 * @attention   set bit_mask before or inside called function - this function does not set needed bit_mask themselves
 * @param [in]  ptCi    : callInfo DB
 * @param [in]  ptBuf   : pointer of E1_BearerContextModificationRequestBuffer
 * @param [in]  srvUpIdx: index of serving AUPF
 * @param [out] numErabAdd : number of ERAB ADD
 * @param [out] numErabMod : number of ERAB MOD
 * @param [out] numErabRem : number of ERAB REMOVE
 * @return      GOOD    : make BearerSetupRequest message
 * @return      ERROR   : can't make BearerSetupRequest message
 */
int VEIL_fillE1_BearerContextMod_DrbToBeList(callInfo_type *ptCi, E1_BearerContextModificationRequestBuffer *ptBuf,
    uint16_t srvUpIdx, uint32_t *ptNumErabAdd, uint32_t *ptNumErabMod, uint32_t *ptNumErabRem)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptBuf);
    VCCB_CHECK_E_RANGE_AND_RETURN(srvUpIdx, MAX_CU_UP_PER_CALL);
    VALID_E_POINT_CHECK_ERROR(ptNumErabAdd);
    VALID_E_POINT_CHECK_ERROR(ptNumErabMod);
    VALID_E_POINT_CHECK_ERROR(ptNumErabRem);

    uint32_t numErabRem = 0, numErabAdd = 0;
    int16_t fRPSCellChangeType = 0;
    int numErabMod = 0;

    for (callERABInfo_type &erab : ptCi->erabInfo)
    {
        if (CI_use != erab.usage || ptCi->endPointInfo.aupf[srvUpIdx].e1Idx != erab.e1Idx) continue;

        if (VEIL_NeedIncludeDrbToSetupItem_BearerCtxtMod(erab, ptCi))
        {
            ptCi->ptTempRi = &erab;
            VCCB_RETURN_ON_CALL_ERROR(ptCi, VEIL_fillE1_DrbToSetupModItemEUTRAN(ptCi, erab.erabIdx, static_cast<uint16_t>(numErabAdd), ptBuf),
                "VEIL_fillE1_DrbToSetupModItemEUTRAN ERROR!\n");
            ++numErabAdd;
            continue;
        }
        if (VEIL_NeedIncludeDrbToRemoveItem_BearerCtxtMod(erab, ptCi))
        {
            ptCi->ptTempRi = &erab;
            VCCB_RETURN_ON_CALL_ERROR(ptCi,
                VEIL_fillE1_DrbToRemoveItemEUTRAN(&ptBuf->drbToRemoveList[numErabRem].value, &(erab)),
                "VEIL_fillE1_DrbToRemoveItemEUTRAN ERROR!\n");
            ++numErabRem;
            continue;
        }

        ptBuf->drbToModifyList[numErabMod].value.bit_mask = 0;
        switch (VEIL_getDrbToModItem_Status(ptCi, erab))
        {
            case enBearerCtxtMod_DrbToMod_status::F1Setup:
                ptCi->ptTempRi = &erab;
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_DrbToModifyItemEUTRAN_Add(
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, ptCi, &(erab), numErabMod),
                    "VEIL_fillE1_DrbToModifyItemEUTRAN_Add ERROR!\n");
                break;
            case enBearerCtxtMod_DrbToMod_status::ScgFailure_UlPathSwitch:
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_DrbToModifyItemEUTRAN_SCGFailure_ULPathSwitch(
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, ptCi, &(erab), numErabMod),
                    "VEIL_fillE1_DrbToModifyItemEUTRAN_SCGFailure_ULPathSwitch ERROR!\n");
                break;
            case enBearerCtxtMod_DrbToMod_status::Mr_UlPathSwitch:
            case enBearerCtxtMod_DrbToMod_status::E1_UlPathSwitch:
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_DrbToModifyItemEUTRAN_ULPathSwitch(
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, ptCi, &(erab), numErabMod),
                    "VEIL_fillE1_DrbToModifyItemEUTRAN_ULPathSwitch ERROR!\n");
                break;
            case enBearerCtxtMod_DrbToMod_status::DrbsModificationToRelease:
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_DrbToModifyItemEUTRAN_Release(
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, ptCi, &(erab), numErabMod),
                    "VEIL_fillE1_DrbToModifyItemEUTRAN_Release ERROR -> SgNB Release!\n");
                break;
            case enBearerCtxtMod_DrbToMod_status::IntraDUHandover:
                ptBuf->drbToModifyList[numErabMod].value.dRB_ID = erab.dRBId;
                // Intra-gNB-DU HO STOP, (bit_mask reset and set inside VEIL_fillE1_CellGroupToModifySetTxStatus)
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_CellGroupToModifySetTxStatus(E1_DL_TX_Stop_stop,
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, ptCi, &(erab), numErabMod),
                    "VEIL_fillE1_CellGroupToModifySetTxStatus ERROR!\n");
                // handle SCG to SPLIT change  during HO
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_CellGroupForBearerTypeChange(
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, ptCi, &(erab), numErabMod),
                    "VEIL_fillE1_CellGroupForBearerTypeChange ERROR!\n");
                // During intra/inter-eNB HO, x2uDlInfo can be changed.
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_DrbToModifyItemEUTRAN_X2UDL(
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, &(erab), numErabMod),
                    "VEIL_fillE1_DrbToModifyItemEUTRAN_X2UDL ERROR!\n");
                if (HO_TYPE_MENB_INTERMNHO == ptCi->hoInfo.hoType.initiated)
                {
                    if (AM_RLC == erab.rbInfo.rlcMode)
                    {
                        // request SN status
                        ptBuf->drbToModifyList[numErabMod].value.bit_mask |=
                            E1_DRB_To_Modify_Item_EUTRAN_pDCP_SN_Status_Request_present;
                        ptBuf->drbToModifyList[numErabMod].value.pDCP_SN_Status_Request = E1_requested;
                    }
                }

                fRPSCellChangeType = VCCM_CheckFR1FR2HO(ptCi);
                if ((FR1FR2PSCellChange == fRPSCellChangeType) || (FR2FR1PSCellChange == fRPSCellChangeType) ||
                    (HO_TYPE_MENB_INITIATED == ptCi->hoInfo.hoType.initiated) ||
                    (HO_TYPE_MENB_INTERMNHO == ptCi->hoInfo.hoType.initiated))
                {
                    ptBuf->drbToModifyList[numErabMod].value.bit_mask |=
                        E1_DRB_To_Modify_Item_EUTRAN_pDCP_Configuration_present;
                    VCCB_RETURN_ON_CALL_ERROR(ptCi,
                        VEIL_fillE1_EUTRAN_PDCP_ConfigurationInfo(
                            &ptBuf->drbToModifyList[numErabMod].value.pDCP_Configuration, ptCi, &(erab)),
                        "VEIL_fillE1_EUTRAN_PDCP_ConfigurationInfo ERROR!\n");
                }
                break;
            case enBearerCtxtMod_DrbToMod_status::ERABReleaseTxStop:
                ptBuf->drbToModifyList[numErabMod].value.dRB_ID = erab.dRBId;
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_CellGroupToModifySetTxStatus(E1_DL_TX_Stop_stop,
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, ptCi, &(erab), numErabMod),
                    "VEIL_fillE1_CellGroupToModifySetTxStatus ERROR!\n");
                if (AM_RLC == erab.rbInfo.rlcMode)
                {
                    ptBuf->drbToModifyList[numErabMod].value.bit_mask |=
                        E1_DRB_To_Modify_Item_EUTRAN_pDCP_SN_Status_Request_present;
                    ptBuf->drbToModifyList[numErabMod].value.pDCP_SN_Status_Request = E1_requested;
                }
                break;
            case enBearerCtxtMod_DrbToMod_status::InterDUHandover:
                if ((ERAB_Setup != erab.erabStatus) &&
                    !(MCG_Bearer == erab.preveBearerType && SPLIT_Bearer == erab.bearerType))
                {
                    // Inter-gNB-DU HO STOP (bit_mask reset and set inside VEIL_fillE1_CellGroupToModifySetTxStatus)
                    VCCB_RETURN_ON_CALL_ERROR(ptCi,
                        VEIL_fillE1_CellGroupToModifySetTxStatus(E1_DL_TX_Stop_stop,
                            &ptBuf->drbToModifyList[numErabMod].value, ptBuf, ptCi, &(erab), numErabMod),
                        "VEIL_fillE1_CellGroupToModifySetTxStatus ERROR!\n");
                }
                // handle bearer type change during HO
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_CellGroupForBearerTypeChange(
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, ptCi, &(erab), numErabMod),
                    "VEIL_fillE1_CellGroupForBearerTypeChange ERROR!\n");
                // During intra/inter-eNB HO, x2uDlInfo can be changed.
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_DrbToModifyItemEUTRAN_F1UDLX2UDL(
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, &(erab), numErabMod),
                    "VEIL_fillE1_DrbToModifyItemEUTRAN_F1UDLX2UDL ERROR!\n");
                if (HO_TYPE_MENB_INTERMNHO == ptCi->hoInfo.hoType.initiated)
                {
                    if (AM_RLC == erab.rbInfo.rlcMode)
                    {
                        // request SN status
                        ptBuf->drbToModifyList[numErabMod].value.bit_mask |=
                            E1_DRB_To_Modify_Item_EUTRAN_pDCP_SN_Status_Request_present;
                        ptBuf->drbToModifyList[numErabMod].value.pDCP_SN_Status_Request = E1_requested;
                    }
                }

                fRPSCellChangeType = VCCM_CheckFR1FR2HO(ptCi);
                if ((FR1FR2PSCellChange == fRPSCellChangeType) || (FR2FR1PSCellChange == fRPSCellChangeType) ||
                    (HO_TYPE_MENB_INITIATED == ptCi->hoInfo.hoType.initiated) ||
                    (HO_TYPE_MENB_INTERMNHO == ptCi->hoInfo.hoType.initiated))
                {
                    ptBuf->drbToModifyList[numErabMod].value.bit_mask |=
                        E1_DRB_To_Modify_Item_EUTRAN_pDCP_Configuration_present;
                    VCCB_RETURN_ON_CALL_ERROR(ptCi,
                        VEIL_fillE1_EUTRAN_PDCP_ConfigurationInfo(
                            &ptBuf->drbToModifyList[numErabMod].value.pDCP_Configuration, ptCi, &(erab)),
                        "VEIL_fillE1_EUTRAN_PDCP_ConfigurationInfo ERROR!\n");
                }
                break;
            case enBearerCtxtMod_DrbToMod_status::FullConfigIndication:
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_DrbToModifyItemEUTRAN_SnStatus(
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, ptCi, &(erab)),
                    "VEIL_fillE1_DrbToModifyItemEUTRAN_SnStatus ERROR!\n");

                // optional Intra-gNB-DU HO RbList fill -> F1U DL + TEID
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_DrbToModifyItemEUTRAN_F1UDL(
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, &(erab), numErabMod),
                    "VEIL_fillE1_DrbToModifyItemEUTRAN_F1UDL ERROR!\n");
                break;
            case enBearerCtxtMod_DrbToMod_status::HandoverResume:
                // HO RESUME
                if ((ERAB_Release != erab.erabStatus) && (ERAB_Setup != erab.prevErabStatus) &&
                    (ERAB_Setup != erab.erabStatus))
                {
                    VCCB_RETURN_ON_CALL_ERROR(ptCi,
                        VEIL_fillE1_CellGroupToModifySetTxStatus(E1_DL_TX_Stop_resume,
                            &ptBuf->drbToModifyList[numErabMod].value, ptBuf, ptCi, &(erab), numErabMod),
                        "VEIL_fillE1_CellGroupToModifySetTxStatus ERROR!\n");
                }

                if ((HO_TYPE_MENB_INTERMNHO == ptCi->hoInfo.hoType.initiated) &&
                    (FLAG_ON == erab.snStatus.needSendFlag) && (AM_RLC == erab.rbInfo.rlcMode))
                {
                    // PDCP SN Status Information Fill - optional
                    ptBuf->drbToModifyList[numErabMod].value.bit_mask |=
                        E1_DRB_To_Modify_Item_EUTRAN_pDCP_SN_Status_Information_present;
                    ptBuf->drbToModifyList[numErabMod].value.pDCP_SN_Status_Information.bit_mask = 0;
                    ptBuf->drbToModifyList[numErabMod].value.pDCP_SN_Status_Information.pdcpStatusTransfer_UL.bit_mask =
                        0;
                    ptBuf->drbToModifyList[numErabMod]
                        .value.pDCP_SN_Status_Information.pdcpStatusTransfer_UL.countValue.bit_mask = 0;
                    ptBuf->drbToModifyList[numErabMod]
                        .value.pDCP_SN_Status_Information.pdcpStatusTransfer_UL.countValue.pDCP_SN = erab.snStatus.ulSN;
                    ptBuf->drbToModifyList[numErabMod]
                        .value.pDCP_SN_Status_Information.pdcpStatusTransfer_UL.countValue.hFN = erab.snStatus.ulHFN;

                    ptBuf->drbToModifyList[numErabMod].value.pDCP_SN_Status_Information.pdcpStatusTransfer_DL.bit_mask =
                        0;
                    ptBuf->drbToModifyList[numErabMod].value.pDCP_SN_Status_Information.pdcpStatusTransfer_DL.pDCP_SN =
                        erab.snStatus.dlSN;
                    ptBuf->drbToModifyList[numErabMod].value.pDCP_SN_Status_Information.pdcpStatusTransfer_DL.hFN =
                        erab.snStatus.dlHFN;
                }
                // optional Intra-gNB-DU HO RbList fill -> F1U DL + TEID and x2uDlInfo can be changed.
                if (ERAB_Release != erab.erabStatus)
                {
                    VCCB_RETURN_ON_CALL_ERROR(ptCi,
                        VEIL_fillE1_DrbToModifyItemEUTRAN_F1UDLX2UDL(
                            &ptBuf->drbToModifyList[numErabMod].value, ptBuf, &(erab), numErabMod),
                        "VEIL_fillE1_DrbToModifyItemEUTRAN_F1UDLX2UDL ERROR!\n");
                }

                {
                    // new user inactivity value from Suspend to Resume
                    VCCB_RETURN_ON_CALL_ERROR(ptCi,
                        VEIL_fillE1_DrbToModifyItem_drbInactivityTimer(
                            &ptBuf->drbToModifyList[numErabMod].value, ptBuf, &(erab), ptCi),
                        "VEIL_fillE1_DrbToModifyItem_drbInactivityTimer ERROR!\n");
                }

                break;
            case enBearerCtxtMod_DrbToMod_status::SgNBAdditionAfterX2SNStatusTransfer:
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_DrbToModifyItemEUTRAN_SnStatus(
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, ptCi, &(erab)),
                    "VEIL_fillE1_DrbToModifyItemEUTRAN_SnStatus ERROR!\n");
                break;
            case enBearerCtxtMod_DrbToMod_status::DlInfoNeedModifyAfterF1UECtxtSetupResp:
                ptBuf->drbToModifyList[numErabMod].value.bit_mask = 0;
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_DrbToModifyItemEUTRAN_Add(
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, ptCi, &(erab), numErabMod),
                    "VEIL_fillE1_DrbToModifyItemEUTRAN_Add ERROR!\n");
                break;
            case enBearerCtxtMod_DrbToMod_status::ChangeTypeScgToSplit:
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_DrbToModifyItemScgMcgToSplit(
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, &(erab), numErabMod, ptCi, CellGroupId_SCG),
                    "VEIL_fillE1_DrbToModifyItemScgMcgToSplit ERROR!\n");
                break;
            case enBearerCtxtMod_DrbToMod_status::ChangeTypeSplitToScg:
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_DrbToModifyItemSplitToScgMcg(
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, &(erab), numErabMod, ptCi, CellGroupId_SCG),
                    "VEIL_fillE1_DrbToModifyItemSplitToScgMcg ERROR!\n");
                break;
            case enBearerCtxtMod_DrbToMod_status::ChangeTypeMcgToSplit:
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_DrbToModifyItemScgMcgToSplit(
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, &(erab), numErabMod, ptCi, CellGroupId_MCG),
                    "VEIL_fillE1_DrbToModifyItemScgMcgToSplit ERROR!\n");
                break;
            case enBearerCtxtMod_DrbToMod_status::ChangeTypeSplitToMcg:
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_DrbToModifyItemSplitToScgMcg(
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, &(erab), numErabMod, ptCi, CellGroupId_MCG),
                    "VEIL_fillE1_DrbToModifyItemSplitToScgMcg ERROR!\n");
                break;
            case enBearerCtxtMod_DrbToMod_status::ChangeTypeSplitToMcgConfirmed:
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_CellGroupToModifySetTxStatus(E1_DL_TX_Stop_resume,
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, ptCi, &(erab), numErabMod),
                    "VEIL_fillE1_CellGroupToModifySetTxStatus ERROR!\n");
                break;
            case enBearerCtxtMod_DrbToMod_status::E1ModificationResume:
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_DrbToModifyItemCellGroupResume(
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, &(erab), numErabMod, ptCi),
                    "VEIL_fillE1_DrbToModifyItemCellGroupResume ERROR!\n");
                break;
            case enBearerCtxtMod_DrbToMod_status::DesiredActivityNotification:
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_DrbToModifyItemEUTRAN_DesiredActivityNotification(
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, ptCi, &(erab)),
                    "VEIL_fillE1_DrbToModifyItemEUTRAN_DesiredActivityNotification ERROR!\n");
                break;
            case enBearerCtxtMod_DrbToMod_status::S1UTunnelUpdate:
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_DrbToModifyItemS1UTunnel(&ptBuf->drbToModifyList[numErabMod].value, &(erab), ptCi),
                    "VEIL_fillE1_DrbToModifyItemS1UTunnel ERROR!\n");
                break;
            case enBearerCtxtMod_DrbToMod_status::EndcHandoverRollback:
                // DL Tx Stop Resume & Old UL Configuration (for UL Path Switch case) set in
                // VEIL_fillE1_CellGroupToModifySetTxStatus
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_CellGroupToModifySetTxStatus(E1_DL_TX_Stop_resume,
                        &ptBuf->drbToModifyList[numErabMod].value, ptBuf, ptCi, &(erab), numErabMod),
                    "VEIL_fillE1_CellGroupToModifySetTxStatus ERROR!\n");
                // send Old DL tunnel to UP & set dRBId
                VCCB_RETURN_ON_CALL_ERROR(ptCi,
                    VEIL_fillE1_DrbToModifyItemEUTRAN_OldDlTunnel(
                        ptCi, &ptBuf->drbToModifyList[numErabMod].value, ptBuf, &(erab), numErabMod),
                    "VEIL_fillE1_DrbToModifyItemEUTRAN_OldDlTunnel ERROR!\n");
                break;
            case enBearerCtxtMod_DrbToMod_status::TrafficMonitoring:
            case enBearerCtxtMod_DrbToMod_status::QosMod:
                break;
            case enBearerCtxtMod_DrbToMod_status::Unknown:
            default:
                VCCB_PRINT_DATA(
                    "VEIL_fillE1_BearerContextMod_DrbToBeList case for DRB id(%d) was not considered \n", erab.dRBId);
                continue;
        }

        // E-UTRAN QoS Fill
        if (VCCB_FLAG_ON == erab.qosModFlag)
        {
            // DRB ID Fill - mandatory
            ptBuf->drbToModifyList[numErabMod].value.dRB_ID = erab.dRBId;

            if (GOOD == VEIL_fillE1_EUTRAN_QoS(&ptBuf->drbToModifyList[numErabMod].value.eUTRAN_QoS, &erab))
            {
                ptBuf->drbToModifyList[numErabMod].value.bit_mask |= E1_eUTRAN_QoS_present;
            }
            else
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VEIL_fillE1_EUTRAN_QoS ERROR!\n");
            }
            erab.qosModFlag = VCCB_FLAG_OFF;
        }

        int status = VEIL_fillE1_DrbToModifyItemEUTRAN_DlTrafficStatusReport(
            ptCi, &ptBuf->drbToModifyList[numErabMod].value, ptBuf, &(erab), numErabMod);
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VEIL_fillE1_DrbToModifyItemEUTRAN_DlTrafficStatusReport ERROR!\n");
        }

        ++numErabMod;
        ON_DRB_E1_MODIFY_FLAG(erab.flag.respFlag);
    }

    *ptNumErabAdd = numErabAdd;
    *ptNumErabMod = static_cast<uint32_t>(numErabMod);
    *ptNumErabRem = numErabRem;

    return GOOD;
}

int FnVCCB_Check_New_UL_TNL_Information_Required_IntraRatHo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    // 1) Check Allowed State
    switch (ptCi->state)
    {
        /* NSA */
        case STATE_DB:
        case STATE_DCInterDuHo_F1UeCtxSetReq:
            break;

        /* SA */
        case STATE_INTER_DU_Prepare:  // Inter DU Handover
        case STATE_INTRA_DU_E1Stop:   // Intra DU Handover
            break;

        case STATE_SN_INTRA_DU_E1Stop:  // For Key Change procedure
        case STATE_SN_INTER_DU_E1Stop:
            break;

        default:
            // 1-1) Not Allowed State, It is not required New TNL IE.
            return FALSE;
    }

    // 2) If Full Configuration is TRUE, New TNL IE is required.
    if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi)) return TRUE;

    // 3) If Full Configuration is TRUE, New TNL IE is required.
    if (VCCB_FLAG_ON == ptCi->ueInfo.securityModFlag) return TRUE;

    // FGR-CC5001: W/A for inter-DU HO without source DU.
    // Request new UL tunnel info so it is forwared to new DU context and MN.
    if (VCCB_NSA_IsInterDuNoScgHo(*ptCi))
    {
        return TRUE;
    }

    // 4) It is not required New TNL IE.
    return FALSE;
}

int VEIL_Check_New_UL_TNL_Information_Required(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    switch (ptCi->stateCmd)
    {
        case IntraRatHO_cmd:
            return FnVCCB_Check_New_UL_TNL_Information_Required_IntraRatHo(ptCi);

        default:
            break;
    }

    if (E_CALLTYPE_NSA == ptCi->callType) return FALSE;

    if ((RrcReestablish_cmd == ptCi->stateCmd) &&
        ((RRE_TYPE_INTRA_DU == ptCi->ueInfo.reestablishInfo.reestablishType) ||
            (RRE_TYPE_INTER_DU == ptCi->ueInfo.reestablishInfo.reestablishType)))  // Intra/Inter DU RRE
    {
        switch (ptCi->state)
        {
            case STATE_RRE_Ready:
                return TRUE;

            default:
                return FALSE;
        }
    }

    if ((IntraCellHO_cmd == ptCi->stateCmd) && (VCCB_FLAG_ON == ptCi->ueInfo.securityModFlag) &&
        (VCCB_FLAG_OFF == ptCi->ueInfo.snKeyChangeWOMnKeyChange))
    {
        return TRUE;
    }

    return FALSE;
}

/**
 * @brief Util BitMask structure to mark Optional IEs presence
 *        in BearerContextModificationRequest message
 */
typedef union
{
    struct
    {
        uint16_t securityInformation         : 1;  // E1_id_SecurityInformation
        uint16_t ueDlAmbr                    : 1;  // E1_id_UEDLAggregateMaximumBitRate
        uint16_t newUlTnlInformationRequired : 1;  // E1_id_New_UL_TNL_Information_Required
        uint16_t bearerContextStatusChange   : 1;  // E1_id_BearerContextStatusChange
        uint16_t ueInactivityTimer           : 1;  // E1_id_UE_Inactivity_Timer
    };
    uint16_t flag;
} BearerContextModificationRequest_IE_bitmask_type;

/**
 * @breif Util function to Check which optional IEs shall be included in BearerContextModificationReques
 * return BearerContextModificationRequest_IE_bitmask_type bitmask with related optional IEs
 */
BearerContextModificationRequest_IE_bitmask_type CheckOptionalIEsForBearerContextModificationRequest(
    callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    BearerContextModificationRequest_IE_bitmask_type bitmask;
    bitmask.flag = 0;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, bitmask);

    // 1. gNB-CU-CP UE E1AP ID - mandatory
    // 2. gNB-CU-UP UE E1AP ID - mandatory
    // 3. Security Information - optional
    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        if (((STATE_DB == ptCi->state) || (STATE_DCInterDuHo_F1UeCtxSetReq == ptCi->state)) &&
            (VCCB_FLAG_ON == ptCi->ueInfo.securityModFlag))
        {
            bitmask.securityInformation = VCCB_FLAG_ON;
        }
    }
    else  // SA_CALL
    {
        if (((STATE_RRE_Ready == ptCi->state) || (RRCResume_cmd == ptCi->stateCmd)) &&
            (VCCB_FLAG_ON == ptCi->ueInfo.securityModFlag))
        {
            bitmask.securityInformation = VCCB_FLAG_ON;
        }
        if (((STATE_Intra_Cell_E1Stop == ptCi->state) || (STATE_SN_INTRA_DU_E1Stop == ptCi->state) ||
                (STATE_SN_INTER_DU_E1Stop == ptCi->state)) &&
            (VCCB_FLAG_ON == ptCi->ueInfo.securityModFlag))
        {
            if (VCCB_FLAG_ON == ptCi->ueInfo.snKeyChangeWOMnKeyChange)
            {
                if (IS_MRDC_MN(ptCi))
                {
                    bitmask.securityInformation = VCCB_FLAG_OFF;
                }
                else if (IS_MRDC_SN(ptCi))
                {
                    bitmask.securityInformation = VCCB_FLAG_ON;
                }
            }
            else
            {
                bitmask.securityInformation = VCCB_FLAG_ON;
            }
        }
    }
    // 4. UE DL Aggregate Maximum BitRate - optional
    if (FOO.VF_UeAmbrSupport_inGNB == TRUE)
    {
        bitmask.ueDlAmbr = E_CALLTYPE_SA == ptCi->callType || CHECK_MOD_EVENT_WITHOUT_STATECMD(ptCi, ambr);
    }
    // 5. New-UL-TNL-Information-Required (optional)
    bitmask.newUlTnlInformationRequired = TRUE == VEIL_Check_New_UL_TNL_Information_Required(ptCi);
    if (bitmask.newUlTnlInformationRequired)
    {
        if (IS_LOG_TRAFFIC(ptCi))
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[TRAFFIC, TNL]: New TNL Required\n");
        }
    }

    // 6. Bearer Context Status Change (optional)
    switch (ptCi->ueInfo.rrcResumeInfo.resumeType)
    {
        case RESUME_TYPE_INTRA_GNB:
            if (RRCSuspend_cmd == ptCi->stateCmd)
            {
                bitmask.bearerContextStatusChange = VCCB_FLAG_ON;
            }
            else if ((RRCResume_cmd == ptCi->stateCmd) && (STATE_Inact_F1Mod == ptCi->state))
            {
                bitmask.bearerContextStatusChange = VCCB_FLAG_ON;
            }
            break;

        case RESUME_TYPE_INTER_GNB_TARGET:
            if ((RRCSuspend_cmd == ptCi->stateCmd) && (STATE_Inact_T_E1Setup == ptCi->state))
            {
                bitmask.bearerContextStatusChange = VCCB_FLAG_ON;
            }
            else if ((RRCResume_cmd == ptCi->stateCmd) && (STATE_Inact_F1Setup == ptCi->state))
            {
                bitmask.bearerContextStatusChange = VCCB_FLAG_ON;
            }
            break;

        case RESUME_TYPE_INTER_GNB_SOURCE:
            if ((RRCResume_cmd == ptCi->stateCmd) &&
                ((STATE_Inact_Suspend == ptCi->state) || (STATE_Inact_ResumeReq == ptCi->state)))
            {
                bitmask.bearerContextStatusChange = VCCB_FLAG_ON;
            }
            break;

        case RESUME_TYPE_UNKNOWN:
            if (RRCSuspend_cmd == ptCi->stateCmd)
            {
                bitmask.bearerContextStatusChange = VCCB_FLAG_ON;
            }
            break;

        default:
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Invalid resumeType(%d) in %s\n", ptCi->ueInfo.rrcResumeInfo.resumeType, __FUNCTION__);
            break;
    }
    // 7. UE Inactivity Timer (optional)
    // 10. Activity Notification Level - optional
    // 8. Choice System - mandatory
    // DRB-related
    // 9. Csl Stitching Info (optional)
    // Contains: CGI, CRNTI and DU-ID so needs to be included after cell change
    // however during cell change '8. Choice System' IE (DRB-related) will trigger BearerContextModificationRequest
    // anyway
    return bitmask;
}

int16_t VEIL_fillE1_BearerContextMod_ActivityNotifLevel(callInfo_type *ptCi, 
                                                        struct E1_ProtocolIE_Container_ *ieContainers,
                                                        uint8_t maxIeCount,
                                                        E1_ActivityNotificationLevel &activityNotifLevel,
                                                        const enumActivityNotifLvl_type selectedLevel,
                                                        unsigned int &ieCnt)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ieContainers);

    if (IS_SUPPORT_RRC_INACTIVE(ptCi))
    {
        activityNotifLevel =
            IS_REDCAP_UE(ptCi) ? 
            FnVCCB_FillActivityNotificationLevel(ptCi->ueInfo.RrcInactiveInfo.redCapActivityNotificationLevel):
            FnVCCB_FillActivityNotificationLevel(ptCi->ueInfo.RrcInactiveInfo.activityNotificationLevel);

        if(ieCnt < maxIeCount)
        {
            InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_ActivityNotificationLevel, E1_ignore,
                    &activityNotifLevel, E1_ActivityNotificationLevel_PDU);
        }
    }
    else
    {
        if (selectedLevel == activityNotifLvl_UE)
        {
            activityNotifLevel = FnVCCB_FillActivityNotificationLevel(activityNotifLvl_UE);
            if(ieCnt < maxIeCount)
            {
                InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_ActivityNotificationLevel, E1_ignore,
                        &activityNotifLevel, E1_ActivityNotificationLevel_PDU);
            }
        }
        else if (selectedLevel == activityNotifLvl_DRB)
        {
            activityNotifLevel = FnVCCB_FillActivityNotificationLevel(activityNotifLvl_DRB);
            if(ieCnt < maxIeCount)
            {
                InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_ActivityNotificationLevel, E1_ignore,
                        &activityNotifLevel, E1_ActivityNotificationLevel_PDU);
            }
        }
    }
    return GOOD;
}
 
 
int16_t VEIL_fillE1_BearerContextMod_GnbDuId(callInfo_type *ptCi, 
                                             struct E1_ProtocolIE_Container_ *ieContainers,
                                             uint8_t maxIeCount,
                                             E1_GNB_DU_ID &gnbDuId,
                                             unsigned int &ieCnt)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ieContainers);
        
    if (GET_F1_RESOURCE_FLAG(ptCi->flag.setupFlag))
    {
        // Intra-Gnb cell change
        if ( // NSA states
            (STATE_DCInterDuHo_RRCRecCmpl == ptCi->state) || (STATE_DCInterDuHo_X2RecCmpl == ptCi->state) ||
            (STATE_DCInterDuHo_X2SnStatus == ptCi->state) || (STATE_DCInterDuHo_X2ModCnf == ptCi->state) ||
            // SA states
            (STATE_INTER_DU_Complete == ptCi->state) || (STATE_SN_INTER_DU_Complete == ptCi->state) ||
            (STATE_Ltm_Complete == ptCi->state && true == ptCi->ltmUeInfo.cellSwitchFlag.e1ResumeIsRequired))
        {
            const uint16_t f1Idx = ptCi->hoInfo.targetDu.f1Idx;
            gnbDuId = FnVCCB_GetDuId(ptCi->gnbNum, f1Idx);
        }
        else
        {
            gnbDuId = ptCi->endPointInfo.gnbDuId;
        }

        if(ieCnt < maxIeCount)
        {
            InsertE1_ContainerValue(
                &ieContainers[ieCnt++], E1_id_GNB_DU_ID, E1_ignore, &gnbDuId, E1_GNB_DU_ID_PDU);
        }
    }
    return GOOD;
}
 
 
int16_t VEIL_fillE1_BearerContextMod_BearerContextStatusChange(callInfo_type *ptCi,
                                                               struct E1_ProtocolIE_Container_ *ieContainers,
                                                               uint8_t maxIeCount,
                                                               E1_BearerContextStatusChange &bearerContextStatusChange,
                                                               unsigned int &ieCnt, 
                                                               const uint16_t srvUpIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ieContainers);
    VCCB_CHECK_E_RANGE_AND_RETURN(srvUpIdx, MAX_CU_UP_PER_CALL);
 
    bearerContextStatusChange =
        (RRCSuspend_cmd == ptCi->stateCmd) ? E1_suspend : E1_BearerContextStatusChange_resume;

    if (ieCnt < maxIeCount)
    {
        InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_BearerContextStatusChange, E1_reject,
            &bearerContextStatusChange, E1_BearerContextStatusChange_PDU);
    }

    if (IS_RRC_INACTIVE_UE_LEVEL(ptCi))
    {
        RscCall::setUeActivityStatusPerUP(*ptCi, srvUpIdx, ActivityStatus_ACTIVE);
    }
    else if (IS_RRC_INACTIVE_DRB_LEVEL(ptCi))
    {
        for (auto &drb : ptCi->drb)
        {
            if (drb.usage != CI_use) continue;
            if (drb.pduIdxInCall >= MAX_PDU_SESS_PER_CALL) continue;
            const auto pduSession = ptCi->pduSess[drb.pduIdxInCall];
            if (pduSession.usage != CI_use) continue;
            if (pduSession.e1Idx != ptCi->endPointInfo.aupf[srvUpIdx].e1Idx) continue;
    
            drb.activityStatus = ActivityStatus_ACTIVE;
        }
    }
    return GOOD;
}
 
int16_t VEIL_fillE1_BearerContextMod_UEInactivityTimer(callInfo_type *ptCi,
                                                       struct E1_ProtocolIE_Container_ *ieContainers,
                                                       uint8_t maxIeCount,
                                                       E1_Inactivity_Timer &ueInactivityTimer,
                                                       const enumActivityNotifLvl_type selectedLevel,
                                                       unsigned int &ieCnt)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi); 
    VALID_E_POINT_CHECK_ERROR(ieContainers);
 
    int16_t status = GOOD;
 
    if (IS_SUPPORT_RRC_INACTIVE(ptCi))
    {
        if (IS_RRC_INACTIVE_UE_LEVEL(ptCi))
        {
            const auto &call = *ptCi;
            ueInactivityTimer = static_cast<E1_Inactivity_Timer>(FnVCCB_GetRRCInactiveTimerValue(call, MAX_5QI_VALUE));
            VCCB_RETURN_ON_CALL_ERROR(ptCi, ueInactivityTimer, "FnVCCB_GetRRCInactiveTimerValue ERROR!\n");

            if (ieCnt < maxIeCount)
            {
                InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_UE_Inactivity_Timer, E1_reject,
                        &ueInactivityTimer, E1_Inactivity_Timer_PDU);
            }
        }
    }
    else
    {
        if (selectedLevel == activityNotifLvl_UE)
        {
            status = static_cast<int16_t>(FnVCCB_FillUeInactivityTimerValue(ptCi, &ueInactivityTimer));
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_FillUeInactivityTimerValue ERROR!\n");

            if (ieCnt < maxIeCount)
            {
                InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_UE_Inactivity_Timer, E1_reject,
                        &ueInactivityTimer, E1_Inactivity_Timer_PDU);
            }
        }
    }
    return status;
}

/**
 * @brief       Make Elementary Procedure E1 Bearer Context Modification Request message
 * @details     fill all necessary fields and pack into ASN structure
 * @attention function sets all bit_mask
 * @param [in]  ptCi    : callInfo DB
 * @param [in]  ptSctp  : SctpDataReq_type buffer
 * @param [in]  srvUpIdx: index of serving AUPF
 * @return      GOOD    : success fill
 * @return      ERROR   : fill error
 * @return      BREAK   : Not need to send E1 BearerContextModificationRequest for this serving AUPFs
 */
int VEIL_makeBearerContextModificationRequest(callInfo_type *ptCi, SctpDataTransfer_type *ptSctp, uint16_t srvUpIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptSctp);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(srvUpIdx, MAX_CU_UP_PER_CALL);

    unsigned int ieCnt = 0, sysCnt = 0;
    int16_t status = GOOD;
    BearerContextModificationRequest_IE_bitmask_type optionaIEbitMask =
        CheckOptionalIEsForBearerContextModificationRequest(ptCi);
    E1_BearerContextModificationRequest sendMsg, *ptMsg = &sendMsg;
    E1_BearerContextModificationRequestBuffer *ptModReqBuf =
        &THREAD_INFO->call[ptCi->myThreadId].buf.tx.e1ap.bearerContextModificationRequest;
    E1_SamsungNECGInformationList pE1_SamsungNECGInformationList =
        ptModReqBuf->samsungNeCgInfoBuffer.samsungNECGInformationList;
    E1_SubscriberProfileIDforRFP subscriberProfileIDforRFP = ptCi->ueInfo.rfsp.subscriberProfile;
    E1_SubscriberProfileIDforRFP indexToRFSP = ptCi->ueInfo.rfsp.indexToRFSP;
    E1_SamsungEmergencyBearerIncluded* pE1_SamsungEmergencyBearerIncluded = &ptModReqBuf->samsungEmergencyBearerIncluded;
    E1_SamsungCallInfo& rSamsungCallInfo = ptModReqBuf->samsungCallInfo;

    constexpr size_t MAX_E1_IE_CNT_MOD_REQ = 17;
    struct E1_ProtocolIE_Container_ ieContainers[MAX_E1_IE_CNT_MOD_REQ]
    {
    };
    ptMsg->protocolIEs = ieContainers;

    E1_DRB_To_Setup_Mod_List_EUTRAN drbSetupListBuff = ptModReqBuf->drbToSetupList;
    E1_DRB_To_Modify_List_EUTRAN drbModifyListBuff = ptModReqBuf->drbToModifyList;
    E1_DRB_To_Remove_List_EUTRAN drbRemoveListBuff = ptModReqBuf->drbToRemoveList;
    E1_PDU_Session_Resource_To_Setup_Mod_List pduSessSetupListBuff = ptModReqBuf->pduSessToSetupList;
    E1_PDU_Session_Resource_To_Modify_List pduSessModifyListBuff = ptModReqBuf->pduSessToModifyList;
    E1_PDU_Session_Resource_To_Remove_List pduSessRemoveListBuff = ptModReqBuf->pduSessToRemoveList;
    E1_UESliceMaximumBitRateList ueSliceMBRListBuff = ptModReqBuf->ueSliceMaximumBitRateList;
    E1_BitRate bitRate;

    // 1. gNB-CU-CP UE E1AP ID - mandatory
    ptModReqBuf->gnbCuCpUeE1apId = ptCi->gnbCuUeId;
    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_gNB_CU_CP_UE_E1AP_ID, E1_reject,
        &ptModReqBuf->gnbCuCpUeE1apId, E1_GNB_CU_CP_UE_E1AP_ID_PDU);

    // 2. gNB-CU-UP UE E1AP ID - mandatory
    ptModReqBuf->gnbCuUpUeE1apId = ptCi->upCallId[srvUpIdx];
    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_gNB_CU_UP_UE_E1AP_ID, E1_reject,
        &ptModReqBuf->gnbCuUpUeE1apId, E1_GNB_CU_UP_UE_E1AP_ID_PDU);

    // FGR-CC1105 Bearer Context Management via E1
    // FR930 : Aupf Audit case. Send only mandatory IEs
    if (STATE_AupfAudit_E1Mod == ptCi->state)
    {
        //  Connect list and pack msg
        status = VCCB_ConnectLinkedList(ieContainers, static_cast<int>(ieCnt));
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_ConnectLinkedList failed -> ieContainers!!\n");

        long packLength = sizeof(ptSctp->data);
        status = PackE1_AllMsg(ptMsg, E1_BearerContextModificationRequest_id, ptSctp->data, &packLength);
        VCCB_ASN_RETURN_ON_CALL_ERROR(ptCi, status, "PackE1_AllMsg(E1_BearerContextModificationRequest_id) ERROR!!\n");

        ptSctp->length = static_cast<uint32_t>(packLength);

        return GOOD;
    }

    // 3. Security Information - optional
    if (optionaIEbitMask.securityInformation)
    {
        VCCB_RETURN_ON_CALL_ERROR(ptCi, VEIL_fillE1_SecurityInformation(ptCi, &ptModReqBuf->securityInformation),
            "VEIL_fillE1_SecurityInformation ERROR!\n");
        InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_SecurityInformation, E1_reject,
            &ptModReqBuf->securityInformation, E1_SecurityInformation_PDU);
    }

    // 4. UE DL Aggregate Maximum BitRate - optional
    if (optionaIEbitMask.ueDlAmbr)
    {
        status = VEIL_FillE1_id_UEDLAggregateMaximumBitRate(ptCi, ptSctp->endPointIdx, __FUNCTION__, TRUE, ieContainers,
            GET_ARR_SIZE(ieContainers), &ieCnt, ptModReqBuf);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_FillE1_id_UEDLAggregateMaximumBitRate ERROR!\n");
    }

    // 4. UEDLMaximumIntegrityProtectedDataRate (optional)
    if (VEIL_checkE1_UEDLMaximumProtectedDataRate_Existence(ptCi, bitRate) == TRUE)
    {
        status = VEIL_FillE1_id_UEDLMaximumIntegrityProtectedDataRate(
            ptCi, __FUNCTION__, bitRate, ieContainers, GET_ARR_SIZE(ieContainers), &ieCnt, ptModReqBuf);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_FillE1_id_UEDLMaximumIntegrityProtectedDataRate ERROR!\n");
    }

    // 5. New-UL-TNL-Information-Required (optional)
    if (optionaIEbitMask.newUlTnlInformationRequired)
    {
        ptCi->hoInfo.newUlTnlInfoRequired = TRUE;
        ptModReqBuf->newUlTnlInformationRequired = E1_New_UL_TNL_Information_Required_required;
        InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_New_UL_TNL_Information_Required, E1_reject,
            &ptModReqBuf->newUlTnlInformationRequired, E1_New_UL_TNL_Information_Required_PDU);
    }

    // 6. Bearer Context Status Change (optional)
    if (optionaIEbitMask.bearerContextStatusChange)
    {
        VCCB_RETURN_ON_CALL_ERROR(ptCi, 
            VEIL_fillE1_BearerContextMod_BearerContextStatusChange(
                ptCi, ieContainers, GET_ARR_SIZE(ieContainers), ptModReqBuf->bearerContextStatusChange, ieCnt, srvUpIdx), 
            "VEIL_fillE1_BearerContextMod_BearerContextStatusChange ERROR!\n");
    }

    // 7. UE Inactivity Timer (optional)
    const enumActivityNotifLvl_type selectedLevel = FnVCCB_Get_UserInactivity_NotiLevel(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, 
        VEIL_fillE1_BearerContextMod_UEInactivityTimer(
            ptCi, ieContainers, GET_ARR_SIZE(ieContainers), ptModReqBuf->ueInactivityTimer, selectedLevel, ieCnt), 
        "VEIL_fillE1_BearerContextMod_UEInactivityTimer ERROR!\n");

    // 8. Choice System - mandatory
    struct E1_ProtocolIE_Container_ choiceSystemContainer[5]{};
    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        unsigned int numErabAdd = 0, numErabMod = 0, numErabRem = 0;
        ptModReqBuf->choiceSystem.choice = E1_e_UTRAN_BearerContextModificationRequest_chosen;
        ptModReqBuf->choiceSystem.u.e_UTRAN_BearerContextModificationRequest = choiceSystemContainer;

        VCCB_RETURN_ON_CALL_ERROR(ptCi,
            VEIL_fillE1_BearerContextMod_DrbToBeList(
                ptCi, ptModReqBuf, srvUpIdx, &numErabAdd, &numErabMod, &numErabRem),
            "VEIL_fillE1_BearerContextMod_DrbToBeList ERROR !!\n");
        // DRB To Setup List
        if (numErabAdd)
        {
            // Connect DRB To Setup List
            VCCB_RETURN_ON_CALL_ERROR(ptCi, VCCB_ConnectLinkedList(ptModReqBuf->drbToSetupList, static_cast<int>(numErabAdd)),
                "ERROR: VCCB_ConnectLinkedList failed -> DRB To Setup List!!\n");

            InsertE1_ContainerValue(&choiceSystemContainer[sysCnt++], E1_id_DRB_To_Setup_Mod_List_EUTRAN, E1_reject,
                &drbSetupListBuff, E1_DRB_To_Setup_Mod_List_EUTRAN_PDU);
        }
        // DRB To Modify List
        if (numErabMod)
        {
            // Connect DRB To Modify List
            VCCB_RETURN_ON_CALL_ERROR(ptCi, VCCB_ConnectLinkedList(ptModReqBuf->drbToModifyList, static_cast<int>(numErabMod)),
                "ERROR: VCCB_ConnectLinkedList failed -> DRB To Modify List!!\n");

            InsertE1_ContainerValue(&choiceSystemContainer[sysCnt++], E1_id_DRB_To_Modify_List_EUTRAN, E1_reject,
                &drbModifyListBuff, E1_DRB_To_Modify_List_EUTRAN_PDU);
        }
        // DRB To Remove List
        if (numErabRem)
        {
            // Connect DRB To Remove List
            VCCB_RETURN_ON_CALL_ERROR(ptCi, VCCB_ConnectLinkedList(ptModReqBuf->drbToRemoveList, static_cast<int>(numErabRem)),
                "ERROR: VCCB_ConnectLinkedList failed -> DRB To Remove List!!\n");

            InsertE1_ContainerValue(&choiceSystemContainer[sysCnt++], E1_id_DRB_To_Remove_List_EUTRAN, E1_reject,
                &drbRemoveListBuff, E1_DRB_To_Remove_List_EUTRAN_PDU);
        }
        // SPID
        if (OPT_PRESENT == ptCi->ueInfo.rfsp.rfspPresent)
        {
            InsertE1_ContainerValue(&choiceSystemContainer[sysCnt++], E1_id_SubscriberProfileIDforRFP, E1_ignore,
                &subscriberProfileIDforRFP, E1_SubscriberProfileIDforRFP_PDU);
        }

        // When there is no DRB-related information
        // And other common IEs not need to be updated then skip sending BearerContextModificationRequest for this
        // serving AUPF
        if (0 == optionaIEbitMask.flag && 0 == (numErabAdd + numErabMod + numErabRem) &&
            (ptCi->ueInfo.rfsp.rfspChanged == FALSE))
        {
            VCCB_PRINT_CALL_DATA(ptCi, "Skip E1 BearerContextModificationRequest for AUPF:(id:%lu E1Idx:%u)\n",
                ptCi->endPointInfo.aupf[srvUpIdx].aupfId, ptCi->endPointInfo.aupf[srvUpIdx].e1Idx);
            return BREAK;
        }
    }
    else  // SA_CALL
    {
        unsigned int numPduSessAdd = 0, numPduSessMod = 0, numPduSessRem = 0;

        ptModReqBuf->choiceSystem.choice = E1_nG_RAN_BearerContextModificationRequest_chosen;
        ptModReqBuf->choiceSystem.u.nG_RAN_BearerContextModificationRequest = choiceSystemContainer;

        VCCB_RETURN_ON_CALL_ERROR(ptCi,
            VEIL_fillE1_BearerContextMod_PDUSessToBeList(
                ptCi, ptModReqBuf, srvUpIdx, &numPduSessAdd, &numPduSessMod, &numPduSessRem),
            "VEIL_fillE1_BearerContextMod_PDUSessToBeList ERROR !!\n");
        if (DBG->flag.logE1)
            VCCB_PRINT_DATA("[E1DBG] ## %s numPduSessAdd:%d numPduSessMod:%d numPduSessRem:%d\n", __func__,
                numPduSessAdd, numPduSessMod, numPduSessRem);
        if (numPduSessAdd)
        {
            // Connect PDU Session Resource To Setup List
            VCCB_RETURN_ON_CALL_ERROR(ptCi, VCCB_ConnectLinkedList(ptModReqBuf->pduSessToSetupList, static_cast<int>(numPduSessAdd)),
                "VCCB_ConnectLinkedList failed in %s-> PDU Session Resource To Setup List!!\n", __func__);

            InsertE1_ContainerValue(&choiceSystemContainer[sysCnt++], E1_id_PDU_Session_Resource_To_Setup_Mod_List,
                E1_reject, &pduSessSetupListBuff, E1_PDU_Session_Resource_To_Setup_Mod_List_PDU);
        }
        if (numPduSessMod)
        {
            // Connect PDU Session Resource To Modify List
            VCCB_RETURN_ON_CALL_ERROR(ptCi, VCCB_ConnectLinkedList(ptModReqBuf->pduSessToModifyList, static_cast<int>(numPduSessMod)),
                "VCCB_ConnectLinkedList failed in %s-> PDU Session Resource To Modify List!!\n", __func__);

            InsertE1_ContainerValue(&choiceSystemContainer[sysCnt++], E1_id_PDU_Session_Resource_To_Modify_List,
                E1_reject, &pduSessModifyListBuff, E1_PDU_Session_Resource_To_Modify_List_PDU);
        }
        if (numPduSessRem)
        {
            // Connect PDU Session Resource To Remove List
            VCCB_RETURN_ON_CALL_ERROR(ptCi, VCCB_ConnectLinkedList(ptModReqBuf->pduSessToRemoveList, static_cast<int>(numPduSessRem)),
                "VCCB_ConnectLinkedList failed in %s-> PDU Session Resource To Remove List!!\n", __func__);

            InsertE1_ContainerValue(&choiceSystemContainer[sysCnt++], E1_id_PDU_Session_Resource_To_Remove_List,
                E1_reject, &pduSessRemoveListBuff, E1_PDU_Session_Resource_To_Remove_List_PDU);
        }

        if (OPT_PRESENT == ptCi->ueInfo.rfsp.rfspPresent)
        {
            InsertE1_ContainerValue(&choiceSystemContainer[sysCnt++], E1_id_SubscriberProfileIDforRFP, E1_ignore,
                &indexToRFSP, E1_SubscriberProfileIDforRFP_PDU);
        }

        // Samsung NR RedCap UE Indication
        if ((TRUE == FOO.VF_BasicCallProcedureforRedCapUE) && IS_REDCAP_UE(ptCi) && (E_CALLTYPE_SA == ptCi->callType))
        {
            ptModReqBuf->samsungNRRedCapUEIndication = E1_SamsungNRRedCapUEIndication_true;
            InsertE1_ContainerValue(&choiceSystemContainer[sysCnt++], E1_id_SamsungNRRedCapUEIndication, E1_ignore,
                &ptModReqBuf->samsungNRRedCapUEIndication, E1_SamsungNRRedCapUEIndication_PDU);
        }
    }

    if (sysCnt)
    {
        VCCB_RETURN_ON_CALL_ERROR(ptCi, VCCB_ConnectLinkedList(choiceSystemContainer, static_cast<int>(sysCnt)),
            "ERROR: VCCB_ConnectLinkedList failed for choice system container!!\n");
        InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_System_BearerContextModificationRequest, E1_reject,
            &ptModReqBuf->choiceSystem, E1_System_BearerContextModificationRequest_PDU);
    }

    // 9. GNB-DU-ID (optional)
    VCCB_RETURN_ON_CALL_ERROR(ptCi, 
        VEIL_fillE1_BearerContextMod_GnbDuId(ptCi, ieContainers, GET_ARR_SIZE(ieContainers), ptModReqBuf->gnbDuId, ieCnt), 
        "VEIL_fillE1_BearerContextMod_GnbDuId ERROR!\n");

    // 10. Activity Notification Level - optional
    VCCB_RETURN_ON_CALL_ERROR(ptCi, 
        VEIL_fillE1_BearerContextMod_ActivityNotifLevel(
            ptCi, ieContainers, GET_ARR_SIZE(ieContainers), ptModReqBuf->activityNotificationLevel, selectedLevel, ieCnt), 
        "VEIL_fillE1_BearerContextMod_ActivityNotifLevel ERROR!\n");

    //RoHC EHC  Reset the Retry Flag
    ptCi->ueInfo.roHCCapability.isRetryDueToUPFailure  = FALSE;
    ptCi->ueInfo.ehcCapability.isEHCRetryDueToUPFailure = FALSE;
    // SAMSUNG SPECIFIC START
    if (TRUE == FOO.VF_CallSummaryLogs_IncludingDataForStitching || TRUE == FOO.VF_CallSummaryLogs_SupportStitching)
    {
        // 10. Csl Stitching Info (optional)
        VCCB_RETURN_ON_CALL_ERROR(ptCi,
            VEIL_fillE1_SamsungCslStitchingInfo(ptCi, ptModReqBuf->samsungCslStitchingInfoWithBuffer),
            "VEIL_fillE1_SamsungCslStitchingInfo ERROR!\n");

        InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_Samsung_Csl_Stitching_Info, E1_ignore,
            &ptModReqBuf->samsungCslStitchingInfoWithBuffer.samsungCslStitchingInfo, E1_SamsungCslStitchingInfo_PDU);
    }

    // 11. Insert Samsung-NE-CG-Information-List
    // 12. Samsung Carrier Information
    status = VEIL_fillE1_SamsungNECGInformationList(ptCi, &ptModReqBuf->samsungNeCgInfoBuffer,
        &ptModReqBuf->samsungCarrierInformationData.samsungCarrierInformation,
        &ptModReqBuf->samsungCarrierInformationData.Container);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_SamsungNECGInformationList ERROR!\n");

    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_Samsung_NE_CG_Information_List, E1_ignore,
        &pE1_SamsungNECGInformationList, E1_SamsungNECGInformationList_PDU);

    // 14. SamsungEmergency Bearer Included
    // 16. Samsung Call Info
    if (ptCi->callType == E_CALLTYPE_SA)
    {
        *pE1_SamsungEmergencyBearerIncluded = VCCM_CheckEmergencyCall(ptCi) ? E1_included : E1_not_included;
        InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_SamsungEmergencyBearerIncluded, E1_ignore,
            pE1_SamsungEmergencyBearerIncluded, E1_SamsungEmergencyBearerIncluded_PDU);

        
        // only 1st E1 modify indicate call-setup other drb-setup
        ptCi->vomaInfo.e1ModCnt++;
        // send samsungCallInfo if any DRB has started VoMA
        if (ptCi->vomaInfo.includeCallInfo)
        {
            status = VEIL_fillE1_SamsungCallInfo(*ptCi, rSamsungCallInfo);
            if (GOOD == status)
            {
                InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_SamsungCallInfo, E1_ignore,
                        &rSamsungCallInfo, E1_SamsungCallInfo_PDU);
            }
        }
    }
    // SAMSUNG SPECIFIC END

    // 15. UE Slice Maximum Bit Rate List (9_3_1_102)
    if (VCCB_FLAG_ON == ptCi->ueInfo.sliceMbrInfo.isSliceMBRListProvided)
    {
        status = VEIL_FillE1_UESliceMaximumBitRateList(*ptCi, ueSliceMBRListBuff, false);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_FillE1_UESliceMaximumBitRateList ERROR!\n");
        if (GOOD == status)
        {
            InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_UESliceMaximumBitRateList, E1_ignore,
                &ueSliceMBRListBuff, E1_UESliceMaximumBitRateList_PDU);
        }
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(ieCnt, MAX_E1_IE_CNT_MOD_REQ + 1);

    //  Connect list and pack msg
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, VCCB_ConnectLinkedList(ieContainers, static_cast<int>(ieCnt)), "VCCB_ConnectLinkedList failed -> ieContainers!!\n");

    long packLength = sizeof(ptSctp->data);
    VCCB_ASN_RETURN_ON_CALL_ERROR(ptCi,
        PackE1_AllMsg(ptMsg, E1_BearerContextModificationRequest_id, ptSctp->data, &packLength),
        "PackE1_AllMsg(E1_BearerContextModificationRequest_id) ERROR!!\n");
    ptSctp->length = static_cast<uint32_t>(packLength);

    return GOOD;
}

/**
 * @brief       Make Elementary Procedure E1 Bearer Context Release Command message
 * @details     fill all necessary fields and pack into ASN structure
 * @attention   no bit_mask
 * @param [in]  ptCi    : callInfo DB
 * @param [in]  ptSctp  : SctpDataReq_type buffer
 * @param       servingUpIdx: Serving Aupf index
 * @return      GOOD    : success fill
 * @return      ERROR   : fill error
 */
int VEIL_makeBearerContextReleaseCommand(callInfo_type *ptCi, SctpDataTransfer_type *ptSctp, uint16_t servingUpIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptSctp);
    VCCB_CHECK_E_RANGE_AND_RETURN(servingUpIdx, MAX_CU_UP_PER_CALL);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int status = GOOD;
    unsigned int ieCnt = 0;
    E1_BearerContextReleaseCommand sendMsg, *ptMsg = &sendMsg;
    E1_BearerContextReleaseCommandBuffer *ptBearerReleaseCmdBuffer =
        &THREAD_INFO->call[ptCi->myThreadId].buf.tx.e1ap.bearerContextReleaseCommand;

#define MAX_E1_IE_CNT_REL_CMD 4
    struct E1_ProtocolIE_Container_ ieContainers[MAX_E1_IE_CNT_REL_CMD]
    {
    };
    ptMsg->protocolIEs = ieContainers;

    // 1. CU-CP UE E1AP ID - mandatory
    ptBearerReleaseCmdBuffer->cuCpUeId = ptCi->gnbCuUeId;
    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_gNB_CU_CP_UE_E1AP_ID, E1_reject,
        &ptBearerReleaseCmdBuffer->cuCpUeId, E1_GNB_CU_CP_UE_E1AP_ID_PDU);

    // 2. CU-UP UE E1AP ID - mandatory
    ptBearerReleaseCmdBuffer->cuUpUeId = ptCi->upCallId[servingUpIdx];
    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_gNB_CU_UP_UE_E1AP_ID, E1_reject,
        &ptBearerReleaseCmdBuffer->cuUpUeId, E1_GNB_CU_UP_UE_E1AP_ID_PDU);

    // 3. Cause - mandatory
    status = VEIL_fillE1_Cause(ptCi->cause.e1Cause, &ptBearerReleaseCmdBuffer->cause);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_Cause ERROR!\n");

    InsertE1_ContainerValue(
        &ieContainers[ieCnt++], E1_id_Cause, E1_ignore, &ptBearerReleaseCmdBuffer->cause, E1_Cause_PDU);

    // -- SAMSUNG SPECIFIC START
    if (TRUE == FOO.VF_CallSummaryLogs_IncludingDataForStitching || TRUE == FOO.VF_CallSummaryLogs_SupportStitching)
    {
        // 4. Csl Stitching Info (optional)
        VCCB_RETURN_ON_CALL_ERROR(ptCi,
            VEIL_fillE1_SamsungCslStitchingInfo(ptCi, ptBearerReleaseCmdBuffer->samsungCslStitchingInfoWithBuffer),
            "VEIL_fillE1_SamsungCslStitchingInfo ERROR!\n");

        InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_Samsung_Csl_Stitching_Info, E1_ignore,
            &ptBearerReleaseCmdBuffer->samsungCslStitchingInfoWithBuffer.samsungCslStitchingInfo,
            E1_SamsungCslStitchingInfo_PDU);
    }
    // -- SAMSUNG SPECIFIC END

    VCCB_CHECK_E_RANGE_AND_RETURN(ieCnt, MAX_E1_IE_CNT_REL_CMD + 1);
    //  Connect list and pack msg
    if (ERROR == VCCB_ConnectLinkedList(ieContainers, static_cast<int>(ieCnt)))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_ConnectLinkedList failed in VEIL_makeBearerContextReleaseCommand msg!!\n");

        return ERROR;
    }

    long packLength = sizeof(ptSctp->data);
    if (ASN_OK != PackE1_AllMsg(ptMsg, E1_BearerContextReleaseCommand_id, ptSctp->data, &packLength))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "PackE1_AllMsg ERROR in VEIL_makeBearerContextReleaseCommand!!\n");

        return ERROR;
    }
    ptSctp->length = static_cast<uint32_t>(packLength);

#ifdef IPC_TEST
    FnVCCB_Check_BearerContextReleaseCommand(*ptCi, servingUpIdx);
#endif

    return GOOD;
}

/**
 * @brief       Make Elementary Procedure E1 Bearer Context Modification Confirm message
 * @details     fill all necessary fields and pack into ASN structure
 * @attention function sets all bit_mask
 * @param [in]  ptCi    : callInfo DB
 * @param [in]  ptSctp  : SctpDataReq_type buffer
 * @param       servingUpIdx: Serving Aupf index
 * @return      GOOD    : success fill
 * @return      ERROR   : fill error
 */
int VEIL_makeBearerContextModificationConfirm(callInfo_type *ptCi, SctpDataTransfer_type *ptSctp, uint16_t servingUpIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptSctp);
    VCCB_CHECK_E_RANGE_AND_RETURN(servingUpIdx, MAX_CU_UP_PER_CALL);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    unsigned int ieCnt = 0, loop = 0;
    E1_BearerContextModificationConfirm sendMsg, *ptMsg = &sendMsg;
    E1_BearerContextModificationConfirmBuffer *ptBearerModConfirmBuffer =
        &THREAD_INFO->call[ptCi->myThreadId].buf.tx.e1ap.bearerContextModificationConfirm;

#define MAX_E1_IE_CNT_MOD_CFM 3
    struct E1_ProtocolIE_Container_ ieContainers[MAX_E1_IE_CNT_MOD_CFM]
    {
    };
    ptMsg->protocolIEs = ieContainers;

    E1_DRB_Confirm_Modified_List_EUTRAN drbModListBuff = ptBearerModConfirmBuffer->drbModifiedList;
    E1_PDU_Session_Resource_Confirm_Modified_List pduSessModListBuff = ptBearerModConfirmBuffer->pduSessModifiedList;

    // 1. CU-CP UE E1AP ID - mandatory
    ptBearerModConfirmBuffer->cuCpUeId = ptCi->gnbCuUeId;
    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_gNB_CU_CP_UE_E1AP_ID, E1_reject,
        &ptBearerModConfirmBuffer->cuCpUeId, E1_GNB_CU_CP_UE_E1AP_ID_PDU);

    // 2. CU-UP UE E1AP ID - mandatory
    ptBearerModConfirmBuffer->cuUpUeId = ptCi->upCallId[servingUpIdx];
    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_gNB_CU_UP_UE_E1AP_ID, E1_reject,
        &ptBearerModConfirmBuffer->cuUpUeId, E1_GNB_CU_UP_UE_E1AP_ID_PDU);

    // 3. Choice System - optional
    struct E1_ProtocolIE_Container_ choiceSystemContainer;
    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        unsigned int numErab = 0;

        ptBearerModConfirmBuffer->choiceSystem.choice = E1_e_UTRAN_BearerContextModificationConfirm_chosen;
        ptBearerModConfirmBuffer->choiceSystem.u.e_UTRAN_BearerContextModificationConfirm = &choiceSystemContainer;

        InsertE1_ContainerValue(&choiceSystemContainer, E1_id_DRB_Confirm_Modified_List_EUTRAN, E1_ignore,
            &drbModListBuff, E1_DRB_Confirm_Modified_List_EUTRAN_PDU);

        // Fill DRB Modified List
        for (loop = 0; loop < MAX_ERAB_PER_CALL; loop++)
        {
            if ((CI_use != ptCi->erabInfo[loop].usage) ||
                (UlConfigBearer_ModOff == ptCi->erabInfo[loop].ulPdcpPathToMod))
                continue;

            if (ERROR == VEIL_fillE1_DrbModifiedItemEUTRAN(ptCi,
                             &ptBearerModConfirmBuffer->drbModifiedList[numErab].value,
                             &ptBearerModConfirmBuffer->drbModifiedConfirmData[numErab], &(ptCi->erabInfo[loop])))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VEIL_fillE1_DrbModifiedList ERROR!\n");

                return ERROR;
            }
            ++numErab;
        }

        if (numErab)
        {
            // Connect DRB Modified List
            if (ERROR == VCCB_ConnectLinkedList(ptBearerModConfirmBuffer->drbModifiedList, static_cast<int>(numErab)))
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "ERROR: VCCB_ConnectLinkedList failed in "
                    "VEIL_makeBearerContextModificationConfirm-> DRB Modified List!\n");

                return ERROR;
            }
            InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_System_BearerContextModificationConfirm, E1_ignore,
                &ptBearerModConfirmBuffer->choiceSystem, E1_System_BearerContextModificationConfirm_PDU);
        }
    }
    else  // SA_CALL
    {
        if(ptCi->bitFlag.storeAndSendMsgInE1DrbPreemption == VCCB_FLAG_ON)
        {
            // Do not fill PDU Session Resource Modified List. in E1 Preemption Scenario. 
        }
        else
        {
            unsigned int numPduSess = 0;

            ptBearerModConfirmBuffer->choiceSystem.choice = E1_nG_RAN_BearerContextModificationConfirm_chosen;
            ptBearerModConfirmBuffer->choiceSystem.u.nG_RAN_BearerContextModificationConfirm = &choiceSystemContainer;

            InsertE1_ContainerValue(&choiceSystemContainer, E1_id_PDU_Session_Resource_Confirm_Modified_List, E1_ignore,
                &pduSessModListBuff, E1_PDU_Session_Resource_Confirm_Modified_List_PDU);

            // Fill PDU Session Resource Modified List
            for (loop = 0; loop < MAX_PDU_SESS_PER_CALL; loop++)
            {
                if (CI_use != ptCi->pduSess[loop].usage) continue;
                VCCB_PRINT_CALL_DATA(ptCi, "[E1DBG] ptCi->pduSess[%d].usage is CI_use\n", loop);

                if (ERROR == VEIL_fillE1_PDUSessModifiedItem(ptCi,
                                &ptBearerModConfirmBuffer->pduSessModifiedList[numPduSess].value,
                                &ptBearerModConfirmBuffer->pduSessModifiedConfirmData[numPduSess], &(ptCi->pduSess[loop])))
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "VEIL_fillE1_PDUSessModifiedItem ERROR!\n");

                    return ERROR;
                }
                ++numPduSess;
            }

            if (numPduSess)
            {
                // Connect PDU Session Resource Modified List
                if (ERROR == VCCB_ConnectLinkedList(ptBearerModConfirmBuffer->pduSessModifiedList, static_cast<int>(numPduSess)))
                {
                    VCCB_PRINT_CALL_ERROR(ptCi,
                        "ERROR: VCCB_ConnectLinkedList failed in %s-> PDU Session Resource Modified List!\n", __func__);

                    return ERROR;
                }
                InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_System_BearerContextModificationConfirm, E1_ignore,
                    &ptBearerModConfirmBuffer->choiceSystem, E1_System_BearerContextModificationConfirm_PDU);
            }
        }
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(ieCnt, MAX_E1_IE_CNT_MOD_CFM + 1);
    //  Connect list and pack msg
    if (ERROR == VCCB_ConnectLinkedList(ieContainers, static_cast<int>(ieCnt)))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "VCCB_ConnectLinkedList failed in VEIL_makeBearerContextModificationConfirm msg!!\n");

        return ERROR;
    }

    long packLength = sizeof(ptSctp->data);
    if (ASN_OK != PackE1_AllMsg(ptMsg, E1_BearerContextModificationConfirm_id, ptSctp->data, &packLength))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "PackE1_AllMsg ERROR in VEIL_makeBearerContextModificationConfirm!!\n");

        return ERROR;
    }
    ptSctp->length = static_cast<uint32_t>(packLength);

    return GOOD;
}

/**
 * @brief       make ErrorIndication message
 * @attention   no bit_mask
 * @param       ptCi        : call info DB
 * @param       pMsg        : ErrorIndication message
 * @param       srvUpIdx    : Serving Aupf index
 * @return      GOOD        : make ErrorIndication message
 */
int VEIL_makeErrorIndication(callInfo_type *ptCi, SctpDataTransfer_type *ptSctp, uint16_t srvUpIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptSctp);
    VCCB_CHECK_E_RANGE_AND_RETURN(srvUpIdx, MAX_CU_UP_PER_CALL);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int status = GOOD;
    unsigned int ieCnt = 0;
    E1_ErrorIndication sendMsg, *ptMsg = &sendMsg;
    E1_ErrorIndicationBuffer *ptErrorIndicationBuffer = &THREAD_INFO->call[ptCi->myThreadId].buf.tx.e1ap.errorIndication;

#define MAX_E1_IE_CNT_ERR_IND 4
    struct E1_ProtocolIE_Container_ ieContainers[MAX_E1_IE_CNT_ERR_IND]
    {
    };
    ptMsg->protocolIEs = ieContainers;

    // 1. Transaction ID
    E1_TransactionID ignoredTransactionId = 0;
    InsertE1_ContainerValue(
        &ieContainers[ieCnt++], E1_id_TransactionID, E1_reject, &ignoredTransactionId, E1_TransactionID_PDU);

    // 2. CU-CP UE E1AP ID - optional
    if (UINT32_MAX != ptCi->gnbCuUeId)
    {
        ptErrorIndicationBuffer->cuCpUeId = ptCi->gnbCuUeId;
        InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_gNB_CU_CP_UE_E1AP_ID, E1_ignore,
            &ptErrorIndicationBuffer->cuCpUeId, E1_GNB_CU_CP_UE_E1AP_ID_PDU);
    }
    // 3. CU-UP UE E1AP ID - optional
    if (UINT32_MAX != ptCi->upCallId[srvUpIdx])
    {
        ptErrorIndicationBuffer->cuUpUeId = ptCi->upCallId[srvUpIdx];
        InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_gNB_CU_UP_UE_E1AP_ID, E1_ignore,
            &ptErrorIndicationBuffer->cuUpUeId, E1_GNB_CU_UP_UE_E1AP_ID_PDU);
    }
    // 4. Cause - mandatory
    status = VEIL_fillE1_Cause(ptCi->cause.e1Cause, &ptErrorIndicationBuffer->cause);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_fillE1_Cause ERROR!\n");

    InsertE1_ContainerValue(
        &ieContainers[ieCnt++], E1_id_Cause, E1_ignore, &ptErrorIndicationBuffer->cause, E1_Cause_PDU);

    VCCB_CHECK_E_RANGE_AND_RETURN(ieCnt, MAX_E1_IE_CNT_ERR_IND + 1);
    //  Connect list and pack msg
    if (ERROR == VCCB_ConnectLinkedList(ieContainers, static_cast<int>(ieCnt)))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_ConnectLinkedList failed in VEIL_makeErrorIndication msg!!\n");

        return ERROR;
    }

    long packLength = sizeof(ptSctp->data);
    if (ASN_OK != PackE1_AllMsg(ptMsg, E1_ErrorIndication_id, ptSctp->data, &packLength))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "PackE1_AllMsg ERROR in VEIL_makeErrorIndication!!\n");

        return ERROR;
    }
    ptSctp->length = static_cast<uint32_t>(packLength);

    return GOOD;
}

/* TRACE START REQUEST */
/**
 * @brief       Make E1 TRACE START REQUEST
 * @details     fill all necessary fields and pack into ASN structure
 *
 * @param [in] ptCi
 * @param [in] ptSctp
 * @return GOOD
 * @return ERROR
 */
int16_t VEIL_makeE1_TraceStart(callInfo_type *ptCi, SctpDataTransfer_type *ptSctp, uint16_t srvUpIdx, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    int16_t status;
    uint8_t ieCnt = 0;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptSctp);
    VCCB_CHECK_E_RANGE_AND_RETURN(srvUpIdx, MAX_CU_UP_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    E1_TraceStart sendMsg, *ptMsg = &sendMsg;
    E1_TraceStartBuffer *ptTraceStartBuffer = &THREAD_INFO->call[ptCi->myThreadId].buf.tx.e1ap.traceStartRequest;
    memset(ptTraceStartBuffer, 0, sizeof(E1_TraceStartBuffer));

    struct E1_ProtocolIE_Container_ ieContainers[4];
    memset(ieContainers, 0, sizeof(ieContainers));

    ptMsg->protocolIEs = ieContainers;

    // 1. gNB-CU-CP UE E1AP ID - mandatory
    ptTraceStartBuffer->gnbCuCpUeE1apId = ptCi->gnbCuUeId;
    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_gNB_CU_CP_UE_E1AP_ID, E1_reject,
        &ptTraceStartBuffer->gnbCuCpUeE1apId, E1_GNB_CU_CP_UE_E1AP_ID_PDU);

    // 2. gNB-CU-UP UE E1AP ID - mandatory
    ptTraceStartBuffer->gnbCuUpUeE1apId = ptCi->upCallId[srvUpIdx];
    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_gNB_CU_UP_UE_E1AP_ID, E1_reject,
        &ptTraceStartBuffer->gnbCuUpUeE1apId, E1_GNB_CU_UP_UE_E1AP_ID_PDU);

    // 3. Trace Activation - mandatory (9_3_1_88)
    status = VEIL_fillE1_TraceActivation(ptCi, &ptTraceStartBuffer->traceActivationData,
                                         &ptTraceStartBuffer->traceActivationData.traceActivation, cellNum);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_fillE1_TraceActivation ERROR!\n");

    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_TraceActivation, E1_ignore,
        &ptTraceStartBuffer->traceActivationData.traceActivation, E1_TraceActivation_PDU);

    //  Connect list and pack msg
    status = VCCB_ConnectLinkedList(ieContainers, static_cast<int>(ieCnt));
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_ConnectLinkedList failed in VEIL_makeE1_TraceStart msg!!\n");

    long packLength = sizeof(ptSctp->data);

    if (ASN_OK != PackE1_AllMsg(ptMsg, E1_TraceStart_id, ptSctp->data, &packLength))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "PackE1_AllMsg ERROR !!\n");
        return ERROR;
    }

    ptSctp->length = static_cast<uint32_t>(packLength);

    return GOOD;
}

/* DEACTIVATE TRACE REQUEST */
/**
 * @brief       Make E1 DEACTIVATE TRACE REQUEST
 * @details     fill all necessary fields and pack into ASN structure
 *
 * @param [in] ptCi
 * @param [in] ptSctp
 * @param [in] srvUpIdx : index of serving UP
 * @return GOOD
 * @return ERROR
 */
int16_t VEIL_makeE1_DeactivateTrace(callInfo_type *ptCi, SctpDataTransfer_type *ptSctp, uint16_t srvUpIdx, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    int16_t status;
    uint8_t ieCnt = 0;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptSctp);
    VCCB_CHECK_E_RANGE_AND_RETURN(srvUpIdx, MAX_CU_UP_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    // cellNum used only by Management, no range check needed

    E1_DeactivateTrace sendMsg, *ptMsg = &sendMsg;
    E1_DeactivateTraceBuffer *ptDeactivateTraceBuffer = &THREAD_INFO->call[ptCi->myThreadId].buf.tx.e1ap.deactivateTraceRequest;
    memset(ptDeactivateTraceBuffer, 0, sizeof(E1_DeactivateTraceBuffer));

    struct E1_ProtocolIE_Container_ ieContainers[4];
    memset(ieContainers, 0, sizeof(ieContainers));

    ptMsg->protocolIEs = ieContainers;

    // 1. gNB-CU-CP UE E1AP ID - mandatory
    ptDeactivateTraceBuffer->gnbCuCpUeE1apId = ptCi->gnbCuUeId;
    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_gNB_CU_CP_UE_E1AP_ID, E1_reject,
        &ptDeactivateTraceBuffer->gnbCuCpUeE1apId, E1_GNB_CU_CP_UE_E1AP_ID_PDU);

    // 2. gNB-CU-UP UE E1AP ID - mandatory
    ptDeactivateTraceBuffer->gnbCuUpUeE1apId = ptCi->upCallId[srvUpIdx];
    InsertE1_ContainerValue(&ieContainers[ieCnt++], E1_id_gNB_CU_UP_UE_E1AP_ID, E1_reject,
        &ptDeactivateTraceBuffer->gnbCuUpUeE1apId, E1_GNB_CU_UP_UE_E1AP_ID_PDU);

    // 3. TraceID - mandatory
    status = FillTraceID(ptCi, &ptDeactivateTraceBuffer->traceId, cellNum, NULL);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FillTraceID for E1 ERROR!\n");

    InsertE1_ContainerValue(
        &ieContainers[ieCnt++], E1_id_TraceID, E1_ignore, &ptDeactivateTraceBuffer->traceId, E1_TraceID_PDU);

    //  Connect list and pack msg
    status = VCCB_ConnectLinkedList(ieContainers, static_cast<int>(ieCnt));
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_ConnectLinkedList failed in VEIL_makeE1_DeactivateTrace msg!!\n");

    long packLength = sizeof(ptSctp->data);

    if (ASN_OK != PackE1_AllMsg(ptMsg, E1_DeactivateTrace_id, ptSctp->data, &packLength))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "PackE1_AllMsg ERROR !!\n");
        return ERROR;
    }

    ptSctp->length = static_cast<uint32_t>(packLength);
    
    if (Trace_Signaling == ptCi->traceType)
    {
        ptCi->signalingTraceInfo.traceActivationStatus.E1delivered = false;
    }

    return GOOD;
}

// 9.3.1.65 gNB-DU ID
// 9.3.1.66 Common Network Instance
// 9.3.1.67 Activity Notification Level
E1_ActivityNotificationLevel FnVCCB_FillActivityNotificationLevel(uint8_t level)
{
    if (level == activityNotifLvl_DRB)  // 1
    {
        return E1_drb;  // 0
    }
    else if (level == activityNotifLvl_PDUSession)  // 2
    {
        return E1_pdu_session;  // 1
    }
    else  // 0
    {
        return E1_ActivityNotificationLevel_ue;  // 2
    }
}

/**
 * @brief       checkAndStoreDirectFwdPathAvailableInAllPduSess
 * @details     Check if DirectFwdPathAvailable IE is available in all PduSession in case of incoming
 *              Handover and store this information under ptCi->hoInfo.allPduSessDirectFwdPathAvailable flag.
 *              This function needs to be called before filling IEs in BearerContextSetupRequest message.
 *
 * @param [in] ptCi
 * @param [in] endPointIdx : index of UP 
 */
void FnVCCB_checkAndStoreDirectFwdPathAvailableInAllPduSess(callInfo_type *ptCi, const uint16_t endPointIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(endPointIdx, MAX_CU_UP_PER_CALL);

    if (E_CALLTYPE_SA != ptCi->callType) return;

    for (int loop = 0; loop < MAX_PDU_SESS_PER_CALL; loop++)
    {
        if ((CI_use != ptCi->pduSess[loop].usage) || (endPointIdx != ptCi->pduSess[loop].e1Idx))
        {
            continue;
        }

        if (false == FnVCCB_is_E1_PDUSessToBeSetup(ptCi, &ptCi->pduSess[loop])) continue;

        if (IS_MRDC_MN(ptCi) && (false == FnVCCB_IsAnyMnTermPerPDU(ptCi, &ptCi->pduSess[loop], request_bearerType)))
        {
            continue;
        }
        else if (IS_NRDC_SN(ptCi) && (FALSE == FnVCCB_ExistSNTermBearerInPdu(ptCi, &ptCi->pduSess[loop])))
        {
            continue;
        }

        if(TRUE == ptCi->pduSess[loop].directFwdPathAvailable)
        {
            ptCi->hoInfo.allPduSessDirectFwdPathAvailable = TRUE;
        }
        else
        {
            ptCi->hoInfo.allPduSessDirectFwdPathAvailable = FALSE;
            break;
        }
    }
}

static int16_t FillE1_S_TMSI(callInfo_type& rCi, E1_FiveG_S_TMSI& rSTMSI)
{
    AUTO_TRACE_FUNC;
    uint8_t index = 0;
    int16_t status = ERROR;
    const fiveGTmsi_type *const fTmsi = &rCi.ueInfo.ueId.sTmsi;

    uint8_t *pTmsiPartialBuff = nullptr;
    if (GOOD != VCCB_GlobalAlloc(pTmsiPartialBuff, 3))
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "ERROR: fnGlobalValueAlloc failed in %s\n", __FUNCTION__);
        return ERROR;
    }

    memset(&rSTMSI.fiveG_TMSI, 0x00, sizeof(rSTMSI.fiveG_TMSI));
    memset(pTmsiPartialBuff, 0x00, 3);
    rSTMSI.aMFSetID.value = &pTmsiPartialBuff[0];
    rSTMSI.aMFPointer.value = &pTmsiPartialBuff[2];

    // 5G-S-TMSI = AMF Set ID (10 Bits) + AMF Pointer (6 Bits) + 5G-TMSI (32 bits)
    // aMFSetID
    status = FillE1_BitString(&rSTMSI.aMFSetID, (uint64_t)fTmsi->amfSetPointer >> 6, 10);
    VCCB_RETURN_ON_CALL_ERROR(&rCi, status, "FillE1_BitString ERROR!\n");

    // aMFPointer
    status = FillE1_BitString(&rSTMSI.aMFPointer, (fTmsi->amfSetPointer & 0x3F), 6);
    VCCB_RETURN_ON_CALL_ERROR(&rCi, status, "FillE1_BitString ERROR!\n");

    // 5G-TMSI
    rSTMSI.fiveG_TMSI.length = static_cast<uint16_t>(UMIN(((fTmsi->fiveGTmsi.n + 7) / 8), MAX_5G_TMSI_LEN));
    memcpy(&rSTMSI.fiveG_TMSI.value[index], &fTmsi->fiveGTmsi.data[index], rSTMSI.fiveG_TMSI.length);

    return GOOD;
}

typedef struct E1_SamsungCallInfo::E1__bit1_3 E1_MaskedIMEISV;
static int16_t FillE1_MaskedIMEISV(callInfo_type& rCi, E1_MaskedIMEISV &rMaskedImeisv)
{
    AUTO_TRACE_FUNC;
    const VccbMaskedIMEISV_type *ptDB = &rCi.ueInfo.imeisvBuf.maskedIMEISV;
    VCCB_CHECK_E_RANGE_AND_RETURN(ptDB->length, (MASKED_IMEISV_LENGTH_MAX + 1));
    // Masked IMEISV : BIT STRING (SIZE:64)
    rMaskedImeisv.length = ptDB->length;

    if (GOOD != VCCB_GlobalAlloc((rMaskedImeisv.value), MASKED_IMEISV_BUF_SIZE))
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "ERROR: fnGlobalValueAlloc failed in %s\n", __FUNCTION__);
        return ERROR;
    }
    memcpy(&rMaskedImeisv.value[0], &ptDB->value[0], MASKED_IMEISV_BUF_SIZE);
    return GOOD;
} 

static int16_t FillE1_SamsungLastVisitedCellE1Item(E1_SamsungLastVisitedCellE1Item& rItem, const visitedCellInfo_type* const pEntry)
{
    VALID_E_POINT_CHECK_ERROR(pEntry);
    int status = ERROR;

    rItem.bit_mask = 0x00;
    rItem.cellSize = static_cast<E1__enum1_3>(pEntry->uRat.nrCell.cellSize);
    rItem.timeUEStayedInCell = static_cast<short unsigned int>(pEntry->uRat.nrCell.stayTime);
    rItem.globalCellID.choice = E1_nR_CGI_chosen;
    uint8_t* pCgiBuf = nullptr;
    
    if (ERROR == VCCB_GlobalAlloc(pCgiBuf, E1_CGI_BUF_SIZE))
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_GlobalAlloc failed in FillE1_SamsungLastVisitedCellE1Item!\n");
        return ERROR;
    }

    status = VEIL_fillE1_NRCGI(rItem.globalCellID.u.nR_CGI, pCgiBuf, pEntry->uRat.nrCell.cgi);
    if (ERROR == status)
    {
        VCCB_PRINT_ERROR("VEIL_fillE1_NRCGI - ERROR\n");
        return ERROR;
    }

    if (OPT_PRESENT == pEntry->uRat.nrCell.stayTimeEnhancedPresent)
    {
        rItem.bit_mask |= E1_timeUEStayedInCellEnhancedGranularity_present;
        rItem.timeUEStayedInCellEnhancedGranularity = pEntry->uRat.nrCell.stayTimeEnhanced;
    }
    return GOOD;
}

typedef struct E1_SamsungCallInfo::E1__seqof40_2 E1_SamsungUeHistoryInfo;
static int16_t FillE1_VomaHoHistory(callInfo_type& rCi, E1_SamsungUeHistoryInfo*& pHoHistory)
{
    AUTO_TRACE_FUNC;

    int16_t status;
    uint8_t cnt = 0;
    int8_t idx = static_cast<int8_t>(rCi.ueHistory.lastIdx);
    if (idx <0 || idx >= MAX_VISITED_CELL)
    {
        idx = (MAX_VISITED_CELL-1);
    }
    const visitedCellInfo_type *entry = nullptr;

    if (ERROR == VCCB_GlobalAlloc(pHoHistory, VOMA_MAX_UE_HISTORY))
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "ERROR: VCCB_GlobalAlloc failed in FillE1_VomaHoHistory!\n");
        return ERROR;
    }

    // For Intra-gNB HO (except Intra-Cell) in HO complete state include ongoing handover info on HO History list for VoMA purpose
    if (rCi.hoInfo.hoType.nb == HO_TYPE_INTRA_NB &&
        rCi.stateCmd != IntraCellHO_cmd &&
        VCCB_FLAG_ON == rCi.managementTraceInfo.isHoRrcReconfCmpleFlag &&
        CI_use == rCi.ueHistory.pendingUeHistoryEntry.usage)
    {
        status = FillE1_SamsungLastVisitedCellE1Item(pHoHistory[cnt].value, &rCi.ueHistory.pendingUeHistoryEntry);
        VCCB_RETURN_ON_CALL_ERROR(&rCi, status, "FillE1_SamsungLastVisitedCellE1Item - ERROR!!\n");
        ++cnt;
    }

    for (uint8_t index=0; index<VOMA_MAX_UE_HISTORY && cnt<VOMA_MAX_UE_HISTORY; ++index)
    {
        entry = &rCi.ueHistory.visitedCell[idx];
        --idx;
        if (idx<0)
        {
            idx = (MAX_VISITED_CELL-1);
        }

        if (CI_use != entry->usage)
        {
            continue;
        }

        if (ci_nr != entry->ratType)
        {
            // first entry other than NR close VoMA list
            break;
        }

        status = FillE1_SamsungLastVisitedCellE1Item(pHoHistory[cnt].value, entry);
        VCCB_RETURN_ON_CALL_ERROR(&rCi, status, "FillE1_SamsungLastVisitedCellE1Item - ERROR!!\n");
        ++cnt;
    }
    if (0 != cnt)
    {
        status = VCCB_ConnectLinkedList(pHoHistory, static_cast<int>(cnt));
        VCCB_RETURN_ON_CALL_ERROR(&rCi, status, "ERROR: VCCB_ConnectLinkedList failed for choice system container!!\n");
        return GOOD;
    }

    VCCB_PRINT_CALL_COMMENT(&rCi, "[VoMA] UE history empty!\n");
    return BREAK;
}

static bool FillE1_VomaCellMeasReport(uint16_t pci,  NRRRC_MeasResultNR& measResult,  E1_MeasurementReport& vomaReport)
{
    NRRRC_MeasQuantityResults *fillMeas = nullptr;
    if (measResult.bit_mask & NRRRC_MeasResultNR_physCellId_present)
    {
        if (measResult.physCellId == pci)
        {
            if (measResult.measResult.cellResults.bit_mask & NRRRC_resultsSSB_Cell_present)
            {
                fillMeas = &measResult.measResult.cellResults.resultsSSB_Cell;
            }
            else if (measResult.measResult.cellResults.bit_mask & NRRRC_resultsCSI_RS_Cell_present)
            {
                fillMeas = &measResult.measResult.cellResults.resultsCSI_RS_Cell;
            }
            else
            {
                fillMeas = nullptr;
            }

            if (fillMeas)
            {
                if (fillMeas->bit_mask & NRRRC_MeasQuantityResults_rsrp_present)
                {
                    vomaReport.bit_mask |= E1_rsrp_present;
                    vomaReport.rsrp = fillMeas->rsrp;
                }
                if (fillMeas->bit_mask & NRRRC_MeasQuantityResults_rsrq_present)
                {
                    vomaReport.bit_mask |= E1_rsrq_present;
                    vomaReport.rsrq = fillMeas->rsrq;
                }
                if (fillMeas->bit_mask & NRRRC_MeasQuantityResults_sinr_present)
                {
                    vomaReport.bit_mask |= E1_sinr_present;
                    vomaReport.sinr = fillMeas->sinr;
                }
            }
            return true;
        }
    }
    return false;
}

static int16_t FillE1_VomaMeasReport(callInfo_type& rCi, E1_SamsungMeasurementReportVOMA& rReport)
{
    VCCB_CHECK_E_RANGE_AND_RETURN(rCi.servCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[rCi.servCellNum];

    // Unpack MeasResultList2NR from hoInfo.
    VCCB_CHECK_E_RANGE_AND_RETURN(rCi.myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    msgUnpack_type *ptUnpack = &THREAD_INFO->call[rCi.myThreadId].buf.unpack.store;

    if (0 == rCi.qInfo.measResultList2NRSize)
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "%s: no measurement buffer to unpack!\n", __FUNCTION__);
        return ERROR;
    }

    if (GOOD !=
        UnpackNRRRC_MeasResultList2NR(ptUnpack, rCi.hoInfo.measResultList2NRPacked, rCi.qInfo.measResultList2NRSize))
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "%s: failed to unpack measResultList2NRPacked!\n", __FUNCTION__);
        return ERROR;
    }
            
    NRRRC_MeasResultList2NR ptMeasResultList2NR =
        *(NRRRC_MeasResultList2NR *)(&ptUnpack->unpack[0] + ptUnpack->unpackMsgOffset);

    // TargetCell PCI
    uint16_t tgtPci = rCi.hoInfo.phyCellId;
    uint32_t tgtSsbFreq = rCi.hoInfo.tgtSsbFreq;
    uint16_t srcPci = pCell->phyCellId;
    uint32_t srcSsbFreq = pCell->ssbArfcn;

    bool srcFound = false;
    bool tgtFound = false;
    bool srcSsbFound = false;
    bool tgtSsbFound = false;
    
    rReport.servingCellMeasurementReport.bit_mask = 0;
    rReport.targetCellMeasurementReport.bit_mask = 0;

    do
    {
        srcSsbFound = false;
        tgtSsbFound = false;

        if (!(ptMeasResultList2NR->value.bit_mask & NRRRC_MeasResult2NR_ssbFrequency_present))
        {
            continue;
        }

        if (!srcFound && ptMeasResultList2NR->value.ssbFrequency == srcSsbFreq)
        {
            srcSsbFound = true;
        }
        
        if (!tgtFound && ptMeasResultList2NR->value.ssbFrequency == tgtSsbFreq)
        {
            tgtSsbFound = true;
        }

        // SSB Freqency not match
        if (!srcSsbFound && !tgtSsbFound)
        {
            continue;
        }

        if (ptMeasResultList2NR->value.bit_mask & NRRRC_MeasResult2NR_measResultServingCell_present)
        {
            if (!srcFound && srcSsbFound)
            {
                srcFound = FillE1_VomaCellMeasReport(srcPci, ptMeasResultList2NR->value.measResultServingCell, rReport.servingCellMeasurementReport);
            }
            if (!tgtFound && tgtSsbFound)
            {
                tgtFound = FillE1_VomaCellMeasReport(tgtPci, ptMeasResultList2NR->value.measResultServingCell, rReport.targetCellMeasurementReport);
            }
            if (srcFound && tgtFound) // both measurement found, exit
            {
                break;
            }
        }

        if (tgtSsbFound && !tgtFound && (ptMeasResultList2NR->value.bit_mask & NRRRC_MeasResult2NR_measResultNeighCellListNR_present))
        {
            NRRRC_MeasResultListNR nbrList = ptMeasResultList2NR->value.measResultNeighCellListNR;
            if (!nbrList)
            {
                continue;
            }

            do
            {
                if (nbrList->value.bit_mask & NRRRC_MeasResultNR_physCellId_present)
                {
                    tgtFound = FillE1_VomaCellMeasReport(tgtPci, nbrList->value, rReport.targetCellMeasurementReport);
                }
            } while ((nbrList = nbrList->next) && !tgtFound);
        }

    } while ( (!srcFound || !tgtFound) && (ptMeasResultList2NR = ptMeasResultList2NR->next));

    int status = ERROR;
    uint8_t* pSrcCgiBuf = nullptr;
    uint8_t* pTgtCgiBuf = nullptr;

    if (ERROR == VCCB_GlobalAlloc(pSrcCgiBuf, E1_CGI_BUF_SIZE))
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "ERROR: VCCB_GlobalAlloc failed in FillE1_VomaMeasReport!\n");
        return ERROR;
    }
    
    if (ERROR == VCCB_GlobalAlloc(pTgtCgiBuf, E1_CGI_BUF_SIZE))
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "ERROR: VCCB_GlobalAlloc failed in FillE1_VomaMeasReport!\n");
        return ERROR;
    }

    // ServCell PCI
    rReport.servingCellMeasurementReport.physCellid = srcPci;

    // ServCell CGI
    cgi_type servedCellCGI;
    servedCellCGI.plmn.longId = rCi.ueInfo.servedPlmn.longId;
    servedCellCGI.ci = pCell->cgi.ci;

    rReport.servingCellMeasurementReport.globalCellId.choice = E1_nR_CGI_chosen;
    status = VEIL_fillE1_NRCGI(rReport.servingCellMeasurementReport.globalCellId.u.nR_CGI,
                               pSrcCgiBuf, servedCellCGI);

    VCCB_RETURN_ON_CALL_ERROR(&rCi, status, "VEIL_fillE1_NRCGI ERROR!\n");

    // TargetCell PCI
    rReport.targetCellMeasurementReport.physCellid = tgtPci;

    // TargetCell CGI
    rReport.targetCellMeasurementReport.globalCellId.choice = E1_nR_CGI_chosen;
    status = VEIL_fillE1_NRCGI(rReport.targetCellMeasurementReport.globalCellId.u.nR_CGI,
                               pTgtCgiBuf, rCi.hoInfo.cgi);

    VCCB_RETURN_ON_CALL_ERROR(&rCi, status, "VEIL_fillE1_NRCGI ERROR!\n");

    return GOOD;
}

int16_t VEIL_fillE1_SamsungCallInfo(callInfo_type& rCi, E1_SamsungCallInfo& rCallInfo)
{
    AUTO_TRACE_FUNC;
    int16_t status = ERROR;
    rCallInfo.bit_mask = 0;
    
    // 5G S-TMSI
    if (CI_use == rCi.ueInfo.ueId.usage &&
        ciSTMSI == rCi.ueInfo.ueId.ueIdType)
    {
        status = FillE1_S_TMSI(rCi, rCallInfo.fiveG_S_TMSI);
        VCCB_RETURN_ON_CALL_ERROR(&rCi, status, "FillE1_S_TMSI ERROR!\n");
        rCallInfo.bit_mask |= E1_fiveG_S_TMSI_present;
    }
    else
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "FillE1_S_TMSI missing (%d:%d)\n",rCi.ueInfo.ueId.usage, rCi.ueInfo.ueId.ueIdType);
    }

    // Masked IMEISV
    if (rCi.ueInfo.imeisvBuf.maskedIMEISVPresent)
    {
        status = FillE1_MaskedIMEISV(rCi, rCallInfo.maskedIMEISV);
        VCCB_RETURN_ON_CALL_ERROR(&rCi, status, "FillE1_MaskedIMEISV ERROR!\n");
        rCallInfo.bit_mask |= E1_maskedIMEISV_present;
    }
    else
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "FillE1_MaskedIMEISV missing (%d)\n", rCi.ueInfo.imeisvBuf.maskedIMEISVPresent);
    }

    // Call Event Type
    if (VOMA_unknown != rCi.vomaInfo.vomaEvent)
    {
        rCallInfo.samsungCallEventType = static_cast<E1_SamsungCallEventType>(rCi.vomaInfo.vomaEvent);
        rCallInfo.bit_mask |= E1_samsungCallEventType_present;
    }

    // HO history
    status = FillE1_VomaHoHistory(rCi, rCallInfo.samsungUEhistoryInformation);
    if (GOOD == status)
    {
        rCallInfo.bit_mask |= E1_samsungUEhistoryInformation_present;
    }

    // Meas report
    if (rCi.vomaInfo.isHO)
    {
        status = FillE1_VomaMeasReport(rCi, rCallInfo.samsungMeasurementReportVOMA);
        if (GOOD == status)
        {
            rCallInfo.bit_mask |= E1_samsungMeasurementReportVOMA_present;
        }
        rCi.vomaInfo.isHO = false;
    }

    if (rCallInfo.bit_mask)
    {
        return GOOD;
    }

    // non of field present
    return ERROR;
}
