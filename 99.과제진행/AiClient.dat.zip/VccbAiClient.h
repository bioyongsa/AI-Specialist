// ============================================================
// VccbAiClient.h
// VCCB <-> AI Engine 비즈니스 로직 레이어
// ============================================================
#ifndef VCCB_VccbAiClient_H_
#define VCCB_VccbAiClient_H_

#include <stdint.h>
#include <stdbool.h>

struct callInfo_s;
typedef struct callInfo_s callInfo_type;

#ifdef __cplusplus
extern "C" {
#endif

// ---- 타이머 결정 정책 상수 ----
#define VCCB_AI_KEEP_THRESHOLD          0.6f
#define VCCB_AI_RELEASE_THRESHOLD       0.3f
#define VCCB_AI_MARGIN_FACTOR           1.2f
#define VCCB_AI_TIMER_MIN_SEC           1
#define VCCB_AI_TIMER_MAX_SEC           3600
#define VCCB_AI_MAX_EXTEND_COUNT        3
#define VCCB_AI_FALLBACK_COUNT          10
#define VCCB_AI_INFER_TIMEOUT_US        1000    // 추론 타임아웃: 1ms
#define VCCB_AI_24H_WINDOW_SEC          86400   // 24시간 (초)

// ---- 전역 AI 추론 통계 (스레드 안전: 읽기 전용 출력 용도) ----
typedef struct VccbAiGlobalStats_s {
    int64_t totalRequests;          // 총 추론 요청 수
    int64_t successCount;           // 성공 수
    int64_t failureCount;           // 추론 실패(오류/NaN) 수
    int64_t timeoutCount;           // 타임아웃(1ms 초과) 수
    int64_t fallbackCount;          // Fallback 응답 수
    int64_t triggerPt1Count;        // 포인트① 트리거 수
    int64_t triggerPt2Count;        // 포인트② 트리거 수
    int64_t triggerPt3Count;        // 포인트③ 트리거 수
    int64_t triggerPt4Count;        // 포인트④ 트리거 수
    int64_t triggerPt5Count;        // 포인트⑤ 트리거 수
    int64_t totalInferUs;           // 총 추론 소요 시간(us, 성공만)
    int32_t consecutiveFailCount;   // 현재 연속 실패 횟수
    bool    isFallbackMode;         // 현재 Fallback 모드 여부
} VccbAiGlobalStats_type;

// ---- 포인트① (MsgE1apMake.cpp) ----
// INACTIVE 진입 시 Inactivity Timer 값 결정.
// 실패/fallback/REDCAP/NRDC 시 defaultTimerSec 를 그대로 반환.
int32_t VccbAiClient_RecommendInactivityTimer(callInfo_type *ci,
                                              int32_t defaultTimerSec);

// ---- 포인트② (FeatRrcInactive.cpp) ----
// INACTIVE 천이 가능 여부. extendCount 초과 시 false.
bool    VccbAiClient_IsAbleToProceedInactive(callInfo_type *ci);

// ---- 포인트③ (StateSaRrcInact.cpp) ----
// Resume 이력을 history[] 순환 버퍼에 push 하고 통계 갱신.
void    VccbAiClient_OnResumeRequest(callInfo_type *ci, int32_t resumeCause);

// ---- 포인트④ (FeatRrcInactive.cpp) ----
// RNA Update 시 AI RNA 크기 권고값을 조회하여 로그 출력.
void    VccbAiClient_OnRnaUpdate(callInfo_type *ci);

// ---- 포인트⑤ (StateSaHo.cpp) ----
// XnAP HandoverRequest 수신 후 UE 이력을 aiCtx seed 데이터로 기록.
void    VccbAiClient_SeedFromXnapHistory(callInfo_type *ci);

// ---- Fallback 관리 (global) ----
bool    VccbAiClient_IsFallbackMode(void);
void    VccbAiClient_Reset(void);

// ---- 통계 출력 (itscp_vccb 디버그 커맨드용) ----
void    VccbAiClient_PrintStats(void);
void    VccbAiClient_GetStats(VccbAiGlobalStats_type *out);

#ifdef __cplusplus
}
#endif

#endif  // VCCB_VccbAiClient_H_
