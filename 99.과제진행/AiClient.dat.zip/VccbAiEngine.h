// ============================================================
// VccbAiEngine.h
// GRU 순전파 추론 엔진
// ============================================================
#ifndef VCCB_VccbAiEngine_H_
#define VCCB_VccbAiEngine_H_

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define VCCB_AI_HISTORY_LEN 10
#define VCCB_AI_HIDDEN_SIZE 16
#define VCCB_AI_STATIC_INPUT 15
#define VCCB_AI_SEQ_INPUT 2

// ---- 추론 입출력 ----
typedef struct VccbAiInput_s {
    float seq[VCCB_AI_HISTORY_LEN][VCCB_AI_SEQ_INPUT];
    float stat[VCCB_AI_STATIC_INPUT];
} VccbAiInput;

typedef struct VccbAiOutput_s {
    float resume_prob;
    float resume_time;
} VccbAiOutput;

// ---- UE별 이력 1건 ----
typedef struct VccbAiHistory_s {
    float durationSec;
    int32_t resumeCause;
} VccbAiHistory_type;

// ---- UE별 AI 컨텍스트 (callInfo_type 의 멤버) ----
typedef struct VccbAiCallContext_s {
    VccbAiHistory_type history[VCCB_AI_HISTORY_LEN];
    int32_t writeIdx;
    int32_t count;

    float avgDurationSec;
    float resumeSuccessRate;
    int32_t resumeCount24h;

    // 24h 슬라이딩 윈도우: 각 Resume 발생 시각(UNIX timestamp) 저장
    int64_t resumeTs[VCCB_AI_HISTORY_LEN];
    int32_t resumeTsWriteIdx;

    int64_t inactiveEntryTs;
    int32_t extendCount;
    float lastInferTimerSec;

    float h[VCCB_AI_HIDDEN_SIZE];
} VccbAiCallContext_type;

// ---- 엔진 ----
void VccbAiEngine_Init(void);
bool VccbAiEngine_Infer(const VccbAiInput &input, VccbAiOutput &output);

// ---- UE별 컨텍스트 초기화 ----
// VLIB_InitCallInfo 의 0xFF memset 직후 반드시 호출.
// h[]/resumeSuccessRate 등이 NaN 으로 깨지는 것을 방지.
void VccbAi_InitContext(VccbAiCallContext_type *ctx);

#ifdef __cplusplus
}
#endif

#endif // VCCB_VccbAiEngine_H_
