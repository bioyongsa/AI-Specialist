/****************************************************************
 * System      : 5G vNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : StateSaHo.cpp
 * Description : VHCM NG / XN interface state function
 * Author      :
 * Dept.       :
 * Created     :
 * Procedures defined :
 * Procedures called  :
 * Version     :
 * Revision history   :
 *          date      :
 *       revised by   :
 * revised information:
 ****************************************************************/

#include "ComInclude.h"
#include "StateSaHo.h"

#include "VccbAiClient.h"
#include "ComAsnUtil.hpp"
#include "ComLibUtility.h"
#include "ComTimeUtil.h"

#include "FeatCommon.h"
#include "FeatCa.hpp"
#include "FeatHoCommon.h"
#include "FeatSon.h"
#include "FeatMco.h"
#include "FeatMco.hpp"
#include "FeatTrace.h"
#include "FeatTrace.hpp"
#include "FeatMro.h"
#include "FeatMrdc.h"
#include "FeatCallInfo.h"
#include "FeatCallProc.h"
#include "FeatFullConfig.h"
#include "FeatMeasurements.hpp"
#include "FeatRre.h"
#include "FeatUlPathControlNRDC.h"
#include "FeatSecurity.h"
#include "FeatCaCsl.hpp"
#include "FeatVoma.hpp"
#include "FeatLtmHo.h"

#include "StateCommon.h"
#include "StateCommonMsgProc.h"
#include "StateTime.h"
#include "StateHandleAll.h"
#include "StateHandleSaHo.h"
#include "StateHandleSaMrdc.h"

#include "MsgCommonUtility.h"

#include "MsgF1apSend.h"
#include "MsgF1apStore.h"

#include "MsgE1apMake.h"
#include "MsgE1apSend.h"
#include "MsgE1apStore.hpp"

#include "MsgXnapSend.h"
#include "MsgXnapStore.h"

#include "MsgNgapSend.h"
#include "MsgNgapStore.h"

#include "MsgOamMake.h"
#include "MsgOamSend.h"

#include "MsgNrRrcMake.h"
#include "MsgNrRrcSend.h"
#include "MsgNrRrcStore.h"

#include "MsgNmbSend.h"

#include "nrrrcPack.h"
#include "nrrrcUnpack.h"

#include "RRC.h"

#include "HandleF1PreCheck.hpp"
#include "SnAddReqAckPreCheckHandler.hpp"

using asn::util::ptUnpackConvert;

/****************************************************************************
                                Util
****************************************************************************/
// {{{

/************************************************************************************************************************
 *  Function    : FnVCCB_IsAnyPartialDrbQosPdu
 *  Description : This function decides whether to allow Partial or Handover.
 ************************************************************************************************************************/
VCCB_STATIC_INLINE
AllowedStatus FnVCCB_IsAnyPartialDrbQosPdu(callInfo_type &callInfo)
{
    callInfo_type *ptCi = &callInfo;

    auto IsAnyPartialInPdu = [&callInfo]()
    {
        for (uint16_t pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
        {
            callPDUSessInfo_type &refPdu = callInfo.pduSess[pduIdx];

            if (!IS_VALID_NODE(PDU_NODE, &callInfo, &refPdu)) continue;

            if (VLIB_IsCommonValidStateOfPduQosDrb(refPdu.pduSessStatus) == ERROR)
            {
                return true;
            }
        }

        return false;
    };

    auto IsAnyPartialInQosFlow = [&callInfo]()
    {
        for (uint16_t qosFlowIdx = 0; qosFlowIdx < MAX_QOS_FLOW_PER_CALL; qosFlowIdx++)
        {
            qosFlowInfo_type &refQosFlow = callInfo.qosFlow[qosFlowIdx];

            if (!IS_VALID_NODE(QOSFLOW_NODE, &callInfo, &refQosFlow)) continue;

            if (VLIB_IsCommonValidStateOfPduQosDrb(refQosFlow.qosFlowStatus) == ERROR)
            {
                return true;
            }
        }

        return false;
    };

    auto IsAnyPartialInDrb = [&callInfo]()
    {
        for (uint16_t drbIdx = 0; drbIdx < MAX_DRB_PER_UE; drbIdx++)
        {
            callDRBInfo_type &refDrb = callInfo.drb[drbIdx];

            if (!IS_VALID_NODE(DRB_NODE, &callInfo, &refDrb)) continue;

            if (VLIB_IsCommonValidStateOfPduQosDrb(refDrb.drbStatus) == ERROR)
            {
                return true;
            }
        }

        return false;
    };

    if (IsAnyPartialInPdu() == true)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : Detect PDU Partial\n");
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerTargetNotAllowed;
        // ptCi->cause.ngCause; // Conditional Handover Only XN Case.
        return Not_Allowed;
    }

    if (IsAnyPartialInQosFlow() == true)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : Detect QosFlow Partial\n");
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerTargetNotAllowed;
        // ptCi->cause.ngCause; // Conditional Handover Only XN Case.
        return Not_Allowed;
    }

    if (IsAnyPartialInDrb() == true)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : Detect DRB Partial\n");
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerTargetNotAllowed;
        // ptCi->cause.ngCause; // Conditional Handover Only XN Case.
        return Not_Allowed;
    }

    return Allowed;
}

/**
 * @brief This function checks if VoNR is not supported on receiving F1 messages.
 *
 * @param[in] ptCi Pointer to the call information structure.
 * @param[in] ptUnpack Pointer to the unpacked message structure.
 */
void FnVCCB_Check_F1FailureCuaseForStat(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptUnpack);

    if (ptCi->callType != E_CALLTYPE_SA) return;

    auto setVonrFailed = [ptCi](uint16_t _cause) {
        if (ptCi->hoInfo.isVonrCall != TRUE) return;
        if (ptCi->stateCmd != IntraRatHO_cmd) return;

        if (_cause == CauseF1apRadioNotSupportedQCI) 
            ptCi->hoInfo.notSupportedVonr = TRUE;
    };

    auto setSliceRejected = [ptCi](uint16_t _cause) {
        if (ptCi->hoInfo.sliceRejectionStats == TRUE) return;
        if (not (ptCi->stateCmd == IntraRatHO_cmd || ptCi->stateCmd == InterRatHO_cmd)) return;

        if (_cause == CauseF1apRadioResourcesNotAvailableForTheSlice)
            SET_SLICE_REJECT_CAUSE(ptCi);
    };

    // Get Cause
    uint16_t cause;
    switch (ptUnpack->msgId)
    {
        case F1_UEContextSetupFailure_id:
        {
            const F1_UEContextSetupFailure *pFailure = asn::util::ptUnpackConvert<F1_UEContextSetupFailure>(ptUnpack);
            const struct F1_ProtocolIE_Container_ *pContainer = pFailure->protocolIEs;
            if (VFIL_storeF1_Cause(pContainer, &cause) == ERROR) return;

            break;
        }
        case F1_UEContextModificationFailure_id:
        {
            const F1_UEContextModificationFailure *pFailure = asn::util::ptUnpackConvert<F1_UEContextModificationFailure>(ptUnpack);
            const struct F1_ProtocolIE_Container_ *pContainer = pFailure->protocolIEs;
            if (VFIL_storeF1_Cause(pContainer, &cause) == ERROR) return;
            break;
        }

        default:
            return;
    }

    // Set flag based on Cause
    setVonrFailed(cause);
    setSliceRejected(cause);
}

enumMrdcYangFlag_type FnVCCB_Get_MRDC_SNAddMode(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, MrdcMobilityYang_SnRelease);

    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, MrdcMobilityYang_SnRelease);
    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    // NR-DC
    if (IS_NRDC(ptCi))
    {
        return (enumMrdcYangFlag_type)pCell->mobilityConfig.nrdcMobilityOption;
    }

    return MrdcMobilityYang_SnRelease;
}

AllowedStatus FnVCCB_CheckMrdcSupportedCell(const callInfo_type *ptCi, const uint32_t cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, Not_Allowed);

    // Inter-DC change is not allowed.

    if (IS_NRDC(ptCi))
    {
        if (!IS_SUPPORT_NRDC_FOO())  // NR-DC not supported in ACPF
        {
            return Not_Allowed;
        }

        if (!IS_SUPPORT_NRDC_Yang(cellNum))  // NR-DC not supported in Cell
        {
            return Not_Allowed;
        }
    }
    else if (IS_NEDC_MN(ptCi))
    {
        if (!IsSupport_NEDC_Foo())  // NE-DC not supported in ACPF
        {
            return Not_Allowed;
        }

        if (!IsSupport_NEDC_Yang(cellNum))  // NE-DC not supported in Cell
        {
            return Not_Allowed;
        }
    }
    else
    {
        return Not_Allowed;
    }

    return Allowed;
}

AllowedStatus FnVCCB_CheckMrdcSupportedBearerType(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, Not_Allowed);

    uint8_t drbIdx;
    callDRBInfo_type *ptDi;

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        ptDi = &ptCi->drb[drbIdx];

        if (ptDi->usage != CI_use) continue;
        if (ptDi->pduIdxInCall >= MAX_PDU_SESS_PER_CALL) continue;

        switch (ptDi->bearerType.val)
        {
            case SN_Term_MCG_Bearer:    // not supported yet
            case MN_Term_SCG_Bearer:    // not supported yet
            case SN_Term_Undetermined:  // error case: need to reject of full configuration
                if (CFG->fullConfig.support.flag.F_21C_MRDC_UNSUPPORT_BEARER == Not_Allowed)
                {
                    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (Unknown/UnSupported Bearer DRB:%u/%s)\n",
                        ptDi->dRBId, FnVCCB_GetStrBearerType((int)ptCi->bearerType));
                    return Not_Allowed;
                }
                else
                {
                    VCCB_SET_FULLCONFIGURATION(ptCi, ci_fc_trigger, "SA, MRDC:: Unknown/UnSupported Bearer DRB");
                    return Not_Allowed;
                }
                break;
            default:
                break;
        }
    }

    return Allowed;
}

AllowedStatus FnVCCB_CheckAdditionalUlTnlAddressInformation_XN(
    callInfo_type *ptCi, const XN_HandoverRequest_type *ptMsg)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, Not_Allowed);
    VALID_E_POINT_CHECK_RET_VAL(ptMsg, Not_Allowed);

    uint8_t index;

    // 5. M - 'UE Context Information' in 'XN HandoverRequest'
    const XNAP_UEContextInfoHORequest_type *p = &ptMsg->uEContextInfoHORequest;

    // 7. M - 'PDU Session Resources' (9_2_1_1) in 'UE Context Information'
    const XNAP_PDUSessionResourcesToBeSetup_List_type *ptPduSetup = &p->pduSessionResourcesToBeSetup_List;
    for (index = 0; index < MIN(ptPduSetup->n, XN_MaxnoofPDUSessions); index++)
    {
        const XNAP_PDUSessionResourcesToBeSetup_Item_type *ptItem =
            &ptPduSetup->pDUSessionResourcesToBeSetup_Item[index];

        uint16_t pduIdxInCall = FnVCCB_GetPDUSessIndexFromPDUSessID(ptCi, ptItem->pduSessionId);
        if (pduIdxInCall >= MAX_PDU_SESS_PER_CALL)
        {
            // PDU Not Found Case .. Ignore .. it is partial case.
            continue;
        }

        callPDUSessInfo_type *ptPi = &ptCi->pduSess[pduIdxInCall];

        // Get current information for UL TNL -------------------------
        vector<qosFlowInfo_type *> mnTermQosFlowList;
        vector<qosFlowInfo_type *> snTermQosFlowList;

        FnVCCB_getQoSFlowListPerTerminatePoint(ptCi, ptPi, mnTermQosFlowList, snTermQosFlowList, current_bearerType);

        const bool isSplitPdu = FnVCCB_IsMrdcSplitPdu(mnTermQosFlowList.size(), snTermQosFlowList.size());
        // ----------------------------------------------------------------------

        if (isSplitPdu == false) continue;  // Check Only Split PDU Case..

        // In the case of a Split PDU

        // 5. O - Additional UL NG-U UP TNL Information at UPF List in Extension.
        if (ptItem->m.pDUSessionResourcesToBeSetup_Item_ExtIEPresent == OPT_PRESENT)
        {
            if (ptItem->pDUSessionResourcesToBeSetup_Item_ExtIE.m.additional_UL_NG_U_TNLatUPF_ListPresent ==
                OPT_PRESENT)
            {
                // Multi Additional TNL Address .. Supported Only 1 Additional TNL Address.
                if (ptItem->pDUSessionResourcesToBeSetup_Item_ExtIE.additional_UL_NG_U_TNLatUPF_List.n == 1)
                {
                    // Normal Case, Check Next PDU.
                    continue;
                }
            }
        }

        // Additional TNL Address must exist.
        return Not_Allowed;
    }

    return Allowed;
}

AllowedStatus FnVCCB_CheckAdditionalUlTnlAddressInformation_NG(
    callInfo_type *ptCi, const NG_HandoverRequestAmfgnb_type *ptMsg)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, Not_Allowed);
    VALID_E_POINT_CHECK_RET_VAL(ptMsg, Not_Allowed);

    uint8_t index;

    // 10. M - 'PDUSessionResourceSetupListHOReq' in 'NG HandoverRequest'
    const NGAP_PDUSessionResourceSetupListHOReq_type *ptPduSetup = &ptMsg->pDUSessionResourceSetupListHOReq;

    for (index = 0; index < MIN(ptPduSetup->n, XN_MaxnoofPDUSessions); index++)
    {
        const NGAP_PDUSessionResourceSetupItemHOReq_type *ptItem = &ptPduSetup->PDUSessionResourceSetupItemHOReq[index];

        uint16_t pduIdxInCall = FnVCCB_GetPDUSessIndexFromPDUSessID(ptCi, ptItem->pDUSessionID);
        if (pduIdxInCall >= MAX_PDU_SESS_PER_CALL)
        {
            // PDU Not Found Case .. Ignore .. it is partial case.
            continue;
        }

        callPDUSessInfo_type *ptPi = &ptCi->pduSess[pduIdxInCall];

        // Get current information for UL TNL -------------------------
        std::vector<qosFlowInfo_type *> mnTermQosFlowList;
        std::vector<qosFlowInfo_type *> snTermQosFlowList;

        FnVCCB_getQoSFlowListPerTerminatePoint(ptCi, ptPi, mnTermQosFlowList, snTermQosFlowList, current_bearerType);

        const bool isSplitPdu = FnVCCB_IsMrdcSplitPdu(mnTermQosFlowList.size(), snTermQosFlowList.size());
        // ----------------------------------------------------------------------

        if (isSplitPdu == false) continue;  // Check Only Split PDU Case..

        // In the case of a Split PDU

        const NGAP_PDUSessionResourceSetupRequestTransfer_type *ptSetupTransfer =
            &ptItem->handoverRequestTransfer.decoded;

        // 5. O - Additional UL NG-U UP TNL Information at UPF List in Extension.
        if (ptSetupTransfer->m.NGAPAdditionalULNGUUPTNLInformationPresent == OPT_PRESENT)
        {
            // Multi Additional TNL Address .. Supported Only 1 Additional TNL Address.
            if (ptSetupTransfer->additionalUL_NGU_UP_TNLInformation.n == 1)
            {
                // Normal Case, Check Next PDU.
                continue;
            }
        }

        // Additional TNL Address must exist.
        return Not_Allowed;
    }

    return Allowed;
}

AllowedStatus FnVCCB_CheckAdditionalUlTnlAddressInformation(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, Not_Allowed);
    VALID_E_POINT_CHECK_RET_VAL(ptUnpack, Not_Allowed);

    switch (ptUnpack->msgId)
    {
        case XN_HandoverRequest_id:
        {
            const XN_HandoverRequest_type *ptXnMsg = (XN_HandoverRequest_type *)ptUnpack->unpack;
            return FnVCCB_CheckAdditionalUlTnlAddressInformation_XN(ptCi, ptXnMsg);
        }

        case NG_HandoverRequestAmfgnb_id:
        {
            NG_HandoverRequestAmfgnb_type *ptNgMsg = (NG_HandoverRequestAmfgnb_type *)ptUnpack->unpack;
            return FnVCCB_CheckAdditionalUlTnlAddressInformation_NG(ptCi, ptNgMsg);
        }

        default:
            return Not_Allowed;
    }
}

VCCB_STATIC_INLINE
int16_t FnVCCB_ProcNotAllowedSnodeAdditionRequestAcknowledge(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack, timerInfo_type *ptTimer)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR_PARAM3(ptCi, ptAll, ptUnpack);
    VALID_E_POINT_CHECK_ERROR(ptTimer);

    int16_t status = GOOD;

    SctpDataTransfer_type *ptSctp = (SctpDataTransfer_type *)ptAll;
    XN_SNodeAdditionRequestAcknowledge_type *ptMsg = (XN_SNodeAdditionRequestAcknowledge_type *)ptUnpack->unpack;

    logShmExtMsg(ptCi, RX_MSG, XN_SNodeAdditionRequestAcknowledge_id, (uint8_t *)ptSctp, ptMsg->m_NG_RANnodeUEXnAPID);

    ptCi->mrdcInfo.SNInfo[TGT_SN].ueXnAPID = ptMsg->s_NG_RANnodeUEXnAPID; // TBD Temp Reject
    ptCi->mrdcInfo.SNInfo[TGT_SN].m.ueXnAPID = VCCB_FLAG_ON;

    { // TIMER
        VCCB_CLEAR_TIMER(ptTimer, CANCEL_TIMER);
    }

    { // FLAG

        // Clear Received Flag
        OFF_SN_NODE_ADD_ACK_RCV_FLAG(ptCi->flag.respFlag);

        // Active Target-SN
        ON_MRDC_RSC_SETUP_FLAG(xn_tgtSnConn);
    }

    { // STAT 24B FGR-CC5201:FR491 Collect attempt+prep_success+cp_fail for the case MN receives SN Add Req Ack but detects full configuration
        VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_PrepSucc);
        VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_CpFail);
    }

    { // Release Processing by FLAG
        FnVCCB_ProcReleaseHandlingForMrdcMnHO(ptCi);
    }

    /* update the SN release event */
    status = FnVCCB_UpdateBearerTypeForHandover(ptCi, MrdcHoWithSnRelease);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_UpdateBearerTypeForHandover ERROR !! \n");

    // It needs to be called again because the Meas configuration needs to be changed according to the scenario change.
    // Scenario : Scenario Change From 'Inter-MN with SN Change' To 'Inter-MN with SN Release' by 'Bearer Context Change'.
    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");

    return GOOD;
}

VCCB_STATIC_INLINE
AllowedStatus FnVCCB_IsAllowedSnodeModificationRequestAcknowledge(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, Not_Allowed);
    VALID_E_POINT_CHECK_RET_VAL(ptAll, Not_Allowed);
    VALID_E_POINT_CHECK_RET_VAL(ptUnpack, Not_Allowed);

    int16_t status = GOOD;

    // XN_SNodeModificationRequestAcknowledge_type *ptMsg = reinterpret_cast<XN_SNodeModificationRequestAcknowledge_type *>(ptUnpack->unpack);

    if (DBG->flag.applySnInitFullConfigInMn_24B == VCCB_FLAG_ON)
    {
        status = FnVCCB_ProcSnInitFullConfiguration(ptCi, ptAll, ptUnpack, false);
        if (status != GOOD)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : Sn Init Full Configuration is not supported.\n");
            return Not_Allowed;
        }
    }

    return Allowed;
}

VCCB_STATIC_INLINE
int16_t FnVCCB_ProcNotAllowedSnodeModificationRequestAcknowledge(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack, timerInfo_type *ptTimer)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR_PARAM3(ptCi, ptAll, ptUnpack);
    VALID_E_POINT_CHECK_ERROR(ptTimer);

    int16_t status = GOOD;

    SctpDataTransfer_type *ptSctp = (SctpDataTransfer_type *)ptAll;
    XN_SNodeModificationRequestAcknowledge_type *ptMsg = (XN_SNodeModificationRequestAcknowledge_type *)ptUnpack->unpack;

    logShmExtMsg(ptCi, RX_MSG, XN_SNodeModificationRequestAcknowledge_id, (uint8_t *)ptSctp, ptMsg->m_NG_RANnodeUEXnAPID);

    { // TIMER
        VCCB_CLEAR_TIMER(ptTimer, CANCEL_TIMER);
    }

    { // FLAG
        // Clear Received Flag
        OFF_SN_NODE_MOD_ACK_RCV_FLAG(ptCi->flag.respFlag);
    }

    /* update the SN release event */
    status = FnVCCB_UpdateBearerTypeForHandover(ptCi, MrdcHoWithSnRelease);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_UpdateBearerTypeForHandover ERROR !! \n");

    // It needs to be called again because the Meas configuration needs to be changed according to the scenario change.
    // Scenario : Scenario Change From 'Intra-MN wo SN Change' To 'Intra-MN with SN Release' by 'Bearer Context Change'.
    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");

    return GOOD;
}

void FnVCCB_PrintMnMobilityWithSnMobility(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!IsAvailable_MrdcInfo()) return;

    int16_t status = GOOD;

    auto getMnHoType = [&ptCi]()
    {
        if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTER_NB)
        {
            switch(ptCi->hoInfo.hoType.interface)
            {
                case HO_TYPE_XN:
                    return "Inter-XN";
                case HO_TYPE_NG:
                    return "Inter-NG";
                default:
                    return "Inter-MN";                
            }
        }
        return "Intra-MN";
    };

    auto getSnScenario = [&ptCi]()
    {
        // ci_scg_released_ue
        if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue) return "w SnRel";

        // ci_scg_configured_ue
        if (FnVCCB_IsInterSnMobilityInMn(ptCi) == true) return "w SnChg";

        return "wo SnChg";
    };

    SNInfo_type *pSrcSnInfo = &ptCi->mrdcInfo.SNInfo[SRC_SN];
    SNInfo_type *pTgtSnInfo = &ptCi->mrdcInfo.SNInfo[TGT_SN];

    xnNbrInfo_type dummyXnNbrInfo;
    xnNbrInfo_type *ptSrcSnXnNbr = NULL;
    xnNbrInfo_type *ptTgtSnXnNbr = NULL;

    nbrGnbCellInfo_type dummyNbrGnbCell;
    nbrGnbCellInfo_type *ptSrcNbrGnbCell = NULL;
    nbrGnbCellInfo_type *ptTgtNbrGnbCell = NULL;

    uint16_t srcNbrIdx = MIN(pSrcSnInfo->nbrIdx, MAX_NBR_PER_CELL);
    uint16_t tgtNbrIdx = MIN(pTgtSnInfo->nbrIdx, MAX_NBR_PER_CELL);


    // 1) Find Information
    {
        // 1-1) Init DB
        {
            memset(&dummyXnNbrInfo, 0x00, sizeof(dummyXnNbrInfo));
            dummyXnNbrInfo.plmn.s2.mnc = 0xFFF;
            dummyXnNbrInfo.plmn.s2.mcc = 0xFFF;
            dummyXnNbrInfo.gnbId.id = (uint32_t)-1;

            memset(&dummyNbrGnbCell, 0x00, sizeof(dummyNbrGnbCell));
            dummyNbrGnbCell.cellId = MAX_CELL_IDENTITY;
        }

        // 1-2) Find End-Point-XN (SrcSN and TgtSN)
        {
            ptSrcSnXnNbr = FnVCCB_GetXnNbrInfo(ptCi->gnbNum, pSrcSnInfo->epIdx);

            if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_config_ue)  // with/without SN Change
            {
                ptTgtSnXnNbr = FnVCCB_GetXnNbrInfo(ptCi->gnbNum, pTgtSnInfo->epIdx);
            }

            if (ptSrcSnXnNbr == NULL) ptSrcSnXnNbr = &dummyXnNbrInfo;
            if (ptTgtSnXnNbr == NULL) ptTgtSnXnNbr = &dummyXnNbrInfo;
        }

        // 1-3) Find Cell Nbr (SrcPSCell and TgtPSCell)
        {
            status = getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, pSrcSnInfo->nbrIdx, &ptSrcNbrGnbCell);
            if (status != GOOD) ptSrcNbrGnbCell = NULL;

            if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_config_ue)  // with/without SN Change
            {
                status = getNbrGnbCellByCellNbrIdx(ptCi->hoInfo.targetCellNum, pTgtSnInfo->nbrIdx, &ptTgtNbrGnbCell);
                if (status != GOOD) ptTgtNbrGnbCell = NULL;
            }

            if (ptSrcNbrGnbCell == NULL) ptSrcNbrGnbCell = &dummyNbrGnbCell;
            if (ptTgtNbrGnbCell == NULL) ptTgtNbrGnbCell = &dummyNbrGnbCell;
        }
    }

    // 2) Print
    if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
    {
        // Print With SN Release
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Start %s %s, SrcSN(%X-%u/%u, %u/%u)\n",
            getMnHoType(), getSnScenario(),
            ptSrcSnXnNbr->plmn.longId, ptSrcSnXnNbr->gnbId.id, pSrcSnInfo->epIdx, ptSrcNbrGnbCell->cellId, srcNbrIdx);

        return;
    }
    else
    {
        // Print With/Without SN Change
        VCCB_PRINT_CALL_INFORMATIVE(ptCi,
            "Start %s %s, SrcSN(%X-%u/%u, %u/%u) TgtSN(%X-%u/%u, %u/%u)\n",
            getMnHoType(), getSnScenario(),
            ptSrcSnXnNbr->plmn.longId, ptSrcSnXnNbr->gnbId.id, pSrcSnInfo->epIdx, ptSrcNbrGnbCell->cellId, srcNbrIdx,
            ptTgtSnXnNbr->plmn.longId, ptTgtSnXnNbr->gnbId.id, pTgtSnInfo->epIdx, ptTgtNbrGnbCell->cellId, tgtNbrIdx);

        return;
    }
}

AllowedStatus FnVCCB_MrdcMobilityProc_IsAllowedYang(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, Not_Allowed);

    // Checks whether MR-DC FOO and YANG is supported.
    if (FnVCCB_CheckMrdcSupportedCell(ptCi, cellNum) == Not_Allowed)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (Does not support Mrdc, ueCtxType:%u)\n", ptCi->mrdcInfo.ueCtxType);
        return Not_Allowed;
    }

    // Checks whether MR-DC Mobility is supported.
    if (MrdcMobilityYang_SnRelease == FnVCCB_Get_MRDC_SNAddMode(ptCi, cellNum))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (Does not support Mrdc Mobility, ueCtxType:%u)\n", ptCi->mrdcInfo.ueCtxType);
        return Not_Allowed;
    }

    return Allowed;
}

AllowedStatus FnVCCB_MrdcMobilityProc_ProcAllowedBCList(callInfo_type *ptCi, CellNum_type cellNum, FreqBandInd_type cellBand, bool isCtrlUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, Not_Allowed);
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(cellNum, Not_Allowed);
    bandCombinationInfoList_type &rCurrAllowedBCList = ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC;

    if (isCtrlUnpack)
    {
        // 1) Unpack
        bigmsgUnpack_type *ptUnpackUeCapa = &THREAD_INFO->call[ptCi->myThreadId].buf.unpack.ueCapa;

        if (FnVCCB_Wrapper_UnpackNRRRC_UE_NR_Capability(ptCi, ptUnpackUeCapa) == ERROR)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (NR RRC CAPA Unpack Fail)\n");
            return Not_Allowed;
        }

        NRRRC_UE_NR_Capability *ptMsg = NULL;
        ptMsg = (NRRRC_UE_NR_Capability *)(&ptUnpackUeCapa->unpack[0] + ptUnpackUeCapa->unpackMsgOffset);

        // 2) make a BC list for target cellNum
        if (ERROR == FnVCCB_MakeAllowedBCList(ptCi, cellNum, cellBand, ptMsg, TRUE))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "FnVCCB_MakeAllowedBCList Error! in %s!!\n", __func__);
        }
    }
    else if (CELLINFO[cellNum].cellIdentity != rCurrAllowedBCList.cellIdentity)
    {
        // update SelectedBandEntryMNBitMap in case of pCell change, even if there is no need to refresh AllowedBCList
        VLIB_UpdateSelectedBandEntryMNBitMap(ptCi, cellNum);
    }

    // If Band Combination cannot be accommodated, SN is released.
    if (ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC.nrofBandComb == 0)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (Not Allowed BC List)\n");
        return Not_Allowed;
    }

    return Allowed;
}

AllowedStatus FnVCCB_MrdcMobilityProc_TargetCellSelection(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, Not_Allowed);

    int16_t status = FnVCCB_SelectNrdcPSCellForMnMobility(ptCi);
    if (status == ERROR)
    {
        auto isProPscellReuse = [](const uint16_t gnbNum)
        {
            if (gnbNum >= MAX_GNB_PER_SYS) return false;

            return GNBINFO[gnbNum].cfg.gnbMobilityConfig.isSnSelectionUsingSelectedBandCombSnSupportNrdc;
        };

        if (isProPscellReuse(ptCi->gnbNum) == true)
        {
            if (ptCi->mrdcInfo.SNInfo[SRC_SN].epIdx == XNIDX_FOR_UNKNOWN_SN)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (PSCell Selection Fail, and SN is DisConnection) \n");
                return Not_Allowed;
            }

            if (GOOD != VRIL_CheckIfSelectedBandCombinationIsIncludedInAllowedBCList(ptCi))
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (PSCell Selection Fail, and SbcSN is Not Include In Allowed BC) \n");
                return Not_Allowed;
            }

            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "MRDC Selection (PSCell Selection Fail, But PSCell Reuse)\n");
            ptCi->mrdcInfo.SNInfo[TGT_SN] = ptCi->mrdcInfo.SNInfo[SRC_SN];  // PSCell Reuse
            return Allowed;
        }

        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (PSCell Selection Fail, There is no PSCell) \n");
        return Not_Allowed;
    }

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Target PSCell Selection Success!\n");
    return Allowed;
}

AllowedStatus FnVCCB_MrdcMobilityProc_InterSnSelection(callInfo_type *ptCi, enumMrdcHoScenario_type &type)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, Not_Allowed);

    if (FnVCCB_IsInterSnMobilityInMn(ptCi))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Inter-SN Mobility (Selected New SN From %d To %d)\n",
            ptCi->mrdcInfo.SNInfo[SRC_SN].epIdx, ptCi->mrdcInfo.SNInfo[TGT_SN].epIdx);
        type = MrdcHoWithSnChange;  // Inter-SN Mobility
    }
    else
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Target PSCell Selection Success!\n");
    }

    return Allowed;
}

AllowedStatus FnVCCB_MrdcMobilityProc_Inter_CandidateMN(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, Not_Allowed);

    if (FnVCCB_CheckValid_octetString(&ptCi->mrdcInfo.candidateCellInfoListMN) == false)
    {
        unsigned int length = MIN(ptCi->qInfo.measResultList2NRSize, MAX_MEASRESULTLIST2NR_SIZE);

        if (length > 0)
        {
            char *pBuff = VLIB_GetBuffer(ptCi, length, VCCB_FLAG_OFF);
            if (!pBuff)
            {
                VCCB_PRINT_CALL_INFORMATIVE(
                    ptCi, "SN Release (Cause: candidateCellInfoListMN buffer alloc fail (len:%u)\n", length);
                return Not_Allowed;
            }

            memcpy(pBuff, ptCi->hoInfo.measResultList2NRPacked, length);

            ptCi->mrdcInfo.candidateCellInfoListMN.length = (uint16_t)length;
            ptCi->mrdcInfo.candidateCellInfoListMN.value = (unsigned char *)pBuff;
        }
    }

    return Allowed;
}

AllowedStatus FnVCCB_MrdcMobilityProc_Intra_CandidateSN(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, Not_Allowed);

    if (IS_NEDC_MN(ptCi))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Support, NEDC Mobility with/without SN Change!\n");
        return Not_Allowed;
    }

    if (FnVCCB_CheckValid_octetString(&ptCi->mrdcInfo.candidateCellInfoListSN))
    {
        if (FnVCCB_CheckValid_octetString(&ptCi->mrdcInfo.candidateCellInfoListMN) == true)
        {
            // If candidateCellInfoListMN Exist, candidateCellInfoListSN Release.
            VCCB_MRDC_FREE_BUFFER(ptCi, (char *)ptCi->mrdcInfo.candidateCellInfoListSN.value);
        }
        else
        {
            // If candidateCellInfoListMN Not Exist, candidateCellInfoListSN to candidateCellInfoListMN.
            ptCi->mrdcInfo.candidateCellInfoListMN = ptCi->mrdcInfo.candidateCellInfoListSN;
        }

        // candidateCellInfoListSN initializes.
        ptCi->mrdcInfo.candidateCellInfoListSN.value = NULL;
        ptCi->mrdcInfo.candidateCellInfoListSN.length = 0;
    }

    return Allowed;
}

int16_t FnVCCB_MrdcMobilityProc_Inter(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->hoInfo.targetCellNum);

    /* There is no SN information */
    if (!IsAvailable_MrdcInfo()) return GOOD;

    int16_t status;
    enumMrdcHoScenario_type type = MrdcHoWithoutSnChange;  // Intra-SN

    // lambda inline function
    auto isProcAllowedBCList = [&ptCi]()
    {
        // update selectedMrdcType
        if (IS_NRDC_MN(ptCi))
        {
            FnVCCB_SetSelectedMrdcType(ptCi, ptCi->servCellNum, MRDC_NRDC);
        }
        else if (IS_NEDC_MN(ptCi))
        {
            FnVCCB_SetSelectedMrdcType(ptCi, ptCi->servCellNum, MRDC_NEDC);
        }

        // when NR-DC UE -> NR-DC UE (Inter gNB handover target)
        if (FnVCCB_MrdcMobilityProc_ProcAllowedBCList(ptCi, ptCi->servCellNum, ptCi->servCellBand, true) == Not_Allowed)
        {
            return Not_Allowed;
        }

        return Allowed;
    };

    // Check Unknown DC Context
    if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (Unknown DC Context, ...)\n");
        goto SN_RELEASE;
    }

    if(IS_NRDC_DISABLED_BY_OVLD(ptCi) == true)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (CPU Overload by Basic Operation for NR-DC)\n");
        goto SN_RELEASE;
    }
    
    // Check Conditional Handover UE
    if (FnVCCB_IsConditionalHandoverUE(ptCi) == true)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (Conditional Handover UE supports only SN Release)\n");
        goto SN_RELEASE;
    }

    // Checks whether MR-DC FOO and YANG is supported.
    if (FnVCCB_MrdcMobilityProc_IsAllowedYang(ptCi, ptCi->hoInfo.targetCellNum) == Not_Allowed)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (FnVCCB_MrdcMobilityProc_IsAllowedYang)\n");
        goto SN_RELEASE;
    }

    // VONR
    if (FALSE == FnVCCB_CheckAllowedConcurrentNRDCandVoNR(ptCi, ptCi->hoInfo.targetCellNum))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi,
            "SN Release (Cause: VoNR and NR-DC is not allowed same time! Handover with SN "
            "Release will be triggered, Inter)\n");
        goto SN_RELEASE;
    }

    // Check Additional UL TNL Address Information
    if (FnVCCB_CheckAdditionalUlTnlAddressInformation(ptCi, ptUnpack) == Not_Allowed)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (Additional UL TNL Address)\n");
        goto SN_RELEASE;
    }

    // Unkonwn or Unsupported Bearer Type -- INTER-GNB Only
    if (FnVCCB_CheckMrdcSupportedBearerType(ptCi) == Not_Allowed)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (Unsupported BearerType)\n");
        goto SN_RELEASE;
    }

    // when NR-DC UE -> NR-DC UE (Inter gNB handover target)
    if (isProcAllowedBCList() == Not_Allowed)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (FnVCCB_MrdcMobilityProc_ProcAllowedBCList::isProcAllowedBCList)\n");
        goto SN_RELEASE;
    }

    status = FnVCCB_UpdateBearerTypeForHandover(ptCi, type);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_UpdateBearerTypeForHandover(Release) ERROR !! \n");

    if (FnVCCB_ValidateGFBRComparedToUeSliceMBR(*ptCi) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Sum of GFBR values exceed UE-Slice-MBR! ERROR!\n");
        goto SN_RELEASE;
    }

    // Fill Config Restriction Info For Inter-MN (P221026-00040)
    // IE : NRRRC_CG_ConfigInfo_IEs_configRestrictInfo_present
    VLIB_Set_MrdcConfigRestrictionInfo(ptCi);
    if(ptCi->cgConfigInfo.configRestrictInfoFlag == VCCB_FLAG_OFF)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (configRestrictInfo setting fail)\n");
        goto SN_RELEASE;
    }

    // MR Based Selection
    if (FnVCCB_MrdcMobilityProc_TargetCellSelection(ptCi) == Not_Allowed)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (FnVCCB_MrdcMobilityProc_TargetCellSelection)\n");
        goto SN_RELEASE;
    }

    // If MN Not Exist, Alloc&Copy From HoInfo.meas to MN.
    if (FnVCCB_MrdcMobilityProc_Inter_CandidateMN(ptCi) == Not_Allowed)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (FnVCCB_MrdcMobilityProc_Inter_CandidateMN)\n");
        goto SN_RELEASE;
    }

    if (FnVCCB_CheckValidEndPointXn_ForSN(ptCi->mrdcInfo.SNInfo[TGT_SN].epIdx) == false)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (Does not connected Target SN)\n");
        goto SN_RELEASE;
    }

    if (FnVCCB_MrdcMobilityProc_InterSnSelection(ptCi, type) == Not_Allowed)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (FnVCCB_MrdcMobilityProc_InterSnSelection)\n");
        goto SN_RELEASE;
    }

    // Non MN Term Bearer
    if (DBG->flag.mrdcHO_NotExistMnTerm_ToSnRelease_Inter == VCCB_FLAG_ON)  // set false for inter MN target
    {
        if (FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType) == false)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (MN Term Bearer Not Exist)\n");
            goto SN_RELEASE;
        }
    }

    // Check Full Configuration -- This content should always be below. This is because there is a situation where the
    // upper level is set to Full Configuration.
    if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (Full Configuration Trigger)\n");
        goto SN_RELEASE;
    }

    // SVR25B FGR-CC5201:FR710 Caution: FnVCCB_MrdcMobilityProc_Inter_Partial must be called after PSCell selection
    // completed
    if (FnVCCB_MrdcMobilityProc_Inter_PartialCheck(*ptCi, type) == Not_Allowed)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (Partial PDU/QOS/DRB)\n");
        goto SN_RELEASE;
    }

    FnVCCB_PrintMnMobilityWithSnMobility(ptCi);

    return GOOD;

SN_RELEASE:
    status = FnVCCB_UpdateBearerTypeForHandover(ptCi, MrdcHoWithSnRelease);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_UpdateBearerTypeForHandover(Release) ERROR !! \n");

    FnVCCB_PrintMnMobilityWithSnMobility(ptCi);

    return GOOD;
}

int16_t FnVCCB_MrdcMobilityProc_Intra(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->hoInfo.targetCellNum);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    CellNum_type cellNum = ptCi->hoInfo.targetCellNum;
    FreqBandInd_type cellBand = ptCi->hoInfo.targetCellBand;

    // SVR22B FGR-CC5203
    if (MrdcScgFailResume_cmd == ptCi->stateCmd)
    {
        if (IS_MRDC_MN(ptCi))
        {
            cellNum = ptCi->servCellNum;
            cellBand = ptCi->servCellBand;
        }
        else
        {
            cellNum = ptCi->nrdcScgFailureInfo.targetPsCellNum;
            cellBand = ptCi->nrdcScgFailureInfo.targetPsCellBand;
        }
    }

    /* There is no SN information */
    if (!IsAvailable_MrdcInfo()) return GOOD;

    int16_t status;
    enumMrdcHoScenario_type type = MrdcHoWithoutSnChange;  // Intra-SN

    if (DBG->flag.mrdcHO_HandoverTriggerStopAndToSnRelease_Intra == VCCB_FLAG_ON)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "DEBUG MOD, Handover Trigger Stop And Sn Release Trigger\n");
        goto SN_RELEASE_AFTER_HO_CANCEL;
    }

    if (FnVCCB_MrdcMobilityProc_IsAllowedYang(ptCi, cellNum) == Not_Allowed)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (FnVCCB_MrdcMobilityProc_IsAllowedYang)\n");
        goto SN_RELEASE;
    }

    // Checks whether Source SN is supported.
    if (FnVCCB_CheckValidEndPointXn_ForSN(ptCi->mrdcInfo.SNInfo[SRC_SN].epIdx) == false)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (Does not connected Source SN)\n");
        goto SN_RELEASE;
    }

    // Check Conditional Handover UE - SVR22C2 is CHO Intra-gNB Not Supported,
    // the following code must be activated when supporting packages later.
    // if (FnVCCB_IsConditionalHandoverUE(ptCi) == true)
    // {
    //     VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (Conditional Handover UE supports only SN Release)\n");
    //     goto SN_RELEASE;
    // }

    // VONR
    if (FALSE == FnVCCB_CheckAllowedConcurrentNRDCandVoNR(ptCi, cellNum))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi,
            "SN Release (Cause: VoNR and NR-DC is not allowed same time! Handover with SN "
            "Release will be triggered, Intra)\n");
        goto SN_RELEASE;
    }

    {
        bool isCtrlUnpack = FnVCCB_CheckPcellInfoChangedforAllowedBC(ptCi, cellNum, cellBand);
        if (FnVCCB_MrdcMobilityProc_ProcAllowedBCList(ptCi, cellNum, cellBand, isCtrlUnpack) == Not_Allowed)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (FnVCCB_MrdcMobilityProc_ProcAllowedBCList)\n");
            goto SN_RELEASE;
        }
    }

    // MR Based Selection
    if (FnVCCB_MrdcMobilityProc_TargetCellSelection(ptCi) == Not_Allowed)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (FnVCCB_MrdcMobilityProc_TargetCellSelection)\n");
        goto SN_RELEASE;
    }

    // If candidateCellInfoListSN Exist
    if (FnVCCB_MrdcMobilityProc_Intra_CandidateSN(ptCi) == Not_Allowed)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (FnVCCB_MrdcMobilityProc_Intra_CandidateSN)\n");
        goto SN_RELEASE;
    }

    if (FnVCCB_CheckValidEndPointXn_ForSN(ptCi->mrdcInfo.SNInfo[TGT_SN].epIdx) == false)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (Does not connected Target SN)\n");
        goto SN_RELEASE;
    }

    if (FnVCCB_MrdcMobilityProc_InterSnSelection(ptCi, type) == Not_Allowed)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release (FnVCCB_MrdcMobilityProc_InterSnSelection)\n");
        goto SN_RELEASE;
    }

    status = FnVCCB_UpdateBearerTypeForHandover(ptCi, type);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_UpdateBearerTypeForHandover(Intra/Inter-SN Mobility) ERROR !! \n");

    if (FnVCCB_ValidateGFBRComparedToUeSliceMBR(*ptCi) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Sum of GFBR values exceed UE-Slice-MBR! ERROR!\n");
        ptCi->cause.ngCause = CauseNgapRadioNetworkLayerRadioResourcesNotAvailable;
        status = VCCB_CALL_RELEASE_TRIGGER(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_CALL_RELEASE_TRIGGER Error!\n");

        return GOOD;
    }

    if (IS_MRDC(ptCi) && ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_config_ue)
    {
        FnVCCB_DecidePdcchBlindDetectionSCG(ptCi, ptCi->hoInfo.targetCellNum, &ptCi->cgConfigInfo.configRestrictInfo);
    }

    FnVCCB_PrintMnMobilityWithSnMobility(ptCi);

    return GOOD;

SN_RELEASE_AFTER_HO_CANCEL:

    // After Handover Cancel, perform Basic SN Release procedure.
    ptCi->hoInfo.cancelControl.needSnRelease = true;

    // When returning BREAK, Handover Cancel
    return BREAK;

SN_RELEASE:
    if (DBG->flag.mrdcHO_NotExistMnTerm_IfSnRel_HoCancelAndSnRel == TRUE)  // TODO :: E1 Setup Processing Not Exist
    {
        if (FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType) == false)
        {
            VCCB_PRINT_CALL_INFORMATIVE(
                ptCi, "SN Release (MN Term Bearer Not Exist), But Ho Cancel and SN Release procedure.\n");

            // After Handover Cancel, perform Basic SN Release procedure.
            ptCi->hoInfo.cancelControl.needSnRelease = true;

            // goto SN_RELEASE_AFTER_HO_CANCEL;
            return BREAK;
        }
    }

    status = FnVCCB_UpdateBearerTypeForHandover(ptCi, MrdcHoWithSnRelease);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_UpdateBearerTypeForHandover(Release) ERROR !! \n");

    FnVCCB_PrintMnMobilityWithSnMobility(ptCi);

    return GOOD;
}

void FnVCCB_MrdcMobilityProc_InterSN(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    int16_t status;
    enumMrdcHoScenario_type type = MrdcHoWithSnChange;

    /* There is no SN information */
    if (!IsAvailable_MrdcInfo())
    {
        return;
    }

    status = FnVCCB_UpdateBearerTypeForHandover(ptCi, type);
    VCCB_RETURN_ON_CALL_VOID(ptCi, status, "FnVCCB_UpdateBearerTypeForHandover ERROR !! \n");
}

int16_t VHCM_AllocCallSrbInfoForInterNode(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint8_t srbIdx;

    for (srbIdx = ID_SRB1 - 1; srbIdx <= ID_SRB2 - 1; srbIdx++)
    {
        /* check the not allocated SRB */
        if (!IS_VALID_NODE(SRB_NODE, ptCi, &(ptCi->srbInfo[srbIdx])))
        {
            if (ERROR == VLIB_AllocCallSrbInfo(ptCi, srbIdx))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_AllocCallSrbInfo ERROR!!\n");

                return ERROR;
            }

            ptCi->srbInfo[srbIdx].srbStatus = S_Setup;
        }
    }

    return GOOD;
}  // }}}

void VHCM_MsgStatAndLogging(callInfo_type *ptCi, const message_type *ptAll, const msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptAll);
    VALID_E_POINT_CHECK_VOID(ptUnpack);

    // MACRO_STAT_PMCC for Message Base
    switch (ptUnpack->msgId)
    {
        /* Setup */
        case F1_UEContextSetupResponse_id:
            MACRO_STAT_PMCC(STAT_F1AP_UE_SETUP_CU, DU_F1UeSetupSucc, ptCi, 0, 0, 0, 0, 0);
            VLIB_SetNoAttemptFlag(ptCi, STAT_F1AP_UE_SETUP_CU);
            break;

        case F1_UEContextSetupFailure_id:
            MACRO_STAT_PMCC(STAT_F1AP_UE_SETUP_CU, CU_F1UeSetupFail_DUFailure, ptCi, 0, 0, 0, 0, 0);
            VLIB_SetNoAttemptFlag(ptCi, STAT_F1AP_UE_SETUP_CU);
            break;

        case timF1_UeContextSetup_id:
            MACRO_STAT_PMCC(STAT_F1AP_UE_SETUP_CU, CU_F1UeSetupFail_DUTimeout, ptCi, 0, 0, 0, 0, 0);
            VLIB_SetNoAttemptFlag(ptCi, STAT_F1AP_UE_SETUP_CU);
            break;

        /* Modify */
        case F1_UEContextModificationResponse_id:
            MACRO_STAT_PMCC(STAT_F1AP_CU_INIT_UE_MOD_CU, CU_F1CuInitUeModSucc, ptCi, 0, 0, 0, 0, 0);
            VLIB_SetNoAttemptFlag(ptCi, STAT_F1AP_CU_INIT_UE_MOD_CU);
            break;

        case F1_UEContextModificationFailure_id:
            MACRO_STAT_PMCC(STAT_F1AP_CU_INIT_UE_MOD_CU, CU_F1CuInitUeModFail_DUFailure, ptCi, 0, 0, 0, 0, 0);
            VLIB_SetNoAttemptFlag(ptCi, STAT_F1AP_CU_INIT_UE_MOD_CU);
            break;

        case timInternalHandoverQuery_id:
            if (GET_F1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag))  // Statistics collected only for F1 MODI TMOUT.
            {
                MACRO_STAT_PMCC(STAT_F1AP_CU_INIT_UE_MOD_CU, CU_F1CuInitUeModFail_DUTimeout, ptCi, 0, 0, 0, 0, 0);
                VLIB_SetNoAttemptFlag(ptCi, STAT_F1AP_CU_INIT_UE_MOD_CU);
            }
            break;

        case timF1_UeContextModification_id:
            MACRO_STAT_PMCC(STAT_F1AP_CU_INIT_UE_MOD_CU, CU_F1CuInitUeModFail_DUTimeout, ptCi, 0, 0, 0, 0, 0);
            VLIB_SetNoAttemptFlag(ptCi, STAT_F1AP_CU_INIT_UE_MOD_CU);
            break;

        default:
            break;
    }

    // logShmIntMsg for Timer
    switch (ptUnpack->msgId)
    {
        case MSGBASE_TIMER ... TIMER_END_ID:
            logShmIntMsg(ptCi, RX_MSG, BLK_TIME, ptUnpack->msgId, sizeof(messageHdr_type), (uint8_t *)ptAll);
            break;

        default:
            break;
    }
}  // }}}

void VCOM_TriggerRreDuringHO(
    callInfo_type *ptCi, uint8_t isReleaseUe)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    VHCM_SA_HO_STAT(ptCi, HO_RRE);

    if (ptCi->hoInfo.ltmHandover == TRUE)
    {
        FnVCCB_CollectLtmCancel(*ptCi);
    }

    // Handles exceptions that occurred while handover is in progress. Responsible for response and release of
    // resources.
    FnVCCB_ProcReleaseHandlingForInterGnbHO(ptCi);

    if (isReleaseUe == TRUE)  // RRC Setup Case - existing ue job release, new ue job rrc-setup
    {
        // It will be called by PutCi, so I won't use it here.
        // VCOM_SaHandover_ReleaseResource(ptCi);
    }
    else  // RRE Setup Case - existing ue job reuse
    {
        VLIB_ClearAllRespFlags(ptCi);

        VCOM_SaHandoverCancel_ToRRE(ptCi, NRRRC_RrcReestablishmentRequest_id);
    }
}  // }}}

/****************************************************************************
 * @brief           Determines the Handover method when a Handover is triggered.
 * @details         Choose between NG and XN in Inter-gNB Handover.
 * @param[in]       ptCi : Pointer of callInfo_type
 * @param[in]       ptGi : Pointer of callGNBInfo_type
 * @param[out]      pHoType : Point of enumHoTypeInterface
 * @return          int16_t (GOOD, ERROR)
 ****************************************************************************/
int16_t VHCM_DecisionInterGnbSaHandoverType(callInfo_type *ptCi, vccbGlobalGnbId_type *pGnbId,
    enumHoTypeInterface *pInterfaceType, uint8_t *pXnLink, enumHandoverTriggerType hoTrigger, enumNgHoSelectionCause& ngHoSelectionCause)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pGnbId);
    VALID_E_POINT_CHECK_ERROR(pInterfaceType);
    VALID_E_POINT_CHECK_ERROR(pXnLink);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint16_t xnIdx = MAX_XN_NBR_PER_GNB;
    uint16_t amfIdx = MAX_AMF_SET_INFO;

    xnNbrInfo_type *pXnNbr = NULL;

    *pInterfaceType = HO_TYPE_NG;
    *pXnLink = FALSE;

    if (DBG->flag.triggerNgHO == VCCB_FLAG_ON)
    {
        ptCi->hoInfo.needNgHO = TRUE;
    }

    if (ptCi->hoInfo.nonNbrCell == TRUE)
    {
        ngHoSelectionCause = NG_HO_CAUSE_NON_NEIGHBOR_CELL;
        VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION(ptCi, "XN HO Not Allowed: Target Cell is nonNeighborCell!\n");
        return GOOD;
    }

    /* 24A FR10 Check intra-nr-src-indrect-fwd-preferece condition */
    if ((e_HoTrigger_ImmediateHandover == hoTrigger) && (TRUE == pGnb->cfg.intraNrSrcIndirectFwdPreference))
    {
        ngHoSelectionCause = NG_HO_CAUSE_INTRA_NR_SRC_INDIRECT_FWD_PREF;
        VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION(
            ptCi, "XN HO Not Allowed: intra-nr-src-indirect-fwd-preference is enabled !\n");
        return GOOD;
    }

    /* Search NbrCell In EndPointXn */
    xnIdx = fnVLIB_FindXnEndPointIndexByGnbId(ptCi->gnbNum, pGnbId);
    if (FnVCCB_CheckValidEndPointXn_ForSN(xnIdx) == false)
    {
        ngHoSelectionCause = NG_HO_CAUSE_NO_XN_END_POINT_INDEX;
        VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION(ptCi, "XN HO Not Allowed: Cannot find XnEndPointIndexByGnbId!\n");
        return GOOD;
    }

    pXnNbr = FnVCCB_GetXnNbrInfo(ptCi->gnbNum, xnIdx);
    if (pXnNbr == NULL)
    {
        ngHoSelectionCause = NG_HO_CAUSE_NO_XN_NBG_INFO;
        VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION(ptCi,
            "XN HO Not Allowed: Cannot find FnVCCB_GetXnNbrInfo(%u) in VHCM_DecisionInterGnbSaHandoverType!\n", xnIdx);
        return GOOD;
    }

    /* Direct Forwarding is available */
    *pXnLink = TRUE;

    /* 25A FGR-MC1010 FR10, If UE's serving GUAMI is NOT available, Don't select XN HO. */
    uint16_t pldGnbIdx = MAX_GNB_PER_SYS;
    if (GOOD != VRRM_CheckGuamiAvailCurrentAMF(ptCi, TRUE, &pldGnbIdx))
    {
        ngHoSelectionCause = NG_HO_CAUSE_NO_AVAIL_SERV_GUAMI;
        VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION(
                ptCi, "XN HO Not Allowed: Not available serving GUAMI - GnbIdx(%u)!\n", pldGnbIdx);
        return GOOD;
    }   

    /* Check Handover Priority */
    if (TRUE == ptCi->hoInfo.needNgHO)
    {
        ngHoSelectionCause = NG_HO_CAUSE_NG_HIGHER_PRIORITY;
        VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION(
            ptCi, "XN HO Not Allowed: NG's priority was defined higher. Ng Handover Start!\n");
        return GOOD;
    }

    /* check HO Black List */
    if (TRUE == VLIB_IsHoBlackListXn(ptCi->gnbNum, pGnbId))
    {
        ngHoSelectionCause = NG_HO_CAUSE_BLACK_LIST_XN;
        VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION(
            ptCi, "XN HO Not Allowed: Target is HoBlackListXn. not allow Xn-HO!\n");
        return GOOD;
    }

    if (xnIdx < MAX_XN_NBR_PER_GNB)
    {
        /* Search Service PLMN and Region In EndPointXn */
        amfIdx = VHCM_FindSameRegionAmfByServedGuami(pXnNbr, &ptCi->servedGuami);
        if (amfIdx >= MAX_AMF_SET_INFO)
        {
            ngHoSelectionCause = NG_HO_CAUSE_NO_SAME_REGION_ID_AMF;
            VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION(
                ptCi, "XN HO Not Allowed: Cannot find SameRegionAmfByServedGuami!\n");
            return GOOD;
        }

        /* Check Inter-Plmn */
        if (VCOM_CheckPlmnIdentical(&ptCi->ueInfo.servedPlmn, &ptCi->hoInfo.selectedTAI.plmn) ==
            FALSE)  // Inter-Plmn Handover
        {
            // check inter plmn handover
            if (VHCM_FindSameRegionAmfByServedGuamiForInterPlmn(ptCi, pXnNbr) == FALSE)
            {
                ngHoSelectionCause = NG_HO_CAUSE_NO_SELECTED_PLMN;
                VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION(
                    ptCi, "XN HO Not Allowed: Target gnb is not supported selected Plmn!\n");
                return GOOD;
            }

            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Inter-Plmn Xn Condition (%X -> %X/%u)!!\n",
                ptCi->ueInfo.servedPlmn.longId, ptCi->hoInfo.selectedTAI.plmn.longId, ptCi->hoInfo.selectedTAI.tac);
        }
    }

    /* Selected XN */
    *pInterfaceType = HO_TYPE_XN;
    ptCi->endPointInfo.xnIdx = xnIdx;

    VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION(ptCi, "XN HO Allowed(%u)!\n", xnIdx);

    return GOOD;
}  // }}}

/****************************************************************************
 * @brief           Determines the Handover method when a Handover is triggered.
 * @details         Choose between Intra-DU and Inter-DU in Intra-gNB Handover.
 * @param[in]       ptCi : Pointer of callInfo_type
 * @param[in]       targetCellNum : cellNum of Target NCGI in Intra-gNB
 * @param[out]      pHoType : Point of enumHoTypeDu
 * @return          int16_t (GOOD, ERROR)
 ****************************************************************************/
int16_t VHCM_DecisionIntraGnbSaHandoverType(callInfo_type *ptCi, uint32_t targetCellNum, enumHoTypeDu *pDuType)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDuType);

    VCCB_CHECK_VALID_CELLNUM_ERROR(targetCellNum);
    const VccbCellInfo_type *const pCell = &CELLINFO[targetCellNum];
    if (ptCi->endPointInfo.f1Idx == pCell->endPointF1Index)
    {
        *pDuType = HO_TYPE_INTRA_DU;
    }
    else
    {
        *pDuType = HO_TYPE_INTER_DU;
    }

    return GOOD;
}  // }}}

uint16_t FnVCCB_ConvertNbrIdxToTargetCellForIntraGnb(uint16_t servCellNum, uint16_t nbrIdx)
{
    uint16_t targetCellNum;

    if (MAX_CELL_NUM_VCCB <= servCellNum || MAX_NBR_PER_CELL <= nbrIdx)
    {
        return MAX_CELL_NUM_VCCB;
    }
    VCCB_GET_INTRA_GNB_NBR_CELLNUM(servCellNum, nbrIdx, targetCellNum);  // Convert nbrIdx to CellNum

    if (targetCellNum < MAX_CELL_NUM_VCCB)
        return targetCellNum;
    else
        return MAX_CELL_NUM_VCCB;
}

void FnVCCB_SetIntraGnbCommonHoInfo(
    callInfo_type *ptCi, const cellSelection_type targetCellSelection, uint16_t cause, uint8_t initiated, enumHoTypeDu duType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(targetCellSelection.cellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pCell = &CELLINFO[targetCellSelection.cellNum];
    ptCi->hoInfo.cause = cause;
    ptCi->hoInfo.isTarget = FALSE;
    ptCi->hoInfo.hoGnbIdx = MAX_GNB_PER_CALL;  // not used
    ptCi->hoInfo.cgi = FnVCCB_GetNrcgiFromCellNum(targetCellSelection.cellNum);
    ptCi->hoInfo.phyCellId = pCell->phyCellId;
    ptCi->hoInfo.targetCellNum = targetCellSelection.cellNum;
    ptCi->hoInfo.targetCellBand = targetCellSelection.bandNr;
    ptCi->hoInfo.targetDu.duUEid = ptCi->auCallId;
    ptCi->hoInfo.targetDu.f1Idx = pCell->endPointF1Index;
    ptCi->hoInfo.cellIdentity = pCell->cellIdentity;
    ptCi->hoInfo.hoType.system = HO_TYPE_INTRA_SYSTEM;
    ptCi->hoInfo.hoType.rat = HO_TYPE_INTRA_RAT;
    ptCi->hoInfo.hoType.nb = HO_TYPE_INTRA_NB;
    ptCi->hoInfo.hoType.du = duType;
    ptCi->hoInfo.hoType.initiated = initiated;

    uint8_t reportType, reportPurpose;
    GET_HO_REPORT_TYPE_AND_PURPOSE(ptCi, reportType, reportPurpose);

    // rollback to 25b
    //ptCi->hoInfo.isVoNRBorderMobility = FnVCCB_IsVoNRBorderMR(*ptCi, reportType, reportPurpose);
    ptCi->hoInfo.isVoNRBorderMobility = FnVCCB_IsVoNRBorderMR(*ptCi, ptCi->saHoMrQueueInfo.reportType, ptCi->saHoMrQueueInfo.reportPurpose);
    ptCi->hoInfo.isSpecificSliceForcedMobilityTargetUe 
        = FnVCCB_IsSpecificSliceForcedMR(*ptCi, reportType, reportPurpose);

    VLIB_InitMGapDuData(ptCi->hoInfo.mGapDuTarget);
    ptCi->hoInfo.ulGapFr2ConfigDu.usage = VCCB_FLAG_OFF;
}

int16_t FnVCCB_AllocateUPAndE1Setup(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    int16_t status;

    // When there are MN DRB or There is no MR-DC or SN Release,
    // TODO: A case in which INTER_Pre_SN_T is changed to SN Release should be considered.
    if (GOOD != VRRM_AUPFSelection(ptCi))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "No available AUPF !!\n");
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalUpAllocationFail);
        return ERROR;
    }

    // PDU Session, DRB, Forwarding
    status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextSetup);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Setup) ERROR!\n");

    VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextSetup_id);

    return status;
}

bool FnVCCB_IsPduSessionResourceModify(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (!IS_MRDC(ptCi)) return false;

    if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
    {
        // when SN term bearer is used
        if (true == FnVCCB_IsAnySnTermPerUE(ptCi, current_bearerType))
        {
            return true;
        }

        return false;
    }

    if (FnVCCB_IsInterSnMobilityInMn(ptCi))
    {
        if (true == FnVCCB_IsAnySnTermPerUE(ptCi, request_bearerType))
        {
            return true;
        }

        return false;
    }

    return false;
}

void FnVCCB_SendXN_UEContextReleaseAfterHO(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (IS_MRDC(ptCi))
    {
        uint8_t targetXN = e_TargetXN_initValue;
        if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
        {
            targetXN = e_Snode_MnToSrcSn;
        }
        else if (FnVCCB_IsInterSnMobilityInMn(ptCi))
        {
            targetXN = e_Snode_MnToSrcSn;
        }

        if (targetXN != e_TargetXN_initValue)
        {
            if (ERROR == FnVCCB_SendXNMessage(XN_UEContextRelease_id, ptCi, &targetXN, nullptr))
            {
                VCCB_PRINT_ERROR("FnVCCB_SendXNMessage(XN_UEContextRelease_id) ERROR!!\n");
            }

            OFF_MRDC_RSC_SETUP_FLAG(xn_snConn); // Intra-MN Intra-DU with UE Ctxt Release
        }
    }

    return;
}  // }}}

// }}}

/****************************************************************************
                        Next Step Common
****************************************************************************/
// {{{

// Common_DU
VCCB_STATIC_INLINE
void FnVCCB_UpdateScgXnU_DlTnl(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    for (int drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        callDRBInfo_type * ptDi = &ptCi->drb[drbIdx];
        if (ptDi->usage != CI_use) continue;
        if (ptDi->xNuDlInfo.fNeedModify == 1)
        {
            ON_E1_MRDC_CTRL_FLAG(drbIdx, scgMod_xNuDlTnl);
        }
    }
}

// Common_DU_SnAdd

int16_t FnVCCB_Common_DU_SnAdd_XN_SNodeAdditionRequestAcknowledge(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    // Intra-MN with SN Change
    uint16_t notAllowedCause = 0;
    if (FnVCCB_IsAllowedSnodeAdditionRequestAcknowledge(ptCi, ptAll, ptUnpack, &notAllowedCause) == Not_Allowed)
    {
        status = FnVCCB_ProcNotAllowedSnodeAdditionRequestAcknowledge(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_ProcNotAllowedSnodeAdditionRequestAcknowledge ERROR !! \n");

        if (ptCi->hoInfo.hoType.du == HO_TYPE_INTRA_DU)
        {
            status = FnVCCB_NextStep_INTRA_DU_RunE1Stop_Or_RunAfterE1Stop(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_RunE1Stop_Or_RunAfterE1Stop ERROR!\n");
        }
        else
        {
            if (FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType) == true)
            {
                status = FnVCCB_NextStep_INTER_DU_E1Stop(ptCi);
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_E1Stop!\n");
                return GOOD;
            }
            else
            {
                // For Intra-MN Inter-DU without SN Change(Intra-SN)
                if (FnVCCB_IsIntraSnMobilityInMn(ptCi))
                {
                    status = FnVCCB_NextStep_INTER_DU_SnMod(ptCi); // Intra-MN Inter-DU without SN Change(Intra-SN)
                    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_SnMod!\n");
                    return GOOD;
                }

                // For Intra-MN Intra-DU with SN Release
                if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
                {
                    status = FnVCCB_NextStep_INTER_DU_SnRelA(ptCi);
                    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_SnRelA!\n");
                    return GOOD;
                }

                VCCB_PRINT_CALL_ERROR(ptCi, "Unknown Handover Scenario!! (isInter: %d)\n", (int)FnVCCB_IsInterSnMobilityInMn(ptCi));
                return ERROR;
            }
        }

        return GOOD;
    }

    status = FnVCCB_CommonMsgProc_XN_SNodeAddition(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    switch (status)
    {
        case ERROR:
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_CommonMsgProc_XN_SNodeAddition(Response) ERROR !!\n");
            return status;
        // case RESPONSE_WITH_PARTIAL_SUCCESS:      //TODO: RESPONSE_WITH_PARTIAL_SUCCESS is not yet supported.
        //     VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : Intra-MN HO doesn't allow partial HO!!\n");
        //     return ERROR;
        default:
            break;
    }

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_PrepSucc);

    FnVCCB_UpdateScgXnU_DlTnl(ptCi);

    if (ptCi->hoInfo.hoType.du == HO_TYPE_INTRA_DU)
    {
        status = FnVCCB_NextStep_INTRA_DU_RunE1Stop_Or_RunAfterE1Stop(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_RunE1Stop_Or_RunAfterE1Stop ERROR!\n");
        return GOOD;
    }
    else
    {
        if (FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType) == true)
        {
            status = FnVCCB_NextStep_INTER_DU_E1Stop(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_E1Stop!\n");
            return GOOD;
        }
        else
        {
            status = FnVCCB_NextStep_INTER_DU_Prepare(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_Prepare ERROR!\n");
            return GOOD;
        }
    }
}

int16_t FnVCCB_Common_DU_SnAdd_XN_SNodeAdditionRequestReject(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_CommonMsgProc_XN_SNodeAddition(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeAddition(Failure) ERROR !!\n");

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_XnFail);

    status = FnVCCB_UpdateBearerTypeForHandover(ptCi, MrdcHoWithSnRelease);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_UpdateBearerTypeForHandover ERROR !! \n");

    // It needs to be called again because the Meas configuration needs to be changed according to the scenario change.
    // Scenario : Scenario Change From 'Intra-MN Intra/Inter-DU with SN Change' To 'Intra-MN Intra/Inter-DU with SN Release' by 'Snode Addition Reject'.
    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");

    if (ptCi->hoInfo.hoType.du == HO_TYPE_INTRA_DU)
    {
        status = FnVCCB_NextStep_INTRA_DU_RunE1Stop_Or_RunAfterE1Stop(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_RunE1Stop_Or_RunAfterE1Stop ERROR!\n");
    }
    else
    {
        if (FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType) == true)
        {
            status = FnVCCB_NextStep_INTER_DU_E1Stop(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_E1Stop!\n");
            return GOOD;
        }
        else
        {
            // For Intra-MN Inter-DU without SN Change(Intra-SN)
            if (FnVCCB_IsIntraSnMobilityInMn(ptCi))
            {
                status = FnVCCB_NextStep_INTER_DU_SnMod(ptCi); // Intra-MN Inter-DU without SN Change(Intra-SN)
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_SnMod!\n");
                return GOOD;
            }

            // For Intra-MN Intra-DU with SN Release
            if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
            {
                status = FnVCCB_NextStep_INTER_DU_SnRelA(ptCi);
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_SnRelA!\n");
                return GOOD;
            }

            VCCB_PRINT_CALL_ERROR(ptCi, "Unknown Handover Scenario!! (isInter: %d)\n", (int)FnVCCB_IsInterSnMobilityInMn(ptCi));
            return ERROR;
        }
    }

    return GOOD;
}

int16_t FnVCCB_Common_DU_SnAdd_timXN_SNodeAddition(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_CommonMsgProc_XN_SNodeAddition(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeAddition(TMOUT) ERROR !!\n");

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_XnFail);

    status = FnVCCB_UpdateBearerTypeForHandover(ptCi, MrdcHoWithSnRelease);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_UpdateBearerTypeForHandover ERROR !! \n");

    // It needs to be called again because the Meas configuration needs to be changed according to the scenario change.
    // Scenario : Scenario Change From 'Intra-MN Intra/Inter-DU with SN Change' To 'Intra-MN Intra/Inter-DU with SN Release' by 'Snode Addition TMOUT'.
    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");

    if (ptCi->hoInfo.hoType.du == HO_TYPE_INTRA_DU)
    {
        status = FnVCCB_NextStep_INTRA_DU_RunE1Stop_Or_RunAfterE1Stop(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_RunE1Stop_Or_RunAfterE1Stop ERROR!\n");
    }
    else
    {
        if (FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType) == true)
        {
            status = FnVCCB_NextStep_INTER_DU_E1Stop(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_E1Stop!\n");
            return GOOD;
        }
        else
        {
            // For Intra-MN Inter-DU without SN Change(Intra-SN)
            if (FnVCCB_IsIntraSnMobilityInMn(ptCi))
            {
                status = FnVCCB_NextStep_INTER_DU_SnMod(ptCi); // Intra-MN Inter-DU without SN Change(Intra-SN)
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_SnMod!\n");
                return GOOD;
            }

            // For Intra-MN Intra-DU with SN Release
            if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
            {
                status = FnVCCB_NextStep_INTER_DU_SnRelA(ptCi);
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_SnRelA!\n");
                return GOOD;
            }

            VCCB_PRINT_CALL_ERROR(ptCi, "Unknown Handover Scenario!! (isInter: %d)\n", (int)FnVCCB_IsInterSnMobilityInMn(ptCi));
            return ERROR;
        }
    }

    return GOOD;
}  //}}}

// Common_DU_SnMod
int16_t FnVCCB_Common_DU_SnMod_XN_SNodeModificationRequestAcknowledge(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    // Intra-MN without SN Change
    if (FnVCCB_IsAllowedSnodeModificationRequestAcknowledge(ptCi, ptAll, ptUnpack) == Not_Allowed)
    {
        status = FnVCCB_ProcNotAllowedSnodeModificationRequestAcknowledge(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_ProcNotAllowedSnodeModificationRequestAcknowledge ERROR !! \n");

        if (ptCi->hoInfo.hoType.du == HO_TYPE_INTRA_DU)
        {
            status = FnVCCB_NextStep_INTRA_DU_SnRelA(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_SnRelA ERROR!\n");
        }
        else
        {
            status = FnVCCB_NextStep_INTER_DU_SnRelA(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_SnRelA ERROR!\n");
        }

        return GOOD;
    }

    status = FnVCCB_CommonMsgProc_XN_SNodeModificationRequest(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    if (status == ERROR)
    {
        MACRO_RESET_CALL_FAULT_CAUSES;
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeModificationRequest(Ack) ERROR !! \n");
    }

    FnVCCB_UpdateScgXnU_DlTnl(ptCi);

    if (ptCi->hoInfo.hoType.du == HO_TYPE_INTRA_DU)
    {
        status = FnVCCB_NextStep_INTRA_DU_Prepare(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_Prepare Error!\n");
    }
    else
    {
        status = FnVCCB_NextStep_INTER_DU_Prepare(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_Prepare Error!\n");
    }

    return GOOD;
}  // }}}

int16_t FnVCCB_Common_DU_SnMod_XN_SNodeModificationRequestRejectOrTmOut(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_CommonMsgProc_XN_SNodeModificationRequest(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeModificationRequest ERROR !! \n");

    status = FnVCCB_UpdateBearerTypeForHandover(ptCi, MrdcHoWithSnRelease);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_UpdateBearerTypeForHandover ERROR !! \n");

    // It needs to be called again because the Meas configuration needs to be changed according to the scenario change.
    // Scenario : Scenario Change From 'Intra-MN Intra/Inter-DU without SN Change' To 'Intra-MN Intra/Inter-DU with SN Release' by 'Snode Modification Reject or TMOUT'.
    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");

    if (ptCi->hoInfo.hoType.du == HO_TYPE_INTRA_DU)
    {
        status = FnVCCB_NextStep_INTRA_DU_SnRelA(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_SnRelA ERROR!\n");
    }
    else
    {
        status = FnVCCB_NextStep_INTER_DU_SnRelA(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_SnRelA ERROR!\n");
    }

    return status;
}  // }}}

// Common_DU_SnRelA
int16_t FnVCCB_Common_DU_SnRelA_XN_SNodeReleaseRequestAcknowledge(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_CommonMsgProc_XN_SNodeRelease(ptCi, ptAll, ptUnpack, &ptCi->timer);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeRelease(Response) ERROR !!\n");

    // DRB BearerType Change and DRB Forwarding Information Request
    // {{{
    enumE1Procedure_type e1Procedure = E1Procedure_BearerContextSetup;
    uint16_t timerId = timE1_BearerContextSetup_id;

    if (FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType) == true)
    {
        e1Procedure = E1Procedure_BearerContextModification;
        timerId = timE1_BearerContextModification_id;
    }

    status = VEIL_sendE1SetupModRelRequest(ptCi, e1Procedure);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (%s) ERROR!\n",
        e1Procedure == E1Procedure_BearerContextSetup ? "Setup" : "Modi");

    VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timerId);
    // }}}

    return status;
}  // }}}

int16_t FnVCCB_Common_DU_SnRelA_XN_SNodeReleaseReject(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_CommonMsgProc_XN_SNodeRelease(ptCi, ptAll, ptUnpack, &ptCi->timer);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeRelease(Failure) ERROR !!\n");

    return status;
}  // }}}

int16_t FnVCCB_Common_DU_SnRelA_timXN_SNodeRelease(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status;

    status = FnVCCB_CommonMsgProc_XN_SNodeRelease(ptCi, ptAll, ptUnpack, &ptCi->timer);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeRelease(TMOUT) ERROR !!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_Common_DU_SnRelA_E1_BearerContextModificationSuccess(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, CANCEL_TIMER);

    return status;
}  // }}}

int16_t FnVCCB_Common_DU_SnRelA_E1_BearerContextModificationUnsuccess(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, CANCEL_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->cause.e1Cause);

    return status;
}  // }}}

int16_t FnVCCB_Common_DU_SnRelA_timE1_BearerContextModification(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, INIT_TIMER);

    return GOOD;
}  // }}}

int16_t FnVCCB_Common_DU_SnRelA_timE1_BearerContextSetup(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, INIT_TIMER);

    return GOOD;
}  // }}}

// Common_DU_SnRelB
int16_t FnVCCB_Common_DU_SnRelB_XN_SNStatusTransfer(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    OFF_SN_STATUS_FLAG(ptCi->flag.respFlag);

    status = FnVCCB_StoreXNMessage(XN_SNStatusTransfer_id, ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_StoreXNMessage(XN_SNStatusTransfer_id) ERROR !!\n");

    // {{{ SeqNum Transfer From SN to MN
    status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

    VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextModification_id);
    // }}}

    return status;
}

int16_t FnVCCB_Common_DU_SnRelB_timXN_SNStatusTransfer(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    return GOOD;
}  // }}}

int16_t FnVCCB_Common_DU_SnRelB_E1_BearerContextModificationSuccess(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, CANCEL_TIMER);

    if (ptCi->hoInfo.hoType.du == HO_TYPE_INTRA_DU)
    {
        status = FnVCCB_NextStep_INTRA_DU_Prepare(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_Prepare_ERROR!\n");
    }
    else
    {
        status = FnVCCB_NextStep_INTER_DU_Prepare(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_Prepare ERROR!\n");
    }
    return status;
}  // }}}

int16_t FnVCCB_Common_DU_SnRelB_E1_BearerContextModificationUnsuccess(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, CANCEL_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->cause.e1Cause);

    return status;
}  // }}}

int16_t FnVCCB_Common_DU_SnRelB_timE1_BearerContextModification(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, INIT_TIMER);

    return GOOD;
}  // }}}

// Common_DU_Execution
int16_t FnVCCB_Common_DU_Execution_NRRRC_RrcReconfigurationComplete(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, CANCEL_TIMER);

    VHCM_SA_PP_HO_STAT(ptCi);

    status = VRIL_storeNRRRC_RrcReconfigurationComplete(ptCi, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VRIL_storeNRRRC_RrcReconfigurationComplete ERROR!\n");

    if (ptCi->hoInfo.hoType.du == HO_TYPE_INTRA_DU)
    {
        if (ptCi->servCellNum != ptCi->hoInfo.targetCellNum)
        {
            VLIB_startLoggedMdtTrace(ptCi, ptCi->hoInfo.targetCellNum);
        }
    }
    else
    {
        VLIB_startLoggedMdtTrace(ptCi, ptCi->hoInfo.targetCellNum);
    }

    OFF_RRC_CONNECTION_FLAG(ptCi->flag.respFlag);

    FnVCCB_SetConditionalCellReleaseAllEvent(ptCi, false, CHO_CandidateRel_gNBCancel);
    FnVCCB_InitializationChoDbForExecution(ptCi);  // SA, Intra-GNB HO, Intra/Inter-DU

    if (ComTimeUtil::get_current_time(ptCi->ueHistory.startTime) < 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ComTimeUtil::get_current_time ERROR in %s\n", __func__);
    }

    VLIB_SAHandoverTime(ptCi, CAL_STOP);
    return GOOD;
}  // }}}

int16_t FnVCCB_Common_DU_Execution_timNRRRC_RRCReconfig(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);
    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, INIT_TIMER);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_RrcFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_RrcTimeOut);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaHoTmOutRrcHandoverComplete);

    return GOOD;
}  // }}}

int16_t FnVCCB_Common_DU_Execution_E1_BearerContextModificationSuccess(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, CANCEL_TIMER);

    OFF_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    if (ptCi->hoInfo.hoType.du == HO_TYPE_INTRA_DU)
    {
        uint8_t srbIdx;
        callSRBInfo_type *ptSi = NULL;

        if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi))
        {
            /* init SRB PDCP for full configuration */
            for (srbIdx = ID_SRB1 - 1; srbIdx <= ID_SRB2 - 1; srbIdx++)
            {
                ptSi = &(ptCi->srbInfo[srbIdx]);

                if (!IS_VALID_NODE(SRB_NODE, ptCi, (ptSi))) continue;

                if (0 != FnPDCP_C_Init(&ptSi->pdcpRbContext, ptSi->rbInfo.rbId))
                {
                    continue;
                }
            }
        }
    }

    return GOOD;
}  // }}}

int16_t FnVCCB_Common_DU_Execution_E1_BearerContextModificationUnsuccess(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, CANCEL_TIMER);

    FnVCCB_CollectingSaHandoverStatistics_E1Fail(ptCi);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->cause.e1Cause);

    return GOOD;
}  // }}}

int16_t FnVCCB_Common_DU_Execution_timE1_BearerContextModification(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, INIT_TIMER);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_UpFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_E1TimeOut);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    return GOOD;
}  // }}}

int16_t FnVCCB_Common_DU_Execution_XN_SNodeReleaseRequestAcknowledge(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_CommonMsgProc_XN_SNodeRelease(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeRelease(Response) ERROR !!\n");

    if (FnVCCB_IsAnySnTermPerUE(ptCi, request_bearerType) == true)
    {
        uint8_t targetXN = e_Snode_MnToSrcSn;
        status = FnVCCB_SendXNMessage(XN_XnUAddressIndication_id, ptCi, &targetXN, nullptr);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_XnUAddressIndication_id ERROR!\n");
    }

    if (FnVCCB_NeedWaitForSNStatus(ptCi))  // AMBearer Check O, SplitBearer Check X
    {
        VLIB_AttachTimer(&ptCi->timer, ptCi, timXN_SnStatusTransfer_id);

        // Waiting for the SN(SeqNum) STATUS of the SN(SNode) is performed.
        ON_SN_STATUS_FLAG(ptCi->flag.respFlag);
    }

    return status;
}

int16_t FnVCCB_Common_DU_Execution_XN_SNodeReleaseReject(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_CommonMsgProc_XN_SNodeRelease(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeRelease(Failure) ERROR !!\n");

    return status;
}  // }}}

int16_t FnVCCB_Common_DU_Execution_timXN_SNodeRelease(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status;

    status = FnVCCB_CommonMsgProc_XN_SNodeRelease(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeRelease(TMOUT) ERROR !!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_Common_DU_Execution_XN_SNStatusTransfer(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    OFF_SN_STATUS_FLAG(ptCi->flag.respFlag);

    status = FnVCCB_StoreXNMessage(XN_SNStatusTransfer_id, ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_StoreXNMessage(XN_SNStatusTransfer_id) ERROR !!\n");

    uint8_t targetXN = e_Snode_MnToTgtSn;
    status = FnVCCB_SendXNMessage(XN_SNStatusTransfer_id, ptCi, &targetXN, nullptr);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_SNStatusTransfer) ERROR!\n");

    return GOOD;
}

int16_t FnVCCB_Common_DU_Execution_timXN_SnStatusTransfer(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    OFF_SN_STATUS_FLAG(ptCi->flag.respFlag);

    return GOOD;
}  // }}}

// Common_DU_Complete
int16_t FnVCCB_Common_DU_Complete_E1_BearerContextModificationSuccess(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, CANCEL_TIMER);

    OFF_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    if (true == FnVCCB_IsPduSessionResourceModify(ptCi))  // when SN term bearer is used
    {
        auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_PDUSessionResourceModifyIndication_id);
        VALID_E_POINT_CHECK_ERROR(ngapSender);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, ngapSender->sendMsg(), "sendMsg(NG_PDUSessionResourceModifyIndication) ERROR!\n");

        ON_PDUSESS_MODIFY_CONFIRM_FLAG(ptCi->flag.respFlag);

        VLIB_AttachTimer(&ptCi->timer, ptCi, timNG_PDUSessModifyConfirm_id);
    }

    return GOOD;
}  // }}}

int16_t FnVCCB_Common_DU_Complete_timE1_BearerContextModification(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, INIT_TIMER);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_UpFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_E1TimeOut);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    return GOOD;
}  // }}}

int16_t FnVCCB_Common_DU_Complete_F1_UEContextModificationResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, CANCEL_TIMER);

    status = VFIL_storeF1_UeContextModificationResponse(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationResponse ERROR !!\n");

    OFF_F1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    return GOOD;
}  // }}}

int16_t FnVCCB_Common_DU_Complete_F1_UEContextModificationFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, CANCEL_TIMER);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_F1Fail);

    status = VFIL_storeF1_UeContextModificationFailure(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationFailure ERROR !!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_Common_DU_Complete_timF1_UeContextModification(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, INIT_TIMER);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_F1TimeOut);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutF1UeContextModification);

    return GOOD;
}  // }}}

int16_t FnVCCB_Common_DU_Complete_NG_PDUSessionResourceModifyConfirm(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status = GOOD;

    status = FnVCCB_CommonMsgProc_NG_PDUSessionResourceModifyIndication(ptCi, ptAll, ptUnpack, &ptCi->timer);
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, status, "FnVCCB_CommonMsgProc_NG_PDUSessionResourceModifyIndication(Response) ERROR !!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_Common_DU_Complete_timNG_PDUSessModifyConfirm(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status = GOOD;

    status = FnVCCB_CommonMsgProc_NG_PDUSessionResourceModifyIndication(ptCi, ptAll, ptUnpack, &ptCi->timer);
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, status, "FnVCCB_CommonMsgProc_NG_PDUSessionResourceModifyIndication(TMOUT) ERROR !!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_Common_DU_SnRelA(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    FnVCCB_set_MrdcSnRelMnEvent(ptCi, StatMrdcSnRelMn_MnInit_IntraMnMobility);

    // reference : FnVCCB_MrdcSNRelPrepare
    SET_MRDC_PROCEDURE(ptCi, MRDC_PROC_CODE_SnRel, 0, MRDC_PROC_INITIATOR_MN);

    // TX Stop to SN
    // {{{
    uint8_t targetXN = 0;
    status = FnVCCB_SendXNMessage(XN_SNodeReleaseRequest_id, ptCi, &targetXN, nullptr);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_SNodeReleaseRequest_id) ERROR!\n");

    ON_SN_NODE_REL_ACK_RCV_FLAG(ptCi->flag.respFlag);

    VLIB_AttachTimer(&ptCi->timer, ptCi, timXN_SNodeRelease_id);
    // }}}

    // Since the SN Release message has been delivered, it is determined that recovery is impossible.
    ptCi->hoInfo.cancelControl.needSnRelease = true;

    return GOOD;
} // }}}

int16_t FnVCCB_NextStep_Common_DU_SnRelB(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint8_t targetXN = 0;
    status = FnVCCB_SendXNMessage(XN_XnUAddressIndication_id, ptCi, &targetXN, nullptr);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage (XN_XnUAddressIndication) ERROR!\n");

    if (FnVCCB_NeedWaitForSNStatus(ptCi))  // AMBearer Check O, SplitBearer Check X
    {
        if (FnVCCB_IsSnStatusReceivedFromSNode(ptCi) == true)
        {
            // {{{ SeqNum Transfer From SN to MN
            status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

            VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextModification_id);
            // }}}
        }
        else
        {
            VLIB_AttachTimer(&ptCi->timer, ptCi, timXN_SnStatusTransfer_id);

            // Waiting for the SN(SeqNum) STATUS of the SN(SNode) is performed.
            ON_SN_STATUS_FLAG(ptCi->flag.respFlag);
        }

        return GOOD;
    }

    if (ptCi->hoInfo.hoType.du == HO_TYPE_INTRA_DU)
    {
        status = FnVCCB_NextStep_INTRA_DU_Prepare(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_Prepare ERROR!\n");
    }
    else
    {
        status = FnVCCB_NextStep_INTER_DU_Prepare(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_Prepare ERROR!\n");
    }

    return GOOD;
} // }}}

int16_t FnVCCB_NextStep_Common_DU_Execution(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // 21D Intra DU SN Change (Release source SN)
    // TODO: need to add with function to check the SN Change procedures
    if (FnVCCB_IsInterSnMobilityInMn(ptCi))
    {
        FnVCCB_set_MrdcSnRelMnEvent(ptCi, StatMrdcSnRelMn_MnInit_IntraMnMobilityWithSnChange);

        uint8_t targetXN = e_Snode_MnToSrcSn;
        status = FnVCCB_SendXNMessage(XN_SNodeReleaseRequest_id, ptCi, &targetXN, nullptr);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_SNodeReleaseRequest) ERROR!!\n");

        if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_config_ue)
        {
            // Not DRB Release Case
            INIT_MRDC_PROCEDURE(ptCi);
        }

        ON_SN_NODE_REL_ACK_RCV_FLAG(ptCi->flag.respFlag);

        VLIB_AttachTimer(&ptCi->hoInfo.timer.xn, ptCi, timXN_SNodeRelease_id);
    }

    // E1 Modification, If need Full Configuration, send E1 Modi Req (SN=0, VersionChangeInd)
    if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi))
    {
        // Full configuration is done based on the final target. This is because the MN/SN DRB considers the
        // reallocation situation.
        if (FnVCCB_IsAnyMnTermPerUE(ptCi, request_bearerType))
        {
            status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

            VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextModification_id);
        }
    }

    return GOOD;
} // }}}

int16_t FnVCCB_NextStep_Common_Complete(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // RRC Reconfiguration Complete Indicator
    status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextModificationRequest ERROR!\n");

    VLIB_AttachTimer(&ptCi->hoInfo.timer.f1, ptCi, timF1_UeContextModification_id);

    // Send XN complete
    if (IS_MRDC(ptCi))
    {
        if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_config_ue)
        {
            // Send XN Reconfiguration
            if (FnVCCB_NeedToSendXnSNodeReconfigurationComplete(ptCi) == true)
            {
                uint8_t targetXN = 0;
                if (FnVCCB_IsInterSnMobilityInMn(ptCi))
                {
                    targetXN = e_Snode_MnToTgtSn;
                }

                status = FnVCCB_SendXNMessage(XN_SNodeReconfigurationComplete_id, ptCi, &targetXN, nullptr);
                VCCB_RETURN_ON_CALL_ERROR(
                    ptCi, status, "FnVCCB_SendXNMessage(XN_SNodeReconfigurationComplete_id) Error!!\n");
            }

            VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Succ);
        }
    }

    // It operates only when MN Term UP exists. (If UP exists, MN E1 Resume control takes precedence.)
    if (FnVCCB_IsAnyMnTermPerUE(ptCi, request_bearerType) == true)
    {
        // RESUME
        status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

        // start the timer
        VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextModification_id);
    }
    else if (true == FnVCCB_IsPduSessionResourceModify(ptCi))  // when SN term bearer is used
    {
        auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_PDUSessionResourceModifyIndication_id);
        VALID_E_POINT_CHECK_ERROR(ngapSender);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, ngapSender->sendMsg(), "sendMsg(NG_PDUSessionResourceModifyIndication) ERROR!\n");

        ON_PDUSESS_MODIFY_CONFIRM_FLAG(ptCi->flag.respFlag);

        VLIB_AttachTimer(&ptCi->timer, ptCi, timNG_PDUSessModifyConfirm_id);
    }

    return GOOD;
} // }}}

// Common_DU_Cancel
void VCCM_Common_DU_Cancel_E1_BearerContextModificationSuccess(callInfo_type *ptCi, unsigned short msgId)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    
    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    OFF_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    VCOM_SaHandoverCancel_ToConn(ptCi, msgId);
}  // }}}

void VCCM_Common_DU_Cancel_E1_BearerContextModificationUnsuccess(callInfo_type *ptCi, unsigned short msgId)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    
    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(msgId, ptCi->cause.e1Cause);
}  // }}}

int16_t VCCM_Common_DU_Cancel_timE1_BearerContextModification(callInfo_type *ptCi, unsigned short msgId)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    
    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(msgId, CauseCpInternalTmOutE1BearerContextModification);

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_Common_DU_Cancel(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    if (ptCi->hoInfo.hoType.du == HO_TYPE_INTRA_DU)
    {
        // When handover cancellation occurs, the reason for call fault is initialized.
        // - If a call fault occurs in the Cancel procedure, it is not collected.
        MACRO_RESET_CALL_FAULT_CAUSES;
    }

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    if (ptCi->hoInfo.hoType.du == HO_TYPE_INTRA_DU)
    {
        VLIB_SetCurStateAll(ptCi, STATE_INTRA_DU_Cancel);
    }
    else
    {
        VLIB_SetCurStateAll(ptCi, STATE_INTER_DU_Cancel);
    }

    // RESUME (Perform the recovery procedure to get to Conn)
    status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

    VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);

    return GOOD;
}  // }}}

// }}}
/****************************************************************************
                        Conditional Handover
****************************************************************************/
// {{{

/****************************************************************
 *  Function             : FnVCCB_NextStep_CondReconfig
 *  Description          : go to next state STATE_CondReconfig
 *  Input                : callInfo_type*
 *  Output               : int16_t (GOOD/ERROR)
 ***************************************************************/
int16_t FnVCCB_NextStep_CondReconfig(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int16_t status = GOOD;

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_CondReconfig);
    SET_STATE_CMD(CondReconfig_cmd);

    // FGR-MC1400 FR90.CACP.SR1.HD1.VCCB.DD1
    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");

    // Handles the case where MeasId is missing.
    {
        for (uint8_t condCellIdx = 0; condCellIdx < MAX_NUM_COND_CELLS; condCellIdx++)
        {
            uint8_t condStatus = Common_Idle;
            conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForIndex(ptCi, condCellIdx);

            if (ptCondCell == NULL) continue;

            if (FnVCCB_CheckNeedCondCellProcessing(ptCondCell) == false) continue;

            FnVCCB_CheckChangedUeMeasConfig(ptCondCell, &condStatus);

            // Detect Event Change
            if (condStatus == ptCondCell->condStatus) continue;

            switch (condStatus)
            {
                case Common_Idle:
                    continue;

                case Common_Release:
                    FnVCCB_SetConditionalCellReleaseEvent(ptCi, ptCondCell, CHO_CandidateRel_ConfigChange);
                    break;

                case Common_Modify:
                    FnVCCB_SetConditionalCellModifyEvent(ptCi, ptCondCell);
                    break;

                case Common_FailToSetup:
                    FnVCCB_SetConditionalCellModifyEvent(ptCi, ptCondCell);
                    break;

                default:
                    VCCB_PRINT_CALL_ERROR(ptCi, "Unknown Conditional Status(%u, %u) in %s (Release!)\n", condCellIdx,
                        condStatus, __func__);
                    FnVCCB_SetConditionalCellReleaseEvent(ptCi, ptCondCell, CHO_CandidateRel_ConfigChange);
                    break;
            }
        }
    }

    status = FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer(ptCi, FALSE, FALSE, ID_SRB1);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer ERROR !!\n");
    if (status == BREAK)
    {
        // If there is no data to configure RRC Reconfiguration, commit immediately.
        FnVCCB_ConditionalCellConfigCommit(ptCi);

        VLIB_SetCurStateAll(ptCi, STATE_Conn);
        SET_STATE_CMD(Idle_cmd);

        return GOOD;
    }

    // RRC Reconfiguration Complete
    VLIB_AttachTimer(&ptCi->timer, ptCi, timNRRRC_RRCReconfig_id);

    return GOOD;
} // }}}

// }}}
/****************************************************************************
                          Inter gNB serving
****************************************************************************/
// {{{

/****************************************************************
 *  Function             : FnVCCB_NextStep_INTER_Pre_DU_S
 *  Description          : go to next state STATE_INTER_Pre_SN_T
 *  Input                : callInfo_type*
 *  Output               : int16_t (GOOD/ERROR)
 ***************************************************************/
int16_t FnVCCB_NextStep_INTER_Pre_DU_S(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTER_Pre_DU_S);

    // F1 Interface
    {
        ptCi->ueInfo.duConfQuery = VCCB_FLAG_ON;
        status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
        ptCi->ueInfo.duConfQuery = VCCB_FLAG_OFF;
        if (status == ERROR)
        {
            // TODO : clear DB
            VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_sendF1_UeContextModificationRequest ERROR !!\n");
            return ERROR;
        }
    }

    // FR300.CACP.SR1.HD1.VCCB.DD1 in FGR-CC5101 Mobility for NE-DC
    if (IsAvailable_MrdcInfo())
    {
        if (DBG->flag.nrdcScgQuerySkip == VCCB_FLAG_OFF)
        {
            if (IS_ON_MRDC_RSC_SETUP_FLAG(xn_snConn))
            {
                VLIB_Set_MrdcScgConfigQuery(ptCi, VCCB_FLAG_ON);
                status = FnVCCB_SendXNMessage(XN_SNodeModificationRequest_id, ptCi, nullptr, nullptr);
                VLIB_Set_MrdcScgConfigQuery(ptCi, VCCB_FLAG_OFF);
                
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_SNodeModificationRequest_id) Error!!\n");
            }
            else
            {
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "Since SNODE and Link are not normal, Proceed without SNode Modification procedure!!\n");
            }
        }
    }

    VLIB_AttachTimer(&ptCi->timer, ptCi, timInternalHandoverQuery_id);

    return GOOD;
}  // }}}

/****************************************************************
 *  Function             : FnVCCB_NextStep_INTER_Pre_CU_S
 *  Description          : go to next state STATE_INTER_Pre_CU_S
 *  Input                : callInfo_type*
 *  Output               : int16_t (GOOD/ERROR)
 ***************************************************************/
int16_t FnVCCB_NextStep_INTER_Pre_CU_S(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    // FGR-MC1009 FR220, FGR-MC1010 FR220
    if (IS_HO_CANCEL_REQUIRED_FOR_PDU(ptCi))
    {
        // Source gNB should cancel the ongoing handover and 
        // will process the newly requested PDU Session Management procedure

        // HO Cancel and dequeueing
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Cancel HO for PDU session management!! \n");
        VCOM_SaHandoverCancel_ToConn(ptCi, F1_UEContextModificationResponse_id);
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTER_Pre_CU_S);

    // send the handover required (No query for cell group configuration)
    status = VCOM_SendHandoverRequest(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCOM_SendHandoverRequest ERROR !!\n");

    VHCM_SA_HO_STAT(ptCi, HO_Att);
    CHO_STAT(ptCi, CHO_PrepAtt, ptCi->hoInfo.cgi);  // STAT_CHO_OUT

    VLIB_SetSaOutgoingHoTime(ptCi, CAL_START); // Outgoing HO Start Time - IRAT_HO_23B

    return GOOD;
}  // }}}

int16_t FnVCCB_PackHandoverCommand(callInfo_type *ptCi, msgUnpack_type *pStoreMsg, msgContainer_type *pRrcTxBuf)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pStoreMsg);
    VALID_E_POINT_CHECK_ERROR(pRrcTxBuf);

    const long maxRrcLen = sizeof(pRrcTxBuf->data) - NR_PDCP_SRB_HDRMACI_SIZE;
    long tmpRrcLen = maxRrcLen;

    auto setRrcTxBufLen = [ptCi, maxRrcLen](msgContainer_type *pRrcTxBuf_, const char *pDebugName, long tmpRrcLen_)
    {
        if (0 <= tmpRrcLen_ && tmpRrcLen_ <= maxRrcLen)
        {
            pRrcTxBuf_->numocts = (uint16_t)tmpRrcLen_;
            return GOOD;
        }

        VCCB_PRINT_CALL_ERROR(ptCi, "%s is Unknown Value! (cur:%ld, max:%ld)\n", pDebugName, tmpRrcLen_, maxRrcLen);

        pRrcTxBuf_->numocts = 0;
        return ERROR;
    };

    if (ptCi->hoInfo.hoType.rat == HO_TYPE_INTRA_RAT)  // NR -> NR
    {
        // For RRC Reconfiguration PDU
        NRRRC_HandoverCommand *ptMsg = (NRRRC_HandoverCommand *)(&pStoreMsg->unpack[0] + pStoreMsg->unpackMsgOffset);
        NRRRC_HandoverCommand_IEs *ptIE = &ptMsg->criticalExtensions.u.c1.u.handoverCommand;
        unsigned int hoRrcLen = ptIE->handoverCommandMessage.length;

        // For RRC Reconfiguration Message
        if (hoRrcLen >= (MAX_RRC_PDU_LENGTH - 1))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Handover Command is too Big! (cur:%u, max:%u)\n", hoRrcLen, (MAX_RRC_PDU_LENGTH - 1));
            return ERROR;
        }

        // length
        if (ERROR == setRrcTxBufLen(pRrcTxBuf, "handoverCommandMessage", (long)hoRrcLen + 1)) // plus 1 (for shift bit)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "setRrcTxBufLen(handoverCommandMessage) Error!\n");
            return ERROR;
        }

        // data
        memcpy(pRrcTxBuf->data, ptIE->handoverCommandMessage.value, hoRrcLen);
        pRrcTxBuf->data[hoRrcLen] = 0;

        FnVCCB_Buffer_RightShift(pRrcTxBuf->data, pRrcTxBuf->numocts, VCCB_SHIFT_BIT_NUM_FOR_DL_DCCH);
    }
    else  // NR -> LTE
    {
        int16_t status = GOOD;
        uint8_t *p_relay_msg;
        unsigned int relay_len;
        RRC_HandoverCommand *ptMsg = (RRC_HandoverCommand *)&pStoreMsg->unpack[0];

        // get encoded data
        relay_len = ptMsg->criticalExtensions.u.c1.u.handoverCommand_r8.handoverCommandMessage.length;
        p_relay_msg = ptMsg->criticalExtensions.u.c1.u.handoverCommand_r8.handoverCommandMessage.value;

        VCCB_CHECK_E_RANGE_AND_RETURN(relay_len, tmpRrcLen);

        status = MakeMsgNRRRC_MobilityFromNRCommand(ptCi, p_relay_msg, relay_len, pRrcTxBuf->data, &tmpRrcLen);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "MakeMsgNRRRC_MobilityFromNRCommand ERROR!\n");

        if (ERROR == setRrcTxBufLen(pRrcTxBuf, "MakeMsgNRRRC_MobilityFromNRCommand", tmpRrcLen))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "setRrcTxBufLen(MakeMsgNRRRC_MobilityFromNRCommand) Error!\n");
            return ERROR;
        }
    }

    return GOOD;
}  // }}}

/****************************************************************
 *  Function             : FnVCCB_NextStep_INTER_CondReconf_S
 *  Description          : go to next state STATE_INTER_CondReconf_S
 *  Input                : callInfo_type*
 *  Output               : int16_t (GOOD/ERROR)
 ***************************************************************/
int16_t FnVCCB_NextStep_INTER_CondReconf_S(callInfo_type *ptCi, conditionalCellInfo_type *ptPrepCondCell)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptPrepCondCell);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int16_t status = GOOD;
    bool isFailToSetupCase = false;

    uint8_t condStatusInCall[MAX_NUM_COND_CELLS];

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTER_CondReconf_S);

    // Handles the case where MeasId is missing.
    {
        for (uint8_t condCellIdx = 0; condCellIdx < MAX_NUM_COND_CELLS; condCellIdx++)
        {
            condStatusInCall[condCellIdx] = Common_STATUS_END;  // Init
        }

        for (uint8_t condCellIdx = 0; condCellIdx < MAX_NUM_COND_CELLS; condCellIdx++)
        {
            uint8_t condStatus = Common_Idle;
            conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForIndex(ptCi, condCellIdx);

            if (ptCondCell == NULL) continue;

            condStatusInCall[condCellIdx] = ptCondCell->condStatus;

            if (FnVCCB_CheckNeedCondCellProcessing(ptCondCell) == false) continue;

            FnVCCB_CheckChangedUeMeasConfig(ptCondCell, &condStatus);

            // Detect Event Change
            if (condStatus == ptCondCell->condStatus) continue;

            switch (condStatus)
            {
                case Common_Idle:
                case Common_Release:
                case Common_Modify:
                    break;

                case Common_FailToSetup:
                    FnVCCB_SetConditionalCellFailToSetupEvent(ptCi, ptCondCell);
                    isFailToSetupCase = true;
                    break;

                default:
                    VCCB_PRINT_CALL_ERROR(ptCi, "Unknown Conditional Status(%u, %u) in %s (Release!)\n", condCellIdx,
                        condStatus, __func__);
                    condStatus = Common_Release;
                    break;
            }

            condStatusInCall[condCellIdx] = condStatus;
        }
    }

    if (isFailToSetupCase == true)
    {
        // Conditional Cell Cancel (Target : RRC:X, XN:O, DB:O)
        // Other Handover Information Clear & Rollback
        VCOM_SaHandoverCancel_ToConn(ptCi, NRRRC_RrcReconfiguration_id);
        return GOOD;
    }

    // Setup Success, But Other Freq, Need Modify and Release
    for (uint8_t condCellIdx = 0; condCellIdx < MAX_NUM_COND_CELLS; condCellIdx++)
    {
        conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForIndex(ptCi, condCellIdx);

        if (ptCondCell == NULL) continue;

        // Detect Event Change
        if (condStatusInCall[condCellIdx] == ptCondCell->condStatus) continue;

        switch (condStatusInCall[condCellIdx])
        {
            case Common_Release:
                FnVCCB_SetConditionalCellReleaseEvent(ptCi, ptCondCell, CHO_CandidateRel_ConfigChange);
                break;

            case Common_Modify:
                FnVCCB_SetConditionalCellModifyEvent(ptCi, ptCondCell);
                break;

            default:
                VCCB_PRINT_CALL_ERROR(ptCi, "Unknown Conditional Status(%u, %u->%u) in %s\n", condCellIdx,
                    ptCondCell->condStatus, condStatusInCall[condCellIdx], __func__);
                break;
        }
    }

    status = FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer(ptCi, FALSE, FALSE, ID_SRB1);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer ERROR!\n");

    // RRC Reconfiguration Complete
    VLIB_AttachTimer(&ptCi->timer, ptCi, timNRRRC_RRCReconfig_id);

    // candidate-cell-release-timer-source
    FnVCCB_AttachTimerWithSpecificValue(
        &ptPrepCondCell->condCellReleaseTimer, ptCi, timXN_HandoverSuccess_id, ptPrepCondCell->condCellIdx);

    return GOOD;
}

/****************************************************************
 *  Function             : FnVCCB_NextStep_INTER_Exe_S
 *  Description          : go to next state STATE_INTER_Exe_T
 *  Input                : callInfo_type*
 *  Output               : int16_t (GOOD/ERROR)
 ***************************************************************/
int16_t FnVCCB_NextStep_INTER_Exe_S(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int16_t status = GOOD;

    msgContainer_type *pRrcTxBuf = NULL;  // Immediate HO is `Not Null`, Cond Ho is `Null`

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTER_Exe_S);

    if (FnVCCB_IsConditionalHandoverUE(ptCi) == true)
    {
        CHO_STAT(ptCi, CHO_ExeAccess, ptCi->hoInfo.cgi);  // STAT_CHO_OUT
    }
    else
    {
        msgUnpack_type *pStoreMsg = &THREAD_INFO->call[ptCi->myThreadId].buf.unpack.store;

        pRrcTxBuf = &THREAD_INFO->call[ptCi->myThreadId].buf.rrcTx;

        status = FnVCCB_PackHandoverCommand(ptCi, pStoreMsg, pRrcTxBuf);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_PackHandoverCommand(Exe_S) ERROR!\n");
    }

    status = VCCM_INTER_S_ProcHandoverFromPrepToExe(ptCi, pRrcTxBuf);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_INTER_S_ProcHandoverFromPrepToExe ERROR!\n");

    FnVCCB_SetHandoverExecution(ptCi);

    VHCM_SA_HO_STAT(ptCi, HO_PrepSucc);

    return GOOD;
}  // }}}

/****************************************************************
 *  Function             : FnVCCB_NextStep_INTER_SeqNum_S
 *  Description          : go to next state STATE_INTER_Switch_T
 *  Input                : callInfo_type*
 *  Output               : int16_t (GOOD/ERROR)
 ***************************************************************/
int16_t FnVCCB_NextStep_INTER_SeqNum_S(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    auto isNoMessageToBeReceived = [&ptCi]()
    {
        return (VLIB_CheckAllConnected(ptCi) == GOOD);
    };

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTER_SeqNum_S);

#ifdef IPC_TEST  // Data Forwarding & UE Capa
    if (ptCi->hoInfo.hoType.system == HO_TYPE_INTRA_SYSTEM)
        VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "[Forwarding]: Req -> PDU Session Data Fwd info request, DRB Data Fwd Info\n");
    else
        VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "[Forwarding]: Req -> PDU Session Data Fwd info request, PDU Session Data Fwd Information\n");
#endif
    /* Send E1 Bearer Context modification Request */
    /*  IntraRAT Handover
            - PDU Session Data Fwd info request
            - DRB Data Fwd Info
            - PDCP SN Status Request
        InterRAT Handover
            - PDU Session Data Fwd Info Req
            - PDU Session Data Fwd Information(TEID)
    */
    OFF_E1_PDCP_SN_FLAG(ptCi->flag.setupFlag);

    if (FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType) == true)
    {
        status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

        VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextModification_id);
    }

    bool isNeedXnUAddress = false;
    if (IS_MRDC(ptCi))
    {
        // MR-DC Release w/ SN Term
        // If exist SN Term Bearer, Send XnUAddressInd
        // (Don`t care Data Forward Information)
        if (FnVCCB_IsAnySnTermPerUE(ptCi, current_bearerType))
        {
            isNeedXnUAddress = true;

            // If 'ueContextKeptInd == TRUE', SN reused by Target MN.
            // thus, VCCB does not send SN.
            if (ptCi->hoInfo.ueContextKeptInd == TRUE)
            {
                isNeedXnUAddress = false;
            }
        }
    }

    // If 'not exist Data Fwd Info', VCCB don`t care data forwarding Information
    // thus, VCCB dont`t get involved.
    if (isNeedXnUAddress == true)
    {
        uint8_t targetXN = 0;
        status = FnVCCB_SendXNMessage(XN_XnUAddressIndication_id, ptCi, &targetXN, nullptr);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage (XN_XnUAddressIndication) ERROR!\n");

        if (FnVCCB_IsSnStatusReceivedFromSNode(ptCi) == true)
        {
            // no action
            // SN Status has already been received in STATE_INTER_Exe_T.
        }
        else
        {
            bool isNeedWaitSnStatus = true;

            // If Not Wait Condition, SN Status Skip
            if (FnVCCB_NeedWaitForSNStatus(ptCi) == false) isNeedWaitSnStatus = false;

            // If Inter Rat Condition, SN Status Skip
            if (ptCi->hoInfo.hoType.rat == HO_TYPE_INTER_RAT) isNeedWaitSnStatus = false;

            if (isNeedWaitSnStatus == true)
            {
#ifdef IPC_TEST
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[Forwarding]: Wait SnStatus From SNode.\n");
#endif
                ON_SN_STATUS_FLAG(ptCi->flag.respFlag);
                VLIB_AttachTimer(&ptCi->hoInfo.timer.xn, ptCi, timXN_SnStatusTransfer_id);
            }
        }
    }

    if (isNoMessageToBeReceived())
    {
        status = FnVCCB_NextStep_INTER_Compl_S(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_Compl_S ERROR!\n");
    }

    return GOOD;
}  // }}}

/****************************************************************
 *  Function             : FnVCCB_NextStep_INTER_Compl_S
 *  Description          : go to next state STATE_INTER_Compl_T
 *  Input                : callInfo_type*
 *  Output               : int16_t (GOOD/ERROR)
 ***************************************************************/
int16_t FnVCCB_NextStep_INTER_Compl_S(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTER_Compl_S);

    bool needSnStatus = false;

    if (ptCi->hoInfo.hoType.system == HO_TYPE_INTRA_SYSTEM)
    {
        needSnStatus = true;

        // MRDC
        if (IS_MRDC_MN(ptCi))
        {
            // Not Exist MN Term
            if (FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType) == false)
            {
                // no sn data forwarding (wo SN Change)
                if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_config_ue)
                {
                    // skip sn status
                    needSnStatus = false;
                }
            }
        }
    }

    // send the message for Intra System handover case
    if (needSnStatus)
    {
        if (ptCi->hoInfo.hoType.interface == HO_TYPE_XN)
        {
            uint8_t targetXN = e_TargetXN_Handover;
            status = FnVCCB_SendXNMessage(XN_SNStatusTransfer_id, ptCi, &targetXN, nullptr);
            if (ERROR == status) return ERROR;
        }
        else
        {
            auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_UplinkRANStatusTransferAllAmf_id);
            VALID_E_POINT_CHECK_ERROR(ngapSender);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, ngapSender->sendMsg(), "sendMsg(NG_UplinkRANStatusTransferAllAmf) ERROR !!\n");
        }
    }

    return GOOD;
}  // }}}

uint8_t VHCM_CheckNeedToSendDataFwdInfoToUpForHO(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    /* Intra-NR Handover(HO_TYPE_INTRA_SYSTEM), always on to send PDCP SN Status Request */
    if (ptCi->hoInfo.hoType.system == HO_TYPE_INTRA_SYSTEM)
    {
#ifdef IPC_TEST  // Data Forwarding & UE Capa
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[Forwarding]: Need DRB Forwarding for Intra System Handover!\n");
#endif
        return TRUE;
    }
    /* Inter-RAT Handover(HO_TYPE_INTER_SYSTEM), turn on if there are fwd accepted qos flow */
    else
    {
        callPDUSessInfo_type *pPDUSessInfo = NULL;
        qosFlowInfo_type *ptQi = NULL;

        uint32_t pduIdx = 0, qosIdx = 0, flowIdx = 0;
        uint8_t dl = FALSE, ul = FALSE;

        enumDataForwardingState_type dataFwdState = FnVCCB_GetDataForwardingState(ptCi);

        for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
        {
            pPDUSessInfo = &ptCi->pduSess[pduIdx];

            if (CI_use != pPDUSessInfo->usage) continue;

            if ((S_Modify == pPDUSessInfo->pduSessStatus) ||
                (TRUE == VEIL_checkE1_NeedToBearerModifiedItem(ptCi, pPDUSessInfo->pduSessStatus)))
            {
                for (qosIdx = 0; qosIdx < MAX_QOS_FLOW_PER_PDU_SESS; qosIdx++)
                {
                    flowIdx = pPDUSessInfo->qosFlowIndex[qosIdx];

                    if (flowIdx >= MAX_QOS_FLOW_PER_CALL) continue;

                    ptQi = &ptCi->qosFlow[flowIdx];

                    if (CI_use != ptQi->usage) continue;

                    // Direct data fwd, if the Data Forwarding Response E-RAB List IE is in the Handover Command we
                    // consider that forwarding of downlink data for this E-RAB is accepted by the target eNB. So we do
                    // not need to check if there are accepted qos flows.
                    if (TRUE == ptCi->hoInfo.directFwdAvailable && ptQi->dataFwdErabInfo.fNeedModify)
                    {
                        return TRUE;
                    }

                    VLIB_checkQosFlowForwardedOnTunnels(ptCi, pPDUSessInfo, ptQi, &dl, &ul, dataFwdState);

                    if ((TRUE == dl) || (TRUE == ul))
                    {
#ifdef IPC_TEST  // Data Forwarding & UE Capa
                        VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                            "[Forwarding]: Need PDU Session Forwarding! (pduSessStatus:%u, dl=%u, ul=%u)\n",
                            pPDUSessInfo->pduSessStatus, dl, ul);
#endif
                        return TRUE;
                    }
                }
            }
        }

#ifdef IPC_TEST  // Data Forwarding & UE Capa
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[Forwarding]: Don`t need PDU Session Forwarding!\n");
#endif
        return FALSE;
    }
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_S_ProcHandoverFromPrepToExe
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_S_ProcHandoverFromPrepToExe(callInfo_type *ptCi, msgContainer_type *pRrcTxBuf)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // It operates only when MN Term UP exists.
    if (FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType) == true)
    {
        // Don't Send Data Forward related information. include only DL Tx Stop.
        status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);  // DL TX STOP
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

        VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextModification_id);
    }

    /* Turn on Data_fwd_flag */
    /* Intra-NR Handover(HO_TYPE_INTRA_SYSTEM), always on to send PDCP SN Status Request */
    /* Inter-RAT Handover(HO_TYPE_INTER_SYSTEM), turn on if there are fwd accepted qos flow */
    if (VHCM_CheckNeedToSendDataFwdInfoToUpForHO(ptCi) == TRUE)
    {
        ON_E1_PDCP_SN_FLAG(ptCi->flag.setupFlag);
    }

    FnVCCB_CommitSCellCslAfterReconfiguration(ptCi);
    status = VFIL_sendF1_UeContextModificationRequest(ptCi, pRrcTxBuf);  // TX STOP, RRC Reconfiguration
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextModificationRequest ERROR!!\n");

    if (FnVCCB_IsImmediateHandoverUE(*ptCi))
    {
        FnVCCB_CancelRreWaitOperation(*ptCi, VCCB_FLAG_ON);
    }

    VLIB_AttachTimer(&ptCi->hoInfo.timer.f1, ptCi, timF1_UeContextModification_id);

    ptCi->mroInfo.isHoCmdTransmitted = TRUE;

    OFF_RRC_CONNECTION_FLAG(ptCi->flag.setupFlag);  // RRC Connection Release

    if (IS_MRDC(ptCi))  // MR-DC UE
    {
        if (ptCi->hoInfo.ueContextKeptInd == TRUE)
        {
            // update bearer Type
            status = FnVCCB_UpdateBearerTypeForHandover(
                ptCi, MrdcHoWithoutSnChange);  // TODO: need to add the enum for update db
            VCCB_RETURN_ON_CALL_ERROR(
                ptCi, status, "FnVCCB_UpdateBearerTypeForHandover(Intra/Inter-SN Mobility) ERROR !! \n");

            // TODO: need to move the position after test. there is no mn drb and without sn change
            if (FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType) == false)
            {
                OFF_E1_PDCP_SN_FLAG(ptCi->flag.setupFlag);
            }

            FnVCCB_set_MrdcSnRelMnEvent(ptCi, StatMrdcSnRelMn_MnInit_InterMnWithUeKeptInd);
        }
        else
        {
            FnVCCB_UpdateCallInfoForHandover_SnRelease(ptCi);

            if (ptCi->stateCmd == InterRatHO_cmd)
            {
                FnVCCB_set_MrdcSnRelMnEvent(ptCi, StatMrdcSnRelMn_MnInit_InterRatMobility);
            }
            else
            {
                FnVCCB_set_MrdcSnRelMnEvent(ptCi, StatMrdcSnRelMn_MnInit_InterMnWithoutUeKeptInd);
            }
        }

        // reference : FnVCCB_MrdcSNRelPrepare
        SET_MRDC_PROCEDURE(ptCi, MRDC_PROC_CODE_SnRel, 0, MRDC_PROC_INITIATOR_MN);

        uint8_t targetXN = 0;
        status = FnVCCB_SendXNMessage(XN_SNodeReleaseRequest_id, ptCi, &targetXN, nullptr);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_SNodeReleaseRequest) ERROR!!\n");

        if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_config_ue)
        {
            // Not DRB Release Case
            INIT_MRDC_PROCEDURE(ptCi);
        }
        ON_SN_NODE_REL_ACK_RCV_FLAG(ptCi->flag.respFlag);

        VLIB_AttachTimer(&ptCi->hoInfo.timer.xn, ptCi, timXN_SNodeRelease_id);

        // Since the SN Release message has been delivered, it is determined that recovery is impossible.
        ptCi->hoInfo.cancelControl.needSnRelease = true;
    }

    if (ptCi->hoInfo.hoType.interface == HO_TYPE_XN)
    {
        VLIB_AttachTimer(&ptCi->hoInfo.timer.spec, ptCi, timXN_RelocOverall_id);
    }
    else
    {
        VLIB_AttachTimer(&ptCi->hoInfo.timer.spec, ptCi, timNG_RelocOverall_id);
    }

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_S_default
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_S_default(callInfo_type *ptCi, const message_type *ptAll, const msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    switch (ptUnpack->msgId)
    {
        case timNG_RelocPrep_id:
        case timXN_RelocPrep_id:
        {
            VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, INIT_TIMER);

            VCCB_DetachHoTimer(&ptCi->hoInfo);  // Ng/Xn-Reloc-Prep and All
            VLIB_ClearAllRespFlags(ptCi);

            if (ptUnpack->msgId == timXN_RelocPrep_id)
            {
                VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_XnFail);
                VHCM_SA_HO_STAT(ptCi, HO_Fail_XnTimeOut);  // InterXnOut_PrepFail_XnTimeOut
                CHO_STAT(ptCi, CHO_PrepFail_XnFail, ptCi->hoInfo.cgi);
                ptCi->cause.xnCause = CauseXnapRadioNetworkLayerTxnRelocPrepExpiry;
            }
            else
            {
                VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_XnFail);
                VHCM_SA_HO_STAT(ptCi, HO_Fail_NgTimeOut);  // InterNgOut_PrepFail_NgTimeOut
                ptCi->cause.ngCause = CauseNgapRadioNetworkLayerTngrelocprepExpiry;
            }

            // If ho-preparation-timer-expiry is ON
            FnVCCB_HandleInvalidNcrNotify(ptCi, INVALID_NCR_PREP_TIME_OUT);   // FGS-SF0502 FR240, FR243

            if (IS_CHO(ptCi))
            {
                FnVCCB_UpdateCHOBlockedCellInfo(ptCi);
            }
            VCOM_SaHandoverCancel_ToConn(ptCi, ptUnpack->msgId);
            status = GOOD;
        }
        break;

        default:
            VCOM_InvalidMessageHandler(ptCi, ptAll, ptUnpack);
            status = GOOD;
            break;
    }

    return status;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_DU_S_rxProcess
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_DU_S_rxProcess(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // Check if all messages to proceed to the next state have been received.
    if (VLIB_CheckAllConnected(ptCi) == ERROR)
    {
        return GOOD;
    }

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    status = FnVCCB_NextStep_INTER_Pre_CU_S(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_Pre_CU_S ERROR !!\n");

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_DU_S_F1_UEContextModificationResponse
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_DU_S_F1_UEContextModificationResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = VFIL_storeF1_UeContextModificationResponse(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationResponse ERROR !!\n");

    OFF_F1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    status = VCCM_INTER_Pre_DU_S_rxProcess(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_INTER_Pre_DU_S_rxProcess ERROR !!\n");

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_DU_S_F1_UEContextModificationFailure
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_DU_S_F1_UEContextModificationFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    status = VFIL_storeF1_UeContextModificationFailure(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationFailure ERROR !!\n");

    OFF_SN_NODE_MOD_ACK_RCV_FLAG(ptCi->flag.respFlag);  // For MRDC-UE

    VCOM_SaHandoverCancel_ToConn(ptCi, ptUnpack->msgId);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_DU_S_timInternalHandoverQuery
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_DU_S_timInternalHandoverQuery(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack, uint8_t *pIsNeedReleaseUe)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);
    VALID_E_POINT_CHECK_ERROR(pIsNeedReleaseUe);

    int16_t status;

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    if (IS_CHO(ptCi))
    {
        FnVCCB_UpdateCHOBlockedCellInfo(ptCi);
    }

    // Case #1. If you do not receive an F1 response
    if (GET_F1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Not Received F1 Response\n");

        // If F1 is not received, Call Release
        *pIsNeedReleaseUe = TRUE;
        MACRO_CALL_FAULT_SAVE(timF1_UeContextModification_id, CauseCpInternalTmOutF1UeContextModification);

        return ERROR;
    }

    // Case #2. If you do not receive an XN response
    if (GET_SN_NODE_MOD_ACK_RCV_FLAG(ptCi->flag.respFlag))
    {
        OFF_SN_NODE_MOD_ACK_RCV_FLAG(ptCi->flag.respFlag);

        // 26A FGR-CC5201::FR310 After Handover Cancel, perform Basic SN Release procedure.
        ptCi->hoInfo.cancelControl.needSnRelease = true;

        return ERROR; // 26A FGR-CC5201::FR310
    }

    // Case #3. When to wait for an unknown response
    if (VLIB_CheckAllConnected(ptCi) == ERROR)
    {
        // In this case, the probability of occurrence is high because the response flag is not turned off before
        // handover.
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "There is an incomplete task, so the Handover procedure is canceled.\n");
        VCOM_SaHandoverCancel_ToConn(ptCi, ptUnpack->msgId);

        return GOOD;
    }

    // Case #4. If there is no message to wait, but a timeout has been processed
    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Since there is no message to wait, the Handover continues.\n");

    status = VCCM_INTER_Pre_DU_S_rxProcess(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_INTER_Pre_DU_S_rxProcess ERROR !!\n");

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_DU_S_XN_SNodeModificationRequestAcknowledge
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_DU_S_XN_SNodeModificationRequestAcknowledge(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status;
    status = FnVCCB_StoreXNMessage(XN_SNodeModificationRequestAcknowledge_id, ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_StoreXNMessage(XN_SNodeModificationRequestAcknowledge) ERROR!\n");
    // 26A FGR-CC5201::FR310 With no SCG configuration, can't proceed HO
    auto validateScgConfig = [&ptCi]() -> bool
    {
        if (FnVCCB_IsAnySnTermPerUE(ptCi, current_bearerType) && not FnVCCB_CheckValid_MrdcSNRBConfig(&ptCi->mrdcInfo))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "SCG Query fail: No valid SN RB Config!!\n");
            return false;
        }
        if (not VLIB_CheckValid_MrdcScgCellGrpConfig(&ptCi->mrdcInfo))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "SCG Query fail: No valid SCG CellGroupConfig!!\n");
            return false;
        }
        return true;
    };

    if (!validateScgConfig())
    {
        ptCi->hoInfo.cancelControl.needSnRelease = true;  // Relase SN
        VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);
        return ERROR;
    }

    status = VCCM_INTER_Pre_DU_S_rxProcess(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_INTER_Pre_DU_S_rxProcess ERROR !!\n");

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_DU_S_XN_SNodeModificationRequestReject
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_DU_S_XN_SNodeModificationRequestReject(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status;

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    status = FnVCCB_StoreXNMessage(XN_SNodeModificationRequestReject_id, ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_StoreXNMessage(XN_SNodeModificationRequestReject) ERROR!\n");

    return ERROR; // 26A FGR-CC5201::FR310 After Handover Cancel
}  // }}}

/****************************************************
 * @brief          This function performs the execution procedure for CHO after preparation is completed.
 * @param[in/out]  ptCi : call information / callInfo_type
 * @return         return GOOD/ERROR / uint16_t
 ****************************************************/
VCCB_STATIC_INLINE
int16_t VCCM_INTER_Pre_CU_S_XN_HandoverRequestAcknowledge_ChoHO(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;
    conditionalCellInfo_type *ptCondCell = NULL;

    // Upon reception of the HANDOVER REQUEST ACKNOWLEDGE message,
    // the source NG-RAN node shall stop the timer TXnRELOCprep and terminate the Handover Preparation procedure.
    // VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, CANCEL_TIMER);  // Xn-Handover Preparation

    ptCondCell = FnVCCB_GetConditionalCellInfoForCGI(ptCi, ptCi->hoInfo.cgi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_GetConditionalCellInfoForCGI(%X/%llu) ERROR!\n",
        ptCi->hoInfo.cgi.plmn.longId, ptCi->hoInfo.cgi.ci * 1ULL);

    // FGR-MC1400 FR100.CACP.SR1.HD1.VCCB.DD1
    status = FnVCCB_StoreHandoverConfigToCondCellInfo(ptCi, ptCondCell, interface_xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_StoreHandoverConfigToCondCellInfo ERROR!\n");

    status = FnVCCB_NextStep_INTER_CondReconf_S(ptCi, ptCondCell);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_CondReconf_S ERROR!\n");

    return GOOD;
}

/****************************************************
 * @brief          This function performs the execution procedure for IM after preparation is completed.
 * @param[in/out]  ptCi : call information / callInfo_type
 * @return         return GOOD/ERROR / uint16_t
 ****************************************************/
VCCB_STATIC_INLINE
int16_t VCCM_INTER_Pre_CU_S_XN_HandoverRequestAcknowledge_ImmediateHO(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    status = FnVCCB_ProcSaHandover_IntergNB_Execution(ptCi, e_HoTrigger_ImmediateHandover);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_ProcSaHandover_IntergNB_Execution(IM, XN) ERROR!\n");

    return GOOD;
}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_CU_S_XN_HandoverRequestAcknowledge
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_CU_S_XN_HandoverRequestAcknowledge(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int16_t status = GOOD;

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, CANCEL_TIMER);  // Ng/Xn-Reloc-Prep

    status = FnVCCB_StoreXNMessage(XN_HandoverRequestAcknowledge_id, ptCi, ptAll, ptUnpack);
    if (ERROR == status)
    {
        CHO_STAT(ptCi, CHO_PrepFail_XnFail, ptCi->hoInfo.cgi);
        return ERROR;
    }

    // A quick release is performed as the resource is no longer used.
    FnVCCB_InitCellGroupConfig(ptCi);

    if (IS_CHO(ptCi) && VCCB_FLAG_ON == ptCi->condHoInfo.flag.to_be_blocklisted)
    {
        ptCi->condHoInfo.flag.to_be_blocklisted = VCCB_FLAG_OFF;
        FnVCCB_UpdateCHOBlockedCellInfo(ptCi);
        VCOM_SaHandoverCancel_ToConn(ptCi, ptUnpack->msgId);
        return GOOD;
    }

    /*Disable LRC if it is enabled*/
    if (ptCi->locRpt.reportOn == CI_use)
    {
        ptCi->locRpt.reportOn = CI_no_use;
    }

    if (FnVCCB_IsConditionalHandoverUE(ptCi) == true)
    {
        status = VCCM_INTER_Pre_CU_S_XN_HandoverRequestAcknowledge_ChoHO(ptCi);
        if (status == ERROR)
        {
            CHO_STAT(ptCi, CHO_PrepFail_XnFail, ptCi->hoInfo.cgi);
        }
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_INTER_Pre_CU_S_XN_HandoverRequestAcknowledge_ChoHO Error!\n");
        return GOOD;
    }

    status = VCCM_INTER_Pre_CU_S_XN_HandoverRequestAcknowledge_ImmediateHO(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_INTER_Pre_CU_S_XN_HandoverRequestAcknowledge_ImmediateHO Error!\n");
    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_CU_S_XN_HandoverPreparationFailure
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_CU_S_XN_HandoverPreparationFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, CANCEL_TIMER);  // Ng/Xn-Reloc-Prep

    VHCM_SA_HO_STAT(ptCi, HO_Fail_XnFail);
    CHO_STAT(ptCi, CHO_PrepFail_XnFail, ptCi->hoInfo.cgi);

    FnVCCB_UpdateInterGnbConnectionState_Source(ptCi, ptCi->hoInfo.cgi, OFF);  // HO

    status = FnVCCB_StoreXNMessage(XN_HandoverPreparationFailure_id, ptCi, ptAll, ptUnpack);
    if (ERROR == status) return ERROR;

    VHCM_UpdateHandoverPreparationFailureCellInfo(ptCi);  // by SA, Inter-GNB XN Preparation Fail

    if (IS_CHO(ptCi) && VCCB_FLAG_ON == ptCi->condHoInfo.flag.to_be_blocklisted)
    {
        ptCi->condHoInfo.flag.to_be_blocklisted = VCCB_FLAG_OFF;
        FnVCCB_UpdateCHOBlockedCellInfo(ptCi);
    }

    switch (ptCi->cause.xnCause)
    {
        case CauseXnapRadioNetworkLayerCellNotAvailable:
            {  // {{{
                FnVCCB_HandleInvalidNcrNotify(ptCi, INVALID_NCR_CELL_NOT_AVAIL); // FGS-SF0502 FR240, FR243
            }  // }}}
            break;

        case CauseXnapRadioNetworkLayerUnknownGuamiId:
        case CauseXnapRadioNetworkLayerInvalidAmfSetId:
            {
                // FGR-MC1400 FR130
                if (IS_CHO(ptCi)) break;
                if (IS_MRDC_MN(ptCi)) break;  // MRDC Mobility is Currently Not Supported. TODO

                /* All Timer Cancel  (Protect Code) */
                VCCB_DetachHoTimer(&ptCi->hoInfo);

                /* All Response Flag Clear (Protect Code) */
                VLIB_ClearAllRespFlags(ptCi);

                /* In the case of Inter-GNB HO, it releases resources for GNB Node. (Protect Code) */
                VHCM_ReleaseGnbNodeForInterGnbHO(ptCi);

                ptCi->hoInfo.needNgHO = TRUE;
                ptCi->hoInfo.noCGConfigQuery = TRUE;

                VCCB_PRINT_CALL_COMMENT(
                    ptCi, "After XN HO Failure(0x%X), proceed with NG HO procedure.\n", ptCi->cause.xnCause);

                auto hoInputDb = StartSaHandoverDb(ptCi->hoInfo.reportType, ptCi->hoInfo.reportPurpose, ptCi->hoInfo.reportConfigQuantitySaHo);
                status = VHCM_StartSaHandover_IntergNB(
                    ptCi, ptCi->hoInfo.tgtNbrGnbCell, ptCi->hoInfo.cause, e_HoTrigger_ImmediateHandover, hoInputDb);

                ptCi->hoInfo.needNgHO = FALSE;
                ptCi->hoInfo.noCGConfigQuery = FALSE;

                if (status == GOOD)
                {
                    return GOOD;
                }
                // else : CONNECTED in Source Cell
            }
            break;

        case CauseXnapRadioNetworkLayerHandoverTargetNotAllowed:
            {
                // FGR-MC1400 FR120
                if (IS_CHO(ptCi)) break;
            }
            break;

        case CauseXnapMiscControlProcessingOverload: // NR_CONN_MC_23B
            {
                // Target gNB is regarded as the overloaded and maintained
                FnVCCB_UpdateOverloadedHoTgtGnbInfo(ptCi); 
            }
            break;

        default:
            // no action
            break;
    }

    VCOM_SaHandoverCancel_ToConn(ptCi, ptUnpack->msgId);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_CU_S_NG_HandoverCommand
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_CU_S_NG_HandoverCommand(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int16_t status = GOOD;

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, CANCEL_TIMER);  // Ng/Xn-Reloc-Prep

    status = VNIL_StoreNGAP_HandoverCommand(ptCi, ptAll, ptUnpack);
    if (status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VNIL_StoreNGAP_HandoverCommand ERROR(%d) !!\n", status);
        return ERROR;
    }

    // A quick release is performed as the resource is no longer used.
    FnVCCB_InitCellGroupConfig(ptCi);

    /*If Successful NG HO, Disable LRC */
    if (ptCi->locRpt.reportOn == CI_use)
    {
        ptCi->locRpt.reportOn = CI_no_use;
    }

    status = FnVCCB_ProcSaHandover_IntergNB_Execution(ptCi, e_HoTrigger_ImmediateHandover);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_ProcSaHandover_IntergNB_Execution(IM, NG) ERROR!\n");

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_CU_S_NG_HandoverPreparationFailure
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_CU_S_NG_HandoverPreparationFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, CANCEL_TIMER);  // Ng/Xn-Reloc-Prep

    FnVCCB_UpdateInterGnbConnectionState_Source(ptCi, ptCi->hoInfo.cgi, OFF);  // HO

    status = VNIL_StoreNGAP_HandoverPreparationFailure(ptCi, ptAll, ptUnpack);
    if (status == ERROR)
    {
        VHCM_SA_HO_STAT(ptCi, HO_Fail_NgFail);  // moved due to IRAT_HO
        VCCB_PRINT_CALL_ERROR(ptCi, "VNIL_StoreNGAP_HandoverPreparationFailure ERROR !!\n");
        return ERROR;
    }

    VHCM_UpdateHandoverPreparationFailureCellInfo(ptCi);  // by SA, Inter-GNB NG Preparation Fail

    switch (ptCi->cause.ngCause)
    {
        // IRAT_HO
        case CauseNgapRadioNetworkLayerN26InterfaceNotAvailable:
        {
            VCCB_PRINT_CALL_INFORMATIVE(
                    ptCi, "[IRAT_HO] HoPrepFailure : CauseNgapRadioNetworkLayerN26InterfaceNotAvailable \n");
            VHCM_SA_HO_STAT(ptCi, HO_PrepFail_N26);  // IRAT_HO STAT

            // trigger the redirection
            if (ptCi->hoInfo.tArfcn < UINT32_MAX)
            {
                VCCB_PRINT_CALL_INFORMATIVE(
                        ptCi, "[IRAT_HO] Call Release with Measurement Based Redirection Trigger!! \n");

                if (ERROR == VLIB_SetRedirectionInfoObjectByArfcn(ptCi, ptCi->hoInfo.tArfcn))
                {
                    VCCB_PRINT_ERROR("ERROR: VLIB_SetRedirectionInfoObjectByArfcn fail\n");
                    return GOOD;
                }

                // Release with redirection info (Measurement Based Redirection)
                status = VCCM_RedirectionByRRCReleaseTrigger(ptCi, ptUnpack->msgId);
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_RedirectionByRRCReleaseTrigger ERROR!\n");
            }
            return GOOD;
        }

        case CauseNgapRadioNetworkLayerCellNotavailable:
        {
            FnVCCB_HandleInvalidNcrNotify(ptCi, INVALID_NCR_CELL_NOT_AVAIL);   // FGS-SF0502 FR240, FR243
        }
        break;

        case CauseNgapRadioNetworkLayerUnknownTargetID:
        {
            FnVCCB_HandleInvalidNcrNotify(ptCi, INVALID_NCR_UNK_TGT_ID);   // FGS-SF0502 FR240, FR243
        }
        break;

        case CauseNgapRadioNetworkLayerHandoverFailureInTarget5gcNgranNodeOrTargetSystem: // FGS-SF0502 FR240, FR243
        {  
            FnVCCB_HandleInvalidNcrNotify(ptCi, INVALID_NCR_HO_FAIL_TGT_5GC_NGRAN);   // FGS-SF0502 FR240, FR243
        } 
        break;

        case CauseNgapMiscControlProcessingOverload: // NR_CONN_MC_23B
        {
            // Target gNB is regarded as the overloaded and maintained
            FnVCCB_UpdateOverloadedHoTgtGnbInfo(ptCi);
        }
        break;

        default:
        // no action
        break;
    }

    VHCM_SA_HO_STAT(ptCi, HO_Fail_NgFail);  // moved due to IRAT_HO
    VCOM_SaHandoverCancel_ToConn(ptCi, ptUnpack->msgId);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_after_pre_S_default
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_after_pre_S_default(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    switch (ptUnpack->msgId)
    {
        case timXN_RelocOverall_id:
        case timNG_RelocOverall_id:
        {
            VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, INIT_TIMER);

            VCCB_DetachHoTimer(&ptCi->hoInfo);  // Ng/Xn-Reloc-Overall and All
            VLIB_ClearAllRespFlags(ptCi);

            if (ptUnpack->msgId == timXN_RelocOverall_id)
            {
                VHCM_SA_HO_STAT(ptCi, HO_Fail_XnTimeOut);
                CHO_STAT(ptCi, CHO_ExeFail_XnFail, ptCi->hoInfo.cgi);
                MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaHoTmOutXnRelocOverall);
            }
            else
            {
                VHCM_SA_HO_STAT(ptCi, HO_Fail_NgTimeOut);
                MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaHoTmOutNgRelocOverall);
            }
        }
            status = ERROR;  // release the call
            break;
#if 0
        case XN_SNodeReleaseRequestAcknowledge_id:
            status = FnVCCB_StoreXNMessage(XN_SNodeReleaseRequestAcknowledge_id, ptCi, ptAll, ptUnpack);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status,
                                       "FnVCCB_StoreXNMessage(XN_SNodeReleaseRequestAcknowledge_id) ERROR !!\n");
            break;
#endif
        default:
            VCOM_InvalidMessageHandler(ptCi, ptAll, ptUnpack);
            status = GOOD;
            break;
    }

    return status;
}  // }}}

/****************************************************************************
 * @brief           Handling NR-RRC Reconfiguration Complete in state STATE_INTER_CondReconf_S
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t FnVCCB_INTER_CondReconf_S_NRRRC_RrcReconfigurationComplete(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    conditionalCellInfo_type *ptCondCell = NULL;

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);  // timNRRRC_RRCReconfig_id

    if (VRIL_storeNRRRC_RrcReconfigurationComplete(ptCi, ptUnpack) == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VRIL_storeNRRRC_RrcReconfigurationComplete ERROR!\n");
        return ERROR;
    }

    ptCondCell = FnVCCB_GetConditionalCellInfoForCGI(ptCi, ptCi->hoInfo.cgi);
    VALID_E_POINT_CHECK_ERROR(ptCondCell);

    // Record the time when Candidate Cell Setup procedure is completed (RRCReconfigurationComplete is received).
    ptCondCell->tCondCellSetupCmpl = tickGetMono();

    CHO_STAT(ptCi, CHO_PrepSucc, ptCi->hoInfo.cgi);  // STAT_CHO_OUT

    // FGR-MC1400, Conditional Handover
    FnVCCB_ConditionalCellConfigCommit(ptCi);

    return GOOD;
}  // }}}

/****************************************************************************
 * @brief           Handling NR-RRC TMOUT of Reconfiguration Complete in state STATE_INTER_CondReconf_S
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t FnVCCB_INTER_CondReconf_S_timNRRRC_RRCReconfig(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);  // timNRRRC_RRCReconfig_id

    CHO_STAT(ptCi, CHO_PrepFail_RrcFail, ptCi->hoInfo.cgi);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Exe_S_F1_UEContextModificationResponse
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Exe_S_F1_UEContextModificationResponse(
    callInfo_type *ptCi, const message_type *ptAll, const msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, CANCEL_TIMER);

    status = VFIL_storeF1_UeContextModificationResponse(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationResponse ERROR !!\n");

    OFF_F1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Exe_S_F1_UEContextModificationFailure
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Exe_S_F1_UEContextModificationFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, CANCEL_TIMER);  // Ng/Xn-Reloc-Overall
    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, CANCEL_TIMER);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_F1Fail);
    CHO_STAT(ptCi, CHO_ExeFail_F1Fail, ptCi->hoInfo.cgi);

    status = VFIL_storeF1_UeContextModificationFailure(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationFailure ERROR !!\n");

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Exe_S_timF1_UeContextModification
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Exe_S_timF1_UeContextModification(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, CANCEL_TIMER);  // Ng/Xn-Reloc-Overall
    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, INIT_TIMER);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_F1TimeOut);
    CHO_STAT(ptCi, CHO_ExeFail_F1Fail, ptCi->hoInfo.cgi);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutF1UeContextModification);

    return GOOD;
}  // }}}

int16_t VCCM_INTER_Exe_S_XN_SNodeReleaseRequestAcknowledge(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status;

    status = FnVCCB_CommonMsgProc_XN_SNodeRelease(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeRelease(Response) ERROR !!\n");

    return GOOD;
}  // }}}

int16_t VCCM_INTER_Exe_S_XN_SNodeReleaseReject(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status;

    CHO_STAT(ptCi, CHO_ExeFail_XnFail, ptCi->hoInfo.cgi);

    status = FnVCCB_CommonMsgProc_XN_SNodeRelease(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeRelease(Failure) ERROR !!\n");

    return GOOD;
}  // }}}

int16_t VCCM_INTER_Exe_S_timXN_SNodeRelease(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status;

    CHO_STAT(ptCi, CHO_ExeFail_XnFail, ptCi->hoInfo.cgi);

    status = FnVCCB_CommonMsgProc_XN_SNodeRelease(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeRelease(TMOUT) ERROR !!\n");

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_HO_Common_E1_BearerContextModificationSuccess
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**
 * *  Output : void
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_HO_Common_E1_BearerContextModificationSuccess(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, CANCEL_TIMER);

    OFF_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Exe_S_timE1_BearerContextModification
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Exe_S_timE1_BearerContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, CANCEL_TIMER);  // Ng/Xn-Reloc-Overall
    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, INIT_TIMER);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_UpFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_E1TimeOut);
    CHO_STAT(ptCi, CHO_ExeFail_E1Fail, ptCi->hoInfo.cgi);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_SeqNum_S_E1_BearerContextModificationUnsuccess
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**
 * *  Output : void
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_SeqNum_S_E1_BearerContextModificationUnsuccess(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, CANCEL_TIMER);  // Ng/Xn-Reloc-Overall
    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, CANCEL_TIMER);

    FnVCCB_CollectingSaHandoverStatistics_E1Fail(ptCi);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->cause.e1Cause);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_SeqNum_S_timE1_BearerContextModification
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_SeqNum_S_timE1_BearerContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, CANCEL_TIMER);  // Ng/Xn-Reloc-Overall
    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, INIT_TIMER);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_UpFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_E1TimeOut);
    CHO_STAT(ptCi, CHO_ExeFail_E1Fail, ptCi->hoInfo.cgi);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : FnVCCB_INTER_SeqNum_S_XN_SNStatusTransfer
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t FnVCCB_INTER_SeqNum_S_XN_SNStatusTransfer(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_CommonMsgProc_XN_SNStatusTransfer(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNStatusTransfer(Response) ERROR !!\n");

    return GOOD;
}

/****************************************************************
 * *  Function     : FnVCCB_INTER_SeqNum_S_timXN_SnStatusTransfer
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t FnVCCB_INTER_SeqNum_S_timXN_SnStatusTransfer(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    CHO_STAT(ptCi, CHO_ExeFail_XnFail, ptCi->hoInfo.cgi);

    status = FnVCCB_CommonMsgProc_XN_SNStatusTransfer(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNStatusTransfer(TMOUT) ERROR !!\n");

    return GOOD;
}

/****************************************************************
 * *  Function     : VCCM_INTER_Compl_S_XN_UEContextRelease
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Compl_S_XN_UEContextRelease(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, CANCEL_TIMER);

    VHCM_SA_HO_STAT(ptCi, HO_Succ);
    CHO_STAT(ptCi, CHO_ExeSuccess, ptCi->hoInfo.cgi);  // STAT_CHO_OUT

    FnVCCB_UpdateInterGnbConnectionState_Source(ptCi, ptCi->hoInfo.cgi, OFF);

    status = FnVCCB_StoreXNMessage(XN_UEContextRelease_id, ptCi, ptAll, ptUnpack);
    if (ERROR == status) return ERROR;

    // Call resource release is requested for SCG.
    if (IS_MRDC(ptCi))
    {
        uint8_t targetXN = e_Snode_MnToSrcSn;
        status = FnVCCB_SendXNMessage(XN_UEContextRelease_id, ptCi, &targetXN, nullptr);
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendXNMessage(XN_UEContextRelease) ERROR!!\n");
        }

        OFF_MRDC_RSC_SETUP_FLAG(xn_snConn); // Inter-MN Source-gNB with UE Ctxt Release
    }

    // Target gNB sends the UE context Release when NG path switch request procedures is done.
    // disable the NGC connection.
    OFFBIT(ptCi->flag.setupFlag, NGC_CONNECTION_FLAG);

    // RETAIN_STAT_HO_21C - XN Serving
    VLIB_SaveEventForCallRetainStat(ptCi, RetainCategory_InterGnbXnHandover,
        ptCi->cause.xnCause);  // RETAIN_STAT_HO_21C
    // VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[RETAIN_STAT] %s RetainCategory_InterGnbXnHandover XN Serving xnCause(%d) \n",
    //         __func__, ptCi->cause.xnCause);
    /* CauseXnapRadioNetworkLayerHandoverDesirableForRadioReasons */

    if (VCCB_CALL_RELEASE_TRIGGER(ptCi) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_CALL_RELEASE_TRIGGER ERROR!\n");
    }

    return GOOD;
}  // }}}
// }}}

// }}}

/****************************************************************************
                          Inter gNB target
****************************************************************************/
// {{{

/****************************************************************
 *  Function             : FnVCCB_NextStep_INTER_Pre_UP_T
 *  Description          : go to next state STATE_INTER_Pre_UP_T
 *  Input                : callInfo_type*
 *  Output               : int16_t (GOOD/ERROR)
 ***************************************************************/
int16_t FnVCCB_NextStep_INTER_Pre_UP_T(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    VLIB_SetCurStateAll(ptCi, STATE_INTER_Pre_UP_T);

    status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextSetup);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendBearerSetupRequest ERROR !! \n");

    // 3-1, 3-2, 3-3, 3-4, 3-5
    if (FnVCCB_IsAnyMnTermSplitPerUE(ptCi, request_bearerType))
    {
        ON_MRDC_RSC_SETUP_FLAG(e1_scgSetup);
    }

    VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextSetup_id);

    return GOOD;
}  // }}}

/****************************************************************
 *  Function             : FnVCCB_NextStep_INTER_Pre_SN_T
 *  Description          : go to next state STATE_INTER_Pre_SN_T
 *  Input                : callInfo_type*
 *  Output               : int16_t (GOOD/ERROR)
 ***************************************************************/
int16_t FnVCCB_NextStep_INTER_Pre_SN_T(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;
    uint8_t targetXn = e_Snode_MnToSrcSn;

    VLIB_SetCurStateAll(ptCi, STATE_INTER_Pre_SN_T);

    if (FnVCCB_IsInterSnMobilityInMn(ptCi))
    {
        targetXn = e_Snode_MnToTgtSn;
    }

    {    
        fullConfiguration_type backupDB;
        ForcedCuInitFullConfigForXnSnAddReqMake mnInitFullConfig(ptCi, &backupDB);
        mnInitFullConfig.procXnSnAddReq();

        status = FnVCCB_SendXNMessage(XN_SNodeAdditionRequest_id, ptCi, &targetXn, nullptr);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_SNodeAdditionRequest) ERROR!\n");
    }

    VLIB_AttachTimer(&ptCi->hoInfo.timer.xn, ptCi, timXN_SNodeAddition_id);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Att);

    ON_SN_NODE_ADD_ACK_RCV_FLAG(ptCi->flag.respFlag);

    OFF_MRDC_XN_RCVINDICATOR_FLAG(scgCellGrpCfg);
    OFF_MRDC_XN_RCVINDICATOR_FLAG(scgRBCfg);

    return GOOD;
}  // }}}

/****************************************************************
 *  Function             : FnVCCB_NextStep_INTER_Pre_DU_T
 *  Description          : go to next state STATE_INTER_Pre_DU_T
 *  Input                : callInfo_type*
 *  Output               : int16_t (GOOD/ERROR)
 ***************************************************************/
int16_t FnVCCB_NextStep_INTER_Pre_DU_T(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;


    VCCB_clearAllFailedCarrier(&ptCi->caInfo.failures);
    VLIB_ConfigSecondaryCellList(ptCi);
    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig!\n");

    VLIB_SetCurStateAll(ptCi, STATE_INTER_Pre_DU_T);

    status = VFIL_sendF1_UeContextSetupRequest(ptCi, NULL, 0);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextSetupRequest ERROR!\n");

    VLIB_AttachTimer(&ptCi->timer, ptCi, timF1_UeContextSetup_id);

    return GOOD;
}  // }}}

/****************************************************************
 *  Function             : FnVCCB_NextStep_INTER_Exe_T
 *  Description          : go to next state STATE_INTER_Exe_T
 *  Input                : callInfo_type*
 *  Output               : int16_t (GOOD/ERROR)
 ***************************************************************/
int16_t FnVCCB_NextStep_INTER_Exe_T(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    VLIB_SetCurStateAll(ptCi, STATE_INTER_Exe_T);

    if (GET_E1_RESOURCE_FLAG(ptCi->flag.setupFlag))
    {
        if (FnVCCB_IsAnyMnTermPerUE(ptCi, request_bearerType) == true)
        {
            status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");
            VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextModification_id);
        }
        else
        {
            status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextRelease);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Release) ERROR!\n");
            VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextRelease_id);
        }
    }

    if (IS_MRDC(ptCi) && ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
    {
        SET_MRDC_PROCEDURE(ptCi, MRDC_PROC_CODE_SnRel, 0, MRDC_PROC_INITIATOR_MN);
        SET_MRDC_PROCEDURE_SNREL_OPRTYPE(ptCi, MRDC_SNREL_OPR_XN_Fallback);
    }

    status = VCOM_SendHandoverAcknowledge(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCOM_SendHandoverAcknowledge ERROR!\n");

    if (IS_MRDC(ptCi) && ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_config_ue)
    {
        if (FnVCCB_IsAnySnTermSplitPerUE(ptCi, request_bearerType))
        {
            uint8_t targetXN = 0;
            if (FnVCCB_IsInterSnMobilityInMn(ptCi))
            {
                targetXN = e_Snode_MnToTgtSn;
            }

            ON_BITFLAG_NEED_XNUADDRIND_FOR_DLUPTNL(ptCi);
            status = FnVCCB_SendXNMessage(XN_XnUAddressIndication_id, ptCi, &targetXN, nullptr);
            OFF_BITFLAG_NEED_XNUADDRIND_FOR_DLUPTNL(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_XnUAddressIndication) ERROR!\n");
        }
    }

    if (FnVCCB_IsConditionalHandoverUE(ptCi))
    {
        CHO_STAT(ptCi, CHO_PrepSucc, ptCi->hoInfo.cgi);  // STAT_CHO_IN

        conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForCGI(ptCi, ptCi->hoInfo.cgi);
        if (ptCondCell == NULL)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Target Cell Not Found\n");
            return ERROR;
        }

        // 8.2.9 Conditional Handover Cancel
        ptCondCell->flag.to_resp_cho_cancel = TRUE;
    }
    else
    {
        FnVCCB_SetHandoverExecution(ptCi);
        VHCM_SA_HO_STAT(ptCi, HO_PrepSucc);
    }

    VLIB_SAHandoverTime(ptCi, CAL_START);

    ON_RRC_RECONFIG_FLAG(ptCi->flag.respFlag);
    if (ptCi->hoInfo.hoType.system == HO_TYPE_INTRA_SYSTEM)
    {
        ON_SN_STATUS_FLAG(ptCi->flag.respFlag);

        // MRDC
        if (IS_MRDC_MN(ptCi))
        {
            // Not Exist MN Term
            if (FnVCCB_IsAnyMnTermPerUE(ptCi, request_bearerType) == false)
            {
                // no sn data forwarding (wo SN Change)
                if (FnVCCB_IsIntraSnMobilityInMn(ptCi))
                {
                    // skip sn Status
                    OFF_SN_STATUS_FLAG(ptCi->flag.respFlag);
                }
            }
        }
    }

    // In case of NG HO, NG-C connection is established when 'NG Handover Acknowledge' is transmitted. <= Current NG
    // CASE In case of XN HO or RRE, NG-C connection is established when 'NG Path Switch Request' is transmitted.
    if (ptCi->hoInfo.hoType.interface == HO_TYPE_NG)
    {
        ON_NGC_CONNECTION_FLAG(ptCi->flag.setupFlag);  // During NG Handover for SA
    }

    return GOOD;
}  // }}}

/****************************************************************
 *  Function             : FnVCCB_NextStep_INTER_Switch_T
 *  Description          : go to next state STATE_INTER_Switch_T
 *  Input                : callInfo_type*
 *  Output               : int16_t (GOOD/ERROR)
 ***************************************************************/
int16_t FnVCCB_NextStep_INTER_Switch_T(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VLIB_SetCurStateAll(ptCi, STATE_INTER_Switch_T);

    // send the path switch request
    auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_PathSwitchRequestGnbAmf_id);
    VALID_E_POINT_CHECK_ERROR(ngapSender);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, ngapSender->sendMsg(), "sendMsg(NG_PathSwitchRequestGnbAmf) ERROR !!\n");

    // In case of NG HO, NG-C connection is established when 'NG Handover Acknowledge' is transmitted.
    // In case of XN HO or RRE, NG-C connection is established when 'NG Path Switch Request' is transmitted. <=
    // Current XN CASE
    ON_NGC_CONNECTION_FLAG(ptCi->flag.setupFlag);  // During XN Handover for SA

    VLIB_AttachTimer(&ptCi->timer, ptCi, timNG_PathSwitch_id);

    return GOOD;
}  // }}}

/****************************************************************
 *  Function             : FnVCCB_NextStep_INTER_Compl_T
 *  Description          : go to next state STATE_INTER_Compl_T
 *  Input                : callInfo_type*
 *  Output               : int16_t (GOOD/ERROR)
 ***************************************************************/
int16_t FnVCCB_NextStep_INTER_Compl_T(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    VLIB_SetCurStateAll(ptCi, STATE_INTER_Compl_T);

    // PDCP SN Status Information
    status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

    VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);

    return GOOD;
}  // }}}

/****************************************************************
 *  Function             : FnVCCB_NextStep_INTER_Compl_T_Complete
 *  Description          : go to next state STATE_INTER_Compl_T
 *  Input                : callInfo_type*
 *  Output               : int16_t (GOOD/ERROR)
 ***************************************************************/
int16_t FnVCCB_NextStep_INTER_T_HandoverComplete(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    // Send 'NG Handover Notify for NG' or 'XN Ue Context Release for XN'
    status = VCOM_SendHandoverComplete(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCOM_SendHandoverComplete ERROR !!\n");

    // Send CallSetupRsp to VNMB
    status = VIIL_sendCallSetupRsp(ptCi, CP_RET_OK);
    if (status == ERROR)
    {
        VCCB_PRINT_ERROR("VIIL_sendCallSetupRsp ERROR!!\n");
    }

    status = VHCM_FinalizeHandover(ptCi);
    if (status == ERROR)
    {
        VCCB_PRINT_ERROR("VHCM_FinalizeHandover ERROR!!\n");
    }

    return GOOD;
}  // }}}

/************************************************************************************************************************
 *  Function    : FnVCCB_IsNeedUpProcessing_For_InterNB
 *  Description : This function determines whether MN UP control is required in the Inter-GNB environment.
 ************************************************************************************************************************/
VCCB_STATIC_INLINE
int16_t FnVCCB_IsNeedUpProcessing_For_InterNB(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_FALSE(ptCi);

    if (IS_MRDC(ptCi) && ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_config_ue)
    {
        // When there are MN DRB
        if (FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType) == true)
        {
            return TRUE;
        }
        else  // When there is no MN DRB
        {
            return FALSE;
        }
    }
    else  // There is no MR-DC or SN Release
    {
        return TRUE;
    }
}

/************************************************************************************************************************
 *  Function    : FnVCCB_ProcHandoverRequest_CheckAndUpdateBearer
 *  Description : This function manages the settings for PDU/QOS/DRB/SRB etc.
 ************************************************************************************************************************/
VCCB_STATIC_INLINE
AllowedStatus FnVCCB_ProcHandoverRequest_CheckAndUpdateBearer(
    callInfo_type &callInfo, uint16_t msgId)
{
    int16_t status = GOOD;
    callInfo_type *ptCi = &callInfo;

    { // {{{
        // perform partial processing inspection and DB update.

        // SVR21A FGR-MC1007 :: NR Connected Mobility Control :: FR261
        // When gNB decides whether to accept newly incoming request in the below,
        // gNB should consider the requested slices of the incoming UE and the supported slices of the target cell.
        // FGR-MC1021 :: Slice Aware Mobility Control :: FR20
        status = VCCM_CheckSliceAwareForTarget(ptCi);
        if (GOOD != status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : Network slicing, status(%d)\n", status);
            return Not_Allowed;
        }

        // FGR-BC0323 :: Ciphering and Integrity Protection for SA (Standalone)
        // Check if UP DRB Integrity Is Supported
        status = VCCM_Check_UP_DRB_Integrity_Supported(ptCi);
        if (GOOD != status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : UP DRB Integrity Is Not Supported, status(%d)\n", status);
            return Not_Allowed;
        }

        // FGR-MC1007 :: NR Connected Mobility Control :: FR262
        // When gNB decides whether to accept hand-in request, gNB should consider the requested 5QI per PDU session for
        // a incoming UE and the supported 5QIs of the target cell. (non-VoNR case)
        status = VCCM_CheckSupportQosFlowAndRearrange(ptCi, msgId);
        if (GOOD != status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : VCCM_CheckSupportQosFlowAndRearrange, status(%d)\n", status);

            ptCi->cause.xnCause = CauseXnapRadioNetworkLayerNotSupported5qiValue;
            ptCi->cause.ngCause = CauseNgapRadioNetworkLayerNotSupported5qiValue;
            return Not_Allowed;
        }

        // FGR-MC1007 :: NR Connected Mobility Control :: FR262
        // When gNB decides whether to accept hand-in request, gNB should consider the requested 5QI per PDU session for
        // a incoming UE and the supported 5QIs of the target cell. (VoNR case)
        status = VCCM_CheckVoiceOverNR(ptCi, ptCi->servCellNum);
        if (GOOD != status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : VCCM_CheckVoiceOverNR, status(%d)\n", status);

            ptCi->cause.xnCause = CauseXnapRadioNetworkLayerNotSupported5qiValue;
            ptCi->cause.ngCause = CauseNgapRadioNetworkLayerNotSupported5qiValue;
            return Not_Allowed;
        }

        // FGR-MC1009 :: Inter-gNB NG Handover :: FR170
        // When target gNB receives Handover Request from AMF,
        // if 'Source NG-RAN Node to Target NG-RAN Node Transparent Container' contains PDU sessions which are not included
        // in PDU Session Resource Setup Request, target gNB should command UE to release the PDU Session through HandoverCommand.
        status = VLIB_checkRadioBearerStatusForMobility(ptCi);
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : VLIB_checkRadioBearerStatusForMobility, status(%d)\n", status);
            return Not_Allowed;
        }

    } // }}}

    { // {{{
        // 2) Perform final processing on DRB.

        // This is a DB record operation for DRB ID Release in Handover Command.
        VCOM_ChangeStatus_DRBStatus_To_FailToSetup_ForHandover(ptCi);

        // FGR-CC0413 :: QoS flow to DRB mapping (SDAP)  
        // allocates the DRB for SDAP layer
        status = VCCM_SDAP_AllocationAndUpdate_DRBStatus(ptCi);
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_SDAP_AllocationAndUpdate_DRBStatus ERROR!\n");
            MACRO_CALL_FAULT_SAVE(msgId, CauseCpInternalResourceAllocFail);
            return Not_Allowed;
        }

        // FGR-MC1020 :: NR full configuration support (NR and MR-DC)
        VHCM_ApplyRadioBearer_For_FullConfiguration(ptCi);
    } // }}}

    return Allowed;
}

/************************************************************************************************************************
 *  Function    : FnVCCB_ProcHandoverRequest_Trace
 *  Description : This function defines the action for the trace action after accepting the Handover Request.
 ************************************************************************************************************************/
VCCB_STATIC_INLINE
void FnVCCB_ProcHandoverRequest_Trace(callInfo_type &callInfo, uint16_t cellNum)
{
    callInfo_type *ptCi = &callInfo;

    if (no_error != ptCi->signalingTraceInfo.failureIndication.cause)
    {
        if (GOOD != VCCM_enqueueActionWithForce(ptCi, ENQUEUE_ACTION_SEND_SIG_TRACE_FAILURE_IND, false))
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, mdt_trace_all, "VCCM_enqueueAction(ENQUEUE_ACTION_SEND_SIG_TRACE_FAILURE_IND) ERROR\n");
        }
    }

    // [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB); 
    VLIB_startManagementMdtTrace(ptCi, cellNum);
    VLIB_startManagementUeThrRfTrace(ptCi, cellNum);
    VLIB_startLoggedMdtTrace(ptCi, cellNum);
}

/************************************************************************************************************************
 *  Function    : VCCB_ProcHandoverRequest_CHO
 *  Description : This function defines the action for MRDC-related settings after allowing Handover Request.
 ************************************************************************************************************************/
VCCB_STATIC_INLINE
int16_t VCCB_ProcHandoverRequest_CHO(callInfo_type &callInfo, uint16_t cellNum)
{
    callInfo_type *ptCi = &callInfo;

    // Conditional Handover UE
    if (FnVCCB_IsConditionalHandoverUE(ptCi) == false) return Allowed;

    // FR83.CACP.SR1.HD1
    // Candidate Cell does not allow CHO (CHO allowance = not use) (Cause= Handover Target not Allowed)
    if (FnVCCB_IsConditionalHandoverSupportedByMobilityConfig(cellNum) == false)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : Not Support Cho (MobilityConfig in Yang)\n");
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerHandoverTargetNotAllowed;
        // ptCi->cause.ngCause; // Conditional Handover Only XN Case.
        return Not_Allowed;
    }

    // SVR22C2 does not support CHO replace, and in case of CHO replace,
    // it transmits Handover Preparation Failure (Cause = Handover Target not Allowed) and terminates.
    if (ptCi->hoInfo.choTriggerInd != e_ChoTriggerCause_initiation)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : Not Support Cho Replace Processing\n");
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerHandoverTargetNotAllowed;
        // ptCi->cause.ngCause; // Conditional Handover Only XN Case.
        return Not_Allowed;
    }

    // FR83.CACP.SR1.HD1 - Only partial PDU session/bearer can be setup
    // Fully support source bearer (not support partial accept)
    // In case of partial accept, it sends Handover Preparation Failure and terminates.
    if (FnVCCB_IsAnyPartialDrbQosPdu(callInfo) == Not_Allowed)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : CHO, Detect DRB/PDU/QOS Partial\n");
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerTargetNotAllowed;
        // ptCi->cause.ngCause; // Conditional Handover Only XN Case.
        return Not_Allowed;
    }

    return Allowed;
}

/************************************************************************************************************************
 *  Function    : VCCB_ProcHandoverRequest_MRDC
 *  Description : This function defines the action for MRDC-related settings after allowing Handover Request.
 ************************************************************************************************************************/
VCCB_STATIC_INLINE
int16_t VCCB_ProcHandoverRequest_MRDC(callInfo_type &callInfo, msgUnpack_type &unpack)
{
    int16_t status = GOOD;
    callInfo_type *ptCi = &callInfo;
    msgUnpack_type *ptUnpack = &unpack;

    // NR/NE-DC Mobility
    status = FnVCCB_MrdcMobilityProc_Inter(ptCi, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_MrdcMobilityProc_Inter ERROR!\n");
    if (status == BREAK)
    {
        // TBD
        VCCB_PRINT_CALL_INFORMATIVE(ptCi,
            "This procedure does not yet have an occurrence scenario, so it should be further "
            "developed if necessary.\n");
        return ERROR;
    }

    return GOOD;
}

/************************************************************************************************************************
 *  Function    : FnVCCB_ProcHandoverRequest_Son
 *  Description : This function defines the action for SON-related settings after allowing Handover Request.
 ************************************************************************************************************************/
VCCB_STATIC_INLINE
int16_t FnVCCB_ProcHandoverRequest_Son(callInfo_type &callInfo)
{
    int16_t status = GOOD;
    callInfo_type *ptCi = &callInfo;

    /* update upm config */
    if (VCOM_UpdateUPM_Prepare(ptCi) == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Forced Disabled UPM (PCell, Hand-In) in %s!\n", __func__);
        VCOM_DisableUPM(ptCi);
    }

    //[22B IRAT MRO] Inter-system ping-pong detection Procedure
    status = VCOM_IntersystemPingpongDetection(ptCi);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_IntersystemPingpongDetection ERROR!\n");
    }

    return GOOD;
}

/************************************************************************************************************************
 *  Function    : FnVCCB_ProcHandoverRequest_LogPrint
 *  Description : This function is used to output information after the Handover Request is accepted.
 ************************************************************************************************************************/
VCCB_STATIC_INLINE
void FnVCCB_ProcHandoverRequest_LogPrint(callInfo_type &callInfo)
{
    callInfo_type *ptCi = &callInfo;

    if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "CU is selected the UE as the target for FullConfig(%s).\n",
            (ptCi->hoInfo.hoType.interface == HO_TYPE_XN ? "XN" : "NG"));
    }

    FnVCCB_PrintMrdcDrbInformation(ptCi);
}

/************************************************************************************************************************
 *  Function    : FnVCCB_ProcHandoverRequest_NextStep
 *  Description : This function decides whether to move to each state machine after accepting the Handover Request.
 ************************************************************************************************************************/
VCCB_STATIC_INLINE
int16_t FnVCCB_ProcHandoverRequest_NextStep(callInfo_type &callInfo)
{
    int16_t status = GOOD;
    callInfo_type *ptCi = &callInfo;

    // when MR-DC is used
    if (FnVCCB_IsNeedUpProcessing_For_InterNB(ptCi) == TRUE)
    {
        // When there are MN DRB or There is no MR-DC or SN Release
        status = FnVCCB_NextStep_INTER_Pre_UP_T(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_Pre_UP_T ERROR !! \n");
    }
    else  // There is no MR-DC or SN Release
    {
        // When there is no MN DRB
        if (IS_MRDC(ptCi) && ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_config_ue)
        {
            status = FnVCCB_NextStep_INTER_Pre_SN_T(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_Pre_SN_T ERROR !!\n");
        }
        else
        {
            status = FnVCCB_NextStep_INTER_Pre_DU_T(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_Pre_DU_T ERROR !!\n");
        }
    }

    return GOOD;
}

VCCB_STATIC_INLINE
int16_t FnVCCB_E1ProcedureAfterSNAdditionFail(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{
    int16_t status = GOOD;

    // FGR-CC5201::FR710 partial HO isn't allowed since SN addition fail
    FnVCCB_SetCurrentlyAllowPartialHO(*ptCi, false);

    // Only SN PDU
    if (!GET_E1_RESOURCE_FLAG(ptCi->flag.setupFlag))
    {
        status = FnVCCB_AllocateUPAndE1Setup(ptCi, ptUnpack);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_AllocateUPAndE1Setup ERROR!\n");
        return GOOD;
    }

    // OneStep (E1Mod / E1Setup)
    if (DBG->flag.SNAdditionRejectE1Mod)
    {
        status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

        FnVCCB_ChangeAllValidDrbStatus(ptCi, S_Setup);

        VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextModification_id);
    }
    // Two Step(E1Rel -> E1Setup)
    else
    {
        // Release all bearer including mn term and Setup all bearers together later.
        status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextRelease);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Release) ERROR!\n");

        VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextRelease_id);
    }
    return GOOD;
}

VCCB_STATIC_INLINE 
bool FnVCCB_IsRedCapUeNotAllowedHandover(callInfo_type &rCi, const uint16_t cellNum)
{
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);

    if (not IS_REDCAP_UE((&rCi))) return false;

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    // SVR23B FGR-MC1027 Connected mobility control for RedCap UE
    if ((FALSE == FOO.VF_BasicCallProcedureforRedCapUE) || (TRUE != pCell->redcapBroadcastUsage) ||
        (FALSE == pCell->redcapBroadcastState))
    {
        rCi.cause.xnCause = CauseXnapRadioNetworkLayerNoRadioResourcesAvailableInTargetCell;
        rCi.cause.ngCause = CauseNgapRadioNetworkLayerRedcapUeNotSupported;
        VCCB_PRINT_CALL_ERROR(&rCi, "Not Allowed : RedCap UE Handover (FOO:%d redCap(Usage:%d Status:%d))!\n",
            FOO.VF_BasicCallProcedureforRedCapUE, pCell->redcapBroadcastUsage, pCell->redcapBroadcastState);
        return true;
    }

    // SVR24B FR130
    if (FnVCCB_IsIntraGnbCellHasInvalidSib1SizeForTddType(cellNum, VCCM_GetNrCellDuplexType(&rCi, cellNum)))
    {
        rCi.cause.xnCause = CauseXnapRadioNetworkLayerCellNotAvailable;
        rCi.cause.ngCause = CauseNgapRadioNetworkLayerCellNotavailable;

        VCCB_PRINT_CALL_ERROR(&rCi, "Not Allowed : RedCap UE Handover! targetCellNum(%d) has zero sib1size\n", cellNum);
        return true;
    }

    return false;
}

/************************************************************************************************************************
 *  Function    : FnVCCB_ProcHandoverRequest_NextStep_PreProcessing
 *  Description : This function checks whether to move to each state machine after accepting the Handover Request.
 ************************************************************************************************************************/
VCCB_STATIC_INLINE
AllowedStatus FnVCCB_ProcHandoverRequest_NextStep_PreProcessing(
    callInfo_type &callInfo, const uint16_t cellNum, msgUnpack_type *ptUnpack)
{
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, Not_Allowed);
    VALID_E_POINT_CHECK_RET_VAL(ptUnpack, Not_Allowed);

    int16_t status = GOOD;
    callInfo_type *ptCi = &callInfo;
    const auto msgId = ptUnpack->msgId;
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    if (FnVCCB_IsRedCapUeNotAllowedHandover(callInfo, cellNum))
        return Not_Allowed;

    // The ssb frequency is in restricted frequency and UE has no capability about it.
    if (!FnVCCB_IsSsbAllowed(*ptCi, pCell->ssbArfcn))
    {
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerHandoverTargetNotAllowed;
        ptCi->cause.ngCause = CauseNgapRadioNetworkLayerHandoverTargetNotAllowed; 
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : freq(%u) in the not allowed ssb frequency list!\n", pCell->ssbArfcn);
        return Not_Allowed;
    }

    // FGR-MC1400 :: ConditionalHandover
    if (FnVCCB_IsConditionalHandoverUE(ptCi) == true)
    {
        // FR83.CACP.SR1.HD1
        //  - Candidate Cell does not allow CHO
        //  - VCCB does not support CHO replace, and in case of CHO replace,
        // FR83.CACP.SR1.HD1
        //  - Not Support Any partial PDU session/bearer

        status = VCCB_ProcHandoverRequest_CHO(callInfo, cellNum);
        if (Not_Allowed == status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : Conditional Handover!\n");
            return Not_Allowed;
        }
    }

    // FGR-CC5101 :: Mobility for NE-DC
    // FGR-CC5201 :: Mobility for NR-DC
    // - MRDC Scenario Determination
    //   * Inter-MN with SN Release
    //   * Inter-MN with SN Change
    //   * Inter-MN without SN Change
    // - TargetCell Selection
    status = VCCB_ProcHandoverRequest_MRDC(callInfo, *ptUnpack);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : MRDC Mobility!\n");
        return Not_Allowed;
    }

    // FGR-CC6001 :: AMF Selection and Load Balancing
    if (ptCi->hoInfo.hoType.interface == HO_TYPE_XN)
    {
        if (GOOD != VLIB_getAmfFromGuami(ptCi))
        {
            // MACRO_CALL_FAULT_SAVE fill VRRM_AMFSelection.
            if (AMF_ASSIGN_FAIL_UNKNOWN_GUAMI_ID == GET_XN_AMF_CALL_FAULT_CAUSE(ptCi))
            {
                MACRO_CALL_FAULT_SAVE(msgId, CauseXnapRadioNetworkLayerUnknownGuamiId);
                ptCi->cause.xnCause = CauseXnapRadioNetworkLayerUnknownGuamiId;
            }
            else  //(AMF_ASSIGN_FAIL_INVALID_SET_ID== GET_XN_AMF_CALL_FAULT_CAUSE(ptCi))
            {
                MACRO_CALL_FAULT_SAVE(msgId, CauseXnapRadioNetworkLayerInvalidAmfSetId);
                ptCi->cause.xnCause = CauseXnapRadioNetworkLayerInvalidAmfSetId;
            }
            VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : No available AMF !!\n");
            return Not_Allowed;
        }
    }

    // FGR-MC1007 :: NR Connected Mobility Control
    // Check UE's appliedFreqBandListFilter and System Configuration
    if (BAND_NOT_FOUND == VLIB_GetFreqBandIndForCell(ptCi, &CELLINFO[cellNum]))
    {
        if (HO_TYPE_XN == ptCi->hoInfo.hoType.interface)
        {
            MACRO_CALL_FAULT_SAVE(msgId, CauseXnapRadioNetworkLayerTargetNotAllowed);
            ptCi->cause.xnCause = CauseXnapRadioNetworkLayerTargetNotAllowed;
        }
        else
        {
            MACRO_CALL_FAULT_SAVE(msgId, CauseNgapRadioNetworkLayerHandoverTargetNotAllowed);
            ptCi->cause.ngCause = CauseNgapRadioNetworkLayerHandoverTargetNotAllowed;
        }
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : UE and Cell do not have common frequency band\n");
        return Not_Allowed;
    }

    // FGR-CC1502 :: Call Procedure for LTE-NR Spectrum Sharing
    if (ERROR == VLIB_checkDssAllowed(ptCi, BAND_NOT_SET, false, &CELLINFO[cellNum]))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : VLIB_checkDssAllowed\n");
        if (HO_TYPE_XN == ptCi->hoInfo.hoType.interface)
        {
            MACRO_CALL_FAULT_SAVE(msgId, CauseXnapRadioNetworkLayerTargetNotAllowed);
            ptCi->cause.xnCause = CauseXnapRadioNetworkLayerTargetNotAllowed;
        }
        else
        {
            MACRO_CALL_FAULT_SAVE(msgId, CauseNgapRadioNetworkLayerHandoverTargetNotAllowed);
            ptCi->cause.ngCause = CauseNgapRadioNetworkLayerHandoverTargetNotAllowed;
        }
        return Not_Allowed;
    }

    // Check UP Resource, Select handling gNB-CU-UP
    if (GOOD != VRRM_AUPFSelection(ptCi))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : No available AUPF !!\n");
        MACRO_CALL_FAULT_SAVE(msgId, CauseCpInternalUpAllocationFail);
        return Not_Allowed;
    }

    if (VCCB_IsCellUlInterfered(CELLINFO[cellNum]))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "cellNum %u is Ul Interfered Cell!\n", cellNum);
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerCellNotAvailable;
        ptCi->cause.ngCause = CauseNgapRadioNetworkLayerCellNotavailable;
        return Not_Allowed;
    }

    // MRS
    FnVCCB_SetMultiRatSelectionInitState(ptCi);

    VCCM_SelectInitialUlPath_NRDC(ptCi);
    
    /* update meas config */
    status = VCCB_PrepareNewMeasConfig(ptCi);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : Meas Configuration (VCCB_PrepareNewMeasConfig)!\n");
        return Not_Allowed;
    }

    FnVCCB_ProcHandoverRequest_Trace(callInfo, cellNum);

    // SVR26A FGR-TA0601 VoMA
    vomaCallEvent_type callEvent = VOMA_ngHo;
    if (HO_TYPE_XN == ptCi->hoInfo.hoType.interface)
    {
        callEvent = VOMA_xnHo;
    }

    status = VLIB_VomaActivate(*ptCi, callEvent);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[VoMA][HO] Startup condition not fulfilled\n");
    }

    VRRM_addCellNonDssUeCount(ptCi, cellNum);

    // Update UserInact Config for RedCap and RFSP
    FnVCCB_UpdateUserInactConfigForRedcap(ptCi, FALSE);
    FnVCCB_CheckAndUpdateRfspBasedUserInactivity(ptCi);

    FnVCCB_ProcHandoverRequest_Son(callInfo);

    FnVCCB_ProcHandoverRequest_LogPrint(callInfo);

    FnVCCB_SetMroHandoverTriggerType(ptCi);

    FnVCCB_SetCurrentlyAllowPartialHO(*ptCi, true);

    return Allowed;
}

bool FnVCCB_CheckAcceptedUeInOverloadedGnb(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (VCCM_CheckEmergencyCall(ptCi) == TRUE)
    {
        return true;
    }

    if (VCCM_CheckMpsCall(ptCi) == TRUE)
    {
        return true;
    }

    if (VCCM_CheckHpaCall(ptCi) == TRUE)
    {
        return true;
    }

    return false;
}

/************************************************************************************************************************
 *  Function    : VCCB_ProcHandoverRequest
 *  Description : This function provides the handling operation for Handover Request.
 ************************************************************************************************************************/
int16_t VCCB_ProcHandoverRequest(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    const uint16_t cellNum = ptCi->hoInfo.targetCellNum;  // Same Value - servCellNum and targetCellNum
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    // 0) Default UE Configuration
    status = VCOM_GetSelectedPLMN_For_SaHandIn(ptCi, cellNum, &ptCi->ueInfo.servedPlmn, &ptCi->cause);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "Not Allowed : PLMN Selection (SaHandIn) [cause(NG:%X/XN:%X)]\n",
        ptCi->cause.ngCause, ptCi->cause.xnCause);

    // CSL Info Update - 26A
    FnVCCB_SetVonrAndEmergencyCallForCsl(*ptCi); 

    // If gNB Overload then check acceptable Call
    if (TRUE == ptCi->hoInfo.gnbOverload)
    {
        if (FnVCCB_CheckAcceptedUeInOverloadedGnb(ptCi) == false)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : gNB is overloaded but UE is not an acceptable call\n");
            return ERROR;
        }

        // initialize callFaultCause, xnCause, ngCause
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CAUSE_NO_FAULT);
        ptCi->cause.xnCause = ptCi->cause.ngCause = CAUSE_NO_FAULT;
    }

    status = VHCM_AllocCallSrbInfoForInterNode(ptCi);
    if (ERROR == status)
    {
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalResourceAllocFail);
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : SRB Allocation Fail, status(%d)\n", status);
        return ERROR;
    }

    // 2) PDU/QOS/DRB :: 5QI Support, Slice Aware, VoNR, ...
    if (FnVCCB_ProcHandoverRequest_CheckAndUpdateBearer(*ptCi, ptUnpack->msgId) == Not_Allowed)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowd : Bearer Configuration [cause(NG:%X/XN:%X)]\n",
            ptCi->cause.ngCause, ptCi->cause.xnCause);
        return ERROR;
    }

    // 3) Service(Feature) Based PreProcessing :: CHO, MRDC, CA, MEAS, TRACE, ...
    if (FnVCCB_ProcHandoverRequest_NextStep_PreProcessing(*ptCi, cellNum, ptUnpack) == Not_Allowed)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Not Allowed : Pre-Processing for NextStep [cause(NG:%X/XN:%X)]\n", ptCi->cause.ngCause, ptCi->cause.xnCause);
        return ERROR;
    }

    // 4) Control State Machine
    status = FnVCCB_ProcHandoverRequest_NextStep(*ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_ProcHandoverRequest_NextStep ERROR! [cause(NG:%X/XN:%X)]\n",
        ptCi->cause.ngCause, ptCi->cause.xnCause);

    return GOOD;

}  // }}}

/****************************************************************
 *  Function             : sage_type    *CCB_ProcMsgX2apSgNBAdditionRequest
 *  Description          : Handling NRX2_SgNBAdditionReq message on main task
 *  Procedures defined   :
 *  Procedures called    :
 *  Procedure calling    :
 *  Input                : callInfo_type*, message_type*, msgUnpack_type*
 *  Output               : int16_t (GOOD/ERROR/BREAK)
 *  Statistics Pegged    :
 ***************************************************************/
int16_t VCCB_ProcMsgNgap_HandoverRequest(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    int16_t status = GOOD;
    msgCallSetupReq_type *ptMsg = (msgCallSetupReq_type *)ptAll;

    // Trace/UETHR need to validate RFSP/SPID condition once again
    ptCi->managementTraceInfo.traceRfspSpidAllowed = traceRfspSpidUnknown;

    status = VNIL_StoreNGAP_HandoverRequest(ptCi, ptAll, ptUnpack);

    // FGR-TA0103 Cell traffic trace. FGR-TA0101 Subscriber and equipment trace
    // Check NGAP Handover Request msg and forward to VTMB (also in Store Error case)
    VLIB_collectTraceMessage(ptCi, {RX_MSG, ptUnpack->msgId, (char *)ptMsg->data, ptMsg->length, ptMsg->endPointIdx});

    if (GOOD != status) return status;
    
    if (IS_REDCAP_UE(ptCi))
    {
        VHCM_SA_HO_STAT(ptCi, HO_Att);
    }

    status = VLIB_SecurityHandling(ptCi, FALSE);
    if (ERROR == status)
    {
        MACRO_CALL_FAULT_SAVE(
            ptUnpack->msgId, CauseCpInternalSaInvalidSecurityAlgorithm);
        VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_SecurityHandling ERROR!\n");
        return ERROR;
    }

    FnVCCB_CheckQoSSupportForEcnMarking(*ptCi);
    status = FnVCCB_ValidateGFBRComparedToUeSliceMBR(*ptCi, false, true);
    if (ERROR == status)
    {
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseNgapRadioNetworkLayerRadioResourcesNotAvailable);
        VCCB_PRINT_CALL_ERROR(ptCi, "Sum of GFBR values exceed UE-Slice-MBR! ERROR!\n");
        return ERROR;
    }

    status = VCCB_ProcHandoverRequest(ptCi, ptUnpack);
    if (ERROR == status)
    {
        return ERROR;
    }

    FnVCCB_UpdateUserInactStateAndDoActionIfExpiry(ptCi, UserInactivityEvent_SIG_RESTART);

    VRRM_addCellCallCount(ptCi, ptCi->hoInfo.targetCellNum);

    return GOOD;
}  // }}}

/****************************************************************
 *  Function             : VCCB_ProcMsgXnap_HandoverRequest
 *  Description          : Handling XN_HandoverRequest message
 *  Procedures defined   :
 *  Procedures called    :
 *  Procedure calling    :
 *  Input                : callInfo_type*, message_type*, msgUnpack_type*
 *  Output               : int16_t (GOOD/ERROR/BREAK)
 *  Statistics Pegged    :
 ***************************************************************/
int16_t VCCB_ProcMsgXnap_HandoverRequest(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    int16_t status = GOOD;
    msgCallSetupReq_type *ptMsg = (msgCallSetupReq_type *)ptAll;

    // Trace/UETHR need to validate RFSP/SPID condition once again
    ptCi->managementTraceInfo.traceRfspSpidAllowed = traceRfspSpidUnknown;

    status = FnVCCB_StoreXNMessage(XN_HandoverRequest_id, ptCi, ptAll, ptUnpack);

    // AI⑤: XnAP HandoverRequest 수신 후 소스 셀 체류 시간을 aiCtx 이력에 seed 기록.
    // VXIL_Store_XN_UE_HistoryInformation() 이 FnVCCB_StoreXNMessage() 내부에서 호출되므로
    // visitedCell[] 이 채워진 직후 호출한다.
    VccbAiClient_SeedFromXnapHistory(ptCi);

    // FGR-TA0103 Cell traffic trace. FGR-TA0101 Subscriber and equipment trace
    // Check XNAP Handover Request msg and forward to VTMB (also in Store Error case)
    VLIB_collectTraceMessage(ptCi, {RX_MSG, ptUnpack->msgId, (char *)ptMsg->data, ptMsg->length, ptMsg->endPointIdx});

    if (GOOD != status) return status;

    if (IS_REDCAP_UE(ptCi))
    {
        VHCM_SA_HO_STAT(ptCi, HO_Att);
    }

    status = VLIB_SecurityHandling(ptCi, FALSE);
    if (ERROR == status)
    {
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaInvalidSecurityAlgorithm);
        VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_SecurityHandling ERROR!\n");
        return ERROR;
    }

    FnVCCB_CheckQoSSupportForEcnMarking(*ptCi);
    status = FnVCCB_ValidateGFBRComparedToUeSliceMBR(*ptCi, false, true);
    if (ERROR == status)
    {
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseXnapRadioNetworkLayerNoRadioResourcesAvailable);
        VCCB_PRINT_CALL_ERROR(ptCi, "Sum of GFBR values exceed UE-Slice-MBR! ERROR!\n");
        return ERROR;
    }

    status = VCCB_ProcHandoverRequest(ptCi, ptUnpack);
    if (ERROR == status) return ERROR;

    FnVCCB_UpdateUserInactStateAndDoActionIfExpiry(ptCi, UserInactivityEvent_SIG_RESTART);

    VRRM_addCellCallCount(ptCi, ptCi->hoInfo.targetCellNum);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_SN_T_XN_SNodeAdditionRequestAcknowledge
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_SN_T_XN_SNodeAdditionRequestAcknowledge(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    // Inter-MN with SN Change
    uint16_t notAllowedCause = 0;
    if (FnVCCB_IsAllowedSnodeAdditionRequestAcknowledge(ptCi, ptAll, ptUnpack, &notAllowedCause) == Not_Allowed)
    {
        status = FnVCCB_ProcNotAllowedSnodeAdditionRequestAcknowledge(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_ProcNotAllowedSnodeAdditionRequestAcknowledge ERROR !! \n");

        if (notAllowedCause & NRDC_SN_ADDMOD_NOT_ALLOWED_CAUSE__SN_PARTIAL_FATAL)
        {
            ptCi->cause.xnCause = CauseXnapRadioNetworkLayerNotSupported5qiValue; //25B FGR-CC5201:FR710 HLD 3.5.1.3.3.2
            ptCi->cause.ngCause = CauseNgapRadioNetworkLayerNotSupported5qiValue;

            return ERROR; // 5QI #1 DRB failure, QoS Flow partial is processed as HO Prep Failure
        }

        status = FnVCCB_E1ProcedureAfterSNAdditionFail(ptCi, ptUnpack);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_E1ProcedureAfterSNAdditionFail ERROR !! \n");

        return GOOD;
    }

    status = FnVCCB_CommonMsgProc_XN_SNodeAddition(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    switch (status)
    {
        case ERROR:
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_CommonMsgProc_XN_SNodeAddition(Response) ERROR !!\n");
            return status;

        case RESPONSE_WITH_PARTIAL_SUCCESS:
        {
            if (VCCM_INTER_Pre_SN_T_XN_SNodeAdditionRequestAcknowledge_RearrangePduQosDrbForPartial(ptCi) != GOOD)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_INTER_Pre_SN_T_XN_SNodeAdditionRequestAcknowledge_RearrangePduQosDrbForPartial ERROR !!\n");
                return ERROR; //call release
            }
        }
        default:
            break;
    }

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_PrepSucc);

    status = FnVCCB_NextStep_INTER_Pre_DU_T(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_Pre_DU_T ERROR !!\n");

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_SN_T_XN_SNodeAdditionRequestReject
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_SN_T_XN_SNodeAdditionRequestReject(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    const causeInfo_type backupCause = ptCi->cause;

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_XnFail);

    status = FnVCCB_CommonMsgProc_XN_SNodeAddition(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeAddition(Failure) ERROR !!\n");

    // Since it should not affect the subsequent operation, the cause is returned to its original state.
    ptCi->cause = backupCause;

    /* update the SN release event */
    status = FnVCCB_UpdateBearerTypeForHandover(ptCi, MrdcHoWithSnRelease);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_UpdateBearerTypeForHandover ERROR !! \n");

    // It needs to be called again because the Meas configuration needs to be changed according to the scenario change.
    // Scenario : Scenario Change From 'Inter-MN with/without SN Change' To 'Inter-MN with SN Release' by 'Snode Addition Reject'.
    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");

    status = FnVCCB_E1ProcedureAfterSNAdditionFail(ptCi, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_E1ProcedureAfterSNAdditionFail ERROR !! \n");

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_SN_T_timXN_SNodeAddition
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_SN_T_timXN_SNodeAddition(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_XnFail);

    status = FnVCCB_CommonMsgProc_XN_SNodeAddition(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeAddition(TMOUT) ERROR !!\n");

    /* update the SN release event */
    status = FnVCCB_UpdateBearerTypeForHandover(ptCi, MrdcHoWithSnRelease);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_UpdateBearerTypeForHandover ERROR !! \n");

    // It needs to be called again because the Meas configuration needs to be changed according to the scenario change.
    // Scenario : Scenario Change From 'Inter-MN with/without SN Change' To 'Inter-MN with SN Release' by 'Snode Addition TMOUT'.
    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");

    status = FnVCCB_E1ProcedureAfterSNAdditionFail(ptCi, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_E1ProcedureAfterSNAdditionFail ERROR !! \n");

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_SN_T_E1_BearerContextSetupModSuccess
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_SN_T_E1_BearerContextSetupModSuccess(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int16_t status = GOOD;
    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    status = FnVCCB_NextStep_INTER_Pre_DU_T(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_Pre_DU_T ERROR !!\n");

    return status;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_SN_T_E1_BearerContextSetupModUnsuccess
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**
 * *  Output : void
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_SN_T_E1_BearerContextSetupModUnsuccess(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, CANCEL_TIMER);

    FnVCCB_CollectingSaHandoverStatistics_E1Fail(ptCi);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->cause.e1Cause);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_SN_T_E1_BearerContextReleaseComplete
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_SN_T_E1_BearerContextReleaseComplete(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_StoreE1Message(E1_BearerContextReleaseComplete_id, ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "StoreE1Message(E1RelCom) ERROR!\n");

    status = FnVCCB_AllocateUPAndE1Setup(ptCi, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_AllocateUPAndE1Setup ERROR!\n");

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_SN_T_timE1_BearerContextRelease
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_SN_T_timE1_BearerContextRelease(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    OFF_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // LOGGING
    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, timE1_BearerContextRelease_id, sizeof(messageHdr_type), (uint8_t *)ptAll);

    return GOOD;
}  // }}}

int16_t VCCM_INTER_Exe_T_timE1_BearerContextReleaseComplete(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    OFF_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // LOGGING
    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, timE1_BearerContextRelease_id, sizeof(messageHdr_type), (uint8_t *)ptAll);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_SN_T_E1_BearerContextSetupResponse
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_SN_T_E1_BearerContextSetupResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_StoreE1Message(E1_BearerContextSetupResponse_id, ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_NBREAK(ptCi, status, "StoreE1Message(E1SetupRsp) waiting for other UPs to respond.\n");
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "StoreE1Message(E1SetupRsp) ERROR!\n");

    status = FnVCCB_NextStep_INTER_Pre_DU_T(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_Pre_DU_T ERROR !!\n");

    return status;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_UP_T_E1_BearerContextSetupSuccess
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_UP_T_E1_BearerContextSetupSuccess(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int16_t status = GOOD;
    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    return status;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_UP_T_E1_BearerContextSetupUnsuccess
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**
 * *  Output : void
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_UP_T_E1_BearerContextSetupUnsuccess(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    FnVCCB_CollectingSaHandoverStatistics_E1Fail(ptCi);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->cause.e1Cause);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_UP_T_timE1_BearerContextSetup
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_UP_T_timE1_BearerContextSetup(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_UpFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_E1TimeOut);
    CHO_STAT(ptCi, CHO_PrepFail_E1Fail, ptCi->hoInfo.cgi);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerSetup);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_DU_T_F1_UEContextSetupResponse
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_DU_T_F1_UEContextSetupResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    F1ResponsePreChecker f1PreChecker(*ptCi, ptAll, ptUnpack);
    bool isAllowedResponse = f1PreChecker.isAllowedResponse();

    if (not ptCi->hoInfo.sliceRejectionStats)
    {
        ptCi->hoInfo.sliceRejectionStats = f1PreChecker.getIsDrbFailedDueToSNotAvailableSlice(); // SVR25B FGR-MC1021:FR210 FR220
    }

    if (Not_Allowed == isAllowedResponse)
    {
        ptCi->hoInfo.notSupportedVonr = f1PreChecker.getIs5qi1DrbFailedWithCause(); //25A FGR-MC1008:FR580

        if (f1PreChecker.getIsSpecificSliceDrbFailed()) // 25B PMB FGR-MC1021:FR140
        {
            MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, f1PreChecker.getFinalFailedCause());
            ptCi->cause.xnCause = CauseXnapRadioNetworkLayerResourcesNotAvailableForTheSlice;
            ptCi->cause.ngCause = CauseNgapRadioNetworkLayerSliceNotSupported;

            VHCM_SA_HO_STAT(ptCi, HO_Fail_CpFail);
            VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_CpFail);
        }
        else if (f1PreChecker.getIsFullConfigNotAllowed())
        {
            ptCi->cause.xnCause = CauseXnapRadioNetworkLayerHandoverTargetNotAllowed;
            ptCi->cause.ngCause = CauseNgapRadioNetworkLayerHandoverTargetNotAllowed;
        }
        else if (f1PreChecker.getIs5qi1DrbFailed() || f1PreChecker.getIsPartialSuccessNotAllowed())
        {
            MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, f1PreChecker.getFinalFailedCause());
            ptCi->cause.xnCause = CauseXnapRadioNetworkLayerNotSupported5qiValue; //25B FGR-CC5201:FR710 HLD 3.5.1.4.1
            ptCi->cause.ngCause = CauseNgapRadioNetworkLayerNotSupported5qiValue;

            VHCM_SA_HO_STAT(ptCi, HO_Fail_CpFail);
            VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_CpFail);
        }

        return ERROR;
    }

    status = VFIL_storeF1_UeContextSetupResponse(ptCi, ptAll, ptUnpack);
    switch (status)
    {
        case BREAK:
            VCCB_PRINT_CALL_ERROR(ptCi, "F1_UEContextSetupResponse :: Received by other DU and ignored.\n");
            ptCi->hoInfo.notSupportedVonr = false; // SVR25A FGR-MC1009 FR580
            return BREAK;
        case ERROR:
            VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_storeF1_UeContextSetupResponse ERROR !!\n");
            VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
            VHCM_SA_HO_STAT(ptCi, HO_Fail_F1Fail);
            return ERROR;
        // SVR25A FGR-MC1009 FR200
        case RESPONSE_WITH_PARTIAL_SUCCESS:
            if (GOOD != FnVCCB_RearrangePduQosDrbStatusByPartialResponse(ptCi, PARTIAL_INTERFACE_F1))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_storeF1_UeContextSetupResponse ERROR (status:%d)\n", status);
                MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->drbPartialInfo.e1f1Info[PARTIAL_INTERFACE_F1].finalFailCause);
                VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
                VHCM_SA_HO_STAT(ptCi, HO_Fail_F1Fail);
                return ERROR;
            }

            VCCB_PRINT_CALL_HO_SERVICE_TYPE(
                ptCi, "INTER-GNB HO RESPONSE_WITH_PARTIAL_SUCCESS from F1_UEContextSetupResponse \n");
            VHCM_SA_HO_IN_PARTIAL_FAIL_SERVICE_TYPE_STAT(ptCi, HO_PrepFail_F1Fail);

            FnVCCB_SetBitToReleaseDRB(*ptCi, [](callDRBInfo_type &rDrb)
                { return (rDrb.drbStatus == S_FailToSetup && rDrb.needToReconfigE1ByF1Fail == TRUE); });
            break;
        default:
            break;
    }

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_DU_T_F1_UEContextSetupFailure
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_DU_T_F1_UEContextSetupFailure(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    // SVR25A FGR-MC1009 FR580
    FnVCCB_Check_F1FailureCuaseForStat(ptCi, ptUnpack);

    status = VFIL_storeF1_UeContextSetupFailure(ptCi, ptAll, ptUnpack);
    switch (status)
    {
        case BREAK:
            VCCB_PRINT_CALL_ERROR(ptCi, "F1_UEContextSetupFailure :: Received by other DU and ignored.\n");
            ptCi->hoInfo.notSupportedVonr = false; // SVR25A FGR-MC1009 FR580
            return BREAK;
        case ERROR:
            VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_storeF1_UeContextSetupFailure ERROR !!\n");
            VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
            VHCM_SA_HO_STAT(ptCi, HO_Fail_F1Fail);
            return ERROR;
        default:
            break;
    }

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_F1Fail);
    CHO_STAT(ptCi, CHO_PrepFail_F1Fail, ptCi->hoInfo.cgi);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Pre_DU_T_timF1_UeContextSetup
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Pre_DU_T_timF1_UeContextSetup(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_F1TimeOut);
    CHO_STAT(ptCi, CHO_PrepFail_F1Fail, ptCi->hoInfo.cgi);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutF1UeContextSetup);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : FnVCCB_INTER_Exe_T_RxProcessForDebugMode
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t FnVCCB_INTER_Exe_T_RxProcessForDebugMode(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    if (GET_RRC_RECONFIG_FLAG(ptCi->flag.respFlag)) return GOOD;  // wait another message

    if (GET_F1_ACCESS_SUCCESS_FLAG(ptCi->flag.respFlag)) return GOOD;  // wait another message

    // RRC Reconfiguration Complete Indicator
    status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_sendF1_UeContextModificationRequest ERROR!\n");
        return ERROR;
    }

    VLIB_AttachTimer(&ptCi->hoInfo.timer.f1, ptCi, timF1_UeContextModification_id);

    return GOOD;
}

/****************************************************************
 * *  Function     : VCCM_INTER_Exe_T_E1_BearerContextModificationSuccess
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Exe_T_E1_BearerContextModificationSuccess(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, CANCEL_TIMER);

    OFF_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    if (GET_E1_PDCP_SN_FLAG(ptCi->flag.setupFlag))
    {
        OFF_E1_PDCP_SN_FLAG(ptCi->flag.setupFlag);

        status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

        VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextModification_id);
    }

    return status;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Exe_T_E1_BearerContextModificationUnsuccess
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, msgUnpack_type*
 * *  Output : void
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Exe_T_E1_BearerContextModificationUnsuccess(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, CANCEL_TIMER);

    if (ptCi->endPointInfo.srvAupfNum > 1 && 
        true == CheckifPartialSuccesAndEnueueBearersRelease(ptCi))
    {
        OFF_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);
        return RESPONSE_WITH_PARTIAL_SUCCESS;
    }

    FnVCCB_CollectingSaHandoverStatistics_E1Fail(ptCi);

    if (GET_RRC_RECONFIG_FLAG(ptCi->flag.respFlag))
    {
        /*
            This counter is the number of times that the CHO Candidate Release procedure is performed
            because of a failure in the UP after completing the Inter-gNB Xn CHO Preparation procedure.
        */
        if (FnVCCB_IsConditionalHandoverUE(ptCi))
        {
            CHO_STAT(ptCi, CHO_CandidateRel_UpInit, ptCi->hoInfo.cgi);
        }
    }

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->cause.e1Cause);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Exe_T_E1_BearerContextModificationUnsuccess
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, msgUnpack_type*
 * *  Output : void
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_HO_Common_BearerContextModificationUnsuccess(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, CANCEL_TIMER);

    FnVCCB_CollectingSaHandoverStatistics_E1Fail(ptCi);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->cause.e1Cause);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Exe_T_timE1_BearerContextModification
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Exe_T_timE1_BearerContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, INIT_TIMER);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_UpFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_E1TimeOut);
    CHO_STAT(ptCi, CHO_ExeFail_E1Fail, ptCi->hoInfo.cgi);

    if (GET_RRC_RECONFIG_FLAG(ptCi->flag.respFlag))
    {
        /*
            This counter is the number of times that the CHO Candidate Release procedure is performed
            because of a failure in the UP after completing the Inter-gNB Xn CHO Preparation procedure.
        */
        if (FnVCCB_IsConditionalHandoverUE(ptCi))
        {
            CHO_STAT(ptCi, CHO_CandidateRel_UpInit, ptCi->hoInfo.cgi);
        }
    }

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Exe_T_timNRRRC_RRCReconfig
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Exe_T_timNRRRC_RRCReconfig(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, INIT_TIMER);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_RrcFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_RrcTimeOut);
    CHO_STAT(ptCi, CHO_ExeFail_gNBFail, ptCi->hoInfo.cgi);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaHoTmOutRrcHandoverComplete);

    return GOOD;
}  // }}}

/****************************************************************************
 * @brief           Handling NR-RRC Setup Complete in state STATE_INTER_Exe_T
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_INTER_Exe_T_NRRRC_RrcReconfigurationComplete(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VHCM_SA_PP_HO_STAT(ptCi);

    if (VRIL_storeNRRRC_RrcReconfigurationComplete(ptCi, ptUnpack) == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VRIL_storeNRRRC_RrcReconfigurationComplete ERROR!\n");
        return ERROR;
    }

    // TODO: need ot check... send it when gNB receives the SCG response (ex. SRB 3 case??)
    if (IS_MRDC(ptCi) && ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_config_ue)
    {
        // SEnd XN Confirm and E1..
        if (FnVCCB_NeedToSendXnSNodeReconfigurationComplete(ptCi) == true)
        {
            uint8_t targetXN = 0;
            if (FnVCCB_IsInterSnMobilityInMn(ptCi))
            {
                targetXN = e_Snode_MnToTgtSn;
            }

            status = FnVCCB_SendXNMessage(XN_SNodeReconfigurationComplete_id, ptCi, &targetXN, nullptr);
            VCCB_RETURN_ON_CALL_ERROR(
                ptCi, status, "FnVCCB_SendXNMessage(XN_SNodeReconfigurationComplete_id) Error!!\n");
        }

        VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Succ);
    }

    if (!GET_RRC_RECONFIG_FLAG(ptCi->flag.respFlag) && !GET_SN_STATUS_FLAG(ptCi->flag.respFlag))
    {
        VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, CANCEL_TIMER);  // Ng/Xn-Handover Complete
    }

    FnVCCB_InitializationChoDbForExecution(ptCi);  // SA, Inter-GNB HO, XN/NG, Target

    VLIB_SAHandoverTime(ptCi, CAL_STOP);
    if (ComTimeUtil::get_current_time(ptCi->ueHistory.startTime) < 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ComTimeUtil::get_current_time ERROR in %s\n", __func__);
    }

    VLIB_SetCurrentTime(&ptCi->cslInfo.connectInfo.completeTime);

    if (DBG->flag.choSendF1ComplAfterReceivingAccesSsucessAndRrcCompl)
    {
        if (FnVCCB_IsConditionalHandoverUE(ptCi) == true)
        {
            return FnVCCB_INTER_Exe_T_RxProcessForDebugMode(ptCi);
        }
    }

    // RRC Reconfiguration Complete Indicator
    status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_sendF1_UeContextModificationRequest ERROR!\n");
        return ERROR;
    }

    VLIB_AttachTimer(&ptCi->hoInfo.timer.f1, ptCi, timF1_UeContextModification_id);

    return GOOD;
}  // }}}

/****************************************************************************
 * @brief
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_INTER_Exe_T_SnCommonProc(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FnVCCB_IsAnyMnTermPerUE(ptCi, request_bearerType) == true)
    {
        if (!GET_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag))
        {
            status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

            VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextModification_id);
        }
        else
        {
            ON_E1_PDCP_SN_FLAG(ptCi->flag.setupFlag);
        }
    }

    // 23B::FR181 in case of HO Execution & CHO & received SN Status, RRE procedure can be done
    if (FnVCCB_IsConditionalHandoverUE(ptCi) == true)
    {
        FnVCCB_insertAllocCallDbForRRE(ptCi);
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Handling NR-RRC Setup Complete in state STATE_INTER_Exe_T
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_INTER_Exe_T_XN_SNStatusTransfer(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    OFF_SN_STATUS_FLAG(ptCi->flag.respFlag);

    if (!GET_RRC_RECONFIG_FLAG(ptCi->flag.respFlag) && !GET_SN_STATUS_FLAG(ptCi->flag.respFlag))
    {
        VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, CANCEL_TIMER);  // Ng/Xn-Handover Complete
    }

    status = FnVCCB_StoreXNMessage(XN_SNStatusTransfer_id, ptCi, ptAll, ptUnpack);
    if (ERROR == status) return ERROR;

    // Inter SN && [TODO: which condition?? SN term???]
    if (FnVCCB_IsInterSnMobilityInMn(ptCi) && FnVCCB_IsAnySnTermPerUE(ptCi, request_bearerType))
    {
        uint8_t targetXN = 0;
        if (FnVCCB_IsInterSnMobilityInMn(ptCi))
        {
            targetXN = e_Snode_MnToTgtSn;
        }

        status = FnVCCB_SendXNMessage(XN_SNStatusTransfer_id, ptCi, &targetXN, nullptr);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_SNStatusTransfer) ERROR!\n");
    }

    status = VCCM_INTER_Exe_T_SnCommonProc(ptCi);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_INTER_Exe_T_SnCommonProc(XN) ERROR!\n");
        return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Handling NR-RRC Setup Complete in state STATE_INTER_Exe_T
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_INTER_Exe_T_NG_DownlinkRANStatusTransfer(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    OFF_SN_STATUS_FLAG(ptCi->flag.respFlag);

    if (!GET_RRC_RECONFIG_FLAG(ptCi->flag.respFlag) && !GET_SN_STATUS_FLAG(ptCi->flag.respFlag))
    {
        VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, CANCEL_TIMER);  // Ng/Xn-Handover Complete
    }

    if (VNIL_StoreNGAP_DownlinkRanStatusTransfer(ptCi, ptAll, ptUnpack) == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VNIL_StoreNGAP_DownlinkRanStatusTransfer ERROR!\n");
        return ERROR;
    }

    // Inter SN && [TODO: which condition?? SN term???]
    if (FnVCCB_IsInterSnMobilityInMn(ptCi) && FnVCCB_IsAnySnTermPerUE(ptCi, request_bearerType))
    {
        uint8_t targetXN = 0;
        if (FnVCCB_IsInterSnMobilityInMn(ptCi))
        {
            targetXN = e_Snode_MnToTgtSn;
        }

        status = FnVCCB_SendXNMessage(XN_SNStatusTransfer_id, ptCi, &targetXN, nullptr);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_SNStatusTransfer) ERROR!\n");
    }

    status = VCCM_INTER_Exe_T_SnCommonProc(ptCi);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_INTER_Exe_T_SnCommonProc(NG) ERROR!\n");
        return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Handling NR-RRC Setup Complete in state STATE_INTER_Exe_T
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_INTER_Exe_T_timInternalInterGnbSnStatusTransfer(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    if (ptCi->hoInfo.hoType.interface == HO_TYPE_XN)
    {
        VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_XnFail);
        VHCM_SA_HO_STAT(ptCi, HO_Fail_XnTimeOut);
        CHO_STAT(ptCi, CHO_ExeFail_XnFail, ptCi->hoInfo.cgi);

        // CALL FAULT
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaHoTmOutXnSNStatusTransfer);
    }
    else
    {
        VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_XnFail);
        VHCM_SA_HO_STAT(ptCi, HO_Fail_NgTimeOut);

        // CALL FAULT
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaHoTmOutNgDownlinkRanStatusTransfer);
    }

    OFF_SN_STATUS_FLAG(ptCi->flag.respFlag);

    return GOOD;
}

/****************************************************************************
 * @brief           Handling NR-RRC Setup Complete in state STATE_INTER_Exe_T
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_INTER_Exe_T_F1_UEContextModificationResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, CANCEL_TIMER);

    status = VFIL_storeF1_UeContextModificationResponse(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationResponse ERROR!\n");

    OFF_F1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    return GOOD;
}

/****************************************************************************
 * @brief           Handling NR-RRC Setup Complete in state STATE_INTER_Exe_T
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_INTER_Exe_T_F1_UEContextModificationFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, CANCEL_TIMER);

    status = VFIL_storeF1_UeContextModificationFailure(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationFailure ERROR!\n");

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_F1Fail);
    CHO_STAT(ptCi, CHO_ExeFail_F1Fail, ptCi->hoInfo.cgi);

    return GOOD;
}

/****************************************************************************
 * @brief           Handling NR-RRC Setup Complete in state STATE_INTER_Exe_T
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_INTER_Exe_T_timF1_UeContextModification(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, INIT_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutF1UeContextModification);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_F1TimeOut);
    CHO_STAT(ptCi, CHO_ExeFail_F1Fail, ptCi->hoInfo.cgi);

    return GOOD;
}

/****************************************************************************
 * @brief           Handling F1 ACCESS SUCCESS in state STATE_INTER_Exe_T
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_INTER_Exe_T_F1_AccessSuccess(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;
    conditionalCellInfo_type *ptCondCell = NULL;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = VFIL_storeF1_AccessSuccess(ptCi, ptAll, ptUnpack, &ptCi->condHoInfo.targetCgi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_AccessSuccess ERROR!\n");

    VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "Conditional Execution CGI(%X-%llu) in F1_AccessSuccess\n",
            ptCi->condHoInfo.targetCgi.plmn.longId, ptCi->condHoInfo.targetCgi.ci * 1LLU);

    ptCondCell = FnVCCB_GetConditionalCellInfoForCGI(ptCi, ptCi->condHoInfo.targetCgi);
    if (NULL == ptCondCell)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "F1 Access Success with invalid NRCGI, Ignored!!\n");
        return GOOD;
    }

    // FLAG OFF
    OFF_F1_ACCESS_SUCCESS_FLAG(ptCi->flag.respFlag);

    CHO_STAT(ptCi, CHO_ExeAccess, ptCi->condHoInfo.targetCgi);  // STAT_CHO_IN

    status = FnVCCB_StartConditionalHandoverExecutionProcedure(ptCi, HO_TYPE_INTER_NB_TARGET);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_StartConditionalHandoverExecutionProcedure ERROR !!\n");

    if (GET_RRC_RECONFIG_FLAG(ptCi->flag.respFlag) || GET_SN_STATUS_FLAG(ptCi->flag.respFlag))
        VLIB_AttachTimer(&ptCi->hoInfo.timer.spec, ptCi, timXN_HandoverComplete_id); // Conditional Handover

    if (DBG->flag.choSendF1ComplAfterReceivingAccesSsucessAndRrcCompl)
    {
        return FnVCCB_INTER_Exe_T_RxProcessForDebugMode(ptCi);
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Handling NG Path Swith Request Acknowledge in state STATE_INTER_Switch_T
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_INTER_Switch_T_NG_PathSwitchRequestAcknowledge(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    uint32_t collectFailToSetupStat = VCCB_FLAG_OFF;
    SET_ON_ALL_RETAIN_STAT_CAPABLE_FLAG(ptCi, collectFailToSetupStat, VCCB_FLAG_ON);  // RETAIN_STAT_HO_21A

    if (VNIL_StoreNGAP_PathSwitchRequestAcknowledge(ptCi, ptAll, ptUnpack) == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VNIL_StoreNGAP_PathSwitchRequestAcknowledge ERROR!\n");
        return ERROR;
    }
    // Security Capabilities are not changing from AMF and Derive is handled in Intra Cell Handover
    /*
    status = VLIB_SecurityHandling(ptCi, TRUE);
    if (ERROR == status)
    {
        MACRO_CALL_FAULT_SAVE(
            ptUnpack->msgId, CauseCpInternalSaInvalidSecurityAlgorithm);
        VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_SecurityHandling ERROR !!\n");
        return ERROR;
    }
    */

    // Check if and send Cell traffic trace to eNB/AMF
    status = VCCM_enqueueActionWithForce(ptCi, ENQUEUE_ACTION_SEND_MGT_CELL_TRAFFIC_TRACE,true);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "[MDT][MGT] VCCM_enqueueActionWithForce(ENQUEUE_ACTION_SEND_MGT_CELL_TRAFFIC_TRACE) ERROR\n");
 
    // This function works only when there is a queuing message.
    status = FnVCCB_ProcULNasMsgDequeueForSaMobility(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_ProcULNasMsgDequeueForSaMobility ERROR!\n");

    if (FnVCCB_IsAnyMnTermPerUE(ptCi, request_bearerType) == true &&
        FnVCCB_IsMnTermNguUlTnlChangedFromHoPathSwitchAck(ptCi) == true)  // INTER_GNB_XN_HO_22C2
    {
        status = FnVCCB_NextStep_INTER_Compl_T(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_Compl_T ERROR!\n");
    }
    else
    {
        // Since the E1 procedure is not performed, the success operation of INTER_Compl_T is performed.
        // TODO The function name needs to be changed. May be misleading.
        status = VCCM_INTER_Compl_T_E1_BearerContextModificationSuccess(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_INTER_Compl_T_E1_BearerContextModificationSuccess ERROR!\n");
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Handling NG Path Swith Request Failure in state STATE_INTER_Switch_T
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_INTER_Switch_T_NG_PathSwitchRequestFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    uint32_t collectFailToSetupStat = VCCB_FLAG_OFF;
    SET_ON_ALL_RETAIN_STAT_CAPABLE_FLAG(ptCi, collectFailToSetupStat, VCCB_FLAG_ON);  // RETAIN_STAT_HO_21A

    // The NG-RAN node shall release the corresponding QoS flows and regard the PDU session(s) indicated
    // in the PDU Session Resource Released List IE included in the PATH SWITCH REQUEST FAILURE message as being
    // released.
    if (VNIL_StoreNGAP_PathSwitchRequestFailure(ptCi, ptAll, ptUnpack) == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VNIL_StoreNGAP_PathSwitchRequestFailure ERROR!\n");
        return ERROR;
    }

    VLIB_SaveEventForCallRetainStat(ptCi, RetainCategory_PathSwitchFailure, ptCi->cause.ngCause);  // RETAIN_STAT_HO_21A

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_XnFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_NgFail);
    CHO_STAT(ptCi, CHO_ExeFail_NgFail, ptCi->hoInfo.cgi);

    return GOOD;
}

/****************************************************************************
 * @brief           Handling NG Path Swith Request Acknowledge in state STATE_INTER_Switch_T
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_INTER_Switch_T_timNG_PathSwitch(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaHoTmOutNgPathSwitchRequest);

    OFF_NGC_CONNECTION_FLAG(ptCi->flag.respFlag);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_XnFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_NgTimeOut);
    CHO_STAT(ptCi, CHO_ExeFail_NgFail, ptCi->hoInfo.cgi);

    return GOOD;
}

/****************************************************************
 * *  Function     : VCCM_INTER_Compl_T_E1_BearerContextModificationSuccess
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Compl_T_E1_BearerContextModificationSuccess(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    OFF_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    status = FnVCCB_NextStep_INTER_T_HandoverComplete(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_T_HandoverComplete ERROR !!\n");

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Compl_T_E1_BearerContextModificationUnsuccess
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, msgUnpack_type*
 * *  Output : void
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Compl_T_E1_BearerContextModificationUnsuccess(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    FnVCCB_CollectingSaHandoverStatistics_E1Fail(ptCi);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->cause.e1Cause);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : VCCM_INTER_Compl_T_timE1_BearerContextModification
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t VCCM_INTER_Compl_T_timE1_BearerContextModification(
    callInfo_type *ptCi, const message_type *ptAll, const msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_UpFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_E1TimeOut);
    CHO_STAT(ptCi, CHO_ExeFail_E1Fail, ptCi->hoInfo.cgi);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    return GOOD;
}  // }}}
// }}}

/****************************************************************************
                    Intra gNB, Inter DU
****************************************************************************/
// {{{

int16_t FnVCCB_NextStep_INTER_DU_DuQuery(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTER_DU_DuQuery);

    ptCi->ueInfo.duConfQuery = VCCB_FLAG_ON;
    status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
    ptCi->ueInfo.duConfQuery = VCCB_FLAG_OFF;
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextModificationRequest ERROR !!\n");

    VLIB_AttachTimer(&ptCi->timer, ptCi, timF1_UeContextModification_id);

    if (FnVCCB_IsInterSnMobilityInMn(ptCi))
    {
        /* set scgConfigQuery to 'VCCB_FLAG_ON' and init buffer before send SN modification request */
        VLIB_Set_MrdcScgConfigQuery(ptCi, VCCB_FLAG_ON);

        /* send SN modification request */
        status = FnVCCB_SendXNMessage(XN_SNodeModificationRequest_id, ptCi, nullptr, nullptr);  // error log already printed inside the function

        VLIB_Set_MrdcScgConfigQuery(ptCi, VCCB_FLAG_OFF);

        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_SNodeModificationRequest_id) Error!!\n");

        VLIB_AttachTimer(&ptCi->hoInfo.timer.xn, ptCi, timXN_SNodeModification_id);
    }

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_INTER_DU_E1Stop(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTER_DU_E1Stop);

    {
        status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");
            return ERROR;
        }

        VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);

        return GOOD;
    }

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_INTER_DU_SnAdd(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTER_DU_SnAdd);

    {
        fullConfiguration_type backupDB;
        ForcedCuInitFullConfigForXnSnAddReqMake mnInitFullConfig(ptCi, &backupDB);
        mnInitFullConfig.procXnSnAddReq();

        uint8_t targetXN = e_Snode_MnToTgtSn;
        status = FnVCCB_SendXNMessage(XN_SNodeAdditionRequest_id, ptCi, &targetXN, nullptr);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "nVCCB_SendXNMessage(XN_SNodeAdditionRequest_id) ERROR!\n");

        VLIB_AttachTimer(&ptCi->hoInfo.timer.xn, ptCi, timXN_SNodeAddition_id);

        VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Att);
    }

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_INTER_DU_SnMod(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTER_DU_SnMod);

    {
        // measResult for PSCell Change
        status = FnVCCB_SendXNMessage(XN_SNodeModificationRequest_id, ptCi, nullptr, nullptr);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_send_XN_SNodeModificationRequest_ERROR!\n");

        VLIB_AttachTimer(&ptCi->hoInfo.timer.xn, ptCi, timXN_SNodeModification_id);

        // Possibility of change according to PSCELL change request
        ptCi->hoInfo.cancelControl.needSnRelease = true;
    }

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_INTER_DU_SnRelA(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTER_DU_SnRelA);

    status = FnVCCB_NextStep_Common_DU_SnRelA(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Common_DU_SnRelA!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_INTER_DU_SnRelB(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VLIB_SetCurStateAll(ptCi, STATE_INTER_DU_SnRelB);

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    status = FnVCCB_NextStep_Common_DU_SnRelB(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Common_DU_SnRelB!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_INTER_DU_Prepare(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VCCB_clearAllFailedCarrier(&ptCi->caInfo.failures);
    VLIB_ConfigSecondaryCellList(ptCi);
    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig!\n");

    VLIB_SetCurStateAll(ptCi, STATE_INTER_DU_Prepare);

    if (HO_TYPE_INTER_DU == ptCi->hoInfo.hoType.du)
    {
        if (HO_TYPE_INTRA_NB == ptCi->hoInfo.hoType.nb)
        {
            // suppress sending F1_DeactivateTrace 
            ptCi->signalingTraceInfo.traceActivationStatus.F1delivered = false;
            sigMdtUethrIntraGnbReactivation(ptCi, ptCi->servCellNum, ptCi->hoInfo.targetCellNum);
        }
    }

    // cellGroupConfig, Target DU
    status = VFIL_sendF1_UeContextSetupRequest(ptCi, NULL, 0);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextSetupRequest ERROR!\n");

    VLIB_AttachTimer(&ptCi->timer, ptCi, timF1_UeContextSetup_id);

    VHCM_SA_HO_STAT(ptCi, HO_Att);

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_INTER_DU_Exe_T(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    /* exchange the state to build the specific message to DU */
    VLIB_SetCurStateAll(ptCi, STATE_INTER_DU_Exe_T);

    status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextModificationRequest ERROR!\n");

    VLIB_AttachTimer(&ptCi->timer, ptCi, timF1_UeContextModification_id);

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_INTER_DU_Execution(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int16_t status;

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    FnVCCB_InitMrsInfo(ptCi, MRS_DIFF_PREV_PRARM_INIT);
    FnVCCB_InitSccData(ptCi, SCC_HO_EXEC_INIT);

    VLIB_SetCurStateAll(ptCi, STATE_INTER_DU_Execution);

    status = VCOM_SaInterDuHandover_ToExecution(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCOM_SaInterDuHandover_ToExecution ERROR!\n");

    status = FnVCCB_NextStep_Common_DU_Execution(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Common_DU_Execution!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_INTER_DU_Complete(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTER_DU_Complete);

    status = FnVCCB_NextStep_Common_Complete(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Common_Complete!\n");

    // F1 Release
    if (VFIL_sendF1_UeContextReleaseCommand(ptCi, NULL, 0, ID_SRB0, DU_HO_SOURCE) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_sendF1_UeContextReleaseCommand Error!!\n");
    }

    VLIB_AttachTimer(&ptCi->timer, ptCi, timF1_UeContextRelease_id);

    return GOOD;
}  // }}}

int16_t FnVCCB_INTER_DU_Prepare_rxProcess(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // Check if all messages to proceed to the next state have been received.
    if (VLIB_CheckAllConnected(ptCi) == ERROR)
    {
        return GOOD;
    }

    FnVCCB_SetHandoverExecution(ptCi);

    VHCM_SA_HO_STAT(ptCi, HO_PrepSucc);

    // The information(TNL) received through F1 UE Context Setup must be delivered to the SN.
    if (FnVCCB_IsAnySnTermSplitPerUE(ptCi, request_bearerType) &&
        ptCi->mrdcInfo.mobilityCfg.ueState != ci_scg_released_ue)
    {
        ON_BITFLAG_NEED_XNUADDRIND_FOR_DLUPTNL(ptCi);

        uint8_t targetXN = 0;
        if (FnVCCB_IsInterSnMobilityInMn(ptCi))
        {
            targetXN = e_Snode_MnToTgtSn;
        }

        status = FnVCCB_SendXNMessage(XN_XnUAddressIndication_id, ptCi, &targetXN, nullptr);
        OFF_BITFLAG_NEED_XNUADDRIND_FOR_DLUPTNL(ptCi);

        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage (XN_XnUAddressIndication_id) ERROR!\n");
    }

    /* Send the New NR U tunnel to Target DU */
    if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi))
    {
        status = FnVCCB_NextStep_INTER_DU_Exe_T(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_Exe_T ERROR!\n");
    }
    else
    {
        status = FnVCCB_NextStep_INTER_DU_Execution(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_Execution ERROR!\n");
    }

    return GOOD;
}  // }}}

// }}}
// {{{
// STATE_INTER_DU_DuQuery
int16_t FnVCCB_INTER_DU_DuQuery_rxProcess(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    if (VLIB_CheckAllConnected(ptCi) == ERROR)
    {
        return GOOD;
    }

    VCCM_InitSaMeasData(ptCi);

    FnVCCB_UpdateMrsInfo(ptCi, MRS_INFO_TO_PREV_MRS_INFO);
    FnVCCB_InitMrsInfo(ptCi, MRS_SAME_PREV_PRARM_INIT);
    FnVCCB_SetMultiRatSelectionInitState(ptCi);
    FnVCCB_InitSccData(ptCi, SCC_HO_PREP_INIT);
    FnVCCB_InitOnDemandMeasConfig(ptCi); 

    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");

    if (IS_MRDC(ptCi) == true)
    {
        if (FnVCCB_IsInterSnMobilityInMn(ptCi))
        {
            // For Intra-MN Intra-DU with SN Change(Inter-SN)
            status = FnVCCB_NextStep_INTER_DU_SnAdd(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_SnAdd!\n");
            return GOOD;
        }

        if (FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType) == true)
        {
            status = FnVCCB_NextStep_INTER_DU_E1Stop(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_E1Stop!\n");
            return GOOD;
        }
        else
        {
            // For Intra-MN Inter-DU without SN Change(Intra-SN)
            if (FnVCCB_IsIntraSnMobilityInMn(ptCi))
            {
                status = FnVCCB_NextStep_INTER_DU_SnMod(ptCi); // Intra-MN Inter-DU without SN Change(Intra-SN)
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_SnMod!\n");
                return GOOD;
            }

            // For Intra-MN Intra-DU with SN Release
            if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
            {
                status = FnVCCB_NextStep_INTER_DU_SnRelA(ptCi);
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_SnRelA!\n");
                return GOOD;
            }
            
            VCCB_PRINT_CALL_ERROR(ptCi, "Unknown Handover Scenario!! (isInter: %d)\n", (int)FnVCCB_IsInterSnMobilityInMn(ptCi));
            return ERROR;
        }
    }

    status = FnVCCB_NextStep_INTER_DU_Prepare(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_Prepare_ERROR!\n");

    return GOOD;
}

int16_t VCCM_INTER_DU_DuQuery_F1_UEContextModificationResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    status = VFIL_storeF1_UeContextModificationResponse(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationResponse ERROR !!\n");

    OFF_F1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    status = FnVCCB_INTER_DU_DuQuery_rxProcess(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_INTER_DU_DuQuery_rxProcess ERROR !!\n");

    return GOOD;
}  // }}}

int16_t VCCM_INTER_DU_DuQuery_F1_UEContextModificationFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    status = VFIL_storeF1_UeContextModificationFailure(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationFailure ERROR !!\n");

    VCOM_SaHandoverCancel_ToConn(ptCi, ptUnpack->msgId);

    return GOOD;
}  // }}}

int16_t VCCM_INTER_DU_DuQuery_timF1_UeContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutF1UeContextModification);

    return GOOD;
}  // }}}

int16_t FnVCCB_INTER_DU_DuQuery_XN_SNodeModificationRequestAcknowledge(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status;

    status = FnVCCB_CommonMsgProc_XN_SNodeModificationRequest(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_CommonMsgProc_XN_SNodeModificationRequest(Ack) ERROR !! \n");
        MACRO_RESET_CALL_FAULT_CAUSES;
        // return ERROR; always return GOOD, call not release
    }

    status = FnVCCB_INTER_DU_DuQuery_rxProcess(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_INTER_DU_DuQuery_rxProcess ERROR !!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_INTER_DU_DuQuery_XN_SNodeModificationRequestReject(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status;

    status = FnVCCB_CommonMsgProc_XN_SNodeModificationRequest(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_CommonMsgProc_XN_SNodeModificationRequest(Reject) ERROR !! \n");
        MACRO_RESET_CALL_FAULT_CAUSES;
        // return ERROR; always return GOOD, call not release
    }

    status = FnVCCB_UpdateBearerTypeForHandover(ptCi, MrdcHoWithSnRelease);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_UpdateBearerTypeForHandover(Release) ERROR !! \n");

    // It needs to be called again because the Meas configuration needs to be changed according to the scenario change.
    // Scenario : Scenario Change From 'Intra-MN Inter-DU with SN Change' To 'Intra-MN Inter-DU with SN Release' by 'Snode Modification Reject(SCG Config Get Fail)'.
    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");

    status = FnVCCB_INTER_DU_DuQuery_rxProcess(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_INTER_DU_DuQuery_rxProcess ERROR !!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_INTER_DU_DuQuery_timXN_SNodeModificationRequest(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status;

    status = FnVCCB_CommonMsgProc_XN_SNodeModificationRequest(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeModificationRequest(Timeout) ERROR !! \n");

    status = FnVCCB_UpdateBearerTypeForHandover(ptCi, MrdcHoWithSnRelease);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_UpdateBearerTypeForHandover(Release) ERROR !! \n");

    // It needs to be called again because the Meas configuration needs to be changed according to the scenario change.
    // Scenario : Scenario Change From 'Intra-MN Inter-DU with SN Change' To 'Intra-MN Inter-DU with SN Release' by 'Snode Modification TMOUT(SCG Config Get Fail)'.
    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");

    status = FnVCCB_INTER_DU_DuQuery_rxProcess(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_INTER_DU_DuQuery_rxProcess ERROR !!\n");

    return GOOD;
}  // }}}

// STATE_INTER_DU_E1Stop
int16_t VCCM_INTER_DU_E1Stop_E1_BearerContextModificationSuccess(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    OFF_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    if (FnVCCB_IsInterSnMobilityInMn(ptCi))
    {
        // For Intra-MN Intra-DU with SN Change(Inter-SN)
        status = FnVCCB_NextStep_INTER_DU_Prepare(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_Prepare!\n");
        return GOOD;
    }

    // For Intra-MN Inter-DU without SN Change(Intra-SN)
    if (FnVCCB_IsIntraSnMobilityInMn(ptCi))
    {
        status = FnVCCB_NextStep_INTER_DU_SnMod(ptCi); // Intra-MN Inter-DU without SN Change(Intra-SN)
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_SnMod!\n");
        return GOOD;
    }

    // For Intra-MN Intra-DU with SN Release
    if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
    {
        status = FnVCCB_NextStep_INTER_DU_SnRelA(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_SnRelA!\n");
        return GOOD;
    }

    VCCB_PRINT_CALL_ERROR(ptCi, "Unknown Handover Scenario!! (isInter: %d)\n", (int)FnVCCB_IsInterSnMobilityInMn(ptCi));
    return ERROR;
}  // }}}

int16_t VCCM_INTER_DU_E1Stop_E1_BearerContextModificationUnsuccess(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    OFF_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->cause.e1Cause);

    return GOOD;
}  // }}}

int16_t VCCM_INTER_DU_E1Stop_timE1_BearerContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    return GOOD;
}  // }}}

// STATE_INTER_DU_SnAdd

// STATE_INTER_DU_SnRelA

// STATE_INTER_DU_SnRelB

// STATE_INTER_DU_Prepare
int16_t FnVCCB_NextStep_HandoverCancel_In_INTER_DU_Prepare(callInfo_type *ptCi, uint16_t msgId)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (IS_ON_BLIND_REDIRECTION_WO_HO_CANCEL(ptCi))
    {
        return FnVCCB_SpecificSliceForcedMobilityBlindRedirection(ptCi, msgId); //25B PMB FGR-MC1021:FR150
    }
    else if (IS_ON_NEED_CALL_RELEASE_WO_HO_CANCEL(ptCi))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Run Call Release in Inter-DU HO without HO Cancel Process\n");
        VCCB_CALL_RELEASE_TRIGGER(ptCi);
        return GOOD;
    }

    if (FnVCCB_IsExistSaHoTargetDU(ptCi))
    {
        // F1 Release
        if (VFIL_sendF1_UeContextReleaseCommand(ptCi, NULL, 0, ID_SRB0, DU_HO_TARGET) != GOOD)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_sendF1_UeContextReleaseCommand Error!!\n");
            return ERROR;
        }

        VLIB_AttachTimer(&ptCi->timer, ptCi, timF1_UeContextRelease_id);
        return GOOD;
    }
    else
    {
        if (IS_MRDC(ptCi) == true && FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType))
        {
            int16_t status = FnVCCB_NextStep_Common_DU_Cancel(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Common_DU_Cancel ERROR!\n");
            return GOOD;
        }

        VCOM_SaHandoverCancel_ToConn(ptCi, msgId);
        return BREAK;
    }

    return GOOD;
}

int16_t VCCM_INTER_DU_Prepare_F1_UEContextSetupResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    F1ResponsePreChecker f1PreChecker(*ptCi, ptAll, ptUnpack);
    bool isAllowedResponse = f1PreChecker.isAllowedResponse();

    if (not ptCi->hoInfo.sliceRejectionStats)
    {
        ptCi->hoInfo.sliceRejectionStats = f1PreChecker.getIsDrbFailedDueToSNotAvailableSlice(); // SVR25B FGR-MC1021:FR210 FR220
    }

    if (Not_Allowed == isAllowedResponse)
    {
        ptCi->hoInfo.notSupportedVonr = f1PreChecker.getIs5qi1DrbFailedWithCause(); //25A FGR-MC1008:FR580

        if (f1PreChecker.getIsFullConfigNotAllowed() && IS_MRDC(ptCi))
        {
            ptCi->hoInfo.cancelControl.needSnRelease = true; // Trigger Src SN release
        }

        VHCM_SA_HO_STAT(ptCi, HO_Fail_CpFail);
        VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_CpFail);

        if (IS_MRDC(ptCi) && ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
        {
            if (ptCi->hoInfo.isSpecificSliceForcedMobilityTargetUe == TRUE) // 25B PMB FGR-MC1021:FR150
            {
                SET_NEED_BLIND_REDIRECTION_WO_HO_CANCEL(ptCi);
            }
            else
            {
                SET_NEED_CALL_RELEASE_WO_HO_CANCEL(ptCi);
            }
            MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, f1PreChecker.getFinalFailedCause());
        }

        VHCM_UpdateHandoverPreparationFailureCellInfo(ptCi);  // by SA, Intra-GNB Inter-DU Preparation Fail
        return FnVCCB_NextStep_HandoverCancel_In_INTER_DU_Prepare(ptCi, ptUnpack->msgId);
    }

    status = VFIL_storeF1_UeContextSetupResponse(ptCi, ptAll, ptUnpack);
    switch (status)
    {
        case BREAK:
            VCCB_PRINT_CALL_ERROR(ptCi, "F1_UEContextSetupResponse :: Received by other DU and ignored.\n");
            ptCi->hoInfo.notSupportedVonr = false;
            return BREAK;
        case ERROR:
            VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_storeF1_UeContextSetupResponse ERROR !!\n");
            VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
            VHCM_SA_HO_STAT(ptCi, HO_Fail_F1Fail);
            return ERROR;
        case RESPONSE_WITH_PARTIAL_SUCCESS:
            VCCB_PRINT_CALL_HO_SERVICE_TYPE(
                ptCi, "INTER-DU HO RESPONSE_WITH_PARTIAL_SUCCESS from F1_UEContextSetupResponse \n");
            VHCM_SA_HO_IN_PARTIAL_FAIL_SERVICE_TYPE_STAT(ptCi, HO_PrepFail_F1Fail);
            break;
        default:
            break;
    }

    // send ue context release command to all ltm candidate cell
    FnVCCB_SendF1ReleaseToLtmTargetCellAndSetLtmRelFlag(*ptCi);

    // If MN Term UP exists, DL Tx Stop and DL TNL will be sent
    // else skip E1 Procedure and DL TNL will be trasnferred when DL Tx Resume is sent
    if (FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType) == true)
    {
        // Suspend
        status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

        VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);
    }
    else
    {
        status = FnVCCB_INTER_DU_Prepare_rxProcess(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_INTER_DU_Prepare_rxProcess ERROR!\n");
    }

    return GOOD;
}  // }}}

int16_t VCCM_INTER_DU_Prepare_F1_UEContextSetupFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    FnVCCB_Check_F1FailureCuaseForStat(ptCi, ptUnpack);
    
    status = VFIL_storeF1_UeContextSetupFailure(ptCi, ptAll, ptUnpack);
    switch (status)
    {
        case BREAK:
            VCCB_PRINT_CALL_ERROR(ptCi, "F1_UEContextSetupFailure :: Received by other DU and ignored.\n");
            ptCi->hoInfo.notSupportedVonr = false;
            return BREAK;
        case ERROR:
            VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_storeF1_UeContextSetupFailure ERROR !!\n");
            VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
            VHCM_SA_HO_STAT(ptCi, HO_Fail_F1Fail);  // IntraGnbIn/Out_PrepFail_F1Fail
            return ERROR;
        default:
            break;
    }

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_F1Fail);  // IntraGnbIn/Out_PrepFail_F1Fail

    VHCM_UpdateHandoverPreparationFailureCellInfo(ptCi);  // by SA, Intra-GNB Inter-DU Preparation Fail

    return FnVCCB_NextStep_HandoverCancel_In_INTER_DU_Prepare(ptCi, ptUnpack->msgId);
}  // }}}

int16_t VCCM_INTER_DU_Prepare_timF1_UeContextSetup(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status = GOOD;

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_F1TimeOut);

    OFF_F1_RESOURCE_TGT_FLAG(ptCi->flag.setupFlag);
    OFF_F1_RESOURCE_TGT_FLAG(ptCi->flag.respFlag);

    if (IS_MRDC(ptCi) == true)
    {
        status = FnVCCB_NextStep_Common_DU_Cancel(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Common_DU_Cancel ERROR!\n");
        return GOOD;
    }

    VCOM_SaHandoverCancel_ToConn(ptCi, ptUnpack->msgId);

    return BREAK;
}  // }}}

int16_t VCCM_INTER_DU_Prepare_F1_UEContextReleaseComplete(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status = GOOD;

    status = FnVCCB_CommonMsgProc_F1_UEContextRelease(ptCi, ptAll, ptUnpack, &ptCi->timer, DU_HO_TARGET);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_CommonMsgProc_F1_UEContextRelease(Complete) ERROR !!\n");
    }

    // If MRDC, E1 Dl tx stop was sent in INTER_DU_E1Stop state
    status = FnVCCB_NextStep_HandoverCancel_In_INTER_DU_Prepare(ptCi, ptUnpack->msgId);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_NextStep_HandoverCancel_In_INTER_DU_Prepare ERROR !!\n");
        return ERROR;
    }

    return GOOD;
}  // }}}

int16_t VCCM_INTER_DU_Prepare_timF1_UeContextRelease(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status = GOOD;

    status = FnVCCB_CommonMsgProc_F1_UEContextRelease(ptCi, ptAll, ptUnpack, &ptCi->timer, DU_HO_TARGET);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_CommonMsgProc_F1_UEContextRelease(TMOUT) ERROR !!\n");
    }

    // If MRDC, E1 Dl tx stop was sent in INTER_DU_E1Stop state
    if (IS_MRDC(ptCi) && FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType) == true)
    {
        status = FnVCCB_NextStep_Common_DU_Cancel(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Common_DU_Cancel ERROR!\n");
        return GOOD;
    }

    VCOM_SaHandoverCancel_ToConn(ptCi, ptUnpack->msgId);

    return GOOD;
}  // }}}

int16_t VCCM_INTER_DU_Prepare_E1_BearerContextModificationSuccess(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    OFF_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    status = FnVCCB_INTER_DU_Prepare_rxProcess(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_INTER_DU_Prepare_rxProcess ERROR!\n");

    return GOOD;
}  // }}}

int16_t VCCM_INTER_DU_Prepare_E1_BearerContextModificationUnsuccess(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    FnVCCB_CollectingSaHandoverStatistics_E1Fail(ptCi);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->cause.e1Cause);

    return GOOD;
}  // }}}

int16_t VCCM_INTER_DU_Prepare_timE1_BearerContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptAll);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_UpFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_E1TimeOut);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    return GOOD;
}  // }}}

// STATE_INTER_DU_Exe_T
int16_t VCCM_INTER_DU_Exe_T_F1_UEContextModificationResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptAll);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    status = VFIL_storeF1_UeContextModificationResponse(ptCi, ptAll, ptUnpack);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_storeF1_UeContextModificationResponse ERROR !!\n");
        return ERROR;
    }

    OFF_F1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    // Change State STATE_INTER_DU_Execution, and Execution Processing.
    status = FnVCCB_NextStep_INTER_DU_Execution(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_Execution ERROR!\n");

    return GOOD;
}  // }}}

int16_t VCCM_INTER_DU_Exe_T_F1_UEContextModificationFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptAll);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_F1Fail);  // IntraGnbIn/Out_Fail_F1Fail

    status = VFIL_storeF1_UeContextModificationFailure(ptCi, ptAll, ptUnpack);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_storeF1_UeContextModificationFailure ERROR !!\n");
        return ERROR;
    }

    return GOOD;
}  // }}}

int16_t VCCM_INTER_DU_Exe_T_timF1_UeContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptAll);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_F1TimeOut);  // IntraGnbIn/Out_Fail_F1TimeOut

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutF1UeContextModification);

    return GOOD;
}  // }}}

// STATE_INTER_DU_Execution

// STATE_INTER_DU_Complete
int16_t VCCM_INTER_DU_Complete_F1_UEContextReleaseComplete(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_CommonMsgProc_F1_UEContextRelease(ptCi, ptAll, ptUnpack, &ptCi->timer, DU_HO_SOURCE);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_CommonMsgProc_F1_UEContextRelease(Complete) ERROR !!\n");
    }

    return GOOD;
}  // }}}

int16_t VCCM_INTER_DU_Complete_timF1_UeContextRelease(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_CommonMsgProc_F1_UEContextRelease(ptCi, ptAll, ptUnpack, &ptCi->timer, DU_HO_SOURCE);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_CommonMsgProc_F1_UEContextRelease(TMOUT) ERROR !!\n");
    }

    return GOOD;
}  // }}}

// }}}

/****************************************************************************
                    Intra gNB, Intra DU
****************************************************************************/
// {{{
//
/****************************************************************
 *  Function             : FnVCCB_NextStep_INTRA_DU_SnQuery
 *  Description          : go to next state STATE_INTER_Pre_SN_T
 *  Input                : callInfo_type*
 *  Output               : int16_t (GOOD/ERROR)
 ***************************************************************/
int16_t FnVCCB_NextStep_INTRA_DU_SnQuery(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTRA_DU_SnQuery);

    /* set scgConfigQuery to 'VCCB_FLAG_ON' and init buffer before send SN modification request */
    VLIB_Set_MrdcScgConfigQuery(ptCi, VCCB_FLAG_ON);

    /* send SN modification request */
    status = FnVCCB_SendXNMessage(XN_SNodeModificationRequest_id, ptCi, nullptr, nullptr);
    VLIB_Set_MrdcScgConfigQuery(ptCi, VCCB_FLAG_OFF);

    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_SNodeModificationRequest_id) Error!!\n");

    VLIB_AttachTimer(&ptCi->hoInfo.timer.xn, ptCi, timXN_SNodeModification_id);

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_INTRA_DU_RunE1Stop_Or_RunAfterE1Stop(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // If MN Control is required, the MN TX Stop procedure is performed.
    if (FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType) == true)
    {
        status = FnVCCB_NextStep_INTRA_DU_E1Stop(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_E1Stop ERROR!\n");

        return GOOD;
    }

    // If MN Control is not required, ignore this procedure and perform the next procedure.
    status = FnVCCB_NextStep_After_E1Stop(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_After_E1Stop ERROR!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_After_E1Stop(callInfo_type *ptCi)
{  // {{{

    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCM_InitSaMeasData(ptCi);

    FnVCCB_UpdateMrsInfo(ptCi, MRS_INFO_TO_PREV_MRS_INFO);
    FnVCCB_InitMrsInfo(ptCi, MRS_SAME_PREV_PRARM_INIT);
    if (VCCB_IS_INTER_FREQ_SSB_FREQ(ptCi->servCellNum, ptCi->hoInfo.tgtSsbFreq))
    {
        FnVCCB_SetMultiRatSelectionInitState(ptCi);
    }

    FnVCCB_InitSccData(ptCi, SCC_HO_PREP_INIT);
    FnVCCB_InitOnDemandMeasConfig(ptCi); 

    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig! ERROR!\n");

    if (IS_MRDC(ptCi) == true)
    {
        // For Intra-MN Intra-DU without SN Change(Intra-SN)
        if (FnVCCB_IsIntraSnMobilityInMn(ptCi))
        {
            status = FnVCCB_NextStep_INTRA_DU_SnMod(ptCi); // Intra-MN Intra-DU without SN Change(Intra-SN)
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_SnMod!\n");
            return GOOD;
        }

        // For Intra-MN Intra-DU with SN Release
        if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
        {
            status = FnVCCB_NextStep_INTRA_DU_SnRelA(ptCi);  // Intra-MN Intra-DU with SN Release
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_SnRelA!\n");
            return GOOD;
        }
    }

    // For Intra-MN Intra-DU with SN Change(Inter-SN)
    // For SA Mobility
    status = FnVCCB_NextStep_INTRA_DU_Prepare(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_Prepare!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_INTRA_DU_E1Stop(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTRA_DU_E1Stop);

    // SUSPEND
    status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");
        return ERROR;
    }

    VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_INTRA_DU_SnAdd(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTRA_DU_SnAdd);

    {
        fullConfiguration_type backupDB;
        ForcedCuInitFullConfigForXnSnAddReqMake mnInitFullConfig(ptCi, &backupDB);
        mnInitFullConfig.procXnSnAddReq();

        uint8_t targetXN = e_Snode_MnToTgtSn;
        status = FnVCCB_SendXNMessage(XN_SNodeAdditionRequest_id, ptCi, &targetXN, nullptr);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "nVCCB_SendXNMessage(XN_SNodeAdditionRequest_id) ERROR!\n");

        VLIB_AttachTimer(&ptCi->hoInfo.timer.xn, ptCi, timXN_SNodeAddition_id);

        VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Att);
    }

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_INTRA_DU_SnMod(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTRA_DU_SnMod);

    {
        // measResult for PSCell Change
        status = FnVCCB_SendXNMessage(XN_SNodeModificationRequest_id, ptCi, nullptr, nullptr);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_send_XN_SNodeModificationRequest_ERROR!\n");

        VLIB_AttachTimer(&ptCi->hoInfo.timer.xn, ptCi, timXN_SNodeModification_id);

        // Possibility of change according to PSCELL change request
        ptCi->hoInfo.cancelControl.needSnRelease = true;
    }

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_INTRA_DU_SnRelA(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTRA_DU_SnRelA);

    status = FnVCCB_NextStep_Common_DU_SnRelA(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Common_DU_SnRelA!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_INTRA_DU_SnRelB(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTRA_DU_SnRelB);

    status = FnVCCB_NextStep_Common_DU_SnRelB(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Common_DU_SnRelB!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_INTRA_DU_Prepare(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VCCB_clearAllFailedCarrier(&ptCi->caInfo.failures);
    VLIB_ConfigSecondaryCellList(ptCi);
    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig! ERROR!\n");

    if (ptCi->hoInfo.targetCellBand != ptCi->servCellBand)
    {
        FnVCCB_Decide_UlGapFR2PreferenceConfig(*ptCi);
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTRA_DU_Prepare);

    // new SpCellId, DRB modified List
    status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
    OFF_BITFLAG_NEED_XNUADDRIND_FOR_DLUPTNL(ptCi); // Temp Code, Manages this FLAG directly during the handover procedure.
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextModificationRequest ERROR!\n");

    VLIB_AttachTimer(&ptCi->timer, ptCi, timF1_UeContextModification_id);

    VHCM_SA_HO_STAT(ptCi, HO_Att);

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_INTRA_DU_Execution(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    if (VCCB_IS_INTER_FREQ_SSB_FREQ(ptCi->servCellNum, ptCi->hoInfo.tgtSsbFreq))
    {
        FnVCCB_InitMrsInfo(ptCi, MRS_DIFF_PREV_PRARM_INIT);
    }
    else
    {
        FnVCCB_InitMrsInfo(ptCi, MRS_ALL_INIT);
    }

    FnVCCB_InitSccData(ptCi, SCC_HO_EXEC_INIT); 
    VLIB_SetCurStateAll(ptCi, STATE_INTRA_DU_Execution);

    status = VCOM_SaIntraDuHandover_ToExecution(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCOM_SaIntraDuHandover_ToExecution ERROR!\n");

    status = FnVCCB_NextStep_Common_DU_Execution(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Common_DU_Execution!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_INTRA_DU_Complete(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_INTRA_DU_Complete);

    status = FnVCCB_NextStep_Common_Complete(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Common_Complete!\n");

    return GOOD;
}  // }}}

int16_t VCCM_INTRA_DU_SnQuery_XN_SNodeModificationRequestAcknowledge(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status;

    status = FnVCCB_CommonMsgProc_XN_SNodeModificationRequest(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_CommonMsgProc_XN_SNodeModificationRequest(Ack) ERROR !! \n");
        MACRO_RESET_CALL_FAULT_CAUSES;
        // return ERROR; always return GOOD, call not release

        status = FnVCCB_UpdateBearerTypeForHandover(ptCi, MrdcHoWithSnRelease);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_UpdateBearerTypeForHandover(Release) ERROR !! \n");

        // It needs to be called again because the Meas configuration needs to be changed according to the scenario change.
        // Scenario : Scenario Change From 'Intra-MN Intra-DU with SN Change' To 'Intra-MN Intra-DU with SN Release' by 'Snode Modification Ack(but SCG Config Get Fail)'.
        status = VCCB_PrepareNewMeasConfig(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");
    }

    // For Intra-MN Intra-DU with SN Release
    if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
    {
        status = FnVCCB_NextStep_INTRA_DU_RunE1Stop_Or_RunAfterE1Stop(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_RunE1Stop_Or_RunAfterE1Stop ERROR!\n");

        return GOOD;
    }

    // For Intra-MN Intra-DU with SN Change(Inter-SN)
    status = FnVCCB_NextStep_INTRA_DU_SnAdd(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_SnAdd ERROR!\n");

    return GOOD;
}  // }}}

int16_t VCCM_INTRA_DU_SnQuery_XN_SNodeModificationRequestReject(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status;

    status = FnVCCB_CommonMsgProc_XN_SNodeModificationRequest(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_CommonMsgProc_XN_SNodeModificationRequest(Reject) ERROR !! \n");
        MACRO_RESET_CALL_FAULT_CAUSES;
        // return ERROR; always return GOOD, call not release
    }

    status = FnVCCB_UpdateBearerTypeForHandover(ptCi, MrdcHoWithSnRelease);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_UpdateBearerTypeForHandover(Release) ERROR !! \n");

    // It needs to be called again because the Meas configuration needs to be changed according to the scenario change.
    // Scenario : Scenario Change From 'Intra-MN Intra-DU with SN Change' To 'Intra-MN Intra-DU with SN Release' by 'Snode Modification Reject(SCG Config Get Fail)'.
    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");

    status = FnVCCB_NextStep_INTRA_DU_RunE1Stop_Or_RunAfterE1Stop(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_RunE1Stop_Or_RunAfterE1Stop ERROR!\n");

    return GOOD;
}  // }}}

int16_t VCCM_INTRA_DU_SnQuery_timXN_SNodeModificationRequest(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status;

    status = FnVCCB_CommonMsgProc_XN_SNodeModificationRequest(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeModificationRequest(Timeout) ERROR !! \n");

    status = FnVCCB_UpdateBearerTypeForHandover(ptCi, MrdcHoWithSnRelease);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_UpdateBearerTypeForHandover(Release) ERROR !! \n");

    // It needs to be called again because the Meas configuration needs to be changed according to the scenario change.
    // Scenario : Scenario Change From 'Intra-MN Intra-DU with SN Change' To 'Intra-MN Intra-DU with SN Release' by 'Snode Modification TMOUT(SCG Config Get Fail)'.
    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");

    status = FnVCCB_NextStep_INTRA_DU_RunE1Stop_Or_RunAfterE1Stop(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_RunE1Stop_Or_RunAfterE1Stop ERROR!\n");

    return GOOD;
}  // }}}

// STATE_INTRA_DU_E1Stop
int16_t VCCM_INTRA_DU_E1Stop_E1_BearerContextModificationSuccess(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    OFF_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    status = FnVCCB_NextStep_After_E1Stop(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_After_E1Stop!\n");

    return GOOD;
}  // }}}

int16_t VCCM_INTRA_DU_E1Stop_E1_BearerContextModificationUnsuccess(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    OFF_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->cause.e1Cause);

    FnVCCB_CollectingSaHandoverStatistics_E1Fail(ptCi);

    return GOOD;
}  // }}}

int16_t VCCM_INTRA_DU_E1Stop_timE1_BearerContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_UpFail);

    return GOOD;
}  // }}}

// STATE_INTRA_DU_SnAdd

// STATE_INTRA_DU_SnRelA

// STATE_INTRA_DU_SnRelB

// STATE_INTRA_DU_Prepare
int16_t FnVCCB_NextStep_HandoverCancel_In_INTRA_DU_Prepare(callInfo_type *ptCi, uint16_t msgId)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (IS_ON_BLIND_REDIRECTION_WO_HO_CANCEL(ptCi))
    {
        return FnVCCB_SpecificSliceForcedMobilityBlindRedirection(ptCi, msgId); //25B PMB FGR-MC1021:FR150
    }
    else if (IS_ON_NEED_CALL_RELEASE_WO_HO_CANCEL(ptCi))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Run Call Release in Intra-DU HO without HO Cancel Process\n");
        VCCB_CALL_RELEASE_TRIGGER(ptCi);
        return GOOD;
    }

    if (FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType) == true)
    {
        int16_t status = FnVCCB_NextStep_Common_DU_Cancel(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Common_DU_Cancel ERROR !!\n");
    }
    else
    {
        VCOM_SaHandoverCancel_ToConn(ptCi, msgId);
    }

    return GOOD;
}

int16_t VCCM_INTRA_DU_Prepare_F1_UEContextModificationResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    F1ResponsePreChecker f1PreChecker(*ptCi, ptAll, ptUnpack);
    bool isAllowedResponse = f1PreChecker.isAllowedResponse();

    if (not ptCi->hoInfo.sliceRejectionStats)
    {
        ptCi->hoInfo.sliceRejectionStats = f1PreChecker.getIsDrbFailedDueToSNotAvailableSlice(); // SVR25B FGR-MC1021:FR210 FR220
    }
    
    if (Not_Allowed == isAllowedResponse)
    {
        ptCi->hoInfo.notSupportedVonr = f1PreChecker.getIs5qi1DrbFailedWithCause(); //25A FGR-MC1008:FR580

        VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_CpFail);
        VHCM_SA_HO_STAT(ptCi, HO_Fail_CpFail);

        if (ptCi->hoInfo.isSpecificSliceForcedMobilityTargetUe == TRUE) // 25B PMB FGR-MC1021:FR150
        {
            SET_NEED_BLIND_REDIRECTION_WO_HO_CANCEL(ptCi);
        }
        else
        {
            SET_NEED_CALL_RELEASE_WO_HO_CANCEL(ptCi);
        }

        if (f1PreChecker.getIsFullConfigNotAllowed())
        {
            // no action: MACRO_CALL_FAULT_SAVE is only called if partial is not allowed.
        }
        else if (f1PreChecker.getIs5qi1DrbFailed() || f1PreChecker.getIsPartialSuccessNotAllowed())
        {
            MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, f1PreChecker.getFinalFailedCause());
        }

        return FnVCCB_NextStep_HandoverCancel_In_INTRA_DU_Prepare(ptCi, ptUnpack->msgId);
    }

    // new CRNTI, new DL GTP TEID, CellGroupConfig for HO Command
    status = VFIL_storeF1_UeContextModificationResponse(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationResponse ERROR !!\n");

    if (status == RESPONSE_WITH_PARTIAL_SUCCESS)
    {
        VCCB_PRINT_CALL_HO_SERVICE_TYPE(
            ptCi, "INTRA-DU HO PARTIAL CHECK from VCCM_INTRA_DU_Prepare_F1_UEContextModificationResponse \n");
        VHCM_SA_HO_IN_PARTIAL_FAIL_SERVICE_TYPE_STAT(ptCi, HO_PrepFail_F1Fail);
    }
    FnVCCB_SetHandoverExecution(ptCi);

    VHCM_SA_HO_STAT(ptCi, HO_PrepSucc);

    // send ue context release command to all ltm candidate cell
    FnVCCB_SendF1ReleaseToLtmTargetCellAndSetLtmRelFlag(*ptCi);

    /* MN DL UP TNL: TODO, reqBearer type is split */
    if (FnVCCB_IsAnySnTermSplitPerUE(ptCi, request_bearerType))
    {
        ON_BITFLAG_NEED_XNUADDRIND_FOR_DLUPTNL(ptCi);

        // TODO: temp code for Inter SN Change...
        uint8_t targetXN = 0;
        if (FnVCCB_IsInterSnMobilityInMn(ptCi))
        {
            targetXN = e_Snode_MnToTgtSn;
        }

        status = FnVCCB_SendXNMessage(XN_XnUAddressIndication_id, ptCi, &targetXN, nullptr);
        OFF_BITFLAG_NEED_XNUADDRIND_FOR_DLUPTNL(ptCi);

        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage (XN_XnUAddressIndication) ERROR!\n");

        status = FnVCCB_NextStep_INTRA_DU_Execution(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_Execution ERROR!\n");

        return status;
    }
    else
    {
        status = FnVCCB_NextStep_INTRA_DU_Execution(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_Execution ERROR!!\n");
    }

    return GOOD;
}  // }}}

int16_t VCCM_INTRA_DU_Prepare_F1_UEContextModificationFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    FnVCCB_Check_F1FailureCuaseForStat(ptCi, ptUnpack);

    status = VFIL_storeF1_UeContextModificationFailure(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationFailure ERROR!\n");

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_F1Fail);

    VHCM_UpdateHandoverPreparationFailureCellInfo(ptCi);  // by SA, Intra-GNB Intra-DU Preparation Fail

    return FnVCCB_NextStep_HandoverCancel_In_INTRA_DU_Prepare(ptCi, ptUnpack->msgId);
}  // }}}

int16_t VCCM_INTRA_DU_Prepare_timF1_UeContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_F1TimeOut);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutF1UeContextModification);

    return GOOD;
}  // }}}

// STATE_INTER_DU_Execution

// INTRA_DU_Complete

// }}}
//
/****************************************************************************
  MN - SN Initiated SN Modification by PSCell Change
****************************************************************************/
// {{{

int16_t FnVCCB_NextStep_MN_SNMob_TxStop(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_MN_SNMob_TxStop);

    status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

    VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_MN_SNMob_F1Mod(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int16_t status = GOOD;

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_MN_SNMob_F1Mod);

    VCCB_clearAllFailedCarrier(&ptCi->caInfo.failures);
    VLIB_ConfigSecondaryCellList(ptCi);

    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");

    status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextModificationRequest ERROR!\n");

    VLIB_AttachTimer(&ptCi->hoInfo.timer.f1, ptCi, timF1_UeContextModification_id);

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_MN_SNMob_ReconfRrc(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int16_t status = GOOD;

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_MN_SNMob_ReconfRrc);

    /* SNRRCReconfiguration_ForMN to SourceDU */
    status = FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer(ptCi, FALSE, FALSE, ID_SRB1);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer ERROR !!\n");

    VLIB_AttachTimer(&ptCi->timer, ptCi, timNRRRC_RRCReconfig_id);

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_MN_SNMob_TxResume(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_MN_SNMob_TxResume);

    status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

    VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);

    return GOOD;
}  // }}}

// STATE_MN_SNMob_TxStop
// {{{
int16_t FnVCCB_MN_SNMob_TxStop_E1_BearerContextModificationSuccess(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    OFF_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    return GOOD;
}  // }}}

int16_t FnVCCB_MN_SNMob_TxStop_E1_BearerContextModificationUnsuccess(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->cause.e1Cause);

    return GOOD;
}  // }}}

int16_t FnVCCB_MN_SNMob_TxStop_timE1_BearerContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    return GOOD;
}  // }}}
// }}}

// STATE_MN_INTER_SN_Exe
// {{{
int16_t FnVCCB_MN_SNMob_F1Mod_F1_UEContextModificationResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_CommonMsgProc_F1_UEContextModification(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.f1);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_F1_UEContextModification(Response) ERROR !!\n");

    status = FnVCCB_NextStep_MN_SNMob_ReconfRrc(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_MN_SNMob_ReconfRrc ERROR !!\n");

    return GOOD;
}  // }}}
// }}}

// STATE_MN_SNMob_ReconfRrc
// {{{
int16_t FnVCCB_MN_SNMob_ReconfRrc_rxProcess(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    if (VLIB_CheckAllConnected(ptCi) == ERROR)
    {
        return GOOD;
    }

    /* check the MN split or [TBD] SCG bearer */
    if (FnVCCB_IsAnyMnTermScgLegPerUE(ptCi, current_bearerType) == true)
    {
        status = FnVCCB_NextStep_MN_SNMob_TxResume(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_MN_SNMob_TxResume ERROR !!\n");
    }
    else
    {
        FnVCCB_MrdcSnMobility_Finalize(ptCi);
    }

    return GOOD;
}

int16_t FnVCCB_MN_SNMob_ReconfRrc_NRRRC_RrcReconfigurationComplete(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status = GOOD;

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    if (VRIL_storeNRRRC_RrcReconfigurationComplete(ptCi, ptUnpack) == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VRIL_storeNRRRC_RrcReconfigurationComplete ERROR!\n");
        return ERROR;
    }

    OFF_RRC_CONNECTION_FLAG(ptCi->flag.respFlag);

    if (ptCi->cellGroupConfig.numocts > 0)
    {
        // RRC Recongifuration Complete Indicator
        status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextModificationRequest ERROR!\n");

        // start the timer
        VLIB_AttachTimer(&ptCi->hoInfo.timer.f1, ptCi, timF1_UeContextModification_id);
    }

    // SEnd XN Confirm and E1..
    status = FnVCCB_SendXNMessage(XN_SNodeModificationConfirm_id, ptCi, nullptr, nullptr);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_SNodeModificationConfirm_id) Error!!\n");

    status = FnVCCB_MN_SNMob_ReconfRrc_rxProcess(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_MN_SNMob_ReconfRrc_rxProcess Error!!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_MN_SNMob_ReconfRrc_timNRRRC_RRCReconfig(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCM_State_Common_timNRRRC_RRCReconfig(ptCi, ptAll, ptUnpack);

    return GOOD;
}  // }}}

int16_t FnVCCB_MN_SNMob_ReconfRrc_F1_UEContextModificationResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_CommonMsgProc_F1_UEContextModification(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.f1);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_F1_UEContextModification(Response) ERROR !!\n");

    status = FnVCCB_MN_SNMob_ReconfRrc_rxProcess(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_MN_SNMob_ReconfRrc_rxProcess Error!!\n");

    return GOOD;
}  // }}}
// }}}
//
// STATE_MN_SNMob_TxResume
// {{{
int16_t FnVCCB_MN_SNMob_TxResume_E1_BearerContextModificationSuccess(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    OFF_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    FnVCCB_MrdcSnMobility_Finalize(ptCi);

    return GOOD;
}  // }}}

int16_t FnVCCB_MN_SNMob_TxResume_E1_BearerContextModificationUnsuccess(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->cause.e1Cause);

    return GOOD;
}  // }}}

int16_t FnVCCB_MN_SNMob_TxResume_timE1_BearerContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    return GOOD;
}  // }}}
// }}}

// }}}

/****************************************************************************
  MN - SN Initiated SN Modification by PSCell Change
****************************************************************************/
// {{{
int16_t FnVCCB_NextStep_MN_INTER_SN_Pre_SN(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_MN_INTER_SN_Pre_SN);

    // send the SNode Addition Request..
    {
        fullConfiguration_type backupDB;
        ForcedCuInitFullConfigForXnSnAddReqMake mnInitFullConfig(ptCi, &backupDB);
        mnInitFullConfig.procXnSnAddReq();

        uint8_t targetXN = e_Snode_MnToTgtSn;
        status = FnVCCB_SendXNMessage(XN_SNodeAdditionRequest_id, ptCi, &targetXN, nullptr);
        if (ERROR == status) return ERROR;
    }

    VLIB_AttachTimer(&ptCi->hoInfo.timer.xn, ptCi, timXN_SNodeAddition_id);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Att);

    ON_SN_NODE_ADD_ACK_RCV_FLAG(ptCi->flag.respFlag);

    return GOOD;
}

int16_t FnVCCB_NextStep_MN_INTER_SN_E1Stop(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_MN_INTER_SN_E1Stop);

    status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

    VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextModification_id);

    return GOOD;
}

int16_t FnVCCB_NextStop_MN_INTER_SN_Exe(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_MN_INTER_SN_Exe);

    VLIB_ConfigSecondaryCellList(ptCi);

    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");

    // Send the XN Change Confirm to Source SN
    status = FnVCCB_SendXNMessage(XN_SNodeChangeConfirm_id, ptCi, nullptr, nullptr);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_SNodeChangeConfirm_id) Error!!\n");

    // If Confirm is sent, it is judged that recovery is impossible.
    ptCi->hoInfo.cancelControl.needSnRelease = true;

#if 1
    // TODO
    status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
    OFF_BITFLAG_NEED_XNUADDRIND_FOR_DLUPTNL(ptCi); // Temp Code, Manages this FLAG directly during the handover procedure.
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextModificationRequest ERROR!\n");

    VLIB_AttachTimer(&ptCi->hoInfo.timer.f1, ptCi, timF1_UeContextModification_id);
#else
    /* SNRRCReconfiguration_ForMN to SourceDU */
    status = FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer(ptCi, FALSE, FALSE, ID_SRB1);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer ERROR !!\n");

    VLIB_AttachTimer(&ptCi->timer, ptCi, timNRRRC_RRCReconfig_id);
#endif

    if (FnVCCB_NeedWaitForSNStatus(ptCi) == true)
    {
#ifdef IPC_TEST
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[Forwarding]: Wait SnStatus From SNode.\n");
#endif
        ON_SN_STATUS_FLAG(ptCi->flag.respFlag);
        VLIB_AttachTimer(&ptCi->hoInfo.timer.xn, ptCi, timXN_SnStatusTransfer_id);
    }

    return GOOD;
}

int16_t FnVCCB_NextStep_MN_INTER_SN_Complete(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VLIB_SetCurStateAll(ptCi, STATE_MN_INTER_SN_Complete);

    // Reconfiguration Compilete Indication For MN.
    status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextModificationRequest ERROR!\n");

    // Reconfiguration Compilete Indication For SN.
    if (FnVCCB_NeedToSendXnSNodeReconfigurationComplete(ptCi) == true)
    {
        uint8_t targetXN = e_Snode_MnToTgtSn;
        status = FnVCCB_SendXNMessage(XN_SNodeReconfigurationComplete_id, ptCi, &targetXN, nullptr);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_SNodeReconfigurationComplete_id) Error!!\n");
    }

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Succ);

    VLIB_AttachTimer(&ptCi->hoInfo.timer.f1, ptCi, timF1_UeContextModification_id);

    // It operates only when MN Term UP exists. (If UP exists, MN E1 Resume control takes precedence.)
    if (true == FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType))
    {
        // Resume
        status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest(Modification) ERROR !!\n");

        VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextModification_id);
    }
    else if (true == FnVCCB_IsAnySnTermPerUE(ptCi, request_bearerType))  // when SN term bearer is used
    {
        auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_PDUSessionResourceModifyIndication_id);
        VALID_E_POINT_CHECK_ERROR(ngapSender);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, ngapSender->sendMsg(), "sendMsg(NG_PDUSessionResourceModifyIndication) ERROR!\n");

        ON_PDUSESS_MODIFY_CONFIRM_FLAG(ptCi->flag.respFlag);

        VLIB_AttachTimer(&ptCi->timer, ptCi, timNG_PDUSessModifyConfirm_id);
    }

    return GOOD;
}

// STATE_MN_INTER_SN_Pre_SN
// {{{
int16_t FnVCCB_MN_INTER_SN_Pre_SN_XN_SNodeAdditionRequestAcknowledge(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    // Sn Init SN Change
    uint16_t notAllowedCause = 0;
    if (FnVCCB_IsAllowedSnodeAdditionRequestAcknowledge(ptCi, ptAll, ptUnpack, &notAllowedCause) == Not_Allowed)
    {
        status = FnVCCB_ProcNotAllowedSnodeAdditionRequestAcknowledge(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_ProcNotAllowedSnodeAdditionRequestAcknowledge ERROR !! \n");

        if (notAllowedCause & NRDC_SN_ADDMOD_NOT_ALLOWED_CAUSE__FULL_CONFIGURATION)
            ptCi->hoInfo.cancelControl.needSnRelease = true; // 24B FGR-CC5201:FR491 HD6 release source SN

        VCOM_SaHandoverCancel_ToConn(ptCi, ptUnpack->msgId);

        return GOOD;
    }

    status = FnVCCB_CommonMsgProc_XN_SNodeAddition(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeAddition(Response) ERROR !!\n");

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_PrepSucc);

    // E1 DL TX Stop
    if (FnVCCB_IsAnyMnTermScgLegPerUE(ptCi, current_bearerType) == true)
    {
        status = FnVCCB_NextStep_MN_INTER_SN_E1Stop(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_MN_INTER_SN_E1Stop ERROR!\n");
    }
    else
    {
        status = FnVCCB_NextStop_MN_INTER_SN_Exe(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStop_MN_INTER_SN_Exe ERROR!\n");
    }

    return GOOD;
}  // }}}

int16_t FnVCCB_MN_INTER_SN_Pre_SN_XN_SNodeAdditionRequestReject(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_XnFail);

    status = FnVCCB_CommonMsgProc_XN_SNodeAddition(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeAddition(Failure) ERROR !!\n");

    VCOM_SaHandoverCancel_ToConn(ptCi, ptUnpack->msgId);

    return GOOD;
}  // }}}

int16_t FnVCCB_MN_INTER_SN_Pre_SN_timXN_SNodeAddition(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_XnFail);

    status = FnVCCB_CommonMsgProc_XN_SNodeAddition(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeAddition(TMOUT) ERROR !!\n");

    return GOOD;
}  // }}}
// }}}

// STATE_MN_INTER_SN_E1Stop

int16_t FnVCCB_MN_INTER_SN_E1Stop_E1_BearerContextModificationFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_CommonMsgProc_E1_BearerContextModification(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.e1);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_E1_BearerContextModification(Failure) ERROR !!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_MN_INTER_SN_E1Stop_timE1_BearerContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_UpFail);

    status = FnVCCB_CommonMsgProc_E1_BearerContextModification(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.e1);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_E1_BearerContextModification(TMOUT) ERROR !!\n");

    return GOOD;
}  // }}}
// }}}

// STATE_MN_INTER_SN_Exe
// {{{
int16_t FnVCCB_MN_INTER_SN_Exe_F1_UEContextModificationResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_CommonMsgProc_F1_UEContextModification(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.f1);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_F1_UEContextModification(Response) ERROR !!\n");

    if (FnVCCB_IsAnySnTermSplitPerUE(ptCi, request_bearerType) == true)
    {
        ON_BITFLAG_NEED_XNUADDRIND_FOR_DLUPTNL(ptCi);
        uint8_t targetXN = e_Snode_MnToTgtSn;
        status = FnVCCB_SendXNMessage(XN_XnUAddressIndication_id, ptCi, &targetXN, nullptr);
        OFF_BITFLAG_NEED_XNUADDRIND_FOR_DLUPTNL(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage (XN_XnUAddressIndication) ERROR!\n");
    }

    /* SNRRCReconfiguration_ForMN to SourceDU */
    status = FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer(ptCi, FALSE, FALSE, ID_SRB1);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer ERROR !!\n");

    VLIB_AttachTimer(&ptCi->timer, ptCi, timNRRRC_RRCReconfig_id);

    return GOOD;
}  // }}}

int16_t FnVCCB_MN_INTER_SN_Exe_F1_UEContextModificationFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);

    status = FnVCCB_CommonMsgProc_F1_UEContextModification(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.f1);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_F1_UEContextModification(Failure) ERROR !!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_MN_INTER_SN_Exe_timF1_UeContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);

    status = FnVCCB_CommonMsgProc_F1_UEContextModification(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.f1);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_F1_UEContextModification(TMOUT) ERROR !!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_MN_INTER_SN_Exe_NRRRC_RrcReconfigurationComplete(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    status = VRIL_storeNRRRC_RrcReconfigurationComplete(ptCi, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VRIL_storeNRRRC_RrcReconfigurationComplete ERROR !! \n");

    return GOOD;
}  // }}}

int16_t FnVCCB_MN_INTER_SN_Exe_timNRRRC_RRCReconfig(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_RrcFail);

    VCCM_State_Common_timNRRRC_RRCReconfig(ptCi, ptAll, ptUnpack);

    return GOOD;
}  // }}}

// {{{
int16_t FnVCCB_MN_INTER_SN_Exe_XN_SNStatusTransfer(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_CommonMsgProc_XN_SNStatusTransfer(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNStatusTransfer(Response) ERROR !!\n");

    uint8_t targetXN = e_Snode_MnToTgtSn;
    status = FnVCCB_SendXNMessage(XN_SNStatusTransfer_id, ptCi, &targetXN, nullptr);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_SNStatusTransfer_id) Error!!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_MN_INTER_SN_Exe_timXN_SnStatusTransfer(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_XnFail);

    status = FnVCCB_CommonMsgProc_XN_SNStatusTransfer(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.xn);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNStatusTransfer(TMOUT) ERROR !!\n");

    return GOOD;
}  // }}}

// }}}

// STATE_MN_INTER_SN_Complete
// {{{
int16_t FnVCCB_MN_INTER_SN_Complete_NG_PDUSessionResourceModifyConfirm(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status = GOOD;

    status = FnVCCB_CommonMsgProc_NG_PDUSessionResourceModifyIndication(ptCi, ptAll, ptUnpack, &ptCi->timer);
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, status, "FnVCCB_CommonMsgProc_NG_PDUSessionResourceModifyIndication(Response) ERROR !!\n");
    if (status == BREAK) return GOOD;

    return GOOD;
}  // }}}

int16_t FnVCCB_MN_INTER_SN_Complete_timNG_PDUSessModifyConfirm(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status = GOOD;

    status = FnVCCB_CommonMsgProc_NG_PDUSessionResourceModifyIndication(ptCi, ptAll, ptUnpack, &ptCi->timer);
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, status, "FnVCCB_CommonMsgProc_NG_PDUSessionResourceModifyIndication(TMOUT) ERROR !!\n");
    if (status == BREAK) return GOOD;

    return GOOD;
}  // }}}

int16_t FnVCCB_MN_INTER_SN_Complete_E1_BearerContextModificationResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_CommonMsgProc_E1_BearerContextModification(ptCi, ptAll, ptUnpack, &ptCi->hoInfo.timer.e1);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_E1_BearerContextModification(Response) ERROR !!\n");

    if (true == FnVCCB_IsAnySnTermPerUE(ptCi, request_bearerType))  // when SN term bearer is used
    {
        auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_PDUSessionResourceModifyIndication_id);
        VALID_E_POINT_CHECK_ERROR(ngapSender);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, ngapSender->sendMsg(), "sendMsg(NG_PDUSessionResourceModifyIndication) ERROR!\n");

        ON_PDUSESS_MODIFY_CONFIRM_FLAG(ptCi->flag.respFlag);

        VLIB_AttachTimer(&ptCi->timer, ptCi, timNG_PDUSessModifyConfirm_id);
    }

    return GOOD;
}  // }}}
// }}}
// }}}

// Intra Cell Handover : VHCM_StartSaHandover_IntraCell
/****************************************************************************
 * @brief           Start SA Intra Cell Handover
 * @details         Make preparation in callInfo for Intra Cell handover
 * @param[in,out]   ptCi : call information / callInfo_type
 * @param[in]       cause : cause of Intra Cell Handover
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VHCM_StartSaHandover_IntraCell(callInfo_type *ptCi, const cellSelection_type cellSelection, uint16_t cause)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = ERROR;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    // This operation is a class operation for controlling the Ho-related database.
    HoDbConroller hoDbConroller(ptCi);

    // CRR Reset
    MACRO_RESET_CALL_FAULT_CAUSES;

    FnVCCB_PrintMrdcDrbInformation(ptCi);

    SET_STATE_CMD(IntraCellHO_cmd);
    FnVCCB_SetIntraGnbCommonHoInfo(
        ptCi, cellSelection, cause, HO_TYPE_SA_INTRA_GNB_INTRA_DU_HANDOVER, HO_TYPE_INTRA_DU);
    VCCM_SelectUlPath_NRDC(ptCi, true);

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Start Intra-gNB HO : cellNum(%u->%u), secModFlag(%u)\n", ptCi->servCellNum,
        ptCi->servCellNum, ptCi->ueInfo.securityModFlag);

    if (cellSelection.bandNr != ptCi->servCellBand)
    {
        FnVCCB_Decide_UlGapFR2PreferenceConfig(*ptCi);
    }

    // Trace/UETHR need to validate RFSP/SPID condition once again
    ptCi->managementTraceInfo.traceRfspSpidAllowed = traceRfspSpidUnknown;
    // SVR26A FGR-TA0601 VoMA CallEvent - IntraCell
    ptCi->vomaInfo.vomaEvent = VOMA_intraCellHo;

    if (FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType) == true)
    {
        status = FnVCCB_NextStep_Intra_Cell_E1Stop(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Intra_Cell_E1Stop ERROR!\n");
    }
    else
    {
        status = FnVCCB_NextStep_After_Intra_Cell_E1Stop(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_After_Intra_Cell_E1Stop ERROR!\n");
    }

    // Handover Trigger Completed
    hoDbConroller.setHandoverTriggerCompleted(true);

    return GOOD;
}  // }}}

/****************************************************************************
                    Intra gNB, Intra Cell
****************************************************************************/
// {{{

int16_t FnVCCB_NextStep_After_Intra_Cell_E1Stop(callInfo_type *ptCi)
{  // {{{

    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (IS_MRDC(ptCi) == true)
    {
        status = FnVCCB_NextStep_Intra_Cell_SnChg(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Intra_Cell_SnChg!\n");
    }
    else
    {
        status = FnVCCB_NextStep_Intra_Cell_Prepare(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Intra_Cell_Prepare!\n");
    }
    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_Intra_Cell_E1Stop(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VLIB_SetCurStateAll(ptCi, STATE_Intra_Cell_E1Stop);

    // SUSPEND
    status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
    if (ERROR == status)
    {
        // TODO : clear DB
        VCCB_PRINT_CALL_ERROR(ptCi, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");
        return ERROR;
    }

    VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_Intra_Cell_SnChg(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VLIB_SetCurStateAll(ptCi, STATE_Intra_Cell_SnChg);

    status = FnVCCB_NextStep_Common_Cell_SnChg(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Common_Cell_SnChg!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_Intra_Cell_SnRelA(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VLIB_SetCurStateAll(ptCi, STATE_Intra_Cell_SnRelA);

    status = FnVCCB_NextStep_Common_Cell_SnRelA(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Common_Cell_SnRelA!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_Intra_Cell_SnRelB(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VLIB_SetCurStateAll(ptCi, STATE_Intra_Cell_SnRelB);

    status = FnVCCB_NextStep_Common_Cell_SnRelB(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Common_Cell_SnRelB!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_Intra_Cell_Prepare(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VLIB_SetCurStateAll(ptCi, STATE_Intra_Cell_Prepare);

    // In 23B, DU has a feature to handle CRNTI collision during intra Cell HO. For this feature, DU should receive SCell rel/add for existing scells during intra Cell HO.
    VCCB_clearAllFailedCarrier(&ptCi->caInfo.failures);
    VLIB_ConfigSecondaryCellList(ptCi);
    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig! ERROR!\n");

    // new SpCellId, DRB modified List
    status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
    OFF_BITFLAG_NEED_XNUADDRIND_FOR_DLUPTNL(ptCi); // Temp Code, Manages this FLAG directly during the handover procedure.
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextModificationRequest ERROR!\n");

    VLIB_AttachTimer(&ptCi->timer, ptCi, timF1_UeContextModification_id);

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_Intra_Cell_Execution(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    status = VCOM_SaIntraCellHandover_ToExecution(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCOM_SaIntraCellHandover_ToExecution ERROR!\n");

    status = FnVCCB_NextStep_Common_Cell_Execution(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Common_Cell_Execution!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_Intra_Cell_Complete(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    VLIB_SetCurStateAll(ptCi, STATE_Intra_Cell_Complete);

    status = FnVCCB_NextStep_Common_Cell_Complete(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Common_Cell_Complete!\n");

    if (IsAvailable_MrdcInfo() && ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
    {
        OFF_MRDC_RSC_SETUP_FLAG(e1_scgSetup);
    }

    return GOOD;
}  // }}}

// STATE_Intra_Cell_E1Stop
int16_t VCCM_Intra_Cell_E1Stop_E1_BearerContextModificationSuccess(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    OFF_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    status = FnVCCB_NextStep_After_Intra_Cell_E1Stop(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_After_Intra_Cell_E1Stop!\n");

    return GOOD;
}  // }}}

int16_t VCCM_Intra_Cell_E1Stop_timE1_BearerContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    return GOOD;
}  // }}}

// STATE_Intra_Cell_SnChg
int16_t VCCM_Intra_Cell_SnChg_XN_SNodeModificationRequestAcknowledge(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    status = FnVCCB_StoreXNMessage(XN_SNodeModificationRequestAcknowledge_id, ptCi, ptAll, ptUnpack);
    if (status == ERROR)
    {
        MACRO_RESET_CALL_FAULT_CAUSES;
        // return ERROR; always return GOOD, call not release
    }

    // TODO: need to update the flag.........
    int drbIdx;
    callDRBInfo_type *ptDi;
    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        ptDi = &ptCi->drb[drbIdx];
        if (ptDi->usage != CI_use) continue;
        if (ptDi->xNuDlInfo.fNeedModify == 1)
        {
            ON_E1_MRDC_CTRL_FLAG(drbIdx, scgMod_xNuDlTnl);
        }
    }

    status = FnVCCB_NextStep_Intra_Cell_Prepare(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Intra_Cell_Prepare ERROR!\n");

    return status;
}  // }}}

int16_t VCCM_Intra_Cell_SnChg_XN_SNodeModificationRequestReject(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    ptCi->ueInfo.snKeyChangeWOMnKeyChange = VCCB_FLAG_OFF;

    status = FnVCCB_StoreXNMessage(XN_SNodeModificationRequestReject_id, ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_StoreXNMessage(XN_SNodeModificationRequestReject_id) ERROR !!\n");

    status = FnVCCB_UpdateBearerTypeForHandover(ptCi, MrdcHoWithSnRelease);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_UpdateBearerTypeForHandover ERROR !! \n");

    // It needs to be called again because the Meas configuration needs to be changed according to the scenario change.
    // Scenario : Scenario Change From 'Intra-Cell with/without SN Change' To 'Intra-Cell with SN Release' by 'Snode Modification Reject'.
    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");

    // Change State STATE_Intra_Cell_SnRelA
    status = FnVCCB_NextStep_Intra_Cell_SnRelA(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Intra_Cell_SnRelA ERROR!\n");

    return status;
}  // }}}

int16_t VCCM_Intra_Cell_SnChg_timXN_SNodeModificationRequest(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    OFF_SN_NODE_MOD_ACK_RCV_FLAG(ptCi->flag.respFlag);

    ptCi->ueInfo.snKeyChangeWOMnKeyChange = VCCB_FLAG_OFF;

    status = FnVCCB_UpdateBearerTypeForHandover(ptCi, MrdcHoWithSnRelease);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_UpdateBearerTypeForHandover ERROR !! \n");

    // It needs to be called again because the Meas configuration needs to be changed according to the scenario change.
    // Scenario : Scenario Change From 'Intra-Cell with/without SN Change' To 'Intra-Cell with SN Release' by 'Snode Modification TMOUT'.
    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");

    // Change State STATE_INTER_DU_SnRelA
    status = FnVCCB_NextStep_Intra_Cell_SnRelA(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Intra_Cell_SnRelA ERROR!\n");

    return GOOD;
}  // }}}

// STATE_Intra_Cell_SnRelA
int16_t VCCM_Intra_Cell_SnRelA_XN_SNodeReleaseRequestAcknowledge(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_CommonMsgProc_XN_SNodeRelease(ptCi, ptAll, ptUnpack, &ptCi->timer);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeRelease(Response) ERROR !!\n");

    if (!GET_E1_RESOURCE_FLAG(ptCi->flag.setupFlag))
    {
        status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextSetup);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Setup) ERROR!\n");
    }
    else
    {
        status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");
    }

    VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);

    return status;
}  // }}}

int16_t VCCM_Intra_Cell_SnRelA_XN_SNodeReleaseReject(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_CommonMsgProc_XN_SNodeRelease(ptCi, ptAll, ptUnpack, &ptCi->timer);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeRelease(Failure) ERROR !!\n");

    return status;
}  // }}}

int16_t VCCM_Intra_Cell_SnRelA_timXN_SNodeRelease(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status;

    status = FnVCCB_CommonMsgProc_XN_SNodeRelease(ptCi, ptAll, ptUnpack, &ptCi->timer);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_CommonMsgProc_XN_SNodeRelease(TMOUT) ERROR !!\n");

    return GOOD;
}  // }}}

int16_t VCCM_Intra_Cell_SnRelA_E1_BearerContextModificationSuccess(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    // check SN Term Bearer Exists
    if (TRUE == FnVCCB_IsAnySnTermPerUE(ptCi, current_bearerType))
    {
        status = FnVCCB_NextStep_Intra_Cell_SnRelB(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Intra_Cell_SnRelB ERROR!!\n");
    }
    else
    {
        status = FnVCCB_NextStep_Intra_Cell_Prepare(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Intra_Cell_Prepare Prepare!!\n");
    }

    return status;
}  // }}}

int16_t VCCM_Intra_Cell_SnRelA_timE1_BearerContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    return GOOD;
}  // }}}

// STATE_Intra_Cell_SnRelB
int16_t VCCM_Intra_Cell_SnRelB_XN_SNStatusTransfer(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    OFF_SN_STATUS_FLAG(ptCi->flag.respFlag);

    status = FnVCCB_StoreXNMessage(XN_SNStatusTransfer_id, ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_StoreXNMessage(XN_SNStatusTransfer_id) ERROR !!\n");

    // remove the E1 message.... It's sending at STATE_Intra_Cell_Execution
    if (1)
    {
        status = FnVCCB_NextStep_Intra_Cell_Prepare(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Intra_Cell_Prepare Prepare!!\n");
    }
    else
    {
        status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

        VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextModification_id);
    }

    return status;
}  // }}}

int16_t VCCM_Intra_Cell_SnRelB_timXN_SNStatusTransfer(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    return GOOD;
}  // }}}

int16_t VCCM_Intra_Cell_Common_E1_BearerContextModificationUnsuccess(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    return status;
}  // }}}

int16_t VCCM_Intra_Cell_SnRelB_timE1_BearerContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    return GOOD;
}  // }}}

// STATE_Intra_Cell_Prepare
int16_t VCCM_Intra_Cell_Prepare_F1_UEContextModificationResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    // new CRNTI, new DL GTP TEID, CellGroupConfig for HO Command
    status = VFIL_storeF1_UeContextModificationResponse(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationResponse ERROR !!\n");

    /* MN DL UP TNL: TODO, reqBearer type is split */
    if (FnVCCB_IsAnySnTermSplitPerUE(ptCi, request_bearerType))
    {
        ON_BITFLAG_NEED_XNUADDRIND_FOR_DLUPTNL(ptCi);

        // TODO: temp code for Inter SN Change...
        uint8_t targetXN = 0;
        if (FnVCCB_IsInterSnMobilityInMn(ptCi))
        {
            targetXN = e_Snode_MnToTgtSn;
        }

        status = FnVCCB_SendXNMessage(XN_XnUAddressIndication_id, ptCi, &targetXN, nullptr);
        OFF_BITFLAG_NEED_XNUADDRIND_FOR_DLUPTNL(ptCi);

        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage (XN_XnUAddressIndication) ERROR!\n");

        status = FnVCCB_NextStep_Intra_Cell_Execution(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Intra_Cell_Execution ERROR!\n");

        return status;
    }
    else
    {
        status = FnVCCB_NextStep_Intra_Cell_Execution(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Intra_Cell_Execution ERROR!!\n");
    }

    return GOOD;
}  // }}}

int16_t VCCM_Intra_Cell_Common_F1_UEContextModificationFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    status = VFIL_storeF1_UeContextModificationFailure(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationFailure ERROR!\n");

    return GOOD;
}  // }}}

int16_t VCCM_Intra_Cell_Prepare_timF1_UeContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutF1UeContextModification);

    return GOOD;
}  // }}}

int16_t VCCM_Intra_Cell_Prepare_XN_SNodeModificationRequestAcknowledge(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_StoreXNMessage(XN_SNodeModificationRequestAcknowledge_id, ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_StoreXNMessage(XN_SNodeModificationRequestAcknowledge) ERROR !!\n");

    status = FnVCCB_NextStep_Intra_Cell_Execution(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Intra_Cell_Execution ERROR!!\n");

    return status;
}  // }}}

int16_t VCCM_Intra_Cell_Prepare_XN_SNodeModificationRequestReject(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    status = FnVCCB_StoreXNMessage(XN_SNodeModificationRequestReject_id, ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage (XN_SNodeModificationRequestReject) ERROR!\n");

    OFF_SN_NODE_MOD_ACK_RCV_FLAG(ptCi->flag.respFlag);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    return status;
}  // }}}

int16_t VCCM_Intra_Cell_Prepare_timXN_SNodeModificationRequest(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status = GOOD;

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    OFF_SN_NODE_MOD_ACK_RCV_FLAG(ptCi->flag.respFlag);

    return status;
}  // }}}

int16_t VCCM_Intra_Cell_Execution_NRRRC_RrcReconfigurationComplete(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, CANCEL_TIMER);

    status = VRIL_storeNRRRC_RrcReconfigurationComplete(ptCi, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VRIL_storeNRRRC_RrcReconfigurationComplete ERROR!\n");

    OFF_RRC_CONNECTION_FLAG(ptCi->flag.respFlag);

    if(VCCB_FLAG_OFF == ptCi->ueInfo.snKeyChangeWOMnKeyChange)
    {
        ptCi->security.nCC = ptCi->security.newNCC;             // nCC value should be updated once the terminal is updated with new ncc.
        ptCi->security.newSecurityContextChangeInd = FALSE;
    }

    return GOOD;
}  // }}}

int16_t VCCM_Intra_Cell_Execution_timNRRRC_RRCReconfig(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, INIT_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaHoTmOutRrcHandoverComplete);

    return GOOD;
}  // }}}

int16_t VCCM_Intra_Cell_Execution_XN_SNStatusTransfer(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    OFF_SN_STATUS_FLAG(ptCi->flag.respFlag);

    status = FnVCCB_StoreXNMessage(XN_SNStatusTransfer_id, ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_StoreXNMessage(XN_SNStatusTransfer_id) ERROR !!\n");

    uint8_t targetXN = e_Snode_MnToTgtSn;
    status = FnVCCB_SendXNMessage(XN_SNStatusTransfer_id, ptCi, &targetXN, nullptr);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_SNStatusTransfer) ERROR!\n");

    return GOOD;
}  // }}}

int16_t VCCM_Intra_Cell_Complete_timE1_BearerContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, INIT_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    return GOOD;
}  // }}}

int16_t VCCM_Intra_Cell_Complete_F1_UEContextModificationResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, CANCEL_TIMER);

    status = VFIL_storeF1_UeContextModificationResponse(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationResponse ERROR !!\n");

    OFF_F1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    return GOOD;
}  // }}}

int16_t VCCM_Intra_Cell_Complete_timF1_UeContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, INIT_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutF1UeContextModification);

    return GOOD;
}  // }}}

int16_t VCCM_Intra_Cell_Complete_NG_PDUSessionResourceModifyConfirm(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status = GOOD;

    status = FnVCCB_CommonMsgProc_NG_PDUSessionResourceModifyIndication(ptCi, ptAll, ptUnpack, &ptCi->timer);
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, status, "FnVCCB_CommonMsgProc_NG_PDUSessionResourceModifyIndication(Response) ERROR !!\n");
    if (status == BREAK) return GOOD;

    if (true == FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType))
    {
        // Resume
        status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest(Modification) ERROR !!\n");

        VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextModification_id);
    }

    return GOOD;
}  // }}}

int16_t VCCM_Intra_Cell_Complete_timNG_PDUSessModifyConfirm(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status = GOOD;

    status = FnVCCB_CommonMsgProc_NG_PDUSessionResourceModifyIndication(ptCi, ptAll, ptUnpack, &ptCi->timer);
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, status, "FnVCCB_CommonMsgProc_NG_PDUSessionResourceModifyIndication(TMOUT) ERROR !!\n");
    if (status == BREAK) return GOOD;

    return GOOD;
}  // }}}

// }}}

/****************************************************************************
                        Next Step Common
****************************************************************************/
// {{{
int16_t FnVCCB_NextStep_Common_Cell_SnChg(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    status = FnVCCB_SendXNMessage(XN_SNodeModificationRequest_id, ptCi, nullptr, nullptr);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_send_XN_SNodeModificationRequest_ERROR!\n");

    VLIB_AttachTimer(&ptCi->timer, ptCi, timXN_SNodeModification_id);

    return GOOD;
} // }}}

int16_t FnVCCB_NextStep_Common_Cell_SnRelA(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    FnVCCB_set_MrdcSnRelMnEvent(ptCi, StatMrdcSnRelMn_MnInit_IntraMnMobility);

    // TX Stop to SN
    uint8_t targetXN = 0;
    status = FnVCCB_SendXNMessage(XN_SNodeReleaseRequest_id, ptCi, &targetXN, nullptr);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_SNodeReleaseRequest_id) ERROR!\n");

    ON_SN_NODE_REL_ACK_RCV_FLAG(ptCi->flag.respFlag);

    VLIB_AttachTimer(&ptCi->timer, ptCi, timXN_SNodeRelease_id);

    return GOOD;
} // }}}

int16_t FnVCCB_NextStep_Common_Cell_SnRelB(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint8_t targetXN = 0;
    status = FnVCCB_SendXNMessage(XN_XnUAddressIndication_id, ptCi, &targetXN, nullptr);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage (XN_XnUAddressIndication) ERROR!\n");

    if (FnVCCB_NeedWaitForSNStatus(ptCi) && (FnVCCB_IsSnStatusReceivedFromSNode(ptCi) == false))  // AMBearer Check O, SplitBearer Check X
    {
        VLIB_AttachTimer(&ptCi->timer, ptCi, timXN_SnStatusTransfer_id);

        // Waiting for the SN(SeqNum) STATUS of the SN(SNode) is performed.
        ON_SN_STATUS_FLAG(ptCi->flag.respFlag);
        return GOOD;
    }

    {
        status = FnVCCB_NextStep_Intra_Cell_Prepare(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Intra_Cell_Prepare ERROR!\n");
    }

    return GOOD;
} // }}}

int16_t FnVCCB_NextStep_Common_Cell_Execution(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint8_t srbIdx;
    callSRBInfo_type *ptSi = NULL;

    // If security info is changed, initiate PDCP SN after RRC Reconfiguration
    if ((VCCB_FLAG_ON == ptCi->ueInfo.securityModFlag) && (VCCB_FLAG_OFF == ptCi->ueInfo.snKeyChangeWOMnKeyChange))
    {
        for (srbIdx = ID_SRB1 - 1; srbIdx <= ID_SRB2 - 1; srbIdx++)
        {
            ptSi = &(ptCi->srbInfo[srbIdx]);

            if (!IS_VALID_NODE(SRB_NODE, ptCi, (ptSi))) continue;

            if (0 != FnPDCP_C_Init(&ptSi->pdcpRbContext, ptSi->rbInfo.rbId))
            {
                continue;
            }
        }
        ptCi->security.pdcpCtx = ptCi->security.newPdcpCtx;
    }

    // Copy the New PDCP Security Context information of the UE (Algo , Key) to the current
    // context, here after the UL/DL Integrity and Ciphering will be performed based on the
    // latest security information received from AMF

    ptCi->ueInfo.securityModFlag = VCCB_FLAG_OFF;

    return GOOD;
} // }}}

int16_t FnVCCB_NextStep_Common_Cell_Complete(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // RRC Recongifuration Complete Indicator
    status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextModificationRequest ERROR!\n");

    VLIB_AttachTimer(&ptCi->hoInfo.timer.f1, ptCi, timF1_UeContextModification_id);

    // Send XN complete
    if (IS_MRDC(ptCi))
    {
        if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_config_ue)
        {
            // Send XN Reconfiguration
            if (FnVCCB_NeedToSendXnSNodeReconfigurationComplete(ptCi) == true)
            {
                uint8_t targetXN = 0;
                status = FnVCCB_SendXNMessage(XN_SNodeReconfigurationComplete_id, ptCi, &targetXN, nullptr);
                VCCB_RETURN_ON_CALL_ERROR(
                    ptCi, status, "FnVCCB_SendXNMessage(XN_SNodeReconfigurationComplete_id) Error!!\n");
            }
        }
    }

    // when SN term bearer is used
    bool isPduSessionResourceModify = false;
    if (IS_MRDC(ptCi))
    {
        if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
        {
            // when SN term bearer is used
            if (true == FnVCCB_IsAnySnTermPerUE(ptCi, current_bearerType))
            {
                isPduSessionResourceModify = true;
            }
        }
    }

    if (true == isPduSessionResourceModify)
    {
        auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_PDUSessionResourceModifyIndication_id);
        VALID_E_POINT_CHECK_ERROR(ngapSender);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, ngapSender->sendMsg(), "sendMsg(NG_PDUSessionResourceModifyIndication) ERROR!\n");

        ON_PDUSESS_MODIFY_CONFIRM_FLAG(ptCi->flag.respFlag);

        VLIB_AttachTimer(&ptCi->timer, ptCi, timNG_PDUSessModifyConfirm_id);
    }
    // It operates only when MN Term UP exists.
    else if (FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType) == true)
    {
        // RESUME
        status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

        // start the timer
        VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextModification_id);
    }

    // SVR26A FGR-BC0323
    // FR500: gNB-CU shall perform LTM release procedure when executing Intra-cell HO w/ key change for LTM configured UE.
    FnVCCB_SendF1ReleaseToLtmTargetCellAndSetLtmRelFlag(*ptCi);

    return GOOD;
} // }}}

// }}}

/****************************************************************************
                        CondReconfig
****************************************************************************/
// {{{
/****************************************************************************
 * @brief           Handling NR-RRC Reconfiguration Complete in state STATE_CondReconfig
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t FnVCCB_CondReconfig_NRRRC_RrcReconfigurationComplete(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);  // timNRRRC_RRCReconfig_id

    if (VRIL_storeNRRRC_RrcReconfigurationComplete(ptCi, ptUnpack) == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VRIL_storeNRRRC_RrcReconfigurationComplete ERROR!\n");
        return ERROR;
    }

    FnVCCB_ConditionalCellConfigCommit(ptCi);

    return GOOD;
}  // }}}

/****************************************************************************
 * @brief           Handling NR-RRC TMOOUT of Reconfiguration Complete in state STATE_CondReconfig
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t FnVCCB_CondReconfig_timNRRRC_RRCReconfig(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);  // timNRRRC_RRCReconfig_id

    return GOOD;
}  // }}}

/****************************************************************************
                        Ltm_Prep
****************************************************************************/
// {{{
/****************************************************************************
 * @brief           Allocate and initialize LTM measurement related data.
 *
 * @param[in/out]   rCall : Call information / callInfo_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t FnVCCB_InitLtmProcRelatedDataForCall(callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;
    rCall.ltmUeInfo.ptProcRelatedData = FnVCCB_GetLtmProcRelatedDataForCall(rCall);
    if (nullptr == rCall.ltmUeInfo.ptProcRelatedData)
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "FnVCCB_GetLtmProcRelatedDataForCall ERROR!\n");
        return ERROR;
    }
    for (measurementsConfiguration_type &rMeasConf : rCall.ltmUeInfo.ptProcRelatedData->measConf)
    {
        VLIB_InitMeasurementsConfiguration(rMeasConf);
    }
    for (measurementsProcedure_type &rMeasProc : rCall.ltmUeInfo.ptProcRelatedData->measProc)
    {
        VLIB_InitMeasurementsProcedure(rMeasProc);
    }
    for (saMeasStateInfo_type &rSaMeas : rCall.ltmUeInfo.ptProcRelatedData->saMeas)
    {
        VCCM_InitSaMeas(&rSaMeas);
    }
    return GOOD;
}

/****************************************************************************
 * @brief       Initialize LTM proc related data for candidate.
 *
 * @param[in]   rCall : Call information / callInfo_type
 * @param[in]   ltmCellIdx : index of selected LTM candidate
 ****************************************************************************/
void FnVCCB_InitLtmProcRelatedDataForLtmCandidate(callInfo_type &rCall, uint8_t ltmCellIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(rCall.ltmUeInfo.ptProcRelatedData);
    VCCB_CHECK_E_RANGE_AND_VOID(ltmCellIdx, MAX_NUM_LTM_CELLS);

    LtmProcRelatedData_type &rLtmProcRelatedData = *rCall.ltmUeInfo.ptProcRelatedData;

    VLIB_InitMGapDuData(rLtmProcRelatedData.mGapDuData[ltmCellIdx]);
    rLtmProcRelatedData.ulGapFr2ConfigDu[ltmCellIdx].usage = VCCB_FLAG_OFF;

    for (scellInfo_type &rLtmScellInfo : rLtmProcRelatedData.ltmCaInfo[ltmCellIdx].ltmScells)
    {
        rLtmScellInfo.state = SCELL_STATE_RELEASED;
        rLtmScellInfo.action = SCELL_ACTION_KEEP;
    }

    memset(&rCall.ltmUeInfo.cellList[ltmCellIdx].data.duSelectionRelatedData, 0x00,
        sizeof(rCall.ltmUeInfo.cellList[ltmCellIdx].data.duSelectionRelatedData));

    OFFBIT_U8TABLE(rLtmProcRelatedData.ulGapFR2PreferenceConfig, ltmCellIdx);
}

int16_t FnVCCB_triggerLtmPrep(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = FnVCCB_InitLtmProcRelatedDataForCall(*ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_InitLtmProcRelatedDataForCall ERROR!\n");

    // set DB if needed (TODO: need to modify as function..
    if (FnVCCB_IsEmptyLtmCell(ptCi))
    {
        // insert current cell
        uint8_t ltmCellIdx = FnVCCB_AllocLtmCellInfoForCGI(ptCi, ptCi->nRCGI);
        if (ltmCellIdx < MAX_NUM_LTM_CELLS)
        {
            auto cellNum = ptCi->servCellNum;
            if (cellNum < MAX_CELL_NUM_VCCB)
            {
                const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
                ptCi->ltmUeInfo.cellList[ltmCellIdx].data.cellIdentity = pCell->cellIdentity;
                ptCi->ltmUeInfo.cellList[ltmCellIdx].data.pci = pCell->phyCellId;

                ptCi->ltmUeInfo.cellList[ltmCellIdx].data.ssb.ssbArfcn = static_cast<int>(pCell->ssbArfcn);
                ptCi->ltmUeInfo.cellList[ltmCellIdx].data.ssb.scs = pCell->measurementsData.measurementObjectsNRDb[INTRAFREQ_OBJECT_IDX].base.ssbSubcarrierSpacing;
                ptCi->ltmUeInfo.cellList[ltmCellIdx].data.ssb.periodicity = pCell->intraGnbNbrInfo.smtc1.periodicityAndOffset.periodicity;
            }

            // If use same crnti with current spcell
            ptCi->ltmUeInfo.cellList[ltmCellIdx].handle.flag.receivedDuUeId = 1;
            ptCi->ltmUeInfo.cellList[ltmCellIdx].handle.flag.setup = TRUE;
            ptCi->ltmUeInfo.cellList[ltmCellIdx].data.crnti = ptCi->ueInfo.ueId.cRNTI;

            ptCi->ltmUeInfo.cellList[ltmCellIdx].handle.du.f1Idx = ptCi->endPointInfo.f1Idx;
            ptCi->ltmUeInfo.cellList[ltmCellIdx].handle.du.duUEid = ptCi->auCallId;


            ptCi->ltmUeInfo.cellList[ltmCellIdx].data.cellSelection.cellNum = cellNum;
            ptCi->ltmUeInfo.cellList[ltmCellIdx].data.cellSelection.bandNr = ptCi->servCellBand;

            FnVCCB_InitLtmProcRelatedDataForLtmCandidate(*ptCi, ltmCellIdx);

            // use the same setting as current spcell
            if (ptCi->ueNrRrcOtherConfig.currConfig.ulGapFR2PreferenceConfig)
            {
                ONBIT_U8TABLE(ptCi->ltmUeInfo.ptProcRelatedData->ulGapFR2PreferenceConfig, ltmCellIdx);
            }
        }

        FnVCCB_UpdateLtmSvcGrp(*ptCi);
    }

    // insert target cell
    {
        uint8_t ltmCellIdx = FnVCCB_AllocLtmCellInfoForCGI(ptCi, ptCi->hoInfo.cgi);
        if (ltmCellIdx < MAX_NUM_LTM_CELLS)
        {
            ptCi->ltmUeInfo.cellList[ltmCellIdx].data.cellIdentity = ptCi->hoInfo.cellIdentity;
            ptCi->ltmUeInfo.cellList[ltmCellIdx].data.pci = ptCi->hoInfo.phyCellId;
            ptCi->ltmUeInfo.cellList[ltmCellIdx].handle.du.f1Idx = ptCi->hoInfo.targetDu.f1Idx;

            ptCi->ltmUeInfo.cellList[ltmCellIdx].data.cellSelection.cellNum = ptCi->hoInfo.targetCellNum;
            ptCi->ltmUeInfo.cellList[ltmCellIdx].data.cellSelection.bandNr = ptCi->hoInfo.targetCellBand;

            auto cellNum = ptCi->hoInfo.targetCellNum;
            if (cellNum < MAX_CELL_NUM_VCCB)
            {
                const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
                // ptCi->ltmUeInfo.cellList[ltmCellIdx].pci = pCell->phyCellId;

                ptCi->ltmUeInfo.cellList[ltmCellIdx].data.ssb.ssbArfcn = static_cast<int>(pCell->ssbArfcn);
                ptCi->ltmUeInfo.cellList[ltmCellIdx].data.ssb.scs = pCell->measurementsData.measurementObjectsNRDb[INTRAFREQ_OBJECT_IDX].base.ssbSubcarrierSpacing;
                ptCi->ltmUeInfo.cellList[ltmCellIdx].data.ssb.periodicity = pCell->intraGnbNbrInfo.smtc1.periodicityAndOffset.periodicity;
            }
            FnVCCB_UpdateRsIndexListForLTM(*ptCi, ptCi->hoInfo.targetCellNum);
            if (ptCi->ltmUeInfo.numOfCellList == 1) FnVCCB_UpdateRsIndexListForLTM(*ptCi, ptCi->servCellNum);

            FnVCCB_InitLtmProcRelatedDataForLtmCandidate(*ptCi, ltmCellIdx);
        }
    }

    ptCi->ltmUeInfo.flag.ltmDuReleaseSent = FALSE;
    memset(&ptCi->ltmUeInfo.releasedDu[0], 0x0, sizeof(duHoInfo_type) * MAX_NUM_LTM_CELLS_EXCL_PCELL);

    // TODO: need to modify the code... while is not good code..
    ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromLtmAction(ptCi, ltm_installed);
    while (ptTarget != NULL)
    {
        FnVCCB_SetLtmCellAction(ptCi, ptTarget->handle.ltmCellIdx, ltm_selectAsTargetCell);
        ptTarget = FnVCCB_GetLtmCellInfoFromLtmAction(ptCi, ltm_installed);
    }

    status = FnVCCB_NextStep_Ltm_Prep_TgtDuAdd(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Ltm_Prep_TgtDu!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_Ltm_Prep_TgtDuRel(callInfo_type &rCall)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status;

    ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromFlag(&rCall, LTM_CELL_INFO_FLAG_RELEASE_IN_PROGRESS);
    if (ptTarget == NULL)
    {
        return BREAK;
    }

    VLIB_SetCurStateAll(&rCall, STATE_Ltm_Prep_TgtDuRel);

    if (DBG->flag.ltm_parallelOperation)
    {
        for (uint8_t ltmCellIdx = 0; ltmCellIdx < MAX_NUM_LTM_CELLS; ltmCellIdx++)
        {
            ltmCellInfo_type *ptTargetCell = FnVCCB_GetLtmCellInfoForIndex(&rCall, ltmCellIdx);
            if (ptTargetCell == NULL) continue;

            if (ptTargetCell->handle.flag_uValue & LTM_CELL_INFO_FLAG_RELEASE_IN_PROGRESS)
            {
                status = FnVCCB_SendF1UeContextRelease_LtmCandidateCell(&rCall, ptTargetCell);
                VCCB_RETURN_ON_CALL_ERROR(&rCall, status, "FnVCCB_SendF1UeContextRelease_LtmCandidateCell ERROR !!\n");

                VCCB_CLEAR_TIMER(&ptTargetCell->handle.ltmCellReleaseTimer, CANCEL_TIMER);
            }
        }
    }
    else
    {
        status = FnVCCB_SendF1UeContextRelease_LtmCandidateCell(&rCall, ptTarget);
        VCCB_RETURN_ON_CALL_ERROR(&rCall, status, "FnVCCB_SendF1UeContextRelease_LtmCandidateCell ERROR !!\n");
        
        VCCB_CLEAR_TIMER(&ptTarget->handle.ltmCellReleaseTimer, CANCEL_TIMER);
    }

    VLIB_AttachTimer(&rCall.hoInfo.timer.f1, &rCall, timF1_UeContextRelease_id);

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_Ltm_Prep_TgtDuAdd(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;
    
    ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromCGI(ptCi, ptCi->hoInfo.cgi);
    if (ptTarget == nullptr) return ERROR;

    FnVCCB_StatLtmOut(*ptCi, *ptTarget, LTM_PrepAtt);
    
    VLIB_SetCurStateAll(ptCi, STATE_Ltm_Prep_TgtDuAdd);
    FnVCCB_SetLtmCellAction(ptCi, ptTarget->handle.ltmCellIdx, ltm_DuIsOngoing);
    HandleCurrentCandidateCellIndex currCandiCellIdxHandler(*ptCi, ptTarget->handle.ltmCellIdx);

    status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");

    ptCi->ltmUeInfo.respFlag = 0;

    status = VFIL_sendF1_UeContextSetupRequest(ptCi, NULL, 0);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextSetupRequest ERROR !!\n");

    VLIB_AttachTimer(&ptCi->hoInfo.timer.f1, ptCi, timF1_UeContextSetup_id);

    return GOOD;
}  // }}}


int16_t FnVCCB_NextStep_Ltm_Prep_Cand(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    VLIB_SetCurStateAll(ptCi, STATE_Ltm_Prep_Cand);

#if defined(NEW_HOST_SIM) || defined(IPC_TEST)
    if (ptCi->cellGroupConfig.numocts != 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "cellGroupConfig.numocts is not 0!!\n");
    }
#endif

    if (DBG->flag.ltmCandidateModifyParallel)
    {
        for (uint8_t ltmCellIdx = 0; ltmCellIdx < MAX_NUM_LTM_CELLS; ltmCellIdx++)
        {
            ltmCellInfo_type *ptTargetCell = FnVCCB_GetLtmCellInfoForIndex(ptCi, ltmCellIdx);
            if (ptTargetCell == NULL) continue;

            if (ptTargetCell->handle.ltmAction == ltm_selectAsTargetCell)
            {
                FnVCCB_SetLtmCellAction(ptCi, ptTargetCell->handle.ltmCellIdx, ltm_DuIsOngoing);
                HandleCurrentCandidateCellIndex currCandiCellIdxHandler(*ptCi, ptTargetCell->handle.ltmCellIdx);

                if (false == FnVCCB_IsLtmReleaseCase(*ptCi))
                {
                    status = VCCB_PrepareNewMeasConfig(ptCi);
                    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");
                }

                status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextModificationRequest ERROR !!\n");

                if (ptTargetCell->data.cellSelection.cellNum == ptCi->servCellNum && ptTargetCell->handle.flag.rrc_activation_flag == FALSE)
                {
                    FnVCCB_StatLtmOut(*ptCi, *ptTargetCell, LTM_PrepAtt);
                }
            }
        }
        VLIB_AttachTimer(&ptCi->hoInfo.timer.f1, ptCi, timF1_UeContextModification_id);
    }
    else
    {
        // 1. [TODO] Set DB for current spcell
        ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromLtmAction(ptCi, ltm_selectAsTargetCell);
        if (ptTarget == NULL) 
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[LTM] ptTarget = NULL %s\n", __func__);
            return ERROR;
        }

        FnVCCB_SetLtmCellAction(ptCi, ptTarget->handle.ltmCellIdx, ltm_DuIsOngoing);

        HandleCurrentCandidateCellIndex currCandiCellIdxHandler(*ptCi, ptTarget->handle.ltmCellIdx);

        if (false == FnVCCB_IsLtmReleaseCase(*ptCi))
        {
            status = VCCB_PrepareNewMeasConfig(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");
        }

        // 2. Send the F1 message to current spcell
        status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextModificationRequest ERROR !!\n");

        if (ptTarget->data.cellSelection.cellNum == ptCi->servCellNum && ptTarget->handle.flag.rrc_activation_flag == FALSE)
        {
            FnVCCB_StatLtmOut(*ptCi, *ptTarget, LTM_PrepAtt);
        }

        VLIB_AttachTimer(&ptCi->hoInfo.timer.f1, ptCi, timF1_UeContextModification_id);
    }

    // Init length of cell group configsss
    ptCi->cellGroupConfig.numocts = 0;

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_Ltm_Prep_Propagation(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    VLIB_SetCurStateAll(ptCi, STATE_Ltm_Prep_Propagation);

    if (DBG->flag.ltm_parallelOperation)
    {
        for (uint8_t ltmCellIdx = 0; ltmCellIdx < MAX_NUM_LTM_CELLS; ltmCellIdx++)
        {
            ltmCellInfo_type *ptTargetCell = FnVCCB_GetLtmCellInfoForIndex(ptCi, ltmCellIdx);
            if (ptTargetCell == NULL) continue;

            if (ptTargetCell->handle.ltmAction == ltm_DuIsDone)
            {
                FnVCCB_SetLtmCellAction(ptCi, ptTargetCell->handle.ltmCellIdx, ltm_PropIsOnging);
                HandleCurrentCandidateCellIndex currCandiCellIdxHandler(*ptCi, ptTargetCell->handle.ltmCellIdx);

                status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextModificationRequest ERROR !!\n");
            }
        }
        VLIB_AttachTimer(&ptCi->hoInfo.timer.f1, ptCi, timF1_UeContextModification_id);
    }
    else
    {
        // trigger propagation
        {
            ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromLtmAction(ptCi, ltm_DuIsDone);
            if (ptTarget != NULL)
            {
                FnVCCB_SetLtmCellAction(ptCi, ptTarget->handle.ltmCellIdx, ltm_PropIsOnging);

                HandleCurrentCandidateCellIndex currCandiCellIdxHandler(*ptCi, ptTarget->handle.ltmCellIdx);

                status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextModificationRequest ERROR !!\n");

                VLIB_AttachTimer(&ptCi->hoInfo.timer.f1, ptCi, timF1_UeContextModification_id);
            }
        }
    }

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_Ltm_Prep_RRC(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    // build non delta reconfiguration before changing state
    {
        FnVCCB_ShowStoredLtmCellGroupConfig(*ptCi);

        // [TODO] need to build multiple cell rrc...
        {
            msgContainer_type *pRrcTxBuf = &THREAD_INFO->call[ptCi->myThreadId].buf.rrcTx;
            NRRRC_RRCReconfiguration rrcReconfiguration, *ptMsg = &rrcReconfiguration;

            uint16_t cgConfigFlag = FALSE;
            uint16_t handoverPreparationInformationFlag = FALSE;

            long tmpRrcLen;

            ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromLtmAction(ptCi, ltm_PropIsDone);
            while (ptTarget != NULL)
            {
                FnVCCB_SetLtmCellAction(ptCi, ptTarget->handle.ltmCellIdx, ltm_RrcIsOngoing);

                std::ignore = FnVCCB_GetStoredCellGroupConfig(*ptCi, ptTarget->handle.ltmCellIdx, ptCi->cellGroupConfig);
                if (ptCi->cellGroupConfig.numocts > 0)
                {
                    // currCandidateCellIdx can be used for getting ltm targetCell Information in MakeMsgNRRRC_RRCReconfiguration 
                    HandleCurrentCandidateCellIndex currCandiCellIdxHandler(*ptCi, ptTarget->handle.ltmCellIdx);
                    // build rrc for target cell
                    status = MakeMsgNRRRC_RRCReconfiguration(ptCi, ptMsg, cgConfigFlag, handoverPreparationInformationFlag);
                    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "MakeMsgNRRRC_RRCReconfiguration ERROR !!\n");
                    if (BREAK == status)
                    {
                        pRrcTxBuf->numocts = 0;
                        VCCB_PRINT_CALL_COMMENT(ptCi, "MakeMsgNRRRC_RRCReconfiguration BREAK!\n");
                        return BREAK;
                    }

                    // pack to other buffer...
                    tmpRrcLen = sizeof(pRrcTxBuf->data);
                    VCCB_RETURN_ON_CALL_ERROR(ptCi, PackMsgNRRRC_RRCReconfigurationPdu(ptMsg, pRrcTxBuf->data, &tmpRrcLen),
                            "PackMsgNRRRC_RRCReconfiguration ERROR !!\n");

                    pRrcTxBuf->numocts = static_cast<uint16_t>(tmpRrcLen);
                }
                else
                {
                    pRrcTxBuf->numocts = 0;
                }

                // TODO:copy the rrc hex packet to buffer
                FnVCCB_StoreLtmReconfig(*ptCi, ptTarget->handle.ltmCellIdx, *pRrcTxBuf);

                // update 
                FnVCCB_SetLtmCellAction(ptCi, ptTarget->handle.ltmCellIdx, ltm_RrcIsDone);

                // get next...
                ptTarget = FnVCCB_GetLtmCellInfoFromLtmAction(ptCi, ltm_PropIsDone);
            }
        }

        std::ignore = FnVCCB_GetStoredSourceCellGroupConfig(*ptCi, ptCi->cellGroupConfig);
    }

    VLIB_SetCurStateAll(ptCi, STATE_Ltm_Prep_RRC);

    status = FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer(ptCi, FALSE, FALSE, ID_SRB1);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer ERROR !!\n");

    // RRC Reconfiguration Complete
    VLIB_AttachTimer(&ptCi->timer, ptCi, timNRRRC_RRCReconfig_id);

    return GOOD;
}  // }}}

int16_t FnVCCB_Ltm_Prep_TgtDuAdd_F1_UEContextSetupResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, CANCEL_TIMER);

    status = FnVCCB_ProcDuInitFullConfiguration(ptCi, ptAll, ptUnpack, true);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_ProcDuInitFullConfiguration Error in %s\n", __func__);
    if (status == BREAK)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Reject by DU Init Full Configuration!! in %s\n", __func__);

        return BREAK;
    }

    ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromCGI(ptCi, ptCi->hoInfo.cgi);
    if (ptTarget == NULL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[LTM] Can't find LTM candidate cell!!\n");
        return ERROR;
    }
    HandleCurrentCandidateCellIndex currCandiCellIdxHandler(*ptCi, ptTarget->handle.ltmCellIdx);

    status = FnVCCB_LtmStoreF1_UeContextSetupResponse(ptCi, ptAll, ptUnpack);
    switch (status)
    {
        case BREAK:
            VCCB_PRINT_CALL_ERROR(ptCi, "F1_UEContextSetupResponse :: Received by other DU and ignored.\n");
            return BREAK;
        case ERROR:
            VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_storeF1_UeContextSetupResponse ERROR !!\n");
            return ERROR;
        default:
            break;
    }
    
    // [TODO] temp code..update db 
    FnVCCB_SetLtmCellAction(ptCi, ptTarget->handle.ltmCellIdx, ltm_DuIsDone);

    FnVCCB_StoreF1_EarlySyncInformation(*ptCi, ptTarget->handle.ltmCellIdx, ptCi->ltmUeInfo.receivedF1Buffer.pEarlySyncInformation);

    FnVCCB_StoreF1_LTMConfiguration(*ptCi, ptTarget->handle.ltmCellIdx, ptCi->ltmUeInfo.receivedF1Buffer.pLtmConfiguration);

    // TODO: need to copy the cell group config to buffer
    std::ignore = FnVCCB_StoreLtmCellGroupConfigAndResetCall(*ptCi, ptTarget->handle.ltmCellIdx, ptCi->cellGroupConfig);
    FnVCCB_AttachLtmCandidateCellRelTimer(*ptCi, ptTarget, ptCi->servCellNum);

    return GOOD;
}  // }}}

int16_t FnVCCB_Ltm_Prep_TgtDuAdd_F1_UEContextSetupFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    // VCCM_INTER_DU_Prepare_F1_UEContextSetupFailure
 
    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, CANCEL_TIMER);

    ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromCGI(ptCi, ptCi->hoInfo.cgi);
    if (ptTarget == NULL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[LTM] Can't find LTM candidate cell!!\n");
        return ERROR;
    }
    HandleCurrentCandidateCellIndex currCandiCellIdxHandler(*ptCi, ptTarget->handle.ltmCellIdx);

    status = VFIL_storeF1_UeContextSetupFailure(ptCi, ptAll, ptUnpack);
    switch (status)
    {
        case BREAK:
            VCCB_PRINT_CALL_ERROR(ptCi, "F1_UEContextSetupFailure :: Received by other DU and ignored.\n");
            return BREAK;
        case ERROR:
            VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_storeF1_UeContextSetupFailure ERROR !!\n");
            return ERROR;
        default:
            break;
    }
    
    return BREAK;
}  // }}}

int16_t FnVCCB_Ltm_Prep_TgtDuAdd_timF1_UeContextSetup(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    // VCCM_INTER_DU_Prepare_timF1_UeContextSetup

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, INIT_TIMER);

    OFF_F1_RESOURCE_TGT_FLAG(ptCi->flag.setupFlag);
    OFF_F1_RESOURCE_TGT_FLAG(ptCi->flag.respFlag);

    return BREAK;
}  // }}}

int16_t FnVCCB_Ltm_Prep_TgtDuRel_F1_UEContextReleaseComplete(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status = GOOD;

    // VCCM_INTER_DU_Prepare_F1_UEContextReleaseComplete

    if (DBG->flag.ltm_parallelOperation == FALSE)
    {
        VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, CANCEL_TIMER);
    }

    status = VFIL_storeF1_UeContextReleaseComplete(ptCi, ptAll, ptUnpack);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_storeF1_UeContextReleaseComplete ERROR !!\n");
    }

    // TBD:: when db init event is requird
    // FnVCCB_FreeLtmCellInfoForIndex(*ptCi, ptCi->ltmUeInfo.currCandidateCellIdx);

    return GOOD;
}  // }}}

int16_t FnVCCB_Ltm_Prep_TgtDuRel_timF1_UeContextRelease(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    // VCCM_INTER_DU_Prepare_timF1_UeContextRelease

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, INIT_TIMER);

    ptCi->ltmUeInfo.respFlag = 0; // 25B IoDT doen't support parallel F1 release in STATE_Ltm_Prep_TgtDuRel

    return GOOD;
}  // }}}

// ============================================================
// Common helper function: Extract LTM cell info from F1 message
// ============================================================
// Common logic to extract gNB-DU UE F1AP ID from 
// F1_UEContextModificationResponse or F1_UEContextModificationFailure
// and find LTM cell info
template<typename F1MsgType>
static ltmCellInfo_type* FnVCCB_GetLtmCellInfoFromF1Message(
    callInfo_type *ptCi, 
    message_type *ptAll, 
    const F1MsgType *pF1Msg)
{
    const F1_GNB_DU_UE_F1AP_ID *pGNB_DU_UE_F1AP_ID = NULL;

    // gNB-DU UE F1AP ID - MANDATORY
    if (ERROR == VFIL_GetF1IE((const void **)&pGNB_DU_UE_F1AP_ID, pF1Msg->protocolIEs, F1_id_gNB_DU_UE_F1AP_ID))
    {
        return NULL;
    }

    SctpDataType *ptMsg = (SctpDataType *)ptAll;
    ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromDuInfo(*ptCi, ptMsg->endPointIdx, *pGNB_DU_UE_F1AP_ID);
    if (ptTarget == NULL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[LTM] Can't find LTM candidate cell!!, endPointIdx: %d, gNB-DU UE F1AP ID: %d\n", 
            ptMsg->endPointIdx, *pGNB_DU_UE_F1AP_ID);
        return NULL;
    }

    return ptTarget;
}

int16_t FnVCCB_Ltm_Prep_Cand_F1_UEContextModificationResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    // VCCM_INTER_DU_DuQuery_F1_UEContextModificationResponse



    const F1_UEContextModificationResponse *pResp = ptUnpackConvert<F1_UEContextModificationResponse>(ptUnpack);
    ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromF1Message(ptCi, ptAll, pResp);
    if (ptTarget == NULL)
    {
        return BREAK;  // LTM Candidate celll will be release by timeout
    }

    
    if (DBG->flag.ltmCandidateModifyParallel == FALSE)
    {
        VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, CANCEL_TIMER);
    }

    HandleCurrentCandidateCellIndex currCandiCellIdxHandler(*ptCi, ptTarget->handle.ltmCellIdx);

    // Collect Trace message when related ltm cell is known
    SctpDataType *ptMsg = (SctpDataType *)ptAll;
    VLIB_collectTraceMessage(ptCi, (TraceParam){RX_MSG, F1_UEContextModificationResponse_id, reinterpret_cast<char *>(ptMsg->data),
                             ptMsg->length, ptMsg->endPointIdx});

    status = FnVCCB_LtmStoreF1_UeContextModificationResponse(ptCi, ptAll, ptUnpack);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_LtmStoreF1_UeContextModificationResponse ERROR !!\n");

        if (ptTarget->data.cellSelection.cellNum == ptCi->servCellNum)
        {
            return ERROR;  // Call Release
        }

        ptTarget->handle.flag.release_in_progress = true;
        return BREAK;  // LTM Candidate Cell Release
    }

    // TODO: how
    FnVCCB_SetLtmCellAction(ptCi, ptTarget->handle.ltmCellIdx, ltm_DuIsDone);

    FnVCCB_StoreF1_EarlySyncInformation(*ptCi, ptTarget->handle.ltmCellIdx, ptCi->ltmUeInfo.receivedF1Buffer.pEarlySyncInformation);

    FnVCCB_StoreF1_LTMConfiguration(*ptCi, ptTarget->handle.ltmCellIdx, ptCi->ltmUeInfo.receivedF1Buffer.pLtmConfiguration);

    // TODO: need to copy the cell group config to buffer
    std::ignore = FnVCCB_StoreLtmCellGroupConfigAndResetCall(*ptCi, ptTarget->handle.ltmCellIdx, ptCi->cellGroupConfig);

    return GOOD;
}  // }}}

int16_t FnVCCB_Ltm_Prep_Cand_F1_UEContextModificationFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    // VCCM_INTER_DU_DuQuery_F1_UEContextModificationFailure

    const F1_UEContextModificationFailure *pResp = ptUnpackConvert<F1_UEContextModificationFailure>(ptUnpack);
    ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromF1Message(ptCi, ptAll, pResp);
    if (ptTarget == NULL)
    {
        return BREAK;  // LTM Candidate celll will be release by timeout
    }

    if (DBG->flag.ltmCandidateModifyParallel == FALSE)
    {
        VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, CANCEL_TIMER);
    }



    HandleCurrentCandidateCellIndex currCandiCellIdxHandler(*ptCi, ptTarget->handle.ltmCellIdx);

    // Collect Trace message when related ltm cell is known
    SctpDataType *ptMsg = reinterpret_cast<SctpDataType *>(ptAll);
    VLIB_collectTraceMessage(ptCi, (TraceParam){RX_MSG, F1_UEContextModificationFailure_id, reinterpret_cast<char *>(ptMsg->data),
                             ptMsg->length, ptMsg->endPointIdx});

    status = VFIL_storeF1_UeContextModificationFailure(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationFailure ERROR !!\n");

    if (ptTarget->data.cellSelection.cellNum == ptCi->servCellNum)
    {
        return ERROR; //call release
    }

    ptTarget->handle.flag.release_in_progress = true;

    return GOOD;
}  // }}}

int16_t FnVCCB_Ltm_Prep_Cand_timF1_UeContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    // VCCM_INTER_DU_DuQuery_timF1_UeContextModification

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, INIT_TIMER);

    if (DBG->flag.ltmCandidateModifyParallel == FALSE)
    {
        ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromLtmAction(ptCi, ltm_DuIsOngoing);
        if (ptTarget == NULL)
        {
            VCCB_PRINT_CALL_CRITICAL(ptCi, "[LTM][Cand] Can't find a candidate cell on TMOUT\n");
            return ERROR;
        }

        if (ptTarget->data.cellSelection.cellNum == ptCi->servCellNum)
        {
            MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutF1UeContextModification);
            return ERROR;  // call release
        }

        OFFBIT_U8(ptCi->ltmUeInfo.respFlag, ptTarget->handle.ltmCellIdx);
        ptTarget->handle.flag.release_in_progress = true;
    }
    else
    {
        if (GET_F1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag)) 
        {
            // Pcell F1_UeContextModification timeout
            MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutF1UeContextModification);
            return ERROR; // call release
        }

        for (auto &rLtmCell : ptCi->ltmUeInfo.cellList)
        {
            if (rLtmCell.handle.usage == CI_no_use) continue;

            if (!GETBIT_U8(ptCi->ltmUeInfo.respFlag, rLtmCell.handle.ltmCellIdx)) continue;

            rLtmCell.handle.flag.release_in_progress = true;
        }

        ptCi->ltmUeInfo.respFlag = 0;
    }

    return GOOD;
}  // }}}

int16_t FnVCCB_Ltm_Prep_Propagation_F1_UEContextModificationResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    const F1_UEContextModificationResponse *pResp = ptUnpackConvert<F1_UEContextModificationResponse>(ptUnpack);
    ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromF1Message(ptCi, ptAll, pResp);
    if (ptTarget == NULL)
    {
        return BREAK;  // LTM Candidate celll will be release by timeout
    }
    
    if (DBG->flag.ltm_parallelOperation == FALSE)
    {
        VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, CANCEL_TIMER);
    }

    FnVCCB_SetLtmCellAction(ptCi, ptTarget->handle.ltmCellIdx, ltm_PropIsDone);
    HandleCurrentCandidateCellIndex currCandiCellIdxHandler(*ptCi, ptTarget->handle.ltmCellIdx);

    // Collect Trace message when related ltm cell is known
    SctpDataType *ptMsg = (SctpDataType *)ptAll;
    VLIB_collectTraceMessage(ptCi, (TraceParam){RX_MSG, F1_UEContextModificationResponse_id, reinterpret_cast<char *>(ptMsg->data),
                             ptMsg->length, ptMsg->endPointIdx});

    status = FnVCCB_LtmStoreF1_UeContextModificationResponse(ptCi, ptAll, ptUnpack);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_LtmStoreF1_UeContextModificationResponse ERROR !!\n");

        if (ptTarget->data.cellSelection.cellNum == ptCi->servCellNum)
        {
            return ERROR;  // Call Release
        }

        ptTarget->handle.flag.release_in_progress = true;
        return BREAK;  // LTM Candidate Cell Release
    }

    if (FnVCCB_CheckCgiIdentical(&ptCi->nRCGI, &ptTarget->data.nrcgi) == TRUE)
    {
        // TODO: need to copy the cell group config to buffer
        std::ignore = FnVCCB_StoreLtmSourceCellGroupConfig(*ptCi, ptCi->cellGroupConfig);
    }

    // if (DBG->flag.ltm_parallelOperation)
    // {
    //     ptTarget = FnVCCB_GetLtmCellInfoFromDuInfo(*ptCi, ptMsg->endPointIdx, *pGNB_DU_UE_F1AP_ID);
    //     if (ptTarget == nullptr) return ERROR;
    //     FnVCCB_SetLtmCellAction(ptCi, ptTarget->handle.ltmCellIdx, ltm_PropIsDone);
    //     // OFFBIT_U8(ptCi->ltmUeInfo.respFlag, pLtmTargetCell->ltmCellIdx);
    // }
    // else
    // {
    //     ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromLtmAction(ptCi, ltm_PropIsOnging);
    //     if (ptTarget != NULL)
    //     {
    //         FnVCCB_SetLtmCellAction(ptCi, ptTarget->handle.ltmCellIdx, ltm_PropIsDone);
    //     }
    // }
    // if (FnVCCB_CheckCgiIdentical(&ptCi->nRCGI, &ptTarget->data.nrcgi) == TRUE)
    // {
    //     // TODO: need to copy the cell group config to buffer
    //     std::ignore = FnVCCB_StoreLtmSourceCellGroupConfig(*ptCi, ptCi->cellGroupConfig);
    // }

    return GOOD;
}  // }}}

int16_t FnVCCB_Ltm_Prep_Propagation_F1_UEContextModificationFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);


    const F1_UEContextModificationFailure *pResp = ptUnpackConvert<F1_UEContextModificationFailure>(ptUnpack);
    ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromF1Message(ptCi, ptAll, pResp);
    if (ptTarget == NULL)
    {
        return BREAK;  // LTM Candidate celll will be release by timeout
    }
    if (DBG->flag.ltm_parallelOperation == FALSE)
    {
        VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, CANCEL_TIMER);
    }

    FnVCCB_SetLtmCellAction(ptCi, ptTarget->handle.ltmCellIdx, ltm_PropIsDone);

    // Collect Trace message when related ltm cell is known
    SctpDataType *ptMsg = reinterpret_cast<SctpDataType *>(ptAll);
    VLIB_collectTraceMessage(ptCi, (TraceParam){RX_MSG, F1_UEContextModificationFailure_id, reinterpret_cast<char *>(ptMsg->data),
                             ptMsg->length, ptMsg->endPointIdx});

    status = VFIL_storeF1_UeContextModificationFailure(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationFailure ERROR !!\n");

    // TBD: ???
    // VCOM_SaHandoverCancel_ToConn(ptCi, ptUnpack->msgId);

    if (ptTarget->data.cellSelection.cellNum == ptCi->servCellNum )
        return ERROR; //call release if serving cell sends F1 failure

    ptTarget->handle.flag.release_in_progress = true;

    return GOOD;  // 25B IoDB: 
}  // }}}

int16_t FnVCCB_Ltm_Prep_Propagation_timF1_UeContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    if (DBG->flag.ltm_parallelOperation == FALSE)
    {
        VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, INIT_TIMER);
        ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromLtmAction(ptCi, ltm_PropIsOnging);
        if (ptTarget == NULL)
        {
            VCCB_PRINT_CALL_CRITICAL(ptCi, "[LTM][Prop] Can't find a candidate cell on TMOUT\n");
            return ERROR;
        }
        
        if (ptTarget->data.cellSelection.cellNum == ptCi->servCellNum)
        {
            MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutF1UeContextModification);
            return ERROR; // call release
        }

        ptTarget->handle.flag.release_in_progress = true; // need no more F1 signalling
        OFFBIT_U8(ptCi->ltmUeInfo.respFlag, ptTarget->handle.ltmCellIdx);
    }
    else
    {
        if (GET_F1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag)) 
        {
            // Pcell F1_UeContextModification timeout
            MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutF1UeContextModification);
            return ERROR; // call release
        }

        for (auto &rLtmCell : ptCi->ltmUeInfo.cellList)
        {
            if (rLtmCell.handle.usage == CI_no_use) continue;

            if (!GETBIT_U8(ptCi->ltmUeInfo.respFlag, rLtmCell.handle.ltmCellIdx)) continue;

            rLtmCell.handle.flag.release_in_progress = true;
        }

        ptCi->ltmUeInfo.respFlag = 0;
    }

    return GOOD;
}  // }}}


int16_t FnVCCB_Ltm_Prep_RRC_F1apUEContextModificationFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{

    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, CANCEL_TIMER);

    status = VFIL_storeF1_UeContextModificationFailure(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationFailure ERROR !!\n");

    FnVCCB_CollectLtmOutPrepF1Fail(*ptCi);

    return GOOD;
}  // }}}


int16_t FnVCCB_Ltm_Prep_RRC_F1apUEContextModificationResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);  // timNRRRC_RRCReconfig_id

    auto status = VFIL_storeF1_UeContextModificationResponse(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR_W_DETACH_TIMER(
        ptCi, status, &ptCi->timer, "VFIL_storeF1_UeContextModificationResponse ERROR !!\n");

    // release F1 Flag
    OFF_F1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);

    FnVCCB_LtmPrepConfigCommit(ptCi);

    return GOOD;
}  // }}}


int16_t FnVCCB_Ltm_Prep_RRC_NRRRC_RrcReconfigurationComplete(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);  // timNRRRC_RRCReconfig_id

    if (VRIL_storeNRRRC_RrcReconfigurationComplete(ptCi, ptUnpack) == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VRIL_storeNRRRC_RrcReconfigurationComplete ERROR!\n");
        return ERROR;
    }

    // to serving candidate cell
    auto *pLtmServingCell = FnVCCB_GetLtmCellInfoFromCGI(ptCi, ptCi->nRCGI);
    if (pLtmServingCell != nullptr)
    {
        HandleCurrentCandidateCellIndex currCandiCellIdxHandler(*ptCi, pLtmServingCell->handle.ltmCellIdx);
        auto status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
        if (status == ERROR)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_sendF1_UeContextModificationRequest ERROR !!\n");

            return ERROR;
        }
        // FnVCCB_LtmPrepConfigCommit(ptCi);
    }

    return GOOD;
}  // }}}

int16_t FnVCCB_Ltm_Prep_RRC_timNRRRC_RRCReconfig(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);  // timNRRRC_RRCReconfig_id

    FnVCCB_CollectLtmOutPrepRrcFail(*ptCi);
    
    return GOOD;
}  // }}}

// }}}

/****************************************************************************
                        Ltm_Exe
****************************************************************************/
// {{{

int16_t FnVCCB_triggerLtmCellSwitchPreparation(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    status = FnVCCB_NextStep_Ltm_Exe(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Ltm_Exe ERROR!\n");
    FnVCCB_InitLtmUeInfoForCellSwitch(ptCi);

    return GOOD;
}  // }}}

int16_t FnVCCB_Ltm_Exe_tim_CellSwitchPreparation(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, INIT_TIMER);

    VLIB_SetCurStateAll(ptCi, STATE_Conn); // LTM Cell Switch cancel. go to Conn state

    return GOOD;
}  // }}}

int16_t FnVCCB_triggerLtmExecution(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    // DB shall be updated before starting execution
    // ex. target cell info (c-rnti, du ue id, etc...)
    FnVCCB_UpdateCandidateCellInfoForLtmHoExec(*ptCi);

    ptCi->ltmUeInfo.cellSwitchFlag.e1StopIsRequired = true;

    status = FnVCCB_NextStep_Ltm_Complete(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_Ltm_Complete ERROR!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_Ltm_Exe(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VLIB_SetCurStateAll(ptCi, STATE_Ltm_Exe);

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_Ltm_Exe_E1Stop(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    VLIB_SetCurStateAll(ptCi, STATE_Ltm_Exe_E1Stop);

    status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

    VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextModification_id);

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_Ltm_Exe_TgtUp(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    VLIB_SetCurStateAll(ptCi, STATE_Ltm_Exe_TgtUp);

    status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

    VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextModification_id);

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_Ltm_Complete(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    VLIB_SetCurStateAll(ptCi, STATE_Ltm_Complete);

    if (ptCi->ltmUeInfo.cellSwitchFlag.f1DuCuCellSwitchNotiReceived) // If CU receives the DU-CU Cell Switch Notification,
    {
        // Sends CU-DU Cell Switch Notification
        status = VFIL_sendF1_CUDUCellSwitchNotification(ptCi, {ptCi->hoInfo.targetDu.duUEid, ptCi->hoInfo.targetDu.f1Idx});
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

        // TODO: Need to wait Access Success
        ON_F1_ACCESS_SUCCESS_FLAG(ptCi->flag.respFlag);
        ON_RRC_RECONFIG_FLAG(ptCi->flag.respFlag);

        OFF_RRC_CONNECTION_FLAG(ptCi->flag.setupFlag); // will be turn on again when RRC Recfg complete received

        auto *ptTarget = FnVCCB_GetLtmCellInfoFromCGI(ptCi, ptCi->hoInfo.cgi);

        if (ptTarget == nullptr)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[LTM] There is no target CGI for LTM Candidate Cells\n");
            return ERROR;
        }

        FnVCCB_StatLtmOut(*ptCi, *ptTarget, LTM_ExeNotify);

        // TODO: make it as function
        status = FnVCCB_LtmExecUpHandler(ptCi, F1_DUCUCellSwitchNotification_id); 
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_LtmExecUpHandler ERROR!\n");
    }
    
    //TBD : for future. L1 MR support, RRE ...
    {
        // From DU
        if (ptCi->ltmUeInfo.cellSwitchFlag.f1AccessSuccessReceived) // [TBD] don't set flag when vccb already receives the access success during E1 Stop state
        {   
            ON_RRC_RECONFIG_FLAG(ptCi->flag.respFlag);
        }

        // From UE
        if (ptCi->ltmUeInfo.cellSwitchFlag.rrcCompleteReceived) // [TBD] don't set flag when vccb already receives the rrc completet during E1 Stop state
        {
            ON_F1_ACCESS_SUCCESS_FLAG(ptCi->flag.respFlag);
        }
    }

    // TODO: if response flag is off, what is the acition??
    if (0)
    {
    }
    else
    {
        // [TODO] Timer??
    }

    return GOOD;
}  // }}}

int16_t FnVCCB_Ltm_Complete_tim_CellSwitch(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, INIT_TIMER);
    FnVCCB_CollectLtmOutExe(*ptCi, LTM_ExeFail_RrcFail);

    return GOOD;
}  // }}}

/****************************************************************************
 * @brief           Handling F1AP AccessSuccess in state STATE_Ltm_Complete
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t FnVCCB_Ltm_Complete_F1_AccessSuccess(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status;
    cgi_type cgi;

    status = VFIL_storeF1_AccessSuccess(ptCi, ptAll, ptUnpack, &cgi);

    if (status == ERROR)
    {
        FnVCCB_CollectLtmOutExe(*ptCi, LTM_ExeFail_CUFail);
    }

    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_AccessSuccess ERROR!\n");

    VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "Multi Target Execution CGI(%X-%llu) in F1_AccessSuccess\n", cgi.plmn.longId, cgi.ci * 1LLU);

    OFF_F1_ACCESS_SUCCESS_FLAG(ptCi->flag.respFlag);

    ptCi->ltmUeInfo.cellSwitchFlag.f1AccessSuccessReceived = true;

    if (ptCi->ltmUeInfo.cellSwitchFlag.rrcCompleteReceived)
    {
        VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, CANCEL_TIMER);
    }
    else 
    {
        VLIB_SAHandoverTime(ptCi, CAL_STOP);
    }

    // TODO: make it as function
    status = FnVCCB_LtmExecUpHandler(ptCi, F1_AccessSuccess_id); 
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_LtmExecUpHandler ERROR!\n");

    return GOOD;
}  // }}}

/****************************************************************************
 * @brief           Handling E1AP BearerContextModifyXXX in state STATE_Ltm_Complete
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t FnVCCB_Ltm_Complete_E1_BearerContext(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status = GOOD;

    status = FnVCCB_StoreE1Message(ptUnpack->msgId, ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_NBREAK(ptCi, status, "StoreE1Message(%d) waiting for other UPs to respond.\n", ptUnpack->msgId);
    VCCB_PRINT_WITHOUT_RETURN_ON_CALL_ERROR(ptCi, status, "StoreE1Message(%d) ERROR!\n", ptUnpack->msgId);

    if (status == ERROR)
    {
        FnVCCB_CollectLtmOutExe(*ptCi, LTM_ExeFail_CUFail);
    }
    // TODO: need to check the multi UP action??

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, CANCEL_TIMER);

    multiUpFunctionParameter_type upParm;
    memset(&upParm, 0x00, sizeof(upParm));
    upParm.successFunction = VCCM_HO_Common_E1_BearerContextModificationSuccess;
    upParm.strSuccessFunction = "VCCM_HO_Common_E1_BearerContextModificationSuccess";
    upParm.unSuccessFunction = VCCM_HO_Common_BearerContextModificationUnsuccess;

    if (ERROR == FnVCCB_MultiUpProcessing(ptCi, ptUnpack, status, &upParm, __func__))
    {
        FnVCCB_CollectLtmOutExe(*ptCi, LTM_ExeFail_E1Fail);
        return ERROR;
    }

    status = FnVCCB_LtmExecUpHandler(ptCi, ptUnpack->msgId); 
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_LtmExecUpHandler ERROR!\n");

    return GOOD;
}  // }}}

/****************************************************************************
 * @brief           Handling NR-RRC Reconfiguration Complete in state STATE_Ltm_Complete
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t FnVCCB_Ltm_Complete_NRRRC_RrcReconfigurationComplete(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status = GOOD;

    // TODO: which timerid db is used??
    // VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);
    if (VRIL_storeNRRRC_RrcReconfigurationComplete(ptCi, ptUnpack) == ERROR)
    {
        FnVCCB_CollectLtmOutExe(*ptCi, LTM_ExeFail_CUFail);
        VCCB_PRINT_CALL_ERROR(ptCi, "VRIL_storeNRRRC_RrcReconfigurationComplete ERROR!\n");
        return ERROR;
    }

    // need to send the complete ind to DU after receiving all response messages.
    ptCi->ltmUeInfo.cellSwitchFlag.rrcCompleteReceived = true;
    
    if (ptCi->ltmUeInfo.cellSwitchFlag.f1AccessSuccessReceived)
    {
        VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, CANCEL_TIMER);
    }
    else
    {
        VLIB_SAHandoverTime(ptCi, CAL_STOP);
    }

    OFF_RRC_RECONFIG_FLAG(ptCi->flag.respFlag);

    // TODO: make it as function
    status = FnVCCB_LtmExecUpHandler(ptCi, NRRRC_RrcReconfigurationComplete_id);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_LtmExecUpHandler ERROR!\n");

    return GOOD;
}  // }}}

/****************************************************************************
 * @brief           Handling NR-RRC TMOOUT of Reconfiguration Complete in state STATE_Ltm_Complete
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t FnVCCB_Ltm_Complete_timNRRRC_RRCReconfig(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    // TODO: which timerid db is used??
    // VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);  // timNRRRC_RRCReconfig_id

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : FnVCCB_Ltm_Exe_timE1_BearerContext
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t FnVCCB_Ltm_Exe_timE1_BearerContext(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    // VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.spec, CANCEL_TIMER);  // Ng/Xn-Reloc-Overall
    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.e1, INIT_TIMER);

    // VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_UpFail);
    // VHCM_SA_HO_STAT(ptCi, HO_Fail_E1TimeOut);
    // CHO_STAT(ptCi, CHO_ExeFail_E1Fail, ptCi->hoInfo.cgi);

    // CALL FAULT (There is no CRR for timE1_BearerContextRelease_id, use togother or not?
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    FnVCCB_CollectLtmOutExe(*ptCi, LTM_ExeFail_E1Fail);

    return GOOD;
}  // }}}

int16_t FnVCCB_NextStep_Ltm_Complete_F1Mod(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    VLIB_SetCurStateAll(ptCi, STATE_Ltm_Complete_F1Mod);

    status = FnVCCB_Send_Ltm_ReconfigCompleteIndicator(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_Send_Ltm_ReconfigCompleteIndicator ERROR!\n");
    return status;
}

/****************************************************************
 * *  Function     : FnVCCB_Ltm__F1_UEContextModificationResponse
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t FnVCCB_Ltm_Complete_F1_UEContextModificationResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status;

    // [TODO] Timer, flag and which cell resource shall be handled

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, CANCEL_TIMER);

    const F1_UEContextModificationResponse *pResp = ptUnpackConvert<F1_UEContextModificationResponse>(ptUnpack);
    const F1_GNB_DU_UE_F1AP_ID *pGNB_DU_UE_F1AP_ID = NULL;

    // gNB-DU UE F1AP ID - MANDATORY
    if (ERROR == VFIL_GetF1IE(reinterpret_cast<const void **>(&pGNB_DU_UE_F1AP_ID), pResp->protocolIEs, F1_id_gNB_DU_UE_F1AP_ID))
    {
        return ERROR;
    }
    SctpDataType *ptMsg = reinterpret_cast<SctpDataType *>(ptAll);
    ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromDuInfo(*ptCi, ptMsg->endPointIdx, *pGNB_DU_UE_F1AP_ID);
    if (ptTarget == NULL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[LTM] Can't find LTM candidate cell!!\n");
        return ERROR;
    }
    HandleCurrentCandidateCellIndex currCandiCellIdxHandler(*ptCi, ptTarget->handle.ltmCellIdx);

    VLIB_collectTraceMessage(ptCi, (TraceParam){RX_MSG, F1_UEContextModificationResponse_id, reinterpret_cast<char *>(ptMsg->data),
                            ptMsg->length, ptMsg->endPointIdx});

    status = VFIL_storeF1_UeContextModificationResponse(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationResponse ERROR !!\n");

    return GOOD;
}  // }}}

int16_t FnVCCB_Ltm_Complete_F1_UEContextModificationFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{

    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, CANCEL_TIMER);

    status = VFIL_storeF1_UeContextModificationFailure(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationFailure ERROR !!\n");
 
    FnVCCB_CollectLtmOutExe(*ptCi, LTM_ExeFail_F1Fail);

    return GOOD;
}  // }}}

/****************************************************************
 * *  Function     : FnVCCB_Ltm__timF1_UeContextModification
 * *  Description  :
 * *  Procedures defined :
 * *  Procedures called  :
 * *  Procedure calling  :
 * *  Input  : callInfo_type**, message_type*, msgUnpack_type*
 * *  Output : int
 * *  Statistics Pegged :
 * ***************************************************************/
int16_t FnVCCB_Ltm_timF1_UeContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->hoInfo.timer.f1, INIT_TIMER);

    FnVCCB_CollectLtmOutExe(*ptCi, LTM_ExeFail_F1Fail);

    return GOOD;
}  // }}}

AllowedStatus FnVCCB_MrdcMobilityProc_Inter_PartialCheck(callInfo_type &rCall, enumMrdcHoScenario_type type)
{
    if (FnVCCB_IsAnyPartialDrbQosPdu(rCall) == Allowed) return Allowed;

    if (not FnVCCB_IsPartialHoAllowEnabled(rCall)) return Not_Allowed;

    if (type != MrdcHoWithSnChange) return Not_Allowed;

    for (auto drbIdx = 0; drbIdx < MAX_DRB_PER_UE; drbIdx++)
    {
        callDRBInfo_type &refDrb = rCall.drb[drbIdx];

        if (!IS_VALID_NODE(DRB_NODE, &rCall, &refDrb)) continue;

        int reqBearerType = static_cast<int>(FnVCCB_getSaDrbBearerType(&rCall, &refDrb, request_bearerType));

        /* If a DRB with bearer type other than MN MCG fails, it must transition to HO that releases SN */
        if (reqBearerType == MN_Term_MCG_Bearer) continue;

        if (VLIB_IsCommonValidStateOfPduQosDrb(refDrb.drbStatus) == ERROR)
        {
            VCCB_PRINT_CALL_INFORMATIVE(&rCall, "Not Allowed : Detect partial DRB (drb:%d/bearerType:%s))\n",
                rCall.drb[drbIdx].dRBId, FnVCCB_GetStrBearerType(reqBearerType));
            return Not_Allowed;
        }
    }

    return Allowed;
}

int16_t VCCM_INTER_Pre_SN_T_XN_SNodeAdditionRequestAcknowledge_RearrangePduQosDrbForPartial(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);

    /*
        In 25B, SN partial is processed only per-DRB (refer to FGR-CC5200)
        MN can recognize SN failed DRB by "GET_MRDC_EVENT_FLAG(ptDi->mrdcFlag.drbEventFlag, scgDrbFail)"
    */

    auto processDrb = [](callInfo_type *_ptCi, callPDUSessInfo_type *_ptPi) {
        for (auto drbIdxInCall : _ptPi->drbIndex)
        {
            if (drbIdxInCall >= MAX_DRB_PER_SA_CALL) continue;

            auto ptDi = &_ptCi->drb[drbIdxInCall];
            if (ptDi->usage != CI_use) continue;
            if (!IS_VALID_NODE(DRB_NODE, _ptCi, ptDi)) continue;
            if (!GET_MRDC_EVENT_FLAG(ptDi->mrdcFlag.drbEventFlag, scgDrbFail)) continue;

            if (ptDi->failCause == CAUSE_NO_FAULT)
                ptDi->failCause = CauseXnapRadioNetworkLayerUnspecified;

            SET_DRB_STATUS(_ptCi, drbIdxInCall, S_FailToSetup);
            ONBIT_U32(_ptCi->drbIdsToRelease, ptDi->dRBId - 1);
            ptDi->needToReconfigE1BySnFail = (ptDi->reqBearerType.val == MN_Term_SPLIT_Bearer) ? TRUE : FALSE;

            for (auto qosIdxInCall : ptDi->qosFlowIndex)
            {
                if (qosIdxInCall >= MAX_QOS_FLOW_PER_CALL) continue;

                auto ptQi = &_ptCi->qosFlow[qosIdxInCall];
                if (ptQi->usage != CI_use) continue;
                if (!IS_VALID_NODE(QOSFLOW_NODE, _ptCi, ptQi)) continue;
                if (VLIB_IsCommonValidStateOfPduQosDrb(ptQi->qosFlowStatus) != GOOD) continue;

                if (ptQi->failCause == CAUSE_NO_FAULT)
                    ptQi->failCause = CauseXnapRadioNetworkLayerUnspecified;

                SET_QOSFLOW_STATUS(_ptCi, qosIdxInCall, S_FailToSetup);
            }
        }
    };
    
    auto checkAndSetPduStatus = [](callInfo_type *_ptCi, callPDUSessInfo_type *_ptPi, uint16_t _pduIdxInCall) {
        auto drbIdxInPdu = 0;
        for (; drbIdxInPdu < MAX_DRB_PER_PDU_SESS; drbIdxInPdu++)
        {
            auto drbIdxInCall = _ptPi->drbIndex[drbIdxInPdu];
            if (drbIdxInCall >= MAX_DRB_PER_SA_CALL) continue;

            auto ptDi = &_ptCi->drb[drbIdxInCall];
            if (ptDi->usage != CI_use) continue;
            if (!IS_VALID_NODE(DRB_NODE, _ptCi, ptDi)) continue;
    
            if (VLIB_IsCommonValidStateOfPduQosDrb(ptDi->drbStatus) == GOOD) break;
        }
    
        if (drbIdxInPdu == MAX_DRB_PER_PDU_SESS)
        {
            _ptPi->failCause = CauseXnapRadioNetworkLayerUnspecified;
            SET_PDU_STATUS(_ptCi, _pduIdxInCall, S_FailToSetup);
        }
    };
    
    for (uint16_t pduIdxInCall = 0; pduIdxInCall < MAX_PDU_SESS_PER_CALL; pduIdxInCall++)
    {
        callPDUSessInfo_type *ptPi = &ptCi->pduSess[pduIdxInCall];
        if (!IS_VALID_NODE(PDU_NODE, ptCi, ptPi)) continue;
        if (VLIB_IsCommonValidStateOfPduQosDrb(ptPi->pduSessStatus) != GOOD) continue;

        processDrb(ptCi, ptPi);
        checkAndSetPduStatus(ptCi, ptPi, pduIdxInCall);
    }

    return GOOD;
}

// }}}

/****************************************************************************
                        TBD...
****************************************************************************/
