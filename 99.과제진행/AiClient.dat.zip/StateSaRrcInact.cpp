/**
 * @file StateSaRrcInact.cpp
 * @brief Received message handler for Inact state
 *
 * State flows
 *   1) RRC Suspend
 *     Conn -> Inact_F1ModQuery -> Inact_E1Mod_Suspend -> Inact_Suspend
 *
 *   2) RRC Resume
 *     <Intra-gNB>
 *       Inact_Suspend -> (Inact_ResumeReq) -> Inact_F1Setup -> Inact_ResumeCmpl -> Inact_F1Mod -> Inact_E1Mod_Pdcp -
 * Conn <Inter-gNB> Source : Inact_Suspend -> (Inact_ResumeReq) -> Inact_S_E1Mod_TxStop -> Inact_S_XnUAdrInd ->
 * Inact_S_E1Mod_XnTeId -> Inact_S_XnUeContextRel -> Call Release Target : Inact_T_XnUeContextReq -> Inact_T_E1Setup ->
 * Inact_F1Setup -> Inact_T_E1Mod -> Inact_ResumeCmpl -> Inact_F1Mod -> Inact_E1Mod_Pdcp -> Inact_T_NgPathSwitch ->
 * Inact_T_E1Mod_N3TeId -> Conn
 *
 *   3) RNA Update
 *     <Intra-gNB>
 *       Inact_Suspend
 *     <Inter-gNB>
 *       Source : Inact_Suspend -> Inact_S_E1Mod_TxStop -> Inact_S_XnUAdrInd -> Inact_S_E1Mod_XnTeId ->
 * Inact_S_XnUeContextRel -> Call Release Target : Inact_T_XnUeContextReq -> Inact_T_E1Setup -> Inact_T_E1Mod ->
 * Inact_E1Mod_Pdcp -> Inact_T_NgPathSwitch -> Inact_T_E1Mod_N3TeId -> Inact_Suspend
 *
 */

#include "ComInclude.h"
#include "StateSaRrcInact.h"
#include "MainCallTask.h"

#include "StateCommon.h"
#include "StateHandleAll.h"
#include "StateHandleSa.h"
#include "StateMeasurements.h"
#include "StateMco.h"

#include "ComLibUtility.h"
#include "ComLibStatistic.h"

#include "FeatCommon.h"
#include "FeatCa.hpp"
#include "FeatHoCommon.h"
#include "FeatRrcInactive.h"
#include "FeatRre.h"
#include "FeatSon.h"
#include "FeatLb.hpp"
#include "FeatMco.h"
#include "FeatMobility.h"
#include "FeatMfbi.h"
#include "FeatMrdc.h"
#include "FeatTrace.h"
#include "FeatTrace.hpp"
#include "FeatCallInfo.h"
#include "FeatCallProc.h"
#include "FeatSecurity.h"
#include "FeatFullConfig.h"
#include "FeatCapaHandling.h"
#include "FeatMeasurements.hpp"
#include "UplinkStatusTriggeredMobility.hpp"
#include "FeatCaCsl.hpp"
#include "IRNTIManager.h"
#include "MsgQueueManager.h"
#include "RscCall.h"
#include "VccbAiClient.h"

#include "MsgXnapSend.h"
#include "MsgXnapStore.h"
#include "MsgNgapStore.h"
#include "MsgNgapSend.h"
#include "MsgE1apSend.h"
#include "MsgE1apStore.hpp"
#include "MsgF1apSend.h"
#include "MsgF1apStore.h"
#include "MsgNrRrcStore.h"
#include "MsgNrRrcSend.h"
#include "MsgNmbSend.h"
#include "MsgTmbSend.h"

#include "f1apUnpack.h"
#include "xnapUnpackMsg.h"

/**
 * @brief Handle F1UeContextModificationResponse in Inact_F1ModQuery
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_F1ModQuery_F1UeContextModificationResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    int16_t status = VFIL_storeF1_UeContextModificationResponse(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_storeF1_UeContextModificationResponse ERROR!\n");

    // Bearer Context Status Change: Suspend, User Inactivity Timer Setting
    status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

    VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);
    VLIB_SetCurStateAll(ptCi, STATE_Inact_E1Mod_Suspend);

    return GOOD;
}

/**
 * @brief Handle F1UeContextModificationFailure in Inact_F1ModQuery
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_F1ModQuery_F1UeContextModificationFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    VCCB_RETURN_ON_CALL_ERROR(ptCi, VFIL_storeF1_UeContextModificationFailure(ptCi, ptAll, ptUnpack),
        "VFIL_storeF1_UeContextModificationFailure ERROR!\n");

    return GOOD;
}

/**
 * @brief Handle timF1_UeContextModification in Inact_F1ModQuery
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_F1ModQuery_timF1_UeContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, timF1_UeContextModification_id, sizeof(messageHdr_type), reinterpret_cast<uint8_t *>(ptAll));

    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutF1UeContextModification);

    MACRO_STAT_PMCC(STAT_F1AP_CU_INIT_UE_MOD_CU, CU_F1CuInitUeModFail_DUTimeout, ptCi, 0, 0, 0, 0, 0);
    VLIB_SetNoAttemptFlag(ptCi, STAT_F1AP_CU_INIT_UE_MOD_CU);

    return GOOD;
}

int16_t FnVCCB_Inact_E1Mod_Suspend_E1BearerContextModificationSuccess(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    int16_t status = IRNTIManager::getInstance().makeIRNTI(ptCi);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "makeIRNTI ERROR!\n");
        MACRO_CALL_FAULT_SAVE(E1_BearerContextModificationResponse_id, CauseCpInternalSaResumeProcedureNotAvailable);
        if (VCCB_CALL_RELEASE_TRIGGER(ptCi) != GOOD)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_CALL_RELEASE_TRIGGER ERROR!\n");
            VLIB_PutCi(ptCi);
        }
        return GOOD;
    }

    // Ciphering and Integration Protection for SA (FGR-BC0323)
    VLIB_updateSuspendedCellInfo(ptCi);

    status = FnVCCB_SendF1_UeContextReleaseCommand_RRCRelease(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendF1_UeContextReleaseCommand_RRCRelease ERROR!\n");
    OFF_F1_REL_COMPLT_RCV_FLAG(ptCi->flag.respFlag);

    // Update sKgNB with NH and NCC with newNCC
    if ((FALSE == ptCi->security.newSecurityContextChangeInd) && (ptCi->security.newNCC != ptCi->security.nCC))
    {
        memcpy(ptCi->security.sKgNB, ptCi->security.nextHop, KEY_VNB_LENGTH);
        ptCi->security.nCC = ptCi->security.newNCC;
    }

    // Clear the flags for the data incoming notification: (for RAN-Paging feature FR250.2)
    ptCi->ranPagingInfo.dlDataFlag = VCCB_FLAG_OFF;
    ptCi->ranPagingInfo.pagingTriggeredByDLNasTransportFlag = VCCB_FLAG_OFF;

    ptCi->ueInfo.RrcInactiveInfo.ranPagingTxCount = 0;  // init

    status = FnVCCB_FinalizeRRCSuspend(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_FinalizeRRCSuspend ERROR!\n");

    return GOOD;
}

void FnVCCB_Inact_E1Mod_Suspend_E1BearerContextModificationUnsuccess(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);
    MACRO_CALL_FAULT_SAVE(E1_BearerContextModificationFailure_id, ptCi->cause.e1Cause);
}

int16_t FnVCCB_Inact_E1Mod_Suspend_timE1_BearerContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);
    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, ptUnpack->msgId, sizeof(messageHdr_type), reinterpret_cast<uint8_t *>(ptAll));
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    return GOOD;
}

/**
 * @brief Check enqueued action and message in Inact_Suspend that can trigger RAN Paging procedure
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_Suspend_CheckEnqueuedAction(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    message_type *ptAll = reinterpret_cast<message_type*>(&THREAD_INFO->call[ptCi->myThreadId].buf.rx);    
    msgUnpack_type *ptUnpack = &THREAD_INFO->call[ptCi->myThreadId].buf.unpack.call.buff;

    int16_t status = GOOD;
    int16_t actionIndex = 0;
    uint64_t actionBitFlag = 0;

    // in case NAS-PDU including message is enqueued, trigger RAN-Paging
    actionBitFlag |= 1 << ENQUEUE_ACTION_PDU_SESSION;
    actionBitFlag |= 1 << ENQUEUE_ACTION_NGUECTX_MOD_REQ;
    actionBitFlag |= 1 << ENQUEUE_ACTION_DOWNLINK_NAS_TRANSPORT;

    actionIndex = FnVCCB_FindActionQueueIndex(ptCi, actionBitFlag);

    if (actionIndex < 0)  // not found
    {
        return GOOD;
    }

    // get first msg from the msg queue, which has actionInQueue
    // actual dequeue will be done after the paging procedure
    status = MsgQueueManager::getInstance().getEnqueuedMsgWithAction(*ptCi, *ptAll, ptCi->actionQueue[actionIndex]);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "getEnqueuedMsgWithAction ERROR!!\n");

    status = VCCB_GetMsgUnpack_checkMsgId(ptAll, ptUnpack, ptCi->myThreadId);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_GetMsgUnpack_checkMsgId ERROR!!\n");

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "%s: enqueued %s triggered paging\n", __FUNCTION__, strMsgId(ptUnpack->msgId));

    if (NG_UEContextModificationRequestAmfAll_id == ptUnpack->msgId)
    {
        ptCi->ranPagingInfo.ngUeContextModFromQueue = TRUE;
    }

    status = FnVCCB_Inact_Suspend(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_Inact_Suspend ERROR!!\n");

    // if there's no NAS-PDU including message in the queue,
    // wait for the messages that would trigger RAN-Paging in Inact_Suspend state.

    return GOOD;
}

/**
 * @brief Handle E1DLDataNotification in Inact_Suspend
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_Suspend_E1DLDataNotification(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->ueInfo.RrcInactiveInfo.guardTimer, CANCEL_TIMER);

    if (ERROR == FnVCCB_StoreE1Message(E1_DLDataNotification_id, ptCi, ptAll,
                     ptUnpack))  // regardless of the result, RAN paging should be sent
    {
        MACRO_RESET_CALL_FAULT_CAUSES;
    }

    ptCi->ranPagingInfo.dlDataFlag = VCCB_FLAG_ON;

    VCCB_RETURN_ON_CALL_ERROR(ptCi, FnVCCB_SendCallPagingReq(ptCi, procDedicated), "FnVCCB_SendCallPagingReq ERROR!\n");

    // timer to wait RRC Resume Request1 over UL-CCCH1
    VLIB_AttachTimer(&ptCi->timer, ptCi, timNRRRC_RRCResumeRequest1_id);
    VLIB_SetCurStateAll(ptCi, STATE_Inact_ResumeReq);

    return GOOD;
}

void FnVCCB_Inact_Suspend_F1UeContextReleaseComplete(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_VOID(ptCi, ptAll, ptUnpack);

    SctpDataType *ptMsg = reinterpret_cast<SctpDataType *>(ptAll);
    logShmExtMsg(ptCi, RX_MSG, F1_UEContextReleaseComplete_id, reinterpret_cast<uint8_t *>(ptMsg), ptCi->auCallId);

    return;
}

/**
 * @brief Handle NgapDownlinkNASTransport in Inact_Suspend
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_Suspend_NgapDownlinkNASTransport(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->ueInfo.RrcInactiveInfo.guardTimer, CANCEL_TIMER);

    /* store ppi for sending ran paging msg */
    FnVCCB_ALL_NgapStorePPI(ptCi, reinterpret_cast<NG_DownlinkNASTransportAmfAll_type *>(ptUnpack->unpack));

    VCCB_RETURN_ON_CALL_ERROR(ptCi, FnVCCB_SendCallPagingReq(ptCi, procDedicated), "FnVCCB_SendCallPagingReq ERROR!\n");

    ptCi->ranPagingInfo.dlDataFlag = VCCB_FLAG_ON;
    ptCi->ranPagingInfo.pagingTriggeredByDLNasTransportFlag = VCCB_FLAG_ON;

    // timer to wait RRC Resume Request1 over UL-CCCH1
    VLIB_AttachTimer(&ptCi->timer, ptCi, timNRRRC_RRCResumeRequest1_id);
    VLIB_SetCurStateAll(ptCi, STATE_Inact_ResumeReq);

    return GOOD;
}

/**
 * @brief Handle NgapUEContextModificationRequest in Inact_Suspend
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_Suspend_NgapUEContextModificationRequest(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->ueInfo.RrcInactiveInfo.guardTimer, CANCEL_TIMER);

    // SVR22B FGR-CC0103
    int16_t status = FnVCCB_Inact_Suspend_ProcRrcInactiveTransitionReport(ptCi, ptAll, ptUnpack);
    if (status != GOOD)
    {
        // check if returns ERROR here, call would be released..
        return (status == BREAK) ? ERROR : GOOD;
    }

    /* store ppi for sending ran paging msg */
    FnVCCB_ALL_NgapStorePPI(ptCi, reinterpret_cast<NG_UEContextModificationRequestAmfAll_type *>(ptUnpack->unpack));

    VCCB_RETURN_ON_CALL_ERROR(ptCi, FnVCCB_SendCallPagingReq(ptCi, procDedicated), "FnVCCB_SendCallPagingReq ERROR!\n");

    ptCi->ranPagingInfo.dlDataFlag = VCCB_FLAG_ON;

    if (!ptCi->ranPagingInfo.ngUeContextModFromQueue)
    {
        SctpDataTransfer_type *ptSctp = reinterpret_cast<SctpDataTransfer_type *>(ptAll);

        uint32_t PeerApUeId =
            static_cast<uint32_t>(reinterpret_cast<uintptr_t>((((NG_UEContextModificationRequestAmfAll_type *)ptUnpack->unpack)->aMF_UE_NGAP_ID)));

        logShmExtMsg(ptCi, RX_MSG, ptUnpack->msgId, reinterpret_cast<uint8_t *>(ptSctp), PeerApUeId);

        status = VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_NGUECTX_MOD_REQ, ptAll, ptUnpack->msgId);

        if (status == ERROR)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                "QUEUEING @FnVCCB_Inact_Suspend_NgapUEContextModificationRequest(%s) fail !!\n",
                strMsgId(ptUnpack->msgId));
            // will be handled as e_RejectOrFailureAction

            ptCi->cause.ngCause = CauseNgapRadioNetworkLayerInteractionWithOtherProcedure;

            // send the failure message
            auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_UEContextModificationFailureAllAmf_id);
            VALID_E_POINT_CHECK_ERROR(ngapSender);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, ngapSender->sendMsg(), "sendMsg(NG_UEContextModificationFailureAllAmf) ERROR!\n");
        }
    }

    ptCi->ranPagingInfo.ngUeContextModFromQueue = FALSE;

    // timer to wait RRC Resume Request1 over UL-CCCH1
    VLIB_AttachTimer(&ptCi->timer, ptCi, timNRRRC_RRCResumeRequest1_id);
    VLIB_SetCurStateAll(ptCi, STATE_Inact_ResumeReq);

    return GOOD;
}

/**
 * @brief Handle NgapLocationReportingControl in Inact_Suspend
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_Suspend_NgapLocationReportingControl(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    // msg is already stored in ALL state

    if (ci_5g_Rpt_direct == ptCi->locRpt.eventType)
    {
        VCCB_CLEAR_TIMER(&ptCi->ueInfo.RrcInactiveInfo.guardTimer, CANCEL_TIMER);

        ptCi->ueInfo.RrcInactiveInfo.ppi = 0xFF;  // PagingPriority is not included in this msg

        VCCB_RETURN_ON_CALL_ERROR(
            ptCi, FnVCCB_SendCallPagingReq(ptCi, procDedicated), "FnVCCB_SendCallPagingReq ERROR!\n");

        ptCi->ranPagingInfo.dlDataFlag = VCCB_FLAG_ON;

        ptCi->locRpt.isPagingReqForInactivity = TRUE;

        // timer to wait RRC Resume Request1 over UL-CCCH1
        VLIB_AttachTimer(&ptCi->timer, ptCi, timNRRRC_RRCResumeRequest1_id);
        VLIB_SetCurStateAll(ptCi, STATE_Inact_ResumeReq);
    }
    else
    {
        if ((ptCi->locRpt.eventType == ci_5g_Rpt_stop_change_of_serve_cell) ||
            (ptCi->locRpt.eventType == ci_5g_Rpt_stop_UE_in_AoI) || (ptCi->locRpt.eventType == ci_5g_Rpt_cancel))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Unexpected event type received !!\n");
        }
        else  // change_of_serve_cell or AOI
        {
            if (ptCi->locRpt.reportOn == CI_use)
            {
                auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_LocationReportAllAmf_id);
                VALID_E_POINT_CHECK_ERROR(ngapSender);
                if (ngapSender->sendMsg() == ERROR)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "sendMsg(NG_LocationReportAllAmf) ERROR !!\n");
                    return ERROR;
                }
            }
        }
        ptCi->locRpt.reportOn = CI_no_use;
    }
    return GOOD;
}

/**
 * @brief Handle NgapPDUSessionResource in Inact_Suspend
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_Suspend_NgapPDUSessionResource(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->ueInfo.RrcInactiveInfo.guardTimer, CANCEL_TIMER);

    /* store ppi for sending ran paging msg */
    switch (ptUnpack->msgId)
    {
        case NG_PDUSessionResourceSetupRequest_id:
            FnVCCB_ALL_NgapStorePPI(ptCi, reinterpret_cast<NG_PDUSessionSetupRequest_type *>(ptUnpack->unpack));
            break;
        case NG_PDUSessionResourceModifyRequest_id:
            FnVCCB_ALL_NgapStorePPI(ptCi, reinterpret_cast<NG_PDUSessionModifyRequest_type *>(ptUnpack->unpack));
            break;
        case NG_PDUSessionResourceReleaseCommand_id:
            FnVCCB_ALL_NgapStorePPI(ptCi, reinterpret_cast<NG_PDUSessionReleaseCommand_type *>(ptUnpack->unpack));
            break;
        default:
            return BREAK;
    }

    VCCB_RETURN_ON_CALL_ERROR(ptCi, FnVCCB_SendCallPagingReq(ptCi, procDedicated), "FnVCCB_SendCallPagingReq ERROR!\n");

    ptCi->ranPagingInfo.dlDataFlag = VCCB_FLAG_ON;
    ptCi->ueInfo.rrcResumeInfo.goingToRRCIdleFlag = VCCB_FLAG_OFF;

    // timer to wait RRC Resume Request1 over UL-CCCH1
    VLIB_AttachTimer(&ptCi->timer, ptCi, timNRRRC_RRCResumeRequest1_id);
    VLIB_SetCurStateAll(ptCi, STATE_Inact_ResumeReq);

    return GOOD;
}

/**
 * @brief Handle CallResumeInd in Inact_Suspend
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_Suspend_CallResumeInd(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->ueInfo.RrcInactiveInfo.guardTimer, CANCEL_TIMER);

    int16_t status;
    msgCallSetupReq_type *ptMsg = reinterpret_cast<msgCallSetupReq_type *>(ptAll);

    switch (ptMsg->interface)
    {
        case interface_f1:
            status = FnVCCB_Inact_ProcRRCResumeRequest1(ptCi, ptAll, ptUnpack);
            if (status == ERROR)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[RRCInactive] Fallback to RRCSetup\n");
                MACRO_RESET_CALL_FAULT_CAUSES;

                FnVCCB_CommonActionforRRCSetupOrRelease(*ptCi, eRrcSetup, ptMsg->hdr.src.contextId);
            }
            break;

        case interface_xn:
            status = FnVCCB_Inact_ProcXnRetrieveUEContextRequest(ptCi, ptAll, ptUnpack);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_Inact_ProcXnRetrieveUEContextRequest ERROR\n");
            break;

        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid interface(%d) in %s\n", ptMsg->interface, __FUNCTION__);
            return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Handling NgDownlinkUEAssociatedNRPPaTransport in Inact_Suspend state
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t FnVCCB_Inact_Suspend_NgapDownlinkUEAssociatedNRPPaTransport(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->ueInfo.RrcInactiveInfo.guardTimer, CANCEL_TIMER);

    VCCB_RETURN_ON_CALL_ERROR(ptCi, FnVCCB_SendCallPagingReq(ptCi, procDedicated), "FnVCCB_SendCallPagingReq ERROR!\n");

    ptCi->NrPpaContext.isPagingRequiredForECID = TRUE;
    ptCi->ranPagingInfo.dlDataFlag = VCCB_FLAG_ON;

    // timer to wait RRC Resume Request1 over UL-CCCH1
    VLIB_AttachTimer(&ptCi->timer, ptCi, timNRRRC_RRCResumeRequest1_id);
    VLIB_SetCurStateAll(ptCi, STATE_Inact_ResumeReq);

    return GOOD;
}

/****************************************************************************
 * @brief           Handling timNRRRC_RNAUpdate_id in Inact_Suspend state
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptAll : Whole received message / message_type
 * @param[in]       ptUnpack : Unpacked message / msgUnpack_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t FnVCCB_Inact_Suspend_timRNAUpdate(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->ueInfo.RrcInactiveInfo.guardTimer, INIT_TIMER);

    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, timNRRRC_RNAUpdate_id, sizeof(messageHdr_type), reinterpret_cast<uint8_t *>(ptAll));
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaTmOutPeriodicRNAU);

    return GOOD;
}

/**
 * @brief Handle CallResumeInd in Inact_ResumeReq
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_ResumeReq_CallResumeInd(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status;
    msgCallSetupReq_type *ptMsg = reinterpret_cast<msgCallSetupReq_type *>(ptAll);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    switch (ptMsg->interface)
    {
        case interface_f1:
            status = FnVCCB_Inact_ProcRRCResumeRequest1(ptCi, ptAll, ptUnpack);
            if (status == ERROR)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[RRCInactive] Fallback to RRCSetup\n");
                MACRO_RESET_CALL_FAULT_CAUSES;

                FnVCCB_CommonActionforRRCSetupOrRelease(*ptCi, eRrcSetup, ptMsg->hdr.src.contextId);
            }
            break;

        case interface_xn:
            status = FnVCCB_Inact_ProcXnRetrieveUEContextRequest(ptCi, ptAll, ptUnpack);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_Inact_ProcXnRetrieveUEContextRequest ERROR\n");
            break;

        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid interface(%d) in %s\n", ptMsg->interface, __FUNCTION__);
            return ERROR;
    }

    return GOOD;
}

/**
 * @brief Handle timNRRRC_RrcResumeRequest1 in Inact_ResumeReq
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_ResumeReq_timNRRRC_RrcResumeRequest1(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint16_t enqueuedActionIndex;

    message_type *ptAllDequeue = reinterpret_cast<message_type*>(&THREAD_INFO->call[ptCi->myThreadId].buf.rx);    
    msgUnpack_type *ptUnpackDequeue = &THREAD_INFO->call[ptCi->myThreadId].buf.unpack.call.buff;
    uint8_t gnbRanPagingTxCount = pGnb->RrcInactiveInfo.ranPagingTxCount;

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // Send RAN-Paging until its maximum tx count
    if (ptCi->ueInfo.RrcInactiveInfo.ranPagingTxCount < gnbRanPagingTxCount)
    {
        VCCB_PRINT_CALL_CRITICAL(ptCi, "timNRRRC_RRCResumeRequest1_id expired but ranPagingTxCount(%d/%d) remains!!\n",
            ptCi->ueInfo.RrcInactiveInfo.ranPagingTxCount, gnbRanPagingTxCount);
        VCCB_RETURN_ON_CALL_ERROR(
            ptCi, FnVCCB_SendCallPagingReq(ptCi, procDedicated), "FnVCCB_SendCallPagingReq ERROR!\n");
        VLIB_AttachTimer(&ptCi->timer, ptCi, timNRRRC_RRCResumeRequest1_id);

        return BREAK;
    }

    // LOGGING
    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, timNRRRC_RRCResumeRequest1_id, sizeof(messageHdr_type), reinterpret_cast<uint8_t *>(ptAll));

    // SVR22A: Collect Statistics (FGR-CC0107)
    if (ptCi->ranPagingInfo.exceptionalFlag != TRUE)
    {
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaTmOutPaging);
        MACRO_STAT_PMCC(STAT_RAN_PAGING, RrcInact_RanPagingFailure, ptCi, 0, 0, 0, 0, 0);
    }

    if ((GETBIT(ptCi->flag.setupFlag, NGC_CONNECTION_FLAG)) &&
        (VCCB_FLAG_ON == ptCi->ranPagingInfo.pagingTriggeredByDLNasTransportFlag) &&
        ENQUEUE_ACTION_DOWNLINK_NAS_TRANSPORT == ptCi->actionQueue[0])
    {
        // dequeue from the action queue
        for (enqueuedActionIndex = 0; enqueuedActionIndex < ACTION_QUEUE_SIZE - 1; enqueuedActionIndex++)
        {
            ptCi->actionQueue[enqueuedActionIndex] = ptCi->actionQueue[enqueuedActionIndex + 1];
        }

        ptCi->actionQueue[ACTION_QUEUE_SIZE - 1] = ENQUEUE_NO_ACTION;

        // dequeue from the msg queue
        if (ERROR == MsgQueueManager::getInstance().dequeueMsgQueueMap(ptCi, ptAllDequeue, ENQUEUE_ACTION_DOWNLINK_NAS_TRANSPORT))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "%s: dequeueMsgQueueMap ERROR!\n", __FUNCTION__);
            return ERROR;
        }

        if (ERROR == VCCB_GetMsgUnpack_checkMsgId(ptAllDequeue, ptUnpackDequeue, ptCi->myThreadId))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "%s: VCCB_GetMsgUnpack_checkMsgId ERROR!\n", __FUNCTION__);
            return ERROR;
        }

        uint16_t cause = CauseNgapRadioNetworkLayerUeInRrcInactiveStateNotReachable;
        auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_NASNonDeliveryIndicationAllAmf_id,
            reinterpret_cast<NG_DownlinkNASTransportAmfAll_type *>(ptUnpackDequeue->unpack), &cause);
        VALID_E_POINT_CHECK_ERROR(ngapSender);
        if (ERROR == ngapSender->sendMsg())
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "sendMsg(NG_NASNonDeliveryIndicationAllAmf) Error !\n");
            return ERROR;
        }
    }

    return GOOD;
}

int16_t FnVCCB_Inact_ResumeReq_E1DLDataNotification(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    if (ERROR == FnVCCB_StoreE1Message(E1_DLDataNotification_id, ptCi, ptAll, ptUnpack))
    {
        MACRO_RESET_CALL_FAULT_CAUSES;
    }

    ptCi->ranPagingInfo.dlDataFlag = VCCB_FLAG_ON;
    return GOOD;
}

/**
 * @brief Handle NgapLocationReportingControlAmfAll in Inact_ResumeReq
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_ResumeReq_NgapLocationReportingControl(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    // msg is already stored in ALL state

    if (ci_5g_Rpt_direct == ptCi->locRpt.eventType)
    {
        ptCi->ranPagingInfo.dlDataFlag = VCCB_FLAG_ON;
        ptCi->locRpt.isPagingReqForInactivity = TRUE;
    }
    else
    {
        if ((ptCi->locRpt.eventType == ci_5g_Rpt_stop_change_of_serve_cell) ||
            (ptCi->locRpt.eventType == ci_5g_Rpt_stop_UE_in_AoI) || (ptCi->locRpt.eventType == ci_5g_Rpt_cancel))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Unexpected event type received !!\n");
        }
        else  // change_of_serve_cell or AOI
        {
            if (ptCi->locRpt.reportOn == CI_use)
            {
                auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_LocationReportAllAmf_id);
                VALID_E_POINT_CHECK_ERROR(ngapSender);
                if (ngapSender->sendMsg() == ERROR)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "sendMsg(NG_LocationReportAllAmf) ERROR !!\n");
                    return ERROR;
                }
            }
        }
        ptCi->locRpt.reportOn = CI_no_use;
    }
    return GOOD;
}

/**
 * @brief Handle NgapDownlinkUEAssociatedNRPPaTransport in Inact_ResumeReq
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_ResumeReq_NgapDownlinkUEAssociatedNRPPaTransport(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    ptCi->NrPpaContext.isPagingRequiredForECID = TRUE;
    ptCi->ranPagingInfo.dlDataFlag = VCCB_FLAG_ON;

    return GOOD;
}

int16_t FnVCCB_Inact_T_XnUeContextReq_XnUeContextResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    SctpDataType *ptSctpDataInd = reinterpret_cast<SctpDataType *>(ptAll);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    ptCi->ueInfo.RrcInactiveInfo.numRtrvUeCtxtReqSendToGnb = 0;
    int16_t status = FnVCCB_StoreXNMessage(XN_RetrieveUEContextResponse_id, ptCi, ptAll, ptUnpack);

    // FGR-TA0103 Cell traffic trace. FGR-TA0101 Subscriber and equipment trace
    // Check XNAP Retrieve UE Context Response msg and forward to VTMB (also in Store Error case)
    VLIB_collectTraceMessage(ptCi,
        {RX_MSG, ptUnpack->msgId, reinterpret_cast<char *>(ptSctpDataInd->data), ptSctpDataInd->length, ptSctpDataInd->endPointIdx});

    if (GOOD != status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_StoreXNMessage(XN_RetrieveUEContextResponse_id) ERROR!\n");
        return BREAK;
    }

    status = VLIB_SecurityHandling(ptCi, FALSE);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_SecurityHandling ERROR !!\n");
        // MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaInvalidSecurityAlgorithm);    // In case of BREAK, we
        // are going for RRC Setup.
        return BREAK;
    }

    // security key is changed on UE side.
    ptCi->ueInfo.securityModFlag = VCCB_FLAG_ON;

    // SVR24B FGR-CC0107 FR1010
    if (ptCi->ueContainerNR.rxFlag && (FnVCCB_CheckUeCapa_RedCapSupport(ptCi) != GOOD))
    {
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaUeCapaNotSupported);
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_CheckUeCapa_RedCapSupport ERROR!\n");
        return ERROR;
    }

    status = FnVCCB_CheckFallbackCondition(ptCi, MobilityType::RRC_RESUME_INTER_GNB);
    if (GOOD != status)
    {
        if (ptCi->ueInfo.RrcInactiveInfo.resumeCause == NRRRC_rna_Update)
        {
            // MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ???? );
            // will be defined in SVR26A
            VCCB_PRINT_CALL_ERROR(ptCi, "Fallback to RRC Release is Required\n");
            return ERROR;
        }
        else
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Fallback to RRC Setup is Required\n");
            return BREAK;  // Network fallback to RRC Setup
        }
    }

    // SVR26A: updates CSL information
    FnVCCB_SetVonrAndEmergencyCallForCsl(*ptCi);

    //SVR25A FGR-CC0107 FR1010: check fb condition additionally for vonr service while resuming
    if (ptCi->ueInfo.RrcInactiveInfo.resumeCause != NRRRC_rna_Update)
    {
        if (GOOD != VCCM_CheckVoiceOverNR(ptCi, ptCi->servCellNum))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_CheckVoiceOverNR ERROR in %s\n", __func__);
            VCCB_PRINT_CALL_ERROR(ptCi, "[RRCInactive] Fallback to RRCSetup!!\n");
            return BREAK;   // Network fallback to RRC Setup
        }
    }

    if (no_error != ptCi->signalingTraceInfo.failureIndication.cause)
    {
        // queue Trace Failure Indication message
        if (GOOD != VCCM_enqueueActionWithForce(ptCi, ENQUEUE_ACTION_SEND_SIG_TRACE_FAILURE_IND, false))
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, mdt_trace_all, "VCCM_enqueueAction(ENQUEUE_ACTION_SEND_SIG_TRACE_FAILURE_IND) ERROR\n");
        }
    }

    // If UE capa enquiry is required as the freq band filter of resuming cell is different from the last serving cell,
    // it leads to carry out RRCSetup procedure
    if ((BAND_NOT_FOUND == VLIB_GetFreqBandIndForCell(ptCi, pCell)) &&
        (ptCi->ueInfo.RrcInactiveInfo.resumeCause != NRRRC_rna_Update))
    {
        VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "[RRCInactive] Going to RRCSetup (servPCellBand is NOT included in supportedBandListNR)\n");
        return BREAK;
    }

    status = (int16_t)FnVCCB_ConfigureUeContextForRREandRRCResume(ptCi, MobilityType::RRC_RESUME_INTER_GNB);
    if (GOOD != status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_ConfigureUeContextForRREandRRCResume ERROR\n");
        return ERROR; // Call Release
    }

    // SVR26A FGR-CC0107
    // CSL: update VoNR indicator and Emergency indicator using common API for an inter-gNB transaction!
    if (ptCi->ueInfo.RrcInactiveInfo.resumeCause != NRRRC_rna_Update)
        FnVCCB_CheckAndUpdate_VoNREmergencyIndicator_CSL(ptCi); 

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "(vonrRequestedForCsl:%d/ emergencyRequestedForCsl:%d)\n",
        ptCi->vonrRequestedForCsl, ptCi->emergencyRequestedForCsl);

    /* update endPointXNIdx */
    ptCi->endPointInfo.xnIdx = ptSctpDataInd->endPointIdx;
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->endPointInfo.xnIdx, MAX_XN_NBR_PER_GNB);

    ptCi->endPointInfo.xnGnbId = pGnb->xnNbr[ptCi->endPointInfo.xnIdx].gnbId.id;

    if (Idle_cmd != ptCi->stateCmd)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid stateCmd(%u) in %s\n", ptCi->stateCmd, __FUNCTION__);
    }

    if (ptCi->ueInfo.RrcInactiveInfo.resumeCause == NRRRC_rna_Update)
    {
        SET_STATE_CMD(RRCSuspend_cmd);  // in order to set bearerContextStatusChange to suspend

        VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "Start RNA Update(Inter-gNB) on target gNB (Cause:%d)\n", ptCi->ueInfo.RrcInactiveInfo.resumeCause);
    }
    else
    {
        SET_STATE_CMD(RRCResume_cmd);

        // during Resume UE selects band again, so VCCB needs do it also.
        FnVCCB_SetServCellBand(ptCi);

        VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "Start RRC Resume(Inter-gNB) on target gNB (Cause:%d)\n", ptCi->ueInfo.RrcInactiveInfo.resumeCause);

        // [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
        VLIB_startManagementMdtTrace(ptCi, ptCi->servCellNum);
        VLIB_startManagementUeThrRfTrace(ptCi, ptCi->servCellNum);
        VLIB_startLoggedMdtTrace(ptCi, ptCi->servCellNum);
        VRRM_addCellNonDssUeCount(ptCi, ptCi->servCellNum);

        FnVCCB_InitUeAssistanceInformation(*ptCi);
        FnVCCB_ClearAll_UlGapFR2(*ptCi);

        // PrepareNewMeasConfig for new cell
        VCCB_RETURN_ON_CALL_ERROR(ptCi, VCCB_PrepareNewMeasConfig(ptCi), "VCCB_PrepareNewMeasConfig ERROR!\n");

        status = VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_CA_MOD);
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "VCCM_enqueueAction(ENQUEUE_ACTION_CA_MOD ERROR!\n");
        }
    }

    // Update cellGroupConfig with the source-cell's masterCellGroupConfig (SVR21D)
    msgContainer_type *pCellGroupConfigBuf = &THREAD_INFO->call[ptCi->myThreadId].buf.cellGroupConfig;
    uint16_t packLen = pCellGroupConfigBuf->numocts;
    memcpy(ptCi->cellGroupConfig.data, pCellGroupConfigBuf->data, packLen);
    ptCi->cellGroupConfig.numocts = packLen;

    status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextSetup);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest(Setup) ERROR!\n");

    VLIB_SetCurStateAll(ptCi, STATE_Inact_T_E1Setup);
    VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextSetup_id);

    if (VCOM_UpdateUPM_Prepare(ptCi) == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Forced Disabled UPM (PCell, RRC-Inact) in %s!\n", __func__);
        VCOM_DisableUPM(ptCi);
    }

    return GOOD;
}

int16_t FnVCCB_Inact_T_XnUeContextReq_XnUeContextFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    if (0 < ptCi->ueInfo.RrcInactiveInfo.numRtrvUeCtxtReqSendToGnb)
    {
        ptCi->ueInfo.RrcInactiveInfo.numRtrvUeCtxtReqSendToGnb--;
    }

    if (0 == ptCi->ueInfo.RrcInactiveInfo.numRtrvUeCtxtReqSendToGnb)
    {
        ptCi->ueInfo.rrcResumeInfo.ueContextRetrievalFail = TRUE;
    }

    int16_t status = FnVCCB_StoreXNMessage(XN_RetrieveUEContextFailure_id, ptCi, ptAll, ptUnpack);
    if (GOOD != status) return ERROR;

    return GOOD;
}

int16_t FnVCCB_Inact_T_XnUeContextReq_timXN_RetrieveUeContext(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    // LOGGING
    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, timXN_RetrieveUEContext_id, sizeof(messageHdr_type), reinterpret_cast<uint8_t *>(ptAll));


    ptCi->ueInfo.RrcInactiveInfo.numRtrvUeCtxtReqSendToGnb = 0;
    ptCi->ueInfo.rrcResumeInfo.ueContextRetrievalFail = TRUE;

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    return GOOD;
}

int16_t FnVCCB_Inact_T_E1Setup_E1BearerContextSetupSuccess(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    int16_t status;
    switch (ptCi->stateCmd)
    {
        case RRCResume_cmd:
            status = VFIL_sendF1_UeContextSetupRequest(ptCi, NULL, 0);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextSetupRequest ERROR!\n");

            VLIB_SetCurStateAll(ptCi, STATE_Inact_F1Setup);
            VLIB_AttachTimer(&ptCi->timer, ptCi, timF1_UeContextSetup_id);
            break;

        case RRCSuspend_cmd:
            VLIB_setBearerStatusToIdle(ptCi);

            // BearerContextStatusChange(=suspend)
            status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

            VLIB_SetCurStateAll(ptCi, STATE_Inact_T_E1Mod);
            VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);
            break;

        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid stateCmd(%u) in %s\n", ptCi->stateCmd, __FUNCTION__);
            return ERROR;
    }

    return GOOD;
}

void FnVCCB_Inact_T_E1Setup_E1BearerContextSetupUnsuccess(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->cause.e1Cause);
}

int16_t FnVCCB_Inact_T_E1Setup_timE1_BearerContextSetup(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // LOGGING
    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, timE1_BearerContextSetup_id, sizeof(messageHdr_type), reinterpret_cast<uint8_t *>(ptAll));

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerSetup);

    return GOOD;
}

/**
 * @brief Handle F1UeContextSetupResponse in Inact_F1Setup
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_F1Setup_F1UeContextSetupResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    VCCB_RETURN_ON_CALL_ERROR(ptCi, VFIL_storeF1_UeContextSetupResponse(ptCi, ptAll, ptUnpack),
        "VFIL_storeF1_UeContextSetupResponse ERROR!\n");

    int16_t status;
    switch (ptCi->ueInfo.rrcResumeInfo.resumeType)
    {
        case RESUME_TYPE_INTRA_GNB:
        {
            status = FnVCCB_SendF1_DLRRCMessageTransfer_RRCResume(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendF1_DLRRCMessageTransfer_RRCResume ERROR!\n");

            VLIB_AttachTimer(&ptCi->timer, ptCi, timNRRRC_RRCResume_id);
            VLIB_SetCurStateAll(ptCi, STATE_Inact_ResumeCmpl);
            break;
        }
        case RESUME_TYPE_INTER_GNB_TARGET:
        {
            // BearerContextStatusChange(=resume), F1 DL TEID per DRB IE
            status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

            VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);
            VLIB_SetCurStateAll(ptCi, STATE_Inact_T_E1Mod);
            break;
        }

        default:
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Invalid resumeType(%d) in %s\n", ptCi->ueInfo.rrcResumeInfo.resumeType, __FUNCTION__);
            return ERROR;
    }

    return GOOD;
}

/**
 * @brief Handle F1UeContextSetupFailure in Inact_F1Setup
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_F1Setup_F1UeContextSetupFailure(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, VFIL_storeF1_UeContextSetupFailure(ptCi, ptAll, ptUnpack), "VFIL_storeF1_UeContextSetupFailure ERROR!\n");

    return GOOD;
}

/**
 * @brief Handle timF1_UeContextSetup in Inact_F1Setup
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_F1Setup_timF1_UeContextSetup(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // Conventional Process on F1 timer expiry: LOGGING
    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, timF1_UeContextSetup_id, sizeof(messageHdr_type), reinterpret_cast<uint8_t *>(ptAll));

    // Conventional Process on F1 timer expiry: CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutF1UeContextSetup);
    MACRO_STAT_PMCC(STAT_F1AP_UE_SETUP_CU, CU_F1UeSetupFail_DUTimeout, ptCi, 0, 0, 0, 0, 0);
    VLIB_SetNoAttemptFlag(ptCi, STAT_F1AP_UE_SETUP_CU);
    return GOOD;
}

int16_t FnVCCB_Inact_T_E1Mod_E1BearerContextModificationSuccess(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    int16_t status;
    uint8_t targetXN = 0;

    switch (ptCi->stateCmd)
    {
        case RRCResume_cmd:
        {
            targetXN = 0;
            status = FnVCCB_SendXNMessage(XN_XnUAddressIndication_id, ptCi, &targetXN, nullptr);
            if (ERROR == status)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendXNMessage (XN_XnUAddressIndication_id) ERROR!\n");
                return ERROR;
            }

            // SVR25A FGR-MC1020
            // Initialize the measConfig that installed to UE before building RRCResume for the full configuration
            if (ptCi->ueInfo.rrcResumeInfo.fullConfigRequiredFlag == TRUE)
            {
                VCCM_InitInstalledMeasConfig_ByFullConfiguration(ptCi);
            }

            status = FnVCCB_SendF1_DLRRCMessageTransfer_RRCResume(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendF1_DLRRCMessageTransfer_RRCResume ERROR!\n");

            // STATE_Inact_T_E1Mod -> STATE_Inact_ResumeCmpl
            VLIB_SetCurStateAll(ptCi, STATE_Inact_ResumeCmpl);
            VLIB_AttachTimer(&ptCi->timer, ptCi, timNRRRC_RRCResume_id);
            break;
        }

        case RRCSuspend_cmd:
        {
            if (ERROR == VIIL_sendCallSetupRsp(ptCi, CP_RET_OK))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_sendCallSetupRsp ERROR!!\n");
            }

            targetXN = 0;
            status = FnVCCB_SendXNMessage(XN_XnUAddressIndication_id, ptCi, &targetXN, nullptr);
            if (ERROR == status)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendXNMessage (XN_XnUAddressIndication_id) ERROR!\n");
                return ERROR;
            }

            // pdcp-reestablishment (RNAU only)
            status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

            // STATE_Inact_T_E1Mod -> STATE_Inact_E1Mod_Pdcp
            VLIB_SetCurStateAll(ptCi, STATE_Inact_E1Mod_Pdcp);
            VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);
            break;
        }

        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid stateCmd(%d) in %s\n", ptCi->stateCmd, __FUNCTION__);
            return ERROR;
    }

    return status;
}

void FnVCCB_Inact_T_E1Mod_E1BearerContextModificationUnsuccess(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->cause.e1Cause);
}

int16_t FnVCCB_Inact_T_E1Mod_timE1_BearerContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // LOGGING
    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, timE1_BearerContextModification_id, sizeof(messageHdr_type), reinterpret_cast<uint8_t *>(ptAll));

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    return GOOD;
}

int16_t FnVCCB_Inact_T_E1Mod_E1DLDataNotification(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    if (RRCSuspend_cmd == ptCi->stateCmd)
    {
        int16_t status = FnVCCB_StoreE1Message(E1_DLDataNotification_id, ptCi, ptAll, ptUnpack);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_StoreE1Message(E1_DLDataNotification_id) ERROR!\n");

        SET_STATE_CMD(RRCResume_cmd);

        status = VFIL_sendF1_UeContextSetupRequest(ptCi, NULL, 0);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextSetupRequest ERROR!\n");

        // STATE_Inact_T_E1Mod -> STATE_Inact_F1Setup (change into RRCResume)
        VLIB_SetCurStateAll(ptCi, STATE_Inact_F1Setup);
        VLIB_AttachTimer(&ptCi->timer, ptCi, timF1_UeContextSetup_id);
    }

    ptCi->ranPagingInfo.dlDataFlag = VCCB_FLAG_ON;

    return GOOD;
}

/**
 * @brief Handle NRRRC_RrcResumeComplete in Inact_ResumeCmpl
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_ResumeCmpl_NRRRC_RrcResumeComplete(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    MACRO_STAT_PMCC(STAT_RRC_INACTIVE_INFO, RrcInact_RrcResume, ptCi, 0, 0, 0, 0, 0);

    if (DBG->flag.keepIrntiUntilProcComplt)
    {
        IRNTIManager::getInstance().removeIRNTI(ptCi);
    }

    if (VRIL_StoreNRRRC_RRCResumeComplete(ptCi, ptUnpack) == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VRIL_StoreNRRRC_RRCResumeComplete ERROR!\n");
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalStoreRrcMessageError);
        // is any statistics required here ???

        return ERROR;
    }

    /* update MO and measConfigs after resumption */
    if (VCCB_CommitMeasurementReconfiguration(ptCi) == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_CommitMeasurementReconfiguration ERROR\n");
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalStoreRrcMessageError);
        return ERROR;
    }
    VLIB_CommitRadioBearerConfigUE(ptCi);

    SET_RRC_STATE(ptCi, RRC_CONNECTED);
    OFF_RRC_CONNECTION_FLAG(ptCi->flag.respFlag);

    // SVR25A FGR-MC1020 initialize the fullconfig flag once resume procedure completed
    ptCi->ueInfo.rrcResumeInfo.fullConfigRequiredFlag = VCCB_FLAG_OFF;

    ComLibStatistic::calculateRRCHoldingTime(*ptCi, RRC_CONNECTED);

    if (RESUME_TYPE_INTER_GNB_TARGET == ptCi->ueInfo.rrcResumeInfo.resumeType)
    {
        if (ERROR == VIIL_sendCallSetupRsp(ptCi, CP_RET_OK))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_sendCallSetupRsp ERROR!!\n");
        }
    }

    VCCB_RETURN_ON_CALL_ERROR(ptCi, VFIL_sendF1_UeContextModificationRequest(ptCi, NULL),
        "VFIL_sendF1_UeContextModificationRequest ERROR!!\n");

    // [FGR-CC0104] UE would cancel 'otherConfig' setting. VCCB would send T345/T346 in next RRC Reconfig procedure.
    FnVCCB_InitUeNrRrcOtherConfig(ptCi);

    // STATE_Inact_ResumeCmpl -> STATE_Inact_F1Mod
    VLIB_AttachTimer(&ptCi->timer, ptCi, timF1_UeContextModification_id);
    VLIB_SetCurStateAll(ptCi, STATE_Inact_F1Mod);
    return GOOD;
}

/**
 * @brief Handle timNRRRC_RrcResume in Inact_ResumeCmpl
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_ResumeCmpl_timNRRRC_RrcResume(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // LOGGING
    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, timNRRRC_RRCResume_id, sizeof(messageHdr_type), reinterpret_cast<uint8_t *>(ptAll));

    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaTmOutRrcResume);

    // Statistics
    // TBD

    return GOOD;
}

/**
 * @brief Handle F1UeContextModificationResponse in Inact_F1Mod
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_F1Mod_F1UeContextModificationResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    VCCB_RETURN_ON_CALL_ERROR(ptCi, VFIL_storeF1_UeContextModificationResponse(ptCi, ptAll, ptUnpack),
        "VFIL_storeF1_UeContextSetupResponse ERROR!\n");

    int16_t status;
    switch (ptCi->ueInfo.rrcResumeInfo.resumeType)
    {
        case RESUME_TYPE_INTRA_GNB:
            status = VIIL_sendCallResourceChangeInd(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VIIL_sendCallResourceChangeInd ERROR!!\n");

            // BearerContextStatusChange(=resume), F1 DL TEID, security info IE
            status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest(Modification) ERROR!\n");
            break;

        case RESUME_TYPE_INTER_GNB_TARGET:
            // pdcp-reestablishment IE
            status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest(Modification) ERROR!\n");
            break;
        default:
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Invalid resumeType(%d) in %s\n", ptCi->ueInfo.rrcResumeInfo.resumeType, __FUNCTION__);
            return ERROR;
    }

    // STATE_Inact_F1Mod -> STATE_Inact_E1Mod_Pdcp
    VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);
    VLIB_SetCurStateAll(ptCi, STATE_Inact_E1Mod_Pdcp);

    return GOOD;
}

/**
 * @brief Handle F1UeContextModificationFailure in Inact_F1Mod
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_F1Mod_F1UeContextModificationFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    VCCB_RETURN_ON_CALL_ERROR(ptCi, VFIL_storeF1_UeContextModificationFailure(ptCi, ptAll, ptUnpack),
        "VFIL_storeF1_UeContextSetupFailure ERROR!\n");

    return GOOD;
}

/**
 * @brief Handle timF1_UeContextModification in Inact_F1Mod
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_F1Mod_timF1_UeContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, timF1_UeContextModification_id, sizeof(messageHdr_type), reinterpret_cast<uint8_t *>(ptAll));

    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutF1UeContextModification);

    MACRO_STAT_PMCC(STAT_F1AP_CU_INIT_UE_MOD_CU, CU_F1CuInitUeModFail_DUTimeout, ptCi, 0, 0, 0, 0, 0);
    VLIB_SetNoAttemptFlag(ptCi, STAT_F1AP_CU_INIT_UE_MOD_CU);

    return GOOD;
}

int16_t FnVCCB_Inact_E1Mod_Pdcp_E1BearerContextModificationSuccess(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    int16_t status = GOOD;
    switch (ptCi->ueInfo.rrcResumeInfo.resumeType)
    {
        case RESUME_TYPE_INTRA_GNB:
            status = FnVCCB_FinalizeRRCResume(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_FinalizeRRCResume ERROR!\n");
            break;

        case RESUME_TYPE_INTER_GNB_TARGET:
        {
            auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_PathSwitchRequestGnbAmf_id);
            VALID_E_POINT_CHECK_ERROR(ngapSender);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, ngapSender->sendMsg(), "sendMsg(NG_PathSwitchRequestGnbAmf) ERROR !!\n");

            ON_NGC_CONNECTION_FLAG(ptCi->flag.setupFlag);

            // STATE_Inact_E1Mod_Pdcp -> STATE_Inact_T_NgPathSwitch
            VLIB_SetCurStateAll(ptCi, STATE_Inact_T_NgPathSwitch);
            VLIB_AttachTimer(&ptCi->timer, ptCi, timNG_PathSwitch_id);
            break;
        }
        default:
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Invalid resumeType(%d) in %s\n", ptCi->ueInfo.rrcResumeInfo.resumeType, __FUNCTION__);
            return ERROR;
    }

    return status;
}

/**
 * @brief Handle E1BearerContextModificationFailure in Inact_E1Mod_Pdcp
 * @param ptCi[in/out] callInfo
 */
void FnVCCB_Inact_E1Mod_Pdcp_E1BearerContextModificationUnsuccess(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    MACRO_CALL_FAULT_SAVE(E1_BearerContextModificationFailure_id, ptCi->cause.e1Cause);
}

/**
 * @brief Handle timE1_BearerContextModification in Inact_E1Mod_Pdcp
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_E1Mod_Pdcp_timE1_BearerContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, timE1_BearerContextModification_id, sizeof(messageHdr_type), reinterpret_cast<uint8_t *>(ptAll));

    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    return GOOD;
}

int16_t FnVCCB_Inact_E1Mod_Pdcp_E1DLDataNotification(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    if (RRCSuspend_cmd == ptCi->stateCmd)
    {
        int16_t status = FnVCCB_StoreE1Message(E1_DLDataNotification_id, ptCi, ptAll, ptUnpack);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_StoreE1Message(E1_DLDataNotification_id) ERROR!\n");

        SET_STATE_CMD(RRCResume_cmd);

        status = VFIL_sendF1_UeContextSetupRequest(ptCi, NULL, 0);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextSetupRequest ERROR!\n");

        // STATE_Inact_E1Mod_Pdcp -> STATE_Inact_F1Setup (change into RRCResume)
        VLIB_SetCurStateAll(ptCi, STATE_Inact_F1Setup);
        VLIB_AttachTimer(&ptCi->timer, ptCi, timF1_UeContextSetup_id);
    }

    ptCi->ranPagingInfo.dlDataFlag = VCCB_FLAG_ON;

    return GOOD;
}

int16_t FnVCCB_Inact_T_NgPathSwitch_NgPathSwitchRequestAcknowledge(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    int16_t status = VNIL_StoreNGAP_PathSwitchRequestAcknowledge(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VNIL_StoreNGAP_PathSwitchRequestAcknowledge ERROR !!\n");

    VCCB_PRINT_CALL_ERROR(ptCi, "RRCInactive ability(%u) CP(%u) UE(%u) AMF(%u)\n", ptCi->ueInfo.RrcInactiveInfo.ability,
        (ptCi->ueInfo.RrcInactiveInfo.ability & RRC_INACTIVE_CP_SUPPORT) ? 1 : 0,
        (ptCi->ueInfo.RrcInactiveInfo.ability & RRC_INACTIVE_UE_SUPPORT) ? 1 : 0,
        (ptCi->ueInfo.RrcInactiveInfo.ability & RRC_INACTIVE_AMF_SUPPORT) ? 1 : 0);

    // Security Capabilities are not changing from AMF and Derive is handled in Intra Cell Handover
    /*
    status = VLIB_SecurityHandling(ptCi, TRUE);
    if (ERROR == status)
    {
        MACRO_CALL_FAULT_SAVE(
            ptUnpack->msgId, CauseCpInternalSaInvalidSecurityAlgorithm);
        VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_SecurityHandling ERROR !!\n");
        return ERROR;
    }
    */

    // This function works only when any UL NAS message has saved.
    status = FnVCCB_ProcULNasMsgDequeueForSaMobility(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_ProcULNasMsgDequeueForSaMobility ERROR!\n");

    SET_ON_ALL_RETAIN_STAT_CAPABLE_FLAG(ptCi, VCCB_FLAG_OFF, VCCB_FLAG_ON);  // 23A FGR CC3401

    // In order to update ngUeId to VNMB, which is obtained through NG_PathSwitchRequestAck
    status = VIIL_sendCallResourceChangeInd(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VIIL_sendCallResourceChangeInd ERROR!!\n");

    uint8_t targetXN = e_TargetXN_RRCResume;
    status = FnVCCB_SendXNMessage(XN_UEContextRelease_id, ptCi, &targetXN, nullptr);
    if (ERROR == status)
    {
        MACRO_RESET_CALL_FAULT_CAUSES;
        VCCB_PRINT_CALL_ERROR(ptCi, "XN_UEContextRelease transmission failed, but proceeds without call release\n");
    }

    switch (ptCi->stateCmd)
    {
        case RRCSuspend_cmd:
        {
            // cell tac/ranac check
            bool isRRCInactiveSupported = true;
            if (FnVCCB_IsServingCellSupportRRCInactive(ptCi) != TRUE)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "ServCell(%d) is not support RRCInactive. Release call instead of Suspend\n", ptCi->servCellNum);
                isRRCInactiveSupported = false;
            }
            else if (ptCi->ueInfo.RrcInactiveInfo.ability != RRC_INACTIVE_SUPPORT)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "RRCInactive is not supported(ability=%u). Release call instead of Suspend\n",
                    ptCi->ueInfo.RrcInactiveInfo.ability);
                isRRCInactiveSupported = false;
            }

            if (false == isRRCInactiveSupported)
            {
                // FGR-CC0107(22A)
                MACRO_RESET_CALL_FAULT_CAUSES;
                // MACRO_CALL_FAULT_SAVE(NG_PathSwitchRequestAcknowledgeAmfGnb_id, ????);
                // will be defined in SVR26A

                if (VCCB_CALL_RELEASE_TRIGGER(ptCi) != GOOD)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_CALL_RELEASE_TRIGGER ERROR!\n");
                    VLIB_PutCi(ptCi);
                }
                return GOOD;
            }

            // N3 UL TEID IE
            status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

            // STATE_Inact_T_NgPathSwitch -> STATE_Inact_T_E1Mod_N3TeId
            VLIB_SetCurStateAll(ptCi, STATE_Inact_T_E1Mod_N3TeId);
            VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);
            break;
        }

        case RRCResume_cmd:
            // N3 UL TEID IE
            status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

            // STATE_Inact_T_NgPathSwitch -> STATE_Inact_T_E1Mod_N3TeId
            VLIB_SetCurStateAll(ptCi, STATE_Inact_T_E1Mod_N3TeId);
            VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);

            // Check if and send Cell traffic trace to eNB/AMF
            status = VCCM_enqueueActionWithForce(ptCi, ENQUEUE_ACTION_SEND_MGT_CELL_TRAFFIC_TRACE,true);
            VCCB_PRINT_WITHOUT_RETURN_ON_CALL_ERROR(ptCi, status, "[MDT][MGT] VCCM_enqueueActionWithForce(ENQUEUE_ACTION_SEND_MGT_CELL_TRAFFIC_TRACE) ERROR\n");
            break;

        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid stateCmd(%d) in %s\n", ptCi->stateCmd, __FUNCTION__);
            return ERROR;
    }

    return GOOD;
}

int16_t FnVCCB_Inact_T_NgPathSwitch_NgPathSwitchRequestFailure(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    int16_t status = VNIL_StoreNGAP_PathSwitchRequestFailure(ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VNIL_StoreNGAP_PathSwitchRequestFailure ERROR !!\n");

    MACRO_RESET_CALL_FAULT_CAUSES;
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaRrcInactiveRelease);

    return GOOD;
}

int16_t FnVCCB_Inact_T_NgPathSwitch_timNG_PathSwitch(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // LOGGING
    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, timNG_PathSwitch_id, sizeof(messageHdr_type), reinterpret_cast<uint8_t *>(ptAll));

    // CALL FAULT
    // FGR-CC0107(22A)
    MACRO_RESET_CALL_FAULT_CAUSES;
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaResumeTmOutNgPathSwitchRequest);

    return GOOD;
}

int16_t FnVCCB_Inact_T_E1Mod_N3TeId_E1BearerContextModificationSuccess(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    int16_t status;
    switch (ptCi->stateCmd)
    {
        case RRCSuspend_cmd:
        {
            if (DBG->flag.keepIrntiUntilProcComplt)
            {
                IRNTIManager::getInstance().removeIRNTI(ptCi);
            }

            status = IRNTIManager::getInstance().makeIRNTI(ptCi);
            if (status == ERROR)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "makeIRNTI ERROR!\n");  // This case cannot occur.
                MACRO_CALL_FAULT_SAVE(
                    E1_BearerContextModificationResponse_id, CauseCpInternalSaResumeProcedureNotAvailable);
                if (VCCB_CALL_RELEASE_TRIGGER(ptCi) != GOOD)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_CALL_RELEASE_TRIGGER ERROR!\n");
                    VLIB_PutCi(ptCi);
                }
                return GOOD;
            }

            // Ciphering and Integration Protection for SA (FGR-BC0323)
            VLIB_updateSuspendedCellInfo(ptCi);

            status = FnVCCB_SendF1_UeContextReleaseCommand_RRCRelease(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendF1_UeContextReleaseCommand_RRCRelease ERROR!\n");
            OFF_F1_REL_COMPLT_RCV_FLAG(ptCi->flag.respFlag);

            if (VIIL_sendCallReleaseIndVccbVnmb(ptCi, eSuspend, ptCi->gnbCuUeId, ptCi->gnbCuUeId) != GOOD)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_sendCallReleaseIndVccbVnmb ERROR!\n");
            }

            status = FnVCCB_FinalizeRRCSuspend(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_FinalizeRRCSuspend ERROR!\n");
            break;
        }

        case RRCResume_cmd:
            status = FnVCCB_FinalizeRRCResume(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_FinalizeRRCResume ERROR!\n");
            break;

        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid stateCmd(%d) in %s\n", ptCi->stateCmd, __FUNCTION__);
            return ERROR;
    }

    return status;
}

void FnVCCB_Inact_T_E1Mod_N3TeId_E1BearerContextModificationUnsuccess(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->cause.e1Cause);
}

int16_t FnVCCB_Inact_T_E1Mod_N3TeId_timE1_BearerContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // LOGGING
    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, timE1_BearerContextModification_id, sizeof(messageHdr_type), reinterpret_cast<uint8_t *>(ptAll));

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    return GOOD;
}

// SVR22B FGR-CC0108 UAI
int16_t FnVCCB_Inact_Reconfig_NRRRC_RrcReconfigurationComplete(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    int16_t status;

    status = FnVCCB_FinalizeRRCResumeExt(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_FinalizeRRCResumeExt ERROR!\n");

    return GOOD;
}

// SVR22B FGR-CC0108 UAI
int16_t FnVCCB_Inact_Reconfig_timNRRRC_RRCReconfig(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // LOGGING
    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, timNRRRC_RRCReconfig_id, sizeof(messageHdr_type), reinterpret_cast<uint8_t *>(ptAll));

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutRrcConnectionReconfig);

    return GOOD;
}

int16_t FnVCCB_Inact_S_E1Mod_TxStop_E1BearerContextModificationSuccess(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    if (FnVCCB_SendXNMessage(XN_RetrieveUEContextResponse_id, ptCi, nullptr, nullptr) == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendXNMessage(XN_RetrieveUEContextResponse_id) ERROR!\n");
        return ERROR;
    }
    ON_XN_U_ADDRESS_INDICATION_FLAG(ptCi->flag.respFlag);

    // STATE_Inact_S_E1Mod_TxStop -> STATE_Inact_S_XnUAddrInd
    VLIB_SetCurStateAll(ptCi, STATE_Inact_S_XnUAddrInd);
    VLIB_AttachTimer(&ptCi->ueInfo.rrcResumeInfo.timerXnRelocOverall, ptCi, timXN_RelocOverall_id);

    // SVR25A: To avoid not broadcasting RAN-Paging when source VCCB receives NG UEContextReleaseCommand in case of fallback at the target gNB.
    ptCi->ueInfo.rrcResumeInfo.rrcFallBackFlag = VCCB_FLAG_ON;

    return GOOD;
}

void FnVCCB_Inact_S_E1Mod_TxStop_E1BearerContextModificationUnsuccess(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->cause.e1Cause);
}

int16_t FnVCCB_Inact_S_E1Mod_TxStop_timE1_BearerContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // LOGGING
    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, timE1_BearerContextModification_id, sizeof(messageHdr_type), reinterpret_cast<uint8_t *>(ptAll));

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    return GOOD;
}

int16_t FnVCCB_Inact_S_XnUAddrInd_XnUAddressIndication(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int16_t status = FnVCCB_StoreXNMessage(XN_XnUAddressIndication_id, ptCi, ptAll, ptUnpack);
    if (ERROR == status) return ERROR;

    // Xn DL TEID per DRB, PDCP SN Status Request IE
    status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest(Modification) ERROR!\n");

    // STATE_Inact_S_XnUAddrInd -> STATE_Inact_S_E1Mod_XnTeId
    VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);
    VLIB_SetCurStateAll(ptCi, STATE_Inact_S_E1Mod_XnTeId);

    return GOOD;
}

int16_t FnVCCB_Inact_S_E1Mod_XnTeId_E1BearerContextModificationSuccess(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    // STATE_Inact_S_E1Mod_XnTeId -> STATE_Inact_S_XnUeContextRel
    VLIB_SetCurStateAll(ptCi, STATE_Inact_S_XnUeContextRel);

    return GOOD;
}

void FnVCCB_Inact_S_E1Mod_XnTeId_E1BearerContextModificationUnsuccess(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ptCi->cause.e1Cause);
}

int16_t FnVCCB_Inact_S_E1Mod_XnTeId_timE1_BearerContextModification(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    // LOGGING
    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, timE1_BearerContextModification_id, sizeof(messageHdr_type), reinterpret_cast<uint8_t *>(ptAll));

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalTmOutE1BearerContextModification);

    return GOOD;
}

int16_t FnVCCB_Inact_S_timXN_RelocOverall(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->ueInfo.rrcResumeInfo.timerXnRelocOverall, INIT_TIMER);

    // LOGGING
    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, timXN_RelocOverall_id, sizeof(messageHdr_type), reinterpret_cast<uint8_t *>(ptAll));

    // CALL FAULT
    // FGR-CC0107(22A)
    MACRO_RESET_CALL_FAULT_CAUSES;
    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaResumeTmOutXnRelocOverall);

    return GOOD;
}

/**
 * @brief Handle RRCResumeRequest1 in Inact_Suspend, Inact_ResumeRequest1 state
 * @param ptCi[in/out] callInfo
 * @param ptAll[in] raw message
 * @param ptUnpack[in] unpacked message
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_Inact_ProcRRCResumeRequest1(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    VLIB_SetCurrentTime(&ptCi->cslInfo.cslResumeTime);

    msgCallSetupReq_type *ptMsg = reinterpret_cast<msgCallSetupReq_type *>(ptAll);

    ptCi->ueInfo.rrcResumeInfo.resumeType = RESUME_TYPE_INTRA_GNB;
    ptCi->ueInfo.rrcResumeInfo.ranPaged = VCCB_FLAG_ON;

    // unpack F1
    int16_t status = UnpackF1_AllMsg(reinterpret_cast<msgUnpack_type *>(ptUnpack), reinterpret_cast<char *>(ptMsg->data), static_cast<long>(ptMsg->length));

    if (ASN_OK != status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "F1AP Decoding Impossible(R: %d, length: %ld) \n", status, (long)ptMsg->length);
        return ERROR;
    }

    // store the unpacked F1 message to temp buffer
    status = VFIL_storeF1_InitialULRRCMessageTransfer(ptCi, ptAll, ptUnpack);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_storeF1_InitialULRRCMessageTransfer ERROR!\n");
        return ERROR;
    }

    MACRO_STAT_PMCC(STAT_RRC_INACTIVE_INFO, RrcInact_RrcResumeReq, ptCi, 0, 0, 0, 0, 0);

    // AI: update resume history (history circular buffer push, update statistics)
    if (ptCi->ueInfo.RrcInactiveInfo.resumeCause != NRRRC_rna_Update)
    {
        VccbAiClient_OnResumeRequest(ptCi,
            static_cast<int32_t>(ptCi->ueInfo.RrcInactiveInfo.resumeCause));
    }

    // SVR26A FGR-CC0103
    // CSL: update VoNR indicator using VCCM_CheckVoiceOverNR and Emergency indicator using VCCM_CheckEmergencyCall
    if (ptCi->ueInfo.RrcInactiveInfo.resumeCause != NRRRC_rna_Update)
        FnVCCB_CheckAndUpdate_VoNREmergencyIndicator_CSL(ptCi); 

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "(vonrRequestedForCsl:%d/ emergencyRequestedForCsl:%d)\n",
        ptCi->vonrRequestedForCsl, ptCi->emergencyRequestedForCsl);

    if (!DBG->flag.keepIrntiUntilProcComplt)
    {
        IRNTIManager::getInstance().removeIRNTI(ptCi);
    }

    if (ptMsg->endPointIdx >= MAX_GNB_DU_PER_GNB_CU_CP)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "F1: ptMsg->endPointIdx is out of range (rcv:%d/max:%d)\n", ptMsg->endPointIdx,
            MAX_GNB_DU_PER_GNB_CU_CP - 1);
        return ERROR;
    }
    ptCi->endPointInfo.f1Idx = ptMsg->endPointIdx;

    FnVCCB_DeriveKeysForRRCResume(*ptCi);

    const auto dataActivityStatus = RscCall::getDataActivityStatus(*ptCi);
    if (ptCi->stateCmd == RRCIdle_cmd)
    {
        VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "[RRCInactive] This call is already decided to release because of E1/NG reset\n");
    }
    else
    {
        // SVR25B FGR-CC0103
        FnVCCB_SetRRCInactiveAction_after_RRCResumeRequest(ptCi, dataActivityStatus);
    }

    // SVR24A FGR-CC0103: check PLMN(MRL, Cell PLMN from SIB1) in intra-gNB resume/rna-update case
    if ((ptCi->stateCmd == RRCResume_cmd) || (ptCi->stateCmd == RRCSuspend_cmd))
    {
        bool checkFallback = true;

        // SVR24B FGR-CC0103 FR600
        if (ptCi->ueContainerNR.rxFlag && (FnVCCB_CheckUeCapa_RedCapSupport(ptCi) != GOOD))
        {
            MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaUeCapaNotSupported);
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_CheckUeCapa_RedCapSupport ERROR!\n");
            SET_STATE_CMD(RRCIdle_cmd);
            checkFallback = false;
        }

        if (checkFallback)
        {
            status = FnVCCB_CheckFallbackCondition(ptCi, MobilityType::RRC_RESUME_INTRA_GNB);
            if (status != GOOD)
            {
                if (ptCi->stateCmd == RRCResume_cmd)
                {
                    return ERROR;
                }
                else
                {
                    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[RRCInactive] Fallback to RRCIdle(Call Release)\n");
                    // MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, ????);
                    // will be defined in SVR26A

                    // SVR25A code refactoring
                    // dstContextId : VNMB temp callId to remove
                    if (VIIL_sendCallReleaseIndVccbVnmb(ptCi, eSuspend, ptCi->gnbCuUeId, ptMsg->hdr.src.contextId) != GOOD)
                    {
                        VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_sendCallReleaseIndVccbVnmb Error\n");
                    }
                    FnVCCB_CommonActionforRRCSetupOrRelease(*ptCi, eSuspend, UNKNOWN_CP_CALLID);
                    return GOOD;
                }
            }

            // SVR25A FGR-CC0103 FR640: check fb condition additionally for vonr service while resuming
            if (ptCi->stateCmd == RRCResume_cmd)
            {
                if (GOOD != VCCM_CheckVoiceOverNR(ptCi, ptCi->servCellNum))
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_CheckVoiceOverNR ERROR in %s\n", __func__);
                    VCCB_PRINT_CALL_ERROR(ptCi, "[RRCInactive] Fallback to RRCSetup!!\n");

                    MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaNotSupported5qiValue);

                    // SVR25A code refactoring
                    FnVCCB_CommonActionforRRCSetupOrRelease(*ptCi, eRrcSetup, ptMsg->hdr.src.contextId);
                    return GOOD;
                }
            }
        }
    }

    ptCi->ranPagingInfo.pagingTriggeredByDLNasTransportFlag = VCCB_FLAG_OFF;
    ptCi->ranPagingInfo.dlDataFlag = VCCB_FLAG_OFF;

    // srcContextId : found old CuCpUeId
    // dstContextId : VNMB temp callId to remove
    if (VIIL_sendCallReleaseIndVccbVnmb(ptCi, eSuspend, ptCi->gnbCuUeId, ptMsg->hdr.src.contextId) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_sendCallReleaseIndVccbVnmb Error\n");
    }

    status = VCCB_InitializePdcpAllSRBs(ptCi);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_InitializePdcpAllSRBs ERROR!!\n");
        return ERROR;
    }

    switch (ptCi->stateCmd)
    {
        // Case 1) RRC_Inactive to RRC_Connected
        case RRCResume_cmd:
        {
            // during Resume UE selects band again, so VCCB needs do it also.
            FnVCCB_SetServCellBand(ptCi);
            VLIB_ConfigSecondaryCellList(ptCi);

            // Check Serving Load Info for Load Balancing
            ptCi->saLbHoExecuted = FALSE; // FGR-LC0703 (FR33)
            VCCB_PRINT_LOG_SA_LB(ptCi, "[SALB] Load balancing is prepared (by RRC RESUME)\n");

            IRAT_LB_INIT_MEAS_STATE(ptCi); // FGR-LC0711
            VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] Load balancing is prepared (by RRC RESUME)\n");

            // [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
            VLIB_startManagementMdtTrace(ptCi, ptCi->servCellNum);
            VLIB_startManagementUeThrRfTrace(ptCi, ptCi->servCellNum);
            VLIB_startLoggedMdtTrace(ptCi, ptCi->servCellNum);
            VRRM_addCellNonDssUeCount(ptCi, ptCi->servCellNum);

            // skip logged MDT reactivation
            if (logged != ptCi->signalingTraceInfo.mdt.mdt_Activation)
            {
                enumSigActFailResult result;
                SignalingTrace_type oldConfig;
                oldConfig.mdt.mdtStatus = mdtDisabled;
                oldConfig.trace.traceStatus = ueTraceDisabled;

                if (ERROR == VLIB_activateSigMdtTrace(ptCi, result, &oldConfig, false))
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_activateSigMdtTrace error\n");
                }
            }

            FnVCCB_InitUeAssistanceInformation(*ptCi);
            FnVCCB_ClearAll_UlGapFR2(*ptCi);

            // PrepareNewMeasConfig for new cell
            VCCB_RETURN_ON_CALL_ERROR(ptCi, VCCB_PrepareNewMeasConfig(ptCi), "VCCB_PrepareNewMeasConfig ERROR!\n");

            FnVCCB_insertAllocCallDbForRRE(ptCi);

            // SVR25A FGR-MC1020
            status = VCCM_DecideCuInitFullConfigSA(ptCi, NULL, __func__);   // check whether intra-gnb and cu-init full config
            if (status != GOOD)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "Full Configuration is not supported!!\n");
            }

            status = VFIL_sendF1_UeContextSetupRequest(ptCi, NULL, 0);
            if (status == ERROR)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_sendF1_UeContextSetupRequest ERROR!!\n");
                return ERROR;
            }

            VLIB_AttachTimer(&ptCi->timer, ptCi, timF1_UeContextSetup_id);
            VLIB_SetCurStateAll(ptCi, STATE_Inact_F1Setup);

            if (ERROR == VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_CA_MOD))
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "VCCM_enqueueAction(ENQUEUE_ACTION_CA_MOD) fail !!\n");
            }

            break;
        }

        // Case 2) Stay RRC_Suspend
        case RRCSuspend_cmd:
        {
            if (DBG->flag.keepIrntiUntilProcComplt)
            {
                IRNTIManager::getInstance().removeIRNTI(ptCi);
            }

            // do not PrepareNewMeasConfig as UE stays RRC_Suspend

            if (FnVCCB_IsServingCellSupportRRCInactive(ptCi) != TRUE)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "ServCell(%d) is not support RRCInactive. Release call instead of Suspend\n", ptCi->servCellNum);
                // MACRO_CALL_FAULT_SAVE(NRRRC_RrcResumeRequest1_id, ????);
                // will be defined in SVR26A
                if (VCCB_CALL_RELEASE_TRIGGER(ptCi) != GOOD)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_CALL_RELEASE_TRIGGER ERROR!\n");
                    VLIB_PutCi(ptCi);
                }
                return GOOD;
            }

            status = IRNTIManager::getInstance().makeIRNTI(ptCi);
            if (status == ERROR)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "makeIRNTI ERROR!\n");  // This case cannot occur.
                MACRO_CALL_FAULT_SAVE(NRRRC_RrcResumeRequest1_id, CauseCpInternalSaResumeProcedureNotAvailable);
                if (VCCB_CALL_RELEASE_TRIGGER(ptCi) != GOOD)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_CALL_RELEASE_TRIGGER ERROR!\n");
                    VLIB_PutCi(ptCi);
                }
                return GOOD;
            }

            VLIB_updateSuspendedCellInfo(ptCi);

            status = FnVCCB_SendF1_UeContextReleaseCommand_RRCRelease(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendF1_UeContextReleaseCommand_RRCRelease ERROR!\n");
            OFF_F1_REL_COMPLT_RCV_FLAG(ptCi->flag.respFlag);

            status = FnVCCB_FinalizeRRCSuspend(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_FinalizeRRCSuspend ERROR!\n");
            break;
        }

        // Case 3) RRC_Inactive to RRC_Idle
        case RRCIdle_cmd:
            VLIB_SaveEventForCallRetainStat(ptCi, RetainCategory_UeCtxtRelRequestByGNB, ptCi->cause.ngCause);

            if (VCCB_CALL_RELEASE_TRIGGER(ptCi) != GOOD)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_CALL_RELEASE_TRIGGER ERROR!\n");
                VLIB_PutCi(ptCi);
            }
            break;

        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "Not expected case(ptCi->stateCmd==%u) in %s\n", ptCi->stateCmd, __FUNCTION__);
            return ERROR;
    }

    return GOOD;
}

static inline int16_t FnVCCB_InitializePdcpAllSRBsAndDeriveKeys(callInfo_type &call)
{
    int16_t status = VCCB_InitializePdcpAllSRBs(&call);
    VCCB_RETURN_ON_CALL_ERROR(&call, status, "VCCB_InitializePdcpAllSRBs ERROR!\n");

    const auto pci = call.ueInfo.rrcResumeInfo.resumePhysCellId;
    const auto arfcn = call.ueInfo.rrcResumeInfo.targetCellSsbArfcn;
    status = VLIB_DeriveKeyNGRANStar(&call, pci, arfcn, call.security.sKgNB);
    VCCB_RETURN_ON_CALL_ERROR(&call, status, "VLIB_DeriveKeyNGRANStar ERROR(%d)!\n", status);

    VLIB_DeriveKeyRrcIntegrity(&call, call.security.pdcpCtx.securityInfo.keyRrcIntCurr, FALSE);
    VLIB_DeriveKeyRrcEncryption(&call, call.security.pdcpCtx.securityInfo.keyRrcEncCurr, FALSE);
    VLIB_DeriveKeyUpEncryption(&call, call.security.pdcpCtx.securityInfo.keyUpEnc, FALSE);
    VLIB_DeriveKeyUpIntegrity(&call, call.security.pdcpCtx.securityInfo.keyUpInt, FALSE);
    return status;
}

int16_t FnVCCB_Inact_ProcXnRetrieveUEContextRequest(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    VLIB_SetCurrentTime(&ptCi->cslInfo.cslResumeTime);
    msgCallSetupReq_type *ptMsg = NULL;
    int16_t status;
    ptMsg = reinterpret_cast<msgCallSetupReq_type *>(ptAll);

    ptCi->ueInfo.rrcResumeInfo.resumeType = RESUME_TYPE_INTER_GNB_SOURCE;

    // unpack XN
    status = static_cast<int16_t>(fnXNAP_UnpackMsg(ptUnpack, reinterpret_cast<char *>(ptMsg->data), static_cast<int>(ptMsg->length)));

    if (ASN_OK != status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "XNAP Decoding Impossible(R: %d, length: %ld) \n", status, (long)ptMsg->length);
        return ERROR;
    }

    // store the unpacked Xn message to ptCi
    if (ERROR == FnVCCB_StoreXNMessage(XN_RetrieveUEContextRequest_id, ptCi, ptAll, ptUnpack))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_StoreXNMessage (XN_RetrieveUEContextRequest_id) ERROR!\n");
        return ERROR;
    }

    ptCi->endPointInfo.xnIdx = ptMsg->endPointIdx;

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->endPointInfo.xnIdx, MAX_XN_NBR_PER_GNB);
    ptCi->endPointInfo.xnGnbId = pGnb->xnNbr[ptCi->endPointInfo.xnIdx].gnbId.id;

    MACRO_STAT_PMCC_MSG(STAT_XNAP_MSG_UE_PER_GNB, Rx_XnRetrieveUEContextRequest, FnVCCB_GetGnbIdx(ptMsg->gnbNum, ptMsg->gnbId), ptMsg->endPointIdx);

    IRNTIManager::getInstance().removeIRNTI(ptCi);

    ptCi->ueInfo.rrcResumeInfo.targetCellSsbArfcn = ptMsg->targetCellSsbArfcn;
    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[RRCInactive] targetCellSsbArfcn=%u\n", ptCi->ueInfo.rrcResumeInfo.targetCellSsbArfcn);
    uint8_t nonUeAsn1ThreadFlag = 0;

    const auto dataActivityStatus = RscCall::getDataActivityStatus(*ptCi);
    if (RRCIdle_cmd == ptCi->stateCmd)
    {
        status = FnVCCB_InitializePdcpAllSRBsAndDeriveKeys(*ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_InitializePdcpAllSRBsAndDeriveKeys ERROR!\n");

        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[RRCInactive] Release Call because E1/NG reset in source gNB\n");
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerUnspecified;
        ptCi->ueInfo.rrcResumeInfo.isRrcReleaseRelayed = TRUE;
        nonUeAsn1ThreadFlag = FALSE;
        status = FnVCCB_SendXNMessage(XN_RetrieveUEContextFailure_id, ptCi, &nonUeAsn1ThreadFlag, nullptr);
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendXNMessage (XN_RetrieveUEContextFailure_id) ERROR!\n");
        }
        MACRO_CALL_FAULT_SAVE(XN_RetrieveUEContextRequest_id, CAUSE_NO_FAULT);
        VCCB_CALL_RELEASE_TRIGGER(ptCi);
        return GOOD;
    }

    status = FnVCCB_InterGnbRanPaging_HandleMessageQueue(ptCi);

    if (ptCi->ueInfo.rrcResumeInfo.goingToRRCIdleFlag == VCCB_FLAG_ON)      // RRC_inactive to RRC_idle
    {
        if (ptCi->bitFlag.isReceivedUeContextRelease == VCCB_FLAG_ON)
        {
            // case1) It has received NG_UEContextReleaseCommand and received XN_RetrieveUEContextRequest
            ptCi->ueInfo.rrcResumeInfo.isRrcReleaseRelayed = TRUE;
            // this leads to respond with XN_RetrieveUEContextFailure w/ RRCRelease...
        }
        else
        {
            // case2) It has not received NG_UEContextReleaseCommand and received XN_RetrieveUEContextRequest
            ptCi->ueInfo.rrcResumeInfo.isRrcReleaseRelayed = FALSE;     // set again for secure handling...
            // this leads to respond without XN_RetrieveUEContextFailure w/o RRCRelease..
        }

        // responds with XN_RetrieveUEContextFailure and leads to network fallback by RRCSetup at the target gNB (SVR25B FGR-CC0107 FR1041)
        status = FnVCCB_InitializePdcpAllSRBsAndDeriveKeys(*ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_InitializePdcpAllSRBsAndDeriveKeys ERROR!\n");

        VCCB_PRINT_CALL_MSG(
                ptCi, "[RRCInactive] Release call by RRC_Inactive to RRC_Idle transition (isRrcReleaseRelayed:%u)\n",
                ptCi->ueInfo.rrcResumeInfo.isRrcReleaseRelayed);
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerUserInactivity;
        nonUeAsn1ThreadFlag = FALSE;

        ptCi->ueInfo.rrcResumeInfo.ranPaged = VCCB_FLAG_ON; // in order not to send RAN-Paging as source-gNB is already in the call release procedure

        status = FnVCCB_SendXNMessage(XN_RetrieveUEContextFailure_id, ptCi, &nonUeAsn1ThreadFlag, nullptr);
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendXNMessage (XN_RetrieveUEContextFailure_id) ERROR!\n");
        }

        // in order not to send RRCRelease in VCCB_CALL_RELEASE_TRIGGER
        OFF_F1_RESOURCE_FLAG(ptCi->flag.setupFlag);
        OFF_F1_RSC_PREPARATION_FLAG(ptCi->flag.setupFlag);

        MACRO_CALL_FAULT_SAVE(XN_RetrieveUEContextRequest_id, CauseCpInternalSaRrcInactiveRelease);
        VCCB_CALL_RELEASE_TRIGGER(ptCi);
        return GOOD;
    }
    else                                                            // RRC_inactive to RRC_connect
    {
        // Received XN_RetrieveUEContextRequest in RRC inactive state (general RRC inactive to RRC connect)
        if (ptCi->ueInfo.RrcInactiveInfo.resumeCause == NRRRC_rna_Update)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                "Start RNA Update(Inter-gNB) from source gNB(dataActivityStatus(%u), ResumeCause(%u), dlDataFlag(%u)\n",
                dataActivityStatus, ptCi->ueInfo.RrcInactiveInfo.resumeCause, ptCi->ranPagingInfo.dlDataFlag);
        }
        else
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                "Start RRC Resume(Inter-gNB) from source gNB(dataActivityStatus(%u), ResumeCause(%u), dlDataFlag(%u)\n",
                dataActivityStatus, ptCi->ueInfo.RrcInactiveInfo.resumeCause, ptCi->ranPagingInfo.dlDataFlag);
        }

        // Otherwise, 
        // case3) It has received NG_PDUSessionResourceSetup/ModifyRequest, then received XN_RetrieveUEContextRequest
        // responds with XN_RetrieveUEContextResponse and leads to RRCResume at the target gNB (SVR25B FGR-CC0107 FR1050)
        // so, keep going through ...
    }

    ptCi->ranPagingInfo.pagingTriggeredByDLNasTransportFlag = VCCB_FLAG_OFF;
    ptCi->ranPagingInfo.dlDataFlag = VCCB_FLAG_OFF;

    // FGR-BC0323 FR400
    if (ptCi->security.newSecurityContextChangeInd == TRUE)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[RRCInactive] Release Call because NSCI=TRUE in source gNB\n");
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerUpIntegrityProtectionFailure;
        nonUeAsn1ThreadFlag = FALSE;
        if (FnVCCB_SendXNMessage(XN_RetrieveUEContextFailure_id, ptCi, &nonUeAsn1ThreadFlag, nullptr) == ERROR)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendXNMessage(XN_RetrieveUEContextFailure_id) ERROR!\n");
            return ERROR;
        }
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaResumeOldCallReleaseSourceFail);
        return ERROR;
    }

    if (FOO.VF_SegmentationOfRrcMessages && ERROR == FnVCCB_CheckValidSegmentedUeForInterGnbRREandResume(ptCi))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi,
            "Target gNB doesn't support SegmentationOfRrcMessages and UE-NR-Capability(%d) is larger than 9K\n",
            ptCi->ueContainerNR_Ext.capaLength);
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerNonRelocationOfContext;

        nonUeAsn1ThreadFlag = FALSE;
        if (FnVCCB_SendXNMessage(XN_RetrieveUEContextFailure_id, ptCi, &nonUeAsn1ThreadFlag, nullptr) == ERROR)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendXNMessage(XN_RetrieveUEContextFailure_id) ERROR!\n");
            return ERROR;
        }
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalSaResumeOldCallReleaseSourceFail);  // FR340
        if (VCCB_CALL_RELEASE_TRIGGER(ptCi) != GOOD)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_CALL_RELEASE_TRIGGER ERROR!\n");
            VLIB_PutCi(ptCi);
        }
        return GOOD;
    }

    SET_STATE_CMD(RRCResume_cmd);

    status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

    VLIB_SetCurStateAll(ptCi, STATE_Inact_S_E1Mod_TxStop);
    VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);

    return GOOD;
}

int16_t FnVCCB_FinalizeRRCSuspend(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    switch (GET_RRC_STATE(ptCi))
    {
        case RRC_CONNECTED:
            if (VIIL_sendCallReleaseIndVccbVnmb(ptCi, eSuspend, ptCi->gnbCuUeId, ptCi->gnbCuUeId) != GOOD)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_sendCallReleaseIndVccbVnmb ERROR!\n");
            }

            // Decrease RRC Connected Call Count
            VRRM_delCellRrcConnectionCountWithMarkedInfo(ptCi);

            // Decrease PowerClass RRC Connected Call Count
            VRRM_delCellPowerClassRrcConnectionCountWithMarkedInfo(ptCi);

            // Increase RRC Inactive Call Count
            VRRM_addCellRrcInactiveCount(ptCi, ptCi->servCellNum);

            // Collect Scell CSL Before CSL message sending
            FnVCCB_SCellCslInfoUpdateByCallRelease(ptCi);

            // send CSL data to VTMB
            if (ERROR == VIIL_sendCSLDataNotiVccbVtmb(ptCi))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_sendCSLDataNotiVccbVtmb ERROR\n");
            }

            // INTRA_NR_ANR_24A - NCGI Report STAT
            if (IS_ANR_REPORT_CGI_IN_PROGRESS(ptCi)) // ANR purpose only, Not HO case
            {   
                VCCB_REPORT_CGI_STAT(ptCi, CGI_REPORT_RESULT_CANCEL, GET_REPORT_CGI_AUTONOMOUS_GAP_FLAG(ptCi));
            }

            // init sa Meas State
            VCCM_InitSaMeasData(ptCi);

            VLIB_InitMeasConfigPeriodicMeasurement(&ptCi->measurementsConfigShared.pa4m);
            VLIB_InitMeasConfigPeriodicMeasurement(&ptCi->measurementsConfigShared.lpm);
            VLIB_InitMeasConfigAltgap(&ptCi->measurementsConfigShared.altgap);
            VCCB_ClearUeMeasForSonSelection(ptCi);

            FnVCCB_InitMrsInfo(ptCi, MRS_ALL_INIT);
            FnVCCB_InitSccData(ptCi, SCC_ALL_INIT);
            SET_PCC_STATE(ptCi, PCC_NOT_SET);
            SET_IRATPCC_STATE(ptCi, IRatPCCState_Idle);

            // detach timer when RRC Inactive
            if (IS_TIMER_VALID(ptCi->anrInfo.reportCgiTimer)) VCCB_CLEAR_TIMER(&ptCi->anrInfo.reportCgiTimer, CANCEL_TIMER);
            if (ptCi->forcedHO.timer.id > 0) VCCB_CLEAR_TIMER(&ptCi->forcedHO.timer, CANCEL_TIMER);
            if (ptCi->saHoMrQueueInfo.t4.id > 0) VCCB_CLEAR_TIMER(&ptCi->saHoMrQueueInfo.t4, CANCEL_TIMER);
            if (ptCi->saHoMrQueueInfo.t5.id > 0) VCCB_CLEAR_TIMER(&ptCi->saHoMrQueueInfo.t5, CANCEL_TIMER);
            if (ptCi->saPriorHOTimer.id > 0) VCCB_CLEAR_TIMER(&ptCi->saPriorHOTimer, CANCEL_TIMER);
            VCCB_CLEAR_TIMER(&ptCi->measurementsConfigShared.pa4m.timer, CANCEL_TIMER);
            VCCB_CLEAR_TIMER(&ptCi->measurementsConfigShared.lpm.timer, CANCEL_TIMER);
            VCCB_CLEAR_TIMER(&ptCi->pccData.pccTmr, CANCEL_TIMER);
            VCCB_CLEAR_TIMER(&ptCi->pccData.slbTmr, CANCEL_TIMER);
            VCCB_CLEAR_TIMER(&ptCi->pccData.interRatWaitingTmr, CANCEL_TIMER);
            VCCB_CLEAR_TIMER(&ptCi->measurementsConfigShared.altgap.timer, CANCEL_TIMER);

            FnVCCB_InitNrConnectedMobilityControlInfo(*ptCi); 
            FnVCCB_InitSpecificSliceForcedMobilityInfo(*ptCi);

            FnVCCB_ClearUeHistoryInformation(ptCi);
            VCOM_DisableUPM(ptCi);
            FnVCCB_eraseAllocCallDbForRRE(ptCi);

            SET_RRC_STATE(ptCi, RRC_INACTIVE);
            break;

        case RRC_INACTIVE:
            if (RESUME_TYPE_INTER_GNB_TARGET != ptCi->ueInfo.rrcResumeInfo.resumeType)  // Intra gNB suspend only
            {
                // Decrease RRC Inactive Call Count for previous cell
                VRRM_delCellRrcInactiveCountWithMarkedInfo(ptCi);
            }

            // Increase RRC Inactive Call Count for current cell
            VRRM_addCellRrcInactiveCount(ptCi, ptCi->servCellNum);

            break;

        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid rRCState(%d) in %s\n", GET_RRC_STATE(ptCi), __FUNCTION__);
            break;
    }

    ComLibStatistic::calculateRRCHoldingTime(*ptCi, RRC_INACTIVE);

    SET_STATE_CMD(Idle_cmd);
    if (STATE_Inact_Suspend != ptCi->state)
    {
        VLIB_SetCurStateAll(ptCi, STATE_Inact_Suspend);
    }

    // timer for waiting the periodic RNA update
    if (ptCi->ueInfo.RrcInactiveInfo.guardTimer.id > 0)
    {
        VCCB_CLEAR_TIMER(&ptCi->ueInfo.RrcInactiveInfo.guardTimer, INIT_TIMER);
    }
    VLIB_AttachTimer(&ptCi->ueInfo.RrcInactiveInfo.guardTimer, ptCi, timNRRRC_RNAUpdate_id);

    // backup for the situation that VCCB has to full configuration when RRCResume happens in case of inter-gNB
    auto prevFullConfigRequiredFlag = ptCi->ueInfo.rrcResumeInfo.fullConfigRequiredFlag;

    VLIB_setBearerStatusToIdle(ptCi);
    FnVCCB_InitRRCResumeInfo(ptCi);

    if (prevFullConfigRequiredFlag == TRUE)
    {
        ptCi->ueInfo.rrcResumeInfo.fullConfigRequiredFlag = TRUE;
    }

    // SVR25A FGR-CC0108 (in order to restore the reduced rrc inactive timer value when UE is in RRC inactive)
    ptCi->ueNrRrcOtherConfig.newConfig.ueRelPrefConfig.releasePreferenceInactiveFlag = VCCB_FLAG_OFF;

    FnVCCB_UpdateRohcDrbCount(ptCi, ptCi->servCellNum, VCCB_STAT_RRC_INACTIVE);
    FnVCCB_UpdateEhcDrbCount(ptCi, VCCB_STAT_RRC_INACTIVE, ptCi->servCellNum);
    FnVCCB_FinalizeSaConnStat_AfterCleaningBearer(ptCi, ptCi->servCellNum, VCCB_STAT_RRC_INACTIVE);

    int16_t status = FnVCCB_Inact_Suspend_CheckEnqueuedAction(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_Inact_Suspend_CheckEnqueuedAction ERROR!\n");

    if (IS_USTM_ONGOING(ptCi))
    {
        VCCB_PRINT_LOG_USTM(ptCi, "Canceled due to suspend procedure\n");
        FnVCCB_USTM_Cancel(*ptCi);
    }

    return GOOD;
}

/**
 * @brief Finalize RRC Resume procedure
 * @param ptCi[in/out] callInfo
 * @return int16_t : GOOD/ERROR
 */
int16_t FnVCCB_FinalizeRRCResume(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (ptCi->ueInfo.rrcResumeInfo.resumeType == RESUME_TYPE_INTRA_GNB)
    {
        // Decrease RRC Inactive Call Count
        VRRM_delCellRrcInactiveCountWithMarkedInfo(ptCi);
    }
    else if (ptCi->ueInfo.rrcResumeInfo.resumeType == RESUME_TYPE_INTER_GNB_TARGET)
    {
        // Add Call Count
        VRRM_addCellCallCount(ptCi, ptCi->servCellNum);
        ptCi->endPointInfo.xnIdx = MAX_XN_NBR_PER_GNB;
    }

    // Increase RRC Connected Call Count
    VRRM_addCellRrcConnectionCount(ptCi, ptCi->servCellNum);

    // Increase PowerClass RRC Connected Call Count
    VRRM_addCellPowerClassRrcConnectionCount(ptCi, ptCi->servCellNum);

    if (ptCi->ueInfo.RrcInactiveInfo.resumeCause != NRRRC_rna_Update)
    {
        FnVCCB_Finalize_UeCapaEnquiryIfNeeded_ForSA(ptCi, ptCi->servCellNum, VCCB_FLAG_ON);
    }

    if (IsAvailable_MrdcInfo() == false)
    {
        FnVCCB_ReinstallMrdcBaseInfoAfterMobility(ptCi, ptCi->servCellNum, ptCi->servCellBand, 0xff);
    }

    // SVR22B FGR-CC0108 UAI
    VLIB_InitUeReleasePreference(ptCi);

    // SVR22B FGR-CC0108 UAI
    if (TRUE == FnVCCB_CheckAndMarkForChangeOfUeReleasePreference(ptCi, VCCB_FLAG_ON))
    {
        status = FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer(ptCi, FALSE, FALSE, ID_SRB1);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer ERROR !!\n");
        VLIB_AttachTimer(&ptCi->timer, ptCi, timNRRRC_RRCReconfig_id);
        VLIB_SetCurStateAll(ptCi, STATE_Inact_Reconfig);

        return GOOD;
    }

    status = FnVCCB_FinalizeRRCResumeExt(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_FinalizeRRCResumeExt ERROR !!\n");

    return GOOD;
}

int16_t FnVCCB_FinalizeRRCResumeExt(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;
    uint8_t sendPduNotiFlag = FALSE;
    uint8_t forcedMobilityFlag = FALSE;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // SVR25A: Store resumeType before potential reset
    const uint8_t resumeType = ptCi->ueInfo.rrcResumeInfo.resumeType;

    // Lambda to skip processing if INTER_GNB_TARGET
    auto skipForInterGnbTarget = [resumeType](auto&& fn) {
        if (resumeType == RESUME_TYPE_INTRA_GNB) {
            fn();
        }
    };

    // SVR25A User Inactivity for Redcap UE (by nicesys): shall be called before UserInactivityEvent_SIG_RESTART
    if (resumeType == RESUME_TYPE_INTER_GNB_TARGET)
        FnVCCB_UpdateUserInactConfigForRedcap(ptCi, FALSE);

    FnVCCB_UpdateUserInactStateAndDoActionIfExpiry(ptCi, UserInactivityEvent_SIG_RESTART);
    FnVCCB_UpdateUserInactStateAndDoActionIfExpiry(ptCi, UserInactivityEvent_DATA_RESTART);
    
    // SVR26A FGR-CC0103 FR720: slice-aware check!
    skipForInterGnbTarget([&]() {
        FnVCCB_CheckSliceAwareRREAndRRCResume_AfterFinalize(ptCi, &sendPduNotiFlag, &forcedMobilityFlag);
    });

    // set ptCi->state to STATE_Conn: RRC_Resumption is completed!!
    SET_STATE_CMD(Idle_cmd);
    VLIB_SetCurStateAll(ptCi, STATE_Conn);

    VCCB_PRINT_CALL_COMMENT(ptCi,
        "IS_SUPPORT_UE_CAPA_INFO FOO.VF_NrRachParaOpt: %d, CallType: %d, ueCapa IS_NRDC_SN: %d\n", FOO.VF_NrRachParaOpt,
        ptCi->callType, ptCi->ueInfo.ueCapa.nr.rachReportR16);
    // need to check that the following routine is only called in case that attachment, HO incoming, RRE and Resume are
    // completed
    if (IS_SUPPORT_UE_CAPA_INFO(ptCi))  // 21D: NR RACH Optimization
    {
        status = (int16_t)VCOM_SendNRRRC_UEInformationRequest(ptCi);
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_SendNRRRC_UEInformationRequest ERROR !!\n");
            return ERROR;
        }
    }

    VLIB_setBearerStatusToIdle(ptCi);
    FnVCCB_UpdateRohcDrbCount(ptCi, ptCi->servCellNum, VCCB_STAT_RRC_CONNECTED);
    FnVCCB_UpdateEhcDrbCount(ptCi, VCCB_STAT_RRC_CONNECTED, ptCi->servCellNum);
    FnVCCB_FinalizeSaConnStat_AfterCleaningBearer(ptCi, ptCi->servCellNum, VCCB_STAT_RRC_CONNECTED);
    VLIB_InitFullConfigurationInfo(ptCi);

    VLIB_ResetSliceLbInfo(ptCi); //SVR23B FGR-LC0710
    FnVCCB_SetSliceLbTriggerEvent(ptCi, S_Idle); //SVR23B FGR-LC0710

    // FGR-CC5500 Multi-Carrier Operation
    FnVCCB_RestartPccAfterHandover(ptCi);
    
    FnVCCB_InitCHOBlockList(ptCi);

    ptCi->ueInfo.securityModFlag = VCCB_FLAG_OFF;
    FnVCCB_InitRRCResumeInfo(ptCi);

    // CRR, If CRR exists, Change Normal
    MACRO_RESET_CALL_FAULT_CAUSES;

    ptCi->cslInfo.cslEvent = csl_event_undefined;

    //  1. State changed to CONN when E1 Mod response is received,
    //  2. Sending LRC failure indication taken care in VCCB_CALL_RELEASE_TRIGGER() in case if failure/timeout is
    //  received during RRC Resume procedure
    if ((ptCi->locRpt.reportOn == CI_use) && (STATE_Conn == ptCi->state) &&
        (ptCi->locRpt.isPagingReqForInactivity == TRUE))
    {
        if (ptCi->locRpt.eventType == ci_5g_Rpt_direct)
        {
            ptCi->locRpt.isPagingReqForInactivity = FALSE;
            ptCi->locRpt.reportOn = CI_no_use;
            auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_LocationReportAllAmf_id);
            VALID_E_POINT_CHECK_ERROR(ngapSender);
            if (ngapSender->sendMsg() == ERROR)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "sendMsg(NG_LocationReportAllAmf) ERROR !!\n");
                return ERROR;
            }
        }
    }

    if ((ptCi->isNrPpaContextValid == TRUE) && (STATE_Conn == ptCi->state) &&
        (ptCi->NrPpaContext.isPagingRequiredForECID == TRUE))
    {
        // Received ECIDMeasurementInitiationRequest with OnDemand and Measurement Quatity as Cell-ID .
        // We are ready to send the ECIDMeasurementInitiationResponse.
        status = VNIL_SendNGAP_NrPPaECIDMeasurementInitiationResponse(ptCi, ptCi->NrPpaContext.lMFUeMeasurementId);
        if (status == ERROR)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VNIL_SendNGAP_NrPPaECIDMeasurementInitiationResponse ERROR !!\n");
            return ERROR;
        }
        ptCi->isNrPpaContextValid = FALSE;
        ptCi->NrPpaContext.isPagingRequiredForECID = FALSE;
    }

    // SVR26A FGR-CC0103 FR720: added to check in case of DRB cases
    skipForInterGnbTarget([&]() {
        FnVCCB_UpdateQosFlowOfPartialDrb(ptCi, sendPduNotiFlag);
    });

    status = GOOD;  // initialize

    // SVR26A FGR-CC0103 FR720: release the failed bearers caused by the unsupported slices during intra-gNB resume only
    skipForInterGnbTarget([&]() {
        const bool isPduReleaseNeeded = VHCM_CheckPduSessionReleaseInfo(ptCi, e_ReleaseTriggerForFindAllCause) == TRUE;
        const bool isQosReleaseNeeded = VHCM_CheckQosFlowReleaseInfo(ptCi, e_ReleaseTriggerForFindAllCause) == TRUE;

        if (isPduReleaseNeeded || isQosReleaseNeeded)
        {
            uint32_t msgId = NRRRC_RrcResumeRequest1_id;
            VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                "[RRCInactive] After RRC resume completion, the bearer release procedure follows. (msgId: %u)\n", msgId);
            status = VHCM_TriggerPduReleaseWithReleaseEvent(ptCi, msgId, sendPduNotiFlag);
        }
    });

    if (status == ERROR)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "VHCM_TriggerPduReleaseWithReleaseEvent(Resume) ERROR!\n");
        return ERROR;
    }
    else if (status == BREAK)
    {
        return GOOD;
    }

    // SVR26A FGR-CC0103 FR730: queueing the action for the forced mobility in case of unsupported specific slices
    skipForInterGnbTarget([&]() {
        if (forcedMobilityFlag)
        {
            uint16_t qMsgId = ptCi->qInfo.qMsgId;
            ptCi->qInfo.qMsgId = NRRRC_RrcResumeRequest1_id;

            if (GOOD == VCCM_enqueueActionWithForce(ptCi, ENQUEUE_ACTION_SPECIFIC_SLICE_FORCED_MOBILITY, true))
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                    "ENQUEUE_ACTION(ENQUEUE_ACTION_SPECIFIC_SLICE_FORCED_MOBILITY) by RRC resume !!\n");
            }
            else
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "ENQUEUE_ACTION(ENQUEUE_ACTION_SPECIFIC_SLICE_FORCED_MOBILITY) by RRC resume ERROR !!\n");
                ptCi->qInfo.qMsgId = qMsgId;
            }
        }
    });

    return GOOD;
}

template <typename T>
void FnVCCB_ALL_NgapStorePPI(callInfo_type *ptCi, T *ptUnpack)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptUnpack);

    if (ptUnpack->m.rANPagingPriorityPresent && ptUnpack->rANPagingPriority != 0)  // rANPagingPriority (1...256)
    {
        ptCi->ueInfo.RrcInactiveInfo.ppi = (uint8_t)(ptUnpack->rANPagingPriority - 1) / 32;
    }
    else
    {
        ptCi->ueInfo.RrcInactiveInfo.ppi = 0xFF;
    }
}

int16_t FnVCCB_Inact_Suspend_ProcRrcInactiveTransitionReport(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    NG_UEContextModificationRequestAmfAll_type *ptMsg = reinterpret_cast<NG_UEContextModificationRequestAmfAll_type *>(ptUnpack->unpack);

    if (TRUE == FnVCCB_Check_OnlyRrcInactiveTransitionReportRequestIncluded(ptCi, ptMsg))
    {
        FnVCCB_Store_NG_RrcInactiveTransitionReportRequest(
            ptCi, ptMsg->rRCInactiveTransitionReportRequest, NG_UEContextModificationRequestAmfAll_id);

        auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_UEContextModificationResponseAllAmf_id);
        VALID_E_POINT_CHECK_ERROR(ngapSender);
        if (ERROR == ngapSender->sendMsg())
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "sendMsg(NG_UEContextModificationResponseAllAmf) ERROR !!\n");

            // initialize
            INIT_RRC_INACTIVE_TRANSITION_REPORT(ptCi);

            // check if return ERROR, call would be released..
            return ERROR;
        }

        // SVR22B: FGR-CC0103
        if (ptCi->ueInfo.RrcInactiveInfo.newInactReportType == NGAP_cancel_report)
        {
            INIT_RRC_INACTIVE_TRANSITION_REPORT(ptCi);
        }
        else
        {
            ptCi->ueInfo.RrcInactiveInfo.oldInactReportType = ptCi->ueInfo.RrcInactiveInfo.newInactReportType;
        }
        return BREAK;
    }
    return GOOD;
}
