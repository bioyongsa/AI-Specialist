// ============================================================
// VccbAiEngine.cpp
// - GRU Feed Forward Inference Engine 
// ============================================================
#include "VccbAiEngine.h"
#include "VccbAiWeights.h"
#include <string.h>
#include <cstring>
#include <cmath>

using namespace VccbAiWeights;

// ──────────────────────────────────────────
// internal utility functions
// ──────────────────────────────────────────

// sigmoid
static inline float sigmoid(float x)
{
    return 1.0f / (1.0f + expf(-x));
}

// tanh
static inline float tanhf_wrap(float x)
{
    return tanhf(x);
}

// relu
static inline float relu(float x)
{
    return x > 0.0f ? x : 0.0f;
}

// vector inner-product + bias
// result = weight[row] · vec + bias[row]
static float dot(const float* weight, const float* vec, int vec_size, int row)
{
    float sum = 0.0f;
    const float* w = weight + row * vec_size;

    for (int i = 0; i < vec_size; i++)
    {
        sum += w[i] * vec[i];
    }
    return sum;
}

// ──────────────────────────────────────────
// GRU unity step
// ──────────────────────────────────────────
// PyTorch GRU date sequence: [reset | update | new]
// r = sigmoid(W_ir * x + b_ir + W_hr * h + b_hr)
// z = sigmoid(W_iz * x + b_iz + W_hz * h + b_hz)
// n = tanh   (W_in * x + b_in + r * (W_hn * h + b_hn))
// h = (1 - z) * n + z * h
static void gru_step(const float *x,    // input        [SEQ_INPUT]
                     float       *h,    // hidden state [HIDDEN] (in/out)
                     int          input_size,
                     int          hidden_size)
{
    // offset per gate
    const int R = 0;
    const int Z = hidden_size;
    const int N = hidden_size * 2;

    // reset gate
    float r[16] = {};
    for (int i = 0; i < hidden_size; i++)
    {
        float val = dot(GRU_WEIGHT_IH, x, input_size, R + i) + GRU_BIAS_IH[R + i]
                  + dot(GRU_WEIGHT_HH, h, hidden_size, R + i) + GRU_BIAS_HH[R + i];
        r[i] = sigmoid(val);
    }

    // update gate
    float z[16] = {};
    for (int i = 0; i < hidden_size; i++)
    {
        float val = dot(GRU_WEIGHT_IH, x, input_size, Z + i) + GRU_BIAS_IH[Z + i]
                  + dot(GRU_WEIGHT_HH, h, hidden_size, Z + i) + GRU_BIAS_HH[Z + i];
        z[i] = sigmoid(val);
    }

    // new gate
    float n[16] = {};
    for (int i = 0; i < hidden_size; i++)
    {
        float hh = dot(GRU_WEIGHT_HH, h, hidden_size, N + i) + GRU_BIAS_HH[N + i];
        float val = dot(GRU_WEIGHT_IH, x, input_size, N + i) + GRU_BIAS_IH[N + i]
                  + r[i] * hh;
        n[i] = tanhf_wrap(val);
    }

    // hidden state update
    for (int i = 0; i < hidden_size; i++)
    {
        h[i] = (1.0f - z[i]) * n[i] + z[i] * h[i];
    }
}

// ──────────────────────────────────────────
// initialization
// ──────────────────────────────────────────
void VccbAiEngine_Init()
{
    // currently, not required for the initialization
    // weights: inside as a constant define in VccbAiWeights.h
}

// ──────────────────────────────────────────
// inference function
// ──────────────────────────────────────────
bool VccbAiEngine_Infer(const VccbAiInput& input, VccbAiOutput& output)
{
    for (int t = 0; t < SEQ_LEN; t++)
    {
        for (int j = 0; j < SEQ_INPUT_SIZE; j++)
        {
            if (not std::isfinite(input.seq[t][j]))
                return false;
        }
    }

    for (int i = 0; i < STATIC_INPUT_SIZE; i++)
    {
        if (not std::isfinite(input.stat[i]))
            return false;
    }

    const int hidden  = HIDDEN_SIZE;
    const int seq_in  = SEQ_INPUT_SIZE;
    const int stat_in = STATIC_INPUT_SIZE;
    const int seq_len = SEQ_LEN;

    // ── GRU feed forward ──
    float h[16] = {};   // hidden state initlization (0)

    for (int t = 0; t < seq_len; t++)
    {
        gru_step(input.seq[t], h, seq_in, hidden);
    }
    // h = GRU final output [hidden]

    // ── MLP feed forward ──
    float mlp_out[16] = {};
    for (int i = 0; i < hidden; i++)
    {
        float val = dot(MLP_WEIGHT, input.stat, stat_in, i) + MLP_BIAS[i];
        mlp_out[i] = relu(val);
    }

    // ── combination ──
    // combined = [h(0..15), mlp_out(0..15)] size: hidden*2
    float combined[32] = {};
    for (int i = 0; i < hidden; i++)
    {
        combined[i]          = h[i];
        combined[i + hidden] = mlp_out[i];
    }

    // ── output head ──
    int combined_size = hidden * 2;

    // resume probability
    float prob_val = dot(HEAD_PROB_WEIGHT, combined, combined_size, 0) + HEAD_PROB_BIAS[0];
    output.resume_prob = sigmoid(prob_val);

    // resume time
    float time_val = dot(HEAD_TIME_WEIGHT, combined, combined_size, 0) + HEAD_TIME_BIAS[0];
    output.resume_time = time_val;

    return true;
}

extern "C" void VccbAi_InitContext(VccbAiCallContext_type *ctx)
{
    if (ctx == NULL) return;

    // all array, scalar => 0
    memset(ctx, 0, sizeof(VccbAiCallContext_type));

    ctx->resumeSuccessRate = 1.0f;  // cold start
}
