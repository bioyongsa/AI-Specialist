#include "MainInit.h"
#include "MainAuditTask.h"
#include "MainTask.h"
#include "MainCallTask.h"
#include "MainLogTask.h"
#include "MainMainTask.h"
#include "MainNonUeTask.h"
#include "MainNonUeAsn1Task.h"
#include "MainOamTask.h"
#include "MainPldTask.h"
#include "MainSubscriptionTask.h"
#include "MainRedisBackupTask.h"
#include "MainRedisRestoreTask.h"
#include "MainStatisticsTask.h"
#include "MainRacsTask.h"

#include "ComInclude.h"
#include "ComLibUtility.h"
#include "ComCslCauseMap.h"
#include "ComTimeUtil.h"
#include "ComEndian.h"
#include "StatIndexMapper.h"

#include "CallIdManager.h"
#include "MsgQueueManager.h"

#include "FeatCommon.h"
#include "FeatCa.hpp"
#include "FeatRre.h"
#include "FeatMrdc.h"
#include "FeatCallInfo.h"
#include "FeatCallProc.h"
#include "FeatFullConfig.h"
#include "FeatRrcSegment.h"
#include "FeatTrafficMeasurements.hpp"
#include "FeatHo.h"
#include "FeatLtmHo.h"
#include "FeatLb.hpp"

#include "StateCommon.h"
#include "StateF1ap.h"
#include "StateCommand.h"
#include "StateMeasurements.h"
#include "StateHandleMrdcSN.h"
#include "StateHandleSaHoSN.h"
#include "StateHandleAll.h"
#include "StateHandleSa.h"
#include "StateHandleSaMrdc.h"
#include "StateHandleNsa.h"
#include "StateHandleSaRre.h"
#include "StateHandleSaHo.h"

#include "CdbFoo.h"
#include "CdbPldReader.h"
#include "CdbPldSubscription.h"
#include "CdbDalReader.h"
#include "CdbDalNotification.h"
#include "CdbDalSubscription.h"

#include "nrrrcUtil.h"
#include "lppUtil.h"
#include "x2apLog.h"
#include "xnapLog.h"
#include "ngapLog.h"
#include "nrppaLog.h"

#include "VpmInterface.h"
#include "shmem.h"
#include "K8sInterface.h"
#include "HasInterface.h"
#include "VccbAiClient.h"

/* ---------------------------------------------------------------------------
 * Define    :    MW Global Variables
 * ---------------------------------------------------------------------------
 */

#ifndef IPC_TEST
/**
 * @brief THS initialization
 */
//{Usage,ThsTaskPri,ThsMbox,BlkName,MainTaskPri(Default:50)}
static ThsInit_Type ThsInitParam = {USING_SERV, NULL_VAL, VCCB_INT_THS_MBOX, VCCB_BLK_NAME, NULL_VAL};

/**
 * @brief MFS initialization
 */
//{Usage,MfsTaskPri,MfsMbox,Ver}
static MfsInit_Type MfsInitParam = {USING_SERV, NULL_VAL, VCCB_INT_MFS_MBOX, "1.0"};

/**
 * @brief MDS initialization
 */
//{Usage,MdsTaskPri,MdsMbox,NumOfFlow,NeType}
static MdsInit_Type MdsInitParam = {
    USING_SERV, NULL_VAL, VCCB_INT_MDS_MBOX, NULL_VAL, NULL_VAL, NULL_VAL, NULL_VAL, NULL_VAL};

/**
 * @brief ENS initialization
 */
//{Usage,EnsTaskPri,EnsMbox,NumOfTimer,TickResolution,SendMsgPerTick}
#if !defined(NEW_HOST_SIM) || (defined(__CNF__) && !defined(IPC_TEST))
static EnsInit_Type EnsInitParam = {USING_SERV, (THS_DEFAULT_MAINTASKPRI + 90), VCCB_INT_ENS_MBOX,
    (MAX_CALL_COUNT_PER_CPC * 2) / VCCB_CALL_THREAD_NUM, 1, NULL_VAL};
#else
static EnsInit_Type EnsInitParam = {
    USING_SERV, (THS_DEFAULT_MAINTASKPRI + 90), VCCB_INT_ENS_MBOX, MAX_CALL_COUNT_PER_CPC * 2, 1, NULL_VAL};
#endif

/**
 * @brief DUS initialization
 */
static DusInit_Type DusInitParam = {USING_SERV, NULL_VAL, VCCB_INT_DUS_MBOX};

/**
 * @brief HAS initialization
 */
#if defined(__NVGNB__)
static HasInit_Type HasInitParam = {NON_USING_SERV, NULL_VAL, VCCB_INT_HAS_MBOX, HAS_NONBLOCKED, USING_BACKUP};
#elif defined(__CNF__)
static HasInit_Type HasInitParam = {USING_SERV, NULL_VAL, VCCB_INT_HAS_MBOX, HAS_NONBLOCKED, NON_USING_BACKUP};
#else
static HasInit_Type HasInitParam = {
    USING_SERV, (THS_DEFAULT_MAINTASKPRI + 90), VCCB_INT_HAS_MBOX, HAS_NONBLOCKED, USING_THREAD_BACKUP};
#endif

/**
 * @brief VCCB middleware initialization
 */
static MwInit_Type VccbMwInitParam = {
    &ThsInitParam, &MfsInitParam, &MdsInitParam, &EnsInitParam, &DusInitParam, &HasInitParam};
#endif

/**
 * @brief VCCB Handle initialization
 */
// enumVccbHandleInit_type
//{Protocol,Dscp,*pIpType,ProcessorType,ProcessorId,MBox,Handle,Port}
static HandleInit_Type VccbHandleInitParam[] = {
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_OUTMOST_MBOX, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_REDIS_RESTORE_MBOX, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_MGMT_MBOX, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_PLD_MBOX, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_LOG_MBOX, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_1, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_2, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_3, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_4, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_5, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_6, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_7, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_8, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_9, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_10, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_11, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_12, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_13, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_14, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_15, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_16, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_17, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_18, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_19, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_20, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_21, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_22, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_23, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_24, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_25, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_26, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_27, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_28, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_29, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_30, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_31, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_32, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_33, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_34, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_35, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_36, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_37, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_38, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_39, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_40, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_41, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_42, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_43, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_44, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_45, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_46, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_47, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_48, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_CALL_MBOX_49, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_01, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_02, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_03, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_04, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_05, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_06, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_07, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_08, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_09, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_10, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_11, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_12, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_13, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_14, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_15, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_16, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_17, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_18, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_19, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_20, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_21, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_22, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_23, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_24, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_25, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_26, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_27, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_28, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_29, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_30, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_31, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_32, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_33, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_34, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_35, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_36, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_37, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_38, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_39, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_40, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_41, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_42, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_43, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_44, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_45, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_46, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_47, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_48, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_CALL_CSLTRACE_MBOX_49, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_KA_MBOX, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_OUTMOST_MBOX, 0,
        0},  // If nanomsg is applied in NVGNB, vccbExt should be deleted.
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_NONUE_MBOX, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_NONUE_BIGMSG_MBOX, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_NONUE_ASN1_MBOX_01, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_STATISTICS_MBOX, 0, 0},

    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_EXT_RACS_BIGMSG_MBOX, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_RACS_MBOX, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_RACS_BIGMSG_MBOX_01, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_RACS_BIGMSG_MBOX_02, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_RACS_BIGMSG_MBOX_03, 0, 0},
    {MDS_ATTR_PROTO_UDP, DSCP_IPC, "IIIP", 0, 0, VCCB_INT_RACS_BIGMSG_MBOX_04, 0, 0},
#ifdef __NVGNB__
//
// NVGNB currently uses 10 threads. (MAX_CALL_THREAD_NUM_VCCB:10)
//
#endif
    {NULL_VAL, 0, NULL, 0, 0, 0, 0, 0}};

/*****************************************************************************
 * TASK Variable :: Defines variables used only in Task.
 ****************************************************************************/
// {{{
static TaskInit_Type VccbTaskInitParam[] = {{"tVccx", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_MainTask, 0},
    {"tNonUe", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_NonUeTask, 0},
    {"tNonUeAsn1", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_NonUeAsn1Task, 0},
    {"tOam", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_OamTask, 0},
    {"tPld", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_PldTask, 0},
    {"tAudit", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_AuditTask, 0},
    {"tSub", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_SubscriptionTask, 0},
    {"tLog", 0, (THS_DEFAULT_MAINTASKPRI + 89), FnVCCB_LogTask, 0},
    {"tStat", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_StatisticsTask, 0},
#ifndef __NVGNB__
    {"tRacs", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_RacsTask, 0},
#endif
#ifdef __CNF__
    {"tRedisBackup", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_RedisBackupTask, 0},
    {"tRedisRestore", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_RedisRestoreTask, 0},
#endif
    {"tCall_0", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 0},
    {"tCall_1", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 1},
    {"tCall_2", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 2},
    {"tCall_3", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 3},
    {"tCall_4", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 4},
    {"tCall_5", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 5},
    {"tCall_6", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 6},
    {"tCall_7", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 7},
    {"tCall_8", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 8},
    {"tCall_9", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 9},
    {"tCall_10", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 10},
    {"tCall_11", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 11},
    {"tCall_12", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 12},
    {"tCall_13", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 13},
    {"tCall_14", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 14},
    {"tCall_15", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 15},
    {"tCall_16", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 16},
    {"tCall_17", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 17},
    {"tCall_18", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 18},
    {"tCall_19", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 19},
    {"tCall_20", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 20},
    {"tCall_21", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 21},
    {"tCall_22", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 22},
    {"tCall_23", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 23},
    {"tCall_24", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 24},
    {"tCall_25", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 25},
    {"tCall_26", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 26},
    {"tCall_27", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 27},
    {"tCall_28", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 28},
    {"tCall_29", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 29},
    {"tCall_30", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 30},
    {"tCall_31", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 31},
    {"tCall_32", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 32},
    {"tCall_33", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 33},
    {"tCall_34", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 34},
    {"tCall_35", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 35},
    {"tCall_36", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 36},
    {"tCall_37", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 37},
    {"tCall_38", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 38},
    {"tCall_39", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 39},
    {"tCall_40", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 40},
    {"tCall_41", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 41},
    {"tCall_42", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 42},
    {"tCall_43", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 43},
    {"tCall_44", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 44},
    {"tCall_45", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 45},
    {"tCall_46", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 46},
    {"tCall_47", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 47},
    {"tCall_48", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 48},
    {"tCall_49", 0, (THS_DEFAULT_MAINTASKPRI + 90), FnVCCB_CallTask, 49},
#ifdef __NVGNB__
//
// NVGNB currently uses 10 threads. (MAX_CALL_THREAD_NUM_VCCB:10)
//
#endif
    {NULL, 0, 0, NULL, 0}};

static TaskInit_Type taskEnd = {NULL, 0, 0, NULL, 0};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                   ####     ##    #    #   #####     #     ####   #       #
//                  #    #   #  #   #    #     #       #    #    #  #       #
//                  #    #  #    #  #    #     #       #    #    #  ##      #
//                  #       #    #  #    #     #       #    #    #  # #     #
//                  #       #    #  #    #     #       #    #    #  #  #    #
//                  #       #    #  #    #     #       #    #    #  #   #   #
//                  #       ######  #    #     #       #    #    #  #    #  #
//                  #       #    #  #    #     #       #    #    #  #     # #
//                  #    #  #    #  #    #     #       #    #    #  #      ##
//                  #    #  #    #  #    #     #       #    #    #  #       #
//                   ####   #    #   ####      #       #     ####   #       #
//
// <Field Problem Action Item>
// If you have added a new state/stateCmd
// You must consider the race-condition situation that may occur in this state/stateCmd and implement follow-up actions
// Option.1) Queuing the incoming message that caused the race-condition.
// Option.2) Cancel the ongoing action and process the received message.
// Option.3) The message can be ignored depending on the type and importance of the received message.
//
// Please be sure to be aware of the above precautions before updating the following maxState/maxStateCmd.
static const int vccbMaxState = 378, vccbMaxStateCmd = 76; // This value shall be decimal rather than enumValue(i.g. MAX_VCCB_STATE, MAX_VCCB_STATE_COMMAND)
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// }}}

void FnVCCB_InitBlock(void)
{
    AUTO_TRACE_FUNC;

    int result = 0;

#ifdef IPC_TEST
#else
    int retryCount = 0;

    timeRecord_type shmCreateStart;
    timeRecord_type loadingStart;

    FnVCCB_RecordTime(&loadingStart);
    /* Set log file size */
    result = dusSetLogFileSize(DUS_MAX_LOGFILE_SIZE / 1000);  // #define DUS_MAX_LOGFILE_SIZE 3000000 [byte]
    VCCB_CHECK_RTCODE_KEEP(result, "dusSetLogFileSize");

    FnVCCB_RecordTime(&shmCreateStart);
    result = FnVCCB_AllocateVccbMemory();
    VCCB_CHECK_RTCODE_EXIT(result, "FnVCCB_AllocateVccbMemory", EXIT_SHM_CREATE_FAIL);

    ENV->vccbInitTime.shmCreateStart = shmCreateStart;
    ENV->vccbInitTime.loadingStart = loadingStart;

    FnVCCB_RecordTime(&ENV->vccbInitTime.shmCreateEnd);
    FnVCCB_RecordTime(&ENV->vccbInitTime.initBaseStart);

    // Get Dynamic Foo
    result = FnVCCB_ReadDynamicFoo();
    VCCB_CHECK_RTCODE_EXIT(result, "FnVCCB_ReadDynamicFoo", EXIT_MW_INIT);
#endif

    // Get Flavor Info.
    result = FnVCCB_LoadDeploymentFlavor();
    VCCB_CHECK_RTCODE_EXIT(result, "FnVCCB_LoadDeploymentFlavor", EXIT_FLAVOR_GET_FAIL);

    // Initialize variables related to Flavor information
    FnVCCB_InitVccbFlavorInfo();

#ifdef IPC_TEST
#else
    /* Allocate VCCB memory related flavor */
    result = FnVCCB_AllocateVccbMemoryRelatedFlavor();
    VCCB_CHECK_RTCODE_EXIT(result, "FnVCCB_AllocateVccbMemoryRelatedFlavor", EXIT_SHM_CREATE_FAIL);
#endif

    // This function declares a common initialization part that is called for both REAL and SIM environments.
    // MUTEX INIT
    FnVCCB_InitMutex();

    // Allocate buffer pool
    result = VLIB_InitBuffMgmt();
    VCCB_CHECK_RTCODE_EXIT(result, "VLIB_InitBuffMgmt", EXIT_OUT_OF_MEMORY);

    FnVCCB_InitVccbMemory();

#if (!defined(NEW_HOST_SIM) || defined(__CNF__)) && !defined(IPC_TEST)  // REAL gNB
    /* Initialize Middleware */
    VCCB_PRINTF("VCCB Initialize Middleware...\n");

    /* Initialize MwInitParam. */
    // ens NumOfTimer will be used in each core.
    // NumOfTimer : (max ue * 2) / call thread
    // Total Timer : NumOfTimer * (input argument of ensSetMultiCoreSize)
    // EnsInitParam.NumOfTimer = (VCCB_MAX_CALL_COUNT_PER_CPC*2)/MAX_CALL_THREAD_NUM_VCCB;
    VccbMwInitParam.pEns->NumOfTimer = (int)((VCCB_MAX_CALL_COUNT_PER_CPC * 2) / MAX_CALL_THREAD_NUM_VCCB);

    // CAUTION : MULTI_CORE_SIZE is MAX.
    result = ensSetMultiCoreSize(MIN(MULTI_CORE_SIZE, (MAX_CALL_THREAD_NUM_VCCB + 1)));
    VCCB_CHECK_RTCODE_EXIT(result, "ensSetMultiCoreSize", EXIT_MW_INIT);
#endif
#ifndef IPC_TEST
    for (retryCount = 0; retryCount < VCCB_MAX_MW_RETRY_COUNT; retryCount++)
    {
        result = MwInitFunc(&VccbMwInitParam);
        VCCB_CHECK_RTCODE_SLEEP(result, "MwInitFunc", retryCount);
    }
    VCCB_CHECK_RTCODE_EXIT(result, "MwInitFunc", EXIT_MW_INIT);

#ifdef __CNF__
    result = mfsSetCoreDumpFilter(MFS_COREDUMP_FILTER_SITE_SMALL_CORE);
    if (result < 0)
    {
        VCCB_PRINTF("SetCoreDumpFilter Err: %d\n", result);
    }
#endif

#ifdef __CNF__
    result = mfsSystem("mkdir -p /var/log/subsystem/call/VCCB");
    if (result < 0)
    {
        VCCB_PRINTF("mkdir Err: %d\n", result);
    }
#endif

    /* Open UDP/TCP port HandleInitFunc */
    result = FnVCCB_InitMdsHandle();
    VCCB_CHECK_RTCODE_EXIT(result, "FnVCCB_InitMdsHandle", EXIT_HANDLE_INIT);
#endif

    // Initialize VCCB ==========================================
    //  - Read PLD
    //  - Get Dest IP & Port
    //  - Initialize global data
    FnVCCB_InitGlobalData();

    // RRC State Predictor - 추론 엔진 및 AI Client 전역 상태 초기화
    VccbAiEngine_Init();
    VccbAiClient_Reset();

    /* Allocate VCCB memory related flavor */
    result = FnVCCB_AllocateVccbMemoryRelatedYang();
    VCCB_CHECK_RTCODE_EXIT(result, "FnVCCB_AllocateVccbMemoryRelatedYang", EXIT_SHM_CREATE_FAIL);

    // Provides a function to operate OAM_API.
    FnVCCB_InitOamApiHandle();

#ifdef __VNF__
    VRRM_setCpcUsageState(idle);
#endif

    x2apSetUserPrintfFun(FnVCCB_AsnPrint);
    f1apSetUserPrintfFun(FnVCCB_AsnPrint);
    nrrrcSetUserPrintfFun(FnVCCB_AsnPrint);
    e1apSetUserPrintfFun(FnVCCB_AsnPrint);
    lppSetUserPrintfFun(FnVCCB_AsnPrint);
    xnapSetUserPrintfFun(FnVCCB_AsnPrint);
    ngapSetUserPrintfFun(FnVCCB_AsnPrint);
    nrppaSetUserPrintfFun(FnVCCB_AsnPrint);

    makeStatIndexMap();
    // ==========================================================

    // for IoDT initializing without PLD...

    // TODO : CFG->vnb.cfg.sysType, CFG.vnb.boardType check is required??

#ifdef IPC_TEST
#else
    HasUnitState_Type prevHasCpc;
    if (FALSE == VCOM_IsHostSim() && e_VCCB_ACPF_VNF == VCOM_getSystemType())
    {
        memcpy(&prevHasCpc, &CFG->hasCpc, sizeof(HasUnitState_Type));

        // Get HAS State of CPC again - protection code for delayed VCCB_BlockInit
        result = hasGetState(HAS_UNIT_STATE, &CFG->hasCpc);
        VCCB_CHECK_RTCODE_EXIT(result, "hasGetState", EXIT_HAS_GET_STATE_FAIL);

        if (FnVCCB_IsSwitchoverTransition(CFG->hasCpc, prevHasCpc))
        {
            FnVCCB_UpdateVnfHasHistory(NULL, &CFG->hasCpc, TRUE);
        }
    }

    /* Create Thread */
    VCCB_PRINTF("VCCB Task(thread) Init...\n");

    result = FnVCCB_CreateTask();
    VCCB_CHECK_RTCODE_EXIT(result, "FnVCCB_CreateTask", EXIT_INIT_TASK);
    FnVCCB_RecordTime(&ENV->vccbInitTime.loadingEnd);
    VCCB_PRINTF("VCCB Create Task Done!!!\n");
    VCCB_PRINT_CRITICAL("VCCB Create Task Done!!!\n");
    VCCB_ONE_LOG_PRINT(LC_INIT, lc_vccbRestarted, "VCCB Create Task Done!!!\n");

    // Send StartAckNoti message to SWM to notify VCCB loading is completed
    if (FALSE == VCOM_IsHostSim() && e_VCCB_ACPF_VNF == VCOM_getSystemType())
    {
        FnVCCB_SendStartAckNoti();
    }

    FnVCCB_RegisterDebugCommands();
#endif

    FnVCCB_initAlarmApi();

    return;
}

int FnVCCB_IsShm64Mode(size_t size, bool *pIsMode64)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pIsMode64);

    if (size <= MAX_SHM_SIZE)  // <= 2GB
    {
        *pIsMode64 = false;
        return GOOD;
    }

    if (size <= MAX_SHM_SIZE64)  // <= 32GB
    {
        *pIsMode64 = true;
        return GOOD;
    }

    // > 32GB
    return ERROR;
}

template <typename T>
int FnVCCB_callShmCreate(const char *ptNameOfAllocBuffer, size_t sizeOfAllocBuffer, T **ptPointerOfAllocBuffer)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptNameOfAllocBuffer);
    VALID_E_POINT_CHECK_ERROR(ptPointerOfAllocBuffer);

    bool isMode64 = false;
    int status = GOOD;

    status = FnVCCB_IsShm64Mode(sizeOfAllocBuffer, &isMode64);
    VCCB_RETURN_ON_ERROR(
        status, "Memory Size is Too Big (%lu, %lu, %lu) in %s\n", sizeOfAllocBuffer, MAX_SHM_SIZE, MAX_SHM_SIZE64, __func__);

    if (isMode64 == true)
    {
        *ptPointerOfAllocBuffer = (T *)callShmCreate64(ptNameOfAllocBuffer, sizeOfAllocBuffer);
        return GOOD;
    }

    *ptPointerOfAllocBuffer = (T *)callShmCreate(ptNameOfAllocBuffer, sizeOfAllocBuffer);
    return GOOD;
}

template <typename T>
int FnVCCB_callShmReadWriteFromFile(
    const char *ptNameOfAllocBuffer, size_t sizeOfAllocBuffer, T **ptPointerOfAllocBuffer, int *ptRtCode)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptNameOfAllocBuffer);
    VALID_E_POINT_CHECK_ERROR(ptPointerOfAllocBuffer);
    VALID_E_POINT_CHECK_ERROR(ptRtCode);

    bool isMode64 = false;
    int status = GOOD;

    status = FnVCCB_IsShm64Mode(sizeOfAllocBuffer, &isMode64);
    VCCB_RETURN_ON_ERROR(
        status, "Memory Size is Too Big (%lu, %lu, %lu) in %s\n", sizeOfAllocBuffer, MAX_SHM_SIZE, MAX_SHM_SIZE64, __func__);

    if (isMode64 == true)
    {
        *ptPointerOfAllocBuffer =
            (T *)callShmReadWriteFromFile64("/dev/shm/", ptNameOfAllocBuffer, sizeOfAllocBuffer, ptRtCode);
        return GOOD;
    }

    *ptPointerOfAllocBuffer =
        (T *)callShmReadWriteFromFile("/dev/shm/", ptNameOfAllocBuffer, sizeOfAllocBuffer, ptRtCode);
    return GOOD;
}

template <typename T>
int FnVCCB_GetShmMemory(const char *ptNameOfAllocBuffer, size_t sizeOfAllocBuffer, T **ptPointerOfAllocBuffer)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptNameOfAllocBuffer);
    VALID_E_POINT_CHECK_ERROR(ptPointerOfAllocBuffer);

    int status = GOOD;
    int rtCode = 0;

    T *ptMem = NULL;

    bool is64Mode = false;

    status = FnVCCB_IsShm64Mode(sizeOfAllocBuffer, &is64Mode);
    VCCB_RETURN_ON_ERROR(
        status, "Memory Size is Too Big (%lu, %lu, %lu) in %s\n", sizeOfAllocBuffer, MAX_SHM_SIZE, MAX_SHM_SIZE64, __func__);

    VCCB_PRINTF(
        "** Get Shared Memory(Name:%s, Size:%ld 64Mode:%d)\n", ptNameOfAllocBuffer, sizeOfAllocBuffer, (int)is64Mode);

    status = FnVCCB_callShmReadWriteFromFile(ptNameOfAllocBuffer, sizeOfAllocBuffer, &ptMem, &rtCode);
    VCCB_RETURN_ON_ERROR(status, "FnVCCB_callShmReadWriteFromFile Error!\n");

    // Case 1) Memory is allocated, but the size is different from the previous one.
    //         Allows the memory to be expanded by "Case 2)".
    if (rtCode == -1)
    {
        // This address is not actually an allocated memory address.
        VCCB_PRINTF("Memory Size is different, previous memory free.\n");
        ptMem = NULL;
    }

    // Case 2) If memory allocation is required, proceed with the memory allocation procedure.
    if (ptMem == NULL)
    {
        status = FnVCCB_callShmCreate(ptNameOfAllocBuffer, sizeOfAllocBuffer, &ptMem);
        if (status == ERROR)
        {
            VCCB_PRINTF(
                "FnVCCB_callShmCreate(%s, %ld) Error! (rtCode=%u)\n", ptNameOfAllocBuffer, sizeOfAllocBuffer, rtCode);
            return ERROR;
        }

        if (ptMem == NULL)
        {
            VCCB_PRINTF("FnVCCB_callShmCreate(%s, %ld) Allocation Fail! (rtCode=%u)\n", ptNameOfAllocBuffer,
                sizeOfAllocBuffer, rtCode);
            return ERROR;
        }

        if (rtCode == -1)
        {
            VCCB_PRINTF("Full initialization according to memory expansion.\n");
            memset(ptMem, 0, sizeOfAllocBuffer);
        }
        else if (is64Mode)
        {
            VCCB_PRINTF("memset(0) triggered in 64Mode\n");
            memset(ptMem, 0, sizeOfAllocBuffer);
        }

        *ptPointerOfAllocBuffer = ptMem;
        return GOOD;
    }

    // Case 3) Memory is allocated, and size is ok.
    memset(ptMem, 0, sizeOfAllocBuffer);

    *ptPointerOfAllocBuffer = ptMem;
    return GOOD;
}

#define MACRO_SHM_ALLOC(__name, __size, __addr)                                                  \
    do                                                                                           \
    {                                                                                            \
        int __status = GOOD;                                                                     \
        __status = FnVCCB_GetShmMemory(__name, __size, __addr);                                  \
        VCCB_RETURN_ON_ERROR(__status, "FnVCCB_GetShmMemory(%s, %lu) Error!\n", __name, __size); \
        VALID_E_POINT_CHECK_ERROR(__addr);                                                       \
    } while (0)


template <typename T, T val>
struct const_val {
    constexpr const_val() = default;
    constexpr const_val(T v) {}
};

template <typename T, T A, typename U, U B>
constexpr void assert_smaller(const_val<T, A>, const_val<U, B>) {
    static_assert(A < B, "POSIX shared memory maximum space exceeded(contact ARC-SD0201 VCCB owner)");
}

#define MAKE_CONST(x) const_val<decltype(x), x> {}
#define STATIC_ASSERT_SMALLER(x, y) assert_smaller(MAKE_CONST(x), MAKE_CONST(y))

int FnVCCB_AllocateVccbMemory()
{
    AUTO_TRACE_FUNC;

    size_t size = 0;

    VLIB_UploadShmLogs();

    /* VCCB_CFG: CFG */
    MACRO_SHM_ALLOC("VCCB_CFG", sizeof(VccbCfgInfo_type), &CFG);

    /* VCCB_ENV: ENV */
    MACRO_SHM_ALLOC("VCCB_ENV", sizeof(VccbEnvInfo_type), &ENV);

    /* VCCB_DBG: DBG */
    MACRO_SHM_ALLOC("VCCB_DBG", sizeof(VccbDbgInfo_type), &DBG);

    /* VCCB_GNB_INFO: GNB */
    // move to FnVCCB_AllocateVccbMemoryRelatedFlavor()

    /* VCCB_LOG */
    MACRO_SHM_ALLOC("VCCB_LOG", sizeof(VccbLogInfo_type), &VCCB_LOG);

    /* VCCB_LOG_DATA */
    size = SHM_LOG_SIZE * (MAX_SHM_LOG_CNT + 1);  // approximately we assume msg size as 128B
    MACRO_SHM_ALLOC("VCCB_LOG_DATA", size, &VCCB_LOG_DATA);
    VCCB_LOG->logDataSize = size;

    /* VCCB_LOG_FISHING */
    MACRO_SHM_ALLOC("VCCB_LOG_FISHING", sizeof(VccbLogFishingInfo_type), &VCCB_LOG_FISHING);

    /* VCCB_LOG_FISHING_DATA */
    size = SHM_LOG_SIZE * (MAX_SHM_LOG_FISHING_CNT + 1);  // approximately we assume msg size as 128B
    MACRO_SHM_ALLOC("VCCB_LOG_FISHING_DATA", size, &VCCB_LOG_FISHING_DATA);
    VCCB_LOG_FISHING->logDataSize = size;

    /* VCCB_CAPA_INFO */
    MACRO_SHM_ALLOC("VCCB_CAPA_INFO", sizeof(VccbSegmentPoolInfo_type), &VCCB_CAPA_INFO);
    VCCB_CAPA_INFO->segmentPoolBuffer = NULL;

    /* VCCB_STAT: VCCB_STAT */
    MACRO_SHM_ALLOC("VCCB_STAT", sizeof(VccbStatInfo_type), &VCCB_STAT);

#ifdef __VNF__
    /* This is for checking POSIX shared memory maximum allocation size exceeded(VNF only).
       The currently defined maximum size is 16GB(17179869184 byte).
       Considering the temporary space for log upload, the memory usage should be within 75%(12GB, 12884901888 byte) */

    /* SVR24B FGR-CC1110 Multitple gNB per CNF/VNF, MAX_GNB_PER_SYS increase from 8 to 16
       thus memory range expand to 9G bytes -> 11G bytes
        9G : 9663676416
       10G : 10737418240
       11G : 11811160064 */

    /* SVR26B PNI-NPN, Multiple CellID (NBR DB)
       thus memory range expand to 11G bytes -> 12G bytes 
       12G : 12884901888 */

    STATIC_ASSERT_SMALLER( (sizeof(VccbCfgInfo_type) + sizeof(VccbEnvInfo_type) + sizeof(VccbDbgInfo_type) +
                      (sizeof(VccbGnbInfo_type) * (MAX_GNB_CU_CP_FUNCTION_PER_SYS)) + sizeof(VccbLogInfo_type) +
                      (SHM_LOG_SIZE * (MAX_SHM_LOG_CNT + 1)) + sizeof(VccbLogFishingInfo_type) +
                      (SHM_LOG_SIZE * (MAX_SHM_LOG_FISHING_CNT + 1)) + sizeof(VccbSegmentPoolInfo_type) +
                      sizeof(VccbStatInfo_type) + (sizeof(VccbCellInfo_type) * (MAX_CELL_PER_VNF + 1))), 12884901888);
#endif

    /* VCLB_STS: VCLB STATUS - KeepAlive, F1-C Multi TNL sctp status */
    // MACRO_SHM_ALLOC("VCLB_STS", sizeof(VclbSts_type), &VCLB_STS); - Owner is in VCLB. (Preserve code before
    // refactoring)
    {
        int rtCode = 0;
        size = sizeof(VclbSts_type);

        VCCB_PRINTF("** Get Shared Memory(Name:%s, Size:%ld 64Mode:0)\n", "VCLB_STS", size);

        VCLB_STS = (VclbSts_type *)callShmReadWrite("VCLB_STS", sizeof(VclbSts_type), &rtCode);
        if (NULL == VCLB_STS || -1 == rtCode)
        {
            VCLB_STS = (VclbSts_type *)callShmCreate("VCLB_STS", size);
            if (NULL == VCLB_STS)
            {
                perror("callShmCreate(VCLB_STS): ");
                return ERROR;
            }
            memset(VCLB_STS, 0, size);
        }
    }
    return GOOD;
}

int FnVCCB_LoadDeploymentFlavor(void)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ENV);
    VALID_E_POINT_CHECK_ERROR(CFG);

    int rc = 0;

#if defined(__NVGNB__)
    const char *pFuncName = "GetNvgnbDeploymentInfo";
    rc = GetNvgnbDeploymentInfo(&ENV->drlibNvgnbDeployment);
#elif defined(__CNF__)
    const char *pFuncName = "GetCnfDeploymentFlavorInfo";
    rc = GetCnfDeploymentFlavorInfo(&ENV->cnfDeploymentFlavorInfo, CFG->foo.VF_Internal_DimensionID);
#else
    const char *pFuncName = "GetVnfDeploymentFlavorInfo";
    rc = GetVnfDeploymentFlavorInfo(&ENV->vnfDeploymentFlavorInfo, CFG->foo.VF_Internal_DimensionID);
#endif

    if (rc < 0)
    {
        VCCB_PRINTF("[CRITICAL] %s Failed(%d)\n", pFuncName, rc);
        VCCB_ONE_LOG_PRINT(LC_RESET, lc_mwInit, "Get %s Fail!! Block Exit!!\n", pFuncName, rc);
        return ERROR;
    }

    return GOOD;
}

int FnVCCB_InitVccbFlavorInfo()
{
    AUTO_TRACE_FUNC;

#ifdef IPC_TEST
    ENV->deploymentFlavorInfo.vccbCoreNum = 1;
    ENV->deploymentFlavorInfo.vccbCallThreadNum = VCCB_CALL_THREAD_NUM;
    ENV->deploymentFlavorInfo.vccbMaxCallNum = MAX_CALL_COUNT_PER_CPC;
    ENV->deploymentFlavorInfo.maxCellNumPerAcpf = MAX_CELL_PER_VNF;
    ENV->deploymentFlavorInfo.vnmbCallThreadNum = VNMB_CALL_THREAD_NUM;
    ENV->deploymentFlavorInfo.vnmbPagingThreadNum = VNMB_PAGING_THREAD_NUM;
    ENV->deploymentFlavorInfo.vclbDataThreadNum = 1;  // not supported VCLB
    ENV->deploymentFlavorInfo.maxGnbNum = MAX_GNB_CU_CP_FUNCTION_PER_SYS;
#else
    if (e_VCCB_NVGNB == VCOM_getSystemType())
    {
        ENV->deploymentFlavorInfo.vccbCoreNum = ENV->drlibNvgnbDeployment.nvgnb.vccb.coreNum;
        ENV->deploymentFlavorInfo.vccbCallThreadNum = ENV->drlibNvgnbDeployment.nvgnb.vccb.callThreadNum;
        ENV->deploymentFlavorInfo.vccbMaxCallNum = ENV->drlibNvgnbDeployment.nvgnb.vccb.maxUeNum;
        ENV->deploymentFlavorInfo.maxCellNumPerAcpf = ENV->drlibNvgnbDeployment.nvgnb.vccb.maxCellNum;
        ENV->deploymentFlavorInfo.vnmbCallThreadNum = ENV->drlibNvgnbDeployment.nvgnb.vnmb.callThreadNum;
        ENV->deploymentFlavorInfo.vnmbPagingThreadNum = ENV->drlibNvgnbDeployment.nvgnb.vnmb.callThreadNum;
        ENV->deploymentFlavorInfo.vupbCallThreadNum = ENV->drlibNvgnbDeployment.nvgnb.vupb.callThreadNum;
        ENV->deploymentFlavorInfo.vclbDataThreadNum = 1;  // not supported VCLB
        ENV->deploymentFlavorInfo.maxGnbNum = MAX_GNB_CU_CP_FUNCTION_PER_SYS;
    }
    else if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
    {
        ENV->deploymentFlavorInfo.vccbCoreNum = ENV->cnfDeploymentFlavorInfo.cpp.coreNum;
        ENV->deploymentFlavorInfo.vccbCallThreadNum = ENV->cnfDeploymentFlavorInfo.cpp.callThreadNum;
        ENV->deploymentFlavorInfo.vccbMaxCallNum = ENV->cnfDeploymentFlavorInfo.cpp.maxUeNum;
        ENV->deploymentFlavorInfo.maxCellNumPerAcpf =
            MAX(1, MIN(ENV->cnfDeploymentFlavorInfo.maxCellNumPerAcpf, MAX_CELL_PER_VNF));
        ENV->deploymentFlavorInfo.vnmbCallThreadNum = ENV->cnfDeploymentFlavorInfo.cip.callThreadNum;
        ENV->deploymentFlavorInfo.vnmbPagingThreadNum = ENV->cnfDeploymentFlavorInfo.cip.callThreadNum;
        ENV->deploymentFlavorInfo.vclbDataThreadNum = 1;  // not supported VCLB
        ENV->deploymentFlavorInfo.maxGnbNum = ENV->cnfDeploymentFlavorInfo.maxGnbNum;
    }
    else  // e_VCCB_ACPF_VNF
    {
        ENV->deploymentFlavorInfo.vccbCoreNum = ENV->vnfDeploymentFlavorInfo.cpc.coreNum;
        ENV->deploymentFlavorInfo.vccbCallThreadNum = ENV->vnfDeploymentFlavorInfo.cpc.callThreadNum;
        ENV->deploymentFlavorInfo.vccbMaxCallNum = ENV->vnfDeploymentFlavorInfo.cpc.maxUeNum;
        ENV->deploymentFlavorInfo.maxCellNumPerAcpf =
            MAX(1, MIN(ENV->vnfDeploymentFlavorInfo.maxCellNumPerAcpf, MAX_CELL_PER_VNF));
        ENV->deploymentFlavorInfo.vnmbCallThreadNum = ENV->vnfDeploymentFlavorInfo.cic.callThreadNum;
        ENV->deploymentFlavorInfo.vnmbPagingThreadNum = ENV->vnfDeploymentFlavorInfo.cic.callThreadNum;
        ENV->deploymentFlavorInfo.vclbDataThreadNum = (uint8_t)MAX(1, MIN(1 + (CORE_NUM_VCCB / 10), VCLB_DATA_THREAD_NUM));
        ENV->deploymentFlavorInfo.maxGnbNum = ENV->vnfDeploymentFlavorInfo.maxGnbNum;
    }

    VCCB_PRINTF(
        "[FnVCCB_InitVccbFlavorInfo] vccbCoreNum: %u, vccbCallThreadNum: %u, vccbMaxCallNum: %u, maxCellNumPerAcpf: %u, "
        "vnmbCallThreadNum: %u, vclbDataThreadNum: %u, vupbCallThreadNum: %u, maxGnbNum: %u\n",
        ENV->deploymentFlavorInfo.vccbCoreNum, ENV->deploymentFlavorInfo.vccbCallThreadNum,
        ENV->deploymentFlavorInfo.vccbMaxCallNum, ENV->deploymentFlavorInfo.maxCellNumPerAcpf,
        ENV->deploymentFlavorInfo.vnmbCallThreadNum, ENV->deploymentFlavorInfo.vclbDataThreadNum,
        ENV->deploymentFlavorInfo.vupbCallThreadNum, ENV->deploymentFlavorInfo.maxGnbNum); // __SVR_24B_SD0201__
#endif

    return GOOD;
}

#if defined(__NVGNB__)
#else
template <typename T>
int FnVCCB_AllocateVccbMemoryRelatedFlavorForSysV(
    size_t itemSize, const char *pShmName, enumVccbShmKeySysV_type keyName, T **writeAddress)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR_PARAM2(pShmName, writeAddress);

    int shm_ret = SHM_OK;

    size_t size = itemSize * (VCCB_MAX_CALL_COUNT_PER_CPC + 1);

    callShmInfoSysV_type callShm;

    snprintf(callShm.shmName, MAX_SHM_NAME, "%s", pShmName);
    callShm.shmKey = keyName;
    callShm.shmAddr = reinterpret_cast<void **>(writeAddress);
    callShm.shmSize = size;
    callShm.shmId = 0;

    *(callShm.shmAddr) = callShmCreateSysV(&callShm);
    if (*(callShm.shmAddr) == NULL)
    {
        VCCB_PRINTF(" Try shm remove\n");
        shm_ret = callShmDestroySysV(callShm.shmKey);
        if (shm_ret != SHM_OK)
        {
            VCCB_PRINTF("Please check and kill itscp_vccb process.(#1. callShmCreateSysV Error!)\n");
            return ERROR;
        }

        *(callShm.shmAddr) = callShmCreateSysV(&callShm);
        if (*(callShm.shmAddr) == NULL)
        {
            VCCB_PRINTF("Please check and kill itscp_vccb process.(#2. callShmCreateSysV Error!)\n");
            return ERROR;
        }
    }

    return GOOD;
}
#endif


template <typename T>
int FnVCCB_AllocateVccbMemoryWithTotalSizeForSysV(
    size_t totalSize, const char *pShmName, enumVccbShmKeySysV_type keyName, T **writeAddress)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR_PARAM2(pShmName, writeAddress);

    int shm_ret = SHM_OK;

    callShmInfoSysV_type callShm;

    snprintf(callShm.shmName, MAX_SHM_NAME, "%s", pShmName);
    callShm.shmKey = keyName;
    callShm.shmAddr = reinterpret_cast<void **>(writeAddress);
    callShm.shmSize = totalSize;
    callShm.shmId = 0;

    *(callShm.shmAddr) = callShmCreateSysV(&callShm);
    if (*(callShm.shmAddr) == NULL)
    {
        VCCB_PRINTF(" Try shm remove\n");
        shm_ret = callShmDestroySysV(callShm.shmKey);
        if (shm_ret != SHM_OK)
        {
            VCCB_PRINTF("Please check and kill itscp_vccb process.(#1. callShmCreateSysV Error!)\n");
            return ERROR;
        }

        *(callShm.shmAddr) = callShmCreateSysV(&callShm);
        if (*(callShm.shmAddr) == NULL)
        {
            VCCB_PRINTF("Please check and kill itscp_vccb process.(#2. callShmCreateSysV Error!)\n");
            return ERROR;
        }
    }

    return GOOD;
}


template <typename T>
int FnVCCB_AllocateVccbMemoryRelatedFlavorByCallCount(
    size_t itemSize, const char *pShmName, enumVccbShmKeySysV_type keyName, T **writeAddress)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR_PARAM2(pShmName, writeAddress);

    size_t size = itemSize * (VCCB_MAX_CALL_COUNT_PER_CPC + 1);

#if defined(__NVGNB__)
    UNUSED1(keyName);

    // below codes are valid when using POSIX shm for CALL_INFO.
    // To use POSIX shm for CALL_INFO, /mnt/CPSW should have enough size.

    MACRO_SHM_ALLOC(pShmName, size, writeAddress);
    return GOOD;
#else
    int ret = FnVCCB_AllocateVccbMemoryRelatedFlavorForSysV(itemSize, pShmName, keyName, writeAddress);
    if (ret == ERROR)
    {
        VCCB_PRINTF("FnVCCB_AllocateVccbMemoryRelatedFlavorForSysV(keyName) Error!.\n");
        return ERROR;
    }

    VCCB_PRINTF(
        "** Get Shared Memory(Name:%s, Size:%ld CallCount:%d, SysV)\n", pShmName, size, VCCB_MAX_CALL_COUNT_PER_CPC);
    return ret;
#endif
}

int FnVCCB_AllocateVccbMemoryRelatedFlavor()
{
    AUTO_TRACE_FUNC;

    size_t size = 0;
    int ret = GOOD;

    /* VCCB_GNB_INFO: GNB */
    size = sizeof(VccbGnbInfo_type) * (MAX_GNB_PER_SYS);
    MACRO_SHM_ALLOC("VCCB_GNB_INFO", size, &GNBINFO);

    /* VCCB_CELL_INFO: CELLINFO */
    size = sizeof(VccbCellInfo_type) * ((uint16_t)(MAX_CELL_NUM_VCCB + 1));
    MACRO_SHM_ALLOC("VCCB_CELL_INFO", size, &CELLINFO);

    /* VCCB_CALL_INFO: CALLINFO */
    size = sizeof(callInfo_type);
    ret = FnVCCB_AllocateVccbMemoryRelatedFlavorByCallCount(
        size, "VCCB_CALL_INFO", CALL_SHM_SYSV_KEY_VCCB_CALL_INFO, &(ENV->callInfo));
    if (ret == ERROR)
    {
        VCCB_PRINTF("Allocation Fail(callInfo_type).\n");
        return ERROR;
    }

    /* CALLINFO in VCCB_EXTERNAL_NON_BACKUP_CALL_INFO: EXTERNAL_INFO.call */
    size = sizeof(VccbNonBackupCallInfo_type);
    ret = FnVCCB_AllocateVccbMemoryRelatedFlavorByCallCount(size, "VCCB_EXTERNAL_NON_BACKUP_CALL_INFO",
        CALL_SHM_SYSV_KEY_VCCB_EXTERNAL_NON_BACKUP_CALL_INFO, &EXTERNAL_INFO.call);
    if (ret == ERROR)
    {
        VCCB_PRINTF("Allocation Fail(VccbNonBackupCallInfo_type).\n");
        return ERROR;
    }

    /* CELLINFO in VCCB_EXTERNAL_NON_BACKUP_CELL_INFO: EXTERNAL_INFO.cell */
    size = sizeof(VccbNonBackupCellInfo_type) * ((uint16_t)(MAX_CELL_NUM_VCCB + 1));
    MACRO_SHM_ALLOC("VCCB_EXTERNAL_NON_BACKUP_CELL_INFO", size, &EXTERNAL_INFO.cell);

    /* THREAD_INFO->call */
    size = sizeof(VccbCallThreadInfo_type) * MAX_CALL_THREAD_NUM_VCCB;
    VCCB_PRINTF("** Get Heap Memory(Name:THREAD_INFO->call, size:%ld)\n", size);
    THREAD_INFO->call = (VccbCallThreadInfo_type *)malloc(size);
    VALID_E_POINT_CHECK_ERROR(THREAD_INFO->call);

    if (FOO.VF_RACS)
    {
#ifdef __NVGNB__
        VCCB_PRINTF("NVGNB NOT support RACS !!\n");
#else
        size = sizeof(VccbRacsInfo_type);
        VCCB_RACS_INFO = NULL;
        ret = FnVCCB_AllocateVccbMemoryWithTotalSizeForSysV(
            size, "VCCB_RACS_INFO", CALL_SHM_SYSV_KEY_VCCB_RACS_INFO, &VCCB_RACS_INFO);
        if (ret == ERROR)
        {
            VCCB_PRINTF("Allocation Fail(VccbRacsInfo_type).\n");
            return ERROR;
        }
#endif
    }

#ifdef NEW_HOST_SIM
    for (int i = 0; i < MAX_CALL_THREAD_NUM_VCCB; ++i)
    {
        VccbMsgBuf_type &txBuf = THREAD_INFO->call[i].buf.tx;
        memset(&txBuf, 0xFF,
            sizeof(txBuf));  // Set dummy for HostSim to discover abnormal msg build scenarios
    }
#endif

    return GOOD;
}

int FnVCCB_AllocateVccbMemoryRelatedYang()
{
    AUTO_TRACE_FUNC;

    if (FOO.VF_SegmentationOfRrcMessages == TRUE)
    {
        /* VCCB_CAPA_INFO: ENV->capa */
        if (ERROR == FnVCCB_InitRrcSegmentPoolBuf())
        {
            VCCB_PRINTF("[%s] Fail to init FnVCCB_InitRrcSegmentPoolBuf\n", __FUNCTION__);
            return ERROR;
        }
    }

    return GOOD;
}

#undef MACRO_SHM_ALLOC

int VLIB_InitMcoLbCacheMutex(pthread_mutexattr_t *pAttr)
{
    AUTO_TRACE_FUNC;

    int rCode = 0;

    if (!pAttr)
    {
        return EXIT_MUTEXATTR_INIT_FAIL;
    }

    for (unsigned int cellNum = 0; cellNum < MAX_CELL_NUM_VCCB; ++cellNum)
    {
        VccbNonBackupCellInfo_type &rCellInfo = EXTERNAL_INFO.cell[cellNum];

        rCode = pthread_mutex_init(&rCellInfo.mcoLbCacheMutex, pAttr);
        if (rCode)
        {
            return EXIT_MUTEXATTR_INIT_FAIL;
        }
    }

    return 0;
}

void FnVCCB_InitMutex(void)
{
    AUTO_TRACE_FUNC;

    uint32_t loop = 0;
    int rc = 0;

    // Recursive Mutex Attribute
    pthread_mutexattr_t attr;
    rc = pthread_mutexattr_init(&attr);
    VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutexattr_init", EXIT_MUTEXATTR_INIT_FAIL);

    rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE_NP);
    VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutexattr_settype", EXIT_MUTEXATTR_SETTYPE_FAIL);

    // MUTEX Init
    for (loop = 0; loop < (uint32_t)MAX_CELL_NUM_VCCB; loop++)
    {
        rc = pthread_mutex_init(&(gVrrmCellCfgMtx[loop]), &attr);
        VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutex_init:(gVrrmCellCfgMtx[loop]", EXIT_MUTEXATTR_INIT_FAIL);

        rc = pthread_mutex_init(&(gCellHistUpdateMtx[loop]), &attr);
        VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutex_init:(gCellHistUpdateMtx[loop]", EXIT_MUTEXATTR_INIT_FAIL);

        rc = pthread_mutex_init(&(gCellUeMeasForSonMtx[loop]), &attr);
        VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutex_init:( gCellUeMeasForSonMtx [loop]", EXIT_MUTEXATTR_INIT_FAIL);
    }

    for (loop = 0; loop < MAX_GNB_PER_SYS; loop++)
    {
        rc = pthread_mutex_init(&(gIRNTIAllocMtx[loop]), &attr);
        VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutex_init:(gIRNTIAllocMtx[loop]", EXIT_MUTEXATTR_INIT_FAIL);
    }

#ifdef __CNF__
    for (loop = 0; loop < MAX_DIST_CODE_PER_SYS; loop++)
    {
        rc = pthread_mutex_init(&(gDistCodeMtx[loop]), &attr);
        VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutex_init:(gDistCodeMtx[loop]", EXIT_MUTEXATTR_INIT_FAIL);
    }

    rc = pthread_mutex_init(&(ENV->redis.redisUpdateFlag.cfg.gnbNumInfo_update), &attr);
    VCCB_CHECK_MUTEX_RTCODE_EXIT(
        rc, "pthread_mutex_init:redisUpdateFlag.cfg.gnbNumInfo_update", EXIT_MUTEXATTR_INIT_FAIL);

    for (loop = 0; loop < MAX_CELL_PER_VNF; loop++)
    {
        rc = pthread_mutex_init(&(ENV->redis.redisUpdateFlag.cell_update[loop]), &attr);
        VCCB_CHECK_MUTEX_RTCODE_EXIT(
            rc, "pthread_mutex_init:redisUpdateFlag.cell_update[loop]", EXIT_MUTEXATTR_INIT_FAIL);
    }

    for (loop = 0; loop < MAX_GNB_CU_CP_FUNCTION_PER_SYS; loop++)
    {
        rc = pthread_mutex_init(&(ENV->redis.redisUpdateFlag.gnb_update[loop]), &attr);
        VCCB_CHECK_MUTEX_RTCODE_EXIT(
            rc, "pthread_mutex_init:redisUpdateFlag.gnb_update[loop]", EXIT_MUTEXATTR_INIT_FAIL);
    }

    for (loop = 0; loop < VCCB_CALL_THREAD_NUM; loop++)
    {
        rc = pthread_mutex_init(&(ENV->redis.callBackupQueue[loop].callQueueMutex), &attr);
        VCCB_CHECK_MUTEX_RTCODE_EXIT(
            rc, "pthread_mutex_init:callBackupQueue[loop].callQueueMutex", EXIT_MUTEXATTR_INIT_FAIL);
    }
#endif

    rc = pthread_mutex_init(&gVrrmGnbCfgMtx, &attr);
    VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutex_ini:gVrrmGnbCfgMtx", EXIT_MUTEXATTR_INIT_FAIL);
    //    pthread_mutex_init(&gVrrmStmsiDbMtx, &attr);

    rc = pthread_mutex_init(&VCCB_LOG->mutex_write, &attr);
    VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutex_init:VCCB_LOG->mutex_write", EXIT_MUTEXATTR_INIT_FAIL);

    rc = pthread_mutex_init(&VCCB_LOG->mutex_upload, &attr);
    VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutex_init:VCCB_LOG->mutex_upload", EXIT_MUTEXATTR_INIT_FAIL);

    rc = pthread_mutex_init(&VCCB_STAT->mutex_write, &attr);
    VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutex_init:VCCB_STAT->mutex_write", EXIT_MUTEXATTR_INIT_FAIL);

    rc = pthread_mutex_init(&VCCB_STAT->mutex_upload, &attr);
    VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutex_init:VCCB_STAT->mutex_upload", EXIT_MUTEXATTR_INIT_FAIL);

    rc = pthread_mutex_init(&gMemoryUsageMtx, &attr);
    VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutex_init:VCCB_LOG->gMemoryUsageMtx", EXIT_MUTEXATTR_INIT_FAIL);

    rc = pthread_mutexattr_setpshared(&attr, PTHREAD_PROCESS_SHARED);
    VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutexattr_setpshared", EXIT_MUTEXATTR_INIT_FAIL);

    rc = pthread_mutex_init(&gCellNumAllocMtx, &attr);
    VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutex_init:gCellNumAllocMtx", EXIT_MUTEXATTR_INIT_FAIL);

    rc = FnVCCB_InitMrdcMutexes(&attr);
    VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutex_init:MrdcMutexs", EXIT_MUTEXATTR_INIT_FAIL);

    rc = pthread_mutex_init(&gActiveUeBitmapMtx, &attr);
    VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutex_init:gActiveUeBitmapMtx", EXIT_MUTEXATTR_INIT_FAIL);

    rc = VLIB_InitOMFailedScellsMutex(&attr);
    VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutex_init:oMFailedScellsMutex", EXIT_MUTEXATTR_INIT_FAIL);

    rc = FnVCCB_InitAllocCallIdDbMutex(&attr);
    VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutex_init:AllocCallIdDbMutex", EXIT_MUTEXATTR_INIT_FAIL);

    rc = pthread_mutex_init(&CFG->acpfInfo.resourceThresholdExceededAlarm.isConfigurationChangedMutex, &attr);
    VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutex_init:CFG->acpfInfo.resourceThresholdExceededAlarm.isConfigurationChangedMutex", EXIT_MUTEXATTR_INIT_FAIL);

    rc = FnVCCB_InitOverloadedHoTgtGnbListMutex(&attr); // NR_CONN_MC_23B
    VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutex_init:OverloadHoTgtGnbMutex", EXIT_MUTEXATTR_INIT_FAIL);

    rc = VLIB_InitMcoLbCacheMutex(&attr);
    VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_mutex_init:McoLbCacheMutex", EXIT_MUTEXATTR_INIT_FAIL);

    rc = pthread_rwlock_init(gRacsCapaIdListMtx, NULL);
    VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_rwlock_init:gRacsCapaIdListMtx", EXIT_MUTEXATTR_INIT_FAIL);

    for (loop = 0; loop < MAX_UE_CAPA_ID_CNT; loop++)
    {
        rc = pthread_rwlock_init(&(gRacsCapaBufferListMtx[loop]), NULL);
        VCCB_CHECK_MUTEX_RTCODE_EXIT(rc, "pthread_rwlock_init:gRacsCapaBufferListMtx", EXIT_MUTEXATTR_INIT_FAIL);
    }

    // Destroy Mutex Attribute
    rc = pthread_mutexattr_destroy(&attr);
    if (rc)
    {
        perror("ERROR pthread_mutexattr_destroy : ");
    }

    return;
}

void FnVCCB_InitRacsInfoAll(void)
{
    if (not FOO.VF_RACS) return;

    VccbRacsInfo_type *pRacs = VCCB_RACS_INFO;
    if (pRacs == NULL) return;

    // WRITE LOCK
    VCCB_WRITE_LOCK(gRacsCapaIdListMtx);

    pRacs->racsCapaIdListNum = 0;
    for (uint16_t idx = 0; idx < MAX_UE_CAPA_ID_CNT; idx++)
    {
        pRacs->racsCapaIdList[idx].usage = VCCB_FLAG_OFF;
        pRacs->racsCapaIdList[idx].ueCapaIdLength = 0;
    }
    VCCB_WRITE_UNLOCK(gRacsCapaIdListMtx);

    for (uint16_t idx = 0; idx < MAX_UE_CAPA_ID_CNT; idx++)
    {
        // WRITE LOCK
        VCCB_WRITE_LOCK(&gRacsCapaBufferListMtx[idx]);

        pRacs->racsCapaBufferList[idx].usage = VCCB_FLAG_OFF;
        pRacs->racsCapaBufferList[idx].length = 0;

        VCCB_WRITE_UNLOCK(&gRacsCapaBufferListMtx[idx]);
    }
}

void FnVCCB_InitVccbMemory(void)
{
    AUTO_TRACE_FUNC;


    FnVCCB_InitCallInfo();

    // Init VCCB_LOG(gVccbInfo.log)
    FnVCCB_InitLogInfo();

    // Init VCCB_LOG(gVccbInfo.log)
    FnVCCB_InitLogFishingInfo(*VCCB_LOG_FISHING);

    // Init DBG(gVccbInfo.dbg)
    FnVCCB_InitDbgInfo();

    // Init ENV(gVccbInfo.env)
    FnVCCB_InitEnvInfo();

    // Init CFG(gVccbInfo.cfg)
    FnVCCB_InitCfgInfo();

    // Init GNBINFO(gVccbInfo.gnb)
    uint16_t gnbNum;
    for (gnbNum = 0; gnbNum < MAX_GNB_PER_SYS; gnbNum++)
    {
        FnVCCB_InitGnbInfo(gnbNum);
    }

    // Init VCCB ENDC Call Count Counters
    VRRM_clearVccbENDCcallCountCounters();

    // Init CELLINFO(gVccbInfo.cell)
    FnVCCB_InitCellInfo();

    // Init VCCB_STAT(gVccbInfo.stat)
    FnVCCB_InitStatInfo();

    FnVCCB_InitThreadInfo();

    if (nr_csl_cause_make_cp_map() != NR_CSL_CAUSE_ERROR_NONE)
    {
#ifndef IPC_TEST  // REAL Only
        VCCB_PRINTF("fail to nr_csl_cause_make_cp_map!! \n");
#endif
    }

    if (nr_csl_cause_make_sacp_map() != NR_CSL_CAUSE_ERROR_NONE)
    {
#ifndef IPC_TEST  // REAL Only
        VCCB_PRINTF("fail to nr_csl_cause_make_sacp_map!! \n");
#endif
    }

    if (nr_csl_cause_make_sacp_nrdc_sn_map() != NR_CSL_CAUSE_ERROR_NONE)
    {
#ifndef IPC_TEST  // REAL Only
        VCCB_PRINTF("fail to nr_csl_cause_make_sacp_nrdc_sn_map!! \n");
#endif
    }

    if (nr_csl_du_id_hex_cause_make_cp_map() != NR_CSL_CAUSE_ERROR_NONE)
    {
#ifndef IPC_TEST  // REAL Only
        VCCB_PRINTF("fail to nr_csl_du_id_hex_cause_make_cp_map!! \n");
#endif
    }

    if (nr_csl_du_id_hex_cause_make_sacp_nrdc_sn_map() != NR_CSL_CAUSE_ERROR_NONE)
    {
#ifndef IPC_TEST  // REAL Only
        VCCB_PRINTF("fail to nr_csl_du_id_hex_cause_make_sacp_nrdc_sn_map!! \n");
#endif
    }

    if (nr_csl_redcap_hex_cause_make_sacp_map() != NR_CSL_CAUSE_ERROR_NONE)
    {
#ifndef IPC_TEST  // REAL Only
        VCCB_PRINTF("fail to nr_csl_redcap_hex_cause_make_sacp_map!! \n");
#endif
    }


#ifndef IPC_TEST  // REAL Only
    VCCB_PRINTF("FnVCCB_InitLogFishingEventList(eventCount=%u)\n", FnVCCB_InitLogFishingEventList());
#endif

    /* Init Msg Queue Map */
    MsgQueueManager::getInstance().initMsgQueueMapAll();
    FnVCCB_InitLtmBufferMapAll();

    CallIdManager &callIdManager = CallIdManager::getInstance();
    callIdManager.initIdleCallIdQueue();

#ifdef __NVGNB__
    uint8_t threadNum = 0;
    for (threadNum = 0; threadNum < VCCB_CALL_THREAD_NUM; threadNum++)
    {
        gLastDfcbCallThread[threadNum] = threadNum;
        gLastVupbCallThread[threadNum] = threadNum;
    }
#endif

    // Call FnPDCP_C_Init to initialize the PDCP_C global state.
    // In case of CPC Redundancy (Standby -> Active) there might be no other scenario where this function is called.
    PdcpRbContext_type dummy;
    memset(&dummy, 0, sizeof(dummy));
    if (0 != FnPDCP_C_Init(&dummy, 0))
    {
        VCCB_PRINT_ERROR("FnPDCP_C_Init Dummy Log\n");
    }

    VCCB_InitMeasReportCallbackTable();
    VCCM_InitQueueingActionSpecifiers();

    VCCB_InitTrafficMeasReportCallbackTable();

    FnVCCB_InitRacsInfoAll();

    return;
}

void FnVCCB_InitCallInfo(void)
{
    AUTO_TRACE_FUNC;

#ifndef IPC_TEST
    VCCB_PRINTF("FnVCCB_InitCallInfo(), VCCB_MAX_CALL_COUNT_PER_CPC= %d\n", VCCB_MAX_CALL_COUNT_PER_CPC);
#endif

    callInfo_type *pCallInfoBase = &ENV->callInfo[0];
    VccbNonBackupCallInfo_type *pCallInfoNonBackupBase = &EXTERNAL_INFO.call[0];
    for (uint32_t callId = 0; callId < VCCB_MAX_CALL_COUNT_PER_CPC; ++callId)
    {
        callInfo_type &callInfo = pCallInfoBase[callId];
        callInfo.callId = callId;
        callInfo.prevFnState = STATE_VCCB_NOT_USED;
        callInfo.state = STATE_VCCB_NOT_USED;
        callInfo.usage = CI_no_use;

        VccbNonBackupCallInfo_type &callInfoNonBackup = pCallInfoNonBackupBase[callId];
        callInfoNonBackup.isActive = TRUE;
        callInfoNonBackup.isReturningCall = FALSE;
    }
    return;
}

void FnVCCB_InitLogInfo(void)
{
    AUTO_TRACE_FUNC;
    int i;

    for (i = 0; i < MAX_CALL_COUNT_PER_CPC; i++)
    {
        VCCB_LOG->previousLogIndex[i] = 0xFFFFFFFF;
    }

    return;
}

void FnVCCB_InitLogFishingInfo(VccbLogFishingInfo_type &logFishing)
{
    logFishing.eventListRecoveryCount = 0;
    logFishing.shmLogDataInvalidCount = 0;
    logFishing.bigMsgLenCount = 0;
    return;
}

void FnVCCB_InitDbgInfo(void)
{
    AUTO_TRACE_FUNC;

    int i, j;
    VccbDbgInfo_type *pDbg = DBG;

    pDbg->mrlInfo.maxReceivedMrlSize = 0;

    pDbg->flag.checkSsbFreqFlag = FLAG_ON;
    pDbg->flag.fdebug_msg = FLAG_ON;
    pDbg->flag.fdis_stat = FLAG_ON;
    pDbg->flag.fdis_periodic_stat = FLAG_OFF;  //[NOTE] If it is set to 1, many PmGauge logs are filled
    pDbg->flag.logOnFlow = FLAG_OFF;  // if it is set to ON, itscp logs on the actual flow are shown

    pDbg->flag.noEnqueueDuringHO = VCCB_FLAG_OFF;
    pDbg->flag.noEnqueueDuringSNInitSgNBMod = VCCB_FLAG_OFF;
    pDbg->flag.noEnqueueDuringReconfigComplete = VCCB_FLAG_OFF;
    pDbg->flag.noEnqueueDlNasDuringOtherNasProc = VCCB_FLAG_OFF;
    pDbg->flag.setAmbrUl_max = FLAG_OFF;  // if it is set to ON, the value of gNBDuUeAmbrUl is set as its maximum value
    pDbg->flag.reuseDrbId = FLAG_OFF;     // According to FR270 of Basic SA, DRB ID should be allocate without reuse.
    pDbg->flag.forcedConditionalHandover = VCCB_FLAG_OFF;
#ifndef NEW_HOST_SIM
    pDbg->flag.noHoBtwSaAndNsaCell = VCCB_FLAG_OFF;
#else
    pDbg->flag.notAllowedIntraCellHO_BasicHO = VCCB_FLAG_ON;
#endif

    pDbg->flag.refusedIntraFr1TargetCell = VCCB_FLAG_OFF;
    pDbg->flag.refusedInterFr1TargetCell = VCCB_FLAG_OFF;
    pDbg->flag.prioritizedMeasObjectIds = VCCB_FLAG_ON;
    pDbg->flag.sliceAwareforSN = VCCB_FLAG_ON;

    pDbg->flag.isSupportSCellReconfigAfterHO = VCCB_FLAG_ON;  // W/A for 21B, 21C(for 21C CU - 21B DU case)
    pDbg->flag.rollbackEndcInterDuHoWhenRejectByMn = VCCB_FLAG_ON;

    pDbg->flag.choSendF1ComplAfterReceivingAccesSsucessAndRrcCompl = VCCB_FLAG_ON;

    pDbg->flag.mrdcHO_useSnModificationProcedure_duringMcgOnlyMobility = VCCB_FLAG_ON;
    pDbg->flag.mcoLbOldAlgorithm = VCCB_FLAG_OFF;
    pDbg->flag.disable_RestrictingGnbTobeSnByOvld = VCCB_FLAG_OFF;
    pDbg->flag.otherVendorNrdcTest = VCCB_FLAG_ON;

    // Enhanced Rrc Unpack Mgr
    pDbg->flag.RrcUnpackMgr = VCCB_FLAG_ON;

    pDbg->ignoreMrSpid = 101;
    pDbg->localLevel = 2;

    // Debug Log Control ---------
    pDbg->log.logCtlFlag = VCCB_FLAG_OFF;
    pDbg->log.logCtlMask = (NO_VCCB_LOG_ITSCP_UPLOAD | NO_VCCB_LOG_DSH_PRINT);
    pDbg->log.logMscGen = VCCB_FLAG_OFF;                 // debugTrace off. Store logs of all call.
    pDbg->log.logMscGenDebugLevel = VCCB_DEFAULT_LOG_STORE_LEVEL;  // PL_ERROR
    pDbg->log.logStoreDebugTrace = VCCB_FLAG_OFF;                 // debugTrace off. Store logs of all call.
    pDbg->log.logStoreDebugLevel = VCCB_DEFAULT_LOG_STORE_LEVEL;  // PL_ERROR
    pDbg->log.logStoreStatistics = VCCB_FLAG_ON;                  // store statistics logs.
    pDbg->log.logStoreStatMsgCnt = VCCB_FLAG_OFF;                 // store message count statistics logs.
    pDbg->log.logStoreKeepAlive = VCCB_FLAG_OFF;                  // not store keepalive message
    pDbg->log.logStoreSctpMsg = VCCB_FLAG_OFF;                    // not store Sctp message.
    pDbg->log.logStoreCsl = VCCB_FLAG_OFF;                        // not store CslDataNoti message.
    pDbg->log.logStoreTraceMsg = VCCB_FLAG_OFF;                   // not store TraceDataNoti message.
    pDbg->log.logStoreSonMsg = VCCB_FLAG_OFF;                     // not store SonResourceStatusInd message.
    pDbg->log.logMcoSlbOpCountResetTimer = VCCB_FLAG_OFF;         // not store McoSlbOpCountResetTimerExpiration message.
    pDbg->log.logStoreStatThrdInternalMsg = VCCB_FLAG_OFF;        // not store internal msg for statistics thread.
    VCCB_INIT_DBG_GNB_LOG_FILTER(pDbg->log.filter);
    VCCB_INIT_DBG_CELL_LOG_FILTER(pDbg->log.filter);

#ifdef NEW_HOST_SIM
    for (uint8_t idx = 0; idx < MAX_FAMILIES_NUM; ++idx)
    {
        pDbg->value.periodicFamilyToLog[idx] = 0x00;
    }
    memset(&pDbg->value.statTestMode_DUID, 0x00, sizeof(pDbg->value.statTestMode_DUID));
    memset(&pDbg->value.statTestMode_GLOBALID, 0x00, sizeof(pDbg->value.statTestMode_GLOBALID));
    memset(&pDbg->value.statTestMode_CP, 0x00, sizeof(pDbg->value.statTestMode_CP));
#endif

    pDbg->value.bufferInitByte = 0xFF;  // initialize msg Buffer
    pDbg->value.restrictedGnbLifeTime = 0;
    pDbg->value.mcoMaxMfbiCc = MAX_MCO_MFBI_CELLS;
#if defined(NEW_HOST_SIM) || defined(IPC_TEST)
    pDbg->flag.checkInvalidBuffer = VCCB_FLAG_ON;
    pDbg->flag.logRelFunc = VCCB_FLAG_ON;   // View Release Function Name and Line.
    pDbg->flag.logYang = VCCB_FLAG_ON;      // View Yang Noti.
    pDbg->flag.logInitFlag = VCCB_FLAG_ON;  // View Not Clear Flag.
    pDbg->confdRestoreTest = VCCB_FLAG_OFF;
#endif
    pDbg->flag.disabledCheckEmptySelectedTAI = VCCB_FLAG_ON;

    pDbg->logFishing.status = VCCB_FLAG_ON;
    pDbg->logFishing.maxRequestPerSecondPerThread = MAX_LOG_FISHING_CNT_PER_SEC_PER_THREAD;
    pDbg->logFishing.minLogKeepingTime = MIN_LOG_FISHING_KEEPING_TIME_MIN;
    pDbg->logFishing.uploadPeriod = LOG_FISHING_UPLOAD_PERIOD_HOUR;
    pDbg->logFishing.lastUploadTime = {.tv_sec = 0, .tv_usec = 0}; // 1970.01.01 00:00:00 UTC+0

    for (i = 0; i < MAX_CELL_NUM_VCCB; i++)
    {
        pDbg->statusHist[i].curIdx = -1;
        pDbg->statusHist[i].cycleFlag = 0;
        for (j = 0; j < MAX_HISTORY_NUM; j++)
        {
            pDbg->statusHist[i].update[j].pldCellIdx = 0xFFFF;
        }
    }

    pDbg->pldAuditHist.curIdx = -1;
    pDbg->pldAuditHist.cycleFlag = 0;
    pDbg->flag.pldAuditFlag = VCCB_FLAG_ON;

    DBG->hasDumpHist.curIdx = -1;
    DBG->hasDumpHist.cycleFlag = 0;

    pDbg->value.callIdForPartialDumpTest = -1;
    pDbg->value.mroDiffTime = -1;

    pDbg->flag.tgtRspBasedQfiFwd = VCCB_FLAG_ON;
    pDbg->flag.extDbTestFlag = FALSE;

    pDbg->flag.mrdcScgFailureSuspendResume = VCCB_FLAG_ON;  // ON is NRDC SCG Failure Handling - Suspend, Resume
    pDbg->flag.mrdcScgFailureSuspendResumeNoF1Proc = VCCB_FLAG_ON;
    pDbg->flag.mrdcScgFailureSuspendResumeAcceptSameTargetPSCell = VCCB_FLAG_ON;
    pDbg->flag.mrdcScgFailureSuspendResumePDCP = VCCB_FLAG_ON;
    pDbg->flag.mrdcScgFailureSuspendResumeMeasConfig = VCCB_FLAG_ON;
    pDbg->flag.mrdcScgFailureSuspendResumeMasterCellGroup = VCCB_FLAG_ON;
    pDbg->flag.mrdcScgFailureSuspendResumeSnMobility = VCCB_FLAG_ON;
    pDbg->flag.includePDCPConfigInRRCReconfig = VCCB_FLAG_ON;

    // In SVR23B, VzW requested to skip PdcchBlindDetection function => eanbled according to FR900
    pDbg->flag.pdcchBlindDetectionSCG = VCCB_FLAG_ON;

    pDbg->flag.snNGuTnlUpdate = VCCB_FLAG_ON;

    pDbg->hasEventHist.curIdx = -1;
    pDbg->hasEventHist.cycleFlag = 0;

    pDbg->gnbAuditHist.curIdx = -1;
    pDbg->gnbAuditHist.cycleFlag = 0;
    pDbg->gnbAuditHist.internalAuditStbGnbNumInfoCount = 0;

    pDbg->flag.forcelyUeNrCapaEnquiry = VCCB_FLAG_OFF;
    pDbg->flag.forcelySetUeCapaSize = VCCB_FLAG_OFF;
    pDbg->flag.SNAdditionRejectE1Mod = VCCB_FLAG_ON;
    pDbg->flag.SNAdditionUpFailTest = VCCB_FLAG_ON;
    pDbg->flag.endcPmaxFR1 = VCCB_FLAG_ON;
    pDbg->flag.logMeasurements = VCCB_FLAG_OFF;
    pDbg->flag.allowOtherVendorSn = VCCB_FLAG_OFF;
    pDbg->flag.allowOtherVendorMn = VCCB_FLAG_OFF;

    pDbg->flag.sendSecuModeCmdInF1CtxtSetupReq = VCCB_FLAG_OFF;
    pDbg->flag.logEmergencyVonrCall = VCCB_FLAG_OFF;
    pDbg->flag.notAllowPduReqInUserInactRel = VCCB_FLAG_OFF;
    pDbg->flag.needSecurityModeCompleteForRedirection = VCCB_FLAG_OFF;

    pDbg->flag.drxConfig = VCCB_FLAG_OFF;
    pDbg->flag.logUplinkStatusTriggeredMobility = VCCB_FLAG_OFF;
    pDbg->flag.logDrbPartial = VCCB_FLAG_OFF;
    pDbg->flag.drbPartialFunctionDisable = VCCB_FLAG_OFF;
    pDbg->flag.logRedCap = VCCB_FLAG_OFF;
#ifdef VCCB_IPC_TEST
    pDbg->flag.logTraffic = VCCB_FLAG_ON;
    pDbg->checkGbrUe = VCCB_FLAG_OFF;   // SVR24B FGS-SF0502
    pDbg->jumpTime.tv_sec = 0;
    pDbg->jumpTime.tv_nsec = 0;
    pDbg->isSetjumpTime = VCCB_FLAG_OFF;
    pDbg->testPartialDrb = VCCB_FLAG_OFF;   // SVR25A FGR-MC3002
    pDbg->testForcedReleaseRedCap = VCCB_FLAG_OFF;
#endif
    pDbg->flag.getPldDataUsingOnlyDbiApi = VCCB_FLAG_OFF;
    pDbg->flag.DACC_forwardMaskedImeisv = VCCB_FLAG_ON;
    pDbg->flag.triggerSnRelForcelyDuetoSnModFailforBearerTypeChg = VCCB_FLAG_ON;
    pDbg->flag.isSkipVpmCollect = VCCB_FLAG_OFF;
    pDbg->flag.isSkipVpmUpdate = VCCB_FLAG_OFF;
    pDbg->flag.isSkipHasDirectSync = VCCB_FLAG_OFF;

    pDbg->mrdcServCellIndexRangeSCG.usage.value = 0;
    pDbg->flag.reportCgiHandoverNewAlgorithm = VCCB_FLAG_ON;
    pDbg->flag.keepIrntiUntilProcComplt = VCCB_FLAG_ON;
    pDbg->flag.taintMeasConfigAfterRRE = VCCB_FLAG_ON;
    pDbg->flag.removeAllMeasConfigIdsAfterRRE = VCCB_FLAG_ON;
    pDbg->flag.logMeasReportPrinter = VCCB_FLAG_OFF;

    pDbg->flag.applySnInitFullConfigInMn_24B = VCCB_FLAG_ON; // 24B FGR-CC5201 FR491
    pDbg->flag.mcoLbCacheEnable = VCCB_FLAG_ON;

    pDbg->flag.statThreadUsage = VCCB_FLAG_ON;
    pDbg->flag.nrdcScgQuerySkip = VCCB_FLAG_OFF;
    pDbg->flag.nrdcXnModNoScgRbConfig = VCCB_FLAG_OFF;
    pDbg->flag.nrdcNoScgCellGrpCfg = VCCB_FLAG_OFF;
    pDbg->flag.ltmCandAddModIncludeWoCellGroup = VCCB_FLAG_OFF;
    pDbg->flag.ltmCandidateModifyParallel = VCCB_FLAG_ON;
    pDbg->flag.ltmCellSwitchExeResumeAnyMsg = VCCB_FLAG_OFF;
    pDbg->flag.ltmMultiUpSkip = VCCB_FLAG_OFF;
    pDbg->flag.logUmfs = VCCB_FLAG_OFF;

#ifndef NEW_HOST_SIM
    pDbg->value.maxThreadCollectItem = MAX_STATISTICS_COLLECT_ITEM_PER_THREAD;
    pDbg->value.maxThreadUpdateItem = MAX_STATISTICS_UPDATE_ITEM_PER_THREAD;
#else
    // Process statistics collection in real time
    pDbg->value.maxThreadCollectItem = 1;
    pDbg->value.maxThreadUpdateItem = 1;
#endif

    pDbg->flag.ltm_parallelOperation = VCCB_FLAG_ON;
    pDbg->flag.ltmL1MrSupport = VCCB_FLAG_OFF;

    DBG->flag.isFailToRrcInactive_type01 = VCCB_FLAG_OFF;
    DBG->flag.isFailToRrcInactive_type02 = VCCB_FLAG_OFF;

    DBG->flag.forcedFail_Security = VCCB_FLAG_OFF;
    DBG->flag.forcedFail_Dss      = VCCB_FLAG_OFF;

    pDbg->flag.logRrcConnStat = VCCB_FLAG_OFF;
    pDbg->flag.logTsmDuIw = VCCB_FLAG_OFF;
    DBG->flag.logCandInfoPrint = VCCB_FLAG_ON;
    pDbg->flag.nbrGnbCellExtCgiListTest = VCCB_FLAG_OFF;

    pDbg->flag.basicSa_SimTest = VCCB_FLAG_OFF;
    pDbg->flag.cacRedirect_simTestVal = VCCB_FLAG_OFF;
    pDbg->value.testCommonVal = 0;

    pDbg->flag.grStatusUsingFlag = VCCB_FLAG_ON;

    return;
}

#ifdef __CNF__
void FnVCCB_InitPodInfo(void)
{
    AUTO_TRACE_FUNC;
    VccbEnvInfo_type *pEnv = ENV;
    pEnv->podInfo.podName[0] = '\0';

    for (int i = 0; i < VCCB_MAX_HA_UNIT_NUM; i++)
    {
        memset(pEnv->podInfo.cip[i].svcName, 0, sizeof(pEnv->podInfo.cip[i].svcName));
        pEnv->podInfo.cip[i].redundancyState = RedunState_unknown;
        pEnv->podInfo.cip[i].nanoUpdateRequiredFlag = VCCB_FLAG_OFF;
        pEnv->podInfo.cip[i].ipPortGetFailFlag = VCCB_FLAG_OFF;
        pEnv->podInfo.cip[i].operState = OpState_unknown;
        memset(pEnv->podInfo.csp[i].svcName, 0, sizeof(pEnv->podInfo.cip[i].svcName));
        pEnv->podInfo.csp[i].redundancyState = RedunState_unknown;
        pEnv->podInfo.csp[i].nanoUpdateRequiredFlag = VCCB_FLAG_OFF;
        pEnv->podInfo.csp[i].ipPortGetFailFlag = VCCB_FLAG_OFF;
        pEnv->podInfo.csp[i].operState = OpState_unknown;
        memset(pEnv->podInfo.cmp[i].svcName, 0, sizeof(pEnv->podInfo.cip[i].svcName));
        pEnv->podInfo.cmp[i].redundancyState = RedunState_unknown;
        pEnv->podInfo.cmp[i].nanoUpdateRequiredFlag = VCCB_FLAG_OFF;
        pEnv->podInfo.cmp[i].ipPortGetFailFlag = VCCB_FLAG_OFF;
        pEnv->podInfo.csp[i].operState = OpState_unknown;
    }

    for (int i = 0; i < VCCB_MAX_POD_ID_NUM; i++)
    {
        memset(pEnv->podInfo.ctp[i].svcName, 0, sizeof(pEnv->podInfo.ctp[i].svcName));
        pEnv->podInfo.ctp[i].redundancyState = RedunState_unknown;
        pEnv->podInfo.ctp[i].nanoUpdateRequiredFlag = VCCB_FLAG_OFF;
        pEnv->podInfo.ctp[i].ipPortGetFailFlag = VCCB_FLAG_OFF;
        pEnv->podInfo.ctp[i].operState = OpState_unknown;
    }

    memset(pEnv->podInfo.snp.svcName, 0, sizeof(pEnv->podInfo.snp.svcName));
}
#endif

void FnVCCB_InitEnvInfo(void)
{
    AUTO_TRACE_FUNC;
    VccbEnvInfo_type *pEnv = ENV;

    KeepAliveInfo_type &keepAliveInfo = pEnv->keepAliveInfo;
    keepAliveInfo.status = KA_BLOCK_INS;
    keepAliveInfo.regReq = FLAG_ON;
    keepAliveInfo.regReqRequired = FLAG_OFF;
    keepAliveInfo.swVer[0] = '\0';

#ifdef __CNF__  // CallTakeover
    keepAliveInfo.lastSentCallAuditIndex = MAX_DIST_CODE_PER_SYS;
#else
    keepAliveInfo.lastSentCallAuditIndex = MAX_NUM_ACTIVE_UE_ARRAY;
#endif

    keepAliveInfo.localVclbValidCheck = VCLB_STS->vclbValidCheck;
    keepAliveInfo.vclbValidFlag = FLAG_OFF;

    pEnv->isSupportHA = CNF_HA_NOT_SUPPORT;
#ifdef __CNF__
    FnVCCB_InitPodInfo();

    pEnv->isRestoredFromRedisDB = FALSE;
    pEnv->shouldSkipReadingCellInfo = FALSE;
    pEnv->redis.restoreCompletedFlag = VCCB_FLAG_OFF;
    for (int i = 0; i < MAX_CALL_THREAD_NUM_VCCB; i++)
    {
        pEnv->redis.callBackupQueue[i].flushedCnt = 0;
    }
    for (uint16_t distCode = 0; distCode < MAX_DIST_CODE_PER_SYS; ++distCode)
    {
        DistCodeInfo_type &distCodeInfo = pEnv->distCodeInfo[distCode];
        distCodeInfo.distCode = distCode;
        distCodeInfo.isAllocated = FALSE;
        distCodeInfo.callCountAllocated = 0;
        for (int distCallId = 0; distCallId < MAX_CALL_COUNT_PER_DISTCODE; ++distCallId)
        {
            distCodeInfo.distCodeToVccbCallId[distCallId] = VCCB_MAX_CALL_COUNT_PER_CPC;
        }
    }
#endif

    // ENV->fnTable registration
    FnVCCB_InitFnTableInfo();

    // On Demand Forced HO
    FnVCCB_InitOnDemandHoLoadParam();  // ODF_HO_21B

#ifdef __VNF__
    FnVCCB_AllocateCallInfoChunk();
    FnVCCB_AllocateCellInfoChunk();
#endif

    return;
}

void FnVCCB_InitFnTableInfo(void)
{
    AUTO_TRACE_FUNC;

    VccbEnvInfo_type *pEnv = ENV;
    for (int i = 0; i < MAX_VCCB_STATE + 1; i++)
    {
        pEnv->fnTable.state[i].func = VCCB_Null;
        pEnv->fnTable.state[i].name[0] = '\0';
    }

#define INIT_FNTABLE(__state, __func) insertFnTable(__state, #__state, __func)

    auto insertFnTable = [&pEnv](enumVccbCallState_type __state, const char *__strState,
                             int16_t (*__func)(callInfo_type *, message_type *, msgUnpack_type *))
    {
        MACRO_STATIC_ASSERT(sizeof(__strState) > sizeof("STATE_"), "Please check state name format. (STATE_xxxx)");

        static const size_t prefixLen = strnlen("STATE_", MAX_LEN_OF_STATE_NAME);

        snprintf(pEnv->fnTable.state[__state].name, MAX_LEN_OF_STATE_NAME, "%s", (__strState + prefixLen));
        pEnv->fnTable.state[__state].func = __func;
    };

    MACRO_STATIC_ASSERT(vccbMaxState == MAX_VCCB_STATE, "Please update vccbMaxState!!!");
    MACRO_STATIC_ASSERT(vccbMaxStateCmd == MAX_VCCB_STATE_COMMAND, "Please update vccbMaxStateCmd!!!");

    INIT_FNTABLE(STATE_I2E, VCCM_I2E);
    INIT_FNTABLE(STATE_Est, VCCM_Est);
    INIT_FNTABLE(STATE_E2C_secu, VCCM_E2C_secu);
    INIT_FNTABLE(STATE_E2C_capa, VCCM_E2C_capa);
    INIT_FNTABLE(STATE_E2C_E1Setup, VCCM_E2C_E1Setup);
    INIT_FNTABLE(STATE_E2C_F1Setup, VCCM_E2C_F1Setup);
    INIT_FNTABLE(STATE_E2C_RRCRecCmpl, VCCM_E2C_RRCRecCmpl);
    INIT_FNTABLE(STATE_E2C_F1Mod, VCCM_E2C_F1Mod);
    INIT_FNTABLE(STATE_Conn, VCCM_Conn);
    INIT_FNTABLE(STATE_Conn_RelCmd, VCCM_Conn_RelCmd);
    INIT_FNTABLE(STATE_Conn_RelCmpl, VCCM_Conn_RelCmpl);
    INIT_FNTABLE(STATE_Conn_RelCmd_ByUserInact, FnVCCB_Conn_RelCmd_ByUserInact);  // Waiting UeConextReleaseCommand or PDU Setup/Modify Request
    INIT_FNTABLE(STATE_Conn_UeNrCapa, VCCM_Conn_UeNrCapa);
    INIT_FNTABLE(STATE_PDUChg_E1Setup, VCCM_PDUChg_E1Setup);
    INIT_FNTABLE(STATE_PDUChg_E1Mod, VCCM_PDUChg_E1Mod);
    INIT_FNTABLE(STATE_PDUChg_E1Rel, VCCM_PDUChg_E1Rel);
    INIT_FNTABLE(STATE_PDUChg_SNMod, FnVCCB_PDUChg_SNMod);
    INIT_FNTABLE(STATE_PDUChg_SNRel, FnVCCB_PDUChg_SNRel);
    INIT_FNTABLE(STATE_PDUChg_F1Setup, VCCM_PDUChg_F1Setup);
    INIT_FNTABLE(STATE_PDUChg_F1Mod, VCCM_PDUChg_F1Mod);
    INIT_FNTABLE(STATE_PDUChg_E1Mod_TnlUpdate, VCCM_PDUChg_E1Mod_TnlUpdate);
    INIT_FNTABLE(STATE_PDUChg_RRCRecCmpl, VCCM_PDUChg_RRCRecCmpl);
    INIT_FNTABLE(STATE_PDUChg_F1Mod_CompltInd, VCCM_PDUChg_F1Mod_CompltInd);
    INIT_FNTABLE(STATE_PDUChg_WaitULNas, VCCM_PDUChg_WaitULNas);
    // RollBack state to recover previous E1 Setup/Mod resource due to partial F1 Failure
    INIT_FNTABLE(STATE_PDUChg_E1Mod_Rollback, FnVCCB_PDUChg_E1Mod_Rollback);

    INIT_FNTABLE(STATE_NGU_ULTNL_NGMod, FnVCCB_NGU_ULTNL_NGMod);  // NRDC Only
    INIT_FNTABLE(STATE_NGU_ULTNL_E1Mod, FnVCCB_NGU_ULTNL_E1Mod);  // NRDC Only
    INIT_FNTABLE(STATE_NGU_ULTNL_XnMod, FnVCCB_NGU_ULTNL_XnMod);  // NRDC Only

    INIT_FNTABLE(STATE_UECMod_E1Mod, FnVCCB_UECMod_E1Mod);
    INIT_FNTABLE(STATE_UECMod_F1Mod, FnVCCB_UECMod_F1Mod);
    INIT_FNTABLE(STATE_UECMod_XnMod, FnVCCB_UECMod_XnMod);
    INIT_FNTABLE(STATE_UECMod_RRCRecCmpl, FnVCCB_UECMod_RRCRecCmpl);
    INIT_FNTABLE(STATE_UECMod_F1Mod_CompltInd, FnVCCB_UECMod_F1Mod_CompltInd);

    INIT_FNTABLE(STATE_II, VCCM_II);
    INIT_FNTABLE(STATE_DCE1Setup_S, VCCM_DCE1Setup_S);
    INIT_FNTABLE(STATE_DCF1Setup_S, VCCM_DCF1Setup_S);
    INIT_FNTABLE(STATE_DCAddPrepare_S, VCCM_DCAddPrepare_S);
    INIT_FNTABLE(STATE_DCUe_S, VCCM_DCUe_S);
    INIT_FNTABLE(STATE_DCAdd_F1UeCtxtModReq, VCCM_DCAdd_F1UeCtxtModReq);
    INIT_FNTABLE(STATE_DCAddSNStatus, VCCM_DCAddSNStatus);
    INIT_FNTABLE(STATE_DCE1Mod_S, VCCM_DCE1Mod_S);
    INIT_FNTABLE(STATE_DCF1Mod_S, VCCM_DCF1Mod_S);
    INIT_FNTABLE(STATE_DCUeMod_S, VCCM_DCUeMod_S);
    INIT_FNTABLE(STATE_DCMod_CompltInd, VCCM_DCMod_CompltInd);
    INIT_FNTABLE(STATE_DCModE1_CompltInd, VCCM_DCModE1_CompltInd);
    INIT_FNTABLE(STATE_DB, VCCM_DB);
    INIT_FNTABLE(STATE_DB2DBRenb, VCCM_DB2DBRenb);
    INIT_FNTABLE(STATE_DB2DBRF1Mod, VCCM_DB2DBRF1Mod);
    INIT_FNTABLE(STATE_DB2DBRE1SNStatus, VCCM_DB2DBRE1SNStatus);
    INIT_FNTABLE(STATE_DB2DBRue, VCCM_DB2DBRue);

    INIT_FNTABLE(STATE_DCSNRelRqrd, VCCM_DCSNRelRqrd);

    INIT_FNTABLE(STATE_DCSNInitMod_X2ModRqrd, VCCM_DCSNInitMod_X2ModRqrd);
    INIT_FNTABLE(STATE_DCSNInitMod_F1UeCtxtModReq, VCCM_DCSNInitMod_F1UeCtxtModReq);

    INIT_FNTABLE(STATE_COMMrelcmd, VCCM_COMMrelcmd);
    INIT_FNTABLE(STATE_COMMrelack, VCCM_COMMrelack);
    INIT_FNTABLE(STATE_COMMrel, VCCM_COMMrel);
    INIT_FNTABLE(STATE_DCSnChg_Prep, VCCM_DCSnChg_Prep);
    INIT_FNTABLE(STATE_DCSnChg_Suspend, VCCM_DCSnChg_Suspend);
    INIT_FNTABLE(STATE_DCSnChg_F1TxStop, VCCM_DCSnChg_F1TxStop);
    INIT_FNTABLE(STATE_DCSnChg_E1SNStatus, VCCM_DCSnChg_E1SNStatus);
    INIT_FNTABLE(STATE_DCSnChg_X2UeCtxRel, VCCM_DCSnChg_X2UeCtxRel);
    INIT_FNTABLE(STATE_DCSnChg_Finalize, VCCM_DCSnChg_Finalize);

    INIT_FNTABLE(STATE_DCIntraDuHo_E1DrbModPrep, VCCM_DCIntraDuHo_E1DrbModPrep);
    INIT_FNTABLE(STATE_DCIntraDuHo_X2RecCmpl, VCCM_DCIntraDuHo_X2RecCmpl);
    INIT_FNTABLE(STATE_DCIntraDuHo_F1UeCtxMod, VCCM_DCIntraDuHo_F1UeCtxMod);
    INIT_FNTABLE(STATE_DCIntraDuHo_E1DrbModSecu, VCCM_DCIntraDuHo_E1DrbModSecu);
    INIT_FNTABLE(STATE_DCIntraDuHo_X2ModCnf, VCCM_DCIntraDuHo_X2ModCnf);
    INIT_FNTABLE(STATE_DCIntraDuHo_RRCRecCmpl, VCCM_DCIntraDuHo_RRCRecCmpl);
    INIT_FNTABLE(STATE_DCIntraDuHo_E1DrbModResume, VCCM_DCIntraDuHo_E1DrbModResume);
    INIT_FNTABLE(STATE_DCIntraDuHo_X2SgnbRelReq, VCCM_DCIntraDuHo_X2SgnbRelReq);
    INIT_FNTABLE(STATE_DCIntraDuHo_X2SnStatus, VCCM_DCIntraDuHo_X2SnStatus);

    INIT_FNTABLE(STATE_DCInterDuHo_EDAddition, VCCM_DCInterDuHo_EDAddition);
    INIT_FNTABLE(STATE_DCInterDuHo_F1UeCtxSetReq, VCCM_DCInterDuHo_F1UeCtxSetReq);
    INIT_FNTABLE(STATE_DCInterDuHo_E1DrbModPrep, VCCM_DCInterDuHo_E1DrbModPrep);
    INIT_FNTABLE(STATE_DCInterDuHo_X2RecCmpl, VCCM_DCInterDuHo_X2RecCmpl);
    INIT_FNTABLE(STATE_DCInterDuHo_RRCRecCmpl, VCCM_DCInterDuHo_RRCRecCmpl);
    INIT_FNTABLE(STATE_DCInterDuHo_X2ModCnf, VCCM_DCInterDuHo_X2ModCnf);
    INIT_FNTABLE(STATE_DCInterDuHo_E1DrbModResume, VCCM_DCInterDuHo_E1DrbModResume);
    INIT_FNTABLE(STATE_DCInterDuHo_E1DrbModSecu, VCCM_DCInterDuHo_E1DrbModSecu);
    INIT_FNTABLE(STATE_DCInterDuHo_X2SgnbRelReq, VCCM_DCInterDuHo_X2SgnbRelReq);
    INIT_FNTABLE(STATE_DCInterDuHo_F1TxStop, VCCM_DCInterDuHo_F1TxStop);
    INIT_FNTABLE(STATE_DCInterDuHo_X2SnStatus, VCCM_DCInterDuHo_X2SnStatus);
    INIT_FNTABLE(STATE_DCInterDuHo_F1SrcDuRecov, VCCM_DCInterDuHo_F1SrcDuRecov);
    INIT_FNTABLE(STATE_DCInterDuHo_E1ModRecov, VCCM_DCInterDuHo_E1ModRecov);
    INIT_FNTABLE(STATE_DCInterDuHo_F1TgtDuRel, VCCM_DCInterDuHo_F1TgtDuRel);

    INIT_FNTABLE(STATE_DCNonDuHo_E1DrbModPrep, VCCM_DCNonDuHo_E1DrbModPrep);
    INIT_FNTABLE(STATE_DCNonDuHo_X2SgnbRelReq, VCCM_DCNonDuHo_X2SgnbRelReq);
    INIT_FNTABLE(STATE_DCNonDuHo_X2RecCmpl, VCCM_DCNonDuHo_X2RecCmpl);
    INIT_FNTABLE(STATE_DCNonDuHo_X2SnStatus, VCCM_DCNonDuHo_X2SnStatus);
    INIT_FNTABLE(STATE_DCNonDuHo_E1DrbModResume, VCCM_DCNonDuHo_E1DrbModResume);

    INIT_FNTABLE(STATE_DCMeasUeRecCmpl, VCCM_DCMeasUeRecCmpl);

    INIT_FNTABLE(STATE_DCScgSusp_E1BCtxtModRes, VCCM_DCScgSusp_E1BCtxtModRes);
    INIT_FNTABLE(STATE_DCScgSusp_X2RecCompl, VCCM_DCScgSusp_X2RecCompl);

    INIT_FNTABLE(STATE_DCE1UlPath_X2ModCnf, VCCM_DCE1UlPath_X2ModCnf);
    INIT_FNTABLE(STATE_DCE1UlPath_E1ModReq, VCCM_DCE1UlPath_E1ModReq);
    INIT_FNTABLE(STATE_DCE1UlPath_F1Mod, VCCM_DCE1UlPath_F1ModReq);

    INIT_FNTABLE(STATE_DCDuCfgQuery, VCCM_DCDuCfgQuery);

    INIT_FNTABLE(STATE_DCUPPS_E1DrbMod, VCCM_DCUPPS_E1DrbMod);
    INIT_FNTABLE(STATE_DCUPPS_RRCRecCmpl, VCCM_DCUPPS_RRCRecCmpl);

    INIT_FNTABLE(STATE_CaMod_F1UeCtxtModReq, VCCM_CaMod_F1UeCtxtModReq);
    INIT_FNTABLE(STATE_CaMod_XnModReq, VCCM_CaMod_XnModReq);
    INIT_FNTABLE(STATE_CaMod_RrcUeRecCmpl, VCCM_CaMod_RrcUeRecCmpl);
    INIT_FNTABLE(STATE_CaMod_F1UeRecCmpl, VCCM_CaMod_F1UeRecCmpl);

    INIT_FNTABLE(STATE_MGap_X2ModReq, VCCM_MGap_X2ModReq);
    INIT_FNTABLE(STATE_MGap_F1CtxMod, VCCM_MGap_F1CtxMod);
    INIT_FNTABLE(STATE_MGap_XnModReq, VCCM_MGap_XnModReq);
    INIT_FNTABLE(STATE_MGap_UeRecCmpl, VCCM_MGap_UeRecCmpl);
    INIT_FNTABLE(STATE_MGap_RfUeRecCmpl, VCCM_MGap_RfUeRecCmpl);
    INIT_FNTABLE(STATE_MGap_F1RecCmpl, VCCM_MGap_F1RecCmpl);

    INIT_FNTABLE(STATE_DCSgNBInitRel_X2ModRqrd, VCCM_DCSgNBInitRel_X2ModRqrd);

    /* Conditional Handover */
    INIT_FNTABLE(STATE_CondReconfig, FnVCCB_CondReconfig);

    /* LTM Handover */
    INIT_FNTABLE(STATE_Ltm_Prep_Cand, FnVCCB_Ltm_Prep_Cand);
    INIT_FNTABLE(STATE_Ltm_Prep_TgtDuAdd, FnVCCB_Ltm_Prep_TgtDuAdd);
    INIT_FNTABLE(STATE_Ltm_Prep_TgtDuRel, FnVCCB_Ltm_Prep_TgtDuRel);
    INIT_FNTABLE(STATE_Ltm_Prep_Propagation, FnVCCB_Ltm_Prep_Propagation);
    INIT_FNTABLE(STATE_Ltm_Prep_RRC, FnVCCB_Ltm_Prep_RRC);

    INIT_FNTABLE(STATE_Ltm_Exe, FnVCCB_Ltm_Exe);
    INIT_FNTABLE(STATE_Ltm_Exe_E1Stop, FnVCCB_Ltm_Exe_E1Stop);
    INIT_FNTABLE(STATE_Ltm_Exe_TgtUp, FnVCCB_Ltm_Exe_TgtUp);
    INIT_FNTABLE(STATE_Ltm_Complete, FnVCCB_Ltm_Complete);
    INIT_FNTABLE(STATE_Ltm_Complete_F1Mod, FnVCCB_Ltm_Complete_F1Mod);

    /* Inter gNB Serving */
    INIT_FNTABLE(STATE_INTER_Pre_DU_S, VCCM_INTER_Pre_DU_S);
    INIT_FNTABLE(STATE_INTER_Pre_CU_S, VCCM_INTER_Pre_CU_S);
    INIT_FNTABLE(STATE_INTER_CondReconf_S, FnVCCB_INTER_CondReconf_S);
    INIT_FNTABLE(STATE_INTER_Exe_S, VCCM_INTER_Exe_S);
    INIT_FNTABLE(STATE_INTER_SeqNum_S, VCCM_INTER_SeqNum_S);
    INIT_FNTABLE(STATE_INTER_Compl_S, VCCM_INTER_Compl_S);

    /* Inter gNB Target */
    INIT_FNTABLE(STATE_INTER_Pre_UP_T, VCCM_INTER_Pre_UP_T);
    INIT_FNTABLE(STATE_INTER_Pre_SN_T, VCCM_INTER_Pre_SN_T);
    INIT_FNTABLE(STATE_INTER_Pre_DU_T, VCCM_INTER_Pre_DU_T);
    INIT_FNTABLE(STATE_INTER_Exe_T, VCCM_INTER_Exe_T);
    INIT_FNTABLE(STATE_INTER_Switch_T, VCCM_INTER_Switch_T);
    INIT_FNTABLE(STATE_INTER_Compl_T, VCCM_INTER_Compl_T);

    /* Intra gNB, Inter DU */
    INIT_FNTABLE(STATE_INTER_DU_DuQuery, VCCM_INTER_DU_DuQuery);     // SA/MRDC, DuQuery +(if Intra-MN Inter-DU with SN Change, SCG Query)
    INIT_FNTABLE(STATE_INTER_DU_SnAdd, FnVCCB_Common_DU_SnAdd);      // MRDC, Intra-MN Inter-DU with SN Change
    INIT_FNTABLE(STATE_INTER_DU_E1Stop, FnVCCB_INTER_DU_E1Stop);     // MRDC, UP Traffic Stop
    INIT_FNTABLE(STATE_INTER_DU_SnMod, FnVCCB_Common_DU_SnMod);      // MRDC, Intra-MN Inter-DU without SN Change
    INIT_FNTABLE(STATE_INTER_DU_SnRelA, FnVCCB_Common_DU_SnRelA);    // MRDC, Intra-MN Inter-DU with SN Release
    INIT_FNTABLE(STATE_INTER_DU_SnRelB, FnVCCB_Common_DU_SnRelB);    // MRDC, Intra-MN Inter-DU with SN Release (Sn Term DRB)
    INIT_FNTABLE(STATE_INTER_DU_Prepare, VCCM_INTER_DU_Prepare);     // SA, Handover Preparation
    INIT_FNTABLE(STATE_INTER_DU_Exe_T, VCCM_INTER_DU_Exe_T);         // SA, FullConfiguration (if need)
    INIT_FNTABLE(STATE_INTER_DU_Execution, VCCM_INTER_DU_Execution); // SA, Handover Execution - I
    INIT_FNTABLE(STATE_INTER_DU_Complete, VCCM_INTER_DU_Complete);   // SA, Handover Execution - II
    INIT_FNTABLE(STATE_INTER_DU_Cancel, FnVCCB_Common_DU_Cancel);     // MRDC, UP Traffic Resume

    /* Intra gNB, Intra DU */
    INIT_FNTABLE(STATE_INTRA_DU_SnQuery, VCCM_INTRA_DU_SnQuery);     // MRDC, Intra-MN Intra-DU with SN Change
    INIT_FNTABLE(STATE_INTRA_DU_SnAdd, FnVCCB_Common_DU_SnAdd);      // MRDC, Intra-MN Intra-DU with SN Change
    INIT_FNTABLE(STATE_INTRA_DU_E1Stop, VCCM_INTRA_DU_E1Stop);       // SA/MRDC, UP Traffic Stop
    INIT_FNTABLE(STATE_INTRA_DU_SnMod, FnVCCB_Common_DU_SnMod);      // MRDC, Intra-MN Intra-DU without SN Change
    INIT_FNTABLE(STATE_INTRA_DU_SnRelA, FnVCCB_Common_DU_SnRelA);    // MRDC, Intra-MN Intra-DU with SN Release
    INIT_FNTABLE(STATE_INTRA_DU_SnRelB, FnVCCB_Common_DU_SnRelB);    // MRDC, Intra-MN Intra-DU with SN Release (Sn Term DRB)
    INIT_FNTABLE(STATE_INTRA_DU_Prepare, VCCM_INTRA_DU_Prepare);     // SA, Handover Preparation
    INIT_FNTABLE(STATE_INTRA_DU_Execution, VCCM_INTRA_DU_Execution); // SA, Handover Execution - I
    INIT_FNTABLE(STATE_INTRA_DU_Complete, VCCM_INTRA_DU_Complete);   // SA, Handover Execution - II
    INIT_FNTABLE(STATE_INTRA_DU_Cancel, FnVCCB_Common_DU_Cancel);       // SA/MRDC, UP Traffic Resume

    /* Inter SN mobility, Serving in SN. (NR-DC Mobility) */
    INIT_FNTABLE(STATE_SN_INTER_SN_DUQuery, FnVCCB_SN_INTER_SN_DUQuery);
    INIT_FNTABLE(STATE_SN_INTER_SN_E1Stop, FnVCCB_SN_INTER_SN_E1Stop);
    INIT_FNTABLE(STATE_SN_INTER_SN_Pre_MN, FnVCCB_SN_INTER_SN_Pre_MN);
    INIT_FNTABLE(STATE_SN_INTER_SN_Exe, FnVCCB_SN_INTER_SN_Exe);
    INIT_FNTABLE(STATE_SN_INTER_SN_Complete, FnVCCB_SN_INTER_SN_Complete);

    /* Inter SN mobility, MN (NR-DC Mobility) */
    INIT_FNTABLE(STATE_MN_INTER_SN_Pre_SN, FnVCCB_MN_INTER_SN_Pre_SN);
    INIT_FNTABLE(STATE_MN_INTER_SN_E1Stop, FnVCCB_MN_INTER_SN_E1Stop);
    INIT_FNTABLE(STATE_MN_INTER_SN_Exe, FnVCCB_MN_INTER_SN_Exe);
    INIT_FNTABLE(STATE_MN_INTER_SN_Complete, FnVCCB_MN_INTER_SN_Complete);

    /* Intra gNB, Inter DU in SN. (NR-DC Mobility) */
    INIT_FNTABLE(STATE_SN_INTER_DU_DuQuery, FnVCCB_SN_INTER_DU_DuQuery);
    INIT_FNTABLE(STATE_SN_INTER_DU_E1Stop, FnVCCB_SN_INTER_DU_E1Stop);
    INIT_FNTABLE(STATE_SN_INTER_DU_Prepare, FnVCCB_SN_INTER_DU_Prepare);
    INIT_FNTABLE(STATE_SN_INTER_DU_Exe, FnVCCB_SN_INTER_DU_Exe);
    INIT_FNTABLE(STATE_SN_INTER_DU_Exe_MN, FnVCCB_SN_INTER_DU_Exe_MN);
    INIT_FNTABLE(STATE_SN_INTER_DU_Exe_SN, FnVCCB_SN_INTER_DU_Exe_SN);
    INIT_FNTABLE(STATE_SN_INTER_DU_Complete, FnVCCB_SN_INTER_DU_Complete);

    /* Intra gNB, Intra DU in SN. (NR-DC Mobility) */
    INIT_FNTABLE(STATE_SN_INTRA_DU_E1Stop, FnVCCB_SN_INTRA_DU_E1Stop);
    INIT_FNTABLE(STATE_SN_INTRA_DU_Prepare, FnVCCB_SN_INTRA_DU_Prepare);
    INIT_FNTABLE(STATE_SN_INTRA_DU_Exe, FnVCCB_SN_INTRA_DU_Exe);
    INIT_FNTABLE(STATE_SN_INTRA_DU_Exe_MN, FnVCCB_SN_INTRA_DU_Exe_MN);
    INIT_FNTABLE(STATE_SN_INTRA_DU_Exe_SN, FnVCCB_SN_INTRA_DU_Exe_SN);
    INIT_FNTABLE(STATE_SN_INTRA_DU_Complete, FnVCCB_SN_INTRA_DU_Complete);
    INIT_FNTABLE(STATE_SN_INTRA_DU_Cancel, FnVCCB_SN_INTRA_DU_Cancel);

    /* Intra gNB, Intra Cell */
    INIT_FNTABLE(STATE_Intra_Cell_E1Stop, VCCM_Intra_Cell_E1Stop);
    INIT_FNTABLE(STATE_Intra_Cell_SnChg, VCCM_Intra_Cell_SnChg);
    INIT_FNTABLE(STATE_Intra_Cell_SnRelA, VCCM_Intra_Cell_SnRelA);
    INIT_FNTABLE(STATE_Intra_Cell_SnRelB, VCCM_Intra_Cell_SnRelB);
    INIT_FNTABLE(STATE_Intra_Cell_Prepare, VCCM_Intra_Cell_Prepare);
    INIT_FNTABLE(STATE_Intra_Cell_Execution, VCCM_Intra_Cell_Execution);
    INIT_FNTABLE(STATE_Intra_Cell_Complete, VCCM_Intra_Cell_Complete);

    /* MN : SN Initiated SN Modification by PSCell Change */
    INIT_FNTABLE(STATE_MN_SNMob_TxStop, FnVCCB_MN_SNMob_TxStop);
    INIT_FNTABLE(STATE_MN_SNMob_ReconfRrc, FnVCCB_MN_SNMob_ReconfRrc);
    INIT_FNTABLE(STATE_MN_SNMob_F1Mod, FnVCCB_MN_SNMob_F1Mod);
    INIT_FNTABLE(STATE_MN_SNMob_TxResume, FnVCCB_MN_SNMob_TxResume);

    INIT_FNTABLE(STATE_MeasUeRecCmpl, VCCM_MeasUeRecCmpl);

    INIT_FNTABLE(STATE_Anr_MnSnCoordination, VCCM_Anr_MnSnCoordination);
    INIT_FNTABLE(STATE_Anr_F1Config, VCCM_Anr_F1Config);
    INIT_FNTABLE(STATE_Anr_RrcConfig, VCCM_Anr_RrcConfig);

    INIT_FNTABLE(STATE_Anr_Rollback, VCCM_Anr_Rollback);

    INIT_FNTABLE(STATE_RRE_Ready, VCCM_RRE_Ready);
    INIT_FNTABLE(STATE_RRE_XnUeRtrv, VCCM_RRE_XnUeRtrv);
    INIT_FNTABLE(STATE_RRE_E1ModTxStop, VCCM_RRE_E1ModTxStop);
    INIT_FNTABLE(STATE_RRE_RreCmpl, VCCM_RRE_RreCmpl);
    INIT_FNTABLE(STATE_RRE_F1SetupMod, VCCM_RRE_F1SetupMod);
    INIT_FNTABLE(STATE_RRE_F1ModQuery, VCCM_RRE_F1ModQuery);
    INIT_FNTABLE(STATE_RRE_E1Setup, VCCM_RRE_E1Setup);
    INIT_FNTABLE(STATE_RRE_E1Mod, VCCM_RRE_E1Mod);
    INIT_FNTABLE(STATE_RRE_RRCRecCmpl, VCCM_RRE_RRCRecCmpl);
    INIT_FNTABLE(STATE_RRE_Switch, VCCM_RRE_Switch);
    INIT_FNTABLE(STATE_RRE_INTRA_Switch, VCCM_RRE_INTRA_Switch);
    INIT_FNTABLE(STATE_RRE_Resume, VCCM_RRE_Resume);
    INIT_FNTABLE(STATE_RRE_SNRel_E1SetupMod, VCCM_RRE_SNRel_E1SetupMod);

    /* source gNB's RRE state */
    INIT_FNTABLE(STATE_RRE_S_E1ModTxStop, VCCM_RRE_S_E1ModTxStop);
    INIT_FNTABLE(STATE_RRE_S_F1ModQuery, VCCM_RRE_S_F1ModQuery);
    INIT_FNTABLE(STATE_RRE_S_XnUAddInd, VCCM_RRE_S_XnUAddInd);

    INIT_FNTABLE(STATE_RLF_WaitRRE, VCCM_RLF_WaitRRE);

    INIT_FNTABLE(STATE_DUInitMod_RRCRecCmpl, VCCM_DUInitMod_RRCRecCmpl);
    INIT_FNTABLE(STATE_DUInitMod_F1Mod_CompltInd, VCCM_DUInitMod_F1Mod_CompltInd);

    INIT_FNTABLE(STATE_Fallback_MeasReport, VCCM_Fallback_MeasReport);

    // ------------------------------------------------------------------------
    // <<< MRDC MN >>>
    // The state machine should be registered regardless of FOO enable/disable
    INIT_FNTABLE(STATE_SNAddPrepare_E1Mod1, VCCM_SNAddPrepare_E1Mod1);
    INIT_FNTABLE(STATE_SNAddPrepare_XnAdd, VCCM_SNAddPrepare_XnAdd);
    INIT_FNTABLE(STATE_SNAddPrepare_E1Mod2, VCCM_SNAddPrepare_E1Mod2);
    INIT_FNTABLE(STATE_SNAddPrepare_F1Mod, VCCM_SNAddPrepare_F1Mod);
    INIT_FNTABLE(STATE_SNAddPrepareFail_ResourceRel, VCCM_SNAddPrepareFail_ResourceRel);
    INIT_FNTABLE(STATE_SNAddExec, VCCM_SNAddExec);
    INIT_FNTABLE(STATE_SNAddComplt_F1Mod, FnVCCB_SNAddModComplt_F1Mod);
    INIT_FNTABLE(STATE_SNAddComplt_E1F1NGMod, FnVCCB_SNAddModComplt_E1F1NGMod);  // NRDC Only
    INIT_FNTABLE(STATE_SNAddComplt_E1Mod, FnVCCB_SNAddModComplt_E1Mod);          // NRDC Only
    INIT_FNTABLE(STATE_SNAddComplt_E1Rel, FnVCCB_SNAddModComplt_E1Rel);          // NRDC Only
    INIT_FNTABLE(STATE_SNAddComplt_XnMod, FnVCCB_SNAddModComplt_XnMod);          // NRDC Only

    INIT_FNTABLE(STATE_SNModPrepare_E1Setup, FnVCCB_SNModPrepare_E1Setup);  // NRDC Only
    INIT_FNTABLE(STATE_SNModPrepare_E1Mod1, FnVCCB_SNModPrepare_E1Mod1);    // NRDC Only
    INIT_FNTABLE(STATE_SNModPrepare_XnMod, VCCM_SNModPrepare_XnMod);
    INIT_FNTABLE(STATE_SNModPrepareFail_E1Mod2, FnVCCB_SNModPrepareFail_E1Mod2); // NRDC Only
    INIT_FNTABLE(STATE_SNModPrepare_E1Mod2, FnVCCB_SNModPrepare_E1Mod2);  // NRDC Only
    INIT_FNTABLE(STATE_SNModPrepare_F1Mod, FnVCCB_SNModPrepare_F1Mod);    // NRDC Only
    INIT_FNTABLE(STATE_SNModExec, VCCM_SNModExec);
    INIT_FNTABLE(STATE_SNModComplt_F1Mod, FnVCCB_SNAddModComplt_F1Mod);          // NRDC Only
    INIT_FNTABLE(STATE_SNModComplt_E1F1NGMod, FnVCCB_SNAddModComplt_E1F1NGMod);  // NRDC Only
    INIT_FNTABLE(STATE_SNModComplt_E1Mod, FnVCCB_SNAddModComplt_E1Mod);          // NRDC Only
    INIT_FNTABLE(STATE_SNModComplt_E1Rel, FnVCCB_SNAddModComplt_E1Rel);          // NRDC Only
    INIT_FNTABLE(STATE_SNModComplt_XnMod, FnVCCB_SNAddModComplt_XnMod);          // NRDC Only

    INIT_FNTABLE(STATE_SNModPrepare_E1Mod, VCCM_SNModPrepare_E1Mod);
    INIT_FNTABLE(STATE_SNModRqrdExec, FnVCCB_SNModRqrdExec);

    INIT_FNTABLE(STATE_MN_SCGSuspend_XnMod, FnVCCB_MN_SCGSuspend_XnMod);                      // NRDC Only (SCG Failure)
    INIT_FNTABLE(STATE_SN_SCGSuspend_E1Mod, FnVCCB_SN_SCGSuspend_E1Mod);                      // NRDC Only (SCG Failure)
    INIT_FNTABLE(STATE_MN_SCGSuspend_E1Mod, FnVCCB_MN_SCGSuspend_E1Mod);                      // NRDC Only (SCG Failure)
    INIT_FNTABLE(STATE_MN_SCGSuspend_RRCReconfigCmpl, FnVCCB_MN_SCGSuspend_RRCReconfigCmpl);  // NRDC Only (SCG Failure)
    INIT_FNTABLE(STATE_SN_SCGSuspend_XnReconfigCmpl, FnVCCB_SN_SCGSuspend_XnReconfigCmpl);    // NRDC Only (SCG Failure)

    INIT_FNTABLE(STATE_MN_SCGResume_XnMod, FnVCCB_MN_SCGResume_XnMod);                      // NRDC Only (SCG Failure)
    INIT_FNTABLE(STATE_MN_SCGResume_E1ModULConfig, FnVCCB_MN_SCGResume_E1ModULConfig);      // NRDC Only (SCG Failure)
    INIT_FNTABLE(STATE_MN_SCGResume_F1Mod, FnVCCB_MN_SCGResume_F1Mod);                      // NRDC Only (SCG Failure)
    INIT_FNTABLE(STATE_MN_SCGResume_RRCReconfigCmpl, FnVCCB_MN_SCGResume_RRCReconfigCmpl);  // NRDC Only (SCG Failure)
    INIT_FNTABLE(STATE_MN_SCGResume_F1ReconfigCmpl, FnVCCB_MN_SCGResume_F1ReconfigCmpl);    // NRDC Only (SCG Failure)
    INIT_FNTABLE(STATE_MN_SCGResume_E1ModResume, FnVCCB_MN_SCGResume_E1ModResume);          // NRDC Only (SCG Failure)

    INIT_FNTABLE(STATE_SNRelPrepare_E1Mod, VCCM_SNRelPrepare_E1Mod);
    INIT_FNTABLE(STATE_SNRelPrepare_XnRel, VCCM_SNRelPrepare_XnRel);
    INIT_FNTABLE(STATE_SNRelPrepare_E1Setup, FnVCCB_SNRelPrepare_E1Setup);  // NRDC Only
    INIT_FNTABLE(STATE_SNRelPrepare_E1Mod2, FnVCCB_SNRelPrepare_E1Mod2);    // NRDC Only
    INIT_FNTABLE(STATE_SNRelPrepare_F1Mod, VCCM_SNRelPrepare_F1Mod);
    INIT_FNTABLE(STATE_SNRelPrepare_E1Mod3, FnVCCB_SNRelPrepare_E1Mod3);  // NRDC Only
    INIT_FNTABLE(STATE_SNRelExec, VCCM_SNRelExec);
    INIT_FNTABLE(STATE_SNRelExec_SNStatusTransfer, FnVCCB_SNRelExec_SNStatusTransfer);  // NRDC Only
    INIT_FNTABLE(STATE_SNRelComplt_F1Mod, VCCM_SNRelComplt_F1Mod);
    INIT_FNTABLE(STATE_SNRelComplt_F1NGMod, FnVCCB_SNRelComplt_F1NGMod);      // NRDC Only
    INIT_FNTABLE(STATE_SNRelComplt_E1F1NGMod, FnVCCB_SNRelComplt_E1F1NGMod);  // NRDC Only
    INIT_FNTABLE(STATE_SNRelComplt_E1Mod, FnVCCB_SNRelComplt_E1Mod);          // NRDC Only

    INIT_FNTABLE(STATE_SNModFbkPrepare_E1Mod1, FnVCCB_SNModFbkPrepare_E1Mod1);  // TBD
    INIT_FNTABLE(STATE_SNModFbkPrepare_XnMod, FnVCCB_SNModFbkPrepare_XnMod);    // TBD
    INIT_FNTABLE(STATE_SNModFbkPrepare_E1Setup, FnVCCB_SNModFbkPrepare_E1Setup);
    INIT_FNTABLE(STATE_SNModFbkPrepare_E1Mod2, FnVCCB_SNModFbkPrepare_E1Mod2);
    INIT_FNTABLE(STATE_SNModFbkPrepare_F1Mod, FnVCCB_SNModFbkPrepare_F1Mod);
    INIT_FNTABLE(STATE_SNModFbkPrepare_E1Mod3, FnVCCB_SNModFbkPrepare_E1Mod3);
    INIT_FNTABLE(STATE_SNModFbkExec, FnVCCB_SNModFbkExec);
    INIT_FNTABLE(STATE_SNModFbkComplt_E1F1NGMod, FnVCCB_SNModFbkComplt_E1F1NGMod);
    INIT_FNTABLE(STATE_SNModFbkComplt_E1Mod, FnVCCB_SNModFbkComplt_E1Mod);
    INIT_FNTABLE(STATE_SNModFbkComplt_XnMod, FnVCCB_SNModFbkComplt_XnMod);

    INIT_FNTABLE(STATE_SNE1UlPath_XnModReq, VCCM_SNE1UlPath_XnModReq);
    INIT_FNTABLE(STATE_SNE1UlPath_RRCRecCmpl, VCCM_SNE1UlPath_RRCRecCmpl);
    INIT_FNTABLE(STATE_SNE1UlPath_E1ModReq, VCCM_SNE1UlPath_E1ModReq);
    INIT_FNTABLE(STATE_SNE1UlPathFail_E1ModReq, VCCM_SNE1UlPathFail_E1ModReq);

    INIT_FNTABLE(STATE_SNUPPS_E1DrbMod, VCCM_SNUPPS_E1DrbMod);
    INIT_FNTABLE(STATE_SNUPPS_XnModReq, VCCM_SNUPPS_XnModReq);
    INIT_FNTABLE(STATE_SNUPPS_RRCRecCmpl, VCCM_SNUPPS_RRCRecCmpl);
    INIT_FNTABLE(STATE_SNUPPS_XnModRequired, VCCM_SNUPPS_XnModRequired);
    INIT_FNTABLE(STATE_SNUPPS_F1RecCmpl, VCCM_SNUPPS_F1RecCmpl);

    INIT_FNTABLE(STATE_SNPowChg_F1CtxMod, VCCM_SNPowChg_F1CtxMod);
    INIT_FNTABLE(STATE_SNPowChg_XnModReq, VCCM_SNPowChg_XnModReq);
    INIT_FNTABLE(STATE_SNPowChg_RRCRecCmpl, VCCM_SNPowChg_RRCRecCmpl);
    INIT_FNTABLE(STATE_SNPowChg_F1RecCmpl, VCCM_SNPowChg_F1RecCmpl);

    // <<< MRDC SN >>> NRDC Only
    INIT_FNTABLE(STATE_SN_SNAddPrepare_E1Setup, FnVCCB_SN_SNAddPrepare_E1Setup);
    INIT_FNTABLE(STATE_SN_SNAddPrepare_F1Setup, FnVCCB_SN_SNAddPrepare_F1Setup);
    INIT_FNTABLE(STATE_SN_SNAddPrepare_E1Mod, FnVCCB_SN_SNAddPrepare_E1Mod);
    INIT_FNTABLE(STATE_SN_SNAddPrepare_E1Rel, FnVCCB_SN_SNAddPrepare_E1Rel);
    INIT_FNTABLE(STATE_SN_SNAddExec, FnVCCB_SN_SNAddExec);
    INIT_FNTABLE(STATE_SN_SNAddComplt_F1E1Mod, FnVCCB_SN_SNAddComplt_F1E1Mod);

    INIT_FNTABLE(STATE_SN_SNModPrepare_XnModRqrd, FnVCCB_SN_SNModPrepare_XnModRqrd);
    INIT_FNTABLE(STATE_SN_SNModPrepare_E1Setup, FnVCCB_SN_SNModPrepare_E1Setup);
    INIT_FNTABLE(STATE_SN_SNModPrepare_E1Mod1, FnVCCB_SN_SNModPrepare_E1Mod1);
    INIT_FNTABLE(STATE_SN_SNModPrepare_E1Rel, FnVCCB_SN_SNModPrepare_E1Rel);
    INIT_FNTABLE(STATE_SN_SNModPrepare_F1Mod1, FnVCCB_SN_SNModPrepare_F1Mod1);
    INIT_FNTABLE(STATE_SN_SNModPrepare_E1Mod2, FnVCCB_SN_SNModPrepare_E1Mod2);
    INIT_FNTABLE(STATE_SN_SNModExec, FnVCCB_SN_SNModExec);
    INIT_FNTABLE(STATE_SN_SNModComplt_F1E1Mod, FnVCCB_SN_SNModComplt_F1E1Mod);

    INIT_FNTABLE(STATE_SN_SNINIT_SNModPrepare_XnMod, FnVCCB_SN_SNINIT_SNModPrepare_XnMod);
    INIT_FNTABLE(STATE_SN_SNINIT_SNModComplt_F1Mod, FnVCCB_SN_SNINIT_SNModComplt_F1Mod);

    INIT_FNTABLE(STATE_SN_SNRelPrepare_XnRel, FnVCCB_SN_SNRelPrepare_XnRel);
    INIT_FNTABLE(STATE_SN_SNRelPrepare_E1Mod, FnVCCB_SN_SNRelPrepare_E1Mod);
    INIT_FNTABLE(STATE_SN_SNRelPrepare_F1Mod, FnVCCB_SN_SNRelPrepare_F1Mod);
    INIT_FNTABLE(STATE_SN_SNRelExec, FnVCCB_SN_SNRelExec);

    INIT_FNTABLE(STATE_SN_SNE1UlPath_F1ModReq, FnVCCB_SN_SNE1UlPath_F1ModReq);
    INIT_FNTABLE(STATE_SN_SNE1UlPath_E1ModReq, FnVCCB_SN_SNE1UlPath_E1ModReq);
    INIT_FNTABLE(STATE_SN_SNE1UlPath_XnModRequired, FnVCCB_SN_SNE1UlPath_XnModRequired);
    INIT_FNTABLE(STATE_SN_SNE1UlPath_RRCRecCmpl, FnVCCB_SN_SNE1UlPath_RRCRecCmpl);
    INIT_FNTABLE(STATE_SN_SNE1UlPathFail_F1ModReq, FnVCCB_SN_SNE1UlPathFail_F1ModReq);
    INIT_FNTABLE(STATE_SN_SNE1UlPathFail_E1ModReq, FnVCCB_SN_SNE1UlPathFail_E1ModReq);

    INIT_FNTABLE(STATE_SN_MeasUeRecCpl, FnVCCB_SN_MeasUeRecCpl);
    INIT_FNTABLE(STATE_SN_MGap_XnModReq, FnVCCB_SN_MGap_XnModReq);
    INIT_FNTABLE(STATE_SN_MGap_F1CtxMod, FnVCCB_SN_MGap_F1CtxMod);
    INIT_FNTABLE(STATE_SN_MGap_UeRecCpl, FnVCCB_SN_MGap_UeRecCpl);
    INIT_FNTABLE(STATE_SN_MGap_RfUeRecCpl, FnVCCB_SN_MGap_RfUeRecCpl);
    INIT_FNTABLE(STATE_SN_MGap_F1RecCpl, FnVCCB_SN_MGap_F1RecCpl);

    // SCG Query For NR-DC
    INIT_FNTABLE(STATE_SN_Du_Query, FnVCCB_SN_Du_Query);

    // ------------------------------------------------------------------------

    // RRC Inactive(Intra-gNB, Target-gNB of Inter-gNB)
    INIT_FNTABLE(STATE_Inact_F1ModQuery, FnVCCB_Inact_F1ModQuery);
    INIT_FNTABLE(STATE_Inact_E1Mod_Suspend, FnVCCB_Inact_E1Mod_Suspend);
    INIT_FNTABLE(STATE_Inact_Suspend, FnVCCB_Inact_Suspend);
    INIT_FNTABLE(STATE_Inact_ResumeReq, FnVCCB_Inact_ResumeReq);
    INIT_FNTABLE(STATE_Inact_T_XnUeContextReq, FnVCCB_Inact_T_XnUeContextReq);
    INIT_FNTABLE(STATE_Inact_T_E1Setup, FnVCCB_Inact_T_E1Setup);
    INIT_FNTABLE(STATE_Inact_F1Setup, FnVCCB_Inact_F1Setup);
    INIT_FNTABLE(STATE_Inact_T_E1Mod, FnVCCB_Inact_T_E1Mod);
    INIT_FNTABLE(STATE_Inact_ResumeCmpl, FnVCCB_Inact_ResumeCmpl);
    INIT_FNTABLE(STATE_Inact_F1Mod, FnVCCB_Inact_F1Mod);
    INIT_FNTABLE(STATE_Inact_E1Mod_Pdcp, FnVCCB_Inact_E1Mod_Pdcp);
    INIT_FNTABLE(STATE_Inact_T_NgPathSwitch, FnVCCB_Inact_T_NgPathSwitch);
    INIT_FNTABLE(STATE_Inact_T_E1Mod_N3TeId, FnVCCB_Inact_T_E1Mod_N3TeId);
    INIT_FNTABLE(STATE_Inact_Reconfig, FnVCCB_Inact_Reconfig);
    INIT_FNTABLE(STATE_Inact_SNRelCmpl, FnVCCB_Inact_SNRelCmpl);
    INIT_FNTABLE(STATE_Inact_RelCmd, FnVCCB_Inact_RelCmd);

    // RRC Inactive(Source-gNB of Inter-gNB)
    INIT_FNTABLE(STATE_Inact_S_E1Mod_TxStop, FnVCCB_Inact_S_E1Mod_TxStop);
    INIT_FNTABLE(STATE_Inact_S_XnUAddrInd, FnVCCB_Inact_S_XnUAddrInd);
    INIT_FNTABLE(STATE_Inact_S_E1Mod_XnTeId, FnVCCB_Inact_S_E1Mod_XnTeId);
    INIT_FNTABLE(STATE_Inact_S_XnUeContextRel, FnVCCB_Inact_S_XnUeContextRel);

    INIT_FNTABLE(STATE_UEAssiInfo_E1F1Mod, FnVCCB_UEAssiInfo_E1F1Mod);
    INIT_FNTABLE(STATE_UEAssiInfo_XNMod, FnVCCB_UEAssiInfo_XNMod);
    INIT_FNTABLE(STATE_UEAssiInfo_RRCRecCmpl, FnVCCB_UEAssiInfo_RRCRecCmpl);
    INIT_FNTABLE(STATE_UEAssiInfo_CompltInd, FnVCCB_UEAssiInfo_CompltInd);

    INIT_FNTABLE(STATE_Comp_F1Mod, FnVCCB_STATE_Comp_F1Mod);

    // NRPPA ECID
    INIT_FNTABLE(STATE_NrppaECID_MeasConfig, VCCM_NrppaECID_MeasConfig);
    INIT_FNTABLE(STATE_NrppaECID_SRS_RRCRecCmpl, VCCM_NrppaECID_SRS_RRCRecCmpl);
    INIT_FNTABLE(STATE_NrppaECID_SRS_F1RecCmpl, VCCM_NrppaECID_SRS_F1RecCmpl);

    // NRPPA Multi-RTT
    INIT_FNTABLE(STATE_NrppaMultiRTT_F1Req, VCCM_NrppaMultiRTT_F1Req);
    INIT_FNTABLE(STATE_NrppaMultiRTT_SRS_RRCRecCmpl, VCCM_NrppaMultiRTT_SRS_RRCRecCmpl);
    INIT_FNTABLE(STATE_NrppaMultiRTT_SRS_F1RecCmpl, VCCM_NrppaMultiRTT_SRS_F1RecCmpl);

    // PDCP Count Wrap Around SN
    INIT_FNTABLE(STATE_SN_SNPCWA_XnModRequired, VCCM_SN_SNPCWA_XnModRequired);

    // Audit
    INIT_FNTABLE(STATE_AupfAudit_E1Mod, FnVCCB_STATE_AupfAudit_E1Mod);

    // Traffic monitoring reconfiguration
    INIT_FNTABLE(STATE_TrfMeasCfg_E1Mod, FnVCCB_STATE_TrfMeasCfg_E1Mod);


    // State CU initiate DU Modification
    INIT_FNTABLE(STATE_CUinitDUmodi_F1Mod, FnVCCB_CUinitDUmodi_F1Mod);
    INIT_FNTABLE(STATE_CUinitDUmodi_RRCRecCmpl, FnVCCB_CUinitDUmodi_RRCRecCmpl);
    INIT_FNTABLE(STATE_CUinitDUmodi_F1RecCmpl, FnVCCB_CUinitDUmodi_F1RecCmpl);

    // State RFSP Redirection (MR Based or Blind).
    INIT_FNTABLE(STATE_RfspRedir_RRCRecCmpl, FnVCCB_RfspRedir_RRCRecCmpl);
    INIT_FNTABLE(STATE_RfspRedir_MrOrPduSetup, FnVCCB_RfspRedir_MrOrPduSetup);

    return;
}

void FnVCCB_InitCfgInfo(void)
{
    AUTO_TRACE_FUNC;

    VccbCfgInfo_type *pCfg = CFG;

    pCfg->ulGrant.size_rrc = 13;
    pCfg->ulGrant.size_smcmd = 5;
    pCfg->ulGrant.size_recfg = 7;

    pCfg->ulGrant.time_rrc = 5;
    pCfg->ulGrant.time_smcmd = 11;
    pCfg->ulGrant.time_recfg = 18;

#ifdef __CNF__
        strcpy(pCfg->acpfInfo.buildTime, VCCB_BUILD_TIME);
#endif

    if (e_VCCB_ACPF_VNF == VCOM_getSystemType())  // VNFC Redundancy feature
    {
        // Has is not initialized yet, set state to -1
        pCfg->hasCpc.State = HAS_NOTINITIALIZED;
    }

    pCfg->pldCpcState.upgradeStatus = CU_UPGRADE_NONE;

    FnVCCB_InitActiveUeBitmap();  // 190418 VNMB-VCCB call resource audit

    FnVCCB_InitGnbNumInfo();

    FnVCCB_InitCellNumInfo();

    // If the Timer has a fixed value, it is declared in this function.
    FnVCCB_InitTimerValue();

    pCfg->amf.amfSelectionMode = AMFSelectionMode_Default;
#ifdef NEW_HOST_SIM
    pCfg->amf.amfSelectionMode = AMFSelectionMode_Debug;
    pCfg->amf.dbgAmfIdx = 0;
    pCfg->amf.dbgTnlIdx = 0;
#endif

    /* Full Configuration : disable full configuration at first version */
    FnVCCB_InitFullConfiguration_InBlockLoading();

    pCfg->nrdcPartialHo.clearForgeRespFlag = 0;

    /* Audit */
    pCfg->callAuditInfo.usage = TRUE;
    pCfg->callAuditInfo.switch_release_ue = TRUE;
    pCfg->callAuditInfo.switch_statistic = TRUE;
    pCfg->callAuditInfo.auditCheckTime = 60 * 5;  // 5min
    pCfg->callAuditInfo.currentTickTime = 0;
    pCfg->callAuditInfo.maxReleaseCountPerThread = 60;  // 60ue
    memset(&pCfg->callAuditInfo.releaseStateCount, 0x00, sizeof(pCfg->callAuditInfo.releaseStateCount));

    pCfg->ipPortCheckPeriod = 10;  // ip port Status check and revice timer(Default : 10sec)
    pCfg->ipPortUpdateFlag = VCCB_FLAG_OFF;

    FnVCCB_InitAllowedCaConfig();

    // TODO: inactivityVendor is used for SVR18.3. InactivityFeature will be updated on SVR19A.
    // KOR_183 : inactivityVendor is ActivityNotification_Off
    // MAIN : Other Vendor except KOR, inactivityVendor is ActivityNotification_SamsungEnb
    //        inactivityVendor rule should be considered for each vendor.
    pCfg->inactivityVendor = ActivityNotification_Off;

    pCfg->assignedCallCount = 0;

    pCfg->globalTraceInfo.loggedRetrieveTimer = 5;
    pCfg->globalTraceInfo.deactTimer = 20;
    pCfg->globalTraceInfo.management.auditTimer = 15; // 15 mins
    pCfg->globalTraceInfo.management.cellTraceUeCountCpc = 0;
    pCfg->globalTraceInfo.maxAcpfTracesNum = 0;
    pCfg->globalTraceInfo.pldLimitCheck = FALSE;
    pCfg->globalTraceInfo.acpfCpcCnt = 1; // number of CPC in ACPF
    pCfg->globalTraceInfo.m6MeasOnOff = FALSE;
    memset(&pCfg->globalTraceInfo.msgCountersPerThread, 0x00, sizeof(pCfg->globalTraceInfo.msgCountersPerThread));
    memset(&pCfg->globalTraceInfo.management.traceAuditHist, 0x00, sizeof(pCfg->globalTraceInfo.management.traceAuditHist));
#ifdef __CNF__
    pCfg->globalTraceInfo.operationalCtpNum = 0;
#endif

    pCfg->globalTraceInfo.msgAggregatedSize = MAX_MSG_LEN;
    pCfg->globalTraceInfo.msgAggregatedTime = 1000; // 1 sec

    if (TRUE == VCOM_IsHostSim())
    {
        pCfg->globalTraceInfo.msgAggregatedSize = 2000; // Aggregate less for HostSim
        pCfg->globalTraceInfo.msgAggregatedTime = 500;
    }

    FnVCCB_InitCfgAcpfInfo();

    // Initialize internal DB before reading all entries
    FnVCCB_InitServiceTypeList();

    FnVCCB_InitMsgQueueCntInfo();

    pCfg->syslogCslTraceDSCP = DSCP_IPC;

    memset(&pCfg->k8sNamespace, 0x00, sizeof(pCfg->k8sNamespace));

    VCCB_CLEAR_TIMER(&pCfg->timer.internalPLDCpuUtilReadPeriodicTimer, INIT_TIMER);

    // FGR-LC0703 FR220
    FnVCCB_InitPeriodicLbInfo();

    // FGR-CC0351 Device Aware Call Control
    memset(&pCfg->imeisvFeatControlInfo, 0x00, sizeof(ImeisvFeatureControlInformation_type));

    for (uint8_t controlIdx = 0; controlIdx < MAX_IMEISV_FEATURE_CONTROL_INFORMATION_ENTRIES; ++controlIdx)
    {
        pCfg->imeisvFeatControlInfo.entries[controlIdx].featureSupport.caUsageForNsa    = caUsage_NoControl;
        pCfg->imeisvFeatControlInfo.entries[controlIdx].featureSupport.caUsageForSa     = caUsage_NoControl;
        pCfg->imeisvFeatControlInfo.entries[controlIdx].featureSupport.ulCaUsageForSa   = ulCaUsage_NoControl;
    }


    return;
}

void FnVCCB_InitThreadInfo(void)
{
    AUTO_TRACE_FUNC;
    VccbThreadInfo_type *pThreadInfo = THREAD_INFO;

    for (int i = 0; i < MAX_CALL_THREAD_NUM_VCCB; ++i)
    {
        pThreadInfo->call[i].tempCallInfo.callId = UNKNOWN_CP_CALLID;
        pThreadInfo->call[i].buf.mrdcBandCombList = {};
        pThreadInfo->call[i].buf.mrdcBuffStoredCallId = VCCB_MAX_CALL_COUNT_PER_CPC;
        pThreadInfo->call[i].buf.measResultList2NRRx.candidateCellInfoListMN = {};
        pThreadInfo->call[i].buf.measResultList2NRRx.candidateCellInfoListSN = {};
#ifdef __CNF__
        pThreadInfo->call[i].lastChosenCtp = 0;
        for (int podId = 0; podId < VCCB_MAX_POD_ID_NUM; ++podId)
        {
            msgAggregatedTraceDataNoti_type &traceAggregationBuff = pThreadInfo->call[i].buf.traceAggregationBuff[podId];
            traceAggregationBuff.msgCnt = 0;
            traceAggregationBuff.occupiedSize = 0;
            memset(traceAggregationBuff.msgStartIndex, 0x00, sizeof(traceAggregationBuff.msgStartIndex));
        }
#else
        msgAggregatedTraceDataNoti_type &traceAggregationBuff = pThreadInfo->call[i].buf.traceAggregationBuff;
        traceAggregationBuff.msgCnt = 0;
        traceAggregationBuff.occupiedSize = 0;
        memset(traceAggregationBuff.msgStartIndex, 0x00, sizeof(traceAggregationBuff.msgStartIndex));
#endif
    }

    pThreadInfo->nonUeAsn1.tempCallInfo.callId = UNKNOWN_CP_CALLID;
}

int FnVCCB_InitLogFishingEventList(void)
{
    AUTO_TRACE_FUNC;

    uint16_t crrId = 0, eventCount = 0;

    FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId);  // CAUSE_NO_FAULT

    // Internal
    crrId = CAUSE_BASE_CUCP_INTERNAL;
    while (crrId < CauseCpInternalEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    crrId = CAUSE_BASE_CUCP_INTERNAL_SA;
    while (crrId < CauseCpInternalSaEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    // F1
    crrId = CAUSE_BASE_F1AP_RADIONETWORK;
    while (crrId < CauseF1apRadioEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    crrId = CAUSE_BASE_F1AP_TRANSPORT;
    while (crrId < CauseF1apTransportEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    crrId = CAUSE_BASE_F1AP_PROTOCOL;
    while (crrId < CauseF1apProtocolEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    crrId = CAUSE_BASE_F1AP_MISC;
    while (crrId < CauseF1apMiscEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    // E1
    crrId = CAUSE_BASE_E1AP_RADIONETWORK;
    while (crrId < CauseE1apRadioNetworkLayerEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    crrId = CAUSE_BASE_E1AP_TRANSPORT;
    while (crrId < CauseE1apTransportLayerEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    crrId = CAUSE_BASE_E1AP_PROTOCOL;
    while (crrId < CauseE1apProtocolEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    crrId = CAUSE_BASE_E1AP_MISC;
    while (crrId < CauseE1apMiscEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    // X2
    crrId = CAUSE_BASE_X2AP_RADIONETWORK;
    while (crrId < CauseX2apRadioNetworkLayerEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    crrId = CAUSE_BASE_X2AP_TRANSPORT;
    while (crrId < CauseX2apTransportNetworkLayerEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    crrId = CAUSE_BASE_X2AP_PROTOCOL;
    while (crrId < CauseX2apProtocolEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    crrId = CAUSE_BASE_X2AP_MISC;
    while (crrId < CauseX2apMiscEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    // NG
    crrId = CAUSE_BASE_NGAP_RADIONETWORK;
    while (crrId < CauseNgapRadioNetworkLayerEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    crrId = CAUSE_BASE_NGAP_TRANSPORT;
    while (crrId < CauseNgapTransportLayerEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    crrId = CAUSE_BASE_NGAP_NAS;
    while (crrId < CauseNgapNasEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    crrId = CAUSE_BASE_NGAP_PROTOCOL;
    while (crrId < CauseNgapProtocolEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    crrId = CAUSE_BASE_NGAP_MISC;
    while (crrId < CauseNgapMiscEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    // XN
    crrId = CAUSE_BASE_XNAP_RADIONETWORK;
    while (crrId < CauseXnapRadioNetworkLayerEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }
    crrId = CAUSE_BASE_XNAP_TRANSPORT;
    while (crrId < CauseXnapTransportLayerEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    crrId = CAUSE_BASE_XNAP_PROTOCOL;
    while (crrId < CauseXnapProtocolEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    crrId = CAUSE_BASE_XNAP_MISC;
    while (crrId < CauseXnapMiscEnd)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_CRR, crrId++);
    }

    VCCB_LOG_FISHING->crrEventCount = eventCount;

    uint16_t eventId = VCCB_LOG_FISHING_MANUAL_EVENT_ID_START;
    while (eventId < LOG_FISHING_MANUAL_EVENT_ID_END)
    {
        FnVCCB_AddLogFishingEvent(eventCount++, LOG_FISHING_EVENT_TYPE_MANUAL, eventId++);
    }

    VCCB_LOG_FISHING->manualEventCount = (uint16_t)(eventCount - VCCB_LOG_FISHING->crrEventCount);
    VCCB_LOG_FISHING->eventCount = eventCount;

    return eventCount;
}

void FnVCCB_AddLogFishingEvent(uint16_t index, enumLogFishingEventType_type eventType, uint16_t eventId)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(index, VCCB_MAX_LOG_FISHING_EVENT_COUNT);

    VccbLogFishingEvent_type *pLogFishingEvent = &VCCB_LOG_FISHING->eventList[index];
    pLogFishingEvent->eventId = eventId;
    pLogFishingEvent->eventType = eventType;
    pLogFishingEvent->isLogging = TRUE;
    pLogFishingEvent->startLogIndex = (uint32_t)(index * MAX_SHM_LOG_FISHING_CNT_PER_EVENT);
    pLogFishingEvent->endLogIndex = pLogFishingEvent->startLogIndex + MAX_SHM_LOG_FISHING_CNT_PER_EVENT - 1;
    pLogFishingEvent->wIdx = pLogFishingEvent->startLogIndex;
    pLogFishingEvent->dataOffset = pLogFishingEvent->startLogIndex * SHM_LOG_SIZE;

    for (int threadId = 0; threadId < MAX_CALL_THREAD_NUM_VCCB; threadId++)
    {
        pLogFishingEvent->occurrenceCount[threadId] = 0;
        pLogFishingEvent->savedCount[threadId] = 0;
    }
}

int FnVCCB_InitMdsHandle(void)
{
    AUTO_TRACE_FUNC;

    int result = 0;
    int retryCount = 0;

    VCCB_PRINTF("VCCB Initialize MDS Handle...\n");

#ifndef IPC_TEST  // REAL Only
    if (VCOM_getSystemType() != e_VCCB_NVGNB)
    {
        mdsSetSendNonBlockOption(1);
    }
#endif

    for (retryCount = 0; retryCount < VCCB_MAX_MW_RETRY_COUNT; retryCount++)
    {
        result = HandleInitFunc(VccbHandleInitParam);
        VCCB_CHECK_RTCODE_SLEEP(result, "HandleInitFunc", retryCount);
    }
    if (result < 0)
    {
        return result;
    }

    // enumVccbHandleInit_type
    ENV->handle.vccb = VccbHandleInitParam[VCCB_MAIN_HANDLE].Handle;
#ifdef __CNF__
    ENV->handle.vccbRedisRestore = VccbHandleInitParam[VCCB_REDIS_RESTORE_HANDLE].Handle;
#endif
    ENV->handle.vccbMgmt = VccbHandleInitParam[VCCB_MGMT_HANDLE].Handle;
    ENV->handle.vccbPld = VccbHandleInitParam[VCCB_PLD_HANDLE].Handle;
    ENV->handle.vccbLog = VccbHandleInitParam[VCCB_INT_LOG_HANDLE].Handle;

    int i = 0;
    for (i = 0; i < MAX_CALL_THREAD_NUM_VCCB; i++)
    {
        ENV->handle.vccbCall[i] = VccbHandleInitParam[VCCB_INT_CALL0_HANDLE + i].Handle;
        ENV->handle.vccbExtCallCslTrace[i] = VccbHandleInitParam[VCCB_EXT_CALL_CSLTRACE_0_HANDLE + i].Handle;
    }
    ENV->handle.vccbKa = VccbHandleInitParam[VCCB_KA_HANDLE].Handle;
    ENV->handle.vccbExt =
        VccbHandleInitParam[VCCB_EXT_MAIN_HANDLE].Handle;  // If nanomsg is applied in NVGNB, vccbExt should be deleted.

    ENV->handle.vccbNonUe = VccbHandleInitParam[VCCB_EXT_NONUE_HANDLE].Handle;
    ENV->handle.vccbNonUeBigMsg = VccbHandleInitParam[VCCB_EXT_NONUE_BIGMSG_HANDLE].Handle;
    ENV->handle.vccbNonUeAsn1 = VccbHandleInitParam[VCCB_EXT_NONUE_ASN1_HANDLE].Handle;

    ENV->handle.vccbStatistics = VccbHandleInitParam[VCCB_INT_STATISTICS_HANDLE].Handle;

    ENV->handle.vccbExtRacsBigMsg = VccbHandleInitParam[VCCB_EXT_RACS_BIGMSG_HANDLE].Handle;
    ENV->handle.vccbIntRacs = VccbHandleInitParam[VCCB_INT_RACS_HANDLE].Handle;
    for (i = 0; i < VCCB_INT_RACS_BIGMSG_MBOX_MAX_NUM; i++)  // current : 2
    {
        ENV->handle.vccbIntRacsBigMsg[i] = VccbHandleInitParam[VCCB_INT_RACS_BIGMSG_0_HANDLE + i].Handle;
    }
    // VCCB_INT_RACS_BIGMSG_2_HANDLE
    // VCCB_INT_RACS_BIGMSG_3_HANDLE

    return GOOD;
}

int FnVCCB_SelectSubConfdIndex(void)
{
    int result = GOOD;
    CFG->confd.subConfdCount = dal_util_get_num_sub_confd();
    VCCB_PRINTF("[DAL] subConfdCount = %d\n", CFG->confd.subConfdCount);
    switch (CFG->confd.subConfdCount)
    {
        case 0:
        case 1:
            CFG->confd.selectedSubConfdIndex = -1;  // VCCB shall use the main-ConfD.
            break;

        case 2:
            CFG->confd.selectedSubConfdIndex = 2;
            result = dal_init_sub(CFG->confd.selectedSubConfdIndex);
            if (result < 0)
            {
                VCCB_PRINTF("[DAL] dal_init_sub error! (errno:%d)\n", result);
                return result;
            }
            break;

        case 3:
#ifdef __VNF__
            CFG->confd.selectedSubConfdIndex = ((CFG->vm.unitId / 2) % 2) + 2;
#else // __CNF__
            CFG->confd.selectedSubConfdIndex = (CFG->vm.unitId % 2) + 2;
#endif

            result = dal_init_sub(CFG->confd.selectedSubConfdIndex);
            if (result < 0)
            {
                VCCB_PRINTF("[DAL] dal_init_sub error! (errno:%d)\n", result);
                return result;
            }
            break;

        default:
            VCCB_PRINTF("[DAL] dal_util_get_num_sub_confd error! (subConfdCount:%d)\n", CFG->confd.subConfdCount);
            return ERROR;
    }
    VCCB_PRINTF("[DAL] selectedSubConfdIndex = %d\n", CFG->confd.selectedSubConfdIndex);
    return GOOD;
}

#ifdef __CNF__

void FnVCCB_PrepareCnfHa()
{
    AUTO_TRACE_FUNC;
    VccbEnvInfo_type *pEnv = ENV;
    if (pEnv->isSupportHA == CNF_HA_SUPPORT)
    {
        pEnv->keepAliveInfo.status = KA_BLOCK_SUSPEND;
        pEnv->keepAliveInfo.regReq = FLAG_OFF;

        FnVCCB_RecordTime(&pEnv->vccbInitTime.readRedisStart);
        VccbRedisConnection_type redisConnection;
        redisConnection.info = &pEnv->redis.backupConnInfo;
        redisConnection.info->firstConnectionFailFlag = FALSE;
        if (GOOD == FnVCCB_RestoreDbFromRedis(redisConnection))
        {
            FnVCCB_RedisFreeContext(redisConnection, REDIS_0);
            FnVCCB_RedisFreeContext(redisConnection, REDIS_1);
        }
        FnVCCB_RecordTime(&pEnv->vccbInitTime.readRedisEnd);
    }
    else
    {
        for (int distCode = VCCB_FIRST_DEFAULT_DIST_CODE;
             distCode < VCCB_FIRST_DEFAULT_DIST_CODE + MAX_ACTIVE_CPC_PER_SYS; ++distCode)
        {
            pEnv->distCodeInfo[distCode].isAllocated = TRUE;
        }
    }
}

void FnVCCB_GetCnfPodInformation(void)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_RTCODE_EXIT(FnVCCB_GetAcpfNeId(CFG->neId), "FnVCCB_GetAcpfNeId", EXIT_MDS_GET_IP);
    VCCB_CHECK_RTCODE_EXIT(FnVCCB_GetPodId(CFG->vm.unitType, CFG->vm.unitId), "FnVCCB_GetPodId", EXIT_MDS_GET_IP);
    VCCB_CHECK_RTCODE_EXIT(
        FnVCCB_GetAcpfRedundancyMode(ENV->isSupportHA), "FnVCCB_GetAcpfRedundancyMode", EXIT_MDS_GET_REDUNDANCY_FAIL);
    VCCB_CHECK_RTCODE_EXIT(FnVCCB_GetK8sNamespace(CFG->k8sNamespace), "FnVCCB_GetK8sNamespace", EXIT_K8S_GET_FAIL);
    VCCB_CHECK_RTCODE_EXIT(FnVCCB_GetPodNamePrefix(CFG->podNamePrefix), "FnVCCB_GetPodNamePrefix", EXIT_K8S_GET_FAIL);
    VCCB_CHECK_RTCODE_EXIT(FnVCCB_SetAllPodsSvcName(ENV->podInfo, CFG->podNamePrefix, CFG->vm.unitId),
        "FnVCCB_SetAllPodsSvcName", EXIT_K8S_GET_FAIL);
    VCCB_CHECK_RTCODE_EXIT(FnVCCB_GetK8sImage(ENV->keepAliveInfo.swVer, ENV->podInfo.podName, CFG->k8sNamespace),
        "FnVCCB_GetK8sImage", EXIT_K8S_GET_FAIL);
    VCCB_CHECK_RTCODE_EXIT(FnVCCB_GetTerminationCallReleaseWaitSeconds(CFG->acpfInfo.cnfUpgrade.terminationCallReleaseWaitSeconds),
        "FnVCCB_GetTerminationCallReleaseWaitSeconds", EXIT_MDS_GET_IP);
#ifndef IPC_TEST
    VCCB_CHECK_RTCODE_EXIT(
        FnVCCB_GetValkeyCertificateFileInfo(), "FnVCCB_GetValkeyCertificateFileInfo", EXIT_VCCB_FAIL_ACCESS_KEY);
#endif
}
#endif  // __CNF__

void FnVCCB_CheckAndApplyDebugFlag(void)
{
    if (0 == access("/var/log/command/VCCB_TEST_SWAP_GNBIDFROMNUM_ARRAY_0_AND_2", F_OK))
    {
        VCCB_PRINTF("@@ VCCB_TEST_SWAP_GNBIDFROMNUM_ARRAY_0_AND_2=TRUE\n");
        std::swap(CFG->gnbNumInfo.gnbIdFromNum[0], CFG->gnbNumInfo.gnbIdFromNum[2]);
        // FnVCCB_ExecuteCommand("rm -f /var/log/command/VCCB_TEST_SWAP_GNBIDFROMNUM_ARRAY_0_AND_2");
    }
    else
    {
        VCCB_PRINTF("@@ VCCB_TEST_SWAP_GNBIDFROMNUM_ARRAY_0_AND_2=FALSE (%d)\n", errno);
    }

    if (0 == access("/var/log/command/VCCB_TEST_PUSH_GNBIDFROMNUM_ARRAY_SEQUENTIALLY", F_OK))
    {
        VCCB_PRINTF("@@ VCCB_TEST_PUSH_GNBIDFROMNUM_ARRAY_SEQUENTIALLY=TRUE\n");
        gnbIdFromNum_type tempGnbIdFromNum = CFG->gnbNumInfo.gnbIdFromNum[2];
        CFG->gnbNumInfo.gnbIdFromNum[2] = CFG->gnbNumInfo.gnbIdFromNum[1];
        CFG->gnbNumInfo.gnbIdFromNum[1] = CFG->gnbNumInfo.gnbIdFromNum[0];
        CFG->gnbNumInfo.gnbIdFromNum[0] = tempGnbIdFromNum;
        // FnVCCB_ExecuteCommand("rm -f /var/log/command/VCCB_TEST_PUSH_GNBIDFROMNUM_ARRAY_SEQUENTIALLY");
    }
    else
    {
        VCCB_PRINTF("@@ VCCB_TEST_PUSH_GNBIDFROMNUM_ARRAY_SEQUENTIALLY=FALSE (%d)\n", errno);
    }
}

void FnVCCB_InitGlobalData(void)
{
    AUTO_TRACE_FUNC;

    int result = DAL_SUCCESS;
    VccbCfgInfo_type *pCfg = CFG;
    VccbEnvInfo_type *pEnv = ENV;
    int retryCount = 0;

#ifndef IPC_TEST  // REAL Only
#if defined(__NVGNB__)
    result = FnVCCB_GetNeInfo();
    VCCB_CHECK_RTCODE_EXIT(result, "FnVCCB_GetNeInfo", EXIT_SMI_GET_FAIL);

    result = GetNvgnbDimensioningInfo(&pEnv->drlibNvgnbInfo);
    VCCB_CHECK_RTCODE_EXIT(result, "GetNvgnbDimensioningInfo", EXIT_MDS_GET_IP);
#elif defined(__CNF__)
    FnVCCB_GetCnfPodInformation();
#endif

    // Get IP and Port
    result = FnVCCB_GetIpAndPort();
    VCCB_CHECK_RTCODE_EXIT(result, "FnVCCB_GetIpAndPort", EXIT_MDS_GET_IP);

    /* VPM Initialization */
    for (retryCount = 0; retryCount < VCCB_MAX_VPM_INIT_RETRY_COUNT; retryCount++)
    {
        result = FnVCCB_InitVPM();
        VCCB_CHECK_RTCODE_SLEEP(result, "FnVCCB_InitVPM", retryCount);
    }
    VCCB_CHECK_RTCODE_EXIT(result, "FnVCCB_InitVPM", EXIT_MW_INIT);

    if (e_VCCB_ACPF_VNF == VCOM_getSystemType())  // VNFC Redundancy feature
    {
        for (retryCount = 0; retryCount < VCCB_MAX_HAS_RETRY_COUNT; retryCount++)
        {
            result = FnVCCB_InitHas();
            VCCB_CHECK_RTCODE_SLEEP(result, "FnVCCB_InitHas", retryCount);
        }
        VCCB_CHECK_RTCODE_EXIT(result, "FnVCCB_InitHas", EXIT_INIT_TASK);

        FnVCCB_CheckAndApplyDebugFlag();

        FnVCCB_RegisterSwitchover();
        FnVCCB_UpdateVnfHasHistory(NULL, &pCfg->hasCpc, TRUE);

        if (FALSE == VCOM_IsHostSim())
        {
            // Register HAS Event for detecting CMC SwitchOver.
            FnVCCB_RegisterEnsEvent();
            FnVCCB_UpdateVnfHasHistory(&pCfg->confd.hasMainUnitState, NULL, TRUE);
        }
    }
    else if (e_VCCB_ACPF_CNF == VCOM_getSystemType() && FALSE == VCOM_IsHostSim())
    {
        // Register HAS Event for detecting POD SwitchOver.
        FnVCCB_RegisterEnsEvent();
    }

    FnVCCB_RecordTime(&pEnv->vccbInitTime.initBaseEnd);
#ifdef __CNF__
    FnVCCB_PrepareCnfHa();
#endif

    /* DAL Initialization */
    result = dal_init(VCCB_BLK_NAME, stderr, DAL_TRACE);
    VCCB_CHECK_RTCODE_EXIT(result, "dal_init", EXIT_MW_INIT);

    result = FnVCCB_SelectSubConfdIndex();
    VCCB_CHECK_RTCODE_EXIT(result, "FnVCCB_SelectSubConfdIndex", EXIT_MW_INIT);

    result = dal_load_schemas();
    VCCB_CHECK_RTCODE_EXIT(result, "dal_load_schemas", EXIT_MW_INIT);

    for (retryCount = 0; retryCount < NRCALL_MAX_DAL_RETRY_TO_CONNECT; retryCount++)
    {
        result = dal_db_connect(&pEnv->handle.vccbSubscribe, DAL_DB_SUBSCRIPTION_SOCKET);
        VCCB_CHECK_RTCODE_SLEEP(result, "dal_db_connect", retryCount);
    }
    VCCB_CHECK_RTCODE_EXIT(result, "dal_db_connect", EXIT_DB_CONNECT_FAIL);
#endif

    CFG->confd.state = enabled;
    CFG->confd.connectCount++;

#ifndef IPC_TEST  // REAL Only
    result = VDAL_SubscribeData(pEnv->handle.vccbSubscribe);
    if (GOOD != result)
    {
        VCCB_PRINTF_ERR("[DAL][ERROR][SUBSCRIPTION] Subscribe Data status(%d)\n", result);
        FnVCCB_DalWrapper_dal_db_close(&pEnv->handle.vccbSubscribe, __func__);
        CFG->confd.state = disabled;
        CFG->confd.disconnectCount++;
        VCCB_ONE_LOG_PRINT(LC_RESET, lc_dbSubFail, "[ERROR][SUBSCRIPTION] Subscribe Data status(%d)\n", result);
        VCCB_EXIT(EXIT_DB_SUBSCRIBE_FAIL);
    }
#endif

    pEnv->handle.vccbRead = -1;
    pEnv->handle.vccbDalOperSocket = -1;

#ifndef IPC_TEST  // REAL Only
    /* DAL Reader App for Initial Data */
    {
        Task::ThreadPriorityChanger mChanger(thsGetTid(), SCHED_OTHER, 38);
        result = VDAL_InitialDataReaderApp();
        VCCB_CHECK_RTCODE_EXIT(result, "VDAL_InitialDataReaderApp", EXIT_READ_YANG_FAIL);
    }
#endif

#ifndef IPC_TEST  // REAL Only
    /* DAL Notification App */
    result = VccbNotiHandler_initConnection();
    VCCB_CHECK_RTCODE_EXIT(result, "VccbNotiHandler_initConnection", EXIT_DB_CONNECT_FAIL);

#endif

#ifndef IPC_TEST
    // Whether to support Nanomsg is determined through Yang.
    // Therefore, Nanohandle gets after Yang Read.
    if (TRUE == pCfg->acpfInfo.isNanoSupport)
    {
        Task::ThreadPriorityChanger mChanger(thsGetTid(), SCHED_OTHER, 38);
        result = FnVCCB_GetNanoHandle();
        VCCB_CHECK_RTCODE_EXIT(result, "FnVCCB_GetNanoHandle", EXIT_MDS_GET_IP);
    }

    FnVCCB_SetTrafficManagementDSCP();
#endif

    pCfg->pld.state = enabled;

#ifndef IPC_TEST  // REAL Only
#if !defined(NEW_HOST_SIM) || defined(NEW_HOST_SIM_PLD) || defined(__CNF__)
    /* PLD Register */
    result = VCCB_RegisterPLD();
    VCCB_CHECK_RTCODE_EXIT(result, "VCCB_RegisterPLD", EXIT_DB_SUBSCRIBE_FAIL);
#endif
#endif

    /* PLD Read */
    for (retryCount = 0; retryCount < VCCB_READ_PLD_MAX_INIT_TOTAL_RETRY; retryCount++)
    {
        result = VCCB_InitialReadPld();
        if (result < 0)
        {
            VCCB_ONE_LOG_PRINT(LC_INFO, 0, "VCCB_InitialReadPld Failed(%d), retry=%d\n", result, retryCount);
            VCCB_PRINTF("VCCB_InitialReadPld Failed(%d), retry=%d\n", result, retryCount);
        }
        else
        {
            break;
        }
    }
    VCCB_CHECK_RTCODE_EXIT(result, "VCCB_InitialReadPld", EXIT_DB_SUBSCRIBE_FAIL);

#ifdef __CNF__
    if (pEnv->isRestoredFromRedisDB)
    {
        pEnv->shouldSkipReadingCellInfo = FALSE;
    }
#endif

    return;
}

#ifdef __NVGNB__
int FnVCCB_GetNeInfo(void)
{
    AUTO_TRACE_FUNC;

    int result = GOOD;
    int retryCount = 0;
    char shelfStr[VCCB_SHELF_ID_STR_LEN];
    char pbaStr[VCCB_PBA_ID_STR_LEN];
    char unitTypeStr[VCCB_UNIT_TYPE_STR_LEN];
    char cpuIdStr[VCCB_CPU_ID_STR_LEN];

    /* Initialization */
    memset(shelfStr, 0x00, sizeof(shelfStr));
    memset(pbaStr, 0x00, sizeof(pbaStr));
    memset(unitTypeStr, 0x00, sizeof(unitTypeStr));
    memset(cpuIdStr, 0x00, sizeof(cpuIdStr));

#ifdef IPC_TEST
    (void)result;
    (void)retryCount;
    ENV->neInfo.shelfId = 0;
    ENV->neInfo.pbaId = 0;
    ENV->neInfo.unitType = FMP;
    ENV->neInfo.cpuId = 0;
#else
    for (retryCount = 0; retryCount < MAX_RETRY_MDS_API; retryCount++)
    {
        result = smiGetNeInfoStr(SMI_SYSINFO_TYPE, "SHELF_ID", shelfStr, sizeof(shelfStr));
        if (result < 0)
        {
            VCCB_CHECK_RTCODE_SLEEP(result, "smiGetNeInfoStr for SHELF_ID", retryCount);
            continue;
        }

        uint16_t maxShelfId = 2;  // reference access-type-shelf-per-system-range
        ENV->neInfo.shelfId = util::str::vccb_strtoul<uint16_t>(shelfStr);
        if (ENV->neInfo.shelfId > maxShelfId)
        {
            VCCB_PRINTF("[%s]ShelfId is out of range.\n", __FUNCTION__);
        }
        VCCB_PRINTF("[%s]Get ShelfId(%d)\n", __FUNCTION__, ENV->neInfo.shelfId);
        break;
    }

    if (result < 0)
    {
        return result;
    }

    for (retryCount = 0; retryCount < MAX_RETRY_MDS_API; retryCount++)
    {
        result = smiGetNeInfoStr(SMI_SYSINFO_TYPE, (char *)"PBA_ID", pbaStr, sizeof(pbaStr));
        if (result < 0)
        {
            VCCB_CHECK_RTCODE_SLEEP(result, "smiGetNeInfoStr for PBA_ID", retryCount);
            continue;
        }

        ENV->neInfo.pbaId = (int)strtol((const char *)pbaStr, (char **)NULL, 10);  // convert to base10 integer
        VCCB_PRINTF("[%s]Get PBAId(%d)\n", __FUNCTION__, ENV->neInfo.pbaId);
        break;
    }

    if (result < 0)
    {
        return result;
    }

    // get UNIT_TYPE
    for (retryCount = 0; retryCount < MAX_RETRY_MDS_API; retryCount++)
    {
        result = smiGetNeInfoStr(SMI_SYSINFO_TYPE, (char *)"UNIT_TYPE", unitTypeStr, sizeof(unitTypeStr));
        if (result < 0)
        {
            VCCB_CHECK_RTCODE_SLEEP(result, "smiGetNeInfoStr for UNIT_TYPE", retryCount);
            continue;
        }

        if (strcmp("FMP", unitTypeStr) == 0)
        {
            ENV->neInfo.unitType = FMP;
        }
        else if (strcmp("FIMP", unitTypeStr) == 0)
        {
            ENV->neInfo.unitType = FIMP;
        }
        else
        {
            VCCB_PRINTF_ERR("UNIT_TYPE is Invalid! UNIT_TYPE: %s", unitTypeStr);
            return ERROR;
        }

        VCCB_PRINTF("[%s]Get unitType(%s)\n", __FUNCTION__, unitTypeStr);
        break;
    }

    // get CPU_ID
    for (retryCount = 0; retryCount < MAX_RETRY_MDS_API; retryCount++)
    {
        result = smiGetNeInfoStr(SMI_SYSINFO_TYPE, (char *)"CPU_ID", cpuIdStr, sizeof(cpuIdStr));
        if (result < 0)
        {
            VCCB_CHECK_RTCODE_SLEEP(result, "smiGetNeInfoStr for CPU_ID", retryCount);
            continue;
        }

        ENV->neInfo.cpuId = (int)strtol((const char *)cpuIdStr, (char **)NULL, 10);

        if ((ENV->neInfo.cpuId < 0) || (ENV->neInfo.cpuId >= MAX_CPU_PER_SLOT))
        {
            VCCB_PRINTF_ERR("Invalid CPU number!(%s/%d) change to 0", cpuIdStr, ENV->neInfo.cpuId);
            ENV->neInfo.cpuId = 0;
        }

        VCCB_PRINTF("[%s]Get cpuId(%d)\n", __FUNCTION__, ENV->neInfo.cpuId);
        break;
    }

#endif
    return result;
}
#endif

/**
 * @brief This function is responsible for initializing the VPM. It is a wrapper function for handling exceptions for C
 * exception handling.
 */
int FnVCCB_InitVPM(void)
{
    AUTO_TRACE_FUNC;

    int status = 0;

    try
    {
        status = vpmInitialize(VCCB_BLK_NAME);
    }
    catch (const std::exception &e)
    {
        VCCB_PRINTF("Exception(f:%s):(C:%s): ", __func__, e.what());
    }
    catch (...)
    {
        VCCB_PRINTF("Exception(f:%s):(C:Unknown): ", __func__);
    }

    if (status < 0)
    {
        VCCB_PRINTF("vpmInitialize(%d) ERROR : EXIT\n", status);
        return ERROR;
    }

    return GOOD;
}

/**
 * @brief   This function is to get Max Has Sync Num for ACPF Flavor.
 * @brief   find the number of HAS API calls for (Basic Call Setup + Release) on max BHCA scenario.
 */

int FnVCCB_GetMaxHasSyncNum()
{
    AUTO_TRACE_FUNC;
    int maxHasSync = 0;
    // -----------------------------------------------------------------
    // 1. Get 1 Call Dup Count = Setup(1 Call backup + Uplink Nas + Ue Capa Enquiry) + Release(Uplink NAS + State change
    // + Usage Change)
    // -----------------------------------------------------------------
#define HAS_CNT_ULNAS        2  // Uplink Nas Dup Count = 2 ( SRB + User Inactivity )
#define HAS_CNT_UCE          4  // UE Capa Enquiry = 4 ( 2Step :  SRB info + UE Info + MR-DC Capa+ Eutra Capa)
#define HAS_CNT_STATE_CHANGE 1  // State Change = 1 ( Conn --> XXX )
#define HAS_CNT_USAGE_CHANGE 1  // Usage Change = 1 ( Used --> Not Used )

    callInfo_type *ptCi = &ENV->callInfo[0];
    uint32_t firstVariableDupSizeInCall = 0, secondVariableDupSizeInCall = 0, oneCallDupCount = 0,
             wholeCallSetupDupCount;

    // 1-1. 1st Variable Dup in callInfo_type : usage ~ hoRestrict in callInfo_type
    firstVariableDupSizeInCall = (uint32_t)((long)(&ptCi->backupSeqNum_last) - (long)(ptCi));
    oneCallDupCount = (firstVariableDupSizeInCall + VCCB_MAX_CHUNK_SIZE - 1) / VCCB_MAX_CHUNK_SIZE;
    VCCB_PRINT_MSG("[Call HAS Count]\n");
    VCCB_PRINT_MSG("firstVariableDupSizeInCall : %u(Num of HAS Chunk: %u)\n", firstVariableDupSizeInCall,
        (firstVariableDupSizeInCall + VCCB_MAX_CHUNK_SIZE - 1) / VCCB_MAX_CHUNK_SIZE);

    // 1-2. 2nd Variable Dup in callInfo_type :  backupSeqNum_last ~ locRpt
    secondVariableDupSizeInCall = ((uint32_t)((long)(&ptCi->cause) - (long)(ptCi))) - firstVariableDupSizeInCall;
    oneCallDupCount += (secondVariableDupSizeInCall + VCCB_MAX_CHUNK_SIZE - 1) / VCCB_MAX_CHUNK_SIZE;
    VCCB_PRINT_MSG("secondVariableDupSizeInCall = %u(Num of HAS Chunk : %u)\n", secondVariableDupSizeInCall,
        (secondVariableDupSizeInCall + VCCB_MAX_CHUNK_SIZE - 1) / VCCB_MAX_CHUNK_SIZE);

    wholeCallSetupDupCount =
        oneCallDupCount + (HAS_CNT_ULNAS * 2) + HAS_CNT_UCE + HAS_CNT_STATE_CHANGE + HAS_CNT_USAGE_CHANGE;
    VCCB_PRINT_MSG("CallInfo HAS Count = %u\nWhole CallSetup Procedure HAS Count = %u\n\n", oneCallDupCount,
        wholeCallSetupDupCount);

    // -----------------------------------------------------------------
    // 2. Get Dup Count in Max BHCA. = (Call Request Per Second) * (Has Buffering) * (Dup Count per 1 Call Flow)
    // -----------------------------------------------------------------
#define MAX_VCCB_CALL_BHCA             40000000  // 40,000,000  40M BHCA
#define VCCB_HOUR_TO_SECOND_CONVERSION 3600      // 3,600 second ( 1 hour )
#define VCCB_HAS_THREAD_BUFFERING_TIME 2

    uint32_t callRequestPerSecond, maxCallFlowDupCount;

    callRequestPerSecond = (MAX_VCCB_CALL_BHCA + VCCB_HOUR_TO_SECOND_CONVERSION - 1) / VCCB_HOUR_TO_SECOND_CONVERSION;

    maxCallFlowDupCount = callRequestPerSecond * VCCB_HAS_THREAD_BUFFERING_TIME * wholeCallSetupDupCount;
    VCCB_PRINT_MSG("[MAX BHCA HAS Count]\ncallRequestPerSecond : %u, maxCallFlowDupCount : %u\n\n",
        callRequestPerSecond, maxCallFlowDupCount);

    // -----------------------------------------------------------------
    // 3. Get Cell Dup Count
    // -----------------------------------------------------------------
    uint32_t oneCellSize, oneCellDupCount, maxCellDupCount;

    oneCellSize = sizeof(VccbCellInfo_type);
    oneCellDupCount = sizeof(VccbCellInfo_type) / VCCB_MAX_CHUNK_SIZE;
    if (oneCellSize % VCCB_MAX_CHUNK_SIZE) oneCellDupCount++;
#ifndef HOST_SIM
    maxCellDupCount = oneCellDupCount * MAX_CELL_NUM_VCCB;
    VCCB_PRINT_MSG(
        "[Cell DUP Count]\noneCellSize=%u, oneCellDupCount = %u, MAX_CELL_NUM_VCCB = %u, maxCellDupCount = %u\n\n",
        oneCellSize, oneCellDupCount, MAX_CELL_NUM_VCCB, maxCellDupCount);
#else
    maxCellDupCount = oneCellDupCount * 2048;
    VCCB_PRINT_MSG(
        "[Cell DUP Count]\noneCellSize=%u, oneCellDupCount = %u, MAX_CELL_NUM_VCCB = %d, maxCellDupCount = %u\n\n",
        oneCellSize, oneCellDupCount, 2048, maxCellDupCount);
#endif

    // -----------------------------------------------------------------
    // 4. Get Max Sync Num  ( = maxCallFlowDupCount + maxCellDupCount )
    // -----------------------------------------------------------------
    maxHasSync = (int)((maxCallFlowDupCount + maxCellDupCount + 999) / 1000 * 1000);  // Round off from 1000
    VCCB_PRINT_MSG("[RESULT]\nmaxHasSync = %d\n", maxHasSync);

    return maxHasSync * 2;
}

int16_t FnVCCB_InitHas()
{
    AUTO_TRACE_FUNC;

    int ret = 0;
    int hasKey = 0;
    int hasDumpFromStandbyFlag =
        OFF;  // Control dump from Stanby to Active when VCCB restarts on Active CPC. ON: Dump. OFF: not Dump.

    MACRO_STATIC_ASSERT(MAX_CALL_COUNT_PER_CPC / (UINT_MAX / sizeof(callInfo_type)) + 1 <= VCCB_NUM_CALLINFO_CHUNKS,
        "Too many calls. Unable to register in HAS");

    // Get Has State
    ret = hasGetState(HAS_UNIT_STATE, &CFG->hasCpc);
    if (ret < 0)
    {
        VCCB_PRINT_ERROR("%s : hasGetState fail. ret:%d\n", __FUNCTION__, ret);
        return (int16_t)ret;
    }

    // protection code for delayed block loading
    // except CU UPGRADE procedure, send StartAckNoti message to SWM early, not to occur function fail
#ifndef IPC_TEST
    if (HAS_SYNC_MODE == CFG->hasCpc.SyncMode)
    {
        FnVCCB_SendStartAckNoti();
    }
#endif

    ret = hasSetDumpFromStandby(hasDumpFromStandbyFlag);
    if (ret < 0)
    {
        VCCB_PRINT_ERROR("%s : hasSetDumpFromStandby fail. ret:%d\n", __FUNCTION__, ret);
        return (int16_t)ret;
    }

    // HAS Set option for Backup
    /** This is configuration for HAS queue size on HAL library.
    [Configuration for 'HasOption.BackupProperty.MaxSyncCall' on SVR 21C]
    1. 40M BHCA call
    2. All Cell Backup
    3. HAS Transfer delay : 2sec **/

    HasOption_Type HasOption;
    HasOption.BackupProperty.MBox = VCCB_INT_HAS_BACKUP_MBOX;
    HasOption.BackupProperty.Priority = 90;                            // default value for hal thread
    HasOption.BackupProperty.Core = 0xFF;                              // no assign core (ACTIVE side)
    HasOption.BackupProperty.MaxSyncCall = FnVCCB_GetMaxHasSyncNum();  // buffer size for backup
    CFG->maxHasSync = (uint32_t)HasOption.BackupProperty.MaxSyncCall;            // save it to retrieve.
    ret = hasSetOption(HAS_BACKUP_PROPERTY, &HasOption);
    if (ret < 0)
    {
        VCCB_PRINTF("hasSetOption() FAIL(ret = %d)!!\n", ret);
        return (int16_t)ret;
    }
    VCCB_PRINTF("hasSetOption Done!\n");  // TBD

    ret = hasSetMultiDump(VCCB_HAS_MULTI_DUMP_MIN_SIZE, VCCB_HAS_MULTI_DUMP_SPLIT_COUNT);
    if (ret < 0)
    {
        VCCB_PRINTF("hasSetMultiDump Error (%d)\n", ret);
    }

    ret = hasSetDumpInterval(VCCB_HAS_DUMP_PACKET_COUNT_PER_INTERVAL, VCCB_HAS_DUMP_INTERVAL);
    if (ret < 0)
    {
        VCCB_PRINTF("hasSetDumpInterval Error (%d)\n", ret);
    }

    // Register HAS data
    for (hasKey = VCCB_HAS_KEY_CALL_INFO_CHUNK_0; hasKey < VCCB_HAS_KEY_END; hasKey++)
    {
        ret = FnVCCB_RegisterHasData(hasKey);
        if (ret != GOOD)
        {
            VCCB_PRINTF("VCCB_InitBackup Error hasKey(%d)\n", hasKey);
            return (int16_t)ret;  // EXIT_HAS_KEY_REGI_FAIL(20), EXIT_HAS_REGI_DATA_FAIL(21)
        }
    }

#if defined(__VNF__) && !defined(NEW_HOST_SIM)
    ComCoreAffinity::InitHasAffinity();
#endif

    //-----------------------
    // End of Registration
    //-----------------------
    VCCB_PRINTF("HAS Dump Start\n");
    ret = hasRegisterDataEnd((unsigned char)hasDumpFromStandbyFlag);
    if (ret < 0)
    {
        VCCB_PRINTF("hasRegisterDataEnd Error (%d)\n", ret);
        return EXIT_HAS_REGI_DATA_END_FAIL;  // 22
    }
    VCCB_PRINTF("HAS Dump End\n");

    //-----------------------
    // ready to dump
    //-----------------------
    ret = hasCommitData(0);
    if (ret < 0)
    {
        VCCB_PRINTF("hasCommitData Error (%d)\n", ret);
        return EXIT_HAS_COMMIT_DATA_FAIL;  // 23
    }

    return GOOD;
}

void FnVCCB_AllocateCallInfoChunk(void)
{
    AUTO_TRACE_FUNC;

    int hasKey = VCCB_HAS_KEY_CALL_INFO_CHUNK_0;
    uint32_t dividedCount = VCCB_MAX_CALL_COUNT_PER_CPC / VCCB_NUM_CALLINFO_CHUNKS;
    uint32_t remainedCount = VCCB_MAX_CALL_COUNT_PER_CPC % VCCB_NUM_CALLINFO_CHUNKS;
    uint32_t callIdToStartAllocation = 0;
    for (int index = 0; index < VCCB_NUM_CALLINFO_CHUNKS; index++)
    {
        CallHasKeyInfo_type *pCallKeyInfo = &ENV->hasInfo.callHasKeyInfo[index];
        pCallKeyInfo->hasKey = hasKey;
        pCallKeyInfo->allocatedCallCount = dividedCount;
        if (remainedCount > 0)
        {
            pCallKeyInfo->allocatedCallCount++;
            remainedCount--;
        }

        pCallKeyInfo->firstCallId = callIdToStartAllocation;
        pCallKeyInfo->lastCallId = pCallKeyInfo->firstCallId + pCallKeyInfo->allocatedCallCount - 1;
        callIdToStartAllocation += pCallKeyInfo->allocatedCallCount;
        hasKey++;
    }
    return;
}

void FnVCCB_AllocateCellInfoChunk(void)
{
    AUTO_TRACE_FUNC;

    int hasKey = VCCB_HAS_KEY_CELL_INFO_1; // cellinfo base
    uint32_t dividedCount = (MAX_CELL_NUM_VCCB) / VCCB_NUM_CELLINFO_CHUNKS;
    uint32_t remainedCount = (MAX_CELL_NUM_VCCB) % VCCB_NUM_CELLINFO_CHUNKS;
    uint32_t cellNumToStartAllocation = 0;

    for (int index = 0; index < VCCB_NUM_CELLINFO_CHUNKS; index++)
    {
        CellHasKeyInfo_type *pCellKeyInfo = &ENV->hasInfo.cellHasKeyInfo[index];
        pCellKeyInfo->hasKey = hasKey;
        pCellKeyInfo->allocatedCellCount = dividedCount;
        if (remainedCount > 0)
        {
            pCellKeyInfo->allocatedCellCount++;
            remainedCount--;
        }

        pCellKeyInfo->firstCellNum = cellNumToStartAllocation;
        pCellKeyInfo->lastCellNum = pCellKeyInfo->firstCellNum + pCellKeyInfo->allocatedCellCount - 1;
        cellNumToStartAllocation += pCellKeyInfo->allocatedCellCount;
        hasKey++;
    }
    return;
}

int16_t FnVCCB_RegisterHasData(int hasKey)
{
    AUTO_TRACE_FUNC;

    int ret = 0;
    void *addr;
    uint64_t size;

    if (GOOD != FnVCCB_GetInfoForHasKey(hasKey, &addr, &size))
    {
        VCCB_PRINTF("VccbRegisterHasKey Error, hasKey(%u)\n", hasKey);
        return EXIT_HAS_KEY_REGI_FAIL;  // 18
    }

    if (size == 0)
    {
        return GOOD;
    }

    if ((ret = hasRegisterData(hasKey, 0, 0, addr, size)) < 0)
    {
        VCCB_PRINTF("hasRegisterData Error HasKey(%u), ret(0x%x)\n", hasKey, ret);
        return EXIT_HAS_REGI_DATA_FAIL;  // 19
    }

    return GOOD;
}

int16_t FnVCCB_GetInfoForHasKey(int hasKey, void **addr, uint64_t *size)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(addr);
    VALID_E_POINT_CHECK_ERROR(size);

    uint16_t gnbNum;
    VccbGnbInfo_type *pGnb;

    switch (hasKey)
    {
        case VCCB_HAS_KEY_GNB_NUM_INFO:
            *addr = &CFG->gnbNumInfo;
            *size = sizeof(gnbNumInfo_type);
            break;

        case VCCB_HAS_KEY_CALL_INFO_CHUNK_0 ... VCCB_HAS_KEY_CALL_INFO_CHUNK_29:
        {
            *addr = NULL;
            *size = 0;
            int index = hasKey - VCCB_HAS_KEY_CALL_INFO_CHUNK_0;
            CallHasKeyInfo_type *pCallHasKeyInfo = &ENV->hasInfo.callHasKeyInfo[index];
            uint32_t firstCallId = pCallHasKeyInfo->firstCallId;
            VCCB_CHECK_E_RANGE_AND_RETURN(firstCallId, MAX_CALL_NUM_VCCB);
            *addr = &ENV->callInfo[firstCallId];
            *size = sizeof(callInfo_type) * pCallHasKeyInfo->allocatedCallCount;

            if (*addr == NULL || *size == 0)
            {
                VCCB_PRINT_CRITICAL("%s: Invalid Data(Check ENV->hasInfo.callHasKeyInfo)\n", __FUNCTION__);
                return ERROR;
            }
            break;
        }

        case VCCB_HAS_KEY_CELL_INFO_1 ... VCCB_HAS_KEY_CELL_INFO_2:
        {
            *addr = NULL;
            *size = 0;
            int index = hasKey - VCCB_HAS_KEY_CELL_INFO_1;
            CellHasKeyInfo_type *pCellHasKeyInfo = &ENV->hasInfo.cellHasKeyInfo[index];
            uint32_t firstCellNum = pCellHasKeyInfo->firstCellNum;
            VCCB_CHECK_E_RANGE_AND_RETURN(firstCellNum, MAX_CELL_NUM_VCCB);
            *addr = &CELLINFO[firstCellNum];
            *size = sizeof(VccbCellInfo_type) * pCellHasKeyInfo->allocatedCellCount;

            if (*addr == NULL || *size == 0)
            {
                VCCB_PRINT_CRITICAL("%s: Invalid Data(Check ENV->hasInfo.cellHasKeyInfo)\n", __FUNCTION__);
                return ERROR;
            }
            break;
        }

        case VCCB_HAS_KEY_GNB_ENV_INFO_GNB_0 ... VCCB_HAS_KEY_GNB_ENV_INFO_GNB_15:  // MAX_GNB_PER_SYS
            gnbNum = (uint16_t)(hasKey - VCCB_HAS_KEY_GNB_ENV_INFO_GNB_0);
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_CU_CP_FUNCTION_PER_SYS);
            if (gnbNum >= MAX_GNB_PER_SYS)
            {
                *size = 0;  // not to register when gnbNum is over MAX_GNB_PER_SYS
            }
            else
            {
                pGnb = &GNBINFO[gnbNum];
                *addr = &pGnb->env;
                *size = sizeof(pGnb->env);
            }
            break;

        case VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_0 ... VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_15:  // NAX_GNB_PER_SYS
            gnbNum = (uint16_t)(hasKey - VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_0);
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_CU_CP_FUNCTION_PER_SYS);
            if (gnbNum >= MAX_GNB_PER_SYS)
            {
                *size = 0;  // not to register when gnbNum is over MAX_GNB_PER_SYS
            }
            else
            {
                pGnb = &GNBINFO[gnbNum];
                *addr = pGnb->gnbDu;
                *size = sizeof(pGnb->gnbDu);
            }
            break;

        case VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_0 ... VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_15:  // NAX_GNB_PER_SYS
            gnbNum = (uint16_t)(hasKey - VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_0);
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_CU_CP_FUNCTION_PER_SYS);
            if (gnbNum >= MAX_GNB_PER_SYS)
            {
                *size = 0;  // not to register when gnbNum is over MAX_GNB_PER_SYS
            }
            else
            {
                pGnb = &GNBINFO[gnbNum];
                *addr = &pGnb->supportedFreqBandInfo;
                *size = sizeof(pGnb->supportedFreqBandInfo);
            }
            break;

            /*  Add keys for other redundant blocks if needed */

        default:
            VCCB_PRINTF("%s: Invalid HasKey(%d)\n", __FUNCTION__, hasKey);
            return ERROR;
    }

    return GOOD;
}

void FnVCCB_UpdateVnfHasHistory(HasActMainUnitState_Type *pCmc, HasUnitState_Type *pCpc, uint8_t isInitProc)
{
    AUTO_TRACE_FUNC;

    if (VCOM_getSystemType() != e_VCCB_ACPF_VNF) return;
    if ((pCmc == NULL) && (pCpc == NULL)) return;

    VccbDbgHasEventHistory_type *pHist = &DBG->hasEventHist;
    VccbHasInfo_type *pInfo = NULL;

    long currentTime;
    int16_t curIdx = pHist->curIdx;

    if (curIdx == -1 || curIdx >= MAX_HISTORY_NUM)  // 1st case or curIdx was corrupted case
    {
        curIdx = 0;
        pHist->cycleFlag = VCCB_FLAG_OFF;
    }
    else if (curIdx == MAX_HISTORY_NUM - 1)
    {
        curIdx = 0;
        pHist->cycleFlag = VCCB_FLAG_ON;
    }
    else
    {
        curIdx++;
    }

    pHist->curIdx = curIdx;
    pInfo = &pHist->hasHist[curIdx];

    pInfo->isInitProc = (bool)isInitProc;
    if (pCmc != NULL)
    {
        pInfo->isMainUnit = TRUE;
        memcpy(&pInfo->cmc, pCmc, sizeof(HasActMainUnitState_Type));
    }
    else
    {
        pInfo->isMainUnit = FALSE;
        memcpy(&pInfo->cpc, pCpc, sizeof(HasUnitState_Type));
    }

    if (time(&currentTime) > 0) pInfo->updateTime = currentTime;

    return;
}

void FnVCCB_RegisterSwitchover(void)
{
    AUTO_TRACE_FUNC;

    int ret = 0;
    int RetryCnt = 0;
#if !defined(NEW_HOST_SIM) || (defined(__CNF__) && !defined(IPC_TEST))
    int isRegisteredSwitchOver = FALSE;
    MsgHeader_Type usrMsg;
#endif

    // Get HAS State of CPC
    for (RetryCnt = 0; RetryCnt < VCCB_MAX_HAS_RETRY_COUNT; RetryCnt++)
    {
        ret = hasGetState(HAS_UNIT_STATE, &CFG->hasCpc);
        if (ret < 0)
        {
            VCCB_PRINTF("%s: hasGetState(CPC) fail(ret:%d, RetryCnt:%d)\n", __FUNCTION__, ret, RetryCnt);
            thsSleep(1000);
            continue;
        }
        else
        {
            VCCB_PRINTF("%s: hasGetState(CPC) Success, State:%d \n", __FUNCTION__, CFG->hasCpc.State);
            break;
        }
    }

    if (RetryCnt >= VCCB_MAX_HAS_RETRY_COUNT)
    {
        VCCB_EXIT(EXIT_HAS_GET_STATE_FAIL);
    }

#if !defined(NEW_HOST_SIM) || (defined(__CNF__) && !defined(IPC_TEST))
    // Register Switchover
    usrMsg.msg_id = msgMGMTSwitchOverReportEns_id;
    ENDIAN_CONVERT(usrMsg.msg_id);

    for (RetryCnt = 0; RetryCnt < VCCB_MAX_HAS_RETRY_COUNT; RetryCnt++)
    {
        if (isRegisteredSwitchOver == FALSE)
        {
            // EV_UNIT_SWITCHOVER
            ret = ensRegisterEvent(
                EV_UNIT_SWITCHOVER, MDS_ATTR_IP_TYPE_IIIP, ENV->addr.vccbMgmt.MdsPort, &usrMsg, sizeof(MsgHeader_Type));
            if (ret < 0)
            {
                VCCB_PRINTF("%s: ensRegisterEvent(CPC:EV_UNIT_SWITCHOVER) fail(ret:%d, port=0x%x, RetryCnt:%d)\n",
                    __FUNCTION__, ret, ENV->handle.vccbMgmt, RetryCnt);
                thsSleep(1000);
                continue;
            }
            else
            {
                VCCB_PRINTF("%s: ensRegisterEvent(CPC:EV_UNIT_SWITCHOVER) Success.\n", __FUNCTION__);
                isRegisteredSwitchOver = TRUE;
                // break;
            }
        }

        // EV_SYNC_MODE_CHANGE
        ret = ensRegisterEvent(
            EV_SYNC_MODE_CHANGE, MDS_ATTR_IP_TYPE_IIIP, ENV->addr.vccbMgmt.MdsPort, &usrMsg, sizeof(MsgHeader_Type));
        if (ret < 0)
        {
            VCCB_PRINTF("%s: ensRegisterEvent(CPC:EV_SYNC_MODE_CHANGE) fail(ret:%d, port=0x%x, RetryCnt:%d)\n",
                __FUNCTION__, ret, ENV->handle.vccbMgmt, RetryCnt);
            thsSleep(1000);
            continue;
        }
        else
        {
            VCCB_PRINTF("%s: ensRegisterEvent(CPC:EV_SYNC_MODE_CHANGE) Success.\n", __FUNCTION__);
            break;
        }
    }

    if (RetryCnt >= VCCB_MAX_HAS_RETRY_COUNT)
    {
        VCCB_EXIT(EXIT_ENS_REGI_EVENT_FAIL);
    }
#endif

    return;
}

static void FnVCCB_UpdateCNFRedundancyState(void)
{
#if defined(__CNF__)
    int ret = 0;
    int loop = 0;
    int podId = 0;
    HasAllUnitState_Type *newAllUnitState = &CFG->confd.hasAllUnitState;

    VCCB_PRINTF("%s: hasGetState(HAS_ALL_UNIT_STATE)\n", __FUNCTION__);
    // CNF HA Support FR changed(20211105): check result of hasGetState() infinitely
    while (1)
    {
        ret = hasGetState(HAS_ALL_UNIT_STATE, newAllUnitState);
        if (ret < 0)
        {
            VCCB_PRINTF("%s: hasGetState(HAS_ALL_UNIT_STATE) Fail (ret:%d)\n", __FUNCTION__, ret);
            thsSleep(VCCB_RETRY_WAIT_TIME * 1000);
        }
        else
        {
            break;
        }
    }

    for (loop = 0; loop < newAllUnitState->MemberNum && loop < MAX_UNITSTATE_ELEM_SIZE; loop++)
    {
        podId = newAllUnitState->Elem[loop].UnitId;
        if (podId >= VCCB_MAX_HA_UNIT_NUM || podId < 0)
        {
            VCCB_PRINTF("%s: invalid podId(%d) Elem[%d].UnitType=%d\n", __FUNCTION__, podId, loop,
                newAllUnitState->Elem[loop].UnitType);
            continue;
        }

        switch (newAllUnitState->Elem[loop].UnitType)
        {
            case CIP:
                VCCB_PRINTF("%s: Set CIP[%d] Redundancy State (%d -> %d)\n", __FUNCTION__, podId,
                    ENV->podInfo.cip[podId].redundancyState,
                    (enumRedundancyStateType)newAllUnitState->Elem[loop].State);
                ENV->podInfo.cip[podId].redundancyState = (enumRedundancyStateType)newAllUnitState->Elem[loop].State;
                break;
            case CMP:
                VCCB_PRINTF("%s: Set CMP[%d] Redundancy State (%d -> %d)\n", __FUNCTION__, podId,
                    ENV->podInfo.cmp[podId].redundancyState,
                    (enumRedundancyStateType)newAllUnitState->Elem[loop].State);
                ENV->podInfo.cmp[podId].redundancyState = (enumRedundancyStateType)newAllUnitState->Elem[loop].State;
                break;
            case CSP:
                VCCB_PRINTF("%s: Set CSP[%d] Redundancy State (%d -> %d)\n", __FUNCTION__, podId,
                    ENV->podInfo.csp[podId].redundancyState,
                    (enumRedundancyStateType)newAllUnitState->Elem[loop].State);
                ENV->podInfo.csp[podId].redundancyState = (enumRedundancyStateType)newAllUnitState->Elem[loop].State;
                break;
            default:
                break;
        }
    }
#endif
}

void FnVCCB_RegisterEnsEvent(void)
{
    AUTO_TRACE_FUNC;

    EventType_enum eventType;
    int ret = 0;
    int RetryCnt = 0;
    MsgHeader_Type usrMsg;

    if (e_VCCB_ACPF_VNF == VCOM_getSystemType())  // VNFC Redundancy feature
    {
        // Get HAS State of CMC
        for (RetryCnt = 0; RetryCnt < VCCB_MAX_HAS_RETRY_COUNT; RetryCnt++)
        {
            // xMC Main board State
            ret = hasGetState(HAS_MAIN_UNIT_STATE, &CFG->confd.hasMainUnitState);
            if (ret < 0)
            {
                VCCB_PRINTF("%s: hasGetState(MainUnit) fail(ret:%d, RetryCnt:%d)\n", __FUNCTION__, ret, RetryCnt);
                thsSleep(1000);
                continue;
            }
            else
            {
                VCCB_PRINTF("%s: hasGetState(MainUnit) Success. VnfcType=%d, vnfcId=%d\n", __FUNCTION__,
                    CFG->confd.hasMainUnitState.VnfcType, CFG->confd.hasMainUnitState.VnfcId);
                break;
            }
        }

        if (RetryCnt >= VCCB_MAX_HAS_RETRY_COUNT)
        {
            VCCB_EXIT(EXIT_HAS_GET_STATE_FAIL);
        }

        // Register ENS Event
        usrMsg.msg_id = msgMGMTMainUnitSwitchOverReportEns_id;
        eventType = EV_MAIN_UNIT_SWITCHOVER;
    }
    else if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
    {
        usrMsg.msg_id = msgMGMTAllUnitSwitchOverReportEns_id;
        eventType = EV_ALL_UNIT_SWITCHOVER;
    }
    else if (e_VCCB_NVGNB == VCOM_getSystemType())
    {
        VCCB_PRINTF("%s: systemType is NVGNB..  just return\n", __FUNCTION__);
        return;
    }
    else
    {
        VCCB_PRINTF("%s: Invalid systemType(%d)\n", __FUNCTION__, VCOM_getSystemType());
        VCCB_EXIT(EXIT_ENS_REGI_EVENT_FAIL);
    }

    // Not used
    usrMsg.version = 0;
    usrMsg.reserved = 0;
    ENDIAN_CONVERT(usrMsg.msg_id);

    for (RetryCnt = 0; RetryCnt < VCCB_MAX_HAS_RETRY_COUNT; RetryCnt++)
    {
        ret = ensRegisterEvent(
            eventType, MDS_ATTR_IP_TYPE_IIIP, ENV->addr.vccbMgmt.MdsPort, &usrMsg, sizeof(MsgHeader_Type));
        if (ret < 0)
        {
            VCCB_PRINTF("%s: ensRegisterEvent(UNIT_SWITCHOVER) fail(ret:%d, port=0x%x, RetryCnt:%d)\n", __FUNCTION__,
                ret, ENV->handle.vccbMgmt, RetryCnt);
            thsSleep(1000);
            continue;
        }
        else
        {
            VCCB_PRINTF("%s: ensRegisterEvent(UNIT_SWITCHOVER) Success.\n", __FUNCTION__);
            break;
        }
    }

    if (RetryCnt >= VCCB_MAX_HAS_RETRY_COUNT)
    {
        VCCB_EXIT(EXIT_ENS_REGI_EVENT_FAIL);
    }

    if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
    {
        FnVCCB_UpdateCNFRedundancyState();
    }

    return;
}

void FnVCCB_InitOamApiHandle(void)
{
    AUTO_TRACE_FUNC;

#if !defined(IPC_TEST) && (!defined(NEW_HOST_SIM) || defined(__CNF__))

    VCCB_PRINTF("OAM API initialize\n");

    try
    {
        osabInitApiClient(VCCB_EXT_OAM_API_MBOX, THS_DEFAULT_MAINTASKPRI);
    }
    catch (const std::exception &e)
    {
        VCCB_PRINTF("Exception(f:%s):(C:%s): ", __func__, e.what());
    }
    catch (...)
    {
        VCCB_PRINTF("Exception(f:%s):(C:Unknown): ", __func__);
    }

    VCCB_PRINTF("OAM API completed\n");

#endif
}

static TaskInit_Type taskInit[VCCB_TASK_END + 1];

#ifndef __CNF__
void FnVCCB_ApplyTaskCpuAffinity(const uint8_t firstIndex, const uint8_t lastIndex)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(firstIndex, CORE_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(lastIndex, CORE_NUM_VCCB);
    if (firstIndex > lastIndex)
    {
        VCCB_PRINTF("[CRITICAL] firstIndex(%u) cannot be greater than lastIndex(%u)\n", firstIndex, lastIndex);
        return;
    }

    int ret = 0;
    thsCpuAffinity_Type cpuAffinity = THS_COREAFFINITY_TYPE_INITIALIZER;
    VCCB_PRINTF("[INFO] Use Cpu affinity policy : (%u ~ %u)\n", firstIndex, lastIndex);

    for (unsigned int i = firstIndex; i <= lastIndex; i++)
    {
        if ((ret = thsSetCpuAffinity(&cpuAffinity, THS_COREAFFNINITY_SET_CMD, i)) < 0)
        {
            VCCB_PRINTF("[CRITICAL] [%d]thsSetCpuAffinity is failed\n", ret);
            return;
        }
    }

    TaskInit_Type *pTask = taskInit;
    while (pTask->pName != NULL)
    {
        for (int retry_count = 0; retry_count < NRCALL_MAX_MW_RETRY; retry_count++)
        {
            if (pTask->Id == 0)
            {
                VCCB_PRINTF(
                    "[CRITICAL] wait for task(%s) create for Core Affinity(retry:%d)\n", pTask->pName, retry_count);
                thsSleep(NRCALL_MW_RETRY_TIME);
                continue;
            }

            if ((ret = thsApplyTaskCpuAffinity(pTask->Id, &cpuAffinity)) < 0)
            {
                VCCB_PRINTF("[CRITICAL] [%d] task(%s) thsApplyTaskCpuAffinity is failed\n", ret, pTask->pName);
                thsSleep(NRCALL_MW_RETRY_TIME);
                continue;
            }
            else
            {
                break;
            }
        }
        pTask++;
    }
}

void FnVCCB_SetCallThreadAffinity(const uint8_t firstIndex, const uint8_t lastIndex)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(firstIndex, CORE_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(lastIndex, CORE_NUM_VCCB);
    if (firstIndex > lastIndex)
    {
        VCCB_PRINTF("[CRITICAL] firstIndex(%u) cannot be greater than lastIndex(%u)\n", firstIndex, lastIndex);
        return;
    }

    int ret = 0;
    TaskInit_Type *pTask = &taskInit[VCCB_CALL0_TASK];
    VCCB_PRINTF("[INFO] Use Cpu affinity policy : (%u ~ %u)\n", firstIndex, lastIndex);

    for (unsigned int index = firstIndex; index <= lastIndex; index++)
    {
        thsCpuAffinity_Type cpuAffinity = THS_COREAFFINITY_TYPE_INITIALIZER;
        if ((ret = thsSetCpuAffinity(&cpuAffinity, THS_COREAFFNINITY_SET_CMD, index)) < 0)
        {
            VCCB_PRINTF("[CRITICAL] [%d]thsSetCpuAffinity is failed\n", ret);
            return;
        }

        for (int retry_count = 0; retry_count < 3/*temp*/; retry_count++)
        {
            if (pTask->Id == 0)
            {
                VCCB_PRINTF(
                    "[CRITICAL] wait for task(%s) create for Core Affinity(retry:%d)\n", pTask->pName, retry_count);
                thsSleep(NRCALL_MW_RETRY_TIME);
                continue;
            }

            if ((ret = thsApplyTaskCpuAffinity(pTask->Id, &cpuAffinity)) < 0)
            {
                VCCB_PRINTF("[CRITICAL] [%d] task(%s) thsApplyTaskCpuAffinity is failed\n", ret, pTask->pName);
                thsSleep(NRCALL_MW_RETRY_TIME);
                continue;
            }
            else
            {
                break;
            }
        }
        pTask++;
    }
}

void FnVCCB_SetCallThreadAffinityRange(const uint8_t firstIndex, const uint8_t lastIndex)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(firstIndex, CORE_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(lastIndex, CORE_NUM_VCCB);
    if (firstIndex > lastIndex)
    {
        VCCB_PRINTF("[CRITICAL] firstIndex(%u) cannot be greater than lastIndex(%u)\n", firstIndex, lastIndex);
        return;
    }

    int ret = 0;
    thsCpuAffinity_Type cpuAffinity = THS_COREAFFINITY_TYPE_INITIALIZER;
    VCCB_PRINTF("[INFO] Use Cpu affinity policy : (%u ~ %u)\n", firstIndex, lastIndex);

    for (unsigned int i = firstIndex; i <= lastIndex; i++)
    {
        if ((ret = thsSetCpuAffinity(&cpuAffinity, THS_COREAFFNINITY_SET_CMD, i)) < 0)
        {
            VCCB_PRINTF("[CRITICAL] [%d]thsSetCpuAffinity is failed\n", ret);
            return;
        }
    }

    TaskInit_Type *pTask = &taskInit[VCCB_CALL0_TASK];

    while (pTask->pName != NULL)
    {
        for (int retry_count = 0; retry_count < NRCALL_MAX_MW_RETRY; retry_count++)
        {
            if (pTask->Id == 0)
            {
                VCCB_PRINTF(
                    "[CRITICAL] wait for task(%s) create for Core Affinity(retry:%d)\n", pTask->pName, retry_count);
                thsSleep(NRCALL_MW_RETRY_TIME);
                continue;
            }

            if ((ret = thsApplyTaskCpuAffinity(pTask->Id, &cpuAffinity)) < 0)
            {
                VCCB_PRINTF("[CRITICAL] [%d] task(%s) thsApplyTaskCpuAffinity is failed\n", ret, pTask->pName);
                thsSleep(NRCALL_MW_RETRY_TIME);
                continue;
            }
            else
            {
                break;
            }
        }
        pTask++;
    }
}
#endif

int FnVCCB_CreateTask(void)
{
    AUTO_TRACE_FUNC;

    int returnCode = 0;
    int index = 0;

#ifdef __NVGNB__
    uint8_t baseCpuId = (uint8_t)(CORE_NUM_VCCB - MAX_CALL_THREAD_NUM_VCCB);
    ths_coremask_t mask = 0;

    for (index = baseCpuId; index < CORE_NUM_VCCB; index++)
    {
        mask |= (ths_coremask_t)(0x1UL << index);
    }

    /* Apply Core Affinity to Tasks already running (MW Tasks) */
    returnCode = thsSetProcessCore(mask);
    if (returnCode < 0)
    {
        VCCB_PRINTF("[ERROR] thsSetProcessCore fail. ret = %d, mask = 0x%x\n", returnCode, mask);
    }
    else
    {
        VCCB_PRINTF("[SUCCESS] thsSetProcessCore suc. ret = %d, mask = 0x%x\n", returnCode, mask);
    }
#endif

    index = 0;
    taskInit[index++] = VccbTaskInitParam[VCCB_MAIN_TASK];
    taskInit[index++] = VccbTaskInitParam[VCCB_NONUE_TASK];
    taskInit[index++] = VccbTaskInitParam[VCCB_NONUE_ASN1_TASK];
    taskInit[index++] = VccbTaskInitParam[VCCB_OAM_TASK];
    taskInit[index++] = VccbTaskInitParam[VCCB_PLD_TASK];
    taskInit[index++] = VccbTaskInitParam[VCCB_AUDIT_TASK];
    taskInit[index++] = VccbTaskInitParam[VCCB_DAL_TASK];
    taskInit[index++] = VccbTaskInitParam[VCCB_LOG_TASK];
    taskInit[index++] = VccbTaskInitParam[VCCB_STATISTICS_TASK];
#ifndef __NVGNB__
    taskInit[index++] = VccbTaskInitParam[VCCB_RACS_TASK];
#endif
#ifdef __CNF__
    if (ENV->isSupportHA == CNF_HA_SUPPORT)
    {
        taskInit[index++] = VccbTaskInitParam[VCCB_REDIS_BACKUP_TASK];
        taskInit[index++] = VccbTaskInitParam[VCCB_REDIS_RESTORE_TASK];
    }
#endif

    int coreIdx = 0;
    for (; coreIdx < MAX_CALL_THREAD_NUM_VCCB; coreIdx++)
    {
        taskInit[index++] = VccbTaskInitParam[VCCB_CALL0_TASK + coreIdx];
    }
    taskInit[index++] = taskEnd;
    VCCB_PRINTF(" create call task : %d \n", coreIdx);

    returnCode = TaskInitFunc(taskInit);
    if (returnCode < 0)
    {
        VCCB_PRINTF("TaskInitFunc() Failed(ret = %d)\n", returnCode);
        VCCB_ONE_LOG_PRINT(LC_RESET, lc_taskInit, "TaskInitFunc() Failed(ret = %d)\n", returnCode);
        return returnCode;
    }
    return GOOD;
}

void FnVCCB_SendStartAckNoti(void)
{
    AUTO_TRACE_FUNC;

    int ret = 0;
    msg_type msg;
    memset(&msg, 0x00, sizeof(msg));
    msgMGMTInformStartAckNotiSwm_type *pMsgData = (msgMGMTInformStartAckNotiSwm_type *)&msg.data;

    /* make StartAckNoti message */
    snprintf(pMsgData->sSwUnitName, sizeof(pMsgData->sSwUnitName), "vccb.%s",
        smiGetMachineExtension());  // rhel:xcc, centos:xce //

    msg.msgHdr.msgType = msgMGMTInformStartAckNotiSwm_id;
    msg.dataLen = sizeof(pMsgData);

    logShmNonUeIntMsg(TX_MSG, BLK_SWM, msgMGMTInformStartAckNotiSwm_id, msg.dataLen, (uint8_t *)&msg, 0);

    /* send StartAckNoti message */
    ret = VLIB_SendMsg(ENV->handle.vccbMgmt, &SWM_ADDR, (char *)&msg, sizeof(msg), FALSE);
    VCCB_RETURN_ON_VOID(ret, "mdsSend ERROR!!\n");

    return;
}

void FnVCCB_initAlarmApi(void)
{
    AUTO_TRACE_FUNC;

    try
    {
#if !defined(NEW_HOST_SIM) || (defined(__CNF__) && !defined(IPC_TEST))
        fmInitApiClient(e_vccb, 0);
        VCCB_PRINTF("fmInitApiClient Done\n");

        fmRegisterAuditAlarmRequestCallback(FnVCCB_AuditCallAlarmSeverity);
        VCCB_PRINTF("fmRegisterAuditAlarmRequestCallback Done\n");
#endif
        FnVCCB_FmSendAllAlarmClearedNotification();

#ifndef IPC_TEST
        VCCB_PRINTF("FnVCCB_FmSendAllAlarmClearedNotification Done\n");
#endif
    }
    catch (const std::exception &e)
    {
        VCCB_PRINTF("Exception(f:%s):(C:%s): ", __func__, e.what());
        VCCB_EXIT(EXIT_MW_INIT);
    }
    catch (...)
    {
        VCCB_PRINTF("Exception(f:%s):(C:Unknown): ", __func__);
        VCCB_EXIT(EXIT_MW_INIT);
    }

    return;
}

void FnVCCB_InitMsgBuffer(uint8_t threadId)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);

    // VCCB_PRINTF("Initialize Message Buffer to 0x%x \n", DBG->value.bufferInitByte);

    memset(&(THREAD_INFO->call[threadId].buf.tx), DBG->value.bufferInitByte, sizeof(VccbMsgBuf_type));

    return;
}

void FnVCCB_InitCfgAcpfInfo()
{
    AUTO_TRACE_FUNC;

    VccbAcpfInfo_type *pAcpfInfo = &CFG->acpfInfo;
    pAcpfInfo->alarmCount = 0;
    pAcpfInfo->isNanoSupport = FALSE;
    // callSuccessRatioLowAlarm
    VccbCallSuccessRatioLowAlarm_type *pCallSuccessRatioLowAlarm = &pAcpfInfo->callSuccessRatioLowAlarm;
    pCallSuccessRatioLowAlarm->monitoringPeriod = 1;
    pCallSuccessRatioLowAlarm->callAttemptThreshold = 0;
    pCallSuccessRatioLowAlarm->minorThreshold = 0;
    pCallSuccessRatioLowAlarm->majorThreshold = 0;
    pCallSuccessRatioLowAlarm->criticalThreshold = 0;
    pCallSuccessRatioLowAlarm->observedThreshold = 0;
    pCallSuccessRatioLowAlarm->recoveryUsage = 0;
    pCallSuccessRatioLowAlarm->alarmSeverity = cleared;
    memset(&pCallSuccessRatioLowAlarm->alarmBody, 0x00, sizeof(pCallSuccessRatioLowAlarm->alarmBody));
    pCallSuccessRatioLowAlarm->criticalCount = 0;
    pCallSuccessRatioLowAlarm->lastCheckTime.tv_sec = 0;
    for (int i = 0; i < VCCB_CALL_THREAD_NUM; i++)
    {
        pCallSuccessRatioLowAlarm->prevCallAttemptCount[i] = 0;
        pCallSuccessRatioLowAlarm->prevCallSuccessCount[i] = 0;
    }
    pCallSuccessRatioLowAlarm->initialGuardTime = 15; // 15 mins

    // resourceThresholdExceededAlarm
    VccbResourceThresholdExceededAlarm_type *pResourceThresholdExceededAlarm =
        &pAcpfInfo->resourceThresholdExceededAlarm;
    pResourceThresholdExceededAlarm->featureEnabled = 0;
    pResourceThresholdExceededAlarm->monitoringPeriod = 0;
    pResourceThresholdExceededAlarm->lastCheckTime.tv_sec = 0;

#ifdef __CNF__
    // redisAccessAlarm
    VccbRedisAccessAlarm_type *pRedisAccessAlarm = &pAcpfInfo->redisAccessAlarm;
    memset(&pRedisAccessAlarm->alarmBody, 0x00, sizeof(pRedisAccessAlarm->alarmBody));
    pRedisAccessAlarm->alarmSeverity = cleared;
#endif

    // callContext
    pResourceThresholdExceededAlarm->callContext.attribute.alarmEnabled = 0;
    pResourceThresholdExceededAlarm->callContext.attribute.minorThreshold = 0;
    pResourceThresholdExceededAlarm->callContext.attribute.majorThreshold = 0;
    pResourceThresholdExceededAlarm->callContext.attribute.criticalThreshold = 0;
    pResourceThresholdExceededAlarm->callContext.observedThreshold = 0;
    pResourceThresholdExceededAlarm->callContext.alarmSeverity = cleared;
    memset(&pResourceThresholdExceededAlarm->callContext.alarmBody, 0x00,
        sizeof(pResourceThresholdExceededAlarm->callContext.alarmBody));

    // messageQueue
    pResourceThresholdExceededAlarm->messageQueue.attribute.alarmEnabled = 0;
    pResourceThresholdExceededAlarm->messageQueue.attribute.minorThreshold = 0;
    pResourceThresholdExceededAlarm->messageQueue.attribute.majorThreshold = 0;
    pResourceThresholdExceededAlarm->messageQueue.attribute.criticalThreshold = 0;
    for (int i = 0; i < VCCB_CALL_THREAD_NUM; i++)
    {
        pResourceThresholdExceededAlarm->messageQueue.observedThreshold[i] = 0;
        pResourceThresholdExceededAlarm->messageQueue.alarmSeverity[i] = cleared;
        memset(&pResourceThresholdExceededAlarm->messageQueue.alarmBody[i], 0x00,
            sizeof(pResourceThresholdExceededAlarm->messageQueue.alarmBody[i]));
    }

    // irntiUeIdMap
    pResourceThresholdExceededAlarm->irntiUeIdMap.attribute.alarmEnabled = 0;
    pResourceThresholdExceededAlarm->irntiUeIdMap.attribute.minorThreshold = 0;
    pResourceThresholdExceededAlarm->irntiUeIdMap.attribute.majorThreshold = 0;
    pResourceThresholdExceededAlarm->irntiUeIdMap.attribute.criticalThreshold = 0;
    for (int i = 0; i < MAX_GNB_CU_CP_FUNCTION_PER_SYS; i++)
    {
        pResourceThresholdExceededAlarm->irntiUeIdMap.observedThreshold[i] = 0;
        pResourceThresholdExceededAlarm->irntiUeIdMap.alarmSeverity[i] = cleared;
        memset(&pResourceThresholdExceededAlarm->irntiUeIdMap.alarmBody[i], 0x00,
            sizeof(pResourceThresholdExceededAlarm->irntiUeIdMap.alarmBody[i]));
    }

#ifdef __CNF__
    // messageQueue
    pResourceThresholdExceededAlarm->contextBackupBuffer.attribute.alarmEnabled = 0;
    pResourceThresholdExceededAlarm->contextBackupBuffer.attribute.minorThreshold = 0;
    pResourceThresholdExceededAlarm->contextBackupBuffer.attribute.majorThreshold = 0;
    pResourceThresholdExceededAlarm->contextBackupBuffer.attribute.criticalThreshold = 0;
    for (int i = 0; i < VCCB_CALL_THREAD_NUM; i++)
    {
        pResourceThresholdExceededAlarm->contextBackupBuffer.observedThreshold[i] = 0;
        pResourceThresholdExceededAlarm->contextBackupBuffer.alarmSeverity[i] = cleared;
        memset(&pResourceThresholdExceededAlarm->contextBackupBuffer.alarmBody[i], 0x00,
            sizeof(pResourceThresholdExceededAlarm->contextBackupBuffer.alarmBody[i]));
    }
#endif

    // SVR25B ARC-FG5403 CNF CU Inservice Upgrade
    VCCB_CLEAR_TIMER(&pAcpfInfo->cnfUpgrade.upgradeExistingCallRelWaitTimer, INIT_TIMER);
    VCCB_CLEAR_TIMER(&pAcpfInfo->cnfUpgrade.upgradeEmergencyCallRelWaitTimer, INIT_TIMER);
    VCCB_CLEAR_TIMER(&pAcpfInfo->cnfUpgrade.upgradeEmergencyCallCheckTimer, INIT_TIMER);
    VCCB_CLEAR_TIMER(&pAcpfInfo->cnfUpgrade.upgradeTerminatingCallRelWaitTimer, INIT_TIMER);

    pAcpfInfo->cnfUpgrade.upgradeEmergencyCallRelWaitTimerValue = 4;    // YANG default 4 min
    pAcpfInfo->cnfUpgrade.upgradeAllCallRelWaitTimerValue = 10000;
    pAcpfInfo->cnfUpgrade.receiveSIG1count = 0;
    pAcpfInfo->cnfUpgrade.receiveSIG2count = 0;
    pAcpfInfo->cnfUpgrade.receivedSignalType = 0;
    pAcpfInfo->cnfUpgrade.terminationCallReleaseWaitSeconds = 300;

    // SVR26A FGR-SV0401 gNB Service Outage Handling
    VccbCallDropRatioHighAlarm_type *pCallDropRatioHighAlarm = &pAcpfInfo->callDropRatioHighAlarm;
    memset(pCallDropRatioHighAlarm, 0, sizeof(VccbCallDropRatioHighAlarm_type));
    pCallDropRatioHighAlarm->alarmEnabled = FALSE;
    pCallDropRatioHighAlarm->monitoringPeriod = 5;                // Minutes
    pCallDropRatioHighAlarm->instantMonitoringPeriod = 2;         // Seconds
    pCallDropRatioHighAlarm->abnormalReleaseRatioThreshold = 20;  // 20 %
    pCallDropRatioHighAlarm->releasedCallThreshold = 100;         // 100 call
    pCallDropRatioHighAlarm->alarmSeverity = cleared;

    // SVR26A FGR-CC3103 IODT RACS(UE Radio Capability Signaling Optimization)
    pAcpfInfo->racsFunctionOnOff = VCCB_FLAG_OFF;

    // SVR26B OAMP-HA0201 vRAN VNF/CNF and Geo Redundancy
    pAcpfInfo->grStatus = grStatus_Active;   // 1

    return;
}

void FnVCCB_InitMsgQueueCntInfo(void)
{
    AUTO_TRACE_FUNC;

    CFG->msgQueue.maxMsgCntPerThread = DEFAULT_MSG_QUEUEING_COUNT_PER_THREAD;
    CFG->msgQueue.maxMsgCntPerCall = DEFAULT_MSG_QUEUEING_COUNT_PER_UE;

    return;
}
