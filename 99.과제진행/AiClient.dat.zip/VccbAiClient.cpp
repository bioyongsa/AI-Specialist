// ============================================================
// VccbAiClient.cpp
// ============================================================
#include "ComInclude.h"
#include "ComLibUtility.h"

#include "VccbStruct.h"

#include "FeatCallInfo.h"

#include "VccbAiClient.h"
#include "VccbAiEngine.h"

#include <string.h>     // memset
#include <math.h>       // ceilf
#include <time.h>       // time, localtime
#include <atomic>       // std::atomic (C++11)
#include <stdint.h>

// ---- 글로벌 상태 (멀티스레드 안전: std::atomic) ----
static std::atomic<int32_t> g_consecutiveFailCount(0);
static std::atomic<bool>    g_fallbackMode(false);

// ---- 전역 추론 통계 ----
static std::atomic<int64_t> g_totalRequests(0);
static std::atomic<int64_t> g_successCount(0);
static std::atomic<int64_t> g_failureCount(0);
static std::atomic<int64_t> g_timeoutCount(0);
static std::atomic<int64_t> g_fallbackCount(0);
static std::atomic<int64_t> g_triggerPt1(0);
static std::atomic<int64_t> g_triggerPt2(0);
static std::atomic<int64_t> g_triggerPt3(0);
static std::atomic<int64_t> g_triggerPt4(0);
static std::atomic<int64_t> g_triggerPt5(0);
static std::atomic<int64_t> g_totalInferUs(0);

// ============================================================
// Helpers
// ============================================================

// callInfo_type -> VccbAiInput 변환
static bool buildAiInput(const callInfo_type *ci, VccbAiInput *input)
{
    if (ci == NULL || input == NULL) return false;

    memset(input, 0, sizeof(*input));

    // ---- sequence feature (UE history circular buffer -> chronological order) ----
    const VccbAiCallContext_type *ctx = &ci->aiCtx;
    int32_t count = (ctx->count < VCCB_AI_HISTORY_LEN) ? ctx->count : VCCB_AI_HISTORY_LEN;

    // before wrap-around: start from 0; after wrap-around: writeIdx points to the oldest entry
    int32_t startIdx = (ctx->count < VCCB_AI_HISTORY_LEN) ? 0 : ctx->writeIdx;

    for (int32_t i = 0; i < count; i++)
    {
        int32_t idx = (startIdx + i) % VCCB_AI_HISTORY_LEN;

        input->seq[i][0] = ctx->history[idx].durationSec;
        input->seq[i][1] = (float)ctx->history[idx].resumeCause;
    }
    // remaining slots are zero-padded (already 0 from memset)

    // ---- static feature (15 items) ----
    // stat[0]: primary_5qi — 첫 번째 활성 DRB의 Non-Dynamic 5QI
    {
        uint8_t primary5qi = 0;
        for (int i = 0; i < MAX_DRB_PER_SA_CALL; i++)
        {
            const callDRBInfo_type &d = ci->drb[i];
            if (d.usage != CI_use) continue;

            uint16_t qIdx = d.drbQosIdxInCall;
            if (qIdx < MAX_QOS_FLOW_PER_CALL && ci->qosFlow[qIdx].usage == CI_use)
            {
                const qosFlowInfo_type &q = ci->qosFlow[qIdx];
                if (q.qosParam.qosCharacteristics == ci_qos_char_non_dynamic_5qi)
                {
                    primary5qi = q.qosParam.nonDyna.fiveQi;
                }
            }
            break;
        }
        input->stat[0] = (float)primary5qi;
    }

    // stat[1]: drb_count — 활성 DRB 수
    {
        int32_t drbCount = 0;
        for (int i = 0; i < MAX_DRB_PER_SA_CALL; i++)
        {
            if (ci->drb[i].usage == CI_use) drbCount++;
        }
        input->stat[1] = (float)drbCount;
    }

    // stat[2]: ue_ambr_dl_mbps — UE DL AMBR (bps → Mbps)
    input->stat[2] = (float)((double)ci->ueInfo.ambr.aggrMbrDl / 1000000.0);

    // stat[3]: has_gbr_flow — GBR Flow 존재 여부 (0/1)
    {
        float hasGbr = 0.0f;
        for (int i = 0; i < MAX_QOS_FLOW_PER_CALL; i++)
        {
            if (ci->qosFlow[i].usage == CI_use &&
                ci->qosFlow[i].qosParam.gbrQosInformationPresent != 0)
            {
                hasGbr = 1.0f;
                break;
            }
        }
        input->stat[3] = hasGbr;
    }

    // stat[4]: cn_expected_idle_period — AMF 제공 예상 유휴 시간
    // 5G NR NGAP CoreNetworkAssistanceInformation에 해당 필드가 없어 현재 0.0 유지.
    // 향후 NGAP 규격에 추가될 경우 VccbStruct.h의 ueInfo.RrcInactiveInfo 계열에서 경로 확인 필요.
    input->stat[4] = 0.0f;

    // stat[5]: cn_stationary — AMF 제공 UE 정지 여부 (0/1)
    // stat[4] 와 동일 이유로 현재 0.0 유지.
    input->stat[5] = 0.0f;

    // stat[6]: last_rsrp — Serving Cell SSB RSRP (0..127, 255=invalid)
    {
        float rsrp = (float)ci->servCellSsbRsrp;
        if (ci->servCellSsbRsrp == 255) rsrp = 0.0f;
        input->stat[6] = rsrp;
    }

    // stat[7]: neighbor_cell_count — 이웃 셀 수
    // MeasurementReport 저장 구조체(VccbStruct.h measResultNeighCell 계열) 필드 경로 미확인.
    // ptCi에 직접 저장되는 인접 셀 카운트 필드를 VccbStruct.h에서 확인 후 교체 필요.
    input->stat[7] = 0.0f;

    // stat[8]: rna_cell_count — RNA 내 TAI 수 (numInactTAI 로 근사)
    input->stat[8] = (float)ci->ueInfo.RrcInactiveInfo.numInactTAI;

    // stat[9]: avg_cell_stay_sec — 평균 셀 체류 시간 (avgDurationSec 재사용)
    input->stat[9] = ctx->avgDurationSec;

    // stat[10]: resume_count_24h — 24h 슬라이딩 윈도우 Resume 횟수
    input->stat[10] = (float)ctx->resumeCount24h;

    // stat[11]: resume_success_rate
    input->stat[11] = ctx->resumeSuccessRate;

    // stat[12]: avg_inactive_duration
    input->stat[12] = ctx->avgDurationSec;

    // stat[13]: hour_of_day (0-23), stat[14]: day_of_week (0=Sun ~ 6=Sat)
    time_t t = time(NULL);
    struct tm *tmv = localtime(&t);
    if (tmv != NULL)
    {
        input->stat[13] = (float)tmv->tm_hour;
        input->stat[14] = (float)tmv->tm_wday;
    }

    return true;
}

static bool shouldSkipAi(const callInfo_type *ci)
{
    if (ci == NULL)          return true;
    if (g_fallbackMode)      return true;
    if (IS_REDCAP_UE(ci))   return true;   // RedCap UE: 초기 구현에서 AI 미적용
    if (IS_NRDC_MN(ci))     return true;   // NRDC MN: AI 개입 대상 아님
    if (IS_NRDC_SN(ci))     return true;   // NRDC SN: AI 개입 대상 아님
    return false;
}

static void noteInferFailure(void)
{
    int32_t cnt = g_consecutiveFailCount.fetch_add(1) + 1;
    g_failureCount.fetch_add(1);
    g_fallbackCount.fetch_add(1);

    if (cnt >= VCCB_AI_FALLBACK_COUNT)
    {
        g_fallbackMode.store(true);
    }
}

static void noteInferSuccess(void)
{
    g_consecutiveFailCount.store(0);
    g_successCount.fetch_add(1);
}

// 추론 실행 + 1ms 타임아웃 체크. 초과 시 false 반환 (Fallback 처리).
// elapsed_us_out: 측정된 실제 추론 소요 시간 (us)
static bool runInferWithTimeout(const VccbAiInput &input, VccbAiOutput &output, int64_t *elapsed_us_out)
{
    struct timespec t_start = {}, t_end = {};
    clock_gettime(CLOCK_MONOTONIC, &t_start);

    bool ok = VccbAiEngine_Infer(input, output);

    clock_gettime(CLOCK_MONOTONIC, &t_end);

    int64_t elapsed_us = (t_end.tv_sec  - t_start.tv_sec)  * 1000000LL
                       + (t_end.tv_nsec - t_start.tv_nsec) / 1000LL;

    if (elapsed_us_out != NULL)
    {
        *elapsed_us_out = elapsed_us;
    }

    if (!ok)
    {
        return false;
    }

    if (elapsed_us > VCCB_AI_INFER_TIMEOUT_US)
    {
        g_timeoutCount.fetch_add(1);
        g_fallbackCount.fetch_add(1);
        return false;
    }

    // 성공 시 통계 누적
    g_totalInferUs.fetch_add(elapsed_us);
    return true;
}

static int32_t clampTimer(int32_t t)
{
    if (t < VCCB_AI_TIMER_MIN_SEC) return VCCB_AI_TIMER_MIN_SEC;
    if (t > VCCB_AI_TIMER_MAX_SEC) return VCCB_AI_TIMER_MAX_SEC;
    return t;
}

// 24h 슬라이딩 윈도우에서 현재 유효한 Resume 횟수를 계산
static int32_t calcResumeCount24h(const VccbAiCallContext_type *ctx)
{
    int64_t now = (int64_t)time(NULL);
    int64_t windowStart = now - VCCB_AI_24H_WINDOW_SEC;
    int32_t count = 0;

    for (int i = 0; i < VCCB_AI_HISTORY_LEN; i++)
    {
        if (ctx->resumeTs[i] > windowStart)
        {
            count++;
        }
    }
    return count;
}

// ============================================================
// Public API
// ============================================================

int32_t VccbAiClient_RecommendInactivityTimer(callInfo_type *ci,
                                              int32_t defaultTimerSec)
{
    g_totalRequests.fetch_add(1);
    g_triggerPt1.fetch_add(1);

    if (shouldSkipAi(ci))
    {
        g_fallbackCount.fetch_add(1);
        return clampTimer(defaultTimerSec);
    }

    VccbAiInput  input;
    VccbAiOutput output;
    int64_t elapsed_us = 0;

    if (!buildAiInput(ci, &input))
    {
        noteInferFailure();
        return clampTimer(defaultTimerSec);
    }
    if (!runInferWithTimeout(input, output, &elapsed_us))
    {
        noteInferFailure();
        return clampTimer(defaultTimerSec);
    }
    noteInferSuccess();

    // record INACTIVE entry timestamp (used at point③ to calculate duration)
    ci->aiCtx.inactiveEntryTs = (int64_t)time(NULL);

    int32_t result;
    if (output.resume_prob >= VCCB_AI_KEEP_THRESHOLD)
    {
        // KEEP: expected resume time * margin factor
        float t = output.resume_time * VCCB_AI_MARGIN_FACTOR;
        result = (int32_t)ceilf(t);

        ci->aiCtx.extendCount++;    // track extension count for forced INACTIVE transition
    }
    else if (output.resume_prob <= VCCB_AI_RELEASE_THRESHOLD)
    {
        // EARLY_RELEASE
        result = VCCB_AI_TIMER_MIN_SEC;
    }
    else
    {
        // DEFAULT: mid-range probability -> keep static timer
        result = defaultTimerSec;
    }

    result = clampTimer(result);
    ci->aiCtx.lastInferTimerSec = (float)result;

    VCCB_PRINT_CALL_INFORMATIVE(ci,
        "[AI①] resume_prob=%.3f resume_time=%.1fs → timer=%ds (latency=%lldus)\n",
        (double)output.resume_prob, (double)output.resume_time, result, (long long)elapsed_us);

    return result;
}

bool VccbAiClient_IsAbleToProceedInactive(callInfo_type *ci)
{
    g_totalRequests.fetch_add(1);
    g_triggerPt2.fetch_add(1);

    if (ci == NULL) return true;

    // extendCount 상한 초과 → AI 판단 없이 즉시 INACTIVE 천이 강제, 카운터 리셋
    if (ci->aiCtx.extendCount >= VCCB_AI_MAX_EXTEND_COUNT)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ci,
            "[AI②] extendCount(%d) >= MAX(%d). Forced INACTIVE transition.\n",
            ci->aiCtx.extendCount, VCCB_AI_MAX_EXTEND_COUNT);
        ci->aiCtx.extendCount = 0;
        return true;
    }

    if (shouldSkipAi(ci))
    {
        g_fallbackCount.fetch_add(1);
        return true;
    }

    VccbAiInput  input;
    VccbAiOutput output;
    int64_t elapsed_us = 0;

    if (!buildAiInput(ci, &input) || !runInferWithTimeout(input, output, &elapsed_us))
    {
        noteInferFailure();
        return true;    // Fallback: 기존 INACTIVE 천이 진행
    }
    noteInferSuccess();

    if (output.resume_prob >= VCCB_AI_KEEP_THRESHOLD)
    {
        // 타이머 연장: 추론 결과를 aiCtx에 저장하고 호출자가 BearerContextModify를 수행하도록 false 반환
        float t = output.resume_time * VCCB_AI_MARGIN_FACTOR;
        int32_t timerSec = (int32_t)ceilf(t);
        if (timerSec < VCCB_AI_TIMER_MIN_SEC) timerSec = VCCB_AI_TIMER_MIN_SEC;
        if (timerSec > VCCB_AI_TIMER_MAX_SEC) timerSec = VCCB_AI_TIMER_MAX_SEC;

        ci->aiCtx.lastInferTimerSec = (float)timerSec;
        ci->aiCtx.inactiveEntryTs   = (int64_t)time(NULL);
        ci->aiCtx.extendCount++;

        VCCB_PRINT_CALL_INFORMATIVE(ci,
            "[AI②] resume_prob=%.3f >= %.1f → Defer INACTIVE. extendCount=%d timer=%ds (latency=%lldus)\n",
            (double)output.resume_prob, (double)VCCB_AI_KEEP_THRESHOLD,
            ci->aiCtx.extendCount, timerSec, (long long)elapsed_us);

        return false;   // INACTIVE 천이 보류: 호출자가 BearerContextModification 전송
    }

    VCCB_PRINT_CALL_INFORMATIVE(ci,
        "[AI②] resume_prob=%.3f < %.1f → Proceed INACTIVE. (latency=%lldus)\n",
        (double)output.resume_prob, (double)VCCB_AI_KEEP_THRESHOLD, (long long)elapsed_us);

    return true;    // resume_prob 낮음 → 즉시 INACTIVE 천이 진행
}

void VccbAiClient_OnResumeRequest(callInfo_type *ci, int32_t resumeCause)
{
    g_triggerPt3.fetch_add(1);

    if (ci == NULL) return;
    VccbAiCallContext_type *ctx = &ci->aiCtx;

    // ---- calculate INACTIVE duration ----
    float durationSec = 0.0f;
    if (ctx->inactiveEntryTs != 0)
    {
        int64_t now  = (int64_t)time(NULL);
        int64_t diff = now - ctx->inactiveEntryTs;
        if (diff < 0) diff = 0;
        durationSec = (float)diff;
    }

    // ---- push to history circular buffer ----
    ctx->history[ctx->writeIdx].durationSec = durationSec;
    ctx->history[ctx->writeIdx].resumeCause = resumeCause;
    ctx->writeIdx = (ctx->writeIdx + 1) % VCCB_AI_HISTORY_LEN;
    if (ctx->count < VCCB_AI_HISTORY_LEN)
    {
        ctx->count++;
    }

    // ---- 24h 슬라이딩 윈도우 타임스탬프 기록 ----
    int64_t now = (int64_t)time(NULL);
    ctx->resumeTs[ctx->resumeTsWriteIdx] = now;
    ctx->resumeTsWriteIdx = (ctx->resumeTsWriteIdx + 1) % VCCB_AI_HISTORY_LEN;
    ctx->resumeCount24h = calcResumeCount24h(ctx);

    // ---- update statistics ----
    // avgDurationSec: exponential moving average (EMA, alpha=0.1)
    if (ctx->count == 1)
    {
        ctx->avgDurationSec = durationSec;          // first entry: use as initial value
    }
    else
    {
        ctx->avgDurationSec = 0.9f * ctx->avgDurationSec + 0.1f * durationSec;
    }

    // resumeSuccessRate: EMA (alpha=0.1)
    // 판단 기준: NRRRC_emergency(긴급 통화로 인한 Resume)은 "예측 실패"로 간주.
    //            그 외(mo_Data, mt_Access, rna_Update 등)는 "예측 가능한 Resume"으로 성공 처리.
    {
        const float alpha = 0.1f;
        float isSuccess = ((int32_t)NRRRC_ResumeCause_emergency == resumeCause) ? 0.0f : 1.0f;
        ctx->resumeSuccessRate = alpha * isSuccess + (1.0f - alpha) * ctx->resumeSuccessRate;
    }

    // prepare for next INACTIVE cycle
    ctx->inactiveEntryTs = 0;
    ctx->extendCount     = 0;
}

void VccbAiClient_OnRnaUpdate(callInfo_type *ci)
{
    g_triggerPt4.fetch_add(1);

    if (ci == NULL) return;
    if (shouldSkipAi(ci))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ci, "[AI④] RNA Update: AI skipped (Fallback/REDCAP/NRDC).\n");
        return;
    }

    VccbAiInput  input;
    VccbAiOutput output;
    int64_t elapsed_us = 0;

    g_totalRequests.fetch_add(1);

    if (!buildAiInput(ci, &input) || !runInferWithTimeout(input, output, &elapsed_us))
    {
        noteInferFailure();
        VCCB_PRINT_CALL_INFORMATIVE(ci, "[AI④] RNA Update: inference failed. Fallback.\n");
        return;
    }
    noteInferSuccess();

    // RNA 크기 권고: resume_prob 기반. 높을수록 RNA 유지 권고, 낮을수록 RNA 축소 권고.
    // RNA 크기 파라미터를 직접 변경하는 메커니즘이 현재 VCCB 코드에 없으므로 로그만 출력.
    const char *rnaSizeRecommendation;
    if (output.resume_prob >= VCCB_AI_KEEP_THRESHOLD)
    {
        rnaSizeRecommendation = "KEEP_OR_EXPAND";
    }
    else if (output.resume_prob <= VCCB_AI_RELEASE_THRESHOLD)
    {
        rnaSizeRecommendation = "SHRINK";
    }
    else
    {
        rnaSizeRecommendation = "NO_CHANGE";
    }

    VCCB_PRINT_CALL_INFORMATIVE(ci,
        "[AI④] RNA Update: resume_prob=%.3f resume_time=%.1fs → RNA_size_recommendation=%s (latency=%lldus)\n",
        (double)output.resume_prob, (double)output.resume_time, rnaSizeRecommendation, (long long)elapsed_us);
}

void VccbAiClient_SeedFromXnapHistory(callInfo_type *ci)
{
    g_triggerPt5.fetch_add(1);

    if (ci == NULL) return;
    VccbAiCallContext_type *ctx = &ci->aiCtx;

    // VXIL_Store_XN_UE_HistoryInformation() 이 FnVCCB_StoreXNMessage(XN_HandoverRequest_id) 내부에서 호출되어
    // visitedCell[]이 채워진 후 이 함수를 호출해야 한다.
    //
    // ueHistory.lastIdx: VHCM_updateUEHistory() 이 증가시키며 최신 셀의 인덱스.
    //   초기값 -1 이므로 유효 범위는 0 ~ MAX_VISITED_CELL-1.
    // visitedCell[idx].uRat.nrCell.stayTime: 해당 셀의 체류 시간 (초, 3GPP TS 38.413 기준 최대 4095s)
    //   stayTimeEnhancedPresent 가 OPT_PRESENT 이면 stayTimeEnhanced (100ms 단위) 사용.

    if (ci->ueHistory.lastIdx >= MAX_VISITED_CELL)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ci,
            "[AI⑤] XnAP HO seed: no valid visitedCell history (lastIdx=%d).\n",
            (int)ci->ueHistory.lastIdx);
        return;
    }

    uint8_t seedIdx = ci->ueHistory.lastIdx;
    const visitedCellInfo_type *pVisited = &ci->ueHistory.visitedCell[seedIdx];

    if (pVisited->usage != CI_use || pVisited->ratType != ci_nr)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ci,
            "[AI⑤] XnAP HO seed: visitedCell[%d] usage=%d ratType=%d — skip.\n",
            (int)seedIdx, (int)pVisited->usage, (int)pVisited->ratType);
        return;
    }

    // stayTimeEnhanced 가 있으면 더 정밀한 값 (단위: 100ms), 없으면 stayTime (초)
    float stayTimeSec;
    if (pVisited->uRat.nrCell.stayTimeEnhancedPresent == OPT_PRESENT)
    {
        stayTimeSec = (float)pVisited->uRat.nrCell.stayTimeEnhanced * 0.1f;  // 100ms → 초
    }
    else
    {
        stayTimeSec = (float)pVisited->uRat.nrCell.stayTime;
    }

    // AI history 버퍼에 seed 기록 (resumeCause = -1: HO source cell history 마커)
    ctx->history[ctx->writeIdx].durationSec = stayTimeSec;
    ctx->history[ctx->writeIdx].resumeCause = -1;
    ctx->writeIdx = (ctx->writeIdx + 1) % VCCB_AI_HISTORY_LEN;
    if (ctx->count < VCCB_AI_HISTORY_LEN)
    {
        ctx->count++;
    }

    // avgDurationSec 갱신 (EMA)
    if (ctx->count == 1)
    {
        ctx->avgDurationSec = stayTimeSec;
    }
    else
    {
        ctx->avgDurationSec = 0.9f * ctx->avgDurationSec + 0.1f * stayTimeSec;
    }

    VCCB_PRINT_CALL_INFORMATIVE(ci,
        "[AI⑤] XnAP HO seed: visitedCell[%d] stayTime=%.1fs → aiCtx.avgDurationSec=%.1fs (count=%d)\n",
        (int)seedIdx, (double)stayTimeSec, (double)ctx->avgDurationSec, ctx->count);
}

bool VccbAiClient_IsFallbackMode(void)
{
    return g_fallbackMode;
}

void VccbAiClient_Reset(void)
{
    g_consecutiveFailCount.store(0);
    g_fallbackMode.store(false);

    g_totalRequests.store(0);
    g_successCount.store(0);
    g_failureCount.store(0);
    g_timeoutCount.store(0);
    g_fallbackCount.store(0);
    g_triggerPt1.store(0);
    g_triggerPt2.store(0);
    g_triggerPt3.store(0);
    g_triggerPt4.store(0);
    g_triggerPt5.store(0);
    g_totalInferUs.store(0);
}

void VccbAiClient_GetStats(VccbAiGlobalStats_type *out)
{
    if (out == NULL) return;

    out->totalRequests       = g_totalRequests.load();
    out->successCount        = g_successCount.load();
    out->failureCount        = g_failureCount.load();
    out->timeoutCount        = g_timeoutCount.load();
    out->fallbackCount       = g_fallbackCount.load();
    out->triggerPt1Count     = g_triggerPt1.load();
    out->triggerPt2Count     = g_triggerPt2.load();
    out->triggerPt3Count     = g_triggerPt3.load();
    out->triggerPt4Count     = g_triggerPt4.load();
    out->triggerPt5Count     = g_triggerPt5.load();
    out->totalInferUs        = g_totalInferUs.load();
    out->consecutiveFailCount = g_consecutiveFailCount.load();
    out->isFallbackMode      = g_fallbackMode.load();
}

void VccbAiClient_PrintStats(void)
{
    VccbAiGlobalStats_type s;
    VccbAiClient_GetStats(&s);

    int64_t avgInferUs = (s.successCount > 0) ? (s.totalInferUs / s.successCount) : 0;

    VCCB_PRINTF("========== VCCB AI Client Statistics ==========\n");
    VCCB_PRINTF("  Mode            : %s\n", s.isFallbackMode ? "FALLBACK" : "ACTIVE");
    VCCB_PRINTF("  Engine          : Scenario B (C++ GRU direct)\n");
    VCCB_PRINTF("  ConsecFailCount : %d\n",   (int)s.consecutiveFailCount);
    VCCB_PRINTF("  TotalRequests   : %lld\n", (long long)s.totalRequests);
    VCCB_PRINTF("  Success         : %lld\n", (long long)s.successCount);
    VCCB_PRINTF("  Failure(infer)  : %lld\n", (long long)s.failureCount);
    VCCB_PRINTF("  Timeout(>1ms)   : %lld\n", (long long)s.timeoutCount);
    VCCB_PRINTF("  Fallback(total) : %lld\n", (long long)s.fallbackCount);
    VCCB_PRINTF("  Trigger Pt①    : %lld\n", (long long)s.triggerPt1Count);
    VCCB_PRINTF("  Trigger Pt②    : %lld\n", (long long)s.triggerPt2Count);
    VCCB_PRINTF("  Trigger Pt③    : %lld\n", (long long)s.triggerPt3Count);
    VCCB_PRINTF("  Trigger Pt④    : %lld\n", (long long)s.triggerPt4Count);
    VCCB_PRINTF("  Trigger Pt⑤    : %lld\n", (long long)s.triggerPt5Count);
    VCCB_PRINTF("  AvgInferLatency : %lldus\n", (long long)avgInferUs);
    VCCB_PRINTF("================================================\n");
}
