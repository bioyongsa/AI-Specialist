/**
 * @file    : CdbDalOperational.hpp
 * @brief   : Provide classes for operations in operational database
 *
 * Copyright 2021 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef VCCB_CDB_CdbDalOperational_HPP_
#define VCCB_CDB_CdbDalOperational_HPP_

namespace dal
{
/**
 * @brief Context for reading and writing to the operational database.
 * @details This class represents RAII for a session in the operational database:
 * - constructor starts the session
 * - destructor ends the session unless it didn't start.
 * Constructor try to reconnect to the dal/cdb in case of network failure.
 */
class OperationalDataSession
{
public:
    OperationalDataSession(int* sock);
    ~OperationalDataSession();

    // no copying
    OperationalDataSession(const OperationalDataSession&) = delete;
    OperationalDataSession& operator=(const OperationalDataSession&) = delete;

    bool isValid() const;

private:
    bool socketAcquired_{false};
    bool sessionStarted_{false};
    int* psock_{nullptr};
    // const char* const name_{"OperationalDataSession"};
};
}  // namespace dal

#endif  // VCCB_CDB_CdbDalOperational_HPP_