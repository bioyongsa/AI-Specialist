#ifndef VCCB_CDB_CdbRedis_H_
#define VCCB_CDB_CdbRedis_H_

#ifdef __CNF__
#include "VccbStruct.h"
#include "ComRedisLib.h"
#include <vector>

#define VCCB_BUILD_TIME               " " __DATE__ " " __TIME__ " "

// [Redis Command Syntax]
// REDIS_DEL [HashKey]
// REDIS_HSET [HashKey] [DataName] [Data]
// REDIS_HGET [HashKey] [DataName]
// REDIS_ZREM [ZKey] [HashKey]
// REDIS_ZADD [ZKey] [Zvalue] [HashKey]
// REDIS_EXPIRE [HashKey] [Expire Time]
// REDIS_HGETALL [HashKey]
// REDIS_ZRANGE [ZKey] [StartIndex] [EndIndex]
// REDIS_ZRANGEBYSCORE [ZKey] [StartZValue] [EndZValue]
// REDIS_EXISTS [HashKey]
// REDIS_PING

int FnVCCB_UpdateExtDb(VccbRedisConnection_type &connection);
int FnVCCB_AuditExtDb(VccbRedisConnection_type &connection);
int FnVCCB_RestoreDbFromRedis(VccbRedisConnection_type &connection);
int FnVCCB_RestoreCall(VccbRedisConnection_type &connection, std::vector<uint16_t> &distCodeList);
int FnVCCB_UpdateRedisCallDBExpire(callInfo_type *ptCi);
int FnVCCB_RedisSetLastUpdateTime(VccbRedisConnection_type &connection);
int FnVCCB_RedisDeleteAllDataOfMyCpp(VccbRedisConnection_type &connection, int contextIdx);
int FnVCCB_ReadExtDbCfgBuildTime(VccbRedisConnection_type &connection, uint16_t cppId);

#ifdef IPC_TEST
int FnVCCB_ReadExtDb(VccbRedisConnection_type &connection);
void FnVCCB_AppendCall(VccbRedisConnection_type &connection, extDbCallBackupQueueNode_type *buff);
int FnVCCB_UpdateExtDbGnb(VccbRedisConnection_type &connection);
int FnVCCB_UpdateExtDbCell(VccbRedisConnection_type &connection);
int FnVCCB_UpdateExtDbCall(VccbRedisConnection_type &connection);
int FnVCCB_UpdateExtDbCfgCellNumInfo(VccbRedisConnection_type &connection);
int FnVCCB_UpdateExtDbCfgGnbNumInfo(VccbRedisConnection_type &connection);
int FnVCCB_UpdateExtDbCfgBuildTime(VccbRedisConnection_type &connection);
int FnVCCB_UpdateExtDbCfg(VccbRedisConnection_type &connection);
int FnVCCB_ReadExtDbGnb(VccbRedisConnection_type &connection);
int FnVCCB_ReadExtDbCell(VccbRedisConnection_type &connection);
int FnVCCB_RedisGetDiffLastUpdateTime(VccbRedisConnection_type &connection);
#endif  // IPC_TEST
#endif  //__CNF__
#endif  // __REDIS_APP_H__
