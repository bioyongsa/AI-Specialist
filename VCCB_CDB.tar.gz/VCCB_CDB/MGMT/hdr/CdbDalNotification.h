#ifndef _VCCB_NOTIHANDLER_H
#define _VCCB_NOTIHANDLER_H

#include "ComInclude.min.h"
#include "DalInterface.h"

uint16_t VccbNotiHandler_initConnection();
void VccbNotiHandler_closeDaemon();
int16_t VccbNotiHandler_initDaemon();
int16_t VccbNotiHandler_registerNotiStream();
void VccbNotiHandler_setOpenSocketFlag(bool value);

int16_t VccbNotiHandler_sendNotification(dal_tag_value_t* elementsToSend, int elementsCount);
struct dal_datetime VccbNotiHandler_getDateTime();

int VLIB_getSourceNameForNotification(char *pBuff, uint32_t buffSize);
int VLIB_getNfcNamingCode(char *pBuff, uint32_t buffSize);

#endif
