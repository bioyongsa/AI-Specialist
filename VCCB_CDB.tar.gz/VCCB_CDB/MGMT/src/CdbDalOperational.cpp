#include "CdbDalOperational.hpp"
#include "ComAutoNtrace.hpp"
#include "DalInterface.h"
#include "ComGlobalData.h"
#include "ComMacro.h"
#include "ComLibIpcApi.h"

namespace dal
{
/****************************************************************************
 * @brief           Constructs OperationalDataSession object.
 *                  Connect/reconnect to dal if necessary. Then start the session.
 *
 * @param[in]       psock : pointer to socket handle. / int*
 ****************************************************************************/
OperationalDataSession::OperationalDataSession(int* psock) : psock_(psock)
{
    AUTO_TRACE_FUNC;

    int status = DAL_SUCCESS;

    if (nullptr == psock_)
    {
        VCCB_PRINT_ERROR("Pointer to sock is NULL!\n");
        return;
    }

    status = dal_db_connect(psock_, DAL_DB_DATA_SOCKET);
    VCCB_HANDLE_DAL_RETURN_VALUE(status, name_);
    if (DAL_SUCCESS != status)
    {
        return;
    }
    socketAcquired_ = true;

    // wait for lock (DAL_DB_LOCK_WAIT) or let it go?
    const int32_t sessionFlags = (int32_t)(DAL_DB_LOCK_REQUEST | DAL_DB_LOCK_PARTIAL | DAL_DB_LOCK_WAIT);
    status = dal_db_start_session(*psock_, DAL_DB_OPERATIONAL, sessionFlags);
    VCCB_HANDLE_DAL_RETURN_VALUE(status, name_);
    if (DAL_SUCCESS != status)
    {
        socketAcquired_ = false;
        const int closeStatus = dal_db_close(*psock_);
        VCCB_HANDLE_DAL_RETURN_VALUE(closeStatus, name_);

        // try to reconnect
        status = dal_db_connect(psock_, DAL_DB_DATA_SOCKET);
        VCCB_HANDLE_DAL_RETURN_VALUE(status, name_);
        if (DAL_SUCCESS != status)
        {
            return;
        }
        socketAcquired_ = true;
        status = dal_db_start_session(*psock_, DAL_DB_OPERATIONAL, sessionFlags);
        VCCB_HANDLE_DAL_RETURN_VALUE(status, name_);
        if (DAL_SUCCESS != status)
        {
            return;
        }
    }

    sessionStarted_ = true;
}

/****************************************************************************
 * @brief           Destructs OperationalDataSession object.
 *                  Close the socket unless connect was not successful.
 *                  Ends the session unless it didn't started.
 ****************************************************************************/
OperationalDataSession::~OperationalDataSession()
{
    AUTO_TRACE_FUNC;

    if (sessionStarted_)
    {
        const int sessiontStatus = dal_db_end_session(*psock_);
        VCCB_HANDLE_DAL_RETURN_VALUE(sessiontStatus, name_);
    }

    if (socketAcquired_)
    {
        const int closeStatus = dal_db_close(*psock_);
        VCCB_HANDLE_DAL_RETURN_VALUE(closeStatus, name_);
    }
}

/****************************************************************************
 * @brief           Instead of throwing an exception if constructor fails this
 *                  function is provided. If an object is properly constructed
 *                  returns true, otherwise returns false.
 ****************************************************************************/
bool OperationalDataSession::isValid() const
{
    AUTO_TRACE_FUNC;

    return socketAcquired_ && sessionStarted_;
}
}  // namespace dal
