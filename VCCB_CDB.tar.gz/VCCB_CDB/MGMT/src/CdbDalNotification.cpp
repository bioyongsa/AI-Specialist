#include "CdbDalNotification.h"
#include "ComInclude.h"
#include "ComTimeUtil.h"

typedef struct
{
    pthread_mutex_t notiHandlerMutex;
    bool isSocketOpened;
    struct dal_daemon_ctx* daemonContext;
    int daemonControlSocket;
    int daemonWorkerSocket;
    struct dal_dp_notification_ctx* notificationContext;
} VccbNotiHandler;

static VccbNotiHandler vccbNotiHandler = {.notiHandlerMutex = PTHREAD_MUTEX_INITIALIZER,
    .isSocketOpened = false,
    .daemonContext = NULL,
    .daemonControlSocket = -1,
    .daemonWorkerSocket = -1,
    .notificationContext = NULL};

uint16_t VccbNotiHandler_initConnection()
{
    AUTO_TRACE_FUNC;

    MUTEX_LOCK(&vccbNotiHandler.notiHandlerMutex);

    if (vccbNotiHandler.isSocketOpened == false)
    {
        VccbNotiHandler_closeDaemon();

        if (VccbNotiHandler_initDaemon() != GOOD)
        {
            VCCB_PRINT_ERROR("VccbNotiHandler_initDaemon() failed\n");
        }
        else
        {
            if (VccbNotiHandler_registerNotiStream() != GOOD)
            {
                VCCB_PRINT_ERROR("VccbNotiHandler_registerNotiStream() failed\n");
            }
            else
            {
                vccbNotiHandler.isSocketOpened = true;
            }
        }
    }

    MUTEX_UNLOCK(&vccbNotiHandler.notiHandlerMutex);
    return GOOD;
}

void VccbNotiHandler_closeDaemon()
{
    AUTO_TRACE_FUNC;

    if (vccbNotiHandler.daemonControlSocket > -1)
    {
        if (dal_close(vccbNotiHandler.daemonControlSocket) != DAL_SUCCESS)
        {
            VCCB_PRINT_ERROR("VccbNotiHandler_closeDaemon(): dal_close() failed\n");
        }

        vccbNotiHandler.daemonControlSocket = -1;
    }

    if (vccbNotiHandler.daemonWorkerSocket > -1)
    {
        if (dal_close(vccbNotiHandler.daemonWorkerSocket) != DAL_SUCCESS)
        {
            VCCB_PRINT_ERROR("VccbNotiHandler_closeDaemon(): dal_close() failed\n");
        }

        vccbNotiHandler.daemonWorkerSocket = -1;
    }

    if (vccbNotiHandler.daemonContext != NULL)
    {
        if (dal_release_daemon(vccbNotiHandler.daemonContext) != DAL_SUCCESS)
        {
            VCCB_PRINT_ERROR("VccbNotiHandler_closeDaemon(): dal_release_daemon() failed\n");
        }

        vccbNotiHandler.daemonContext = NULL;
    }

    vccbNotiHandler.notificationContext = NULL;
}

int16_t VccbNotiHandler_initDaemon()
{
    AUTO_TRACE_FUNC;

    int newSocket;

    vccbNotiHandler.daemonContext = dal_init_daemon("vccb_ConfD_daemon");
    if (vccbNotiHandler.daemonContext == NULL)
    {
        VCCB_PRINT_ERROR("VccbNotiHandler_initDaemon(): dal_init_daemon() failed\n");
    }

    if (vccbNotiHandler.daemonControlSocket > 0)
    {
        if (dal_db_close(vccbNotiHandler.daemonControlSocket) != DAL_SUCCESS)
        {
            VCCB_PRINT_ERROR("VccbNotiHandler_initDaemon(): dal_db_close() failed\n");
        }

        vccbNotiHandler.daemonControlSocket = -1;
    }

    if (vccbNotiHandler.daemonWorkerSocket > 0)
    {
        if (dal_db_close(vccbNotiHandler.daemonWorkerSocket) != DAL_SUCCESS)
        {
            VCCB_PRINT_ERROR("VccbNotiHandler_initDaemon(): dal_db_close() failed\n");
        }

        vccbNotiHandler.daemonWorkerSocket = -1;
    }

    if (dal_daemon_connect(&newSocket, DAL_DAEMON_CONTROL_SOCKET, vccbNotiHandler.daemonContext) != DAL_SUCCESS)
    {
        VCCB_PRINT_ERROR("VccbNotiHandler_initDaemon(): dal_daemon_connect() failed\n");
        return ERROR;
    }

    vccbNotiHandler.daemonControlSocket = newSocket;

    if (dal_daemon_connect(&newSocket, DAL_DAEMON_WORKER_SOCKET, vccbNotiHandler.daemonContext) != DAL_SUCCESS)
    {
        VCCB_PRINT_ERROR("VccbNotiHandler_initDaemon(): dal_daemon_connect() failed\n");
        return ERROR;
    }

    vccbNotiHandler.daemonWorkerSocket = newSocket;

    return GOOD;
}

int16_t VccbNotiHandler_registerNotiStream()
{
    AUTO_TRACE_FUNC;

    struct dal_dp_notification_stream_cbs dalNotiStream;
    memset(&dalNotiStream, 0, sizeof(dalNotiStream));

    dalNotiStream.fd = vccbNotiHandler.daemonWorkerSocket;
    dalNotiStream.get_log_times = NULL;
    dalNotiStream.replay = NULL;
    strncpy(dalNotiStream.streamname, "NETCONF", sizeof(dalNotiStream.streamname));

    if (dal_dp_register_notification_stream(
            vccbNotiHandler.daemonContext, &dalNotiStream, &vccbNotiHandler.notificationContext) != DAL_SUCCESS)
    {
        VCCB_PRINT_ERROR("VccbNotiHandler_registerNotiStream(): dal_dp_register_notification_stream() failed\n");
        return ERROR;
    }

    if (dal_dp_register_done(vccbNotiHandler.daemonContext) != DAL_SUCCESS)
    {
        VCCB_PRINT_ERROR("VccbNotiHandler_registerNotiStream(): dal_dp_register_done() failed\n");
        return ERROR;
    }

    return GOOD;
}

void VccbNotiHandler_setOpenSocketFlag(bool value)
{
    AUTO_TRACE_FUNC;
    MUTEX_LOCK(&vccbNotiHandler.notiHandlerMutex);
    vccbNotiHandler.isSocketOpened = value;
    MUTEX_UNLOCK(&vccbNotiHandler.notiHandlerMutex);
}

struct dal_datetime VccbNotiHandler_getDateTime()
{
    AUTO_TRACE_FUNC;
    tzset();

    time_t timeCnt = time(NULL);
    struct tm stm;
    localtime_r(&timeCnt, &stm);

    struct timespec ts;
    if (ComTimeUtil::get_current_time(ts) < 0)
    {
        VCCB_PRINT_ERROR("ComTimeUtil::get_current_time ERROR in %s\n", __FUNCTION__);
    }

    struct dal_datetime datetime;
    memset(&datetime, 0, sizeof(datetime));
    datetime.year = (int16_t)(stm.tm_year + 1900);
    datetime.month = (uint8_t)(stm.tm_mon + 1);
    datetime.day = (uint8_t)stm.tm_mday;
    datetime.hour = (uint8_t)stm.tm_hour;
    datetime.min = (uint8_t)stm.tm_min;
    datetime.sec = (uint8_t)stm.tm_sec;
    datetime.micro = (uint32_t)(ts.tv_nsec / 1000);
    datetime.timezone = (int8_t)(stm.tm_gmtoff / 3600);
    datetime.timezone_minutes = (int8_t)((stm.tm_gmtoff % 3600) / 60);

    return datetime;
}

int16_t VccbNotiHandler_sendNotification(dal_tag_value_t* elementsToSend, int elementsCount)
{
    AUTO_TRACE_FUNC;

    if (VccbNotiHandler_initConnection() != GOOD)
    {
        VCCB_PRINT_ERROR("VccbNotiHandler_initConnection() failed\n");
        return ERROR;
    }

    struct dal_datetime eventTime = VccbNotiHandler_getDateTime();
    if (dal_dp_notification_send(vccbNotiHandler.notificationContext, &eventTime, elementsToSend, elementsCount) !=
        DAL_SUCCESS)
    {
        VCCB_PRINT_ERROR("VccbNotiHandler_sendNotification(): dal_dp_notification_send failed, error: [%d : %s]\n",
            dal_db_get_error_code(DAL_ERR), dal_strerror(dal_db_get_error_code(DAL_ERR)));
        VccbNotiHandler_setOpenSocketFlag(false);
        return ERROR;
    }

    VCCB_PRINT_COMMENT("Notification sent! (elements sent in noti = %d)\n", elementsCount);

    return GOOD;
}

void VLIB_StrToLower(char *strbuff, size_t strlen, int bufflen)
{
    AUTO_TRACE_FUNC;
    unsigned strloopindex = 0;

    if (strbuff == NULL)
    {
        return;
    }
    if (strlen <= 0 || bufflen <= 0)
    {
        return;
    }
    if (strlen >= (unsigned)bufflen)
    {
        return;
    }

    for (strloopindex = 0; strloopindex < strlen; strloopindex++)
    {
        strbuff[strloopindex] = (char)tolower(strbuff[strloopindex]);
    }
}

int VLIB_getSourceNameForNotification(char *pBuff, uint32_t buffSize)
{
    AUTO_TRACE_FUNC;
#define MAX_INFO_STR_LEN_FOR_NOTI (30)

    if (pBuff == NULL || buffSize == 0)
    {
        VCCB_PRINT_ERROR("[%s   %d] VLIB_getSourceNameForNotification pBuff(%p) or buffSize(%u) invalid\n", __FILE__,
            __LINE__, pBuff, buffSize);
        return ERROR;
    }

#if defined(NEW_HOST_SIM) && (!defined(__CNF__) || defined(IPC_TEST))
    snprintf(pBuff, buffSize, "acpf-1-cpc-0-vccb");
    return GOOD;
#else

#ifdef __CNF__
#define GET_INFO_FOR_SOURCE_NAME(__STR__, __VAL__)                                                                    \
    {                                                                                                                 \
        ret = mdsGetConfigMap(__STR__, MAX_INFO_STR_LEN_FOR_NOTI, __VAL__);                                           \
        if (ret != 0)                                                                                                 \
        {                                                                                                             \
            VCCB_PRINT_ERROR(                                                                                         \
                "[%s   %d] VLIB_getSourceNameForNotification get " __STR__ " Failed(%d)\n", __FILE__, __LINE__, ret); \
            return ERROR;                                                                                             \
        }                                                                                                             \
        VLIB_StrToLower(__VAL__, strlen(__VAL__), MAX_INFO_STR_LEN_FOR_NOTI);                                         \
    }
#else
#define GET_INFO_FOR_SOURCE_NAME(__STR__, __VAL__)                                                                    \
    {                                                                                                                 \
        ret = smiGetNeInfoStr(SMI_SYSINFO_TYPE, __STR__, __VAL__, sizeof(__VAL__));                                   \
        if (ret != 0)                                                                                                 \
        {                                                                                                             \
            VCCB_PRINT_ERROR(                                                                                         \
                "[%s   %d] VLIB_getSourceNameForNotification get " __STR__ " Failed(%d)\n", __FILE__, __LINE__, ret); \
            return ERROR;                                                                                             \
        }                                                                                                             \
        VLIB_StrToLower(__VAL__, strlen(__VAL__), MAX_INFO_STR_LEN_FOR_NOTI);                                         \
    }
#endif

    {
        char strNeType[MAX_INFO_STR_LEN_FOR_NOTI] = {
            0,
        };
        char strNeId[MAX_INFO_STR_LEN_FOR_NOTI] = {
            0,
        };
        char strUnitType[MAX_INFO_STR_LEN_FOR_NOTI] = {
            0,
        };
        char strUnitId[MAX_INFO_STR_LEN_FOR_NOTI] = {
            0,
        };

        int ret;

        GET_INFO_FOR_SOURCE_NAME("NE_TYPE", strNeType);
        GET_INFO_FOR_SOURCE_NAME("NE_ID", strNeId);
#ifdef __CNF__
        GET_INFO_FOR_SOURCE_NAME("POD_TYPE", strUnitType);
        snprintf(strUnitId, MAX_INFO_STR_LEN_FOR_NOTI, "%u", CFG->vm.unitId);
#else
        GET_INFO_FOR_SOURCE_NAME("UNIT_TYPE", strUnitType);
        GET_INFO_FOR_SOURCE_NAME("UNIT_ID", strUnitId);
#endif

        // sourceName : NeType-NeId-UnitType-UnitId-BlockName
        snprintf(pBuff, buffSize, "%s-%s-%s-%s-vccb", strNeType, strNeId, strUnitType, strUnitId);
    }
#endif

#undef MAX_INFO_STR_LEN_FOR_NOTI

    return GOOD;
}

int VLIB_getNfcNamingCode(char *pBuff, uint32_t buffSize)
{
#define MAX_INFO_STR_LEN_FOR_NOTI (30)

    if (pBuff == NULL || buffSize == 0)
    {
        VCCB_PRINT_ERROR(
            "[%s   %d] VLIB_getNfcNamingCode pBuff(%p) or buffSize(%u) invalid\n", __FILE__, __LINE__, pBuff, buffSize);
        return ERROR;
    }

#if defined(NEW_HOST_SIM) && (!defined(__CNF__) || defined(IPC_TEST))
    snprintf(pBuff, buffSize, "cpc");
    return GOOD;
#else

    {
        char strUnitType[MAX_INFO_STR_LEN_FOR_NOTI] = {
            0,
        };

        int ret;

#ifdef __CNF__
#define GET_INFO_FOR_NFC_NAMING_CODE(__STR__, __VAL__)                                                                 \
    {                                                                                                                  \
        ret = mdsGetConfigMap(__STR__, MAX_INFO_STR_LEN_FOR_NOTI, __VAL__);                                            \
        if (ret != 0)                                                                                                  \
        {                                                                                                              \
            VCCB_PRINT_ERROR("[%s   %d] VLIB_getNfcNamingCode get " __STR__ " Failed(%d)\n", __FILE__, __LINE__, ret); \
            return ERROR;                                                                                              \
        }                                                                                                              \
        VLIB_StrToLower(__VAL__, strlen(__VAL__), MAX_INFO_STR_LEN_FOR_NOTI);                                          \
    }
        GET_INFO_FOR_NFC_NAMING_CODE("POD_TYPE", strUnitType);
#else
#define GET_INFO_FOR_NFC_NAMING_CODE(__STR__, __VAL__)                                                                 \
    {                                                                                                                  \
        ret = smiGetNeInfoStr(SMI_SYSINFO_TYPE, __STR__, __VAL__, sizeof(__VAL__));                                    \
        if (ret != 0)                                                                                                  \
        {                                                                                                              \
            VCCB_PRINT_ERROR("[%s   %d] VLIB_getNfcNamingCode get " __STR__ " Failed(%d)\n", __FILE__, __LINE__, ret); \
            return ERROR;                                                                                              \
        }                                                                                                              \
        VLIB_StrToLower(__VAL__, strlen(__VAL__), MAX_INFO_STR_LEN_FOR_NOTI);                                          \
    }
        GET_INFO_FOR_NFC_NAMING_CODE("UNIT_TYPE", strUnitType);
#endif

        // nfcNamingCode : using UnitType
        snprintf(pBuff, buffSize, "%s", strUnitType);
    }

#endif

#undef MAX_INFO_STR_LEN_FOR_NOTI

    return GOOD;
}