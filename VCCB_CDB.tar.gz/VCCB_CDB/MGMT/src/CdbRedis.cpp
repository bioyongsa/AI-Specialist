#ifdef __CNF__
#include "CdbRedis.h"
#include "K8sInterface.h"
#include "ComCallBackupQueue.h"
#include "ComInclude.h"
#include "ComLibUtility.h"
#include "MainAuditTask.h"
#include "MsgVccbSend.h"
#include "RscCell.h"
#include "StateHandleAll.h"
#include "ComMacro.h"
#include "ComUtil.hpp"
#include "VccbDefine.h"

#include "lz4.h"
#include <stdint.h>
#include "ComRedisReply.hpp"

void FnVCCB_AppendCall(VccbRedisConnection_type &connection, extDbCallBackupQueueNode_type *buff)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(buff);
    uint16_t callGroupId = (uint16_t)buff->distCode;
    char hashesKey[REDIS_KEY_LEN];
    FnVCCB_RedisMakeCallHashesKey(hashesKey, callGroupId, buff->callId);
    char sortedSetKey[REDIS_KEY_LEN];
    FnVCCB_RedisMakeCallSortedSetKey(sortedSetKey, callGroupId);

    switch (buff->backupType)
    {
        case BACKUP_TYPE_DEL:
            VCCB_REDIS_PRINT_DATA("[Redis DB][Update] ZREM %s %s\n", sortedSetKey, hashesKey);
            if (ERROR == FnVCCB_RedisAppend(connection, REDIS_BOTH_SIDE, "ZREM %s %s", sortedSetKey, hashesKey))
            {
                VCCB_PRINTF("[Redis DB][Update] (ZREM %s %s) is Failed\n", sortedSetKey, hashesKey);
            }

            VCCB_REDIS_PRINT_DATA("[Redis DB][Update] DEL %s\n", hashesKey);
            if (ERROR == FnVCCB_RedisAppend(connection, REDIS_BOTH_SIDE, "DEL %s", hashesKey))
            {
                VCCB_PRINTF("[Redis DB][Update] (DEL %s) is Failed\n", hashesKey);
            }
            break;
        case BACKUP_TYPE_UPDATE_STATE:
            VCCB_REDIS_PRINT_DATA("[Redis DB][Update] HSET %s state %d\n", hashesKey, buff->state);
            if (ERROR == FnVCCB_RedisAppend(connection, REDIS_BOTH_SIDE, "HSET %s state %d", hashesKey, buff->state))
            {
                VCCB_PRINTF("[Redis DB][Update] HSET %s state is failed\n", hashesKey);
            }
            break;
        case BACKUP_TYPE_UPDATE_EXPIRE:
            VCCB_REDIS_PRINT_DATA("[Redis DB][Update] EXPIRE %s %d\n", hashesKey, REDIS_CALL_DB_EXPIRE_TIME);
            if (ERROR ==
                FnVCCB_RedisAppend(connection, REDIS_BOTH_SIDE, "EXPIRE %s %d", hashesKey, REDIS_CALL_DB_EXPIRE_TIME))
            {
                VCCB_PRINTF("[Redis DB][Update] (EXPIRE %s %d) is failed\n", hashesKey, REDIS_CALL_DB_EXPIRE_TIME);
            }
            break;
        case BACKUP_TYPE_SET:
        {
            VCCB_CHECK_E_RANGE_AND_VOID(buff->callThreadId, MAX_CALL_THREAD_NUM_VCCB);
            VCCB_CHECK_E_RANGE_AND_VOID(buff->bufferIndex, VCCB_MAX_CALL_CTX_BACKUP_BUFF);
            auto &compressedCallInfo = THREAD_INFO->call[buff->callThreadId].buf.compressedCallInfo[buff->bufferIndex];

            VCCB_REDIS_PRINT_DATA("[Redis DB][Update] HSET %s callInfo (bytes_returned:%d) state %d\n", hashesKey,
                buff->len, buff->state);

            if (ERROR == FnVCCB_RedisAppend(connection, REDIS_BOTH_SIDE, "HSET %s callInfo %b state %d", hashesKey,
                             compressedCallInfo.data, buff->len, buff->state))
            {
                VCCB_PRINTF("[Redis DB][Update] HSET %s callInfo state is failed\n", hashesKey);
            }

            VCCB_REDIS_PRINT_DATA("[Redis DB][Update] EXPIRE %s %d\n", hashesKey, REDIS_CALL_DB_EXPIRE_TIME);
            if (ERROR ==
                FnVCCB_RedisAppend(connection, REDIS_BOTH_SIDE, "EXPIRE %s %d", hashesKey, REDIS_CALL_DB_EXPIRE_TIME))
            {
                VCCB_PRINTF("[Redis DB][Update] (EXPIRE %s %d) is failed\n", hashesKey, REDIS_CALL_DB_EXPIRE_TIME);
            }

            VCCB_REDIS_PRINT_DATA("[Redis DB][Update] ZADD %s %d %s\n", sortedSetKey, buff->callId, hashesKey);
            if (ERROR ==
                FnVCCB_RedisAppend(connection, REDIS_BOTH_SIDE, "ZADD %s %d %s", sortedSetKey, buff->callId, hashesKey))
            {
                VCCB_PRINTF("[Redis DB][Update] (ZADD %s %d %s) is failed\n", sortedSetKey, buff->callId, hashesKey);
            }
            break;
        }
        default:
            VCCB_PRINTF("[Redis DB][Update] Invalid call backup attempt\n");
            break;
    }
    return;
}

int FnVCCB_UpdateExtDbGnb(VccbRedisConnection_type &connection)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(connection.info);
    VccbEnvInfo_type *pEnv = ENV;
    int compRet;
    int needToUpdate[MAX_GNB_CU_CP_FUNCTION_PER_SYS] = {FALSE};
    char compBuff[LZ4_COMPRESSBOUND(sizeof(gnbEnvInfo_type))];
    char hashesKey[REDIS_KEY_LEN];
    char sortedSetKey[REDIS_KEY_LEN];
    uint16_t cppId = CFG->vm.unitId;
    for (uint32_t idx = 0; idx < MAX_GNB_PER_SYS; idx++)
    {
        if (pEnv->redis.redisUpdateFlag.gnb[idx])
        {
            needToUpdate[idx] = TRUE;
            MUTEX_LOCK(&pEnv->redis.redisUpdateFlag.gnb_update[idx]);
            pEnv->redis.redisUpdateFlag.gnb[idx] = FALSE;
            MUTEX_UNLOCK(&pEnv->redis.redisUpdateFlag.gnb_update[idx]);
        }
    }

    for (uint32_t idx = 0; idx < MAX_GNB_PER_SYS; idx++)
    {
        if (needToUpdate[idx])
        {
            FnVCCB_RedisMakeGnbHashesKey(hashesKey, cppId, idx);
            FnVCCB_RedisMakeGnbSortedSetKey(sortedSetKey, cppId);

            VccbGnbInfo_type *pGnb = &GNBINFO[idx];
            compRet = LZ4_compress_default(
                (char *)&pGnb->env, compBuff, sizeof(gnbEnvInfo_type), LZ4_COMPRESSBOUND(sizeof(gnbEnvInfo_type)));
            if (compRet <= 0)
            {
                VCCB_PRINTF("[Redis DB][Update] Lz4 Compress is failed(gnbEnvInfo_type)\n");
                return ERROR;
            }
            VCCB_REDIS_PRINT_DATA("[Redis DB][Update] HSET %s env %s\n", hashesKey, compBuff);
            if (ERROR ==
                FnVCCB_RedisAppend(connection, REDIS_BOTH_SIDE, "HSET %s env %b", hashesKey, compBuff, compRet))
            {
                VCCB_PRINTF("[Redis DB][Update] HSET %s env  is failed\n", hashesKey);
                return ERROR;
            }
            memset(compBuff, 0, sizeof(compBuff));

            compRet = LZ4_compress_default((char *)&pGnb->supportedFreqBandInfo, compBuff,
                sizeof(gnbSupportedBandInfo_type), LZ4_COMPRESSBOUND(sizeof(gnbSupportedBandInfo_type)));
            if (compRet <= 0)
            {
                VCCB_PRINTF("[Redis DB][Update] Lz4 Compress is failed(gnbSupportedBandInfo_type)\n");
                return ERROR;
            }

            VCCB_REDIS_PRINT_DATA("[Redis DB][Update] HSET %s sptBand %s\n", hashesKey, compBuff);
            if (ERROR ==
                FnVCCB_RedisAppend(connection, REDIS_BOTH_SIDE, "HSET %s sptBand %b", hashesKey, compBuff, compRet))
            {
                VCCB_PRINTF("[Redis DB][Update] HSET %s sptBand  is failed\n", hashesKey);
                return ERROR;
            }
            memset(compBuff, 0, sizeof(compBuff));

            compRet = LZ4_compress_default(
                (char *)&pGnb->gnbDu, compBuff, sizeof(gnbDuInfo_type), LZ4_COMPRESSBOUND(sizeof(gnbDuInfo_type)));
            if (compRet <= 0)
            {
                VCCB_PRINTF("[Redis DB][Update] Lz4 Compress is failed(gnbDuInfo_type)\n");
                return ERROR;
            }
            VCCB_REDIS_PRINT_DATA("[Redis DB][Update] HSET %s gnbDu %s\n", hashesKey, compBuff);
            if (ERROR ==
                FnVCCB_RedisAppend(connection, REDIS_BOTH_SIDE, "HSET %s gnbDu %b", hashesKey, compBuff, compRet))
            {
                VCCB_PRINTF("[Redis DB][Update] HSET %s gnbDu  is failed\n", hashesKey);
                return ERROR;
            }
            memset(compBuff, 0, sizeof(compBuff));

            VCCB_REDIS_PRINT_DATA("[Redis DB][Update] ZADD %s %d %s\n", sortedSetKey, idx, hashesKey);
            if (ERROR == FnVCCB_RedisAppend(connection, REDIS_BOTH_SIDE, "ZADD %s %d %s", sortedSetKey, idx, hashesKey))
            {
                VCCB_PRINTF("[Redis DB][Update] (ZADD %s %d %s) is failed\n", sortedSetKey, idx, hashesKey);
                return ERROR;
            }

            if (connection.info->appendedCommandCount[REDIS_0] >= VCCB_MAX_PIPELINED_DB_CMD ||
                connection.info->appendedCommandCount[REDIS_1] >= VCCB_MAX_PIPELINED_DB_CMD)
            {
                if (ERROR == FnVCCB_SendPipelinedCmd(connection, REDIS_BOTH_SIDE))
                {
                    VCCB_PRINTF("FnVCCB_SendPipelinedCmd is Failed!!\n");
                    return ERROR;
                }
            }
        }
    }
    if (connection.info->appendedCommandCount[REDIS_0] > 0 || connection.info->appendedCommandCount[REDIS_1] > 0)
    {
        if (ERROR == FnVCCB_SendPipelinedCmd(connection, REDIS_BOTH_SIDE))
        {
            VCCB_PRINTF("FnVCCB_SendPipelinedCmd is Failed!!\n");
            return ERROR;
        }
    }
    return GOOD;
}

int FnVCCB_UpdateExtDbCell(VccbRedisConnection_type &connection)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(connection.info);
    VccbEnvInfo_type *pEnv = ENV;
    int compRet;
    int needToUpdate[MAX_CELL_PER_VNF] = {FALSE};
    char compBuff[LZ4_COMPRESSBOUND(sizeof(VccbCellInfo_type))];
    char hashesKey[REDIS_KEY_LEN];
    char sortedSetKey[REDIS_KEY_LEN];
    uint16_t cppId = CFG->vm.unitId;

    uint32_t idx;
    for (idx = 0; idx < MAX_CELL_NUM_VCCB; idx++)
    {
        if (pEnv->redis.redisUpdateFlag.cell[idx])
        {
            needToUpdate[idx] = TRUE;
            MUTEX_LOCK(&pEnv->redis.redisUpdateFlag.cell_update[idx]);
            pEnv->redis.redisUpdateFlag.cell[idx] = FALSE;
            MUTEX_UNLOCK(&pEnv->redis.redisUpdateFlag.cell_update[idx]);
        }
    }

    for (idx = 0; idx < MAX_CELL_NUM_VCCB; idx++)
    {
        if (needToUpdate[idx])
        {
            FnVCCB_RedisMakeCellHashesKey(hashesKey, cppId, idx);
            FnVCCB_RedisMakeCellSortedSetKey(sortedSetKey, cppId);

            VccbCellInfo_type *pCell = &CELLINFO[idx];
            compRet = LZ4_compress_default(
                (char *)pCell, compBuff, sizeof(VccbCellInfo_type), LZ4_COMPRESSBOUND(sizeof(VccbCellInfo_type)));
            if (compRet <= 0)
            {
                VCCB_PRINTF("[Redis DB][Update] Lz4 Compress is failed(VccbCellInfo_type)\n");
                return ERROR;
            }
            VCCB_REDIS_PRINT_DATA("[Redis DB][Update] HSET %s cellInfo %s\n", hashesKey, compBuff);
            if (ERROR ==
                FnVCCB_RedisAppend(connection, REDIS_BOTH_SIDE, "HSET %s cellInfo %b", hashesKey, compBuff, compRet))
            {
                VCCB_PRINTF("[Redis DB][Update] HSET %s cellInfo  is failed\n", hashesKey);
                return ERROR;
            }

            VCCB_REDIS_PRINT_DATA("[Redis DB][Update] ZADD %s %d %s\n", sortedSetKey, idx, hashesKey);
            if (ERROR == FnVCCB_RedisAppend(connection, REDIS_BOTH_SIDE, "ZADD %s %d %s", sortedSetKey, idx, hashesKey))
            {
                VCCB_PRINTF("[Redis DB][Update] (ZADD %s %d %s) is failed\n", sortedSetKey, idx, hashesKey);
                return ERROR;
            }

            if (connection.info->appendedCommandCount[REDIS_0] >= VCCB_MAX_PIPELINED_DB_CMD ||
                connection.info->appendedCommandCount[REDIS_1] >= VCCB_MAX_PIPELINED_DB_CMD)
            {
                if (ERROR == FnVCCB_SendPipelinedCmd(connection, REDIS_BOTH_SIDE))
                {
                    VCCB_PRINTF("FnVCCB_SendPipelinedCmd is Failed!!\n");
                    return ERROR;
                }
            }
        }
    }
    if (connection.info->appendedCommandCount[REDIS_0] > 0 || connection.info->appendedCommandCount[REDIS_1] > 0)
    {
        if (ERROR == FnVCCB_SendPipelinedCmd(connection, REDIS_BOTH_SIDE))
        {
            VCCB_PRINTF("FnVCCB_SendPipelinedCmd is Failed!!\n");
            return ERROR;
        }
    }
    return GOOD;
}

int FnVCCB_UpdateExtDbCall(VccbRedisConnection_type &connection)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(connection.info);
    uint16_t thId;
    for (thId = 0; thId < MAX_CALL_THREAD_NUM_VCCB; thId++)
    {
        while (TRUE)
        {
            extDbCallBackupQueueNode_type *buff = FnVCCB_DequeueRedisCallQ(thId);
            if (buff == NULL) break;
            FnVCCB_AppendCall(connection, buff);
            if (connection.info->appendedCommandCount[REDIS_0] >= VCCB_MAX_PIPELINED_DB_CMD ||
                connection.info->appendedCommandCount[REDIS_1] >= VCCB_MAX_PIPELINED_DB_CMD)
            {
                if (ERROR == FnVCCB_SendPipelinedCmd(connection, REDIS_BOTH_SIDE))
                {
                    VCCB_PRINTF("FnVCCB_SendPipelinedCmd is Failed!!\n");
                    return ERROR;
                }
            }
        }
    }
    if (connection.info->appendedCommandCount[REDIS_0] > 0 || connection.info->appendedCommandCount[REDIS_1] > 0)
    {
        if (ERROR == FnVCCB_SendPipelinedCmd(connection, REDIS_BOTH_SIDE))
        {
            VCCB_PRINTF("FnVCCB_SendPipelinedCmd is Failed!!\n");
            return ERROR;
        }
    }
    return GOOD;
}

int FnVCCB_RedisGetLastUpdateTime(VccbRedisConnection_type &connection)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(connection.context);
    VALID_E_POINT_CHECK_ERROR(connection.info);
    uint16_t myCppId = CFG->vm.unitId;
    char hashesKey[REDIS_KEY_LEN];
    FnVCCB_RedisMakeCfgHashesKey(hashesKey, myCppId);
    VccbRedisReply reply;
    if (ERROR == FnVCCB_RedisCommandGetReply(connection, REDIS_GET_ACTIVE_IDX(connection),
                     reply.getReplyDoublePointer(), "HGET %s lastUpdateTime", hashesKey))
    {
        VCCB_PRINTF("[Redis DB][%s] (HGET %s lastUpdateTime) is Failed\n", __func__, hashesKey);
        return ERROR;
    }
    // do not count lastUpdateTime command
    connection.info->redisCommandCount[REDIS_GET_ACTIVE_IDX(connection)]--;
    if (reply.getReply()->type != REDIS_REPLY_STRING)
    {
        VCCB_PRINTF("[Redis DB][%s] Reply type(%d) is abnormal!!\n", __func__, reply.getReply()->type);
        return ERROR;
    }
    return util::str::vccb_strtol<int>(reply.getReply()->str);
}

int FnVCCB_RedisGetDiffLastUpdateTime(VccbRedisConnection_type &connection)
{
    AUTO_TRACE_FUNC;
    time_t lastUpdateTime = FnVCCB_RedisGetLastUpdateTime(connection);
    if (lastUpdateTime == ERROR)
    {
        VCCB_PRINTF("[Redis DB] FnVCCB_RedisGetLastUpdateTime is Failed\n");
        return ERROR;
    }
    time_t currT = time(0);
    time_t diffTime = currT - lastUpdateTime;
    VCCB_PRINTF("[Redis DB] Last Valid CheckTime :%d , current Time :%d (Diff :%d)\n", (int)lastUpdateTime, (int)currT,
        (int)diffTime);
    VCCB_PRINT_CRITICAL("[Redis DB] Last Valid CheckTime :%d , current Time :%d (Diff :%d)\n", (int)lastUpdateTime,
        (int)currT, (int)diffTime);
    return (int)diffTime;
}

int FnVCCB_RedisSetLastUpdateTime(VccbRedisConnection_type &connection)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(connection.context);
    VALID_E_POINT_CHECK_ERROR(connection.info);
    uint16_t myCppId = CFG->vm.unitId;
    char hashesKey[REDIS_KEY_LEN];
    FnVCCB_RedisMakeCfgHashesKey(hashesKey, myCppId);
    long int lastUpdateTime = (long int)time(0);
    if (ERROR == FnVCCB_RedisCommandWithoutReply(connection, REDIS_GET_ACTIVE_IDX(connection),
                     "HSET %s lastUpdateTime %ld", hashesKey, lastUpdateTime))
    {
        VCCB_PRINTF("[Redis DB][%s] (HSET %s lastUpdateTime) is Failed\n", __func__, hashesKey);
        return ERROR;
    }
    // do not count lastUpdateTime command
    connection.info->redisCommandCount[REDIS_GET_ACTIVE_IDX(connection)]--;
    return GOOD;
}

int FnVCCB_UpdateExtDbCfgBuildTime(VccbRedisConnection_type &connection)
{
    AUTO_TRACE_FUNC;

    VccbCfgInfo_type *pCfg = CFG;
    uint16_t cppId = pCfg->vm.unitId;
    char hashesKey[REDIS_KEY_LEN];
    FnVCCB_RedisMakeCfgHashesKey(hashesKey, cppId);

    VCCB_REDIS_PRINT_DATA("[Redis DB][Update] HSET %s buildTime %s\n", hashesKey, pCfg->acpfInfo.buildTime);
    if (ERROR == FnVCCB_RedisCommandWithoutReply(
                     connection, REDIS_BOTH_SIDE, "HSET %s buildTime %s", hashesKey, pCfg->acpfInfo.buildTime))
    {
        VCCB_PRINTF("[Redis DB][Update] (HSET %s buildTime) is Failed\n", hashesKey);
        return ERROR;
    }

    if (ERROR == FnVCCB_RedisSetLastUpdateTime(connection))
    {
        VCCB_PRINTF("[Redis DB][Update] FnVCCB_RedisSetLastUpdateTime is Failed\n");
        return ERROR;
    }
    return GOOD;
}

int FnVCCB_UpdateExtDbCfgGnbNumInfo(VccbRedisConnection_type &connection)
{
    AUTO_TRACE_FUNC;

    VccbCfgInfo_type *pCfg = CFG;
    VccbEnvInfo_type *pEnv = ENV;
    uint16_t cppId = pCfg->vm.unitId;
    char hashesKey[REDIS_KEY_LEN];
    FnVCCB_RedisMakeCfgHashesKey(hashesKey, cppId);

    if (pEnv->redis.redisUpdateFlag.cfg.gnbNumInfo)
    {
        MUTEX_LOCK(&pEnv->redis.redisUpdateFlag.cfg.gnbNumInfo_update);
        pEnv->redis.redisUpdateFlag.cfg.gnbNumInfo = FALSE;
        MUTEX_UNLOCK(&pEnv->redis.redisUpdateFlag.cfg.gnbNumInfo_update);
    }
    else
    {
        return GOOD;
    }

    VCCB_REDIS_PRINT_DATA("[Redis DB][Update] HSET %s gnbNumInfo %s\n", hashesKey, (char *)&pCfg->gnbNumInfo);
    if (ERROR == FnVCCB_RedisCommandWithoutReply(connection, REDIS_BOTH_SIDE, "HSET %s gnbNumInfo %b", hashesKey,
                     (char *)&pCfg->gnbNumInfo, sizeof(gnbNumInfo_type)))
    {
        VCCB_PRINTF("[Redis DB][Update] (HSET %s gnbNumInfo) is failed\n", hashesKey);
        return ERROR;
    }
    return GOOD;
}

int FnVCCB_UpdateExtDbCfg(VccbRedisConnection_type &connection)
{
    AUTO_TRACE_FUNC;

    static uint16_t sBuildTimeUpdate = FALSE;
    if (!sBuildTimeUpdate)
    {
        if (ERROR == FnVCCB_UpdateExtDbCfgBuildTime(connection))
        {
            return ERROR;
        }
        else
        {
            sBuildTimeUpdate = TRUE;
        }
    }
    if (ERROR == FnVCCB_UpdateExtDbCfgGnbNumInfo(connection)) return ERROR;
    return GOOD;
}

int FnVCCB_UpdateExtDb(VccbRedisConnection_type &connection)
{
    AUTO_TRACE_FUNC;

    if (ERROR == FnVCCB_UpdateExtDbCfg(connection)) return ERROR;
    if (ERROR == FnVCCB_UpdateExtDbGnb(connection)) return ERROR;
    if (ERROR == FnVCCB_UpdateExtDbCell(connection)) return ERROR;
    if (ERROR == FnVCCB_UpdateExtDbCall(connection)) return ERROR;
    return GOOD;
}

int FnVCCB_ReadExtDbCfgBuildTime(VccbRedisConnection_type &connection, uint16_t cppId)
{
    AUTO_TRACE_FUNC;

    VccbCfgInfo_type *pCfg = CFG;
    char hashesKey[REDIS_KEY_LEN];
    FnVCCB_RedisMakeCfgHashesKey(hashesKey, cppId);

    VCCB_REDIS_PRINT_DATA("[Redis DB][Read] HGET %s buildTime\n", hashesKey);
    VccbRedisReply reply;
    if (ERROR == FnVCCB_RedisCommandGetReply(connection, REDIS_GET_ACTIVE_IDX(connection),
                     reply.getReplyDoublePointer(), "HGET %s buildTime", hashesKey))
    {
        VCCB_PRINTF("[Redis DB][Read] (HGET %s buildTime) is failed!!\n", hashesKey);
        return ERROR;
    }
    if (strncasecmp(pCfg->acpfInfo.buildTime, reply.getReply()->str, reply.getReply()->len) &&
        reply.getReply()->len != 0)
    {
        VCCB_PRINTF("[Redis DB][Read] Build Time is Difference VCCB: %s, Redis: %s\n", pCfg->acpfInfo.buildTime,
            reply.getReply()->str);
        return ERROR;
    }

    if (!strncasecmp("NOAUTH Authentication required", reply.getReply()->str, reply.getReply()->len) &&
        reply.getReply()->len != 0)
    {
        VCCB_PRINTF("[Redis DB][Read] Redis DB install Option is abnormal! Please check Redis DB AUTH!!\n");
        return ERROR;
    }
    return GOOD;
}

int FnVCCB_ReadExtDbCfg(VccbRedisConnection_type &connection)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(connection.context);
    VccbCfgInfo_type *pCfg = CFG;
    uint64_t element_Idx;
    uint16_t cppId = pCfg->vm.unitId;
    char hashesKey[REDIS_KEY_LEN];
    FnVCCB_RedisMakeCfgHashesKey(hashesKey, cppId);

    VCCB_REDIS_PRINT_DATA("[Redis DB][Read] HGETALL %s\n", hashesKey);
    VccbRedisReply reply;
    if (ERROR == FnVCCB_RedisCommandGetReply(connection, REDIS_GET_ACTIVE_IDX(connection),
                     reply.getReplyDoublePointer(), "HGETALL %s", hashesKey))
    {
        VCCB_PRINTF("[Redis DB][Read] (HGETALL %s) is failed!!\n", hashesKey);
        return ERROR;
    }

    VCCB_REDIS_PRINT_DATA("[Redis DB][Read] reply->type:%d len:%lu elements:%lu\n", reply.getReply()->type,
        (uint64_t)reply.getReply()->len, (uint64_t)reply.getReply()->elements);

    for (element_Idx = 0; element_Idx < reply.getReply()->elements; element_Idx++)
    {
        redisReply *replyElement = reply.getReply()->element[element_Idx];
        VALID_E_POINT_CHECK_ERROR(replyElement);
        VCCB_REDIS_PRINT_DATA("[Redis DB][Read] replyElement[%lu].type:%d len:%lu elements:%lu\n", element_Idx,
            replyElement->type, (uint64_t)replyElement->len, replyElement->elements);
        VCCB_REDIS_PRINT_DATA("[Redis DB][Read] %lu) %s\n", element_Idx, replyElement->str);

        if (!strncasecmp(replyElement->str, "buildTime", replyElement->len) && replyElement->len != 0)
        {
            element_Idx++;
            replyElement = reply.getReply()->element[element_Idx];
            VALID_E_POINT_CHECK_ERROR(replyElement);
            VCCB_REDIS_PRINT_DATA("[Redis DB][Read] replyElement[%lu]->type:%d len:%lu str:%s\n", element_Idx,
                replyElement->type, (uint64_t)replyElement->len, replyElement->str);
        }
        else if (!strncasecmp(replyElement->str, "gnbNumInfo", replyElement->len) && replyElement->len != 0)
        {
            element_Idx++;
            replyElement = reply.getReply()->element[element_Idx];
            VALID_E_POINT_CHECK_ERROR(replyElement);
            VCCB_REDIS_PRINT_DATA("[Redis DB][Read] replyElement[%lu]->type:%d len:%lu str:%s\n", element_Idx,
                replyElement->type, (uint64_t)replyElement->len, replyElement->str);
            if (replyElement->len > sizeof(gnbNumInfo_type))
            {
                VCCB_PRINTF(
                    "[Redis DB][Read] replyElement->len is Over[reply : %lu > gnbNumInfo_type : %zu] "
                    "ERROR!!!!\n",
                    replyElement->len, sizeof(gnbNumInfo_type));
                return ERROR;
            }
            memcpy(&pCfg->gnbNumInfo, replyElement->str, replyElement->len);
        }
    }
    VCCB_PRINTF("[Redis DB][Read] %s Finish\n", __func__);
    return GOOD;
}

int FnVCCB_ReadGnbInfoFromRedisReply(VccbRedisReply &reply, const int gnbNum)
{
    AUTO_TRACE_FUNC;

    for (uint32_t element_Idx = 0; element_Idx < reply.getReply()->elements; element_Idx++)
    {
        VCCB_CHECK_E_RANGE_AND_CONTINUE(gnbNum, MAX_GNB_PER_SYS);
        VccbGnbInfo_type *pGnb = &GNBINFO[gnbNum];

        redisReply *replyElement = reply.getReply()->element[element_Idx];
        VALID_E_POINT_CHECK_ERROR(replyElement);
        VCCB_REDIS_PRINT_DATA("[Redis DB][Read] replyElement[%d].type:%d len:%lu elements:%lu\n", element_Idx,
            replyElement->type, replyElement->len, replyElement->elements);
        VCCB_REDIS_PRINT_DATA("[Redis DB][Read] %u) %s\n", element_Idx, replyElement->str);

        if (!strncasecmp(replyElement->str, "env", replyElement->len) && replyElement->len != 0)
        {
            element_Idx++;
            replyElement = reply.getReply()->element[element_Idx];
            VALID_E_POINT_CHECK_ERROR(replyElement);
            VCCB_REDIS_PRINT_DATA("[Redis DB][Read] replyElement[%d].type:%d len:%lu str:%s\n", element_Idx,
                replyElement->type, replyElement->len, replyElement->str);

            int decomp_bytes = LZ4_decompress_safe(
                (char *)replyElement->str, (char *)&pGnb->env, (int32_t)replyElement->len, sizeof(gnbEnvInfo_type));
            if (decomp_bytes < 0)
            {
                VCCB_PRINTF("[Redis DB][Read] LZ4_decompress_safe(env) ERROR(%d)\n", decomp_bytes);
                return ERROR;
            }
        }
        else if (!strncasecmp(replyElement->str, "gnbDu", replyElement->len) && replyElement->len != 0)
        {
            element_Idx++;
            replyElement = reply.getReply()->element[element_Idx];
            VALID_E_POINT_CHECK_ERROR(replyElement);
            VCCB_REDIS_PRINT_DATA("[Redis DB][Read] replyElement[%d].type:%d len:%lu str:%s\n", element_Idx,
                replyElement->type, replyElement->len, replyElement->str);

            int decomp_bytes = LZ4_decompress_safe(
                (char *)replyElement->str, (char *)&pGnb->gnbDu, (int32_t)replyElement->len, sizeof(gnbDuInfo_type));
            if (decomp_bytes < 0)
            {
                VCCB_PRINTF("[Redis DB][Read] LZ4_decompress_safe(gnbDu) ERROR(%d)\n", decomp_bytes);
                return ERROR;
            }
        }
        else if (!strncasecmp(replyElement->str, "sptBand", replyElement->len) && replyElement->len != 0)
        {
            element_Idx++;
            replyElement = reply.getReply()->element[element_Idx];
            VCCB_REDIS_PRINT_DATA("[Redis DB][Read] replyElement[%d].type:%d len:%lu str:%s\n", element_Idx,
                replyElement->type, replyElement->len, replyElement->str);

            int decomp_bytes = LZ4_decompress_safe((char *)replyElement->str, (char *)&pGnb->supportedFreqBandInfo,
                (int32_t)replyElement->len, sizeof(gnbSupportedBandInfo_type));
            if (decomp_bytes < 0)
            {
                VCCB_PRINTF("[Redis DB][Read] LZ4_decompress_safe(supportedFreqBandInfo) ERROR(%d)\n", decomp_bytes);
                return ERROR;
            }
        }
        else
        {
            VCCB_REDIS_PRINT_DATA("[Redis DB][Read] LZ4_decompress Fail (Wrong input : %s)\n", replyElement->str);
            return ERROR;
        }
    }
    return GOOD;
}

int FnVCCB_ReadExtDbGnb(VccbRedisConnection_type &connection)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(connection.context);
    VALID_E_POINT_CHECK_ERROR(connection.info);

    char sortedSetKey[REDIS_KEY_LEN];
    uint16_t cppId = CFG->vm.unitId;
    FnVCCB_RedisMakeGnbSortedSetKey(sortedSetKey, cppId);

    // Get all gnb keys.
    VCCB_REDIS_PRINT_DATA("[Redis DB][Read] ZRANGE %s 0 -1\n", sortedSetKey);
    VccbRedisReply replyZrange;
    if (ERROR == FnVCCB_RedisCommandGetReply(connection, REDIS_GET_ACTIVE_IDX(connection),
                     replyZrange.getReplyDoublePointer(), "ZRANGE %s 0 -1", sortedSetKey))
    {
        VCCB_PRINTF("[Redis DB][Read] (ZRANGE %s 0 -1) is Failed\n", sortedSetKey);
        return ERROR;
    }
    VCCB_REDIS_PRINT_DATA("[Redis DB][Read] replyZrange->type:%d len:%lu elements:%lu\n", replyZrange.getReply()->type,
        replyZrange.getReply()->len, replyZrange.getReply()->elements);

    int gnbNumInKey[VCCB_MAX_PIPELINED_DB_CMD];
    memset(gnbNumInKey, 0, sizeof(gnbNumInKey));
    int &pipelinedCmd = connection.info->appendedCommandCount[connection.info->readContextIdx];
    if (pipelinedCmd >= VCCB_MAX_PIPELINED_DB_CMD || pipelinedCmd < 0)
    {
        VCCB_PRINTF("[Redis DB][Read] Invalid value, pipelinedCmd(%d)\n", pipelinedCmd);
        return ERROR;
    }

    for (int zrangeIdx = 0; zrangeIdx < (int)replyZrange.getReply()->elements; zrangeIdx++)
    {
        redisReply *replyElement = replyZrange.getReply()->element[zrangeIdx];
        VALID_E_POINT_CHECK_BREAK(replyElement);

        // gnbNum is obtained from the key obtained through Zrange and backed up to gnbNumInKey.
        gnbNumInKey[pipelinedCmd] = FnVCCB_GetIdFromZrange((char *)replyElement->str, (int)replyElement->len);
        if (gnbNumInKey[pipelinedCmd] < 0)
        {
            VCCB_PRINTF(
                "[Redis DB][Read] Invalid value, gnbNumInKey[%d](%d)\n", pipelinedCmd, gnbNumInKey[pipelinedCmd]);
            return ERROR;
        }

        // appends a command that reads the value of the key obtained by zrange to the pipeline.
        VCCB_REDIS_PRINT_DATA("[Redis DB][Read] Append HGETALL %s \n", replyElement->str);
        if (ERROR == FnVCCB_RedisAppend(connection, REDIS_GET_ACTIVE_IDX(connection), "HGETALL %s", replyElement->str))
        {
            VCCB_PRINTF("[Redis DB][Read] (HGETALL %s) is failed!!\n", replyElement->str);
            return ERROR;
        }

        // if the appended commands are accumulated as much as VCCB_MAX_PIPELINED_DB_CMD, execute them.
        if ((pipelinedCmd == VCCB_MAX_PIPELINED_DB_CMD) || ((zrangeIdx + 1) == (int)replyZrange.getReply()->elements))
        {
            for (int pipelinedCmdIdx = 0; pipelinedCmdIdx < pipelinedCmd; pipelinedCmdIdx++)
            {
                VccbRedisReply reply;
                if (redisGetReply(connection.context[connection.info->readContextIdx],
                        (void **)(reply.getReplyDoublePointer())) != REDIS_OK ||
                    reply.getReply() == NULL)
                {
                    VCCB_PRINTF(
                        "redisGetReply err[%s]\n", connection.context[connection.info->readContextIdx]->errstr);
                    return ERROR;
                }
                int gnbNum = gnbNumInKey[pipelinedCmdIdx];
                if (ERROR == FnVCCB_ReadGnbInfoFromRedisReply(reply, gnbNum))
                {
                    VCCB_PRINTF("[Redis DB] FnVCCB_ReadGnbInfoFromRedisReply is failed\n");
                    return ERROR;
                }
            }
            pipelinedCmd = 0;
        }
    }
    VCCB_PRINTF("[Redis DB][Read] %s Finish\n", __func__);
    return GOOD;
}

int FnVCCB_ReadCellInfoFromRedisReply(VccbRedisReply &reply, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    for (uint32_t element_Idx = 0; element_Idx < reply.getReply()->elements; element_Idx++)
    {
        redisReply *replyElement = reply.getReply()->element[element_Idx];
        VALID_E_POINT_CHECK_ERROR(replyElement);
        VCCB_REDIS_PRINT_DATA("[Redis DB][Read] replyElement[%d].type:%d len:%lu elements:%lu\n", element_Idx,
            replyElement->type, replyElement->len, replyElement->elements);
        VCCB_REDIS_PRINT_DATA("[Redis DB][Read] %u) %s\n", element_Idx, replyElement->str);
        if (!strncasecmp(replyElement->str, "cellInfo", replyElement->len) && replyElement->len != 0)
        {
            element_Idx++;
            replyElement = reply.getReply()->element[element_Idx];
            VALID_E_POINT_CHECK_ERROR(replyElement);
            int decomp_bytes = LZ4_decompress_safe(
                (char *)replyElement->str, (char *)pCell, (int32_t)replyElement->len, sizeof(VccbCellInfo_type));
            if (decomp_bytes < 0)
            {
                VCCB_PRINTF("[Redis DB][Read] LZ4_decompress_safe(cellInfo) ERROR(%d)\n", decomp_bytes);
                return ERROR;
            }
            VRRM_initCellCallCount(pCell, cellNum);
        }
        else
        {
            VCCB_REDIS_PRINT_DATA("[Redis DB][Read] LZ4_decompress Fail (Wrong input : %s)\n", replyElement->str);
            return ERROR;
        }
    }
    return GOOD;
}

int FnVCCB_ReadExtDbCell(VccbRedisConnection_type &connection)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(connection.context);
    VALID_E_POINT_CHECK_ERROR(connection.info);
    uint16_t cppId = CFG->vm.unitId;
    char sortedSetKey[REDIS_KEY_LEN];
    FnVCCB_RedisMakeCellSortedSetKey(sortedSetKey, cppId);

    // Get all cell keys.
    VCCB_REDIS_PRINT_DATA("[Redis DB][Read] ZRANGE %s 0 -1\n", sortedSetKey);
    VccbRedisReply replyZrange;
    if (ERROR == FnVCCB_RedisCommandGetReply(connection, REDIS_GET_ACTIVE_IDX(connection),
                     replyZrange.getReplyDoublePointer(), "ZRANGE %s 0 -1", sortedSetKey))
    {
        VCCB_PRINTF("[Redis DB][Read] (ZRANGE %s 0 -1) is Failed\n", sortedSetKey);
        return ERROR;
    }

    VCCB_REDIS_PRINT_DATA("[Redis DB][Read] replyZrange->type:%d len:%lu elements:%lu\n", replyZrange.getReply()->type,
        replyZrange.getReply()->len, replyZrange.getReply()->elements);

    int cellNumInKey[VCCB_MAX_PIPELINED_DB_CMD];
    memset(cellNumInKey, 0, sizeof(cellNumInKey));
    int &pipelinedCmd = connection.info->appendedCommandCount[connection.info->readContextIdx];
    if (pipelinedCmd >= VCCB_MAX_PIPELINED_DB_CMD || pipelinedCmd < 0)
    {
        VCCB_PRINTF("[Redis DB][Read] Invalid value, pipelinedCmd(%d)\n", pipelinedCmd);
        return ERROR;
    }

    for (int zrangeIdx = 0; zrangeIdx < (int)replyZrange.getReply()->elements; zrangeIdx++)
    {
        redisReply *replyElement = replyZrange.getReply()->element[zrangeIdx];
        VALID_E_POINT_CHECK_BREAK(replyElement);

        // cellNum is obtained from the key obtained through Zrange and backed up to cellNumInKey.
        cellNumInKey[pipelinedCmd] = FnVCCB_GetIdFromZrange((char *)replyElement->str, (int)replyElement->len);
        if (cellNumInKey[pipelinedCmd] < 0)
        {
            VCCB_PRINTF(
                "[Redis DB][Read] Invalid value, cellNumInKey[%d](%d)\n", pipelinedCmd, cellNumInKey[pipelinedCmd]);
            return ERROR;
        }

        // appends a command that reads the value of the key obtained by zrange to the pipeline.
        VCCB_REDIS_PRINT_DATA("[Redis DB][Read] Append HGETALL %s \n", replyElement->str);
        if (ERROR == FnVCCB_RedisAppend(connection, REDIS_GET_ACTIVE_IDX(connection), "HGETALL %s", replyElement->str))
        {
            VCCB_PRINTF("[Redis DB][Read] (HGETALL %s) is failed!!\n", replyElement->str);
            return ERROR;
        }

        // if the appended commands are accumulated as much as VCCB_MAX_PIPELINED_DB_CMD, execute them.
        if ((pipelinedCmd == VCCB_MAX_PIPELINED_DB_CMD) || ((zrangeIdx + 1) == (int)replyZrange.getReply()->elements))
        {
            for (int pipelinedCmdIdx = 0; pipelinedCmdIdx < pipelinedCmd; pipelinedCmdIdx++)
            {
                VccbRedisReply reply;
                if (redisGetReply(connection.context[connection.info->readContextIdx],
                        (void **)(reply.getReplyDoublePointer())) != REDIS_OK ||
                    reply.getReply() == NULL)
                {
                    VCCB_PRINTF(
                        "redisGetReply err[%s]\n", connection.context[connection.info->readContextIdx]->errstr);
                    return ERROR;
                }
                const uint16_t cellNum = (uint16_t)cellNumInKey[pipelinedCmdIdx];
                if (ERROR == FnVCCB_ReadCellInfoFromRedisReply(reply, cellNum))
                {
                    VCCB_PRINTF("[Redis DB] FnVCCB_ReadCellInfoFromRedisReply is failed\n");
                    return ERROR;
                }
            }
            pipelinedCmd = 0;
        }
    }
    VCCB_PRINTF("[Redis DB][Read] %s Finish\n", __func__);
    return GOOD;
}

int FnVCCB_ReadExtDb(VccbRedisConnection_type &connection)
{
    AUTO_TRACE_FUNC;

    if (ERROR == FnVCCB_ReadExtDbCfg(connection)) return ERROR;
    if (ERROR == FnVCCB_ReadExtDbGnb(connection)) return ERROR;
    if (ERROR == FnVCCB_ReadExtDbCell(connection)) return ERROR;
    VCCB_PRINTF("[Redis DB][Read] %s Finish\n", __func__);
    return GOOD;
}

int FnVCCB_UpdateRedisCallDBExpire(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    if (FnVCCB_EnqueueRedisCallQ(ptCi, BACKUP_TYPE_UPDATE_EXPIRE) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[%s][ExtDb] FnVCCB_EnqueueRedisCallQ ERROR !!\n", __FUNCTION__);
        return ERROR;
    }
    return GOOD;
}

int FnVCCB_RedisDeleteAllCallOfMyCpp(VccbRedisConnection_type &connection, int contextIdx)
{
    AUTO_TRACE_FUNC;

    int firstDistCode = VCCB_FIRST_DEFAULT_DIST_CODE;
    for (int distCode = firstDistCode; distCode < firstDistCode + MAX_ACTIVE_CPC_PER_SYS; distCode++)
    {
        VccbRedisReply reply;
        if (ERROR == FnVCCB_RedisCommandGetReply(
                         connection, contextIdx, reply.getReplyDoublePointer(), "KEYS dist#%04d:*", distCode))
        {
            VCCB_PRINTF("[Redis DB][Delete] (KEYS dist#%04d:*) is Failed\n", distCode);
            return ERROR;
        }
        for (int element_Idx = 0; element_Idx < (int)reply.getReply()->elements; element_Idx++)
        {
            if (ERROR == FnVCCB_RedisCommandWithoutReply(
                             connection, contextIdx, "UNLINK %s", reply.getReply()->element[element_Idx]->str))
            {
                VCCB_PRINTF("[Redis DB][Delete] (UNLINK) is Failed\n");
                return ERROR;
            }
        }
    }

    return GOOD;
}

int FnVCCB_RedisDeleteAllGnbOfMyCpp(VccbRedisConnection_type &connection, int contextIdx)
{
    AUTO_TRACE_FUNC;

    uint16_t myCppId = CFG->vm.unitId;

    {
        VccbRedisReply reply;
        if (ERROR == FnVCCB_RedisCommandGetReply(
                         connection, contextIdx, reply.getReplyDoublePointer(), "KEYS vccb#%02d:gnb*", myCppId))
        {
            VCCB_PRINTF("[Redis DB][Delete] (KEYS vccb#%02d:gnb*) is Failed\n", myCppId);
            return ERROR;
        }

        for (int element_Idx = 0; element_Idx < (int)reply.getReply()->elements; element_Idx++)
        {
            if (ERROR == FnVCCB_RedisCommandWithoutReply(
                             connection, contextIdx, "UNLINK %s", reply.getReply()->element[element_Idx]->str))
            {
                VCCB_PRINTF("[Redis DB][Delete] (UNLINK) is Failed\n");
                return ERROR;
            }
        }
    }

    return GOOD;
}

int FnVCCB_RedisDeleteAllCellOfMyCpp(VccbRedisConnection_type &connection, int contextIdx)
{
    AUTO_TRACE_FUNC;

    uint16_t myCppId = CFG->vm.unitId;

    {
        VccbRedisReply reply;
        if (ERROR == FnVCCB_RedisCommandGetReply(
                         connection, contextIdx, reply.getReplyDoublePointer(), "KEYS vccb#%02d:cell*", myCppId))
        {
            VCCB_PRINTF("[Redis DB][Delete] (KEYS vccb#%02d:cell*) is Failed\n", myCppId);
            return ERROR;
        }

        for (int element_Idx = 0; element_Idx < (int)reply.getReply()->elements; element_Idx++)
        {
            if (ERROR == FnVCCB_RedisCommandWithoutReply(
                             connection, contextIdx, "UNLINK %s", reply.getReply()->element[element_Idx]->str))
            {
                VCCB_PRINTF("[Redis DB][Delete] (UNLINK) is Failed\n");
                return ERROR;
            }
        }
    }

    return GOOD;
}

int FnVCCB_RedisDeleteAllCfgOfMyCpp(VccbRedisConnection_type &connection, int contextIdx)
{
    AUTO_TRACE_FUNC;

    uint16_t myCppId = CFG->vm.unitId;

    {
        VccbRedisReply reply;
        if (ERROR == FnVCCB_RedisCommandGetReply(
                         connection, contextIdx, reply.getReplyDoublePointer(), "KEYS vccb#%02d:cfg*", myCppId))
        {
            VCCB_PRINTF("[Redis DB][Delete] (KEYS vccb#%02d:cfg*) is Failed\n", myCppId);
            return ERROR;
        }

        for (int element_Idx = 0; element_Idx < (int)reply.getReply()->elements; element_Idx++)
        {
            if (ERROR == FnVCCB_RedisCommandWithoutReply(
                             connection, contextIdx, "UNLINK %s", reply.getReply()->element[element_Idx]->str))
            {
                VCCB_PRINTF("[Redis DB][Delete] (UNLINK) is Failed\n");
                return ERROR;
            }
        }
    }

    return GOOD;
}

int FnVCCB_RedisDeleteAllDataOfMyCpp(VccbRedisConnection_type &connection, int contextIdx)
{
    AUTO_TRACE_FUNC;

    if (ERROR == FnVCCB_RedisDeleteAllCallOfMyCpp(connection, contextIdx))
    {
        VCCB_PRINTF("[Redis DB] FnVCCB_RedisDeleteAllCallOfMyCpp is Failed\n");
        return ERROR;
    }

    if (ERROR == FnVCCB_RedisDeleteAllCellOfMyCpp(connection, contextIdx))
    {
        VCCB_PRINTF("[Redis DB] FnVCCB_RedisDeleteAllCellOfMyCpp is Failed\n");
        return ERROR;
    }

    if (ERROR == FnVCCB_RedisDeleteAllGnbOfMyCpp(connection, contextIdx))
    {
        VCCB_PRINTF("[Redis DB] FnVCCB_RedisDeleteAllGnbOfMyCpp is Failed\n");
        return ERROR;
    }

    if (ERROR == FnVCCB_RedisDeleteAllCfgOfMyCpp(connection, contextIdx))
    {
        VCCB_PRINTF("[Redis DB] FnVCCB_RedisDeleteAllCfgOfMyCpp is Failed\n");
        return ERROR;
    }

    return GOOD;
}

int FnVCCB_SetCfgData(VccbRedisConnection_type &connection, int contextIdx)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_RETURN(contextIdx, REDIS_MAX_CONTEXT_CNT);
    VccbCfgInfo_type *pCfg = CFG;
    uint16_t cppId = pCfg->vm.unitId;
    char hashesKey[REDIS_KEY_LEN];
    FnVCCB_RedisMakeCfgHashesKey(hashesKey, cppId);

    VCCB_REDIS_PRINT_DATA("[Redis DB][ReSync] HSET %s gnbNumInfo %s\n", hashesKey, (char *)&pCfg->gnbNumInfo);
    if (ERROR == FnVCCB_RedisCommandWithoutReply(connection, contextIdx, "HSET %s gnbNumInfo %b", hashesKey,
                     (char *)&pCfg->gnbNumInfo, sizeof(gnbNumInfo_type)))
    {
        VCCB_PRINTF("[Redis DB][ReSync] (HSET %s gnbNumInfo) is Failed\n", hashesKey);
        return ERROR;
    }

    VCCB_REDIS_PRINT_DATA("[Redis DB][ReSync] HSET %s buildTime %s\n", hashesKey, pCfg->acpfInfo.buildTime);
    if (ERROR == FnVCCB_RedisCommandWithoutReply(
                     connection, contextIdx, "HSET %s buildTime %s", hashesKey, pCfg->acpfInfo.buildTime))
    {
        VCCB_PRINTF("[Redis DB][ReSync] (HSET %s buildTime) is Failed\n", hashesKey);
        return ERROR;
    }

    if (ERROR == FnVCCB_RedisSetLastUpdateTime(connection))
    {
        VCCB_PRINTF("[Redis DB][ReSync] FnVCCB_RedisSetLastUpdateTime is Failed\n");
        return ERROR;
    }

    return GOOD;
}

int FnVCCB_SetGnbData(VccbRedisConnection_type &connection, int contextIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(connection.info);
    VCCB_CHECK_E_RANGE_AND_RETURN(contextIdx, REDIS_MAX_CONTEXT_CNT);
    uint32_t idx;
    int compRet;
    char compBuff[LZ4_COMPRESSBOUND(sizeof(gnbEnvInfo_type))];
    char hashesKey[REDIS_KEY_LEN];
    char sortedSetKey[REDIS_KEY_LEN];
    uint16_t cppId = CFG->vm.unitId;

    for (idx = 0; idx < MAX_GNB_PER_SYS; idx++)
    {
        VccbGnbInfo_type *pGnb = &GNBINFO[idx];
        if (pGnb->status == EQUIP)
        {
            FnVCCB_RedisMakeGnbHashesKey(hashesKey, cppId, idx);
            FnVCCB_RedisMakeGnbSortedSetKey(sortedSetKey, cppId);

            compRet = LZ4_compress_default(
                (char *)&pGnb->env, compBuff, sizeof(gnbEnvInfo_type), LZ4_COMPRESSBOUND(sizeof(gnbEnvInfo_type)));
            if (compRet <= 0)
            {
                VCCB_PRINTF("[Redis DB][ReSync] Lz4 Compress is failed(gnbEnvInfo_type)\n");
                return ERROR;
            }
            VCCB_REDIS_PRINT_DATA("[Redis DB][ReSync] HSET %s env %s\n", hashesKey, compBuff);
            if (ERROR == FnVCCB_RedisAppend(connection, contextIdx, "HSET %s env %b", hashesKey, compBuff, compRet))
            {
                VCCB_PRINTF("[Redis DB][ReSync] HSET %s env  is failed\n", hashesKey);
                return ERROR;
            }
            memset(compBuff, 0, sizeof(compBuff));

            compRet = LZ4_compress_default((char *)&pGnb->supportedFreqBandInfo, compBuff,
                sizeof(gnbSupportedBandInfo_type), LZ4_COMPRESSBOUND(sizeof(gnbSupportedBandInfo_type)));
            if (compRet <= 0)
            {
                VCCB_PRINTF("[Redis DB][ReSync] Lz4 Compress is failed(gnbSupportedBandInfo_type)\n");
                return ERROR;
            }

            VCCB_REDIS_PRINT_DATA("[Redis DB][ReSync] HSET %s sptBand %s\n", hashesKey, compBuff);
            if (ERROR == FnVCCB_RedisAppend(connection, contextIdx, "HSET %s sptBand %b", hashesKey, compBuff, compRet))
            {
                VCCB_PRINTF("[Redis DB][ReSync] HSET %s env  is failed\n", hashesKey);
                return ERROR;
            }
            memset(compBuff, 0, sizeof(compBuff));

            compRet = LZ4_compress_default(
                (char *)&pGnb->gnbDu, compBuff, sizeof(gnbDuInfo_type), LZ4_COMPRESSBOUND(sizeof(gnbDuInfo_type)));
            if (compRet <= 0)
            {
                VCCB_PRINTF("[Redis DB][ReSync] Lz4 Compress is failed(gnbDuInfo_type)\n");
                return ERROR;
            }
            VCCB_REDIS_PRINT_DATA("[Redis DB][ReSync] HSET %s gnbDu %s\n", hashesKey, compBuff);
            if (ERROR == FnVCCB_RedisAppend(connection, contextIdx, "HSET %s gnbDu %b", hashesKey, compBuff, compRet))
            {
                VCCB_PRINTF("[Redis DB][ReSync] HSET %s env  is failed\n", hashesKey);
                return ERROR;
            }
            memset(compBuff, 0, sizeof(compBuff));

            VCCB_REDIS_PRINT_DATA("[Redis DB][ReSync] ZADD %s %d %s\n", sortedSetKey, idx, hashesKey);
            if (ERROR == FnVCCB_RedisAppend(connection, contextIdx, "ZADD %s %d %s", sortedSetKey, idx, hashesKey))
            {
                VCCB_PRINTF("[Redis DB][ReSync] (ZADD %s %d %s) is failed\n", sortedSetKey, idx, hashesKey);
                return ERROR;
            }

            if (connection.info->appendedCommandCount[REDIS_0] >= VCCB_MAX_PIPELINED_DB_CMD ||
                connection.info->appendedCommandCount[REDIS_1] >= VCCB_MAX_PIPELINED_DB_CMD)
            {
                if (ERROR == FnVCCB_SendPipelinedCmd(connection, contextIdx))
                {
                    return ERROR;
                }
            }
        }
    }
    if (connection.info->appendedCommandCount[REDIS_0] > 0 || connection.info->appendedCommandCount[REDIS_1] > 0)
    {
        if (ERROR == FnVCCB_SendPipelinedCmd(connection, contextIdx))
        {
            return ERROR;
        }
    }
    return GOOD;
}

int FnVCCB_SetCellData(VccbRedisConnection_type &connection, int contextIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(connection.context);
    VALID_E_POINT_CHECK_ERROR(connection.info);
    VCCB_CHECK_E_RANGE_AND_RETURN(contextIdx, REDIS_MAX_CONTEXT_CNT);
    int compRet;
    char compBuff[LZ4_COMPRESSBOUND(sizeof(VccbCellInfo_type))];
    char hashesKey[REDIS_KEY_LEN];
    char sortedSetKey[REDIS_KEY_LEN];
    uint16_t cppId = CFG->vm.unitId;

    for (uint32_t idx = 0; idx < MAX_CELL_NUM_VCCB; idx++)
    {
        VccbCellInfo_type *pCell = &CELLINFO[idx];
        if (pCell->status == EQUIP)
        {
            FnVCCB_RedisMakeCellHashesKey(hashesKey, cppId, idx);
            FnVCCB_RedisMakeCellSortedSetKey(sortedSetKey, cppId);

            compRet = LZ4_compress_default(
                (char *)pCell, compBuff, sizeof(VccbCellInfo_type), LZ4_COMPRESSBOUND(sizeof(VccbCellInfo_type)));
            if (compRet <= 0)
            {
                VCCB_PRINTF("[Redis DB][ReSync] Lz4 Compress is failed(VccbCellInfo_type)\n");
                return ERROR;
            }
            VCCB_REDIS_PRINT_DATA("[Redis DB][ReSync] HSET %s cellInfo %s\n", hashesKey, compBuff);
            if (ERROR ==
                FnVCCB_RedisAppend(connection, contextIdx, "HSET %s cellInfo %b", hashesKey, compBuff, compRet))
            {
                VCCB_PRINTF("[Redis DB][ReSync] HSET %s cellInfo  is failed\n", hashesKey);
                return ERROR;
            }

            VCCB_REDIS_PRINT_DATA("[Redis DB][ReSync] ZADD %s %d %s\n", sortedSetKey, idx, hashesKey);
            if (ERROR == FnVCCB_RedisAppend(connection, contextIdx, "ZADD %s %d %s", sortedSetKey, idx, hashesKey))
            {
                VCCB_PRINTF("[Redis DB][ReSync] (ZADD %s %d %s) is failed\n", sortedSetKey, idx, hashesKey);
                return ERROR;
            }

            if (connection.info->appendedCommandCount[REDIS_0] >= VCCB_MAX_PIPELINED_DB_CMD ||
                connection.info->appendedCommandCount[REDIS_1] >= VCCB_MAX_PIPELINED_DB_CMD)
            {
                if (ERROR == FnVCCB_SendPipelinedCmd(connection, contextIdx))
                {
                    return ERROR;
                }
            }
        }
    }
    if (connection.info->appendedCommandCount[REDIS_0] > 0 || connection.info->appendedCommandCount[REDIS_1] > 0)
    {
        if (ERROR == FnVCCB_SendPipelinedCmd(connection, contextIdx))
        {
            return ERROR;
        }
    }
    return GOOD;
}

int FnVCCB_DataReSync(VccbRedisConnection_type &connection, int contextIdx)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_RETURN(contextIdx, REDIS_MAX_CONTEXT_CNT);
    int ret = GOOD;

    ret = FnVCCB_RedisDeleteAllDataOfMyCpp(connection, contextIdx);
    if (ret == ERROR)
    {
        VCCB_PRINTF("[Redis DB][ReSync] FnVCCB_DeleteAll is Failed\n");
        return ERROR;
    }
    if (ERROR == FnVCCB_SetCellData(connection, contextIdx)) return ERROR;
    if (ERROR == FnVCCB_SetGnbData(connection, contextIdx)) return ERROR;
    if (ERROR == FnVCCB_SetCfgData(connection, contextIdx)) return ERROR;
    return ret;
}

int FnVCCB_AuditExtDb(VccbRedisConnection_type &connection)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(connection.info);

    if (ERROR == PingToServer(connection))
    {
        int prevCondRedisConnection[REDIS_MAX_CONTEXT_CNT];
        for (int contextIdx = 0; contextIdx < REDIS_MAX_CONTEXT_CNT; contextIdx++)
        {
            prevCondRedisConnection[contextIdx] = connection.info->isContextConnected[contextIdx];
        }
        if (ERROR == FnVCCB_ConnectRedisDb(connection))
        {
            FnVCCB_CountRedisAccessFail();
            VCCB_PRINTF("[Redis DB][Audit] FnVCCB_ConnectRedisDb ERROR\n");
            return ERROR;
        }
        else
        {
            FnVCCB_ClearRedisAccessAlarm();
        }
        for (int contextIdx = 0; contextIdx < REDIS_MAX_CONTEXT_CNT; contextIdx++)
        {
            if (prevCondRedisConnection[contextIdx] == FALSE && connection.info->isContextConnected[contextIdx] == TRUE)
            {
                if (ERROR == FnVCCB_DataReSync(connection, contextIdx))
                {
                    VCCB_PRINTF("[Redis DB][Conn] FnVCCB_DataReSync is Failed\n");
                    return ERROR;
                }
            }
        }
    }

    // Skip the call audit operation until the call restore is completed.
    if (ENV->redis.restoreCompletedFlag == VCCB_FLAG_OFF)
    {
        VCCB_PRINTF("[Redis DB][Audit] Skip call audit because call restore is not completed.\n");
        return GOOD;
    }

    static int32_t sStartScore = 0;
    char sortedSetKey[REDIS_KEY_LEN];
    static int16_t callGroupIdx = -1;
    static int16_t firstDefaultDistCode = (int16_t)VCCB_FIRST_DEFAULT_DIST_CODE;
    int32_t endScore = sStartScore + MAX_EXT_DB_AUDIT_CALL_COUNT - 1;
    if (endScore >= (int32_t)MAX_CALL_COUNT_PER_DISTCODE)
    {
        endScore = -1;
    }

    if (callGroupIdx == -1)  // for first function call
    {
        callGroupIdx = firstDefaultDistCode;
    }

    FnVCCB_RedisMakeCallSortedSetKey(sortedSetKey, (uint16_t)callGroupIdx);

    if(ENV->distCodeInfo[callGroupIdx].isAllocated == FALSE)
    {
        VCCB_REDIS_PRINT_DATA("[Redis DB][Audit] %s is not allocated yet !!\n", sortedSetKey);
        
        sStartScore = 0;
        callGroupIdx++;
        if (callGroupIdx == firstDefaultDistCode + 20)
        {
            callGroupIdx = firstDefaultDistCode;
        }
        
        return GOOD;
    }

    VCCB_REDIS_PRINT_DATA("[Redis DB][Audit] ZRANGEBYSCORE %s %d %d\n", sortedSetKey, sStartScore, endScore);
    VccbRedisReply replyZrange;
    int zrangeResult = ERROR;
    if (endScore != -1)
    {
        zrangeResult = FnVCCB_RedisCommandGetReply(connection, REDIS_GET_ACTIVE_IDX(connection),
            replyZrange.getReplyDoublePointer(), "ZRANGEBYSCORE %s %d %d", sortedSetKey, sStartScore, endScore);
    }
    else
    {
        zrangeResult = FnVCCB_RedisCommandGetReply(connection, REDIS_GET_ACTIVE_IDX(connection),
            replyZrange.getReplyDoublePointer(), "ZRANGEBYSCORE %s %d +inf", sortedSetKey, sStartScore);
    }
    // ZRANGEBYSCORE not count
    connection.info->redisCommandCount[REDIS_GET_ACTIVE_IDX(connection)]--;

    if (zrangeResult == ERROR)
    {
        VCCB_PRINTF("[Redis DB][Audit] (ZRANGEBYSCORE %s %d %d) is failed!\n", sortedSetKey, sStartScore, endScore);
        return ERROR;
    }
    VCCB_REDIS_PRINT_DATA("[Redis DB][Audit] [replyZrange->elements] elements:%lu\n", replyZrange.getReply()->elements);

    sStartScore += MAX_EXT_DB_AUDIT_CALL_COUNT;
    if (sStartScore >= (int32_t)MAX_CALL_COUNT_PER_DISTCODE)
    {
        sStartScore = 0;
        callGroupIdx++;
        if (callGroupIdx == firstDefaultDistCode + 20)
        {
            callGroupIdx = firstDefaultDistCode;
        }
    }

    for (int zrangeIdx = 0; zrangeIdx < (int)replyZrange.getReply()->elements; zrangeIdx++)
    {
        redisReply *zrangeReplyElement = replyZrange.getReply()->element[zrangeIdx];
        VALID_E_POINT_CHECK_ERROR(zrangeReplyElement);
        int callIdInKey = FnVCCB_GetIdFromZrange((char *)zrangeReplyElement->str, (int)zrangeReplyElement->len);
        if (callIdInKey >= (int)MAX_CALL_COUNT_PER_DISTCODE || callIdInKey < 0)
        {
            VCCB_PRINTF("[Redis DB][Audit] Invalid value, callIdInKey(%d)\n", callIdInKey);
            continue;
        }

        VCCB_REDIS_PRINT_DATA("[Redis DB][Audit] [for replyZrange->zrangeReplyElement[%d]] EXISTS %s\n", zrangeIdx,
            zrangeReplyElement->str);
        VccbRedisReply reply;
        if (ERROR == FnVCCB_RedisCommandGetReply(connection, REDIS_GET_ACTIVE_IDX(connection),
                         reply.getReplyDoublePointer(), "EXISTS %s", zrangeReplyElement->str))
        {
            VCCB_PRINTF("[Redis DB][Audit] (EXISTS %s) is failed!\n", zrangeReplyElement->str);
            return ERROR;
        }
        if (reply.getReply()->integer == FALSE)  // not exist
        {
            VCCB_REDIS_PRINT_DATA("[Redis DB][Audit] callId:%d is not exist in callSet\n", callIdInKey);

            VCCB_REDIS_PRINT_DATA("[Redis DB][Audit] ZREM %s %s\n", sortedSetKey, zrangeReplyElement->str);
            if (ERROR == FnVCCB_RedisCommandWithoutReply(
                             connection, REDIS_BOTH_SIDE, "ZREM %s %s", sortedSetKey, zrangeReplyElement->str))
            {
                VCCB_PRINTF("[Redis DB][Audit] (ZREM %s %s) is Failed\n", sortedSetKey, zrangeReplyElement->str);
                return ERROR;
            }
        }
        else
        {
            uint32_t vccbCallId = ENV->distCodeInfo[callGroupIdx].distCodeToVccbCallId[callIdInKey];
            if (FnVCCB_IsCallInUse(vccbCallId) == FALSE)
            {
                VCCB_REDIS_PRINT_DATA("[Redis DB][Audit] callId:%d is exist but the call is not in use\n", vccbCallId);

                VCCB_REDIS_PRINT_DATA("[Redis DB][Audit] ZREM %s %s\n", sortedSetKey, zrangeReplyElement->str);
                if (ERROR == FnVCCB_RedisCommandWithoutReply(
                                 connection, REDIS_BOTH_SIDE, "ZREM %s %s", sortedSetKey, zrangeReplyElement->str))
                {
                    VCCB_PRINTF("[Redis DB][Audit] (ZREM %s %s) is Failed\n", sortedSetKey, zrangeReplyElement->str);
                    return ERROR;
                }

                VCCB_REDIS_PRINT_DATA("[Redis DB][Audit] DEL %s\n", zrangeReplyElement->str);

                if (ERROR ==
                    FnVCCB_RedisCommandWithoutReply(connection, REDIS_BOTH_SIDE, "DEL %s", zrangeReplyElement->str))
                {
                    VCCB_PRINTF("[Redis DB][Delete] (DEL %s) is Failed\n", zrangeReplyElement->str);
                    return ERROR;
                }
            }
        }
    }
    return GOOD;
}

int FnVCCB_RestoreDbFromRedis(VccbRedisConnection_type &connection)
{
    AUTO_TRACE_FUNC;

    VccbEnvInfo_type *pEnv = ENV;
    VccbCfgInfo_type *pCfg = CFG;
    VccbDbgInfo_type *pDbg = DBG;
    FnVCCB_InitRedisContext(connection);

    if (pDbg->flag.extDbTestFlag)
    {
        VCCB_PRINTF("[%s]Skip Redis DB Connection for test\n", __func__);
    }
    if (GOOD == FnVCCB_ConnectRedisDb(connection))
    {
        FnVCCB_ClearRedisAccessAlarm();
        VCCB_PRINTF("[%s]ExtDb is Connected!\n", __func__);
    }
    else
    {
        FnVCCB_CountRedisAccessFail();
        connection.info->firstConnectionFailFlag = TRUE;
        VCCB_PRINTF("[%s]redisConnect Error!! skip Restore, set firstConnectionFailFlag = %d\n",
                __func__, connection.info->firstConnectionFailFlag);
        return ERROR;
    }

    if (!pDbg->flag.extDbTestFlag)
    {
        // 1. VCCB buildTime is SAME (VCCB refork, POD Restart, POD Recreation)
        if (GOOD == FnVCCB_ReadExtDbCfgBuildTime(connection, pCfg->vm.unitId))
        {
            int lastUpdateTimeDiff = FnVCCB_RedisGetDiffLastUpdateTime(connection);
            if (lastUpdateTimeDiff == ERROR || lastUpdateTimeDiff >= REDIS_DB_EXPIRE_TIME)
            {
                VCCB_PRINTF("[%s][ExtDb] Delete all Gnb, Cell, Cfg data(lastUpdateTimeDiff:%d)\n", __func__,
                    lastUpdateTimeDiff);

                if (ERROR == FnVCCB_RedisDeleteAllGnbOfMyCpp(connection, REDIS_BOTH_SIDE))
                {
                    VCCB_PRINTF("[%s][ExtDb] FnVCCB_RedisDeleteAllGnbOfMyCpp Error\n", __func__);
                }

                if (ERROR == FnVCCB_RedisDeleteAllCellOfMyCpp(connection, REDIS_BOTH_SIDE))
                {
                    VCCB_PRINTF("[%s][ExtDb] FnVCCB_RedisDeleteAllCellOfMyCpp Error\n", __func__);
                }

                if (ERROR == FnVCCB_RedisDeleteAllCfgOfMyCpp(connection, REDIS_BOTH_SIDE))
                {
                    VCCB_PRINTF("[%s][ExtDb] FnVCCB_RedisDeleteAllCfgOfMyCpp Error\n", __func__);
                }
                return GOOD;
            }
            if (ERROR == FnVCCB_ReadExtDb(connection))
            {
                VCCB_PRINTF("[%s][ExtDb] FnVCCB_ReadExtDb Error\n", __func__);
                // abnormal case recovery
                if (ERROR == FnVCCB_RedisDeleteAllDataOfMyCpp(connection, REDIS_BOTH_SIDE))
                {
                    VCCB_PRINTF("[%s][ExtDb] FnVCCB_RedisDeleteAllDataOfMyCpp Error\n", __func__);
                }
                VCCB_EXIT(EXIT_HAS_DB_CONN_FAIL);  // for internal DB initialization
            }
            pEnv->isRestoredFromRedisDB = TRUE;
            pEnv->shouldSkipReadingCellInfo = TRUE;
        }
        // 2. VCCB buildTime is DIFFERENT or NOT Exist (PKG Update, Scale-out)
        else
        {
            if (ERROR == FnVCCB_RedisDeleteAllDataOfMyCpp(connection, REDIS_BOTH_SIDE))
            {
                VCCB_PRINTF("[%s][ExtDb] FnVCCB_RedisDeleteAllDataOfMyCpp Error\n", __func__);
                VCCB_EXIT(EXIT_HAS_DB_CONN_FAIL);  // for internal DB initialization
            }
        }
    }
    return GOOD;
}

callInfo_type *FnVCCB_GetOrAllocCallInfo(const uint32_t cuCpUeId)
{
    AUTO_TRACE_FUNC;
    uint16_t distCode = VCCB_GET_DIST_CODE(cuCpUeId);
    uint32_t distCallId = VCCB_GET_DIST_CALL_ID(cuCpUeId);
    VCCB_CHECK_E_RANGE_AND_NULL(distCode, (uint16_t)MAX_DIST_CODE_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_NULL(distCallId, (int)MAX_CALL_COUNT_PER_DISTCODE);
    VccbEnvInfo_type *pEnv = ENV;
    const uint32_t vccbCallId = pEnv->distCodeInfo[distCode].distCodeToVccbCallId[distCallId];
    if (TRUE == FnVCCB_IsCallInUse(vccbCallId))
    {
        return NULL;
    }
    else
    {
        return FnVCCB_AllocateCallWithoutActivation(cuCpUeId);
    }
}

int FnVCCB_ReadCallInfoFromRedisReply(VccbRedisReply &reply, callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    enumVccbCallState_type callState = MAX_VCCB_STATE;
    for (int element_Idx = 0; element_Idx < (int)reply.getReply()->elements; element_Idx++)
    {
        redisReply *replyElement = reply.getReply()->element[element_Idx];
        VALID_E_POINT_CHECK_ERROR(replyElement);

        VCCB_REDIS_PRINT_DATA("[Redis DB][%s] replyElement[%d].type:%d len:%lu elements:%lu\n", __func__, element_Idx,
            replyElement->type, replyElement->len, replyElement->elements);
        VCCB_REDIS_PRINT_DATA("[Redis DB][%s] %u) %s\n", __func__, element_Idx, replyElement->str);

        if (!strncasecmp(replyElement->str, "callInfo", replyElement->len) && replyElement->len != 0)
        {
            element_Idx++;
            replyElement = reply.getReply()->element[element_Idx];
            VALID_E_POINT_CHECK_ERROR(replyElement);

            int decomp_bytes =
                LZ4_decompress_safe((char *)replyElement->str, (char *)ptCi, (int32_t)replyElement->len, sizeof(callInfo_type));
            if (decomp_bytes < 0)
            {
                VCCB_PRINTF("[Redis DB][Read] LZ4_decompress_safe(callInfo) ERROR(%d)\n", decomp_bytes);
                return ERROR;
            }
        }
        else if (!strncasecmp(replyElement->str, "state", replyElement->len) && replyElement->len != 0)
        {
            element_Idx++;
            replyElement = reply.getReply()->element[element_Idx];
            VALID_E_POINT_CHECK_ERROR(replyElement);
            callState = static_cast<enumVccbCallState_type>(util::str::vccb_strtol<int>(replyElement->str));
        }
        else
        {
            VCCB_REDIS_PRINT_DATA("[Redis DB][Read] LZ4_decompress Fail (Wrong input : %s)\n", replyElement->str);
            return ERROR;
        }
    }
    if (callState == MAX_VCCB_STATE)
    {
        VCCB_PRINTF("[Redis DB][Read] Invalid callState!!\n");
        return ERROR;
    }
    ptCi->state = callState;
    return GOOD;
}

int FnVCCB_RestoreCall(VccbRedisConnection_type &connection, std::vector<uint16_t> &distCodeList)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(connection.context);
    VALID_E_POINT_CHECK_ERROR(connection.info);

    int totalRestoredCall = 0;
    std::vector<uint32_t> cuCpUeIdListToRelease;

    for (auto &distCode : distCodeList)
    {
        if (ERROR == FnVCCB_ReadExtDbCfgBuildTime(connection, distCode / MAX_ACTIVE_CPC_PER_SYS))
        {
            VCCB_PRINT_ERROR("[Redis DB][%s] The buildtime of the distCode(%d) is different.\n", __func__, distCode);
            continue;
        }
        int restoreSuccCount = 0;
        char sortedSetKey[REDIS_KEY_LEN];
        FnVCCB_RedisMakeCallSortedSetKey(sortedSetKey, distCode);
        VCCB_REDIS_PRINT_DATA("[Redis DB][%s] ZRANGE %s 0 -1\n", __func__, sortedSetKey);

        VccbRedisReply replyZrange;
        if (ERROR == FnVCCB_RedisCommandGetReply(connection, REDIS_GET_ACTIVE_IDX(connection),
                         replyZrange.getReplyDoublePointer(), "ZRANGE %s 0 -1", sortedSetKey))
        {
            VCCB_PRINTF("[Redis DB][%s] (ZRANGE %s 0 -1) is Failed\n", __func__, sortedSetKey);
            return ERROR;
        }

        int callIdInKey[VCCB_MAX_PIPELINED_DB_CMD];
        memset(callIdInKey, 0, sizeof(callIdInKey));
        int &pipelinedCmd = connection.info->appendedCommandCount[connection.info->readContextIdx];
        if (pipelinedCmd >= VCCB_MAX_PIPELINED_DB_CMD || pipelinedCmd < 0)
        {
            VCCB_PRINTF("[Redis DB][Read] Invalid value, pipelinedCmd(%d)\n", pipelinedCmd);
            return ERROR;
        }

        VCCB_REDIS_PRINT_DATA("[Redis DB][%s] replyZrange->type:%d len:%lu elements:%lu\n", __func__,
            replyZrange.getReply()->type, replyZrange.getReply()->len, replyZrange.getReply()->elements);

        for (int zrangeIdx = 0; zrangeIdx < (int)replyZrange.getReply()->elements; zrangeIdx++)
        {
            redisReply *replyElement = replyZrange.getReply()->element[zrangeIdx];
            VALID_E_POINT_CHECK_BREAK(replyElement);

            // callId is obtained from the key obtained through Zrange and backed up to callIdInKey.
            callIdInKey[pipelinedCmd] = FnVCCB_GetIdFromZrange((char *)replyElement->str, (int)replyElement->len);
            if (callIdInKey[pipelinedCmd] < 0)
            {
                VCCB_PRINTF(
                    "[Redis DB][Read] Invalid value, callIdInKey[%d](%d)\n", pipelinedCmd, callIdInKey[pipelinedCmd]);
                return ERROR;
            }

            // appends a command that reads the value of the key obtained by zrange to the pipeline.
            VCCB_REDIS_PRINT_DATA("[Redis DB][Read] Append HGETALL %s \n", replyElement->str);
            if (ERROR ==
                FnVCCB_RedisAppend(connection, REDIS_GET_ACTIVE_IDX(connection), "HGETALL %s", replyElement->str))
            {
                VCCB_PRINTF("[Redis DB][Read] (HGETALL %s) is failed!!\n", replyElement->str);
                return ERROR;
            }

            // if the appended commands are accumulated as much as VCCB_MAX_PIPELINED_DB_CMD, execute them.
            if ((pipelinedCmd == VCCB_MAX_PIPELINED_DB_CMD) ||
                ((zrangeIdx + 1) == (int)replyZrange.getReply()->elements))
            {
                for (int pipelinedCmdIdx = 0; pipelinedCmdIdx < pipelinedCmd; pipelinedCmdIdx++)
                {
                    VccbRedisReply reply;
                    if (redisGetReply(connection.context[connection.info->readContextIdx],
                            (void **)(reply.getReplyDoublePointer())) != REDIS_OK ||
                        reply.getReply() == NULL)
                    {
                        VCCB_PRINTF("[Redis DB][%s] redisGetReply err[%s]\n", __func__,
                            connection.context[connection.info->readContextIdx]->errstr);
                        continue;
                    }

                    const uint32_t cuCpUeId = (uint32_t)VCCB_GET_CUCP_UE_ID(distCode, callIdInKey[pipelinedCmdIdx]);
                    callInfo_type *ptCi = FnVCCB_GetOrAllocCallInfo(cuCpUeId);
                    VALID_E_POINT_CHECK_CONTINUE(ptCi);

                    const uint32_t vccbCallIdBackup = ptCi->callId;
                    if (ERROR == FnVCCB_ReadCallInfoFromRedisReply(reply, ptCi))
                    {
                        VCCB_PRINT_ERROR("FnVCCB_ReadCallInfoFromRedisReply ERROR in %s\n", __func__);
                        // The failed ptCi during FnVCCB_ReadCallInfoFromRedisReply is unreliable. callId must be
                        // written over
                        ptCi->callId = vccbCallIdBackup;
                        ptCi->usage = CI_use;
                        ptCi->gnbCuUeId = cuCpUeId;
                        if (FnVCCB_FreeCall(ptCi, false) != GOOD)
                        {
                            VCCB_PRINT_ERROR("FnVCCB_FreeCall(%u) ERROR in %s\n", ptCi->callId, __func__);
                        }
                        continue;
                    }

                    if (ERROR == FnVCCB_ConvertCallInfoToMatchCurrentCPP(ptCi, vccbCallIdBackup))
                    {
                        if (FnVCCB_FreeCall(ptCi, false) != GOOD)
                        {
                            VCCB_PRINT_ERROR("FnVCCB_FreeCall(%u) ERROR in %s\n", ptCi->callId, __func__);
                        }
                        continue;
                    }

#ifndef IPC_TEST
                    if (RscCall::recoveryDB(ptCi) != GOOD)
                    {
                        cuCpUeIdListToRelease.push_back(ptCi->gnbCuUeId);
                    }
#endif

                    restoreSuccCount++;
                }
                pipelinedCmd = 0;
            }
        }
        VCCB_PRINT_ERROR("[Redis DB][%s] call recovered successfully from distCode[%d] : (%d/%d)\n", __func__, distCode,
            restoreSuccCount, (int)replyZrange.getReply()->elements);
        totalRestoredCall += restoreSuccCount;
    }
    if (cuCpUeIdListToRelease.size() > 0)
    {
        FnVCCB_SendInternalCallRelease(cuCpUeIdListToRelease, INTERNAL_CALL_RELEASE_CAUSE_CNF_CALL_TAKEOVER);
    }
    return totalRestoredCall;
}

#endif  //__CNF__
