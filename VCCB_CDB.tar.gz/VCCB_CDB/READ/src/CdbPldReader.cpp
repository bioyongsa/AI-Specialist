/**
 * @file       CdbPldReader.cpp
 * @brief      PLD read
 */

/*----------------------------------------------------------------------------
 * Define    :    Include Header Files
 * ---------------------------------------------------------------------------
 */
#include "CdbPldReader.h"
#include "CdbPldBuffer.hpp"
#include "CdbPldSubscription.h"
#include "CdbDalSubscription.h"
#include "CdbFoo.h"
#include "ComInclude.h"
#include "ComLibUtility.h"
#include "FeatSwVersion.h"
#include "FeatCommon.h"
#include "FeatLbm.hpp"
#include "MsgVccbSend.h"
#include "MsgNrRrcStore.h"

#include "DbiInterface.h"

#define VCCB_MAX_USER_PLD                  ((int)(sizeof(gPldInfo_) / sizeof(gPldInfo_[0])) - 1)
#define VCCB_GET_REL_BUFF_SIZE(_rtRelInfo) _rtRelInfo.numOfTuple *_rtRelInfo.tupleSize

// To print logs only when initial PLD read
#define VCCB_PRINTF_PLD_INITIAL_READ(fmt, args...) \
    {                                              \
        if (CFG->pld.isInitialReadDone == FALSE)   \
        {                                          \
            VCCB_COMMON_LOG_PRINTF(fmt, ##args);   \
        }                                          \
    }

// pldInfo_type gPldInfo[] =
static pldInfo_type gPldInfo_[] =  // [SAM_GV_IMPROVEMENT]
    {{REL_DU_STATUS_ID, MAX_TUPLE_REL_DU_STATUS_ID, "REL_DU_STATUS_ID", VCCB_getRel_PLDDuStatus,
        VCCB_getTuple_PLDDuStatus, MANDATORY, FALSE, TRUE, TRUE, TRUE},
    {REL_AUPF_STATUS_ID, MAX_TUPLE_REL_AUPF_STATUS_ID, "REL_AUPF_STATUS_ID", VCCB_getRel_PLDAupfStatus,
        VCCB_getTuple_PLDAupfStatus, MANDATORY, FALSE, TRUE, TRUE, TRUE},
    {REL_AUPF_PLMN_INFO_ID, MAX_TUPLE_REL_AUPF_STATUS_ID, "REL_AUPF_PLMN_INFO_ID", VCCB_getRel_PLDAupfPlmnInfo,
        VCCB_getTuple_PLDAupfPlmnInfo, MANDATORY, FALSE, TRUE, TRUE, TRUE},
    {REL_AMF_STATUS_ID, MAX_TUPLE_REL_AMF_STATUS_ID, "REL_AMF_STATUS_ID", VCCB_getRel_PLDAmfStatus,
        VCCB_getTuple_PLDAmfStatus, MANDATORY, TRUE, TRUE, TRUE, TRUE},
    {REL_AMF_PLMN_INFO_ID, MAX_TUPLE_REL_AMF_STATUS_ID, "REL_AMF_PLMN_INFO_ID", VCCB_getRel_PLDAmfPlmnInfo,
        VCCB_getTuple_PLDAmfPlmnInfo, MANDATORY, TRUE, TRUE, TRUE, TRUE},
    {REL_AMF_TNL_STATUS_ID, MAX_TUPLE_REL_AMF_TNL_STATUS_ID, "REL_AMF_TNL_STATUS_ID", VCCB_getRel_PLDAmfTnlStatus,
        VCCB_getTuple_PLDAmfTnlStatus, MANDATORY, TRUE, TRUE, TRUE, TRUE},
    {REL_AMF_TNL_SCTP_STATE_ID, MAX_TUPLE_REL_AMF_TNL_SCTP_STATE_ID, "REL_AMF_TNL_SCTP_STATE_ID",
        VCCB_getRel_PLDAmfTnlSctpState, VCCB_getTuple_PLDAmfTnlSctpState, MANDATORY, TRUE, TRUE, TRUE, TRUE},
    {REL_CELL_STATUS_ID, MAX_TUPLE_REL_CELL_STATUS_ID, "REL_CELL_STATUS_ID", VCCB_getRel_PLDCellStatus,
        VCCB_getTuple_PLDCellStatus, MANDATORY, TRUE, TRUE, TRUE, TRUE}, 
    {REL_NR_CELL_PLMN_INFO_ID, MAX_TUPLE_REL_CELL_STATUS_ID, "REL_NR_CELL_PLMN_INFO_ID", VCCB_getRel_PLDNrCellPlmnInfo,
        VCCB_getTuple_PLDNrCellPlmnInfo, MANDATORY, TRUE, TRUE, TRUE, TRUE},
    {REL_GNB_BARRING_INFO_ID, MAX_TUPLE_REL_GNB_BARRING_INFO_ID, "REL_GNB_BARRING_INFO_ID",
        VCCB_getRel_PLDGnbBarringInfo, VCCB_getTuple_PLDGnbBarringInfo, MANDATORY, TRUE, TRUE, TRUE, TRUE},
    {REL_CPU_UTIL_EXT_ID, MAX_TUPLE_REL_CPU_UTIL_EXT_ID, "REL_CPU_UTIL_EXT_ID", VCCB_getRel_PLDCpuUtilExt,
        VCCB_getTuple_PLDCpuUtilExt, MANDATORY, TRUE, TRUE, TRUE, TRUE},
    {REL_CELL_TRACE_STATUS_ID, MAX_TUPLE_REL_CELL_STATUS_ID, "REL_CELL_TRACE_STATUS_ID",
        VCCB_getRel_PLDCellTraceStatus, VCCB_getTuple_PLDCellTraceStatus, MANDATORY, TRUE, TRUE, TRUE, TRUE},
    {REL_TRACE_STATUS_ID, MAX_TUPLE_REL_TRACE_STATUS_ID, "REL_TRACE_STATUS_ID", VCCB_getRel_PLDTraceStatus,
        VCCB_getTuple_PLDTraceStatus, MANDATORY, TRUE, TRUE, TRUE, TRUE},
    {REL_IMSI_TRACE_ID, MAX_TUPLE_REL_IMSI_TRACE_ID, "REL_IMSI_TRACE_ID", VCCB_getRel_PLDImsiTrace,
        VCCB_getTuple_PLDImsiTrace, OPTIONAL, TRUE, TRUE, TRUE, TRUE},
    {REL_CPC_USAGE_STATE_ID, MAX_CPC_PER_SYS, "REL_CPC_USAGE_STATE_ID", VCCB_getRel_PLDCpcUsageState,
        VCCB_getTuple_PLDCpcUsageState, MANDATORY, FALSE, FALSE, TRUE, TRUE},
    {REL_EUTRA_CELL_INFO_ID, MAX_TUPLE_REL_EUTRA_CELL_INFO_ID, "REL_EUTRA_CELL_INFO_ID",
        VCCB_getRel_PLDEutraCellInfo, VCCB_getTuple_PLDEutraCellInfo, MANDATORY, TRUE, TRUE, TRUE, TRUE},
    {REL_XN_GNB_STATUS_ID, MAX_TUPLE_REL_XN_GNB_STATUS_ID, "REL_XN_GNB_STATUS_ID", VCCB_getRel_PLDXnGnbStatus,
        VCCB_getTuple_PLDXnGnbStatus, OPTIONAL, TRUE, TRUE, TRUE, TRUE},
    {REL_GNB_XN_TAI_INFO_ID, MAX_TUPLE_REL_GNB_XN_TAI_INFO_ID, "REL_GNB_XN_TAI_INFO_ID",
        VCCB_getRel_PLDGnbXnTaiInfo, VCCB_getTuple_PLDGnbXnTaiInfo, OPTIONAL, TRUE, TRUE, TRUE, TRUE},
    {REL_GNB_CALL_STATE_ID, MAX_TUPLE_REL_GNB_CALL_STATE_ID, "REL_GNB_CALL_STATE_ID", VCCB_getRel_PLDGnbCallState,
        VCCB_getTuple_PLDGnbCallState, MANDATORY, TRUE, TRUE, TRUE, TRUE},
    {REL_CBRS_CELL_CARRIER_INFO_ID, MAX_TUPLE_REL_CELL_STATUS_ID, "REL_CBRS_CELL_CARRIER_INFO_ID",
        VCCB_getRel_PLDCbrsCellCarrierInfo, VCCB_getTuple_PLDCbrsCellCarrierInfo, MANDATORY, TRUE, TRUE, TRUE, TRUE},
    {REL_SON_OP_STATUS_ID, MAX_TUPLE_REL_CELL_STATUS_ID, "REL_SON_OP_STATE_ID",
        VCCB_getRel_PLDSonOpState, VCCB_getTuple_PLDSonOpState, OPTIONAL, TRUE, TRUE, TRUE, TRUE},
    {0, 0, "", NULL, NULL, 0, FALSE, FALSE, FALSE, FALSE}};
    
pldInfo_type *GetgPldInfo_() { return gPldInfo_; }                       // [SAM_GV_IMPROVEMENT]

static int FnVCCB_GetRelationInfo(int relId, relationInfo *pRelInfo)
{
    AUTO_TRACE_FUNC;

    int result = GOOD;
    int retryCount = 0;

    memset(pRelInfo, 0, sizeof(relationInfo));

    if (CFG->pld.isInitialReadDone == FALSE)  // Initial Read
    {
        for (retryCount = 0; retryCount < NRCALL_MAX_PLD_RETRY; retryCount++)
        {
            result = dbiGetRelationInfo(relId, pRelInfo);
            VCCB_CHECK_RTCODE_SLEEP(result, "dbiGetRelationInfo", retryCount);
        }
    }
    else
    {
        result = dbiGetRelationInfo(relId, pRelInfo);
    }

    if (result < 0)
    {
        VCCB_PRINTF("[%s] relId(%d) dbiGetRelationInfo ERROR!(%d)\n", __func__, relId, result);
    }

    return result;
}

static int FnVCCB_GetRelation(int relId, char *buf, uint32_t bufSize, uint32_t tupleSize)
{
    AUTO_TRACE_FUNC;

    int result = GOOD;
    int retryCount = 0;

    if (CFG->pld.isInitialReadDone == FALSE)  // Initial Read
    {
        for (retryCount = 0; retryCount < NRCALL_MAX_PLD_RETRY; retryCount++)
        {
            result = dbiGetRelation(relId, buf, bufSize, tupleSize);
            VCCB_CHECK_RTCODE_SLEEP(result, "dbiGetRelation", retryCount);
        }
    }
    else
    {
        result = dbiGetRelation(relId, buf, bufSize, tupleSize);
    }

    if (result < 0)
    {
        VCCB_PRINTF("[%s] relId(%d) dbiGetRelation ERROR!(%d)\n", __func__, relId, result);
    }

    return result;
}

// SUCCESS: return gnbNum (0 <= gnbNum < MAX_GNB_PER_SYS)
// FAIL:    return UNKNOWN_GNB_NUM (0xFF)
uint16_t FnVCCB_GetGnbNumFromIdOrIdx(uint32_t gnbId, uint16_t gnbIdx)
{
    uint16_t gnbNum = UNKNOWN_GNB_NUM;

#ifdef __NVGNB__
    (void)gnbId; // remove compile warning
    if (gnbIdx < MAX_GNB_PER_SYS)
    {
        gnbNum = gnbIdx;
    }
#else
    if (TRUE == FOO.VF_MultipleOperatorRanSupport)
    {
        if (gnbIdx < MAX_GNB_PER_SYS)
        {
            gnbNum = gnbIdx;
        }
    }
    else 
    {
        if (GOOD != VLIB_GetGnbNumFromId(&gnbNum, gnbId))
        {
            gnbNum = UNKNOWN_GNB_NUM;
        }
    }
#endif

    return gnbNum;
}


/* #define MACRO_GET_RELATION(__type, __relId, __buf, __bufSize, __relInfo) \ */


#define MACRO_GET_RELATION(__type, __relId, __relInfo)                                                              \
{                                                                                                                   \
    uint32_t bufSize;                                                                                               \
    const int maxRetryCount = (CFG->pld.isInitialReadDone == FALSE)?NRCALL_MAX_PLD_RETRY:1;                         \
    for (int retryCount = 0; retryCount < maxRetryCount; retryCount++)                                              \
    {                                                                                                               \
        if (retryCount != 0)                                                                                        \
        {                                                                                                           \
            thsSleep(VCCB_SLEEP_WAIT_TIME);                                                                         \
            result = dbiGetRelationInfo(__relId, &__relInfo);                                                       \
            if (result < 0)                                                                                         \
            {                                                                                                       \
                VCCB_ONE_LOG_PRINT(LC_INFO, 0, "FnVCCB_GetRelationInfo Failed (%d), id=%d\n", result, retryCount);  \
                VCCB_PRINTF("[%s] relId(0x%x) dbiGetRelationInfo ERROR!(%d/%d)\n", __func__, __relId, result, retryCount );\
                continue; \
            }                                                                                                       \
            numOfTuple = MIN(__relInfo.numOfMaxTuple, __relInfo.numOfTuple);                                        \
            VCCB_PRINTF("[%s] numOfTuple=%d [retryCount=%d]\n", __func__, numOfTuple, retryCount );                 \
            if (numOfTuple == 0) break;                                                                             \
        }                                                                                                           \
\
        bufSize = numOfTuple * __relInfo.tupleSize;                                                                 \
        buf = (__type *)pldBuffer.allocBuffer(bufSize);                                                             \
        VALID_E_POINT_CHECK_ERROR(buf);                                                                             \
\
        result = dbiGetRelation(__relId, reinterpret_cast<char *>(buf), bufSize, __relInfo.tupleSize);              \
        if (result < 0)                                                                                             \
        {                                                                                                           \
            VCCB_ONE_LOG_PRINT(LC_INFO, 0, "dbiGetRelation Failed (%d), id=%d\n", result, retryCount);              \
            VCCB_PRINTF("[%s] relId(0x%x) dbiGetRelation ERROR!(%d/%d)\n", __func__, __relId, result, retryCount);  \
\
            if (CFG->pld.isInitialReadDone == TRUE) return (int16_t)result;                                         \
        }                                                                                                           \
        else break;                                                                                                 \
    }                                                                                                               \
    if (result < 0) return (int16_t)result;                                                                         \
}

int16_t VCCB_getRel_PLDDuStatus(void)
{
    AUTO_TRACE_FUNC;

    int result;
    uint32_t loop = 0;
    relationInfo relInfo;
    VccbPldBuffer pldBuffer;

    result = FnVCCB_GetRelationInfo(REL_DU_STATUS_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    VccbGnbInfo_type *const pGnbInfo = GNBINFO;
    bool updateFlag[MAX_GNB_PER_SYS][MAX_GNB_DU_PER_GNB_CU_CP] = {false};

    uint32_t numOfTuple = MIN(relInfo.numOfMaxTuple, relInfo.numOfTuple);
    if (numOfTuple > 0)
    {
        PLDDuStatus *buf;

        MACRO_GET_RELATION(PLDDuStatus, REL_DU_STATUS_ID, relInfo);

        for (loop = 0; loop < numOfTuple; loop++)
        {
            if (buf[loop].status != EQUIP) continue;

            uint16_t gnbIdx = buf[loop].gNBIdx;
            int endPointIdx = buf[loop].endPointIdx;

            VCCB_CHECK_E_RANGE_AND_CONTINUE(endPointIdx, MAX_GNB_DU_PER_GNB_CU_CP);

            uint16_t gnbNum = FnVCCB_GetGnbNumFromIdOrIdx(buf[loop].gNBId, gnbIdx);
            if (MAX_GNB_PER_SYS <= gnbNum)
            {
                VCCB_PRINTF("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gNBId, gnbIdx);
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gNBId, gnbIdx);
                continue;
            }

            gnbDuInfo_type *const pGnbDu = &pGnbInfo[gnbNum].gnbDu[endPointIdx];

            VCCB_PRINTF_PLD_INITIAL_READ(
                "[%4d] (%d:%d) gnbNum:%d status:%d ovld:%d gNBId:%d bdType:%d duId:%lu\n, rrcVer:[%d.%d.%d]", loop, gnbIdx,
                endPointIdx, gnbNum, buf[loop].status, buf[loop].overloadStatus, buf[loop].gNBId, buf[loop].boardType,
                buf[loop].duId, buf[loop].rrcVersion[0], buf[loop].rrcVersion[1], buf[loop].rrcVersion[2]);

            if (buf[loop].overloadStatus)
            {
                pGnbDu->overloadStatus = ci_overload;
            }
            else
            {
                pGnbDu->overloadStatus = ci_not_overload;
            }

            pGnbDu->pldStatus = buf[loop].status;
            pGnbDu->gnbDuId = buf[loop].duId;
            pGnbDu->boardType = (uint8_t)buf[loop].boardType;
            pGnbDu->gNBIdx = gnbIdx;
            pGnbDu->rrcVersion[0] = buf[loop].rrcVersion[0];
            pGnbDu->rrcVersion[1] = buf[loop].rrcVersion[1];
            pGnbDu->rrcVersion[2] = buf[loop].rrcVersion[2];
            VLIB_CreateSwVersionFromPld(buf[loop].swVersion, &pGnbDu->swVersion);

            updateFlag[gnbNum][endPointIdx] = true;
        }
    }

    // In case buf[loop].status = N_EQUIP, pld parameters except key value are unreliable.
    // Hence, initialization of VCCB DB shall proceeds like below.
    for (int gnbNum = 0; gnbNum < MAX_GNB_PER_SYS; gnbNum++)
    {
        for(int endPointIdx = 0; endPointIdx < MAX_GNB_DU_PER_GNB_CU_CP; endPointIdx++)
        {
            if (updateFlag[gnbNum][endPointIdx] == false)
            {
                // Initialize VCCB DB
                gnbDuInfo_type *const pGnbDu = &pGnbInfo[gnbNum].gnbDu[endPointIdx];

                pGnbDu->overloadStatus = ci_not_overload;
                pGnbDu->boardType = BoardType_GCB;
                pGnbDu->rrcVersion[0] = 0;
                pGnbDu->rrcVersion[1] = 0;
                pGnbDu->rrcVersion[2] = 0;
                pGnbDu->gNBIdx = 0xFFFF;
                
                VLIB_InitSwVersion(pGnbDu->swVersion);

                pGnbDu->pldStatus = N_EQUIP;
            }
        }
    }

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}

void FnVCCB_InitAupfStautsInfo_PLDAupfStatus(AupfStatusInfo_type *pAupf)
{
    VALID_E_POINT_CHECK_VOID(pAupf);

    pAupf->gNBIdx           = 0;
    pAupf->endPointIdx      = 0;
    pAupf->status           = 0;
    pAupf->serviceState     = 0;
    pAupf->gNBId            = 0;
    pAupf->aupfId           = 0;
    pAupf->overloadStatus   = 0;
    pAupf->capacity         = 0;
    pAupf->cnSupport        = 0;
    
    VLIB_InitSwVersion(pAupf->swVersion);
}

void FnVCCB_SetAupfStautsInfo_PLDAupfStatus(AupfStatusInfo_type *pAupf, PLDAupfStatus *pPLDAupfStatus)
{
    VALID_E_POINT_CHECK_VOID(pAupf);
    VALID_E_POINT_CHECK_VOID(pPLDAupfStatus);

    pAupf->gNBIdx           = pPLDAupfStatus->gNBIdx;
    pAupf->endPointIdx      = pPLDAupfStatus->endPointIdx;
    pAupf->status           = pPLDAupfStatus->status;
    pAupf->serviceState     = pPLDAupfStatus->serviceState;
    pAupf->gNBId            = pPLDAupfStatus->gNBId;
    pAupf->aupfId           = pPLDAupfStatus->aupfId;
    pAupf->overloadStatus   = pPLDAupfStatus->overloadStatus;
    pAupf->capacity         = pPLDAupfStatus->capacity;
    pAupf->cnSupport        = pPLDAupfStatus->cnSupport;    

    VLIB_CreateSwVersionFromPld(pPLDAupfStatus->swVersion, &pAupf->swVersion);   
}

// Initialize item related with PLMN only
// related with Index(ex.gnbIdx ..) will be initialized in FnVCCB_InitAupfStautsInfo_PLDAupfStatus
void FnVCCB_InitAupfStautsInfo_PLDAupfPlmnInfo(AupfStatusInfo_type *pAupf)
{
    VALID_E_POINT_CHECK_VOID(pAupf);

    uint32_t loop = 0;
    uint32_t loop2 = 0;

    pAupf->statusPlmn = 0;
    pAupf->plmnCnt = 0;
    for (loop = 0; loop < MAX_E1_SUPPORTED_PLMN; loop++)
    {
        pAupf->plmn[loop] = 0;

        pAupf->eutranQciPerPlmnCnt[loop] = 0;
        for (loop2 = 0; loop2 < MAX_EUTRAN_QCI_PER_PLMN; loop2++) 
        {
            pAupf->eutranQci[loop][loop2] = 0;
        }

        pAupf->supportedSnssaiGrpCntPerPlmn[loop] = 0;
        for (loop2 = 0; loop2 < MAX_SNSSAI_GRP_PER_PLMN_AUPF; loop2++)
        {
            pAupf->supportedSnssaiGrp[loop][loop2] = 0;
            pAupf->supportedSnssaiGrpLength[loop][loop2] = 0;
        }
    }
}

void FnVCCB_SetAupfStautsInfo_PLDAupfPlmnInfo(AupfStatusInfo_type *pAupf, PLDAupfPlmnInfo *pPLDAupfPlmnInfo)
{
    VALID_E_POINT_CHECK_VOID(pAupf);
    VALID_E_POINT_CHECK_VOID(pPLDAupfPlmnInfo);

    uint32_t loop = 0;
    uint32_t loop2 = 0;

    pAupf->statusPlmn = pPLDAupfPlmnInfo->status;
    pAupf->plmnCnt = pPLDAupfPlmnInfo->supportedPlmnCnt;
    for (loop = 0; loop < MIN(pAupf->plmnCnt, MAX_E1_SUPPORTED_PLMN); loop++)
    {
        pAupf->plmn[loop] = pPLDAupfPlmnInfo->supportedPlmn[loop];;

        pAupf->eutranQciPerPlmnCnt[loop] = pPLDAupfPlmnInfo->eutranQciPerPlmnCnt[loop];
        for (loop2 = 0; loop2 < MIN(pAupf->eutranQciPerPlmnCnt[loop], MAX_EUTRAN_QCI_PER_PLMN); loop2++) 
        {
            pAupf->eutranQci[loop][loop2] = pPLDAupfPlmnInfo->eutranQci[loop][loop2];
        }

        pAupf->supportedSnssaiGrpCntPerPlmn[loop] = pPLDAupfPlmnInfo->supportedSnssaiGrpCntPerPlmn[loop];
        for (loop2 = 0; loop2 < MIN(pAupf->supportedSnssaiGrpCntPerPlmn[loop], MAX_SNSSAI_GRP_PER_PLMN_AUPF); loop2++)
        {
            pAupf->supportedSnssaiGrp[loop][loop2]       = pPLDAupfPlmnInfo->supportedSnssaiGrp[loop][loop2];
            pAupf->supportedSnssaiGrpLength[loop][loop2] = pPLDAupfPlmnInfo->supportedSnssaiGrpLength[loop][loop2];
        }
    }
}


int16_t VCCB_getRel_PLDAupfStatus(void)
{
    AUTO_TRACE_FUNC;

    int result;
    uint32_t loop = 0;
    relationInfo relInfo;
    VccbPldBuffer pldBuffer;

    result = FnVCCB_GetRelationInfo(REL_AUPF_STATUS_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    VccbGnbInfo_type *const pGnbInfo = GNBINFO;
    bool updateFlag[MAX_GNB_PER_SYS][MAX_GNB_CU_UP_PER_GNB_CU_CP] = {false};

    uint32_t numOfTuple = MIN(relInfo.numOfMaxTuple, relInfo.numOfTuple);
    if (numOfTuple > 0)
    {
        PLDAupfStatus *buf;

        MACRO_GET_RELATION(PLDAupfStatus, REL_AUPF_STATUS_ID, relInfo);

        for (loop = 0; loop < numOfTuple; loop++)
        {
            if (buf[loop].status != EQUIP) continue;

            uint16_t gnbIdx = buf[loop].gNBIdx;
            int endPointIdx = buf[loop].endPointIdx;
            VCCB_CHECK_E_RANGE_AND_CONTINUE(endPointIdx, MAX_GNB_CU_UP_PER_GNB_CU_CP);

            uint16_t gnbNum = FnVCCB_GetGnbNumFromIdOrIdx(buf[loop].gNBId, gnbIdx);
            if (MAX_GNB_PER_SYS <= gnbNum)
            {
                VCCB_PRINTF("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gNBId, gnbIdx);
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gNBId, gnbIdx);
                continue;
            }

            VCCB_PRINTF_PLD_INITIAL_READ("[%4d] (%d:%d) gnbNum:%d status:%d gNBId:%d aupfId:%lu ovld:%d capa:%d\n", loop,
                gnbIdx, endPointIdx, gnbNum, buf[loop].status, buf[loop].gNBId, buf[loop].aupfId, buf[loop].overloadStatus,
                buf[loop].capacity);

            FnVCCB_SetAupfStautsInfo_PLDAupfStatus(&pGnbInfo[gnbNum].aupf.gnbCuUp[endPointIdx], &buf[loop]);
            
            updateFlag[gnbNum][endPointIdx] = true;
        }
    }

    // In case buf[loop].status = N_EQUIP, pld parameters except key value are unreliable.
    // Hence, initialization of VCCB DB shall proceeds like below.
    for (int gnbNum = 0; gnbNum < MAX_GNB_PER_SYS; gnbNum++)
    {
        for(int endPointIdx = 0; endPointIdx < MAX_GNB_CU_UP_PER_GNB_CU_CP; endPointIdx++)
        {
            if (updateFlag[gnbNum][endPointIdx] == false)
            {
                // Initialize VCCB DB
                // AupfStatusInfo_type *const pGnbCuUp = &pGnbInfo[gnbNum].aupf.gnbCuUp[endPointIdx];
                // memset(pGnbCuUp, 0, sizeof(AupfStatusInfo_type));
                // VLIB_InitSwVersion(pGnbCuUp->swVersion);
                FnVCCB_InitAupfStautsInfo_PLDAupfStatus(&pGnbInfo[gnbNum].aupf.gnbCuUp[endPointIdx]);
            }
        }
    }

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}

int16_t VCCB_getRel_PLDAmfStatus(void)
{
    AUTO_TRACE_FUNC;

    int result;
    uint32_t loop = 0;
    relationInfo relInfo;
    VccbPldBuffer pldBuffer;

    result = FnVCCB_GetRelationInfo(REL_AMF_STATUS_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    VccbCfgInfo_type *pCfg = CFG;
    bool updateFlag[MAX_GNB_PER_SYS][MAX_AMF_PER_GNB_CU_CP] = {false};

    uint32_t numOfTuple = MIN(relInfo.numOfMaxTuple, relInfo.numOfTuple);
    if (numOfTuple > 0)
    {
        PLDAmfStatus *buf;

        MACRO_GET_RELATION(PLDAmfStatus, REL_AMF_STATUS_ID, relInfo);

        for (loop = 0; loop < numOfTuple; loop++)
        {
            if (buf[loop].status != EQUIP) continue;

            uint16_t gnbIdx = buf[loop].gNBIdx;
            int endPointIdx = buf[loop].endPointIdx;

            VCCB_CHECK_E_RANGE_AND_CONTINUE(endPointIdx, MAX_AMF_PER_GNB_CU_CP);

            uint16_t gnbNum = FnVCCB_GetGnbNumFromIdOrIdx(buf[loop].gNBId, gnbIdx);
            if (MAX_GNB_PER_SYS <= gnbNum)
            {
                VCCB_PRINTF("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d, gnbIdx:%d)\n", __func__, buf[loop].gNBId, gnbIdx);
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d, gnbIdx:%d)\n", __func__, buf[loop].gNBId, gnbIdx);
                continue;
            }

            // TODO: Print VCCB_PRINTF_PLD_INITIAL_READ

            memcpy(&pCfg->amf.pldAmfStatus[gnbNum][endPointIdx], &buf[loop], sizeof(PLDAmfStatus));

            updateFlag[gnbNum][endPointIdx] = true;
        }
    }

    // In case buf[loop].status = N_EQUIP, pld parameters except key value are unreliable.
    // Hence, initialization of VCCB DB shall proceeds like below.
    for (int gnbNum = 0; gnbNum < MAX_GNB_PER_SYS; gnbNum++)
    {
        for(int endPointIdx = 0; endPointIdx < MAX_AMF_PER_GNB_CU_CP; endPointIdx++)
        {
            if (updateFlag[gnbNum][endPointIdx] == false)
            {
                memset(&pCfg->amf.pldAmfStatus[gnbNum][endPointIdx], 0, sizeof(PLDAmfStatus));
            }
        }
    }

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}

int16_t VCCB_getRel_PLDAmfTnlStatus(void)
{
    AUTO_TRACE_FUNC;

    int result;
    uint32_t loop = 0;
    relationInfo relInfo;
    VccbPldBuffer pldBuffer;

    result = FnVCCB_GetRelationInfo(REL_AMF_TNL_STATUS_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    VccbCfgInfo_type *pCfg = CFG;
    bool updateFlag[MAX_GNB_PER_SYS][MAX_AMF_PER_GNB_CU_CP][MAX_TNL_PER_AMF] = {false};

    uint32_t numOfTuple = MIN(relInfo.numOfMaxTuple, relInfo.numOfTuple);
    if (numOfTuple > 0)
    {
        PLDAmfTnlStatus *buf;

        MACRO_GET_RELATION(PLDAmfTnlStatus, REL_AMF_TNL_STATUS_ID, relInfo);

        for (loop = 0; loop < numOfTuple; loop++)
        {
            if (buf[loop].status != EQUIP) continue;

            uint16_t gnbIdx = buf[loop].gNBIdx;
            int endPointIdx = buf[loop].endPointIdx;
            int tnlIdx = buf[loop].tnlIdx;

            VCCB_CHECK_E_RANGE_AND_CONTINUE(endPointIdx, MAX_AMF_PER_GNB_CU_CP);
            VCCB_CHECK_E_RANGE_AND_CONTINUE(tnlIdx, MAX_TNL_PER_AMF);

            uint16_t gnbNum = FnVCCB_GetGnbNumFromIdOrIdx(buf[loop].gNBId, gnbIdx);
            if (MAX_GNB_PER_SYS <= gnbNum)
            {
                VCCB_PRINTF("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gNBId, gnbIdx);
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gNBId, gnbIdx);
                continue;
            }

            // TODO: Print VCCB_PRINTF_PLD_INITIAL_READ

            memcpy(&pCfg->amf.pldAmfTnlStatus[gnbNum][endPointIdx][tnlIdx], &buf[loop], sizeof(PLDAmfTnlStatus));

            updateFlag[gnbNum][endPointIdx][tnlIdx] = true;
        }
    }

    // In case buf[loop].status = N_EQUIP, pld parameters except key value are unreliable.
    // Hence, initialization of VCCB DB shall proceeds like below.
    for (int gnbNum = 0; gnbNum < MAX_GNB_PER_SYS; gnbNum++)
    {
        for(int endPointIdx = 0; endPointIdx < MAX_AMF_PER_GNB_CU_CP; endPointIdx++)
        {
            for (int tnlIdx = 0; tnlIdx < MAX_TNL_PER_AMF; tnlIdx++)
            {
                if (updateFlag[gnbNum][endPointIdx][tnlIdx] == false)
                {
                    memset(&pCfg->amf.pldAmfTnlStatus[gnbNum][endPointIdx][tnlIdx], 0, sizeof(PLDAmfTnlStatus));
                }
            }
        }
    }

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}

void VCCB_store_PLDCellStatus_MeasObject(VccbCellInfo_type *pCell, PLDCellStatus *pPld)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pCell);
    VALID_E_POINT_CHECK_VOID(pPld);
    measurementObjectNRBaseDb_type *pObj = &pCell->measurementsData.measurementObjectsNRDb[INTRAFREQ_OBJECT_IDX].base;

    pObj->usage = CI_use;

    uint32_t loop = 0;

    // ssbArfcn
    pObj->ssbFrequency = pPld->ssbArfcn;

    // subcarrier-spacing
    pObj->ssbSubcarrierSpacing = (enumSubcarrierSpacing)pPld->ssbSubcarrierSpacing;

    // SMTC1
    // - periodicity
    pObj->smtc1.periodicityAndOffset.periodicity = (enumSmtcPeriodicity)pPld->smtc1Periodicity;
    // - offset
    pObj->smtc1.periodicityAndOffset.offset = pPld->smtc1Offset;
    // - duration
    pObj->smtc1.duration = pPld->smtc1Duration;

    pCell->intraGnbNbrInfo.smtcStatus = CI_use;
    pCell->intraGnbNbrInfo.smtc1.periodicityAndOffset.periodicity = pObj->smtc1.periodicityAndOffset.periodicity;
    pCell->intraGnbNbrInfo.smtc1.periodicityAndOffset.offset = pObj->smtc1.periodicityAndOffset.offset;
    pCell->intraGnbNbrInfo.smtc1.duration = pObj->smtc1.duration;

    // - ssb-ToMeasure
    pCell->intraGnbNbrInfo.ssbMeasurementConfiguration.usage = pPld->ssbToMeasure_usage;
    pCell->intraGnbNbrInfo.ssbMeasurementConfiguration.ssbToMeasure = pPld->ssbToMeasure;
    pCell->intraGnbNbrInfo.ssbMeasurementConfiguration.ssbValue = pPld->bitmap;
    if (CI_use == pCell->intraGnbNbrInfo.ssbMeasurementConfiguration.usage &&
        0 == pCell->intraGnbNbrInfo.ssbMeasurementConfiguration.ssbValue)
    {
        // If "ssb-toMeasure" is configured and bitmap is 0, UE does not measure blocks -> Cell is non-SSB
        pCell->isCellSSB = FALSE;
    }
    else
    {
        // If "ssb-toMeasure" is not configured, UE measures on all SS blocks -> Cell is SSB
        // If "ssb-toMeasure" is configured and bitmap is different to 0, UE measures corresponding blocks where bits
        // are set to 1 -> Cell is SSB
        pCell->isCellSSB = TRUE;
    }

    // (list)freq-band-indicator-nr-type
    uint8_t nrOfBands = 0;
    for (loop = 0; loop < MAX_NR_CELL_FREQ_BAND_LIST; loop++)
    {
        if (0 == pPld->nRFrequencyBand[loop]) continue;

        pObj->freqBandIndicatorDbList.freqBand[nrOfBands].usage = CI_use;
        pObj->freqBandIndicatorDbList.freqBand[nrOfBands].band = pPld->nRFrequencyBand[loop];
        nrOfBands++;
    }

    pObj->saCapable           = TRUE;
    pObj->redcapAccessAllowed = TRUE;

    return;
}

int16_t VCCB_getRel_PLDAmfTnlSctpState(void)
{
    AUTO_TRACE_FUNC;

    int result;
    uint32_t loop = 0;
    relationInfo relInfo;
    VccbPldBuffer pldBuffer;

    result = FnVCCB_GetRelationInfo(REL_AMF_TNL_SCTP_STATE_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    VccbCfgInfo_type *pCfg = CFG;
    bool updateFlag[MAX_GNB_PER_SYS][MAX_AMF_PER_GNB_CU_CP][MAX_TNL_PER_AMF] = {false};

    uint32_t numOfTuple = MIN(relInfo.numOfMaxTuple, relInfo.numOfTuple);
    if (numOfTuple > 0)
    {
        PLDAmfTnlSctpState *buf;

        MACRO_GET_RELATION(PLDAmfTnlSctpState, REL_AMF_TNL_SCTP_STATE_ID, relInfo);

        for (loop = 0; loop < numOfTuple; loop++)
        {
            int gnbNum = 0xFFFF;
            int gnbIdx = buf[loop].gNBIdx;
            int endPointIdx = buf[loop].endPointIdx;
            int tnlIdx = buf[loop].tnlIdx;

            VCCB_CHECK_E_RANGE_AND_CONTINUE(endPointIdx, MAX_AMF_PER_GNB_CU_CP);
            VCCB_CHECK_E_RANGE_AND_CONTINUE(tnlIdx, MAX_TNL_PER_AMF);

            // Get gnbNum from pldAmfTnlStatus since these two PLDs are correlated.
            uint16_t i;
            for (i = 0; i < MAX_GNB_PER_SYS; i++)
            {
                if (gnbIdx == (int)pCfg->amf.pldAmfTnlStatus[i][endPointIdx][tnlIdx].gNBIdx &&
                    EQUIP == pCfg->amf.pldAmfTnlStatus[i][endPointIdx][tnlIdx].status)
                {
                    gnbNum = i;
                    break;
                }
            }
            if (gnbNum == 0xFFFF) continue;

            // TODO: Print VCCB_PRINTF_PLD_INITIAL_READ

            memcpy(&pCfg->amf.pldAmfTnlSctpState[gnbNum][endPointIdx][tnlIdx], &buf[loop], sizeof(PLDAmfTnlSctpState));

            updateFlag[gnbNum][endPointIdx][tnlIdx] = true;
        }
    }

    // In case buf[loop].status = N_EQUIP, pld parameters except key value are unreliable.
    // Hence, initialization of VCCB DB shall proceeds like below.
    for (int gnbNum = 0; gnbNum < MAX_GNB_PER_SYS; gnbNum++)
    {
        for(int endPointIdx = 0; endPointIdx < MAX_AMF_PER_GNB_CU_CP; endPointIdx++)
        {
            for (int tnlIdx = 0; tnlIdx < MAX_TNL_PER_AMF; tnlIdx++)
            {
                if (updateFlag[gnbNum][endPointIdx][tnlIdx] == false)
                {
                    memset(&pCfg->amf.pldAmfTnlSctpState[gnbNum][endPointIdx][tnlIdx], 0, sizeof(PLDAmfTnlSctpState));
                }
            }
        }
    }

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}

/**
 * @brief Save plmnLongId in callInfo::ueInfo.servedPlmn.longId. The index matched in gNB Plmn Info is stored in
 * callInfo::ueInfo.servedPlmnIdxInGnPlmn.
 * @param [in]  plmnLongId : callInfo DB
 */

void VLIB_Store_PLDCellPlmnIndexInfo(VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pCell);

    uint16_t loop = 0, plmnIdx = 0, numOfPlmn = 0;
    uint16_t findFlag = 0, addCount = 0;

    cellPlmnIndexInfo_type tmpCellPlmnIndexInfo[MAX_PLMN_INDEX];
    uint32_t addPlmnList[MAX_PLMN_INDEX];

    // 0. Initialize temp Buffer.
    memset(tmpCellPlmnIndexInfo, 0, sizeof(tmpCellPlmnIndexInfo));

    // 1. Copy Current DB to Temp DB.
    for (plmnIdx = 0; plmnIdx < MAX_PLMN_INDEX; plmnIdx++)
    {
        tmpCellPlmnIndexInfo[plmnIdx].status = pCell->cellPlmnIndexInfo[plmnIdx].status;
        tmpCellPlmnIndexInfo[plmnIdx].servedPlmn = pCell->cellPlmnIndexInfo[plmnIdx].servedPlmn;
    }

    // 2. Check Exist Plmn with New Plmn Info
    numOfPlmn = MIN(pCell->cellPlmn.numOfPLMN, MAX_PLMN_INDEX);
    for (loop = 0; loop < numOfPlmn; loop++)
    {
        findFlag = 0;
        for (plmnIdx = 0; plmnIdx < MAX_PLMN_INDEX; plmnIdx++)
        {
            if (tmpCellPlmnIndexInfo[plmnIdx].status != EQUIP) continue;

            if (tmpCellPlmnIndexInfo[plmnIdx].servedPlmn == pCell->cellPlmn.servedPlmn[loop])
            {
                findFlag++;
                // Mark it in updateStatus.
                tmpCellPlmnIndexInfo[plmnIdx].updateStatus++;
            }
        }

        // If No Match, Marked it in addPlmnList
        if (findFlag == 0)
        {
            if (addCount < MAX_PLMN_INDEX)
            {
                addPlmnList[addCount] = pCell->cellPlmn.servedPlmn[loop];
                addCount++;
            }
        }
    }

    // 3. Check Delete DB.
    for (plmnIdx = 0; plmnIdx < MAX_PLMN_INDEX; plmnIdx++)
    {
        if (tmpCellPlmnIndexInfo[plmnIdx].updateStatus == 0)  // 0 means No Match with new PLMN Info.
        {
            tmpCellPlmnIndexInfo[plmnIdx].status = N_EQUIP;
        }
    }

    // 4. Add Plmn from addPlmnList to tmpCellPlmnIndexInfo.
    numOfPlmn = MIN(addCount, MAX_PLMN_INDEX);
    for (loop = 0; loop < numOfPlmn; loop++)
    {
        findFlag = 0;
        for (plmnIdx = 0; plmnIdx < MAX_PLMN_INDEX; plmnIdx++)
        {
            if (tmpCellPlmnIndexInfo[plmnIdx].status == EQUIP) continue;

            tmpCellPlmnIndexInfo[plmnIdx].status = EQUIP;
            tmpCellPlmnIndexInfo[plmnIdx].servedPlmn = addPlmnList[loop];
            findFlag++;
            break;
        }

        if (findFlag == 0)
        {
            // Error Print.. No Space for New Plmn
            VCCB_PRINTF("[%s] No Space for New Plmn!!! (cellId=%d)\n", __func__, pCell->cellIdentity);
        }
    }

    // 5. Copy tempDB to cellPlmnIndexInfo
    for (plmnIdx = 0; plmnIdx < MAX_PLMN_INDEX; plmnIdx++)
    {
        pCell->cellPlmnIndexInfo[plmnIdx] = tmpCellPlmnIndexInfo[plmnIdx];
    }

}

/**
 * @brief           Store SIB1 to cell from user PLD (0x0077f007)
 */
void FnVCCB_PLDCellStatus_Sib1(PLDCellStatus *ptrBuf, const uint16_t gnbNum, const CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptrBuf);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    if (0 == ptrBuf->sib1Size)  // init case
    {
        memset(&pCell->sib1, 0, sizeof(pCell->sib1));
    }
    else if (MAX_F1_DU_SYSTEM_INFO_SIB1 > ptrBuf->sib1Size)
    {
        int16_t result = VRIL_StoreNRRRC_SIB1(gnbNum, cellNum, ptrBuf->sib1, ptrBuf->sib1Size);
        if (GOOD != result)
        {
            VCCB_PRINTF("[%s] VRIL_StoreNRRRC_SIB1 ERROR!!! (%d)\n", __func__, result);
        }
        memcpy(pCell->sib1.sib1Data, ptrBuf->sib1, ptrBuf->sib1Size);
    }
    pCell->sib1.sib1Size = ptrBuf->sib1Size;
}

/**
 * @brief MCO SpCell LB Cache: Initialise/reset cell data
 */
void FnVCCB_InitMcoLbCellCache(const CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    VccbNonBackupCellInfo_type &rCellInfo = EXTERNAL_INFO.cell[cellNum];

    ///// MUTEX LOCK /////
    MUTEX_LOCK(&rCellInfo.mcoLbCacheMutex);
    /////////////////////

    for (McoLbCacheResultEntry_type &rEntry : rCellInfo.mcoLbCacheEntries)
    {
        // set unused
        rEntry.eligibleCcIdxBitmsk = 0;
    }

    ///// MUTEX UNLOCK /////
    MUTEX_UNLOCK(&rCellInfo.mcoLbCacheMutex);
    ////////////////////////    
}

/**
 * @brief MCO SpCell LB Cache: Init cache after cell add/dell/serving state change
 */
void FnVCCB_InitMcoLbDuCellsCache(const uint16_t gnbNum, const uint16_t endPointF1Idx)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    if (VCOM_getSystemType() == e_VCCB_NVGNB)
    {
        // Cell per DU = Cell per gNb
        for (CellNum_type cellNum = 0; cellNum < MAX_CELL_NUM_VCCB; cellNum++)
        {
            const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
            if (EQUIP != pCell->status)
            {
                continue;
            }
            if (gnbNum != pCell->gnbNum)
            {
                continue;
            }
            FnVCCB_InitMcoLbCellCache(cellNum);
        }
    }
    else
    {
        VCCB_CHECK_E_RANGE_AND_VOID(endPointF1Idx, MAX_GNB_DU_PER_GNB_CU_CP);
        const VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
        VALID_E_POINT_CHECK_VOID(pGnb->gnbDu);
        const gnbDuInfo_type *pGnbDu = &pGnb->gnbDu[endPointF1Idx];
        for (uint16_t loop = 0; loop < MAX_CELL_PER_DU; loop++)
        {
            if (EQUIP != pGnbDu->cellInDu[loop].status)
            {
                continue;
            }
            FnVCCB_InitMcoLbCellCache(pGnbDu->cellInDu[loop].cellNum);
        }
    }
}

/**
 * @brief           Get cell status parameters from user PLD (0x0077f007)
 */
void VLIB_GetPldCellStatusParam(PLDCellStatus *ptrBuf, uint16_t gnbNum, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptrBuf);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *pGnb = &GNBINFO[gnbNum];
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    uint8_t prevServiceState;
    uint8_t prevPldState;
    uint32_t loop = 0;
    int result;

/*
    uint8_t numOfPlmn = 0;
    uint8_t numOfSnssaiPerPlmn = 0;
    uint32_t iNssai = 0;
*/

    // STORE PARAMETERS FROM USER PLD

    pCell->cellIdentity = ptrBuf->cellId;
    pCell->gnbNum = (uint8_t)gnbNum;

    // BTSP #TS2590I2 (VZW 25A)
    pCell->gnbId = CFG->gnbNumInfo.gnbIdFromNum[gnbNum % MAX_GNB_PER_SYS].gnbId;

    pCell->intraGnbNbrInfo.cellId = (uint16_t)pCell->cellIdentity;

    pCell->pldCellIdx = ptrBuf->cellIdx;
    if(pCell->pldCellIdx < MAX_CELL_PER_VNF)
    {
        mappingCellNumAndPldCellIdx[pCell->pldCellIdx] = cellNum;
    }
    pCell->cgi.ci = VLIB_GnbIdCellId2NrCellId(&pGnb->globalGnbId.gnbId, (uint16_t)pCell->cellIdentity);
    pCell->intraGnbNbrInfo.globalGnbId = pGnb->globalGnbId;

    /* service-state */
    prevServiceState = pCell->serviceState;
    pCell->serviceState = ptrBuf->serviceState;

    /* nr-physical-cell-id */
    pCell->phyCellId = ptrBuf->phyCellId;
    pCell->intraGnbNbrInfo.nrPci = pCell->phyCellId;

    /* nr-scs-dl,ul */
    pCell->nrScsDl = ptrBuf->nRSCSDl;
    pCell->intraGnbNbrInfo.nrScsDl = (uint8_t)pCell->nrScsDl;
    pCell->nrScsUl = ptrBuf->nRSCSUl;
    pCell->intraGnbNbrInfo.nrScsUl = (uint8_t)pCell->nrScsUl;

    /* nrb-dl,ul */
    pCell->nRbDl = ptrBuf->nRNRBDl;
    pCell->intraGnbNbrInfo.nrbDl = pCell->nRbDl;
    pCell->nRbUl = ptrBuf->nRNRBUl;
    pCell->intraGnbNbrInfo.nrbUl = pCell->nRbUl;

    pCell->intraGnbNbrInfo.bandwidthDl = static_cast<uint16_t>(VLIB_NrbScs2Bw((enumNrSystemBandwidth_type)pCell->nRbDl, (enumNrSubCarrierSpacing_type)pCell->nrScsDl));
    pCell->intraGnbNbrInfo.bandwidthUl = static_cast<uint16_t>(VLIB_NrbScs2Bw((enumNrSystemBandwidth_type)pCell->nRbUl, (enumNrSubCarrierSpacing_type)pCell->nrScsUl));

    /* nr-frequency-band-info */
    for (loop = 0; loop < MAX_NR_CELL_FREQ_BAND_LIST; loop++)
    {
        if (ptrBuf->nRFrequencyBand[loop] != 0 && ptrBuf->nRFrequencyBand[loop] < MAX_NUM_NR_BAND)  // initial value : 0
        {
            pCell->freqBandInfoList[loop].nRFrequencyBand = (unsigned)(ptrBuf->nRFrequencyBand[loop] & 0x7FFF); // cut to 15 bits
            pCell->freqBandInfoList[loop].status = EQUIP;
            pCell->intraGnbNbrInfo.freqBandInfoList[loop].nRFrequencyBand = (unsigned)(ptrBuf->nRFrequencyBand[loop] & 0x7FFF); // cut to 15 bits
            pCell->intraGnbNbrInfo.freqBandInfoList[loop].status = EQUIP;
        }
        else
        {
            pCell->freqBandInfoList[loop].nRFrequencyBand = 0;
            pCell->freqBandInfoList[loop].status = N_EQUIP;
            pCell->intraGnbNbrInfo.freqBandInfoList[loop].nRFrequencyBand = 0;
            pCell->intraGnbNbrInfo.freqBandInfoList[loop].status = N_EQUIP;
        }
    }

    /* nr-arfcn-dl,ul */
    pCell->nrArfcnDl = ptrBuf->arfcnDl;
    pCell->intraGnbNbrInfo.nrArfcnDl = pCell->nrArfcnDl;
    pCell->nrArfcnUl = ptrBuf->arfcnUl;
    pCell->intraGnbNbrInfo.cellDirection =
        (MAX_A6_NR_ARFCN == pCell->nrArfcnUl ? VCCB_CELLDIR_DLONLY : VCCB_CELLDIR_BOTH);
    pCell->intraGnbNbrInfo.nrArfcnUl = pCell->nrArfcnUl;
    if (pCell->profileDBInfo.pdcpProfileIdx == PDCP_PROFILE_INIT_VALUE)
    {
        if (pCell->nrArfcnDl >= MIN_A6_NR_ARFCN)
        {
            pCell->profileDBInfo.pdcpProfileIdx = PDCP_PROFILE_A6;
        }
        else
        {
            pCell->profileDBInfo.pdcpProfileIdx = PDCP_PROFILE_B6;
        }
    }

    /* ssb-arfcn */
    pCell->ssbArfcn = ptrBuf->ssbArfcn;
    pCell->intraGnbNbrInfo.ssbArfcn = pCell->ssbArfcn;

    /* ncd-ssb-config */
    pCell->ncdSsbInfo.usage = ptrBuf->ncdSsbPresent;
    pCell->ncdSsbInfo.ncdSsbArfcn = ptrBuf->ncdSsbArfcn;
    pCell->ncdSsbInfo.ncdSsbSubcarrierSpacing = ptrBuf->ncdSsbSubcarrierSpacing;
    pCell->ncdSsbInfo.ncdSmtc1.duration = ptrBuf->ncdSsbSmtc1Duration;
    pCell->ncdSsbInfo.ncdSmtc1.periodicityAndOffset.offset = ptrBuf->ncdSsbSmtc1Offset;
    pCell->ncdSsbInfo.ncdSmtc1.periodicityAndOffset.periodicity = ptrBuf->ncdSsbSmtc1Periodicity;

    /* tracking-area-code */
    pCell->tacStatus = ptrBuf->fiveGS_TAC_usage;
    pCell->intraGnbNbrInfo.fiveGsTacStatus = pCell->tacStatus;
    pCell->tac = ptrBuf->fiveGS_TAC;
    pCell->intraGnbNbrInfo.fiveGsTac = pCell->tac;

    /* configured-tac */
    pCell->configuredTacStatus = ptrBuf->configuredTac_usage;
    pCell->intraGnbNbrInfo.configuredTacStatus = pCell->configuredTacStatus;
    pCell->configuredTac = ptrBuf->configuredTac;
    pCell->intraGnbNbrInfo.configuredTac = (uint16_t)pCell->configuredTac;

    pCell->isCellHighSpeed = ptrBuf->highSpeed;

    /* switchingOffOngoing  */
    const uint8_t switchingOffOngoingPrev = pCell->switchingOffOngoing;
    // ODF_HO_21B TODO_TODO - Check processed on both active and standby.
    if (switchingOffOngoingPrev != ptrBuf->switchingOffOngoing)  // ODF_HO_21B
    {
        if (ptrBuf->switchingOffOngoing == TRUE)
        {
            VCCB_PRINTF("[ODF_HO] switchingOffOngoing on cell(%u)\n", pCell->cellIdentity);     // ODF_HO_21B
            VCCB_PRINT_CMD("[ODF_HO] switchingOffOngoing on cell(%u)\n", pCell->cellIdentity);  // ODF_HO_21B
            sTriggerOndemandHandoverByPLD = true;
        }
    }

    pCell->switchingOffOngoing = ptrBuf->switchingOffOngoing;
    // VCCB_PRINTF("[ODF_HO] switchingOffOngoing(%d) on cellNum(%d)\n", pCell->switchingOffOngoing, cellNum); //
    // ODF_HO_21B // odfho_dbg

    // configuredTacIndication CONFIG_TAC_IND_21C
    pCell->intraGnbNbrInfo.configuredTacIndication = ptrBuf->configuredTacIndication;
    pCell->configuredTacIndication = ptrBuf->configuredTacIndication;

    const uint8_t cellBarredPrev = pCell->mib.cellBarred;
    /* mib */
    if (ptrBuf->mibSize == 0)  // init case
    {
        pCell->mib.cellBarred = NRRRC_notBarred;
    }
    else if (ptrBuf->mibSize <= MAX_SI_MIB_LEN)
    {
        result = VRIL_StoreNRRRC_MIB(gnbNum, cellNum, ptrBuf->mib, ptrBuf->mibSize, ptrBuf->rrcVersion);
        if (result != GOOD)
        {
            VCCB_PRINTF("[%s] VRIL_StoreNRRRC_MIB ERROR!!! (%d)\n", __func__, result);
        }
    }

    // Check if state changed from notBarred to barred for SA&NSA cells for ongoing switchOff.
    // NSA UEs that were conditionally attached after switchOff will be released.
    const bool isEndcReleaseNeeded { NRRRC_notBarred == cellBarredPrev &&
                                     NRRRC_barred == pCell->mib.cellBarred &&
                                     VCCB_IsCellSaReady(*pCell) && 
                                     ((TRUE == pCell->switchingOffOngoing ) || 
                                     (TRUE == switchingOffOngoingPrev)) };
    if (isEndcReleaseNeeded)
    {
        VCCB_PRINTF("[%s] MIB cellBarred. EN-DC UEs release on cell(%u)\n", __func__, pCell->cellIdentity);
        FnVCCB_ReleaseAllCallsOnCellOfType(gnbNum, cellNum, INTERNAL_CALL_RELEASE_CAUSE_MIB_CELL_BARRED, E_CALLTYPE_NSA);
    }

    /* sib1 */
    FnVCCB_PLDCellStatus_Sib1(ptrBuf, gnbNum, cellNum);


#if 0
    /* served-plmn & S-NSSAI*/ // --> move to PLDNrCellPlmnInfo
    {
        /* intraGnbNbrInfo */
        for (loop = 0; loop < MAX_PLMN_INDEX; loop++) pCell->intraGnbNbrInfo.cellPlmnInfo[loop].shmStatus = N_EQUIP;

        numOfPlmn = MIN(ptrBuf->numOfPLMN, MAX_PLMN_INDEX);
        for (loop = 0; loop < numOfPlmn; loop++)
        {
            /* cellPlmn */
            pCell->cellPlmn.servedPlmn[loop] = ptrBuf->servedPlmn[loop];

            numOfSnssaiPerPlmn = (uint8_t)MIN(ptrBuf->supportedSnssaiPerPlmnCnt[loop], MAX_SNSSAI_PER_PLMN);
            for (iNssai = 0; iNssai < numOfSnssaiPerPlmn; iNssai++)
            {
                pCell->cellPlmn.supportedSnssai[loop][iNssai] = ptrBuf->supportedSnssai[loop][iNssai];
            }
            pCell->cellPlmn.numOfSnssaiPerPlmnCnt[loop] = numOfSnssaiPerPlmn;

            /* intraGnbNbrInfo */
            pCell->intraGnbNbrInfo.cellPlmnInfo[loop].shmStatus = EQUIP;
            pCell->intraGnbNbrInfo.cellPlmnInfo[loop].longId = pCell->cellPlmn.servedPlmn[loop];
            pCell->intraGnbNbrInfo.cellPlmnInfo[loop].plmnIndex = loop;
        }
        pCell->cellPlmn.numOfPLMN = numOfPlmn;
        VLIB_Store_PLDCellPlmnIndexInfo(pCell);
    }
#endif

    /* intra-frequency-meas-object */
    VCCB_store_PLDCellStatus_MeasObject(pCell, ptrBuf);

    /* ranac */
    pCell->ranacUsage = ptrBuf->ranac_usage;
    if (EQUIP == ptrBuf->ranac_usage)
    {
        pCell->ranac = ptrBuf->ranac;
    }

    pCell->duplexMode = ptrBuf->duplexMode;

    pCell->redcapBroadcastUsage = ptrBuf->redcapBroadcastInfo_usage;
    pCell->redcapBroadcastState = ptrBuf->redcapBroadcastInfo;

    if (pCell->redcapBroadcastUsage == TRUE) 
    {
        pCell->intraGnbNbrInfo.redcapBroadcastInfo = pCell->redcapBroadcastState;
    }
    else
    {
        pCell->intraGnbNbrInfo.redcapBroadcastInfo = -1;
    }

    pCell->numOfTotalSymbols = ptrBuf->numOfTotalSymbols;
    pCell->numOfUlSymbols = ptrBuf->numOfUlSymbols;
    pCell->numOfDlSymbols = ptrBuf->numOfDlSymbols;
    pCell->ulInterference = ptrBuf->interference;
    // this should be done after updating cell info to avoid multi thread issue
    prevPldState = pCell->pldState;
    pCell->pldState = EQUIP;
    pCell->intraGnbNbrInfo.status = pCell->pldState;
    pCell->intraGnbNbrInfo.deactivationIndication = VCCB_NBR_GNB_CELL_ACTIVATE;
    pCell->intraGnbNbrInfo.saAvailable = 0xFF; // set savailable all TRUE

#ifndef __NVGNB__
    /* mapping-end-point-f1-index */
    if (pCell->endPointF1Index != ptrBuf->endPointF1Index)
    {
        // Abnormal Case - if endPointF1Index is changed, delete it from the previous DU info
        if (pCell->endPointF1Index < MAX_GNB_DU_PER_GNB_CU_CP)
        {
            VLIB_DelCellFromCellListOfDu(gnbNum, cellNum, pCell->endPointF1Index, ENDPOINT_F1_CHANGED);
            FnVCCB_InitMcoLbDuCellsCache(gnbNum, pCell->endPointF1Index);
        }
    }
    const uint16_t prevEndPointF1Index = pCell->endPointF1Index;
    pCell->endPointF1Index = ptrBuf->endPointF1Index;
    if (pCell->endPointF1Index < MAX_GNB_DU_PER_GNB_CU_CP)
    {
        VLIB_AddCellToCellListOfDu(gnbNum, cellNum, pCell->endPointF1Index);
        if (prevEndPointF1Index != ptrBuf->endPointF1Index)
        {
            FnVCCB_InitMcoLbDuCellsCache(gnbNum, pCell->endPointF1Index);
        }
    }
#endif

    // When PLD equipped, Update the PLD's freq band Info to gNB Supported Band List.
    FnVCCB_UpdateGnbSupportBand_byCellPLDUpdate(cellNum, (uint8_t)gnbNum, ptrBuf, CELLPLD_UPDATE);

    VLIB_UpdatePcidUsedCellCount(gnbNum, cellNum, prevServiceState);  // check for pcid duplication
    if ((EQUIP != prevPldState) || (prevServiceState != pCell->serviceState))
    {
        FnVCCB_InitMcoLbDuCellsCache(gnbNum, pCell->endPointF1Index);
    }

    multipleBwInfo_type& multiBwInfo = pCell->multiBwInfo;
    multiBwInfo.multiBwCount = ptrBuf->multiBWCount;
    multiBwInfo.servingCellType = static_cast<enum_multiBwServingCellType_type>(ptrBuf->servingCellType);
    for (uint8_t idx = 0; idx < MIN(multiBwInfo.multiBwCount, MAX_NR_CHANNEL_BW_LIST); idx++)
    {
        multiBwInfo.ueType[idx] = static_cast<enum_multiBwUeType_type>(ptrBuf->ueType[idx]);
        multiBwInfo.carrierBandwidthDL[idx] = ptrBuf->carrierBandwidthDL[idx];
        multiBwInfo.offsetToCarrierDL[idx] = ptrBuf->offsetToCarrierDL[idx];
        multiBwInfo.carrierBandwidthUL[idx] = ptrBuf->carrierBandwidthUL[idx];
        multiBwInfo.offsetToCarrierUL[idx] = ptrBuf->offsetToCarrierUL[idx];
    }
}

/**
 * @brief           Initialize PLD cell status parameters
 * @param[in]       ptCi :   Call information / callInfo_type
 * @return          status : GOOD, ERROR / int16_t
 */
void FnVCCB_InitPldCellStatusParam(VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pCell);
    int loop;

    pCell->pldState = N_EQUIP;
    if (pCell->pldCellIdx < MAX_CELL_PER_VNF) mappingCellNumAndPldCellIdx[pCell->pldCellIdx] = MAX_CELL_NUM_VCCB;
    pCell->pldCellIdx = 0xFFFF;
    pCell->serviceState = CELL_OOS;  // access_s5gtype_f1_cell_out_of_service
#ifndef __NVGNB__
    pCell->endPointF1Index = MAX_GNB_DU_PER_GNB_CU_CP;
#endif
    pCell->phyCellId = 0;
    pCell->intraGnbNbrInfo.nrPci = pCell->phyCellId;
    pCell->nrScsDl = 0;
    pCell->nrScsUl = 0;
    pCell->nRbDl = 0;
    pCell->intraGnbNbrInfo.bandwidthDl = 0;
    pCell->intraGnbNbrInfo.bandwidthUl = 0;
    for (loop = 0; loop < MAX_FREQBAND_PER_CELL; loop++)
    {
        pCell->freqBandInfoList[loop].nRFrequencyBand = 0;  // initial value : 0
        pCell->freqBandInfoList[loop].status = N_EQUIP;
    }
    pCell->nrArfcnDl = 0;
    pCell->intraGnbNbrInfo.nrArfcnDl = pCell->nrArfcnDl;
    pCell->nrArfcnUl = 0;
    pCell->intraGnbNbrInfo.nrArfcnUl = pCell->nrArfcnUl;
    pCell->ssbArfcn = 0;
    pCell->intraGnbNbrInfo.ssbArfcn = pCell->ssbArfcn;
    pCell->ncdSsbInfo.usage = false;

    pCell->tacStatus = N_EQUIP;
    pCell->configuredTacStatus = N_EQUIP;

    pCell->ranacUsage = N_EQUIP;

    pCell->mib.cellBarred = NRRRC_notBarred;
    pCell->sib1.cellReservedForOtherUseFlag = FALSE;
    pCell->sib1.cellReservedForFutureUseFlag = FALSE;

    pCell->configuredTacIndication = CI_no_use;  // CONFIG_TAC_IND_21C

    pCell->duplexMode = 0;  // CI_DUPLEXTYPE_FDD

    pCell->redcapBroadcastUsage = 0;
    pCell->redcapBroadcastState = 0;
    pCell->intraGnbNbrInfo.deactivationIndication = VCCB_NBR_GNB_CELL_ACTIVATE;

    pCell->isCellHighSpeed = false;
}

void FnVCCB_ReleaseCell(VccbCellInfo_type *pCell, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pCell);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    pCell->intraGnbNbrInfo.status = pCell->status;

    memset(pCell->Nbr, 0, sizeof(pCell->Nbr));

    VDAL_VnbCall_DestroyTraceSession(pCell);
    VDAL_VnbCall_ClearCellMeasurementsData(&pCell->measurementsData);
    VDAL_VnbCall_ClearCellRFDSPData(&pCell->cellRfspBasedCtrl);
    VDAL_VnbCall_ClearColocCellEntries(cellNum);
    VDAL_VnbCall_ClearTsmConfig(cellNum);
    for (omFailedCellInfo_type &rOMFailedCell : pCell->omFailedCells)
    {
        rOMFailedCell.usage = CI_no_use;
    }

    pCell->lbCellResel[0].nrFreqItem.usage = CI_no_use;
    pCell->lbCellResel[0].nrFreqItem.measObjIdx = 0;

    pCell->gnbId = 0xFFFFFFFF;  // init
}

void FnVCCB_HandlePldCellDeleteNoti(const PLDCellStatus *ptrBuf, VccbCellInfo_type *pCell, uint16_t cellNum, enumCellStatusHistoryCause_type eventCause)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptrBuf);
    VALID_E_POINT_CHECK_VOID(pCell);

    uint16_t gnbNum = pCell->gnbNum;
    uint8_t prevServiceState;

    // prevent mismatch between VCCB-VNMB
    // ignore N_EQUIP noti from the pld tuple of which pld idx is different with EQUIP cell's.
    if (pCell->pldCellIdx != ptrBuf->cellIdx)
    {
        VCCB_PRINT_DATA(
            "[PLD] VCCB_getTuple_PLDCellStatus: N_EQUIP noti from pldCellIdx %d ignored!! for cellNum(%d) "
            "pldCellIdx(%d)\n",
            ptrBuf->cellIdx, cellNum, pCell->pldCellIdx);
        return;
    }

    if (pCell->status != EQUIP)  // [case 1] YANG and PLD states are both N_EQUIP: release cell
    {
        if (FnVCCB_FreeCell(gnbNum, cellNum, RELEASE_CELL_USERPLD) == ERROR)
        {
            VCCB_PRINT_ERROR("FnVCCB_FreeCell ERROR!! for cellNum(%d)\n", GNBINFO[gnbNum].env.cellNum[ptrBuf->cellId]);
            return;
        }

        FnVCCB_UpdateGnbSupportBand_byCellPLDUpdate(cellNum, (uint8_t)gnbNum, ptrBuf, CELLPLD_DELETE);

        pCell->pldState = N_EQUIP;
        if (pCell->endPointF1Index < MAX_GNB_DU_PER_GNB_CU_CP)
        {
            VLIB_DelCellFromCellListOfDu(gnbNum, cellNum, pCell->endPointF1Index, eventCause);
        }
        VLIB_UpdateCellStatusHistory(cellNum, eventCause);
        FnVCCB_ReleaseCell(pCell, cellNum);

        pCell->gnbNum = MAX_GNB_PER_SYS;  // init
        pCell->gnbId = 0xFFFFFFFF;  // init

        // check for pcid duplication
        prevServiceState = pCell->serviceState;
        pCell->serviceState = CELL_OOS;  // access_s5gtype_f1_cell_out_of_service
        VLIB_UpdatePcidUsedCellCount(gnbNum, cellNum, prevServiceState);
    }
    else  // [case 2] YANG status is EQUIP and PLD state is N_EQUIP: don't release cell
    {
        FnVCCB_UpdateGnbSupportBand_byCellPLDUpdate(cellNum, (uint8_t)gnbNum, ptrBuf, CELLPLD_DELETE);

        pCell->pldState = N_EQUIP;
        if (pCell->endPointF1Index < MAX_GNB_DU_PER_GNB_CU_CP)
        {
            VLIB_DelCellFromCellListOfDu(gnbNum, cellNum, pCell->endPointF1Index, eventCause);
        }
        VLIB_UpdateCellStatusHistory(cellNum, eventCause);
    }

    // initialize PLD parameter to prevent PLD parameter use
    FnVCCB_InitPldCellStatusParam(pCell);

    // Cell Delete Notification sync to StandBy 
    FnVCCB_BackupCellInfo(cellNum);

    return;
}


void FnVCCB_HandlePldCellIdChangeNoti(const PLDCellStatus *ptrBuf, const uint16_t gnbNum, enumCellStatusHistoryCause_type eventCause)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptrBuf);
    VCCB_CHECK_E_RANGE_AND_VOID(ptrBuf->cellId, MAX_CELL_IDENTITY);
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(ptrBuf->cellIdx, MAX_CELL_PER_VNF);

    uint16_t cellNum = GNBINFO[gnbNum].env.cellNum[ptrBuf->cellId];
    // this array provides information about which VCCB cellNum is connected with PLD cellIdx
    uint16_t cellNumDeletedFromPld = mappingCellNumAndPldCellIdx[ptrBuf->cellIdx];

    if (CFG->pld.isInitialReadDone == FALSE)  // only for AUDIT case
    {
        return;
    }

    if (cellNumDeletedFromPld >= MAX_CELL_NUM_VCCB)
    {
        return;
    }

    VccbCellInfo_type *pCell = &CELLINFO[cellNumDeletedFromPld];

    if (ptrBuf->status != EQUIP && pCell->pldState == EQUIP && cellNum == cellNumDeletedFromPld)
    {
        VCCB_PRINT_CRITICAL("cellNum(%d) is EQUIPPED in VCCB but deleted in PLD\n", cellNum);
        VCCB_PRINTF("cellNum(%d) is EQUIPPED in VCCB but deleted in PLD\n", cellNum);
        FnVCCB_HandlePldCellDeleteNoti(ptrBuf, pCell, cellNum, eventCause);
    }
    else if (ptrBuf->status == EQUIP && pCell->pldState == EQUIP && cellNum != cellNumDeletedFromPld)
    {
        if ((cellNum >= MAX_CELL_NUM_VCCB) &&
            (pCell->pldCellIdx == ptrBuf->cellIdx) &&
            (pCell->status == EQUIP) &&
            (pCell->gnbNum == gnbNum) && 
            (pCell->cellIdentity == ptrBuf->cellId))
        {
            VCCB_PRINT_CRITICAL("cellId(%d) is EQUIPPED in VCCB and reallocated into cellNum(%u)\n",
                pCell->cellIdentity, cellNumDeletedFromPld);
            VCCB_PRINTF("cellId(%d) is EQUIPPED in VCCB and reallocated into cellNum(%u)\n",
                pCell->cellIdentity, cellNumDeletedFromPld);

            VRRM_MUTEX_LOCK(&gCellNumAllocMtx);
            GNBINFO[gnbNum].env.cellNum[ptrBuf->cellId] = cellNumDeletedFromPld;
            VRRM_MUTEX_UNLOCK(&gCellNumAllocMtx);
#ifdef __CNF__
            FnVCCB_RedisUpdateGnbInfoFlagOn(gnbNum);
#else
            HAS_BACKUP_DATA_PER_GNB(gnbNum, VCCB_HAS_KEY_GNB_ENV_INFO_GNB_0, GNBINFO[gnbNum].env.cellNum, sizeof(GNBINFO[gnbNum].env.cellNum))
#endif
        }
        else
        {
            VCCB_PRINT_CRITICAL(
                "cell(id:%d/num:%d) is EQUIPPED in VCCB but PLD(cellIdx:%d) is changed to cell(id:%d num:%u)\n",
                pCell->cellIdentity, cellNumDeletedFromPld, ptrBuf->cellIdx, ptrBuf->cellId, cellNum);
            VCCB_PRINTF(
                "cell(id:%d/num:%d) is EQUIPPED in VCCB but PLD(cellIdx:%d) is changed to cell(id:%d num:%u)\n",
                pCell->cellIdentity, cellNumDeletedFromPld, ptrBuf->cellIdx, ptrBuf->cellId, cellNum);
            FnVCCB_HandlePldCellDeleteNoti(ptrBuf, pCell, cellNumDeletedFromPld, eventCause);
        }
    }

    return;
}


int16_t VCCB_getRel_PLDCellStatus(void)
{
    AUTO_TRACE_FUNC;
    STANDBY_RETURN_OK;

    int result;
    uint32_t loop = 0;
    uint16_t cellNum = MAX_CELL_NUM_VCCB;
    uint16_t gnbNum = 0;
    relationInfo relInfo;
    VccbPldBuffer pldBuffer;

    VccbCfgInfo_type *pCfg = CFG;

    result = FnVCCB_GetRelationInfo(REL_CELL_STATUS_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    uint32_t numOfTuple = MIN(relInfo.numOfMaxTuple, relInfo.numOfTuple);
    if (numOfTuple > 0)
    {
        PLDCellStatus *buf;

        MACRO_GET_RELATION(PLDCellStatus, REL_CELL_STATUS_ID, relInfo);

        if (pCfg->pld.isInitialReadDone == FALSE)  // Need to execute only at the first read time
        {
            INIT_FLAG_FALSE(sTriggerOndemandHandoverByPLD);  // ODF_HO_21B
            for (loop = 0; loop < MAX_CELL_PER_VNF; ++loop) mappingCellNumAndPldCellIdx[loop] = MAX_CELL_NUM_VCCB;
        }

        PLDCellStatus *ptrBuf = NULL;
        for (loop = 0; loop < numOfTuple; loop++)
        {
            ptrBuf = &buf[loop];

            gnbNum = FnVCCB_GetGnbNumFromIdOrIdx(ptrBuf->gNBId, ptrBuf->gnbNum);
            if (MAX_GNB_PER_SYS <= gnbNum)
            {
                if (ptrBuf->status == EQUIP)
                {
                    // If buf.status == EQUIP and gnbNum is out of range, something went wrong!
                    VCCB_PRINTF("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,pldGnbNum:%d)\n", __func__, ptrBuf->gNBId, ptrBuf->gnbNum);
                    VCCB_PRINT_ERROR("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,pldGnbNum:%d)\n", __func__, ptrBuf->gNBId, ptrBuf->gnbNum);
                }
                continue;
            }

            if (ptrBuf->status != EQUIP)
            {
                // in case PLD delete noti is missed
                if (VCCB_FLAG_ON == pCfg->pld.isInPldAuditProcessing)
                {
                    FnVCCB_HandlePldCellIdChangeNoti(ptrBuf, gnbNum, PLD_AUDIT_NEQUIP);
                }
                else
                {
                    FnVCCB_HandlePldCellIdChangeNoti(ptrBuf, gnbNum, PLD_READ_NEQUIP);
                }
                continue;
            }
            else
            {
                VCCB_CHECK_E_RANGE_AND_CONTINUE(ptrBuf->cellId, MAX_CELL_IDENTITY);
                if (VCCB_FLAG_ON == pCfg->pld.isInPldAuditProcessing)
                {
                    FnVCCB_HandlePldCellIdChangeNoti(ptrBuf, gnbNum, PLD_AUDIT_EQUIP_DEL);
                }
                else
                {
                    FnVCCB_HandlePldCellIdChangeNoti(ptrBuf, gnbNum, PLD_READ_EQUIP_DEL);
                }

                cellNum = FnVCCB_GetCellNum(gnbNum, ptrBuf->cellId);
                if (cellNum >= MAX_CELL_NUM_VCCB)
                {
                    cellNum = FnVCCB_AllocateCell(gnbNum, ptrBuf->cellId);
                    if (cellNum >= MAX_CELL_NUM_VCCB)
                    {
                        VCCB_PRINT_ERROR("FnVCCB_AllocateCell ERROR!! for cellIdentity(%d)\n", ptrBuf->cellId);
                        continue;
                    }
                }

                VLIB_GetPldCellStatusParam(ptrBuf, (uint8_t)gnbNum, cellNum);
                if (VCCB_FLAG_ON == pCfg->pld.isInPldAuditProcessing)
                {
                    VLIB_UpdateCellStatusHistory(cellNum, PLD_AUDIT_EQUIP);
                }
                else
                {
                    VLIB_UpdateCellStatusHistory(cellNum, PLD_READ_EQUIP);
                }

                VCCB_PRINTF_PLD_INITIAL_READ("[%4d] gnbNum:%d status:%d gNBId:%d cellId:%d sib1Size:%d endPointF1Index:%d\n",
                    loop, gnbNum, ptrBuf->status, ptrBuf->gNBId, ptrBuf->cellId, ptrBuf->sib1Size, ptrBuf->endPointF1Index);

                if (VCCB_IS_HAS_BACKUP_REQUIRED_DURING_PLD_READ_PER_RELATION())
                {
                    FnVCCB_BackupCellInfo(cellNum);
                }
            }
        }

        if (pCfg->pld.isInitialReadDone == FALSE)  // Need to execute only at the first read time
        {
            TRIGGER_ODF_HO(sTriggerOndemandHandoverByPLD);  // ODF_HO_21B
        }

        FnVCCB_AuditGnbSupportBandInfo();
    }

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}

int16_t VCCB_getRel_PLDGnbCallState(void)
{
    AUTO_TRACE_FUNC;

    int result;
    uint16_t gnbIdx;
    uint32_t loop = 0;
    uint32_t cellNum = 0;
    uint16_t gnbNum = 0;
    relationInfo relInfo;
    VccbPldBuffer pldBuffer;

    result = FnVCCB_GetRelationInfo(REL_GNB_CALL_STATE_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    VccbGnbInfo_type *const pGnbInfo = GNBINFO;
    bool updateFlag[MAX_GNB_CU_CP_FUNCTION_PER_SYS] = {false};

    uint32_t numOfTuple = MIN(relInfo.numOfMaxTuple, relInfo.numOfTuple);
    if (numOfTuple > 0)
    {
        PLDGnbCallState *buf;

        MACRO_GET_RELATION(PLDGnbCallState, REL_GNB_CALL_STATE_ID, relInfo);

        for (loop = 0; loop < numOfTuple; loop++)
        {
            if (buf[loop].status != EQUIP) continue;

            gnbIdx = (uint16_t)buf[loop].gnbIdx;

            gnbNum = FnVCCB_GetGnbNumFromIdOrIdx(buf[loop].gnbId, gnbIdx);
            if (MAX_GNB_PER_SYS <= gnbNum)
            {
                VCCB_PRINTF("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gnbId, gnbIdx);
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gnbId, gnbIdx);
                continue;
            }

            VccbGnbInfo_type *pGnb = &pGnbInfo[gnbNum];

            if (pGnb->pldActivationState != (uint8_t)buf[loop].activationState)
            {
                pGnb->pldActivationState = (uint8_t)buf[loop].activationState;
                for (cellNum = 0; cellNum < MAX_CELL_NUM_VCCB; cellNum++)
                {
                    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
                    if (gnbNum != pCell->gnbNum) continue;
                    if (pCell->status == N_EQUIP && pCell->pldState == N_EQUIP) continue;
                    VLIB_UpdateCellStatusHistory((uint16_t)cellNum, PLD_GNBSTATE_CHANGED);
                }
            }

            updateFlag[gnbNum] = true;
        }
    }

    // In case buf[loop].status = N_EQUIP, pld parameters except key value are unreliable.
    // Hence, initialization of VCCB DB shall proceeds like below.
    for (gnbNum = 0; gnbNum < MAX_GNB_PER_SYS; gnbNum++)
    {
        if (updateFlag[gnbNum] == false)
        {
            VccbGnbInfo_type *pGnb = &pGnbInfo[gnbNum];
            pGnb->pldActivationState = N_EQUIP;
        }
    }

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}

int16_t VCCB_getRel_PLDGnbBarringInfo(void)
{
    AUTO_TRACE_FUNC;

    int result;
    uint32_t loop = 0;
    relationInfo relInfo;
    VccbPldBuffer pldBuffer;

    result = FnVCCB_GetRelationInfo(REL_GNB_BARRING_INFO_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    VccbGnbInfo_type *const pGnbInfo = GNBINFO;
    bool updateFlag[MAX_GNB_CU_CP_FUNCTION_PER_SYS] = {false};

    uint32_t numOfTuple = MIN(relInfo.numOfMaxTuple, relInfo.numOfTuple);
    if (numOfTuple > 0)
    {
        PLDGnbBarringInfo *buf;

        MACRO_GET_RELATION(PLDGnbBarringInfo, REL_GNB_BARRING_INFO_ID, relInfo);

        for (loop = 0; loop < numOfTuple; loop++)  // every tuple
        {
            if (buf[loop].status != EQUIP) continue;

            uint16_t gnbIdx = (uint16_t)buf[loop].gnbIdx;

            uint16_t gnbNum = FnVCCB_GetGnbNumFromIdOrIdx(buf[loop].gnbId, gnbIdx);
            if (MAX_GNB_PER_SYS <= gnbNum)
            {
                VCCB_PRINTF("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gnbId, gnbIdx);
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gnbId, gnbIdx);
                continue;
            }

            VCCB_PRINTF_PLD_INITIAL_READ(
                "[%4d] (gnbIdx:%d) gnbNum:%d gNBId:%d shuttingDown:%d ovld:%d amfNotAvailable:%d\n", loop, gnbIdx, gnbNum,
                buf[loop].gnbId, buf[loop].shuttingDown, buf[loop].overload, buf[loop].amfNotAvailable);

            memcpy(&pGnbInfo[gnbNum].pldGnbBarringInfo, &buf[loop], sizeof(PLDGnbBarringInfo));

            updateFlag[gnbNum] = true;
        }
    }

    // In case buf[loop].status = N_EQUIP, pld parameters except key value are unreliable.
    // Hence, initialization of VCCB DB shall proceeds like below.
    for (int gnbNum = 0; gnbNum < MAX_GNB_PER_SYS; gnbNum++)
    {
        if (updateFlag[gnbNum] == false)
        {
            memset(&pGnbInfo[gnbNum].pldGnbBarringInfo, 0, sizeof(PLDGnbBarringInfo));
        }
    }

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}

int16_t VCCB_getRel_PLDCpuUtilExt(void)
{
    AUTO_TRACE_FUNC;

    int result;
    int isValidTuple = 0;
    uint32_t loop = 0;
    relationInfo relInfo;
    VccbPldBuffer pldBuffer;

    result = FnVCCB_GetRelationInfo(REL_CPU_UTIL_EXT_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    uint32_t numOfTuple = MIN(relInfo.numOfMaxTuple, relInfo.numOfTuple);
    if (numOfTuple > 0)
    {
        PLDCpuUtilExt *buf;

        MACRO_GET_RELATION(PLDCpuUtilExt, REL_CPU_UTIL_EXT_ID, relInfo);

// SVR23B: FGR-LC0302 FR163
#ifdef __NVGNB__
#define getMin(a, b) (((a) == static_cast<AlarmPerceivedSeverity>(indeterminate)) ? (b) :       \
(((b) == static_cast<AlarmPerceivedSeverity>(indeterminate)) ? (a) : (((a) < (b)) ? (a) : (b))))
    uint8_t max_overload = static_cast <AlarmPerceivedSeverity>(cleared); // 5
#endif

        for (loop = 0; loop < numOfTuple; loop++)
        {
#ifdef __NVGNB__
            // SVR23B: FGR-LC0302 FR163.CACP.SR1.HD1
            if ((ENV->drlibNvgnbInfo.mainCardType == DRLIB_NVGNB_GMA1_NR_LTE) ||
            (ENV->drlibNvgnbInfo.mainCardType == DRLIB_NVGNB_GMA1_NR_ONLY))
            {
                isValidTuple = ((buf[loop].unitType == ENV->neInfo.unitType) && (buf[loop].cpuId == 0 || buf[loop].cpuId == 1));
            }
            else
            {
                isValidTuple = ((buf[loop].unitType == ENV->neInfo.unitType) && (buf[loop].cpuId == ENV->neInfo.cpuId));
            }
#else
#ifdef __CNF__
            isValidTuple = buf[loop].unitType == CPP && buf[loop].unitId == CFG->vm.unitId;  // unitType CPP for CNF
#else
            isValidTuple = buf[loop].unitType == CPC && buf[loop].unitId == CFG->vm.unitId;  // unitType CPC for VNF
#endif
#endif
            if (isValidTuple && buf[loop].ValidFlag == 1)
            {
                // SVR23B: FGR-LC0302 FR163.CACP.SR1.HD1
#ifdef __NVGNB__
                if ((ENV->drlibNvgnbInfo.mainCardType == DRLIB_NVGNB_GMA1_NR_LTE) ||
                (ENV->drlibNvgnbInfo.mainCardType == DRLIB_NVGNB_GMA1_NR_ONLY))
                {
                    CFG->overloadValue[buf[loop].cpuId] = (uint8_t)buf[loop].cpuAlarmStatus;
                    max_overload = getMin(CFG->overloadValue[buf[loop].cpuId], max_overload);
                    CFG->overloadStatus = max_overload;
                }
                else
                {
                    CFG->overloadStatus = (uint8_t)buf[loop].cpuAlarmStatus;
                }
#else
                CFG->overloadStatus = (uint8_t)buf[loop].cpuAlarmStatus;
#endif
                if (CFG->overloadStatus == 0)
                {
                    CFG->globalTraceInfo.traceDisabledDueOverload = 0;
                }
                else
                {
                    if (CFG->overloadStatus - 1 <= CFG->globalTraceInfo.stopThreshold)
                        CFG->globalTraceInfo.traceDisabledDueOverload = 1;
                    
                    if (CFG->overloadStatus - 1 >= CFG->globalTraceInfo.resumeThreshold)
                        CFG->globalTraceInfo.traceDisabledDueOverload = 0;
                }

                CFG->cpuLoad = (uint8_t)buf[loop].cpuLoad;

                VCCB_PRINTF_PLD_INITIAL_READ(
                    "[PLD] Overload status init - value:(%d) \n", CFG->overloadStatus);
                VCCB_PRINTF_PLD_INITIAL_READ("[PLD] Trace Overload flag traceDisabledDueOverload init value:(%d) \n",
                    CFG->globalTraceInfo.traceDisabledDueOverload);
                VCCB_PRINTF_PLD_INITIAL_READ(
                    "[PLD] CpuLoad init - value:(%d)\n", CFG->cpuLoad);
            }
        }
    #ifdef __NVGNB__
    #undef getMin
    #endif
    }

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}

int16_t VCCB_getRel_PLDCellTraceStatus(void)
{
    AUTO_TRACE_FUNC;
    STANDBY_RETURN_OK;

    int result;
    uint32_t loop = 0;
    relationInfo relInfo;
    VccbPldBuffer pldBuffer;

    result = FnVCCB_GetRelationInfo(REL_CELL_TRACE_STATUS_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    VccbCellInfo_type *const pCellInfo = CELLINFO;
    const int maxCellNum = MAX_CELL_NUM_VCCB;
    bool updateFlag[MAX_CELL_PER_VNF] = {false};

    uint32_t numOfTuple = MIN(relInfo.numOfMaxTuple, relInfo.numOfTuple);
    if (numOfTuple > 0)
    {
        PLDCellTraceStatus *buf;

        MACRO_GET_RELATION(PLDCellTraceStatus, REL_CELL_TRACE_STATUS_ID, relInfo);

        VccbGnbInfo_type *const pGnbInfo = GNBINFO;

        for (loop = 0; loop < numOfTuple; loop++)
        {
            if (buf[loop].status != EQUIP) continue;

            uint16_t pldGnbNum = buf[loop].gnbNum;
            uint16_t cellId = buf[loop].cellId;

            VCCB_CHECK_E_RANGE_AND_CONTINUE(cellId, MAX_CELL_IDENTITY);

            uint16_t gnbNum = FnVCCB_GetGnbNumFromIdOrIdx(buf[loop].gNBId, pldGnbNum);
            if (MAX_GNB_PER_SYS <= gnbNum)
            {
                VCCB_PRINTF("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,pldGnbNum:%d)\n", __func__, buf[loop].gNBId, pldGnbNum);
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,pldGnbNum:%d)\n", __func__, buf[loop].gNBId, pldGnbNum);
                continue;
            }

            uint16_t cellNum = pGnbInfo[gnbNum].env.cellNum[cellId];
            VCCB_CHECK_E_RANGE_AND_CONTINUE(cellNum, maxCellNum);

            ManagementTraceSessionPerCell_type *const pSession = &pCellInfo[cellNum].traceSession;
            pSession->pldCellIndex = (uint16_t)loop;
            pSession->trace.cellTraceAllowedFlag = buf[loop].cellTraceAllowedFlag;
            pSession->mdt.immediateMdtAllowedFlag = buf[loop].immediateMdtAllowedFlag;
            pSession->mdt.loggedMdtAllowedFlag = buf[loop].loggedMdtAllowedFlag;

            if (VCCB_IS_HAS_BACKUP_REQUIRED_DURING_PLD_READ_PER_RELATION())
            {
    #ifdef __CNF__
                FnVCCB_BackupCellInfo(cellNum);
    #else
                FnVCCB_BackupCellInfoPartial(cellNum, &pSession->pldCellIndex, 
                    sizeof(pSession->pldCellIndex));
                FnVCCB_BackupCellInfoPartial(cellNum, &pSession->trace.cellTraceAllowedFlag,
                    sizeof(pSession->trace.cellTraceAllowedFlag));
                FnVCCB_BackupCellInfoPartial(cellNum, &pSession->mdt.immediateMdtAllowedFlag,
                    sizeof(pSession->mdt.immediateMdtAllowedFlag));
                FnVCCB_BackupCellInfoPartial(cellNum, &pSession->mdt.loggedMdtAllowedFlag,
                    sizeof(pSession->mdt.loggedMdtAllowedFlag));
    #endif
            }

            updateFlag[cellNum] = true;
        }
    }

    // In case buf[loop].status = N_EQUIP, pld parameters except key value are unreliable.
    // Hence, initialization of VCCB DB shall proceeds like below.
    for (int cellNum = 0; cellNum < maxCellNum; cellNum++)
    {
        if (updateFlag[cellNum] == false)
        {
            ManagementTraceSessionPerCell_type *const pSession = &pCellInfo[cellNum].traceSession;
            pSession->pldCellIndex = 0;
            pSession->trace.cellTraceAllowedFlag = 0;
            pSession->mdt.immediateMdtAllowedFlag = 0;
            pSession->mdt.loggedMdtAllowedFlag = 0;
        }
    }

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}

int16_t VCCB_getRel_PLDTraceStatus(void)
{
    AUTO_TRACE_FUNC;

    int result;
    relationInfo relInfo;
    PLDTraceStatus buf;

    result = FnVCCB_GetRelationInfo(REL_TRACE_STATUS_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    result = FnVCCB_GetRelation(REL_TRACE_STATUS_ID, (char *)&buf, VCCB_GET_REL_BUFF_SIZE(relInfo), relInfo.tupleSize);
    if (result < 0)
    {
        return (int16_t)result;
    }

    VCCB_PRINTF_PLD_INITIAL_READ("PLDTraceStatus acpfIdx:%d status:%d acpfTraceAllowedFlag:%d sigTraceAllowedFlag:%d\n",
        buf.acpfIdx, buf.status, buf.acpfTraceAllowedFlag, buf.ueTraceAllowedFlag);

    CFG->globalTraceInfo.acpfTraceAllowedFlag = buf.acpfTraceAllowedFlag;
    CFG->globalTraceInfo.signaling.sigTraceAllowedFlag = buf.ueTraceAllowedFlag;

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}

void make_Z_IMSI(PLDImsiTrace *buf)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(buf);

    ZIMSI_type Z_IMSI;  // Z_IMSI buf
    IMSI_type imsi;     // imsiTraceInfo buf (imsi buf)
    uint8_t length = 0, idx = 0;
    memset(&Z_IMSI, 0x00, sizeof(ZIMSI_type));
    memset(&imsi, 0x00, sizeof(IMSI_type));

    // Make Z_IMSI from PLDImsiTrace Buf for Debugging
    for (idx = 0; idx < MIN(MAX_TRACE_IMSI, buf->numOfImsi); idx++)
    {
        // Z_IMSI information
        Z_IMSI.length = buf->digitLen[idx];
        for (length = 0; length < MIN(MAX_IMSI_BYTE, buf->digitLen[idx]); length++)
        {
            Z_IMSI.value[length] = buf->digit[idx][length];  // Z_IMSI of #imsiIdx
            DBG->imsiTraceInfo.ZIMSILen[idx] = buf->digitLen[idx];
            DBG->imsiTraceInfo.ZIMSI[idx][length] = Z_IMSI.value[length];
        }

        // Convert Z_IMSI to IMSI
        ConvertZImsiToImsi(&Z_IMSI, &imsi);
        // Make imsiTraceInfo from converted IMSI
        DBG->imsiTraceInfo.numOfImsi = buf->numOfImsi;
        DBG->imsiTraceInfo.imsiIdx[idx] = idx;
        DBG->imsiTraceInfo.IMSILen[idx] = (uint8_t)imsi.n;
        // IMSI information
        for (length = 0; length < MIN(MAX_IMSI_DIGIT, imsi.n); length++)
        {
            DBG->imsiTraceInfo.IMSI[idx][length] = imsi.digit[length];
        }
    }
}

int16_t VCCB_getRel_PLDImsiTrace(void)
{
    AUTO_TRACE_FUNC;

    int result;
    relationInfo relInfo;

    PLDImsiTrace buf;  // PLDImsiTrace buf

    result = FnVCCB_GetRelationInfo(REL_IMSI_TRACE_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    result = FnVCCB_GetRelation(REL_IMSI_TRACE_ID, (char *)&buf, VCCB_GET_REL_BUFF_SIZE(relInfo), relInfo.tupleSize);
    if (result < 0)
    {
        return (int16_t)result;
    }

    make_Z_IMSI(&buf);

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}

int16_t VCCB_getRel_PLDCpcUsageState(void)
{
    AUTO_TRACE_FUNC;

    int result;
    uint32_t loop = 0;
    relationInfo relInfo;
    VccbPldBuffer pldBuffer;

    result = FnVCCB_GetRelationInfo(REL_CPC_USAGE_STATE_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    uint32_t numOfTuple = MIN(relInfo.numOfMaxTuple, relInfo.numOfTuple);
    if (numOfTuple > 0)
    {
        PLDCPCUsageState *buf;

        MACRO_GET_RELATION(PLDCPCUsageState, REL_CPC_USAGE_STATE_ID, relInfo);

        for (loop = 0; loop < numOfTuple; ++loop)
        {
            if (CFG->vm.unitId == buf[loop].cpcId)
            {
                int isReleaseNeeded =
                    buf[loop].upgradeStatus == CU_UPGRADE_RELEASE && CFG->pldCpcState.upgradeStatus != buf[loop].upgradeStatus;
                CFG->pldCpcState.upgradeStatus = (uint8_t)buf[loop].upgradeStatus;

                VCCB_PRINTF_PLD_INITIAL_READ(
                    "PLDCPCUsageState cpcId:%d status:%d preScaleInStatus:%d usageState:%d upgradeStatus:%d\n",
                    buf[loop].cpcId, buf[loop].status, buf[loop].preScaleInStatus, buf[loop].usageState, buf[loop].upgradeStatus);

                if (isReleaseNeeded)
                {
                    VCCB_PRINTF("[PLD] upgradeState changed into 'release' - releasing all calls.\n");
                    FnVCCB_ReleaseAllCalls(INTERNAL_CALL_RELEASE_CAUSE_VNF_UPGRADE);

                }

                break;
            }
        }
    }

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}

int16_t VCCB_getRel_PLDEutraCellInfo(void)
{
    AUTO_TRACE_FUNC;

    int result;
    uint32_t loop = 0;
    relationInfo relInfo;
    VccbPldBuffer pldBuffer;

    uint16_t gnbIdx;
    int endPointIdx;
    uint16_t gnbNum;

    result = FnVCCB_GetRelationInfo(REL_EUTRA_CELL_INFO_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }
    
    VccbCfgInfo_type *pCfg = CFG;
    bool updateFlag[MAX_GNB_PER_SYS][MAX_ENB_PER_GNB_CU_CP] = {false};

    uint32_t numOfTuple = MIN(relInfo.numOfMaxTuple, relInfo.numOfTuple);
    if (numOfTuple > 0)
    {
        PLDEutraCellInfo *buf;

        MACRO_GET_RELATION(PLDEutraCellInfo, REL_EUTRA_CELL_INFO_ID, relInfo);

        for (loop = 0; loop < numOfTuple; loop++)
        {
            if (buf[loop].status != EQUIP) continue;

            gnbIdx = buf[loop].gNBIdx;
            endPointIdx = buf[loop].endPointIdx;

            VCCB_CHECK_E_RANGE_AND_CONTINUE(endPointIdx, MAX_ENB_PER_GNB_CU_CP);
            
            gnbNum = FnVCCB_GetGnbNumFromIdOrIdx(buf[loop].gNBId, gnbIdx);
            if (MAX_GNB_PER_SYS <= gnbNum)
            {
                VCCB_PRINTF("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gNBId, gnbIdx);
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gNBId, gnbIdx);
                continue;
            }

            memcpy(&pCfg->pldEutraCellInfo[gnbNum][endPointIdx], &buf[loop], sizeof(PLDEutraCellInfo));

            updateFlag[gnbNum][endPointIdx] = true;
        }
    }

    // In case buf[loop].status = N_EQUIP, pld parameters except key value are unreliable.
    // Hence, initialization of VCCB DB shall proceeds like below.
    for (gnbNum = 0; gnbNum < MAX_GNB_PER_SYS; gnbNum++)
    {
        for (endPointIdx = 0; endPointIdx < MAX_ENB_PER_GNB_CU_CP; endPointIdx++)
        {
            if (updateFlag[gnbNum][endPointIdx] == false)
            {
                memset(&pCfg->pldEutraCellInfo[gnbNum][endPointIdx], 0, sizeof(PLDEutraCellInfo));
            }
        }
    }

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}

int16_t VCCB_getRel_PLDXnGnbStatus(void)
{
    AUTO_TRACE_FUNC;

    int result;
    relationInfo relInfo;
    VccbPldBuffer pldBuffer;

    uint16_t gnbNum = 0xFFFF;
    uint16_t endPointIdx;
    uint32_t loop = 0, idx = 0;

    result = FnVCCB_GetRelationInfo(REL_XN_GNB_STATUS_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    VccbGnbInfo_type *const pGnbInfo = GNBINFO;
    bool updateFlag[MAX_GNB_PER_SYS][MAX_XN_NBR_PER_GNB] = {false};

    uint32_t numOfTuple = MIN(relInfo.numOfMaxTuple, relInfo.numOfTuple);
    if (numOfTuple > 0)
    {
        PLDXnGnbStatus *buf;

        MACRO_GET_RELATION(PLDXnGnbStatus, REL_XN_GNB_STATUS_ID, relInfo);

        for (loop = 0; loop < numOfTuple; loop++)
        {
            if (buf[loop].status != EQUIP) continue;

            gnbNum = FnVCCB_GetGnbNumFromIdOrIdx(buf[loop].gNBId, buf[loop].gNBIdx);
            if (MAX_GNB_PER_SYS <= gnbNum)
            {
                VCCB_PRINTF("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gNBId, buf[loop].gNBIdx);
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gNBId, buf[loop].gNBIdx);
                continue;
            }

            endPointIdx = buf[loop].endPointIdx;
            VCCB_CHECK_E_RANGE_AND_CONTINUE(endPointIdx, MAX_XN_NBR_PER_GNB);

            // memset(&GNBINFO[gnbNum].xnGnbInfo[endPointIdx], 0, sizeof(xnTaiInfo_type));

            xnTaiInfo_type *pXnGnb = &pGnbInfo[gnbNum].xnGnbInfo[endPointIdx];
            xnNbrInfo_type *pXnNbr = &pGnbInfo[gnbNum].xnNbr[endPointIdx];
            pXnGnb->gNBId = buf[loop].gNBId;
            pXnGnb->gNBIdx = buf[loop].gNBIdx;
            pXnGnb->status = buf[loop].status;
            pXnGnb->serviceState = buf[loop].serviceState;
            pXnGnb->samsungVendorInd = (unsigned)(buf[loop].samsungVendorInd & 0x1);
            pXnGnb->taiSupportCnt = buf[loop].taiSupportCnt;
            pXnNbr->xnapLinkState = (unsigned)(FnVCCB_CommonEnumOperType(buf[loop].serviceState) & 0x1);
            if (pXnGnb->status == EQUIP)
            {
                for (idx = 0; idx < MAX_XN_TAI_SUPPORT_COUNT; idx++)
                {
                    pXnGnb->tac[idx] = buf[loop].tac[idx];
                    pXnGnb->plmn[idx] = buf[loop].plmn[idx];
                    pXnGnb->sNssai[idx] = buf[loop].sNssai[idx];
                }
            }

            updateFlag[gnbNum][endPointIdx] = true;
        }
    }

    // In case buf[loop].status = N_EQUIP, pld parameters except key value are unreliable.
    // Hence, initialization of VCCB DB shall proceeds like below.
    for (gnbNum = 0; gnbNum < MAX_GNB_PER_SYS; gnbNum++)
    {
        for (endPointIdx = 0; endPointIdx < MAX_XN_NBR_PER_GNB; endPointIdx++)
        {
            if (updateFlag[gnbNum][endPointIdx] == false)
            {
                memset(&pGnbInfo[gnbNum].xnGnbInfo[endPointIdx], 0, sizeof(xnTaiInfo_type));
                pGnbInfo[gnbNum].xnNbr[endPointIdx].xnapLinkState = CI_no_use;
            }
        }
    }

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}

int16_t VCCB_getRel_PLDGnbXnTaiInfo(void)
{
    AUTO_TRACE_FUNC;

    int result;
    relationInfo relInfo;
    VccbPldBuffer pldBuffer;

    uint16_t gnbNum = 0xFFFF;
    uint32_t loop = 0, idx = 0;

    result = FnVCCB_GetRelationInfo(REL_GNB_XN_TAI_INFO_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    VccbGnbInfo_type *const pGnbInfo = GNBINFO;
    bool updateFlag[MAX_GNB_CU_CP_FUNCTION_PER_SYS] = {false};

    uint32_t numOfTuple = MIN(relInfo.numOfMaxTuple, relInfo.numOfTuple);
    if (numOfTuple > 0)
    {
        PLDGnbXnTaiInfo *buf;

        MACRO_GET_RELATION(PLDGnbXnTaiInfo, REL_GNB_XN_TAI_INFO_ID, relInfo);

        for (loop = 0; loop < numOfTuple; loop++)
        {
            if (buf[loop].status != EQUIP) continue;

            gnbNum = FnVCCB_GetGnbNumFromIdOrIdx(buf[loop].gNBId, buf[loop].gnbIdx);
            if (MAX_GNB_PER_SYS <= gnbNum)
            {
                VCCB_PRINTF("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gNBId, buf[loop].gnbIdx);
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gNBId, buf[loop].gnbIdx);
                continue;
            }

            xnTaiInfo_type *pGnbXnTai = &pGnbInfo[gnbNum].gnbXnTaiInfo;
            pGnbXnTai->gNBId = buf[loop].gNBId;
            pGnbXnTai->gNBIdx = buf[loop].gnbIdx;
            pGnbXnTai->status = buf[loop].status;
            pGnbXnTai->serviceState = OpState_enabled;  // Always Enabled
            pGnbXnTai->taiSupportCnt = buf[loop].taiSupportCnt;
            if (pGnbXnTai->status == EQUIP)
            {
                for (idx = 0; idx < MAX_XN_TAI_SUPPORT_COUNT; idx++)
                {
                    pGnbXnTai->tac[idx] = buf[loop].tac[idx];
                    pGnbXnTai->plmn[idx] = buf[loop].plmn[idx];
                    pGnbXnTai->sNssai[idx] = buf[loop].sNssai[idx];
                }
            }

            updateFlag[gnbNum] = true;
        }
    }

    // In case buf[loop].status = N_EQUIP, pld parameters except key value are unreliable.
    // Hence, initialization of VCCB DB shall proceeds like below.
    for (gnbNum = 0; gnbNum < MAX_GNB_PER_SYS; gnbNum++)
    {
        if (updateFlag[gnbNum] == false)
        {
            memset(&pGnbInfo[gnbNum].gnbXnTaiInfo, 0, sizeof(xnTaiInfo_type));
        }
    }

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}

#if !defined(NEW_HOST_SIM) || defined(NEW_HOST_SIM_PLD)
#else
void FnVCCB_FillPLDInfo_ForHostSim()
{
    AUTO_TRACE_FUNC;

    uint8_t loop;
    int32_t loop1;

    // Initial PLD setting for HOST SIM
    for (loop = 0; loop < MAX_GNB_PER_SYS; ++loop)
    {
        for (loop1 = 0; loop1 < MAX_AMF_PER_GNB_CU_CP; ++loop1)
        {
            CFG->amf.pldAmfStatus[loop][loop1].gNBId = CFG->amf.pldAmfTnlStatus[loop][loop1][0].gNBId =
                CFG->gnbNumInfo.gnbIdFromNum[loop].gnbId;
            CFG->amf.pldAmfStatus[loop][loop1].gNBIdx = CFG->amf.pldAmfTnlStatus[loop][loop1][0].gNBIdx = loop;
            CFG->amf.pldAmfStatus[loop][loop1].status = CFG->amf.pldAmfTnlStatus[loop][loop1][0].status = EQUIP;

            CFG->amf.pldAmfStatus[loop][loop1].serviceState = (int8_t)OpState_enabled;
            CFG->amf.pldAmfTnlSctpState[loop][loop1][0].sctpState = (int)OpState_enabled;
            
            CFG->amf.pldAmfStatus[loop][loop1].endPointIdx = 0;
            CFG->amf.pldAmfTnlStatus[loop][loop1][0].weightFactor = 2;
            CFG->amf.pldAmfTnlStatus[loop][loop1][0].tnlUsage = NGAP_ue;
        }
    }

    return;
}
#endif

int16_t FnVCCB_IsReadSkipCase(pldInfo_type *pPld, int isReadCase)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(pPld);

    if (VCCB_GetNecessityPldByFOO(pPld->relId) == e_Unnecessity)
    {
        if (TRUE == isReadCase)
        {
            if (FALSE == CFG->pld.isInitialReadDone)
            {
                VCCB_PRINTF(
                    "[ReadPld] Skipped. FOO not supported(relId:0x%X, relName:%s)\n", pPld->relId, pPld->relName);
                CFG->pld.pldRelationReadSkipByFooCount++;
            }
        }
        else
        {
            VCCB_PRINTF(
                "[RegisterPLD] Skipped. FOO not supported(relId:0x%X, relName:%s)\n", pPld->relId, pPld->relName);
        }

        return TRUE;
    }

    if ((e_VCCB_NVGNB == VCOM_getSystemType()) && (FALSE == pPld->isSupportNVGNB))
    {
        if (TRUE == isReadCase)
        {
            if (FALSE == CFG->pld.isInitialReadDone)
            {
                VCCB_PRINTF(
                    "[ReadPld] Skipped. NVGNB not supported(relId:0x%X, relName:%s)\n", pPld->relId, pPld->relName);
                CFG->pld.pldRelationReadSkipNVGNBCount++;
            }
        }
        else
        {
            VCCB_PRINTF(
                "[RegisterPLD] Skipped. NVGNB not supported(relId:0x%X, relName:%s)\n", pPld->relId, pPld->relName);
        }

        return TRUE;
    }

    if ((e_VCCB_ACPF_CNF == VCOM_getSystemType()) && (FALSE == pPld->isSupportCNF))
    {
        if (TRUE == isReadCase)
        {
            if (FALSE == CFG->pld.isInitialReadDone)
            {
                VCCB_PRINTF(
                    "[ReadPld] Skipped. CNF not supported(relId:0x%X, relName:%s)\n", pPld->relId, pPld->relName);
                CFG->pld.pldRelationReadSkipCNFCount++;
            }
        }
        else
        {
            VCCB_PRINTF(
                "[RegisterPLD] Skipped. CNF not supported(relId:0x%X, relName:%s)\n", pPld->relId, pPld->relName);
        }

        return TRUE;
    }

    return FALSE;
}

int16_t VCCB_InitialReadPld()
{
    AUTO_TRACE_FUNC;

    // [SAM_GV_IMPROVEMENT] gPldInfo -> gPldInfo_
    if (CFG->pld.isInitialReadDone == FALSE)
    {
#ifndef IPC_TEST
        VCCB_PRINTF("========== InitialRead Pld Start! ==========\n");
#endif
        FnVCCB_RecordTime(&ENV->vccbInitTime.initialReadPldStart);
    }
    else
    {
        VCCB_PRINTF("========== ReRead Pld Start! ==========\n");
    }
    VLIB_SetCurrentTime(&CFG->pld.pldDataReadStartTime);

    CFG->pld.pldRelationReadSkipByFooCount = 0;
    CFG->pld.pldRelationReadSkipNVGNBCount = 0;
    CFG->pld.pldRelationReadSkipCNFCount = 0;
    CFG->pld.pldGetOptionalRelationFailCount = 0;
    CFG->pld.pldGetMandatoryRelationFailCount = 0;

#ifndef IPC_TEST  // REAL Only
#if !defined(NEW_HOST_SIM) || defined(NEW_HOST_SIM_PLD)
    int16_t result;
    int relIdx = 0;
    pldInfo_type *pPld = NULL;
    for (relIdx = 0; relIdx < VCCB_MAX_USER_PLD; relIdx++)
    {
        pPld = &gPldInfo_[relIdx];

        if (pPld->relId == 0) continue;
        if (pPld->fnGetRel == NULL) continue;

        if (FnVCCB_IsReadSkipCase(pPld, TRUE) == TRUE) continue;

        result = pPld->fnGetRel();
        if (result != GOOD)
        {
            if (pPld->optional == OPTIONAL)
            {
                VCCB_PRINTF(
                    "[ReadPld] fnGetRel Error and skipped(OPTIONAL PLD)!! (relId:0x%X, relName:%s, retVal:%d)\n",
                    pPld->relId, pPld->relName, result);
                CFG->pld.pldGetOptionalRelationFailCount++;
                continue;
            }

            VCCB_PRINTF(
                "[ReadPld] fnGetRel Error!! (relId:0x%X, relName:%s, retVal:%d)\n", pPld->relId, pPld->relName, result);
            CFG->pld.pldGetMandatoryRelationFailCount++;

            VLIB_SetCurrentTime(&CFG->pld.pldDataReadEndTime);
            return result;
        }
    }
#else
    FnVCCB_FillPLDInfo_ForHostSim();
#endif
#endif

    CFG->pld.needAuditWithHasBackup = FALSE;
    if (CFG->pld.isInitialReadDone == FALSE)
    {
        CFG->pld.isInitialReadDone = TRUE;
        CFG->pld.numOfPld = VCCB_MAX_USER_PLD;
        CFG->pld.curAuditRelIdx = 0;
#ifndef IPC_TEST
        VCCB_PRINTF("========== InitialRead Pld Success ==========\n");
#endif
        FnVCCB_RecordTime(&ENV->vccbInitTime.initialReadPldEnd);
    }
    else
    {
        VCCB_PRINTF("========== ReRead Pld Success ==========\n");
    }
    VLIB_SetCurrentTime(&CFG->pld.pldDataReadEndTime);

    return GOOD;
}

void FnVCCB_HandleInternalPLDReadRequest(message_type *ptAll)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptAll);

    msgInternalPLDReadRequest_type *ptRequest = NULL;

    ptRequest = (msgInternalPLDReadRequest_type *)ptAll;

    if (ptRequest->requestCause == e_BY_SWITCHOVER)
    {
        VCCB_PRINTF("[%s]Read all PLDs by InternalPLDReadRequest(due to SwitchOver)\n", __func__);
    }
    else // (ptRequest->requestCause == e_BY_GNB_CREATION)
    {
        VCCB_PRINTF("[%s]Read all PLDs by InternalPLDReadRequest(due to GNB_CREATION)\n", __func__);
    }

    if (ptRequest->isHasBackupRequired == TRUE)
    {
        CFG->pld.needAuditWithHasBackup = TRUE;
    }

    if (ERROR == VCCB_InitialReadPld())
    {
        VCCB_PRINTF("Read User PLD Failed in %s\n", __FUNCTION__);
    }

    // Initialize Audit Index (Start from 0 after reading all the UserPLD)
    CFG->pld.curAuditRelIdx = 0;

    return;
}

void FnVCCB_AuditGnbSupportBandInfo(void)
{
    AUTO_TRACE_FUNC;

    /*************************************************************************
    // 1. Check If not-used band exists in CELLINFO PLDs, and remove them.
    // 2. Check If not-included band exists, and add them to the list.
    // 3. Trim Duplication.
    **************************************************************************/

    uint16_t gnbNum, gnbBandIdx, cellBandIdx, cellNum, loop, relIdx;
    uint16_t findBandFlag = 0;
    uint8_t changeGnbList[MAX_GNB_PER_SYS] = {
        0,
    };
    gnbSupportedBandInfo_type tempGnbSupportBand;
    gnbSupportedBandInfo_type *pRelList = NULL;

    // 1. Compare GNBINFO to CELL PLD for finding not-used band in 'GNBINFO.supportedFreqBandInfo'
    // if there are any not used-band, remove them.
    for (gnbNum = 0; gnbNum < MAX_GNB_PER_SYS; gnbNum++)
    {
        VccbGnbInfo_type *pGnb = &GNBINFO[gnbNum];
        gnbSupportedBandInfo_type *pGnbLocal = &pGnb->supportedFreqBandInfo;
        memset(&tempGnbSupportBand, 0, sizeof(tempGnbSupportBand));
        pRelList = &tempGnbSupportBand;
        // Audit Num.
        if (pGnbLocal->num > MAX_FREQBAND_FILTER)
        {
            pGnbLocal->num = MAX_FREQBAND_FILTER;
        }

        // Find nRFrequencyBand in Cell PLD.
        for (gnbBandIdx = 0; gnbBandIdx < pGnbLocal->num; gnbBandIdx++)
        {
            findBandFlag = 0;
            for (cellNum = 0; cellNum < MAX_CELL_NUM_VCCB; cellNum++)
            {
                VccbCellInfo_type *pCell = &CELLINFO[cellNum];
                if (pCell->pldState != EQUIP) continue;
                if (pCell->gnbNum != gnbNum) continue;
                for (cellBandIdx = 0; cellBandIdx < MAX_NR_CELL_FREQ_BAND_LIST; cellBandIdx++)
                {
                    if (pCell->freqBandInfoList[cellBandIdx].status != EQUIP) continue;
                    if (pCell->freqBandInfoList[cellBandIdx].nRFrequencyBand == 0) continue;
                    if (pCell->freqBandInfoList[cellBandIdx].nRFrequencyBand > MAX_NUM_NR_BAND) continue;

                    if (pGnbLocal->nrFreqBand[gnbBandIdx] == pCell->freqBandInfoList[cellBandIdx].nRFrequencyBand)
                    {
                        findBandFlag++;
                        break;
                    }
                }
                if (findBandFlag) break;
            }  // for cell

            if (findBandFlag == 0)  // This gNB DB doesn't exist among Cell PLDs
            {
                pRelList->nrFreqBand[pRelList->num++] = pGnbLocal->nrFreqBand[gnbBandIdx];
            }
        }  // for band

        // Remove Band in GNB SupportBandList.
        if (pRelList->num)
        {
            for (relIdx = 0; relIdx < pRelList->num; relIdx++)
            {
                for (gnbBandIdx = 0; gnbBandIdx < pGnbLocal->num; gnbBandIdx++)
                {
                    if (pGnbLocal->nrFreqBand[gnbBandIdx] == pRelList->nrFreqBand[relIdx])
                    {
                        if (gnbBandIdx == (pGnbLocal->num - 1))
                        {
                            pGnbLocal->nrFreqBand[gnbBandIdx] = 0;
                        }
                        else
                        {
                            pGnbLocal->nrFreqBand[gnbBandIdx] = pGnbLocal->nrFreqBand[pGnbLocal->num - 1];
                        }
                        pGnbLocal->num--;
                        changeGnbList[gnbNum] = VCCB_FLAG_ON;  // Those gnb list will be backed up.
                        VCCB_PRINT_ERROR(
                            "GNB[%d] Audit Del SupportedBandInfoList. (num : %d)\n", gnbNum, pGnbLocal->num);
                        break;
                    }
                }
            }  // for relIdx
        }
    }  // for gNB

    // 2. Check If Not included Band exist, and Add it
    for (cellNum = 0; cellNum < MAX_CELL_NUM_VCCB; cellNum++)
    {
        VccbCellInfo_type *pCell = &CELLINFO[cellNum];
        if (pCell->pldState != EQUIP) continue;
        for (loop = 0; loop < MAX_NR_CELL_FREQ_BAND_LIST; loop++)
        {
            if (pCell->freqBandInfoList[loop].status != EQUIP) continue;
            if (pCell->freqBandInfoList[loop].nRFrequencyBand == 0) continue;
            if (pCell->freqBandInfoList[loop].nRFrequencyBand > MAX_NUM_NR_BAND) continue;

            if (pCell->gnbNum >= MAX_GNB_PER_SYS) continue;
            VccbGnbInfo_type *pGnb = &GNBINFO[pCell->gnbNum];
            gnbSupportedBandInfo_type *pGnbLocal = &pGnb->supportedFreqBandInfo;
            // Find BandList
            if (FnVCCB_isAlreadyExist_inGnbBand(pGnbLocal, pCell->freqBandInfoList[loop].nRFrequencyBand) != TRUE)
            {
                if (pGnbLocal->num < MAX_FREQBAND_FILTER)
                {
                    pGnbLocal->nrFreqBand[pGnbLocal->num++] = pCell->freqBandInfoList[loop].nRFrequencyBand;
                    changeGnbList[pCell->gnbNum] = VCCB_FLAG_ON;
                    VCCB_PRINT_ERROR(
                        "GNB[%d] Audit Add SupportedBandInfoList. (num : %d)\n", pCell->gnbNum, pGnbLocal->num);
                }
            }
        }
    }

    // 3. Duplication.
    for (gnbNum = 0; gnbNum < MAX_GNB_PER_SYS; gnbNum++)
    {
        if (changeGnbList[gnbNum] == VCCB_FLAG_ON)
        {
#ifdef __CNF__
            FnVCCB_RedisUpdateGnbInfoFlagOn(gnbNum);
#else
            HAS_BACKUP_DATA_PER_GNB(gnbNum, VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_0,
                &GNBINFO[gnbNum].supportedFreqBandInfo, sizeof(gnbSupportedBandInfo_type));
#endif
        }
    }  // for gnbNum
    return;
}

void FnVCCB_UpdatePldAuditHistory(int relId, int result)
{
    AUTO_TRACE_FUNC;

    VccbDbgPldAuditHistory_type *pHist = &DBG->pldAuditHist;
    VccbDbgUpdatePldAuditHistory_type *pUpdate = NULL;

    long currentTime;
    int16_t curIdx = pHist->curIdx;

    if (curIdx == -1 || curIdx >= MAX_HISTORY_NUM)  // 1st case or curIdx was corrupted case
    {
        curIdx = 0;
        pHist->cycleFlag = VCCB_FLAG_OFF;
    }
    else if (curIdx == MAX_HISTORY_NUM - 1)
    {
        curIdx = 0;
        pHist->cycleFlag = VCCB_FLAG_ON;
    }
    else
        curIdx++;

    pHist->curIdx = curIdx;
    pUpdate = &DBG->pldAuditHist.update[curIdx];

    pUpdate->relId = relId;
    pUpdate->readResult = result;
    if (time(&currentTime) > 0) pUpdate->updateTime = currentTime;
}

void VCCB_AuditPld(void)
{
    AUTO_TRACE_FUNC;
    int result = GOOD;
    uint8_t relIdx = 0;
    pldInfo_type *pPld = NULL;

    // This function is called every 60 seconds. When called, VCCB read only one User PLD. (For reducing load)

    if (CFG->pld.curAuditRelIdx >= VCCB_MAX_USER_PLD)
    {
        CFG->pld.curAuditRelIdx = 0;

        // In order to reduce repeated HAS backup, HAS backup is performed only in the first audit after switching to
        // ACTIVE.
        CFG->pld.needAuditWithHasBackup = FALSE;
    }

    CFG->pld.isInPldAuditProcessing = VCCB_FLAG_ON;

    for (relIdx = CFG->pld.curAuditRelIdx; relIdx < VCCB_MAX_USER_PLD; relIdx++)
    {
        pPld = &gPldInfo_[relIdx];

        if (pPld->relId == 0) continue;
        if (pPld->fnGetRel == NULL) continue;

        if (FnVCCB_IsReadSkipCase(pPld, TRUE) == TRUE) continue;
        if (pPld->isRequiredAudit != TRUE) continue;

#ifndef IPC_TEST  // REAL Only
#if !defined(NEW_HOST_SIM) || defined(NEW_HOST_SIM_PLD)
        if (dbiPLDExists(pPld->relId) != DBI_SUCCESS) continue;

        result = pPld->fnGetRel();
        if (result != GOOD)
        {
            VCCB_PRINTF("[VCCB_AuditPld] fnGetRel Error!! (relId:0x%X, relName:%s, retVal:%d)\n", pPld->relId,
                pPld->relName, result);
        }
        else if (TRUE == pPld->isRequiredSub)
        {
            // Only some mandatory PLD require DBI_WITH_DATA (REL_DU_STATUS_ID, REL_CELL_STATUS_ID, REL_CELL_TRACE_STATUS_ID)
            // VCCB will not start without subscribing these PLD
            if (GOOD != VCCB_RegisterSinglePLD(pPld, DBI_WITHOUT_DATA))
            {
                VCCB_PRINTF("[VCCB_AuditPld] VCCB_RegisterSinglePLD Error!! (relId:0x%X, relName:%s, retVal:%d)\n", pPld->relId,
                    pPld->relName, result);
            }
        }
#endif
#endif

        FnVCCB_UpdatePldAuditHistory(pPld->relId, result);
        relIdx++;
        break;
    }

    CFG->pld.curAuditRelIdx = relIdx;
    CFG->pld.isInPldAuditProcessing = VCCB_FLAG_OFF;

    return;
}

int32_t FnVCCB_ReadOneCbrsCellCarrierInfo(const PLDCbrsCellCarrierInfo *pBuf)
{
    // Read Success: Return cellNum
    // Read Fail:    Return ERROR

    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pBuf);

    if (EQUIP != pBuf->status)
    {
        // not update in this case, gNBId and cellId may not be reliable when N_EQUIP
        return ERROR;
    }

    uint16_t pldGnbNum = pBuf->gnbNum;
    uint16_t cellId = pBuf->cellId;

    VCCB_CHECK_E_RANGE_AND_RETURN(cellId, MAX_CELL_IDENTITY);

    uint16_t gnbNum = FnVCCB_GetGnbNumFromIdOrIdx(pBuf->gNBId, pldGnbNum);
    if (MAX_GNB_PER_SYS <= gnbNum)
    {
        if (pBuf->status == EQUIP)
        {
            // If buf.status == EQUIP and gnbNum is out of range, something went wrong!
            VCCB_PRINTF("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,pldGnbNum:%d)\n", __func__, pBuf->gNBId, pldGnbNum);
            VCCB_PRINT_ERROR("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,pldGnbNum:%d)\n", __func__, pBuf->gNBId, pldGnbNum);
        }
        return ERROR;
    }

    uint16_t cellNum = GNBINFO[gnbNum].env.cellNum[cellId];
    if (MAX_CELL_NUM_VCCB <= cellNum)
    {
        return ERROR;
    }

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    if (EQUIP != pCell->status)
    {
        return ERROR;
    }

    cbrsInfo_type *pCbrsInfo = &pCell->cbrsInfo;
    pCbrsInfo->numOfCbrsCarrierInfo = (uint8_t)MIN(pBuf->carrierCnt, VCCB_ARRAY_COUNT(pCbrsInfo->cbrsCarrierInfo));
    pCbrsInfo->numOfCbrsCarrierInfo = (uint8_t)MIN(pCbrsInfo->numOfCbrsCarrierInfo, VCCB_ARRAY_COUNT(pBuf->cbrsSsbArfcn));
    uint16_t carrierCntLoop = 0;
    for (carrierCntLoop = 0; carrierCntLoop < pCbrsInfo->numOfCbrsCarrierInfo; carrierCntLoop++)
    {
        pCbrsInfo->cbrsCarrierInfo[carrierCntLoop].ssbArfcn = pBuf->cbrsSsbArfcn[carrierCntLoop];
        pCbrsInfo->cbrsCarrierInfo[carrierCntLoop].umfsCurrentCallCnt = 0;
    }

    return cellNum;
}

int16_t VCCB_getRel_PLDCbrsCellCarrierInfo(void)
{
    AUTO_TRACE_FUNC;
    STANDBY_RETURN_OK;

    int result;
    uint32_t loop = 0;
    relationInfo relInfo;
    VccbPldBuffer pldBuffer;

    result = FnVCCB_GetRelationInfo(REL_CBRS_CELL_CARRIER_INFO_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    const int maxCellNum = MAX_CELL_NUM_VCCB;
    bool updateFlag[MAX_CELL_PER_VNF] = {false};

    uint32_t numOfTuple = MIN(relInfo.numOfMaxTuple, relInfo.numOfTuple);
    if (numOfTuple > 0)
    {
        PLDCbrsCellCarrierInfo *buf;

        MACRO_GET_RELATION(PLDCbrsCellCarrierInfo, REL_CBRS_CELL_CARRIER_INFO_ID, relInfo);

        for (loop = 0; loop < numOfTuple; loop++)
        {
            int32_t cellNum = FnVCCB_ReadOneCbrsCellCarrierInfo(&buf[loop]);
            if (ERROR != cellNum) updateFlag[cellNum] = true;
        }
    }

    // In case buf[loop].status = N_EQUIP, pld parameters except key value are unreliable.
    // Hence, initialization of VCCB DB shall proceeds like below.
    VccbCellInfo_type *pCellInfo = CELLINFO;
    for (int cellNum = 0; cellNum < maxCellNum; cellNum++)
    {
        if (updateFlag[cellNum] == false)
        {
            pCellInfo[cellNum].cbrsInfo.numOfCbrsCarrierInfo = 0;
        }
    }

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}

void FnVCCB_InitPldNrCellPlmnInfo(VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pCell);

    memset(&pCell->cellPlmn, 0, sizeof(pCell->cellPlmn));
    memset(pCell->cellPlmnIndexInfo, 0, sizeof(pCell->cellPlmnIndexInfo));
}

void FnVLIB_UpdatePldNrCellPlmnInfo(VccbCellInfo_type *pCell, PLDNrCellPlmnInfo *ptrBuf)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pCell);
    VALID_E_POINT_CHECK_VOID(ptrBuf);

    uint32_t loop = 0;
    uint32_t numOfSnssaiGrpPerPlmn = 0;

    /* intraGnbNbrInfo */
    for (loop = 0; loop < MAX_PLMN_INDEX; loop++)
    {
        pCell->intraGnbNbrInfo.cellPlmnInfo[loop].shmStatus = N_EQUIP;
    }

    uint8_t numOfPlmn = MIN(ptrBuf->servedPlmnCnt, MAX_PLMN_INDEX);
    for (loop = 0; loop < numOfPlmn; loop++)
    {
        /* cellPlmn */
        pCell->cellPlmn.servedPlmn[loop] = ptrBuf->servedPlmn[loop];

        pCell->cellPlmn.supportedSnssaiGrpCntPerPlmn[loop] = ptrBuf->supportedSnssaiGrpCntPerPlmn[loop];
        numOfSnssaiGrpPerPlmn = (uint8_t)MIN(ptrBuf->supportedSnssaiGrpCntPerPlmn[loop], MAX_SNSSAI_GRP_PER_PLMN_CELL);

        for (uint32_t iNssai = 0; iNssai < numOfSnssaiGrpPerPlmn; iNssai++)
        {
            pCell->cellPlmn.supportedSnssaiGrp[loop][iNssai] = ptrBuf->supportedSnssaiGrp[loop][iNssai];
            pCell->cellPlmn.supportedSnssaiGrpLength[loop][iNssai] = ptrBuf->supportedSnssaiGrpLength[loop][iNssai];
        }

        /* intraGnbNbrInfo */
        pCell->intraGnbNbrInfo.cellPlmnInfo[loop].shmStatus = EQUIP;
        pCell->intraGnbNbrInfo.cellPlmnInfo[loop].longId = pCell->cellPlmn.servedPlmn[loop];
        pCell->intraGnbNbrInfo.cellPlmnInfo[loop].plmnIndex = loop;
    }
    
    pCell->cellPlmn.numOfPLMN = numOfPlmn;
    VLIB_Store_PLDCellPlmnIndexInfo(pCell);
}

int16_t VCCB_getRel_PLDNrCellPlmnInfo(void)
{
    AUTO_TRACE_FUNC;
    STANDBY_RETURN_OK;

    int result;
    uint32_t loop = 0;
    uint16_t cellNum = MAX_CELL_NUM_VCCB;
    uint16_t gnbNum = 0;
    relationInfo relInfo;
    VccbPldBuffer pldBuffer;

    result = FnVCCB_GetRelationInfo(REL_NR_CELL_PLMN_INFO_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    bool updateFlag[MAX_CELL_NUM_VCCB] = {false};

    uint32_t numOfTuple = MIN(relInfo.numOfMaxTuple, relInfo.numOfTuple);
    if (numOfTuple > 0)
    {
        PLDNrCellPlmnInfo *buf;

        MACRO_GET_RELATION(PLDNrCellPlmnInfo, REL_NR_CELL_PLMN_INFO_ID, relInfo);

        PLDNrCellPlmnInfo *ptrBuf = NULL;
        for (loop = 0; loop < numOfTuple; loop++)
        {
            ptrBuf = &buf[loop];

            if (ptrBuf->status != EQUIP) continue;

            gnbNum = FnVCCB_GetGnbNumFromIdOrIdx(ptrBuf->gNBId, ptrBuf->gnbNum);
            if (gnbNum >= MAX_GNB_PER_SYS)
            {
                // If buf.status == EQUIP and gnbNum is out of range, something went wrong!
                VCCB_PRINTF("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,pldGnbNum:%d)\n", __func__, ptrBuf->gNBId, ptrBuf->gnbNum);
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,pldGnbNum:%d)\n", __func__, ptrBuf->gNBId, ptrBuf->gnbNum);
                continue;
            }
            
            VCCB_CHECK_E_RANGE_AND_CONTINUE(ptrBuf->cellId, MAX_CELL_IDENTITY);
            cellNum = FnVCCB_GetCellNum(gnbNum, ptrBuf->cellId);
            if (cellNum >= MAX_CELL_NUM_VCCB)
            {
                VCCB_PRINT_ERROR("FnVCCB_GetCellNum  ERROR!! for cellNum(%d) / cellId(%d)\n", cellNum, ptrBuf->cellId);
                continue;
            }

            VccbCellInfo_type *pCell = &CELLINFO[cellNum];

            /* served-plmn & S-NSSAI*/  // --> move from PLDNrCellStatusInfo
            FnVLIB_UpdatePldNrCellPlmnInfo(pCell, ptrBuf);
            updateFlag[cellNum] = true;

            if (VCCB_IS_HAS_BACKUP_REQUIRED_DURING_PLD_READ_PER_RELATION())
            {
                FnVCCB_BackupCellInfo(cellNum);
            }
        }
    }

    // Initialize cellPlmnInfo when there is not information in PLD
    for( loop = 0; loop < MAX_CELL_NUM_VCCB; loop++ )
    {
        if( updateFlag[loop] == false)
        {
            VccbCellInfo_type *pCell = &CELLINFO[loop];
            FnVCCB_InitPldNrCellPlmnInfo(pCell);
        }
    }

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}



int16_t VCCB_getRel_PLDAupfPlmnInfo(void)
{
    AUTO_TRACE_FUNC;
    STANDBY_RETURN_OK;

    int result;
    uint32_t loop = 0;
    relationInfo relInfo;
    VccbPldBuffer pldBuffer;

    result = FnVCCB_GetRelationInfo(REL_AUPF_PLMN_INFO_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    bool updateFlag[MAX_GNB_PER_SYS][MAX_GNB_CU_UP_PER_GNB_CU_CP] = {false};

    uint32_t numOfTuple = MIN(relInfo.numOfMaxTuple, relInfo.numOfTuple);
    if (numOfTuple > 0)
    {
        PLDAupfPlmnInfo *buf;

        MACRO_GET_RELATION(PLDAupfPlmnInfo, REL_AUPF_PLMN_INFO_ID, relInfo);

        for (loop = 0; loop < numOfTuple; loop++)
        {
            if (buf[loop].status != EQUIP) continue;

            uint16_t gnbIdx = buf[loop].gNBIdx;
            int endPointIdx = buf[loop].endPointIdx;
            VCCB_CHECK_E_RANGE_AND_CONTINUE(endPointIdx, MAX_GNB_CU_UP_PER_GNB_CU_CP);

            uint16_t gnbNum = FnVCCB_GetGnbNumFromIdOrIdx(buf[loop].gNBId, gnbIdx);
            if (MAX_GNB_PER_SYS <= gnbNum)
            {
                VCCB_PRINTF("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gNBId, gnbIdx);
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gNBId, gnbIdx);
                continue;
            }

            FnVCCB_SetAupfStautsInfo_PLDAupfPlmnInfo(&GNBINFO[gnbNum].aupf.gnbCuUp[endPointIdx], &buf[loop]);
            
            updateFlag[gnbNum][endPointIdx] = true;
        }
    }

    // Initialize AupfStatusInfo when there is not information in PLD
    for( uint32_t gnbIdx = 0; gnbIdx < MAX_GNB_PER_SYS; gnbIdx++ )
    {
        for( uint32_t endPointIdx = 0; endPointIdx < MAX_GNB_CU_UP_PER_GNB_CU_CP; endPointIdx++ )
        {
            if( updateFlag[gnbIdx][endPointIdx] == false)
            {
                FnVCCB_InitAupfStautsInfo_PLDAupfPlmnInfo(&GNBINFO[gnbIdx].aupf.gnbCuUp[endPointIdx]);
            }
        }
    }

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}


int16_t VCCB_getRel_PLDAmfPlmnInfo(void)
{
    AUTO_TRACE_FUNC;

    int result;
    uint32_t loop = 0;
    relationInfo relInfo;
    VccbPldBuffer pldBuffer;

    result = FnVCCB_GetRelationInfo(REL_AMF_PLMN_INFO_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    VccbCfgInfo_type *pCfg = CFG;
    bool updateFlag[MAX_GNB_PER_SYS][MAX_AMF_PER_GNB_CU_CP] = {false};

    uint32_t numOfTuple = MIN(relInfo.numOfMaxTuple, relInfo.numOfTuple);
    if (numOfTuple > 0)
    {
        PLDAmfPlmnInfo *buf;

        MACRO_GET_RELATION(PLDAmfPlmnInfo, REL_AMF_PLMN_INFO_ID, relInfo);

        for (loop = 0; loop < numOfTuple; loop++)
        {
            if (buf[loop].status != EQUIP) continue;

            uint16_t gnbIdx = buf[loop].gNBIdx;
            int endPointIdx = buf[loop].endPointIdx;

            VCCB_CHECK_E_RANGE_AND_CONTINUE(endPointIdx, MAX_AMF_PER_GNB_CU_CP);

            uint16_t gnbNum = FnVCCB_GetGnbNumFromIdOrIdx(buf[loop].gNBId, gnbIdx);
            if (MAX_GNB_PER_SYS <= gnbNum)
            {
                VCCB_PRINTF("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gNBId, gnbIdx);
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,gnbIdx:%d)\n", __func__, buf[loop].gNBId, gnbIdx);
                continue;
            }

            memcpy(&pCfg->amf.pldAmfPlmnInfo[gnbNum][endPointIdx], &buf[loop], sizeof(PLDAmfPlmnInfo));

            updateFlag[gnbNum][endPointIdx] = true;
        }
    }

    // Initialize AmfPlmnInfo when there is not information in PLD
    for (int gnbNum = 0; gnbNum < MAX_GNB_PER_SYS; gnbNum++)
    {
        for(int endPointIdx = 0; endPointIdx < MAX_AMF_PER_GNB_CU_CP; endPointIdx++)
        {
            if (updateFlag[gnbNum][endPointIdx] == false)
            {
                memset(&pCfg->amf.pldAmfPlmnInfo[gnbNum][endPointIdx], 0, sizeof(PLDAmfPlmnInfo));
            }
        }
    }

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}

// This is a temporary enum until FGR-LC0740 implements it in a common header file
namespace
{
typedef enum
{
    disable = 0,
    update = 1,
    fallback = 2,
    lbmParaConfigStateMax
} enum_NrLbmParaConfigState_type;
};

void FnVCCB_DecideAndSetNrLbmConfigIndex(const PLDSonOpStatus *pBuf, VccbCellInfo_type &rCell, const CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pBuf);

    if (!FOO.VF_NR_LBM)
    {
        return;
    }

    if (pBuf->lbmParaConfigState >= enum_NrLbmParaConfigState_type::lbmParaConfigStateMax)
    {
        VCCB_PRINT_ERROR("[LBM] Received invalid LBM update for cellNum(%u): lbmParaConfigState out of range (%d)!\n",
                cellNum, pBuf->lbmParaConfigState);
        return;
    }

    // Window state is irrelevant when lbmParaConfigState is disable
    if (pBuf->lbmParaConfigState == enum_NrLbmParaConfigState_type::disable)
    {
        rCell.nrLbmConfigurationIndex = NR_LBM_DISABLE;
        VCCB_PRINT_COMMENT("[LBM] CellNum(%u) selected index(%u)\n", cellNum, NR_LBM_DISABLE);
        return;
    }

    if (pBuf->lbmWindowState > MAX_NR_LBM_WINDOW_STATE)
    {
        VCCB_PRINT_ERROR("[LBM] Received invalid LBM update for cellNum(%u): lbmWindowState out of range (%d)!\n",
                cellNum, pBuf->lbmWindowState);
        return;
    }

    enumNrLbmConfigurationIndex_type newNrLbmConfigIndex = rCell.nrLbmConfigurationIndex;
    switch (pBuf->lbmWindowState)
    {
        case 0:
        {
            switch (pBuf->lbmParaConfigState)
            {
                case enum_NrLbmParaConfigState_type::update:
                {
                    newNrLbmConfigIndex = enumNrLbmConfigurationIndex_type::NR_LBM_WINDOW0_UPDATE;
                    break;
                }
                case enum_NrLbmParaConfigState_type::fallback:
                {
                    newNrLbmConfigIndex = enumNrLbmConfigurationIndex_type::NR_LBM_WINDOW0_FALLBACK;
                    break;
                }
                default:
                    break;
            }
            break;
        }
        case 1:
        {
            switch (pBuf->lbmParaConfigState)
            {
                case enum_NrLbmParaConfigState_type::update:
                {
                    newNrLbmConfigIndex = enumNrLbmConfigurationIndex_type::NR_LBM_WINDOW1_UPDATE;
                    break;
                }
                case enum_NrLbmParaConfigState_type::fallback:
                {
                    newNrLbmConfigIndex = enumNrLbmConfigurationIndex_type::NR_LBM_WINDOW1_FALLBACK;
                    break;
                }
                default:
                    break;
            }
            break;
        }
        default:
            break;
    }
    rCell.nrLbmConfigurationIndex = newNrLbmConfigIndex;
    VCCB_PRINT_COMMENT("[LBM] CellNum(%u) selected index(%u)\n", cellNum, newNrLbmConfigIndex);

    return;
}

void FnVCCB_ReadOneSonOpState(const PLDSonOpStatus *pBuf)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pBuf);

    auto &indexManager = PldSonOpStatusIndexManager::instance();

    auto cellNum = indexManager.getCellNumOfDbIndex(pBuf->dbIndex);
    if (cellNum < MAX_CELL_NUM_VCCB)
    {
        // Clean TSM state of old cell for cellIdentity changed or tuple delete case...
        CELLINFO[cellNum].tsmConfig.state       = tsmState_Disable;
    }

    // Soft-delete case, tuple still exists in valkey but status == N_EQUIP
    // For hard-delete case (tuple deleted from valkey) see VCCB_getTuple_PLDSonOpState
    if (EQUIP != pBuf->status)
    {
        if (MAX_CELL_NUM_VCCB <= cellNum)
        {
            VCCB_PRINT_COMMENT("[SonOpStatus] Attempted to soft-delete dbIndex(%u) but it was already free!\n", pBuf->dbIndex);
            return;
        }

        // LBM cleanup
        CELLINFO[cellNum].nrLbmConfigurationIndex = NR_LBM_DISABLE;

        indexManager.deleteDbIndex(pBuf->dbIndex);
        return;
    }

    uint16_t pldGnbNum = pBuf->gnbNum;
    uint16_t cellId = pBuf->cellIdentity;

    VCCB_CHECK_E_RANGE_AND_VOID(cellId, MAX_CELL_IDENTITY);

    uint16_t gnbNum = FnVCCB_GetGnbNumFromIdOrIdx(pBuf->gnbId, pldGnbNum);
    if (MAX_GNB_PER_SYS <= gnbNum)
    {
        if (pBuf->status == EQUIP)
        {
            // If buf.status == EQUIP and gnbNum is out of range, something went wrong!
            VCCB_PRINTF("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,pldGnbNum:%d)\n", __func__, pBuf->gnbId, pldGnbNum);
            VCCB_PRINT_ERROR("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,pldGnbNum:%d)\n", __func__, pBuf->gnbId, pldGnbNum);
        }
        return;
    }

    cellNum = GNBINFO[gnbNum].env.cellNum[cellId];
    VCCB_CHECK_VALID_CELLNUM_VOID(cellNum); 

    VccbCellInfo_type &rCell = CELLINFO[cellNum];
    if (EQUIP != rCell.status)
    {
        VCCB_PRINT_ERROR("[SonOpStatus] Received PLDSonOpState update for not equipped cellNum(%u)!\n", cellNum);
        return;
    }

    indexManager.insertDbIndexCellNumPair(pBuf->dbIndex, cellNum);
    FnVCCB_DecideAndSetNrLbmConfigIndex(pBuf, rCell, cellNum);

    rCell.sammConfig.windowState = pBuf->sammWindowState;
    rCell.sammConfig.paraConfigState = pBuf->sammParaConfigState;

    rCell.tsmConfig.configuredIndex = pBuf->tsmWindowState;
    rCell.tsmConfig.state           = pBuf->tsmParaConfigState;

    return;
}

int16_t VCCB_getRel_PLDSonOpState(void)
{
    AUTO_TRACE_FUNC;
    STANDBY_RETURN_OK;

    int result;
    uint32_t loop = 0;
    relationInfo relInfo;
    VccbPldBuffer pldBuffer;

    result = FnVCCB_GetRelationInfo(REL_SON_OP_STATUS_ID, &relInfo);
    if (result < 0)
    {
        return (int16_t)result;
    }

    // Init TSM state(disable) of all cells
    for (CellNum_type cellNum = 0; cellNum < MAX_CELL_NUM_VCCB; cellNum++)
    {
        CELLINFO[cellNum].tsmConfig.state       = tsmState_Disable;
    }

    uint32_t numOfTuple = MIN(relInfo.numOfMaxTuple, relInfo.numOfTuple);
    if (numOfTuple > 0)
    {
        PLDSonOpStatus *buf;

        MACRO_GET_RELATION(PLDSonOpStatus, REL_SON_OP_STATUS_ID, relInfo);

        for (loop = 0; loop < numOfTuple; loop++)
        {
            FnVCCB_ReadOneSonOpState(&buf[loop]);
        }
    }

    VCCB_PRINTF_PLD_INITIAL_READ("%s done\n", __func__);

    return GOOD;
}
