#ifndef VCCB_CDB_CdbPldBuffer_H_
#define VCCB_CDB_CdbPldBuffer_H_

#include <iostream>

class VccbPldBuffer
{
private:
    char* pBuf;

public:
    VccbPldBuffer() 
    {
        this->pBuf = NULL;
    }
    ~VccbPldBuffer() 
    {
        if (this->pBuf != NULL)
        {
            free(this->pBuf); 
            this->pBuf = NULL;
        }
    }

    char* allocBuffer(size_t buffSize)
    {
        if (this->pBuf != NULL)
        {
            free(this->pBuf); 
            this->pBuf = NULL;
        }

        this->pBuf = (char *)malloc(buffSize);
        return this->pBuf;
    }
#ifdef IPC_TEST
    char* getBuffer()
    {
        return this->pBuf;
    }
#endif
};

#endif  // VCCB_CDB_CdbPldBuffer_H_
