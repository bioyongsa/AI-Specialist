#ifndef VCCB_CDB_CdbDalReader_H_
#define VCCB_CDB_CdbDalReader_H_

#include "ComInclude.min.h"
#include "CdbUtil.h"
 
#include <type_traits>
 
#define ZERO               0
#define VDAL_MAX_YANG_PATH 512
 
#define TYPECAST(ref, val)  static_cast<typename std::remove_reference<decltype(ref)>::type>(val)
 
#define VCCB_CONV_D64_TO_DOUBLE(_var) ((double)_var.value / (pow((double)(10), (double)(_var.fraction_digits))))
#define VCCB_GET_ATTR(_attr, _pV)                                               \
    do                                                                          \
    {                                                                           \
        switch ((_pV)->type)                                                    \
        {                                                                       \
            case DAL_C_NOEXISTS:                                                \
                break;                                                          \
            case DAL_C_INT8:                                                    \
                _attr = TYPECAST(_attr, DAL_GET_INT8(_pV));                     \
                break;                                                          \
            case DAL_C_INT16:                                                   \
                _attr = TYPECAST(_attr, DAL_GET_INT16(_pV));                    \
                break;                                                          \
            case DAL_C_INT32:                                                   \
                _attr = TYPECAST(_attr, DAL_GET_INT32(_pV));                    \
                break;                                                          \
            case DAL_C_INT64:                                                   \
                _attr = TYPECAST(_attr, DAL_GET_INT64(_pV));                    \
                break;                                                          \
            case DAL_C_UINT8:                                                   \
                _attr = TYPECAST(_attr, DAL_GET_UINT8(_pV));                    \
                break;                                                          \
            case DAL_C_UINT16:                                                  \
                _attr = TYPECAST(_attr, DAL_GET_UINT16(_pV));                   \
                break;                                                          \
            case DAL_C_UINT32:                                                  \
                _attr = TYPECAST(_attr, DAL_GET_UINT32(_pV));                   \
                break;                                                          \
            case DAL_C_UINT64:                                                  \
                _attr = TYPECAST(_attr, DAL_GET_UINT64(_pV));                   \
                break;                                                          \
            case DAL_C_DOUBLE:                                                  \
                _attr = TYPECAST(_attr, DAL_GET_DOUBLE(_pV));                   \
                break;                                                          \
            case DAL_C_BOOL:                                                    \
                _attr = TYPECAST(_attr, DAL_GET_BOOL(_pV));                     \
                break;                                                          \
            case DAL_C_ENUM_VALUE:                                              \
                _attr = TYPECAST(_attr, DAL_GET_ENUM_VALUE(_pV));               \
                break;                                                          \
            case DAL_C_BIT32:                                                   \
                _attr = TYPECAST(_attr, DAL_GET_BIT32(_pV));                    \
                break;                                                          \
            case DAL_C_BIT64:                                                   \
                _attr = TYPECAST(_attr, DAL_GET_BIT64(_pV));                    \
                break;                                                          \
            case DAL_C_DECIMAL64:                                               \
                _attr = TYPECAST(_attr, VCCB_CONV_D64_TO_DOUBLE(DAL_GET_DECIMAL64(_pV)));\
                break;                                                          \
            default:                                                            \
                VCCB_PRINTF("DAL value type(%d) not suported!\n", (_pV)->type); \
                break;                                                          \
        }                                                                       \
    } while (0)
 
#ifdef NEW_HOST_SIM
namespace BitFieldSize
{
template<typename T>
constexpr auto getBitFieldSize(T data, size_t startBit = 0) -> typename std::enable_if<std::is_unsigned<T>::value, size_t>::type
{
    return (startBit == sizeof(T) * 8) ? 0 :
        getBitFieldSize(data, startBit + 1) + ((data & (1ull << startBit)) ? 1 : 0);
}
 
// ignore warnings which are occurred when making temporary struct for calculating bit field size
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wmissing-field-initializers"
#pragma GCC diagnostic ignored "-Woverflow"
 
template<typename StructType, typename StructFieldsType, StructFieldsType ...initVals>
constexpr StructType getFilledStructImpl(StructType s, ...)
{
    return s;
}
 
template<typename StructType, typename StructFieldsType, StructFieldsType ...initVals>
constexpr StructType getFilledStructImpl(StructType, decltype(StructType{ initVals... }, int()) = 0)
{
    return getFilledStructImpl<StructType, StructFieldsType, initVals..., 
        static_cast<StructFieldsType>(-1)> (StructType { initVals... }, 0); 
}
 
template<typename StructType, typename StructFieldsType>
constexpr StructType getFilledStruct()
{
    return getFilledStructImpl<StructType, StructFieldsType>(StructType{}, 0);
}
 
#pragma GCC diagnostic pop
}
#define bitFieldSizeOf(structType, fieldName) \
    ::BitFieldSize::getBitFieldSize(::BitFieldSize::getFilledStruct<structType, decltype(structType{}.fieldName)>().fieldName)
#endif
 
#define VCCB_GET_ATTR_BIT(_attr, _pV, _nbit)                                    \
    do                                                                          \
    {                                                                           \
        uint64_t temp = _attr; \
        VCCB_GET_ATTR(temp, _pV); \
        _attr = temp & _nbit; \
    } while (0)
 
#define VCCB_GET_ATTR_W_PRESENT_S(_attr, _pV, _present, _min, _max) \
    do                                                              \
    {                                                               \
        uint8_t isCheck = OPT_NOT_PRESENT;                          \
        if ((_pV)->type != DAL_C_NOEXISTS)                          \
        {                                                           \
            VCCB_GET_ATTR((_attr), (_pV));                          \
            if ((_min) <= (_attr) && (_attr) <= (_max))             \
            {                                                       \
                isCheck = OPT_PRESENT;                              \
            }                                                       \
        }                                                           \
        (_present) = (unsigned)(isCheck & 1);                       \
    } while (0)
 
#define VCCB_GET_ATTR_W_PRESENT_U(_attr, _pV, _present, _max) \
    do                                                        \
    {                                                         \
        uint8_t isCheck = OPT_NOT_PRESENT;                    \
        if ((_pV)->type != DAL_C_NOEXISTS)                    \
        {                                                     \
            VCCB_GET_ATTR((_attr), (_pV));                    \
            if ((_attr) <= (_max))                            \
            {                                                 \
                isCheck = OPT_PRESENT;                        \
            }                                                 \
        }                                                     \
        (_present) = (unsigned)(isCheck & 1);                 \
    } while (0)
 
#define VCCB_GET_ATTR_W_PRESENT_WO_RANGE(_attr, _pV, _present) \
    do                                                         \
    {                                                          \
        uint8_t isCheck = OPT_NOT_PRESENT;                     \
        if ((_pV)->type != DAL_C_NOEXISTS)                     \
        {                                                      \
            VCCB_GET_ATTR((_attr), (_pV));                     \
            isCheck = OPT_PRESENT;                             \
        }                                                      \
        (_present) = (unsigned)(isCheck & 1);                  \
    } while (0)
 
#define VCCB_GET_STR(_attr, _pV, _func, _ret)                                \
    do                                                                       \
    {                                                                        \
        if ((_pV)->type != DAL_C_NOEXISTS)                                   \
        {                                                                    \
            _ret = VDAL_StringToInternal((_pV), __func__, (_func), (_attr)); \
            if (_ret == ERROR)                                               \
            {                                                                \
                VCCB_PRINTF("VDAL_StringToInternal Error!!\n");              \
            }                                                                \
        }                                                                    \
    } while (0)
 
#define VCCB_GET_STR_W_PRESENT(_attr, _pV, _func, _ret, _present) \
    do                                                            \
    {                                                             \
        uint8_t isCheck = OPT_NOT_PRESENT;                        \
        if ((_pV)->type != DAL_C_NOEXISTS)                        \
        {                                                         \
            VCCB_GET_STR(_attr, _pV, _func, _ret);                \
            if (_ret == GOOD)                                     \
            {                                                     \
                isCheck = OPT_PRESENT;                            \
            }                                                     \
        }                                                         \
        (_present) = (unsigned)(isCheck & 1);                     \
    } while (0)
 
typedef enum
{
    CONFIGURATIONAL = 0,
    OPERATIONAL,
    PRE_CONFIGURATIONAL
} dal_connection_type;
 
typedef enum
{
    CRITICAL = 0,
    NON_CRITICAL
} criticality_type;
 
typedef struct
{
    dalFuncId_type FunctionId;
    const char *FunctionName;
    const char *KeyPath;
    int (*ReadFunction)(int, int, uint16_t);
    criticality_type Criticality;
} VccbDalReadInfo_type;
 
typedef struct
{
    struct dal_cs_node *tupleStructure;
    int valuesCount;
    dal_value_t *values;
} VDAL_Tuple;
 
typedef struct
{
    dal_connection_type mode;
    char *pModeString;
 
    int conf;
    int oper;
} VDAL_Socket;
 
typedef struct
{
    struct dal_cs_node *object;
    dal_value_t *vtab;
    int v_size;
} VDAL_Data;
 
typedef struct
{
    char structPath[VDAL_MAX_YANG_PATH + 1];
    char objectPath[VDAL_MAX_YANG_PATH + 1];
} VDAL_PathBuffer;
 
typedef struct
{
    VDAL_Socket sock;
    VDAL_Data dal;
    VDAL_PathBuffer path;
    int32_t listNum;
} VccbDalCommonInfo_type;

/* Func declaration section --> */
int16_t VDAL_Convert_MccToPlmn(const char *, const int, const char *, void *);
int16_t VDAL_Convert_MncToPlmn(const char *, const int, const char *, void *);
int16_t VDAL_StringToInternal(dal_value_t *, const char *, int16_t (*)(const char *, const int, const char *, void *), void *);
int32_t VDAL_GetNumInstances(VccbDalCommonInfo_type *);
int VDAL_GenerateDalData(VccbDalCommonInfo_type *);
void VDAL_FreeDalData(VccbDalCommonInfo_type *);
bool VDAL_isCheckYangPath(const char *keyPath);
int VDAL_ProcGnbCuCpFunctionEntriesWithEndPointXnWithAmfInformation(
    VccbDalCommonInfo_type *, uint16_t, uint16_t, uint32_t);
int VDAL_ProcGnbCuCpFunctionEntriesWithEndPointXn(VccbDalCommonInfo_type *, uint16_t, uint16_t);
int VDAL_ProcGnbCuCpFunctionEntriesWithHoBlackListXnEntries(VccbDalCommonInfo_type *, uint16_t, uint16_t);
int VDAL_ProcGnbCuCpFunctionEntries(
    int, int, uint16_t, dal_connection_type, int (*)(VccbDalCommonInfo_type *, uint16_t, uint16_t));
int VDAL_VnbCall_TceIpFromFqdn_OperRead(int confSocket, int operSocket, uint16_t readGnbNum);

int VDAL_EstablishReadConnection(int *, dal_connection_type);

int VDAL_VnbCall_ReportConfigEntries_ReadEntry(dal_hkeypath_t *modKeypath, reportConfigurationDb_type *pReportConfig,
    VccbCellInfo_type *pCell, uint8_t reportConfigKey);
int VDAL_VnbCall_Cell_OperRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_NeId_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_Nano_Support_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_CallSuccessRatioLowAlarm_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_GnbInfo_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_DuGnbInfo_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_CuPlmnInfo_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_PlmnInfo_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_Cell_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_CellNeighborRelations_ConfigRead(
    int confSocket, uint16_t *nbrGnbIdx, uint32_t cellNum, uint32_t cellIdentity, uint32_t *totalNbr);
int VDAL_VnbCall_VoMA_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_CellNeighborRelations_OperRead(int operSocket, uint16_t gnbIdx, uint32_t cellNum, uint32_t cellIdentity);
int VDAL_VnbCall_CellEutraNeighborRelations_ConfigRead(
    int confSocket, uint16_t *nbrGnbIdx, uint32_t cellNum, uint32_t cellIdentity, uint32_t *totalNbr);
int VDAL_VnbCall_CellEutraNeighborRelations_OperRead(
    int operSocket, uint16_t gnbIdx, uint32_t cellNum, uint32_t cellIdentity);
#ifndef __NVGNB__
int VDAL_VnbCall_EndPointF1_OperRead(int confSocket, int readSocket, uint16_t readGnbNum);
#endif
int VDAL_VnbCall_EndPointX2_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_EndPointX2_OperRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_EndPointXn_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_EndPointXn_OperRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_EndPointNg_OperRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_HoBlackListXn_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_TimerInfo_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_RrcSaTimerProfile_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_RrcEndcTimerProfile_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_InactivityDataSA_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_InactivityDataNrdcSN_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_AnrInfoGnb_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_InterRatAnrInfoGnb_Read(int confSocket, int operSocket, uint16_t readGnbNum); // 26A
int VDAL_VnbCall_IdleMobilityControl_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_PeriodicLbInfo_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_CaProfileEntries_Read(int confSocket, uint16_t gnbIdx, uint16_t readGnbNum);
int VDAL_VnbCall_MroInfoGnb_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_DssConfiguration_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_DrxConfig_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_NeighborGNB_ConfigRead(int confSocket, VccbNbrGnbReadInfo_type *gnbNbr, uint32_t *totalNbr);
int VDAL_VnbCall_NeighborENB_ConfigRead(int confSocket, VccbNbrGnbReadInfo_type *enbNbr, uint32_t *totalNbr);
int VDAL_VnbCall_CslData_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_CslOperData_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_ScgFailureHandling_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_DynamicUlPrimaryPathSelection_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_SpidBasedUlPathSwitchingProfileEntries_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_DataForwarding_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_LocalTimeInfo_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_CarrierAggregationInfo_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_MultiCarrierOperation_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_MultiCarrierOperationConfig_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_SpidInfo_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_GnbcpManagement_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_SecurityData_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_EndPointNg_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);
 
int VDAL_VnbCall_MeasurementGap_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_PeriodicA4Measurement_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_LongPeriodicMeasurement_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_PerPlmnQciSupport_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_QciSupport_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_Qos5qiSupport_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_PerPlmnQos5qiSupport_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_PdcpProfile_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_DrxConfigFiveqi_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_ProcGnbCuCpFunctionEntriesWithEndPointNg(VccbDalCommonInfo_type *, uint16_t, uint16_t);
int VDAL_VnbCall_QosDrbMappingConfig_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_InactivityData_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_TraceConfiguration_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_CuUpSelectionConfiguration_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_TraceCell_Read(int readSocket, uint16_t gnbIdx, int cellNum, uint16_t cellIdentity);
int VDAL_VnbCall_ReadCuColocCellInfo(int confSocket, uint16_t gnbIdx, int cellNum, uint16_t cellIdentity);
int VDAL_VnbCall_SliceSupportInfo_ReadForDed(int confSocket, uint16_t gnbIdx, uint16_t gnbNum, uint8_t groupIndex);
int VDAL_VnbCall_SliceSupportInfo_ReadMapRule(int confSocket, uint16_t gnbIdx, uint16_t gnbNum, uint8_t groupIndex);
int VDAL_VnbCall_PlmnSupportInfo_ReadForDed(int confSocket, uint16_t gnbIdx, uint16_t gnbNum, uint8_t groupIndex);
int VDAL_VnbCall_PlmnSupportInfo_ReadMapRule(int confSocket, uint16_t gnbIdx, uint16_t gnbNum, uint8_t groupIndex);
int VDAL_VnbCall_MdtCellIdentity_Read(int readSocket, uint16_t gnbIdx, int cellNum, uint16_t cellIdentity);
int VDAL_VnbCall_MdtTacList_Read(int readSocket, uint16_t gnbIdx, int cellNum, uint16_t cellIdentity);
int VDAL_VnbCall_MdtTaiList_Read(int readSocket, uint16_t gnbIdx, int cellNum, uint16_t cellIdentity);
int VDAL_VnbCall_MdtNeighborInterFreqCellList_Read(int readSocket, uint16_t gnbIdx, int cellNum, uint16_t cellIdentity);
int VDAL_VnbCall_MdtNeighborInterFreqPCIList_Read(
    int readSocket, uint16_t gnbIdx, int cellNum, uint16_t cellIdentity, uint8_t neighborCellIdx, uint32_t dlFreq);
int VDAL_VnbCall_TraceJobType_Read(int readSocket, uint16_t gnbIdx, int cellNum, uint16_t cellIdentity);
int VDAL_VnbCall_RealTimeSgnbAdditionTimer_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_OverloadControlFunc_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_Gnb_NrdcConfig_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_Gnb_ServiceTypeCounter_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_RacsInfo_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);
 
int VDAL_ReadConfigData(uint16_t readGnbNum);
int VDAL_ReadOperationalData(uint16_t readGnbNum);
#ifdef __CNF__
int VDAL_ReadConfigDataByDalFunctionId(dalFuncId_type dalFunctionId);
#endif
 
void VDAL_EndSocketSession(int readSocket);
 
int VDAL_InitialDataReaderApp(void);
 
int VDAL_VnbCall_NedcCellInfo_Read(struct dal_cs_node *object, struct dal_cs_node **curr, int *pIter, dal_value_t *v,
    uint32_t containerParentTag, VccbCellInfo_type *pCell);
int VDAL_VnbCall_NedcPowerConfig_Read(struct dal_cs_node *object, struct dal_cs_node **curr, int *pIter, dal_value_t *v,
    uint32_t containerParentTag, VccbCellInfo_type *pCell);
int VDAL_VnbCall_DualConnectivityControl_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_NedcAmbrConfiguration_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_NrdcControl_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_NrdcAmbrConfiguration_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_NrdcSliceMbrConfiguration_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_NrdcCellInfo_Read(int confSocket, uint16_t gnbIdx, VccbCellInfo_type *pCell);
int VDAL_VnbCall_CongestionAware_Read(int confSocket, uint16_t gnbIdx, VccbCellInfo_type *pCell);
int VDAL_VnbCall_CapabilityRequestFilter_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_MobilityConfigGnb_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_RrcInactiveInfo_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_RrcInactiveInfo_RedCap_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_RrcInactiveInfo_eDRX_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_EmergencyArpInfo_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_EmergencyFiveqiArpCombinationInfo_Read(int confSocket, int gnbIdx, uint8_t plmnIndex, emergencyArpInfo_type *pEmerArpInfo);
int VDAL_VnbCall_ServiceGroupConfig_Read(int confSocket, uint16_t gnbIdx, int gnbNum);
int VDAL_VnbCall_ServiceGroupConfig_ServiceGroupIdEntries_ConfigRead(int confSocket, uint16_t readGnbNum);
int VDAL_VnbCall_UEOverheatingControlInfo_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_UEPowersavingControlInfo_Read(int confSocket, int operSocket, uint16_t readGnbNum);
void VCCB_SetQuantityValue(measTriggerQuantitySetDb_type *arg, enumMeasTriggerQuantityChoice choice, dal_value_t *newv);
void VCCB_SetRedCapQuantityValue(MeasQuantitiesRedCapValues_type &values, const enumMeasTriggerQuantityChoice choice, const dal_value_t &newv);

uint8_t VDAL_VnbCall_GetInterfaceFlag(uint32_t tag);
void VDAL_VnbCall_InitTraceThresholds(GlobalTraceInfo_type *traceInfo, int enumValue);
 
int VDAL_VnbCall_VnfcInfo_Read(int confSocket, int operSocket, uint16_t readGnbNum);  // ODF_HO_21B
int VDAL_VnbCall_UserInactivityFreqControl_Read(int confSocket, int operSocket, uint16_t readGnbNum);
 
int VDAL_VnbCall_FastRlfRecovery_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_CellConfigProfile_Read(struct dal_cs_node *object, struct dal_cs_node **curr, int *pIter,
    dal_value_t *v, uint32_t containerParentTag, VccbCellInfo_type *pCell);
 
int VDAL_VnbCall_RRCSegmentInfo_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_UlRrcSegmentationSupport_Gnb_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_ProcGnbCuCpFunctionEntriesWithUlRrcSegmentationSupport_Gnb(
    VccbDalCommonInfo_type *pCfg, uint16_t gnbIdx, uint16_t gnbNum);
int VDAL_ProcGnbCuCpFunctionEntriesWithUlRrcSegmentationSupport_Gnb_ConfParam(VccbDalCommonInfo_type *pCfg,
    uint16_t gnbIdx, uint16_t gnbNum, struct dal_cs_node *curr, dal_value_t *newv, uint32_t nbrIdx);
int VDAL_VnbCall_UlRrcSegmentationSupport_Enb_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_ProcGnbCuCpFunctionEntriesWithUlRrcSegmentationSupport_Enb(
    VccbDalCommonInfo_type *pCfg, uint16_t gnbIdx, uint16_t gnbNum);
int VDAL_ProcGnbCuCpFunctionEntriesWithUlRrcSegmentationSupport_Enb_ConfParam(VccbDalCommonInfo_type *pCfg,
    uint16_t gnbIdx, uint16_t gnbNum, struct dal_cs_node *curr, dal_value_t *newv, uint32_t nbrIdx);
 
int VDAL_VnbCall_ReleasePreference_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_NrdcScgFailureHandling_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_IratMroInfoGnb_Read(int confSocket, int operSocket, uint16_t readGnbNum);
 
int VDAL_VnbCall_ReadScgBandSelectionConfig(int confSocket, uint16_t gnbIdx, VccbCellInfo_type *pCell);
int VDAL_VnbCall_ResourceThresholdExceededAlarm_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_ResourceThresholdExceededAlarmAttribute_ConfigRead(
    int confSocket, const char *yangPath, VccbAlarmAttribute_type *pAttribute);
int VDAL_VnbCall_CellReselect_CellSvcBasedCrp_Read(int confSocket, uint16_t gnbIdx, VccbCellInfo_type *pCell);
int VDAL_VnbCall_CellReselect_ServiceGroupEntries_NRFrequencyList_Get(int confSocket, uint16_t gnbIdx,
    uint8_t svcGroupIdx, uint32_t cellId, const char *listTagStr, const char *pathForListEntries,
    const char *pathToChange, svcFreqNrItem_type *pObject);
int VDAL_VnbCall_CellReselect_ServiceGroupEntries_EutraFrequencyList_Get(int confSocket, uint16_t gnbIdx,
    uint8_t svcGroupIdx, uint32_t cellId, const char *listTagStr, const char *pathForListEntries,
    const char *pathToChange, svcFreqEutraItem_type *pObject);
int VDAL_VnbCall_SpidBasedStatisticSupport_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_QciAndSpidBasedStatisticSupport_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_RfspBasedCounter_Read(int confSocket, int operSocket, uint16_t readGnbNum);
 
int VDAL_VnbCall_RfspControlOptionExt_Read(struct dal_cs_node *object, struct dal_cs_node **curr, int *pIter,
    dal_value_t *v, controlOptionExt_type *pControlOptionExt);
 
int VDAL_VnbCall_CellCapabilityRequestFilterConfig_Read(struct dal_cs_node *object, struct dal_cs_node **curr, int *pIter,
    dal_value_t *v, uint32_t containerParentTag, VccbCellInfo_type *pCell);
 
int VDAL_VnbCall_OperatorSpecificFreq_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_OperatorSpecificFreqList_Read(int confSocket, uint16_t gnbIdx, uint16_t gnbNum);
 
// NBR_AUDIT_22B Start
void VDAL_ReadGnbNbrData(uint16_t gnbNum, uint16_t *ptStartGnbNum, uint32_t *ptMax_nbrGnbNum);
void VDAL_ProcNbrReadAuditChecker(uint32_t *pSecCnt, uint32_t *pMax_nbrGnbNum, uint16_t *pStartGnbNum);
void VDAL_AuditClearNbrGnbCell(uint16_t gnbNum, uint32_t *baseCnt);
void VDAL_AuditClearNbrEnbCell(uint16_t gnbNum, uint32_t *baseCnt);
void VDAL_AuditCompleteProc(void);
// NBR_AUDIT_22B End
 
int VDAL_VnbCall_ReadSliceIdEntries(int confSocket, int operSocket, uint16_t gnbNum, uint16_t gnbIdx);
 
int VDAL_VnbCall_RedCap_PdcpInfo_Read(int confSocket, int operSocket, uint16_t readGnbNum);
 
int VDAL_VnbCall_SliceAwareLoadBalancing_Read(int confSocket, int operSocket, uint16_t readGnbNum); //SVR23B FGR-LC0710
int VDAL_VnbCall_SliceAwareLoadBalancingEntries_Read(int confSocket, uint16_t gnbIdx, uint16_t gnbNum); //SVR23B FGR-LC0710
int VDAL_VnbCall_SliceLoadControlInfoEntries_Read(int confSocket, int operSocket, uint16_t readGnbNum); //SVR24A FGR-LC0710
int VDAL_VnbCall_SliceLbConfiguration_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_OverloadProtectInfo_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_UlSliceLoadBasedUlPathSwitchingConfiguration_Read(int confSocket, uint16_t gnbIdx, uint16_t gnbNum);

int VDAL_VnbCall_RestrictedSsbFrequencies_Read(int confSocket, int operSocket, uint16_t readGnbNum);

int VDAL_VnbCall_NcdSsbConfig_Read(int confSocket, int operSocket, uint16_t readGnbNum);

void VDAL_VnbCall_GetTceFqdn(const dal_value_t& v, TceAddress_type& tce);
void VDAL_VnbCall_UpdateTraceSessionTceId(ManagementTraceSessionPerCell_type& traceSession);

// SVR24B FGR-CC0300 Service Type Configuration for Statistics
int VDAL_VnbCall_ServiceTypeSa_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_DeviceIdentRequestFilter_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_ManagementTraffic_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_PlmnRfspBasedVonrControl_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_InactivityDataSA_Redcap_Read(int confSocket, int operSocket, uint16_t readGnbNum);

int VDAL_VnbCall_EfficientPaging_Read(int confSocket, int operSocket, uint16_t readGnbNum);
void FnVCCB_UpdateNbrEnbCellIfNoExists(nbrEnbCellInfo_type &rNbrEnbCell, uint32_t tag);
void FnVCCB_UpdateNbrGnbCellIfNoExists(nbrGnbCellInfo_type &rNbrGnbCell, uint32_t tag);

// SVR25A FGR-CC6301 NR Call Priority Access Services
int VDAL_VnbCall_MpsCallInfo_Read(int confSocket, int operSocket, uint16_t readGnbNum);
int VDAL_VnbCall_FiveqiArpCombinationInfo_Read(int confSocket, int gnbIdx, uint8_t plmnIndex, mpsCallInfo_type *pMpsCallInfo);

int VDAL_VnbCall_GracefulReleaseConf_Read(int confSocket, int operSocket, uint16_t readGnbNum);

// SVR25B FGR-CC6101 Multiple PLMN Support
int VDAL_VnbCall_ServiceAvailableInfo_Read(int confSocket, int operSocket, uint16_t readGnbNum);

//FGR-TA0103 CTT Multi CTP Support
#ifdef __CNF__
int VDAL_VnbCall_PodEntries_OperRead(int confSocket, int operSocket, uint16_t readGnbNum);
#endif
int VDAL_VnbCall_SammGnbConfig_Read(int confSocket, int operSocket, uint16_t readGnbNum);

// SVR26A FGR-CC3501 Served UE Connection Status
int VDAL_VnbCall_PlmnSliceCounterConfig_Read(int confSocket, int operSocket, uint16_t readGnbNum);

// SVR26A FGR-CC5000 FR3622
int VDAL_VnbCall_UlInterferenceCellSelectionThresholds_Read(int confSocket, int operSocket, uint16_t readGnbNum);

// SVR26A FGR-SV0401 gNB Service Outage Handling
int VDAL_VnbCall_CallDropRatioHighAlarm_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);

// SVR26A FGR-BC0310 PDCP Duplication
int VDAL_VnbCall_PdcpDuplicationConfig_Read(int confSocket, int operSocket, uint16_t readGnbNum);

// SVR26B FGR-CC0361 Device Aware Call Control
int VDAL_VnbCall_ImeisvFeatureControlInformation_ConfigRead(int confSocket, int operSocket, uint16_t readGnbNum);

#endif  // VCCB_CDB_CdbDalReader_H_
