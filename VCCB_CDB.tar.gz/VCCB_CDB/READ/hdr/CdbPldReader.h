#ifndef VCCB_CDB_CdbPldReader_H_
#define VCCB_CDB_CdbPldReader_H_

#include "ComInclude.min.h"

// Func declaration section //
int16_t VCCB_InitialReadPld(void);

pldInfo_type *GetgPldInfo_();

int16_t VCCB_getRel_PLDDuStatus(void);
int16_t VCCB_getRel_PLDAupfStatus(void);
int16_t VCCB_getRel_PLDAmfStatus(void);
int16_t VCCB_getRel_PLDAmfTnlStatus(void);
int16_t VCCB_getRel_PLDAmfTnlSctpState(void);
int16_t VCCB_getRel_PLDCellStatus(void);
int16_t VCCB_getRel_PLDGnbBarringInfo(void);
int16_t VCCB_getRel_PLDGnbCallState(void);
int16_t VCCB_getRel_PLDCpuUtilExt(void);
int16_t VCCB_getRel_PLDCellTraceStatus(void);
int16_t VCCB_getRel_PLDTraceStatus(void);
int16_t VCCB_getRel_PLDImsiTrace(void);
int16_t VCCB_getRel_PLDCpcUsageState(void);
int16_t VCCB_getRel_PLDEutraCellInfo(void);
int16_t VCCB_getRel_PLDXnGnbStatus(void);
int16_t VCCB_getRel_PLDGnbXnTaiInfo(void);
int16_t VCCB_getRel_PLDCbrsCellCarrierInfo(void);
int16_t VCCB_getRel_PLDNrCellPlmnInfo(void);
int16_t VCCB_getRel_PLDAupfPlmnInfo(void);
int16_t VCCB_getRel_PLDAmfPlmnInfo(void);
int16_t VCCB_getRel_PLDSonOpState(void);


void make_Z_IMSI(PLDImsiTrace *buf);
void VCCB_store_PLDCellStatus_MeasObject(VccbCellInfo_type *pCell, PLDCellStatus *pPld);
void VLIB_GetPldCellStatusParam(PLDCellStatus *ptrBuf, uint16_t gnbNum, uint16_t cellNum);  // VCCB_ARCH_MCD
void FnVCCB_InitPldCellStatusParam(VccbCellInfo_type *pCell);

void FnVCCB_HandleInternalPLDReadRequest(message_type *ptAll);
void FnVCCB_UpdatePldAuditHistory(int relId, int result);
void FnVCCB_HandlePldCellDeleteNoti(const PLDCellStatus *ptrBuf, VccbCellInfo_type *pCell, uint16_t cellNum, enumCellStatusHistoryCause_type eventCause);
void FnVCCB_HandlePldCellIdChangeNoti(const PLDCellStatus *ptrBuf, const uint16_t gnbNum, enumCellStatusHistoryCause_type eventCause);
void FnVCCB_ReleaseCell(VccbCellInfo_type *pCell, uint16_t cellNum);

void FnVCCB_AuditGnbSupportBandInfo(void);

void VCCB_AuditPld(void);
int16_t FnVCCB_IsReadSkipCase(pldInfo_type *pPld, int isReadCase);

int32_t FnVCCB_ReadOneCbrsCellCarrierInfo(const PLDCbrsCellCarrierInfo *pBuf);
void FnVCCB_ReadOneSonOpState(const PLDSonOpStatus *pBuf);

uint16_t FnVCCB_GetGnbNumFromIdOrIdx(uint32_t gnbId, uint16_t gnbIdx);

void FnVLIB_UpdatePldNrCellPlmnInfo(VccbCellInfo_type *pCell, PLDNrCellPlmnInfo *ptrBuf);
void FnVCCB_InitPldNrCellPlmnInfo(VccbCellInfo_type *pCell);
void FnVCCB_InitAupfStautsInfo_PLDAupfStatus(AupfStatusInfo_type *pAupf);
void FnVCCB_SetAupfStautsInfo_PLDAupfStatus(AupfStatusInfo_type *pAupf, PLDAupfStatus *pPLDAupfStatus);
void FnVCCB_InitAupfStautsInfo_PLDAupfPlmnInfo(AupfStatusInfo_type *pAupf);
void FnVCCB_SetAupfStautsInfo_PLDAupfPlmnInfo(AupfStatusInfo_type *pAupf, PLDAupfPlmnInfo *pPLDAupfPlmnInfo);

#endif  // VCCB_CDB_CdbPldReader_H_
