#ifndef VCCB_CDB_CdbFoo_H_
#define VCCB_CDB_CdbFoo_H_

#include "ComInclude.min.h"

typedef enum
{
    e_Unnecessity,
    e_Necessity
} VCCB_Necessity;

VCCB_Necessity VCCB_GetNecessityYangByFOO(const int id);
VCCB_Necessity VCCB_GetNecessityPldByFOO(const int id);

int FnVCCB_ReadDynamicFoo(void);

const char *VCCB_GetFeatureErrStr(int errCause);
BOOL VCCB_checkRetry_ReadDynamicFoo(int errCause);

#endif
