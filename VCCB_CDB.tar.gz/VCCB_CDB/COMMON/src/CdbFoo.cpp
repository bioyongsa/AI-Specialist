
#include "CdbFoo.h"
#include "CdbUtil.h"
#include "ComInclude.h"

#include "NetFeature.h"

/**
 * @brief This function checks the Mandatory YANG according to the runtime environment.
 * @details The purpose of this function is to check the normality of the block by checking the Mandatory YANG depending
 * on the operating environment.
 * @param criticality_type
 * @return true : Mandatory parameters ( In this case, YANG must exist. )
 * @return false : Optional parameters ( In this case, if YANG not exits, skip )
 */
VCCB_Necessity VCCB_GetNecessityYangByFOO(const int id)
{
    int ret;

    AUTO_TRACE_FUNC;

    switch (id)
    {
        case YANG_VCCB_SUBSCRIBE_CELL_EUTRA_NEIGHBOR_RELATION_ENTRIES_ID:
        case YANG_VCCB_READER_NEIGHBOR_ENBCELL_ID:
        case YANG_VCCB_SUBSCRIBE_NEIGHBOR_ENB_CELLENTRIES_ID:
        case YANG_VCCB_SUBSCRIBE_NEIGHBOR_ENB_ENTRIES_ID:
        case YANG_VCCB_READER_QOS_DRB_MAPPINGCONFIG_ID:
        case YANG_VCCB_SUBSCRIBE_QOS_DRBMAPPING_ID:
        case YANG_VCCB_SUBSCRIBE_QOS_DRBMAPPING_DEDICATED_GROUP_ID:
        case YANG_VCCB_SUBSCRIBE_QOS_DRBMAPPING_MAPPING_RULE_ID:
        case YANG_VCCB_READER_ENDPOINT_NG_ID:
        case YANG_VCCB_SUBSCRIBE_ENDPOINT_NG_ENTRIES_ID:
        case YANG_VCCB_READER_DRXCONFIG_ID:
        case YANG_VCCB_READER_TIMERINFO_ID:
        case YANG_VCCB_SUBSCRIBE_TIMERINFO_ID:
        case YANG_VCCB_READER_INACTIVITYDATASA_ID:
        case YANG_VCCB_SUBSCRIBE_INACTIVITYDATASA_ID:
        case YANG_VCCB_READER_CAPABILITY_REQUEST_FILTER_ID:
        case YANG_VCCB_SUBSCRIBE_CAPABILITY_REQUEST_FILTER_ID:
        case YANG_VCCB_READER_VNFC_INFO_ID:     // ODF_HO_21B
        case YANG_VCCB_SUBSCRIBE_VNFC_INFO_ID:  // ODF_HO_21B
        case YANG_VCCB_SUBSCRIBE_EMERGENCY_ARP_INFO_ID:
        case YANG_VCCB_READER_EMERGENCY_ARP_INFO_ID:
        case YANG_VCCB_READER_RELEASE_PREFERENCE_ID:
        case YANG_VCCB_SUBSCRIBE_RELEASE_PREFERENCE_ID:
        case YANG_VCCB_SUBSCRIBE_MPS_CALL_INFO_ID:
        case YANG_VCCB_READER_MPS_CALL_INFO_ID:
        case YANG_VCCB_SUBSCRIBE_QOS_DRBMAPPING_DEDICATED_GROUP_SLICE_INFO_ID:
        case YANG_VCCB_SUBSCRIBE_QOS_DRBMAPPING_MAPPING_RULE_SLICE_INFO_ID:
            ret = (FOO.VF_StandAlone_BasicCallOperationForSa);
            break;

        case YANG_VCCB_SUBSCRIBE_ENDPOINT_XN_ENTRIES_AMF_SETINFORMATION_ENTRIES_ID:
            ret = (FOO.VF_StandAlone_BasicCallOperationForSa);
            break;

        case YANG_VCCB_READER_XN_HOBLACKLIST_ID:
        case YANG_VCCB_SUBSCRIBE_HOBLACKLIST_XN_ENTRIES_ID:
            ret = (FOO.VF_StandAlone_BasicCallOperationForSa && FOO.VF_IntraNrANR);
            break;

        case YANG_VCCB_READER_ANRINFO_GNB_ID:
        case YANG_VCCB_SUBSCRIBE_ANRINFO_GNB_ID:
            ret = FOO.VF_IntraNrANR;
            break;

        case YANG_VCCB_READER_DSS_CONFIGURATION_ID:
        case YANG_VCCB_SUBSCRIBE_DSS_CONFIGURATION_ID:
            ret = FOO.VF_LTENRSpectrumSharing5G;
            break;
        case YANG_VCCB_READER_DUAL_CONNECTIVITY_CONTROL_ID:  // 20C
        case YANG_VCCB_SUBSCRIBE_DUAL_CONNECTIVITY_CONTROL_ID:
        case YANG_VCCB_READER_NEDC_AMBR_CONFIGURATION_ID:
        case YANG_VCCB_SUBSCRIBE_NEDC_AMBR_CONFIGURATION_ID:
            ret = FOO.VF_BasicOperationforNEDC_CALL;
            break;
        case YANG_VCCB_READER_NR_DC_CONTROL_ID:
        case YANG_VCCB_SUBSCRIBE_NR_DC_CONTROL_ID:
        case YANG_VCCB_READER_NRDC_AMBR_CONFIGURATION_ID:
        case YANG_VCCB_SUBSCRIBE_NRDC_AMBR_CONFIGURATION_ID:
        case YANG_VCCB_READER_NRDC_SLICE_MBR_CONFIGURATION_ID:
        case YANG_VCCB_SUBSCRIBE_NRDC_SLICE_MBR_CONFIGURATION_ID:
        case YANG_VCCB_READER_INACTIVITYDATANRDCSN_ID:
        case YANG_VCCB_SUBSCRIBE_INACTIVITYDATANRDCSN_ID:
            ret = FOO.VF_BasicOperationforNRDC_CALL;
            break;
        case YANG_VCCB_READER_RRC_INACTIVE_INFO_ID:
        case YANG_VCCB_SUBSCRIBE_RRC_INACTIVE_INFO_ID:
            ret = FOO.VF_RRCInactiveDay1;
            break;

        case YANG_VCCB_READER_RRC_INACTIVE_INFO_REDCAP_ID:
        case YANG_VCCB_SUBSCRIBE_RRC_INACTIVE_INFO_REDCAP_ID:
            ret = FOO.VF_RRCInactiveDay1 && FOO.VF_BasicCallProcedureforRedCapUE;
            break;

        case YANG_VCCB_READER_RRC_INACTIVE_INFO_EDRX_ID:
        case YANG_VCCB_SUBSCRIBE_RRC_INACTIVE_INFO_EDRX_ID:
            ret = FOO.VF_RRCInactiveDay1 && (not FOO.VF_NrExtendedDrx_NotSupport);
            break;

        case YANG_VCCB_READER_RRC_SEGMENTATION_ID:
        case YANG_VCCB_SUBSCRIBE_RRC_SEGMENTATION_ID:
            ret = FOO.VF_SegmentationOfRrcMessages;
            break;

        case YANG_VCCB_READER_USER_INACTIVITY_FREQ_CONTROL_ID:
        case YANG_VCCB_SUBSCRIBE_USER_INACTIVITY_FREQ_CONTROL_ID:
            ret = FOO.VF_UserInactivityTimer_FrequencyBasedControl;
            break;

        case YANG_VCCB_READER_NANO_SUPPORT_ID:
            ret = FOO.VF_NanomsgSupport;
            break;

        case YANG_VCCB_READER_SPID_BASED_STATISTIC_SUPPORT_ID:
        case YANG_VCCB_SUBSCRIBE_SPID_BASED_STATISTIC_SUPPORT_ID:
            ret = FOO.VF_VzwOnlyCounterFamily;
            break;
        
        case YANG_VCCB_READER_QCI_AND_SPID_BASED_STATISTIC_SUPPORT_ID:
        case YANG_VCCB_SUBSCRIBE_QCI_AND_SPID_BASED_STATISTIC_SUPPORT_ID:
            ret = FOO.VF_VzwOnlyCounterFamily;
            break;

        case YANG_VCCB_READER_RFSP_BASED_COUNTER_ID:
        case YANG_VCCB_SUBSCRIBE_RFSP_BASED_COUNTER_ID:
            ret = FOO.VF_ServedUEConnectionStatus_InclRFSP;
            break;

        case YANG_VCCB_READER_QCISUPPORT_ID:
        case YANG_VCCB_SUBSCRIBE_QCISUPPORT_ID:
            ret = !FOO.VF_QoSSchedulingPerPLMN;
            break;

        case YANG_VCCB_READER_QOS_5QISUPPORT_ID:
        case YANG_VCCB_SUBSCRIBE_QOS_5QISUPPORT_ID:
            ret = FOO.VF_StandAlone_BasicCallOperationForSa && !FOO.VF_QoS5qiSupportPerPLMN;
            break;

        case YANG_VCCB_READER_PERPLMNQOS5QISUPPORT_ID:
        case YANG_VCCB_SUBSCRIBE_PERPLMNQOS5QISUPPORT_ID:
            ret = FOO.VF_StandAlone_BasicCallOperationForSa && FOO.VF_QoS5qiSupportPerPLMN;
            break;

        case YANG_VCCB_READER_PERPLMNQCISUPPORT_ID:
        case YANG_VCCB_SUBSCRIBE_PERPLMNQCISUPPORT_ID:
            ret = FOO.VF_QoSSchedulingPerPLMN;
            break;

        case YANG_VCCB_READER_REAL_TIME_SGNB_ADDITION_TIMER_ID:
        case YANG_VCCB_SUBSCRIBE_REAL_TIME_SGNB_ADDITION_TIMER_ID:
            ret = FOO.VF_BasicOperationforENDC_RetrieveRealTimeCallCount;
            break;

        case YANG_VCCB_READER_IDLE_MOBILITY_CONTROL_ID:
        case YANG_VCCB_SUBSCRIBE_IDLE_MOBILITY_CONTROL_ID:
        case YANG_VCCB_SUBSCRIBE_CA_PROFILE_ENTRIES_ID:
            ret = FOO.VF_IdlemobilitycontrolforNR_CaProfileBased;
            break;
        case YANG_VCCB_READER_RESTRICTED_SSB_FREQ_ID:
        case YANG_VCCB_SUBSCRIBE_RESTRICTED_SSB_FREQ_ID:
            ret = FOO.VF_NRMeasurement_RestrictedSsbFrequencies;
            break;
        case YANG_VCCB_READER_SERVICETYPE_COUNTER_ID:
        case YANG_VCCB_SUBSCRIBE_SERVICETYPE_COUNTER_ID:
            ret = FOO.VF_ServiceTypeConfigurationforStatistics_SA;
            break;

        case YANG_VCCB_SUBSCRIBE_USER_INACTIVITY_PROFILE_ENTRIES_ID:
            ret = FOO.VF_UserInactivityTimer_PerCellControl;
            break;

        case YANG_VCCB_READER_PLMN_RFSP_BASED_VONR_CONTROL_ID:
        case YANG_VCCB_SUBSCRIBE_PLMN_RFSP_BASED_VONR_CONTROL_ID:
            ret = FOO.VF_AllowVoNRwithRfsp;
            break;

        case YANG_VCCB_READER_INACTIVITYDATASA_REDCAP_ID:
        case YANG_VCCB_SUBSCRIBE_INACTIVITYDATASA_REDCAP_ID:
            ret = FOO.VF_BasicCallProcedureforRedCapUE;
            break;

        case YANG_VCCB_READER_PLMN_SLICE_COUNTER_CONFIG_ID:
        case YANG_VCCB_SUBSCRIBE_PLMN_SLICE_COUNTER_CONFIG_ID:
            ret = FOO.VF_ConnInfoPlmnSnssaiCounterConfig;
            break;

        case YANG_VCCB_READER_VOMA_CONFIG_ID:
        case YANG_VCCB_SUBSCRIBE_VOMA_CONFIG_ID:
            ret = FOO.VF_VoNRMonitoringSupportForVoMA;
            break;

        default:
            ret = 0;  // default is Unnecessity
            break;
    }

    ret = !!ret;  // only allowed true(!= 0) and false(== 0)

    if (ret == 0)
        return e_Unnecessity;
    else
        return e_Necessity;
}

/**
 * @brief This function checks the Mandatory PLD according to the runtime environment.
 * @details The purpose of this function is to check the normality of the block by checking the Mandatory PLD depending
 * on the operating environment.
 * @param criticality_type
 * @return true : Mandatory parameters ( In this case, PLD must exist. )
 * @return false : Optional parameters ( In this case, if PLD not exits, skip )
 */
VCCB_Necessity VCCB_GetNecessityPldByFOO(const int id)
{
    int ret;

    AUTO_TRACE_FUNC;

    switch (id)
    {
        case REL_AMF_STATUS_ID:
        case REL_AMF_TNL_STATUS_ID:
        case REL_AMF_TNL_SCTP_STATE_ID:
            ret = FOO.VF_StandAlone_BasicCallOperationForSa;
            break;

        default:
            ret = 1;  // default is Necessity
            break;
    }

    ret = !!ret;  // only allowed true(!= 0) and false(== 0)

    if (ret == 0)
        return e_Unnecessity;
    else
        return e_Necessity;
}

/****************************************************************
 *  Function     : FnVCCB_ReadDynamicFoo
 *  Description  : Read VCCB Dynamic Foo
 *  Procedures defined :
 *  Procedures called  :
 *  Procedure calling  :
 *  Input  : void
 *  Output : int
 *  Statistics Pegged :
 ***************************************************************/

int FnVCCB_ReadDynamicFoo()
{
    AUTO_TRACE_FUNC;
    VccbDynamicFlagInfo_type *pFooInfo = &CFG->foo;
    memset(pFooInfo, 0x00, sizeof(VccbDynamicFlagInfo_type));

    /**
     * @brief VCCB FOO initialization
     *
     * To use Dynamic FOO, structure and variable definition must be modified as below.
     * 1. (struct) VccbDynamicFlagInfo_type in VccbFoo.h (VCCB, ITSCP_VCCB)
     * 2. (func) getFooArray in VccbFoo.h (VCCB, ITSCP_VCCB)
     *
     * This setting must have FullSet on all packages.
     * Variable values from the point of view not provided in the built package must always be zero.
     *
     * Do not use ifdef in this area.
     */

    VccbFooArrayWrapper wrapper;
    if (getFooArray(&CFG->foo, &wrapper) != GOOD)
    {
        VCCB_PRINTF("NULL POINTER ERROR IN getFooArray, VccbFoo.h");
        return ERROR;
    }
    const int arrSize = VCCB_ARRAY_COUNT(wrapper.fooArray);
    uint32_t loop = 0;

    VCCB_PRINTF("=======================================================================\n");
    VCCB_PRINTF(" Read Dynamic FOO (Feature On Off)                          Count : %u \n", arrSize);
    VCCB_PRINTF("-----------------------------------------------------------------------\n");
    VCCB_PRINTF(" No | Name                                          | Val | Cause      \n");

    for (loop = 0; loop < arrSize; loop++)
    {
        if (loop % 10 == 0) VCCB_PRINTF("-----------------------------------------------------------------------\n");

        if (wrapper.fooArray[loop].pFooName == NULL || wrapper.fooArray[loop].pFooVal == NULL ||
            wrapper.fooArray[loop].pFailCause == NULL)
        {
            VCCB_PRINTF("NULL POINTER ERROR: loop:%d, pFooName:%p, pFooVal=%p, pFailCause=%p\n", loop,
                wrapper.fooArray[loop].pFooName, wrapper.fooArray[loop].pFooVal, wrapper.fooArray[loop].pFailCause);
            continue;
        }

        int rc = 0, retryCount = 0;

        for (retryCount = 0; retryCount < NRCALL_MAX_FOO_RETRY; retryCount++)
        {
            rc = featureCheck(wrapper.fooArray[loop].pFooName);
            if (VCCB_checkRetry_ReadDynamicFoo(rc) == True)
            {
                VCCB_PRINTF("[Dynamic FOO #1] Foo is not ready, so try again. (%d of %d, N:%s, E:%s,%d) \n", retryCount,
                    NRCALL_MAX_FOO_RETRY, wrapper.fooArray[loop].pFooName, VCCB_GetFeatureErrStr(rc), rc);
                continue;
            }

            rc = featureGetInt(wrapper.fooArray[loop].pFooName);
            if (VCCB_checkRetry_ReadDynamicFoo(rc) == True)
            {
                VCCB_PRINTF("[Dynamic FOO #2] Foo is not ready, so try again. (%d of %d, N:%s, E:%s,%d) \n", retryCount,
                    NRCALL_MAX_FOO_RETRY, wrapper.fooArray[loop].pFooName, VCCB_GetFeatureErrStr(rc), rc);
                continue;
            }

            if (rc < 0)  // Error handling operation
            {
                // Init
                *(wrapper.fooArray[loop].pFooVal) = 0;
                *(wrapper.fooArray[loop].pFailCause) = rc;

                // VCCB restart is attempted by processing the error except "Feautre is not registered".
                if (rc != E_FEATURE_API_FEATURE_NOT_EXIST)
                {
                    VCCB_PRINTF("[Dynamic FOO #3] VCCB restart is attempted by cause '%s,%d'. (N:%s) \n",
                        VCCB_GetFeatureErrStr(rc), rc, wrapper.fooArray[loop].pFooName);
                    return ERROR;
                }

                VCCB_PRINTF(" %02d | %-45s | %03u | %s(%d) \n", loop, wrapper.fooArray[loop].pFooName,
                    *(wrapper.fooArray[loop].pFooVal), VCCB_GetFeatureErrStr(rc), rc);
            }
            else  // Normal handling operation
            {
                *(wrapper.fooArray[loop].pFooVal) = rc;
                *(wrapper.fooArray[loop].pFailCause) = 0;
                VCCB_PRINTF(" %02d | %-45s | %03u | %s \n", loop, wrapper.fooArray[loop].pFooName,
                    *(wrapper.fooArray[loop].pFooVal), VCCB_GetFeatureErrStr(rc));
            }

            break;
        }

        if (retryCount >= NRCALL_MAX_FOO_RETRY)
        {
            // Init
            *(wrapper.fooArray[loop].pFooVal) = 0;
            *(wrapper.fooArray[loop].pFailCause) = rc;

            VCCB_PRINTF("[Dynamic FOO #4] VCCB restart is attempted by cause 'MAX RETRY OVER'.\n");
            return ERROR;
        }
    }

    VCCB_PRINTF("=======================================================================\n");

    return GOOD;
}

/****************************************************************
 *  Function     : VCCB_GetFeatureErrStr
 *  Description  : Convert Error Number To String
 *  Procedures defined :
 *  Procedures called  :
 *  Procedure calling  :
 *  Input  : int
 *  Output : const char*
 *  Statistics Pegged :
 ***************************************************************/
const char *VCCB_GetFeatureErrStr(int errCause)
{
    AUTO_TRACE_FUNC;

    if (errCause >= 0) return "-";

    switch (errCause)
    {
        case E_FEATURE_API_FEATURE_NOT_EXIST:
            return "FEATURE_NOT_EXIST";
        case E_FEATURE_API_INITIALIZING:
            return "INITIALIZING";
        case E_FEATURE_API_NOT_INITIALIAED:
            return "NOT_INITIALIAED";
        case E_FEATURE_API_NO_FEATURE_FILE:
            return "NO_FEATURE_FILE";
        case E_FEATURE_API_SHM_AT_ERROR:
            return "SHM_AT_ERROR";
        case E_FEATURE_API_SHM_DT_ERROR:
            return "SHM_DT_ERROR";
        case E_FEATURE_API_SHM_CTL_ERROR:
            return "SHM_CTL_ERROR";
        case E_FEATURE_API_FEATURE_TYPE_MISMATCH_BOOL:
            return "TYPE_MISMATCH_BOOL";
        case E_FEATURE_API_FEATURE_TYPE_MISMATCH_INT:
            return "TYPE_MISMATCH_INT";
        case E_FEATURE_API_FEATURE_TYPE_MISMATCH_STRING:
            return "TYPE_MISMATCH_STRING";

        default:
            return "UNKNOWN_ERROR";
    }
}

BOOL VCCB_checkRetry_ReadDynamicFoo(int errCause)
{
    AUTO_TRACE_FUNC;

    BOOL bResult = False;

    switch (errCause)
    {
        //
        case E_FEATURE_API_INITIALIZING:
        case E_FEATURE_API_NOT_INITIALIAED:
        case E_FEATURE_API_SHM_AT_ERROR:
        case E_FEATURE_API_SHM_DT_ERROR:
        case E_FEATURE_API_SHM_CTL_ERROR:
            bResult = True;
            thsSleep(NRCALL_FOO_RETRY_TIME);  // VCCB_FOO_SLEEP_TIME
            break;

        default:
            break;
    }

    return bResult;
}
