#include "CdbUtil.h"
#include "ComInclude.h"

#include "MsgVccbSend.h"

#include "access_common_yang.h"

/***************************************************************************************************************************************************************
 *
 *
 *                                                               YANG Dependency Wrapper
 *
 *
 * This function is used to break the YANG dependency.
 * When referring to YANG-related functions, refer directly to this file, and indirectly refer to the function where
 *necessary.
 ***************************************************************************************************************************************************************/

// Is Function

uint8_t FnVCCB_IsSupportDirectAmfRelocation(uint16_t gnbNum)
{
    VCCB_CHECK_VALID_GNBNUM_FALSE(gnbNum);
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
    return (pGnb->cfg.amfRelocationOption == FnVCCB_GetYangValueDirectAmfRelocation());
}

uint8_t FnVCCB_IsNeBasicPowerMode(uint16_t cellNum)
{
    VCCB_CHECK_VALID_CELLNUM_FALSE(cellNum);

    return (NEDC_PowerAllocMode(cellNum) == access_s5gtype_ne_dc_basic_power_mode);
}

uint8_t FnVCCB_IsUlPrimaryPathModeInitDynamicRSRPandRSRQ(uint16_t cellNum)
{
    VCCB_CHECK_VALID_CELLNUM_FALSE(cellNum);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    return (pCell->ulPrimaryPathMode == FnVCCB_GetYangValueInitDynamicRsrpRsrq());
}

uint8_t FnVCCB_IsUlPrimaryPathModeInitSCG(uint16_t cellNum)
{
    VCCB_CHECK_VALID_CELLNUM_FALSE(cellNum);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    return (pCell->ulPrimaryPathMode == access_s5gtype_initial_SCG);
}

uint8_t FnVCCB_IsUlPrimaryPathModeInitScgProbability(uint16_t cellNum)
{
    VCCB_CHECK_VALID_CELLNUM_FALSE(cellNum);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    return (pCell->ulPrimaryPathMode == access_s5gtype_initial_probability_based);
}

uint8_t FnVCCB_IsScgFailureRSRQmodeForDynamicSelection(uint16_t gnbNum)
{
    VCCB_CHECK_VALID_GNBNUM_FALSE(gnbNum);
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    return (pGnb->cfg.scgFailureHandlingInfo.dynamicSelectionCriteria == access_s5gtype_RSRQ);
}

uint8_t FnVCCB_IsNrDcUlPrimaryPathModeInitScg(uint16_t cellNum)
{
    VCCB_CHECK_VALID_CELLNUM_FALSE(cellNum);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    return (pCell->nrdcCellInfo.nrdcUlPrimaryPathMode == access_s5gtype_initial_SCG_nrdc);
}
uint8_t FnVCCB_IsNrDcUlPrimaryPathModeInitProbability(uint16_t cellNum)
{
    VCCB_CHECK_VALID_CELLNUM_FALSE(cellNum);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    return (pCell->nrdcCellInfo.nrdcUlPrimaryPathMode == access_s5gtype_initial_probability_based_nrdc);
}

uint8_t FnVCCB_isCslReportingNsaOnly(void)
{
    return (common_nsa_only == CFG->cslReportingType);
}

uint8_t FnVCCB_isCslReportingSaOnly(void)
{
    return (common_sa_only == CFG->cslReportingType);
}

uint8_t FnVCCB_isCslReportingTypeNsaAndSa(void)
{
    return (common_nsa_and_sa == CFG->cslReportingType);
}

bool FnVCCB_isCslDataDiscardedForCallType(bool sendToTce, enumCallType_type callType)
{
    int16_t status = ERROR;
    bool sendToStatus = sendToTce;

    if(!FnVCCB_isCslReportingTypeNsaAndSa() && sendToTce)
    {
        if (E_CALLTYPE_NSA == callType)
        {
            status = FnVCCB_isCslReportingNsaOnly();
            sendToStatus = GOOD == status;
        }

        if(E_CALLTYPE_SA == callType)
        {
            status = FnVCCB_isCslReportingSaOnly();
            sendToStatus = GOOD == status;
        }
    }
    return sendToStatus;
}

uint8_t FnVCCB_IsPdcp18BitSnMode(uint8_t pdcpSnSize) { return (access_s5gtype_pdcp_sn_size_len18bits == pdcpSnSize); }

bool FnVCCB_IsNedcModeMode1(uint16_t cellNum)
{
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(cellNum, false);

    return (NEDC_OprMode(cellNum) == access_s5gtype_ne_dc_mode1);
}

bool FnVCCB_IsNedcModeMode2(uint16_t cellNum)
{
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(cellNum, false);

    return (NEDC_OprMode(cellNum) == FnVCCB_GetYangValueNedcMode2());
}

uint8_t FnVCCB_IsPsCellSelectionMeasurement(uint8_t pscellSelectionMethod)
{
    return (pscellSelectionMethod == access_s5gtype_pscell_selection_measurement);
}

uint8_t FnVCCB_IsPsCellSelectionLB(uint8_t pscellSelectionMethod)
{
    return ((pscellSelectionMethod == access_s5gtype_pscell_selection_load_balancing) ||
            (pscellSelectionMethod == access_s5gtype_pscell_selection_load_balancing_ue_count_based));
}

uint8_t FnVCCB_GetNrdcScgProbability(uint16_t cellNum)
{
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(cellNum, 50);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    return pCell->nrdcCellInfo.nrdcScgProbability;
}

uint8_t FnVCCB_GetYangValueNedcMode2(void) { return access_s5gtype_ne_dc_mode2; }

uint8_t FnVCCB_GetYangValueNrdcOprMode1(void) { return access_s5gtype_nr_dc_mode1; }
uint8_t FnVCCB_GetYangValueNrdcOprMode2(void) { return access_s5gtype_nr_dc_mode2; }
uint8_t FnVCCB_GetYangValueNrdcOprMode3(void) { return access_s5gtype_nr_dc_mode3; }
uint8_t FnVCCB_GetYangValueNrdcOprMode4(void) { return access_s5gtype_nr_dc_mode4; }

uint8_t FnVCCB_GetYangValueInitDynamicRsrpRsrq(void) { return access_s5gtype_initial_dynamic_RSRP_RSRQ; }

uint8_t FnVCCB_GetYangValueDirectAmfRelocation(void) { return access_s5gtype_direct_amf_relocation; }

int8_t FnVCCB_GetYangValueMnTerm(void) { return access_s5gtype_mn_term; }

int8_t FnVCCB_GetYangValueMnTermMcg(void) { return access_s5gtype_mn_term_mcg; }

uint16_t FnVCCB_GetYangValueSnTermSplit(void) { return access_s5gtype_sn_term_split; }

uint16_t FnVCCB_GetYangValueSnTermScg(void) { return access_s5gtype_sn_term_scg; }

int32_t FnVCCB_ConvNedcBearerTypeYangToInternal(int32_t yangEnum)
{
    switch (yangEnum)
    {
        case access_s5gtype_mn_term_mcg:
            return MN_Term_MCG_Bearer;

        case access_s5gtype_mn_term_split:
            return MN_Term_SPLIT_Bearer;

        default:
            return MN_Term_MCG_Bearer;
    }
}

int32_t FnVCCB_ConvNrdcBearerTypeYangToInternalforMN(int8_t termPoint, int8_t mnBearerType)
{
    if (termPoint == access_s5gtype_mn_term)
    {
        switch (mnBearerType)
        {
            case access_s5gtype_mn_term_mcg:
                return MN_Term_MCG_Bearer;

            case access_s5gtype_mn_term_split:
                return MN_Term_SPLIT_Bearer;

            default:
                break;
        }
    }
    else if (termPoint == access_s5gtype_sn_term)
    {
        return SN_Term_SPLIT_Bearer; // default 
    }

    return MN_Term_MCG_Bearer;
}

int16_t FnVCCB_ConvNrdcControlToSelectedBearerTypeForSN(uint16_t nrdcControl_SelectType)
{
    switch (nrdcControl_SelectType)
    {
        case access_s5gtype_sn_term_scg:
            return SN_Term_SCG_Bearer;

        case access_s5gtype_sn_term_split:
            return SN_Term_SPLIT_Bearer;

        default:
            return INIT_BEARER_TYPE;
    }
}

/*****************************************************************************************************
 * @brief           Get the 8-bit binary string from YANG and convert to uint8_t variable
 *
 * @param[in]       bufferPtr   : Pointer to uint8_t binary string
 * @param[in]       bufferLen   : The lenght of binary string (Shall not be greater than 8)
 * @return          decimalValue: The decimal value corresponding to the binary string representation
 *****************************************************************************************************/
uint8_t FnVCCB_GetDecimalValueFromYangBitString(uint8_t *bufferPtr, const uint8_t bufferLen)
{
    uint8_t decimalValue = 0;
    const uint8_t bitPosition = 7;  // Bit string order is B7 B6 B5 B4 B3 B2 B1 B0
    uint8_t i;
    for (i = 0; i < bufferLen; i++)
    {
        if ('1' == bufferPtr[i])
        {
            ONBIT_U8(decimalValue, (uint8_t)(bitPosition - i));
        }
    }
    return decimalValue;
}

enumUsage_type FnVCCB_CommonEnumOperType(const int32_t state)
{
    AUTO_TRACE_FUNC;

    enumUsage_type retState = CI_no_use;

    switch (state)
    {
        default:
        case OpState_unknown:
        case OpState_disabled:
            retState = CI_no_use;
            break;

        case OpState_enabled:
            retState = CI_use;
            break;
    }

    return retState;
}

uint8_t FnVCCB_IsSamsungVendor(const int32_t isSamsungVendor)
{
    AUTO_TRACE_FUNC;

    switch (isSamsungVendor)
    {
        default:
        case IS_SAMSUNG_VENDOR_FALSE:
        case IS_SAMSUNG_VENDOR_UNKNOWN:
            return FALSE;

        case IS_SAMSUNG_VENDOR_TRUE:
            return TRUE;
    }
}

void FnVCCB_ReleaseAllCalls(const uint8_t cause)
{
    AUTO_TRACE_FUNC;

    std::vector<uint32_t> cuCpUeIdList;
    for (uint32_t callId = 0; callId < VCCB_MAX_CALL_COUNT_PER_CPC; callId++)
    {
        callInfo_type *ptCi = FnVCCB_GetCallInUse(callId);
        if (ptCi != NULL)
        {
            cuCpUeIdList.push_back(ptCi->gnbCuUeId);
        }
    }
    if (cuCpUeIdList.size() > 0)
    {
        FnVCCB_SendInternalCallRelease(cuCpUeIdList, cause);
    }
    return;
}

void FnVCCB_ReleaseAllCallsOnCellOfType(const uint16_t gnbNum, const uint16_t cellNum, const uint8_t cause, const enumCallType_type callType)
{
    AUTO_TRACE_FUNC;

    std::vector<uint32_t> cuCpUeIdList;
    for (uint32_t callId = 0; callId < VCCB_MAX_CALL_COUNT_PER_CPC; callId++)
    {
        callInfo_type *ptCi = FnVCCB_GetCallInUse(callId);
        if (ptCi != NULL)
        {
            if((gnbNum == ptCi->gnbNum) && (cellNum == ptCi->servCellNum) && (callType == ptCi->callType))
            {
                cuCpUeIdList.push_back(ptCi->gnbCuUeId);
            }
        }
    }
    if (cuCpUeIdList.size() > 0)
    {
        FnVCCB_SendInternalCallRelease(cuCpUeIdList, cause);
    }
    return;
}

void FnVCCB_ReleaseCall(const callInfo_type *const ptCi, const uint8_t cause)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    std::vector<uint32_t> cuCpUeIdList;
    cuCpUeIdList.push_back(ptCi->gnbCuUeId);
    FnVCCB_SendInternalCallRelease(cuCpUeIdList, cause);
    return;
}

uint8_t FnVCCB_GetServiceAvailPlmnIdx(uint16_t gnbNum, s2_type s2TypePlmn)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_CU_CP_FUNCTION_PER_SYS, MAX_PLMN_INDEX);
    VccbGnbInfo_type* const pGnb = &GNBINFO[gnbNum];

    uint8_t plmnIdx;
    for (plmnIdx = 0; plmnIdx < MAX_PLMN_INDEX; ++plmnIdx)
    {
        if ( (pGnb->serviceAvailInfo[plmnIdx].status == EQUIP) &&
             (pGnb->serviceAvailInfo[plmnIdx].plmn.s2.vField == s2TypePlmn.vField) )
        {
            return plmnIdx;
        }
    }

    return MAX_PLMN_INDEX;
}

uint8_t FnVCCB_GetAllocServiceAvailPlmnIdx(uint16_t gnbNum, s2_type s2TypePlmn)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_CU_CP_FUNCTION_PER_SYS, MAX_PLMN_INDEX);
    VccbGnbInfo_type* const pGnb = &GNBINFO[gnbNum];

    uint8_t plmnIdx = FnVCCB_GetServiceAvailPlmnIdx(gnbNum, s2TypePlmn);

    if (plmnIdx < MAX_PLMN_INDEX)
    {
        return plmnIdx;
    }

    for (plmnIdx = 0; plmnIdx < MAX_PLMN_INDEX; ++plmnIdx)
    {
        if (pGnb->serviceAvailInfo[plmnIdx].status == EQUIP)
            continue;

        return plmnIdx;
    }

    return MAX_PLMN_INDEX;
}

void FnVCCB_DalErrorPrint(int status, const char *ptCalledFunc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCalledFunc);

    switch (status)
    {
        case DAL_ERR:
            VCCB_PRINTF_ERR("[DAL][%s] %s\n", ptCalledFunc, dal_db_get_errcode_str(dal_db_get_error_code(status)));
            break;
        case DAL_EOF:
            VCCB_PRINTF_ERR("[DAL][%s] Socket has been closed\n", ptCalledFunc);
            break;
        case DAL_SOCK_CONNECT_FAIL:
            VCCB_PRINTF_ERR("[DAL][%s] Connection failed\n", ptCalledFunc);
            break;
        case DAL_INVALID_PARAM:
            VCCB_PRINTF_ERR("[DAL][%s] Invalid params\n", ptCalledFunc);
            break;
        default:
            break;
    }
}

void FnVCCB_DalWrapper_dal_db_close(int *pReadSocket, const char *ptCalledFunc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pReadSocket);
    VALID_E_POINT_CHECK_VOID(ptCalledFunc);

    int status = dal_db_close(*pReadSocket);
    if (DAL_SUCCESS != status)
    {
        FnVCCB_DalErrorPrint(status, ptCalledFunc);
    }

    *pReadSocket = -1;
}

ReadDataSessionDuringSubscription::ReadDataSessionDuringSubscription(int &rSocket) : rSocket_(rSocket)
{
    AUTO_TRACE_FUNC;

    // DAL_DB_LOCK_WAIT is not added to a flag because handling subcription should be as quick as possible.
    // For now it is deemed that it is better to fail to start a session rather than wait.
    int result{DAL_SUCCESS};
    VCCB_DAL_DB_START_SESSION(rSocket_, DAL_DB_RUNNING, DAL_DB_LOCK_SESSION, result);
    if (result != DAL_SUCCESS)
    {
        return;
    }
    VCCB_DAL_DB_SET_NAMESPACE(rSocket_, result);
    if (result != DAL_SUCCESS)
    {
        return;
    }
    sessionStarted_ = true;
}

ReadDataSessionDuringSubscription::~ReadDataSessionDuringSubscription()
{
    AUTO_TRACE_FUNC;

    if (sessionStarted_)
    {
        int result{DAL_SUCCESS};
        VCCB_DAL_DB_END_SESSION(rSocket_, result);
    }
}

bool ReadDataSessionDuringSubscription::isValid() const { return sessionStarted_; }
int ReadDataSessionDuringSubscription::getSocket() const { return rSocket_; }

// end
