/**
 * @file       CdbPldSubscription.c
 * @brief      PLD Subscription and Update
 */

/*----------------------------------------------------------------------------
 * Define    :    Include Header Files
 * ---------------------------------------------------------------------------
 */
#include "CdbDalSubscription.h"
#include "CdbPldReader.h"
#include "ComInclude.h"
#include "FeatSwVersion.h"
#include "MsgVccbSend.h"
#include "ComLibUtility.h"
#include "FeatCommon.h"
#include "FeatLbm.hpp"
#include "ComEndian.h"

#include "DbiInterface.h"
int16_t VCCB_getTuple_PLDCellTraceStatus(message_type *pRxMsg);

// extern pldInfo_type gPldInfo[]; // [SAM_GV_IMPROVEMENT]
// extern pldInfo_type *GetgPldInfo_();  // [SAM_GV_IMPROVEMENT]
#define gPldInfo (GetgPldInfo_())     // [SAM_GV_IMPROVEMENT]

DbiWithDataOption FnVCCB_GetPLDNotificationWithDataOption(const int relationId, const int dbIndex)
{
    AUTO_TRACE_FUNC;
    if (e_VCCB_NVGNB == VCOM_getSystemType())
    {
        return DBI_WITHOUT_DATA;
    }

    VCCB_CHECK_E_RANGE_AND_VAL(dbIndex, MAX_NUM_SUBSCRIBE_PLD, DBI_WITHOUT_DATA);
    
    switch(relationId)
    {
        case REL_DU_STATUS_ID:
        case REL_CELL_STATUS_ID:
        case REL_CELL_TRACE_STATUS_ID:
            {
                vccbPldAttributeInfo_type *pInfo = &CFG->pld.pldAttInfo[dbIndex];
                pInfo->relationId = relationId;

                relationInfo relHdr;
                memset(&relHdr, 0, sizeof(relHdr));
                int result = dbiGetRelationInfo(relationId, &relHdr);
                if (result < 0)
                {
                    VCCB_PRINTF("%s: dbiGetRelationInfo failed(%d)! DBI_WITHOUT_DATA will be used!\n",
                            __func__, result);
                    return DBI_WITHOUT_DATA;
                }

                pInfo->numOfAttribute = relHdr.numOfAttribute;
                if ((pInfo->numOfAttribute == 0) || (pInfo->numOfAttribute > DBI_MAX_LOOP_CNT_ATTR))
                {
                    pInfo->numOfAttribute = 0; // initialize
                    VCCB_PRINTF("%s: Invalid numOfAttribute(%d)! DBI_WITHOUT_DATA will be used!\n",
                            __func__, pInfo->numOfAttribute);
                    return DBI_WITHOUT_DATA;
                }

                memset(pInfo->attInfo, 0, sizeof(pInfo->attInfo));
                result = dbiGetAttributeInfo(relationId, pInfo->attInfo);
                if (result < 0)
                {
                    VCCB_PRINTF("%s: dbiGetAttributeInfo failed(%d)! DBI_WITHOUT_DATA will be used!\n",
                            __func__, result);
                    return DBI_WITHOUT_DATA;
                }
            }
            return DBI_WITH_DATA;
        default:
            return DBI_WITHOUT_DATA;
    }
}

int VCCB_RegisterSinglePLD(pldInfo_type * pPldInfo, const DbiWithDataOption option)
{
    AUTO_TRACE_FUNC;

    int result = GOOD;
    result = dbiSubscribe(DBI_CHANGE_NOTI_SUBSCRIBE, DBI_ALL_TUPLE_OPTION, option,
            VCCB_INT_PLD_MBOX, (uint32_t)pPldInfo->relId, NULL, NULL);
    if (result < 0)
    {
        VCCB_PRINTF("[RegisterPLD] dbiSubscribe Error!! (relId:0x%X, relName:%s, retVal:%d)\n",
                pPldInfo->relId, pPldInfo->relName, result);

        return ERROR;
    }

    pPldInfo->isRequiredSub = FALSE;
    return GOOD;
}

int VCCB_RegisterPLD(void)
{
    AUTO_TRACE_FUNC;
    int result = GOOD, retry_count = 0;
    pldInfo_type *pPldInfo = gPldInfo;

    FnVCCB_RecordTime(&ENV->vccbInitTime.regiPldStart);
    VCCB_PRINTF("==== VCCB_RegisterPLD =====================\n");

    // DBI Subscribe Init
    while ((result = dbiInitializeSubscription(VCCB_INT_RSI_MBOX, MDS_ATTR_IP_TYPE_IIIP)) < 0)
    {
        if (retry_count >= VCCB_MAX_PLD_RETRY_FOR_INIT)
        {
            VCCB_PRINT_ERROR("[PLD] dbiInitializeSubscription Error(%d) !!!\n", result);
            return ERROR;
        }
        retry_count++;
        VCCB_PRINTF("[PLD] %dth Retry dbiInitializeSubscription !!!\n", retry_count++);
        thsSleep(NRCALL_PLD_RETRY_TIME);
    }
    VCCB_PRINTF("[PLD] dbiInitializeSubscription done...\n");

    // DBI Subscribe Relations
    CFG->pld.numOfPldWithData = 0;
    while (pPldInfo->relId != 0)
    {
        if (TRUE == FnVCCB_IsReadSkipCase(pPldInfo, FALSE))
        {
            pPldInfo++;
            continue;
        }

        DbiWithDataOption option = FnVCCB_GetPLDNotificationWithDataOption(pPldInfo->relId, CFG->pld.numOfPldWithData);
        if (option == DBI_WITH_DATA)
        {
            CFG->pld.numOfPldWithData++;
        }

        retry_count = 0;
        while (VCCB_RegisterSinglePLD(pPldInfo, option) != GOOD)
        {
            if ((retry_count >= VCCB_MAX_PLD_RETRY_FOR_INIT) && (pPldInfo->optional == OPTIONAL))
            {
                pPldInfo->isRequiredSub = TRUE;
                VCCB_PRINTF(
                        "[RegisterPLD] Maximum retry count exceeded for optional PLD! Skip: relId:0x%X, relName:%s)\n",
                        pPldInfo->relId, pPldInfo->relName);
                break;
            }
            retry_count++;

            VCCB_PRINTF("[RegisterPLD] [%d]th Retry dbiSubscribe (relId:0x%X, relName:%s, retVal:%d)\n", retry_count,
                    pPldInfo->relId, pPldInfo->relName, result);

            thsSleep(NRCALL_PLD_RETRY_TIME);
        }

        pPldInfo++;
    }


    VCCB_PRINTF("[PLD] dbiSubscribe Relations done...\n");
    VCCB_PRINTF("===========================================\n");
    FnVCCB_RecordTime(&ENV->vccbInitTime.regiPldEnd);

    return GOOD;
}

int16_t VCCB_UpdatePldMsg(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    int16_t result;
    msgDBInformPldNotiDbiAll_type *pNotifyPld = NULL;

    VALID_E_POINT_CHECK_ERROR(pRxMsg);

    pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;
    VCCB_PRINT_DATA("[PLD]VCCB_UpdatePldMsg pldNotify(rel:x%x,updateType:%d,numOfKey:%d,key:%d,%d,%d)\n",
        pNotifyPld->relId, pNotifyPld->updateType, pNotifyPld->numOfPKey, pNotifyPld->tpKey[0],
        pNotifyPld->tpKey[1], pNotifyPld->tpKey[2]);

    int relIdx = 0;
    while (gPldInfo[relIdx].relId != 0)
    {
        if (gPldInfo[relIdx].relId == pNotifyPld->relId)
        {
            switch (pNotifyPld->updateType)
            {
                case UPDATE_TYPE_CHANGE_REL:
                case UPDATE_TYPE_CREATE_REL:
                case UPDATE_TYPE_SYNC_REL:
                    VCCB_PRINTF("[PLD]VCCB_UpdatePldMsg pldNotify(rel:x%x,updateType:%d,numOfKey:%d,key:%d,%d,%d)\n",
                        pNotifyPld->relId, pNotifyPld->updateType, pNotifyPld->numOfPKey, pNotifyPld->tpKey[0],
                        pNotifyPld->tpKey[1], pNotifyPld->tpKey[2]);
                    result = gPldInfo[relIdx].fnGetRel();
                    if (result != GOOD)
                    {
                        if (gPldInfo[relIdx].optional == OPTIONAL)
                        {
                            VCCB_PRINTF(
                                "[%s] VCCB_UpdatePldMsg optional PLD: %s failed to get Rel(can be no exist) (x%x)\n",
                                __func__, gPldInfo[relIdx].relName, gPldInfo[relIdx].relId);
                            break;
                        }
                        VCCB_PRINT_ERROR("[%s] fnGetRel Error!!! (x%x:%s)\n", __func__, gPldInfo[relIdx].relId,
                            gPldInfo[relIdx].relName);
                        return result;
                    }
                    break;

                default:  // updateType : UPDATE_TYPE_*_TPL
                    result = gPldInfo[relIdx].fnGetTuple(pRxMsg);
                    if (result != GOOD)
                    {
                        if (gPldInfo[relIdx].optional == OPTIONAL)
                        {
                            VCCB_PRINTF(
                                "[%s] VCCB_UpdatePldMsg optional PLD: %s failed to get tuple(can be no exist) (x%x)\n",
                                __func__, gPldInfo[relIdx].relName, gPldInfo[relIdx].relId);
                            break;
                        }
                        VCCB_PRINT_ERROR("[%s] fnGetTuple Error!!! (x%x:%s)\n", __func__, gPldInfo[relIdx].relId,
                            gPldInfo[relIdx].relName);
                        return result;
                    }
                    break;
            }
        }
        relIdx++;
    }

    return GOOD;
}

static int FnVCCB_GetTuple(int relId, int *pTupleKey, char *buf, uint32_t bufSize, message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;

    int result = GOOD;
    
    if ((DBG->flag.getPldDataUsingOnlyDbiApi != VCCB_FLAG_ON) &&
            (pRxMsg != NULL) && (pRxMsg->msgHdr.msgType == msgDBInformPldWithDataNotiDbiAll_id))
    {
        msgDBInformPldWithDataNotiDbiAll_type *pNoti = (msgDBInformPldWithDataNotiDbiAll_type *)pRxMsg;
        if (pNoti->dataSize >= (int)bufSize)
        {
            // Get PLD Data from Message
            memcpy(buf, (char *)pRxMsg + sizeof(msgDBInformPldWithDataNotiDbiAll_type), bufSize);
            return GOOD;
        }
    }

    // Get PLD Data by using DBI API
    result = dbiGetTuple(relId, pTupleKey, buf, bufSize);
    if (result < 0)
    {
        VCCB_PRINTF("[%s] relId(%d) dbiGetTuple ERROR! (%d)\n", __func__, relId, result);
    }

    return result;
}

char* updateTypeToStr(int type)
{
    switch(type)
    {
        case UPDATE_TYPE_BASE_TPL:
            return (char*)"UPDATE_TYPE_BASE_TPL";
        case UPDATE_TYPE_CREATE_TPL:
            return (char*)"UPDATE_TYPE_CREATE_TPL";
        case UPDATE_TYPE_DELETE_TPL:
            return (char*)"UPDATE_TYPE_DELETE_TPL";
        case UPDATE_TYPE_CHANGE_TPL:
            return (char*)"UPDATE_TYPE_CHANGE_TPL";
        default:
            return (char*)"Unknown";
    }

    return (char*)"Unknown";
}

int16_t VCCB_getTuple_PLDDuStatus(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;

    int result;
    PLDDuStatus buf = {};
    gnbDuInfo_type *pGnbDu = NULL;
    uint16_t gnbNum = MAX_GNB_PER_SYS;

    uint16_t gnbIdx = (uint16_t)pNotifyPld->tpKey[0];
    int endPointIdx = pNotifyPld->tpKey[1];

    VCCB_CHECK_E_RANGE_AND_RETURN(endPointIdx, MAX_GNB_DU_PER_GNB_CU_CP);

    switch (pNotifyPld->updateType)
    {
        case UPDATE_TYPE_DELETE_TPL:
            // get gnbNum
#ifdef __NVGNB__
            gnbNum = gnbIdx;
#else
            if (TRUE == FOO.VF_MultipleOperatorRanSupport)
            {
                gnbNum = gnbIdx;
            }
            else
            {
                uint16_t idx;
                for (idx = 0; idx < MAX_GNB_PER_SYS; idx++)
                {
                    pGnbDu = &GNBINFO[idx].gnbDu[endPointIdx];
                    
                    if (pGnbDu->pldStatus != EQUIP) continue;
                    
                    if (pGnbDu->gNBIdx == (uint32_t)gnbIdx)
                    {
                        gnbNum = idx;
                        break;
                    }
                }
            }
#endif
            if (gnbNum >= MAX_GNB_PER_SYS)
            {
                VCCB_PRINTF("[%s] Delete Fail (gnbIdx:%d endPointIdx:%d)\n", __func__, gnbIdx, endPointIdx);
                return ERROR;
            }

            pGnbDu = &GNBINFO[gnbNum].gnbDu[endPointIdx];

            pGnbDu->pldStatus = N_EQUIP;

            pGnbDu->overloadStatus = ci_not_overload;  // FnVCCB_InitGnbInfo
            pGnbDu->boardType = BoardType_GCB;
            pGnbDu->rrcVersion[0] = 0;
            pGnbDu->rrcVersion[1] = 0;
            pGnbDu->rrcVersion[2] = 0;
            pGnbDu->gNBIdx = 0xFFFF;

            VCCB_PRINTF("[%s] Success (gnbNum:%d,endPointIdx:%d)\n", __func__, gnbNum, endPointIdx);
            return GOOD;

        case UPDATE_TYPE_CREATE_TPL:
        case UPDATE_TYPE_CHANGE_TPL:
            result = FnVCCB_GetTuple(REL_DU_STATUS_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
            if (result < 0)
            {
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d) (%d:%d)\n", __func__, result, gnbIdx, endPointIdx);
                return (int16_t)result;
            }

            /* get gnbNum */
#ifdef __NVGNB__
            gnbNum = gnbIdx;
#else
            if (TRUE == FOO.VF_MultipleOperatorRanSupport)
            {
                gnbNum = gnbIdx;
            }
            else
            {
                // In case buf.status = N_EQUIP, pld parameters except key value(gNBIdx, endPointIdx) are 0.
                if (buf.status == EQUIP)
                {
                    VCCB_GET_GNB_NUM_FROM_ID_RETURN(buf.gNBId, gnbNum);
                }
                else
                {
                    uint16_t idx;
                    for (idx = 0; idx < MAX_GNB_PER_SYS; idx++)
                    {
                        VccbGnbInfo_type *const pGnb = &GNBINFO[idx];
                        if (gnbIdx == (int)pGnb->gnbDu[endPointIdx].gNBIdx && EQUIP == pGnb->gnbDu[endPointIdx].status)
                        {
                            gnbNum = idx;
                            break;
                        }
                    }
                }
            }
#endif
            if (gnbNum >= MAX_GNB_PER_SYS)
            {
                return GOOD;
            }
            pGnbDu = &GNBINFO[gnbNum].gnbDu[endPointIdx];

            if (buf.status != EQUIP)
            {
                pGnbDu->pldStatus = N_EQUIP;
                pGnbDu->overloadStatus = ci_not_overload;  // FnVCCB_InitGnbInfo
                pGnbDu->boardType = BoardType_GCB;
                pGnbDu->rrcVersion[0] = 0;
                pGnbDu->rrcVersion[1] = 0;
                pGnbDu->rrcVersion[2] = 0;

                pGnbDu->gNBIdx = 0xFFFF;
                VCCB_PRINTF(
                    "[%s] N_EQUIP Success (gnbIdx:%d,endPointIdx:%d,gnbNum:%d)\n", __func__, gnbIdx, endPointIdx, gnbNum);
            }
            else
            {
                enumOverloadInfo_type orgOverloadStatus = pGnbDu->overloadStatus;
                uint8_t orgBoardType = pGnbDu->boardType;
                uint32_t orgGnbIdx = pGnbDu->gNBIdx;
                uint8_t orgRrcVersion0 = pGnbDu->rrcVersion[0];
                uint8_t orgRrcVersion1 = pGnbDu->rrcVersion[1];
                uint8_t orgRrcVersion2 = pGnbDu->rrcVersion[2];

                if (buf.overloadStatus)
                {
                    pGnbDu->overloadStatus = ci_overload;
                }
                else
                {
                    pGnbDu->overloadStatus = ci_not_overload;
                }

                pGnbDu->pldStatus = buf.status;

                pGnbDu->boardType = (uint8_t)buf.boardType;
                pGnbDu->rrcVersion[0] = buf.rrcVersion[0];
                pGnbDu->rrcVersion[1] = buf.rrcVersion[1];
                pGnbDu->rrcVersion[2] = buf.rrcVersion[2];

                pGnbDu->gNBIdx = gnbIdx;
                pGnbDu->gnbDuId = buf.duId;

                uint32_t orgSwVersionXyz = pGnbDu->swVersion.xyz;
                VLIB_CreateSwVersionFromPld(buf.swVersion, &pGnbDu->swVersion);

                if (pGnbDu->overloadStatus != orgOverloadStatus || pGnbDu->boardType != orgBoardType ||
                    pGnbDu->gNBIdx != orgGnbIdx || pGnbDu->rrcVersion[0] != orgRrcVersion0 ||
                    pGnbDu->rrcVersion[1] != orgRrcVersion1 || pGnbDu->rrcVersion[2] != orgRrcVersion2 ||
                    pGnbDu->swVersion.xyz != orgSwVersionXyz)
                {
                    VCCB_PRINTF(
                        "[%s] Success (gnbIdx:%d,endPointIdx:%d,gnbId:%u,gnbNum:%d,ovld:%d,boardType:%d,rrcVer:%d.%d.%d)\n",
                        __func__, gnbIdx, endPointIdx, buf.gNBId, gnbNum, buf.overloadStatus, buf.boardType, buf.rrcVersion[0],
                        buf.rrcVersion[1], buf.rrcVersion[2]);
                }
            }

            return GOOD;

        default:
            VCCB_PRINTF("[%s] Not handle type %d (gnbIdx:%d,endPointIdx:%d)\n", __func__, pNotifyPld->updateType, gnbIdx, endPointIdx);
            return GOOD;
    }
}


int16_t VCCB_getTuple_PLDAupfStatus(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;

    int result;
    PLDAupfStatus buf = {};
    AupfStatusInfo_type *pGnbAupf = NULL;
    uint16_t gnbNum = MAX_GNB_PER_SYS;

    uint16_t gnbIdx = (uint16_t)pNotifyPld->tpKey[0];
    int endPointIdx = pNotifyPld->tpKey[1];

    VCCB_CHECK_E_RANGE_AND_RETURN(endPointIdx, MAX_GNB_CU_UP_PER_GNB_CU_CP);

    switch (pNotifyPld->updateType)
    {
        case UPDATE_TYPE_DELETE_TPL:
            // get gnbNum
#ifdef __NVGNB__
            gnbNum = gnbIdx;
#else
            if (TRUE == FOO.VF_MultipleOperatorRanSupport)
            {
                gnbNum = gnbIdx;
            }
            else
            {
                uint16_t idx;
                for (idx = 0; idx < MAX_GNB_PER_SYS; idx++)
                {
                    pGnbAupf = &GNBINFO[idx].aupf.gnbCuUp[endPointIdx];

                    if (pGnbAupf->status != EQUIP) continue;

                    if (pGnbAupf->gNBIdx == gnbIdx)
                    {
                        gnbNum = idx;
                        break;
                    }
                }
            }
#endif
            if (gnbNum >= MAX_GNB_PER_SYS)
            {
                VCCB_PRINTF("[%s] Delete Fail (gnbIdx:%d endPointIdx:%d)\n", __func__, gnbIdx, endPointIdx);
                return ERROR;
            }

            FnVCCB_InitAupfStautsInfo_PLDAupfStatus(&GNBINFO[gnbNum].aupf.gnbCuUp[endPointIdx]);
            
            VCCB_PRINTF("[%s] Success (gnbNum:%d,endPointIdx:%d)\n", __func__, gnbNum, endPointIdx);
            return GOOD;

        case UPDATE_TYPE_CREATE_TPL:
        case UPDATE_TYPE_CHANGE_TPL:
            result = FnVCCB_GetTuple(REL_AUPF_STATUS_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
            if (result < 0)
            {
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d) (%d:%d)\n", __func__, result, gnbIdx, endPointIdx);
                return (int16_t)result;
            }

            /* get gnbNum */
#ifdef __NVGNB__
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbIdx, MAX_GNB_PER_SYS);
            gnbNum = gnbIdx;
#else
            if (TRUE == FOO.VF_MultipleOperatorRanSupport)
            {
                VCCB_CHECK_E_RANGE_AND_RETURN(gnbIdx, MAX_GNB_PER_SYS);
                gnbNum = gnbIdx;
            }
            else
            {
                // In case buf.status = N_EQUIP, pld parameters except key value(gNBIdx, endPointIdx) are 0.
                if (buf.status == EQUIP)
                {
                    VCCB_GET_GNB_NUM_FROM_ID_RETURN(buf.gNBId, gnbNum);   
                }
                else
                {
                    uint16_t idx;
                    for (idx = 0; idx < MAX_GNB_PER_SYS; idx++)
                    {
                        VccbGnbInfo_type *const pGnb = &GNBINFO[idx];
                        if (gnbIdx == (int)pGnb->aupf.gnbCuUp[endPointIdx].gNBIdx &&
                            EQUIP == pGnb->aupf.gnbCuUp[endPointIdx].status)
                        {
                            gnbNum = idx;
                            break;
                        }
                    }
                }
            }
#endif
            if (gnbNum >= MAX_GNB_PER_SYS)
            {
                return GOOD;
            }

            pGnbAupf = &GNBINFO[gnbNum].aupf.gnbCuUp[endPointIdx];
            if (buf.status != EQUIP)
            {
                FnVCCB_InitAupfStautsInfo_PLDAupfStatus(&GNBINFO[gnbNum].aupf.gnbCuUp[endPointIdx]);                
            }
            else
            {
                FnVCCB_SetAupfStautsInfo_PLDAupfStatus(pGnbAupf, &buf);   
            }

            VCCB_PRINTF("[%s] Success (gnbIdx:%d,endPointIdx:%d,gnbId:%u,gnbNum:%d, swVersion=0x%x)\n", __func__, gnbIdx, endPointIdx,
                buf.gNBId, gnbNum, pGnbAupf->swVersion.xyz);
            return GOOD;

        default:
            VCCB_PRINTF("[%s] Not handle type %d (gnbIdx:%d,endPointIdx:%d)\n", __func__, pNotifyPld->updateType, gnbIdx, endPointIdx);
            return GOOD;
    }
}

int16_t VCCB_getTuple_PLDAmfStatus(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;

    int result;
    PLDAmfStatus buf = {};

    uint16_t gnbIdx = (uint16_t)pNotifyPld->tpKey[0];
    int endPointIdx = pNotifyPld->tpKey[1];

    VccbCfgInfo_type *const pCfg = CFG;
    uint16_t gnbNum = MAX_GNB_PER_SYS;
    uint8_t oldStatus;
    int8_t oldServiceState;

    VCCB_CHECK_E_RANGE_AND_RETURN(endPointIdx, MAX_AMF_PER_GNB_CU_CP);

    switch (pNotifyPld->updateType)
    {
        case UPDATE_TYPE_DELETE_TPL:
            // get gnbNum
#ifdef __NVGNB__
            gnbNum = gnbIdx;
#else
            if (TRUE == FOO.VF_MultipleOperatorRanSupport)
            {
                gnbNum = gnbIdx;
            }
            else
            {
                uint16_t idx;
                for (idx = 0; idx < MAX_GNB_PER_SYS; idx++)
                {
                    PLDAmfStatus *const pAmfStatus = &pCfg->amf.pldAmfStatus[idx][endPointIdx];

                    if (pAmfStatus->status != EQUIP) continue;

                    if (pAmfStatus->gNBIdx == gnbIdx)
                    {
                        gnbNum = idx;
                        break;
                    }
                }
            }
#endif
            if (gnbNum >= MAX_GNB_PER_SYS)
            {
                VCCB_PRINTF("[%s] Delete Fail (gnbIdx:%d endPointIdx:%d)\n", __func__, gnbIdx, endPointIdx);
                return ERROR;
            }

            memset(&pCfg->amf.pldAmfStatus[gnbNum][endPointIdx], 0, sizeof(PLDAmfStatus));
            VCCB_PRINTF("[%s] Success (gnbNum:%d,endPointIdx:%d)\n", __func__, gnbNum, endPointIdx);
            return GOOD;


        case UPDATE_TYPE_CREATE_TPL:
        case UPDATE_TYPE_CHANGE_TPL:
            result = FnVCCB_GetTuple(REL_AMF_STATUS_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
            if (result < 0)
            {
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d) (%d:%d)\n", __func__, result, gnbIdx, endPointIdx);
                return (int16_t)result;
            }

#ifdef __NVGNB__
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbIdx, MAX_GNB_PER_SYS);
            gnbNum = gnbIdx;
#else
            if (TRUE == FOO.VF_MultipleOperatorRanSupport)
            {
                VCCB_CHECK_E_RANGE_AND_RETURN(gnbIdx, MAX_GNB_PER_SYS);
                gnbNum = gnbIdx;
            }
            else
            {
                if (buf.status == EQUIP)
                {
                    VCCB_GET_GNB_NUM_FROM_ID_RETURN(buf.gNBId, gnbNum);
                }
                else
                {
                    uint16_t idx;
                    for (idx = 0; idx < MAX_GNB_PER_SYS; idx++)
                    {
                        if (gnbIdx == (int)pCfg->amf.pldAmfStatus[idx][endPointIdx].gNBIdx &&
                            EQUIP == pCfg->amf.pldAmfStatus[idx][endPointIdx].status)
                        {
                            gnbNum = idx;
                            break;
                        }
                    }
                }
            }
#endif
            if (gnbNum >= MAX_GNB_PER_SYS)
            {
                return ERROR;
            }

            oldStatus = pCfg->amf.pldAmfStatus[gnbNum][endPointIdx].status;
            oldServiceState = pCfg->amf.pldAmfStatus[gnbNum][endPointIdx].serviceState;

            memcpy(&pCfg->amf.pldAmfStatus[gnbNum][endPointIdx], &buf, sizeof(PLDAmfStatus));

            if ((oldStatus != pCfg->amf.pldAmfStatus[gnbNum][endPointIdx].status) ||
                (oldServiceState != pCfg->amf.pldAmfStatus[gnbNum][endPointIdx].serviceState))
            {
                VCCB_PRINTF("[%s] status:%d->%d serviceState:%d->%d (gnbNum:%d,endPointIdx:%d,gnbId:%u)\n", __func__, oldStatus,
                    pCfg->amf.pldAmfStatus[gnbNum][endPointIdx].status, oldServiceState,
                    pCfg->amf.pldAmfStatus[gnbNum][endPointIdx].serviceState, gnbNum, endPointIdx, buf.gNBId);
            }

            VCCB_PRINTF("[%s] Success (gnbNum:%d,endPointIdx:%d,gnbId:%u)\n", __func__, gnbNum, endPointIdx, buf.gNBId);
            return GOOD;

        default:
            VCCB_PRINTF("[%s] Not handle type %d (gnbIdx:%d,endPointIdx:%d)\n", __func__, pNotifyPld->updateType, gnbIdx, endPointIdx);
            return GOOD;
    }
}

int16_t VCCB_getTuple_PLDAmfTnlStatus(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;

    int result;
    PLDAmfTnlStatus buf = {};

    uint16_t gnbIdx = (uint16_t)pNotifyPld->tpKey[0];
    int endPointIdx = pNotifyPld->tpKey[1];
    int tnlIdx = pNotifyPld->tpKey[2];

    VccbCfgInfo_type *const pCfg = CFG;
    uint16_t gnbNum = MAX_GNB_PER_SYS;
    uint8_t oldStatus;

    VCCB_CHECK_E_RANGE_AND_RETURN(endPointIdx, MAX_AMF_PER_GNB_CU_CP);
    VCCB_CHECK_E_RANGE_AND_RETURN(tnlIdx, MAX_TNL_PER_AMF);

    switch (pNotifyPld->updateType)
    {
        case UPDATE_TYPE_DELETE_TPL:
            // get gnbNum
#ifdef __NVGNB__
            gnbNum = gnbIdx;
#else
            if (TRUE == FOO.VF_MultipleOperatorRanSupport)
            {
                gnbNum = gnbIdx;
            }
            else
            {
                uint16_t idx;
                for (idx = 0; idx < MAX_GNB_PER_SYS; idx++)
                {
                    PLDAmfTnlStatus *const pAmfTnl = &pCfg->amf.pldAmfTnlStatus[idx][endPointIdx][tnlIdx];

                    if (pAmfTnl->status != EQUIP) continue;

                    if (pAmfTnl->gNBIdx == gnbIdx)
                    {
                        gnbNum = idx;
                        break;
                    }
                }
            }
#endif
            if (gnbNum >= MAX_GNB_PER_SYS)
            {
                VCCB_PRINTF("[%s] Delete Fail (gnbIdx:%d endPointIdx:%d tnlIdx:%d)\n", __func__, gnbIdx, endPointIdx, tnlIdx);
                return ERROR;
            }

            memset(&pCfg->amf.pldAmfTnlStatus[gnbNum][endPointIdx][tnlIdx], 0, sizeof(PLDAmfTnlStatus));
            VCCB_PRINTF("[%s] Success (gnbNum:%d,endPointIdx:%d)\n", __func__, gnbNum, endPointIdx);
            return GOOD;

        case UPDATE_TYPE_CREATE_TPL:
        case UPDATE_TYPE_CHANGE_TPL:

            result = FnVCCB_GetTuple(REL_AMF_TNL_STATUS_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
            if (result < 0)
            {
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d) (%d:%d:%d)\n", __func__, result, gnbIdx, endPointIdx, tnlIdx);
                return (int16_t)result;
            }

#ifdef __NVGNB__
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbIdx, MAX_GNB_PER_SYS);
            gnbNum = gnbIdx;
#else
            if (TRUE == FOO.VF_MultipleOperatorRanSupport)
            {
                VCCB_CHECK_E_RANGE_AND_RETURN(gnbIdx, MAX_GNB_PER_SYS);
                gnbNum = gnbIdx;
            }
            else
            {
                if (buf.status == EQUIP)
                {
                    VCCB_GET_GNB_NUM_FROM_ID_RETURN(buf.gNBId, gnbNum);
                }
                else
                {
                    uint16_t idx;
                    for (idx = 0; idx < MAX_GNB_PER_SYS; idx++)
                    {
                        if (gnbIdx == (int)pCfg->amf.pldAmfTnlStatus[idx][endPointIdx][tnlIdx].gNBIdx &&
                            EQUIP == pCfg->amf.pldAmfTnlStatus[idx][endPointIdx][tnlIdx].status)
                        {
                            gnbNum = idx;
                            break;
                        }
                    }
                }
            }
#endif
            if (gnbNum >= MAX_GNB_PER_SYS)
            {
                return ERROR;
            }

            oldStatus = pCfg->amf.pldAmfTnlStatus[gnbNum][endPointIdx][tnlIdx].status;

            memcpy(&pCfg->amf.pldAmfTnlStatus[gnbNum][endPointIdx][tnlIdx], &buf, sizeof(PLDAmfTnlStatus));

            if (oldStatus != pCfg->amf.pldAmfTnlStatus[gnbNum][endPointIdx][tnlIdx].status)
            {
                VCCB_PRINTF("[%s] status:%d->%d (gnbNum:%d,endPointIdx:%d,gnbId:%u)\n", __func__, oldStatus,
                    pCfg->amf.pldAmfTnlStatus[gnbNum][endPointIdx][tnlIdx].status, gnbNum, endPointIdx, buf.gNBId);
            }

            VCCB_PRINTF("[%s] Success (gnbNum:%d,endPointIdx:%d,tnlIdx:%d,gnbId:%u)\n", __func__, gnbNum, endPointIdx, tnlIdx,
                buf.gNBId);
            return GOOD;

        default:
            VCCB_PRINTF("[%s] Not handle type %d (gnbIdx:%d,endPointIdx:%d)\n", __func__, pNotifyPld->updateType, gnbIdx, endPointIdx);
            return GOOD;
    }
}

int16_t VCCB_getTuple_PLDAmfTnlSctpState(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;
    
    VCCB_CHECK_PLD_UPDATE_TYPE_AND_PRINT_WARNING(pNotifyPld->updateType, UPDATE_TYPE_CHANGE_TPL);

    int result;
    PLDAmfTnlSctpState buf = {};

    int gnbIdx = pNotifyPld->tpKey[0];
    int endPointIdx = pNotifyPld->tpKey[1];
    int tnlIdx = pNotifyPld->tpKey[2];

    VCCB_CHECK_E_RANGE_AND_RETURN(endPointIdx, MAX_AMF_PER_GNB_CU_CP);
    VCCB_CHECK_E_RANGE_AND_RETURN(tnlIdx, MAX_TNL_PER_AMF);

    result = FnVCCB_GetTuple(REL_AMF_TNL_SCTP_STATE_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
    if (result < 0)
    {
        VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d) (%d:%d:%d)\n", __func__, result, gnbIdx, endPointIdx, tnlIdx);
        return (int16_t)result;
    }

    VccbCfgInfo_type *const pCfg = CFG;
    uint16_t gnbNum = 0xFFFF;
    
    uint16_t loop;
    for (loop = 0; loop < MAX_GNB_PER_SYS; loop++)
    {
        // Note that CFG->amf.pldAmfTnlStatus and CFG->amf.pldAmfTnlSctpState are correlated
        if (gnbIdx == (int)pCfg->amf.pldAmfTnlStatus[loop][endPointIdx][tnlIdx].gNBIdx &&
            EQUIP == pCfg->amf.pldAmfTnlStatus[loop][endPointIdx][tnlIdx].status)
        {
            gnbNum = loop;
            break;
        }
    }

    if (gnbNum == 0xFFFF)
    {
        return ERROR;
    }

    int oldSctpState = pCfg->amf.pldAmfTnlSctpState[gnbNum][endPointIdx][tnlIdx].sctpState;

    memcpy(&pCfg->amf.pldAmfTnlSctpState[gnbNum][endPointIdx][tnlIdx], &buf, sizeof(PLDAmfTnlSctpState));

    if (oldSctpState != pCfg->amf.pldAmfTnlSctpState[gnbNum][endPointIdx][tnlIdx].sctpState)
    {
        VCCB_PRINTF("[%s] oldSctpState:%d->%d (gnbNum:%d,endPointIdx:%d)\n", __func__, oldSctpState,
            pCfg->amf.pldAmfTnlSctpState[gnbNum][endPointIdx][tnlIdx].sctpState, gnbNum, endPointIdx);
    }

    VCCB_PRINTF("[%s] Success (gnbNum:%d,endPointIdx:%d,tnlIdx:%d)\n", __func__, gnbNum, endPointIdx, tnlIdx);
    return GOOD;
}

int16_t VCCB_getTuple_PLDCellStatus(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;
    
    VCCB_CHECK_PLD_UPDATE_TYPE_AND_PRINT_WARNING(pNotifyPld->updateType, UPDATE_TYPE_CHANGE_TPL);
    STANDBY_RETURN_OK;

    int result;
    uint16_t gnbNum = 0;
    uint16_t cellNum = MAX_CELL_NUM_VCCB;
    PLDCellStatus buf = {};
    int cellIdx = pNotifyPld->tpKey[0];

    bool createFlag = false;
    bool deleteFlag = false;

    result = FnVCCB_GetTuple(REL_CELL_STATUS_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
    if (result < 0)
    {
        VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d) (%d)\n", __func__, result, cellIdx);
        return (int16_t)result;
    }

    // ODF_HO_21B TODO_TODO - Check both active and standby are processed.
    INIT_FLAG_FALSE(sTriggerOndemandHandoverByPLD);  // ODF_HO_21B

    if (buf.status != EQUIP)
    {
        // in case PLD cell status is changed from EQUIP to N_EQUIP, checking validity is required
#ifdef __NVGNB__
        VCCB_CHECK_E_RANGE_AND_GOOD(buf.gnbNum, MAX_GNB_PER_SYS);
        gnbNum = buf.gnbNum;
#else
        if (TRUE == FOO.VF_MultipleOperatorRanSupport)
        {
            VCCB_CHECK_E_RANGE_AND_GOOD(buf.gnbNum, MAX_GNB_PER_SYS);
            gnbNum = buf.gnbNum;
        }
        else
        {
            VCCB_GET_GNB_NUM_FROM_ID_RETURN_GOOD(buf.gNBId, gnbNum);
        }
#endif

        cellNum = FnVCCB_GetCellNum(gnbNum, buf.cellId);
        if (cellNum < MAX_CELL_NUM_VCCB)
        {
            FnVCCB_InitPldNrCellPlmnInfo(&CELLINFO[cellNum]);
        }

        FnVCCB_HandlePldCellIdChangeNoti(&buf, gnbNum, PLD_NOTI_NEQUIP);

        deleteFlag = true;
    }
    else
    {
#ifdef __NVGNB__
        VCCB_CHECK_E_RANGE_AND_RETURN(buf.gnbNum, MAX_GNB_PER_SYS);
        gnbNum = buf.gnbNum;
#else
        if (TRUE == FOO.VF_MultipleOperatorRanSupport)
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(buf.gnbNum, MAX_GNB_PER_SYS);
            gnbNum = buf.gnbNum;
        }
        else
        {
            VCCB_GET_GNB_NUM_FROM_ID_RETURN(buf.gNBId, gnbNum);
        }
#endif
        VCCB_CHECK_E_RANGE_AND_RETURN(buf.cellId, MAX_CELL_IDENTITY);

        FnVCCB_HandlePldCellIdChangeNoti(&buf, gnbNum, PLD_NOTI_EQUIP_DEL);

        cellNum = FnVCCB_GetCellNum(gnbNum, buf.cellId);
        if (cellNum >= MAX_CELL_NUM_VCCB)
        {
            cellNum = FnVCCB_AllocateCell(gnbNum, buf.cellId);
            if (cellNum >= MAX_CELL_NUM_VCCB)
            {
                VCCB_PRINT_ERROR("FnVCCB_AllocateCell ERROR!! for cellIdentity(%d)\n", buf.cellId);
                return ERROR;
            }
            createFlag = true;

            VccbCellInfo_type *pCell;
            for (uint16_t tCell = 0; tCell < MAX_CELL_NUM_VCCB; tCell++)
            {
                if (tCell == cellNum) continue;

                pCell = &CELLINFO[tCell];

                // If there is another cellNum with the same pldCellIdx as the newly allocated cellNum, 
                // change Old tCell's pldState to N_EQUIP.
                // there is no need to check that pldState is N_EQUIP. 
                // This is because if the cellIdx value exists, pldState is also set to EQUIP.(ref> VLIB_GetPldCellStatusParam)
                if (pCell->pldCellIdx == buf.cellIdx && pCell->status == N_EQUIP)
                {
                    VCCB_PRINTF("[%s] initialize - cellNum:%d pldCellIdx:%d gnbNum:%d cellIdentity:%d\n", __func__,
                        tCell, pCell->pldCellIdx, gnbNum, pCell->cellIdentity);
                        
                    VLIB_UpdateCellStatusHistory(tCell, PLD_NOTI_EQUIP_INVALID_CELL_DEL);

                    pCell->pldState = N_EQUIP;
                    pCell->pldCellIdx = 0xFFFF;
                }
            }
        }
        
        VLIB_GetPldCellStatusParam(&buf, gnbNum, cellNum);
        VLIB_UpdateCellStatusHistory(cellNum, PLD_NOTI_EQUIP);
    }

    if (cellNum < MAX_CELL_NUM_VCCB)
    {
        FnVCCB_BackupCellInfo(cellNum);
    }

    TRIGGER_ODF_HO(sTriggerOndemandHandoverByPLD);  // ODF_HO_21B

    uint16_t envCellNum = 0xFFFF;
    uint16_t mapCellNum = 0xFFFF;

    if (gnbNum < MAX_GNB_PER_SYS && buf.cellId < MAX_CELL_IDENTITY)
        envCellNum = GNBINFO[gnbNum].env.cellNum[buf.cellId];
    if (buf.cellIdx < MAX_CELL_PER_VNF) 
        mapCellNum = mappingCellNumAndPldCellIdx[buf.cellIdx];

    if (createFlag || deleteFlag)
    {
        VCCB_PRINTF("[%s] Success (idx:%d sts:%d gnb:(%d/%d), cellId:%d cellNum:%d (%u/%u, %d/%d))\n", __func__,
            buf.cellIdx, buf.status, buf.gNBId, gnbNum, buf.cellId, cellNum, envCellNum, mapCellNum, createFlag, deleteFlag);
    }

#if !defined(NEW_HOST_SIM) && !defined(IPC_TEST)
    if (createFlag)
    {
        // If PLDCellTraceStatus is growed before PLDCellStatus, read at this time
        // PLDCellStatus and PLDCellTraceStatus have same key (just cellIdx)
        pRxMsg->msgHdr.msgType = msgDBInformPldNotiDbiAll_id;  // for direct read not use MSG piggyback
        VCCB_getTuple_PLDCellTraceStatus(pRxMsg);
    }
#endif

    return GOOD;
}

int16_t VCCB_getTuple_PLDGnbBarringInfo(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;
    
    VCCB_CHECK_PLD_UPDATE_TYPE_AND_PRINT_WARNING(pNotifyPld->updateType, UPDATE_TYPE_CHANGE_TPL);

    int result;
    PLDGnbBarringInfo buf = {};
    uint16_t gnbNum = 0xFFFF;
    uint16_t gnbIdx = (uint16_t)pNotifyPld->tpKey[0];

    result = FnVCCB_GetTuple(REL_GNB_BARRING_INFO_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
    if (result < 0)
    {
        VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d) (%d)\n", __func__, result, gnbIdx);
        return (int16_t)result;
    }

    /* get gnbNum */
#ifdef __NVGNB__
    gnbNum = gnbIdx;
#else
    if (TRUE == FOO.VF_MultipleOperatorRanSupport)
    {
        gnbNum = gnbIdx;
    }
    else
    {
        // In case buf.status = N_EQUIP, pld parameters except key value(gNBIdx, endPointIdx) are 0.
        if (buf.status != EQUIP)
        {
            uint16_t idx = 0;

            for (idx = 0; idx < MAX_GNB_PER_SYS; idx++)
            {
                VccbGnbInfo_type *const pGnb = &GNBINFO[idx];
                if (gnbIdx == (int)pGnb->pldGnbBarringInfo.gnbIdx && EQUIP == pGnb->pldGnbBarringInfo.status)
                {
                    gnbNum = idx;
                    break;
                }
            }
            if (gnbNum == 0xFFFF)
            {
                return GOOD;
            }
        }
        else
        {
            VCCB_GET_GNB_NUM_FROM_ID_RETURN(buf.gnbId, gnbNum);
        }
    }
#endif
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    if (buf.status != EQUIP)
    {
        memset(&pGnb->pldGnbBarringInfo, 0, sizeof(PLDGnbBarringInfo));
    }
    else
    {
        memcpy(&pGnb->pldGnbBarringInfo, &buf, sizeof(PLDGnbBarringInfo));
    }
    VCCB_PRINTF("[%s] Success (gnbIdx:%d,gnbId:%u,gnbNum:%d,amfNotAvailable:(%d:%d))\n", __func__, gnbIdx, buf.gnbId,
        gnbNum, pGnb->pldGnbBarringInfo.amfNotAvailable, buf.amfNotAvailable);

    return GOOD;
}

int16_t VCCB_getTuple_PLDGnbCallState(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;
    
    VCCB_CHECK_PLD_UPDATE_TYPE_AND_PRINT_WARNING(pNotifyPld->updateType, UPDATE_TYPE_CHANGE_TPL);

    int result;
    PLDGnbCallState buf = {};
    uint16_t gnbNum = 0xFFFF;
    uint16_t gnbIdx = (uint16_t)pNotifyPld->tpKey[0];
    uint16_t cellNum;

    result = FnVCCB_GetTuple(REL_GNB_CALL_STATE_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
    if (result < 0)
    {
        VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d) (gnbIdx: %d)\n", __func__, result, gnbIdx);
        return (int16_t)result;
    }

    /* get gnbNum */
#ifdef __NVGNB__
    gnbNum = gnbIdx;
#else
    if (TRUE == FOO.VF_MultipleOperatorRanSupport)
    {
        gnbNum = gnbIdx;
    }
    else
    {
        VCCB_GET_GNB_NUM_FROM_ID_RETURN(buf.gnbId, gnbNum);
    }
#endif
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    if (buf.status && buf.activationState)
    {
        pGnb->pldActivationState = EQUIP;
    }
    else
    {
        pGnb->pldActivationState = N_EQUIP;
    }

    for (cellNum = 0; cellNum < MAX_CELL_NUM_VCCB; cellNum++)
    {
        VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
        if (gnbNum != pCell->gnbNum) continue;
        if (pCell->status == N_EQUIP && pCell->pldState == N_EQUIP) continue;
        VLIB_UpdateCellStatusHistory(cellNum, PLD_GNBSTATE_CHANGED);
    }

    // VCCB_PRINTF("[%s] Success (gnbIdx:%d,gnbId:%u,gnbNum:%d,activationState:%d)\n", __func__, gnbIdx, buf.gnbId,
    // gnbNum, buf.activationState);
    return GOOD;
}

int16_t VCCB_getTuple_PLDCpuUtilExt(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;
    
    VCCB_CHECK_PLD_UPDATE_TYPE_AND_PRINT_WARNING(pNotifyPld->updateType, UPDATE_TYPE_CHANGE_TPL);

    int result;
    int isValidTuple = 0;
    PLDCpuUtilExt buf = {};

    result = FnVCCB_GetTuple(REL_CPU_UTIL_EXT_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
    if (result < 0)
    {
        VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d)\n", __func__, result);
        return (int16_t)result;
    }

#ifdef __NVGNB__
    if((ENV->drlibNvgnbInfo.mainCardType == DRLIB_NVGNB_GMA1_NR_LTE) || (ENV->drlibNvgnbInfo.mainCardType == DRLIB_NVGNB_GMA1_NR_ONLY))
    {
        isValidTuple = buf.unitType == (ENV->neInfo.unitType) && ((buf.cpuId == 0) || (buf.cpuId == 1));
    }
    else
    {
        isValidTuple = buf.unitType == (ENV->neInfo.unitType) && (buf.cpuId == ENV->neInfo.cpuId);
    }
#else
    #ifdef __CNF__
        isValidTuple = (buf.unitType == CPP) && (buf.unitId == CFG->vm.unitId);  // unitType CPP for CNF
    #else // VNF
        isValidTuple = (buf.unitType == CPC) && (buf.unitId == CFG->vm.unitId);  // unitType CPC for VNF
    #endif
#endif
    if (isValidTuple && buf.ValidFlag == 1)
    {
        if (CFG->overloadStatus != buf.cpuAlarmStatus)
        {
            // SVR23B : FGR-LC0302 FR163.CACP.SR1.HD1
#ifdef __NVGNB__
            if((ENV->drlibNvgnbInfo.mainCardType == DRLIB_NVGNB_GMA1_NR_LTE) || 
            (ENV->drlibNvgnbInfo.mainCardType == DRLIB_NVGNB_GMA1_NR_ONLY))
            {
#define getMin(a, b) (((a) == (AlarmPerceivedSeverity)(indeterminate)) ? (b) :       \
(((b) == (AlarmPerceivedSeverity)(indeterminate)) ? (a) : (((a) < (b)) ? (a) : (b))))
                CFG->overloadValue[buf.cpuId] = (uint8_t)buf.cpuAlarmStatus;
                CFG->overloadStatus = getMin(CFG->overloadValue[0], CFG->overloadValue[1]);
#undef getMin
            }
            else
            {
                CFG->overloadStatus = (uint8_t)buf.cpuAlarmStatus;
            }
#else            
            CFG->overloadStatus = (uint8_t)buf.cpuAlarmStatus;
#endif

            if (CFG->overloadStatus - 1 <= CFG->globalTraceInfo.stopThreshold)
                CFG->globalTraceInfo.traceDisabledDueOverload = 1;

            if (CFG->overloadStatus - 1 >= CFG->globalTraceInfo.resumeThreshold)
                CFG->globalTraceInfo.traceDisabledDueOverload = 0;

            CFG->cpuLoad = (uint8_t)buf.cpuLoad;

            VCCB_PRINTF("[PLD] Overload status updated - new value:(%d) \n", CFG->overloadStatus);
            VCCB_PRINTF("[PLD] Trace Overload flag traceDisabledDueOverload value:(%d) \n",
                CFG->globalTraceInfo.traceDisabledDueOverload);
            VCCB_PRINTF("[PLD] CpuLoad updated - new value:(%d) \n", CFG->cpuLoad);
        }
    }

    return GOOD;
}

int16_t VCCB_getTuple_PLDCellTraceStatus(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;
    
    VCCB_CHECK_PLD_UPDATE_TYPE_AND_PRINT_WARNING(pNotifyPld->updateType, UPDATE_TYPE_CHANGE_TPL);
    STANDBY_RETURN_OK;
    
    int result;
    uint16_t gnbNum = 0;
    uint16_t cellNum = MAX_CELL_NUM_VCCB;
    PLDCellTraceStatus buf = {};

    uint16_t cellIdx = (uint16_t)pNotifyPld->tpKey[0];

    result = FnVCCB_GetTuple(REL_CELL_TRACE_STATUS_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
    if (result < 0)
    {
        VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d) (%d)\n", __func__, result, cellIdx);
        return (int16_t)result;
    }

    if (buf.status != EQUIP)
    {
        // not update in this case, gNBId and cellId are not filled in case of EQUIP->N_EQUIP
        return GOOD;
    }

    gnbNum = buf.gnbNum;
#ifndef __NVGNB__
    if (TRUE == FOO.VF_MultipleOperatorRanSupport)
    {
    }
    else
    {
        VCCB_GET_GNB_NUM_FROM_ID_RETURN(buf.gNBId, gnbNum);
    }
#endif

    VCCB_CHECK_E_RANGE_AND_RETURN(buf.cellId, MAX_CELL_IDENTITY);

    cellNum = FnVCCB_GetCellNum(gnbNum, buf.cellId);
    if (cellNum >= MAX_CELL_NUM_VCCB)
    {
#if defined(NEW_HOST_SIM) || defined(IPC_TEST)
        cellNum = FnVCCB_AllocateCell(gnbNum, buf.cellId);
        if (cellNum >= MAX_CELL_NUM_VCCB)
        {
            VCCB_PRINT_ERROR("FnVCCB_AllocateCell ERROR!! for cellIdentity(%d)\n", buf.cellId);
            return ERROR;
        }
#else

        VCCB_PRINTF("[%s] Cell(gnbId:%d cellId:%d, PLD-key:%d) doesn't grow yet\n", __func__, 
                buf.gNBId, buf.cellId, cellIdx);

        return GOOD;
#endif
    }
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    ManagementTraceSessionPerCell_type *traceSession = &pCell->traceSession;

    traceSession->pldCellIndex = cellIdx;
    traceSession->trace.cellTraceAllowedFlag = buf.cellTraceAllowedFlag;
    traceSession->mdt.immediateMdtAllowedFlag = buf.immediateMdtAllowedFlag;
    traceSession->mdt.loggedMdtAllowedFlag = buf.loggedMdtAllowedFlag;

#ifdef __CNF__
    FnVCCB_BackupCellInfo(cellNum);
#else
    FnVCCB_BackupCellInfoPartial(cellNum, &pCell->traceSession.pldCellIndex, 
        sizeof(pCell->traceSession.pldCellIndex));
    FnVCCB_BackupCellInfoPartial(cellNum, &pCell->traceSession.trace.cellTraceAllowedFlag,
        sizeof(pCell->traceSession.trace.cellTraceAllowedFlag));
    FnVCCB_BackupCellInfoPartial(cellNum, &pCell->traceSession.mdt.immediateMdtAllowedFlag,
        sizeof(pCell->traceSession.mdt.immediateMdtAllowedFlag));
    FnVCCB_BackupCellInfoPartial(cellNum, &pCell->traceSession.mdt.loggedMdtAllowedFlag,
        sizeof(pCell->traceSession.mdt.loggedMdtAllowedFlag));
#endif

    VCCB_PRINTF(
        "[%s] Success (cellIdx:%d,cellNum:%d,gnbId:%u,gnbNum:%d,cellId:%d, AllowedFlags Trace:%d Immediate:%d Logged:%d)\n",
        __func__, cellIdx, cellNum, buf.gNBId, gnbNum, buf.cellId, buf.cellTraceAllowedFlag, buf.immediateMdtAllowedFlag,
        buf.loggedMdtAllowedFlag);

    return GOOD;
}

int16_t VCCB_getTuple_PLDTraceStatus(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;
    
    VCCB_CHECK_PLD_UPDATE_TYPE_AND_PRINT_WARNING(pNotifyPld->updateType, UPDATE_TYPE_CHANGE_TPL);

    int result;
    PLDTraceStatus buf = {};

    result = FnVCCB_GetTuple(REL_TRACE_STATUS_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
    if (result < 0)
    {
        VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d)\n", __func__, result);
        return (int16_t)result;
    }

    VCCB_PRINTF("PLDTraceStatus acpfIdx:%d status:%d acpfTraceAllowedFlag:%d ueTraceAllowedFlag:%d\n", buf.acpfIdx,
        buf.status, buf.acpfTraceAllowedFlag, buf.ueTraceAllowedFlag);

    CFG->globalTraceInfo.acpfTraceAllowedFlag = buf.acpfTraceAllowedFlag;
    CFG->globalTraceInfo.signaling.sigTraceAllowedFlag = buf.ueTraceAllowedFlag;

    VCCB_PRINTF("[%s] Success (acpfIdx:%d status:%d acpfTraceAllowedFlag:%d ueTraceAllowedFlag:%d)\n", __func__,
        buf.acpfIdx, buf.status, buf.acpfTraceAllowedFlag, buf.ueTraceAllowedFlag);

    return GOOD;
}

int16_t VCCB_getTuple_PLDImsiTrace(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;
    
    VCCB_CHECK_PLD_UPDATE_TYPE_AND_PRINT_WARNING(pNotifyPld->updateType, UPDATE_TYPE_CHANGE_TPL);

    int result;
    PLDImsiTrace buf = {};  // PLDImsiTrace buf

    result = FnVCCB_GetTuple(REL_IMSI_TRACE_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
    if (result < 0)
    {
        VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d)\n", __func__, result);
        return (int16_t)result;
    }

    make_Z_IMSI(&buf);

    VCCB_PRINTF("[%s] Success (imsiIdx:%d numOfImsi:%d)\n", __func__, buf.dbIndex, buf.numOfImsi);

    return GOOD;
}

int16_t VCCB_getTuple_PLDCpcUsageState(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;
    
    VCCB_CHECK_PLD_UPDATE_TYPE_AND_PRINT_WARNING(pNotifyPld->updateType, UPDATE_TYPE_CHANGE_TPL);

    int result;
    PLDCPCUsageState buf = {};

    result = FnVCCB_GetTuple(REL_CPC_USAGE_STATE_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
    if (result < 0)
    {
        VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d)\n", __func__, result);
        return (int16_t)result;
    }

    VCCB_PRINTF("PLDCPCUsageState cpcId:%d status:%d preScaleInStatus:%d usageState:%d upgradeStatus:%d\n", buf.cpcId,
        buf.status, buf.preScaleInStatus, buf.usageState, buf.upgradeStatus);

    if (buf.cpcId == CFG->vm.unitId)
    {
        int isReleaseNeeded =
            buf.upgradeStatus == CU_UPGRADE_RELEASE && CFG->pldCpcState.upgradeStatus != buf.upgradeStatus;
        CFG->pldCpcState.upgradeStatus = (uint8_t)buf.upgradeStatus;

        if (isReleaseNeeded)
        {
            VCCB_PRINTF("[PLD] upgradeState changed into 'release' - releasing all calls.\n");
            FnVCCB_ReleaseAllCalls(INTERNAL_CALL_RELEASE_CAUSE_VNF_UPGRADE);
        }
    }

    VCCB_PRINTF("[%s] Success \n", __func__);

    return GOOD;
}

int16_t VCCB_getTuple_PLDEutraCellInfo(message_type *pRxMsg)
{
    // This function supports Dynamic PLD

    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;

    int result;
    PLDEutraCellInfo buf = {};

    uint16_t gnbIdx = (uint16_t)pNotifyPld->tpKey[0];
    int endPointIdx = pNotifyPld->tpKey[1];

    uint16_t gnbNum = MAX_GNB_PER_SYS;
#ifdef __NVGNB__
#else
    uint16_t idx = 0;
    uint32_t tmpGnbId = UNKNOWN_GNB_ID;
#endif

    VCCB_CHECK_E_RANGE_AND_RETURN(endPointIdx, MAX_ENB_PER_GNB_CU_CP);

    switch (pNotifyPld->updateType)
    {
        case UPDATE_TYPE_DELETE_TPL:
            /* get gnbNum */
#ifdef __NVGNB__
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbIdx, MAX_GNB_PER_SYS);
            gnbNum = gnbIdx;
#else
            if (TRUE == FOO.VF_MultipleOperatorRanSupport)
            {
                VCCB_CHECK_E_RANGE_AND_RETURN(gnbIdx, MAX_GNB_PER_SYS);
                gnbNum = gnbIdx;
            }
            else
            {
                for (idx = 0; idx < MAX_GNB_PER_SYS; idx++)
                {
                    PLDEutraCellInfo *const pEutraCell = &CFG->pldEutraCellInfo[idx][endPointIdx];

                    if (pEutraCell->status != EQUIP) continue;

                    if (pEutraCell->gNBIdx == gnbIdx)
                    {
                        tmpGnbId = pEutraCell->gNBId;
                        break;
                    }
                }
                if (tmpGnbId == UNKNOWN_GNB_ID)
                {
                    VCCB_PRINTF("[%s] Delete Fail (gnbIdx:%d endPointIdx:%d)\n", __func__, gnbIdx, endPointIdx);
                    return ERROR;
                }
                VCCB_GET_GNB_NUM_FROM_ID_RETURN(tmpGnbId, gnbNum);
            }
#endif
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            memset(&CFG->pldEutraCellInfo[gnbNum][endPointIdx], 0, sizeof(PLDEutraCellInfo));
            VCCB_PRINTF("[%s] Success (gnbNum:%d,endPointIdx:%d)\n", __func__, gnbNum, endPointIdx);
            return GOOD;

        case UPDATE_TYPE_CREATE_TPL:
        case UPDATE_TYPE_CHANGE_TPL:
            result = FnVCCB_GetTuple(REL_EUTRA_CELL_INFO_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
            if (result < 0)
            {
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d) (%d:%d)\n", __func__, result, gnbIdx, endPointIdx);
                return (int16_t)result;
            }

            // Dynamic PLD does not give N_EQUIP tuple. (It will request UPDATE_TYPE_DELETE_TPL when N_EQUIP.)
            // Thus, handle notification only when status==1.
            if (buf.status != EQUIP)
            {
                VCCB_PRINT_ERROR("[%s] Ignore Notification (gnbIdx:%d,endPointIdx:%d,status:%d)\n", __func__, gnbIdx,
                    endPointIdx, buf.status);
                return GOOD;
            }

            /* get gnbNum */
#ifdef __NVGNB__
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbIdx, MAX_GNB_PER_SYS);
            gnbNum = gnbIdx;
#else
            if (TRUE == FOO.VF_MultipleOperatorRanSupport)
            {
                VCCB_CHECK_E_RANGE_AND_RETURN(gnbIdx, MAX_GNB_PER_SYS);
                gnbNum = gnbIdx;
            }
            else
            {
                VCCB_GET_GNB_NUM_FROM_ID_RETURN(buf.gNBId, gnbNum);
            }
#endif

            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            memcpy(&CFG->pldEutraCellInfo[gnbNum][endPointIdx], &buf, sizeof(PLDEutraCellInfo));
            VCCB_PRINTF("[%s] Success (gnbIdx:%d,gnbNum:%d,endPointIdx:%d,gnbId:%u)\n", __func__, gnbIdx, gnbNum, endPointIdx, buf.gNBId);
            return GOOD;

        default:
            VCCB_PRINTF("[%s] Not handle type %d (gnbIdx:%d,endPointIdx:%d)\n", __func__, pNotifyPld->updateType, gnbIdx, endPointIdx);
            return GOOD;
    }
}

int16_t VCCB_getTuple_PLDXnGnbStatus(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;

    int result;
    PLDXnGnbStatus buf = {};
    uint16_t gnbNum = MAX_GNB_PER_SYS;
    uint16_t idx = 0;
    uint16_t gnbIdx = (uint16_t)pNotifyPld->tpKey[0];
    uint16_t endPointIdx = (uint16_t)pNotifyPld->tpKey[1];
#ifdef __NVGNB__
#else
    uint32_t tmpGnbId = UNKNOWN_GNB_ID;
#endif
    VCCB_CHECK_E_RANGE_AND_RETURN(endPointIdx, MAX_XN_NBR_PER_GNB);

    switch (pNotifyPld->updateType)
    {
        case UPDATE_TYPE_DELETE_TPL:
        {
            // get gnbNum
#ifdef __NVGNB__
            gnbNum = gnbIdx;
#else
            if (TRUE == FOO.VF_MultipleOperatorRanSupport)
            {
                gnbNum = gnbIdx;
            }
            else
            {
                for (idx = 0; idx < MAX_GNB_PER_SYS; idx++)
                {
                    VccbGnbInfo_type *const pGnb = &GNBINFO[idx];

                    if (pGnb->xnGnbInfo[endPointIdx].status != EQUIP) continue;

                    if (pGnb->xnGnbInfo[endPointIdx].gNBIdx == gnbIdx)
                    {
                            tmpGnbId = pGnb->xnGnbInfo[endPointIdx].gNBId;
                            break;
                    }
                }
                if (tmpGnbId == UNKNOWN_GNB_ID)
                {
                    VCCB_PRINTF("[%s] Delete Fail (gnbIdx:%d endPointIdx:%d)\n", __func__, gnbIdx, endPointIdx);
                    return ERROR;
                }
                VCCB_GET_GNB_NUM_FROM_ID_RETURN(tmpGnbId, gnbNum);
            }
#endif
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
            memset(&pGnb->xnGnbInfo[endPointIdx], 0, sizeof(xnTaiInfo_type));
            xnNbrInfo_type *pXnNbr = &pGnb->xnNbr[endPointIdx];
            pXnNbr->xnapLinkState = CI_no_use;

            VCCB_PRINTF("[%s] Delete Success (gnbIdx:%d gnbNum:%d endPointIdx:%d)\n", __func__, gnbIdx, gnbNum,
                endPointIdx);
            return GOOD;
        }

        case UPDATE_TYPE_CREATE_TPL:
        case UPDATE_TYPE_CHANGE_TPL:
        {
            result = FnVCCB_GetTuple(REL_XN_GNB_STATUS_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
            if (result < 0)
            {
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d) (%d:%d)\n", __func__, result, gnbIdx, endPointIdx);
                return (int16_t)result;
            }
            // get gnbNum
#ifdef __NVGNB__
            gnbNum = gnbIdx;
#else
            if (TRUE == FOO.VF_MultipleOperatorRanSupport)
            {
                gnbNum = gnbIdx;
            }
            else
            {
                // In case buf.status = N_EQUIP, pld parameters except key value(gNBIdx, endPointIdx) are 0.
                if (buf.status != EQUIP)
                {
                    for (idx = 0; idx < MAX_GNB_PER_SYS; idx++)
                    {
                        VccbGnbInfo_type *const pGnb = &GNBINFO[idx];
                        if (gnbIdx == (int)pGnb->xnGnbInfo[endPointIdx].gNBIdx &&
                            EQUIP == pGnb->xnGnbInfo[endPointIdx].status)
                        {
                            gnbNum = idx;
                            break;
                        }
                    }
                }
                else
                {
                    VCCB_GET_GNB_NUM_FROM_ID_RETURN(buf.gNBId, gnbNum);
                }
            }
#endif

            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
            xnTaiInfo_type *const pXnGnb = &pGnb->xnGnbInfo[endPointIdx];
            xnNbrInfo_type *const pXnNbr = &pGnb->xnNbr[endPointIdx];

            pXnGnb->gNBIdx = buf.gNBIdx;
            pXnGnb->gNBId = buf.gNBId;
            pXnGnb->status = buf.status;
            pXnGnb->serviceState = buf.serviceState;
            pXnGnb->taiSupportCnt = buf.taiSupportCnt;
            pXnNbr->xnapLinkState = (unsigned)FnVCCB_CommonEnumOperType(buf.serviceState) & e_BitMask_1bit;
            pXnGnb->samsungVendorInd = (unsigned)(buf.samsungVendorInd & e_BitMask_1bit);

            if (pXnGnb->status == EQUIP)
            {
                for (idx = 0; idx < MAX_XN_TAI_SUPPORT_COUNT; idx++)
                {
                    pXnGnb->tac[idx] = buf.tac[idx];
                    pXnGnb->plmn[idx] = buf.plmn[idx];
                    pXnGnb->sNssai[idx] = buf.sNssai[idx];
                }
            }
            VCCB_PRINTF("[%s] Success (gnbIdx:%d gnbNum:%d gnbId:%d endPointIdx:%d status:%d, serviceState:%d)\n",
                __func__, gnbIdx, gnbNum, buf.gNBId, endPointIdx, buf.status, buf.serviceState);
            return GOOD;
        }
        default:
        {
            VCCB_PRINTF("[%s] Not handle type %d (gnbIdx:%d,endPointIdx:%d)\n", __func__, pNotifyPld->updateType, gnbIdx, endPointIdx);
            return GOOD;
        }
    }
}

int16_t VCCB_getTuple_PLDGnbXnTaiInfo(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;

    int result;
    PLDGnbXnTaiInfo buf = {};
    uint16_t gnbNum = MAX_GNB_PER_SYS;
    uint16_t idx = 0;
    uint16_t gnbIdx = (uint16_t)pNotifyPld->tpKey[0];
#ifdef __NVGNB__
#else
    uint32_t tmpGnbId = UNKNOWN_GNB_ID;
#endif


    switch (pNotifyPld->updateType)
    {
        case UPDATE_TYPE_DELETE_TPL:
        {
            /* get gnbNum */
#ifdef __NVGNB__
            gnbNum = gnbIdx;
#else
            if (TRUE == FOO.VF_MultipleOperatorRanSupport)
            {
                gnbNum = gnbIdx;
            }
            else
            {
                for (idx = 0; idx < MAX_GNB_PER_SYS; idx++)
                {
                    VccbGnbInfo_type *const pGnb = &GNBINFO[idx];
                    if (pGnb->gnbXnTaiInfo.gNBIdx == gnbIdx)
                    {
                        tmpGnbId = pGnb->gnbXnTaiInfo.gNBId;
                    }
                }
                if (tmpGnbId == UNKNOWN_GNB_ID)
                {
                    VCCB_PRINTF("[%s] Delete Fail (gnbIdx:%d)\n", __func__, gnbIdx);
                    return ERROR;
                }
                VCCB_GET_GNB_NUM_FROM_ID_RETURN(tmpGnbId, gnbNum);
            }
#endif
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
            memset(&pGnb->gnbXnTaiInfo, 0, sizeof(xnTaiInfo_type));
            VCCB_PRINTF("[%s] Delete Success (gnbIdx:%d gnbNum:%d)\n", __func__, gnbIdx, gnbNum);
            return GOOD;
        }
        case UPDATE_TYPE_CREATE_TPL:
        case UPDATE_TYPE_CHANGE_TPL:
        {
            result = FnVCCB_GetTuple(REL_GNB_XN_TAI_INFO_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
            if (result < 0)
            {
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d) (%d)\n", __func__, result, gnbIdx);
                return (int16_t)result;
            }
            /* get gnbNum */
#ifdef __NVGNB__
            gnbNum = gnbIdx;
#else
            if (TRUE == FOO.VF_MultipleOperatorRanSupport)
            {
                gnbNum = gnbIdx;
            }
            else
            {
                // In case buf.status = N_EQUIP, pld parameters except key value(gNBIdx, endPointIdx) are 0.
                if (buf.status != EQUIP)
                {
                    for (idx = 0; idx < MAX_GNB_PER_SYS; idx++)
                    {
                        VccbGnbInfo_type *const pGnb = &GNBINFO[idx];
                        if (gnbIdx == (int)pGnb->gnbXnTaiInfo.gNBIdx && EQUIP == pGnb->gnbXnTaiInfo.status)
                        {
                            gnbNum = idx;
                            break;
                        }
                    }
                }
                else
                {
                    VCCB_GET_GNB_NUM_FROM_ID_RETURN(buf.gNBId, gnbNum);
                }
            }
#endif
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
            pGnb->gnbXnTaiInfo.gNBIdx = buf.gnbIdx;
            pGnb->gnbXnTaiInfo.gNBId = buf.gNBId;
            pGnb->gnbXnTaiInfo.status = buf.status;
            pGnb->gnbXnTaiInfo.serviceState = OpState_enabled;  // Always Enabled
            pGnb->gnbXnTaiInfo.taiSupportCnt = buf.taiSupportCnt;

            if (pGnb->gnbXnTaiInfo.status == EQUIP)
            {
                for (idx = 0; idx < MAX_XN_TAI_SUPPORT_COUNT; idx++)
                {
                    pGnb->gnbXnTaiInfo.tac[idx] = buf.tac[idx];
                    pGnb->gnbXnTaiInfo.plmn[idx] = buf.plmn[idx];
                    pGnb->gnbXnTaiInfo.sNssai[idx] = buf.sNssai[idx];
                }
            }
            VCCB_PRINTF("[%s] Success (gnbIdx:%d gnbNum:%d gnbId:%u status:%d)\n", __func__, gnbIdx, gnbNum, buf.gNBId,
                buf.status);
            return GOOD;
        }
        default:
        {
            VCCB_PRINTF("[%s] Not handle type %d (gnbIdx:%d)\n", __func__, pNotifyPld->updateType, gnbIdx);
            return GOOD;
        }
    }
}

int16_t VCCB_getTuple_PLDCbrsCellCarrierInfo(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;

    VCCB_CHECK_PLD_UPDATE_TYPE_AND_PRINT_WARNING(pNotifyPld->updateType, UPDATE_TYPE_CHANGE_TPL);
    STANDBY_RETURN_OK;

    PLDCbrsCellCarrierInfo buf = {};
    uint16_t cellIdx = (uint16_t)pNotifyPld->tpKey[0];

    int result = FnVCCB_GetTuple(REL_CBRS_CELL_CARRIER_INFO_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
    if (result < 0)
    {
        VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d) (%d)\n", __func__, result, cellIdx);
        return (int16_t)result;
    }

    FnVCCB_ReadOneCbrsCellCarrierInfo(&buf);

    return GOOD;
}

int16_t VCCB_getTuple_PLDNrCellPlmnInfo(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;

    VCCB_CHECK_PLD_UPDATE_TYPE_AND_PRINT_WARNING(pNotifyPld->updateType, UPDATE_TYPE_CHANGE_TPL);
    STANDBY_RETURN_OK;

    int result;
    uint16_t gnbNum = 0;
    uint16_t cellNum = MAX_CELL_NUM_VCCB;
    PLDNrCellPlmnInfo *ptrBuf, buf = {};
    int cellIdx = pNotifyPld->tpKey[0];

    result = FnVCCB_GetTuple(REL_NR_CELL_PLMN_INFO_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
    if (result < 0)
    {
        VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d) (%d)\n", __func__, result, cellIdx);
        return (int16_t)result;
    }

    ptrBuf = &buf;

    gnbNum = FnVCCB_GetGnbNumFromIdOrIdx(ptrBuf->gNBId, ptrBuf->gnbNum);
    if (gnbNum >= MAX_GNB_PER_SYS)
    {
        // If buf.status == EQUIP and gnbNum is out of range, something went wrong!
        VCCB_PRINTF("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,pldGnbNum:%d)\n", __func__, ptrBuf->gNBId, ptrBuf->gnbNum);
        VCCB_PRINT_ERROR("[%s] FnVCCB_GetGnbNumFromIdOrIdx ERROR! (gnbId:%d,pldGnbNum:%d)\n", __func__, ptrBuf->gNBId, ptrBuf->gnbNum);
        return ERROR;
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(ptrBuf->cellId, MAX_CELL_IDENTITY);
    cellNum = FnVCCB_GetCellNum(gnbNum, ptrBuf->cellId);
    if (cellNum >= MAX_CELL_NUM_VCCB)
    {
        VCCB_PRINTF("FnVCCB_GetCellNum ERROR!! for cellNum(%d) / cellId(%d) !!\n", cellNum, ptrBuf->cellId);
        VCCB_PRINTF("  - If PLDCellStatus is already deleted, This is normal !!\n" );
        return GOOD;
    }

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    if (ptrBuf->status != EQUIP)
    {
        FnVCCB_InitPldNrCellPlmnInfo(pCell);
    }
    else
    {
        FnVLIB_UpdatePldNrCellPlmnInfo(pCell, ptrBuf);
    }

    // VCCB_PRINTF("[%s] Success (gnbNum:%d, cellNum:%d)\n", __func__, gnbNum, cellNum);

    FnVCCB_BackupCellInfo(cellNum);

    return GOOD;
}


int16_t VCCB_getTuple_PLDAupfPlmnInfo(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;

    int result;
    PLDAupfPlmnInfo buf = {};
    AupfStatusInfo_type *pGnbAupf = NULL;
    uint16_t gnbNum = MAX_GNB_PER_SYS;

    uint16_t gnbIdx = (uint16_t)pNotifyPld->tpKey[0];
    int endPointIdx = pNotifyPld->tpKey[1];

    VCCB_CHECK_E_RANGE_AND_RETURN(endPointIdx, MAX_GNB_CU_UP_PER_GNB_CU_CP);

    switch (pNotifyPld->updateType)
    {
        case UPDATE_TYPE_DELETE_TPL:
            // get gnbNum
#ifdef __NVGNB__
            gnbNum = gnbIdx;
#else
            if (TRUE == FOO.VF_MultipleOperatorRanSupport)
            {
                gnbNum = gnbIdx;
            }
            else
            {
                uint16_t idx;
                for (idx = 0; idx < MAX_GNB_PER_SYS; idx++)
                {
                    pGnbAupf = &GNBINFO[idx].aupf.gnbCuUp[endPointIdx];

                    if (pGnbAupf->status != EQUIP) continue;

                    if (pGnbAupf->gNBIdx == gnbIdx)
                    {
                        gnbNum = idx;
                        break;
                    }
                }
            }
#endif
            if (gnbNum >= MAX_GNB_PER_SYS)
            {
                VCCB_PRINTF("[%s] Delete Fail (gnbIdx:%d endPointIdx:%d)\n", __func__, gnbIdx, endPointIdx);
                VCCB_PRINTF("  - If PLDAupfStatus is already deleted, This is normal !!\n" );
                return GOOD;  // Prevent Error Message 
            }

            FnVCCB_InitAupfStautsInfo_PLDAupfPlmnInfo(&GNBINFO[gnbNum].aupf.gnbCuUp[endPointIdx]);
            
            // VCCB_PRINTF("[%s] Success (gnbNum:%d,endPointIdx:%d)\n", __func__, gnbNum, endPointIdx);
            return GOOD;

        case UPDATE_TYPE_CREATE_TPL:
        case UPDATE_TYPE_CHANGE_TPL:
            result = FnVCCB_GetTuple(REL_AUPF_PLMN_INFO_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
            if (result < 0)
            {
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d) (%d:%d)\n", __func__, result, gnbIdx, endPointIdx);
                return (int16_t)result;
            }

            /* get gnbNum */
#ifdef __NVGNB__
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbIdx, MAX_GNB_PER_SYS);
            gnbNum = gnbIdx;
#else
            if (TRUE == FOO.VF_MultipleOperatorRanSupport)
            {
                VCCB_CHECK_E_RANGE_AND_RETURN(gnbIdx, MAX_GNB_PER_SYS);
                gnbNum = gnbIdx;
            }
            else
            {
                // In case buf.status = N_EQUIP, pld parameters except key value(gNBIdx, endPointIdx) are 0.
                if (buf.status == EQUIP)
                {
                    VCCB_GET_GNB_NUM_FROM_ID_RETURN(buf.gNBId, gnbNum);   
                }
                else
                {
                    uint16_t idx;
                    for (idx = 0; idx < MAX_GNB_PER_SYS; idx++)
                    {
                        VccbGnbInfo_type *const pGnb = &GNBINFO[idx];
                        if (gnbIdx == (int)pGnb->aupf.gnbCuUp[endPointIdx].gNBIdx &&
                            EQUIP == pGnb->aupf.gnbCuUp[endPointIdx].status)
                        {
                            gnbNum = idx;
                            break;
                        }
                    }
                }
            }
#endif
            if (gnbNum >= MAX_GNB_PER_SYS)
            {
                return GOOD;
            }
            pGnbAupf = &GNBINFO[gnbNum].aupf.gnbCuUp[endPointIdx];

            if (buf.status != EQUIP)
            {
                FnVCCB_InitAupfStautsInfo_PLDAupfPlmnInfo(&GNBINFO[gnbNum].aupf.gnbCuUp[endPointIdx]);                
            }
            else
            {
                FnVCCB_SetAupfStautsInfo_PLDAupfPlmnInfo(pGnbAupf, &buf);   
            }

            // VCCB_PRINTF("[%s] Success (gnbIdx:%d,endPointIdx:%d,gnbId:%u,gnbNum:%d)\n", __func__, gnbIdx, endPointIdx, buf.gNBId, gnbNum);
            return GOOD;

        default:
            VCCB_PRINTF("[%s] Not handle type %d (gnbIdx:%d,endPointIdx:%d)\n", __func__, pNotifyPld->updateType, gnbIdx, endPointIdx);
            return GOOD;
    }    
}


int16_t VCCB_getTuple_PLDAmfPlmnInfo(message_type *pRxMsg)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = (msgDBInformPldNotiDbiAll_type *)pRxMsg;

    int result;
    PLDAmfPlmnInfo buf = {};

    uint16_t gnbIdx = (uint16_t)pNotifyPld->tpKey[0];
    int endPointIdx = pNotifyPld->tpKey[1];

    VccbCfgInfo_type *const pCfg = CFG;
    uint16_t gnbNum = MAX_GNB_PER_SYS;

    VCCB_CHECK_E_RANGE_AND_RETURN(endPointIdx, MAX_AMF_PER_GNB_CU_CP);

    switch (pNotifyPld->updateType)
    {
        case UPDATE_TYPE_DELETE_TPL:
            // get gnbNum
#ifdef __NVGNB__
            gnbNum = gnbIdx;
#else
            if (TRUE == FOO.VF_MultipleOperatorRanSupport)
            {
                gnbNum = gnbIdx;
            }
            else
            {
                uint16_t idx;
                for (idx = 0; idx < MAX_GNB_PER_SYS; idx++)
                {
                    PLDAmfPlmnInfo *const pAmfPlmnInfo = &pCfg->amf.pldAmfPlmnInfo[idx][endPointIdx];

                    if (pAmfPlmnInfo->status != EQUIP) continue;

                    if (pAmfPlmnInfo->gNBIdx == gnbIdx)
                    {
                        gnbNum = idx;
                        break;
                    }
                }
            }
#endif
            if (gnbNum >= MAX_GNB_PER_SYS)
            {
                VCCB_PRINTF("[%s] Delete Fail (gnbIdx:%d endPointIdx:%d)\n", __func__, gnbIdx, endPointIdx);
                VCCB_PRINTF("  - If PLDAmfStatus is already deleted, This is normal !!\n" );
                return GOOD;  // Prevent Error Message 
            }

            memset(&pCfg->amf.pldAmfPlmnInfo[gnbNum][endPointIdx], 0, sizeof(PLDAmfPlmnInfo));
            VCCB_PRINTF("[%s] Success (gnbNum:%d, endPointIdx:%d)\n", __func__, gnbNum, endPointIdx);
            return GOOD;


        case UPDATE_TYPE_CREATE_TPL:
        case UPDATE_TYPE_CHANGE_TPL:
            result = FnVCCB_GetTuple(REL_AMF_PLMN_INFO_ID, pNotifyPld->tpKey, (char *)&buf, sizeof(buf), pRxMsg);
            if (result < 0)
            {
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d) (%d:%d)\n", __func__, result, gnbIdx, endPointIdx);
                return (int16_t)result;
            }

#ifdef __NVGNB__
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbIdx, MAX_GNB_PER_SYS);
            gnbNum = gnbIdx;
#else
            if (TRUE == FOO.VF_MultipleOperatorRanSupport)
            {
                VCCB_CHECK_E_RANGE_AND_RETURN(gnbIdx, MAX_GNB_PER_SYS);
                gnbNum = gnbIdx;
            }
            else
            {
                if (buf.status == EQUIP)
                {
                    VCCB_GET_GNB_NUM_FROM_ID_RETURN(buf.gNBId, gnbNum);
                }
                else
                {
                    uint16_t idx;
                    for (idx = 0; idx < MAX_GNB_PER_SYS; idx++)
                    {
                        if (gnbIdx == (int)pCfg->amf.pldAmfPlmnInfo[idx][endPointIdx].gNBIdx &&
                            EQUIP == pCfg->amf.pldAmfPlmnInfo[idx][endPointIdx].status)
                        {
                            gnbNum = idx;
                            break;
                        }
                    }
                }
            }
#endif
            if (gnbNum >= MAX_GNB_PER_SYS)
            {
                return ERROR;
            }

            memcpy(&pCfg->amf.pldAmfPlmnInfo[gnbNum][endPointIdx], &buf, sizeof(PLDAmfPlmnInfo));

            VCCB_PRINTF("[%s] Success (gnbNum:%d, endPointIdx:%d, gnbId:%u)\n", __func__, gnbNum, endPointIdx, buf.gNBId);
            return GOOD;

        default:
            VCCB_PRINTF("[%s] Not handle type %d (gnbIdx:%d, endPointIdx:%d)\n", __func__, pNotifyPld->updateType, gnbIdx, endPointIdx);
            return GOOD;
    }
}

int16_t VCCB_getTuple_PLDSonOpState(message_type *pRxMsg)
{

    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pRxMsg);
    msgDBInformPldNotiDbiAll_type *pNotifyPld = reinterpret_cast<msgDBInformPldNotiDbiAll_type *>(pRxMsg);

    STANDBY_RETURN_OK;

    PLDSonOpStatus buf = {};
    uint16_t dbIndex = static_cast<uint16_t>(pNotifyPld->tpKey[0]);

    switch (pNotifyPld->updateType)
    {
        // Hard-delete case, tuple deleted from valkey
        // For soft-delete case (VCSB sets the tuple status to N_EQUIP) see ReadOneSonOpState
        case UPDATE_TYPE_DELETE_TPL:
        {
            auto &indexManager = PldSonOpStatusIndexManager::instance();
            CellNum_type targetCellNum = indexManager.getCellNumOfDbIndex(dbIndex);
            if (MAX_CELL_NUM_VCCB <= targetCellNum)
            {
                VCCB_PRINT_ERROR("[SonOpStatus] Received hard-delete for non-existing dbIndex(%u)\n!", dbIndex);
                return ERROR;
            }

            // Feature-related cleanup
            CELLINFO[targetCellNum].nrLbmConfigurationIndex = NR_LBM_DISABLE;
            CELLINFO[targetCellNum].tsmConfig.state         = tsmState_Disable;

            indexManager.deleteDbIndex(dbIndex);
            break;
        }
        case UPDATE_TYPE_CREATE_TPL:
        case UPDATE_TYPE_CHANGE_TPL:
        {
            int result = FnVCCB_GetTuple(REL_SON_OP_STATUS_ID, pNotifyPld->tpKey, reinterpret_cast<char *>(&buf), sizeof(buf), pRxMsg);
            if (0 > result)
            {
                VCCB_PRINT_ERROR("[%s] FnVCCB_GetTuple Fail!(%d) (%d)\n", __func__, result, dbIndex);
                return static_cast<int16_t>(result);
            }

            FnVCCB_ReadOneSonOpState(&buf);
            break;
        }
        default:
            VCCB_PRINTF("[%s] Not handle type %d (cellIdx:%d)\n", __func__, pNotifyPld->updateType, dbIndex);
            break;
    }

    return GOOD;
}
