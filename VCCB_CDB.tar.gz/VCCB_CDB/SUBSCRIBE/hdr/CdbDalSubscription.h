#ifndef VCCB_CDB_CdbDalSubscription_H_
#define VCCB_CDB_CdbDalSubscription_H_

#include "ComInclude.min.h"
#include "CdbUtil.h"

/* Func declaration section --> */
enum dal_db_iter_ret VDAL_VnbCall_CallSuccessRatioLowAlarm_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_GnbInfo_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_DuGnbInfo_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_PlmnInfo_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_CuPlmnInfo_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_QciSupport_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
enum dal_db_iter_ret VDAL_VnbCall_PerPlmnQciSupport_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
enum dal_db_iter_ret VDAL_VnbCall_Qos5qiSupport_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
enum dal_db_iter_ret VDAL_VnbCall_PerPlmnQos5qiSupport_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
enum dal_db_iter_ret VDAL_VnbCall_GutranCuCellEntries_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_CellNeighborRelations_callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_CellEutraNeighborRelations_callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_QosData_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_PdcpProfile_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_CslData_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_ScgFailureHandling_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_SpidInfo_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_DynamicUlPrimaryPathSelection_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_SpidBasedUlPathSwitchingProfile_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_DataForwarding_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_GnbcpManagement_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_EndPointX2Entries_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
#ifndef __NVGNB__
enum dal_db_iter_ret VDAL_VnbCall_EndPointF1Entries_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
#endif
enum dal_db_iter_ret VDAL_VnbCall_NrdcControl_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
enum dal_db_iter_ret VDAL_VnbCall_NrdcAmbrConfiguration_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
enum dal_db_iter_ret VDAL_VnbCall_NrdcSliceMbrConfiguration_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
enum dal_db_iter_ret VDAL_VnbCall_EndPointXnEntriesAmfSetInformationEntries_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_EndPointXnEntries_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_GnbCuPlmnInfo_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_NeighborGnbEntries_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_NeighborGnbCellEntries_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_NeighborEnbEntries_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_NeighborEnbCellEntries_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_SecurityData_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_InactivityData_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_UserInactivityProfile_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_MeasurementGap_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_PeriodicA4Measurement_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_LongPeriodicMeasurement_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_MobilityConfigGnb_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_CarrierAggregationInfo_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_MultiCarrierOperation_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_MultiCarrierOperationConfig_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_QosDrbMapping_DedicatedGroup_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_QosDrbMapping_MappingRule_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_DrxConfig_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_DssConfiguration_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_TraceConfiguration_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_CuUpSelectionConfiguration_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_TraceConfiguration_CellNumEntry_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_TraceConfiguration_CellNumEntry_Validation(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_TimerInfo_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_RrcSaTimerProfile_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_RrcEndcTimerProfile_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_InactivityDataSA_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_InactivityDataSA_Redcap_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_InactivityDataNrdcSN_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_AnrInfoGnb_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_InterRatAnrInfoGnb_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_MroInfoGnb_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
enum dal_db_iter_ret VDAL_VnbCall_HoBlacklistXnEntries_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_EndPointNgEntries_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);

enum dal_db_iter_ret VDAL_VnbCall_DualConnectivityControl_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_NedcAmbrConfiguration_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_CapabilityRequestFilter_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_QosDrbMapping_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_QosDrbMapping_DedicatedGroup_SliceInfo_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_QosDrbMapping_MappingRule_SliceInfo_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_RrcInactiveInfo_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_EmergencyArpInfo_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
enum dal_db_iter_ret VDAL_VnbCall_LocalTimeInfo_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_VnfcInfo_Callback(dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *,
    void *);  // ODF_HO_21B
enum dal_db_iter_ret VDAL_GnbCu_UEPowersavingControlInfo_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_UEOverheatingControlInfo_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_GnbCu_UserInactivityFreqControl_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
enum dal_db_iter_ret VDAL_VnbCall_FastRlfRecovery_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
enum dal_db_iter_ret VDAL_VnbCall_RealTimeSgnbAdditionTimer_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
enum dal_db_iter_ret VDAL_VnbCall_OverloadControlFunc_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
enum dal_db_iter_ret VDAL_GnbCu_VomaConfiguration_Callback(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);
enum dal_db_iter_ret VDAL_VnbCall_CallDropRatioHighAlarm_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
enum dal_db_iter_ret VDAL_VnbCall_RacsInfo_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

int VDAL_VnbCall_WriteCreateTime(uint16_t caCellNum, uint16_t cellNum, uint16_t nbrIdx);
int VDAL_VnbCall_Validate_Keypath(dal_hkeypath_t *modKeypath, const int pathIter);

int VDAL_VnbCall_InitCellUsageState(void);
int VDAL_SubscribeData(int subscribeSock);
void *VDAL_SubscriptionMsgProc(void *);
int FnVCCB_GetIterForCpCuFunc(int *pIterForCuCpFunc);
void VDAL_InitConfdNbrReadInfo();

void VDAL_TriggerPostUpdateActions(void);
void VDAL_VnbCall_ClearCellMeasurementsData(measurementsData_type *pMeasData);
void VDAL_VnbCall_ClearCellRFDSPData(cellRfspBasedCtrl_type *pCellRfspBasedCtrl);
void VDAL_VnbCall_InitRFSPBasedCtrlData(rfspBasedCtrl_type *pRfspBasedCtrl);
void VDAL_VnbCall_ClearColocCellEntries(uint16_t spCellNum);
void VDAL_VnbCall_ClearTsmConfig(uint16_t cellNum);
void VDAL_VnbCall_DestroyTraceSession(VccbCellInfo_type *pCell);
void VDAL_VnbCall_SliceSupportInfoEntries_GetSub(dal_hkeypath_t *modKeypath, int pathIter, dal_value_t *newv,
    enum dal_db_iter_op op, SliceSupportedInfo_type *pSliceInfoList);
void VDAL_VnbCall_PlmnSupportInfoEntries_GetSub(dal_hkeypath_t *modKeypath, int pathIter, dal_value_t *newv,
    enum dal_db_iter_op op, PlmnSupportedInfo_type *pPlmnInfoList);
void VDAL_VnbCall_SliceIdEntries_GetSub(dal_hkeypath_t *modKeypath, int pathIter, dal_value_t *newv,
    enum dal_db_iter_op op, VccbGnbInfo_type *const pGnb);
void VDAL_VnbCall_MultiRatSelection_GetSub(dal_hkeypath_t *modKeypath, int pathIter, dal_value_t *newv,
    VccbGnbInfo_type *const pGnb);


typedef enum dal_db_iter_ret (*subscriptionCallback_func)(
    dal_hkeypath_t *, enum dal_db_iter_op, dal_value_t *, dal_value_t *, void *);

typedef struct
{
    dalFuncId_type FunctionId;
    enum dal_db_sub_type Type;
    int Flags;
    int SubPoint;
    const char *KeyPath;
    const char *FunctionName;
    subscriptionCallback_func SubFunction;
    subscriptionCallback_func Validation;
} VccbDalSubInfo_type;

#define VCCB_TUPLE_KEY(__name) e_##__FUNCTION__##__name
void VLIB_MeasurementObjectInit(measurementObjectNRBaseDb_type *pMeasObj);
void VLIB_UpdateCellsUmfsMaxCallCnt(VccbCellInfo_type *pCell);
void VLIB_UpdateCellsUmfsEutraMaxCallCnt(VccbCellInfo_type *pCell);
void VLIB_IntraFreqSmtc1ConfigurableInit(VccbCellInfo_type *pCell);

void FnVCCB_CloseDalConnection(int *pReadSocket, const char *ptCalledFunc);

enum dal_db_iter_ret VDAL_VnbCall_UlRrcSegmentationSupport_Gnb_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
int VDAL_VnbCall_UlRrcSegmentationSupport_getGnbNbr(dal_hkeypath_t *modKeypath, dal_value_t *pKey[], uint32_t *gnbId,
    uint16_t *ptGnb, int *nbrIdx, enum dal_db_iter_ret *dalStatus);
enum dal_db_iter_ret VDAL_VnbCall_UlRrcSegmentationSupport_Enb_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
int VDAL_VnbCall_UlRrcSegmentationSupport_getEnbNbr(dal_hkeypath_t *modKeypath, dal_value_t *pKey[], uint32_t *gnbId,
    uint16_t *ptGnb, int *nbrIdx, enum dal_db_iter_ret *dalStatus);

enum dal_db_iter_ret VDAL_VnbCall_ReleasePreference_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_VnbCall_NrdcScgFailureHandling_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
enum dal_db_iter_ret VDAL_VnbCall_IratMroInfoGnb_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
enum dal_db_iter_ret VDAL_VnbCall_IdleMobilityControl_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
enum dal_db_iter_ret VDAL_VnbCall_CaProfileEntries_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
enum dal_db_iter_ret VDAL_VnbCall_PeriodicLbInfo_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
void VDAL_VnbCall_ResourceThresholdExceededAlarm_GetSub(dal_hkeypath_t *modKeypath, int pathIter, dal_value_t *newv,
    enum dal_db_iter_op op, VccbAlarmAttribute_type *pAttribute);
enum dal_db_iter_ret VDAL_VnbCall_ResourceThresholdExceededAlarm_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_GnbCu_SpidBasedStatisticSupport_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_GnbCu_QciAndSpidBasedStatisticSupport_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_GnbCu_RfspBasedCounterControl_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

void VDAL_VnbCall_CellCapabilityRequestFilter_GetSub(
    dal_hkeypath_t *modKeypath, int pathIter, dal_value_t *newv, enum dal_db_iter_op op, VccbCellInfo_type *pCell);    

enum dal_db_iter_ret VDAL_GnbCu_OperatorSpecificFreq_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

void VDAL_TriggerReadNbrByAudit(uint32_t *pMax_nbrGnbNum);  // NBR_AUDIT_22B
void VDAL_InitConfdNbrReadAuditInfo(void);                  // NBR_AUDIT_22B

enum dal_db_iter_ret VDAL_VnbCall_RedCapPdcpInfo_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_VnbCall_SliceAwareLoadBalancing_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state); //SVR23B FGR-LC0710

enum dal_db_iter_ret VDAL_VnbCall_SliceLoadControlInfoEntries_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_VnbCall_SliceAwardLbConfiguration_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_VnbCall_OverloadProtectInfo_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_VnbCall_RestrictedSsbFrequencies_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_VnbCall_NcdSsbConfig_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_VnbCall_ServiceTypeSa_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state); 

enum dal_db_iter_ret VDAL_VnbCall_TceIpFromFqdn_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_VnbCall_ServicetypeCounterConfig_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_DeviceIdentRequestFilter_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_VnbCall_ManagementTraffic_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_VnbCall_EfficientPaging_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_VnbCall_PlmnRfspBasedVonrControl_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_VnbCall_MpsCallInfo_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_VnbCall_GracefulReleaseConf_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_VnbCall_CslOperData_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_VnbCall_NrSammGnbConfig_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

// SVR26A FGR-CC5000 FR3622
enum dal_db_iter_ret VDAL_VnbCall_UlInterferenceCellSelectionThresholds_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

#ifdef VCCB_IPC_TEST
void VDAL_ProcNbrRead_OnWaitTime(uint32_t *pSecCnt, uint32_t *pMax_nbrGnbNum, nbrReadCountInto_type *pTotalCnt,
    uint16_t *pStartGnbNum, uint16_t *pInitialNbrReadFlag);
#endif

// SVR25B FGR-CC6101 Multiple PLMN Support
enum dal_db_iter_ret VDAL_VnbCall_ServiceAvailableInfo_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

#ifdef __CNF__
enum dal_db_iter_ret VDAL_VnbCall_PodEntries_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
#endif

enum dal_db_iter_ret VDAL_GnbCu_PlmnSliceCounterConfig_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_VnbCall_PdcpDuplicationConfig_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);

enum dal_db_iter_ret VDAL_VnbCall_ImeisvFeatureControlInformation_Callback(
    dal_hkeypath_t *modKeypath, enum dal_db_iter_op op, dal_value_t *oldv, dal_value_t *newv, void *state);
#endif  // VCCB_CDB_CdbDalSubscription_H_
