#ifndef VCCB_CDB_CdbPldSubscription_H_
#define VCCB_CDB_CdbPldSubscription_H_

#include "ComInclude.min.h"

// Func declaration section //
int VCCB_RegisterPLD(void);
int VCCB_RegisterSinglePLD(pldInfo_type * pPldInfo, const DbiWithDataOption option);
int16_t VCCB_UpdatePldMsg(message_type *pRxMsg);

int16_t VCCB_getTuple_PLDDuStatus(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDAupfStatus(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDAmfStatus(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDAmfTnlStatus(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDAmfTnlSctpState(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDCellStatus(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDGnbBarringInfo(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDGnbCallState(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDCpuUtilExt(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDCellTraceStatus(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDTraceStatus(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDImsiTrace(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDCpcUsageState(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDEutraCellInfo(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDXnGnbStatus(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDGnbXnTaiInfo(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDCbrsCellCarrierInfo(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDNrCellPlmnInfo(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDAupfPlmnInfo(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDAmfPlmnInfo(message_type *pRxMsg);
int16_t VCCB_getTuple_PLDSonOpState(message_type *pRxMsg);

#endif  // VCCB_CDB_CdbPldSubscription_H_
