#include "StatisticsHandler.h"

/****************************************************************************
 * @brief           Handle statistics family and index
 * @param[in]       ptCi : pointer to Call information / callInfo_type
 * @param[in]       rFamily : original statistics family / int&
 * @param[in]       rPmKey : reference to pmKey / VccbPmKey_type&
 * @return          void
 ****************************************************************************/
void StatisticsHandler::changeFamilyAndIndex(
    callInfo_type* ptCi, int& rFamily, VccbPmKey_type& rPmKey)
{
    AUTO_TRACE_FUNC;

    if (TRUE == checkFamilyForRedCap(ptCi, rFamily))
        changeFamilyAndIndexForRedCap(ptCi, rFamily, rPmKey);
    else
        changeFamilyAndIndexForFOO(ptCi, rFamily, rPmKey);

    return;
}

/****************************************************************************
 * @brief           Handle statistics family and index for specific FOO.
 * @param[in]       ptCi : pointer to Call information / callInfo_type
 * @param[in]       rFamily : original statistics family / int&
 * @param[in]       rPmKey : reference to pmKey / VccbPmKey_type&
 * @return          void
 ****************************************************************************/
void StatisticsHandler::changeFamilyAndIndexForFOO(
    callInfo_type* ptCi, int& rFamily, VccbPmKey_type& rPmKey)
{
    AUTO_TRACE_FUNC;

    int prevFamily = rFamily;
    int postFamily = prevFamily;

    changeFamilyForFOO(prevFamily, postFamily);

    if(prevFamily == postFamily)
    {
        // no change
        return;
    }

    if(ERROR == fillStatisticsIndex(ptCi, rPmKey, prevFamily, postFamily))
    {
        // TODO : Some of index value are pre-filled by hardcoding before changing the location of the statistics index.
        // return;
    }

    rFamily = postFamily;

    return;
}

/****************************************************************************
 * @brief           change statistics Family for specific FOO
 * @param[in]       prevFamily : original statistics family / int
 * @param[in]       rPostFamily : changed statistics family / int
 * @return          void
 ****************************************************************************/
void StatisticsHandler::changeFamilyForFOO(int prevFamily, int& rPostFamily)
{
    AUTO_TRACE_FUNC;

    VccbDynamicFlagInfo_type &rFoo = FOO;

    if (rFoo.VF_MobilityforENDC_InterSnPScellChgPerGnbDuNciCounterFamily)
    {
        if (changeFamily_MobilityforENDC_InterSnPScellChgPerGnbDuNciCounterFamily(prevFamily, rPostFamily))
        {
            return;
        }
    }

    if (rFoo.VF_BasicOperationforENDC_LGUOnlyCounterFamily)
    {
        if (changeFamily_BasicOperationforENDC_LGUOnlyCounterFamily(prevFamily, rPostFamily))
        {
            return;
        }
    }

    if (rFoo.VF_MobilityforENDC_PerDuCounterFamily)
    {
        if (changeFamily_MobilityforENDC_PerDuCounterFamily(prevFamily, rPostFamily))
        {
            return;
        }
    }

    if (rFoo.VF_BearerContextManagementviaE1_UpIdCounterFamily)
    {
        if (changeFamily_BearerContextManagementviaE1_UpIdCounterFamily(prevFamily, rPostFamily))
        {
            return;
        }
    }

    // Do not change the order of changeFamily_CNF() and changeFamily_MultipleOperatorRanSupport()
    //& don't return from this as the new family name is referred in below function incase of
    // CNF + MORAN case
    if (isCollectStatForCP())
    {
        changeFamily_CNF(prevFamily, rPostFamily);
        prevFamily = rPostFamily;
    }

    if (isCollectStatForDUID())
    {
        if (changeFamily_BasicOperation_IndexgNBDUId(prevFamily, rPostFamily))
        {
            return;
        }
    }

    if (isCollectStatForGLOBALID())
    {
        if (changeFamily_MultipleOperatorRanSupport(prevFamily, rPostFamily))
        {
            return;
        }
    }

    return;
}

/****************************************************************************
 * @brief           Handle statistics family and index for RedCap UE.
 * @param[in]       ptCi : pointer to Call information / callInfo_type
 * @param[in]       rFamily : original statistics family / int&
 * @param[in]       rPmKey : reference to pmKey / VccbPmKey_type&
 * @return          void
 ****************************************************************************/
void StatisticsHandler::changeFamilyAndIndexForRedCap(
    callInfo_type *ptCi, int& rFamily, VccbPmKey_type& rPmKey)
{
    AUTO_TRACE_FUNC;

    int prevFamily = rFamily;
    int postFamily = prevFamily;

    changeFamilyForRedCap(prevFamily, postFamily);

    if (prevFamily == postFamily)
    {
        // no change
        return;
    }

    if (ERROR == fillStatisticsIndex(ptCi, rPmKey, prevFamily, postFamily))
    {
        // TODO : Some of index value are pre-filled by hardcoding before changing the location of the statistics index.
        // return;
    }

    rFamily = postFamily;

    return;
}

/****************************************************************************
 * @brief           change statistics Family for RedCap UE
 * @param[in]       prevFamily : original statistics family / int
 * @param[in]       rPostFamily : changed statistics family / int
 * @return          void
 ****************************************************************************/
void StatisticsHandler::changeFamilyForRedCap(int prevFamily, int& rPostFamily)
{
    switch (prevFamily)
    {
        case STAT_RRC_ESTAB:
            rPostFamily = STAT_RRC_ESTAB_REDCAP;
            break;

        case STAT_RRC_SETUP_TIME:
            if (isCollectStatForCP())
                rPostFamily = STAT_CP_RRC_SETUP_TIME_REDCAP;
            else
                rPostFamily = STAT_RRC_SETUP_TIME_REDCAP;
            break;

        case STAT_RRC_RELEASE:
            rPostFamily = STAT_RRC_RELEASE_REDCAP;
            break;

        case STAT_DRB_SETUP:
            rPostFamily = STAT_DRB_SETUP_REDCAP;
            break;

        case STAT_DRB_SETUP_PLMN_SNSSAI:
            rPostFamily = STAT_DRB_SETUP_REDCAP_PLMN_SNSSAI;
            break;

        case STAT_DRB_RELEASE_AND_ERASE:
            rPostFamily = STAT_DRB_RELEASE_AND_ERASE_REDCAP;
            break;

        case STAT_PDU_SESSION_RESOURCE_SETUP_PLMN_SNSSAI:
            rPostFamily = STAT_PDU_SESSION_RSC_SETUP_REDCAP_PLMN_SNSSAI;
            break;

        case STAT_QOS_FLOW_SETUP:
            rPostFamily = STAT_QOS_FLOW_SETUP_REDCAP;
            break;

        case STAT_QOS_FLOW_SETUP_PLMN_SNSSAI:
            rPostFamily = STAT_QOS_FLOW_SETUP_REDCAP_PLMN_SNSSAI;
            break;

        case STAT_RRC_REESTAB:
            rPostFamily = STAT_RRC_REESTAB_REDCAP;
            break;

        case STAT_RAN_PAGING:
            rPostFamily = STAT_RAN_PAGING_REDCAP;
            break;

        case STAT_RRC_INACTIVE_INFO:
            rPostFamily = STAT_RRC_INACTIVE_INFO_REDCAP;
            break;
            
        case STAT_NG_ESTAB:
            rPostFamily = STAT_NG_ESTAB_REDCAP;
            break;
            
        case STAT_INITIAL_CONTEXT_SETUP:
            rPostFamily = STAT_INITIAL_CONTEXT_SETUP_REDCAP;
            break;

        default: // Do nothing
            break;
    }

    return;
}

/****************************************************************************
 * @brief           check if it is a RedCap UE statistics family
 * @param[in]       ptCi : pointer to Call information / callInfo_type
 * @param[in]       rFamily : original statistics family / int
 * @return          void
 ****************************************************************************/
int StatisticsHandler::checkFamilyForRedCap(callInfo_type *ptCi, int rFamily)
{
    int status = FALSE;

    if (NULL == ptCi || FALSE == IS_REDCAP_UE(ptCi))
        return status;

    switch (rFamily)
    {
        case STAT_RRC_ESTAB:
        case STAT_NG_ESTAB:
        case STAT_INITIAL_CONTEXT_SETUP:
        case STAT_RRC_SETUP_TIME:
        case STAT_RRC_RELEASE:
        case STAT_DRB_SETUP:
        case STAT_DRB_SETUP_PLMN_SNSSAI:
        case STAT_DRB_RELEASE_AND_ERASE:
        case STAT_PDU_SESSION_RESOURCE_SETUP_PLMN_SNSSAI:
        case STAT_QOS_FLOW_SETUP:
        case STAT_QOS_FLOW_SETUP_PLMN_SNSSAI:
        case STAT_RRC_REESTAB:
        case STAT_RAN_PAGING:
        case STAT_RRC_INACTIVE_INFO:
            status = TRUE;
            break;

        default:
            break;
    }

    return status;
}

uint64_t StatisticsHandler::getIndexValue(StatIndexValue prevIndexValue[INDEX_END], int postFamily, int postIndexName,
    callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    // NULL ptCi is valid when getting DUID.

    // Index Value already exists in previous Family.
    if (prevIndexValue[postIndexName].isExist)
    {
        return prevIndexValue[postIndexName].value;
    }

    // Index Value not exists in previous Family.
    // Get Index Value for posterior Family.
    switch (postIndexName)
    {
        case INDEX_TriggeredNCI:
            return getTriggeredNCI(ptCi);
        case INDEX_Tgt_gNB_DU_ID:
            return getTgtGnbDuId(ptCi);
        case INDEX_gNB_DU_ID:
            return getDuId(ptCi);
        case INDEX_PLMN:
            return getPlmn();
        case INDEX_PLMN_UE:
            return getPlmnUe(ptCi);
        case INDEX_CP_ID:
            return CFG->vm.unitId;
        case INDEX_CellIdentity:
            return cellIdentity;
        case INDEX_gNB_CU_UP_ID:
            if (endPointIdxForUpId >= MAX_GNB_CU_UP_PER_GNB_CU_CP) break;
            if (gnbNum >= MAX_GNB_PER_SYS) break;
            return GNBINFO[gnbNum].aupf.gnbCuUp[endPointIdxForUpId].aupfId;
        case INDEX_eNB_ID:
            // the eNB_ID index name is different from that of the family before and after the change.
            switch (postFamily)
            {
                case STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG_DU_ID:
                case STAT_SGNB_ADD_MNHO_INTRA_ENB_DU_ID:
                case STAT_SGNB_ADD_MNHO_INTER_ENB_DU_ID:
                case STAT_MENB_INIT_SGNB_REL_MCGMOB_PER_GNB_DU_ID:
                case STAT_MENB_INIT_SGNB_REL_MCGMOB_UECTX_IND_DU_ID:
                case STAT_MENB_INIT_SGNB_REL_TC_PER_GNB_DU_ID:
                case STAT_SGNB_ADD_SGNB_CHG_DU_ID:
                    if (prevIndexValue[INDEX_MeNB_ID].isExist)
                    {
                        return prevIndexValue[INDEX_MeNB_ID].value;
                    }
                default:
                    break;
            }
            break;
        case INDEX_ServiceType_SA:  // Prevent to print out below "ERROR PRINT". serviceTypeIndex will be configured out of function later.
            break;
        case INDEX_InSessionStatus:
            return 0;       // InSessionStatus (Fixed : 0)
        default:
            VCCB_PRINT_ERROR("cannot fill family(%d) index(%d) at StatisticsHandler!!\n", postFamily, postIndexName);
            break;
    }

    return 0;
}

/****************************************************************************
 * @brief           Handle Index for changed statistics family
 *                  - if index exists in orginal statistics Family, use it.
 *                  - otherwise, get value and fill it.
 * @param[in]       ptCi : pointer to Call information / callInfo_type
 * @param[in]       rPmKey : reference to pmKey / VccbPmKey_type&
 * @param[in]       prevFamily : original statistics family / int
 * @param[in]       postFamily : changed statistics family / int
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t StatisticsHandler::fillStatisticsIndex(callInfo_type *ptCi, VccbPmKey_type &rPmKey, int prevFamily, int postFamily)
{
    AUTO_TRACE_FUNC;

    // NULL ptCi is valid when getting DUID.

    simpleVector<int, MAX_VCCB_STAT_KEY_NUM> prevIndexNameVector = getIndexNameVector(prevFamily);
    simpleVector<int, MAX_VCCB_STAT_KEY_NUM> postIndexNameVector = getIndexNameVector(postFamily);

    if (prevIndexNameVector.empty() || postIndexNameVector.empty())
    {
        return ERROR;
    }

    VccbPmKey_type tempPmKey = rPmKey;
    StatIndexValue prevIndexValue[INDEX_END] = {};
    uint16_t idxNum = 0;

    for (auto prevIndex : prevIndexNameVector)
    {
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(prevIndex, 1, INDEX_END - 1);
        VCCB_CHECK_E_RANGE_AND_RETURN(idxNum, MAX_VCCB_STAT_KEY_NUM);
        prevIndexValue[prevIndex].value = rPmKey.keyList[idxNum++];
        prevIndexValue[prevIndex].isExist = true;
    }

    // If the cellIdentity Index name is used as something other than "cellIdentity" (ex. cellIdentityWithInvalid),
    // it must be defined within function below.
    cellIdentity = getCellIdentity(prevFamily, prevIndexValue);

    idxNum = 0;
    for (auto postIndexName : postIndexNameVector)
    {
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(postIndexName, 1, INDEX_END - 1);
        VCCB_CHECK_E_RANGE_AND_RETURN(idxNum, MAX_VCCB_STAT_KEY_NUM);
        tempPmKey.keyList[idxNum++] = getIndexValue(prevIndexValue, postFamily, postIndexName, ptCi);
    }

    tempPmKey.numKey = idxNum;

    rPmKey = tempPmKey;

    return GOOD;
}


//////////// Family change rule ////////////
bool StatisticsHandler::changeFamily_MobilityforENDC_InterSnPScellChgPerGnbDuNciCounterFamily(int prevFamily, int& rPostFamily)
{
    switch(prevFamily)
    {
        case STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB:
            rPostFamily = STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB_PER_DU_PER_NCI;
            break;
        default:
            return false;
    }

    return true;
}

bool StatisticsHandler::changeFamily_BasicOperationforENDC_LGUOnlyCounterFamily(int prevFamily, int& rPostFamily)
{
    switch (prevFamily)
    {
        case STAT_SGNB_ADD_PER_GNB:
            rPostFamily = STAT_SGNB_ADD_PER_GNB_PER_DU;
            break;
        case STAT_MENB_INIT_SGNB_REL_PER_GNB:
            rPostFamily = STAT_MENB_INIT_SGNB_REL_PER_GNB_PER_DU;
            break;
        case STAT_SGNB_INIT_SGNB_REL_PER_GNB:
            rPostFamily = STAT_SGNB_INIT_SGNB_REL_PER_GNB_PER_DU;
            break;
        default:
            return false;
    }

    return true;
}

bool StatisticsHandler::changeFamily_MobilityforENDC_PerDuCounterFamily(int prevFamily, int& rPostFamily)
{
    switch (prevFamily)
    {
        case STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB:
            rPostFamily = STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB_PER_DU;
            break;
        case STAT_SGNB_INIT_SGNB_REL_MR_PER_GNB:
            rPostFamily = STAT_SGNB_INIT_SGNB_REL_MR_PER_GNB_PER_DU;
            break;
        default:
            return false;
    }

    return true;
}

bool StatisticsHandler::changeFamily_BearerContextManagementviaE1_UpIdCounterFamily(int prevFamily, int& rPostFamily)
{
    switch(prevFamily)
    {
        case STAT_E1AP_CUCP_MSG_UE:
            rPostFamily = STAT_E1AP_CUCP_MSG_UE_PER_UP;
            break;
        default:
            return false;
    }

    return true;
}

void StatisticsHandler::changeFamily_CNF(int prevFamily, int& rPostFamily)
{
    switch (prevFamily)
    {
        case STAT_HO_TIME:
            rPostFamily = STAT_CP_HO_TIME;
            break;
        case STAT_PSCELL_CHANGE_TIME:
            rPostFamily = STAT_CP_PSCELL_CHANGE_TIME;
            break;
        case STAT_UE_NUM_PER_GNB:
            rPostFamily = STAT_CP_UE_NUM_PER_GNB;
            break;
        case STAT_DRB_NUM_PER_GNB:
            rPostFamily = STAT_CP_DRB_NUM_PER_GNB;
            break;
        case STAT_SGNB_PROC_TIME_PER_GNB_DU_ID:
            rPostFamily = STAT_CP_SGNB_PROC_TIME_PER_GNB_DU_ID;
            break;
        case STAT_UE_NUM_PER_GNB_PLMN:
            rPostFamily = STAT_CP_UE_NUM_PER_GNB_PLMN;
            break;
        case STAT_DRB_NUM_PER_GNB_PLMN:
            rPostFamily = STAT_CP_DRB_NUM_PER_GNB_PLMN;
            break;
        case STAT_RRC_SETUP_TIME:
            rPostFamily = STAT_CP_RRC_SETUP_TIME;
            break;
        case STAT_NG_SETUP_TIME:
            rPostFamily = STAT_CP_NG_SETUP_TIME;
            break;
        case STAT_DRB_SETUP_TIME_DU_ID:
            rPostFamily = STAT_CP_DRB_SETUP_TIME_DU_ID;
            break;
        case STAT_RRC_CONN_INFO:
            rPostFamily = STAT_CP_RRC_CONN_INFO;
            break;
        case STAT_RRC_CONN_INFO_PLMN:
            rPostFamily = STAT_CP_RRC_CONN_INFO_PLMN;
            break;
        case STAT_RRC_CONN_INFO_DU_ID_PLMN_RFSP:
            rPostFamily = STAT_CP_RRC_CONN_INFO_DU_ID_PLMN_RFSP;
            break;
        case STAT_RRC_CONN_INFO_PC1_DU_ID:
            rPostFamily = STAT_CP_RRC_CONN_INFO_PC1_DU_ID;
            break;
        case STAT_RRC_CONN_INFO_PC15_DU_ID:
            rPostFamily = STAT_CP_RRC_CONN_INFO_PC15_DU_ID;
            break;
        case STAT_RRC_CONN_INFO_PC2_DU_ID:
            rPostFamily = STAT_CP_RRC_CONN_INFO_PC2_DU_ID;
            break;
        case STAT_DRB_CONN_INFO:
            rPostFamily = STAT_CP_DRB_CONN_INFO;
            break;
        case STAT_DRB_CONN_INFO_PLMN:
            rPostFamily = STAT_CP_DRB_CONN_INFO_PLMN;
            break;
        case STAT_DRB_CONN_INFO_PLMN_SNSSAI:
            rPostFamily = STAT_CP_DRB_CONN_INFO_PLMN_SNSSAI;
            break;
        case STAT_NRDC_SN_CONN_INFO_MN:
            rPostFamily = STAT_CP_NRDC_SN_CONN_INFO_MN;
            break;
        case STAT_NRDC_SN_CONN_INFO_SN:
            rPostFamily = STAT_CP_NRDC_SN_CONN_INFO_SN;
            break;
        case STAT_NRDC_SN_TERM_DRB_CONN_INFO:
            rPostFamily = STAT_CP_NRDC_SN_TERM_DRB_CONN_INFO;
            break;
        case STAT_ERAB_SPEC_INFO_PER_GNB_DU_ID:
            rPostFamily = STAT_CP_ERAB_SPEC_INFO_PER_GNB_DU_ID;
            break;
        case STAT_DRB_NUM_UL_ONLY_ROHC_SA:
            rPostFamily = STAT_CP_DRB_NUM_UL_ONLY_ROHC_SA;
            break;
        case STAT_ERAB_NUM_UL_ONLY_ROHC:
            rPostFamily = STAT_CP_ERAB_NUM_UL_ONLY_ROHC;
            break;
        case STAT_UE_NUM_UL_ONLY_ROHC:
            rPostFamily = STAT_CP_UE_NUM_UL_ONLY_ROHC;
            break;
        case STAT_UE_NUM_UL_ONLY_ROHC_SA:
            rPostFamily = STAT_CP_UE_NUM_UL_ONLY_ROHC_SA;
            break;
        case STAT_VONR_EMERGENCY_CONN_INFO:
            rPostFamily = STAT_CP_VONR_EMERGENCY_CONN_INFO;
            break;
        case STAT_UE_NUM_PER_GNB_PLMN_SPID_DU_ID:
            rPostFamily = STAT_CP_UE_NUM_PER_GNB_PLMN_SPID_DU_ID;
            break;
        case STAT_UE_NUM_DU_ID:
            rPostFamily = STAT_CP_UE_NUM_DU_ID;
            break;
        case STAT_MDT_CONFIGURATION_DELIVERY_DU_ID:
            rPostFamily = STAT_CP_MDT_CONFIGURATION_DELIVERY_DU_ID;
            break;
#ifdef HOST_SIM
        case STAT_RRC_CONN_INFO_GLOBAL_ID:
            rPostFamily = STAT_CP_RRC_CONN_INFO_GLOBAL_ID;
            break;
        case STAT_RRC_CONN_INFO_GLOBAL_ID_PLMN:
            rPostFamily = STAT_CP_RRC_CONN_INFO_GLOBAL_ID_PLMN;
            break;
        // 23A : DU_ID, PLMN
        case STAT_RRC_CONN_INFO_DU_ID:
            rPostFamily = STAT_CP_RRC_CONN_INFO_DU_ID;
            break;
        case STAT_RRC_CONN_INFO_DU_ID_PLMN:
            rPostFamily = STAT_CP_RRC_CONN_INFO_DU_ID_PLMN;
            break;
        case STAT_DRB_CONN_INFO_GLOBAL_ID_PLMN:
            rPostFamily = STAT_CP_DRB_CONN_INFO_GLOBAL_ID_PLMN;
            break;
        case STAT_DRB_CONN_INFO_GLOBAL_ID:
            rPostFamily = STAT_CP_DRB_CONN_INFO_GLOBAL_ID;
            break;
        case STAT_DRB_CONN_INFO_DU_ID:
            rPostFamily = STAT_CP_DRB_CONN_INFO_DU_ID;
            break;
        case STAT_DRB_CONN_INFO_DU_ID_PLMN:
            rPostFamily = STAT_CP_DRB_CONN_INFO_DU_ID_PLMN;
            break;
#endif
        default:
            break;
    }

    return;
}

bool StatisticsHandler::changeFamily_BasicOperation_IndexgNBDUId(int prevFamily, int& rPostFamily)
{
    switch (prevFamily)
    {
        // -------------------------------------------------------
        // STAT_IDX_APPEND_DU_ID_AT_SECOND_USING_CELLID (Default)
        // -------------------------------------------------------
        case STAT_SPCELL_CHG_TIME:
            rPostFamily = STAT_SPCELL_CHG_TIME_DU_ID;
            break;
        case STAT_SPCELL_CHG_TIME_VIA_SRB3:
            rPostFamily = STAT_SPCELL_CHG_TIME_VIA_SRB3_DU_ID;
            break;
        case STAT_HO_IN:
            rPostFamily = STAT_HO_IN_DU_ID;
            break;
        case STAT_HO_OUT:
            rPostFamily = STAT_HO_OUT_DU_ID;
            break;
        case STAT_PINGPONG:
            rPostFamily = STAT_PINGPONG_DU_ID;
            break;
        case STAT_UPM_RLF_NR:
            rPostFamily = STAT_UPM_RLF_NR_DU_ID;
            break;
        case STAT_HO_EUTRAN_OUT:
            rPostFamily = STAT_HO_EUTRAN_OUT_DU_ID;
            break;
        case STAT_HO_EUTRAN_OUT_FALLBACK:
            rPostFamily = STAT_HO_EUTRAN_OUT_FALLBACK_DU_ID;
            break;
        case STAT_HO_EUTRAN_IN:
            rPostFamily = STAT_HO_EUTRAN_IN_DU_ID;
            break;
        case STAT_NRDC_SN_ADD_MN:
            rPostFamily = STAT_NRDC_SN_ADD_MN_DU_ID;
            break;
        case STAT_NRDC_SN_ADD_SN_WITH_INVALID_CELL:
            rPostFamily = STAT_NRDC_SN_ADD_SN_DU_ID;
            break;
        case STAT_NRDC_SN_REL_MN:
            rPostFamily = STAT_NRDC_SN_REL_MN_DU_ID;
            break;
        case STAT_NRDC_SN_REL_SN:
            rPostFamily = STAT_NRDC_SN_REL_SN_DU_ID;
            break;
        case STAT_NRDC_SCG_FAILURE:
            rPostFamily = STAT_NRDC_SCG_FAILURE_DU_ID;
            break;
        case STAT_NRDC_PSCELL_CHANGE_IN:
            rPostFamily = STAT_NRDC_PSCELL_CHANGE_IN_DU_ID;
            break;
        case STAT_NRDC_PSCELL_CHANGE_OUT:
            rPostFamily = STAT_NRDC_PSCELL_CHANGE_OUT_DU_ID;
            break;
        case STAT_HO_INTER_FREQ_OUT:
            rPostFamily = STAT_HO_INTER_FREQ_OUT_DU_ID;
            break;
        case STAT_HO_INTRA_FREQ_OUT:
            rPostFamily = STAT_HO_INTRA_FREQ_OUT_DU_ID;
            break;
        case STAT_DISCARD_MR_BY_CONDITION_INTRA_NR:
            rPostFamily = STAT_DISCARD_MR_BY_CONDITION_INTRA_NR_DU_ID;
            break;
        case STAT_DISCARD_MR_BY_CONDITION_NR_TO_LTE:
            rPostFamily = STAT_DISCARD_MR_BY_CONDITION_NR_TO_LTE_DU_ID;
            break;
        case STAT_SETUP_DRB_RELEASE:
            rPostFamily = STAT_SETUP_DRB_RELEASE_DU_ID;
            break;
        case STAT_SETUP_UECONTEXT_RELEASE:
            rPostFamily = STAT_SETUP_UECONTEXT_RELEASE_DU_ID;
            break;
        case STAT_RRC_ESTAB:
            rPostFamily = STAT_RRC_ESTAB_DU_ID;
            break;
        case STAT_RRC_RECONFIG:
            rPostFamily = STAT_RRC_RECONFIG_DU_ID;
            break;
        case STAT_RRC_RELEASE:
            rPostFamily = STAT_RRC_RELEASE_DU_ID;
            break;
        case STAT_NG_ESTAB:
            rPostFamily = STAT_NG_ESTAB_DU_ID;
            break;
        case STAT_DRB_SETUP:
            rPostFamily = STAT_DRB_SETUP_DU_ID;
            break;
        case STAT_DRB_SETUP_PLMN_SNSSAI:
            rPostFamily = STAT_DRB_SETUP_DU_ID_PLMN_SNSSAI;
            break;
        case STAT_DRB_RELEASE_AND_ERASE:
            rPostFamily = STAT_DRB_RELEASE_AND_ERASE_DU_ID;
            break;
        case STAT_PDU_SESSION_RESOURCE_SETUP_PLMN_SNSSAI:
            rPostFamily = STAT_PDU_SESSION_RESOURCE_SETUP_DU_ID_PLMN_SNSSAI;
            break;
        case STAT_PDU_SESSION_RESOURCE_MODIFY_REQUEST_DRB_SETUP:
            rPostFamily = STAT_PDU_SESSION_RSC_MODIFY_REQUEST_DRB_SETUP_DU_ID;
            break;
        case STAT_QOS_FLOW_SETUP:
            rPostFamily = STAT_QOS_FLOW_SETUP_DU_ID;
            break;
        case STAT_QOS_FLOW_SETUP_PLMN_SNSSAI:
            rPostFamily = STAT_QOS_FLOW_SETUP_DU_ID_PLMN_SNSSAI;
            break;
        case STAT_REDIR_NR_OUT:
            rPostFamily = STAT_REDIR_NR_OUT_DU_ID;
            break;
        case STAT_REDIR_EUTRAN_OUT:
            rPostFamily = STAT_REDIR_EUTRAN_OUT_DU_ID;
            break;
        case STAT_F1AP_UE_SETUP_CU:
            rPostFamily = STAT_F1AP_UE_SETUP_CU_DU_ID;
            break;
        case STAT_F1AP_CU_INIT_UE_MOD_CU:
            rPostFamily = STAT_F1AP_CU_INIT_UE_MOD_CU_DU_ID;
            break;
        case STAT_MEAS_FOR_SON_CELL:
            rPostFamily = STAT_MEAS_FOR_SON_CELL_DU_ID;
            break;
        case STAT_MEAS_FOR_SON_FREQ:
            rPostFamily = STAT_MEAS_FOR_SON_FREQ_DU_ID;
            break;
        case STAT_CA_SCELL_ADD_REL:
            rPostFamily = STAT_CA_SCELL_ADD_REL_DU_ID;
            break;
        case STAT_SCG_FAIL_OPER:
            rPostFamily = STAT_SCG_FAIL_OPER_DU_ID;
            break;
        case STAT_ERAB_REL_PER_GNB:
            rPostFamily = STAT_ERAB_REL_PER_GNB_DU_ID;
            break;
        case STAT_DATA_USAGE_PER_GNB:
            rPostFamily = STAT_DATA_USAGE_PER_GNB_DU_ID;
            break;
        case STAT_MENB_INIT_SGNB_REL_PER_GNB:
            rPostFamily = STAT_MENB_INIT_SGNB_REL_PER_GNB_DU_ID;
            break;
        case STAT_SGNB_INIT_SGNB_REL_PER_GNB:
            rPostFamily = STAT_SGNB_INIT_SGNB_REL_PER_GNB_DU_ID;
            break;
        case STAT_MRO_PER_CELL:
            rPostFamily = STAT_MRO_PER_CELL_DU_ID;  // 23A FGR-SF0509 FR151
            break;
        case STAT_MRO_PER_NBR:
            rPostFamily = STAT_MRO_PER_NBR_DU_ID;  // 23A FGR-SF0509 FR161
            break;
        case STAT_MRO_PER_EUTRA_NBR:  // 23A FGS-SF0510 FR201
            rPostFamily = STAT_MRO_PER_EUTRA_NBR_DU_ID;
            break;
        case STAT_NR_MEAS_PCI:
            rPostFamily = STAT_NR_MEAS_PCI_DU_ID;
            break;
        case STAT_RRC_INACTIVE_INFO:
            rPostFamily = STAT_RRC_INACTIVE_INFO_DU_ID;
            break;
        case STAT_SGNB_ADD_EUTRAN_OUT:
            rPostFamily = STAT_SGNB_ADD_EUTRAN_OUT_DU_ID;  // 23A FGR-MC3004 FR202
            break;
        case STAT_SGNB_ADD_PER_GNB:
            rPostFamily = STAT_SGNB_ADD_PER_GNB_DU_ID;
            break;
        case STAT_MENB_INIT_SGNB_MOD_PER_GNB:
            rPostFamily = STAT_MENB_INIT_SGNB_MOD_PER_GNB_DU_ID;
            break;
        case STAT_SGNB_INIT_SGNB_MOD_PER_GNB:
            rPostFamily = STAT_SGNB_INIT_SGNB_MOD_PER_GNB_DU_ID;
            break;
        case STAT_ERAB_ADD_PER_GNB:
            rPostFamily = STAT_ERAB_ADD_PER_GNB_DU_ID;
            break;
        case STAT_ERAB_ADD_PER_GNB_PLMN:
            rPostFamily = STAT_ERAB_ADD_PER_GNB_PLMN_DU_ID;
            break;
        case STAT_ERAB_MOD_PER_GNB:
            rPostFamily = STAT_ERAB_MOD_PER_GNB_DU_ID;
            break;
        case STAT_ERAB_CHG_PER_GNB:
            rPostFamily = STAT_ERAB_CHG_PER_GNB_DU_ID;
            break;
        case STAT_ENDC_CTX_REL_ALL_PER_GNB_PLMN:
            rPostFamily = STAT_ENDC_CTX_REL_ALL_PER_GNB_PLMN_DU_ID;
            break;
        case STAT_ERAB_REL_ALL_PER_GNB_PLMN:
            rPostFamily = STAT_ERAB_REL_ALL_PER_GNB_PLMN_DU_ID;
            break;
        case STAT_RRC_REESTAB:
            rPostFamily = STAT_RRC_REESTAB_DU_ID;
            break;
        case STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB:
            rPostFamily = STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB_DU_ID;
            break;
        case STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB:
            rPostFamily = STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB_DU_ID;
            break;
        case STAT_SGNB_INIT_SGNB_REL_MR_PER_GNB:
            rPostFamily = STAT_SGNB_INIT_SGNB_REL_MR_PER_GNB_DU_ID;
            break;
        case STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB:
            rPostFamily = STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB_DU_ID;
            break;
        case STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG:
            rPostFamily = STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG_DU_ID;
            break;
        case STAT_SGNB_ADD_MNHO_INTRA_ENB:
            rPostFamily = STAT_SGNB_ADD_MNHO_INTRA_ENB_DU_ID;
            break;
        case STAT_SGNB_ADD_MNHO_INTER_ENB:
            rPostFamily = STAT_SGNB_ADD_MNHO_INTER_ENB_DU_ID;
            break;
        case STAT_MENB_INIT_SGNB_REL_MCGMOB_PER_GNB:
            rPostFamily = STAT_MENB_INIT_SGNB_REL_MCGMOB_PER_GNB_DU_ID;
            break;
        case STAT_MENB_INIT_SGNB_REL_MCGMOB_UECTX_IND:
            rPostFamily = STAT_MENB_INIT_SGNB_REL_MCGMOB_UECTX_IND_DU_ID;
            break;
        case STAT_MENB_INIT_SGNB_REL_TC_PER_GNB:
            rPostFamily = STAT_MENB_INIT_SGNB_REL_TC_PER_GNB_DU_ID;
            break;
        case STAT_SGNB_ADD_SGNB_CHG:
            rPostFamily = STAT_SGNB_ADD_SGNB_CHG_DU_ID;
            break;
        // -------------------------------------------------------
        // STAT_IDX_APPEND_DU_ID_AT_THIRD_USING_CELLID
        // -------------------------------------------------------
        case STAT_HO_TIME:
            rPostFamily = STAT_HO_TIME_DU_ID;
            break;
        case STAT_CP_HO_TIME:
            rPostFamily = STAT_CP_HO_TIME_DU_ID;
            break;
        case STAT_PSCELL_CHANGE_TIME:
            rPostFamily = STAT_PSCELL_CHANGE_TIME_DU_ID;
            break;
        case STAT_CP_PSCELL_CHANGE_TIME:
            rPostFamily = STAT_CP_PSCELL_CHANGE_TIME_DU_ID;
            break;
        case STAT_UE_NUM_UL_ONLY_ROHC:
            rPostFamily = STAT_UE_NUM_UL_ONLY_ROHC_DU_ID;
            break;
        case STAT_ERAB_NUM_UL_ONLY_ROHC:
            rPostFamily = STAT_ERAB_NUM_UL_ONLY_ROHC_DU_ID;
            break;
        case STAT_UE_NUM_UL_ONLY_ROHC_SA:
            rPostFamily = STAT_UE_NUM_UL_ONLY_ROHC_SA_DU_ID;
            break;
        case STAT_DRB_NUM_UL_ONLY_ROHC_SA:
            rPostFamily = STAT_DRB_NUM_UL_ONLY_ROHC_SA_DU_ID;
            break;
        case STAT_CP_UE_NUM_UL_ONLY_ROHC:
            rPostFamily = STAT_CP_UE_NUM_UL_ONLY_ROHC_DU_ID;
            break;
        case STAT_CP_ERAB_NUM_UL_ONLY_ROHC:
            rPostFamily = STAT_CP_ERAB_NUM_UL_ONLY_ROHC_DU_ID;
            break;
        case STAT_CP_UE_NUM_UL_ONLY_ROHC_SA:
            rPostFamily = STAT_CP_UE_NUM_UL_ONLY_ROHC_SA_DU_ID;
            break;
        case STAT_CP_DRB_NUM_UL_ONLY_ROHC_SA:
            rPostFamily = STAT_CP_DRB_NUM_UL_ONLY_ROHC_SA_DU_ID;
            break;
        case STAT_RRC_SETUP_TIME:
            rPostFamily = STAT_RRC_SETUP_TIME_DU_ID;
            break;
        case STAT_NG_SETUP_TIME:
            rPostFamily = STAT_NG_SETUP_TIME_DU_ID;
            break;
        case STAT_CP_RRC_SETUP_TIME:
            rPostFamily = STAT_CP_RRC_SETUP_TIME_DU_ID;
            break;
        case STAT_CP_NG_SETUP_TIME:
            rPostFamily = STAT_CP_NG_SETUP_TIME_DU_ID;
            break;
        case STAT_UE_NUM_PER_GNB_PLMN:
            rPostFamily = STAT_UE_NUM_PER_GNB_PLMN_DU_ID;
            break;
        case STAT_CP_UE_NUM_PER_GNB_PLMN:
            rPostFamily = STAT_CP_UE_NUM_PER_GNB_PLMN_DU_ID;
            break;
        case STAT_DRB_NUM_PER_GNB:
            rPostFamily = STAT_DRB_NUM_PER_GNB_DU_ID;
            break;
        case STAT_DRB_NUM_PER_GNB_PLMN:
            rPostFamily = STAT_DRB_NUM_PER_GNB_PLMN_DU_ID;
            break;
        case STAT_CP_DRB_NUM_PER_GNB:
            rPostFamily = STAT_CP_DRB_NUM_PER_GNB_DU_ID;
            break;
        case STAT_CP_DRB_NUM_PER_GNB_PLMN:
            rPostFamily = STAT_CP_DRB_NUM_PER_GNB_PLMN_DU_ID;
            break;

        case STAT_DRB_CONN_INFO:
            rPostFamily = STAT_DRB_CONN_INFO_DU_ID;
            break;
        case STAT_DRB_CONN_INFO_PLMN:
            rPostFamily = STAT_DRB_CONN_INFO_DU_ID_PLMN;
            break;
        case STAT_RRC_CONN_INFO:
            rPostFamily = STAT_RRC_CONN_INFO_DU_ID;
            break;
        case STAT_RRC_CONN_INFO_PLMN:
            rPostFamily = STAT_RRC_CONN_INFO_DU_ID_PLMN;
            break;
        case STAT_CP_DRB_CONN_INFO:
            rPostFamily = STAT_CP_DRB_CONN_INFO_DU_ID;
            break;
        case STAT_CP_DRB_CONN_INFO_PLMN:
            rPostFamily = STAT_CP_DRB_CONN_INFO_DU_ID_PLMN;
            break;
        case STAT_CP_RRC_CONN_INFO:
            rPostFamily = STAT_CP_RRC_CONN_INFO_DU_ID;
            break;
        case STAT_CP_RRC_CONN_INFO_PLMN:
            rPostFamily = STAT_CP_RRC_CONN_INFO_DU_ID_PLMN;
            break;
        case STAT_PLMN_HO_OUT:
            rPostFamily = STAT_PLMN_HO_OUT_DU_ID;
            break;
        default:
            return false;
    }

    return true;
}

bool StatisticsHandler::changeFamily_MultipleOperatorRanSupport(int prevFamily, int& rPostFamily)
{
    switch (prevFamily)
    {
        case STAT_INTER_DU_PSCELL_CHANGE_GETTING_BACK:
            rPostFamily = STAT_INTER_DU_PSCELL_CHANGE_GETTING_BACK_GLOBAL_ID;
            break;
        case STAT_PINGPONG:
            rPostFamily = STAT_PINGPONG_GLOBAL_ID;
            break;
        case STAT_HO_EUTRAN_IN:
            rPostFamily = STAT_HO_EUTRAN_IN_GLOBAL_ID;
            break;
        case STAT_HO_EUTRAN_OUT:
            rPostFamily = STAT_HO_EUTRAN_OUT_GLOBAL_ID;
            break;
        case STAT_HO_EUTRAN_OUT_FALLBACK:
            rPostFamily = STAT_HO_EUTRAN_OUT_FALLBACK_GLOBAL_ID;
            break;
        case STAT_HO_IN:
            rPostFamily = STAT_HO_IN_GLOBAL_ID;
            break;
        case STAT_HO_OUT:
            rPostFamily = STAT_HO_OUT_GLOBAL_ID;
            break;
        case STAT_HO_INTER_FREQ_OUT:
            rPostFamily = STAT_HO_INTER_FREQ_OUT_GLOBAL_ID;
            break;
        case STAT_HO_INTRA_FREQ_OUT:
            rPostFamily = STAT_HO_INTRA_FREQ_OUT_GLOBAL_ID;
            break;
        case STAT_HO_TIME:
            rPostFamily = STAT_HO_TIME_GLOBAL_ID;  // 5270
            break;
        case STAT_RRC_REESTAB:
            rPostFamily = STAT_RRC_REESTAB_GLOBAL_ID;
            break;
        case STAT_MRO_PER_CELL:
            rPostFamily = STAT_MRO_PER_CELL_GLOBAL_ID;
            break;
        case STAT_MRO_PER_NBR:
            rPostFamily = STAT_MRO_PER_NBR_GLOBAL_ID;
            break;
        case STAT_MRO_PER_EUTRA_NBR:
            rPostFamily = STAT_MRO_PER_EUTRA_NBR_GLOBAL_ID;
            break;
        case STAT_COVERAGE_PROBLEM_DU_ID:
            rPostFamily = STAT_COVERAGE_PROBLEM_GLOBAL_ID_DU_ID;
            break;
        case STAT_UPM_RLF_NR:
            rPostFamily = STAT_UPM_RLF_NR_GLOBAL_ID;
            break;
        case STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB:
            rPostFamily = STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB_GLOBAL_ID;
            break;
        case STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB:
            rPostFamily = STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB_GLOBAL_ID;
            break;
        case STAT_SGNB_INIT_SGNB_REL_MR_PER_GNB:
            rPostFamily = STAT_SGNB_INIT_SGNB_REL_MR_PER_GNB_GLOBAL_ID;
            break;
        case STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB:
            rPostFamily = STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB_GLOBAL_ID;
            break;
        case STAT_SGNB_ADD_MNHO_INTRA_ENB:
            rPostFamily = STAT_SGNB_ADD_MNHO_INTRA_ENB_GLOBAL_ID;
            break;
        case STAT_SGNB_ADD_MNHO_INTER_ENB:
            rPostFamily = STAT_SGNB_ADD_MNHO_INTER_ENB_GLOBAL_ID;
            break;
        case STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG:
            rPostFamily = STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG_GLOBAL_ID;
            break;
        case STAT_MENB_INIT_SGNB_REL_MCGMOB_PER_GNB:
            rPostFamily = STAT_MENB_INIT_SGNB_REL_MCGMOB_PER_GNB_GLOBAL_ID;
            break;
        case STAT_MENB_INIT_SGNB_REL_MCGMOB_UECTX_IND:
            rPostFamily = STAT_MENB_INIT_SGNB_REL_MCGMOB_UECTX_IND_GLOBAL_ID;
            break;
        case STAT_MENB_INIT_SGNB_REL_TC_PER_GNB:
            rPostFamily = STAT_MENB_INIT_SGNB_REL_TC_PER_GNB_GLOBAL_ID;
            break;
        case STAT_SGNB_ADD_SGNB_CHG:
            rPostFamily = STAT_SGNB_ADD_SGNB_CHG_GLOBAL_ID;
            break;
        case STAT_SPCELL_CHG_TIME_VIA_SRB3:
            rPostFamily = STAT_SPCELL_CHG_TIME_VIA_SRB3_GLOBAL_ID;
            break;
        case STAT_DATA_USAGE_PER_GNB:
            rPostFamily = STAT_DATA_USAGE_PER_GNB_GLOBAL_ID;
            break;
        case STAT_RRC_ESTAB:
            rPostFamily = STAT_RRC_ESTAB_GLOBAL_ID;
            break;
        case STAT_RRC_SETUP_TIME:
            rPostFamily = STAT_RRC_SETUP_TIME_GLOBAL_ID;
            break;
        case STAT_RRC_RELEASE:
            rPostFamily = STAT_RRC_RELEASE_GLOBAL_ID;
            break;
        case STAT_RRC_INACTIVE_INFO:
            rPostFamily = STAT_RRC_INACTIVE_INFO_GLOBAL_ID;
            break;
        case STAT_NG_ESTAB:
            rPostFamily = STAT_NG_ESTAB_GLOBAL_ID;
            break;
        case STAT_NG_SETUP_TIME:
            rPostFamily = STAT_NG_SETUP_TIME_GLOBAL_ID;
            break;
        case STAT_DRB_SETUP:
            rPostFamily = STAT_DRB_SETUP_GLOBAL_ID;
            break;
        case STAT_DRB_SETUP_PLMN_SNSSAI:
            rPostFamily = STAT_DRB_SETUP_GLOBAL_ID_PLMN_SNSSAI;
            break;
        case STAT_PDU_SESSION_RESOURCE_MODIFY_REQUEST_DRB_SETUP:
            rPostFamily = STAT_PDU_SESSION_RESOURCE_MODIFY_REQUEST_DRB_SETUP_GLOBAL_ID;
            break;
        case STAT_INITIAL_DRB_SETUP_DU_ID:
            rPostFamily = STAT_INITIAL_DRB_SETUP_GLOBAL_ID_DU_ID;
            break;
        case STAT_INITIAL_DRB_SETUP_DU_ID_PLMN_SNSSAI:
            rPostFamily = STAT_INITIAL_DRB_SETUP_GLOBAL_ID_DU_ID_PLMN_SNSSAI;
            break;
        case STAT_SETUP_DRB_RELEASE:
            rPostFamily = STAT_SETUP_DRB_RELEASE_GLOBAL_ID;
            break;
        case STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID:
            rPostFamily = STAT_SETUP_ACTIVE_DRB_RELEASE_GLOBAL_ID_DU_ID;
            break;
        case STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID_PLMN:
            rPostFamily = STAT_SETUP_ACTIVE_DRB_RELEASE_GLOBAL_ID_DU_ID_PLMN;
            break;
        case STAT_DRB_RELEASE_AND_ERASE:
            rPostFamily = STAT_DRB_RELEASE_AND_ERASE_GLOBAL_ID;
            break;
        case STAT_SETUP_UECONTEXT_RELEASE:
            rPostFamily = STAT_SETUP_UECONTEXT_RELEASE_GLOBAL_ID;
            break;
        case STAT_RRC_CONN_INFO:
            rPostFamily = STAT_RRC_CONN_INFO_GLOBAL_ID;
            break;
        case STAT_RRC_CONN_INFO_PLMN:
            rPostFamily = STAT_RRC_CONN_INFO_GLOBAL_ID_PLMN;
            break;
        case STAT_CP_RRC_CONN_INFO_DU_ID_PLMN_RFSP:
            rPostFamily = STAT_CP_RRC_CONN_INFO_PLMN_RFSP_GLOBAL_ID; // For VOS
            break;
        case STAT_RAN_PAGING:
            rPostFamily = STAT_RAN_PAGING_GLOBAL_ID;
            break;
        case STAT_DRB_CONN_INFO:
            rPostFamily = STAT_DRB_CONN_INFO_GLOBAL_ID;
            break;
        case STAT_PDU_SESSION_RESOURCE_SETUP_PLMN_SNSSAI:
            rPostFamily = STAT_PDU_SESSION_RESOURCE_SETUP_GLOBAL_ID_PLMN_SNSSAI;
            break;
        case STAT_RRC_RECONFIG:
            rPostFamily = STAT_RRC_RECONFIG_GLOBAL_ID;
            break;
        case STAT_NGAP_MSG_UE:
            rPostFamily = STAT_NGAP_MSG_UE_GLOBAL_ID;
            break;
        case STAT_RRC_MSG:
            rPostFamily = STAT_RRC_MSG_GLOBAL_ID;
            break;
        case STAT_SCG_FAIL_OPER:
            rPostFamily = STAT_SCG_FAIL_OPER_GLOBAL_ID;
            break;
        case STAT_SGNB_INIT_SGNB_REL_PER_GNB:
            rPostFamily = STAT_SGNB_INIT_SGNB_REL_PER_GNB_GLOBAL_ID;
            break;
        case STAT_ERAB_REL_PER_GNB:
            rPostFamily = STAT_ERAB_REL_PER_GNB_GLOBAL_ID;
            break;
        case STAT_MENB_INIT_SGNB_REL_PER_GNB:
            rPostFamily = STAT_MENB_INIT_SGNB_REL_PER_GNB_GLOBAL_ID;
            break;
        case STAT_REDIR_EUTRAN_OUT:
            rPostFamily = STAT_REDIR_EUTRAN_OUT_GLOBAL_ID;
            break;
        case STAT_REDIR_NR_OUT:
            rPostFamily = STAT_REDIR_NR_OUT_GLOBAL_ID;
            break;
        case STAT_ERAB_ADD_PER_GNB:
            rPostFamily = STAT_ERAB_ADD_PER_GNB_GLOBAL_ID;
            break;
        case STAT_ERAB_MOD_PER_GNB:
            rPostFamily = STAT_ERAB_MOD_PER_GNB_GLOBAL_ID;
            break;
        case STAT_ERAB_CHG_PER_GNB:
            rPostFamily = STAT_ERAB_CHG_PER_GNB_GLOBAL_ID;
            break;
        case STAT_MENB_INIT_SGNB_MOD_PER_GNB:
            rPostFamily = STAT_MENB_INIT_SGNB_MOD_PER_GNB_GLOBAL_ID;
            break;
        case STAT_SGNB_ADD_PER_GNB:
            rPostFamily = STAT_SGNB_ADD_PER_GNB_GLOBAL_ID;
            break;
        case STAT_SGNB_ADD_EUTRAN_OUT:
            rPostFamily = STAT_SGNB_ADD_EUTRAN_OUT_GLOBAL_ID;
            break;
        case STAT_SGNB_INIT_SGNB_MOD_PER_GNB:
            rPostFamily = STAT_SGNB_INIT_SGNB_MOD_PER_GNB_GLOBAL_ID;
            break;
        case STAT_X2AP_MSG_UE_PER_GNB:
            rPostFamily = STAT_X2AP_MSG_UE_PER_GNB_GLOBAL_ID;
            break;
        case STAT_X2AP_MSG_NON_UE_PER_GNB:
            rPostFamily = STAT_X2AP_MSG_NON_UE_PER_GNB_GLOBAL_ID;
            break;
        case STAT_NR_REJECTED_SA_CALL:
            rPostFamily = STAT_NR_REJECTED_SA_CALL_GLOBAL_ID;
            break;
        case STAT_DRB_CONN_INFO_PLMN:
            rPostFamily = STAT_DRB_CONN_INFO_GLOBAL_ID_PLMN;
            break;
        case STAT_DRB_NUM_PER_GNB:
            rPostFamily = STAT_DRB_NUM_PER_GNB_GLOBAL_ID;
            break;
        case STAT_DRB_NUM_PER_GNB_PLMN:
            rPostFamily = STAT_DRB_NUM_PER_GNB_GLOBAL_ID_PLMN;
            break;
        case STAT_DRB_NUM_UL_ONLY_ROHC_SA:
            rPostFamily = STAT_DRB_NUM_UL_ONLY_ROHC_SA_GLOBAL_ID;
            break;
        case STAT_ERAB_NUM_UL_ONLY_ROHC:
            rPostFamily = STAT_ERAB_NUM_UL_ONLY_ROHC_GLOBAL_ID;
            break;
        case STAT_UE_NUM_PER_GNB:
            rPostFamily = STAT_UE_NUM_PER_GNB_GLOBAL_ID;
            break;
        case STAT_UE_NUM_PER_GNB_PLMN:
            rPostFamily = STAT_UE_NUM_PER_GNB_GLOBAL_ID_PLMN;
            break;
        case STAT_UE_NUM_UL_ONLY_ROHC:
            rPostFamily = STAT_UE_NUM_UL_ONLY_ROHC_GLOBAL_ID;
            break;
        case STAT_UE_NUM_UL_ONLY_ROHC_SA:
            rPostFamily = STAT_UE_NUM_UL_ONLY_ROHC_SA_GLOBAL_ID;
            break;
        case STAT_QOS_FLOW_SETUP:
            rPostFamily = STAT_QOS_FLOW_SETUP_GLOBAL_ID;
            break;
        case STAT_QOS_FLOW_SETUP_PLMN_SNSSAI:
            rPostFamily = STAT_QOS_FLOW_SETUP_GLOBAL_ID_PLMN_SNSSAI;
            break;
        case STAT_MEAS_FOR_SON_FREQ:
            rPostFamily = STAT_MEAS_FOR_SON_FREQ_GLOBAL_ID;
            break;
        case STAT_MEAS_FOR_SON_CELL:
            rPostFamily = STAT_MEAS_FOR_SON_CELL_GLOBAL_ID;
            break;
        case STAT_MEAS_FOR_SON_EUTRA_FREQ_DU_ID:
            rPostFamily = STAT_MEAS_FOR_SON_EUTRA_FREQ_GLOBAL_ID_DU_ID;
            break;
        case STAT_MEAS_FOR_SON_EUTRA_CELL_DU_ID:
            rPostFamily = STAT_MEAS_FOR_SON_EUTRA_CELL_GLOBAL_ID_DU_ID;
            break;
        case STAT_CA_SCELL_ADD_REL:
            rPostFamily = STAT_CA_SCELL_ADD_REL_GLOBAL_ID;
            break;
        case STAT_DISCARD_MR_BY_CONDITION_INTRA_NR:
            rPostFamily = STAT_DISCARD_MR_BY_CONDITION_INTRA_NR_GLOBAL_ID;
            break;
        case STAT_DISCARD_MR_BY_CONDITION_NR_TO_LTE:
            rPostFamily = STAT_DISCARD_MR_BY_CONDITION_NR_TO_LTE_GLOBAL_ID;
            break;
        case STAT_CP_HO_TIME:
            rPostFamily = STAT_CP_HO_TIME_GLOBAL_ID;  // 5662
            break;
        case STAT_CP_RRC_SETUP_TIME:
            rPostFamily = STAT_CP_RRC_SETUP_TIME_GLOBAL_ID;
            break;
        case STAT_CP_NG_SETUP_TIME:
            rPostFamily = STAT_CP_NG_SETUP_TIME_GLOBAL_ID;
            break;
        case STAT_CP_RRC_CONN_INFO:
            rPostFamily = STAT_CP_RRC_CONN_INFO_GLOBAL_ID;
            break;
        case STAT_CP_RRC_CONN_INFO_PLMN:
            rPostFamily = STAT_CP_RRC_CONN_INFO_GLOBAL_ID_PLMN;
            break;
        case STAT_CP_DRB_CONN_INFO:
            rPostFamily = STAT_CP_DRB_CONN_INFO_GLOBAL_ID;
            break;
        case STAT_CP_DRB_CONN_INFO_PLMN:
            rPostFamily = STAT_CP_DRB_CONN_INFO_GLOBAL_ID_PLMN;
            break;
        case STAT_CP_DRB_NUM_UL_ONLY_ROHC_SA:
            rPostFamily = STAT_CP_DRB_NUM_UL_ONLY_ROHC_SA_GLOBAL_ID;
            break;
        case STAT_CP_ERAB_NUM_UL_ONLY_ROHC:
            rPostFamily = STAT_CP_ERAB_NUM_UL_ONLY_ROHC_GLOBAL_ID;
            break;
        case STAT_CP_UE_NUM_UL_ONLY_ROHC:
            rPostFamily = STAT_CP_UE_NUM_UL_ONLY_ROHC_GLOBAL_ID;
            break;
        case STAT_CP_UE_NUM_UL_ONLY_ROHC_SA:
            rPostFamily = STAT_CP_UE_NUM_UL_ONLY_ROHC_SA_GLOBAL_ID;
            break;
        case STAT_CP_UE_NUM_PER_GNB:
            rPostFamily = STAT_CP_UE_NUM_PER_GNB_GLOBAL_ID;
            break;
        case STAT_CP_UE_NUM_PER_GNB_PLMN:
            rPostFamily = STAT_CP_UE_NUM_PER_GNB_GLOBAL_ID_PLMN;
            break;
        case STAT_CP_DRB_NUM_PER_GNB:
            rPostFamily = STAT_CP_DRB_NUM_PER_GNB_GLOBAL_ID;
            break;
        case STAT_CP_DRB_NUM_PER_GNB_PLMN:
            rPostFamily = STAT_CP_DRB_NUM_PER_GNB_GLOBAL_ID_PLMN;
            break;
        case STAT_E1AP_CUCP_MSG_UE:
            rPostFamily = STAT_E1AP_CUCP_MSG_UE_GLOBAL_ID;
            break;
        case STAT_LB_HO:
            rPostFamily = STAT_LB_HO_GLOBAL_ID;
            break;
        case STAT_F1AP_CU_MSG_UE:
            rPostFamily = STAT_F1AP_CU_MSG_UE_GLOBAL_ID;
            break;
        case STAT_F1AP_UE_SETUP_CU:
            rPostFamily = STAT_F1AP_UE_SETUP_CU_GLOBAL_ID;
            break;
        case STAT_F1AP_CU_INIT_UE_MOD_CU:
            rPostFamily = STAT_F1AP_CU_INIT_UE_MOD_CU_GLOBAL_ID;
            break;
        case STAT_UE_CAPA_SIZE_DIST_DU_ID:
            rPostFamily = STAT_UE_CAPA_SIZE_DIST_GLOBAL_ID_DU_ID;
            break;
        case STAT_ENDC_CTX_REL_ALL_PER_GNB_PLMN:
            rPostFamily = STAT_ENDC_CTX_REL_ALL_PER_GNB_GLOBAL_ID_PLMN;
            break;
        case STAT_ENDC_CTX_REL_ALL_PER_GNB_PLMN_ACT:
            rPostFamily = STAT_ENDC_CTX_REL_ALL_PER_GNB_PLMN_ACT_GLOBAL_ID;
            break;
        case STAT_ERAB_REL_ALL_PER_GNB_PLMN:
            rPostFamily = STAT_ERAB_REL_ALL_PER_GNB_GLOBAL_ID_PLMN;
            break;
        case STAT_NRDC_PSCELL_CHANGE_IN:
            rPostFamily = STAT_NRDC_PSCELL_CHANGE_IN_GLOBAL_ID;
            break;
        case STAT_NRDC_PSCELL_CHANGE_OUT:
            rPostFamily = STAT_NRDC_PSCELL_CHANGE_OUT_GLOBAL_ID;
            break;
        case STAT_PSCELL_CHANGE_TIME:
            rPostFamily = STAT_PSCELL_CHANGE_TIME_GLOBAL_ID;
            break;
        case STAT_PLMN_HO_OUT:
            rPostFamily = STAT_PLMN_HO_OUT_DU_ID;
            break;
            // FGR-CC5200:FR661 FR673 FR721 FR731
        case STAT_NRDC_SN_ADD_MN:
            rPostFamily = STAT_NRDC_SN_ADD_MN_GLOBAL_ID;  //  FGR-CC5200:FR661
            break;
        case STAT_NRDC_SN_ADD_SN_WITH_INVALID_CELL:
            rPostFamily = STAT_NRDC_SN_ADD_SN_GLOBAL_ID;  //  FGR-CC5200:FR673
            break;
        case STAT_NRDC_SN_REL_MN:
            rPostFamily = STAT_NRDC_SN_REL_MN_GLOBAL_ID;  //  FGR-CC5200:FR721
            break;
        case STAT_NRDC_SN_REL_SN:
            rPostFamily = STAT_NRDC_SN_REL_SN_GLOBAL_ID;  //  FGR-CC5200:FR731
            break;
        case STAT_NRDC_SCG_FAILURE:
            rPostFamily = STAT_NRDC_SCG_FAILURE_GLOBAL_ID; // FGR-CC5203:FR270
            break;
        case STAT_CHO_OUT:
            rPostFamily = STAT_CHO_OUT_GLOBAL_ID;
            break;
        case STAT_CHO_IN:
            rPostFamily = STAT_CHO_IN_GLOBAL_ID;
            break;
        case STAT_NR_MEAS_PCI:
            rPostFamily = STAT_NR_MEAS_PCI_GLOBAL_ID; // FGS-SF0502:FR748
            break;
        case STAT_CP_UE_NUM_PER_GNB_PLMN_SPID_DU_ID:
            rPostFamily = STAT_CP_UE_NUM_PER_GNB_PLMN_SPID_DU_ID_GLOBAL_ID;
            break;
        case STAT_SGNB_ADD_PER_GNB_SPID_DU_ID:
            rPostFamily = STAT_SGNB_ADD_PER_GNB_SPID_DU_ID_GLOBAL_ID;
            break;
        default:
            return false;
    }
    return true;
}

//////////// Fill New Index ////////////
uint64_t StatisticsHandler::getTgtGnbDuId(callInfo_type *ptCi)
{

#ifdef __NVGNB__
    (void)ptCi;
    return MAX_GNB_DU_ID;
#else
    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_GNB_DU_ID + 1);

    uint16_t endPointIdx = ptCi->hoInfo.targetDu.f1Idx;
    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, MAX_GNB_DU_ID + 1);
    VCCB_CHECK_E_RANGE_AND_VAL(endPointIdx, MAX_GNB_DU_PER_GNB_CU_CP, MAX_GNB_DU_ID + 1);

    return GNBINFO[gnbNum].gnbDu[endPointIdx].gnbDuId;
#endif
}

uint64_t StatisticsHandler::getDuId(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    // It is a valid case when ptCi is NULL

#ifdef __NVGNB__
    uint64_t duId = MAX_GNB_DU_ID;  // In 23A, It's 0. Since 23B, It's MAX_GNB_DU_ID.
    (void)ptCi;
    (void)cellIdentity;
#else
    uint64_t duId = MAX_GNB_DU_ID + 1;
    uint16_t cellNum = MAX_CELL_NUM_VCCB;
    uint16_t gnbNumForDuID = (ptCi != NULL) ? ptCi->gnbNum : gnbNum;

    if (gnbNumForDuID < MAX_GNB_PER_SYS)
    {
        if (cellIdentity < MAX_CELL_IDENTITY)
        {
            VccbGnbInfo_type *ptGnbInfo = &GNBINFO[gnbNumForDuID];
            cellNum = ptGnbInfo->env.cellNum[cellIdentity];
            if (cellNum < MAX_CELL_NUM_VCCB)
            {
                uint16_t endPointF1Index = CELLINFO[cellNum].endPointF1Index;
                if (endPointF1Index < MAX_GNB_DU_PER_GNB_CU_CP)
                {
                    duId = ptGnbInfo->gnbDu[endPointF1Index].gnbDuId;
                }
            }
        }
    }

    // if DU ID is invalid, then use max value
    if (duId > MAX_GNB_DU_ID)
    {
        duId = MAX_GNB_DU_ID;
    }
#endif

    return duId;
};

uint32_t StatisticsHandler::getPlmn()
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, 0);
    uint32_t cellPlmnKey = 0;

    VLIB_ConvertPlmnIdToPlmnValue(&GNBINFO[gnbNum].globalGnbId.plmn.s2, &cellPlmnKey);

    return cellPlmnKey;
}

uint32_t StatisticsHandler::getPlmnUe(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, 0);

    uint32_t uePlmnKey = 0;

    VLIB_ConvertPlmnIdToPlmnValue(&ptCi->ueInfo.servedPlmn.s2, &uePlmnKey);

    return uePlmnKey;
}

uint16_t StatisticsHandler::getCellIdentity(int family, StatIndexValue indexValue[INDEX_END])
{
    AUTO_TRACE_FUNC;

    int prevCellIdentityIndex = INDEX_CellIdentity;

    switch (family)
    {
        case STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB:
        case STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB:
        case STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB_PER_DU_PER_NCI:
        case STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB_PER_DU:
        case STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB_PER_DU:
        case STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB_GLOBAL_ID:
        case STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB_GLOBAL_ID:
            prevCellIdentityIndex = INDEX_SrcCellIdentity;
            break;
        case STAT_SGNB_ADD_PER_GNB:
        case STAT_NRDC_SN_ADD_SN_WITH_INVALID_CELL:
        case STAT_SGNB_ADD_EUTRAN_OUT:
        case STAT_SGNB_ADD_PER_GNB_DU_ID:
        case STAT_NRDC_SN_ADD_SN_DU_ID:
        case STAT_NRDC_SN_ADD_SN_GLOBAL_ID:
        case STAT_SGNB_ADD_EUTRAN_OUT_DU_ID:
        case STAT_SGNB_ADD_PER_GNB_GLOBAL_ID:
        case STAT_SGNB_ADD_EUTRAN_OUT_GLOBAL_ID:
            prevCellIdentityIndex = INDEX_CellIdentityWithInvalid;
            break;
        default:
            break;
    }

    return (uint16_t)indexValue[prevCellIdentityIndex].value;
}

uint64_t StatisticsHandler::getTriggeredNCI(callInfo_type* ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_CELL_IDENTITY);

    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->hoInfo.hoGnbIdx, MAX_GNB_PER_CALL, MAX_CELL_IDENTITY);

    return VLIB_GnbIdCellId2NrCellId(
        &ptCi->gnbInfo[ptCi->hoInfo.hoGnbIdx].globalGnbId.gnbId, (uint16_t)ptCi->hoInfo.cellIdentity);
}

/****************************************************************************
 * @brief           Handle statistics mType when base family and derived family counter types does not match.
 * @param[in]       mType : original mType / int&
 * @param[in]       mActualFamily : derived family / int
 * @return          void
 ****************************************************************************/
void StatisticsHandler::changeCounterTypeIdForDerivedFamilies(int& mType, int mActualFamily)
{
    AUTO_TRACE_FUNC;

    switch(mActualFamily)
    {
        case STAT_SGNB_INIT_SGNB_REL_PER_GNB_GLOBAL_ID:
            if(EndcRelBySgnb_DL_randomAccessProblem_AfterInitialAccess == mType) // 15
            {
                mType = EndcRelBySgnb_DL_randomAccessProblem_AfterInitialAccess_GlobalId; // 16
            }
            else if(EndcRelBySgnb_SwitchOffOngoing == mType) // 16
            {
                mType = EndcRelBySgnb_SwitchOffOngoing_GlobalId; // 15
            }
            break;
        case STAT_SGNB_INIT_SGNB_REL_PER_GNB_PER_DU:
            if(EndcRelBySgnb_DL_randomAccessProblem_AfterInitialAccess == mType) // 15
            {
                mType = EndcRelBySgnb_DL_randomAccessProblem_AfterInitialAccess_DU; // 16
            }
            else if(EndcRelBySgnb_SwitchOffOngoing == mType) // 16
            {
                mType = EndcRelBySgnb_SwitchOffOngoing_DU; // 15
            }
            break;
        case STAT_ERAB_REL_PER_GNB_GLOBAL_ID:
            if(ErabRel_DL_randomAccessProblem_AfterInitialAccess == mType) // 15
            {
                mType = ErabRel_DL_randomAccessProblem_AfterInitialAccess_GlobalId; // 16
            }
            else if(ErabRel_SwitchOffOngoing == mType) // 16
            {
                mType = ErabRel_SwitchOffOngoing_GlobalId; // 15
            }
            break;
        case STAT_SGNB_ADD_PER_GNB_PER_DU:
            if(EndcAddFail_CpFail_RxF1UEContextModificationResponseFail == mType) // 45
            {
                mType = EndcAddFail_CpFail_RxF1UEContextModificationResponseFail_DU_cell; // 30
            }
            else if(EndcAddFail_CpFail_RxE1BearerContextModificationResponseFail == mType) // 46
            {
                mType = EndcAddFail_CpFail_RxE1BearerContextModificationResponseFail_DU_cell; // 31
            }
            else if(EndcAddFail_CpFail_TxF1UEContextModificationRequestFail == mType) // 47
            {
                mType = EndcAddFail_CpFail_TxF1UEContextModificationRequestFail_DU_cell; // 32
            }
            else if(EndcAddFail_CpFail_TxE1BearerContextModificationRequestFail == mType) // 48
            {
                mType = EndcAddFail_CpFail_TxE1BearerContextModificationRequestFail_DU_cell; // 33
            }
            else if(EndcAddFail_CpFail_Unspecified == mType) // 49
            {
                mType = EndcAddFail_CpFail_Unspecified_DU_cell; // 34
            }
            break;
        default:
            break;
    }
}

bool StatisticsHandler::isCollectStatForDUID()
{
#ifdef NEW_HOST_SIM
    if (DBG->value.statTestMode_DUID.sw == 1)
        return !!(DBG->value.statTestMode_DUID.val);
#endif

    return !!(FOO.VF_BasicOperation_IndexgNBDUId);
}

bool StatisticsHandler::isCollectStatForGLOBALID()
{
#ifdef NEW_HOST_SIM
    if (DBG->value.statTestMode_GLOBALID.sw == 1)
        return !!(DBG->value.statTestMode_GLOBALID.val);
#endif

    return !!(FOO.VF_MultipleOperatorRanSupport);
}

bool StatisticsHandler::isCollectStatForCP()
{
#ifdef NEW_HOST_SIM
    if (DBG->value.statTestMode_CP.sw == 1)
        return !!(DBG->value.statTestMode_CP.val);
#endif

    return (e_VCCB_ACPF_CNF == VCOM_getSystemType());
}
