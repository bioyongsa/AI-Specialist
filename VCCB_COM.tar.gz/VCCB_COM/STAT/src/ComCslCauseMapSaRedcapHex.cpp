#include <map>
#include <string>
#include "PM_TYPE_ID.h"
#include "cause_call_5g.h"
#include "ComCslCauseMap.h"

typedef std::map<cause_t, pmCause_t> pmCauseMap_type;

static pmCauseMap_type& wrapperCauseMap()
{
    static pmCauseMap_type causeMap;
    return causeMap;
}

nr_csl_cause_error_e nr_csl_redcap_hex_cause_make_sacp_map(void)
{
    wrapperCauseMap()[CAUSE_NO_FAULT] =
        HEXA_REDCAP_SAACPF_NoFault;
    wrapperCauseMap()[CauseCpInternalTmOutRrcConnectionReconfig] =
        HEXA_REDCAP_SAACPF_CauseInternalTmOutRrcConnectionReconfig;
    wrapperCauseMap()[CauseCpInternalTmOutF1UeContextSetup] =
        HEXA_REDCAP_SAACPF_CauseInternalTmOutF1UeContextSetup;
    wrapperCauseMap()[CauseCpInternalTmOutE1BearerSetup] =
        HEXA_REDCAP_SAACPF_CauseInternalTmOutE1BearerSetup;
    wrapperCauseMap()[CauseCpInternalTmOutE1BearerContextModification] =
        HEXA_REDCAP_SAACPF_CauseInternalTmOutE1BearerContextModification;
    wrapperCauseMap()[CauseCpInternalTmOutF1UeContextModification] =
        HEXA_REDCAP_SAACPF_CauseInternalTmOutF1UeContextModification;
    wrapperCauseMap()[CauseCpInternalTmOutF1UeContextRelease] =
        HEXA_REDCAP_SAACPF_CauseInternalTmOutF1UeContextRelease;
    wrapperCauseMap()[CauseCpInternalTmOutInternalResourceSetup] =
        HEXA_REDCAP_SAACPF_CauseInternalTmOutInternalResourceSetup;
    wrapperCauseMap()[CauseCpInternalF1SctpOutOfService] =
        HEXA_REDCAP_SAACPF_CauseInternalF1SctpOutOfService;
    wrapperCauseMap()[CauseCpInternalE1SctpOutOfService] =
        HEXA_REDCAP_SAACPF_CauseInternalE1SctpOutOfService;
    wrapperCauseMap()[CauseCpInternalMDSSendFail] =
        HEXA_REDCAP_SAACPF_CauseInternalMDSSendFail;
    wrapperCauseMap()[CauseCpInternalCacCallCountOver] =
        HEXA_REDCAP_SAACPF_CauseInternalCacCallCountOver;
    wrapperCauseMap()[CauseCpInternalInvalidCallContext] =
        HEXA_REDCAP_SAACPF_CauseInternalInvalidCallContext;
    wrapperCauseMap()[CauseCpInternalResourceAllocFail] =
        HEXA_REDCAP_SAACPF_CauseInternalResourceAllocFail;
    wrapperCauseMap()[CauseCpInternalOMIntervention] =
        HEXA_REDCAP_SAACPF_CauseInternalOMIntervention;
    wrapperCauseMap()[CauseCpInternalVmScaleIn] =
        HEXA_REDCAP_SAACPF_CauseInternalVmScaleIn;
    wrapperCauseMap()[CauseCpInternalCellRelease] =
        HEXA_REDCAP_SAACPF_CauseInternalCellRelease;
    wrapperCauseMap()[CauseCpInternalCallAllocationFail] =
        HEXA_REDCAP_SAACPF_CauseInternalCallAllocationFail;
    wrapperCauseMap()[CauseCpInternalUpAllocationFail] =
        HEXA_REDCAP_SAACPF_CauseInternalUpAllocationFail;
    wrapperCauseMap()[CauseCpInternalInvalidCallId] =
        HEXA_REDCAP_SAACPF_CauseInternalInvalidCallId;
    wrapperCauseMap()[CauseCpInternalInvalidPlmn] =
        HEXA_REDCAP_SAACPF_CauseInternalInvalidPlmn;
    wrapperCauseMap()[CauseCpInternalUserInactivity] =
        HEXA_REDCAP_SAACPF_CauseInternalUserInactivity;
    wrapperCauseMap()[CauseCpInternalScgMobility] =
        HEXA_REDCAP_SAACPF_CauseInternalScgMobility;
    wrapperCauseMap()[CauseCpInternalMeasurementReportBasedRelease] =
        HEXA_REDCAP_SAACPF_CauseInternalMeasurementReportBasedRelease;
    wrapperCauseMap()[CauseCpInternalDuULRadioLinkFailure] =
        HEXA_REDCAP_SAACPF_CauseInternalDuULRadioLinkFailure;
    wrapperCauseMap()[CauseCpInternalDuRlcMaxNumRetx] =
        HEXA_REDCAP_SAACPF_CauseInternalDuRlcMaxNumRetx;
    wrapperCauseMap()[CauseCpInternalCpSrb3IntegrityFailure] =
        HEXA_REDCAP_SAACPF_CauseInternalCpSrb3IntegrityFailure;
    wrapperCauseMap()[CauseCpInternalCuOverload] =
        HEXA_REDCAP_SAACPF_CauseInternalCuOverload;
    wrapperCauseMap()[CauseCpInternalStoreRrcMessageError] =
        HEXA_REDCAP_SAACPF_CauseInternalStoreRrcMessageError;
    wrapperCauseMap()[CauseCpInternalStoreE1MessageError] =
        HEXA_REDCAP_SAACPF_CauseInternalStoreE1MessageError;
    wrapperCauseMap()[CauseCpInternalStoreF1MessageError] =
        HEXA_REDCAP_SAACPF_CauseInternalStoreF1MessageError;
    wrapperCauseMap()[CauseCpInternalSendRrcMessageError] =
        HEXA_REDCAP_SAACPF_CauseInternalSendRrcMessageError;
    wrapperCauseMap()[CauseCpInternalSendE1MessageError] =
        HEXA_REDCAP_SAACPF_CauseInternalSendE1MessageError;
    wrapperCauseMap()[CauseCpInternalSendF1MessageError] =
        HEXA_REDCAP_SAACPF_CauseInternalSendF1MessageError;
    wrapperCauseMap()[CauseCpInternalSaTmOutNgInitialContextSetup] =
        HEXA_REDCAP_SAACPF_CauseInternalTmOutNgInitialContextSetup;
    wrapperCauseMap()[CauseCpInternalSaTmOutRrcSetup] =
        HEXA_REDCAP_SAACPF_CauseInternalTmOutRrcSetup;
    wrapperCauseMap()[CauseCpInternalSaTmOutRrcUeCapabilityEnquiry] =
        HEXA_REDCAP_SAACPF_CauseInternalTmOutRrcUeCapabilityEnquiry;
    wrapperCauseMap()[CauseCpInternalSaTmOutRrcSecurityModeCommand] =
        HEXA_REDCAP_SAACPF_CauseInternalTmOutRrcSecurityModeCommand;
    wrapperCauseMap()[CauseCpInternalSaHoTmOutNgDownlinkRanStatusTransfer] =
        HEXA_REDCAP_SAACPF_CauseInternalHoTmOutNgDownlinkRanStatusTransfer;
    wrapperCauseMap()[CauseCpInternalSaHoTmOutNgPathSwitchRequest] =
        HEXA_REDCAP_SAACPF_CauseInternalHoTmOutNgPathSwitchRequest;
    wrapperCauseMap()[CauseCpInternalSaHoTmOutNgRelocOverall] =
        HEXA_REDCAP_SAACPF_CauseInternalHoTmOutNgRelocOverall;
    wrapperCauseMap()[CauseCpInternalSaHoTmOutXnSNStatusTransfer] =
        HEXA_REDCAP_SAACPF_CauseInternalHoTmOutXnSNStatusTransfer;
    wrapperCauseMap()[CauseCpInternalSaHoTmOutXnRelocOverall] =
        HEXA_REDCAP_SAACPF_CauseInternalHoTmOutXnRelocOverall;
    wrapperCauseMap()[CauseCpInternalSaHoTmOutRrcHandoverComplete] =
        HEXA_REDCAP_SAACPF_CauseInternalHoTmOutRrcHandoverComplete;
    wrapperCauseMap()[CauseCpInternalSaNgSctpOutOfService] =
        HEXA_REDCAP_SAACPF_CauseInternalNgSctpOutOfService;
    wrapperCauseMap()[CauseCpInternalSaXnSctpOutOfService] =
        HEXA_REDCAP_SAACPF_CauseInternalXnSctpOutOfService;
    wrapperCauseMap()[CauseCpInternalSaAllAmfNotService] =
        HEXA_REDCAP_SAACPF_CauseInternalAllAmfNotService;
    wrapperCauseMap()[CauseCpInternalSaNotExistAmf] =
        HEXA_REDCAP_SAACPF_CauseInternalNotExistAmf;
    wrapperCauseMap()[CauseCpInternalSaAvailableAmfNotExist] =
        HEXA_REDCAP_SAACPF_CauseInternalAvailableAmfNotExist;
    wrapperCauseMap()[CauseCpInternalSaDuCallAllocationFail] =
        HEXA_REDCAP_SAACPF_CauseInternalDuCallAllocationFail;
    wrapperCauseMap()[CauseCpInternalSaRedirectionRelease] =
        HEXA_REDCAP_SAACPF_CauseInternalRedirectionRelease;
    wrapperCauseMap()[CauseCpInternalSaNotSupported5qiValue] =
        HEXA_REDCAP_SAACPF_CauseInternalNotSupported5qiValue;
    wrapperCauseMap()[CauseCpInternalSaStoreNgMessageError] =
        HEXA_REDCAP_SAACPF_CauseInternalStoreNgMessageError;
    wrapperCauseMap()[CauseCpInternalSaStoreXnMessageError] =
        HEXA_REDCAP_SAACPF_CauseInternalStoreXnMessageError;
    wrapperCauseMap()[CauseCpInternalSaSendNgMessageError] =
        HEXA_REDCAP_SAACPF_CauseInternalSendNgMessageError;
    wrapperCauseMap()[CauseCpInternalSaSendXnMessageError] =
        HEXA_REDCAP_SAACPF_CauseInternalSendXnMessageError;
    wrapperCauseMap()[CauseCpInternalSaRreOldCallRelease] =
        HEXA_REDCAP_SAACPF_CauseInternalRreOldCallRelease;
    wrapperCauseMap()[CauseCpInternalSaTmOutRrcReestablishment] =
        HEXA_REDCAP_SAACPF_CauseInternalTmOutRrcReestablishment;
    wrapperCauseMap()[CauseF1apRadioUnspecified] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioUnspecified;
    wrapperCauseMap()[CauseF1apRadioRLFailure] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioRLFailure;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedCuUeF1apId] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioUnknownOrAlreadyAllocatedCuUeF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedDuUeF1apId] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioUnknownOrAlreadyAllocatedDuUeF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownInconsistentPairOfUeF1apId] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioUnknownInconsistentPairOfUeF1apId;
    wrapperCauseMap()[CauseF1apRadioInteraction] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioInteraction;
    wrapperCauseMap()[CauseF1apRadioNotSupportedQCI] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioNotSupportedQCI;
    wrapperCauseMap()[CauseF1apRadioDesirableRadioReasons] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioDesirableRadioReasons;
    wrapperCauseMap()[CauseF1apRadioUnavailableRadioReasons] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioUnavailableRadioReasons;
    wrapperCauseMap()[CauseF1apRadioProcedureCancelled] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioProcedureCancelled;
    wrapperCauseMap()[CauseF1apRadioNormalRelease] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioNormalRelease;
    wrapperCauseMap()[CauseF1apRadioCellNotAvailable] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioCellNotAvailable;
    wrapperCauseMap()[CauseF1apRadioRLFailureothers] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioRLFailureothers;
    wrapperCauseMap()[CauseF1apRadioUeRejection] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioUeRejection;
    wrapperCauseMap()[CauseF1apRadioResourcesNotAvailableForTheSlice] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioResourcesNotAvailableForTheSlice;
    wrapperCauseMap()[CauseF1apTransportUnspecified] =
        HEXA_REDCAP_SAACPF_CauseF1apTransportUnspecified;
    wrapperCauseMap()[CauseF1apTransportResourceUnavailable] =
        HEXA_REDCAP_SAACPF_CauseF1apTransportResourceUnavailable;
    wrapperCauseMap()[CauseF1apProtocolTransferSyntaxError] =
        HEXA_REDCAP_SAACPF_CauseF1apProtocolTransferSyntaxError;
    wrapperCauseMap()[CauseF1apProtocolAbstractSyntaxErrorReject] =
        HEXA_REDCAP_SAACPF_CauseF1apProtocolAbstractSyntaxErrorReject;
    wrapperCauseMap()[CauseF1apProtocolAbstractSyntaxErrorIgnore] =
        HEXA_REDCAP_SAACPF_CauseF1apProtocolAbstractSyntaxErrorIgnore;
    wrapperCauseMap()[CauseF1apProtocolMessageNotCompatible] =
        HEXA_REDCAP_SAACPF_CauseF1apProtocolMessageNotCompatible;
    wrapperCauseMap()[CauseF1apProtocolSemanticError] =
        HEXA_REDCAP_SAACPF_CauseF1apProtocolSemanticError;
    wrapperCauseMap()[CauseF1apProtocolAbstractSyntaxError] =
        HEXA_REDCAP_SAACPF_CauseF1apProtocolAbstractSyntaxError;
    wrapperCauseMap()[CauseF1apProtocolUnspecified] =
        HEXA_REDCAP_SAACPF_CauseF1apProtocolUnspecified;
    wrapperCauseMap()[CauseF1apMiscControlProcessingOverload] =
        HEXA_REDCAP_SAACPF_CauseF1apMiscControlProcessingOverload;
    wrapperCauseMap()[CauseF1apMiscUnavailableResources] =
        HEXA_REDCAP_SAACPF_CauseF1apMiscUnavailableResources;
    wrapperCauseMap()[CauseF1apMiscHardwareFailure] =
        HEXA_REDCAP_SAACPF_CauseF1apMiscHardwareFailure;
    wrapperCauseMap()[CauseF1apMiscOMIntervention] =
        HEXA_REDCAP_SAACPF_CauseF1apMiscOMIntervention;
    wrapperCauseMap()[CauseF1apMiscUnspecifiedFailure] =
        HEXA_REDCAP_SAACPF_CauseF1apMiscUnspecifiedFailure;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnspecified] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerUnspecified;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpUeE1apId] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpUeE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpUeE1apId] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpUeE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfUeE1apId] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfUeE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerInteractionWithOtherProcedure] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerInteractionWithOtherProcedure;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerPdcpCountWrapAround] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerPdcpCountWrapAround;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNotSupportedQciValue] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerNotSupportedQciValue;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNotSupported5QiValue] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerNotSupported5QiValue;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerEncryptionAlgorithmsNotSupported] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerEncryptionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerIntegrityProtectionAlgorithmsNotSupported] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerIntegrityProtectionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUpIntegrityProtectionNotPossible] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerUpIntegrityProtectionNotPossible;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUpConfidentialityProtectionNotPossible] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerUpConfidentialityProtectionNotPossible;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMultiplePduSessionIdInstances] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerMultiplePduSessionIdInstances;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownPduSessionId] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerUnknownPduSessionId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMultipleQosFlowIdInstances] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerMultipleQosFlowIdInstances;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownQosFlowId] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerUnknownQosFlowId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMultipleDrbIdInstances] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerMultipleDrbIdInstances;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownDrbId] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerUnknownDrbId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerInvalidQosCombination] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerInvalidQosCombination;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerProcedureCancelled] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerProcedureCancelled;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNormalRelease] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerNormalRelease;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNoRadioResourcesAvailable] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerNoRadioResourcesAvailable;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerActionDesirableForRadioReasons] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerActionDesirableForRadioReasons;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerResourcesNotAvailableForTheSlice] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerResourcesNotAvailableForTheSlice;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerPdcpConfigurationNotSupported] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerPdcpConfigurationNotSupported;
    wrapperCauseMap()[CauseE1apTransportLayerUnspecified] =
        HEXA_REDCAP_SAACPF_CauseE1apTransportLayerUnspecified;
    wrapperCauseMap()[CauseE1apTransportLayerTransportResourceUnavailable] =
        HEXA_REDCAP_SAACPF_CauseE1apTransportLayerTransportResourceUnavailable;
    wrapperCauseMap()[CauseE1apProtocolTransferSyntaxError] =
        HEXA_REDCAP_SAACPF_CauseE1apProtocolTransferSyntaxError;
    wrapperCauseMap()[CauseE1apProtocolAbstractSyntaxErrorReject] =
        HEXA_REDCAP_SAACPF_CauseE1apProtocolAbstractSyntaxErrorReject;
    wrapperCauseMap()[CauseE1apProtocolAbstractSyntaxErrorIgnoreAndNotify] =
        HEXA_REDCAP_SAACPF_CauseE1apProtocolAbstractSyntaxErrorIgnoreAndNotify;
    wrapperCauseMap()[CauseE1apProtocolMessageNotCompatibleWithReceiverState] =
        HEXA_REDCAP_SAACPF_CauseE1apProtocolMessageNotCompatibleWithReceiverState;
    wrapperCauseMap()[CauseE1apProtocolSemanticError] =
        HEXA_REDCAP_SAACPF_CauseE1apProtocolSemanticError;
    wrapperCauseMap()[CauseE1apProtocolAbstractSyntaxErrorFalselyConstructedMessage] =
        HEXA_REDCAP_SAACPF_CauseE1apProtocolAbstractSyntaxErrorFalselyConstructedMessage;
    wrapperCauseMap()[CauseE1apProtocolUnspecified] =
        HEXA_REDCAP_SAACPF_CauseE1apProtocolUnspecified;
    wrapperCauseMap()[CauseE1apMiscControlProcessingOverload] =
        HEXA_REDCAP_SAACPF_CauseE1apMiscControlProcessingOverload;
    wrapperCauseMap()[CauseE1apMiscNotEnoughUserPlaneProcessingResources] =
        HEXA_REDCAP_SAACPF_CauseE1apMiscNotEnoughUserPlaneProcessingResources;
    wrapperCauseMap()[CauseE1apMiscHardwareFailure] =
        HEXA_REDCAP_SAACPF_CauseE1apMiscHardwareFailure;
    wrapperCauseMap()[CauseE1apMiscOMIntervention] =
        HEXA_REDCAP_SAACPF_CauseE1apMiscOMIntervention;
    wrapperCauseMap()[CauseE1apMiscUnspecified] =
        HEXA_REDCAP_SAACPF_CauseE1apMiscUnspecified;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUnspecified] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerUnspecified;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerTxnrelocoverallExpiry] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerTxnrelocoverallExpiry;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerSuccessfulHandover] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerSuccessfulHandover;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerReleaseDueToNgranGeneratedReason] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerReleaseDueToNgranGeneratedReason;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerReleaseDueTo5gcGeneratedReason] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerReleaseDueTo5gcGeneratedReason;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerHandoverCancelled] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerHandoverCancelled;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerPartialHandover] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerPartialHandover;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerHandoverFailureInTarget5gcNgranNodeOrTargetSystem] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerHandoverFailureInTarget5gcNgranNodeOrTargetSystem;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerHandoverTargetNotAllowed] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerHandoverTargetNotAllowed;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerTngrelocoverallExpiry] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerTngrelocoverallExpiry;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerTngrelocprepExpiry] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerTngrelocprepExpiry;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerCellNotavailable] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerCellNotavailable;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUnknownTargetID] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerUnknownTargetID;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerNoRadioResourcesAvailableInTargetCell] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerNoRadioResourcesAvailableInTargetCell;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUnknownLocalUeNgapID] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerUnknownLocalUeNgapID;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerInconsistentRemoteUeNgapID] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerInconsistentRemoteUeNgapID;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerHandoverDesirableForRadioReasons] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerHandoverDesirableForRadioReasons;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerTimeCriticalHandover] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerTimeCriticalHandover;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerResourceOptimisationHandover] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerResourceOptimisationHandover;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerReduceLoadInServingCell] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerReduceLoadInServingCell;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUserInactivity] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerUserInactivity;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerRadioConnectionWithUeLost] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerRadioConnectionWithUeLost;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerRadioResourcesNotAvailable] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerRadioResourcesNotAvailable;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerInvalidQosCombination] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerInvalidQosCombination;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerFailureInTheRadioInterfaceProcedure] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerFailureInTheRadioInterfaceProcedure;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerInteractionWithOtherProcedure] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerInteractionWithOtherProcedure;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUnknownPduSessionID] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerUnknownPduSessionID;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUnknownQosFlowID] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerUnknownQosFlowID;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerMultiplePduSessionIdInstances] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerMultiplePduSessionIdInstances;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerMultipleQosFlowIdInstances] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerMultipleQosFlowIdInstances;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerEncryptionAndOrIntegrityProtectionAlgorithmsNotSupported] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerEncryptionAndOrIntegrityProtectionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerNgIntraSystemHandoverTriggered] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerNgIntraSystemHandoverTriggered;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerNgInterSystemHandoverTriggered] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerNgInterSystemHandoverTriggered;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerXnHandoverTriggered] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerXnHandoverTriggered;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerNotSupported5qiValue] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerNotSupported5qiValue;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUeContextTransfer] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerUeContextTransfer;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerImsVoiceEpsFallbackOrRatFallbackTriggered] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerImsVoiceEpsFallbackOrRatFallbackTriggered;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUpIntegrityProtectionNotPossible] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerUpIntegrityProtectionNotPossible;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUpConfidentialityProtectionNotPossible] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerUpConfidentialityProtectionNotPossible;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerSliceNotSupported] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerSliceNotSupported;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUeInRrcInactiveStateNotReachable] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerUeInRrcInactiveStateNotReachable;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerRedirection] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerRedirection;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerResourcesNotAvailableForTheSlice] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerResourcesNotAvailableForTheSlice;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUeMaximumIntegrityProtectedDataRateReason] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerUeMaximumIntegrityProtectedDataRateReason;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerReleaseDueToCnDetectedMobility] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerReleaseDueToCnDetectedMobility;
    wrapperCauseMap()[CauseNgapTransportLayerTransportResourceUnavailable] =
        HEXA_REDCAP_SAACPF_CauseNgapTransportLayerTransportResourceUnavailable;
    wrapperCauseMap()[CauseNgapTransportLayerUnspecified] =
        HEXA_REDCAP_SAACPF_CauseNgapTransportLayerUnspecified;
    wrapperCauseMap()[CauseNgapNasNormalRelease] =
        HEXA_REDCAP_SAACPF_CauseNgapNasNormalRelease;
    wrapperCauseMap()[CauseNgapNasAuthenticationFailure] =
        HEXA_REDCAP_SAACPF_CauseNgapNasAuthenticationFailure;
    wrapperCauseMap()[CauseNgapNasDeregister] =
        HEXA_REDCAP_SAACPF_CauseNgapNasDeregister;
    wrapperCauseMap()[CauseNgapNasUnspecified] =
        HEXA_REDCAP_SAACPF_CauseNgapNasUnspecified;
    wrapperCauseMap()[CauseNgapProtocolTransferSyntaxError] =
        HEXA_REDCAP_SAACPF_CauseNgapProtocolTransferSyntaxError;
    wrapperCauseMap()[CauseNgapProtocolAbstractSyntaxErrorReject] =
        HEXA_REDCAP_SAACPF_CauseNgapProtocolAbstractSyntaxErrorReject;
    wrapperCauseMap()[CauseNgapProtocolAbstractSyntaxErrorIgnoreAndNotify] =
        HEXA_REDCAP_SAACPF_CauseNgapProtocolAbstractSyntaxErrorIgnoreAndNotify;
    wrapperCauseMap()[CauseNgapProtocolMessageNotCompatibleWithReceiverState] =
        HEXA_REDCAP_SAACPF_CauseNgapProtocolMessageNotCompatibleWithReceiverState;
    wrapperCauseMap()[CauseNgapProtocolSemanticError] =
        HEXA_REDCAP_SAACPF_CauseNgapProtocolSemanticError;
    wrapperCauseMap()[CauseNgapProtocolAbstractSyntaxErrorFalselyConstructedMessage] =
        HEXA_REDCAP_SAACPF_CauseNgapProtocolAbstractSyntaxErrorFalselyConstructedMessage;
    wrapperCauseMap()[CauseNgapProtocolUnspecified] =
        HEXA_REDCAP_SAACPF_CauseNgapProtocolUnspecified;
    wrapperCauseMap()[CauseNgapMiscControlProcessingOverload] =
        HEXA_REDCAP_SAACPF_CauseNgapMiscControlProcessingOverload;
    wrapperCauseMap()[CauseNgapMiscNotEnoughUserPlaneProcessingResources] =
        HEXA_REDCAP_SAACPF_CauseNgapMiscNotEnoughUserPlaneProcessingResources;
    wrapperCauseMap()[CauseNgapMiscHardwareFailure] =
        HEXA_REDCAP_SAACPF_CauseNgapMiscHardwareFailure;
    wrapperCauseMap()[CauseNgapMiscOMIntervention] =
        HEXA_REDCAP_SAACPF_CauseNgapMiscOMIntervention;
    wrapperCauseMap()[CauseNgapMiscUnknownPlmn] =
        HEXA_REDCAP_SAACPF_CauseNgapMiscUnknownPlmn;
    wrapperCauseMap()[CauseNgapMiscUnspecifiedFailure] =
        HEXA_REDCAP_SAACPF_CauseNgapMiscUnspecifiedFailure;
    wrapperCauseMap()[CauseCpInternalSaInvalidSecurityAlgorithm] =
        HEXA_REDCAP_SAACPF_CauseInternalInvalidSecurityAlgorithm;
    wrapperCauseMap()[CauseCpInternalSaSecurityModeFailure] =
        HEXA_REDCAP_SAACPF_CauseInternalSecurityModeFailure;
    wrapperCauseMap()[CauseCpInternalSaConfigNotExist] =
        HEXA_REDCAP_SAACPF_CauseInternalConfigNotExist;
    wrapperCauseMap()[CauseCpInternalSaRreTmOutNgPathSwitchRequest] =
        HEXA_REDCAP_SAACPF_CauseInternalRreTmOutNgPathSwitchRequest;
    wrapperCauseMap()[CauseCpInternalSaRreTmOutXnSNStatusTransfer] =
        HEXA_REDCAP_SAACPF_CauseInternalRreTmOutXnSNStatusTransfer;
    wrapperCauseMap()[CauseCpInternalSaRreTmOutXnRelocOverall] =
        HEXA_REDCAP_SAACPF_CauseInternalRreTmOutXnRelocOverall;
    wrapperCauseMap()[CauseCpInternalSaRreProcedureNotAvailable] =
        HEXA_REDCAP_SAACPF_CauseInternalRreProcedureNotAvailable;
    wrapperCauseMap()[CauseF1apRadioAmfInitiatedAbnormalRelease] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioAmfInitiatedAbnormalRelease;
    wrapperCauseMap()[CauseF1apRadioReleaseDueToPreEmption] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioReleaseDueToPreEmption;
    wrapperCauseMap()[CauseF1apRadioPlmnNotServedByTheGnbCu] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioPlmnNotServedByTheGnbCu;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUeDlMaxIPDataRateReason] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerUeDlMaxIPDataRateReason;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUpIntegrityProtectionFailure] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerUpIntegrityProtectionFailure;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerReleaseDueToPreEmption] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerReleaseDueToPreEmption;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerN26InterfaceNotAvailable] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerN26InterfaceNotAvailable;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerReleaseDueToPreEmption] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerReleaseDueToPreEmption;
    wrapperCauseMap()[CauseCpInternalSaUeCapaNotSupported] =
        HEXA_REDCAP_SAACPF_CauseInternalUeCapaNotSupported;
    wrapperCauseMap()[CauseCpInternalSaRrcInactiveRelease] =
        HEXA_REDCAP_SAACPF_CauseInternalRrcInactiveRelease;
    wrapperCauseMap()[CauseCpInternalSaResumeMacIMismatch] =
        HEXA_REDCAP_SAACPF_CauseInternalResumeMacIMismatch;
    wrapperCauseMap()[CauseCpInternalSaTmOutPaging] =
        HEXA_REDCAP_SAACPF_CauseInternalTmOutPaging;
    wrapperCauseMap()[CauseCpInternalSaTmOutRrcResume] =
        HEXA_REDCAP_SAACPF_CauseInternalTmOutRrcResume;
    wrapperCauseMap()[CauseCpInternalSaTmOutPeriodicRNAU] =
        HEXA_REDCAP_SAACPF_CauseInternalTmOutPeriodicRNAU;
    wrapperCauseMap()[CauseCpInternalSaResumeOldCallRelease] =
        HEXA_REDCAP_SAACPF_CauseInternalResumeOldCallRelease;
    wrapperCauseMap()[CauseCpInternalSaResumeOldCallReleaseSourceFail] =
        HEXA_REDCAP_SAACPF_CauseInternalResumeOldCallReleaseSourceFail;
    wrapperCauseMap()[CauseCpInternalSaResumeTmOutNgPathSwitchRequest] =
        HEXA_REDCAP_SAACPF_CauseInternalResumeTmOutNgPathSwitchRequest;
    wrapperCauseMap()[CauseCpInternalSaResumeTmOutXnRelocOverall] =
        HEXA_REDCAP_SAACPF_CauseInternalResumeTmOutXnRelocOverall;
    wrapperCauseMap()[CauseCpInternalSaResumeProcedureNotAvailable] =
        HEXA_REDCAP_SAACPF_CauseInternalResumeProcedureNotAvailable;
    wrapperCauseMap()[CauseF1apRadioMultipleDrbIdInstances] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioMultipleDrbIdInstances;
    wrapperCauseMap()[CauseF1apRadioUnknownDrbId] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioUnknownDrbId;
    wrapperCauseMap()[CauseF1apRadioMultipleBhRlcChIdInstances] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioMultipleBhRlcChIdInstances;
    wrapperCauseMap()[CauseF1apRadioUnknownBhRlcChId] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioUnknownBhRlcChId;
    wrapperCauseMap()[CauseF1apRadioChoCpcResourcesToBeChanged] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioChoCpcResourcesToBeChanged;
    wrapperCauseMap()[CauseF1apRadioNpnNotSupported] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioNpnNotSupported;
    wrapperCauseMap()[CauseF1apRadioNpnAccessDenied] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioNpnAccessDenied;
    wrapperCauseMap()[CauseF1apRadioGnbCuCellCapacityExceeded] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioGnbCuCellCapacityExceeded;
    wrapperCauseMap()[CauseF1apRadioReportCharacteristicsEmpty] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioReportCharacteristicsEmpty;
    wrapperCauseMap()[CauseF1apRadioExistingMeasurementID] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioExistingMeasurementID;
    wrapperCauseMap()[CauseF1apRadioMeasurementTemporarilyNotAvailable] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioMeasurementTemporarilyNotAvailable;
    wrapperCauseMap()[CauseF1apRadioMeasurementNotSupportedForTheObject] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioMeasurementNotSupportedForTheObject;
    wrapperCauseMap()[CauseF1apRadioUnknownBAPAddress] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioUnknownBAPAddress;
    wrapperCauseMap()[CauseF1apRadioUnknownBAPRoutingID] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioUnknownBAPRoutingID;
    wrapperCauseMap()[CauseF1apRadioInsufficientUeCapabilities] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioInsufficientUeCapabilities;
    wrapperCauseMap()[CauseF1apTransportUnknownTNLAddressForIAB] =
        HEXA_REDCAP_SAACPF_CauseF1apTransportUnknownTNLAddressForIAB;
    wrapperCauseMap()[CauseF1apTransportUnknownUPTNLInformationForIAB] =
        HEXA_REDCAP_SAACPF_CauseF1apTransportUnknownUPTNLInformationForIAB;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerRSNNotAvailableForTheUP] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerRSNNotAvailableForTheUP;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNPNNotSupported] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerNPNNotSupported;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerReportCharacteristicsEmpty] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerReportCharacteristicsEmpty;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerExistingMeasurementID] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerExistingMeasurementID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMeasurementTemporarilyNotAvailable] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerMeasurementTemporarilyNotAvailable;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMeasurementNotSupportedForTheObject] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerMeasurementNotSupportedForTheObject;
    wrapperCauseMap()[CauseE1apTransportLayerUnknownTNLAddressForIAB] =
        HEXA_REDCAP_SAACPF_CauseE1apTransportLayerUnknownTNLAddressForIAB;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerMultipleLocationReportingReferenceIDInstances] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerMultipleLocationReportingReferenceIDInstances;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerRSNNotAvailableForTheUP] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerRSNNotAvailableForTheUP;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerNPNAccessDenied] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerNPNAccessDenied;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerCAGOnlyAccessDenied] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerCAGOnlyAccessDenied;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerCellNotAvailable] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerCellNotAvailable;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerHandoverDesirableForRadioReasons] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerHandoverDesirableForRadioReasons;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerHandoverTargetNotAllowed] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerHandoverTargetNotAllowed;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerInvalidAmfSetId] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerInvalidAmfSetId;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNoRadioResourcesAvailableInTargetCell] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerNoRadioResourcesAvailableInTargetCell;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerPartialHandover] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerPartialHandover;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerReduceLoadInServingCell] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerReduceLoadInServingCell;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerResourceOptimisationHandover] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerResourceOptimisationHandover;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTimeCriticalHandover] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerTimeCriticalHandover;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTxnRelocOverallExpiry] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerTxnRelocOverallExpiry;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTxnRelocPrepExpiry] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerTxnRelocPrepExpiry;
    wrapperCauseMap()[CauseCpInternalCpSrbIntegrityFailure] =
        HEXA_REDCAP_SAACPF_CauseInternalCpSrbIntegrityFailure;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnknownGuamiId] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerUnknownGuamiId;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnknownLocalNgranNodeUeXnapId] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerUnknownLocalNgranNodeUeXnapId;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerInconsistentRemoteNgranNodeUeXnapId] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerInconsistentRemoteNgranNodeUeXnapId;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerEncryptionAndOrIntegrityProtectionAlgorithmsNotSupported] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerEncryptionAndOrIntegrityProtectionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerProtectionAlgorithmsNotSupported] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerProtectionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMultiplePduSessionIdInstances] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerMultiplePduSessionIdInstances;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnknownPduSessionId] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerUnknownPduSessionId;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnknownQosFlowId] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerUnknownQosFlowId;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMultipleQosFlowIdInstances] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerMultipleQosFlowIdInstances;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerSwitchOffOngoing] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerSwitchOffOngoing;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNotSupported5qiValue] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerNotSupported5qiValue;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTxnDcOverallExpiry] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerTxnDcOverallExpiry;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTxnDcPrepExpiry] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerTxnDcPrepExpiry;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerActionDesirableForRadioReasons] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerActionDesirableForRadioReasons;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerReduceLoad] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerReduceLoad;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerResourceOptimisation] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerResourceOptimisation;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTimeCriticalAction] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerTimeCriticalAction;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTargetNotAllowed] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerTargetNotAllowed;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNoRadioResourcesAvailable] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerNoRadioResourcesAvailable;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerInvalidQosCombination] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerInvalidQosCombination;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerEncryptionAlgorithmsNotSupported] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerEncryptionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerProcedureCancelled] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerProcedureCancelled;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerRrmPurpose] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerRrmPurpose;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerImproveUserBitRate] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerImproveUserBitRate;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUserInactivity] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerUserInactivity;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerRadioConnectionWithUeLost] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerRadioConnectionWithUeLost;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerFailureInTheRadioInterfaceProcedure] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerFailureInTheRadioInterfaceProcedure;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerBearerOptionNotSupported] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerBearerOptionNotSupported;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUpIntegrityProtectionNotPossible] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerUpIntegrityProtectionNotPossible;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUpConfidentialityProtectionNotPossible] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerUpConfidentialityProtectionNotPossible;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerResourcesNotAvailableForTheSlice] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerResourcesNotAvailableForTheSlice;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUeMaximumIntegrityProtectedDataRateReason] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerUeMaximumIntegrityProtectedDataRateReason;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerCpIntegrityProtectionFailure] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerCpIntegrityProtectionFailure;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUpIntegrityProtectionFailure] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerUpIntegrityProtectionFailure;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerSlicesNotSupportedByNgran] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerSlicesNotSupportedByNgran;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMnMobility] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerMnMobility;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerSnMobility] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerSnMobility;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerCountReachesMaxValue] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerCountReachesMaxValue;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnknownOldNgranNodeUeXnapId] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerUnknownOldNgranNodeUeXnapId;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerPdcpOverload] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerPdcpOverload;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerDrbIdNotAvailable] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerDrbIdNotAvailable;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnspecified] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerUnspecified;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUeContextIdNotKnown] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerUeContextIdNotKnown;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNonRelocationOfContext] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerNonRelocationOfContext;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerCHOCPCResourcesToBeChanged] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerCHOCPCResourcesToBeChanged;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerRSNNotAvailableForTheUP] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerRSNNotAvailableForTheUP;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNPNAccessDenied] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerNPNAccessDenied;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerReportCharacteristicsEmpty] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerReportCharacteristicsEmpty;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerExistingMeasurementID] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerExistingMeasurementID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMeasurementTemporarilyNotAvailable] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerMeasurementTemporarilyNotAvailable;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMeasurementNotSupportedForTheObject] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerMeasurementNotSupportedForTheObject;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUEPowerSaving] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerUEPowerSaving;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNotExistingNGRANNode2MeasurementID] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerNotExistingNGRANNode2MeasurementID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerInsufficientUECapabilities] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerInsufficientUECapabilities;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNormalRelease] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerNormalRelease;
    wrapperCauseMap()[CauseXnapTransportLayerTransportResourceUnavailable] =
        HEXA_REDCAP_SAACPF_CauseXnapTransportLayerTransportResourceUnavailable;
    wrapperCauseMap()[CauseXnapTransportLayerUnspecified] =
        HEXA_REDCAP_SAACPF_CauseXnapTransportLayerUnspecified;
    wrapperCauseMap()[CauseXnapProtocolTransferSyntaxError] =
        HEXA_REDCAP_SAACPF_CauseXnapProtocolTransferSyntaxError;
    wrapperCauseMap()[CauseXnapProtocolAbstractSyntaxErrorReject] =
        HEXA_REDCAP_SAACPF_CauseXnapProtocolAbstractSyntaxErrorReject;
    wrapperCauseMap()[CauseXnapProtocolAbstractSyntaxErrorIgnoreAndNotify] =
        HEXA_REDCAP_SAACPF_CauseXnapProtocolAbstractSyntaxErrorIgnoreAndNotify;
    wrapperCauseMap()[CauseXnapProtocolMessageNotCompatibleWithReceiverState] =
        HEXA_REDCAP_SAACPF_CauseXnapProtocolMessageNotCompatibleWithReceiverState;
    wrapperCauseMap()[CauseXnapProtocolSemanticError] =
        HEXA_REDCAP_SAACPF_CauseXnapProtocolSemanticError;
    wrapperCauseMap()[CauseXnapProtocolAbstractSyntaxErrorFalselyConstructedMessage] =
        HEXA_REDCAP_SAACPF_CauseXnapProtocolAbstractSyntaxErrorFalselyConstructedMessage;
    wrapperCauseMap()[CauseXnapProtocolUnspecified] =
        HEXA_REDCAP_SAACPF_CauseXnapProtocolUnspecified;
    wrapperCauseMap()[CauseXnapMiscControlProcessingOverload] =
        HEXA_REDCAP_SAACPF_CauseXnapMiscControlProcessingOverload;
    wrapperCauseMap()[CauseXnapMiscHardwareFailure] =
        HEXA_REDCAP_SAACPF_CauseXnapMiscHardwareFailure;
    wrapperCauseMap()[CauseXnapMiscOMIntervention] =
        HEXA_REDCAP_SAACPF_CauseXnapMiscOMIntervention;
    wrapperCauseMap()[CauseXnapMiscNotEnoughUserPlaneProcessingResources] =
        HEXA_REDCAP_SAACPF_CauseXnapMiscNotEnoughUserPlaneProcessingResources;
    wrapperCauseMap()[CauseXnapMiscUnspecified] =
        HEXA_REDCAP_SAACPF_CauseXnapMiscUnspecified;
    wrapperCauseMap()[CauseCpInternalSaUeAssistanceInformation] =
        HEXA_REDCAP_SAACPF_CauseInternalUeAssistanceInformation;
    wrapperCauseMap()[CauseCpInternalSaInvalidAMFName] =
        HEXA_REDCAP_SAACPF_CauseInternalInvalidAMFName;
    wrapperCauseMap()[CauseF1apRadioScgActivationDeactivationFailure] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioScgActivationDeactivationFailure;
    wrapperCauseMap()[CauseF1apRadioScgDeactivationFailureDueToDataTransmission] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioScgDeactivationFailureDueToDataTransmission;
    wrapperCauseMap()[CauseF1apRadioRequestedItemNotSupportedOnTime] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioRequestedItemNotSupportedOnTime;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedGnbCuMbsF1apId] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioUnknownOrAlreadyAllocatedGnbCuMbsF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedGnbDuMbsF1apId] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioUnknownOrAlreadyAllocatedGnbDuMbsF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownOrInconsistentPairOfMbsF1apId] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioUnknownOrInconsistentPairOfMbsF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownOrInconsistentMrbId] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioUnknownOrInconsistentMrbId;
    wrapperCauseMap()[CauseF1apRadioTatSdtExpiry] =
        HEXA_REDCAP_SAACPF_CauseF1apRadioTatSdtExpiry;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerScgActivationDeactivationFailure] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerScgActivationDeactivationFailure;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerScgDeactivationFailureDueToDataTransmission] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerScgDeactivationFailureDueToDataTransmission;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpMbsE1apId] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpMbsE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpMbsE1apId] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpMbsE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfMbsE1apId] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfMbsE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrInconsistentMrbId] =
        HEXA_REDCAP_SAACPF_CauseE1apRadioNetworkLayerUnknownOrInconsistentMrbId;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerInsufficientUeCapabilities] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerInsufficientUeCapabilities;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerRedcapUeNotSupported] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerRedCapUeNotSupported;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUnknownMBSSessionID] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerUnknownMbsSessionId;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerIndicatedMBSSessionAreaInformationNotServedByTheGNB] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerIndicatedMbsSessionAreaInformationNotServedByTheGnb;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerInconsistentSliceInfoForTheSession] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerInconsistentSliceInfoForTheSession;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerMisalignedAssociationForMulticastUnicast] =
        HEXA_REDCAP_SAACPF_CauseNgapRadioNetworkLayerMisalignedAssociationForTheMulticastAndUnicastSessionsOrFlows;
    wrapperCauseMap()[CauseNgapNasUeNotInPlmnServingArea] =
        HEXA_REDCAP_SAACPF_CauseNgapNasUeNotInPlmnServingArea;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerScgActivationDeactivationFailure] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerScgActivationDeactivationFailure;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerScgDeactivationFailureDueToDataTransmission] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerScgDeactivationFailureDueToDataTransmission;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerValueOutOfAllowedRange] =
        HEXA_REDCAP_SAACPF_CauseXnapRadioNetworkLayerValueOutOfAllowedRange;

    if ((STAT_SA_REDCAP_CUCPCSL_HEXA_END + STAT_SA_REDCAP_CUCPCSL_HEXA_2_END) == wrapperCauseMap().size())
        return NR_CSL_CAUSE_ERROR_NONE;
    else
        return NR_CSL_CAUSE_ERROR_VALIDATION_FAILED;
}

nr_csl_cause_error_e nr_csl_redcap_hex_cause_get_cp_pmCause(const cause_t cause, pmCause_t* pmCause)
{
    if (wrapperCauseMap().find(cause) == wrapperCauseMap().end())
    {
        return NR_CSL_CAUSE_ERROR_VALIDATION_FAILED;
    }

    if (NULL == pmCause)
    {
        return NR_CSL_CAUSE_ERROR_INVALID_PARAMETER;
    }

    *pmCause = wrapperCauseMap()[cause];
    return NR_CSL_CAUSE_ERROR_NONE;
}
