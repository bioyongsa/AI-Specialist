#include "ComStatisticMapper.hpp"
#include "ComContainers.hpp"
#include "PM_TYPE_ID.h"

static const auto& CpFailMap = makeMap<enumStatEndcAddDetailedCpFail_type, int>(
{
    {StatEndcAddPrepCpFail_CallAllocFailVnmb_OOS, EndcAddPrepFail_CpFail_CallAllocFailVnmb},
    {StatEndcAddPrepCpFail_CallAllocFailVnmb_CAC, EndcAddPrepFail_CpFail_CallAllocFailVnmb},
    {StatEndcAddPrepCpFail_CallAllocFailVnmb_CallIdAllocFail, EndcAddPrepFail_CpFail_CallAllocFailVnmb},
    {StatEndcAddPrepCpFail_CallAllocFailVccb_ThreadIdMismatch, EndcAddPrepFail_CpFail_CallAllocFailVccb},
    {StatEndcAddPrepCpFail_CallAllocFailVccb_DuplicatedCall, EndcAddPrepFail_CpFail_CallAllocFailVccb},
    {StatEndcAddPrepCpFail_CallAllocFailVnmb_Overload, EndcAddPrepFail_CpFail_CpOverload},
    {StatEndcAddPrepCpFail_SpCellSelFail, EndcAddPrepFail_CpFail_SpCellSelFailure},
    {StatEndcAddPrepCpFail_UpSelectionFail_NoCandidates, EndcAddPrepFail_CpFail_UpSelectionFail},
    {StatEndcAddPrepCpFail_ErabConfigurationFail, EndcAddPrepFail_CpFail_ErabConfigurationFail},
    {StatEndcAddPrepCpFail_RxX2SgNBAdditionRequestError_BearerTypeNotSup, EndcAddPrepFail_CpFail_RxX2SgNBAdditionRequestFail},
    {StatEndcAddPrepCpFail_RxX2SgNBAdditionRequestError_Other, EndcAddPrepFail_CpFail_RxX2SgNBAdditionRequestFail},
    {StatEndcAddPrepCpFail_RxE1BearerContextSetupResponseFail, EndcAddPrepFail_CpFail_RxE1BearerContextSetupResponseFail},
    {StatEndcAddPrepCpFail_RxF1UEContextSetupResponseFail, EndcAddPrepFail_CpFail_RxF1UEContextSetupResponseFail},
    {StatEndcAddPrepCpFail_RxE1BearerContextModificationResponseFail, EndcAddPrepFail_CpFail_RxE1BearerContextModificationResponseFail},
    {StatEndcAddPrepCpFail_TxE1BearerContextSetupRequestFail, EndcAddPrepFail_CpFail_TxE1BearerContextSetupRequestFail},
    {StatEndcAddPrepCpFail_TxF1UEContextSetupRequestFail, EndcAddPrepFail_CpFail_TxF1UEContextSetupRequestFail},
    {StatEndcAddPrepCpFail_TxE1BearerContextModificationRequestFail, EndcAddPrepFail_CpFail_TxE1BearerContextModificationRequestFail},
    {StatEndcAddPrepCpFail_TxX2SgNBAdditionRequestAckFail, EndcAddPrepFail_CpFail_TxX2SgNBAdditionRequestAcknowledgeFail},
    {StatEndcAddPrepCpFail_OtherVendor, EndcAddPrepFail_CpFail_OtherVendor},
    {StatEndcAddPrepCpFail_Unspecified, EndcAddPrepFail_CpFail_Unspecified},
    {StatEndcAddCpFail_RxF1UEContextModificationResponseFail, EndcAddFail_CpFail_RxF1UEContextModificationResponseFail},
    {StatEndcAddCpFail_RxE1BearerContextModificationResponseFail, EndcAddFail_CpFail_RxE1BearerContextModificationResponseFail},
    {StatEndcAddCpFail_TxF1UEContextModificationRequestFail, EndcAddFail_CpFail_TxF1UEContextModificationRequestFail},
    {StatEndcAddCpFail_TxE1BearerContextModificationRequestFail, EndcAddFail_CpFail_TxE1BearerContextModificationRequestFail},
    {StatEndcAddCpFail_Unspecified, EndcAddFail_CpFail_Unspecified}
});

static const auto& SpCellSelFailPerCandidateMap = makeMap<enumStatSpCellSelectionFailCause_type, int>(
{
    {StatEndcSpCellSelFail_Nrcgi_GnbIdMismatch, EndcAddPrepFail_CpFail_SpCellSel_NrcgiNoCellSelectable_perCandidate},
    {StatEndcSpCellSelFail_Nrcgi_CellNumNotFound, EndcAddPrepFail_CpFail_SpCellSel_NrcgiNoCellSelectable_perCandidate},
    {StatEndcSpCellSelFail_Nrcgi_PciMismatch, EndcAddPrepFail_CpFail_SpCellSel_NrcgiNoCellSelectable_perCandidate},
    {StatEndcSpCellSelFail_Nrcgi_ssbFreqMismatch, EndcAddPrepFail_CpFail_SpCellSel_NrcgiNoCellSelectable_perCandidate},
    {StatEndcSpCellSelFail_Nrcgi_CellOosOrBarred, EndcAddPrepFail_CpFail_SpCellSel_NrcgiOos_perCandidate},
    {StatEndcSpCellSelFail_Nrcgi_MibCellBarred, EndcAddPrepFail_CpFail_SpCellSel_NrcgiOos_perCandidate},
    {StatEndcSpCellSelFail_ULInterfered, EndcAddPrepFail_CpFail_SpCellSel_UlInterference_perCandidate},
    {StatEndcSpCellSelFail_nonNrcgi_PciSelectionNotAllowed, EndcAddPrepFail_CpFail_SpCellSel_NonNrcgiNotAllowed_perCandidate},
    {StatEndcSpCellSelFail_nonNrcgi_PciNotInCandidateListInfo, EndcAddPrepFail_CpFail_SpCellSel_NonNrcgiNoCellSelectable_perCandidate},
    {StatEndcSpCellSelFail_nonNrcgi_PciAndSsbFeqNoAvailable, EndcAddPrepFail_CpFail_SpCellSel_NonNrcgiNoCellSelectable_perCandidate},
    {StatEndcSpCellSelFail_nonNrcgi_CellOosOrBarred, EndcAddPrepFail_CpFail_SpCellSel_NonNrcgiOos_perCandidate},
    {StatEndcSpCellSelFail_nonNrcgi_MibCellBarred, EndcAddPrepFail_CpFail_SpCellSel_NonNrcgiOos_perCandidate},
    {StatEndcSpCellSelFail_nonNrcgi_SamePciAndSsbFeqInMoreCells, EndcAddPrepFail_CpFail_SpCellSel_NonNrcgiDupPci_perCandidate},
    {StatEndcSpCellSelFail_UeNotSupCellFreqBand, EndcAddPrepFail_CpFail_SpCellSel_UeNotSupCellFreqBand_perCandidate},
    {StatEndcSpCellSelFail_UeNotSupBandCombination, EndcAddPrepFail_CpFail_SpCellSel_UeNotSupCellFreqBand_perCandidate},
    {StatEndcSpCellSelFail_SsbRestricted, EndcAddPrepFail_CpFail_SpCellSel_UeNotSupCellFreqBand_perCandidate},
    {StatEndcSpCellSelFail_UeNotSupChannelBw, EndcAddPrepFail_CpFail_SpCellSel_UeNotSupChannelBw_perCandidate},
    {StatEndcSpCellSelFail_UeNotSup90MhzBw, EndcAddPrepFail_CpFail_SpCellSel_UeNotSup90MhzBw_perCandidate},
    {StatEndcSpCellSelFail_MrBasedUeNotSupLteNrIntraBandRelation, EndcAddPrepFail_CpFail_SpCellSel_NoNsaCellSelectable_perCandidate},
    {StatEndcSpCellSelFail_NotSsbCell, EndcAddPrepFail_CpFail_SpCellSel_NoNsaCellSelectable_perCandidate},
    {StatEndcSpCellSelFail_DssUeNotSupRateMatchingLteCrs, EndcAddPrepFail_CpFail_SpCellSel_NoNsaCellSelectable_perCandidate},
    {StatEndcSpCellSelFail_NrSdlCell, EndcAddPrepFail_CpFail_SpCellSel_NoNsaCellSelectable_perCandidate},
    {StatEndcSpCellSelFail_MrlNotSatisfied, EndcAddPrepFail_CpFail_SpCellSel_NoNsaCellSelectable_perCandidate},
    {StatEndcSpCellSelFail_NoHoBtwSaAndNsaCell, EndcAddPrepFail_CpFail_SpCellSel_NoNsaCellSelectable_perCandidate},
    {StatEndcSpCellSelFail_DuOverload, EndcAddPrepFail_CpFail_SpCellSel_DuOverload_perCandidate},
    {StatEndcSpCellSelFail_Spid_SsbFreqNotInCandidateInfoList, EndcAddPrepFail_CpFail_SpCellSel_SpidNoCellSelectable_perCandidate},
    {StatEndcSpCellSelFail_Spid_PlmnInHrlNotSupported, EndcAddPrepFail_CpFail_SpCellSel_SpidNoCellSelectable_perCandidate},
    {StatEndcSpCellSelFail_Spid_PlmnSpidSsbFreqNotConfigured, EndcAddPrepFail_CpFail_SpCellSel_SpidNoCellSelectable_perCandidate},
    {StatEndcSpCellSelFail_Spid_PlmnSpidOutOfRange, EndcAddPrepFail_CpFail_SpCellSel_SpidNoCellSelectable_perCandidate},
    {StatEndcSpCellSelFail_EnergySaving, EndcAddPrepFail_CpFail_SpCellSel_EnergySaving_perCandidate},
});

static const auto& SpCellSelFailPerCandidateIndexMap = makeMap<int, int>({
    {EndcAddPrepFail_CpFail_SpCellSel_NrcgiNoCellSelectable_perCandidate, 0},
    {EndcAddPrepFail_CpFail_SpCellSel_NrcgiOos_perCandidate, 1},
    {EndcAddPrepFail_CpFail_SpCellSel_UlInterference_perCandidate, 2},
    {EndcAddPrepFail_CpFail_SpCellSel_NonNrcgiNotAllowed_perCandidate, 3},
    {EndcAddPrepFail_CpFail_SpCellSel_NonNrcgiNoCellSelectable_perCandidate, 4},
    {EndcAddPrepFail_CpFail_SpCellSel_NonNrcgiOos_perCandidate, 5},
    {EndcAddPrepFail_CpFail_SpCellSel_NonNrcgiDupPci_perCandidate, 6},
    {EndcAddPrepFail_CpFail_SpCellSel_UeNotSupCellFreqBand_perCandidate, 7},
    {EndcAddPrepFail_CpFail_SpCellSel_UeNotSupChannelBw_perCandidate, 8},
    {EndcAddPrepFail_CpFail_SpCellSel_UeNotSup90MhzBw_perCandidate, 9},
    {EndcAddPrepFail_CpFail_SpCellSel_NoNsaCellSelectable_perCandidate, 10},
    {EndcAddPrepFail_CpFail_SpCellSel_DuOverload_perCandidate, 11},
    {EndcAddPrepFail_CpFail_SpCellSel_SpidNoCellSelectable_perCandidate, 12},
    {EndcAddPrepFail_CpFail_SpCellSel_EnergySaving_perCandidate, 13},
    {EndcAddPrepFail_CpFail_SpCellSel_Unspecified_perCandidate, 14},
});

static const auto& SpCellSelFailPerCandidateIndexReverseMap = makeMap<int, int>({
    {0, EndcAddPrepFail_CpFail_SpCellSel_NrcgiNoCellSelectable_perCandidate},
    {1, EndcAddPrepFail_CpFail_SpCellSel_NrcgiOos_perCandidate},
    {2, EndcAddPrepFail_CpFail_SpCellSel_UlInterference_perCandidate},
    {3, EndcAddPrepFail_CpFail_SpCellSel_NonNrcgiNotAllowed_perCandidate},
    {4, EndcAddPrepFail_CpFail_SpCellSel_NonNrcgiNoCellSelectable_perCandidate},
    {5, EndcAddPrepFail_CpFail_SpCellSel_NonNrcgiOos_perCandidate},
    {6, EndcAddPrepFail_CpFail_SpCellSel_NonNrcgiDupPci_perCandidate},
    {7, EndcAddPrepFail_CpFail_SpCellSel_UeNotSupCellFreqBand_perCandidate},
    {8, EndcAddPrepFail_CpFail_SpCellSel_UeNotSupChannelBw_perCandidate},
    {9, EndcAddPrepFail_CpFail_SpCellSel_UeNotSup90MhzBw_perCandidate},
    {10, EndcAddPrepFail_CpFail_SpCellSel_NoNsaCellSelectable_perCandidate},
    {11, EndcAddPrepFail_CpFail_SpCellSel_DuOverload_perCandidate},
    {12, EndcAddPrepFail_CpFail_SpCellSel_SpidNoCellSelectable_perCandidate},
    {13, EndcAddPrepFail_CpFail_SpCellSel_EnergySaving_perCandidate},
    {14, EndcAddPrepFail_CpFail_SpCellSel_Unspecified_perCandidate},
});

static const auto& SpCellSelFailMap = makeMap<enumStatSpCellSelectionFailCause_type, int>(
{
    {StatEndcSpCellSelFail_Nrcgi_GnbIdMismatch, EndcAddPrepFail_CpFail_SpCellSel_NrcgiNoCellSelectable},
    {StatEndcSpCellSelFail_Nrcgi_CellNumNotFound, EndcAddPrepFail_CpFail_SpCellSel_NrcgiNoCellSelectable},
    {StatEndcSpCellSelFail_Nrcgi_PciMismatch, EndcAddPrepFail_CpFail_SpCellSel_NrcgiNoCellSelectable},
    {StatEndcSpCellSelFail_Nrcgi_ssbFreqMismatch, EndcAddPrepFail_CpFail_SpCellSel_NrcgiNoCellSelectable},
    {StatEndcSpCellSelFail_ULInterfered, EndcAddPrepFail_CpFail_SpCellSel_UlInterference},
    {StatEndcSpCellSelFail_nonNrcgi_PciSelectionNotAllowed, EndcAddPrepFail_CpFail_SpCellSel_NonNrcgiNotAllowed},
    {StatEndcSpCellSelFail_nonNrcgi_PciNotInCandidateListInfo, EndcAddPrepFail_CpFail_SpCellSel_NonNrcgiNoCellSelectable},
    {StatEndcSpCellSelFail_nonNrcgi_PciAndSsbFeqNoAvailable, EndcAddPrepFail_CpFail_SpCellSel_NonNrcgiNoCellSelectable},
    {StatEndcSpCellSelFail_UeNotSupCellFreqBand, EndcAddPrepFail_CpFail_SpCellSel_UeNotSupCellFreqBand},
    {StatEndcSpCellSelFail_UeNotSupBandCombination, EndcAddPrepFail_CpFail_SpCellSel_UeNotSupCellFreqBand},
    {StatEndcSpCellSelFail_SsbRestricted, EndcAddPrepFail_CpFail_SpCellSel_UeNotSupCellFreqBand},
    {StatEndcSpCellSelFail_UeNotSupChannelBw, EndcAddPrepFail_CpFail_SpCellSel_UeNotSupChannelBw},
    {StatEndcSpCellSelFail_UeNotSup90MhzBw, EndcAddPrepFail_CpFail_SpCellSel_UeNotSup90MhzBw},
    {StatEndcSpCellSelFail_MrBasedUeNotSupLteNrIntraBandRelation, EndcAddPrepFail_CpFail_SpCellSel_NoNsaCellSelectable},
    {StatEndcSpCellSelFail_NotSsbCell, EndcAddPrepFail_CpFail_SpCellSel_NoNsaCellSelectable},
    {StatEndcSpCellSelFail_DssUeNotSupRateMatchingLteCrs, EndcAddPrepFail_CpFail_SpCellSel_NoNsaCellSelectable},
    {StatEndcSpCellSelFail_NrSdlCell, EndcAddPrepFail_CpFail_SpCellSel_NoNsaCellSelectable},
    {StatEndcSpCellSelFail_MrlNotSatisfied, EndcAddPrepFail_CpFail_SpCellSel_NoNsaCellSelectable},
    {StatEndcSpCellSelFail_NoHoBtwSaAndNsaCell, EndcAddPrepFail_CpFail_SpCellSel_NoNsaCellSelectable},
    {StatEndcSpCellSelFail_DuOverload, EndcAddPrepFail_CpFail_SpCellSel_DuOverload},
});

static const auto& SpCellSelFailPriorityMap = makeMap<int, int>(
{
    {EndcAddPrepFail_CpFail_SpCellSel_UeNotSupCellFreqBand, 1},
    {EndcAddPrepFail_CpFail_SpCellSel_UeNotSupChannelBw, 2},
    {EndcAddPrepFail_CpFail_SpCellSel_UeNotSup90MhzBw, 3},
    {EndcAddPrepFail_CpFail_SpCellSel_UlInterference, 4},
    {EndcAddPrepFail_CpFail_SpCellSel_NrcgiNoCellSelectable, 5},
    {EndcAddPrepFail_CpFail_SpCellSel_NonNrcgiNoCellSelectable, 6},
    {EndcAddPrepFail_CpFail_SpCellSel_NoNsaCellSelectable, 7},
    {EndcAddPrepFail_CpFail_SpCellSel_NonNrcgiNotAllowed, 8},
    {EndcAddPrepFail_CpFail_SpCellSel_DuOverload, 9},
});

static const auto& InvalidCellMap = makeMap<enumStatSpCellSelectionFailCause_type, int>(
{
    {StatEndcSpCellSelFail_UeNotSupCellFreqBand, InvalidCellCauseUENotSupFreqBand},
    {StatEndcSpCellSelFail_UeNotSupBandCombination, InvalidCellCauseUENotSupFreqBand},
    {StatEndcSpCellSelFail_SsbRestricted, InvalidCellCauseUENotSupFreqBand},
    {StatEndcSpCellSelFail_Spid_SsbFreqNotInCandidateInfoList, InvalidCellCauseSpid},
    {StatEndcSpCellSelFail_Spid_PlmnInHrlNotSupported, InvalidCellCauseSpid},
    {StatEndcSpCellSelFail_Spid_PlmnSpidSsbFreqNotConfigured, InvalidCellCauseSpid},
    {StatEndcSpCellSelFail_Spid_PlmnSpidOutOfRange, InvalidCellCauseSpid}
});

std::optional<int> getValueCpFailMap(enumStatEndcAddDetailedCpFail_type enumStatEndcAddDetailedCpFail)
{
    return CpFailMap.getValue(enumStatEndcAddDetailedCpFail);
};
std::optional<int> getValueSpCellSelFailPerCandidateMap(enumStatSpCellSelectionFailCause_type enumStatSpCellSelectionFailCause)
{
    return SpCellSelFailPerCandidateMap.getValue(enumStatSpCellSelectionFailCause);
};
std::optional<int> getValueSpCellSelFailMap(enumStatSpCellSelectionFailCause_type enumStatSpCellSelectionFailCause)
{
    return SpCellSelFailMap.getValue(enumStatSpCellSelectionFailCause);
};
std::optional<int> getValueInvalidCellMap(enumStatSpCellSelectionFailCause_type enumStatSpCellSelectionFailCause)
{
    return InvalidCellMap.getValue(enumStatSpCellSelectionFailCause);
};
std::optional<int> getValueSpCellSelFailPriorityMap(int typeId)
{
    return SpCellSelFailPriorityMap.getValue(typeId);
};
std::optional<int> getValueSpCellSelFailPerCandidateIndexMap(int typeId)
{
    return SpCellSelFailPerCandidateIndexMap.getValue(typeId);
};
int getSizeSpCellSelFailPerCandidateIndexMap()
{
    return static_cast<int>(SpCellSelFailPerCandidateIndexMap.size());
}
std::optional<int> getKeySpCellSelFailPerCandidateIndexMap(int index)
{
    return SpCellSelFailPerCandidateIndexReverseMap.getValue(index);
};
