#include <map>
#include <string>
#include "PM_TYPE_ID.h"
#include "cause_call_5g.h"
#include "ComCslCauseMap.h"

typedef std::map<cause_t, pmCause_t> pmCauseMap_type;

static pmCauseMap_type& wrapperCauseMap()
{
    static pmCauseMap_type causeMap;
    return causeMap;
}

nr_csl_cause_error_e nr_csl_du_id_hex_cause_make_cp_map(void)
{
    wrapperCauseMap()[CAUSE_CRR_SUM] = HEXA_ACPF_CrrSum_DUID;
    wrapperCauseMap()[CAUSE_NO_FAULT_DU_ID] = HEXA_ACPF_NoFault_DUID;
    wrapperCauseMap()[CauseCpInternalTmOutRrcConnectionReconfig] = HEXA_ACPF_CauseInternalTmOutRrcConnectionReconfig_DUID;
    wrapperCauseMap()[CauseCpInternalTmOutF1UeContextSetup] = HEXA_ACPF_CauseInternalTmOutF1UeContextSetup_DUID;
    wrapperCauseMap()[CauseCpInternalTmOutE1BearerSetup] = HEXA_ACPF_CauseInternalTmOutE1BearerSetup_DUID;
    wrapperCauseMap()[CauseCpInternalTmOutE1BearerContextModification] =
            HEXA_ACPF_CauseInternalTmOutE1BearerContextModification_DUID;
    wrapperCauseMap()[CauseCpInternalTmOutF1UeContextModification] = HEXA_ACPF_CauseInternalTmOutF1UeContextModification_DUID;
    wrapperCauseMap()[CauseCpInternalTmOutF1UeContextRelease] = HEXA_ACPF_CauseInternalTmOutF1UeContextRelease_DUID;
    wrapperCauseMap()[CauseCpInternalNsaTmOutX2SgnbReconfigurationComplete] =
            HEXA_ACPF_CauseInternalTmOutX2SgnbReconfigurationComplete_DUID;
    wrapperCauseMap()[CauseCpInternalNsaTmOutX2ModificationConfirm] = HEXA_ACPF_CauseInternalTmOutX2ModificationConfirm_DUID;
    wrapperCauseMap()[CauseCpInternalTmOutInternalResourceSetup] = HEXA_ACPF_CauseInternalTmOutInternalResourceSetup_DUID;
    wrapperCauseMap()[CauseCpInternalF1SctpOutOfService] = HEXA_ACPF_CauseInternalF1SctpOutOfService_DUID;
    wrapperCauseMap()[CauseCpInternalE1SctpOutOfService] = HEXA_ACPF_CauseInternalE1SctpOutOfService_DUID;
    wrapperCauseMap()[CauseCpInternalNsaX2SctpOutOfService] = HEXA_ACPF_CauseInternalX2SctpOutOfService_DUID;
    wrapperCauseMap()[CauseCpInternalMDSSendFail] = HEXA_ACPF_CauseInternalMDSSendFail_DUID;
    wrapperCauseMap()[CauseCpInternalCacCallCountOver] = HEXA_ACPF_CauseInternalCacCallCountOver_DUID;
    wrapperCauseMap()[CauseCpInternalNsaNotSupportedQci] = HEXA_ACPF_CauseInternalNotSupportedQci_DUID;
    wrapperCauseMap()[CauseCpInternalInvalidCallContext] = HEXA_ACPF_CauseInternalInvalidCallContext_DUID;
    wrapperCauseMap()[CauseCpInternalResourceAllocFail] = HEXA_ACPF_CauseInternalResourceAllocFail_DUID;
    wrapperCauseMap()[CauseCpInternalOMIntervention] = HEXA_ACPF_CauseInternalOMIntervention_DUID;
    wrapperCauseMap()[CauseCpInternalVmScaleIn] = HEXA_ACPF_CauseInternalVmScaleIn_DUID;
    wrapperCauseMap()[CauseCpInternalCellRelease] = HEXA_ACPF_CauseInternalCellRelease_DUID;
    wrapperCauseMap()[CauseCpInternalCallAllocationFail] = HEXA_ACPF_CauseInternalCallAllocationFail_DUID;
    wrapperCauseMap()[CauseCpInternalUpAllocationFail] = HEXA_ACPF_CauseInternalUpAllocationFail_DUID;
    wrapperCauseMap()[CauseCpInternalInvalidCallId] = HEXA_ACPF_CauseInternalInvalidCallId_DUID;
    wrapperCauseMap()[CauseCpInternalInvalidPlmn] = HEXA_ACPF_CauseInternalInvalidPlmn_DUID;
    wrapperCauseMap()[CauseCpInternalUserInactivity] = HEXA_ACPF_CauseInternalUserInactivity_DUID;
    wrapperCauseMap()[CauseCpInternalNsaT310Expiry] = HEXA_ACPF_CauseInternalT310Expiry_DUID;
    wrapperCauseMap()[CauseCpInternalNsaRandomAccessProblem] = HEXA_ACPF_CauseInternalRandomAccessProblem_DUID;
    wrapperCauseMap()[CauseCpInternalNsaRlcMaxNumRetx] = HEXA_ACPF_CauseInternalRlcMaxNumRetx_DUID;
    wrapperCauseMap()[CauseCpInternalNsaScgChangeFailure] = HEXA_ACPF_CauseInternalScgChangeFailure_DUID;
    wrapperCauseMap()[CauseCpInternalNsaScgReconfigFailure] = HEXA_ACPF_CauseInternalScgReconfigFailure_DUID;
    wrapperCauseMap()[CauseCpInternalNsaSrb3IntegrityFailure] = HEXA_ACPF_CauseInternalSrb3IntegrityFailure_DUID;
    wrapperCauseMap()[CauseCpInternalScgMobility] = HEXA_ACPF_CauseInternalScgMobility_DUID;
    wrapperCauseMap()[CauseCpInternalMeasurementReportBasedRelease] = HEXA_ACPF_CauseInternalMeasurementReportBasedRelease_DUID;
    wrapperCauseMap()[CauseF1apRadioUnspecified] = HEXA_ACPF_CauseF1apRadioUnspecified_DUID;
    wrapperCauseMap()[CauseF1apRadioRLFailure] = HEXA_ACPF_CauseF1apRadioRLFailure_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedCuUeF1apId] =
            HEXA_ACPF_CauseF1apRadioUnknownOrAlreadyAllocatedCuUeF1apId_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedDuUeF1apId] =
            HEXA_ACPF_CauseF1apRadioUnknownOrAlreadyAllocatedDuUeF1apId_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownInconsistentPairOfUeF1apId] =
            HEXA_ACPF_CauseF1apRadioUnknownInconsistentPairOfUeF1apId_DUID;
    wrapperCauseMap()[CauseF1apRadioInteraction] = HEXA_ACPF_CauseF1apRadioInteraction_DUID;
    wrapperCauseMap()[CauseF1apRadioNotSupportedQCI] = HEXA_ACPF_CauseF1apRadioNotSupportedQCI_DUID;
    wrapperCauseMap()[CauseF1apRadioDesirableRadioReasons] = HEXA_ACPF_CauseF1apRadioDesirableRadioReasons_DUID;
    wrapperCauseMap()[CauseF1apRadioUnavailableRadioReasons] = HEXA_ACPF_CauseF1apRadioUnavailableRadioReasons_DUID;
    wrapperCauseMap()[CauseF1apRadioProcedureCancelled] = HEXA_ACPF_CauseF1apRadioProcedureCancelled_DUID;
    wrapperCauseMap()[CauseF1apRadioNormalRelease] = HEXA_ACPF_CauseF1apRadioNormalRelease_DUID;
    wrapperCauseMap()[CauseF1apRadioCellNotAvailable] = HEXA_ACPF_CauseF1apRadioCellNotAvailable_DUID;
    wrapperCauseMap()[CauseF1apRadioRLFailureothers] = HEXA_ACPF_CauseF1apRadioRLFailureothers_DUID;
    wrapperCauseMap()[CauseF1apRadioUeRejection] = HEXA_ACPF_CauseF1apRadioUeRejection_DUID;
    wrapperCauseMap()[CauseF1apRadioResourcesNotAvailableForTheSlice] =
            HEXA_ACPF_CauseF1apRadioResourcesNotAvailableForTheSlice_DUID;
    wrapperCauseMap()[CauseF1apTransportUnspecified] = HEXA_ACPF_CauseF1apTransportUnspecified_DUID;
    wrapperCauseMap()[CauseF1apTransportResourceUnavailable] = HEXA_ACPF_CauseF1apTransportResourceUnavailable_DUID;
    wrapperCauseMap()[CauseF1apProtocolTransferSyntaxError] = HEXA_ACPF_CauseF1apProtocolTransferSyntaxError_DUID;
    wrapperCauseMap()[CauseF1apProtocolAbstractSyntaxErrorReject] = HEXA_ACPF_CauseF1apProtocolAbstractSyntaxErrorReject_DUID;
    wrapperCauseMap()[CauseF1apProtocolAbstractSyntaxErrorIgnore] = HEXA_ACPF_CauseF1apProtocolAbstractSyntaxErrorIgnore_DUID;
    wrapperCauseMap()[CauseF1apProtocolMessageNotCompatible] = HEXA_ACPF_CauseF1apProtocolMessageNotCompatible_DUID;
    wrapperCauseMap()[CauseF1apProtocolSemanticError] = HEXA_ACPF_CauseF1apProtocolSemanticError_DUID;
    wrapperCauseMap()[CauseF1apProtocolAbstractSyntaxError] = HEXA_ACPF_CauseF1apProtocolAbstractSyntaxError_DUID;
    wrapperCauseMap()[CauseF1apProtocolUnspecified] = HEXA_ACPF_CauseF1apProtocolUnspecified_DUID;
    wrapperCauseMap()[CauseF1apMiscControlProcessingOverload] = HEXA_ACPF_CauseF1apMiscControlProcessingOverload_DUID;
    wrapperCauseMap()[CauseF1apMiscUnavailableResources] = HEXA_ACPF_CauseF1apMiscUnavailableResources_DUID;
    wrapperCauseMap()[CauseF1apMiscHardwareFailure] = HEXA_ACPF_CauseF1apMiscHardwareFailure_DUID;
    wrapperCauseMap()[CauseF1apMiscOMIntervention] = HEXA_ACPF_CauseF1apMiscOMIntervention_DUID;
    wrapperCauseMap()[CauseF1apMiscUnspecifiedFailure] = HEXA_ACPF_CauseF1apMiscUnspecifiedFailure_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerHandoverDesirableForRadioReasons] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerHandoverDesirableForRadioReasons_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerTimeCriticalHandover] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerTimeCriticalHandover_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerResourceOptimisationHandover] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerResourceOptimisationHandover_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerReduceLoadInServingCell] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerReduceLoadInServingCell_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerPartialHandover] = HEXA_ACPF_CauseX2apRadioNetworkLayerPartialHandover_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUnknownNewEnbUeX2apId] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerUnknownNewEnbUeX2apId_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUnknownOldEnbUeX2apId] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerUnknownOldEnbUeX2apId_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUnknownPairOfUeX2apId] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerUnknownPairOfUeX2apId_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerHoTargetNotAllowed] = HEXA_ACPF_CauseX2apRadioNetworkLayerHoTargetNotAllowed_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerTx2relocoverallExpiry] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerTx2relocoverallExpiry_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerTrelocoverallExpiry] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerTrelocoverallExpiry_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerCellNotAvailable] = HEXA_ACPF_CauseX2apRadioNetworkLayerCellNotAvailable_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerNoRadioResourcesAvailableInTargetCell] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerNoRadioResourcesAvailableInTargetCell_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerInvalidMMEGroupID] = HEXA_ACPF_CauseX2apRadioNetworkLayerInvalidMMEGroupID_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUnknownMMECode] = HEXA_ACPF_CauseX2apRadioNetworkLayerUnknownMMECode_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerEncryptionAndOrIntegrityProtectionAlgorithmsNotSupported] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerEncryptionAndOrIntegrityProtectionAlgorithmsNotSupported_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerReportCharacteristicsEmpty] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerReportCharacteristicsEmpty_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerNoReportPeriodicity] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerNoReportPeriodicity_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerExistingMeasurementID] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerExistingMeasurementID_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUnknownEnbMeasurementID] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerUnknownEnbMeasurementID_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerMeasurementTemporarilyNotAvailable] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerMeasurementTemporarilyNotAvailable_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUnspecified] = HEXA_ACPF_CauseX2apRadioNetworkLayerUnspecified_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerLoadBalancing] = HEXA_ACPF_CauseX2apRadioNetworkLayerLoadBalancing_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerHandoverOptimisation] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerHandoverOptimisation_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerValueOutOfAllowedRange] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerValueOutOfAllowedRange_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerMultipleErabIdInstances] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerMultipleErabIdInstances_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerSwitchOffOngoing] = HEXA_ACPF_CauseX2apRadioNetworkLayerSwitchOffOngoing_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerNotSupportedQciValue] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerNotSupportedQciValue_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerMeasurementNotSupportedForTheObject] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerMeasurementNotSupportedForTheObject_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerTdcoverallExpiry] = HEXA_ACPF_CauseX2apRadioNetworkLayerTdcoverallExpiry_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerTdcprepExpiry] = HEXA_ACPF_CauseX2apRadioNetworkLayerTdcprepExpiry_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerActionDesirableForRadioReasons] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerActionDesirableForRadioReasons_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerReduceLoad] = HEXA_ACPF_CauseX2apRadioNetworkLayerReduceLoad_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerResourceOptimisation] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerResourceOptimisation_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerTimeCriticalAction] = HEXA_ACPF_CauseX2apRadioNetworkLayerTimeCriticalAction_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerTargetNotAllowed] = HEXA_ACPF_CauseX2apRadioNetworkLayerTargetNotAllowed_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerNoRadioResourcesAvailable] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerNoRadioResourcesAvailable_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerInvalidQosCombination] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerInvalidQosCombination_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerEncryptionAlgorithmsNotSupported] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerEncryptionAlgorithmsNotSupported_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerProcedureCancelled] = HEXA_ACPF_CauseX2apRadioNetworkLayerProcedureCancelled_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerRrmPurpose] = HEXA_ACPF_CauseX2apRadioNetworkLayerRrmPurpose_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerImproveUserBitRate] = HEXA_ACPF_CauseX2apRadioNetworkLayerImproveUserBitRate_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUserInactivity] = HEXA_ACPF_CauseX2apRadioNetworkLayerUserInactivity_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerRadioConnectionWithUeLost] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerRadioConnectionWithUeLost_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerFailureInTheRadioInterfaceProcedure] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerFailureInTheRadioInterfaceProcedure_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerBearerOptionNotSupported] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerBearerOptionNotSupported_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerMcgMobility] = HEXA_ACPF_CauseX2apRadioNetworkLayerMcgMobility_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerScgMobility] = HEXA_ACPF_CauseX2apRadioNetworkLayerScgMobility_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerCountReachesMaxValue] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerCountReachesMaxValue_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUnknownOldEngnbUeX2apId] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerUnknownOldEngnbUeX2apId_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerPdcpOverload] = HEXA_ACPF_CauseX2apRadioNetworkLayerPdcpOverload_DUID;
    wrapperCauseMap()[CauseX2apTransportNetworkLayerTransportResourceUnavailable] =
            HEXA_ACPF_CauseX2apTransportNetworkLayerTransportResourceUnavailable_DUID;
    wrapperCauseMap()[CauseX2apTransportNetworkLayerUnspecified] = HEXA_ACPF_CauseX2apTransportNetworkLayerUnspecified_DUID;
    wrapperCauseMap()[CauseX2apProtocolTransferSyntaxError] = HEXA_ACPF_CauseX2apProtocolTransferSyntaxError_DUID;
    wrapperCauseMap()[CauseX2apProtocolAbstractSyntaxErrorReject] = HEXA_ACPF_CauseX2apProtocolAbstractSyntaxErrorReject_DUID;
    wrapperCauseMap()[CauseX2apProtocolAbstractSyntaxErrorIgnoreAndNotify] =
            HEXA_ACPF_CauseX2apProtocolAbstractSyntaxErrorIgnoreAndNotify_DUID;
    wrapperCauseMap()[CauseX2apProtocolMessageNotCompatibleWithReceiverState] =
            HEXA_ACPF_CauseX2apProtocolMessageNotCompatibleWithReceiverState_DUID;
    wrapperCauseMap()[CauseX2apProtocolSemanticError] = HEXA_ACPF_CauseX2apProtocolSemanticError_DUID;
    wrapperCauseMap()[CauseX2apProtocolUnspecified] = HEXA_ACPF_CauseX2apProtocolUnspecified_DUID;
    wrapperCauseMap()[CauseX2apProtocolAbstractSyntaxErrorFalselyConstructedMessage] =
            HEXA_ACPF_CauseX2apProtocolAbstractSyntaxErrorFalselyConstructedMessage_DUID;
    wrapperCauseMap()[CauseX2apMiscControlProcessingOverload] = HEXA_ACPF_CauseX2apMiscControlProcessingOverload_DUID;
    wrapperCauseMap()[CauseX2apMiscHardwareFailure] = HEXA_ACPF_CauseX2apMiscHardwareFailure_DUID;
    wrapperCauseMap()[CauseX2apMiscOMIntervention] = HEXA_ACPF_CauseX2apMiscOMIntervention_DUID;
    wrapperCauseMap()[CauseX2apMiscNotEnoughUserPlaneProcessingResources] =
            HEXA_ACPF_CauseX2apMiscNotEnoughUserPlaneProcessingResources_DUID;
    wrapperCauseMap()[CauseX2apMiscUnspecified] = HEXA_ACPF_CauseX2apMiscUnspecified_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnspecified] = HEXA_ACPF_CauseE1apRadioNetworkLayerUnspecified_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpUeE1apId] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpUeE1apId_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpUeE1apId] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpUeE1apId_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfUeE1apId] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfUeE1apId_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerInteractionWithOtherProcedure] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerInteractionWithOtherProcedure_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerPdcpCountWrapAround] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerPdcpCountWrapAround_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNotSupportedQciValue] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerNotSupportedQciValue_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNotSupported5QiValue] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerNotSupported5QiValue_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerEncryptionAlgorithmsNotSupported] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerEncryptionAlgorithmsNotSupported_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerIntegrityProtectionAlgorithmsNotSupported] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerIntegrityProtectionAlgorithmsNotSupported_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUpIntegrityProtectionNotPossible] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerUpIntegrityProtectionNotPossible_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUpConfidentialityProtectionNotPossible] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerUpConfidentialityProtectionNotPossible_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMultiplePduSessionIdInstances] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerMultiplePduSessionIdInstances_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownPduSessionId] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerUnknownPduSessionId_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMultipleQosFlowIdInstances] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerMultipleQosFlowIdInstances_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownQosFlowId] = HEXA_ACPF_CauseE1apRadioNetworkLayerUnknownQosFlowId_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMultipleDrbIdInstances] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerMultipleDrbIdInstances_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownDrbId] = HEXA_ACPF_CauseE1apRadioNetworkLayerUnknownDrbId_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerInvalidQosCombination] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerInvalidQosCombination_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerProcedureCancelled] = HEXA_ACPF_CauseE1apRadioNetworkLayerProcedureCancelled_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNormalRelease] = HEXA_ACPF_CauseE1apRadioNetworkLayerNormalRelease_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNoRadioResourcesAvailable] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerNoRadioResourcesAvailable_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerActionDesirableForRadioReasons] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerActionDesirableForRadioReasons_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerResourcesNotAvailableForTheSlice] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerResourcesNotAvailableForTheSlice_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerPdcpConfigurationNotSupported] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerPdcpConfigurationNotSupported_DUID;
    wrapperCauseMap()[CauseE1apTransportLayerUnspecified] = HEXA_ACPF_CauseE1apTransportLayerUnspecified_DUID;
    wrapperCauseMap()[CauseE1apTransportLayerTransportResourceUnavailable] =
            HEXA_ACPF_CauseE1apTransportLayerTransportResourceUnavailable_DUID;
    wrapperCauseMap()[CauseE1apProtocolTransferSyntaxError] = HEXA_ACPF_CauseE1apProtocolTransferSyntaxError_DUID;
    wrapperCauseMap()[CauseE1apProtocolAbstractSyntaxErrorReject] = HEXA_ACPF_CauseE1apProtocolAbstractSyntaxErrorReject_DUID;
    wrapperCauseMap()[CauseE1apProtocolAbstractSyntaxErrorIgnoreAndNotify] =
            HEXA_ACPF_CauseE1apProtocolAbstractSyntaxErrorIgnoreAndNotify_DUID;
    wrapperCauseMap()[CauseE1apProtocolMessageNotCompatibleWithReceiverState] =
            HEXA_ACPF_CauseE1apProtocolMessageNotCompatibleWithReceiverState_DUID;
    wrapperCauseMap()[CauseE1apProtocolSemanticError] = HEXA_ACPF_CauseE1apProtocolSemanticError_DUID;
    wrapperCauseMap()[CauseE1apProtocolAbstractSyntaxErrorFalselyConstructedMessage] =
            HEXA_ACPF_CauseE1apProtocolAbstractSyntaxErrorFalselyConstructedMessage_DUID;
    wrapperCauseMap()[CauseE1apProtocolUnspecified] = HEXA_ACPF_CauseE1apProtocolUnspecified_DUID;
    wrapperCauseMap()[CauseE1apMiscControlProcessingOverload] = HEXA_ACPF_CauseE1apMiscControlProcessingOverload_DUID;
    wrapperCauseMap()[CauseE1apMiscNotEnoughUserPlaneProcessingResources] =
            HEXA_ACPF_CauseE1apMiscNotEnoughUserPlaneProcessingResources_DUID;
    wrapperCauseMap()[CauseE1apMiscHardwareFailure] = HEXA_ACPF_CauseE1apMiscHardwareFailure_DUID;
    wrapperCauseMap()[CauseE1apMiscOMIntervention] = HEXA_ACPF_CauseE1apMiscOMIntervention_DUID;
    wrapperCauseMap()[CauseE1apMiscUnspecified] = HEXA_ACPF_CauseE1apMiscUnspecified_DUID;
    wrapperCauseMap()[CauseCpInternalDuULRadioLinkFailure] = HEXA_ACPF_CauseInternalDuULRadioLinkFailure_DUID;
    wrapperCauseMap()[CauseCpInternalDuRlcMaxNumRetx] = HEXA_ACPF_CauseInternalDuRlcMaxNumRetx_DUID;
    wrapperCauseMap()[CauseCpInternalCpSrb3IntegrityFailure] = HEXA_ACPF_CauseInternalCpSrb3IntegrityFailure_DUID;
    wrapperCauseMap()[CauseCpInternalCuOverload] = HEXA_ACPF_CauseInternalCuOverload_DUID;
    wrapperCauseMap()[CauseCpInternalStoreRrcMessageError] = HEXA_ACPF_CauseInternalStoreRrcMessageError_DUID;
    wrapperCauseMap()[CauseCpInternalStoreE1MessageError] = HEXA_ACPF_CauseInternalStoreE1MessageError_DUID;
    wrapperCauseMap()[CauseCpInternalStoreF1MessageError] = HEXA_ACPF_CauseInternalStoreF1MessageError_DUID;
    wrapperCauseMap()[CauseCpInternalSendRrcMessageError] = HEXA_ACPF_CauseInternalSendRrcMessageError_DUID;
    wrapperCauseMap()[CauseCpInternalSendE1MessageError] = HEXA_ACPF_CauseInternalSendE1MessageError_DUID;
    wrapperCauseMap()[CauseCpInternalSendF1MessageError] = HEXA_ACPF_CauseInternalSendF1MessageError_DUID;
    wrapperCauseMap()[CauseCpInternalNsaStoreX2MessageError] = HEXA_ACPF_CauseInternalStoreX2MessageError_DUID;
    wrapperCauseMap()[CauseCpInternalNsaSendX2MessageError] = HEXA_ACPF_CauseInternalSendX2MessageError_DUID;
    wrapperCauseMap()[CauseCpInternalNsaTmOutX2ChangeConfirm] = HEXA_ACPF_CauseInternalTmOutX2ChangeConfirm_DUID;
    wrapperCauseMap()[CauseCpInternalNsaTmOutX2SNStatusTransfer] = HEXA_ACPF_CauseInternalTmOutX2SNStatusTransfer_DUID;
    wrapperCauseMap()[CauseCpInternalNsaSpCellSelectionFail] = HEXA_ACPF_CauseInternalSpCellSelectionFail_DUID;
    wrapperCauseMap()[CauseCpInternalInvalidCellId] = HEXA_ACPF_CauseInternalInvalidCellId_DUID;
    wrapperCauseMap()[CauseF1apRadioAmfInitiatedAbnormalRelease] = HEXA_ACPF_CauseF1apRadioAmfInitiatedAbnormalRelease_DUID;
    wrapperCauseMap()[CauseF1apRadioReleaseDueToPreEmption] = HEXA_ACPF_CauseF1apRadioReleaseDueToPreEmption_DUID;
    wrapperCauseMap()[CauseF1apRadioPlmnNotServedByTheGnbCu] = HEXA_ACPF_CauseF1apRadioPlmnNotServedByTheGnbCu_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUeDlMaxIPDataRateReason] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerUeDlMaxIPDataRateReason_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUpIntegrityProtectionFailure] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerUpIntegrityProtectionFailure_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerReleaseDueToPreEmption] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerReleaseDueToPreEmption_DUID;
    wrapperCauseMap()[CauseCpInternalNsaTmOutResumeForMrBased] = HEXA_ACPF_CauseInternalTmOutResumeForMrBased_DUID;
    wrapperCauseMap()[CauseCpInternalNsaSynchReconfigFailureScg] = HEXA_ACPF_CauseInternalSynchReconfigFailureScg_DUID;
    wrapperCauseMap()[CauseCpInternalNsaX2UEContextRelease] = HEXA_ACPF_CauseInternalX2UEContextRelease_DUID;
    wrapperCauseMap()[CauseCpInternalNsaT312Expiry] = HEXA_ACPF_CauseInternalT312Expiry_DUID;
    wrapperCauseMap()[CauseCpInternalNsaBeamFailureRecoveryFailure] = HEXA_ACPF_CauseInternalBeamFailureRecoveryFailure_DUID;
    wrapperCauseMap()[CauseF1apRadioMultipleDrbIdInstances] = HEXA_ACPF_CauseF1apRadioMultipleDrbIdInstances_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownDrbId] = HEXA_ACPF_CauseF1apRadioUnknownDrbId_DUID;
    wrapperCauseMap()[CauseF1apRadioMultipleBhRlcChIdInstances] = HEXA_ACPF_CauseF1apRadioMultipleBhRlcChIdInstances_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownBhRlcChId] = HEXA_ACPF_CauseF1apRadioUnknownBhRlcChId_DUID;
    wrapperCauseMap()[CauseF1apRadioChoCpcResourcesToBeChanged] = HEXA_ACPF_CauseF1apRadioChoCpcResourcesToBeChanged_DUID;
    wrapperCauseMap()[CauseF1apRadioNpnNotSupported] = HEXA_ACPF_CauseF1apRadioNpnNotSupported_DUID;
    wrapperCauseMap()[CauseF1apRadioNpnAccessDenied] = HEXA_ACPF_CauseF1apRadioNpnAccessDenied_DUID;
    wrapperCauseMap()[CauseF1apRadioGnbCuCellCapacityExceeded] = HEXA_ACPF_CauseF1apRadioGnbCuCellCapacityExceeded_DUID;
    wrapperCauseMap()[CauseF1apRadioReportCharacteristicsEmpty] = HEXA_ACPF_CauseF1apRadioReportCharacteristicsEmpty_DUID;
    wrapperCauseMap()[CauseF1apRadioExistingMeasurementID] = HEXA_ACPF_CauseF1apRadioExistingMeasurementID_DUID;
    wrapperCauseMap()[CauseF1apRadioMeasurementTemporarilyNotAvailable] =
            HEXA_ACPF_CauseF1apRadioMeasurementTemporarilyNotAvailable_DUID;
    wrapperCauseMap()[CauseF1apRadioMeasurementNotSupportedForTheObject] =
            HEXA_ACPF_CauseF1apRadioMeasurementNotSupportedForTheObject_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownBAPAddress] = HEXA_ACPF_CauseF1apRadioUnknownBAPAddress_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownBAPRoutingID] = HEXA_ACPF_CauseF1apRadioUnknownBAPRoutingID_DUID;
    wrapperCauseMap()[CauseF1apRadioInsufficientUeCapabilities] = HEXA_ACPF_CauseF1apRadioInsufficientUeCapabilities_DUID;
    wrapperCauseMap()[CauseF1apTransportUnknownTNLAddressForIAB] = HEXA_ACPF_CauseF1apTransportUnknownTNLAddressForIAB_DUID;
    wrapperCauseMap()[CauseF1apTransportUnknownUPTNLInformationForIAB] =
            HEXA_ACPF_CauseF1apTransportUnknownUPTNLInformationForIAB_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerRSNNotAvailableForTheUP] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerRSNNotAvailableForTheUP_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNPNNotSupported] = HEXA_ACPF_CauseE1apRadioNetworkLayerNPNNotSupported_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerReportCharacteristicsEmpty] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerReportCharacteristicsEmpty_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerExistingMeasurementID] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerExistingMeasurementID_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMeasurementTemporarilyNotAvailable] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerMeasurementTemporarilyNotAvailable_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMeasurementNotSupportedForTheObject] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerMeasurementNotSupportedForTheObject_DUID;
    wrapperCauseMap()[CauseE1apTransportLayerUnknownTNLAddressForIAB] =
            HEXA_ACPF_CauseE1apTransportLayerUnknownTNLAddressForIAB_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerCHOCPCResourcesToBeChanged] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerCHOCPCResourcesToBeChanged_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUEPowerSaving] = HEXA_ACPF_CauseX2apRadioNetworkLayerUEPowerSaving_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerInsufficientUeCapabilities] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerInsufficientUeCapabilities_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerNormalRelease] = HEXA_ACPF_CauseX2apRadioNetworkLayerNormalRelease_DUID;
    wrapperCauseMap()[CauseCpInternalCpSrbIntegrityFailure] = HEXA_ACPF_CauseInternalCpSrbIntegrityFailure_DUID;
    wrapperCauseMap()[CauseCpInternalNsaRandomAccessProblemAfterInitialAccess] =
            HEXA_ACPF_CauseInternalRandomAccessProblemAfterInitialAccess_DUID;
    wrapperCauseMap()[CauseF1apRadioScgActivationDeactivationFailure] =
            HEXA_ACPF_CauseF1apRadioScgActivationDeactivationFailure_DUID;
    wrapperCauseMap()[CauseF1apRadioScgDeactivationFailureDueToDataTransmission] =
            HEXA_ACPF_CauseF1apRadioScgDeactivationFailureDueToDataTransmission_DUID;
    wrapperCauseMap()[CauseF1apRadioRequestedItemNotSupportedOnTime] =
            HEXA_ACPF_CauseF1apRadioRequestedItemNotSupportedOnTime_DUID;
    wrapperCauseMap()[CauseF1apRadioTatSdtExpiry] =
            HEXA_ACPF_CauseF1apRadioTatSdtExpiry_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedGnbCuMbsF1apId] =
            HEXA_ACPF_CauseF1apRadioUnknownOrAlreadyAllocatedGnbCuMbsF1apId_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedGnbDuMbsF1apId] =
            HEXA_ACPF_CauseF1apRadioUnknownOrAlreadyAllocatedGnbDuMbsF1apId_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownOrInconsistentPairOfMbsF1apId] =
            HEXA_ACPF_CauseF1apRadioUnknownOrInconsistentPairOfMbsF1apId_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownOrInconsistentMrbId] =
            HEXA_ACPF_CauseF1apRadioUnknownOrInconsistentMrbId_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerScgActivationDeactivationFailure] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerScgActivationDeactivationFailure_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerScgDeactivationFailureDueToDataTransmission] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerScgDeactivationFailureDueToDataTransmission_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpMbsE1apId] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpMbsE1apId_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpMbsE1apId] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpMbsE1apId_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfMbsE1apId] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfMbsE1apId_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrInconsistentMrbId] =
            HEXA_ACPF_CauseE1apRadioNetworkLayerUnknownOrInconsistentMrbId_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUnknownEutranNodeMeasurementId] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerUnknownEutranNodeMeasurementId_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerScgActivationDeactivationFailure] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerScgActivationDeactivationFailure_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerScgDeactivationFailureDueToDataTransmission] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerScgDeactivationFailureDueToDataTransmission_DUID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUpIntegrityProtectionNotPossible] =
            HEXA_ACPF_CauseX2apRadioNetworkLayerUpIntegrityProtectionNotPossible_DUID;

    if (STAT_CUCPCSL_PER_GNB_DU_ID_HEXA_END == wrapperCauseMap().size())
        return NR_CSL_CAUSE_ERROR_NONE;
    else
        return NR_CSL_CAUSE_ERROR_VALIDATION_FAILED;
}

nr_csl_cause_error_e nr_csl_du_id_hex_cause_get_cp_pmCause(const cause_t cause, pmCause_t* pmCause)
{
    if (wrapperCauseMap().find(cause) == wrapperCauseMap().end())
    {
        return NR_CSL_CAUSE_ERROR_VALIDATION_FAILED;
    }

    if (NULL == pmCause)
    {
        return NR_CSL_CAUSE_ERROR_INVALID_PARAMETER;
    }

    *pmCause = wrapperCauseMap()[cause];
    return NR_CSL_CAUSE_ERROR_NONE;
}
