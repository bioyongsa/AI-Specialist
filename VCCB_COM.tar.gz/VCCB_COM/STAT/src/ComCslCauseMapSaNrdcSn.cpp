#include <map>
#include <string>
#include "PM_TYPE_ID.h"
#include "cause_call_5g.h"
#include "ComCslCauseMap.h"

typedef std::map<cause_t, pmCause_t> pmCauseMap_type;

static pmCauseMap_type& wrapperCauseMap()
{
    static pmCauseMap_type causeMap;
    return causeMap;
}

nr_csl_cause_error_e nr_csl_cause_make_sacp_nrdc_sn_map(void)
{
    wrapperCauseMap()[CAUSE_NO_FAULT] = SAACPF_NRDC_NoFault;
    wrapperCauseMap()[CauseCpInternalTmOutRrcConnectionReconfig] = SAACPF_NRDC_CauseInternalTmOutRrcConnectionReconfig;
    wrapperCauseMap()[CauseCpInternalTmOutF1UeContextSetup] = SAACPF_NRDC_CauseInternalTmOutF1UeContextSetup;
    wrapperCauseMap()[CauseCpInternalTmOutE1BearerSetup] = SAACPF_NRDC_CauseInternalTmOutE1BearerSetup;
    wrapperCauseMap()[CauseCpInternalTmOutE1BearerContextModification] =
        SAACPF_NRDC_CauseInternalTmOutE1BearerContextModification;
    wrapperCauseMap()[CauseCpInternalTmOutF1UeContextModification] =
        SAACPF_NRDC_CauseInternalTmOutF1UeContextModification;
    wrapperCauseMap()[CauseCpInternalTmOutF1UeContextRelease] = SAACPF_NRDC_CauseInternalTmOutF1UeContextRelease;
    wrapperCauseMap()[CauseCpInternalTmOutInternalResourceSetup] = SAACPF_NRDC_CauseInternalTmOutInternalResourceSetup;
    wrapperCauseMap()[CauseCpInternalF1SctpOutOfService] = SAACPF_NRDC_CauseInternalF1SctpOutOfService;
    wrapperCauseMap()[CauseCpInternalE1SctpOutOfService] = SAACPF_NRDC_CauseInternalE1SctpOutOfService;
    wrapperCauseMap()[CauseCpInternalMDSSendFail] = SAACPF_NRDC_CauseInternalMDSSendFail;
    wrapperCauseMap()[CauseCpInternalCacCallCountOver] = SAACPF_NRDC_CauseInternalCacCallCountOver;
    wrapperCauseMap()[CauseCpInternalInvalidCallContext] = SAACPF_NRDC_CauseInternalInvalidCallContext;
    wrapperCauseMap()[CauseCpInternalResourceAllocFail] = SAACPF_NRDC_CauseInternalResourceAllocFail;
    wrapperCauseMap()[CauseCpInternalOMIntervention] = SAACPF_NRDC_CauseInternalOMIntervention;
    wrapperCauseMap()[CauseCpInternalVmScaleIn] = SAACPF_NRDC_CauseInternalVmScaleIn;
    wrapperCauseMap()[CauseCpInternalCellRelease] = SAACPF_NRDC_CauseInternalCellRelease;
    wrapperCauseMap()[CauseCpInternalCallAllocationFail] = SAACPF_NRDC_CauseInternalCallAllocationFail;
    wrapperCauseMap()[CauseCpInternalUpAllocationFail] = SAACPF_NRDC_CauseInternalUpAllocationFail;
    wrapperCauseMap()[CauseCpInternalInvalidCallId] = SAACPF_NRDC_CauseInternalInvalidCallId;
    wrapperCauseMap()[CauseCpInternalInvalidPlmn] = SAACPF_NRDC_CauseInternalInvalidPlmn;
    wrapperCauseMap()[CauseCpInternalUserInactivity] = SAACPF_NRDC_CauseInternalUserInactivity;
    wrapperCauseMap()[CauseCpInternalScgMobility] = SAACPF_NRDC_CauseInternalScgMobility;
    wrapperCauseMap()[CauseCpInternalMeasurementReportBasedRelease] =
        SAACPF_NRDC_CauseInternalMeasurementReportBasedRelease;
    wrapperCauseMap()[CauseCpInternalDuULRadioLinkFailure] = SAACPF_NRDC_CauseInternalDuULRadioLinkFailure;
    wrapperCauseMap()[CauseCpInternalDuRlcMaxNumRetx] = SAACPF_NRDC_CauseInternalDuRlcMaxNumRetx;
    wrapperCauseMap()[CauseCpInternalCpSrb3IntegrityFailure] = SAACPF_NRDC_CauseInternalCpSrb3IntegrityFailure;
    wrapperCauseMap()[CauseCpInternalCuOverload] = SAACPF_NRDC_CauseInternalCuOverload;
    wrapperCauseMap()[CauseCpInternalStoreRrcMessageError] = SAACPF_NRDC_CauseInternalStoreRrcMessageError;
    wrapperCauseMap()[CauseCpInternalStoreE1MessageError] = SAACPF_NRDC_CauseInternalStoreE1MessageError;
    wrapperCauseMap()[CauseCpInternalStoreF1MessageError] = SAACPF_NRDC_CauseInternalStoreF1MessageError;
    wrapperCauseMap()[CauseCpInternalSendRrcMessageError] = SAACPF_NRDC_CauseInternalSendRrcMessageError;
    wrapperCauseMap()[CauseCpInternalSendE1MessageError] = SAACPF_NRDC_CauseInternalSendE1MessageError;
    wrapperCauseMap()[CauseCpInternalSendF1MessageError] = SAACPF_NRDC_CauseInternalSendF1MessageError;
    wrapperCauseMap()[CauseCpInternalSaHoTmOutXnSNStatusTransfer] = SAACPF_NRDC_CauseInternalHoTmOutXnSNStatusTransfer;
    wrapperCauseMap()[CauseCpInternalSaHoTmOutXnRelocOverall] = SAACPF_NRDC_CauseInternalHoTmOutXnRelocOverall;
    wrapperCauseMap()[CauseCpInternalSaHoTmOutRrcHandoverComplete] =
        SAACPF_NRDC_CauseInternalHoTmOutRrcHandoverComplete;
    wrapperCauseMap()[CauseCpInternalSaXnSctpOutOfService] = SAACPF_NRDC_CauseInternalXnSctpOutOfService;
    wrapperCauseMap()[CauseCpInternalSaDuCallAllocationFail] = SAACPF_NRDC_CauseInternalDuCallAllocationFail;
    wrapperCauseMap()[CauseCpInternalSaNotSupported5qiValue] = SAACPF_NRDC_CauseInternalNotSupported5qiValue;
    wrapperCauseMap()[CauseCpInternalSaStoreXnMessageError] = SAACPF_NRDC_CauseInternalStoreXnMessageError;
    wrapperCauseMap()[CauseCpInternalSaSendXnMessageError] = SAACPF_NRDC_CauseInternalSendXnMessageError;
    wrapperCauseMap()[CauseF1apRadioUnspecified] = SAACPF_NRDC_CauseF1apRadioUnspecified;
    wrapperCauseMap()[CauseF1apRadioRLFailure] = SAACPF_NRDC_CauseF1apRadioRLFailure;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedCuUeF1apId] =
        SAACPF_NRDC_CauseF1apRadioUnknownOrAlreadyAllocatedCuUeF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedDuUeF1apId] =
        SAACPF_NRDC_CauseF1apRadioUnknownOrAlreadyAllocatedDuUeF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownInconsistentPairOfUeF1apId] =
        SAACPF_NRDC_CauseF1apRadioUnknownInconsistentPairOfUeF1apId;
    wrapperCauseMap()[CauseF1apRadioInteraction] = SAACPF_NRDC_CauseF1apRadioInteraction;
    wrapperCauseMap()[CauseF1apRadioDesirableRadioReasons] = SAACPF_NRDC_CauseF1apRadioDesirableRadioReasons;
    wrapperCauseMap()[CauseF1apRadioUnavailableRadioReasons] = SAACPF_NRDC_CauseF1apRadioUnavailableRadioReasons;
    wrapperCauseMap()[CauseF1apRadioProcedureCancelled] = SAACPF_NRDC_CauseF1apRadioProcedureCancelled;
    wrapperCauseMap()[CauseF1apRadioNormalRelease] = SAACPF_NRDC_CauseF1apRadioNormalRelease;
    wrapperCauseMap()[CauseF1apRadioCellNotAvailable] = SAACPF_NRDC_CauseF1apRadioCellNotAvailable;
    wrapperCauseMap()[CauseF1apRadioRLFailureothers] = SAACPF_NRDC_CauseF1apRadioRLFailureothers;
    wrapperCauseMap()[CauseF1apRadioUeRejection] = SAACPF_NRDC_CauseF1apRadioUeRejection;
    wrapperCauseMap()[CauseF1apRadioResourcesNotAvailableForTheSlice] =
        SAACPF_NRDC_CauseF1apRadioResourcesNotAvailableForTheSlice;
    wrapperCauseMap()[CauseF1apTransportUnspecified] = SAACPF_NRDC_CauseF1apTransportUnspecified;
    wrapperCauseMap()[CauseF1apTransportResourceUnavailable] = SAACPF_NRDC_CauseF1apTransportResourceUnavailable;
    wrapperCauseMap()[CauseF1apProtocolTransferSyntaxError] = SAACPF_NRDC_CauseF1apProtocolTransferSyntaxError;
    wrapperCauseMap()[CauseF1apProtocolAbstractSyntaxErrorReject] =
        SAACPF_NRDC_CauseF1apProtocolAbstractSyntaxErrorReject;
    wrapperCauseMap()[CauseF1apProtocolAbstractSyntaxErrorIgnore] =
        SAACPF_NRDC_CauseF1apProtocolAbstractSyntaxErrorIgnore;
    wrapperCauseMap()[CauseF1apProtocolMessageNotCompatible] = SAACPF_NRDC_CauseF1apProtocolMessageNotCompatible;
    wrapperCauseMap()[CauseF1apProtocolSemanticError] = SAACPF_NRDC_CauseF1apProtocolSemanticError;
    wrapperCauseMap()[CauseF1apProtocolAbstractSyntaxError] = SAACPF_NRDC_CauseF1apProtocolAbstractSyntaxError;
    wrapperCauseMap()[CauseF1apProtocolUnspecified] = SAACPF_NRDC_CauseF1apProtocolUnspecified;
    wrapperCauseMap()[CauseF1apMiscControlProcessingOverload] = SAACPF_NRDC_CauseF1apMiscControlProcessingOverload;
    wrapperCauseMap()[CauseF1apMiscUnavailableResources] = SAACPF_NRDC_CauseF1apMiscUnavailableResources;
    wrapperCauseMap()[CauseF1apMiscHardwareFailure] = SAACPF_NRDC_CauseF1apMiscHardwareFailure;
    wrapperCauseMap()[CauseF1apMiscOMIntervention] = SAACPF_NRDC_CauseF1apMiscOMIntervention;
    wrapperCauseMap()[CauseF1apMiscUnspecifiedFailure] = SAACPF_NRDC_CauseF1apMiscUnspecifiedFailure;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnspecified] = SAACPF_NRDC_CauseE1apRadioNetworkLayerUnspecified;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpUeE1apId] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpUeE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpUeE1apId] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpUeE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfUeE1apId] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfUeE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerInteractionWithOtherProcedure] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerInteractionWithOtherProcedure;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerPdcpCountWrapAround] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerPdcpCountWrapAround;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNotSupported5QiValue] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerNotSupported5QiValue;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerEncryptionAlgorithmsNotSupported] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerEncryptionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerIntegrityProtectionAlgorithmsNotSupported] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerIntegrityProtectionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUpIntegrityProtectionNotPossible] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerUpIntegrityProtectionNotPossible;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUpConfidentialityProtectionNotPossible] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerUpConfidentialityProtectionNotPossible;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMultiplePduSessionIdInstances] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerMultiplePduSessionIdInstances;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownPduSessionId] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownPduSessionId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMultipleQosFlowIdInstances] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerMultipleQosFlowIdInstances;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownQosFlowId] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownQosFlowId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMultipleDrbIdInstances] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerMultipleDrbIdInstances;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownDrbId] = SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownDrbId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerInvalidQosCombination] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerInvalidQosCombination;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerProcedureCancelled] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerProcedureCancelled;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNormalRelease] = SAACPF_NRDC_CauseE1apRadioNetworkLayerNormalRelease;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNoRadioResourcesAvailable] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerNoRadioResourcesAvailable;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerActionDesirableForRadioReasons] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerActionDesirableForRadioReasons;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerResourcesNotAvailableForTheSlice] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerResourcesNotAvailableForTheSlice;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerPdcpConfigurationNotSupported] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerPdcpConfigurationNotSupported;
    wrapperCauseMap()[CauseE1apTransportLayerUnspecified] = SAACPF_NRDC_CauseE1apTransportLayerUnspecified;
    wrapperCauseMap()[CauseE1apTransportLayerTransportResourceUnavailable] =
        SAACPF_NRDC_CauseE1apTransportLayerTransportResourceUnavailable;
    wrapperCauseMap()[CauseE1apProtocolTransferSyntaxError] = SAACPF_NRDC_CauseE1apProtocolTransferSyntaxError;
    wrapperCauseMap()[CauseE1apProtocolAbstractSyntaxErrorReject] =
        SAACPF_NRDC_CauseE1apProtocolAbstractSyntaxErrorReject;
    wrapperCauseMap()[CauseE1apProtocolAbstractSyntaxErrorIgnoreAndNotify] =
        SAACPF_NRDC_CauseE1apProtocolAbstractSyntaxErrorIgnoreAndNotify;
    wrapperCauseMap()[CauseE1apProtocolMessageNotCompatibleWithReceiverState] =
        SAACPF_NRDC_CauseE1apProtocolMessageNotCompatibleWithReceiverState;
    wrapperCauseMap()[CauseE1apProtocolSemanticError] = SAACPF_NRDC_CauseE1apProtocolSemanticError;
    wrapperCauseMap()[CauseE1apProtocolAbstractSyntaxErrorFalselyConstructedMessage] =
        SAACPF_NRDC_CauseE1apProtocolAbstractSyntaxErrorFalselyConstructedMessage;
    wrapperCauseMap()[CauseE1apProtocolUnspecified] = SAACPF_NRDC_CauseE1apProtocolUnspecified;
    wrapperCauseMap()[CauseE1apMiscControlProcessingOverload] = SAACPF_NRDC_CauseE1apMiscControlProcessingOverload;
    wrapperCauseMap()[CauseE1apMiscNotEnoughUserPlaneProcessingResources] =
        SAACPF_NRDC_CauseE1apMiscNotEnoughUserPlaneProcessingResources;
    wrapperCauseMap()[CauseE1apMiscHardwareFailure] = SAACPF_NRDC_CauseE1apMiscHardwareFailure;
    wrapperCauseMap()[CauseE1apMiscOMIntervention] = SAACPF_NRDC_CauseE1apMiscOMIntervention;
    wrapperCauseMap()[CauseE1apMiscUnspecified] = SAACPF_NRDC_CauseE1apMiscUnspecified;
    wrapperCauseMap()[CauseCpInternalSaInvalidSecurityAlgorithm] = SAACPF_NRDC_CauseInternalInvalidSecurityAlgorithm;
    wrapperCauseMap()[CauseCpInternalSaConfigNotExist] = SAACPF_NRDC_CauseInternalConfigNotExist;
    wrapperCauseMap()[CauseF1apRadioReleaseDueToPreEmption] = SAACPF_NRDC_CauseF1apRadioReleaseDueToPreEmption;
    wrapperCauseMap()[CauseF1apRadioPlmnNotServedByTheGnbCu] = SAACPF_NRDC_CauseF1apRadioPlmnNotServedByTheGnbCu;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUeDlMaxIPDataRateReason] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerUeDlMaxIPDataRateReason;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUpIntegrityProtectionFailure] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerUpIntegrityProtectionFailure;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerReleaseDueToPreEmption] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerReleaseDueToPreEmption;
    wrapperCauseMap()[CauseCpInternalSaUeCapaNotSupported] = SAACPF_NRDC_CauseInternalUeCapaNotSupported;

    wrapperCauseMap()[CauseF1apRadioMultipleDrbIdInstances] = SAACPF_NRDC_CauseF1apRadioMultipleDrbIdInstances;
    wrapperCauseMap()[CauseF1apRadioUnknownDrbId] = SAACPF_NRDC_CauseF1apRadioUnknownDrbId;
    wrapperCauseMap()[CauseF1apRadioMultipleBhRlcChIdInstances] = SAACPF_NRDC_CauseF1apRadioMultipleBhRlcChIdInstances;
    wrapperCauseMap()[CauseF1apRadioUnknownBhRlcChId] = SAACPF_NRDC_CauseF1apRadioUnknownBhRlcChId;
    wrapperCauseMap()[CauseF1apRadioChoCpcResourcesToBeChanged] = SAACPF_NRDC_CauseF1apRadioChoCpcResourcesToBeChanged;
    wrapperCauseMap()[CauseF1apRadioNpnNotSupported] = SAACPF_NRDC_CauseF1apRadioNpnNotSupported;
    wrapperCauseMap()[CauseF1apRadioNpnAccessDenied] = SAACPF_NRDC_CauseF1apRadioNpnAccessDenied;
    wrapperCauseMap()[CauseF1apRadioGnbCuCellCapacityExceeded] = SAACPF_NRDC_CauseF1apRadioGnbCuCellCapacityExceeded;
    wrapperCauseMap()[CauseF1apRadioReportCharacteristicsEmpty] = SAACPF_NRDC_CauseF1apRadioReportCharacteristicsEmpty;
    wrapperCauseMap()[CauseF1apRadioExistingMeasurementID] = SAACPF_NRDC_CauseF1apRadioExistingMeasurementID;
    wrapperCauseMap()[CauseF1apRadioMeasurementTemporarilyNotAvailable] =
        SAACPF_NRDC_CauseF1apRadioMeasurementTemporarilyNotAvailable;
    wrapperCauseMap()[CauseF1apRadioMeasurementNotSupportedForTheObject] =
        SAACPF_NRDC_CauseF1apRadioMeasurementNotSupportedForTheObject;
    wrapperCauseMap()[CauseF1apRadioUnknownBAPAddress] = SAACPF_NRDC_CauseF1apRadioUnknownBAPAddress;
    wrapperCauseMap()[CauseF1apRadioUnknownBAPRoutingID] = SAACPF_NRDC_CauseF1apRadioUnknownBAPRoutingID;
    wrapperCauseMap()[CauseF1apRadioInsufficientUeCapabilities] = SAACPF_NRDC_CauseF1apRadioInsufficientUeCapabilities;
    wrapperCauseMap()[CauseF1apTransportUnknownTNLAddressForIAB] =
        SAACPF_NRDC_CauseF1apTransportUnknownTNLAddressForIAB;
    wrapperCauseMap()[CauseF1apTransportUnknownUPTNLInformationForIAB] =
        SAACPF_NRDC_CauseF1apTransportUnknownUPTNLInformationForIAB;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerRSNNotAvailableForTheUP] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerRSNNotAvailableForTheUP;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNPNNotSupported] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerNPNNotSupported;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerReportCharacteristicsEmpty] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerReportCharacteristicsEmpty;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerExistingMeasurementID] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerExistingMeasurementID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMeasurementTemporarilyNotAvailable] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerMeasurementTemporarilyNotAvailable;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMeasurementNotSupportedForTheObject] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerMeasurementNotSupportedForTheObject;
    wrapperCauseMap()[CauseE1apTransportLayerUnknownTNLAddressForIAB] =
        SAACPF_NRDC_CauseE1apTransportLayerUnknownTNLAddressForIAB;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerCellNotAvailable] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerCellNotAvailable;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerHandoverDesirableForRadioReasons] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerHandoverDesirableForRadioReasons;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerHandoverTargetNotAllowed] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerHandoverTargetNotAllowed;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNoRadioResourcesAvailableInTargetCell] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerNoRadioResourcesAvailableInTargetCell;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerPartialHandover] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerPartialHandover;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerReduceLoadInServingCell] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerReduceLoadInServingCell;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerResourceOptimisationHandover] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerResourceOptimisationHandover;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTimeCriticalHandover] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerTimeCriticalHandover;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTxnRelocOverallExpiry] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerTxnRelocOverallExpiry;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTxnRelocPrepExpiry] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerTxnRelocPrepExpiry;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnknownLocalNgranNodeUeXnapId] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerUnknownLocalNgranNodeUeXnapId;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerInconsistentRemoteNgranNodeUeXnapId] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerInconsistentRemoteNgranNodeUeXnapId;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerEncryptionAndOrIntegrityProtectionAlgorithmsNotSupported] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerEncryptionAndOrIntegrityProtectionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerProtectionAlgorithmsNotSupported] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerProtectionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMultiplePduSessionIdInstances] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerMultiplePduSessionIdInstances;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnknownPduSessionId] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerUnknownPduSessionId;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnknownQosFlowId] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerUnknownQosFlowId;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMultipleQosFlowIdInstances] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerMultipleQosFlowIdInstances;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerSwitchOffOngoing] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerSwitchOffOngoing;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNotSupported5qiValue] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerNotSupported5qiValue;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTxnDcOverallExpiry] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerTxnDcOverallExpiry;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTxnDcPrepExpiry] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerTxnDcPrepExpiry;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerActionDesirableForRadioReasons] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerActionDesirableForRadioReasons;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerReduceLoad] = SAACPF_NRDC_CauseXnapRadioNetworkLayerReduceLoad;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerResourceOptimisation] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerResourceOptimisation;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTimeCriticalAction] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerTimeCriticalAction;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTargetNotAllowed] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerTargetNotAllowed;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNoRadioResourcesAvailable] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerNoRadioResourcesAvailable;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerInvalidQosCombination] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerInvalidQosCombination;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerEncryptionAlgorithmsNotSupported] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerEncryptionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerProcedureCancelled] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerProcedureCancelled;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerRrmPurpose] = SAACPF_NRDC_CauseXnapRadioNetworkLayerRrmPurpose;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerImproveUserBitRate] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerImproveUserBitRate;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUserInactivity] = SAACPF_NRDC_CauseXnapRadioNetworkLayerUserInactivity;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerRadioConnectionWithUeLost] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerRadioConnectionWithUeLost;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerFailureInTheRadioInterfaceProcedure] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerFailureInTheRadioInterfaceProcedure;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerBearerOptionNotSupported] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerBearerOptionNotSupported;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUpIntegrityProtectionNotPossible] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerUpIntegrityProtectionNotPossible;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUpConfidentialityProtectionNotPossible] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerUpConfidentialityProtectionNotPossible;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerResourcesNotAvailableForTheSlice] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerResourcesNotAvailableForTheSlice;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUeMaximumIntegrityProtectedDataRateReason] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerUeMaximumIntegrityProtectedDataRateReason;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerCpIntegrityProtectionFailure] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerCpIntegrityProtectionFailure;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUpIntegrityProtectionFailure] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerUpIntegrityProtectionFailure;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerSlicesNotSupportedByNgran] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerSlicesNotSupportedByNgran;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMnMobility] = SAACPF_NRDC_CauseXnapRadioNetworkLayerMnMobility;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerSnMobility] = SAACPF_NRDC_CauseXnapRadioNetworkLayerSnMobility;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerCountReachesMaxValue] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerCountReachesMaxValue;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnknownOldNgranNodeUeXnapId] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerUnknownOldNgranNodeUeXnapId;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerPdcpOverload] = SAACPF_NRDC_CauseXnapRadioNetworkLayerPdcpOverload;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerDrbIdNotAvailable] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerDrbIdNotAvailable;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnspecified] = SAACPF_NRDC_CauseXnapRadioNetworkLayerUnspecified;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUeContextIdNotKnown] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerUeContextIdNotKnown;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNonRelocationOfContext] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerNonRelocationOfContext;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerCHOCPCResourcesToBeChanged] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerCHOCPCResourcesToBeChanged;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerRSNNotAvailableForTheUP] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerRSNNotAvailableForTheUP;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNPNAccessDenied] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerNPNAccessDenied;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerReportCharacteristicsEmpty] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerReportCharacteristicsEmpty;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerExistingMeasurementID] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerExistingMeasurementID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMeasurementTemporarilyNotAvailable] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerMeasurementTemporarilyNotAvailable;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMeasurementNotSupportedForTheObject] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerMeasurementNotSupportedForTheObject;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUEPowerSaving] = SAACPF_NRDC_CauseXnapRadioNetworkLayerUEPowerSaving;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNotExistingNGRANNode2MeasurementID] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerNotExistingNGRANNode2MeasurementID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerInsufficientUECapabilities] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerInsufficientUECapabilities;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNormalRelease] = SAACPF_NRDC_CauseXnapRadioNetworkLayerNormalRelease;
    wrapperCauseMap()[CauseXnapTransportLayerTransportResourceUnavailable] =
        SAACPF_NRDC_CauseXnapTransportLayerTransportResourceUnavailable;
    wrapperCauseMap()[CauseXnapTransportLayerUnspecified] = SAACPF_NRDC_CauseXnapTransportLayerUnspecified;
    wrapperCauseMap()[CauseXnapProtocolTransferSyntaxError] = SAACPF_NRDC_CauseXnapProtocolTransferSyntaxError;
    wrapperCauseMap()[CauseXnapProtocolAbstractSyntaxErrorReject] =
        SAACPF_NRDC_CauseXnapProtocolAbstractSyntaxErrorReject;
    wrapperCauseMap()[CauseXnapProtocolAbstractSyntaxErrorIgnoreAndNotify] =
        SAACPF_NRDC_CauseXnapProtocolAbstractSyntaxErrorIgnoreAndNotify;
    wrapperCauseMap()[CauseXnapProtocolMessageNotCompatibleWithReceiverState] =
        SAACPF_NRDC_CauseXnapProtocolMessageNotCompatibleWithReceiverState;
    wrapperCauseMap()[CauseXnapProtocolSemanticError] = SAACPF_NRDC_CauseXnapProtocolSemanticError;
    wrapperCauseMap()[CauseXnapProtocolAbstractSyntaxErrorFalselyConstructedMessage] =
        SAACPF_NRDC_CauseXnapProtocolAbstractSyntaxErrorFalselyConstructedMessage;
    wrapperCauseMap()[CauseXnapProtocolUnspecified] = SAACPF_NRDC_CauseXnapProtocolUnspecified;
    wrapperCauseMap()[CauseXnapMiscControlProcessingOverload] = SAACPF_NRDC_CauseXnapMiscControlProcessingOverload;
    wrapperCauseMap()[CauseXnapMiscHardwareFailure] = SAACPF_NRDC_CauseXnapMiscHardwareFailure;
    wrapperCauseMap()[CauseXnapMiscOMIntervention] = SAACPF_NRDC_CauseXnapMiscOMIntervention;
    wrapperCauseMap()[CauseXnapMiscNotEnoughUserPlaneProcessingResources] =
        SAACPF_NRDC_CauseXnapMiscNotEnoughUserPlaneProcessingResources;
    wrapperCauseMap()[CauseXnapMiscUnspecified] = SAACPF_NRDC_CauseXnapMiscUnspecified;
    wrapperCauseMap()[CauseCpInternalSaTmOutXNSgnbReconfigurationComplete] =
        SAACPF_NRDC_CauseInternalTmOutXNSgnbReconfigurationComplete;
    wrapperCauseMap()[CauseCpInternalCpSrbIntegrityFailure] = SAACPF_NRDC_CauseInternalCpSrbIntegrityFailure;
    wrapperCauseMap()[CauseF1apRadioScgActivationDeactivationFailure] =
        SAACPF_NRDC_CauseF1apRadioScgActivationDeactivationFailure;
    wrapperCauseMap()[CauseF1apRadioScgDeactivationFailureDueToDataTransmission] =
        SAACPF_NRDC_CauseF1apRadioScgDeactivationFailureDueToDataTransmission;
    wrapperCauseMap()[CauseF1apRadioRequestedItemNotSupportedOnTime] =
        SAACPF_NRDC_CauseF1apRadioRequestedItemNotSupportedOnTime;
    wrapperCauseMap()[CauseF1apRadioTatSdtExpiry] =
        SAACPF_NRDC_CauseF1apRadioTatSdtExpiry;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedGnbCuMbsF1apId] =
        SAACPF_NRDC_CauseF1apRadioUnknownOrAlreadyAllocatedGnbCuMbsF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedGnbDuMbsF1apId] =
        SAACPF_NRDC_CauseF1apRadioUnknownOrAlreadyAllocatedGnbDuMbsF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownOrInconsistentPairOfMbsF1apId] =
        SAACPF_NRDC_CauseF1apRadioUnknownOrInconsistentPairOfMbsF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownOrInconsistentMrbId] =
        SAACPF_NRDC_CauseF1apRadioUnknownOrInconsistentMrbId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerScgActivationDeactivationFailure] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerScgActivationDeactivationFailure;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerScgDeactivationFailureDueToDataTransmission] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerScgDeactivationFailureDueToDataTransmission;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpMbsE1apId] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpMbsE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpMbsE1apId] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpMbsE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfMbsE1apId] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfMbsE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrInconsistentMrbId] =
        SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownOrInconsistentMrbId;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerInsufficientUeCapabilities] =
        SAACPF_NRDC_CauseNgapRadioNetworkLayerInsufficientUeCapabilities;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerRedcapUeNotSupported] =
        SAACPF_NRDC_CauseNgapRadioNetworkLayerRedCapUeNotSupported;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUnknownMBSSessionID] =
        SAACPF_NRDC_CauseNgapRadioNetworkLayerUnknownMbsSessionId;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerIndicatedMBSSessionAreaInformationNotServedByTheGNB] =
        SAACPF_NRDC_CauseNgapRadioNetworkLayerIndicatedMbsSessionAreaInformationNotServedByTheGnb;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerInconsistentSliceInfoForTheSession] =
        SAACPF_NRDC_CauseNgapRadioNetworkLayerInconsistentSliceInfoForTheSession;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerMisalignedAssociationForMulticastUnicast] =
        SAACPF_NRDC_CauseNgapRadioNetworkLayerMisalignedAssociationForTheMulticastAndUnicastSessionsOrFlows;
    wrapperCauseMap()[CauseNgapNasUeNotInPlmnServingArea] =
        SAACPF_NRDC_CauseNgapNasUeNotInPlmnServingArea;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerScgActivationDeactivationFailure] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerScgActivationDeactivationFailure;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerScgDeactivationFailureDueToDataTransmission] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerScgDeactivationFailureDueToDataTransmission;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerValueOutOfAllowedRange] =
        SAACPF_NRDC_CauseXnapRadioNetworkLayerValueOutOfAllowedRange;
    wrapperCauseMap()[CauseCpInternalT310Expiry] =
        SAACPF_NRDC_CauseInternalT310Expiry;
    wrapperCauseMap()[CauseCpInternalRandomAccessProblem] =
        SAACPF_NRDC_CauseInternalRandomAccessProblem;
    wrapperCauseMap()[CauseCpInternalRlcMaxNumRetx] =
        SAACPF_NRDC_CauseInternalRlcMaxNumRetx;
    wrapperCauseMap()[CauseCpInternalSynchReconfigFailureScg] =
        SAACPF_NRDC_CauseInternalSynchReconfigFailureScg;
    wrapperCauseMap()[CauseCpInternalScgReconfigFailure] =
        SAACPF_NRDC_CauseInternalScgReconfigFailure;
    wrapperCauseMap()[CauseCpInternalT312Expiry] = 
        SAACPF_NRDC_CauseInternalT312Expiry;
    wrapperCauseMap()[CauseCpInternalSrb3IntegrityFailure] =
        SAACPF_NRDC_CauseInternalSrb3IntegrityFailure;
    wrapperCauseMap()[CauseCpInternalBeamFailureRecoveryFailure] =
        SAACPF_NRDC_CauseInternalBeamFailureRecoveryFailure;
    wrapperCauseMap()[CauseCpInternalScgFailureOthers] = 
        SAACPF_NRDC_CauseInternalScgFailureOthers;

    if (STAT_SA_CUCPCSL_NRDC_SN_PER_GNB_END == wrapperCauseMap().size())
        return NR_CSL_CAUSE_ERROR_NONE;
    else
        return NR_CSL_CAUSE_ERROR_VALIDATION_FAILED;
}

nr_csl_cause_error_e nr_csl_cause_get_sacp_nrdc_sn_pmCause(const cause_t cause, pmCause_t* pmCause)
{
    if (wrapperCauseMap().find(cause) == wrapperCauseMap().end())
    {
        return NR_CSL_CAUSE_ERROR_VALIDATION_FAILED;
    }

    if (NULL == pmCause)
    {
        return NR_CSL_CAUSE_ERROR_INVALID_PARAMETER;
    }

    *pmCause = wrapperCauseMap()[cause];
    return NR_CSL_CAUSE_ERROR_NONE;
}
