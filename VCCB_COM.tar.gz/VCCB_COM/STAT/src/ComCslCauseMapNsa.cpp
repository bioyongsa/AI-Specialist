#include <map>
#include <string>
#include "PM_TYPE_ID.h"
#include "cause_call_5g.h"
#include "ComCslCauseMap.h"

typedef std::map<cause_t, pmCause_t> pmCauseMap_type;

static pmCauseMap_type& wrapperCauseMap()
{
    static pmCauseMap_type causeMap;
    return causeMap;
}

nr_csl_cause_error_e nr_csl_cause_make_cp_map(void)
{
    wrapperCauseMap()[CAUSE_NO_FAULT] = ACPF_NoFault;
    wrapperCauseMap()[CauseCpInternalTmOutRrcConnectionReconfig] = ACPF_CauseInternalTmOutRrcConnectionReconfig;
    wrapperCauseMap()[CauseCpInternalTmOutF1UeContextSetup] = ACPF_CauseInternalTmOutF1UeContextSetup;
    wrapperCauseMap()[CauseCpInternalTmOutE1BearerSetup] = ACPF_CauseInternalTmOutE1BearerSetup;
    wrapperCauseMap()[CauseCpInternalTmOutE1BearerContextModification] =
        ACPF_CauseInternalTmOutE1BearerContextModification;
    wrapperCauseMap()[CauseCpInternalTmOutF1UeContextModification] = ACPF_CauseInternalTmOutF1UeContextModification;
    wrapperCauseMap()[CauseCpInternalTmOutF1UeContextRelease] = ACPF_CauseInternalTmOutF1UeContextRelease;
    wrapperCauseMap()[CauseCpInternalNsaTmOutX2SgnbReconfigurationComplete] =
        ACPF_CauseInternalTmOutX2SgnbReconfigurationComplete;
    wrapperCauseMap()[CauseCpInternalNsaTmOutX2ModificationConfirm] = ACPF_CauseInternalTmOutX2ModificationConfirm;
    wrapperCauseMap()[CauseCpInternalTmOutInternalResourceSetup] = ACPF_CauseInternalTmOutInternalResourceSetup;
    wrapperCauseMap()[CauseCpInternalF1SctpOutOfService] = ACPF_CauseInternalF1SctpOutOfService;
    wrapperCauseMap()[CauseCpInternalE1SctpOutOfService] = ACPF_CauseInternalE1SctpOutOfService;
    wrapperCauseMap()[CauseCpInternalNsaX2SctpOutOfService] = ACPF_CauseInternalX2SctpOutOfService;
    wrapperCauseMap()[CauseCpInternalMDSSendFail] = ACPF_CauseInternalMDSSendFail;
    wrapperCauseMap()[CauseCpInternalCacCallCountOver] = ACPF_CauseInternalCacCallCountOver;
    wrapperCauseMap()[CauseCpInternalNsaNotSupportedQci] = ACPF_CauseInternalNotSupportedQci;
    wrapperCauseMap()[CauseCpInternalInvalidCallContext] = ACPF_CauseInternalInvalidCallContext;
    wrapperCauseMap()[CauseCpInternalResourceAllocFail] = ACPF_CauseInternalResourceAllocFail;
    wrapperCauseMap()[CauseCpInternalOMIntervention] = ACPF_CauseInternalOMIntervention;
    wrapperCauseMap()[CauseCpInternalVmScaleIn] = ACPF_CauseInternalVmScaleIn;
    wrapperCauseMap()[CauseCpInternalCellRelease] = ACPF_CauseInternalCellRelease;
    wrapperCauseMap()[CauseCpInternalCallAllocationFail] = ACPF_CauseInternalCallAllocationFail;
    wrapperCauseMap()[CauseCpInternalUpAllocationFail] = ACPF_CauseInternalUpAllocationFail;
    wrapperCauseMap()[CauseCpInternalInvalidCallId] = ACPF_CauseInternalInvalidCallId;
    wrapperCauseMap()[CauseCpInternalInvalidPlmn] = ACPF_CauseInternalInvalidPlmn;
    wrapperCauseMap()[CauseCpInternalUserInactivity] = ACPF_CauseInternalUserInactivity;
    wrapperCauseMap()[CauseCpInternalNsaT310Expiry] = ACPF_CauseInternalT310Expiry;
    wrapperCauseMap()[CauseCpInternalNsaRandomAccessProblem] = ACPF_CauseInternalRandomAccessProblem;
    wrapperCauseMap()[CauseCpInternalNsaRlcMaxNumRetx] = ACPF_CauseInternalRlcMaxNumRetx;
    wrapperCauseMap()[CauseCpInternalNsaScgChangeFailure] = ACPF_CauseInternalScgChangeFailure;
    wrapperCauseMap()[CauseCpInternalNsaScgReconfigFailure] = ACPF_CauseInternalScgReconfigFailure;
    wrapperCauseMap()[CauseCpInternalNsaSrb3IntegrityFailure] = ACPF_CauseInternalSrb3IntegrityFailure;
    wrapperCauseMap()[CauseCpInternalScgMobility] = ACPF_CauseInternalScgMobility;
    wrapperCauseMap()[CauseCpInternalMeasurementReportBasedRelease] = ACPF_CauseInternalMeasurementReportBasedRelease;
    wrapperCauseMap()[CauseF1apRadioUnspecified] = ACPF_CauseF1apRadioUnspecified;
    wrapperCauseMap()[CauseF1apRadioRLFailure] = ACPF_CauseF1apRadioRLFailure;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedCuUeF1apId] =
        ACPF_CauseF1apRadioUnknownOrAlreadyAllocatedCuUeF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedDuUeF1apId] =
        ACPF_CauseF1apRadioUnknownOrAlreadyAllocatedDuUeF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownInconsistentPairOfUeF1apId] =
        ACPF_CauseF1apRadioUnknownInconsistentPairOfUeF1apId;
    wrapperCauseMap()[CauseF1apRadioInteraction] = ACPF_CauseF1apRadioInteraction;
    wrapperCauseMap()[CauseF1apRadioNotSupportedQCI] = ACPF_CauseF1apRadioNotSupportedQCI;
    wrapperCauseMap()[CauseF1apRadioDesirableRadioReasons] = ACPF_CauseF1apRadioDesirableRadioReasons;
    wrapperCauseMap()[CauseF1apRadioUnavailableRadioReasons] = ACPF_CauseF1apRadioUnavailableRadioReasons;
    wrapperCauseMap()[CauseF1apRadioProcedureCancelled] = ACPF_CauseF1apRadioProcedureCancelled;
    wrapperCauseMap()[CauseF1apRadioNormalRelease] = ACPF_CauseF1apRadioNormalRelease;
    wrapperCauseMap()[CauseF1apRadioCellNotAvailable] = ACPF_CauseF1apRadioCellNotAvailable;
    wrapperCauseMap()[CauseF1apRadioRLFailureothers] = ACPF_CauseF1apRadioRLFailureothers;
    wrapperCauseMap()[CauseF1apRadioUeRejection] = ACPF_CauseF1apRadioUeRejection;
    wrapperCauseMap()[CauseF1apRadioResourcesNotAvailableForTheSlice] =
        ACPF_CauseF1apRadioResourcesNotAvailableForTheSlice;
    wrapperCauseMap()[CauseF1apTransportUnspecified] = ACPF_CauseF1apTransportUnspecified;
    wrapperCauseMap()[CauseF1apTransportResourceUnavailable] = ACPF_CauseF1apTransportResourceUnavailable;
    wrapperCauseMap()[CauseF1apProtocolTransferSyntaxError] = ACPF_CauseF1apProtocolTransferSyntaxError;
    wrapperCauseMap()[CauseF1apProtocolAbstractSyntaxErrorReject] = ACPF_CauseF1apProtocolAbstractSyntaxErrorReject;
    wrapperCauseMap()[CauseF1apProtocolAbstractSyntaxErrorIgnore] = ACPF_CauseF1apProtocolAbstractSyntaxErrorIgnore;
    wrapperCauseMap()[CauseF1apProtocolMessageNotCompatible] = ACPF_CauseF1apProtocolMessageNotCompatible;
    wrapperCauseMap()[CauseF1apProtocolSemanticError] = ACPF_CauseF1apProtocolSemanticError;
    wrapperCauseMap()[CauseF1apProtocolAbstractSyntaxError] = ACPF_CauseF1apProtocolAbstractSyntaxError;
    wrapperCauseMap()[CauseF1apProtocolUnspecified] = ACPF_CauseF1apProtocolUnspecified;
    wrapperCauseMap()[CauseF1apMiscControlProcessingOverload] = ACPF_CauseF1apMiscControlProcessingOverload;
    wrapperCauseMap()[CauseF1apMiscUnavailableResources] = ACPF_CauseF1apMiscUnavailableResources;
    wrapperCauseMap()[CauseF1apMiscHardwareFailure] = ACPF_CauseF1apMiscHardwareFailure;
    wrapperCauseMap()[CauseF1apMiscOMIntervention] = ACPF_CauseF1apMiscOMIntervention;
    wrapperCauseMap()[CauseF1apMiscUnspecifiedFailure] = ACPF_CauseF1apMiscUnspecifiedFailure;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerHandoverDesirableForRadioReasons] =
        ACPF_CauseX2apRadioNetworkLayerHandoverDesirableForRadioReasons;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerTimeCriticalHandover] =
        ACPF_CauseX2apRadioNetworkLayerTimeCriticalHandover;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerResourceOptimisationHandover] =
        ACPF_CauseX2apRadioNetworkLayerResourceOptimisationHandover;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerReduceLoadInServingCell] =
        ACPF_CauseX2apRadioNetworkLayerReduceLoadInServingCell;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerPartialHandover] = ACPF_CauseX2apRadioNetworkLayerPartialHandover;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUnknownNewEnbUeX2apId] =
        ACPF_CauseX2apRadioNetworkLayerUnknownNewEnbUeX2apId;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUnknownOldEnbUeX2apId] =
        ACPF_CauseX2apRadioNetworkLayerUnknownOldEnbUeX2apId;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUnknownPairOfUeX2apId] =
        ACPF_CauseX2apRadioNetworkLayerUnknownPairOfUeX2apId;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerHoTargetNotAllowed] = ACPF_CauseX2apRadioNetworkLayerHoTargetNotAllowed;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerTx2relocoverallExpiry] =
        ACPF_CauseX2apRadioNetworkLayerTx2relocoverallExpiry;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerTrelocoverallExpiry] =
        ACPF_CauseX2apRadioNetworkLayerTrelocoverallExpiry;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerCellNotAvailable] = ACPF_CauseX2apRadioNetworkLayerCellNotAvailable;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerNoRadioResourcesAvailableInTargetCell] =
        ACPF_CauseX2apRadioNetworkLayerNoRadioResourcesAvailableInTargetCell;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerInvalidMMEGroupID] = ACPF_CauseX2apRadioNetworkLayerInvalidMMEGroupID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUnknownMMECode] = ACPF_CauseX2apRadioNetworkLayerUnknownMMECode;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerEncryptionAndOrIntegrityProtectionAlgorithmsNotSupported] =
        ACPF_CauseX2apRadioNetworkLayerEncryptionAndOrIntegrityProtectionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerReportCharacteristicsEmpty] =
        ACPF_CauseX2apRadioNetworkLayerReportCharacteristicsEmpty;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerNoReportPeriodicity] =
        ACPF_CauseX2apRadioNetworkLayerNoReportPeriodicity;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerExistingMeasurementID] =
        ACPF_CauseX2apRadioNetworkLayerExistingMeasurementID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUnknownEnbMeasurementID] =
        ACPF_CauseX2apRadioNetworkLayerUnknownEnbMeasurementID;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerMeasurementTemporarilyNotAvailable] =
        ACPF_CauseX2apRadioNetworkLayerMeasurementTemporarilyNotAvailable;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUnspecified] = ACPF_CauseX2apRadioNetworkLayerUnspecified;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerLoadBalancing] = ACPF_CauseX2apRadioNetworkLayerLoadBalancing;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerHandoverOptimisation] =
        ACPF_CauseX2apRadioNetworkLayerHandoverOptimisation;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerValueOutOfAllowedRange] =
        ACPF_CauseX2apRadioNetworkLayerValueOutOfAllowedRange;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerMultipleErabIdInstances] =
        ACPF_CauseX2apRadioNetworkLayerMultipleErabIdInstances;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerSwitchOffOngoing] = ACPF_CauseX2apRadioNetworkLayerSwitchOffOngoing;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerNotSupportedQciValue] =
        ACPF_CauseX2apRadioNetworkLayerNotSupportedQciValue;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerMeasurementNotSupportedForTheObject] =
        ACPF_CauseX2apRadioNetworkLayerMeasurementNotSupportedForTheObject;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerTdcoverallExpiry] = ACPF_CauseX2apRadioNetworkLayerTdcoverallExpiry;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerTdcprepExpiry] = ACPF_CauseX2apRadioNetworkLayerTdcprepExpiry;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerActionDesirableForRadioReasons] =
        ACPF_CauseX2apRadioNetworkLayerActionDesirableForRadioReasons;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerReduceLoad] = ACPF_CauseX2apRadioNetworkLayerReduceLoad;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerResourceOptimisation] =
        ACPF_CauseX2apRadioNetworkLayerResourceOptimisation;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerTimeCriticalAction] = ACPF_CauseX2apRadioNetworkLayerTimeCriticalAction;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerTargetNotAllowed] = ACPF_CauseX2apRadioNetworkLayerTargetNotAllowed;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerNoRadioResourcesAvailable] =
        ACPF_CauseX2apRadioNetworkLayerNoRadioResourcesAvailable;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerInvalidQosCombination] =
        ACPF_CauseX2apRadioNetworkLayerInvalidQosCombination;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerEncryptionAlgorithmsNotSupported] =
        ACPF_CauseX2apRadioNetworkLayerEncryptionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerProcedureCancelled] = ACPF_CauseX2apRadioNetworkLayerProcedureCancelled;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerRrmPurpose] = ACPF_CauseX2apRadioNetworkLayerRrmPurpose;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerImproveUserBitRate] = ACPF_CauseX2apRadioNetworkLayerImproveUserBitRate;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUserInactivity] = ACPF_CauseX2apRadioNetworkLayerUserInactivity;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerRadioConnectionWithUeLost] =
        ACPF_CauseX2apRadioNetworkLayerRadioConnectionWithUeLost;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerFailureInTheRadioInterfaceProcedure] =
        ACPF_CauseX2apRadioNetworkLayerFailureInTheRadioInterfaceProcedure;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerBearerOptionNotSupported] =
        ACPF_CauseX2apRadioNetworkLayerBearerOptionNotSupported;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerMcgMobility] = ACPF_CauseX2apRadioNetworkLayerMcgMobility;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerScgMobility] = ACPF_CauseX2apRadioNetworkLayerScgMobility;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerCountReachesMaxValue] =
        ACPF_CauseX2apRadioNetworkLayerCountReachesMaxValue;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUnknownOldEngnbUeX2apId] =
        ACPF_CauseX2apRadioNetworkLayerUnknownOldEngnbUeX2apId;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerPdcpOverload] = ACPF_CauseX2apRadioNetworkLayerPdcpOverload;
    wrapperCauseMap()[CauseX2apTransportNetworkLayerTransportResourceUnavailable] =
        ACPF_CauseX2apTransportNetworkLayerTransportResourceUnavailable;
    wrapperCauseMap()[CauseX2apTransportNetworkLayerUnspecified] = ACPF_CauseX2apTransportNetworkLayerUnspecified;
    wrapperCauseMap()[CauseX2apProtocolTransferSyntaxError] = ACPF_CauseX2apProtocolTransferSyntaxError;
    wrapperCauseMap()[CauseX2apProtocolAbstractSyntaxErrorReject] = ACPF_CauseX2apProtocolAbstractSyntaxErrorReject;
    wrapperCauseMap()[CauseX2apProtocolAbstractSyntaxErrorIgnoreAndNotify] =
        ACPF_CauseX2apProtocolAbstractSyntaxErrorIgnoreAndNotify;
    wrapperCauseMap()[CauseX2apProtocolMessageNotCompatibleWithReceiverState] =
        ACPF_CauseX2apProtocolMessageNotCompatibleWithReceiverState;
    wrapperCauseMap()[CauseX2apProtocolSemanticError] = ACPF_CauseX2apProtocolSemanticError;
    wrapperCauseMap()[CauseX2apProtocolUnspecified] = ACPF_CauseX2apProtocolUnspecified;
    wrapperCauseMap()[CauseX2apProtocolAbstractSyntaxErrorFalselyConstructedMessage] =
        ACPF_CauseX2apProtocolAbstractSyntaxErrorFalselyConstructedMessage;
    wrapperCauseMap()[CauseX2apMiscControlProcessingOverload] = ACPF_CauseX2apMiscControlProcessingOverload;
    wrapperCauseMap()[CauseX2apMiscHardwareFailure] = ACPF_CauseX2apMiscHardwareFailure;
    wrapperCauseMap()[CauseX2apMiscOMIntervention] = ACPF_CauseX2apMiscOMIntervention;
    wrapperCauseMap()[CauseX2apMiscNotEnoughUserPlaneProcessingResources] =
        ACPF_CauseX2apMiscNotEnoughUserPlaneProcessingResources;
    wrapperCauseMap()[CauseX2apMiscUnspecified] = ACPF_CauseX2apMiscUnspecified;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnspecified] = ACPF_CauseE1apRadioNetworkLayerUnspecified;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpUeE1apId] =
        ACPF_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpUeE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpUeE1apId] =
        ACPF_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpUeE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfUeE1apId] =
        ACPF_CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfUeE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerInteractionWithOtherProcedure] =
        ACPF_CauseE1apRadioNetworkLayerInteractionWithOtherProcedure;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerPdcpCountWrapAround] =
        ACPF_CauseE1apRadioNetworkLayerPdcpCountWrapAround;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNotSupportedQciValue] =
        ACPF_CauseE1apRadioNetworkLayerNotSupportedQciValue;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNotSupported5QiValue] =
        ACPF_CauseE1apRadioNetworkLayerNotSupported5QiValue;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerEncryptionAlgorithmsNotSupported] =
        ACPF_CauseE1apRadioNetworkLayerEncryptionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerIntegrityProtectionAlgorithmsNotSupported] =
        ACPF_CauseE1apRadioNetworkLayerIntegrityProtectionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUpIntegrityProtectionNotPossible] =
        ACPF_CauseE1apRadioNetworkLayerUpIntegrityProtectionNotPossible;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUpConfidentialityProtectionNotPossible] =
        ACPF_CauseE1apRadioNetworkLayerUpConfidentialityProtectionNotPossible;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMultiplePduSessionIdInstances] =
        ACPF_CauseE1apRadioNetworkLayerMultiplePduSessionIdInstances;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownPduSessionId] =
        ACPF_CauseE1apRadioNetworkLayerUnknownPduSessionId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMultipleQosFlowIdInstances] =
        ACPF_CauseE1apRadioNetworkLayerMultipleQosFlowIdInstances;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownQosFlowId] = ACPF_CauseE1apRadioNetworkLayerUnknownQosFlowId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMultipleDrbIdInstances] =
        ACPF_CauseE1apRadioNetworkLayerMultipleDrbIdInstances;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownDrbId] = ACPF_CauseE1apRadioNetworkLayerUnknownDrbId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerInvalidQosCombination] =
        ACPF_CauseE1apRadioNetworkLayerInvalidQosCombination;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerProcedureCancelled] = ACPF_CauseE1apRadioNetworkLayerProcedureCancelled;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNormalRelease] = ACPF_CauseE1apRadioNetworkLayerNormalRelease;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNoRadioResourcesAvailable] =
        ACPF_CauseE1apRadioNetworkLayerNoRadioResourcesAvailable;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerActionDesirableForRadioReasons] =
        ACPF_CauseE1apRadioNetworkLayerActionDesirableForRadioReasons;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerResourcesNotAvailableForTheSlice] =
        ACPF_CauseE1apRadioNetworkLayerResourcesNotAvailableForTheSlice;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerPdcpConfigurationNotSupported] =
        ACPF_CauseE1apRadioNetworkLayerPdcpConfigurationNotSupported;
    wrapperCauseMap()[CauseE1apTransportLayerUnspecified] = ACPF_CauseE1apTransportLayerUnspecified;
    wrapperCauseMap()[CauseE1apTransportLayerTransportResourceUnavailable] =
        ACPF_CauseE1apTransportLayerTransportResourceUnavailable;
    wrapperCauseMap()[CauseE1apProtocolTransferSyntaxError] = ACPF_CauseE1apProtocolTransferSyntaxError;
    wrapperCauseMap()[CauseE1apProtocolAbstractSyntaxErrorReject] = ACPF_CauseE1apProtocolAbstractSyntaxErrorReject;
    wrapperCauseMap()[CauseE1apProtocolAbstractSyntaxErrorIgnoreAndNotify] =
        ACPF_CauseE1apProtocolAbstractSyntaxErrorIgnoreAndNotify;
    wrapperCauseMap()[CauseE1apProtocolMessageNotCompatibleWithReceiverState] =
        ACPF_CauseE1apProtocolMessageNotCompatibleWithReceiverState;
    wrapperCauseMap()[CauseE1apProtocolSemanticError] = ACPF_CauseE1apProtocolSemanticError;
    wrapperCauseMap()[CauseE1apProtocolAbstractSyntaxErrorFalselyConstructedMessage] =
        ACPF_CauseE1apProtocolAbstractSyntaxErrorFalselyConstructedMessage;
    wrapperCauseMap()[CauseE1apProtocolUnspecified] = ACPF_CauseE1apProtocolUnspecified;
    wrapperCauseMap()[CauseE1apMiscControlProcessingOverload] = ACPF_CauseE1apMiscControlProcessingOverload;
    wrapperCauseMap()[CauseE1apMiscNotEnoughUserPlaneProcessingResources] =
        ACPF_CauseE1apMiscNotEnoughUserPlaneProcessingResources;
    wrapperCauseMap()[CauseE1apMiscHardwareFailure] = ACPF_CauseE1apMiscHardwareFailure;
    wrapperCauseMap()[CauseE1apMiscOMIntervention] = ACPF_CauseE1apMiscOMIntervention;
    wrapperCauseMap()[CauseE1apMiscUnspecified] = ACPF_CauseE1apMiscUnspecified;
    wrapperCauseMap()[CauseCpInternalDuULRadioLinkFailure] = ACPF_CauseInternalDuULRadioLinkFailure;
    wrapperCauseMap()[CauseCpInternalDuRlcMaxNumRetx] = ACPF_CauseInternalDuRlcMaxNumRetx;
    wrapperCauseMap()[CauseCpInternalCpSrb3IntegrityFailure] = ACPF_CauseInternalCpSrb3IntegrityFailure;
    wrapperCauseMap()[CauseCpInternalCuOverload] = ACPF_CauseInternalCuOverload;
    wrapperCauseMap()[CauseCpInternalStoreRrcMessageError] = ACPF_CauseCpInternalStoreRrcMessageError;
    wrapperCauseMap()[CauseCpInternalStoreE1MessageError] = ACPF_CauseCpInternalStoreE1MessageError;
    wrapperCauseMap()[CauseCpInternalStoreF1MessageError] = ACPF_CauseCpInternalStoreF1MessageError;
    wrapperCauseMap()[CauseCpInternalSendRrcMessageError] = ACPF_CauseCpInternalSendRrcMessageError;
    wrapperCauseMap()[CauseCpInternalSendE1MessageError] = ACPF_CauseCpInternalSendE1MessageError;
    wrapperCauseMap()[CauseCpInternalSendF1MessageError] = ACPF_CauseCpInternalSendF1MessageError;
    wrapperCauseMap()[CauseCpInternalNsaStoreX2MessageError] = ACPF_CauseCpInternalStoreX2MessageError;
    wrapperCauseMap()[CauseCpInternalNsaSendX2MessageError] = ACPF_CauseCpInternalSendX2MessageError;
    wrapperCauseMap()[CauseCpInternalNsaTmOutX2ChangeConfirm] = ACPF_CauseCpInternalTmOutX2ChangeConfirm;
    wrapperCauseMap()[CauseCpInternalNsaTmOutX2SNStatusTransfer] = ACPF_CauseCpInternalTmOutX2SNStatusTransfer;
    wrapperCauseMap()[CauseCpInternalNsaSpCellSelectionFail] = ACPF_CauseCpInternalSpCellSelectionFail;
    wrapperCauseMap()[CauseCpInternalInvalidCellId] = ACPF_CauseCpInternalInvalidCellId;
    wrapperCauseMap()[CauseF1apRadioAmfInitiatedAbnormalRelease] = ACPF_CauseF1apRadioAmfInitiatedAbnormalRelease;
    wrapperCauseMap()[CauseF1apRadioReleaseDueToPreEmption] = ACPF_CauseF1apRadioReleaseDueToPreEmption;
    wrapperCauseMap()[CauseF1apRadioPlmnNotServedByTheGnbCu] = ACPF_CauseF1apRadioPlmnNotServedByTheGnbCu;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUeDlMaxIPDataRateReason] =
        ACPF_CauseE1apRadioNetworkLayerUeDlMaxIPDataRateReason;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUpIntegrityProtectionFailure] =
        ACPF_CauseE1apRadioNetworkLayerUpIntegrityProtectionFailure;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerReleaseDueToPreEmption] =
        ACPF_CauseE1apRadioNetworkLayerReleaseDueToPreEmption;
    wrapperCauseMap()[CauseCpInternalNsaTmOutResumeForMrBased] = ACPF_CauseInternalTmOutResumeForMrBased;
    wrapperCauseMap()[CauseCpInternalNsaSynchReconfigFailureScg] = ACPF_CauseInternalSynchReconfigFailureScg;
    wrapperCauseMap()[CauseCpInternalNsaX2UEContextRelease] = ACPF_CauseInternalX2UEContextRelease;
    wrapperCauseMap()[CauseCpInternalNsaT312Expiry] = ACPF_CauseInternalT312Expiry;
    wrapperCauseMap()[CauseCpInternalNsaBeamFailureRecoveryFailure] = ACPF_CauseInternalBeamFailureRecoveryFailure;
    wrapperCauseMap()[CauseF1apRadioMultipleDrbIdInstances] = ACPF_CauseF1apRadioMultipleDrbIdInstances;
    wrapperCauseMap()[CauseF1apRadioUnknownDrbId] = ACPF_CauseF1apRadioUnknownDrbId;
    wrapperCauseMap()[CauseF1apRadioMultipleBhRlcChIdInstances] = ACPF_CauseF1apRadioMultipleBhRlcChIdInstances;
    wrapperCauseMap()[CauseF1apRadioUnknownBhRlcChId] = ACPF_CauseF1apRadioUnknownBhRlcChId;
    wrapperCauseMap()[CauseF1apRadioChoCpcResourcesToBeChanged] = ACPF_CauseF1apRadioChoCpcResourcesToBeChanged;
    wrapperCauseMap()[CauseF1apRadioNpnNotSupported] = ACPF_CauseF1apRadioNpnNotSupported;
    wrapperCauseMap()[CauseF1apRadioNpnAccessDenied] = ACPF_CauseF1apRadioNpnAccessDenied;
    wrapperCauseMap()[CauseF1apRadioGnbCuCellCapacityExceeded] = ACPF_CauseF1apRadioGnbCuCellCapacityExceeded;
    wrapperCauseMap()[CauseF1apRadioReportCharacteristicsEmpty] = ACPF_CauseF1apRadioReportCharacteristicsEmpty;
    wrapperCauseMap()[CauseF1apRadioExistingMeasurementID] = ACPF_CauseF1apRadioExistingMeasurementID;
    wrapperCauseMap()[CauseF1apRadioMeasurementTemporarilyNotAvailable] =
        ACPF_CauseF1apRadioMeasurementTemporarilyNotAvailable;
    wrapperCauseMap()[CauseF1apRadioMeasurementNotSupportedForTheObject] =
        ACPF_CauseF1apRadioMeasurementNotSupportedForTheObject;
    wrapperCauseMap()[CauseF1apRadioUnknownBAPAddress] = ACPF_CauseF1apRadioUnknownBAPAddress;
    wrapperCauseMap()[CauseF1apRadioUnknownBAPRoutingID] = ACPF_CauseF1apRadioUnknownBAPRoutingID;
    wrapperCauseMap()[CauseF1apRadioInsufficientUeCapabilities] = ACPF_CauseF1apRadioInsufficientUeCapabilities;
    wrapperCauseMap()[CauseF1apTransportUnknownTNLAddressForIAB] = ACPF_CauseF1apTransportUnknownTNLAddressForIAB;
    wrapperCauseMap()[CauseF1apTransportUnknownUPTNLInformationForIAB] =
        ACPF_CauseF1apTransportUnknownUPTNLInformationForIAB;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerRSNNotAvailableForTheUP] =
        ACPF_CauseE1apRadioNetworkLayerRSNNotAvailableForTheUP;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNPNNotSupported] = ACPF_CauseE1apRadioNetworkLayerNPNNotSupported;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerReportCharacteristicsEmpty] =
        ACPF_CauseE1apRadioNetworkLayerReportCharacteristicsEmpty;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerExistingMeasurementID] =
        ACPF_CauseE1apRadioNetworkLayerExistingMeasurementID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMeasurementTemporarilyNotAvailable] =
        ACPF_CauseE1apRadioNetworkLayerMeasurementTemporarilyNotAvailable;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMeasurementNotSupportedForTheObject] =
        ACPF_CauseE1apRadioNetworkLayerMeasurementNotSupportedForTheObject;
    wrapperCauseMap()[CauseE1apTransportLayerUnknownTNLAddressForIAB] =
        ACPF_CauseE1apTransportLayerUnknownTNLAddressForIAB;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerCHOCPCResourcesToBeChanged] =
        ACPF_CauseX2apRadioNetworkLayerCHOCPCResourcesToBeChanged;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUEPowerSaving] = ACPF_CauseX2apRadioNetworkLayerUEPowerSaving;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerInsufficientUeCapabilities] =
        ACPF_CauseX2apRadioNetworkLayerInsufficientUeCapabilities;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerNormalRelease] = ACPF_CauseX2apRadioNetworkLayerNormalRelease;
    wrapperCauseMap()[CauseCpInternalCpSrbIntegrityFailure] = ACPF_CauseInternalCpSrbIntegrityFailure;
    wrapperCauseMap()[CauseCpInternalNsaRandomAccessProblemAfterInitialAccess] =
        ACPF_CauseInternalRandomAccessProblemAfterInitialAccess;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerScgActivationDeactivationFailure] =
        ACPF_CauseE1apRadioNetworkLayerScgActivationDeactivationFailure;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerScgDeactivationFailureDueToDataTransmission] =
        ACPF_CauseE1apRadioNetworkLayerScgDeactivationFailureDueToDataTransmission;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpMbsE1apId] =
        ACPF_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpMbsE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpMbsE1apId] =
        ACPF_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpMbsE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfMbsE1apId] =
        ACPF_CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfMbsE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrInconsistentMrbId] =
        ACPF_CauseE1apRadioNetworkLayerUnknownOrInconsistentMrbId;
    wrapperCauseMap()[CauseF1apRadioScgActivationDeactivationFailure] =
        ACPF_CauseF1apRadioScgActivationDeactivationFailure;
    wrapperCauseMap()[CauseF1apRadioScgDeactivationFailureDueToDataTransmission] =
        ACPF_CauseF1apRadioScgDeactivationFailureDueToDataTransmission;
    wrapperCauseMap()[CauseF1apRadioRequestedItemNotSupportedOnTime] =
        ACPF_CauseF1apRadioRequestedItemNotSupportedOnTime;
    wrapperCauseMap()[CauseF1apRadioTatSdtExpiry] =
        ACPF_CauseF1apRadioTatSdtExpiry;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedGnbCuMbsF1apId] =
        ACPF_CauseF1apRadioUnknownOrAlreadyAllocatedGnbCuMbsF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedGnbDuMbsF1apId] =
        ACPF_CauseF1apRadioUnknownOrAlreadyAllocatedGnbDuMbsF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownOrInconsistentPairOfMbsF1apId] =
        ACPF_CauseF1apRadioUnknownOrInconsistentPairOfMbsF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownOrInconsistentMrbId] =
        ACPF_CauseF1apRadioUnknownOrInconsistentMrbId;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUnknownEutranNodeMeasurementId] =
        ACPF_CauseX2apRadioNetworkLayerUnknownEutranNodeMeasurementId;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerScgActivationDeactivationFailure] =
        ACPF_CauseX2apRadioNetworkLayerScgActivationDeactivationFailure;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerScgDeactivationFailureDueToDataTransmission] =
        ACPF_CauseX2apRadioNetworkLayerScgDeactivationFailureDueToDataTransmission;
    wrapperCauseMap()[CauseX2apRadioNetworkLayerUpIntegrityProtectionNotPossible] =
        ACPF_CauseX2apRadioNetworkLayerUpIntegrityProtectionNotPossible;

    if (STAT_CUCPCSL_PER_GNB_END == wrapperCauseMap().size())
        return NR_CSL_CAUSE_ERROR_NONE;
    else
        return NR_CSL_CAUSE_ERROR_VALIDATION_FAILED;
}

nr_csl_cause_error_e nr_csl_cause_get_cp_pmCause(const cause_t cause, pmCause_t* pmCause)
{
    if (wrapperCauseMap().find(cause) == wrapperCauseMap().end())
    {
        return NR_CSL_CAUSE_ERROR_VALIDATION_FAILED;
    }

    if (NULL == pmCause)
    {
        return NR_CSL_CAUSE_ERROR_INVALID_PARAMETER;
    }

    *pmCause = wrapperCauseMap()[cause];
    return NR_CSL_CAUSE_ERROR_NONE;
}
