#include <map>
#include <string>
#include "PM_TYPE_ID.h"
#include "cause_call_5g.h"
#include "ComCslCauseMap.h"

typedef std::map<cause_t, pmCause_t> pmCauseMap_type;

static pmCauseMap_type& wrapperCauseMap()
{
    static pmCauseMap_type causeMap;
    return causeMap;
}

nr_csl_cause_error_e nr_csl_cause_make_sacp_map(void)
{
    wrapperCauseMap()[CAUSE_NO_FAULT] = SAACPF_NoFault;
    wrapperCauseMap()[CauseCpInternalTmOutRrcConnectionReconfig] = SAACPF_CauseInternalTmOutRrcConnectionReconfig;
    wrapperCauseMap()[CauseCpInternalTmOutF1UeContextSetup] = SAACPF_CauseInternalTmOutF1UeContextSetup;
    wrapperCauseMap()[CauseCpInternalTmOutE1BearerSetup] = SAACPF_CauseInternalTmOutE1BearerSetup;
    wrapperCauseMap()[CauseCpInternalTmOutE1BearerContextModification] =
        SAACPF_CauseInternalTmOutE1BearerContextModification;
    wrapperCauseMap()[CauseCpInternalTmOutF1UeContextModification] = SAACPF_CauseInternalTmOutF1UeContextModification;
    wrapperCauseMap()[CauseCpInternalTmOutF1UeContextRelease] = SAACPF_CauseInternalTmOutF1UeContextRelease;
    wrapperCauseMap()[CauseCpInternalTmOutInternalResourceSetup] = SAACPF_CauseInternalTmOutInternalResourceSetup;
    wrapperCauseMap()[CauseCpInternalF1SctpOutOfService] = SAACPF_CauseInternalF1SctpOutOfService;
    wrapperCauseMap()[CauseCpInternalE1SctpOutOfService] = SAACPF_CauseInternalE1SctpOutOfService;
    wrapperCauseMap()[CauseCpInternalMDSSendFail] = SAACPF_CauseInternalMDSSendFail;
    wrapperCauseMap()[CauseCpInternalCacCallCountOver] = SAACPF_CauseInternalCacCallCountOver;
    wrapperCauseMap()[CauseCpInternalInvalidCallContext] = SAACPF_CauseInternalInvalidCallContext;
    wrapperCauseMap()[CauseCpInternalResourceAllocFail] = SAACPF_CauseInternalResourceAllocFail;
    wrapperCauseMap()[CauseCpInternalOMIntervention] = SAACPF_CauseInternalOMIntervention;
    wrapperCauseMap()[CauseCpInternalVmScaleIn] = SAACPF_CauseInternalVmScaleIn;
    wrapperCauseMap()[CauseCpInternalCellRelease] = SAACPF_CauseInternalCellRelease;
    wrapperCauseMap()[CauseCpInternalCallAllocationFail] = SAACPF_CauseInternalCallAllocationFail;
    wrapperCauseMap()[CauseCpInternalUpAllocationFail] = SAACPF_CauseInternalUpAllocationFail;
    wrapperCauseMap()[CauseCpInternalInvalidCallId] = SAACPF_CauseInternalInvalidCallId;
    wrapperCauseMap()[CauseCpInternalInvalidPlmn] = SAACPF_CauseInternalInvalidPlmn;
    wrapperCauseMap()[CauseCpInternalUserInactivity] = SAACPF_CauseInternalUserInactivity;
    wrapperCauseMap()[CauseCpInternalScgMobility] = SAACPF_CauseInternalScgMobility;
    wrapperCauseMap()[CauseCpInternalMeasurementReportBasedRelease] = SAACPF_CauseInternalMeasurementReportBasedRelease;
    wrapperCauseMap()[CauseCpInternalDuULRadioLinkFailure] = SAACPF_CauseInternalDuULRadioLinkFailure;
    wrapperCauseMap()[CauseCpInternalDuRlcMaxNumRetx] = SAACPF_CauseInternalDuRlcMaxNumRetx;
    wrapperCauseMap()[CauseCpInternalCpSrb3IntegrityFailure] = SAACPF_CauseInternalCpSrb3IntegrityFailure;
    wrapperCauseMap()[CauseCpInternalCuOverload] = SAACPF_CauseInternalCuOverload;
    wrapperCauseMap()[CauseCpInternalStoreRrcMessageError] = SAACPF_CauseInternalStoreRrcMessageError;
    wrapperCauseMap()[CauseCpInternalStoreE1MessageError] = SAACPF_CauseInternalStoreE1MessageError;
    wrapperCauseMap()[CauseCpInternalStoreF1MessageError] = SAACPF_CauseInternalStoreF1MessageError;
    wrapperCauseMap()[CauseCpInternalSendRrcMessageError] = SAACPF_CauseInternalSendRrcMessageError;
    wrapperCauseMap()[CauseCpInternalSendE1MessageError] = SAACPF_CauseInternalSendE1MessageError;
    wrapperCauseMap()[CauseCpInternalSendF1MessageError] = SAACPF_CauseInternalSendF1MessageError;
    wrapperCauseMap()[CauseCpInternalSaTmOutNgInitialContextSetup] = SAACPF_CauseInternalTmOutNgInitialContextSetup;
    wrapperCauseMap()[CauseCpInternalSaTmOutRrcSetup] = SAACPF_CauseInternalTmOutRrcSetup;
    wrapperCauseMap()[CauseCpInternalSaTmOutRrcUeCapabilityEnquiry] = SAACPF_CauseInternalTmOutRrcUeCapabilityEnquiry;
    wrapperCauseMap()[CauseCpInternalSaTmOutRrcSecurityModeCommand] = SAACPF_CauseInternalTmOutRrcSecurityModeCommand;
    wrapperCauseMap()[CauseCpInternalSaHoTmOutNgDownlinkRanStatusTransfer] =
        SAACPF_CauseInternalHoTmOutNgDownlinkRanStatusTransfer;
    wrapperCauseMap()[CauseCpInternalSaHoTmOutNgPathSwitchRequest] = SAACPF_CauseInternalHoTmOutNgPathSwitchRequest;
    wrapperCauseMap()[CauseCpInternalSaHoTmOutNgRelocOverall] = SAACPF_CauseInternalHoTmOutNgRelocOverall;
    wrapperCauseMap()[CauseCpInternalSaHoTmOutXnSNStatusTransfer] = SAACPF_CauseInternalHoTmOutXnSNStatusTransfer;
    wrapperCauseMap()[CauseCpInternalSaHoTmOutXnRelocOverall] = SAACPF_CauseInternalHoTmOutXnRelocOverall;
    wrapperCauseMap()[CauseCpInternalSaHoTmOutRrcHandoverComplete] = SAACPF_CauseInternalHoTmOutRrcHandoverComplete;
    wrapperCauseMap()[CauseCpInternalSaNgSctpOutOfService] = SAACPF_CauseInternalNgSctpOutOfService;
    wrapperCauseMap()[CauseCpInternalSaXnSctpOutOfService] = SAACPF_CauseInternalXnSctpOutOfService;
    wrapperCauseMap()[CauseCpInternalSaAllAmfNotService] = SAACPF_CauseInternalAllAmfNotService;
    wrapperCauseMap()[CauseCpInternalSaNotExistAmf] = SAACPF_CauseInternalNotExistAmf;
    wrapperCauseMap()[CauseCpInternalSaAvailableAmfNotExist] = SAACPF_CauseInternalAvailableAmfNotExist;
    wrapperCauseMap()[CauseCpInternalSaDuCallAllocationFail] = SAACPF_CauseInternalDuCallAllocationFail;
    wrapperCauseMap()[CauseCpInternalSaRedirectionRelease] = SAACPF_CauseInternalRedirectionRelease;
    wrapperCauseMap()[CauseCpInternalSaNotSupported5qiValue] = SAACPF_CauseInternalNotSupported5qiValue;
    wrapperCauseMap()[CauseCpInternalSaStoreNgMessageError] = SAACPF_CauseInternalStoreNgMessageError;
    wrapperCauseMap()[CauseCpInternalSaStoreXnMessageError] = SAACPF_CauseInternalStoreXnMessageError;
    wrapperCauseMap()[CauseCpInternalSaSendNgMessageError] = SAACPF_CauseInternalSendNgMessageError;
    wrapperCauseMap()[CauseCpInternalSaSendXnMessageError] = SAACPF_CauseInternalSendXnMessageError;
    wrapperCauseMap()[CauseCpInternalSaRreOldCallRelease] = SAACPF_CauseInternalRreOldCallRelease;
    wrapperCauseMap()[CauseCpInternalSaTmOutRrcReestablishment] = SAACPF_CauseInternalTmOutRrcReestablishment;
    wrapperCauseMap()[CauseF1apRadioUnspecified] = SAACPF_CauseF1apRadioUnspecified;
    wrapperCauseMap()[CauseF1apRadioRLFailure] = SAACPF_CauseF1apRadioRLFailure;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedCuUeF1apId] =
        SAACPF_CauseF1apRadioUnknownOrAlreadyAllocatedCuUeF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedDuUeF1apId] =
        SAACPF_CauseF1apRadioUnknownOrAlreadyAllocatedDuUeF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownInconsistentPairOfUeF1apId] =
        SAACPF_CauseF1apRadioUnknownInconsistentPairOfUeF1apId;
    wrapperCauseMap()[CauseF1apRadioInteraction] = SAACPF_CauseF1apRadioInteraction;
    wrapperCauseMap()[CauseF1apRadioNotSupportedQCI] = SAACPF_CauseF1apRadioNotSupportedQCI;
    wrapperCauseMap()[CauseF1apRadioDesirableRadioReasons] = SAACPF_CauseF1apRadioDesirableRadioReasons;
    wrapperCauseMap()[CauseF1apRadioUnavailableRadioReasons] = SAACPF_CauseF1apRadioUnavailableRadioReasons;
    wrapperCauseMap()[CauseF1apRadioProcedureCancelled] = SAACPF_CauseF1apRadioProcedureCancelled;
    wrapperCauseMap()[CauseF1apRadioNormalRelease] = SAACPF_CauseF1apRadioNormalRelease;
    wrapperCauseMap()[CauseF1apRadioCellNotAvailable] = SAACPF_CauseF1apRadioCellNotAvailable;
    wrapperCauseMap()[CauseF1apRadioRLFailureothers] = SAACPF_CauseF1apRadioRLFailureothers;
    wrapperCauseMap()[CauseF1apRadioUeRejection] = SAACPF_CauseF1apRadioUeRejection;
    wrapperCauseMap()[CauseF1apRadioResourcesNotAvailableForTheSlice] =
        SAACPF_CauseF1apRadioResourcesNotAvailableForTheSlice;
    wrapperCauseMap()[CauseF1apTransportUnspecified] = SAACPF_CauseF1apTransportUnspecified;
    wrapperCauseMap()[CauseF1apTransportResourceUnavailable] = SAACPF_CauseF1apTransportResourceUnavailable;
    wrapperCauseMap()[CauseF1apProtocolTransferSyntaxError] = SAACPF_CauseF1apProtocolTransferSyntaxError;
    wrapperCauseMap()[CauseF1apProtocolAbstractSyntaxErrorReject] = SAACPF_CauseF1apProtocolAbstractSyntaxErrorReject;
    wrapperCauseMap()[CauseF1apProtocolAbstractSyntaxErrorIgnore] = SAACPF_CauseF1apProtocolAbstractSyntaxErrorIgnore;
    wrapperCauseMap()[CauseF1apProtocolMessageNotCompatible] = SAACPF_CauseF1apProtocolMessageNotCompatible;
    wrapperCauseMap()[CauseF1apProtocolSemanticError] = SAACPF_CauseF1apProtocolSemanticError;
    wrapperCauseMap()[CauseF1apProtocolAbstractSyntaxError] = SAACPF_CauseF1apProtocolAbstractSyntaxError;
    wrapperCauseMap()[CauseF1apProtocolUnspecified] = SAACPF_CauseF1apProtocolUnspecified;
    wrapperCauseMap()[CauseF1apMiscControlProcessingOverload] = SAACPF_CauseF1apMiscControlProcessingOverload;
    wrapperCauseMap()[CauseF1apMiscUnavailableResources] = SAACPF_CauseF1apMiscUnavailableResources;
    wrapperCauseMap()[CauseF1apMiscHardwareFailure] = SAACPF_CauseF1apMiscHardwareFailure;
    wrapperCauseMap()[CauseF1apMiscOMIntervention] = SAACPF_CauseF1apMiscOMIntervention;
    wrapperCauseMap()[CauseF1apMiscUnspecifiedFailure] = SAACPF_CauseF1apMiscUnspecifiedFailure;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnspecified] = SAACPF_CauseE1apRadioNetworkLayerUnspecified;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpUeE1apId] =
        SAACPF_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpUeE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpUeE1apId] =
        SAACPF_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpUeE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfUeE1apId] =
        SAACPF_CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfUeE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerInteractionWithOtherProcedure] =
        SAACPF_CauseE1apRadioNetworkLayerInteractionWithOtherProcedure;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerPdcpCountWrapAround] =
        SAACPF_CauseE1apRadioNetworkLayerPdcpCountWrapAround;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNotSupportedQciValue] =
        SAACPF_CauseE1apRadioNetworkLayerNotSupportedQciValue;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNotSupported5QiValue] =
        SAACPF_CauseE1apRadioNetworkLayerNotSupported5QiValue;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerEncryptionAlgorithmsNotSupported] =
        SAACPF_CauseE1apRadioNetworkLayerEncryptionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerIntegrityProtectionAlgorithmsNotSupported] =
        SAACPF_CauseE1apRadioNetworkLayerIntegrityProtectionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUpIntegrityProtectionNotPossible] =
        SAACPF_CauseE1apRadioNetworkLayerUpIntegrityProtectionNotPossible;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUpConfidentialityProtectionNotPossible] =
        SAACPF_CauseE1apRadioNetworkLayerUpConfidentialityProtectionNotPossible;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMultiplePduSessionIdInstances] =
        SAACPF_CauseE1apRadioNetworkLayerMultiplePduSessionIdInstances;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownPduSessionId] =
        SAACPF_CauseE1apRadioNetworkLayerUnknownPduSessionId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMultipleQosFlowIdInstances] =
        SAACPF_CauseE1apRadioNetworkLayerMultipleQosFlowIdInstances;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownQosFlowId] = SAACPF_CauseE1apRadioNetworkLayerUnknownQosFlowId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMultipleDrbIdInstances] =
        SAACPF_CauseE1apRadioNetworkLayerMultipleDrbIdInstances;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownDrbId] = SAACPF_CauseE1apRadioNetworkLayerUnknownDrbId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerInvalidQosCombination] =
        SAACPF_CauseE1apRadioNetworkLayerInvalidQosCombination;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerProcedureCancelled] =
        SAACPF_CauseE1apRadioNetworkLayerProcedureCancelled;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNormalRelease] = SAACPF_CauseE1apRadioNetworkLayerNormalRelease;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNoRadioResourcesAvailable] =
        SAACPF_CauseE1apRadioNetworkLayerNoRadioResourcesAvailable;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerActionDesirableForRadioReasons] =
        SAACPF_CauseE1apRadioNetworkLayerActionDesirableForRadioReasons;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerResourcesNotAvailableForTheSlice] =
        SAACPF_CauseE1apRadioNetworkLayerResourcesNotAvailableForTheSlice;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerPdcpConfigurationNotSupported] =
        SAACPF_CauseE1apRadioNetworkLayerPdcpConfigurationNotSupported;
    wrapperCauseMap()[CauseE1apTransportLayerUnspecified] = SAACPF_CauseE1apTransportLayerUnspecified;
    wrapperCauseMap()[CauseE1apTransportLayerTransportResourceUnavailable] =
        SAACPF_CauseE1apTransportLayerTransportResourceUnavailable;
    wrapperCauseMap()[CauseE1apProtocolTransferSyntaxError] = SAACPF_CauseE1apProtocolTransferSyntaxError;
    wrapperCauseMap()[CauseE1apProtocolAbstractSyntaxErrorReject] = SAACPF_CauseE1apProtocolAbstractSyntaxErrorReject;
    wrapperCauseMap()[CauseE1apProtocolAbstractSyntaxErrorIgnoreAndNotify] =
        SAACPF_CauseE1apProtocolAbstractSyntaxErrorIgnoreAndNotify;
    wrapperCauseMap()[CauseE1apProtocolMessageNotCompatibleWithReceiverState] =
        SAACPF_CauseE1apProtocolMessageNotCompatibleWithReceiverState;
    wrapperCauseMap()[CauseE1apProtocolSemanticError] = SAACPF_CauseE1apProtocolSemanticError;
    wrapperCauseMap()[CauseE1apProtocolAbstractSyntaxErrorFalselyConstructedMessage] =
        SAACPF_CauseE1apProtocolAbstractSyntaxErrorFalselyConstructedMessage;
    wrapperCauseMap()[CauseE1apProtocolUnspecified] = SAACPF_CauseE1apProtocolUnspecified;
    wrapperCauseMap()[CauseE1apMiscControlProcessingOverload] = SAACPF_CauseE1apMiscControlProcessingOverload;
    wrapperCauseMap()[CauseE1apMiscNotEnoughUserPlaneProcessingResources] =
        SAACPF_CauseE1apMiscNotEnoughUserPlaneProcessingResources;
    wrapperCauseMap()[CauseE1apMiscHardwareFailure] = SAACPF_CauseE1apMiscHardwareFailure;
    wrapperCauseMap()[CauseE1apMiscOMIntervention] = SAACPF_CauseE1apMiscOMIntervention;
    wrapperCauseMap()[CauseE1apMiscUnspecified] = SAACPF_CauseE1apMiscUnspecified;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUnspecified] = SAACPF_CauseNgapRadioNetworkLayerUnspecified;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerTxnrelocoverallExpiry] =
        SAACPF_CauseNgapRadioNetworkLayerTxnrelocoverallExpiry;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerSuccessfulHandover] =
        SAACPF_CauseNgapRadioNetworkLayerSuccessfulHandover;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerReleaseDueToNgranGeneratedReason] =
        SAACPF_CauseNgapRadioNetworkLayerReleaseDueToNgranGeneratedReason;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerReleaseDueTo5gcGeneratedReason] =
        SAACPF_CauseNgapRadioNetworkLayerReleaseDueTo5gcGeneratedReason;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerHandoverCancelled] = SAACPF_CauseNgapRadioNetworkLayerHandoverCancelled;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerPartialHandover] = SAACPF_CauseNgapRadioNetworkLayerPartialHandover;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerHandoverFailureInTarget5gcNgranNodeOrTargetSystem] =
        SAACPF_CauseNgapRadioNetworkLayerHandoverFailureInTarget5gcNgranNodeOrTargetSystem;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerHandoverTargetNotAllowed] =
        SAACPF_CauseNgapRadioNetworkLayerHandoverTargetNotAllowed;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerTngrelocoverallExpiry] =
        SAACPF_CauseNgapRadioNetworkLayerTngrelocoverallExpiry;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerTngrelocprepExpiry] =
        SAACPF_CauseNgapRadioNetworkLayerTngrelocprepExpiry;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerCellNotavailable] = SAACPF_CauseNgapRadioNetworkLayerCellNotavailable;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUnknownTargetID] = SAACPF_CauseNgapRadioNetworkLayerUnknownTargetID;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerNoRadioResourcesAvailableInTargetCell] =
        SAACPF_CauseNgapRadioNetworkLayerNoRadioResourcesAvailableInTargetCell;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUnknownLocalUeNgapID] =
        SAACPF_CauseNgapRadioNetworkLayerUnknownLocalUeNgapID;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerInconsistentRemoteUeNgapID] =
        SAACPF_CauseNgapRadioNetworkLayerInconsistentRemoteUeNgapID;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerHandoverDesirableForRadioReasons] =
        SAACPF_CauseNgapRadioNetworkLayerHandoverDesirableForRadioReasons;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerTimeCriticalHandover] =
        SAACPF_CauseNgapRadioNetworkLayerTimeCriticalHandover;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerResourceOptimisationHandover] =
        SAACPF_CauseNgapRadioNetworkLayerResourceOptimisationHandover;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerReduceLoadInServingCell] =
        SAACPF_CauseNgapRadioNetworkLayerReduceLoadInServingCell;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUserInactivity] = SAACPF_CauseNgapRadioNetworkLayerUserInactivity;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerRadioConnectionWithUeLost] =
        SAACPF_CauseNgapRadioNetworkLayerRadioConnectionWithUeLost;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerRadioResourcesNotAvailable] =
        SAACPF_CauseNgapRadioNetworkLayerRadioResourcesNotAvailable;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerInvalidQosCombination] =
        SAACPF_CauseNgapRadioNetworkLayerInvalidQosCombination;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerFailureInTheRadioInterfaceProcedure] =
        SAACPF_CauseNgapRadioNetworkLayerFailureInTheRadioInterfaceProcedure;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerInteractionWithOtherProcedure] =
        SAACPF_CauseNgapRadioNetworkLayerInteractionWithOtherProcedure;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUnknownPduSessionID] =
        SAACPF_CauseNgapRadioNetworkLayerUnknownPduSessionID;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUnknownQosFlowID] = SAACPF_CauseNgapRadioNetworkLayerUnknownQosFlowID;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerMultiplePduSessionIdInstances] =
        SAACPF_CauseNgapRadioNetworkLayerMultiplePduSessionIdInstances;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerMultipleQosFlowIdInstances] =
        SAACPF_CauseNgapRadioNetworkLayerMultipleQosFlowIdInstances;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerEncryptionAndOrIntegrityProtectionAlgorithmsNotSupported] =
        SAACPF_CauseNgapRadioNetworkLayerEncryptionAndOrIntegrityProtectionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerNgIntraSystemHandoverTriggered] =
        SAACPF_CauseNgapRadioNetworkLayerNgIntraSystemHandoverTriggered;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerNgInterSystemHandoverTriggered] =
        SAACPF_CauseNgapRadioNetworkLayerNgInterSystemHandoverTriggered;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerXnHandoverTriggered] =
        SAACPF_CauseNgapRadioNetworkLayerXnHandoverTriggered;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerNotSupported5qiValue] =
        SAACPF_CauseNgapRadioNetworkLayerNotSupported5qiValue;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUeContextTransfer] = SAACPF_CauseNgapRadioNetworkLayerUeContextTransfer;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerImsVoiceEpsFallbackOrRatFallbackTriggered] =
        SAACPF_CauseNgapRadioNetworkLayerImsVoiceEpsFallbackOrRatFallbackTriggered;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUpIntegrityProtectionNotPossible] =
        SAACPF_CauseNgapRadioNetworkLayerUpIntegrityProtectionNotPossible;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUpConfidentialityProtectionNotPossible] =
        SAACPF_CauseNgapRadioNetworkLayerUpConfidentialityProtectionNotPossible;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerSliceNotSupported] = SAACPF_CauseNgapRadioNetworkLayerSliceNotSupported;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUeInRrcInactiveStateNotReachable] =
        SAACPF_CauseNgapRadioNetworkLayerUeInRrcInactiveStateNotReachable;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerRedirection] = SAACPF_CauseNgapRadioNetworkLayerRedirection;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerResourcesNotAvailableForTheSlice] =
        SAACPF_CauseNgapRadioNetworkLayerResourcesNotAvailableForTheSlice;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUeMaximumIntegrityProtectedDataRateReason] =
        SAACPF_CauseNgapRadioNetworkLayerUeMaximumIntegrityProtectedDataRateReason;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerReleaseDueToCnDetectedMobility] =
        SAACPF_CauseNgapRadioNetworkLayerReleaseDueToCnDetectedMobility;
    wrapperCauseMap()[CauseNgapTransportLayerTransportResourceUnavailable] =
        SAACPF_CauseNgapTransportLayerTransportResourceUnavailable;
    wrapperCauseMap()[CauseNgapTransportLayerUnspecified] = SAACPF_CauseNgapTransportLayerUnspecified;
    wrapperCauseMap()[CauseNgapNasNormalRelease] = SAACPF_CauseNgapNasNormalRelease;
    wrapperCauseMap()[CauseNgapNasAuthenticationFailure] = SAACPF_CauseNgapNasAuthenticationFailure;
    wrapperCauseMap()[CauseNgapNasDeregister] = SAACPF_CauseNgapNasDeregister;
    wrapperCauseMap()[CauseNgapNasUnspecified] = SAACPF_CauseNgapNasUnspecified;
    wrapperCauseMap()[CauseNgapProtocolTransferSyntaxError] = SAACPF_CauseNgapProtocolTransferSyntaxError;
    wrapperCauseMap()[CauseNgapProtocolAbstractSyntaxErrorReject] = SAACPF_CauseNgapProtocolAbstractSyntaxErrorReject;
    wrapperCauseMap()[CauseNgapProtocolAbstractSyntaxErrorIgnoreAndNotify] =
        SAACPF_CauseNgapProtocolAbstractSyntaxErrorIgnoreAndNotify;
    wrapperCauseMap()[CauseNgapProtocolMessageNotCompatibleWithReceiverState] =
        SAACPF_CauseNgapProtocolMessageNotCompatibleWithReceiverState;
    wrapperCauseMap()[CauseNgapProtocolSemanticError] = SAACPF_CauseNgapProtocolSemanticError;
    wrapperCauseMap()[CauseNgapProtocolAbstractSyntaxErrorFalselyConstructedMessage] =
        SAACPF_CauseNgapProtocolAbstractSyntaxErrorFalselyConstructedMessage;
    wrapperCauseMap()[CauseNgapProtocolUnspecified] = SAACPF_CauseNgapProtocolUnspecified;
    wrapperCauseMap()[CauseNgapMiscControlProcessingOverload] = SAACPF_CauseNgapMiscControlProcessingOverload;
    wrapperCauseMap()[CauseNgapMiscNotEnoughUserPlaneProcessingResources] =
        SAACPF_CauseNgapMiscNotEnoughUserPlaneProcessingResources;
    wrapperCauseMap()[CauseNgapMiscHardwareFailure] = SAACPF_CauseNgapMiscHardwareFailure;
    wrapperCauseMap()[CauseNgapMiscOMIntervention] = SAACPF_CauseNgapMiscOMIntervention;
    wrapperCauseMap()[CauseNgapMiscUnknownPlmn] = SAACPF_CauseNgapMiscUnknownPlmn;
    wrapperCauseMap()[CauseNgapMiscUnspecifiedFailure] = SAACPF_CauseNgapMiscUnspecifiedFailure;
    wrapperCauseMap()[CauseCpInternalSaInvalidSecurityAlgorithm] = SAACPF_CauseInternalInvalidSecurityAlgorithm;
    wrapperCauseMap()[CauseCpInternalSaSecurityModeFailure] = SAACPF_CauseInternalSecurityModeFailure;
    wrapperCauseMap()[CauseCpInternalSaConfigNotExist] = SAACPF_CauseInternalConfigNotExist;
    wrapperCauseMap()[CauseCpInternalSaRreTmOutNgPathSwitchRequest] = SAACPF_CauseInternalRreTmOutNgPathSwitchRequest;
    wrapperCauseMap()[CauseCpInternalSaRreTmOutXnSNStatusTransfer] = SAACPF_CauseInternalRreTmOutXnSNStatusTransfer;
    wrapperCauseMap()[CauseCpInternalSaRreTmOutXnRelocOverall] = SAACPF_CauseInternalRreTmOutXnRelocOverall;
    wrapperCauseMap()[CauseCpInternalSaRreProcedureNotAvailable] = SAACPF_CauseInternalRreProcedureNotAvailable;
    wrapperCauseMap()[CauseF1apRadioAmfInitiatedAbnormalRelease] = SAACPF_CauseF1apRadioAmfInitiatedAbnormalRelease;
    wrapperCauseMap()[CauseF1apRadioReleaseDueToPreEmption] = SAACPF_CauseF1apRadioReleaseDueToPreEmption;
    wrapperCauseMap()[CauseF1apRadioPlmnNotServedByTheGnbCu] = SAACPF_CauseF1apRadioPlmnNotServedByTheGnbCu;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUeDlMaxIPDataRateReason] =
        SAACPF_CauseE1apRadioNetworkLayerUeDlMaxIPDataRateReason;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUpIntegrityProtectionFailure] =
        SAACPF_CauseE1apRadioNetworkLayerUpIntegrityProtectionFailure;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerReleaseDueToPreEmption] =
        SAACPF_CauseE1apRadioNetworkLayerReleaseDueToPreEmption;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerN26InterfaceNotAvailable] =
        SAACPF_CauseNgapRadioNetworkLayerN26InterfaceNotAvailable;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerReleaseDueToPreEmption] =
        SAACPF_CauseNgapRadioNetworkLayerReleaseDueToPreEmption;
    wrapperCauseMap()[CauseCpInternalSaUeCapaNotSupported] = SAACPF_CauseInternalUeCapaNotSupported;
    wrapperCauseMap()[CauseCpInternalSaRrcInactiveRelease] = SAACPF_CauseInternalRrcInactiveRelease;
    wrapperCauseMap()[CauseCpInternalSaResumeMacIMismatch] = SAACPF_CauseInternalResumeMacIMismatch;
    wrapperCauseMap()[CauseCpInternalSaTmOutPaging] = SAACPF_CauseInternalTmOutPaging;
    wrapperCauseMap()[CauseCpInternalSaTmOutRrcResume] = SAACPF_CauseInternalTmOutRrcResume;
    wrapperCauseMap()[CauseCpInternalSaTmOutPeriodicRNAU] = SAACPF_CauseInternalTmOutPeriodicRNAU;
    wrapperCauseMap()[CauseCpInternalSaResumeOldCallRelease] = SAACPF_CauseInternalResumeOldCallRelease;
    wrapperCauseMap()[CauseCpInternalSaResumeOldCallReleaseSourceFail] =
        SAACPF_CauseInternalResumeOldCallReleaseSourceFail;
    wrapperCauseMap()[CauseCpInternalSaResumeTmOutNgPathSwitchRequest] =
        SAACPF_CauseInternalResumeTmOutNgPathSwitchRequest;
    wrapperCauseMap()[CauseCpInternalSaResumeTmOutXnRelocOverall] = SAACPF_CauseInternalResumeTmOutXnRelocOverall;
    wrapperCauseMap()[CauseCpInternalSaResumeProcedureNotAvailable] = SAACPF_CauseInternalResumeProcedureNotAvailable;
    wrapperCauseMap()[CauseCpInternalSaUeAssistanceInformation] = SAACPF_CauseInternalUeAssistanceInformation;
    wrapperCauseMap()[CauseCpInternalSaInvalidAMFName] = SAACPF_CauseInternalInvalidAMFName;

    wrapperCauseMap()[CauseF1apRadioMultipleDrbIdInstances] = SAACPF_CauseF1apRadioMultipleDrbIdInstances;
    wrapperCauseMap()[CauseF1apRadioUnknownDrbId] = SAACPF_CauseF1apRadioUnknownDrbId;
    wrapperCauseMap()[CauseF1apRadioMultipleBhRlcChIdInstances] = SAACPF_CauseF1apRadioMultipleBhRlcChIdInstances;
    wrapperCauseMap()[CauseF1apRadioUnknownBhRlcChId] = SAACPF_CauseF1apRadioUnknownBhRlcChId;
    wrapperCauseMap()[CauseF1apRadioChoCpcResourcesToBeChanged] = SAACPF_CauseF1apRadioChoCpcResourcesToBeChanged;
    wrapperCauseMap()[CauseF1apRadioNpnNotSupported] = SAACPF_CauseF1apRadioNpnNotSupported;
    wrapperCauseMap()[CauseF1apRadioNpnAccessDenied] = SAACPF_CauseF1apRadioNpnAccessDenied;
    wrapperCauseMap()[CauseF1apRadioGnbCuCellCapacityExceeded] = SAACPF_CauseF1apRadioGnbCuCellCapacityExceeded;
    wrapperCauseMap()[CauseF1apRadioReportCharacteristicsEmpty] = SAACPF_CauseF1apRadioReportCharacteristicsEmpty;
    wrapperCauseMap()[CauseF1apRadioExistingMeasurementID] = SAACPF_CauseF1apRadioExistingMeasurementID;
    wrapperCauseMap()[CauseF1apRadioMeasurementTemporarilyNotAvailable] =
        SAACPF_CauseF1apRadioMeasurementTemporarilyNotAvailable;
    wrapperCauseMap()[CauseF1apRadioMeasurementNotSupportedForTheObject] =
        SAACPF_CauseF1apRadioMeasurementNotSupportedForTheObject;
    wrapperCauseMap()[CauseF1apRadioUnknownBAPAddress] = SAACPF_CauseF1apRadioUnknownBAPAddress;
    wrapperCauseMap()[CauseF1apRadioUnknownBAPRoutingID] = SAACPF_CauseF1apRadioUnknownBAPRoutingID;
    wrapperCauseMap()[CauseF1apRadioInsufficientUeCapabilities] = SAACPF_CauseF1apRadioInsufficientUeCapabilities;
    wrapperCauseMap()[CauseF1apTransportUnknownTNLAddressForIAB] = SAACPF_CauseF1apTransportUnknownTNLAddressForIAB;
    wrapperCauseMap()[CauseF1apTransportUnknownUPTNLInformationForIAB] =
        SAACPF_CauseF1apTransportUnknownUPTNLInformationForIAB;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerRSNNotAvailableForTheUP] =
        SAACPF_CauseE1apRadioNetworkLayerRSNNotAvailableForTheUP;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNPNNotSupported] = SAACPF_CauseE1apRadioNetworkLayerNPNNotSupported;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerReportCharacteristicsEmpty] =
        SAACPF_CauseE1apRadioNetworkLayerReportCharacteristicsEmpty;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerExistingMeasurementID] =
        SAACPF_CauseE1apRadioNetworkLayerExistingMeasurementID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMeasurementTemporarilyNotAvailable] =
        SAACPF_CauseE1apRadioNetworkLayerMeasurementTemporarilyNotAvailable;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMeasurementNotSupportedForTheObject] =
        SAACPF_CauseE1apRadioNetworkLayerMeasurementNotSupportedForTheObject;
    wrapperCauseMap()[CauseE1apTransportLayerUnknownTNLAddressForIAB] =
        SAACPF_CauseE1apTransportLayerUnknownTNLAddressForIAB;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerMultipleLocationReportingReferenceIDInstances] =
        SAACPF_CauseNgapRadioNetworkLayerMultipleLocationReportingReferenceIDInstances;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerRSNNotAvailableForTheUP] =
        SAACPF_CauseNgapRadioNetworkLayerRSNNotAvailableForTheUP;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerNPNAccessDenied] = SAACPF_CauseNgapRadioNetworkLayerNPNAccessDenied;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerCAGOnlyAccessDenied] =
        SAACPF_CauseNgapRadioNetworkLayerCAGOnlyAccessDenied;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerCellNotAvailable] = SAACPF_CauseXnapRadioNetworkLayerCellNotAvailable;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerHandoverDesirableForRadioReasons] =
        SAACPF_CauseXnapRadioNetworkLayerHandoverDesirableForRadioReasons;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerHandoverTargetNotAllowed] =
        SAACPF_CauseXnapRadioNetworkLayerHandoverTargetNotAllowed;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerInvalidAmfSetId] = SAACPF_CauseXnapRadioNetworkLayerInvalidAmfSetId;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNoRadioResourcesAvailableInTargetCell] =
        SAACPF_CauseXnapRadioNetworkLayerNoRadioResourcesAvailableInTargetCell;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerPartialHandover] = SAACPF_CauseXnapRadioNetworkLayerPartialHandover;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerReduceLoadInServingCell] =
        SAACPF_CauseXnapRadioNetworkLayerReduceLoadInServingCell;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerResourceOptimisationHandover] =
        SAACPF_CauseXnapRadioNetworkLayerResourceOptimisationHandover;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTimeCriticalHandover] =
        SAACPF_CauseXnapRadioNetworkLayerTimeCriticalHandover;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTxnRelocOverallExpiry] =
        SAACPF_CauseXnapRadioNetworkLayerTxnRelocOverallExpiry;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTxnRelocPrepExpiry] =
        SAACPF_CauseXnapRadioNetworkLayerTxnRelocPrepExpiry;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnknownGuamiId] = SAACPF_CauseXnapRadioNetworkLayerUnknownGuamiId;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnknownLocalNgranNodeUeXnapId] =
        SAACPF_CauseXnapRadioNetworkLayerUnknownLocalNgranNodeUeXnapId;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerInconsistentRemoteNgranNodeUeXnapId] =
        SAACPF_CauseXnapRadioNetworkLayerInconsistentRemoteNgranNodeUeXnapId;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerEncryptionAndOrIntegrityProtectionAlgorithmsNotSupported] =
        SAACPF_CauseXnapRadioNetworkLayerEncryptionAndOrIntegrityProtectionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerProtectionAlgorithmsNotSupported] =
        SAACPF_CauseXnapRadioNetworkLayerProtectionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMultiplePduSessionIdInstances] =
        SAACPF_CauseXnapRadioNetworkLayerMultiplePduSessionIdInstances;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnknownPduSessionId] =
        SAACPF_CauseXnapRadioNetworkLayerUnknownPduSessionId;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnknownQosFlowId] = SAACPF_CauseXnapRadioNetworkLayerUnknownQosFlowId;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMultipleQosFlowIdInstances] =
        SAACPF_CauseXnapRadioNetworkLayerMultipleQosFlowIdInstances;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerSwitchOffOngoing] = SAACPF_CauseXnapRadioNetworkLayerSwitchOffOngoing;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNotSupported5qiValue] =
        SAACPF_CauseXnapRadioNetworkLayerNotSupported5qiValue;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTxnDcOverallExpiry] =
        SAACPF_CauseXnapRadioNetworkLayerTxnDcOverallExpiry;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTxnDcPrepExpiry] = SAACPF_CauseXnapRadioNetworkLayerTxnDcPrepExpiry;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerActionDesirableForRadioReasons] =
        SAACPF_CauseXnapRadioNetworkLayerActionDesirableForRadioReasons;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerReduceLoad] = SAACPF_CauseXnapRadioNetworkLayerReduceLoad;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerResourceOptimisation] =
        SAACPF_CauseXnapRadioNetworkLayerResourceOptimisation;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTimeCriticalAction] =
        SAACPF_CauseXnapRadioNetworkLayerTimeCriticalAction;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTargetNotAllowed] = SAACPF_CauseXnapRadioNetworkLayerTargetNotAllowed;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNoRadioResourcesAvailable] =
        SAACPF_CauseXnapRadioNetworkLayerNoRadioResourcesAvailable;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerInvalidQosCombination] =
        SAACPF_CauseXnapRadioNetworkLayerInvalidQosCombination;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerEncryptionAlgorithmsNotSupported] =
        SAACPF_CauseXnapRadioNetworkLayerEncryptionAlgorithmsNotSupported;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerProcedureCancelled] =
        SAACPF_CauseXnapRadioNetworkLayerProcedureCancelled;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerRrmPurpose] = SAACPF_CauseXnapRadioNetworkLayerRrmPurpose;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerImproveUserBitRate] =
        SAACPF_CauseXnapRadioNetworkLayerImproveUserBitRate;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUserInactivity] = SAACPF_CauseXnapRadioNetworkLayerUserInactivity;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerRadioConnectionWithUeLost] =
        SAACPF_CauseXnapRadioNetworkLayerRadioConnectionWithUeLost;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerFailureInTheRadioInterfaceProcedure] =
        SAACPF_CauseXnapRadioNetworkLayerFailureInTheRadioInterfaceProcedure;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerBearerOptionNotSupported] =
        SAACPF_CauseXnapRadioNetworkLayerBearerOptionNotSupported;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUpIntegrityProtectionNotPossible] =
        SAACPF_CauseXnapRadioNetworkLayerUpIntegrityProtectionNotPossible;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUpConfidentialityProtectionNotPossible] =
        SAACPF_CauseXnapRadioNetworkLayerUpConfidentialityProtectionNotPossible;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerResourcesNotAvailableForTheSlice] =
        SAACPF_CauseXnapRadioNetworkLayerResourcesNotAvailableForTheSlice;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUeMaximumIntegrityProtectedDataRateReason] =
        SAACPF_CauseXnapRadioNetworkLayerUeMaximumIntegrityProtectedDataRateReason;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerCpIntegrityProtectionFailure] =
        SAACPF_CauseXnapRadioNetworkLayerCpIntegrityProtectionFailure;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUpIntegrityProtectionFailure] =
        SAACPF_CauseXnapRadioNetworkLayerUpIntegrityProtectionFailure;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerSlicesNotSupportedByNgran] =
        SAACPF_CauseXnapRadioNetworkLayerSlicesNotSupportedByNgran;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMnMobility] = SAACPF_CauseXnapRadioNetworkLayerMnMobility;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerSnMobility] = SAACPF_CauseXnapRadioNetworkLayerSnMobility;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerCountReachesMaxValue] =
        SAACPF_CauseXnapRadioNetworkLayerCountReachesMaxValue;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnknownOldNgranNodeUeXnapId] =
        SAACPF_CauseXnapRadioNetworkLayerUnknownOldNgranNodeUeXnapId;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerPdcpOverload] = SAACPF_CauseXnapRadioNetworkLayerPdcpOverload;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerDrbIdNotAvailable] = SAACPF_CauseXnapRadioNetworkLayerDrbIdNotAvailable;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnspecified] = SAACPF_CauseXnapRadioNetworkLayerUnspecified;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUeContextIdNotKnown] =
        SAACPF_CauseXnapRadioNetworkLayerUeContextIdNotKnown;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNonRelocationOfContext] =
        SAACPF_CauseXnapRadioNetworkLayerNonRelocationOfContext;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerCHOCPCResourcesToBeChanged] =
        SAACPF_CauseXnapRadioNetworkLayerCHOCPCResourcesToBeChanged;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerRSNNotAvailableForTheUP] =
        SAACPF_CauseXnapRadioNetworkLayerRSNNotAvailableForTheUP;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNPNAccessDenied] = SAACPF_CauseXnapRadioNetworkLayerNPNAccessDenied;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerReportCharacteristicsEmpty] =
        SAACPF_CauseXnapRadioNetworkLayerReportCharacteristicsEmpty;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerExistingMeasurementID] =
        SAACPF_CauseXnapRadioNetworkLayerExistingMeasurementID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMeasurementTemporarilyNotAvailable] =
        SAACPF_CauseXnapRadioNetworkLayerMeasurementTemporarilyNotAvailable;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMeasurementNotSupportedForTheObject] =
        SAACPF_CauseXnapRadioNetworkLayerMeasurementNotSupportedForTheObject;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUEPowerSaving] = SAACPF_CauseXnapRadioNetworkLayerUEPowerSaving;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNotExistingNGRANNode2MeasurementID] =
        SAACPF_CauseXnapRadioNetworkLayerNotExistingNGRANNode2MeasurementID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerInsufficientUECapabilities] =
        SAACPF_CauseXnapRadioNetworkLayerInsufficientUECapabilities;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNormalRelease] = SAACPF_CauseXnapRadioNetworkLayerNormalRelease;
    wrapperCauseMap()[CauseXnapTransportLayerTransportResourceUnavailable] =
        SAACPF_CauseXnapTransportLayerTransportResourceUnavailable;
    wrapperCauseMap()[CauseXnapTransportLayerUnspecified] = SAACPF_CauseXnapTransportLayerUnspecified;
    wrapperCauseMap()[CauseXnapProtocolTransferSyntaxError] = SAACPF_CauseXnapProtocolTransferSyntaxError;
    wrapperCauseMap()[CauseXnapProtocolAbstractSyntaxErrorReject] = SAACPF_CauseXnapProtocolAbstractSyntaxErrorReject;
    wrapperCauseMap()[CauseXnapProtocolAbstractSyntaxErrorIgnoreAndNotify] =
        SAACPF_CauseXnapProtocolAbstractSyntaxErrorIgnoreAndNotify;
    wrapperCauseMap()[CauseXnapProtocolMessageNotCompatibleWithReceiverState] =
        SAACPF_CauseXnapProtocolMessageNotCompatibleWithReceiverState;
    wrapperCauseMap()[CauseXnapProtocolSemanticError] = SAACPF_CauseXnapProtocolSemanticError;
    wrapperCauseMap()[CauseXnapProtocolAbstractSyntaxErrorFalselyConstructedMessage] =
        SAACPF_CauseXnapProtocolAbstractSyntaxErrorFalselyConstructedMessage;
    wrapperCauseMap()[CauseXnapProtocolUnspecified] = SAACPF_CauseXnapProtocolUnspecified;
    wrapperCauseMap()[CauseXnapMiscControlProcessingOverload] = SAACPF_CauseXnapMiscControlProcessingOverload;
    wrapperCauseMap()[CauseXnapMiscHardwareFailure] = SAACPF_CauseXnapMiscHardwareFailure;
    wrapperCauseMap()[CauseXnapMiscOMIntervention] = SAACPF_CauseXnapMiscOMIntervention;
    wrapperCauseMap()[CauseXnapMiscNotEnoughUserPlaneProcessingResources] =
        SAACPF_CauseXnapMiscNotEnoughUserPlaneProcessingResources;
    wrapperCauseMap()[CauseXnapMiscUnspecified] = SAACPF_CauseXnapMiscUnspecified;
    wrapperCauseMap()[CauseCpInternalCpSrbIntegrityFailure] = SAACPF_CauseInternalCpSrbIntegrityFailure;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerScgActivationDeactivationFailure] =
        SAACPF_CauseE1apRadioNetworkLayerScgActivationDeactivationFailure;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerScgDeactivationFailureDueToDataTransmission] =
        SAACPF_CauseE1apRadioNetworkLayerScgDeactivationFailureDueToDataTransmission;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpMbsE1apId] =
        SAACPF_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpMbsE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpMbsE1apId] =
        SAACPF_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpMbsE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfMbsE1apId] =
        SAACPF_CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfMbsE1apId;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrInconsistentMrbId] =
        SAACPF_CauseE1apRadioNetworkLayerUnknownOrInconsistentMrbId;
    wrapperCauseMap()[CauseF1apRadioScgActivationDeactivationFailure] =
        SAACPF_CauseF1apRadioScgActivationDeactivationFailure;
    wrapperCauseMap()[CauseF1apRadioScgDeactivationFailureDueToDataTransmission] =
        SAACPF_CauseF1apRadioScgDeactivationFailureDueToDataTransmission;
    wrapperCauseMap()[CauseF1apRadioRequestedItemNotSupportedOnTime] =
        SAACPF_CauseF1apRadioRequestedItemNotSupportedOnTime;
    wrapperCauseMap()[CauseF1apRadioTatSdtExpiry] =
        SAACPF_CauseF1apRadioTatSdtExpiry;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedGnbCuMbsF1apId] =
        SAACPF_CauseF1apRadioUnknownOrAlreadyAllocatedGnbCuMbsF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedGnbDuMbsF1apId] =
        SAACPF_CauseF1apRadioUnknownOrAlreadyAllocatedGnbDuMbsF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownOrInconsistentPairOfMbsF1apId] =
        SAACPF_CauseF1apRadioUnknownOrInconsistentPairOfMbsF1apId;
    wrapperCauseMap()[CauseF1apRadioUnknownOrInconsistentMrbId] =
        SAACPF_CauseF1apRadioUnknownOrInconsistentMrbId;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerInsufficientUeCapabilities] =
        SAACPF_CauseNgapRadioNetworkLayerInsufficientUeCapabilities;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerRedcapUeNotSupported] =
        SAACPF_CauseNgapRadioNetworkLayerRedCapUeNotSupported;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUnknownMBSSessionID] =
        SAACPF_CauseNgapRadioNetworkLayerUnknownMbsSessionId;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerIndicatedMBSSessionAreaInformationNotServedByTheGNB] =
        SAACPF_CauseNgapRadioNetworkLayerIndicatedMbsSessionAreaInformationNotServedByTheGnb;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerInconsistentSliceInfoForTheSession] =
        SAACPF_CauseNgapRadioNetworkLayerInconsistentSliceInfoForTheSession;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerMisalignedAssociationForMulticastUnicast] =
        SAACPF_CauseNgapRadioNetworkLayerMisalignedAssociationForTheMulticastAndUnicastSessionsOrFlows;
    wrapperCauseMap()[CauseNgapNasUeNotInPlmnServingArea] =
        SAACPF_CauseNgapNasUeNotInPlmnServingArea;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerScgActivationDeactivationFailure] =
        SAACPF_CauseXnapRadioNetworkLayerScgActivationDeactivationFailure;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerScgDeactivationFailureDueToDataTransmission] =
        SAACPF_CauseXnapRadioNetworkLayerScgDeactivationFailureDueToDataTransmission;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerValueOutOfAllowedRange] =
        SAACPF_CauseXnapRadioNetworkLayerValueOutOfAllowedRange;

    if ((STAT_SA_CUCPCSL_PER_GNB_END + STAT_SA_CUCPCSL_PER_GNB_2_END) == wrapperCauseMap().size())
        return NR_CSL_CAUSE_ERROR_NONE;
    else
        return NR_CSL_CAUSE_ERROR_VALIDATION_FAILED;
}

nr_csl_cause_error_e nr_csl_cause_get_sacp_pmCause(const cause_t cause, pmCause_t* pmCause)
{
    if (wrapperCauseMap().find(cause) == wrapperCauseMap().end())
    {
        return NR_CSL_CAUSE_ERROR_VALIDATION_FAILED;
    }

    if (NULL == pmCause)
    {
        return NR_CSL_CAUSE_ERROR_INVALID_PARAMETER;
    }

    *pmCause = wrapperCauseMap()[cause];
    return NR_CSL_CAUSE_ERROR_NONE;
}
