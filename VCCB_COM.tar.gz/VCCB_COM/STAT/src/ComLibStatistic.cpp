/**
 * @file        VlibStatistic.c
 * @brief       functions for CP call context
 */

/*----------------------------------------------------------------------------
 * Define    :    Include Header Files
 * ---------------------------------------------------------------------------
 */
#include "ComLibStatistic.h"
#include "ComInclude.h"
#include "ComTimeUtil.h"
#include "ComLibUtility.h"
#include "ComCslCauseMap.h"
#include "ComStatisticMapper.hpp"

#include "FeatCommon.h"
#include "FeatCallInfo.h"
#include "FeatCallProc.h"
#include "FeatHo.h"
#include "FeatSon.h"
#include "FeatConditionalHo.h"
#include "FeatNonNeighborHo.h"
#include "FeatSpeedState.hpp"

#include "StateCommon.h"

#include "MsgX2apStore.h"
#include "MsgNgapStore.h"
#include "MsgNmbSend.h"
#include "MsgVccbSend.h"

#include "VpmInterface.h"

#include "NRRRC.h"
#include "ComMacro.h"
#include "StatisticsHandler.h"
#include "FeatMeasurementsStatistics.h"
#include "FeatMeasurements.hpp"
#include "UplinkStatusTriggeredMobility.hpp"

#include "PM_TYPE_ID.h"
#include "log_util.h"

#include <iostream>

static uint32_t gAuditCallCountVmIndex = 0;  // used at VLIB_LibStatPeriodicEvent
#ifdef HOST_SIM
static uint32_t gBTAuditCallCountVmIndex = 0;
#endif

int GetAttTypeId(callInfo_type *ptCi, int mFamily, int mType);
int GetPrepSuccTypeId(callInfo_type *ptCi, int mFamily, int mType);
inline uint64_t GetDuId(uint64_t gnbDuId)
{
#ifdef __NVGNB__
    UNUSED1(gnbDuId);
    return static_cast<uint64_t>(NVGNB_DUID);
#else
    return gnbDuId;
#endif
}

#ifdef PM_COLLECT
#define LOG_PM_COLLECT(family,type) do \
{ \
    std::cout << "PM_COLLECT " << family << " " << type << "\n"; \
} \
while (0)
#else
#define LOG_PM_COLLECT(family,type) do { (void)family; (void)type; } while (0)
#endif

#define MACRO_STAT_PMCC_ADD_ITEM(_item, _cntOfItem, _mFamily, _mType, _method, _val) \
    FnVCCB_MultiPmAddItem(_item, #_item, _cntOfItem, _mFamily, _mType, _method, _val)

template <typename UpdateItem, typename UpdateVal>
void FnVCCB_MultiPmAddItem(UpdateItem &item, const char *pStrItem, unsigned int &cntOfItem, int mFamily, int mType,
    PME_LIB_TYPE method, UpdateVal val)
{
    const unsigned int arrSize = sizeof(item) / sizeof(item[0]);

    if (arrSize <= cntOfItem)
    {
        VALID_E_POINT_CHECK_VOID(pStrItem);

        VCCB_PRINT_CRITICAL("%s OverFlow Error!!(arrSize:%d , reqIdx:%d) mFamily:%d mType:%d!!\n", pStrItem, arrSize,
            cntOfItem, mFamily, mType);
        return;
    }

    item[cntOfItem].typeID = (decltype(item[cntOfItem].typeID))mType;
    item[cntOfItem].updateMethod = (decltype(item[cntOfItem].updateMethod))method;
    item[cntOfItem].updateVal = (decltype(item[cntOfItem].updateVal))val;

    cntOfItem++;
}

template <typename _vpmUpdateType>
int vpmUpdateAny_WithNumKey(
    unsigned int familyID, unsigned int numOfItem, _vpmUpdateType updateValue, VccbPmKey_type &pmKey);

template <>
int vpmUpdateAny_WithNumKey(
    unsigned int familyID, unsigned int numOfItem, updateItemUINT *updateValue, VccbPmKey_type &pmKey)
{
    int status = vpmUpdateUint_VariableIndexNum(familyID, pmKey.numKey, pmKey.keyList, numOfItem, updateValue);
    if (status < 0)
    {
        VCCB_PRINT_CRITICAL("vpmUpdateUint_VariableIndexNum Error(%d) %d/%u/%llu/%llu/%llu/%llu/%llu/%llu/%llu\n", status, familyID,
                    pmKey.numKey,
                    pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2],
                    pmKey.keyList[VCCB_PMKEY_INDEX3], pmKey.keyList[VCCB_PMKEY_INDEX4],
                    pmKey.keyList[VCCB_PMKEY_INDEX5], pmKey.keyList[VCCB_PMKEY_INDEX6],
                    pmKey.keyList[VCCB_PMKEY_INDEX7]);
    }
    return status;
}

template <>
int vpmUpdateAny_WithNumKey(unsigned int familyID, unsigned int numOfItem, updateItemULL *updateValue, VccbPmKey_type &pmKey)
{
    int status = vpmUpdateUll_VariableIndexNum(familyID, pmKey.numKey, pmKey.keyList, numOfItem, updateValue);
    if (status < 0)
    {
        VCCB_PRINT_CRITICAL("vpmUpdateUll_VariableIndexNum Error(%d) %d/%u/%llu/%llu/%llu/%llu/%llu/%llu/%llu\n", status, familyID,
                    pmKey.numKey,
                    pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2],
                    pmKey.keyList[VCCB_PMKEY_INDEX3], pmKey.keyList[VCCB_PMKEY_INDEX4],
                    pmKey.keyList[VCCB_PMKEY_INDEX5], pmKey.keyList[VCCB_PMKEY_INDEX6],
                    pmKey.keyList[VCCB_PMKEY_INDEX7]);
    }
    return status;
}

template <>
int vpmUpdateAny_WithNumKey(
    unsigned int familyID, unsigned int numOfItem, updateItemFLOAT *updateValue, VccbPmKey_type &pmKey)
{
    int status = vpmUpdateFloat_VariableIndexNum(familyID, pmKey.numKey, pmKey.keyList, numOfItem, updateValue);
    if (status < 0)
    {
        VCCB_PRINT_CRITICAL("vpmUpdateFloat_VariableIndexNum Error(%d) %d/%u/%llu/%llu/%llu/%llu/%llu/%llu/%llu\n", status, familyID,
                    pmKey.numKey,
                    pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2],
                    pmKey.keyList[VCCB_PMKEY_INDEX3], pmKey.keyList[VCCB_PMKEY_INDEX4],
                    pmKey.keyList[VCCB_PMKEY_INDEX5], pmKey.keyList[VCCB_PMKEY_INDEX6],
                    pmKey.keyList[VCCB_PMKEY_INDEX7]);
    }
    return status;
}

/**
 * @brief       Call vpmUpdate[ ] API according to PME_LIB_TYPE
 */
template <typename _vpmUpdateArr>
inline void VPM_UPDATE_WITH_NUMKEY(
    PME_LIB_TYPE method, int mFamily, VccbPmKey_type& rPmKey, unsigned int numOfItem, _vpmUpdateArr updateArr)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(updateArr);
    switch (method)
    {
        case PME_LIB_GAUGE:
        case PME_LIB_SI:
        case PME_LIB_CC:
            vpmUpdateAny_WithNumKey((unsigned int)mFamily, numOfItem, updateArr, rPmKey);
            break;
        default:
            VCCB_PRINT_COMMENT("VPM_UPDATE_WITH_NUMKEY: PME_LIB_TYPE(%d) not supported!\n", method);
            return;
    }
}

template <typename _vpmCollectType>
int vpmCollectAny_WithNumKey(
    PME_LIB_TYPE method, unsigned int familyID, unsigned int typeID, _vpmCollectType updateValue, VccbPmKey_type &pmKey);

template <>
int vpmCollectAny_WithNumKey(
    PME_LIB_TYPE method, unsigned int familyID, unsigned int typeID, unsigned int val, VccbPmKey_type &pmKey)
{
    int status = vpmCollectUint_VariableIndexNum(method, familyID, typeID, val, pmKey.numKey, pmKey.keyList);
    if (status < 0)
    {
        VCCB_PRINT_CRITICAL("vpmCollectUint_VariableIndexNum Error(%d) mFamily:%d mType:%d numKey:%d!!\n", status,
                familyID, typeID, pmKey.numKey);
    }
    return status;
}

template <>
int vpmCollectAny_WithNumKey(
    PME_LIB_TYPE method, unsigned int familyID, unsigned int typeID, unsigned long long val, VccbPmKey_type &pmKey)
{
    int status = vpmCollectUll_VariableIndexNum(method, familyID, typeID, val, pmKey.numKey, pmKey.keyList);
    if (status < 0)
    {
        VCCB_PRINT_CRITICAL("vpmCollectUll_VariableIndexNum Error(%d) mFamily:%d mType:%d numKey:%d!!\n", status,
                familyID, typeID, pmKey.numKey);
    }
    return status;
}

template <>
int vpmCollectAny_WithNumKey(
    PME_LIB_TYPE method, unsigned int familyID, unsigned int typeID, float val, VccbPmKey_type &pmKey)
{
    int status = vpmCollectFloat_VariableIndexNum(method, familyID, typeID, val, pmKey.numKey, pmKey.keyList);
    if (status < 0)
    {
        VCCB_PRINT_CRITICAL("vpmCollectFloat_VariableIndexNum Error(%d) mFamily:%d mType:%d numKey:%d!!\n", status,
                familyID, typeID, pmKey.numKey);
    }
    return status;
}

/**
 * @brief       Call vpmCollect[ ] API according to PME_LIB_TYPE
 */
template <typename UpdateVal>
inline void VPM_COLLECT_WITH_NUMKEY(
    PME_LIB_TYPE method, unsigned int mFamily, unsigned int mType, UpdateVal updateVal, VccbPmKey_type& rPmKey)
{
    AUTO_TRACE_FUNC;
    switch (method)
    {
        case PME_LIB_GAUGE:
        case PME_LIB_SI:
        case PME_LIB_CC:
            vpmCollectAny_WithNumKey(method, mFamily, mType, updateVal, rPmKey);
            LOG_PM_COLLECT(mFamily, mType);
            break;
        default:
            VCCB_PRINT_COMMENT("VPM_COLLECT: PME_LIB_TYPE(%d) not supported!\n", method);
            return;
    }
}

void FnVCCB_SendInternalStatisticsItemCollect(uint8_t threadId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB); // Call Thread

    msgInternalStatisticsItemCollect_type &msg = gStatisticsItemCollect[threadId].msg;

    // TODO: If a timer expired and there is no statistics collection at all, it should not send a message.
    if (msg.itemCount > 0)
    {
        if (msg.itemCount > MAX_STATISTICS_COLLECT_ITEM_PER_THREAD)
        {
            VCCB_PRINT_ERROR("itemCount(%u) exceeds max(%u) in %s\n", msg.itemCount, MAX_STATISTICS_COLLECT_ITEM_PER_THREAD, __func__);
            msg.itemCount = MAX_STATISTICS_COLLECT_ITEM_PER_THREAD;
        }

        msg.hdr.msgType = InternalStatisticsItemCollect_id;
        msg.threadId = threadId;

        int status = FnVCCB_SendMessageToVCCB(msg.hdr.msgType, threadId, reinterpret_cast<char *>(&msg), sizeof(msgInternalStatisticsItemCollect_type));
        if (status == ERROR)
        {
            VCCB_PRINT_ERROR("FnVCCB_SendMessageToVCCB ERROR in FnVCCB_SendInternalStatisticsItemCollect!\n");
        }

        if (DBG->log.logStoreStatThrdInternalMsg)
        {
            logShmNonUeIntMsg(
                TX_MSG, BLK_VCCB, InternalStatisticsItemCollect_id, sizeof(msgInternalStatisticsItemCollect_type), reinterpret_cast<uint8_t *>(&msg), 0);
            VCCB_PRINT_ERROR("[TX] InternalStatisticsItemCollect_id (threadId:%d)\n", threadId);
        }

        memset(msg.mItem, 0,msg.itemCount * sizeof(VccbStatisticsTemporaryCollect_type) );
        msg.itemCount = 0;
    }

    if (DBG->flag.statThreadUsage == VCCB_FLAG_ON)
    {
        VLIB_AttachTimerNonCore(&gStatisticsItemCollect[threadId].timer,
            timInternalStatisticsItemCollect_id, VLIB_GetTimerVal(timInternalStatisticsItemCollect_id), VCCB_CALL_ADDR[threadId].MdsPort);
    }
}

template <typename collectType>
void FnVCCB_StatisticsItemCollect(uint32_t mFamily, uint32_t mType,
        collectType val, const VccbPmKey_type &rPmKey, uint8_t threadId, enumStatisticsValueType valueType)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB); // Call Thread

    const uint32_t maxItem = MIN(DBG->value.maxThreadCollectItem, MAX_STATISTICS_COLLECT_ITEM_PER_THREAD);

    uint32_t &itemCount = gStatisticsItemCollect[threadId].msg.itemCount;
    VCCB_CHECK_E_RANGE_AND_VOID(itemCount, MAX_STATISTICS_COLLECT_ITEM_PER_THREAD);

    VccbStatisticsTemporaryCollect_type &mItem = gStatisticsItemCollect[threadId].msg.mItem[itemCount];

    mItem.mFamily = mFamily;
    mItem.mType = mType;
    mItem.valueType = valueType; // 0: vpmCollectUint, 1: vpmCollectUll, 2: vpmCollectFloat
    switch (valueType)
    {
        case STATISTICS_UINT_TYPE:
            mItem.uVal = static_cast<uint32_t>(val);
            break;
        case STATISTICS_ULL_TYPE:
            mItem.lVal = static_cast<uint64_t>(val);
            break;
        case STATISTICS_FLOAT_TYPE:
            mItem.fVal = static_cast<float>(val);
            break;
        default:
            break;
    }
    mItem.key[0] = rPmKey.keyList[VCCB_PMKEY_INDEX1];
    mItem.key[1] = rPmKey.keyList[VCCB_PMKEY_INDEX2];
    mItem.key[2] = rPmKey.keyList[VCCB_PMKEY_INDEX3];
    mItem.key[3] = rPmKey.keyList[VCCB_PMKEY_INDEX4];
    mItem.key[4] = rPmKey.keyList[VCCB_PMKEY_INDEX5];
    mItem.key[5] = rPmKey.keyList[VCCB_PMKEY_INDEX6];
    mItem.key[6] = rPmKey.keyList[VCCB_PMKEY_INDEX7];

    if (DBG->log.logStoreStatThrdInternalMsg)
    {
        VCCB_PRINT_ERROR("[StatCollect] : itemCount=%d, valueType:%d (Family/Type/Value/Index.. = %d/%d/%d/%llu/%llu/%llu/%llu/%llu/%llu)\n",
                itemCount, mItem.valueType, mItem.mFamily, mItem.mType, mItem.uVal,
                mItem.key[0], mItem.key[1], mItem.key[2],
                mItem.key[3], mItem.key[4], mItem.key[5]);
    }

    itemCount++;
    if (itemCount >= maxItem)
    {
        //VCCB_CLEAR_TIMER(&gStatisticsItemCollect[threadId].timer, CANCEL_TIMER);
        VLIB_DetachTimerNonCore(&gStatisticsItemCollect[threadId].timer);
        FnVCCB_SendInternalStatisticsItemCollect(threadId);
    }
    else
    {
        if (DBG->log.logStoreStatThrdInternalMsg == VCCB_FLAG_ON)
        {
            VCCB_PRINT_COMMENT("Skip FnVCCB_SendMessageToVCCB! (gCurStatisticsCollectIndex[threadId:%u] = %u, max = %u)\n", threadId, itemCount, maxItem);
        }
    }

}

void FnVCCB_SendInternalStatisticsItemUpdate(uint8_t threadId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB); // Call Thread

    msgInternalStatisticsItemUpdate_type &msg = gStatisticsItemUpdate[threadId].msg;

    // TODO: If a timer expired and there is no statistics collection at all, it should not send a message.
    if (msg.itemCount > 0)
    {
        if (msg.itemCount > MAX_STATISTICS_UPDATE_ITEM_PER_THREAD)
        {
            VCCB_PRINT_ERROR("itemCount(%u) exceeds max(%u) in %s\n", msg.itemCount, MAX_STATISTICS_UPDATE_ITEM_PER_THREAD, __func__);
            msg.itemCount = MAX_STATISTICS_UPDATE_ITEM_PER_THREAD;
        }

        msg.hdr.msgType = InternalStatisticsItemUpdate_id;
        msg.threadId = threadId;

        int status = FnVCCB_SendMessageToVCCB(msg.hdr.msgType, threadId, reinterpret_cast<char *>(&msg), sizeof(msgInternalStatisticsItemUpdate_type));
        if (status == ERROR)
        {
            VCCB_PRINT_ERROR("FnVCCB_SendMessageToVCCB ERROR in FnVCCB_SendInternalStatisticsItemUpdate!\n");
        }

        if (DBG->log.logStoreStatThrdInternalMsg)
        {
            logShmNonUeIntMsg(
                    TX_MSG, BLK_VCCB, InternalStatisticsItemUpdate_id, sizeof(msgInternalStatisticsItemUpdate_type), reinterpret_cast<uint8_t *>(&msg), 0);
            VCCB_PRINT_ERROR("[TX] InternalStatisticsItemUpdate_id (threadId:%d)\n", threadId);
        }

        memset(msg.mItem, 0, msg.itemCount * sizeof(VccbStatisticsTemporaryUpdate_type));
        msg.itemCount = 0;
    }

    if (DBG->flag.statThreadUsage == VCCB_FLAG_ON)
    {
        VLIB_AttachTimerNonCore(&gStatisticsItemUpdate[threadId].timer,
            timInternalStatisticsItemUpdate_id, VLIB_GetTimerVal(timInternalStatisticsItemUpdate_id), VCCB_CALL_ADDR[threadId].MdsPort);
    }
}

template <typename updateType>
void FnVCCB_StatisticsItemUpdate(uint32_t mFamily, uint32_t numOfItem,
        updateType *updateItemArr, const VccbPmKey_type &rPmKey, uint8_t threadId, enumStatisticsValueType valueType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(updateItemArr);
    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB); // Call Thread

    const uint32_t maxItem = MIN(DBG->value.maxThreadUpdateItem, MAX_STATISTICS_UPDATE_ITEM_PER_THREAD);

    uint32_t &itemCount = gStatisticsItemUpdate[threadId].msg.itemCount;
    VCCB_CHECK_E_RANGE_AND_VOID(itemCount, MAX_STATISTICS_UPDATE_ITEM_PER_THREAD);

    bool debugPrintFlag = DBG->log.logStoreStatThrdInternalMsg;

    VccbStatisticsTemporaryUpdate_type &mItem = gStatisticsItemUpdate[threadId].msg.mItem[itemCount];

    mItem.mFamily = mFamily;
    mItem.valueType = valueType;
    mItem.numOfItem = static_cast<uint16_t>(MIN(numOfItem, VCCB_MAX_STAT_THREAD_MTYPES));

    for (uint32_t i = 0; i < numOfItem; i++)
    {
        switch (valueType)
        {
            case STATISTICS_UINT_TYPE:
                mItem.updateItemUintArr[i].typeID = updateItemArr[i].typeID;
                mItem.updateItemUintArr[i].updateMethod = updateItemArr[i].updateMethod;
                mItem.updateItemUintArr[i].updateVal = static_cast<uint32_t>(updateItemArr[i].updateVal);

                if (debugPrintFlag)
                {
                    VCCB_PRINT_ERROR("[StatUpdate] : InputItem[%2d] - [%2d] TYPE=%d Value=%d\n", itemCount,
                        i, mItem.updateItemUintArr[i].typeID, mItem.updateItemUintArr[i].updateVal);
                }
                break;

            case STATISTICS_ULL_TYPE:
                mItem.updateItemUllArr[i].typeID = updateItemArr[i].typeID;
                mItem.updateItemUllArr[i].updateMethod = updateItemArr[i].updateMethod;
                mItem.updateItemUllArr[i].updateVal = static_cast<uint64_t>(updateItemArr[i].updateVal);
                break;

            case STATISTICS_FLOAT_TYPE:
                mItem.updateItemFloatArr[i].typeID = updateItemArr[i].typeID;
                mItem.updateItemFloatArr[i].updateMethod = updateItemArr[i].updateMethod;
                mItem.updateItemFloatArr[i].updateVal = static_cast<float>(updateItemArr[i].updateVal);
                break;

            default:
                break;
        }
    }

    mItem.key[0] = rPmKey.keyList[VCCB_PMKEY_INDEX1];
    mItem.key[1] = rPmKey.keyList[VCCB_PMKEY_INDEX2];
    mItem.key[2] = rPmKey.keyList[VCCB_PMKEY_INDEX3];
    mItem.key[3] = rPmKey.keyList[VCCB_PMKEY_INDEX4];
    mItem.key[4] = rPmKey.keyList[VCCB_PMKEY_INDEX5];
    mItem.key[5] = rPmKey.keyList[VCCB_PMKEY_INDEX6];
    mItem.key[6] = rPmKey.keyList[VCCB_PMKEY_INDEX7];

    if (debugPrintFlag)
    {
        VCCB_PRINT_ERROR("[StatUpdate] :         (Family/Index.. = %d/%llu/%llu/%llu/%llu/%llu/%llu)\n",
                mItem.mFamily,
                mItem.key[0], mItem.key[1], mItem.key[2],
                mItem.key[3], mItem.key[4], mItem.key[5]);
    }

    itemCount++;
    if (itemCount >= maxItem)
    {
        // VCCB_CLEAR_TIMER(&gStatisticsItemUpdate[threadId].timer, CANCEL_TIMER);
        VLIB_DetachTimerNonCore(&gStatisticsItemUpdate[threadId].timer);
        FnVCCB_SendInternalStatisticsItemUpdate(threadId);
    }
    else
    {
        if (debugPrintFlag)
        {
            VCCB_PRINT_COMMENT("Skip FnVCCB_SendMessageToVCCB! (gCurStatisticsUpdateIndex[threadId:%u] = %u, max = %u)\n", threadId, itemCount, maxItem);
        }
    }

}

uint8_t isSupportedStatisticFamilyForCNF(int family)
{
    switch (family)
    {
        // For CNF, below statistic families will be supported in 21B with other family name
        case STAT_CPC_CALL_USAGE:
            return FALSE;

        default:
            return TRUE;
    }
}

void FnVCCB_InitPmMultiCollect(VccbPmMultiCollect_type *pSrc, PME_LIB_TYPE type)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pSrc);

    memset(pSrc, 0x00, sizeof(VccbPmMultiCollect_type));

    pSrc->updateMethod = type;

    switch (type)
    {
        case PME_LIB_GAUGE:
        case PME_LIB_SI:
            pSrc->updateItemFloatArr->updateMethod = type;
            break;

        case PME_LIB_CC:
            pSrc->updateItemUintArr->updateMethod = type;
            break;

        default:
            VCCB_PRINT_ERROR("Unsupported Invalid Pme Lib Type(%d)\n", type);
            return;
    }
}

static inline enumStatTypeClassification FnVCCB_GetStatType(int familyId, int typeId)
{
#define IS_ATTEMPT_TYPE_ID(_attemptTypeId) if(typeId == _attemptTypeId) return STAT_TYPE_ATTEMPT
#define IS_PREP_SUCCESS_TYPE_ID(_prepSuccessTypeId) if(typeId == _prepSuccessTypeId) return STAT_TYPE_PREP_SUCCESS

    switch (familyId)
    {
        case STAT_LB_PSCELL_CHANGE:
            IS_ATTEMPT_TYPE_ID(LbPscellChange_Att);
            IS_PREP_SUCCESS_TYPE_ID(LbPscellChange_PrepSucc);
            break;
        case STAT_INTER_DU_PSCELL_CHANGE_GETTING_BACK:
            IS_ATTEMPT_TYPE_ID(InterDuPscellChgGetBackAtt);
            break;
        case STAT_SGNB_ADD_PER_GNB:
            IS_ATTEMPT_TYPE_ID(EndcAddAtt);
            IS_PREP_SUCCESS_TYPE_ID(EndcAddPrepSucc);
            break;
        case STAT_SGNB_ADD_PER_GNB_PER_DU:
            IS_ATTEMPT_TYPE_ID(EndcAddAtt_DU_cell);
            IS_PREP_SUCCESS_TYPE_ID(EndcAddPrepSucc_DU_cell);
            break;
        case STAT_SGNB_ADD_PER_DU_PER_GNB:
            IS_ATTEMPT_TYPE_ID(EndcAddAtt_DU);
            IS_PREP_SUCCESS_TYPE_ID(EndcAddPrepSucc_DU);
            break;
        case STAT_SGNB_ADD_PER_GNB_PLMN:
            IS_ATTEMPT_TYPE_ID(EndcAddAttPlmn);
            IS_PREP_SUCCESS_TYPE_ID(EndcAddPrepSuccPlmn);
            break;
        case STAT_SGNB_ADD_PER_GNB_ECI_DU_ID:
            IS_ATTEMPT_TYPE_ID(EndcAddAtt_ECI_DUID);
            IS_PREP_SUCCESS_TYPE_ID(EndcAddPrepSucc_ECI_DUID);
            break;
        case STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG:
            IS_ATTEMPT_TYPE_ID(EndcAddLteHoNoSgnbChgAtt);
            IS_PREP_SUCCESS_TYPE_ID(EndcAddLteHoNoSgnbChgPrepSucc);
            break;
        case STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG_GLOBAL_ID_SPID:
            IS_ATTEMPT_TYPE_ID(EndcAddLteHoNoSgnbChgAtt_SPID);
            IS_PREP_SUCCESS_TYPE_ID(EndcAddLteHoNoSgnbChgPrepSucc_SPID);
            break;
        case STAT_SGNB_ADD_SGNB_CHG:
            IS_ATTEMPT_TYPE_ID(EndcAddSgnbChgAtt);
            IS_PREP_SUCCESS_TYPE_ID(EndcAddSgnbChgPrepSucc);
            break;
        case STAT_SGNB_ADD_SGNB_CHG_GLOBAL_ID_SPID:
            IS_ATTEMPT_TYPE_ID(EndcAddSgnbChgAtt_SPID);
            IS_PREP_SUCCESS_TYPE_ID(EndcAddSgnbChgPrepSucc_SPID);
            break;
        case STAT_SGNB_ADD_MNHO_INTRA_ENB:
            IS_ATTEMPT_TYPE_ID(EndcAddMnHoIntraEnbAtt);
            IS_PREP_SUCCESS_TYPE_ID(EndcAddMnHoIntraEnbPrepSucc);
            break;
        case STAT_SGNB_ADD_MNHO_INTRA_ENB_GLOBAL_ID_SPID:
            IS_ATTEMPT_TYPE_ID(EndcAddMnHoIntraEnbAtt_SPID);
            IS_PREP_SUCCESS_TYPE_ID(EndcAddMnHoIntraEnbPrepSucc_SPID);
            break;
        case STAT_SGNB_ADD_MNHO_INTER_ENB:
            IS_ATTEMPT_TYPE_ID(EndcAddMnHoInterEnbAtt);
            IS_PREP_SUCCESS_TYPE_ID(EndcAddMnHoInterEnbPrepSucc);
            break;
        case STAT_SGNB_ADD_MNHO_INTER_ENB_GLOBAL_ID_SPID:
            IS_ATTEMPT_TYPE_ID(EndcAddMnHoInterEnbAtt_SPID);
            IS_PREP_SUCCESS_TYPE_ID(EndcAddMnHoInterEnbPrepSucc_SPID);
            break;
        case STAT_SGNB_INIT_SGNB_MOD_PER_GNB:
            IS_ATTEMPT_TYPE_ID(EndcModBySgnbAtt);
            break;
        case STAT_MENB_INIT_SGNB_MOD_PER_GNB:
            IS_ATTEMPT_TYPE_ID(EndcModByMenbAtt);
            IS_PREP_SUCCESS_TYPE_ID(EndcModByMenbPrepSucc);
            break;
        case STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB:
            IS_ATTEMPT_TYPE_ID(EndcIntraChgAtt);
            IS_PREP_SUCCESS_TYPE_ID(EndcIntraChgPrepSucc);
            break;
        case STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB_DU_ID_CELL_SPID:
            IS_ATTEMPT_TYPE_ID(EndcIntraChgAtt_DUID_SPID);
            IS_PREP_SUCCESS_TYPE_ID(EndcIntraChgPrepSucc_DUID_SPID);
            break;
        case STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB:
            IS_ATTEMPT_TYPE_ID(EndcInterChgSrcAtt);
            IS_PREP_SUCCESS_TYPE_ID(EndcInterChgSrcPrepSucc);
            break;
        case STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB_DU_ID_CELL_SPID:
            IS_ATTEMPT_TYPE_ID(EndcInterChgSrcAtt_DUID_SPID);
            IS_PREP_SUCCESS_TYPE_ID(EndcInterChgSrcPrepSucc_DUID_SPID);
            break;
        case STAT_INTRA_FREQ_PSCELL_CHANGE_SCGMOB_PER_GNB_DU_ID:
            IS_ATTEMPT_TYPE_ID(EndcIntraFreqIntraSnChgAtt);
            IS_PREP_SUCCESS_TYPE_ID(EndcIntraFreqIntraSnChgPrepSucc);

            IS_ATTEMPT_TYPE_ID(EndcIntraFreqInterSnChgAtt);
            IS_PREP_SUCCESS_TYPE_ID(EndcIntraFreqInterSnChgPrepSucc);
            break;
        case STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB:
            IS_ATTEMPT_TYPE_ID(EndcModByMenbMcgMobAtt);
            IS_PREP_SUCCESS_TYPE_ID(EndcModByMenbMcgMobPrepSucc);
            break;
        case STAT_ERAB_ADD_PER_GNB:
            IS_ATTEMPT_TYPE_ID(ErabAddAtt);
            break;
        case STAT_ERAB_MOD_PER_GNB:
            IS_ATTEMPT_TYPE_ID(ErabModAtt);
            break;
        case STAT_F1AP_UE_SETUP_CU:
            IS_ATTEMPT_TYPE_ID(CU_F1UeSetupAtt);
            break;
        case STAT_F1AP_CU_INIT_UE_MOD_CU:
            IS_ATTEMPT_TYPE_ID(CU_F1CuInitUeModAtt);
            break;
        case STAT_HO_OUT:
        case STAT_HO_OUT_SERVICE_TYPE:
            // Mismatched STAT_HO_OUT_SERVICE_TYPE from STAT_HO_OUT
            STAT_HO_OUT_TYPE_FROM_SERVICE_TYPE(familyId, typeId);

            IS_ATTEMPT_TYPE_ID(IntraGnbOut_Att);
            IS_PREP_SUCCESS_TYPE_ID(IntraGnbOut_PrepSucc);

            IS_ATTEMPT_TYPE_ID(InterXnOut_Att);
            IS_PREP_SUCCESS_TYPE_ID(InterXnOut_PrepSucc);

            IS_ATTEMPT_TYPE_ID(InterNgOut_Att);
            IS_PREP_SUCCESS_TYPE_ID(InterNgOut_PrepSucc);

            IS_ATTEMPT_TYPE_ID(IntraGnbOutWithNedc_Att);
            IS_PREP_SUCCESS_TYPE_ID(IntraGnbOutWithNedc_PrepSucc);

            IS_ATTEMPT_TYPE_ID(InterXnOutWithNedc_Att);
            IS_PREP_SUCCESS_TYPE_ID(InterXnOutWithNedc_PrepSucc);

            IS_ATTEMPT_TYPE_ID(InterNgOutWithNedc_Att);
            IS_PREP_SUCCESS_TYPE_ID(InterNgOutWithNedc_PrepSucc);

            IS_ATTEMPT_TYPE_ID(IntraGnbOutWithNrdc_Att);
            IS_PREP_SUCCESS_TYPE_ID(IntraGnbOutwithNrdc_PrepSucc);

            IS_ATTEMPT_TYPE_ID(InterXnOutwithNrdc_Att);
            IS_PREP_SUCCESS_TYPE_ID(InterXnOutwithNrdc_PrepSucc);

            IS_ATTEMPT_TYPE_ID(InterNgOutwithNrdc_Att);
            IS_PREP_SUCCESS_TYPE_ID(InterNgOutwithNrdc_PrepSucc);
            break;
        case STAT_HO_IN:
        case STAT_HO_IN_SERVICE_TYPE:
            IS_ATTEMPT_TYPE_ID(IntraGnbIn_Att);
            IS_PREP_SUCCESS_TYPE_ID(IntraGnbIn_PrepSucc);

            IS_ATTEMPT_TYPE_ID(InterXnIn_Att);
            IS_PREP_SUCCESS_TYPE_ID(InterXnIn_PrepSucc);

            IS_ATTEMPT_TYPE_ID(InterNgIn_Att);
            IS_PREP_SUCCESS_TYPE_ID(InterNgIn_PrepSucc);

            IS_ATTEMPT_TYPE_ID(IntraGnbInWithNedc_Att);
            IS_PREP_SUCCESS_TYPE_ID(IntraGnbInWithNedc_PrepSucc);

            IS_ATTEMPT_TYPE_ID(InterXnInWithNedc_Att);
            IS_PREP_SUCCESS_TYPE_ID(InterXnInWithNedc_PrepSucc);

            IS_ATTEMPT_TYPE_ID(InterNgInWithNedc_Att);
            IS_PREP_SUCCESS_TYPE_ID(InterNgInWithNedc_PrepSucc);

            IS_ATTEMPT_TYPE_ID(IntraGnbInWithNrdc_Att);
            IS_PREP_SUCCESS_TYPE_ID(IntraGnbInWithNrdc_PrepSucc);

            IS_ATTEMPT_TYPE_ID(InterXnInWithNrdc_Att);
            IS_PREP_SUCCESS_TYPE_ID(InterXnInWithNrdc_PrepSucc);

            IS_ATTEMPT_TYPE_ID(InterNgInWithNrdc_Att);
            IS_PREP_SUCCESS_TYPE_ID(InterNgInWithNrdc_PrepSucc);
            break;
        case STAT_HO_IN_REDCAP:
            IS_ATTEMPT_TYPE_ID(IntraGnbIn_Att_RedCap);
            IS_PREP_SUCCESS_TYPE_ID(IntraGnbIn_PrepSucc_RedCap);

            IS_ATTEMPT_TYPE_ID(InterXnIn_Att_RedCap);
            IS_PREP_SUCCESS_TYPE_ID(InterXnIn_PrepSucc_RedCap);

            IS_ATTEMPT_TYPE_ID(InterNgIn_Att_RedCap);
            IS_PREP_SUCCESS_TYPE_ID(InterNgIn_PrepSucc_RedCap);
            break;
        case STAT_RRC_ESTAB:
            IS_ATTEMPT_TYPE_ID(ConnEstabAtt);
            break;
        case STAT_NG_ESTAB:
            IS_ATTEMPT_TYPE_ID(NgConnEstabAtt);
            break;
        case STAT_NG_ESTAB_DU_ID_PLMN:
            IS_ATTEMPT_TYPE_ID(NgConnEstabAtt);
            break;
        case STAT_INITIAL_CONTEXT_SETUP:
            IS_ATTEMPT_TYPE_ID(InitialContextSetupAtt_DUID);
            break;
        case STAT_RRC_REESTAB:
            IS_ATTEMPT_TYPE_ID(IntraGnbReEstabAtt);
            IS_PREP_SUCCESS_TYPE_ID(IntraGnbReEstabRreAtt);
            IS_PREP_SUCCESS_TYPE_ID(IntraGnbReEstabRrcSetupAtt);

            IS_ATTEMPT_TYPE_ID(InterGnbReEstabAtt);
            IS_PREP_SUCCESS_TYPE_ID(InterGnbReEstabRreAtt);
            IS_PREP_SUCCESS_TYPE_ID(InterGnbReEstabRrcSetupAtt);
            break;
        case STAT_HO_EUTRAN_OUT:
        case STAT_HO_EUTRAN_OUT_SERVICE_TYPE:
            IS_ATTEMPT_TYPE_ID(InterSysLTE_Out_Att);
            IS_PREP_SUCCESS_TYPE_ID(InterSysLTE_Out_PrepSucc);
            break;
        case STAT_HO_EUTRAN_OUT_FALLBACK:
        case STAT_HO_EUTRAN_OUT_FALLBACK_SERVICE_TYPE:
            IS_ATTEMPT_TYPE_ID(InterSysLTE_Out_EPSFallback_Att);
            IS_PREP_SUCCESS_TYPE_ID(InterSysLTE_Out_EPSFallback_PrepSucc);

            IS_ATTEMPT_TYPE_ID(InterSysLTE_Out_EmergencyFallback_Att);
            IS_PREP_SUCCESS_TYPE_ID(InterSysLTE_Out_EmergencyFallback_PrepSucc);
            break;
        case STAT_HO_EUTRAN_FREQ_OUT:
        case STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE:
            IS_ATTEMPT_TYPE_ID(InterSysLTE_Out_Att_FREQ_OUT);
            IS_PREP_SUCCESS_TYPE_ID(InterSysLTE_Out_PrepSucc_FREQ_OUT);

            IS_ATTEMPT_TYPE_ID(InterSysLTE_Out_EPSFallback_Att_FREQ_OUT);
            IS_PREP_SUCCESS_TYPE_ID(InterSysLTE_Out_EPSFallback_PrepSucc_FREQ_OUT);

            IS_ATTEMPT_TYPE_ID(InterSysLTE_Out_EmergencyFallback_Att_FREQ_OUT);
            IS_PREP_SUCCESS_TYPE_ID(InterSysLTE_Out_EmergencyFallback_PrepSucc_FREQ_OUT);
            break;
        case STAT_HO_EUTRAN_FREQ_OUT_REDCAP:
            IS_ATTEMPT_TYPE_ID(InterSysLTE_Out_Att_RedCap);
            IS_PREP_SUCCESS_TYPE_ID(InterSysLTE_Out_PrepSucc_RedCap);

            IS_ATTEMPT_TYPE_ID(InterSysLTE_Out_EPSFallback_Att_RedCap);
            IS_PREP_SUCCESS_TYPE_ID(InterSysLTE_Out_EPSFallback_PrepSucc_RedCap);

            IS_ATTEMPT_TYPE_ID(InterSysLTE_Out_EmergencyFallback_Att_RedCap);
            IS_PREP_SUCCESS_TYPE_ID(InterSysLTE_Out_EmergencyFallback_PrepSucc_RedCap);
            break;
        case STAT_SGNB_ADD_EUTRAN_OUT:
            IS_ATTEMPT_TYPE_ID(EndcAddAtt);
            IS_PREP_SUCCESS_TYPE_ID(EndcAddPrepSucc);
            break;
        case STAT_HO_EUTRAN_IN:
        case STAT_HO_EUTRAN_IN_SERVICE_TYPE:
            IS_ATTEMPT_TYPE_ID(InterSysLTE_In_Att); // InterSysLTE_In_Att == InterSysLTE_In_Att_SERVICE_TYPE
            IS_PREP_SUCCESS_TYPE_ID(InterSysLTE_In_PrepSucc);
            break;
        case STAT_HO_EUTRAN_IN_REDCAP:
            IS_ATTEMPT_TYPE_ID(InterSysLTE_In_Att_RedCap);
            IS_PREP_SUCCESS_TYPE_ID(InterSysLTE_In_PrepSucc_RedCap);
            break;
        case STAT_HO_INTER_FREQ_OUT:
        case STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE:
            IS_ATTEMPT_TYPE_ID(InterFreqOutWithGap_Att);
            IS_PREP_SUCCESS_TYPE_ID(InterFreqOutWithGap_PrepSucc);

            IS_ATTEMPT_TYPE_ID(InterFreqOutWithoutGap_Att);
            IS_PREP_SUCCESS_TYPE_ID(InterFreqOutWithoutGap_PrepSucc);
            break;
        case STAT_HO_INTER_FREQ_OUT_REDCAP:
            IS_ATTEMPT_TYPE_ID(InterFreqOutWithGap_Att_RedCap);
            IS_PREP_SUCCESS_TYPE_ID(InterFreqOutWithGap_PrepSucc_RedCap);

            IS_ATTEMPT_TYPE_ID(InterFreqOutWithoutGap_Att_RedCap);
            IS_PREP_SUCCESS_TYPE_ID(InterFreqOutWithoutGap_PrepSucc_RedCap);
            break;
        case STAT_HO_INTRA_FREQ_OUT:
        case STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE:
            IS_ATTEMPT_TYPE_ID(IntraFreqOut_Att);
            IS_PREP_SUCCESS_TYPE_ID(IntraFreqOut_PrepSucc);
            break;
        case STAT_HO_INTRA_FREQ_OUT_REDCAP:
            IS_ATTEMPT_TYPE_ID(IntraFreqOut_Att_RedCap);
            IS_PREP_SUCCESS_TYPE_ID(IntraFreqOut_PrepSucc_RedCap);
            break;
        case STAT_NEDC_ADD:
            IS_ATTEMPT_TYPE_ID(NedcAddAtt);
            IS_PREP_SUCCESS_TYPE_ID(NedcAddPrepSucc);
            break;
        case STAT_NEDC_DRB_SETUP:
            IS_ATTEMPT_TYPE_ID(NedcDrbSetupAtt);
            break;
        case STAT_NEDC_DRB_MOD:
            IS_ATTEMPT_TYPE_ID(NedcDrbModByMgnbAtt);
            IS_ATTEMPT_TYPE_ID(NedcDrbModBySenbAtt);
            break;
        case STAT_NRDC_SN_ADD_MN:
        case STAT_NRDC_SN_ADD_MN_PSCELL_NCI:
            IS_ATTEMPT_TYPE_ID(NrdcAddMn_Att);
            IS_PREP_SUCCESS_TYPE_ID(NrdcAddMn_PrepSucc);

            IS_ATTEMPT_TYPE_ID(NrdcAddMn_IntraMnMobilityWithSgnbChg_Att);
            IS_PREP_SUCCESS_TYPE_ID(NrdcAddMn_IntraMnMobilityWithSgnbChg_PrepSucc);

            IS_ATTEMPT_TYPE_ID(NrdcAddMn_InterMnMobilityWithSgnbChg_Att);
            IS_PREP_SUCCESS_TYPE_ID(NrdcAddMn_InterMnMobilityWithSgnbChg_PrepSucc);

            IS_ATTEMPT_TYPE_ID(NrdcAddMn_InterMnMobilityWithoutSgnbChg_Att);
            IS_PREP_SUCCESS_TYPE_ID(NrdcAddMn_InterMnMobilityWithoutSgnbChg_PrepSucc);

            IS_ATTEMPT_TYPE_ID(NrdcAddMn_SnChange_Att);
            IS_PREP_SUCCESS_TYPE_ID(NrdcAddMn_SnChange_PrepSucc);
            break;
        case STAT_NRDC_SN_ADD_SN_WITH_INVALID_CELL:
        case STAT_NRDC_SN_ADD_SN_PCELL_NCI:
            IS_ATTEMPT_TYPE_ID(NrdcAddSn_Att);
            IS_PREP_SUCCESS_TYPE_ID(NrdcAddSn_PrepSucc);

            IS_ATTEMPT_TYPE_ID(NrdcAddSn_IntraMnMobilityWithSgnbChange_Att);
            IS_PREP_SUCCESS_TYPE_ID(NrdcAddSn_IntraMnMobilityWithSgnbChange_PrepSucc);

            IS_ATTEMPT_TYPE_ID(NrdcAddSn_InterMnMobilityWithSgnbChange_Att);
            IS_PREP_SUCCESS_TYPE_ID(NrdcAddSn_InterMnMobilityWithSgnbChange_PrepSucc);

            IS_ATTEMPT_TYPE_ID(NrdcAddSn_InterMnMobilityWithoutSgnbChange_Att);
            IS_PREP_SUCCESS_TYPE_ID(NrdcAddSn_InterMnMobilityWithoutSgnbChange_PrepSucc);

            IS_ATTEMPT_TYPE_ID(NrdcAddSn_SnChange_Att);
            IS_PREP_SUCCESS_TYPE_ID(NrdcAddSn_SnChange_PrepSucc);
            break;
        // FGR-CC5200:FR680
        case V_STAT_NRDC_SN_MOD_MN_MNInitiated:
            IS_ATTEMPT_TYPE_ID(NrdcModMn_MnInit_Att);
            break;
        case V_STAT_NRDC_SN_MOD_MN_SNInitiated:
            IS_ATTEMPT_TYPE_ID(NrdcModMn_SnInit_Att);
            break;
        case V_STAT_NRDC_SN_MOD_SN_MNInitiated:
            IS_ATTEMPT_TYPE_ID(NrdcModSn_MnInit_Att);
            break;
        case V_STAT_NRDC_SN_MOD_SN_SNInitiated:
            IS_ATTEMPT_TYPE_ID(NrdcModSn_SnInit_Att);
            break;
        case STAT_NRDC_PSCELL_CHANGE_IN:
            IS_ATTEMPT_TYPE_ID(NrdcPsCellChange_In_MnInit_IntraSn_Att);
            IS_PREP_SUCCESS_TYPE_ID(NrdcPsCellChange_In_MnInit_IntraSn_PrepSucc);

            IS_ATTEMPT_TYPE_ID(NrdcPsCellChange_In_SnInit_IntraSn_Att);
            IS_PREP_SUCCESS_TYPE_ID(NrdcPsCellChange_In_SnInit_IntraSn_PrepSucc);
            break;
        case STAT_NRDC_PSCELL_CHANGE_OUT:
            IS_ATTEMPT_TYPE_ID(NrdcPsCellChange_Out_MnInit_IntraSn_Att);
            IS_PREP_SUCCESS_TYPE_ID(NrdcPsCellChange_Out_MnInit_IntraSn_PrepSucc);

            IS_ATTEMPT_TYPE_ID(NrdcPsCellChange_Out_MnInit_InterSn_Att);
            IS_PREP_SUCCESS_TYPE_ID(NrdcPsCellChange_Out_MnInit_InterSn_PrepSucc);

            IS_ATTEMPT_TYPE_ID(NrdcPsCellChange_Out_SnInit_IntraSn_Att);
            IS_PREP_SUCCESS_TYPE_ID(NrdcPsCellChange_Out_SnInit_IntraSn_PrepSucc);

            IS_ATTEMPT_TYPE_ID(NrdcPsCellChange_Out_SnInit_InterSn_Att);
            IS_PREP_SUCCESS_TYPE_ID(NrdcPsCellChange_Out_SnInit_InterSn_PrepSucc);
            break;
        case STAT_DRB_SETUP:
            IS_ATTEMPT_TYPE_ID(DrbSetupAtt);
            break;
        case STAT_DRB_SETUP_PLMN_SNSSAI:
        case STAT_DRB_SETUP_PLMN_SNSSAI_5QI:
        case STAT_DRB_SETUP_GLOBAL_ID_RFSP:
            IS_ATTEMPT_TYPE_ID(DrbSetupPlmnSnssaiAtt);
            break;
        case STAT_PDU_SESSION_RESOURCE_MODIFY_REQUEST_DRB_SETUP:
            IS_ATTEMPT_TYPE_ID(DrbSetupAtt_PduSessionResourceModify);
            break;
        case STAT_DRB_RELEASE_AND_ERASE:
            IS_ATTEMPT_TYPE_ID(DrbRelAtt);
            IS_ATTEMPT_TYPE_ID(DrbEraseAtt);
            break;
        case STAT_PDU_SESSION_RESOURCE_SETUP_PLMN_SNSSAI:
            IS_ATTEMPT_TYPE_ID(PduSetupPlmnSnssaiAtt);
            break;
        case STAT_PDU_SESSION_RESOURCE_MODIFY_PLMN_SNSSAI_RFSP:
            IS_ATTEMPT_TYPE_ID(PduSetupPlmnSnssaiAtt);
            break;
        case STAT_QOS_FLOW_SETUP:
            IS_ATTEMPT_TYPE_ID(QosFlowSetupAtt);
            break;
        case STAT_QOS_FLOW_SETUP_PLMN_SNSSAI:
            IS_ATTEMPT_TYPE_ID(QosFlowSetupPlmnSnssaiAtt);
            break;
        case STAT_INITIAL_DRB_SETUP_DU_ID:
            IS_ATTEMPT_TYPE_ID(DrbSetupAtt);
            break;
        case STAT_INITIAL_DRB_SETUP_DU_ID_PLMN_SNSSAI:
            IS_ATTEMPT_TYPE_ID(DrbSetupPlmnSnssaiAtt);
            break;
        case STAT_CHO_OUT:
            IS_ATTEMPT_TYPE_ID(ChoXnOut_PrepAtt);
            IS_ATTEMPT_TYPE_ID(ChoXnOut_ExeAccess);
            IS_ATTEMPT_TYPE_ID(ChoXnOutWithMrdc_PrepAtt);
            IS_ATTEMPT_TYPE_ID(ChoXnOutWithMrdc_ExeAccess);
            break;
        case STAT_CHO_IN:
            IS_ATTEMPT_TYPE_ID(ChoXnIn_PrepAtt);
            IS_ATTEMPT_TYPE_ID(ChoXnIn_ExeAccess);
            IS_ATTEMPT_TYPE_ID(ChoXnInWithMrdc_PrepAtt);
            IS_ATTEMPT_TYPE_ID(ChoXnInWithMrdc_ExeAccess);
            break;
        default:
            break;
    }

#undef IS_ATTEMPT_TYPE_ID
#undef IS_PREP_SUCCESS_TYPE_ID

    return STAT_TYPE_OTHER;
}

/**
 ** @brief     VLIB_PeriodicStat_DrbInfo
 **/
void VLIB_PeriodicStat_DrbInfo(VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;

    uint16_t qciIdx = 0;
    uint8_t plmnIdx = 0, plmnInfoIdx = 0;
    plmnId_type plmnToConvertBuff;
    uint16_t cellIdentity;
    uint32_t uePlmnKey = 0;

    VALID_E_POINT_CHECK_VOID(pCell);
    VCCB_CHECK_E_RANGE_AND_VOID(pCell->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(pCell->profileDBInfo.pdcpProfileIdx, MAX_PDCP_INFO_PROFILE_PER_GNB);
    VccbGnbInfo_type *pGnb = &GNBINFO[pCell->gnbNum];
    pdcpProfile_type *pPdcpProf = &pGnb->pdcpProfile[pCell->profileDBInfo.pdcpProfileIdx];
    if (pPdcpProf->status != EQUIP) return;

    cellIdentity = pCell->cellIdentity;

    for (qciIdx = 0; qciIdx < MAX_QCI_VALUE; qciIdx++)
    {
        if (pPdcpProf->pdcpInfoQci[qciIdx].shmStatus == N_EQUIP) continue;

        if (FALSE == FOO.VF_QoSSchedulingPerPLMN && FOO.VF_StandardQciSupport == TRUE &&
            !pGnb->qciSupport[qciIdx].usage)
            continue;

        bool qciPresentForAnyPlmnFlag = false;
        for (plmnIdx = 0; plmnIdx < MAX_PLMN_INDEX; plmnIdx++)
        {
            if (EQUIP == pCell->cellPlmnIndexInfo[plmnIdx].status)
            {
                plmnToConvertBuff.longId = pCell->cellPlmnIndexInfo[plmnIdx].servedPlmn;
                if (GOOD != VLIB_getMultipleGnbPlmnIndexInfo(pCell->gnbNum, &plmnInfoIdx, plmnToConvertBuff.longId))
                    continue;

                if (TRUE == FOO.VF_QoSSchedulingPerPLMN && FOO.VF_StandardQciSupport == TRUE &&
                    !pGnb->perPlmnQciSupport[plmnInfoIdx][qciIdx].usage)
                    continue;

                VLIB_ConvertPlmnIdToPlmnValue(&plmnToConvertBuff.s2, &uePlmnKey);
                MACRO_STAT_PMGAUGE(STAT_DRB_NUM_PER_GNB_PLMN, DrbNoAvg_Plmn, NULL,
                    (float)pCell->cfg.assignedEnDcDrbCountWithPlmn[qciIdx][plmnIdx], pCell->gnbNum, cellIdentity,
                    uePlmnKey, qciIdx);
                qciPresentForAnyPlmnFlag = true;
            }
        }
        if (qciPresentForAnyPlmnFlag)
        {
            // For the operators supporting [MORAN] and CNF system collect DRB count for EN-DC bearers
            // CP_DRB_NUM_PER_GNB_GLOBAL_ID collecting by DRB_NUM_PER_GNB
            if (FOO.VF_MultipleOperatorRanSupport && e_VCCB_ACPF_CNF == VCOM_getSystemType())
            {
                MACRO_STAT_PMGAUGE(STAT_DRB_NUM_PER_GNB, DrbNoAvg, NULL, (float)pCell->cfg.assignedEnDcDrbCount[qciIdx],
                    pCell->gnbNum, cellIdentity, qciIdx, 0);
            }
            else
            {
                MACRO_STAT_PMGAUGE(STAT_DRB_NUM_PER_GNB, DrbNoAvg, NULL, (float)pCell->cfg.assignedDrbCount[qciIdx],
                    pCell->gnbNum, cellIdentity, qciIdx, 0);
            }
        }
    }
}

/**
 ** @brief     VLIB_PeriodicStat_ErabInfo
 **/
void VLIB_PeriodicStat_ErabInfo(VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;

    uint16_t qciIdx = 0;
    uint16_t cellIdentity;

    VALID_E_POINT_CHECK_VOID(pCell);
    VCCB_CHECK_E_RANGE_AND_VOID(pCell->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(pCell->profileDBInfo.pdcpProfileIdx, MAX_PDCP_INFO_PROFILE_PER_GNB);
    VccbGnbInfo_type *pGnb = &GNBINFO[pCell->gnbNum];
    pdcpProfile_type *pPdcpProf = &pGnb->pdcpProfile[pCell->profileDBInfo.pdcpProfileIdx];
    if (pPdcpProf->status != EQUIP) return;
    cellIdentity = pCell->cellIdentity;

    for (qciIdx = 0; qciIdx < MAX_QCI_VALUE; qciIdx++)
    {
        if (pPdcpProf->pdcpInfoQci[qciIdx].shmStatus == N_EQUIP) continue;

        if (FOO.VF_StandardQciSupport == TRUE && !pGnb->qciSupport[qciIdx].usage) continue;
        MACRO_STAT_PMGAUGE(STAT_ERAB_NUM_UL_ONLY_ROHC, UlRohcErabNoAvg, NULL,
            (float)pCell->cfg.assignedULOnlyRoHCErabCount[qciIdx], pCell->gnbNum, cellIdentity, qciIdx, 0);
    }
}

/**
 ** @brief     VLIB_PeriodicStat_UEInfo
 **/
void VLIB_PeriodicStat_UEInfo(VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;
    uint8_t plmnIdx = 0;
    plmnId_type plmnToConvertBuff;
    uint16_t cellIdentity;
    uint32_t uePlmnKey = 0;
    uint16_t supportedSpidArrIdx = 0;

    VALID_E_POINT_CHECK_VOID(pCell);
    VCCB_CHECK_E_RANGE_AND_VOID(pCell->gnbNum, MAX_GNB_PER_SYS);

    cellIdentity = pCell->cellIdentity;

    gnbConfig_type *pGnbCfg = &GNBINFO[pCell->gnbNum].cfg;
    for (plmnIdx = 0; plmnIdx < MAX_PLMN_INDEX; plmnIdx++)
    {
        if (EQUIP == pCell->cellPlmnIndexInfo[plmnIdx].status)
        {
            plmnToConvertBuff.longId = pCell->cellPlmnIndexInfo[plmnIdx].servedPlmn;
            VLIB_ConvertPlmnIdToPlmnValue(&plmnToConvertBuff.s2, &uePlmnKey);

            MACRO_STAT_PMGAUGE(STAT_UE_NUM_PER_GNB_PLMN, UeNoAvg_Plmn, NULL,
                (float)pCell->cfg.assignedCellEnDcCallCount[plmnIdx], pCell->gnbNum, cellIdentity, uePlmnKey, 0);
            MACRO_STAT_PMGAUGE(STAT_UE_NUM_PER_GNB_PLMN, NonDssUeNoAvg_Plmn, NULL,
                (float)pCell->cfg.assignedNonDssEnDcUeCountWithPlmn[plmnIdx], pCell->gnbNum, cellIdentity, uePlmnKey,
                0);

            if (FOO.VF_SPIDBasedStatistics_ENDC)
            {
                uint32_t notSupportedSpidUeCnt = 0, notSupportedNonDssSpidUeCnt = 0;
                const bool isSpid0Supported = (pGnbCfg->supportedSPIDforStatistic[0] & 1);
                for (supportedSpidArrIdx = 0; supportedSpidArrIdx < MAX_SPID_ARR_SIZE; supportedSpidArrIdx++)
                {
                    uint32_t supportedSpids = pGnbCfg->supportedSPIDforStatistic[supportedSpidArrIdx];
                    uint16_t counter = 0;
                    do
                    {
                        uint32_t spid = (supportedSpidArrIdx * (unsigned)MAX_SPID_ARR_ELEM_SIZE_IN_BIT) + counter;

                        if (MAX_SPID_VALUE < spid)
                        {
                            supportedSpids = supportedSpids >> 1;  // supportedSpids value right shift
                            counter++;
                            continue;
                        }

                        if (supportedSpids & 1 && SPID_0 != spid)  // check first bit in supportedSpids value
                        {
                            MACRO_STAT_PMGAUGE(STAT_UE_NUM_PER_GNB_PLMN_SPID_DU_ID, UeNoAvg_Plmn_SPID_DUID, NULL,
                                (float)pCell->cfg.assignedCellEnDcCallCountPerSPID[plmnIdx][spid], pCell->gnbNum,
                                cellIdentity, uePlmnKey, spid);
                            MACRO_STAT_PMGAUGE(STAT_UE_NUM_PER_GNB_PLMN_SPID_DU_ID, NonDssUeNoAvg_Plmn_SPID_DUID, NULL,
                                (float)pCell->cfg.assignedNonDssEnDcUeCountPerSPID[plmnIdx][spid], pCell->gnbNum,
                                cellIdentity, uePlmnKey, spid);
                        }
                        else if (isSpid0Supported)
                        {
                            // exact spid is not supported so we accumulate separate variable
                            notSupportedSpidUeCnt += pCell->cfg.assignedCellEnDcCallCountPerSPID[plmnIdx][spid];
                            notSupportedNonDssSpidUeCnt += pCell->cfg.assignedNonDssEnDcUeCountPerSPID[plmnIdx][spid];
                        }
                        supportedSpids = supportedSpids >> 1;  // supportedSpids value right shift
                        counter++;                             // shift counting
                    } while (supportedSpids != 0);  // check all bits with value 1
                }

                if (isSpid0Supported)
                {
                    // pegging of spid 0 after other SPID counters finished pegging
                    MACRO_STAT_PMGAUGE(STAT_UE_NUM_PER_GNB_PLMN_SPID_DU_ID, UeNoAvg_Plmn_SPID_DUID, NULL,
                        (float)notSupportedSpidUeCnt, pCell->gnbNum, cellIdentity, uePlmnKey, SPID_0);
                    MACRO_STAT_PMGAUGE(STAT_UE_NUM_PER_GNB_PLMN_SPID_DU_ID, NonDssUeNoAvg_Plmn_SPID_DUID, NULL,
                        (float)notSupportedNonDssSpidUeCnt, pCell->gnbNum, cellIdentity, uePlmnKey, SPID_0);
                }
            }
        }
    }

    if (FOO.VF_BasicOperation_IndexgNBDUId)
    {
        // due to issue with collectin per eNBId for performance or limiting to collection of only cells/eNBs with
        // active calls, this statistic is reverted to collect with dummy eNBId=0 value
        MACRO_STAT_PMGAUGE(STAT_UE_NUM_DU_ID, UeNoAvg_DUID, NULL, (float)pCell->cfg.assignedEnDcCellCallCountForStat,
            pCell->gnbNum, cellIdentity, 0, 0);

        MACRO_STAT_PMGAUGE(STAT_UE_NUM_DU_ID, NonDssUeNoAvg_DUID, NULL, (float)pCell->cfg.assignedNonDssEnDcUeCount,
            pCell->gnbNum, cellIdentity, 0, 0);
    }
    else
    {
        MACRO_STAT_PMGAUGE(STAT_UE_NUM_PER_GNB, UeNoAvg, NULL, (float)pCell->cfg.assignedEnDcCellCallCountForStat,
            pCell->gnbNum, cellIdentity, 0, 0);
        MACRO_STAT_PMGAUGE(STAT_UE_NUM_PER_GNB, NonDssUeNoAvg, NULL, (float)pCell->cfg.assignedNonDssEnDcUeCount,
            pCell->gnbNum, cellIdentity, 0, 0);
    }
}

/**
 *** @brief     VLIB_PeriodicStat_UEUlRohcInfo
 ***/
void VLIB_PeriodicStat_UEUlRohcInfo(VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;
    uint16_t cellIdentity;

    VALID_E_POINT_CHECK_VOID(pCell);
    VCCB_CHECK_E_RANGE_AND_VOID(pCell->gnbNum, MAX_GNB_PER_SYS);

    cellIdentity = pCell->cellIdentity;
    if(IS_SA_CELL_FOR_STAT(pCell))
    {
        MACRO_STAT_PMGAUGE(STAT_UE_NUM_UL_ONLY_ROHC_SA, UlRohcUeNoAvg_Sa, NULL,
            (float)pCell->cfg.assignedULOnlyRoHCCellCallCountSA, pCell->gnbNum, cellIdentity, 0, 0);
    }
    else
    {
        MACRO_STAT_PMGAUGE(STAT_UE_NUM_UL_ONLY_ROHC, UlRohcUeNoAvg, NULL,
            (float)pCell->cfg.assignedULOnlyRoHCCellCallCount, pCell->gnbNum, cellIdentity, 0, 0);

    }
}

/**
 ** @brief     VLIB_PeriodicStat_MdtConfigDelivery
 **/
void VLIB_PeriodicStat_MdtConfigDelivery(VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pCell);
    VCCB_CHECK_E_RANGE_AND_VOID(pCell->gnbNum, MAX_GNB_PER_SYS);
    uint16_t cellIdentity = pCell->cellIdentity;
    uint32_t loggedMdtUeCount = pCell->cfg.assignedLoggedMdtCapableUeCount;

    MACRO_STAT_PMGAUGE(STAT_MDT_CONFIGURATION_DELIVERY_DU_ID, LoggedMDTCapableUeNumAvg, NULL, (float)loggedMdtUeCount,
        pCell->gnbNum, cellIdentity, 0, 0);
}

void FnVCCB_CollectCallUsage()
{
#ifndef __NVGNB__
    AUTO_TRACE_FUNC;
    uint32_t maxVccbCallCount = VCCB_MAX_CALL_COUNT_PER_CPC;
    VccbCfgInfo_type *pCfg = CFG;
    uint32_t currCallCount = pCfg->assignedCallCount;
    float currCallUsage = ((float)currCallCount / (float)maxVccbCallCount) * 100;
    if (e_VCCB_ACPF_VNF == VCOM_getSystemType())
    {
        if (maxVccbCallCount != 0)
        {
            MACRO_STAT_PMGAUGE(STAT_CPC_CALL_USAGE, CallCountAvg, NULL, (float)currCallCount, 0, 0, 0, 0);
            MACRO_STAT_PMGAUGE(STAT_CPC_CALL_USAGE, CallUsageAvg, NULL, currCallUsage, 0, 0, 0, 0);
        }
        else
        {
            VCCB_PRINT_CRITICAL(
                "Collect STAT_CPC_CALL_USAGE is failed!! Invalid VCCB_MAX_CALL_COUNT_PER_CPC(%u)\n", maxVccbCallCount);
        }
    }
    else if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
    {
        if (maxVccbCallCount != 0)
        {
            MACRO_STAT_PMGAUGE(STAT_CP_CALL_USAGE, CP_CallCountAvg, NULL, (float)currCallCount, 0, 0, 0, 0);
            MACRO_STAT_PMGAUGE(STAT_CP_CALL_USAGE, CP_CallUsageAvg, NULL, currCallUsage, 0, 0, 0, 0);
        }
        else
        {
            VCCB_PRINT_CRITICAL(
                "Collect STAT_CP_CALL_USAGE is failed!! Invalid VCCB_MAX_CALL_COUNT_PER_CPC(%u)\n", maxVccbCallCount);
        }
    }
#endif  // __NVGNB__
}

void FnVCCB_ReportCallUsage()
{
#ifndef __NVGNB__
    AUTO_TRACE_FUNC;
    VccbCfgInfo_type *pCfg = CFG;
    uint32_t maxVccbCallCount = VCCB_MAX_CALL_COUNT_PER_CPC;
    if (maxVccbCallCount == 0)
    {
        VCCB_PRINT_CRITICAL(
            "Report CALL_USAGE is failed!! Invalid VCCB_MAX_CALL_COUNT_PER_CPC(%u)\n", maxVccbCallCount);
        return;
    }
    uint32_t currCallCount = pCfg->assignedCallCount;
    float currCallUsage = ((float)currCallCount / (float)maxVccbCallCount) * 100;

    int ret = 0;
#ifdef __VNF__
    ret = PmVNFMPeg_FLT(VNF_CPC_CALL_USAGE, (float)(currCallUsage));
#elif __CNF__
    ret = pmSendUsageValueResponse(STAT_CP_CALL_USAGE, (float)(currCallUsage), CFG->vm.unitId, 0, 0, 0, 0, 0);
#endif
    if (0 != ret)
    {
        VCCB_PRINT_CRITICAL("FnVCCB_ReportCallUsage error(%d) while reporting CALL_USAGE\n", ret);
    }
    if (currCallUsage > (float)70)
    {
        VCCB_PRINTF("Report CALL_USAGE(%f)\n", (double)currCallUsage);
    }
#endif  // __NVGNB__
}

#ifdef HOST_SIM
void FnVCCB_SetgAuditCallCountVmIndex(uint32_t index)
{
    gBTAuditCallCountVmIndex = index % 60;
}
#endif

/**
 * @brief     Collecting statistics periodically
 */
void VLIB_LibStatPeriodicEvent(void)
{
    AUTO_TRACE_FUNC;

    uint16_t i = 0;
    uint16_t cellNum = 0;
    const uint16_t cellsPerSecondDrb =
        MAX_CELL_NUM_VCCB / 60;  // 60 is a period in seconds, after which all cells are reported
    const uint16_t cellsPerSecondUe = MAX_CELL_NUM_VCCB / 10;  // UE period must be an aliquot of the DRB one

    if (gAuditCallCountVmIndex >= 60) gAuditCallCountVmIndex = 0;
#ifdef HOST_SIM
    gAuditCallCountVmIndex = 0;
    if (gBTAuditCallCountVmIndex > 0) gAuditCallCountVmIndex = gBTAuditCallCountVmIndex;
#endif

    bool collect_10s_PeriodForDrbConnPlmnSlice = false;
    if (FOO.VF_DrbConnInfoPlmnSnssaiCounter10SecConfig)
    {
        collect_10s_PeriodForDrbConnPlmnSlice = true;
    }

    // Update local I/F MSG count statistics
    FnVCCB_PeriodicStat_InterfaceMsgCount();

    /*
     * Collect UE_NUM, DRB_NUM every 60 Sec
     * Every second, VCCB collects stats of ( MAX_CELL_NUM_VCCB/60) Cells.
     * ex) When gAuditCallCountVmIndex is ' 0', then VCCB collects stat of Cell( 0/ 60/120/180/.../ 960/1020)
     *     When gAuditCallCountVmIndex is ' 1', then VCCB collects stat of Cell( 1/ 61/121/181/.../ 961/1021)
     *     ...
     *     When gAuditCallCountVmIndex is '59', then VCCB collects stat of Cell(59/119/179/239/.../1019)
     */

    for (i = 0; i <= cellsPerSecondDrb; i++)
    {
        cellNum = (uint16_t)(((unsigned)60 * i) + gAuditCallCountVmIndex);

        if (cellNum >= MAX_CELL_NUM_VCCB) break;
        VccbCellInfo_type *pCell = &CELLINFO[cellNum];

        if (pCell->status != EQUIP) continue;

        VLIB_PeriodicStat_DrbInfo(pCell);
        VLIB_PeriodicStat_ErabInfo(pCell);
        if (FOO.VF_StandAlone_BasicCallOperationForSa)
        {
            /* SA Cell DrbConnInfo(Include RedCap) and NrdcSnTermDrbConnInfo */
            if (collect_10s_PeriodForDrbConnPlmnSlice)
            {
                FnVCCB_PeriodicStat_SaCommonDrbConnInfo(pCell, CollectDrbStatOpt_1min_Period);
            }
            else
            {
                FnVCCB_PeriodicStat_SaCommonDrbConnInfo(pCell, CollectDrbStatOpt_AllDrbConn);
            }

        }

        VLIB_PeriodicStat_UEUlRohcInfo(pCell);
    }

    for (i = 0; i <= cellsPerSecondUe; i++)
    {
        cellNum = (uint16_t)(((unsigned)10 * i) + (gAuditCallCountVmIndex % 10));

        if (cellNum >= MAX_CELL_NUM_VCCB)
        {
            break;
        }

        VccbCellInfo_type *pCell = &CELLINFO[cellNum];

        if (pCell->status != EQUIP)
        {
            continue;
        }

        VCCB_CHECK_E_RANGE_AND_CONTINUE(pCell->gnbNum, MAX_GNB_PER_SYS);

        if ((FOO.VF_StandAlone_BasicCallOperationForSa) && (collect_10s_PeriodForDrbConnPlmnSlice))
        {
            /* SA Cell DrbConnInfo(Include RedCap) */
            FnVCCB_PeriodicStat_SaCommonDrbConnInfo(pCell, CollectDrbStatOpt_10s_Period);
        }

        VLIB_PeriodicStat_UEInfo(pCell);
        VLIB_PeriodicStat_MdtConfigDelivery(pCell);

        //  SA Rrc Conn and RedCap
        if ((FOO.VF_StandAlone_BasicCallOperationForSa)  &&
            (IS_SA_CELL_FOR_STAT(pCell)))
        {
             VLIB_PeriodicStat_RrcConnInfo(pCell);
        }

        // FGR-CC5200:FR760 FR770
        if (FOO.VF_BasicOperationforNRDC_CALL && FOO.VF_NRDC_ConnInfo)
        {
            FnVCCB_PeriodicStat_NrdcConnInfo(pCell);
        }
    }

    if(e_VCCB_ACPF_VNF == VCOM_getSystemType())
    {
        if (gAuditCallCountVmIndex % 10 == 0)  // duration : 10 sec
        {
            FnVCCB_CollectCallUsage();
            FnVCCB_ReportCallUsage();
        }
    }
    else if(e_VCCB_ACPF_CNF == VCOM_getSystemType())
    {
        if (gAuditCallCountVmIndex % 10 == 0)  // duration : 10 sec
        {
            FnVCCB_CollectCallUsage();
        }

        if (gAuditCallCountVmIndex % 60 == 0)
        {
            FnVCCB_ReportCallUsage();
        }
    }

    gAuditCallCountVmIndex++;

#ifdef HOST_SIM
    gBTAuditCallCountVmIndex = 0;
#endif

    return;
}

/**
 * @brief     Calculate ERAB holding time
 * @param     ptCi : call context pointer
 * @param     ptRi : ERAB pointer
 * @param     actFlag : action flag either start or finish
 */
void VLIB_CalculateErabHoldTime(callInfo_type *ptCi, callERABInfo_type *ptRi, uint8_t actFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptRi);

    // ERAB_SPEC_INFO_PER_GNB_DU_ID is supported only for VZW customer
    if (!FOO.VF_VzwOnlyCounterFamily || !FOO.VF_BasicOperation_IndexgNBDUId)
    {
        return;
    }

    Stopwatch_type &stopwatch = ptRi->holdTime;
    if (actFlag == CAL_START)
    {
        ComTimeUtil::stopwatch_start(stopwatch);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_start in %s\n", __func__);
    }
    else
    {
        const struct timespec timeElapsed = ComTimeUtil::stopwatch_get_elapsed_time(stopwatch);
        if (timeElapsed.tv_sec < 0 && timeElapsed.tv_nsec < 0)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "stopwatch_get_elapsed_time ERROR(tv_sec=%ld,tv_nsec=%ld) in %s\n",
                timeElapsed.tv_sec, timeElapsed.tv_nsec, __func__);
            return;
        }

        const float timeElapsedInSecond = ComTimeUtil::getTimeSecondInFloat(timeElapsed);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_get_elapsed_time(timeElapsed:%f sec) in %s\n", (double)timeElapsedInSecond, __func__);

        if (actFlag == CAL_STOP)
        {
            MACRO_STAT_PMSI_QCI(STAT_ERAB_SPEC_INFO_PER_GNB_DU_ID, ErabSpecInfo_HoldingTimeTot_cell_DUID, ptCi, ptRi,
                timeElapsedInSecond, USE_NEW_QCI, 0, 0);
        }
        else if (actFlag == CAL_MOD)
        {
            MACRO_STAT_PMSI_QCI(STAT_ERAB_SPEC_INFO_PER_GNB_DU_ID, ErabSpecInfo_HoldingTimeTot_cell_DUID, ptCi, ptRi,
                timeElapsedInSecond, USE_OLD_QCI, 0, 0);
        }
    }
}

void VLIB_CollectAdditionalStatistic_FLOAT(int mFamily, int mActualFamily, int mType, callInfo_type *ptCi,
    float updateValue, int reserved3, int reserved4, int reserved5, int reserved6)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    UNUSED2(mActualFamily, reserved3);

    switch (mFamily)
    {
        case STAT_RRC_TIME_PER_GNB_DU_ID:
            if (FOO.VF_VzwOnlyCounterFamily)
            {
                uint16_t SPID = SPID_0;
                const bool isSpidStatConfigured = FnVCCB_setSpidCounterIndex(ptCi, SPID);
                if (isSpidStatConfigured)
                {
                    MACRO_STAT_PMCC_FLOAT(STAT_RRC_TIME_PER_GNB_SPID_DU_ID, mType, ptCi, updateValue, SPID, reserved4,
                        reserved5, reserved6);
                }
            }
            break;

        default:
            return;
    }
}

/**
 * @brief     Calculate call holding time
 * @param     ptCi : call context pointer
 * @param     actFlag : action flag either start or finish
 * @return    void
 */
void VLIB_CalculateEndcRrcConnHoldingTime(callInfo_type *ptCi, uint8_t actFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->myThreadId, VCCB_CALL_THREAD_NUM);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    // RRC_TIME_PER_GNB_DU_ID is supported only for VZW customer
    if (!FOO.VF_VzwOnlyCounterFamily || !FOO.VF_BasicOperation_IndexgNBDUId)
    {
        return;
    }

    Stopwatch_type &stopwatch = ptCi->rrcConnStat.rrcEndcConnHoldingTime;

    if (actFlag == CAL_START)
    {
        ComTimeUtil::stopwatch_start(stopwatch);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_start in %s\n", __func__);
    }
    else
    {
        const struct timespec timeElapsed = ComTimeUtil::stopwatch_stop(stopwatch);
        if (timeElapsed.tv_sec < 0 && timeElapsed.tv_nsec < 0)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "stopwatch_stop ERROR in %s\n", __func__);
            return;
        }

        const float timeElapsedInSecond = ComTimeUtil::getTimeSecondInFloat(timeElapsed);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_stop(timeElapsed:%f sec) in %s\n", (double)timeElapsedInSecond, __func__);

        MACRO_STAT_PMCC_FLOAT(STAT_RRC_TIME_PER_GNB_DU_ID, ReleaseCallHoldingTimeTot, ptCi, timeElapsedInSecond, 0, 0, 0, 0);
        MACRO_STAT_PMCC_FLOAT(STAT_RRC_TIME_PER_GNB_DU_ID, ReleaseCallHoldingTimeCnt, ptCi, (float)1.0, 0, 0, 0, 0);

        const uint32_t durationInMilliSecond = (uint32_t)ComTimeUtil::getTimeMilliSecondInFloat(timeElapsed);  // unit:ms
        VccbLocalStatDuration_type *rRCHoldingDuration = &VCCB_STAT->localStat.rRCHoldingDuration[ptCi->myThreadId];
        rRCHoldingDuration->eventCount++;
        rRCHoldingDuration->recentDuration = durationInMilliSecond;
        rRCHoldingDuration->totalDuration += durationInMilliSecond;
        if (durationInMilliSecond > rRCHoldingDuration->maxDuration)
        {
            rRCHoldingDuration->maxDuration = durationInMilliSecond;
        }
        if (durationInMilliSecond < rRCHoldingDuration->minDuration)
        {
            rRCHoldingDuration->minDuration = durationInMilliSecond;
        }
    }
    return;
}

/**
 * @brief     Calculate SgNB Addition Procedure time (X2 SgNB Addition Request - X2 SgNB Reconfiguration Complete)
 * @param     ptCi : call context pointer
 * @param     actFlag : action flag either start or finish
 * @return    void
 */
void VLIB_CalculateAddProcTime(callInfo_type *ptCi, uint8_t actFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    // SGNB_PROC_TIME_PER_GNB_DU_ID is supported only for VZW customer
    if (!FOO.VF_VzwOnlyCounterFamily || !FOO.VF_BasicOperation_IndexgNBDUId)
    {
        return;
    }

    Stopwatch_type &stopwatch = ptCi->rrcConnStat.addProcTime;

    if (actFlag == CAL_START)
    {
        ComTimeUtil::stopwatch_start(stopwatch);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_start in %s\n", __func__);
    }
    else
    {
        const struct timespec timeElapsed = ComTimeUtil::stopwatch_stop(stopwatch);
        if (timeElapsed.tv_sec < 0 && timeElapsed.tv_nsec < 0)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "stopwatch_stop ERROR in %s\n", __func__);
            return;
        }

        const float timeElapsedInMilliSecond = ComTimeUtil::getTimeMilliSecondInFloat(timeElapsed);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_stop(timeElapsed:%f sec) in %s\n", (double)timeElapsedInMilliSecond, __func__);

        VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
        VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];
        MACRO_STAT_PMGAUGE(STAT_SGNB_PROC_TIME_PER_GNB_DU_ID, AddProcTimeAvg, ptCi, timeElapsedInMilliSecond, ptCi->gnbNum,
            pCell->cellIdentity, 0, 0);
    }

    return;
}

/**
 * @brief     Calculate SpCell Change Time in case of using RRC Reconfiguration via SRB3.
 * @param     ptCi : call context pointer
 * @param     actFlag : action flag either start or stop
 * @return    void
 */
void VLIB_CalculateSpCellChgTime(callInfo_type *ptCi, uint8_t actFlag, spCellChg_type spCellChgType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    Stopwatch_type &stopwatch = ptCi->hoInfo.rrcSpCellChgTime;

    if (actFlag == CAL_START)
    {
        ComTimeUtil::stopwatch_start(stopwatch);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_start in %s\n", __func__);
    }
    else
    {
        const struct timespec timeElapsed = ComTimeUtil::stopwatch_stop(stopwatch);
        if (timeElapsed.tv_sec < 0 && timeElapsed.tv_nsec < 0)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "stopwatch_stop ERROR in %s\n", __func__);
            return;
        }

        const float timeElapsedInSecond = ComTimeUtil::getTimeSecondInFloat(timeElapsed);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_stop(timeElapsed:%f) in %s\n", (double)timeElapsedInSecond, __func__);

        switch (spCellChgType)
        {
            case SpCellChg_ThroughSRB3:
                MACRO_STAT_PMCC_FLOAT(STAT_SPCELL_CHG_TIME_VIA_SRB3, EndcRRCTimeSRB3Tot, ptCi, timeElapsedInSecond, 0, 0, 0, 0);
                MACRO_STAT_PMCC_FLOAT(STAT_SPCELL_CHG_TIME_VIA_SRB3, EndcRRCTimeSRB3Cnt, ptCi, 1.0f, 0, 0, 0, 0);
                MACRO_STAT_PMCC_FLOAT(STAT_SPCELL_CHG_TIME, IntraSNSPcellChgSRB3Tot, ptCi, timeElapsedInSecond, 0, 0, 0, 0);
                MACRO_STAT_PMCC_FLOAT(STAT_SPCELL_CHG_TIME, IntraSNSPcellChgSRB3Cnt, ptCi, 1.0f, 0, 0, 0, 0);
                break;

            case SpCellChg_ThroughMCBSRB:
                MACRO_STAT_PMCC_FLOAT(STAT_SPCELL_CHG_TIME, IntraSNSPcellChgMCGSRBTot, ptCi, timeElapsedInSecond, 0, 0, 0, 0);
                MACRO_STAT_PMCC_FLOAT(STAT_SPCELL_CHG_TIME, IntraSNSPcellChgMCGSRBCnt, ptCi, 1.0f, 0, 0, 0, 0);
                break;

            case SpCellChg_SnChange:
                MACRO_STAT_PMCC_FLOAT(STAT_SPCELL_CHG_TIME, InterSNSPcellChgTot, ptCi, timeElapsedInSecond, 0, 0, 0, 0);
                MACRO_STAT_PMCC_FLOAT(STAT_SPCELL_CHG_TIME, InterSNSPcellChgCnt, ptCi, 1.0f, 0, 0, 0, 0);
                break;

            default:
                break;
        }
    }

    return;
}

/**
 * @brief     Calculate RRC Connection Establishment Procedure time (RRC Setup Request - RRC Setup Complete)
 * @param     ptCi : call context pointer
 * @param     actFlag : action flag either start or finish
 * @return    void
 **/
void VLIB_CalculateRrcConnEstabProcTime(callInfo_type *ptCi, uint8_t actFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    if (ptCi->bitFlag.isRrcSetupReqWithRrcSetupComplete)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "RrcSetup Time is Skipped by isRrcSetupReqWithRrcSetupComplete\n");
        return;
    }

    Stopwatch_type &stopwatch = ptCi->rrcConnStat.rrcEstabProcTime;

    if (actFlag == CAL_START)
    {
        ComTimeUtil::stopwatch_start(stopwatch);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_start in %s\n", __func__);
    }
    else
    {
        const struct timespec timeElapsed = ComTimeUtil::stopwatch_stop(stopwatch);
        if (timeElapsed.tv_sec < 0 && timeElapsed.tv_nsec < 0)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "stopwatch_stop ERROR in %s\n", __func__);
            return;
        }

        const float timeElapsedInMilliSecond = ComTimeUtil::getTimeMilliSecondInFloat(timeElapsed);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_stop(timeElapsed:%f) in %s\n", (double)timeElapsedInMilliSecond, __func__);

        VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
        const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
        MACRO_STAT_PMGAUGE(STAT_RRC_SETUP_TIME, ConnEstabTimeAvg, ptCi, timeElapsedInMilliSecond, ptCi->gnbNum, pCell->cellIdentity,
            ptCi->ueInfo.establishmentCause, 0);

        FnVCCB_CollectStatCSL_RrcSetupTime(ptCi, timeElapsedInMilliSecond);

        VccbLocalStatDuration_type *rRCSetupDuration = &VCCB_STAT->localStat.rRCSetupDuration[ptCi->myThreadId];
        rRCSetupDuration->eventCount++;
        rRCSetupDuration->recentDuration = (uint32_t)timeElapsedInMilliSecond;
        rRCSetupDuration->totalDuration += (uint32_t)timeElapsedInMilliSecond;
        if (timeElapsedInMilliSecond > (float)rRCSetupDuration->maxDuration)
        {
            rRCSetupDuration->maxDuration = (uint32_t)timeElapsedInMilliSecond;
        }
        if (timeElapsedInMilliSecond < (float)rRCSetupDuration->minDuration)
        {
            rRCSetupDuration->minDuration = (uint32_t)timeElapsedInMilliSecond;
        }
    }

    return;
}

/**
 * @brief     Calculate NG Connection Establishment Procedure time (NG Initial UE Message - NG NAS Message)
 * @param     ptCi : call context pointer
 * @param     actFlag : action flag either start or finish
 * @return    void
 **/
void VLIB_CalculateNgConnEstabProcTime(callInfo_type *ptCi, uint8_t actFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    Stopwatch_type &stopwatch = ptCi->rrcConnStat.ngEstabProcTime;

    if (actFlag == CAL_START)
    {
        ComTimeUtil::stopwatch_start(stopwatch);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_start in %s\n", __func__);
    }
    else
    {
        const struct timespec timeElapsed = ComTimeUtil::stopwatch_stop(stopwatch);
        if (timeElapsed.tv_sec < 0 && timeElapsed.tv_nsec < 0)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "stopwatch_stop ERROR in %s\n", __func__);
            return;
        }

        const float timeElapsedInMilliSecond = ComTimeUtil::getTimeMilliSecondInFloat(timeElapsed);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_stop(timeElapsed:%f) in %s\n", (double)timeElapsedInMilliSecond, __func__);

        VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
        const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
        MACRO_STAT_PMGAUGE(STAT_NG_SETUP_TIME, NgConnEstabTimeAvg, ptCi, timeElapsedInMilliSecond, ptCi->gnbNum, pCell->cellIdentity,
            ptCi->ueInfo.establishmentCause, 0);
    }

    return;
}

void ComLibStatistic::calculateRRCHoldingTime(callInfo_type &call, const enumRRCState_type rRCState)
{
    switch (rRCState)
    {
        case RRC_CONNECTED:
            if (call.rrcConnStat.rrcConnInactHoldingTime.isRunning == false)
            {
                VLIB_CalculateRrcConnInactHoldingTime(&call, CAL_START);
            }
            if (call.rrcConnStat.rrcConnHoldingTime.isRunning == false)
            {
                VLIB_CalculateRrcConnHoldingTime(&call, CAL_START);
            }
            if (call.rrcConnStat.rrcInactHoldingTime.isRunning == true)
            {
                VLIB_CalculateRrcInactHoldingTime(&call, CAL_STOP);
            }
            break;
        case RRC_INACTIVE:
            if (call.rrcConnStat.rrcConnInactHoldingTime.isRunning == false)
            {
                VLIB_CalculateRrcConnInactHoldingTime(&call, CAL_START);
            }
            if (call.rrcConnStat.rrcConnHoldingTime.isRunning == true)
            {
                VLIB_CalculateRrcConnHoldingTime(&call, CAL_STOP);
            }
            if (call.rrcConnStat.rrcInactHoldingTime.isRunning == false)
            {
                VLIB_CalculateRrcInactHoldingTime(&call, CAL_START);
            }
            break;
        case RRC_IDLE:
            if (call.rrcConnStat.rrcConnInactHoldingTime.isRunning == true)
            {
                VLIB_CalculateRrcConnInactHoldingTime(&call, CAL_STOP);
            }
            if (call.rrcConnStat.rrcConnHoldingTime.isRunning == true)
            {
                VLIB_CalculateRrcConnHoldingTime(&call, CAL_STOP);
            }
            if (call.rrcConnStat.rrcInactHoldingTime.isRunning == true)
            {
                VLIB_CalculateRrcInactHoldingTime(&call, CAL_STOP);
            }
            break;
        default:
            VCCB_PRINT_CALL_ERROR(&call, "Invalid rRCState(%u) in %s\n", rRCState, __func__);
            break;
    }
}

/**
 * @brief     Calculate RRC Call Holding Time (Received RRCReconfigurationComplete ~ RRC Connection released)
 * @param     ptCi : call context pointer
 * @param     actFlag : action flag either start or stop
 * @return    void
 */
void VLIB_CalculateRrcConnInactHoldingTime(callInfo_type *ptCi, uint8_t actFlag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->myThreadId, VCCB_CALL_THREAD_NUM);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    if ((ptCi->callType != E_CALLTYPE_SA) || IS_NRDC_SN(ptCi))
    {
        return;
    }

    Stopwatch_type &stopwatch = ptCi->rrcConnStat.rrcConnInactHoldingTime;

    if (actFlag == CAL_START)
    {
        ComTimeUtil::stopwatch_start(stopwatch);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_start in %s\n", __func__);
    }
    else
    {
        const struct timespec timeElapsed = ComTimeUtil::stopwatch_stop(stopwatch);
        if (timeElapsed.tv_sec < 0 && timeElapsed.tv_nsec < 0)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "stopwatch_stop ERROR in %s\n", __func__);
            return;
        }

        const float timeElapsedInSecond = ComTimeUtil::getTimeSecondInFloat(timeElapsed);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_stop(timeElapsed:%f) in %s\n", (double)timeElapsedInSecond, __func__);

        if (IS_REDCAP_UE(ptCi))
        {
            int redCapFamily = STAT_RRC_CONN_INFO_REDCAP_PLMN;

            if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
                redCapFamily = STAT_CP_RRC_CONN_INFO_REDCAP_PLMN;

            MACRO_STAT_PMSI(redCapFamily, ConnInactCallHoldingTimeAvg, ptCi, timeElapsedInSecond, 0, 0, 0, 0);
        }
        else
        {
            MACRO_STAT_PMSI(STAT_RRC_CONN_INFO, ConnInactCallHoldingTimeAvg, ptCi, timeElapsedInSecond, 0, 0, 0, 0);
            if (FOO.VF_MultipleOperatorCNSupport)
            {
                MACRO_STAT_PMSI(STAT_RRC_CONN_INFO_PLMN, ConnInactCallHoldingTimeAvgPlmn, ptCi, timeElapsedInSecond, 0, 0, 0, 0);
            }
        }

        if (FOO.VF_ServedUEConnectionStatus_InclRFSP)
        {
            // Peg statistics only when rfsp yang is set. (rfsp-based-counter-control-entries/rfsp)
            FnVCCB_CollectRfspBasedHoldingTime(
                ptCi, STAT_RRC_CONN_INFO_DU_ID_PLMN_RFSP, ConnInactCallHoldingTimeAvgPlmn, timeElapsedInSecond);
        }

        uint32_t durationInMilliSecond = (uint32_t)ComTimeUtil::getTimeMilliSecondInFloat(timeElapsed);  // unit:ms
        VccbLocalStatDuration_type *rRCHoldingDuration = &VCCB_STAT->localStat.rRCHoldingDuration[ptCi->myThreadId];
        rRCHoldingDuration->eventCount++;
        rRCHoldingDuration->recentDuration = durationInMilliSecond;
        rRCHoldingDuration->totalDuration += durationInMilliSecond;
        if (durationInMilliSecond > rRCHoldingDuration->maxDuration)
        {
            rRCHoldingDuration->maxDuration = durationInMilliSecond;
        }
        if (durationInMilliSecond < rRCHoldingDuration->minDuration)
        {
            rRCHoldingDuration->minDuration = durationInMilliSecond;
        }
    }

    return;
}

void VLIB_CalculateRrcInactHoldingTime(callInfo_type *ptCi, uint8_t actFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    Stopwatch_type &stopwatch = ptCi->rrcConnStat.rrcInactHoldingTime;

    if (actFlag == CAL_START)
    {
        ComTimeUtil::stopwatch_start(stopwatch);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_start in %s\n", __func__);
    }
    else
    {
        const struct timespec timeElapsed = ComTimeUtil::stopwatch_stop(stopwatch);
        if (timeElapsed.tv_sec < 0 && timeElapsed.tv_nsec < 0)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "stopwatch_stop ERROR in %s\n", __func__);
            return;
        }

        const float timeElapsedInSecond = ComTimeUtil::getTimeSecondInFloat(timeElapsed);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_stop(timeElapsed:%f) in %s\n", (double)timeElapsedInSecond, __func__);

        if (IS_REDCAP_UE(ptCi))
        {
            int redCapFamily = STAT_RRC_CONN_INFO_REDCAP_PLMN;

            if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
                redCapFamily = STAT_CP_RRC_CONN_INFO_REDCAP_PLMN;

            MACRO_STAT_PMSI(redCapFamily, InactCallHoldingTimeAvg, ptCi, timeElapsedInSecond, 0, 0, 0, 0);
        }
        else
        {
            MACRO_STAT_PMSI(STAT_RRC_CONN_INFO, InactCallHoldingTimeAvg, ptCi, timeElapsedInSecond, 0, 0, 0, 0);

            if (FOO.VF_MultipleOperatorCNSupport)
            {
                MACRO_STAT_PMSI(STAT_RRC_CONN_INFO_PLMN, InactCallHoldingTimeAvgPlmn, ptCi, timeElapsedInSecond, 0, 0, 0, 0);
            }
        }

        if (FOO.VF_ServedUEConnectionStatus_InclRFSP)
        {
            // Peg statistics only when rfsp yang is set. (rfsp-based-counter-control-entries/rfsp)
            FnVCCB_CollectRfspBasedHoldingTime(
                ptCi, STAT_RRC_CONN_INFO_DU_ID_PLMN_RFSP, InactCallHoldingTimeAvgPlmn, timeElapsedInSecond);
        }
    }
    return;
}

void VLIB_CalculateRrcConnHoldingTime(callInfo_type *ptCi, uint8_t actFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if ((ptCi->callType != E_CALLTYPE_SA) || IS_NRDC_SN(ptCi))
    {
        return;
    }

    Stopwatch_type &stopwatch = ptCi->rrcConnStat.rrcConnHoldingTime;

    if (actFlag == CAL_START)
    {
        ComTimeUtil::stopwatch_start(stopwatch);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_start in %s\n", __func__);
    }
    else
    {
        const struct timespec timeElapsed = ComTimeUtil::stopwatch_stop(stopwatch);
        if (timeElapsed.tv_sec < 0 && timeElapsed.tv_nsec < 0)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "stopwatch_stop ERROR in %s\n", __func__);
            return;
        }

        const float timeElapsedInSecond = ComTimeUtil::getTimeSecondInFloat(timeElapsed);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_stop(timeElapsed:%f) in %s\n", (double)timeElapsedInSecond, __func__);

        if (IS_REDCAP_UE(ptCi))
        {
            int redCapFamily = STAT_RRC_CONN_INFO_REDCAP_PLMN;

            if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
                redCapFamily = STAT_CP_RRC_CONN_INFO_REDCAP_PLMN;

            MACRO_STAT_PMSI(redCapFamily, CallHoldingTimeAvg, ptCi, timeElapsedInSecond, 0, 0, 0, 0);
        }
        else
        {
            MACRO_STAT_PMSI(STAT_RRC_CONN_INFO, CallHoldingTimeAvg, ptCi, timeElapsedInSecond, 0, 0, 0, 0);

            if (TRUE == ptCi->bitFlag.pc1Capable)
            {
                MACRO_STAT_PMSI(
                    STAT_RRC_CONN_INFO_PC1_DU_ID, CallHoldingTimeAvg_PC1_DUID, ptCi, timeElapsedInSecond, 0, 0, 0, 0);
            }
            else if (TRUE == ptCi->bitFlag.pc15Capable)
            {
                MACRO_STAT_PMSI(
                    STAT_RRC_CONN_INFO_PC15_DU_ID, CallHoldingTimeAvg_PC15_DUID, ptCi, timeElapsedInSecond, 0, 0, 0, 0);
            }
            else if (TRUE == ptCi->bitFlag.pc2Capable)
            {
                MACRO_STAT_PMSI(
                    STAT_RRC_CONN_INFO_PC2_DU_ID, CallHoldingTimeAvg_PC2_DUID, ptCi, timeElapsedInSecond, 0, 0, 0, 0);
            }

            if (FOO.VF_MultipleOperatorCNSupport)
            {
                MACRO_STAT_PMSI(STAT_RRC_CONN_INFO_PLMN, CallHoldingTimeAvgPlmn, ptCi, timeElapsedInSecond, 0, 0, 0, 0);
            }
        }

        if (FOO.VF_ServedUEConnectionStatus_InclRFSP)
        {
            // Peg statistics only when rfsp yang is set. (rfsp-based-counter-control-entries/rfsp)
            FnVCCB_CollectRfspBasedHoldingTime(
                ptCi, STAT_RRC_CONN_INFO_DU_ID_PLMN_RFSP, CallHoldingTimeAvgPlmn, timeElapsedInSecond);
        }
    }
    return;
}

/**
 * @brief           Prepare Attempt/Success QCI structure for pegging
 * @param[in/out]   ptCi : call context pointer / callInfo_type
 * @param[in]       mType : stat type / int
 * @return          void
 */
void VLIB_PrepareQciAttemptSuccess(callInfo_type *ptCi, int mType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    if ((FALSE == FOO.VF_BasicOperationforENDC_NsaCslQciReporting) || (ErabAddAtt != mType))
    {
        return;
    }

    // Algorithm consists of following steps:
    // Step 1. Retrieve all newly added bearers' QCI values. Sort them by importance, where a lower QCI value indicates
    // higher priority.
    // Step 2. Prepare a temporary buffer to store the pegged QCI values. Iterate through the added QCI values:
    //  - If the QCI does not exist in QciHistory, add it to the temporary buffer in the first slot.
    //  - If the QCI already exists in QciHistory, move its qci and counters from QciHistory to the temporary buffer in
    //  the first slot.
    //  - Clear the QCI entry in QciHistory after processing.
    // Step 3. If fewer than four QCI values were added, fill the remaining slots in the temporary buffer with entries
    // from QciHistory.
    // Step 4. Enter all of data from tempQciHistory into QciHistory.

    callInfo_s::QciCount_s::QciAttemptSuccessData_s tempQciHistory[MAX_QCI_HISTORY_STORING_CAPACITY];
    uint8_t qciCount = 0, index = MAX_QCI_HISTORY_STORING_CAPACITY;
    auto QciHistory = ptCi->qciCount.QciAttemptSuccessData;
    for (uint8_t loop = 0; loop < MAX_QCI_HISTORY_STORING_CAPACITY; loop++)
    {
        tempQciHistory[loop] = {MAX_QCI_VALUE, 0, 0};
    }

    // Step 1.
    std::set<uint16_t> QCIsToPegg;
    for (uint8_t loop = 0; loop < MAX_ERAB_PER_CALL; loop++)
    {
        if (ptCi->erabInfo[loop].usage != CI_use) continue;
        if ((ERAB_Setup == ptCi->erabInfo[loop].erabStatus) ||
            ((ERAB_Modify == ptCi->erabInfo[loop].erabStatus) && (ERAB_Setup == ptCi->erabInfo[loop].prevErabStatus)))
        {
            QCIsToPegg.insert(ptCi->erabInfo[loop].erabQos.qciValue.QCI);
        }
    }

    // Step 2.
    for (const auto &QCI : QCIsToPegg)
    {
        if (MAX_QCI_HISTORY_STORING_CAPACITY == qciCount) break;
        index = MAX_QCI_HISTORY_STORING_CAPACITY;
        for (uint8_t loop = 0; loop < MAX_QCI_HISTORY_STORING_CAPACITY; loop++)
        {
            if (QCI == QciHistory[loop].qci)
            {
                index = loop;
            }
        }
        // QCI not present in current structure
        if (MAX_QCI_HISTORY_STORING_CAPACITY <= index)
        {
            tempQciHistory[qciCount] = {QCI, 0, 0};
        }
        // QCI present in current structure
        else if (MAX_QCI_HISTORY_STORING_CAPACITY > index)
        {
            tempQciHistory[qciCount] = {QCI, QciHistory[index].attempt, QciHistory[index].success};
            QciHistory[index] = {MAX_QCI_VALUE, 0, 0};
        }
        qciCount++;
    }

    // Step 3.
    for (uint8_t loop = 0; loop < MAX_QCI_HISTORY_STORING_CAPACITY; loop++)
    {
        if (MAX_QCI_HISTORY_STORING_CAPACITY <= qciCount) break;
        if (QciHistory[loop].qci == MAX_QCI_VALUE) continue;
        tempQciHistory[qciCount] = QciHistory[loop];
        qciCount++;
    }

    // Step 4.
    for (uint8_t loop = 0; loop < MAX_QCI_HISTORY_STORING_CAPACITY; loop++)
    {
        QciHistory[loop] = tempQciHistory[loop];
    }
}

/**
 * @brief           Function that provides pegging operation of Attempt/Success QCI data to later store it
 * @param[in/out]   ptCi : call context pointer / callInfo_type
 * @param[in]       QCI : QCI value / uint16_t
 * @param[in]       mType : stat type / int
 * @return          void
 */
void VLIB_PeggQciAttemptSuccess(callInfo_type *ptCi, uint16_t QCI, int mType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    if (FALSE == FOO.VF_BasicOperationforENDC_NsaCslQciReporting)
    {
        return;
    }
    auto QciHistory = ptCi->qciCount.QciAttemptSuccessData;
    for (uint8_t loop = 0; loop < MAX_QCI_HISTORY_STORING_CAPACITY; loop++)
    {
        if (QCI == QciHistory[loop].qci)
        {
            auto QciIter = &QciHistory[loop];
            if (ErabAddAtt == mType)
            {
                QciIter->attempt =
                    (__UINT8_MAX__ <= QciIter->attempt) ? __UINT8_MAX__ : static_cast<uint8_t>(QciIter->attempt + 1);
            }
            else if (ErabAddSucc == mType)
            {
                QciIter->success =
                    (__UINT8_MAX__ <= QciIter->success) ? __UINT8_MAX__ : static_cast<uint8_t>(QciIter->success + 1);
            }
        }
    }

    VCCB_PRINT_LOG_NSA_CSL_ACCESSIBILITY(ptCi);
}

/**
 * @brief           Function that provides pegging operation of counters with InSessionStatus index.
 * @param[in]       mFamily Family ID of the statistic counter / int
 * @param[in]       mType : stat type / int
 * @param[in/out]   ptCi : call context pointer / callInfo_type
 * @param[in]       reserved2..6 : reserved indexes / int
 * @return          void
 */
void VLIB_PeggInSessionStatusFamilies(int mFamily, int mType, callInfo_type *ptCi, unsigned int reserved2,
    unsigned int reserved3, int reserved4, int reserved5, int reserved6)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    for (const callERABInfo_type &erabInfo : ptCi->erabInfo)
    {
        if (erabInfo.usage != CI_use) continue;

        if (GET_DRB_RELEASED_IN_SESSION_FLAG(erabInfo.flag.setupFlag))
        {
            MACRO_STAT_PMCC(mFamily, mType, ptCi, reserved2, reserved3, reserved4, reserved5, reserved6);
            break;
        }
    }
}

/**
 * @brief           Function that provides pegging operation of context release counters for operators supporting MORAN.
 * @param[in/out]   ptCi : call context pointer / callInfo_type
 * @param[in]       mType : stat type / int
 * @param[in]       SPID : stat index / uint
 * @param[in]       reserved3..6 : reserved indexes / int
 * @return          void
 */
void VLIB_PeggEndcCtxRelAllPerGnbGlobalIdPlmnSpid(callInfo_type *ptCi, int mType, unsigned int SPID,
    unsigned int reserved3, int reserved4, int reserved5, int reserved6)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    if (FALSE == FOO.VF_SPIDBasedStatistics_ENDC || TRUE == FOO.VF_VzwOnlyCounterFamily)
    {
        return;
    }

    MACRO_STAT_PMCC(STAT_ENDC_CTX_REL_ALL_PER_GNB_GLOBAL_ID_PLMN_SPID, mType, ptCi, SPID, reserved3, reserved4,
        reserved5, reserved6);
    VLIB_PeggInSessionStatusFamilies(STAT_ENDC_CTX_REL_ALL_PER_GNB_GLOBAL_ID_PLMN_SPID_ACT, mType, ptCi, SPID,
        reserved3, reserved4, reserved5, reserved6);
}

/**
 * @brief     Collect statistics for answer
 * @param     ptCi : call context pointer
 * @param     ptRi : ERAB pointer
 */
void VLIB_CallStatProcessAnswer(callInfo_type *ptCi, callERABInfo_type *ptRi)
{
    AUTO_TRACE_FUNC;

    // ERAB_SPEC_INFO_PER_GNB_DU_ID is supported only for VZW customer
    if (!FOO.VF_VzwOnlyCounterFamily || !FOO.VF_BasicOperation_IndexgNBDUId)
    {
        return;
    }

    if (ptCi == NULL)
    {
        VCCB_PRINT_CRITICAL("ptCi(=NULL) in VLIB_CallStatProcessAnswer\n");

        return;
    }

    // Performance Simulator
    if (ptCi->simCallFlag)
    {
        return;
    }

    if (ptRi == NULL)
    {
        VCCB_PRINT_CRITICAL("ptRi(=NULL) in VLIB_CallStatProcessAnswer\n");

        return;
    }

    if (!IS_VALID_NODE(ERAB_NODE, ptCi, ptRi))
    {
        return;
    }

    // ERAB Holding Time
    VLIB_CalculateErabHoldTime(ptCi, ptRi, CAL_START);
}

/**
 * @brief This function checks whether to store the failure cause history for the given family and type.
 *
 * @param ptCi Pointer to call information structure.
 * @param mFamily Family ID of the statistic counter.
 * @param mType Type ID of the statistic counter.
 * @return int True if the failure cause history should be stored, false otherwise.
 */
int FnVCCB_CheckIfFailureCauseHistoryShouldBeStored(callInfo_type *ptCi, int mFamily, int mType)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, FALSE);

    int lastSuccessType = 0xFFFF;
    int lastFailureType = 0xFFFF;
    int storeHist = FALSE;

    switch (mFamily)
    {
        case STAT_SGNB_ADD_PER_GNB:
            lastSuccessType = EndcAddSucc;
            lastFailureType = EndcAddFail_DuFail;
            break;

        case STAT_SGNB_ADD_PER_GNB_PER_DU:
            lastSuccessType = EndcAddSucc_DU_cell;
            lastFailureType = EndcAddFail_DuFail_DU_cell;
            break;

        case STAT_MENB_INIT_SGNB_MOD_PER_GNB:
            lastSuccessType = EndcModByMenbSucc;
            lastFailureType = EndcModByMenbFail_DuTimeout;
            break;

        case STAT_SGNB_INIT_SGNB_MOD_PER_GNB:
            lastSuccessType = EndcModBySgnbSucc;
            lastFailureType = EndcModBySgnbFail_DuFail;
            break;

        case STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB:
            lastSuccessType = EndcModByMenbMcgMobSucc;
            lastFailureType = EndcModByMenbMcgMobFail_DuFail;
            break;

        case STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG:
            lastSuccessType = EndcAddLteHoNoSgnbChgSucc;
            lastFailureType = EndcAddLteHoNoSgnbChgFail_DuFail;
            break;

        case STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG_GLOBAL_ID_SPID:
            lastSuccessType = EndcAddLteHoNoSgnbChgSucc_SPID;
            lastFailureType = EndcAddLteHoNoSgnbChgFail_DuFail_SPID;
            break;

        case STAT_SGNB_ADD_SGNB_CHG:
            lastSuccessType = EndcAddSgnbChgSucc;
            lastFailureType = EndcAddSgnbChgFail_DuFail;
            break;

        case STAT_SGNB_ADD_SGNB_CHG_GLOBAL_ID_SPID:
            lastSuccessType = EndcAddSgnbChgSucc_SPID;
            lastFailureType = EndcAddSgnbChgFail_DuFail_SPID;
            break;

        case STAT_SGNB_ADD_MNHO_INTRA_ENB:
            lastSuccessType = EndcAddMnHoIntraEnbSucc;
            lastFailureType = EndcAddMnHoIntraEnbFail_DuFail;
            break;

        case STAT_SGNB_ADD_MNHO_INTRA_ENB_GLOBAL_ID_SPID:
            lastSuccessType = EndcAddMnHoIntraEnbSucc_SPID;
            lastFailureType = EndcAddMnHoIntraEnbFail_DuFail_SPID;
            break;

        case STAT_SGNB_ADD_MNHO_INTER_ENB:
            lastSuccessType = EndcAddMnHoInterEnbHoSucc;
            lastFailureType = EndcAddMnHoInterEnbFail_DuFail;
            break;

        case STAT_SGNB_ADD_MNHO_INTER_ENB_GLOBAL_ID_SPID:
            lastSuccessType = EndcAddMnHoInterEnbHoSucc_SPID;
            lastFailureType = EndcAddMnHoInterEnbFail_DuFail_SPID;
            break;

        case STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB:
            lastSuccessType = EndcIntraChgSucc;
            lastFailureType = EndcIntraChgFail_DuFail;
            break;

        case STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB_DU_ID_CELL_SPID:
            lastSuccessType = EndcIntraChgSucc_DUID_SPID;
            lastFailureType = EndcIntraChgFail_DuFail_DUID_SPID;
            break;

        case STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB:
            lastSuccessType = EndcInterChgSrcSucc;
            lastFailureType = EndcInterChgSrcFail_DuFail;
            break;

        case STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB_DU_ID_CELL_SPID:
            lastSuccessType = EndcInterChgSrcSucc_DUID_SPID;
            lastFailureType = EndcInterChgSrcFail_DuFail_DUID_SPID;
            break;

        case STAT_ERAB_ADD_PER_GNB:
            lastSuccessType = ErabAddSucc;
            lastFailureType = ErabAddFail_DuFail;
            break;

        case STAT_ERAB_MOD_PER_GNB:
            lastSuccessType = ErabModSucc;
            lastFailureType = ErabModFail_DuFail;
            break;

        case STAT_DRB_SETUP:
            lastSuccessType = DrbSetupSucc;
            lastFailureType = DrbSetupFail_NgFail;
            break;

        case STAT_DRB_RELEASE_AND_ERASE:
            lastSuccessType = DrbRelSucc;
            lastFailureType = DrbRelFail_NgFail;
            break;

        case STAT_QOS_FLOW_SETUP:
            lastSuccessType = QosFlowSetupSucc;
            lastFailureType = QosFlowSetupFail_NgFail;
            break;

        case STAT_HO_OUT:
            switch (mType)
            {
                // Success Case is Not Store History
                case IntraGnbOut_Att ... IntraGnbOut_Succ:
                case InterXnOut_Att ... InterXnOut_Succ:
                case InterNgOut_Att ... InterNgOut_Succ:
                case IntraGnbOutWithNedc_Att ... IntraGnbOutWithNedc_Succ:
                case InterXnOutWithNedc_Att ... InterXnOutWithNedc_Succ:
                case InterNgOutWithNedc_Att ... InterNgOutWithNedc_Succ:
                    storeHist = FALSE;
                    break;
                // Failure Case is Store History
                default:
                    storeHist = TRUE;
            }
            break;

        case STAT_HO_INTRA_FREQ_OUT:
            lastSuccessType = IntraFreqOut_Succ;
            lastFailureType = IntraFreqOut_RRE;
            break;

        case STAT_HO_INTRA_FREQ_OUT_REDCAP:
            lastSuccessType = IntraFreqOut_Succ_RedCap;
            lastFailureType = IntraFreqOut_RRE_RedCap;
            break;

        case STAT_HO_INTER_FREQ_OUT:
            if ((mType > InterFreqOutWithGap_Succ && mType <= InterFreqOutWithGap_RRE) ||  // NR_CONN_MC_21D
                (mType > InterFreqOutWithoutGap_Succ && mType <= InterFreqOutWithoutGap_RRE))
                storeHist = TRUE;
            break;

        case STAT_HO_INTER_FREQ_OUT_REDCAP:
            if ((mType > InterFreqOutWithGap_Succ_RedCap && mType <= InterFreqOutWithGap_RRE_RedCap) ||  // NR_CONN_MC_21D
                (mType > InterFreqOutWithoutGap_Succ_RedCap && mType <= InterFreqOutWithoutGap_RRE_RedCap))
                storeHist = TRUE;
            break;

        case STAT_HO_IN:
            switch (mType)
            {
                // Success Case is Not Store History
                case IntraGnbIn_Att ... IntraGnbIn_Succ:
                case InterXnIn_Att ... InterXnIn_Succ:
                case InterNgIn_Att ... InterNgIn_Succ:
                case IntraGnbInWithNedc_Att ... IntraGnbInWithNedc_Succ:
                case InterXnInWithNedc_Att ... InterXnInWithNedc_Succ:
                case InterNgInWithNedc_Att ... InterNgInWithNedc_Succ:
                    storeHist = FALSE;
                    break;
                // Failure Case is Store History
                default:
                    storeHist = TRUE;
            }
            break;

        case STAT_HO_IN_REDCAP:
            switch (mType)
            {
                // Success Case is Not Store History
                case IntraGnbIn_Att_RedCap ... IntraGnbIn_Succ_RedCap:
                case InterXnIn_Att_RedCap ... InterXnIn_Succ_RedCap:
                case InterNgIn_Att_RedCap ... InterNgIn_Succ_RedCap:
                    storeHist = FALSE;
                    break;
                // Failure Case is Store History
                default:
                    storeHist = TRUE;
            }
            break;

        case STAT_RRC_ESTAB:
            lastSuccessType = ConnEstabSucc;
            lastFailureType = ConnEstabReject_CacFail;
            break;

        case STAT_NG_ESTAB:
            lastSuccessType = NgConnEstabSucc;
            lastFailureType = NgConnEstabFail_F1Fail;
            break;

        // IRAT_HO
        case STAT_HO_EUTRAN_OUT:
            lastSuccessType = InterSysLTE_Out_Succ;
            lastFailureType = InterSysLTE_Out_N26InterfaceNotAvailable;
            break;
        case STAT_HO_EUTRAN_OUT_FALLBACK:
            if ((mType > InterSysLTE_Out_EPSFallback_Succ &&
                    mType <= InterSysLTE_Out_EPSFallback_N26InterfaceNotAvailable) ||
                (mType > InterSysLTE_Out_EmergencyFallback_Succ && mType <= InterSysLTE_Out_EmergencyFallback_RRE))
                storeHist = TRUE;
            break;

        case STAT_SGNB_ADD_EUTRAN_OUT:
            lastSuccessType = EndcAddSucc;
            lastFailureType = EndcAddFail_DuFail;
            break;

        case STAT_HO_EUTRAN_IN:
            lastSuccessType = InterSysLTE_In_Succ;
            lastFailureType = InterSysLTE_In_RRE;
            break;

        case STAT_HO_EUTRAN_IN_REDCAP:
            lastSuccessType = InterSysLTE_In_Succ_RedCap;
            lastFailureType = InterSysLTE_In_RRE_RedCap;
            break;

        case STAT_DRB_SETUP_PLMN_SNSSAI:
        case STAT_INITIAL_DRB_SETUP_DU_ID:
        case STAT_INITIAL_DRB_SETUP_DU_ID_PLMN_SNSSAI:
            if (mType > DrbSetupSnssaiSucc) storeHist = TRUE;
            break;

        case STAT_PDU_SESSION_RESOURCE_MODIFY_REQUEST_DRB_SETUP:
            if (mType > DrbSetupSucc) storeHist = TRUE;
            break;

        case STAT_PDU_SESSION_RESOURCE_SETUP_PLMN_SNSSAI:
            if (mType > PduSetupSucc) storeHist = TRUE;
            break;

        case STAT_QOS_FLOW_SETUP_PLMN_SNSSAI:
            if (mType > QosFlowSetupSucc) storeHist = TRUE;
            break;

        case STAT_NEDC_ADD:
            lastSuccessType = NedcAddSucc;
            lastFailureType = NedcAddFail_DuFail;
            break;

        case STAT_NEDC_DRB_SETUP:
            lastSuccessType = NedcDrbSetupSucc;
            lastFailureType = NedcDrbSetupFail_DuFail;
            break;

        case STAT_PLMN_HO_OUT:
            storeHist = FALSE;
            break;

        case STAT_HO_EUTRAN_FREQ_OUT: // IRAT_HO_24A
            {
                if (ptCi->hoInfo.hoType.rat == HO_TYPE_INTER_RAT)
                {
                    if (IS_FALLBACK_CASE(ptCi))
                    {
                        if ((mType > InterSysLTE_Out_EPSFallback_Succ_FREQ_OUT &&
                                    mType <= InterSysLTE_Out_EPSFallback_N26InterfaceNotAvailable_FREQ_OUT) ||
                                (mType > InterSysLTE_Out_EmergencyFallback_Succ_FREQ_OUT &&
                                    mType <= InterSysLTE_Out_EmergencyFallback_RRE_FREQ_OUT))
                            storeHist = TRUE;
                    }
                    else
                    {
                        lastSuccessType = InterSysLTE_Out_Succ_FREQ_OUT;
                        lastFailureType = InterSysLTE_Out_N26InterfaceNotAvailable_FREQ_OUT;
                    }
                }
                else
                {
                    return FALSE; // default
                }
            }
            break;

        case STAT_HO_EUTRAN_FREQ_OUT_REDCAP:
            {
                if (ptCi->hoInfo.hoType.rat == HO_TYPE_INTER_RAT)
                {
                    if (IS_FALLBACK_CASE(ptCi))
                    {
                        if ((mType > InterSysLTE_Out_EPSFallback_Succ_RedCap &&
                                    mType <= InterSysLTE_Out_EPSFallback_N26InterfaceNotAvailable_RedCap) ||
                                (mType > InterSysLTE_Out_EmergencyFallback_Succ_RedCap &&
                                    mType <= InterSysLTE_Out_EmergencyFallback_RRE_RedCap))
                            storeHist = TRUE;
                    }
                    else
                    {
                        lastSuccessType = InterSysLTE_Out_Succ_RedCap;
                        lastFailureType = InterSysLTE_Out_N26InterfaceNotAvailable_RedCap;
                    }
                }
                else
                {
                    return FALSE; // default
                }
            }
            break;

        default:
            return FALSE;
    }

    if (mType > lastSuccessType && mType <= lastFailureType)
    {
        storeHist = TRUE;
    }

    return storeHist;
}

/**
 * @brief       Store statistics fail cause history
 *
 * @param[in]       mFamily : statistic family / STAT_PM_FAMILY_ID_TYPE
 * @param[in]       mType : statistic type / STAT_DATA_USAGE_ITEM
 * @param[in/out]   ptCi : call information / callInfo_type
 * @return          None
 */
void VLIB_StoreFailCauseHist(
    int mFamily, int mActualFamily, int mType, callInfo_type *ptCi, VccbPmKey_type* pPmKey, const char *fnName)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (FnVCCB_CheckIfFailureCauseHistoryShouldBeStored(ptCi, mFamily, mType) == TRUE)
    {
        uint8_t storeTargetInfo = FALSE;
        uint16_t targetCellNum = ptCi->hoInfo.targetCellNum;
        if (targetCellNum < MAX_CELL_NUM_VCCB && CELLINFO[targetCellNum].gnbNum < MAX_GNB_PER_SYS &&
            CELLINFO[targetCellNum].endPointF1Index < MAX_GNB_DU_PER_GNB_CU_CP)
        {
            storeTargetInfo = TRUE;
        }
        else
        {
            storeTargetInfo = FALSE;
            VCCB_PRINT_COMMENT("%s:%d:Target info is not stored\n", __FUNCTION__, __LINE__);
        }

        MUTEX_LOCK(&VCCB_STAT->mutex_write);

        VccbFailCauseHist_type *pHist = &VCCB_STAT->failCauseHist[VCCB_STAT->lastStoredFailHistIndex % MAX_VCCB_STAT_FAIL_HIST];

        memset(pHist, 0, sizeof(VccbFailCauseHist_type));

        ComTimeUtil::get_current_time(pHist->loggingTime);

        pHist->mFamily = mActualFamily;
        pHist->mType = mType;
        pHist->index1 = pPmKey->keyList[VCCB_PMKEY_INDEX1];
        pHist->index2 = pPmKey->keyList[VCCB_PMKEY_INDEX2];

        if (strlen(fnName) > 5)
            snprintf(pHist->fnName, sizeof(pHist->fnName), "%s", &fnName[5]);
        else
            snprintf(pHist->fnName, sizeof(pHist->fnName), "%s", fnName);

        pHist->callId = ptCi->callId;
        pHist->stateCmd = ptCi->stateCmd;
        pHist->callState = ptCi->state;

        pHist->myThreadId = ptCi->myThreadId;
        pHist->servCellNum = (int16_t)ptCi->servCellNum;
        pHist->endPointInfo = ptCi->endPointInfo;

        pHist->hoType = ptCi->hoInfo.hoType;
        pHist->isTarget = ptCi->hoInfo.isTarget;
        if (TRUE == storeTargetInfo)
        {
            pHist->hoTargetCellNum = targetCellNum;
            pHist->hoTargetCellIdentity = ptCi->hoInfo.cellIdentity;
            pHist->hoDuId =
                GetDuId(GNBINFO[CELLINFO[targetCellNum].gnbNum].gnbDu[CELLINFO[targetCellNum].endPointF1Index].gnbDuId);
        }
        pHist->hoF1Idx = ptCi->hoInfo.targetDu.f1Idx;

        pHist->cause = ptCi->cause;

        VCCB_STAT->lastStoredFailHistIndex++;
        VCCB_STAT->lastStoredFailHistIndex %= MAX_VCCB_STAT_FAIL_HIST;

        MUTEX_UNLOCK(&VCCB_STAT->mutex_write);
    }
}

/**
 * @brief     Function for selecting cell Indentity index for F1AP_UE_SETUP_CU and F1AP_CU_INIT_UE_MOD_CU stat families
 * @param     ptCi      : callInfo
 * @param     ptIndex   : index used in the statistic
 * @param     mFamily   : stat family
 * @param     reserved2 : reserved value for cellIdentity
 */
void VLIB_StatSelectCellIdIndex(callInfo_type *ptCi, unsigned long long *ptIndex, int mFamily, int reserved2)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptIndex);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];
    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];

    switch (mFamily)
    {
        case STAT_RRC_RELEASE:
        case STAT_RRC_RELEASE_GLOBAL_ID:
        case STAT_RRC_RECONFIG:
        case STAT_RRC_RECONFIG_GLOBAL_ID:
            if (VHCM_isSaHandoverUE(ptCi) == TRUE &&
                ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_INTRA_GNB_INTER_DU_HANDOVER)
            {
                *ptIndex = VLIB_NrCellId2CellId(pGnb->globalGnbId.gnbId.idLength, ptCi->nRCGI.ci);
            }
            else
            {
                *ptIndex = pCell->cellIdentity;
            }
            break;

        case STAT_F1AP_UE_SETUP_CU:
            if (((IntraRatHO_cmd == ptCi->stateCmd) && (HO_TYPE_INTER_DU == ptCi->hoInfo.hoType.du)) ||
                (VCCB_FLAG_ON == ptCi->bitFlag.isEndcUeCtxtReleaseDuringF1Setup &&
                    X2UeContextRelease_cmd == ptCi->stateCmd && SgNBAddition_cmd != ptCi->prevStateCmd))
            {
                *ptIndex = ptCi->hoInfo.cellIdentity;
            }
            else
            {
                *ptIndex = pCell->cellIdentity;
            }
            break;

        case STAT_F1AP_CU_INIT_UE_MOD_CU:
            if (reserved2 != 0)
            {
                *ptIndex = (unsigned long long)reserved2;
            }
            else
            {
                if ((STATE_INTER_DU_Execution == ptCi->state) &&
                    (HO_TYPE_INTER_DU == ptCi->hoInfo.hoType.du))  // SA Handover
                {
                    *ptIndex = ptCi->hoInfo.cellIdentity;
                }
                else if ((IntraRatHO_cmd == ptCi->stateCmd) && (HO_TYPE_INTER_DU == ptCi->hoInfo.hoType.du))
                {
                    if ((F1_UEContextModificationResponse_id == ptCi->recentMsgId) ||
                        (F1_UEContextModificationFailure_id == ptCi->recentMsgId))
                    {
                        if (ptCi->hoInfo.targetDu.f1Idx == ptCi->recentRcvdMsgEndPointIdx)
                        {
                            // F1 msg from target DU.
                            *ptIndex = ptCi->hoInfo.cellIdentity;
                        }
                        else
                        {
                            *ptIndex = pCell->cellIdentity;
                        }
                    }
                    else if (GET_F1_CTXT_MODRSP_TGT_FLAG(ptCi->flag.respFlag) &&
                             !(GET_F1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag)))
                    {
                        // In timeout or other failure case, not receive any msg from only target DU.
                        *ptIndex = ptCi->hoInfo.cellIdentity;
                    }
                    else
                    {
                        *ptIndex = pCell->cellIdentity;
                    }
                }
                else if ((RrcReestablish_cmd == ptCi->stateCmd) && (RRE_TYPE_INTER_DU == ptCi->ueInfo.reestablishInfo.reestablishType))
                {
                    if ((F1_UEContextModificationResponse_id == ptCi->recentMsgId) ||
                        (F1_UEContextModificationFailure_id == ptCi->recentMsgId))
                    {
                        *ptIndex = pCell->cellIdentity;
                        if (ptCi->ueInfo.reestablishInfo.oldF1Idx == ptCi->recentRcvdMsgEndPointIdx)
                        {
                            // F1 msg from old DU.
                            if (ptCi->ueInfo.reestablishInfo.oldCellNum < MAX_CELL_NUM_VCCB)
                            {
                                VccbCellInfo_type *pOldCell = &CELLINFO[ptCi->ueInfo.reestablishInfo.oldCellNum];
                                *ptIndex = pOldCell->cellIdentity;
                            }
                        }
                    }
                    else
                    {
                        *ptIndex = pCell->cellIdentity;
                    }
                }
                else
                {
                    *ptIndex = pCell->cellIdentity;
                }
            }
            break;

        default:
            // nothing to do
            break;
    }
}

/**
 * @brief     Function for selecting F1 Cause index for F1AP_UE_SETUP_CU and F1AP_CU_INIT_UE_MOD_CU stat families
 * @param     ptCi    : callInfo
 * @param     ptIndex  : index used in the statistic
 * @param     mFamily : stat family
 */
void VLIB_StatSelectF1CauseIndex(callInfo_type *ptCi, unsigned long long *ptIndex, int mFamily)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptIndex);

    switch (mFamily)
    {
        case STAT_F1AP_UE_SETUP_CU:
            if ((SgNBAddition_cmd == ptCi->stateCmd) || (RRCConnection_cmd == ptCi->stateCmd) ||
                (PDUSetup_cmd == ptCi->stateCmd) ||
                (VCCB_FLAG_ON == ptCi->bitFlag.isEndcUeCtxtReleaseDuringF1Setup &&
                    X2UeContextRelease_cmd == ptCi->stateCmd && SgNBAddition_cmd == ptCi->prevStateCmd))
            {
                *ptIndex = F1_UE_CTX_SETUP_INITIAL_SETUP_CAUSE;
            }
            else if (IntraRatHO_cmd == ptCi->stateCmd ||
                     (VCCB_FLAG_ON == ptCi->bitFlag.isEndcUeCtxtReleaseDuringF1Setup &&
                         X2UeContextRelease_cmd == ptCi->stateCmd && SgNBAddition_cmd != ptCi->prevStateCmd))
            {
                *ptIndex = F1_UE_CTX_SETUP_MOBILITY_CAUSE;
            }
            else
            {
                *ptIndex = F1_UE_CTX_SETUP_REESTABLISH_CAUSE;
            }
            break;

        case STAT_F1AP_CU_INIT_UE_MOD_CU:
            if (IntraRatHO_cmd == ptCi->stateCmd)
            {
                *ptIndex = F1_UE_CTX_MOD_MOBILITY_CAUSE;
            }
            else if (RrcReestablish_cmd == ptCi->stateCmd)
            {
                *ptIndex = F1_UE_CTX_MOD_REESTABLISH_CAUSE;
            }
            else
            {
                *ptIndex = F1_UE_CTX_MOD_OTHERS_CAUSE;
            }
            break;

        default:
            // nothing to do
            break;
    }
}

/**
 * @brief       Call logShmStat or logShmStatCall according to the ptCi value
 */

namespace
{
template <typename updateType>
void fillUpdateVal(VccbPmUpdateVal_type &pmUpdateVal, updateType updateValue)
{
    pmUpdateVal.u.updateValInt = static_cast<int>(updateValue);
    pmUpdateVal.uType = INT;
}

template <>
void fillUpdateVal(VccbPmUpdateVal_type &pmUpdateVal, unsigned long long updateValue)
{
    pmUpdateVal.u.updateValUll = updateValue;
    pmUpdateVal.uType = ULL;
}

template <>
void fillUpdateVal(VccbPmUpdateVal_type &pmUpdateVal, float updateValue)
{
    pmUpdateVal.u.updateValFloat = updateValue;
    pmUpdateVal.uType = FLOAT;
}
}

template <typename UpdateVal>
inline void LOG_SHM_STAT(
    callInfo_type *ptCi, PME_LIB_TYPE method, int mFamily, int mType, UpdateVal updateVal, VccbPmKey_type& rPmKey)
{
    VccbPmUpdateVal_type pmUpdateVal;

    switch (method)
    {
        case PME_LIB_GAUGE:
        case PME_LIB_SI:
        case PME_LIB_CC:
            fillUpdateVal(pmUpdateVal, updateVal);
            break;
        default:
            return;
    }

    if (ptCi == NULL)
    {
        logShmStat(method, mFamily, mType, pmUpdateVal, rPmKey);
    }
    else
    {
        logShmStatCall(ptCi, method, mFamily, mType, pmUpdateVal, rPmKey);
    }
}

namespace std
{
// vpmCollectAny
template <typename _vpmCollectType>
int vpmCollectAny(PME_LIB_TYPE method, unsigned int familyID, unsigned int typeID, _vpmCollectType updateValue,
    const VccbPmKey_type &pmKey, uint8_t threadId);

template <>
int vpmCollectAny(
    PME_LIB_TYPE method, unsigned int familyID, unsigned int typeID, unsigned int val, const VccbPmKey_type &pmKey, uint8_t threadId)
{
#ifndef IPC_TEST
    if (DBG->flag.statThreadUsage == VCCB_FLAG_ON && method == PME_LIB_CC && threadId < MAX_CALL_THREAD_NUM_VCCB)
    {
        FnVCCB_StatisticsItemCollect(familyID, typeID, val, pmKey, threadId, STATISTICS_UINT_TYPE);
        return GOOD;
    }
    else
#endif
    {
        (void) threadId;
        int status = vpmCollectUint(method, familyID, typeID, val, pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2], pmKey.keyList[VCCB_PMKEY_INDEX3], pmKey.keyList[VCCB_PMKEY_INDEX4],
            pmKey.keyList[VCCB_PMKEY_INDEX5], pmKey.keyList[VCCB_PMKEY_INDEX6]);
        if (status < 0)
        {
            VCCB_PRINT_CRITICAL("vpmCollectUint Error(%d) mFamily:%d mType:%d!!\n", status, familyID, typeID);
        }
        return status;
    }
}

template <>
int vpmCollectAny(PME_LIB_TYPE method, unsigned int familyID, unsigned int typeID, unsigned long long val,
    const VccbPmKey_type &pmKey, uint8_t threadId)
{
#ifndef IPC_TEST
    if (DBG->flag.statThreadUsage == VCCB_FLAG_ON && method == PME_LIB_CC && threadId < MAX_CALL_THREAD_NUM_VCCB)
    {
        FnVCCB_StatisticsItemCollect(familyID, typeID, val, pmKey, threadId, STATISTICS_ULL_TYPE);
        return GOOD;
    }
    else
#endif
    {
        (void) threadId;
        int status = vpmCollectUll(method, familyID, typeID, val, pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2], pmKey.keyList[VCCB_PMKEY_INDEX3], pmKey.keyList[VCCB_PMKEY_INDEX4],
            pmKey.keyList[VCCB_PMKEY_INDEX5], pmKey.keyList[VCCB_PMKEY_INDEX6]);
        if (status < 0)
        {
            VCCB_PRINT_CRITICAL("vpmCollectUll Error(%d) mFamily:%d mType:%d!!\n", status, familyID, typeID);
        }
        return status;
    }
}

template <>
int vpmCollectAny(
    PME_LIB_TYPE method, unsigned int familyID, unsigned int typeID, float val, const VccbPmKey_type &pmKey, uint8_t threadId)
{
#ifndef IPC_TEST
    if (DBG->flag.statThreadUsage == VCCB_FLAG_ON && method == PME_LIB_CC && threadId < MAX_CALL_THREAD_NUM_VCCB)
    {
        FnVCCB_StatisticsItemCollect(familyID, typeID, val, pmKey, threadId, STATISTICS_FLOAT_TYPE);
        return GOOD;
    }
    else
#endif
    {
        (void) threadId;
        int status = vpmCollectFloat(method, familyID, typeID, val, pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2], pmKey.keyList[VCCB_PMKEY_INDEX3], pmKey.keyList[VCCB_PMKEY_INDEX4],
            pmKey.keyList[VCCB_PMKEY_INDEX5], pmKey.keyList[VCCB_PMKEY_INDEX6]);
        if (status < 0)
        {
            VCCB_PRINT_CRITICAL("vpmCollectFloat Error(%d) mFamily:%d mType:%d!!\n", status, familyID, typeID);
        }
        return status;
    }
}

// vpmUpdateAny
template <typename _vpmUpdateType>
int vpmUpdateAny(
    PME_LIB_TYPE method, unsigned int familyID, unsigned int numOfItem, _vpmUpdateType updateValue, const VccbPmKey_type &pmKey, uint8_t threadId);

template <>
int vpmUpdateAny(
    PME_LIB_TYPE method, unsigned int familyID, unsigned int numOfItem, updateItemUINT *updateValue, const VccbPmKey_type &pmKey, uint8_t threadId)
{
#ifndef IPC_TEST
    if (DBG->flag.statThreadUsage == VCCB_FLAG_ON && method == PME_LIB_CC && threadId < MAX_CALL_THREAD_NUM_VCCB && numOfItem < VCCB_MAX_STAT_THREAD_MTYPES)
    {
        FnVCCB_StatisticsItemUpdate(familyID, numOfItem, updateValue, pmKey, threadId, STATISTICS_UINT_TYPE);
        return GOOD;
    }
    else
#endif
    {
        (void) method;
        (void) threadId;
        int status = vpmUpdateUint(familyID, pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2], pmKey.keyList[VCCB_PMKEY_INDEX3], pmKey.keyList[VCCB_PMKEY_INDEX4], pmKey.keyList[VCCB_PMKEY_INDEX5],
            pmKey.keyList[VCCB_PMKEY_INDEX6], numOfItem, updateValue);
        if (status < 0)
        {
            VCCB_PRINT_CRITICAL("vpmUpdateUint Error(%d) %d/%llu/%llu/%llu/%llu/%llu/%llu\n", status, familyID,
                pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2], pmKey.keyList[VCCB_PMKEY_INDEX3], pmKey.keyList[VCCB_PMKEY_INDEX4], pmKey.keyList[VCCB_PMKEY_INDEX5], pmKey.keyList[VCCB_PMKEY_INDEX6]);
        }
        return status;
    }
}

template <>
int vpmUpdateAny(
    PME_LIB_TYPE method, unsigned int familyID, unsigned int numOfItem, updateItemULL *updateValue, const VccbPmKey_type &pmKey, uint8_t threadId)
{
#ifndef IPC_TEST
    if (DBG->flag.statThreadUsage == VCCB_FLAG_ON && method == PME_LIB_CC && threadId < MAX_CALL_THREAD_NUM_VCCB && numOfItem < VCCB_MAX_STAT_THREAD_MTYPES)
    {
        FnVCCB_StatisticsItemUpdate(familyID, numOfItem, updateValue, pmKey, threadId, STATISTICS_ULL_TYPE);
        return GOOD;
    }
    else
#endif
    {
        (void) method;
        (void) threadId;
        int status = vpmUpdateUll(familyID, pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2], pmKey.keyList[VCCB_PMKEY_INDEX3], pmKey.keyList[VCCB_PMKEY_INDEX4], pmKey.keyList[VCCB_PMKEY_INDEX5],
            pmKey.keyList[VCCB_PMKEY_INDEX6], numOfItem, updateValue);
        if (status < 0)
        {
            VCCB_PRINT_CRITICAL("vpmUpdateUll Error(%d) %d/%llu/%llu/%llu/%llu/%llu/%llu\n", status, familyID, pmKey.keyList[VCCB_PMKEY_INDEX1],
                pmKey.keyList[VCCB_PMKEY_INDEX2], pmKey.keyList[VCCB_PMKEY_INDEX3], pmKey.keyList[VCCB_PMKEY_INDEX4], pmKey.keyList[VCCB_PMKEY_INDEX5], pmKey.keyList[VCCB_PMKEY_INDEX6]);
        }
        return status;
    }
}

template <>
int vpmUpdateAny(
    PME_LIB_TYPE method, unsigned int familyID, unsigned int numOfItem, updateItemFLOAT *updateValue, const VccbPmKey_type &pmKey, uint8_t threadId)
{
#ifndef IPC_TEST
    if (DBG->flag.statThreadUsage == VCCB_FLAG_ON && method == PME_LIB_CC && threadId < MAX_CALL_THREAD_NUM_VCCB && numOfItem < VCCB_MAX_STAT_THREAD_MTYPES)
    {
        FnVCCB_StatisticsItemUpdate(familyID, numOfItem, updateValue, pmKey, threadId, STATISTICS_FLOAT_TYPE);
        return GOOD;
    }
    else
#endif
    {
        (void) method;
        (void) threadId;
        int status = vpmUpdateFloat(familyID, pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2], pmKey.keyList[VCCB_PMKEY_INDEX3], pmKey.keyList[VCCB_PMKEY_INDEX4], pmKey.keyList[VCCB_PMKEY_INDEX5],
            pmKey.keyList[VCCB_PMKEY_INDEX6], numOfItem, updateValue);
        if (status < 0)
        {
            VCCB_PRINT_CRITICAL("vpmUpdateFloat Error(%d) %d/%llu/%llu/%llu/%llu/%llu/%llu\n", status, familyID,
                pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2], pmKey.keyList[VCCB_PMKEY_INDEX3], pmKey.keyList[VCCB_PMKEY_INDEX4], pmKey.keyList[VCCB_PMKEY_INDEX5], pmKey.keyList[VCCB_PMKEY_INDEX6]);
        }
        return status;
    }
}
}  // namespace

/**
 * @brief       Call vpmCollect[ ] API according to PME_LIB_TYPE
 */
template <typename UpdateVal>
inline void VPM_COLLECT(
    PME_LIB_TYPE method, unsigned int mFamily, unsigned int mType, UpdateVal updateVal, VccbPmKey_type& rPmKey, uint8_t threadId)
{
    AUTO_TRACE_FUNC;
    switch (method)
    {
        case PME_LIB_GAUGE:
        case PME_LIB_SI:
        case PME_LIB_CC:
            std::vpmCollectAny(method, mFamily, mType, updateVal, rPmKey, threadId);
            LOG_PM_COLLECT(mFamily, mType);
            break;
        default:
            VCCB_PRINT_COMMENT("VPM_COLLECT: PME_LIB_TYPE(%d) not supported!\n", method);
            return;
    }
}

/**
 * @brief       Call vpmUpdate[ ] API according to PME_LIB_TYPE
 */
template <typename _vpmUpdateArr>
inline void VPM_UPDATE(
    PME_LIB_TYPE method, unsigned int mFamily, VccbPmKey_type& rPmKey, unsigned int numOfItem, _vpmUpdateArr updateArr, uint8_t threadId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(updateArr);

    switch (method)
    {
        case PME_LIB_GAUGE:
        case PME_LIB_SI:
        case PME_LIB_CC:
            std::vpmUpdateAny(method, mFamily, numOfItem, updateArr, rPmKey, threadId);
            break;
        default:
            VCCB_PRINT_COMMENT("VPM_UPDATE: PME_LIB_TYPE(%d) not supported!\n", method);
            return;
    }
}

/**
 * @brief       Print dsh log according to PME_LIB_TYPE
 */
template <typename UpdateVal>
inline void PM_PRINT(PME_LIB_TYPE method, int mFamily, int mType, UpdateVal updateVal, VccbPmKey_type& rPmKey)
{
    AUTO_TRACE_FUNC;
    const char *cMethod[] = {"pmGauge", "pmSI", "pmCC"};
    uint8_t idx = 0;

    switch (method)
    {
        case PME_LIB_GAUGE:
            idx = 0;
            break;
        case PME_LIB_SI:
            idx = 1;
            break;
        case PME_LIB_CC:
            idx = 2;
            break;
        default:
            return;
    }

    if (!(DBG->log.logCtlMask & NO_VCCB_LOG_DSH_PRINT))
    {
        const std::string tmp = std::to_string(updateVal);
        const char *uVal = tmp.c_str();

        LOGFPRT(PL_MAJOR, "%s (mFam/mType/val/idx1/..) = %d/%d/%s/%llu/%llu/%llu/%llu/%llu/%llu/%llu\n", cMethod[idx],
            mFamily, mType, uVal, rPmKey.keyList[VCCB_PMKEY_INDEX1], rPmKey.keyList[VCCB_PMKEY_INDEX2],
            rPmKey.keyList[VCCB_PMKEY_INDEX3], rPmKey.keyList[VCCB_PMKEY_INDEX4], rPmKey.keyList[VCCB_PMKEY_INDEX5],
            rPmKey.keyList[VCCB_PMKEY_INDEX6], rPmKey.keyList[VCCB_PMKEY_INDEX7]);
    }
}

#ifdef NEW_HOST_SIM
static void checkAndStoreFamilyShmLog(unsigned int mFamily, int *shmStoreFlag)
{
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(mFamily, 5000, 6500);

    if (TRUE == *shmStoreFlag)
    {
        return;
    }

    for(uint8_t idx=0; idx < MAX_FAMILIES_NUM; ++idx)
    {
        if (0 == DBG->value.periodicFamilyToLog[idx])
        {
            return;
        }

        if (mFamily == DBG->value.periodicFamilyToLog[idx])
        {
            *shmStoreFlag = TRUE;
            return;
        }
    }
}
#endif

/**
 * @brief       Collect Attempt stats and Success / Fail stats.
 *
 * @param[in/out]   ptCi : call information / callInfo_type
 * @param[in]       mFamily : statistic family
 * @param[in]       mType : statistic type
 * @return          None
 */
template <typename UpdateItemCommon>
void CollectPmStatistics(callInfo_type *ptCi, unsigned int mFamily, unsigned int mActualFamily,
    VccbPmMultiCollect_type *pPmMultiCollect, UpdateItemCommon updateItem, VccbPmKey_type& rPmKey, int shmStoreFlag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pPmMultiCollect);
    if (ptCi != NULL && RscCall::isReturningCall(ptCi->callId) == TRUE)
    {
        return;
    }

    unsigned int itemIdx, item_mType = 0;
    unsigned int maxType = VCCB_MAX_MTYPES;
    (void)mFamily;

    PME_LIB_TYPE method = pPmMultiCollect->updateMethod;

#ifdef IPC_TEST
#else
    // OAM request : It works only when multiple statistics calls are made.
    if (pPmMultiCollect->numOfItem > 1)
    {
        pPmMultiCollect->usage = CI_use;
    }
#endif

    for (itemIdx = 0; itemIdx < MIN(pPmMultiCollect->numOfItem, maxType); ++itemIdx)
    {
        item_mType = updateItem[itemIdx].typeID;

        /* call PM lib */
        if (pPmMultiCollect->usage == CI_no_use)  // vpmCollect[ ](O) vpmUpdate[ ](X)
        {
            if (DBG->flag.isSkipVpmCollect == VCCB_FLAG_OFF)
            {
                if((rPmKey.usageOfNumKey == CI_use) && (rPmKey.numKey >= VCCB_USE_PM_VARIABLE_KEY_THRESHOLD)) // 7
                {
                    // New API When pmKey Num >= 7
                    VPM_COLLECT_WITH_NUMKEY(method, mActualFamily, item_mType, updateItem[itemIdx].updateVal, rPmKey);
                }
                else
                {
                    if (ptCi != NULL)
                    {
                        VPM_COLLECT(method, mActualFamily, item_mType, updateItem[itemIdx].updateVal, rPmKey, ptCi->myThreadId);
                    }
                    else
                    {
                        VPM_COLLECT(method, mActualFamily, item_mType, updateItem[itemIdx].updateVal, rPmKey, MAX_CALL_THREAD_NUM_VCCB);
                    }
                }
            }
        }

#ifdef NEW_HOST_SIM
        checkAndStoreFamilyShmLog(mActualFamily, &shmStoreFlag);
#endif
        if (shmStoreFlag == TRUE)
        {
            LOG_SHM_STAT(ptCi, method, (int)mActualFamily, (int)item_mType, updateItem[itemIdx].updateVal, rPmKey);
        }

        /* print dsh log */
        if (DBG->flag.fdis_stat &&  // fdis_stat : default on
            ((method == PME_LIB_GAUGE && DBG->flag.fdis_periodic_stat) || method != PME_LIB_GAUGE))
        {
            PM_PRINT(method, (int)mActualFamily, (int)item_mType, updateItem[itemIdx].updateVal, rPmKey);
        }
    }

    if (pPmMultiCollect->usage == CI_use)  // vpmCollect[ ](X) vpmUpdate[ ](O)
    {
        if (DBG->flag.isSkipVpmUpdate == VCCB_FLAG_OFF)
        {
            if((rPmKey.usageOfNumKey == CI_use) && (rPmKey.numKey >= VCCB_USE_PM_VARIABLE_KEY_THRESHOLD)) // 7
            {
                // New API When pmKey Num >= 7
                VPM_UPDATE_WITH_NUMKEY(method, (int)mActualFamily, rPmKey, pPmMultiCollect->numOfItem, updateItem);
            }
            else
            {
                if (ptCi != NULL)
                {
                    VPM_UPDATE(method, mActualFamily, rPmKey, pPmMultiCollect->numOfItem, updateItem, ptCi->myThreadId);
                }
                else
                {
                    VPM_UPDATE(method, mActualFamily, rPmKey, pPmMultiCollect->numOfItem, updateItem, MAX_CALL_THREAD_NUM_VCCB);
                }
            }
        }
    }
}

/**
 * @brief     Collecting stat by pmGauge_FLOAT
 * @param     mFamily : stat family
 * @param     mType : stat type
 * @param     eventVal : value
 * @return    string of stat type
 */
void VLIB_LibStatPmGauge(int mFamily, int mType, callInfo_type *ptCi, float updateValue, uint16_t gnbNum,
    uint16_t cellIdentity, uint32_t reserved5, uint32_t reserved6)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(CFG->vm.unitId, MAX_CPC_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(cellIdentity, MAX_CELL_IDENTITY);
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);

    int mActualFamily = mFamily;
    int additionalType = -1;

    VccbPmKey_type pmKey;
    memset(&pmKey, 0, sizeof(VccbPmKey_type));

    VccbPmMultiCollect_type pmMultiCollect;
    FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_GAUGE);

    int shmStoreFlag = FALSE;

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    switch (mFamily)
    {
        case STAT_CPC_CALL_USAGE:
        case STAT_CP_CALL_USAGE:
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;
            break;

        case STAT_DRB_CONN_INFO:
        case STAT_DRB_NUM_PER_GNB:
        case STAT_DRB_NUM_UL_ONLY_ROHC_SA:
        case STAT_ERAB_NUM_UL_ONLY_ROHC:
            VCCB_CHECK_E_RANGE_AND_VOID(reserved5, MAX_QCI_VALUE);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = cellIdentity;
            pmKey.keyList[VCCB_PMKEY_INDEX4] = reserved5;  // QCI
            break;

        case STAT_DRB_CONN_INFO_PLMN:
        case STAT_DRB_NUM_PER_GNB_PLMN:
            VCCB_CHECK_E_RANGE_AND_VOID(reserved6, MAX_QCI_VALUE);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = cellIdentity;
            pmKey.keyList[VCCB_PMKEY_INDEX4] = reserved5;  // PLMN_UE
            pmKey.keyList[VCCB_PMKEY_INDEX5] = reserved6;  // QCI
            break;

        case STAT_RRC_CONN_INFO_PLMN:
        case STAT_UE_NUM_PER_GNB_PLMN:
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = cellIdentity;
            pmKey.keyList[VCCB_PMKEY_INDEX4] = reserved5;  // PLMN_UE
            break;

        case STAT_RRC_CONN_INFO_DU_ID_PLMN_RFSP:
            VCCB_CHECK_E_RANGE_AND_VOID(reserved6, MAX_RFSP_VALUE + 1);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3], cellIdentity, gnbNum);  // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = cellIdentity;  // CellIdentity
            pmKey.keyList[VCCB_PMKEY_INDEX5] = reserved5;     // PLMN_UE
            pmKey.keyList[VCCB_PMKEY_INDEX6] = reserved6;     // RFSP Value
            break;

        case STAT_NRDC_SN_CONN_INFO_MN:  // FGR-CC5200:FR760
        case STAT_NRDC_SN_CONN_INFO_SN:  // FGR-CC5200:FR770
            VCCB_CHECK_E_RANGE_AND_VOID(reserved6, MAX_RFSP_VALUE + 1);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3], cellIdentity, gnbNum);  // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = cellIdentity;  // CellIdentity
            pmKey.keyList[VCCB_PMKEY_INDEX5] = reserved5;     // PLMN_UE
            pmKey.keyList[VCCB_PMKEY_INDEX6] = reserved6;     // RFSP Value
            VCCB_FLAG_ON_FOR_DBG_LOG_NRDC_BASIC(shmStoreFlag);
            break;

        case STAT_NRDC_SN_TERM_DRB_CONN_INFO:
            VCCB_CHECK_E_RANGE_AND_VOID(reserved6, MAX_QCI_VALUE);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3], cellIdentity, gnbNum);  // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = cellIdentity;                                                 // CellIdentity
            pmKey.keyList[VCCB_PMKEY_INDEX5] = reserved5;                                                    // PLMN_UE
            pmKey.keyList[VCCB_PMKEY_INDEX6] = reserved6;                                                    // 5QI
            VCCB_FLAG_ON_FOR_DBG_LOG_NRDC_BASIC(shmStoreFlag);
            break;

        case STAT_UE_NUM_PER_GNB:
        case STAT_UE_NUM_UL_ONLY_ROHC:
        case STAT_UE_NUM_UL_ONLY_ROHC_SA:
        case STAT_RRC_CONN_INFO:
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = cellIdentity;
            break;
        case STAT_MDT_CONFIGURATION_DELIVERY_DU_ID:
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3], cellIdentity, gnbNum);
            pmKey.keyList[VCCB_PMKEY_INDEX4] = cellIdentity;
            break;

        case STAT_PSCELL_CHANGE_TIME:
        case STAT_HO_TIME:
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;  // index0 - CPC
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = cellIdentity;
            shmStoreFlag = TRUE;
            break;

        case STAT_SGNB_PROC_TIME_PER_GNB_DU_ID:
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;                      // CPC
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;          // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3], cellIdentity, gnbNum); // gNB_DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = cellIdentity;                        // CellIdentity
            shmStoreFlag = TRUE;
            break;

        case STAT_RRC_SETUP_TIME:
        case STAT_NG_SETUP_TIME:
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = cellIdentity;
            pmKey.keyList[VCCB_PMKEY_INDEX4] = reserved5;  // establishmentCause
            shmStoreFlag = TRUE;
            break;

        case STAT_DRB_SETUP_TIME_DU_ID:
        {
            uint32_t cellPlmnKey = 0;
            VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &cellPlmnKey);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = cellPlmnKey;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = pGnb->globalGnbId.gnbId.id;
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX4], cellIdentity, gnbNum);  // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX5] = cellIdentity;  // CellIdentity
            pmKey.keyList[VCCB_PMKEY_INDEX6] = reserved5;     // 5QI
            shmStoreFlag = TRUE;
            break;
        }

        case STAT_VONR_EMERGENCY_CONN_INFO:
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = GNBINFO[gnbNum].globalGnbId.gnbId.id;                         // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3], cellIdentity, gnbNum);  // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = cellIdentity;                                                 // CellIdentity
            break;

        case STAT_UE_NUM_PER_GNB_PLMN_SPID_DU_ID:
        {
            uint16_t cellNum = pGnb->env.cellNum[cellIdentity];
            VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
            const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
            if (MAX_GNB_DU_PER_GNB_CU_CP <= pCell->endPointF1Index)
            {
                // Skip pegging with Invalid Du ID for periodic family.
                return;
            }
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;                                          // CPC_ID
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;                              // gNB_ID
            pmKey.keyList[VCCB_PMKEY_INDEX3] = GetDuId(pGnb->gnbDu[pCell->endPointF1Index].gnbDuId);    // gNB_DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = cellIdentity;                                            // CellIdentity
            pmKey.keyList[VCCB_PMKEY_INDEX5] = reserved5;                                               // PLMN_UE
            pmKey.keyList[VCCB_PMKEY_INDEX6] = reserved6;                                               // SPIDIncludingInvalid
            break;
        }

        case STAT_RRC_CONN_INFO_REDCAP_PLMN:
        case STAT_CP_RRC_CONN_INFO_REDCAP_PLMN:
        {
            uint32_t cellPlmnKey = 0;
            VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &cellPlmnKey);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;                                               // CPC_ID, CP_ID
            pmKey.keyList[VCCB_PMKEY_INDEX2] = cellPlmnKey;                                                  // PLMN
            pmKey.keyList[VCCB_PMKEY_INDEX3] = pGnb->globalGnbId.gnbId.id;                                   // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX4], cellIdentity, gnbNum);  // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX5] = cellIdentity;                                                 // CellIdentity
            pmKey.keyList[VCCB_PMKEY_INDEX6] = reserved5;                                                    // PLMN_UE
            break;
        }

        case STAT_DRB_CONN_INFO_REDCAP_PLMN:
        case STAT_CP_DRB_CONN_INFO_REDCAP_PLMN:
        {
            uint32_t cellPlmnKey = 0;
            VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &cellPlmnKey);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;                                               // CPC_ID, CP_ID
            pmKey.keyList[VCCB_PMKEY_INDEX2] = cellPlmnKey;                                                  // PLMN
            pmKey.keyList[VCCB_PMKEY_INDEX3] = pGnb->globalGnbId.gnbId.id;                                   // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX4], cellIdentity, gnbNum);  // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX5] = cellIdentity;                                                 // CellIdentity
            pmKey.keyList[VCCB_PMKEY_INDEX6] = reserved5;                                                    // PLMN_UE
            pmKey.keyList[VCCB_PMKEY_INDEX7] = reserved6;                                                    // 5QI
            pmKey.usageOfNumKey = CI_use;
            pmKey.numKey = VCCB_PMKEY_INDEX7 + 1;
            break;
        }

        case STAT_DRB_CONN_INFO_PLMN_SNSSAI:
        {
            uint32_t gnbPlmnKey = 0;
            VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &gnbPlmnKey);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;                                               // CPC_ID, CP_ID
            pmKey.keyList[VCCB_PMKEY_INDEX2] = gnbPlmnKey;                                                   // PLMN
            pmKey.keyList[VCCB_PMKEY_INDEX3] = pGnb->globalGnbId.gnbId.id;                                   // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX4], cellIdentity, gnbNum);  // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX5] = cellIdentity;                                                 // CellIdentity
            pmKey.keyList[VCCB_PMKEY_INDEX6] = reserved5;                                                    // PLMN_UE
            pmKey.keyList[VCCB_PMKEY_INDEX7] = reserved6;                                                    // SNSSAI
            pmKey.usageOfNumKey = CI_use;
            pmKey.numKey = VCCB_PMKEY_INDEX7 + 1;
            break;
        }

        case STAT_UE_NUM_DU_ID:
        {
            uint16_t cellNum = pGnb->env.cellNum[cellIdentity];
            VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
            const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
            if (MAX_GNB_DU_PER_GNB_CU_CP <= pCell->endPointF1Index)
            {
                // Skip pegging with Invalid Du ID for periodic family.
                return;
            }
            pmKey.keyList[VCCB_PMKEY_INDEX1]= CFG->vm.unitId;                                          // CPC_ID
            pmKey.keyList[VCCB_PMKEY_INDEX2]= pGnb->globalGnbId.gnbId.id;                              // gNB_ID
            pmKey.keyList[VCCB_PMKEY_INDEX3]= GetDuId(pGnb->gnbDu[pCell->endPointF1Index].gnbDuId);    // gNB_DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4]= cellIdentity;                                            // CellIdentity
            break;
        }

        case STAT_RRC_CONN_INFO_PC1_DU_ID:
        case STAT_RRC_CONN_INFO_PC15_DU_ID:
        case STAT_RRC_CONN_INFO_PC2_DU_ID:
        {
            pmKey.keyList[VCCB_PMKEY_INDEX1]= CFG->vm.unitId;                                          // CPC_ID
            pmKey.keyList[VCCB_PMKEY_INDEX2]= pGnb->globalGnbId.gnbId.id;                              // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3], cellIdentity, gnbNum); // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4]= cellIdentity;                                            // CellIdentity
            break;
        }

        default:
            VCCB_PRINT_ERROR("Not a Stat family(%d) defined in VLIB_LibStatPmGauge!\n", mFamily);
            return;
    }

    StatisticsHandler statHandler(gnbNum);
    statHandler.changeFamilyAndIndex(ptCi, mActualFamily, pmKey);

    if ((VCOM_getSystemType() == e_VCCB_ACPF_CNF) && (isSupportedStatisticFamilyForCNF(mActualFamily) == FALSE))
    {
        return;
    }

    MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemFloatArr, pmMultiCollect.numOfItem, mActualFamily, mType,
        pmMultiCollect.updateMethod, updateValue);

    if (ptCi != NULL)
    {
        additionalType = FnVCCB_GetAdditionalTypeForPmGauge(ptCi, mFamily, mType);
        if (additionalType != -1)
        {
            VCCB_PRINT_CALL_COMMENT(
                ptCi, "Family:%d mType:%d additional Type:%d\n", mActualFamily, mType, additionalType);
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemFloatArr, pmMultiCollect.numOfItem, mActualFamily,
                additionalType, pmMultiCollect.updateMethod, updateValue);
        }
    }

    if (mActualFamily == STAT_CP_RRC_CONN_INFO_PLMN_RFSP_GLOBAL_ID)
    {
        pmKey.usageOfNumKey = CI_use;
    }

    CollectPmStatistics(
        ptCi, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemFloatArr, pmKey, shmStoreFlag);

    FnVCCB_CollectStatCSL_HOTIME(ptCi, mFamily, mType, updateValue); // SVR25B FGR-MC1009 FR610
}

/**
 * @brief     check if stat information is valid
 * @param     mFamily : stat family
 * @param     mType : stat type
 * @return    STAT_VALID : valid
 * @return    STAT_ERROR_DUPLICATE_ATTEMPT : an attempt stat has already been collected.
 * @return    STAT_ERROR_NO_ATTEMPT_MADE : A success/fail stat has been collected without an attempt stat being
 * collected.
 * @return    STAT_ERROR_WRONG_TYPE : Stat is not attempt/success/fail type stat.
 */
template <typename AttemptFlag>
int CheckAttemptStatValidity(callInfo_type *ptCi, AttemptFlag *ptAttemptFlag, int mFamily, int mType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptAttemptFlag);

    enumStatTypeClassification statType = FnVCCB_GetStatType(mFamily, mType);

    // Check if the stat is an attempt type of stat.
    if (statType == STAT_TYPE_ATTEMPT)
    {
        // if there has been no attempt, remember that an attempt has been made.
        if (*ptAttemptFlag == NO_ATTEMPT)
        {
            *ptAttemptFlag = ATTEMPT_MADE;
        }
        else
        {
            // an attempt stat has already been collected.
            return STAT_ERROR_DUPLICATE_ATTEMPT;
        }
    }
    // if stat not an attempt stat but a succ/fail stat.
    else
    {
        // There must be an attempt of the same family type for success/fail stat to be collected.
        if (*ptAttemptFlag == ATTEMPT_MADE || *ptAttemptFlag == PREP_SUCCESS_MADE)
        {
            if (statType == STAT_TYPE_PREP_SUCCESS)
            {
                // This case is not the final stat.
                // Before collecting Succ(not PrepSucc), FAIL can be happened.
                if (PREP_SUCCESS_MADE == *ptAttemptFlag)
                {
                    return STAT_ERROR_DUPLICATE_PREP_SUCCESS;
                }
                *ptAttemptFlag = PREP_SUCCESS_MADE;
            }
            else
            {
                // Decision made,no further stats of the same type may be collected for this call.
                if (*ptAttemptFlag == ATTEMPT_MADE)
                {
                    *ptAttemptFlag = SUCCESS_FAIL_DECISION_MADE;
                }
                else if (*ptAttemptFlag == PREP_SUCCESS_MADE)
                {
                    *ptAttemptFlag = SUCCESS_FAIL_DECISION_MADE_AFTER_PREP;
                }
            }
        }
        else
        {
            // A success/fail stat has been collected without an attempt stat being collected.
            return STAT_ERROR_NO_ATTEMPT_MADE;
        }
    }

    return STAT_VALID;
}

/**
 * @brief     collect VoNR statistics type for HO_IN, HO_OUT family
 * @param     ptCi : call context pointer
 * @param     mFamily : statistics family
 * @param     mActualFamily : statistics actual family
 * @param     pmType : statistics type in PM_TYPE_ID.h
 */
void FnVCCB_CollectPmccAdditionalVoNRForHoInOut(
    callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int pmType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    // VoNR UE
    if (ptCi->hoInfo.isVonrCall != TRUE) return;

    // Mismatched STAT_HO_OUT_SERVICE_TYPE from STAT_HO_OUT
    STAT_HO_OUT_TYPE_FROM_SERVICE_TYPE(mFamily, pmType);

    // Intra gNB Handover
    auto IntraGnb_HoOut_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case IntraGnbOut_Att:
            case IntraGnbOutWithNedc_Att:
            case IntraGnbOutWithNrdc_Att:
                return IntraGnbOutVoNR_Att;

            case IntraGnbOut_PrepSucc:
            case IntraGnbOutWithNedc_PrepSucc:
            case IntraGnbOutwithNrdc_PrepSucc:
                return IntraGnbOutVoNR_PrepSucc;

            case IntraGnbOut_Succ:
            case IntraGnbOutWithNedc_Succ:
            case IntraGnbOutwithNrdc_Succ:
                return IntraGnbOutVoNR_Succ;

            case IntraGnbOut_HandoverCancel:
            case IntraGnbOutWithNedc_HandoverCancel:
            case IntraGnbOutwithNrdc_HandoverCancel:
                return IntraGnbOutVoNR_HandoverCancel;

            case IntraGnbOut_RRE:
            case IntraGnbOutWithNedc_RRE:
            case IntraGnbOutwithNrdc_RRE:
                return IntraGnbOutVoNR_RRE;

            default:
                return -1;
        }
    };
    auto IntraGnb_HoIn_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case IntraGnbIn_Att:
            case IntraGnbInWithNedc_Att:
            case IntraGnbInWithNrdc_Att:
                return IntraGnbInVoNR_Att;

            case IntraGnbIn_PrepSucc:
            case IntraGnbInWithNedc_PrepSucc:
            case IntraGnbInWithNrdc_PrepSucc:
                return IntraGnbInVoNR_PrepSucc;

            case IntraGnbIn_Succ:
            case IntraGnbInWithNedc_Succ:
            case IntraGnbInWithNrdc_Succ:
                return IntraGnbInVoNR_Succ;

            case IntraGnbIn_HandoverCancel:
            case IntraGnbInWithNedc_HandoverCancel:
            case IntraGnbInWithNrdc_HandoverCancel:
                return IntraGnbInVoNR_HandoverCancel;

            case IntraGnbIn_RRE:
            case IntraGnbInWithNedc_RRE:
            case IntraGnbInWithNrdc_RRE:
                return IntraGnbInVoNR_RRE;

            default:
                return -1;
        }
    };

    // Inter gNB XN Handover
    auto InterXn_HoOut_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterXnOut_Att:
            case InterXnOutWithNedc_Att:
            case InterXnOutwithNrdc_Att:
                return InterXnOutVoNR_Att;

            case InterXnOut_PrepSucc:
            case InterXnOutWithNedc_PrepSucc:
            case InterXnOutwithNrdc_PrepSucc:
                return InterXnOutVoNR_PrepSucc;

            case InterXnOut_Succ:
            case InterXnOutWithNedc_Succ:
            case InterXnOutwithNrdc_Succ:
                return InterXnOutVoNR_Succ;

            case InterXnOut_HandoverCancel:
            case InterXnOutWithNedc_HandoverCancel:
            case InterXnOutwithNrdc_HandoverCancel:
                return InterXnOutVoNR_HandoverCancel;

            case InterXnOut_RRE:
            case InterXnOutWithNedc_RRE:
            case InterXnOutwithNrdc_RRE:
                return InterXnOutVoNR_RRE;

            default:
                return -1;
        }
    };
    auto InterXn_HoIn_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterXnIn_Att:
            case InterXnInWithNedc_Att:
            case InterXnInWithNrdc_Att:
                return InterXnInVoNR_Att;

            case InterXnIn_PrepSucc:
            case InterXnInWithNedc_PrepSucc:
            case InterXnInWithNrdc_PrepSucc:
                return InterXnInVoNR_PrepSucc;

            case InterXnIn_Succ:
            case InterXnInWithNedc_Succ:
            case InterXnInWithNrdc_Succ:
                return InterXnInVoNR_Succ;

            case InterXnIn_HandoverCancel:
            case InterXnInWithNedc_HandoverCancel:
            case InterXnInWithNrdc_HandoverCancel:
                return InterXnInVoNR_HandoverCancel;

            case InterXnIn_RRE:
            case InterXnInWithNedc_RRE:
            case InterXnInWithNrdc_RRE:
                return InterXnInVoNR_RRE;

            default:
                return -1;
        }
    };

    // Inter gNB NG Handover
    auto InterNg_HoOut_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterNgOut_Att:
            case InterNgOutWithNedc_Att:
            case InterNgOutwithNrdc_Att:
                return InterNgOutVoNR_Att;

            case InterNgOut_PrepSucc:
            case InterNgOutWithNedc_PrepSucc:
            case InterNgOutwithNrdc_PrepSucc:
                return InterNgOutVoNR_PrepSucc;

            case InterNgOut_Succ:
            case InterNgOutWithNedc_Succ:
            case InterNgOutwithNrdc_Succ:
                return InterNgOutVoNR_Succ;

            case InterNgOut_HandoverCancel:
            case InterNgOutWithNedc_HandoverCancel:
            case InterNgOutwithNrdc_HandoverCancel:
                return InterNgOutVoNR_HandoverCancel;

            case InterNgOut_RRE:
            case InterNgOutWithNedc_RRE:
            case InterNgOutwithNrdc_RRE:
                return InterNgOutVoNR_RRE;

            default:
                return -1;
        }
    };
    auto InterNg_HoIn_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterNgIn_Att:
            case InterNgInWithNedc_Att:
            case InterNgInWithNrdc_Att:
                return InterNgInVoNR_Att;

            case InterNgIn_PrepSucc:
            case InterNgInWithNedc_PrepSucc:
            case InterNgInWithNrdc_PrepSucc:
                return InterNgInVoNR_PrepSucc;

            case InterNgIn_Succ:
            case InterNgInWithNedc_Succ:
            case InterNgInWithNrdc_Succ:
                return InterNgInVoNR_Succ;

            case InterNgIn_HandoverCancel:
            case InterNgInWithNedc_HandoverCancel:
            case InterNgInWithNrdc_HandoverCancel:
                return InterNgInVoNR_HandoverCancel;

            case InterNgIn_RRE:
            case InterNgInWithNedc_RRE:
            case InterNgInWithNrdc_RRE:
                return InterNgInVoNR_RRE;

            default:
                return -1;
        }
    };

    int typeId = -1;

    switch (mFamily)
    {
        case STAT_HO_OUT:
        case STAT_HO_OUT_SERVICE_TYPE:
            if (IS_INTRA_GNB_HO())
                typeId = IntraGnb_HoOut_mapping();
            else if (IS_INTER_GNB_XN_HO())
                typeId = InterXn_HoOut_mapping();
            else if (IS_INTER_GNB_NG_HO())
                typeId = InterNg_HoOut_mapping();
            break;

        case STAT_HO_IN:
        case STAT_HO_IN_SERVICE_TYPE:
            if (IS_INTRA_GNB_HO())
                typeId = IntraGnb_HoIn_mapping();
            else if (IS_INTER_GNB_XN_HO())
                typeId = InterXn_HoIn_mapping();
            else if (IS_INTER_GNB_NG_HO())
                typeId = InterNg_HoIn_mapping();
            break;

        default:
            break;
    }

    if (typeId != -1)
    {
        // Mismatched STAT_HO_OUT_SERVICE_TYPE from STAT_HO_OUT
        STAT_SERVICE_TYPE_FROM_HO_OUT_TYPE(mFamily, typeId);

        VCCB_PRINT_CALL_COMMENT(
            ptCi, "%s mFamily:%d mActualFamily:%d VoNR Att:%d \n", __func__, mFamily, mActualFamily, typeId);
        MACRO_STAT_PMCC_ADD_ITEM(
            pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, typeId, PME_LIB_CC, 1);
    }
}

void FnVCCB_CollectPmccAdditionalVoNRForHoInRedCap(
    callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int pmType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    // VoNR UE
    if (ptCi->hoInfo.isVonrCall != TRUE) return;

    auto IntraGnb_HoIn_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case IntraGnbIn_Att_RedCap:
                return IntraGnbInVoNR_Att_RedCap;
            case IntraGnbIn_PrepSucc_RedCap:
                return IntraGnbInVoNR_PrepSucc_RedCap;
            case IntraGnbIn_Succ_RedCap:
                return IntraGnbInVoNR_Succ_RedCap;
            case IntraGnbIn_HandoverCancel_RedCap:
                return IntraGnbInVoNR_HandoverCancel_RedCap;
            case IntraGnbIn_RRE_RedCap:
                return IntraGnbInVoNR_RRE_RedCap;

            default:
                return -1;
        }
    };

    auto InterXn_HoIn_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterXnIn_Att_RedCap:
                return InterXnInVoNR_Att_RedCap;
            case InterXnIn_PrepSucc_RedCap:
                return InterXnInVoNR_PrepSucc_RedCap;
            case InterXnIn_Succ_RedCap:
                return InterXnInVoNR_Succ_RedCap;
            case InterXnIn_HandoverCancel_RedCap:
                return InterXnInVoNR_HandoverCancel_RedCap;
            case InterXnIn_RRE_RedCap:
                return InterXnInVoNR_RRE_RedCap;

            default:
                return -1;
        }
    };

    auto InterNg_HoIn_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterNgIn_Att_RedCap:
                return InterNgInVoNR_Att_RedCap;
            case InterNgIn_PrepSucc_RedCap:
                return InterNgInVoNR_PrepSucc_RedCap;
            case InterNgIn_Succ_RedCap:
                return InterNgInVoNR_Succ_RedCap;
            case InterNgIn_HandoverCancel_RedCap:
                return InterNgInVoNR_HandoverCancel_RedCap;
            case InterNgIn_RRE_RedCap:
                return InterNgInVoNR_RRE_RedCap;

            default:
                return -1;
        }
    };

    int typeId = -1;

    switch (mFamily)
    {
        case STAT_HO_IN_REDCAP:
            if (IS_INTRA_GNB_HO())
                typeId = IntraGnb_HoIn_RedCap_mapping();
            else if (IS_INTER_GNB_XN_HO())
                typeId = InterXn_HoIn_RedCap_mapping();
            else if (IS_INTER_GNB_NG_HO())
                typeId = InterNg_HoIn_RedCap_mapping();
            break;


        default:
            break;
    }

    if (typeId != -1)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "%s mFamily:%d mActualFamily:%d VoNR Att:%d \n", __func__, mFamily, mActualFamily, typeId);
        MACRO_STAT_PMCC_ADD_ITEM(
            pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, typeId, PME_LIB_CC, 1);
    }
}

/**
 * @brief Collect additional F1 failure statistics for handover events.
 *
 * This function collects additional F1 failure statistics for handover events based on the given parameters.
 * It checks if the current handover event supports VoNR and updates the PM multi-collect structure accordingly.
 *
 * @param[in] ptCi Pointer to the call information structure.
 * @param[in,out] pPmMultiCollect Pointer to the PM multi-collect structure.
 * @param[in] mFamily Measurement family identifier.
 * @param[in] mActualFamily Actual measurement family identifier.
 */
void FnVCCB_CollectPmccAdditionalHoF1FailStat(
    callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    if (mFamily != STAT_HO_IN && mFamily != STAT_HO_IN_SERVICE_TYPE) return;
    if (ptCi->hoInfo.notSupportedVonr != TRUE) return; // F1 Fail: Not supported QCI valud for 5QI(1)

    auto HandIn_F1Fail_mapping = [&ptCi]() -> int
    {
        switch (ptCi->hoInfo.hoType.initiated)
        {
            case HO_TYPE_SA_INTRA_GNB_INTER_DU_HANDOVER: // SVR25A FGR-MC1008 FR580
            case HO_TYPE_SA_INTRA_GNB_INTRA_DU_HANDOVER:
                return IntraGnbIn_F1Fail_NotSupport_5QI1;

            case HO_TYPE_SA_INTER_GNB_NG_HANDOVER:
                return InterNgIn_F1Fail_NotSupport_5QI1; // SVR25A FGR-MC1009 FR580

            case HO_TYPE_SA_INTER_GNB_XN_HANDOVER:
                return InterXnIn_F1Fail_NotSupport_5QI1; // SVR25A FGR-MC1010 FR580

            default:
                return -1;
        }
    };

    int typeId = HandIn_F1Fail_mapping();

    if (typeId != -1)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "%s mFamily:%d mActualFamily:%d typeId:%d \n", __func__, mFamily, mActualFamily, typeId);
        MACRO_STAT_PMCC_ADD_ITEM(
            pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, typeId, PME_LIB_CC, 1);
    }
}

void FnVCCB_CollectPmccAdditionalSliceRejectStat(
    callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    if (not (mFamily == STAT_HO_IN || mFamily == STAT_HO_IN_REDCAP
          || mFamily == STAT_HO_EUTRAN_IN || mFamily == STAT_HO_EUTRAN_IN_REDCAP
          || mFamily == STAT_HO_IN_SERVICE_TYPE))
    {
        return;
    }

    if (ptCi->hoInfo.sliceRejectionStats != TRUE) return; // TRUE: E1/F1 fail cause is Not Available For The Slice

    auto handIn_SliceReject_mapping = [](uint8_t initiatedHoType) -> int
    {
        switch (initiatedHoType)
        {
            case HO_TYPE_SA_INTRA_GNB_INTER_DU_HANDOVER:
            case HO_TYPE_SA_INTRA_GNB_INTRA_DU_HANDOVER:
                return IntraGnbIn_SliceReject;  // SVR25B FGR-MC1021:FR210

            case HO_TYPE_SA_INTER_GNB_NG_HANDOVER:
                return InterNgIn_SliceReject;  // SVR25B FGR-MC1021:FR210

            case HO_TYPE_SA_INTER_GNB_XN_HANDOVER:
                return InterXnIn_SliceReject;  // SVR25B FGR-MC1021:FR210

            case HO_TYPE_SA_INTER_SYSTEM_INTER_RAT_HANDOVER:
                return InterSysLTE_In_SliceReject;  //SVR25B FGR-MC1021:FR220

            default:
                return -1;
        }
    };

    auto handIn_RedCap_SliceReject_mapping = [](uint8_t initiatedHoType) -> int
    {
        switch (initiatedHoType)
        {
            case HO_TYPE_SA_INTRA_GNB_INTER_DU_HANDOVER:
            case HO_TYPE_SA_INTRA_GNB_INTRA_DU_HANDOVER:
                return IntraGnbIn_SliceReject_RedCap;  // SVR25B FGR-MC1021:FR210

            case HO_TYPE_SA_INTER_GNB_NG_HANDOVER:
                return InterNgIn_SliceReject_RedCap;  // SVR25B FGR-MC1021:FR210

            case HO_TYPE_SA_INTER_GNB_XN_HANDOVER:
                return InterXnIn_SliceReject_RedCap;  // SVR25B FGR-MC1021:FR210

            case HO_TYPE_SA_INTER_SYSTEM_INTER_RAT_HANDOVER:
                return InterSysLTE_In_SliceReject_RedCap;  //SVR25B FGR-MC1021:FR220

            default:
                return -1;
        }
    };

    int typeId = -1;
    if (mFamily == STAT_HO_IN_REDCAP || mFamily == STAT_HO_EUTRAN_IN_REDCAP)
        typeId = handIn_RedCap_SliceReject_mapping(ptCi->hoInfo.hoType.initiated);
    else
        typeId = handIn_SliceReject_mapping(ptCi->hoInfo.hoType.initiated);

    if (typeId != -1)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "%s mFamily:%d mActualFamily:%d typeId:%d \n", __func__, mFamily, mActualFamily, typeId);
        MACRO_STAT_PMCC_ADD_ITEM(
            pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, typeId, PME_LIB_CC, 1);
    }
}

void FnVCCB_CollectAdditionalInterGnbHoAttFromFreq(callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect,
    int mFamily, int mActualFamily, uint32_t tgtSsbFreq, int pmType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    // Collected only for Inter GNB HO
    if (!IS_INTER_GNB_HO()) return;

    // Frequency based
    switch (mFamily)
    {
        case STAT_HO_INTER_FREQ_OUT:
        case STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE:
        case STAT_HO_INTRA_FREQ_OUT:
        case STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE:
            break;
        default:
            return;
    }

    // HO_INTRA_FREQ_OUT
    auto IntraFreq_XnHoOut_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case IntraFreqOut_Att:
                return IntraFreqXnHoOut_Att;
            case IntraFreqOut_PrepSucc:
                return IntraFreqXnHoOut_PrepSucc;
            case IntraFreqOut_Succ:
                return IntraFreqXnHoOut_Succ;
            case IntraFreqOut_HandoverCancel:
                return IntraFreqXnHoOut_HandoverCancel;
            case IntraFreqOut_RRE:
                return IntraFreqXnHoOut_RRE;

            default:
                return -1;
        }
    };
    auto IntraFreq_NgHoOut_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case IntraFreqOut_Att:
                return IntraFreqNgHoOut_Att;
            case IntraFreqOut_PrepSucc:
                return IntraFreqNgHoOut_PrepSucc;
            case IntraFreqOut_Succ:
                return IntraFreqNgHoOut_Succ;
            case IntraFreqOut_HandoverCancel:
                return IntraFreqNgHoOut_HandoverCancel;
            case IntraFreqOut_RRE:
                return IntraFreqNgHoOut_RRE;

            default:
                return -1;
        }
    };

    // HO_INTER_FREQ_OUT
    auto InterFreq_XnHoOut_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithGap_Att:
                return InterFreqXnHoOutWithGap_Att;
            case InterFreqOutWithGap_PrepSucc:
                return InterFreqXnHoOutWithGap_PrepSucc;
            case InterFreqOutWithGap_Succ:
                return InterFreqXnHoOutWithGap_Succ;
            case InterFreqOutWithGap_HandoverCancel:
                return InterFreqXnHoOutWithGap_HandoverCancel;
            case InterFreqOutWithGap_RRE:
                return InterFreqXnHoOutWithGap_RRE;

            default:
                return -1;
        }
    };
    auto InterFreq_XnHoOut_WithoutGap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithoutGap_Att:
                return InterFreqXnHoOutWithoutGap_Att;
            case InterFreqOutWithoutGap_PrepSucc:
                return InterFreqXnHoOutWithoutGap_PrepSucc;
            case InterFreqOutWithoutGap_Succ:
                return InterFreqXnHoOutWithoutGap_Succ;
            case InterFreqOutWithoutGap_HandoverCancel:
                return InterFreqXnHoOutWithoutGap_HandoverCancel;
            case InterFreqOutWithoutGap_RRE:
                return InterFreqXnHoOutWithoutGap_RRE;

            default:
                return -1;
        }
    };
    auto InterFreq_NgHoOut_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithGap_Att:
                return InterFreqNgHoOutWithGap_Att;
            case InterFreqOutWithGap_PrepSucc:
                return InterFreqNgHoOutWithGap_PrepSucc;
            case InterFreqOutWithGap_Succ:
                return InterFreqNgHoOutWithGap_Succ;
            case InterFreqOutWithGap_HandoverCancel:
                return InterFreqNgHoOutWithGap_HandoverCancel;
            case InterFreqOutWithGap_RRE:
                return InterFreqNgHoOutWithGap_RRE;

            default:
                return -1;
        }
    };
    auto InterFreq_NgHoOut_WithoutGap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithoutGap_Att:
                return InterFreqNgHoOutWithoutGap_Att;
            case InterFreqOutWithoutGap_PrepSucc:
                return InterFreqNgHoOutWithoutGap_PrepSucc;
            case InterFreqOutWithoutGap_Succ:
                return InterFreqNgHoOutWithoutGap_Succ;
            case InterFreqOutWithoutGap_HandoverCancel:
                return InterFreqNgHoOutWithoutGap_HandoverCancel;
            case InterFreqOutWithoutGap_RRE:
                return InterFreqNgHoOutWithoutGap_RRE;

            default:
                return -1;
        }
    };


    int typeId = -1;

    if (STAT_HO_INTER_FREQ_OUT == mFamily || STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE == mFamily)
    {
        if (IS_IF_HO_WITH_MGAP(ptCi, tgtSsbFreq))
        {
            if (IS_INTER_GNB_NG_HO())
                typeId = InterFreq_NgHoOut_mapping();
            else  // IS_INTER_GNB_XN_HO()
                typeId = InterFreq_XnHoOut_mapping();
        }
        else
        {
            if (IS_INTER_GNB_NG_HO())
                typeId = InterFreq_NgHoOut_WithoutGap_mapping();
            else  // IS_INTER_GNB_XN_HO()
                typeId = InterFreq_XnHoOut_WithoutGap_mapping();
        }
    }
    else // STAT_HO_INTRA_FREQ_OUT, STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE
    {
        if (IS_INTER_GNB_NG_HO())
            typeId = IntraFreq_NgHoOut_mapping();
        else  // IS_INTER_GNB_XN_HO()
            typeId = IntraFreq_XnHoOut_mapping();
    }

#ifdef IPC_TEST
    VCCB_PRINT_CALL_ERROR(ptCi, "%s mFamily:%d mActualFamily:%d tgtSsbFreq:%u typeId:%d \n", __func__, mFamily,
        mActualFamily, ptCi->hoInfo.tgtSsbFreq, typeId);
#endif

    if (typeId != -1)
    {
        VCCB_PRINT_CALL_COMMENT(
                ptCi, "%s mFamily:%d mActualFamily:%d tgtSsbFreq:%u typeId:%d \n",
                __func__, mFamily, mActualFamily, tgtSsbFreq, typeId);
        MACRO_STAT_PMCC_ADD_ITEM(
                pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, typeId, PME_LIB_CC, 1);
    }
}


void FnVCCB_CollectAdditionalInterGnbHoAttFromFreqRedCap(callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect,
    int mFamily, int mActualFamily, uint32_t tgtSsbFreq, int pmType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    // Collected only for Inter GNB HO
    if (!IS_INTER_GNB_HO()) return;

    // Frequency based
    if (STAT_HO_INTER_FREQ_OUT_REDCAP != mFamily && STAT_HO_INTRA_FREQ_OUT_REDCAP != mFamily)
        return;

    auto IntraFreq_XnHoOutRedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case IntraFreqOut_Att_RedCap:
                return IntraFreqXnHoOut_Att_RedCap;
            case IntraFreqOut_PrepSucc_RedCap:
                return IntraFreqXnHoOut_PrepSucc_RedCap;
            case IntraFreqOut_Succ_RedCap:
                return IntraFreqXnHoOut_Succ_RedCap;
            case IntraFreqOut_HandoverCancel_RedCap:
                return IntraFreqXnHoOut_HandoverCancel_RedCap;
            case IntraFreqOut_RRE_RedCap:
                return IntraFreqXnHoOut_RRE_RedCap;

            default:
                return -1;
        }
    };

    auto IntraFreq_NgHoOutRedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case IntraFreqOut_Att_RedCap:
                return IntraFreqNgHoOut_Att_RedCap;
            case IntraFreqOut_PrepSucc_RedCap:
                return IntraFreqNgHoOut_PrepSucc_RedCap;
            case IntraFreqOut_Succ_RedCap:
                return IntraFreqNgHoOut_Succ_RedCap;
            case IntraFreqOut_HandoverCancel_RedCap:
                return IntraFreqNgHoOut_HandoverCancel_RedCap;
            case IntraFreqOut_RRE_RedCap:
                return IntraFreqNgHoOut_RRE_RedCap;

            default:
                return -1;
        }
    };

    auto InterFreq_XnHoOutRedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithGap_Att_RedCap:
                return InterFreqXnHoOutWithGap_Att_RedCap;
            case InterFreqOutWithGap_PrepSucc_RedCap:
                return InterFreqXnHoOutWithGap_PrepSucc_RedCap;
            case InterFreqOutWithGap_Succ_RedCap:
                return InterFreqXnHoOutWithGap_Succ_RedCap;
            case InterFreqOutWithGap_HandoverCancel_RedCap:
                return InterFreqXnHoOutWithGap_HandoverCancel_RedCap;
            case InterFreqOutWithGap_RRE_RedCap:
                return InterFreqXnHoOutWithGap_RRE_RedCap;

            default:
                return -1;
        }
    };

    auto InterFreq_XnHoOut_WithoutGapRedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithoutGap_Att_RedCap:
                return InterFreqXnHoOutWithoutGap_Att_RedCap;
            case InterFreqOutWithoutGap_PrepSucc_RedCap:
                return InterFreqXnHoOutWithoutGap_PrepSucc_RedCap;
            case InterFreqOutWithoutGap_Succ_RedCap:
                return InterFreqXnHoOutWithoutGap_Succ_RedCap;
            case InterFreqOutWithoutGap_HandoverCancel_RedCap:
                return InterFreqXnHoOutWithoutGap_HandoverCancel_RedCap;
            case InterFreqOutWithoutGap_RRE_RedCap:
                return InterFreqXnHoOutWithoutGap_RRE_RedCap;

            default:
                return -1;
        }
    };

    auto InterFreq_NgHoOutRedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithGap_Att_RedCap:
                return InterFreqNgHoOutWithGap_Att_RedCap;
            case InterFreqOutWithGap_PrepSucc_RedCap:
                return InterFreqNgHoOutWithGap_PrepSucc_RedCap;
            case InterFreqOutWithGap_Succ_RedCap:
                return InterFreqNgHoOutWithGap_Succ_RedCap;
            case InterFreqOutWithGap_HandoverCancel_RedCap:
                return InterFreqNgHoOutWithGap_HandoverCancel_RedCap;
            case InterFreqOutWithGap_RRE_RedCap:
                return InterFreqNgHoOutWithGap_RRE_RedCap;

            default:
                return -1;
        }
    };

    auto InterFreq_NgHoOut_WithoutGapRedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithoutGap_Att_RedCap:
                return InterFreqNgHoOutWithoutGap_Att_RedCap;
            case InterFreqOutWithoutGap_PrepSucc_RedCap:
                return InterFreqNgHoOutWithoutGap_PrepSucc_RedCap;
            case InterFreqOutWithoutGap_Succ_RedCap:
                return InterFreqNgHoOutWithoutGap_Succ_RedCap;
            case InterFreqOutWithoutGap_HandoverCancel_RedCap:
                return InterFreqNgHoOutWithoutGap_HandoverCancel_RedCap;
            case InterFreqOutWithoutGap_RRE_RedCap:
                return InterFreqNgHoOutWithoutGap_RRE_RedCap;

            default:
                return -1;
        }
    };

    int typeId = -1;

    if (STAT_HO_INTER_FREQ_OUT_REDCAP == mFamily)
    {
        if (IS_IF_HO_WITH_MGAP(ptCi, tgtSsbFreq))
        {
            if (IS_INTER_GNB_NG_HO())
                typeId = InterFreq_NgHoOutRedCap_mapping();
            else  // IS_INTER_GNB_XN_HO()
                typeId = InterFreq_XnHoOutRedCap_mapping();
        }
        else
        {
            if (IS_INTER_GNB_NG_HO())
                typeId = InterFreq_NgHoOut_WithoutGapRedCap_mapping();
            else  // IS_INTER_GNB_XN_HO()
                typeId = InterFreq_XnHoOut_WithoutGapRedCap_mapping();
        }
    }
    else if (STAT_HO_INTRA_FREQ_OUT_REDCAP == mFamily)
    {
        if (IS_INTER_GNB_NG_HO())
            typeId = IntraFreq_NgHoOutRedCap_mapping();
        else  // IS_INTER_GNB_XN_HO()
            typeId = IntraFreq_XnHoOutRedCap_mapping();
    }

#ifdef IPC_TEST
    VCCB_PRINT_CALL_ERROR(ptCi, "%s mFamily:%d mActualFamily:%d tgtSsbFreq:%u typeId:%d \n", __func__, mFamily,
        mActualFamily, ptCi->hoInfo.tgtSsbFreq, typeId);
#endif

    if (typeId != -1)
    {
        VCCB_PRINT_CALL_COMMENT(
                ptCi, "%s mFamily:%d mActualFamily:%d tgtSsbFreq:%u typeId:%d \n",
                __func__, mFamily, mActualFamily, tgtSsbFreq, typeId);
        MACRO_STAT_PMCC_ADD_ITEM(
                pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, typeId, PME_LIB_CC, 1);
    }
}

void FnVCCB_CollectAdditionalVoNRAttFromFreq(callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily,
    int mActualFamily, uint32_t tgtSsbFreq, int pmType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    // VoNR only
    if (TRUE != ptCi->hoInfo.isVonrCall) return;

    // Frequency based
    switch (mFamily)
    {
        case STAT_HO_INTER_FREQ_OUT:
        case STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE:
        case STAT_HO_INTRA_FREQ_OUT:
        case STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE:
            break;
        default:
            return;
    }

    // HO_INTER_FREQ_OUT
    auto InterFreq_Out_WithGap_VoNR_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithGap_Att:
                return InterFreqOutWithGapVoNR_Att;
            case InterFreqOutWithGap_PrepSucc:
                return InterFreqOutWithGapVoNR_PrepSucc;
            case InterFreqOutWithGap_Succ:
                return InterFreqOutWithGapVoNR_Succ;
            case InterFreqOutWithGap_HandoverCancel:
                return InterFreqOutWithGapVoNR_HandoverCancel;
            case InterFreqOutWithGap_RRE:
                return InterFreqOutWithGapVoNR_RRE;

            default:
                return -1;
        }
    };
    auto InterFreq_Out_WithoutGap_VoNR_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithoutGap_Att:
                return InterFreqOutwithOutGapVoNR_Att;
            case InterFreqOutWithoutGap_PrepSucc:
                return InterFreqOutwithOutGapVoNR_PrepSucc;
            case InterFreqOutWithoutGap_Succ:
                return InterFreqOutwithOutGapVoNR_Succ;
            case InterFreqOutWithoutGap_HandoverCancel:
                return InterFreqOutWithoutGapVoNR_HandoverCancel;
            case InterFreqOutWithoutGap_RRE:
                return InterFreqOutWithoutGapVoNR_RRE;

            default:
                return -1;
        }
    };
    auto InterFreq_XnHoOut_WithGap_VoNR_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithGap_Att:
                return InterFreqXnHoOutWithGap_VoNR_Att;
            case InterFreqOutWithGap_PrepSucc:
                return InterFreqXnHoOutWithGap_VoNR_PrepSucc;
            case InterFreqOutWithGap_Succ:
                return InterFreqXnHoOutWithGap_VoNR_Succ;
            case InterFreqOutWithGap_HandoverCancel:
                return InterFreqXnHoOutWithGap_VoNR_HandoverCancel;
            case InterFreqOutWithGap_RRE:
                return InterFreqXnHoOutWithGap_VoNR_RRE;

            default:
                return -1;
        }
    };
    auto InterFreq_XnHoOut_WithoutGap_VoNR_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithoutGap_Att:
                return InterFreqXnHoOutWithoutGap_VoNR_Att;
            case InterFreqOutWithoutGap_PrepSucc:
                return InterFreqXnHoOutWithoutGap_VoNR_PrepSucc;
            case InterFreqOutWithoutGap_Succ:
                return InterFreqXnHoOutWithoutGap_VoNR_Succ;
            case InterFreqOutWithoutGap_HandoverCancel:
                return InterFreqXnHoOutWithoutGap_VoNR_HandoverCancel;
            case InterFreqOutWithoutGap_RRE:
                return InterFreqXnHoOutWithoutGap_VoNR_RRE;

            default:
                return -1;
        }
    };
    auto InterFreq_NgHoOut_WithGap_VoNR_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithGap_Att:
                return InterFreqNgHoOutWithGap_VoNR_Att;
            case InterFreqOutWithGap_PrepSucc:
                return InterFreqNgHoOutWithGap_VoNR_PrepSucc;
            case InterFreqOutWithGap_Succ:
                return InterFreqNgHoOutWithGap_VoNR_Succ;
            case InterFreqOutWithGap_HandoverCancel:
                return InterFreqNgHoOutWithGap_VoNR_HandoverCancel;
            case InterFreqOutWithGap_RRE:
                return InterFreqNgHoOutWithGap_VoNR_RRE;

            default:
                return -1;
        }
    };
    auto InterFreq_NgHoOut_WithoutGap_VoNR_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithoutGap_Att:
                return InterFreqNgHoOutWithoutGap_VoNR_Att;
            case InterFreqOutWithoutGap_PrepSucc:
                return InterFreqNgHoOutWithoutGap_VoNR_PrepSucc;
            case InterFreqOutWithoutGap_Succ:
                return InterFreqNgHoOutWithoutGap_VoNR_Succ;
            case InterFreqOutWithoutGap_HandoverCancel:
                return InterFreqNgHoOutWithoutGap_VoNR_HandoverCancel;
            case InterFreqOutWithoutGap_RRE:
                return InterFreqNgHoOutWithoutGap_VoNR_RRE;

            default:
                return -1;
        }
    };

    // HO_INTRA_FREQ_OUT
    auto IntraFreq_Out_VoNR_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case IntraFreqOut_Att:
                return IntraFreqOutVoNR_Att;
            case IntraFreqOut_PrepSucc:
                return IntraFreqOutVoNR_PrepSucc;
            case IntraFreqOut_Succ:
                return IntraFreqOutVoNR_Succ;
            case IntraFreqOut_HandoverCancel:
                return IntraFreqOutVoNR_HandoverCancel;
            case IntraFreqOut_RRE:
                return IntraFreqOutVoNR_RRE;

            default:
                return -1;
        }
    };
    auto IntraFreq_XnHoOut_VoNR_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case IntraFreqOut_Att:
                return IntraFreqXnHoOutVoNR_Att;
            case IntraFreqOut_PrepSucc:
                return IntraFreqXnHoOutVoNR_PrepSucc;
            case IntraFreqOut_Succ:
                return IntraFreqXnHoOutVoNR_Succ;
            case IntraFreqOut_HandoverCancel:
                return IntraFreqXnHoOutVoNR_HandoverCancel;
            case IntraFreqOut_RRE:
                return IntraFreqXnHoOutVoNR_RRE;

            default:
                return -1;
        }
    };
    auto IntraFreq_NgHoOut_VoNR_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case IntraFreqOut_Att:
                return IntraFreqNgHoOutVoNR_Att;
            case IntraFreqOut_PrepSucc:
                return IntraFreqNgHoOutVoNR_PrepSucc;
            case IntraFreqOut_Succ:
                return IntraFreqNgHoOutVoNR_Succ;
            case IntraFreqOut_HandoverCancel:
                return IntraFreqNgHoOutVoNR_HandoverCancel;
            case IntraFreqOut_RRE:
                return IntraFreqNgHoOutVoNR_RRE;

            default:
                return -1;
        }
    };

    int typeId = -1, interGnbTypeId = -1;

    if (STAT_HO_INTER_FREQ_OUT == mFamily || STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE == mFamily)
    {
        if (IS_IF_HO_WITH_MGAP(ptCi, tgtSsbFreq))
        {
            typeId = InterFreq_Out_WithGap_VoNR_mapping();

            if (IS_INTER_GNB_NG_HO()) // NR_CONN_MC_23B
            {
                interGnbTypeId = InterFreq_NgHoOut_WithGap_VoNR_mapping();
            }
            else if (IS_INTER_GNB_XN_HO())
            {
                interGnbTypeId = InterFreq_XnHoOut_WithGap_VoNR_mapping();
            }
        }
        else
        {
            typeId = InterFreq_Out_WithoutGap_VoNR_mapping();

            if (IS_INTER_GNB_NG_HO()) // NR_CONN_MC_23B
            {
                interGnbTypeId = InterFreq_NgHoOut_WithoutGap_VoNR_mapping();
            }
            else if (IS_INTER_GNB_XN_HO())
            {
                interGnbTypeId = InterFreq_XnHoOut_WithoutGap_VoNR_mapping();
            }
        }
    }
    else // STAT_HO_INTRA_FREQ_OUT, STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE
    {
        typeId = IntraFreq_Out_VoNR_mapping();

        if (IS_INTER_GNB_NG_HO()) // NR_CONN_MC_23B
        {
            interGnbTypeId = IntraFreq_NgHoOut_VoNR_mapping();
        }
        else if (IS_INTER_GNB_XN_HO())
        {
            interGnbTypeId = IntraFreq_XnHoOut_VoNR_mapping();
        }
    }

#ifdef IPC_TEST
    VCCB_PRINT_CALL_ERROR(ptCi, "%s mFamily:%d mActualFamily:%d tgtSsbFreq:%u typeId:%d interGnbTypeId:%d \n",
            __func__, mFamily, mActualFamily, ptCi->hoInfo.tgtSsbFreq, typeId, interGnbTypeId);
#endif

    // InterFreqOut or IntraFreqOutVoNR
    if (typeId != -1)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "%s mFamily:%d mActualFamily:%d tgtSsbFreq:%u typeId:%d \n",
            __func__, mFamily, mActualFamily, tgtSsbFreq, typeId);
        MACRO_STAT_PMCC_ADD_ITEM(
            pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, typeId, PME_LIB_CC, 1);
    }

    // InterFreqXnHo or InterFreqNgHo or IntraFreqXnHo or IntraFreqNgHo // NR_CONN_MC_23B
    if (interGnbTypeId != -1)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "%s mFamily:%d mActualFamily:%d interGnbTypeId:%d \n", __func__, mFamily, mActualFamily, interGnbTypeId);
        MACRO_STAT_PMCC_ADD_ITEM(
            pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, interGnbTypeId, PME_LIB_CC, 1);
    }
}

void FnVCCB_CollectAdditionalVoNRAttFromFreqRedCap(callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily,
    int mActualFamily, uint32_t tgtSsbFreq, int pmType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    // Frequency based
    if (STAT_HO_INTER_FREQ_OUT_REDCAP != mFamily && STAT_HO_INTRA_FREQ_OUT_REDCAP != mFamily)
        return;

    // VoNR only
    if (TRUE != ptCi->hoInfo.isVonrCall) return;

    auto InterFreq_Out_WithGap_VoNR_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithGap_Att_RedCap:
                return InterFreqOutWithGapVoNR_Att_RedCap;
            case InterFreqOutWithGap_PrepSucc_RedCap:
                return InterFreqOutWithGapVoNR_PrepSucc_RedCap;
            case InterFreqOutWithGap_Succ_RedCap:
                return InterFreqOutWithGapVoNR_Succ_RedCap;
            case InterFreqOutWithGap_HandoverCancel_RedCap:
                return InterFreqOutWithGapVoNR_HandoverCancel_RedCap;
            case InterFreqOutWithGap_RRE_RedCap:
                return InterFreqOutWithGapVoNR_RRE_RedCap;

            default:
                return -1;
        }
    };

    auto InterFreq_Out_WithoutGap_VoNR_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithoutGap_Att_RedCap:
                return InterFreqOutwithOutGapVoNR_Att_RedCap;
            case InterFreqOutWithoutGap_PrepSucc_RedCap:
                return InterFreqOutwithOutGapVoNR_PrepSucc_RedCap;
            case InterFreqOutWithoutGap_Succ_RedCap:
                return InterFreqOutwithOutGapVoNR_Succ_RedCap;
            case InterFreqOutWithoutGap_HandoverCancel_RedCap:
                return InterFreqOutWithoutGapVoNR_HandoverCancel_RedCap;
            case InterFreqOutWithoutGap_RRE_RedCap:
                return InterFreqOutWithoutGapVoNR_RRE_RedCap;

            default:
                return -1;
        }
    };

    auto InterFreq_XnHoOut_WithGap_VoNR_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithGap_Att_RedCap:
                return InterFreqXnHoOutWithGap_VoNR_Att_RedCap;
            case InterFreqOutWithGap_PrepSucc_RedCap:
                return InterFreqXnHoOutWithGap_VoNR_PrepSucc_RedCap;
            case InterFreqOutWithGap_Succ_RedCap:
                return InterFreqXnHoOutWithGap_VoNR_Succ_RedCap;
            case InterFreqOutWithGap_HandoverCancel_RedCap:
                return InterFreqXnHoOutWithGap_VoNR_HandoverCancel_RedCap;
            case InterFreqOutWithGap_RRE_RedCap:
                return InterFreqXnHoOutWithGap_VoNR_RRE_RedCap;

            default:
                return -1;
        }
    };

    auto InterFreq_XnHoOut_WithoutGap_VoNR_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithoutGap_Att_RedCap:
                return InterFreqXnHoOutWithoutGap_VoNR_Att_RedCap;
            case InterFreqOutWithoutGap_PrepSucc_RedCap:
                return InterFreqXnHoOutWithoutGap_VoNR_PrepSucc_RedCap;
            case InterFreqOutWithoutGap_Succ_RedCap:
                return InterFreqXnHoOutWithoutGap_VoNR_Succ_RedCap;
            case InterFreqOutWithoutGap_HandoverCancel_RedCap:
                return InterFreqXnHoOutWithoutGap_VoNR_HandoverCancel_RedCap;
            case InterFreqOutWithoutGap_RRE_RedCap:
                return InterFreqXnHoOutWithoutGap_VoNR_RRE_RedCap;

            default:
                return -1;
        }
    };

    auto InterFreq_NgHoOut_WithGap_VoNR_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithGap_Att_RedCap:
                return InterFreqNgHoOutWithGap_VoNR_Att_RedCap;
            case InterFreqOutWithGap_PrepSucc_RedCap:
                return InterFreqNgHoOutWithGap_VoNR_PrepSucc_RedCap;
            case InterFreqOutWithGap_Succ_RedCap:
                return InterFreqNgHoOutWithGap_VoNR_Succ_RedCap;
            case InterFreqOutWithGap_HandoverCancel_RedCap:
                return InterFreqNgHoOutWithGap_VoNR_HandoverCancel_RedCap;
            case InterFreqOutWithGap_RRE_RedCap:
                return InterFreqNgHoOutWithGap_VoNR_RRE_RedCap;

            default:
                return -1;
        }
    };

    auto InterFreq_NgHoOut_WithoutGap_VoNR_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithoutGap_Att_RedCap:
                return InterFreqNgHoOutWithoutGap_VoNR_Att_RedCap;
            case InterFreqOutWithoutGap_PrepSucc_RedCap:
                return InterFreqNgHoOutWithoutGap_VoNR_PrepSucc_RedCap;
            case InterFreqOutWithoutGap_Succ_RedCap:
                return InterFreqNgHoOutWithoutGap_VoNR_Succ_RedCap;
            case InterFreqOutWithoutGap_HandoverCancel_RedCap:
                return InterFreqNgHoOutWithoutGap_VoNR_HandoverCancel_RedCap;
            case InterFreqOutWithoutGap_RRE_RedCap:
                return InterFreqNgHoOutWithoutGap_VoNR_RRE_RedCap;

            default:
                return -1;
        }
    };

    auto IntraFreq_Out_VoNR_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case IntraFreqOut_Att_RedCap:
                return IntraFreqOutVoNR_Att_RedCap;
            case IntraFreqOut_PrepSucc_RedCap:
                return IntraFreqOutVoNR_PrepSucc_RedCap;
            case IntraFreqOut_Succ_RedCap:
                return IntraFreqOutVoNR_Succ_RedCap;
            case IntraFreqOut_HandoverCancel_RedCap:
                return IntraFreqOutVoNR_HandoverCancel_RedCap;
            case IntraFreqOut_RRE_RedCap:
                return IntraFreqOutVoNR_RRE_RedCap;

            default:
                return -1;
        }
    };

    auto IntraFreq_XnHoOut_VoNR_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case IntraFreqOut_Att_RedCap:
                return IntraFreqXnHoOutVoNR_Att_RedCap;
            case IntraFreqOut_PrepSucc_RedCap:
                return IntraFreqXnHoOutVoNR_PrepSucc_RedCap;
            case IntraFreqOut_Succ_RedCap:
                return IntraFreqXnHoOutVoNR_Succ_RedCap;
            case IntraFreqOut_HandoverCancel_RedCap:
                return IntraFreqXnHoOutVoNR_HandoverCancel_RedCap;
            case IntraFreqOut_RRE_RedCap:
                return IntraFreqXnHoOutVoNR_RRE_RedCap;

            default:
                return -1;
        }
    };

    auto IntraFreq_NgHoOut_VoNR_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case IntraFreqOut_Att_RedCap:
                return IntraFreqNgHoOutVoNR_Att_RedCap;
            case IntraFreqOut_PrepSucc_RedCap:
                return IntraFreqNgHoOutVoNR_PrepSucc_RedCap;
            case IntraFreqOut_Succ_RedCap:
                return IntraFreqNgHoOutVoNR_Succ_RedCap;
            case IntraFreqOut_HandoverCancel_RedCap:
                return IntraFreqNgHoOutVoNR_HandoverCancel_RedCap;
            case IntraFreqOut_RRE_RedCap:
                return IntraFreqNgHoOutVoNR_RRE_RedCap;

            default:
                return -1;
        }
    };

    int typeId = -1, interGnbTypeId = -1;

    if (STAT_HO_INTER_FREQ_OUT_REDCAP == mFamily)
    {
        if (IS_IF_HO_WITH_MGAP(ptCi, tgtSsbFreq))
        {
            typeId = InterFreq_Out_WithGap_VoNR_RedCap_mapping();

            if (IS_INTER_GNB_NG_HO()) // NR_CONN_MC_23B
            {
                interGnbTypeId = InterFreq_NgHoOut_WithGap_VoNR_RedCap_mapping();
            }
            else if (IS_INTER_GNB_XN_HO())
            {
                interGnbTypeId = InterFreq_XnHoOut_WithGap_VoNR_RedCap_mapping();
            }
        }
        else
        {
            typeId = InterFreq_Out_WithoutGap_VoNR_RedCap_mapping();

            if (IS_INTER_GNB_NG_HO()) // NR_CONN_MC_23B
            {
                interGnbTypeId = InterFreq_NgHoOut_WithoutGap_VoNR_RedCap_mapping();
            }
            else if (IS_INTER_GNB_XN_HO())
            {
                interGnbTypeId = InterFreq_XnHoOut_WithoutGap_VoNR_RedCap_mapping();
            }
        }
    }
    else if (STAT_HO_INTRA_FREQ_OUT_REDCAP == mFamily)
    {
        typeId = IntraFreq_Out_VoNR_RedCap_mapping();

        if (IS_INTER_GNB_NG_HO()) // NR_CONN_MC_23B
        {
            interGnbTypeId = IntraFreq_NgHoOut_VoNR_RedCap_mapping();
        }
        else if (IS_INTER_GNB_XN_HO())
        {
            interGnbTypeId = IntraFreq_XnHoOut_VoNR_RedCap_mapping();
        }
    }

#ifdef IPC_TEST
    VCCB_PRINT_CALL_ERROR(ptCi, "%s mFamily:%d mActualFamily:%d tgtSsbFreq:%u typeId:%d interGnbTypeId:%d \n",
            __func__, mFamily, mActualFamily, ptCi->hoInfo.tgtSsbFreq, typeId, interGnbTypeId);
#endif

    // InterFreqOut or IntraFreqOutVoNR
    if (typeId != -1)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "%s mFamily:%d mActualFamily:%d tgtSsbFreq:%u typeId:%d \n",
            __func__, mFamily, mActualFamily, tgtSsbFreq, typeId);
        MACRO_STAT_PMCC_ADD_ITEM(
            pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, typeId, PME_LIB_CC, 1);
    }

    // InterFreqXnHo or InterFreqNgHo or IntraFreqXnHo or IntraFreqNgHo // NR_CONN_MC_23B
    if (interGnbTypeId != -1)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "%s mFamily:%d mActualFamily:%d interGnbTypeId:%d \n", __func__, mFamily, mActualFamily, interGnbTypeId);
        MACRO_STAT_PMCC_ADD_ITEM(
            pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, interGnbTypeId, PME_LIB_CC, 1);
    }
}

void FnVCCB_CollectAdditionalNonNeighborAttFromFreq(callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect,
    int mFamily, int mActualFamily, uint32_t tgtSsbFreq, int pmType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    // Check Handover to NR Small Cell
    if (TRUE != ptCi->hoInfo.nonNbrCell) return;

    // Frequency based
    switch (mFamily)
    {
        case STAT_HO_INTER_FREQ_OUT:
        case STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE:
        case STAT_HO_INTRA_FREQ_OUT:
        case STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE:
            break;
        default:
            return;
    }

    // HO_INTER_FREQ_OUT
    auto InterFreq_Ng_Out_WithGap_nonNeighbor_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithGap_Att:
                return InterFreqNgHoOutWithGap_nonNeighbour_Att;
            case InterFreqOutWithGap_PrepSucc:
                return InterFreqNgHoOutWithGap_nonNeighbour_PrepSucc;
            case InterFreqOutWithGap_Succ:
                return InterFreqNgHoOutWithGap_nonNeighbour_Succ;
            case InterFreqOutWithGap_HandoverCancel:
                return InterFreqNgHoOutWithGap_nonNeighbour_HandoverCancel;
            case InterFreqOutWithGap_RRE:
                return InterFreqNgHoOutWithGap_nonNeighbour_RRE;

            default:
                return -1;
        }
    };
    auto InterFreq_Ng_Out_WithoutGap_nonNeighbor_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithoutGap_Att:
                return InterFreqNgHoOutWithoutGap_nonNeighbour_Att;
            case  InterFreqOutWithoutGap_PrepSucc:
                return InterFreqNgHoOutWithoutGap_nonNeighbour_PrepSucc;
            case InterFreqOutWithoutGap_Succ:
                return InterFreqNgHoOutWithoutGap_nonNeighbour_Succ;
            case InterFreqOutWithoutGap_HandoverCancel:
                return InterFreqNgHoOutWithoutGap_nonNeighbour_HandoverCancel;
            case InterFreqOutWithoutGap_RRE:
                return InterFreqNgHoOutWithoutGap_nonNeighbour_RRE;

            default:
                return -1;
        }
    };
    auto IntraFreq_Ng_Out_nonNeighbor_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case IntraFreqOut_Att:
                return IntraFreqNgHoOut_nonNeighbour_Att;
            case IntraFreqOut_PrepSucc:
                return IntraFreqNgHoOut_nonNeighbour_PrepSucc;
            case IntraFreqOut_Succ:
                return IntraFreqNgHoOut_nonNeighbour_Succ;
            case IntraFreqOut_HandoverCancel:
                return IntraFreqNgHoOut_nonNeighbour_HandoverCancel;
            case IntraFreqOut_RRE:
                return IntraFreqNgHoOut_nonNeighbour_RRE;

            default:
                return -1;
        }
    };

    int typeId = -1;

    if (STAT_HO_INTER_FREQ_OUT == mFamily || STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE == mFamily)
    {
        if (IS_IF_HO_WITH_MGAP(ptCi, tgtSsbFreq))
        {
            typeId = InterFreq_Ng_Out_WithGap_nonNeighbor_mapping();
        }
        else
        {
            typeId = InterFreq_Ng_Out_WithoutGap_nonNeighbor_mapping();
        }
    }
    else // STAT_HO_INTRA_FREQ_OUT, STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE
    {
        typeId = IntraFreq_Ng_Out_nonNeighbor_mapping();
    }

#ifdef IPC_TEST
    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "%s mFamily:%d mActualFamily:%d tgtSsbFreq:%u typeId:%d \n",
            __func__, mFamily, mActualFamily, ptCi->hoInfo.tgtSsbFreq, typeId);
#endif

    if (typeId != -1)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "%s mFamily:%d mActualFamily:%d tgtSsbFreq:%u typeId:%d \n",
            __func__, mFamily, mActualFamily, tgtSsbFreq, typeId);
        MACRO_STAT_PMCC_ADD_ITEM(
            pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, typeId, PME_LIB_CC, 1);
    }
}

void FnVCCB_CollectAdditionalNonNeighborAttFromFreqRedCap(callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect,
    int mFamily, int mActualFamily, uint32_t tgtSsbFreq, int pmType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    // Check Frequency based
    if (STAT_HO_INTER_FREQ_OUT_REDCAP != mFamily && STAT_HO_INTRA_FREQ_OUT_REDCAP != mFamily) return;

    // Check Handover to NR Small Cell
    if (TRUE != ptCi->hoInfo.nonNbrCell) return;

    // HO_INTER_FREQ_OUT
    auto InterFreq_Ng_Out_WithGap_nonNeighbor_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithGap_Att_RedCap:
                return InterFreqNgHoOutWithGap_nonNeighbour_Att_RedCap;
            case InterFreqOutWithGap_PrepSucc_RedCap:
                return InterFreqNgHoOutWithGap_nonNeighbour_PrepSucc_RedCap;
            case InterFreqOutWithGap_Succ_RedCap:
                return InterFreqNgHoOutWithGap_nonNeighbour_Succ_RedCap;
            case InterFreqOutWithGap_HandoverCancel_RedCap:
                return InterFreqNgHoOutWithGap_nonNeighbour_HandoverCancel_RedCap;
            case InterFreqOutWithGap_RRE_RedCap:
                return InterFreqNgHoOutWithGap_nonNeighbour_RRE_RedCap;

            default:
                return -1;
        }
    };
    auto InterFreq_Ng_Out_WithoutGap_nonNeighbor_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithoutGap_Att_RedCap:
                return InterFreqNgHoOutWithoutGap_nonNeighbour_Att_RedCap;
            case  InterFreqOutWithoutGap_PrepSucc_RedCap:
                return InterFreqNgHoOutWithoutGap_nonNeighbour_PrepSucc_RedCap;
            case InterFreqOutWithoutGap_Succ_RedCap:
                return InterFreqNgHoOutWithoutGap_nonNeighbour_Succ_RedCap;
            case InterFreqOutWithoutGap_HandoverCancel_RedCap:
                return InterFreqNgHoOutWithoutGap_nonNeighbour_HandoverCancel_RedCap;
            case InterFreqOutWithoutGap_RRE_RedCap:
                return InterFreqNgHoOutWithoutGap_nonNeighbour_RRE_RedCap;

            default:
                return -1;
        }
    };
    auto IntraFreq_Ng_Out_nonNeighbor_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case IntraFreqOut_Att_RedCap:
                return IntraFreqNgHoOut_nonNeighbour_Att_RedCap;
            case IntraFreqOut_PrepSucc_RedCap:
                return IntraFreqNgHoOut_nonNeighbour_PrepSucc_RedCap;
            case IntraFreqOut_Succ_RedCap:
                return IntraFreqNgHoOut_nonNeighbour_Succ_RedCap;
            case IntraFreqOut_HandoverCancel:
                return IntraFreqNgHoOut_nonNeighbour_HandoverCancel_RedCap;
            case IntraFreqOut_RRE:
                return IntraFreqNgHoOut_nonNeighbour_RRE_RedCap;

            default:
                return -1;
        }
    };

    int typeId = -1;

    if (STAT_HO_INTER_FREQ_OUT_REDCAP == mFamily)
    {
        if (IS_IF_HO_WITH_MGAP(ptCi, tgtSsbFreq))
        {
            typeId = InterFreq_Ng_Out_WithGap_nonNeighbor_RedCap_mapping();
        }
        else
        {
            typeId = InterFreq_Ng_Out_WithoutGap_nonNeighbor_RedCap_mapping();
        }
    }
    else // STAT_HO_INTRA_FREQ_OUT_REDCAP
    {
        typeId = IntraFreq_Ng_Out_nonNeighbor_RedCap_mapping();
    }

#ifdef IPC_TEST
    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "%s mFamily:%d mActualFamily:%d tgtSsbFreq:%u typeId:%d \n",
            __func__, mFamily, mActualFamily, ptCi->hoInfo.tgtSsbFreq, typeId);
#endif

    if (typeId != -1)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "%s mFamily:%d mActualFamily:%d tgtSsbFreq:%u typeId:%d \n",
            __func__, mFamily, mActualFamily, tgtSsbFreq, typeId);
        MACRO_STAT_PMCC_ADD_ITEM(
            pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, typeId, PME_LIB_CC, 1);
    }
}

void FnVCCB_CollectAdditionalHighSpeedUeAttFromFreq(callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect,
    int mFamily, int mActualFamily, uint32_t tgtSsbFreq, int pmType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    if (UeSpeedState::VCCB_GetUeSpeedState(*ptCi, ptCi->servCellNum) != ueSpeedState_High)
    {
        return;
    }

    // Frequency based
    switch (mFamily)
    {
        case STAT_HO_INTER_FREQ_OUT:
        case STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE:
        case STAT_HO_INTER_FREQ_OUT_REDCAP:
        case STAT_HO_INTRA_FREQ_OUT:
        case STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE:
        case STAT_HO_INTRA_FREQ_OUT_REDCAP:
            break;
        default:
            return;
    }

    // HO_INTER_FREQ_OUT
    auto InterFreq_HighSpeedUe_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithGap_Att:
                return InterFreqOutWithGap_HighSpeedUe_Att;
            case InterFreqOutWithoutGap_Att:
                return InterFreqOutWithoutGap_HighSpeedUe_Att;
            case InterFreqOutWithGap_PrepSucc:
                return InterFreqOutWithGap_HighSpeedUe_PrepSucc;
            case InterFreqOutWithoutGap_PrepSucc:
                return InterFreqOutWithoutGap_HighSpeedUe_PrepSucc;
            case InterFreqOutWithGap_Succ:
                return InterFreqOutWithGap_HighSpeedUe_Succ;
            case InterFreqOutWithoutGap_Succ:
                return InterFreqOutWithoutGap_HighSpeedUe_Succ;
            case InterFreqOutWithGap_HandoverCancel:
                return InterFreqOutWithGap_HighSpeedUe_HandoverCancel;
            case InterFreqOutWithoutGap_HandoverCancel:
                return InterFreqOutWithoutGap_HighSpeedUe_HandoverCancel;
            case InterFreqOutWithGap_RRE:
                return InterFreqOutWithGap_HighSpeedUe_RRE;
            case InterFreqOutWithoutGap_RRE:
                return InterFreqOutWithoutGap_HighSpeedUe_RRE;

            default:
                return -1;
        }
    };
    auto InterFreq_HighSpeedUe_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterFreqOutWithGap_Att_RedCap:
                return InterFreqOutWithGap_HighSpeedUe_Att_RedCap;
            case InterFreqOutWithoutGap_Att_RedCap:
                return InterFreqOutWithoutGap_HighSpeedUe_Att_RedCap;
            case InterFreqOutWithGap_PrepSucc_RedCap:
                return InterFreqOutWithGap_HighSpeedUe_PrepSucc_RedCap;
            case InterFreqOutWithoutGap_PrepSucc_RedCap:
                return InterFreqOutWithoutGap_HighSpeedUe_PrepSucc_RedCap;
            case InterFreqOutWithGap_Succ_RedCap:
                return InterFreqOutWithGap_HighSpeedUe_Succ_RedCap;
            case InterFreqOutWithoutGap_Succ_RedCap:
                return InterFreqOutWithoutGap_HighSpeedUe_Succ_RedCap;
            case InterFreqOutWithGap_HandoverCancel_RedCap:
                return InterFreqOutWithGap_HighSpeedUe_HandoverCancel_RedCap;
            case InterFreqOutWithoutGap_HandoverCancel_RedCap:
                return InterFreqOutWithoutGap_HighSpeedUe_HandoverCancel_RedCap;
            case InterFreqOutWithGap_RRE_RedCap:
                return InterFreqOutWithGap_HighSpeedUe_RRE_RedCap;
            case InterFreqOutWithoutGap_RRE_RedCap:
                return InterFreqOutWithoutGap_HighSpeedUe_RRE_RedCap;

            default:
                return -1;
        }
    };

    // HO_INTRA_FREQ_OUT
    auto IntraFreq_HighSpeedUe_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case IntraFreqOut_Att:
                return IntraFreqOut_HighSpeedUe_Att;
            case IntraFreqOut_PrepSucc:
                return IntraFreqOut_HighSpeedUe_PrepSucc;
            case IntraFreqOut_Succ:
                return IntraFreqOut_HighSpeedUe_Succ;
            case IntraFreqOut_HandoverCancel:
                return IntraFreqOut_HighSpeedUe_HandoverCancel;
            case IntraFreqOut_RRE:
                return IntraFreqOut_HighSpeedUe_RRE;

            default:
                return -1;
        }
    };
    auto IntraFreq_HighSpeedUe_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case IntraFreqOut_Att_RedCap:
                return IntraFreqOut_HighSpeedUe_Att_RedCap;
            case IntraFreqOut_PrepSucc_RedCap:
                return IntraFreqOut_HighSpeedUe_PrepSucc_RedCap;
            case IntraFreqOut_Succ_RedCap:
                return IntraFreqOut_HighSpeedUe_Succ_RedCap;
            case IntraFreqOut_HandoverCancel_RedCap:
                return IntraFreqOut_HighSpeedUe_HandoverCancel_RedCap;
            case IntraFreqOut_RRE_RedCap:
                return IntraFreqOut_HighSpeedUe_RRE_RedCap;

            default:
                return -1;
        }
    };

    int typeId = -1;
    switch (mFamily)
    {
        case STAT_HO_INTER_FREQ_OUT:
        case STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE:
            typeId = InterFreq_HighSpeedUe_mapping();
            break;
        case STAT_HO_INTER_FREQ_OUT_REDCAP:
            typeId = InterFreq_HighSpeedUe_RedCap_mapping();
            break;
        case STAT_HO_INTRA_FREQ_OUT:
        case STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE:
            typeId = IntraFreq_HighSpeedUe_mapping();
            break;
        case STAT_HO_INTRA_FREQ_OUT_REDCAP:
            typeId = IntraFreq_HighSpeedUe_RedCap_mapping();
            break;
        default:
            break;
    }

#ifdef IPC_TEST
    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "%s mFamily:%d mActualFamily:%d tgtSsbFreq:%u typeId:%d \n",
            __func__, mFamily, mActualFamily, ptCi->hoInfo.tgtSsbFreq, typeId);
#endif

    if (typeId != -1)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "%s mFamily:%d mActualFamily:%d tgtSsbFreq:%u typeId:%d \n",
            __func__, mFamily, mActualFamily, tgtSsbFreq, typeId);
        MACRO_STAT_PMCC_ADD_ITEM(
            pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, typeId, PME_LIB_CC, 1);
    }
}

void FnVCCB_CollectAdditionalHoAttFromFreq(callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily,
    int mActualFamily, uint32_t tgtSsbFreq, int pmType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    // Inter gNB HO related Att
    FnVCCB_CollectAdditionalInterGnbHoAttFromFreq(ptCi, pPmMultiCollect, mFamily, mActualFamily, tgtSsbFreq, pmType);

    // VoNR related Att
    FnVCCB_CollectAdditionalVoNRAttFromFreq(ptCi, pPmMultiCollect, mFamily, mActualFamily, tgtSsbFreq, pmType);

    // Non NBR Cell Handover Att (To NR SmallCell)
    FnVCCB_CollectAdditionalNonNeighborAttFromFreq(ptCi, pPmMultiCollect, mFamily, mActualFamily, tgtSsbFreq, pmType);

    // High Speed Ue
    FnVCCB_CollectAdditionalHighSpeedUeAttFromFreq(ptCi, pPmMultiCollect, mFamily, mActualFamily, tgtSsbFreq, pmType);
}

void FnVCCB_CollectAdditionalHoAttFromFreqRedCap(callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily,
    int mActualFamily, uint32_t tgtSsbFreq, int pmType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    // Inter gNB HO related Att
    FnVCCB_CollectAdditionalInterGnbHoAttFromFreqRedCap(ptCi, pPmMultiCollect, mFamily, mActualFamily, tgtSsbFreq, pmType);

    // VoNR related Att
    FnVCCB_CollectAdditionalVoNRAttFromFreqRedCap(ptCi, pPmMultiCollect, mFamily, mActualFamily, tgtSsbFreq, pmType);

    // Non NBR Cell Handover Att (To NR SmallCell)
    FnVCCB_CollectAdditionalNonNeighborAttFromFreqRedCap(ptCi, pPmMultiCollect, mFamily, mActualFamily, tgtSsbFreq, pmType);

    // High Speed Ue
    FnVCCB_CollectAdditionalHighSpeedUeAttFromFreq(ptCi, pPmMultiCollect, mFamily, mActualFamily, tgtSsbFreq, pmType);
}

void FnVCCB_CollectPmccAdditionalUeContextRefForIratHo(
    callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int pmType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    if (!FOO.VF_NrToEndcHandover) return;

    int typeId = -1;  // Init

    if (true == ptCi->hoInfo.ueContextRefInfo)
    {
        switch (mFamily)
        {
            case STAT_HO_EUTRAN_OUT:
            case STAT_HO_EUTRAN_OUT_SERVICE_TYPE:
                typeId = InterSysLTE_Out_with_UeContextRefInformation;  // 17
                break;

            case STAT_HO_EUTRAN_OUT_FALLBACK:
            case STAT_HO_EUTRAN_OUT_FALLBACK_SERVICE_TYPE:
                if (ptCi->redirectionInfo.isEPSFallbackRequired == TRUE)
                {
                    typeId = InterSysLTE_Out_EPSFallback_with_UeContextRefInformation;  // 33
                }
                else if (ptCi->redirectionInfo.emergencyFallbackInd == TRUE)
                {
                    typeId = InterSysLTE_Out_EmergencyFallback_with_UeContextRefInformation;  // 34
                }
                break;

            case STAT_HO_EUTRAN_IN:
            case STAT_HO_EUTRAN_IN_SERVICE_TYPE:
                typeId = InterSysLTE_In_with_UeContextRefInformation;  // 19
                break;

            case STAT_HO_EUTRAN_FREQ_OUT: // IRAT_HO_24A
            case STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE:
                {
                    if (IS_FALLBACK_CASE(ptCi)) // Fallback case
                    {
                        if (ptCi->redirectionInfo.isEPSFallbackRequired == TRUE)
                        {
                            typeId = InterSysLTE_Out_EPSFallback_with_UeContextRefInformation_FREQ_OUT;  // 66
                        }
                        else if (ptCi->redirectionInfo.emergencyFallbackInd == TRUE)
                        {
                            typeId = InterSysLTE_Out_EmergencyFallback_with_UeContextRefInformation_FREQ_OUT;  // 67
                        }
                    }
                    else
                    {
                        typeId = InterSysLTE_Out_with_UeContextRefInformation_FREQ_OUT; // 16
                    }
                }
                break;

            default:
                break;
        }
    }

    if (typeId != -1)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "%s mFamily:%d mActualFamily:%d pmType:%d typeId:%d \n", __func__, mFamily, mActualFamily, pmType, typeId);
        MACRO_STAT_PMCC_ADD_ITEM(
            pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, typeId, PME_LIB_CC, 1);
    }
}

void FnVCCB_CollectPmccAdditionalTrafficBasedAttForIratHo(
    callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int pmType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    if (TRUE != ptCi->hoInfo.trafficBasedHoFlag) return;

    auto InterRat_HoOut_Traffic_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_Att:
                return InterSysLTE_Out_TrafficBasedHo_Att;
            case InterSysLTE_Out_PrepSucc:
                return InterSysLTE_Out_TrafficBasedHo_PrepSucc;
            case InterSysLTE_Out_Succ:
                return InterSysLTE_Out_TrafficBasedHo_Succ;
            case InterSysLTE_Out_HandoverCancel:
                return InterSysLTE_Out_TrafficBasedHo_HandoverCancel;
            case InterSysLTE_Out_RRE:
                return InterSysLTE_Out_TrafficBasedHo_RRE;

            default:
                return -1;
        }
    };

    // IRAT_HO_24A
    auto InterRat_HoFreqOut_Traffic_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_Att_FREQ_OUT:
                return InterSysLTE_Out_TrafficBasedHo_Att_FREQ_OUT;
            case InterSysLTE_Out_PrepSucc_FREQ_OUT:
                return InterSysLTE_Out_TrafficBasedHo_PrepSucc_FREQ_OUT;
            case InterSysLTE_Out_Succ_FREQ_OUT:
                return InterSysLTE_Out_TrafficBasedHo_Succ_FREQ_OUT;
            case InterSysLTE_Out_HandoverCancel_FREQ_OUT:
                return InterSysLTE_Out_TrafficBasedHo_HandoverCancel_FREQ_OUT;
            case InterSysLTE_Out_RRE_FREQ_OUT:
                return InterSysLTE_Out_TrafficBasedHo_RRE_FREQ_OUT;

            default:
                return -1;
        }
    };

    // Traffic based IRAT HO
    int typeId = -1;

    if (STAT_HO_EUTRAN_OUT == mFamily || STAT_HO_EUTRAN_OUT_SERVICE_TYPE == mFamily)
    {
        typeId = InterRat_HoOut_Traffic_mapping();
    }
    else if (STAT_HO_EUTRAN_FREQ_OUT == mFamily || STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE == mFamily)
    {
        typeId = InterRat_HoFreqOut_Traffic_mapping();
    }

    if (typeId != -1)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "%s mFamily:%d mActualFamily:%d Att:%d \n", __func__, mFamily, mActualFamily, typeId);
        MACRO_STAT_PMCC_ADD_ITEM(
            pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, typeId, PME_LIB_CC, 1);
    }
}

void FnVCCB_CollectPmccAdditionalVoNRAttForIratHo(
    callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int pmType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    // Check VoNR UE
    if (TRUE != ptCi->hoInfo.isVonrCall) return;

    auto InterRat_HoOut_VoNR_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_Att:
                return InterSysLTE_Out_VoNR_Att;
            case InterSysLTE_Out_PrepSucc:
                return InterSysLTE_Out_VoNR_PrepSucc;
            case InterSysLTE_Out_Succ:
                return InterSysLTE_Out_VoNR_Succ;
            case InterSysLTE_Out_HandoverCancel:
                return InterSysLTE_Out_VoNR_HandoverCancel;
            case InterSysLTE_Out_RRE:
                return InterSysLTE_Out_VoNR_RRE;

            default:
                return -1;
        }
    };
    auto InterRat_HoIn_VoNR_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_In_Att:
                return InterSysLTE_In_VoNR_Att;
            case InterSysLTE_In_PrepSucc:
                return InterSysLTE_In_VoNR_PrepSucc;
            case InterSysLTE_In_Succ:
                return InterSysLTE_In_VoNR_Succ;
            case InterSysLTE_In_HandoverCancel:
                return InterSysLTE_In_VoNR_HandoverCancel;
            case InterSysLTE_In_RRE:
                return InterSysLTE_In_VoNR_RRE;

            default:
                return -1;
        }
    };
    auto InterRat_HoIn_VoNR_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_In_Att_RedCap:
                return InterSysLTE_In_VoNR_Att_RedCap;
            case InterSysLTE_In_PrepSucc_RedCap:
                return InterSysLTE_In_VoNR_PrepSucc_RedCap;
            case InterSysLTE_In_Succ_RedCap:
                return InterSysLTE_In_VoNR_Succ_RedCap;
            case InterSysLTE_In_HandoverCancel_RedCap:
                return InterSysLTE_In_VoNR_HandoverCancel_RedCap;
            case InterSysLTE_In_RRE_RedCap:
                return InterSysLTE_In_VoNR_RRE_RedCap;

            default:
                return -1;
        }
    };

    // IRAT_HO_24A
    auto InterRat_HoFreqOut_VoNR_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_Att_FREQ_OUT:
                return InterSysLTE_Out_VoNR_Att_FREQ_OUT;
            case InterSysLTE_Out_PrepSucc_FREQ_OUT:
                return InterSysLTE_Out_VoNR_PrepSucc_FREQ_OUT;
            case InterSysLTE_Out_Succ_FREQ_OUT:
                return InterSysLTE_Out_VoNR_Succ_FREQ_OUT;
            case InterSysLTE_Out_HandoverCancel_FREQ_OUT:
                return InterSysLTE_Out_VoNR_HandoverCancel_FREQ_OUT;
            case InterSysLTE_Out_RRE_FREQ_OUT:
                return InterSysLTE_Out_VoNR_RRE_FREQ_OUT;

            default:
                return -1;
        }
    };

    auto InterRat_HoFreqOut_VoNR_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_Att_RedCap:
                return InterSysLTE_Out_VoNR_Att_RedCap;
            case InterSysLTE_Out_PrepSucc_RedCap:
                return InterSysLTE_Out_VoNR_PrepSucc_RedCap;
            case InterSysLTE_Out_Succ_RedCap:
                return InterSysLTE_Out_VoNR_Succ_RedCap;
            case InterSysLTE_Out_HandoverCancel_RedCap:
                return InterSysLTE_Out_VoNR_HandoverCancel_RedCap;
            case InterSysLTE_Out_RRE_RedCap:
                return InterSysLTE_Out_VoNR_RRE_RedCap;

            default:
                return -1;
        }
    };

    int voNrTypeId = -1;

    switch (mFamily)
    {
        case STAT_HO_EUTRAN_OUT:
        case STAT_HO_EUTRAN_OUT_SERVICE_TYPE:
            voNrTypeId = InterRat_HoOut_VoNR_mapping();
            break;
        case STAT_HO_EUTRAN_IN:
        case STAT_HO_EUTRAN_IN_SERVICE_TYPE:
            voNrTypeId = InterRat_HoIn_VoNR_mapping();
            break;
        case STAT_HO_EUTRAN_IN_REDCAP:
            voNrTypeId = InterRat_HoIn_VoNR_RedCap_mapping();
            break;
        case STAT_HO_EUTRAN_FREQ_OUT:
        case STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE:
            voNrTypeId = InterRat_HoFreqOut_VoNR_mapping();
            break;
        case STAT_HO_EUTRAN_FREQ_OUT_REDCAP:
            voNrTypeId = InterRat_HoFreqOut_VoNR_RedCap_mapping();
            break;
        default:
            break;
    }

    if (voNrTypeId != -1)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "%s mFamily:%d mActualFamily:%d voNrTypeId:%d \n", __func__, mFamily, mActualFamily, voNrTypeId);
        MACRO_STAT_PMCC_ADD_ITEM(
            pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, voNrTypeId, PME_LIB_CC, 1);
    }
}

int FnVCCB_hoTypeToMrsForIratHoTypeId(int mFamily, int pmType)
{
    auto InterRat_HoOut_Mrs_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_Att:
                return InterSysLTE_Out_MRS_Att;
            case InterSysLTE_Out_PrepSucc:
                return InterSysLTE_Out_MRS_PrepSucc;
            case InterSysLTE_Out_Succ:
                return InterSysLTE_Out_MRS_Succ;

            default:
                return -1;
        }
    };
    auto InterRat_HoFreqOut_Mrs_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_Att_FREQ_OUT:
                return InterSysLTE_Out_MRS_Att_FREQ_OUT;
            case InterSysLTE_Out_PrepSucc_FREQ_OUT:
                return InterSysLTE_Out_MRS_PrepSucc_FREQ_OUT;
            case InterSysLTE_Out_Succ_FREQ_OUT:
                return InterSysLTE_Out_MRS_Succ_FREQ_OUT;

            default:
                return -1;
        }
    };

    int typeId = -1;

    if (STAT_HO_EUTRAN_OUT == mFamily || STAT_HO_EUTRAN_OUT_SERVICE_TYPE == mFamily)
    {
        typeId = InterRat_HoOut_Mrs_mapping();
    }
    else if (STAT_HO_EUTRAN_FREQ_OUT == mFamily || STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE == mFamily)
    {
        typeId = InterRat_HoFreqOut_Mrs_mapping();
    }

    return typeId;

}

void FnVCCB_CollectPmccAdditionalMrsForIratHo(callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int pmType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    if (ptCi->hoInfo.interRatMrsHoFlag == VCCB_FLAG_ON)
    {
        int typeId = FnVCCB_hoTypeToMrsForIratHoTypeId(mFamily, pmType);
        if (typeId != -1)
        {
            VCCB_PRINT_CALL_COMMENT(
                    ptCi, "%s mFamily:%d mActualFamily:%d Att:%d \n", __func__, mFamily, mActualFamily, typeId);
            MACRO_STAT_PMCC_ADD_ITEM(
                    pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, typeId, PME_LIB_CC, 1);
        }
    }
}

void FnVCCB_CollectPmccAdditionalPccForIratHo(callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int pmType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    if (ptCi->hoInfo.interRatPccHoFlag == VCCB_FLAG_OFF) return;

    auto InterRat_HoOut_Pcc_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_Att:
                return InterSysLTE_Out_InterRatPccChange_Att;
            case InterSysLTE_Out_PrepSucc:
                return InterSysLTE_Out_InterRatPccChange_PrepSucc;
            case InterSysLTE_Out_Succ:
                return InterSysLTE_Out_InterRatPccChange_Succ;

            default:
                return -1;
        }
    };
    auto InterRat_HoFreqOut_Pcc_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_Att_FREQ_OUT:
                return InterSysLTE_Out_InterRatPccChange_Att_FREQ_OUT;
            case InterSysLTE_Out_PrepSucc_FREQ_OUT:
                return InterSysLTE_Out_InterRatPccChange_PrepSucc_FREQ_OUT;
            case InterSysLTE_Out_Succ_FREQ_OUT:
                return InterSysLTE_Out_InterRatPccChange_Succ_FREQ_OUT;

            default:
                return -1;
        }
    };

    int typeId = -1;

    if (STAT_HO_EUTRAN_OUT == mFamily || STAT_HO_EUTRAN_OUT_SERVICE_TYPE == mFamily)
    {
        typeId = InterRat_HoOut_Pcc_mapping();
    }
    else if (STAT_HO_EUTRAN_FREQ_OUT == mFamily || STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE == mFamily)
    {
        typeId = InterRat_HoFreqOut_Pcc_mapping();
    }

    if (typeId != -1)
    {
        VCCB_PRINT_CALL_COMMENT(
                ptCi, "%s mFamily:%d mActualFamily:%d Att:%d \n", __func__, mFamily, mActualFamily, typeId);
        MACRO_STAT_PMCC_ADD_ITEM(
                pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, typeId, PME_LIB_CC, 1);
    }
}

void FnVCCB_CollectPmccAdditionalNonNbrAttForIratHo(
        callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int pmType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    // Check Handover to Eutran Small Cell
    if (!IS_IRAT_HO_TARGET_NON_NBR_CELL()) return;

    // Family Check
    switch (mFamily) {
        case STAT_HO_EUTRAN_FREQ_OUT:
        case STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE:
        case STAT_HO_EUTRAN_FREQ_OUT_REDCAP:
            break;
        default:
            return;
    }


    // IRAT_HO_24A
    auto InterRat_HoFreqOut_NonNbr_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_Att_FREQ_OUT:
                return InterSysLTE_Out_nonNeighbour_Att_FREQ_OUT;
            case InterSysLTE_Out_PrepSucc_FREQ_OUT:
                return InterSysLTE_Out_nonNeighbour_PrepSucc_FREQ_OUT;
            case InterSysLTE_Out_Succ_FREQ_OUT:
                return InterSysLTE_Out_nonNeighbour_Succ_FREQ_OUT;
            case InterSysLTE_Out_HandoverCancel_FREQ_OUT:
                return InterSysLTE_Out_nonNeighbour_HandoverCancel_FREQ_OUT;
            case InterSysLTE_Out_RRE_FREQ_OUT:
                return InterSysLTE_Out_nonNeighbour_RRE_FREQ_OUT;

            default:
                return -1;
        }
    };
    auto InterRat_HoFreqOut_NonNbr_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_Att_RedCap:
                return InterSysLTE_Out_nonNeighbour_Att_RedCap;
            case InterSysLTE_Out_PrepSucc_RedCap:
                return InterSysLTE_Out_nonNeighbour_PrepSucc_RedCap;
            case InterSysLTE_Out_Succ_RedCap:
                return InterSysLTE_Out_nonNeighbour_Succ_RedCap;
            case InterSysLTE_Out_HandoverCancel_RedCap:
                return InterSysLTE_Out_nonNeighbour_HandoverCancel_RedCap;
            case InterSysLTE_Out_RRE_RedCap:
                return InterSysLTE_Out_nonNeighbour_RRE_RedCap;

            default:
                return -1;
        }
    };
    auto InterRat_HoFreqOut_EpsFallback_NonNbr_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_EPSFallback_Att_FREQ_OUT:
                return InterSysLTE_Out_EPSFallback_nonNeighbour_Att_FREQ_OUT;
            case InterSysLTE_Out_EPSFallback_PrepSucc_FREQ_OUT:
                return InterSysLTE_Out_EPSFallback_nonNeighbour_PrepSucc_FREQ_OUT;
            case InterSysLTE_Out_EPSFallback_Succ_FREQ_OUT:
                return InterSysLTE_Out_EPSFallback_nonNeighbour_Succ_FREQ_OUT;
            case InterSysLTE_Out_EPSFallback_HandoverCancel_FREQ_OUT:
                return InterSysLTE_Out_EPSFallback_nonNeighbour_HandoverCancel_FREQ_OUT;
            case InterSysLTE_Out_EPSFallback_RRE_FREQ_OUT:
                return InterSysLTE_Out_EPSFallback_nonNeighbour_RRE_FREQ_OUT;

            default:
                return -1;
        }
    };
    auto InterRat_HoFreqOut_EpsFallback_NonNbr_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_EPSFallback_Att_FREQ_OUT:
                return InterSysLTE_Out_EPSFallback_nonNeighbour_Att_RedCap;
            case InterSysLTE_Out_EPSFallback_PrepSucc_FREQ_OUT:
                return InterSysLTE_Out_EPSFallback_nonNeighbour_PrepSucc_RedCap;
            case InterSysLTE_Out_EPSFallback_Succ_FREQ_OUT:
                return InterSysLTE_Out_EPSFallback_nonNeighbour_Succ_RedCap;
            case InterSysLTE_Out_EPSFallback_HandoverCancel_FREQ_OUT:
                return InterSysLTE_Out_EPSFallback_nonNeighbour_HandoverCancel_RedCap;
            case InterSysLTE_Out_EPSFallback_RRE_FREQ_OUT:
                return InterSysLTE_Out_EPSFallback_nonNeighbour_RRE_RedCap;

            default:
                return -1;
        }
    };

    auto InterRat_HoFreqOut_EmergencyFallback_NonNbr_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_EmergencyFallback_Att_FREQ_OUT:
                return InterSysLTE_Out_EmergencyFallback_nonNeighbour_Att_FREQ_OUT;
            case InterSysLTE_Out_EmergencyFallback_PrepSucc_FREQ_OUT:
                return InterSysLTE_Out_EmergencyFallback_nonNeighbour_PrepSucc_FREQ_OUT;
            case InterSysLTE_Out_EmergencyFallback_Succ_FREQ_OUT:
                return InterSysLTE_Out_EmergencyFallback_nonNeighbour_Succ_FREQ_OUT;
            case InterSysLTE_Out_EmergencyFallback_HandoverCancel_FREQ_OUT:
                return InterSysLTE_Out_EmergencyFallback_nonNeighbour_HandoverCancel_FREQ_OUT;
            case InterSysLTE_Out_EmergencyFallback_RRE_FREQ_OUT:
                return InterSysLTE_Out_EmergencyFallback_nonNeighbour_RRE_FREQ_OUT;

            default:
                return -1;
        }
    };
    auto InterRat_HoFreqOut_EmergencyFallback_NonNbr_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_EmergencyFallback_Att_FREQ_OUT:
                return InterSysLTE_Out_EmergencyFallback_nonNeighbour_Att_RedCap;
            case InterSysLTE_Out_EmergencyFallback_PrepSucc_FREQ_OUT:
                return InterSysLTE_Out_EmergencyFallback_nonNeighbour_PrepSucc_RedCap;
            case InterSysLTE_Out_EmergencyFallback_Succ_FREQ_OUT:
                return InterSysLTE_Out_EmergencyFallback_nonNeighbour_Succ_RedCap;
            case InterSysLTE_Out_EmergencyFallback_HandoverCancel_FREQ_OUT:
                return InterSysLTE_Out_EmergencyFallback_nonNeighbour_HandoverCancel_RedCap;
            case InterSysLTE_Out_EmergencyFallback_RRE_FREQ_OUT:
                return InterSysLTE_Out_EmergencyFallback_nonNeighbour_RRE_RedCap;

            default:
                return -1;
        }
    };


    int typeId = -1;

    if (STAT_HO_EUTRAN_FREQ_OUT_REDCAP == mFamily)
    {
        if (IS_EMERGENCY_FALLBACK_CASE(ptCi))
        {
            typeId = InterRat_HoFreqOut_EmergencyFallback_NonNbr_RedCap_mapping();
        }
        else if (IS_EPS_FALLBACK_CASE(ptCi))
        {
            typeId = InterRat_HoFreqOut_EpsFallback_NonNbr_RedCap_mapping();
        }
        else
        {
            typeId = InterRat_HoFreqOut_NonNbr_RedCap_mapping();
        }
    }
    else // STAT_HO_EUTRAN_FREQ_OUT, STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE
    {
        if (IS_EMERGENCY_FALLBACK_CASE(ptCi))
        {
            typeId = InterRat_HoFreqOut_EmergencyFallback_NonNbr_mapping();
        }
        else if (IS_EPS_FALLBACK_CASE(ptCi))
        {
            typeId = InterRat_HoFreqOut_EpsFallback_NonNbr_mapping();
        }
        else
        {
            typeId = InterRat_HoFreqOut_NonNbr_mapping();
        }
    }

    if (typeId != -1)
    {
        VCCB_PRINT_CALL_COMMENT(
                ptCi, "%s mFamily:%d mActualFamily:%d typeId:%d \n", __func__, mFamily, mActualFamily, typeId);
        MACRO_STAT_PMCC_ADD_ITEM(
                pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, typeId, PME_LIB_CC, 1);
    }
}

void FnVCCB_CollectPmccAdditionalNonNbrVonrAttForIratHo(
    callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int pmType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    // Check VoNR UE
    if (TRUE != ptCi->hoInfo.isVonrCall) return;
    // Check Handover to Eutran Small Cell
    if (!IS_IRAT_HO_TARGET_NON_NBR_CELL()) return;

    // Family Check
    switch (mFamily) {
        case STAT_HO_EUTRAN_FREQ_OUT:
        case STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE:
        case STAT_HO_EUTRAN_FREQ_OUT_REDCAP:
            break;
        default:
            return;
    }

    // IRAT_HO_24A
    auto InterRat_HoFreqOut_NonNbr_Vonr_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_Att_FREQ_OUT:
                return InterSysLTE_Out_nonNeighbour_VoNR_Att_FREQ_OUT;
            case InterSysLTE_Out_PrepSucc_FREQ_OUT:
                return InterSysLTE_Out_nonNeighbour_VoNR_PrepSucc_FREQ_OUT;
            case InterSysLTE_Out_Succ_FREQ_OUT:
                return InterSysLTE_Out_nonNeighbour_VoNR_Succ_FREQ_OUT;
            case InterSysLTE_Out_HandoverCancel_FREQ_OUT:
                return InterSysLTE_Out_nonNeighbour_VoNR_HandoverCancel_FREQ_OUT;
            case InterSysLTE_Out_RRE_FREQ_OUT:
                return InterSysLTE_Out_nonNeighbour_VoNR_RRE_FREQ_OUT;

            default:
                return -1;
        }
    };

    auto InterRat_HoFreqOut_NonNbr_Vonr_RedCap_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_Att_RedCap:
                return InterSysLTE_Out_nonNeighbour_VoNR_Att_RedCap;
            case InterSysLTE_Out_PrepSucc_RedCap:
                return InterSysLTE_Out_nonNeighbour_VoNR_PrepSucc_RedCap;
            case InterSysLTE_Out_Succ_RedCap:
                return InterSysLTE_Out_nonNeighbour_VoNR_Succ_RedCap;
            case InterSysLTE_Out_HandoverCancel_RedCap:
                return InterSysLTE_Out_nonNeighbour_VoNR_HandoverCancel_RedCap;
            case InterSysLTE_Out_RRE_RedCap:
                return InterSysLTE_Out_nonNeighbour_VoNR_RRE_RedCap;

            default:
                return -1;
        }
    };

    int typeId = -1;

    if (STAT_HO_EUTRAN_FREQ_OUT_REDCAP == mFamily)
    {
        typeId = InterRat_HoFreqOut_NonNbr_Vonr_RedCap_mapping();
    }
    else // STAT_HO_EUTRAN_FREQ_OUT, STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE
    {
        typeId = InterRat_HoFreqOut_NonNbr_Vonr_mapping();
    }

    if (typeId != -1)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "%s mFamily:%d mActualFamily:%d typeId:%d \n", __func__, mFamily, mActualFamily, typeId);
        MACRO_STAT_PMCC_ADD_ITEM(
            pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, typeId, PME_LIB_CC, 1);
    }
}

void FnVCCB_CollectPmccAdditionalAttForIratHoRedCap(
    callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int pmType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    // VoNR Att
    FnVCCB_CollectPmccAdditionalVoNRAttForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);

    // for Non NBR Cell Handover (To Eutra SmallCell)
    FnVCCB_CollectPmccAdditionalNonNbrAttForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);

    // for Non NBR Cell Handover (To Eutra SmallCell) and VoNR UE // SVR24B FGR-MC1028 FR160
    FnVCCB_CollectPmccAdditionalNonNbrVonrAttForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);

    // ServiceBorder Att, SVR25B FGR-MC1007 FR860 (FGR-MC1027 FR303)
    FnVCCB_CollectPmccAdditionalServiceBorderAttForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);
}

// InterSysLTE_Out_Att or InterSysLTE_In_Att
void FnVCCB_CollectPmccAdditionalAttForIratHo(
    callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int pmType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    // TrafficBasedHo_Att
    FnVCCB_CollectPmccAdditionalTrafficBasedAttForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);

    // VoNR Att
    FnVCCB_CollectPmccAdditionalVoNRAttForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);

    // for MRS Inter-RAT Handover   // SVR23B_MRS
    FnVCCB_CollectPmccAdditionalMrsForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);

    // for PCC Inter-RAT Handover
    FnVCCB_CollectPmccAdditionalPccForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);

    // for Non NBR Cell Handover (To Eutra SmallCell)
    FnVCCB_CollectPmccAdditionalNonNbrAttForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);

    // for Non NBR Cell Handover (To Eutra SmallCell) and VoNR UE // SVR24B FGR-MC1028 FR160
    FnVCCB_CollectPmccAdditionalNonNbrVonrAttForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);

    // ServiceBorder Att, SVR25B FGR-MC1007 FR860
    FnVCCB_CollectPmccAdditionalServiceBorderAttForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);
}

/**
 * @brief Collect PCC Change statistics type for HO_OUT family, Apply from 23B
 *
 * @param ptCi : Call Context pointer
 * @param mFamily : Statistics family
 * @param mActualFamily : Statistics actual family
 * @param pmType : Statistics type in PM_TYPE_ID.h
 */
void FnVCCB_CollectPmccAdditionalPccChangeAttForHoOut(
    callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int pmType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pPmMultiCollect);

    if (TRUE != ptCi->hoInfo.pccChangeHoFlag) return;

    // Mismatched STAT_HO_OUT_SERVICE_TYPE from STAT_HO_OUT
    STAT_HO_OUT_TYPE_FROM_SERVICE_TYPE(mFamily, pmType);

    // Intra gNB Handover
    auto IntraGnb_HoOut_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case IntraGnbOut_Att:
                return IntraGnbOutPccChange_Att;
            case IntraGnbOut_PrepSucc:
                return IntraGnbOutPccChange_PrepSucc;
            case IntraGnbOut_Succ:
                return IntraGnbOutPccChange_Succ;

            default:
                return -1;
        }
    };

    int typeId = -1;

    switch (mFamily)
    {
        case STAT_HO_OUT:
        case STAT_HO_OUT_SERVICE_TYPE:
            if (IS_INTRA_GNB_HO())
            {
                typeId = IntraGnb_HoOut_mapping();
            }
            break;

        default:
            return;
    }

    if (typeId != -1)
    {
        // Mismatched STAT_HO_OUT_SERVICE_TYPE from STAT_HO_OUT
        STAT_SERVICE_TYPE_FROM_HO_OUT_TYPE(mFamily, typeId);

        VCCB_PRINT_CALL_COMMENT(ptCi, "%s mFamily:%d mActualFamily:%d typeId:%d\n",
            __FUNCTION__, mFamily, mActualFamily, typeId);
        MACRO_STAT_PMCC_ADD_ITEM(
            pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, typeId, PME_LIB_CC, 1);
    }
}

void FnVCCB_CollectPmccAdditionalAttItems(
    callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int pmType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    switch (mFamily)
    {
        case STAT_HO_OUT:  // 5197
        case STAT_HO_OUT_SERVICE_TYPE:
            FnVCCB_CollectPmccAdditionalVoNRForHoInOut(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);
            FnVCCB_CollectPmccAdditionalPccChangeAttForHoOut(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);
            break;

        case STAT_HO_IN:   // 5198
        case STAT_HO_IN_SERVICE_TYPE:   // 6251
            FnVCCB_CollectPmccAdditionalVoNRForHoInOut(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);
            break;

        case STAT_HO_IN_REDCAP:   // 6027
            FnVCCB_CollectPmccAdditionalVoNRForHoInRedCap(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);
            break;

        case STAT_HO_INTER_FREQ_OUT:  // 5235 // NR_CONN_MC_22B
        case STAT_HO_INTRA_FREQ_OUT:  // 5236
        case STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE:
        case STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE:
            FnVCCB_CollectAdditionalHoAttFromFreq(
                ptCi, pPmMultiCollect, mFamily, mActualFamily, ptCi->hoInfo.tgtSsbFreq, pmType);
            break;

        case STAT_HO_INTER_FREQ_OUT_REDCAP:  // 6025
        case STAT_HO_INTRA_FREQ_OUT_REDCAP:  // 6026
            FnVCCB_CollectAdditionalHoAttFromFreqRedCap(
                ptCi, pPmMultiCollect, mFamily, mActualFamily, ptCi->hoInfo.tgtSsbFreq, pmType);
            break;

        case STAT_HO_EUTRAN_OUT:           // 5211 // IRAT_HO_CTRL_CONSID_21D
        case STAT_HO_EUTRAN_OUT_FALLBACK:  // 5229
        case STAT_HO_EUTRAN_IN:            // 5212
        case STAT_HO_EUTRAN_FREQ_OUT:      // 6064 // IRAT_HO_24A
        case STAT_HO_EUTRAN_OUT_SERVICE_TYPE:
        case STAT_HO_EUTRAN_OUT_FALLBACK_SERVICE_TYPE:
        case STAT_HO_EUTRAN_IN_SERVICE_TYPE:
        case STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE:
            // for UeContextRefInformation
            FnVCCB_CollectPmccAdditionalUeContextRefForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);
            FnVCCB_CollectPmccAdditionalAttForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);
            break;

        case STAT_HO_EUTRAN_IN_REDCAP:     // 6029
        case STAT_HO_EUTRAN_FREQ_OUT_REDCAP:  // 6028
            // for UeContextRefInformation
            FnVCCB_CollectPmccAdditionalAttForIratHoRedCap(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);
            break;

        default:
            break;
    }
}

void FnVCCB_CollectPmccAdditionalPrepSuccItems(
    callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int pmType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    switch (mFamily)
    {
        case STAT_HO_OUT:  // 5197
        case STAT_HO_OUT_SERVICE_TYPE:
            FnVCCB_CollectPmccAdditionalVoNRForHoInOut(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);
            FnVCCB_CollectPmccAdditionalPccChangeAttForHoOut(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);
            break;

        case STAT_HO_IN:   // 5198
        case STAT_HO_IN_SERVICE_TYPE:   // 6251
            FnVCCB_CollectPmccAdditionalVoNRForHoInOut(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);
            break;

        case STAT_HO_IN_REDCAP:   // 6027
            FnVCCB_CollectPmccAdditionalVoNRForHoInRedCap(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);
            break;

        case STAT_HO_INTER_FREQ_OUT:  // 5235 // NR_CONN_MC_22B
        case STAT_HO_INTRA_FREQ_OUT:  // 5236
        case STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE:
        case STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE:
            FnVCCB_CollectAdditionalHoAttFromFreq(
                ptCi, pPmMultiCollect, mFamily, mActualFamily, ptCi->hoInfo.tgtSsbFreq, pmType);
            break;

        case STAT_HO_INTER_FREQ_OUT_REDCAP:  // 6025
        case STAT_HO_INTRA_FREQ_OUT_REDCAP:  // 6026
            FnVCCB_CollectAdditionalHoAttFromFreqRedCap(
                ptCi, pPmMultiCollect, mFamily, mActualFamily, ptCi->hoInfo.tgtSsbFreq, pmType);
            break;

        case STAT_HO_EUTRAN_OUT:           // 5211 // IRAT_HO_CTRL_CONSID_21D
        case STAT_HO_EUTRAN_OUT_FALLBACK:  // 5229
        case STAT_HO_EUTRAN_IN:            // 5212
        case STAT_HO_EUTRAN_FREQ_OUT:      // 6064 // IRAT_HO_24A
        case STAT_HO_EUTRAN_OUT_SERVICE_TYPE:
        case STAT_HO_EUTRAN_OUT_FALLBACK_SERVICE_TYPE:
        case STAT_HO_EUTRAN_IN_SERVICE_TYPE:
        case STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE:
            FnVCCB_CollectPmccAdditionalAttForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);
            break;

        case STAT_HO_EUTRAN_IN_REDCAP:     // 6029
        case STAT_HO_EUTRAN_FREQ_OUT_REDCAP:      // 6028
            FnVCCB_CollectPmccAdditionalAttForIratHoRedCap(ptCi, pPmMultiCollect, mFamily, mActualFamily, pmType);
            break;

        default:
            break;
    }
}

void FnVCCB_CollectPmccAdditionalHoSuccItems(
    callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int mType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);
    enumHoStatType type = HO_TYPE_MAX; // HO_STAT_23B

    switch (mFamily)
    {
        case STAT_HO_OUT:  // 5197
        case STAT_HO_OUT_SERVICE_TYPE:
            // Mismatched STAT_HO_OUT_SERVICE_TYPE from STAT_HO_OUT
            STAT_HO_OUT_TYPE_FROM_SERVICE_TYPE(mFamily, mType);

            VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_OUT_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            // Mismatched STAT_HO_OUT_SERVICE_TYPE from STAT_HO_OUT
            STAT_SERVICE_TYPE_FROM_HO_OUT_TYPE(mFamily, mType);

            FnVCCB_CollectPmccAdditionalVoNRForHoInOut(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);
            FnVCCB_CollectPmccAdditionalPccChangeAttForHoOut(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);
            break;

        case STAT_HO_IN:  // 5198
        case STAT_HO_IN_SERVICE_TYPE:  // 6251
            VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_IN_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectPmccAdditionalVoNRForHoInOut(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);
            break;

        case STAT_HO_IN_REDCAP:   // 6027
            VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_IN_REDCAP_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectPmccAdditionalVoNRForHoInRedCap(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);
            break;

        case STAT_HO_INTER_FREQ_OUT:  // 5235
        case STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE:
            VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_INTER_FREQ_OUT_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectAdditionalHoAttFromFreq(
                ptCi, pPmMultiCollect, mFamily, mActualFamily, ptCi->hoInfo.tgtSsbFreq, mType);
            break;

        case STAT_HO_INTER_FREQ_OUT_REDCAP:  // 6025
            VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_INTER_FREQ_OUT_REDCAP_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectAdditionalHoAttFromFreqRedCap(
                ptCi, pPmMultiCollect, mFamily, mActualFamily, ptCi->hoInfo.tgtSsbFreq, mType);
            break;

        case STAT_HO_INTRA_FREQ_OUT:  // 5236
        case STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE:
            VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_INTRA_FREQ_OUT_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectAdditionalHoAttFromFreq(
                ptCi, pPmMultiCollect, mFamily, mActualFamily, ptCi->hoInfo.tgtSsbFreq, mType);
            break;

        case STAT_HO_INTRA_FREQ_OUT_REDCAP:  // 6026
            VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_INTRA_FREQ_OUT_REDCAP_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectAdditionalHoAttFromFreqRedCap(
                ptCi, pPmMultiCollect, mFamily, mActualFamily, ptCi->hoInfo.tgtSsbFreq, mType);
            break;

        case STAT_HO_EUTRAN_OUT:           // 5211
        case STAT_HO_EUTRAN_OUT_SERVICE_TYPE:
            VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_EUTRAN_OUT_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectPmccAdditionalAttForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);
            break;

        case STAT_HO_EUTRAN_OUT_FALLBACK:  // 5229
        case STAT_HO_EUTRAN_OUT_FALLBACK_SERVICE_TYPE:
            VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_EUTRAN_OUT_FALLBACK_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectPmccAdditionalAttForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);
            break;

        case STAT_HO_EUTRAN_IN:            // 5212
        case STAT_HO_EUTRAN_IN_SERVICE_TYPE:
            VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_EUTRAN_IN_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectPmccAdditionalAttForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);
            break;

        case STAT_HO_EUTRAN_IN_REDCAP:     // 6029
            VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_EUTRAN_IN_REDCAP_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectPmccAdditionalAttForIratHoRedCap(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);
            break;

        case STAT_HO_EUTRAN_FREQ_OUT:      // 6064  IRAT_HO_24A
        case STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE:
            VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_EUTRAN_FREQ_OUT_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectPmccAdditionalAttForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);
            break;

        case STAT_HO_EUTRAN_FREQ_OUT_REDCAP:      // 6028
            VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_EUTRAN_REDCAP_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectPmccAdditionalAttForIratHoRedCap(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);
            break;

        default:
            break;
    }
}

/**
 * @brief     collect VoNR statistics for Handover Cancel, RRE
 * @param     ptCi : call context pointer
 * @param     mFamily : statistics family
 * @param     mActualFamily : statistics actual family
 * @param     mType : statistic type in family
 */
void FnVCCB_CollectPmccAdditionalHoCancelRreItems(
    callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int mType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);
    enumHoStatType type = HO_TYPE_MAX; // HO_STAT_23B

    switch (mFamily)
    {
        case STAT_HO_OUT:  // 5197
        case STAT_HO_OUT_SERVICE_TYPE:
            // Mismatched STAT_HO_OUT_SERVICE_TYPE from STAT_HO_OUT
            STAT_HO_OUT_TYPE_FROM_SERVICE_TYPE(mFamily, mType);

            VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_OUT_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            // Mismatched STAT_HO_OUT_SERVICE_TYPE from STAT_HO_OUT
            STAT_SERVICE_TYPE_FROM_HO_OUT_TYPE(mFamily, mType);

            FnVCCB_CollectPmccAdditionalVoNRForHoInOut(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);
            break;

        case STAT_HO_IN:  // 5198
        case STAT_HO_IN_SERVICE_TYPE:  // 6251
            VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_IN_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectPmccAdditionalVoNRForHoInOut(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);
            break;

        case STAT_HO_IN_REDCAP:   // 6027
            VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_IN_REDCAP_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectPmccAdditionalVoNRForHoInRedCap(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);
            break;

        case STAT_HO_INTER_FREQ_OUT:  // 5235
        case STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE:
            VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_INTER_FREQ_OUT_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectAdditionalHoAttFromFreq(
                    ptCi, pPmMultiCollect, mFamily, mActualFamily, ptCi->hoInfo.tgtSsbFreq, mType);
            break;

        case STAT_HO_INTER_FREQ_OUT_REDCAP:  // 6025
            VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_INTER_FREQ_OUT_REDCAP_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectAdditionalHoAttFromFreqRedCap(
                    ptCi, pPmMultiCollect, mFamily, mActualFamily, ptCi->hoInfo.tgtSsbFreq, mType);
            break;

        case STAT_HO_INTRA_FREQ_OUT:  // 5236
        case STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE:
            VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_INTRA_FREQ_OUT_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectAdditionalHoAttFromFreq(
                    ptCi, pPmMultiCollect, mFamily, mActualFamily, ptCi->hoInfo.tgtSsbFreq, mType);
            break;

        case STAT_HO_INTRA_FREQ_OUT_REDCAP:  // 6026
            VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_INTRA_FREQ_OUT_REDCAP_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectAdditionalHoAttFromFreqRedCap(
                    ptCi, pPmMultiCollect, mFamily, mActualFamily, ptCi->hoInfo.tgtSsbFreq, mType);
            break;

        case STAT_HO_EUTRAN_OUT:           // 5211
        case STAT_HO_EUTRAN_OUT_SERVICE_TYPE:
            VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_EUTRAN_OUT_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectPmccAdditionalAttForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);
            break;

        case STAT_HO_EUTRAN_IN:            // 5212
        case STAT_HO_EUTRAN_IN_SERVICE_TYPE:
            VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_EUTRAN_IN_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectPmccAdditionalAttForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);
            break;

        case STAT_HO_EUTRAN_IN_REDCAP:     // 6029
            VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_EUTRAN_IN_REDCAP_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectPmccAdditionalAttForIratHoRedCap(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);
            break;

        case STAT_HO_EUTRAN_FREQ_OUT:           // 6064  // IRAT_HO_24A
        case STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE:
            VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_EUTRAN_FREQ_OUT_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectPmccAdditionalAttForIratHo(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);
            break;

        case STAT_HO_EUTRAN_FREQ_OUT_REDCAP:    // 6028
            VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_EUTRAN_REDCAP_STAT(mType, type);
            if (HO_TYPE_MAX == type) return;

            FnVCCB_CollectPmccAdditionalAttForIratHoRedCap(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);
            break;


        default:
            break;
    }
}

#define PRINT_STAT_CSL_HO_OUT_INFO(rCall, mFamilyStr, type) \
    do { \
        if (DBG->flag.logHoStatCsl) { \
            VCCB_PRINT_CALL_INFORMATIVE(&rCall, "(CSL)(hoOut) %s %d \n", mFamilyStr, type); \
        } \
    } while (0)

void FnVCCB_CollectMobilityCsl_Redir(callInfo_type &rCall, const unsigned int mType)
{
    AUTO_TRACE_FUNC;

    switch (mType)
    {
        case RedirectionToLTE_CoverageOut:
            rCall.cslInfo.cslMobilityInfo.cslRedirection.redCovCnt = 1;
            break;
        case RedirectionToLTE_EPSFallback:
            rCall.cslInfo.cslMobilityInfo.cslRedirection.redEpsFallCnt = 1;
            break;
        case RedirectionToLTE_EmergencyFallback:
            rCall.cslInfo.cslMobilityInfo.cslRedirection.redEmFallCnt = 1;
            break;
        case RedirectionToLTE_BlindA2:
            rCall.cslInfo.cslMobilityInfo.cslRedirection.redA2Cnt = 1;
            break;
        default:
            break;
    }

    if (DBG->flag.logHoStatCsl)
    {
        VCCB_PRINT_CALL_INFORMATIVE(&rCall,
            "(CSL)(redirectionToLte) (mType;%d) CoverageOut=%u, EpsFallback=%u, EmergencyFallback=%u, BlindA2=%u\n",
            mType, rCall.cslInfo.cslMobilityInfo.cslRedirection.redCovCnt,
            rCall.cslInfo.cslMobilityInfo.cslRedirection.redEpsFallCnt,
            rCall.cslInfo.cslMobilityInfo.cslRedirection.redEmFallCnt,
            rCall.cslInfo.cslMobilityInfo.cslRedirection.redA2Cnt);
    }
}

void FnVCCB_CollectMobilityCsl_HoOut(callInfo_type &rCall, uint32_t item_mType, int mFamily)
{
    if (mFamily != STAT_HO_OUT) return;

    VCCB_CSL_STAT_UPDATE_HO_OUT(rCall, item_mType);
    PRINT_STAT_CSL_HO_OUT_INFO(rCall, "STAT_HO_OUT", item_mType);
    if (DBG->flag.logHoStatCsl)
    {
        auto cslMobility = rCall.cslInfo.cslMobilityInfo;

        VCCB_PRINT_CALL_INFORMATIVE(&rCall,
            "(CSL)(hoOut) (mType:%3d) Intra(%u,%u,%u,%u,%u)Xn(%u,%u,%u,%u,%u), Ng(%u,%u,%u,%u,%u)\n", item_mType,
            cslMobility.intraGnbHoAttCnt, cslMobility.intraGnbHoPrepCnt, cslMobility.intraGnbHoExecCnt,
            cslMobility.intraGnbHoCancelCnt, cslMobility.intraGnbHoRreCnt, cslMobility.interGnbXnHoAttCnt,
            cslMobility.interGnbXnHoPrepCnt, cslMobility.interGnbXnHoExecCnt, cslMobility.interGnbXnHoCancelCnt,
            cslMobility.interGnbXnHoRreCnt, cslMobility.interGnbNgHoAttCnt, cslMobility.interGnbNgHoPrepCnt,
            cslMobility.interGnbNgHoExecCnt, cslMobility.interGnbNgHoCancelCnt, cslMobility.interGnbNgHoRreCnt);
    }
}

/*
 * @brief     Collect CSL Handover related stat
 * @param     Family Id: HO related Stat family
 * @param     Type : type in the family id
 */
void FnVCCB_CollectMobilityCsl(callInfo_type &rCall, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily)
{
    VALID_E_POINT_CHECK_VOID(pPmMultiCollect);
    auto isMobilityCslFailily = [](int family) -> bool
    {
        switch (family)
        {
            case STAT_HO_EUTRAN_FREQ_OUT:  // SVR25A FGR-MC3002 FR190
            case STAT_HO_EUTRAN_FREQ_OUT_REDCAP:
            case STAT_HO_INTRA_FREQ_OUT:  // SVR25A FGR-MC1007 FR790
            case STAT_HO_INTRA_FREQ_OUT_REDCAP:
            case STAT_HO_INTER_FREQ_OUT:  // SVR25A FGR-MC1007 FR790
            case STAT_HO_INTER_FREQ_OUT_REDCAP:
            case STAT_HO_OUT: // SVR25B FGR-MC1009 FR600
            case STAT_REDIR_EUTRAN_OUT:  // SVR25B FGR-MC3001 FR240
                return true;

            default:
                break;
        }

        return false;
    };

    if (not isMobilityCslFailily(mFamily)) return;

    for (uint32_t itemIdx = 0; itemIdx < MIN(pPmMultiCollect->numOfItem, VCCB_MAX_MTYPES); ++itemIdx)
    {
        auto item_mType = pPmMultiCollect->updateItemUintArr[itemIdx].typeID;

        switch (mFamily)
        {
            case STAT_HO_EUTRAN_FREQ_OUT:  // SVR25A FGR-MC3002 FR190
                VCCB_CSL_STAT_UPDATE_HO_EUTRAN_FREQ_OUT(rCall, item_mType);
                PRINT_STAT_CSL_HO_OUT_INFO(rCall, "STAT_HO_EUTRAN_FREQ_OUT", item_mType);
                break;

            case STAT_HO_EUTRAN_FREQ_OUT_REDCAP:
                VCCB_CSL_STAT_UPDATE_HO_EUTRAN_FREQ_OUT_REDCAP(rCall, item_mType);
                PRINT_STAT_CSL_HO_OUT_INFO(rCall, "STAT_HO_EUTRAN_FREQ_OUT_REDCAP", item_mType);
                break;

            case STAT_HO_INTRA_FREQ_OUT:  // SVR25A FGR-MC1007 FR790
            case STAT_HO_INTRA_FREQ_OUT_REDCAP:
                VCCB_CSL_STAT_UPDATE_HO_INTRA_FREQ_OUT(rCall, item_mType);
                PRINT_STAT_CSL_HO_OUT_INFO(rCall, "STAT_HO_INTRA_FREQ_OUT", item_mType);
                break;

            case STAT_HO_INTER_FREQ_OUT:  // SVR25A FGR-MC1007 FR790
            case STAT_HO_INTER_FREQ_OUT_REDCAP:
                VCCB_CSL_STAT_UPDATE_HO_INTER_FREQ_OUT(rCall, item_mType);
                PRINT_STAT_CSL_HO_OUT_INFO(rCall, "STAT_HO_INTER_FREQ_OUT", item_mType);
                break;

            case STAT_HO_OUT:  // SVR25B FGR-MC1009 FR600
                FnVCCB_CollectMobilityCsl_HoOut(rCall, item_mType, mFamily);
                break;

            case STAT_REDIR_EUTRAN_OUT:  // SVR25B FGR-MC3001 FR240
                FnVCCB_CollectMobilityCsl_Redir(rCall, item_mType);
                break;

            default:
                break;
        }
    }
}

// For additional handover related stat
// Whenever a handover-related event occurs, a specific family type is collected.
// In addition, different family's types or same family's types are collected.
void FnVCCB_CollectPmccAdditionalHOStatistic(
        callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int mType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    // Additional HO Success related statistics
    FnVCCB_CollectPmccAdditionalHoSuccItems(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);  // HO_STAT_23A

    // Additional HO Cancel/RRE related statistics
    FnVCCB_CollectPmccAdditionalHoCancelRreItems(ptCi, pPmMultiCollect, mFamily, mActualFamily, mType);  // HO_STAT_23B

    // Additional 5QI 1 setup/modify fail statistics
    FnVCCB_CollectPmccAdditionalHoF1FailStat(ptCi, pPmMultiCollect, mFamily, mActualFamily);

    // Additional Slice Reject cause statistics
    FnVCCB_CollectPmccAdditionalSliceRejectStat(ptCi, pPmMultiCollect, mFamily, mActualFamily);
}

// FGR-CC5200:FR640
int FnVCCB_GetDetailInfoforStatNrdcCtxRel(int mType, bool *pIsNormal, bool *pIsMnInitiated)
{
    VALID_E_POINT_CHECK_ERROR_PARAM2(pIsNormal, pIsMnInitiated);
    // to extract information(normal/abnormal, mn/sn) from mType
    // This extracted info will be used to decide STAT_NRDC_CTX_REL::NrdcNormalReleasebyMnTot,
    // NrdcAbnormalReleasebyMnTot, NrdcNormalReleasebySnTot, NrdcAbnormalReleasebySnTot
    switch (mType)
    {
        case PSCellDrop_NrdcNormalReleasebyMn_RRE:
        case PSCellDrop_NrdcNormalReleasebyMn_UeSignature:
        case PSCellDrop_NrdcNormalReleasebyMn_UserInactivity:
        case PSCellDrop_NrdcNormalReleasebyMn_MnMobilityWithSnRelease:
        case PSCellDrop_NrdcNormalReleasebyMn_MnMobilityWithIntraSnMobility:
            *pIsNormal = true;
            *pIsMnInitiated = true;
            break;
        case PSCellDrop_NrdcNormalReleasebySn_A2Mr:
        case PSCellDrop_NrdcNormalReleasebySn_Preemption:
        case PSCellDrop_NrdcNormalReleasebySn_IntraSnMobility:
        case PSCellDrop_NrdcNormalReleasebySn_InterSnMobility:
        case PSCellDrop_NrdcNormalReleasebySn_UserInactivity:
            *pIsNormal = true;
            *pIsMnInitiated = false;
            break;
        case PSCellDrop_NrdcAbnormalReleasebyMn_XnReset:
        case PSCellDrop_NrdcAbnormalReleasebyMn_RadioConnectionWithUeLost:
            *pIsNormal = false;
            *pIsMnInitiated = true;
            break;
        case PSCellDrop_NrdcAbnormalReleasebySn_XnLinkFail:
        case PSCellDrop_NrdcAbnormalReleasebySn_DL_t310Expiry:
        case PSCellDrop_NrdcAbnormalReleasebySn_DL_randomAccessProblem:
        case PSCellDrop_NrdcAbnormalReleasebySn_DL_rlcMaxNumRetx:
        case PSCellDrop_NrdcAbnormalReleasebySn_DL_synchReconfigFailureSCG:
        case PSCellDrop_NrdcAbnormalReleasebySn_DL_scgReconfigFailure:
        case PSCellDrop_NrdcAbnormalReleasebySn_DL_t312Expiry:
        case PSCellDrop_NrdcAbnormalReleasebySn_DL_srb3IntegrityFailure:
        case PSCellDrop_NrdcAbnormalReleasebySn_DL_beamFailureRecoveryFailure:
        case PSCellDrop_NrdcAbnormalReleasebySn_DL_other:
        case PSCellDrop_NrdcAbnormalReleasebySn_UL_outOfSync:
        case PSCellDrop_NrdcAbnormalReleasebySn_UL_rlcMaxNumRetx:
            *pIsNormal = false;
            *pIsMnInitiated = false;
            break;
        default:
            // VCCB_PRINT_ERROR("Invalid mType(%d) of STAT_NRDC_CTX_REL in %s!\n", mType, __func__);
            return ERROR;
    }
    return GOOD;
}

// FGR-CC5200:FR640
void FnVCCB_CollectPmccAdditionalNrdcStats(
        callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mActualFamily, int mType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    if (!IS_SUPPORT_CollectNrdcCtxRelStats(ptCi)) return;

    // FGR-CC5200:FR641
    if (mActualFamily != STAT_NRDC_CTX_REL && mActualFamily != STAT_NRDC_CTX_REL_SERVICE_TYPE)
    {
        return;
    }
    int  mActualType = NrdcNormalReleasebyMnTot;
    bool isNormalRelease = true;
    bool isMnInitiated = true;
    if (GOOD != FnVCCB_GetDetailInfoforStatNrdcCtxRel(mType, &isNormalRelease, &isMnInitiated))
    {
        return;
    }
    if (isNormalRelease)
    {
        if (isMnInitiated)
        {
            mActualType = NrdcNormalReleasebyMnTot;
        }
        else
        {
            mActualType = NrdcNormalReleasebySnTot;
        }
    }
    else
    {
        if (isMnInitiated)
        {
            mActualType = NrdcAbnormalReleasebyMnTot;
        }
        else
        {
            mActualType = NrdcAbnormalReleasebySnTot;
        }
    }
    MACRO_STAT_PMCC_ADD_ITEM(pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, mActualType, pPmMultiCollect->updateMethod, 1);
}

// FGR-LC0750: FR20: Evt_PscellChange
void FnVCCB_CollectPmccPScellChangeLocalStats(callInfo_type *ptCi, int mFamily)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    const bool isPScellChangeAllowedFamily {STAT_LB_PSCELL_CHANGE == mFamily ||
                                            STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB == mFamily ||
                                            STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB == mFamily ||
                                            STAT_INTER_DU_PSCELL_CHANGE_GETTING_BACK == mFamily ||
                                            STAT_NRDC_PSCELL_CHANGE_IN == mFamily };

    if (false == isPScellChangeAllowedFamily)
    {
        return;
    }

    INCREASE_LOCAL_MSG_STAT(ptCi->myThreadId, INT_PScellChange);
}

/**
 * @brief Collect INVALID_CELL_ENDC_ADD_PER_GNB family.
 *        Verizon requested new family to be collected when SgNBAdditon is rejected before SpCell is selected
 * @param[in]  ptCi : callInfo
 * @param[in]  mFamily : family to be collected
 * @param[in]  mType : type to be collected
 * @return N/A
 */
void FnVCCB_CollectPmccInvalidCellSgNBAddition(callInfo_type *ptCi, int mFamily, int mType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->endPointInfo.x2Idx, MAX_ENB_PER_GNB_CU_CP);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->invalidCellSgNBAddReject.arfcn, (MAX_NR_ARFCN+1));

    const bool isEndcAddFailWithInvalidCell
        { MAX_CELL_NUM_VCCB <= ptCi->servCellNum &&
          STAT_SGNB_ADD_PER_GNB == mFamily &&
          StatEndcAddPrepFail_CpFail == mType};

    if (false == isEndcAddFailWithInvalidCell)
    {
        return;
    }

    VccbPmKey_type pmKey;
    memset(&pmKey, 0x00, sizeof(pmKey));

    pmKey.usageOfNumKey = CI_no_use;
    pmKey.numKey = 0;

    pmKey.keyList[0] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
    pmKey.keyList[1] = GNBINFO[ptCi->gnbNum].x2Nbr[ptCi->endPointInfo.x2Idx].enbId;

    VccbPmMultiCollect_type pmMultiCollect;
    FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_CC);

    mFamily = STAT_INVALID_CELL_ENDC_ADD_PER_GNB;

    // B3G C-Band
    // size of array is defined by amount of counters in mFamily
    bool counterType[STAT_INVALID_CELL_ENDC_ADD_PER_GNB_END]  = { false };
    const uint8_t spCellSelFailCount = ptCi->spCellSelFailStats.num;

    // Handling case, where Candidates are prepared, but Addition fail occurs before SpCellSelection
    if (0 == spCellSelFailCount)
    {
        if (MIN_A6_NR_ARFCN <= ptCi->invalidCellSgNBAddReject.arfcn && MAX_A6_NR_ARFCN >= ptCi->invalidCellSgNBAddReject.arfcn)
        {
            counterType[A6GOthers] = true;
        }
        else if (MIN_A3_NR_ARFCN <= ptCi->invalidCellSgNBAddReject.arfcn && MAX_A3_NR_ARFCN >= ptCi->invalidCellSgNBAddReject.arfcn)
        {
            counterType[A3GOthers] = true;
        }
        else if (MIN_A3_NR_ARFCN > ptCi->invalidCellSgNBAddReject.arfcn)
        {
            counterType[B3GOthers] = true;
        }
    }

    for (uint8_t loop = 0; loop < spCellSelFailCount; ++loop)
    {
        const uint32_t arfcn = ptCi->spCellSelFailStats.SpCellSelFailPerCandidateCell[loop].arfcn;
        const enumStatSpCellSelectionFailCause_type cause = static_cast<enumStatSpCellSelectionFailCause_type>(ptCi->spCellSelFailStats.SpCellSelFailPerCandidateCell[loop].spCellSelFailure);

        auto InvalidCellMap = getValueInvalidCellMap(cause);
        if (MIN_A6_NR_ARFCN <= arfcn && MAX_A6_NR_ARFCN >= arfcn)
        {
            if (InvalidCellMap.has_value() && InvalidCellCauseUENotSupFreqBand == InvalidCellMap.value())
            {
                counterType[A6GUENotSupFreqBand] = true;
            }
            else if (InvalidCellMap.has_value() && InvalidCellCauseSpid == InvalidCellMap.value())
            {
                counterType[A6GSpid] = true;
            }
            else
            {
                counterType[A6GOthers] = true;
            }
        }
        else if (MIN_A3_NR_ARFCN <= arfcn && MAX_A3_NR_ARFCN >= arfcn)
        {
            if (InvalidCellMap.has_value() && InvalidCellCauseUENotSupFreqBand == InvalidCellMap.value())
            {
                counterType[A3GUENotSupFreqBand] = true;
            }
            else if (InvalidCellMap.has_value() && InvalidCellCauseSpid == InvalidCellMap.value())
            {
                counterType[A3GSpid] = true;
            }
            else
            {
                counterType[A3GOthers] = true;
            }
        }
        else if (MIN_A3_NR_ARFCN > arfcn)
        {
            if (InvalidCellMap.has_value() && InvalidCellCauseUENotSupFreqBand == InvalidCellMap.value())
            {
                counterType[B3GUENotSupFreqBand] = true;
            }
            else if (InvalidCellMap.has_value() && InvalidCellCauseSpid == InvalidCellMap.value())
            {
                counterType[B3GSpid] = true;
            }
            else
            {
                counterType[B3GOthers] = true;
            }
        }
    }

    // Rank attemptType and causeType
    int causeType = GetCauseTypeBasedOnPriority(counterType);
    if (ERROR == causeType)
    {
        VCCB_PRINT_COMMENT("causeType is invalid (causeType:%d)\n", causeType);
        return;
    }
    int attemptType = GetAttemptTypeBasedOnPriority(causeType);
    if (ERROR == attemptType)
    {
        VCCB_PRINT_COMMENT("attemptType is invalid (attemptType:%d)\n", attemptType);
        return;
    }

    // Collect TotAddAtt + B3G/A3G/A6G AddAttTot + B3G/A3G/A6G : UENotSupFreqBand/Spid/Other
    MACRO_STAT_PMCC_ADD_ITEM(
        pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mFamily, TotAddAtt, PME_LIB_CC, 1);
    MACRO_STAT_PMCC_ADD_ITEM(
        pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mFamily, attemptType, PME_LIB_CC, 1);
    MACRO_STAT_PMCC_ADD_ITEM(
        pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mFamily, causeType, PME_LIB_CC, 1);

    CollectPmStatistics(
        ptCi, (unsigned)mFamily, (unsigned)mFamily, &pmMultiCollect, pmMultiCollect.updateItemUintArr, pmKey, true);
}

/**
 * @brief Process individual cell failure and update counters
 * @param[in]  ptCi : callInfo containing call details and failure statistics
 * @param[in]  cause : SpCellSelection failure cause
 * @param[in,out] typeIdPerCandidate : array of counters per candidate priority
 * @param[in]  MAX_PRIORITY_MAP_SIZE : maximum size of priority map
 */
static void processPerCandidateCounters(callInfo_type *ptCi, enumStatSpCellSelectionFailCause_type cause,
    int typeIdPerCandidate[], int MAX_PRIORITY_MAP_SIZE)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    auto spCellSelFailPerCandidateMap = getValueSpCellSelFailPerCandidateMap(cause);
    auto spCellSelFailPerCandIndexMap =
        getValueSpCellSelFailPerCandidateIndexMap(EndcAddPrepFail_CpFail_SpCellSel_Unspecified_perCandidate);

    if (spCellSelFailPerCandidateMap.has_value())
    {
        spCellSelFailPerCandIndexMap = getValueSpCellSelFailPerCandidateIndexMap(spCellSelFailPerCandidateMap.value());

        if (spCellSelFailPerCandIndexMap.has_value())
        {
            if (spCellSelFailPerCandIndexMap.value() < MAX_PRIORITY_MAP_SIZE)
            {
                typeIdPerCandidate[spCellSelFailPerCandIndexMap.value()]++;
            }
            else
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "%s - priority index(%i) out of range!\n", __FUNCTION__,
                    spCellSelFailPerCandIndexMap.value());
            }
        }
    }
    else if (spCellSelFailPerCandIndexMap.has_value())
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "%s - typeIdPerCandidate not found!\n", __FUNCTION__);
        if (spCellSelFailPerCandIndexMap.value() < MAX_PRIORITY_MAP_SIZE)
        {
            typeIdPerCandidate[spCellSelFailPerCandIndexMap.value()]++;  // unspecified cause
        }
        else
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "%s - priority index(%i) out of range for unspecified!\n", __FUNCTION__,
                spCellSelFailPerCandIndexMap.value());
        }
    }
}

/**
 * @brief Process call priority mapping to determine the highest priority failure type
 * @param[in]  ptCi : callInfo containing call details and failure statistics
 * @param[in]  cause : SpCellSelection failure cause
 * @param[in,out] typeIdPerCall : reference to the highest priority type ID for the call
 * @return N/A
 */
static void processPerCallCounters(callInfo_type *ptCi, enumStatSpCellSelectionFailCause_type cause, int &typeIdPerCall)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    auto spCellSelFailPerCallMap = getValueSpCellSelFailMap(cause);
    if (spCellSelFailPerCallMap.has_value())
    {
        int newTypeId = spCellSelFailPerCallMap.value();
        auto newPriorityOpt = getValueSpCellSelFailPriorityMap(newTypeId);

        if (newPriorityOpt.has_value())
        {
            auto currentPriorityOpt = getValueSpCellSelFailPriorityMap(typeIdPerCall);

            if (!currentPriorityOpt.has_value() || newPriorityOpt.value() < currentPriorityOpt.value())
            {
                typeIdPerCall = newTypeId;
            }
        }
    }
    else
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "%s - typeIdPerCall not found!\n", __FUNCTION__);
    }
}

/**
 * @brief Collect internal counters per gNB and per cell
 * @param[in]  ptCi : callInfo containing call details and failure statistics
 * @param[in]  pGnb : gNB information structure for counter updates
 * @param[in]  cause : SpCellSelection failure cause
 * @param[in]  cellId : cell identifier
 * @return N/A
 */
static void collectInternalCounters(
    callInfo_type *ptCi, VccbGnbInfo_type *pGnb, enumStatSpCellSelectionFailCause_type cause, uint16_t cellId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pGnb);

    if (cause < StatEndcSpCellSelFail_MAX_STAT)
    {
        ++pGnb->cfg.statEndcAddDetailedSpCellSelFail[cause];
        if (cellId < MAX_CELL_IDENTITY)
        {
            const uint16_t cellNum = FnVCCB_GetCellNum(ptCi->gnbNum, cellId);
            if (cellNum < MAX_CELL_NUM_VCCB)
            {
                VccbCellInfo_type *pCell = &CELLINFO[cellNum];
                ++pCell->statEndcAddDetailedSpCellSelFail[cause];
            }
        }
    }
}

/**
 * @brief Collect counters per candidate
 *        Iterates through priority mappings and collects counters for each candidate
 *        based on the typeIdPerCandidate array
 * @param[in]  pPmMultiCollect : PM collection structure for counter updates
 * @param[in]  mActualFamily : actual family to be collected
 * @param[in]  typeIdPerCandidate : array of counters per candidate priority
 * @param[in]  MAX_PRIORITY_MAP_SIZE : maximum size of priority map
 */
static void collectCountersPerCandidate(
    VccbPmMultiCollect_type *pPmMultiCollect, int mActualFamily, int typeIdPerCandidate[], int MAX_PRIORITY_MAP_SIZE)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pPmMultiCollect);

    for (int priority = 0; priority < MAX_PRIORITY_MAP_SIZE; ++priority)
    {
        if (!(typeIdPerCandidate[priority]))
        {
            continue;
        }

        // Collect counter per Candidate
        auto spCellSelFailPerCandidateIndexMap = getKeySpCellSelFailPerCandidateIndexMap(priority);
        if (spCellSelFailPerCandidateIndexMap.has_value())
        {
            MACRO_STAT_PMCC_ADD_ITEM(pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily,
                spCellSelFailPerCandidateIndexMap.value(), PME_LIB_CC, typeIdPerCandidate[priority]);
        }
    }
}

/**
 * @brief Collect SpCellSelection Failure counters
 *        Detailed counter for rejection reason of candidate cell during SgNBAdditon procedure
 * @param[in]  ptCi : callInfo
 * @param[in]  pPmMultiCollect : PM collection structure
 * @param[in]  mFamily : family to be collected
 * @param[in]  mActualFamily : actual family to be collected
 * @param[in]  mType : type to be collected
 * @return N/A
 */
void FnVCCB_CollectPmccSpCellSelectionFailure(
    callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int mType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pPmMultiCollect);
    VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    VALID_E_POINT_CHECK_VOID(pGnb);

    const bool isSgnbAddAllowedFamily { STAT_SGNB_ADD_PER_GNB_PER_DU != mActualFamily &&
                                        (STAT_SGNB_ADD_PER_GNB == mFamily ||
                                         STAT_SGNB_ADD_PER_GNB_PLMN == mFamily ||
                                         STAT_SGNB_ADD_PER_GNB_SPID_DU_ID == mFamily ||
                                         STAT_SGNB_ADD_PER_GNB_SPID_DU_ID_GLOBAL_ID == mFamily ||
                                         STAT_SGNB_ADD_PER_GNB_ECI_DU_ID == mFamily) };
    const bool isEndcAddFailWithSpCellSelectionFail { isSgnbAddAllowedFamily &&
                                                      StatEndcAddPrepFail_CpFail == mType &&
                                                      StatEndcAddPrepCpFail_SpCellSelFail == ptCi->endcAddCpFailDetailCause };

    if (true != isEndcAddFailWithSpCellSelectionFail)
    {
        return;
    }

    const uint8_t spCellSelFailCount = ptCi->spCellSelFailStats.num;

    if (0 == spCellSelFailCount)
    {
        return;
    }

    int typeIdPerCall = STAT_SGNB_ADD_PER_GNB_END;
    const int MAX_PRIORITY_MAP_SIZE = getSizeSpCellSelFailPerCandidateIndexMap();
    int typeIdPerCandidate[static_cast<std::size_t>(MAX_PRIORITY_MAP_SIZE)] = {0};

    for (uint8_t loop = 0; loop < spCellSelFailCount; ++loop)
    {
        const uint16_t cellId = ptCi->spCellSelFailStats.SpCellSelFailPerCandidateCell[loop].cellId;
        const enumStatSpCellSelectionFailCause_type cause = static_cast<enumStatSpCellSelectionFailCause_type>(
            ptCi->spCellSelFailStats.SpCellSelFailPerCandidateCell[loop].spCellSelFailure);

        if (StatEndcSpCellSelFail_MAX_STAT <= cause)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "%s - cause(%i) out of range! CellId(%d)\n", __FUNCTION__, cause, cellId);
            continue;
        }

        processPerCandidateCounters(ptCi, cause, typeIdPerCandidate, MAX_PRIORITY_MAP_SIZE);

        processPerCallCounters(ptCi, cause, typeIdPerCall);

        collectInternalCounters(ptCi, pGnb, cause, cellId);
    }

    collectCountersPerCandidate(pPmMultiCollect, mActualFamily, typeIdPerCandidate, MAX_PRIORITY_MAP_SIZE);

    // Collect counter per Call
    if (STAT_SGNB_ADD_PER_GNB_END != typeIdPerCall)
    {
        MACRO_STAT_PMCC_ADD_ITEM(pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily,
            typeIdPerCall, PME_LIB_CC, 1);
    }

    // Collect counter RejectedCandidate Total
    MACRO_STAT_PMCC_ADD_ITEM(pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily,
        EndcAddPrepFail_CpFail_SpCellSel_RejectedCandidate_Tot, PME_LIB_CC, spCellSelFailCount);
}

/**
 * @brief FGR-CC5000 Basic Operation for EN-DC
 *        FR:1122,1124,1125,1126,2400 Collect detailed CpFail counter
 * @param[in]  ptCi : callInfo
 * @param[out] pmMultiCollect : array of counters to be collected
 * @param[in]  mFamily : family to be collected
 * @param[in]  mActualFamily : actual family to be collected
 * @param[in]  mType : type to be collected
 * @return N/A
 */
void FnVCCB_CollectPmccAdditionalEndcAddDetailedCpFail(
    callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int mType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pPmMultiCollect);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    const bool isSgnbAddAllowedFamily { STAT_SGNB_ADD_PER_GNB == mFamily ||
                                        STAT_SGNB_ADD_PER_GNB_PLMN == mFamily ||
                                        STAT_SGNB_ADD_PER_GNB_SPID_DU_ID == mFamily ||
                                        STAT_SGNB_ADD_PER_GNB_SPID_DU_ID_GLOBAL_ID == mFamily ||
                                        STAT_SGNB_ADD_PER_GNB_ECI_DU_ID == mFamily };
    const bool isCpFailAllowedType { StatEndcAddPrepFail_CpFail == mType ||
                                     StatEndcAddFail_CpFail == mType };
    const bool isEndcAddCpFail { isSgnbAddAllowedFamily &&
                                 isCpFailAllowedType };

    if (false == isEndcAddCpFail)
    {
        return;
    }

    const enumStatEndcAddDetailedCpFail_type cause = ptCi->endcAddCpFailDetailCause;
    auto CpFailMap = getValueCpFailMap(cause);
    if (!CpFailMap.has_value())
    {
        return;
    }
    int typeId = CpFailMap.value();

    // Part of counters skipped for STAT_SGNB_ADD_PER_GNB_PER_DU
    StatisticsHandler statHandler(ptCi->gnbNum);
    statHandler.changeCounterTypeIdForDerivedFamilies(typeId, mActualFamily);

    // Collect internal counter per gNB and per cell
    if (cause < StatEndcAddCpFail_MAX_STAT)
    {
        ++pGnb->cfg.statEndcAddDetailedCpFail[cause];
        if (ptCi->servCellNum < MAX_CELL_NUM_VCCB)
        {
            VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];
            ++pCell->statEndcAddDetailedCpFail[cause];
        }
    }

    // Collect official counter
    MACRO_STAT_PMCC_ADD_ITEM(
        pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily, typeId, PME_LIB_CC, 1);
}

/**
 * @brief     if the flag is ATTEMPT_MADE or PREP_SUCCESS_MADE: return
 *            else if the flag is SUCCESS_FAIL_DECISION_MADE: add attempt info (and prepSucc info if needed) to the
 * pmMultiCollect structure before calling CollectPmStatistics, where attempt-prepSucc-succ/fail statistics are
 * collected at once
 */
template <typename AttemptFlag>
int16_t VLIB_AttemptBasedPmCCStatCollector(callInfo_type *ptCi, AttemptFlag *ptAttemptFlag, int mFamily,
    int mActualFamily, int mType, VccbPmMultiCollect_type *pPmMultiCollect, VccbPmKey_type *pPmKey)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pPmMultiCollect);
    VALID_E_POINT_CHECK_ERROR(pPmKey);

    int typeId_attempt = GetAttTypeId(ptCi, mFamily, mType);
    int typeId_prepSucc = GetPrepSuccTypeId(ptCi, mFamily, mType);

    // This function skips the actual processing operation when Attempt and Preparation are successful. (Batch
    // collection at the end)
    if ((ATTEMPT_MADE == *ptAttemptFlag) || (PREP_SUCCESS_MADE == *ptAttemptFlag))
    {
        // print log for state change
        if (DBG->flag.logOnFlow == YES)
        {
            switch (*ptAttemptFlag)
            {
                case ATTEMPT_MADE:
                    VCCB_PRINT_CRITICAL(
                        "State changed: NO_ATTEMPT -> ATTEMPT_MADE (mFam/mType/..) = "
                        "%d/%d/%llu/%llu/%llu/%llu/%llu/%llu\n",
                        mActualFamily, typeId_attempt, pPmKey->keyList[VCCB_PMKEY_INDEX1], pPmKey->keyList[VCCB_PMKEY_INDEX2], pPmKey->keyList[VCCB_PMKEY_INDEX3], pPmKey->keyList[VCCB_PMKEY_INDEX4],
                        pPmKey->keyList[VCCB_PMKEY_INDEX5], pPmKey->keyList[VCCB_PMKEY_INDEX6]);
                    break;
                case PREP_SUCCESS_MADE:
                    VCCB_PRINT_CRITICAL(
                        "State changed: ATTEMPT_MADE -> PREP_SUCCESS_MADE (mFam/mType/..) = "
                        "%d/%d/%llu/%llu/%llu/%llu/%llu/%llu\n",
                        mActualFamily, typeId_prepSucc, pPmKey->keyList[VCCB_PMKEY_INDEX1], pPmKey->keyList[VCCB_PMKEY_INDEX2], pPmKey->keyList[VCCB_PMKEY_INDEX3], pPmKey->keyList[VCCB_PMKEY_INDEX4],
                        pPmKey->keyList[VCCB_PMKEY_INDEX5], pPmKey->keyList[VCCB_PMKEY_INDEX6]);
                    break;
                default:
                    break;
            }
        }


        return BREAK;
    }

    // This procedure controls the Attempt and Preprataion collection operations when the Preaparation step fails or the
    // Exuction step fails.
    if ((SUCCESS_FAIL_DECISION_MADE == *ptAttemptFlag) || (SUCCESS_FAIL_DECISION_MADE_AFTER_PREP == *ptAttemptFlag))
    {
        // Attempt statistics
        MACRO_STAT_PMCC_ADD_ITEM(pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily,
            typeId_attempt, PME_LIB_CC, 1);

        // Additional Attempt statistics
        FnVCCB_CollectPmccAdditionalAttItems(ptCi, pPmMultiCollect, mFamily, mActualFamily, typeId_attempt);  // HO_STAT_23A

        if (SUCCESS_FAIL_DECISION_MADE_AFTER_PREP == *ptAttemptFlag)
        {
            // Prep Success statistics
            MACRO_STAT_PMCC_ADD_ITEM(pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily,
                typeId_prepSucc, PME_LIB_CC, 1);

            // Additional Prep Success statistics
            FnVCCB_CollectPmccAdditionalPrepSuccItems(ptCi, pPmMultiCollect, mFamily, mActualFamily, typeId_prepSucc);  // HO_STAT_23A
        }
    }

    return GOOD;
}

/**
 * @brief     translate family if to an index used for Erab case to check
 *            if Attempt at pegging statistic was already done
 * @param     mFamily : family id
 */
enumStatErabIndex translateErabFamilyToAttemptArrIndex(int mFamily)
{
    switch (mFamily)
    {
        case STAT_ERAB_ADD_PER_GNB:
            return ERAB_ADD_INDEX;

        case STAT_ERAB_MOD_PER_GNB:
            return ERAB_MOD_INDEX;

        default:
            return ERAB_END_INDEX;
    }
}

/**
 * @brief     translate family if to an index used for DRB case to check
 *            if Attempt at pegging statistic was already done
 * @param     mFamily : family id
 */
enumDRBstat_type translateDRBFamilyToAttemptArrIndex(int mFamily)
{
    switch (mFamily)
    {
        case STAT_DRB_SETUP:
            return DRB_SETUP;

        case STAT_DRB_SETUP_PLMN_SNSSAI:
            return DRB_SETUP_PLMN_SNSSAI;

        case STAT_DRB_SETUP_PLMN_SNSSAI_5QI:
            return DRB_SETUP_PLMN_SNSSAI_5QI;

        case STAT_DRB_SETUP_GLOBAL_ID_RFSP:
            return DRB_SETUP_GLOBAL_ID_RFSP;

        case STAT_PDU_SESSION_RESOURCE_MODIFY_REQUEST_DRB_SETUP:
            return DRB_SETUP_IN_PDUSESSION_MODIFY;

        case STAT_INITIAL_DRB_SETUP_DU_ID:
            return INITIAL_DRB_SETUP;

        case STAT_INITIAL_DRB_SETUP_DU_ID_PLMN_SNSSAI:
            return INITIAL_DRB_SETUP_PLMN_SNSSAI;

        case STAT_DRB_RELEASE_AND_ERASE:
            return DRB_RELEASE_AND_ERASE;

        case STAT_NEDC_DRB_SETUP:
            return NEDC_DRB_SETUP;

        // current assumption is SN originated modification is not supported
        case STAT_NEDC_DRB_MOD:
            return NEDC_DRB_MOD;

        default:
            return MAX_VCCB_DRB_STAT_FAMILY_TYPE;
    }
}

/**
 * @brief     translate family if to an index used for PDU case to check
 *            if Attempt at pegging statistic was already done
 * @param     mFamily : family id
 */
enumPDUstat_type translatePDUFamilyToAttemptArrIndex(int mFamily)
{
    switch (mFamily)
    {
        case STAT_PDU_SESSION_RESOURCE_SETUP_PLMN_SNSSAI:
            return PDU_SESSION_RESOURCE_SETUP_PLMN_SNSSAI;

        case STAT_PDU_SESSION_RESOURCE_MODIFY_PLMN_SNSSAI_RFSP:
            return PDU_SESSION_RESOURCE_MODIFY_PLMN_SNSSAI_RFSP;

        default:
            return MAX_VCCB_PDU_STAT_FAMILY_TYPE;
    }
}

/**
 * @brief     translate family if to an index used for QosFlow case to check
 *            if Attempt at pegging statistic was already done
 * @param     mFamily : family id
 */
enumQosFlowstat_type translateQosFlowFamilyToAttemptArrIndex(int mFamily)
{
    switch (mFamily)
    {
        case STAT_QOS_FLOW_SETUP:
            return QOS_FLOW_SETUP;

        case STAT_QOS_FLOW_SETUP_PLMN_SNSSAI:
            return QOS_FLOW_SETUP_PLMN_SNSSAI;

        default:
            return MAX_VCCB_QOS_FLOW_STAT_FAMILY_TYPE;
    }
}

/**
 * @brief           Collecting stat by pmSI_FLOAT
 * @param[in]       mFamily : statistic family / STAT_PM_FAMILY_ID_TYPE
 * @param[in]       mType : statistic type / STAT_DATA_USAGE_ITEM
 * @param[in/out]   ptCi : call information / callInfo_type
 * @return          None
 */
void VLIB_LibStatPmSI(int mFamily, int mType, callInfo_type *ptCi, float updateValue, int reserved3, uint64_t reserved4,
    uint64_t reserved5, uint64_t reserved6)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    UNUSED2(reserved5, reserved6);

    uint32_t uePlmnKey = 0;

    int mActualFamily = mFamily;

    VccbPmKey_type pmKey;
    memset(&pmKey, 0, sizeof(VccbPmKey_type));
    VccbPmMultiCollect_type pmMultiCollect;

    int shmStoreFlag = TRUE;

    FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_SI);

    if ((VCOM_getSystemType() == e_VCCB_ACPF_CNF) && (isSupportedStatisticFamilyForCNF(mFamily) == FALSE))
    {
        VCCB_PRINT_COMMENT("Skipped not supported statistics for 21A CNF(mFamily:%d, mType:%d)\n", mFamily, mType);
        return;
    }

    // PLMN_UE
    VLIB_ConvertPlmnIdToPlmnValue(&ptCi->ueInfo.servedPlmn.s2,
        &uePlmnKey);  // {mcc:450, mnc:05F} -> '45005', {mcc:320, mnc:120} -> '320120'

    switch (mFamily)
    {
        case STAT_RRC_CONN_INFO:
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;  // index1 - CPC
            pmKey.keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;
            break;

        case STAT_RRC_CONN_INFO_PC1_DU_ID:
        case STAT_RRC_CONN_INFO_PC15_DU_ID:
        case STAT_RRC_CONN_INFO_PC2_DU_ID:
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;  // CPC_ID, CP_ID
            pmKey.keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3], CELLINFO[ptCi->servCellNum].cellIdentity, MAX_GNB_PER_SYS); // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = CELLINFO[ptCi->servCellNum].cellIdentity;
            break;

        case STAT_RRC_CONN_INFO_PLMN:  // 20C  : SA && MOCN
            VCCB_CHECK_RANGE_AND_RETURN_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB, "ptCi->servCellNum");
            VCCB_CHECK_RANGE_AND_RETURN_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS, "ptCi->gnbNum");
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pmKey.keyList[VCCB_PMKEY_INDEX4] = uePlmnKey;
            break;

        case STAT_RRC_CONN_INFO_DU_ID_PLMN_RFSP:
            VCCB_CHECK_RANGE_AND_RETURN_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB, "ptCi->servCellNum");
            VCCB_CHECK_RANGE_AND_RETURN_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS, "ptCi->gnbNum");
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3], CELLINFO[ptCi->servCellNum].cellIdentity, MAX_GNB_PER_SYS); // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pmKey.keyList[VCCB_PMKEY_INDEX5] = uePlmnKey;
            pmKey.keyList[VCCB_PMKEY_INDEX6] = (unsigned)reserved3; // RFSP Value
            break;

        case STAT_NRDC_SN_CONN_INFO_MN:
        case STAT_NRDC_SN_CONN_INFO_SN:
            {
                VCCB_CHECK_RANGE_AND_RETURN_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB, "ptCi->servCellNum");
                VCCB_CHECK_RANGE_AND_RETURN_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS, "ptCi->gnbNum");
                pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;
                pmKey.keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
                /////////////////////////////////////////////////////////////////////////////////////////////////////
                uint16_t _cellIdentity = CELLINFO[ptCi->servCellNum].cellIdentity;
                mrdcStatistic::NrdcSnConnInfoStats_s &nrdcConnInfoStats = ptCi->mrdcInfo.stat.nrdcSnConnInfo;

                // this is protection code in mn side
                if (mFamily == STAT_NRDC_SN_CONN_INFO_MN && mType == NrdcMnHoldingTimeAvg &&
                        nrdcConnInfoStats.markedCellIdForConnNoAvg < MAX_CELL_IDENTITY)
                {
                    _cellIdentity = nrdcConnInfoStats.markedCellIdForConnNoAvg;
                }
                /////////////////////////////////////////////////////////////////////////////////////////////////////
                FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3], _cellIdentity, MAX_GNB_PER_SYS); // DU_ID
                pmKey.keyList[VCCB_PMKEY_INDEX4] = _cellIdentity;
                pmKey.keyList[VCCB_PMKEY_INDEX5] = uePlmnKey;
                pmKey.keyList[VCCB_PMKEY_INDEX6] = (unsigned)reserved3; // RFSP Value
            }
            break;

        case STAT_DRB_CONN_INFO:
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;  // index1 - CPC
            pmKey.keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pmKey.keyList[VCCB_PMKEY_INDEX4] = (unsigned)reserved3;  // 5QI
            break;

        case STAT_DRB_CONN_INFO_PLMN:
            VCCB_CHECK_RANGE_AND_RETURN_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB, "ptCi->servCellNum");
            VCCB_CHECK_RANGE_AND_RETURN_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS, "ptCi->gnbNum");
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pmKey.keyList[VCCB_PMKEY_INDEX4] = uePlmnKey;
            pmKey.keyList[VCCB_PMKEY_INDEX5] = (unsigned)reserved3;  // 5QI
            break;

        case STAT_RRC_CONN_INFO_REDCAP_PLMN:
        case STAT_CP_RRC_CONN_INFO_REDCAP_PLMN:
        {
            VCCB_CHECK_RANGE_AND_RETURN_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS, "ptCi->gnbNum");
            VCCB_CHECK_RANGE_AND_RETURN_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB, "ptCi->servCellNum");
            uint32_t cellPlmnKey = 0;
            VLIB_ConvertPlmnIdToPlmnValue(&GNBINFO[ptCi->gnbNum].globalGnbId.plmn.s2, &cellPlmnKey);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;                                                                                   // CPC_ID, CP_ID
            pmKey.keyList[VCCB_PMKEY_INDEX2] = cellPlmnKey;                                                                                      // PLMN
            pmKey.keyList[VCCB_PMKEY_INDEX3] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;                                                       // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX4], CELLINFO[ptCi->servCellNum].cellIdentity, MAX_GNB_PER_SYS); // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX5] = CELLINFO[ptCi->servCellNum].cellIdentity;                                                         // CellIdentity
            pmKey.keyList[VCCB_PMKEY_INDEX6] = uePlmnKey;                                                                                        // PLMN_UE
            break;
        }

        case STAT_DRB_CONN_INFO_REDCAP_PLMN:
        case STAT_CP_DRB_CONN_INFO_REDCAP_PLMN:
        {
            VCCB_CHECK_RANGE_AND_RETURN_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS, "ptCi->gnbNum");
            VCCB_CHECK_RANGE_AND_RETURN_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB, "ptCi->servCellNum");
            uint32_t cellPlmnKey = 0;
            VLIB_ConvertPlmnIdToPlmnValue(&GNBINFO[ptCi->gnbNum].globalGnbId.plmn.s2, &cellPlmnKey);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;                                                                                   // CPC_ID, CP_ID
            pmKey.keyList[VCCB_PMKEY_INDEX2] = cellPlmnKey;                                                                                      // PLMN
            pmKey.keyList[VCCB_PMKEY_INDEX3] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;                                                       // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX4], CELLINFO[ptCi->servCellNum].cellIdentity, MAX_GNB_PER_SYS); // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX5] = CELLINFO[ptCi->servCellNum].cellIdentity;                                                         // CellIdentity
            pmKey.keyList[VCCB_PMKEY_INDEX6] = uePlmnKey;                                                                                        // PLMN_UE
            pmKey.keyList[VCCB_PMKEY_INDEX7] = (unsigned)reserved3;                                                                              // 5QI
            pmKey.usageOfNumKey = CI_use;
            pmKey.numKey = VCCB_PMKEY_INDEX7 + 1;
            break;
        }

        case STAT_DRB_CONN_INFO_PLMN_SNSSAI:
        {
            VCCB_CHECK_RANGE_AND_RETURN_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS, "ptCi->gnbNum");
            VCCB_CHECK_RANGE_AND_RETURN_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB, "ptCi->servCellNum");
            uint32_t gnbPlmnKey = 0;
            VLIB_ConvertPlmnIdToPlmnValue(&GNBINFO[ptCi->gnbNum].globalGnbId.plmn.s2, &gnbPlmnKey);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;                                                                                   // CPC_ID, CP_ID
            pmKey.keyList[VCCB_PMKEY_INDEX2] = gnbPlmnKey;                                                                                       // PLMN
            pmKey.keyList[VCCB_PMKEY_INDEX3] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;                                                       // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX4], CELLINFO[ptCi->servCellNum].cellIdentity, MAX_GNB_PER_SYS); // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX5] = CELLINFO[ptCi->servCellNum].cellIdentity;                                                         // CellIdentity
            pmKey.keyList[VCCB_PMKEY_INDEX6] = uePlmnKey;                                                                                        // PLMN_UE
            pmKey.keyList[VCCB_PMKEY_INDEX7] = (unsigned)reserved4;                                                                              // SNSSAI
            pmKey.usageOfNumKey = CI_use;
            pmKey.numKey = VCCB_PMKEY_INDEX7 + 1;
            break;
        }

        case STAT_NRDC_SN_TERM_DRB_CONN_INFO:
            VCCB_CHECK_RANGE_AND_RETURN_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB, "ptCi->servCellNum");
            VCCB_CHECK_RANGE_AND_RETURN_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS, "ptCi->gnbNum");
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3],
                CELLINFO[ptCi->servCellNum].cellIdentity, MAX_GNB_PER_SYS);  // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pmKey.keyList[VCCB_PMKEY_INDEX5] = uePlmnKey;
            pmKey.keyList[VCCB_PMKEY_INDEX6] = (unsigned)reserved3;  // 5QI
            break;

        default:
            VCCB_PRINT_ERROR("Not a Stat family(%d) defined in VLIB_LibStatPmSI!\n", mFamily);
            return;  // Return on invalid mFamily
    }

    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    StatisticsHandler statHandler(ptCi->gnbNum);
    statHandler.changeFamilyAndIndex(ptCi, mActualFamily, pmKey);

    MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemFloatArr, pmMultiCollect.numOfItem, mActualFamily, mType,
        pmMultiCollect.updateMethod, updateValue);

    if(mActualFamily == STAT_CP_RRC_CONN_INFO_PLMN_RFSP_GLOBAL_ID)
    {
        pmKey.usageOfNumKey = CI_use;
    }

    CollectPmStatistics(
        ptCi, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemFloatArr, pmKey, shmStoreFlag);
}

/**
 * @brief     This function provides the behavior of converting PLMN Value to PLMN Key to be used in statistics.
 *            Example 1) 'plmnId_type 45005F' to 'uint32_t 45005'
 *            Example 2) 'plmnId_type 320120' to 'uint32_t 320120'
 * @param     plmnId_type *p_plmn_value : pointer of plmnId_type
 * @param     uint32_t *p_plmn_key : pointer of uint32_t
 */

void VLIB_ConvertPlmnIdToPlmnValue(s2_type *p_plmn_s2_value, uint32_t *p_plmn_key)
{
    VALID_E_POINT_CHECK_VOID(p_plmn_s2_value);
    VALID_E_POINT_CHECK_VOID(p_plmn_key);

    // init value
    *p_plmn_key = 0;

    // mcc
    uint32_t val = (((uint32_t)p_plmn_s2_value->mcc >> 0) & 0xF) + (((uint32_t)p_plmn_s2_value->mcc >> 4) & 0xF) * 10 +
                   (((uint32_t)p_plmn_s2_value->mcc >> 8) & 0xF) * 100;

    // mnc
    if ((p_plmn_s2_value->mnc & 0xF) == 0xF)  // mnc length is 2. { 05F , 06F , xxF }
    {
        val *= 100;

        val += (((uint32_t)p_plmn_s2_value->mnc >> 4) & 0xF) + (((uint32_t)p_plmn_s2_value->mnc >> 8) & 0xF) * 10;
    }
    else  // mnc length is 3. { 120, 150, 210 }
    {
        val *= 1000;

        val += (((uint32_t)p_plmn_s2_value->mnc >> 0) & 0xF) + (((uint32_t)p_plmn_s2_value->mnc >> 4) & 0xF) * 10 +
               (((uint32_t)p_plmn_s2_value->mnc >> 8) & 0xF) * 100;
    }

    *p_plmn_key = val;
}

// Do not call the function directly, use the macro below!!
//#define MACRO_STAT_PMSI_QCI(_mFam,_mType,_ptCi,_ptRi,updateValue,b,c,d)
void FnVCCB_LibStatPmSI_QCI(int mFamily, int mType, callInfo_type *ptCi, callERABInfo_type *ptRi, float updateValue,
    int reserved4, int reserved5, int reserved6)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptRi);
    UNUSED3(reserved4, reserved5, reserved6);

    int mActualFamily = mFamily;

    VccbPmKey_type pmKey;
    memset(&pmKey, 0, sizeof(VccbPmKey_type));
    VccbPmMultiCollect_type pmMultiCollect;

    int shmStoreFlag = TRUE;

    FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_SI);

    if ((VCOM_getSystemType() == e_VCCB_ACPF_CNF) && (isSupportedStatisticFamilyForCNF(mFamily) == FALSE))
    {
        VCCB_PRINT_COMMENT("Skipped not supported statistics for 21A CNF(mFamily:%d, mType:%d)\n", mFamily, mType);
        return;
    }

    switch (mFamily)
    {
        case STAT_ERAB_SPEC_INFO_PER_GNB_DU_ID:
            // ErabSpecInfo_"Cnt" would be counted as MACRO_STAT_PMCC_QCI vpmCC_FLOAT
            // ErabSpecInfo_"Time" would be counted as MACRO_STAT_PMSI_QCI vpmSI_FLOAT
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->endPointInfo.gnbDuId, MAX_GNB_DU_ID + 1);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;                              // CPC_ID
            pmKey.keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3],
                CELLINFO[ptCi->servCellNum].cellIdentity, ptCi->gnbNum);                    // gNB_DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = CELLINFO[ptCi->servCellNum].cellIdentity;    // CellIdentity
            if (reserved4 == USE_NEW_QCI)                               // QCI
            {
                pmKey.keyList[VCCB_PMKEY_INDEX5] = ptRi->erabQos.qciValue.QCI;
            }
            else
            {
                pmKey.keyList[VCCB_PMKEY_INDEX5] = ptRi->erabQos.qciValue.oldQCI;
            }
            break;

        default:
            VCCB_PRINT_ERROR("Not a Stat family(%d) defined in FnVCCB_LibStatPmSI_QCI!\n", mFamily);
            return;
    }
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    uint16_t gnbNum = ptCi->gnbNum;
    StatisticsHandler statHandler(gnbNum);
    statHandler.changeFamilyAndIndex(ptCi, mActualFamily, pmKey);

    MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemFloatArr, pmMultiCollect.numOfItem, mActualFamily, mType,
        pmMultiCollect.updateMethod, updateValue);

    CollectPmStatistics(
        ptCi, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemFloatArr, pmKey, shmStoreFlag);
}

/**
 * @brief       Collect pmCC_FLOAT statictic
 *
 * @param[in]       mFamily : statistic family / STAT_PM_FAMILY_ID_TYPE
 * @param[in]       mType : statistic type / STAT_DATA_USAGE_ITEM
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       updateValue: value to be updated (float)
 * @return          None
 */
// Do not call the function directly, use the macro below!!
//#define MACRO_STAT_PMCC_FLOAT(_mFam, _mType, _ptCi, _updateValue, a, b, c, d)
void VLIB_LibStatPmCC_FLOAT(int mFamily, int mType, callInfo_type *ptCi, float updateValue, int reserved3,
    int reserved4, int reserved5, int reserved6)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    UNUSED3(reserved4, reserved5, reserved6);

    uint16_t gnbNum = ptCi->gnbNum;
    VccbGnbInfo_type *pGnb = &GNBINFO[gnbNum];
    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];

    int mActualFamily = mFamily;

    VccbPmKey_type pmKey;
    memset(&pmKey, 0, sizeof(VccbPmKey_type));
    VccbPmMultiCollect_type pmMultiCollect;
    memset(&pmMultiCollect, 0x00, sizeof(VccbPmMultiCollect_type));
    pmMultiCollect.updateItemFloatArr->updateMethod = PME_LIB_CC;

    int shmStoreFlag = TRUE;

    switch (mFamily)
    {
        case STAT_MDT_CONFIGURATION_DELIVERY_DU_ID:
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;
            if (TRUE==VHCM_isSaHandoverUE(ptCi))
            {
                FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3],
                    ptCi->hoInfo.cellIdentity, ptCi->gnbNum);
                pmKey.keyList[VCCB_PMKEY_INDEX4] = ptCi->hoInfo.cellIdentity;
            }
            else
            {
                FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3],
                    pCell->cellIdentity, ptCi->gnbNum);
                pmKey.keyList[VCCB_PMKEY_INDEX4] = pCell->cellIdentity;
            }
            break;

        case STAT_SPCELL_CHG_TIME_VIA_SRB3:
            pmKey.keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id; // gNB_ID
            pmKey.keyList[VCCB_PMKEY_INDEX2] = ptCi->hoInfo.cellIdentity;                  // CellIdentity
            break;

        case STAT_SPCELL_CHG_TIME:
            pmKey.keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id; // gNB_ID
            pmKey.keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;   // CellIdentity
            break;

        case STAT_RRC_TIME_PER_GNB_DU_ID:
            pmKey.keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;          // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX2],
                pCell->cellIdentity, ptCi->gnbNum); // gNB_DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX3] = pCell->cellIdentity;                 // CellIdentity
            break;

        case STAT_RRC_TIME_PER_GNB_SPID_DU_ID:
            pmKey.keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;          // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX2],
                pCell->cellIdentity, ptCi->gnbNum);       // gNB_DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX3] = pCell->cellIdentity;                 // CellIdentity
            pmKey.keyList[VCCB_PMKEY_INDEX4] = (unsigned long long)reserved3;       // SPIDIncludingInvalid
            break;

        default:
            VCCB_PRINT_ERROR("Not a Stat family(%d) defined in VLIB_LibStatPmCC_FLOAT!\n", mFamily);
            return;
    }

    StatisticsHandler statHandler(gnbNum);
    statHandler.changeFamilyAndIndex(ptCi, mActualFamily, pmKey);

    if ((VCOM_getSystemType() == e_VCCB_ACPF_CNF) && (isSupportedStatisticFamilyForCNF(mActualFamily) == FALSE))
    {
        VCCB_PRINT_COMMENT("Skipped not supported statistics for CNF(mFamily:%d, mType:%d)\n", mActualFamily, mType);
        return;
    }

    VLIB_CollectAdditionalStatistic_FLOAT(mFamily, mActualFamily, mType, ptCi, updateValue, reserved3, reserved4, reserved5, reserved6);

    MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemFloatArr, pmMultiCollect.numOfItem, mActualFamily, mType,
        pmMultiCollect.updateMethod, updateValue);
    CollectPmStatistics(
        ptCi, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemFloatArr, pmKey, shmStoreFlag);
}

void VLIB_CollectAdditionalStatistic_QCI(int mFamily, int mActualFamily, int mType, callInfo_type *ptCi,
    callERABInfo_type *ptRi, int reserved3, int reserved4, int reserved5, int reserved6)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptRi);
    UNUSED1(mActualFamily);

    switch (mFamily)
    {
        case STAT_ERAB_ADD_PER_GNB:
            if (FOO.VF_BasicOperationforENDC_TLUOnlyCounterFamily)
            {
                MACRO_STAT_PMCC_QCI(
                    STAT_ERAB_ADD_PER_GNB_PLMN, mType, ptCi, ptRi, reserved3, reserved4, reserved5, reserved6);
            }
            if (FnVCCB_IsQciAndSpidStatSuppConfigured(ptCi, ptRi))
            {
                MACRO_STAT_PMCC_QCI(
                    STAT_ERAB_ADD_PER_GNB_SPID_DU_ID, mType, ptCi, ptRi, reserved3, reserved4, reserved5, reserved6);
            }
            break;

        case STAT_ERAB_REL_PER_GNB:
            if (FnVCCB_IsQciAndSpidStatSuppConfigured(ptCi, ptRi))
            {
                MACRO_STAT_PMCC_QCI(
                    STAT_ERAB_REL_PER_GNB_SPID_DU_ID, mType, ptCi, ptRi, reserved3, reserved4, reserved5, reserved6);
            }
            break;

        case STAT_ERAB_REL_ALL_PER_GNB_PLMN:
            if (FnVCCB_IsQciAndSpidStatSuppConfigured(ptCi, ptRi))
            {
                if (ptRi->usage == CI_use && GET_DRB_RELEASED_IN_SESSION_FLAG(ptRi->flag.setupFlag))
                {
                    MACRO_STAT_PMCC_QCI(STAT_ERAB_REL_ALL_PER_GNB_PLMN_SPID_ACT_DU_ID, mType, ptCi, ptRi, reserved3,
                        reserved4, reserved5, reserved6);
                }
                MACRO_STAT_PMCC_QCI(STAT_ERAB_REL_ALL_PER_GNB_PLMN_SPID_DU_ID, mType, ptCi, ptRi, reserved3, reserved4,
                    reserved5, reserved6);
            }
            break;

        default:
            break;
    }
}

/**
 * @brief       Collect statistics based on QCI
 *
 * @param[in]       mFamily : statistic family / STAT_PM_FAMILY_ID_TYPE
 * @param[in]       mType : statistic type / STAT_DATA_USAGE_ITEM
 * @param[in/out]   ptCi : call information / callInfo_type
 * @param[in/out]   ptRi : call ERAB information / callERABInfo_type
 * @return          None
 */

// Do not call the function directly, use the macro below!!
//#define MACRO_STAT_PMCC_QCI(_mFam,_mType,_ptCi,_ptRi,a,b,c,d)
void VLIB_LibStatPmCC_QCI(int mFamily, int mType, callInfo_type *ptCi, callERABInfo_type *ptRi, int reserved3,
    int reserved4, int reserved5, int reserved6, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptRi);
    VALID_E_POINT_CHECK_VOID(fnName);
    UNUSED4(reserved3, reserved4, reserved5, reserved6);

    int typeId_attempt = GetAttTypeId(ptCi, mFamily, mType);

    VccbPmKey_type pmKey;
    memset(&pmKey, 0, sizeof(VccbPmKey_type));
    VccbPmMultiCollect_type pmMultiCollect;

    unsigned long long updateValueUll = 0;
    float updateValueFloat = 0;
    int shmStoreFlag = FALSE;
    int16_t status = GOOD;
    uint32_t uePlmnKey = 0;

    enumStatErabIndex indexErabMfamily = ERAB_END_INDEX;
    int retVal;

    // Note: FRR-CC5004 SVR25A
    // For SN init bearer type modification statistics not designed yet.
    if (((SgNBInitBearerChangeToMcg_cmd == ptCi->stateCmd) ||
         (SgNBInitBearerChangeToMcg_cmd == ptCi->prevStateCmd)) &&
        ((STAT_ERAB_CHG_PER_GNB == mFamily) ||
         (STAT_ERAB_MOD_PER_GNB == mFamily)))
    {
        return;
    }

    FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_CC);

    if ((VCOM_getSystemType() == e_VCCB_ACPF_CNF) && (isSupportedStatisticFamilyForCNF(mFamily) == FALSE))
    {
        VCCB_PRINT_COMMENT("Skipped not supported statistics for 21A CNF(mFamily:%d, mType:%d)\n", mFamily, mType);
        return;
    }

    if (STAT_TYPE_ATTEMPT == FnVCCB_GetStatType(mFamily, typeId_attempt))
    {
        indexErabMfamily = translateErabFamilyToAttemptArrIndex(mFamily);
        if (ERAB_END_INDEX == indexErabMfamily)
        {
            VCCB_PRINT_ERROR("translateErabFamilyToAttemptArrIndex failed - wrong mFamily(%d)\n", mFamily);
            return;
        }

        retVal = CheckAttemptStatValidity(ptCi, &ptRi->erabStatistic.attemptFlag[indexErabMfamily], mFamily, mType);
        if (retVal != STAT_VALID)
        {
            VCCB_PRINT_COMMENT(
                "CheckAttemptStatValidity Error with cause: %d (mFamily:%d, mType:%d)!\n", retVal, mFamily, mType);
            return;
        }
    }

    switch (mFamily)
    {
        case STAT_ERAB_ADD_PER_GNB:
        case STAT_ERAB_MOD_PER_GNB:
        case STAT_ERAB_REL_PER_GNB:
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = ptRi->erabQos.qciValue.QCI;
            // For Bearer Type we assume that it is SN terminated
            pmKey.keyList[VCCB_PMKEY_INDEX4] = ptRi->bearerType;
            shmStoreFlag = TRUE;
            break;

        case STAT_ERAB_ADD_PER_GNB_PLMN:
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            // PLMN_UE
            uePlmnKey = 0;
            // {mcc:450, mnc:05F} -> '45005', {mcc:320, mnc:120} -> '320120'
            VLIB_ConvertPlmnIdToPlmnValue(&ptCi->ueInfo.servedPlmn.s2, &uePlmnKey);
            pmKey.keyList[VCCB_PMKEY_INDEX3] = uePlmnKey;
            pmKey.keyList[VCCB_PMKEY_INDEX4] = ptRi->erabQos.qciValue.QCI;
            // For Bearer Type we assume that it is SN terminated
            pmKey.keyList[VCCB_PMKEY_INDEX5] = ptRi->bearerType;
            shmStoreFlag = TRUE;
            break;

        case STAT_ERAB_REL_ALL_PER_GNB_PLMN:
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            // PLMN_UE
            uePlmnKey = 0;
            // {mcc:450, mnc:05F} -> '45005', {mcc:320, mnc:120} -> '320120'
            VLIB_ConvertPlmnIdToPlmnValue(&ptCi->ueInfo.servedPlmn.s2, &uePlmnKey);
            pmKey.keyList[VCCB_PMKEY_INDEX3] = uePlmnKey;
            pmKey.keyList[VCCB_PMKEY_INDEX4] = ptRi->erabQos.qciValue.QCI;
            shmStoreFlag = TRUE;
            break;

        case STAT_ERAB_REL_ALL_PER_GNB_PLMN_SPID_DU_ID:
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;          // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX2],
                CELLINFO[ptCi->servCellNum].cellIdentity, ptCi->gnbNum);                            // gNB_DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;            // CellIdentity
            uePlmnKey = 0;  //{mcc:450, mnc:05F} -> '45005', {mcc:320, mnc:120} -> '320120'
            VLIB_ConvertPlmnIdToPlmnValue(&ptCi->ueInfo.servedPlmn.s2, &uePlmnKey);
            pmKey.keyList[VCCB_PMKEY_INDEX4] = uePlmnKey;                                           // PLMN_UE
            pmKey.keyList[VCCB_PMKEY_INDEX5] = ptCi->ueInfo.rfsp.subscriberProfile;                 // SPIDIncludingInvalid
            pmKey.keyList[VCCB_PMKEY_INDEX6] = ptRi->erabQos.qciValue.QCI;                          // QCI
            shmStoreFlag = TRUE;
            break;

        case STAT_ERAB_REL_ALL_PER_GNB_PLMN_SPID_ACT_DU_ID:
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;          // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX2],
                CELLINFO[ptCi->servCellNum].cellIdentity, ptCi->gnbNum);                            // gNB_DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;            // CellIdentity
            uePlmnKey = 0;  //{mcc:450, mnc:05F} -> '45005', {mcc:320, mnc:120} -> '320120'
            VLIB_ConvertPlmnIdToPlmnValue(&ptCi->ueInfo.servedPlmn.s2, &uePlmnKey);
            pmKey.keyList[VCCB_PMKEY_INDEX4] = uePlmnKey;                                           // PLMN_UE
            pmKey.keyList[VCCB_PMKEY_INDEX5] = ptCi->ueInfo.rfsp.subscriberProfile;                 // SPIDIncludingInvalid
            pmKey.keyList[VCCB_PMKEY_INDEX6] = ptRi->erabQos.qciValue.QCI;                          // QCI
            pmKey.keyList[VCCB_PMKEY_INDEX7] = IN_SESSION_STATUS_ACTIVE;                            // InSessionStatus
            shmStoreFlag = TRUE;
            break;

        case STAT_ERAB_CHG_PER_GNB:
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = ptRi->erabQos.qciValue.QCI;
            // For Bearer Type Change we assume that both are SN terminated
            if (ptRi->bearerType == SPLIT_Bearer)
            {
                pmKey.keyList[VCCB_PMKEY_INDEX4] = ptRi->preveBearerType == MCG_Bearer ? MCG_SPLIT_Bearer : SCG_SPLIT_Bearer;
            }
            else
            {
                pmKey.keyList[VCCB_PMKEY_INDEX4] = ptRi->bearerType == MCG_Bearer ? SPLIT_MCG_Bearer : SPLIT_SCG_Bearer;
            }
            shmStoreFlag = TRUE;
            break;

        case STAT_DATA_USAGE_PER_GNB:
            if ((DL_NrSplitBearerDataVolume == mType) || (DL_NrScgBearerDataVolume == mType))
            {
                if (ptRi->dataUsage[0].useFlag) updateValueUll += ptRi->dataUsage[0].countDl;

                if (ptRi->dataUsage[1].useFlag) updateValueUll += ptRi->dataUsage[1].countDl;
            }
            else if ((UL_NrSplitBearerDataVolume == mType) || (UL_NrScgBearerDataVolume == mType))
            {
                if (ptRi->dataUsage[0].useFlag) updateValueUll += ptRi->dataUsage[0].countUl;

                if (ptRi->dataUsage[1].useFlag) updateValueUll += ptRi->dataUsage[1].countUl;
            }
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = ptRi->erabQos.qciValue.QCI;
            shmStoreFlag = TRUE;
            break;

        case STAT_ERAB_SPEC_INFO_PER_GNB_DU_ID:
            // ErabSpecInfo_"Cnt" would be counted as MACRO_STAT_PMCC_QCI vpmCC_FLOAT
            // ErabSpecInfo_"Time" would be counted as MACRO_STAT_PMSI_QCI vpmSI_FLOAT
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = CFG->vm.unitId;                              // CPC_ID
            pmKey.keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3],
                CELLINFO[ptCi->servCellNum].cellIdentity, ptCi->gnbNum); // gNB_DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = CELLINFO[ptCi->servCellNum].cellIdentity;    // CellIdentity
            pmKey.keyList[VCCB_PMKEY_INDEX5] = ptRi->erabQos.qciValue.QCI;                  // QCI
            shmStoreFlag = TRUE;
            updateValueFloat = 1.0;
            break;

        case STAT_ERAB_ADD_PER_GNB_SPID_DU_ID:
        {
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id; // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX2],
                CELLINFO[ptCi->servCellNum].cellIdentity, ptCi->gnbNum); // gNB_DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;   // CellIdentity
            pmKey.keyList[VCCB_PMKEY_INDEX4] = ptRi->erabQos.qciValue.QCI;                 // QCI
            pmKey.keyList[VCCB_PMKEY_INDEX5] = ptCi->ueInfo.rfsp.subscriberProfile;        // SPIDIncludingInvalid
            shmStoreFlag = TRUE;
            break;
        }

        case STAT_ERAB_REL_PER_GNB_SPID_DU_ID:
        {
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id; // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX2],
                CELLINFO[ptCi->servCellNum].cellIdentity, ptCi->gnbNum); // gNB_DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;   // CellIdentity
            pmKey.keyList[VCCB_PMKEY_INDEX4] = ptRi->erabQos.qciValue.QCI;                 // QCI
            pmKey.keyList[VCCB_PMKEY_INDEX5] = ptCi->ueInfo.rfsp.subscriberProfile;        // SPIDIncludingInvalid
            shmStoreFlag = TRUE;
            break;
        }

        default:
            VCCB_PRINT_ERROR("Not a Stat family(%d) defined in VLIB_LibStatPmCC_QCI!\n", mFamily);
            return;
    }

    int mActualFamily = mFamily;
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    uint16_t gnbNum = ptCi->gnbNum;
    StatisticsHandler statHandler(gnbNum);
    statHandler.changeFamilyAndIndex(ptCi, mActualFamily, pmKey);
    statHandler.changeCounterTypeIdForDerivedFamilies(mType, mActualFamily);

    VLIB_CollectAdditionalStatistic_QCI(mFamily, mActualFamily, mType, ptCi, ptRi, reserved3, reserved4, reserved5, reserved6);

    VLIB_StoreFailCauseHist(mFamily, mActualFamily, mType, ptCi, &pmKey, fnName);

    // To prevent mismatch of statistics, the Attempt and Success / Fail statistics are collected in the following
    // steps. A. When Attempt statistics are invoked, they are marked only in attemptFlag (Do not peg the actual
    // statistics) B. When Success / Fail statistics are invoked, they are pegged together.

    // Step A : exit the function
    if ((STAT_TYPE_ATTEMPT == FnVCCB_GetStatType(mFamily, typeId_attempt)) && (indexErabMfamily < MAX_VCCB_ERAB_FAMILY_TYPE))
    {
        status = VLIB_AttemptBasedPmCCStatCollector(ptCi, &ptRi->erabStatistic.attemptFlag[indexErabMfamily], mFamily,
            mActualFamily, mType, &pmMultiCollect, &pmKey);
        VCCB_RETURN_ON_CALL_VOID(ptCi, status,
            "VLIB_AttemptBasedPmCCStatCollector ERROR! %d/%d/%llu/%llu/%llu/%llu/%llu/%llu\n", mActualFamily, mType,
            pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2], pmKey.keyList[VCCB_PMKEY_INDEX3],
            pmKey.keyList[VCCB_PMKEY_INDEX4], pmKey.keyList[VCCB_PMKEY_INDEX5], pmKey.keyList[VCCB_PMKEY_INDEX6]);

        if (status == BREAK) return;

        // reset flag
        ptRi->erabStatistic.attemptFlag[indexErabMfamily] = NO_ATTEMPT;
    }

    // Step B : actual pegging is done
    if (CHECK_FAMILY_PMCC_ULL(mFamily))  // for DATA_USAGE_PER_GNB
    {
        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUllArr, pmMultiCollect.numOfItem, mActualFamily, mType,
            pmMultiCollect.updateMethod, updateValueUll);
        CollectPmStatistics(
            ptCi, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemUllArr, pmKey, shmStoreFlag);
    }
    else if(mFamily == STAT_ERAB_SPEC_INFO_PER_GNB_DU_ID)
    {
        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemFloatArr, pmMultiCollect.numOfItem, mActualFamily, mType,
            pmMultiCollect.updateMethod, updateValueFloat);

        CollectPmStatistics(
            ptCi, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemFloatArr, pmKey, shmStoreFlag);
    }
    else
    {
        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily, mType,
            pmMultiCollect.updateMethod, 1);
        CollectPmStatistics(
            ptCi, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemUintArr, pmKey, shmStoreFlag);
    }
}

/**
 * @brief       Collect statistics based on QosFlow
 *
 * @param[in]       mFamily : statistic family / STAT_PM_FAMILY_ID_TYPE
 * @param[in]       mType : statistic type / STAT_DATA_USAGE_ITEM
 * @param[in/out]   ptCi : call information / callInfo_type
 * @param[in/out]   ptQi : call QosFlow information / qosFlowInfo_type
 * @return          None
 */

void VLIB_LibStatPmCC_QosFlow(int mFamily, int mType, callInfo_type *ptCi, callPDUSessInfo_type *ptPi,
    qosFlowInfo_type *ptQi, int sliceFail, int statOption, int reserved6, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptQi);
    VALID_E_POINT_CHECK_VOID(fnName);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    UNUSED1(reserved6);

    // Only collected in MN Side.
    if(IS_NRDC_SN(ptCi)) return;
    uint16_t gnbNum = ptCi->gnbNum;
    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];
    VccbGnbInfo_type *pGnb = &GNBINFO[gnbNum];

    int typeId_attempt = GetAttTypeId(ptCi, mFamily, mType);

    VccbPmKey_type pmKey;
    memset(&pmKey, 0, sizeof(VccbPmKey_type));
    VccbPmMultiCollect_type pmMultiCollect;

    uint32_t uePlmnKey = 0;
    VLIB_ConvertPlmnIdToPlmnValue(&ptCi->ueInfo.servedPlmn.s2,
        &uePlmnKey);  // {mcc:450, mnc:05F} -> '45005', {mcc:320, mnc:120} -> '320120'

    enumQosFlowstat_type indexQosFlowStatfamily = MAX_VCCB_QOS_FLOW_STAT_FAMILY_TYPE;
    int retVal;
    uint8_t fiveQi = 0;
    int16_t status = GOOD;

    FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_CC);

    if (STAT_TYPE_ATTEMPT == FnVCCB_GetStatType(mFamily, typeId_attempt))
    {
        indexQosFlowStatfamily = translateQosFlowFamilyToAttemptArrIndex(mFamily);
        if (MAX_VCCB_QOS_FLOW_STAT_FAMILY_TYPE == indexQosFlowStatfamily)
        {
            VCCB_PRINT_ERROR("translateQosFlowFamilyToAttemptArrIndex failed - wrong family mFamily(%d)\n", mFamily);
            return;
        }

        retVal =
            CheckAttemptStatValidity(ptCi, &ptQi->qosFlowStatistic.attemptFlag[indexQosFlowStatfamily], mFamily, mType);
        if (retVal != STAT_VALID)
        {
            VCCB_PRINT_COMMENT(
                "CheckAttemptStatValidity Error with cause: %d (mFamily:%d, mType:%d)!\n", retVal, mFamily, mType);
            return;
        }
    }

    switch (mFamily)
    {
        case STAT_QOS_FLOW_SETUP:
            pmKey.keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pCell->cellIdentity;
            VLIB_getFiveQi(ptQi, &fiveQi);
            pmKey.keyList[VCCB_PMKEY_INDEX3] = fiveQi;
            break;

        case STAT_QOS_FLOW_SETUP_PLMN_SNSSAI:
            pmKey.keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pCell->cellIdentity;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = uePlmnKey;
            pmKey.keyList[VCCB_PMKEY_INDEX4] = ptPi->sNssai.sstSd;
            break;

        default:
            VCCB_PRINT_ERROR("Not a Stat family(%d) defined in VLIB_LibStatPmCC_QosFlow!\n", mFamily);
            return;
    }

    int mActualFamily = mFamily;

    StatisticsHandler statHandler(gnbNum);
    statHandler.changeFamilyAndIndex(ptCi, mActualFamily, pmKey);

    VLIB_StoreFailCauseHist(mFamily, mActualFamily, mType, ptCi, &pmKey, fnName);  //<====

    // To prevent mismatch of statistics, the Attempt and Success / Fail statistics are collected in the following
    // steps. A. When Attempt statistics are invoked, they are marked only in attemptFlag (Do not peg the actual
    // statistics) B. When Success / Fail statistics are invoked, they are pegged together.

    // Step A : exit the function
    if (STAT_TYPE_ATTEMPT == FnVCCB_GetStatType(mFamily, typeId_attempt))
    {
        status = VLIB_AttemptBasedPmCCStatCollector(ptCi, &ptQi->qosFlowStatistic.attemptFlag[indexQosFlowStatfamily],
            mFamily, mActualFamily, mType, &pmMultiCollect, &pmKey);
        VCCB_RETURN_ON_CALL_VOID(ptCi, status,
            "VLIB_AttemptBasedPmCCStatCollector ERROR! %d/%d/%llu/%llu/%llu/%llu/%llu/%llu\n", mActualFamily, mType,
            pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2], pmKey.keyList[VCCB_PMKEY_INDEX3], pmKey.keyList[VCCB_PMKEY_INDEX4], pmKey.keyList[VCCB_PMKEY_INDEX5], pmKey.keyList[VCCB_PMKEY_INDEX6]);

        if (status == BREAK) return;

        // reset flag
        ptQi->qosFlowStatistic.attemptFlag[indexQosFlowStatfamily] = NO_ATTEMPT;
    }

    // Step B : actual pegging is done
    MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily, mType,
        pmMultiCollect.updateMethod, 1);

    if(sliceFail == VCCB_FLAG_ON)
    {
        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily,
            QosFlowSetupFail_SliceReject, pmMultiCollect.updateMethod, 1); // TODO: Check Final Name of QosFlowSetupFail_SliceReject.
    }

    /* Check isLteFallbackTriggered */
    if(statOption == COLLECT_ADDITIONAL_InteractionWithOtherProcedure)
    {
        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily,
            QosFlowSetupFail_InteractionWithOtherProcedure, pmMultiCollect.updateMethod, 1);
    }
    else
    {
        if(ptQi->isLteFallbackTriggered == VCCB_FLAG_ON)
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily,
                QosFlowSetupFail_LteFBTriggered, pmMultiCollect.updateMethod, 1);
        }
    }

    CollectPmStatistics(ptCi, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemUintArr, pmKey, TRUE);
}

/**
 * @brief       Collect statistics based on DRB
 *
 * @param[in]       mFamily : statistic family / STAT_PM_FAMILY_ID_TYPE
 * @param[in]       mType : statistic type / STAT_DATA_USAGE_ITEM
 * @param[in/out]   ptCi : call information / callInfo_type
 * @param[in/out]   ptDi : call DRB information / callDRBInfo_type
 * @return          None
 */

// Do not call the function directly, use the macro below!!
//#define MACRO_STAT_PMCC_DRB(_mFam,_mType,_ptCi,_ptRi,a,b,c,d)
void VLIB_LibStatPmCC_DRB(int mFamily, int mType, callInfo_type *ptCi, callDRBInfo_type *ptDi, int additionalOption,
    int reserved4, int reserved5, uint64_t inputUint64Val, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptDi);
    VALID_E_POINT_CHECK_VOID(fnName);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    UNUSED2(reserved4, reserved5);

    // Only collected in MN Side.
    if(IS_NRDC_SN(ptCi)) return;
    uint16_t gnbNum = ptCi->gnbNum;
    VccbGnbInfo_type *pGnb = &GNBINFO[gnbNum];
    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];
    uint32_t cellPlmnKey = 0;
    uint32_t gnbPlmn = 0;
    uint16_t rfspVal = 0;

    int typeId_attempt = GetAttTypeId(ptCi, mFamily, mType);

    VccbPmKey_type pmKey;
    memset(&pmKey, 0, sizeof(VccbPmKey_type));
    VccbPmMultiCollect_type pmMultiCollect;

    uint32_t uePlmnKey = 0;
    VLIB_ConvertPlmnIdToPlmnValue(&ptCi->ueInfo.servedPlmn.s2,
        &uePlmnKey);  // {mcc:450, mnc:05F} -> '45005', {mcc:320, mnc:120} -> '320120'

    uint8_t fiveQi = 0;
    enumDRBstat_type indexDrbStatfamily = MAX_VCCB_DRB_STAT_FAMILY_TYPE;

    unsigned long long updateValueUll = 0;

    int retVal;
    int16_t status = GOOD;

    FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_CC);

    // Only Collected in case of Basic Call
    switch (mFamily)
    {
        // Collected on Basic Attach Scenario(Initial Attach, PDU Session Setup/Modify/Release, UE Context Release)
        // Remove Check DRB SETUP, That is already checked in attach side.
        case STAT_DRB_RELEASE_AND_ERASE:
            if ((VHCM_isSaHandoverUE(ptCi) == TRUE) || (ptCi->stateCmd == RrcReestablish_cmd) ||
                (ptCi->stateCmd == RRCResume_cmd))
            {
                return;
            }
            break;
        case STAT_NEDC_DRB_SETUP:
            if ((VHCM_isSaHandoverUE(ptCi) == TRUE) || (ptCi->stateCmd == RrcReestablish_cmd))
            {
                return;
            }
            break;

        default:
            break;
    }

    if (STAT_TYPE_ATTEMPT == FnVCCB_GetStatType(mFamily, typeId_attempt))
    {
        indexDrbStatfamily = translateDRBFamilyToAttemptArrIndex(mFamily);
        if (MAX_VCCB_DRB_STAT_FAMILY_TYPE == indexDrbStatfamily)
        {
            VCCB_PRINT_ERROR("translateDRBFamilyToAttemptArrIndex failed - wrong family mFamily(%d)\n", mFamily);
            return;
        }

        retVal = CheckAttemptStatValidity(ptCi, &ptDi->drbStatistic.attemptFlag[indexDrbStatfamily], mFamily, mType);
        if (retVal != STAT_VALID)
        {
            VCCB_PRINT_COMMENT(
                "CheckAttemptStatValidity Error with cause: %d (mFamily:%d, mType:%d)!\n", retVal, mFamily, mType);
            return;
        }
    }

    switch (mFamily)
    {
        case STAT_DRB_SETUP:
        case STAT_PDU_SESSION_RESOURCE_MODIFY_REQUEST_DRB_SETUP:
        case STAT_NEDC_DRB_SETUP:
        case STAT_DRB_RELEASE_AND_ERASE:
        case STAT_NEDC_DRB_MOD:
        case STAT_NEDC_DRB_REL:
            if (ptDi->drbQosIdxInCall >= MAX_QOS_FLOW_PER_CALL)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "VLIB_LibStatPmCC_DRB invalid drbQosIdxInCall for STAT_DRB_SETUP statistics (E - %d)\n",
                    ptDi->drbQosIdxInCall);
                return;
            }
            VLIB_getFiveQi(&ptCi->qosFlow[ptDi->drbQosIdxInCall], &fiveQi);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pCell->cellIdentity;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = fiveQi;  // pmCC 5QI index
            break;

        case STAT_DRB_SETUP_PLMN_SNSSAI:
            VCCB_CHECK_E_RANGE_AND_VOID(ptDi->pduIdxInCall, MAX_PDU_SESS_PER_CALL);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pCell->cellIdentity;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = uePlmnKey;
            pmKey.keyList[VCCB_PMKEY_INDEX4] = ptCi->pduSess[ptDi->pduIdxInCall].sNssai.sstSd;
            break;

        case STAT_DRB_SETUP_PLMN_SNSSAI_5QI:
            VCCB_CHECK_E_RANGE_AND_VOID(ptDi->pduIdxInCall, MAX_PDU_SESS_PER_CALL);
            if (ptDi->drbQosIdxInCall >= MAX_QOS_FLOW_PER_CALL)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "VLIB_LibStatPmCC_DRB invalid drbQosIdxInCall for STAT_DRB_SETUP_PLMN_SNSSAI_5QI statistics (E - %d)\n",
                    ptDi->drbQosIdxInCall);
                return;
            }
            VLIB_getFiveQi(&ptCi->qosFlow[ptDi->drbQosIdxInCall], &fiveQi);
            VLIB_ConvertPlmnIdToPlmnValue(&GNBINFO[ptCi->gnbNum].globalGnbId.plmn.s2, &cellPlmnKey);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = cellPlmnKey;                                    // PLMN
            pmKey.keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;     // gNB_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = CELLINFO[ptCi->servCellNum].cellIdentity;       // CellIdentity
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3], (uint16_t)pmKey.keyList[VCCB_PMKEY_INDEX4], MAX_GNB_PER_SYS); // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX5] = uePlmnKey;
            pmKey.keyList[VCCB_PMKEY_INDEX6] = ptCi->pduSess[ptDi->pduIdxInCall].sNssai.sstSd;
            pmKey.keyList[VCCB_PMKEY_INDEX7] = fiveQi;  // pmCC 5QI index

            pmKey.usageOfNumKey = CI_use;
            pmKey.numKey = VCCB_PMKEY_INDEX7 + 1; // MAX_VCCB_STAT_KEY_NUM (7)
            break;

        case STAT_DRB_SETUP_GLOBAL_ID_RFSP:
            if (ptDi->drbQosIdxInCall >= MAX_QOS_FLOW_PER_CALL)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "VLIB_LibStatPmCC_DRB invalid drbQosIdxInCall for STAT_DRB_SETUP statistics (E - %d)\n",
                    ptDi->drbQosIdxInCall);
                return;
            }
            VLIB_getFiveQi(&ptCi->qosFlow[ptDi->drbQosIdxInCall], &fiveQi);
            VLIB_ConvertPlmnIdToPlmnValue(&GNBINFO[ptCi->gnbNum].globalGnbId.plmn.s2, &gnbPlmn);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = gnbPlmn;                                        // PLMN
            pmKey.keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;     // gNB_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = CELLINFO[ptCi->servCellNum].cellIdentity;       // CellIdentity
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3], (uint16_t)pmKey.keyList[VCCB_PMKEY_INDEX4], MAX_GNB_PER_SYS); // DU_ID
            FnVCCB_GetRfspStatValueFromYang(ptCi, rfspVal);
            pmKey.keyList[VCCB_PMKEY_INDEX5] = rfspVal; // RFSPIncludingInvalid
            pmKey.keyList[VCCB_PMKEY_INDEX6] = fiveQi;  // pmCC 5QI index
            break;

        case STAT_INITIAL_DRB_SETUP_DU_ID: // Basically include DU_ID
            if (ptDi->drbQosIdxInCall >= MAX_QOS_FLOW_PER_CALL)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "VLIB_LibStatPmCC_DRB invalid drbQosIdxInCall for STAT_DRB_SETUP statistics (E - %d)\n",
                    ptDi->drbQosIdxInCall);
                return;
            }
            VLIB_getFiveQi(&ptCi->qosFlow[ptDi->drbQosIdxInCall], &fiveQi);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = pCell->cellIdentity;
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX2], (uint16_t)pmKey.keyList[VCCB_PMKEY_INDEX3], MAX_GNB_PER_SYS); // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = fiveQi;  // pmCC 5QI index
            break;

        case STAT_INITIAL_DRB_SETUP_DU_ID_PLMN_SNSSAI: // Basically include DU_ID
            VCCB_CHECK_E_RANGE_AND_VOID(ptDi->pduIdxInCall, MAX_PDU_SESS_PER_CALL);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = pCell->cellIdentity;
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX2], (uint16_t)pmKey.keyList[VCCB_PMKEY_INDEX3], MAX_GNB_PER_SYS); // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = uePlmnKey;
            pmKey.keyList[VCCB_PMKEY_INDEX5] = ptCi->pduSess[ptDi->pduIdxInCall].sNssai.sstSd;
            break;

        case STAT_ACTIVITY_INFO_DU_ID_PLMN:
            VCCB_CALL_CHECK_RANGE_AND_RETURN_VOID(ptCi, ptDi->drbQosIdxInCall, MAX_QOS_FLOW_PER_CALL, "drbQosIdxInCall");
            VLIB_getFiveQi(&ptCi->qosFlow[ptDi->drbQosIdxInCall], &fiveQi);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = pCell->cellIdentity;
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX2], (uint16_t)pmKey.keyList[VCCB_PMKEY_INDEX3], MAX_GNB_PER_SYS); // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = uePlmnKey;
            pmKey.keyList[VCCB_PMKEY_INDEX5] = fiveQi;  // pmCC 5QI index
            updateValueUll = inputUint64Val;
            break;

        case STAT_ACTIVITY_INFO_DU_ID_PLMN_SNSSAI:
            VCCB_CHECK_E_RANGE_AND_VOID(ptDi->pduIdxInCall, MAX_PDU_SESS_PER_CALL);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = pCell->cellIdentity;
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX2], (uint16_t)pmKey.keyList[VCCB_PMKEY_INDEX3], MAX_GNB_PER_SYS); // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = uePlmnKey;
            pmKey.keyList[VCCB_PMKEY_INDEX5] = ptCi->pduSess[ptDi->pduIdxInCall].sNssai.sstSd;
            updateValueUll = inputUint64Val;
            break;

        case STAT_ACTIVITY_INFO_GLOBAL_ID_PLMN: // MSO Only
            VCCB_CALL_CHECK_RANGE_AND_RETURN_VOID(ptCi, ptDi->drbQosIdxInCall, MAX_QOS_FLOW_PER_CALL, "drbQosIdxInCall");
            VLIB_getFiveQi(&ptCi->qosFlow[ptDi->drbQosIdxInCall], &fiveQi);
            VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &cellPlmnKey);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = cellPlmnKey; // PLMN
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = pCell->cellIdentity;
            pmKey.keyList[VCCB_PMKEY_INDEX4] = uePlmnKey;
            pmKey.keyList[VCCB_PMKEY_INDEX5] = fiveQi;  // pmCC 5QI index
            updateValueUll = inputUint64Val;
            break;

        case STAT_ACTIVITY_INFO_SERVICE_TYPE: // SVR26A
            VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &cellPlmnKey);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = cellPlmnKey;                 // PLMN
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;  // gNB ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3], pCell->cellIdentity, MAX_GNB_PER_SYS); // gNB DU ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = pCell->cellIdentity;         // Cell Identity
            pmKey.keyList[VCCB_PMKEY_INDEX5] = 0;                           // Service Type
            updateValueUll = inputUint64Val;
            break;

        case STAT_ACTIVITY_INFO_PLMN_SNSSAI_5QI:  // JIO Only
            VCCB_CALL_CHECK_RANGE_AND_RETURN_VOID(ptCi, ptDi->pduIdxInCall, MAX_PDU_SESS_PER_CALL, "pduIdxInCall");
            VCCB_CALL_CHECK_RANGE_AND_RETURN_VOID(ptCi, ptDi->drbQosIdxInCall, MAX_QOS_FLOW_PER_CALL, "drbQosIdxInCall");
            VLIB_getFiveQi(&ptCi->qosFlow[ptDi->drbQosIdxInCall], &fiveQi);
            VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &cellPlmnKey);

            pmKey.keyList[VCCB_PMKEY_INDEX1] = cellPlmnKey;                 // PLMN
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;  // GNB ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3], pCell->cellIdentity, MAX_GNB_PER_SYS);  // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = pCell->cellIdentity;
            pmKey.keyList[VCCB_PMKEY_INDEX5] = uePlmnKey;
            pmKey.keyList[VCCB_PMKEY_INDEX6] = ptCi->pduSess[ptDi->pduIdxInCall].sNssai.sstSd;
            pmKey.keyList[VCCB_PMKEY_INDEX7] = fiveQi;
            updateValueUll = inputUint64Val;

            pmKey.usageOfNumKey = CI_use;
            pmKey.numKey = VCCB_PMKEY_INDEX7 + 1;  // 7
            break;

        default:
            VCCB_PRINT_ERROR("Not a Stat family(%d) defined in VLIB_LibStatPmCC_DRB!\n", mFamily);
            return;
    }

    VccbPmKey_type orgPmKey = pmKey; // for STAT_ACTIVITY_INFO_SERVICE_TYPE.

    int mActualFamily = mFamily;
    StatisticsHandler statHandler(gnbNum);
    statHandler.changeFamilyAndIndex(ptCi, mActualFamily, pmKey);

    VLIB_StoreFailCauseHist(mFamily, mActualFamily, mType, ptCi, &pmKey, fnName);

    // To prevent mismatch of statistics, the Attempt and Success / Fail statistics are collected in the following
    // steps. A. When Attempt statistics are invoked, they are marked only in attemptFlag (Do not peg the actual
    // statistics) B. When Success / Fail statistics are invoked, they are pegged together.

    // Step A : exit the function
    if ((STAT_TYPE_ATTEMPT == FnVCCB_GetStatType(mFamily, typeId_attempt)) && (indexDrbStatfamily < MAX_VCCB_DRB_STAT_FAMILY_TYPE))
    {
        status = VLIB_AttemptBasedPmCCStatCollector(ptCi, &ptDi->drbStatistic.attemptFlag[indexDrbStatfamily], mFamily,
            mActualFamily, mType, &pmMultiCollect, &pmKey);
        VCCB_RETURN_ON_CALL_VOID(ptCi, status,
            "VLIB_AttemptBasedPmCCStatCollector ERROR! %d/%d/%llu/%llu/%llu/%llu/%llu/%llu\n", mActualFamily, mType,
            pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2], pmKey.keyList[VCCB_PMKEY_INDEX3],
            pmKey.keyList[VCCB_PMKEY_INDEX4], pmKey.keyList[VCCB_PMKEY_INDEX5], pmKey.keyList[VCCB_PMKEY_INDEX6]);

        if (status == BREAK) return;

        // reset flag
        ptDi->drbStatistic.attemptFlag[indexDrbStatfamily] = NO_ATTEMPT;
    }

    // Step B : actual pegging is done
    if (CHECK_FAMILY_PMCC_ULL(mFamily))  // for ACTIVITY_INFO_PLMN
    {
        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUllArr, pmMultiCollect.numOfItem, mActualFamily, mType,
            pmMultiCollect.updateMethod, updateValueUll);

        if(mFamily == STAT_ACTIVITY_INFO_SERVICE_TYPE)
        {
            // STAT_ACTIVITY_INFO_SERVICE_TYPE is called Directly in StoreRemovedDrbInSessionTimeAndStat()
            FnVCCB_CollectNrRetainServiceType(ptCi, mFamily, ptDi, &pmMultiCollect, orgPmKey);
        }
        else
        {
            CollectPmStatistics(
                ptCi, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemUllArr, pmKey, TRUE);
        }
    }
    else
    {
        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily, mType,
            pmMultiCollect.updateMethod, 1);

        int failCauseCslVal = 0;
        if(mType >= DrbSetupFail_CpFail) // Set Basic Cause
        {
            failCauseCslVal = mType;
        }

        // Check DU Voice Not Support
        if(additionalOption & DRB_STAT_ADDITIONAL_DuVoice5QINotSupport)
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily,
                DrbSetupFail_F1Fail_NotSupport_5QI1, pmMultiCollect.updateMethod, 1);
            failCauseCslVal = failCauseCslVal + FAIL_CAUSE_VONR_CSL_DU_5QI_NOT_SUPPORT_OFFSET; // 10
        }

        // Check Slice Not Support
        if(additionalOption & DRB_STAT_ADDITIONAL_RxNotSupportSlice)
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily,
                DrbSetupFail_SliceReject, pmMultiCollect.updateMethod, 1); // TODO: Check Final Name of DrbSetupFail_SliceReject.
            failCauseCslVal = failCauseCslVal + FAIL_CAUSE_VONR_CSL_SLICE_REJECT_OFFSET; // 100
        }

        // Check isLteFallbackTriggered
        if( additionalOption & DRB_STAT_ADDITIONAL_LteFallbackTriggered)
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily,
                DrbSetupFail_LteFBTriggered, pmMultiCollect.updateMethod, 1);
        }

        CollectPmStatistics(
            ptCi, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemUintArr, pmKey, TRUE);
        // DRB Stat CSL
        FnVCCB_CollectStatCSL_DrbSetup(ptCi, fiveQi, mFamily, mType, static_cast<uint16_t>(failCauseCslVal));
    }
}

/**
 * @brief       Collect statistics based on PDU
 *
 * @param[in]       mFamily : statistic family / STAT_PM_FAMILY_ID_TYPE
 * @param[in]       mType : statistic type / STAT_DATA_USAGE_ITEM
 * @param[in/out]   ptCi : call information / callInfo_type
 * @param[in/out]   ptPi : call PDU information / callPDUInfo_type
 * @return          None
 */

// Do not call the function directly, use the macro below!!
//#define MACRO_STAT_PMCC_PDU(_mFam,_mType,_ptCi,_ptRi,a,b,c,d)
void VLIB_LibStatPmCC_PDU(int mFamily, int mType, callInfo_type *ptCi, callPDUSessInfo_type *ptPi, int sliceFail,
    int statOption, int reserved5, int reserved6, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptPi);
    VALID_E_POINT_CHECK_VOID(fnName);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    UNUSED2(reserved5, reserved6);

    uint16_t gnbNum = ptCi->gnbNum;
    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];
    VccbGnbInfo_type *pGnb = &GNBINFO[gnbNum];

    int typeId_attempt = GetAttTypeId(ptCi, mFamily, mType);

    VccbPmKey_type pmKey;
    memset(&pmKey, 0, sizeof(VccbPmKey_type));
    VccbPmMultiCollect_type pmMultiCollect;

    uint32_t uePlmnKey = 0;
    VLIB_ConvertPlmnIdToPlmnValue(&ptCi->ueInfo.servedPlmn.s2,
        &uePlmnKey);  // {mcc:450, mnc:05F} -> '45005', {mcc:320, mnc:120} -> '320120'

    uint32_t gnbPlmn = 0;
    uint16_t rfspVal = 0;
    callSNSSAI_type sNssai;

    enumPDUstat_type indexPduStatfamily = MAX_VCCB_PDU_STAT_FAMILY_TYPE;
    int retVal;
    int16_t status = GOOD;

    // Only collected in MN Side.
    if(IS_NRDC_SN(ptCi)) return;

    FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_CC);

    if (STAT_TYPE_ATTEMPT == FnVCCB_GetStatType(mFamily, typeId_attempt))
    {
        indexPduStatfamily = translatePDUFamilyToAttemptArrIndex(mFamily);
        if (MAX_VCCB_PDU_STAT_FAMILY_TYPE == indexPduStatfamily)
        {
            VCCB_PRINT_ERROR("translatePDUFamilyToAttemptArrIndex failed - wrong family mFamily(%d)\n", mFamily);
            return;
        }

        retVal = CheckAttemptStatValidity(ptCi, &ptPi->pduStatistic.attemptFlag[indexPduStatfamily], mFamily, mType);
        if (retVal != STAT_VALID)
        {
            VCCB_PRINT_COMMENT(
                "CheckAttemptStatValidity Error with cause: %d (mFamily:%d, mType:%d)!\n", retVal, mFamily, mType);
            return;
        }
    }

    switch (mFamily)
    {
        case STAT_PDU_SESSION_RESOURCE_SETUP_PLMN_SNSSAI:
            pmKey.keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pCell->cellIdentity;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = uePlmnKey;
            pmKey.keyList[VCCB_PMKEY_INDEX4] = ptPi->sNssai.sstSd;
            break;

        case STAT_PDU_SESSION_RESOURCE_MODIFY_PLMN_SNSSAI_RFSP:
            VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &gnbPlmn);
            pmKey.keyList[VCCB_PMKEY_INDEX1] = gnbPlmn;                                                                     // PLMN
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;                                                  // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pmKey.keyList[VCCB_PMKEY_INDEX3], pCell->cellIdentity, MAX_GNB_PER_SYS); // DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = pCell->cellIdentity;                                                         // CellIdentity
            pmKey.keyList[VCCB_PMKEY_INDEX5] = uePlmnKey;                                                                   // PLMN_UE
            FnVCCB_GetSliceValWithReqVal(ptPi, &sNssai); // Get Slice Val
            pmKey.keyList[VCCB_PMKEY_INDEX6] = sNssai.sstSd;                                                                // Slice
            FnVCCB_GetRfspStatValueFromYang(ptCi, rfspVal); // Get Rfsp Val
            pmKey.keyList[VCCB_PMKEY_INDEX7] = rfspVal;                                                                     // RFSP

            pmKey.usageOfNumKey = CI_use;
            pmKey.numKey = VCCB_PMKEY_INDEX7 + 1; // MAX_VCCB_STAT_KEY_NUM (7)
            break;

        default:
            VCCB_PRINT_ERROR("Not a Stat family(%d) defined in VLIB_LibStatPmCC_PDU!\n", mFamily);
            return;
    }

    int mActualFamily = mFamily;
    StatisticsHandler statHandler(gnbNum);
    statHandler.changeFamilyAndIndex(ptCi, mActualFamily, pmKey);

    VLIB_StoreFailCauseHist(mFamily, mActualFamily, mType, ptCi, &pmKey, fnName);

    // To prevent mismatch of statistics, the Attempt and Success / Fail statistics are collected in the following
    // steps. A. When Attempt statistics are invoked, they are marked only in attemptFlag (Do not peg the actual
    // statistics) B. When Success / Fail statistics are invoked, they are pegged together.

    // Step A : exit the function
    if (STAT_TYPE_ATTEMPT == FnVCCB_GetStatType(mFamily, typeId_attempt))
    {
        status = VLIB_AttemptBasedPmCCStatCollector(ptCi, &ptPi->pduStatistic.attemptFlag[indexPduStatfamily], mFamily,
            mActualFamily, mType, &pmMultiCollect, &pmKey);
        VCCB_RETURN_ON_CALL_VOID(ptCi, status,
            "VLIB_AttemptBasedPmCCStatCollector ERROR! %d/%d/%llu/%llu/%llu/%llu/%llu/%llu\n", mActualFamily, mType,
            pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2], pmKey.keyList[VCCB_PMKEY_INDEX3], pmKey.keyList[VCCB_PMKEY_INDEX4], pmKey.keyList[VCCB_PMKEY_INDEX5], pmKey.keyList[VCCB_PMKEY_INDEX6]);

        if (status == BREAK) return;

        // reset flag
        ptPi->pduStatistic.attemptFlag[indexPduStatfamily] = NO_ATTEMPT;
    }

    // Step B : actual pegging is done
    MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily, mType,
        pmMultiCollect.updateMethod, 1);

    if ((sliceFail == VCCB_FLAG_ON) && (mFamily != STAT_PDU_SESSION_RESOURCE_MODIFY_PLMN_SNSSAI_RFSP))
    {
        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily,
            PduSetupPlmnSnssaiFail_SliceReject, pmMultiCollect.updateMethod, 1); // TODO: Check Final Name of PduSetupPlmnSnssaiFail_SliceReject
    }

    if (statOption == COLLECT_ADDITIONAL_InteractionWithOtherProcedure)
    {
        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily,
            PduSetupPlmnSnssaiFail_InteractionWithOtherProcedure, pmMultiCollect.updateMethod, 1);
    }
    else
    {
        /* Check isLteFallbackTriggered */
        if(ptPi->isLteFallbackTriggered)
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily,
                PduSetupPlmnSnssaiFail_LteFBTriggered, pmMultiCollect.updateMethod, 1);
        }
    }

    CollectPmStatistics(
        ptCi, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemUintArr, pmKey, TRUE);
}

VCCB_STATIC_INLINE
void FnVCCB_LibStatPmCC_WithAttemptBasedChoCollector(VccbPmKey_type &pmKey, VccbPmMultiCollect_type &pmMultiCollect,
    int mFamily, int mActualFamily, int mType, callInfo_type *ptCi, int typeId_attempt)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    int retVal = STAT_VALID, rankType = -1;

    // Distinguish between statistics that need attempt and statistics that don't.
    if (STAT_TYPE_ATTEMPT == FnVCCB_GetStatType(mFamily, typeId_attempt))
    {
        int famIdx = GET_FAMIDX(mFamily);
        IS_VALID_FAMIDX_TYPE_NVOID(famIdx, mType);

        retVal = CheckAttemptStatValidity(ptCi, &ptCi->stat.flag[famIdx], mFamily, mType);
        if (retVal != STAT_VALID)
        {
            VCCB_PRINT_COMMENT(
                    "CheckAttemptStatValidity Error with cause: %d (mFamily:%d, mType:%d)!\n", retVal, mFamily, mType);
            return;
        }

        retVal = VLIB_AttemptBasedPmCCStatCollector(
            ptCi, &ptCi->stat.flag[famIdx], mFamily, mActualFamily, mType, &pmMultiCollect, &pmKey);
        VCCB_RETURN_ON_CALL_VOID(ptCi, retVal,
            "VLIB_AttemptBasedPmCCStatCollector ERROR! %d/%d/%llu/%llu/%llu/%llu/%llu/%llu\n", mActualFamily, mType,
            pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2], pmKey.keyList[VCCB_PMKEY_INDEX3],
            pmKey.keyList[VCCB_PMKEY_INDEX4], pmKey.keyList[VCCB_PMKEY_INDEX5], pmKey.keyList[VCCB_PMKEY_INDEX6]);
        if (retVal == BREAK)  // If Attempt, PrepSuccess is called, it is not collected at this time.
        {
            return;
        }

        // reset flag
        SET_CALL_STAT_FLAG(ptCi, famIdx, NO_ATTEMPT);
    }

    MACRO_STAT_PMCC_ADD_ITEM(
        pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily, mType, pmMultiCollect.updateMethod, 1);

    // Check Additional Statistic for Ranking.
    rankType = GetRankTypeId(mActualFamily, mType);
    if (rankType != -1)
    {
        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily, rankType,
            pmMultiCollect.updateMethod, 1);
    }

    VCCB_PRINT_CALL_SA_CHO(ptCi, "(*CHO) %s\n", FnVCCB_GetStrChoStatisticTypeName(mActualFamily, mType));
}

VCCB_STATIC_INLINE
void FnVCCB_LibStatPmCC_WithOutAttemptBasedChoCollector(VccbPmMultiCollect_type &pmMultiCollect, int mFamily, int mType)
{
    MACRO_STAT_PMCC_ADD_ITEM(
        pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mFamily, mType, pmMultiCollect.updateMethod, 1);
}

void FnVCCB_LibStatPmCC_ChoCollector(int mFamily, int mType, callInfo_type *ptCi, cgi_type *pTargetCgi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pTargetCgi);

    auto servCellNum = ptCi->servCellNum;
    auto gnbNum = ptCi->gnbNum;

    VccbGnbInfo_type *pGnb = NULL;

    VccbPmKey_type pmKey;
    memset(&pmKey, 0, sizeof(VccbPmKey_type));
    VccbPmMultiCollect_type pmMultiCollect;
    conditionalCellInfo_type *ptCondCell = NULL;

    int typeId_attempt = GetAttTypeId(ptCi, mFamily, mType);
    uint16_t srcCellIdentity = MAX_CELL_IDENTITY, tgtCellIdentity = MAX_CELL_IDENTITY;
    unsigned long long duId = 0;

    VCCB_CHECK_VALID_GNBNUM_VOID(gnbNum);

    FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_CC);

    ptCondCell = FnVCCB_GetConditionalCellInfoForCGI(ptCi, *pTargetCgi);
    VALID_E_POINT_CHECK_VOID(ptCondCell);

    if (typeId_attempt == -1)  // Collect type of CandidateRelease
    {
        // 1) has already been collected.
        if (ptCondCell->flag.collectableCandidateRelStat == FALSE) return;

        // 2) FLAG is disabled as the acquisition progresses.
        ptCondCell->flag.collectableCandidateRelStat = FALSE;
    }

    pGnb = &GNBINFO[gnbNum];

    switch (mFamily)
    {
        case STAT_CHO_OUT:
        {
            VCCB_CHECK_VALID_CELLNUM_VOID(servCellNum);
            srcCellIdentity = CELLINFO[servCellNum].cellIdentity;
            VCCB_CHECK_E_RANGE_AND_VOID(srcCellIdentity, MAX_CELL_IDENTITY);

            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &duId, srcCellIdentity, MAX_GNB_PER_SYS);

            pmKey.keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;  // gNB ID
            pmKey.keyList[VCCB_PMKEY_INDEX2] = duId;                        // gNB_DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX3] = srcCellIdentity;             // Cell ID
            pmKey.keyList[VCCB_PMKEY_INDEX4] = ptCondCell->nrcgi.ci;        // NCI of Target Cell
        }
        break;

        case STAT_CHO_IN:
        {
            tgtCellIdentity = VLIB_NrCellId2CellId(pGnb->globalGnbId.gnbId.idLength, ptCondCell->nrcgi.ci);
            VCCB_CHECK_E_RANGE_AND_VOID(tgtCellIdentity, MAX_CELL_IDENTITY);

            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &duId, tgtCellIdentity, MAX_GNB_PER_SYS);

            pmKey.keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;  // gNB ID
            pmKey.keyList[VCCB_PMKEY_INDEX2] = duId;                        // gNB_DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX3] = tgtCellIdentity;             // NCI of Target Cell
        }
        break;

        default:
            VCCB_PRINT_ERROR("Not a Stat family(%d) defined in VLIB_LibStatPmCC_PDU!\n", mFamily);
            return;
    }

    int mActualFamily = mFamily;
    StatisticsHandler statHandler(gnbNum);
    statHandler.changeFamilyAndIndex(ptCi, mActualFamily, pmKey);

    if (typeId_attempt == -1)
    {
        // Statisic without attempt (CandidateRel_CandidateInit, CandidateRel_gNBTimeout, ...)
        FnVCCB_LibStatPmCC_WithOutAttemptBasedChoCollector(pmMultiCollect, mActualFamily, mType);

        VCCB_PRINT_CALL_SA_CHO(ptCi, "(*CHO) %s\n", FnVCCB_GetStrChoStatisticTypeName(mActualFamily, mType));
    }
    else
    {
        // Statisic with attempt (PrepAtt, PrepComplete, ...)
        FnVCCB_LibStatPmCC_WithAttemptBasedChoCollector(pmKey, pmMultiCollect, mFamily, mActualFamily, mType, ptCi, typeId_attempt);
    }

    if (pmMultiCollect.numOfItem == 0) return;

    CollectPmStatistics(
        ptCi, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemUintArr, pmKey, TRUE);

    return;
}

#define SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(__prep_flag, __mtype_name) \
    do                                                                 \
    {                                                                  \
        if (__prep_flag == TRUE)                                       \
        {                                                              \
            retVal = __mtype_name##_PrepSucc;                          \
        }                                                              \
        else                                                           \
        {                                                              \
            retVal = __mtype_name##_Att;                               \
        }                                                              \
    } while (0)

#define SET_SERVICE_TYPE_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(__prep_flag, __mtype_name) \
    do                                                                 \
    {                                                                  \
        if (__prep_flag == TRUE)                                       \
        {                                                              \
            retVal = __mtype_name##_PrepSucc_SERVICE_TYPE;             \
        }                                                              \
        else                                                           \
        {                                                              \
            retVal = __mtype_name##_Att_SERVICE_TYPE;                  \
        }                                                              \
    } while (0)

int FnVCCB_GetRrcReestabTypeId(const callInfo_type * const ptCi, const int mType, const uint8_t isNeedPrepMType)
{
    // one is default prep success index
    // zero is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 1 : 0);

    switch (mType)
    {
        case IntraGnbReEstabAtt ... IntraGnbReEstabFail_RrcSetupTimeout:
            if (isNeedPrepMType == TRUE)
            {
                VALID_E_POINT_CHECK_RET_VAL(ptCi, retVal);
                if (ptCi->ueInfo.reestablishInfo.reestablishType == RRE_TYPE_INTRA_GNB_RRC_SETUP)
                    retVal = IntraGnbReEstabRrcSetupAtt;
                else
                    retVal = IntraGnbReEstabRreAtt;
            }
            else
                retVal = IntraGnbReEstabAtt;
            break;

        case InterGnbReEstabAtt ... InterGnbReEstabFail_RrcSetupTimeout:
            if (isNeedPrepMType == TRUE)
            {
                VALID_E_POINT_CHECK_RET_VAL(ptCi, retVal);
                if (ptCi->ueInfo.reestablishInfo.reestablishType == RRE_TYPE_INTER_GNB_RRC_SETUP)
                    retVal = InterGnbReEstabRrcSetupAtt;
                else
                    retVal = InterGnbReEstabRreAtt;
            }
            else
                retVal = InterGnbReEstabAtt;
            break;

        case ReEstabToRrcSetup_Overload:
                retVal = ReEstabToRrcSetup_Overload;
            break;
        default:
            break;
    }

    return retVal;
}

int FnVCCB_GetHoOutTypeId(const int mFamily, const int mType, const uint8_t isNeedPrepMType)
{
    // one is default prep success index
    // zero is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 1 : 0);

    switch (mType)
    {
        case IntraGnbOut_Att ... IntraGnbOut_RRE:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, IntraGnbOut);
            break;

        case InterXnOut_Att ... InterXnOut_RRE:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterXnOut);
            break;

        case InterNgOut_Att ... InterNgOut_RRE:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterNgOut);
            break;

        case IntraGnbOutWithNedc_Att ... IntraGnbOutWithNedc_RRE:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, IntraGnbOutWithNedc);
            break;

        case InterXnOutWithNedc_Att ... InterXnOutWithNedc_RRE:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterXnOutWithNedc);
            break;

        case InterNgOutWithNedc_Att ... InterNgOutWithNedc_RRE:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterNgOutWithNedc);
            break;

        case IntraGnbOutWithNrdc_Att ... IntraGnbOutwithNrdc_RRE:
            if (isNeedPrepMType == TRUE)
            {
                retVal = IntraGnbOutwithNrdc_PrepSucc;
            }
            else
            {
                retVal = IntraGnbOutWithNrdc_Att;
            }
            break;

        case InterXnOutwithNrdc_Att ... InterXnOutwithNrdc_RRE:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterXnOutwithNrdc);
            break;

        case InterNgOutwithNrdc_Att ... InterNgOutwithNrdc_RRE:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterNgOutwithNrdc);
            break;

        default:
            VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                isNeedPrepMType);
    }

    return retVal;
}

int FnVCCB_GetHoOutServiceTypeId(const int mFamily, const int mType, const uint8_t isNeedPrepMType)
{
    // two is default prep success index
    // one is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 2 : 1);

    switch (mType)
    {
        case IntraGnbOut_Att_SERVICE_TYPE ... IntraGnbOut_RRE_SERVICE_TYPE:
            SET_SERVICE_TYPE_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, IntraGnbOut);
            break;

        case InterXnOut_Att_SERVICE_TYPE ... InterXnOut_RRE_SERVICE_TYPE:
            SET_SERVICE_TYPE_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterXnOut);
            break;

        case InterNgOut_Att_SERVICE_TYPE ... InterNgOut_RRE_SERVICE_TYPE:
            SET_SERVICE_TYPE_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterNgOut);
            break;

        case IntraGnbOutWithNedc_Att_SERVICE_TYPE ... IntraGnbOutWithNedc_RRE_SERVICE_TYPE:
            SET_SERVICE_TYPE_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, IntraGnbOutWithNedc);
            break;

        case InterXnOutWithNedc_Att_SERVICE_TYPE ... InterXnOutWithNedc_RRE_SERVICE_TYPE:
            SET_SERVICE_TYPE_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterXnOutWithNedc);
            break;

        case InterNgOutWithNedc_Att_SERVICE_TYPE ... InterNgOutWithNedc_RRE_SERVICE_TYPE:
            SET_SERVICE_TYPE_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterNgOutWithNedc);
            break;

        case IntraGnbOutWithNrdc_Att_SERVICE_TYPE ... IntraGnbOutwithNrdc_RRE_SERVICE_TYPE:
            if (isNeedPrepMType == TRUE)
            {
                retVal = IntraGnbOutwithNrdc_PrepSucc_SERVICE_TYPE;
            }
            else
            {
                retVal = IntraGnbOutWithNrdc_Att_SERVICE_TYPE;
            }
            break;

        case InterXnOutwithNrdc_Att_SERVICE_TYPE ... InterXnOutwithNrdc_RRE_SERVICE_TYPE:
            SET_SERVICE_TYPE_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterXnOutwithNrdc);
            break;

        case InterNgOutwithNrdc_Att_SERVICE_TYPE ... InterNgOutwithNrdc_RRE_SERVICE_TYPE:
            SET_SERVICE_TYPE_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterNgOutwithNrdc);
            break;

        default:
            VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                isNeedPrepMType);
    }

    return retVal;
}

int FnVCCB_GetHoInTypeId(const int mFamily, const int mType, const uint8_t isNeedPrepMType)
{
    // one is default prep success index
    // zero is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 1 : 0);

    switch (mType)
    {
        case IntraGnbIn_Att ... IntraGnbIn_HandoverCancel:
        case IntraGnbIn_RRE: //TODO: to make it simpler
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, IntraGnbIn);
            break;

        case InterXnIn_Att ... InterXnIn_RRE:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterXnIn);
            break;

        case InterNgIn_Att ... InterNgIn_RRE:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterNgIn);
            break;

        case IntraGnbInWithNedc_Att ... IntraGnbInWithNedc_HandoverCancel:
        case IntraGnbInWithNedc_RRE: //TODO: to make it simpler
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, IntraGnbInWithNedc);
            break;

        case InterXnInWithNedc_Att ... InterXnInWithNedc_RRE:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterXnInWithNedc);
            break;

        case InterNgInWithNedc_Att ... InterNgInWithNedc_RRE:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterNgInWithNedc);
            break;

        case IntraGnbInWithNrdc_Att ... IntraGnbInWithNrdc_HandoverCancel:
        case IntraGnbInWithNrdc_RRE:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, IntraGnbInWithNrdc);
            break;

        case InterXnInWithNrdc_Att ... InterXnInWithNrdc_RRE:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterXnInWithNrdc);
            break;

        case InterNgInWithNrdc_Att ... InterNgInWithNrdc_RRE:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterNgInWithNrdc);
            break;

        default:
            VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                isNeedPrepMType);
    }

    return retVal;
}

int FnVCCB_GetHoInRedcapTypeId(const int mFamily, const int mType, const uint8_t isNeedPrepMType)
{
    // one is default prep success index
    // zero is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 1 : 0);

    switch (mType)
    {
        case IntraGnbIn_Att_RedCap ... IntraGnbIn_HandoverCancel_RedCap:
        case IntraGnbIn_RRE_RedCap:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, IntraGnbIn);
            break;

        case InterXnIn_Att_RedCap ... InterXnIn_RRE_RedCap:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterXnIn);
            break;

        case InterNgIn_Att_RedCap ... InterNgIn_RRE_RedCap:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterNgIn);
            break;

        default:
            VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                isNeedPrepMType);
    }

    return retVal;
}

int FnVCCB_GetHoInterFreqOutTypeId(const int mFamily, const int mType, const uint8_t isNeedPrepMType)
{
    // one is default prep success index
    // zero is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 1 : 0);

    switch (mType)  // NR_CONN_MC_21D
    {
        case InterFreqOutWithGap_Att ... InterFreqOutWithGap_RRE:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterFreqOutWithGap);
            break;

        case InterFreqOutWithoutGap_Att ... InterFreqOutWithoutGap_RRE:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterFreqOutWithoutGap);
            break;

        default:
            VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                isNeedPrepMType);
    }

    return retVal;
}

int FnVCCB_GetHoInterFreqOutRedcapTypeId(const int mFamily, const int mType, const uint8_t isNeedPrepMType)
{
    // one is default prep success index
    // zero is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 1 : 0);

    switch (mType)  // NR_CONN_MC_21D
    {
        case InterFreqOutWithGap_Att_RedCap ... InterFreqOutWithGap_RRE_RedCap:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterFreqOutWithGap);
            break;

        case InterFreqOutWithoutGap_Att_RedCap ... InterFreqOutWithoutGap_RRE_RedCap:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterFreqOutWithoutGap);
            break;

        default:
            VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                isNeedPrepMType);
    }

    return retVal;
}

int FnVCCB_GetHoEutraOutTypeId(const int mFamily, const int mType, const uint8_t isNeedPrepMType)
{
    // one is default prep success index
    // zero is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 1 : 0);

    switch (mType)
    {
        case InterSysLTE_Out_Att ... InterSysLTE_Out_N26InterfaceNotAvailable:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterSysLTE_Out);
            break;

        default:
            VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                isNeedPrepMType);
    }

    return retVal;
}

int FnVCCB_GetHoEutraOutFallbackTypeId(const int mFamily, const int mType, const uint8_t isNeedPrepMType)
{
    // one is default prep success index
    // zero is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 1 : 0);

    switch (mType)
    {
        case InterSysLTE_Out_EPSFallback_Att ... InterSysLTE_Out_EPSFallback_N26InterfaceNotAvailable:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterSysLTE_Out_EPSFallback);
            break;

        case InterSysLTE_Out_EmergencyFallback_Att ... InterSysLTE_Out_EmergencyFallback_N26InterfaceNotAvailable:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterSysLTE_Out_EmergencyFallback);
            break;

        default:
            VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                isNeedPrepMType);
    }

    return retVal;
}

int FnVCCB_GetHoEutranFreqOutTypeId(const callInfo_type * const ptCi, const int mFamily, const int mType, const uint8_t isNeedPrepMType)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, -1);

    // one is default prep success index
    // zero is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 1 : 0);

    if (IS_FALLBACK_CASE(ptCi)) // Fallback case
    {
        switch (mType)
        {
            case InterSysLTE_Out_EPSFallback_Att_FREQ_OUT ... InterSysLTE_Out_EPSFallback_N26InterfaceNotAvailable_FREQ_OUT:
                if (TRUE == isNeedPrepMType)
                {
                    retVal = InterSysLTE_Out_EPSFallback_PrepSucc_FREQ_OUT;
                }
                else
                {
                    retVal = InterSysLTE_Out_EPSFallback_Att_FREQ_OUT;
                }
                break;

            case InterSysLTE_Out_EmergencyFallback_Att_FREQ_OUT ... InterSysLTE_Out_EmergencyFallback_N26InterfaceNotAvailable_FREQ_OUT:
                if (TRUE == isNeedPrepMType)
                {
                    retVal = InterSysLTE_Out_EmergencyFallback_PrepSucc_FREQ_OUT;
                }
                else
                {
                    retVal = InterSysLTE_Out_EmergencyFallback_Att_FREQ_OUT;
                }
                break;

            default:
                VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                        isNeedPrepMType);
        }
    }
    else
    {
        switch (mType)
        {
            case InterSysLTE_Out_Att_FREQ_OUT ... InterSysLTE_Out_N26InterfaceNotAvailable_FREQ_OUT:
                if (TRUE == isNeedPrepMType)
                {
                    retVal = InterSysLTE_Out_PrepSucc_FREQ_OUT;
                }
                else
                {
                    retVal = InterSysLTE_Out_Att_FREQ_OUT;
                }
                break;

            default:
                VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                        isNeedPrepMType);
        }
    }

    return retVal;
}

int FnVCCB_GetHoEutranFreqOutRedCapTypeId(const callInfo_type * const ptCi, const int mFamily, const int mType, const uint8_t isNeedPrepMType)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, -1);

    // one is default prep success index
    // zero is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 1 : 0);

    if (IS_FALLBACK_CASE(ptCi)) // Fallback case
    {
        switch (mType)
        {
            case InterSysLTE_Out_EPSFallback_Att_RedCap ... InterSysLTE_Out_EPSFallback_N26InterfaceNotAvailable_RedCap:
                if (TRUE == isNeedPrepMType)
                {
                    retVal = InterSysLTE_Out_EPSFallback_PrepSucc_RedCap;
                }
                else
                {
                    retVal = InterSysLTE_Out_EPSFallback_Att_RedCap;
                }
                break;

            case InterSysLTE_Out_EmergencyFallback_Att_RedCap ... InterSysLTE_Out_EmergencyFallback_N26InterfaceNotAvailable_RedCap:
                if (TRUE == isNeedPrepMType)
                {
                    retVal = InterSysLTE_Out_EmergencyFallback_PrepSucc_RedCap;
                }
                else
                {
                    retVal = InterSysLTE_Out_EmergencyFallback_Att_RedCap;
                }
                break;

            default:
                VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                        isNeedPrepMType);
        }
    }
    else
    {
        switch (mType)
        {
            case InterSysLTE_Out_Att_RedCap ... InterSysLTE_Out_N26InterfaceNotAvailable_RedCap:
                if (TRUE == isNeedPrepMType)
                {
                    retVal = InterSysLTE_Out_PrepSucc_RedCap;
                }
                else
                {
                    retVal = InterSysLTE_Out_Att_RedCap;
                }
                break;

            default:
                VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                        isNeedPrepMType);
        }
    }

    return retVal;
}

int FnVCCB_GetHoEutraInTypeId(const int mFamily, const int mType, const uint8_t isNeedPrepMType)
{
    // one is default prep success index
    // zero is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 1 : 0);

    switch (mType)
    {
        case InterSysLTE_In_Att ... InterSysLTE_In_RRE:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterSysLTE_In);
            break;

        default:
            VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                isNeedPrepMType);
    }

    return retVal;
}

int FnVCCB_GetHoEutraInRedcapTypeId(const int mFamily, const int mType, const uint8_t isNeedPrepMType)
{
    // one is default prep success index
    // zero is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 1 : 0);

    switch (mType)
    {
        case InterSysLTE_In_Att_RedCap ... InterSysLTE_In_RRE_RedCap:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, InterSysLTE_In);
            break;

        default:
            VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                isNeedPrepMType);
    }

    return retVal;
}

int FnVCCB_GetNrdcSnAddMnTypeId(const int mFamily, const int mType, const uint8_t isNeedPrepMType)
{
    // one is default prep success index
    // zero is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 1 : 0);

    switch (mType)
    {
        case NrdcAddMn_Att ... NrdcAddMn_Fail_RrcFail:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, NrdcAddMn);
            break;

        case NrdcAddMn_IntraMnMobilityWithSgnbChg_Att ... NrdcAddMn_IntraMnMobilityWithSgnbChg_Fail_RrcFail:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, NrdcAddMn_IntraMnMobilityWithSgnbChg);
            break;

        case NrdcAddMn_InterMnMobilityWithSgnbChg_Att ... NrdcAddMn_InterMnMobilityWithSgnbChg_Fail_RrcFail:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, NrdcAddMn_InterMnMobilityWithSgnbChg);
            break;

        case NrdcAddMn_InterMnMobilityWithoutSgnbChg_Att ... NrdcAddMn_InterMnMobilityWithoutSgnbChg_Fail_RrcFail:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, NrdcAddMn_InterMnMobilityWithoutSgnbChg);
            break;

        case NrdcAddMn_SnChange_Att ... NrdcAddMn_SnChange_Fail_RrcFail:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, NrdcAddMn_SnChange);
            break;

        default:
            VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                isNeedPrepMType);
    }

    return retVal;
}

int FnVCCB_GetNrdcSnAddSnWithInvalidCellTypeId(const int mFamily, const int mType, const uint8_t isNeedPrepMType)
{
    // one is default prep success index
    // zero is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 1 : 0);

    switch (mType)
    {
        case NrdcAddSn_Att ... NrdcAddSn_Fail_DuFail:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, NrdcAddSn);
            break;

        case NrdcAddSn_IntraMnMobilityWithSgnbChange_Att ... NrdcAddSn_IntraMnMobilityWithSgnbChange_Fail_DuFail:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, NrdcAddSn_IntraMnMobilityWithSgnbChange);
            break;

        case NrdcAddSn_InterMnMobilityWithSgnbChange_Att ... NrdcAddSn_InterMnMobilityWithSgnbChange_Fail_DuFail:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, NrdcAddSn_InterMnMobilityWithSgnbChange);
            break;

        case NrdcAddSn_InterMnMobilityWithoutSgnbChange_Att ... NrdcAddSn_InterMnMobilityWithoutSgnbChange_Fail_DuFail:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, NrdcAddSn_InterMnMobilityWithoutSgnbChange);
            break;

        case NrdcAddSn_SnChange_Att ... NrdcAddSn_SnChange_Fail_DuFail:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, NrdcAddSn_SnChange);
            break;

        default:
            VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                isNeedPrepMType);
    }

    return retVal;
}

int FnVCCB_GetNrdcPscellChangeInTypeId(const int mType, const uint8_t isNeedPrepMType)
{
    // one is default prep success index
    // zero is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 1 : 0);

    switch (mType)
    {
        case NrdcPsCellChange_In_MnInit_IntraSn_Att ... NrdcPsCellChange_In_MnInit_IntraSn_Fail_MgnbFail:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, NrdcPsCellChange_In_MnInit_IntraSn);
            break;
        case NrdcPsCellChange_In_SnInit_IntraSn_Att ... NrdcPsCellChange_In_SnInit_IntraSn_Fail_MgnbFail:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, NrdcPsCellChange_In_SnInit_IntraSn);
            break;
        default:
            break;
    }

    return retVal;
}

int FnVCCB_GetNrdcPscellChangeOutTypeId(const int mType, const uint8_t isNeedPrepMType)
{
    // one is default prep success index
    // zero is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 1 : 0);

    switch (mType)
    {
        case NrdcPsCellChange_Out_MnInit_IntraSn_Att ... NrdcPsCellChange_Out_MnInit_IntraSn_Fail_MgnbFail:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, NrdcPsCellChange_Out_MnInit_IntraSn);
            break;
        case NrdcPsCellChange_Out_MnInit_InterSn_Att ... NrdcPsCellChange_Out_MnInit_InterSn_Fail_MgnbFail:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, NrdcPsCellChange_Out_MnInit_InterSn);
            break;
        case NrdcPsCellChange_Out_SnInit_IntraSn_Att ... NrdcPsCellChange_Out_SnInit_IntraSn_Fail_MgnbFail:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, NrdcPsCellChange_Out_SnInit_IntraSn);
            break;
        case NrdcPsCellChange_Out_SnInit_InterSn_Att ... NrdcPsCellChange_Out_SnInit_InterSn_Fail_MgnbFail:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, NrdcPsCellChange_Out_SnInit_InterSn);
            break;
        default:
            break;
    }

    return retVal;
}

int FnVCCB_GetChoOutTypeId(const int mType, const uint8_t isNeedPrepMType)
{
    // one is default prep success index
    // zero is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 1 : 0);

    switch (mType)
    {
        case ChoXnOut_PrepAtt ... ChoXnOut_PrepCancel:
            retVal = ChoXnOut_PrepAtt;
            break;
        case ChoXnOutWithMrdc_PrepAtt ... ChoXnOutWithMrdc_PrepCancel:
            retVal = ChoXnOutWithMrdc_PrepAtt;
            break;
        case ChoXnOut_ExeAccess ... ChoXnOut_ExeFail_E1Fail:
            retVal = ChoXnOut_ExeAccess;
            break;
        case ChoXnOutWithMrdc_ExeAccess ... ChoXnOutWithMrdc_ExeFail_E1Fail:
            retVal = ChoXnOutWithMrdc_ExeAccess;
            break;
        default:
            retVal = -1;
            break;
    }

    return retVal;
}

int FnVCCB_GetChoInTypeId(const int mType, const uint8_t isNeedPrepMType)
{
    // one is default prep success index
    // zero is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 1 : 0);

    switch (mType)
    {
        case ChoXnIn_PrepAtt ... ChoXnIn_PrepFail_E1Fail:
            retVal = ChoXnIn_PrepAtt;
            break;
        case ChoXnInWithMrdc_PrepAtt ... ChoXnInWithMrdc_PrepFail_E1Fail:
            retVal = ChoXnInWithMrdc_PrepAtt;
            break;
        case ChoXnIn_ExeAccess ... ChoXnIn_ExeFail_NgFail:
            retVal = ChoXnIn_ExeAccess;
            break;
        case ChoXnInWithMrdc_ExeAccess ... ChoXnInWithMrdc_ExeFail_NgFail:
            retVal = ChoXnInWithMrdc_ExeAccess;
            break;
        default:
            retVal = -1;
            break;
    }

    return retVal;
}

int GetTypeId(callInfo_type *ptCi, int mFamily, int mType, uint8_t isNeedPrepMType)
{
    AUTO_TRACE_FUNC;

    // one is default prep success index
    // zero is default attempt index
    int retVal = (isNeedPrepMType == TRUE ? 1 : 0);

    switch (mFamily)
    {
        case STAT_RRC_REESTAB:
            return FnVCCB_GetRrcReestabTypeId(ptCi, mType, isNeedPrepMType);

        case STAT_HO_OUT:
            return FnVCCB_GetHoOutTypeId(mFamily, mType, isNeedPrepMType);

        case STAT_HO_OUT_SERVICE_TYPE:
            return FnVCCB_GetHoOutServiceTypeId(mFamily, mType, isNeedPrepMType);

        case STAT_HO_IN:
        case STAT_HO_IN_SERVICE_TYPE:
            return FnVCCB_GetHoInTypeId(mFamily, mType, isNeedPrepMType);

        case STAT_HO_IN_REDCAP:
            return FnVCCB_GetHoInRedcapTypeId(mFamily, mType, isNeedPrepMType);

        case STAT_HO_INTER_FREQ_OUT:
        case STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE:
            return FnVCCB_GetHoInterFreqOutTypeId(mFamily, mType, isNeedPrepMType);

        case STAT_HO_INTER_FREQ_OUT_REDCAP:
            return FnVCCB_GetHoInterFreqOutRedcapTypeId(mFamily, mType, isNeedPrepMType);

        case STAT_HO_INTRA_FREQ_OUT:
        case STAT_HO_INTRA_FREQ_OUT_REDCAP:
        case STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE:
            SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, IntraFreqOut);
            break;

        case STAT_HO_EUTRAN_OUT:
        case STAT_HO_EUTRAN_OUT_SERVICE_TYPE:
            return FnVCCB_GetHoEutraOutTypeId(mFamily, mType, isNeedPrepMType);

        case STAT_HO_EUTRAN_OUT_FALLBACK:  // IRAT_HO
        case STAT_HO_EUTRAN_OUT_FALLBACK_SERVICE_TYPE:
            return FnVCCB_GetHoEutraOutFallbackTypeId(mFamily, mType, isNeedPrepMType);

        case STAT_HO_EUTRAN_FREQ_OUT: // IRAT_HO_24A
        case STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE:
            return FnVCCB_GetHoEutranFreqOutTypeId(ptCi, mFamily, mType, isNeedPrepMType);

        case STAT_HO_EUTRAN_FREQ_OUT_REDCAP:
            return FnVCCB_GetHoEutranFreqOutRedCapTypeId(ptCi, mFamily, mType, isNeedPrepMType);

        case STAT_HO_EUTRAN_IN:
        case STAT_HO_EUTRAN_IN_SERVICE_TYPE:
            return FnVCCB_GetHoEutraInTypeId(mFamily, mType, isNeedPrepMType);

        case STAT_HO_EUTRAN_IN_REDCAP:
            return FnVCCB_GetHoEutraInRedcapTypeId(mFamily, mType, isNeedPrepMType);

        case STAT_DRB_RELEASE_AND_ERASE:
            if (mType >= static_cast<int>(DrbRelAtt) && mType <= DrbRelFail_NgFail)
                retVal = DrbRelAtt;
            else
                retVal = DrbEraseAtt;
            break;

        case STAT_NEDC_DRB_MOD:
            if (mType >= static_cast<int>(NedcDrbModByMgnbAtt) && mType <= NedcDrbModByMgnbFail_DuFail)
                retVal = NedcDrbModByMgnbAtt;
            else
                retVal = NedcDrbModBySenbAtt;
            break;

        case STAT_INTRA_FREQ_PSCELL_CHANGE_SCGMOB_PER_GNB_DU_ID:
            if (mType >= EndcIntraFreqInterSnChgAtt && mType <= EndcIntraFreqInterSnChgSucc)
            {
                if (TRUE == isNeedPrepMType)
                {
                    retVal = EndcIntraFreqInterSnChgPrepSucc;
                }
                else
                {
                    retVal = EndcIntraFreqInterSnChgAtt;
                }
            }
            break;

        case STAT_NRDC_SN_ADD_MN:
        case STAT_NRDC_SN_ADD_MN_PSCELL_NCI:
            return FnVCCB_GetNrdcSnAddMnTypeId(mFamily, mType, isNeedPrepMType);

        case STAT_NRDC_SN_ADD_SN_WITH_INVALID_CELL:
        case STAT_NRDC_SN_ADD_SN_PCELL_NCI:
            return FnVCCB_GetNrdcSnAddSnWithInvalidCellTypeId(mFamily, mType, isNeedPrepMType);

        // FGR-CC5200:FR680
        case V_STAT_NRDC_SN_MOD_MN_MNInitiated:
            switch (mType)
            {
                case NrdcModMn_MnInit_Att ... NrdcModMn_MnInit_PrepFail:
                    SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, NrdcModMn_MnInit);
                    break;
                default:
                    VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                        isNeedPrepMType);
            }
            break;

        case V_STAT_NRDC_SN_MOD_MN_SNInitiated:
            switch (mType)
            {
                case NrdcModMn_SnInit_Att ... NrdcModMn_SnInit_Fail:
                    retVal = NrdcModMn_SnInit_Att;
                    break;

                default:
                    VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                        isNeedPrepMType);
            }
            break;

        case V_STAT_NRDC_SN_MOD_SN_MNInitiated:
            switch (mType)
            {
                case NrdcModSn_MnInit_Att ... NrdcModSn_MnInit_PrepFail:
                    SET_ATTEMPT_OR_PREP_SUCCESS_TYPE_ID(isNeedPrepMType, NrdcModSn_MnInit);
                    break;

                default:
                    VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                        isNeedPrepMType);
            }
            break;

        case V_STAT_NRDC_SN_MOD_SN_SNInitiated:
            switch (mType)
            {
                case NrdcModSn_SnInit_Att ... NrdcModSn_SnInit_Fail:
                    retVal = NrdcModSn_SnInit_Att;
                    break;

                default:
                    VCCB_PRINT_DATA("Invalid Statistics(mFamily=%d, mType=%d, isNeedPrepMType=%u)\n", mFamily, mType,
                        isNeedPrepMType);
            }
            break;

        case STAT_NRDC_PSCELL_CHANGE_IN:
            return FnVCCB_GetNrdcPscellChangeInTypeId(mType, isNeedPrepMType);

        case STAT_NRDC_PSCELL_CHANGE_OUT:
            return FnVCCB_GetNrdcPscellChangeOutTypeId(mType, isNeedPrepMType);

        case STAT_CHO_OUT:
            return FnVCCB_GetChoOutTypeId(mType, isNeedPrepMType);

        case STAT_CHO_IN:
            return FnVCCB_GetChoInTypeId(mType, isNeedPrepMType);

        default:
            break;
    }

    return retVal;
}

int GetAttTypeId(callInfo_type *ptCi, int mFamily, int mType) { return GetTypeId(ptCi, mFamily, mType, FALSE); }

int GetPrepSuccTypeId(callInfo_type *ptCi, int mFamily, int mType) { return GetTypeId(ptCi, mFamily, mType, TRUE); }

// To get ranking mType, Use the below function after getting attType
int GetRankTypeId(int mFamily, int mType)  // IRAT_HO - RANK_STAT
{
    int retVal = -1;

    AUTO_TRACE_FUNC;

    switch (mFamily)
    {
        case STAT_HO_EUTRAN_OUT:
        case STAT_HO_EUTRAN_OUT_GLOBAL_ID:
            retVal = HoLTE_Out;
            break;
        case STAT_HO_EUTRAN_OUT_FALLBACK:
        case STAT_HO_EUTRAN_OUT_FALLBACK_GLOBAL_ID:
            retVal = HoLTE_Out_Fallback;
            break;
        case STAT_PINGPONG:
        case STAT_PINGPONG_GLOBAL_ID:
            retVal = Pingpong;
            break;
        case STAT_NEDC_SCG_FAIL_OPER:
            retVal = NedcScgFailure;
            break;
        case STAT_NRDC_SN_ADD_MN:
        case STAT_NRDC_SN_ADD_MN_PSCELL_NCI:
            retVal = NrdcAddMn_Total;
            break;
        case STAT_NRDC_SN_ADD_SN_WITH_INVALID_CELL:
        case STAT_NRDC_SN_ADD_SN_PCELL_NCI:
            retVal = NrdcAddSn_Total;
            break;
        case V_STAT_NRDC_SN_MOD_MN_MNInitiated:
        case V_STAT_NRDC_SN_MOD_MN_SNInitiated:
            retVal = NrdcModMn_Total;
            break;
        case V_STAT_NRDC_SN_MOD_SN_MNInitiated:
        case V_STAT_NRDC_SN_MOD_SN_SNInitiated:
            retVal = NrdcModSn_Total;
            break;
        case STAT_NRDC_PSCELL_CHANGE_IN:
            retVal = NrdcPsCellChange_In;
            break;
        case STAT_NRDC_PSCELL_CHANGE_OUT:
            retVal = NrdcPsCellChange_Out;
            break;
        case STAT_CHO_OUT:
        case STAT_CHO_OUT_GLOBAL_ID:
            switch (mType)
            {
                case ChoXnOut_PrepAtt ... ChoXnOut_PrepCancel:
                case ChoXnOutWithMrdc_PrepAtt ... ChoXnOutWithMrdc_PrepCancel:
                    retVal = ChoTotalOut_PrepAtt;
                    break;
                default:
                    break;
            }
            break;
        case STAT_HO_OUT_SERVICE_TYPE:  // FGR-MC1009/MC1010 FR531 25B
            retVal = HoNR_Out_SERVICE_TYPE;
            break;
        case STAT_HO_EUTRAN_OUT_SERVICE_TYPE:
            retVal = HoLTE_Out_SERVICE_TYPE;
            break;
        case STAT_HO_EUTRAN_OUT_FALLBACK_SERVICE_TYPE:
            retVal = HoLTE_Out_Fallback_SERVICE_TYPE;
            break;

        default:
            break;
    }

    return retVal;
}

// To get proper attemptType (that takes ranking info account), use the below function
int GetAttemptTypeBasedOnPriority(int causeType)
{
    AUTO_TRACE_FUNC;
    int retVal = ERROR;

    if (B3GSpid == causeType || B3GOthers == causeType || B3GUENotSupFreqBand == causeType)
    {
        retVal = B3GAddAttTot;
    }
    else if (A3GSpid == causeType || A3GOthers == causeType || A3GUENotSupFreqBand == causeType)
    {
        retVal = A3GAddAttTot;
    }
    else if (A6GSpid == causeType || A6GOthers == causeType || A6GUENotSupFreqBand == causeType)
    {
        retVal = A6GAddAttTot;
    }

    return retVal;
}

// To get proper causeType (that takes ranking info account), use the below function
int GetCauseTypeBasedOnPriority(bool * counterType)
{
    AUTO_TRACE_FUNC;
    int retVal = ERROR;

    if (counterType[B3GUENotSupFreqBand])
    {
        retVal = B3GUENotSupFreqBand;
    }
    else if (counterType[A3GUENotSupFreqBand])
    {
        retVal = A3GUENotSupFreqBand;
    }
    else if (counterType[A6GUENotSupFreqBand])
    {
        retVal = A6GUENotSupFreqBand;
    }
    else if (counterType[B3GSpid])
    {
        retVal = B3GSpid;
    }
    else if (counterType[A3GSpid])
    {
        retVal = A3GSpid;
    }
    else if (counterType[A6GSpid])
    {
        retVal = A6GSpid;
    }
    else if (counterType[B3GOthers])
    {
        retVal = B3GOthers;
    }
    else if (counterType[A3GOthers])
    {
        retVal = A3GOthers;
    }
    else if (counterType[A6GOthers])
    {
        retVal = A6GOthers;
    }

    return retVal;
}

void VLIB_StatNedcScgFailure(callInfo_type *ptCi)  // NEDC_SCG_FAILURE_20C
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->callType == E_CALLTYPE_NSA) goto END_OF_STAT_NEDC_SCG_FAILURE;

    // mType validity
    if (ptCi->nedcScgFailCauseInfo < NeDcScgFailCauseInfo_UeT313Expired ||
        ptCi->nedcScgFailCauseInfo >= MAX_NEDC_SCG_FAIL_CAUSE_INFO)
        goto END_OF_STAT_NEDC_SCG_FAILURE;

    // Index validity
    if (VLIB_GetNedcSnodeEnbId(ptCi) == 0xFFFFFFFF) goto END_OF_STAT_NEDC_SCG_FAILURE;

    /* STAT_NEDC_SCG_FAIL_OPER == 5275 */
    MACRO_STAT_PMCC(STAT_NEDC_SCG_FAIL_OPER, ptCi->nedcScgFailCauseInfo, ptCi, 0, 0, 0, 0, 0);

END_OF_STAT_NEDC_SCG_FAILURE:
    return;
}

void VLIB_StatNedcMgnbInitRel(callInfo_type *ptCi)  // NEDC_SCG_FAILURE_20C
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    uint8_t mType;

    if (ptCi->callType == E_CALLTYPE_NSA) goto END_OF_STAT_NEDC_MGNB_INIT_REL;

    // mType validity
    if (ptCi->nedcScgFailCauseInfo < NedcScgFailure_t313Expiry ||
        ptCi->nedcScgFailCauseInfo >= MAX_NEDC_SCG_FAIL_CAUSE_INFO)
        goto END_OF_STAT_NEDC_MGNB_INIT_REL;

    // Index validity
    if (VLIB_GetNedcSnodeEnbId(ptCi) == 0xFFFFFFFF) goto END_OF_STAT_NEDC_MGNB_INIT_REL;

    if ((mType = getMgnbInitRelSenbIdx(ptCi->nedcScgFailCauseInfo)) == 0xFF) goto END_OF_STAT_NEDC_MGNB_INIT_REL;

    MACRO_STAT_PMCC(STAT_NEDC_MGNB_INIT_REL, (int)mType, ptCi, 0, 0, 0, 0, 0);

END_OF_STAT_NEDC_MGNB_INIT_REL:
    return;
}

// void VLIB_StatNedcSenbInitRel(callInfo_type *ptCi, int mType)  // NEDC_SCG_FAILURE_20C
// {
//     AUTO_TRACE_FUNC;
//     VALID_E_POINT_CHECK_VOID(ptCi);

//     if (ptCi->callType == E_CALLTYPE_NSA) goto END_OF_STAT_NEDC_SENB_INIT_REL;

//     // Index validity
//     if (VLIB_GetNedcSnodeEnbId(ptCi) == 0xFFFFFFFF) goto END_OF_STAT_NEDC_SENB_INIT_REL;

//     // NedcRelBySenb_RadioConnectionWithUeLost only as mType on 20200731
//     MACRO_STAT_PMCC(STAT_NEDC_SENB_INIT_REL, mType, ptCi, 0, 0, 0, 0, 0);

// END_OF_STAT_NEDC_SENB_INIT_REL:
//     return;
// }

// FGS-SF0503 FR530 26A - STAT_ECGI_REPORT_ANR
int FnVCCB_GetReportCgiEventType(uint8_t ratType, int nrEventType, int eutraEventType)
{
    if (ratType == nrType)
        return nrEventType;
    else
        return eutraEventType;
}

int FnVCCB_GetCgiReportStatType(callInfo_type *ptCi, enumCgiReportReportResult_type type)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint8_t ratType = ptCi->anrInfo.ratType;

    switch (type)
    {
        case CGI_REPORT_RESULT_SUCC:
            return FnVCCB_GetReportCgiEventType(ratType, NCGI_REPORT_EVENT_SUCC, ECGI_REPORT_EVENT_SUCC);
        case CGI_REPORT_RESULT_CANCEL:
            return FnVCCB_GetReportCgiEventType(ratType, NCGI_REPORT_EVENT_CANCEL, ECGI_REPORT_EVENT_CANCEL);
        case CGI_REPORT_RESULT_FAIL_NO_SIB1MR:
            return FnVCCB_GetReportCgiEventType(ratType, NCGI_REPORT_EVENT_FAIL_NO_SIB1MR, -1);
        case CGI_REPORT_RESULT_FAIL_NULL_CGI_MR:
            return FnVCCB_GetReportCgiEventType(
                ratType, NCGI_REPORT_EVENT_FAIL_NULL_NCGI_MR, ECGI_REPORT_EVENT_FAIL_NULL_ECGI_MR);
        case CGI_REPORT_RESULT_FAIL_TIMEOUT:
            return FnVCCB_GetReportCgiEventType(
                ratType, NCGI_REPORT_EVENT_FAIL_TIMEOUT, ECGI_REPORT_EVENT_FAIL_TIMEOUT);
        default:
            return -1;
    }
}

// FGS-SF0503 FR530 26A - STAT_ECGI_REPORT_ANR
void FnVCCB_CollectReportCgiStat(
    callInfo_type *ptCi, enumCgiReportReportResult_type type, uint8_t autonomousGapFlag, const char *fnName)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, fnName);

    if (IS_REPORT_CGI_FOR_HANDOVER(ptCi)) return;  // ANR purpose only, Not HO case

    if (GET_REPORT_CGI_STAT_COLLECT_REQUIRED(ptCi) != true) // ANR purpose only + Only one time collected
    {
        VCCB_PRINT_LOG_ANR(ptCi, "%s No need to collect STAT type:%d autonomousGapFlag:%d  \n", __func__, type,
            autonomousGapFlag);
        return;
    }

    uint8_t ratType = ptCi->anrInfo.ratType;
    if (ratType != nrType && ratType != eutraType) return;

    int eventType = FnVCCB_GetCgiReportStatType(ptCi, type);
    if (eventType == -1) return;

    if (ptCi->anrInfo.ratType == nrType)
    {
        FnVCCB_CollectStatNcgiReport(ptCi, static_cast<enumNcgiReportReportEvent_type>(eventType), autonomousGapFlag, fnName);
    }
    else
    {
        FnVCCB_CollectStatEcgiReport(ptCi, static_cast<enumEcgiReportReportEvent_type>(eventType), autonomousGapFlag, fnName);
    }

    SET_REPORT_CGI_STAT_COLLECT_REQUIRED(ptCi, VCCB_FLAG_OFF);
}

// INTRA_NR_ANR_24A FR760
#define STAT_NCGI_REPORT_AUTOGAP_ITEM_OFFSET 6
void FnVCCB_CollectStatNcgiReport(
    callInfo_type *ptCi, enumNcgiReportReportEvent_type type, uint8_t autonomousGapFlag, const char *fnName)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, fnName);

    int attTypeId = ((autonomousGapFlag) ? NcgiAttAutoGap : NcgiAttDrx);
    int typeId = (autonomousGapFlag) ? (type + STAT_NCGI_REPORT_AUTOGAP_ITEM_OFFSET) : type;

    if (typeId >= STAT_NCGI_REPORT_END) return;

    // Collect attempt type together
    MACRO_STAT_PMCC_NAME(STAT_NCGI_REPORT, attTypeId, ptCi, 0, 0, 0, 0, 0, fnName);
    MACRO_STAT_PMCC_NAME(STAT_NCGI_REPORT, typeId, ptCi, 0, 0, 0, 0, 0, fnName);
}

// FGS-SF0503 FR530 26A - STAT_ECGI_REPORT_ANR
#define STAT_ECGI_REPORT_AUTOGAP_ITEM_OFFSET 5
void FnVCCB_CollectStatEcgiReport(
    callInfo_type *ptCi, enumEcgiReportReportEvent_type type, uint8_t autonomousGapFlag, const char *fnName)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, fnName);

    int attTypeId = ((autonomousGapFlag) ? EcgiAttAutoGap_Anr : EcgiAttDrx_Anr);
    int typeId = (autonomousGapFlag) ? (type + STAT_ECGI_REPORT_AUTOGAP_ITEM_OFFSET) : type;

    if (typeId >= STAT_ECGI_REPORT_ANR_END) return;

    // Collect attempt type together
    MACRO_STAT_PMCC_NAME(STAT_ECGI_REPORT_ANR, attTypeId, ptCi, 0, 0, 0, 0, 0, fnName);
    MACRO_STAT_PMCC_NAME(STAT_ECGI_REPORT_ANR, typeId, ptCi, 0, 0, 0, 0, 0, fnName);
}

void VLIB_CollectAdditionalStatistic(int mFamily, int mActualFamily, int mType, callInfo_type *ptCi,
    unsigned int reserved2, unsigned int reserved3, int reserved4, int reserved5, int reserved6)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    switch (mActualFamily)
    {
        case STAT_MENB_INIT_SGNB_REL_PER_GNB_PER_DU:
            if (mType != EndcRelByMenb_DU)
            {
                MACRO_STAT_PMCC(STAT_MENB_INIT_SGNB_REL_PER_GNB, EndcRelByMenb, ptCi, reserved2, reserved3, reserved4,
                    reserved5, reserved6);
            }
            return;

        case STAT_SGNB_INIT_SGNB_REL_PER_GNB_PER_DU:
            if (mType != EndcRelBySgnb_DU)
            {
                MACRO_STAT_PMCC(STAT_SGNB_INIT_SGNB_REL_PER_GNB, EndcRelBySgnb, ptCi, reserved2, reserved3, reserved4,
                    reserved5, reserved6);
            }
            return;

        default:
            break;
    }

    switch (mFamily)
    {
        case STAT_SGNB_ADD_PER_GNB:
        {
            if (INVALID_SRC_CALLID_FOR_IRAT_HO != ptCi->srcCuCpUeIdInterRATHo)
            {
                // Inter Rat SA->EN-DC
                // collect related statistic STAT_SGNB_ADD_EUTRAN_OUT
                MACRO_STAT_PMCC(
                    STAT_SGNB_ADD_EUTRAN_OUT, mType, ptCi, reserved2, reserved3, reserved4, reserved5, reserved6);
            }

            if (FOO.VF_VzwOnlyCounterFamily)
            {
                MACRO_STAT_PMCC(
                    STAT_SGNB_ADD_PER_DU_PER_GNB, mType, ptCi, reserved2, reserved3, reserved4, reserved5, reserved6);
                MACRO_STAT_PMCC(STAT_SGNB_ADD_PER_GNB_ECI_DU_ID, mType, ptCi, reserved2, reserved3, reserved4,
                    reserved5, reserved6);
                FnVCCB_CollectPmccInvalidCellSgNBAddition(ptCi, mFamily, mType);
            }
            else if (!(FOO.VF_BasicOperation_IndexgNBDUId || FOO.VF_MultipleOperatorRanSupport))
            {
                MACRO_STAT_PMCC(
                    STAT_SGNB_ADD_PER_GNB_PLMN, mType, ptCi, reserved2, reserved3, reserved4, reserved5, reserved6);
            }

            if (FOO.VF_SPIDBasedStatistics_ENDC)
            {
                uint16_t SPID = SPID_0;
                const bool isSpidStatConfigured = FnVCCB_setSpidCounterIndex(ptCi, SPID);

                if (isSpidStatConfigured)
                {
                    MACRO_STAT_PMCC(STAT_SGNB_ADD_PER_GNB_SPID_DU_ID, mType, ptCi, SPID, reserved3, reserved4,
                        reserved5, reserved6);
                }
            }
            break;
        }
        case STAT_ENDC_CTX_REL_ALL_PER_GNB_PLMN:
        {
            VLIB_PeggInSessionStatusFamilies(STAT_ENDC_CTX_REL_ALL_PER_GNB_PLMN_ACT, mType, ptCi, reserved2, reserved3,
                reserved4, reserved5, reserved6);

            uint16_t SPID = SPID_0;
            const bool isSpidStatConfigured = FnVCCB_setSpidCounterIndex(ptCi, SPID);
            if (isSpidStatConfigured)
            {
                if (FOO.VF_VzwOnlyCounterFamily)
                {
                    MACRO_STAT_PMCC(STAT_ENDC_CTX_REL_ALL_PER_GNB_PLMN_SPID_DU_ID, mType, ptCi, SPID, reserved3,
                        reserved4, reserved5, reserved6);
                }

                VLIB_PeggEndcCtxRelAllPerGnbGlobalIdPlmnSpid(
                    ptCi, mType, SPID, reserved3, reserved4, reserved5, reserved6);
            }
            break;
        }
        case STAT_MENB_INIT_SGNB_REL_PER_GNB:
        {
            if (FOO.VF_VzwOnlyCounterFamily)
            {
                uint16_t SPID = SPID_0;
                const bool isSpidStatConfigured = FnVCCB_setSpidCounterIndex(ptCi, SPID);
                if (isSpidStatConfigured)
                {
                    MACRO_STAT_PMCC(STAT_MENB_INIT_SGNB_REL_PER_GNB_SPID_DU_ID, mType, ptCi, SPID, reserved3, reserved4,
                        reserved5, reserved6);
                }
            }
            break;
        }
        case STAT_SGNB_INIT_SGNB_REL_PER_GNB:
        {
            if (FOO.VF_VzwOnlyCounterFamily)
            {
                uint16_t SPID = SPID_0;
                const bool isSpidStatConfigured = FnVCCB_setSpidCounterIndex(ptCi, SPID);
                if (isSpidStatConfigured)
                {
                    MACRO_STAT_PMCC(STAT_SGNB_INIT_SGNB_REL_PER_GNB_SPID_DU_ID, mType, ptCi, SPID, reserved3, reserved4,
                        reserved5, reserved6);
                }
            }
            break;
        }
        default:
            break;
    }
}

// Index: PLMN / gNB_ID / gNB_DU_ID / CellIdentity
void FnVccb_FillPlmnGnbIdDuIdCellIdStatIndex(callInfo_type *ptCi, VccbPmKey_type *pPmKey, bool isTarget)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pPmKey);

    VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);

    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];
    uint16_t cellNum = isTarget ? ptCi->hoInfo.targetCellNum : ptCi->servCellNum;
    VCCB_CHECK_VALID_CELLNUM_VOID(cellNum);

    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    uint32_t plmnIndex = 0;
    VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &plmnIndex);

    pPmKey->keyList[VCCB_PMKEY_INDEX1] = plmnIndex;                                         // PLMN
    pPmKey->keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;                        // gNB ID
    FnVCCB_UpdateGnbDuIdUsingCellId(
            ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX3], pCell->cellIdentity, ptCi->gnbNum);  // gNB_DU_ID
    pPmKey->keyList[VCCB_PMKEY_INDEX4] = pCell->cellIdentity;                               // cell Identity
}

// bool FnVCCB_FillRedirectionFrequencyIndex(VccbPmKey_type *pPmKey, callInfo_type *ptCi, uint8_t index, int mFamily)
// {
//     VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
//     VALID_E_POINT_CHECK_RET_VAL(pPmKey, false);
//     if (index >= MAX_VCCB_STAT_KEY_NUM) return false;

//     if (CI_use == ptCi->cacTriggeredRedirInfo.usage)
//     {
//         pPmKey->keyList[index] = (unsigned long long)ptCi->cacTriggeredRedirInfo.nr.ssbFrequency;
//     }
//     else if (ptCi->redirectionInfo.redirType == INTER_RAT_REDIRECTION)
//     {
//         pPmKey->keyList[index] = (unsigned long long)ptCi->redirectionInfo.rat.eutra.carrierFreq;
//     }
//     else if (ptCi->redirectionInfo.redirType == INTRA_RAT_REDIRECTION)
//     {
//         pPmKey->keyList[index] = (unsigned long long)ptCi->redirectionInfo.rat.nr.ssbFrequency;
//     }
//     else
//     {
//         // VCCB_PRINT_ERROR(mFamily == STAT_REDIR_EUTRAN_OUT ? "STAT_REDIR_EUTRAN_OUT" : "STAT_REDIR_NR_OUT",
//         //     ": redirection type(%d) is invalid!\n", ptCi->redirectionInfo.redirType);
//         VCCB_PRINT_CALL_ERROR(ptCi, "%s redirection type(%d) is invalid!\n",
//             mFamily == STAT_REDIR_EUTRAN_OUT ? "STAT_REDIR_EUTRAN_OUT" : "STAT_REDIR_NR_OUT",
//             ptCi->redirectionInfo.redirType);
//         return false;
//     }
//     return true;
// }

const char *FnVCCB_GetRedirectionFamilyString(int mFamily)
{
    return (mFamily == STAT_REDIR_EUTRAN_OUT) ? "STAT_REDIR_EUTRAN_OUT" : "STAT_REDIR_NR_OUT";
}

bool FnVCCB_FillRedirectionFrequencyIndex(VccbPmKey_type *pPmKey, callInfo_type *ptCi, uint8_t index, int mFamily)
{
    if (!ptCi || !pPmKey || index >= MAX_VCCB_STAT_KEY_NUM) return false;

    if (CI_use == ptCi->cacTriggeredRedirInfo.usage)
    {
        pPmKey->keyList[index] = static_cast<unsigned long long>(ptCi->cacTriggeredRedirInfo.nr.ssbFrequency);
    }
    else
    {
        switch (ptCi->redirectionInfo.redirType)
        {
            case INTER_RAT_REDIRECTION:
                pPmKey->keyList[index] = static_cast<unsigned long long>(ptCi->redirectionInfo.rat.eutra.carrierFreq);
                break;
            case INTRA_RAT_REDIRECTION:
                pPmKey->keyList[index] = static_cast<unsigned long long>(ptCi->redirectionInfo.rat.nr.ssbFrequency);
                break;
            default:
                VCCB_PRINT_CALL_ERROR(ptCi, "%s type(%d) is invalid!\n", FnVCCB_GetRedirectionFamilyString(mFamily),
                    ptCi->redirectionInfo.redirType);
                return false;
        }
    }
    return true;
}

int16_t VLIB_FillStatisticsIndex(callInfo_type *ptCi, int mFamily, int mType, VccbPmKey_type *pPmKey,
    int *pShmStoreFlag, uint64_t reserved2, uint64_t reserved3, int reserved4, int reserved5, int reserved6)
{
    AUTO_TRACE_FUNC;
    UNUSED4(reserved3, reserved4, reserved5, reserved6);

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pPmKey);
    VALID_E_POINT_CHECK_ERROR(pShmStoreFlag);

    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);

    uint32_t uePlmnKey = 0, gnbPlmn = 0;
    // {mcc:450, mnc:05F} -> '45005', {mcc:320, mnc:120} -> '320120'
    VLIB_ConvertPlmnIdToPlmnValue(&ptCi->ueInfo.servedPlmn.s2, &uePlmnKey);

    switch (mFamily)
    {
        case STAT_LB_PSCELL_CHANGE:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1]  = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2]  = GetDuId(ptCi->endPointInfo.gnbDuId);         // gNB_DU_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3]  = CELLINFO[ptCi->servCellNum].cellIdentity;    // CellIdentity
            pPmKey->keyList[VCCB_PMKEY_INDEX4]  = ptCi->hoInfo.cgi.ci;                         // TargetNCI
            break;

        case STAT_INTER_DU_PSCELL_CHANGE_GETTING_BACK:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1]  = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2]  = GetDuId(ptCi->endPointInfo.gnbDuId);         // gNB_DU_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3]  = CELLINFO[ptCi->servCellNum].cellIdentity;    // CellIdentity
            pPmKey->keyList[VCCB_PMKEY_INDEX4]  = ptCi->hoInfo.cellIdentity;                   // TgtCellIdentity
            break;

        case STAT_SGNB_ADD_PER_GNB:
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->endPointInfo.x2Idx, MAX_ENB_PER_GNB_CU_CP);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB_ID
            if (ptCi->servCellNum < MAX_CELL_NUM_VCCB)                    // CellIdentityWithInvalid
            {
                pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            }
            else
            {
                pPmKey->keyList[VCCB_PMKEY_INDEX2] = 0xFFFF;
            }
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = GNBINFO[ptCi->gnbNum].x2Nbr[ptCi->endPointInfo.x2Idx].enbId;  // eNB_ID
            break;
        case STAT_SGNB_ADD_PER_DU_PER_GNB:
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB_ID
            if (ptCi->servCellNum < MAX_CELL_NUM_VCCB)                    // CellIdentityWithInvalid
            {
                FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2], CELLINFO[ptCi->servCellNum].cellIdentity, ptCi->gnbNum); // gNB_DU_ID
            }
            else
            {
                FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2], MAX_CELL_IDENTITY, ptCi->gnbNum); // gNB_DU_ID
            }

            break;

        case STAT_SGNB_ADD_PER_GNB_PLMN:
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB_ID
            if (ptCi->servCellNum < MAX_CELL_NUM_VCCB)                    // CellIdentityWithInvalid
            {
                pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            }
            else
            {
                pPmKey->keyList[VCCB_PMKEY_INDEX2] = 0xFFFF;
            }
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = uePlmnKey;
            break;

        case STAT_SGNB_ADD_PER_GNB_ECI_DU_ID:
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;      // gNB_ID
            if (ptCi->servCellNum < MAX_CELL_NUM_VCCB)
            {
                FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2],
                    CELLINFO[ptCi->servCellNum].cellIdentity, ptCi->gnbNum);                      // gNB_DU_ID
                pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;    // CellIdentityWithInvalid
            }
            else
            {
                FnVCCB_UpdateGnbDuIdUsingCellId(
                    ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2], MAX_CELL_IDENTITY, ptCi->gnbNum);  // gNB_DU_ID
                pPmKey->keyList[VCCB_PMKEY_INDEX3] = 0xFFFF;                                      // CellIdentityWithInvalid
            }
            pPmKey->keyList[VCCB_PMKEY_INDEX4] =
                (ptCi->eCGI.ci < 0xFFFFFFF) ? ptCi->eCGI.ci : 0xFFFFFFF;                          // TgtEUTRANCellIdentity
            break;

        case STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG:
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->hoInfo.targetEnb.x2Idx, MAX_ENB_PER_GNB_CU_CP);

            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = ptCi->hoInfo.cellIdentity;
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = GNBINFO[ptCi->gnbNum].x2Nbr[ptCi->hoInfo.targetEnb.x2Idx].enbId;
            break;

        case STAT_SGNB_ADD_EUTRAN_OUT:
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB_ID
            if (ptCi->servCellNum < MAX_CELL_NUM_VCCB)                    // CellIdentityWithInvalid
            {
                pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            }
            else
            {
                pPmKey->keyList[VCCB_PMKEY_INDEX2] = 0xFFFF;
            }
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = ptCi->eCGI.ci;  // ECGI of Target EUTRA Cell
            break;

        case STAT_SGNB_ADD_REJECT_PER_GNB:
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = ptCi->unavailableCellIdAddReqFail;           // CellIdentity
            break;

        case STAT_SGNB_ADD_SGNB_CHG:
        case STAT_MENB_INIT_SGNB_REL_MCGMOB_UECTX_IND:
        case STAT_SGNB_ADD_MNHO_INTRA_ENB:
        case STAT_SGNB_ADD_MNHO_INTER_ENB:
        case STAT_MENB_INIT_SGNB_REL_PER_GNB:
        case STAT_SGNB_INIT_SGNB_REL_PER_GNB:
        case STAT_MENB_INIT_SGNB_MOD_PER_GNB:
        case STAT_SGNB_INIT_SGNB_MOD_PER_GNB:
        case STAT_SGNB_INIT_SGNB_REL_MR_PER_GNB:
        case STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB:
        case STAT_MENB_INIT_SGNB_REL_MCGMOB_PER_GNB:
        case STAT_MENB_INIT_SGNB_REL_TC_PER_GNB:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->endPointInfo.x2Idx, MAX_ENB_PER_GNB_CU_CP);

            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = GNBINFO[ptCi->gnbNum].x2Nbr[ptCi->endPointInfo.x2Idx].enbId;
            break;

        case STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG_GLOBAL_ID_SPID:
            VLIB_ConvertPlmnIdToPlmnValue(&GNBINFO[ptCi->gnbNum].globalGnbId.plmn.s2, &gnbPlmn);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = gnbPlmn;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = ptCi->hoInfo.cellIdentity;
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = ptCi->ueInfo.rfsp.subscriberProfile;
            pPmKey->keyList[VCCB_PMKEY_INDEX5] = uePlmnKey;
            break;

        case STAT_SGNB_ADD_MNHO_INTER_ENB_GLOBAL_ID_SPID:
        case STAT_SGNB_ADD_MNHO_INTRA_ENB_GLOBAL_ID_SPID:
        case STAT_SGNB_ADD_SGNB_CHG_GLOBAL_ID_SPID:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            VLIB_ConvertPlmnIdToPlmnValue(&GNBINFO[ptCi->gnbNum].globalGnbId.plmn.s2, &gnbPlmn);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = gnbPlmn;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = ptCi->ueInfo.rfsp.subscriberProfile;
            pPmKey->keyList[VCCB_PMKEY_INDEX5] = uePlmnKey;
            break;

        case STAT_ENDC_CTX_REL_ALL_PER_GNB_PLMN:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = uePlmnKey;
            break;

        case STAT_ENDC_CTX_REL_ALL_PER_GNB_PLMN_ACT:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = uePlmnKey;
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = IN_SESSION_STATUS_ACTIVE;          // InSessionStatus
            break;

        case STAT_ENDC_CTX_REL_ALL_PER_GNB_PLMN_SPID_DU_ID:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2],
                CELLINFO[ptCi->servCellNum].cellIdentity, ptCi->gnbNum); // gNB_DU_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = uePlmnKey;
            pPmKey->keyList[VCCB_PMKEY_INDEX5] = reserved2; // SPIDIncludingInvalid

            break;

        case STAT_ENDC_CTX_REL_ALL_PER_GNB_GLOBAL_ID_PLMN_SPID:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            VLIB_ConvertPlmnIdToPlmnValue(&GNBINFO[ptCi->gnbNum].globalGnbId.plmn.s2, &gnbPlmn);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = gnbPlmn;                                       // PLMN
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;    // gNB_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;      // CellIdentityWithInvalid
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = uePlmnKey;                                     // PLMN_UE
            pPmKey->keyList[VCCB_PMKEY_INDEX5] = reserved2;                                     // SPIDIncludingInvalid
            break;

        case STAT_ENDC_CTX_REL_ALL_PER_GNB_GLOBAL_ID_PLMN_SPID_ACT:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            VLIB_ConvertPlmnIdToPlmnValue(&GNBINFO[ptCi->gnbNum].globalGnbId.plmn.s2, &gnbPlmn);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = gnbPlmn;                                       // PLMN
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;    // gNB_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;      // CellIdentityWithInvalid
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = uePlmnKey;                                     // PLMN_UE
            pPmKey->keyList[VCCB_PMKEY_INDEX5] = reserved2;                                     // SPIDIncludingInvalid
            pPmKey->keyList[VCCB_PMKEY_INDEX6] = IN_SESSION_STATUS_ACTIVE;                      // InSessionStatus
            break;

        case STAT_F1AP_UE_SETUP_CU:
            if (DBG->log.logStoreStatMsgCnt == VCCB_FLAG_OFF) *pShmStoreFlag = FALSE;  // not store msg count stat

            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            VLIB_StatSelectCellIdIndex(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2], mFamily, (int)reserved2);
            VLIB_StatSelectF1CauseIndex(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX3], mFamily);
            break;

        case STAT_F1AP_CU_INIT_UE_MOD_CU:
            if (DBG->log.logStoreStatMsgCnt == VCCB_FLAG_OFF) *pShmStoreFlag = FALSE;  // not store msg count stat

            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            VLIB_StatSelectCellIdIndex(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2], mFamily, (int)reserved2);
            VLIB_StatSelectF1CauseIndex(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX3], mFamily);
            break;

        case STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = ptCi->hoInfo.cellIdentity;
            break;

        case STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->hoInfo.hoGnbIdx, MAX_GNB_PER_CALL);

            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = ptCi->gnbInfo[ptCi->hoInfo.hoGnbIdx].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = ptCi->hoInfo.cellIdentity;
            break;

        case STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB_DU_ID_CELL_SPID:
        case STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB_DU_ID_CELL_SPID:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            VLIB_ConvertPlmnIdToPlmnValue(&GNBINFO[ptCi->gnbNum].globalGnbId.plmn.s2, &gnbPlmn);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = gnbPlmn;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = GetDuId(ptCi->endPointInfo.gnbDuId);
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pPmKey->keyList[VCCB_PMKEY_INDEX5] = ptCi->ueInfo.rfsp.subscriberProfile;
            pPmKey->keyList[VCCB_PMKEY_INDEX6] = uePlmnKey;
            break;

        case STAT_INTRA_FREQ_PSCELL_CHANGE_SCGMOB_PER_GNB_DU_ID:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            VLIB_ConvertPlmnIdToPlmnValue(&GNBINFO[ptCi->gnbNum].globalGnbId.plmn.s2, &gnbPlmn);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = gnbPlmn;                                    // PLMN
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id; // gNB_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = GetDuId(ptCi->endPointInfo.gnbDuId);        // gNB_DU_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = CELLINFO[ptCi->servCellNum].cellIdentity;   // SrcCellIdentity
            pPmKey->keyList[VCCB_PMKEY_INDEX5] = uePlmnKey;                                  // PLMN_UE
            break;

        case STAT_SCG_FAIL_OPER:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            // For attempt-success stats pegged with delay (e.g. after successful HO).
            if ((0 != reserved2) && (MAX_CELL_IDENTITY > ptCi->scgFailAttSuccStats.cellId))
            {
                pPmKey->keyList[VCCB_PMKEY_INDEX2] = ptCi->scgFailAttSuccStats.cellId;
            }
            // Default behavor.
            else
            {
                pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            }
            break;
        case STAT_AS_SECURITY_GLOBAL_ID_DU_ID:
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = uePlmnKey;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX3]  = GetDuId(ptCi->endPointInfo.gnbDuId);
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = CELLINFO[ptCi->servCellNum].cellIdentity;
            break;

        case STAT_HO_INTRA_FREQ_OUT:
        case STAT_NRDC_SCG_FAILURE:
        case STAT_SOURCE_CELL_MR:
        case STAT_PLMN_HO_OUT:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            break;

        case STAT_PSCELL_CHANGE_REFUSED_MCGMOB_PER_CELL_DU_ID:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            VLIB_ConvertPlmnIdToPlmnValue(&GNBINFO[ptCi->gnbNum].globalGnbId.plmn.s2, &gnbPlmn);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = gnbPlmn;                                    // PLMN
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id; // gNB_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = GetDuId(ptCi->endPointInfo.gnbDuId);        // gNB_DU_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = CELLINFO[ptCi->servCellNum].cellIdentity;   // SrcCellIdentity
            break;

        case STAT_NR_MEAS_PCI:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = reserved2;
            break;

        case STAT_EUTRA_MEAS_PCI: // IRAT_ANR FR500
            FnVccb_FillPlmnGnbIdDuIdCellIdStatIndex(ptCi, pPmKey, false); // Index (1 ~ 4) : PLMN, gNB ID, gNB_DU_ID, cell Identity
            pPmKey->keyList[VCCB_PMKEY_INDEX5] = reserved2;   // TgtEarfcnDl
            break;

        case STAT_REDIR_EUTRAN_OUT:
        case STAT_REDIR_NR_OUT:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            if (not FnVCCB_FillRedirectionFrequencyIndex(pPmKey, ptCi, VCCB_PMKEY_INDEX3, mFamily))
            {
                return ERROR;
            }
            break;

        case STAT_RRC_ESTAB:
        case STAT_NG_ESTAB:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = ptCi->ueInfo.establishmentCause;
            break;

        case STAT_NG_ESTAB_DU_ID_PLMN:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id; // gNB_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;   // CellIdentity
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2], (uint16_t)pPmKey->keyList[VCCB_PMKEY_INDEX3], MAX_GNB_PER_SYS); /* DU_ID */
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = uePlmnKey;                                  // PLMN_UE
            pPmKey->keyList[VCCB_PMKEY_INDEX5] = ptCi->ueInfo.establishmentCause;            // Estab Cause
            break;

        case STAT_INITIAL_CONTEXT_SETUP:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            VLIB_ConvertPlmnIdToPlmnValue(&GNBINFO[ptCi->gnbNum].globalGnbId.plmn.s2, &gnbPlmn);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = gnbPlmn;                                        // PLMN
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;     // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX3], CELLINFO[ptCi->servCellNum].cellIdentity, MAX_GNB_PER_SYS); /* DU_ID */
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = CELLINFO[ptCi->servCellNum].cellIdentity;       // CellIdentity
            break;

        case STAT_RRC_REESTAB:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = ptCi->ueInfo.reestablishInfo.reestCause;
            break;

        case STAT_RRC_RECONFIG:
        case STAT_RRC_RELEASE:
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            VLIB_StatSelectCellIdIndex(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2], mFamily, 0);
            break;

        case STAT_NR_REJECTED_SA_CALL:
            /* comparison is always false due to limited range of data type
                VCCB_CHECK_E_RANGE_AND_RETURN(reserved2, MAX_GNB_IDENTITY); */
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = reserved2;
            break;

        case STAT_HO_OUT:
        {
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;    // Cell ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = ptCi->hoInfo.cgi.ci;                         // NCI of Target Cell
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = ptCi->hoInfo.cause;                          // HO Purpose...enum=DLQuality(0),Reserved(1)
        }
        break;

        case STAT_CHO_OUT:
        {
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1]  = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2]  = GetDuId(ptCi->endPointInfo.gnbDuId);         // gNB_DU_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3]  = CELLINFO[ptCi->servCellNum].cellIdentity;    // Cell ID
            pPmKey->keyList[VCCB_PMKEY_INDEX4]  = ptCi->hoInfo.cgi.ci;                         // NCI of Target Cell
        }
        break;

        case STAT_HO_INTER_FREQ_OUT:
        {
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;    // Cell ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = reserved2;                                   // TgtNrArfcn
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = ptCi->hoInfo.cause;                          // HO Purpose...enum=DLQuality(0),Reserved(1)
        }
        break;

        case STAT_HO_IN:
        {
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = ptCi->hoInfo.cellIdentity;                   // NCI of Target Cell
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = ptCi->hoInfo.cause;                          // HO Purpose...enum=DLQuality(0),Reserved(1)
        }
        break;

        case STAT_CHO_IN:
        {
            pPmKey->keyList[VCCB_PMKEY_INDEX1]  = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2]  = GetDuId(ptCi->endPointInfo.gnbDuId);         // gNB_DU_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3]  = ptCi->hoInfo.cellIdentity;                   // NCI of Target Cell
        }
        break;

        case STAT_HO_EUTRAN_OUT:
        case STAT_HO_EUTRAN_OUT_FALLBACK:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;    // cell Identity
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = ptCi->hoInfo.cause;                          // HO Purpose...enum=DLQuality(0),Reserved(1)
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = ptCi->hoInfo.cgi.ci;                         // NCI of Target Cell
            break;

        case STAT_HO_EUTRAN_FREQ_OUT: // IRAT_HO_24A
        case STAT_HO_EUTRAN_FREQ_OUT_REDCAP:
        {
            FnVccb_FillPlmnGnbIdDuIdCellIdStatIndex(ptCi, pPmKey, false); // Index (1 ~ 4) : PLMN, gNB ID, gNB_DU_ID, cell Identity
            pPmKey->keyList[VCCB_PMKEY_INDEX5] = ptCi->hoInfo.tArfcn;   // TgtEarfcnDl
        }
        break;

        case STAT_HO_INTER_FREQ_OUT_REDCAP:
        {
            FnVccb_FillPlmnGnbIdDuIdCellIdStatIndex(ptCi, pPmKey, false); // Index (1 ~ 4) : PLMN, gNB ID, gNB_DU_ID, cell Identity
            pPmKey->keyList[VCCB_PMKEY_INDEX5] = reserved2;   // TgtEarfcnDl
        }
        break;

        case STAT_FORCED_MOBILITY_NR:
        case STAT_FORCED_MOBILITY_EUTRAN:
        {
            FnVccb_FillPlmnGnbIdDuIdCellIdStatIndex(ptCi, pPmKey, false); // Index (1 ~ 4) : PLMN, gNB ID, gNB_DU_ID, cell Identity
            pPmKey->keyList[VCCB_PMKEY_INDEX5] = reserved2;        // TgtNrArfcn or NR Redirected Carrier or PCell freq
                                                                   // TgtEarfcnDl or EUTRA Redirected Carrier
        }
        break;

        case STAT_HO_EUTRAN_IN_REDCAP:     // 6029
        {
            VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];

            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

            uint32_t plmnValue = 0;
            VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &plmnValue);

            pPmKey->keyList[VCCB_PMKEY_INDEX1] = plmnValue;                                             // PLMN
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;                            // gNB ID
            FnVCCB_UpdateGnbDuIdUsingCellId(
                    ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX3], pCell->cellIdentity, ptCi->gnbNum);      // gNB_DU_ID

            pPmKey->keyList[VCCB_PMKEY_INDEX4] = pCell->cellIdentity;                                   // cell Identity
        }
        break;

        case STAT_HO_IN_REDCAP:
        {
            VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];

            uint32_t plmnValue = 0;
            VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &plmnValue);

            pPmKey->keyList[VCCB_PMKEY_INDEX1] = plmnValue;                                             // PLMN
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;                            // gNB ID
            FnVCCB_UpdateGnbDuIdUsingCellId(
                    ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX3], ptCi->hoInfo.cellIdentity, ptCi->gnbNum);      // gNB_DU_ID

            pPmKey->keyList[VCCB_PMKEY_INDEX4] = ptCi->hoInfo.cellIdentity;                                   // cell Identity
        }
        break;

        case STAT_HO_INTRA_FREQ_OUT_REDCAP:
        {
            VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];

            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

            uint32_t plmnValue = 0;
            VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &plmnValue);

            pPmKey->keyList[VCCB_PMKEY_INDEX1] = plmnValue;                                             // PLMN
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;                            // gNB ID
            FnVCCB_UpdateGnbDuIdUsingCellId(
                    ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX3], pCell->cellIdentity, ptCi->gnbNum);      // gNB_DU_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = pCell->cellIdentity;                                   // cell Identity
        }
        break;

        case STAT_HO_EUTRAN_IN:
        {
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = ptCi->hoInfo.cellIdentity;                   // NCI of Target Cell
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = ptCi->hoInfo.cause;                          // HO Purpose...enum=DLQuality(0),Reserved(1)
        }
        break;

        case STAT_PINGPONG:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->upmInfo.upmStatInfo.upmStoreCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->upmInfo.upmStatInfo.upmStoreCellNum].cellIdentity;
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = ptCi->upmInfo.upmStatInfo.targetCgi.ci;  // NCI of Target Cell
            break;

        case STAT_NEDC_SCG_FAIL_OPER:  // ranking type required // NEDC_SCG_FAILURE_20C
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;    // Cell ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = VLIB_GetNedcSnodeEnbId(ptCi);                // enbId in SN
            break;

        case STAT_NEDC_ADD:
        case STAT_NEDC_MGNB_INIT_REL:
        case STAT_NEDC_SENB_INIT_REL:
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->mrdcInfo.SNInfo[SRC_SN].epIdx, MAX_XN_NBR_PER_GNB);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = GNBINFO[ptCi->gnbNum].xnNbr[ptCi->mrdcInfo.SNInfo[SRC_SN].epIdx].enbId.id;
            break;

        case STAT_NRDC_SN_ADD_MN:
        {
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            uint16_t endPointIdx;
            switch (mType)
            {
                case NrdcAddMn_IntraMnMobilityWithSgnbChg_Att ... NrdcAddMn_InterMnMobilityWithSgnbChg_Fail_RrcFail:
                case NrdcAddMn_SnChange_Att ... NrdcAddMn_SnChange_Fail_RrcFail:
                    endPointIdx = ptCi->mrdcInfo.SNInfo[TGT_SN].epIdx;
                    break;
                default:
                    endPointIdx = ptCi->mrdcInfo.SNInfo[SRC_SN].epIdx;
                    break;
            }
            xnNbrInfo_type *pXnNbr = FnVCCB_GetXnNbrInfo(ptCi->gnbNum, endPointIdx);
            if (pXnNbr == NULL)
            {
                VCCB_PRINT_CALL_COMMENT(
                    ptCi, "Invalid xnEndPoint : Ignore Case (gnbNum:%u, epIdx:%u)\n", ptCi->gnbNum, endPointIdx);
                return ERROR;
            }

            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // MgNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;    // Cell ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = pXnNbr->gnbId.id;
            VCCB_FLAG_ON_FOR_DBG_LOG_NRDC_BASIC(*pShmStoreFlag);
            break;
        }

        case STAT_NRDC_SN_ADD_MN_PSCELL_NCI:
        {
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            uint16_t endPointIdx;
            SNInfo_type snInfo = ptCi->mrdcInfo.SNInfo[SRC_SN];

            switch (mType)
            {
                case NrdcAddMn_IntraMnMobilityWithSgnbChg_Att ... NrdcAddMn_InterMnMobilityWithSgnbChg_Fail_RrcFail:
                case NrdcAddMn_SnChange_Att ... NrdcAddMn_SnChange_Fail_RrcFail:
                    snInfo      = ptCi->mrdcInfo.SNInfo[TGT_SN];
                    endPointIdx = snInfo.epIdx;
                    break;
                default:
                    endPointIdx = snInfo.epIdx;
                    break;
            }
            xnNbrInfo_type *pXnNbr = FnVCCB_GetXnNbrInfo(ptCi->gnbNum, endPointIdx);
            if (pXnNbr == NULL)
            {
                VCCB_PRINT_CALL_COMMENT(
                    ptCi, "Invalid xnEndPoint : Ignore Case (gnbNum:%u, epIdx:%u)\n", ptCi->gnbNum, endPointIdx);
                return ERROR;
            }

            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // MgNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = GetDuId(ptCi->endPointInfo.gnbDuId);         // DU ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;    // Cell ID
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = pXnNbr->gnbId.id;                            // SgNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX5] =
                (snInfo.selectedPsCell.locationInfo.present
                    ? snInfo.selectedPsCell.locationInfo.nrCgi.ci: 0x1000000000);             // PSCell NCI with invalid

            VCCB_FLAG_ON_FOR_DBG_LOG_NRDC_BASIC(*pShmStoreFlag);
            break;
        }
        case STAT_NRDC_SN_REL_MN:
        {
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            VCCB_CHECK_E_RANGE_AND_RETURN(reserved2, MAX_SN);
            uint16_t endPointIdx = ptCi->mrdcInfo.SNInfo[reserved2].epIdx;

            xnNbrInfo_type *pXnNbr = FnVCCB_GetXnNbrInfo(ptCi->gnbNum, endPointIdx);
            if (pXnNbr == NULL)
            {
                VCCB_PRINT_CALL_COMMENT(
                    ptCi, "Invalid xnEndPoint : Ignore Case (gnbNum:%u, epIdx:%u)\n", ptCi->gnbNum, endPointIdx);
                return ERROR;
            }

            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // MgNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;    // Cell ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = pXnNbr->gnbId.id;
            VCCB_FLAG_ON_FOR_DBG_LOG_NRDC_BASIC(*pShmStoreFlag);
            break;
        }
        case STAT_NRDC_SN_REL_MN_PSCELL_NCI:
        {
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            VCCB_CHECK_E_RANGE_AND_RETURN(reserved2, MAX_SN);

            uint16_t endPointIdx = ptCi->mrdcInfo.SNInfo[reserved2].epIdx;;
            SNInfo_type snInfo = ptCi->mrdcInfo.SNInfo[reserved2];

            xnNbrInfo_type *pXnNbr = FnVCCB_GetXnNbrInfo(ptCi->gnbNum, endPointIdx);
            if (pXnNbr == NULL)
            {
                VCCB_PRINT_CALL_COMMENT(
                    ptCi, "Invalid xnEndPoint : Ignore Case (gnbNum:%u, epIdx:%u)\n", ptCi->gnbNum, endPointIdx);
                return ERROR;
            }

            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // MgNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = GetDuId(ptCi->endPointInfo.gnbDuId);         // DU ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;    // Cell ID
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = pXnNbr->gnbId.id;                            // SgNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX5] =
                (snInfo.selectedPsCell.locationInfo.present
                    ? snInfo.selectedPsCell.locationInfo.nrCgi.ci: 0x1000000000);             // PSCell NCI with invalid

            VCCB_FLAG_ON_FOR_DBG_LOG_NRDC_BASIC(*pShmStoreFlag);
            break;
        }
        case STAT_NRDC_SN_ADD_SN_WITH_INVALID_CELL:
        {
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);

            uint16_t endPointIdx;
            switch (mType)
            {
                case NrdcAddSn_InterMnMobilityWithoutSgnbChange_Att ... NrdcAddSn_InterMnMobilityWithoutSgnbChange_Fail_DuFail:
                    // case NrdcAddSn_InterMnMobilityWithSgnbChange_Att ...
                    // NrdcAddSn_InterMnMobilityWithoutSgnbChange_Fail_DuFail:
                    endPointIdx = ptCi->hoInfo.targetGnb.xnIdx;
                    break;
                default:
                    endPointIdx = ptCi->endPointInfo.xnIdx;
                    break;
            }

            xnNbrInfo_type *pXnNbr = FnVCCB_GetXnNbrInfo(ptCi->gnbNum, endPointIdx);

            if (pXnNbr == NULL)
            {
                VCCB_PRINT_CALL_COMMENT(
                    ptCi, "Invalid xnEndPoint : Ignore Case (gnbNum:%u, epIdx:%u)\n", ptCi->gnbNum, endPointIdx);
                return ERROR;
            }
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // SgNB ID

            pPmKey->keyList[VCCB_PMKEY_INDEX2] =
                (ptCi->servCellNum < MAX_CELL_NUM_VCCB) ? CELLINFO[ptCi->servCellNum].cellIdentity : 0xFFFF;  // Cell ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = pXnNbr->gnbId.id;
            VCCB_FLAG_ON_FOR_DBG_LOG_NRDC_BASIC(*pShmStoreFlag);
            break;
        }
        case STAT_NRDC_SN_ADD_SN_PCELL_NCI:
        {
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);

            uint16_t endPointIdx;
            MNInfo_type mnInfo;
            switch (mType)
            {
                case NrdcAddSn_IntraMnMobilityWithSgnbChange_Att ... NrdcAddSn_InterMnMobilityWithSgnbChange_Fail_DuFail:
                    endPointIdx = ptCi->endPointInfo.xnIdx;
                    mnInfo = ptCi->mrdcInfo.MNInfo[TGT_MN];
                    break;

                case NrdcAddSn_InterMnMobilityWithoutSgnbChange_Att ... NrdcAddSn_InterMnMobilityWithoutSgnbChange_Fail_DuFail:
                    endPointIdx = ptCi->hoInfo.targetGnb.xnIdx;
                    mnInfo = ptCi->mrdcInfo.MNInfo[TGT_MN];
                    break;

                case NrdcAddSn_SnChange_Att ... NrdcAddSn_SnChange_Fail_DuFail:
                    endPointIdx = ptCi->endPointInfo.xnIdx;
                    mnInfo = ptCi->mrdcInfo.MNInfo[TGT_MN];
                    break;

                default:
                    endPointIdx = ptCi->endPointInfo.xnIdx;
                    mnInfo = ptCi->mrdcInfo.MNInfo[SRC_MN];
                    break;
            }

            xnNbrInfo_type *pXnNbr = FnVCCB_GetXnNbrInfo(ptCi->gnbNum, endPointIdx);

            if (pXnNbr == NULL)
            {
                VCCB_PRINT_CALL_COMMENT(
                    ptCi, "Invalid xnEndPoint : Ignore Case (gnbNum:%u, epIdx:%u)\n", ptCi->gnbNum, endPointIdx);
                return ERROR;
            }
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;                  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] =
                (ptCi->servCellNum < MAX_CELL_NUM_VCCB) ? CELLINFO[ptCi->servCellNum].cellIdentity : 0xFFFF;  // Cell ID, HO 검토 필요
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2], (uint16_t)pPmKey->keyList[VCCB_PMKEY_INDEX3], MAX_GNB_PER_SYS);  // gNB_DU_ID, HO 검토 필요
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = pXnNbr->gnbId.id;                                            // MgNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX5] =
                (mnInfo.m.usage == VCCB_FLAG_ON && mnInfo.m.mnNRCGI == VCCB_FLAG_ON) ? mnInfo.mnNRCGI.ci : 0x1000000000; //PCell ID, HO 검토 필요
            VCCB_FLAG_ON_FOR_DBG_LOG_NRDC_BASIC(*pShmStoreFlag);
            break;
        }
        case STAT_NRDC_SN_REL_SN:
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // SgNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;    // Cell ID

            if (IS_INTRA_GNB_NRDC_SN(ptCi))
            {
                pPmKey->keyList[VCCB_PMKEY_INDEX3] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // MgNB ID = SgNB ID
            }
            else
            {
                pPmKey->keyList[VCCB_PMKEY_INDEX3] = ptCi->endPointInfo.xnGnbId;  // MgNB ID
            }
            VCCB_FLAG_ON_FOR_DBG_LOG_NRDC_BASIC(*pShmStoreFlag);
            break;
        case STAT_NRDC_SN_REL_SN_PCELL_NCI:
        {
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);

            xnNbrInfo_type *pXnNbr = FnVCCB_GetXnNbrInfo(ptCi->gnbNum, ptCi->endPointInfo.xnIdx);
            if (pXnNbr == NULL)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "Invalid xnEndPoint : Ignore Case (gnbNum:%u, epIdx:%u)\n", ptCi->gnbNum, ptCi->endPointInfo.xnIdx);
                return ERROR;
            }

            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;     // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;       // Cell ID,   HO 검토 필요
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2], (uint16_t)pPmKey->keyList[VCCB_PMKEY_INDEX3], MAX_GNB_PER_SYS);  // gNB_DU_ID, HO 검토 필요
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = pXnNbr->gnbId.id;                               // MgNB ID,   HO 검토 필요
            const MNInfo_type &mnInfo = ptCi->mrdcInfo.MNInfo[SRC_MN];
            pPmKey->keyList[VCCB_PMKEY_INDEX5] =
                (mnInfo.m.usage == VCCB_FLAG_ON && mnInfo.m.mnNRCGI == VCCB_FLAG_ON) ? mnInfo.mnNRCGI.ci : 0x1000000000;  //PCell ID, HO 검토 필요

            VCCB_FLAG_ON_FOR_DBG_LOG_NRDC_BASIC(*pShmStoreFlag);
            break;
        }
        // FGR-CC5200:FR640
        case STAT_NRDC_CTX_REL:
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->endPointInfo.gnbDuId, MAX_GNB_DU_ID + 1);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1]  = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;                   // gNB_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2]  = GetDuId(ptCi->endPointInfo.gnbDuId);                          // gNB_DU_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3]  = CELLINFO[ptCi->servCellNum].cellIdentity;                     // CellIdentity
            pPmKey->keyList[VCCB_PMKEY_INDEX4]  = uePlmnKey;                                                    // UE_PLMN
            pPmKey->keyList[VCCB_PMKEY_INDEX5]  = reserved2;                                                    // DataActivityStatus
            VCCB_FLAG_ON_FOR_DBG_LOG_NRDC_BASIC(*pShmStoreFlag);
            break;
        // FGR-CC5200:FR641
        case STAT_NRDC_CTX_REL_SERVICE_TYPE:
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->endPointInfo.gnbDuId, MAX_GNB_DU_ID + 1);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = GetDuId(ptCi->endPointInfo.gnbDuId);         // gNB_DU_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;    // CellIdentity
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = reserved2;                                   // ServiceType_SA
            pPmKey->keyList[VCCB_PMKEY_INDEX5] = reserved3;                                   // DataActivityStatus
            VCCB_FLAG_ON_FOR_DBG_LOG_NRDC_BASIC(*pShmStoreFlag);
            break;
        case V_STAT_NRDC_SN_MOD_MN_MNInitiated:
        case V_STAT_NRDC_SN_MOD_MN_SNInitiated:
        {
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->endPointInfo.gnbDuId, MAX_GNB_DU_ID + 1);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            uint16_t endPointIdx = ptCi->mrdcInfo.SNInfo[SRC_SN].epIdx;

            xnNbrInfo_type *pXnNbr = FnVCCB_GetXnNbrInfo(ptCi->gnbNum, endPointIdx);
            if (pXnNbr == NULL)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "Invalid xnEndPoint : Ignore Case (gnbNum:%u, epIdx:%u) for family(%d)\n",
                    ptCi->gnbNum, endPointIdx, mFamily);
                return ERROR;
            }

            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // MgNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = GetDuId(ptCi->endPointInfo.gnbDuId);         // DU ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;    // Cell ID
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = pXnNbr->gnbId.id;
            VCCB_FLAG_ON_FOR_DBG_LOG_NRDC_BASIC(*pShmStoreFlag);
            break;
        }

        case V_STAT_NRDC_SN_MOD_SN_MNInitiated:
        case V_STAT_NRDC_SN_MOD_SN_SNInitiated:
        {
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->endPointInfo.gnbDuId, MAX_GNB_DU_ID + 1);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);

            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // SgNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = GetDuId(ptCi->endPointInfo.gnbDuId);         // DU ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;    // Cell ID
            if (IS_INTRA_GNB_NRDC_SN(ptCi))
            {
                pPmKey->keyList[VCCB_PMKEY_INDEX4] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // MgNB ID = SgNB ID
            }
            else
            {
                pPmKey->keyList[VCCB_PMKEY_INDEX4] = ptCi->endPointInfo.xnGnbId;  // MgNB ID
            }
            VCCB_FLAG_ON_FOR_DBG_LOG_NRDC_BASIC(*pShmStoreFlag);
            break;
        }
        case STAT_RAN_PAGING:
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            break;

        case STAT_RRC_INACTIVE_INFO:
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = ptCi->ueInfo.RrcInactiveInfo.resumeCause;
            break;

        case STAT_NR_TARGET_CELL_MR:
        case STAT_INTER_RAT_TARGET_CELL_MR:
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = reserved2;
            break;

        case STAT_IDLE_LB:
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;    // Cell ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = reserved2;                                   // TgtNrArfcn
            break;

        case STAT_INTRA_NR_IDLE_LB:
            FnVccb_FillPlmnGnbIdDuIdCellIdStatIndex(ptCi, pPmKey, false);
            pPmKey->keyList[VCCB_PMKEY_INDEX5] = reserved2;  // TgtNrArfcn
            break;

        case STAT_LB_HO:
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;    // Cell ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = ptCi->hoInfo.cgi.ci;                         // NCI of Target Cell
            break;

        case STAT_INTRA_NR_LB_HO:
            FnVccb_FillPlmnGnbIdDuIdCellIdStatIndex(ptCi, pPmKey, false); // Index (1 ~ 4) : PLMN, gNB ID, gNB_DU_ID, cell Identity
            pPmKey->keyList[VCCB_PMKEY_INDEX5] = ptCi->hoInfo.cgi.ci;                         // TargetNCI
            break;

        case STAT_MRO_PER_CELL:
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = VLIB_NrCellId2CellId(GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.idLength,
                reserved2);  // Cell ID
            break;

        case STAT_MRO_PER_NBR:
        case STAT_MRO_PER_EUTRA_NBR:
        case STAT_UPM_RLF_NR:
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = VLIB_NrCellId2CellId(GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.idLength,
                reserved2);              // Cell ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = reserved3;  // TargetNCI
            break;

        case STAT_COVERAGE_PROBLEM_DU_ID:
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = VLIB_NrCellId2CellId(GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.idLength,
                reserved2);  // Cell ID
            FnVCCB_UpdateGnbDuIdUsingCellId(
                ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2], (uint16_t)pPmKey->keyList[VCCB_PMKEY_INDEX3], MAX_GNB_PER_SYS);  // gNB DU ID
            break;

        case STAT_NRDC_PSCELL_CHANGE_IN:
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = ptCi->hoInfo.cellIdentity;                   // NCI of Target Cell
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = ptCi->hoInfo.cause;                          // HO Purpose...enum=DLQuality(0),Reserved(1)
            break;

        case STAT_NRDC_PSCELL_CHANGE_OUT:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;    // Cell ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = ptCi->hoInfo.cause;                          // HO Purpose...enum=DLQuality(0),Reserved(1)
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = ptCi->hoInfo.cgi.ci;                         // NCI of Target Cell
            break;

        case STAT_CA_SCELL_ADD_REL:
            VCCB_CHECK_VALID_CELLNUM_ERROR(reserved3);                   // servCellNum provided as reserved3
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[reserved3].cellIdentity;            // CellIdentity
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = reserved2;  // scell cellIdentity provided as parameter of MACRO_STAT_PMCC
            break;

        case STAT_MEAS_FOR_SON_CELL:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->NRCANbrCellAutoConfig.nbrGnbCellIndex, MAX_NBR_PER_CELL);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;    // Cell ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = VLIB_GnbIdCellId2NrCellId(
                &CELLINFO[ptCi->servCellNum].Nbr[ptCi->NRCANbrCellAutoConfig.nbrGnbCellIndex].targetGnbId.gnbId,
                CELLINFO[ptCi->servCellNum]
                    .Nbr[ptCi->NRCANbrCellAutoConfig.nbrGnbCellIndex]
                    .targetCellId);  // Target NCI
            break;

        case STAT_MEAS_FOR_SON_FREQ:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;    // Cell ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = reserved2;                                   // TgtNrArfcn
            break;

        case STAT_MEAS_FOR_SON_EUTRA_FREQ_DU_ID:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            VCCB_CHECK_E_RANGE_AND_RETURN(CELLINFO[ptCi->servCellNum].endPointF1Index, MAX_GNB_DU_PER_GNB_CU_CP);
            pPmKey->keyList[VCCB_PMKEY_INDEX1]  = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;                                                // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2]  = GetDuId(GNBINFO[ptCi->gnbNum].gnbDu[CELLINFO[ptCi->servCellNum].endPointF1Index].gnbDuId); // gNB DU ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3]  = CELLINFO[ptCi->servCellNum].cellIdentity;                                                  // Cell ID
            pPmKey->keyList[VCCB_PMKEY_INDEX4]  = reserved2;                                                                                 // TgtEarfcnDl
            break;

        case STAT_MEAS_FOR_SON_EUTRA_CELL_DU_ID:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            VCCB_CHECK_E_RANGE_AND_RETURN(CELLINFO[ptCi->servCellNum].endPointF1Index, MAX_GNB_DU_PER_GNB_CU_CP);
            pPmKey->keyList[VCCB_PMKEY_INDEX1]  = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;                                                // gNB ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2]  = GetDuId(GNBINFO[ptCi->gnbNum].gnbDu[CELLINFO[ptCi->servCellNum].endPointF1Index].gnbDuId); // gNB DU ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3]  = CELLINFO[ptCi->servCellNum].cellIdentity;                                                  // Cell ID
            pPmKey->keyList[VCCB_PMKEY_INDEX4]  = reserved2;                                                                                 // TgtEUTRANCellIdentity
            break;

        case STAT_DISCARD_MR_BY_CONDITION_INTRA_NR:
        case STAT_DISCARD_MR_BY_CONDITION_NR_TO_LTE:
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = CELLINFO[ptCi->servCellNum].cellIdentity;    // CellIdentity
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = reserved2;                                   // TgtNrArfcn or TgtEarfcnDl
            break;

        case STAT_NRDC_UL_PATH_SWITCH:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            FnVCCB_UpdateGnbDuIdUsingCellId(
                ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2], CELLINFO[ptCi->servCellNum].cellIdentity, MAX_GNB_PER_SYS);
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;
            break;
        case STAT_NRDC_UL_PATH_SWITCH_SERVICE_TYPE:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
            FnVCCB_UpdateGnbDuIdUsingCellId(
                ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2], CELLINFO[ptCi->servCellNum].cellIdentity, MAX_GNB_PER_SYS);
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = reserved2;                                   // ServiceType_SA
            break;

        case STAT_UL_PATH_SWITCH:
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1]  = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2],
                CELLINFO[ptCi->servCellNum].cellIdentity, ptCi->gnbNum); // gNB_DU_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3]  = CELLINFO[ptCi->servCellNum].cellIdentity;    // CellIdentity
            break;

        case STAT_UL_PATH_SWITCH_SPID:
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1]  = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2],
                CELLINFO[ptCi->servCellNum].cellIdentity, ptCi->gnbNum); // gNB_DU_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3]  = CELLINFO[ptCi->servCellNum].cellIdentity;    // CellIdentity
            pPmKey->keyList[VCCB_PMKEY_INDEX4]  = reserved2;                                   // SPIDIncludingInvalid
            break;

        case STAT_MEAS_REPORT_DU_ID:
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->endPointInfo.gnbDuId, MAX_GNB_DU_ID + 1);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;    // gNB_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = GetDuId(ptCi->endPointInfo.gnbDuId);           // gNB_DU_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;      // CellIdentity
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = reserved2;
            break;

        case STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE:
        case STAT_MEAS_REPORT_NRDC_SN_SERVICE_TYPE:
        case STAT_MEAS_REPORT_EUTRA_SERVICE_TYPE:
        {
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->endPointInfo.gnbDuId, MAX_GNB_DU_ID + 1);

            VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];
            uint32_t plmnValue = 0;
            VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &plmnValue);

            pPmKey->keyList[VCCB_PMKEY_INDEX1] = plmnValue;                                 // PLMN
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;                // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX3],
                CELLINFO[ptCi->servCellNum].cellIdentity, ptCi->gnbNum);                    // gNB_DU_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = CELLINFO[ptCi->servCellNum].cellIdentity;  // CellIdentity
            pPmKey->keyList[VCCB_PMKEY_INDEX5] = reserved3;                                 // ServiceType_SA
            pPmKey->keyList[VCCB_PMKEY_INDEX6] = reserved2;                                 // TgtNrArfcn / TgtEarfcnDl
            break;
        }
        case STAT_MEAS_REPORT_ENDC:
        {
            VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->endPointInfo.gnbDuId, MAX_GNB_DU_ID + 1);

            VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];
            uint32_t plmnValue = 0;
            VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &plmnValue);

            pPmKey->keyList[VCCB_PMKEY_INDEX1] = plmnValue;                                 // PLMN
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;                // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX3],
                CELLINFO[ptCi->servCellNum].cellIdentity, ptCi->gnbNum);                    // gNB_DU_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = CELLINFO[ptCi->servCellNum].cellIdentity;  // CellIdentity
            pPmKey->keyList[VCCB_PMKEY_INDEX5] = reserved2;                                 // TgtNrArfcn
            pPmKey->keyList[VCCB_PMKEY_INDEX6] = reserved3;                                 // SPIDIncludingInvalid
            break;
        }
        case STAT_UE_CAPA_SIZE_DIST_DU_ID:
            if(ptCi->callType == E_CALLTYPE_NSA)
            {
                if (IntraRatHO_cmd == ptCi->stateCmd)
                {
                    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->hoInfo.targetDu.f1Idx, MAX_GNB_DU_PER_GNB_CU_CP);
                    pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;                                        // gNB ID
                    FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2],
                        ptCi->hoInfo.cellIdentity, MAX_GNB_PER_SYS); // DU_ID
                    pPmKey->keyList[VCCB_PMKEY_INDEX3] = ptCi->hoInfo.cellIdentity;                                                         // CellIdentity
                }
                else
                {
                    VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
                    pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB ID
                    FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2],
                        CELLINFO[ptCi->servCellNum].cellIdentity, ptCi->gnbNum); // gNB_DU_ID
                    pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;    // CellIdentity
                }
            }
            else
            {
                VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
                pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;
                pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;
                FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2],
                    (uint16_t)pPmKey->keyList[VCCB_PMKEY_INDEX3], MAX_GNB_PER_SYS); // DU_ID
            }
            break;

        case STAT_MULTI_RAT_SELECTION:
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->endPointInfo.gnbDuId, MAX_GNB_DU_ID + 1);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = GetDuId(ptCi->endPointInfo.gnbDuId);         // gNB_DU_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;    // CellIdentity
            break;

        case STAT_NRDC_SCG_BAND_SELECTION:
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->endPointInfo.gnbDuId, MAX_GNB_DU_ID + 1);
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;  // gNB_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = GetDuId(ptCi->endPointInfo.gnbDuId);         // gNB_DU_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;    // CellIdentity
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = reserved2;                                   // Target Arfcn
            pPmKey->keyList[VCCB_PMKEY_INDEX5] = reserved3;                                   // Target NCI
            VCCB_FLAG_ON_FOR_DBG_LOG_NRDC_BASIC(*pShmStoreFlag);
            break;

        case STAT_NCGI_REPORT: // INTRA_NR_ANR_24A FR760
        {
            FnVccb_FillPlmnGnbIdDuIdCellIdStatIndex(ptCi, pPmKey, false); // Index (1 ~ 4) : PLMN, gNB ID, gNB_DU_ID, cell Identity
            pPmKey->keyList[VCCB_PMKEY_INDEX5] =  // SourceCellType : Pcell(0), Pscell(1)
                ((ptCi->callType == E_CALLTYPE_NSA) || (IS_NRDC_SN(ptCi))) ? NCGI_REPORT_SRC_CELL_PSCELL : NCGI_REPORT_SRC_CELL_PCELL;
            if (IS_MRDC_MN(ptCi)) pPmKey->keyList[VCCB_PMKEY_INDEX5] = NCGI_REPORT_SRC_CELL_PCELL_MN; // SourceCellType : NR-DC/NE-DC MN(2) 26A FR761
            pPmKey->keyList[VCCB_PMKEY_INDEX6] =  // UEResourceType : GBR(0), NonGBR(1)
                (ptCi->anrInfo.anrGbrUe ? CGI_REPORT_UE_RESOURCE_GBR : CGI_REPORT_UE_RESOURCE_NGBR);
            // TargetFrequencyType: fr1-with-mgap(0),fr1-without-mgap(1),fr2-with-mgap(2),fr2-without-mgap(3)
            pPmKey->keyList[VCCB_PMKEY_INDEX7] = GET_REPORT_CGI_TGT_FREQ_TYPE(ptCi); // enumNcgiReportTgtFreq_type
            pPmKey->usageOfNumKey = CI_use;
            pPmKey->numKey = VCCB_PMKEY_INDEX7 + 1; // MAX_VCCB_STAT_KEY_NUM (7)
            break;
        }

        case STAT_ECGI_REPORT_ANR: // FGS-SF0503 FR530
        {
            FnVccb_FillPlmnGnbIdDuIdCellIdStatIndex(ptCi, pPmKey, false); // Index (1 ~ 4) : PLMN, gNB ID, gNB_DU_ID, cell Identity
            pPmKey->keyList[VCCB_PMKEY_INDEX5] = (IS_MRDC(ptCi) ? TRUE : FALSE); // MrdcStatus MRDC_not_configured(0),MRDC_configured(1)
            pPmKey->keyList[VCCB_PMKEY_INDEX6] =  // UEResourceType : GBR(0), NonGBR(1)
                (ptCi->anrInfo.anrGbrUe ? CGI_REPORT_UE_RESOURCE_GBR : CGI_REPORT_UE_RESOURCE_NGBR);
            // EUTRAMeasurementType : withoutGap(0),withGap(1)
            pPmKey->keyList[VCCB_PMKEY_INDEX7] = GET_REPORT_CGI_TGT_FREQ_TYPE(ptCi); // 26A // EUTRAMeasurementType
            pPmKey->usageOfNumKey = CI_use;
            pPmKey->numKey = VCCB_PMKEY_INDEX7 + 1; // MAX_VCCB_STAT_KEY_NUM (7)
            break;
        }

        case STAT_SGNB_ADD_PER_GNB_SPID_DU_ID:
        {
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id; // gNB_ID
            if (ptCi->servCellNum < MAX_CELL_NUM_VCCB)                                       // CellIdentityWithInvalid
            {
                FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2],
                    CELLINFO[ptCi->servCellNum].cellIdentity, ptCi->gnbNum);                 // gNB_DU_ID
                pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;
            }
            else
            {
                FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2],
                    MAX_CELL_IDENTITY, ptCi->gnbNum);              // gNB_DU_ID
                pPmKey->keyList[VCCB_PMKEY_INDEX3] = 0xFFFF;
            }
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = reserved2;                                  // SPIDIncludingInvalid
            break;
        }

        case STAT_MENB_INIT_SGNB_REL_PER_GNB_SPID_DU_ID:
        {
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;       // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2],
                CELLINFO[ptCi->servCellNum].cellIdentity, ptCi->gnbNum); // gNB_DU_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;         // CellIdentity
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = reserved2;                                        // SPIDIncludingInvalid
            break;
        }

        case STAT_SGNB_INIT_SGNB_REL_PER_GNB_SPID_DU_ID:
        {
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id;        // gNB_ID
            FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2],
                CELLINFO[ptCi->servCellNum].cellIdentity, ptCi->gnbNum);  // gNB_DU_ID
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = CELLINFO[ptCi->servCellNum].cellIdentity;          // CellIdentity
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = reserved2;                                         // SPIDIncludingInvalid
            break;
        }

        case STAT_HO_IN_SERVICE_TYPE:
        case STAT_HO_EUTRAN_IN_SERVICE_TYPE:
        {
            // PLMN / gNB_ID / gNB_DU_ID / CellIdentity / ServiceType_SA (1 ~ 5)
            FnVccb_FillPlmnGnbIdDuIdCellIdStatIndex(ptCi, pPmKey, true); // Index (1 ~ 4)
            // pPmKey->keyList[VCCB_PMKEY_INDEX5] = service type;   // ServiceType_SA later
            break;
        }

        case STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE:
        {
            // PLMN / gNB_ID / gNB_DU_ID / CellIdentity / ServiceType_SA / TgtEarfcnDl (1 ~ 6)
            FnVccb_FillPlmnGnbIdDuIdCellIdStatIndex(ptCi, pPmKey, false); // Index (1 ~ 4)
            // pPmKey->keyList[VCCB_PMKEY_INDEX5] = service type;   // ServiceType_SA later
            pPmKey->keyList[VCCB_PMKEY_INDEX6] = ptCi->hoInfo.tArfcn;   // TgtEarfcnDl
            break;
        }

        case STAT_HO_OUT_SERVICE_TYPE:
        {
            // PLMN / gNB_ID / gNB_DU_ID / CellIdentity / ServiceType_SA / TargetNCI (1 ~ 6)
            FnVccb_FillPlmnGnbIdDuIdCellIdStatIndex(ptCi, pPmKey, false); // Index (1 ~ 4)
            // pPmKey->keyList[VCCB_PMKEY_INDEX5] = service type;   // ServiceType_SA later
            pPmKey->keyList[VCCB_PMKEY_INDEX6] = ptCi->hoInfo.cgi.ci; // TargetNCI
            break;
        }

        case STAT_HO_EUTRAN_OUT_SERVICE_TYPE:
        case STAT_HO_EUTRAN_OUT_FALLBACK_SERVICE_TYPE:
        {
            // PLMN / gNB_ID / gNB_DU_ID / CellIdentity / ServiceType_SA / TgtEUTRANCellIdentity (1 ~ 6)
            FnVccb_FillPlmnGnbIdDuIdCellIdStatIndex(ptCi, pPmKey, false); // Index (1 ~ 4)
            // pPmKey->keyList[VCCB_PMKEY_INDEX5] = service type;   // ServiceType_SA later
            pPmKey->keyList[VCCB_PMKEY_INDEX6] = ptCi->hoInfo.cgi.ci; // TgtEUTRANCellIdentity
            break;
        }

        case STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE:
        {
            // PLMN / gNB_ID / gNB_DU_ID / CellIdentity / ServiceType_SA / TgtNrArfcn (1 ~ 6)
            FnVccb_FillPlmnGnbIdDuIdCellIdStatIndex(ptCi, pPmKey, false); // Index (1 ~ 4)
            // pPmKey->keyList[VCCB_PMKEY_INDEX5] = service type;   // ServiceType_SA later
            pPmKey->keyList[VCCB_PMKEY_INDEX6] = ptCi->hoInfo.tgtSsbFreq; // TgtNrArfcn
            break;
        }

        case STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE:
        {
            // PLMN / gNB_ID / gNB_DU_ID / CellIdentity / ServiceType_SA (1 ~ 5)
            FnVccb_FillPlmnGnbIdDuIdCellIdStatIndex(ptCi, pPmKey, false); // Index (1 ~ 4)
            // pPmKey->keyList[VCCB_PMKEY_INDEX5] = service type;   // ServiceType_SA later
            break;
        }

        case STAT_REDIR_EUTRAN_OUT_SERVICE_TYPE:
        case STAT_REDIR_NR_OUT_SERVICE_TYPE:
        {
            // PLMN / gNB_ID / gNB_DU_ID / CellIdentity / ServiceType_SA / TgtEarfcnDl (1 ~ 6)
            // PLMN / gNB_ID / gNB_DU_ID / CellIdentity / ServiceType_SA / TgtNrArfcn (1 ~ 6)
            FnVccb_FillPlmnGnbIdDuIdCellIdStatIndex(ptCi, pPmKey, false);  // Index (1 ~ 4)
            // pPmKey->keyList[VCCB_PMKEY_INDEX5] = service type;   // ServiceType_SA later
            if (not FnVCCB_FillRedirectionFrequencyIndex(pPmKey, ptCi, VCCB_PMKEY_INDEX6, mFamily))
            {
                return ERROR;
            }
            break;
        }
        case STAT_BAND_SELECTION:
        {
            const uint32_t gnbPLMN = static_cast<uint32_t>(reserved2);
            const uint32_t gnbId = static_cast<uint32_t>(reserved3);
            const uint16_t cellIdentity = static_cast<uint16_t>(reserved4);

            pPmKey->keyList[VCCB_PMKEY_INDEX1] = gnbPLMN;
            pPmKey->keyList[VCCB_PMKEY_INDEX2] = gnbId;
            if (gnbId == GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id) // intra gNB cell
            {
                FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX3],
                    cellIdentity, ptCi->gnbNum);
            }
            else // inter gNB cell, set MAX_GNB_DU_ID
            {
                pPmKey->keyList[VCCB_PMKEY_INDEX3] = MAX_GNB_DU_ID;
            }
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = cellIdentity;
            break;
        }

        default:
            VCCB_PRINT_ERROR("Family type not supported by pmCC (mFamily:%d)!\n", mFamily);
            return ERROR;
    }

    return GOOD;
}

/**
 * @brief     Collect stat with PmCC with given value
 * @param     mFamily : stat family
 * @param     mType : stat type
 */

// Do not call the function directly, use the macro below!!
//#define MACRO_STAT_PMCC_VALUE(_mFam,_mType,_ptCi,a,b,c,d,e, _val)
void VLIB_LibStatPmCC_Value(int mFamily, int mType, callInfo_type *ptCi, uint64_t reserved2, uint64_t reserved3,
    int reserved4, int reserved5, int reserved6, unsigned int updateValue)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    int status = GOOD, shmStoreFlag = TRUE;

    VccbPmKey_type pmKey;
    memset(&pmKey, 0, sizeof(VccbPmKey_type));
    VccbPmMultiCollect_type pmMultiCollect;

    FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_CC);

    // Fill Statistic Index (pmKey -> index1, index2, ...)
    status = VLIB_FillStatisticsIndex(
        ptCi, mFamily, mType, &pmKey, &shmStoreFlag, reserved2, reserved3, reserved4, reserved5, reserved6);
    VCCB_RETURN_ON_CALL_VOID(ptCi, status, "VLIB_FillStatisticsIndex ERROR! %d/%d/%llu/%llu/%llu/%llu/%llu/%llu\n",
        mFamily, mType, pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2],
        pmKey.keyList[VCCB_PMKEY_INDEX3], pmKey.keyList[VCCB_PMKEY_INDEX4], pmKey.keyList[VCCB_PMKEY_INDEX5],
        pmKey.keyList[VCCB_PMKEY_INDEX6]);

    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    uint16_t gnbNum = ptCi->gnbNum;
    StatisticsHandler statHandler(gnbNum);
    statHandler.changeFamilyAndIndex(ptCi, mFamily, pmKey);

    MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mFamily, mType,
        pmMultiCollect.updateMethod, updateValue);

    CollectPmStatistics(ptCi, (unsigned)mFamily, (unsigned)mFamily, &pmMultiCollect, pmMultiCollect.updateItemUintArr, pmKey, shmStoreFlag);
}

/**
 * @brief Returns true if conditions to collect given family are met.
 *        Used not to call a checker function before every MACRO_STAT_PMCC.
 *
 * @param call info
 * @param family id
 * @return true
 * @return false
 */
bool VCCB_LibStatPmCC_NeedToCollectFamily(const callInfo_type &call, int family)
{
    AUTO_TRACE_FUNC;

    bool result = true;

    switch (family)
    {
    case STAT_INTRA_FREQ_PSCELL_CHANGE_SCGMOB_PER_GNB_DU_ID:
        result = VLIB_NeedToPegIntraFreqPscellChangeScgMob(call);
        break;
    default:
        break;
    }

    return result;
}

/**
 * @brief This API is designed to obtain the service type values for partial success DRBs in the HO target
 *        at the Handover execution stage when performing handover.
 *        I hope you don't use it for other purposes.
 *
 * @param call info
 * @param std::set
 * @return GOOD
 * @return ERROR
 */
int16_t FnVCCB_GetHandInDrbsServiceType(callInfo_type *ptCi, std::set<uint32_t> &serviceTypeListResultSet)
{
    int16_t status = GOOD;
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    callDRBInfo_type *ptDi;

    if (CFG->acpfInfo.serviceTypeList[0].usage == CI_use)
        serviceTypeListResultSet.insert(0);

    for (uint32_t drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        ptDi = &ptCi->drb[drbIdx];

        if (ptDi->usage != CI_use) continue;

        if (IS_NRDC_SN(ptCi))
        {
            if (ptDi->bearerType.termPoint == TermPoint_Mn) continue;
        }
        else
        {
            if (ptDi->bearerType.termPoint == TermPoint_Sn) continue;
        }

        // Partially failed DRB while Inter-gNB HO
        if (ptDi->drbStatus == S_FailToSetup)
        {
            VCCB_PRINT_CALL_HO_SERVICE_TYPE(ptCi, "%s excluding dRBId:%u S_FailToSetup \n", __func__, ptDi->dRBId);
            continue;
        }

        // Partially failed DRB while Intra-gNB HO
        if (GET_NEED_RELEASE_FAIL_DRB_FROM_AMF(ptDi))
        {
            VCCB_PRINT_CALL_HO_SERVICE_TYPE(ptCi, "%s excluding dRBId:%u needToReleaseAmfByF1Partial \n", __func__, ptDi->dRBId);
            continue;
        }

        // Inter-gNB UP
        // if (ptDi->drbStatus == S_FailToSetup) continue;

        // Inter-gNB DU
        // if (ptDi->drbStatus == S_FailToSetup && ptDi->needToReconfigE1ByF1Fail == TRUE) continue;

        // Inter-DU
        // if (ptDi->drbStatus == S_Modify && ptDi->needToReconfigE1ByF1Fail == TRUE &&
        // ptDi->needToReleaseAmfByF1Partial_intraGnbOnlyUsed) continue;

        // Intra-DU
        // if (ptDi->drbStatus == S_Modify && ptDi->needToReleaseAmfByF1Partial_intraGnbOnlyUsed) continue;

        VCCB_PRINT_CALL_HO_SERVICE_TYPE(ptCi, "%s dRBId:%u for service type\n", __func__, ptDi->dRBId);

        status = FnVCCB_GetDrbServiceType(ptCi, ptDi, serviceTypeListResultSet);
    }

    return status;
}

/**
 * @brief This API is designed to obtain the service type values for all DRBs in the HO target
 *        at the Handover preparation stage when performing handover.
 *        I hope you don't use it for other purposes.
 *
 * @param call info
 * @param std::set
 * @return GOOD
 * @return ERROR
 */
int16_t FnVCCB_GetHandInAllDrbsServiceType(callInfo_type *ptCi, std::set<uint32_t> &serviceTypeListResultSet)
{
    int16_t status = GOOD;
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    callDRBInfo_type *ptDi;

    if (CFG->acpfInfo.serviceTypeList[0].usage == CI_use) serviceTypeListResultSet.insert(0);

    for (uint32_t drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        ptDi = &ptCi->drb[drbIdx];

        if (ptDi->usage != CI_use) continue;

        if (IS_NRDC_SN(ptCi))
        {
            if (ptDi->bearerType.termPoint == TermPoint_Mn) continue;
        }
        else
        {
            if (ptDi->bearerType.termPoint == TermPoint_Sn) continue;
        }

        VCCB_PRINT_CALL_HO_SERVICE_TYPE(
            ptCi, "%s dRBId:%u status:%s \n", __func__, ptDi->dRBId, FnLIB_GetSaBearerStatusToString(ptDi->drbStatus));

        status = FnVCCB_GetDrbServiceType(ptCi, ptDi, serviceTypeListResultSet);
    }

    return status;
}

int16_t FnVCCB_GetHandoverCallServiceType(
    callInfo_type *ptCi, int mFamily, std::set<uint32_t> &serviceTypeListResultSet)
{
    int16_t status = GOOD;
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    auto isHandInServiceTypeFamily = [mFamily]() -> bool
    {
        switch (mFamily)
        {
            case STAT_HO_IN_SERVICE_TYPE:
            case STAT_HO_EUTRAN_IN_SERVICE_TYPE:
                return true;

            default:
                return false;
        }
    };

    if (isHandInServiceTypeFamily())
    {
        // Preparation Phase
        if (ptCi->hoInfo.handoverExecutionFlag == FALSE)
        {
            VCCB_PRINT_CALL_HO_SERVICE_TYPE(
                ptCi, "[HANDIN] FnVCCB_GetHandInAllDrbsServiceType %s \n", FnVCCB_GetServiceTypeFamily(mFamily));
            status = FnVCCB_GetHandInAllDrbsServiceType(ptCi, serviceTypeListResultSet);
            return status;
        }
        else
        {
            VCCB_PRINT_CALL_HO_SERVICE_TYPE(
                ptCi, "[HANDIN] FnVCCB_GetHandInDrbsServiceType %s \n", FnVCCB_GetServiceTypeFamily(mFamily));
            status = FnVCCB_GetHandInDrbsServiceType(ptCi, serviceTypeListResultSet);
        }
    }
    else
    {
        // except for S_Setup or S_FailToSetup in drbStatus
        VCCB_PRINT_CALL_HO_SERVICE_TYPE(
            ptCi, "[HANDOUT] FnVCCB_GetCallServiceType %s \n", FnVCCB_GetServiceTypeFamily(mFamily));

        status = FnVCCB_GetCallServiceType(ptCi, serviceTypeListResultSet);
    }
    return status;
}

bool FnVCCB_IsServiceTypeStatFamily(int family)
{
    switch (family)
    {
        case STAT_HO_EUTRAN_OUT_SERVICE_TYPE:  // SVR25B FGR-MC3002 FR108
        case STAT_HO_EUTRAN_OUT_FALLBACK_SERVICE_TYPE:  // SVR25B FGR-MC3002 FR109
        case STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE:
        case STAT_HO_EUTRAN_IN_SERVICE_TYPE:  // SVR25B FGR-MC3002 FR133
        case STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE:
        case STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE:
        case STAT_HO_OUT_SERVICE_TYPE:  // SVR25B FGR-MC1009 FR531
        case STAT_HO_IN_SERVICE_TYPE:  // SVR25B FGR-MC1009 FR541
        case STAT_REDIR_EUTRAN_OUT_SERVICE_TYPE:  // SVR25B FGR-MC3001 FR231
        case STAT_REDIR_NR_OUT_SERVICE_TYPE:
            return true;
        default:
            return false;
    }
}

const char *FnVCCB_GetServiceTypeFamily(int family)
{
    switch (family)
    {
        case STAT_HO_EUTRAN_OUT_SERVICE_TYPE:  // SVR25B FGR-MC3002 FR108
            return "STAT_HO_EUTRAN_OUT_SERVICE_TYPE";
        case STAT_HO_EUTRAN_OUT_FALLBACK_SERVICE_TYPE:  // SVR25B FGR-MC3002 FR109
            return "STAT_HO_EUTRAN_OUT_FALLBACK_SERVICE_TYPE";
        case STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE:
            return "STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE";
        case STAT_HO_EUTRAN_IN_SERVICE_TYPE:  // SVR25B FGR-MC3002 FR133
            return "STAT_HO_EUTRAN_IN_SERVICE_TYPE";
        case STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE:
            return "STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE";
        case STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE:
            return "STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE";
        case STAT_HO_OUT_SERVICE_TYPE:  // SVR25B FGR-MC1009 FR531
            return "STAT_HO_OUT_SERVICE_TYPE";
        case STAT_HO_IN_SERVICE_TYPE:  // SVR25B FGR-MC1009 FR541
            return "STAT_HO_IN_SERVICE_TYPE";
        case STAT_REDIR_EUTRAN_OUT_SERVICE_TYPE:  // SVR25B FGR-MC3001 FR231
            return "STAT_REDIR_EUTRAN_OUT_SERVICE_TYPE";
        case STAT_REDIR_NR_OUT_SERVICE_TYPE:
            return "STAT_REDIR_NR_OUT_SERVICE_TYPE";
        default:
            return "Unknown";
    }
}

bool FnVCCB_IsSupportServiceTypeYang(int family, VccbGnbInfo_type *pGnb)
{
    VALID_E_POINT_CHECK_RET_VAL(pGnb, false);

    if (CFG->acpfInfo.serviceTypeOnOff != TRUE) return false;

    uint32_t yangOnOff{0};
    switch (family)
    {
        case STAT_HO_EUTRAN_OUT_SERVICE_TYPE:
            yangOnOff = pGnb->cfg.serviceTypeCounterConfig.hoEutranOutServiceType;
            break;
        case STAT_HO_EUTRAN_OUT_FALLBACK_SERVICE_TYPE:
            yangOnOff = pGnb->cfg.serviceTypeCounterConfig.hoEutranOutFallbackServiceType;
            break;
        case STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE:
            yangOnOff = pGnb->cfg.serviceTypeCounterConfig.hoEutranFreqOutServicetype;
            break;
        case STAT_HO_EUTRAN_IN_SERVICE_TYPE:
            yangOnOff = pGnb->cfg.serviceTypeCounterConfig.hoEutranInServicetype;
            break;
        case STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE:
            yangOnOff = pGnb->cfg.serviceTypeCounterConfig.handoverInterFreqOutServicetypeOnoff;
            break;
        case STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE:
            yangOnOff = pGnb->cfg.serviceTypeCounterConfig.handoverIntraFreqOutServicetypeOnoff;
            break;
        case STAT_HO_OUT_SERVICE_TYPE:
            yangOnOff = pGnb->cfg.serviceTypeCounterConfig.handoverOutServicetypeOnoff;
            break;
        case STAT_HO_IN_SERVICE_TYPE:
            yangOnOff = pGnb->cfg.serviceTypeCounterConfig.handoverInServicetypeOnoff;
            break;
        case STAT_REDIR_EUTRAN_OUT_SERVICE_TYPE:
            yangOnOff = pGnb->cfg.serviceTypeCounterConfig.redirEutranOutServiceTypeOnOff;
            break;
        case STAT_REDIR_NR_OUT_SERVICE_TYPE:
            yangOnOff = pGnb->cfg.serviceTypeCounterConfig.redirNrOutServiceTypeOnOff;
            break;
        default:
            break;
    }
    return (yangOnOff == 0 ? false : true);
}

void FnVCCB_CollectMobilityServiceTypeFamily(
    callInfo_type *ptCi, int mFamily, VccbPmKey_type rPmKey, VccbPmMultiCollect_type *pPmMultiCollect)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pPmMultiCollect);

    int16_t status = GOOD;
    uint16_t gnbNum = ptCi->gnbNum;
    VCCB_CHECK_VALID_GNBNUM_VOID(gnbNum);

    VccbGnbInfo_type *pGnb = &GNBINFO[gnbNum];

    // service-type-sa/service-type-onoff
    if (CFG->acpfInfo.serviceTypeOnOff != TRUE) return;

    if (not FnVCCB_IsSupportServiceTypeYang(mFamily, pGnb)) return;

    std::set<uint32_t> serviceTypelist;

    status = FnVCCB_GetHandoverCallServiceType(ptCi, mFamily, serviceTypelist);
    if (status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "%s FnVCCB_GetHandoverCallServiceType ERROR(%d)\n", __func__, status);
        serviceTypelist.clear();
    }

    // No Service type
    if (serviceTypelist.empty()) return;

    for (const auto &serviceType : serviceTypelist)
    {
        rPmKey.keyList[VCCB_PMKEY_INDEX5] = serviceType;  // ServiceType_SA (5)
        VCCB_PRINT_CALL_HO_SERVICE_TYPE(
            ptCi, "[ServiceType] mFamily:%s serviceType:%u \n", FnVCCB_GetServiceTypeFamily(mFamily), serviceType);
        CollectPmStatistics(ptCi, (unsigned)mFamily, (unsigned)mFamily, pPmMultiCollect,
            pPmMultiCollect->updateItemUintArr, rPmKey, TRUE);
    }
}

/**
 * @brief     Collect stat with PmCC with value 1
 * @param     mFamily : stat family
 * @param     mType : stat type
 */

// Do not call the function directly, use the macro below!!
//#define MACRO_STAT_PMCC(_mFam,_mType,_ptCi,a,b,c,d,e)
void VLIB_LibStatPmCC(int mFamily, int mType, callInfo_type *ptCi, uint64_t reserved2, uint64_t reserved3,
    int reserved4, int reserved5, int reserved6, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);

    // One place to check if family needs to be collected. Not to call checker every time MACRO_STAT_PMCC is used.
    if (not VCCB_LibStatPmCC_NeedToCollectFamily(*ptCi, mFamily))
    {
        return;
    }

    // Variable
    int status = GOOD, shmStoreFlag = TRUE, rankType = -1;
    int typeId_attempt = GetAttTypeId(ptCi, mFamily, mType);

    VccbPmKey_type pmKey;
    memset(&pmKey, 0, sizeof(VccbPmKey_type));
    VccbPmMultiCollect_type pmMultiCollect;

    int retVal;

    FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_CC);

    // This function is used to determine the normality of statistics, and in the case of Attempt statistics, set FLAG
    // for this.
    if (STAT_TYPE_ATTEMPT == FnVCCB_GetStatType(mFamily, typeId_attempt))
    {
        int famIdx = GET_FAMIDX(mFamily);
        IS_VALID_FAMIDX_TYPE_NVOID(famIdx, mType);

        retVal = CheckAttemptStatValidity(ptCi, &ptCi->stat.flag[famIdx], mFamily, mType);
        if (retVal != STAT_VALID)
        {
            VCCB_PRINT_COMMENT(
                    "CheckAttemptStatValidity Error with cause: %d (mFamily:%d, mType:%d)!\n", retVal, mFamily, mType);
            return;
        }
    }

    int mActualFamily = mFamily;

    // Fill Statistic Index (pmKey -> index1, index2, ...)
    status = VLIB_FillStatisticsIndex(
        ptCi, mFamily, mType, &pmKey, &shmStoreFlag, reserved2, reserved3, reserved4, reserved5, reserved6);
    VCCB_RETURN_ON_CALL_VOID(ptCi, status, "VLIB_FillStatisticsIndex ERROR! %d/%d/%llu/%llu/%llu/%llu/%llu/%llu\n",
        mActualFamily, mType, pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2],
        pmKey.keyList[VCCB_PMKEY_INDEX3], pmKey.keyList[VCCB_PMKEY_INDEX4],
        pmKey.keyList[VCCB_PMKEY_INDEX5], pmKey.keyList[VCCB_PMKEY_INDEX6]);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    uint16_t gnbNum = ptCi->gnbNum;

    VccbPmKey_type orgPmKey = pmKey;

    if (IS_VIRTUAL_FAMILY(mFamily))
    {
        CONVERT_FAMILY_VIRTUAL2ACTUAL(mFamily, mActualFamily);
    }
    else
    {
        StatisticsHandler statHandler(gnbNum);
        statHandler.changeFamilyAndIndex(ptCi, mActualFamily, pmKey);
        statHandler.changeCounterTypeIdForDerivedFamilies(mType, mActualFamily);
    }

    VLIB_CollectAdditionalStatistic(
        mFamily, mActualFamily, mType, ptCi, (unsigned int)reserved2, (unsigned)reserved3, reserved4, reserved5, reserved6);

    // If there are any failure statistics that need to be saved, save them in this function.
    VLIB_StoreFailCauseHist(mFamily, mActualFamily, mType, ptCi, &pmKey, fnName);

    // Distinguish between statistics that need attempt and statistics that don't.
    if (STAT_TYPE_ATTEMPT == FnVCCB_GetStatType(mFamily, typeId_attempt))
    {
        int famIdx = GET_FAMIDX(mFamily);
        IS_VALID_FAMIDX_TYPE_NVOID(famIdx, mType);

        status = VLIB_AttemptBasedPmCCStatCollector(
            ptCi, &ptCi->stat.flag[famIdx], mFamily, mActualFamily, mType, &pmMultiCollect, &pmKey);
        VCCB_RETURN_ON_CALL_VOID(ptCi, status,
            "VLIB_AttemptBasedPmCCStatCollector ERROR! %d/%d/%llu/%llu/%llu/%llu/%llu/%llu\n", mActualFamily, mType,
            pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2], pmKey.keyList[VCCB_PMKEY_INDEX3],
            pmKey.keyList[VCCB_PMKEY_INDEX4], pmKey.keyList[VCCB_PMKEY_INDEX5], pmKey.keyList[VCCB_PMKEY_INDEX6]);
        if (status == BREAK)  // If Attempt, PrepSuccess is called, it is not collected at this time.
        {
            return;
        }

        // reset flag
        SET_CALL_STAT_FLAG(ptCi, famIdx, NO_ATTEMPT);
    }

    if (FOO.VF_BasicOperationforENDC_RetrieveRealTimeCallCount)
    {
        if (mFamily == STAT_SGNB_ADD_PER_GNB && mType > EndcAddSucc)
        {
            status = VRRM_addVccbENDCcallCount(gnbNum, false);
            if (status == ERROR)
            {
                VCCB_PRINT_ERROR("VRRM_addVccbENDCcallCount status == ERROR for gnbNum(%d) \n", gnbNum);
            }
        }
        if (mFamily == STAT_SGNB_ADD_PER_GNB && mType == EndcAddSucc)
        {
            status = VRRM_addVccbENDCcallCount(gnbNum, true);
            if (status == ERROR)
            {
                VCCB_PRINT_ERROR(
                    "VRRM_addVccbENDCcallCount Attempt + Success status == ERROR for gnbNum(%d) \n", gnbNum);
            }
        }
    }

    MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily, mType,
        pmMultiCollect.updateMethod, 1);

    if((mFamily == STAT_RRC_ESTAB) && (FOO.VF_CallSummaryLogs_KPI))
    {
        FnVCCB_CollectStatCSL_RrcSetup(ptCi, mFamily, mType);
    }

    if((mFamily == STAT_RRC_REESTAB) && (FOO.VF_CallSummaryLogs_KPI))
    {
        FnVCCB_CollectStatCSL_RrcReestab(ptCi, mFamily, mType);
    }

    // Check Additional Statistic for Ranking.
    rankType = GetRankTypeId(mFamily, mType);
    if (rankType != -1)
    {
        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily, rankType,
            pmMultiCollect.updateMethod, 1);
    }

    // FGR-CC5000 Basic Operation for EN-DC
    FnVCCB_CollectPmccAdditionalEndcAddDetailedCpFail(ptCi, &pmMultiCollect, mFamily, mActualFamily, mType);
    FnVCCB_CollectPmccSpCellSelectionFailure(ptCi, &pmMultiCollect, mFamily, mActualFamily, mType);

    // FGR-CC5200:FR640
    FnVCCB_CollectPmccAdditionalNrdcStats(ptCi, &pmMultiCollect, mActualFamily, mType);

    // FGR-LC0750: FR20: Evt_PscellChange
    FnVCCB_CollectPmccPScellChangeLocalStats(ptCi, mFamily);

    CollectPmStatistics(
        ptCi, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemUintArr, pmKey, shmStoreFlag);

    if (MACRO_IS_SERVICE_TYPE_STAT_ON() && mFamily == STAT_RRC_REESTAB)
    {
        FnVCCB_CollectNrRrcReestablishServiceType(ptCi, mFamily, &pmMultiCollect, orgPmKey);
    }
}

// Dedicated STAT API for the handover and redirection instead of VLIB_LibStatPmCC
void FnVCCB_LibStatPmCC_Mobility(int mFamily, int mType, callInfo_type *ptCi, uint64_t reserved2, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    // Variable
    int status = GOOD, shmStoreFlag = TRUE, rankType = -1;
    int mActualFamily = mFamily;
    int typeId_attempt = GetAttTypeId(ptCi, mFamily, mType);
    uint16_t gnbNum = ptCi->gnbNum;

    VccbPmKey_type pmKey;
    VccbPmMultiCollect_type pmMultiCollect;

    // init
    memset(&pmKey, 0, sizeof(VccbPmKey_type));
    FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_CC);

    // This function is used to determine the normality of statistics, and in the case of Attempt statistics, set FLAG
    // for this.
    if (STAT_TYPE_ATTEMPT == FnVCCB_GetStatType(mFamily, typeId_attempt))
    {
        int famIdx = GET_FAMIDX(mFamily);
        IS_VALID_FAMIDX_TYPE_NVOID(famIdx, mType);

        status = CheckAttemptStatValidity(ptCi, &ptCi->stat.flag[famIdx], mFamily, mType);
        if (status != STAT_VALID)
        {
            VCCB_PRINT_COMMENT(
                    "CheckAttemptStatValidity Error with cause: %d (mFamily:%d, mType:%d)!\n", status, mFamily, mType);
            return;
        }
    }

    // Fill Statistic Index (pmKey -> index1, index2, ...)
    status = VLIB_FillStatisticsIndex(ptCi, mFamily, mType, &pmKey, &shmStoreFlag, reserved2, 0, 0, 0, 0);
    VCCB_RETURN_ON_CALL_VOID(ptCi, status, "VLIB_FillStatisticsIndex ERROR! %d/%d/%llu/%llu/%llu/%llu/%llu/%llu\n",
        mActualFamily, mType, pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2],
        pmKey.keyList[VCCB_PMKEY_INDEX3], pmKey.keyList[VCCB_PMKEY_INDEX4],
        pmKey.keyList[VCCB_PMKEY_INDEX5], pmKey.keyList[VCCB_PMKEY_INDEX6]);

    StatisticsHandler statHandler(gnbNum);
    statHandler.changeFamilyAndIndex(ptCi, mActualFamily, pmKey);

    // If there are any failure statistics that need to be saved, save them in this function.
    VLIB_StoreFailCauseHist(mFamily, mActualFamily, mType, ptCi, &pmKey, fnName);

    // Distinguish between statistics that need attempt and statistics that don't.
    if (STAT_TYPE_ATTEMPT == FnVCCB_GetStatType(mFamily, typeId_attempt))
    {
        int famIdx = GET_FAMIDX(mFamily);
        IS_VALID_FAMIDX_TYPE_NVOID(famIdx, mType);

        status = VLIB_AttemptBasedPmCCStatCollector(
            ptCi, &ptCi->stat.flag[famIdx], mFamily, mActualFamily, mType, &pmMultiCollect, &pmKey);
        VCCB_RETURN_ON_CALL_VOID(ptCi, status,
            "VLIB_AttemptBasedPmCCStatCollector ERROR! %d/%d/%llu/%llu/%llu/%llu/%llu/%llu\n", mActualFamily, mType,
            pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2], pmKey.keyList[VCCB_PMKEY_INDEX3],
            pmKey.keyList[VCCB_PMKEY_INDEX4], pmKey.keyList[VCCB_PMKEY_INDEX5], pmKey.keyList[VCCB_PMKEY_INDEX6]);

        if (status == BREAK)  // If Attempt, PrepSuccess is called, it is not collected at this time.
        {
            return;
        }

        // reset flag
        SET_CALL_STAT_FLAG(ptCi, famIdx, NO_ATTEMPT);
    }

    MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily, mType,
        pmMultiCollect.updateMethod, 1);

    // Handover features related additional statistics
    FnVCCB_CollectPmccAdditionalHOStatistic(ptCi, &pmMultiCollect, mFamily, mActualFamily, mType);  // HO_STAT_23B

    // Check Additional Statistic for Ranking.
    rankType = GetRankTypeId(mFamily, mType);
    if (rankType != -1)
    {
        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily, rankType,
            pmMultiCollect.updateMethod, 1);
    }

    // Collect Mobility CSL - FGR-MC1007 FR790, FGR-MC1027 FR400, FGR-MC3002 FR190
    FnVCCB_CollectMobilityCsl(*ptCi, &pmMultiCollect, mFamily);

    if (STAT_IS_MOBILITY_SERVICETYPE_FAMILY(mFamily)) // Fill ServiceType_SA Indexes
    {
        FnVCCB_CollectMobilityServiceTypeFamily(ptCi, mFamily, pmKey, &pmMultiCollect);
    }
    else
    {
        CollectPmStatistics(
                ptCi, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemUintArr, pmKey, shmStoreFlag);
    }
}

/**
 * @brief     Collect UE message stat(CATEGORY:message only) with PmCC
 * @param     mFamily : stat family
 * @param     mType : stat type
 */
void VLIB_LibStatPmCC_MSG(int mFamily, int mType, uint32_t gnbIdOrNum, uint16_t endPointIdx)
{
    AUTO_TRACE_FUNC;

    int shmStoreFlag = TRUE;

    uint32_t gnbId;
    uint16_t gnbNum;

    VccbGnbInfo_type *pGnb = NULL;

#ifdef __NVGNB__
    gnbNum = (uint16_t)gnbIdOrNum;
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    pGnb = &GNBINFO[gnbNum];
    gnbId = pGnb->globalGnbId.gnbId.id;
#else
    if (TRUE == FOO.VF_MultipleOperatorRanSupport)
    {
        gnbNum = (uint16_t)gnbIdOrNum;
        VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
        pGnb = &GNBINFO[gnbNum];
        gnbId = pGnb->globalGnbId.gnbId.id;
    }
    else
    {
        gnbId = gnbIdOrNum;
        gnbNum = 0;
        VCCB_GET_GNB_NUM_FROM_ID_RETURN_VOID(gnbId, gnbNum);
        pGnb = &GNBINFO[gnbNum];
    }
#endif

    int mActualFamily = mFamily;
    xnNbrInfo_type *pXnNbr = NULL;
    uint32_t plmnKey = 0;

    VccbPmKey_type pmKey;
    memset(&pmKey, 0, sizeof(VccbPmKey_type));
    VccbPmMultiCollect_type pmMultiCollect;

    FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_CC);

    if (DBG->log.logStoreStatMsgCnt == VCCB_FLAG_OFF)
    {
        shmStoreFlag = FALSE;  // not store msg count stat
    }

    switch (mFamily)
    {
        case STAT_X2AP_MSG_UE_PER_GNB:
            pmKey.keyList[VCCB_PMKEY_INDEX1] = gnbId;
            VCCB_CHECK_E_RANGE_AND_VOID(endPointIdx, MAX_ENB_PER_GNB_CU_CP);
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->x2Nbr[endPointIdx].enbId;
            break;

        case STAT_XNAP_MSG_UE:
            pXnNbr = FnVCCB_GetXnNbrInfo(gnbNum, endPointIdx);
            if (pXnNbr == NULL)
            {
                return;
            }
            if(pXnNbr->ngRanNodeType != ngRanNode_ngEnbType)    // Counter is pegged only for NEDC
            {
                return;
            }
            pmKey.keyList[VCCB_PMKEY_INDEX1] = gnbId;
            /*
                caution)
                if the endpointIdx of XNAP is used in the future,
                be sure to keep in mind that endPointIdx is 0xFFFE in case of INTRA-GNB-NRDC.
                So, don't use endPointIdx as dbIdx in this case. it will cause db-overrun.
            */
            break;

        case STAT_XNAP_MSG_UE_PER_GNB:

            VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &plmnKey);

            pXnNbr = FnVCCB_GetXnNbrInfo(gnbNum, endPointIdx);
            if (pXnNbr == NULL)
            {
                return;
            }

            if(pXnNbr->ngRanNodeType == ngRanNode_ngEnbType)    // Counter is pegged only for SA and NRDC
            {
                return;
            }

            pmKey.keyList[VCCB_PMKEY_INDEX1] = plmnKey;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = gnbId;
            pmKey.keyList[VCCB_PMKEY_INDEX3] = pXnNbr->gnbId.id;
            break;

        // For the following message count statistics family (Target I/F: E1, F1, NG, RRC),
        // it is recommended to collect periodically through the MACRO_STAT_PMCC_MSG_PERIODIC macro to resolve performance issue.
        case STAT_F1AP_CU_MSG_UE:
        case STAT_NGAP_MSG_UE:
        case STAT_RRC_MSG:
        case STAT_E1AP_CUCP_MSG_UE:
            pmKey.keyList[VCCB_PMKEY_INDEX1] = gnbId;
            break;

        default:
            VCCB_PRINT_ERROR("Not a Stat family(%d) defined in VLIB_LibStatPmCC_MSG!\n", mFamily);
            return;  // calling OAMLIB with invalid family could cause unexpected behavior
    }

    StatisticsHandler statHandler(gnbNum, endPointIdx);
    statHandler.changeFamilyAndIndex(NULL, mActualFamily, pmKey);

    MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily, mType,
        pmMultiCollect.updateMethod, 1);
    CollectPmStatistics(
        NULL, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemUintArr, pmKey, shmStoreFlag);
}

void FnVCCB_PeriodicStat_InterfaceMsgCount_E1apCuCpMsgUe(uint16_t epIdx, uint16_t gnbNum, uint32_t gnbId, int shmStoreFlag)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(epIdx, MAX_GNB_CU_UP_PER_GNB_CU_CP);
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    /* comparison is always false due to limited range of data type
    VCCB_CHECK_E_RANGE_AND_VOID(gnbId, MAX_GNB_IDENTITY);
    */

    auto& rLocalE1apCuCpMsgUe = VCCB_STAT->localStat.localE1apCuCpMsgUe[gnbNum][epIdx];

    VccbPmMultiCollect_type pmMultiCollect;
    VccbPmKey_type pmKey;

    int mFamily = STAT_E1AP_CUCP_MSG_UE;
    int mActualFamily = mFamily;

    // E1AP: [index1][epIdx][mType][callThread]

    FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_CC);
    memset(&pmKey, 0, sizeof(VccbPmKey_type));

    pmKey.keyList[VCCB_PMKEY_INDEX1] = gnbId; // gnodeb-id

    StatisticsHandler statHandler(gnbNum, epIdx);
    statHandler.changeFamilyAndIndex(NULL, mActualFamily, pmKey);

    const uint32_t maxCallThreadNum = MAX_CALL_THREAD_NUM_VCCB;
    for (int mType = 0; mType < STAT_E1AP_CUCP_MSG_UE_END; mType++)
    {
        uint32_t aggregated = 0;

        for (uint32_t callThr = 0; callThr < maxCallThreadNum; callThr++)
        {
            uint32_t curr = rLocalE1apCuCpMsgUe[mType][callThr].curr;
            aggregated += calcIncreasedCount(rLocalE1apCuCpMsgUe[mType][callThr].prev, curr);
            rLocalE1apCuCpMsgUe[mType][callThr].prev = curr;
        }

        if (aggregated > 0)
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily, mType, pmMultiCollect.updateMethod, aggregated);
        }
    }

    if (pmMultiCollect.numOfItem > 0)
    {
        CollectPmStatistics(NULL, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemUintArr, pmKey, shmStoreFlag);
    }
}

void FnVCCB_PeriodicStat_InterfaceMsgCount_F1apCuMsgUe(uint16_t gnbNum, uint32_t gnbId, int shmStoreFlag)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    /* comparison is always false due to limited range of data type
    VCCB_CHECK_E_RANGE_AND_VOID(gnbId, MAX_GNB_IDENTITY);
    */

    auto& rLocalF1apCuMsgUe = VCCB_STAT->localStat.localF1apCuMsgUe[gnbNum];

    VccbPmMultiCollect_type pmMultiCollect;
    VccbPmKey_type pmKey;

    int mFamily = STAT_F1AP_CU_MSG_UE;
    int mActualFamily = mFamily;

    // F1AP: [index1][mType][callThread]

    FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_CC);
    memset(&pmKey, 0, sizeof(VccbPmKey_type));

    pmKey.keyList[VCCB_PMKEY_INDEX1] = gnbId; // gnodeb-id

    StatisticsHandler statHandler(gnbNum);
    statHandler.changeFamilyAndIndex(NULL, mActualFamily, pmKey);

    const uint32_t maxCallThreadNum = MAX_CALL_THREAD_NUM_VCCB;
    for (int mType = 0; mType < STAT_F1AP_CU_MSG_UE_END; mType++)
    {
        uint32_t aggregated = 0;

        for (uint32_t callThr = 0; callThr < maxCallThreadNum; callThr++)
        {
            uint32_t curr = rLocalF1apCuMsgUe[mType][callThr].curr;
            aggregated += calcIncreasedCount(rLocalF1apCuMsgUe[mType][callThr].prev, curr);
            rLocalF1apCuMsgUe[mType][callThr].prev = curr;
        }

        if (aggregated > 0)
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily, mType, pmMultiCollect.updateMethod, aggregated);
        }
    }

    if (pmMultiCollect.numOfItem > 0)
    {
        CollectPmStatistics(NULL, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemUintArr, pmKey, shmStoreFlag);
    }
}

void FnVCCB_PeriodicStat_InterfaceMsgCount_NgapMsgUe(uint16_t gnbNum, uint32_t gnbId, int shmStoreFlag)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    /* comparison is always false due to limited range of data type
    VCCB_CHECK_E_RANGE_AND_VOID(gnbId, MAX_GNB_IDENTITY);
    */

    auto& rLocalNgapMsgUe = VCCB_STAT->localStat.localNgapMsgUe[gnbNum];

    VccbPmMultiCollect_type pmMultiCollect;
    VccbPmKey_type pmKey;

    int mFamily = STAT_NGAP_MSG_UE;
    int mActualFamily = mFamily;

    // NGAP: [index1][mType][callThread]

    FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_CC);
    memset(&pmKey, 0, sizeof(VccbPmKey_type));

    pmKey.keyList[VCCB_PMKEY_INDEX1] = gnbId; // gnodeb-id

    StatisticsHandler statHandler(gnbNum);
    statHandler.changeFamilyAndIndex(NULL, mActualFamily, pmKey);

    const uint32_t maxCallThreadNum = MAX_CALL_THREAD_NUM_VCCB;
    for (int mType = 0; mType < STAT_NGAP_MSG_UE_END; mType++)
    {
        uint32_t aggregated = 0;

        for (uint32_t callThr = 0; callThr < maxCallThreadNum; callThr++)
        {
            uint32_t curr = rLocalNgapMsgUe[mType][callThr].curr;
            aggregated += calcIncreasedCount(rLocalNgapMsgUe[mType][callThr].prev, curr);
            rLocalNgapMsgUe[mType][callThr].prev = curr;
        }

        if (aggregated > 0)
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily, mType, pmMultiCollect.updateMethod, aggregated);
        }
    }

    if (pmMultiCollect.numOfItem > 0)
    {
        CollectPmStatistics(NULL, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemUintArr, pmKey, shmStoreFlag);
    }
}

void FnVCCB_PeriodicStat_InterfaceMsgCount_RrcMsg(uint16_t gnbNum, uint32_t gnbId, int shmStoreFlag)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    /* comparison is always false due to limited range of data type
    VCCB_CHECK_E_RANGE_AND_VOID(gnbId, MAX_GNB_IDENTITY);
    */

    auto& rLocalRrcMsg = VCCB_STAT->localStat.localRrcMsg[gnbNum];

    VccbPmMultiCollect_type pmMultiCollect;
    VccbPmKey_type pmKey;

    int mFamily = STAT_RRC_MSG;
    int mActualFamily = mFamily;

    // RRC: [index1][mType][callThread]

    FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_CC);
    memset(&pmKey, 0, sizeof(VccbPmKey_type));

    pmKey.keyList[VCCB_PMKEY_INDEX1] = gnbId; // gnodeb-id

    StatisticsHandler statHandler(gnbNum);
    statHandler.changeFamilyAndIndex(NULL, mActualFamily, pmKey);

    const uint32_t maxCallThreadNum = MAX_CALL_THREAD_NUM_VCCB;
    for (int mType = 0; mType < STAT_RRC_MSG_END; mType++)
    {
        uint32_t aggregated = 0;

        for (uint32_t callThr = 0; callThr < maxCallThreadNum; callThr++)
        {
            uint32_t curr = rLocalRrcMsg[mType][callThr].curr;
            aggregated += calcIncreasedCount(rLocalRrcMsg[mType][callThr].prev, curr);
            rLocalRrcMsg[mType][callThr].prev = curr;
        }

        if (aggregated > 0)
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily, mType, pmMultiCollect.updateMethod, aggregated);
        }
    }

    if (pmMultiCollect.numOfItem > 0)
    {
        CollectPmStatistics(NULL, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemUintArr, pmKey, shmStoreFlag);
    }
}

/**
 * @brief     Update UE message stat(CATEGORY:message only) with PmCC periodically
 */
void FnVCCB_PeriodicStat_InterfaceMsgCount()
{
    AUTO_TRACE_FUNC;

    static_assert((VCCB_MAX_MTYPES >= STAT_E1AP_CUCP_MSG_UE_END) && (VCCB_MAX_MTYPES >= STAT_F1AP_CU_MSG_UE_END)
                  && (VCCB_MAX_MTYPES >= STAT_NGAP_MSG_UE_END) && (VCCB_MAX_MTYPES >= STAT_RRC_MSG_END),
                  "[PeriodicMsgStat] Maximum mTypes of MSG Stats exceeds VCCB_MAX_MTYPES(96) capacity!");

    auto& pGnb = GNBINFO;
    int shmStoreFlag = (DBG->log.logStoreStatMsgCnt != VCCB_FLAG_OFF) ? TRUE : FALSE;

    for (uint16_t gnbNum = 0; gnbNum < MAX_GNB_PER_SYS; gnbNum++)
    {
        uint32_t gnbId = pGnb[gnbNum].globalGnbId.gnbId.id;

        FnVCCB_PeriodicStat_InterfaceMsgCount_F1apCuMsgUe(gnbNum, gnbId, shmStoreFlag);
        for (uint16_t epIdx = 0; epIdx < MAX_GNB_CU_UP_PER_GNB_CU_CP; epIdx++)
        {
            // epIdx: F_BearerContextManagementviaE1_UpIdCounterFamily
            FnVCCB_PeriodicStat_InterfaceMsgCount_E1apCuCpMsgUe(epIdx, gnbNum, gnbId, shmStoreFlag);
        }
        FnVCCB_PeriodicStat_InterfaceMsgCount_NgapMsgUe(gnbNum, gnbId, shmStoreFlag);
        FnVCCB_PeriodicStat_InterfaceMsgCount_RrcMsg(gnbNum, gnbId, shmStoreFlag);
    }
}

/**
 * @brief     Collect UE message stat(CATEGORY:message only) without PmCC
 */
void FnVCCB_CollectInterfaceMsgCount(int mFamily, int mType, uint32_t gnbIdOrNum, uint16_t endPointIdx, uint8_t threadId)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);

    uint32_t gnbId;
    uint16_t gnbNum;

    VccbGnbInfo_type *pGnb = NULL;

#ifdef __NVGNB__
    gnbNum = (uint16_t)gnbIdOrNum;
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    pGnb = &GNBINFO[gnbNum];
    gnbId = pGnb->globalGnbId.gnbId.id;
#else
    if (TRUE == FOO.VF_MultipleOperatorRanSupport)
    {
        gnbNum = (uint16_t)gnbIdOrNum;
        VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
        pGnb = &GNBINFO[gnbNum];
        gnbId = pGnb->globalGnbId.gnbId.id;
    }
    else
    {
        gnbId = gnbIdOrNum;
        gnbNum = 0;
        VCCB_GET_GNB_NUM_FROM_ID_RETURN_VOID(gnbId, gnbNum);
        pGnb = &GNBINFO[gnbNum];
    }
#endif

    switch (mFamily)
    {
        case STAT_E1AP_CUCP_MSG_UE:
            VCCB_CHECK_E_RANGE_AND_VOID(endPointIdx, MAX_GNB_CU_UP_PER_GNB_CU_CP);
            VCCB_STAT->localStat.localE1apCuCpMsgUe[gnbNum][endPointIdx][mType][threadId].curr += 1;
            break;
        case STAT_F1AP_CU_MSG_UE:
            VCCB_STAT->localStat.localF1apCuMsgUe[gnbNum][mType][threadId].curr += 1;
            break;
        case STAT_NGAP_MSG_UE:
            VCCB_STAT->localStat.localNgapMsgUe[gnbNum][mType][threadId].curr += 1;
            break;
        case STAT_RRC_MSG:
            VCCB_STAT->localStat.localRrcMsg[gnbNum][mType][threadId].curr += 1;
            break;
        default:
            VCCB_PRINT_ERROR("Not a Stat family(%d) defined in FnVCCB_CollectInterfaceMsgCount!\n", mFamily);
            break;
    }

    if (DBG->log.logStoreStatMsgCnt == VCCB_FLAG_ON)
    {
        VccbPmKey_type pmKey;
        memset(&pmKey, 0, sizeof(VccbPmKey_type));
        pmKey.keyList[VCCB_PMKEY_INDEX1] = gnbId;

        int mActualFamily = mFamily;
        StatisticsHandler statHandler(gnbNum, endPointIdx);
        statHandler.changeFamilyAndIndex(NULL, mActualFamily, pmKey);

        VCCB_PRINT_COMMENT("[PeriodicMsgStat] %u/%u/%u/%llu/%llu/%llu/%llu/%llu/%llu/%llu (%u/%u/%u)\n", mActualFamily, mType, /*updateVal*/ 1,
            pmKey.keyList[VCCB_PMKEY_INDEX1], pmKey.keyList[VCCB_PMKEY_INDEX2], pmKey.keyList[VCCB_PMKEY_INDEX3],
            pmKey.keyList[VCCB_PMKEY_INDEX4], pmKey.keyList[VCCB_PMKEY_INDEX5], pmKey.keyList[VCCB_PMKEY_INDEX6],
            pmKey.keyList[VCCB_PMKEY_INDEX7], threadId, endPointIdx, gnbNum);
    }

    return;
}

void VLIB_SetPmInfoForSaCsl_NrdcSn(callInfo_type *ptCi, nr_csl_cause_error_e &pmResult, uint16_t cause, pmCause_t *pmCause, pmCause_t &pmCauseEnd, uint32_t &pmFamilyId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    bool gnbDuIdIdxFamily = (FOO.VF_CallSummaryLogs_StatisticsForDuIdFamilies);
    bool statsForMSO      = (FOO.VF_CallSummaryLogs_StatisticsForMSO);
    bool cslWithHexCode   = (FOO.VF_CallSummaryLogs_WithCRRHexCode);

    if (gnbDuIdIdxFamily) // SVR23A
    {
        pmResult = nr_csl_du_id_hex_cause_get_sacp_nrdc_sn_pmCause(cause, pmCause);
        pmCauseEnd = STAT_SA_CUCPCSL_NRDC_SN_PER_GNB_DU_ID_HEXA_END;
        pmFamilyId = STAT_SA_CUCPCSL_NRDC_SN_PER_GNB_DU_ID_HEXA;

        if (statsForMSO)
        {
            pmCauseEnd = STAT_SA_CUCPCSL_NRDC_SN_PER_GNB_GLOBAL_ID_DU_ID_HEXA_END;
            pmFamilyId = STAT_SA_CUCPCSL_NRDC_SN_PER_GNB_GLOBAL_ID_DU_ID_HEXA;
        }
    }
    else if (statsForMSO && cslWithHexCode)
    {
        pmResult = nr_csl_cause_get_sacp_nrdc_sn_pmCause(cause, pmCause);
        pmCauseEnd = STAT_SA_CUCPCSL_NRDC_SN_PER_GNB_GLOBAL_ID_HEXA_END;
        pmFamilyId = STAT_SA_CUCPCSL_NRDC_SN_PER_GNB_GLOBAL_ID_HEXA;
    }
    else
    {
        pmResult = nr_csl_cause_get_sacp_nrdc_sn_pmCause(cause, pmCause);
        pmCauseEnd = STAT_SA_CUCPCSL_NRDC_SN_PER_GNB_END;  // Same as STAT_SA_CUCPCSL_NRDC_SN_PER_GNB_HEXA_END
        pmFamilyId = cslWithHexCode ? STAT_SA_CUCPCSL_NRDC_SN_PER_GNB_HEXA
                                    : STAT_SA_CUCPCSL_NRDC_SN_PER_GNB;  // Hex for VZW only
    }
}

void VLIB_SetPmInfoForSaCsl(callInfo_type *ptCi, nr_csl_cause_error_e &pmResult, uint16_t cause, pmCause_t *pmCause, pmCause_t &pmCauseEnd, uint32_t &pmFamilyId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    bool gnbDuIdIdxFamily = (FOO.VF_CallSummaryLogs_StatisticsForDuIdFamilies);
    bool moranSupport     = (FOO.VF_MultipleOperatorRanSupport);
    bool cslWithHexCode   = (FOO.VF_CallSummaryLogs_WithCRRHexCode);

    pmResult = nr_csl_cause_get_sacp_pmCause(cause, pmCause);
    pmCauseEnd = STAT_SA_CUCPCSL_PER_GNB_END;  // Same as STAT_SA_CUCPCSL_PER_GNB_HEXA_END and
                                               // STAT_SA_CUCPCSL_PER_GNB_GLOBAL_ID_END and
                                               // STAT_SA_CUCPCSL_PER_GNB_DU_ID_HEXA_END

    if (VLIB_IsExtendedCSL(cause) == FALSE)
    {
        if (moranSupport)
            pmFamilyId = STAT_SA_CUCPCSL_PER_GNB_GLOBAL_ID;
        else
            pmFamilyId = (TRUE == cslWithHexCode) ? STAT_SA_CUCPCSL_PER_GNB_HEXA
                                                  : STAT_SA_CUCPCSL_PER_GNB;
        if (gnbDuIdIdxFamily)
            pmFamilyId = STAT_SA_CUCPCSL_PER_GNB_DU_ID_HEXA;
    }
    else
    {
        pmCauseEnd = STAT_SA_CUCPCSL_PER_GNB_2_END;  // Same as STAT_SA_CUCPCSL_PER_GNB_GLOBAL_ID_2_END

        if (moranSupport)
            pmFamilyId = STAT_SA_CUCPCSL_PER_GNB_GLOBAL_ID_2;
        else
            pmFamilyId = (TRUE == cslWithHexCode) ? STAT_SA_CUCPCSL_PER_GNB_HEXA_2
                                                  : STAT_SA_CUCPCSL_PER_GNB_2;
        if (gnbDuIdIdxFamily)
        {
            pmCauseEnd = STAT_SA_CUCPCSL_PER_GNB_DU_ID_HEXA_2_END;
            pmFamilyId = STAT_SA_CUCPCSL_PER_GNB_DU_ID_HEXA_2;
        }
    }
}

void VLIB_SetPmInfoForNsaCsl_Endc(callInfo_type *ptCi, nr_csl_cause_error_e &pmResult, uint16_t cause, pmCause_t *pmCause, pmCause_t &pmCauseEnd, uint32_t &pmFamilyId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    bool gnbDuIdIdxFamily = (FOO.VF_CallSummaryLogs_StatisticsForDuIdFamilies);
    bool moranSupport     = (FOO.VF_MultipleOperatorRanSupport);

    if (gnbDuIdIdxFamily) // SVR23A
    {
        pmResult = nr_csl_du_id_hex_cause_get_cp_pmCause(cause, pmCause);
        pmCauseEnd = STAT_CUCPCSL_PER_GNB_DU_ID_HEXA_END;
        pmFamilyId = STAT_CUCPCSL_PER_GNB_DU_ID_HEXA;
    }
    else
    {
        pmResult = nr_csl_cause_get_cp_pmCause(cause, pmCause);
        pmCauseEnd = STAT_CUCPCSL_PER_GNB_END;  // Same as STAT_CUCPCSL_PER_GNB_HEXA_END and STAT_CUCPCSL_PER_GNB_GLOBAL_ID_END

        if (moranSupport)
        {
            pmFamilyId = STAT_CUCPCSL_PER_GNB_GLOBAL_ID;
        }
        else
        {
            pmFamilyId = (TRUE == FOO.VF_CallSummaryLogs_WithCRRHexCode) ? STAT_CUCPCSL_PER_GNB_HEXA
                                                                         : STAT_CUCPCSL_PER_GNB;
        }
    }
}

void VLIB_SetPmKey(callInfo_type *ptCi, uint64_t cellIdentity, VccbPmKey_type& pmKey, VccbPmMultiCollect_type& pmMultiCollect, uint32_t pmFamilyId, pmCause_t pmCause)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellIdentity, MAX_CELL_IDENTITY);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];

    bool gnbDuIdIdxFamily = (FOO.VF_CallSummaryLogs_StatisticsForDuIdFamilies);
    bool moranSupport     = (FOO.VF_MultipleOperatorRanSupport);
    bool statsForMSO      = (FOO.VF_CallSummaryLogs_StatisticsForMSO);

    if (moranSupport)
    {
        uint32_t plmnKey = 0;
        VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &plmnKey);

        pmKey.keyList[VCCB_PMKEY_INDEX1] = plmnKey;
        pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;
        pmKey.keyList[VCCB_PMKEY_INDEX3] = cellIdentity;

        VCCB_PRINT_COMMENT("PEG CSL Moran stats...\n");
    }
    else if (statsForMSO)
    {
        uint32_t plmnKey = 0;
        VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &plmnKey);

        pmKey.keyList[VCCB_PMKEY_INDEX1] = plmnKey;
        pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;
        pmKey.keyList[VCCB_PMKEY_INDEX3] = cellIdentity;

        if (gnbDuIdIdxFamily)
        {
            uint16_t cellNum = pGnb->env.cellNum[cellIdentity];
            VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
            const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

            VCCB_CHECK_E_RANGE_AND_VOID(pCell->endPointF1Index, MAX_GNB_DU_PER_GNB_CU_CP);
            pmKey.keyList[VCCB_PMKEY_INDEX3] = GetDuId(pGnb->gnbDu[pCell->endPointF1Index].gnbDuId);
            pmKey.keyList[VCCB_PMKEY_INDEX4] = cellIdentity;
            pmKey.keyList[VCCB_PMKEY_INDEX5] = ptCi->cslInfo.connectInfo.dcPeerRanNodeGnbId.id; // MgNB ID Master gNB -Secondary
        }
    }
    else
    {
        pmKey.keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;

        if(gnbDuIdIdxFamily)
        {
            uint16_t cellNum = pGnb->env.cellNum[cellIdentity];
            VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
            const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

            VCCB_CHECK_E_RANGE_AND_VOID(pCell->endPointF1Index, MAX_GNB_DU_PER_GNB_CU_CP);
            pmKey.keyList[VCCB_PMKEY_INDEX2] = GetDuId(pGnb->gnbDu[pCell->endPointF1Index].gnbDuId); // gNB_DU_ID
            pmKey.keyList[VCCB_PMKEY_INDEX3] = cellIdentity;                                         // Cell_ID

            if (pmFamilyId == STAT_CUCPCSL_PER_GNB_DU_ID_HEXA)
            {
                VCCB_CHECK_E_RANGE_AND_VOID(ptCi->endPointInfo.x2Idx, MAX_ENB_PER_GNB_CU_CP);
                pmKey.keyList[VCCB_PMKEY_INDEX4] = pGnb->x2Nbr[ptCi->endPointInfo.x2Idx].enbId; // eNB_ID
            }
            else if (pmFamilyId == STAT_SA_CUCPCSL_NRDC_SN_PER_GNB_DU_ID_HEXA)
            {
                pmKey.keyList[VCCB_PMKEY_INDEX4] = ptCi->cslInfo.connectInfo.dcPeerRanNodeGnbId.id; // MgNB ID  Master gNB -Secondary
            }

            VCCB_PRINT_COMMENT("PEG CSL DU_ID stats...\n");
        }
        else
        {
            pmKey.keyList[VCCB_PMKEY_INDEX2] = cellIdentity;
        }
    }

    MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, (int)pmFamilyId, pmCause,
                             pmMultiCollect.updateMethod, 1);
}

void VLIB_LibStatCSLInfo_CollectCrrSum(VccbPmMultiCollect_type& pmMultiCollect, uint32_t pmFamilyId, pmCause_t pmCause)
{
    AUTO_TRACE_FUNC;

    bool gnbDuIdIdxFamily = (FOO.VF_CallSummaryLogs_StatisticsForDuIdFamilies);
    bool pmFamSumId {
        (pmFamilyId  == STAT_CUCPCSL_PER_GNB_DU_ID_HEXA)                   ||
        (pmFamilyId  == STAT_SA_CUCPCSL_NRDC_SN_PER_GNB_DU_ID_HEXA)        ||
        (pmFamilyId  == STAT_SA_CUCPCSL_NRDC_SN_PER_GNB_GLOBAL_ID_DU_ID_HEXA)
    };

    if (gnbDuIdIdxFamily && pmFamSumId)
    {
        pmCause_t crrSumPmCause = (uint32_t)HEXA_ACPF_CrrSum_DUID;

        bool pmCauseSum = (pmCause != HEXA_SAACPF_NRDC_CrrSum_DUID);

        if (pmCauseSum)
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, (int)pmFamilyId, crrSumPmCause,
                                     pmMultiCollect.updateMethod, 1);
        }
    }
}

void VLIB_LibStatCSLInfo_CollectRedcapStats(callInfo_type *ptCi, uint64_t cellIdentity, uint16_t cause)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    if (not IS_REDCAP_UE(ptCi))
    {
        return;
    }

    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];

    pmCause_t pmCause = 0;
    pmCause_t pmCauseEnd = 0;
    uint32_t pmFamilyId = 0;
    nr_csl_cause_error_e pmResult = NR_CSL_CAUSE_ERROR_MAX;

    bool gnbRedcapFamily = (FOO.VF_CallSummaryLogs_StatisticsForRedcapFamilies);
    bool saCallType = (ptCi->callType == E_CALLTYPE_SA);

    if (saCallType && IS_REDCAP_UE(ptCi) && gnbRedcapFamily)
    {
        pmResult = nr_csl_redcap_hex_cause_get_cp_pmCause(cause, &pmCause);

        if (VLIB_IsExtendedCSL(cause) == FALSE)
        {
            pmCauseEnd = STAT_SA_REDCAP_CUCPCSL_HEXA_END;
            pmFamilyId = STAT_SA_REDCAP_CUCPCSL_HEXA;
        }
        else
        {
            pmCauseEnd = STAT_SA_REDCAP_CUCPCSL_HEXA_2_END;
            pmFamilyId = STAT_SA_REDCAP_CUCPCSL_HEXA_2;
        }
    }

    if (NR_CSL_CAUSE_ERROR_NONE == pmResult && pmCause < pmCauseEnd)
    {
        VCCB_CHECK_E_RANGE_AND_VOID(cellIdentity, MAX_CELL_IDENTITY);

        VccbPmKey_type pmKey;
        memset(&pmKey, 0, sizeof(VccbPmKey_type));
        VccbPmMultiCollect_type pmMultiCollect;
        FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_CC);

        if (gnbRedcapFamily)
        {
            uint32_t plmnKey = 0;
            VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &plmnKey);

            pmKey.keyList[VCCB_PMKEY_INDEX1] = plmnKey;
            pmKey.keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id;

            uint16_t cellNum = pGnb->env.cellNum[cellIdentity];
            VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
            const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

            VCCB_CHECK_E_RANGE_AND_VOID(pCell->endPointF1Index, MAX_GNB_DU_PER_GNB_CU_CP);
            pmKey.keyList[VCCB_PMKEY_INDEX3] = GetDuId(pGnb->gnbDu[pCell->endPointF1Index].gnbDuId);
            pmKey.keyList[VCCB_PMKEY_INDEX4] = cellIdentity;
        }

        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem,
                                 (int)pmFamilyId, pmCause, pmMultiCollect.updateMethod, 1);

        CollectPmStatistics(ptCi, pmFamilyId, pmFamilyId, &pmMultiCollect,
                            pmMultiCollect.updateItemUintArr, pmKey, TRUE);
    }
    else
    {
        VCCB_PRINT_CRITICAL("invalid pmCause(%d) for cause (%d). pmResult(%d)\n", pmCause, cause, pmResult);
        return;
    }
}

void VLIB_LibStatCSLInfo_CollectLegacyStats(callInfo_type *ptCi, uint64_t cellIdentity, uint16_t cause)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    if ( IS_REDCAP_UE(ptCi))
    {
        return;
    }

    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];

    pmCause_t pmCause = 0;
    pmCause_t pmCauseEnd = 0;
    uint32_t pmFamilyId = 0;
    nr_csl_cause_error_e pmResult = NR_CSL_CAUSE_ERROR_MAX;

    if (ptCi->callType == E_CALLTYPE_SA)
    {
        if (IS_NRDC_SN(ptCi) && FOO.VF_CallSummaryLogs_StatisticsForNRDCSN)  // NRDC SN
        {
            pmResult = nr_csl_cause_get_sacp_nrdc_sn_pmCause(cause, &pmCause);
            pmCauseEnd = STAT_SA_CUCPCSL_NRDC_SN_PER_GNB_END;  // Same as STAT_SA_CUCPCSL_NRDC_SN_PER_GNB_HEXA_END
            pmFamilyId = (FOO.VF_CallSummaryLogs_WithCRRHexCode) ? STAT_SA_CUCPCSL_NRDC_SN_PER_GNB_HEXA
                                                                 : STAT_SA_CUCPCSL_NRDC_SN_PER_GNB;  // Hex for VZW only
        }
        else
        {
            return;
        }
    }
    else  // NSA EN-DC
    {
            pmResult = nr_csl_cause_get_cp_pmCause(cause, &pmCause);
            pmCauseEnd = STAT_CUCPCSL_PER_GNB_END;  // Same as STAT_CUCPCSL_PER_GNB_HEXA_END and STAT_CUCPCSL_PER_GNB_GLOBAL_ID_END
            pmFamilyId = (TRUE == FOO.VF_CallSummaryLogs_WithCRRHexCode) ? STAT_CUCPCSL_PER_GNB_HEXA
                                                                         : STAT_CUCPCSL_PER_GNB;
    }

    if (NR_CSL_CAUSE_ERROR_NONE == pmResult && pmCause < pmCauseEnd)
    {
        VCCB_CHECK_E_RANGE_AND_VOID(cellIdentity, MAX_CELL_IDENTITY);

        VccbPmKey_type pmKey;
        memset(&pmKey, 0, sizeof(VccbPmKey_type));
        VccbPmMultiCollect_type pmMultiCollect;
        FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_CC);

        pmKey.keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;
        pmKey.keyList[VCCB_PMKEY_INDEX2] = cellIdentity;

        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, (int)pmFamilyId, pmCause,
                pmMultiCollect.updateMethod, 1);

        CollectPmStatistics(
                ptCi, pmFamilyId, pmFamilyId, &pmMultiCollect, pmMultiCollect.updateItemUintArr, pmKey, TRUE);
    }
    else
    {
        VCCB_PRINT_CRITICAL("invalid pmCause(%d) for cause (%d). pmResult(%d)\n", pmCause, cause, pmResult);
        return;
    }

}

/**
 * @brief     Collect CSL stat
 * @param     cellNum : Cell number
 * @param     cause : CSL cause
 */
void VLIB_LibStatCSLInfo(callInfo_type *ptCi, uint64_t cellIdentity, uint16_t cause)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    pmCause_t pmCause = 0;
    pmCause_t pmCauseEnd = 0;
    uint32_t pmFamilyId = 0;
    nr_csl_cause_error_e pmResult = NR_CSL_CAUSE_ERROR_MAX;

    bool gnbDuIdIdxFamily = (FOO.VF_CallSummaryLogs_StatisticsForDuIdFamilies);
    bool gnbRedcapFamily  = (FOO.VF_CallSummaryLogs_StatisticsForRedcapFamilies);
    bool cslWithHexCode   = (FOO.VF_CallSummaryLogs_WithCRRHexCode);

    if (ptCi->callType == E_CALLTYPE_SA)
    {
        if (IS_NRDC_SN(ptCi) && FOO.VF_CallSummaryLogs_StatisticsForNRDCSN)  // NRDC SN
        {
            VLIB_SetPmInfoForSaCsl_NrdcSn(ptCi, pmResult, cause, &pmCause, pmCauseEnd, pmFamilyId);
        }
        else
        {
            VLIB_SetPmInfoForSaCsl(ptCi, pmResult, cause, &pmCause, pmCauseEnd, pmFamilyId);
        }
    }
    else  // NSA EN-DC
    {
        VLIB_SetPmInfoForNsaCsl_Endc(ptCi, pmResult, cause, &pmCause, pmCauseEnd, pmFamilyId);
    }

    if (NR_CSL_CAUSE_ERROR_NONE == pmResult && pmCause < pmCauseEnd)
    {
        if (not IS_REDCAP_UE(ptCi))
        {
            VCCB_CHECK_E_RANGE_AND_VOID(cellIdentity, MAX_CELL_IDENTITY);

            VccbPmKey_type pmKey;
            memset(&pmKey, 0, sizeof(VccbPmKey_type));
            VccbPmMultiCollect_type pmMultiCollect;
            FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_CC);

            VLIB_SetPmKey(ptCi, cellIdentity, pmKey, pmMultiCollect, pmFamilyId, pmCause);

            VLIB_LibStatCSLInfo_CollectCrrSum(pmMultiCollect, pmFamilyId, pmCause);

            CollectPmStatistics(ptCi, pmFamilyId, pmFamilyId, &pmMultiCollect, pmMultiCollect.updateItemUintArr, pmKey, TRUE);
        }
    }
    else
    {
        VCCB_PRINT_CRITICAL("invalid pmCause(%d) for cause (%d). pmResult(%d)\n", pmCause, cause, pmResult);
        return;
    }

    // SVR24A
    if (gnbRedcapFamily && !(IS_NRDC_SN(ptCi) && FOO.VF_CallSummaryLogs_StatisticsForNRDCSN))
    {
        VCCB_PRINT_COMMENT("PEG CSL Redcap stats... \n");
        VLIB_LibStatCSLInfo_CollectRedcapStats(ptCi, cellIdentity, cause);
    }

    // SVR23A, SVR24A
    if ((gnbDuIdIdxFamily || gnbRedcapFamily) && cslWithHexCode)
    {
        VCCB_PRINT_COMMENT("PEG CSL legacy stats... \n");
        VLIB_LibStatCSLInfo_CollectLegacyStats(ptCi, cellIdentity, cause);
    }
}

void VLIB_IntraRatHO_F1Cause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    int famIdx;

    if (ptCi->hoInfo.hoType.initiated == HO_TYPE_SGNB_INITIATED)
    {
        if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
        {
            famIdx = GET_FAMIDX(STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegIntraSnPscellChange(*ptCi, EndcIntraChgFail_DuFail);
            }
            else
            {
                VCCB_NSA_PegIntraSnPscellChange(*ptCi, EndcIntraChgPrepFail_DuFail);
            }
        }
        else if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTER_NB)
        {
            famIdx = GET_FAMIDX(STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegInterSnPscellChange(*ptCi, EndcInterChgSrcFail_DuFail);
            }
            else
            {
                VCCB_NSA_PegInterSnPscellChange(*ptCi, EndcInterChgSrcPrepFail_DuFail);
            }
        }
    }
    else if (ptCi->hoInfo.hoType.initiated == HO_TYPE_MENB_INITIATED)
    {
        famIdx = GET_FAMIDX(STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB);
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
        if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
        {
            MACRO_STAT_PMCC(
                STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB, EndcModByMenbMcgMobFail_DuFail, ptCi, 0, 0, 0, 0, 0);
        }
        else
        {
            MACRO_STAT_PMCC(
                STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB, EndcModByMenbMcgMobPrepFail_DuFail, ptCi, 0, 0, 0, 0, 0);
        }
    }
    else if (ptCi->hoInfo.hoType.initiated == HO_TYPE_MENB_INTERMNHO)
    {
        famIdx = GET_FAMIDX(STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG);
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
        if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
        {
            VCCB_NSA_PegSgnbAddIntraLteHoNoSgnbChg(*ptCi, EndcAddLteHoNoSgnbChgFail_DuFail);
        }
        else
        {
            VCCB_NSA_PegSgnbAddIntraLteHoNoSgnbChg(*ptCi, EndcAddLteHoNoSgnbChgPrepFail_DuFail);
        }
    }
}

void VLIB_IntraRatHO_E1Cause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    int famIdx;

    if (ptCi->hoInfo.hoType.initiated == HO_TYPE_SGNB_INITIATED)
    {
        if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
        {
            famIdx = GET_FAMIDX(STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegIntraSnPscellChange(*ptCi, EndcIntraChgFail_UpFail);
            }
            else
            {
                VCCB_NSA_PegIntraSnPscellChange(*ptCi, EndcIntraChgPrepFail_UpFail);
            }
        }
        else if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTER_NB)
        {
            famIdx = GET_FAMIDX(STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegInterSnPscellChange(*ptCi, EndcInterChgSrcFail_UpFail);
            }
            else
            {
                VCCB_NSA_PegInterSnPscellChange(*ptCi, EndcInterChgSrcPrepFail_UpFail);
            }
        }
    }
    else if (ptCi->hoInfo.hoType.initiated == HO_TYPE_MENB_INITIATED)
    {
        famIdx = GET_FAMIDX(STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB);
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
        if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
        {
            MACRO_STAT_PMCC(
                STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB, EndcModByMenbMcgMobFail_UpFail, ptCi, 0, 0, 0, 0, 0);
        }
        else
        {
            MACRO_STAT_PMCC(
                STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB, EndcModByMenbMcgMobPrepFail_UpFail, ptCi, 0, 0, 0, 0, 0);
        }
    }
    else if (ptCi->hoInfo.hoType.initiated == HO_TYPE_MENB_INTERMNHO)
    {
        famIdx = GET_FAMIDX(STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG);
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
        if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
        {
            VCCB_NSA_PegSgnbAddIntraLteHoNoSgnbChg(*ptCi, EndcAddLteHoNoSgnbChgFail_UpFail);
        }
        else
        {
            VCCB_NSA_PegSgnbAddIntraLteHoNoSgnbChg(*ptCi, EndcAddLteHoNoSgnbChgPrepFail_UpFail);
        }
    }
}

void VLIB_IntraRatHO_X2Cause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    int famIdx;

    if (ptCi->hoInfo.hoType.initiated == HO_TYPE_SGNB_INITIATED)
    {
        if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
        {
            famIdx = GET_FAMIDX(STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegIntraSnPscellChange(*ptCi, EndcIntraChgFail_MenbFail);
            }
            else
            {
                VCCB_NSA_PegIntraSnPscellChange(*ptCi, EndcIntraChgPrepFail_MenbFail);
            }
        }
        else if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTER_NB)
        {
            famIdx = GET_FAMIDX(STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegInterSnPscellChange(*ptCi, EndcInterChgSrcFail_MenbFail);
            }
            else
            {
                VCCB_NSA_PegInterSnPscellChange(*ptCi, EndcInterChgSrcPrepFail_MenbFail);
            }
        }
    }
    else if (ptCi->hoInfo.hoType.initiated == HO_TYPE_MENB_INITIATED)
    {
        famIdx = GET_FAMIDX(STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB);
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
        if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
        {
            MACRO_STAT_PMCC(
                STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB, EndcModByMenbMcgMobFail_MenbFail, ptCi, 0, 0, 0, 0, 0);
        }
        else
        {
            MACRO_STAT_PMCC(
                STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB, EndcModByMenbMcgMobPrepFail_MenbFail, ptCi, 0, 0, 0, 0, 0);
        }
    }
    else if (ptCi->hoInfo.hoType.initiated == HO_TYPE_MENB_INTERMNHO)
    {
        famIdx = GET_FAMIDX(STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG);
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
        if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
        {
            VCCB_NSA_PegSgnbAddIntraLteHoNoSgnbChg(*ptCi, EndcAddLteHoNoSgnbChgFail_MenbFail);
        }
        else
        {
            VCCB_NSA_PegSgnbAddIntraLteHoNoSgnbChg(*ptCi, EndcAddLteHoNoSgnbChgPrepFail_MenbFail);
        }
    }
}

void VLIB_IntraRatHO_InternalCause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    int famIdx;

    if (ptCi->hoInfo.hoType.initiated == HO_TYPE_SGNB_INITIATED)
    {
        if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
        {
            famIdx = GET_FAMIDX(STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegIntraSnPscellChange(*ptCi, EndcIntraChgFail_CpFail);
            }
            else
            {
                VCCB_NSA_PegIntraSnPscellChange(*ptCi, EndcIntraChgPrepFail_CpFail);
            }
        }
        else if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTER_NB)
        {
            famIdx = GET_FAMIDX(STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegInterSnPscellChange(*ptCi, EndcInterChgSrcFail_CpFail);
            }
            else
            {
                VCCB_NSA_PegInterSnPscellChange(*ptCi, EndcInterChgSrcPrepFail_CpFail);
            }
        }
    }
    else if (ptCi->hoInfo.hoType.initiated == HO_TYPE_MENB_INITIATED)
    {
        famIdx = GET_FAMIDX(STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB);
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
        if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
        {
            MACRO_STAT_PMCC(
                STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB, EndcModByMenbMcgMobFail_CpFail, ptCi, 0, 0, 0, 0, 0);
        }
        else
        {
            MACRO_STAT_PMCC(
                STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB, EndcModByMenbMcgMobPrepFail_CpFail, ptCi, 0, 0, 0, 0, 0);
        }
    }
    else if (ptCi->hoInfo.hoType.initiated == HO_TYPE_MENB_INTERMNHO)
    {
        famIdx = GET_FAMIDX(STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG);
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
        if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
        {
            VCCB_NSA_PegSgnbAddIntraLteHoNoSgnbChg(*ptCi, EndcAddLteHoNoSgnbChgFail_CpFail);
        }
        else
        {
            VCCB_NSA_PegSgnbAddIntraLteHoNoSgnbChg(*ptCi, EndcAddLteHoNoSgnbChgPrepFail_CpFail);
        }
    }
}

void VLIB_SgNBAddition_F1Cause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    int famIdx;

    switch (ptCi->hoInfo.sgnbAddTrigInd)
    {
        case SgnbAddTrigInd_SnChange:
            famIdx = GET_FAMIDX(STAT_SGNB_ADD_SGNB_CHG);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegSgnbAddSgnbChg(*ptCi, EndcAddSgnbChgFail_DuFail);
            }
            else
            {
                VCCB_NSA_PegSgnbAddSgnbChg(*ptCi, EndcAddSgnbChgPrepFail_DuFail);
            }
            break;

        case SgnbAddTrigInd_InterMnHo:
            famIdx = GET_FAMIDX(STAT_SGNB_ADD_MNHO_INTER_ENB);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegSgnbAddMnHoInterEnb(*ptCi, EndcAddMnHoInterEnbFail_DuFail);
            }
            else
            {
                VCCB_NSA_PegSgnbAddMnHoInterEnb(*ptCi, EndcAddMnHoInterEnbPrepFail_DuFail);
            }
            break;

        case SgnbAddTrigInd_IntraMnHo:
            famIdx = GET_FAMIDX(STAT_SGNB_ADD_MNHO_INTRA_ENB);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegSgnbAddMnHoIntraEnb(*ptCi, EndcAddMnHoIntraEnbFail_DuFail);
            }
            else
            {
                VCCB_NSA_PegSgnbAddMnHoIntraEnb(*ptCi, EndcAddMnHoIntraEnbPrepFail_DuFail);
            }
            break;

        default:
            famIdx = GET_FAMIDX(STAT_SGNB_ADD_PER_GNB);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                MACRO_STAT_PMCC(STAT_SGNB_ADD_PER_GNB, EndcAddFail_DuFail, ptCi, 0, 0, 0, 0, 0);
            }
            else
            {
                MACRO_STAT_PMCC(STAT_SGNB_ADD_PER_GNB, EndcAddPrepFail_DuFail, ptCi, 0, 0, 0, 0, 0);
            }
            break;
    }
}

void VLIB_SgNBAddition_E1Cause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    int famIdx;

    switch (ptCi->hoInfo.sgnbAddTrigInd)
    {
        case SgnbAddTrigInd_SnChange:
            famIdx = GET_FAMIDX(STAT_SGNB_ADD_SGNB_CHG);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegSgnbAddSgnbChg(*ptCi, EndcAddSgnbChgFail_UpFail);
            }
            else
            {
                VCCB_NSA_PegSgnbAddSgnbChg(*ptCi, EndcAddSgnbChgPrepFail_UpFail);
            }
            break;

        case SgnbAddTrigInd_InterMnHo:
            famIdx = GET_FAMIDX(STAT_SGNB_ADD_SGNB_CHG);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegSgnbAddMnHoInterEnb(*ptCi, EndcAddMnHoInterEnbFail_UpFail);
            }
            else
            {
                VCCB_NSA_PegSgnbAddMnHoInterEnb(*ptCi, EndcAddMnHoInterEnbPrepFail_UpFail);
            }
            break;

        case SgnbAddTrigInd_IntraMnHo:
            famIdx = GET_FAMIDX(STAT_SGNB_ADD_MNHO_INTRA_ENB);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegSgnbAddMnHoIntraEnb(*ptCi, EndcAddMnHoIntraEnbFail_UpFail);
            }
            else
            {
                VCCB_NSA_PegSgnbAddMnHoIntraEnb(*ptCi, EndcAddMnHoIntraEnbPrepFail_UpFail);
            }
            break;

        default:
            famIdx = GET_FAMIDX(STAT_SGNB_ADD_PER_GNB);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                MACRO_STAT_PMCC(STAT_SGNB_ADD_PER_GNB, EndcAddFail_UpFail, ptCi, 0, 0, 0, 0, 0);
            }
            else
            {
                MACRO_STAT_PMCC(STAT_SGNB_ADD_PER_GNB, EndcAddPrepFail_UpFail, ptCi, 0, 0, 0, 0, 0);
            }
            break;
    }
}

void VLIB_SgNBAddition_X2Cause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    int famIdx;

    switch (ptCi->hoInfo.sgnbAddTrigInd)
    {
        case SgnbAddTrigInd_SnChange:
            famIdx = GET_FAMIDX(STAT_SGNB_ADD_SGNB_CHG);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegSgnbAddSgnbChg(*ptCi, EndcAddSgnbChgFail_MenbFail);
            }
            else
            {
                VCCB_NSA_PegSgnbAddSgnbChg(*ptCi, EndcAddSgnbChgPrepFail_MenbFail);
            }
            break;

        case SgnbAddTrigInd_InterMnHo:
            famIdx = GET_FAMIDX(STAT_SGNB_ADD_MNHO_INTER_ENB);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegSgnbAddMnHoInterEnb(*ptCi, EndcAddMnHoInterEnbFail_MenbFail);
            }
            else
            {
                VCCB_NSA_PegSgnbAddMnHoInterEnb(*ptCi, EndcAddMnHoInterEnbPrepFail_MenbFail);
            }
            break;

        case SgnbAddTrigInd_IntraMnHo:
            famIdx = GET_FAMIDX(STAT_SGNB_ADD_MNHO_INTRA_ENB);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegSgnbAddMnHoIntraEnb(*ptCi, EndcAddMnHoIntraEnbFail_MenbFail);
            }
            else
            {
                VCCB_NSA_PegSgnbAddMnHoIntraEnb(*ptCi, EndcAddMnHoIntraEnbPrepFail_MenbFail);
            }
            break;

        default:
            famIdx = GET_FAMIDX(STAT_SGNB_ADD_PER_GNB);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                MACRO_STAT_PMCC(STAT_SGNB_ADD_PER_GNB, EndcAddFail_MenbFail, ptCi, 0, 0, 0, 0, 0);
            }
            else
            {
                MACRO_STAT_PMCC(STAT_SGNB_ADD_PER_GNB, EndcAddPrepFail_MenbFail, ptCi, 0, 0, 0, 0, 0);
            }
            break;
    }
}

void VLIB_SgNBAddition_InternalCause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    int famIdx;

    switch (ptCi->hoInfo.sgnbAddTrigInd)
    {
        case SgnbAddTrigInd_SnChange:
            famIdx = GET_FAMIDX(STAT_SGNB_ADD_SGNB_CHG);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegSgnbAddSgnbChg(*ptCi, EndcAddSgnbChgFail_CpFail);
            }
            else
            {
                VCCB_NSA_PegSgnbAddSgnbChg(*ptCi, EndcAddSgnbChgPrepFail_CpFail);
            }
            break;

        case SgnbAddTrigInd_InterMnHo:
            famIdx = GET_FAMIDX(STAT_SGNB_ADD_MNHO_INTER_ENB);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegSgnbAddMnHoInterEnb(*ptCi, EndcAddMnHoInterEnbFail_CpFail);
            }
            else
            {
                VCCB_NSA_PegSgnbAddMnHoInterEnb(*ptCi, EndcAddMnHoInterEnbPrepFail_CpFail);
            }
            break;

        case SgnbAddTrigInd_IntraMnHo:
            famIdx = GET_FAMIDX(STAT_SGNB_ADD_MNHO_INTRA_ENB);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                VCCB_NSA_PegSgnbAddMnHoIntraEnb(*ptCi, EndcAddMnHoIntraEnbFail_CpFail);
            }
            else
            {
                VCCB_NSA_PegSgnbAddMnHoIntraEnb(*ptCi, EndcAddMnHoIntraEnbPrepFail_CpFail);
            }
            break;

        default:
            famIdx = GET_FAMIDX(STAT_SGNB_ADD_PER_GNB);
            VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                MACRO_STAT_PMCC(STAT_SGNB_ADD_PER_GNB, EndcAddFail_CpFail, ptCi, 0, 0, 0, 0, 0);
            }
            else
            {
                MACRO_STAT_PMCC(STAT_SGNB_ADD_PER_GNB, EndcAddPrepFail_CpFail, ptCi, 0, 0, 0, 0, 0);
            }
            break;
    }
}

void VLIB_ERABModify_F1Cause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    int famIdx = GET_FAMIDX(STAT_MENB_INIT_SGNB_MOD_PER_GNB);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);

    if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
    {
        MACRO_STAT_PMCC(STAT_MENB_INIT_SGNB_MOD_PER_GNB, EndcModByMenbFail_DuFail, ptCi, 0, 0, 0, 0, 0);
    }
    else
    {
        MACRO_STAT_PMCC(STAT_MENB_INIT_SGNB_MOD_PER_GNB, EndcModByMenbPrepFail_DuFail, ptCi, 0, 0, 0, 0, 0);
    }
}

void VLIB_ERABModify_E1Cause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    int famIdx = GET_FAMIDX(STAT_MENB_INIT_SGNB_MOD_PER_GNB);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);

    if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
    {
        MACRO_STAT_PMCC(STAT_MENB_INIT_SGNB_MOD_PER_GNB, EndcModByMenbFail_UpFail, ptCi, 0, 0, 0, 0, 0);
    }
    else
    {
        MACRO_STAT_PMCC(STAT_MENB_INIT_SGNB_MOD_PER_GNB, EndcModByMenbPrepFail_UpFail, ptCi, 0, 0, 0, 0, 0);
    }
}

void VLIB_ERABModify_X2Cause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    int famIdx = GET_FAMIDX(STAT_MENB_INIT_SGNB_MOD_PER_GNB);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);

    if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
    {
        MACRO_STAT_PMCC(STAT_MENB_INIT_SGNB_MOD_PER_GNB, EndcModByMenbFail_MenbFail, ptCi, 0, 0, 0, 0, 0);
    }
    else
    {
        MACRO_STAT_PMCC(STAT_MENB_INIT_SGNB_MOD_PER_GNB, EndcModByMenbPrepFail_MenbFail, ptCi, 0, 0, 0, 0, 0);
    }
}

void VLIB_ERABModify_InternalCause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    int famIdx = GET_FAMIDX(STAT_MENB_INIT_SGNB_MOD_PER_GNB);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);

    if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
    {
        MACRO_STAT_PMCC(STAT_MENB_INIT_SGNB_MOD_PER_GNB, EndcModByMenbFail_CpFail, ptCi, 0, 0, 0, 0, 0);
    }
    else
    {
        MACRO_STAT_PMCC(STAT_MENB_INIT_SGNB_MOD_PER_GNB, EndcModByMenbPrepFail_CpFail, ptCi, 0, 0, 0, 0, 0);
    }
}

void VLIB_SNInitSgNBMod_F1Cause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    MACRO_STAT_PMCC(STAT_SGNB_INIT_SGNB_MOD_PER_GNB, EndcModBySgnbFail_DuFail, ptCi, 0, 0, 0, 0, 0);
}

void VLIB_SNInitSgNBMod_E1Cause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    MACRO_STAT_PMCC(STAT_SGNB_INIT_SGNB_MOD_PER_GNB, EndcModBySgnbFail_UpFail, ptCi, 0, 0, 0, 0, 0);
}

void VLIB_SNInitSgNBMod_X2Cause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    MACRO_STAT_PMCC(STAT_SGNB_INIT_SGNB_MOD_PER_GNB, EndcModBySgnbFail_MenbFail, ptCi, 0, 0, 0, 0, 0);
}

void VLIB_SNInitSgNBMod_InternalCause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    MACRO_STAT_PMCC(STAT_SGNB_INIT_SGNB_MOD_PER_GNB, EndcModBySgnbFail_CpFail, ptCi, 0, 0, 0, 0, 0);
}

void VLIB_F1Cause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    switch (ptCi->stateCmd)
    {
        case IntraRatHO_cmd:
            VLIB_IntraRatHO_F1Cause_StatReleaseInd(ptCi);
            break;
        case SgNBAddition_cmd:
            VLIB_SgNBAddition_F1Cause_StatReleaseInd(ptCi);
            break;
        case SNInitSgNBMod_cmd:
        case SgnbInitBearerRelease_cmd:
            VLIB_SNInitSgNBMod_F1Cause_StatReleaseInd(ptCi);
            break;
        default:
            break;
    }

    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        if (CHECK_MOD_EVENT_WITH_STATECMD(ptCi, erabModify))
        {
            VLIB_ERABModify_F1Cause_StatReleaseInd(ptCi);
        }
        VLIB_CollectErabAddModStat(ptCi, ErabAddFail_DuFail, ErabModFail_DuFail, ErabModFail_DuFail_Change);

        if ((SgNBInitBearerChangeToMcg_cmd == ptCi->stateCmd) ||
            (SgNBInitBearerChangeToMcg_cmd == ptCi->prevStateCmd))
        {
            // Increment internal statistic for SN init bearer type change
            VRRM_endcSNinitErabChgCount(ptCi, StatEndcErabModFail_DuFail);
        }
    }
}

void VLIB_E1Cause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    switch (ptCi->stateCmd)
    {
        case IntraRatHO_cmd:
            VLIB_IntraRatHO_E1Cause_StatReleaseInd(ptCi);
            break;
        case SgNBAddition_cmd:
            VLIB_SgNBAddition_E1Cause_StatReleaseInd(ptCi);
            break;
        case SNInitSgNBMod_cmd:
        case SgnbInitBearerRelease_cmd:
            VLIB_SNInitSgNBMod_E1Cause_StatReleaseInd(ptCi);
            break;
        default:
            break;
    }

    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        if (CHECK_MOD_EVENT_WITH_STATECMD(ptCi, erabModify))
        {
            VLIB_ERABModify_E1Cause_StatReleaseInd(ptCi);
        }
        VLIB_CollectErabAddModStat(ptCi, ErabAddFail_UpFail, ErabModFail_UpFail, ErabModFail_UpFail_Change);

        if ((SgNBInitBearerChangeToMcg_cmd == ptCi->stateCmd) ||
            (SgNBInitBearerChangeToMcg_cmd == ptCi->prevStateCmd))
        {
            // Increment internal statistic for SN init bearer type change
            VRRM_endcSNinitErabChgCount(ptCi, StatEndcErabModFail_UpFail);
        }
    }
}

void VLIB_X2Cause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    switch (ptCi->stateCmd)
    {
        case IntraRatHO_cmd:
            VLIB_IntraRatHO_X2Cause_StatReleaseInd(ptCi);
            break;
        case SgNBAddition_cmd:
            VLIB_SgNBAddition_X2Cause_StatReleaseInd(ptCi);
            break;
        case SNInitSgNBMod_cmd:
        case SgnbInitBearerRelease_cmd:
        case SgNBInitBearerChangeToMcg_cmd:
            VLIB_SNInitSgNBMod_X2Cause_StatReleaseInd(ptCi);
            break;
        default:
            break;
    }

    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        if (CHECK_MOD_EVENT_WITH_STATECMD(ptCi, erabModify))
        {
            VLIB_ERABModify_X2Cause_StatReleaseInd(ptCi);
        }
        VLIB_CollectErabAddModStat(ptCi, ErabAddFail_MenbFail, ErabModFail_MenbFail, ErabModFail_MenbFail_Change);

        if ((SgNBInitBearerChangeToMcg_cmd == ptCi->stateCmd) ||
            (SgNBInitBearerChangeToMcg_cmd == ptCi->prevStateCmd))
        {
            // Increment internal statistic for SN init bearer type change
            VRRM_endcSNinitErabChgCount(ptCi, StatEndcErabModFail_MenbFail);
        }
    }
}

void VLIB_NGCause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    // TBD
}

void VLIB_XNCause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    // TBD
}

void VLIB_InternalCause_StatReleaseInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    switch (ptCi->stateCmd)
    {
        case IntraRatHO_cmd:
            VLIB_IntraRatHO_InternalCause_StatReleaseInd(ptCi);
            break;
        case SgNBAddition_cmd:
            VLIB_SgNBAddition_InternalCause_StatReleaseInd(ptCi);
            break;
        case SNInitSgNBMod_cmd:
        case SgnbInitBearerRelease_cmd:
        case SgNBInitBearerChangeToMcg_cmd:
            VLIB_SNInitSgNBMod_InternalCause_StatReleaseInd(ptCi);
            break;
        default:
            break;
    }

    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        if (CHECK_MOD_EVENT_WITH_STATECMD(ptCi, erabModify))
        {
            VLIB_ERABModify_InternalCause_StatReleaseInd(ptCi);
        }
        VLIB_CollectErabAddModStat(ptCi, ErabAddFail_CpFail, ErabModFail_CpFail, ErabModFail_CpFail_Change);

        if ((SgNBInitBearerChangeToMcg_cmd == ptCi->stateCmd) ||
            (SgNBInitBearerChangeToMcg_cmd == ptCi->prevStateCmd))
        {
            // Increment internal statistic for SN init bearer type change
            VRRM_endcSNinitErabChgCount(ptCi, StatEndcErabModFail_CpFail);
        }
    }
}

/**************************************************************
 *  Function     : VLIB_StatReleaseInd
 *  Description  :
 *  Input  : callInfo_type*, uint32_t
 ***************************************************************/
void VLIB_StatReleaseInd(callInfo_type *ptCi, uint32_t cause)
{
    AUTO_TRACE_FUNC;

    if (ptCi == NULL)
    {
        VCCB_PRINT_ERROR("ptCi is NULL in VLIB_StatReleaseInd ERROR!\n");

        return;
    }

    switch (cause)
    {
        case CauseCpInternalF1SctpOutOfService:
        case CAUSE_BASE_F1AP_RADIONETWORK ... CauseF1apMax - 1:
            VLIB_F1Cause_StatReleaseInd(ptCi);
            break;

        case CauseCpInternalE1SctpOutOfService:
        case CAUSE_BASE_E1AP_RADIONETWORK ... CauseE1apMax - 1:
            VLIB_E1Cause_StatReleaseInd(ptCi);
            break;

        case CauseCpInternalNsaX2SctpOutOfService:
        case CAUSE_BASE_X2AP_RADIONETWORK ... CauseX2apMax - 1:
            VLIB_X2Cause_StatReleaseInd(ptCi);
            break;

        case CauseCpInternalSaNgSctpOutOfService:
        case CAUSE_BASE_NGAP_RADIONETWORK ... CauseNgapMax - 1:
            VLIB_NGCause_StatReleaseInd(ptCi);
            break;

        case CauseCpInternalSaXnSctpOutOfService:
        case CAUSE_BASE_XNAP_RADIONETWORK ... CauseXnapMax - 1:
            VLIB_XNCause_StatReleaseInd(ptCi);
            break;

        default:
            VLIB_InternalCause_StatReleaseInd(ptCi);
    }
}

measPciInfo_type *FnVCCB_GetMeasPciInfo(callInfo_type *ptCi, uint8_t idx, enumAnrObjType ratType, bool isStat)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_NULL(ptCi);

    measPciInfo_type *pMeasPciInfo = NULL;

    if (eutraType == ratType)
    {
        VCCB_CHECK_E_RANGE_AND_NULL(idx, MAX_NR_OF_OBJECTEUTRA_ID_DB);

        if (isStat)
            pMeasPciInfo = &ptCi->anrInfo.eutraMeasPciStatInfo[idx];
        else
            pMeasPciInfo = &ptCi->anrInfo.eutraMeasMrCountInfo[idx];
    }
    else
    {
        VCCB_CHECK_E_RANGE_AND_NULL(idx, MAX_NR_OF_OBJECT_ID_DB);

        if (isStat)
            pMeasPciInfo = &ptCi->anrInfo.nrMeasPciStatInfo[idx];
        else
            pMeasPciInfo = &ptCi->anrInfo.nrMeasMrCountInfo[idx];
    }

    return pMeasPciInfo;
}

void FnVCCB_UpdateAnrMeasPciStatMrCnt(callInfo_type *ptCi, uint8_t idx, uint16_t pci, uint32_t arfcn, time_t currTime, enumAnrObjType ratType, bool isStat)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    measPciInfo_type *pMeasPciInfo = FnVCCB_GetMeasPciInfo(ptCi, idx, ratType, isStat);
    VALID_E_POINT_CHECK_VOID(pMeasPciInfo);

    pMeasPciInfo->usage = CI_use;
    pMeasPciInfo->pci = pci;
    pMeasPciInfo->freq = arfcn;
    pMeasPciInfo->collectedTime = currTime;
}

BOOL FnVCCB_CheckAndUpdateMeasPciStat(callInfo_type *ptCi, uint16_t pci, uint32_t arfcn, enumAnrObjType ratType, bool isStat)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, False);

    time_t currTime = time(NULL);  // time(&timer); get cuurent time; smae as: timer = time(NULL)
    uint8_t emptyIdx = MAX_NR_OF_OBJECT_ID_DB;
    uint8_t idx = 0, maxIdx = MAX_NR_OF_OBJECT_ID_DB;
    measPciInfo_type *pMeasPciInfo = NULL;

#ifdef IPC_TEST
    currTime = DBG->diffTime;
#endif

    if (eutraType == ratType) // EUTRA
        emptyIdx = maxIdx = MAX_NR_OF_OBJECTEUTRA_ID_DB;

    for (idx = 0; idx < maxIdx; idx++)
    {
        pMeasPciInfo = FnVCCB_GetMeasPciInfo(ptCi, idx, ratType, isStat);
        VALID_E_POINT_CHECK_RET_VAL(pMeasPciInfo, False);

        // statistic for the same frequency
        if (pMeasPciInfo->usage == CI_use && arfcn == pMeasPciInfo->freq)
        {
#ifdef IPC_TEST
            VCCB_PRINT_LOG_ANR(ptCi, "(ANR) pMeasPciInfo(ratType:%d isStat:%d) : usage(%d) arfcn(%u:%u) pci(%d:%d) time(%u:%u)\n",
                ratType, isStat, pMeasPciInfo->usage, arfcn, pMeasPciInfo->freq, pci, pMeasPciInfo->pci, currTime,
                pMeasPciInfo->collectedTime);
#endif
            if (pci != pMeasPciInfo->pci)
            {
                FnVCCB_UpdateAnrMeasPciStatMrCnt(ptCi, idx, pci, arfcn, currTime, ratType, isStat);
                return True;
            }
            else
            {
                double diffTime = difftime(currTime, pMeasPciInfo->collectedTime);
                if (diffTime > 10.0)  // difftime(end, start)
                {
                    // Update Stat DB
                    FnVCCB_UpdateAnrMeasPciStatMrCnt(ptCi, idx, pci, arfcn, currTime, ratType, isStat);
                    return True;
                }
                // update expired time to current time+10s and do not collect statistics.
                else
                {
                    // If difftime(currTime, collectedTime) < 10, determined as duplicated case
                    pMeasPciInfo->collectedTime = currTime;
                    VCCB_PRINT_LOG_ANR(
                        ptCi, "(ANR) duplicated pci in 10s(isStat:%u/idx:%u/freq:%u/pci:%u) difftime(%lf)\n", isStat, idx, arfcn, pci, diffTime);
                    return False;
                }
            }
        }
        else if (pMeasPciInfo->usage == CI_no_use && maxIdx == emptyIdx)
        {
            // there is no statistics for the same frequency. find empty idx.
            emptyIdx = idx;
        }
    }

    // there is no statistics for the same frequency. Update Stat DB.
    if (maxIdx > emptyIdx)  // if (MAX_NR_OF_OBJECT_ID_DB != emptyIdx) or if (MAX_NR_OF_OBJECTEUTRA_ID_DB != emptyIdx)
    {
        FnVCCB_UpdateAnrMeasPciStatMrCnt(ptCi, emptyIdx, pci, arfcn, currTime, ratType, isStat);
        return True;
    }
    else  // There is no available DB (maxIdx == emptyIdx)
    {
        // Initialize the DB whose collection time is 10s earlier than the current time.
        for (idx = 0; idx < maxIdx; idx++)
        {
            pMeasPciInfo = FnVCCB_GetMeasPciInfo(ptCi, idx, ratType, isStat);
            VALID_E_POINT_CHECK_RET_VAL(pMeasPciInfo, False);

            if (pMeasPciInfo->usage == CI_use)
            {
                if (difftime(currTime, pMeasPciInfo->collectedTime) > 10.0)
                {  // init DB and store empty idx
                    pMeasPciInfo->usage = CI_no_use;
                    if (maxIdx == emptyIdx)
                    {
                        emptyIdx = idx;
                        break;
                    }
                }
            }
        }

        if (maxIdx == emptyIdx)
        {
            // Exceptional Case, Init all DB and record StatInfo to index=0
            for (idx = 0; idx < maxIdx; idx++)
            {
                if (eutraType == ratType) // EUTRA
                {
                    if (isStat)
                        ptCi->anrInfo.eutraMeasPciStatInfo[idx].usage = CI_no_use;
                    else
                        ptCi->anrInfo.eutraMeasMrCountInfo[idx].usage = CI_no_use;
                }
                else
                {
                    if (isStat)
                        ptCi->anrInfo.nrMeasPciStatInfo[idx].usage = CI_no_use;
                    else
                        ptCi->anrInfo.nrMeasMrCountInfo[idx].usage = CI_no_use;
                }
            }

            emptyIdx = 0;
        }

        FnVCCB_UpdateAnrMeasPciStatMrCnt(ptCi, emptyIdx, pci, arfcn, currTime, ratType, isStat);
        return True;
    }
}

// FGS-SF0502 FR746, FR747
uint8_t FnVccb_GetStatNrMeasPciType(bool knownFlag, enumNRMeas_type nrMeasType, uint16_t allowedNcrCnt)
{
    // For STAT_NR_MEAS_PCI_ITEM
    uint8_t eventType = STAT_NR_MEAS_PCI_END;

    switch (nrMeasType)
    {
        case NRMeas_PSCell_Change:
            eventType = (knownFlag) ? NRMeasPCI_Known : NRMeasPCI_Unknown;
            if (knownFlag)
            {
                if (allowedNcrCnt == 0)
                    eventType = NRMeasPCI_Blocked;
                else if (allowedNcrCnt >= 2)
                    eventType = NRMeasPCI_Duplicated;
            }
            break;

        case NRMeas_HO:
            eventType = (knownFlag) ? NRMeasPCI_Known_ForHO : NRMeasPCI_Unknown_ForHO;
            if (knownFlag)
            {
                if (allowedNcrCnt == 0)
                    eventType = NRMeasPCI_Blacklisted_ForHO;
                else if (allowedNcrCnt >= 2)
                    eventType = NRMeasPCI_Duplicated_ForHo;
            }
            break;

        case NRMeas_NRDC_Addition:
            eventType = (knownFlag) ? NRMeasPCI_Known_For_NrDcAddition : NRMeasPCI_Unknown_For_NrDcAddition;
            if (knownFlag)
            {
                if (allowedNcrCnt >= 2)
                    eventType = NRMeasPCI_Duplicated_NrDcAddition;
            }
            break;

        case NRMeas_NRDC_PSCell_Change:
            eventType = (knownFlag) ? NRMeasPCI_Known_For_NrDcPscellChange : NRMeasPCI_Unknown_For_NrDcPscellChange;
            if (knownFlag)
            {
                if (allowedNcrCnt >= 2)
                    eventType = NRMeasPCI_Duplicated_NrDcPscellChange;
            }
            break;

        default:
            break;
    }

    return eventType;
}

/**************************************************************
 *  Function     : VLIB_StatUnKnownPciCount
 *  Description  : This function count the number of known or unknown PCIs. (FGS-SF0502)
 *               : If the same PCI came within the timer active, it is discarded and timer will be restarted.
 *               : FR741 - (19A) A3/A4/A5 PSCell change MR
 *               : FR743 - (21B) A3/A4/A5 Intra-NR Handover MR
 *               : FR744 - (22C2) A4 NR-DC Addition MR, A3/A4/A5 NR-DC PSCell change MR
 *  Input  : callInfo_type *ptCi
 ***************************************************************/
void VLIB_StatUnKnownPciCount(callInfo_type *ptCi, uint16_t pci, bool knownFlag,
        uint32_t arfcn, enumNRMeas_type nrMeasType, int8_t smallCellListIdx, uint16_t allowedNcrCnt) // 25B
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    // FR742 : Check Duplicated
    if (!FnVCCB_CheckAndUpdateMeasPciStat(ptCi, pci, arfcn, nrType, true))
    {
        return;
    }

    if (FnVCCB_IsNrSmallCellPci(ptCi, pci, smallCellListIdx)) // INTRA_NR_ANR_24A
    {
        VCCB_PRINT_LOG_ANR(ptCi,"(ANR) %s Not Collect STAT_NR_MEAS_PCI! SmallCell(%d) Pci(%d)\n",
                __func__, smallCellListIdx, pci);
        return;
    }

    uint8_t eventType = FnVccb_GetStatNrMeasPciType(knownFlag, nrMeasType, allowedNcrCnt);
    if (eventType == STAT_NR_MEAS_PCI_END)
    {
        return;
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "%s knownFlag:%d nrMeasType:%d allowedNcrCnt:%d eventType:%d \n", __func__,
            knownFlag, nrMeasType, allowedNcrCnt, eventType);

    /* Collect NR_MEAS_PCI */
    MACRO_STAT_PMCC(STAT_NR_MEAS_PCI, eventType, ptCi, arfcn, 0, 0, 0, 0);
    return;
}

/**************************************************************
 *  Function     : VLIB_StatEutraUnKnownPciCount
 *  Description  : This function count the number of known or unknown PCIs. (FGS-SF0503)
 *               : If the same PCI came within the timer active, it is discarded and timer will be restarted.
 *               : FR500 - (24B) All Mobility MR
 *  Input  : callInfo_type *ptCi
 ***************************************************************/
void VLIB_StatEutraUnKnownPciCount( callInfo_type *ptCi, uint16_t pci, BOOL knownFlag,
        uint32_t arfcn, uint8_t hoAllowedFlag, int8_t smallCellListIdx, uint16_t allowedNcrCnt)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    // SF0503 FR281, FR500 : Check Duplicated
    // A MR received for "same frequency + PCI" for a certain period of time is not collected by statistics.
    if (!FnVCCB_CheckAndUpdateMeasPciStat(ptCi, pci, arfcn, eutraType, true))
    {
        return;
    }

    // Not collected when Strongest PCI corresponds to Smallcell PCI and NCR addition mode is OFF.
    if (FnVCCB_IsEutraSmallCellPci(ptCi, pci, smallCellListIdx))
    {
        VCCB_PRINT_LOG_ANR(ptCi,"(ANR) %s Not Collect STAT_EUTRA_MEAS_PCI! SmallCell(%d) Pci(%d)\n",
                __func__, smallCellListIdx, pci);
        return;
    }

    /*
     Collects statistics for Strongest PCI.

     1. Unknown PCI : EutraUnknownPciMobilityMr
     2. Known PCI && is-handover-allowed == TRUE : EutraKnownPciMobilityMr
      - If there is more than one PCI, it is collected as EutraKnownPciMobilityMr
        if there is at least one neighbor whose is-handover-allowed is set to true.
     3. Known PCI && is-handover-allowed == FALSE : EutraHoNotAllowedPciMobilityMr
      - If there is more than one PCI, it is collected as EutraHoNotAllowedPciMobilityMr only
        when the is-handover-allowed configuration of all the neighbors is false.
    */
    int mType = STAT_EUTRA_MEAS_PCI_END;
    if (False == knownFlag) // Unknown PCI
    {
        mType = EutraUnknownPciMobilityMr;
    }
    else // Known PCI
    {
        mType = (hoAllowedFlag == VCCB_FLAG_ON) ? EutraKnownPciMobilityMr : EutraHoNotAllowedPciMobilityMr;
        if (mType == EutraKnownPciMobilityMr)
        {
            if (allowedNcrCnt >= 2) // FGS-SF0503 FR501
                mType = EutraHoDuplicatedPciMobilityMr;
        }
    }

    /* Collect NR_MEAS_PCI */
    MACRO_STAT_PMCC(STAT_EUTRA_MEAS_PCI, mType, ptCi, arfcn, 0, 0, 0, 0);
    return;
}


/****************************************************************************
 * @brief           Collect statistics for Release in SCG Failure Handling
 *                  per fail cause
 *
 * @param[in]       ptCi :          call information / callInfo_type
 * @param[in]       ptUnpack :      Unpacked message / msgUnpack_type
 ****************************************************************************/
void VLIB_StatCallFaultPerFailCauseSCGFailure(callInfo_type *ptCi, const msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptUnpack);

    if (ScgFailCauseInfo_UeT310Expired == ptCi->scgFailCauseInfo)
    {
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalNsaT310Expiry);
    }
    else if (ScgFailCauseInfo_UeRandomAccessProblem == ptCi->scgFailCauseInfo)
    {
        if (ptCi->bitFlag.isE1apDddsNotificationENDCReceived == FLAG_OFF)
        {
            MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalNsaRandomAccessProblem);
        }
        else
        {
            MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalNsaRandomAccessProblemAfterInitialAccess);
        }
    }
    else if (ScgFailCauseInfo_UeRlcMaxRetransmission == ptCi->scgFailCauseInfo)
    {
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalNsaRlcMaxNumRetx);
    }
    else if (ScgFailCauseInfo_UeSynchReconfigFailureScg == ptCi->scgFailCauseInfo)
    {
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalNsaSynchReconfigFailureScg);
    }
    else if (ScgFailCauseInfo_UeScgReconfigFailure == ptCi->scgFailCauseInfo)
    {
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalNsaScgReconfigFailure);
    }
    else if (ScgFailCauseInfo_UeSrb3IntegrityFailure == ptCi->scgFailCauseInfo)
    {
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalNsaSrb3IntegrityFailure);
    }
    else if (ScgFailCauseInfo_DuRlcMaxRetransmission == ptCi->scgFailCauseInfo)
    {
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalDuRlcMaxNumRetx);
    }
    else if (ScgFailCauseInfo_DuUlRadioLinkFailureOthers == ptCi->scgFailCauseInfo)
    {
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalDuULRadioLinkFailure);
    }
    else if (ScgFailCauseInfo_MrBasedSuspend == ptCi->scgFailCauseInfo)
    {
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalNsaTmOutResumeForMrBased);
    }
    // TODO: j.cieslar, FGR-BC1202, update causes for the rest of the MACRO_CALL_FAULT_SAVE in the function
    else if (ScgFailCauseInfo_ScgLbtFailureR16 == ptCi->scgFailCauseInfo)
    {
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalNsaT310Expiry);
    }
    else if (ScgFailCauseInfo_BeamFailureRecoveryFailureR16 == ptCi->scgFailCauseInfo)
    {
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalNsaBeamFailureRecoveryFailure);
    }
    else if (ScgFailCauseInfo_T312ExpiryR16 == ptCi->scgFailCauseInfo)
    {
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalNsaT312Expiry);
    }
    else if (ScgFailCauseInfo_BhRlfR16 == ptCi->scgFailCauseInfo)
    {
        MACRO_CALL_FAULT_SAVE(ptUnpack->msgId, CauseCpInternalNsaT310Expiry);
    }

    return;
}

/**
 * @brief        Update counters for mr-based-resync attempt with specific SCG Failure causes
 *
 * @param[in]    ptCi :          call information / callInfo_type
 * @return       void
 */
void VLIB_UpdateCounters_AttemptMrBasedResyncSCGFailure(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_VALID_CELLNUM_VOID(ptCi->servCellNum);

    ptCi->scgFailAttSuccStats.onOff  = VCCB_FLAG_ON;
    ptCi->scgFailAttSuccStats.cellId = (uint16_t)CELLINFO[ptCi->servCellNum].cellIdentity;

    switch (ptCi->scgFailAttSuccStats.cause)
    {
        case ScgFailCauseInfo_UeT310Expired:
            MACRO_STAT_PMCC(STAT_SCG_FAIL_OPER, SCGFailOper_DL_t310Expiry_AtemptMrBasedResync, ptCi, 0, 0, 0, 0, 0);
            break;
        case ScgFailCauseInfo_UeSynchReconfigFailureScg:
            MACRO_STAT_PMCC(
                STAT_SCG_FAIL_OPER, SCGFailOper_DL_syncReconfFailure_AtemptMrBasedResync, ptCi, 0, 0, 0, 0, 0);
            break;
        case ScgFailCauseInfo_UeRandomAccessProblem:
            MACRO_STAT_PMCC(
                STAT_SCG_FAIL_OPER, SCGFailOper_DL_randomAccessProblem_AtemptMrBasedResync, ptCi, 0, 0, 0, 0, 0);
            break;
        case ScgFailCauseInfo_UeRlcMaxRetransmission:
            MACRO_STAT_PMCC(STAT_SCG_FAIL_OPER, SCGFailOper_DL_rlcMaxNumRetx_AtemptMrBasedResync, ptCi, 0, 0, 0, 0, 0);
            break;
        default:
            VCCB_PRINT_ERROR("No right scg Failure cause to update AttemptMrBasedResync stats, Type(%d)\n",
                ptCi->scgFailAttSuccStats.cause);
            break;
    }
    return;
}

/**
 * @brief        Update counters for mr-based-resync success with specific SCG Failure causes
 *
 * @param[in]    ptCi :          call information / callInfo_type
 * @return       void
 */
void VLIB_UpdateCounters_SuccessMrBasedResyncSCGFailure(callInfo_type *ptCi, uint8_t newScgFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    // Is attempt statistic pegged?
    if (VCCB_FLAG_OFF == ptCi->scgFailAttSuccStats.onOff)
    {
        VCCB_PRINT_COMMENT("SuccessMrBasedResyncSCGFailure: skipping, scgFailureMrBasedResyncFlag is off.\n");
        ptCi->scgFailAttSuccStats.cause = ScgFailCauseInfo_NoScgFailure;
        return;
    }
    // Do not peg success during first SCG fail processing.
    if (VCCB_FLAG_ON == ptCi->scgFailureFlag)
    {
        VCCB_PRINT_COMMENT("SuccessMrBasedResyncSCGFailure: skipping, scgFailureFlag is on.\n");
        return;
    }
    // Do not peg success if second SCG fail cause is synchReconfigFailure.
    if ((TRUE == newScgFlag) && (NRRRC_synchReconfigFailure_SCG == ptCi->cgConfigInfo.scgFailureInfo.failureType))
    {
        VCCB_PRINT_COMMENT("SuccessMrBasedResyncSCGFailure: resetting, second SCG fail is synchReconfigFailure.\n");
        VLIB_ResetScgFailAttSuccStats(ptCi);
        return;
    }

    switch (ptCi->scgFailAttSuccStats.cause)
    {
        case ScgFailCauseInfo_UeT310Expired:
            MACRO_STAT_PMCC(STAT_SCG_FAIL_OPER, SCGFailOper_DL_t310Expiry_SuccessMrBasedResync, ptCi, 1, 0, 0, 0, 0);
            break;
        case ScgFailCauseInfo_UeSynchReconfigFailureScg:
            MACRO_STAT_PMCC(
                STAT_SCG_FAIL_OPER, SCGFailOper_DL_syncReconfFailure_SuccessMrBasedResync, ptCi, 1, 0, 0, 0, 0);
            break;
        case ScgFailCauseInfo_UeRandomAccessProblem:
            MACRO_STAT_PMCC(
                STAT_SCG_FAIL_OPER, SCGFailOper_DL_randomAccessProblem_SuccessMrBasedResync, ptCi, 1, 0, 0, 0, 0);
            break;
        case ScgFailCauseInfo_UeRlcMaxRetransmission:
            MACRO_STAT_PMCC(STAT_SCG_FAIL_OPER, SCGFailOper_DL_rlcMaxNumRetx_SuccessMrBasedResync, ptCi, 1, 0, 0, 0, 0);
            break;
        default:
            VCCB_PRINT_ERROR("No right scg Failure cause to update SuccessMrBasedResync stats, Type(%d)\n",
                ptCi->scgFailAttSuccStats.cause);
            break;
    }

    VLIB_ResetScgFailAttSuccStats(ptCi);
}

/**
 * @brief     Generic function to stat ENDC Addition
 * @param     ptCi : callInfo
 * @param     type : stat type
 * @param     fnName : caller function name
 */
void VLIB_StatEndcAdd(callInfo_type *ptCi, enumStatEndcAddType type, const char *fnName)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(type, STAT_ENDC_ADD_MAX);

    static const uint8_t localType2EndcAdd[STAT_ENDC_ADD_MAX] = {EndcAddAtt, EndcAddPrepSucc, EndcAddSucc,
        EndcAddPrepFail_UpTimeout, EndcAddPrepFail_DuTimeout, EndcAddPrepFail_MenbFail, EndcAddPrepFail_CpFail,
        EndcAddPrepFail_UpFail, EndcAddPrepFail_DuFail, EndcAddFail_Tdcoverall, EndcAddFail_MenbFail,
        EndcAddFail_CpFail, EndcAddFail_UpFail, EndcAddFail_DuFail};

    static const uint8_t localType2EndcAddSgnbChg[STAT_ENDC_ADD_MAX] = {EndcAddSgnbChgAtt, EndcAddSgnbChgPrepSucc,
        EndcAddSgnbChgSucc, EndcAddSgnbChgPrepFail_UpTimeout, EndcAddSgnbChgPrepFail_DuTimeout,
        EndcAddSgnbChgPrepFail_MenbFail, EndcAddSgnbChgPrepFail_CpFail, EndcAddSgnbChgPrepFail_UpFail,
        EndcAddSgnbChgPrepFail_DuFail, EndcAddSgnbChgFail_Tdcoverall, EndcAddSgnbChgFail_MenbFail,
        EndcAddSgnbChgFail_CpFail, EndcAddSgnbChgFail_UpFail, EndcAddSgnbChgFail_DuFail};

    static const uint8_t localType2EndcAddMnHoInterEnb[STAT_ENDC_ADD_MAX] = {EndcAddMnHoInterEnbAtt,
        EndcAddMnHoInterEnbPrepSucc, EndcAddMnHoInterEnbHoSucc, EndcAddMnHoInterEnbPrepFail_UpTimeout,
        EndcAddMnHoInterEnbPrepFail_DuTimeout, EndcAddMnHoInterEnbPrepFail_MenbFail, EndcAddMnHoInterEnbPrepFail_CpFail,
        EndcAddMnHoInterEnbPrepFail_UpFail, EndcAddMnHoInterEnbPrepFail_DuFail, EndcAddMnHoInterEnbFail_Tdcoverall,
        EndcAddMnHoInterEnbFail_MenbFail, EndcAddMnHoInterEnbFail_CpFail, EndcAddMnHoInterEnbFail_UpFail,
        EndcAddMnHoInterEnbFail_DuFail};

    static const uint8_t localType2EndcAddMnHoIntraEnb[STAT_ENDC_ADD_MAX] = {EndcAddMnHoIntraEnbAtt,
        EndcAddMnHoIntraEnbPrepSucc, EndcAddMnHoIntraEnbSucc, EndcAddMnHoIntraEnbPrepFail_UpTimeout,
        EndcAddMnHoIntraEnbPrepFail_DuTimeout, EndcAddMnHoIntraEnbPrepFail_MenbFail, EndcAddMnHoIntraEnbPrepFail_CpFail,
        EndcAddMnHoIntraEnbPrepFail_UpFail, EndcAddMnHoIntraEnbPrepFail_DuFail, EndcAddMnHoIntraEnbFail_Tdcoverall,
        EndcAddMnHoIntraEnbFail_MenbFail, EndcAddMnHoIntraEnbFail_CpFail, EndcAddMnHoIntraEnbFail_UpFail,
        EndcAddMnHoIntraEnbFail_DuFail};

    if (MAX_CELL_NUM_VCCB > ptCi->servCellNum)
    {
        switch (ptCi->hoInfo.sgnbAddTrigInd)
        {
            case SgnbAddTrigInd_SnChange:
                VLIB_LibStatPmCC(STAT_SGNB_ADD_SGNB_CHG, localType2EndcAddSgnbChg[type], ptCi, 0, 0, 0, 0, 0, fnName);
                if ((TRUE == FOO.VF_MultipleOperatorRanSupport) && (TRUE == FOO.VF_SPIDBasedStatistics_ENDC))
                {
                    // FGR-CC5001 FR823
                    VLIB_LibStatPmCC(STAT_SGNB_ADD_SGNB_CHG_GLOBAL_ID_SPID, localType2EndcAddSgnbChg[type], ptCi, 0, 0, 0, 0, 0, fnName);
                }
                break;

            case SgnbAddTrigInd_InterMnHo:
                VLIB_LibStatPmCC(
                    STAT_SGNB_ADD_MNHO_INTER_ENB, localType2EndcAddMnHoInterEnb[type], ptCi, 0, 0, 0, 0, 0, fnName);
                if ((TRUE == FOO.VF_MultipleOperatorRanSupport) && (TRUE == FOO.VF_SPIDBasedStatistics_ENDC))
                {
                    // FGR-CC5001 FR821
                    VLIB_LibStatPmCC(
                        STAT_SGNB_ADD_MNHO_INTER_ENB_GLOBAL_ID_SPID, localType2EndcAddMnHoInterEnb[type], ptCi, 0, 0, 0, 0, 0, fnName);
                }
                break;

            case SgnbAddTrigInd_IntraMnHo:
                VLIB_LibStatPmCC(
                    STAT_SGNB_ADD_MNHO_INTRA_ENB, localType2EndcAddMnHoIntraEnb[type], ptCi, 0, 0, 0, 0, 0, fnName);
                if ((TRUE == FOO.VF_MultipleOperatorRanSupport) && (TRUE == FOO.VF_SPIDBasedStatistics_ENDC))
                {
                    // FGR-CC5001 FR822
                    VLIB_LibStatPmCC(
                    STAT_SGNB_ADD_MNHO_INTRA_ENB_GLOBAL_ID_SPID, localType2EndcAddMnHoIntraEnb[type], ptCi, 0, 0, 0, 0, 0, fnName);
                }
                break;

            default:
                VLIB_LibStatPmCC(STAT_SGNB_ADD_PER_GNB, localType2EndcAdd[type], ptCi, 0, 0, 0, 0, 0, fnName);
                if (localType2EndcAdd[type] == EndcAddSucc)
                {
                    VLIB_SetNoAttemptFlag(ptCi, STAT_SGNB_ADD_PER_GNB);
                }
                break;
        }
    }
    else
    {
        VLIB_LibStatPmCC(STAT_SGNB_ADD_PER_GNB, localType2EndcAdd[type], ptCi, 0, 0, 0, 0, 0, fnName);
        if (localType2EndcAdd[type] == EndcAddSucc)
        {
            VLIB_SetNoAttemptFlag(ptCi, STAT_SGNB_ADD_PER_GNB);
        }
    }

    return;
}

/**
 * @brief     This is a function to change to a type for Handover Preparation. (For MN/gNB)
 * @param     type : stat type
 */
void FnVCCB_ChangeTypeForHandoverPreparation_MN(enumHoStatType *pType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pType);

    switch (*pType)
    {
        case HO_Fail_E1TimeOut:
            *pType = HO_PrepFail_E1TimeOut;
            break;

        case HO_Fail_F1TimeOut:
            *pType = HO_PrepFail_F1TimeOut;
            break;

        case HO_Fail_XnTimeOut:
            *pType = HO_PrepFail_XnTimeOut;
            break;

        case HO_Fail_NgTimeOut:
            *pType = HO_PrepFail_NgTimeOut;
            break;

        case HO_Fail_CpFail:
            *pType = HO_PrepFail_CpFail;
            break;

        case HO_Fail_E1Fail:
            *pType = HO_PrepFail_E1Fail;
            break;

        case HO_Fail_F1Fail:
            *pType = HO_PrepFail_F1Fail;
            break;

        case HO_Fail_NgFail:
            *pType = HO_PrepFail_NgFail;
            break;

        case HO_Fail_XnFail:
            *pType = HO_PrepFail_XnFail;
            break;

        default:
            // no action
            break;
    }
}

/**
 * @brief     This is a function to change to a type for Handover Preparation. (For SN)
 * @param     type : stat type
 */
void FnVCCB_ChangeTypeForHandoverPreparation_SN(int *pType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pType);

    switch (*pType)
    {
        case NRDC_SN_HOFail_UpFail:
            *pType = NRDC_SN_HOPrepFail_UpFail;
            break;

        case NRDC_SN_HOFail_DuFail:
            *pType = NRDC_SN_HOPrepFail_DuFail;
            break;

        case NRDC_SN_HOFail_CpFail:
            *pType = NRDC_SN_HOPrepFail_CpFail;
            break;

        case NRDC_SN_HOFail_XnFail:
            *pType = NRDC_SN_HOPrepFail_XnFail;
            break;

        default:
            // no action
            break;
    }
}

/**
 * @brief     Generic function to stat NEDC Addition
 * @param     ptCi : callInfo
 * @param     type : stat type
 * @param     fnName : caller function name
 */
void VLIB_StatNedcAdd(callInfo_type *ptCi, enumStatNedcAddType type)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(type, STAT_NEDC_ADD_MAX);

    if (!IS_NEDC_MN(ptCi))
    {
        return;
    }

    static const int8_t localType2NedcAdd[STAT_NEDC_ADD_MAX] = {NedcAddAtt, NedcAddPrepSucc, NedcAddSucc,
        NedcAddPrepFail_UpTimeout, NedcAddPrepFail_DuTimeout, NedcAddPrepFail_SenbFail, NedcAddPrepFail_CpFail,
        NedcAddPrepFail_UpFail, NedcAddPrepFail_DuFail, NedcAddPrepFail_TXndcprep, NedcAddFail_SenbFail,
        NedcAddFail_CpFail, NedcAddFail_UpFail, NedcAddFail_DuFail};

    static const int8_t localType2NedcDrbSetup[STAT_NEDC_ADD_MAX] = {NedcDrbSetupAtt, -1, NedcDrbSetupSucc,
        NedcDrbSetupFail_UpTimeout, NedcDrbSetupFail_DuTimeout, -1, -1, -1, -1, NedcDrbSetupFail_TXndcprep,
        NedcDrbSetupFail_SenbFail, NedcDrbSetupFail_CpFail, NedcDrbSetupFail_UpFail, NedcDrbSetupFail_DuFail};

    MACRO_STAT_PMCC(STAT_NEDC_ADD, localType2NedcAdd[type], ptCi, 0, 0, 0, 0, 0);
    if (-1 != localType2NedcDrbSetup[type])
    {
        int drbIdxInCall = 0;
        for (drbIdxInCall = 0; drbIdxInCall < MAX_DRB_PER_SA_CALL; drbIdxInCall++)
        {
            if (ptCi->drb[drbIdxInCall].usage == CI_no_use) continue;
            if ((localType2NedcDrbSetup[type] == NedcDrbSetupAtt &&
                    ptCi->drb[drbIdxInCall].bearerType.val == MN_Term_MCG_Bearer &&
                    ptCi->drb[drbIdxInCall].reqBearerType.val == MN_Term_SPLIT_Bearer &&
                    ptCi->drb[drbIdxInCall].selectedBearerType.val == MN_Term_SPLIT_Bearer) ||
                (localType2NedcDrbSetup[type] >= NedcDrbSetupSucc))
            {
                MACRO_STAT_PMCC_DRB(
                    STAT_NEDC_DRB_SETUP, localType2NedcDrbSetup[type], ptCi, &ptCi->drb[drbIdxInCall], 0, 0, 0, 0);
            }
        }
    }

    if (localType2NedcAdd[type] >= NedcAddSucc)
    {
        int famIdx = GET_FAMIDX(STAT_NEDC_ADD);
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);

        if (GET_CALL_STAT_FLAG(ptCi, famIdx) >= SUCCESS_FAIL_DECISION_MADE)
        {
            VLIB_SetNoAttemptFlag(ptCi, STAT_NEDC_ADD);
            VLIB_SetNoAttemptFlag(ptCi, STAT_NEDC_DRB_SETUP);
        }
    }

    return;
}

/**
 * @brief     This is a function to change to a type for SN Addition Preparation. (For MN/gNB)
 * @param     type : stat type
 */
void FnVCCB_ChangeTypeForSNAdditionPreparation(int *pType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pType);

    switch (*pType)
    {
        case MRDC_SnAdd_Fail_XnFail:
            *pType = MRDC_SnAdd_PrepFail_XnFail;
            break;
        case MRDC_SnAdd_Fail_CpFail:
            *pType = MRDC_SnAdd_PrepFail_CpFail;
            break;
        case MRDC_SnAdd_Fail_UpFail:
            *pType = MRDC_SnAdd_PrepFail_UpFail;
            break;
        case MRDC_SnAdd_Fail_DuFail:
            *pType = MRDC_SnAdd_PrepFail_DuFail;
            break;
        default:
            // no action
            break;
    }
}

int FnVCCB_getMrdcSnAddStatFamily(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    int familyType = -1;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, familyType);

    // Addition case (not supported yet)
    if (IS_NEDC_MN(ptCi))
    {
        return familyType;
    }

    // Addition case
    if (IS_NRDC_SN(ptCi))
    {
        return STAT_NRDC_SN_ADD_SN_WITH_INVALID_CELL;
    }

    return STAT_NRDC_SN_ADD_MN;
}

int FnVCCB_getMrdcSnAddStatType(callInfo_type *ptCi, int type)
{
    AUTO_TRACE_FUNC;

    int pmType = -1;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, pmType);

    unsigned int keyType = 0;

    if (type < 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Unknown Type Value(%d) in FnVCCB_getMrdcSnAddStatType\n", type);
        return -1;
    }

    keyType = (unsigned)type;

    const int NrdcAddMn_mapping[MRDC_SNADD_TYPE_MAX] = {
        NrdcAddMn_Att,               /* MRDC_SnAdd_Att */
        NrdcAddMn_PrepSucc,          /* MRDC_SnAdd_PrepSucc */
        NrdcAddMn_Succ,              /* MRDC_SnAdd_Succ */
        NrdcAddMn_PrepFail_SgnbFail, /* MRDC_SnAdd_PrepFail_XnFail */
        NrdcAddMn_PrepFail_CpFail,   /* MRDC_SnAdd_PrepFail_CpFail */
        -1,                          /* MRDC_SnAdd_PrepFail_UpFail */
        -1,                          /* MRDC_SnAdd_PrepFail_DuFail */
        NrdcAddMn_Fail_SgnbFail,     /* MRDC_SnAdd_Fail_XnFail */
        NrdcAddMn_Fail_CpFail,       /* MRDC_SnAdd_Fail_CpFail */
        NrdcAddMn_Fail_UpFail,       /* MRDC_SnAdd_Fail_UpFail */
        NrdcAddMn_Fail_DuFail,       /* MRDC_SnAdd_Fail_DuFail */
        NrdcAddMn_Fail_RrcFail       /* MRDC_SnAdd_Fail_RrcFail */
    };

    const int NrdcAddSn_mapping[MRDC_SNADD_TYPE_MAX] = {
        NrdcAddSn_Att,               /* MRDC_SnAdd_Att */
        NrdcAddSn_PrepSucc,          /* MRDC_SnAdd_PrepSucc */
        NrdcAddSn_Succ,              /* MRDC_SnAdd_Succ */
        NrdcAddSn_PrepFail_MgnbFail, /* MRDC_SnAdd_PrepFail_XnFail */
        NrdcAddSn_PrepFail_CpFail,   /* MRDC_SnAdd_PrepFail_CpFail */
        NrdcAddSn_PrepFail_UpFail,   /* MRDC_SnAdd_PrepFail_UpFail */
        NrdcAddSn_PrepFail_DuFail,   /* MRDC_SnAdd_PrepFail_DuFail */
        NrdcAddSn_Fail_MgnbFail,     /* MRDC_SnAdd_Fail_XnFail */
        NrdcAddSn_Fail_CpFail,       /* MRDC_SnAdd_Fail_CpFail */
        NrdcAddSn_Fail_UpFail,       /* MRDC_SnAdd_Fail_UpFail */
        NrdcAddSn_Fail_DuFail,       /* MRDC_SnAdd_Fail_DuFail */
        -1,                          /* MRDC_SnAdd_Fail_RrcFail */
    };

    const int NrdcAddMn_IntraMnMobilityWithSgnbChg_mapping[MRDC_SNADD_TYPE_MAX] = {
        NrdcAddMn_IntraMnMobilityWithSgnbChg_Att,               /* MRDC_SnAdd_Att */
        NrdcAddMn_IntraMnMobilityWithSgnbChg_PrepSucc,          /* MRDC_SnAdd_PrepSucc */
        NrdcAddMn_IntraMnMobilityWithSgnbChg_Succ,              /* MRDC_SnAdd_Succ */
        NrdcAddMn_IntraMnMobilityWithSgnbChg_PrepFail_SgnbFail, /* MRDC_SnAdd_PrepFail_XnFail */
        NrdcAddMn_IntraMnMobilityWithSgnbChg_PrepFail_CpFail,   /* MRDC_SnAdd_PrepFail_CpFail */
        -1,                                                     /* MRDC_SnAdd_PrepFail_UpFail */
        -1,                                                     /* MRDC_SnAdd_PrepFail_DuFail */
        NrdcAddMn_IntraMnMobilityWithSgnbChg_Fail_SgnbFail,     /* MRDC_SnAdd_Fail_XnFail */
        NrdcAddMn_IntraMnMobilityWithSgnbChg_Fail_CpFail,       /* MRDC_SnAdd_Fail_CpFail */
        NrdcAddMn_IntraMnMobilityWithSgnbChg_Fail_UpFail,       /* MRDC_SnAdd_Fail_UpFail */
        NrdcAddMn_IntraMnMobilityWithSgnbChg_Fail_DuFail,       /* MRDC_SnAdd_Fail_DuFail */
        NrdcAddMn_IntraMnMobilityWithSgnbChg_Fail_RrcFail       /* MRDC_SnAdd_Fail_RrcFail */
    };

    const int NrdcAddSn_IntraMnMobilityWithSgnbChange_mapping[MRDC_SNADD_TYPE_MAX] = {
        NrdcAddSn_IntraMnMobilityWithSgnbChange_Att,               /* MRDC_SnAdd_Att */
        NrdcAddSn_IntraMnMobilityWithSgnbChange_PrepSucc,          /* MRDC_SnAdd_PrepSucc */
        NrdcAddSn_IntraMnMobilityWithSgnbChange_Succ,              /* MRDC_SnAdd_Succ */
        NrdcAddSn_IntraMnMobilityWithSgnbChange_PrepFail_MgnbFail, /* MRDC_SnAdd_PrepFail_XnFail */
        NrdcAddSn_IntraMnMobilityWithSgnbChange_PrepFail_CpFail,   /* MRDC_SnAdd_PrepFail_CpFail */
        NrdcAddSn_IntraMnMobilityWithSgnbChange_PrepFail_UpFail,   /* MRDC_SnAdd_PrepFail_UpFail */
        NrdcAddSn_IntraMnMobilityWithSgnbChange_PrepFail_DuFail,   /* MRDC_SnAdd_PrepFail_DuFail */
        NrdcAddSn_IntraMnMobilityWithSgnbChange_Fail_MgnbFail,     /* MRDC_SnAdd_Fail_XnFail */
        NrdcAddSn_IntraMnMobilityWithSgnbChange_Fail_CpFail,       /* MRDC_SnAdd_Fail_CpFail */
        NrdcAddSn_IntraMnMobilityWithSgnbChange_Fail_UpFail,       /* MRDC_SnAdd_Fail_UpFail */
        NrdcAddSn_IntraMnMobilityWithSgnbChange_Fail_DuFail,       /* MRDC_SnAdd_Fail_DuFail */
        -1,                                                        /* MRDC_SnAdd_Fail_RrcFail */
    };

    const int NrdcAddMn_InterMnMobilityWithSgnbChg_mapping[MRDC_SNADD_TYPE_MAX] = {
        NrdcAddMn_InterMnMobilityWithSgnbChg_Att,               /* MRDC_SnAdd_Att */
        NrdcAddMn_InterMnMobilityWithSgnbChg_PrepSucc,          /* MRDC_SnAdd_PrepSucc */
        NrdcAddMn_InterMnMobilityWithSgnbChg_Succ,              /* MRDC_SnAdd_Succ */
        NrdcAddMn_InterMnMobilityWithSgnbChg_PrepFail_SgnbFail, /* MRDC_SnAdd_PrepFail_XnFail */
        NrdcAddMn_InterMnMobilityWithSgnbChg_PrepFail_CpFail,   /* MRDC_SnAdd_PrepFail_CpFail */
        -1,                                                     /* MRDC_SnAdd_PrepFail_UpFail */
        -1,                                                     /* MRDC_SnAdd_PrepFail_DuFail */
        NrdcAddMn_InterMnMobilityWithSgnbChg_Fail_SgnbFail,     /* MRDC_SnAdd_Fail_XnFail */
        NrdcAddMn_InterMnMobilityWithSgnbChg_Fail_CpFail,       /* MRDC_SnAdd_Fail_CpFail */
        NrdcAddMn_InterMnMobilityWithSgnbChg_Fail_UpFail,       /* MRDC_SnAdd_Fail_UpFail */
        NrdcAddMn_InterMnMobilityWithSgnbChg_Fail_DuFail,       /* MRDC_SnAdd_Fail_DuFail */
        NrdcAddMn_InterMnMobilityWithSgnbChg_Fail_RrcFail       /* MRDC_SnAdd_Fail_RrcFail */
    };

    const int NrdcAddSn_InterMnMobilityWithSgnbChange_mapping[MRDC_SNADD_TYPE_MAX] = {
        NrdcAddSn_InterMnMobilityWithSgnbChange_Att,               /* MRDC_SnAdd_Att */
        NrdcAddSn_InterMnMobilityWithSgnbChange_PrepSucc,          /* MRDC_SnAdd_PrepSucc */
        NrdcAddSn_InterMnMobilityWithSgnbChange_Succ,              /* MRDC_SnAdd_Succ */
        NrdcAddSn_InterMnMobilityWithSgnbChange_PrepFail_MgnbFail, /* MRDC_SnAdd_PrepFail_XnFail */
        NrdcAddSn_InterMnMobilityWithSgnbChange_PrepFail_CpFail,   /* MRDC_SnAdd_PrepFail_CpFail */
        NrdcAddSn_InterMnMobilityWithSgnbChange_PrepFail_UpFail,   /* MRDC_SnAdd_PrepFail_UpFail */
        NrdcAddSn_InterMnMobilityWithSgnbChange_PrepFail_DuFail,   /* MRDC_SnAdd_PrepFail_DuFail */
        NrdcAddSn_InterMnMobilityWithSgnbChange_Fail_MgnbFail,     /* MRDC_SnAdd_Fail_XnFail */
        NrdcAddSn_InterMnMobilityWithSgnbChange_Fail_CpFail,       /* MRDC_SnAdd_Fail_CpFail */
        NrdcAddSn_InterMnMobilityWithSgnbChange_Fail_UpFail,       /* MRDC_SnAdd_Fail_UpFail */
        NrdcAddSn_InterMnMobilityWithSgnbChange_Fail_DuFail,       /* MRDC_SnAdd_Fail_DuFail */
        -1,                                                        /* MRDC_SnAdd_Fail_RrcFail */
    };

    const int NrdcAddMn_InterMnMobilityWithoutSgnbChg_mapping[MRDC_SNADD_TYPE_MAX] = {
        NrdcAddMn_InterMnMobilityWithoutSgnbChg_Att,               /* MRDC_SnAdd_Att */
        NrdcAddMn_InterMnMobilityWithoutSgnbChg_PrepSucc,          /* MRDC_SnAdd_PrepSucc */
        NrdcAddMn_InterMnMobilityWithoutSgnbChg_Succ,              /* MRDC_SnAdd_Succ */
        NrdcAddMn_InterMnMobilityWithoutSgnbChg_PrepFail_SgnbFail, /* MRDC_SnAdd_PrepFail_XnFail */
        NrdcAddMn_InterMnMobilityWithoutSgnbChg_PrepFail_CpFail,   /* MRDC_SnAdd_PrepFail_CpFail */
        -1,                                                        /* MRDC_SnAdd_PrepFail_UpFail */
        -1,                                                        /* MRDC_SnAdd_PrepFail_DuFail */
        NrdcAddMn_InterMnMobilityWithoutSgnbChg_Fail_SgnbFail,     /* MRDC_SnAdd_Fail_XnFail */
        NrdcAddMn_InterMnMobilityWithoutSgnbChg_Fail_CpFail,       /* MRDC_SnAdd_Fail_CpFail */
        NrdcAddMn_InterMnMobilityWithoutSgnbChg_Fail_UpFail,       /* MRDC_SnAdd_Fail_UpFail */
        NrdcAddMn_InterMnMobilityWithoutSgnbChg_Fail_DuFail,       /* MRDC_SnAdd_Fail_DuFail */
        NrdcAddMn_InterMnMobilityWithoutSgnbChg_Fail_RrcFail       /* MRDC_SnAdd_Fail_RrcFail */
    };

    const int NrdcAddSn_InterMnMobilityWithoutSgnbChange_mapping[MRDC_SNADD_TYPE_MAX] = {
        NrdcAddSn_InterMnMobilityWithoutSgnbChange_Att,               /* MRDC_SnAdd_Att */
        NrdcAddSn_InterMnMobilityWithoutSgnbChange_PrepSucc,          /* MRDC_SnAdd_PrepSucc */
        NrdcAddSn_InterMnMobilityWithoutSgnbChange_Succ,              /* MRDC_SnAdd_Succ */
        NrdcAddSn_InterMnMobilityWithoutSgnbChange_PrepFail_MgnbFail, /* MRDC_SnAdd_PrepFail_XnFail */
        NrdcAddSn_InterMnMobilityWithoutSgnbChange_PrepFail_CpFail,   /* MRDC_SnAdd_PrepFail_CpFail */
        NrdcAddSn_InterMnMobilityWithoutSgnbChange_PrepFail_UpFail,   /* MRDC_SnAdd_PrepFail_UpFail */
        NrdcAddSn_InterMnMobilityWithoutSgnbChange_PrepFail_DuFail,   /* MRDC_SnAdd_PrepFail_DuFail */
        NrdcAddSn_InterMnMobilityWithoutSgnbChange_Fail_MgnbFail,     /* MRDC_SnAdd_Fail_XnFail */
        NrdcAddSn_InterMnMobilityWithoutSgnbChange_Fail_CpFail,       /* MRDC_SnAdd_Fail_CpFail */
        NrdcAddSn_InterMnMobilityWithoutSgnbChange_Fail_UpFail,       /* MRDC_SnAdd_Fail_UpFail */
        NrdcAddSn_InterMnMobilityWithoutSgnbChange_Fail_DuFail,       /* MRDC_SnAdd_Fail_DuFail */
        -1,                                                           /* MRDC_SnAdd_Fail_RrcFail */
    };

    const int NrdcAddMn_SnChange_mapping[MRDC_SNADD_TYPE_MAX] = {
        NrdcAddMn_SnChange_Att,               /* MRDC_SnAdd_Att */
        NrdcAddMn_SnChange_PrepSucc,          /* MRDC_SnAdd_PrepSucc */
        NrdcAddMn_SnChange_Succ,              /* MRDC_SnAdd_Succ */
        NrdcAddMn_SnChange_PrepFail_SgnbFail, /* MRDC_SnAdd_PrepFail_XnFail */
        NrdcAddMn_SnChange_PrepFail_CpFail,   /* MRDC_SnAdd_PrepFail_CpFail */
        -1,                                   /* MRDC_SnAdd_PrepFail_UpFail */
        -1,                                   /* MRDC_SnAdd_PrepFail_DuFail */
        NrdcAddMn_SnChange_Fail_SgnbFail,     /* MRDC_SnAdd_Fail_XnFail */
        NrdcAddMn_SnChange_Fail_CpFail,       /* MRDC_SnAdd_Fail_CpFail */
        NrdcAddMn_SnChange_Fail_UpFail,       /* MRDC_SnAdd_Fail_UpFail */
        NrdcAddMn_SnChange_Fail_DuFail,       /* MRDC_SnAdd_Fail_DuFail */
        NrdcAddMn_SnChange_Fail_RrcFail       /* MRDC_SnAdd_Fail_RrcFail */
    };

    const int NrdcAddSn_SnChange_mapping[MRDC_SNADD_TYPE_MAX] = {
        NrdcAddSn_SnChange_Att,               /* MRDC_SnAdd_Att */
        NrdcAddSn_SnChange_PrepSucc,          /* MRDC_SnAdd_PrepSucc */
        NrdcAddSn_SnChange_Succ,              /* MRDC_SnAdd_Succ */
        NrdcAddSn_SnChange_PrepFail_MgnbFail, /* MRDC_SnAdd_PrepFail_XnFail */
        NrdcAddSn_SnChange_PrepFail_CpFail,   /* MRDC_SnAdd_PrepFail_CpFail */
        NrdcAddSn_SnChange_PrepFail_UpFail,   /* MRDC_SnAdd_PrepFail_UpFail */
        NrdcAddSn_SnChange_PrepFail_DuFail,   /* MRDC_SnAdd_PrepFail_DuFail */
        NrdcAddSn_SnChange_Fail_MgnbFail,     /* MRDC_SnAdd_Fail_XnFail */
        NrdcAddSn_SnChange_Fail_CpFail,       /* MRDC_SnAdd_Fail_CpFail */
        NrdcAddSn_SnChange_Fail_UpFail,       /* MRDC_SnAdd_Fail_UpFail */
        NrdcAddSn_SnChange_Fail_DuFail,       /* MRDC_SnAdd_Fail_DuFail */
        -1,                                   /* MRDC_SnAdd_Fail_RrcFail */
    };

    if (FnVCCB_isMnInitMobility(ptCi))
    {
        if (FnVCCB_isIntraSnMobility(ptCi))
        {
            // TODO: need to add the condition(Inter MN without SN Change)
            if (IS_NRDC_SN(ptCi))
            {
                VCCB_CHECK_E_RANGE_AND_VAL(
                    keyType, GET_ARR_SIZE(NrdcAddSn_InterMnMobilityWithoutSgnbChange_mapping), -1);
            }
            else
            {
                VCCB_CHECK_E_RANGE_AND_VAL(keyType, GET_ARR_SIZE(NrdcAddMn_InterMnMobilityWithoutSgnbChg_mapping), -1);
            }

            return IS_NRDC_SN(ptCi) ? NrdcAddSn_InterMnMobilityWithoutSgnbChange_mapping[keyType]
                                    : NrdcAddMn_InterMnMobilityWithoutSgnbChg_mapping[keyType];
        }

        // TODO: need to add the condition(Intra MN Inter SN Change)
        if (FnVCCB_isInterMnInitMobility(ptCi))
        {
            if (IS_NRDC_SN(ptCi))
            {
                VCCB_CHECK_E_RANGE_AND_VAL(keyType, GET_ARR_SIZE(NrdcAddSn_InterMnMobilityWithSgnbChange_mapping), -1);
            }
            else
            {
                VCCB_CHECK_E_RANGE_AND_VAL(keyType, GET_ARR_SIZE(NrdcAddMn_InterMnMobilityWithSgnbChg_mapping), -1);
            }

            return IS_NRDC_SN(ptCi) ? NrdcAddSn_InterMnMobilityWithSgnbChange_mapping[keyType]
                                    : NrdcAddMn_InterMnMobilityWithSgnbChg_mapping[keyType];
        }

        // TODO: need to add the condition(Inter MN Inter SN Change)
        {
            if (IS_NRDC_SN(ptCi))
            {
                VCCB_CHECK_E_RANGE_AND_VAL(keyType, GET_ARR_SIZE(NrdcAddSn_IntraMnMobilityWithSgnbChange_mapping), -1);
            }
            else
            {
                VCCB_CHECK_E_RANGE_AND_VAL(keyType, GET_ARR_SIZE(NrdcAddMn_IntraMnMobilityWithSgnbChg_mapping), -1);
            }

            return IS_NRDC_SN(ptCi) ? NrdcAddSn_IntraMnMobilityWithSgnbChange_mapping[keyType]
                                    : NrdcAddMn_IntraMnMobilityWithSgnbChg_mapping[keyType];
        }
    }

    if (FnVCCB_isSnInitMobility(ptCi))
    {
        // TODO: need to add the condition(SN Init Inter SN Change)

        if (IS_NRDC_SN(ptCi))
        {
            VCCB_CHECK_E_RANGE_AND_VAL(keyType, GET_ARR_SIZE(NrdcAddSn_SnChange_mapping), -1);
        }
        else
        {
            VCCB_CHECK_E_RANGE_AND_VAL(keyType, GET_ARR_SIZE(NrdcAddMn_SnChange_mapping), -1);
        }

        return IS_NRDC_SN(ptCi) ? NrdcAddSn_SnChange_mapping[keyType] : NrdcAddMn_SnChange_mapping[keyType];
    }

    if (IS_NRDC_SN(ptCi))
    {
        VCCB_CHECK_E_RANGE_AND_VAL(keyType, GET_ARR_SIZE(NrdcAddSn_mapping), -1);
    }
    else
    {
        VCCB_CHECK_E_RANGE_AND_VAL(keyType, GET_ARR_SIZE(NrdcAddMn_mapping), -1);
    }

    return IS_NRDC_SN(ptCi) ? NrdcAddSn_mapping[keyType] : NrdcAddMn_mapping[keyType];
}

/**
 * @brief     Generic function to stat Mrdc Sn Add
 * @param     ptCi : callInfo
 * @param     type : stat type
 * @param     fnName : caller function name
 */

void FnVCCB_StatMrdcSnAdd(callInfo_type *ptCi, int type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    int familyType = -1;
    int pmType = -1;

    familyType = FnVCCB_getMrdcSnAddStatFamily(ptCi);
    if (familyType == -1)
    {
        return;
    }

    if (GET_SN_ADDITION_PREPARATION_FLAG(ptCi->flag.setupFlag))
    {
        FnVCCB_ChangeTypeForSNAdditionPreparation(&type);
    }

    pmType = FnVCCB_getMrdcSnAddStatType(ptCi, type);
    if (pmType == -1)
    {
        return;
    }

    MACRO_STAT_PMCC_NAME(familyType, pmType, ptCi, 0, 0, 0, 0, 0, fnName);
    if(familyType == STAT_NRDC_SN_ADD_MN)
    {
        MACRO_STAT_PMCC_NAME(STAT_NRDC_SN_ADD_MN_PSCELL_NCI, pmType, ptCi, 0, 0, 0, 0, 0, fnName);
    }
    else if(familyType == STAT_NRDC_SN_ADD_SN_WITH_INVALID_CELL)
    {
        MACRO_STAT_PMCC_NAME(STAT_NRDC_SN_ADD_SN_PCELL_NCI, pmType, ptCi, 0, 0, 0, 0, 0, fnName);
    }
}

int FnVCCB_GetFamilyTypeNrdcModStats(const callInfo_type *const ptCi, const int mType)
{
    AUTO_TRACE_FUNC;
    int familyType = -1;

    if (IS_NRDC_MN(ptCi))
    {
        switch (mType)
        {
            case NrdcModMn_MnInit_Att ... NrdcModMn_MnInit_PrepFail:
                familyType = V_STAT_NRDC_SN_MOD_MN_MNInitiated;
                break;

            case NrdcModMn_SnInit_Att ... NrdcModMn_SnInit_Fail:
                familyType = V_STAT_NRDC_SN_MOD_MN_SNInitiated;
                break;
            default:
                VCCB_PRINT_CALL_ERROR(ptCi, "Invalid pm mType(%d) in %s!!\n", mType, __func__);
                break;
        }
    }
    else if (IS_NRDC_SN(ptCi))
    {
        switch (mType)
        {
            case NrdcModSn_MnInit_Att ... NrdcModSn_MnInit_PrepFail:
                familyType = V_STAT_NRDC_SN_MOD_SN_MNInitiated;
                break;
            case NrdcModSn_SnInit_Att ... NrdcModSn_SnInit_Fail:
                familyType = V_STAT_NRDC_SN_MOD_SN_SNInitiated;
                break;
            default:
                VCCB_PRINT_CALL_ERROR(ptCi, "Invalid pm mType(%d) in %s!!\n", mType, __func__);
                break;
        }
    }
    return familyType;
}

int FnVCCB_CheckXnCauseNrdcModStats(
    const callInfo_type *const ptCi, const int mType, const XNAP_Cause_type *const pCause)
{
    if ((IS_NRDC_MN(ptCi) && (mType == NrdcModMn_MnInit_Att || mType == NrdcModMn_SnInit_Att)) ||
        (IS_NRDC_SN(ptCi) && (mType == NrdcModSn_SnInit_Att || mType == NrdcModSn_MnInit_Att)))
    {
        if (pCause == NULL) return false;
        if (pCause->choice == XNAP_radioNetwork_chosen &&
            (pCause->u.radioNetwork == XNAP_mN_Mobility || pCause->u.radioNetwork == XNAP_sN_Mobility))
        {
            return false;
        }
    }
    return true;
}

// FGR-CC5200:FR680
void FnVCCB_UpdateNrdcModStats(
    callInfo_type *ptCi, int mType, XNAP_Cause_type *pCause, bool chkRaceCondition)
{
    AUTO_TRACE_FUNC;

    if (!FnVCCB_CheckXnCauseNrdcModStats(ptCi, mType, pCause))
    {
        return;
    }

    char fnName[MAX_VCCB_STAT_FUNC_NAME];
    snprintf(fnName, MAX_VCCB_STAT_FUNC_NAME, "%.*s:%d", (MAX_VCCB_STAT_FUNC_NAME - 6), __func__, __LINE__);
    fnName[MAX_VCCB_STAT_FUNC_NAME - 1] = '\0';

    int familyType = FnVCCB_GetFamilyTypeNrdcModStats(ptCi, mType);

    if (familyType > 0)
    {
        int famIdx = GET_FAMIDX(familyType);
        IS_VALID_FAMIDX_TYPE_NVOID(famIdx, mType);

        if (!(mType == NrdcModMn_MnInit_Att || mType == NrdcModMn_SnInit_Att || mType == NrdcModSn_MnInit_Att ||
                mType == NrdcModSn_SnInit_Att))
        {
            if (ptCi->stat.flag[famIdx] != ATTEMPT_MADE)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi,
                    "Stats(mFamily:%d, mType:%d) couldn't be collected because there has not been attempted !\n",
                    familyType, mType);
                return;
            }
        }

        (void)chkRaceCondition;
        /*
         * TBD
         *
        if (chkRaceCondition && mType == NrdcModSn_MnInit_Att)
        {
            int needTobeFailed_mFamily = V_STAT_NRDC_SN_MOD_SN_SNInitiated,
                needTobeFailed_mType = NrdcModSn_SnInit_Fail;
            famIdx = GET_FAMIDX(needTobeFailed_mFamily);
            IS_VALID_FAMIDX_TYPE_NVOID(famIdx, needTobeFailed_mType);
            if (ptCi->stat.flag[famIdx] == ATTEMPT_MADE)
            {
                MACRO_STAT_PMCC_NAME(needTobeFailed_mFamily, needTobeFailed_mType, ptCi, 0, 0, 0, 0, 0, fnName);
            }
        }
        */

        MACRO_STAT_PMCC_NAME(familyType, mType, ptCi, 0, 0, 0, 0, 0, fnName);
    }
}

/**
 * @brief     Generic function for mapping families from 18.3 to 19A version and setting NO_ATTEMPT flag.
 * @param     ptCi    : callInfo
 * @param     mFamily : stat family
 */
void VLIB_SetNoAttemptFlag(callInfo_type *ptCi, int mFamily)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    int famIdx = GET_FAMIDX(mFamily);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);

    SET_CALL_STAT_FLAG(ptCi, famIdx, NO_ATTEMPT);

    return;
}

int FnVCCB_GetOutTypeByFreqRedCap(callInfo_type *ptCi, enumHoStatType type, uint32_t tgtSsbFreq)
{
    AUTO_TRACE_FUNC;

    int pmType = -1;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, pmType);
    if (type >= HO_TYPE_MAX)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Supported Type(%d, max:%d)!!\n", type, HO_TYPE_MAX);

        return -1;
    }

    const int IntraFreq_Out_RedCap_mapping[HO_TYPE_MAX] = {
        // HO_INTRA_FREQ
        IntraFreqOut_Att_RedCap,                /*HO_Att*/
        IntraFreqOut_PrepSucc_RedCap,           /*HO_PrepSucc*/
        IntraFreqOut_Succ_RedCap,               /*HO_Succ*/
        IntraFreqOut_PrepFail_E1TimeOut_RedCap, /*HO_PrepFail_E1TimeOut*/
        IntraFreqOut_PrepFail_F1TimeOut_RedCap, /*HO_PrepFail_F1TimeOut*/
        IntraFreqOut_PrepFail_XnTimeOut_RedCap, /*HO_PrepFail_XnTimeOut*/
        IntraFreqOut_PrepFail_NgTimeOut_RedCap, /*HO_PrepFail_NgTimeOut*/
        IntraFreqOut_PrepFail_CpFail_RedCap,    /*HO_PrepFail_CpFail*/
        IntraFreqOut_PrepFail_E1Fail_RedCap,    /*HO_PrepFail_E1Fail*/
        IntraFreqOut_PrepFail_F1Fail_RedCap,    /*HO_PrepFail_F1Fail*/
        IntraFreqOut_PrepFail_NgFail_RedCap,    /*HO_PrepFail_NgFail*/
        IntraFreqOut_PrepFail_XnFail_RedCap,    /*HO_PrepFail_XnFail*/
        -1,                              /*HO_PrepFail_N26*/
        IntraFreqOut_Fail_E1TimeOut_RedCap,     /*HO_Fail_E1TimeOut*/
        IntraFreqOut_Fail_F1TimeOut_RedCap,     /*HO_Fail_F1TimeOut*/
        IntraFreqOut_Fail_XnTimeOut_RedCap,     /*HO_Fail_XnTimeOut*/
        IntraFreqOut_Fail_NgTimeOut_RedCap,     /*HO_Fail_NgTimeOut*/
        IntraFreqOut_Fail_RrcTimeOut_RedCap,    /*HO_Fail_RrcTimeOut*/
        IntraFreqOut_Fail_CpFail_RedCap,        /*HO_Fail_CpFail*/
        IntraFreqOut_Fail_E1Fail_RedCap,        /*HO_Fail_E1Fail*/
        IntraFreqOut_Fail_F1Fail_RedCap,        /*HO_Fail_F1Fail*/
        IntraFreqOut_Fail_NgFail_RedCap,        /*HO_Fail_NgFail*/
        IntraFreqOut_Fail_XnFail_RedCap,        /*HO_Fail_XnFail*/
        IntraFreqOut_HandoverCancel_RedCap,     /*HO_HandoverCancel*/
        IntraFreqOut_RRE_RedCap,                /*HO_RRE*/
    };

    const int InterFreq_Out_RedCap_mapping[HO_TYPE_MAX] = {
        // HO_INTER_FREQ
        InterFreqOutWithGap_Att_RedCap,                /*HO_Att*/
        InterFreqOutWithGap_PrepSucc_RedCap,           /*HO_PrepSucc*/
        InterFreqOutWithGap_Succ_RedCap,               /*HO_Succ*/
        InterFreqOutWithGap_PrepFail_E1TimeOut_RedCap, /*HO_PrepFail_E1TimeOut*/
        InterFreqOutWithGap_PrepFail_F1TimeOut_RedCap, /*HO_PrepFail_F1TimeOut*/
        InterFreqOutWithGap_PrepFail_XnTimeOut_RedCap, /*HO_PrepFail_XnTimeOut*/
        InterFreqOutWithGap_PrepFail_NgTimeOut_RedCap, /*HO_PrepFail_NgTimeOut*/
        InterFreqOutWithGap_PrepFail_CpFail_RedCap,    /*HO_PrepFail_CpFail*/
        InterFreqOutWithGap_PrepFail_E1Fail_RedCap,    /*HO_PrepFail_E1Fail*/
        InterFreqOutWithGap_PrepFail_F1Fail_RedCap,    /*HO_PrepFail_F1Fail*/
        InterFreqOutWithGap_PrepFail_NgFail_RedCap,    /*HO_PrepFail_NgFail*/
        InterFreqOutWithGap_PrepFail_XnFail_RedCap,    /*HO_PrepFail_XnFail*/
        -1,                                     /*HO_PrepFail_N26*/
        InterFreqOutWithGap_Fail_E1TimeOut_RedCap,     /*HO_Fail_E1TimeOut*/
        InterFreqOutWithGap_Fail_F1TimeOut_RedCap,     /*HO_Fail_F1TimeOut*/
        InterFreqOutWithGap_Fail_XnTimeOut_RedCap,     /*HO_Fail_XnTimeOut*/
        InterFreqOutWithGap_Fail_NgTimeOut_RedCap,     /*HO_Fail_NgTimeOut*/
        InterFreqOutWithGap_Fail_RrcTimeOut_RedCap,    /*HO_Fail_RrcTimeOut*/
        InterFreqOutWithGap_Fail_CpFail_RedCap,        /*HO_Fail_CpFail*/
        InterFreqOutWithGap_Fail_E1Fail_RedCap,        /*HO_Fail_E1Fail*/
        InterFreqOutWithGap_Fail_F1Fail_RedCap,        /*HO_Fail_F1Fail*/
        InterFreqOutWithGap_Fail_NgFail_RedCap,        /*HO_Fail_NgFail*/
        InterFreqOutWithGap_Fail_XnFail_RedCap,        /*HO_Fail_XnFail*/
        InterFreqOutWithGap_HandoverCancel_RedCap,     /*HO_HandoverCancel*/
        InterFreqOutWithGap_RRE_RedCap,                /*HO_RRE*/
    };

    const int InterFreq_Out_WithoutGap_RedCap_mapping[HO_TYPE_MAX] = {
        // NR_CONN_MC_21D
        // HO_INTER_FREQ_WITHOUT_GAP
        InterFreqOutWithoutGap_Att_RedCap,                /*HO_Att*/
        InterFreqOutWithoutGap_PrepSucc_RedCap,           /*HO_PrepSucc*/
        InterFreqOutWithoutGap_Succ_RedCap,               /*HO_Succ*/
        InterFreqOutWithoutGap_PrepFail_E1TimeOut_RedCap, /*HO_PrepFail_E1TimeOut*/
        InterFreqOutWithoutGap_PrepFail_F1TimeOut_RedCap, /*HO_PrepFail_F1TimeOut*/
        InterFreqOutWithoutGap_PrepFail_XnTimeOut_RedCap, /*HO_PrepFail_XnTimeOut*/
        InterFreqOutWithoutGap_PrepFail_NgTimeOut_RedCap, /*HO_PrepFail_NgTimeOut*/
        InterFreqOutWithoutGap_PrepFail_CpFail_RedCap,    /*HO_PrepFail_CpFail*/
        InterFreqOutWithoutGap_PrepFail_E1Fail_RedCap,    /*HO_PrepFail_E1Fail*/
        InterFreqOutWithoutGap_PrepFail_F1Fail_RedCap,    /*HO_PrepFail_F1Fail*/
        InterFreqOutWithoutGap_PrepFail_NgFail_RedCap,    /*HO_PrepFail_NgFail*/
        InterFreqOutWithoutGap_PrepFail_XnFail_RedCap,    /*HO_PrepFail_XnFail*/
        -1,                                        /*HO_PrepFail_N26*/
        InterFreqOutWithoutGap_Fail_E1TimeOut_RedCap,     /*HO_Fail_E1TimeOut*/
        InterFreqOutWithoutGap_Fail_F1TimeOut_RedCap,     /*HO_Fail_F1TimeOut*/
        InterFreqOutWithoutGap_Fail_XnTimeOut_RedCap,     /*HO_Fail_XnTimeOut*/
        InterFreqOutWithoutGap_Fail_NgTimeOut_RedCap,     /*HO_Fail_NgTimeOut*/
        InterFreqOutWithoutGap_Fail_RrcTimeOut_RedCap,    /*HO_Fail_RrcTimeOut*/
        InterFreqOutWithoutGap_Fail_CpFail_RedCap,        /*HO_Fail_CpFail*/
        InterFreqOutWithoutGap_Fail_E1Fail_RedCap,        /*HO_Fail_E1Fail*/
        InterFreqOutWithoutGap_Fail_F1Fail_RedCap,        /*HO_Fail_F1Fail*/
        InterFreqOutWithoutGap_Fail_NgFail_RedCap,        /*HO_Fail_NgFail*/
        InterFreqOutWithoutGap_Fail_XnFail_RedCap,        /*HO_Fail_XnFail*/
        InterFreqOutWithoutGap_HandoverCancel_RedCap,     /*HO_HandoverCancel*/
        InterFreqOutWithoutGap_RRE_RedCap,                /*HO_RRE*/
    };

    if (VCCB_IS_INTER_FREQ_SSB_FREQ(ptCi->servCellNum, tgtSsbFreq))
    {
        if (IS_IF_HO_WITH_MGAP(ptCi, tgtSsbFreq))
        {
            return InterFreq_Out_RedCap_mapping[type];
        }
        else
        {
            return InterFreq_Out_WithoutGap_RedCap_mapping[type];
        }
    }
    else
    {
        return IntraFreq_Out_RedCap_mapping[type];
    }

    return pmType;
}

int FnVCCB_GetOutTypeByFreq(callInfo_type *ptCi, enumHoStatType type, uint32_t tgtSsbFreq)
{
    AUTO_TRACE_FUNC;

    int pmType = -1;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, pmType);
    if (type >= HO_TYPE_MAX)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Supported Type(%d, max:%d)!!\n", type, HO_TYPE_MAX);

        return -1;
    }

    const int IntraFreq_Out_mapping[HO_TYPE_MAX] = {
        // HO_INTRA_FREQ
        IntraFreqOut_Att,                /*HO_Att*/
        IntraFreqOut_PrepSucc,           /*HO_PrepSucc*/
        IntraFreqOut_Succ,               /*HO_Succ*/
        IntraFreqOut_PrepFail_E1TimeOut, /*HO_PrepFail_E1TimeOut*/
        IntraFreqOut_PrepFail_F1TimeOut, /*HO_PrepFail_F1TimeOut*/
        IntraFreqOut_PrepFail_XnTimeOut, /*HO_PrepFail_XnTimeOut*/
        IntraFreqOut_PrepFail_NgTimeOut, /*HO_PrepFail_NgTimeOut*/
        IntraFreqOut_PrepFail_CpFail,    /*HO_PrepFail_CpFail*/
        IntraFreqOut_PrepFail_E1Fail,    /*HO_PrepFail_E1Fail*/
        IntraFreqOut_PrepFail_F1Fail,    /*HO_PrepFail_F1Fail*/
        IntraFreqOut_PrepFail_NgFail,    /*HO_PrepFail_NgFail*/
        IntraFreqOut_PrepFail_XnFail,    /*HO_PrepFail_XnFail*/
        -1,                              /*HO_PrepFail_N26*/
        IntraFreqOut_Fail_E1TimeOut,     /*HO_Fail_E1TimeOut*/
        IntraFreqOut_Fail_F1TimeOut,     /*HO_Fail_F1TimeOut*/
        IntraFreqOut_Fail_XnTimeOut,     /*HO_Fail_XnTimeOut*/
        IntraFreqOut_Fail_NgTimeOut,     /*HO_Fail_NgTimeOut*/
        IntraFreqOut_Fail_RrcTimeOut,    /*HO_Fail_RrcTimeOut*/
        IntraFreqOut_Fail_CpFail,        /*HO_Fail_CpFail*/
        IntraFreqOut_Fail_E1Fail,        /*HO_Fail_E1Fail*/
        IntraFreqOut_Fail_F1Fail,        /*HO_Fail_F1Fail*/
        IntraFreqOut_Fail_NgFail,        /*HO_Fail_NgFail*/
        IntraFreqOut_Fail_XnFail,        /*HO_Fail_XnFail*/
        IntraFreqOut_HandoverCancel,     /*HO_HandoverCancel*/
        IntraFreqOut_RRE,                /*HO_RRE*/
    };

    const int InterFreq_Out_mapping[HO_TYPE_MAX] = {
        // HO_INTER_FREQ
        InterFreqOutWithGap_Att,                /*HO_Att*/
        InterFreqOutWithGap_PrepSucc,           /*HO_PrepSucc*/
        InterFreqOutWithGap_Succ,               /*HO_Succ*/
        InterFreqOutWithGap_PrepFail_E1TimeOut, /*HO_PrepFail_E1TimeOut*/
        InterFreqOutWithGap_PrepFail_F1TimeOut, /*HO_PrepFail_F1TimeOut*/
        InterFreqOutWithGap_PrepFail_XnTimeOut, /*HO_PrepFail_XnTimeOut*/
        InterFreqOutWithGap_PrepFail_NgTimeOut, /*HO_PrepFail_NgTimeOut*/
        InterFreqOutWithGap_PrepFail_CpFail,    /*HO_PrepFail_CpFail*/
        InterFreqOutWithGap_PrepFail_E1Fail,    /*HO_PrepFail_E1Fail*/
        InterFreqOutWithGap_PrepFail_F1Fail,    /*HO_PrepFail_F1Fail*/
        InterFreqOutWithGap_PrepFail_NgFail,    /*HO_PrepFail_NgFail*/
        InterFreqOutWithGap_PrepFail_XnFail,    /*HO_PrepFail_XnFail*/
        -1,                                     /*HO_PrepFail_N26*/
        InterFreqOutWithGap_Fail_E1TimeOut,     /*HO_Fail_E1TimeOut*/
        InterFreqOutWithGap_Fail_F1TimeOut,     /*HO_Fail_F1TimeOut*/
        InterFreqOutWithGap_Fail_XnTimeOut,     /*HO_Fail_XnTimeOut*/
        InterFreqOutWithGap_Fail_NgTimeOut,     /*HO_Fail_NgTimeOut*/
        InterFreqOutWithGap_Fail_RrcTimeOut,    /*HO_Fail_RrcTimeOut*/
        InterFreqOutWithGap_Fail_CpFail,        /*HO_Fail_CpFail*/
        InterFreqOutWithGap_Fail_E1Fail,        /*HO_Fail_E1Fail*/
        InterFreqOutWithGap_Fail_F1Fail,        /*HO_Fail_F1Fail*/
        InterFreqOutWithGap_Fail_NgFail,        /*HO_Fail_NgFail*/
        InterFreqOutWithGap_Fail_XnFail,        /*HO_Fail_XnFail*/
        InterFreqOutWithGap_HandoverCancel,     /*HO_HandoverCancel*/
        InterFreqOutWithGap_RRE,                /*HO_RRE*/
    };

    const int InterFreq_Out_WithoutGap_mapping[HO_TYPE_MAX] = {
        // NR_CONN_MC_21D
        // HO_INTER_FREQ_WITHOUT_GAP
        InterFreqOutWithoutGap_Att,                /*HO_Att*/
        InterFreqOutWithoutGap_PrepSucc,           /*HO_PrepSucc*/
        InterFreqOutWithoutGap_Succ,               /*HO_Succ*/
        InterFreqOutWithoutGap_PrepFail_E1TimeOut, /*HO_PrepFail_E1TimeOut*/
        InterFreqOutWithoutGap_PrepFail_F1TimeOut, /*HO_PrepFail_F1TimeOut*/
        InterFreqOutWithoutGap_PrepFail_XnTimeOut, /*HO_PrepFail_XnTimeOut*/
        InterFreqOutWithoutGap_PrepFail_NgTimeOut, /*HO_PrepFail_NgTimeOut*/
        InterFreqOutWithoutGap_PrepFail_CpFail,    /*HO_PrepFail_CpFail*/
        InterFreqOutWithoutGap_PrepFail_E1Fail,    /*HO_PrepFail_E1Fail*/
        InterFreqOutWithoutGap_PrepFail_F1Fail,    /*HO_PrepFail_F1Fail*/
        InterFreqOutWithoutGap_PrepFail_NgFail,    /*HO_PrepFail_NgFail*/
        InterFreqOutWithoutGap_PrepFail_XnFail,    /*HO_PrepFail_XnFail*/
        -1,                                        /*HO_PrepFail_N26*/
        InterFreqOutWithoutGap_Fail_E1TimeOut,     /*HO_Fail_E1TimeOut*/
        InterFreqOutWithoutGap_Fail_F1TimeOut,     /*HO_Fail_F1TimeOut*/
        InterFreqOutWithoutGap_Fail_XnTimeOut,     /*HO_Fail_XnTimeOut*/
        InterFreqOutWithoutGap_Fail_NgTimeOut,     /*HO_Fail_NgTimeOut*/
        InterFreqOutWithoutGap_Fail_RrcTimeOut,    /*HO_Fail_RrcTimeOut*/
        InterFreqOutWithoutGap_Fail_CpFail,        /*HO_Fail_CpFail*/
        InterFreqOutWithoutGap_Fail_E1Fail,        /*HO_Fail_E1Fail*/
        InterFreqOutWithoutGap_Fail_F1Fail,        /*HO_Fail_F1Fail*/
        InterFreqOutWithoutGap_Fail_NgFail,        /*HO_Fail_NgFail*/
        InterFreqOutWithoutGap_Fail_XnFail,        /*HO_Fail_XnFail*/
        InterFreqOutWithoutGap_HandoverCancel,     /*HO_HandoverCancel*/
        InterFreqOutWithoutGap_RRE,                /*HO_RRE*/
    };

    if (VCCB_IS_INTER_FREQ_SSB_FREQ(ptCi->servCellNum, tgtSsbFreq))
    {
        if (IS_IF_HO_WITH_MGAP(ptCi, tgtSsbFreq))
            return InterFreq_Out_mapping[type];
        else
            return InterFreq_Out_WithoutGap_mapping[type];
    }
    else
    {
        return IntraFreq_Out_mapping[type];
    }

    return pmType;
}

int FnVCCB_GetOutTypeByEutraFreqRedCap(callInfo_type *ptCi, enumHoStatType type)
{
    AUTO_TRACE_FUNC;

    int pmType = -1;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, pmType);
    if (type >= HO_TYPE_MAX)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "%s Not Supported Type(%d, max:%d)!!\n", __func__, type, HO_TYPE_MAX);

        return -1;
    }

    const int InterSysLTE_Freq_Out_RedCap_mapping[HO_TYPE_MAX] = {
        // IRAT_HO
        InterSysLTE_Out_Att_RedCap,                      /*HO_Att*/
        InterSysLTE_Out_PrepSucc_RedCap,                 /*HO_PrepSucc*/
        InterSysLTE_Out_Succ_RedCap,                     /*HO_Succ*/
        -1,                                       /*HO_PrepFail_E1TimeOut*/
        -1,                                       /*HO_PrepFail_F1TimeOut*/
        -1,                                       /*HO_PrepFail_XnTimeOut*/
        InterSysLTE_Out_PrepFail_NgTimeOut_RedCap,       /*HO_PrepFail_NgTimeOut*/
        InterSysLTE_Out_PrepFail_CpFail_RedCap,          /*HO_PrepFail_CpFail*/
        -1,                                       /*HO_PrepFail_E1Fail*/
        -1,                                       /*HO_PrepFail_F1Fail*/
        InterSysLTE_Out_PrepFail_NgFail_RedCap,          /*HO_PrepFail_NgFail*/
        -1,                                       /*HO_PrepFail_XnFail*/
        InterSysLTE_Out_N26InterfaceNotAvailable_RedCap, /*HO_PrepFail_N26*/
        InterSysLTE_Out_Fail_E1TimeOut_RedCap,           /*HO_Fail_E1TimeOut*/
        InterSysLTE_Out_Fail_F1TimeOut_RedCap,           /*HO_Fail_F1TimeOut*/
        -1,                                       /*HO_Fail_XnTimeOut*/
        InterSysLTE_Out_Fail_NgTimeOut_RedCap,           /*HO_Fail_NgTimeOut*/
        -1,                                       /*HO_Fail_RrcTimeOut*/
        InterSysLTE_Out_Fail_CpFail_RedCap,              /*HO_Fail_CpFail*/
        InterSysLTE_Out_Fail_E1Fail_RedCap,              /*HO_Fail_E1Fail*/
        InterSysLTE_Out_Fail_F1Fail_RedCap,              /*HO_Fail_F1Fail*/
        InterSysLTE_Out_Fail_NgFail_RedCap,              /*HO_Fail_NgFail*/
        -1,                                       /*HO_Fail_XnFail*/
        InterSysLTE_Out_HandoverCancel_RedCap,           /*HO_HandoverCancel*/
        InterSysLTE_Out_RRE_RedCap,                      /*HO_RRE*/
    };

    const int InterSysLTE_Freq_Out_EPSFallback_RedCap_mapping[HO_TYPE_MAX] = {
        // IRAT_HO
        InterSysLTE_Out_EPSFallback_Att_RedCap,                      /*HO_Att*/
        InterSysLTE_Out_EPSFallback_PrepSucc_RedCap,                 /*HO_PrepSucc*/
        InterSysLTE_Out_EPSFallback_Succ_RedCap,                     /*HO_Succ*/
        -1,                                                   /*HO_PrepFail_E1TimeOut*/
        -1,                                                   /*HO_PrepFail_F1TimeOut*/
        -1,                                                   /*HO_PrepFail_XnTimeOut*/
        InterSysLTE_Out_EPSFallback_PrepFail_NgTimeOut_RedCap,       /*HO_PrepFail_NgTimeOut*/
        InterSysLTE_Out_EPSFallback_PrepFail_CpFail_RedCap,          /*HO_PrepFail_CpFail*/
        -1,                                                   /*HO_PrepFail_E1Fail*/
        -1,                                                   /*HO_PrepFail_F1Fail*/
        InterSysLTE_Out_EPSFallback_PrepFail_NgFail_RedCap,          /*HO_PrepFail_NgFail*/
        -1,                                                   /*HO_PrepFail_XnFail*/
        InterSysLTE_Out_EPSFallback_N26InterfaceNotAvailable_RedCap, /*HO_PrepFail_N26*/
        InterSysLTE_Out_EPSFallback_Fail_E1Timeout_RedCap,           /*HO_Fail_E1TimeOut*/
        InterSysLTE_Out_EPSFallback_Fail_F1Timeout_RedCap,           /*HO_Fail_F1TimeOut*/
        -1,                                                   /*HO_Fail_XnTimeOut*/
        InterSysLTE_Out_EPSFallback_Fail_NgTimeout_RedCap,           /*HO_Fail_NgTimeOut*/
        -1,                                                   /*HO_Fail_RrcTimeOut*/
        InterSysLTE_Out_EPSFallback_Fail_CpFail_RedCap,              /*HO_Fail_CpFail*/
        InterSysLTE_Out_EPSFallback_Fail_E1Fail_RedCap,              /*HO_Fail_E1Fail*/
        InterSysLTE_Out_EPSFallback_Fail_F1Fail_RedCap,              /*HO_Fail_F1Fail*/
        InterSysLTE_Out_EPSFallback_Fail_NgFail_RedCap,              /*HO_Fail_NgFail*/
        -1,                                                   /*HO_Fail_XnFail*/
        InterSysLTE_Out_EPSFallback_HandoverCancel_RedCap,           /*HO_HandoverCancel*/
        InterSysLTE_Out_EPSFallback_RRE_RedCap,                      /*HO_RRE*/
    };

    const int InterSysLTE_Freq_Out_EmergencyFallback_RedCap_mapping[HO_TYPE_MAX] = {
        // IRAT_HO
        InterSysLTE_Out_EmergencyFallback_Att_RedCap,                      /*HO_Att*/
        InterSysLTE_Out_EmergencyFallback_PrepSucc_RedCap,                 /*HO_PrepSucc*/
        InterSysLTE_Out_EmergencyFallback_Succ_RedCap,                     /*HO_Succ*/
        -1,                                                         /*HO_PrepFail_E1TimeOut*/
        -1,                                                         /*HO_PrepFail_F1TimeOut*/
        -1,                                                         /*HO_PrepFail_XnTimeOut*/
        InterSysLTE_Out_EmergencyFallback_PrepFail_NgTimeOut_RedCap,       /*HO_PrepFail_NgTimeOut*/
        InterSysLTE_Out_EmergencyFallback_PrepFail_CpFail_RedCap,          /*HO_PrepFail_CpFail*/
        -1,                                                         /*HO_PrepFail_E1Fail*/
        -1,                                                         /*HO_PrepFail_F1Fail*/
        InterSysLTE_Out_EmergencyFallback_PrepFail_NgFail_RedCap,          /*HO_PrepFail_NgFail*/
        -1,                                                         /*HO_PrepFail_XnFail*/
        InterSysLTE_Out_EmergencyFallback_N26InterfaceNotAvailable_RedCap, /*HO_PrepFail_N26*/
        InterSysLTE_Out_EmergencyFallback_Fail_E1Timeout_RedCap,           /*HO_Fail_E1TimeOut*/
        InterSysLTE_Out_EmergencyFallback_Fail_F1Timeout_RedCap,           /*HO_Fail_F1TimeOut*/
        -1,                                                         /*HO_Fail_XnTimeOut*/
        InterSysLTE_Out_EmergencyFallback_Fail_NgTimeout_RedCap,           /*HO_Fail_NgTimeOut*/
        -1,                                                         /*HO_Fail_RrcTimeOut*/
        InterSysLTE_Out_EmergencyFallback_Fail_CpFail_RedCap,              /*HO_Fail_CpFail*/
        InterSysLTE_Out_EmergencyFallback_Fail_E1Fail_RedCap,              /*HO_Fail_E1Fail*/
        InterSysLTE_Out_EmergencyFallback_Fail_F1Fail_RedCap,              /*HO_Fail_F1Fail*/
        InterSysLTE_Out_EmergencyFallback_Fail_NgFail_RedCap,              /*HO_Fail_NgFail*/
        -1,                                                         /*HO_Fail_XnFail*/
        InterSysLTE_Out_EmergencyFallback_HandoverCancel_RedCap,           /*HO_HandoverCancel*/
        InterSysLTE_Out_EmergencyFallback_RRE_RedCap,                      /*HO_RRE*/
    };

    if (IS_EMERGENCY_FALLBACK_CASE(ptCi))
    {
        pmType = InterSysLTE_Freq_Out_EmergencyFallback_RedCap_mapping[type];
    }
    else if (IS_EPS_FALLBACK_CASE(ptCi))
    {
        pmType = InterSysLTE_Freq_Out_EPSFallback_RedCap_mapping[type];
    }
    else
    {
        pmType = InterSysLTE_Freq_Out_RedCap_mapping[type];
    }

    return pmType;
}

int FnVCCB_GetOutTypeByEutraFreq(callInfo_type *ptCi, enumHoStatType type)
{
    AUTO_TRACE_FUNC;

    int pmType = -1;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, pmType);
    if (type >= HO_TYPE_MAX)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "%s Not Supported Type(%d, max:%d)!!\n", __func__, type, HO_TYPE_MAX);

        return -1;
    }

    const int InterSysLTE_Freq_Out_mapping[HO_TYPE_MAX] = {
        // IRAT_HO
        InterSysLTE_Out_Att_FREQ_OUT,                      /*HO_Att*/
        InterSysLTE_Out_PrepSucc_FREQ_OUT,                 /*HO_PrepSucc*/
        InterSysLTE_Out_Succ_FREQ_OUT,                     /*HO_Succ*/
        -1,                                       /*HO_PrepFail_E1TimeOut*/
        -1,                                       /*HO_PrepFail_F1TimeOut*/
        -1,                                       /*HO_PrepFail_XnTimeOut*/
        InterSysLTE_Out_PrepFail_NgTimeOut_FREQ_OUT,       /*HO_PrepFail_NgTimeOut*/
        InterSysLTE_Out_PrepFail_CpFail_FREQ_OUT,          /*HO_PrepFail_CpFail*/
        -1,                                       /*HO_PrepFail_E1Fail*/
        -1,                                       /*HO_PrepFail_F1Fail*/
        InterSysLTE_Out_PrepFail_NgFail_FREQ_OUT,          /*HO_PrepFail_NgFail*/
        -1,                                       /*HO_PrepFail_XnFail*/
        InterSysLTE_Out_N26InterfaceNotAvailable_FREQ_OUT, /*HO_PrepFail_N26*/
        InterSysLTE_Out_Fail_E1TimeOut_FREQ_OUT,           /*HO_Fail_E1TimeOut*/
        InterSysLTE_Out_Fail_F1TimeOut_FREQ_OUT,           /*HO_Fail_F1TimeOut*/
        -1,                                       /*HO_Fail_XnTimeOut*/
        InterSysLTE_Out_Fail_NgTimeOut_FREQ_OUT,           /*HO_Fail_NgTimeOut*/
        -1,                                       /*HO_Fail_RrcTimeOut*/
        InterSysLTE_Out_Fail_CpFail_FREQ_OUT,              /*HO_Fail_CpFail*/
        InterSysLTE_Out_Fail_E1Fail_FREQ_OUT,              /*HO_Fail_E1Fail*/
        InterSysLTE_Out_Fail_F1Fail_FREQ_OUT,              /*HO_Fail_F1Fail*/
        InterSysLTE_Out_Fail_NgFail_FREQ_OUT,              /*HO_Fail_NgFail*/
        -1,                                       /*HO_Fail_XnFail*/
        InterSysLTE_Out_HandoverCancel_FREQ_OUT,           /*HO_HandoverCancel*/
        InterSysLTE_Out_RRE_FREQ_OUT,                      /*HO_RRE*/
    };

    const int InterSysLTE_Freq_Out_EPSFallback_mapping[HO_TYPE_MAX] = {
        // IRAT_HO
        InterSysLTE_Out_EPSFallback_Att_FREQ_OUT,                      /*HO_Att*/
        InterSysLTE_Out_EPSFallback_PrepSucc_FREQ_OUT,                 /*HO_PrepSucc*/
        InterSysLTE_Out_EPSFallback_Succ_FREQ_OUT,                     /*HO_Succ*/
        -1,                                                   /*HO_PrepFail_E1TimeOut*/
        -1,                                                   /*HO_PrepFail_F1TimeOut*/
        -1,                                                   /*HO_PrepFail_XnTimeOut*/
        InterSysLTE_Out_EPSFallback_PrepFail_NgTimeOut_FREQ_OUT,       /*HO_PrepFail_NgTimeOut*/
        InterSysLTE_Out_EPSFallback_PrepFail_CpFail_FREQ_OUT,          /*HO_PrepFail_CpFail*/
        -1,                                                   /*HO_PrepFail_E1Fail*/
        -1,                                                   /*HO_PrepFail_F1Fail*/
        InterSysLTE_Out_EPSFallback_PrepFail_NgFail_FREQ_OUT,          /*HO_PrepFail_NgFail*/
        -1,                                                   /*HO_PrepFail_XnFail*/
        InterSysLTE_Out_EPSFallback_N26InterfaceNotAvailable_FREQ_OUT, /*HO_PrepFail_N26*/
        InterSysLTE_Out_EPSFallback_Fail_E1Timeout_FREQ_OUT,           /*HO_Fail_E1TimeOut*/
        InterSysLTE_Out_EPSFallback_Fail_F1Timeout_FREQ_OUT,           /*HO_Fail_F1TimeOut*/
        -1,                                                   /*HO_Fail_XnTimeOut*/
        InterSysLTE_Out_EPSFallback_Fail_NgTimeout_FREQ_OUT,           /*HO_Fail_NgTimeOut*/
        -1,                                                   /*HO_Fail_RrcTimeOut*/
        InterSysLTE_Out_EPSFallback_Fail_CpFail_FREQ_OUT,              /*HO_Fail_CpFail*/
        InterSysLTE_Out_EPSFallback_Fail_E1Fail_FREQ_OUT,              /*HO_Fail_E1Fail*/
        InterSysLTE_Out_EPSFallback_Fail_F1Fail_FREQ_OUT,              /*HO_Fail_F1Fail*/
        InterSysLTE_Out_EPSFallback_Fail_NgFail_FREQ_OUT,              /*HO_Fail_NgFail*/
        -1,                                                   /*HO_Fail_XnFail*/
        InterSysLTE_Out_EPSFallback_HandoverCancel_FREQ_OUT,           /*HO_HandoverCancel*/
        InterSysLTE_Out_EPSFallback_RRE_FREQ_OUT,                      /*HO_RRE*/
    };

    const int InterSysLTE_Freq_Out_EmergencyFallback_mapping[HO_TYPE_MAX] = {
        // IRAT_HO
        InterSysLTE_Out_EmergencyFallback_Att_FREQ_OUT,                      /*HO_Att*/
        InterSysLTE_Out_EmergencyFallback_PrepSucc_FREQ_OUT,                 /*HO_PrepSucc*/
        InterSysLTE_Out_EmergencyFallback_Succ_FREQ_OUT,                     /*HO_Succ*/
        -1,                                                         /*HO_PrepFail_E1TimeOut*/
        -1,                                                         /*HO_PrepFail_F1TimeOut*/
        -1,                                                         /*HO_PrepFail_XnTimeOut*/
        InterSysLTE_Out_EmergencyFallback_PrepFail_NgTimeOut_FREQ_OUT,       /*HO_PrepFail_NgTimeOut*/
        InterSysLTE_Out_EmergencyFallback_PrepFail_CpFail_FREQ_OUT,          /*HO_PrepFail_CpFail*/
        -1,                                                         /*HO_PrepFail_E1Fail*/
        -1,                                                         /*HO_PrepFail_F1Fail*/
        InterSysLTE_Out_EmergencyFallback_PrepFail_NgFail_FREQ_OUT,          /*HO_PrepFail_NgFail*/
        -1,                                                         /*HO_PrepFail_XnFail*/
        InterSysLTE_Out_EmergencyFallback_N26InterfaceNotAvailable_FREQ_OUT, /*HO_PrepFail_N26*/
        InterSysLTE_Out_EmergencyFallback_Fail_E1Timeout_FREQ_OUT,           /*HO_Fail_E1TimeOut*/
        InterSysLTE_Out_EmergencyFallback_Fail_F1Timeout_FREQ_OUT,           /*HO_Fail_F1TimeOut*/
        -1,                                                         /*HO_Fail_XnTimeOut*/
        InterSysLTE_Out_EmergencyFallback_Fail_NgTimeout_FREQ_OUT,           /*HO_Fail_NgTimeOut*/
        -1,                                                         /*HO_Fail_RrcTimeOut*/
        InterSysLTE_Out_EmergencyFallback_Fail_CpFail_FREQ_OUT,              /*HO_Fail_CpFail*/
        InterSysLTE_Out_EmergencyFallback_Fail_E1Fail_FREQ_OUT,              /*HO_Fail_E1Fail*/
        InterSysLTE_Out_EmergencyFallback_Fail_F1Fail_FREQ_OUT,              /*HO_Fail_F1Fail*/
        InterSysLTE_Out_EmergencyFallback_Fail_NgFail_FREQ_OUT,              /*HO_Fail_NgFail*/
        -1,                                                         /*HO_Fail_XnFail*/
        InterSysLTE_Out_EmergencyFallback_HandoverCancel_FREQ_OUT,           /*HO_HandoverCancel*/
        InterSysLTE_Out_EmergencyFallback_RRE_FREQ_OUT,                      /*HO_RRE*/
    };

    if (IS_EMERGENCY_FALLBACK_CASE(ptCi))
    {
        pmType = InterSysLTE_Freq_Out_EmergencyFallback_mapping[type];
    }
    else if (IS_EPS_FALLBACK_CASE(ptCi))
    {
        pmType = InterSysLTE_Freq_Out_EPSFallback_mapping[type];
    }
    else
    {
        pmType = InterSysLTE_Freq_Out_mapping[type];
    }

    return pmType;
}

/**
 * @brief     return VoNR statistics type for HO_TIME family
 * @param     ptCi : call context pointer
 * @param     mFamily : statistics family
 * @param     type : statistics type in family
 * @return    VoNR statistics type
 */
int FnVCCB_CollectVoNRStatFromHoTime(callInfo_type *ptCi, int mFamily, int type)
{
    AUTO_TRACE_FUNC;

    int typeId = -1;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, typeId);

    switch (type)
    {
        case IntraGnb_HoTimeAvg:
            typeId = IntraGnbVoNR_HoTimeAvg;
            break;
        case IntraGnb_HoTimeAvg_RedCap:
            typeId = IntraGnbVoNR_HoTimeAvg_RedCap;
            break;
        case InterXn_HoTimeAvg:
            typeId = InterXnVoNR_HoTimeAvg;
            break;
        case InterXn_HoTimeAvg_RedCap:
            typeId = InterXnVoNR_HoTimeAvg_RedCap;
            break;
        case InterNg_HoTimeAvg:
            typeId = InterNgVoNR_HoTimeAvg;
            break;
        case InterNg_HoTimeAvg_RedCap:
            typeId = InterNgVoNR_HoTimeAvg_RedCap;
            break;
        case InterRatIn_HoTimeAvg:
            typeId = InterRatIn_VoNR_HoTimeAvg;
            break;
        case InterRatIn_HoTimeAvg_RedCap:
            typeId = InterRatIn_VoNR_HoTimeAvg_RedCap;
            break;
        default:
            return typeId;
    }

    // Available to VoNR
    if (ptCi->hoInfo.isVonrCall == FALSE) return -1;

    VCCB_PRINT_CALL_COMMENT(ptCi, "%s mFamily:%d type:%d typeId:%d \n", __func__, mFamily, type, typeId);

    return typeId;
}

int getTypeFromOut(callInfo_type *ptCi, enumHoStatType type)
{
    AUTO_TRACE_FUNC;

    int pmType = -1;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, pmType);
    if (type >= HO_TYPE_MAX)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Supported Type(%d, max:%d)!!\n", type, HO_TYPE_MAX);

        return -1;
    }

    const int InterNgOut_mapping[HO_TYPE_MAX] = {
        InterNgOut_Att,                /*HO_Att*/
        InterNgOut_PrepSucc,           /*HO_PrepSucc*/
        InterNgOut_Succ,               /*HO_Succ*/
        -1,                            /*HO_PrepFail_E1TimeOut*/
        -1,                            /*HO_PrepFail_F1TimeOut*/
        -1,                            /*HO_PrepFail_XnTimeOut*/
        InterNgOut_PrepFail_NgTimeOut, /*HO_PrepFail_NgTimeOut*/
        InterNgOut_PrepFail_CpFail,    /*HO_PrepFail_CpFail*/
        -1,                            /*HO_PrepFail_E1Fail*/
        -1,                            /*HO_PrepFail_F1Fail*/
        InterNgOut_PrepFail_NgFail,    /*HO_PrepFail_NgFail*/
        -1,                            /*HO_PrepFail_XnFail*/
        -1,                            /*HO_PrepFail_N26*/
        InterNgOut_Fail_E1TimeOut,     /*HO_Fail_E1TimeOut*/
        InterNgOut_Fail_F1TimeOut,     /*HO_Fail_F1TimeOut*/
        -1,                            /*HO_Fail_XnTimeOut*/
        InterNgOut_Fail_NgTimeOut,     /*HO_Fail_NgTimeOut*/
        -1,                            /*HO_Fail_RrcTimeOut*/
        InterNgOut_Fail_CpFail,        /*HO_Fail_CpFail*/
        InterNgOut_Fail_E1Fail,        /*HO_Fail_E1Fail*/
        InterNgOut_Fail_F1Fail,        /*HO_Fail_F1Fail*/
        InterNgOut_Fail_NgFail,        /*HO_Fail_NgFail*/
        -1,                            /*HO_Fail_XnFail*/
        InterNgOut_HandoverCancel,     /*HO_HandoverCancel*/
        InterNgOut_RRE,                /*HO_RRE*/
    };

    const int InterXnOut_mapping[HO_TYPE_MAX] = {
        InterXnOut_Att,                /*HO_Att*/
        InterXnOut_PrepSucc,           /*HO_PrepSucc*/
        InterXnOut_Succ,               /*HO_Succ*/
        -1,                            /*HO_PrepFail_E1TimeOut*/
        -1,                            /*HO_PrepFail_F1TimeOut*/
        InterXnOut_PrepFail_XnTimeOut, /*HO_PrepFail_XnTimeOut*/
        -1,                            /*HO_PrepFail_NgTimeOut*/
        InterXnOut_PrepFail_CpFail,    /*HO_PrepFail_CpFail*/
        -1,                            /*HO_PrepFail_E1Fail*/
        -1,                            /*HO_PrepFail_F1Fail*/
        -1,                            /*HO_PrepFail_NgFail*/
        InterXnOut_PrepFail_XnFail,    /*HO_PrepFail_XnFail*/
        -1,                            /*HO_PrepFail_N26*/
        InterXnOut_Fail_E1TimeOut,     /*HO_Fail_E1TimeOut*/
        InterXnOut_Fail_F1TimeOut,     /*HO_Fail_F1TimeOut*/
        InterXnOut_Fail_XnTimeOut,     /*HO_Fail_XnTimeOut*/
        -1,                            /*HO_Fail_NgTimeOut*/
        -1,                            /*HO_Fail_RrcTimeOut*/
        InterXnOut_Fail_CpFail,        /*HO_Fail_CpFail*/
        InterXnOut_Fail_E1Fail,        /*HO_Fail_E1Fail*/
        InterXnOut_Fail_F1Fail,        /*HO_Fail_F1Fail*/
        -1,                            /*HO_Fail_NgFail*/
        InterXnOut_Fail_XnFail,        /*HO_Fail_XnFail*/
        InterXnOut_HandoverCancel,     /*HO_HandoverCancel*/
        InterXnOut_RRE,                /*HO_RRE*/
    };

    const int IntraGnbOut_mapping[HO_TYPE_MAX] = {
        IntraGnbOut_Att,                /*HO_Att*/
        IntraGnbOut_PrepSucc,           /*HO_PrepSucc*/
        IntraGnbOut_Succ,               /*HO_Succ*/
        IntraGnbOut_PrepFail_E1TimeOut, /*HO_PrepFail_E1TimeOut*/
        IntraGnbOut_PrepFail_F1TimeOut, /*HO_PrepFail_F1TimeOut*/
        -1,                             /*HO_PrepFail_XnTimeOut*/
        -1,                             /*HO_PrepFail_NgTimeOut*/
        IntraGnbOut_PrepFail_CpFail,    /*HO_PrepFail_CpFail*/
        IntraGnbOut_PrepFail_E1Fail,    /*HO_PrepFail_E1Fail*/
        IntraGnbOut_PrepFail_F1Fail,    /*HO_PrepFail_F1Fail*/
        -1,                             /*HO_PrepFail_NgFail*/
        -1,                             /*HO_PrepFail_XnFail*/
        -1,                             /*HO_PrepFail_N26*/
        IntraGnbOut_Fail_E1TimeOut,     /*HO_Fail_E1TimeOut*/
        IntraGnbOut_Fail_F1TimeOut,     /*HO_Fail_F1TimeOut*/
        -1,                             /*HO_Fail_XnTimeOut*/
        -1,                             /*HO_Fail_NgTimeOut*/
        IntraGnbOut_Fail_RrcTimeOut,    /*HO_Fail_RrcTimeOut*/
        IntraGnbOut_Fail_CpFail,        /*HO_Fail_CpFail*/
        IntraGnbOut_Fail_E1Fail,        /*HO_Fail_E1Fail*/
        IntraGnbOut_Fail_F1Fail,        /*HO_Fail_F1Fail*/
        -1,                             /*HO_Fail_NgFail*/
        -1,                             /*HO_Fail_XnFail*/
        IntraGnbOut_HandoverCancel,     /*HO_HandoverCancel*/
        IntraGnbOut_RRE,                /*HO_RRE*/
    };

    const int InterSysLTE_Out_mapping[HO_TYPE_MAX] = {
        // IRAT_HO
        InterSysLTE_Out_Att,                      /*HO_Att*/
        InterSysLTE_Out_PrepSucc,                 /*HO_PrepSucc*/
        InterSysLTE_Out_Succ,                     /*HO_Succ*/
        -1,                                       /*HO_PrepFail_E1TimeOut*/
        -1,                                       /*HO_PrepFail_F1TimeOut*/
        -1,                                       /*HO_PrepFail_XnTimeOut*/
        InterSysLTE_Out_PrepFail_NgTimeOut,       /*HO_PrepFail_NgTimeOut*/
        InterSysLTE_Out_PrepFail_CpFail,          /*HO_PrepFail_CpFail*/
        -1,                                       /*HO_PrepFail_E1Fail*/
        -1,                                       /*HO_PrepFail_F1Fail*/
        InterSysLTE_Out_PrepFail_NgFail,          /*HO_PrepFail_NgFail*/
        -1,                                       /*HO_PrepFail_XnFail*/
        InterSysLTE_Out_N26InterfaceNotAvailable, /*HO_PrepFail_N26*/
        InterSysLTE_Out_Fail_E1TimeOut,           /*HO_Fail_E1TimeOut*/
        InterSysLTE_Out_Fail_F1TimeOut,           /*HO_Fail_F1TimeOut*/
        -1,                                       /*HO_Fail_XnTimeOut*/
        InterSysLTE_Out_Fail_NgTimeOut,           /*HO_Fail_NgTimeOut*/
        -1,                                       /*HO_Fail_RrcTimeOut*/
        InterSysLTE_Out_Fail_CpFail,              /*HO_Fail_CpFail*/
        InterSysLTE_Out_Fail_E1Fail,              /*HO_Fail_E1Fail*/
        InterSysLTE_Out_Fail_F1Fail,              /*HO_Fail_F1Fail*/
        InterSysLTE_Out_Fail_NgFail,              /*HO_Fail_NgFail*/
        -1,                                       /*HO_Fail_XnFail*/
        InterSysLTE_Out_HandoverCancel,           /*HO_HandoverCancel*/
        InterSysLTE_Out_RRE,                      /*HO_RRE*/
    };

    const int InterSysLTE_Out_EPSFallback_mapping[HO_TYPE_MAX] = {
        // IRAT_HO
        InterSysLTE_Out_EPSFallback_Att,                      /*HO_Att*/
        InterSysLTE_Out_EPSFallback_PrepSucc,                 /*HO_PrepSucc*/
        InterSysLTE_Out_EPSFallback_Succ,                     /*HO_Succ*/
        -1,                                                   /*HO_PrepFail_E1TimeOut*/
        -1,                                                   /*HO_PrepFail_F1TimeOut*/
        -1,                                                   /*HO_PrepFail_XnTimeOut*/
        InterSysLTE_Out_EPSFallback_PrepFail_NgTimeOut,       /*HO_PrepFail_NgTimeOut*/
        InterSysLTE_Out_EPSFallback_PrepFail_CpFail,          /*HO_PrepFail_CpFail*/
        -1,                                                   /*HO_PrepFail_E1Fail*/
        -1,                                                   /*HO_PrepFail_F1Fail*/
        InterSysLTE_Out_EPSFallback_PrepFail_NgFail,          /*HO_PrepFail_NgFail*/
        -1,                                                   /*HO_PrepFail_XnFail*/
        InterSysLTE_Out_EPSFallback_N26InterfaceNotAvailable, /*HO_PrepFail_N26*/
        InterSysLTE_Out_EPSFallback_Fail_E1Timeout,           /*HO_Fail_E1TimeOut*/
        InterSysLTE_Out_EPSFallback_Fail_F1Timeout,           /*HO_Fail_F1TimeOut*/
        -1,                                                   /*HO_Fail_XnTimeOut*/
        InterSysLTE_Out_EPSFallback_Fail_NgTimeout,           /*HO_Fail_NgTimeOut*/
        -1,                                                   /*HO_Fail_RrcTimeOut*/
        InterSysLTE_Out_EPSFallback_Fail_CpFail,              /*HO_Fail_CpFail*/
        InterSysLTE_Out_EPSFallback_Fail_E1Fail,              /*HO_Fail_E1Fail*/
        InterSysLTE_Out_EPSFallback_Fail_F1Fail,              /*HO_Fail_F1Fail*/
        InterSysLTE_Out_EPSFallback_Fail_NgFail,              /*HO_Fail_NgFail*/
        -1,                                                   /*HO_Fail_XnFail*/
        InterSysLTE_Out_EPSFallback_HandoverCancel,           /*HO_HandoverCancel*/
        InterSysLTE_Out_EPSFallback_RRE,                      /*HO_RRE*/
    };

    const int InterSysLTE_Out_EmergencyFallback_mapping[HO_TYPE_MAX] = {
        // IRAT_HO
        InterSysLTE_Out_EmergencyFallback_Att,                      /*HO_Att*/
        InterSysLTE_Out_EmergencyFallback_PrepSucc,                 /*HO_PrepSucc*/
        InterSysLTE_Out_EmergencyFallback_Succ,                     /*HO_Succ*/
        -1,                                                         /*HO_PrepFail_E1TimeOut*/
        -1,                                                         /*HO_PrepFail_F1TimeOut*/
        -1,                                                         /*HO_PrepFail_XnTimeOut*/
        InterSysLTE_Out_EmergencyFallback_PrepFail_NgTimeOut,       /*HO_PrepFail_NgTimeOut*/
        InterSysLTE_Out_EmergencyFallback_PrepFail_CpFail,          /*HO_PrepFail_CpFail*/
        -1,                                                         /*HO_PrepFail_E1Fail*/
        -1,                                                         /*HO_PrepFail_F1Fail*/
        InterSysLTE_Out_EmergencyFallback_PrepFail_NgFail,          /*HO_PrepFail_NgFail*/
        -1,                                                         /*HO_PrepFail_XnFail*/
        InterSysLTE_Out_EmergencyFallback_N26InterfaceNotAvailable, /*HO_PrepFail_N26*/
        InterSysLTE_Out_EmergencyFallback_Fail_E1Timeout,           /*HO_Fail_E1TimeOut*/
        InterSysLTE_Out_EmergencyFallback_Fail_F1Timeout,           /*HO_Fail_F1TimeOut*/
        -1,                                                         /*HO_Fail_XnTimeOut*/
        InterSysLTE_Out_EmergencyFallback_Fail_NgTimeout,           /*HO_Fail_NgTimeOut*/
        -1,                                                         /*HO_Fail_RrcTimeOut*/
        InterSysLTE_Out_EmergencyFallback_Fail_CpFail,              /*HO_Fail_CpFail*/
        InterSysLTE_Out_EmergencyFallback_Fail_E1Fail,              /*HO_Fail_E1Fail*/
        InterSysLTE_Out_EmergencyFallback_Fail_F1Fail,              /*HO_Fail_F1Fail*/
        InterSysLTE_Out_EmergencyFallback_Fail_NgFail,              /*HO_Fail_NgFail*/
        -1,                                                         /*HO_Fail_XnFail*/
        InterSysLTE_Out_EmergencyFallback_HandoverCancel,           /*HO_HandoverCancel*/
        InterSysLTE_Out_EmergencyFallback_RRE,                      /*HO_RRE*/
    };

    switch (ptCi->hoInfo.hoType.initiated)
    {
        case HO_TYPE_SA_INTER_GNB_NG_HANDOVER:  // Inter-Gnb NG Handover Outgoing
            pmType = InterNgOut_mapping[type];

            if (pmType == -1) break;  // Not Found Mapping Stat

            if (IS_NEDC_MN(ptCi))
            {
                pmType += (InterNgOutWithNedc_Att - InterNgOut_Att);
            }
            if (IS_NRDC_MN(ptCi))
            {
                pmType += (InterNgOutwithNrdc_Att - InterNgOut_Att);
            }
            break;

        case HO_TYPE_SA_INTER_GNB_XN_HANDOVER:  // Inter-Gnb XN Handover Outgoing
            pmType = InterXnOut_mapping[type];

            if (pmType == -1) break;  // Not Found Mapping Stat

            if (IS_NEDC_MN(ptCi))
            {
                pmType += (InterXnOutWithNedc_Att - InterXnOut_Att);
            }
            if (IS_NRDC_MN(ptCi))
            {
                pmType += (InterXnOutwithNrdc_Att - InterXnOut_Att);
            }
            break;

        case HO_TYPE_SA_INTRA_GNB_INTER_DU_HANDOVER:  // Intra-Gnb Handover Outgoing
        case HO_TYPE_SA_INTRA_GNB_INTRA_DU_HANDOVER:
            pmType = IntraGnbOut_mapping[type];

            if (pmType == -1) break;  // Not Found Mapping Stat

            if (IS_NEDC_MN(ptCi))
            {
                pmType += (IntraGnbOutWithNedc_Att - IntraGnbOut_Att);
            }
            if (IS_NRDC_MN(ptCi))
            {
                pmType += (IntraGnbOutWithNrdc_Att - IntraGnbOut_Att);
            }
            break;

        case HO_TYPE_SA_INTER_SYSTEM_INTER_RAT_HANDOVER:  // Inter System Inter-RAT NG Handover Outgoing // IRAT_HO
            // In case of handover to EUTRA small cell, don't collect HO_EUTRAN_OUT and STAT_HO_EUTRAN_OUT_FALLBACK.
            if (IS_IRAT_HO_TARGET_NON_NBR_CELL())  // IRAT_HO_24A
            {
                VCCB_PRINT_CALL_NON_NBR_HO(ptCi, "Skip collecting HO_EUTRAN_OUT !! Tgt is EUTRA Small Cell\n");
                return -1;
            }

            if (IS_EMERGENCY_FALLBACK_CASE(ptCi))
            {
                pmType = InterSysLTE_Out_EmergencyFallback_mapping[type];
            }
            else if (IS_EPS_FALLBACK_CASE(ptCi))
            {
                pmType = InterSysLTE_Out_EPSFallback_mapping[type];
            }
            else
            {
                pmType = InterSysLTE_Out_mapping[type];
            }
            break;

        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "Not Supported Statistic Error!!(%d)\n", ptCi->hoInfo.hoType.initiated);

            return -1;
    }

    return pmType;
}

int getTypeFromInRedCap(callInfo_type *ptCi, enumHoStatType type)
{
    AUTO_TRACE_FUNC;

    int pmType = -1;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, pmType);
    if (type >= HO_TYPE_MAX)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Supported Type(%d, max:%d)!!\n", type, HO_TYPE_MAX);
        return -1;
    }

    const int InterNgIn_RedCap_mapping[HO_TYPE_MAX] = {
        InterNgIn_Att_RedCap,                /*HO_Att*/
        InterNgIn_PrepSucc_RedCap,           /*HO_PrepSucc*/
        InterNgIn_Succ_RedCap,               /*HO_Succ*/
        InterNgIn_PrepFail_E1TimeOut_RedCap, /*HO_PrepFail_E1TimeOut*/
        InterNgIn_PrepFail_F1TimeOut_RedCap, /*HO_PrepFail_F1TimeOut*/
        -1,                                  /*HO_PrepFail_XnTimeOut*/
        -1,                                  /*HO_PrepFail_NgTimeOut*/
        InterNgIn_PrepFail_CpFail_RedCap,    /*HO_PrepFail_CpFail*/
        InterNgIn_PrepFail_E1Fail_RedCap,    /*HO_PrepFail_E1Fail*/
        InterNgIn_PrepFail_F1Fail_RedCap,    /*HO_PrepFail_F1Fail*/
        InterNgIn_PrepFail_NgFail_RedCap,    /*HO_PrepFail_NgFail*/
        -1,                                  /*HO_PrepFail_XnFail*/
        -1,                                  /*HO_PrepFail_N26*/
        InterNgIn_Fail_E1TimeOut_RedCap,     /*HO_Fail_E1TimeOut*/
        InterNgIn_Fail_F1TimeOut_RedCap,     /*HO_Fail_F1TimeOut*/
        -1,                                  /*HO_Fail_XnTimeOut*/
        InterNgIn_Fail_NgTimeOut_RedCap,     /*HO_Fail_NgTimeOut*/
        InterNgIn_Fail_RrcTimeOut_RedCap,    /*HO_Fail_RrcTimeOut*/
        InterNgIn_Fail_CpFail_RedCap,        /*HO_Fail_CpFail*/
        InterNgIn_Fail_E1Fail_RedCap,        /*HO_Fail_E1Fail*/
        InterNgIn_Fail_F1Fail_RedCap,        /*HO_Fail_F1Fail*/
        InterNgIn_Fail_NgFail_RedCap,        /*HO_Fail_NgFail*/
        -1,                                  /*HO_Fail_XnFail*/
        InterNgIn_HandoverCancel_RedCap,     /*HO_HandoverCancel*/
        InterNgIn_RRE_RedCap,                /*HO_RRE*/
    };

    const int InterXnIn_RedCap_mapping[HO_TYPE_MAX] = {
        InterXnIn_Att_RedCap,                /*HO_Att*/
        InterXnIn_PrepSucc_RedCap,           /*HO_PrepSucc*/
        InterXnIn_Succ_RedCap,               /*HO_Succ*/
        InterXnIn_PrepFail_E1TimeOut_RedCap, /*HO_PrepFail_E1TimeOut*/
        InterXnIn_PrepFail_F1TimeOut_RedCap, /*HO_PrepFail_F1TimeOut*/
        -1,                                  /*HO_PrepFail_XnTimeOut*/
        -1,                                  /*HO_PrepFail_NgTimeOut*/
        InterXnIn_PrepFail_CpFail_RedCap,    /*HO_PrepFail_CpFail*/
        InterXnIn_PrepFail_E1Fail_RedCap,    /*HO_PrepFail_E1Fail*/
        InterXnIn_PrepFail_F1Fail_RedCap,    /*HO_PrepFail_F1Fail*/
        -1,                                  /*HO_PrepFail_NgFail*/
        InterXnIn_PrepFail_XnFail_RedCap,    /*HO_PrepFail_XnFail*/
        -1,                                  /*HO_PrepFail_N26*/
        InterXnIn_Fail_E1TimeOut_RedCap,     /*HO_Fail_E1TimeOut*/
        InterXnIn_Fail_F1TimeOut_RedCap,     /*HO_Fail_F1TimeOut*/
        InterXnIn_Fail_XnTimeOut_RedCap,     /*HO_Fail_XnTimeOut*/
        InterXnIn_Fail_NgTimeOut_RedCap,     /*HO_Fail_NgTimeOut*/
        InterXnIn_Fail_RrcTimeOut_RedCap,    /*HO_Fail_RrcTimeOut*/
        InterXnIn_Fail_CpFail_RedCap,        /*HO_Fail_CpFail*/
        InterXnIn_Fail_E1Fail_RedCap,        /*HO_Fail_E1Fail*/
        InterXnIn_Fail_F1Fail_RedCap,        /*HO_Fail_F1Fail*/
        InterXnIn_Fail_NgFail_RedCap,        /*HO_Fail_NgFail*/
        InterXnIn_Fail_XnFail_RedCap,        /*HO_Fail_XnFail*/
        InterXnIn_HandoverCancel_RedCap,     /*HO_HandoverCancel*/
        InterXnIn_RRE_RedCap,                /*HO_RRE*/
    };

    const int IntraGnbIn_RedCap_mapping[HO_TYPE_MAX] = {
        IntraGnbIn_Att_RedCap,                /*HO_Att*/
        IntraGnbIn_PrepSucc_RedCap,           /*HO_PrepSucc*/
        IntraGnbIn_Succ_RedCap,               /*HO_Succ*/
        IntraGnbIn_PrepFail_E1TimeOut_RedCap, /*HO_PrepFail_E1TimeOut*/
        IntraGnbIn_PrepFail_F1TimeOut_RedCap, /*HO_PrepFail_F1TimeOut*/
        -1,                                   /*HO_PrepFail_XnTimeOut*/
        -1,                                   /*HO_PrepFail_NgTimeOut*/
        IntraGnbIn_PrepFail_CpFail_RedCap,    /*HO_PrepFail_CpFail*/
        IntraGnbIn_PrepFail_E1Fail_RedCap,    /*HO_PrepFail_E1Fail*/
        IntraGnbIn_PrepFail_F1Fail_RedCap,    /*HO_PrepFail_F1Fail*/
        -1,                                   /*HO_PrepFail_NgFail*/
        -1,                                   /*HO_PrepFail_XnFail*/
        -1,                                   /*HO_PrepFail_N26*/
        IntraGnbIn_Fail_E1TimeOut_RedCap,     /*HO_Fail_E1TimeOut*/
        IntraGnbIn_Fail_F1TimeOut_RedCap,     /*HO_Fail_F1TimeOut*/
        -1,                                   /*HO_Fail_XnTimeOut*/
        -1,                                   /*HO_Fail_NgTimeOut*/
        IntraGnbIn_Fail_RrcTimeOut_RedCap,    /*HO_Fail_RrcTimeOut*/
        IntraGnbIn_Fail_CpFail_RedCap,        /*HO_Fail_CpFail*/
        IntraGnbIn_Fail_E1Fail_RedCap,        /*HO_Fail_E1Fail*/
        IntraGnbIn_Fail_F1Fail_RedCap,        /*HO_Fail_F1Fail*/
        -1,                                   /*HO_Fail_NgFail*/
        -1,                                   /*HO_Fail_XnFail*/
        IntraGnbIn_HandoverCancel_RedCap,     /*HO_HandoverCancel*/
        IntraGnbIn_RRE_RedCap,                /*HO_RRE*/
    };

    const int InterSysLTE_In_RedCap_mapping[HO_TYPE_MAX] = {
        // IRAT_HO
        InterSysLTE_In_Att_RedCap,                /*HO_Att*/
        InterSysLTE_In_PrepSucc_RedCap,           /*HO_PrepSucc*/
        InterSysLTE_In_Succ_RedCap,               /*HO_Succ*/
        InterSysLTE_In_PrepFail_E1TimeOut_RedCap, /*HO_PrepFail_E1TimeOut*/
        InterSysLTE_In_PrepFail_F1TimeOut_RedCap, /*HO_PrepFail_F1TimeOut*/
        -1,                                       /*HO_PrepFail_XnTimeOut*/
        -1,                                       /*HO_PrepFail_NgTimeOut*/
        InterSysLTE_In_PrepFail_CpFail_RedCap,    /*HO_PrepFail_CpFail*/
        InterSysLTE_In_PrepFail_E1Fail_RedCap,    /*HO_PrepFail_E1Fail*/
        InterSysLTE_In_PrepFail_F1Fail_RedCap,    /*HO_PrepFail_F1Fail*/
        InterSysLTE_In_PrepFail_NgFail_RedCap,    /*HO_PrepFail_NgFail*/
        -1,                                       /*HO_PrepFail_XnFail*/
        -1,                                       /*HO_PrepFail_N26*/
        InterSysLTE_In_Fail_E1TimeOut_RedCap,     /*HO_Fail_E1TimeOut*/
        InterSysLTE_In_Fail_F1TimeOut_RedCap,     /*HO_Fail_F1TimeOut*/
        -1,                                       /*HO_Fail_XnTimeOut*/
        InterSysLTE_In_Fail_NgTimeOut_RedCap,     /*HO_Fail_NgTimeOut*/
        InterSysLTE_In_Fail_RrcTimeOut_RedCap,    /*HO_Fail_RrcTimeOut*/
        InterSysLTE_In_Fail_CpFail_RedCap,        /*HO_Fail_CpFail*/
        InterSysLTE_In_Fail_E1Fail_RedCap,        /*HO_Fail_E1Fail*/
        InterSysLTE_In_Fail_F1Fail_RedCap,        /*HO_Fail_F1Fail*/
        InterSysLTE_In_Fail_NgFail_RedCap,        /*HO_Fail_NgFail*/
        -1,                                       /*HO_Fail_XnFail*/
        InterSysLTE_In_HandoverCancel_RedCap,     /*HO_HandoverCancel*/
        InterSysLTE_In_RRE_RedCap,                /*HO_RRE*/
    };

    if (ptCi->hoInfo.hoType.initiated != HO_TYPE_SA_INTER_SYSTEM_INTER_RAT_HANDOVER)
    {
        if (IS_NEDC_MN(ptCi) || IS_NRDC_MN(ptCi))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Not Supported Statistic Error!!(%d)\n", ptCi->hoInfo.hoType.initiated);
            return -1;
        }
    }

    switch (ptCi->hoInfo.hoType.initiated)
    {
        case HO_TYPE_SA_INTER_GNB_NG_HANDOVER:  // Inter-Gnb NG Handover Incoming
            pmType = InterNgIn_RedCap_mapping[type];
            break;

        case HO_TYPE_SA_INTER_GNB_XN_HANDOVER:  // Inter-Gnb XN Handover Incoming
            pmType = InterXnIn_RedCap_mapping[type];
            break;

        case HO_TYPE_SA_INTRA_GNB_INTER_DU_HANDOVER:  // Intra-Gnb Handover Incoming
        case HO_TYPE_SA_INTRA_GNB_INTRA_DU_HANDOVER:
            pmType = IntraGnbIn_RedCap_mapping[type];
            break;

        case HO_TYPE_SA_INTER_SYSTEM_INTER_RAT_HANDOVER:  // Inter System Inter-RAT NG Handover Incoming // IRAT_HO
            pmType = InterSysLTE_In_RedCap_mapping[type];
            break;

        default:
            break;
    }

    if (pmType == -1)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Supported Statistic Error!!(%d)\n", ptCi->hoInfo.hoType.initiated);
    }

    return pmType;
}

int getTypeFromIn(callInfo_type *ptCi, enumHoStatType type)
{
    AUTO_TRACE_FUNC;

    int pmType = -1;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, pmType);
    if (type >= HO_TYPE_MAX)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Supported Type(%d, max:%d)!!\n", type, HO_TYPE_MAX);
        return -1;
    }

    const int InterNgIn_mapping[HO_TYPE_MAX] = {
        InterNgIn_Att,                /*HO_Att*/
        InterNgIn_PrepSucc,           /*HO_PrepSucc*/
        InterNgIn_Succ,               /*HO_Succ*/
        InterNgIn_PrepFail_E1TimeOut, /*HO_PrepFail_E1TimeOut*/
        InterNgIn_PrepFail_F1TimeOut, /*HO_PrepFail_F1TimeOut*/
        -1,                           /*HO_PrepFail_XnTimeOut*/
        -1,                           /*HO_PrepFail_NgTimeOut*/
        InterNgIn_PrepFail_CpFail,    /*HO_PrepFail_CpFail*/
        InterNgIn_PrepFail_E1Fail,    /*HO_PrepFail_E1Fail*/
        InterNgIn_PrepFail_F1Fail,    /*HO_PrepFail_F1Fail*/
        InterNgIn_PrepFail_NgFail,    /*HO_PrepFail_NgFail*/
        -1,                           /*HO_PrepFail_XnFail*/
        -1,                           /*HO_PrepFail_N26*/
        InterNgIn_Fail_E1TimeOut,     /*HO_Fail_E1TimeOut*/
        InterNgIn_Fail_F1TimeOut,     /*HO_Fail_F1TimeOut*/
        -1,                           /*HO_Fail_XnTimeOut*/
        InterNgIn_Fail_NgTimeOut,     /*HO_Fail_NgTimeOut*/
        InterNgIn_Fail_RrcTimeOut,    /*HO_Fail_RrcTimeOut*/
        InterNgIn_Fail_CpFail,        /*HO_Fail_CpFail*/
        InterNgIn_Fail_E1Fail,        /*HO_Fail_E1Fail*/
        InterNgIn_Fail_F1Fail,        /*HO_Fail_F1Fail*/
        InterNgIn_Fail_NgFail,        /*HO_Fail_NgFail*/
        -1,                           /*HO_Fail_XnFail*/
        InterNgIn_HandoverCancel,     /*HO_HandoverCancel*/
        InterNgIn_RRE,                /*HO_RRE*/
    };

    const int InterXnIn_mapping[HO_TYPE_MAX] = {
        InterXnIn_Att,                /*HO_Att*/
        InterXnIn_PrepSucc,           /*HO_PrepSucc*/
        InterXnIn_Succ,               /*HO_Succ*/
        InterXnIn_PrepFail_E1TimeOut, /*HO_PrepFail_E1TimeOut*/
        InterXnIn_PrepFail_F1TimeOut, /*HO_PrepFail_F1TimeOut*/
        -1,                           /*HO_PrepFail_XnTimeOut*/
        -1,                           /*HO_PrepFail_NgTimeOut*/
        InterXnIn_PrepFail_CpFail,    /*HO_PrepFail_CpFail*/
        InterXnIn_PrepFail_E1Fail,    /*HO_PrepFail_E1Fail*/
        InterXnIn_PrepFail_F1Fail,    /*HO_PrepFail_F1Fail*/
        -1,                           /*HO_PrepFail_NgFail*/
        InterXnIn_PrepFail_XnFail,    /*HO_PrepFail_XnFail*/
        -1,                           /*HO_PrepFail_N26*/
        InterXnIn_Fail_E1TimeOut,     /*HO_Fail_E1TimeOut*/
        InterXnIn_Fail_F1TimeOut,     /*HO_Fail_F1TimeOut*/
        InterXnIn_Fail_XnTimeOut,     /*HO_Fail_XnTimeOut*/
        InterXnIn_Fail_NgTimeOut,     /*HO_Fail_NgTimeOut*/
        InterXnIn_Fail_RrcTimeOut,    /*HO_Fail_RrcTimeOut*/
        InterXnIn_Fail_CpFail,        /*HO_Fail_CpFail*/
        InterXnIn_Fail_E1Fail,        /*HO_Fail_E1Fail*/
        InterXnIn_Fail_F1Fail,        /*HO_Fail_F1Fail*/
        InterXnIn_Fail_NgFail,        /*HO_Fail_NgFail*/
        InterXnIn_Fail_XnFail,        /*HO_Fail_XnFail*/
        InterXnIn_HandoverCancel,     /*HO_HandoverCancel*/
        InterXnIn_RRE,                /*HO_RRE*/
    };

    const int IntraGnbIn_mapping[HO_TYPE_MAX] = {
        IntraGnbIn_Att,                /*HO_Att*/
        IntraGnbIn_PrepSucc,           /*HO_PrepSucc*/
        IntraGnbIn_Succ,               /*HO_Succ*/
        IntraGnbIn_PrepFail_E1TimeOut, /*HO_PrepFail_E1TimeOut*/
        IntraGnbIn_PrepFail_F1TimeOut, /*HO_PrepFail_F1TimeOut*/
        -1,                            /*HO_PrepFail_XnTimeOut*/
        -1,                            /*HO_PrepFail_NgTimeOut*/
        IntraGnbIn_PrepFail_CpFail,    /*HO_PrepFail_CpFail*/
        IntraGnbIn_PrepFail_E1Fail,    /*HO_PrepFail_E1Fail*/
        IntraGnbIn_PrepFail_F1Fail,    /*HO_PrepFail_F1Fail*/
        -1,                            /*HO_PrepFail_NgFail*/
        -1,                            /*HO_PrepFail_XnFail*/
        -1,                            /*HO_PrepFail_N26*/
        IntraGnbIn_Fail_E1TimeOut,     /*HO_Fail_E1TimeOut*/
        IntraGnbIn_Fail_F1TimeOut,     /*HO_Fail_F1TimeOut*/
        -1,                            /*HO_Fail_XnTimeOut*/
        -1,                            /*HO_Fail_NgTimeOut*/
        IntraGnbIn_Fail_RrcTimeOut,    /*HO_Fail_RrcTimeOut*/
        IntraGnbIn_Fail_CpFail,        /*HO_Fail_CpFail*/
        IntraGnbIn_Fail_E1Fail,        /*HO_Fail_E1Fail*/
        IntraGnbIn_Fail_F1Fail,        /*HO_Fail_F1Fail*/
        -1,                            /*HO_Fail_NgFail*/
        -1,                            /*HO_Fail_XnFail*/
        IntraGnbIn_HandoverCancel,     /*HO_HandoverCancel*/
        IntraGnbIn_RRE,                /*HO_RRE*/
    };

    const int InterSysLTE_In_mapping[HO_TYPE_MAX] = {
        // IRAT_HO
        InterSysLTE_In_Att,                /*HO_Att*/
        InterSysLTE_In_PrepSucc,           /*HO_PrepSucc*/
        InterSysLTE_In_Succ,               /*HO_Succ*/
        InterSysLTE_In_PrepFail_E1TimeOut, /*HO_PrepFail_E1TimeOut*/
        InterSysLTE_In_PrepFail_F1TimeOut, /*HO_PrepFail_F1TimeOut*/
        -1,                                /*HO_PrepFail_XnTimeOut*/
        -1,                                /*HO_PrepFail_NgTimeOut*/
        InterSysLTE_In_PrepFail_CpFail,    /*HO_PrepFail_CpFail*/
        InterSysLTE_In_PrepFail_E1Fail,    /*HO_PrepFail_E1Fail*/
        InterSysLTE_In_PrepFail_F1Fail,    /*HO_PrepFail_F1Fail*/
        InterSysLTE_In_PrepFail_NgFail,    /*HO_PrepFail_NgFail*/
        -1,                                /*HO_PrepFail_XnFail*/
        -1,                                /*HO_PrepFail_N26*/
        InterSysLTE_In_Fail_E1TimeOut,     /*HO_Fail_E1TimeOut*/
        InterSysLTE_In_Fail_F1TimeOut,     /*HO_Fail_F1TimeOut*/
        -1,                                /*HO_Fail_XnTimeOut*/
        InterSysLTE_In_Fail_NgTimeOut,     /*HO_Fail_NgTimeOut*/
        InterSysLTE_In_Fail_RrcTimeOut,    /*HO_Fail_RrcTimeOut*/
        InterSysLTE_In_Fail_CpFail,        /*HO_Fail_CpFail*/
        InterSysLTE_In_Fail_E1Fail,        /*HO_Fail_E1Fail*/
        InterSysLTE_In_Fail_F1Fail,        /*HO_Fail_F1Fail*/
        InterSysLTE_In_Fail_NgFail,        /*HO_Fail_NgFail*/
        -1,                                /*HO_Fail_XnFail*/
        InterSysLTE_In_HandoverCancel,     /*HO_HandoverCancel*/
        InterSysLTE_In_RRE,                /*HO_RRE*/
    };

    auto intraGnbInPmTypeWithNedc = [](int Type) -> int
    {
        switch (Type)
        {
            case IntraGnbIn_RRE:
                return IntraGnbInWithNedc_RRE;
            default:
                return Type + (IntraGnbInWithNedc_Att - IntraGnbIn_Att);
        }
    };

    auto intraGnbInPmTypeWithNrdc = [](int Type) -> int
    {
        switch (Type)
        {
            case IntraGnbIn_RRE:
                return IntraGnbInWithNrdc_RRE;
            default:
                return Type + (IntraGnbInWithNrdc_Att - IntraGnbIn_Att);
        }
    };

    switch (ptCi->hoInfo.hoType.initiated)
    {
        case HO_TYPE_SA_INTER_GNB_NG_HANDOVER:  // Inter-Gnb NG Handover Incoming
            pmType = InterNgIn_mapping[type];

            if (pmType == -1) break;  // Not Found Mapping Stat

            if (IS_NEDC_MN(ptCi))
            {
                pmType += (InterNgInWithNedc_Att - InterNgIn_Att);
            }
            if (IS_NRDC_MN(ptCi))
            {
                pmType += (InterNgInWithNrdc_Att - InterNgIn_Att);
            }
            break;

        case HO_TYPE_SA_INTER_GNB_XN_HANDOVER:  // Inter-Gnb XN Handover Incoming
            pmType = InterXnIn_mapping[type];

            if (pmType == -1) break;  // Not Found Mapping Stat

            if (IS_NEDC_MN(ptCi))
            {
                pmType += (InterXnInWithNedc_Att - InterXnIn_Att);
            }
            if (IS_NRDC_MN(ptCi))
            {
                pmType += (InterXnInWithNrdc_Att - InterXnIn_Att);
            }
            break;

        case HO_TYPE_SA_INTRA_GNB_INTER_DU_HANDOVER:  // Intra-Gnb Handover Incoming
        case HO_TYPE_SA_INTRA_GNB_INTRA_DU_HANDOVER:
            pmType = IntraGnbIn_mapping[type];

            if (pmType == -1) break;  // Not Found Mapping Stat

            if (IS_NEDC_MN(ptCi))
            {
                pmType = intraGnbInPmTypeWithNedc(pmType);
            }
            if (IS_NRDC_MN(ptCi))
            {
                pmType = intraGnbInPmTypeWithNrdc(pmType);
            }
            break;

        case HO_TYPE_SA_INTER_SYSTEM_INTER_RAT_HANDOVER:  // Inter System Inter-RAT NG Handover Incoming // IRAT_HO
            pmType = InterSysLTE_In_mapping[type];
            break;

        default:
            break;
    }

    if (pmType == -1)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Supported Statistic Error!!(%d)\n", ptCi->hoInfo.hoType.initiated);
    }

    return pmType;
}

/**
 * @brief     Select counter family and type for initial call setup or reestablishment
 * @param     ptCi : callInfo
 * @param     type : STAT_RRC_ESTAB stat type
 */
void VLIB_Stat_RrcEstabResult(callInfo_type *ptCi, int type)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->reestablishFlag == TRUE)
    {
        switch (type)
        {
            case ConnEstabSucc:
                MACRO_RRE_STAT(ptCi, ReEstabRrcSetupSucc);
                VLIB_SetNoAttemptFlag(ptCi, STAT_RRC_REESTAB);
                break;
            case ConnEstabFail_CpFail:
            case ConnEstabReject_CpFail:
                MACRO_RRE_STAT(ptCi, ReEstabFail_CpFail);
                break;
            case ConnEstabFail_RrcTimeout:
                MACRO_RRE_STAT(ptCi, ReEstabFail_RrcSetupTimeout);
                break;
            default:
                VCCB_PRINT_CALL_ERROR(ptCi, "STAT_RRC_ESTAB Type(%d) mapping ERROR!\n", type);
                break;
        }
    }
    else
    {
        int famIdx = GET_FAMIDX(STAT_RRC_ESTAB);
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, MAX_VCCB_FAMILY_TYPE - 1);
        if (GET_CALL_STAT_FLAG(ptCi, famIdx) == ATTEMPT_MADE)
        {
            MACRO_STAT_PMCC(STAT_RRC_ESTAB, type, ptCi, 0, 0, 0, 0, 0);
        }

    }

    return;
}

VCCB_STATIC_INLINE
float FnVCCB_GetTimeDiffForHO(const struct timespec &startTime, const struct timespec &endTime)
{
    float HOExecTime = (float)(endTime.tv_sec - startTime.tv_sec) * 1000;    // calculate time from sec to ms
    HOExecTime += (float)(endTime.tv_nsec - startTime.tv_nsec) / 1000000.f;  // calculate time from nsec to ms
    return HOExecTime;
}

VCCB_STATIC
void VLIB_StatSaHoTime(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // Calculate HO TIME
    const float HOExecTime = FnVCCB_GetTimeDiffForHO(ptCi->hoInfo.HOtHoAck, ptCi->hoInfo.HOtReconfigCmpl);

    if (HOExecTime < 0)  // Minus Value is Invalid
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid Value!! HoExecTime=(%f)\n", (double)HOExecTime);
        return;
    }

    VCCB_PRINT_CALL_DATA(ptCi, "Collect HoExecutationTime(HO_TIME)=(%f)\n", (double)HOExecTime);

    // PCELL HO CASE (STATE_HO_TIME)
    auto getHoTimeMType = [&ptCi]()
    {
        switch (ptCi->hoInfo.hoType.initiated)
        {
            case HO_TYPE_SA_INTER_GNB_NG_HANDOVER:
                if (IS_REDCAP_UE(ptCi))
                    return InterNg_HoTimeAvg_RedCap;
                else
                    return InterNg_HoTimeAvg;

            case HO_TYPE_SA_INTER_GNB_XN_HANDOVER:
                if (IS_REDCAP_UE(ptCi))
                    return InterXn_HoTimeAvg_RedCap;
                else
                    return InterXn_HoTimeAvg;

            case HO_TYPE_SA_INTRA_GNB_INTER_DU_HANDOVER:
            case HO_TYPE_SA_INTRA_GNB_INTRA_DU_HANDOVER:
                if (IS_REDCAP_UE(ptCi))
                    return IntraGnb_HoTimeAvg_RedCap;
                else
                    return IntraGnb_HoTimeAvg;

            case HO_TYPE_SA_INTER_SYSTEM_INTER_RAT_HANDOVER: // IRAT_HO_23B
                if (IS_REDCAP_UE(ptCi))
                    return InterRatIn_HoTimeAvg_RedCap;
                else
                    return InterRatIn_HoTimeAvg;

            default:
                return STAT_HO_TIME_END;
        }

    };

    const STAT_HO_TIME_ITEM mType = getHoTimeMType();

    // If Valid Range
    if (mType < STAT_HO_TIME_END)
    {
        // Main Feature ID : FGR-MC1008/1009/1010 FR520
        MACRO_STAT_PMGAUGE(STAT_HO_TIME, mType, ptCi, HOExecTime, ptCi->gnbNum, ptCi->hoInfo.cellIdentity, 0, 0);
    }

    // Other Feature ----------------------------------------------------------

}

void VLIB_StatSaPsCellChangeTime(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    // Calculate PSCELL CHANGE TIME
    const float HOExecTime = FnVCCB_GetTimeDiffForHO(ptCi->hoInfo.HOtHoAck, ptCi->hoInfo.HOtReconfigCmpl);

    if (HOExecTime < 0)  // Minus Value is Invalid
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid Value!! HoExecTime=(%f)\n", (double)HOExecTime);
        return;
    }

    VCCB_PRINT_CALL_DATA(ptCi, "Collect HoExecutationTime(PSCELL_CHANGE_TIME)=(%f)\n", (double)HOExecTime);

    // PSCELL HO CASE (STAT_PSCELL_CHANGE_TIME)
    auto getChangeTimeMType = [&ptCi]()
    {
        switch (ptCi->hoInfo.hoType.initiated)
        {
            // SN Init Mobility (Intra-SN)
            case HO_TYPE_SA_SGNB_INITIATED:

                // SN Init Mobility (Intra-SN) with SRB3
                if (ptCi->hoInfo.hoUsingSRB3 == TRUE)
                    return IntraSnViaSrb3_HoTimeAvg;

                // SN Init Mobility (Intra-SN) without SRB3
                return IntraSn_HoTimeAvg;

            // SN Init Mobility (Inter-SN)
            case HO_TYPE_SA_SGNB_INITIATED_INTER_SN_CHANGE:
                return InterSn_HoTimeAvg;

            default:
                return STAT_PSCELL_CHANGE_TIME_END;
        }
    };

    const STAT_PSCELL_CHANGE_TIME_ITEM mType = getChangeTimeMType();

    // If Valid Range
    if (mType < STAT_PSCELL_CHANGE_TIME_END)
    {
        MACRO_STAT_PMGAUGE(STAT_PSCELL_CHANGE_TIME, mType, ptCi, HOExecTime, ptCi->gnbNum, pCell->cellIdentity, 0, 0);
    }

    // Other Feature ----------------------------------------------------------

}

VCCB_STATIC
void FnVCCB_StatHoAccessTime(callInfo_type *ptCi, cgi_type cgi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_VALID_CELLNUM_VOID(ptCi->servCellNum);

    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];

    conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForCGI(ptCi, cgi);
    VALID_E_POINT_CHECK_VOID(ptCondCell);

    // Calculate HO TIME (ACCESS TIME) - calculate time from sec to ms
    const float HOAccessTime = FnVCCB_GetTimeDiffForHO(ptCondCell->tCondCellSetupCmpl, ptCi->condHoInfo.tXnHandoverSuccess);

    if (HOAccessTime < 0)  // Minus Value is Invalid
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid Value!! HoAccessTime=(%f)\n", (double)HOAccessTime);
        return;
    }

    VCCB_PRINT_CALL_DATA(ptCi, "Collect HoAccessTime(HO_TIME)=(%f)\n", (double)HOAccessTime);

    // PCELL HO CASE (STAT_HO_TIME)
    if (IS_REDCAP_UE(ptCi))
    {
        MACRO_STAT_PMGAUGE(STAT_HO_TIME, ChoXn_AccessTimeAvg_RedCap, ptCi, HOAccessTime, ptCi->gnbNum, pCell->cellIdentity, 0, 0);
    }
    else
    {
        MACRO_STAT_PMGAUGE(STAT_HO_TIME, ChoXn_AccessTimeAvg, ptCi, HOAccessTime, ptCi->gnbNum, pCell->cellIdentity, 0, 0);
    }
}

void VLIB_CollectStatSaOutgoingHoTime(callInfo_type *ptCi) // IRAT_HO_23B
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    // Check Inter RAT - as of 23B
    if (HO_TYPE_SA_INTER_SYSTEM_INTER_RAT_HANDOVER != ptCi->hoInfo.hoType.initiated) return;

    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    // Calculate HO TIME
    const float HOExecTime = FnVCCB_GetTimeDiffForHO(ptCi->hoInfo.HOtHoRqd, ptCi->hoInfo.HOtUeCtxtRelCmpl);

    if (HOExecTime < 0)  // Minus Value is Invalid
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid Outgoing HoExecTime=(%f)\n", (double)HOExecTime);
        return;
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "Collect Outgoing HO_TIME=(%f)\n", (double)HOExecTime);

    // STAT_HO_TIME
    auto getMType = [&ptCi]()
    {
        switch (ptCi->hoInfo.hoType.initiated)
        {
            case HO_TYPE_SA_INTER_SYSTEM_INTER_RAT_HANDOVER:
                if (CauseNgapRadioNetworkLayerSuccessfulHandover == ptCi->cause.ngCause)
                {
                    if (IS_REDCAP_UE(ptCi))
                    {
                        if (IS_EPS_FALLBACK_CASE(ptCi)) // EPS Fallback
                        {
                            return InterRatOut_EPSFallback_HoTimeAvg_RedCap;
                        }
                        else if (TRUE == ptCi->hoInfo.isVonrCall)  // VoNR
                        {
                            return InterRatOut_VoNR_HoTimeAvg_RedCap;
                        }
                    }
                    else
                    {
                        if (IS_EPS_FALLBACK_CASE(ptCi)) // EPS Fallback
                        {
                            return InterRatOut_EPSFallback_HoTimeAvg;
                        }
                        else if (TRUE == ptCi->hoInfo.isVonrCall)  // VoNR
                        {
                            return InterRatOut_VoNR_HoTimeAvg;
                        }
                    }
                }

                VCCB_PRINT_CALL_COMMENT(ptCi,
                        "[HO_OUT_TIME] IRAT ngCause:%d, SuccessfulHandover(%d) NOT VoNR and EPS FB \n",
                        ptCi->cause.ngCause, CauseNgapRadioNetworkLayerSuccessfulHandover);

                return STAT_HO_TIME_END;

            default:
                return STAT_HO_TIME_END;
        }
    };

    const STAT_HO_TIME_ITEM mType = getMType();

    // If Valid Range
    if (mType < STAT_HO_TIME_END)
    {
        MACRO_STAT_PMGAUGE(STAT_HO_TIME, mType, ptCi, HOExecTime, ptCi->gnbNum, pCell->cellIdentity, 0, 0);
    }

}

/**
 * @brief     Indicates whether or not to collect Incoming (Hand-In) statistics of SA Handover.
 * @param     ptCi : callInfo
 * @return    true,false / bool
 */
static bool FnVCCB_IsStatSaHandoverIncoming(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    switch (ptCi->hoInfo.hoType.initiated)
    {
        /* Inter-gNB */
        case HO_TYPE_SA_INTER_SYSTEM_INTER_RAT_HANDOVER:  // IRAT_HO
        case HO_TYPE_SA_INTRA_SYSTEM_INTER_RAT_HANDOVER:  // TBD
        case HO_TYPE_SA_INTER_GNB_NG_HANDOVER:
        case HO_TYPE_SA_INTER_GNB_XN_HANDOVER:
            if (ptCi->hoInfo.isTarget == True) return true;  // HO_IN (Incoming)

            return false;

        /* Intra-gNB */
        case HO_TYPE_SA_INTRA_GNB_INTER_DU_HANDOVER:
        case HO_TYPE_SA_INTRA_GNB_INTRA_DU_HANDOVER:
            return true;  // HO_IN (Incoming)

        /* Other */
        default:
            return false;
    }
}

/**
 * @brief     Indicates whether or not to collect Outgoing (Hand-Out) statistics of SA Handover.
 * @param     ptCi : callInfo
 * @return    true,false / bool
 */
static bool FnVCCB_IsStatSaHandoverOutGoing(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    switch (ptCi->hoInfo.hoType.initiated)
    {
        /* Inter-gNB */
        case HO_TYPE_SA_INTER_SYSTEM_INTER_RAT_HANDOVER:  // IRAT_HO
        case HO_TYPE_SA_INTRA_SYSTEM_INTER_RAT_HANDOVER:  // TBD
        case HO_TYPE_SA_INTER_GNB_NG_HANDOVER:
        case HO_TYPE_SA_INTER_GNB_XN_HANDOVER:
            if (ptCi->hoInfo.isTarget == FALSE) return true;  // HO_IN (Outgoing)

            return false;

        /* Intra-gNB */
        case HO_TYPE_SA_INTRA_GNB_INTER_DU_HANDOVER:
        case HO_TYPE_SA_INTRA_GNB_INTRA_DU_HANDOVER:
            return true;  // HO_IN (Outgoing)

        /* Other */
        default:
            return false;
    }
}

/**
 * @brief     This function selects what to collect Handover In statistics from.
 * @param     ptCi : callInfo
 * @return    family id / STAT_PM_FAMILY_ID_TYPE
 */
static STAT_PM_FAMILY_ID_TYPE FnVCCB_GetStatSaHandoverInFamilyId(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, STAT_HO_IN);

    if (IS_REDCAP_UE(ptCi))
    {
        if (ptCi->hoInfo.hoType.rat == HO_TYPE_INTER_RAT)  // IRAT_HO
        {
            return STAT_HO_EUTRAN_IN_REDCAP;  // Main Feature ID : FGR-MC3002 FR130
        }

        // HO_TYPE_INTRA_RAT (INTRA-NR)

        return STAT_HO_IN_REDCAP;  // Main Feature ID : FGR-MC1008FGR-MC1008/1009/1010 FR510
    }
    else
    {
        if (ptCi->hoInfo.hoType.rat == HO_TYPE_INTER_RAT)  // IRAT_HO
        {
            return STAT_HO_EUTRAN_IN;  // Main Feature ID : FGR-MC3002 FR130
        }

        // HO_TYPE_INTRA_RAT (INTRA-NR)

        return STAT_HO_IN;  // Main Feature ID : FGR-MC1008FGR-MC1008/1009/1010 FR510
    }
}

static STAT_PM_FAMILY_ID_TYPE FnVCCB_GetSaHandInServiceTypeFamilyId(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, STAT_HO_IN_SERVICE_TYPE);

    if (ptCi->hoInfo.hoType.rat == HO_TYPE_INTER_RAT)
    {
        return STAT_HO_EUTRAN_IN_SERVICE_TYPE;
    }
    else
    {
        return STAT_HO_IN_SERVICE_TYPE;
    }
}

void FnVCCB_StatSaHandInServiceType(callInfo_type *ptCi, enumHoStatType type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    int typeId = getTypeFromIn(ptCi, type);
    if (typeId != -1)
    {
        STAT_PM_FAMILY_ID_TYPE mFamily = FnVCCB_GetSaHandInServiceTypeFamilyId(ptCi);

        VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];

        if (not FnVCCB_IsSupportServiceTypeYang(mFamily, pGnb)) return;

        // Mismatch between STAT_HO_IN and STAT_HO_IN_SERVICE_TYPE
        if (mFamily == STAT_HO_IN_SERVICE_TYPE && typeId >= STAT_HO_IN_SERVICE_TYPE_END) return;
        if (mFamily == STAT_HO_EUTRAN_IN_SERVICE_TYPE && typeId >= STAT_HO_EUTRAN_IN_SERVICE_TYPE_END) return;

        FnVCCB_LibStatPmCC_Mobility(mFamily, typeId, ptCi, 0, fnName);
    }
}


/**
 * @brief     This function is used for the purpose of collecting HandIn statistics.
 * @param     ptCi : callInfo
 * @param     type : stat type
 * @param     fnName : caller function name
 */
static void FnVCCB_StatSaHandoverIncoming(callInfo_type *ptCi, enumHoStatType type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);

    // FGR-LC0712 FR210 (25B) Only the STAT_INTRA_NR_LB_HO family is collected and no other statistics are collected.
    if (ptCi->hoInfo.isVoNrLbHo == TRUE) return;

    int typeId = -1;
    if (IS_REDCAP_UE(ptCi))
    {
        typeId = getTypeFromInRedCap(ptCi, type);
    }
    else
    {
        typeId = getTypeFromIn(ptCi, type);
    }

    if (typeId != -1)
    {
        STAT_PM_FAMILY_ID_TYPE collectFamilyId = FnVCCB_GetStatSaHandoverInFamilyId(ptCi);
        FnVCCB_LibStatPmCC_Mobility(collectFamilyId, typeId, ptCi, 0, fnName);
    }

    // Service Type STAT
    FnVCCB_StatSaHandInServiceType(ptCi, type, fnName);

    // HO_TIME Incoming case
    if (type == HO_Succ)
    {
        VLIB_StatSaHoTime(ptCi);
    }
}

/**
 * @brief     This function selects what to collect Handover Out statistics from.
 * @param     ptCi : callInfo
 * @return    family id / STAT_PM_FAMILY_ID_TYPE
 */
static STAT_PM_FAMILY_ID_TYPE FnVCCB_GetStatSaHandoverOutFamilyId(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, STAT_HO_OUT);

    if (ptCi->hoInfo.hoType.rat == HO_TYPE_INTER_RAT)  // IRAT_HO
    {
        if (IS_FALLBACK_CASE(ptCi))
        {
            return STAT_HO_EUTRAN_OUT_FALLBACK;  // Main Feature ID : FGR-MC3002 FR101
        }

        return STAT_HO_EUTRAN_OUT;  // Main Feature ID : FGR-MC3002 FR100
    }

    // HO_TYPE_INTRA_RAT (INTRA-NR)

    return STAT_HO_OUT;  // Main Feature ID : FGR-MC1008/1009/1010 FR500
}

void FnVCCB_StatSaHandOutFreqServiceType(callInfo_type *ptCi, enumHoStatType type, uint32_t tgtSsbFreq, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);

    int typeId = FnVCCB_GetOutTypeByFreq(ptCi, type, tgtSsbFreq);
    if (typeId == -1) return;

    if (VCCB_IS_INTER_FREQ_SSB_FREQ(ptCi->servCellNum, tgtSsbFreq))
    {
        if (typeId >= STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE_END) return;
        FnVCCB_LibStatPmCC_Mobility(STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE, typeId, ptCi, tgtSsbFreq, fnName);
    }
    else
    {
        if (typeId >= STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE_END) return;
        FnVCCB_LibStatPmCC_Mobility(STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE, typeId, ptCi, 0, fnName);
    }
}

/**
 * @brief     This function is used for the purpose of additionally collecting Handover Out statistics in units of
 * frequency.
 * @param     ptCi : callInfo
 * @param     type : stat type
 * @param     fnName : caller function name
 */
static void FnVCCB_StatSaHandoverOutgoing_FreqBaseStatistic(callInfo_type *ptCi, enumHoStatType type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);

    uint32_t tgtSsbFreq = ptCi->hoInfo.tgtSsbFreq;

    if (IS_REDCAP_UE(ptCi))
    {
        int typeId = FnVCCB_GetOutTypeByFreqRedCap(ptCi, type, tgtSsbFreq);
        if (typeId != -1)
        {
            if (VCCB_IS_INTER_FREQ_SSB_FREQ(ptCi->servCellNum, tgtSsbFreq))
            {
                // Main Feature ID : FGR-MC1007 FR800
                FnVCCB_LibStatPmCC_Mobility(STAT_HO_INTER_FREQ_OUT_REDCAP, typeId, ptCi, tgtSsbFreq, fnName);
            }
            else
            {
                // Main Feature ID : FGR-MC1007 FR810
                FnVCCB_LibStatPmCC_Mobility(STAT_HO_INTRA_FREQ_OUT_REDCAP, typeId, ptCi, 0, fnName);
            }
        }
    }
    else
    {
        int typeId = FnVCCB_GetOutTypeByFreq(ptCi, type, tgtSsbFreq);
        if (typeId != -1)
        {
            if (VCCB_IS_INTER_FREQ_SSB_FREQ(ptCi->servCellNum, tgtSsbFreq))
            {
                // Main Feature ID : FGR-MC1007 FR800
                FnVCCB_LibStatPmCC_Mobility(STAT_HO_INTER_FREQ_OUT, typeId, ptCi, tgtSsbFreq, fnName);
            }
            else
            {
                // Main Feature ID : FGR-MC1007 FR810
                FnVCCB_LibStatPmCC_Mobility(STAT_HO_INTRA_FREQ_OUT, typeId, ptCi, 0, fnName);
            }
        }
    }

    // Service Type STAT - Freqeuncy
    FnVCCB_StatSaHandOutFreqServiceType(ptCi, type, tgtSsbFreq, fnName);
}

/**
 * @brief     This function is used for the purpose of additionally collecting Handover Out statistics in units of plmn.
 * @param     ptCi : callInfo
 * @param     type : stat type
 * @param     fnName : caller function name
 */
static void FnVCCB_StatSaHandoverOutgoing_PlmnBaseStatistic(callInfo_type *ptCi, enumHoStatType type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);

    bool isInterPlmn = VCCB_IS_INTER_PLMN(ptCi->ueInfo.servedPlmn, ptCi->hoInfo.tgtPlmn);
    int type_attempt = isInterPlmn? InterPlmnHoOut_Att : IntraPlmnHoOut_Att;
    int type_prepSucc = isInterPlmn? InterPlmnHoOut_PrepSucc : IntraPlmnHoOut_PrepSucc;
    int type_succ = isInterPlmn? InterPlmnHoOut_Succ : IntraPlmnHoOut_Succ;

    const int PLMN_HO_OUT_FAMILY_IDX = GET_FAMIDX(STAT_PLMN_HO_OUT);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(PLMN_HO_OUT_FAMILY_IDX, 0, (MAX_VCCB_FAMILY_TYPE - 1));

    switch (type)
    {
        case HO_Att:
            if(GET_CALL_STAT_FLAG(ptCi, PLMN_HO_OUT_FAMILY_IDX) == NO_ATTEMPT)
            {
                SET_CALL_STAT_FLAG(ptCi, PLMN_HO_OUT_FAMILY_IDX, ATTEMPT_MADE);
            }
            break;
        case HO_PrepSucc:
            if (GET_CALL_STAT_FLAG(ptCi, PLMN_HO_OUT_FAMILY_IDX) == ATTEMPT_MADE)
            {
                SET_CALL_STAT_FLAG(ptCi, PLMN_HO_OUT_FAMILY_IDX, PREP_SUCCESS_MADE);
            }
            break;
        case HO_Succ:
            if (GET_CALL_STAT_FLAG(ptCi, PLMN_HO_OUT_FAMILY_IDX) == PREP_SUCCESS_MADE)
            {
                MACRO_STAT_PMCC(STAT_PLMN_HO_OUT, type_attempt, ptCi, 0, 0, 0, 0, 0);
                MACRO_STAT_PMCC(STAT_PLMN_HO_OUT, type_prepSucc, ptCi, 0, 0, 0, 0, 0);
                MACRO_STAT_PMCC(STAT_PLMN_HO_OUT, type_succ, ptCi, 0, 0, 0, 0, 0);
            }
            SET_CALL_STAT_FLAG(ptCi, PLMN_HO_OUT_FAMILY_IDX, NO_ATTEMPT);
            break;
        default:
            if (GET_CALL_STAT_FLAG(ptCi, PLMN_HO_OUT_FAMILY_IDX) == ATTEMPT_MADE)
            {
                MACRO_STAT_PMCC(STAT_PLMN_HO_OUT, type_attempt, ptCi, 0, 0, 0, 0, 0);
            }
            else if (GET_CALL_STAT_FLAG(ptCi, PLMN_HO_OUT_FAMILY_IDX) == PREP_SUCCESS_MADE)
            {
                MACRO_STAT_PMCC(STAT_PLMN_HO_OUT, type_attempt, ptCi, 0, 0, 0, 0, 0);
                MACRO_STAT_PMCC(STAT_PLMN_HO_OUT, type_prepSucc, ptCi, 0, 0, 0, 0, 0);

            }
            SET_CALL_STAT_FLAG(ptCi, PLMN_HO_OUT_FAMILY_IDX, NO_ATTEMPT);
            break;
    }

    return;
}

void FnVCCB_StatSaHandOutEutraFreqServiceType(callInfo_type *ptCi, enumHoStatType type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);

    int typeId = FnVCCB_GetOutTypeByEutraFreq(ptCi, type);
    if (typeId == -1) return;

    FnVCCB_LibStatPmCC_Mobility(STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE, typeId, ptCi, 0, fnName);
}

void FnVCCB_StatSaHandoverOutgoing_EutraFreqBaseStatistic(callInfo_type *ptCi, enumHoStatType type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);

    if (IS_REDCAP_UE(ptCi))
    {
        int typeId = FnVCCB_GetOutTypeByEutraFreqRedCap(ptCi, type);
        if (typeId != -1)
        {
            FnVCCB_LibStatPmCC_Mobility(STAT_HO_EUTRAN_FREQ_OUT_REDCAP, typeId, ptCi, 0, fnName);
        }
    }
    else
    {
        int typeId = FnVCCB_GetOutTypeByEutraFreq(ptCi, type);
        if (typeId != -1)
        {
            FnVCCB_LibStatPmCC_Mobility(STAT_HO_EUTRAN_FREQ_OUT, typeId, ptCi, 0, fnName);
        }
    }

    // Service Type STAT - EUTRA Freqeuncy
    FnVCCB_StatSaHandOutEutraFreqServiceType(ptCi, type, fnName);
}

STAT_PM_FAMILY_ID_TYPE FnVCCB_GetSaHandOutServiceTypeFamilyId(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, STAT_HO_OUT_SERVICE_TYPE);

    if (ptCi->hoInfo.hoType.rat == HO_TYPE_INTER_RAT)
    {
        if (IS_FALLBACK_CASE(ptCi))
        {
            return STAT_HO_EUTRAN_OUT_FALLBACK_SERVICE_TYPE;
        }
        return STAT_HO_EUTRAN_OUT_SERVICE_TYPE;
    }

    return STAT_HO_OUT_SERVICE_TYPE;
}

void FnVCCB_StatSaHandOutServiceType(callInfo_type *ptCi, enumHoStatType type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    int typeId = getTypeFromOut(ptCi, type);
    if (typeId != -1)
    {
        STAT_PM_FAMILY_ID_TYPE mFamily = FnVCCB_GetSaHandOutServiceTypeFamilyId(ptCi);

        VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];

        if (not FnVCCB_IsSupportServiceTypeYang(mFamily, pGnb)) return;

        // Mismatch between STAT_HO_OUT_SERVICE_TYPE and STAT_HO_OUT
        STAT_SERVICE_TYPE_FROM_HO_OUT_TYPE(mFamily, typeId);

        // Validation check
        if (mFamily == STAT_HO_EUTRAN_OUT_FALLBACK_SERVICE_TYPE &&
            typeId >= STAT_HO_EUTRAN_OUT_FALLBACK_SERVICE_TYPE_END)
            return;
        if (mFamily == STAT_HO_EUTRAN_OUT_SERVICE_TYPE && typeId >= STAT_HO_EUTRAN_OUT_SERVICE_TYPE_END) return;
        if (mFamily == STAT_HO_OUT_SERVICE_TYPE && typeId >= STAT_HO_OUT_SERVICE_TYPE_END) return;

        FnVCCB_LibStatPmCC_Mobility(mFamily, typeId, ptCi, 0, fnName);
    }
}

/**
 * @brief     This function is used for the purpose of collecting HandOut statistics.
 * @param     ptCi : callInfo
 * @param     type : stat type
 * @param     fnName : caller function name
 */
static void FnVCCB_StatSaHandoverOutgoing(callInfo_type *ptCi, enumHoStatType type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);

    if (TRUE == ptCi->hoInfo.nonNbrCell) // SM_CELL_HO
    {
        VCCB_PRINT_CALL_NON_NBR_HO(ptCi, "Skip collecting HO_OUT !! Tgt is NonNeighbor Small Cell\n");
        return;
    }

    // FGR-LC0712 FR210 (25B) Only the STAT_INTRA_NR_LB_HO family is collected and no other statistics are collected.
    if (ptCi->hoInfo.isVoNrLbHo == TRUE) return;

    int typeId = getTypeFromOut(ptCi, type);
    if (typeId == -1) return;

    STAT_PM_FAMILY_ID_TYPE collectFamilyId = FnVCCB_GetStatSaHandoverOutFamilyId(ptCi);

    // Non-service Type STAT first
    // In Redcap UE case, Not collected family - STAT_HO_EUTRAN_OUT_FALLBACK, STAT_HO_EUTRAN_OUT, STAT_HO_OUT
    if (not IS_REDCAP_UE(ptCi))
    {
        FnVCCB_LibStatPmCC_Mobility(collectFamilyId, typeId, ptCi, 0, fnName);
    }

    // Service Type STAT - Outgoing
    FnVCCB_StatSaHandOutServiceType(ptCi, type, fnName);

    if (IS_REDCAP_UE(ptCi))
    {
        // In case of Redcap UE, HO out statistics family is not collected, but CSL is collected from SVR25B.
        FnVCCB_CollectMobilityCsl_HoOut(*ptCi, static_cast<uint32_t>(typeId), collectFamilyId);
        return;
    }
}


static void FnVccb_UpdateAttStatsForLbHo(callInfo_type &rCall)
{
    if (rCall.hoInfo.isVoNrLbHo)
    {
        MACRO_STAT_PMCC(STAT_INTRA_NR_LB_HO, LbHoOut_Att_VoNR_INTRA_NR_LB_HO, &rCall, 0, 0, 0, 0, 0);
    }
    else
    {
        MACRO_STAT_PMCC(STAT_INTRA_NR_LB_HO, LbHoOut_Att_INTRA_NR_LB_HO, &rCall, 0, 0, 0, 0, 0);
        if (IS_REDCAP_UE(&rCall)) // Additional
        {
            MACRO_STAT_PMCC(STAT_INTRA_NR_LB_HO, LbHoOut_Att_Redcap_INTRA_NR_LB_HO, &rCall, 0, 0, 0, 0, 0);
        }
    }
}

static void FnVccb_UpdatePrepSuccStatsForLbHo(callInfo_type &rCall)
{
    if (rCall.hoInfo.isVoNrLbHo)
    {
        MACRO_STAT_PMCC(STAT_INTRA_NR_LB_HO, LbHoOut_Att_VoNR_INTRA_NR_LB_HO, &rCall, 0, 0, 0, 0, 0);
        MACRO_STAT_PMCC(STAT_INTRA_NR_LB_HO, LbHoOut_PrepSucc_VoNR_INTRA_NR_LB_HO, &rCall, 0, 0, 0, 0, 0);
    }
    else
    {
        MACRO_STAT_PMCC(STAT_INTRA_NR_LB_HO, LbHoOut_Att_INTRA_NR_LB_HO, &rCall, 0, 0, 0, 0, 0);
        MACRO_STAT_PMCC(STAT_INTRA_NR_LB_HO, LbHoOut_PrepSucc_INTRA_NR_LB_HO, &rCall, 0, 0, 0, 0, 0);

        if (IS_REDCAP_UE(&rCall)) // Additional
        {
            MACRO_STAT_PMCC(STAT_INTRA_NR_LB_HO, LbHoOut_Att_Redcap_INTRA_NR_LB_HO, &rCall, 0, 0, 0, 0, 0);
            MACRO_STAT_PMCC(STAT_INTRA_NR_LB_HO, LbHoOut_PrepSucc_Redcap_INTRA_NR_LB_HO, &rCall, 0, 0, 0, 0, 0);
        }
    }
}

static void FnVccb_UpdateSuccStatsForLbHo(callInfo_type &rCall)
{
    if (rCall.hoInfo.isVoNrLbHo)
    {
        MACRO_STAT_PMCC(STAT_INTRA_NR_LB_HO, LbHoOut_Att_VoNR_INTRA_NR_LB_HO, &rCall, 0, 0, 0, 0, 0);
        MACRO_STAT_PMCC(STAT_INTRA_NR_LB_HO, LbHoOut_PrepSucc_VoNR_INTRA_NR_LB_HO, &rCall, 0, 0, 0, 0, 0);
        MACRO_STAT_PMCC(STAT_INTRA_NR_LB_HO, LbHoOut_Succ_VoNR_INTRA_NR_LB_HO, &rCall, 0, 0, 0, 0, 0);
    }
    else
    {
        MACRO_STAT_PMCC(STAT_INTRA_NR_LB_HO, LbHoOut_Att_INTRA_NR_LB_HO, &rCall, 0, 0, 0, 0, 0);
        MACRO_STAT_PMCC(STAT_INTRA_NR_LB_HO, LbHoOut_PrepSucc_INTRA_NR_LB_HO, &rCall, 0, 0, 0, 0, 0);
        MACRO_STAT_PMCC(STAT_INTRA_NR_LB_HO, LbHoOut_Succ_INTRA_NR_LB_HO, &rCall, 0, 0, 0, 0, 0);

        if (IS_REDCAP_UE(&rCall)) // Additional
        {
            MACRO_STAT_PMCC(STAT_INTRA_NR_LB_HO, LbHoOut_Att_Redcap_INTRA_NR_LB_HO, &rCall, 0, 0, 0, 0, 0);
            MACRO_STAT_PMCC(STAT_INTRA_NR_LB_HO, LbHoOut_PrepSucc_Redcap_INTRA_NR_LB_HO, &rCall, 0, 0, 0, 0, 0);
            MACRO_STAT_PMCC(STAT_INTRA_NR_LB_HO, LbHoOut_Succ_Redcap_INTRA_NR_LB_HO, &rCall, 0, 0, 0, 0, 0);
        }
    }
}

/**
 * @brief     This function is used for the purpose of collecting LB Handover statistics.
 * @param     ptCi : callInfo
 * @param     type : stat type
 * @param     fnName : caller function name
 */
static void FnVCCB_StatSaHandoverOutgoing_LoadBalancing(callInfo_type *ptCi, enumHoStatType type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);

    // FGR-LC0712 FR210 (25B) Only the STAT_INTRA_NR_LB_HO family is collected and no other statistics are collected.
    if (ptCi->hoInfo.isLbHo != TRUE) return; // 25B FGR-LC0712 FR210

    const int LB_HO_FAMILY_IDX = GET_FAMIDX(STAT_LB_HO);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(LB_HO_FAMILY_IDX, 0, (MAX_VCCB_FAMILY_TYPE - 1));
    switch (type)
    {
        case HO_Att:
            if(GET_CALL_STAT_FLAG(ptCi, LB_HO_FAMILY_IDX) == NO_ATTEMPT)
            {
                SET_CALL_STAT_FLAG(ptCi, LB_HO_FAMILY_IDX, ATTEMPT_MADE);
            }
            break;
        case HO_PrepSucc:
            if (GET_CALL_STAT_FLAG(ptCi, LB_HO_FAMILY_IDX) == ATTEMPT_MADE)
            {
                SET_CALL_STAT_FLAG(ptCi, LB_HO_FAMILY_IDX, PREP_SUCCESS_MADE);
            }
            break;
        case HO_Succ:
            if (GET_CALL_STAT_FLAG(ptCi, LB_HO_FAMILY_IDX) == PREP_SUCCESS_MADE)
            {
                MACRO_STAT_PMCC(STAT_LB_HO, LbHoOut_Att, ptCi, 0, 0, 0, 0, 0);
                MACRO_STAT_PMCC(STAT_LB_HO, LbHoOut_PrepSucc, ptCi, 0, 0, 0, 0, 0);
                MACRO_STAT_PMCC(STAT_LB_HO, LbHoOut_Succ, ptCi, 0, 0, 0, 0, 0);
            }
            SET_CALL_STAT_FLAG(ptCi, LB_HO_FAMILY_IDX, NO_ATTEMPT);
            break;
        default:
            if (GET_CALL_STAT_FLAG(ptCi, LB_HO_FAMILY_IDX) == ATTEMPT_MADE)
            {
                MACRO_STAT_PMCC(STAT_LB_HO, LbHoOut_Att, ptCi, 0, 0, 0, 0, 0);
            }
            else if (GET_CALL_STAT_FLAG(ptCi, LB_HO_FAMILY_IDX) == PREP_SUCCESS_MADE)
            {
                MACRO_STAT_PMCC(STAT_LB_HO, LbHoOut_Att, ptCi, 0, 0, 0, 0, 0);
                MACRO_STAT_PMCC(STAT_LB_HO, LbHoOut_PrepSucc, ptCi, 0, 0, 0, 0, 0);
            }
            SET_CALL_STAT_FLAG(ptCi, LB_HO_FAMILY_IDX, NO_ATTEMPT);
            break;
    }
}

/**
 * @brief     This function is used for the purpose of collecting Connect UE(FGR-LC0703)/VoNR LB(FGR-LC0712) Handover statistics.
 *            STAT_INTRA_NR_LB_HO (6349) family as of 25B
 * @param     ptCi : callInfo
 * @param     type : stat type
 * @param     fnName : caller function name
 */
static void FnVCCB_StatSaHandoverOutgoing_IntraNrLbHo(callInfo_type *ptCi, enumHoStatType type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);

    const int LB_HO_FAMILY_IDX = GET_FAMIDX(STAT_INTRA_NR_LB_HO);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(LB_HO_FAMILY_IDX, 0, (MAX_VCCB_FAMILY_TYPE - 1));

    switch (type)
    {
        case HO_Att:
            if (GET_CALL_STAT_FLAG(ptCi, LB_HO_FAMILY_IDX) == NO_ATTEMPT)
            {
                SET_CALL_STAT_FLAG(ptCi, LB_HO_FAMILY_IDX, ATTEMPT_MADE);
            }
            break;

        case HO_PrepSucc:
            if (GET_CALL_STAT_FLAG(ptCi, LB_HO_FAMILY_IDX) == ATTEMPT_MADE)
            {
                SET_CALL_STAT_FLAG(ptCi, LB_HO_FAMILY_IDX, PREP_SUCCESS_MADE);
            }
            break;

        case HO_Succ:
            if (GET_CALL_STAT_FLAG(ptCi, LB_HO_FAMILY_IDX) == PREP_SUCCESS_MADE)
            {
                FnVccb_UpdateSuccStatsForLbHo(*ptCi);
            }
            SET_CALL_STAT_FLAG(ptCi, LB_HO_FAMILY_IDX, NO_ATTEMPT);
            break;

        default:
            if (GET_CALL_STAT_FLAG(ptCi, LB_HO_FAMILY_IDX) == ATTEMPT_MADE)
            {
                FnVccb_UpdateAttStatsForLbHo(*ptCi);
            }
            else if (GET_CALL_STAT_FLAG(ptCi, LB_HO_FAMILY_IDX) == PREP_SUCCESS_MADE)
            {
                FnVccb_UpdatePrepSuccStatsForLbHo(*ptCi);
            }
            SET_CALL_STAT_FLAG(ptCi, LB_HO_FAMILY_IDX, NO_ATTEMPT);
            break;
    }
}

/**
 * @brief     This function is used for the purpose of collecting Handover statistics excluding
 * Coverage-Based Handover.
 * @param     ptCi : callInfo
 * @param     type : stat type
 * @param     fnName : caller function name
 */
static void FnVCCB_StatSaHandoverOutgoing_NonCoverageBased(callInfo_type *ptCi, enumHoStatType type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);

    // FGR-LC0712 FR210 (25B) Only the STAT_INTRA_NR_LB_HO family is collected and no other statistics are collected.
    if (ptCi->hoInfo.isVoNrLbHo == TRUE) return;

    if (ptCi->hoInfo.hoType.rat == HO_TYPE_INTRA_RAT)  // INTRA_RAT (Intra-NR)
    {
        int typeId = getTypeFromOut(ptCi, type);

        if (typeId != -1)
        {
            FnVCCB_StatSaHandoverOutgoing_FreqBaseStatistic(ptCi, type, fnName);

            FnVCCB_StatSaHandoverOutgoing_PlmnBaseStatistic(ptCi, type, fnName);
        }
    }

    if (ptCi->hoInfo.hoType.rat == HO_TYPE_INTER_RAT) // IRAT_HO_24A
    {
        // IRAT_HO_24A Inter RAT Handover Per Target Frequency
        FnVCCB_StatSaHandoverOutgoing_EutraFreqBaseStatistic(ptCi, type, fnName); // STAT_HO_EUTRAN_FREQ_OUT
    }

    if (IS_VALID_CELLNUM(ptCi->servCellNum))
    {
        cgi_type cgi = FnVCCB_GetNrcgiFromCellNum(ptCi->servCellNum);

        FnVCCB_libStatUpmRlf_ForHO(ptCi, type, &cgi, &ptCi->hoInfo.cgi);  // Main Feature ID : FGS-SF0107 FR60
    }
}

static void FnVCCB_StatSaHandoverOutgoing_OnDemandForcedMobility(callInfo_type *ptCi, enumHoStatType type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);

    if (!IS_ONDEMAND_HO()) return;

    bool isInterRat = static_cast<bool>(IS_INTERRAT_HO());
    const int familyId = isInterRat ? STAT_FORCED_MOBILITY_EUTRAN : STAT_FORCED_MOBILITY_NR;
    const int famIdx = isInterRat ? GET_FAMIDX(STAT_FORCED_MOBILITY_EUTRAN) : GET_FAMIDX(STAT_FORCED_MOBILITY_NR);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, (MAX_VCCB_FAMILY_TYPE - 1));

    uint32_t freq = isInterRat ? ptCi->hoInfo.tArfcn : ptCi->hoInfo.tgtSsbFreq;

    auto ForcedMobility_HoOut_OnDemand_mapping = [isInterRat](int triggerType) -> int
    {
        switch (triggerType)
        {
            case HO_Att:
                if (isInterRat)
                    return HoLteOutByOndemandForcedMobility_Att;
                return HoOutByOndemandForcedMobility_Att;
            case HO_PrepSucc:
                if (isInterRat)
                    return HoLteOutByOndemandForcedMobility_PrepSucc;
                return HoOutByOndemandForcedMobility_PrepSucc;
            case HO_Succ:
                if (isInterRat)
                    return HoLteOutByOndemandForcedMobility_Succ;
                return HoOutByOndemandForcedMobility_Succ;
            case HO_HandoverCancel:
                if (isInterRat)
                    return HoLteOutByOndemandForcedMobility_Cancel;
                return HoOutByOndemandForcedMobility_Cancel;
            case HO_RRE:
                if (isInterRat)
                    return HoLteOutByOndemandForcedMobility_RRE;
                return HoOutByOndemandForcedMobility_RRE;
            default:
                return -1;
        }
    };

    switch (type)
    {
        case HO_Att:
            SET_CALL_STAT_FLAG(ptCi, famIdx, ATTEMPT_MADE);
            break;

        case HO_PrepSucc:
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == ATTEMPT_MADE)
            {
                SET_CALL_STAT_FLAG(ptCi, famIdx, PREP_SUCCESS_MADE);
            }
            break;

        case HO_Succ:
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                MACRO_STAT_PMCC(familyId, ForcedMobility_HoOut_OnDemand_mapping(HO_Att), ptCi, freq, 0, 0, 0, 0);
                MACRO_STAT_PMCC(familyId, ForcedMobility_HoOut_OnDemand_mapping(HO_PrepSucc), ptCi, freq, 0, 0, 0, 0);
                MACRO_STAT_PMCC(familyId, ForcedMobility_HoOut_OnDemand_mapping(HO_Succ), ptCi, freq, 0, 0, 0, 0);
            }

            SET_CALL_STAT_FLAG(ptCi, famIdx, NO_ATTEMPT);
            break;

        default:
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == ATTEMPT_MADE)
            {
                MACRO_STAT_PMCC(familyId, ForcedMobility_HoOut_OnDemand_mapping(HO_Att), ptCi, freq, 0, 0, 0, 0);
            }
            else if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                MACRO_STAT_PMCC(familyId, ForcedMobility_HoOut_OnDemand_mapping(HO_Att), ptCi, freq, 0, 0, 0, 0);
                MACRO_STAT_PMCC(familyId, ForcedMobility_HoOut_OnDemand_mapping(HO_PrepSucc), ptCi, freq, 0, 0, 0, 0);
            }

            int typeId = ForcedMobility_HoOut_OnDemand_mapping(type); // HO_HandoverCancel or HO_RRE
            if (typeId != -1)
            {
                MACRO_STAT_PMCC_NAME(familyId, typeId, ptCi, freq, 0, 0, 0, 0, fnName);
            }

            SET_CALL_STAT_FLAG(ptCi, famIdx, NO_ATTEMPT);
            break;
    }
}

static void FnVCCB_StatSaHandoverIntraNrOutgoing_USTM(callInfo_type *ptCi, enumHoStatType type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);

    if (FALSE == ptCi->ustmInfo.intraNrHandoverTriggered)
    {
        return;
    }

    auto typeopt =
        FnVCCB_MapUlStatusReasonAndNrHandoverPhaseToCounterType(ptCi->ustmInfo.ulStatusReasonTriggeredHandover, type);
    if (false == typeopt.has_value())
    {
        return;
    }

    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->hoInfo.tgtSsbFreq, UINT32_MAX);
    MACRO_STAT_PMCC_NAME(STAT_FORCED_MOBILITY_NR, *typeopt, ptCi, ptCi->hoInfo.tgtSsbFreq, 0, 0, 0, 0, fnName);
}

static void FnVCCB_StatSaHandoverInterRATOutgoing_USTM(
    callInfo_type *ptCi, volatile enumHoStatType type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);

    if (FALSE == ptCi->ustmInfo.interRatHandoverTriggered)
    {
        return;
    }

    auto typeopt = FnVCCB_MapUlStatusReasonAndInterRatHandoverPhaseToCounterType(
        ptCi->ustmInfo.ulStatusReasonTriggeredHandover, type);

    if (false == typeopt.has_value())
    {
        return;
    }

    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->hoInfo.tArfcn, UINT32_MAX);
    MACRO_STAT_PMCC_NAME(STAT_FORCED_MOBILITY_EUTRAN, *typeopt, ptCi, ptCi->hoInfo.tArfcn, 0, 0, 0, 0, fnName);
}

static void FnVCCB_StatSaHandoverOutgoing_SpecificSliceForcedMobility(callInfo_type *ptCi, volatile enumHoStatType type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);

    if (not ptCi->hoInfo.specificSliceForcedMobilityFlag) return;

    const int familyId = STAT_FORCED_MOBILITY_EUTRAN;
    const int famIdx = GET_FAMIDX(familyId);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(famIdx, 0, (MAX_VCCB_FAMILY_TYPE - 1));

    uint32_t freq = ptCi->hoInfo.tArfcn;

    auto ForcedMobility_HoOut_SpecificSlice_mapping = [](int triggerType) -> int
    {
        switch(triggerType)
        {
            case HO_Att:
                return HoLteOutBySpecificSliceForcedMobility_Att;
            case HO_PrepSucc:
                return HoLteOutBySpecificSliceForcedMobility_PrepSucc;
            case HO_Succ:
                return HoLteOutBySpecificSliceForcedMobility_Succ;
            case HO_HandoverCancel:
                return HoLteOutBySpecificSliceForcedMobility_Cancel;
            case HO_RRE:
                return HoLteOutBySpecificSliceForcedMobility_RRE;
            default:
                return -1;
        }
    };

    switch (type)
    {
        case HO_Att:
            SET_CALL_STAT_FLAG(ptCi, famIdx, ATTEMPT_MADE);
            break;
        case HO_PrepSucc:
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == ATTEMPT_MADE)
            {
                SET_CALL_STAT_FLAG(ptCi, famIdx, PREP_SUCCESS_MADE);
            }
            break;
        case HO_Succ:
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                MACRO_STAT_PMCC(familyId, ForcedMobility_HoOut_SpecificSlice_mapping(HO_Att), ptCi, freq, 0, 0, 0, 0);
                MACRO_STAT_PMCC(familyId, ForcedMobility_HoOut_SpecificSlice_mapping(HO_PrepSucc), ptCi, freq, 0, 0, 0, 0);
                MACRO_STAT_PMCC(familyId, ForcedMobility_HoOut_SpecificSlice_mapping(HO_Succ), ptCi, freq, 0, 0, 0, 0);
            }

            SET_CALL_STAT_FLAG(ptCi, famIdx, NO_ATTEMPT);
            break;

        default:
            if (GET_CALL_STAT_FLAG(ptCi, famIdx) == ATTEMPT_MADE)
            {
                MACRO_STAT_PMCC(familyId, ForcedMobility_HoOut_SpecificSlice_mapping(HO_Att), ptCi, freq, 0, 0, 0, 0);
            }
            else if (GET_CALL_STAT_FLAG(ptCi, famIdx) == PREP_SUCCESS_MADE)
            {
                MACRO_STAT_PMCC(familyId, ForcedMobility_HoOut_SpecificSlice_mapping(HO_Att), ptCi, freq, 0, 0, 0, 0);
                MACRO_STAT_PMCC(familyId, ForcedMobility_HoOut_SpecificSlice_mapping(HO_PrepSucc), ptCi, freq, 0, 0, 0, 0);
            }

            int typeId = ForcedMobility_HoOut_SpecificSlice_mapping(type); // HO_HandoverCancel or HO_RRE
            if (typeId != -1)
            {
                MACRO_STAT_PMCC_NAME(familyId, typeId, ptCi, freq, 0, 0, 0, 0, fnName);
            }

            SET_CALL_STAT_FLAG(ptCi, famIdx, NO_ATTEMPT);
            break;
    }
}

static void FnVCCB_StatSaHandoverOutgoing_ForcedMobility(callInfo_type *ptCi, enumHoStatType type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);

    // FGR-LC0712 FR210 (25B) Only the STAT_INTRA_NR_LB_HO family is collected and no other statistics are collected.
    if (ptCi->hoInfo.isVoNrLbHo == TRUE) return;

    // Forced Mobility (On Demand Handover)
    FnVCCB_StatSaHandoverOutgoing_OnDemandForcedMobility(ptCi, type, fnName);

    // Forced Mobility (Uplink Status Triggered Mobility)
    FnVCCB_StatSaHandoverIntraNrOutgoing_USTM(ptCi, type, fnName);
    FnVCCB_StatSaHandoverInterRATOutgoing_USTM(ptCi, type, fnName);

    // 25B PMB FGR-MC1021:FR200 Forced Mobility (Specific Slice dut to service border mobility)
    FnVCCB_StatSaHandoverOutgoing_SpecificSliceForcedMobility(ptCi, type, fnName);
}

/**
 * @brief     Generic function to stat SA Handover
 * @param     ptCi : callInfo
 * @param     type : stat type
 * @param     fnName : caller function name
 */

void VLIB_StatSaHandover(callInfo_type *ptCi,
    enumHoStatType type,
    const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);

    /* If Handover Preparation Case, Change State Type */
    if (ptCi->hoInfo.handoverExecutionFlag == FALSE)
    {
        FnVCCB_ChangeTypeForHandoverPreparation_MN(&type);
    }

    /* Proc */
    if (FnVCCB_IsStatSaHandoverIncoming(ptCi))  // HO_IN (Incoming)
    {
        FnVCCB_StatSaHandoverIncoming(ptCi, type, fnName);
    }

    if (FnVCCB_IsStatSaHandoverOutGoing(ptCi))  // HO_OUT (Outgoing)
    {
        if (ptCi->hoInfo.isLbHo == TRUE || ptCi->hoInfo.isVoNrLbHo == TRUE) // FGR-LC0712 FR210
        { // In 25B, STAT_LB_HO and STAT_INTRA_NR_LB_HO families exist at the same time for LB. but STAT_LB_HO will be deleted later.
            FnVCCB_StatSaHandoverOutgoing_LoadBalancing(ptCi, type, fnName); // For STAT_LB_HO (5554)
            FnVCCB_StatSaHandoverOutgoing_IntraNrLbHo(ptCi, type, fnName); // For STAT_INTRA_NR_LB_HO (6349) as of 25B
        }
        else
        {
            FnVCCB_StatSaHandoverOutgoing(ptCi, type, fnName);
        }

        // Forced Mobility
        FnVCCB_StatSaHandoverOutgoing_ForcedMobility(ptCi, type, fnName);

        FnVCCB_StatSaHandoverOutgoing_NonCoverageBased(ptCi, type, fnName);
    }
}

int FnVCCB_GetTypeFromChoIn(callInfo_type *ptCi, int type)
{
    AUTO_TRACE_FUNC;

    int pmType = -1;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, pmType);

    if (type >= CHO_TYPE_MAX)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Supported Type(%d, max:%d)!!\n", type, CHO_TYPE_MAX);
        return -1;
    }

    const int ChoIn_mapping[CHO_TYPE_MAX] = {
        // Preparation
        ChoXnIn_PrepAtt,          /* CHO_PrepAtt                              */
        ChoXnIn_PrepSuccess,      /* CHO_PrepSucc                             */
        ChoXnIn_PrepFail_gNBFail, /* CHO_PrepFail_XnFail        - Not Mapping */
        ChoXnIn_PrepFail_E1Fail,  /* CHO_PrepFail_E1Fail        - IN          */
        ChoXnIn_PrepFail_F1Fail,  /* CHO_PrepFail_F1Fail        - IN          */
        ChoXnIn_PrepFail_gNBFail, /* CHO_PrepFail_gNBFail       - IN, OUT     */
        ChoXnIn_PrepFail_gNBFail, /* CHO_PrepFail_RrcFail       - Not Mapping */
        ChoXnIn_PrepFail_gNBFail, /* CHO_PrepCancel             - Not Mapping */

        // Execution
        ChoXnIn_ExeAccess,       /* CHO_ExeAccess                             */
        ChoXnIn_ExeSuccess,      /* CHO_ExeSuccess                            */
        ChoXnIn_ExeFail_gNBFail, /* CHO_ExeFail_gNBFail        - IN, OUT      */
        ChoXnIn_ExeFail_XnFail,  /* CHO_ExeFail_XnFail         - IN, OUT      */
        ChoXnIn_ExeFail_NgFail,  /* CHO_ExeFail_NgFail         - IN           */
        ChoXnIn_ExeFail_F1Fail,  /* CHO_ExeFail_F1Fail         - IN, OUT      */
        ChoXnIn_ExeFail_E1Fail,  /* CHO_ExeFail_E1Fail         - IN, OUT      */

        // CandidateRel
        -1,                                  /* CHO_CandidateRel_CandidateInit - OUT     */
        ChoXnIn_CandidateRelease_SrcInit,    /* CHO_CandidateRel_SrcInit       - IN      */
        ChoXnIn_CandidateRelease_DuInit,     /* CHO_CandidateRel_DuInit        - IN      */
        ChoXnIn_CandidateRelease_UpInit,     /* CHO_CandidateRel_UpInit        - IN      */
        ChoXnIn_CandidateRelease_gNBTimeout, /* CHO_CandidateRel_gNBTimeout    - IN, OUT */
        -1,                                  /* CHO_CandidateRel_ConfigChange  - OUT     */
        ChoXnIn_CandidateRelease_gNBCancel   /* CHO_CandidateRel_gNBCancel     - IN, OUT */
    };

    pmType = ChoIn_mapping[type];

    if (pmType == -1)  // Not Found Mapping Stat
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Supported Statistic Error!!(%d) in CHO-IN\n", ptCi->hoInfo.hoType.initiated);
        return -1;
    }

    if (IS_MRDC_MN(ptCi))
    {
        pmType += (ChoXnInWithMrdc_PrepAtt - ChoXnIn_PrepAtt);
    }

    return pmType;
}

int FnVCCB_GetTypeFromChoOut(callInfo_type *ptCi, int type)
{
    AUTO_TRACE_FUNC;

    int pmType = -1;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, pmType);

    if (type >= CHO_TYPE_MAX)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Supported Type(%d, max:%d)!!\n", type, CHO_TYPE_MAX);
        return -1;
    }

    const int ChoOut_mapping[CHO_TYPE_MAX] = {
        // Preparation
        ChoXnOut_PrepAtt,          /* CHO_PrepAtt                              */
        ChoXnOut_PrepComplete,     /* CHO_PrepSucc                             */
        ChoXnOut_PrepFail_XnFail,  /* CHO_PrepFail_XnFail        - OUT         */
        ChoXnOut_PrepFail_gNBFail, /* CHO_PrepFail_E1Fail        - Not Mapping */
        ChoXnOut_PrepFail_gNBFail, /* CHO_PrepFail_F1Fail        - Not Mapping */
        ChoXnOut_PrepFail_gNBFail, /* CHO_PrepFail_gNBFail       - IN, OUT     */
        ChoXnOut_PrepFail_RrcFail, /* CHO_PrepFail_RrcFail       - OUT         */
        ChoXnOut_PrepCancel,       /* CHO_PrepCancel             - OUT         */

        // Execution
        ChoXnOut_ExeAccess,       /* CHO_ExeAccess                             */
        ChoXnOut_ExeSuccess,      /* CHO_ExeSuccess                            */
        ChoXnOut_ExeFail_gNBFail, /* CHO_ExeFail_gNBFail         - IN, OUT     */
        ChoXnOut_ExeFail_XnFail,  /* CHO_ExeFail_XnFail          - IN, OUT     */
        ChoXnOut_ExeFail_gNBFail, /* CHO_ExeFail_NgFail          - Not Mapping */
        ChoXnOut_ExeFail_F1Fail,  /* CHO_ExeFail_F1Fail          - IN, OUT     */
        ChoXnOut_ExeFail_E1Fail,  /* CHO_ExeFail_E1Fail          - IN, OUT     */

        // CandidateRel
        ChoXnOut_CandidateRel_CandidateInit, /* CHO_CandidateRel_CandidateInit - OUT     */
        -1,                                  /* CHO_CandidateRel_SrcInit       - IN      */
        -1,                                  /* CHO_CandidateRel_DuInit        - IN      */
        -1,                                  /* CHO_CandidateRel_UpInit        - IN      */
        ChoXnOut_CandidateRel_gNBTimeout,    /* CHO_CandidateRel_gNBTimeout    - IN, OUT */
        ChoXnOut_CandidateRel_ConfigChange,  /* CHO_CandidateRel_ConfigChange  - OUT     */
        ChoXnOut_CandidateRel_gNBCancel      /* CHO_CandidateRel_gNBCancel     - IN, OUT */
    };

    pmType = ChoOut_mapping[type];

    if (pmType == -1)  // Not Found Mapping Stat
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Supported Statistic Error!!(%d) in CHO-OUT\n", ptCi->hoInfo.hoType.initiated);
        return -1;
    }

    // The period from the completion of SN Addition (Finalize) to SN Release (Finalize) is regarded as an MRDC UE.
    if (IS_MRDC_ACTIVE(ptCi))
    {
        pmType += (ChoXnOutWithMrdc_PrepAtt - ChoXnOut_PrepAtt);
    }

    return pmType;
}

/**
 * @brief     Generic function to stat CHO Handover In Preparation
 * @param     ptCi : callInfo
 * @param     type : stat type
 * @param     fnName : caller function name
 */

void FnVCCB_StatChoHandover(callInfo_type *ptCi, enumChoStatType type, cgi_type *pTargetCgi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pTargetCgi);

    int typeId = -1;

    if (type == CHO_PrepSucc || type == CHO_ExeSuccess)
    {
        conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForCGI(ptCi, *pTargetCgi);
        VALID_E_POINT_CHECK_VOID(ptCondCell);

        // If successful, it is excluded from the Init collection target.
        ptCondCell->flag.collectableCandidateRelStat = (type == CHO_PrepSucc ? TRUE : FALSE);
    }

    if (ptCi->hoInfo.isTarget == FALSE)  // Source gNB Side
    {
        typeId = FnVCCB_GetTypeFromChoOut(ptCi, type);
        if (typeId == -1) return;

        FnVCCB_LibStatPmCC_ChoCollector(STAT_CHO_OUT, typeId, ptCi, pTargetCgi);

        if (type == CHO_ExeAccess)
        {
            FnVCCB_StatHoAccessTime(ptCi, ptCi->condHoInfo.targetCgi);
            FnVCCB_SetHandoverExecution(ptCi);
        }

        return;
    }

    // Candidate & Target gNB Side
    typeId = FnVCCB_GetTypeFromChoIn(ptCi, type);
    if (typeId == -1) return;

    FnVCCB_LibStatPmCC_ChoCollector(STAT_CHO_IN, typeId, ptCi, pTargetCgi);
}

void VLIB_SAHandoverTime(callInfo_type *ptCi, uint8_t actFlag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t flag = ptCi->hoInfo.HOTimeFlag;

    // SVR22C
    if (FnVCCB_IsConditionalHandoverUE(ptCi) == true)
    {
        // Conditional Handover does not collect statistics.
        return;
    }

    // SVR23B FGR-LC0711
    if ((ptCi->hoInfo.hoType.rat == HO_TYPE_INTER_RAT) &&
        (ptCi->hoInfo.isIratLbHo == TRUE))
    {
        // IRAT LB Handover does not collect statistics.
        return;
    }

    // SVR24B FGR-LC0712
    if (TRUE == ptCi->hoInfo.isVoNrLbHo)
    {
        // FR110 gNB should not count VoNR handover triggered by this feature for HO statistics.
        return;
    }

    if (actFlag == CAL_START && flag == FALSE)
    {
        ptCi->hoInfo.HOtHoAck = tickGetMono();
        ptCi->hoInfo.HOTimeFlag = TRUE;
        VCCB_PRINT_DATA(
            "tHoAck(sec:%ld / nsec:%ld) is stoered\n", ptCi->hoInfo.HOtHoAck.tv_sec, ptCi->hoInfo.HOtHoAck.tv_nsec);
    }
    else if (actFlag == CAL_STOP && flag == TRUE)
    {
        ptCi->hoInfo.HOTimeFlag = FALSE;
        ptCi->hoInfo.HOtReconfigCmpl = tickGetMono();
        VCCB_PRINT_DATA("tReconfig(sec:%ld / nsec:%ld) is stoered\n", ptCi->hoInfo.HOtReconfigCmpl.tv_sec,
            ptCi->hoInfo.HOtReconfigCmpl.tv_nsec);
    }
    else
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Handover Time Invalid State!! (actFlag = %u, flag = %u)!!\n", actFlag, flag);

        return;
    }
}

void VLIB_SetSaOutgoingHoTime(callInfo_type *ptCi, uint8_t actFlag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t flag = ptCi->hoInfo.OutHOTimeFlag;

    if (actFlag == CAL_START && flag == FALSE)
    {
        ptCi->hoInfo.HOtHoRqd = tickGetMono();
        ptCi->hoInfo.OutHOTimeFlag = TRUE;
        VCCB_PRINT_CALL_COMMENT(ptCi, "HOtHoRqd(sec:%ld / nsec:%ld) Set\n",
                ptCi->hoInfo.HOtHoRqd.tv_sec, ptCi->hoInfo.HOtHoRqd.tv_nsec);
    }
    else if (actFlag == CAL_STOP && flag == TRUE)
    {
        ptCi->hoInfo.OutHOTimeFlag = FALSE;
        ptCi->hoInfo.HOtUeCtxtRelCmpl = tickGetMono();
        VCCB_PRINT_CALL_COMMENT(ptCi, "HOtUeCtxtRelCmpl(sec:%ld / nsec:%ld) Set\n",
                ptCi->hoInfo.HOtUeCtxtRelCmpl.tv_sec, ptCi->hoInfo.HOtUeCtxtRelCmpl.tv_nsec);
    }
}

int getTypeFromNrdcSnChangeOut(callInfo_type *ptCi, int type)
{
    AUTO_TRACE_FUNC;

    int pmType = -1;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, pmType);
    if (type >= NRDC_SN_HO_TYPE_MAX)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Supported Type(%d, max:%d)!!\n", type, NRDC_SN_HO_TYPE_MAX);

        return -1;
    }

    const int MnInit_IntraSn_mapping[NRDC_SN_HO_TYPE_MAX] = {
        NrdcPsCellChange_Out_MnInit_IntraSn_Att,               /* NRDC_SN_HOAtt */
        NrdcPsCellChange_Out_MnInit_IntraSn_PrepSucc,          /* NRDC_SN_HOPrepSucc */
        NrdcPsCellChange_Out_MnInit_IntraSn_Succ,              /* NRDC_SN_HOSucc */
        NrdcPsCellChange_Out_MnInit_IntraSn_PrepFail_UpFail,   /* NRDC_SN_HOPrepFail_UpFail */
        NrdcPsCellChange_Out_MnInit_IntraSn_PrepFail_DuFail,   /* NRDC_SN_HOPrepFail_DuFail */
        NrdcPsCellChange_Out_MnInit_IntraSn_PrepFail_CpFail,   /* NRDC_SN_HOPrepFail_CpFail */
        NrdcPsCellChange_Out_MnInit_IntraSn_PrepFail_MgnbFail, /* NRDC_SN_HOPrepFail_XnFail */
        NrdcPsCellChange_Out_MnInit_IntraSn_Fail_UpFail,       /* NRDC_SN_HOFail_UpFail */
        NrdcPsCellChange_Out_MnInit_IntraSn_Fail_DuFail,       /* NRDC_SN_HOFail_DuFail */
        NrdcPsCellChange_Out_MnInit_IntraSn_Fail_CpFail,       /* NRDC_SN_HOFail_CpFail */
        NrdcPsCellChange_Out_MnInit_IntraSn_Fail_MgnbFail,     /* NRDC_SN_HOFail_XnFail */
    };

    const int MnInit_InterSn_mapping[NRDC_SN_HO_TYPE_MAX] = {
        NrdcPsCellChange_Out_MnInit_InterSn_Att,               /* NRDC_SN_HOAtt */
        NrdcPsCellChange_Out_MnInit_InterSn_PrepSucc,          /* NRDC_SN_HOPrepSucc */
        NrdcPsCellChange_Out_MnInit_InterSn_Succ,              /* NRDC_SN_HOSucc */
        -1,                                                    /* NRDC_SN_HOPrepFail_UpFail */
        -1,                                                    /* NRDC_SN_HOPrepFail_DuFail */
        NrdcPsCellChange_Out_MnInit_InterSn_PrepFail_CpFail,   /* NRDC_SN_HOPrepFail_CpFail */
        NrdcPsCellChange_Out_MnInit_InterSn_PrepFail_MgnbFail, /* NRDC_SN_HOPrepFail_XnFail */
        -1,                                                    /* NRDC_SN_HOFail_UpFail */
        -1,                                                    /* NRDC_SN_HOFail_DuFail */
        -1,                                                    /* NRDC_SN_HOFail_CpFail */
        NrdcPsCellChange_Out_MnInit_InterSn_Fail_MgnbFail,     /* NRDC_SN_HOFail_XnFail */
    };

    const int SnInit_IntraSn_mapping[NRDC_SN_HO_TYPE_MAX] = {
        NrdcPsCellChange_Out_SnInit_IntraSn_Att,               /* NRDC_SN_HOAtt */
        NrdcPsCellChange_Out_SnInit_IntraSn_PrepSucc,          /* NRDC_SN_HOPrepSucc */
        NrdcPsCellChange_Out_SnInit_IntraSn_Succ,              /* NRDC_SN_HOSucc */
        NrdcPsCellChange_Out_SnInit_IntraSn_PrepFail_UpFail,   /* NRDC_SN_HOPrepFail_UpFail */
        NrdcPsCellChange_Out_SnInit_IntraSn_PrepFail_DuFail,   /* NRDC_SN_HOPrepFail_DuFail */
        NrdcPsCellChange_Out_SnInit_IntraSn_PrepFail_CpFail,   /* NRDC_SN_HOPrepFail_CpFail */
        NrdcPsCellChange_Out_SnInit_IntraSn_PrepFail_MgnbFail, /* NRDC_SN_HOPrepFail_XnFail */
        NrdcPsCellChange_Out_SnInit_IntraSn_Fail_UpFail,       /* NRDC_SN_HOFail_UpFail */
        NrdcPsCellChange_Out_SnInit_IntraSn_Fail_DuFail,       /* NRDC_SN_HOFail_DuFail */
        NrdcPsCellChange_Out_SnInit_IntraSn_Fail_CpFail,       /* NRDC_SN_HOFail_CpFail */
        NrdcPsCellChange_Out_SnInit_IntraSn_Fail_MgnbFail,     /* NRDC_SN_HOFail_XnFail */
    };

    const int SnInit_InterSn_mapping[NRDC_SN_HO_TYPE_MAX] = {
        NrdcPsCellChange_Out_SnInit_InterSn_Att,               /* NRDC_SN_HOAtt */
        NrdcPsCellChange_Out_SnInit_InterSn_PrepSucc,          /* NRDC_SN_HOPrepSucc */
        NrdcPsCellChange_Out_SnInit_InterSn_Succ,              /* NRDC_SN_HOSucc */
        -1,                                                    /* NRDC_SN_HOPrepFail_UpFail */
        -1,                                                    /* NRDC_SN_HOPrepFail_DuFail */
        NrdcPsCellChange_Out_SnInit_InterSn_PrepFail_CpFail,   /* NRDC_SN_HOPrepFail_CpFail */
        NrdcPsCellChange_Out_SnInit_InterSn_PrepFail_MgnbFail, /* NRDC_SN_HOPrepFail_XnFail */
        -1,                                                    /* NRDC_SN_HOFail_UpFail */
        -1,                                                    /* NRDC_SN_HOFail_DuFail */
        -1,                                                    /* NRDC_SN_HOFail_CpFail */
        NrdcPsCellChange_Out_SnInit_InterSn_Fail_MgnbFail,     /* NRDC_SN_HOFail_XnFail */
    };

    if (FnVCCB_isMnInitMobility(ptCi))
    {
        return FnVCCB_isIntraSnMobility(ptCi) ? MnInit_IntraSn_mapping[type] : MnInit_InterSn_mapping[type];
    }

    return FnVCCB_isIntraSnMobility(ptCi) ? SnInit_IntraSn_mapping[type] : SnInit_InterSn_mapping[type];
}

int getTypeFromNrdcSnChangeIn(callInfo_type *ptCi, int type)
{
    AUTO_TRACE_FUNC;

    int pmType = -1;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, pmType);
    if (type >= NRDC_SN_HO_TYPE_MAX)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Supported Type(%d, max:%d)!!\n", type, NRDC_SN_HO_TYPE_MAX);

        return -1;
    }

    const int MnInit_IntraSn_mapping[NRDC_SN_HO_TYPE_MAX] = {
        NrdcPsCellChange_In_MnInit_IntraSn_Att,               /* NRDC_SN_HOAtt */
        NrdcPsCellChange_In_MnInit_IntraSn_PrepSucc,          /* NRDC_SN_HOPrepSucc */
        NrdcPsCellChange_In_MnInit_IntraSn_Succ,              /* NRDC_SN_HOSucc */
        NrdcPsCellChange_In_MnInit_IntraSn_PrepFail_UpFail,   /* NRDC_SN_HOPrepFail_UpFail */
        NrdcPsCellChange_In_MnInit_IntraSn_PrepFail_DuFail,   /* NRDC_SN_HOPrepFail_DuFail */
        NrdcPsCellChange_In_MnInit_IntraSn_PrepFail_CpFail,   /* NRDC_SN_HOPrepFail_CpFail */
        NrdcPsCellChange_In_MnInit_IntraSn_PrepFail_MgnbFail, /* NRDC_SN_HOPrepFail_XnFail */
        NrdcPsCellChange_In_MnInit_IntraSn_Fail_UpFail,       /* NRDC_SN_HOFail_UpFail */
        NrdcPsCellChange_In_MnInit_IntraSn_Fail_DuFail,       /* NRDC_SN_HOFail_DuFail */
        NrdcPsCellChange_In_MnInit_IntraSn_Fail_CpFail,       /* NRDC_SN_HOFail_CpFail */
        NrdcPsCellChange_In_MnInit_IntraSn_Fail_MgnbFail,     /* NRDC_SN_HOFail_XnFail */
    };

    const int SnInit_IntraSn_mapping[NRDC_SN_HO_TYPE_MAX] = {
        NrdcPsCellChange_In_SnInit_IntraSn_Att,               /* NRDC_SN_HOAtt */
        NrdcPsCellChange_In_SnInit_IntraSn_PrepSucc,          /* NRDC_SN_HOPrepSucc */
        NrdcPsCellChange_In_SnInit_IntraSn_Succ,              /* NRDC_SN_HOSucc */
        NrdcPsCellChange_In_SnInit_IntraSn_PrepFail_UpFail,   /* NRDC_SN_HOPrepFail_UpFail */
        NrdcPsCellChange_In_SnInit_IntraSn_PrepFail_DuFail,   /* NRDC_SN_HOPrepFail_DuFail */
        NrdcPsCellChange_In_SnInit_IntraSn_PrepFail_CpFail,   /* NRDC_SN_HOPrepFail_CpFail */
        NrdcPsCellChange_In_SnInit_IntraSn_PrepFail_MgnbFail, /* NRDC_SN_HOPrepFail_XnFail */
        NrdcPsCellChange_In_SnInit_IntraSn_Fail_UpFail,       /* NRDC_SN_HOFail_UpFail */
        NrdcPsCellChange_In_SnInit_IntraSn_Fail_DuFail,       /* NRDC_SN_HOFail_DuFail */
        NrdcPsCellChange_In_SnInit_IntraSn_Fail_CpFail,       /* NRDC_SN_HOFail_CpFail */
        NrdcPsCellChange_In_SnInit_IntraSn_Fail_MgnbFail,     /* NRDC_SN_HOFail_XnFail */
    };

    return FnVCCB_isMnInitMobility(ptCi) ? MnInit_IntraSn_mapping[type] : SnInit_IntraSn_mapping[type];
}

/**
 * @brief     Generic function to stat Nrdc SN Handover
 * @param     ptCi : callInfo
 * @param     type : stat type
 * @param     fnName : caller function name
 */

void FnVCCB_StatNrdcSnChange(callInfo_type *ptCi,
    int type,  // need to add it as enum
    const char *fnName)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);

    // skip Intra cell Handover stat (same with SA Mobility : need to check with system design team)
    if (FnVCCB_isIntraSnIntraCellMobility(ptCi))
    {
        return;
    }

    // 24B FGR-CC5201:FR609, FGR-CC5203:FR231
    if (NRDC_SN_HOAtt == type && ptCi->hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
    {
        // Service type needs to be set only for Inter-cell HO and Intra-SN PSCell change (including SCG Resume)
        SET_SERVICE_TYPE_INDEX_FOR_STAT_NRDC_CTX_REL_SERVICE_TYPE(ptCi);
    }

    // 22C2: FGR-CC5203
    if (ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_MN_INIT_SCG_RESUME)
    {
        return;
    }

    /* If Handover Preparation Case, Change State Type */
    if (ptCi->hoInfo.handoverExecutionFlag == FALSE)  // TODO : (GET_CALL_STAT_FLAG(ptCi, key) == ATTEMPT_MADE)
    {
        FnVCCB_ChangeTypeForHandoverPreparation_SN(&type);
    }

    uint8_t isStatInComing = false;
    uint8_t isStatOutgoing = true;

    if (FnVCCB_isIntraSnMobility(ptCi))
    {
        isStatInComing = true;
    }
    else
    {
        // STAT_NRDC_SN_ADD_SN is collected for Inter SN case
    }

    int typeId = -1;

    /* Proc */
    if (isStatInComing == True)  // HO_IN (Incoming)
    {
        typeId = getTypeFromNrdcSnChangeIn(ptCi, type);
        if (typeId != -1)
        {
            MACRO_STAT_PMCC_NAME(STAT_NRDC_PSCELL_CHANGE_IN, typeId, ptCi, 0, 0, 0, 0, 0, fnName);
        }

        if (type == NRDC_SN_HOSucc)
        {
            VLIB_StatSaPsCellChangeTime(ptCi);
        }
    }

    if (isStatOutgoing == True)  // HO_OUT (Outgoing)
    {
        typeId = getTypeFromNrdcSnChangeOut(ptCi, type);
        if (typeId != -1)
        {
            MACRO_STAT_PMCC_NAME(STAT_NRDC_PSCELL_CHANGE_OUT, typeId, ptCi, 0, 0, 0, 0, 0, fnName);
        }
    }
}

int16_t FnVCCB_SaHandoverStatForF1(callInfo_type *ptCi, enumDuHoRole duHoRole)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, GOOD);

    // ignore case
    switch (ptCi->state)
    {
        case STATE_INTER_Exe_S:
        case STATE_INTER_SeqNum_S:
        case STATE_INTER_Compl_S:
            // If entering this state, F1 Ue Context Release will proceed soon. Therefore, the content requested by the
            // DU is ignored.
            VCCB_PRINT_ERROR("Ignore F1_UEContextReleaseRequest during Inter-gNB(Source-gNB, Execution State) HO\n");
            return BREAK;

        case STATE_INTER_DU_Exe_T:
        case STATE_INTER_DU_Execution:
        case STATE_INTER_DU_Complete:
            if (duHoRole == DU_HO_SOURCE)
            {
                // If entering this state, F1 Ue Context Release will proceed soon. Therefore, the content requested by
                // the DU is ignored.
                VCCB_PRINT_ERROR("Ignore F1_UEContextReleaseRequest during Intra-gNB(Source-DU, Execution State) HO\n");
                return BREAK;
            }
            break;

        default:
            break;
    }

    // collect
    if (IS_NRDC_SN(ptCi))
    {
        VCCB_MRDC_SN_HO_STAT(ptCi, NRDC_SN_HOFail_DuFail);
        return GOOD;
    }

    VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_DuFail);
    VHCM_SA_HO_STAT(ptCi, HO_Fail_F1Fail);

    if (ptCi->hoInfo.handoverExecutionFlag == FALSE)
    {
        CHO_STAT(ptCi, CHO_PrepFail_F1Fail, ptCi->hoInfo.cgi);
    }
    else
    {
        CHO_STAT(ptCi, CHO_ExeFail_F1Fail, ptCi->hoInfo.cgi);

        if (ptCi->hoInfo.isTarget == TRUE)
        {
            CHO_STAT(ptCi, CHO_CandidateRel_DuInit, ptCi->hoInfo.cgi);
        }
    }

    return GOOD;
}

void FnVCCB_UpdateSaHoStatFromUeCxtRelCmd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // cho collect
    if (FnVCCB_IsConditionalHandoverUE(ptCi))
    {
        if (ptCi->hoInfo.handoverExecutionFlag == FALSE)
        {
            CHO_STAT(ptCi, CHO_PrepCancel, ptCi->hoInfo.cgi);
        }
        return;
    }

    // collect
    if (ptCi->state == STATE_INTER_Compl_S)
    {
        if (ptCi->hoInfo.hoType.interface == HO_TYPE_NG)  // Inter-gNB NG Handover
        {
            VHCM_SA_HO_STAT(ptCi, HO_Succ);  // Collect when the handover ends normally.
            return;
        }
    }

    // If the NG UE Context Release Command is received in a situation other than the desired operation scenario,
    // it is collected as Handover Cancel because Handover Cancel processing is performed.
    VHCM_SA_HO_STAT(ptCi, HO_HandoverCancel);
}

void FnVCCB_SaHandoverStatForXN(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // ignore case
    CHO_STAT(ptCi, CHO_CandidateRel_SrcInit, ptCi->hoInfo.cgi);

    // collect
    if (IS_NRDC_SN(ptCi))
    {
        VCCB_MRDC_SN_HO_STAT(ptCi, NRDC_SN_HOFail_XnFail);
        return;
    }

    // Received XN Handover Cancel
    VHCM_SA_HO_STAT(ptCi, HO_HandoverCancel);
}

/**
 * @brief This function retrieves the UPM statistics value based on whether the call is
 *        MRDC SN or Legacy and the number of ping-pong handovers.
 *
 * @param isMrdcSn Flag indicating whether the call is MRDC SN or Legacy.
 * @param numPingPongHo Number of ping-pong handovers.
 * @return int The UPM statistics value corresponding to the input parameters.
 */
VCCB_STATIC_INLINE
int FnVCCB_GetUpmStatValue(bool isMrdcSn, uint8_t numPingPongHo)
{
    auto GetMrdcSnStatValue = [&]() -> int /*mType*/
    {
        switch(numPingPongHo)
        {
            case Pingpong1: return PingpongPSCellChange1;
            case Pingpong2: return PingpongPSCellChange2;
            case Pingpong3: return PingpongPSCellChange3;
            case Pingpong4: return PingpongPSCellChange4;
            default:
                return -1;
        }
    };
    auto GetLegacyStatValue = [&]() -> int /*mType*/
    {
        switch(numPingPongHo)
        {
            case Pingpong1 ... Pingpong8:
                return static_cast<int>(numPingPongHo);

            default:
                return -1;
        }
    };

    if (isMrdcSn == true)
    {
        return GetMrdcSnStatValue();
    }
    else
    {
        return GetLegacyStatValue();
    }
}

/**
 * @brief This function checks whether UPM statistics collection is supported for the given call and UPM statistics information.
 *
 * @param ptCi Pointer to call information structure.
 * @param ptStat Pointer to UPM statistics information structure.
 * @return true if UPM statistics collection is supported, otherwise false.
 */
VCCB_STATIC_INLINE
int FnVCCB_IsUpmStatCollectionSupported(callInfo_type *ptCi, upmStatInfoForCall_type *ptStat)
{
    // Check if the input pointers are valid
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptStat, false);

    // Define lambda functions for checking call-based validation
    auto CheckCallBasedValidation = [&]()
    {
        // Check for specific state commands and handover types
        switch(ptCi->stateCmd)
        {
            case RrcReestablish_cmd:
            case MrdcXnSNAdd_cmd:
                return true;

            default:
                break;
        }

        // Check if the UE is a SA handover UE
        if (VHCM_isSaHandoverUE(ptCi))
        {
            return true;
        }

        // If none of the conditions are met, return false
        return false;
    };

    // Define lambda functions for checking UPM DB-based validation
    auto CheckUpmDbBasedValidation = [&]()
    {
        // Check if UPM statistics flag is set to FALSE
        if (ptStat->upmStatFlag == FALSE) return false;

        // Check if the number of ping-pong handovers is zero
        if (ptStat->numPingPongHO == 0) return false;

        // Check if the target cell number in UPM statistics information matches the current cell number
        if (ptStat->upmStoreCellNum != FnVCCB_GetTargetCellNumForUpm(ptCi)) return false;

        // If all conditions are met, return true
        return true;
    };

    // Check if call-based validation is successful
    if (CheckCallBasedValidation() == false) return false;

    // Check if UPM DB-based validation is successful
    return CheckUpmDbBasedValidation();
}

/**
 * @brief This function collects statistics related to Ping-Pong Handover (PPHO, UPM) events.
 *
 * @param ptCi Pointer to the call information structure.
 */
void VLIB_StatPingPongHandover(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    // Validate the input parameter.
    VALID_E_POINT_CHECK_VOID(ptCi);

    // Declare variables.
    int mType = -1;
    upmStatInfoForCall_type *ptStat = NULL;

    // Get the pointer to the UPM statistics structure.
    ptStat = FnVCCB_GetUpmStatInfo(ptCi);
    if (ptStat == NULL) return;

    // Check if the call supports UPM statistics collection.
    if (FnVCCB_IsUpmStatCollectionSupported(ptCi, ptStat) == true)
    {
        // Get the measurement type based on the number of PPHO events.
        mType = FnVCCB_GetUpmStatValue(IS_MRDC_SN(ptCi), ptStat->numPingPongHO);
        if (mType > 0)
        {
            // Collect the statistics using the measurement type.
            MACRO_STAT_PMCC(STAT_PINGPONG, mType, ptCi, 0, 0, 0, 0, 0);
        }
    }

    // If the UPM statistics flag is set, initialize the UPM statistics information.
    if (ptStat->upmStatFlag == TRUE)
    {
        FnVCCB_InitUpmStatInfo(ptStat);
    }
}

/**
 * @brief     Generic function to accumulate STAT_ERAB_ADD_PER_GNB during Inter MN HO Erab Addition
 * @param     ptCi : callInfo
 * @param     type : stat type
 * @param     erabStatus_flag : flag to distinguish between ptRi->erabStatus and ptRi->prevErabStatus for erab
 */
void VLIB_StatErabAddInterMnHO(callInfo_type *ptCi, STAT_ERAB_ADD_PER_GNB_ITEM type, int16_t erabStatus_flag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint16_t erabIdx = 0;
    callERABInfo_type *ptRi = NULL;

    for (erabIdx = 0; erabIdx < MAX_ERAB_PER_CALL; erabIdx++)
    {
        ptRi = &ptCi->erabInfo[erabIdx];
        if (CI_use != ptRi->usage) continue;

        // Statistics Update
        if (TRUE == erabStatus_flag)
        {
            if (ERAB_Setup == ptRi->erabStatus)
            {
                MACRO_STAT_PMCC_QCI(STAT_ERAB_ADD_PER_GNB, type, ptCi, ptRi, 0, 0, 0, 0);
                ptRi->prevErabStatus = ptRi->erabStatus;
                ptRi->erabStatus = ERAB_FailToSetup;
            }
        }
        else
        {
            if (ERAB_Setup == ptRi->prevErabStatus)
            {
                MACRO_STAT_PMCC_QCI(STAT_ERAB_ADD_PER_GNB, type, ptCi, ptRi, 0, 0, 0, 0);
                ptRi->prevErabStatus = ptRi->erabStatus;
                ptRi->erabStatus = ERAB_FailToSetup;
            }
        }
    }

    return;
}

void VLIB_StatHoDebugIncreaseEventCount(uint8_t threadId)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);

    VCCB_STAT->localStat.hoDebugStatInfo[threadId].ulNasOverWriteCnt++;

    return;
}

void FnVCCB_IncreaseEventOccurrenceCount(uint8_t threadId, uint16_t eventId)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);

    for (int eventIndex = 0; eventIndex < MIN(VCCB_LOG_FISHING->eventCount, VCCB_MAX_LOG_FISHING_EVENT_COUNT);
         eventIndex++)
    {
        if (eventId == VCCB_LOG_FISHING->eventList[eventIndex].eventId)
        {
            VCCB_LOG_FISHING->eventList[eventIndex].occurrenceCount[threadId]++;
            break;
        }
    }
    return;
}

void FnVCCB_IncreaseEventSavedCount(uint8_t threadId, uint16_t eventId)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);

    for (int eventIndex = 0; eventIndex < MIN(VCCB_LOG_FISHING->eventCount, VCCB_MAX_LOG_FISHING_EVENT_COUNT);
         eventIndex++)
    {
        if (eventId == VCCB_LOG_FISHING->eventList[eventIndex].eventId)
        {
            VCCB_LOG_FISHING->eventList[eventIndex].savedCount[threadId]++;
            break;
        }
    }
    return;
}

// FGR-CC5200:FR740 FR750
void FnVCCB_PeriodicStat_NrdcSnTermDrbConnInfo(VccbCellInfo_type *pCell, uint16_t fiveQiIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pCell);
    VCCB_CHECK_E_RANGE_AND_VOID(fiveQiIdx, MAX_QCI_VALUE);

    uint32_t plmnIndex;
    uint32_t uePlmnKey = 0;  // (MCC * 1000) + MNC  = 0~999999
    plmnId_type plmnToConvertBuff;
    uint16_t cellIdentity = pCell->cellIdentity;
    uint32_t snTermDrbCount = 0;

    for (plmnIndex = 0; plmnIndex < MAX_PLMN_INDEX; plmnIndex++)
    {
        if (pCell->cellPlmnIndexInfo[plmnIndex].status != EQUIP) continue;

        plmnToConvertBuff.longId = pCell->cellPlmnIndexInfo[plmnIndex].servedPlmn;
        VLIB_ConvertPlmnIdToPlmnValue(&plmnToConvertBuff.s2, &uePlmnKey);
        if (uePlmnKey != 0)
        {
            snTermDrbCount = pCell->cfg.assignedNrdcSnTermDrbConnCount[fiveQiIdx][plmnIndex];

            MACRO_STAT_PMGAUGE(STAT_NRDC_SN_TERM_DRB_CONN_INFO, SnTermDrbConnNoAvg, NULL, (float)snTermDrbCount,
                pCell->gnbNum, cellIdentity, uePlmnKey, fiveQiIdx);
        }
    }
}

void FnVCCB_PeriodicStat_NrdcSnTermDrbConnInfoForPlmn(VccbCellInfo_type *pCell, uint16_t fiveQiIdx, uint32_t cellPlmnIndex)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pCell);
    VCCB_CHECK_E_RANGE_AND_VOID(fiveQiIdx, MAX_QCI_VALUE);
    VCCB_CHECK_E_RANGE_AND_VOID(cellPlmnIndex, MAX_PLMN_INDEX);

    uint32_t uePlmnKey = 0;  // (MCC * 1000) + MNC  = 0~999999
    plmnId_type plmnToConvertBuff;
    uint16_t cellIdentity = pCell->cellIdentity;
    uint32_t snTermDrbCount = 0;

    if (pCell->cellPlmnIndexInfo[cellPlmnIndex].status != EQUIP) return;

    plmnToConvertBuff.longId = pCell->cellPlmnIndexInfo[cellPlmnIndex].servedPlmn;
    VLIB_ConvertPlmnIdToPlmnValue(&plmnToConvertBuff.s2, &uePlmnKey);
    if (uePlmnKey != 0)
    {
        snTermDrbCount = pCell->cfg.assignedNrdcSnTermDrbConnCount[fiveQiIdx][cellPlmnIndex];

        MACRO_STAT_PMGAUGE(STAT_NRDC_SN_TERM_DRB_CONN_INFO, SnTermDrbConnNoAvg, NULL, (float)snTermDrbCount,
            pCell->gnbNum, cellIdentity, uePlmnKey, fiveQiIdx);
    }

}

void FnVCCB_PeriodicStat_SaCellDrbConnInfoForPlmn(VccbCellInfo_type *pCell, uint16_t fiveQiIdx, uint32_t cellPlmnIndex)
{
    AUTO_TRACE_FUNC;
    uint32_t uePlmnKey = 0;  // (MCC * 1000) + MNC  = 0~999999
    plmnId_type plmnToConvertBuff;
    uint16_t cellIdentity;

    VALID_E_POINT_CHECK_VOID(pCell);
    VCCB_CHECK_E_RANGE_AND_VOID(fiveQiIdx, MAX_QCI_VALUE);
    VCCB_CHECK_E_RANGE_AND_VOID(cellPlmnIndex, MAX_PLMN_INDEX);

    cellIdentity = pCell->cellIdentity;
    uint32_t cellDrbCountForRrcCon = 0, cellDrbCountForRrcInact = 0;

    ////////////////////////////////////////////////////////////
    // 1. SA , MORAN  ( Choose One )
    ////////////////////////////////////////////////////////////
    cellDrbCountForRrcCon = pCell->cfg.assignedDrbCount5QiRrcConn[fiveQiIdx];
    cellDrbCountForRrcInact = pCell->cfg.assignedDrbCount5QiRrcInact[fiveQiIdx];
    MACRO_STAT_PMGAUGE(STAT_DRB_CONN_INFO, DrbConnNoAvg, NULL, (float)cellDrbCountForRrcCon, pCell->gnbNum,
        cellIdentity, fiveQiIdx, 0);
    MACRO_STAT_PMGAUGE(STAT_DRB_CONN_INFO, DrbInactNoAvg, NULL, (float)cellDrbCountForRrcInact, pCell->gnbNum,
        cellIdentity, fiveQiIdx, 0);
    MACRO_STAT_PMGAUGE(STAT_DRB_CONN_INFO, DrbConnInactNoAvg, NULL,
        (float)(cellDrbCountForRrcCon + cellDrbCountForRrcInact), pCell->gnbNum, cellIdentity, fiveQiIdx, 0);

    // UL ROHC statistics : sai.babu, ashvin.jo (SRIB)
    MACRO_STAT_PMGAUGE(STAT_DRB_NUM_UL_ONLY_ROHC_SA, UlRohcDrbNoAvg, NULL,
        (float)pCell->cfg.assignedULOnlyRoHCDrbCountRrcConn[fiveQiIdx], pCell->gnbNum, cellIdentity, fiveQiIdx, 0);

    ////////////////////////////////////////////////////////////
    // 2. SA, MOCN ( Additional )
    ////////////////////////////////////////////////////////////
    if (FOO.VF_MultipleOperatorCNSupport)
    {
        if (pCell->cellPlmnIndexInfo[cellPlmnIndex].status != EQUIP) return;
        plmnToConvertBuff.longId = pCell->cellPlmnIndexInfo[cellPlmnIndex].servedPlmn;
        VLIB_ConvertPlmnIdToPlmnValue(&plmnToConvertBuff.s2, &uePlmnKey);
        cellDrbCountForRrcCon = pCell->cfg.assignedDrbCount5QiWithPlmnRrcConn[fiveQiIdx][cellPlmnIndex];
        cellDrbCountForRrcInact = pCell->cfg.assignedDrbCount5QiWithPlmnRrcInact[fiveQiIdx][cellPlmnIndex];
        if (uePlmnKey != 0)
        {
            MACRO_STAT_PMGAUGE(STAT_DRB_CONN_INFO_PLMN, DrbConnNoAvgPlmn, NULL, (float)cellDrbCountForRrcCon,
                pCell->gnbNum, cellIdentity, uePlmnKey, fiveQiIdx);
            MACRO_STAT_PMGAUGE(STAT_DRB_CONN_INFO_PLMN, DrbInactNoAvgPlmn, NULL, (float)cellDrbCountForRrcInact,
                pCell->gnbNum, cellIdentity, uePlmnKey, fiveQiIdx);
            MACRO_STAT_PMGAUGE(STAT_DRB_CONN_INFO_PLMN, DrbConnInactNoAvgPlmn, NULL,
                (float)(cellDrbCountForRrcCon + cellDrbCountForRrcInact), pCell->gnbNum, cellIdentity, uePlmnKey,
                fiveQiIdx);
        }
    }

    if (FOO.VF_BasicCallProcedureforRedCapUE && pCell->redcapBroadcastUsage)
    {
        int redCapFamily = STAT_DRB_CONN_INFO_REDCAP_PLMN;

        if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
            redCapFamily = STAT_CP_DRB_CONN_INFO_REDCAP_PLMN;

        if (pCell->cellPlmnIndexInfo[cellPlmnIndex].status != EQUIP) return;
        plmnToConvertBuff.longId = pCell->cellPlmnIndexInfo[cellPlmnIndex].servedPlmn;
        VLIB_ConvertPlmnIdToPlmnValue(&plmnToConvertBuff.s2, &uePlmnKey);
        if (uePlmnKey != 0)
        {
            cellDrbCountForRrcCon = pCell->cfg.assignedRedCapDrbCount5QiWithPlmnRrcConn[fiveQiIdx][cellPlmnIndex];
            cellDrbCountForRrcInact = pCell->cfg.assignedRedCapDrbCount5QiWithPlmnRrcInact[fiveQiIdx][cellPlmnIndex];
            MACRO_STAT_PMGAUGE(redCapFamily, DrbConnNoAvgPlmn, NULL, (float)cellDrbCountForRrcCon,
                pCell->gnbNum, cellIdentity, uePlmnKey, fiveQiIdx);
            MACRO_STAT_PMGAUGE(redCapFamily, DrbInactNoAvgPlmn, NULL, (float)cellDrbCountForRrcInact,
                pCell->gnbNum, cellIdentity, uePlmnKey, fiveQiIdx);
            MACRO_STAT_PMGAUGE(redCapFamily, DrbConnInactNoAvgPlmn, NULL, (float)(cellDrbCountForRrcCon + cellDrbCountForRrcInact),
                pCell->gnbNum, cellIdentity, uePlmnKey, fiveQiIdx);
        }

    }

    return;
}


void FnVCCB_PeriodicStat_SaCellDrbConnInfo(VccbCellInfo_type *pCell, uint16_t fiveQiIdx)
{
    AUTO_TRACE_FUNC;
    uint32_t plmnIndex;
    uint32_t uePlmnKey = 0;  // (MCC * 1000) + MNC  = 0~999999
    plmnId_type plmnToConvertBuff;
    uint16_t cellIdentity;

    VALID_E_POINT_CHECK_VOID(pCell);
    VCCB_CHECK_E_RANGE_AND_VOID(fiveQiIdx, MAX_QCI_VALUE);

    cellIdentity = pCell->cellIdentity;
    uint32_t cellDrbCountForRrcCon = 0, cellDrbCountForRrcInact = 0;

    ////////////////////////////////////////////////////////////
    // 1. SA , MORAN  ( Choose One )
    ////////////////////////////////////////////////////////////
    cellDrbCountForRrcCon = pCell->cfg.assignedDrbCount5QiRrcConn[fiveQiIdx];
    cellDrbCountForRrcInact = pCell->cfg.assignedDrbCount5QiRrcInact[fiveQiIdx];
    MACRO_STAT_PMGAUGE(STAT_DRB_CONN_INFO, DrbConnNoAvg, NULL, (float)cellDrbCountForRrcCon, pCell->gnbNum,
        cellIdentity, fiveQiIdx, 0);
    MACRO_STAT_PMGAUGE(STAT_DRB_CONN_INFO, DrbInactNoAvg, NULL, (float)cellDrbCountForRrcInact, pCell->gnbNum,
        cellIdentity, fiveQiIdx, 0);
    MACRO_STAT_PMGAUGE(STAT_DRB_CONN_INFO, DrbConnInactNoAvg, NULL,
        (float)(cellDrbCountForRrcCon + cellDrbCountForRrcInact), pCell->gnbNum, cellIdentity, fiveQiIdx, 0);

    // UL ROHC statistics : sai.babu, ashvin.jo (SRIB)
    MACRO_STAT_PMGAUGE(STAT_DRB_NUM_UL_ONLY_ROHC_SA, UlRohcDrbNoAvg, NULL,
        (float)pCell->cfg.assignedULOnlyRoHCDrbCountRrcConn[fiveQiIdx], pCell->gnbNum, cellIdentity, fiveQiIdx, 0);

    ////////////////////////////////////////////////////////////
    // 2. SA, MOCN ( Additional )
    ////////////////////////////////////////////////////////////
    if (FOO.VF_MultipleOperatorCNSupport)
    {
        for (plmnIndex = 0; plmnIndex < MAX_PLMN_INDEX; plmnIndex++)
        {
            if (pCell->cellPlmnIndexInfo[plmnIndex].status != EQUIP) continue;
            plmnToConvertBuff.longId = pCell->cellPlmnIndexInfo[plmnIndex].servedPlmn;
            VLIB_ConvertPlmnIdToPlmnValue(&plmnToConvertBuff.s2, &uePlmnKey);
            cellDrbCountForRrcCon = pCell->cfg.assignedDrbCount5QiWithPlmnRrcConn[fiveQiIdx][plmnIndex];
            cellDrbCountForRrcInact = pCell->cfg.assignedDrbCount5QiWithPlmnRrcInact[fiveQiIdx][plmnIndex];
            if (uePlmnKey != 0)
            {
                MACRO_STAT_PMGAUGE(STAT_DRB_CONN_INFO_PLMN, DrbConnNoAvgPlmn, NULL, (float)cellDrbCountForRrcCon,
                    pCell->gnbNum, cellIdentity, uePlmnKey, fiveQiIdx);
                MACRO_STAT_PMGAUGE(STAT_DRB_CONN_INFO_PLMN, DrbInactNoAvgPlmn, NULL, (float)cellDrbCountForRrcInact,
                    pCell->gnbNum, cellIdentity, uePlmnKey, fiveQiIdx);
                MACRO_STAT_PMGAUGE(STAT_DRB_CONN_INFO_PLMN, DrbConnInactNoAvgPlmn, NULL,
                    (float)(cellDrbCountForRrcCon + cellDrbCountForRrcInact), pCell->gnbNum, cellIdentity, uePlmnKey,
                    fiveQiIdx);
            }
        }
    }

    if (FOO.VF_BasicCallProcedureforRedCapUE && pCell->redcapBroadcastUsage)
    {
        int redCapFamily = STAT_DRB_CONN_INFO_REDCAP_PLMN;

        if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
            redCapFamily = STAT_CP_DRB_CONN_INFO_REDCAP_PLMN;

        for (plmnIndex = 0; plmnIndex < MAX_PLMN_INDEX; plmnIndex++)
        {
            if (pCell->cellPlmnIndexInfo[plmnIndex].status != EQUIP) continue;

            plmnToConvertBuff.longId = pCell->cellPlmnIndexInfo[plmnIndex].servedPlmn;
            VLIB_ConvertPlmnIdToPlmnValue(&plmnToConvertBuff.s2, &uePlmnKey);
            if (uePlmnKey != 0)
            {
                cellDrbCountForRrcCon = pCell->cfg.assignedRedCapDrbCount5QiWithPlmnRrcConn[fiveQiIdx][plmnIndex];
                cellDrbCountForRrcInact = pCell->cfg.assignedRedCapDrbCount5QiWithPlmnRrcInact[fiveQiIdx][plmnIndex];

                MACRO_STAT_PMGAUGE(redCapFamily, DrbConnNoAvgPlmn, NULL, (float)cellDrbCountForRrcCon,
                    pCell->gnbNum, cellIdentity, uePlmnKey, fiveQiIdx);
                MACRO_STAT_PMGAUGE(redCapFamily, DrbInactNoAvgPlmn, NULL, (float)cellDrbCountForRrcInact,
                    pCell->gnbNum, cellIdentity, uePlmnKey, fiveQiIdx);
                MACRO_STAT_PMGAUGE(redCapFamily, DrbConnInactNoAvgPlmn, NULL, (float)(cellDrbCountForRrcCon + cellDrbCountForRrcInact),
                    pCell->gnbNum, cellIdentity, uePlmnKey, fiveQiIdx);
            }
        }
    }

    return;
}

void VLIB_PeriodicStat_RrcConnInfo(VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;

    uint32_t plmnIndex;
    uint32_t uePlmnKey = 0;  // (MCC * 1000) + MNC  = 0~999999
    plmnId_type plmnToConvertBuff;

    /*
     A. Connected : Status until 'Call release' and 'RRC Inactive(Suspend)' after 'RRC connection establishment'.
      - 1. ConnNoAvg
      - 2. CallHoldingTimeAvg :
     B. Inactive  : Status after 'RRC Inactive(Suspend)'
      - 1. InactNoAvg
      - 2. InactCallHoldingTimeAvg
     C. Connected + Inactive : Status from 'RRC connection establishment' to 'Call release' (including suspension
     status)
      - 1. ConnInactNoAvg
      - 2. ConnInactCallHoldingTimeAvg
     */

    uint32_t cellConnCallCount = 0, cellInactiveCallCount = 0, nonDssUeCount = 0, cellPC1RrcConnectionCount = 0,
             cellPC15RrcConnectionCount = 0, cellPC2RrcConnectionCount = 0;

    VALID_E_POINT_CHECK_VOID(pCell);
    VCCB_CHECK_E_RANGE_AND_VOID(pCell->gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *pGnb = &GNBINFO[pCell->gnbNum];

    ////////////////////////////////////////////////////////////
    // 1. SA , MORAN  ( Choose One )
    ////////////////////////////////////////////////////////////
    cellConnCallCount = pCell->cfg.assignedCellRrcConnectionCount;
    cellInactiveCallCount = pCell->cfg.assignedCellRrcInactiveCount;
    nonDssUeCount = pCell->cfg.assignedNonDssUeCount;
    cellPC1RrcConnectionCount = pCell->cfg.assignedCellPC1RrcConnectionCount;
    cellPC15RrcConnectionCount = pCell->cfg.assignedCellPC15RrcConnectionCount;
    cellPC2RrcConnectionCount = pCell->cfg.assignedCellPC2RrcConnectionCount;

    MACRO_STAT_PMGAUGE(
        STAT_RRC_CONN_INFO, ConnNoAvg, NULL, (float)cellConnCallCount, pCell->gnbNum, pCell->cellIdentity, 0, 0);

    MACRO_STAT_PMGAUGE(STAT_RRC_CONN_INFO_PC1_DU_ID, ConnNoAvg_PC1_DUID, NULL, (float)cellPC1RrcConnectionCount,
       pCell->gnbNum, pCell->cellIdentity, 0, 0);
    MACRO_STAT_PMGAUGE(STAT_RRC_CONN_INFO_PC15_DU_ID, ConnNoAvg_PC15_DUID, NULL, (float)cellPC15RrcConnectionCount,
        pCell->gnbNum, pCell->cellIdentity, 0, 0);
    MACRO_STAT_PMGAUGE(STAT_RRC_CONN_INFO_PC2_DU_ID, ConnNoAvg_PC2_DUID, NULL, (float)cellPC2RrcConnectionCount,
       pCell->gnbNum, pCell->cellIdentity, 0, 0);

    MACRO_STAT_PMGAUGE(
        STAT_RRC_CONN_INFO, InactNoAvg, NULL, (float)cellInactiveCallCount, pCell->gnbNum, pCell->cellIdentity, 0, 0);
    MACRO_STAT_PMGAUGE(STAT_RRC_CONN_INFO, ConnInactNoAvg, NULL, (float)(cellConnCallCount + cellInactiveCallCount),
        pCell->gnbNum, pCell->cellIdentity, 0, 0);
    MACRO_STAT_PMGAUGE(
        STAT_RRC_CONN_INFO, NonDssUeNoAvgConn, NULL, (float)nonDssUeCount, pCell->gnbNum, pCell->cellIdentity, 0, 0);
    if (FOO.VF_VONREmergency_Counter)
    {
        cellConnCallCount = pCell->cfg.vonrEmerCellRrcConnectionCount;
        MACRO_STAT_PMGAUGE(STAT_VONR_EMERGENCY_CONN_INFO, VoNREmergencyConnNoAvg, NULL, (float)cellConnCallCount,
            pCell->gnbNum, pCell->cellIdentity, 0, 0);
    }

    ////////////////////////////////////////////////////////////
    // 2. SA, MOCN ( Additional )
    ////////////////////////////////////////////////////////////
    if (FOO.VF_MultipleOperatorCNSupport)
    {
        for (plmnIndex = 0; plmnIndex < MAX_PLMN_INDEX; plmnIndex++)
        {
            if (pCell->cellPlmnIndexInfo[plmnIndex].status != EQUIP) continue;
            plmnToConvertBuff.longId = pCell->cellPlmnIndexInfo[plmnIndex].servedPlmn;
            VLIB_ConvertPlmnIdToPlmnValue(&plmnToConvertBuff.s2, &uePlmnKey);
            if (uePlmnKey != 0)
            {
                cellConnCallCount = pCell->cfg.assignedCellRrcConnectionCountWithPlmn[plmnIndex];
                cellInactiveCallCount = pCell->cfg.assignedCellRrcInactiveCountWithPlmn[plmnIndex];
                nonDssUeCount = pCell->cfg.assignedNonDssUeCountWithPlmn[plmnIndex];
                MACRO_STAT_PMGAUGE(STAT_RRC_CONN_INFO_PLMN, ConnNoAvgPlmn, NULL, (float)cellConnCallCount,
                    pCell->gnbNum, pCell->cellIdentity, uePlmnKey, 0);
                MACRO_STAT_PMGAUGE(STAT_RRC_CONN_INFO_PLMN, InactNoAvgPlmn, NULL, (float)cellInactiveCallCount,
                    pCell->gnbNum, pCell->cellIdentity, uePlmnKey, 0);
                MACRO_STAT_PMGAUGE(STAT_RRC_CONN_INFO_PLMN, ConnInactNoAvgPlmn, NULL,
                    (float)(cellConnCallCount + cellInactiveCallCount), pCell->gnbNum, pCell->cellIdentity, uePlmnKey,
                    0);
                MACRO_STAT_PMGAUGE(STAT_RRC_CONN_INFO_PLMN, NonDssUeNoAvgConnPlmn, NULL, (float)nonDssUeCount,
                    pCell->gnbNum, pCell->cellIdentity, uePlmnKey, 0);
            }
        }  // for
    }

    if (FOO.VF_ServedUEConnectionStatus_InclRFSP)
    {
        uint16_t rfspVal;
        uint16_t rfspIdx;
        uint8_t yangRfspList[MAX_RFSP_CONN_STAT_BUFFER];
        memset(yangRfspList, 0, sizeof(yangRfspList));

        // 1. RFSP Count with Yang(gNB)
        for (rfspIdx = 0; rfspIdx < MAX_RFSP_CONN_STAT_YANG; rfspIdx++)  // 0..29
        {
            // Check RFSP Yang Usage.
            if (pGnb->rfspBasedCounterList[rfspIdx].usage != EQUIP) continue;
            rfspVal = pGnb->rfspBasedCounterList[rfspIdx].rfspVal;
            if ((!IS_VALID_RFSP_STAT_VAL(rfspVal)) || (rfspVal == 0)) continue;

            // Set Valid RFSP Value in RFSP List
            yangRfspList[rfspVal] = VCCB_FLAG_ON;

            // Collect Stat
            for (plmnIndex = 0; plmnIndex < MAX_PLMN_INDEX; plmnIndex++) // 0..7
            {
                if (pCell->cellPlmnIndexInfo[plmnIndex].status != EQUIP) continue;
                plmnToConvertBuff.longId = pCell->cellPlmnIndexInfo[plmnIndex].servedPlmn;
                VLIB_ConvertPlmnIdToPlmnValue(&plmnToConvertBuff.s2, &uePlmnKey);
                if (uePlmnKey != 0)
                {
                    cellConnCallCount = pCell->cfg.assignedCellRrcConnectionCountWithRfsp[rfspVal][plmnIndex];
                    cellInactiveCallCount = pCell->cfg.assignedCellRrcInactiveCountWithRfsp[rfspVal][plmnIndex];
                    nonDssUeCount = pCell->cfg.assignedNonDssUeCountWithRfsp[rfspVal][plmnIndex];

                    MACRO_STAT_PMGAUGE(STAT_RRC_CONN_INFO_DU_ID_PLMN_RFSP, ConnNoAvgPlmnRfsp, NULL,
                        (float)cellConnCallCount, pCell->gnbNum, pCell->cellIdentity, uePlmnKey, rfspVal);
                    MACRO_STAT_PMGAUGE(STAT_RRC_CONN_INFO_DU_ID_PLMN_RFSP, InactNoAvgPlmnRfsp, NULL,
                        (float)cellInactiveCallCount, pCell->gnbNum, pCell->cellIdentity, uePlmnKey, rfspVal);
                    MACRO_STAT_PMGAUGE(STAT_RRC_CONN_INFO_DU_ID_PLMN_RFSP, ConnInactNoAvgPlmnRfsp, NULL,
                        (float)(cellConnCallCount + cellInactiveCallCount), pCell->gnbNum, pCell->cellIdentity,
                        uePlmnKey, rfspVal);
                    MACRO_STAT_PMGAUGE(STAT_RRC_CONN_INFO_DU_ID_PLMN_RFSP, NonDssUeNoAvgConnPlmnRfsp_DUID, NULL,
                        (float)(nonDssUeCount), pCell->gnbNum, pCell->cellIdentity,
                        uePlmnKey, rfspVal);
                }
            }  // for plmnIndex
        } // for rfspIdx

        // 2. RFSP Count without Yang(gNB)
        rfspVal = 0;
        for (plmnIndex = 0; plmnIndex < MAX_PLMN_INDEX; plmnIndex++) // 0..7
        {
            if (pCell->cellPlmnIndexInfo[plmnIndex].status != EQUIP) continue;
            plmnToConvertBuff.longId = pCell->cellPlmnIndexInfo[plmnIndex].servedPlmn;
            VLIB_ConvertPlmnIdToPlmnValue(&plmnToConvertBuff.s2, &uePlmnKey);

            if (uePlmnKey != 0)
            {
                cellConnCallCount     = 0;
                cellInactiveCallCount = 0;
                nonDssUeCount         = 0;

                for (rfspIdx = 0; rfspIdx < MAX_RFSP_CONN_STAT_BUFFER; rfspIdx++)  // 0..256
                {
                    if(yangRfspList[rfspIdx] == VCCB_FLAG_ON) continue;
                    
                    cellConnCallCount     += pCell->cfg.assignedCellRrcConnectionCountWithRfsp[rfspIdx][plmnIndex];
                    cellInactiveCallCount += pCell->cfg.assignedCellRrcInactiveCountWithRfsp[rfspIdx][plmnIndex];
                    nonDssUeCount         += pCell->cfg.assignedNonDssUeCountWithRfsp[rfspIdx][plmnIndex];
                } // for rfspIdx

                MACRO_STAT_PMGAUGE(STAT_RRC_CONN_INFO_DU_ID_PLMN_RFSP, ConnNoAvgPlmnRfsp, NULL,
                    (float)cellConnCallCount, pCell->gnbNum, pCell->cellIdentity, uePlmnKey, rfspVal);
                MACRO_STAT_PMGAUGE(STAT_RRC_CONN_INFO_DU_ID_PLMN_RFSP, InactNoAvgPlmnRfsp, NULL,
                    (float)cellInactiveCallCount, pCell->gnbNum, pCell->cellIdentity, uePlmnKey, rfspVal);
                MACRO_STAT_PMGAUGE(STAT_RRC_CONN_INFO_DU_ID_PLMN_RFSP, ConnInactNoAvgPlmnRfsp, NULL,
                    (float)(cellConnCallCount + cellInactiveCallCount), pCell->gnbNum, pCell->cellIdentity,
                    uePlmnKey, rfspVal);
                MACRO_STAT_PMGAUGE(STAT_RRC_CONN_INFO_DU_ID_PLMN_RFSP, NonDssUeNoAvgConnPlmnRfsp_DUID, NULL,
                    (float)(nonDssUeCount), pCell->gnbNum, pCell->cellIdentity,
                    uePlmnKey, rfspVal);
            }
        } // for plmnIndex
    }

    if (FOO.VF_BasicCallProcedureforRedCapUE && pCell->redcapBroadcastUsage)
    {
        int redCapFamily = STAT_RRC_CONN_INFO_REDCAP_PLMN;

        if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
            redCapFamily = STAT_CP_RRC_CONN_INFO_REDCAP_PLMN;

        for (plmnIndex = 0; plmnIndex < MAX_PLMN_INDEX; plmnIndex++)
        {
            if (pCell->cellPlmnIndexInfo[plmnIndex].status != EQUIP) continue;

            plmnToConvertBuff.longId = pCell->cellPlmnIndexInfo[plmnIndex].servedPlmn;
            VLIB_ConvertPlmnIdToPlmnValue(&plmnToConvertBuff.s2, &uePlmnKey);
            if (uePlmnKey != 0)
            {
                cellConnCallCount = pCell->cfg.assignedRedCapCellRrcConnectionCountWithPlmn[plmnIndex];
                cellInactiveCallCount = pCell->cfg.assignedRedCapCellRrcInactiveCountWithPlmn[plmnIndex];
                nonDssUeCount = pCell->cfg.assignedRedCapNonDssUeCountWithPlmn[plmnIndex];

                MACRO_STAT_PMGAUGE(redCapFamily, ConnNoAvgPlmn, NULL, (float)cellConnCallCount,
                    pCell->gnbNum, pCell->cellIdentity, uePlmnKey, 0);
                MACRO_STAT_PMGAUGE(redCapFamily, InactNoAvgPlmn, NULL, (float)cellInactiveCallCount,
                    pCell->gnbNum, pCell->cellIdentity, uePlmnKey, 0);
                MACRO_STAT_PMGAUGE(redCapFamily, ConnInactNoAvgPlmn, NULL, (float)(cellConnCallCount + cellInactiveCallCount),
                    pCell->gnbNum, pCell->cellIdentity, uePlmnKey, 0);
                MACRO_STAT_PMGAUGE(redCapFamily, NonDssUeNoAvgConnPlmn, NULL, (float)nonDssUeCount,
                    pCell->gnbNum, pCell->cellIdentity, uePlmnKey, 0);
            }
        }
    }

    return;
}

// FGR-CC5200:FR760 FR770 FR780 FR790
void FnVCCB_PeriodicStat_NrdcConnInfo(VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pCell);

    auto getUePlmnKey = [](cellPlmnIndexInfo_type &callPlmn)
    {
        plmnId_type plmnToConvertBuff;
        plmnToConvertBuff.longId = callPlmn.servedPlmn;
        uint32_t uePlmnKey = 0;
        VLIB_ConvertPlmnIdToPlmnValue(&plmnToConvertBuff.s2, &uePlmnKey);  // (MCC * 1000) + MNC  = 0~999999
        return uePlmnKey;
    };

    auto collectConnNoAvgStat = [&pCell](uint32_t uePlmnKey, uint16_t rfspVal, uint32_t mnCnt, uint32_t snCnt)
    {
        MACRO_STAT_PMGAUGE(STAT_NRDC_SN_CONN_INFO_MN, NrdcMnConnNoAvg, NULL, (float)mnCnt, pCell->gnbNum,
            pCell->cellIdentity, uePlmnKey, rfspVal);
        MACRO_STAT_PMGAUGE(STAT_NRDC_SN_CONN_INFO_SN, NrdcSnConnNoAvg, NULL, (float)snCnt, pCell->gnbNum,
            pCell->cellIdentity, uePlmnKey, rfspVal);
    };

    // For checking RFSP is configured in gNB
    bool isRfspConfiguredInGnb[MAX_RFSP_CONN_STAT_BUFFER] = {
        false,
    };

    // Set rfsp configured in gnb true
    VCCB_CHECK_E_RANGE_AND_VOID(pCell->gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *pGnb = &GNBINFO[pCell->gnbNum];
    for (auto &rfspConfiguredInGnb : pGnb->rfspBasedCounterList)
    {
        if (rfspConfiguredInGnb.usage != EQUIP || rfspConfiguredInGnb.rfspVal == 0 ||
            rfspConfiguredInGnb.rfspVal >= MAX_RFSP_CONN_STAT_BUFFER)
            continue;
        isRfspConfiguredInGnb[rfspConfiguredInGnb.rfspVal] = true;
    }

    for (uint8_t plmnIndex = 0; plmnIndex < MAX_PLMN_INDEX; plmnIndex++)
    {
        if (pCell->cellPlmnIndexInfo[plmnIndex].status != EQUIP) continue;

        auto uePlmnKey = getUePlmnKey(pCell->cellPlmnIndexInfo[plmnIndex]);
        if (uePlmnKey == 0) continue;

        // Accumulated value for unconfigured RFSP
        uint32_t cellNrdcMnCntForNotConfiguredRfsp = 0;
        uint32_t cellNrdcSnCntForNotConfiguredRfsp = 0;

        for (uint16_t rfspVal = 0; rfspVal < MAX_RFSP_CONN_STAT_BUFFER; rfspVal++)
        {
            // Get MN/SN connection counts
            uint32_t cellNrdcMnCnt = pCell->cfg.assignedCellNrdcSnConnInfoMnCount[rfspVal][plmnIndex];
            uint32_t cellNrdcSnCnt = pCell->cfg.assignedCellNrdcSnConnInfoSnCount[rfspVal][plmnIndex];

            // Case 1: RFSP is configured - collect regular statistics
            if (isRfspConfiguredInGnb[rfspVal])
            {
                collectConnNoAvgStat(uePlmnKey, rfspVal, cellNrdcMnCnt, cellNrdcSnCnt);
            }
            // Case 2: RFSP is not configured - accumulate as unconfigured RFSP
            else
            {
                cellNrdcMnCntForNotConfiguredRfsp += cellNrdcMnCnt;
                cellNrdcSnCntForNotConfiguredRfsp += cellNrdcSnCnt;
            }
        }
        // Collect Statistics for RFSP is not configured in YANG
        const uint16_t NOT_CONFIGURED_RFSP = 0;
        collectConnNoAvgStat(
            uePlmnKey, NOT_CONFIGURED_RFSP, cellNrdcMnCntForNotConfiguredRfsp, cellNrdcSnCntForNotConfiguredRfsp);
    }
}

/**
 * @brief     Generic function to represent that this call collects statistics for retaining.
 * @brief     Turn on RETAIN_STAT flags for both call and all DRBs.
 * @param     ptCi : callInfo
 */

void VLIB_SetOnAllRetainStatCapableFlag(callInfo_type *ptCi, uint32_t collectSetupFailStat, uint32_t isInterGnbOperationFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    uint16_t callDrbIdx = 0;
    callDRBInfo_type *ptDi = NULL;
    uint16_t qosFlowIdx = 0;
    qosFlowInfo_type *ptQi = NULL;

    if(IS_NRDC_SN(ptCi)) return;

    /* Set Call Retain CapaFlag as ON */
    SET_CALL_RETAIN_STAT_CAPABLE_FLAG(ptCi, VCCB_FLAG_ON);
    SET_VONR_EMER_RETAIN_STAT_CAPABLE_FLAG(ptCi, VCCB_FLAG_ON);

    /* Set DRB Retain CapaFlag as ON */
    for (callDrbIdx = 0; callDrbIdx < MAX_DRB_PER_SA_CALL; callDrbIdx++)
    {
        ptDi = &ptCi->drb[callDrbIdx];

        if (ptDi->usage != CI_use) continue;
        // Collect FailToSetup item only when 'collectSetupFailStat' flag is on
        if ((ptDi->drbStatus == S_FailToSetup) && (collectSetupFailStat == VCCB_FLAG_OFF)) continue;

        SET_DRB_RETAIN_STAT_CAPABLE_FLAG(ptDi, VCCB_FLAG_ON);
    }

    for (qosFlowIdx = 0; qosFlowIdx < MAX_QOS_FLOW_PER_CALL; qosFlowIdx++)
    {
        ptQi = &ptCi->qosFlow[qosFlowIdx];

        if (ptQi->usage != CI_use) continue;

        // Collect FailToSetup item only when 'collectSetupFailStat' flag is on
        if ((ptQi->qosFlowStatus == S_FailToSetup) && (collectSetupFailStat == VCCB_FLAG_OFF)) continue;

        SET_QOSFLOW_RETAIN_STAT_CAPABLE_FLAG(ptQi, VCCB_FLAG_ON);

    }

    // Decide VoNR & Emergency Call for Inter Gnb New Call
    if(isInterGnbOperationFlag == VCCB_FLAG_ON)
    {
        // Update VoNr Emergency Call                    /* Not Collect Retain Stat */
        FnVCCB_UpdateVoNrEmergencyCallAndReleaseStat(ptCi, VCCB_FLAG_OFF);
    }
}

/**
 * @brief     Classifies 'mItem' which will be collected by statistics according to 'retainCategory' and 'cause'.
 * @brief     Turn on RETAIN_STAT flags for both call and all DRBs.
 * @param     ptCi : callInfo
 * @param     ptDi : DRB Info
 * @param     retainCategory : enumCallDrb_RetainEventCategory_type defined in msg_def_call_5g.h
 * @param     cause : Call release cause
 */

void FnVCCB_SaveEventForQosVonrEmerRetainStat(callInfo_type *ptCi, qosFlowInfo_type *ptQi, uint8_t retainCategory, uint32_t cause)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptQi);

    // Check Capable State & vonrEmerCallFlag Flag
    if ((ptCi->retainStatOfVonrEmer.capableFlag != VCCB_FLAG_ON) ||
        (ptQi->retainStat.capableFlag != VCCB_FLAG_ON)           ||
        (ptCi->rrcConnStat.vonrEmerCallFlag != VCCB_FLAG_ON))
    {
        return;
    }

    // First Event Category will be saved. later Event will be ignored.
    // If Event Catetory is RetainCategory_PduSessonModifyByAMF, then can be overlapped.
    // SubItem is allowed to be overlapped.
    if ((ptCi->retainStatOfVonrEmer.savedEventCategory == No_CallDrb_RetainCategory) ||
        ((retainCategory == ptCi->retainStatOfVonrEmer.savedEventCategory) &&
         (retainCategory == RetainCategory_PduSessonModifyByAMF          )         ))
    {
        FnVCCB_SaveEventCommonForDrbQosRetain(ptCi, &ptCi->retainStatOfVonrEmer, retainCategory, cause);
    }
    else
    {
        // No Action
    }

    return;
}

void VLIB_SaveEventForDrbRetainStat(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t retainCategory, uint32_t cause)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptDi);

    // Check Capable State
    if ((ptCi->retainStat.capableFlag != VCCB_FLAG_ON) || (ptDi->retainStat.capableFlag != VCCB_FLAG_ON))
    {
        return;
    }

    if(IS_NRDC_SN(ptCi)) return;

    // Check SN Term Bearer.
    if(VCCB_IS_SN_TERM_DRB_WITH_ONLY_CHECK_BEARER_TYPE(ptDi)) return;

    // First Event Category will be saved. later Event will be ignored.
    // SubItem is allowed to be overlapped.
    if (ptDi->retainStat.savedEventCategory == No_CallDrb_RetainCategory)
    {
        FnVCCB_SaveEventCommonForDrbQosRetain(ptCi, &ptDi->retainStat, retainCategory, cause);
    }
    else
    {
        //       VCCB_PRINT_CALL_INFORMATIVE(ptCi, "%s No Effect callId:%d DRB:%d savedEventCategory:%d new:%d \n",
        //       __func__,
        //               ptCi->callId, ptDi->dRBId, ptDi->retainStat.savedEventCategory, retainCategory);
    }

    return;
}

void FnVCCB_SaveEventCommonForDrbQosRetain(callInfo_type *ptCi, retainStatInfo_type *ptRetainInfo, uint8_t retainCategory, uint32_t cause)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptRetainInfo);

    // Save Call EventCategory
    ptRetainInfo->savedEventCategory = retainCategory;

    switch (retainCategory)
    {
        // PDU Modify Case(Release by modify)
        case RetainCategory_PduSessonModifyByAMF:
            if ((cause == CauseNgapNasNormalRelease)   ||
                (cause == CauseNgapNasDeregister)      ||
                (cause == CauseNgapMiscOMIntervention) ||
                (cause == CauseNgapRadioNetworkLayerReleaseDueToCnDetectedMobility))
            {
                ptRetainInfo->savedEventItem |= RetainItem_PduSessonModifyByAMF_Normal;
                if(cause == CauseNgapRadioNetworkLayerReleaseDueToCnDetectedMobility)
                {
                    ptRetainInfo->savedEventItem |= RetainItem_PduSessonModifyByAMF_CnDetectedMobility;
                }
            }
            break;

        // PDU Release Case
        case RetainCategory_PduSessonReleaseByAMF:
            if ((cause == CauseNgapNasNormalRelease)                ||
                (cause == CauseNgapRadioNetworkLayerUserInactivity) ||
                (cause == CauseNgapRadioNetworkLayerReleaseDueToCnDetectedMobility) ||
                (cause == CauseNgapNasDeregister)                   ||
                (cause == CauseNgapMiscOMIntervention))
            {
                ptRetainInfo->savedEventItem |= RetainItem_PduSessonReleaseByAMF_Normal;
                if(cause == CauseNgapRadioNetworkLayerReleaseDueToCnDetectedMobility)
                {
                    ptRetainInfo->savedEventItem |= RetainItem_PduSessonReleaseByAMF_CnDetectedMobility;
                }
            }
            break;

        // Only DRB Release by Preemption by F1
        case RetainCategory_RelOnlyDrbByPreemptionByGNB:
            ptRetainInfo->savedEventItem |= RetainItem_RelOnlyDrbByPreemptionByGNB;
            ptRetainInfo->savedEventItem |= RetainItem_RelOnlyDrbByPreemptionByGNB_PduNotify;
            break;

        default:
            break;
    }

    return;
}

#define MACRO_RETAIN_REMOVE_NORMAL_CAUSE(__ptCi)                                                              \
    do                                                                                                        \
    {                                                                                                         \
        __ptCi->retainStat.savedEventItem &= static_cast<uint16_t>(~RetainItem_UeCtxtRelRequestByGNB_Normal); \
    } while (0)

void FnVCCB_SaveEventForCallRetainStat_SaveRetainEventItem(callInfo_type *ptCi, uint8_t retainCategory, uint32_t cause)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    // 2. Save retainStat.savedEventItem
    uint32_t detailType = No_DetainType_RetainStat;
    switch (retainCategory)
    {
        case RetainCategory_UeCtxtRelCommandByAMF:
            if (IS_INTER_GNB_NG_HO())  // RETAIN_STAT_HO_21C - NG HO Only
            {
                detailType = RetainDetailType_NgIntraNrHo;
                ptCi->retainStat.savedEventItem |= RetainItem_UeCtxtRelCommandByAMF_NgIntraNRHo_All;
            }
            else if (IS_INTERRAT_HO())  // RETAIN_STAT_HO_21A
            {
                detailType = RetainDetailType_NgInterRatHo;
                ptCi->retainStat.savedEventItem |= RetainItem_UeCtxtRelCommandByAMF_NgInterRatHo_All;
            }

            // Normal Case
            if ((cause == CauseNgapNasNormalRelease) || (cause == CauseNgapRadioNetworkLayerHandoverCancelled) ||
                (cause == CauseNgapRadioNetworkLayerSuccessfulHandover) ||  // RETAIN_STAT_HO_21A
                (cause == CauseNgapRadioNetworkLayerNgIntraSystemHandoverTriggered) ||
                (cause == CauseNgapRadioNetworkLayerNgInterSystemHandoverTriggered) ||
                (cause == CauseNgapNasDeregister) || (cause == CauseNgapMiscOMIntervention) ||  // RETAIN_STAT_HO_24B
                (cause == CauseNgapRadioNetworkLayerReleaseDueToCnDetectedMobility))
            {
                ptCi->retainStat.savedEventItem |= RetainItem_UeCtxtRelCommandByAMF_Normal;

                if (cause == CauseNgapRadioNetworkLayerReleaseDueToCnDetectedMobility)
                {
                    ptCi->retainStat.savedEventItem |= RetainItem_UeCtxtRelCommandByAMF_CnDetectedMobility;
                }

                if (detailType == RetainDetailType_NgIntraNrHo)
                {
                    ptCi->retainStat.savedEventItem |= RetainItem_UeCtxtRelCommandByAMF_NgIntraNrHo_Normal;
                }
                else if (detailType == RetainDetailType_NgInterRatHo)
                {
                    ptCi->retainStat.savedEventItem |= RetainItem_UeCtxtRelCommandByAMF_NgInterRatHo_Normal;
                }
            }
            break;

        case RetainCategory_UeCtxtRelRequestByGNB:
            if ((cause == CauseNgapNasNormalRelease) || (cause == CauseNgapRadioNetworkLayerUserInactivity) ||
                (cause == CauseNgapMiscOMIntervention) ||
                (cause == CauseNgapRadioNetworkLayerPartialHandover) ||
                (cause == CauseNgapRadioNetworkLayerSuccessfulHandover))
            {
                ptCi->retainStat.savedEventItem |= RetainItem_UeCtxtRelRequestByGNB_Normal;
            }

            // RETAIN_STAT_BASIC_21C
            if (cause == CauseF1apRadioReleaseDueToPreEmption)
            {
                ptCi->retainStat.savedEventItem |= RetainItem_UeCtxtRelRequestByGNB_Preemption;
            }
            // RETAIN_STAT_HO_21C
            if (IS_INTRA_RAT_REDIRECTION())
            {
                ptCi->retainStat.savedEventItem |= RetainItem_UeCtxtRelRequestByGNB_IntraRatRd;
                MACRO_RETAIN_REMOVE_NORMAL_CAUSE(ptCi);
            }
            else if (IS_INTER_RAT_REDIRECTION())
            {
                ptCi->retainStat.savedEventItem |= RetainItem_UeCtxtRelRequestByGNB_InterRatRd;
                MACRO_RETAIN_REMOVE_NORMAL_CAUSE(ptCi);
            }
            break;
            
        default:
            // RetainCategory_PathSwitchFailure
            // RetainCategory_NgResetByAMF
            // RetainCategory_NgResetByGNB
            // RetainCategory_NgcLinkFailure
            break;
    }

    return;
}

void VLIB_SaveAbnRelCauseCallRetainStat(uint16_t callFaultCause, uint8_t retainCategory, uint8_t &abnRelCause5qi)
{
    if ((retainCategory == RetainCategory_UeCtxtRelCommandByAMF) ||
        (retainCategory == RetainCategory_UeCtxtRelRequestByGNB))
    {
        switch(callFaultCause)
        {
            case CauseNgapRadioNetworkLayerReleaseDueTo5gcGeneratedReason:
                abnRelCause5qi = Retain_AbnRel_CauseNgapRadioNetworkLayerReleaseDueTo5gcGeneratedReason;
                break;
            case CauseNgapRadioNetworkLayerReleaseDueToNgranGeneratedReason:
                abnRelCause5qi = Retain_AbnRel_CauseNgapRadioNetworkLayerReleaseDueToNgranGeneratedReason;
                break;
            case CauseNgapNasUnspecified:
                abnRelCause5qi = Retain_AbnRel_CauseNgapNasUnspecified;
                break;
            case CauseCpInternalTmOutRrcConnectionReconfig:
                abnRelCause5qi = Retain_AbnRel_CauseInternalTmOutRrcConnectionReconfig;
                break;
            case CauseCpInternalDuRlcMaxNumRetx:
                abnRelCause5qi = Retain_AbnRel_CauseInternalDuRlcMaxNumRetx;
                break;
            case CauseCpInternalSaHoTmOutRrcHandoverComplete:
                abnRelCause5qi = Retain_AbnRel_CauseInternalHoTmOutRrcHandoverComplete;
                break;
            case CauseCpInternalSaHoTmOutNgRelocOverall:
                abnRelCause5qi = Retain_AbnRel_CauseInternalHoTmOutNgRelocOverall;
                break;
            case CauseCpInternalSaHoTmOutXnRelocOverall:
                abnRelCause5qi = Retain_AbnRel_CauseInternalHoTmOutXnRelocOverall;
                break;
            default:
                break;
        }
    }
}

void VLIB_SaveEventForCallRetainStat(callInfo_type *ptCi, uint8_t retainCategory, uint32_t cause)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t abnRelCause5qi = Retain_AbnRel_CauseStatMAX;

    // RETAIN_STAT_HO_21C
    // VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[RETAIN_STAT] %s capa(%d) Cat(%d) cause(%d) odfmr(%d) odfrd(%d) odfrel(%d)\n",
    //        __func__, ptCi->retainStat.capableFlag, retainCategory, cause,
    //        ptCi->onDemandInfo.hoTriggered, ptCi->redirectionInfo.onDemandRedirect, ptCi->onDemandInfo.release);

    // Event Category can be saved ONLY when retainStat.capableFlag is on.
    if (ptCi->retainStat.capableFlag != VCCB_FLAG_ON)
    {
        return;
    }

    if(IS_NRDC_SN(ptCi)) return;

    // Check DRB Only Event.
    if ((retainCategory == RetainCategory_PduSessonReleaseByAMF) ||
        (retainCategory == RetainCategory_PduSessonModifyByAMF)  ||
        (retainCategory == RetainCategory_PduSessionNotifyByGNB))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[UeRetainSaveEvent] Invalid Category=%d \n", retainCategory);
        return;
    }

    // First Event Category will be saved. later Event will be ignored.
    // SubItem is allowed to be overlapped.
    if (ptCi->retainStat.savedEventCategory == No_CallDrb_RetainCategory)
    {
        // 1. Save retainStat.savedEventCategory
        ptCi->retainStat.savedEventCategory = retainCategory;

        // Increase collect order before save event
        MACRO_INCREASE_RETAIN_STAT_CSL_COLLECT_ORDER(ptCi);

        // 2. Save retainStat.savedEventItem
        FnVCCB_SaveEventForCallRetainStat_SaveRetainEventItem(ptCi, retainCategory, cause);

        // 3. Check CRR Cause
        // When UE Context Release Command is received, VCCB hasn't stored ngCauset in CallFaultCause yet.
        // Therefore, when receiving a UE Context Release Command, use ngCause(cause) instead of callFaultCause
        uint16_t retainCause = ptCi->cause.callFault.callFaultCause;
        if (retainCategory == RetainCategory_UeCtxtRelCommandByAMF)
            retainCause = static_cast<uint16_t>(cause);

        VLIB_SaveAbnRelCauseCallRetainStat(retainCause, retainCategory, abnRelCause5qi);

        // 4. Call Event can overwrite DRB's retainCategory and sub Item.
        for (int callDrbIdx = 0; callDrbIdx < MAX_DRB_PER_SA_CALL; callDrbIdx++)
        {
            if (ptCi->drb[callDrbIdx].usage != CI_use) continue;

            callDRBInfo_type* ptDi = &ptCi->drb[callDrbIdx];

            // Setup is not included.
            if (ptDi->retainStat.capableFlag != VCCB_FLAG_ON) continue;

            // Check SN Term Bearer
            if ( VCCB_IS_SN_TERM_DRB_WITH_ONLY_CHECK_BEARER_TYPE(ptDi)) continue;

            // Save retainStateForAmfReq if PduSessonModifyByAMF/PduSessonReleaseByAMF.
            if ((ptDi->retainStat.savedEventCategory == RetainCategory_PduSessonModifyByAMF) ||
                (ptDi->retainStat.savedEventCategory == RetainCategory_PduSessonReleaseByAMF))
            {
                // Save another category for AMF Release stat.
                ptDi->retainStatForAmfReq.savedEventCategory = ptDi->retainStat.savedEventCategory;
                ptDi->retainStatForAmfReq.savedEventItem = ptDi->retainStat.savedEventItem;
            }

            // Save DRB Event by Using Call Event.
            ptDi->retainStat.savedEventCategory = ptCi->retainStat.savedEventCategory;
            ptDi->retainStat.savedEventItem = ptCi->retainStat.savedEventItem;
            UPDATE_DRB_ABNORMAL_REL_STAT_CAUSE_5QI(ptDi->retainStat.abnRelCause5qi, abnRelCause5qi);
        }

        // 4. Save VoNR & Emergency Info.
        if(ptCi->rrcConnStat.vonrEmerCallFlag == VCCB_FLAG_ON)
        {
            ptCi->retainStatOfVonrEmer.savedEventCategory = ptCi->retainStat.savedEventCategory;
            ptCi->retainStatOfVonrEmer.savedEventItem     = ptCi->retainStat.savedEventItem;
            UPDATE_DRB_ABNORMAL_REL_STAT_CAUSE_5QI(ptCi->retainStatOfVonrEmer.abnRelCause5qi, abnRelCause5qi);
        }
    }
    else
    {
        //       VCCB_PRINT_CALL_INFORMATIVE(ptCi, "%s No Effect callId:%d savedEventCategory:%d new:%d \n", __func__,
        //               ptCi->callId, ptCi->retainStat.savedEventCategory, retainCategory);
    }

    return;
}

#define SET_PMKEY_FOR_STAT_SETUP_UECONTEXT_RELEASE(ptCi, pPmKey)\
do\
{\
    /* Validation Check */\
    if (ptCi->retainStat.savedEventCategory == No_CallDrb_RetainCategory) return BREAK;\
\
    pPmKey->keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;\
    pPmKey->numKey++; /* key 1 */\
    if (isOldCell == TRUE)  /* oldCellNum */\
    {\
        VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->ueInfo.reestablishInfo.oldCellNum);\
        pOldCell = &CELLINFO[ptCi->ueInfo.reestablishInfo.oldCellNum];\
        pPmKey->keyList[VCCB_PMKEY_INDEX2] = pOldCell->cellIdentity;\
    }\
    else\
    {\
        pPmKey->keyList[VCCB_PMKEY_INDEX2] = pServedCell->cellIdentity;\
    }\
    pPmKey->numKey++; /* key 2 */\
    if (skipTotalType  == FALSE)  /* In Mobility Case(ex. HO, RRE), Don't collect total count(UeContextRelTotal). */\
    {\
        MACRO_STAT_PMCC_ADD_ITEM(   pmMultiCollect->updateItemUintArr,    pmMultiCollect->numOfItem,\
            mActualFamily, UeContextRelTotal, PME_LIB_CC, 1);\
    }\
}while(0)

#define SET_PMKEY_FOR_STAT_VONR_EMERGENCY_RELEASE(ptCi, pPmkey)\
do\
{\
    /* Validation Check */\
    if (ptCi->rrcConnStat.vonrEmerCallFlag != VCCB_FLAG_ON) return BREAK;\
    if (ptCi->retainStatOfVonrEmer.savedEventCategory == No_CallDrb_RetainCategory) return BREAK;\
\
    pPmKey->keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;\
    pPmKey->numKey++; /* key 1 */\
    if (isOldCell == TRUE)  /* oldCellNum */\
    {\
        VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->ueInfo.reestablishInfo.oldCellNum);\
        pOldCell = &CELLINFO[ptCi->ueInfo.reestablishInfo.oldCellNum];\
        pPmKey->keyList[VCCB_PMKEY_INDEX3] = pOldCell->cellIdentity;\
    }\
    else\
    {\
        pPmKey->keyList[VCCB_PMKEY_INDEX3] = pServedCell->cellIdentity;\
    }\
    pPmKey->numKey++; /* key 2 */\
    FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2], (uint16_t)pPmKey->keyList[VCCB_PMKEY_INDEX3], MAX_GNB_PER_SYS); /* DU_ID */\
    pPmKey->numKey++; /* key 3 */\
\
    *drbStatTypeOffset =\
        RETAIN_STAT_DRB_CALL_ITEM_OFFSET;  /* Give offset(4) to mType when it's drb related stats. */\
                                            /* for a reference, see STAT_SETUP_DRB_RELEASE_ITEM & */\
                                            /* STAT_SETUP_UECONTEXT_RELEASE_ITEM. */\
\
    if (skipTotalType == FALSE)  /* In Mobility Case(ex. HO, RRE), Don't collect total count(UeContextRelTotal) */\
    {\
        MACRO_STAT_PMCC_ADD_ITEM(   pmMultiCollect->updateItemUintArr,    pmMultiCollect->numOfItem,\
            mActualFamily, UeContextRelTotal, PME_LIB_CC, 1);\
    }\
}while(0)


#define SET_PMKEY_FOR_STAT_SETUP_DRB_RELEASE(ptCi, pPmKey)\
do\
{\
    pPmKey->keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;\
    pPmKey->numKey++; /* key 1 */\
    if (isOldCell == TRUE)  /* oldCellNum */\
    {\
        VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->ueInfo.reestablishInfo.oldCellNum);\
        pOldCell = &CELLINFO[ptCi->ueInfo.reestablishInfo.oldCellNum];\
        pPmKey->keyList[VCCB_PMKEY_INDEX2] = pOldCell->cellIdentity;\
    }\
    else\
    {\
        pPmKey->keyList[VCCB_PMKEY_INDEX2] = pServedCell->cellIdentity;\
    }\
    pPmKey->numKey++; /* key 2 */\
    VLIB_getFiveQi(&ptCi->qosFlow[ptDi->drbQosIdxInCall], &fiveQi);\
    pPmKey->keyList[VCCB_PMKEY_INDEX3] = fiveQi;  /* pmCC 5QI index */\
    pPmKey->numKey++; /* key 3 */\
\
    *drbStatTypeOffset =\
        RETAIN_STAT_DRB_CALL_ITEM_OFFSET;  /* Give offset(4) to mType when it's drb related stats. */\
                                            /* for a reference, see STAT_SETUP_DRB_RELEASE_ITEM & */\
                                            /* STAT_SETUP_UECONTEXT_RELEASE_ITEM. */\
    if (skipTotalType == FALSE)  /* In Mobility Case(ex. HO, RRE), Don't collect total count(DrbRelTotal). */\
    {\
        MACRO_STAT_PMCC_ADD_ITEM(   pmMultiCollect->updateItemUintArr,    pmMultiCollect->numOfItem,\
            mActualFamily, DrbRelTotal, PME_LIB_CC, 1);\
    }\
}while(0)

#define SET_PMKEY_FOR_STAT_SETUP_DRB_RELEASE_DU_ID_PLMN_SNSSAI(ptCi, pPmKey)\
do\
{\
    pPmKey->keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;\
    pPmKey->numKey++; /* key 1 : gNB ID*/\
    if (isOldCell == TRUE)  /* oldCellNum */\
    {\
        VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->ueInfo.reestablishInfo.oldCellNum);\
        pOldCell = &CELLINFO[ptCi->ueInfo.reestablishInfo.oldCellNum];\
        pPmKey->keyList[VCCB_PMKEY_INDEX3] = pOldCell->cellIdentity;\
    }\
    else\
    {\
        pPmKey->keyList[VCCB_PMKEY_INDEX3] = pServedCell->cellIdentity;\
    }\
    pPmKey->numKey++; /* key 3 : CellIdentity*/\
    FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2], (uint16_t)pPmKey->keyList[VCCB_PMKEY_INDEX3], MAX_GNB_PER_SYS); /* DU_ID */\
    pPmKey->numKey++; /* key 2 : DU_ID*/\
    VLIB_ConvertPlmnIdToPlmnValue(&ptCi->ueInfo.servedPlmn.s2, &uePlmnKey);\
    pPmKey->keyList[VCCB_PMKEY_INDEX4] = uePlmnKey;\
    pPmKey->numKey++; /* key 4 : UE PLMN*/\
    pPmKey->keyList[VCCB_PMKEY_INDEX5] = ptCi->pduSess[ptDi->pduIdxInCall].sNssai.sstSd;  /*SstSd in PDU*/ \
    pPmKey->numKey++; /* key 5 : SNSSAI */ \
    if(mFamily == STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID_PLMN_SNSSAI)\
    {\
        pPmKey->keyList[VCCB_PMKEY_INDEX6] = 0;          /*InSessinStatus (Fixed : 0)*/ \
        pPmKey->numKey++; /* key 6 : Insession Status */ \
    }\
    *drbStatTypeOffset =\
        RETAIN_STAT_DRB_CALL_ITEM_OFFSET;  /* Give offset(4) to mType when it's drb related stats. */\
                                            /* for a reference, see STAT_SETUP_DRB_RELEASE_ITEM & */\
                                            /* STAT_SETUP_UECONTEXT_RELEASE_ITEM. */\
    if (skipTotalType == FALSE)  /* In Mobility Case(ex. HO, RRE), Don't collect total count(DrbRelTotal). */\
    {\
        MACRO_STAT_PMCC_ADD_ITEM(   pmMultiCollect->updateItemUintArr,    pmMultiCollect->numOfItem,\
            mActualFamily, DrbRelTotal, PME_LIB_CC, 1);\
    }\
}while(0)

#define SET_PMKEY_FOR_STAT_SETUP_DRB_RELEASE_PLMN_SNSSAI_5QI(ptCi, pPmKey)                                             \
    do                                                                                                                 \
    {                                                                                                                  \
        VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &cellPlmnKey);                                       \
        pPmKey->keyList[VCCB_PMKEY_INDEX1] = cellPlmnKey;                /* Key 1 : PLMN*/                             \
        pPmKey->keyList[VCCB_PMKEY_INDEX2] = pGnb->globalGnbId.gnbId.id; /* Key 2 : gnbId */                           \
        if (isOldCell == TRUE)                                           /* oldCellNum */                              \
        {                                                                                                              \
            VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->ueInfo.reestablishInfo.oldCellNum);                                   \
            pOldCell = &CELLINFO[ptCi->ueInfo.reestablishInfo.oldCellNum];                                             \
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = pOldCell->cellIdentity;                                               \
        }                                                                                                              \
        else                                                                                                           \
        {                                                                                                              \
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = pServedCell->cellIdentity; /* Key 4 : Cell Identity*/                 \
        }                                                                                                              \
        FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX3],                                     \
            (uint16_t)pPmKey->keyList[VCCB_PMKEY_INDEX4], MAX_GNB_PER_SYS); /* Key 3 : DU_ID */                        \
        VLIB_ConvertPlmnIdToPlmnValue(&ptCi->ueInfo.servedPlmn.s2, &uePlmnKey);                                        \
        pPmKey->keyList[VCCB_PMKEY_INDEX5] = uePlmnKey;                                      /* Key 5 : PLMN_UE */     \
        pPmKey->keyList[VCCB_PMKEY_INDEX6] = ptCi->pduSess[ptDi->pduIdxInCall].sNssai.sstSd; /* Key 6 : SstSd in PDU*/ \
        VLIB_getFiveQi(&ptCi->qosFlow[ptDi->drbQosIdxInCall], &fiveQi);                                                \
        pPmKey->keyList[VCCB_PMKEY_INDEX7] = fiveQi; /* Key 7 : 5QI */                                                 \
                                                                                                                       \
        pPmKey->usageOfNumKey = CI_use;                                                                                \
        pPmKey->numKey = VCCB_PMKEY_INDEX7 + 1; /* numKey : 7 */                                                       \
                                                                                                                       \
        *drbStatTypeOffset =                                                                                           \
            RETAIN_STAT_DRB_CALL_ITEM_OFFSET; /* Give offset(4) to mType when it's drb related stats. */               \
                                              /* for a reference, see STAT_SETUP_DRB_RELEASE_ITEM & */                 \
                                              /* STAT_SETUP_UECONTEXT_RELEASE_ITEM. */                                 \
        if (skipTotalType == FALSE) /* In Mobility Case(ex. HO, RRE), Don't collect total count(DrbRelTotal). */       \
        {                                                                                                              \
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem, mActualFamily,      \
                DrbRelTotal, PME_LIB_CC, 1);                                                                           \
        }                                                                                                              \
    } while (0)


#define SET_PMKEY_FOR_STAT_SETUP_ACTIVE_DRB_RELEASE_FAMILY(ptCi, pPmKey)\
do\
{\
            pPmKey->keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;\
            pPmKey->numKey++; /* key 1 */\
\
            if (isOldCell == TRUE)  /* oldCellNum */\
            {\
                VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->ueInfo.reestablishInfo.oldCellNum);\
                pOldCell = &CELLINFO[ptCi->ueInfo.reestablishInfo.oldCellNum];\
                pPmKey->keyList[VCCB_PMKEY_INDEX2] = pOldCell->cellIdentity;\
            }\
            else\
            {\
                pPmKey->keyList[VCCB_PMKEY_INDEX2] = pServedCell->cellIdentity;\
            }\
            pPmKey->numKey++; /* key 2 */\
\
            VLIB_getFiveQi(&ptCi->qosFlow[ptDi->drbQosIdxInCall], &fiveQi);\
            pPmKey->keyList[VCCB_PMKEY_INDEX3] = fiveQi;     /* pmCC 5QI index */\
            pPmKey->numKey++; /* key 3 */\
\
            pPmKey->keyList[VCCB_PMKEY_INDEX4] = IN_SESSION_STATUS_ACTIVE;          /* InSessionStatus (Fixed : 0) */\
            pPmKey->numKey++; /* key 4 */\
\
            if(mFamily == STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID) /* gNB_ID / gNB_DU_ID / CellIdentity / 5QI / InSessionStatus */ \
            {\
                /* Add gNB_DU_ID into index2 */\
                VCCB_PMKEY_SHIFT(pPmKey, VCCB_PMKEY_INDEX2); \
                FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2], (uint16_t)pPmKey->keyList[VCCB_PMKEY_INDEX3], MAX_GNB_PER_SYS); /* DU_ID */\
                pPmKey->numKey++; /*2->3->4->5->... */\
            }\
            else if(mFamily == STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID_PLMN) /* For MOCN */\
            {                                                            /* gNB_ID / gNB_DU_ID / CellIdentity / PLMN_UE / 5QI / InSessionStatus */ \
                /* Add gNB_DU_ID into index2 */\
                VCCB_PMKEY_SHIFT(pPmKey, VCCB_PMKEY_INDEX2); \
                FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2], (uint16_t)pPmKey->keyList[VCCB_PMKEY_INDEX3], MAX_GNB_PER_SYS); /* DU_ID */\
                pPmKey->numKey++; /*2->3->4->5->... */\
\
                /* Add UE PLMN into index4 */\
                VCCB_PMKEY_SHIFT(pPmKey, VCCB_PMKEY_INDEX4); \
                VLIB_ConvertPlmnIdToPlmnValue(&ptCi->ueInfo.servedPlmn.s2, &uePlmnKey); \
                pPmKey->keyList[VCCB_PMKEY_INDEX4] = uePlmnKey; \
                pPmKey->numKey++; /*4->5->6... */\
            }\
            else if(mFamily == STAT_SETUP_ACTIVE_DRB_RELEASE_GLOBAL_ID_PLMN) /* for MSO Only */\
            {                                                                /* PLMN / gNB_ID / CellIdentity / PLMN_UE / 5QI / InSessionStatus */ \
                /* Add Cell PLMN into index1 */\
                VCCB_PMKEY_SHIFT(pPmKey, VCCB_PMKEY_INDEX1); /*1->2->3->4->5->... */ \
                VLIB_ConvertPlmnIdToPlmnValue(&pGnb->globalGnbId.plmn.s2, &cellPlmnKey); \
                pPmKey->keyList[VCCB_PMKEY_INDEX1] = cellPlmnKey;\
                pPmKey->numKey++; /* key 1 */\
\
                /* Add UE PLMN into index4 */\
                VCCB_PMKEY_SHIFT(pPmKey, VCCB_PMKEY_INDEX4); /*4->5->6->... */\
                VLIB_ConvertPlmnIdToPlmnValue(&ptCi->ueInfo.servedPlmn.s2, &uePlmnKey); \
                pPmKey->keyList[VCCB_PMKEY_INDEX4] = uePlmnKey; \
                pPmKey->numKey++; /* key 4 */\
            }\
\
            *drbStatTypeOffset =\
                RETAIN_STAT_DRB_CALL_ITEM_OFFSET;  /* Give offset(4) to mType when it's drb related stats. */\
                                                   /* for a reference, see STAT_SETUP_DRB_RELEASE_ITEM & */\
                                                   /* STAT_SETUP_UECONTEXT_RELEASE_ITEM. */\
\
            if (skipTotalType == FALSE)  /* In Mobility Case(ex. HO, RRE), Don't collect total count(DrbRelTotal). */\
            {\
                MACRO_STAT_PMCC_ADD_ITEM(   pmMultiCollect->updateItemUintArr,    pmMultiCollect->numOfItem,\
                    mActualFamily, Active_DrbRelTotal_DUID, PME_LIB_CC, 1);\
            }\
}while(0)

#define SET_PMKEY_FOR_STAT_SETUP_ACTIVE_UECONTEXT_RELEASE(ptCi, pPmKey)\
do\
{\
    /* Validation Check */\
    if (ptCi->retainStat.savedEventCategory == No_CallDrb_RetainCategory) return BREAK;\
\
    pPmKey->keyList[VCCB_PMKEY_INDEX1] = pGnb->globalGnbId.gnbId.id;\
    pPmKey->numKey++; /* key 1 */\
    if (isOldCell == TRUE)  /* oldCellNum */\
    {\
        VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->ueInfo.reestablishInfo.oldCellNum);\
        pOldCell = &CELLINFO[ptCi->ueInfo.reestablishInfo.oldCellNum];\
        pPmKey->keyList[VCCB_PMKEY_INDEX3] = pOldCell->cellIdentity;\
    }\
    else\
    {\
        pPmKey->keyList[VCCB_PMKEY_INDEX3] = pServedCell->cellIdentity;\
    }\
    pPmKey->numKey++; /* key 2 */\
    FnVCCB_UpdateGnbDuIdUsingCellId(ptCi, &pPmKey->keyList[VCCB_PMKEY_INDEX2], (uint16_t)pPmKey->keyList[VCCB_PMKEY_INDEX3], MAX_GNB_PER_SYS); /* DU_ID */\
    pPmKey->numKey++; /* key 3 */\
    pPmKey->keyList[VCCB_PMKEY_INDEX4] = 0; /* InSessinStatus (Fixed : 0) */\
    pPmKey->numKey++; /* key 4 */\
    if (skipTotalType  == FALSE)  /* In Mobility Case(ex. HO, RRE), Don't collect total count(UeContextRelTotal). */\
    {\
        MACRO_STAT_PMCC_ADD_ITEM(   pmMultiCollect->updateItemUintArr,    pmMultiCollect->numOfItem,\
            mActualFamily, UeContextRelTotal, PME_LIB_CC, 1);\
    }\
} while (0)

#define RETAIN_STAT_DRB_CALL_ITEM_OFFSET 4

void VLIB_LibStatPmCC_Retain(int mFamily, callInfo_type *ptCi, callDRBInfo_type *ptDi, uint16_t retainCategory,
    uint16_t retainItem, uint32_t isOldCell, uint32_t isMobility)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    int status = GOOD;

    VccbPmKey_type pmKey;
    VccbPmKey_type *pPmKey = &pmKey;
    memset(pPmKey, 0, sizeof(VccbPmKey_type));
    VccbPmMultiCollect_type pmMultiCollect;
    retainExtraInfo_type retainExtraInfo;
    memset(&retainExtraInfo, 0, sizeof(retainExtraInfo));
    retainExtraInfo.cslInfo.abnRelCause5qi = Retain_AbnRel_CslMAX;  // It's for CSL and CauseStat

    uint8_t drbStatTypeOffset = 0;
    uint8_t isCollectAbnormalItem = VCCB_FLAG_OFF;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);
    VCCB_CHECK_VALID_CELLNUM_VOID(ptCi->servCellNum);
    uint16_t gnbNum = ptCi->gnbNum;

    if (ptCi->callType != E_CALLTYPE_SA) return;
    if (IS_NRDC_SN(ptCi)) return;

    // Check 'SETUP_DRB_RELEASE' family
    status = VLIB_LibStatPmCC_Retain_Validation(mFamily, ptCi, ptDi, &isCollectAbnormalItem);
    if(status != GOOD) return;

    int mActualFamily = mFamily;
    StatisticsHandler statHandler(gnbNum);
    statHandler.changeFamilyForFOO(mFamily, mActualFamily);

    // VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[RETAIN_STAT] %s mFamily(%d) retainCategory(%d) retainItem(0x%x)  \n",
    //        __func__, mFamily, retainCategory, retainItem);

    FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_CC);
    pPmKey->usageOfNumKey = CI_use;  // For 7 PmKey for Retain

    // Set pPmKey
    status = VLIB_LibStatPmCC_Retain_SetPmkey(ptCi, ptDi, pPmKey, &pmMultiCollect, mFamily, mActualFamily,
        retainCategory, isOldCell, isMobility, &drbStatTypeOffset, &retainExtraInfo);
    if(status != GOOD)
    {
        return;
    }

    VccbPmKey_type orgPmKey = pmKey; // for Retain ServiceType
    if( mFamily != mActualFamily)
    {
        statHandler.fillStatisticsIndex(ptCi, pmKey, mFamily, mActualFamily);
    }

    // Set retainItem using PmLib
    status = VLIB_LibStatPmCC_Retain_Collect_PmLib(ptCi, &pmMultiCollect, mFamily, mActualFamily, retainCategory,
        retainItem, isCollectAbnormalItem, drbStatTypeOffset, &retainExtraInfo);
    if(status != GOOD)
    {
        return;
    }

    // Call Statistic API
    CollectPmStatistics(
        ptCi, (unsigned)mFamily, (unsigned)mActualFamily, &pmMultiCollect, pmMultiCollect.updateItemUintArr, pmKey, TRUE);

    // Check Service Type Statistics
    if( (MACRO_IS_SERVICE_TYPE_STAT_ON()) &&
        ((mFamily == STAT_SETUP_UECONTEXT_RELEASE)        ||
         (mFamily == STAT_SETUP_DRB_RELEASE)              ||
         (mFamily == STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID) ||
         (mFamily == STAT_SETUP_ACTIVE_DRB_RELEASE_GLOBAL_ID_PLMN))  // for future usage of MSO. currently no case in SVR25B
    )
    {
        FnVCCB_CollectNrRetainServiceType(ptCi, mFamily, ptDi, &pmMultiCollect, orgPmKey);
    }

    // Clear the flag after collecting DRB stats.
    switch (mFamily)
    {
        case STAT_SETUP_UECONTEXT_RELEASE:
            SET_CALL_RETAIN_STAT_CAPABLE_FLAG(ptCi, VCCB_FLAG_OFF);
            CLEAR_RETAIN_STAT_EVENT(ptCi->retainStat);
            ptCi->bitFlag.activeUeContextRelease = VCCB_FLAG_OFF;
            break;
        case STAT_SETUP_DRB_RELEASE:
            SET_DRB_RETAIN_STAT_CAPABLE_FLAG(ptDi, VCCB_FLAG_OFF);
            CLEAR_DRB_RETAIN_STAT_EVENT(ptDi);
            ptDi->retainStat.inSessionFlagByE1 = VCCB_FLAG_OFF;
            break;
        case STAT_VONR_EMERGENCY_RELEASE:
            // Not clear capable. only clear event.
            CLEAR_RETAIN_STAT_EVENT(ptCi->retainStatOfVonrEmer);
            break;
        default:
            return;
    }
    return;
}

/*
 * @brief     For collecting ERAB_ADD or ERAB_MOD statistics
 * @param     ptCi : callInfo
 * @param     type : stat type
 */
void VLIB_CollectErabAddModStat(callInfo_type *ptCi, uint32_t erabAddType, uint32_t erabModType, uint32_t erabChgType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    uint16_t loop = 0;

    VLIB_PrepareQciAttemptSuccess(ptCi, (int)erabAddType);
    for (loop = 0; loop < MAX_ERAB_PER_CALL; loop++)
    {
        if (ptCi->erabInfo[loop].usage != CI_use) continue;

        // Statistics Update
        ptCi->ptTempRi = &ptCi->erabInfo[loop];
        if ((ERAB_Setup == ptCi->erabInfo[loop].erabStatus) ||
            ((ERAB_Modify == ptCi->erabInfo[loop].erabStatus) && (ERAB_Setup == ptCi->erabInfo[loop].prevErabStatus)))
        {
            // ERAB SETUP CASE
            MACRO_STAT_PMCC_QCI(STAT_ERAB_ADD_PER_GNB, (int)erabAddType, ptCi, ptCi->ptTempRi, 0, 0, 0, 0);
            VLIB_PeggQciAttemptSuccess(ptCi, ptCi->erabInfo[loop].erabQos.qciValue.QCI, (int)erabAddType);
            if (ErabAddSucc == erabAddType)
            {
                VLIB_CallStatProcessAnswer(ptCi, ptCi->ptTempRi);

                ptCi->erabInfo[loop].addSuccessFlagForStat = FLAG_ON;
                VRRM_addCellDrbCount(ptCi, ptCi->servCellNum, loop);
            }
        }
        else if (ERAB_Modify == ptCi->erabInfo[loop].erabStatus || ERAB_FailToModify == ptCi->erabInfo[loop].erabStatus)
        {
            if (ptCi->erabInfo[loop].preveBearerType != ptCi->erabInfo[loop].bearerType)
            {
                if ((ErabModSucc_Change == erabChgType) && (STATE_DCModE1_CompltInd != ptCi->state))
                {
                    continue;
                }
                // ERAB BEARER CHANGE CASE
                MACRO_STAT_PMCC_QCI(STAT_ERAB_CHG_PER_GNB, (int)erabChgType, ptCi, ptCi->ptTempRi, 0, 0, 0, 0);
            }
            // ERAB MODIFY CASE
            MACRO_STAT_PMCC_QCI(STAT_ERAB_MOD_PER_GNB, (int)erabModType, ptCi, ptCi->ptTempRi, 0, 0, 0, 0);
            if (ErabModSucc == erabModType)
            {
                if (ptCi->erabInfo[loop].erabQos.qciValue.QCI != ptCi->erabInfo[loop].erabQos.qciValue.oldQCI)
                {
                    VLIB_CalculateErabHoldTime(ptCi, &ptCi->erabInfo[loop], CAL_MOD);
                    VLIB_CallStatProcessAnswer(ptCi, &ptCi->erabInfo[loop]);

                    // Update cellDrbCount per QCI according to QCI Change
                    VRRM_delCellDrbCount(ptCi, ptCi->servCellNum, loop,
                        TRUE);  // Decrease CellDrbCount using old QCI value
                    VRRM_addCellDrbCount(ptCi, ptCi->servCellNum,
                        loop);  // Increase CellDrbCount using current QCI value
                }
            }
        }
    }

    return;
}

/*
 * @brief     For collecting NSA Handover Preparation Fail Stat
 * @param     ptCi : callInfo
 * @param     type : stat type
 */
void VLIB_CollectNsaHoCpFailStat(callInfo_type *ptCi, int isPrepFail)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (HO_TYPE_MENB_INITIATED == ptCi->hoInfo.hoType.initiated)
    {
        if (isPrepFail == TRUE)
        {
            MACRO_STAT_PMCC(
                STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB, EndcModByMenbMcgMobPrepFail_CpFail, ptCi, 0, 0, 0, 0, 0);
        }
        else
        {
            MACRO_STAT_PMCC(
                STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB, EndcModByMenbMcgMobFail_CpFail, ptCi, 0, 0, 0, 0, 0);
        }
    }
    else if (HO_TYPE_MENB_INTERMNHO == ptCi->hoInfo.hoType.initiated)
    {
        for (callERABInfo_type &erab : ptCi->erabInfo)
        {
            if (CI_use != erab.usage)
            {
                continue;
            }

            if ((ERAB_Setup == erab.prevErabStatus) || (ERAB_Setup == erab.erabStatus))
            {
                VLIB_StatErabAddInterMnHO(ptCi, ErabAddFail_CpFail, TRUE);
            }
        }

        if (isPrepFail == TRUE)
        {
            VCCB_NSA_PegSgnbAddIntraLteHoNoSgnbChg(*ptCi, EndcAddLteHoNoSgnbChgPrepFail_CpFail);
        }
        else
        {
            VCCB_NSA_PegSgnbAddIntraLteHoNoSgnbChg(*ptCi, EndcAddLteHoNoSgnbChgFail_CpFail);
        }
    }
    else if (HO_TYPE_SGNB_INITIATED == ptCi->hoInfo.hoType.initiated)
    {
        if (isPrepFail == TRUE)
        {
            VCCB_NSA_PegIntraSnPscellChange(*ptCi, EndcIntraChgPrepFail_CpFail);
        }
        else
        {
            VCCB_NSA_PegIntraSnPscellChange(*ptCi, EndcIntraChgFail_CpFail);
        }
    }

    return;
}

/*
 * @brief           Collect HO Success Statistics and finalizing Handover
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @return          status : GOOD, ERROR / int16_t
 */
int16_t VLIB_CollectNsaHoSuccessStatAndFinalizeHandover(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (HO_TYPE_MENB_INITIATED == ptCi->hoInfo.hoType.initiated)
    {
        MACRO_STAT_PMCC(STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB, EndcModByMenbMcgMobSucc, ptCi, 0, 0, 0, 0, 0);
    }
    else
    {
        VCCB_NSA_PegIntraSnPscellChange(*ptCi, EndcIntraChgSucc);
        MACRO_STAT_PMCC(STAT_INTRA_FREQ_PSCELL_CHANGE_SCGMOB_PER_GNB_DU_ID, EndcIntraFreqIntraSnChgSucc, ptCi, 0, 0, 0, 0, 0);
    }

    if ((HO_TYPE_MENB_INTERMNHO == ptCi->hoInfo.hoType.initiated) ||
        ((HO_TYPE_MENB_INITIATED == ptCi->hoInfo.hoType.initiated) &&
            (CauseX2apRadioNetworkLayerScgMobility != ptCi->cause.x2Cause)))
    {
        SET_PROC_FOR_STAT(ptCi, INTRA_SN_MOB_BY_ENB_PROC);
    }

    if ((HO_TYPE_SGNB_INITIATED == ptCi->hoInfo.hoType.initiated) ||
        ((HO_TYPE_MENB_INITIATED == ptCi->hoInfo.hoType.initiated) &&
            (CauseX2apRadioNetworkLayerScgMobility == ptCi->cause.x2Cause)))
    {
        SET_PROC_FOR_STAT(ptCi, INTRA_SN_MOB_BY_GNB_PROC);
    }

    status = VHCM_FinalizeHandover(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VHCM_FinalizeHandover ERROR!\n");

    return GOOD;
}

/*
 * @brief           Collect HO Success Statistics and finalizing Handover in IntraDuHo_E1apDrbModResume state
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @return          status : GOOD, ERROR / int16_t
 */
int16_t VLIB_CollectNsaHoSuccessStatAndFinalizeHandover_IntraDuHo_E1apDrbModResume(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (HO_TYPE_MENB_INITIATED == ptCi->hoInfo.hoType.initiated)
    {
        MACRO_STAT_PMCC(STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB, EndcModByMenbMcgMobSucc, ptCi, 0, 0, 0, 0, 0);
    }
    else if (HO_TYPE_SGNB_INITIATED == ptCi->hoInfo.hoType.initiated)
    {
        VCCB_NSA_PegIntraSnPscellChange(*ptCi, EndcIntraChgSucc);
        MACRO_STAT_PMCC(STAT_INTRA_FREQ_PSCELL_CHANGE_SCGMOB_PER_GNB_DU_ID, EndcIntraFreqIntraSnChgSucc, ptCi, 0, 0, 0, 0, 0);
    }

    if (HO_TYPE_MENB_INTERMNHO != ptCi->hoInfo.hoType.initiated)
    {
        status = VIIL_sendCallResourceChangeInd(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VIIL_sendCallResourceChangeInd ERROR!\n");
    }

    if ((HO_TYPE_MENB_INTERMNHO == ptCi->hoInfo.hoType.initiated) ||
        ((HO_TYPE_MENB_INITIATED == ptCi->hoInfo.hoType.initiated) &&
            (CauseX2apRadioNetworkLayerScgMobility != ptCi->cause.x2Cause)))
    {
        SET_PROC_FOR_STAT(ptCi, INTRA_SN_MOB_BY_ENB_PROC);
    }

    if ((HO_TYPE_SGNB_INITIATED == ptCi->hoInfo.hoType.initiated) ||
        ((HO_TYPE_MENB_INITIATED == ptCi->hoInfo.hoType.initiated) &&
            (CauseX2apRadioNetworkLayerScgMobility == ptCi->cause.x2Cause)))
    {
        SET_PROC_FOR_STAT(ptCi, INTRA_SN_MOB_BY_GNB_PROC);
    }

    status = VHCM_FinalizeHandover(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VHCM_FinalizeHandover ERROR!\n");

    return status;
}

/*
 * @brief           Collect HO Success Statistics and finalizing Handover
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @return          status : GOOD, ERROR / int16_t
 */
int16_t VLIB_CollectNsaModSuccessStatAndSetStableState(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // Note: For SN init SN modification counter counting probably never occur below. For SGNB_INIT_SGNB_MOD_PER_GNB
    // statistic EndcModBySgnbSucc is counting whenever gNB receives SgNBModificationConfirm.
    if (SgNBModificationConfirm_cmd == ptCi->stateCmd || SgNBInitBearerChangeToMcg_cmd == ptCi->stateCmd)
    {
        MACRO_STAT_PMCC(STAT_SGNB_INIT_SGNB_MOD_PER_GNB, EndcModBySgnbSucc, ptCi, 0, 0, 0, 0, 0);
        VLIB_SetNoAttemptFlag(ptCi, STAT_SGNB_INIT_SGNB_MOD_PER_GNB);
    }
    else
    {
        MACRO_STAT_PMCC(STAT_MENB_INIT_SGNB_MOD_PER_GNB, EndcModByMenbSucc, ptCi, 0, 0, 0, 0, 0);
        VLIB_SetNoAttemptFlag(ptCi, STAT_MENB_INIT_SGNB_MOD_PER_GNB);
        SET_PROC_FOR_STAT(ptCi, MOD_BY_ENB_PROC);
    }

    VCCM_SetStableState_CallSetup(ptCi);

    return GOOD;
}

/*
 * @brief           Collect Stat of "PDU Session Resource Setup" with failure cause
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @return          void
 */
void VLIB_PduSessionResourceSetup_CollectStat_AllFailedCause(callInfo_type *ptCi, uint16_t reqCause)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t callPduIdx = 0;
    uint8_t pduQosFlowIdx = 0;
    uint8_t callQosFlowIdx = 0;
    uint8_t pduDrbIdx = 0;
    uint8_t callDrbIdx = 0;

    callPDUSessInfo_type *ptPi = NULL;
    qosFlowInfo_type *ptQi = NULL;
    callDRBInfo_type *ptDi = NULL;

    for (callPduIdx = 0; callPduIdx < MAX_PDU_SESS_PER_CALL; callPduIdx++)
    {
        ptPi = &ptCi->pduSess[callPduIdx];
        if (ptPi->usage != CI_use) continue;

        uint16_t pduCause;
        if (ptPi->failCause != CAUSE_NO_FAULT)
            pduCause = ptPi->failCause;
        else
            pduCause = reqCause;


        if (ptPi->pduStatistic.attemptFlag[PDU_SESSION_RESOURCE_SETUP_PLMN_SNSSAI] == ATTEMPT_MADE)
        {
            VLIB_PduSessionResourceSetup_CollectStat_FailedPduItem(
                ptCi, pduCause, callPduIdx, STAT_PDU_SESSION_RESOURCE_SETUP_PLMN_SNSSAI);
        }
        if (ptPi->pduStatistic.attemptFlag[PDU_SESSION_RESOURCE_MODIFY_PLMN_SNSSAI_RFSP] == ATTEMPT_MADE)
        {
            VLIB_PduSessionResourceSetup_CollectStat_FailedPduItem(
                ptCi, pduCause, callPduIdx, STAT_PDU_SESSION_RESOURCE_MODIFY_PLMN_SNSSAI_RFSP);
        }

        for (pduQosFlowIdx = 0; pduQosFlowIdx < MAX_QOS_FLOW_PER_PDU_SESS; pduQosFlowIdx++)
        {
            callQosFlowIdx = (uint8_t)ptPi->qosFlowIndex[pduQosFlowIdx];

            if (callQosFlowIdx >= MAX_QOS_FLOW_PER_CALL) continue;
            ptQi = &ptCi->qosFlow[callQosFlowIdx];
            if (ptQi->usage != CI_use) continue;

            if (ptQi->qosFlowStatistic.attemptFlag[QOS_FLOW_SETUP] == ATTEMPT_MADE)
            {
                if (ptQi->failCause != CAUSE_NO_FAULT)
                    VLIB_QosFlowSetup_CollectStat_FailedQosflowItem(ptCi, ptQi->failCause,
                        ptPi, ptQi, STAT_QOS_FLOW_SETUP);
                else
                    VLIB_QosFlowSetup_CollectStat_FailedQosflowItem(ptCi, reqCause, ptPi,
                        ptQi, STAT_QOS_FLOW_SETUP);
            }

            if (ptQi->qosFlowStatistic.attemptFlag[QOS_FLOW_SETUP_PLMN_SNSSAI] == ATTEMPT_MADE)
            {
                if (ptQi->failCause != CAUSE_NO_FAULT)
                    VLIB_QosFlowSetup_CollectStat_FailedQosflowItem(ptCi, ptQi->failCause,
                        ptPi, ptQi, STAT_QOS_FLOW_SETUP_PLMN_SNSSAI);
                else
                    VLIB_QosFlowSetup_CollectStat_FailedQosflowItem(ptCi, reqCause, ptPi,
                        ptQi, STAT_QOS_FLOW_SETUP_PLMN_SNSSAI);
            }
        }

        // It's collected when receive F1/E1 failure. So Do not consider drbFailCause.
        for (pduDrbIdx = 0; pduDrbIdx < MAX_DRB_PER_PDU_SESS; pduDrbIdx++)
        {
            callDrbIdx = static_cast<uint8_t>(ptPi->drbIndex[pduDrbIdx]);
            if (callDrbIdx >= MAX_DRB_PER_SA_CALL) continue;

            ptDi = &ptCi->drb[callDrbIdx];
            if (ptDi->usage != CI_use) continue;

            MACRO_STAT_COLLECT_ALL_DRB_SETUP_WITH_CAUSE(ptCi, ptDi, callDrbIdx, reqCause);
        }
    }
}

/*
 * @brief           Returns TRUE if family INTRA_FREQ_PSCELL_CHANGE_SCGMOB_PER_GNB* must be pegged.
 *                  Otherwise returns FALSE.
 *                  Related feature: Mobility for EN-DC, FR543, FR545.
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @return          int : TRUE / FALSE
 */
bool VLIB_NeedToPegIntraFreqPscellChangeScgMob(const callInfo_type &call)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(call.servCellNum, false);

    // Must be SCG Mobility.
    if ((IntraRatHO_cmd != call.stateCmd) || (HO_TYPE_SGNB_INITIATED != call.hoInfo.hoType.initiated))
    {
        return false;
    }
    // Must be intra-frequency handover.
    uint32_t tgtCellFreq = 0;
    if (GOOD != VLIB_GetTgtCellFreqForHo(&call, &tgtCellFreq))
    {
        return false;
    }
    const auto srcCellFreq = CELLINFO[call.servCellNum].ssbArfcn;
    if (srcCellFreq != tgtCellFreq)
    {
        return false;
    }
    // All conditions met.
    return true;
}

/*
 * @brief           Pegges one of following counter from INTRA_SN_PSCELL_CHANGE_PER_GNB family
 *                  depending on condition:
 *                  EndcIntraChgSucc - PSCell change is not performed due to SgNB Modification Refuse
 *                  with 'Cause=mCG-Mobility' or 'Cause=message_not_compatible_with_receiver_state' from MeNB (TELUS
 * behavior only) EndcIntraChgFail_MenbFail - SgNB Modification Refuse msg includes other cause than mCG-Mobility or
 * message_not_compatible_with_receiver_state (TELUS behavior only); or for other operators besides TELUS when SgNB
 * Modification Refuse comes.
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @param[in]       ptUnpack : Call information / msgUnpack_type
 */
void VLIB_PegEndcIntraChg_SuccOrFailMenbFailWhenX2ModRefuse(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptUnpack);

    X2_SgNBModificationRefuse_type *ptMsg = nullptr;
    uint16_t x2Cause = CAUSE_NO_FAULT;

    if (IntraRatHO_cmd != ptCi->stateCmd)
    {
        return;
    }
    if (HO_TYPE_SGNB_INITIATED != ptCi->hoInfo.hoType.initiated)
    {
        return;
    }

    ptMsg = reinterpret_cast<X2_SgNBModificationRefuse_type *>(ptUnpack->unpack);
    VXIL_StoreIE_Cause_type(&ptMsg->cause, &x2Cause);

    if ((TRUE == FOO.VF_MobilityforENDC_PsCellChangeCounterSpecificPegging) &&
        ((CauseX2apRadioNetworkLayerMcgMobility == x2Cause) ||
            (CauseX2apProtocolMessageNotCompatibleWithReceiverState == x2Cause)))
    {
        // FGR-LC0708 FR60 is not applied here.
        // F_MobilityforENDC_PsCellChangeCounterSpecificPegging != F_LoadBasedPscellChangeEndc_UseLbPscellChangeFamily.
        VCCB_NSA_PegIntraSnPscellChange(*ptCi, EndcIntraChgSucc);
        // Mobility for EN-DC FR558.
        MACRO_STAT_PMCC(
            STAT_PSCELL_CHANGE_REFUSED_MCGMOB_PER_CELL_DU_ID, EndcIntraSnPscellChngRefMcgMob, ptCi, 0, 0, 0, 0, 0);
    }
    else
    {
        VCCB_NSA_PegIntraSnPscellChange(*ptCi, EndcIntraChgFail_MenbFail);
    }
}

/*
 * @brief           Tries to check target cell's frequency based on handover type.
 *                  On success returns GOOD and stores selected frequency in cellFreq.
 *                  Returns ERROR otherwise.
 *
 * @param[in/out]   ptCi         : Call information / callInfo_type
 * @param[in/out]   pTgtCellFreq : Buffer for target cell frequency value
 * @return          int          : GOOD / ERROR
 */
int VLIB_GetTgtCellFreqForHo(const callInfo_type *ptCi, uint32_t *pTgtCellFreq)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pTgtCellFreq);

    if (IntraRatHO_cmd != ptCi->stateCmd)
    {
        return ERROR;
    }
    if (HO_TYPE_INTRA_NB == ptCi->hoInfo.hoType.nb)
    {
        VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->hoInfo.targetCellNum, MAX_CELL_NUM_VCCB);
        *pTgtCellFreq = CELLINFO[ptCi->hoInfo.targetCellNum].ssbArfcn;
        return GOOD;
    }
    else if (HO_TYPE_INTER_NB == ptCi->hoInfo.hoType.nb)
    {
        nbrGnbCellInfo_type *nbrGnbCellInfo = NULL;

        VCCB_RETURN_ON_CALL_ERROR(ptCi,
            getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, ptCi->hoInfo.tgtNbrGnbCell, &nbrGnbCellInfo),
            "getNbrGnbCellByCellNbrIdx ERROR!\n");
        *pTgtCellFreq = nbrGnbCellInfo->ssbArfcn;
        return GOOD;
    }
    // Invalid handover type.
    return ERROR;
}

/**
 * @brief     return additional statistics for VLIB_LibStatPmGauge function
 * @param     ptCi : call context pointer
 * @param     mFamily : statistics family
 * @param     type : statistics type in family
 * @return    additional type
 */
int FnVCCB_GetAdditionalTypeForPmGauge(callInfo_type *ptCi, int mFamily, int type)
{
    AUTO_TRACE_FUNC;
    int mType = -1;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, mType);

    switch (mFamily)
    {
        case STAT_HO_TIME:  // 5199
            return FnVCCB_CollectVoNRStatFromHoTime(ptCi, mFamily, type);
            break;

        default:
            return mType;
    }

    return mType;
}

void VLIB_QosFlowSetup_CollectStat_FailedQosflowItem(
    callInfo_type *ptCi, uint16_t cause, callPDUSessInfo_type *ptPi, qosFlowInfo_type *ptQi, int32_t mFamily)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptPi);
    VALID_E_POINT_CHECK_VOID(ptQi);

    uint16_t f1CauseEnd, e1CauseEnd, ngCauseEnd;

    int sliceFail = ptQi->rxNotSupportSlice;
    int mType     = QosFlowSetupFail_CpFail;

    f1CauseEnd = CauseF1apMax;
    e1CauseEnd = CauseE1apMax;
    ngCauseEnd = CauseNgapMax;

    if ((cause == CauseCpInternalF1SctpOutOfService) || (cause >= CAUSE_BASE_F1AP_RADIONETWORK && cause < f1CauseEnd))
    {
        mType = QosFlowSetupFail_F1Fail;
    }
    else if ((cause == CauseCpInternalE1SctpOutOfService) ||
             (cause >= CAUSE_BASE_E1AP_RADIONETWORK && cause < e1CauseEnd))
    {
        mType = QosFlowSetupFail_E1Fail;
    }
    else if ((cause == CauseCpInternalSaNgSctpOutOfService) ||
             (cause >= CAUSE_BASE_NGAP_RADIONETWORK && cause < ngCauseEnd))
    {
        mType = QosFlowSetupFail_NgFail;
    }
    else if ((cause == CauseCpInternalSaTmOutRrcUeCapabilityEnquiry) ||
             (cause == CauseCpInternalSaTmOutRrcSecurityModeCommand) ||
             (cause == CauseCpInternalTmOutRrcConnectionReconfig))
    {
        mType = QosFlowSetupFail_RrcTimeout;
    }
    else if ((cause == CauseCpInternalTmOutE1BearerSetup) || (cause == CauseCpInternalTmOutE1BearerContextModification))
    {
        mType = QosFlowSetupFail_E1Timeout;
    }
    else if ((cause == CauseCpInternalTmOutF1UeContextSetup) || (cause == CauseCpInternalTmOutF1UeContextModification))
    {
        mType = QosFlowSetupFail_F1Timeout;
    }
    else
    {
        mType = QosFlowSetupFail_CpFail;
    }

    MACRO_STAT_PMCC_QosFlow(mFamily, mType, ptCi, ptPi, ptQi, sliceFail, 0, 0);
}

void VLIB_StatNrdcScgFailure(callInfo_type *ptCi)  // revised in SVR22B
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->callType == E_CALLTYPE_NSA) return;

    uint16_t index = STAT_NRDC_SN_REL_MN_END;

    if (NrDcScgFailureSnRelease == ptCi->nrdcScgFailureInfo.failAction)
    {
        switch (ptCi->nrdcScgFailureInfo.failType)
        {
            case NrDcScgFailCause_dl_t310Expiry:      // 0
                index = NrdcRelMn_MnInit_t310Expiry;  // 11
                break;

            case NrDcScgFailCause_dl_randomAccessProblem:      // 1
                index = NrdcRelMn_MnInit_randomAccessProblem;  // 12
                break;

            case NrDcScgFailCause_dl_rlcMaxRetransmission:  // 2
                index = NrdcRelMn_MnInit_rlcMaxNumRetx;     // 13
                break;

            case NrDcScgFailCause_dl_synchReconfigFailure:         // 3
                index = NrdcRelMn_MnInit_synchReconfigFailureSCG;  // 14
                break;

            case NrDcScgFailCause_dl_scgReconfigFailure:      // 4
                index = NrdcRelMn_MnInit_scgReconfigFailure;  // 15
                break;

            case NrDcScgFailCause_dl_srb3IntegrityFailure:      // 5
                index = NrdcRelMn_MnInit_srb3IntegrityFailure;  // 17
                break;

            case NrDcScgFailCause_dl_scglbtFailure:  // 6
            case NrDcScgFailCause_dl_bhRLF:          // 9
                index = NrdcRelMn_MnInit_others;     // 19
                break;

            case NrDcScgFailCause_dl_beamFailureRecoveryFailure:      // 7
                index = NrdcRelMn_MnInit_beamFailureRecoveryFailure;  // 18
                break;

            case NrDcScgFailCause_dl_t312Expiry:      // 8
                index = NrdcRelMn_MnInit_t312Expiry;  // 16
                break;

            case NRDC_SCG_FAIL_CAUSE_TYPE_MAX:
                index = NrdcRelMn_MnInit_others;    // 19
                break;

            default:
                break;
        }

        if (index == STAT_NRDC_SN_REL_MN_END) return;

        /* STAT_NRDC_SN_REL_MN == 5570 */
        VCCB_MRDC_SN_REL_MN_STAT(index, ptCi, 0);
    }
    else  //    suspend and resume
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_StatNrdcScgFailure, failAction = %u\n", ptCi->nrdcScgFailureInfo.failAction);
    }

    return;
}

/*
 * @brief           Returns this cause is extended.
 *                  Extended means STAT_SA_CUCPCSL_PER_GNB_2, STAT_SA_CUCPCSL_PER_GNB_GLOBAL_ID_2,
 *                  STAT_SA_CUCPCSL_PER_GNB_HEXA_2, STAT_SA_CUCPCSL_PER_GNB_DU_ID_HEXA_2, STAT_SA_REDCAP_CUCPCSL_HEXA_2.
 *
 * @param[in/out]   cause
 * @return          TRUE / FALSE
 */
int16_t VLIB_IsExtendedCSL(uint16_t cause)
{
    if ((cause >= CauseXnapRadioNetworkLayerUnknownGuamiId))
    {
        return TRUE;
    }

    switch (cause)
    {
        case CauseCpInternalSaUeAssistanceInformation:
        case CauseCpInternalSaInvalidAMFName:
        case CauseE1apRadioNetworkLayerScgActivationDeactivationFailure:
        case CauseE1apRadioNetworkLayerScgDeactivationFailureDueToDataTransmission:
        case CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpMbsE1apId:
        case CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpMbsE1apId:
        case CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfMbsE1apId:
        case CauseE1apRadioNetworkLayerUnknownOrInconsistentMrbId:
        case CauseF1apRadioScgActivationDeactivationFailure:
        case CauseF1apRadioScgDeactivationFailureDueToDataTransmission:
        case CauseF1apRadioRequestedItemNotSupportedOnTime:
        case CauseF1apRadioUnknownOrAlreadyAllocatedGnbCuMbsF1apId:
        case CauseF1apRadioUnknownOrAlreadyAllocatedGnbDuMbsF1apId:
        case CauseF1apRadioUnknownOrInconsistentPairOfMbsF1apId:
        case CauseF1apRadioUnknownOrInconsistentMrbId:
        case CauseF1apRadioTatSdtExpiry:
        case CauseNgapRadioNetworkLayerInsufficientUeCapabilities:
        case CauseNgapRadioNetworkLayerRedcapUeNotSupported:
        case CauseNgapRadioNetworkLayerUnknownMBSSessionID:
        case CauseNgapRadioNetworkLayerIndicatedMBSSessionAreaInformationNotServedByTheGNB:
        case CauseNgapRadioNetworkLayerInconsistentSliceInfoForTheSession:
        case CauseNgapRadioNetworkLayerMisalignedAssociationForMulticastUnicast:
        case CauseNgapNasUeNotInPlmnServingArea:
        case CauseXnapRadioNetworkLayerValueOutOfAllowedRange:
        case CauseXnapRadioNetworkLayerScgActivationDeactivationFailure:
        case CauseXnapRadioNetworkLayerScgDeactivationFailureDueToDataTransmission:
            return TRUE;

        default:
            return FALSE;
    }
}

void FnVCCB_UpdateCellRrcConnectionCountWithRfsp(callInfo_type *ptCi, uint16_t newRfspVal)
{
    AUTO_TRACE_FUNC;

    uint16_t cellNum;
    uint8_t plmnIdx;
    uint16_t prevRfspVal;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        return;
    }

    if (ptCi->rrcConnStat.rrcConnectionCountFlag == FLAG_OFF)
    {
        return;
    }

    cellNum = ptCi->rrcConnStat.markedCellNumForRrcConnStat;
    plmnIdx = ptCi->rrcConnStat.markedPlmnIdxForRrcConnStat;
    prevRfspVal = ptCi->rrcConnStat.markedRfspForRrcConnStat;
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[cellNum]);

    if (IS_VALID_PLMNNUM(plmnIdx))
    {
        if (IS_VALID_RFSP_STAT_VAL(prevRfspVal) && IS_VALID_RFSP_STAT_VAL(newRfspVal))
        {
            // Delete Old
            if (pCell->cfg.assignedCellRrcConnectionCountWithRfsp[prevRfspVal][plmnIdx] > 0)
            {
                pCell->cfg.assignedCellRrcConnectionCountWithRfsp[prevRfspVal][plmnIdx]--;
                if (VCCB_FLAG_ON == DBG->flag.logRrcConnStat)
                {
                    VCCB_PRINT_CALL_COMMENT(ptCi,
                        "assignedCellRrcConnectionCountWithRfsp[%d][%d]--(CellNum=%d, Count=%d)\n", prevRfspVal, plmnIdx,
                        cellNum, pCell->cfg.assignedCellRrcConnectionCountWithRfsp[prevRfspVal][plmnIdx]);
                }
            }

            // Add New
            pCell->cfg.assignedCellRrcConnectionCountWithRfsp[newRfspVal][plmnIdx]++;
            if (VCCB_FLAG_ON == DBG->flag.logRrcConnStat)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "assignedCellRrcConnectionCountWithRfsp[%d][%d]++CellNum=%d, Count=%d)\n",
                    newRfspVal, plmnIdx, cellNum, pCell->cfg.assignedCellRrcConnectionCountWithRfsp[newRfspVal][plmnIdx]);
            }

            // Save New Value
            ptCi->rrcConnStat.markedRfspForRrcConnStat = newRfspVal;
        }
    }

    VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[cellNum]);

    return;
}

void FnVCCB_UpdateCellNonDssUeCountWithRfsp(callInfo_type *ptCi, uint16_t newRfspVal)
{
    AUTO_TRACE_FUNC;

    uint16_t cellNum;
    uint8_t plmnIdx;
    uint16_t prevRfspVal;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        return;
    }

    cellNum = ptCi->rrcConnStat.markedCellNumForNonDssUeStat;
    plmnIdx = ptCi->rrcConnStat.markedPlmnIdxForNonDssUeStat;
    prevRfspVal = ptCi->rrcConnStat.markedRfspForNonDssUeStat;

    if (MAX_CELL_NUM_VCCB <= cellNum)
    {
        // invalid cellNum indicate that UE support DSS
        return;
    }
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[cellNum]);

    if (IS_VALID_PLMNNUM(plmnIdx))
    {
        if (IS_VALID_RFSP_STAT_VAL(prevRfspVal) && IS_VALID_RFSP_STAT_VAL(newRfspVal))
        {
            // Delete Old
            if (pCell->cfg.assignedNonDssUeCountWithRfsp[prevRfspVal][plmnIdx] > 0)
            {
                pCell->cfg.assignedNonDssUeCountWithRfsp[prevRfspVal][plmnIdx]--;
                if (VCCB_FLAG_ON == DBG->flag.logRrcConnStat)
                {
                    VCCB_PRINT_CALL_COMMENT(ptCi,
                        "assignedNonDssUeCountWithRfsp[%d][%d]--, (CellNum=%d, Count=%d)\n", prevRfspVal, plmnIdx,
                        cellNum, pCell->cfg.assignedNonDssUeCountWithRfsp[prevRfspVal][plmnIdx]);
                }
            }

            // Add New
            pCell->cfg.assignedNonDssUeCountWithRfsp[newRfspVal][plmnIdx]++;
            if (VCCB_FLAG_ON == DBG->flag.logRrcConnStat)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "assignedNonDssUeCountWithRfsp[%d][%d]++, CellNum=%d, Count=%d)\n",
                    newRfspVal, plmnIdx, cellNum, pCell->cfg.assignedNonDssUeCountWithRfsp[newRfspVal][plmnIdx]);
            }

            // Save New Value
            ptCi->rrcConnStat.markedRfspForNonDssUeStat = newRfspVal;
        }
    }

    VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[cellNum]);

    return;
}

void FnVCCB_DiffRfspValAndUpdateRrcConStat(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint16_t newRfspVal = 0;

    // Get Current RFSP Val
    newRfspVal = FnVCCB_GetRfspValue(ptCi);

    // Compare old and new
    if (newRfspVal != ptCi->rrcConnStat.markedRfspForRrcConnStat &&
        FLAG_ON == ptCi->rrcConnStat.rrcConnectionCountFlag)
    {
        FnVCCB_UpdateCellRrcConnectionCountWithRfsp(ptCi, newRfspVal);
    }

    if (newRfspVal != ptCi->rrcConnStat.markedRfspForNonDssUeStat)
    {
        FnVCCB_UpdateCellNonDssUeCountWithRfsp(ptCi, newRfspVal);
    }
    return;
}

// FGR-CC5200:FR760 FR770
void FnVCCB_DiffRfspValAndUpdateNrdcConStat(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!IS_NRDC(ptCi))
    {
        return;
    }

    mrdcStatistic::NrdcSnConnInfoStats_s &nrdcConnInfoStats = ptCi->mrdcInfo.stat.nrdcSnConnInfo;
    if (nrdcConnInfoStats.connNoAvgUpdatedFlag)
    {
        uint16_t newRfspVal = FnVCCB_GetRfspValue(ptCi);
        if (nrdcConnInfoStats.markedRfspForConnNoAvg != newRfspVal)
        {
            FnVCCB_NrdcSnConnInfoStatsCmd(ptCi, ptCi->servCellNum, ConnInfoStatsCmd_Change);
        }
    }
}

void FnVCCB_UpdateConnStatsIfRfspChanged(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (E_CALLTYPE_NSA == ptCi->callType)
    {
        return;
    }

    if (!IS_NRDC_SN(ptCi))
    {
        FnVCCB_DiffRfspValAndUpdateRrcConStat(ptCi);
    }
    FnVCCB_DiffRfspValAndUpdateNrdcConStat(ptCi);
}

void FnVCCB_GetRfspStatValueFromYang(callInfo_type *ptCi, uint16_t &rRfsp)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];

    uint16_t rfspIdx = 0;
    uint16_t foundFlag = VCCB_FLAG_OFF;
    rRfsp = FnVCCB_GetRfspValue(ptCi);

    // ~25B : If Matched, then use RFSP Value.
    //      : If Not Matched, then NOT Collect.
    // 26A~ : If Matched, then use RFSP Value.
    //      : If Not Matched, then use 0.

    if (rRfsp != 0) // RFSP Present.
    {
        for (rfspIdx = 0; rfspIdx < MAX_RFSP_CONN_STAT_YANG; rfspIdx++)
        {
            if (pGnb->rfspBasedCounterList[rfspIdx].usage != EQUIP) continue;

            if (pGnb->rfspBasedCounterList[rfspIdx].rfspVal == rRfsp)
            {
                foundFlag = VCCB_FLAG_ON;
                break;
            }
        }

        // if Not Found, use it.
        if (foundFlag == VCCB_FLAG_OFF)
        {
            rRfsp = 0;
        }
    }
}

void FnVCCB_CollectRfspBasedSetupTime(callInfo_type *ptCi, int mFamily, int mType, float setupTime)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    uint16_t rfspVal = 0;
    FnVCCB_GetRfspStatValueFromYang(ptCi, rfspVal);

    uint32_t uePlmnKey = 0;
    VLIB_ConvertPlmnIdToPlmnValue(&ptCi->ueInfo.servedPlmn.s2, &uePlmnKey);
    
    MACRO_STAT_PMGAUGE(mFamily, mType, ptCi, setupTime, ptCi->gnbNum, pCell->cellIdentity, uePlmnKey, rfspVal);
}

void FnVCCB_CollectRfspBasedHoldingTime(callInfo_type *ptCi, int mFamily, int mType, float holdingTime)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint16_t rfspVal = 0;
    FnVCCB_GetRfspStatValueFromYang(ptCi, rfspVal);

    MACRO_STAT_PMSI(mFamily, mType, ptCi, holdingTime, rfspVal, 0, 0, 0);
}

void FnVCCB_UpdateGnbDuIdUsingCellId(
    callInfo_type *ptCi, unsigned long long *pPmIndex, uint16_t cellIdentity, uint16_t nonUeGnbNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pPmIndex);

#ifdef __NVGNB__
    *pPmIndex = MAX_GNB_DU_ID;  // In 23A, It's 0. Since 23B, It's MAX_GNB_DU_ID.
    (void)ptCi;
    (void)cellIdentity;
    (void)nonUeGnbNum;
#else
    uint16_t cellNum = MAX_CELL_NUM_VCCB;
    uint16_t gnbNum = MAX_GNB_PER_SYS;
    uint16_t endPointF1Index = MAX_GNB_DU_PER_GNB_CU_CP;
    VccbGnbInfo_type *ptGnbInfo = NULL;

    *pPmIndex = (MAX_GNB_DU_ID + 1);  // Set Invalid as default.

    if (ptCi != NULL)
    {
        gnbNum = ptCi->gnbNum;
    }
    else
    {
        gnbNum = nonUeGnbNum;
    }

    if (gnbNum < MAX_GNB_PER_SYS)
    {
        if (cellIdentity < MAX_CELL_IDENTITY)
        {
            ptGnbInfo = &GNBINFO[gnbNum];
            cellNum = ptGnbInfo->env.cellNum[cellIdentity];
            if (cellNum < MAX_CELL_NUM_VCCB)
            {
                endPointF1Index = CELLINFO[cellNum].endPointF1Index;
                if (endPointF1Index < MAX_GNB_DU_PER_GNB_CU_CP)
                {
                    *pPmIndex = ptGnbInfo->gnbDu[endPointF1Index].gnbDuId;
                }
            }
        }
    }

    // if DU ID is invalid, then use max value
    if (*pPmIndex > MAX_GNB_DU_ID)
    {
        *pPmIndex = MAX_GNB_DU_ID;
    }
#endif

    return;
}

void FnVCCB_EndcUlPathControl_CollectSpidPathChangeStats(callInfo_type *ptCi, int mType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(ptCi->ueInfo.rfsp.subscriberProfile, 0, MAX_SPID_VALUE); // 0 in case when SPID is not received from the MeNB 

    uint16_t SPID = 0;

    if (FnVCCB_setSpidCounterIndex(ptCi, SPID))
    {
        MACRO_STAT_PMCC(STAT_UL_PATH_SWITCH_SPID, mType, ptCi, SPID, 0, 0, 0, 0);
    }

    return;
}

void FnVCCB_EndcUlPathControl_CollectHighLatencyPathChangeStats(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    for (uint16_t erabIdx = 0; erabIdx < MAX_ERAB_PER_CALL; erabIdx++)
    {
        if (!IS_VALID_NODE(ERAB_NODE, ptCi, &(ptCi->erabInfo[erabIdx]))) continue;
        callERABInfo_type *const ptRi = &ptCi->erabInfo[erabIdx];

        if (ptRi->usage != CI_use) continue;
        if (ptRi->ulPdcpPathPrev == ptRi->ulPdcpPath) continue;
        if ((SPLIT_Bearer == ptRi->bearerType) && (NRRRC_UL_DataSplitThreshold_infinity != ptRi->prevDataSplitThreshold) &&
            (NRRRC_UL_DataSplitThreshold_infinity == ptRi->dataSplitThreshold))
        {
            if (UlPdcpPath_ScgShared == ptRi->ulPdcpPathPrev)
            {
                if (UlPdcpPath_ScgOnly == ptRi->ulPdcpPath)
                {
                    // Collect UlPathSwitch_LatencyHigh_ScgToScg
                    MACRO_STAT_PMCC(STAT_UL_PATH_SWITCH, UlPathSwitch_LatencyHigh_ScgToScg, ptCi, 0, 0, 0, 0, 0);
                    FnVCCB_EndcUlPathControl_CollectSpidPathChangeStats(ptCi, UlPathSwitch_LatencyHigh_ScgToScg);
                }
                else if (UlPdcpPath_McgOnly == ptRi->ulPdcpPath)
                {
                    // Collect UlPathSwitch_LatencyHigh_ScgToMcg
                    MACRO_STAT_PMCC(STAT_UL_PATH_SWITCH, UlPathSwitch_LatencyHigh_ScgToMcg, ptCi, 0, 0, 0, 0, 0);
                    FnVCCB_EndcUlPathControl_CollectSpidPathChangeStats(ptCi, UlPathSwitch_LatencyHigh_ScgToMcg);
                }
            }
            else if (UlPdcpPath_McgShared == ptRi->ulPdcpPathPrev)
            {
                if (UlPdcpPath_ScgOnly == ptRi->ulPdcpPath)
                {
                    // Collect UlPathSwitch_LatencyHigh_McgToScg
                    MACRO_STAT_PMCC(STAT_UL_PATH_SWITCH, UlPathSwitch_LatencyHigh_McgToScg, ptCi, 0, 0, 0, 0, 0);
                    FnVCCB_EndcUlPathControl_CollectSpidPathChangeStats(ptCi, UlPathSwitch_LatencyHigh_McgToScg);
                }
                else if (UlPdcpPath_McgOnly == ptRi->ulPdcpPath)
                {
                    // Collect UlPathSwitch_LatencyHigh_McgToMcg
                    MACRO_STAT_PMCC(STAT_UL_PATH_SWITCH, UlPathSwitch_LatencyHigh_McgToMcg, ptCi, 0, 0, 0, 0, 0);
                    FnVCCB_EndcUlPathControl_CollectSpidPathChangeStats(ptCi, UlPathSwitch_LatencyHigh_McgToMcg);
                }
            }
        }
    }

    return;
}

void FnVCCB_EndcUlPathControl_CollectPathChangeStats(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (FOO.VF_ULPathControlinENDC_PathSwitchCount != TRUE)
    {
        return;
    }

    // TODO: This condition is temporary code. It will be refactored later.
    switch (ptCi->stateCmd)
    {
        case E1UlPathSwitch_cmd:
        case MrUlPathSwitch_cmd:
            break;
        case ScgFailure_cmd:
        {
            if (VCCB_FLAG_ON == ptCi->scgSuspendStateForMeas)
            {
                break;
            }
            return;
        }
        default:
            return;
    }

    if (true == ptCi->changeTriggeredByE1PrivateMessage)
    {
        if (High_Latency == ptCi->HighLatencyIndication)
        {
             FnVCCB_EndcUlPathControl_CollectHighLatencyPathChangeStats(ptCi);
        }

        ptCi->changeTriggeredByE1PrivateMessage = false;
        return;
    }

    for (uint16_t erabIdx = 0; erabIdx < MAX_ERAB_PER_CALL; erabIdx++)
    {
        if (!IS_VALID_NODE(ERAB_NODE, ptCi, &(ptCi->erabInfo[erabIdx]))) continue;
        callERABInfo_type *const ptRi = &ptCi->erabInfo[erabIdx];

        if (ptRi->usage != CI_use) continue;
        if (ptRi->ulPdcpPathPrev == ptRi->ulPdcpPath) continue;

        if ((ptRi->ulPdcpPathPrev == UlPdcpPath_ScgShared) || (ptRi->ulPdcpPathPrev == UlPdcpPath_ScgOnly))
        {
            if ((ptRi->ulPdcpPath == UlPdcpPath_ScgShared) || (ptRi->ulPdcpPath == UlPdcpPath_ScgOnly))
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "Invalid ulPdcpPathPrev value (%d) ulPdcpPath value (%d) in %s!\n",
                    ptRi->ulPdcpPathPrev, ptRi->ulPdcpPath, __func__);
            }
            else
            {
                MACRO_STAT_PMCC(STAT_UL_PATH_SWITCH, UlPathSwitch_CovOut_ScgToMcg, ptCi, 0, 0, 0, 0, 0);

                FnVCCB_EndcUlPathControl_CollectSpidPathChangeStats(ptCi, UlPathSwitch_CovOut_ScgToMcg);
            }
        }
        else if (ptRi->ulPdcpPathPrev == UlPdcpPath_McgShared)
        {
            if (ptRi->ulPdcpPath == UlPdcpPath_McgOnly)
            {
                MACRO_STAT_PMCC(STAT_UL_PATH_SWITCH, UlPathSwitch_CovOut_McgToMcg, ptCi, 0, 0, 0, 0, 0);

                FnVCCB_EndcUlPathControl_CollectSpidPathChangeStats(ptCi, UlPathSwitch_CovOut_McgToMcg);
            }
        }
        else if (ptRi->ulPdcpPathPrev == UlPdcpPath_McgOnly)
        {
            if ((ptRi->ulPdcpPath == UlPdcpPath_ScgShared) || (ptRi->ulPdcpPath == UlPdcpPath_ScgOnly))
            {
                MACRO_STAT_PMCC(STAT_UL_PATH_SWITCH, UlPathSwitch_CovIn_McgToScg, ptCi, 0, 0, 0, 0, 0);

                FnVCCB_EndcUlPathControl_CollectSpidPathChangeStats(ptCi, UlPathSwitch_CovIn_McgToScg);
            }
            else if (ptRi->ulPdcpPath == UlPdcpPath_McgShared)
            {
                MACRO_STAT_PMCC(STAT_UL_PATH_SWITCH, UlPathSwitch_CovIn_McgToMcg, ptCi, 0, 0, 0, 0, 0);

                FnVCCB_EndcUlPathControl_CollectSpidPathChangeStats(ptCi, UlPathSwitch_CovIn_McgToMcg);
            }
        }
        else
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid ulPdcpPathPrev value (%d) in %s!\n", ptRi->ulPdcpPathPrev, __func__);
        }
    }

    return;
}

void FnVCCB_CollectPduQosFlowStat_ForRejectAll(callInfo_type *ptCi, msgUnpack_type *ptUnpack, enumActionOfPduSessionMsg_type doOption)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptUnpack);

    int16_t status = GOOD;

    switch (ptUnpack->msgId)
    {
        case NG_InitialContextSetupRequestAmfAll_id:
            status = FnVCCB_CollectPduQosFlow_ForInitialContextSetupRejectAll(ptCi, ptUnpack);
            VCCB_RETURN_ON_CALL_VOID(ptCi, status, "FnVCCB_CollectPduQosFlow_ForInitialContextSetupRejectAll ERROR !!\n");
            break;
        case NG_PDUSessionResourceSetupRequest_id:
            status = FnVCCB_CollectPduQosFlow_ForPduSessionSetupRejectAll(ptCi, ptUnpack, doOption);
            VCCB_RETURN_ON_CALL_VOID(ptCi, status, "FnVCCB_CollectPduQosFlow_ForPduSessionSetupRejectAll ERROR !!\n");
            break;
        case NG_PDUSessionResourceModifyRequest_id:
            status = FnVCCB_CollectPduQosFlow_ForPduSessionModifyRejectAll(ptCi, ptUnpack, doOption);
            VCCB_RETURN_ON_CALL_VOID(ptCi, status, "FnVCCB_CollectPduQosFlow_ForPduSessionModifyRejectAll ERROR !!\n");
            break;

        default:
            return;
    }
    return;
}

int16_t FnVCCB_CollectPduQosFlow_ForInitialContextSetupRejectAll (callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    int16_t status = GOOD;

    auto ptMsg = reinterpret_cast<NG_InitialContextSetupRequestAmfAll_type *>(ptUnpack->unpack);

    if (ptMsg->m.pDUSessionResourceSetupListCxtReqPresent)
    {
        status = FnVCCB_CollectPduQosFlowSetupFail_InPduSessionSetupList(ptCi, &ptMsg->pDUSessionResourceSetupListCxtReq, PDU_MSG_COLLECT_STAT);
    }

    return status;
}

int16_t FnVCCB_CollectPduQosFlow_ForPduSessionSetupRejectAll(
    callInfo_type *ptCi, msgUnpack_type *ptUnpack, enumActionOfPduSessionMsg_type doOption)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    int16_t status = GOOD;

    auto ptMsg = reinterpret_cast<NG_PDUSessionSetupRequest_type *>(ptUnpack->unpack);

    status = FnVCCB_CollectPduQosFlowSetupFail_InPduSessionSetupList(ptCi, &ptMsg->pDUSessionResSetupList, doOption);

    return status;
}

// for PduSessionSetupList common
int16_t FnVCCB_CollectPduQosFlowSetupFail_InPduSessionSetupList(
    callInfo_type *ptCi, NGAP_PDUSessionResourceSetupListCxtReq_type *ptList, enumActionOfPduSessionMsg_type doOption)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptList);

    uint8_t index;
    uint8_t listIdx = 0;
    int listNum = 0;
    int status = GOOD;

    callPDUSessInfo_type  tmpPDU;
    callPDUSessInfo_type *ptPi = &tmpPDU;
    qosFlowInfo_type     tmpQosFlow;
    qosFlowInfo_type     *ptQi = &tmpQosFlow;
    NGAP_PDUSessionResourceSetupItemCxtReq_type *ptPduSessionSetupItem = NULL;
    NGAP_QosFlowSetupRequestItem_type *ptQosFlowSetupItem = NULL;
    uint8_t saveCslOption = (doOption == PDU_MSG_COLLECT_STAT ? TRUE : FALSE);

    for (index = 0; index < MIN(ptList->n, MAX_PDU_SESS_PER_CALL); index++)
    {
        // PDU Session
        ptPduSessionSetupItem = &ptList->pDUSessionResourceSetupItemCtxReq[index];

        memset(ptPi, 0x00, sizeof(callPDUSessInfo_type));
        ptPi->pduSessId = (uint8_t)(ptPduSessionSetupItem->pDUSessionID);
        VNIL_StoreNGAP_SNSSAI(&ptPi->sNssai, &ptPduSessionSetupItem->s_NSSAI);

        // PDU Stat for Failure
        if(doOption == PDU_MSG_COLLECT_STAT)
        {
            MACRO_STAT_PMCC_PDU_SETUP_FAMILY_ALL(PduSetupAtt, ptCi, ptPi, 0, 0, 0, 0);
            MACRO_STAT_PMCC_PDU_SETUP_FAMILY_ALL(PduSetupFail_CpFail, ptCi, ptPi,  0, 0, 0, 0);
        }

        // QosFlow
        NGAP_PDUSessionResourceSetupRequestTransfer_type *ptSetupTransfer = &ptPduSessionSetupItem->pDUSessionResourceSetupRequestTransfer.decoded;
        NGAP_QosFlowSetupRequestList_type *ptQosFlowSetupList = &ptSetupTransfer->qosFlowSetupRequestList;

        listNum = MIN(ptQosFlowSetupList->n, NG_MaxnoofQosFlows);
        for (listIdx = 0; listIdx < listNum; listIdx++)
        {
            ptQosFlowSetupItem = &ptQosFlowSetupList->qosFlowSetupRequest[listIdx];

            memset(ptQi, 0x00, sizeof(qosFlowInfo_type));
            ptQi->flowId = (uint8_t)ptQosFlowSetupItem->qosFlowIdentifier;
            status = VNIL_StoreNGAP_QosFlowLevelQosParam(ptCi, &ptQi->qosParam, &ptQosFlowSetupItem->qosFlowLevelQosParameters, saveCslOption);
            if(status != GOOD)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,"FnVCCB_CollectPduQosFlowSetupFail_InPduSessionSetupList VNIL_StoreNGAP_QosFlowLevelQosParam ERROR!\n");
            }

            // QosFlow Stat for Failure
            if (doOption == PDU_MSG_COLLECT_STAT)
            {
                MACRO_STAT_PMCC_QOS_FLOW_SETUP_FAMILY_ALL(QosFlowSetupAtt, ptCi, ptPi, ptQi, 0, 0, 0);
                MACRO_STAT_PMCC_QOS_FLOW_SETUP_FAMILY_ALL(QosFlowSetupFail_CpFail, ptCi, ptPi, ptQi, 0, 0, 0);
            }
            else if (doOption == PDU_MSG_CHECK_VOICE)
            {
                uint8_t fiveQi = 0;
                VLIB_getFiveQi(ptQi, &fiveQi);
                if (fiveQi == 1)
                {
                    ptCi->bitFlag.hasVoiceInRequestMsg = VCCB_FLAG_ON;
                    return GOOD;
                }
            }
        }
    }

    return GOOD;
}

int16_t FnVCCB_CollectPduQosFlow_ForPduSessionModifyRejectAll(
    callInfo_type *ptCi, msgUnpack_type *ptUnpack, enumActionOfPduSessionMsg_type doOption)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    //uint8_t index;
    int16_t status = GOOD;

    callPDUSessInfo_type *ptPi = NULL;
    NGAP_PDUSessionResourceModifyItemModReq_type *ptModItem = NULL;
    NGAP_PDUSessionResourceModifyRequestTransfer_type *ptModTransfer = NULL;

    callPDUSessInfo_type tempPDU;
    callPDUSessInfo_type *ptTempPi = &tempPDU;

    auto ptMsg = reinterpret_cast<NG_PDUSessionModifyRequest_type *>(ptUnpack->unpack);

    PDUSessionResourceModifyListModReq_type *ptList = &ptMsg->pDUSessionResModifyList;

    int maxListIdx = MIN(ptList->n, MAX_PDU_SESS_PER_CALL);
    for (int listIdx = 0; listIdx < maxListIdx; listIdx++)
{
        ptModItem = &ptList->PDUSessionResourceModifyItemListModReq[listIdx];
        for (int pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
        {
            ptPi = &ptCi->pduSess[pduIdx];
            if (ptPi->usage != CI_use) continue;
            if (ptPi->pduSessId != ptModItem->pDUSessionID) continue;

            memcpy(ptTempPi, ptPi, sizeof(callPDUSessInfo_type));
            if (ptModItem->m.pDUSessionResourceModifyItemModReq_ExtIE)
            {
                ptPi->isSavedRequestedPduParam = VCCB_FLAG_OFF;
                VNIL_StoreNGAP_SNSSAI(&ptTempPi->sNssai, &ptModItem->pDUSessionResourceModifyItemModReq_ExtIE.s_NSSAI);
            }

            /* PDU Modify Stat for Failure */
            if (doOption == PDU_MSG_COLLECT_STAT)
            {
                MACRO_STAT_PMCC_PDU(STAT_PDU_SESSION_RESOURCE_MODIFY_PLMN_SNSSAI_RFSP, PduSetupAtt, ptCi, ptTempPi, 0, 0, 0, 0);
                MACRO_STAT_PMCC_PDU(STAT_PDU_SESSION_RESOURCE_MODIFY_PLMN_SNSSAI_RFSP, PduSetupFail_CpFail, ptCi, ptTempPi, 0, 0, 0, 0);
            }

            /* Found pDUSessionID */
            ptModTransfer = &ptModItem->pDUSessionResourceModifyRequestTransfer.decoded;
            if (ptModTransfer->m.qosFlowAddOrModifyRequestListPresent)
            {
                status = FnVCCB_CollectQosFlowSetupFail_inQosFlowAddOrModify(
                    ptCi, &ptModTransfer->qosFlowAddOrModifyRequestList, ptTempPi, doOption);
                if(status != GOOD)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi,"FnVCCB_CollectPduQosFlow_ForPduSessionModifyRejectAll FnVCCB_CollectQosFlowSetupFail_inQosFlowAddOrModify ERROR!\n");
                }
            }
            break;
        }
    }
    return GOOD;
}

int16_t FnVCCB_CollectQosFlowSetupFail_inQosFlowAddOrModify(callInfo_type *ptCi,
    NGAP_QosFlowAddOrModifyRequestList_type *ptQosFlowAddModList, callPDUSessInfo_type *ptPi,
    enumActionOfPduSessionMsg_type doOption)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptQosFlowAddModList);
    VALID_E_POINT_CHECK_ERROR(ptPi);

    uint8_t isModCase = FALSE;  // TRUE: Mod, FALSE: Add
    uint8_t listIdx = 0;
    int listNum = 0;
    uint8_t qosIdxInPdu, qosIdxInCall;

    qosFlowInfo_type *ptQi = NULL;
    qosFlowInfo_type     tmpQosFlow;
    NGAP_QosFlowAddOrModifyRequestItem_type *ptAddModItem = NULL;

    listNum = MIN(ptQosFlowAddModList->n, NG_MaxnoofQosFlows);
    for (listIdx = 0; listIdx < listNum; listIdx++)
    {
        ptAddModItem = &ptQosFlowAddModList->qosFlowAddOrModifyRequestItem[listIdx];
        isModCase = FALSE;

        for (qosIdxInPdu = 0; qosIdxInPdu < MAX_QOS_FLOW_PER_PDU_SESS; qosIdxInPdu++)
        {
            qosIdxInCall = (uint8_t)(ptPi->qosFlowIndex[qosIdxInPdu]);
            if (qosIdxInCall >= MAX_QOS_FLOW_PER_CALL)  // Not yet allocated
                continue;

            ptQi = &ptCi->qosFlow[qosIdxInCall];
            if (ptQi->usage != CI_use)  continue;

            if (ptQi->flowId == (uint8_t)ptAddModItem->qosFlowIdentifier)  // QoS Flow Modification Case
            {
                isModCase = TRUE;
                break;
            }
        }

        {
            int status = GOOD;
            ptQi = &tmpQosFlow;
            memset(ptQi, 0x00, sizeof(qosFlowInfo_type));

            ptQi->flowId = (uint8_t)ptAddModItem->qosFlowIdentifier;
            // QoS Flow Level QoS Parameter
            if (ptAddModItem->m.NGAPQosFlowLevelQosParameterspresent)
            {
                uint8_t saveCslOption = (doOption == PDU_MSG_COLLECT_STAT ? TRUE : FALSE);

                status = VNIL_StoreNGAP_QosFlowLevelQosParam(ptCi, &ptQi->qosParam, &ptAddModItem->qosFlowLevelQosParameters, saveCslOption);
                if(status != GOOD)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi,"FnVCCB_CollectQosFlowSetupFail_inQosFlowAddOrModify VNIL_StoreNGAP_QosFlowLevelQosParam ERROR!\n");
                }

                // Qos Flow Fail Stat
                if(doOption == PDU_MSG_COLLECT_STAT)
                {
                    if(isModCase == FALSE) // QoS Flow Addition Case
                    {
                        MACRO_STAT_PMCC_QOS_FLOW_SETUP_FAMILY_ALL(QosFlowSetupAtt, ptCi, ptPi, ptQi, 0, 0, 0);
                        MACRO_STAT_PMCC_QOS_FLOW_SETUP_FAMILY_ALL(QosFlowSetupFail_CpFail, ptCi, ptPi, ptQi, 0, 0, 0);
                    }
                }
                else if(doOption == PDU_MSG_CHECK_VOICE)
                {
                    uint8_t fiveQi = 0;
                    VLIB_getFiveQi(ptQi, &fiveQi);
                    if(fiveQi == VONR_5QI)
                    {
                        ptCi->bitFlag.hasVoiceInRequestMsg = VCCB_FLAG_ON;
                        return GOOD;
                    }
                }
            }
        }
    }
    return GOOD;
}

int16_t VLIB_LibStatPmCC_Retain_Validation(int mFamily, callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t *isCollectAbnormalItem)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if(MACRO_STAT_IS_NRRETAIN_DRBRELFAMILY(mFamily))
    {
        VALID_E_POINT_CHECK_ERROR(ptDi);
        VALID_E_POINT_CHECK_ERROR(isCollectAbnormalItem);

        if((mFamily == STAT_SETUP_DRB_RELEASE_DU_ID_PLMN_SNSSAI) ||
           (mFamily == STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID_PLMN_SNSSAI))
        {
            VCCB_CALL_CHECK_RANGE_AND_RETURN(ptCi, ptDi->pduIdxInCall, MAX_PDU_SESS_PER_CALL, "pduIdxInCall");
        }
        else if((mFamily == STAT_SETUP_DRB_RELEASE_PLMN_SNSSAI_5QI) ||
                (mFamily == STAT_SETUP_ACTIVE_DRB_RELEASE_PLMN_SNSSAI_5QI))
        {
            VCCB_CALL_CHECK_RANGE_AND_RETURN(ptCi, ptDi->pduIdxInCall, MAX_PDU_SESS_PER_CALL, "pduIdxInCall");
            VCCB_CALL_CHECK_RANGE_AND_RETURN(ptCi, ptDi->drbQosIdxInCall, MAX_QOS_FLOW_PER_CALL, "drbQosIdxInCall");
        }        
        else
        {
            VCCB_CALL_CHECK_RANGE_AND_RETURN(ptCi, ptDi->drbQosIdxInCall, MAX_QOS_FLOW_PER_CALL, "drbQosIdxInCall");
        }

        // No event for retain, then return,
        if (ptDi->retainStat.savedEventCategory == No_CallDrb_RetainCategory) return BREAK;

        // MR-DC SN Term is not included.
        if (VCCB_IS_SN_TERM_DRB_WITH_ONLY_CHECK_BEARER_TYPE(ptDi))
        {
            CLEAR_DRB_RETAIN_STAT_EVENT(ptDi);
            return BREAK;
        }

        // Check Active and Abnormal Item.
        if(MACRO_STAT_IS_NRRETAIN_ACTIVEFAMILY(mFamily))
        {
            if (ptDi->retainStat.inSessionFlagByE1 != VCCB_FLAG_ON) return BREAK;
            *isCollectAbnormalItem = VCCB_FLAG_ON;
        }
    }
    return GOOD;
}

#define SET_CSL_RETAIN_COLLECT(_pRetainExtraInfo, _srcType, _isAbnormal)\
        if(flag_CollectRetainCsl)\
        {\
            pRetainExtraInfo->cslInfo.gnbAmfInitType = _srcType;\
            pRetainExtraInfo->cslInfo.cslAbnormal    = _isAbnormal;\
        }\

typedef enum
{
    e_csl_normal = VCCB_FLAG_OFF,
    e_csl_abnormal = VCCB_FLAG_ON
} enumDrbRetainCollectAbnormal_type;

bool FnVCCB_IsCollectRetainCsl(callInfo_type &rCall, uint16_t retainCategory, uint16_t retainItem, uint8_t includingRelTotal)
{
    // 1. Check FOO
    if(!(FOO.VF_CallSummaryLogs_KPI))
    {
        if(DBG->flag.logRetainCsl)
        {
            VCCB_PRINT_CALL_INFORMATIVE(&rCall, "[CSL][Ue/DrbRetain] F_CallSummaryLogs_KPI is OFF. => No Collect\n");
        }
        return false;
    }

    // 2. Check Not Include Total
    //  - RetainCategory_InterGnbXnHandover
    //  - RetainCategory_IntraGnbHandover
    //  - RetainCategory_InterGnbRRE
    //  - RetainCategory_InterGnbRRE
    if(includingRelTotal == VCCB_FLAG_OFF)
    {
        if(DBG->flag.logRetainCsl)
        {
            VCCB_PRINT_CALL_INFORMATIVE(&rCall, "[CSL][Ue/DrbRetain] Not Include RelTal. Category(%u) => No Collect \n", retainCategory);
        }
        return false;
    }

    // 3. Check UeCtxtRelCommandByAMF_NgIntraNRHo
    if((retainCategory == RetainCategory_UeCtxtRelCommandByAMF) &&
       (retainItem & RetainItem_UeCtxtRelCommandByAMF_NgIntraNRHo_All))
    {
        if(DBG->flag.logRetainCsl)
        {
            VCCB_PRINT_CALL_INFORMATIVE(&rCall, "[CSL][Ue/DrbRetain] UeCtxtRelCommandByAMF_NgIntraNRHo => No Collect \n");
        }
        return false;
    }

    // 4. Check CNF Returning Call.
    if(RscCall::isReturningCall(rCall.callId) == TRUE)
    {
        if(DBG->flag.logRetainCsl)
        {
            VCCB_PRINT_CALL_INFORMATIVE( &rCall, "[CSL][Ue/DrbRetain] Returning Call => No Collect\n");
        }
        return false;
    }
    return true;
}


int16_t VLIB_LibStatPmCC_Retain_Collect_PmLib(callInfo_type *ptCi, VccbPmMultiCollect_type *pmMultiCollect, int mFamily, int mActualFamily,
    uint16_t retainCategory, uint16_t retainItem, uint8_t isCollectAbnormalItem, const uint8_t drbStatTypeOffset, retainExtraInfo_type *pRetainExtraInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR_PARAM3(ptCi, pmMultiCollect, pRetainExtraInfo);

    uint8_t isDrbAbnormal_ForActive = VCCB_FLAG_OFF;
    uint8_t isCnDetectedMobility = VCCB_FLAG_OFF;
    uint8_t isPduSessionNotify = VCCB_FLAG_OFF;

    uint8_t  isAmfRequested_BySpecialSave     = VCCB_FLAG_OFF;
    uint8_t  isAmfRequested_ByOriginal       = VCCB_FLAG_OFF;
    uint8_t  isAmfRequested_Normal          = VCCB_FLAG_OFF;
    uint8_t  flag_CollectRetainCsl = false;

    // 25A: Currently DRB Retain is supported for Csl(STAT_SETUP_DRB_RELEASE)
    // 25B: Currently UE Retain is supported for Csl(STAT_SETUP_UECONTEXT_RELEASE)
    // Use saved category to determine to collect csl
    if(mFamily == STAT_SETUP_DRB_RELEASE || mFamily == STAT_SETUP_UECONTEXT_RELEASE)
    {
        flag_CollectRetainCsl = FnVCCB_IsCollectRetainCsl(*ptCi, retainCategory, retainItem, pRetainExtraInfo->cslInfo.includingRelTotal);
    }

    // Check AMF Request(DRB Only). It has a high priority more than OrginalRetain Value.
    // When DRB Stat, pRetainExtraInfo->retainStatForAmfReq.savedEventCategory is Valid
    if((pRetainExtraInfo->retainStatForAmfReq.savedEventCategory == RetainCategory_PduSessonModifyByAMF) ||
       (pRetainExtraInfo->retainStatForAmfReq.savedEventCategory == RetainCategory_PduSessonReleaseByAMF))
    {
        isAmfRequested_BySpecialSave  = VCCB_FLAG_ON;
        // if( (pRetainExtraInfo->retainStatForAmfReq.savedEventItem & RetainItem_PduSessonModifyByAMF_Normal) ||
        //     (pRetainExtraInfo->retainStatForAmfReq.savedEventItem & RetainItem_PduSessonReleaseByAMF_Normal))
        if ((pRetainExtraInfo->retainStatForAmfReq.savedEventItem & (RetainItem_PduSessonModifyByAMF_Normal | RetainItem_PduSessonReleaseByAMF_Normal)) != 0)
        {
            isAmfRequested_Normal = VCCB_FLAG_ON;
        }
    }

    auto handlePduSessionModifyByAmf = [&]() {
        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem, mActualFamily,
            DrbRelbyAmf_PduSessionModifyReq, PME_LIB_CC, 1);

        SET_AMF_REQUEST_ORIGINAL_FLAG(isAmfRequested_BySpecialSave , isAmfRequested_ByOriginal);

        if (retainItem & RetainItem_PduSessonModifyByAMF_Normal)
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                mActualFamily, DrbRelbyAmf_PduSessionModifyReq_WithNormalCause, PME_LIB_CC, 1);
            SET_AMF_REQUEST_NORMAL_WITH_ORGINAL_RETAIN(isAmfRequested_ByOriginal, isAmfRequested_Normal);
        }
        else
        {
            // DRB Abnormal:
            // (DrbRelbyAmf_PduSessionModifyReq) && (Not DrbRelbyAmf_PduSessionModifyReq_WithNormalCause )
            if (isCollectAbnormalItem)
            {
                isDrbAbnormal_ForActive = VCCB_FLAG_ON;
            }

            SET_CSL_RETAIN_COLLECT(pRetainExtraInfo, AMF_INIT_RETAIN, e_csl_abnormal);
        }

        if (retainItem & RetainItem_PduSessonModifyByAMF_CnDetectedMobility)
        {
            isCnDetectedMobility = VCCB_FLAG_ON;
        }
    };

    auto handlePduSessionReleaseByAmf = [&]() {
        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem, mActualFamily,
            DrbRelbyAmf_PduSessionRelCmd, PME_LIB_CC, 1);

        SET_AMF_REQUEST_ORIGINAL_FLAG(isAmfRequested_BySpecialSave , isAmfRequested_ByOriginal)
        if (retainItem & RetainItem_PduSessonReleaseByAMF_Normal)
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                mActualFamily, DrbRelbyAmf_PduSessionRelCmd_WithNormalCause, PME_LIB_CC, 1);
            SET_AMF_REQUEST_NORMAL_WITH_ORGINAL_RETAIN(isAmfRequested_ByOriginal, isAmfRequested_Normal);
        }
        else
        {
            // DRB Abnormal: (DrbRelbyAmf_PduSessionRelCmd) and (Not DrbRelbyAmf_PduSessionRelCmd_WithNormalCause )
            if (isCollectAbnormalItem)
            {
                isDrbAbnormal_ForActive = VCCB_FLAG_ON;
            }
            SET_CSL_RETAIN_COLLECT(pRetainExtraInfo, AMF_INIT_RETAIN, e_csl_abnormal);
        }

        if (retainItem & RetainItem_PduSessonReleaseByAMF_CnDetectedMobility)
        {
            isCnDetectedMobility = VCCB_FLAG_ON;
        }
    };

    auto handleUeCtxtRelCommandByAmf = [&]() {
        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem, mActualFamily,
            (UeRelbyAmf_UeContextRelCmd + drbStatTypeOffset), PME_LIB_CC, 1);

        SET_AMF_REQUEST_ORIGINAL_FLAG(isAmfRequested_BySpecialSave , isAmfRequested_ByOriginal);
        if (retainItem & RetainItem_UeCtxtRelCommandByAMF_Normal)
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                mActualFamily, (UeRelbyAmf_UeContextRelCmd_WithNormalCause + drbStatTypeOffset), PME_LIB_CC, 1);
            SET_AMF_REQUEST_NORMAL_WITH_ORGINAL_RETAIN(isAmfRequested_ByOriginal, isAmfRequested_Normal)
        }
        else
        {
            // DRB Abnormal: (DrbRelbyAmf_UeContextRelCmd) and (Not DrbRelbyAmf_UeContextRelCmd_WithNormalCause )
            if (isCollectAbnormalItem)
            {
                isDrbAbnormal_ForActive = VCCB_FLAG_ON;
            }
            SET_CSL_RETAIN_COLLECT(pRetainExtraInfo, AMF_INIT_RETAIN, e_csl_abnormal);
        }

        if (retainItem & RetainItem_UeCtxtRelCommandByAMF_CnDetectedMobility)
        {
            isCnDetectedMobility = VCCB_FLAG_ON;
        }

        if (retainItem & RetainItem_UeCtxtRelCommandByAMF_NgIntraNRHo_All)
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                mActualFamily, (UeRelbyAmf_UeContextRelCmd_IntraNrHo + drbStatTypeOffset), PME_LIB_CC, 1);
            if (retainItem & RetainItem_UeCtxtRelCommandByAMF_NgIntraNrHo_Normal)
            {
                MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                    mActualFamily, (UeRelbyAmf_UeContextRelCmd_IntraNrHo_WithNormalCause + drbStatTypeOffset),
                    PME_LIB_CC, 1);
            }

            if (IS_ONDEMAND_HO())  // RETAIN_STAT_HO_21C
            {
                /* Ondemand event and intra system inter gnb NG handover serving */
                MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                    mActualFamily, (UeRelbyOnDemandForcedMobility_InterGnbNgHandover + drbStatTypeOffset),
                    PME_LIB_CC, 1);
            }
        }
        else if (retainItem & RetainItem_UeCtxtRelCommandByAMF_NgInterRatHo_All)
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                mActualFamily, (UeRelbyAmf_UeContextRelCmd_InterRatHo + drbStatTypeOffset), PME_LIB_CC, 1);
            if (retainItem & RetainItem_UeCtxtRelCommandByAMF_NgInterRatHo_Normal)
            {
                MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                    mActualFamily, (UeRelbyAmf_UeContextRelCmd_InterRatHo_WithNormalCause + drbStatTypeOffset),
                    PME_LIB_CC, 1);
            }

            if (IS_ONDEMAND_HO())  // RETAIN_STAT_HO_21C
            {
                /* Ondemand event and inter system inter gnb NG handover serving */
                MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                    mActualFamily, (UeRelbyOnDemandForcedMobility_InterRatHandoverToEutran + drbStatTypeOffset),
                    PME_LIB_CC, 1);
            }
        }
    };

    auto handleUeCtxtRelRequestByGNB = [&]() {
        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem, mActualFamily,
            (UeRelbyGnb_UeContextRelReq + drbStatTypeOffset), PME_LIB_CC, 1);
        if (retainItem & RetainItem_UeCtxtRelRequestByGNB_Normal)
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                mActualFamily, (UeRelbyGnb_UeContextRelReq_WithNormalCause + drbStatTypeOffset), PME_LIB_CC, 1);

            // numOfItem = 2
            // updateItemArray[0].typeID = UeRelbyGnb_UeContextRelReq_WithNormalCause + drbStatTypeOffset
            // updateItemArray[0].updateMethod = PME_LIB_CC
            // updateItemArray[0].updateVal = 1
        }
        else
        {
            // DRB Abnormal: (DrbRelbyGnb_UeContextRelReq) and (Not DrbRelbyGnb_UeContextRelReq_WithNormalCause )
            if (isCollectAbnormalItem)
            {
                isDrbAbnormal_ForActive = VCCB_FLAG_ON;
            }

            SET_CSL_RETAIN_COLLECT(pRetainExtraInfo, GNB_INIT_RETAIN, e_csl_abnormal);
        }

        // Check CSL : Normal Case (UeContextReleaseRequestByGNB)
        if(flag_CollectRetainCsl)
        {
            if((retainItem & RetainItem_UeCtxtRelRequestByGNB_Preemption) ||
               (retainItem & RetainItem_UeCtxtRelRequestByGNB_IntraRatRd) ||
               (retainItem & RetainItem_UeCtxtRelRequestByGNB_InterRatRd))
            {
                // handle it as normal in CSL.
                pRetainExtraInfo->cslInfo.cslAbnormal = VCCB_FLAG_OFF;
            }
        }

        // RETAIN_STAT_BASIC_21C
        if (retainItem & RetainItem_UeCtxtRelRequestByGNB_Preemption)
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                mActualFamily, (UeRelbyPreemption + drbStatTypeOffset), PME_LIB_CC, 1);

            // for only DRB Release
            if(MACRO_STAT_IS_COLLECT_UECTXTREQUEST_BYPREEMPTION(mFamily)) // 24B
            {
                /* Offset is different. (ActiveFamily: 32, Others: 31) */
                if(MACRO_STAT_IS_NRRETAIN_ACTIVEFAMILY(mFamily)) // Offset: 32
                {
                    MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                        mActualFamily, (Active_DrbRelbyGnb_UeContextRelReq_withDrbRelbyPreemption_DUID), PME_LIB_CC, 1);
                }
                else // Offset: 31
                {
                    MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                        mActualFamily, (DrbRelbyGnb_UeContextRelReq_withDrbRelbyPreemption), PME_LIB_CC, 1);
                }
            }
        }

        // RETAIN_STAT_HO_21C
        if (retainItem & RetainItem_UeCtxtRelRequestByGNB_IntraRatRd)
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                mActualFamily, (UeRelbyIntraRatRedirection + drbStatTypeOffset), PME_LIB_CC, 1);

            // VCCB_PRINT_CALL_INFORMATIVE(ptCi,
            //         "[RETAIN_STAT] %s RetainItem_UeCtxtRelRequestByGNB_IntraRatRd ondemandRd(%d) \n",
            //         __func__, IS_ONDEMAND_REDIRECT());

            if (IS_ONDEMAND_REDIRECT())
            {
                MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                    mActualFamily, (UeRelbyOnDemandForcedMobility_IntraRatRedirection + drbStatTypeOffset),
                    PME_LIB_CC, 1);
            }
        }
        else if (retainItem & RetainItem_UeCtxtRelRequestByGNB_InterRatRd)
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                mActualFamily, (UeRelbyInterRatRedirection + drbStatTypeOffset), PME_LIB_CC, 1);

            // VCCB_PRINT_CALL_INFORMATIVE(ptCi,
            //         "[RETAIN_STAT] %s RetainItem_UeCtxtRelRequestByGNB_InterRatRd ondemandRd(%d) \n",
            //         __func__, IS_ONDEMAND_REDIRECT());

            if (IS_ONDEMAND_REDIRECT())
            {
                MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                    mActualFamily, (UeRelbyOnDemandForcedMobility_InterRatRedirection + drbStatTypeOffset),
                    PME_LIB_CC, 1);
            }
        }
        else if (IS_ONDEMAND_RELEASE())  // Ondemand Release
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                mActualFamily, (UeRelbyOnDemandForcedMobility_CallRelease + drbStatTypeOffset), PME_LIB_CC, 1);
        }
    };

    switch (retainCategory)
    {
        /* PduSessonModifyByAMF */
        case RetainCategory_PduSessonModifyByAMF:
            handlePduSessionModifyByAmf();
            break;

        /* PduSessonReleaseByAMF */
        case RetainCategory_PduSessonReleaseByAMF:
            handlePduSessionReleaseByAmf();
            break;

        /* UeCtxtRelCommandByAMF */
        case RetainCategory_UeCtxtRelCommandByAMF:
            handleUeCtxtRelCommandByAmf();
            break;

        /* UeContextReleaseRequestByGNB */
        case RetainCategory_UeCtxtRelRequestByGNB:
            handleUeCtxtRelRequestByGNB();
            break;

        /* PathSwitch */
        case RetainCategory_PathSwitchFailure: /* H/O, RRE */
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem, mActualFamily,
                (UeRelbyAmf_PathSwitch + drbStatTypeOffset), PME_LIB_CC, 1);

            if (isCollectAbnormalItem)
            {
                isDrbAbnormal_ForActive = VCCB_FLAG_ON;
            }

            SET_CSL_RETAIN_COLLECT(pRetainExtraInfo, AMF_INIT_RETAIN, e_csl_abnormal);
            break;

        /* NG-Reset */
        case RetainCategory_NgResetByAMF:
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem, mActualFamily,
                (UeRelbyAmf_NgReset + drbStatTypeOffset), PME_LIB_CC, 1);
            SET_AMF_REQUEST_ORIGINAL_FLAG(isAmfRequested_BySpecialSave , isAmfRequested_ByOriginal);

            SET_CSL_RETAIN_COLLECT(pRetainExtraInfo, AMF_INIT_RETAIN, e_csl_abnormal);
            if(flag_CollectRetainCsl)
            {
                pRetainExtraInfo->cslInfo.abnRelCause5qi = Retain_AbnRel_CslNgReset;
            }
            break;

        case RetainCategory_NgResetByGNB:
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem, mActualFamily,
                (UeRelbyGnb_NgReset + drbStatTypeOffset), PME_LIB_CC, 1);

            SET_CSL_RETAIN_COLLECT(pRetainExtraInfo, GNB_INIT_RETAIN, e_csl_abnormal);
            if(flag_CollectRetainCsl)
            {
                pRetainExtraInfo->cslInfo.abnRelCause5qi = Retain_AbnRel_CslNgReset;
            }
            break;

        case RetainCategory_NgcLinkFailure:
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem, mActualFamily,
                (UeRelbyGnb_NgcLinkFail + drbStatTypeOffset), PME_LIB_CC, 1);

            SET_CSL_RETAIN_COLLECT(pRetainExtraInfo, GNB_INIT_RETAIN, e_csl_abnormal);
            if(flag_CollectRetainCsl)
            {
                pRetainExtraInfo->cslInfo.abnRelCause5qi = Retain_AbnRel_CslNgcLinkFail;
            }
            break;

        case RetainCategory_IntraGnbRRE: /* PCell change by Intra gNB RRE */
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem, mActualFamily,
                (UeRelbyIntraGnbRRE + drbStatTypeOffset), PME_LIB_CC, 1);
            break;

        case RetainCategory_InterGnbRRE: /* PCell change by Inter gNB RRE */
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem, mActualFamily,
                (UeRelbyInterGnbRRE + drbStatTypeOffset), PME_LIB_CC, 1);
            break;

        // RETAIN_STAT_HO_21C
        case RetainCategory_IntraGnbHandover:  // the number of PCell change due to intra-gNB handover.
            // VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[RETAIN_STAT] IntraGnbHandover family(%d) type(%d) \n",
            //        mActualFamily, (UeRelbyIntraGnbHandover + drbStatTypeOffset));
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem, mActualFamily,
                (UeRelbyIntraGnbHandover + drbStatTypeOffset), PME_LIB_CC, 1);

            if (IS_ONDEMAND_HO())
            {
                MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                    mActualFamily, (UeRelbyOnDemandForcedMobility_IntraGnbHandover + drbStatTypeOffset), PME_LIB_CC, 1);
            }
            break;

        // RETAIN_STAT_HO_21C
        case RetainCategory_InterGnbXnHandover:  // the number of UE contexts released due to inter-gNB XN handover.
            // VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[RETAIN_STAT] InterGnbXnHandover family(%d) type(%d) \n",
            //        mActualFamily, (UeRelbyInterGnbXnHandover + drbStatTypeOffset));
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem, mActualFamily,
                (UeRelbyInterGnbXnHandover + drbStatTypeOffset), PME_LIB_CC, 1);

            if (IS_ONDEMAND_HO())
            {
                MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                    mActualFamily, (UeRelbyOnDemandForcedMobility_InterGnbXnHandover + drbStatTypeOffset), PME_LIB_CC,
                    1);
            }
            break;

        // RETAIN_STAT_21D_PREEMPTION
        case RetainCategory_RelOnlyDrbByPreemptionByGNB:
            if (retainItem & RetainItem_RelOnlyDrbByPreemptionByGNB)
            {
                MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                    mActualFamily, (UeRelbyPreemption + drbStatTypeOffset), PME_LIB_CC, 1);
            }

            if (retainItem & RetainItem_RelOnlyDrbByPreemptionByGNB_PduNotify)
            {
                isPduSessionNotify = VCCB_FLAG_ON;
                SET_CSL_RETAIN_COLLECT(pRetainExtraInfo, GNB_INIT_RETAIN, e_csl_abnormal);
            }
            break;

        case RetainCategory_PduSessionNotifyByGNB:
            isPduSessionNotify = VCCB_FLAG_ON;
            SET_CSL_RETAIN_COLLECT(pRetainExtraInfo, GNB_INIT_RETAIN, e_csl_abnormal);
            break;

        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_LibStatPmCC_Retain invalid retainCategory (E - %d)\n", retainCategory);
            return ERROR;
    }

    //  1. DRB Active Abnormal. It's for Only DRB Active. (Exclude UE, VoNR_Emer, general DRB)
    if (isDrbAbnormal_ForActive)
    {
        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem, mActualFamily,
            (DrbAbnormalRelPlmn), PME_LIB_CC, 1);
    }

    // 2. CN Detected Mobility. It's for ALL(UE/DRB/VoNR_Emer)
    if (isCnDetectedMobility)
    {
        /* Offset is different. (UE: 27, DRB(VoNR_Emer): 32, Active DRB:33) */
        if (MACRO_STAT_IS_NRRETAIN_UE_FAMILY(mFamily))  // item: 27
        {
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem, mActualFamily,
                (UeRelbyAmf_CnDetected), PME_LIB_CC, 1);  // 27
        }
        else  // DRB.
        {
            // DRB/VoNR_Emer item: 32, Active DRB item: 33
            int activeDrbOffset = 0;
            if (MACRO_STAT_IS_NRRETAIN_ACTIVEFAMILY(mFamily))  // Active DRB item: 33
            {
                activeDrbOffset = ACTIVE_DRB_RETAIN_OFFSET;  // (1)
            }
            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem, mActualFamily,
                (DrbRelbyAmf_CnDetected + activeDrbOffset), PME_LIB_CC, 1);
        }
    }

    // 3. AMF Request. It's for Only ALL DRB stats(Include general DRB, DRB Active)(Exclude UE, VoNR_Emer)
    // - Include DrbRelbyAmf_PduSessionModifyReq
    // - Include DrbRelbyAmf_PduSessionRelCmd
    // - Include DrbRelbyAmf_UeContextRelCmd
    // - Include DrbRelbyAmf_NgReset   (Exclude DrbRelbyAmf_PathSwitch)
    if((isAmfRequested_BySpecialSave ) ||  (isAmfRequested_ByOriginal))
    {
        if((!MACRO_STAT_IS_NRRETAIN_UE_FAMILY(mFamily)) &&
           (mFamily != STAT_VONR_EMERGENCY_RELEASE))
        {
            /* Offset is different. (DRB: 33, Active DRB:34) */
            int activeDrbOffset = 0;
            if(MACRO_STAT_IS_NRRETAIN_ACTIVEFAMILY(mFamily)) // Active DRB item: 33
            {
                activeDrbOffset = ACTIVE_DRB_RETAIN_OFFSET; // (1)
            }

            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                mActualFamily, (DrbRelbyAmf_RequestCount + activeDrbOffset), PME_LIB_CC, 1);

            if(isAmfRequested_Normal)
            {
                MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                    mActualFamily, (DrbRelbyAmf_RequestCount_WithNormalCause + activeDrbOffset), PME_LIB_CC, 1);
            }
        }
    } // AMF Request

    // 4. PDU Session Nofity. It's for DRB Only
    if (isPduSessionNotify && (!(MACRO_STAT_IS_NRRETAIN_UE_FAMILY(mFamily))))
    {
        int notifyOffset = 0;

        if(MACRO_STAT_IS_NRRETAIN_DRBRELFAMILY(mFamily))
        {
            if(MACRO_STAT_IS_NRRETAIN_ACTIVEFAMILY(mFamily))
            {
                notifyOffset = 3;
            }
            else // DRB
            {
                notifyOffset = 2;
            }
        }

        // VoNREmer   : 33
        // DRB        : 35
        // Active DRB : 36
        MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem, mActualFamily,
            (VoNREmergencyRelbyGnb_PduSessionNotify + notifyOffset), PME_LIB_CC, 1);
    }

    // Check Abnormal Release 5QI // for Only Stat
    if(pRetainExtraInfo->cslInfo.abnRelCause5qi < Retain_AbnRel_CauseStatMAX)   // check Stat Range
    {
        // Only (DRB and VonrEmer),  NOT UE Release.
        if (!MACRO_STAT_IS_NRRETAIN_UE_FAMILY(mFamily))
        {
            /* Offset is different. (VonrEmer: 34, DRB: 36, Active DRB:37) */
            int abnRelCause5qiDrbOffset = 0;
            int abnRelCause5qiCause = pRetainExtraInfo->cslInfo.abnRelCause5qi + VoNREmergencyRelbyCauseInternalTmOutRrcConnectionReconfig; // VonrEmer Base.

            if(mFamily == STAT_VONR_EMERGENCY_RELEASE)
            {
                // No Change // It's based.
            }
            else if(MACRO_STAT_IS_NRRETAIN_ACTIVEFAMILY(mFamily)) // Active DRB item: 37
            {
                abnRelCause5qiDrbOffset = 3;
            }
            else // DRB : 36
            {
                abnRelCause5qiDrbOffset = 2;
            }

            MACRO_STAT_PMCC_ADD_ITEM(pmMultiCollect->updateItemUintArr, pmMultiCollect->numOfItem,
                    mActualFamily, (abnRelCause5qiCause+abnRelCause5qiDrbOffset), PME_LIB_CC, 1);
        }
    }

    // 5. Collect CSL
    if(flag_CollectRetainCsl)
    {
        if(mFamily == STAT_SETUP_DRB_RELEASE)
        {
            FnVCCB_CollectStatCSL_DrbRetain(ptCi, mFamily, pRetainExtraInfo);
        }
        else if(mFamily == STAT_SETUP_UECONTEXT_RELEASE)
        {
            FnVCCB_CollectStatCSL_UeRetain(ptCi, mFamily, pRetainExtraInfo);
        }
    }

    return GOOD;
}

int16_t VLIB_LibStatPmCC_Retain_SetPmkey(callInfo_type *ptCi, callDRBInfo_type *ptDi, VccbPmKey_type *pPmKey, VccbPmMultiCollect_type* pmMultiCollect, int mFamily, int mActualFamily, uint16_t retainCategory, uint32_t isOldCell, uint32_t isMobility, uint8_t* drbStatTypeOffset, retainExtraInfo_type* pRetainExtraInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pPmKey);
    VALID_E_POINT_CHECK_ERROR(pmMultiCollect);

    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);

    uint16_t gnbNum = ptCi->gnbNum;
    VccbGnbInfo_type *pGnb = &GNBINFO[gnbNum];
    const VccbCellInfo_type *pServedCell = &CELLINFO[ptCi->servCellNum];
    VccbCellInfo_type *pOldCell = NULL;

    uint8_t fiveQi = 0;
    uint32_t uePlmnKey;  // PLMN_UE
    uint32_t cellPlmnKey = 0;

    int skipTotalType = FALSE;

    if ((RetainCategory_InterGnbXnHandover == retainCategory) ||
        (RetainCategory_IntraGnbRRE == retainCategory) ||
        (RetainCategory_InterGnbRRE == retainCategory) || (isMobility == TRUE))
    {
        skipTotalType = TRUE;
    }

    switch (mFamily)
    {
        case STAT_SETUP_UECONTEXT_RELEASE:
            SET_PMKEY_FOR_STAT_SETUP_UECONTEXT_RELEASE(ptCi, pPmKey);
            // CSL INFO
            pRetainExtraInfo->cslInfo.includingRelTotal = (skipTotalType == TRUE) ? VCCB_FLAG_OFF : VCCB_FLAG_ON;
            pRetainExtraInfo->cslInfo.inSessionFlagByE1 = ptCi->bitFlag.activeUeContextRelease;
            break;

        case STAT_VONR_EMERGENCY_RELEASE:
            SET_PMKEY_FOR_STAT_VONR_EMERGENCY_RELEASE(ptCi, pPmkey);
            UPDATE_DRB_ABNORMAL_REL_STAT_CAUSE_5QI(pRetainExtraInfo->cslInfo.abnRelCause5qi, ptCi->retainStatOfVonrEmer.abnRelCause5qi);
            break;

        case STAT_SETUP_DRB_RELEASE:
            VALID_E_POINT_CHECK_ERROR(ptDi);
            SET_PMKEY_FOR_STAT_SETUP_DRB_RELEASE(ptCi, pPmKey);

            pRetainExtraInfo->retainStatForAmfReq.savedEventCategory = ptDi->retainStatForAmfReq.savedEventCategory;
            pRetainExtraInfo->retainStatForAmfReq.savedEventItem     = ptDi->retainStatForAmfReq.savedEventItem;
            pRetainExtraInfo->cslInfo.includingRelTotal = (skipTotalType == TRUE) ? VCCB_FLAG_OFF : VCCB_FLAG_ON;
            pRetainExtraInfo->cslInfo.inSessionFlagByE1 = ptDi->retainStat.inSessionFlagByE1;
            pRetainExtraInfo->cslInfo.fiveQi = fiveQi;
            UPDATE_DRB_ABNORMAL_REL_STAT_CAUSE_5QI(pRetainExtraInfo->cslInfo.abnRelCause5qi, ptDi->retainStat.abnRelCause5qi);
            break;

        case STAT_SETUP_DRB_RELEASE_DU_ID_PLMN_SNSSAI:
        case STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID_PLMN_SNSSAI:
            VALID_E_POINT_CHECK_ERROR(ptDi);
            SET_PMKEY_FOR_STAT_SETUP_DRB_RELEASE_DU_ID_PLMN_SNSSAI(ptCi, pPmKey);

            pRetainExtraInfo->retainStatForAmfReq.savedEventCategory = ptDi->retainStatForAmfReq.savedEventCategory;
            pRetainExtraInfo->retainStatForAmfReq.savedEventItem     = ptDi->retainStatForAmfReq.savedEventItem;
            UPDATE_DRB_ABNORMAL_REL_STAT_CAUSE_5QI(pRetainExtraInfo->cslInfo.abnRelCause5qi, ptDi->retainStat.abnRelCause5qi);
            break;

        case STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID:
        case STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID_PLMN: /* MOCN */
        case STAT_SETUP_ACTIVE_DRB_RELEASE_GLOBAL_ID_PLMN: /* for Only MSO */
            VALID_E_POINT_CHECK_ERROR(ptDi);
            SET_PMKEY_FOR_STAT_SETUP_ACTIVE_DRB_RELEASE_FAMILY(ptCi, pPmKey);

            pRetainExtraInfo->retainStatForAmfReq.savedEventCategory = ptDi->retainStatForAmfReq.savedEventCategory;
            pRetainExtraInfo->retainStatForAmfReq.savedEventItem     = ptDi->retainStatForAmfReq.savedEventItem;
            UPDATE_DRB_ABNORMAL_REL_STAT_CAUSE_5QI(pRetainExtraInfo->cslInfo.abnRelCause5qi, ptDi->retainStat.abnRelCause5qi);
            break;

        case STAT_SETUP_ACTIVE_UECONTEXT_RELEASE_DU_ID:
            SET_PMKEY_FOR_STAT_SETUP_ACTIVE_UECONTEXT_RELEASE(ptCi, pPmKey);
            break;

        case STAT_SETUP_DRB_RELEASE_PLMN_SNSSAI_5QI:
        case STAT_SETUP_ACTIVE_DRB_RELEASE_PLMN_SNSSAI_5QI:
            VALID_E_POINT_CHECK_ERROR(ptDi);
            SET_PMKEY_FOR_STAT_SETUP_DRB_RELEASE_PLMN_SNSSAI_5QI(ptCi, pPmKey);

            pRetainExtraInfo->retainStatForAmfReq.savedEventCategory = ptDi->retainStatForAmfReq.savedEventCategory;
            pRetainExtraInfo->retainStatForAmfReq.savedEventItem = ptDi->retainStatForAmfReq.savedEventItem;
            UPDATE_DRB_ABNORMAL_REL_STAT_CAUSE_5QI(pRetainExtraInfo->cslInfo.abnRelCause5qi, ptDi->retainStat.abnRelCause5qi);
            break;

        default:
            VCCB_PRINT_ERROR("Not a Stat family(%d) defined in VLIB_LibStatPmCC_Retain!\n", mFamily);
            return ERROR;
    }

    return GOOD;
}


static unordered_map<int /*PmFamilyId*/, int /*localFamilyIndex*/> pmStatMappingTable;

void FnVCCB_InitStatInfo(void)
{
    // This table is for converting Real Family Id to Local Id.

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// It is not necessary to list all family IDs, and you only need to add a family that needs to use ptCi->stat.flag[]! //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    int localFamilyIndexTable[] =
    {
        STAT_LB_PSCELL_CHANGE,
        STAT_INTER_DU_PSCELL_CHANGE_GETTING_BACK,
        STAT_SGNB_ADD_PER_GNB,
        STAT_SGNB_ADD_PER_GNB_PER_DU,
        STAT_SGNB_ADD_PER_DU_PER_GNB,
        STAT_SGNB_ADD_PER_GNB_PLMN,
        STAT_SGNB_ADD_PER_GNB_ECI_DU_ID,
        STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG,
        STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG_GLOBAL_ID_SPID,
        STAT_SGNB_ADD_SGNB_CHG,
        STAT_SGNB_ADD_SGNB_CHG_GLOBAL_ID_SPID,
        STAT_SGNB_ADD_MNHO_INTRA_ENB,
        STAT_SGNB_ADD_MNHO_INTRA_ENB_GLOBAL_ID_SPID,
        STAT_SGNB_ADD_MNHO_INTER_ENB,
        STAT_SGNB_ADD_MNHO_INTER_ENB_GLOBAL_ID_SPID,
        STAT_SGNB_INIT_SGNB_MOD_PER_GNB,
        STAT_MENB_INIT_SGNB_MOD_PER_GNB,
        STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB,
        STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB_DU_ID_CELL_SPID,
        STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB,
        STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB_DU_ID_CELL_SPID,
        STAT_INTRA_FREQ_PSCELL_CHANGE_SCGMOB_PER_GNB_DU_ID,
        STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB,
        STAT_F1AP_UE_SETUP_CU,
        STAT_F1AP_CU_INIT_UE_MOD_CU,
        STAT_HO_OUT,
        STAT_PLMN_HO_OUT,
        STAT_LB_HO,
        STAT_INTRA_NR_LB_HO,
        STAT_HO_IN,
        STAT_HO_IN_REDCAP,
        STAT_RRC_ESTAB,
        STAT_NG_ESTAB,
        STAT_NG_ESTAB_DU_ID_PLMN,
        STAT_INITIAL_CONTEXT_SETUP,
        STAT_RRC_REESTAB,
        STAT_FORCED_MOBILITY_NR,
        STAT_FORCED_MOBILITY_EUTRAN,

        // IRAT_HO
        STAT_HO_EUTRAN_OUT,
        STAT_HO_EUTRAN_OUT_FALLBACK,
        STAT_HO_EUTRAN_FREQ_OUT,
        STAT_HO_EUTRAN_FREQ_OUT_REDCAP,
        STAT_SGNB_ADD_EUTRAN_OUT,
        STAT_HO_EUTRAN_IN,
        STAT_HO_EUTRAN_IN_REDCAP,
        STAT_HO_INTER_FREQ_OUT,
        STAT_HO_INTER_FREQ_OUT_REDCAP,
        STAT_HO_INTRA_FREQ_OUT,
        STAT_HO_INTRA_FREQ_OUT_REDCAP,

        // HO Service Type
        STAT_HO_IN_SERVICE_TYPE,
        STAT_HO_EUTRAN_IN_SERVICE_TYPE,
        STAT_HO_OUT_SERVICE_TYPE,
        STAT_HO_EUTRAN_OUT_SERVICE_TYPE,
        STAT_HO_EUTRAN_OUT_FALLBACK_SERVICE_TYPE,
        STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE,
        STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE,
        STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE,

        // NE-DC
        STAT_NEDC_ADD,

        // NR-DC
        STAT_NRDC_SN_ADD_MN,
        STAT_NRDC_SN_ADD_MN_PSCELL_NCI,
        STAT_NRDC_SN_ADD_SN_WITH_INVALID_CELL,
        STAT_NRDC_SN_ADD_SN_PCELL_NCI,

        // STAT_NRDC_PSCELL_CHANGE_IN (Nr-DC SN Intra gNB Mobility)
        STAT_NRDC_PSCELL_CHANGE_IN,

        // STAT_NRDC_PSCELL_CHANGE_OUT (Nr-DC SN Mobility)
        STAT_NRDC_PSCELL_CHANGE_OUT,

        // Conditional Handover
        STAT_CHO_OUT,
        STAT_CHO_IN,

        // FGR-CC5200:FR680
        V_STAT_NRDC_SN_MOD_MN_MNInitiated, // for STAT_NRDC_SN_MOD_MN
        V_STAT_NRDC_SN_MOD_MN_SNInitiated, // for STAT_NRDC_SN_MOD_MN
        V_STAT_NRDC_SN_MOD_SN_MNInitiated, // for STAT_NRDC_SN_MOD_SN
        V_STAT_NRDC_SN_MOD_SN_SNInitiated  // for STAT_NRDC_SN_MOD_SN
    };

    pmStatMappingTable.clear();

    const int max_local_index_table = GET_ARR_SIZE(localFamilyIndexTable);
    for (int localFamilyIndex = 0; localFamilyIndex < max_local_index_table; localFamilyIndex++)
    {
        int pmFamilyId = localFamilyIndexTable[localFamilyIndex];

        // Map Insert (Duplicate keys are automatically ignored by unordermap)
        pmStatMappingTable.insert({pmFamilyId, localFamilyIndex});
    }
}

int FnVCCB_GetLocalFamilyIndexUsingPmFamilyId(int pmFamilyId)
{
    auto iter = pmStatMappingTable.find(pmFamilyId);

    if (iter == pmStatMappingTable.end())
    {
        // Not Found - localFamilyIndex
        // This is family information that does not need to be managed with Attempt.

#ifdef NEW_HOST_SIM
        VCCB_PRINT_ERROR("For using ptCi->stat.flag[], FamilyId(%d) should be registered in pmStatMappingTable!\n",
                pmFamilyId);
#endif
        return -1; // Not Found
    }

    // Found localFamilyIndex
    // This is family information that needs to be managed with Attempt.
    return iter->second;
}

// For GTEST
int FnVCCB_GetStatMappingTableSize(void)
{
    return (int)pmStatMappingTable.size();
}


static std::set<uint32_t> serviceTypeListSet;   // for checking only valid service type, this will include only serviceTypeList's index (0~63)
static std::set<uint32_t> serviceTypeListSetOnlyUeInfo; // serviceTypeList's index will be included if mcc, mnc, rfsp only is valid

#define SERVICE_TYPE_LIST CFG->acpfInfo.serviceTypeList
void FnVCCB_InitServiceTypeList()
{
    CFG->acpfInfo.serviceTypeOnOff = CI_no_use;
    memset(SERVICE_TYPE_LIST, 0, sizeof(SERVICE_TYPE_LIST));

    serviceTypeListSet.clear();
    serviceTypeListSetOnlyUeInfo.clear();
}

void FnVCCB_SetServiceType(ServiceTypeList_type &ServiceType,
        int32_t mcc, int32_t mnc, int32_t sst, int32_t sd, int16_t fiveQi, int16_t rfsp, int16_t arp, int16_t ueType)
{
    memset(&ServiceType, 0, sizeof(ServiceType));

    ServiceType.ItemList.mcc    = ((mcc+1)    & 0x1FFF);
    ServiceType.ItemList.mnc    = ((mnc+1)    & 0x1FFF);
    ServiceType.ItemList.sst    = ((sst+1)    & 0x1FF);
    ServiceType.ItemList.sd     = ((sd+1)     & 0x1FFFFFF);
    ServiceType.ItemList.fiveQi = ((fiveQi+1) & 0x1FF);
    ServiceType.ItemList.rfsp   = ((rfsp+1)   & 0x3FF);
    ServiceType.ItemList.arp    = ((arp+1)    & 0x1FF);
    ServiceType.ItemList.ueType = ((ueType+1) & 0x3);

    return;
}

// add std::set/std::map when serviceTypeList[].usage is use
void FnVCCB_SetValidServiceTypeListSet(void)
{
    std::set<uint32_t> tmpServiceType;
    std::set<uint32_t> tmpServiceTypeOnlyUeInfo;

    auto serviceTypeList = CFG->acpfInfo.serviceTypeList;
    for(uint32_t i = 0; i < MAX_SERVICE_TYPE_NUM; i++)
    {
        if( serviceTypeList[i].usage == CI_no_use )
            continue;

        tmpServiceType.insert(i);

        if( i == 0 ) continue;  // Don't need to be set '0' for Only UeInfo

        // find the serviceListItem with only rfsp or mcc or mnc like only included in ueInfo not bearer
        if( (serviceTypeList[i].ItemList.sst    == 0) &&
            (serviceTypeList[i].ItemList.sd     == 0) &&
            (serviceTypeList[i].ItemList.fiveQi == 0) &&
            (serviceTypeList[i].ItemList.arp    == 0) )
        {
            if( serviceTypeList[i].ItemList.mcc    != 0 ||
                serviceTypeList[i].ItemList.mnc    != 0 ||
                serviceTypeList[i].ItemList.rfsp   != 0 ||
                serviceTypeList[i].ItemList.ueType != 0 )
            {
                tmpServiceTypeOnlyUeInfo.insert(i);
            }
        }
    }

    // Update ServiceTypeListSet for preventing using other thread safe
    serviceTypeListSet = tmpServiceType;
    serviceTypeListSetOnlyUeInfo = tmpServiceTypeOnlyUeInfo;
}


// When YANG is configured, All Item's value can not be Zero(0).
// so below is check condition except '0' and not matched item.
// 0 means "not-configured" so '0' is considered as matched.

#define IS_VALID_MATCH_ITEM(__Item) \
    if((pItem->__Item != 0) && (pItem->__Item != target.ItemList.__Item)) continue;


int16_t FnVCCB_GetServiceTypeResultOnlyUeInfo(const ServiceTypeList_type target, std::set<uint32_t> &serviceTypeListResultSet)
{
    auto serviceTypeList = CFG->acpfInfo.serviceTypeList;

    // for checking only UE side not DRB
    for( auto iter : serviceTypeListSetOnlyUeInfo )
    {
        if (iter >= MAX_SERVICE_TYPE_NUM) continue;
        if (serviceTypeList[iter].usage == CI_no_use) continue;

        ServiceTypeItemList *pItem = &serviceTypeList[iter].ItemList;

        IS_VALID_MATCH_ITEM(mcc);
        IS_VALID_MATCH_ITEM(mnc);
        IS_VALID_MATCH_ITEM(rfsp);
        IS_VALID_MATCH_ITEM(ueType);

        serviceTypeListResultSet.insert(iter);
    }

    return GOOD;
}

int16_t FnVCCB_GetServiceTypeResult(const ServiceTypeList_type target, std::set<uint32_t> &serviceTypeListResultSet)
{
    auto serviceTypeList = CFG->acpfInfo.serviceTypeList;
    for( auto iter : serviceTypeListSet )
    {
        if (iter >= MAX_SERVICE_TYPE_NUM) continue;
        if (serviceTypeList[iter].usage == CI_no_use) continue;

        if( iter == 0 )
        {
            serviceTypeListResultSet.insert(iter);
            continue;
        }

        ServiceTypeItemList *pItem = &serviceTypeList[iter].ItemList;

        IS_VALID_MATCH_ITEM(mcc);
        IS_VALID_MATCH_ITEM(mnc);
        IS_VALID_MATCH_ITEM(sst);
        IS_VALID_MATCH_ITEM(sd);
        IS_VALID_MATCH_ITEM(fiveQi);
        IS_VALID_MATCH_ITEM(rfsp);
        IS_VALID_MATCH_ITEM(arp);
        IS_VALID_MATCH_ITEM(ueType);

        // finally Match
        serviceTypeListResultSet.insert(iter);
    }

    // for checking only UE side except DRB
    FnVCCB_GetServiceTypeResultOnlyUeInfo(target, serviceTypeListResultSet);

    return GOOD;
}
#undef IS_VALID_MATCH_ITEM


int16_t FnVCCB_GetQosServiceType(callInfo_type *ptCi, callPDUSessInfo_type *ptPi, qosFlowInfo_type *ptQi, std::set<uint32_t> &serviceTypeListResultSet)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptPi);
    VALID_E_POINT_CHECK_ERROR(ptQi);

    uint32_t sst;
    uint32_t sd;
    uint8_t  fiveQi;
    uint16_t rfsp;
    uint16_t arp;
    uint16_t ueType;

    ServiceTypeList_type  target;

    if(ptPi->usage != CI_use) return BREAK;
    if(ptQi->usage != CI_use) return BREAK;

    // S-NSSAI, 5QI, RFSP
    sst = ptPi->sNssai.sst;
    sd = ptPi->sNssai.sd;

    VLIB_getFiveQi(ptQi, &fiveQi);
    rfsp = FnVCCB_GetRfspValue(ptCi);
    arp = ptQi->qosParam.allocAndRetent.priorityLevel;
    ueType = IS_REDCAP_UE(ptCi);

    // Setting target's information
    FnVCCB_SetServiceType(target,
            ptCi->ueInfo.servedPlmn.s2.mcc,
            ptCi->ueInfo.servedPlmn.s2.mnc,
            (int32_t)sst,
            (int32_t)sd,
            (int16_t)fiveQi,
            (int16_t)rfsp,
            (int16_t)arp,    /* ARP */
            (int16_t)ueType  /* ueType - normal or redCapUe */);

    // --> check result
    FnVCCB_GetServiceTypeResult(target, serviceTypeListResultSet);

    return GOOD;
}

int16_t FnVCCB_GetDrbServiceType(callInfo_type *ptCi, callDRBInfo_type *ptDi, std::set<uint32_t> &serviceTypeListResultSet)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);

    VCCB_CHECK_E_RANGE_AND_VAL(ptDi->pduIdxInCall, MAX_PDU_SESS_PER_CALL, BREAK);
    VCCB_CHECK_E_RANGE_AND_VAL(ptDi->drbQosIdxInCall, MAX_QOS_FLOW_PER_CALL, BREAK);

    uint32_t sst;
    uint32_t sd;
    uint8_t  fiveQi;
    uint16_t rfsp;
    uint16_t arp;
    uint16_t ueType;

    ServiceTypeList_type  target;

    if(ptDi->usage != CI_use) return BREAK;

    // S-NSSAI, 5QI, RFSP
    sst = ptCi->pduSess[ptDi->pduIdxInCall].sNssai.sst;
    sd = ptCi->pduSess[ptDi->pduIdxInCall].sNssai.sd;

    qosFlowInfo_type *ptQi = &ptCi->qosFlow[ptDi->drbQosIdxInCall];

    VLIB_getFiveQi(ptQi, &fiveQi);
    rfsp = FnVCCB_GetRfspValue(ptCi);
    arp = ptQi->qosParam.allocAndRetent.priorityLevel;
    ueType = IS_REDCAP_UE(ptCi);


    // Setting target's information
    FnVCCB_SetServiceType(target,
            ptCi->ueInfo.servedPlmn.s2.mcc,
            ptCi->ueInfo.servedPlmn.s2.mnc,
            (int32_t)sst,
            (int32_t)sd,
            (int16_t)fiveQi,
            (int16_t)rfsp,
            (int16_t)arp,    /* ARP */
            (int16_t)ueType  /* ueType - normal or redCapUe */);

    // --> check result
    FnVCCB_GetServiceTypeResult(target, serviceTypeListResultSet);

    return GOOD;
}

int16_t FnVCCB_GetCallServiceType(callInfo_type *ptCi, std::set<uint32_t> &serviceTypeListResultSet)
{
    int16_t status = GOOD;
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    callDRBInfo_type *ptDi;
    uint16_t    drbCount = 0;

    if( CFG->acpfInfo.serviceTypeList[0].usage == CI_use )
        serviceTypeListResultSet.insert(0);

    for( uint32_t drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++ )
    {
        ptDi = &ptCi->drb[drbIdx];

        if( ptDi->usage != CI_use ) continue;

        if( ptDi->drbStatus == S_Setup || ptDi->drbStatus == S_FailToSetup ) continue;

        if( IS_NRDC_SN(ptCi) ) {
            if(ptDi->bearerType.termPoint == TermPoint_Mn) continue;
        }
        else {
            if( ptDi->bearerType.termPoint == TermPoint_Sn) continue;
        }

        status = FnVCCB_GetDrbServiceType(ptCi, ptDi, serviceTypeListResultSet);
        if( status == ERROR)
            continue;

        drbCount++;
    }


    // For Signalling only call, check statistics item using in serviceTypeListSetOnlyUeInfo
    if( drbCount == 0 )
    {
        ServiceTypeList_type  target;

        uint16_t rfsp = FnVCCB_GetRfspValue (ptCi);
        uint16_t ueType = IS_REDCAP_UE(ptCi);

        FnVCCB_SetServiceType(target,
                ptCi->ueInfo.servedPlmn.s2.mcc,
                ptCi->ueInfo.servedPlmn.s2.mnc,
                0,      /* SST */
                0,      /* SD  */
                0,      /* 5QI */
                (int16_t)rfsp,
                0,      /* ARP */
                (int16_t)ueType  /* ueType - normal or redCapUe */ );

        FnVCCB_GetServiceTypeResultOnlyUeInfo(target, serviceTypeListResultSet);
    }

    return status;
}

void FnVCCB_PeriodicStat_SaCommonDrbConnInfo(VccbCellInfo_type *pCell, enumDrbStatCollectOption_type collectOption)
{
    VALID_E_POINT_CHECK_VOID(pCell);
    VCCB_CHECK_E_RANGE_AND_VOID(pCell->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(pCell->profileDBInfo.pdcpProfileIdx, MAX_PDCP_INFO_PROFILE_PER_GNB);
    VccbGnbInfo_type *pGnb = &GNBINFO[pCell->gnbNum];
    pdcpProfile_type *pPdcpProf = &pGnb->pdcpProfile[pCell->profileDBInfo.pdcpProfileIdx];
    if (pPdcpProf->status != EQUIP) return;

    uint16_t fiveQiIdx = 0;
    uint8_t isSaCellCollect = VCCB_FLAG_OFF;
    uint8_t isNrDcSnCollect = VCCB_FLAG_OFF;
    uint8_t  plmnInfoIdx = 0;

    if (IS_SA_CELL_FOR_STAT(pCell))
        isSaCellCollect = VCCB_FLAG_ON;

    if (FOO.VF_NRDC_ConnInfo)
        isNrDcSnCollect = VCCB_FLAG_ON;

    if(isSaCellCollect || isNrDcSnCollect)
    {
        // For All or 1 Min stattistics.
        if ((collectOption == CollectDrbStatOpt_AllDrbConn ) ||
            (collectOption == CollectDrbStatOpt_1min_Period))
        {
            for (fiveQiIdx = 0; fiveQiIdx < MAX_5QI_VALUE; fiveQiIdx++)
            {
                if (pPdcpProf->pdcpInfo5qi[fiveQiIdx].shmStatus == N_EQUIP) continue;

                if (TRUE == FOO.VF_QoS5qiSupportPerPLMN)
                {
                    for (uint8_t plmnIdx = 0; plmnIdx < MAX_PLMN_INDEX; ++plmnIdx)
                    {
                        if (GOOD != VLIB_getMultipleGnbPlmnIndexInfo(pCell->gnbNum, &plmnInfoIdx, pCell->cellPlmnIndexInfo[plmnIdx].servedPlmn))
                            continue;

                        if (pGnb->perPlmnQos5qiSupport[plmnInfoIdx][fiveQiIdx])
                        {
                            if(isSaCellCollect)
                                FnVCCB_PeriodicStat_SaCellDrbConnInfoForPlmn(pCell, fiveQiIdx, plmnIdx);
                            if(isNrDcSnCollect)
                                FnVCCB_PeriodicStat_NrdcSnTermDrbConnInfoForPlmn(pCell, fiveQiIdx, plmnIdx);
                        }
                    }
                }
                else
                {
                    if (!pGnb->qos5qiSupport[fiveQiIdx]) continue;

                    if(isSaCellCollect)
                        FnVCCB_PeriodicStat_SaCellDrbConnInfo(pCell, fiveQiIdx);
                    if(isNrDcSnCollect)
                        FnVCCB_PeriodicStat_NrdcSnTermDrbConnInfo(pCell, fiveQiIdx);
                }
            } // for fiveQiIdx
        }

        // For All or 10s stattistics. (For JIO 25B PH3)
        if ((collectOption == CollectDrbStatOpt_AllDrbConn) ||
            (collectOption == CollectDrbStatOpt_10s_Period))
        {
            // DRB Conn with PLMN+Slice (No 5QI)
            if ((isSaCellCollect) && (FOO.VF_ConnInfoPlmnSnssaiCounterConfig))
            {
                FnVCCB_PeriodicStat_SaCellDrbConnPlmnSlice(pGnb, pCell);
            }
        }

    }

    return;
}

void FnVCCB_StatCallFaultPerFailCauseSCGFailure_NRDC(callInfo_type *ptCi, uint32_t msgId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!IS_NRDC_SN(ptCi))
        return;

    if (ptCi->nrdcScgFailureInfo.event == NrDcScgFailure_NoEvent &&
        ptCi->cause.xnCause != CauseXnapRadioNetworkLayerRadioConnectionWithUeLost)
        return;

    if (ptCi->nrdcScgFailureInfo.event == NrDcScgFailure_SnInit_Suspend)
    {
        // SVR24B FR300: CRR
        MACRO_F1RLF_CALL_FAULT_SAVE(msgId, ptCi->cause.f1Cause);
    }
    else    // NrDcScgFailure_MnInit_Suspend or NrDcScgFailure_MnInit_Resume
    {
        switch (ptCi->nrdcScgFailureInfo.failType)
        {
            case NrDcScgFailCause_dl_t310Expiry:                                            // 0
                MACRO_CALL_FAULT_SAVE(msgId, CauseCpInternalT310Expiry);                    // 0x112D
                break;
            case NrDcScgFailCause_dl_randomAccessProblem:                                   // 1
                MACRO_CALL_FAULT_SAVE(msgId, CauseCpInternalRandomAccessProblem);           // 0x112E
                break;
            case NrDcScgFailCause_dl_rlcMaxRetransmission:                                  // 2
                MACRO_CALL_FAULT_SAVE(msgId, CauseCpInternalRlcMaxNumRetx);                 // 0x112F
                break;
            case NrDcScgFailCause_dl_synchReconfigFailure:                                  // 3
                MACRO_CALL_FAULT_SAVE(msgId, CauseCpInternalSynchReconfigFailureScg);       // 0x1130
                break;
            case NrDcScgFailCause_dl_scgReconfigFailure:                                    // 4
                MACRO_CALL_FAULT_SAVE(msgId, CauseCpInternalScgReconfigFailure);            // 0x1131
                break;
            case NrDcScgFailCause_dl_srb3IntegrityFailure:                                  // 5
                MACRO_CALL_FAULT_SAVE(msgId, CauseCpInternalSrb3IntegrityFailure);          // 0x1133
                break;
            case NrDcScgFailCause_dl_scglbtFailure:                                         // 6
            case NrDcScgFailCause_dl_bhRLF:                                                 // 9
                MACRO_CALL_FAULT_SAVE(msgId, CauseCpInternalScgFailureOthers);              // 0x1135
                break;
            case NrDcScgFailCause_dl_beamFailureRecoveryFailure:                            // 7
                MACRO_CALL_FAULT_SAVE(msgId, CauseCpInternalBeamFailureRecoveryFailure);    // 0x1130
                break;
            case NrDcScgFailCause_dl_t312Expiry:                                            // 8
                MACRO_CALL_FAULT_SAVE(msgId, CauseCpInternalT312Expiry);                    // 0x1132
                break;
            case NrDcScgFailCause_ul_outOfSync:                                             // 10
                MACRO_CALL_FAULT_SAVE(msgId, CauseCpInternalDuULRadioLinkFailure);          // 0x1021
                break;
            case NrDcScgFailCause_ul_rlcMaxRetransmission:                                  // 11
                MACRO_CALL_FAULT_SAVE(msgId, CauseCpInternalDuRlcMaxNumRetx);               // 0x1022
                break;
            default:
                break;
        }
    }
}

#define MAX_RETAIN_SERVICE_TYPE_STAT_INFO 10
typedef struct {
    int mActualFamily;
    int serviceTypeKeyIndex;
} RetainStatFamilyInfo_type;

typedef struct {
    int     num;
    RetainStatFamilyInfo_type  familyInfo[MAX_RETAIN_SERVICE_TYPE_STAT_INFO];
} RetainServiceTypeCollectInfo_type;

void FnVCCB_CollectNrRetainServiceType(callInfo_type *ptCi, int mFamily, callDRBInfo_type *ptDi, VccbPmMultiCollect_type *pPmMultiCollect, VccbPmKey_type &rPmKey)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pPmMultiCollect);

    RetainServiceTypeCollectInfo_type   retainServiceTypeCollectInfo, *pCollectInfo;

    uint16_t gnbNum = ptCi->gnbNum;
    VCCB_CHECK_VALID_GNBNUM_VOID(gnbNum);
    VccbGnbInfo_type *pGnb = &GNBINFO[gnbNum];

    int ueLevelServiceType = FALSE;
    int serviceTypeKeyIndex = 0;
    int16_t status = GOOD;

    std::set<uint32_t> serviceTypelist;
    memset(&retainServiceTypeCollectInfo, 0, sizeof(retainServiceTypeCollectInfo));
    pCollectInfo = &retainServiceTypeCollectInfo;
    int &statIndex = pCollectInfo->num;

    // 1. Get Actual Family
    switch (mFamily)
    {
        case STAT_SETUP_UECONTEXT_RELEASE:
            if (FOO.VF_ServiceTypeConfigurationforStatisticsSA_DEPRECATED &&
                pGnb->cfg.serviceTypeCounterConfig.setupUecontextReleaseDuidServicetype)     // SVR24B
            {
                pCollectInfo->familyInfo[statIndex].mActualFamily = STAT_SETUP_UECONTEXT_RELEASE_DU_ID_SERVICE_TYPE;
                pCollectInfo->familyInfo[statIndex].serviceTypeKeyIndex = VCCB_PMKEY_INDEX4;
                statIndex++;
            }

            if(pGnb->cfg.serviceTypeCounterConfig.setupUecontextReleaseServicetype)         // SVR26A
            {
                pCollectInfo->familyInfo[statIndex].mActualFamily = STAT_SETUP_UECONTEXT_RELEASE_SERVICE_TYPE;
                pCollectInfo->familyInfo[statIndex].serviceTypeKeyIndex = VCCB_PMKEY_INDEX5;
                statIndex++;
            }

            if(VCCB_FLAG_ON == ptCi->bitFlag.activeUeContextRelease &&
               pGnb->cfg.serviceTypeCounterConfig.setupActiveUecontextReleaseServicetype)   // SVR26A
            {
                pCollectInfo->familyInfo[statIndex].mActualFamily = STAT_SETUP_ACTIVE_UECONTEXT_RELEASE_SERVICE_TYPE;
                pCollectInfo->familyInfo[statIndex].serviceTypeKeyIndex = VCCB_PMKEY_INDEX5;
                statIndex++;
            }

            ueLevelServiceType = TRUE;
            break;

        case STAT_SETUP_DRB_RELEASE:
            if (FOO.VF_ServiceTypeConfigurationforStatisticsSA_DEPRECATED &&
                pGnb->cfg.serviceTypeCounterConfig.setupDrbReleaseDuidServicetype)
            {
                pCollectInfo->familyInfo[statIndex].mActualFamily = STAT_SETUP_DRB_RELEASE_DU_ID_SERVICE_TYPE;
                pCollectInfo->familyInfo[statIndex].serviceTypeKeyIndex = VCCB_PMKEY_INDEX4;
                statIndex++;
            }

            if (pGnb->cfg.serviceTypeCounterConfig.setupDrbReleaseServicetype)
            {
                pCollectInfo->familyInfo[statIndex].mActualFamily = STAT_SETUP_DRB_RELEASE_SERVICE_TYPE;
                pCollectInfo->familyInfo[statIndex].serviceTypeKeyIndex = VCCB_PMKEY_INDEX5;
                statIndex++;
            }
            break;

        case STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID:
        case STAT_SETUP_ACTIVE_DRB_RELEASE_GLOBAL_ID_PLMN:
            if (pGnb->cfg.serviceTypeCounterConfig.setupActiveDrbReleaseServicetype)
            {
                pCollectInfo->familyInfo[statIndex].mActualFamily = STAT_SETUP_ACTIVE_DRB_RELEASE_SERVICE_TYPE;
                pCollectInfo->familyInfo[statIndex].serviceTypeKeyIndex = VCCB_PMKEY_INDEX5;
                statIndex++;
            }
            break;

        case STAT_ACTIVITY_INFO_SERVICE_TYPE:
            if (pGnb->cfg.serviceTypeCounterConfig.activityInfoServicetype)
            {
                pCollectInfo->familyInfo[statIndex].mActualFamily = STAT_ACTIVITY_INFO_SERVICE_TYPE;
                pCollectInfo->familyInfo[statIndex].serviceTypeKeyIndex = VCCB_PMKEY_INDEX5;
                statIndex++;
            }
            break;

        default:
            break;
    }

    if (statIndex == 0)  // not target family
    {
        if (ueLevelServiceType)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                "FnVCCB_CollectNrRetainServiceType not collected : mFamily(%d), UE-serviceTypeCounter(%d,%d,%d)\n", mFamily,
                pGnb->cfg.serviceTypeCounterConfig.setupUecontextReleaseServicetype,
                pGnb->cfg.serviceTypeCounterConfig.setupUecontextReleaseDuidServicetype,
                pGnb->cfg.serviceTypeCounterConfig.setupActiveUecontextReleaseServicetype);
        }
        else
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                "FnVCCB_CollectNrRetainServiceType not collected : mFamily(%d), DRB-serviceTypeCounter(%d,%d,%d,%d)\n", mFamily,
                pGnb->cfg.serviceTypeCounterConfig.setupDrbReleaseServicetype,
                pGnb->cfg.serviceTypeCounterConfig.setupDrbReleaseDuidServicetype,
                pGnb->cfg.serviceTypeCounterConfig.setupActiveDrbReleaseServicetype,
                pGnb->cfg.serviceTypeCounterConfig.activityInfoServicetype);
        }

        return;
    }

    // 2. Get Service Type List per UE / DRB
    if (ueLevelServiceType)
    {
        status = FnVCCB_GetCallServiceType(ptCi, serviceTypelist);
        if (status != GOOD)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetCallServiceType ERROR(%d)\n", status);
        }
    }
    else
    {
        status = FnVCCB_GetDrbServiceType(ptCi, ptDi, serviceTypelist);
        if (status != GOOD)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetDrbServiceType ERROR(%d)\n", status);
        }
    }

    // 3. Collect ServiceType statistiacs if exist
    if (serviceTypelist.size() > 0)
    {
        for(uint8_t idx = 0; idx < statIndex; idx++)
        {
            VccbPmKey_type pmKey = rPmKey;

            StatisticsHandler statHandler(ptCi->gnbNum);
            statHandler.fillStatisticsIndex(ptCi, pmKey, mFamily, pCollectInfo->familyInfo[idx].mActualFamily);

            for (auto iterServType : serviceTypelist)
            {
                serviceTypeKeyIndex = pCollectInfo->familyInfo[idx].serviceTypeKeyIndex;
                pmKey.keyList[serviceTypeKeyIndex] = iterServType;

                if(mFamily == STAT_ACTIVITY_INFO_SERVICE_TYPE)   // using updateItemUllArr
                {
                    // Call Statistic API
                    CollectPmStatistics(ptCi, (unsigned)mFamily, (unsigned)pCollectInfo->familyInfo[idx].mActualFamily, pPmMultiCollect,
                        pPmMultiCollect->updateItemUllArr, pmKey, TRUE);
                }
                else
                {
                    // Call Statistic API
                    CollectPmStatistics(ptCi, (unsigned)mFamily, (unsigned)pCollectInfo->familyInfo[idx].mActualFamily, pPmMultiCollect,
                        pPmMultiCollect->updateItemUintArr, pmKey, TRUE);
                }
            }
        }
    }
}

void FnVCCB_CollectNrRrcReestablishServiceType(callInfo_type *ptCi, int mFamily,
                                               VccbPmMultiCollect_type *pPmMultiCollect, VccbPmKey_type &rPmKey)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pPmMultiCollect);

    uint16_t gnbNum = ptCi->gnbNum;
    VCCB_CHECK_VALID_GNBNUM_VOID(gnbNum);
    VccbGnbInfo_type *pGnb = &GNBINFO[gnbNum];

    int mActualFamily = 0;
    int serviceTypeKeyIndex = 0;
    int16_t status = GOOD;

    std::set<uint32_t> serviceTypelist;

    // 1. Get Actual Family
    if (pGnb->cfg.serviceTypeCounterConfig.rrcReestablishServiceTypeOnOff)
    {
        mActualFamily = STAT_RRC_REESTAB_SERVICE_TYPE;
        serviceTypeKeyIndex = VCCB_PMKEY_INDEX5;
    }
    else // rrcReestablishServiceTypeOnOff is false
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi,
            "FnVCCB_CollectNrRrcReestablishServiceType not collected : mFamily(%d), rrcReestablishServiceTypeOnOff(%d)\n", mFamily,
            pGnb->cfg.serviceTypeCounterConfig.rrcReestablishServiceTypeOnOff);

        return;
    }

    // 2. Get Service Type List per UE / DRB
    status = FnVCCB_GetCallServiceType(ptCi, serviceTypelist);
    if (status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetCallServiceType ERROR(%d)\n", status);
    }

    // 3. Collect ServiceType statistiacs if exist
    if (serviceTypelist.size() > 0)
    {
        VccbPmKey_type pmKey = rPmKey;

        StatisticsHandler statHandler(ptCi->gnbNum);
        statHandler.fillStatisticsIndex(ptCi, pmKey, mFamily, mActualFamily);

        for (auto iterServType : serviceTypelist)
        {
            pmKey.keyList[serviceTypeKeyIndex] = iterServType;

            // Call Statistic API
            CollectPmStatistics(ptCi, (unsigned)mFamily, (unsigned)mActualFamily, pPmMultiCollect,
                pPmMultiCollect->updateItemUintArr, pmKey, TRUE);
        }
    }
}

void FnVCCB_CollectStatCSL_RrcSetup(callInfo_type *ptCi, int mFamily, int mType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    (void)mFamily;

    ptCi->cslInfo.basicCallStatInfo.rrcSetup_Attempt = 1;
    if(mType == ConnEstabSucc)
    {
        ptCi->cslInfo.basicCallStatInfo.rrcSetup_Success = 1;
    }
    else
    {
        ptCi->cslInfo.basicCallStatInfo.rrcSetup_Success = 0;
    }
    return;
}

void FnVCCB_CollectStatCSL_RrcReestab(callInfo_type *ptCi, int mFamily, int mType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    (void)mFamily;

    switch (mType)
    {
        case IntraGnbReEstabFail_Ignore ... IntraGnbReEstabFail_RrcSetupTimeout:
            ptCi->cslInfo.cslRreInfo.vonrRreFailCause = (uint8_t)mType;
            break;
        case InterGnbReEstabFail_Ignore ... ReEstabToRrcSetup_Overload:
            ptCi->cslInfo.cslRreInfo.vonrRreFailCause = (uint8_t)mType;
            break;
        default:
            break;
    }

    return;
}

void FnVCCB_UeRetain_CollectStat_PutCi(callInfo_type *ptCi)
{
    //MACRO_INCREASE_BASIC_CALL_STAT_CSL_COLLECT_ORDER(ptCi);


    if (ptCi->retainStat.savedEventCategory != No_CallDrb_RetainCategory)
    {
        // VCCB_PRINT_CALL_ERROR(ptCi, "[RETAIN_STAT] %s: savedEventCategory == %d\n",
        //        __func__, ptCi->retainStat.savedEventCategory);

        if(TRUE == FnVCCB_IsActiveUeContextStat(ptCi))
        {
            ptCi->bitFlag.activeUeContextRelease = VCCB_FLAG_ON;
        }

        if((FOO.VF_NRRetainability_ActiveUeContext) &&
           (VCCB_FLAG_ON == ptCi->bitFlag.activeUeContextRelease))
        {
            MACRO_STAT_PMCC_RETAIN(STAT_SETUP_ACTIVE_UECONTEXT_RELEASE_DU_ID, ptCi, NULL, ptCi->retainStat.savedEventCategory,
                                ptCi->retainStat.savedEventItem, 0, FALSE);
        }

        // Update STAT
        // Use MACRO like DRB case - RETAIN_STAT_HO_21C
        MACRO_STAT_PMCC_RETAIN(STAT_SETUP_UECONTEXT_RELEASE, ptCi, NULL, ptCi->retainStat.savedEventCategory,
            ptCi->retainStat.savedEventItem, 0, FALSE);

        // Clear Event
        CLEAR_RETAIN_STAT_EVENT(ptCi->retainStat);
    }

    if((ptCi->rrcConnStat.vonrEmerCallFlag == VCCB_FLAG_ON) &&
       (ptCi->retainStatOfVonrEmer.savedEventCategory != No_CallDrb_RetainCategory))
    {
        // VoNR Emergency Call Release
        MACRO_STAT_PMCC_RETAIN(STAT_VONR_EMERGENCY_RELEASE, ptCi, NULL, ptCi->retainStatOfVonrEmer.savedEventCategory,
                ptCi->retainStatOfVonrEmer.savedEventItem, 0, FALSE);
    }
}

void FnVCCB_AllDrbRetain_CollectStat_PutCi(callInfo_type *ptCi)
{
    callDRBInfo_type *ptDi = NULL;
    uint8_t pduDrbIdx = 0, callDrbIdx = 0;

    for (uint16_t callPduIdx = 0; callPduIdx < MAX_PDU_SESS_PER_CALL; callPduIdx++)
    {
        if (!IS_VALID_NODE(PDU_NODE, ptCi, &(ptCi->pduSess[callPduIdx]))) continue;

        for (pduDrbIdx = 0; pduDrbIdx < MAX_DRB_PER_PDU_SESS; pduDrbIdx++)
        {
            callDrbIdx = static_cast<uint8_t>(ptCi->pduSess[callPduIdx].drbIndex[pduDrbIdx]);  // put Drb Pool's data
            if (callDrbIdx >= MAX_DRB_PER_SA_CALL) continue;
            if (!IS_VALID_NODE(DRB_NODE, ptCi, &(ptCi->drb[callDrbIdx]))) continue;
            ptDi = &ptCi->drb[callDrbIdx];

            if (ptDi->retainStat.savedEventCategory != No_CallDrb_RetainCategory)
            {
                MACRO_STAT_PMCC_RETAIN(STAT_SETUP_DRB_RELEASE, ptCi, ptDi, ptDi->retainStat.savedEventCategory,
                                ptDi->retainStat.savedEventItem, 0, FALSE);
            }
        }
    }
}


void FnVCCB_CollectStatBeforeCSL_PutCi(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->callType == E_CALLTYPE_SA)
    {
        VLIB_RrcConnEstab_CollectStat_PutCi(ptCi);
        VLIB_DrbSetup_CollectStat_PutCi(ptCi);
        if (!IS_NRDC_SN(ptCi))
        {
            // UE Retan should be first than DRB retain because Active UE Retain.
            FnVCCB_UeRetain_CollectStat_PutCi(ptCi);
            FnVCCB_AllDrbRetain_CollectStat_PutCi(ptCi);
        }
    }
}

/**
 * @brief           Prepare latest released QCI structure and increment it
 * @param[in/out]   ptCi : call context / callInfo_type
 * @return          void
 */
void FnVCCB_CollectLatestReleasedQcis(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if ((ptCi->callType != E_CALLTYPE_NSA) || FALSE == FOO.VF_BasicOperationforENDC_NsaCslQciReporting)
    {
        return;
    }

    VLIB_PrepareLatestReleasedQcis(ptCi, FALSE);
    for (uint16_t erabIndex = 0; erabIndex < MAX_ERAB_PER_CALL; erabIndex++)
    {
        callERABInfo_type *ptRi = &(ptCi->erabInfo[erabIndex]);
        VLIB_IncrementLatestReleasedQcis(ptCi, ptRi);
    }
}

// 1: Change Position, 0,-1: No change,
int FnVCCB_QsortDrbSetupCslDescendingOrder(const void *arg1, const void *arg2)
{
    AUTO_TRACE_FUNC;

    const drbSetupCsl_type *a = static_cast<const drbSetupCsl_type *>(arg1);
    const drbSetupCsl_type *b = static_cast<const drbSetupCsl_type *>(arg2);

    // First check the collectOrder field
    if (a->collectOrder != b->collectOrder) {
        return (a->collectOrder > b->collectOrder) ? -1 : 1;
    }

    // If collectOrder is the same, check the fiveQi field
    if (a->fiveQi != b->fiveQi) {
        return (a->fiveQi < b->fiveQi) ? -1 : 1;
    }

    // Both fields are the same, no change needed
    return 0;
}

uint8_t FnVCCB_GetCslIndexForDrbSetup(callInfo_type *ptCi, int mFamily, uint8_t fiveQi, uint8_t *pUsingExistFiveQi)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_BASIC_CALL_STAT_CSL);
    VALID_E_POINT_CHECK_RET_VAL(pUsingExistFiveQi, MAX_BASIC_CALL_STAT_CSL);

    uint8_t currentNum = 0, idx=0;
    drbSetupCsl_type *pDrbSetupCslInfo = NULL;
    if(mFamily == STAT_DRB_SETUP)
    {
        pDrbSetupCslInfo = &ptCi->cslInfo.basicCallStatInfo.drbSetup[0];
        currentNum = MIN(ptCi->cslInfo.basicCallStatInfo.drbSetupStatNum, MAX_BASIC_CALL_STAT_CSL);
    }
    else
    {
        pDrbSetupCslInfo = &ptCi->cslInfo.basicCallStatInfo.initialDrbSetup[0];
        currentNum = MIN(ptCi->cslInfo.basicCallStatInfo.initialDrbSetupStatNum, MAX_BASIC_CALL_STAT_CSL);
    }

    // 1. currentNum is 0
    if(currentNum == 0) return currentNum;

    // 2. Find Same 5QI
    drbSetupCsl_type *pFindCslInfo = pDrbSetupCslInfo;
    for(idx=0; idx < currentNum; idx++, pFindCslInfo++)
    {
        if(pFindCslInfo->fiveQi == fiveQi)
        {
            *pUsingExistFiveQi = VCCB_FLAG_ON;
            return idx;
        }
    }

    // 3. if (currentNum < 4), Using currentNum
    if(currentNum < MAX_BASIC_CALL_STAT_CSL)
    {
        return currentNum;
    }

    // 4. if currentNum = 4,
    // 4-1. sort Order(Big),5qi(small) DesendingOrder(4,3,2,1)
    drbSetupCsl_type *pOrderDrbSetupInfo = pDrbSetupCslInfo;
    qsort(pOrderDrbSetupInfo, currentNum, sizeof(drbSetupCsl_type),
                    FnVCCB_QsortDrbSetupCslDescendingOrder);

    // 4-2. If lowest array has same collectOrder, then check 5QI
    if(pDrbSetupCslInfo[(currentNum-1)].collectOrder == ptCi->cslInfo.basicCallStatInfo.collectOrder)
    {
        if(pDrbSetupCslInfo[(currentNum-1)].fiveQi < fiveQi)
        {
            // Ignore New 5QI.
            if(DBG->flag.logBasicStatCsl)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[CSL][DrbSetup] family(%d),5Qi=%d, Ignored.\n", mFamily, fiveQi);
            }
            return MAX_BASIC_CALL_STAT_CSL;
        }
    }

    return --currentNum; // return 3;
}

void FnVCCB_RearrangeCslCollectOrder_DrbSetup(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t currentNum = 0;
    drbSetupCsl_type *pDrbSetupCslInfo = NULL;
    uint8_t prevOrder, newOrder, idx;

    // Rearrange is needed for only STAT_DRB_SETUP. (STAT_INITIAL_DRB_SETUP_DU_ID is not needed)
    pDrbSetupCslInfo = &ptCi->cslInfo.basicCallStatInfo.drbSetup[0];
    currentNum = MIN(ptCi->cslInfo.basicCallStatInfo.drbSetupStatNum, MAX_BASIC_CALL_STAT_CSL);

    if(currentNum == 0)
    {
        ptCi->cslInfo.basicCallStatInfo.collectOrder = ++currentNum;
        return;
    }
    else if(currentNum == 1)
    {
        pDrbSetupCslInfo->collectOrder = currentNum;
        ptCi->cslInfo.basicCallStatInfo.collectOrder = ++currentNum;
        return;
    }

    // Sorting: 4, 3, 2, 1
    drbSetupCsl_type *pOrderDrbSetupInfo = pDrbSetupCslInfo;
    qsort(pOrderDrbSetupInfo, currentNum, sizeof(drbSetupCsl_type),
                    FnVCCB_QsortDrbSetupCslDescendingOrder);

    // Rearrange collectOrder. // currentNum->(currentNum-1)->(currentNum-2)->(currentNum-3)
    prevOrder = pDrbSetupCslInfo->collectOrder;
    newOrder = currentNum;
    for(idx = 0; idx < currentNum; idx++, pDrbSetupCslInfo++)
    {
        if(idx == 0)
        {
            // Update New Order.
            pDrbSetupCslInfo->collectOrder = newOrder;
            continue;
        }

        if(pDrbSetupCslInfo->collectOrder != prevOrder)
        {
            // Save prevOrder
            prevOrder = pDrbSetupCslInfo->collectOrder;
            // Get New Order
            if(newOrder > 0) newOrder--;
        }
        // Update New Order
        pDrbSetupCslInfo->collectOrder = newOrder;
    }

    ptCi->cslInfo.basicCallStatInfo.collectOrder = ++currentNum;
    return;
}

void FnVCCB_AddDrbSetupFailCauseInCsl(callInfo_type *ptCi, uint16_t failCauseCslVal)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    basicCallStatCslInfo_type *pBasicCallCsl = &ptCi->cslInfo.basicCallStatInfo;
    if (pBasicCallCsl->setupFailCause5qi1StatNum < MAX_BASIC_CALL_STAT_CSL)
    {
        pBasicCallCsl->setupFailCause5Qi_1[pBasicCallCsl->setupFailCause5qi1StatNum] = failCauseCslVal;
        pBasicCallCsl->setupFailCause5qi1StatNum++;
    }
    else
    {
        for (int idx = 1; idx < MAX_BASIC_CALL_STAT_CSL; idx++)
        {
            pBasicCallCsl->setupFailCause5Qi_1[idx - 1] = pBasicCallCsl->setupFailCause5Qi_1[idx];
        }
        pBasicCallCsl->setupFailCause5Qi_1[MAX_BASIC_CALL_STAT_CSL - 1] = failCauseCslVal;
        pBasicCallCsl->setupFailCause5qi1StatNum = MAX_BASIC_CALL_STAT_CSL;
    }
}

void FnVCCB_Clear5QIFailCauseIfNotVoNRInCsl(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    basicCallStatCslInfo_type *pBasicCallCsl = &ptCi->cslInfo.basicCallStatInfo;
    uint8_t drbSetupStatNum = MIN(pBasicCallCsl->drbSetupStatNum, MAX_BASIC_CALL_STAT_CSL);
    for (int idx = 0; idx < drbSetupStatNum; idx++)
    {
        if (pBasicCallCsl->drbSetup[idx].fiveQi == VONR_5QI) return;
    }

    // No Find 5QI=1
    if (pBasicCallCsl->setupFailCause5qi1StatNum != 0)
    {
        pBasicCallCsl->setupFailCause5qi1StatNum = 0;
        memset(&pBasicCallCsl->setupFailCause5Qi_1[0], 0xFF, sizeof(pBasicCallCsl->setupFailCause5Qi_1));
    }
}

void FnVCCB_CollectStatCSL_DrbSetup(callInfo_type *ptCi, uint8_t fiveQi, int mFamily, int mType, uint16_t failCauseCslVal)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    drbSetupCsl_type *pDrbSetupCslInfo = NULL;
    uint8_t findIndex = MAX_BASIC_CALL_STAT_CSL;
    uint8_t usingExistFiveQi = VCCB_FLAG_OFF;
    uint8_t *pDrbSetupNum = NULL;

    // 1. Check FOO.
    if(!(FOO.VF_CallSummaryLogs_KPI))
    {
        if(DBG->flag.logBasicStatCsl)
        {
            VCCB_PRINT_CALL_INFORMATIVE( ptCi, "[CSL][DrbSetup] F_CallSummaryLogs_KPI is OFF. => No Collect\n");
        }
        return;
    }
    // 2. Check CNF Returning Call
    if(RscCall::isReturningCall(ptCi->callId) == TRUE)
    {
        if(DBG->flag.logBasicStatCsl)
        {
            VCCB_PRINT_CALL_INFORMATIVE( ptCi, "[CSL][DrbSetup] Returning Call => No Collect.\n");
        }
        return;
    }

    // 3. Check Allowed Family
    if((mFamily != STAT_DRB_SETUP) && (mFamily != STAT_INITIAL_DRB_SETUP_DU_ID))
    {
        return;
    }

    // 4. Get CSL Index
    findIndex = FnVCCB_GetCslIndexForDrbSetup(ptCi, mFamily, fiveQi, &usingExistFiveQi);
    if(findIndex >= MAX_BASIC_CALL_STAT_CSL)
    {
        // Ignore New 5QI
        if(DBG->flag.logBasicStatCsl)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[CSL][DrbSetup] family(%d),5Qi(%u), Invalid findIndex(%u).\n", mFamily, fiveQi, findIndex);
        }
        return;
    }

    // 5. Get CSL Data.
    if(mFamily == STAT_DRB_SETUP)
    {
        pDrbSetupCslInfo = &ptCi->cslInfo.basicCallStatInfo.drbSetup[findIndex];
        pDrbSetupNum = &ptCi->cslInfo.basicCallStatInfo.drbSetupStatNum;
    }
    else
    {
        pDrbSetupCslInfo = &ptCi->cslInfo.basicCallStatInfo.initialDrbSetup[findIndex];
        pDrbSetupNum = &ptCi->cslInfo.basicCallStatInfo.initialDrbSetupStatNum;
    }

    // 5. Fill CSL Data.
    // 5-1. If New 5QI, then increase DrbSetupNum and initialize count as 0.
    if(usingExistFiveQi == VCCB_FLAG_OFF) // New 5QI.
    {
        if(*pDrbSetupNum < MAX_BASIC_CALL_STAT_CSL)
        {
            ++(*pDrbSetupNum);
        }

        // If 5Qi is different, need to initialize count as 0.
        //  case 1:  New 5QI when pDrbSetupNum < 4
        //  case 2:  New 5QI when pDrbSetupNum = 4, and preempted by collectOrder/5qi order.
        pDrbSetupCslInfo->attempt = 0;
        pDrbSetupCslInfo->success = 0;
    }

    // 5-2. collectOrder, fiveQi
    pDrbSetupCslInfo->collectOrder = ptCi->cslInfo.basicCallStatInfo.collectOrder;
    pDrbSetupCslInfo->fiveQi       = fiveQi;

    // 5-3. attempt, success
    MACRO_INCREASE_DRBSETUP_STAT_COUNT_FOR_CSL(pDrbSetupCslInfo->attempt);
    if(mType == DrbSetupSucc)
    {
        MACRO_INCREASE_DRBSETUP_STAT_COUNT_FOR_CSL(pDrbSetupCslInfo->success);
    }

    if (mFamily == STAT_DRB_SETUP)
    {
        if ((fiveQi == VONR_5QI) && (mType != DrbSetupSucc))
        {
            FnVCCB_AddDrbSetupFailCauseInCsl(ptCi, failCauseCslVal);
        }

        // Check Clear 5QI Cause: If 5QI is not in pDrbSetupCslInfo, then cleare cause.
        FnVCCB_Clear5QIFailCauseIfNotVoNRInCsl(ptCi);
    }

    if(DBG->flag.logBasicStatCsl)
    {
        VCCB_PRINT_CALL_INFORMATIVE( ptCi, "[CSL][Drb] collectOrder=%u, InitialDrbNum=%u, DrbNum=%u, failCauseNum=%u, newIdx=%u\n",
                ptCi->cslInfo.basicCallStatInfo.collectOrder,
                ptCi->cslInfo.basicCallStatInfo.drbSetupStatNum,
                ptCi->cslInfo.basicCallStatInfo.initialDrbSetupStatNum,
                ptCi->cslInfo.basicCallStatInfo.setupFailCause5qi1StatNum,
                findIndex);

        if(mFamily == STAT_DRB_SETUP)
        {
            uint8_t drbNum = MIN(ptCi->cslInfo.basicCallStatInfo.drbSetupStatNum, MAX_BASIC_CALL_STAT_CSL);
            for (uint8_t idx = 0; idx < drbNum; idx++)
            {
                pDrbSetupCslInfo = &ptCi->cslInfo.basicCallStatInfo.drbSetup[idx];
                VCCB_PRINT_CALL_INFORMATIVE( ptCi, "[CSL][DrbSetup][%u] order/5qi, attempt/success = %u/%u, /%u/%u\n",
                    idx, pDrbSetupCslInfo->collectOrder, pDrbSetupCslInfo->fiveQi,
                    pDrbSetupCslInfo->attempt, pDrbSetupCslInfo->success);
            }
            drbNum = MIN(ptCi->cslInfo.basicCallStatInfo.setupFailCause5qi1StatNum, MAX_BASIC_CALL_STAT_CSL);
            for (uint8_t idx = 0; idx < drbNum; idx++)
            {
                VCCB_PRINT_CALL_INFORMATIVE( ptCi, "[CSL][setupFailCause5Qi_1][%u] = %u\n",
                    idx, ptCi->cslInfo.basicCallStatInfo.setupFailCause5Qi_1[idx]);
            }
        }
        else
        {
            uint8_t drbNum = MIN(ptCi->cslInfo.basicCallStatInfo.initialDrbSetupStatNum, MAX_BASIC_CALL_STAT_CSL);
            for (uint8_t idx = 0; idx < drbNum; idx++)
            {
                pDrbSetupCslInfo = &ptCi->cslInfo.basicCallStatInfo.initialDrbSetup[idx];
                VCCB_PRINT_CALL_INFORMATIVE( ptCi, "[CSL][InitDrbSetup][%u] order/5qi, attempt/success = %u/%u, /%u/%u\n",
                        idx, pDrbSetupCslInfo->collectOrder, pDrbSetupCslInfo->fiveQi,
                        pDrbSetupCslInfo->attempt, pDrbSetupCslInfo->success);
            }
        }
    }
    return;
}

// Mark DRBs under PDU to be released. Collect stats for those DRB on Call Release.
void FnVCCB_SaveDrbRetainCause_ByPduRelReqForAmfRequest(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t pduIdx = 0, pduDrbIdx = 0;
    uint16_t callDrbIdx = 0;
    callDRBInfo_type *ptDi = NULL;
    callPDUSessInfo_type *ptPi = NULL;

    for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        ptPi = &ptCi->pduSess[pduIdx];

        if (ptPi->usage != CI_use) continue;
        if (ptPi->pduSessStatus != S_Release) continue;  // Only Release PDU.

        for (pduDrbIdx = 0; pduDrbIdx < MAX_DRB_PER_PDU_SESS; pduDrbIdx++)
        {
            callDrbIdx = ptPi->drbIndex[pduDrbIdx];  // put Drb Pool's data
            if (callDrbIdx >= MAX_DRB_PER_SA_CALL) continue;

            ptDi = &ptCi->drb[callDrbIdx];
            if (ptDi->usage != CI_use) continue;

            if (ptDi->retainStat.savedEventCategory == No_CallDrb_RetainCategory)
            {
                VLIB_SaveEventForDrbRetainStat(
                    ptCi, ptDi, RetainCategory_PduSessonReleaseByAMF, ptPi->releaseInfo.releaseCause);
            }
        }
    }
}

namespace
{

/**
 * @brief Increment given CSL counter if possible (value less than max).
 *
 * @param cslCounter to increment
 */
void VCCB_NSA_IncrementCslCounterIfPossible(uint8_t &cslCounter)
{
    if (VCCB_MOBILITY_INTRA_NR_STAT_CSL_MAX > cslCounter)
    {
        ++cslCounter;
    }
}

/**
 * @brief Increment CSL counters during SgNB initiated PSCell change.
 *        Related feature: FGR-CC5001 FR740.
 *
 * @param rCi call info
 * @param type to collect
 */
void VCCB_NSA_CslIntraSnPscellChange(callInfo_type &rCi, int type)
{
    AUTO_TRACE_FUNC;

    if (EndcIntraChgAtt == type)
    {
        VCCB_NSA_IncrementCslCounterIfPossible(rCi.cslInfo.cslMobilityInfo_nsa.nsa_intraGnbHoAttCnt);
    }
    else if (EndcIntraChgPrepSucc == type)
    {
        VCCB_NSA_IncrementCslCounterIfPossible(rCi.cslInfo.cslMobilityInfo_nsa.nsa_intraGnbHoPrepCnt);
    }
    else if (EndcIntraChgSucc == type)
    {
        VCCB_NSA_IncrementCslCounterIfPossible(rCi.cslInfo.cslMobilityInfo_nsa.nsa_intraGnbHoExecCnt);
    }
}

/**
 * @brief Increment CSL counters during SgNB initiated SgNB change.
 *        Related feature: FGR-CC5001 FR741.
 *
 * @param rCi call info
 * @param type to collect
 */
void VCCB_NSA_CslInterSnPscellChange(callInfo_type &rCi, int type)
{
    AUTO_TRACE_FUNC;

    if (EndcInterChgSrcAtt == type)
    {
        VCCB_NSA_IncrementCslCounterIfPossible(rCi.cslInfo.cslMobilityInfo_nsa.nsa_interGnbX2HoAttCnt);
    }
    else if (EndcInterChgSrcPrepSucc == type)
    {
        VCCB_NSA_IncrementCslCounterIfPossible(rCi.cslInfo.cslMobilityInfo_nsa.nsa_interGnbX2HoPrepCnt);
    }
    else if (EndcInterChgSrcSucc == type)
    {
        VCCB_NSA_IncrementCslCounterIfPossible(rCi.cslInfo.cslMobilityInfo_nsa.nsa_interGnbX2HoExecCnt);
    }
}

} // namespace

/**
 * @brief FGR-LC0708 Load based PSCell Change for EN-DC (FR60)
 *        Collect either STAT_LB_PSCELL_CHANGE or STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB
 *        depending on HO trigger and FOO setting.
 *
 * @param call info
 * @param type to collect
 */
void VCCB_NSA_PegIntraSnPscellChange(callInfo_type &call, int type)
{
    AUTO_TRACE_FUNC;

    // Select LB or basic family.
    const auto needLbStat =
        ((TRUE == FOO.VF_LoadBasedPscellChangeEndc_UseLbPscellChangeFamily) && (TRUE == call.hoInfo.isLbHo));
    const auto family = (needLbStat ? STAT_LB_PSCELL_CHANGE : STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB);

    MACRO_STAT_PMCC(family, type, &call, 0, 0, 0, 0, 0);

    if (needLbStat)
    {
        if ((LbPscellChange_Att == type) || (LbPscellChange_PrepSucc == type) || (LbPscellChange_Succ == type))
        {
            MACRO_STAT_PMCC(STAT_LB_PSCELL_CHANGE, type, &call, 0, 0, 0, 0, 0);
        }
    }
    else
    {
        MACRO_STAT_PMCC(STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB, type, &call, 0, 0, 0, 0, 0);
    }

    if (TRUE == FOO.VF_SPIDBasedStatistics_ENDC)
    {
        // FGR-CC5001 FR565
        MACRO_STAT_PMCC(STAT_INTRA_SN_PSCELL_CHANGE_PER_GNB_DU_ID_CELL_SPID, type, &call, 0, 0, 0, 0, 0);
    }

    // FGR-CC5001 FR740 - collect CSL.
    VCCB_NSA_CslIntraSnPscellChange(call, type);
}

/**
 * @brief Collect INTER_SN_PSCELL_CHANGE_SRC* family during SgNB initiated SgNB change.
 *
 * @param rCi call info
 * @param type to collect
 */
void VCCB_NSA_PegInterSnPscellChange(callInfo_type &rCi, int type)
{
    AUTO_TRACE_FUNC;

    MACRO_STAT_PMCC(STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB, type, &rCi, 0, 0, 0, 0, 0);

    if (TRUE == FOO.VF_SPIDBasedStatistics_ENDC)
    {
        // FGR-CC5001 FR566
        MACRO_STAT_PMCC(STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB_DU_ID_CELL_SPID, type, &rCi, 0, 0, 0, 0, 0);
    }

    // FGR-CC5001 FR741 - collect CSL.
    VCCB_NSA_CslInterSnPscellChange(rCi, type);
}

/**
 * @brief Collect STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG* family
 *
 * @param call info
 * @param type to collect
 */
void VCCB_NSA_PegSgnbAddIntraLteHoNoSgnbChg(callInfo_type &call, int type)
{
    AUTO_TRACE_FUNC;

    MACRO_STAT_PMCC(STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG, type, &call, 0, 0, 0, 0, 0);
    if ((TRUE == FOO.VF_MultipleOperatorRanSupport) && (TRUE == FOO.VF_SPIDBasedStatistics_ENDC))
    {
        // FGR-CC5001 FR820
        MACRO_STAT_PMCC(STAT_SGNB_ADD_INTRA_LTE_HO_NO_SGNB_CHG_GLOBAL_ID_SPID, type, &call, 0, 0, 0, 0, 0);
    }
}

/**
 * @brief Collect SGNB_ADD_MNHO_INTER_ENB* family
 *
 * @param call info
 * @param type to collect
 */
void VCCB_NSA_PegSgnbAddMnHoInterEnb(callInfo_type &call, int type)
{
    AUTO_TRACE_FUNC;

    MACRO_STAT_PMCC(STAT_SGNB_ADD_MNHO_INTER_ENB, type, &call, 0, 0, 0, 0, 0);
    if ((TRUE == FOO.VF_MultipleOperatorRanSupport) && (TRUE == FOO.VF_SPIDBasedStatistics_ENDC))
    {
        // FGR-CC5001 FR821
        MACRO_STAT_PMCC(STAT_SGNB_ADD_MNHO_INTER_ENB_GLOBAL_ID_SPID, type, &call, 0, 0, 0, 0, 0);
    }
}

/**
 * @brief Collect STAT_SGNB_ADD_MNHO_INTRA_ENB* family
 *
 * @param call info
 * @param type to collect
 */
void VCCB_NSA_PegSgnbAddMnHoIntraEnb(callInfo_type &call, int type)
{
    AUTO_TRACE_FUNC;

    MACRO_STAT_PMCC(STAT_SGNB_ADD_MNHO_INTRA_ENB, type, &call, 0, 0, 0, 0, 0);
    if ((TRUE == FOO.VF_MultipleOperatorRanSupport) && (TRUE == FOO.VF_SPIDBasedStatistics_ENDC))
    {
        // FGR-CC5001 FR822
        MACRO_STAT_PMCC(STAT_SGNB_ADD_MNHO_INTRA_ENB_GLOBAL_ID_SPID, type, &call, 0, 0, 0, 0, 0);
    }
}

/**
 * @brief Collect SGNB_ADD_SGNB_CHG* family
 *
 * @param call info
 * @param type to collect
 */
void VCCB_NSA_PegSgnbAddSgnbChg(callInfo_type &call, int type)
{
    AUTO_TRACE_FUNC;

    MACRO_STAT_PMCC(STAT_SGNB_ADD_SGNB_CHG, type, &call, 0, 0, 0, 0, 0);
    if ((TRUE == FOO.VF_MultipleOperatorRanSupport) && (TRUE == FOO.VF_SPIDBasedStatistics_ENDC))
    {
        // FGR-CC5001 FR823
        MACRO_STAT_PMCC(STAT_SGNB_ADD_SGNB_CHG_GLOBAL_ID_SPID , type, &call, 0, 0, 0, 0, 0);
    }
}

#define VCCB_RETAIN_STAT_COUNT_MAX   255
#define MACRO_INCREASE_DRBRETAIN_STAT_COUNT_FOR_CSL(__count)  \
    do                                                        \
    {                                                         \
        if (__count  < (VCCB_RETAIN_STAT_COUNT_MAX))          \
        {                                                     \
            __count++;                                        \
        }                                                     \
    } while (0)


// Comparator for qsort
// 1: Change Position, 0,-1: No change,
int FnVCCB_QsortDrbRetainCslDescendingOrder(const void *arg1, const void *arg2)
{
    AUTO_TRACE_FUNC;

    auto a = static_cast<const drbRetainCsl_type*>(arg1);
    auto b = static_cast<const drbRetainCsl_type*>(arg2);

    // First Check order
    if (a->collectOrder != b->collectOrder) {
        return (a->collectOrder > b->collectOrder) ? -1 : 1;
    }

    // Second Check 5qi
    if (a->fiveQi != b->fiveQi) {
        return (a->fiveQi < b->fiveQi) ? -1 : 1;
    }

    return 0;
}

uint8_t FnVCCB_GetCslIndexForDrbRetain(callInfo_type *ptCi, int mFamily, uint8_t fiveQi, uint8_t *pUsingExistFiveQi)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_RETAIN_STAT_CSL);
    VALID_E_POINT_CHECK_RET_VAL(pUsingExistFiveQi, MAX_RETAIN_STAT_CSL);

    uint8_t currentNum = 0, idx=0;
    drbRetainCsl_type *pDrbRetainCslInfo = NULL;

    pDrbRetainCslInfo = &ptCi->cslInfo.retainStatInfo.drbRetain[0];
    currentNum = MIN(ptCi->cslInfo.retainStatInfo.drbRetainStatNum, MAX_RETAIN_STAT_CSL);

    // 1. currentNum is 0
    if(currentNum == 0) return currentNum;

    // 2. Find Same 5QI
    drbRetainCsl_type *pFindCslInfo = pDrbRetainCslInfo;
    for(idx=0; idx < currentNum; idx++, pFindCslInfo++)
    {
        if(pFindCslInfo->fiveQi == fiveQi)
        {
            *pUsingExistFiveQi = VCCB_FLAG_ON;
            return idx;
        }
    }

    // 3. if (currentNum < 4), Using currentNum
    if(currentNum < MAX_RETAIN_STAT_CSL)
    {
        return currentNum;
    }
    // 4. if currentNum = 4,
    // 4-1. sort Order(Big),5qi(small) DesendingOrder(4,3,2,1)
    drbRetainCsl_type *pOrderDrbRetainCslInfo = pDrbRetainCslInfo;
    qsort(pOrderDrbRetainCslInfo, currentNum, sizeof(drbRetainCsl_type),
                    FnVCCB_QsortDrbRetainCslDescendingOrder);

    // 4-2. If lowest array has same collectOrder, then check 5QI
    if(pDrbRetainCslInfo[(currentNum-1)].collectOrder == ptCi->cslInfo.retainStatInfo.collectOrder)
    {
        if(pDrbRetainCslInfo[(currentNum-1)].fiveQi < fiveQi)
        {
            // Ignore New 5QI.
            if(DBG->flag.logRetainCsl)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[CSL][DrbRetain] family(%d),5Qi=%d, Ignored.\n", mFamily, fiveQi);
            }
            return MAX_RETAIN_STAT_CSL;
        }
    }

    return static_cast<uint8_t>(currentNum-1); // return 3;
}

void FnVCCB_AddAbnormalVonrFailCauseInRetain(callInfo_type *ptCi, retainExtraInfo_type *pRetainExtraInfo)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pRetainExtraInfo);

    retainStatCslInfo_type  *pRetainCslInfo = &ptCi->cslInfo.retainStatInfo;
    if(pRetainCslInfo->abnRelCause5qiNum < MAX_ABNORMAL_REL_CAUSE_5QI)
    {
        pRetainCslInfo->abnRelCause5Qi_1[pRetainCslInfo->abnRelCause5qiNum] = pRetainExtraInfo->cslInfo.abnRelCause5qi;
        pRetainCslInfo->abnRelCause5qiNum++;
    }
    else
    {
        for(auto idx=1; idx < MAX_ABNORMAL_REL_CAUSE_5QI; idx++)
        {
            pRetainCslInfo->abnRelCause5Qi_1[idx-1] = pRetainCslInfo->abnRelCause5Qi_1[idx];
        }
        pRetainCslInfo->abnRelCause5Qi_1[MAX_ABNORMAL_REL_CAUSE_5QI-1] = pRetainExtraInfo->cslInfo.abnRelCause5qi;
        pRetainCslInfo->abnRelCause5qiNum = MAX_ABNORMAL_REL_CAUSE_5QI;
    }
}

void FnVCCB_CollectStatCSL_DrbRetain(callInfo_type *ptCi, int mFamily, retainExtraInfo_type *pRetainExtraInfo)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pRetainExtraInfo);

    drbRetainCsl_type *pDrbRetainCslInfo = NULL;
    uint8_t findIndex = MAX_RETAIN_STAT_CSL;
    uint8_t usingExistFiveQi = VCCB_FLAG_OFF;
    uint8_t *pDrbRetainNum = NULL;

    // 1. Check Allowed Family
    if(mFamily != STAT_SETUP_DRB_RELEASE)
    {
        return;
    }

    // 2. Get CSL Index
    findIndex = FnVCCB_GetCslIndexForDrbRetain(ptCi, mFamily, pRetainExtraInfo->cslInfo.fiveQi, &usingExistFiveQi);
    if(findIndex >= MAX_RETAIN_STAT_CSL)
    {
        if(DBG->flag.logRetainCsl)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[CSL][DrbRetain] family(%d),5Qi(%u), Invalid findIndex(%u).\n", mFamily, pRetainExtraInfo->cslInfo.fiveQi, findIndex);
        }
        return;
    }

    // 3. Get CSL Data.
    pDrbRetainCslInfo = &ptCi->cslInfo.retainStatInfo.drbRetain[findIndex];
    pDrbRetainNum = &ptCi->cslInfo.retainStatInfo.drbRetainStatNum;

    // 4. Fill CSL Data.
    // 4-1. If New 5QI, then increase DrbSetupNum and initialize count as 0.
    if(usingExistFiveQi == VCCB_FLAG_OFF)
    {
        if(*pDrbRetainNum < MAX_RETAIN_STAT_CSL)
        {
            (*pDrbRetainNum)++;
        }

        // If 5Qi is different, need to initialize count as 0.
        //  case 1:  New 5QI when pDrbRetainNum < 4
        //  case 2:  New 5QI when pDrbRetainNum = 4, and preempted by collectOrder/5qi order.
        pDrbRetainCslInfo->gnbInitAbnormal_Active   = 0;
        pDrbRetainCslInfo->gnbInitAbnormal_InActive = 0;
        pDrbRetainCslInfo->amfInitAbnormal_Active   = 0;
        pDrbRetainCslInfo->amfInitAbnormal_InActive = 0;
        pDrbRetainCslInfo->drbRelTotal = 0;
    }

    // 4-2. collectOrder, fiveQi, Active/Inactive
    pDrbRetainCslInfo->collectOrder = ptCi->cslInfo.retainStatInfo.collectOrder;
    pDrbRetainCslInfo->fiveQi       = pRetainExtraInfo->cslInfo.fiveQi;

    // 4-3. drbRelTotal, if cslAbnormal then collect Active/Inactive
    MACRO_INCREASE_DRBRETAIN_STAT_COUNT_FOR_CSL(pDrbRetainCslInfo->drbRelTotal);
    if(pRetainExtraInfo->cslInfo.cslAbnormal)
    {
        if(pRetainExtraInfo->cslInfo.gnbAmfInitType == GNB_INIT_RETAIN)
        {
            if(pRetainExtraInfo->cslInfo.inSessionFlagByE1)
                MACRO_INCREASE_DRBRETAIN_STAT_COUNT_FOR_CSL(pDrbRetainCslInfo->gnbInitAbnormal_Active);
            else
                MACRO_INCREASE_DRBRETAIN_STAT_COUNT_FOR_CSL(pDrbRetainCslInfo->gnbInitAbnormal_InActive);
        }
        else if(pRetainExtraInfo->cslInfo.gnbAmfInitType == AMF_INIT_RETAIN)
        {
            if(pRetainExtraInfo->cslInfo.inSessionFlagByE1)
                MACRO_INCREASE_DRBRETAIN_STAT_COUNT_FOR_CSL(pDrbRetainCslInfo->amfInitAbnormal_Active);
            else
                MACRO_INCREASE_DRBRETAIN_STAT_COUNT_FOR_CSL(pDrbRetainCslInfo->amfInitAbnormal_InActive);
        }
    }

    // Check VoNR 5QI Abnormal Release Cause.
    if( (pRetainExtraInfo->cslInfo.fiveQi == VONR_5QI) &&
        (pRetainExtraInfo->cslInfo.abnRelCause5qi < Retain_AbnRel_CslMAX))
    {
        FnVCCB_AddAbnormalVonrFailCauseInRetain(ptCi, pRetainExtraInfo);
    }

    if(DBG->flag.logRetainCsl)
    {
        VCCB_PRINT_CALL_INFORMATIVE( ptCi, "[CSL][DrbRetain] collectOrder=%u, retainDrbNum=%u, abnRelCause5qiNum=%u, newIdx=%u\n",
                ptCi->cslInfo.retainStatInfo.collectOrder,
                ptCi->cslInfo.retainStatInfo.drbRetainStatNum,
                ptCi->cslInfo.retainStatInfo.abnRelCause5qiNum,
                findIndex);

        uint8_t drbNum = MIN(ptCi->cslInfo.retainStatInfo.drbRetainStatNum, MAX_RETAIN_STAT_CSL);
        for (uint8_t idx = 0; idx < drbNum; idx++)
        {
            pDrbRetainCslInfo = &ptCi->cslInfo.retainStatInfo.drbRetain[idx];
            VCCB_PRINT_CALL_INFORMATIVE( ptCi, "[CSL][DrbRetain][%u] order/5qi, gnbAct/gngInAct/AmfAct/AmfInact/total = %u/%u, %u/%u/%u/%u/%u\n",
                    idx, pDrbRetainCslInfo->collectOrder, pDrbRetainCslInfo->fiveQi,
                    pDrbRetainCslInfo->gnbInitAbnormal_Active, pDrbRetainCslInfo->gnbInitAbnormal_InActive,
                    pDrbRetainCslInfo->amfInitAbnormal_Active, pDrbRetainCslInfo->amfInitAbnormal_InActive,
                    pDrbRetainCslInfo->drbRelTotal);
        }

        uint8_t causeNum = MIN(ptCi->cslInfo.retainStatInfo.abnRelCause5qiNum, MAX_ABNORMAL_REL_CAUSE_5QI);
        for (uint8_t idx = 0; idx < causeNum; idx++)
        {
            VCCB_PRINT_CALL_INFORMATIVE( ptCi, "[CSL][DrbRetain][abnRelCause5Qi_1][%u] = %u\n",
                    idx, ptCi->cslInfo.retainStatInfo.abnRelCause5Qi_1[idx]);
        }

    }
    return;
}

#define VCCB_UE_RETAIN_STAT_COUNT_MAX 128
#define MACRO_INCREASE_UERETAIN_STAT_COUNT_FOR_CSL(__count)     \
    do  {                                                       \
        if (__count < VCCB_UE_RETAIN_STAT_COUNT_MAX) __count++; \
    } while (0)

void FnVCCB_CollectStatCSL_UeRetain(callInfo_type *ptCi, int mFamily, retainExtraInfo_type *pRetainExtraInfo)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pRetainExtraInfo);

    ueRetainCsl_type *pUeRetainCslInfo = &ptCi->cslInfo.retainStatInfo.ueRetain;

    // 1. Check Allowed Family
    if (mFamily != STAT_SETUP_UECONTEXT_RELEASE)
        return;

    // 2. Fill CSL Data
    // 2-1. if first request, set it as '0'
    if (pUeRetainCslInfo->ueRelTotal == 0xFF)
    {
        pUeRetainCslInfo->gnbInitAbnormal_Active = 0;
        pUeRetainCslInfo->gnbInitAbnormal_InActive = 0;
        pUeRetainCslInfo->amfInitAbnormal_Active = 0;
        pUeRetainCslInfo->amfInitAbnormal_InActive = 0;
        pUeRetainCslInfo->ueRelTotal = 0;
    }

    // 2-2. collect ueRelTotal
    //      collect Active/Inactive if cslAbnormal
    MACRO_INCREASE_UERETAIN_STAT_COUNT_FOR_CSL(pUeRetainCslInfo->ueRelTotal);
    if (pRetainExtraInfo->cslInfo.cslAbnormal)
    {
        if (pRetainExtraInfo->cslInfo.gnbAmfInitType == GNB_INIT_RETAIN)
        {
            if (pRetainExtraInfo->cslInfo.inSessionFlagByE1)
            {
                MACRO_INCREASE_UERETAIN_STAT_COUNT_FOR_CSL(pUeRetainCslInfo->gnbInitAbnormal_Active);
            }
            else
            {
                MACRO_INCREASE_UERETAIN_STAT_COUNT_FOR_CSL(pUeRetainCslInfo->gnbInitAbnormal_InActive);
            }
        }
        else if (pRetainExtraInfo->cslInfo.gnbAmfInitType == AMF_INIT_RETAIN)
        {
            if (pRetainExtraInfo->cslInfo.inSessionFlagByE1)
            {
                MACRO_INCREASE_UERETAIN_STAT_COUNT_FOR_CSL(pUeRetainCslInfo->amfInitAbnormal_Active);
            }
            else
            {
                MACRO_INCREASE_UERETAIN_STAT_COUNT_FOR_CSL(pUeRetainCslInfo->amfInitAbnormal_InActive);
            }
        }
    }

    if (DBG->flag.logRetainCsl)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[CSL][UeRetain] gnbAct/gnbInAct/AmfAct/AmfInAct/total = %u/%u/%u/%u/%u\n",
            pUeRetainCslInfo->gnbInitAbnormal_Active, pUeRetainCslInfo->gnbInitAbnormal_InActive,
            pUeRetainCslInfo->amfInitAbnormal_Active, pUeRetainCslInfo->amfInitAbnormal_InActive,
            pUeRetainCslInfo->ueRelTotal);
    }
}

void FnVCCB_RearrangeCslCollectOrder_RetainStat(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t currentNum = 0;
    drbRetainCsl_type *pDrbRetainCslInfo = NULL;
    uint8_t prevOrder, newOrder, idx;

    // Rearrange is needed for only STAT_DRB_SETUP. (STAT_INITIAL_DRB_SETUP_DU_ID is not needed)
    pDrbRetainCslInfo = &ptCi->cslInfo.retainStatInfo.drbRetain[0];
    currentNum = MIN(ptCi->cslInfo.retainStatInfo.drbRetainStatNum, MAX_RETAIN_STAT_CSL);

    if(currentNum == 0)
    {
        ptCi->cslInfo.retainStatInfo.collectOrder = static_cast<uint8_t>(currentNum+1);
        return;
    }
    else if(currentNum == 1)
    {
        pDrbRetainCslInfo->collectOrder = currentNum;
        ptCi->cslInfo.retainStatInfo.collectOrder = static_cast<uint8_t>(currentNum+1);
        return;
    }

    // Sorting: 4, 3, 2, 1
    drbRetainCsl_type *pOrderDrbRetainCslInfo = pDrbRetainCslInfo;
    qsort(pOrderDrbRetainCslInfo, currentNum, sizeof(drbRetainCsl_type),
                    FnVCCB_QsortDrbRetainCslDescendingOrder);

    // Rearrange collectOrder. // currentNum->(currentNum-1)->(currentNum-2)->(currentNum-3)
    prevOrder = pDrbRetainCslInfo->collectOrder;
    newOrder = currentNum;
    for(idx = 0; idx < currentNum; idx++, pDrbRetainCslInfo++)
    {
        if(idx == 0)
        {
            // Update New Order.
            pDrbRetainCslInfo->collectOrder = newOrder;
            continue;
        }

        if(pDrbRetainCslInfo->collectOrder != prevOrder)
        {
            // Save prevOrder
            prevOrder = pDrbRetainCslInfo->collectOrder;
            // Get New Order
            if(newOrder > 0) newOrder--;
        }
        // Update New Order
        pDrbRetainCslInfo->collectOrder = newOrder;
    }

    ptCi->cslInfo.retainStatInfo.collectOrder = static_cast<uint8_t>(currentNum+1);
    return;
}

#ifdef IPC_TEST
#define UPDATE_MOBILITY_CSL_TIME(sumTimeTotal, updateValue) \
    do                                                      \
    {                                                       \
        float inputValue = sumTimeTotal;                    \
        inputValue += 100;                                  \
        sumTimeTotal = static_cast<uint16_t>(inputValue);   \
    } while (0)
#else
#define UPDATE_MOBILITY_CSL_TIME(sumTimeTotal, updateValue) \
    do                                                      \
    {                                                       \
        float inputValue = sumTimeTotal;                    \
        inputValue += updateValue;                          \
        sumTimeTotal = static_cast<uint16_t>(inputValue);   \
    } while (0)
#endif

#define PRINT_STAT_CSL_TIME_INFO(rCall, prefix, sumTimeTotal, cnt) \
    do { \
        if (DBG->flag.logHoStatCsl) { \
            VCCB_PRINT_CALL_INFORMATIVE(&rCall, "(CSL)(hoTime) %s.sumTimeTotal:%u %s.cnt:%u \n", \
                    prefix, sumTimeTotal, prefix, cnt); \
        } \
    } while (0)

void FnVCCB_CollectStatCSL_HOTIME(callInfo_type *ptCi, int mFamily, int mType, float updateValue)
{
    AUTO_TRACE_FUNC;

    if (ptCi == NULL || mFamily != STAT_HO_TIME)
    {
        return;
    }

    switch (mType)
    {
        case IntraGnb_HoTimeAvg:
        case IntraGnb_HoTimeAvg_RedCap:
            /*
                26A FGR-MC1008 HO TIME CSL algorithm changed. update will be done at VHCM_FinalizeHandover_UpdateIntraGnbConfiguration_HoTimeCSL
                ~25B : collect for source cell
                26A~ : collect for target cell
            */
            break;

        case InterXn_HoTimeAvg:
        case InterXn_HoTimeAvg_RedCap:
            UPDATE_MOBILITY_CSL_TIME(ptCi->cslInfo.hoInfo.interGnbXnHo.sumTimeTotal, updateValue);
            VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(ptCi->cslInfo.hoInfo.interGnbXnHo.cnt);
            PRINT_STAT_CSL_TIME_INFO(*ptCi, "interGnbXnHo", ptCi->cslInfo.hoInfo.interGnbXnHo.sumTimeTotal, ptCi->cslInfo.hoInfo.interGnbXnHo.cnt);
            if (ptCi->hoInfo.isVonrCall == TRUE) // Additional Stat
            {
                UPDATE_MOBILITY_CSL_TIME(ptCi->cslInfo.hoInfo.interGnbXnVonrHo.sumTimeTotal, updateValue);
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(ptCi->cslInfo.hoInfo.interGnbXnVonrHo.cnt);
                PRINT_STAT_CSL_TIME_INFO(*ptCi, "interGnbXnVonrHo", ptCi->cslInfo.hoInfo.interGnbXnVonrHo.sumTimeTotal, ptCi->cslInfo.hoInfo.interGnbXnVonrHo.cnt);
            }
            break;

        case InterNg_HoTimeAvg:
        case InterNg_HoTimeAvg_RedCap:
            UPDATE_MOBILITY_CSL_TIME(ptCi->cslInfo.hoInfo.interGnbNgHo.sumTimeTotal, updateValue);
            VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(ptCi->cslInfo.hoInfo.interGnbNgHo.cnt);
            PRINT_STAT_CSL_TIME_INFO(*ptCi, "interGnbNgHo", ptCi->cslInfo.hoInfo.interGnbNgHo.sumTimeTotal, ptCi->cslInfo.hoInfo.interGnbNgHo.cnt);
            if (ptCi->hoInfo.isVonrCall == TRUE) // Additional Stat
            {
                UPDATE_MOBILITY_CSL_TIME(ptCi->cslInfo.hoInfo.interGnbNgVonrHo.sumTimeTotal, updateValue);
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(ptCi->cslInfo.hoInfo.interGnbNgVonrHo.cnt);
                PRINT_STAT_CSL_TIME_INFO(*ptCi, "interGnbNgVonrHo", ptCi->cslInfo.hoInfo.interGnbNgVonrHo.sumTimeTotal, ptCi->cslInfo.hoInfo.interGnbNgVonrHo.cnt);
            }
            break;

        case InterRatIn_HoTimeAvg:
        case InterRatIn_HoTimeAvg_RedCap:
            UPDATE_MOBILITY_CSL_TIME(ptCi->cslInfo.hoInfo.incomingEuNrHo.sumTimeTotal, updateValue);
            VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(ptCi->cslInfo.hoInfo.incomingEuNrHo.cnt);
            PRINT_STAT_CSL_TIME_INFO(*ptCi, "incomingEuNrHo", ptCi->cslInfo.hoInfo.incomingEuNrHo.sumTimeTotal, ptCi->cslInfo.hoInfo.incomingEuNrHo.cnt);
            if (ptCi->hoInfo.isVonrCall == TRUE) // Additional Stat
            {
                UPDATE_MOBILITY_CSL_TIME(ptCi->cslInfo.hoInfo.incomingEuNrVonrHo.sumTimeTotal, updateValue);
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(ptCi->cslInfo.hoInfo.incomingEuNrVonrHo.cnt);
                PRINT_STAT_CSL_TIME_INFO(*ptCi, "incomingEuNrVonrHo", ptCi->cslInfo.hoInfo.incomingEuNrVonrHo.sumTimeTotal, ptCi->cslInfo.hoInfo.incomingEuNrVonrHo.cnt);
            }
            break;

        case InterRatOut_VoNR_HoTimeAvg:
        case InterRatOut_VoNR_HoTimeAvg_RedCap:
            UPDATE_MOBILITY_CSL_TIME(ptCi->cslInfo.hoInfo.outNrEuVonrHo.sumTimeTotal, updateValue);
            VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(ptCi->cslInfo.hoInfo.outNrEuVonrHo.cnt);
            PRINT_STAT_CSL_TIME_INFO(*ptCi, "outNrEuVonrHo", ptCi->cslInfo.hoInfo.outNrEuVonrHo.sumTimeTotal, ptCi->cslInfo.hoInfo.outNrEuVonrHo.cnt);
            break;

        case InterRatOut_EPSFallback_HoTimeAvg:
        case InterRatOut_EPSFallback_HoTimeAvg_RedCap:
            UPDATE_MOBILITY_CSL_TIME(ptCi->cslInfo.hoInfo.outNrEuEpsHo.sumTimeTotal, updateValue);
            VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(ptCi->cslInfo.hoInfo.outNrEuEpsHo.cnt);
            PRINT_STAT_CSL_TIME_INFO(*ptCi, "outNrEuEpsHo", ptCi->cslInfo.hoInfo.outNrEuEpsHo.sumTimeTotal, ptCi->cslInfo.hoInfo.outNrEuEpsHo.cnt);
            break;

        default:
            VCCB_PRINT_CALL_COMMENT(ptCi, "Unknown mType:%d updateValue:%.2f mFamily:%d \n", mType, (double)updateValue, mFamily);
            break;
    }
}

/**
 * @brief Updates handover information statistics for the given call.
 * @param rCall Reference to the call information containing handover data
 * @param cnt Reference to the handover count counter to be incremented
 * @param sumTimeTotal Reference to the total handover time sum to be updated
 */
void FnVCCB_UpdateHandoverInfoCsl(callInfo_type &rCall, uint8_t &cnt, uint16_t &sumTimeTotal)
{
#ifdef IPC_TEST
    (void)rCall;
    const float HoExecTime = 100.0;
#else
    const float HoExecTime = FnVCCB_GetTimeDiffForHO(rCall.hoInfo.HOtHoAck, rCall.hoInfo.HOtReconfigCmpl);
#endif

    uint32_t newSumTimeTotal = static_cast<uint32_t>(sumTimeTotal) + static_cast<uint32_t>(HoExecTime);
    if (((cnt + 1) <= VCCB_HANDOVER_INFO_CSL_COUNT_MAX) && (newSumTimeTotal <= VCCB_HANDOVER_INFO_CSL_TIME_MAX))
    {
        cnt++;
        sumTimeTotal = static_cast<uint16_t>(newSumTimeTotal);
    }
}

void FnVCCB_CollectDrbSetupTime(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    uint16_t callDrbIdx = 0;

    if ((ptCi->callType != E_CALLTYPE_SA) || IS_NRDC_SN(ptCi))
    {
        return;
    }

    for (callDrbIdx = 0; callDrbIdx < MAX_DRB_PER_SA_CALL; callDrbIdx++)
    {
        if (CI_use != ptCi->drb[callDrbIdx].usage) continue;

        callDRBInfo_type* ptDi = &ptCi->drb[callDrbIdx];

        if (ptDi->drbStatus != S_Modify) continue;

        if (ptDi->firstReqStatusInThisProcedure != S_Setup) continue;

        if (ptDi->drbConnStat.drbSetupTime.isRunning)
        {
            FnVCCB_CalculateDrbSetupTime(ptCi, ptDi, CAL_STOP);
        }
    }
}

void FnVCCB_CollectStatCSL_RrcSetupTime(callInfo_type *ptCi, float timeElapsedInMilliSecond)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!(FOO.VF_CallSummaryLogs_KPI))
    {
        if(DBG->flag.logBasicStatCsl)
        {
            VCCB_PRINT_CALL_INFORMATIVE( ptCi, "[CSL][RRC_SETUP_TIME] F_CallSummaryLogs_KPI is OFF. => No Collect\n");
        }
        return;
    }

    auto &rBasicCallStatInfo = ptCi->cslInfo.basicCallStatInfo;

    uint16_t prevRrcSetupTimeCount = rBasicCallStatInfo.rrcSetupTime;

    if (timeElapsedInMilliSecond > VCCB_CSL_RRC_SETUP_TIME_MAX)
    {
        rBasicCallStatInfo.rrcSetupTime = VCCB_CSL_RRC_SETUP_TIME_MAX;
    }
    else
    {
        rBasicCallStatInfo.rrcSetupTime = static_cast<uint16_t>(timeElapsedInMilliSecond);
    }

    if (DBG->flag.logBasicStatCsl)
    {
        VCCB_PRINT_CALL_INFORMATIVE( ptCi, "[CSL][RRC_SETUP_TIME] input=%f, rrcSetupTime=(%u->%u)\n",
                static_cast<double>(timeElapsedInMilliSecond),
                prevRrcSetupTimeCount,
                rBasicCallStatInfo.rrcSetupTime);
    }
}

#ifdef IPC_TEST
#define GET_BASIC_DRB_CSL_TIME(newTime, elapsedTime) \
    do                                               \
    {                                                \
        newTime = 10;                                \
    } while (0)
#else
#define GET_BASIC_DRB_CSL_TIME(newTime, elapsedTime)        \
    do                                                      \
    {                                                       \
        if (elapsedTime > VCCB_CSL_DRB_SETUP_TIME_MAX)      \
        {                                                   \
            newTime = VCCB_CSL_DRB_SETUP_TIME_MAX;          \
        }                                                   \
        else                                                \
        {                                                   \
            newTime = static_cast<uint16_t>(elapsedTime);   \
        }                                                   \
    } while (0)
#endif

void FnVCCB_CollectStatCSL_DrbSetupTime(callInfo_type *ptCi, float timeElapsedInMilliSecond)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!(FOO.VF_CallSummaryLogs_KPI))
    {
        if(DBG->flag.logBasicStatCsl)
        {
            VCCB_PRINT_CALL_INFORMATIVE( ptCi, "[CSL][DRB_SETUP_TIME] F_CallSummaryLogs_KPI is OFF. => No Collect\n");
        }
        return;
    }

    auto &rBasicCallStatInfo = ptCi->cslInfo.basicCallStatInfo;

    uint16_t prevDrbSetupTimeCount = rBasicCallStatInfo.drbSetupTimeCount;
    uint16_t prevDrbSetupTimeTotal = rBasicCallStatInfo.drbSetupTimeTotal;

    // If first Request, Set it as 0
    if (rBasicCallStatInfo.drbSetupTimeCount == 0xFF)
    {
        rBasicCallStatInfo.drbSetupTimeCount = 0;
        rBasicCallStatInfo.drbSetupTimeTotal = 0;
    }

    if (rBasicCallStatInfo.drbSetupTimeCount < VCCB_CSL_DRB_SETUP_TIME_CNT_MAX)
    {
        uint16_t newTime  = 0;
        GET_BASIC_DRB_CSL_TIME(newTime, timeElapsedInMilliSecond);

        rBasicCallStatInfo.drbSetupTimeCount++;

        if (static_cast<uint32_t>(rBasicCallStatInfo.drbSetupTimeTotal) + static_cast<uint32_t>(newTime) <= static_cast<uint32_t>(VCCB_CSL_DRB_SETUP_TIME_MAX))
        {
            rBasicCallStatInfo.drbSetupTimeTotal = static_cast<uint16_t>(rBasicCallStatInfo.drbSetupTimeTotal + newTime);
        }
        else
        {
            rBasicCallStatInfo.drbSetupTimeTotal = VCCB_CSL_DRB_SETUP_TIME_MAX;
        }
    }

    if (DBG->flag.logBasicStatCsl)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[CSL][DRB_SETUP_TIME] input=%f, count=(%u->%u),TotalTime=(%u->%u)\n",
                static_cast<double>(timeElapsedInMilliSecond),
                prevDrbSetupTimeCount,
                rBasicCallStatInfo.drbSetupTimeCount,
                prevDrbSetupTimeTotal,
                rBasicCallStatInfo.drbSetupTimeTotal);
    }
}

void FnVCCB_CollectPmccAdditionalServiceBorderAttForIratHo(
    callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int pmType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pPmMultiCollect);

    // Check Service Border
    if (ptCi->hoInfo.serviceBorderFlag == FALSE) return;

    auto InterRat_HoOut_NonVoNR_Service_Border_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_Att:
                return InterSysLTE_Out_NonVoNR_Service_Border_Att;
            case InterSysLTE_Out_PrepSucc:
                return InterSysLTE_Out_NonVoNR_Service_Border_PrepSucc;
            case InterSysLTE_Out_Succ:
                return InterSysLTE_Out_NonVoNR_Service_Border_Succ;
            case InterSysLTE_Out_HandoverCancel:
                return InterSysLTE_Out_NonVoNR_Service_Border_HandoverCancel;
            case InterSysLTE_Out_RRE:
                return InterSysLTE_Out_NonVoNR_Service_Border_RRE;

            default:
                return -1;
        }
    };

    auto InterRat_HoOut_VoNR_Service_Border_mapping = [pmType]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_Att:
                return InterSysLTE_Out_VoNR_Service_Border_Att;
            case InterSysLTE_Out_PrepSucc:
                return InterSysLTE_Out_VoNR_Service_Border_PrepSucc;
            case InterSysLTE_Out_Succ:
                return InterSysLTE_Out_VoNR_Service_Border_Succ;
            case InterSysLTE_Out_HandoverCancel:
                return InterSysLTE_Out_VoNR_Service_Border_HandoverCancel;
            case InterSysLTE_Out_RRE:
                return InterSysLTE_Out_VoNR_Service_Border_RRE;

            default:
                return -1;
        }
    };

    auto InterRat_HoFreqOut_NonVoNR_Service_Border_mapping = [pmType, ptCi]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_Att_FREQ_OUT:
                return InterSysLTE_Out_NonVoNR_Service_Border_Att_FREQ_OUT;
            case InterSysLTE_Out_PrepSucc_FREQ_OUT:
                return InterSysLTE_Out_NonVoNR_Service_Border_PrepSucc_FREQ_OUT;
            case InterSysLTE_Out_Succ_FREQ_OUT:
                return InterSysLTE_Out_NonVoNR_Service_Border_Succ_FREQ_OUT;
            case InterSysLTE_Out_HandoverCancel_FREQ_OUT:
                return InterSysLTE_Out_NonVoNR_Service_Border_HandoverCancel_FREQ_OUT;
            case InterSysLTE_Out_RRE_FREQ_OUT:
                return InterSysLTE_Out_NonVoNR_Service_Border_RRE_FREQ_OUT;

            default:
                return -1;
        }
    };

    auto InterRat_HoFreqOut_VoNR_Service_Border_mapping = [pmType, ptCi]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_Att_FREQ_OUT:
                return InterSysLTE_Out_VoNR_Service_Border_Att_FREQ_OUT;
            case InterSysLTE_Out_PrepSucc_FREQ_OUT:
                return InterSysLTE_Out_VoNR_Service_Border_PrepSucc_FREQ_OUT;
            case InterSysLTE_Out_Succ_FREQ_OUT:
                return InterSysLTE_Out_VoNR_Service_Border_Succ_FREQ_OUT;
            case InterSysLTE_Out_HandoverCancel_FREQ_OUT:
                return InterSysLTE_Out_VoNR_Service_Border_HandoverCancel_FREQ_OUT;
            case InterSysLTE_Out_RRE_FREQ_OUT:
                return InterSysLTE_Out_VoNR_Service_Border_RRE_FREQ_OUT;

            default:
                return -1;
        }
    };

    // SVR25B FGR-MC1021 FR303
    auto InterRat_HoFreqOut_NonVoNR_Service_Border_RedCap_mapping = [pmType, ptCi]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_Att_RedCap:
                return InterSysLTE_Out_NonVoNR_Service_Border_Att_RedCap;
            case InterSysLTE_Out_PrepSucc_RedCap:
                return InterSysLTE_Out_NonVoNR_Service_Border_PrepSucc_RedCap;
            case InterSysLTE_Out_Succ_RedCap:
                return InterSysLTE_Out_NonVoNR_Service_Border_Succ_RedCap;
            case InterSysLTE_Out_HandoverCancel_RedCap:
                return InterSysLTE_Out_NonVoNR_Service_Border_HandoverCancel_RedCap;
            case InterSysLTE_Out_RRE_RedCap:
                return InterSysLTE_Out_NonVoNR_Service_Border_RRE_RedCap;

            default:
                return -1;
        }
    };

    // SVR25B FGR-MC1021 FR303
    auto InterRat_HoFreqOut_VoNR_Service_Border_RedCap_mapping = [pmType, ptCi]() -> int
    {
        switch (pmType)
        {
            case InterSysLTE_Out_Att_RedCap:
                return InterSysLTE_Out_VoNR_Service_Border_Att_RedCap;
            case InterSysLTE_Out_PrepSucc_RedCap:
                return InterSysLTE_Out_VoNR_Service_Border_PrepSucc_RedCap;
            case InterSysLTE_Out_Succ_RedCap:
                return InterSysLTE_Out_VoNR_Service_Border_Succ_RedCap;
            case InterSysLTE_Out_HandoverCancel_RedCap:
                return InterSysLTE_Out_VoNR_Service_Border_HandoverCancel_RedCap;
            case InterSysLTE_Out_RRE_RedCap:
                return InterSysLTE_Out_VoNR_Service_Border_RRE_RedCap;

            default:
                return -1;
        }
    };

    int serviceBorderTypeId = -1;

    switch (mFamily)
    {
        case STAT_HO_EUTRAN_OUT:
        case STAT_HO_EUTRAN_OUT_SERVICE_TYPE:
            if (ptCi->hoInfo.isVonrCall == TRUE)
                serviceBorderTypeId = InterRat_HoOut_VoNR_Service_Border_mapping();
            else
                serviceBorderTypeId = InterRat_HoOut_NonVoNR_Service_Border_mapping();
            break;
        case STAT_HO_EUTRAN_FREQ_OUT:
        case STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE:
            if (ptCi->hoInfo.isVonrCall == TRUE)
                serviceBorderTypeId = InterRat_HoFreqOut_VoNR_Service_Border_mapping();
            else
                serviceBorderTypeId = InterRat_HoFreqOut_NonVoNR_Service_Border_mapping();
            break;
        case STAT_HO_EUTRAN_FREQ_OUT_REDCAP:  // SVR25B FGR-MC1021 FR303
            if (ptCi->hoInfo.isVonrCall == TRUE)
                serviceBorderTypeId = InterRat_HoFreqOut_VoNR_Service_Border_RedCap_mapping();
            else
                serviceBorderTypeId = InterRat_HoFreqOut_NonVoNR_Service_Border_RedCap_mapping();
            break;

        default:
            break;
    }

    if (serviceBorderTypeId != -1)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "%s mFamily:%d mActualFamily:%d voNrTypeId:%d \n", __func__, mFamily,
            mActualFamily, serviceBorderTypeId);
        MACRO_STAT_PMCC_ADD_ITEM(pPmMultiCollect->updateItemUintArr, pPmMultiCollect->numOfItem, mActualFamily,
            serviceBorderTypeId, PME_LIB_CC, 1);
    }
}

bool FnVCCB_IsPartialFailedDrbStatCondition(callInfo_type *ptCi, callDRBInfo_type *ptDi, enumHoStatType type)
{
    if (ptCi == NULL || ptDi == NULL) return false;
    if (type != HO_PrepFail_E1Fail && type != HO_PrepFail_F1Fail) return false;

    if (IS_INTRA_GNB_HO())
    {
        if (type != HO_PrepFail_F1Fail) return false;

        if (GET_NEED_RELEASE_FAIL_DRB_FROM_AMF(ptDi) != TRUE) return false;

        // if (ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_INTRA_GNB_INTRA_DU_HANDOVER) // Intra DU
        // {
        //     if (ptDi->needToReleaseAmfByF1Partial_intraGnbOnlyUsed != true) return false;
        // }
        // else // Inter DU
        // {
        //     if (ptDi->drbStatus != S_Modify || ptDi->needToReconfigE1ByF1Fail != TRUE ||
        //     ptDi->needToReleaseAmfByF1Partial_intraGnbOnlyUsed != true) return false;
        // }
    }
    else
    {
        if (ptDi->drbStatus != S_FailToSetup) return false;

        // if (type == HO_PrepFail_F1Fail)
        // {
        //     if (ptDi->drbStatus != S_FailToSetup || ptDi->needToReconfigE1ByF1Fail != TRUE) return false;
        // }
        // else // HO_PrepFail_E1Fail
        // {
        //     if (ptDi->drbStatus != S_FailToSetup) return false;
        // }
    }

    return true;
}

/**
 * @brief This API is designed to obtain the service type values for failed DRBs in the HO target
 *        at the Handover preparation stage when performing handover.
 *        Don't use it for other purposes.
 *
 * @param call info
 * @param type
 * @return void
 */
void FnVCCB_GetHandInFailedDrbsServiceType(callInfo_type *ptCi, enumHoStatType type)
{
    int16_t status = GOOD;
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    if (not FnVCCB_IsStatSaHandoverIncoming(ptCi)) return;

    int mType = getTypeFromIn(ptCi, type);
    if (mType == -1)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "%s wrong enumHoStatType:%d \n", __func__, type);
        return;
    }

    STAT_PM_FAMILY_ID_TYPE collectFamilyId = FnVCCB_GetSaHandInServiceTypeFamilyId(ptCi);

    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];
    if (not FnVCCB_IsSupportServiceTypeYang(collectFamilyId, pGnb)) return;

    VCCB_PRINT_CALL_HO_SERVICE_TYPE(
        ptCi, "[HANDIN PARTIAL] %s mFamily:%d mType:%d \n", __func__, collectFamilyId, mType);

    std::set<uint32_t> serviceTypelist;

    if (CFG->acpfInfo.serviceTypeList[0].usage == CI_use) serviceTypelist.insert(0);

    callDRBInfo_type *ptDi;
    for (uint32_t drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        ptDi = &ptCi->drb[drbIdx];

        if (ptDi->usage != CI_use) continue;

        if (IS_NRDC_SN(ptCi))
        {
            if (ptDi->bearerType.termPoint == TermPoint_Mn) continue;
        }
        else
        {
            if (ptDi->bearerType.termPoint == TermPoint_Sn) continue;
        }

        if (FnVCCB_IsPartialFailedDrbStatCondition(ptCi, ptDi, type) != true) continue;

        // Debug Info
        if (ptDi->drbStatus == S_FailToSetup)
        {
            VCCB_PRINT_CALL_HO_SERVICE_TYPE(ptCi, "%s dRBId:%u S_FailToSetup \n", __func__, ptDi->dRBId);
        }

        if (GET_NEED_RELEASE_FAIL_DRB_FROM_AMF(ptDi))
        {
            VCCB_PRINT_CALL_HO_SERVICE_TYPE(
                ptCi, "%s dRBId:%u needToReleaseAmfByF1Partial \n", __func__, ptDi->dRBId);
        }

        status = FnVCCB_GetDrbServiceType(ptCi, ptDi, serviceTypelist);
        if (status == ERROR)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "%s FnVCCB_GetDrbServiceType ERROR\n", __func__);
        }
    }

    if (serviceTypelist.empty()) return;

    VccbPmKey_type pmKey;
    memset(&pmKey, 0, sizeof(pmKey));
    VccbPmMultiCollect_type pmMultiCollect;
    FnVCCB_InitPmMultiCollect(&pmMultiCollect, PME_LIB_CC);

    int typeId_attempt = GetAttTypeId(ptCi, collectFamilyId, mType);
    int mActualFamily = collectFamilyId;

    // Attempt
    MACRO_STAT_PMCC_ADD_ITEM(
        pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily, typeId_attempt, PME_LIB_CC, 1);

    // Preparation Fail
    MACRO_STAT_PMCC_ADD_ITEM(
        pmMultiCollect.updateItemUintArr, pmMultiCollect.numOfItem, mActualFamily, mType, PME_LIB_CC, 1);

    // Index
    FnVccb_FillPlmnGnbIdDuIdCellIdStatIndex(
        ptCi, &pmKey, true);  // Index (1 ~ 4) : PLMN, gNB_ID, gNB_DU_ID, CellIdentity
    for (const auto &serviceType : serviceTypelist)
    {
        pmKey.keyList[VCCB_PMKEY_INDEX5] = serviceType;  // ServiceType_SA (5)
        VCCB_PRINT_CALL_HO_SERVICE_TYPE(ptCi, "[ServiceType] mFamily:%s serviceType:%u \n",
            FnVCCB_GetServiceTypeFamily(mActualFamily), serviceType);
        CollectPmStatistics(ptCi, (unsigned)mActualFamily, (unsigned)mActualFamily, &pmMultiCollect,
            pmMultiCollect.updateItemUintArr, pmKey, TRUE);
    }
}

void FnVCCB_StatRedirectionServiceType(callInfo_type *ptCi, STAT_PM_FAMILY_ID_TYPE mFamily, int mType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];

    if (not FnVCCB_IsSupportServiceTypeYang(mFamily, pGnb)) return;

    FnVCCB_LibStatPmCC_Mobility(mFamily, mType, ptCi, 0, __func__);
}

void FnVCCB_PeriodicStat_SaCellDrbConnPlmnSlice(VccbGnbInfo_type *pGnb, VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pGnb);
    VALID_E_POINT_CHECK_VOID(pCell);

    uint32_t uePlmnKey = 0;  // (MCC * 1000) + MNC  = 0~999999
    plmnId_type plmnToConvertBuff;
    uint16_t cellIdentity;

    cellIdentity = pCell->cellIdentity;
    uint32_t cellDrbCountSliceForRrcCon = 0, cellDrbCountSliceForRrcInact = 0;
    uint32_t sstSdVal = 0;

    for (uint8_t sliceDbIdx = 0; sliceDbIdx < MAX_SLICE_STAT_YANG; sliceDbIdx++)
    {
        if (pGnb->sliceStatCounterList[sliceDbIdx].usage != EQUIP) continue;

        uint8_t plmnIndex = pGnb->sliceStatCounterList[sliceDbIdx].plmnIndex;
        if (plmnIndex < MAX_PLMN_INDEX)
        {
            const plmnIdInfo_type *pGnbPlmn = &pGnb->plmnIndexInfo[plmnIndex];
            if (pGnbPlmn->shmStatus != EQUIP) continue;

            // UE_PLMN
            plmnToConvertBuff.longId = pGnbPlmn->longId;
            VLIB_ConvertPlmnIdToPlmnValue(&plmnToConvertBuff.s2, &uePlmnKey);

            cellDrbCountSliceForRrcCon   = pCell->cfg.assignedDrbCountWithPlmnSliceRrcConn[sliceDbIdx];
            cellDrbCountSliceForRrcInact = pCell->cfg.assignedDrbCountWithPlmnSliceRrcInact[sliceDbIdx];
            sstSdVal                     = pGnb->sliceStatCounterList[sliceDbIdx].sNssai.sstSd;

            if (uePlmnKey != 0)
            {
                MACRO_STAT_PMGAUGE(STAT_DRB_CONN_INFO_PLMN_SNSSAI, DrbConnNoAvgPlmn, NULL, (float)cellDrbCountSliceForRrcCon,
                    pCell->gnbNum, cellIdentity, uePlmnKey, sstSdVal);
                MACRO_STAT_PMGAUGE(STAT_DRB_CONN_INFO_PLMN_SNSSAI, DrbInactNoAvgPlmn, NULL, (float)cellDrbCountSliceForRrcInact,
                    pCell->gnbNum, cellIdentity, uePlmnKey, sstSdVal);
                MACRO_STAT_PMGAUGE(STAT_DRB_CONN_INFO_PLMN_SNSSAI, DrbConnInactNoAvgPlmn, NULL,
                    (float)(cellDrbCountSliceForRrcCon + cellDrbCountSliceForRrcInact),
                    pCell->gnbNum, cellIdentity, uePlmnKey, sstSdVal);
            }
        }
    }
}
