#include <map>
#include <string>
#include "PM_TYPE_ID.h"
#include "cause_call_5g.h"
#include "ComCslCauseMap.h"

typedef std::map<cause_t, pmCause_t> pmCauseMap_type;

static pmCauseMap_type& wrapperCauseMap()
{
    static pmCauseMap_type causeMap;
    return causeMap;
}

nr_csl_cause_error_e nr_csl_du_id_hex_cause_make_sacp_nrdc_sn_map(void)
{
    wrapperCauseMap()[CAUSE_CRR_SUM] = HEXA_SAACPF_NRDC_CrrSum_DUID;
    wrapperCauseMap()[CAUSE_NO_FAULT_DU_ID] = HEXA_SAACPF_NRDC_NoFault_DUID;
    wrapperCauseMap()[CauseCpInternalTmOutRrcConnectionReconfig] = HEXA_SAACPF_NRDC_CauseInternalTmOutRrcConnectionReconfig_DUID;
    wrapperCauseMap()[CauseCpInternalTmOutF1UeContextSetup] = HEXA_SAACPF_NRDC_CauseInternalTmOutF1UeContextSetup_DUID;
    wrapperCauseMap()[CauseCpInternalTmOutE1BearerSetup] = HEXA_SAACPF_NRDC_CauseInternalTmOutE1BearerSetup_DUID;
    wrapperCauseMap()[CauseCpInternalTmOutE1BearerContextModification] =
        HEXA_SAACPF_NRDC_CauseInternalTmOutE1BearerContextModification_DUID;
    wrapperCauseMap()[CauseCpInternalTmOutF1UeContextModification] =
        HEXA_SAACPF_NRDC_CauseInternalTmOutF1UeContextModification_DUID;
    wrapperCauseMap()[CauseCpInternalTmOutF1UeContextRelease] = HEXA_SAACPF_NRDC_CauseInternalTmOutF1UeContextRelease_DUID;
    wrapperCauseMap()[CauseCpInternalTmOutInternalResourceSetup] = HEXA_SAACPF_NRDC_CauseInternalTmOutInternalResourceSetup_DUID;
    wrapperCauseMap()[CauseCpInternalF1SctpOutOfService] = HEXA_SAACPF_NRDC_CauseInternalF1SctpOutOfService_DUID;
    wrapperCauseMap()[CauseCpInternalE1SctpOutOfService] = HEXA_SAACPF_NRDC_CauseInternalE1SctpOutOfService_DUID;
    wrapperCauseMap()[CauseCpInternalMDSSendFail] = HEXA_SAACPF_NRDC_CauseInternalMDSSendFail_DUID;
    wrapperCauseMap()[CauseCpInternalCacCallCountOver] = HEXA_SAACPF_NRDC_CauseInternalCacCallCountOver_DUID;
    wrapperCauseMap()[CauseCpInternalInvalidCallContext] = HEXA_SAACPF_NRDC_CauseInternalInvalidCallContext_DUID;
    wrapperCauseMap()[CauseCpInternalResourceAllocFail] = HEXA_SAACPF_NRDC_CauseInternalResourceAllocFail_DUID;
    wrapperCauseMap()[CauseCpInternalOMIntervention] = HEXA_SAACPF_NRDC_CauseInternalOMIntervention_DUID;
    wrapperCauseMap()[CauseCpInternalVmScaleIn] = HEXA_SAACPF_NRDC_CauseInternalVmScaleIn_DUID;
    wrapperCauseMap()[CauseCpInternalCellRelease] = HEXA_SAACPF_NRDC_CauseInternalCellRelease_DUID;
    wrapperCauseMap()[CauseCpInternalCallAllocationFail] = HEXA_SAACPF_NRDC_CauseInternalCallAllocationFail_DUID;
    wrapperCauseMap()[CauseCpInternalUpAllocationFail] = HEXA_SAACPF_NRDC_CauseInternalUpAllocationFail_DUID;
    wrapperCauseMap()[CauseCpInternalInvalidCallId] = HEXA_SAACPF_NRDC_CauseInternalInvalidCallId_DUID;
    wrapperCauseMap()[CauseCpInternalInvalidPlmn] = HEXA_SAACPF_NRDC_CauseInternalInvalidPlmn_DUID;
    wrapperCauseMap()[CauseCpInternalUserInactivity] = HEXA_SAACPF_NRDC_CauseInternalUserInactivity_DUID;
    wrapperCauseMap()[CauseCpInternalScgMobility] = HEXA_SAACPF_NRDC_CauseInternalScgMobility_DUID;
    wrapperCauseMap()[CauseCpInternalMeasurementReportBasedRelease] =
        HEXA_SAACPF_NRDC_CauseInternalMeasurementReportBasedRelease_DUID;
    wrapperCauseMap()[CauseCpInternalDuULRadioLinkFailure] = HEXA_SAACPF_NRDC_CauseInternalDuULRadioLinkFailure_DUID;
    wrapperCauseMap()[CauseCpInternalDuRlcMaxNumRetx] = HEXA_SAACPF_NRDC_CauseInternalDuRlcMaxNumRetx_DUID;
    wrapperCauseMap()[CauseCpInternalCpSrb3IntegrityFailure] = HEXA_SAACPF_NRDC_CauseInternalCpSrb3IntegrityFailure_DUID;
    wrapperCauseMap()[CauseCpInternalCuOverload] = HEXA_SAACPF_NRDC_CauseInternalCuOverload_DUID;
    wrapperCauseMap()[CauseCpInternalStoreRrcMessageError] = HEXA_SAACPF_NRDC_CauseInternalStoreRrcMessageError_DUID;
    wrapperCauseMap()[CauseCpInternalStoreE1MessageError] = HEXA_SAACPF_NRDC_CauseInternalStoreE1MessageError_DUID;
    wrapperCauseMap()[CauseCpInternalStoreF1MessageError] = HEXA_SAACPF_NRDC_CauseInternalStoreF1MessageError_DUID;
    wrapperCauseMap()[CauseCpInternalSendRrcMessageError] = HEXA_SAACPF_NRDC_CauseInternalSendRrcMessageError_DUID;
    wrapperCauseMap()[CauseCpInternalSendE1MessageError] = HEXA_SAACPF_NRDC_CauseInternalSendE1MessageError_DUID;
    wrapperCauseMap()[CauseCpInternalSendF1MessageError] = HEXA_SAACPF_NRDC_CauseInternalSendF1MessageError_DUID;
    wrapperCauseMap()[CauseCpInternalSaHoTmOutXnSNStatusTransfer] = HEXA_SAACPF_NRDC_CauseInternalHoTmOutXnSNStatusTransfer_DUID;
    wrapperCauseMap()[CauseCpInternalSaHoTmOutXnRelocOverall] = HEXA_SAACPF_NRDC_CauseInternalHoTmOutXnRelocOverall_DUID;
    wrapperCauseMap()[CauseCpInternalSaHoTmOutRrcHandoverComplete] =
        HEXA_SAACPF_NRDC_CauseInternalHoTmOutRrcHandoverComplete_DUID;
    wrapperCauseMap()[CauseCpInternalSaXnSctpOutOfService] = HEXA_SAACPF_NRDC_CauseInternalXnSctpOutOfService_DUID;
    wrapperCauseMap()[CauseCpInternalSaDuCallAllocationFail] = HEXA_SAACPF_NRDC_CauseInternalDuCallAllocationFail_DUID;
    wrapperCauseMap()[CauseCpInternalSaNotSupported5qiValue] = HEXA_SAACPF_NRDC_CauseInternalNotSupported5qiValue_DUID;
    wrapperCauseMap()[CauseCpInternalSaStoreXnMessageError] = HEXA_SAACPF_NRDC_CauseInternalStoreXnMessageError_DUID;
    wrapperCauseMap()[CauseCpInternalSaSendXnMessageError] = HEXA_SAACPF_NRDC_CauseInternalSendXnMessageError_DUID;
    wrapperCauseMap()[CauseF1apRadioUnspecified] = HEXA_SAACPF_NRDC_CauseF1apRadioUnspecified_DUID;
    wrapperCauseMap()[CauseF1apRadioRLFailure] = HEXA_SAACPF_NRDC_CauseF1apRadioRLFailure_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedCuUeF1apId] =
        HEXA_SAACPF_NRDC_CauseF1apRadioUnknownOrAlreadyAllocatedCuUeF1apId_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedDuUeF1apId] =
        HEXA_SAACPF_NRDC_CauseF1apRadioUnknownOrAlreadyAllocatedDuUeF1apId_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownInconsistentPairOfUeF1apId] =
        HEXA_SAACPF_NRDC_CauseF1apRadioUnknownInconsistentPairOfUeF1apId_DUID;
    wrapperCauseMap()[CauseF1apRadioInteraction] = HEXA_SAACPF_NRDC_CauseF1apRadioInteraction_DUID;
    wrapperCauseMap()[CauseF1apRadioDesirableRadioReasons] = HEXA_SAACPF_NRDC_CauseF1apRadioDesirableRadioReasons_DUID;
    wrapperCauseMap()[CauseF1apRadioUnavailableRadioReasons] = HEXA_SAACPF_NRDC_CauseF1apRadioUnavailableRadioReasons_DUID;
    wrapperCauseMap()[CauseF1apRadioProcedureCancelled] = HEXA_SAACPF_NRDC_CauseF1apRadioProcedureCancelled_DUID;
    wrapperCauseMap()[CauseF1apRadioNormalRelease] = HEXA_SAACPF_NRDC_CauseF1apRadioNormalRelease_DUID;
    wrapperCauseMap()[CauseF1apRadioCellNotAvailable] = HEXA_SAACPF_NRDC_CauseF1apRadioCellNotAvailable_DUID;
    wrapperCauseMap()[CauseF1apRadioRLFailureothers] = HEXA_SAACPF_NRDC_CauseF1apRadioRLFailureothers_DUID;
    wrapperCauseMap()[CauseF1apRadioUeRejection] = HEXA_SAACPF_NRDC_CauseF1apRadioUeRejection_DUID;
    wrapperCauseMap()[CauseF1apRadioResourcesNotAvailableForTheSlice] =
        HEXA_SAACPF_NRDC_CauseF1apRadioResourcesNotAvailableForTheSlice_DUID;
    wrapperCauseMap()[CauseF1apTransportUnspecified] = HEXA_SAACPF_NRDC_CauseF1apTransportUnspecified_DUID;
    wrapperCauseMap()[CauseF1apTransportResourceUnavailable] = HEXA_SAACPF_NRDC_CauseF1apTransportResourceUnavailable_DUID;
    wrapperCauseMap()[CauseF1apProtocolTransferSyntaxError] = HEXA_SAACPF_NRDC_CauseF1apProtocolTransferSyntaxError_DUID;
    wrapperCauseMap()[CauseF1apProtocolAbstractSyntaxErrorReject] =
        HEXA_SAACPF_NRDC_CauseF1apProtocolAbstractSyntaxErrorReject_DUID;
    wrapperCauseMap()[CauseF1apProtocolAbstractSyntaxErrorIgnore] =
        HEXA_SAACPF_NRDC_CauseF1apProtocolAbstractSyntaxErrorIgnore_DUID;
    wrapperCauseMap()[CauseF1apProtocolMessageNotCompatible] = HEXA_SAACPF_NRDC_CauseF1apProtocolMessageNotCompatible_DUID;
    wrapperCauseMap()[CauseF1apProtocolSemanticError] = HEXA_SAACPF_NRDC_CauseF1apProtocolSemanticError_DUID;
    wrapperCauseMap()[CauseF1apProtocolAbstractSyntaxError] = HEXA_SAACPF_NRDC_CauseF1apProtocolAbstractSyntaxError_DUID;
    wrapperCauseMap()[CauseF1apProtocolUnspecified] = HEXA_SAACPF_NRDC_CauseF1apProtocolUnspecified_DUID;
    wrapperCauseMap()[CauseF1apMiscControlProcessingOverload] = HEXA_SAACPF_NRDC_CauseF1apMiscControlProcessingOverload_DUID;
    wrapperCauseMap()[CauseF1apMiscUnavailableResources] = HEXA_SAACPF_NRDC_CauseF1apMiscUnavailableResources_DUID;
    wrapperCauseMap()[CauseF1apMiscHardwareFailure] = HEXA_SAACPF_NRDC_CauseF1apMiscHardwareFailure_DUID;
    wrapperCauseMap()[CauseF1apMiscOMIntervention] = HEXA_SAACPF_NRDC_CauseF1apMiscOMIntervention_DUID;
    wrapperCauseMap()[CauseF1apMiscUnspecifiedFailure] = HEXA_SAACPF_NRDC_CauseF1apMiscUnspecifiedFailure_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnspecified] = HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerUnspecified_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpUeE1apId] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpUeE1apId_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpUeE1apId] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpUeE1apId_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfUeE1apId] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfUeE1apId_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerInteractionWithOtherProcedure] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerInteractionWithOtherProcedure_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerPdcpCountWrapAround] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerPdcpCountWrapAround_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNotSupported5QiValue] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerNotSupported5QiValue_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerEncryptionAlgorithmsNotSupported] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerEncryptionAlgorithmsNotSupported_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerIntegrityProtectionAlgorithmsNotSupported] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerIntegrityProtectionAlgorithmsNotSupported_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUpIntegrityProtectionNotPossible] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerUpIntegrityProtectionNotPossible_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUpConfidentialityProtectionNotPossible] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerUpConfidentialityProtectionNotPossible_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMultiplePduSessionIdInstances] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerMultiplePduSessionIdInstances_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownPduSessionId] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownPduSessionId_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMultipleQosFlowIdInstances] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerMultipleQosFlowIdInstances_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownQosFlowId] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownQosFlowId_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMultipleDrbIdInstances] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerMultipleDrbIdInstances_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownDrbId] = HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownDrbId_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerInvalidQosCombination] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerInvalidQosCombination_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerProcedureCancelled] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerProcedureCancelled_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNormalRelease] = HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerNormalRelease_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNoRadioResourcesAvailable] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerNoRadioResourcesAvailable_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerActionDesirableForRadioReasons] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerActionDesirableForRadioReasons_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerResourcesNotAvailableForTheSlice] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerResourcesNotAvailableForTheSlice_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerPdcpConfigurationNotSupported] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerPdcpConfigurationNotSupported_DUID;
    wrapperCauseMap()[CauseE1apTransportLayerUnspecified] = HEXA_SAACPF_NRDC_CauseE1apTransportLayerUnspecified_DUID;
    wrapperCauseMap()[CauseE1apTransportLayerTransportResourceUnavailable] =
        HEXA_SAACPF_NRDC_CauseE1apTransportLayerTransportResourceUnavailable_DUID;
    wrapperCauseMap()[CauseE1apProtocolTransferSyntaxError] = HEXA_SAACPF_NRDC_CauseE1apProtocolTransferSyntaxError_DUID;
    wrapperCauseMap()[CauseE1apProtocolAbstractSyntaxErrorReject] =
        HEXA_SAACPF_NRDC_CauseE1apProtocolAbstractSyntaxErrorReject_DUID;
    wrapperCauseMap()[CauseE1apProtocolAbstractSyntaxErrorIgnoreAndNotify] =
        HEXA_SAACPF_NRDC_CauseE1apProtocolAbstractSyntaxErrorIgnoreAndNotify_DUID;
    wrapperCauseMap()[CauseE1apProtocolMessageNotCompatibleWithReceiverState] =
        HEXA_SAACPF_NRDC_CauseE1apProtocolMessageNotCompatibleWithReceiverState_DUID;
    wrapperCauseMap()[CauseE1apProtocolSemanticError] = HEXA_SAACPF_NRDC_CauseE1apProtocolSemanticError_DUID;
    wrapperCauseMap()[CauseE1apProtocolAbstractSyntaxErrorFalselyConstructedMessage] =
        HEXA_SAACPF_NRDC_CauseE1apProtocolAbstractSyntaxErrorFalselyConstructedMessage_DUID;
    wrapperCauseMap()[CauseE1apProtocolUnspecified] = HEXA_SAACPF_NRDC_CauseE1apProtocolUnspecified_DUID;
    wrapperCauseMap()[CauseE1apMiscControlProcessingOverload] = HEXA_SAACPF_NRDC_CauseE1apMiscControlProcessingOverload_DUID;
    wrapperCauseMap()[CauseE1apMiscNotEnoughUserPlaneProcessingResources] =
        HEXA_SAACPF_NRDC_CauseE1apMiscNotEnoughUserPlaneProcessingResources_DUID;
    wrapperCauseMap()[CauseE1apMiscHardwareFailure] = HEXA_SAACPF_NRDC_CauseE1apMiscHardwareFailure_DUID;
    wrapperCauseMap()[CauseE1apMiscOMIntervention] = HEXA_SAACPF_NRDC_CauseE1apMiscOMIntervention_DUID;
    wrapperCauseMap()[CauseE1apMiscUnspecified] = HEXA_SAACPF_NRDC_CauseE1apMiscUnspecified_DUID;
    wrapperCauseMap()[CauseCpInternalSaInvalidSecurityAlgorithm] = HEXA_SAACPF_NRDC_CauseInternalInvalidSecurityAlgorithm_DUID;
    wrapperCauseMap()[CauseCpInternalSaConfigNotExist] = HEXA_SAACPF_NRDC_CauseInternalConfigNotExist_DUID;
    wrapperCauseMap()[CauseF1apRadioReleaseDueToPreEmption] = HEXA_SAACPF_NRDC_CauseF1apRadioReleaseDueToPreEmption_DUID;
    wrapperCauseMap()[CauseF1apRadioPlmnNotServedByTheGnbCu] = HEXA_SAACPF_NRDC_CauseF1apRadioPlmnNotServedByTheGnbCu_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUeDlMaxIPDataRateReason] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerUeDlMaxIPDataRateReason_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUpIntegrityProtectionFailure] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerUpIntegrityProtectionFailure_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerReleaseDueToPreEmption] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerReleaseDueToPreEmption_DUID;
    wrapperCauseMap()[CauseCpInternalSaUeCapaNotSupported] = HEXA_SAACPF_NRDC_CauseInternalUeCapaNotSupported_DUID;

    wrapperCauseMap()[CauseF1apRadioMultipleDrbIdInstances] = HEXA_SAACPF_NRDC_CauseF1apRadioMultipleDrbIdInstances_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownDrbId] = HEXA_SAACPF_NRDC_CauseF1apRadioUnknownDrbId_DUID;
    wrapperCauseMap()[CauseF1apRadioMultipleBhRlcChIdInstances] = HEXA_SAACPF_NRDC_CauseF1apRadioMultipleBhRlcChIdInstances_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownBhRlcChId] = HEXA_SAACPF_NRDC_CauseF1apRadioUnknownBhRlcChId_DUID;
    wrapperCauseMap()[CauseF1apRadioChoCpcResourcesToBeChanged] = HEXA_SAACPF_NRDC_CauseF1apRadioChoCpcResourcesToBeChanged_DUID;
    wrapperCauseMap()[CauseF1apRadioNpnNotSupported] = HEXA_SAACPF_NRDC_CauseF1apRadioNpnNotSupported_DUID;
    wrapperCauseMap()[CauseF1apRadioNpnAccessDenied] = HEXA_SAACPF_NRDC_CauseF1apRadioNpnAccessDenied_DUID;
    wrapperCauseMap()[CauseF1apRadioGnbCuCellCapacityExceeded] = HEXA_SAACPF_NRDC_CauseF1apRadioGnbCuCellCapacityExceeded_DUID;
    wrapperCauseMap()[CauseF1apRadioReportCharacteristicsEmpty] = HEXA_SAACPF_NRDC_CauseF1apRadioReportCharacteristicsEmpty_DUID;
    wrapperCauseMap()[CauseF1apRadioExistingMeasurementID] = HEXA_SAACPF_NRDC_CauseF1apRadioExistingMeasurementID_DUID;
    wrapperCauseMap()[CauseF1apRadioMeasurementTemporarilyNotAvailable] =
        HEXA_SAACPF_NRDC_CauseF1apRadioMeasurementTemporarilyNotAvailable_DUID;
    wrapperCauseMap()[CauseF1apRadioMeasurementNotSupportedForTheObject] =
        HEXA_SAACPF_NRDC_CauseF1apRadioMeasurementNotSupportedForTheObject_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownBAPAddress] = HEXA_SAACPF_NRDC_CauseF1apRadioUnknownBAPAddress_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownBAPRoutingID] = HEXA_SAACPF_NRDC_CauseF1apRadioUnknownBAPRoutingID_DUID;
    wrapperCauseMap()[CauseF1apRadioInsufficientUeCapabilities] = HEXA_SAACPF_NRDC_CauseF1apRadioInsufficientUeCapabilities_DUID;
    wrapperCauseMap()[CauseF1apTransportUnknownTNLAddressForIAB] =
        HEXA_SAACPF_NRDC_CauseF1apTransportUnknownTNLAddressForIAB_DUID;
    wrapperCauseMap()[CauseF1apTransportUnknownUPTNLInformationForIAB] =
        HEXA_SAACPF_NRDC_CauseF1apTransportUnknownUPTNLInformationForIAB_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerRSNNotAvailableForTheUP] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerRSNNotAvailableForTheUP_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerNPNNotSupported] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerNPNNotSupported_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerReportCharacteristicsEmpty] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerReportCharacteristicsEmpty_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerExistingMeasurementID] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerExistingMeasurementID_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMeasurementTemporarilyNotAvailable] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerMeasurementTemporarilyNotAvailable_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerMeasurementNotSupportedForTheObject] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerMeasurementNotSupportedForTheObject_DUID;
    wrapperCauseMap()[CauseE1apTransportLayerUnknownTNLAddressForIAB] =
        HEXA_SAACPF_NRDC_CauseE1apTransportLayerUnknownTNLAddressForIAB_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerCellNotAvailable] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerCellNotAvailable_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerHandoverDesirableForRadioReasons] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerHandoverDesirableForRadioReasons_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerHandoverTargetNotAllowed] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerHandoverTargetNotAllowed_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNoRadioResourcesAvailableInTargetCell] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerNoRadioResourcesAvailableInTargetCell_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerPartialHandover] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerPartialHandover_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerReduceLoadInServingCell] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerReduceLoadInServingCell_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerResourceOptimisationHandover] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerResourceOptimisationHandover_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTimeCriticalHandover] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerTimeCriticalHandover_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTxnRelocOverallExpiry] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerTxnRelocOverallExpiry_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTxnRelocPrepExpiry] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerTxnRelocPrepExpiry_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnknownLocalNgranNodeUeXnapId] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerUnknownLocalNgranNodeUeXnapId_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerInconsistentRemoteNgranNodeUeXnapId] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerInconsistentRemoteNgranNodeUeXnapId_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerEncryptionAndOrIntegrityProtectionAlgorithmsNotSupported] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerEncryptionAndOrIntegrityProtectionAlgorithmsNotSupported_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerProtectionAlgorithmsNotSupported] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerProtectionAlgorithmsNotSupported_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMultiplePduSessionIdInstances] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerMultiplePduSessionIdInstances_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnknownPduSessionId] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerUnknownPduSessionId_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnknownQosFlowId] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerUnknownQosFlowId_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMultipleQosFlowIdInstances] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerMultipleQosFlowIdInstances_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerSwitchOffOngoing] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerSwitchOffOngoing_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNotSupported5qiValue] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerNotSupported5qiValue_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTxnDcOverallExpiry] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerTxnDcOverallExpiry_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTxnDcPrepExpiry] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerTxnDcPrepExpiry_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerActionDesirableForRadioReasons] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerActionDesirableForRadioReasons_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerReduceLoad] = HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerReduceLoad_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerResourceOptimisation] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerResourceOptimisation_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTimeCriticalAction] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerTimeCriticalAction_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerTargetNotAllowed] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerTargetNotAllowed_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNoRadioResourcesAvailable] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerNoRadioResourcesAvailable_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerInvalidQosCombination] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerInvalidQosCombination_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerEncryptionAlgorithmsNotSupported] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerEncryptionAlgorithmsNotSupported_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerProcedureCancelled] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerProcedureCancelled_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerRrmPurpose] = HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerRrmPurpose_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerImproveUserBitRate] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerImproveUserBitRate_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUserInactivity] = HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerUserInactivity_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerRadioConnectionWithUeLost] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerRadioConnectionWithUeLost_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerFailureInTheRadioInterfaceProcedure] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerFailureInTheRadioInterfaceProcedure_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerBearerOptionNotSupported] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerBearerOptionNotSupported_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUpIntegrityProtectionNotPossible] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerUpIntegrityProtectionNotPossible_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUpConfidentialityProtectionNotPossible] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerUpConfidentialityProtectionNotPossible_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerResourcesNotAvailableForTheSlice] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerResourcesNotAvailableForTheSlice_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUeMaximumIntegrityProtectedDataRateReason] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerUeMaximumIntegrityProtectedDataRateReason_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerCpIntegrityProtectionFailure] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerCpIntegrityProtectionFailure_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUpIntegrityProtectionFailure] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerUpIntegrityProtectionFailure_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerSlicesNotSupportedByNgran] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerSlicesNotSupportedByNgran_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMnMobility] = HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerMnMobility_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerSnMobility] = HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerSnMobility_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerCountReachesMaxValue] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerCountReachesMaxValue_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnknownOldNgranNodeUeXnapId] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerUnknownOldNgranNodeUeXnapId_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerPdcpOverload] = HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerPdcpOverload_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerDrbIdNotAvailable] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerDrbIdNotAvailable_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUnspecified] = HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerUnspecified_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUeContextIdNotKnown] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerUeContextIdNotKnown_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNonRelocationOfContext] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerNonRelocationOfContext_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerCHOCPCResourcesToBeChanged] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerCHOCPCResourcesToBeChanged_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerRSNNotAvailableForTheUP] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerRSNNotAvailableForTheUP_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNPNAccessDenied] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerNPNAccessDenied_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerReportCharacteristicsEmpty] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerReportCharacteristicsEmpty_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerExistingMeasurementID] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerExistingMeasurementID_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMeasurementTemporarilyNotAvailable] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerMeasurementTemporarilyNotAvailable_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerMeasurementNotSupportedForTheObject] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerMeasurementNotSupportedForTheObject_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerUEPowerSaving] = HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerUEPowerSaving_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNotExistingNGRANNode2MeasurementID] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerNotExistingNGRANNode2MeasurementID_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerInsufficientUECapabilities] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerInsufficientUECapabilities_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerNormalRelease] = HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerNormalRelease_DUID;
    wrapperCauseMap()[CauseXnapTransportLayerTransportResourceUnavailable] =
        HEXA_SAACPF_NRDC_CauseXnapTransportLayerTransportResourceUnavailable_DUID;
    wrapperCauseMap()[CauseXnapTransportLayerUnspecified] = HEXA_SAACPF_NRDC_CauseXnapTransportLayerUnspecified_DUID;
    wrapperCauseMap()[CauseXnapProtocolTransferSyntaxError] = HEXA_SAACPF_NRDC_CauseXnapProtocolTransferSyntaxError_DUID;
    wrapperCauseMap()[CauseXnapProtocolAbstractSyntaxErrorReject] =
        HEXA_SAACPF_NRDC_CauseXnapProtocolAbstractSyntaxErrorReject_DUID;
    wrapperCauseMap()[CauseXnapProtocolAbstractSyntaxErrorIgnoreAndNotify] =
        HEXA_SAACPF_NRDC_CauseXnapProtocolAbstractSyntaxErrorIgnoreAndNotify_DUID;
    wrapperCauseMap()[CauseXnapProtocolMessageNotCompatibleWithReceiverState] =
        HEXA_SAACPF_NRDC_CauseXnapProtocolMessageNotCompatibleWithReceiverState_DUID;
    wrapperCauseMap()[CauseXnapProtocolSemanticError] = HEXA_SAACPF_NRDC_CauseXnapProtocolSemanticError_DUID;
    wrapperCauseMap()[CauseXnapProtocolAbstractSyntaxErrorFalselyConstructedMessage] =
        HEXA_SAACPF_NRDC_CauseXnapProtocolAbstractSyntaxErrorFalselyConstructedMessage_DUID;
    wrapperCauseMap()[CauseXnapProtocolUnspecified] = HEXA_SAACPF_NRDC_CauseXnapProtocolUnspecified_DUID;
    wrapperCauseMap()[CauseXnapMiscControlProcessingOverload] = HEXA_SAACPF_NRDC_CauseXnapMiscControlProcessingOverload_DUID;
    wrapperCauseMap()[CauseXnapMiscHardwareFailure] = HEXA_SAACPF_NRDC_CauseXnapMiscHardwareFailure_DUID;
    wrapperCauseMap()[CauseXnapMiscOMIntervention] = HEXA_SAACPF_NRDC_CauseXnapMiscOMIntervention_DUID;
    wrapperCauseMap()[CauseXnapMiscNotEnoughUserPlaneProcessingResources] =
        HEXA_SAACPF_NRDC_CauseXnapMiscNotEnoughUserPlaneProcessingResources_DUID;
    wrapperCauseMap()[CauseXnapMiscUnspecified] = HEXA_SAACPF_NRDC_CauseXnapMiscUnspecified_DUID;
    wrapperCauseMap()[CauseCpInternalSaTmOutXNSgnbReconfigurationComplete] =
        HEXA_SAACPF_NRDC_CauseInternalTmOutXNSgnbReconfigurationComplete_DUID;
    wrapperCauseMap()[CauseCpInternalCpSrbIntegrityFailure] = HEXA_SAACPF_NRDC_CauseInternalCpSrbIntegrityFailure_DUID;
    wrapperCauseMap()[CauseF1apRadioScgActivationDeactivationFailure] =
        HEXA_SAACPF_NRDC_CauseF1apRadioScgActivationDeactivationFailure_DUID;
    wrapperCauseMap()[CauseF1apRadioScgDeactivationFailureDueToDataTransmission] =
        HEXA_SAACPF_NRDC_CauseF1apRadioScgDeactivationFailureDueToDataTransmission_DUID;
    wrapperCauseMap()[CauseF1apRadioRequestedItemNotSupportedOnTime] =
        HEXA_SAACPF_NRDC_CauseF1apRadioRequestedItemNotSupportedOnTime_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedGnbCuMbsF1apId] =
        HEXA_SAACPF_NRDC_CauseF1apRadioUnknownOrAlreadyAllocatedGnbCuMbsF1apId_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownOrAlreadyAllocatedGnbDuMbsF1apId] =
        HEXA_SAACPF_NRDC_CauseF1apRadioUnknownOrAlreadyAllocatedGnbDuMbsF1apId_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownOrInconsistentPairOfMbsF1apId] =
        HEXA_SAACPF_NRDC_CauseF1apRadioUnknownOrInconsistentPairOfMbsF1apId_DUID;
    wrapperCauseMap()[CauseF1apRadioUnknownOrInconsistentMrbId] =
        HEXA_SAACPF_NRDC_CauseF1apRadioUnknownOrInconsistentMrbId_DUID;
    wrapperCauseMap()[CauseF1apRadioTatSdtExpiry] =
        HEXA_SAACPF_NRDC_CauseF1apRadioTatSdtExpiry_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerScgActivationDeactivationFailure] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerScgActivationDeactivationFailure_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerScgDeactivationFailureDueToDataTransmission] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerScgDeactivationFailureDueToDataTransmission_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpMbsE1apId] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpMbsE1apId_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpMbsE1apId] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpMbsE1apId_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfMbsE1apId] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfMbsE1apId_DUID;
    wrapperCauseMap()[CauseE1apRadioNetworkLayerUnknownOrInconsistentMrbId] =
        HEXA_SAACPF_NRDC_CauseE1apRadioNetworkLayerUnknownOrInconsistentMrbId_DUID;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerInsufficientUeCapabilities] =
        HEXA_SAACPF_NRDC_CauseNgapRadioNetworkLayerInsufficientUeCapabilities_DUID;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerRedcapUeNotSupported] =
        HEXA_SAACPF_NRDC_CauseNgapRadioNetworkLayerRedCapUeNotSupported_DUID;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerUnknownMBSSessionID] =
        HEXA_SAACPF_NRDC_CauseNgapRadioNetworkLayerUnknownMbsSessionId_DUID;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerIndicatedMBSSessionAreaInformationNotServedByTheGNB] =
        HEXA_SAACPF_NRDC_CauseNgapRadioNetworkLayerIndicatedMbsSessionAreaInformationNotServedByTheGnb_DUID;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerInconsistentSliceInfoForTheSession] =
        HEXA_SAACPF_NRDC_CauseNgapRadioNetworkLayerInconsistentSliceInfoForTheSession_DUID;
    wrapperCauseMap()[CauseNgapRadioNetworkLayerMisalignedAssociationForMulticastUnicast] =
        HEXA_SAACPF_NRDC_CauseNgapRadioNetworkLayerMisalignedAssociationForTheMulticastAndUnicastSessionsOrFlows_DUID;
    wrapperCauseMap()[CauseNgapNasUeNotInPlmnServingArea] =
        HEXA_SAACPF_NRDC_CauseNgapNasUeNotInPlmnServingArea_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerScgActivationDeactivationFailure] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerScgActivationDeactivationFailure_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerScgDeactivationFailureDueToDataTransmission] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerScgDeactivationFailureDueToDataTransmission_DUID;
    wrapperCauseMap()[CauseXnapRadioNetworkLayerValueOutOfAllowedRange] =
        HEXA_SAACPF_NRDC_CauseXnapRadioNetworkLayerValueOutOfAllowedRange_DUID;
    wrapperCauseMap()[CauseCpInternalT310Expiry] =
        HEXA_SAACPF_NRDC_CauseInternalT310Expiry_DUID;
    wrapperCauseMap()[CauseCpInternalRandomAccessProblem] =
        HEXA_SAACPF_NRDC_CauseInternalRandomAccessProblem_DUID;
    wrapperCauseMap()[CauseCpInternalRlcMaxNumRetx] =
        HEXA_SAACPF_NRDC_CauseInternalRlcMaxNumRetx_DUID;
    wrapperCauseMap()[CauseCpInternalSynchReconfigFailureScg] =
        HEXA_SAACPF_NRDC_CauseInternalSynchReconfigFailureScg_DUID;
    wrapperCauseMap()[CauseCpInternalScgReconfigFailure] =
        HEXA_SAACPF_NRDC_CauseInternalScgReconfigFailure_DUID;
    wrapperCauseMap()[CauseCpInternalT312Expiry] = 
        HEXA_SAACPF_NRDC_CauseInternalT312Expiry_DUID;
    wrapperCauseMap()[CauseCpInternalSrb3IntegrityFailure] =
        HEXA_SAACPF_NRDC_CauseInternalSrb3IntegrityFailure_DUID;
    wrapperCauseMap()[CauseCpInternalBeamFailureRecoveryFailure] =
        HEXA_SAACPF_NRDC_CauseInternalBeamFailureRecoveryFailure_DUID;
    wrapperCauseMap()[CauseCpInternalScgFailureOthers] = 
        HEXA_SAACPF_NRDC_CauseInternalScgFailureOthers_DUID;

    if (STAT_SA_CUCPCSL_NRDC_SN_PER_GNB_DU_ID_HEXA_END == wrapperCauseMap().size())
        return NR_CSL_CAUSE_ERROR_NONE;
    else
        return NR_CSL_CAUSE_ERROR_VALIDATION_FAILED;
}

nr_csl_cause_error_e nr_csl_du_id_hex_cause_get_sacp_nrdc_sn_pmCause(const cause_t cause, pmCause_t* pmCause)
{
    if (wrapperCauseMap().find(cause) == wrapperCauseMap().end())
    {
        return NR_CSL_CAUSE_ERROR_VALIDATION_FAILED;
    }

    if (NULL == pmCause)
    {
        return NR_CSL_CAUSE_ERROR_INVALID_PARAMETER;
    }

    *pmCause = wrapperCauseMap()[cause];
    return NR_CSL_CAUSE_ERROR_NONE;
}
