#ifndef StatIndexMapper_H
#define StatIndexMapper_H

/**
 * @file        : StatIndexMapper.h
 * @brief       : header of interface for StatIndexMapper
 *
 * @author      : hyunz.lee@samsung.com
 * @date        : 2023/08/11
 *
 * Copyright 2023 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#include <stdint.h>
#include "VccbDefine.h"
#include "ComContainers.hpp"

const simpleVector<int, MAX_VCCB_STAT_KEY_NUM> getIndexNameVector(const int family);
void makeStatIndexMap(void);

#endif
