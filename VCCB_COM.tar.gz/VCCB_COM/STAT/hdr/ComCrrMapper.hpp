/**
 * @file        : ComCrrMapper.hpp
 * @brief       : header of interface for crr cause
 *
 * @author      : k.hernas@samsung.com
 * @date        : 2024/10/30
 *
 * Copyright 2024 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef VCCB_COM_ComCrrMapper_HPP_
#define VCCB_COM_ComCrrMapper_HPP_

#include <stdint.h>
#include <optional>

/**
 * @brief enumeration for error code of application.
 */

typedef enum
{
    UNKNOWN_CRR = -1,
    ABNORMAL_CRR = 0,
    NORMAL_CRR = 1,
    SEMINORMAL_CRR = 2,
} enumCrrCategory;

/**
 * @brief 
 * @param[in] callFaultCause : cause of call fault
 * @param[out]
 * @return enumCrrCategory : proper category of CRR based on cause of call fault
 */

std::optional<int16_t> getCrrCategoryValue(uint16_t callFaultCause);

#endif /* VCCB_COM_ComCrrMapper_HPP_ */
