#ifndef VCCB_COM_ComLibStatistic_H_
#define VCCB_COM_ComLibStatistic_H_

#include "VccbStruct.h"
#include "PM_FAMILY_ID.h"
#include "PM_TYPE_ID.h"

#include "VpmInterface.h"
#include "ComInclude.h"
#include "ComCslCauseMap.h"

typedef struct
{
    uint8_t usage;
    PME_LIB_TYPE updateMethod;
    unsigned int numOfItem;
    union
    {
        updateItemUINT updateItemUintArr[VCCB_MAX_MTYPES];
        updateItemULL updateItemUllArr[VCCB_MAX_MTYPES];
        updateItemFLOAT updateItemFloatArr[VCCB_MAX_MTYPES];
    };
} VccbPmMultiCollect_type;  // For vpmUpdate

namespace ComLibStatistic
{
void calculateRRCHoldingTime(callInfo_type &call, const enumRRCState_type rRCState);
}  // namespace ComLibStatistic

/*----------------------------------------------------------------------------
 * Define    :    Function ProtoType
 * ---------------------------------------------------------------------------
 */

/* Periodic Statistics*/
void VLIB_LibStatPeriodicEvent(void);
void VLIB_PeriodicStat_DrbInfo(VccbCellInfo_type *pCell);
void VLIB_PeriodicStat_ErabInfo(VccbCellInfo_type *pCell);
void VLIB_PeriodicStat_UEInfo(VccbCellInfo_type *pCell);
void VLIB_PeriodicStat_UEUlRohcInfo(VccbCellInfo_type *pCell);
void VLIB_PeriodicStat_MdtConfigDelivery(VccbCellInfo_type *pCell);

void FnVCCB_PeriodicStat_SaCellDrbConnInfo(VccbCellInfo_type *pCell, uint16_t fiveQiIdx);
void FnVCCB_PeriodicStat_SaCellDrbConnInfoPerPlmn(VccbCellInfo_type *pCell, uint16_t fiveQiIdx, uint32_t servedPlmn);

void FnVCCB_PeriodicStat_SaCommonDrbConnInfo(VccbCellInfo_type *pCell, enumDrbStatCollectOption_type collectOption);
void VLIB_PeriodicStat_RrcConnInfo(VccbCellInfo_type *pCell);
void FnVCCB_PeriodicStat_NrdcConnInfo(VccbCellInfo_type *pCell);
void FnVCCB_PeriodicStat_NrdcSnTermDrbConnInfo(VccbCellInfo_type *pCell, uint16_t fiveQiIdx);
void FnVCCB_PeriodicStat_NrdcSnTermDrbConnInfoForPlmn(VccbCellInfo_type *pCell, uint16_t fiveQiIdx, uint32_t cellPlmnIndex);


void VLIB_LibStatPmCC_Value(int mFamily, int mType, callInfo_type *ptCi, uint64_t reserved2, uint64_t reserved3,
    int reserved4, int reserved5, int reserved6, unsigned int updateValue);
void VLIB_LibStatPmCC(int mFamily, int mType, callInfo_type *ptCi, uint64_t reserved2, uint64_t reserved3,
    int reserved4, int reserved5, int reserved6, const char *fnName);
void VLIB_LibStatPmGauge(int mFamily, int mType, callInfo_type *ptCi, float updateValue, uint16_t gnbNum,
    uint16_t cellIdentity, uint32_t reserved5, uint32_t reserved6);
void VLIB_LibStatPmSI(int mFamily, int mType, callInfo_type *ptCi, float updateValue, int reserved3, uint64_t reserved4,
    uint64_t reserved5, uint64_t reserved6);
void VLIB_LibStatPmCC_QCI(int mFamily, int mType, callInfo_type *ptCi, callERABInfo_type *ptRi, int reserved3,
    int reserved4, int reserved5, int reserved6, const char *fnName);
void FnVCCB_LibStatPmSI_QCI(int mFamily, int mType, callInfo_type *ptCi, callERABInfo_type *ptRi, float updateValue,
    int reserved4, int reserved5, int reserved6);
void VLIB_LibStatPmCC_MSG(int mFamily, int mType, uint32_t gnbIdOrNum, uint16_t endPointIdx);

// pmCC MSG Statistics 
void FnVCCB_CollectInterfaceMsgCount(int mFamily, int mType, uint32_t gnbIdOrNum, uint16_t endPointIdx, uint8_t threadId);
void FnVCCB_PeriodicStat_InterfaceMsgCount(void);

void VLIB_SetPmInfoForSaCsl_NrdcSn(callInfo_type *ptCi, nr_csl_cause_error_e &pmResult, uint16_t cause, pmCause_t *pmCause, pmCause_t &pmCauseEnd, uint32_t &pmFamilyId);
void VLIB_SetPmInfoForSaCsl(callInfo_type *ptCi, nr_csl_cause_error_e &pmResult, uint16_t cause, pmCause_t *pmCause, pmCause_t &pmCauseEnd, uint32_t &pmFamilyId);
void VLIB_SetPmInfoForNsaCsl_Endc(callInfo_type *ptCi, nr_csl_cause_error_e &pmResult, uint16_t cause, pmCause_t *pmCause, pmCause_t &pmCauseEnd, uint32_t &pmFamilyId);
void VLIB_SetPmKey(callInfo_type *ptCi, uint64_t cellIdentity, VccbPmKey_type& pmKey, VccbPmMultiCollect_type& pmMultiCollect, uint32_t pmFamilyId, pmCause_t pmCause);
void VLIB_LibStatCSLInfo_CollectCrrSum(VccbPmMultiCollect_type& pmMultiCollect, uint32_t pmFamilyId, pmCause_t pmCause);
void VLIB_LibStatCSLInfo_CollectRedcapStats(callInfo_type *ptCi, uint64_t cellIdentity, uint16_t cause);
void VLIB_LibStatCSLInfo_CollectLegacyStats(callInfo_type *ptCi, uint64_t cellIdentity, uint16_t cause);
void VLIB_LibStatCSLInfo(callInfo_type *ptCi, uint64_t cellIdentity, uint16_t cause);
void VLIB_CalculateErabHoldTime(callInfo_type *ptCi, callERABInfo_type *ptRi, uint8_t actFlag);

// SA Resource Statistics
void VLIB_LibStatPmCC_DRB(int mFamily, int mType, callInfo_type *ptCi, callDRBInfo_type *ptDi, int duVoice5QINotSupport,
    int sliceFail, int reserved5, uint64_t inputUint64Val, const char *fnName);
void VLIB_LibStatPmCC_PDU(int mFamily, int mType, callInfo_type *ptCi, callPDUSessInfo_type *ptPi, int sliceFail,
    int reserved4, int reserved5, int reserved6, const char *fnName);
void VLIB_LibStatPmCC_QosFlow(int mFamily, int mType, callInfo_type *ptCi, callPDUSessInfo_type *ptPi,
    qosFlowInfo_type *ptQi, int sliceFail, int reserved5, int reserved6, const char *fnName);
void VLIB_LibStatPmCC_FLOAT(int mFamily, int mType, callInfo_type *ptCi, float updateValue, int reserved3,
    int reserved4, int reserved5, int reserved6);

void VLIB_PrepareQciAttemptSuccess(callInfo_type *ptCi, int mType);
void VLIB_PeggQciAttemptSuccess(callInfo_type *ptCi, uint16_t QCI, int mType);
void VLIB_CallStatProcessAnswer(callInfo_type *ptCi, callERABInfo_type *ptRi);

void VLIB_StatReleaseInd(callInfo_type *ptCi, uint32_t cause);
void VLIB_CalculateEndcRrcConnHoldingTime(callInfo_type *ptCi, uint8_t actFlag);
void VLIB_CalculateAddProcTime(callInfo_type *ptCi, uint8_t actFlag);
void VLIB_StatUnKnownPciCount( callInfo_type *ptCi, uint16_t pci, bool knownFlag, uint32_t arfcn, 
        enumNRMeas_type nrMeasType, int8_t smallCellListIdx, uint16_t allowedNcrCnt);
void VLIB_StatEndcAdd(callInfo_type *ptCi, enumStatEndcAddType type, const char *fnName);
void VLIB_StatNedcAdd(callInfo_type *ptCi, enumStatNedcAddType type);
void VLIB_SetNoAttemptFlag(callInfo_type *ptCi, int mFamily);
void VLIB_StatErabAddInterMnHO(callInfo_type *ptCi, STAT_ERAB_ADD_PER_GNB_ITEM type, int16_t erabStatus_flag);

// void VLIB_StatResumePerFailCauseSCGFailure (callInfo_type *ptCi);
void VLIB_StatCallFaultPerFailCauseSCGFailure(callInfo_type *ptCi, const msgUnpack_type *ptUnpack);
void VLIB_UpdateCounters_AttemptMrBasedResyncSCGFailure(callInfo_type *ptCi);
void VLIB_UpdateCounters_SuccessMrBasedResyncSCGFailure(callInfo_type *ptCi, uint8_t newScgFlag);
void VLIB_CalculateSpCellChgTime(callInfo_type *ptCi, uint8_t actFlag, spCellChg_type spCellChgType);
void VLIB_CalculateRrcConnEstabProcTime(callInfo_type *ptCi, uint8_t actFlag);
void VLIB_CalculateNgConnEstabProcTime(callInfo_type *ptCi, uint8_t actFlag);
void VLIB_CalculateRrcConnInactHoldingTime(callInfo_type *ptCi, uint8_t actFlag);
void VLIB_CalculateRrcInactHoldingTime(callInfo_type *ptCi, uint8_t actFlag);
void VLIB_CalculateRrcConnHoldingTime(callInfo_type *ptCi, uint8_t actFlag);
void VLIB_Stat_RrcEstabResult(callInfo_type *ptCi, int type);
void VLIB_StatSaHandover(callInfo_type *ptCi, enumHoStatType type, const char *fnName);
void FnVCCB_StatChoHandover(callInfo_type *ptCi, enumChoStatType type, cgi_type *pTargetCgi);
int GetRankTypeId(int mFamily, int mType);
int GetAttemptTypeBasedOnPriority(int causeType);
int GetCauseTypeBasedOnPriority(bool * counterType);
void VLIB_StatSaPsCellChangeTime(callInfo_type *ptCi);

void VLIB_SAHandoverTime(callInfo_type *ptCi, uint8_t actFlag);
void VLIB_StatPingPongHandover(callInfo_type *ptCi);

bool FnVCCB_IsServiceTypeStatFamily(int family);
const char *FnVCCB_GetServiceTypeFamily(int family);
int FnVCCB_GetServiceTypeStatFamily(int family);
bool FnVCCB_IsSupportServiceTypeYang(int family, VccbGnbInfo_type *pGnb);
void FnVCCB_LibStatPmCC_Mobility(int mFamily, int mType, callInfo_type *ptCi, uint64_t reserved2, const char *fnName);

int16_t FnVCCB_SaHandoverStatForF1(callInfo_type *ptCi, enumDuHoRole duHoRole);
void FnVCCB_UpdateSaHoStatFromUeCxtRelCmd(callInfo_type *ptCi);
void FnVCCB_SaHandoverStatForXN(callInfo_type *ptCi);

void FnVCCB_IncreaseEventOccurrenceCount(uint8_t threadId, uint16_t eventId);
void FnVCCB_IncreaseEventSavedCount(uint8_t threadId, uint16_t eventId);

void VLIB_ConvertPlmnIdToPlmnValue(s2_type *p_plmn_s2_value, uint32_t *p_plmn_key);
void VLIB_StatNedcScgFailure(callInfo_type *ptCi);   // NEDC_SCG_FAILURE_20C
void VLIB_StatNedcMgnbInitRel(callInfo_type *ptCi);  // NEDC_SCG_FAILURE_20C
void VLIB_SetOnAllRetainStatCapableFlag(callInfo_type *ptCi, uint32_t collectSetupFailStat, uint32_t isInterGnbOperationFlag);
void VLIB_SaveEventForDrbRetainStat(
    callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t retainCategory, uint32_t cause);
void VLIB_SaveEventForCallRetainStat(callInfo_type *ptCi, uint8_t retainCategory, uint32_t cause);
void VLIB_LibStatPmCC_Retain(int mFamily, callInfo_type *ptCi, callDRBInfo_type *ptDi, uint16_t retainCategory,
    uint16_t retainItem, uint32_t isOldCell, uint32_t isMobility);

void FnVCCB_CollectStatCSL_DrbRetain(callInfo_type *ptCi, int mFamily, retainExtraInfo_type *pRetainExtraInfo);
void FnVCCB_CollectStatCSL_UeRetain(callInfo_type *ptCi, int mFamily, retainExtraInfo_type *pRetainExtraInfo);
int16_t VLIB_LibStatPmCC_Retain_Validation(int mFamily, callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t *isCollectAbnormalItem);
int16_t VLIB_LibStatPmCC_Retain_Collect_PmLib(callInfo_type *ptCi, VccbPmMultiCollect_type *pmMultiCollect, int mFamily,
    int mActualFamily, uint16_t retainCategory, uint16_t retainItem, uint8_t isCollectAbnormalItem,
    const uint8_t drbStatTypeOffset, const retainExtraInfo_type *pRetainExtraInfo);
int16_t VLIB_LibStatPmCC_Retain_Collect_PmLib(callInfo_type *ptCi, VccbPmMultiCollect_type *pmMultiCollect, int mFamily, int mActualFamily, 
    uint16_t retainCategory, uint16_t retainItem, uint8_t isCollectAbnormalItem, const uint8_t drbStatTypeOffset, retainExtraInfo_type *pRetainExtraInfo);
int16_t VLIB_LibStatPmCC_Retain_SetPmkey(callInfo_type *ptCi, callDRBInfo_type *ptDi, VccbPmKey_type *pPmKey,
    VccbPmMultiCollect_type *pmMultiCollect, int mFamily, int mActualFamily, uint16_t retainCategory,
    uint32_t isOldCell, uint32_t isMobility, uint8_t *drbStatTypeOffset, retainExtraInfo_type* retainExtraInfo);
void FnVCCB_SaveDrbRetainCause_ByPduRelReqForAmfRequest(callInfo_type *ptCi);

void VLIB_CollectErabAddModStat(callInfo_type *ptCi, uint32_t erabAddType, uint32_t erabModType, uint32_t erabChgType);
void VLIB_CollectNsaHoCpFailStat(callInfo_type *ptCi, int isPrepFail);
int16_t VLIB_CollectNsaHoSuccessStatAndFinalizeHandover(callInfo_type *ptCi);
int16_t VLIB_CollectNsaHoSuccessStatAndFinalizeHandover_IntraDuHo_E1apDrbModResume(callInfo_type *ptCi);
int16_t VLIB_CollectNsaModSuccessStatAndSetStableState(callInfo_type *ptCi);
void VLIB_StatHoDebugIncreaseEventCount(uint8_t threadId);
void VLIB_PduSessionResourceSetup_CollectStat_AllFailedCause(callInfo_type *ptCi, uint16_t reqCause);
bool VLIB_NeedToPegIntraFreqPscellChangeScgMob(const callInfo_type &call);
void VLIB_PegEndcIntraChg_SuccOrFailMenbFailWhenX2ModRefuse(callInfo_type *ptCi, msgUnpack_type *ptUnpack);
int VLIB_GetTgtCellFreqForHo(const callInfo_type *ptCi, uint32_t *pTgtCellFreq);
void VLIB_QosFlowSetup_CollectStat_FailedQosflowItem(
    callInfo_type *ptCi, uint16_t cause, callPDUSessInfo_type *ptPi, qosFlowInfo_type *ptQi, int32_t mFamily);
void VLIB_StatNrdcScgFailure(callInfo_type *ptCi);  // NRDC_SCG_FAILURE_21D

extern void FnVCCB_StatMrdcSnAdd(callInfo_type *ptCi, int type, const char *fnName);

extern void FnVCCB_StatNrdcSnChange(callInfo_type *ptCi, int type, const char *fnName);

int16_t VLIB_IsExtendedCSL(uint16_t cause);
void FnVCCB_DiffRfspValAndUpdateRrcConStat(callInfo_type *ptCi);
void FnVCCB_DiffRfspValAndUpdateNrdcConStat(callInfo_type *ptCi);
void FnVCCB_UpdateConnStatsIfRfspChanged(callInfo_type *ptCi);
void FnVCCB_GetRfspStatValueFromYang(callInfo_type *ptCi, uint16_t &rRfsp);

void FnVCCB_CollectRfspBasedSetupTime(callInfo_type *ptCi, int mFamily, int mType, float setupTime);
void FnVCCB_UpdateCellRrcConnectionCountWithRfsp(callInfo_type *ptCi, uint16_t newRfspVal);
void FnVCCB_CollectRfspBasedHoldingTime(callInfo_type *ptCi, int mFamily, int mType, float holdingTime);

void FnVCCB_UpdateGnbDuIdUsingCellId(
    callInfo_type *ptCi, unsigned long long *pPmIndex, uint16_t cellIdentity, uint16_t nonUeGnbNum);
int FnVCCB_CollectVoNRStatFromHoTime(callInfo_type *ptCi, int mFamily, int type);
int FnVCCB_GetAdditionalTypeForPmGauge(callInfo_type *ptCi, int mFamily, int type);
void FnVCCB_SaveEventCommonForDrbQosRetain(callInfo_type *ptCi, retainStatInfo_type *ptRetainInfo, uint8_t retainCategory, uint32_t cause);
void FnVCCB_SaveEventForQosVonrEmerRetainStat(callInfo_type *ptCi, qosFlowInfo_type *ptQi, uint8_t retainCategory, uint32_t cause);
void FnVCCB_EndcUlPathControl_CollectSpidPathChangeStats(callInfo_type *ptCi, int mType);
void FnVCCB_EndcUlPathControl_CollectHighLatencyPathChangeStats(callInfo_type *ptCi);
void FnVCCB_EndcUlPathControl_CollectPathChangeStats(callInfo_type *ptCi);

void VLIB_SetSaOutgoingHoTime(callInfo_type *ptCi, uint8_t actFlag); // IRAT_HO_23B
void VLIB_CollectStatSaOutgoingHoTime(callInfo_type *ptCi); // IRAT_HO_23B

void FnVCCB_CollectPduQosFlowStat_ForRejectAll(callInfo_type *ptCi, msgUnpack_type *ptUnpack, enumActionOfPduSessionMsg_type doOption);

int16_t FnVCCB_CollectPduQosFlow_ForInitialContextSetupRejectAll (callInfo_type *ptCi, msgUnpack_type *ptUnpack);
int16_t FnVCCB_CollectPduQosFlow_ForPduSessionSetupRejectAll (callInfo_type *ptCi, msgUnpack_type *ptUnpack, enumActionOfPduSessionMsg_type doOption);
int16_t FnVCCB_CollectPduQosFlow_ForPduSessionModifyRejectAll (callInfo_type *ptCi, msgUnpack_type *ptUnpack, enumActionOfPduSessionMsg_type doOption);

int16_t FnVCCB_CollectPduQosFlowSetupFail_InPduSessionSetupList(
    callInfo_type *ptCi, NGAP_PDUSessionResourceSetupListCxtReq_type *ptList, enumActionOfPduSessionMsg_type doOption);
int16_t FnVCCB_CollectQosFlowSetupFail_inQosFlowAddOrModify(callInfo_type *ptCi, NGAP_QosFlowAddOrModifyRequestList_type *ptQosFlowAddModList, 
    callPDUSessInfo_type *ptPi, enumActionOfPduSessionMsg_type doOption);

void FnVCCB_InitStatInfo(void);
int FnVCCB_GetLocalFamilyIndexUsingPmFamilyId(int pmFamilyId);
int FnVCCB_GetStatMappingTableSize(void);
void FnVCCB_CollectStatNcgiReport(
    callInfo_type *ptCi, enumNcgiReportReportEvent_type type, uint8_t autonomousGapFlag, const char *fnName);
void FnVCCB_CollectStatEcgiReport(
    callInfo_type *ptCi, enumEcgiReportReportEvent_type type, uint8_t autonomousGapFlag, const char *fnName);
void FnVCCB_CollectReportCgiStat(
    callInfo_type *ptCi, enumCgiReportReportResult_type type, uint8_t autonomousGapFlag, const char *fnName);

void FnVCCB_StatCallFaultPerFailCauseSCGFailure_NRDC(callInfo_type *ptCi, uint32_t msgId);

// SVR24B FGR-CC0300 Service Type Configuration for Statistics
extern void FnVCCB_InitServiceTypeList(void);
extern void FnVCCB_SetServiceType(ServiceTypeList_type &ServiceType, int32_t mcc, int32_t mnc, int32_t sst, int32_t sd, int16_t fiveQi, int16_t rfsp, int16_t arp, int16_t ueType);
extern void FnVCCB_SetValidServiceTypeListSet(void);
extern int16_t FnVCCB_GetServiceTypeResult(const ServiceTypeList_type target, std::set<uint32_t> &serviceTypeListResultSet);
int16_t FnVCCB_GetQosServiceType(callInfo_type *ptCi, callPDUSessInfo_type *ptPi, qosFlowInfo_type *ptQi, std::set<uint32_t> &serviceTypeListResultSet);
extern int16_t FnVCCB_GetDrbServiceType(callInfo_type *ptCi, callDRBInfo_type *ptDi, std::set<uint32_t> &serviceTypeListResultSet);
extern int16_t FnVCCB_GetCallServiceType(callInfo_type *ptCi, std::set<uint32_t> &serviceTypeListResultSet);

BOOL FnVCCB_CheckAndUpdateMeasPciStat(callInfo_type *ptCi, uint16_t pci, uint32_t arfcn, enumAnrObjType ratType, bool isStat);
void FnVCCB_CollectNrRetainServiceType(callInfo_type *ptCi, int mFamily, callDRBInfo_type *ptDi, VccbPmMultiCollect_type *pPmMultiCollect, VccbPmKey_type& rPmKey);
void FnVCCB_CollectNrRrcReestablishServiceType(callInfo_type *ptCi, int mFamily, VccbPmMultiCollect_type *pPmMultiCollect, VccbPmKey_type& rPmKey);
void VLIB_StatEutraUnKnownPciCount( callInfo_type *ptCi, uint16_t pci, BOOL knownFlag,
        uint32_t arfcn, uint8_t hoAllowedFlag, int8_t smallCellListIdx, uint16_t allowedNcrCnt);
void FnVCCB_UpdateNrdcModStats(
    callInfo_type *ptCi, int mType, XNAP_Cause_type *pCause, bool chkRaceCondition);
void VLIB_LibStatCSLHoInfo(callInfo_type &rCall, int mFamily, int mType);
void FnVCCB_CollectStatCSL_RrcSetup(callInfo_type *ptCi, int mFamily, int mType);
void FnVCCB_CollectStatCSL_RrcReestab(callInfo_type *ptCi, int mFamily, int mType);
void FnVCCB_CollectStatBeforeCSL_PutCi(callInfo_type *ptCi);
void FnVCCB_CollectLatestReleasedQcis(callInfo_type *ptCi);
void FnVCCB_RearrangeCslCollectOrder_DrbSetup(callInfo_type *ptCi);
void FnVCCB_CollectStatCSL_DrbSetup(callInfo_type *ptCi, uint8_t fiveQi, int mFamily, int mType, uint16_t failCauseCslVal);
void FnVCCB_RearrangeCslCollectOrder_RetainStat(callInfo_type *ptCi);
uint8_t FnVCCB_GetCslIndexForDrbRetain(callInfo_type *ptCi, int mFamily, uint8_t fiveQi, uint8_t *pUsingExistFiveQi);

void FnVCCB_SendInternalStatisticsItemCollect(uint8_t threadId);
void FnVCCB_SendInternalStatisticsItemUpdate(uint8_t threadId);

typedef struct collectItemIndexValue_s {
    uint32_t    itemIndex;
    union {
        uint32_t    uVal;
        uint64_t    lVal;
        float       fVal;
    };
} collectItemIndexValue_type;

typedef struct collectItemHasher_s {
public:
    size_t operator() (const VccbStatisticsTemporaryCollect_type& item) const
    {
        size_t seed = 0;

        hash_combine(seed, item.mFamily);
        hash_combine(seed, item.mType);
        hash_combine(seed, item.valueType);
        for (int i = 0; i < MAX_VCCB_STAT_KEY_NUM; i++)
        {
            hash_combine(seed, item.key[i]);
        }

        return seed;
    }

private:
    template <typename T>
    void hash_combine(size_t& seed, const T& val) const 
    {
        seed = std::hash<T>{}(val) + 0x9e3779b9 + (seed << 6) + (seed >> 2);
    }
} collectItemHasher;

typedef struct collectItemEquality_s {
    bool operator()(const VccbStatisticsTemporaryCollect_type& lhs, const VccbStatisticsTemporaryCollect_type& rhs) const
    {
        if (lhs.mFamily != rhs.mFamily) return false;
        else if (lhs.mType != rhs.mType) return false;
        else if (lhs.valueType != rhs.valueType) return false;
        else 
        {
            for (int i = 0; i < MAX_VCCB_STAT_KEY_NUM; i++)
            {
                if (lhs.key[i] != rhs.key[i]) return false;
            }

            return true;
        }
    }
} collectItemEquality;

void VCCB_NSA_PegIntraSnPscellChange(callInfo_type &call, int type);
void VCCB_NSA_PegInterSnPscellChange(callInfo_type &call, int type);
void VCCB_NSA_PegSgnbAddIntraLteHoNoSgnbChg(callInfo_type &call, int type);
void VCCB_NSA_PegSgnbAddMnHoInterEnb(callInfo_type &call, int type);
void VCCB_NSA_PegSgnbAddMnHoIntraEnb(callInfo_type &call, int type);
void VCCB_NSA_PegSgnbAddSgnbChg(callInfo_type &call, int type);

void FnVCCB_CollectStatCSL_HOTIME(callInfo_type *ptCi, int mFamily, int mType, float updateValue);
void FnVCCB_UpdateHandoverInfoCsl(callInfo_type &rCall, uint8_t &cnt, uint16_t &sumTimeTotal);

void FnVCCB_CollectDrbSetupTime(callInfo_type *ptCi);

#define VCCB_CSL_RRC_SETUP_TIME_MAX         65534
#define VCCB_CSL_DRB_SETUP_TIME_MAX         65534
#define VCCB_CSL_DRB_SETUP_TIME_CNT_MAX       128

void FnVCCB_CollectStatCSL_RrcSetupTime(callInfo_type *ptCi, float timeElapsedInMilliSecond);
void FnVCCB_CollectStatCSL_DrbSetupTime(callInfo_type *ptCi, float timeElapsedInMilliSecond);
void FnVCCB_CollectPmccAdditionalServiceBorderAttForIratHo(
    callInfo_type *ptCi, VccbPmMultiCollect_type *pPmMultiCollect, int mFamily, int mActualFamily, int pmType);

// Only for Handover Target 
int16_t FnVCCB_GetHandInAllDrbsServiceType(callInfo_type *ptCi, std::set<uint32_t> &serviceTypeListResultSet);
int16_t FnVCCB_GetHandInDrbsServiceType(callInfo_type *ptCi, std::set<uint32_t> &serviceTypeListResultSet);
void FnVCCB_GetHandInFailedDrbsServiceType(callInfo_type *ptCi, enumHoStatType type);

void FnVCCB_StatSaHandOutEutraFreqServiceType(callInfo_type *ptCi, enumHoStatType type, const char *fnName);
void FnVCCB_StatSaHandoverOutgoing_EutraFreqBaseStatistic(callInfo_type *ptCi, enumHoStatType type, const char *fnName);
STAT_PM_FAMILY_ID_TYPE FnVCCB_GetSaHandOutServiceTypeFamilyId(callInfo_type *ptCi);
void FnVCCB_StatSaHandOutServiceType(callInfo_type *ptCi, enumHoStatType type, const char *fnName);
void FnVCCB_StatSaHandOutFreqServiceType(callInfo_type *ptCi, enumHoStatType type, uint32_t tgtSsbFreq, const char *fnName);
void FnVCCB_StatSaHandInServiceType(callInfo_type *ptCi, enumHoStatType type, const char *fnName);
void FnVCCB_StatRedirectionServiceType(callInfo_type *ptCi, STAT_PM_FAMILY_ID_TYPE mFamily, int mType);

// FGR-CC3501 
void FnVCCB_PeriodicStat_SaCellDrbConnPlmnSlice(VccbGnbInfo_type *pGnb, VccbCellInfo_type *pCell);

#ifdef HOST_SIM
void FnVCCB_SetgAuditCallCountVmIndex(uint32_t index);
#endif

#endif
