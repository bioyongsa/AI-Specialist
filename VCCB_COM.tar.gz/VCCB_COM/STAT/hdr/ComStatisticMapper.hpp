#ifndef ComStatisticMapper_HPP
#define ComStatisticMapper_HPP
#include "VccbDefine.h"
#include <optional>

/**
 * @file        : ComStatisticMapper.hpp
 * @brief       : header of interface for ComStatisticMapper
 *
 * @author      : k.hernas@samsung.com
 * @date        : 2024/03/01
 *
 * Copyright 2024 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

std::optional<int> getValueCpFailMap(enumStatEndcAddDetailedCpFail_type);
std::optional<int> getValueSpCellSelFailPerCandidateMap(enumStatSpCellSelectionFailCause_type);
std::optional<int> getValueSpCellSelFailMap(enumStatSpCellSelectionFailCause_type);
std::optional<int> getValueInvalidCellMap(enumStatSpCellSelectionFailCause_type);
std::optional<int> getValueSpCellSelFailPriorityMap(int typeId);
std::optional<int> getValueSpCellSelFailPerCandidateIndexMap(int typeId);
int getSizeSpCellSelFailPerCandidateIndexMap();
std::optional<int> getKeySpCellSelFailPerCandidateIndexMap(int priority);

typedef enum
{
    InvalidCellCauseUENotSupFreqBand = 0,
    InvalidCellCauseSpid             = 1,

    INVALID_CELL_ENDC_ADD_PER_GNB_CAUSE_END
} INVALID_CELL_ENDC_ADD_PER_GNB_CAUSE_ITEM;

#endif
