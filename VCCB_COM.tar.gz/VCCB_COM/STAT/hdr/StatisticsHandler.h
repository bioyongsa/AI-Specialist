#ifndef STATISTICSHANDLER_H
#define STATISTICSHANDLER_H

#include "VpmInterface.h"
#include "VccbDefine.h"
#include "VccbStruct.h"
#include "StatIndexMapper.h"

#include "ComMacro.h"
#include "ComInclude.h"
#include "ComLibStatistic.h"
#include "ComLibUtility.h"

#include <map>
#include <vector>
#include <string>

/*
1. make sure that the original family and the changed family are defined in StatIndexMapper, respectively.
    i.e)
    FOO.VF_BasicOperation_IndexgNBDUId is ON
    original Family : STAT_HO_IN
    changed Family: STAT_HO_IN_DU_ID

    void makeStatIndexMap(void)
        ...
        wrapperStatMap()[STAT_HO_IN] = {INDEX_gNB_ID, INDEX_CellIdentity, INDEX_HoPurpose};
        wrapperStatMap()[STAT_HO_IN_DU_ID] = {INDEX_gNB_ID, INDEX_gNB_DU_ID, INDEX_CellIdentity, INDEX_HoPurpose};

2. map original Family and changed Family in changeFamly_XXX
    i.e)
    changeFamily_BasicOperation_IndexgNBDUId
        ...
        case STAT_HO_IN:
            rPostFamily = STAT_HO_IN_DU_ID;

3. If the index of the changed family is not in the original family, get new Index in fillStatisticsIndex function.
    i.e)
    INDEX_gNB_DU_ID is newly added in changed Family(STAT_HO_IN_DU_ID)

        switch (postIndexName)
        {
            case INDEX_gNB_DU_ID:
                tempPmKey.keyList[idxNum++] = getDuId(ptCi, cellIdentity);
            ...
*/

typedef struct
{
    unsigned long long value;
    bool isExist;
} StatIndexValue;

class StatisticsHandler
{
private:
    bool changeFamily_MobilityforENDC_InterSnPScellChgPerGnbDuNciCounterFamily(int prevFamily, int& rPostFamily);
    bool changeFamily_BasicOperationforENDC_LGUOnlyCounterFamily(int family, int &rPostFamily);
    bool changeFamily_MobilityforENDC_PerDuCounterFamily(int family, int &rPostFamily);
    bool changeFamily_BearerContextManagementviaE1_UpIdCounterFamily(int prevFamily, int &rPostFamily);
    void changeFamily_CNF(int prevFamily, int &rPostFamily);
    bool changeFamily_BasicOperation_IndexgNBDUId(int family, int &postFamily);
    bool changeFamily_MultipleOperatorRanSupport(int family, int &rPostFamily);
    void changeFamilyAndIndexForFOO(callInfo_type *ptCi, int &rFamily, VccbPmKey_type &rPmKey);
    void changeFamilyAndIndexForRedCap(callInfo_type *ptCi, int &rFamily, VccbPmKey_type &rPmKey);
    void changeFamilyForRedCap(int prevFamily, int& rPostFamily);
    int  checkFamilyForRedCap(callInfo_type *ptCi, int rFamily);

    uint64_t getDuId(callInfo_type *ptCi);
    uint64_t getTgtGnbDuId(callInfo_type *ptCi);
    uint32_t getPlmn();
    uint32_t getPlmnUe(callInfo_type *ptCi);
    uint16_t getCellIdentity(int family, StatIndexValue indexValue[INDEX_END]);
    uint64_t getTriggeredNCI(callInfo_type* ptCi);
    uint64_t getUpId();
    uint64_t getIndexValue(StatIndexValue prevIndexValue[INDEX_END], int postFamily, int postIndexName,
        callInfo_type *ptCi);

    bool isCollectStatForDUID();
    bool isCollectStatForGLOBALID();
    bool isCollectStatForCP();

    uint16_t gnbNum = MAX_GNB_PER_SYS;
    uint16_t endPointIdxForUpId = MAX_GNB_CU_UP_PER_GNB_CU_CP;
    uint16_t cellIdentity = MAX_CELL_IDENTITY;

public:
    StatisticsHandler(uint16_t _gnbNum) : gnbNum(_gnbNum) {}
    StatisticsHandler(uint16_t _gnbNum, uint16_t _endPointIdxForUpId) : gnbNum(_gnbNum), endPointIdxForUpId(_endPointIdxForUpId)  {}
    ~StatisticsHandler() {}
    int16_t fillStatisticsIndex(callInfo_type *ptCi, VccbPmKey_type &rPmKey, int prevFamily, int postFamily);
    void changeFamilyForFOO(int prevFamily, int& rPostFamily);
    void changeFamilyAndIndex(callInfo_type *ptCi, int &rFamily, VccbPmKey_type &rPmKey);
    void changeCounterTypeIdForDerivedFamilies(int& mType, int mActualFamily);



};

#endif
