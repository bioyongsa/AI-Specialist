/**
 * @file        : ComCslCauseMap.h
 * @brief       : header of interface for nr call csl
 *
 * @author      : hohyun.kang@samsung.com
 * @date        : 2019/07/22
 *
 * Copyright 2019 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef VCCB_COM_ComCslCauseMap_H_
#define VCCB_COM_ComCslCauseMap_H_

#include <stdint.h>

/**
 * @brief enumeration for error code of application.
 */
typedef enum
{
    NR_CSL_CAUSE_ERROR_NONE = 0,
    NR_CSL_CAUSE_ERROR_INVALID_PARAMETER = -1,
    NR_CSL_CAUSE_ERROR_OUT_OF_MEMORY = -2,
    NR_CSL_CAUSE_ERROR_PERMISSION_DENIED = -3,
    NR_CSL_CAUSE_ERROR_TIMED_OUT = -4,
    NR_CSL_CAUSE_ERROR_REQUEST_FAILED = -5,
    NR_CSL_CAUSE_ERROR_NOT_CREATED = -6,
    NR_CSL_CAUSE_ERROR_VALIDATION_FAILED = -7,
    NR_CSL_CAUSE_ERROR_MAX = -8
} nr_csl_cause_error_e;

typedef uint32_t cause_t;
typedef uint16_t pmCause_t;

/**
 * @brief make a pm cause map for cp's cause
 * @remarks
 * @return 0 on success, otherwise error value.
 * @retval #NR_CSL_CAUSE_ERROR_NONE Successful
 * @retval #NR_CSL_CAUSE_ERROR_VALIDATION_FAILED Can't find pm type id of cause
 */
nr_csl_cause_error_e nr_csl_cause_make_cp_map(void);

/**
 * @brief make a pm cause map for sa cp's cause
 * @remarks
 * @return 0 on success, otherwise error value.
 * @retval #NR_CSL_CAUSE_ERROR_NONE Successful
 * @retval #NR_CSL_CAUSE_ERROR_VALIDATION_FAILED Can't find pm type id of cause
 */
nr_csl_cause_error_e nr_csl_cause_make_sacp_map(void);

/**
 * @brief make a pm cause map for sa cp's nrdc sn cause
 * @remarks
 * @return 0 on success, otherwise error value.
 * @retval #NR_CSL_CAUSE_ERROR_NONE Successful
 * @retval #NR_CSL_CAUSE_ERROR_VALIDATION_FAILED Can't find pm type id of cause
 */
nr_csl_cause_error_e nr_csl_cause_make_sacp_nrdc_sn_map(void);

/**
 * @brief get a pm cause of cause for cp
 * @remarks
 * @param[in] cause : cause of cp
 * @param[out] pmCause : pm type id of cause
 * @return 0 on success, otherwise error value.
 * @retval #NR_CSL_CAUSE_ERROR_NONE Successful
 * @retval #NR_CSL_CAUSE_ERROR_VALIDATION_FAILED Can't find pm type id of cause
 */
nr_csl_cause_error_e nr_csl_cause_get_cp_pmCause(const cause_t cause, pmCause_t* pmCause);

/**
 * @brief get a pm cause of cause for sa cp
 * @remarks
 * @param[in] cause : cause of sa cp
 * @param[out] pmCause : pm type id of cause
 * @return 0 on success, otherwise error value.
 * @retval #NR_CSL_CAUSE_ERROR_NONE Successful
 * @retval #NR_CSL_CAUSE_ERROR_VALIDATION_FAILED Can't find pm type id of cause
 */
nr_csl_cause_error_e nr_csl_cause_get_sacp_pmCause(const cause_t cause, pmCause_t* pmCause);

/**
 * @brief get a pm cause of cause for sa nrdc sn cp
 * @remarks
 * @param[in] cause : cause of sa nrdc sn cp
 * @param[out] pmCause : pm type id of cause
 * @return 0 on success, otherwise error value.
 * @retval #NR_CSL_CAUSE_ERROR_NONE Successful
 * @retval #NR_CSL_CAUSE_ERROR_VALIDATION_FAILED Can't find pm type id of cause
 */
nr_csl_cause_error_e nr_csl_cause_get_sacp_nrdc_sn_pmCause(const cause_t cause, pmCause_t* pmCause);

/**
 * @brief make a pm cause map for cp's cause for du id stats
 * @remarks
 * @return 0 on success, otherwise error value.
 * @retval #NR_CSL_CAUSE_ERROR_NONE Successful
 * @retval #NR_CSL_CAUSE_ERROR_VALIDATION_FAILED Can't find pm type id of cause
 */
nr_csl_cause_error_e nr_csl_du_id_hex_cause_make_cp_map(void);

/**
 * @brief get a pm cause of cause for cp
 * @remarks
 * @param[in] cause : cause of cp
 * @param[out] pmCause : pm type id of cause
 * @return 0 on success, otherwise error value.
 * @retval #NR_CSL_CAUSE_ERROR_NONE Successful
 * @retval #NR_CSL_CAUSE_ERROR_VALIDATION_FAILED Can't find pm type id of cause
 */
nr_csl_cause_error_e nr_csl_du_id_hex_cause_get_cp_pmCause(const cause_t cause, pmCause_t* pmCause);

/**
 * @brief make a pm cause map for sa cp's nrdc sn cause du id hex
 * @remarks
 * @return 0 on success, otherwise error value.
 * @retval #NR_CSL_CAUSE_ERROR_NONE Successful
 * @retval #NR_CSL_CAUSE_ERROR_VALIDATION_FAILED Can't find pm type id of cause
 */

nr_csl_cause_error_e nr_csl_du_id_hex_cause_make_sacp_nrdc_sn_map(void);

/**
 * @brief get a pm cause of cause for sa nrdc sn cp du id hex
 * @remarks
 * @param[in] cause : cause of sa nrdc sn cp
 * @param[out] pmCause : pm type id of cause
 * @return 0 on success, otherwise error value.
 * @retval #NR_CSL_CAUSE_ERROR_NONE Successful
 * @retval #NR_CSL_CAUSE_ERROR_VALIDATION_FAILED Can't find pm type id of cause
 */
nr_csl_cause_error_e nr_csl_du_id_hex_cause_get_sacp_nrdc_sn_pmCause(const cause_t cause, pmCause_t* pmCause);

/**
 * @brief make a pm cause map for sa cp's redcap cause hex
 * @remarks
 * @return 0 on success, otherwise error value.
 * @retval #NR_CSL_CAUSE_ERROR_NONE Successful
 * @retval #NR_CSL_CAUSE_ERROR_VALIDATION_FAILED Can't find pm type id of cause
 */

nr_csl_cause_error_e nr_csl_redcap_hex_cause_make_sacp_map(void);

/**
 * @brief get a pm cause of cause for sa cp redcap hex
 * @remarks
 * @param[in] cause : cause of sa cp redcap
 * @param[out] pmCause : pm type id of cause
 * @return 0 on success, otherwise error value.
 * @retval #NR_CSL_CAUSE_ERROR_NONE Successful
 * @retval #NR_CSL_CAUSE_ERROR_VALIDATION_FAILED Can't find pm type id of cause
 */
nr_csl_cause_error_e nr_csl_redcap_hex_cause_get_cp_pmCause(const cause_t cause, pmCause_t* pmCause);

#endif /* VCCB_COM_ComCslCauseMap_H_ */
