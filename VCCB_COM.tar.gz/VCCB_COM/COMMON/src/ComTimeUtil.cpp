#include "ComTimeUtil.h"

#include <sys/time.h>
#include "ComInclude.h"

/**
 * @fn timespec_diff(struct timespec *, struct timespec *, struct timespec *)
 * @brief Compute the diff of two timespecs, that is a - b = result.
 * @param a the minuend
 * @param b the subtrahend
 * @param result a - b
 */
static inline void timespec_diff(const struct timespec &a, const struct timespec &b, struct timespec &result)
{
    result.tv_sec = a.tv_sec - b.tv_sec;
    result.tv_nsec = a.tv_nsec - b.tv_nsec;
    if (result.tv_nsec < 0)
    {
        --result.tv_sec;
        result.tv_nsec += 1000000000L;
    }
}

int ComTimeUtil::get_current_time(struct timespec &ts)
{
    if (clock_gettime(CLOCK_REALTIME, &ts) < 0)
    {
        char errBuf[256];
        strerror_r(errno, errBuf, sizeof(errBuf));
        VCCB_PRINT_ERROR("ERROR(%s) in %s\n", errBuf, __func__);
        ts = {0, 0};
        return ERROR;
    }
    return GOOD;
}
int ComTimeUtil::get_current_time(timeval &tv)
{
    struct timespec ts;
    if (clock_gettime(CLOCK_REALTIME, &ts) < 0)
    {
        char errBuf[256];
        strerror_r(errno, errBuf, sizeof(errBuf));
        VCCB_PRINT_ERROR("ERROR(%s) in %s\n", errBuf, __func__);
        tv = {0, 0};
        return ERROR;
    }
    TIMESPEC_TO_TIMEVAL(&tv, &ts);
    return GOOD;
}

struct timespec ComTimeUtil::get_elapsed_time(const struct timespec &past)
{
    struct timespec now, result;
    if (get_current_time(now) < 0)
    {
        result = {0, 0};
        return result;
    }
    return ComTimeUtil::get_elapsed_time(now, past);
}

struct timespec ComTimeUtil::get_elapsed_time(const struct timespec &now, const struct timespec &past)
{
    struct timespec result;
    timespec_diff(now, past, result);
    return result;
}

struct timeval ComTimeUtil::get_elapsed_time(const struct timeval &past)
{
    struct timespec pastTs, resultTs;
    TIMEVAL_TO_TIMESPEC(&past, &pastTs);
    resultTs = ComTimeUtil::get_elapsed_time(pastTs);
    struct timeval resultTv;
    TIMESPEC_TO_TIMEVAL(&resultTv, &resultTs);
    return resultTv;
}

struct timeval ComTimeUtil::get_elapsed_time(const struct timeval &now, const struct timeval &past)
{
    struct timespec tsNow, tsPast, resultTs;
    TIMEVAL_TO_TIMESPEC(&now, &tsNow);
    TIMEVAL_TO_TIMESPEC(&past, &tsPast);
    resultTs = ComTimeUtil::get_elapsed_time(tsNow, tsPast);
    struct timeval resultTv;
    TIMESPEC_TO_TIMEVAL(&resultTv, &resultTs);
    return resultTv;
}

void ComTimeUtil::stopwatch_start(Stopwatch_type &stopwatch)
{
    if (stopwatch.isRunning == true)
    {
        VCCB_PRINT_ERROR("stopwatch is already running ERROR in %s\n", __func__);
        return;
    }
    if (clock_gettime(CLOCK_REALTIME, &stopwatch.startTime) < 0)
    {
        char errBuf[256];
        strerror_r(errno, errBuf, sizeof(errBuf));
        VCCB_PRINT_ERROR("ERROR(%s) in %s\n", errBuf, __func__);
        stopwatch.startTime = {0, 0};
        return;
    }
    stopwatch.isRunning = true;
    return;
}

struct timespec ComTimeUtil::stopwatch_stop(Stopwatch_type &stopwatch)
{
    if (stopwatch.isRunning == false) return {-1, -1};
    struct timespec timeElapsed = stopwatch_get_elapsed_time(stopwatch);
    stopwatch.isRunning = false;
    stopwatch.startTime = {0, 0};
    return timeElapsed;
}

struct timespec ComTimeUtil::stopwatch_get_elapsed_time(const Stopwatch_type &stopwatch)
{
    if (stopwatch.isRunning == false)
    {
        VCCB_PRINT_ERROR("stopwatch is not running ERROR in %s\n", __func__);
        return {-1, -1};
    }
    const struct timespec &timeBefore = stopwatch.startTime;
    struct timespec timeAfter;
    if (clock_gettime(CLOCK_REALTIME, &timeAfter) < 0)
    {
        char errBuf[256];
        strerror_r(errno, errBuf, sizeof(errBuf));
        VCCB_PRINT_ERROR("ERROR(%s) in %s\n", errBuf, __func__);
        return {-1, -1};
    }
    struct timespec timeElapsed;
    timespec_diff(timeAfter, timeBefore, timeElapsed);
    return timeElapsed;
}
