/**
 * @file        VlibIpcApi.c
 * @brief       functions for printing log and sending IPC
 */

/*----------------------------------------------------------------------------
 * Define    :    Include Header Files
 * ---------------------------------------------------------------------------
 */
#include "ComLibIpcApi.h"

#include "ComInclude.h"
#include "ComEndian.h"
#include "ComLibUtility.h"

#define VCCB_MAKE_MDS_ADDR(__mdsAddr, __port, __mdsIp)                              \
    do                                                                              \
    {                                                                               \
        int16_t _rc = FnVCCB_MakeMdsAddr(#__mdsAddr, &__mdsAddr, __port, &__mdsIp); \
        if (_rc == ERROR)                                                           \
        {                                                                           \
            VCCB_PRINT_ERROR("FnVCCB_MakeMdsAddr ERROR!\n");                        \
            return ERROR;                                                           \
        }                                                                           \
    } while (0);

void FnVCCB_PrintMdsAddrV4(const char *pStrMdsAddrName, const unsigned int V4, const unsigned short port)
{
    VALID_E_POINT_CHECK_VOID(pStrMdsAddrName);

    union
    {
        unsigned int value;
        uint8_t byteData[4];
    } converter;

    converter.value = htobe32(V4);

    VCCB_PRINTF("%s : IP = %u.%u.%u.%u, port = %u\n", pStrMdsAddrName, converter.byteData[0], converter.byteData[1],
        converter.byteData[2], converter.byteData[3], port);
}

void FnVCCB_PrintMdsAddrV6(const char *pStrMdsAddrName, const unsigned char V6[IPV6_ADDRLEN], const unsigned short port)
{
    VALID_E_POINT_CHECK_VOID(pStrMdsAddrName);

    VCCB_PRINTF("%s : IP = %02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x, port = %u\n",
        pStrMdsAddrName, V6[0], V6[1], V6[2], V6[3], V6[4], V6[5], V6[6], V6[7], V6[8], V6[9], V6[10], V6[11], V6[12],
        V6[13], V6[14], V6[15], port);
}

int16_t FnVCCB_MakeMdsAddr(const char *pStrMdsAddrName, MdsAddr_Type *pMdsAddr, unsigned short port, MdsIp_Type *pMdsIp)
{
    VALID_E_POINT_CHECK_ERROR(pStrMdsAddrName);
    VALID_E_POINT_CHECK_ERROR(pMdsAddr);
    VALID_E_POINT_CHECK_ERROR(pMdsIp);

    int rc = 0;

    if (pMdsIp->IpVer == MDS_IPV4)
    {
        if ((rc = mdsMakeMdsAddr(pMdsAddr, port, "V4-%d", pMdsIp->Ip.V4)) < 0)
        {
            mdsPrintError(rc);
            return ERROR;
        }
    }
    else
    {
        if ((rc = mdsMakeMdsAddr(pMdsAddr, port, "V6-%ld", pMdsIp->Ip.V6)) < 0)
        {
            mdsPrintError(rc);
            return ERROR;
        }
    }

    return GOOD;
}

void FnVCCB_PrintMdsIpV4(const char *pStrMdsAddrName, int unitId, const unsigned int V4)
{
    VALID_E_POINT_CHECK_VOID(pStrMdsAddrName);

    union
    {
        unsigned int value;
        uint8_t byteData[4];
    } converter;

    converter.value = htobe32(V4);

    VCCB_PRINTF("%s[%d] : IP = %u.%u.%u.%u\n", pStrMdsAddrName, unitId, converter.byteData[0], converter.byteData[1],
        converter.byteData[2], converter.byteData[3]);
}

void FnVCCB_PrintMdsIpV6(const char *pStrMdsAddrName, int unitId, const unsigned char V6[IPV6_ADDRLEN])
{
    VALID_E_POINT_CHECK_VOID(pStrMdsAddrName);

    VCCB_PRINTF("%s[%d] : IP = %02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x\n",
        pStrMdsAddrName, unitId, V6[0], V6[1], V6[2], V6[3], V6[4], V6[5], V6[6], V6[7], V6[8], V6[9], V6[10], V6[11],
        V6[12], V6[13], V6[14], V6[15]);
}

void FnVCCB_PrintMdsIp(enumNode blockId, int unitId, const MdsIp_Type &rMdsIp)
{
    const char *blockName = getNodeName(blockId);
    VALID_E_POINT_CHECK_VOID(blockName);
    if (rMdsIp.IpVer == MDS_IPV4)
    {
        FnVCCB_PrintMdsIpV4(blockName, unitId, rMdsIp.Ip.V4);
    }
    else if (rMdsIp.IpVer == MDS_IPV6)
    {
        FnVCCB_PrintMdsIpV6(blockName, unitId, rMdsIp.Ip.V6);
    }
    else
    {
        VCCB_PRINTF("[%s] MdsIpType Error(%d)\n", __func__, rMdsIp.IpVer);
    }
}

static inline int VLIB_GetIpWithRetry(int (*fp)(int), int unitId)
{
    AUTO_TRACE_FUNC;
    int status;
    while (1)
    {
        status = fp(unitId);
        if (GOOD != status)
        {
            if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
            {
                VCCB_PRINTF("%s ERROR\n", __FUNCTION__);
                thsSleep(VCCB_RETRY_WAIT_TIME * 1000);
            }
            else
            {
                break;
            }
        }
        else
        {
            break;
        }
    }

    return status;
}

/**
 * @brief   Get VCCB ip and port
 */
int VLIB_GetVccbIpAndPort(void)
{
    AUTO_TRACE_FUNC;

    int rc;
    unsigned short destPort = 0;
    MdsIp_Type vccbSourceIp;
    uint16_t loop;
    MdsResolveIp_Type resolveIp;

    if ((rc = mdsGetSrcIp(&vccbSourceIp, MDS_ATTR_IP_TYPE_IIIP, NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsGetSrcIp ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }

    if (e_VCCB_ACPF_VNF == VCOM_getSystemType())
    {
        if ((rc = mdsResolveIp(vccbSourceIp, MDS_ATTR_IP_TYPE_IIIP, &resolveIp)) < 0)
        {
            VCCB_PRINTF("[%s]mdsResolveIp ERROR(%d)\n", __FUNCTION__, rc);
            mdsPrintError(rc);
            return ERROR;
        }
        CFG->vm.unitType = (uint16_t)resolveIp.Info.vRan.UnitType;
        CFG->vm.unitId = (uint16_t)resolveIp.Info.vRan.UnitId;
    }

    // VCCB_ADDR
    if ((rc = mdsMakePort(&destPort, (uint16_t)(VCCB_INT_OUTMOST_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }
    VCCB_MAKE_MDS_ADDR(VCCB_ADDR, destPort, vccbSourceIp);

    // VCCB_EXT_ADDR
    if ((rc = mdsMakePort(&destPort, (uint16_t)(VCCB_EXT_OUTMOST_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }
    VCCB_MAKE_MDS_ADDR(VCCB_EXT_ADDR, destPort, vccbSourceIp);

    // VCCB_CALL_ADDR
    for (loop = 0; loop < MAX_CALL_THREAD_NUM_VCCB; loop++)
    {
        if ((rc = mdsMakePort(&destPort, (uint16_t)(VCCB_INT_CALL_MBOX + loop + DBG->offsetPort), NULL)) < 0)
        {
            VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
            mdsPrintError(rc);

            return ERROR;
        }
        VCCB_MAKE_MDS_ADDR(VCCB_CALL_ADDR[loop], destPort, vccbSourceIp);
    }

    // VCCB_MGMT_ADDR
    if ((rc = mdsMakePort(&destPort, (uint16_t)(VCCB_INT_MGMT_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }
    VCCB_MAKE_MDS_ADDR(VCCB_MGMT_ADDR, destPort, vccbSourceIp);

    // VCCB_PLD_ADDR
    if ((rc = mdsMakePort(&destPort, (uint16_t)(VCCB_INT_PLD_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }
    VCCB_MAKE_MDS_ADDR(VCCB_PLD_ADDR, destPort, vccbSourceIp);

    // VCCB_KA_ADDR
    if ((rc = mdsMakePort(&destPort, (uint16_t)(VCCB_INT_KA_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }
    VCCB_MAKE_MDS_ADDR(VCCB_KA_ADDR, destPort, vccbSourceIp);

    // VCCB_LOG_ADDR
    if ((rc = mdsMakePort(&destPort, (uint16_t)(VCCB_INT_LOG_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }
    VCCB_MAKE_MDS_ADDR(VCCB_LOG_ADDR, destPort, vccbSourceIp);

#ifdef __CNF__
    if (CNF_HA_SUPPORT == ENV->isSupportHA)
    {
        // ENV->addr.vccbRedisRestore
        if ((rc = mdsMakePort(&destPort, (uint16_t)(VCCB_REDIS_RESTORE_MBOX + DBG->offsetPort), NULL)) < 0)
        {
            VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
            mdsPrintError(rc);

            return ERROR;
        }
        VCCB_MAKE_MDS_ADDR(ENV->addr.vccbRedisRestore, destPort, vccbSourceIp);
    }
#endif

    // VCCB_NONUE_ADDR
    if ((rc = mdsMakePort(&destPort, (uint16_t)(VCCB_EXT_NONUE_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }
    VCCB_MAKE_MDS_ADDR(VCCB_NONUE_ADDR, destPort, vccbSourceIp);

    // VCCB_NONUE_BIGMSG_ADDR
    if ((rc = mdsMakePort(&destPort, (uint16_t)(VCCB_EXT_NONUE_BIGMSG_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }
    VCCB_MAKE_MDS_ADDR(VCCB_NONUE_BIGMSG_ADDR, destPort, vccbSourceIp);

    // VCCB_NONUE_ASN1_ADDR
    if ((rc = mdsMakePort(&destPort, (uint16_t)(VCCB_EXT_NONUE_ASN1_MBOX_01 + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }
    VCCB_MAKE_MDS_ADDR(VCCB_NONUE_ASN1_ADDR, destPort, vccbSourceIp);

    // VCCB_STATISTICS_ADDR
    if ((rc = mdsMakePort(&destPort, (uint16_t)(VCCB_INT_STATISTICS_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }
    VCCB_MAKE_MDS_ADDR(VCCB_STATISTICS_ADDR, destPort, vccbSourceIp);

    // SVR26A FGR-CC3103 IODT RACS(UE Radio Capability Signaling Optimization)
    // VCCB_EXT_RACS_BIGMSG_ADDR
    if ((rc = mdsMakePort(&destPort, (uint16_t)(VCCB_EXT_RACS_BIGMSG_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }
    VCCB_MAKE_MDS_ADDR(VCCB_EXT_RACS_BIGMSG_ADDR, destPort, vccbSourceIp);

    // VCCB_INT_RACS_ADDR
    if ((rc = mdsMakePort(&destPort, (uint16_t)(VCCB_INT_RACS_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }
    VCCB_MAKE_MDS_ADDR(VCCB_INT_RACS_ADDR, destPort, vccbSourceIp);

    // VCCB_INT_RACS_BIGMSG_ADDR
    for (loop = 0; loop < VCCB_INT_RACS_BIGMSG_MBOX_MAX_NUM; loop++)     // current : 2
    {
        if ((rc = mdsMakePort(&destPort, (uint16_t)(VCCB_INT_RACS_BIGMSG_MBOX_01 + loop + DBG->offsetPort), NULL)) < 0)
        {
            VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
            mdsPrintError(rc);

            return ERROR;
        }
        VCCB_MAKE_MDS_ADDR(VCCB_INT_RACS_BIGMSG_ADDR[loop], destPort, vccbSourceIp);
    }

    return GOOD;
}

int FnVCCB_IsActivePod(const int podType, const int podId)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_FALSE(podId, VCCB_MAX_HA_UNIT_NUM);
    VccbEnvInfo_type &rEnv = *ENV;

    switch (podType)
    {
        case CIP:
            if (rEnv.podInfo.cip[podId].redundancyState == RedunState_active ||
                rEnv.podInfo.cip[podId].redundancyState == RedunState_single)
            {
                return TRUE;
            }
            break;
        case CSP:
            if (rEnv.podInfo.csp[podId].redundancyState == RedunState_active ||
                rEnv.podInfo.csp[podId].redundancyState == RedunState_single)
            {
                return TRUE;
            }
            break;
        case CMP:
            if (rEnv.podInfo.cmp[podId].redundancyState == RedunState_active ||
                rEnv.podInfo.cmp[podId].redundancyState == RedunState_single)
            {
                return TRUE;
            }
            break;
        default:
            VCCB_PRINTF("[%s] podType(%d) is not supported\n", __FUNCTION__, podType);
            break;
    }
    return FALSE;
}

int32_t FnVCCB_GetActivePodId(uint16_t podType)
{
    AUTO_TRACE_FUNC;

    switch (podType)
    {
        case CIP:
        case CSP:
        case CMP:
            for (int podId = 0; podId < VCCB_MAX_HA_UNIT_NUM; podId++)
            {
                if (FnVCCB_IsActivePod(podType, podId))
                {
                    return podId;
                }
            }
            break;
        case CTP: // POD is operating in multiple mode. Return id of a CTP leader.
        case SNP: // POD is currently operating in single duplex.
            return 0;
        default:
            VCCB_PRINTF("[%s] podType(%d) is not supported\n", __FUNCTION__, podType);
            break;
    }
    return VCCB_UNKNOWN_POD_ID;
}

/**
 * @brief   Get VNMB ip and port
 */
int FnVCCB_GetVnmbIpAndPort(const int unitId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(unitId, 0, VCCB_MAX_HA_UNIT_NUM - 1);

    int rc;
    MdsIp_Type destIp;
    unsigned short destPort = 0;
    uint16_t loop;

    rc = VLIB_getMdsIp(&destIp, BLOCK_VNMB, unitId);
    if (rc < 0)
    {
        VCCB_PRINTF("[%s]VLIB_getMdsIp BLOCK_VNMB[%d] ERROR(%d)\n", __FUNCTION__, unitId, rc);
        mdsPrintError(rc);
        return ERROR;
    }

    if (MdsIp_TypeCmp(&destIp, &VNMB_ADDR[unitId].MdsIp) == 0)
    {
        return BREAK;
    }

    if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
    {
        // Ip is changed. there is need to get a new nano handle.
        ENV->podInfo.cip[unitId].nanoUpdateRequiredFlag = VCCB_FLAG_ON;
    }

    //-------------- VNMB MAIN MBOX -------------
    // Make port from MBOX-ID
    if ((rc = mdsMakePort(&destPort, (uint16_t)(VNMB_INT_MAIN_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }

    // Make destination Address which consists of IP and Port

    VCCB_MAKE_MDS_ADDR(VNMB_ADDR[unitId], destPort, destIp);

    //-------------- VNMB CALL MBOX -------------
    // VNMB CALL THREAD
    for (loop = 0; loop < VNMB_CALL_THREAD_NUM; loop++)
    {
        if ((rc = mdsMakePort(&destPort, (uint16_t)(VNMB_INT_CALL_MBOX + loop + DBG->offsetPort), NULL)) < 0)
        {
            VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
            mdsPrintError(rc);

            return ERROR;
        }

        VCCB_MAKE_MDS_ADDR(VNMB_CALL_ADDR[unitId][loop], destPort, destIp);
    }

    //-------------- VNMB TRANSFER MBOX -------------
    if ((rc = mdsMakePort(&destPort, (uint16_t)(VNMB_INT_TRANSFER_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }
    VCCB_MAKE_MDS_ADDR(VNMB_TRANSFER_ADDR[unitId], destPort, destIp);

    //-------------- VNMB PAGING MBOX -------------
    // VNMB PAGING THREAD
    for (loop = 0; loop < VNMB_PAGING_THREAD_NUM; loop++)
    {
        if ((rc = mdsMakePort(&destPort, (uint16_t)(VNMB_INT_PAGING_MBOX + loop + DBG->offsetPort), NULL)) < 0)
        {
            VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
            mdsPrintError(rc);

            return ERROR;
        }

        VCCB_MAKE_MDS_ADDR(VNMB_PAGING_ADDR[unitId][loop], destPort, destIp);
    }

    //-------------- VNMB CBRS MBOX -------------
    if ((rc = mdsMakePort(&destPort, (uint16_t)(VNMB_INT_CBRS_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }
    VCCB_MAKE_MDS_ADDR(VNMB_CBRS_ADDR[unitId], destPort, destIp);


    // SVR26A FGR-CC3103 IODT RACS(UE Radio Capability Signaling Optimization)
    //-------------- VNMB RACS MBOX -------------
    if ((rc = mdsMakePort(&destPort, (uint16_t)(VNMB_INT_RACS_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }
    VCCB_MAKE_MDS_ADDR(VNMB_RACS_BIGMSG_ADDR[unitId], destPort, destIp);

    VCCB_PRINTF("Successfully updated Vnmb[%d] IP/PORT\n", unitId);
    FnVCCB_PrintMdsIp(BLK_VNMB, unitId, destIp);
    return GOOD;
}

/**
 * @brief   Get VCSB ip and port
 */
int FnVCCB_GetVcsbIpAndPort(const int unitId)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(unitId, 0, VCCB_MAX_HA_UNIT_NUM - 1);

    int rc;
    MdsIp_Type destIp;
    unsigned short destPort = 0;

    rc = VLIB_getMdsIp(&destIp, BLOCK_VCSB, unitId);
    if (rc < 0)
    {
        VCCB_PRINTF("[%s]VLIB_getMdsIp BLOCK_VCSB[%d] ERROR(%d)\n", __FUNCTION__, unitId, rc);
        mdsPrintError(rc);
        return ERROR;
    }

    //-------------- VCSB MAIN MBOX -------------
    // Make port from MBOX-ID
    if ((rc = mdsMakePort(&destPort, (uint16_t)(VCSB_INT_MAIN_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }

    // Make destination Address which consists of IP and Port
    VCCB_MAKE_MDS_ADDR(VCSB_ADDR[unitId], destPort, destIp);

    VCCB_PRINTF("Successfully updated Vcsb[%d] IP/PORT\n", unitId);
    FnVCCB_PrintMdsIp(BLK_VCSB, unitId, destIp);
    return GOOD;
}


/**
 * @brief   Get VNLB ip and port
 */
#define MAX_GNB_PER_SYS_8   8
int FnVCCB_GetVnlbIpAndPort(const int unitId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(unitId, 0, VCCB_MAX_HA_UNIT_NUM - 1);

    int rc;
    MdsIp_Type destIp;
    unsigned short destPort = 0;
    uint16_t loop;

    rc = VLIB_getMdsIp(&destIp, BLOCK_VNLB, unitId);
    if (rc < 0)
    {
        VCCB_PRINTF("[%s]VLIB_getMdsIp BLOCK_VNLB[%d] ERROR(%d)\n", __FUNCTION__, unitId, rc);
        return ERROR;
    }

    if (MdsIp_TypeCmp(&destIp, &VNLB_SCTP_E1_ADDR[unitId][0].MdsIp) == 0)
    {
        return BREAK;
    }

    if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
    {
        // Ip is changed. there is need to get a new nano handle.
        ENV->podInfo.csp[unitId].nanoUpdateRequiredFlag = VCCB_FLAG_ON;
    }

    //-------------- VNLB E1AP MBOX -------------
    for (loop = 0; loop < MAX_GNB_PER_SYS; loop++)
    {
        uint16_t baseMbox = (loop < MAX_GNB_PER_SYS_8) ? VNLB_INT_E1_DATA_REQ_MBOX : (VNLB_INT_E1_DATA_REQ_MBOX_8 - MAX_GNB_PER_SYS_8);

        // Make port from MBOX-ID
        if ((rc = mdsMakePort(&destPort, (uint16_t)(baseMbox + loop + DBG->offsetPort), NULL)) < 0)
        {
            VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
            mdsPrintError(rc);

            return ERROR;
        }

        // Make destination Address which consists of IP and Port
        VCCB_MAKE_MDS_ADDR(VNLB_SCTP_E1_ADDR[unitId][loop], destPort, destIp);
    }

    //-------------- VNLB F1AP MBOX -------------
    for (loop = 0; loop < MAX_GNB_PER_SYS; loop++)
    {
        uint16_t baseMbox = (loop < MAX_GNB_PER_SYS_8) ? VNLB_INT_F1_DATA_REQ_MBOX : (VNLB_INT_F1_DATA_REQ_MBOX_8 - MAX_GNB_PER_SYS_8);

        // Make port from MBOX-ID
        if ((rc = mdsMakePort(&destPort, (uint16_t)(baseMbox + loop + DBG->offsetPort), NULL)) < 0)
        {
            VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
            mdsPrintError(rc);

            return ERROR;
        }

        // Make destination Address which consists of IP and Port
        VCCB_MAKE_MDS_ADDR(VNLB_SCTP_F1_ADDR[unitId][loop], destPort, destIp);
    }

    //-------------- VNLB X2AP MBOX -------------
    for (loop = 0; loop < MAX_GNB_PER_SYS; loop++)
    {
        uint16_t baseMbox = (loop < MAX_GNB_PER_SYS_8) ? VNLB_INT_X2_DATA_REQ_MBOX : (VNLB_INT_X2_DATA_REQ_MBOX_8 - MAX_GNB_PER_SYS_8);

        // Make port from MBOX-ID
        if ((rc = mdsMakePort(&destPort, (uint16_t)(baseMbox + loop + DBG->offsetPort), NULL)) < 0)
        {
            VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
            mdsPrintError(rc);

            return ERROR;
        }

        // Make destination Address which consists of IP and Port
        VCCB_MAKE_MDS_ADDR(VNLB_SCTP_X2_ADDR[unitId][loop], destPort, destIp);
    }

    //-------------- VNLB NGAP MBOX -------------
    for (loop = 0; loop < MAX_GNB_PER_SYS; loop++)
    {
        uint16_t baseMbox = (loop < MAX_GNB_PER_SYS_8) ? VNLB_INT_NG_DATA_REQ_MBOX : (VNLB_INT_NG_DATA_REQ_MBOX_8 - MAX_GNB_PER_SYS_8);

        // Make port from MBOX-ID
        if ((rc = mdsMakePort(&destPort, (uint16_t)(baseMbox + loop + DBG->offsetPort), NULL)) < 0)
        {
            VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
            mdsPrintError(rc);

            return ERROR;
        }

        // Make destination Address which consists of IP and Port
        VCCB_MAKE_MDS_ADDR(VNLB_SCTP_NG_ADDR[unitId][loop], destPort, destIp);
    }

    //-------------- VNLB XNAP MBOX -------------
    for (loop = 0; loop < MAX_GNB_PER_SYS; loop++)
    {
        uint16_t baseMbox = (loop < MAX_GNB_PER_SYS_8) ? VNLB_INT_XN_DATA_REQ_MBOX : (VNLB_INT_XN_DATA_REQ_MBOX_8 - MAX_GNB_PER_SYS_8);

        // Make port from MBOX-ID
        if ((rc = mdsMakePort(&destPort, (uint16_t)(baseMbox + loop + DBG->offsetPort), NULL)) < 0)
        {
            VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
            mdsPrintError(rc);

            return ERROR;
        }

        // Make destination Address which consists of IP and Port
        VCCB_MAKE_MDS_ADDR(VNLB_SCTP_XN_ADDR[unitId][loop], destPort, destIp);
    }

    //------------ VNLB INT MAIN MBOX -----------
    // Make port from MBOX-ID
    if ((rc = mdsMakePort(&destPort, (uint16_t)(VNLB_INT_MAIN_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }

    // Make destination Address which consists of IP and Port
    VCCB_MAKE_MDS_ADDR(VNLB_ADDR[unitId], destPort, destIp);

    VCCB_PRINTF("Successfully updated Vnlb[%d] IP/PORT\n", unitId);
    FnVCCB_PrintMdsIp(BLK_VNLB, unitId, destIp);
    return GOOD;
}
#undef MAX_GNB_PER_SYS_8

/**
 * @brief   Get VTMB ip and port
 */
int FnVCCB_GetVtmbIpAndPort(const int unitId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(unitId, 0, VCCB_GetMaxVtmbUnits() - 1);

    int rc;
    MdsIp_Type destIp;
    unsigned short destPort = 0;

    const uint16_t TRACE_MANAGER_RECV_MBOX_LIST[MAX_VTMB_TRACE_THREAD_NUM] = {
        VTMB_TRACE_MANAGER_RECV_MBOX,
        VTMB_TRACE_MANAGER_2_RECV_MBOX,
        VTMB_TRACE_MANAGER_3_RECV_MBOX,
        VTMB_TRACE_MANAGER_4_RECV_MBOX,
        VTMB_TRACE_MANAGER_5_RECV_MBOX,
#ifdef __CNF__
        VTMB_TRACE_MANAGER_6_RECV_MBOX
#endif
    };

    rc = VLIB_getMdsIp(&destIp, BLOCK_VTMB, unitId);
    if (rc < 0)
    {
        VCCB_PRINTF("[%s]VLIB_getMdsIp BLOCK_VTMB[%d] ERROR(%d)\n", __FUNCTION__, unitId, rc);
        mdsPrintError(rc);

        return ERROR;
    }

    if (MdsIp_TypeCmp(&destIp, &VTMB_ADDR[unitId].MdsIp) == 0)
    {
        return BREAK;
    }

    if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
    {
        // Ip is changed. there is need to get a new nano handle.
        ENV->podInfo.ctp[unitId].nanoUpdateRequiredFlag = VCCB_FLAG_ON;
    }

    const unsigned short vtmbCslHandlerMboxId = VTMB_CSL_HANDLER_MANAGER_RECV_MBOX;
    if ((rc = mdsMakePort(&destPort, (uint16_t)(vtmbCslHandlerMboxId + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }

    // Make destination Address which consists of IP and Port
    VCCB_MAKE_MDS_ADDR(VTMB_ADDR[unitId], destPort, destIp);

    for (uint8_t idx=0; idx<MAX_VTMB_TRACE_THREAD_NUM; ++idx)
    {
        if ((rc = mdsMakePort(&destPort, static_cast<uint16_t>(TRACE_MANAGER_RECV_MBOX_LIST[idx] + DBG->offsetPort), NULL)) < 0)
        {
            VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
            mdsPrintError(rc);

            return ERROR;
        }
        // Make destination Address which consists of IP and Port
        VCCB_MAKE_MDS_ADDR(VTMB_ADDR_TRACE[unitId][idx], destPort, destIp);
    }

    // on CNF open only to ctp0-0
    if ((e_VCCB_ACPF_CNF == VCOM_getSystemType() && unitId == 0) || (e_VCCB_ACPF_CNF != VCOM_getSystemType()))
    {
        if ((rc = mdsMakePort(&destPort, (uint16_t)(VTMB_MAIN_RECV_MBOX + DBG->offsetPort), NULL)) < 0)
        {
            VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
            mdsPrintError(rc);

            return ERROR;
        }

        // Make destination Address which consists of IP and Port
        VCCB_MAKE_MDS_ADDR(VTMB_MAIN_ADDR[unitId], destPort, destIp);
    }

    if ((rc = mdsMakePort(&destPort, (uint16_t)(VTMB_MDT_MANAGER_RECV_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }

    // Make destination Address which consists of IP and Port
    VCCB_MAKE_MDS_ADDR(VTMB_ADDR_MDT[unitId], destPort, destIp);

    VCCB_PRINTF("Successfully updated Vtmb[%d] IP/PORT\n", unitId);
    FnVCCB_PrintMdsIp(BLK_VTMB, unitId, destIp);
    return GOOD;
}

/**
 * @brief   Get OSAB ip and port
 */
int FnVCCB_GetOsabIpAndPort(const int unitId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(unitId, 0, VCCB_MAX_HA_UNIT_NUM - 1);

    int rc;
    MdsIp_Type destIp;
    unsigned short destPort = 0;

    rc = VLIB_getMdsIp(&destIp, BLOCK_OSAB, unitId);
    if (rc < 0)
    {
        VCCB_PRINTF("[%s]VLIB_getMdsIp BLOCK_OSAB[%d] ERROR(%d)\n", __FUNCTION__, unitId, rc);
        mdsPrintError(rc);
        return ERROR;
    }

    if (MdsIp_TypeCmp(&destIp, &OSAB_ADDR_ANR[unitId].MdsIp) == 0)
    {
        return BREAK;
    }

    if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
    {
        // Ip is changed. there is need to get a new nano handle.
        ENV->podInfo.cmp[unitId].nanoUpdateRequiredFlag = VCCB_FLAG_ON;
    }

    if ((rc = mdsMakePort(&destPort, SONA_INT_ANR_CALL_MBOX_ID, NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }
    // Make destination Address which consists of IP and Port
    VCCB_MAKE_MDS_ADDR(OSAB_ADDR_ANR[unitId], destPort, destIp);

    VCCB_PRINTF("Successfully updated Osab[%d] IP/PORT\n", unitId);
    FnVCCB_PrintMdsIp(BLK_OSAB, unitId, destIp);
    return GOOD;
}

/**
 * @brief   Get VCLB ip and port
 */
int FnVCCB_GetVclbIpAndPort(void)
{
    AUTO_TRACE_FUNC;

    int rc;
    MdsIp_Type destIp;
    unsigned short destPort = 0;
    uint16_t loop;

    if ((rc = VLIB_getMdsIp(&destIp, BLOCK_VCLB, CFG->vm.unitId)) < 0)
    {
        VCCB_PRINTF("VLIB_getMdsIp ERROR(%d)\n", rc);
        mdsPrintError(rc);

        return ERROR;
    }

    //-------------- VCLB F1AP MBOX -------------
    for (loop = 0; loop < MAX_CALL_THREAD_NUM_VCLB; loop++)
    {
        if ((rc = mdsMakePort(&destPort, (uint16_t)(VCLB_INT_F1_DATA_REQ_MBOX + loop + DBG->offsetPort), NULL)) < 0)
        {
            VCCB_PRINTF("mdsMakePort ERROR(%d)\n", rc);
            mdsPrintError(rc);

            return ERROR;
        }

        VCCB_MAKE_MDS_ADDR(VCLB_SCTP_F1_ADDR[loop], destPort, destIp);
    }

    FnVCCB_PrintMdsIp(BLK_VCLB, 0, destIp);
    VCCB_PRINTF("VCLB IP/PORT Updated\n");
    return GOOD;
}

#ifdef __NVGNB__
/**
 * @brief   Get VUPB ip and port
 */
int FnVCCB_GetVupbIpAndPort(void)
{
    AUTO_TRACE_FUNC;

    int rc;
    MdsIp_Type destIp;
    unsigned short destPort = 0;

    rc = VLIB_getMdsIp(&destIp, BLOCK_VUPB, 0);
    if (rc < 0)
    {
        VCCB_PRINTF("[%s]VLIB_getMdsIp BLOCK_VUPB ERROR(%d)\n", __FUNCTION__, rc);

        return ERROR;
    }

    for (int loop = 0; loop < VCCB_MAX_CALL_THREAD_NUM_VUPB; loop++)
    {
        if ((rc = mdsMakePort(&destPort, (uint16_t)(VUPB_CALL_THREAD_0_MBOX + loop + DBG->offsetPort), NULL)) < 0)
        {
            VCCB_PRINTF("mdsMakePort ERROR(%d)\n", rc);
            mdsPrintError(rc);

            return ERROR;
        }

        VCCB_MAKE_MDS_ADDR(VUPB_CALL_ADDR[loop], destPort, destIp);
    }
    return GOOD;
}

/**
 * @brief   Get DFCB ip and port
 */
int FnVCCB_GetDfcbIpAndPort(void)
{
    AUTO_TRACE_FUNC;

    int rc;
    MdsIp_Type destIp;
    unsigned short destPort = 0;
    uint16_t loop;

    rc = VLIB_getMdsIp(&destIp, BLOCK_DFCB, 0);
    if (rc < 0)
    {
        VCCB_PRINTF("[%s]VLIB_getMdsIp BLOCK_DFCB ERROR(%d)\n", __FUNCTION__, rc);

        return ERROR;
    }

    for (loop = 0; loop < MAX_DFCB_CALL_MBOX_NUM; loop++)
    {
        if ((rc = mdsMakePort(&destPort, (uint16_t)(DFCB_CALL_BASE_MBOX_ID + loop), NULL)) < 0)
        {
            VCCB_PRINTF("mdsMakePort ERROR(%d)\n", rc);
            mdsPrintError(rc);

            return ERROR;
        }

        VCCB_MAKE_MDS_ADDR(DFCB_CALL_ADDR[loop], destPort, destIp);
    }

    for (loop = 0; loop < MAX_DFCB_CALL_MBOX_NUM; loop++)
    {
        if ((rc = mdsMakePort(&destPort, (uint16_t)(DFCB_RRC_BASE_MBOX_ID + loop), NULL)) < 0)
        {
            VCCB_PRINTF("mdsMakePort ERROR(%d)\n", rc);
            mdsPrintError(rc);

            return ERROR;
        }

        VCCB_MAKE_MDS_ADDR(DFCB_RRC_ADDR[loop], destPort, destIp);
    }

    if ((rc = mdsMakePort(&destPort, (uint16_t)(DFCB_INT_MGMT_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("mdsMakePort ERROR(%d)\n", rc);
        mdsPrintError(rc);
        return ERROR;
    }
    VCCB_MAKE_MDS_ADDR(DFCB_MGMT_ADDR, destPort, destIp);

    return GOOD;
}
#endif

int FnVCCB_GetSwmIpAndPort(void)
{
    AUTO_TRACE_FUNC;

    int rc;
    MdsIp_Type destIp = VCCB_ADDR.MdsIp;  // function would be called in VNF && !HostSim
    unsigned short destPort = 0;

    // Make port from MBOX-ID
    if ((rc = mdsMakePort(&destPort, SWM_INT_STATE_MBOX_ID, NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }

    // Make destination Address which consists of IP and Port
    VCCB_MAKE_MDS_ADDR(SWM_ADDR, destPort, destIp);

    return GOOD;
}

int FnVCCB_GetKasIp(MdsIp_Type &rMdsIp, const char *const svcName, const enumVccbPodDeploymentKind_type podDeploymentKind)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(svcName);
    if (VCCB_UNKNOWN_DEPLOYMENT_KIND_POD == podDeploymentKind)
    {
        return ERROR;
    }

    MdsKasIpValue_Type val;
    memset(&val, 0, sizeof(MdsKasIpValue_Type));

    MdsKasIpKey_Type key;
    key.RetryCount = 0;  // 0 means 1 try
    snprintf(key.Name, sizeof(key.Name), "%s", svcName);
    key.IpType = (podDeploymentKind == VCCB_STATEFULSET_POD) ? MDS_KAS_IP_TYPE_POD : MDS_KAS_IP_TYPE_SVC;

    int result = mdsGetKasIp(&val, &key);
    if (result < 0)
    {
        VCCB_PRINTF("mdsGetKasIp ERROR(%d)\n", result);
        mdsPrintError(result);
        return ERROR;
    }

    memcpy(&rMdsIp, &val.Ip, sizeof(MdsIp_Type));
    return GOOD;
}

/**
 * @brief   Get Mds Ip
 */
int VLIB_getMdsIp(pMdsIp_Type pMdsIp, const int blockType, const int unitId)
{
    AUTO_TRACE_FUNC;

#if defined(NEW_HOST_SIM) && (!defined(__CNF__) || defined(IPC_TEST))
    (void)blockType;
    (void)unitId;

    return mdsGetSrcIp(pMdsIp, MDS_ATTR_IP_TYPE_IIIP, NULL);
#elif __CNF__
    enumVccbPod_type podType = FnVCCB_GetBlockPodType(blockType);
    if (podType == VCCB_POD_TYPE_END)
    {
        VCCB_PRINTF("[%s] FnVCCB_GetBlockPodType ERROR!!\n", __func__);
        return ERROR;
    }

    char *svcName = NULL;
    if (ERROR == FnVCCB_GetPodSvcName(&svcName, podType, unitId, ENV->podInfo))
    {
        VCCB_PRINTF("[%s] FnVCCB_GetPodSvcName ERROR!!\n", __func__);
        return ERROR;
    }

    enumVccbPodDeploymentKind_type podDeploymentKind = FnVCCB_GetPodDeploymentKind(podType);
    if (VCCB_UNKNOWN_DEPLOYMENT_KIND_POD == podDeploymentKind)
    {
        VCCB_PRINTF("[%s] FnVCCB_GetPodDeploymentKind ERROR!!\n", __func__);
        return ERROR;
    }

    if (ERROR == FnVCCB_GetKasIp(*pMdsIp, svcName, podDeploymentKind))
    {
        VCCB_PRINTF("[%s] FnVCCB_GetKasIp ERROR!!\n", __func__);
        return ERROR;
    }

#elif __NVGNB__
    (void)unitId;
    switch (blockType)
    {
        case BLOCK_VNMB:
            *pMdsIp = ENV->drlibNvgnbInfo.blockInfo[DRLIB_NVGNB_VNMB].iiip;
            break;
        case BLOCK_VNLB:
            *pMdsIp = ENV->drlibNvgnbInfo.blockInfo[DRLIB_NVGNB_VNLB].iiip;
            break;
        case BLOCK_OSAB:
            *pMdsIp = ENV->drlibNvgnbInfo.blockInfo[DRLIB_NVGNB_OSAB].iiip;
            break;
        case BLOCK_VTMB:
            *pMdsIp = ENV->drlibNvgnbInfo.blockInfo[DRLIB_NVGNB_VTMB].iiip;
            break;
        case BLOCK_VCSB:
            *pMdsIp = ENV->drlibNvgnbInfo.blockInfo[DRLIB_NVGNB_VCSB].iiip;
            break;
        case BLOCK_VUPB:
            *pMdsIp = ENV->drlibNvgnbInfo.blockInfo[DRLIB_NVGNB_VUPB].iiip;
            break;
        case BLOCK_DFCB:
            *pMdsIp = ENV->drlibNvgnbInfo.blockInfo[DRLIB_NVGNB_DFCB].iiip;
            break;
        default:
            VCCB_PRINTF("ERROR : unknown blockType(%d)\n", blockType);
            return ERROR;
    }
#elif __VNF__
    int result;
    int unitType = VCOM_getUnitType((uint16_t)blockType);
    if (UNIT_TYPE_NULL == unitType)
    {
        VCCB_PRINTF("ERROR : Invalid blockType(%d)\n", blockType);

        return ERROR;
    }

    if ((result = mdsGetDesIp(pMdsIp, MDS_ATTR_IP_TYPE_IIIP, "UNITTYPE-%d,UNITID-%d", unitType, unitId)) < 0)
    {
        VCCB_PRINTF("mdsGetDesIp ERROR(%d)\n", result);
        mdsPrintError(result);

        return ERROR;
    }
#endif
    return GOOD;
}

static const char *FnVCCB_CallBlockTypeStr(int blockType)
{
    switch (blockType)
    {
        // Application/Hdr/msg_def.h
        case BLOCK_VNMB:
            return "VNMB";
        case BLOCK_VNLB:
            return "VNLB";
        case BLOCK_VCCB:
            return "VCCB";
        case BLOCK_VTMB:
            return "VTMB";
        case BLOCK_OSAB:
            return "OSAB";
        case BLOCK_VCSB:
            return "VCSB";
        default:
            return "UNKNOWN";
    }
}

/**
 * @brief   Get IP and port
 */
int FnVCCB_GetIpAndPort(void)
{
    AUTO_TRACE_FUNC;
    if (GOOD != VLIB_GetVccbIpAndPort())
    {
        VCCB_PRINTF("VLIB_GetVccbIpAndPort ERROR\n");

        return ERROR;
    }

    VccbSystem_type systemType = VCOM_getSystemType();
    int isDuplexed = 0;

    auto getBlockIpAndPort = [&](int blockType, int (*fn)(int))
    {
        int maxUnitIdx = isDuplexed ? 2 : 1;
        int result = ERROR;

        for (int i = 0; i < maxUnitIdx; i++)
        {
            if (GOOD == fn(i))
            {
                result = GOOD;  // if fn succeeded once, then result is GOOD
            }
            else
            {
                VCCB_PRINTF("Failed to get %s[%d] ip/port!!\n", FnVCCB_CallBlockTypeStr(blockType), i);
            }
        }
        if (systemType == e_VCCB_ACPF_CNF)
        {
            // in cnf acpf, the ip/port will be updated by FnVCCB_AuditIpPort
            return GOOD;
        }
        else
        {
            // in vnf acpf, vccb will exit when vccb failed to get ip/port both side.
            //              if vccb succeed to get one side ip/port, continue and opposite side will be updated by
            //              FnVCCB_AuditIpPort.
            return result;
        }
    };

    // VNMB
    {
        // NVGNB    :   Single
        // VNF      :   Duplex
        // CNF      :   Duplex / Single
        isDuplexed =
            (systemType == e_VCCB_ACPF_VNF) || (systemType == e_VCCB_ACPF_CNF && ENV->isSupportHA == CNF_HA_SUPPORT);
        if (ERROR == getBlockIpAndPort(BLOCK_VNMB, FnVCCB_GetVnmbIpAndPort))
        {
            VCCB_PRINT_ERROR("getBlockIpAndPort(VNMB) ERROR!\n");
            return ERROR;
        }
    }

    // VNLB
    {
        // NVGNB    :   Single
        // VNF      :   Duplex
        // CNF      :   Duplex / Single
        isDuplexed =
            ((systemType == e_VCCB_ACPF_VNF) || (systemType == e_VCCB_ACPF_CNF && ENV->isSupportHA == CNF_HA_SUPPORT));
        if (ERROR == getBlockIpAndPort(BLOCK_VNLB, FnVCCB_GetVnlbIpAndPort))
        {
            VCCB_PRINT_ERROR("getBlockIpAndPort(VNLB) ERROR!\n");
            return ERROR;
        }
    }

    // OSAB
    {
        // NVGNB    :   Single
        // VNF      :   Duplex
        // CNF      :   Single / Duplex
        isDuplexed =
            ((systemType == e_VCCB_ACPF_VNF) || (systemType == e_VCCB_ACPF_CNF && ENV->isSupportHA == CNF_HA_SUPPORT));
        if (ERROR == getBlockIpAndPort(BLOCK_OSAB, FnVCCB_GetOsabIpAndPort))
        {
            VCCB_PRINT_ERROR("getBlockIpAndPort(OSAB) ERROR!\n");
            return ERROR;
        }
    }

    // VTMB
    {
        // NVGNB    :   Single
        // VNF      :   Duplex
        // CNF      :   Multiple
        // On startup get ip and port for CTP leader, during audit remianing CTP will be updated
        isDuplexed = ((systemType == e_VCCB_ACPF_VNF));
        if (ERROR == getBlockIpAndPort(BLOCK_VTMB, FnVCCB_GetVtmbIpAndPort))
        {
            VCCB_PRINT_ERROR("getBlockIpAndPort(VTMB) ERROR!\n");
            return ERROR;
        }
    }

    // VCSB
    {
        // NVGNB    :   Single
        // VNF      :   Duplex
        // CNF      :   Single
        isDuplexed = ((systemType == e_VCCB_ACPF_VNF));
        if (ERROR == getBlockIpAndPort(BLOCK_VCSB, FnVCCB_GetVcsbIpAndPort))
        {
            VCCB_PRINT_ERROR("getBlockIpAndPort(OSAB) ERROR!\n");
            return ERROR;
        }
    }

    if (e_VCCB_ACPF_VNF == systemType)
    {
        if (GOOD != FnVCCB_GetVclbIpAndPort())
        {
            VCCB_PRINTF("FnVCCB_GetVclbIpAndPort ERROR\n");
            return ERROR;
        }

        if (GOOD != FnVCCB_GetSwmIpAndPort())
        {
            VCCB_PRINTF("FnVCCB_GetSwmIpAndPort ERROR\n");
            return ERROR;
        }
    }

#ifdef __NVGNB__
    if (GOOD != FnVCCB_GetVupbIpAndPort())
    {
        VCCB_PRINTF("FnVCCB_GetVupbIpAndPort ERROR\n");

        return ERROR;
    }

    if (GOOD != FnVCCB_GetDfcbIpAndPort())
    {
        VCCB_PRINTF("FnVCCB_GetDfcbIpAndPort ERROR\n");

        return ERROR;
    }
#endif

    VCCB_PRINTF("FnVCCB_GetIpAndPort is done\n");
    return GOOD;
}

int FnVCCB_ConvertMdsIptoChar(MdsIp_Type mdsIp, char *convIp)
{
    AUTO_TRACE_FUNC;

    int result = mdsConvertIpN2S(convIp, INET6_ADDRSTRLEN, mdsIp);
    if (result < 0)
    {
        VCCB_PRINT_ERROR("[%s] ERROR!! Failed to convert mds ip to Char(%d)\n", __func__, result);
        return result;
    }
    return GOOD;
}

int FnVCCB_GetVtmbPushNanoPort(const int unitId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(unitId, 0, VCCB_GetMaxVtmbUnits() - 1);

    int rc;
    unsigned short destPort = 0;

    const uint16_t TRACE_MANAGER_RECV_MBOX_LIST[MAX_VTMB_TRACE_THREAD_NUM] = {
        VTMB_TCP_TRACE_MANAGER_1_RECV_MBOX,
        VTMB_TCP_TRACE_MANAGER_2_RECV_MBOX,
        VTMB_TCP_TRACE_MANAGER_3_RECV_MBOX,
        VTMB_TCP_TRACE_MANAGER_4_RECV_MBOX,
        VTMB_TCP_TRACE_MANAGER_5_RECV_MBOX,
#ifdef __CNF__
        VTMB_TCP_TRACE_MANAGER_6_RECV_MBOX
#endif
    };

    if ((rc = mdsMakePort(&destPort, static_cast<uint16_t>(VTMB_TCP_CSL_HANDLER_MANAGER_RECV_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }
    VCCB_MAKE_MDS_ADDR(VTMB_ADDR[unitId], destPort, VTMB_ADDR[unitId].MdsIp);
    VCCB_PRINTF("[%s]VTMB_ADDR[%d] MBOX_ID: %" PRIu16 " Port = %hu\n", __FUNCTION__, unitId, VTMB_TCP_CSL_HANDLER_MANAGER_RECV_MBOX, VTMB_ADDR[unitId].MdsPort);

    for (uint8_t idx=0; idx < MAX_VTMB_TRACE_THREAD_NUM; ++idx)
    {
        if ((rc = mdsMakePort(&destPort, static_cast<uint16_t>(TRACE_MANAGER_RECV_MBOX_LIST[idx] + DBG->offsetPort), NULL)) < 0)
        {
            VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
            mdsPrintError(rc);

            return ERROR;
        }
        VCCB_MAKE_MDS_ADDR(VTMB_ADDR_TRACE[unitId][idx], destPort, VTMB_ADDR_TRACE[unitId][idx].MdsIp);
        VCCB_PRINTF("[%s]VTMB_ADDR_TRACE[%d][%d] MBOX_ID: %" PRIu16 " Port = %hu\n", __FUNCTION__, unitId, idx, TRACE_MANAGER_RECV_MBOX_LIST[idx], VTMB_ADDR_TRACE[unitId][idx].MdsPort);
    }

    if ((e_VCCB_ACPF_CNF == VCOM_getSystemType() && unitId == 0) || e_VCCB_ACPF_CNF != VCOM_getSystemType())
    {
        if ((rc = mdsMakePort(&destPort, static_cast<uint16_t>(VTMB_TCP_MAIN_RECV_MBOX + DBG->offsetPort), NULL)) < 0)
        {
            VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
            mdsPrintError(rc);

            return ERROR;
        }
        VCCB_MAKE_MDS_ADDR(VTMB_MAIN_ADDR[unitId], destPort, VTMB_MAIN_ADDR[unitId].MdsIp);
        VCCB_PRINTF("[%s]VTMB_MAIN_ADDR[%d] MBOX_ID: %" PRIu16 " Port = %hu\n", __FUNCTION__, unitId, VTMB_TCP_MAIN_RECV_MBOX, VTMB_MAIN_ADDR[unitId].MdsPort);
    }

    if ((rc = mdsMakePort(&destPort, static_cast<uint16_t>(VTMB_TCP_MDT_MANAGER_RECV_MBOX + DBG->offsetPort), NULL)) < 0)
    {
        VCCB_PRINTF("[%s]mdsMakePort ERROR(%d)\n", __FUNCTION__, rc);
        mdsPrintError(rc);

        return ERROR;
    }
    VCCB_MAKE_MDS_ADDR(VTMB_ADDR_MDT[unitId], destPort, VTMB_ADDR_MDT[unitId].MdsIp);
    VCCB_PRINTF("[%s]VTMB_ADDR_MDT[%d] MBOX_ID: %" PRIu16 " Port = %hu\n", __FUNCTION__, unitId, VTMB_TCP_MDT_MANAGER_RECV_MBOX, VTMB_ADDR_MDT[unitId].MdsPort);

    return GOOD;
}

int FnVCCB_GetPushNanoHandle(MdsAddr_Type destAddr, int *handle)
{
    AUTO_TRACE_FUNC;
    int result = GOOD;
    int sendBufSize = MSG_SEND_BUFF;

    if (e_VCCB_NVGNB == VCOM_getSystemType())
    {
        return GOOD;
    }

    char destIp[INET6_ADDRSTRLEN];
    memset(destIp, 0, sizeof(char) * INET6_ADDRSTRLEN);

    if (*handle > 0)
    {
        result = mdsClose(*handle);
        if (result < 0)
        {
            VCCB_PRINTF("mdsClose is Failed!!(res(%d))\n", result);
            return result;
        }
        *handle = -1;
    }

    result = FnVCCB_ConvertMdsIptoChar(destAddr.MdsIp, destIp);
    if (result < 0)
    {
        VCCB_PRINTF("FnVCCB_ConvertMdsIptoChar is Failed!!(res(%d))\n", result);
        return result;
    }

    result = mdsOpenPush(DSCP_IPC, 0, destAddr.MdsPort, destIp);
    if (result < 0)
    {
        VCCB_PRINTF("mdsOpenPush is Failed!!(res(%d))\n", result);
        return result;
    }

    if (mdsSetHandleOpt(result, MDS_HANDLE_OPT_SNDBUF_SET, (void *)&sendBufSize, sizeof(int)) < 0)
    {
        VCCB_PRINTF("NANO mdsOpenPush_mdsSetHandleOpt(%d) is Failed.(handle:%d)\n", sendBufSize, result);
    }

    int val = 1;
    if (mdsSetHandleOpt(result, MDS_HANDLE_OPT_TCP_NODELAY_SET, &val, sizeof(val)) < 0)
    {
        VCCB_PRINTF("NANO mdsOpenPush_mdsSetHandleOpt(TCP_NO_DELAY) is Failed.(handle:%d)\n", result);
    }

    *handle = result;
    return GOOD;
}

int FnVCCB_GetPullNanoHandle(MdsAddr_Type destAddr, int *handle)
{
    AUTO_TRACE_FUNC;
    int result = GOOD;

    if (e_VCCB_NVGNB == VCOM_getSystemType())
    {
        return GOOD;
    }

    if (*handle > 0)
    {
        result = mdsClose(*handle);
        if (result < 0)
        {
            VCCB_PRINTF("mdsClose is Failed!!(res(%d))\n", result);
            return result;
        }
    }
    result = mdsOpenPull(DSCP_IPC, 0, destAddr.MdsPort, "IIIP");
    if (result < 0)
    {
        VCCB_PRINTF("mdsOpenPull is Failed!!(res(%d))\n", result);
    }
    *handle = result;
    return GOOD;
}

int FnVCCB_GetOsabNanoHandle(const int unitId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(unitId, 0, VCCB_MAX_HA_UNIT_NUM - 1);

    VccbEnvInfo_type &rEnv = *ENV;
    if (e_VCCB_ACPF_CNF == VCOM_getSystemType() && rEnv.podInfo.cmp[unitId].nanoUpdateRequiredFlag == VCCB_FLAG_OFF)
    {
        return GOOD;
    }

    int result = GOOD;

    result = FnVCCB_GetPushNanoHandle(OSAB_ADDR_ANR[unitId], &rEnv.nanoPushHandle.osabAnr[unitId]);
    if (GOOD != result)
    {
        VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(OSAB_ADDR_ANR[%d] res(%d))\n", unitId, result);
        return ERROR;
    }
    VCCB_PRINTF("Successfully acquired Osab[%d] Nano handle!\n", unitId);
    rEnv.podInfo.cmp[unitId].nanoUpdateRequiredFlag = VCCB_FLAG_OFF;
    return GOOD;
}

int FnVCCB_GetVclbNanoHandle(void)
{
    AUTO_TRACE_FUNC;

    int result = GOOD;
    VccbEnvInfo_type &rEnv = *ENV;
    int i = 0;

    for (i = 0; i < MAX_CALL_THREAD_NUM_VCLB; i++)
    {
        result = FnVCCB_GetPushNanoHandle(VCLB_SCTP_F1_ADDR[i], &rEnv.nanoPushHandle.vclbF1[i]);
        if (GOOD != result)
        {
            VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(VCLB_SCTP_F1_ADDR[%d] res(%d))\n", i, result);
            return ERROR;
        }
    }

    VCCB_PRINTF("Successfully acquired Vclb Nano handle!\n");
    return GOOD;
}

int FnVCCB_GetVnlbNanoHandle(const int unitId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(unitId, 0, VCCB_MAX_HA_UNIT_NUM - 1);

    VccbEnvInfo_type &rEnv = *ENV;
    if (e_VCCB_ACPF_CNF == VCOM_getSystemType() && rEnv.podInfo.csp[unitId].nanoUpdateRequiredFlag == VCCB_FLAG_OFF)
    {
        return GOOD;
    }

    int result = GOOD;
    int i = 0;

    result = FnVCCB_GetPushNanoHandle(VNLB_ADDR[unitId], &rEnv.nanoPushHandle.vnlb[unitId]);
    if (GOOD != result)
    {
        VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(VNLB_ADDR[%d] res(%d))\n", unitId, result);
        return ERROR;
    }

    for (i = 0; i < MAX_GNB_PER_SYS; i++)
    {
        result = FnVCCB_GetPushNanoHandle(VNLB_SCTP_E1_ADDR[unitId][i], &rEnv.nanoPushHandle.sctbE1[unitId][i]);
        if (GOOD != result)
        {
            VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(VNLB_SCTP_E1_ADDR[%d][%d] res(%d))\n", unitId, i, result);
            return ERROR;
        }
    }

    for (i = 0; i < MAX_GNB_PER_SYS; i++)
    {
        result = FnVCCB_GetPushNanoHandle(VNLB_SCTP_F1_ADDR[unitId][i], &rEnv.nanoPushHandle.sctbF1[unitId][i]);
        if (GOOD != result)
        {
            VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(VNLB_SCTP_F1_ADDR[%d][%d] res(%d))\n", unitId, i, result);
            return ERROR;
        }
    }

    for (i = 0; i < MAX_GNB_PER_SYS; i++)
    {
        result = FnVCCB_GetPushNanoHandle(VNLB_SCTP_X2_ADDR[unitId][i], &rEnv.nanoPushHandle.sctbX2[unitId][i]);
        if (GOOD != result)
        {
            VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(VNLB_SCTP_X2_ADDR[%d][%d] res(%d))\n", unitId, i, result);
            return ERROR;
        }
    }

    for (i = 0; i < MAX_GNB_PER_SYS; i++)
    {
        result = FnVCCB_GetPushNanoHandle(VNLB_SCTP_NG_ADDR[unitId][i], &rEnv.nanoPushHandle.sctbNG[unitId][i]);
        if (GOOD != result)
        {
            VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(VNLB_SCTP_NG_ADDR[%d][%d] res(%d))\n", unitId, i, result);
            return ERROR;
        }
    }

    for (i = 0; i < MAX_GNB_PER_SYS; i++)
    {
        result = FnVCCB_GetPushNanoHandle(VNLB_SCTP_XN_ADDR[unitId][i], &rEnv.nanoPushHandle.sctbXN[unitId][i]);
        if (GOOD != result)
        {
            VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(VNLB_SCTP_XN_ADDR[%d][%d] res(%d))\n", unitId, i, result);
            return ERROR;
        }
    }
    VCCB_PRINTF("Successfully acquired Vnlb[%d] Nano handle!\n", unitId);
    rEnv.podInfo.csp[unitId].nanoUpdateRequiredFlag = VCCB_FLAG_OFF;
    return GOOD;
}

int FnVCCB_GetVcsbNanoHandle(const int unitId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(unitId, 0, VCCB_MAX_HA_UNIT_NUM - 1);

    int result = GOOD;

    result = FnVCCB_GetPushNanoHandle(VCSB_ADDR[unitId], &ENV->nanoPushHandle.vcsb[unitId]);
    if (GOOD != result)
    {
        VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(VCSB_ADDR[%d] res(%d))\n", unitId, result);
        return ERROR;
    }

    VCCB_PRINTF("Successfully acquired Vcsb Nano handle!\n");
    return GOOD;
}

int FnVCCB_GetVtmbNanoHandle(const int unitId)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(unitId, 0, VCCB_GetMaxVtmbUnits() - 1);

    VccbEnvInfo_type &rEnv = *ENV;
    if (e_VCCB_ACPF_CNF == VCOM_getSystemType() && rEnv.podInfo.ctp[unitId].nanoUpdateRequiredFlag == VCCB_FLAG_OFF)
    {
        return GOOD;
    }

    if (GOOD != FnVCCB_GetVtmbPushNanoPort(unitId))
    {
        VCCB_PRINTF("[%s] FnVCCB_GetVtmbPushNanoPort ERROR\n", __FUNCTION__);
        return ERROR;
    }

    if (GOOD != FnVCCB_GetPushNanoHandle(VTMB_ADDR[unitId], &rEnv.nanoPushHandle.vtmb[unitId]))
    {
        VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(VTMB_ADDR[%d])\n", unitId);
        return ERROR;
    }

    //on CNF open only ctp0-0
    if ((e_VCCB_ACPF_CNF == VCOM_getSystemType() && unitId == 0) || e_VCCB_ACPF_CNF != VCOM_getSystemType())
    {
        if (GOOD != FnVCCB_GetPushNanoHandle(VTMB_MAIN_ADDR[unitId], &rEnv.nanoPushHandle.vtmbMain[unitId]))
        {
            VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(VTMB_MAIN_ADDR[%d])\n", unitId);
            return ERROR;
        }
    }

    for (uint8_t idx=0; idx<MAX_VTMB_TRACE_THREAD_NUM; ++idx)
    {
        if (GOOD != FnVCCB_GetPushNanoHandle(VTMB_ADDR_TRACE[unitId][idx], &rEnv.nanoPushHandle.vtmbTrace[unitId][idx]))
        {
            VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(VTMB_ADDR_TRACE[%d][%d])\n", unitId, idx);
            return ERROR;
        }
    }

    if (GOOD != FnVCCB_GetPushNanoHandle(VTMB_ADDR_MDT[unitId], &rEnv.nanoPushHandle.vtmbMdt[unitId]))
    {
        VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(VTMB_ADDR_MDT[%d])\n", unitId);
        return ERROR;
    }

    VCCB_PRINTF("Successfully acquired Vtmb Nano handle!\n");
    rEnv.podInfo.ctp[unitId].nanoUpdateRequiredFlag = VCCB_FLAG_OFF;
    return GOOD;
}

int FnVCCB_GetVnmbNanoHandle(const int unitId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(unitId, 0, VCCB_MAX_HA_UNIT_NUM - 1);

    VccbEnvInfo_type &rEnv = *ENV;
    if (e_VCCB_ACPF_CNF == VCOM_getSystemType() && rEnv.podInfo.cip[unitId].nanoUpdateRequiredFlag == VCCB_FLAG_OFF)
    {
        return GOOD;
    }

    int result = GOOD;
    int i = 0;

    result = FnVCCB_GetPushNanoHandle(VNMB_ADDR[unitId], &rEnv.nanoPushHandle.vnmb[unitId]);
    if (GOOD != result)
    {
        VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(VNMB_ADDR[%d] res(%d))\n", unitId, result);
        return ERROR;
    }

    for (i = 0; i < MAX_CALL_THREAD_NUM_VNMB; i++)
    {
        result = FnVCCB_GetPushNanoHandle(VNMB_CALL_ADDR[unitId][i], &rEnv.nanoPushHandle.vnmbCall[unitId][i]);
        if (GOOD != result)
        {
            VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(VNMB_CALL_ADDR[%d][%d] res(%d))\n", unitId, i, result);
            return ERROR;
        }
    }

    for (i = 0; i < MAX_PAGING_THREAD_NUM_VNMB; i++)
    {
        result = FnVCCB_GetPushNanoHandle(VNMB_PAGING_ADDR[unitId][i], &rEnv.nanoPushHandle.vnmbPag[unitId][i]);
        if (GOOD != result)
        {
            VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(VNMB_PAGING_ADDR[%d][%d] res(%d))\n", unitId, i, result);
            return ERROR;
        }
    }

    result = FnVCCB_GetPushNanoHandle(VNMB_TRANSFER_ADDR[unitId], &rEnv.nanoPushHandle.vnmbTransfer[unitId]);
    if (GOOD != result)
    {
        VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(VNMB_TRANSFER_ADDR[%d] res(%d))\n", unitId, result);
        return ERROR;
    }

    result = FnVCCB_GetPushNanoHandle(VNMB_CBRS_ADDR[unitId], &rEnv.nanoPushHandle.vnmbCbrs[unitId]);
    if (GOOD != result)
    {
        VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(VNMB_CBRS_ADDR[%d] res(%d))\n", unitId, result);
        return ERROR;
    }

    result = FnVCCB_GetPushNanoHandle(VNMB_RACS_BIGMSG_ADDR[unitId], &rEnv.nanoPushHandle.vnmbExtRacsBigMsg[unitId]);
    if (GOOD != result)
    {
        VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(VNMB_RACS_ADDR[%d] res(%d))\n", unitId, result);
        return ERROR;
    }

    VCCB_PRINTF("Successfully acquired Vnmb[%d] Nano handle!\n", unitId);
    rEnv.podInfo.cip[unitId].nanoUpdateRequiredFlag = VCCB_FLAG_OFF;
    return GOOD;
}


#define MACRO_WRAPPER_GET_BLOCK_ADDRESS(__FN)   FnVCCB_wrapperGetBlockAddr(isDuplexed, systemType, __FN, #__FN)
int FnVCCB_wrapperGetBlockAddr(int isDuplexed, VccbSystem_type systemType, int (*fn)(int), const char *functionName)
{
    int maxUnitIdx = isDuplexed ? 2 : 1;
    int result = ERROR;

    for (int i = 0; i < maxUnitIdx; i++)
    {
        if (GOOD == fn(i))
        {
            result = GOOD;  // if fn succeeded once, then result is GOOD
        }
        else
        {
            VCCB_PRINTF("Failed to get %s[%d] !!\n", functionName, i);
        }
    }
    if (systemType == e_VCCB_ACPF_CNF)
    {
        // in cnf acpf, the ip/port will be updated by FnVCCB_AuditIpPort
        return GOOD;
    }
    else
    {
        // in vnf acpf, vccb will exit when vccb failed to get ip/port both side.
        //              if vccb succeed to get one side ip/port, continue and opposite side will be updated by
        //              FnVCCB_AuditIpPort.
        return result;
    }
}

int FnVCCB_GetVccbNanoHandle(void)
{
    AUTO_TRACE_FUNC;

    int result = GOOD;
    int i = 0;
    VccbEnvInfo_type *const pENV = ENV;

    // open TCP handle for pulling messages
    // Nano Message can be used only ACPF(VNF, CNF)
#ifdef __CNF__
    result = FnVCCB_GetPullNanoHandle(pENV->addr.vccbExt, &pENV->nanoPullHandle.vccb);
    if (GOOD != result)
    {
        VCCB_PRINTF("FnVCCB_GetPullNanoHandle is Failed!!(vccbExt res(%d))\n", result);
        return ERROR;
    }

    if (CNF_HA_SUPPORT == pENV->isSupportHA)
    {
        result = FnVCCB_GetPullNanoHandle(pENV->addr.vccbRedisRestore, &pENV->nanoPullHandle.vccbRedisRestore);
        if (GOOD != result)
        {
            VCCB_PRINTF("FnVCCB_GetPullNanoHandle is Failed!!(vccbRedisRestore res(%d))\n", result);
            return ERROR;
        }
    }
#else
    result = FnVCCB_GetPullNanoHandle(pENV->addr.vccb, &pENV->nanoPullHandle.vccb);
    if (GOOD != result)
    {
        VCCB_PRINTF("FnVCCB_GetPullNanoHandle is Failed!!(vccb res(%d))\n", result);
        return ERROR;
    }
#endif

    for (i = 0; i < MAX_CALL_THREAD_NUM_VCCB; i++)
    {
        result = FnVCCB_GetPullNanoHandle(pENV->addr.vccbCall[i], &pENV->nanoPullHandle.vccbCall[i]);
        if (GOOD != result)
        {
            VCCB_PRINTF("FnVCCB_GetPullNanoHandle is Failed!!(vccbCall[%d] res(%d))\n", i, result);
            return ERROR;
        }
    }

    result = FnVCCB_GetPullNanoHandle(pENV->addr.vccbNonUe, &pENV->nanoPullHandle.vccbNonUe);
    if (GOOD != result)
    {
        VCCB_PRINTF("FnVCCB_GetPullNanoHandle is Failed!!(vccbNonUe res(%d))\n", result);
        return ERROR;
    }

    result = FnVCCB_GetPullNanoHandle(pENV->addr.vccbNonUeAsn1, &pENV->nanoPullHandle.vccbNonUeAsn1);
    if (GOOD != result)
    {
        VCCB_PRINTF("FnVCCB_GetPullNanoHandle is Failed!!(vccbNonUeAsn1 res(%d))\n", result);
        return ERROR;
    }

    // SVR26A FGR-CC3103 IODT RACS(UE Radio Capability Signaling Optimization)
    result = FnVCCB_GetPullNanoHandle(pENV->addr.vccbExtRacsBigMsg, &pENV->nanoPullHandle.vccbExtRacsBigMsg);
    if (GOOD != result)
    {
        VCCB_PRINTF("FnVCCB_GetPullNanoHandle is Failed!!(vccbExtRacsBigMsg res(%d))\n", result);
        return ERROR;
    }

    for(i=0; i < VCCB_INT_RACS_BIGMSG_MBOX_MAX_NUM; i++)
    {
        result = FnVCCB_GetPullNanoHandle(pENV->addr.vccbIntRacsBigMsg[i], &pENV->nanoPullHandle.vccbIntRacsBigMsg[i]);
        if (GOOD != result)
        {
            VCCB_PRINTF("FnVCCB_GetPullNanoHandle is Failed!!(vccbIntRacsBigMsg[%d] res(%d))\n", i, result);
            return ERROR;
        }

        result = FnVCCB_GetPushNanoHandle(pENV->addr.vccbIntRacsBigMsg[i], &pENV->nanoPushHandle.vccbIntRacsBigMsg[i]);
        if (GOOD != result)
        {
            VCCB_PRINTF("FnVCCB_GetPushNanoHandle is Failed!!(vccbIntRacsBigMsg[%d] res(%d))\n", i, result);
            return ERROR;
        }
    }


    return GOOD;
}

void FnVCCB_SetNanoWorkerThreadPriority()
{
#define VCCB_NANOMSG_WORK_THREAD_PRIORITY_CNF       38
#define VCCB_NANOMSG_WORK_THREAD_PRIORITY_VNF       130

    int result = 0;
    int priority = VCCB_NANOMSG_WORK_THREAD_PRIORITY_CNF;
    if (VCOM_getSystemType() == e_VCCB_ACPF_VNF)
    {
        priority = VCCB_NANOMSG_WORK_THREAD_PRIORITY_VNF;
    }

    if ((result = mdsSetGlobalConfig(MDS_GLOBAL_CONFIG_NANO_THREAD_NICE_PRIORITY, &priority, sizeof(priority))) < 0)
    {
        VCCB_PRINTF("NANOMSG mdsSetGlobalConfig(worker thread priority:%d) is Failed.(%d)\n", priority, result);
    }
    else
    {
        VCCB_PRINTF("NANOMSG mdsSetGlobalConfig(worker thread priority:%d) is success\n", priority);
    }
}

int FnVCCB_GetNanoHandle()
{
    AUTO_TRACE_FUNC;

    if (VCOM_getSystemType() == e_VCCB_NVGNB)
    {
        // NVGNB is not supported Nano IPC
        return GOOD;
    }

    // Set NANOMSG worker thread's priority equally CallTask before creating nano handle
    FnVCCB_SetNanoWorkerThreadPriority();


    if (FnVCCB_GetVccbNanoHandle() != GOOD)
    {
        return ERROR;
    }

    VccbSystem_type systemType = VCOM_getSystemType();
    int isDuplexed;
    VccbEnvInfo_type &rEnv = *ENV;

    // VNMB
    {
        // VNF      :   Duplex
        // CNF      :   Duplex / Single
        isDuplexed =
            (systemType == e_VCCB_ACPF_VNF) || (systemType == e_VCCB_ACPF_CNF && rEnv.isSupportHA == CNF_HA_SUPPORT);
        if (ERROR == MACRO_WRAPPER_GET_BLOCK_ADDRESS(FnVCCB_GetVnmbNanoHandle))
        {
            VCCB_PRINTF("FnVCCB_GetVnmbNanoHandle ERROR\n");
            return ERROR;
        }
    }

    // VNLB
    {
        // VNF      :   Duplex
        // CNF      :   Duplex / Single
        isDuplexed =
            ((systemType == e_VCCB_ACPF_VNF) || (systemType == e_VCCB_ACPF_CNF && rEnv.isSupportHA == CNF_HA_SUPPORT));
        if (ERROR == MACRO_WRAPPER_GET_BLOCK_ADDRESS(FnVCCB_GetVnlbNanoHandle))
        {
            VCCB_PRINTF("FnVCCB_GetVnlbNanoHandle ERROR\n");
            return ERROR;
        }
    }

    // OSAB
    {
        // VNF      :   Duplex
        // CNF      :   Single / Duplex
        isDuplexed =
            ((systemType == e_VCCB_ACPF_VNF) || (systemType == e_VCCB_ACPF_CNF && rEnv.isSupportHA == CNF_HA_SUPPORT));
        if (ERROR == MACRO_WRAPPER_GET_BLOCK_ADDRESS(FnVCCB_GetOsabNanoHandle))
        {
            VCCB_PRINTF("FnVCCB_GetOsabNanoHandle ERROR\n");
            return ERROR;
        }
    }

    // VTMB
    {
        // VNF      :   Duplex
        // CNF      :   Multiple
        // On startup get ip and port for CTP leader, during audit remianing CTP will be updated
        isDuplexed = ((systemType == e_VCCB_ACPF_VNF));
        if (ERROR == MACRO_WRAPPER_GET_BLOCK_ADDRESS(FnVCCB_GetVtmbNanoHandle))
        {
            VCCB_PRINTF("FnVCCB_GetVtmbNanoHandle ERROR\n");
            return ERROR;
        }
    }

    // VCSB
    {
        // VNF      :   Duplex
        // CNF      :   Single
        isDuplexed = ((systemType == e_VCCB_ACPF_VNF));
        if (ERROR == MACRO_WRAPPER_GET_BLOCK_ADDRESS(FnVCCB_GetVcsbNanoHandle))
        {
            VCCB_PRINTF("FnVCCB_GetVcsbNanoHandle ERROR\n");
            return ERROR;
        }
    }

    if (systemType == e_VCCB_ACPF_VNF)
    {
        if (ERROR == FnVCCB_GetVclbNanoHandle())
        {
            VCCB_PRINTF("FnVCCB_GetVcsbNanoHandle ERROR\n");
            return ERROR;
        }
    }

    VCCB_PRINTF("FnVCCB_GetNanoHandle is done\n");
    return GOOD;
}

int FnVCCB_UpdateVnlbIpAndPortForCNF(const int unitId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(unitId, 0, VCCB_MAX_HA_UNIT_NUM - 1);

    int status = FnVCCB_GetVnlbIpAndPort(unitId);
    if (ERROR == status)
    {
        VCCB_PRINTF("FnVCCB_GetVnlbIpAndPort is failed!\n");
        ENV->podInfo.csp[unitId].ipPortGetFailFlag = VCCB_FLAG_ON;
        return ERROR;
    }

    if (TRUE == CFG->acpfInfo.isNanoSupport)
    {
        if (ERROR == FnVCCB_GetVnlbNanoHandle(unitId))
        {
            VCCB_PRINTF("FnVCCB_GetVnlbNanoHandle is failed!\n");
            ENV->podInfo.csp[unitId].ipPortGetFailFlag = VCCB_FLAG_ON;
            return ERROR;
        }
    }

    ENV->podInfo.csp[unitId].ipPortGetFailFlag = VCCB_FLAG_OFF;
    return status;
}

int FnVCCB_UpdateVnmbIpAndPortForCNF(const int unitId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(unitId, VCCB_MAX_HA_UNIT_NUM, ERROR);

    int status = FnVCCB_GetVnmbIpAndPort(unitId);
    if (ERROR == status)
    {
        VCCB_PRINTF("FnVCCB_GetVnmbIpAndPort is failed!\n");
        ENV->podInfo.cip[unitId].ipPortGetFailFlag = VCCB_FLAG_ON;
        return ERROR;
    }

    if (TRUE == CFG->acpfInfo.isNanoSupport)
    {
        if (ERROR == FnVCCB_GetVnmbNanoHandle(unitId))
        {
            VCCB_PRINTF("FnVCCB_GetVnmbNanoHandle is failed!\n");
            ENV->podInfo.cip[unitId].ipPortGetFailFlag = VCCB_FLAG_ON;
            return ERROR;
        }
    }

    ENV->podInfo.cip[unitId].ipPortGetFailFlag = VCCB_FLAG_OFF;
    return status;
}

int FnVCCB_UpdateOsabIpAndPortForCNF(const int unitId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(unitId, 0, VCCB_MAX_HA_UNIT_NUM - 1);

    int status = FnVCCB_GetOsabIpAndPort(unitId);
    if (ERROR == status)
    {
        VCCB_PRINTF("FnVCCB_GetOsabIpAndPort is failed!\n");
        ENV->podInfo.cmp[unitId].ipPortGetFailFlag = VCCB_FLAG_ON;
        return ERROR;
    }

    if (TRUE == CFG->acpfInfo.isNanoSupport)
    {
        if (ERROR == FnVCCB_GetOsabNanoHandle(unitId))
        {
            VCCB_PRINTF("FnVCCB_GetOsabNanoHandle is failed!\n");
            ENV->podInfo.cmp[unitId].ipPortGetFailFlag = VCCB_FLAG_ON;
            return ERROR;
        }
    }

    ENV->podInfo.cmp[unitId].ipPortGetFailFlag = VCCB_FLAG_OFF;
    return status;
}

int FnVCCB_UpdateVtmbIpAndPortForCNF(const int unitId)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VAL(unitId, VCCB_MAX_POD_ID_NUM, ERROR);

    int status = FnVCCB_GetVtmbIpAndPort(unitId);
    if (ERROR == status)
    {
        VCCB_PRINTF("FnVCCB_GetVtmbIpAndPort is failed!\n");
        ENV->podInfo.ctp[unitId].ipPortGetFailFlag = VCCB_FLAG_ON;
        return ERROR;
    }

    if (TRUE == CFG->acpfInfo.isNanoSupport)
    {
        if (ERROR == FnVCCB_GetVtmbNanoHandle(unitId))
        {
            VCCB_PRINTF("FnVCCB_GetVnmbNanoHandle is failed!\n");
            ENV->podInfo.ctp[unitId].ipPortGetFailFlag = VCCB_FLAG_ON;
            return ERROR;
        }
    }

    ENV->podInfo.ctp[unitId].ipPortGetFailFlag = VCCB_FLAG_OFF;
    return status;
}

void FnVCCB_CleanupVtmbConnections(const int unitId)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_RANGE_AND_RETURN_VOID(unitId, VCCB_GetMaxVtmbUnits(), "unitId");

    VccbSystem_type systemType = VCOM_getSystemType();
    VccbEnvInfo_type &rEnv = *ENV;

    if (systemType != e_VCCB_ACPF_CNF)
    {
        return;
    }

    auto clearIpAndPort =  [](auto& addr)
    {
        memset(&addr, 0, sizeof(addr));
        addr.MdsIp.IpVer = MDS_UNKNOWN;
    };

    if (rEnv.addr.vtmb[unitId].MdsIp.IpVer != MDS_UNKNOWN)
    {
        VCCB_PRINTF("%s addr cleanup for %d\n", __FUNCTION__, unitId);

        clearIpAndPort(rEnv.addr.vtmb[unitId]);
        clearIpAndPort(rEnv.addr.vtmbMain[unitId]);
        clearIpAndPort(rEnv.addr.vtmbMdt[unitId]);

        for(int i = 0; i < MAX_VTMB_TRACE_THREAD_NUM; ++i)
        {
            clearIpAndPort(rEnv.addr.vtmbTrace[unitId][i]);
        }
    }

    auto closeConnection = [](int& handle)
    {
        if (handle != 0)
        {
            auto result = mdsClose(handle);
            if (result < 0)
            {
                VCCB_PRINTF("mdsClose is Failed!!(res(%d))\n", result);
                return;
            }
            handle = 0;
        }
    };

    if (TRUE == CFG->acpfInfo.isNanoSupport && rEnv.nanoPushHandle.vtmb[unitId] != 0)
    {
        VCCB_PRINTF("%s nano handle cleanup for %d\n", __FUNCTION__, unitId);

        closeConnection(rEnv.nanoPushHandle.vtmb[unitId]);
        closeConnection(rEnv.nanoPushHandle.vtmbMain[unitId]);
        closeConnection(rEnv.nanoPushHandle.vtmbMdt[unitId]);
        for(int i = 0; i < MAX_VTMB_TRACE_THREAD_NUM; ++i)
        {
            closeConnection(rEnv.nanoPushHandle.vtmbTrace[unitId][i]);
        }
    }
}

void FnVCCB_SetTrafficManagementDSCPNano(const int unitId)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_RANGE_AND_RETURN_VOID(unitId, VCCB_MAX_POD_ID_NUM, "unitId");

    VccbSystem_type systemType = VCOM_getSystemType();
    int32_t result = GOOD;

    if (FALSE == CFG->acpfInfo.isNanoSupport)
    {
        return;
    }

    auto setDscp = [&](auto& handle)
    {
        if (handle != 0)
        {
            result = mdsSetDscp(handle, CFG->syslogCslTraceDSCP);
        }
    };

    if ((systemType == e_VCCB_ACPF_CNF && ENV->podInfo.ctp[unitId].operState == OpState_enabled) || systemType != e_VCCB_ACPF_CNF)
    {
        //CSL
        setDscp(ENV->nanoPushHandle.vtmb[unitId]);
        VCCB_CHECK_RTCODE_KEEP(result, "mdsSetDscp CSL");

        // Trace
        for (uint8_t idx=0; idx < MAX_VTMB_TRACE_THREAD_NUM; ++idx)
        {
            setDscp(ENV->nanoPushHandle.vtmbTrace[unitId][idx]);
            VCCB_CHECK_RTCODE_KEEP(result, "mdsSetDscp Trace");
        }

        // MDT
        setDscp(ENV->nanoPushHandle.vtmbMdt[unitId]);
        VCCB_CHECK_RTCODE_KEEP(result, "mdsSetDscp MDT");
    }
}

void FnVCCB_SetTrafficManagementDSCP(void)
{
    AUTO_TRACE_FUNC;

    VccbSystem_type systemType = VCOM_getSystemType();
    int maxUnitIdx = 1;
    int32_t result = GOOD;

    if (TRUE == CFG->acpfInfo.isNanoSupport)
    {
        switch (systemType)
        {
            case e_VCCB_ACPF_CNF:
            {
                maxUnitIdx = VCCB_MAX_POD_ID_NUM;
                break;
            }
            case e_VCCB_ACPF_VNF:
            {
                maxUnitIdx = 2;
                break;
            }
            case e_VCCB_NVGNB:
            default:
            {
                maxUnitIdx = 1;
                break;
            }
        }

        for (int unitId = 0; unitId < maxUnitIdx; unitId++)
        {
            FnVCCB_SetTrafficManagementDSCPNano(unitId);
        }
    }
    else
    {
        for (int i = 0; i < MAX_CALL_THREAD_NUM_VCCB; i++)
        {
            result = mdsSetDscp(ENV->handle.vccbExtCallCslTrace[i], CFG->syslogCslTraceDSCP);
            VCCB_CHECK_RTCODE_KEEP(result, "mdsSetDscp");
        }
    }
}

/**
 * @brief     sending IPC message
 * @param     txHandle : connection handle
 * @param     destAddr : destination address
 * @param     myMsg : message pointer
 * @param     len : message length
 * @return    GOOD : success
 * @return    ERROR : failure
 */
int16_t VLIB_SendMsg(int txHandle, MdsAddr_Type *destAddr, char *myMsg, uint32_t len, const int isNanoSupport)
{
    AUTO_TRACE_FUNC;

    int32_t stat;

    if (CFG->flag.preventToSend == FLAG_ON)
    {
        return GOOD;
    }
    VALID_E_POINT_CHECK_ERROR(destAddr);
    VALID_E_POINT_CHECK_ERROR(myMsg);

    //  PrintIpcMsg((void *)myMsg, TX_MSG);
    CONVERT_NET_ORDER((bigMessage_type *)myMsg);

    if (isNanoSupport == TRUE)
    {
        stat = mdsSendP(txHandle, myMsg, (int)len);
        if (stat < 0)
        {
            VCCB_PRINT_ERROR("mdsSendP(Nano) error (handle = %d, code = %d)\n", txHandle, stat);
            mdsPrintError(stat);
            return ERROR;
        }
    }
    else
    {
        if (len > 0 && len <= MSG_DAT_LEN)  // Small messages up to 65kB
        {
            if ((stat = mdsSend(txHandle, myMsg, (int)len, destAddr)) < 0)
            {
                VCCB_PRINT_COMMENT("Sendto(UDP) error (code = %d)\n", stat);
                mdsPrintError(stat);

                return ERROR;
            }
        }
        else
        {
            VCCB_PRINT_ERROR("Sendto(UDP) error (Wrong message size = %ui\n", len);
            return ERROR;
        }
        if (DBG->flag.fdis_port)
        {
            FnVCCB_PrintMdsAddrV4("SEND", destAddr->MdsIp.Ip.V4, destAddr->MdsPort);
        }
    }

    return GOOD;
}

/**
 * @brief     sending Big IPC message
 * @param     txHandle : connection handle
 * @param     destAddr : destination address
 * @param     myMsg : message pointer
 * @param     len : message length
 * @return    GOOD : success
 * @return    ERROR : failure
 */
int16_t VLIB_SendBigIpcMsg(int txHandle, MdsAddr_Type *destAddr, char *myMsg, uint32_t len)
{
    AUTO_TRACE_FUNC;

    int32_t stat;

    if (CFG->flag.preventToSend == FLAG_ON)
    {
        return GOOD;
    }
    VALID_E_POINT_CHECK_ERROR(destAddr);
    VALID_E_POINT_CHECK_ERROR(myMsg);

    //  PrintIpcMsg((void *)myMsg, TX_MSG);
    CONVERT_NET_ORDER((bigMessage_type *)myMsg);

    if (len > 0 && len <= MAX_SCTP_MSG_LEN)  // Big messages up to 580kB
    {
        if ((stat = mdsSendBIpc(txHandle, myMsg, (int)len, destAddr, 0)) < 0)
        {
            VCCB_PRINT_ERROR("Sendto(UDP) error (code = %d)\n", stat);
            mdsPrintError(stat);

            return ERROR;
        }
    }
    else
    {
        VCCB_PRINT_ERROR("SendBigIpcTo(UDP) error (Wrong message size = %u\n", len);
        return ERROR;
    }

    if (DBG->flag.fdis_port)
    {
        FnVCCB_PrintMdsAddrV4("SEND", destAddr->MdsIp.Ip.V4, destAddr->MdsPort);
    }

    return GOOD;
}

int16_t FnVCCB_SendMessageToInternalTaskWithBigMsg(
    const uint32_t msgId, const uint8_t callThreadId, char *pMsg, const uint32_t length)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pMsg);

    int status = GOOD;
    int handle;
    MdsAddr_Type *destAddr;

    int isAcpfSupportNanoMsg = CFG->acpfInfo.isNanoSupport;

    switch (msgId)
    {
        case InternalUeCapaIDUpdate_id:
            VCCB_CHECK_E_RANGE_AND_RETURN(callThreadId, MAX_CALL_THREAD_NUM_VCCB);
            destAddr = &ENV->addr.vccbIntRacsBigMsg[callThreadId % VCCB_INT_RACS_BIGMSG_MBOX_MAX_NUM];
            if (isAcpfSupportNanoMsg)
            {
                handle = ENV->nanoPushHandle.vccbIntRacsBigMsg[callThreadId % VCCB_INT_RACS_BIGMSG_MBOX_MAX_NUM];
            }
            else
            {
                handle = ENV->handle.vccbCall[callThreadId];
            }
            break;

        default:
            VCCB_PRINT_ERROR("Invalid msgID(%d) !!\n", msgId);
            return ERROR;
    }

#ifdef IPC_TEST
    status = VLIB_SendMsg(handle, destAddr, reinterpret_cast<char *>(pMsg), length, isAcpfSupportNanoMsg);
    VCCB_RETURN_ON_ERROR(status, "VLIB_SendMsg ERROR!!\n");
#else
    if (isAcpfSupportNanoMsg)
    {
        status = VLIB_SendMsg(handle, destAddr, reinterpret_cast<char *>(pMsg), length, isAcpfSupportNanoMsg);
        VCCB_RETURN_ON_ERROR(status, "VLIB_SendMsg ERROR!!\n");
    }
    else
    {
        status = VLIB_SendBigIpcMsg(handle, destAddr, reinterpret_cast<char *>(pMsg), length);
        VCCB_RETURN_ON_ERROR(status, "VLIB_SendMsg ERROR!!\n");
    }
#endif

    return GOOD;
}

/* EOF */
