/**************************************************************** 
 * System      : 5G vNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : ComLibUtility.c
 * Description :
 * Author      :
 * Dept.       : NG Access Lab.
 * Created     : 2020.09.25
 * Procedures defined :
 * Procedures called  :
 * Version     :
 * Revision history   :
 *          date      :
 *       revised by   :
 * revised information:
 ****************************************************************/

#include <math.h>

#include "ComInclude.h"
#include "ComLibUtility.h"
#include "ComCslCauseMap.h"
#include "ComCrrMapper.hpp"
#include "ComCallBackupQueue.h"
#include "ComTimeUtil.h"
#include "CdbPldReader.h"
#include "CdbUtil.h"

#include "FeatCommon.h"
#include "FeatCallInfo.h"
#include "FeatCallProc.h"
#include "FeatMrdc.h"
#include "FeatRre.h"
#include "FeatSwVersion.h"
#include "FeatCapaHandling.h"
#include "FeatMeasurements.hpp"
#include "FeatTrafficMeasurements.hpp"
#include "FeatConditionalHo.h"
#include "FeatRbInfo.h"

#include "StateCommon.h"
#include "StateHandleAll.h"
#include "StateHandleSaMrdc.h"

#include "MsgNgapSend.h"
#include "MsgNmbSend.h"
#include "MsgNrRrcSend.h"

#include "NRRRC.h"

#include "access_common_yang.h"
#include "K8sInterface.h"
#include "VccbStruct.h"

/**
 * @brief     VCCB For 'COMMAND_INJECTION'
 * @param     ptCi : call context
 * @param     srbIdx : SRB index / uint16_t
 * @return    GOOD : success
 * @return    ERROR : failure
 */
int FnVCCB_ExecuteCommand(const char *ptCmd)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCmd);

    string cmd = "/usr/local/bin/";
    cmd +=  ptCmd;
    FILE *ret = popen(cmd.c_str(), "r");
    if (ret == NULL)
    {
        VCCB_PRINTF("popen(%s) Failed\n", cmd.c_str());
        return ERROR;
    }
    pclose(ret);
    return GOOD;
}

/**
 * @brief     Release call SRB information
 * @param     ptCi : call context
 * @param     srbIdx : SRB index / uint16_t
 * @return    GOOD : success
 * @return    ERROR : failure
 */
int16_t VLIB_FreeCallSrbInfo(callInfo_type *ptCi, uint16_t srbIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (srbIdx >= MAX_SRB_PER_CALL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid srbIdx(%d) !! \n", srbIdx);
        return ERROR;
    }

    if (!IS_VALID_NODE(SRB_NODE, ptCi, &(ptCi->srbInfo[srbIdx])))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid srbIdx (%d)\n", srbIdx);
        return ERROR;
    }
    VCCB_CLEAR_TIMER(&ptCi->srbInfo[srbIdx].timer, CANCEL_TIMER);

    if (ptCi->srb3Idx == srbIdx)
    {
        ptCi->srb3Idx = MAX_SRB_PER_CALL;
    }
    ptCi->srbInfo[srbIdx].usage = CI_no_use;
    ptCi->numSRB--;

    return GOOD;
}

/**
 * @brief     Release call ERAB information
 * @param     ptCi : call context
 * @param     erabIdx : ERAB index / uint16_t
 * @return    GOOD : success
 * @return    ERROR : failure
 */
int16_t VLIB_FreeCallErabInfo(callInfo_type *ptCi, uint16_t erabIdx)
{
    AUTO_TRACE_FUNC;

    uint16_t cause;
    uint16_t f1CauseEnd, e1CauseEnd, x2CauseEnd;
    uint8_t incrementStatsForErab = TRUE;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (erabIdx >= MAX_ERAB_PER_CALL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid erabIdx(%d) !! \n", erabIdx);
        return ERROR;
    }

    callERABInfo_type *ptErabInfo = &ptCi->erabInfo[erabIdx];

    if (!IS_VALID_NODE(ERAB_NODE, ptCi, ptErabInfo))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid erabIdx (%d)\n", erabIdx);
        return ERROR;
    }

    f1CauseEnd = CauseF1apMax;
    e1CauseEnd = CauseE1apMax;
    x2CauseEnd = CauseX2apMax;

    cause = ptCi->cause.callFault.callFaultCause;

    uint16_t mType;

    // Call Statistics...
    if ((ptErabInfo->erabStatus == ERAB_Setup) ||
        ((ptErabInfo->erabStatus == ERAB_Modify) && (ptErabInfo->prevErabStatus == ERAB_Setup)) ||
        ((ptErabInfo->erabStatus == ERAB_Release) &&
            (ptErabInfo->prevErabStatus == ERAB_Modify)))  // in case that received SgNBReleaseReq instead ReconfigCmp
    {
        if ((cause == CauseCpInternalF1SctpOutOfService) ||
            (cause >= CAUSE_BASE_F1AP_RADIONETWORK && cause < f1CauseEnd))
        {
            mType = ErabAddFail_DuFail;
        }
        else if ((cause == CauseCpInternalE1SctpOutOfService) ||
                 (cause >= CAUSE_BASE_E1AP_RADIONETWORK && cause < e1CauseEnd))
        {
            mType = ErabAddFail_UpFail;
        }
        else if ((cause == CauseCpInternalNsaX2SctpOutOfService) ||
                 (cause == CauseCpInternalNsaX2UEContextRelease) ||
                 (cause >= CAUSE_BASE_X2AP_RADIONETWORK && cause < x2CauseEnd))
        {
            mType = ErabAddFail_MenbFail;
        }
        else
        {
            mType = ErabAddFail_CpFail;
        }
        MACRO_STAT_PMCC_QCI(STAT_ERAB_ADD_PER_GNB, mType, ptCi, ptErabInfo, 0, 0, 0, 0);
    }
    else if ((ptErabInfo->erabStatus == ERAB_Modify) && (ptErabInfo->prevErabStatus != ERAB_Setup))
    {
        if (ptErabInfo->preveBearerType != ptErabInfo->bearerType)
        {
            if ((cause == CauseCpInternalF1SctpOutOfService) ||
                (cause >= CAUSE_BASE_F1AP_RADIONETWORK && cause < f1CauseEnd))
            {
                mType = ErabModFail_DuFail_Change;
            }
            else if ((cause == CauseCpInternalE1SctpOutOfService) ||
                     (cause >= CAUSE_BASE_E1AP_RADIONETWORK && cause < e1CauseEnd))
            {
                mType = ErabModFail_UpFail_Change;
            }
            else if ((cause == CauseCpInternalNsaX2SctpOutOfService) ||
                     (cause == CauseCpInternalNsaX2UEContextRelease) ||
                     (cause >= CAUSE_BASE_X2AP_RADIONETWORK && cause < x2CauseEnd))
            {
                mType = ErabModFail_MenbFail_Change;
            }
            else
            {
                mType = ErabModFail_CpFail_Change;
            }
            MACRO_STAT_PMCC_QCI(STAT_ERAB_CHG_PER_GNB, mType, ptCi, ptErabInfo, 0, 0, 0, 0);
        }

        if ((cause == CauseCpInternalF1SctpOutOfService) ||
            (cause >= CAUSE_BASE_F1AP_RADIONETWORK && cause < f1CauseEnd))
        {
            mType = ErabModFail_DuFail;
        }
        else if ((cause == CauseCpInternalE1SctpOutOfService) ||
                 (cause >= CAUSE_BASE_E1AP_RADIONETWORK && cause < e1CauseEnd))
        {
            mType = ErabModFail_UpFail;
        }
        else if ((cause == CauseCpInternalNsaX2SctpOutOfService) ||
                 (cause == CauseCpInternalNsaX2UEContextRelease) ||
                 (cause >= CAUSE_BASE_X2AP_RADIONETWORK && cause < x2CauseEnd))
        {
            mType = ErabModFail_MenbFail;
        }
        else
        {
            mType = ErabModFail_CpFail;
        }
        MACRO_STAT_PMCC_QCI(STAT_ERAB_MOD_PER_GNB, mType, ptCi, ptErabInfo, 0, 0, 0, 0);
    }

    if (ptErabInfo->addSuccessFlagForStat == FLAG_ON)
    {
        // ERAB Release stats only for ERAB_Idle and ERAB_Release and etc(currently not supported)
        switch (ptCi->scgFailCauseInfo)
        {
            case ScgFailCauseInfo_UeT310Expired:
                mType = ErabRel_DL_t310Expiry;
                break;

            case ScgFailCauseInfo_UeRandomAccessProblem:
                if (ptCi->bitFlag.isE1apDddsNotificationENDCReceived == FLAG_OFF)
                {
                    mType = ErabRel_DL_randomAccessProblem;
                }
                else
                {
                    mType = ErabRel_DL_randomAccessProblem_AfterInitialAccess;
                }
                break;
            case ScgFailCauseInfo_UeRlcMaxRetransmission:
                mType = ErabRel_UL_rlcMaxNumRetx;
                break;
            case ScgFailCauseInfo_UeSynchReconfigFailureScg:
                mType = ErabRel_DL_syncReconfFailure;
                break;
            case ScgFailCauseInfo_UeScgReconfigFailure:
                mType = ErabRel_DL_scgReconfFailure;
                break;
            case ScgFailCauseInfo_UeSrb3IntegrityFailure:
                mType = ErabRel_DL_srb3IntegrityFailure;
                break;
            case ScgFailCauseInfo_DuUlRadioLinkFailureOthers:
                mType = ErabRel_UL_outOfSync;
                break;
            case ScgFailCauseInfo_DuRlcMaxRetransmission:
                mType = ErabRel_DL_rlcMaxNumRetx;
                break;
            case ScgFailCauseInfo_CpSrb3IntegrityFailure:
                mType = ErabRel_UL_srb3IntegrityFailure;
                break;
            case ScgFailCauseInfo_MrBasedSuspend:
                mType = ErabRel_MrBasedSuspendResume;
                break;
            case ScgFailCauseInfo_ScgLbtFailureR16:
            case ScgFailCauseInfo_BhRlfR16:
                mType = ErabRel_OtherR16FailCauses;
                break;
            case ScgFailCauseInfo_BeamFailureRecoveryFailureR16:
                mType = ErabRel_BeamFailureRecoveryFailure;
                break;
            case ScgFailCauseInfo_T312ExpiryR16:
                mType = ErabRel_T312Expiry;
                break;
            default:
                if(CauseX2apRadioNetworkLayerSwitchOffOngoing == ptCi->cause.x2Cause)
                {
                    mType = ErabRel_SwitchOffOngoing;
                }
                else if(CauseX2apRadioNetworkLayerRadioConnectionWithUeLost == ptCi->cause.x2Cause)
                {
                    mType = ErabRel_radioConnectionWithUeLost;
                }
                else
                {
                    mType = ErabRel;
                }
        }
        MACRO_STAT_PMCC_QCI(STAT_ERAB_REL_PER_GNB, mType, ptCi, ptErabInfo, 0, 0, 0, 0);

        if (FOO.VF_VzwOnlyCounterFamily)
        {
            if (cause == CauseCpInternalUserInactivity)
            {
                MACRO_STAT_PMCC_QCI(STAT_ERAB_SPEC_INFO_PER_GNB_DU_ID, ErabSpecInfo_RelCntByInactivityTimer, ptCi,
                    ptErabInfo, 0, 0, 0, 0);
            }

            MACRO_STAT_PMCC_QCI(
                STAT_ERAB_SPEC_INFO_PER_GNB_DU_ID, ErabSpecInfo_TotalRelCnt, ptCi, ptErabInfo, 0, 0, 0, 0);
        }
    }
    // else ERAB_REL counter will not be collected

    // VCCB_CLEAR_TIMER (ptErabInfo->timer, CANCEL_TIMER);

    if (ptErabInfo->erabStatus == ERAB_Release || ptErabInfo->erabStatus == ERAB_FailToSetup)
    {
        VLIB_IncrementLatestReleasedQcis(ptCi, ptErabInfo);
    }
    VLIB_IncrementReleaseAllStats(ptCi, incrementStatsForErab, ptErabInfo);

    SET_CALL_ERAB_INFO_USAGE_OFF(ptCi, erabIdx);

    return GOOD;
}

/**
 * @brief           Release gNB information
 *
 * @param[in/out]   ptCi : call context / callInfo_type
 * @param[in]       hoGnbIdx : gNB index / uint16_t
 * @return          GOOD/ERROR / int16_t
 */
int16_t VLIB_FreeCallGnbInfo(callInfo_type *ptCi, uint16_t hoGnbIdx)
{
    AUTO_TRACE_FUNC;

    uint16_t erabIdx = 0;
    callGNBInfo_type *ptGi = NULL;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(hoGnbIdx, MAX_GNB_PER_CALL);

    if (!IS_VALID_NODE(GNB_NODE, ptCi, &(ptCi->gnbInfo[hoGnbIdx])))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "ERROR: hoGnbIdx (%d) is out of range (%d..%d) or invalid\n", hoGnbIdx, 0, MAX_GNB_PER_CALL - 1);
        return ERROR;
    }

    ptGi = &(ptCi->gnbInfo[hoGnbIdx]);

    VCCB_CLEAR_TIMER(&ptGi->timer, CANCEL_TIMER);

    for (erabIdx = 0; erabIdx < MAX_ERAB_PER_CALL; erabIdx++)
    {
        if (IS_VALID_NODE(PATH_NODE, ptGi, &(ptGi->dlPath[erabIdx])))
        {
            VLIB_FreePathInfo(ptCi, hoGnbIdx, erabIdx, DL_FORWARDING);
        }

        if (IS_VALID_NODE(PATH_NODE, ptGi, &(ptGi->ulPath[erabIdx])))
        {
            VLIB_FreePathInfo(ptCi, hoGnbIdx, erabIdx, UL_FORWARDING);
        }
    }

    ptCi->gnbInfo[hoGnbIdx].usage = CI_no_use;
    ptCi->numGNB--;

    return GOOD;
}

/**
 * @brief     Release NR X2 path information
 * @param     ptCi : call context
 * @param     hoGnbIdx : vNB index / uint16_t
 * @param     erabIdx : ERAB index / uint16_t
 * @param     pathType : forwarding direction DL or UL / uint16_t
 * @return    GOOD : success
 * @return    ERROR : failure
 */
int16_t VLIB_FreePathInfo(callInfo_type *ptCi, uint16_t hoGnbIdx, uint16_t erabIdx, uint16_t pathType)
{
    AUTO_TRACE_FUNC;

    pathInfo_type *pPi;
    callGNBInfo_type *ptEi;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (erabIdx >= MAX_ERAB_PER_CALL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid erabIdx(%d) !! \n", erabIdx);
        return ERROR;
    }

    if (hoGnbIdx >= MAX_GNB_PER_CALL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid hoGnbIdx(%d) !! \n", hoGnbIdx);
        return ERROR;
    }

    if (!IS_VALID_NODE(GNB_NODE, ptCi, &(ptCi->gnbInfo[hoGnbIdx])))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid hoGnbIdx (%d)\n", hoGnbIdx);
        return ERROR;
    }

    ptEi = &(ptCi->gnbInfo[hoGnbIdx]);

    if (pathType == DL_FORWARDING)
    {
        if (!IS_VALID_NODE(PATH_NODE, ptEi, &(ptEi->dlPath[erabIdx])))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Invalid Path Index (branch/trch/direction = %d/%d/%d)\n", hoGnbIdx, erabIdx, pathType);
            return ERROR;
        }

        pPi = &(ptEi->dlPath[erabIdx]);
    }
    else
    {
        if (!IS_VALID_NODE(PATH_NODE, ptEi, &(ptEi->ulPath[erabIdx])))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Invalid Path Index (branch/trch/direction = %d/%d/%d)\n", hoGnbIdx, erabIdx, pathType);
            return ERROR;
        }

        pPi = &(ptEi->ulPath[erabIdx]);
    }

    VCCB_CLEAR_TIMER(&pPi->timer, CANCEL_TIMER);

    pPi->usage = CI_no_use;

    return GOOD;
}

/**
 * @brief     Release call Pdu information
 * @param     ptCi : call context
 * @param     PduIdx : PDU index / uint16_t
 * @return    GOOD : success
 * @return    ERROR : failure
 */
int16_t VLIB_FreeCallPduInfo(callInfo_type *ptCi, uint16_t callPduIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(callPduIdx, MAX_PDU_SESS_PER_CALL);

    uint16_t pduDrbIdx, pduQosIdx;
    uint16_t callDrbIdx, callQosIdx;

    if (!IS_VALID_NODE(PDU_NODE, ptCi, &(ptCi->pduSess[callPduIdx])))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid callPduIdx (%d)\n", callPduIdx);
        return ERROR;
    }

    ptCi->pduSess[callPduIdx].usage = CI_no_use;
    if (ptCi->numPDUSess > 0)
    {
        ptCi->numPDUSess--;
    }
    ptCi->pduSess[callPduIdx].splitStatus = MNTerm_PDU;

    // Release all the DRBs under the PDU
    for (pduDrbIdx = 0; pduDrbIdx < MAX_DRB_PER_PDU_SESS; pduDrbIdx++)
    {
        callDrbIdx = ptCi->pduSess[callPduIdx].drbIndex[pduDrbIdx];  // put Drb Pool's data
        if (callDrbIdx >= MAX_DRB_PER_SA_CALL) continue;

        if (!IS_VALID_NODE(DRB_NODE, ptCi, &(ptCi->drb[callDrbIdx]))) continue;

        if (VLIB_FreeCallDrbInfoUnderPdu(ptCi, callPduIdx, pduDrbIdx) != GOOD)
        {
            VCCB_PRINT_ERROR("VLIB_FreeCallDrbInfoUnderPdu ERROR!! \n");
        }
        SET_DRB_STATUS(ptCi, callDrbIdx, S_Idle);
    }

    // Release all the QosFlows under the PDU
    for (pduQosIdx = 0; pduQosIdx < MAX_QOS_FLOW_PER_PDU_SESS; pduQosIdx++)
    {
        callQosIdx = ptCi->pduSess[callPduIdx].qosFlowIndex[pduQosIdx];
        if (callQosIdx >= MAX_QOS_FLOW_PER_CALL) continue;

        if (!IS_VALID_NODE(QOSFLOW_NODE, ptCi, &(ptCi->qosFlow[callQosIdx]))) continue;

        if (VLIB_FreeCallQosFlowInfoUnderPdu(ptCi, callPduIdx, pduQosIdx) != GOOD)
        {
            VCCB_PRINT_ERROR("VLIB_FreeCallQosFlowInfoUnderPdu ERROR!! \n");
        }
        SET_QOSFLOW_STATUS(ptCi, callQosIdx, S_Idle);

        // typedef enum
        // {
        //     e_ReleaseTriggerForFindAllCause = -1, /* This value is used for searching all causes regardless of the
        //     reason. */ e_ReleaseTriggerNotRelease = 0,       /* Init Value */ e_ReleaseTriggerByAmf, /* Received
        //     Release List in PDU Session Modify/Release Command */ e_ReleaseTriggerByPathSwitch,         /* Received
        //     Unsuccessful List in Path Switch Request Ack */ e_ReleaseTriggerBySliceNotSupport,    /* TODO */
        //     e_MaxOfReleaseTrigger
        // } releaseTrigger_type;

        VCCB_SetBearerReleaseInfo(&ptCi->qosFlow[callQosIdx].releaseInfo, e_ReleaseTriggerNotRelease, CAUSE_NO_FAULT);
    }
    VCCB_SetBearerReleaseInfo(&ptCi->pduSess[callPduIdx].releaseInfo, e_ReleaseTriggerNotRelease, CAUSE_NO_FAULT);
    SET_PDU_STATUS(ptCi, callPduIdx, S_Idle);

    return GOOD;
}

/**
 * @brief     Release call Drb information
 * @param     ptCi : call context
 * @param     DrbIdx : DRB index / uint16_t
 * @return    GOOD : success
 * @return    ERROR : failure
 */
int16_t VLIB_FreeCallDrbInfoUnderPdu(callInfo_type *ptCi, uint16_t pduIdx, uint16_t pduDrbIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(pduIdx, MAX_PDU_SESS_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(pduDrbIdx, MAX_DRB_PER_PDU_SESS);

    uint8_t callDrbIdx = static_cast<uint8_t>(ptCi->pduSess[pduIdx].drbIndex[pduDrbIdx]);

    VCCB_CHECK_E_RANGE_AND_RETURN(callDrbIdx, MAX_DRB_PER_SA_CALL);

    callDRBInfo_type *ptDi = &ptCi->drb[callDrbIdx];

    if (ptDi->firstReqStatusInThisProcedure == S_Setup)
    {
        uint16_t cause = ptCi->cause.callFault.callFaultCause;

        // Statistics
        if (ptCi->cause.callFault.callFaultCause == CAUSE_NO_FAULT)
        {
            cause = ptDi->failCause;
        }
        MACRO_STAT_COLLECT_ALL_DRB_SETUP_WITH_CAUSE(ptCi, ptDi, callDrbIdx, cause);
    }

    if ((ptDi->rbInfo.pdcpInfo.headerCompression.ulRohcEnabled == TRUE) &&
        (ptDi->rbInfo.pdcpInfo.headerCompression.useProfile006 == TRUE))
    {
        VRRM_delCellassignedULOnlyRoHCDrbCount(ptCi, ptCi->servCellNum, callDrbIdx, FALSE);
        FnVCCB_delULRoHCDrbCountInRrcInact(ptCi, ptCi->servCellNum, callDrbIdx);
    }

    if (ptDi->rbInfo.pdcpInfo.headerCompression.symmetricRohcEnabled == TRUE)
    {
        FnVCCB_delSymmRoHCDrbCountInRrcConn(ptCi, ptCi->servCellNum, callDrbIdx);
        FnVCCB_delSymmRoHCDrbCountInRrcInact(ptCi, ptCi->servCellNum, callDrbIdx);
    }

    ptCi->ueInfo.roHCCapability.tempAllocatedRohcCid = 0;

    if (ptDi->rbInfo.pdcpInfo.ethernetCompression.ehcEnabled == TRUE)
    {
        FnVCCB_delEHCDrbCountInRrcConn(ptCi, callDrbIdx, ptCi->servCellNum);
        FnVCCB_delEHCDrbCountInRrcInact(ptCi, callDrbIdx, ptCi->servCellNum);
    }

    ptCi->ueInfo.ehcCapability.tempAllocatedEhcCid = 0;

    // Delete RRC Conn/Inact DRB Count.
    FnVCCB_DelCellDrbCountWithMarkedInfoOfSaRrcConn(ptCi, callDrbIdx);
    FnVCCB_DelCellDrbCountWithMarkedInfoOfSaRrcInact(ptCi, callDrbIdx);

    // Check RRC Conn/Inact/ConnInact DRB Holding Time.
    if (ptDi->drbConnStat.drbHoldingTimeOfRrcConnInact.isRunning)
    {
        FnVCCB_CalculateDrbHoldingTimeOfSaRrcConnInact(ptCi, callDrbIdx, CAL_STOP);
    }
    if (ptDi->drbConnStat.drbHoldingTimeOfRrcConn.isRunning)
    {
        FnVCCB_CalculateDrbHoldingTimeOfSaRrcConn(ptCi, callDrbIdx, CAL_STOP);
    }
    if (ptDi->drbConnStat.drbHoldingTimeOfRrcInact.isRunning)
    {
        FnVCCB_CalculateDrbHoldingTimeOfSaRrcInact(ptCi, callDrbIdx, CAL_STOP);
    }

    // FGR-CC5200:FR740 FR750 STAT_NRDC_SN_TERM_DRB_CONN_INFO
    FnVCCB_NrdcSnTermDrbConnInfoStatsCmd(ptCi, ptCi->servCellNum, callDrbIdx, ConnInfoStatsCmd_HoldingTimeStop);
    FnVCCB_NrdcSnTermDrbConnInfoStatsCmd(ptCi, ptCi->servCellNum, callDrbIdx, ConnInfoStatsCmd_Decrease);

    // VCCB_PRINT_CALL_ERROR(ptCi, "[RETAIN_STAT] %s: STAT_SETUP_DRB_RELEASE !! \n", __func__);
    // Statistics
    MACRO_STAT_PMCC_DRB(STAT_DRB_RELEASE_AND_ERASE, DrbRelSucc, ptCi, ptDi, 0, 0, 0, 0);
    MACRO_STAT_PMCC_RETAIN(STAT_SETUP_DRB_RELEASE, ptCi, ptDi, ptDi->retainStat.savedEventCategory,
        ptDi->retainStat.savedEventItem, 0, FALSE);

    /* Do not release DRB ID from Pool for preventing DRB ID Reuse Case.
     * ==========
     * [FR270] of FGR-CC3101(Basic Operation for NR SA)
     * gNB shall allocate DRB ID in ascending order.
     * When it uses all max DRB ID without re-use of DRB ID for the UE in RRC Connected, gNB shall release the UE.
     * ==========
     */
    if (DBG->flag.reuseDrbId == FLAG_ON)
    {
        OFF_BIT_DRB_ID_IN_POOL(ptCi, ptCi->drb[callDrbIdx].dRBId);  // Release DRB ID from drbIdPool
    }

    if (ptCi->pduSess[pduIdx].numDRBPerPDUSess > 0)
    {
        ptCi->pduSess[pduIdx].numDRBPerPDUSess--;
    }

    ptCi->pduSess[pduIdx].drbIndex[pduDrbIdx] = 0xFFFF;

    // Initialize default DRB info under PDU Sess
    if (ptCi->pduSess[pduIdx].defaultGroupPresent == OPT_PRESENT &&
        ptCi->pduSess[pduIdx].mappingDrbIdxDefaultGroup == callDrbIdx)
    {
        ptCi->pduSess[pduIdx].defaultGroupPresent = OPT_NOT_PRESENT;
        ptCi->pduSess[pduIdx].mappingDrbIdxDefaultGroup = 0xFF;
    }
    SET_DRB_RETAIN_STAT_CAPABLE_FLAG(&ptCi->drb[callDrbIdx], VCCB_FLAG_OFF);
    FnVCCB_InitTrafficReportDrbProperty(ptCi, ptDi);
    ptDi->usage = CI_no_use;

    return GOOD;
}

/**
 * @brief     Release call QosFlow information
 * @param     ptCi : call context
 * @param     QosFlowIdx : QOS FLOW index / uint16_t
 * @return    GOOD : success
 * @return    ERROR : failure
 */
int16_t VLIB_FreeCallQosFlowInfoUnderPdu(callInfo_type *ptCi, uint16_t pduIdx, uint16_t pduQosIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(pduIdx, MAX_PDU_SESS_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(pduQosIdx, MAX_QOS_FLOW_PER_PDU_SESS);

    uint16_t callDrbIdx;
    uint8_t drbQosIdx;
    uint16_t callQosFlowIdx = ptCi->pduSess[pduIdx].qosFlowIndex[pduQosIdx];

    callDRBInfo_type *ptDi = NULL;
    VCCB_CHECK_E_RANGE_AND_RETURN(callQosFlowIdx, MAX_QOS_FLOW_PER_CALL);
    qosFlowInfo_type *ptQi = &ptCi->qosFlow[callQosFlowIdx];

    VCCB_CHECK_E_RANGE_AND_RETURN(callQosFlowIdx, MAX_QOS_FLOW_PER_CALL);

    if (ptQi->firstReqStatusInThisProcedure == S_Setup)
    {
        uint16_t cause = ptCi->cause.callFault.callFaultCause;

        // Statistics
        if (ptCi->cause.callFault.callFaultCause == CAUSE_NO_FAULT)
        {
            cause = ptCi->qosFlow[callQosFlowIdx].failCause;
        }

        if (ptCi->qosFlow[callQosFlowIdx].qosFlowStatistic.attemptFlag[QOS_FLOW_SETUP] == ATTEMPT_MADE)
        {
            VLIB_QosFlowSetup_CollectStat_FailedQosflowItem(
                ptCi, cause, &ptCi->pduSess[pduIdx], &ptCi->qosFlow[callQosFlowIdx], STAT_QOS_FLOW_SETUP);
        }

        if (ptCi->qosFlow[callQosFlowIdx].qosFlowStatistic.attemptFlag[QOS_FLOW_SETUP_PLMN_SNSSAI] == ATTEMPT_MADE)
        {
            VLIB_QosFlowSetup_CollectStat_FailedQosflowItem(
                ptCi, cause, &ptCi->pduSess[pduIdx], &ptCi->qosFlow[callQosFlowIdx], STAT_QOS_FLOW_SETUP_PLMN_SNSSAI);
        }
    }

    ptCi->qosFlow[callQosFlowIdx].usage = CI_no_use;
    ptCi->qosFlow[callQosFlowIdx].isSDAPatSN = VCCB_FLAG_OFF;

    if (ptCi->pduSess[pduIdx].numQoSFlowPerPDUSess > 0)
    {
        ptCi->pduSess[pduIdx].numQoSFlowPerPDUSess--;
    }

    ptCi->pduSess[pduIdx].qosFlowIndex[pduQosIdx] = 0xFFFF;

    // Remove qosFlowIndex from related DRB
    callDrbIdx = ptCi->qosFlow[callQosFlowIdx].drbIdxInCall;
    if (callDrbIdx < MAX_DRB_PER_SA_CALL)
    {
        ptDi = &ptCi->drb[callDrbIdx];

        for (drbQosIdx = 0; drbQosIdx < MAX_QOS_FLOW_PER_DRB; drbQosIdx++)
        {
            // Find qosFlowIndex in DRB DB using callQosFlowIdx
            if (ptDi->qosFlowIndex[drbQosIdx] == callQosFlowIdx)
            {
                if (ptDi->numQoSFlowPerDRB > 0)
                {
                    ptDi->numQoSFlowPerDRB--;
                }

                ptDi->qosFlowIndex[drbQosIdx] = 0xFFFF;
                break;
            }
        }
    }

    return GOOD;
}

void VLIB_Init_NrppaMeasId(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    NrPpaContext_type *pNrppaInfo = &ptCi->NrPpaContext;
    VALID_E_POINT_CHECK_VOID(pNrppaInfo);

    uint8_t loop;

    for (loop = 0; loop < MAX_MEAS_ID; ++loop)
    {
        ptCi->NrPpaContext.ecidMeasId[loop] = UNKNOWN_MEAS_ID;
    }
    ptCi->NrPpaContext.isMeasReportStored = FALSE;
}

void VLIB_FreeNRPPaData(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    NrPpaContext_type *pNrppaInfo = &ptCi->NrPpaContext;
    VALID_E_POINT_CHECK_VOID(pNrppaInfo);

    ptCi->NrPpaContext.measurementPeriodicityPresent = OPT_NOT_PRESENT;
    ptCi->NrPpaContext.numOfMeasuredQuantities = 0;
    ptCi->NrPpaContext.numOfIratMeasuredQuantities = 0;
    ptCi->isNrPpaContextValid = FALSE;
    ptCi->NrPpaContext.isMeasReportRequired = FALSE;
    ptCi->NrPpaContext.tRPDirectNormal.geoCoordinatesPresent = OPT_NOT_PRESENT;
    ptCi->NrPpaContext.OtherRATMeasurementQuantitiesPresent = OPT_NOT_PRESENT;
    ptCi->NrPpaContext.numOfWlanMeasuredQuantities = 0;
    ptCi->NrPpaContext.isMeasConfigRequired = FALSE;
    ptCi->NrPpaContext.isMeasGapConfiguredInOnDemand = FALSE;
    ptCi->NrPpaContext.measResultCell.numCellReport = 0;
    ptCi->NrPpaContext.measResultCellEUTRA.numCellReport = 0;
    ptCi->NrPpaContext.isNrTARequested = FALSE;
    ptCi->NrPpaContext.isTimAdvReceived = FALSE;
    ptCi->NrPpaContext.valueTimAdvNR = 0xFFFF;
    ptCi->NrPpaContext.isTriggerMeasReconfig = FALSE;
    VCCB_CLEAR_TIMER(&ptCi->nrppaTimer, CANCEL_TIMER);
    VCCB_CLEAR_TIMER(&ptCi->nrppaTimerAoA, CANCEL_TIMER);
    VLIB_Init_NrppaMeasId(ptCi);
    ptCi->NrPpaContext.isPcellFilled               = FALSE;
    ptCi->NrPpaContext.isNrAoARequested            = FALSE;
    ptCi->NrPpaContext.isAoAReceived               = FALSE;
    ptCi->NrPpaContext.isMeasPeriodicityAoAPresent = FALSE;
    ptCi->NrPpaContext.aoANotReceivedInTime        = FALSE;
    ptCi->NrPpaContext.otherMeasNotReceivedInTime  = FALSE;
    ptCi->NrPpaContext.isF1EcidMeasFailureReceivedDuringSrsOn = FALSE;
    ptCi->NrPpaContext.measResultCell.measResultNR[0].physCellId = 0xFFFF; //Initialise PCI to avoid residual between 2 ECID requests
}

/**
 * @brief     Set current time in vccbTimeInfo_type struct
 * @param     ptr to time struct
 */
void VLIB_SetCurrentTime(vccbTimeInfo_type *ptTime)
{
    AUTO_TRACE_FUNC;

    struct timeb mTime;
    struct tm sTime_l;
    struct tm *sTime = &sTime_l;

    VALID_E_POINT_CHECK_VOID(ptTime);

    ftime(&mTime);
    localtime_r(&mTime.time, sTime);

    ptTime->year = (uint16_t)(sTime->tm_year + 1900);
    ptTime->mon = (uint8_t)(sTime->tm_mon + 1);
    ptTime->mday = (uint8_t)sTime->tm_mday;
    ptTime->hour = (uint8_t)sTime->tm_hour;
    ptTime->min = (uint8_t)sTime->tm_min;
    ptTime->sec = (uint8_t)sTime->tm_sec;
    ptTime->millisec = (uint16_t)mTime.millitm;
}

void VLIB_ConvertTimeToTm(vccbTimeInfo_type *ptTime, struct tm *ptTm)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptTime);
    VALID_E_POINT_CHECK_VOID(ptTm);

    ptTm->tm_year = ptTime->year - 1900;
    ptTm->tm_mon = ptTime->mon - 1;
    ptTm->tm_mday = ptTime->mday;
    ptTm->tm_hour = ptTime->hour;
    ptTm->tm_min = ptTime->min;
    ptTm->tm_sec = ptTime->sec;
    ptTm->tm_isdst = 0;
}

void VIIL_calcTimeDiff(vccbTimeInfo_type *ptTimeTarget, vccbTimeInfo_type *ptTimeStart, vccbTimeInfo_type *ptTimeEnd)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptTimeTarget);
    VALID_E_POINT_CHECK_VOID(ptTimeStart);
    VALID_E_POINT_CHECK_VOID(ptTimeEnd);

    struct tm startTm;
    struct tm endTm;
    VLIB_ConvertTimeToTm(ptTimeStart, &startTm);
    VLIB_ConvertTimeToTm(ptTimeEnd, &endTm);
    unsigned long long secDiff = (unsigned long long)llrint(floor(difftime(mktime(&endTm), mktime(&startTm))));

    if (ptTimeEnd->millisec < ptTimeStart->millisec)
    {
        --secDiff;
        ptTimeEnd->millisec = (uint16_t)(ptTimeEnd->millisec + 1000);
    }

    ptTimeTarget->millisec = (uint16_t)(ptTimeEnd->millisec - ptTimeStart->millisec);
    ptTimeTarget->sec = (uint8_t)(secDiff % 60);
    secDiff /= 60;
    ptTimeTarget->min = (uint8_t)(secDiff % 60);
    secDiff /= 60;
    ptTimeTarget->hour = (uint8_t)(secDiff % 24);
    secDiff /= 24;

    if (secDiff > 0)
    {
        VCCB_PRINT_ERROR("Time difference is bigger than 24 hours. Days: %llu", secDiff);
    }

    ptTimeTarget->mday = (uint8_t)secDiff;
    ptTimeTarget->mon = 0;
    ptTimeTarget->year = 0;
}

/**
 * @brief     Fill ERAB configuration in call context
 * @param     ptCi : call context
 * @param     ptRi : ERAB context
 * @return    GOOD : success
 * @return    ERROR : failure, invalid configuration
 */
int16_t VLIB_FillCallErabInfo_New(callInfo_type *ptCi, callERABInfo_type *ptRi, uint16_t msgId)
{
    AUTO_TRACE_FUNC;

    int status;
    uint16_t errCause;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptRi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (!IS_VALID_NODE(ERAB_NODE, ptCi, ptRi))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid ERAB_NODE in VLIB_FillCallErabInfo_New!\n");
        return ERROR;
    }

    //    if(ptCi->hoInfo.hoType.isTarget == FALSE)   // Serving
    {
        status = VRRM_assignRB(ptCi, ptRi, &errCause);
        if (status < 0)
        {
            MACRO_CALL_FAULT_SAVE(msgId, errCause);
            VCCB_PRINT_CALL_ERROR(ptCi, "VRRM_assignRB (callId = %d, errno = %d) \n", ptCi->callId, status);
            return ERROR;
        }
    }

    if (ptRi->erabQos.qciValue.QCI >= MAX_QCI_VALUE)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "ptRi[%d]->erabQos.qciValue.QCI[%d] Out Of Range!!\n", ptRi->erabIdx, ptRi->erabQos.qciValue.QCI);
        return ERROR;
    }

    if (TRUE == FOO.VF_StandardQciSupport)
    {
        if (TRUE == FOO.VF_QoSSchedulingPerPLMN)
        {
            int plmnIdx = VLIB_FindGnbPlmnIndexOfCall(ptCi);
            if (IS_VALID_PLMNNUM(plmnIdx))
            {
                if (!pGnb->perPlmnQciSupport[plmnIdx][ptRi->erabQos.qciValue.QCI].usage)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi,
                        "QCI(%d) value is not supported for the PlmnIdx(%d)! (YANG per-plmn-qci-support(%d) status = %d)\n",
                        ptRi->erabQos.qciValue.QCI, plmnIdx, ptRi->erabQos.qciValue.QCI,
                        pGnb->perPlmnQciSupport[plmnIdx][ptRi->erabQos.qciValue.QCI].usage);
                    return ERROR;
                }
            }
            else
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "VLIB_FindGnbPlmnIndexOfCall ERROR: can't find PLMN. PlmnIdx: %d is invalid. Checking default PlmnIdx(%d) for QCI(%d).\n",
                    plmnIdx, DEFAULT_PLMN_INDEX_SUPPORT, ptRi->erabQos.qciValue.QCI);
                if (!pGnb->perPlmnQciSupport[DEFAULT_PLMN_INDEX_SUPPORT][ptRi->erabQos.qciValue.QCI].usage)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi,
                        "QCI(%d) value is not supported for the PlmnIdx(%d)! (YANG per-plmn-qci-support(%d) status = %d)\n",
                        ptRi->erabQos.qciValue.QCI, DEFAULT_PLMN_INDEX_SUPPORT, ptRi->erabQos.qciValue.QCI,
                        pGnb->perPlmnQciSupport[DEFAULT_PLMN_INDEX_SUPPORT][ptRi->erabQos.qciValue.QCI].usage);
                    return ERROR;
                }
            }
        }
        else
        {
            if (!pGnb->qciSupport[ptRi->erabQos.qciValue.QCI].usage)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "QCI value is not supported! (%d)\n", ptRi->erabQos.qciValue.QCI);
                return ERROR;
            }
        }
    }

    status = FnVCCB_FillCallRbInfoPerQci(ptCi, ptRi, ptRi->erabQos.qciValue.QCI);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "FnVCCB_FillCallRbInfoPerQci (erabIdx = %d, qci = %d) \n", ptRi->erabIdx, ptRi->erabQos.qciValue.QCI);
        return ERROR;
    }

    return GOOD;
}

/**
 * @brief     Allocate SRB in call context
 * @param     ptCi : call context
 * @param     srbIdx : SRB index to allocate / uint16_t
 * @return    GOOD : success
 * @return    ERROR : failure
 */
int16_t VLIB_AllocCallSrbInfo(callInfo_type *ptCi, uint8_t srbIdx)
{
    AUTO_TRACE_FUNC;

    uint8_t loop;
    callSRBInfo_type *ptSi;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (srbIdx < MAX_SRB_PER_CALL)
    {
        if (IS_VALID_NODE(SRB_NODE, ptCi, &(ptCi->srbInfo[srbIdx])))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "SRB already allocated (%d)\n", srbIdx);
            return ERROR;
        }
    }
    else
    {
        for (loop = 0; loop < MAX_SRB_PER_CALL; loop++)
        {
            if (!IS_VALID_NODE(SRB_NODE, ptCi, &(ptCi->srbInfo[loop])))
            {
                break;
            }
        }

        if (loop == MAX_SRB_PER_CALL)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Fail to get Free srbIndex...\n");
            return ERROR;
        }

        srbIdx = loop;
    }

    ptSi = &(ptCi->srbInfo[srbIdx]);
    VLIB_InitCallSrbInfo(ptCi, ptSi, srbIdx);

    ptCi->numSRB++;

    // alloc SRB2 (It's SA UE)
    if (srbIdx == 1)
    {
        bool isRreTarget = true;

        // exclude CHO calls from RRE target
        if (FnVCCB_IsConditionalHandoverUE(ptCi) == true)
        {
            isRreTarget = false;
        }

        if (isRreTarget == true)
        {
            FnVCCB_insertAllocCallDbForRRE(ptCi);
        }
    }

    return GOOD;
}

/**
 * @brief     Allocate ERAB in call context
 * @param     msgId : call context
 * @param     ptCi : call context
 * @param     erabIdx : ERAB index to allocate / uint16_t
 * @return    GOOD : success
 * @return    ERROR : failure
 */
int16_t VLIB_AllocCallErabInfo(uint32_t msgId, callInfo_type *ptCi, uint8_t erabIdx)
{
    AUTO_TRACE_FUNC;
    (void)msgId;  // for warning removal

    uint8_t loop;
    callERABInfo_type *ptRi = NULL;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (erabIdx < MAX_ERAB_PER_CALL)
    {
        if (IS_VALID_NODE(ERAB_NODE, ptCi, &(ptCi->erabInfo[erabIdx])))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "ERAB already allocated (%d)\n", erabIdx);
            return ERROR;
        }
    }
    else
    {
        for (loop = 0; loop < MAX_ERAB_PER_CALL; loop++)
        {
            if (!IS_VALID_NODE(ERAB_NODE, ptCi, &(ptCi->erabInfo[loop]))) break;
        }

        if (loop == MAX_ERAB_PER_CALL)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Fail to get Free erabIndex...\n");
            return ERROR;
        }

        erabIdx = loop;
    }

    ptRi = &(ptCi->erabInfo[erabIdx]);
    VLIB_InitCallErabInfo(ptCi, ptRi, erabIdx);

    return GOOD;
}

int16_t VLIB_getArfcnFromMeasResult2NR(measResult2NR_type *ptMeasResult2NR, enumRSType rsType, uint32_t *arfcn)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptMeasResult2NR);
    VALID_E_POINT_CHECK_ERROR(arfcn);

    if (RSType_SSB == rsType && TRUE == ptMeasResult2NR->ssbFrequency_Flag)
    {
        *arfcn = ptMeasResult2NR->ssbFrequency;
    }
    else if (RSType_CSIRS == rsType && TRUE == ptMeasResult2NR->refFreqCSI_RS_Flag)
    {
        *arfcn = ptMeasResult2NR->refFreqCSI_RS;
    }
    else
    {
        VCCB_PRINT_ERROR("VLIB_getArfcnFromMeasResult2NR not found arfcn value in MeasResult2NR \n");
        *arfcn = 0;
        return ERROR;
    }

    return GOOD;
}
/**
 * @brief Check if call have at least one split bearer
 * @param [in]  ptCi                                : callInfo DB
 * @return      GOOD                                : At least one bearer have split config
 * @return      ERROR                               : None of the bearers have split config
 */
int16_t VLIB_CheckSplitDrb(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    int16_t erabIdx = 0;

    for (erabIdx = 0; erabIdx < MAX_ERAB_PER_CALL; erabIdx++)
    {
        if (!IS_VALID_NODE(ERAB_NODE, ptCi, &(ptCi->erabInfo[erabIdx]))) continue;

        if ((ERAB_Setup != ptCi->erabInfo[erabIdx].erabStatus) && (ERAB_Modify != ptCi->erabInfo[erabIdx].erabStatus) &&
            (ERAB_Idle != ptCi->erabInfo[erabIdx].erabStatus))
        {
            continue;
        }

        if (SPLIT_Bearer == ptCi->erabInfo[erabIdx].bearerType)
        {
            return GOOD;
        }
    }

    return ERROR;
}

/**
 * @brief Get if SPID based UlPathSwitching Profile Index
 * @param [in]  ptCi                                : callInfo DB
 * @return      spidThreshold_type                  : SPID based UlPathSwitching Profile Index
 */
spidThreshold_type VLIB_getDBSpidBasedUlPathSwitchingProfileIndex(
    callInfo_type *ptCi, uint16_t cellNum, uint16_t spidIdx)
{
    AUTO_TRACE_FUNC;
    spidThreshold_type defaultValue;
    memset(&defaultValue, 0, sizeof(spidThreshold_type));

    if (ptCi->gnbNum >= MAX_GNB_PER_SYS)
    {
        return defaultValue;
    }

    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (cellNum >= MAX_CELL_NUM_VCCB)
    {
        return defaultValue;
    }

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    if (spidIdx >= MAX_SPID_VALUE)
    {
        return defaultValue;
    }

    int spidBasedUlPathSwitchingProfileIdx = pCell->profileDBInfo.spidBasedUlPathSwitchingProfileIdx;
    if (spidBasedUlPathSwitchingProfileIdx >= MAX_SPID_UL_PATH_SWITCHING_PROFILE)
    {
        return defaultValue;
    }

    SpidUlPathSwitchProfile_type *pSpidUlpathSwitchProfile = NULL;
    pSpidUlpathSwitchProfile = &pGnb->SpidUlPathSwitchProfile[spidBasedUlPathSwitchingProfileIdx];

    return pSpidUlpathSwitchProfile->spidThreshold[spidIdx];
}

int16_t VLIB_getUlPrimaryPathSwitchFlagPerSpid(callInfo_type *ptCi, uint16_t cellNum, uint16_t spidIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    const spidThreshold_type spidThreshold = VLIB_getDBSpidBasedUlPathSwitchingProfileIndex(ptCi, cellNum, spidIdx);

    return spidThreshold.spidEnable && spidThreshold.ulPrimaryPathSwitchFlagPerSpid;
}

/**
 * @brief Check if call have SPID enable for Ul Primary Path Switch ENDC
 * @param [in]  ptCi                                : callInfo DB
 * @return      GOOD                                : spid enable and ulPrimaryPathSwitchFlagPerSpid enable
 * @return      ERROR                               : spid !(enable and ulPrimaryPathSwitchFlagPerSpid enable)
 */
int16_t VLIB_CheckEnableForSpidbasedUlPathSwitch(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    if ((E_CALLTYPE_NSA != ptCi->callType) || (OPT_NOT_PRESENT == ptCi->ueInfo.rfsp.rfspPresent))
    {
        return ERROR;
    }

    uint16_t spidIdx = FnVCCB_GetSpidIdx(ptCi);  // spid is in [1,256] and table is indexed from 0
    VCCB_CHECK_E_RANGE_AND_RETURN(spidIdx, MAX_SPID_VALUE);

    const spidThreshold_type spidThreshold = VLIB_getDBSpidBasedUlPathSwitchingProfileIndex(ptCi, cellNum, spidIdx);

    const bool spidEnable = spidThreshold.spidEnable;
    const bool ulPrimaryPathSwitchFlagPerSpid = VLIB_getUlPrimaryPathSwitchFlagPerSpid(ptCi, cellNum, spidIdx);

    if (spidEnable && ulPrimaryPathSwitchFlagPerSpid)
    {
        return GOOD;
    }

    VCCB_PRINT_COMMENT("[%s]:doesn't trigger spidEnable(%d) ulPrimaryPathSwitchFlagPerSpid(%d) is disable\n",
        __FUNCTION__, spidEnable, ulPrimaryPathSwitchFlagPerSpid);

    return ERROR;
}

/**
 * @brief Check whether call have A1/A2 measure about ulPrimaryPathSwitchFlagPerSpid
 * @param [in]  ptCi                                : callInfo DB
 * @return      GOOD                                : !(spid enable and ulPrimaryPathSwitchFlagPerSpid disable)
 * @return      ERROR                               : spid enable and ulPrimaryPathSwitchFlagPerSpid disable
 */
int16_t VLIB_CheckToMakeA1A2UlPrimaryPathSwitch(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    if (E_CALLTYPE_NSA != ptCi->callType)
    {
        return ERROR;
    }

    // Normal UL path Switch for A1/A2 measure is generated
    if (OPT_NOT_PRESENT == ptCi->ueInfo.rfsp.rfspPresent)
    {
        return GOOD;
    }

    uint16_t spidIdx = FnVCCB_GetSpidIdx(ptCi);  // spid is in [1,256] and table is indexed from 0
    VCCB_CHECK_E_RANGE_AND_RETURN(spidIdx, MAX_SPID_VALUE);

    const spidThreshold_type spidThreshold = VLIB_getDBSpidBasedUlPathSwitchingProfileIndex(ptCi, cellNum, spidIdx);

    const bool spidEnable = spidThreshold.spidEnable;
    const bool ulPrimaryPathSwitchFlagPerSpid = VLIB_getUlPrimaryPathSwitchFlagPerSpid(ptCi, cellNum, spidIdx);

    // Normal UL path Switch for A1/A2 measure is generated
    if (VCCB_FLAG_OFF == spidEnable)
    {
        return GOOD;
    }

    // SPID based UL path Switch for A1/A2 measure is generated
    if (VCCB_FLAG_ON == ulPrimaryPathSwitchFlagPerSpid)
    {
        return GOOD;
    }

    return ERROR;
}

/**
 * @brief This function checks if the given endPointIndex is being used for serving Xn.
 *
 * @param ptCi Pointer to call information structure.
 * @param endPointIndex The index of the Xn to check.
 * @return bool True if the endPointIndex is being used for serving Xn, false otherwise.
 */
VCCB_STATIC_INLINE
bool FnVCCB_IsUsingServingEndPointIndexForXn(const callInfo_type *ptCi, const uint16_t endPointIndex)
{
    // Check if the given pointer and function name are valid
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // Check if the endPointIndex matches the serving endPointIndex for Xn
    if (ptCi->endPointInfo.xnIdx == endPointIndex)
    {
        // Return true since the endPointIndex matches
        return true;
    }

    // Return false since the endPointIndex does not match
    return false;
}

/**
 * @brief This function checks if the given call information matches the serving endpoint index for XN.
 *
 * @param ptCi Pointer to the call information structure.
 * @param ptMsg Pointer to the message containing the serving endpoint index.
 * @param endPointIdx Serving endpoint index.
 * @param rSelectionCause Reference to the release call selection cause structure.
 * @return int16_t Returns GOOD if the call matches the serving endpoint index for XN, otherwise ERROR.
 */
VCCB_STATIC_INLINE
int16_t FnVCCB_GetReleaseCallInfo_ForXN(callInfo_type *ptCi, msgCallReleaseCommand_type *ptMsg,
    uint16_t endPointIdx, VccbReleaseCallSelectionCause_type &rSelectionCause)
{
    // Check if the given pointers are valid
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMsg);

    // Check if the call is using NRDC-SN
    if (IS_NRDC_SN(ptCi))
    {
        // Check if the call is using the specified serving endpoint index for XN
        if (FnVCCB_IsUsingServingEndPointIndexForXn(ptCi, endPointIdx) == true)
        {
            // Set the byServingEndPointIdx flag in the release call selection cause structure
            rSelectionCause.byServingEndPointIdx = true;
        }
    }
    else
    {
        // Check if the call is using MRDC-MN
        if (IS_MRDC_MN(ptCi))
        {
            // Check if the call is using the source MRDC SN
            if (ptCi->mrdcInfo.SNInfo[SRC_SN].epIdx == endPointIdx)
            {
                auto isValidSrcSnEpIdxInMrdcMn = [&ptCi]()
                {
                    auto isInterMnMobilityInTargetMN =[&]()
                    {
                        auto &hoInfo = ptCi->hoInfo;

                        if (VHCM_isSaHandoverUE(ptCi) == FALSE) return false;

                        if (hoInfo.isSnInitMobilityInMn == true) return false;

                        // Intra-MN Target-gNB Case
                        return (hoInfo.hoType.nb == HO_TYPE_INTER_NB && hoInfo.isTarget == TRUE);
                    };

                    // In Target-MN, the connection with the SrcSN may not be established,
                    // so the processing based on this information should not be performed.
                    if (isInterMnMobilityInTargetMN() == TRUE)
                    {
                        // Inter-MN Mobility Case
                        return false;
                    }

                    return true;
                };

                if (isValidSrcSnEpIdxInMrdcMn() == true)
                {
                    // Set the byXnSrcMrdcSn flag in the release call selection cause structure
                    rSelectionCause.byXnSrcMrdcSn = true;
                }
            }

            // Check if the call is using the target MRDC SN
            if (ptCi->mrdcInfo.SNInfo[TGT_SN].epIdx == endPointIdx)
            {
                // Set the byXnTgtMrdcSn flag in the release call selection cause structure
                rSelectionCause.byXnTgtMrdcSn = true;
            }
        }

        // Check the state command of the call
        switch(ptCi->stateCmd)
        {
            case RrcReestablish_cmd:
                // Check if the call is using the specified serving endpoint index for XN
                if (FnVCCB_IsUsingServingEndPointIndexForXn(ptCi, endPointIdx) == true)
                {
                    // Set the byXnDuringRRE flag in the release call selection cause structure
                    rSelectionCause.byXnDuringRRE = true;
                }
                break;

            case RRCResume_cmd:
                // Check if the call is using the specified serving endpoint index for XN
                if (FnVCCB_IsUsingServingEndPointIndexForXn(ptCi, endPointIdx) == true)
                {
                    // Set the byXnDuringResume flag in the release call selection cause structure
                    rSelectionCause.byXnDuringResume = true;
                }
                break;

            case IntraRatHO_cmd:
                // Check if the call needs to process XN Reset during inter-gNB XN handover
                if (FnVCCB_NeedToProcessXnResetDuringInterGnbXnHandover(ptCi, ptMsg) == true)
                {
                    /* SVR19A Design - XNAP Interface Processing

                        The releaseType is only supported as 'RELEASE_ALL_ENDPOINT'.
                        In SVR19A, XN Reset is only supported as 'RELEASE_ALL_ENDPOINT'.

                        When XN Reset is received during XN Handover, the design operation is described.
                        1) If XN Reset is received by the SourceGNB during XN Handover, call release is performed if the call is in the HO-Preparation stage.
                        2) If the call is in the HO-Execution stage (SourceGNB->HO-Execution, Target-gNB,...), call release is performed.
                            - If an XN Cause is received, set CRR with CauseCpInternalOMIntervention.
                                * Reason: CRR for XN was not defined at the time of development, so it was mapped.
                            - If any other cause is received, set CRR with the received cause.

                        - If XN Reset is received by the Target-gNB, call release is performed regardless of the preparation/execution stage.
                        - If an XN Cause is received, receive CRR with CauseCpInternalOMIntervention.
                        - If any other cause is received, receive CRR with the received cause. */

                    // Set the byXnDuringXnHo flag in the release call selection cause structure
                    rSelectionCause.byXnDuringXnHo = true;
                }
                break;

            default:
                break;
        }
    }

    if (rSelectionCause.bitmask)
        return GOOD;

    return ERROR;
}

/**
 * @brief     Get release call info for VNMB-VCCB Ongoing Call Release
 * @param     releaseType: releaseType in the msgCallReleaseCommand
 * @param     interface: interface in the msgCallReleaseCommand
 * @param     endPointIdx: endPointIdx in the msgCallReleaseCommand
 * @param     callId: callId in the msgCallReleaseCommand
 * @param     ptCi: pointer of callInfo
 * @return    GOOD : success
 * @return    ERROR : failure
 */
int16_t VLIB_GetReleaseCallInfo(msgCallReleaseCommand_type *ptMsg, uint16_t interface, uint16_t gnbNum,
    uint16_t endPointIdx, uint32_t callId, callInfo_type **ptCi, VccbReleaseCallSelectionCause_type &rSelectionCause) // 23A_NRRetainability
{
    int16_t status = ERROR;

    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_RETURN(callId, VCCB_MAX_CALL_COUNT_PER_CPC);
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);

    // 23A_NRRetainability
    VALID_E_POINT_CHECK_ERROR(ptCi);
    enumReleaseType_type  releaseType = ptMsg->releaseType;

    *ptCi = FnVCCB_GetCallInUse(callId);
    if (*ptCi == NULL)
    {
        return ERROR;
    }

    if ((*ptCi)->gnbNum != gnbNum)
    {
        return ERROR;
    }

#define INTERFACE_NONE 0

    // Init Value
    rSelectionCause.bitmask = 0;

    switch (interface)
    {
        case INTERFACE_NONE:
            // VCCB_PRINT_MSG("[%6d] gnbNum:%d matched\n", callId, gnbNum);
            rSelectionCause.byAlwaysSelected = true;
            status = GOOD;
            break;

        case interface_e1:
        {
            uint16_t srvUpIdx = VRRM_FindServingUpIndex((*ptCi), endPointIdx);
            if (srvUpIdx < MAX_CU_UP_PER_CALL)
            {
                (*ptCi)->flag.e1Flag[srvUpIdx].isE1Reset = VCCB_FLAG_ON;
                (*ptCi)->endPointInfo.aupf[srvUpIdx].e1Cause = (uint16_t)ptMsg->cause;
                // VCCB_PRINT_MSG("[%6d] gnbNum:%d e1Idx:%d matched for servingUpIdx:%u\n", callId, gnbNum, endPointIdx,
                // srvUpIdx);

                // 23A_NRRetainability
                if( (*ptCi)->callType == E_CALLTYPE_SA)
                {
                    if(ptMsg->ngResetType == NG_RESET_BY_RAN)
                        (*ptCi)->endPointInfo.aupf[srvUpIdx].resetEventType = e_ReleaseTriggerByRanResetFromVnmb;
                    else if(ptMsg->ngResetType == NG_RESET_BY_LINK_FAIL)
                        (*ptCi)->endPointInfo.aupf[srvUpIdx].resetEventType = e_ReleaseTriggerByLinkFailureFromVnmb;
                }

                rSelectionCause.byServingEndPointIdx = true;
                status = GOOD;
            }
            else if (RELEASE_BEARER == releaseType)
            {
                VCCB_PRINT_CALL_ERROR((*ptCi), "E1idx:%u Is Not serving AUPF for this call \n", endPointIdx);
                // Correct the mismatch in VNMB
                VCCB_RETURN_ON_CALL_ERROR(
                    (*ptCi), VIIL_sendCallResourceChangeInd((*ptCi)), "VIIL_sendCallResourceChangeInd ERROR!\n");
            }
            break;
        }

        case interface_f1:
            if ((*ptCi)->endPointInfo.f1Idx == endPointIdx)
            {
                // VCCB_PRINT_MSG("[%6d] gnbNum:%d f1Idx:%d matched\n", callId, gnbNum, endPointIdx);
                rSelectionCause.byServingEndPointIdx = true;
                status = GOOD;
            }
            break;

            /* In case of X2 RESET, VNMB sends with RELEASE_PARTIAL because
       VNMB already knows VCCB call id corresponding to X2 ue id. */

        case interface_ng:
            if ((*ptCi)->callType != E_CALLTYPE_SA) break;

            if ((*ptCi)->endPointInfo.ngIdx == endPointIdx)
            {
                // VCCB_PRINT_MSG("[%6d] gnbNum:%d ngIdx:%d matched\n", callId, gnbNum, endPointIdx);
                rSelectionCause.byServingEndPointIdx = true;
                status = GOOD;
            }
            break;

        case interface_xn:
            if ((*ptCi)->callType != E_CALLTYPE_SA) break;

            status = FnVCCB_GetReleaseCallInfo_ForXN(*ptCi, ptMsg, endPointIdx, rSelectionCause);
            if (status == GOOD)
            {
                VCCB_PRINT_CALL_ERROR((*ptCi), "callId:%d gnbNum:%d xnIdx:%d matched (bitmask:%s)\n",
                    callId, gnbNum, endPointIdx, std::bitset<64>(rSelectionCause.bitmask).to_string().c_str());
            }
            break;

        default:
            break;
    }

    if (rSelectionCause.bitmask)
        return GOOD;

    return status;

#undef INTERFACE_NONE
}

/**
 * @brief This function is to get gnbNum from gnbId.
 * @param [out] gnbNum : gnbNum.
 * @param [in] gnbId : gnbId.
 * @return GOOD : The operation success.
 * @return ERROR : The operation fail.
 * @exception N /A
 */
int16_t VLIB_GetGnbNumFromId(uint16_t *gnbNum, uint32_t gnbId)
{
    AUTO_TRACE_FUNC;

    /* Check Input */
    VRRM_VALID_CHECK_NULL_POINTER_ERROR(gnbNum);
    /* comparison is always false due to limited range of data type
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbId, MAX_GNB_IDENTITY);
    */

    *gnbNum = UNKNOWN_GNB_NUM;
    uint16_t i;

    if (e_VCCB_NVGNB == VCOM_getSystemType())
    {
        for (i = 0; i < MAX_GNB_PER_SYS; i++)
        {
            const VccbGnbInfo_type *const pGnb = &GNBINFO[i];

            if ((EQUIP == pGnb->status) && (gnbId == pGnb->globalGnbId.gnbId.id))
            {
                *gnbNum = i;
                return GOOD;
            }
        }
        return ERROR;
    }
    else
    {
        for (i = 0; i < MAX_GNB_PER_SYS; i++)
        {
            if ((CFG->gnbNumInfo.gnbIdFromNum[i].status == EQUIP) && (CFG->gnbNumInfo.gnbIdFromNum[i].gnbId == gnbId))
            {
                *gnbNum = i;
                return GOOD;
            }
        }

        VRRM_PRINT(VRRM_ERROR, "[%s   %d] ERROR fail to get gnbNum from gnbId = %d\n", __FILE__, __LINE__, gnbId);

        return ERROR;
    }
}
/**
 * @brief     Get Priority Level
 * @param     ptQi : qosFlow, ptPriorityLevel : priorityLevel
 * @return
 */
void VLIB_getPriorityLevelQos(qosFlowInfo_type *ptQi, uint16_t *ptPriorityLevel)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptQi);
    VALID_E_POINT_CHECK_VOID(ptPriorityLevel);

    *ptPriorityLevel = 0xFFFF;

    if (ci_qos_char_non_dynamic_5qi == ptQi->qosParam.qosCharacteristics)
    {
        if (ptQi->qosParam.nonDyna.priorityLevelQosPresent)
        {
            *ptPriorityLevel = ptQi->qosParam.nonDyna.priorityLevelQos;
        }
    }
    else  // ci_qos_char_dynamic_5qi
    {
        *ptPriorityLevel = ptQi->qosParam.dynamic.priorityLevel;
    }
}
/**
 * @brief     Get 5qi value
 * @param     ptQi : qosFlow, ptFiveQi : fiveQi
 * @return
 */
void VLIB_getFiveQi(qosFlowInfo_type *ptQi, uint8_t *ptFiveQi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptQi);
    VALID_E_POINT_CHECK_VOID(ptFiveQi);

    *ptFiveQi = 0xFF;

    if (ci_qos_char_non_dynamic_5qi == ptQi->qosParam.qosCharacteristics)
    {
        *ptFiveQi = ptQi->qosParam.nonDyna.fiveQi;
    }
    else  // ci_qos_char_dynamic_5qi
    {
        /* TODO : dynamic 5qi is not supported yet */
        // if (ptQi->qosParam.dynamic.fiveQiPresent) // if not present, use default value 255
        // {
        //     *ptFiveQi = ptQi->qosParam.dynamic.fiveQi;
        // }
    }
}

uint8_t convertNeDcScgFailType(uint8_t failInfo)
{
    // return failureType in SCGFailureInformationEUTRA
    return ((failInfo > NeDcScgFailCauseInfo_UeScgChangeFailureEutra) ? 0xFF : (uint8_t)(failInfo - 1));
}

uint8_t convertNeDcScgFailInfo(uint8_t failType)
{
    // return enumNeDcScgFailCauseInfo_type
    return ((failType >= MAX_NEDC_SCG_FAIL_CAUSE_TYPE) ? 0xFF : (uint8_t)(failType + 1));
}

uint8_t getMgnbInitRelSenbIdx(uint8_t failInfo)
{
    // return STAT_NEDC_MGNB_INIT_REL_ITEM
    return ((failInfo >= MAX_NEDC_SCG_FAIL_CAUSE_INFO || failInfo == NeDcScgFailCauseInfo_NoScgFailure)
                ? 0xFF
                : (uint8_t)(failInfo + STAT_NEDC_MGNB_INIT_REL_OFFSET));
}
uint32_t VLIB_GetNedcSnodeEnbId(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    uint16_t xnIdx = MAX_XN_NBR_PER_GNB;
    uint32_t enbId = 0xFFFFFFFF;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, enbId);
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, enbId);

    xnIdx = ptCi->mrdcInfo.SNInfo[SRC_SN].epIdx;

    if (xnIdx >= MAX_XN_NBR_PER_GNB)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "xnIdx >= MAX_XN_NBR_PER_GNB  ERROR!! \n");
        goto END_OF_FUNC;
    }

    xnNbrInfo_type *pXnNbr;
    pXnNbr = FnVCCB_GetXnNbrInfo(ptCi->gnbNum, xnIdx);

    if (pXnNbr == NULL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetXnNbrInfo NULL!! \n");
        goto END_OF_FUNC;
    }

    enbId = pXnNbr->enbId.id;

END_OF_FUNC:
    return enbId;
}

bool FnVCCB_IsSaRreUE(const callInfo_type &callInfo)
{
    AUTO_TRACE_FUNC;

    if (callInfo.callType == E_CALLTYPE_NSA)
    {
        return false;
    }

    switch (callInfo.stateCmd)
    {
        case RrcReestablish_cmd:
            return true;

        default:
            break;
    }

    return false;
}

bool FnVCCB_IsSaMobilityUE(const callInfo_type &callInfo)
{
    AUTO_TRACE_FUNC;

    if (VHCM_isSaHandoverUE(&callInfo))
    {
        return true;
    }

    if (FnVCCB_IsSaRreUE(callInfo))
    {
        return true;
    }

    return false;
}

bool FnVCCB_IsSaIntraGnbHoUE(const callInfo_type &callInfo)
{  // {{{
    AUTO_TRACE_FUNC;

    if (VHCM_isSaHandoverUE(&callInfo) == FALSE)
    {
        return false;
    }

    switch (callInfo.hoInfo.hoType.initiated)
    {
        case HO_TYPE_SA_INTRA_GNB_INTRA_DU_HANDOVER:
        case HO_TYPE_SA_INTRA_GNB_INTER_DU_HANDOVER:
            return true;

        case HO_TYPE_SA_INIT:
        case HO_TYPE_MAX_OF_SA_HANDOVER:
            return false;

        default:
            break;
    }

    if (callInfo.hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
    {
        return true;
    }

    return false;
}  // }}}

bool FnVCCB_IsSaIntraGnbRreUE(const callInfo_type &callInfo)
{
    AUTO_TRACE_FUNC;

    if (FnVCCB_IsSaRreUE(callInfo) == false)
    {
        return false;
    }

    switch (callInfo.ueInfo.reestablishInfo.reestablishType)
    {
        case RRE_TYPE_INTRA_DU:
        case RRE_TYPE_INTER_DU:
            return true;

        default:
            break;
    }

    return false;
}

bool FnVCCB_IsSaIntraGnbMobilityUE(const callInfo_type &callInfo)
{
    AUTO_TRACE_FUNC;

    if (FnVCCB_IsSaIntraGnbHoUE(callInfo))
    {
        return true;
    }

    if (FnVCCB_IsSaIntraGnbRreUE(callInfo))
    {
        return true;
    }

    return false;
}

uint16_t GetMaxCIDAsSession(uint16_t choiceSession)
{
    uint16_t maxCID;
    switch (choiceSession)
    {
        case ci_maxROHC_Sessions_cs2:
            maxCID = 1;
            break;
        case ci_maxROHC_Sessions_cs4:
            maxCID = 3;
            break;
        case ci_maxROHC_Sessions_cs8:
            maxCID = 7;
            break;
        case ci_maxROHC_Sessions_cs12:
            maxCID = 11;
            break;
        case ci_maxROHC_Sessions_cs16:
            maxCID = 15;
            break;
        case ci_maxROHC_Sessions_cs24:
            maxCID = 23;
            break;
        case ci_maxROHC_Sessions_cs32:
            maxCID = 31;
            break;
        case ci_maxROHC_Sessions_cs48:
            maxCID = 47;
            break;
        case ci_maxROHC_Sessions_cs64:
            maxCID = 63;
            break;
        case ci_maxROHC_Sessions_cs128:
            maxCID = 127;
            break;
        case ci_maxROHC_Sessions_cs256:
            maxCID = 255;
            break;
        case ci_maxROHC_Sessions_cs512:
            maxCID = 511;
            break;
        case ci_maxROHC_Sessions_cs1024:
            maxCID = 1023;
            break;
        case ci_maxROHC_Sessions_cs16384:
            maxCID = 16383;
            break;
        default:
            maxCID = 1;
            break;
    }
    return maxCID;
}

uint16_t GetMaxEhcCIDAsSession(uint16_t choiceSession)
{
    uint16_t maxCID;
    switch (choiceSession)
    {

        case ci_maxEHC_Sessions_cs2 :
            maxCID = 1;
            break;
        case ci_maxEHC_Sessions_cs4 :
            maxCID = 3;
            break;
        case ci_maxEHC_Sessions_cs8 :
            maxCID = 7;
            break;
        case ci_maxEHC_Sessions_cs16 :
            maxCID = 15;
            break;
        case ci_maxEHC_Sessions_cs32 :
            maxCID = 31;
            break;
        case ci_maxEHC_Sessions_cs64 :
            maxCID = 63;
            break;
        case ci_maxEHC_Sessions_cs128 :
            maxCID = 127;
            break;
        case ci_maxEHC_Sessions_cs256 :
            maxCID = 255;
            break;
        case ci_maxEHC_Sessions_cs512 :
            maxCID = 511;
            break;
        case ci_maxEHC_Sessions_cs1024 :
            maxCID = 1023;
            break;
        case ci_maxEHC_Sessions_cs2048 :
            maxCID = 2047;
            break;
        case ci_maxEHC_Sessions_cs4096 :
            maxCID = 4095;
            break;
        case ci_maxEHC_Sessions_cs8192 :
            maxCID = 8191;
            break;
        case ci_maxEHC_Sessions_cs16384 :
            maxCID = 16383;
            break;
        case ci_maxEHC_Sessions_cs32768 :
            maxCID = 32767;
            break;
        case ci_maxEHC_Sessions_cs65536 :
            maxCID = 65535;
            break;
        default:
            maxCID = 1;
            break;
    }
    return maxCID;
}

/**
 * @brief     increase time transaction ID
 * @param     transactionId : transaction ID pointer
 */
int16_t VLIB_IncTimTransactionId(int16_t transactionId)
{
    AUTO_TRACE_FUNC;

    int16_t nonSeq;
    int16_t incTransactionId;

    nonSeq = transactionId & (int16_t)NON_SEQUENCE_MASK;

    incTransactionId = (int16_t)(transactionId + 1);

    incTransactionId = (int16_t)(nonSeq | (incTransactionId & (int16_t)SEQUENCE_MASK));

    return (incTransactionId);
}

/**
 * @brief     increase RRC transaction ID
 * @param     transactionId : transaction ID pointer
 */
int16_t VLIB_IncRRCTransactionId(uint8_t *transactionId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(transactionId);

    (*transactionId)++;

    if (*transactionId > 3)
    {
        *transactionId = 0;
    }

    return (*transactionId);
}

/**
 * @brief     Get transaction type
 */
int VLIB_CheckAddrOfPool(const char *file, int line, uint32_t type, const void *base, const void *ptr, int *ptCause)
{
    uint16_t size = 0;
    uint16_t maxNum = 0;
    const void *base1 = NULL;
    enumUsage_type usage = CI_no_use;

    if (ptCause) *ptCause = e_Invalid_unknown;

    if (ptr == NULL)
    {
        if (ptCause) *ptCause = e_Invalid_PointerAddress;
        return FALSE;
    }

    switch (type)
    {
        case SRB_NODE:
            base1 = static_cast<const callInfo_type *>(base)->srbInfo;
            size = sizeof(callSRBInfo_type);
            maxNum = MAX_SRB_PER_CALL;
            break;

        case ERAB_NODE:
            base1 = static_cast<const callInfo_type *>(base)->erabInfo;
            size = sizeof(callERABInfo_type);
            maxNum = MAX_ERAB_PER_CALL;
            break;

        case GNB_NODE:
            base1 = static_cast<const callInfo_type *>(base)->gnbInfo;
            size = sizeof(callGNBInfo_type);
            maxNum = MAX_GNB_PER_CALL;
            break;

        case PATH_NODE:
            base1 = static_cast<const callGNBInfo_type *>(base)->dlPath;
            size = sizeof(pathInfo_type);
            maxNum = MAX_ERAB_PER_CALL * 2;
            break;

        case PDU_NODE:
            base1 = static_cast<const callInfo_type *>(base)->pduSess;
            size = sizeof(callPDUSessInfo_type);
            maxNum = MAX_PDU_SESS_PER_CALL;
            break;

        case DRB_NODE:
            base1 = static_cast<const callInfo_type *>(base)->drb;
            size = sizeof(callDRBInfo_type);
            maxNum = MAX_DRB_PER_SA_CALL;
            break;

        case QOSFLOW_NODE:
            base1 = static_cast<const callInfo_type *>(base)->qosFlow;
            size = sizeof(qosFlowInfo_type);
            maxNum = MAX_QOS_FLOW_PER_CALL;
            break;

        case COND_CELL_NODE:
            base1 = static_cast<const callInfo_type *>(base)->condHoInfo.cellList;
            size = sizeof(conditionalCellInfo_type);
            maxNum = MAX_NUM_COND_CELLS;
            break;

        case LTM_CELL_NODE:
            base1 = static_cast<const callInfo_type *>(base)->ltmUeInfo.cellList;
            size = sizeof(ltmCellInfo_type);
            maxNum = MAX_NUM_COND_CELLS;
            break;

        default:
            VCCB_PRINT_ERROR("%s %d: Unknown Type(%u)\n", FnVCCB_GetFileName(file), line, type);
            if (ptCause) *ptCause = e_Invalid_UnknownNodeType;
            return FALSE;
    }

    if ((long)ptr >= (long)base1 && (long)ptr < ((long)base1 + (long)size * maxNum))
    {
        if (((long)ptr - (long)base1) % size == 0)
        {
            if (type == SRB_NODE)
            {
                usage = static_cast<enumUsage_type>(static_cast<const callSRBInfo_type *>(ptr)->usage);
            }
            else if (type == ERAB_NODE)
            {
                usage = static_cast<enumUsage_type>(static_cast<const callERABInfo_type *>(ptr)->usage);
            }
            else if (type == GNB_NODE)
            {
                usage = static_cast<const callGNBInfo_type *>(ptr)->usage;
            }
            else if (type == PDU_NODE)
            {
                usage = static_cast<enumUsage_type>(static_cast<const callPDUSessInfo_type *>(ptr)->usage);
            }
            else if (type == DRB_NODE)
            {
                usage = static_cast<enumUsage_type>(static_cast<const callDRBInfo_type *>(ptr)->usage);
            }
            else if (type == QOSFLOW_NODE)
            {
                usage = static_cast<enumUsage_type>(static_cast<const qosFlowInfo_type *>(ptr)->usage);
            }
            else if (type == PATH_NODE)
            {
                usage = static_cast<enumUsage_type>(static_cast<const pathInfo_type *>(ptr)->usage);
            }
            else if (type == COND_CELL_NODE)
            {
                usage = static_cast<enumUsage_type>(static_cast<const conditionalCellInfo_type *>(ptr)->usage);
            }
            else if (type == LTM_CELL_NODE)
            {
                usage = static_cast<enumUsage_type>(static_cast<const ltmCellInfo_type *>(ptr)->handle.usage);
            }

            if (usage == CI_use)
            {
                if (ptCause) *ptCause = e_Valid_Ok;
                return TRUE;
            }

            // else == CI_no_use
            if (ptCause) *ptCause = e_Invalid_no_use;

            return FALSE;
        }
        else
        {
            VCCB_PRINT_ERROR("Modula is not Zero... \n");
            VCCB_PRINT_ERROR("%s %d: type(%u), base1(0x%lx), ptr(0x%lx), size(%d), num(%d), usage(%d)\n", FnVCCB_GetFileName(file), line,
                type, (long)base1, (long)ptr, size, maxNum, usage);
            if (ptCause) *ptCause = e_Invalid_MoudlaIsNotZero;

            return FALSE;
        }
    }
    else
    {
        VCCB_PRINT_ERROR("Out of Valid Range... \n");
        VCCB_PRINT_ERROR("%s %d: type(%u), base1(0x%lx), ptr(0x%lx), size(%d), num(%d), usage(%d)\n", FnVCCB_GetFileName(file), line, type,
            (long)base1, (long)ptr, size, maxNum, usage);
        if (ptCause) *ptCause = e_Invalid_OutOfValidRange;

        return FALSE;
    }
}

/**
 * @brief     Set radio bearer status
 */
void VLIB_CallFaultSave(callInfo_type *ptCi, uint32_t msgId, uint16_t cause, const char *fnName)
{
    AUTO_TRACE_FUNC;

    uint16_t noFault;

    if (ptCi == NULL)
    {
        VCCB_PRINT_ERROR("ptCi(=NULL) in VLIB_CallFaultSave\n");
        return;
    }

    noFault = CAUSE_NO_FAULT;

    if (cause == noFault)
    {
        if (DBG->flag.logCsl) VCCB_PRINT_CALL_ERROR(ptCi, "[CRR] Clear! in %s\n", fnName);

        ptCi->cause.callFault.callFaultCause = noFault;
        ptCi->cause.callFault.fnName[0] = '\0';
        ptCi->cause.callFault.stateCmd = Idle_cmd;
        ptCi->cause.callFault.msgId = msgId;
        ptCi->cause.e1Cause = CauseE1apRadioNetworkLayerNormalRelease;
        ptCi->cause.f1Cause = CauseF1apRadioNormalRelease;
        ptCi->cause.x2Cause = CauseX2apRadioNetworkLayerUnspecified;
        ptCi->cause.ngCause = CauseNgapRadioNetworkLayerUnspecified;
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerUnspecified;
        return;
    }

    if (cause == CauseCpInternalCpSrb3IntegrityFailure)
    {  // CauseCpInternalCpSrb3IntegrityFailure is not used anymore
        cause = CauseCpInternalCpSrbIntegrityFailure;
    }

    if ((noFault == ptCi->cause.callFault.callFaultCause && CHECK_NOT_STATECMD_RELEASE(ptCi)))
    {  // The First Fault Occurred or CRR for TOUT
        FnVCCB_ConvertUndefinedCRR(ptCi, &cause);

        if (DBG->flag.logCsl) VCCB_PRINT_CALL_ERROR(ptCi, "[CRR] Setting! in %s\n", fnName);

        ptCi->cause.callFault.callFaultCause = cause;
        ptCi->cause.callFault.msgId = msgId;
        ptCi->cause.callFault.stateCmd = ptCi->stateCmd;
        if (strlen(fnName) >= 5)
            snprintf(ptCi->cause.callFault.fnName, sizeof(ptCi->cause.callFault.fnName), "%s", &fnName[5]);
        else
            snprintf(ptCi->cause.callFault.fnName, sizeof(ptCi->cause.callFault.fnName), "%s", fnName);

        /* Mapping Cause */
        MACRO_GET_INTERFACE_CAUSE(ptCi, cause);
        ptCi->cause.callFault.callState = ptCi->state;

        // FGR-CC5200:FR640
        FnVCCB_NrdcCtxRelStat_SaveSnRelType(ptCi, PSCellDrop_END, SRC_SN);
    }
}

/**
 * @brief     Convert Cause enum to string
 */
const char *VLIB_FailureTypeToStr(uint32_t failureType)
{
#define FAILURE_TYPE_STR(FAILURE_TYPE) \
    case FAILURE_TYPE:                 \
        return #FAILURE_TYPE;
    switch (failureType)
    {
        FAILURE_TYPE_STR(NRRRC_scgFailureInfo_failureType_t310_Expiry);
        FAILURE_TYPE_STR(NRRRC_scgFailureInfo_failureType_randomAccessProblem);
        FAILURE_TYPE_STR(NRRRC_scgFailureInfo_failureType_rlc_MaxNumRetx);
        FAILURE_TYPE_STR(NRRRC_scgFailureInfo_failureType_srb3_IntegrityFailure);
        FAILURE_TYPE_STR(NRRRC_synchReconfigFailure_SCG);
        FAILURE_TYPE_STR(NRRRC_scg_reconfigFailure);

        default:
            return "Unknown failureType";
    }
#undef FAILURE_TYPE_STR
}

/**
 * @brief     Convert Cause enum with failure r16 to string
 */
const char *VLIB_FailureTypeToStr_r16(uint32_t failureType)
{
#define FAILURE_TYPE_STR(FAILURE_TYPE) \
    case FAILURE_TYPE:                 \
        return #FAILURE_TYPE;
    switch (failureType)
    {
        FAILURE_TYPE_STR(NRRRC_scg_lbtFailure_r16_1);
        FAILURE_TYPE_STR(NRRRC_beamFailureRecoveryFailure_r16_1);
        FAILURE_TYPE_STR(NRRRC_t312_Expiry_r16_1);
        FAILURE_TYPE_STR(NRRRC_bh_RLF_r16_1);

        default:
            return "Unknown failureType r16";
    }
#undef FAILURE_TYPE_STR
}

/**
 * @brief     Convert RRE Cause enum to string
 */
const char *VLIB_RreCauseToStr(uint16_t cause)
{
#define RRE_CAUSE_STR(RRE_CAUSE) \
    case RRE_CAUSE:              \
        return #RRE_CAUSE;

    switch (cause)
    {
        RRE_CAUSE_STR(NRRRC_reconfigurationFailure);
        RRE_CAUSE_STR(NRRRC_handoverFailure);
        RRE_CAUSE_STR(NRRRC_otherFailure);
        RRE_CAUSE_STR(NRRRC_ReestablishmentCause_spare1);
        default:
            return "Unknown RreCause";
    }
#undef RRE_CAUSE_STR
}

/**
 * @brief     Convert SCGFailure Cause enum to string
 */
const char *VLIB_ScgFailureCauseToStr(uint16_t cause)
{
    switch (cause)
    {
        case NrDcScgFailCause_dl_t310Expiry:
            return "dl_t310Expiry";
        case NrDcScgFailCause_dl_randomAccessProblem:
            return "dl_randomAccessProblem";
        case NrDcScgFailCause_dl_rlcMaxRetransmission:
            return "dl_rlcMaxRetransmission";
        case NrDcScgFailCause_dl_synchReconfigFailure:
            return "dl_synchReconfigFailure";
        case NrDcScgFailCause_dl_scgReconfigFailure:
            return "dl_scgReconfigFailure";
        case NrDcScgFailCause_dl_srb3IntegrityFailure:
            return "dl_srb3IntegrityFailure";
        case NrDcScgFailCause_dl_scglbtFailure:
            return "dl_scglbtFailure";
        case NrDcScgFailCause_dl_beamFailureRecoveryFailure:
            return "dl_beamFailureRecoveryFailure";
        case NrDcScgFailCause_dl_t312Expiry:
            return "dl_t312Expiry";
        case NrDcScgFailCause_dl_bhRLF:
            return "dl_bhRLF";
        case NrDcScgFailCause_ul_outOfSync:
            return "ul_outOfSync";
        case NrDcScgFailCause_ul_rlcMaxRetransmission:
            return "ul_rlcMaxRetransmission";
        default:
            return "Unknown SCGFailure Cause";
    }
}

/**
 * @brief     Convert UeAllPowerClass enum to string
 */
const char *VLIB_UeAllPowerClassToStr(uint16_t pc)
{
    switch (pc)
    {
        case PowerClass_None:
            return "PowerClass_None";
        case PowerClass_Pc1:
            return "PowerClass_Pc1";
        case PowerClass_Pc1dot5:
            return "PowerClass_Pc1dot5";
        case PowerClass_Pc2:
            return "PowerClass_Pc2";
        case PowerClass_Pc3:
            return "PowerClass_Pc3";
        case PowerClass_Pc4:
            return "PowerClass_Pc4";
        default:
            return "Unknown Power Class";
    }
}

/**
 * @brief     Convert ReportConfigType enum to string
 */
const char *VLIB_ReportConfigTypeToStr(uint32_t repType)
{
    switch (repType)
    {
        case measReport_periodical:
            return "Pd";
        case measReport_A1:
            return "A1";
        case measReport_A2:
            return "A2";
        case measReport_A3:
            return "A3";
        case measReport_A4:
            return "A4";
        case measReport_A5:
            return "A5";
        case measReport_A6:
            return "A6";
        case measReport_B1Eutra:
            return "B1e";
        case measReport_B2Eutra:
            return "B2e";
        case measReport_reportCGI:
            return "RC";
        case measReport_reportCGIEutra:
            return "RCe";
        case measReport_periodicalInterRat:
            return "Pdi";
        default:
            return "Unknown reportConfigType";
    }
    return "Unknown";
}

/**
 * @brief     get current tick data Monotonic
 */
struct timespec tickGetMono(void)
{
    AUTO_TRACE_FUNC;

    struct timespec stime;
    int rslt = 0;

    /* getting timestamp */
    if ((rslt = clock_gettime(CLOCK_MONOTONIC, &stime)) != 0)
    {
        VCCB_PRINT_ERROR("clock_gettime() ERROR, error(%d)\n", rslt);
    }

    return stime;
}

/**
 * @brief     Get time duration from prevTime to current time, unit is millisec
 */
// long  VLIB_getTickDifference (struct timeval prevTime)
long VLIB_getTickDifference(struct timespec prevTime)
{
    AUTO_TRACE_FUNC;

#ifdef IPC_TEST
    if (DBG->isSetjumpTime == VCCB_FLAG_ON)
    {
        DBG->isSetjumpTime = VCCB_FLAG_OFF;
        return (DBG->jumpTime.tv_sec * 1000 + DBG->jumpTime.tv_nsec / 1000000);
    }
#endif

    long diffTime;
    struct timespec curTime;

    curTime = tickGetMono();
    diffTime = (curTime.tv_sec - prevTime.tv_sec) * 1000 + (curTime.tv_nsec - prevTime.tv_nsec) / 1000000;

    if (diffTime <= 0)
    {
        diffTime = 0;
    }

    return diffTime;
}

/*
 * @brief     Get time duration from prevTime to specific time, unit is millisec
 */
long VLIB_getTickDifferenceWithTime(struct timespec prevTime, struct timespec specTime)
{
    AUTO_TRACE_FUNC;

    long diffTime;

    diffTime = (specTime.tv_sec - prevTime.tv_sec) * 1000 + (specTime.tv_nsec - prevTime.tv_nsec) / 1000000;

    if (diffTime <= 0)
    {
        diffTime = 0;
    }

    return diffTime;
}

/**
 * @brief     Get time duration from prevTime to current time, unit is nanosec
 */
long long VLIB_getTickDifferenceNanoSec(struct timespec prevTime)
{
    AUTO_TRACE_FUNC;

    long long diffTime;

    struct timespec curTime;

    curTime = tickGetMono();
    diffTime = (curTime.tv_sec - prevTime.tv_sec) * 1000000 + (curTime.tv_nsec - prevTime.tv_nsec) / 1000;

    if (diffTime <= 0)
    {
        diffTime = 0;
    }

    return diffTime;
}

/**
 * @brief      This function is used to convert the TAC from hex string to int.
 * @param      NONE
 * @return     GOOD, ERROR
 */
int VLIB_HexstrToInt(uint32_t numByte, unsigned char *value, uint32_t len, uint32_t *intValue)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(value);
    VALID_E_POINT_CHECK_ERROR(intValue);
    unsigned char *pVal = value;
    unsigned char tmpChar = 0;
    uint32_t i = 0;

    // Init intValue
    *intValue = 0;

    for (i = 0; (i < len) && (i < numByte * CHAR_TO_HEX_STR_LEN); i++)
    {
        if (*pVal >= '0' && *pVal <= '9')
            tmpChar = (unsigned char)(*pVal - '0');
        else
            tmpChar = (unsigned char)(*pVal - 'A' + 10);
        *intValue = (*intValue << 4) | tmpChar;
        pVal++;
    }
    return GOOD;
}

int16_t FnVCCB_Fill_CellInfo_NRCGI(const uint16_t cellNum, cgi_type *ptOut)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptOut);

    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    if (pCell->status != EQUIP)
    {
        return ERROR;
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(pCell->gnbNum, MAX_GNB_PER_SYS);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[pCell->gnbNum];

    if (pGnb->status != EQUIP)
    {
        return ERROR;
    }

    ptOut->ci = pCell->cgi.ci;

    ptOut->plmn.s2.mcc = pGnb->globalGnbId.plmn.s2.mcc;
    ptOut->plmn.s2.mnc = pGnb->globalGnbId.plmn.s2.mnc;

    // Reserved Field Clear
    memset(&ptOut->reserved, 0x00, sizeof(ptOut->reserved));
    ptOut->plmn.s2.reserved = 0;  // Always Clear

    return GOOD;
}

cgi_type FnVCCB_GetCellNbr_NRCGI(const nbrCellInfo_type &cellNbr)
{
    AUTO_TRACE_FUNC;
    cgi_type result;
    result.ci = VLIB_GnbIdCellId2NrCellId(&cellNbr.targetGnbId.gnbId, cellNbr.targetCellId);

    result.plmn.s2.mcc = cellNbr.targetGnbId.plmn.s2.mcc;
    result.plmn.s2.mnc = cellNbr.targetGnbId.plmn.s2.mnc;

    memset(&result.reserved, 0x00, sizeof(result.reserved));
    result.plmn.s2.reserved = 0;

    return result;
}

int16_t FnVCCB_Fill_CellNbr_NRCGI(const uint16_t cellNum, const uint16_t nbrIdx, cgi_type *ptOut)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptOut);

    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_NBR_PER_CELL);

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    if (pCell->status != EQUIP)
    {
        return ERROR;
    }

    if (pCell->Nbr[nbrIdx].status != EQUIP)
    {
        return ERROR;
    }

    ptOut->ci = VLIB_GnbIdCellId2NrCellId(&pCell->Nbr[nbrIdx].targetGnbId.gnbId, pCell->Nbr[nbrIdx].targetCellId);

    ptOut->plmn.s2.mcc = pCell->Nbr[nbrIdx].targetGnbId.plmn.s2.mcc;
    ptOut->plmn.s2.mnc = pCell->Nbr[nbrIdx].targetGnbId.plmn.s2.mnc;

    // Reserved Field Clear
    memset(&ptOut->reserved, 0x00, sizeof(ptOut->reserved));
    ptOut->plmn.s2.reserved = 0;  // Always Clear

    return GOOD;
}

/*
 * @brief      This function is used to convert the enbId(20bits) and cellId(8bits) to EUTRA cell identity (28 bit).
 * @param      cellNum, eutraNbr nbrIdx
 * @param      EUTRA Cell Identity (28 bit)
 * @return     result of function
 */
int16_t FnVCCB_Fill_CellEutraNbr_ECGI(const uint16_t cellNum, const uint16_t nbrIdx, cgi_type *ptOut)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptOut);

    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL);

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    if (pCell->status != EQUIP)
    {
        return ERROR;
    }

    if (pCell->eutraNbr[nbrIdx].status != EQUIP)
    {
        return ERROR;
    }

    ptOut->ci = pCell->eutraNbr[nbrIdx].targetEnbId<< 8 | pCell->eutraNbr[nbrIdx].cellId;

    ptOut->plmn.s2.mcc = pCell->eutraNbr[nbrIdx].plmn.s2.mcc;
    ptOut->plmn.s2.mnc = pCell->eutraNbr[nbrIdx].plmn.s2.mnc;

    // Reserved Field Clear
    memset(&ptOut->reserved, 0x00, sizeof(ptOut->reserved));
    ptOut->plmn.s2.reserved = 0;  // Always Clear

    return GOOD;
}

/*
 * @brief      This function is used to convert the gnbId and cellId(2-14 bit) to NR cell identity (36 bit).
 * @param      pGnbId, cellId (2-14 bit)
 * @return     NR Cell Identity (36 bit)
 */
uint64_t VLIB_GnbIdCellId2NrCellId(const gnbId_type *pGnbId, uint16_t cellId)
{
    //  | NRCGI : Cell Global Identity                                                  |
    //  | PLMN       | NCI : NR Cell Identity (36 bit, ~68719476735)                    | <= Output
    //  | MCC  | MNC | GNB ID (22-32 bit, ~ 4294967295) | CELL ID (14-2 bit, ~ 16383)   | <= Input

    // The NR gNB id can be from 22-32 bits in length.
    // Corresponding Local cell id would be 14 to 4 bits.
    // So the full NCI (gNB+CI is 36 bits from 0 to 68719476735)
    // The max gNB Id with 32 bits will be from 0 to 4294967295
    // The max CellId with 14 bits will be from 0 to 16383
    uint64_t nrCellId = cellId;

    if (NULL != pGnbId)
    {
        nrCellId |= ((uint64_t)pGnbId->id << (MAX_NR_CELLIDENTITY_BIT - pGnbId->idLength));
    }

    return nrCellId;
}

/*
 * @brief      This function is used to convert the NR cell identity (36 bit) to cellId(2-14 bit).
 * @param      GNB ID Length(22-32 bit), NR Cell Identity (36 bit)
 * @return     cellId (2-14 bit)
 */
uint16_t VLIB_NrCellId2CellId(const uint8_t gnbIdLen, const uint64_t NCI_36bit)
{
    //  | NRCGI : Cell Global Identity                                                  |
    //  | PLMN       | NCI : NR Cell Identity (36 bit, ~68719476735)                    | <= Input
    //  | MCC  | MNC | GNB ID (22-32 bit, ~ 4294967295) | CELL ID (14-2 bit, ~ 16383)   | <= Output(CELL ID)

    // The NR gNB id can be from 22-32 bits in length.
    // Corresponding Local cell id would be 14 to 4 bits.
    // So the full NCI (gNB+CI is 36 bits from 0 to 68719476735)
    // The max gNB Id with 32 bits will be from 0 to 4294967295
    // The max CellId with 14 bits will be from 0 to 16383

    AUTO_TRACE_FUNC;

    const uint8_t cellIdLen = (uint8_t)MIN(MAX_CELLIDENTITY_BIT, (MAX_NR_CELLIDENTITY_BIT - gnbIdLen));

    const uint16_t localCellId = (NCI_36bit & ((1UL << cellIdLen) - 1UL)) & e_BitMask_14bit;

    return localCellId;
}

/*
 * @brief      This function is used to convert the NR cell identity (36 bit) to gnbId(22-32 bit).
 * @param      GNB ID Length(22-32 bit), NR Cell Identity (36 bit)
 * @return     gnbId (22-32 bit)
 */
uint32_t VLIB_NrCellId2GnbId(const uint8_t gnbIdLen, const uint64_t NCI_36bit)
{
    //  | NRCGI : Cell Global Identity                                                  |
    //  | PLMN       | NCI : NR Cell Identity (36 bit, ~68719476735)                    | <= Input
    //  | MCC  | MNC | GNB ID (22-32 bit, ~ 4294967295) | CELL ID (14-2 bit, ~ 16383)   | <= Output(GNB ID)

    // The NR gNB id can be from 22-32 bits in length.
    // Corresponding Local cell id would be 14 to 4 bits.
    // So the full NCI (gNB+CI is 36 bits from 0 to 68719476735)
    // The max gNB Id with 32 bits will be from 0 to 4294967295
    // The max CellId with 14 bits will be from 0 to 16383

    AUTO_TRACE_FUNC;

    const uint8_t gnbIdLength = (uint8_t)MIN(MAX_LENGTH_GNB_ID, MAX(MIN_LENGTH_GNB_ID, gnbIdLen));

    const uint8_t cellIdLen = (uint8_t)MIN(MAX_CELLIDENTITY_BIT, (MAX_NR_CELLIDENTITY_BIT - gnbIdLength));

    const uint32_t localGnbId = (NCI_36bit >> cellIdLen) & e_BitMask64_32bit;

    return localGnbId;
}

/**
 * @brief     Upload logs in shared memory to VSM
 */
void VLIB_UploadShmLogs(void)
{
    AUTO_TRACE_FUNC;

    VCCB_PRINTF("Shared Memory Log Full(Partial)! The logs will be uploaded!\n");

    FnVCCB_ExecuteCommand("itscp_vccb get log upload log &");
}

void FnVCCB_UploadShmLogAll(void)
{
    AUTO_TRACE_FUNC;

    VCCB_PRINTF("Shared Memory Log Full(All)! The logs will be uploaded!\n");

    FnVCCB_ExecuteCommand("itscp_vccb get log upload all &");
}

/**
 * @brief     Upload fishing logs in shared memory to VSM
 */
void VLIB_UploadShmFishingLogs(void)
{
    AUTO_TRACE_FUNC;

    FnVCCB_ExecuteCommand("itscp_vccb get log upload fishing &");
}

enumActivityNotificationMode getInactivityVendor(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, ActivityNotification_Off);

    // if test flag on, see CFG->inactivityVendor
    if (CFG->inactivityVendor != ActivityNotification_Off)
    {
        if (CFG->inactivityVendor == ActivityNotification_SamsungEnb)
        {
            return ActivityNotification_SamsungEnb;
        }
        else if (CFG->inactivityVendor == ActivityNotification_OtherEnb)
        {
            return ActivityNotification_OtherEnb;
        }
    }

    if (ptCi->eNBInfo.x2VendorInd == 1)  // 0: others, 1: samsungEnb
    {
        return ActivityNotification_SamsungEnb;
    }
    else
    {
        return ActivityNotification_OtherEnb;
    }
}
void VLIB_FillSuspendTimeStartCsl(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->cslInfo.scgFailureHistory.lastIdx, MAX_SCG_FAILURE_COUNT);

    if (CI_use == ptCi->cslInfo.scgFailureHistory.scgFailure[ptCi->cslInfo.scgFailureHistory.lastIdx].usage &&
        VCCB_SUSPEND_STATE_OFF ==
            ptCi->cslInfo.scgFailureHistory.scgFailure[ptCi->cslInfo.scgFailureHistory.lastIdx].suspendTimeState)
    {
        VLIB_SetCurrentTime(
            &ptCi->cslInfo.scgFailureHistory.scgFailure[ptCi->cslInfo.scgFailureHistory.lastIdx].suspendTime);
        ptCi->cslInfo.scgFailureHistory.scgFailure[ptCi->cslInfo.scgFailureHistory.lastIdx].suspendTimeState =
            VCCB_SUSPEND_STATE_INIT;
    }

    return;
}
void VLIB_FillSuspendTimeEndCsl(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->cslInfo.scgFailureHistory.lastIdx, MAX_SCG_FAILURE_COUNT);
    vccbTimeInfo_type endTime;
    vccbTimeInfo_type diffTime;

    if (CI_use == ptCi->cslInfo.scgFailureHistory.scgFailure[ptCi->cslInfo.scgFailureHistory.lastIdx].usage &&
        VCCB_SUSPEND_STATE_INIT ==
            ptCi->cslInfo.scgFailureHistory.scgFailure[ptCi->cslInfo.scgFailureHistory.lastIdx].suspendTimeState)
    {
        VLIB_SetCurrentTime(&endTime);
        VIIL_calcTimeDiff(&diffTime,
            &ptCi->cslInfo.scgFailureHistory.scgFailure[ptCi->cslInfo.scgFailureHistory.lastIdx].suspendTime, &endTime);
        ptCi->cslInfo.scgFailureHistory.scgFailure[ptCi->cslInfo.scgFailureHistory.lastIdx].suspendTime = diffTime;
        ptCi->cslInfo.scgFailureHistory.scgFailure[ptCi->cslInfo.scgFailureHistory.lastIdx].suspendTimeState =
            VCCB_SUSPEND_STATE_SET;
    }

    return;
}

static inline
uint16_t FnVCCB_GetSrbErabTransactionId(uint8_t srbIdx, uint8_t erabIdx)
{
    const uint8_t maxOfGnbPerCall = MAX_GNB_PER_CALL + 1U;

    const uint8_t srbMask = (uint16_t)((srbIdx) << SRB_SHIFT) & SRB_MASK;
    const uint8_t erabMask = (uint16_t)((erabIdx) << ERAB_SHIFT) & ERAB_MASK;
    const uint16_t gnbMask = (uint16_t)((maxOfGnbPerCall) << GNB_SHIFT) & GNB_MASK;

    return (uint16_t)(srbMask + erabMask + gnbMask);
}

/**
 * @brief     Initialize SRB information in call context
 * @param     ptCi : call context
 * @param     ptSi : call SRB information
 * @param     srbIdx : SRB index to allocate / uint16_t
 */
void VLIB_InitCallSrbInfo(callInfo_type *ptCi, callSRBInfo_type *ptSi, uint8_t srbIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptSi);

    ptCi->reserved = 0;  // for warning removal

    memset((uint8_t *)ptSi, 0xFF, sizeof(callSRBInfo_type));

    ptSi->usage = CI_use;
    ptSi->srbIdx = srbIdx;

    VCCB_CLEAR_TIMER(&ptSi->timer, INIT_TIMER);

    ptSi->transactionId = FnVCCB_GetSrbErabTransactionId(srbIdx, MAX_ERAB_PER_CALL + 1U);

    ptSi->flag.setupFlag = 0;
    ptSi->flag.releaseFlag = 0;
    ptSi->flag.respFlag = 0;

    ptSi->srbStatus = ERAB_Idle;

    ptSi->rbInfo.rbId = (uint8_t)(srbIdx + 1);

    if (0 != FnPDCP_C_Init(&ptSi->pdcpRbContext, ptSi->rbInfo.rbId))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnPDCP_C_Init ERROR!\n");
    }
}

/**
 * @brief     Initialize ERAB information in call context
 * @param     ptCi : call context
 * @param     ptRi : ERAB information
 * @param     erabIdx : ERAB index to allocate / uint16_t
 */
void VLIB_InitCallErabInfo(callInfo_type *ptCi, callERABInfo_type *ptRi, uint8_t erabIdx)
{
    AUTO_TRACE_FUNC;

    struct tm sTime_l;
    struct tm *sTime = &sTime_l;
    time_t timeCnt;
    uint32_t loop1 = 0;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptRi);

    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    memset((uint8_t *)ptRi, 0xFF, sizeof(callERABInfo_type));

    if (ptRi->usage != CI_use)
    {
        ptRi->usage = CI_use;
        ptCi->numERAB++;
    }
    ptRi->erabIdx = erabIdx;

    // VCCB_CLEAR_TIMER(&ptRi->timer, INIT_TIMER);
    ptRi->transactionId = FnVCCB_GetSrbErabTransactionId(MAX_SRB_PER_CALL + 1U, erabIdx);

    ptRi->flag.setupFlag = 0;
    ptRi->flag.releaseFlag = 0;
    ptRi->flag.respFlag = 0;

    ptRi->prevErabStatus = ERAB_Idle;
    ptRi->erabStatus = ERAB_Idle;
    ptRi->activityStatus = ActivityStatus_ACTIVE;
    ptRi->activityStatusPrev = ActivityStatus_ACTIVE;

    ptRi->s1uDlInfo.fNeedModify = 0;
    ptRi->s1uUlInfo.fNeedModify = 0;
    ptRi->x2uDlInfo.fNeedModify = 0;
    ptRi->x2uUlInfo.fNeedModify = 0;
    ptRi->f1uDlInfo.fNeedModify = 0;
    ptRi->f1uDlInfoPrev.fNeedModify = 0;
    ptRi->f1uUlInfo.fNeedModify = 0;
    ptRi->x2uForwardUlInfo.fNeedModify = 0;
    ptRi->x2uForwardDlInfo.fNeedModify = 0;

    ptRi->snStatus.needSendFlag = FLAG_OFF;
    ptRi->snStatus.dlForwardFlag = 0;
    ptRi->snStatus.ulForwardFlag = 0;
    ptRi->snStatus.ulSN = 0;
    ptRi->snStatus.dlSN = 0;
    ptRi->snStatus.ulHFN = 0;
    ptRi->snStatus.dlHFN = 0;
    memset(ptRi->snStatus.ulRcvStatus, 0, sizeof(ptRi->snStatus.ulRcvStatus));
    ptRi->erabStatistic.statState = CALL_SUCCESS;

    // rbPdcpSdapConfig_type
    //    ptRi->rbInfo.maxRetransInd = 0;
    ptRi->rbInfo.pdcpInfo.isPdcpConfigured = VCCB_FLAG_OFF;
    ptRi->rbInfo.pdcpInfo.headerCompression.ulRohcEnabled = FLAG_OFF;
    ptRi->rbInfo.pdcpInfoPrev.headerCompression.ulRohcEnabled = FLAG_OFF;
    ptRi->rbInfo.pdcpInfo.reestablishPdcp = FLAG_OFF;
    ptRi->rbInfo.pdcpInfoPrev.reestablishPdcp = FLAG_OFF;

    ptRi->rbInfo.pdcpInfo.headerCompression.isDrbContinueRohcPossible = FLAG_OFF;
    ptRi->rbInfo.pdcpInfoPrev.headerCompression.isDrbContinueRohcPossible = FLAG_OFF;

    ptRi->rbInfo.pdcpInfo.headerCompression.rohc_m.ulRohcEnabled = OPT_NOT_PRESENT;
    ptRi->rbInfo.pdcpInfo.m.headerCompression = OPT_NOT_PRESENT;

    /*For Preemption*/
    timeCnt = time(NULL);
    localtime_r(&timeCnt, sTime);

    ptRi->setupYear = (uint16_t)(sTime->tm_year + 1900);
    ptRi->setupMon = (uint8_t)(sTime->tm_mon + 1);
    ptRi->setupMday = (uint8_t)(sTime->tm_mday);
    ptRi->setupHour = (uint8_t)(sTime->tm_hour);
    ptRi->setupMin = (uint8_t)(sTime->tm_min);
    ptRi->setupSec = (uint8_t)(sTime->tm_sec);

    for (loop1 = 0; loop1 < MAX_VCCB_ERAB_FAMILY_TYPE; loop1++)
    {
        ptRi->erabStatistic.attemptFlag[loop1] = 0;
    }

    ptRi->ulPdcpPathPrev = UlPdcpPath_ScgShared;
    ptRi->ulPdcpPath = UlPdcpPath_ScgShared;

    ptRi->ulPdcpPathToMod = UlConfigBearer_ModOff;
    ptRi->ulPdcpPathEnq = VCCB_FLAG_OFF;
    ptRi->ulPdcpPathEnqToSet = UlPdcpPath_ScgShared;
    ptRi->dataSplitThreshold = NRRRC_b0;
    ptRi->prevDataSplitThreshold = NRRRC_b0;

    ptRi->packetInspectionQciFlag = VCCB_FLAG_OFF;
    ptRi->dlTrafficAboveThldFlag = VCCB_FLAG_OFF;

    ptRi->sgnbInitRelFlag = FLAG_OFF;

    ptRi->cslAllocOrder = ptCi->cslInfo.cslErabPduDrbAllocIdx;

    ptRi->holdTime.isRunning = FALSE;
    ptRi->qosModFlag = VCCB_FLAG_OFF;
}

static inline int16_t FnVCCB_SyncData_WithThread(const uint8_t threadId, char *pAddr, const int hasKey, const unsigned long size)
{
    int ret;

    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pAddr);

    if (DBG->flag.isSkipHasDirectSync)
    {
        return GOOD;
    }

    if (threadId >= MAX_CALL_THREAD_NUM_VCCB)
    {
        VCCB_PRINT_ERROR("%s: Invalid ThreadId(%d)\n", __FUNCTION__, threadId);
        return ERROR;
    }

    INCREASE_LOCAL_HAS_CALL_STAT1(threadId, hasDirectSync_Att);

    if ((ret = hasDirectSync(hasKey, pAddr, size)) >= 0)
    {
        INCREASE_LOCAL_HAS_CALL_STAT1(threadId, hasDirectSync_Succ);
        VCCB_STAT->localStat.hasCallStat1[threadId].syncedSize += size;

        return GOOD;
    }

    INCREASE_LOCAL_HAS_CALL_STAT1(threadId, hasDirectSync_Fail);
    VCCB_PRINTF("%s: hasDirectSync Failed(%d)\n", __FUNCTION__, ret);

    return ERROR;
}

static inline int16_t FnVCCB_SyncData_WithOutThread(char *pAddr, const int hasKey, const unsigned long size)
{
    int ret;

    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pAddr);

    if (DBG->flag.isSkipHasDirectSync)
    {
        return GOOD;
    }

    INCREASE_LOCAL_HAS_COMM_STAT(hasDirectSync_Att);

    if ((ret = hasDirectSync(hasKey, pAddr, size)) >= 0)
    {
        INCREASE_LOCAL_HAS_COMM_STAT(hasDirectSync_Succ);
        VCCB_STAT->localStat.hasComStat.syncedSize += size;

        return GOOD;
    }

    INCREASE_LOCAL_HAS_COMM_STAT(hasDirectSync_Fail);
    VCCB_PRINTF("%s: hasDirectSync Failed(%d)\n", __FUNCTION__, ret);

    return ERROR;
}

int16_t FnVCCB_SyncData(const uint8_t threadId, unsigned long unsynced, char *pAddr, const int hasKey)
{
    AUTO_TRACE_FUNC;

    if (hasKey <= VCCB_HAS_KEY_START || hasKey >= VCCB_HAS_KEY_END)
    {
        VCCB_PRINT_ERROR("%s: Invalid hasKey(%d)\n", __FUNCTION__, hasKey);
        return ERROR;
    }

    int16_t status = GOOD;
    unsigned long size = 0;

    while (unsynced > 0)
    {
        size = (unsynced > VCCB_MAX_CHUNK_SIZE) ? VCCB_MAX_CHUNK_SIZE : unsynced;

        if (threadId < MAX_CALL_THREAD_NUM_VCCB)
        {
            status = FnVCCB_SyncData_WithThread(threadId, pAddr, hasKey, size);
            VCCB_RETURN_ON_ERROR(status, "FnVCCB_SyncData_WithThread ERROR!\n");
        }
        else
        {
            status = FnVCCB_SyncData_WithOutThread(pAddr, hasKey, size);
            VCCB_RETURN_ON_ERROR(status, "FnVCCB_SyncData_WithOutThread ERROR!\n");
        }

        // If 'FnVCCB_SyncData_WithThread' and 'FnVCCB_SyncData_WithOutThread' succeed,
        // increase or decrease the internal variable.
        unsynced -= size;
        pAddr += size;
    }

    return GOOD;
}

int FnVCCB_GetHasKeyByCallId(const uint32_t callId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(callId, VCCB_MAX_CALL_COUNT_PER_CPC);

    int index;
    for (index = 0; index < VCCB_NUM_CALLINFO_CHUNKS; index++)
    {
        CallHasKeyInfo_type *pCallHasKeyInfo = &ENV->hasInfo.callHasKeyInfo[index];
        if (pCallHasKeyInfo->firstCallId <= callId && callId <= pCallHasKeyInfo->lastCallId)
        {
            return pCallHasKeyInfo->hasKey;
        }
    }

    return ERROR;
}

int16_t FnVCCB_BackupCallInfoPartial(callInfo_type *ptCi, void *addr, const unsigned long size)
{
#if defined(__NVGNB__) || defined(IPC_TEST) || defined(__CNF__)
    UNUSED3(ptCi, addr, size);
    return GOOD;
#else // defined(__VNF__)
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(addr);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    if (CFG->hasCpc.State == HAS_NOTINITIALIZED)
    {
        VCCB_PRINT_COMMENT("%s:HAS not initialized.\n", __FUNCTION__);
        return GOOD;
    }

    int hasKey = FnVCCB_GetHasKeyByCallId(ptCi->callId);
    if (hasKey < 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetHasKeyByCallId(%d) ERROR in %s\n", hasKey, __FUNCTION__);
        return ERROR;
    }

    if (ERROR == FnVCCB_SyncData(ptCi->myThreadId, size, (char*)addr, hasKey))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SyncData ERROR in %s\n", __FUNCTION__);
        return ERROR;
    }

    return GOOD;
#endif
}

/**
 *  @brief VCCB Sync Call Data
 *  @param ptCi
 *  @return GOOD, ERROR
 */

int16_t FnVCCB_BackupCallInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

#ifdef __CNF__

    if (ENV->isSupportHA == CNF_HA_SUPPORT)
    {
        enumBackupType_type backupType;  // 0 is SET, 1 is DEL

        if (ptCi->usage == CI_no_use)
        {
            backupType = BACKUP_TYPE_DEL;
        }
        else if (FnVCCB_IsCallToBackup(ptCi))
        {
            backupType = BACKUP_TYPE_SET;
            VLIB_AttachTimer(&ptCi->redisExpireUpdateTimer, ptCi, timInternalRedisExpireUpdate_id);
        }
        else
        {
            backupType = BACKUP_TYPE_UPDATE_STATE;
        }

        if (FnVCCB_EnqueueRedisCallQ(ptCi, backupType) != GOOD)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[%s][ExtDb] FnVCCB_EnqueueRedisCallQ ERROR !!\n", __FUNCTION__);
            return ERROR;
        }
    }
#else
    int ret;
    unsigned long forbiddenTASize;
    unsigned long unsynced, dynamicSize;

    int hasKey = FnVCCB_GetHasKeyByCallId(ptCi->callId);
    if (hasKey < 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetHasKeyByCallId ERROR(%d) in %s\n", hasKey, __FUNCTION__);
        return ERROR;
    }
    // **** STEP 1. RANGE - 'usage' ~ 'hoRestrict' **** //
    // fixed : 'usage' ~ 'hoRestrict.encoded'
    ptCi->backupSeqNum_First++;
    unsynced = (char *)(&ptCi->hoRestrict.forbiddenTA) - (char *)ptCi;  // OPT2

    // variable : hoRestrict.forbiddenTA (union)
    if (E_CALLTYPE_SA == ptCi->callType)
    {
        forbiddenTASize = sizeof(forbidden5gTACompressed_type);
    }
    else
    {
        forbiddenTASize = sizeof(forbiddenTACompressed_type);
    }
    dynamicSize = UMIN(ptCi->hoRestrict.numForbidTaPlmn, X2_maxnoofEPLMNsPlusOne) * forbiddenTASize;
    unsynced += dynamicSize;

    ret = FnVCCB_SyncData(ptCi->myThreadId, unsynced, (char *)ptCi, hasKey);
    if (ERROR == ret)
    {
        VCCB_PRINT_CALL_CRITICAL(ptCi, "%s: STEP1 : hasDirectSync Failed(%d)\n", __FUNCTION__, ret);
    }
    // - STEP1 END -

    // **** STEP 2. RANGE - 'backupSeqNum_last' ~ 'locRpt' **** //
    // fixed : 'backupSeqNum_last' ~ 'locRpt.areaofInterest.aol[0]'
    ptCi->backupSeqNum_last = ptCi->backupSeqNum_First;
    unsynced = (char *)(&ptCi->locRpt.areaofInterest.aoI[0]) - (char *)(&ptCi->backupSeqNum_last);

    // variable : locRpt.areaofInterest.noofAoI (union)
    dynamicSize = (UMIN(ptCi->locRpt.areaofInterest.noofAoI, NG_MaxnoofAoI) * sizeof(locRptAoIItem_type));
    unsynced += dynamicSize;
    ret = FnVCCB_SyncData(ptCi->myThreadId, unsynced, (char *)(&ptCi->backupSeqNum_last), hasKey);
    if (ERROR == ret)
    {
        VCCB_PRINT_CALL_CRITICAL(ptCi, "%s STEP2 hoRestrict : hasDirectSync Failed(%d)\n", __FUNCTION__, ret);
    }
    // - STEP2 END -

#endif
    return GOOD;
}

int FnVCCB_GetHasKeyByCellNum(const uint32_t cellNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    int index;
    for (index = 0; index < VCCB_NUM_CELLINFO_CHUNKS; index++)
    {
        CellHasKeyInfo_type *pCellHasKeyInfo = &ENV->hasInfo.cellHasKeyInfo[index];
        if (cellNum >= pCellHasKeyInfo->firstCellNum  && cellNum <= pCellHasKeyInfo->lastCellNum)
        {
            return pCellHasKeyInfo->hasKey;
        }
    }

    return ERROR;
}

void FnVCCB_BackupCellInfoPartial(uint16_t cellNum, void *addr, const unsigned long size)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    if (e_VCCB_ACPF_VNF != VCOM_getSystemType()) return;

    int ret;
    int hasKey = FnVCCB_GetHasKeyByCellNum(cellNum);
    if (hasKey < 0)
    {
        VCCB_PRINT_ERROR("FnVCCB_BackupCellInfoPartial ERROR(%d) in %s\n", hasKey, __FUNCTION__);
        return;
    }

    ret = FnVCCB_SyncData(UNKNOWN_CALL_THREAD_ID, size, (char *)addr, hasKey);
    if (ERROR == ret)
    {
        VCCB_PRINT_CRITICAL("%s: hasDirectSync Failed(%d)\n", __FUNCTION__, ret);
    }

    return;
}

/**
 *  @brief VCCB Sync Cell Data, use for bigger struct than VCCB_MAX_CHUNK_SIZE
 *  @param cellNum
 *  @return GOOD, ERROR
 */
void FnVCCB_BackupCellInfo(uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

#if defined(__CNF__)
    FnVCCB_RedisUpdateCellInfoFlagOn(cellNum);
#elif defined(__VNF__)
    unsigned long unsynced;
    int ret;
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    unsynced = sizeof(VccbCellInfo_type) - (sizeof(pCell->Nbr) + sizeof(pCell->eutraNbr));

    int hasKey = FnVCCB_GetHasKeyByCellNum(cellNum);
    if (hasKey < 0)
    {
        VCCB_PRINT_ERROR("FnVCCB_BackupCellInfo ERROR(%d) in %s\n", hasKey, __FUNCTION__);
        return;
    }

    ret = FnVCCB_SyncData(UNKNOWN_CALL_THREAD_ID, unsynced, (char *)pCell, hasKey);

    if (ERROR == ret)
    {
        VCCB_PRINT_CRITICAL("%s: hasDirectSync Failed(%d)\n", __FUNCTION__, ret);
    }

#endif
    return;
}

/**
 *  @brief VCCB Sync CellNbr Data
 *  @param gnbNum
 *  @return GOOD, ERROR
 */
void FnVCCB_BackupCellNbrInfo(uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

#if defined(__CNF__)
    FnVCCB_RedisUpdateCellInfoFlagOn(cellNum);
#elif defined(__VNF__)
    unsigned long unsynced;
    int ret;

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    nbrCellInfo_type *ptNbrCell = pCell->Nbr;

    unsynced = sizeof(*ptNbrCell);

    int hasKey = FnVCCB_GetHasKeyByCellNum(cellNum);
    if (hasKey < 0)
    {
        VCCB_PRINT_ERROR("FnVCCB_BackupCellNbrInfo ERROR(%d) in %s\n", hasKey, __FUNCTION__);
        return;
    }

    ret = FnVCCB_SyncData(UNKNOWN_CALL_THREAD_ID, unsynced, (char *)ptNbrCell, hasKey);

    if (ERROR == ret)
    {
        VCCB_PRINT_CRITICAL("%s: hasDirectSync Failed(%d)\n", __FUNCTION__, ret);
    }

#endif
    return;
}

/**
 *  @brief VCCB Sync CellEutraNbr Data,
 *  @param gnbNum
 *  @return GOOD, ERROR
 */
void FnVCCB_BackupCellEutraNbrInfo(uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

#if defined(__CNF__)
    FnVCCB_RedisUpdateCellInfoFlagOn(cellNum);
#elif defined(__VNF__)
    unsigned long unsynced;
    int ret;

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    nbrEutraCellInfo_type *ptEutraNbrCell = pCell->eutraNbr;

    unsynced = sizeof(*ptEutraNbrCell);

    int hasKey = FnVCCB_GetHasKeyByCellNum(cellNum);
    if (hasKey < 0)
    {
        VCCB_PRINT_ERROR("FnVCCB_BackupCellEutraNbrInfo ERROR(%d) in %s\n", hasKey, __FUNCTION__);
        return;
    }

    ret = FnVCCB_SyncData(UNKNOWN_CALL_THREAD_ID, unsynced, (char *)ptEutraNbrCell, hasKey);

    if (ERROR == ret)
    {
        VCCB_PRINT_CRITICAL("%s: hasDirectSync Failed(%d)\n", __FUNCTION__, ret);
    }

#endif
    return;
}

#ifdef __CNF__
/**
 *  @brief To update the data backed up in the Redis DB, turn on the RedisUpdateFlag.
 */
void FnVCCB_RedisUpdateGnbInfoFlagOn(uint16_t gnbNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);

    VccbEnvInfo_type *pEnv = ENV;
    if (pEnv->isSupportHA == CNF_HA_SUPPORT)
    {
        if (pEnv->redis.redisUpdateFlag.gnb[gnbNum] != TRUE)
        {
            MUTEX_LOCK(&pEnv->redis.redisUpdateFlag.gnb_update[gnbNum]);
            pEnv->redis.redisUpdateFlag.gnb[gnbNum] = TRUE;
            MUTEX_UNLOCK(&pEnv->redis.redisUpdateFlag.gnb_update[gnbNum]);
            VCCB_PRINT_COMMENT("[%s][ExtDb] redisUpdateFlag.gnb[%d] Set TRUE\n", __func__, gnbNum);
        }
    }

    return;
}

void FnVCCB_RedisUpdateGnbNumInfoFlagOn(void)
{
    AUTO_TRACE_FUNC;

    VccbEnvInfo_type *pEnv = ENV;
    if (pEnv->isSupportHA == CNF_HA_SUPPORT)
    {
        MUTEX_LOCK(&pEnv->redis.redisUpdateFlag.cfg.gnbNumInfo_update);
        pEnv->redis.redisUpdateFlag.cfg.gnbNumInfo = TRUE;
        MUTEX_UNLOCK(&pEnv->redis.redisUpdateFlag.cfg.gnbNumInfo_update);
        VCCB_PRINT_COMMENT("[%s][ExtDb] redisUpdateFlag.cfg.gnbNumInfo Set TRUE\n", __func__);
    }

    return;
}

void FnVCCB_RedisUpdateCellInfoFlagOn(uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    VccbEnvInfo_type *pEnv = ENV;
    if (pEnv->isSupportHA == CNF_HA_SUPPORT)
    {
        MUTEX_LOCK(&pEnv->redis.redisUpdateFlag.cell_update[cellNum]);
        pEnv->redis.redisUpdateFlag.cell[cellNum] = TRUE;
        MUTEX_UNLOCK(&pEnv->redis.redisUpdateFlag.cell_update[cellNum]);
        VCCB_PRINT_COMMENT("[%s][ExtDb] redisUpdateFlag.cell[%d] Set TRUE\n", __func__, cellNum);
    }

    return;
}
#endif

void FnVCCB_InitGnbRrcSaTimerProfile(int gnbNum, int profileIndex)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(profileIndex, MAX_RRC_SA_TIMER_PROFILE_PER_GNB);

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    RrcSaTimerProfile_type *pRrcSaTimerProfile = &pGnb->rrcSaTimerProfile[profileIndex];
    pRrcSaTimerProfile->usage = CI_no_use;
    pRrcSaTimerProfile->profileName[0] = '\0';
    pRrcSaTimerProfile->rrcSetup = 1000;
    pRrcSaTimerProfile->rrcReestablish = 2000;
    pRrcSaTimerProfile->rrcReconfig = 3000;
    pRrcSaTimerProfile->rrcResume = 3000;
    pRrcSaTimerProfile->rrcSecurityModeCommand = 2000;
    pRrcSaTimerProfile->rrcUeCapabilityEnquiry = 2000;
    pRrcSaTimerProfile->rrcUlInformationTransferTimeToWait = 2000;
    pRrcSaTimerProfile->f1RrcDeliveryReportTimeToWait = 1500;

    return;
}

void FnVCCB_InitGnbRrcEndcTimerProfile(int gnbNum, int profileIndex)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(profileIndex, MAX_RRC_ENDC_TIMER_PROFILE_PER_GNB);

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    RrcEndcTimerProfile_type *pRrcEndcTimerProfile = &pGnb->rrcEndcTimerProfile[profileIndex];
    pRrcEndcTimerProfile->usage = CI_no_use;
    pRrcEndcTimerProfile->rrcReconfig = 1000;

    return;
}

void FnVCCB_InitNrdcRfspBasedUlPathSwitchCtrl(NrdcCellInfo_type *pNrdcCellInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pNrdcCellInfo);

    pNrdcCellInfo->rfspBasedEntriesCount = 0;

    uint8_t rfspIndex = 0;
    for (rfspIndex = 0; rfspIndex < MAX_RFSP_INDEX_TIMES_TWO; rfspIndex++)
    {
        pNrdcCellInfo->rfspBasedEntries[rfspIndex].usage = CI_no_use;
        pNrdcCellInfo->rfspBasedEntries[rfspIndex].rfsp = NO_RFSP_VALUE;
        pNrdcCellInfo->rfspBasedEntries[rfspIndex].ulPrimaryPathSwitch = access_s5gtype_disabled;
    }
}

void VCCB_InitMeasObjectBlacklistCells_PerPlmn(measurementObjectBlacklistCells_PlmnSupportEntry_type &plmnSupportEntry)
{
    plmnSupportEntry.usage = CI_no_use;
    plmnSupportEntry.spidRefs.spidDefaultEndcIdx = UNKNOWN_IDX_IN_ENDC_BLACKLIST_CELLS_SETS;
    plmnSupportEntry.rfspRefs.rfspDefaultSaIdx = UNKNOWN_IDX_IN_SA_BLACKLIST_CELLS_SETS;

    unsigned spidLoop = 0;
    for (spidLoop = 0; spidLoop < VCCB_ARRAY_COUNT(plmnSupportEntry.spidRefs.spidEndcIdx); spidLoop++)
    {
        plmnSupportEntry.spidRefs.spidEndcIdx[spidLoop] = UNKNOWN_IDX_IN_ENDC_BLACKLIST_CELLS_SETS;
    }

    unsigned rfspLoop = 0;
    for (rfspLoop = 0; rfspLoop < VCCB_ARRAY_COUNT(plmnSupportEntry.rfspRefs.rfspSaIdx); rfspLoop++)
    {
        plmnSupportEntry.rfspRefs.rfspSaIdx[rfspLoop] = UNKNOWN_IDX_IN_SA_BLACKLIST_CELLS_SETS;
    }
}

void VCCB_InitMeasObjectBlacklistCells(VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pCell);

    measurementObjectBlacklistCells_type *pMoBlacklistCells = &pCell->measurementsData.measObjectBlacklistCells;
    memset(pMoBlacklistCells, 0x00, sizeof(*pMoBlacklistCells));

    pMoBlacklistCells->refs.defaultEndcIdx = UNKNOWN_IDX_IN_ENDC_BLACKLIST_CELLS_SETS;
    pMoBlacklistCells->refs.defaultSaIdx = UNKNOWN_IDX_IN_SA_BLACKLIST_CELLS_SETS;

    unsigned plmnLoop = 0;
    for (plmnLoop = 0; plmnLoop < VCCB_ARRAY_COUNT(pMoBlacklistCells->refs.plmnSupportEntries); plmnLoop++)
    {
        VCCB_InitMeasObjectBlacklistCells_PerPlmn(pMoBlacklistCells->refs.plmnSupportEntries[plmnLoop]);
    }

    unsigned serviceGroupIdLoop = 0;
    for (serviceGroupIdLoop = 0;
         serviceGroupIdLoop < VCCB_ARRAY_COUNT(pMoBlacklistCells->refs.serviceGroupConfig.entries);
         serviceGroupIdLoop++)
    {
        measurementObjectBlacklistCells_ServiceGroupRefs_Entry_type *pEntry =
            &pMoBlacklistCells->refs.serviceGroupConfig.entries[serviceGroupIdLoop];
        pEntry->priority = 0;
        pEntry->usage = CI_no_use;
        pEntry->saIdx = UNKNOWN_IDX_IN_SA_BLACKLIST_CELLS_SETS;
    }
}

void VCCB_InitYangCbrsInfo(cbrsInfo_type *pCbrsInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pCbrsInfo);

    pCbrsInfo->cbrsCarrierUpdateEnabled = FALSE;
    pCbrsInfo->cbrsCarrierInfoUpdateMode = CbrsCarrierInfoUpdateMode_gnbCellInfoBased;
}

/* Init NR Measurement Frequency Auto Config */
void FnVCCB_InitFreqAutoConfig(VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pCell);

    int loop = 0;

    for (loop = 0; MAX_MEAS_OBJECT_ENTRIES > loop; ++loop)
    {
        pCell->facMeasResult[loop].ssbFreq = UNKNOWN_ARFCN;
        pCell->facMeasResult[loop].measConfigCount = 0;
        pCell->facMeasResult[loop].mrCount = 0;
    }
}

void FnVCCB_InitCellInfo(void)
{
    AUTO_TRACE_FUNC;

    int32_t loop;

    auto initUpmInfo = [](upmCellInfo_type *pUpmInfo)
    {
        memset(pUpmInfo, 0x00, sizeof(upmCellInfo_type));

        // Default Value Setting
        pUpmInfo->upmSwitch = FALSE;
        pUpmInfo->hoTimeWindow = 80;  // 8s * 10
        pUpmInfo->hoTimer = 20.0f;    // 2s * 10
        pUpmInfo->hoCount = 2;
        pUpmInfo->maxCioReduction = 6;
        pUpmInfo->cioInitialOffset = 1;
        pUpmInfo->cioWeight = 1;
    };

    for (loop = 0; loop < MAX_CELL_NUM_VCCB; loop++)
    {
        VccbCellInfo_type *const pCell = &CELLINFO[loop];

        pCell->status = N_EQUIP;
        pCell->gnbNum = MAX_GNB_PER_SYS;
        pCell->gnbId = 0xFFFFFFFF;  // init
        pCell->nrLbmConfigurationIndex = NR_LBM_DISABLE;

        /* Init cell parameters get from user PLD */
        FnVCCB_InitPldCellStatusParam(pCell);
        FnVCCB_InitPldNrCellPlmnInfo(pCell);

        /*Cell state*/
        pCell->ulPathCongestionBased.congestionState = NORMAL_STATE;
        pCell->ulPathCongestionBased.congestionStateSliceLoad = NORMAL_STATE;

        /* Init UPM */
        {
            initUpmInfo(&pCell->upmInfo);
            initUpmInfo(&pCell->psCellUpmInfo);
        }

        pCell->cellRfspBasedCtrl.rfspBasedCellReselectUsage = VCCB_FLAG_OFF;

        pCell->cuColocCellInfo.colocCellInfoUsage = CI_no_use;
        for (colocCellEntries_type &rColocCell : pCell->cuColocCellInfo.colocCellEntries)
        {
            rColocCell.usage = CI_no_use;
            rColocCell.auditDbColocCellStatus = CaColocCellStatus_Unknown;
            rColocCell.callCurrColocCellStatus = CaColocCellStatus_Unknown;
        }
        for (omFailedCellInfo_type &rOMFailedCell : pCell->omFailedCells)
        {
            rOMFailedCell.usage = CI_no_use;
        }

        /*Init Cell Resource Information*/
        FnVCCB_InitCellRscInfo(&pCell->cellRscInfo);
        FnVCCB_InitCellCacInfo(&pCell->cellCacInfo);  // SVR23B FGR-L0706 NR Resource Status Reporting

        /*Init OnDemand HO DB */  // ODF_HO_21B
        FnVCCB_InitOnDemandMobilityControlOnCell(pCell);
        onDemandLoadDistInfo_type *pCtrl = &ENV->onDemandLoadDistCtrl;
        INIT_CELL_TIME_FOR_ODF(pCtrl, loop);

        /*Init Nrdc Param*/
        pCell->mobilityConfig.nrdcMobilityOption = MrdcMobilityYang_SnRelease;
        pCell->mobilityConfig.nrToEndcHoSupport = false;
        pCell->mobilityConfig.endcPscellSelectionThreshold.thresholdRsrp = NOT_CONFIGURED;
        pCell->mobilityConfig.endcPscellSelectionThreshold.thresholdRsrq = NOT_CONFIGURED;

        pCell->mobilityConfig.intraNrInterFreqHandoverFollowA2 = false;
        pCell->mobilityConfig.eutraHandoverFollowA2 = false;
        pCell->mobilityConfig.followA2WithMultipleTriggerQuantitySupportNr = FALSE;
        pCell->mobilityConfig.followA2WithMultipleTriggerQuantitySupportEutra = FALSE;
        pCell->mobilityConfig.multipleA1WithFollowA2Support = FALSE; // SVR25B FGR-MC1007 FR35

        pCell->mobilityConfig.ueBasedCgiReportingForEndcPscellChange = VCCB_FLAG_OFF;

        /* Init NRDC RFSP based Ul Path Switch Information */
        FnVCCB_InitNrdcRfspBasedUlPathSwitchCtrl(&pCell->nrdcCellInfo);

        /* Init NRDC RFSP based operation mode */
        FnVCCB_InitNrdcRfspBasedOprMode(&pCell->nrdcCellInfo);

        /*Init Profile DB */
        memset(&pCell->profileDBInfo, 0x00, sizeof(pCell->profileDBInfo));
        /* UE Capability Handling for Cell */
        memset(&pCell->uceCellOptionInfo, 0x00, sizeof(pCell->uceCellOptionInfo));

        /*Init DlTrfStatusRptCfg */
        FnVCCB_InitDlTrfStatusRptCfg(pCell);
        FnVCCB_InitTrafficMonitoringCfgRfsp(pCell);

        memset(&pCell->measurementsData.specMeasConfig, 0x00, sizeof(pCell->measurementsData.specMeasConfig));
        VCCB_InitMeasObjectBlacklistCells(pCell);
        VCCB_InitYangCbrsInfo(&pCell->cbrsInfo);
        FnVCCB_InitFreqAutoConfig(pCell);

        memset(&pCell->lbCfg, 0, sizeof(pCell->lbCfg));
        pCell->lbCfg.idleModeInfo.legacyIdleLbSwitch = 1;

        /* Init internal stat EndcAddDetailedCpFail and EndcAddDetailedSpCellSelFail */
        memset(&pCell->statEndcAddDetailedCpFail, 0x00, sizeof(pCell->statEndcAddDetailedCpFail));
        memset(&pCell->statEndcAddDetailedSpCellSelFail, 0x00, sizeof(pCell->statEndcAddDetailedSpCellSelFail));
        time(&pCell->resetTimeStatEndcAddDetailedCpFail);
        time(&pCell->resetTimeStatEndcAddSpCellSelFail);

        pCell->isUlPathVipUeTimerRunning = FALSE;
        pCell->ulPathVipUeTimer.mutex = PTHREAD_MUTEX_INITIALIZER;
        pCell->mobilityConfig.supportFreqPriorityBasedIntraRatBlindRedirection = FALSE;
        pCell->pdcchConfig.minBlindDetectionScg = 4; // 4 is Minimum value (!)

        pCell->scgAdaptation.adaptationSwitch = FALSE;
        pCell->scgAdaptation.weightFactorNr = 1;
        pCell->scgAdaptation.weightFactorLte = 1;

        /* Init ForcedMobilityDueToUplinkStatusIndication */
        pCell->mobilityConfig.forcedMobilityDueToUplinkStatusIndication.loadBasedTargetSelection.usage = FALSE;
        pCell->mobilityConfig.forcedMobilityDueToUplinkStatusIndication.loadBasedTargetSelection.dlCapacityThreshold = 30;
        pCell->mobilityConfig.forcedMobilityDueToUplinkStatusIndication.loadBasedTargetSelection.ulCapacityThreshold = 30;

        // Initialize Cell Trace Recording Session Reference indexes
        for (uint16_t idx = 0; idx < MAX_UE_PER_CELL_TRACE_SESSION; ++idx)
        {
            pCell->traceSession.cellTRSR[idx] = UNKNOWN_VCCB_CALLID;
        }

        pCell->traceSession.trace.tce1Id = std::numeric_limits<uint8_t>::max();
        pCell->traceSession.trace.tce2Id = std::numeric_limits<uint8_t>::max();
        pCell->traceSession.mdt.mdtSessionConfiguration.tceId = std::numeric_limits<uint8_t>::max();
        pCell->signalingMdtUeCounters.immediateMdtUeCountCpc = 0;
        pCell->signalingMdtUeCounters.loggedMdtUeCountCpc = 0;

        pCell->allowVonrWithRfspPerCell = VCCB_FLAG_OFF;

        pCell->supportRedCapDedicatedMeasurement = 0;

        // FGR-MC1015 SVR25A FR100
        pCell->mobilityConfig.plmnBasedDedicatedPrioritySupport = FALSE;
        for (uint8_t plmnIdx = 0; plmnIdx < MAX_PLMN_INDEX; plmnIdx++)
        {
            plmnBasedDedicatedPriority_type *pPlmnPriority = &pCell->plmnBasedDedicatedPriority[plmnIdx];
            pPlmnPriority->usage = CI_no_use;
            for (uint8_t freqListIdx = 0; freqListIdx < MAX_NUM_PLMN_BASED_FREQS; freqListIdx++)
            {
                pPlmnPriority->nrFreqItems[freqListIdx].usage = CI_no_use;
                pPlmnPriority->eutraFreqItems[freqListIdx].usage = CI_no_use;
            }
        }
        // TODO: [LTM] Need to check this code, when YANG is added.(FR40)
        pCell->mobilityConfig.ltmAllowance = VCCB_FLAG_OFF;
        pCell->fpMobilityControl.cellLoadBasedTargetCellSelectionSupport = FALSE;
        pCell->mobilityConfig.handoverPrepFailedTimer = DEFAULT_HO_PREP_FAILED_TIMER; 

        memset(&pCell->lbCfg.lbmConfiguration.lbmConnModeLbInfo, 0xFF, sizeof(pCell->lbCfg.lbmConfiguration.lbmConnModeLbInfo));

        memset(&pCell->vonrControlInfo, 0x00, sizeof(pCell->vonrControlInfo));  // SVR26A FGR-SV0201

#ifdef NEW_HOST_SIM
        pCell->mockTrafficSteeringConfig.enabled = false;
        pCell->mockTrafficSteeringConfig.min = 1.0;
        pCell->mockTrafficSteeringConfig.max = 1.0;
        pCell->mockTrafficSteeringConfig.variableA = 1.0;
        pCell->mockTrafficSteeringConfig.variableB = 1.0;
        pCell->mockTrafficSteeringConfig.variableC = 1.0;
        pCell->mockTrafficSteeringConfig.variableD = 1.0;
#endif
    }

    int result = 0;
    uint16_t cellNum = 0;
    /* Init EQUIP Cell */
    for (cellNum = 0; cellNum < MAX_CELL_NUM_VCCB; cellNum++)
    {
        /* Init Each Cell */
        uint16_t errCause = 0;
        result = VRRM_initEachCell(cellNum, &errCause);
        if (result != GOOD)
        {
            VRRM_PRINT(VRRM_ERROR, "[%s   %d] VRRM_initEachCell Error(%d)\n", __FILE__, __LINE__, result);
            continue;
        }
    }
}

/**
 * @brief   This function initializes the values of allowedCaConfig for NSA and SA
 * @param   void
 * @return  void
 */
void FnVCCB_InitAllowedCaConfig(void)
{
    AUTO_TRACE_FUNC;

    // supported CA configurations are defined in FGR-RC0100 FR116,FR118
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD]
                           [BandDependencyCa_INTRA] = VCCB_SUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD]
                           [BandDependencyCa_INTER] = VCCB_SUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD]
                           [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD]
                           [BandDependencyCa_INTER] = VCCB_SUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD]
                           [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD]
                           [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD]
                           [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD]
                           [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD]
                           [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD]
                           [BandDependencyCa_INTER] = VCCB_SUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD]
                           [BandDependencyCa_INTRA] = VCCB_SUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD]
                           [BandDependencyCa_INTER] = VCCB_SUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD]
                           [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD]
                           [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD]
                           [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD]
                           [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD]
                           [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD]
                           [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD]
                           [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD]
                           [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD]
                           [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD]
                           [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD]
                           [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD]
                           [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD]
                           [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD]
                           [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD]
                           [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD]
                           [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD]
                           [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD]
                           [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD]
                           [BandDependencyCa_INTRA] = VCCB_SUPPORTED;
    CFG->allowedCaConfigNSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD]
                           [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;

    CFG->allowedCaConfigSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD]
                          [BandDependencyCa_INTRA] = VCCB_SUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD]
                          [BandDependencyCa_INTER] = VCCB_SUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD]
                          [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD]
                          [BandDependencyCa_INTER] = VCCB_SUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD]
                          [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD]
                          [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD]
                          [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD]
                          [BandDependencyCa_INTER] = VCCB_SUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD]
                          [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD]
                          [BandDependencyCa_INTER] = VCCB_SUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD]
                          [BandDependencyCa_INTRA] = VCCB_SUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD]
                          [BandDependencyCa_INTER] = VCCB_SUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD]
                          [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD]
                          [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD]
                          [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD]
                          [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD]
                          [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD]
                          [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD]
                          [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD]
                          [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD]
                          [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD]
                          [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD]
                          [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD]
                          [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD]
                          [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_FDD]
                          [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD]
                          [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR1][ci_DUPLEXTYPE_TDD]
                          [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD]
                          [BandDependencyCa_INTRA] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_FDD]
                          [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD]
                          [BandDependencyCa_INTRA] = VCCB_SUPPORTED;
    CFG->allowedCaConfigSA[FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD][FrequencyRangeCa_FR2][ci_DUPLEXTYPE_TDD]
                          [BandDependencyCa_INTER] = VCCB_UNSUPPORTED;
}

void FnVCCB_SetInitTimer(const uint32_t msgId, const int timeValue)
{
    const uint32_t msgBase = MSGBASE_TIMER;

    // Check for overflow condition
    if ((msgBase > msgId) || (msgId - msgBase) >= std::numeric_limits<uint32_t>::max())
    {
        return;
    }

    const uint32_t timer_key = static_cast<uint32_t>(msgId - msgBase);

    if (timer_key < MAX_VCCB_TIMER)  // Valid Case
    {
        CFG->timer.value[timer_key] = timeValue;
    }
}

void FnVCCB_InitTimerValue()
{
    // This function defines a timer that cannot be controlled by Yang.

    // for Internal call stat
    FnVCCB_SetInitTimer(timInternalCallStatistics_id, 1000);  // 1 sec

    // for KeepAlive timer
    FnVCCB_SetInitTimer(timKeepAliveReq_id, 2000);

    // for forced call release
    FnVCCB_SetInitTimer(timInternalCallForcedRelease_id, 11000);  // 11sec

    // SLR410_A152 : NWSYS01434533 timer
    // FnVCCB_SetInitTimer(timAdvancedCaLb_id, 2000);

    FnVCCB_SetInitTimer(timAnrMrCountPeriodicNoti_id, 600000);  // 10min
    FnVCCB_SetInitTimer(timAnrMrCountNoti_id, 100);             // 100ms
    FnVCCB_SetInitTimer(timAnrReportCgi_t321Fr1_id, 3000);      // 2sec + 1sec(margin)
    FnVCCB_SetInitTimer(timAnrReportCgi_t321Fr2_id, 17000);     // 16sec + 1sec(margin)

    FnVCCB_SetInitTimer(timIRatAnrReportCgi_t321_id, 2000);  // 1sec + 1sec(margin)

    FnVCCB_SetInitTimer(timInternalRetrieveUeContextResult_id, 200);
    FnVCCB_SetInitTimer(timInternalInterGnbSnStatusTransfer_id, 1000);

    FnVCCB_SetInitTimer(timInternalULNasTimeToWait_id, 2000);

    // for Internal Audit in OAM thread (e.g., HAS)
    FnVCCB_SetInitTimer(timInternalOamAudit_id, 30 * 1000);  // 30 sec
    // for Internal Audit in PLD thread
    FnVCCB_SetInitTimer(timInternalPldAudit_id, 60 * 1000);  // 60 sec

    FnVCCB_SetInitTimer(timInternalCaModTrigger_id, 1000);  // 1sec
    FnVCCB_SetInitTimer(timInternalUeMeasForSon_id, 2000);
    FnVCCB_SetInitTimer(timInternalMeasReconfigDelay_id, 3000);

    FnVCCB_SetInitTimer(timInternalTrfBasedHoMeas_id, 10000);  // 10000ms

    FnVCCB_SetInitTimer(timX2_BcInformationResponse_id, 3000);  // 3sec

    FnVCCB_SetInitTimer(timInternalMcoSlbOperationCountResetTimer_id, 10000); // 10 sec, FGR-CC5500 FR12

#ifndef NEW_HOST_SIM
    FnVCCB_SetInitTimer(timX2_SnStatusTransfer_id, 1000);
#else
    FnVCCB_SetInitTimer(timX2_SnStatusTransfer_id, 5000);
#endif
    FnVCCB_SetInitTimer(timPeerInfoRspVnlb_id, 1000);
    FnVCCB_SetInitTimer(timPeerInfoRspVnmb_id, 1000);

#ifndef NEW_HOST_SIM
    FnVCCB_SetInitTimer(timInternalStatisticsItemCollect_id, 2000); // 2 sec
    FnVCCB_SetInitTimer(timInternalStatisticsItemUpdate_id, 2000); 
#else
    FnVCCB_SetInitTimer(timInternalStatisticsItemCollect_id, 500); // 0.5 sec
    FnVCCB_SetInitTimer(timInternalStatisticsItemUpdate_id, 500);
#endif
    FnVCCB_SetInitTimer(timInternalAuditStbGnbNumInfo_id, 1000);  // 1 sec
    FnVCCB_SetInitTimer(timInternalPLDCpuUtilRead_id, 10000);       // 10 sec

    // SVR26A FGR-CC3103 IODT RACS
#ifndef NEW_HOST_SIM    
    FnVCCB_SetInitTimer(timInternalPeriodicUeCapaQueryToVnmb_id, 1000);             // 1 sec
    FnVCCB_SetInitTimer(timInternalPeriodicUeCapaAuditReqToVnmb_id, (60*60*1000));  // 1 hour (3,600,000 ms)
#else
    FnVCCB_SetInitTimer(timInternalPeriodicUeCapaQueryToVnmb_id, 1000);             // 1 sec
    FnVCCB_SetInitTimer(timInternalPeriodicUeCapaAuditReqToVnmb_id, (10*1000));     // 10 sec
#endif
}


void FnVCCB_InitCellRscInfo(sonCellPrbRsc_type *pCellRscInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pCellRscInfo);

    uint16_t nbrIdx;

    memset(pCellRscInfo, 0x00, sizeof(sonCellPrbRsc_type));

    pCellRscInfo->dlCapacityValue = 100;
    pCellRscInfo->ulCapacityValue = 100;
    pCellRscInfo->numAvailUe = 100;

    // SVR23B FGR-L0706 NR Resource Status Reporting
    pCellRscInfo->ulCceFailRate = NOT_UPDATED;
    pCellRscInfo->dlCceUsage    = NOT_UPDATED;
    pCellRscInfo->ulCceUsage    = NOT_UPDATED;
    for(nbrIdx = 0; nbrIdx < MAX_NBR_RELATION_TABLE_PER_CELL; nbrIdx++)
    {  
        pCellRscInfo->nbrPrb[nbrIdx].ulCceFailRate = NOT_UPDATED;
        pCellRscInfo->nbrPrb[nbrIdx].dlCceUsage    = NOT_UPDATED;
        pCellRscInfo->nbrPrb[nbrIdx].ulCceUsage    = NOT_UPDATED;
    }

    // SVR25B
    pCellRscInfo->dlCapacityValueRedcap = NOT_UPDATED;
    pCellRscInfo->ulCapacityValueRedcap = NOT_UPDATED;
    pCellRscInfo->ulCceFailRateRedcap = NOT_UPDATED;
    pCellRscInfo->dlCceUsageRedcap = NOT_UPDATED;
    pCellRscInfo->ulCceUsageRedcap = NOT_UPDATED;
}

// SVR23B FGR-L0706 NR Resource Status Reporting
void FnVCCB_InitCellCacInfo(sonCellSliceCac_type *pCellCacInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pCellCacInfo);

    uint16_t loop;

    memset(pCellCacInfo, 0x00, sizeof(sonCellSliceCac_type));

    for(loop = 0; loop < MAX_ACTIVE_SLICE_NUM; loop++)
    {
        pCellCacInfo->sliceCac[loop].dlSliceCapacity = -1;
        pCellCacInfo->sliceCac[loop].ulSliceCapacity = -1;
    }
}

/****************************************************************************
 * @brief       Classify call fault cause (NORMAL/SEMINORMAL/ABNORMAL/UNKNOWN)

 * @param[in]   callFaultCause :    Call fault cause / uint16_t
 * @return      NORMAL_CRR :        Normal cause / int16_t
 * @return      SEMINORMAL_CRR :    Seminormal cause / int16_t
 * @return      ABNORMAL_CRR :      Fault cause / int16_t
 * @return      UNKNOWN_CRR :       Cause not found / int16_t
 ****************************************************************************/
int16_t VIIL_CrrClassification(uint16_t callFaultCause)
{
    AUTO_TRACE_FUNC;

    int16_t status = UNKNOWN_CRR;

    auto CrrCategory = getCrrCategoryValue(callFaultCause);
    if (CrrCategory.has_value())
    {
        status = CrrCategory.value();
    }

    return status;
}

// SVR26A FGR-SV0401 gNB Service Outage Handling
int16_t FnVCCB_GetExcludeCrrListForCallDropRatioHigh(uint16_t callFaultCause)
{
    for(int idx = 0; idx < MIN(CFG->acpfInfo.callDropRatioHighAlarm.excludedCrrCount, MAX_EXCLUDED_CRR_LIST); idx++)
    {
        if( callFaultCause == CFG->acpfInfo.callDropRatioHighAlarm.excludedCRRList[idx] )
            return NORMAL_CRR;
    }
    return UNKNOWN_CRR;
}

int16_t FnVCCB_CheckAbnormalCallReleaseForCallDropRatioHigh(uint16_t callFaultCause)
{
    // NORMAL CALL when callFaultCause is not internal cause
    if(callFaultCause < CAUSE_BASE_CUCP_INTERNAL || callFaultCause > CauseCpInternalEnd) 
        return GOOD;

    // ABNORMAL CALL when CRR Classification is ABNORMAL CRR and not in exluded-crr-list
    if (VIIL_CrrClassification(callFaultCause) == ABNORMAL_CRR &&   
        FnVCCB_GetExcludeCrrListForCallDropRatioHigh(callFaultCause) == UNKNOWN_CRR) 
        return ERROR;

    return GOOD;
}


/**
 * @brief     Generic function to stat SN Addition
 * @param     ptCi : callInfo
 * @param     type : stat type
 * @param     fnName : caller function name
 */

void VHCM_StateTriggerEventForSNAddition(callInfo_type *ptCi,
    int type,  // need to add it as enum
    const char *fnName)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);

    if (IS_NRDC(ptCi) == FALSE)
    {
        return;
    }

    switch (type)
    {
        case MRDC_SnAdd_Att:
            ON_SN_ADDITION_PREPARATION_FLAG(ptCi->flag.setupFlag);
            break;

        case MRDC_SnAdd_PrepSucc:
            OFF_SN_ADDITION_PREPARATION_FLAG(ptCi->flag.setupFlag);
            break;

        default:
            break;
    }
}  // }}}

int16_t FnVCCB_GetCellNumFromCellId(uint16_t gnbNum, uint16_t cellIdentity, uint16_t *pCellNum)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_VALID_GNBNUM_ERROR(gnbNum);
    VALID_E_POINT_CHECK_ERROR(pCellNum);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    VCCB_CHECK_E_RANGE_AND_RETURN(cellIdentity, MAX_CELL_IDENTITY);
    uint16_t cellNum = pGnb->env.cellNum[cellIdentity];

    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);

    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    // Abnormal Case
    if (EQUIP != pCell->status && EQUIP != pCell->pldState)
    {
        VCCB_PRINT_ERROR("CELLINFO[%d] is N_EQUIP!(cellIdentity:%d yang:%d pld:%d)\n", cellNum, cellIdentity,
            pCell->status, pCell->pldState);
        return ERROR;
    }

    *pCellNum = cellNum;

    return GOOD;
}

int16_t VCCM_GetCellNumFromNrCgi(uint16_t gnbNum, cgi_type *pNRCGI, uint16_t *pCellNum, bool logOpt)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pNRCGI);
    VALID_E_POINT_CHECK_ERROR(pCellNum);
    VCCB_CHECK_VALID_GNBNUM_ERROR(gnbNum);

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    if (FALSE == VCOM_CheckPlmnIdentical(&pGnb->globalGnbId.plmn, &pNRCGI->plmn))
    {
        // Invalid Plmn Id(Reject)
        if (logOpt)
        {
            VCCB_PRINT_ERROR("Invalid Plmn Id(gNB(%d):%x NR-CGI:%x) in %s\n", gnbNum, pGnb->globalGnbId.plmn.longId,
                pNRCGI->plmn.longId, __func__);
        }
        return ERROR;
    }

    uint16_t cellIdentity = VLIB_NrCellId2CellId(pGnb->globalGnbId.gnbId.idLength, pNRCGI->ci);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellIdentity, MAX_CELL_IDENTITY);

    int16_t status = FnVCCB_GetCellNumFromCellId(gnbNum, cellIdentity, pCellNum);
    return status;
}

uint16_t FnVCCB_GetCellNumFromNbrInfo(const nbrCellInfo_type &rNbrCellInfo)
{
    AUTO_TRACE_FUNC;

    uint16_t cellNum = MAX_CELL_NUM_VCCB;
    vccbGlobalGnbId_type targetGnbId = rNbrCellInfo.targetGnbId;
    uint16_t targetCellId = rNbrCellInfo.targetCellId;

    auto compareGnbGlobalId = [targetGnbId](VccbGnbInfo_type *const pGnb) -> bool
    {
        if (pGnb->globalGnbId.gnbId.id == targetGnbId.gnbId.id &&
            pGnb->globalGnbId.gnbId.idLength == targetGnbId.gnbId.idLength &&
            pGnb->globalGnbId.plmn.longId == targetGnbId.plmn.longId)
        {
            return true;
        }
        return false;
    };

    for (uint16_t gnbNum = 0; MAX_GNB_PER_SYS > gnbNum; gnbNum++)
    {
        VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

        if (pGnb->status != EQUIP)
        {
            continue;
        }

        if (compareGnbGlobalId(pGnb) == false)
        {
            continue;
        }

        if (FnVCCB_GetCellNumFromCellId(gnbNum, targetCellId, &cellNum) != GOOD)
        {
            return MAX_CELL_NUM_VCCB;
        }
        break;
    }

    return cellNum;
}

/**
 *  @brief This function tells the location of the UE that the UE was last identified with.
 *  @param callInfo_type* ptCi
 *  @return int16_t GOOD/BREAK/ERROR (1/-1)
 */
uint16_t VCCB_FindF1IndexUelocated(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_GNB_DU_PER_GNB_CU_CP);

    uint16_t releaseF1Index = MAX_GNB_DU_PER_GNB_CU_CP;
    uint16_t releaseCellNum = MAX_CELL_NUM_VCCB;
    int16_t status = GOOD;

    status = VCCM_GetCellNumFromNrCgi(ptCi->gnbNum, &ptCi->nRCGI, &releaseCellNum, false);
    if (status == GOOD && releaseCellNum < MAX_CELL_NUM_VCCB)
    {
        const VccbCellInfo_type *const pCell = &CELLINFO[releaseCellNum];

        releaseF1Index = pCell->endPointF1Index;
    }
    else  // If the value is unknown, select the default end point.
    {
        releaseF1Index = ptCi->endPointInfo.f1Idx;
    }

    return releaseF1Index;
}

/**
 *  @brief This function stores the triggered event and reason when the PDU Session/Qos Flow/DRB, etc. should be
 * released.
 *  @param callInfo_type*        ptCi
 *  @param releaseInfo_type*     ptReleaseInfo
 *  @param releaseTrigger_type   triggerType
 *  @param uint16_t              releaseCause
 */
void VCCB_SetBearerReleaseInfo(releaseInfo_type *ptRelInfo, releaseTrigger_type triggerType, uint16_t cause)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptRelInfo);
    VCCB_CHECK_E_RANGE_AND_VOID(triggerType, e_MaxOfReleaseTrigger);

    // if (cause == CAUSE_NO_FAULT)
    // {
    //     return;
    // }

    ptRelInfo->releaseCause = cause;
    ptRelInfo->triggerEvent = (uint8_t)triggerType;
}

uint8_t VLIB_findCellPlmnIndex(uint16_t cellNum, uint32_t plmnLongId)
{
    AUTO_TRACE_FUNC;

    uint8_t plmnIndex = 0;

    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, 0xFF);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    for (plmnIndex = 0; plmnIndex < MAX_PLMN_INDEX; plmnIndex++)
    {
        if (pCell->cellPlmnIndexInfo[plmnIndex].status != EQUIP) continue;

        if (pCell->cellPlmnIndexInfo[plmnIndex].servedPlmn == plmnLongId)
        {
            return plmnIndex;
        }
    }

    return 0xFF;
}

void VLIB_updateSuspendedCellInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    VCCB_PRINT_CALL_MSG(ptCi, "Update suspendedCRNTI(%u->%u), suspendedPCI(%u->%u)\n", ptCi->ueInfo.ueId.suspendedCRNTI,
        ptCi->ueInfo.ueId.cRNTI, ptCi->ueInfo.ueId.suspendedPCI, pCell->phyCellId);

    // 1. CRNTI
    ptCi->ueInfo.ueId.suspendedCRNTI = ptCi->ueInfo.ueId.cRNTI;

    // 2. PCI(Physical Cell Id)
    ptCi->ueInfo.ueId.suspendedPCI = pCell->phyCellId;

    // 3. CellIdentity(NRCGI) - pre-stored
    // ptCi->nRCGI.plmn.longId = GNBINFO[gnbNum].plmnIdInfo[0].longId;
    // ptCi->nRCGI.plmn.s2 = GNBINFO[gnbNum].plmnIdInfo[0].s2;
    // ptCi->nRCGI.ci = pCell->cgi.ci;

    return;
}

uint8_t FnVCCB_GetMappedRRCEstablishmentCause(uint8_t resumeCause)
{
    AUTO_TRACE_FUNC;
    uint8_t rRCEstablishmentCause;
    switch (resumeCause)
    {
        case NRRRC_ResumeCause_emergency:
            rRCEstablishmentCause = ci_emergency;
            break;
        case NRRRC_ResumeCause_highPriorityAccess:
            rRCEstablishmentCause = ci_highPriorityAccess;
            break;
        case NRRRC_ResumeCause_mt_Access:
            rRCEstablishmentCause = ci_mt_Access;
            break;
        case NRRRC_ResumeCause_mo_Signalling:
            rRCEstablishmentCause = ci_mo_Signalling;
            break;
        case NRRRC_ResumeCause_mo_Data:
            rRCEstablishmentCause = ci_mo_Data;
            break;
        case NRRRC_ResumeCause_mo_VoiceCall:
            rRCEstablishmentCause = ci_mo_VoiceCall;
            break;
        case NRRRC_ResumeCause_mo_VideoCall:
            rRCEstablishmentCause = ci_mo_VideoCall;
            break;
        case NRRRC_ResumeCause_mo_SMS:
            rRCEstablishmentCause = ci_mo_SMS;
            break;
        case NRRRC_rna_Update:
            rRCEstablishmentCause = ci_relocatedCall;
            break;
        case NRRRC_ResumeCause_mps_PriorityAccess:
            rRCEstablishmentCause = ci_mps_PriorityAccess;
            break;
        case NRRRC_ResumeCause_mcs_PriorityAccess:
            rRCEstablishmentCause = ci_mcs_PriorityAccess;
            break;
        default:
            rRCEstablishmentCause = ci_relocatedCall;
            break;
    }
    return rRCEstablishmentCause;
}

// NG_HOREQ_PDU_QFI_DIFF_21B
int16_t VLIB_checkRadioBearerStatusForMobility(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        return ERROR;
    }

    uint16_t callPduIdx;
    callPDUSessInfo_type *ptPi = NULL;
    uint8_t pduQosFlowIdx = 0;
    uint16_t callQosFlowIdx = 0;
    qosFlowInfo_type *ptQi = NULL;

    uint8_t num_not_allocated_qfi_in_pdu = 0, num_not_allocated_qfi = 0;

    if (ptCi->hoInfo.hoType.system == HO_TYPE_INTRA_SYSTEM)
    {
        for (callPduIdx = 0; callPduIdx < MAX_PDU_SESS_PER_CALL; callPduIdx++)
        {
            if (!IS_VALID_NODE(PDU_NODE, ptCi, &(ptCi->pduSess[callPduIdx]))) continue;
            if (ptCi->pduSess[callPduIdx].usage != CI_use) continue;

            ptPi = &ptCi->pduSess[callPduIdx];

            if (ptPi->pduSessStatus != S_Setup) continue;

            uint8_t qfiAllAcceptInPdu = TRUE;

            // QoS Flows
            for (pduQosFlowIdx = 0; pduQosFlowIdx < MAX_QOS_FLOW_PER_PDU_SESS; pduQosFlowIdx++)
            {
                callQosFlowIdx = ptCi->pduSess[callPduIdx].qosFlowIndex[pduQosFlowIdx];

                if (callQosFlowIdx >= MAX_QOS_FLOW_PER_CALL) continue;
                if (!IS_VALID_NODE(QOSFLOW_NODE, ptCi, &(ptCi->qosFlow[callQosFlowIdx]))) continue;

                ptQi = &ptCi->qosFlow[callQosFlowIdx];

                if (ptQi->qosFlowStatus != S_Setup) continue;

                // This is the case where the AMF includes more PDUs and QosFlows than the RRC handover preparation.
                if (ptQi->drbIdxInCall >= MAX_DRB_PER_SA_CALL)
                {
                    // not allocated QFI
                    num_not_allocated_qfi++;
                    qfiAllAcceptInPdu = FALSE;
                    continue;
                }

                // This is the case where the RRC handover preparation includes more PDUs and QosFlow than the AMF. (w/
                // SCG ue..) MN DRB -> release SCG cell group -> release
            }

            if (qfiAllAcceptInPdu == FALSE) num_not_allocated_qfi_in_pdu++;
        }
    }
    else
    {
        /* Inter system handover is needed to allocate DRB w/ full configuration */
    }

    // Handover : AMF sends the more QFI
    // MR-DC : target MN decodes and stores the source SN radioBearerConfig. It's reject case from 21C
    if (num_not_allocated_qfi > 0)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi,
            "Handover Not Allowed : AMF includes more PDUs(%u) and QosFlows(%u) than the "
            "RRC handover preparation\n",
            num_not_allocated_qfi_in_pdu, num_not_allocated_qfi);
        MACRO_CALL_FAULT_SAVE(NG_HandoverRequestAmfgnb_id, CauseNgapRadioNetworkLayerHandoverTargetNotAllowed);
        return ERROR;
    }

    return GOOD;
}

/**
 *  @brief This function change status and failcause for PDU Session/QosFlow
 */
void VLIB_SetStatusToFailforAllRequestedPduAndQosFlow(callInfo_type *ptCi, uint16_t cause)
{
    AUTO_TRACE_FUNC;

    uint8_t pduIdx;
    uint16_t qosFlowIdxInPdu;
    uint16_t qosFlowIdxInCall;
    callPDUSessInfo_type *ptPi = NULL;
    qosFlowInfo_type *ptQi = NULL;

    VALID_E_POINT_CHECK_VOID(ptCi);

    for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        ptPi = &ptCi->pduSess[pduIdx];
        if (ptPi->usage != CI_use) continue;

        // Set PDU Session Status & Cause
        switch (ptPi->pduSessStatus)
        {
            case S_Setup:
                SET_PDU_STATUS(ptCi, pduIdx, S_FailToSetup);
                break;
            case S_Modify:
                SET_PDU_STATUS(ptCi, pduIdx, S_FailToModify);
                break;
            case S_Release:
                SET_PDU_STATUS(ptCi, pduIdx, S_FailToRelease);
                break;
            default:
                break;
        }

        ptPi->failCause = cause;

        for (qosFlowIdxInPdu = 0; qosFlowIdxInPdu < MAX_QOS_FLOW_PER_PDU_SESS; qosFlowIdxInPdu++)
        {
            qosFlowIdxInCall = ptPi->qosFlowIndex[qosFlowIdxInPdu];
            if (qosFlowIdxInCall >= MAX_QOS_FLOW_PER_CALL) continue;
            ptQi = &ptCi->qosFlow[qosFlowIdxInCall];

            if (ptQi->usage != CI_use) continue;
            if (ptQi->qosFlowStatus == S_Idle) continue;

            // Set Qos Flow Status & Cause
            switch (ptQi->qosFlowStatus)
            {
                case S_Setup:
                    SET_QOSFLOW_STATUS(ptCi, qosFlowIdxInCall, S_FailToSetup);
                    break;
                case S_Modify:
                    SET_QOSFLOW_STATUS(ptCi, qosFlowIdxInCall, S_FailToModify);
                    break;
                case S_Release:
                    SET_QOSFLOW_STATUS(ptCi, qosFlowIdxInCall, S_FailToRelease);
                    break;
                default:
                    break;
            }

            ptQi->failCause = cause;
        }
    }

    return;
}


/**
 * @brief This function change status and failcause for PDU Session/QosFlow/DRB
 * @param ptCi Pointer to the call information structure.
 * @param forcedCause The cause for setting the failCause of each Bearers(PDU Session/QosFlow/DRB)
 */
void VLIB_SetStatusToFailforAllRequestedBearerWithForced(callInfo_type *ptCi, uint16_t forcedCause)
{
    AUTO_TRACE_FUNC;

    uint8_t pduIdx;
    uint16_t qosFlowIdxInPdu;
    uint16_t qosFlowIdxInCall;
    uint16_t drbIndexInPdu;
    uint16_t drbIdxInCall;

    callPDUSessInfo_type *ptPi = NULL;
    callDRBInfo_type *ptDi = NULL;
    qosFlowInfo_type *ptQi = NULL;

    VALID_E_POINT_CHECK_VOID(ptCi);

    for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        ptPi = &ptCi->pduSess[pduIdx];
        if (ptPi->usage != CI_use) continue;
        if (ptPi->pduSessStatus == S_Idle) continue;

        // Set PDU Session Status & Cause
        switch (ptPi->pduSessStatus)
        {
            case S_Setup:
            case S_FailToSetup:
                SET_PDU_STATUS(ptCi, pduIdx, S_FailToSetup);
                ptPi->failCause = forcedCause;
                break;
            case S_Modify:
            case S_FailToModify:
                if (ptPi->firstReqStatusInThisProcedure == S_Setup)
                {
                    SET_PDU_STATUS(ptCi, pduIdx, S_FailToSetup);
                }
                else
                {
                    SET_PDU_STATUS(ptCi, pduIdx, S_FailToModify);
                }
                ptPi->failCause = forcedCause;
                break;
            case S_Release:
            case S_FailToRelease:
                SET_PDU_STATUS(ptCi, pduIdx, S_FailToRelease);
                ptPi->failCause = forcedCause;
                break;
            default:
                break;
        }

        for (qosFlowIdxInPdu = 0; qosFlowIdxInPdu < MAX_QOS_FLOW_PER_PDU_SESS; qosFlowIdxInPdu++)
        {
            qosFlowIdxInCall = ptPi->qosFlowIndex[qosFlowIdxInPdu];
            if (qosFlowIdxInCall >= MAX_QOS_FLOW_PER_CALL) continue;

            ptQi = &ptCi->qosFlow[qosFlowIdxInCall];
            if (ptQi->usage != CI_use) continue;
            if (ptQi->qosFlowStatus == S_Idle) continue;

            // Set Qos Flow Status & Cause
            switch (ptQi->qosFlowStatus)
            {
                case S_Setup:
                case S_FailToSetup:
                    SET_QOSFLOW_STATUS(ptCi, qosFlowIdxInCall, S_FailToSetup);
                    ptQi->failCause = forcedCause;
                    break;
                case S_Modify:
                case S_FailToModify:
                    if (ptQi->firstReqStatusInThisProcedure == S_Setup)
                    {
                        SET_QOSFLOW_STATUS(ptCi, qosFlowIdxInCall, S_FailToSetup);
                    }
                    else
                    {
                        SET_QOSFLOW_STATUS(ptCi, qosFlowIdxInCall, S_FailToModify);
                    }
                    ptQi->failCause = forcedCause;
                    break;
                case S_Release:
                case S_FailToRelease:
                    SET_QOSFLOW_STATUS(ptCi, qosFlowIdxInCall, S_FailToRelease);
                    ptQi->failCause = forcedCause;
                    break;
                default:
                    break;
            }
        }


        for (drbIndexInPdu = 0; drbIndexInPdu < MAX_DRB_PER_PDU_SESS; drbIndexInPdu++)
        {
            drbIdxInCall = ptPi->drbIndex[drbIndexInPdu];
            if (drbIdxInCall >= MAX_DRB_PER_SA_CALL) continue;

            ptDi = &ptCi->drb[drbIdxInCall];
            if (ptDi->usage != CI_use) continue;
            if (ptDi->drbStatus == S_Idle) continue;

            // Set DRB Status & Cause
            switch (ptDi->drbStatus)
            {
                case S_Setup:
                case S_FailToSetup:
                    SET_DRB_STATUS(ptCi, drbIdxInCall, S_FailToSetup);
                    ptDi->failCause = forcedCause;
                    break;

                case S_Modify:
                case S_FailToModify:
                    if (ptDi->firstReqStatusInThisProcedure == S_Setup)
                    {
                        SET_DRB_STATUS(ptCi, drbIdxInCall, S_FailToSetup);
                    }
                    else
                    {
                        SET_DRB_STATUS(ptCi, drbIdxInCall, S_FailToModify);
                    }
                    ptDi->failCause = forcedCause;
                    break;

                case S_Release:
                case S_FailToRelease:
                    SET_DRB_STATUS(ptCi, drbIdxInCall, S_FailToRelease);
                    ptDi->failCause = forcedCause;
                    break;

                default:
                    break;
            }
        }
    }

    return;
}

/**
 *  @brief This function is used to obtain the number of PDU sessions in process of setup or modification.
 */
uint8_t VLIB_GetPduSessionNumOnSetupOrModi(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    uint8_t tmpPduNum = 0;
    uint8_t pduIdx;
    callPDUSessInfo_type *ptPi = NULL;

    if (ptCi == NULL)
    {
        return tmpPduNum;
    }

    for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        ptPi = &ptCi->pduSess[pduIdx];

        if (ptPi->usage != CI_use) continue;

        if ((ptPi->pduSessStatus == S_Setup) || (ptPi->pduSessStatus == S_Modify))
        {
            tmpPduNum++;
        }
    }

    return tmpPduNum;
}

bool FnVCCB_IsMandatoryF1DRBsSetupList(callInfo_type *ptCi)
{
    enumDrbBearerTag_type tag = request_bearerType;
    if (IS_NRDC_SN(ptCi))
    {
        return true;
    }

    return FnVCCB_IsAnyMnTermPerUE(ptCi, tag);
}

/**
 *  @brief This function is used to cancel NAS PDU which related failed PDU
 */
void VLIB_CancelNasPduByFailedPDU(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    uint8_t loop;
    uint8_t pduIdx;
    uint32_t numNasMsg = 0;
    uint8_t numCancelledNasPdu = 0;
    callPDUSessInfo_type *ptPi = NULL;

    VALID_E_POINT_CHECK_VOID(ptCi);

    numNasMsg = UMIN(ptCi->nasInfo.numNasMsg, VCCB_MAX_NAS_NUM_PER_CALL);

    for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        ptPi = &ptCi->pduSess[pduIdx];
        if (ptPi->usage != CI_use) continue;

        if ((ptPi->pduSessStatus == S_FailToSetup) || (ptPi->pduSessStatus == S_FailToModify))
        {
            for (loop = 0; loop < numNasMsg; loop++)
            {
                if (ptCi->nasInfo.nasPduSessionId[loop] == ptPi->pduSessId)
                {
                    ptCi->nasInfo.nasPduSessionId[loop] = CANCELLED_NAS_PDU_SESSION_ID;
                    numCancelledNasPdu++;
                }
            }
        }
    }

    if (numCancelledNasPdu == numNasMsg)
    {
        INIT_NAS_INFORMATION(ptCi->nasInfo);
    }

    return;
}

/**
 * @brief     Check State of PDU/QoS/DRB
 */
int16_t VLIB_IsCommonValidStateOfPduQosDrb(uint8_t status)
{
    AUTO_TRACE_FUNC;

    switch (status)
    {
        case S_Setup:
        case S_Modify:
        case S_Idle:
        case S_FailToModify:   // It's valid. because It just failed for modification operation.
        case S_FailToRelease:  // It's valid. because It will not be released.
        case S_AddToModify:
        case S_ModToModify:
            return GOOD;

        default:
        case S_Release:
        case S_FailToSetup:
        case S_RelToModify:
            return ERROR;
    }
}

/**
 * @brief     Check State of PDU/QoS/DRB
 */
int16_t VLIB_IsCommonValidStateOfPduQosDrbForCellReselection(uint8_t status)
{
    AUTO_TRACE_FUNC;

    switch (status)
    {
        case S_Setup:
        case S_Modify:
        case S_Idle:
        case S_FailToModify:   // It's valid. because It just failed for modification operation.
        case S_FailToRelease:  // It's valid. because It will not be released.
        case S_AddToModify:
        case S_ModToModify:
        case S_Release:
            return GOOD;

        default:
        case S_FailToSetup:
        case S_RelToModify:
            return ERROR;
    }
}

/**
 * @brief     Check State of PDU/QoS/DRB
 */
int16_t VLIB_IsCommonValidStateOfPduQosDrbForQosMonitoring(uint8_t status)
{
    AUTO_TRACE_FUNC;

    switch (status)
    {
        case S_Setup:
        case S_Modify:
        case S_Idle:
        case S_AddToModify:
        case S_ModToModify:
            return GOOD;

        default:
        case S_Release:
        case S_RelToModify:
        case S_FailToModify:   // It's valid. because It just failed for modification operation.
        case S_FailToRelease:  // It's valid. because It will not be released.
        case S_FailToSetup:
            return ERROR;
    }
}
/**************************************************************
 *  Function     : VLIB_GetGnbNumFromGnbIdx
 *  Description  : This function is used to extract gnbNum from GNB IDX(GNB NUM or GNB ID)
 ***************************************************************/
uint16_t VLIB_GetGnbNumFromGnbIdx(uint32_t in_gnbId, uint8_t in_gnbNum)
{
    AUTO_TRACE_FUNC;
    if (VCOM_getSystemType() == e_VCCB_NVGNB || (TRUE == FOO.VF_MultipleOperatorRanSupport))
    {
        return in_gnbNum;
    }
    else
    {
        uint16_t out_gnbNum = MAX_GNB_PER_SYS;

        if (GOOD != VLIB_GetGnbNumFromId(&out_gnbNum, in_gnbId))
        {
            VCCB_PRINT_ERROR("Invalid gnbId(%d)!\n", in_gnbId);
            return MAX_GNB_PER_SYS;
        }

        return out_gnbNum;
    }
}

/**
 *  @brief This function is used to find Neighbour Gnb Nr Cell Id by physCellId and Frequency
 */
int16_t VLIB_GetNbrGnbNrCellIdByPciAndFreq(
    callInfo_type *ptCi, uint32_t usedFreq, const measResultNR_type *ptMeasResultNR, enumRSType rsType, uint64_t *ptNci)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMeasResultNR);
    VALID_E_POINT_CHECK_ERROR(ptNci);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    int16_t status = GOOD;
    uint16_t nbrIdx = 0;
    nbrGnbCellInfo_type *ptNbrGnbCell = NULL;

    for (nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)  // go through all the neighbors
    {
        if (N_EQUIP == pCell->Nbr[nbrIdx].status)
        {
            continue;
        }
        status = getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &ptNbrGnbCell);
        if (status == ERROR)
        {
            continue;
        }
        if (N_EQUIP == ptNbrGnbCell->status)
        {
            continue;
        }
        status = VCCM_ComparePcisAndFreqsOfNbrCell(ptMeasResultNR, usedFreq, rsType, ptNbrGnbCell);
        if (status == BREAK)
        {
            continue;
        }
        *ptNci = VLIB_GnbIdCellId2NrCellId(&ptNbrGnbCell->globalGnbId.gnbId, ptNbrGnbCell->cellId);
        return GOOD;
    }
    return ERROR;
}

/**
 *  @brief This function is used to find Neighbour Enb Eutra Cell Id by physCellId and Frequency
 */
int16_t VLIB_GetNbrEnbEutraCellIdByPciAndFreq(
    callInfo_type *ptCi, uint32_t earfcnDl, uint16_t physCellId, uint64_t *ptEci)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptEci);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    int16_t status = GOOD;
    uint16_t eutraNbrIdx = 0;
    nbrEnbCellInfo_type *pNbrEnbCell = NULL;

    for (eutraNbrIdx = 0; eutraNbrIdx < MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL; eutraNbrIdx++)
    {
        if (N_EQUIP == pCell->eutraNbr[eutraNbrIdx].status)
        {
            continue;
        }
        status = getNbrEnbCellByCellNbrIdx(ptCi->servCellNum, eutraNbrIdx, &pNbrEnbCell);
        if (status == ERROR)
        {
            continue;
        }
        if (N_EQUIP == pNbrEnbCell->status)
        {
            continue;
        }
        if (physCellId != pNbrEnbCell->pci || earfcnDl != pNbrEnbCell->earfcnDl)
        {
            continue;
        }
        *ptEci = VCCB_GET_ECGI(pNbrEnbCell->enbId, pNbrEnbCell->cellId);
        return GOOD;
    }
    return ERROR;
}

int16_t FnVCCB_GetNbrPlmnList(
    callInfo_type *ptCi, uint16_t cellNum, uint16_t nbrIdx, allowedPlmnList_Type *pOutPlmnList)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pOutPlmnList);
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_NBR_PER_CELL);
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);

    int16_t status;

    pOutPlmnList->num_plmn = 0;

    if (VCCB_IS_INTRA_GNB_NEIGHBOR(cellNum, nbrIdx))  // INTRA-GNB
    {
        uint16_t targetCellNum = MAX_CELL_NUM_VCCB;

        VCCB_GET_INTRA_GNB_NBR_CELLNUM(cellNum, nbrIdx, targetCellNum);  // Convert nbrIdx to CellNum

        VCCB_CHECK_VALID_CELLNUM_ERROR(targetCellNum);

        if (ptCi->callType == E_CALLTYPE_SA)
        {
            status = VLIB_getBPLMN(ptCi, targetCellNum, pOutPlmnList);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VLIB_getBPLMN ERROR in FnVCCB_GetNbrPlmnList.\n");
        }
        else
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "The NSA is not supported.\n");
            return ERROR;  // Reject procedure
        }
    }
    else
    {
        uint16_t nbrPlmnIdx;
        nbrGnbCellInfo_type *pNbr = NULL;

        status = getNbrGnbCellByCellNbrIdx(cellNum, nbrIdx, &pNbr);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "getNbrGnbCellByCellNbrIdx ERROR in FnVCCB_GetNbrPlmnList.\n");

        for (nbrPlmnIdx = 0; nbrPlmnIdx < MAX_PLMN_INDEX; nbrPlmnIdx++)
        {
            if (pOutPlmnList->num_plmn >= MAX_NUM_PLMN) break;

            if (EQUIP != pNbr->cellPlmnInfo[nbrPlmnIdx].shmStatus) continue;

            pOutPlmnList->plmn[pOutPlmnList->num_plmn++].longId = pNbr->cellPlmnInfo[nbrPlmnIdx].longId;
        }
    }

    VCCB_PRINT_CALL_LOG_PLMN(ptCi, "[%u] %X %X %X %X %X %X %X %X %X %X %X %X\n", pOutPlmnList->num_plmn,
            pOutPlmnList->plmn[0].longId, pOutPlmnList->plmn[1].longId, pOutPlmnList->plmn[2].longId,
            pOutPlmnList->plmn[3].longId, pOutPlmnList->plmn[4].longId, pOutPlmnList->plmn[5].longId,
            pOutPlmnList->plmn[6].longId, pOutPlmnList->plmn[7].longId, pOutPlmnList->plmn[8].longId,
            pOutPlmnList->plmn[9].longId, pOutPlmnList->plmn[10].longId, pOutPlmnList->plmn[11].longId);

    return GOOD;
}

int16_t FnVCCB_IsSetupOrModifyFailOnVonr(callInfo_type *ptCi, enumCheckHoOrRedirectionState_type checkState, uint8_t &checkResult)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    uint8_t pduIdx;
    uint8_t selected5qi = 0;
    uint16_t qosFlowIdxInPdu;
    callPDUSessInfo_type *ptPi = NULL;
    qosFlowInfo_type *ptQi = NULL;

    // Check 5QI(==1) which is set/modified
    for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        ptPi = &ptCi->pduSess[pduIdx];
        if (ptPi->usage != CI_use) continue;

        // Check PDU Session status
        if ((ptPi->pduSessStatus != S_Setup) && (ptPi->pduSessStatus != S_FailToSetup) &&
            (ptPi->pduSessStatus != S_Modify) && (ptPi->pduSessStatus != S_FailToModify))
        {
            continue;
        }

        for (qosFlowIdxInPdu = 0; qosFlowIdxInPdu < MAX_QOS_FLOW_PER_PDU_SESS; qosFlowIdxInPdu++)
        {
            if (ptPi->qosFlowIndex[qosFlowIdxInPdu] >= MAX_QOS_FLOW_PER_CALL) continue;

            ptQi = &ptCi->qosFlow[ptPi->qosFlowIndex[qosFlowIdxInPdu]];
            if (ptQi->usage != CI_use) continue;

            VLIB_getFiveQi(ptQi, &selected5qi);
            if (selected5qi != VONR_5QI) continue;

            // Check QoS Flow status
            if ((ptQi->qosFlowStatus == S_Setup)  || (ptQi->qosFlowStatus == S_FailToSetup) ||
                (ptQi->qosFlowStatus == S_Modify) || (ptQi->qosFlowStatus == S_FailToModify))
            {
                if(checkState == CheckHoOrRedirect_OnPartialState) // Check Only Failed Case.
                {
                    if( (ptQi->qosFlowStatus == S_FailToSetup ) ||
                        ((ptQi->firstReqStatusInThisProcedure == S_Setup) && (ptQi->qosFlowStatus == S_FailToModify)))
                    {
                        checkResult = CheckResult_Ho;
                    }
                    else if (ptQi->qosFlowStatus == S_FailToModify)
                    {
                        checkResult = CheckResult_Redirect;
                        return TRUE;
                    }
                }
                else // CheckHoOrRedirect_OnUeReleaseState // state may not changed fail. So check all ongoing operation State
                {
                    checkResult = CheckResult_Redirect;
                    return TRUE;
                }
            }
        }// for QosFlow
    } // for PDU

    if(checkResult == CheckResult_NoCondition)
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

int16_t FnVCCB_CheckVoNrFail_InterRatHoOrRedirection(callInfo_type *ptCi, enumCheckHoOrRedirectionState_type checkState, uint8_t &checkResult, uint8_t &checkFallbackType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    // 1. Check VoNR SetupFail in CheckHoOrRedirect_OnPartialState
    //    Check VoNR SetupFail/ModifyFail in CheckHoOrRedirect_OnUeReleaseState
    if (TRUE != FnVCCB_IsSetupOrModifyFailOnVonr(ptCi, checkState, checkResult))
    {
        return FALSE;
    }

    if(checkResult == CheckResult_NoCondition)
    {
        return FALSE;
    }

    // 2. Check Emergency Fallback by VoNR Fail
    if( (ptCi->bitFlag.isEmergencyCallByReqValInThisProcedure == VCCB_FLAG_ON) &&
        (FnVCCB_IsEmergencyFallbackVoNrFailSwitch(*ptCi) == TRUE))
    {
        checkFallbackType = CheckType_EmergencyFallback;
        if(DBG->flag.logEmergencyVonrCall)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[CheckVoNrFail] CheckType_EmergencyFallback)\n");
        }
        // In Emergency Fallack, There is no constration for CheckResult_Ho.

        return TRUE;
    }
    else
    {
        // 3. Check EPS Fallback by VoNR Fail
        // 3-1. Check Switch for Fallback.
        if (pGnb->cfg.epsFallbackSwitch != enabled)
        {
            return FALSE;
        }

        // 3-2. Check Switch for Fallback.
        if ((pGnb->cfg.epsFallbackVoNrFailSwitch_Redirection != enabled) &&
            (pGnb->cfg.epsFallbackVoNrFailSwitch_HO          != enabled))
        {
            return FALSE;
        }

        // 3-3. If redirectionVoiceFallback is NGAP_not_possible, EPS Fallback is not possible.
        if ((ptCi->ueInfo.ngapBuf.m.redirectionVoiceFallbackPresent == OPT_PRESENT) &&
            (ptCi->ueInfo.ngapBuf.redirectionVoiceFallbackValue == NGAP_not_possible))
        {
            // NGAP_not_possible case
            return FALSE;
        }

        // 3-4. Only Possible HO when epsFallbackVoNrFailSwitch_HO is ON.
        if((pGnb->cfg.epsFallbackVoNrFailSwitch_HO != enabled) &&
            (checkResult == CheckResult_Ho))
        {
            checkResult = CheckResult_Redirect;
        }

        checkFallbackType = CheckType_EpsFallback;
        if(DBG->flag.logEmergencyVonrCall)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[CheckVoNrFail] CheckType_EpsFallback)\n");
        }
        return TRUE;
    }
}

int16_t FnVCCB_CheckInterRatRedirectionPossibleInFail(callInfo_type *ptCi, uint8_t checkFallbackType, enumCheckHoOrRedirectionState_type checkState, uint8_t &checkResult)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    int16_t status;
    enumRedirectionType_type saveRedirType = ptCi->redirectionInfo.redirType;

    enumInterRatRedirectionForcedOption_type forcedOption = Redirection_Forced_Blind;

    // 1. If Fallback Case, then Set Forcely Fallback for just check
    if(checkFallbackType == CheckType_EpsFallback)
    {
        ON_EPS_FALLBACK_REDIRECTION(ptCi); // Need To Set firstly for SelectEARFCN_ForInterRATRedirection()
    }
    else if(checkFallbackType == CheckType_EmergencyFallback)
    {
        ON_EMERGENCY_FALLBACK_REDIRECTION(ptCi); // Need To Set firstly for SelectEARFCN_ForInterRATRedirection()
    }

    // 2. When Release State, Set Fail for ServiceType.
    if(checkState == CheckHoOrRedirect_OnUeReleaseState)
    {
        // VoNR or Other Case should use callFaultCause. When Redirection possible, the set EPS cause for only EPS Redirection.
        VLIB_SetStatusToFailforAllRequestedBearerWithForced(ptCi, ptCi->cause.callFault.callFaultCause);
    }

    // 3. Set forcedOption (If EPS Fallback & Partial State & Result is H/O)
    if( ((checkFallbackType == CheckType_EpsFallback) ||
         (checkFallbackType == CheckType_EmergencyFallback)) &&
        (checkState    == CheckHoOrRedirect_OnPartialState) &&
        (checkResult   == CheckResult_Ho                  ))
    {
        forcedOption = Redirection_Forced_MrBased;
    }

    // 4. Check and Get IRAT Redirection Freq.
    status = SelectEARFCN_ForInterRATRedirection(ptCi, forcedOption);
    if (status != GOOD )
    {
        OFF_EPS_FALLBACK_REDIRECTION(ptCi); // When CheckHoOrRedirect_OnUeReleaseState, need to clear.
        OFF_EMERGENCY_FALLBACK_REDIRECTION(ptCi); // When CheckHoOrRedirect_OnUeReleaseState, need to clear.
        VCCB_PRINT_CALL_ERROR(ptCi, "No IRAT Redirection Freq(forcedOption=%d, checkResult=0x%0x) ERROR !!\n", forcedOption, checkResult);
        return FALSE; // Do Processing remain things.
    }

    // Set LteFallbackTriggered. (26B)
    MACRO_CHECK_AND_SET_LTE_FALLBACK_TRIGGERED(ptCi);

    if(checkState == CheckHoOrRedirect_OnPartialState)
    {
        // Here, Only make a judgment, and the actual action will be done later.
        OFF_EPS_FALLBACK_REDIRECTION(ptCi);
        OFF_EMERGENCY_FALLBACK_REDIRECTION(ptCi);
        ptCi->redirectionInfo.redirType = saveRedirType;
    }
    else // CheckHoOrRedirect_OnUeReleaseState
    {
        // EPS/Emergency Fallback is already Set. But If SpecificSlice, then need to set ON
        if(checkFallbackType == CheckType_SpecificSliceFallback) // for SpecificSlice.
        {
            ON_SPECIFIC_SLICE_REDIRECT_IN_BASIC_SA(ptCi);
        }
    }

    // If No Ho Condition, then change Result.
    if(ptCi->redirectionInfo.actualRedirectionMethod != MR_BASED_REDIR_OR_HO)
    {
        checkResult = CheckResult_Redirect;
    }

    return TRUE;
}

int16_t FnVCCB_DoInterRatRedirectionInFail(callInfo_type *ptCi, uint8_t isEpsEmerFallback, uint16_t msgId) 
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint16_t callFaultCause = 0;

    // 1. Set VoiceFallbackIndicator in RRC Release if possible.
    if(isEpsEmerFallback == VCCB_FLAG_ON) // EPS Fallback or Emergency Fallback.
    {
        FnVCCB_CheckAndSetVoiceFallbackIndicator(ptCi);
    }

    // 2. Set All Bearer as Fail and Response to AMF.
    // Save & Clear Call Fault
    if(isEpsEmerFallback == VCCB_FLAG_ON)
    {
        callFaultCause = CauseNgapRadioNetworkLayerImsVoiceEpsFallbackOrRatFallbackTriggered;
    }
    else // PS Slice Fail.
    {
        callFaultCause = ptCi->cause.callFault.callFaultCause;
        // Already Set Status in
    }

    // Set the Status using Cause.
    VLIB_SetStatusToFailforAllRequestedBearerWithForced( ptCi, callFaultCause);

    MACRO_RESET_CALL_FAULT_CAUSES;

    // 3. Send Response Message with PDU FailCause
    if (ptCi->stateCmd == RRCConnection_cmd)
    {
        if (GETBIT(ptCi->flag.respFlag, NG_INIT_SETUP_FLAG))
        {
            auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_InitialContextSetupResponseAllAmf_id);
            VALID_E_POINT_CHECK_ERROR(ngapSender);
            VCCB_RETURN_ON_CALL_ERROR(
                ptCi, ngapSender->sendMsg(), "sendMsg(NG_InitialContextSetupResponseAllAmf) ERROR!\n");
        }
    }
    else if (ptCi->stateCmd == PDUSetup_cmd)
    {
        if (!GET_PDU_SESSION_PROC_NO_RESP(ptCi->flag.setupFlag))
        {
            auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_PDUSessionResourceSetupResponse_id);
            VALID_E_POINT_CHECK_ERROR(ngapSender);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, ngapSender->sendMsg(), "sendMsg(NG_PDUSessionResourceSetupResponse) ERROR!\n");

            ON_PDU_SESSION_PROC_NO_RESP(ptCi->flag.setupFlag);  // For not sending in VCCB_SA_Conn_Rel_sendReleaseAll()
        }
    }
    else if (ptCi->stateCmd == PDUModify_cmd)
    {
        if (!GET_PDU_SESSION_PROC_NO_RESP(ptCi->flag.setupFlag))
        {
            auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_PDUSessionResourceModifyResponse_id);
            VALID_E_POINT_CHECK_ERROR(ngapSender);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, ngapSender->sendMsg(), "sendMsg(NG_PDUSessionResourceModifyResponse) ERROR!\n");

            ON_PDU_SESSION_PROC_NO_RESP(ptCi->flag.setupFlag);  // For not sending in VCCB_SA_Conn_Rel_sendReleaseAll()
        }
    }

    // 4. Collect PDU/QosFlow/DRB Stat (refer to VCCM_BlindRedirectionWithResponse() )
    VLIB_PduSessionResourceSetup_CollectStat_AllFailedCause(ptCi, callFaultCause);

    // 5. Check Security Mode Command
    if ((ptCi->stateCmd == RRCConnection_cmd) &&
        (ptCi->bitFlag.isPossibleRedirectionInBasicProcedure == VCCB_FLAG_ON) &&
        (ptCi->bitFlag.isNeedSecurityFlow == TRUE))
    {
        if(GOOD != FnVCCB_SendNRRRC_SecurityModeCommand_F1DLTransfer(ptCi, msgId))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendNRRRC_SecurityModeCommand_F1DLTransfer ERROR !!\n");
        }
    }

    // 6. Release with redirection info (Blind Redirection, including retain stat processing)
    if (GOOD != VCCM_RedirectionByRRCReleaseTrigger(ptCi, msgId))
    {
        return ERROR;
    }
    return GOOD;
}

// Set 5QI Fail Cause and Associated PDU/QosFlow
void FnVCCB_FindVoNrFailAndSetCauseRelatedBearers(callInfo_type *ptCi, uint16_t newCause)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t pduIdx;
    uint8_t selected5qi = 0;
    uint16_t qosFlowIdxInPdu;
    uint16_t callDrbIdx = 0;
    callPDUSessInfo_type *ptPi = NULL;
    qosFlowInfo_type *ptQi = NULL;

    for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        ptPi = &ptCi->pduSess[pduIdx];
        if (ptPi->usage != CI_use) continue;

        // Check PDU Session status
        if ((ptPi->pduSessStatus != S_Setup ) && (ptPi->pduSessStatus != S_FailToSetup ) &&
            (ptPi->pduSessStatus != S_Modify) && (ptPi->pduSessStatus != S_FailToModify))
        {
            continue;
        }

        for (qosFlowIdxInPdu = 0; qosFlowIdxInPdu < MAX_QOS_FLOW_PER_PDU_SESS; qosFlowIdxInPdu++)
        {
            if (ptPi->qosFlowIndex[qosFlowIdxInPdu] >= MAX_QOS_FLOW_PER_CALL) continue;

            ptQi = &ptCi->qosFlow[ptPi->qosFlowIndex[qosFlowIdxInPdu]];
            if (ptQi->usage != CI_use) continue;

            // Check QoS Flow status
            if ((ptQi->qosFlowStatus != S_FailToSetup) && (ptQi->qosFlowStatus != S_FailToModify))
                continue;

            VLIB_getFiveQi(ptQi, &selected5qi);

            if (selected5qi == VONR_5QI)
            {
                // QosFlow: Set New Cause
                ptQi->failCause = newCause;

                // DRB
                callDrbIdx = ptQi->drbIdxInCall;
                if (callDrbIdx < MAX_DRB_PER_SA_CALL)
                {
                    ptCi->drb[callDrbIdx].failCause = newCause;
                }

                // PDU
                if((ptPi->pduSessStatus == S_FailToSetup) || (ptPi->pduSessStatus == S_FailToModify))
                {
                    ptPi->failCause = newCause;
                }
            }
        } // for QOSFLOW
    } // for PDU

    return;
}

int16_t FnVCCB_IsSetupOrModifyFailOnSpecificSlice(callInfo_type *ptCi, enumCheckHoOrRedirectionState_type checkState, uint8_t &checkResult)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    uint8_t pduIdx;
    uint16_t qosFlowIdxInPdu;
    callPDUSessInfo_type *ptPi = NULL;
    qosFlowInfo_type *ptQi = NULL;

    // Check 5QI(==1) which is set/modified
    for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        ptPi = &ptCi->pduSess[pduIdx];
        if (ptPi->usage != CI_use) continue;

        // Check isSpecificSlice
        if(ptPi->isSpecificSlice != TRUE) continue;

        // Check PDU Session status
        if ((ptPi->pduSessStatus != S_Setup ) && (ptPi->pduSessStatus != S_FailToSetup) &&
            (ptPi->pduSessStatus != S_Modify) && (ptPi->pduSessStatus != S_FailToModify))
        {
            continue;
        }

        // When UE Release, No more check.
        if(checkState == CheckHoOrRedirect_OnUeReleaseState)
        {
            checkResult = CheckResult_Redirect;
            return TRUE;
        }
        //-----------------------------------------------------
        // Following for only CheckHoOrRedirect_OnPartialState.
        //-----------------------------------------------------

        // Check if Slice Fail in NgStore (It can be no qosflow)
        if(ptPi->specificSliceHasFailInNgStore) // It's set in NgStore.
        {
            // Already Queueing is done in Ng Store. So NOT Set checkResult.
            continue;
        }

        // if Slice Fail by VCCB, then VCCB do not save QosFlow.
        for (qosFlowIdxInPdu = 0; qosFlowIdxInPdu < MAX_QOS_FLOW_PER_PDU_SESS; qosFlowIdxInPdu++)
        {
            if (ptPi->qosFlowIndex[qosFlowIdxInPdu] >= MAX_QOS_FLOW_PER_CALL) continue;

            ptQi = &ptCi->qosFlow[ptPi->qosFlowIndex[qosFlowIdxInPdu]];
            if (ptQi->usage != CI_use) continue;

            // Check QoS Flow status (Only Failed Case)
            if( (ptQi->qosFlowStatus == S_FailToSetup ) ||
                (ptQi->qosFlowStatus == S_FailToModify ))
            {
                checkResult = CheckResult_Ho;
                return TRUE;
            }
        }// for QosFlow
    } // for PDU

    if(checkResult == CheckResult_NoCondition)
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

int16_t FnVCCB_CheckSpecificSliceFail_InterRatHoOrRedirection(callInfo_type *ptCi, enumCheckHoOrRedirectionState_type checkState, uint8_t &checkResult)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    checkResult = CheckResult_NoCondition;

    // 1. Check Specific Slice SetupFail in CheckHoOrRedirect_OnPartialState
    //    Check Specific Slice SetupFail/ModifyFail in CheckHoOrRedirect_OnUeReleaseState
    if (TRUE != FnVCCB_IsSetupOrModifyFailOnSpecificSlice(ptCi, checkState, checkResult))
    {
        return FALSE;
    }

    return TRUE;
}

int16_t FnVCCB_CheckFailCond_InterRatHoOrRedirection(callInfo_type *ptCi, uint16_t msgId, enumCheckHoOrRedirectionState_type checkState)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    uint8_t checkResult = CheckResult_NoCondition;
    uint8_t checkFallbackType = CheckType_NoFallback;

    // 1. If NSA or NR-DC SN, then No Need
    if ((ptCi->callType != E_CALLTYPE_SA) || IS_NRDC_SN(ptCi))
    {
        return STATE_IGNORE;
    }

    // 2. Clear H/O Flag. Set flag whenever Bearer condition is changed. (for service group)
    ptCi->bitFlag.isInterRatHoRequiredByVonrSetupFail = VCCB_FLAG_OFF;

    // 3. Check StateCmd (Only below stateCmd is valid to check)
    //    ReconfigComplete_cmd is NOT Support. Because Already Sent Response to AMF.
    if ((ptCi->stateCmd != RRCConnection_cmd) &&
        (ptCi->stateCmd != PDUSetup_cmd     ) &&
        (ptCi->stateCmd != PDUModify_cmd    ))
    {
        return STATE_IGNORE;
    }

    // Check Not Allowed State
    if ((ptCi->state == STATE_I2E      ) ||
        (CHECK_SA_STATE_RELEASE(ptCi) ) || // Not in Release Procedure
        (!(ptCi->ueContainerNR.rxFlag)))   // Need Ue NR Capa
    {
        // No Need to check STATE_Conn_RelCmd_ByUserInact because no condition in RRCConnection_cmd/PDUSetup_cmd/PDUModify_cmd
        return STATE_IGNORE;
    }

    // isPossibleRedirectionInBasicProcedure is set in VCCM_CheckAndDoCommonProcessForPduQosRequest()
    if(ptCi->bitFlag.isPossibleRedirectionInBasicProcedure != VCCB_FLAG_ON)
    {
        return STATE_IGNORE;
    }

    // 4. Already Fallback, Check and Triggering Redirection.
    if( (IS_FALLBACK_CASE(ptCi)             ) ||
        (IS_RFSP_BLIND_INTER_RAT_REDIRECTION(ptCi)) ||
        (IS_SPECIFIC_SLICE_REDIRECT_IN_BASIC_SA(ptCi)))
    {
        if (checkState == CheckHoOrRedirect_OnUeReleaseState)
        {
            uint8_t isEpsEmerFallback = (IS_FALLBACK_CASE(ptCi)) ? VCCB_FLAG_ON : VCCB_FLAG_OFF;
            if(IS_SPECIFIC_SLICE_REDIRECT_IN_BASIC_SA(ptCi))
            {
                // If no cause, then set specificSliceFailCause.
                MACRO_CALL_FAULT_SAVE(msgId, ptCi->redirectionInfo.specificSliceFailCause);
            }

            if(GOOD != FnVCCB_DoInterRatRedirectionInFail(ptCi, isEpsEmerFallback, msgId))
            {
                return STATE_IGNORE;
            }
            return STATE_REDIRECTION_IS_TRIGGERED; // Redirection is Triggered.
        }
        else // CheckHoOrRedirect_OnPartialState
        {
            return STATE_NEED_REDIRECTION;
        }
    }

    // 5. Check VoNR Setup Fail in CheckHoOrRedirect_OnPartialState
    // Check VoNR Setup/Modify Fail in CheckHoOrRedirect_OnUeReleaseState
    if(TRUE == FnVCCB_CheckVoNrFail_InterRatHoOrRedirection(ptCi, checkState, checkResult, checkFallbackType))
    {
        // Check IRAT Redirection Condition
        if(TRUE == FnVCCB_CheckInterRatRedirectionPossibleInFail(ptCi, checkFallbackType, checkState, checkResult))
        {
            // Check STATE is ON Partial
            if(checkState == CheckHoOrRedirect_OnPartialState)
            {
                if(checkResult == CheckResult_Ho)
                {
                    // Enqueue Action
                    if (ERROR == VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_INTER_RAT_HO_BY_VONR_SETUP_FAIL))
                    {
                        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "VCCM_enqueueAction(%d) fail\n", ENQUEUE_ACTION_INTER_RAT_HO_BY_VONR_SETUP_FAIL);
                        return STATE_NEED_REDIRECTION; // Call Release with Redirection.
                    }
                    else
                    {
                        // Mark for Inter-RAT H/O
                        ptCi->bitFlag.isInterRatHoRequiredByVonrSetupFail = VCCB_FLAG_ON;
                        ptCi->saveHoOrRedirectMsgId = msgId;

                        if(checkFallbackType == CheckType_EmergencyFallback)
                        {
                            ptCi->bitFlag.isQueueingByEmergencyCall = VCCB_FLAG_ON;
                        }
                        else
                        {
                            ptCi->bitFlag.isQueueingByEmergencyCall = VCCB_FLAG_OFF;
                        }

                        // Set PDU/QosFlow/DRB cause for VoNR Fail
                        FnVCCB_FindVoNrFailAndSetCauseRelatedBearers(ptCi,
                                                                     CauseNgapRadioNetworkLayerImsVoiceEpsFallbackOrRatFallbackTriggered);

                        return STATE_HO_QUEUEING; // Keep Going Current Operation.
                    }
                }
                else // CheckResult_Redirect
                {
                    return STATE_NEED_REDIRECTION; // Call Release with Redirection.
                }
            }
            else // CheckHoOrRedirect_OnUeReleaseState
            {
                if(GOOD != FnVCCB_DoInterRatRedirectionInFail(ptCi, VCCB_FLAG_ON, msgId))
                {
                    return STATE_IGNORE;
                }
                return STATE_REDIRECTION_IS_TRIGGERED; // Redirection is Triggered.
            }
        }
        else
        {
            // No Frequency, So Keep going on.
            return STATE_IGNORE;
        }
    }
    else if(TRUE == FnVCCB_CheckSpecificSliceFail_InterRatHoOrRedirection(ptCi, checkState, checkResult))
    {
        // Check IRAT Redirection Condition
        if(checkState == CheckHoOrRedirect_OnPartialState)
        {
            if(checkResult == CheckResult_Ho)
            {
                // Enqueue Action
                if (ERROR == VCCM_enqueueActionWithForce(ptCi, ENQUEUE_ACTION_SPECIFIC_SLICE_FORCED_MOBILITY, true))
                {
                    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "VCCM_enqueueActionWithForce(ENQUEUE_ACTION_SPECIFIC_SLICE_FORCED_MOBILITY) fail\n");
                    return STATE_NEED_REDIRECTION; // Call Release with Redirection.
                }
                else
                {
                    ptCi->qInfo.qMsgId = msgId; // need to msgId when do redirection if HO Condition is NOT meet.
                    // No Special Cause for Specific Slice...

                    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "VCCM_enqueueActionWithForce(ENQUEUE_ACTION_SPECIFIC_SLICE_FORCED_MOBILITY) msgId(%d)\n", msgId);
                    return STATE_HO_QUEUEING; // Keep Googing Current Operation.
                }
            }
            else // CheckResult_Redirect.. But No Case in CheckHoOrRedirect_OnPartialState.
            {
                return STATE_NEED_REDIRECTION; // Call Release with Redirection.
            }
        }
        else // CheckHoOrRedirect_OnUeReleaseState
        {
            if(TRUE == FnVCCB_CheckInterRatRedirectionPossibleInFail(ptCi, CheckType_SpecificSliceFallback, checkState, checkResult))
            {
                if(GOOD != FnVCCB_DoInterRatRedirectionInFail(ptCi, VCCB_FLAG_OFF, msgId))
                {
                    return STATE_IGNORE;
                }
                return STATE_REDIRECTION_IS_TRIGGERED; // Redirection is Triggered.
            }
            else // No Redirection Frequency --> Call Release.
            {
                return STATE_NEED_REDIRECTION;
            }
        }

        return STATE_IGNORE;
    }
    return STATE_IGNORE;
}
/**
 *  @brief This function is used to check and set voiceFallbackIndicator
 */
void FnVCCB_CheckAndSetVoiceFallbackIndicator(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // (UE Capa Support) && (5qi=1 is requested)
    // ==> Should be set voiceFallbackIndicator

    // 1. Check UE Capa
    if (ptCi->ueInfo.ueCapa.nr.imsParam.voiceFallbackIndicationEPS_r16 != TRUE)
    {
        return;
    }

    // 2. Check Requested 5QI(==1)
    uint8_t checkResult = CheckResult_NoCondition;
    if (TRUE == FnVCCB_IsSetupOrModifyFailOnVonr(ptCi, CheckHoOrRedirect_OnUeReleaseState, checkResult))
    {
        // Set voiceFallbackIndicator
        ptCi->redirectionInfo.voiceFallbackIndicator = TRUE;
    }

    return;
}

int16_t FnVCCB_ExistSNTermBearerToBeSetupInCall(
    callInfo_type *ptCi, uint8_t needAMBearerCheck, uint8_t needSplitBearerCheck)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    uint16_t drbIndex;
    callDRBInfo_type *ptDi = NULL;

    // Currently, no use case in MN
    if (!IS_NRDC_SN(ptCi))
    {
        return FALSE;
    }

    for (drbIndex = 0; drbIndex < MAX_DRB_PER_SA_CALL; drbIndex++)
    {
        bool isContinue = false;

        ptDi = &ptCi->drb[drbIndex];

        if (ptDi->usage != CI_use) continue;
        if (!ptDi->selectedBearerTypeFrozenFlag) continue;

        if (ptDi->bearerType.termPoint != TermPoint_Sn) continue;
        if ((needSplitBearerCheck == TRUE) && (ptDi->bearerType.val != SN_Term_SPLIT_Bearer)) continue;

        switch (ptDi->drbStatus)
        {
            case S_Setup:
            case S_Modify:
                if (ptDi->firstReqStatusInThisProcedure != S_Setup)
                {
                    isContinue = true;
                }
                break;

            default:
                if (VHCM_isSaHandoverUE(ptCi) == FALSE)
                {
                    isContinue = true;
                }
                break;
        }

        if (isContinue == true) continue;

        if ((needAMBearerCheck == TRUE) && (ptDi->rbInfo.rlcMode != AM_RLC)) continue;

        return TRUE;
    }

    return FALSE;
}

int16_t FnVCCB_ExistSNTermBearerToBeReleaseInCall(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    uint16_t drbIndex;
    callDRBInfo_type *ptDi = NULL;

    // Currently, no use case in MN
    if (!IS_NRDC_SN(ptCi))
    {
        return FALSE;
    }

    for (drbIndex = 0; drbIndex < MAX_DRB_PER_SA_CALL; drbIndex++)
    {
        ptDi = &ptCi->drb[drbIndex];

        if (ptDi->usage != CI_use) continue;
        if (!ptDi->selectedBearerTypeFrozenFlag) continue;
        if (ptDi->drbStatus != S_Release) continue;
        if (ptDi->bearerType.termPoint != TermPoint_Sn) continue;

        return TRUE;
    }

    return FALSE;
}

int16_t FnVCCB_ExistSNTermBearerInPdu(callInfo_type *ptCi, callPDUSessInfo_type *ptPi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(ptPi);

    uint16_t drbIndexInPdu;
    callDRBInfo_type *ptDi = NULL;

    for (drbIndexInPdu = 0; drbIndexInPdu < MAX_DRB_PER_PDU_SESS; drbIndexInPdu++)
    {
        if (ptPi->usage != CI_use) continue;
        if (ptPi->drbIndex[drbIndexInPdu] >= MAX_DRB_PER_SA_CALL) continue;

        ptDi = &ptCi->drb[ptPi->drbIndex[drbIndexInPdu]];

        if (ptDi->usage != CI_use) continue;
        if (!ptDi->selectedBearerTypeFrozenFlag) continue;
        if (ptDi->bearerType.termPoint != TermPoint_Sn) continue;

        return TRUE;
    }

    return FALSE;
}

int16_t FnVCCB_ExistValidSNTermBearerInPdu(callInfo_type *ptCi, callPDUSessInfo_type *ptPi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(ptPi);

    uint16_t drbIndexInPdu;
    callDRBInfo_type *ptDi = NULL;

    for (drbIndexInPdu = 0; drbIndexInPdu < MAX_DRB_PER_PDU_SESS; drbIndexInPdu++)
    {
        if (ptPi->usage != CI_use) continue;
        if (ptPi->drbIndex[drbIndexInPdu] >= MAX_DRB_PER_SA_CALL) continue;

        ptDi = &ptCi->drb[ptPi->drbIndex[drbIndexInPdu]];

        if (ptDi->usage != CI_use) continue;
        if (!ptDi->selectedBearerTypeFrozenFlag) continue;
        if ((ptDi->drbStatus != S_Idle) && (ptDi->drbStatus != S_Setup) && (ptDi->drbStatus != S_Modify) &&
            ptDi->drbStatus != S_Null)
            continue;
        if (ptDi->bearerType.termPoint != TermPoint_Sn) continue;

        return TRUE;
    }

    return FALSE;
}

int16_t FnVCCB_ExistMNTermBearerInNrdcSN(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    uint16_t drbIndex;
    callDRBInfo_type *ptDi = NULL;

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        return FALSE;
    }

    if (!IS_NRDC_SN(ptCi))
    {
        return FALSE;
    }

    for (drbIndex = 0; drbIndex < MAX_DRB_PER_SA_CALL; drbIndex++)
    {
        ptDi = &ptCi->drb[drbIndex];

        if (ptDi->usage != CI_use) continue;
        if (!ptDi->selectedBearerTypeFrozenFlag) continue;
        if ((ptDi->drbStatus != S_Idle) && (ptDi->drbStatus != S_Setup) && (ptDi->drbStatus != S_Modify)) continue;
        if (ptDi->bearerType.termPoint != TermPoint_Mn) continue;

        return TRUE;
    }

    return FALSE;
}

/**
 *  @brief This function is used to find if Cell is inservice
 *  @param ptCi info
 *  @param cellNum cell to check service state status for
 *  @param printErrorLog print Error log in case of failure or not
 *  @return int16_t TRUE / FALSE
 */

int16_t VLIB_IsInServiceCell(callInfo_type *ptCi, uint16_t cellNum, uint16_t printErrorLog)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_VALID_CELLNUM_FALSE(cellNum);

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    if (pCell->gnbNum >= MAX_GNB_PER_SYS)  
    {
        // same as VCCB_CHECK_E_RANGE_AND_FALSE(CELLINFO[cellNum].gnbNum, MAX_GNB_PER_SYS) but not printing error log.
        if (printErrorLog)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "CELLINFO[%u].gnbNum is out of range (%d:%d)\n",
                cellNum, pCell->gnbNum, MAX_GNB_PER_SYS);
        }
        return FALSE;
    }

    uint32_t gnbNum = pCell->gnbNum;
    int16_t isInServiceCell = TRUE;
    const VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    if ((pCell->pldState != EQUIP) || (pCell->serviceState != CELL_INS))
    {
        // Cell is not equipped: Recovery Target
        if (MAX_CALL_THREAD_NUM_VCCB > ptCi->myThreadId)
        {
            THREAD_INFO->call[ptCi->myThreadId].failedPCIInfoForRecovery.failedDueToRecoveryTargetParam = TRUE;
        }
        isInServiceCell = FALSE;
    }

    if (pGnb->pldActivationState != EQUIP)
    {
        isInServiceCell = FALSE;
    }

    if (IS_REDCAP_UE(ptCi) && (E_CALLTYPE_SA == ptCi->callType) &&
        (FALSE == pCell->redcapBroadcastUsage))
    {
        isInServiceCell = FALSE;

        if ((Idle_cmd == ptCi->stateCmd) && (STATE_II == ptCi->state))
        {
            ptCi->redCapUeInfo.isAttachFailedByRedCap = TRUE;
        }
    }

    if (FALSE == isInServiceCell)
    {
        if (E_CALLTYPE_NSA == ptCi->callType)
        {
            ptCi->bitFlag.spCellSelCellBarredWithSwitchOff = TRUE;
        }

        if (printErrorLog)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "CellNum(%u) is Out-Of-Service!!\n", cellNum);
            VCCB_PRINT_CALL_ERROR(ptCi, "(status:%u, pldState:%u, serviceState:%s, pldActivationState:%u, redcapBroadcastUsage:%u)\n",
                pCell->status, pCell->pldState, (pCell->serviceState == CELL_INS ? "INS" : "OOS"),
                pGnb->pldActivationState, pCell->redcapBroadcastUsage);
        }
    }
    return isInServiceCell;
}

/**
 * @brief Internal implementation of VLIB_IsCellBarred.
 *        VLIB_IsCellBarred should be used by client code.
 *        Returns TRUE if given cell status is barred.
 *
 * @param call info
 * @param cellNum cell to check barring status for
 * @return int16_t ERROR / TRUE / FALSE
 */
int16_t VLIB_Internal_IsCellBarred(callInfo_type &call, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    const auto &cell = CELLINFO[cellNum];
    const auto gnbNum = cell.gnbNum;
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
    const auto &gnb = GNBINFO[gnbNum];

    int16_t isCellBarred = FALSE;

    if (TRUE == gnb.pldGnbBarringInfo.overload)
    {
        isCellBarred = TRUE;
    }
    // FGR-CC5001 FR501 & FGR-CC5000 FR3530 - only check MIB barred (and all above) if cell supports SA and NSA.
    if (VCCB_IsEndcSn(call) && VCCB_IsCellSaReady(cell) && (TRUE == gnb.cfg.endcAddWithSwitchingOffCells))
    {
        if (NRRRC_barred == cell.mib.cellBarred)
        {
            isCellBarred = TRUE;
            call.bitFlag.spCellSelCellBarredWithSwitchOff = TRUE;
        }
        return isCellBarred;
    }

    if (E_CALLTYPE_SA == call.callType && VCCB_IsCellSaReady(cell)) // SA CELL
    {
        if (TRUE == gnb.pldGnbBarringInfo.shuttingDown || TRUE == cell.switchingOffOngoing)
        {
            VCCB_PRINT_CALL_INFORMATIVE(&call, "skip checking shuttingDown(%d) and switchOffOngoing(%d)\n",
                gnb.pldGnbBarringInfo.shuttingDown, cell.switchingOffOngoing);
        }
    }
    else // NSA CELL
    {
        if (TRUE == gnb.pldGnbBarringInfo.shuttingDown)
        {
            isCellBarred = TRUE;
        }
        if (TRUE == cell.switchingOffOngoing)
        {
            isCellBarred = TRUE;
        }
    }

    if (TRUE == cell.switchingOffOngoing)
    {
        // switchingOffOngoing is TRUE: Recovery Target
        if (MAX_CALL_THREAD_NUM_VCCB > call.myThreadId)
        {
            THREAD_INFO->call[call.myThreadId].failedPCIInfoForRecovery.failedDueToRecoveryTargetParam = TRUE;
        }
        if ((VCCB_IsEndcSn(call) && !VCCB_IsCellSaReady(cell)) || (FALSE == gnb.cfg.endcAddWithSwitchingOffCells))
        {
            // NSA only cell or EN-DC Addition after switchOff for SA&NSA cells is off.
            call.bitFlag.spCellSelCellBarredWithSwitchOff = TRUE;
        }
    }

    // Additional Cond. for SA call
    if (E_CALLTYPE_SA == call.callType)
    {
        if (IS_NRDC_SN(&call))
        {
            // This condition is true when SgNB addition procedure(include HO) and SgNB is barred because all UPs of
            // SgNB are in the overload state.
            if ((GET_SGNB_ADD_REQ_FLAG(call.flag.setupFlag)) && (FALSE == gnb.pldGnbBarringInfo.shuttingDown) &&
                (TRUE == gnb.pldGnbBarringInfo.overload) && (FALSE == cell.switchingOffOngoing))
            {
                // In this case, call release cause is determined in the UP selection procedure.
                isCellBarred = FALSE;
            }
        }
        else
        {
            if (TRUE == gnb.pldGnbBarringInfo.amfNotAvailable)
            {
                isCellBarred = TRUE;
            }
            if (NRRRC_barred == cell.mib.cellBarred)
            {
                isCellBarred = TRUE;
            }
            if ((TRUE == cell.sib1.cellReservedForOtherUseFlag) && (NRRRC_true == cell.sib1.cellReservedForOtherUse))
            {
                isCellBarred = TRUE;
            }
            if ((TRUE == cell.sib1.cellReservedForFutureUseFlag) && (NRRRC_true == cell.sib1.cellReservedForFutureUse))
            {
                isCellBarred = TRUE;
            }
        }

        if (IS_REDCAP_UE(&call) && (TRUE == cell.redcapBroadcastUsage) && (FALSE == cell.redcapBroadcastState))
        {
            isCellBarred = TRUE;

            if ((Idle_cmd == call.stateCmd) && (STATE_II == call.state))
            {
                call.redCapUeInfo.isAttachFailedByRedCap = TRUE;
            }
        }
    }

    return isCellBarred;
}

/**
 * @brief This function is a wrapper for VLIB_Internal_IsCellBarred.
 *        It checks and returns cell barring status.
 *        It logs detailed cell barring status if printErrorLog is set TRUE.
 *
 * @param ptCi call info
 * @param cellNum cell to check barring status for
 * @param printErrorLog print detailed cell barring status if set TRUE
 * @return int16_t ERROR / TRUE / FALSE
 */
int16_t VLIB_IsCellBarred(callInfo_type *ptCi, uint16_t cellNum, uint16_t printErrorLog)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    const auto &cell = CELLINFO[cellNum];
    const auto gnbNum = cell.gnbNum;
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
    const auto &gnb = GNBINFO[gnbNum];

    const auto isCellBarred = VLIB_Internal_IsCellBarred(*ptCi, cellNum);
    if (TRUE == isCellBarred)
    {
        if (TRUE == VHCM_isSaHandoverUE(ptCi))
        {
            ptCi->cause.xnCause = CauseXnapMiscOMIntervention;
            ptCi->cause.ngCause = CauseNgapMiscOMIntervention;
        }
        if (printErrorLog)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "CellNum(%u) is Barred!! (shuttingDown:%u, overload:%u, switchingOffOngoing:%u, "
                "MibCellBarred(%s))\n", cellNum, gnb.pldGnbBarringInfo.shuttingDown,
                gnb.pldGnbBarringInfo.overload, cell.switchingOffOngoing,
                (NRRRC_barred == cell.mib.cellBarred) ? "Barred" : "notBarred");

            if (E_CALLTYPE_SA == ptCi->callType)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "+ Add Check SA Only Barred Parameter\n");
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "(amfNotAvailable:%u,  cellReservedForOtherUse:%u/%u, cellReservedForFutureUse:%u/%u,\n",
                    gnb.pldGnbBarringInfo.amfNotAvailable, cell.sib1.cellReservedForOtherUseFlag,
                    cell.sib1.cellReservedForOtherUse, cell.sib1.cellReservedForFutureUseFlag,
                    cell.sib1.cellReservedForFutureUse);
                VCCB_PRINT_CALL_ERROR(ptCi, "isRedCapUE:%u, redcapBroadcast:%u/%u)\n", IS_REDCAP_UE(ptCi),
                    cell.redcapBroadcastUsage, cell.redcapBroadcastState);
            }
        }
    }

    return isCellBarred;
}

uint16_t FnVCCB_GetPDUSessIndexFromPDUSessID(callInfo_type *ptCi, uint16_t pduSessId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_PDU_SESS_PER_CALL);

    uint8_t idx = 0;
    for (idx = 0; idx < MAX_PDU_SESS_PER_CALL; idx++)
    {
        if (ptCi->pduSess[idx].usage == CI_no_use) continue;
        if (ptCi->pduSess[idx].pduSessId == pduSessId)
        {
            return idx;
        }
    }

    return MAX_PDU_SESS_PER_CALL;
}

int16_t FnVCCB_GetDRBIndexFromDRBId(callInfo_type *ptCi, uint8_t drbId, uint8_t *pDrbIndex)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDrbIndex);

    *pDrbIndex = MAX_DRB_PER_SA_CALL;

    uint8_t idx = 0;
    for (idx = 0; idx < MAX_DRB_PER_SA_CALL; idx++)
    {
        if (ptCi->drb[idx].usage == CI_no_use) continue;
        if (ptCi->drb[idx].dRBId == drbId)
        {
            *pDrbIndex = idx;
            return GOOD;
        }
    }

    return ERROR;
}

int16_t FnVCCB_IsSameTwoTransportLayerInfo(transportLayerInfo_type *pS1, transportLayerInfo_type *pS2)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pS1);
    VALID_E_POINT_CHECK_ERROR(pS2);

    if (pS1->TEID != pS2->TEID)
    {
        return ERROR;
    }

    if (pS1->numTLAbit != pS2->numTLAbit)
    {
        return ERROR;
    }

    uint32_t idx = 0, maxIdx = UMIN((uint32_t)MAX_TLA_BYTE, ((pS1->numTLAbit + 7U) / 8U));

    for (idx = 0; idx < maxIdx; idx++)
    {
        if (pS1->TLAddr[idx] != pS2->TLAddr[idx])
        {
            return ERROR;
        }
    }

    return GOOD;
}

void VLIB_CreateRedirectionInfoNrFromMeasObjectDb(
    redirectionInfoNr_type *pOutput, const measurementObjectNRBaseDb_type *pObj)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pOutput);
    VALID_E_POINT_CHECK_VOID(pObj);

    pOutput->ssbFrequency = pObj->ssbFrequency;
    pOutput->ssbSubcarrierSpacing = static_cast<enumSubcarrierSpacing>(pObj->ssbSubcarrierSpacing);
    pOutput->smtc1 = pObj->smtc1;
}

void VLIB_CreateRedirectionInfoNrFromMeasObjectUe(
    redirectionInfoNr_type *pOutput, const measurementObjectNRUe_type *pObj)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pOutput);
    VALID_E_POINT_CHECK_VOID(pObj);

    pOutput->ssbFrequency = pObj->minimal.ssbFrequency;
    pOutput->ssbSubcarrierSpacing = static_cast<enumSubcarrierSpacing>(pObj->minimal.ssbSubcarrierSpacing);
    pOutput->smtc1 = pObj->minimal.smtc1;
}

void VLIB_CreateRedirectionInfoEutraFromMeasObjectDb(
    redirectionInfoEutra_type *pOutput, const measurementObjectEUTRABaseDb_type *pObj, uint32_t overlappedCarrierFreq)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pOutput);
    VALID_E_POINT_CHECK_VOID(pObj);

    pOutput->carrierFreq = pObj->carrierFreq;
    pOutput->overlappedCarrierFreq = overlappedCarrierFreq;
}

void VLIB_CreateRedirectionInfoEutraFromMeasObjectUe(
    redirectionInfoEutra_type *pOutput, const measurementObjectEUTRAUe_type *pObj)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pOutput);
    VALID_E_POINT_CHECK_VOID(pObj);

    pOutput->carrierFreq = pObj->minimal.carrierFreq;
    pOutput->overlappedCarrierFreq = pObj->minimal.overlappedCarrierFreq;
}

int16_t FnVCCB_CheckDuplicatedPDUSessionID(NGAP_PDUSessionResourceSetupListCxtReq_type *ptList)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptList);

    int count[MAX_PDU_SESS_ID_3GPP + 1] = {
        0,
    };

    unsigned short loop1;
    uint8_t pduSessId = 0;

    for (loop1 = 0; loop1 < ptList->n && loop1 < NG_MaxnoofPDUSessions; loop1++)
    {
        pduSessId = (uint8_t)ptList->pDUSessionResourceSetupItemCtxReq[loop1].pDUSessionID;
        if (count[pduSessId] > 0)
        {
            // Duplicated item found.
            return ERROR;
        }
        count[pduSessId]++;
    }

    return GOOD;
}

int16_t FnVCCB_IsCallToBackup(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    int16_t isCallToBackup = FALSE;

    if (ptCi->stateCmd != Idle_cmd)
    {
        return FALSE;
    }

    if (E_CALLTYPE_SA == ptCi->callType)
    {
        switch (ptCi->state)
        {
            case STATE_Conn:
            case STATE_Inact_Suspend:
                isCallToBackup = TRUE;
                break;

            default:
                break;
        }
    }
    else  // E_CALLTYPE_NSA
    {
        switch (ptCi->state)
        {
            case STATE_DB:
                isCallToBackup = TRUE;
                break;

            default:
                break;
        }
    }

    return isCallToBackup;
}

bool FnVCCB_IsSetupOrModify(uint8_t brStatus)
{
    AUTO_TRACE_FUNC;

    switch (brStatus)
    {
        case S_Setup:
        case S_Modify:
            return true;

        default:
            return false;
    }
}

callPDUSessInfo_type *FnVCCB_FindCallPduInfo_FromPduSessId(
    callInfo_type *ptCi, const uint8_t pduSessionId, uint16_t *pPduIdx /*optional*/)
{
    uint16_t pduIdx = 0;
    callPDUSessInfo_type *ptPi = NULL;

    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptCi);
    // VALID_E_POINT_CHECK_NULL(pPduIdx); - not check

    if (pPduIdx) *pPduIdx = pduIdx;

    for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        ptPi = &ptCi->pduSess[pduIdx];

        if (!IS_VALID_NODE(PDU_NODE, ptCi, ptPi)) continue;  // Include Check ptPi->usage

        if (ptPi->pduSessId == pduSessionId)
        {
            if (pPduIdx) *pPduIdx = pduIdx;

            return ptPi;
        }
    }

    return NULL;
}

// This function gets the structure address of the Call Pdu by using the PDU Session Id.
callDRBInfo_type *FnVCCB_FindCallDrbInfo_FromDrbId(
    callInfo_type *ptCi, const uint8_t drbId, uint16_t *pDrbIdx /*optional*/)
{
    uint16_t drbIdx = 0;
    callDRBInfo_type *ptDi = NULL;

    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptCi);
    // VALID_E_POINT_CHECK_NULL(pDrbIdx); - not check

    if (pDrbIdx) *pDrbIdx = MAX_DRB_PER_SA_CALL;

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        ptDi = &ptCi->drb[drbIdx];

        if (!IS_VALID_NODE(DRB_NODE, ptCi, ptDi)) continue;  // Include Check ptDi->usage

        if (ptDi->dRBId == drbId)
        {
            if (pDrbIdx) *pDrbIdx = drbIdx;

            return ptDi;
        }
    }

    return NULL;
}

int16_t FnVCCB_BackupCallRestrictInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    if (NULL == ptCi)
    {
        VCCB_PRINT_ERROR("%s: NULL pointer \n", __FUNCTION__);
        return ERROR;
    }

    unsigned long unsynced, dynamicSize;
    int ret;
    unsigned long forbiddenTASize;

    // STEP 1. Fixed Size Backup
    int hasKey = FnVCCB_GetHasKeyByCallId(ptCi->callId);
    if (hasKey < 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetHasKeyByCallId ERROR(%d) in %s\n", hasKey, __FUNCTION__);
        return ERROR;
    }

    unsynced = (char *)(&ptCi->hoRestrict.forbiddenTA) - (char *)&ptCi->hoRestrict;
    if (E_CALLTYPE_SA == ptCi->callType)
    {
        forbiddenTASize = sizeof(forbidden5gTACompressed_type);
    }
    else
    {
        forbiddenTASize = sizeof(forbiddenTACompressed_type);
    }
    dynamicSize = UMIN(ptCi->hoRestrict.numForbidTaPlmn, X2_maxnoofEPLMNsPlusOne) * forbiddenTASize;
    unsynced += dynamicSize;

    ret = FnVCCB_SyncData(ptCi->myThreadId, unsynced, (char *)ptCi, hasKey);
    if (ERROR == ret)
    {
        VCCB_PRINT_CALL_CRITICAL(ptCi, "%s: STEP1 : hasDirectSync Failed(%d)\n", __FUNCTION__, ret);
    }
    return GOOD;
}

void FnVCCB_BackupCallLocRpt(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    unsigned long unsynced = (char *)(&ptCi->locRpt.areaofInterest.aoI[0]) - (char *)(&ptCi->locRpt);
    unsigned long dynamicSize = ((UMIN(ptCi->locRpt.areaofInterest.noofAoI, NG_MaxnoofAoI)) * sizeof(locRptAoIItem_type));
    unsynced += dynamicSize;
    HAS_BACKUP_DATA_CALL_PARTIAL(ptCi, &ptCi->locRpt, unsynced);
    return;
}

void FnVCCB_BackupE1InactivityInfo(callInfo_type *ptCi, uint8_t drbFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (e_VCCB_ACPF_VNF == VCOM_getSystemType())
    {
        if (ptCi->stateCmd == Idle_cmd &&
            (ptCi->state == STATE_DB || ptCi->state == STATE_Conn || ptCi->state == STATE_Inact_Suspend))
        {
            HAS_BACKUP_DATA_CALL_PARTIAL(ptCi, &ptCi->CallUserInactivity, sizeof(ptCi->CallUserInactivity));

            if (IS_SUPPORT_RRC_INACTIVE(ptCi))
            {
                HAS_BACKUP_DATA_CALL_PARTIAL(ptCi, &ptCi->ueInfo, sizeof(ptCi->ueInfo));
                HAS_BACKUP_DATA_CALL_PARTIAL(ptCi, &ptCi->bitFlag, sizeof(ptCi->bitFlag));
            }

            if (drbFlag)
            {
                if (ptCi->callType == E_CALLTYPE_NSA)
                {
                    HAS_BACKUP_DATA_CALL_PARTIAL(ptCi, &ptCi->erabInfo, sizeof(ptCi->erabInfo));
                }
                else  // SA
                {
                    HAS_BACKUP_DATA_CALL_PARTIAL(ptCi, &ptCi->drb, sizeof(ptCi->drb));
                }
            }
            else
            {
                HAS_BACKUP_DATA_CALL_PARTIAL(ptCi, &ptCi->activityStatus, sizeof(ptCi->activityStatus));
                HAS_BACKUP_DATA_CALL_PARTIAL(ptCi, &ptCi->endPointInfo.aupf, sizeof(ptCi->endPointInfo.aupf));
            }
            ptCi->needBackupAfterStateAll = VCCB_FLAG_OFF;
        }
    }
    return;
}

void FnVCCB_ConvertUndefinedCRR(callInfo_type *ptCi, uint16_t *pCause)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pCause);

    pmCause_t pmCause = 0;
    nr_csl_cause_error_e pmResult = NR_CSL_CAUSE_ERROR_MAX;
    uint16_t causeOrg = *pCause;

    if (ptCi->callType == E_CALLTYPE_SA)
    {
        pmResult = nr_csl_cause_get_sacp_pmCause(*pCause, &pmCause);
    }
    else  // NSA EN-DC
    {
        pmResult = nr_csl_cause_get_cp_pmCause(*pCause, &pmCause);
    }

    // if 'cause' is not defined in PM, convert it to 'unspecified' for each cause layer
    if (NR_CSL_CAUSE_ERROR_NONE != pmResult)
    {
        switch (*pCause)
        {
            /* X2 */
            case CAUSE_BASE_X2AP_RADIONETWORK ... CauseX2apRadioNetworkLayerEnd:
                *pCause = CauseX2apRadioNetworkLayerUnspecified;
                break;
            case CAUSE_BASE_X2AP_TRANSPORT ... CauseX2apTransportNetworkLayerEnd:
                *pCause = CauseX2apTransportNetworkLayerUnspecified;
                break;
            case CAUSE_BASE_X2AP_PROTOCOL ... CauseX2apProtocolEnd:
                *pCause = CauseX2apProtocolUnspecified;
                break;
            case CAUSE_BASE_X2AP_MISC ... CauseX2apMiscEnd:
                *pCause = CauseX2apMiscUnspecified;
                break;

            /* F1 */
            case CAUSE_BASE_F1AP_RADIONETWORK ... CauseF1apRadioEnd:
                *pCause = CauseF1apRadioUnspecified;
                break;
            case CAUSE_BASE_F1AP_TRANSPORT ... CauseF1apTransportEnd:
                *pCause = CauseF1apTransportUnspecified;
                break;
            case CAUSE_BASE_F1AP_PROTOCOL ... CauseF1apProtocolEnd:
                *pCause = CauseF1apProtocolUnspecified;
                break;
            case CAUSE_BASE_F1AP_MISC ... CauseF1apMiscEnd:
                *pCause = CauseF1apMiscEnd;
                break;

            /* E1 */
            case CAUSE_BASE_E1AP_RADIONETWORK ... CauseE1apRadioNetworkLayerEnd:
                *pCause = CauseE1apRadioNetworkLayerUnspecified;
                break;
            case CAUSE_BASE_E1AP_TRANSPORT ... CauseE1apTransportLayerEnd:
                *pCause = CauseE1apTransportLayerUnspecified;
                break;
            case CAUSE_BASE_E1AP_PROTOCOL ... CauseE1apProtocolEnd:
                *pCause = CauseE1apProtocolUnspecified;
                break;
            case CAUSE_BASE_E1AP_MISC ... CauseE1apMiscEnd:
                *pCause = CauseE1apMiscUnspecified;
                break;

            /* NG */
            case CAUSE_BASE_NGAP_RADIONETWORK ... CauseNgapRadioNetworkLayerEnd:
                *pCause = CauseNgapRadioNetworkLayerUnspecified;
                break;
            case CAUSE_BASE_NGAP_TRANSPORT ... CauseNgapTransportLayerEnd:
                *pCause = CauseNgapTransportLayerUnspecified;
                break;
            case CAUSE_BASE_NGAP_NAS ... CauseNgapNasEnd:
                *pCause = CauseNgapNasUnspecified;
                break;
            case CAUSE_BASE_NGAP_PROTOCOL ... CauseNgapProtocolEnd:
                *pCause = CauseNgapProtocolUnspecified;
                break;
            case CAUSE_BASE_NGAP_MISC ... CauseNgapMiscEnd:
                *pCause = CauseNgapMiscUnspecifiedFailure;
                break;

            /* XN */
            case CAUSE_BASE_XNAP_RADIONETWORK ... CauseXnapRadioNetworkLayerEnd:
                *pCause = CauseXnapRadioNetworkLayerUnspecified;
                break;
            case CAUSE_BASE_XNAP_TRANSPORT ... CauseXnapTransportLayerEnd:
                *pCause = CauseXnapTransportLayerUnspecified;
                break;
            case CAUSE_BASE_XNAP_PROTOCOL ... CauseXnapProtocolEnd:
                *pCause = CauseXnapProtocolUnspecified;
                break;
            case CAUSE_BASE_XNAP_MISC ... CauseXnapMiscEnd:
                *pCause = CauseXnapMiscUnspecified;
                break;

            default:
                break;
        }
    }

    if (causeOrg != *pCause)  // conversion is occurred
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Undefined CRR(%d) is converted to CRR(%d)\n", causeOrg, *pCause);
    }

    return;
}

/**
 * @brief fill F1 Cause
 *
 * @param [in] f1Cause  :
 * @param [in] ptCause  :
 * @return GOOD
 * @return ERROR
 */
void FnVCCB_fillF1_Cause(uint16_t f1Cause, F1_Cause *ptCause)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCause);

    switch (f1Cause)
    {
        case CAUSE_BASE_F1AP_RADIONETWORK ...(CauseF1apRadioEnd - 1):
            ptCause->choice = F1_radioNetwork_chosen;
            ptCause->u.radioNetwork = (F1_CauseRadioNetwork)(f1Cause - CAUSE_BASE_F1AP_RADIONETWORK);
            break;
        case CAUSE_BASE_F1AP_TRANSPORT ...(CauseF1apTransportEnd - 1):
            ptCause->choice = F1_transport_chosen;
            ptCause->u.transport = (F1_CauseTransport)(f1Cause - CAUSE_BASE_F1AP_TRANSPORT);
            break;
        case CAUSE_BASE_F1AP_PROTOCOL ...(CauseF1apProtocolEnd - 1):
            ptCause->choice = F1_protocol_chosen;
            ptCause->u.protocol = (F1_CauseProtocol)(f1Cause - CAUSE_BASE_F1AP_PROTOCOL);
            break;
        case CAUSE_BASE_F1AP_MISC ...(CauseF1apMiscEnd - 1):
            ptCause->choice = F1_misc_chosen;
            ptCause->u.misc = (F1_CauseMisc)(f1Cause - CAUSE_BASE_F1AP_MISC);
            break;
        default:
            // In case of No F1 Cause, Set default value
            ptCause->choice = F1_misc_chosen;
            ptCause->u.misc = (F1_CauseMisc)(CauseF1apMiscUnspecifiedFailure - CAUSE_BASE_F1AP_MISC);
            VCCB_PRINT_ERROR("Invalid F1 Cause value(%d), so set MiscUnspecifiedFailure !!\n", f1Cause);
            break;
    }
}

uint8_t FnVCCB_isAlreadyExist_inGnbBand(gnbSupportedBandInfo_type *pBandList, uint16_t value)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(pBandList);

    uint32_t loop;
    uint32_t maxBandIdx = UMIN(pBandList->num, (uint16_t)MAX_FREQBAND_FILTER);

    for (loop = 0; loop < maxBandIdx; loop++)
    {
        // Do not write if new Band Configuration is existed in GNB Band Freq List.
        if (pBandList->nrFreqBand[loop] == value)
        {
            return TRUE;
        }
    }
    return FALSE;
}

void FnVCCB_UpdateGnbSupportedBandList(uint16_t cellNum, uint8_t gnbNum, cellBand_changedInfo_type *pChgInfo)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    VALID_E_POINT_CHECK_VOID(pChgInfo);

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    uint16_t delIdx, addIdx, loop, cellIdx;
    uint16_t findFlag = 0, changeFlag = 0;
    uint16_t deletedBand = 0;

    gnbSupportedBandInfo_type *pGnbLocal = &pGnb->supportedFreqBandInfo;

    // Del List (Should be handled before Add List)
    if (pChgInfo->numDel > 0)
    {
        for (delIdx = 0; delIdx < MAX_NR_CELL_FREQ_BAND_LIST; delIdx++)
        {
            if (pChgInfo->delFreqBandStatus[delIdx] != VCCB_FLAG_ON) continue;

            deletedBand = pChgInfo->delFreqBandInfo[delIdx];

            // 1. Find 'deletedBand' among all cell.
            findFlag = 0;
            for (cellIdx = 0; cellIdx < MAX_CELL_NUM_VCCB; cellIdx++)
            {
                if (cellIdx == cellNum) continue;  // skip my cell

                VccbCellInfo_type *const pCell = &CELLINFO[cellIdx];

                if (pCell->gnbNum != gnbNum) continue;
                if (pCell->pldState != EQUIP) continue;

                for (loop = 0; loop < MAX_NR_CELL_FREQ_BAND_LIST; loop++)
                {
                    if (pCell->freqBandInfoList[loop].status != EQUIP) continue;
                    if (pCell->freqBandInfoList[loop].nRFrequencyBand == 0) continue;
                    if (pCell->freqBandInfoList[loop].nRFrequencyBand > MAX_NUM_NR_BAND) continue;

                    // 'deletedBand' is also existed in other cell of gNB.
                    // Do not delete in gNB Band List.
                    if (pCell->freqBandInfoList[loop].nRFrequencyBand == deletedBand)
                    {
                        findFlag++;
                        break;
                    }
                }

                if (findFlag) break;
            }

            // Not Exist in All Cell, then remove
            if (findFlag == 0)
            {
                // Delete 'deletedBand' In gNB List
                uint32_t maxBandIdx = UMIN(pGnbLocal->num, (uint16_t)MAX_FREQBAND_FILTER);
                for (loop = 0; loop < maxBandIdx; loop++)
                {
                    if (pGnbLocal->nrFreqBand[loop] == 0) continue;
                    // If exists, set the value as 0.
                    if (pGnbLocal->nrFreqBand[loop] == deletedBand)
                    {
                        pGnbLocal->nrFreqBand[loop] = pGnbLocal->nrFreqBand[pGnbLocal->num - 1];
                        pGnbLocal->nrFreqBand[pGnbLocal->num - 1] = 0;
                        pGnbLocal->num--;
                        changeFlag++;
                        break;
                    }
                }
            }
        }
    }

    if (pChgInfo->numAddMod > 0)
    {
        // Add List
        for (addIdx = 0; addIdx < pChgInfo->numAddMod; addIdx++)
        {
            if (pGnbLocal->num >= MAX_FREQBAND_FILTER)
            {
                VCCB_PRINT_ERROR(
                    "GNB[%d] SupportedBandInfoList is Full. (MAX_FREQBAND_FILTER : %d)\n", gnbNum, MAX_FREQBAND_FILTER);
                break;
            }

            if (FnVCCB_isAlreadyExist_inGnbBand(pGnbLocal, pChgInfo->addModFreqBandInfo[addIdx]) == TRUE) continue;

            // Not Exist, then Add item at the end of the list.
            pGnbLocal->nrFreqBand[pGnbLocal->num++] = pChgInfo->addModFreqBandInfo[addIdx];
            changeFlag++;
        }
    }

    // If Changed, then backup.
    if (changeFlag)
    {
#ifdef __CNF__
        FnVCCB_RedisUpdateGnbInfoFlagOn(gnbNum);
#else
        HAS_BACKUP_DATA_PER_GNB(
            gnbNum, VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_0, pGnbLocal, sizeof(gnbSupportedBandInfo_type));
#endif
    }
}

void FnVCCB_UpdateGnbSupportBand_byCellPLDUpdate(
    uint16_t cellNum, uint8_t gnbNum, const PLDCellStatus *pNewPld, enumCellPldUpdateOption_type pldUpdateOption)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VALID_E_POINT_CHECK_VOID(pNewPld);

    VccbCellInfo_type *pOldPld = &CELLINFO[cellNum];

    uint16_t loop, loop2;
    uint16_t newBand = 0;
    uint16_t oldBand = 0;

    int findFlag = FALSE;
    uint8_t numAddMod = 0;
    uint8_t numDel = 0;
    cellBand_changedInfo_type chgInfo;
    memset(&chgInfo, 0, sizeof(cellBand_changedInfo_type));

    switch (pldUpdateOption)
    {
        case CELLPLD_UPDATE:
        {
            // Make Changed Band List.

            // 1. Find Add/Mod item in New PLD List. (Not Exist in OLD PLD List.)
            for (loop = 0; loop < MAX_NR_CELL_FREQ_BAND_LIST; loop++)
            {
                if (pNewPld->nRFrequencyBand[loop] == 0) continue;
                if (pNewPld->nRFrequencyBand[loop] > MAX_NUM_NR_BAND) continue;

                newBand = pNewPld->nRFrequencyBand[loop];
                findFlag = FALSE;
                for (loop2 = 0; loop2 < MAX_FREQBAND_PER_CELL; loop2++)
                {
                    if (pOldPld->freqBandInfoList[loop2].status != EQUIP) continue;
                    if (pOldPld->freqBandInfoList[loop2].nRFrequencyBand == newBand)
                    {
                        findFlag = TRUE;
                        break;
                    }
                }

                if (findFlag == FALSE)
                {
                    // Add on Add/Mod Item List.
                    chgInfo.addModFreqBandInfo[numAddMod] = newBand;
                    numAddMod++;
                }
            }

            // 2. Find Deleted item in OLD PLD List. (Not Exist in New PLD List.)
            for (loop = 0; loop < MAX_FREQBAND_PER_CELL; loop++)
            {
                if (pOldPld->freqBandInfoList[loop].status != EQUIP) continue;
                if (pOldPld->freqBandInfoList[loop].nRFrequencyBand == 0) continue;
                if (pOldPld->freqBandInfoList[loop].nRFrequencyBand > MAX_NUM_NR_BAND) continue;

                oldBand = pOldPld->freqBandInfoList[loop].nRFrequencyBand;
                findFlag = FALSE;

                for (loop2 = 0; loop2 < MAX_NR_CELL_FREQ_BAND_LIST; loop2++)
                {
                    if (pNewPld->nRFrequencyBand[loop2] == oldBand)
                    {
                        findFlag = TRUE;
                        break;
                    }
                }

                if (findFlag == FALSE)
                {
                    // Add on Delete Item List.
                    chgInfo.delFreqBandStatus[numDel] = VCCB_FLAG_ON;
                    chgInfo.delFreqBandInfo[numDel] = oldBand;
                    numDel++;
                }
            }

            break;  // End of Case
        }

        case CELLPLD_DELETE:
        {
            // 1. Add All items in the Old List to Delete Item List.
            for (loop = 0; loop < MAX_FREQBAND_PER_CELL; loop++)
            {
                if (pOldPld->freqBandInfoList[loop].status != EQUIP) continue;
                if ((pOldPld->freqBandInfoList[loop].nRFrequencyBand == 0) ||
                    (pOldPld->freqBandInfoList[loop].nRFrequencyBand > MAX_NUM_NR_BAND))
                    continue;

                oldBand = pOldPld->freqBandInfoList[loop].nRFrequencyBand;

                // Add on Delete Item List.
                chgInfo.delFreqBandStatus[numDel] = VCCB_FLAG_ON;
                chgInfo.delFreqBandInfo[numDel] = oldBand;
                numDel++;
            }

            break;  // End of Case
        }

        default:
            break;
    }

    // If Cell Band Configuration changes, reflect the changes to gNB Support Band Configuration
    if ((numAddMod) || (numDel))
    {
        chgInfo.numAddMod = numAddMod;
        chgInfo.numDel = numDel;
        FnVCCB_UpdateGnbSupportedBandList(cellNum, gnbNum, &chgInfo);
    }
}
int FnVCCB_GetActiveUnitId(uint16_t blockType)
{
    AUTO_TRACE_FUNC;
    // uint32_t unitId = 0;
#ifdef IPC_TEST
    return 0;
#endif
    uint16_t unitType = VCOM_getUnitType(blockType);

    if (e_VCCB_ACPF_VNF == VCOM_getSystemType())
    {
        uint32_t retVnfId = 0;
        unsigned int vnfcId = 0;
        int result;
        vnfcId |= (unsigned int)(unitType << 16U);
        result = mdsGetActiveVnfcId(vnfcId, &retVnfId);
        if (result < 0)
        {
            VCCB_PRINT_ERROR("mdsGetActiveVnfcId is failed!! BlockType : %d, unitId : %d\n", blockType, /*unitId*/ 0);
            return ERROR;
        }
        retVnfId &= 0xFFFF;
        return (int)retVnfId;
    }
    else if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
    {
        int32_t retCnfId = FnVCCB_GetActivePodId(unitType);
        return retCnfId;
    }
    else if (e_VCCB_NVGNB == VCOM_getSystemType())
    {
        // In NVGNB, HA is not supported
        int32_t retCnfId = 0;
        return retCnfId;
    }

    return ERROR;
}

int16_t FnVCCB_UpdateRRCInactStateAndDoActionIfExpiry(callInfo_type *ptCi, enumRRCInactiveEvent_type event)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;
    bool sigTimerExpired = VCCB_IS_SIGNALING_TIMER_EXPIRED(ptCi);

    if (((RRCInactiveEvent_DATA_EXPIRY == event) && sigTimerExpired == true) ||
        (RRCInactiveEvent_SIGNAL_EXPIRY == event))
    {
        if (STATE_Conn == ptCi->state || STATE_Inact_Suspend == ptCi->state)
        {
            status = FnVCCB_DoInactivityActionInIdleState(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_DoInactivityActionInIdleState ERROR in %s\n", __FUNCTION__);
        }
        else
        {
            VCCB_PRINT_CALL_INFORMATIVE(
                ptCi, "[RRCInactive] Enqueued E1 Inactivity Noti Action procedure in ptCi->state(%u)/event(%u)/sigTimerExpired(%u)\n",
                ptCi->state, event, sigTimerExpired);

            if (ERROR == VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_E1_INACTIVITY_NOTI))
            {
                VCCB_PRINT_CALL_INFORMATIVE(
                    ptCi, "VCCM_enqueueAction(ENQUEUE_ACTION_E1_INACTIVITY_NOTI) in %s fail\n", __FUNCTION__);
            }
        }
    }
    else
    {
        VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "[RRCInactive] event(%u) and SIGTimer(%u/%u) => Stay in current state, and DO NOT start RRC suspend procedure!\n",
            event, ptCi->CallUserInactivity.featureEnabled, ptCi->CallUserInactivity.ueInactivityState);
    }

    return status;
}

void FnVCCB_InitMultiCarrierOperation(uint16_t gnbNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    pGnb->multiCarrierOperation.multiRatCarrierChange = FALSE;

    return;
}

void FnVCCB_RecordTime(timeRecord_type *t)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(t);
    time_t ct = time(NULL);
    localtime_r(&ct, &t->tm);
    if (ComTimeUtil::get_current_time(t->tv) < 0)
    {
        VCCB_PRINT_ERROR("ComTimeUtil::get_current_time ERROR in %s\n", __FUNCTION__);
        return;
    }
    return;
}

bool FnVCCB_IsExistActiveSNTermDrb_NrdcSN(const callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    int i;
    callDRBInfo_type *ptDi = NULL;

    if (!IS_NRDC_SN(ptCi))
    {
        return false;
    }

    for (i = 0; i < MAX_DRB_PER_SA_CALL; i++)
    {
        ptDi = (callDRBInfo_type *)&ptCi->drb[i];
        if (ptDi->usage != CI_use)
        {
            continue;
        }
        if (ptDi->bearerType.termPoint != TermPoint_Sn)
        {
            continue;
        }

        if (ptDi->activityStatus == ActivityStatus_ACTIVE)
        {
            return true;
        }
    }

    return false;
}

bool FnVCCB_CheckNeedSendActivityNotiToMN_DRBLevel_NrdcSN(const callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, false);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (!pGnb->UserInactivityNrdcSN.featureEnabled)
    {
        return false;
    }

    if (!IS_NRDC_SN(ptCi))
    {
        return false;
    }

    if (ptCi->CallUserInactivity.activityNotificationLevel != activityNotifLvl_DRB)
    {
        return false;
    }

    bool isActiveSNTermBearerExist = FnVCCB_IsExistActiveSNTermDrb_NrdcSN(ptCi);
    enumActivityStatus_type prevReport = ptCi->CallUserInactivity.ueLevelActivityReportSentToMN;

    if (((prevReport == ActivityStatus_ACTIVE) && (isActiveSNTermBearerExist == false)) ||
        ((prevReport == ActivityStatus_INACTIVE) && (isActiveSNTermBearerExist == true)))
    {
        return true;
    }

    return false;
}

/****************************************************************************
 * @brief       convert timeInfo struct into BCD representation (each number as nibble)
 *
 * @param[in]    pTimeInfo:     pointer to vccbTimeInfo_type object
 * @param[in]    len:           size of input buffer (pBcdTime)
 *                              size=1 (YY), =2(YYMM), =3 (YYMMDD), =4 (YYMMDDHH), =5 (YYMMDDHHmm) =6 (YYMMDDHHmmss)
 * @param[out]   pBcdTime:      pointer to buffer for converted representation
 * @return       status:        GOOD, ERROR
 ****************************************************************************/
int16_t FnVCCB_TimeToBCD(const vccbTimeInfo_type *const pTimeInfo, uint8_t *const pBcdTime, uint8_t len)
{
    VALID_E_POINT_CHECK_ERROR(pTimeInfo);
    VALID_E_POINT_CHECK_ERROR(pBcdTime);

    uint8_t year = 0;

    switch (len)
    {
        case 6:
            pBcdTime[5] = (uint8_t)((pTimeInfo->sec / 10) << 4 | (pTimeInfo->sec % 10));
            // fall through
        case 5:
            pBcdTime[4] = (uint8_t)((pTimeInfo->min / 10) << 4 | (pTimeInfo->min % 10));
            // fall through
        case 4:
            pBcdTime[3] = (uint8_t)((pTimeInfo->hour / 10) << 4 | (pTimeInfo->hour % 10));
            // fall through
        case 3:
            pBcdTime[2] = (uint8_t)((pTimeInfo->mday / 10) << 4 | (pTimeInfo->mday % 10));
            // fall through
        case 2:
            pBcdTime[1] = (uint8_t)((pTimeInfo->mon / 10) << 4 | (pTimeInfo->mon % 10));
            // fall through
        case 1:
            year = (uint8_t)((pTimeInfo->year) % 100);
            pBcdTime[0] = (uint8_t)((year / 10) << 4 | (year % 10));
            return GOOD;

        default:
            return ERROR;
    }
    return ERROR;
}

/**
 * @brief Function iterates over all FR2 NR measurement objects of call's
 *        serving cell or target cell (in case of ongoing handover).
 *        It at least one such measurement object can be configured on UE then
 *        UE is considered FR2 capable and function returns TRUE.
 *        If there is no such measurement object then function returns FALSE.
 *
 * @param ptCi - call info pointer
 * @return int - TRUE/FALSE
 */
int VLIB_IsAnyFr2MoThatCanBeConfOnUe(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    int16_t retval = GOOD;
    int16_t result = GOOD;
    int moIdx = 0;

    // Select proper cell number based on call's state.
    const uint16_t cellNum = (IntraRatHO_cmd == ptCi->stateCmd ? ptCi->hoInfo.targetCellNum : ptCi->servCellNum);
    VCCB_CHECK_VALID_CELLNUM_FALSE(cellNum);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    // Iterate over all cell's NR measurement objects.
    for (; moIdx < MAX_NR_OF_OBJECT_ID_DB; ++moIdx)
    {
        // Cache current MO.
        const measurementObjectNRBaseDb_type *ptMO = &pCell->measurementsData.measurementObjectsNRDb[moIdx].base;
        // Current MO must be in-use and in FR2.
        if ((CI_use != ptMO->usage) || (MIN_A6_NR_ARFCN > ptMO->ssbFrequency))
        {
            continue;
        }
        // Check if current MO can be configured on UE.
        retval = VCCB_CheckIfMeasObjectNrCanBeAdded(ptCi, cellNum, ptMO->ssbFrequency, RSType_SSB, &result);
        if ((GOOD != retval) || (GOOD != result))
        {
            continue;
        }
        // Current FR2 MO determines that UE is FR2 capable.
        return TRUE;
    }

    return FALSE;
}

/**
 * @brief Checks all conditions related to PDCP buffer-based FR2 PSCell change, i.e.
 *        IS_PDCP_BUFFER_BASED_FR2_PSCELL_CHANGE_ENABLED &&
 *        IS_CALL_PSCELL_FR1                             &&
 *        VLIB_IsAnyFr2MoThatCanBeConfOnUe
 *        Returns TRUE if all above conditions are met.
 *        Returns FALSE otherwise.
 *
 * @param ptCi call info pointer
 * @return int TRUE/FALSE
 */
int VLIB_IsPdcpBufBasedFr2PscellChgSatisfied(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    if (IS_PDCP_BUFFER_BASED_FR2_PSCELL_CHANGE_ENABLED(ptCi->gnbNum) && IS_CALL_PSCELL_FR1(ptCi) &&
        (TRUE == VLIB_IsAnyFr2MoThatCanBeConfOnUe(ptCi)))
    {
        return TRUE;
    }

    return FALSE;
}

/**
 * @brief This is internal function for VLIB_GetDrbIdxByDrbId for NSA call.
 *
 * @param ptCi call info pointer
 * @param drbId DRB identity
 * @param pDrbIdx output of found DRB index.
 * @return int GOOD/ERROR
 */
int VLIB_GetDrbIdxByDrbId_NSA(const callInfo_type *ptCi, uint8_t drbId, uint8_t *pDrbIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDrbIdx);

    // Initialize output to invalid index.
    *pDrbIdx = MAX_ERAB_PER_CALL;

    uint8_t drbIdx = 0;

    // Try to find DRB by index.
    for (; drbIdx < MAX_ERAB_PER_CALL; ++drbIdx)
    {
        // DRB must be in-use.
        if (CI_use != ptCi->erabInfo[drbIdx].usage)
        {
            continue;
        }
        // Check if id matches.
        if (ptCi->erabInfo[drbIdx].dRBId == drbId)
        {
            *pDrbIdx = drbIdx;
            return GOOD;
        }
    }

    // DRB was not found.
    return ERROR;
}

/**
 * @brief This is internal function for VLIB_GetDrbIdxByDrbId for SA call.
 *
 * @param ptCi call info pointer
 * @param drbId DRB identity
 * @param pDrbIdx output of found DRB index.
 * @return int GOOD/ERROR
 */
int VLIB_GetDrbIdxByDrbId_SA(const callInfo_type *ptCi, uint8_t drbId, uint8_t *pDrbIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDrbIdx);

    // Initialize output to invalid index.
    *pDrbIdx = MAX_DRB_PER_SA_CALL;

    uint8_t drbIdx = 0;

    // Try to find DRB by index.
    for (; drbIdx < MAX_DRB_PER_SA_CALL; ++drbIdx)
    {
        // DRB must be in-use.
        if (CI_use != ptCi->drb[drbIdx].usage)
        {
            continue;
        }
        // Check if id matches.
        if (ptCi->drb[drbIdx].dRBId == drbId)
        {
            *pDrbIdx = drbIdx;
            return GOOD;
        }
    }

    // DRB was not found.
    return ERROR;
}

/**
 * @brief Tries to find DRB index based on DRB id.
 *        For SA calls it puts index of found DRB in ptCi->drb array into pDrbIdx.
 *        For NSA calls it puts index of found DRB in ptCi->erabInfo array into pDrbIdx.
 *        pDrbIdx is initialized to invalid index (out-of-range for array).
 *        Returns GOOD if DRB of given id was found.
 *        Returns ERROR otherwise.
 *
 * @param ptCi call info pointer
 * @param drbId DRB identity
 * @param pDrbIdx output of found DRB index
 * @return int GOOD/ERROR
 */
int VLIB_GetDrbIdxByDrbId(const callInfo_type *ptCi, uint8_t drbId, uint8_t *pDrbIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDrbIdx);

    int result = ERROR;

    switch (ptCi->callType)
    {
        case E_CALLTYPE_NSA:
            result = VLIB_GetDrbIdxByDrbId_NSA(ptCi, drbId, pDrbIdx);
            break;
        case E_CALLTYPE_SA:
            result = VLIB_GetDrbIdxByDrbId_SA(ptCi, drbId, pDrbIdx);
            break;
        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "Unknown call type %d.\n", (int)ptCi->callType);
            break;
    }

    return result;
}

/**
 * @brief Iterates over all ERABs and counts these with dlTarfficAboveThldFlag on.
 *        Returns count.
 *
 * @param ptCi call info pointer
 * @return int ERAB's with dlTarfficAboveThldFlag on count
 */
uint8_t VLIB_CountDrbWithAboveDlTrafficThldFlagOn(const callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ZERO(ptCi);

    // Only NSA calls are supported.
    if (E_CALLTYPE_NSA != ptCi->callType)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Only NSA calls are supported.\n");
        return 0;
    }

    uint8_t count = 0;
    int drbIdx = 0;
    for (; drbIdx < MAX_ERAB_PER_CALL; ++drbIdx)
    {
        if ((CI_use == ptCi->erabInfo[drbIdx].usage) && (VCCB_FLAG_ON == ptCi->erabInfo[drbIdx].dlTrafficAboveThldFlag))
        {
            ++count;
        }
    }

    return count;
}

/**
 * @brief Iterates over all DRBs and counts these with dlTarfficAboveThldFlag on.
 *        Returns count.
 *
 * @param ptCi call info pointer
 * @return int DRB's with dlTarfficAboveThldFlag on count
 */
uint8_t VLIB_CountDrbWithAboveDlTrafficThldFlagOn_SA(const callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ZERO(ptCi);

    // Only SA calls are supported.
    if (E_CALLTYPE_SA != ptCi->callType)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Only SA calls are supported.\n");
        return 0;
    }

    uint8_t count = 0;
    int drbIdx = 0;

    for (; drbIdx < MAX_DRB_PER_SA_CALL; ++drbIdx)
    {
        if (ERROR == VLIB_IsCommonValidStateOfPduQosDrb(ptCi->drb[drbIdx].drbStatus))
        {
            continue;
        }

        if ((CI_use == ptCi->drb[drbIdx].usage) && (VCCB_FLAG_ON == ptCi->drb[drbIdx].dlTrafficAboveThldFlag))
        {
            ++count;
        }
    }

    return count;
}

/**
 * @brief     This function provides a function to obtain the NRCGI of a specific cell.
 * @param     pCell : VccbCellInfo_type*
 * @return    cgi_type { ci, plmn }
 */
cgi_type FnVCCB_GetNrcgiFromCellInfo(const VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;

    cgi_type cgi;

    memset(&cgi, 0x00, sizeof(cgi));

    // {{{ For VccbCellInfo_type
    VALID_E_POINT_CHECK_RET_VAL(pCell, cgi);
    // }}}

    // {{{ For GNBINFO
    const uint8_t gnbNum = pCell->gnbNum;

    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, cgi);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
    // }}}

    cgi.plmn.longId = pGnb->globalGnbId.plmn.longId;
    cgi.ci = pCell->cgi.ci;

    return cgi;
}

/**
 * @brief     This function provides a function to obtain the NRCGI of a specific cell.
 * @param     cellNum : uint32_t
 * @return    cgi_type { ci, plmn }
 */
cgi_type FnVCCB_GetNrcgiFromCellNum(uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    cgi_type cgi;

    memset(&cgi, 0x00, sizeof(cgi));

    // {{{ For CELLINFO
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, cgi);

    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    // }}}

    cgi = FnVCCB_GetNrcgiFromCellInfo(pCell);

    return cgi;
}

bool FnVCCB_CheckSliceFiveQiRule(
    svcGrpCfg_type &rSvcGrpCfg,
    serviceGroupMappingInfo_type &rSvcGrpMapInfo,
    uint8_t *svcGrpId,
    uint8_t *priority,
    uint8_t svcGrpPriority) 
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(svcGrpId, false);
    VALID_E_POINT_CHECK_RET_VAL(priority, false);

    sliceFiveqiRule_type *pRule = &rSvcGrpCfg.u.sliceFiveqiRule;
    for (uint8_t sliceIdx = 0; sliceIdx < MAX_SVC_GRP_CONFIG_SLICE_NUM; sliceIdx++) 
    {
        if (pRule->sliceFiveqi[sliceIdx].usage != TRUE) continue;
        if (pRule->sliceFiveqi[sliceIdx].sstSd != rSvcGrpMapInfo.sstSd) continue;

        for (uint8_t fiveqi = 0; fiveqi < MAX_SVC_GRP_CONFIG_5QI_NUM; fiveqi++) 
        {
            qos5qiEntry_type *pQos5qi = &pRule->sliceFiveqi[sliceIdx].qos5qiEntries[fiveqi];
            if (pQos5qi->usage != TRUE) continue;
            if (rSvcGrpMapInfo.qos5qiMap[pQos5qi->qos5qi] != TRUE) continue;  

            *svcGrpId = rSvcGrpCfg.svcGrpId;
            *priority = svcGrpPriority;
            return true;
        }
    }
    return false;
}

bool FnVCCB_CheckSliceRule(
    svcGrpCfg_type &rSvcGrpCfg,
    serviceGroupMappingInfo_type &rSvcGrpMapInfo,
    uint8_t *svcGrpId,
    uint8_t *priority,
    uint8_t svcGrpPriority) 
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(svcGrpId, false);
    VALID_E_POINT_CHECK_RET_VAL(priority, false);

    for (uint8_t sliceIdx = 0; sliceIdx < MAX_SVC_GRP_CONFIG_SLICE_NUM; sliceIdx++) 
    {
        if (rSvcGrpCfg.u.sliceRule.slice[sliceIdx].usage != CI_use) continue;
        if (rSvcGrpCfg.u.sliceRule.slice[sliceIdx].sstSd != rSvcGrpMapInfo.sstSd) continue;

        *svcGrpId = rSvcGrpCfg.svcGrpId;
        *priority = svcGrpPriority;
        return true;
    }
    return false;
}

bool FnVCCB_CheckFiveQiRule(
    svcGrpCfg_type &rSvcGrpCfg,
    serviceGroupMappingInfo_type &rSvcGrpMapInfo,
    uint8_t *svcGrpId,
    uint8_t *priority,
    uint8_t svcGrpPriority) 
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(svcGrpId, false);
    VALID_E_POINT_CHECK_RET_VAL(priority, false);

    for (uint8_t fiveqi = 0; fiveqi < MAX_SVC_GRP_CONFIG_5QI_NUM; fiveqi++) 
    {
        qos5qiEntry_type *pQos5qi = &rSvcGrpCfg.u.qos5qiRule.qos5qiEntries[fiveqi];
        if (pQos5qi->usage != TRUE) continue;
        if (rSvcGrpMapInfo.qos5qiMap[pQos5qi->qos5qi] != TRUE) continue;

        *svcGrpId = rSvcGrpCfg.svcGrpId;
        *priority = svcGrpPriority;
        return true;
    }
    return false;
}

bool FnVCCB_CheckArpRule(
    svcGrpCfg_type &rSvcGrpCfg,
    serviceGroupMappingInfo_type &rSvcGrpMapInfo,
    uint8_t *svcGrpId,
    uint8_t *priority,
    uint8_t svcGrpPriority)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(svcGrpId, false);
    VALID_E_POINT_CHECK_RET_VAL(priority, false);

    arpRule_type *pRule = &rSvcGrpCfg.u.arpRule;
    for (uint8_t arpIdx = 0; arpIdx < MAX_SVC_GRP_CONFIG_ARP_NUM; arpIdx++)
    {
        if (pRule->arp[arpIdx].usage != TRUE) continue;
        if (pRule->arp[arpIdx].arpValue >= MAX_ARP_LEVEL) continue;
        if (rSvcGrpMapInfo.arpMap[pRule->arp[arpIdx].arpValue] != TRUE) continue;

        *svcGrpId = rSvcGrpCfg.svcGrpId;
        *priority = svcGrpPriority;
        return true;
    }
    return false;
}

bool FnVCCB_CheckArpFiveQiRule(
    svcGrpCfg_type &rSvcGrpCfg,
    serviceGroupMappingInfo_type &rSvcGrpMapInfo,
    uint8_t *svcGrpId,
    uint8_t *priority,
    uint8_t svcGrpPriority)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(svcGrpId, false);
    VALID_E_POINT_CHECK_RET_VAL(priority, false);

    arpFiveqiRule_type *pRule = &rSvcGrpCfg.u.arpFiveqiRule;
    for (uint8_t arpIdx = 0; arpIdx < MAX_SVC_GRP_CONFIG_ARP_NUM; arpIdx++)
    {
        if (pRule->arpFiveqi[arpIdx].usage != TRUE) continue;

        uint8_t arpValue = pRule->arpFiveqi[arpIdx].arpValue;
        if (arpValue >= MAX_ARP_LEVEL) continue;
        if (rSvcGrpMapInfo.arpMap[arpValue] != TRUE) continue;

        for (uint8_t fiveqi = 0; fiveqi < MAX_SVC_GRP_CONFIG_5QI_NUM; fiveqi++)
        {
            qos5qiEntry_type *pQos5qi = &pRule->arpFiveqi[arpIdx].qos5qiEntries[fiveqi];
            if (pQos5qi->usage != TRUE) continue;
            if (rSvcGrpMapInfo.arpQos5qiMap[pQos5qi->qos5qi][arpValue] != TRUE) continue;

            *svcGrpId = rSvcGrpCfg.svcGrpId;
            *priority = svcGrpPriority;
            return true;
        }
    }
    return false;
}

/****************************************************************************
 * @brief    FGR-MC1019 Service(5QI/Slice) based Mobility Control (Intra-NR, NR-LTE)
 ****************************************************************************/
void FnVCCB_FindSvcGrpIdByMappingRule(svcGrpCfg_type &rSvcGrpCfg, serviceGroupMappingInfo_type &rSvcGrpMapInfo,
    uint8_t *svcGrpId, uint8_t *priority, const uint8_t svcGrpPriority)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(svcGrpId);
    VALID_E_POINT_CHECK_VOID(priority);

    switch (rSvcGrpCfg.ruleOption) 
    {
        case SLICE_FIVEQI_MAPPING_RULE:
            if (FnVCCB_CheckSliceFiveQiRule(rSvcGrpCfg, rSvcGrpMapInfo, svcGrpId, priority, svcGrpPriority)) return;
            break;
        case SLICE_MAPPING_RULE:
            if (FnVCCB_CheckSliceRule(rSvcGrpCfg, rSvcGrpMapInfo, svcGrpId, priority, svcGrpPriority)) return;
            break;
        case FIVEQI_MAPPING_RULE:
            if (FnVCCB_CheckFiveQiRule(rSvcGrpCfg, rSvcGrpMapInfo, svcGrpId, priority, svcGrpPriority)) return;
            break;
        case ARP_MAPPING_RULE:
            if (FnVCCB_CheckArpRule(rSvcGrpCfg, rSvcGrpMapInfo, svcGrpId, priority, svcGrpPriority)) return;
            break;
        case ARP_FIVEQI_MAPPING_RULE:
            if (FnVCCB_CheckArpFiveQiRule(rSvcGrpCfg, rSvcGrpMapInfo, svcGrpId, priority, svcGrpPriority)) return;
            break;

        default:
            break;
    }

    return;
}

bool FnVCCB_CheckValidStateOfPduQosDrb(uint8_t status, uint8_t isReleaseProcedure)
{
    AUTO_TRACE_FUNC;

    if (isReleaseProcedure == TRUE)
    {
        if (ERROR == VLIB_IsCommonValidStateOfPduQosDrbForCellReselection(status))
        {
            return false;
        }
    }
    else
    {
        if (ERROR == VLIB_IsCommonValidStateOfPduQosDrb(status))
        {
            return false;
        }
    }

    return true;
}

/**
 * Determines whether the UE type supports service group configuration based on the UE type and REDCap status.
 * This function checks if the given UE type supports service group configuration based on its type and REDCap status.
 * It returns true if the UE type is 'UE_TYPE_ALL' or matches the appropriate type based on the REDCap status.
 * @param[in] isRedcapUe A boolean indicating whether the UE supports REDCap functionality.
 * @param[in] ueType An unsigned 8-bit integer representing the UE type.
 * @return bool Returns true if the UE type supports service group configuration, otherwise false.
 */
bool FnVCCB_IsUeTypeSupportSvcGrpCfg(bool isRedcapUe, uint8_t ueType)
{
    if(ueType == UE_TYPE_ALL) return true;

    return (isRedcapUe ? ueType == UE_TYPE_REDCAP : ueType == UE_TYPE_NORMAL);
}

void FnVCCB_GetServiceGroupIdByQos(callInfo_type *ptCi, uint8_t *pSvcGrpId, uint8_t *pPriority, serviceGroupMappingInfo_type &rSvcGrpMapInfo,
    const serviceGroupPriorities_type *ptSvcGrpPriorities)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pSvcGrpId);
    VALID_E_POINT_CHECK_VOID(pPriority);
    VALID_E_POINT_CHECK_VOID(ptSvcGrpPriorities);

    uint8_t uePlmnIndex;
    if (GOOD != VLIB_getMultipleGnbPlmnIndexInfo(ptCi, &uePlmnIndex, ptCi->ueInfo.servedPlmn.longId))
    {
        VCCB_PRINT_CALL_MSG(ptCi, "No match PLMN configuration to not exist for UE PLMN(idx:(%d) longId:(%X))\n",
            uePlmnIndex, ptCi->ueInfo.servedPlmn.longId);
        return;
    }

    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];
    uint8_t svcGrpIdx;
    for (svcGrpIdx = MIN_SVC_GRP_CONFIG_ID; svcGrpIdx < MAX_SVC_GRP_DB_NUM; svcGrpIdx++)
    {
        svcGrpCfg_type *ptSvcGrpCfg = &pGnb->cfg.svcGrpCfg[svcGrpIdx];

        if (ptSvcGrpCfg->usage != TRUE) continue;
        if (ptSvcGrpCfg->plmnIndex != uePlmnIndex) continue;
        if (not FnVCCB_IsUeTypeSupportSvcGrpCfg(IS_REDCAP_UE(ptCi), ptSvcGrpCfg->ueType)) continue;

        const uint8_t svcGrpPriority = ptSvcGrpPriorities->priority[svcGrpIdx];
        if ((*pPriority == svcGrpPriority) && (*pSvcGrpId < ptSvcGrpCfg->svcGrpId)) continue;  
        if (*pPriority < svcGrpPriority) continue;

        FnVCCB_FindSvcGrpIdByMappingRule(*ptSvcGrpCfg, rSvcGrpMapInfo, pSvcGrpId, pPriority, svcGrpPriority);
    }

    return;
}

int16_t FnVCCB_GetServiceGroupIdByDrb(
    callInfo_type *ptCi, uint8_t *ptSvcGrpId, callDRBInfo_type *pDrb, uint8_t isReleaseProcedure)
{
    AUTO_TRACE_FUNC;

    serviceGroupPriorities_type priorities;
    if (GOOD != FnVCCB_GetDefaultServiceGroupPriority(ptCi, &priorities))
    {
        return ERROR;
    }
    const int16_t status =
        FnVCCB_GetServiceGroupIdByDrbWithPriorityTable(ptCi, ptSvcGrpId, pDrb, &priorities, isReleaseProcedure);

    return status;
}

int16_t FnVCCB_GetServiceGroupId(callInfo_type *ptCi, uint8_t *ptSvcGrpId, uint8_t isReleaseProcedure)
{
    AUTO_TRACE_FUNC;

    serviceGroupPriorities_type priorities;
    if (GOOD != FnVCCB_GetDefaultServiceGroupPriority(ptCi, &priorities))
    {
        return ERROR;
    }
    const int16_t status = FnVCCB_GetServiceGroupIdWithPriorityTable(ptCi, ptSvcGrpId, &priorities, isReleaseProcedure);

    return status;
}

int16_t FnVCCB_GetDefaultServiceGroupPriority(callInfo_type *ptCi, serviceGroupPriorities_type *ptSvcGrpPriorities)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptSvcGrpPriorities);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];
    for (uint8_t svcGrpIdx = MIN_SVC_GRP_CONFIG_ID; svcGrpIdx < MAX_SVC_GRP_DB_NUM; svcGrpIdx++)
    {
        ptSvcGrpPriorities->priority[svcGrpIdx] = pGnb->cfg.svcGrpCfg[svcGrpIdx].priority;
    }

    return GOOD;
}

void FnVCCB_SetServiceGroupMappingInfo(qosFlowInfo_type &rQi, serviceGroupMappingInfo_type *pSvcGrpMapInfo)
{
    VALID_E_POINT_CHECK_VOID(pSvcGrpMapInfo);

    uint8_t fiveQi;
    VLIB_getFiveQi(&rQi, &fiveQi);

    pSvcGrpMapInfo->qos5qiMap[fiveQi] = TRUE;

    if (rQi.qosParam.allocAndRetent.priorityLevel < MAX_ARP_LEVEL)
    {
        pSvcGrpMapInfo->arpMap[rQi.qosParam.allocAndRetent.priorityLevel] = TRUE;
        pSvcGrpMapInfo->arpQos5qiMap[fiveQi][rQi.qosParam.allocAndRetent.priorityLevel] = TRUE;
    }
}

int16_t FnVCCB_GetServiceGroupIdByDrbWithPriorityTable(callInfo_type *ptCi, uint8_t *ptSvcGrpId, callDRBInfo_type *pDrb,
    const serviceGroupPriorities_type *ptSvcGrpPriorities, uint8_t isReleaseProcedure)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptSvcGrpId);
    VALID_E_POINT_CHECK_ERROR(pDrb);
    VALID_E_POINT_CHECK_ERROR(ptSvcGrpPriorities);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    uint8_t svcGrpId = 0, prevSvcGrpId = svcGrpId;  // make it as define value (default group)
    uint8_t priority = WORST_SVC_GRP_PRIORITY;

    uint8_t drbQosIdx;

    if (false == FnVCCB_CheckValidStateOfPduQosDrb(pDrb->drbStatus, isReleaseProcedure))
    {
        VCCB_PRINT_CALL_MSG(ptCi, "DRB[%d] Invalid Status(%d) !!!\n", pDrb->dRBId, pDrb->drbStatus);
        return ERROR;
    }

    uint8_t pduIdx = pDrb->pduIdxInCall;
    VCCB_CHECK_E_RANGE_AND_RETURN(pduIdx, MAX_PDU_SESS_PER_CALL);

    serviceGroupMappingInfo_type svcGrpMapInfo = {};
    svcGrpMapInfo.sstSd = ptCi->pduSess[pduIdx].sNssai.sstSd;

    for (drbQosIdx = 0; drbQosIdx < MAX_QOS_FLOW_PER_DRB; drbQosIdx++)
    {
        uint16_t qosFlowIdx = pDrb->qosFlowIndex[drbQosIdx];
        if (qosFlowIdx >= MAX_QOS_FLOW_PER_CALL) continue;

        qosFlowInfo_type *ptQi = &ptCi->qosFlow[qosFlowIdx];
        if (ptQi->usage != CI_use) continue;

        if (false == FnVCCB_CheckValidStateOfPduQosDrb(ptQi->qosFlowStatus, isReleaseProcedure))
        {
            VCCB_PRINT_CALL_MSG(ptCi, "Qos[%d] Invalid Status(%d) !!!\n", qosFlowIdx, ptQi->qosFlowStatus);
            continue;
        }

        FnVCCB_SetServiceGroupMappingInfo(*ptQi, &svcGrpMapInfo);
    }

    FnVCCB_GetServiceGroupIdByQos(ptCi, &svcGrpId, &priority, svcGrpMapInfo, ptSvcGrpPriorities);
    if (prevSvcGrpId != svcGrpId)
    {
        VCCB_PRINT_CALL_MSG(ptCi, "UE DRB[%d] : Update SvcGroupId: svcGrpId(%d->%d)\n", pDrb->dRBId,
            prevSvcGrpId, svcGrpId);
        prevSvcGrpId = svcGrpId;
    }

    *ptSvcGrpId = svcGrpId;
    return GOOD;
}

int16_t FnVCCB_GetServiceGroupIdWithPriorityTable(
    callInfo_type *ptCi, uint8_t *ptSvcGrpId, const serviceGroupPriorities_type *ptSvcGrpPriorities, uint8_t isReleaseProcedure)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptSvcGrpId);
    VALID_E_POINT_CHECK_ERROR(ptSvcGrpPriorities);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    uint8_t svcGrpId = 0, prevSvcGrpId = svcGrpId;  // make it as define value (default group)
    uint8_t priority = WORST_SVC_GRP_PRIORITY;

    uint8_t pduIdx, pduQosIdx;

    for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        callPDUSessInfo_type *ptPi = &ptCi->pduSess[pduIdx];
        if ((ptPi->usage != CI_use)) continue; 

        if (false == FnVCCB_CheckValidStateOfPduQosDrb(ptPi->pduSessStatus, isReleaseProcedure))
        {
            VCCB_PRINT_CALL_MSG(ptCi, "PDU[%d] Invalid Status(%d) !!!\n", pduIdx, ptPi->pduSessStatus);
            continue;
        }

        serviceGroupMappingInfo_type svcGrpMapInfo = {};
        svcGrpMapInfo.sstSd = ptPi->sNssai.sstSd;

        for (pduQosIdx = 0; pduQosIdx < MAX_QOS_FLOW_PER_PDU_SESS; pduQosIdx++)
        {
            uint16_t qosFlowIdx = ptPi->qosFlowIndex[pduQosIdx];
            if (qosFlowIdx >= MAX_QOS_FLOW_PER_CALL) continue;

            qosFlowInfo_type *ptQi = &ptCi->qosFlow[qosFlowIdx];
            if (ptQi->usage != CI_use) continue;

            if (false == FnVCCB_CheckValidStateOfPduQosDrb(ptQi->qosFlowStatus, isReleaseProcedure))
            {
                VCCB_PRINT_CALL_MSG(ptCi, "Qos[%d] Invalid Status(%d) !!!\n", qosFlowIdx, ptQi->qosFlowStatus);
                continue;
            }

            FnVCCB_SetServiceGroupMappingInfo(*ptQi, &svcGrpMapInfo);
        }

        FnVCCB_GetServiceGroupIdByQos(ptCi, &svcGrpId, &priority, svcGrpMapInfo, ptSvcGrpPriorities);
        if (prevSvcGrpId != svcGrpId)
        {
            VCCB_PRINT_CALL_MSG(ptCi, "UE PDU[%d] : Update SvcGroupId: svcGrpId(%d->%d)\n", pduIdx,
                prevSvcGrpId, svcGrpId);
            prevSvcGrpId = svcGrpId;
        }
    }

    *ptSvcGrpId = svcGrpId;
    return GOOD;
}

#ifdef __CNF__
/**
 * @brief   Get ACPF NE ID
 */
int FnVCCB_GetAcpfNeId(int64_t& neId)
{
    AUTO_TRACE_FUNC;

    char neIdStr[64] = { 0,};
    for (int retryCount = 0; retryCount < NRCALL_MAX_MW_RETRY; retryCount++)
    {
        const int result = mdsGetConfigMap("NE_ID", sizeof(neIdStr), neIdStr);
        if (result < 0)
        {
            VCCB_PRINTF("[%s] mdsGetConfigMap(NE_ID) ERROR(ret:%d retryCount:%d)\n", __FUNCTION__, result, retryCount);
            mdsPrintError(result);
            thsSleep(NRCALL_MW_RETRY_TIME);
        }
        else
        {
            char* endptr;
            neId = strtol(neIdStr, &endptr, 10);
            if (*endptr != '\0')
            {
                VCCB_PRINTF("Invalid string : neIdStr(%s)\n", neIdStr);
                continue;
            }

            if (neId == 0 && neIdStr[0] != '0')
            {
                VCCB_PRINTF("[%s] mdsGetConfigMap(NE_ID) ERROR Invalid NeId!! (Acquired neId:%s retryCount:%d)\n",
                    __FUNCTION__, neIdStr, retryCount);
                thsSleep(NRCALL_MW_RETRY_TIME);
                continue;
            }
            VCCB_PRINTF("[%s] Succeeded in getting NeId(%ld)\n", __FUNCTION__, neId);
            return GOOD;
        }
    }

    return ERROR;
}

/**
 * @brief   Get POD Id(unitType, unitId)
 */
int FnVCCB_GetPodId(uint16_t& unitType, uint16_t& unitId)
{
    AUTO_TRACE_FUNC;

    unitType = CPP;  // unitType(podType) is always CPP for VCCB
    int statefulSetIndex=0;
    for (int retryCount = 0; retryCount < NRCALL_MAX_MW_RETRY; retryCount++)
    {
        const int result = mdsGetStatefulSetIndex(&statefulSetIndex);
        if (result < 0)
        {
            VCCB_PRINTF("[%s] mdsGetStatefulSetIndex ERROR(%d)\n", __FUNCTION__, result);
            mdsPrintError(result);
            thsSleep(NRCALL_MW_RETRY_TIME);
        }
        else
        {
            unitId = static_cast<uint16_t>(statefulSetIndex);
            VCCB_PRINTF("[%s] Succeeded in getting pod id(%u)\n", __FUNCTION__, unitId);
            return GOOD;
        }
    }

    return ERROR;
}

int FnVCCB_GetAcpfRedundancyMode(enumCnfHaSupport_type& isSupportHA)
{
    AUTO_TRACE_FUNC;
    char buff[DAL_SYSINFO_BUFF_SIZE] = {
        0,
    };
    for (int retryCount = 0; retryCount < NRCALL_MAX_MW_RETRY; retryCount++)
    {
        const int ret = mdsGetConfigMap("REDIS", sizeof(buff), buff);
        if (ret < 0)
        {
            VCCB_PRINTF("[%s] mdsGetConfigMap(REDIS) ERROR(%d)\n", __func__, ret);
            VCCB_PRINTF("[%s], result = %s\n", __func__, buff);
            mdsPrintError(ret);
            thsSleep(NRCALL_MW_RETRY_TIME);
        }
        else
        {
            if (strncmp(buff, "enable", 6) != 0)
            {
                isSupportHA = CNF_HA_NOT_SUPPORT;
                VCCB_PRINTF("[%s], This Acpf dose not support HA function\n", __func__);
            }
            else
            {
                isSupportHA = CNF_HA_SUPPORT;
                VCCB_PRINTF("[%s], This Acpf support HA function\n", __func__);
            }
            return GOOD;
        }
    }

    return ERROR;
}

int FnVCCB_GetK8sNamespace(char (&k8sNamespace)[VCCB_MAX_K8S_NAMESPACE_NAME_LEN + 1])
{
    AUTO_TRACE_FUNC;
    if (k8sNamespace[0] == '\0')
    {
        for (int retryCount = 0; retryCount < NRCALL_MAX_MW_RETRY; retryCount++)
        {
            const int apiRet = k8sApiGetMyNamespace((VCCB_MAX_K8S_NAMESPACE_NAME_LEN + 1), k8sNamespace);
            if (apiRet != 0)
            {
                VCCB_PRINTF("[%s] k8sApiGetMyNamespace ERROR(%d)\n", __FUNCTION__, apiRet);
                thsSleep(NRCALL_MW_RETRY_TIME);
            }
            else
            {
                k8sNamespace[VCCB_MAX_K8S_NAMESPACE_NAME_LEN] = '\0';
                break;
            }
        }
    }
    return ((k8sNamespace[0] != '\0') ? GOOD : ERROR);
}

int FnVCCB_GetPodNamePrefix(char (&podNamePrefix)[VCCB_MAX_CNF_PREFIX_LEN + 1])
{
    AUTO_TRACE_FUNC;
    for (int retryCount = 0; retryCount < NRCALL_MAX_MW_RETRY; retryCount++)
    {
        const int result = mdsGetCnfPrefix(VCCB_MAX_CNF_PREFIX_LEN, podNamePrefix);
        if (result < 0)
        {
            VCCB_PRINTF("[%s] mdsGetCnfPrefix ERROR(%d)\n", __FUNCTION__, result);
            mdsPrintError(result);
            thsSleep(NRCALL_MW_RETRY_TIME);
        }
        else
        {
            VCCB_PRINTF("[%s] Succeeded in getting cnf prefix(%s)\n", __FUNCTION__, podNamePrefix);
            return GOOD;
        }
    }
    return ERROR;
}


int FnVCCB_GetK8sImage(char (&swVer)[SW_VER_STR_LENGTH], const char (&podName)[VCCB_MAX_POD_NAME_LENGTH + 1], const char (&k8sNamespace)[VCCB_MAX_K8S_NAMESPACE_NAME_LEN + 1])
{
    AUTO_TRACE_FUNC;
    K8sImage_Type k8sImage;
    for (int retryCount = 0; retryCount < NRCALL_MAX_MW_RETRY; retryCount++)
    {
        int apiRet = k8sApiGetImage(podName, k8sNamespace, &k8sImage);
        if (apiRet != 0)
        {
            VCCB_PRINTF("k8sApiGetImage ERROR(ret=%d) in %s\n", apiRet, __func__);
            thsSleep(NRCALL_MW_RETRY_TIME);
        }
        else
        {
            if (k8sImage.ContainerNum > 0)
            {
                snprintf(swVer, SW_VER_STR_LENGTH, k8sImage.ImageList[0].ImageString);
                VCCB_PRINTF("Set swVer(%s)\n", swVer);
                return GOOD;
            }
            else
            {
                VCCB_PRINTF("k8sImage.ContainerNum(%d) ERROR in %s\n", k8sImage.ContainerNum, __func__);
                thsSleep(NRCALL_MW_RETRY_TIME);
            }
        }
    }

    return ERROR;
}

const char *FnVCCB_GetPodTypeStr(enumVccbPod_type podType)
{
    switch (podType)
    {
        case VCCB_CPP:
            return "cpp";

        case VCCB_CIP:
            return "cip";
        case VCCB_CSP:
            return "csp";
        case VCCB_CMP:
            return "cmp";
        case VCCB_CTP:
            return "ctp";
        case VCCB_REDIS:
            return "redismaster";
        case VCCB_SNP:
            return "snp";
        default:
            VCCB_PRINTF("[%s] ERROR : unknown podType(%d)\n", __func__, podType);
            return NULL;
    }
}

enumVccbPod_type FnVCCB_GetBlockPodType(const int blockType)
{
    switch (blockType)
    {
        case BLOCK_VNMB:
            return VCCB_CIP;
        case BLOCK_VNLB:
            return VCCB_CSP;
        case BLOCK_VTMB:
            return VCCB_CTP;
        case BLOCK_OSAB:
            return VCCB_CMP;
        case BLOCK_VCSB:
            return VCCB_SNP;
        default:
            VCCB_PRINTF("[%s] ERROR : unknown blockType(%d)\n", __func__, blockType);
            return VCCB_POD_TYPE_END;
    }
}

enumVccbPodDeploymentKind_type FnVCCB_GetPodDeploymentKind(const enumVccbPod_type potType)
{
    switch (potType)
    {
        case VCCB_CIP:
        case VCCB_CSP:
        case VCCB_CMP:
        case VCCB_REDIS:
        case VCCB_CTP:
            return VCCB_STATEFULSET_POD;
        case VCCB_SNP:
            return VCCB_DEPLOYMENT_POD;
        default:
            VCCB_PRINTF("[%s] ERROR : unknown potType(%d)\n", __func__, potType);
            return VCCB_UNKNOWN_DEPLOYMENT_KIND_POD;
    }
}

int FnVCCB_GetPodSvcName(char *svcName[], const enumVccbPod_type podType, const int unitIdx, struct VccbEnvInfo_type::VccbEnvPodInfo_s& podInfo)
{
    const int maxUnitIdx = (podType == VCCB_CTP) ? VCCB_MAX_POD_ID_NUM : VCCB_MAX_HA_UNIT_NUM;

    if (unitIdx < 0 || unitIdx >= maxUnitIdx)
    {
        VCCB_PRINTF("[%s] unitIdx is out of range(%d:%d)\n", __func__, unitIdx, maxUnitIdx);
        return ERROR;
    }

    switch (podType)
    {
        case VCCB_CIP:
            *svcName = podInfo.cip[unitIdx].svcName;
            return GOOD;
        case VCCB_CSP:
            *svcName = podInfo.csp[unitIdx].svcName;
            return GOOD;
        case VCCB_CMP:
            *svcName = podInfo.cmp[unitIdx].svcName;
            return GOOD;
        case VCCB_REDIS:
            *svcName = podInfo.redis[unitIdx].svcName;
            return GOOD;
        case VCCB_SNP:
            (void)unitIdx;
            *svcName = podInfo.snp.svcName;
            return GOOD;
        case VCCB_CTP:
            *svcName = podInfo.ctp[unitIdx].svcName;
            return GOOD;
        default:
            (void)svcName;
            return ERROR;
    }
}

int FnVCCB_MakePodSvcName(char *buff, const size_t buffSize, const enumVccbPod_type podType, const int unitIdx, const char podNamePrefix[VCCB_MAX_CNF_PREFIX_LEN + 1])
{
    VALID_E_POINT_CHECK_ERROR(buff);

    enumVccbPodDeploymentKind_type deployType;
    deployType = FnVCCB_GetPodDeploymentKind(podType);
    if (deployType == VCCB_UNKNOWN_DEPLOYMENT_KIND_POD)
    {
        VCCB_PRINTF("[%s] FnVCCB_GetPodDeploymentKind ERROR!!\n", __func__);
        return ERROR;
    }

    const char *podTypeStr = FnVCCB_GetPodTypeStr(podType);
    if (podTypeStr == NULL)
    {
        VCCB_PRINTF("[%s] FnVCCB_GetPodTypeStr ERROR\n", __func__);
        return ERROR;
    }
    if (deployType == VCCB_STATEFULSET_POD)
    {
        snprintf(buff, buffSize, "%s-%s0-%d", podNamePrefix, podTypeStr, unitIdx);
    }
    else  // (deployType == VCCB_DEPLOYMENT_POD)
    {
        snprintf(buff, buffSize, "%s-%s%d", podNamePrefix, podTypeStr, unitIdx);
    }
    return GOOD;
}

int FnVCCB_SetAllPodsSvcName(struct VccbEnvInfo_type::VccbEnvPodInfo_s& podInfo, const char (&podNamePrefix)[VCCB_MAX_CNF_PREFIX_LEN + 1], const uint16_t unitId)
{
    // Set PodName(ex. acpf1048575-cpp0-19)
    snprintf(podInfo.podName, VCCB_MAX_POD_NAME_LENGTH, "%s-cpp0-%u", podNamePrefix, unitId);
    VCCB_PRINTF("Set podName(%s)\n", podInfo.podName);

    // Set 1:1 Redundancy pods Service Name
    for (int unitIdx = 0; unitIdx < VCCB_MAX_HA_UNIT_NUM; unitIdx++)
    {
        if (FnVCCB_MakePodSvcName(podInfo.cip[unitIdx].svcName, sizeof(podInfo.cip[unitIdx].svcName),
                VCCB_CIP, unitIdx, podNamePrefix) == ERROR)
        {
            VCCB_PRINTF("FnVCCB_MakePodSvcName ERROR!!(CIP, %d)\n", unitIdx);
            return ERROR;
        }
        if (FnVCCB_MakePodSvcName(podInfo.csp[unitIdx].svcName, sizeof(podInfo.csp[unitIdx].svcName),
                VCCB_CSP, unitIdx, podNamePrefix) == ERROR)
        {
            VCCB_PRINTF("FnVCCB_MakePodSvcName ERROR!!(CSP, %d)\n", unitIdx);
            return ERROR;
        }
        if (FnVCCB_MakePodSvcName(podInfo.cmp[unitIdx].svcName, sizeof(podInfo.cmp[unitIdx].svcName),
                VCCB_CMP, unitIdx, podNamePrefix) == ERROR)
        {
            VCCB_PRINTF("FnVCCB_MakePodSvcName ERROR!!(CMP, %d)\n", unitIdx);
            return ERROR;
        }
        if (ERROR == FnVCCB_MakePodSvcName(podInfo.redis[unitIdx].svcName,
                         sizeof(podInfo.redis[unitIdx].svcName), VCCB_REDIS, unitIdx, podNamePrefix))
        {
            VCCB_PRINTF("FnVCCB_MakePodSvcName ERROR!!(REDIS, %d)\n", unitIdx);
            return ERROR;
        }
    }

    for (int unitIdx = 0; unitIdx < VCCB_MAX_POD_ID_NUM; unitIdx++)
    {
        if (FnVCCB_MakePodSvcName(podInfo.ctp[unitIdx].svcName, sizeof(podInfo.ctp[unitIdx].svcName),
                VCCB_CTP, unitIdx, podNamePrefix) == ERROR)
        {
            VCCB_PRINTF("FnVCCB_MakePodSvcName ERROR!!(CTP %d)\n", unitIdx);
            return ERROR;
        }
    }

    // Set Single pods Service Name
    if (FnVCCB_MakePodSvcName(podInfo.snp.svcName, sizeof(podInfo.snp.svcName), VCCB_SNP, 0, podNamePrefix) == ERROR)
    {
        VCCB_PRINTF("FnVCCB_MakePodSvcName ERROR!!(SNP)\n");
        return ERROR;
    }
    return GOOD;
}

int FnVCCB_GetTerminationCallReleaseWaitSeconds(uint16_t &terminationCallReleaseWaitSeconds)
{
    AUTO_TRACE_FUNC;
    char buff[DAL_SYSINFO_BUFF_SIZE] = {
        0,
    };

    terminationCallReleaseWaitSeconds = 300;  // default setting

    for (int retryCount = 0; retryCount < NRCALL_MAX_MW_RETRY; retryCount++)
    {
        const int ret = mdsGetConfigMap("TERMINATION_CALL_REL_WAIT_SEC", sizeof(buff), buff);
        if (ret < 0)
        {
            VCCB_PRINTF("[%s] mdsGetConfigMap(TERMINATION_CALL_REL_WAIT_SEC) ERROR(%d)\n", __func__, ret);
            VCCB_PRINTF("[%s], result = %s\n", __func__, buff);
            mdsPrintError(ret);
            thsSleep(NRCALL_MW_RETRY_TIME);
        }
        else
        {
            char *endptr;
            terminationCallReleaseWaitSeconds = static_cast<uint16_t>(strtol(buff, &endptr, 10));
            if (*endptr != '\0')
            {
                VCCB_PRINTF("Invalid string : terminationCallReleaseWaitSeconds(%s)\n", buff);
                continue;
            }

            if (terminationCallReleaseWaitSeconds > 600)
            {
                VCCB_PRINTF(
                    "[%s] mdsGetConfigMap(TERMINATION_CALL_REL_WAIT_SEC) ERROR (Acquired value:%s retryCount:%d) -> forcedSet:600\n",
                    __FUNCTION__, buff, retryCount);
                terminationCallReleaseWaitSeconds = 600;
            }
            else if (terminationCallReleaseWaitSeconds < 1)
            {
                VCCB_PRINTF(
                    "[%s] mdsGetConfigMap(TERMINATION_CALL_REL_WAIT_SEC) ERROR (Acquired value:%s retryCount:%d) -> forcedSet:1\n",
                    __FUNCTION__, buff, retryCount);
                terminationCallReleaseWaitSeconds = 1;
            }

            VCCB_PRINTF("[%s] Succeeded in getting terminationCallReleaseWaitSeconds(%u)\n", __FUNCTION__,
                terminationCallReleaseWaitSeconds);
            return GOOD;
        }
    }

    return ERROR;
}

#endif  // __CNF__
void FnVCCB_Buffer_RightShift(unsigned char buffer[MAX_DAT_LEN], const unsigned int length, const uint8_t offset)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(buffer);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(length, 1, MAX_RRC_PDU_LENGTH);  // RRC limit is 'MAX_RRC_PDU_LENGTH'

    const uint32_t reservedLengthForOffset = (offset + 7U) / 8U;
    const uint32_t length_in_bytes = length + reservedLengthForOffset;
    const uint8_t lower_byte_mask = (uint8_t)((1U << offset) - 1U);

    uint8_t curr_byte, prev_byte;
    unsigned bufIdx = 0;

    prev_byte = buffer[0];
    buffer[0] = (unsigned char)(buffer[0] >> offset);
    for (bufIdx = 1; bufIdx < MIN(length_in_bytes, MAX_DAT_LEN); bufIdx++)
    {
        curr_byte = buffer[bufIdx];
        buffer[bufIdx] = (unsigned char)((prev_byte & lower_byte_mask) << (8U - offset));
        buffer[bufIdx] |= (unsigned char)(curr_byte >> offset);
        prev_byte = curr_byte;
    }
}

uint16_t FnVCCB_GetRfspValue(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    uint16_t rfspVal = 0;

    // Get Current RFSP Value
    if ((ptCi->ueInfo.rfsp.rfspPresent == OPT_PRESENT) && (IS_VALID_RFSP_STAT_VAL(ptCi->ueInfo.rfsp.indexToRFSP)))
    {
        rfspVal = ptCi->ueInfo.rfsp.indexToRFSP;
    }
    else
    {
        rfspVal = 0;
    }

    return rfspVal;
}

/****************************************************************************
 * @brief           This function initializes all SN Status related FLAGs.
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 ****************************************************************************/
void FnVCCB_InitSnStatusFlag(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->callType == E_CALLTYPE_SA)
    {
        uint8_t drbIdx = 0;
        for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
        {
            callDRBInfo_type *pDi = &ptCi->drb[drbIdx];
            FnVCCB_InitDrbPdcpSnStatus(&pDi->dataFwdInfo.snStatus);
        }
    }
    // If the NSA also uses this function, you need to activate the code as shown below.
    // else
    //{
    //     uint16_t erabIdx = 0;
    //     for (erabIdx = 0; erabIdx < MAX_ERAB_PER_CALL; erabIdx++)
    //     {
    //         callERABInfo_type *pEi = &ptCi->erabInfo[erabIdx];
    //         pEi->snStatus.needSendFlag = FALSE;
    //     }
    // }
}

/****************************************************************************
 * @brief           This function indicates whether SN Status information has been received.
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @return          true/false / bool
 ****************************************************************************/
bool FnVCCB_IsSnStatusReceivedFromSNode(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    uint8_t idx = 0;

    for (idx = 0; idx < MAX_DRB_PER_SA_CALL; idx++)
    {
        callDRBInfo_type *pDi = &ptCi->drb[idx];

        if (pDi->usage != CI_use) continue;

        if (pDi->dataFwdInfo.snStatus.needSendFlag == FALSE) continue;

        if (FnVCCB_IsSnTermPerDRB(ptCi, pDi, current_bearerType) == false) continue;

        return true;  // has already been received.
    }

    return false;  // reception is not received.
}

void FnVCCB_InitQosFlowDataFwdInfo(QosFlowDataFwdInfo_type *ptInfo)
{
    VALID_E_POINT_CHECK_VOID(ptInfo);

    memset(ptInfo, 0x00, sizeof(QosFlowDataFwdInfo_type));
}

void FnVCCB_InitPduDataFwdTunnel(PduDataFwdTunnel_type *ptInfo)
{
    VALID_E_POINT_CHECK_VOID(ptInfo);

    memset(ptInfo, 0x00, sizeof(PduDataFwdTunnel_type));
}

void FnVCCB_InitDrbDataFwdTunnel(DrbDataFwdTunnel_type *ptInfo)
{
    VALID_E_POINT_CHECK_VOID(ptInfo);

    memset(ptInfo, 0x00, sizeof(DrbDataFwdTunnel_type));
}

void FnVCCB_InitDrbPdcpSnStatus(DrbPdcpSnStatus_type *ptInfo)
{
    VALID_E_POINT_CHECK_VOID(ptInfo);

    memset(ptInfo, 0x00, sizeof(DrbPdcpSnStatus_type));
}

void FnVCCB_InitAllDrb_DataFwdTunnelAndSnStatus(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t callDrbIdx = 0;
    for (callDrbIdx = 0; callDrbIdx < MAX_DRB_PER_SA_CALL; callDrbIdx++)
    {
        if (ptCi->drb[callDrbIdx].usage == CI_no_use) continue;

        FnVCCB_InitDrbDataFwdTunnel(&ptCi->drb[callDrbIdx].dataFwdInfo.gtpTunnel);
        FnVCCB_InitDrbPdcpSnStatus(&ptCi->drb[callDrbIdx].dataFwdInfo.snStatus);
    }
}


/**
 * @brief     This function is called when choosing target cell candidates for SN addition
 *            (SVR23A FGR-CC5203)
 * @param     ptCi : call context
 * @param     gnbId : global gNB ID
 * @return    TRUE : should not be selected in the target cell candidates
 * @return    FALSE : can be selected as a target cell candidates
 */
bool FnVCCB_IsGnbBlocklisted(callInfo_type *ptCi, vccbGlobalGnbId_type gnbId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    uint16_t idx;
    for (idx = 0; idx < MAX_SN_BLOCKED_GNB_COUNT; idx++)
    {
        if (gnbId.gnbId.id == ptCi->blockListInfo.blocklist[idx].gnbId.id &&
            gnbId.plmn.longId == ptCi->blockListInfo.blocklist[idx].plmn.longId)
        {
            VCCB_PRINT_CALL_MSG(ptCi, "gnb(id: %d, plmn: %d) is in blocklist!!\n", gnbId.gnbId.id, gnbId.plmn.longId);
            return true;
        }
    }

    return false;
}

int16_t FnVCCB_IsVoNrEmergencyCall(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    uint8_t fiveQi;
    uint16_t qosFlowIdx;
    uint16_t findVoNrFlag = 0;

    qosFlowInfo_type *ptQi = NULL;

    if ((ptCi->callType != E_CALLTYPE_SA) || IS_NRDC_SN(ptCi))
    {
        return FALSE;
    }

    // Check Emergency Call
    if (VCCM_CheckEmergencyCall(ptCi) != TRUE)
    {
        return FALSE;
    }

    // Check 5QI=1
    for (qosFlowIdx = 0; qosFlowIdx < MAX_QOS_FLOW_PER_CALL; qosFlowIdx++)
    {
        ptQi = &ptCi->qosFlow[qosFlowIdx];

        if (ptQi->usage != CI_use) continue;

        if ((ptQi->qosFlowStatus != S_Idle) && (ptQi->qosFlowStatus != S_Setup) && (ptQi->qosFlowStatus != S_Modify) &&
            (ptQi->qosFlowStatus != S_FailToModify))
            continue;

        VLIB_getFiveQi(ptQi, &fiveQi);

        if (fiveQi == VONR_5QI)
        {
            findVoNrFlag++;
            break;
        }
    }
    if (findVoNrFlag == 0)
    {
        return FALSE;
    }

    return TRUE;
}

int FnVCCB_GetLongDrxCycleTime(enumVccbLongDrxCycle_type longDrxCycle)
{
    int ret = ERROR;
    switch(longDrxCycle)
    {
        case VCCB_DRX_LONG_CYCLE_10MS:
            ret = 10;
            break;
        case VCCB_DRX_LONG_CYCLE_20MS:
            ret = 20;
            break;
        case VCCB_DRX_LONG_CYCLE_32MS:
            ret = 32;
            break;
        case VCCB_DRX_LONG_CYCLE_40MS:
            ret = 40;
            break;
        case VCCB_DRX_LONG_CYCLE_60MS:
            ret = 60;
            break;
        case VCCB_DRX_LONG_CYCLE_64MS:
            ret = 64;
            break;
        case VCCB_DRX_LONG_CYCLE_70MS:
            ret = 70;
            break;
        case VCCB_DRX_LONG_CYCLE_80MS:
            ret = 80;
            break;
        case VCCB_DRX_LONG_CYCLE_128MS:
            ret = 128;
            break;
        case VCCB_DRX_LONG_CYCLE_160MS:
            ret = 160;
            break;
        case VCCB_DRX_LONG_CYCLE_256MS:
            ret = 256;
            break;
        case VCCB_DRX_LONG_CYCLE_320MS:
            ret = 320;
            break;
        case VCCB_DRX_LONG_CYCLE_512MS:
            ret = 512;
            break;
        case VCCB_DRX_LONG_CYCLE_640MS:
            ret = 640;
            break;
        case VCCB_DRX_LONG_CYCLE_1024MS:
            ret = 1024;
            break;
        case VCCB_DRX_LONG_CYCLE_1280MS:
            ret = 1280;
            break;
        case VCCB_DRX_LONG_CYCLE_2048MS:
            ret = 2048;
            break;
        case VCCB_DRX_LONG_CYCLE_2560MS:
            ret = 2560;
            break;
        case VCCB_DRX_LONG_CYCLE_5120MS:
            ret = 5120;
            break;
        case VCCB_DRX_LONG_CYCLE_10240MS:
            ret = 10240;
            break;
        default:
            break;
    }
    return ret;
}

int FnVCCB_GetShortDrxCycleTime(enumVccbShortDrxCycle_type shortDrxCycle)
{
    int ret = ERROR;
    switch(shortDrxCycle)
    {
        case VCCB_DRX_SHORT_CYCLE_2MS:
            ret = 2;
            break;
        case VCCB_DRX_SHORT_CYCLE_3MS:
            ret = 3;
            break;
        case VCCB_DRX_SHORT_CYCLE_4MS:
            ret = 4;
            break;
        case VCCB_DRX_SHORT_CYCLE_5MS:
            ret = 5;
            break;
        case VCCB_DRX_SHORT_CYCLE_6MS:
            ret = 6;
            break;
        case VCCB_DRX_SHORT_CYCLE_7MS:
            ret = 7;
            break;
        case VCCB_DRX_SHORT_CYCLE_8MS:
            ret = 8;
            break;
        case VCCB_DRX_SHORT_CYCLE_10MS:
            ret = 10;
            break;
        case VCCB_DRX_SHORT_CYCLE_14MS:
            ret = 14;
            break;
        case VCCB_DRX_SHORT_CYCLE_16MS:
            ret = 16;
            break;
        case VCCB_DRX_SHORT_CYCLE_20MS:
            ret = 20;
            break;
        case VCCB_DRX_SHORT_CYCLE_30MS:
            ret = 30;
            break;
        case VCCB_DRX_SHORT_CYCLE_32MS:
            ret = 32;
            break;
        case VCCB_DRX_SHORT_CYCLE_35MS:
            ret = 35;
            break;
        case VCCB_DRX_SHORT_CYCLE_40MS:
            ret = 40;
            break;
        case VCCB_DRX_SHORT_CYCLE_64MS:
            ret = 64;
            break;
        case VCCB_DRX_SHORT_CYCLE_80MS:
            ret = 80;
            break;
        case VCCB_DRX_SHORT_CYCLE_128MS:
            ret = 128;
            break;
        case VCCB_DRX_SHORT_CYCLE_160MS:
            ret = 160;
            break;
        case VCCB_DRX_SHORT_CYCLE_256MS:
            ret = 256;
            break;
        case VCCB_DRX_SHORT_CYCLE_320MS:
            ret = 320;
            break;
        case VCCB_DRX_SHORT_CYCLE_512MS:
            ret = 512;
            break;
        case VCCB_DRX_SHORT_CYCLE_640MS:
            ret = 640;
            break;
        default:
            break;
    }
    return ret;
}

/**
 * @brief     Range check
 * @return    val : value is not over the limit
 * @return    limit : value is over the limit
 */
uint32_t VLIB_CheckUpperLimit(const char *file, int line, uint32_t limit, uint32_t val)
{
    if (limit >= val)
    {
        return val;
    }
    else
    {
        VCCB_PRINT_DATA("%s %d :upperLimit(%u) < val(%u)\n", FnVCCB_GetFileName(file), line, limit, val);

        // MOD BY KGB :: 20101130 :: return 0 -> return limit
        return limit;
    }
}

int16_t FnVCCB_IsVoNRCall(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    uint16_t qosFlowIdx = FnVCCB_GetVoNRQoSFlowIndex(ptCi);

    if (qosFlowIdx < MAX_QOS_FLOW_PER_CALL)
    {
        return TRUE;
    }

    return FALSE;
}

int16_t FnVCCB_ExistUeAssistanceInformation(const callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    if (ptCi->overheatingAssistance.overheating_m.overheatingAssistance)
    {
        return TRUE;
    }

    if (ptCi->preferenceConfigForPowersaving.powersaving_m.maxCC_Preference ||
        ptCi->preferenceConfigForPowersaving.powersaving_m.maxBW_Preference ||
        ptCi->preferenceConfigForPowersaving.powersaving_m.maxMIMO_Preference)
    {
        return TRUE;
    }

    if (ptCi->ulGapFR2PreferenceAssistance.patternPreference_present)
    {
        return TRUE;
    }

    return FALSE;
}

/**
 * @brief   Check whether MRO operation is enabled
 * @param   ptCi : call context (it can be tempCall)
 * @param   checkType : Type of MRO operation (Intra-NR MRO HOP, Inter-RAT MRO for LTE, Coverage Problem Detection)
 * @return  true : Requested MRO operation is enabled
 * @return  false : Requested MRO operation is disabled
**/
bool FnVCCB_CheckMroEnabled(uint8_t checkType, callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    auto cpuOverloaded = [&]() -> bool
    {
        if (ptCi->mroInfo.ue.needToCheckLoad)
        {
            ptCi->mroInfo.ue.needToCheckLoad = FALSE;

            if (VCCB_FLAG_ON == CFG->overloadControl.ueSigCpuOverloadControl.ueSigCpuOverloadAction)
            {
                auto threshold = CFG->overloadControl.ueSigCpuOverloadControl.overloadedLevelMro;
                ptCi->mroInfo.ue.isOverloaded = IS_CPC_CPU_OVERLOAD_CONDITION(threshold);
                VCCB_PRINT_CALL_MRO(ptCi, "[MRO] CPU Overloaded(th:%d)\n", threshold);
            }
        }

        if (ptCi->mroInfo.ue.isOverloaded)
        {
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] Overloaded UE, stop MRO!!\n");
            return true;
        }
        return false;
    };

    if (IS_REDCAP_UE(ptCi)) return false;

    if (cpuOverloaded()) return false;

    if ((checkType & MRO_RAT_NR) &&
        (TRUE == FOO.VF_IntraNrMro && VCCB_FLAG_ON == pGnb->mroInfo.statSwitch))
    {
        return true;
    }

    if ((checkType & MRO_RAT_LTE) &&
        (TRUE == FOO.VF_IratMro && VCCB_FLAG_ON == pGnb->iratMroInfo.statSwitch))
    {
        return true;
    }

    // SVR24A FGS-SF0509 FR100
    if ((checkType & MRO_RAT_NR_CPD) &&
        (TRUE == FOO.VF_IntraNrMro && VCCB_FLAG_ON == pGnb->mroInfo.cpdSwitch))
    {
        return true;
    }

    return false;
}

enumActivityNotifLvl_type FnVCCB_Get_UserInactivity_NotiLevel(const callInfo_type *const ptCi)
{
    AUTO_TRACE_FUNC;

    if (ptCi == NULL)
    {
        return activityNotifLvl_UE;
    }

    /*
     * 1. NSA
     *  1) Use 'Desired Activity Notification Level' from eNB if received
     *  2) Use '.../inactivity-data/notification-level' in YANG
     * 2. SA
     *  1) Use '.../inactivity-data-sa/notification-level' for SA and NR-DC MN
     *         '.../inactivity-data-nrdc-sn/notification-level' for NR-DC SN
     */

    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        switch (ptCi->CallUserInactivity.desiredActivityNotificationLevel)
        {
            case desiredActivityNotifLvl_UE:
                return activityNotifLvl_UE;

            case desiredActivityNotifLvl_ERAB:
                return activityNotifLvl_DRB;

            default:
                // desiredActivityNotifLvl_NONE
                // desiredActivityNotifLvl_NA
                break;
        }
    }

    switch (ptCi->CallUserInactivity.activityNotificationLevel)
    {
        case activityNotifLvl_PDUSession:
            return activityNotifLvl_PDUSession;

        case activityNotifLvl_DRB:
            return activityNotifLvl_DRB;

        default:
            return activityNotifLvl_UE;
    }
}

/**
 * @brief   Set SPID index value for collection purposes without modifying SPID value inside ptCi structure
 * @param   ptCi : call context
 * @param   SPID : Reference to SPID index value
 * @return  true : Index was properly setup
 * @return  false : SPID value not changed
 **/
bool FnVCCB_setSpidCounterIndex(callInfo_type *ptCi, uint16_t &SPID)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, false);

    uint16_t UE_SPID = ptCi->ueInfo.rfsp.subscriberProfile;
    VCCB_CHECK_E_RANGE_AND_FALSE(UE_SPID, MAX_SPID_VALUE + 1);

    gnbConfig_type *pGnbCfg = &GNBINFO[ptCi->gnbNum].cfg;

    // Collect under specific SPID.
    if (SPID_0 != UE_SPID)
    {
        uint16_t supportedSpidArrIndex = UE_SPID / MAX_SPID_ARR_ELEM_SIZE_IN_BIT;
        uint32_t *pSpidConfig = &pGnbCfg->supportedSPIDforStatistic[supportedSpidArrIndex];
        bool isSpidConfigured = GETBIT_U32(*pSpidConfig, (UE_SPID % MAX_SPID_ARR_ELEM_SIZE_IN_BIT));
        if (isSpidConfigured)
        {
            SPID = UE_SPID;
            return true;
        }
    }

    // If specific SPID is not configured or SPID is 0, check if SPID 0 is configured
    if (GETBIT_U32(pGnbCfg->supportedSPIDforStatistic[0], SPID_0))
    {
        // Collect under SPID zero.
        SPID = SPID_0;
        return true;
    }

    return false;
}

bool FnVCCB_IsQciAndSpidStatSuppConfigured(callInfo_type *ptCi, callERABInfo_type *ptRi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptRi, false);

    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, false);

    if (false == FOO.VF_VzwOnlyCounterFamily)
    {
        return false;
    }

    gnbConfig_type *pGnbCfg = &GNBINFO[ptCi->gnbNum].cfg;

    for (uint8_t index = 0; index < MAX_QCI_AND_SPID_SIZE; index++)
    {
        if (pGnbCfg->qciAndSpidStatSup[index].usage == CI_use &&
            pGnbCfg->qciAndSpidStatSup[index].spidKey == ptCi->ueInfo.rfsp.subscriberProfile  &&
            pGnbCfg->qciAndSpidStatSup[index].qciKey ==  ptRi->erabQos.qciValue.QCI)
        {
            return true;
        }
    }

    return false;
}

const char *FnVCCB_GetBearerTypeStr(enumBearerType bearerType)
{
    switch (bearerType)
    {
        case SCG_Bearer:
            return "SCG";
        case SPLIT_Bearer:
            return "SPLIT";
        case MCG_Bearer:
            return "MCG";
        default:
            return "UNKNOWN";
    }
}

/**
 * @brief This function retrieves the target cell number for the given call information.
 *
 * @param ptCi Pointer to the call information structure.
 * @return uint16_t The target cell number.
 */
uint16_t FnVCCB_GetTargetCellNumForUpm(const callInfo_type * const ptCi)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_CELL_NUM_VCCB);

    // Initialize the target cell number with the serving cell number.
    uint16_t cellNum = ptCi->servCellNum;

    // Check if the call is in the Intra-RAT HO state.
    if (ptCi->stateCmd == IntraRatHO_cmd)
    {
        // Check if the HO type is intra-NB.
        if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
        {
            // Update the target cell number with the target cell number from the HO information.
            cellNum = ptCi->hoInfo.targetCellNum;
        }
    }

    // Return the target cell number.
    return cellNum;
}

bool FnVCCB_IsAoAPeriodicitySame(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    uint32_t tNrppaMeasPeriodicity[13] = {120, 240, 480, 640, 1024, 2048, 5120, 10240, 60000, 360000, 720000, 1800000,
                                          3600000};
    uint32_t tNrppaMeasPeriodicityAoA[14] = {160, 320, 640, 1280, 2560, 5120, 10240, 20480, 40960, 61440, 81920,
                                             368640, 737280, 1843200};

    if(tNrppaMeasPeriodicity[ptCi->NrPpaContext.measurementPeriodicity] ==
       tNrppaMeasPeriodicityAoA[ptCi->NrPpaContext.measurementPeriodicityAoA])
    {
        return true;
    }

    return false;
}

void FnVCCB_InitUeSliceMBRList(ueSliceMbrList_type (&ueSliceMbrList)[MAX_NR_OF_SLICE_MBR])
{
    AUTO_TRACE_FUNC;

    for (uint8_t index = 0; index < MAX_NR_OF_SLICE_MBR; index++)
    {
        ueSliceMbrList[index].sNssai.sdPresent = OPT_NOT_PRESENT;
        ueSliceMbrList[index].sNssai.sstSd = 0xFFFFFFFF;
        ueSliceMbrList[index].bitRateDl = MAX_EXTENDED_BITRATE;
        ueSliceMbrList[index].bitRateUl = MAX_EXTENDED_BITRATE;
        ueSliceMbrList[index].usage = CI_no_use;
    }
}

bool FnVCCB_IsSameSNSSAI(const callSNSSAI_type &s1, const callSNSSAI_type &s2)
{
    AUTO_TRACE_FUNC;

    if (GET_SNSSAI_FROM_SST_AND_SD(s1.sst, s1.sd) == GET_SNSSAI_FROM_SST_AND_SD(s2.sst, s2.sd))
    {
        return true;
    }

    return false;
}

void FnVCCB_HandleNrCallMsgDelayStart(msgCallSetupReq_type *ptMsg, uint8_t threadId, uint16_t msgId)
{
    VALID_E_POINT_CHECK_VOID(ptMsg);
    VCCB_CHECK_RANGE_AND_RETURN_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB, "FnVCCB_HandleNrCallMsgDelayStart ignored! threadId");

    THREAD_INFO->call[threadId].buf.sctpTx.callMsgDelayCheckFlag = ptMsg->callMsgDelayCheckFlag;
    memcpy(&THREAD_INFO->call[threadId].callMsgDelay, &ptMsg->data[ptMsg->length], sizeof(NrCallMsgDelay_type));

    struct timespec ts;
    blockTime_type *pVccbTime = &THREAD_INFO->call[threadId].callMsgDelay.vccbTime;

    // Initialize before get information
    pVccbTime->startTime.msgId = msgId;
    pVccbTime->startTime.duUeId = 0;
    pVccbTime->startTime.cuUeId = 0;
    pVccbTime->startTime.time_ms = 0;

    if (clock_gettime(CLOCK_REALTIME, &ts) < 0)
    {
        char errBuf[256];
        strerror_r(errno, errBuf, sizeof(errBuf));
        VCCB_PRINT_ERROR("ERROR(%s) in %s\n", errBuf, __func__);
    }
    else
    {
        pVccbTime->startTime.msgId = msgId;
        pVccbTime->startTime.duUeId = 0;
        pVccbTime->startTime.cuUeId = 0;  // not yet to be allocated
        pVccbTime->startTime.time_ms = static_cast<uint64_t>((ts.tv_sec * 1000) + (ts.tv_nsec / 1000000));
    }

    VCCB_PRINT_ERROR("[****] Receive delay check flag set(thread:%d, time_ms:%lu)\n", threadId, pVccbTime->startTime.time_ms);
}

void FnVCCB_HandleNrCallMsgDelayEnd(callInfo_type *ptCi, SctpDataTransfer_type *ptMsg, uint16_t msg_Id, uint32_t &length)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptMsg);

    uint32_t threadId = ptCi->myThreadId;
    VCCB_CHECK_RANGE_AND_RETURN_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB, "FnVCCB_HandleNrCallMsgDelayEnd ignored! threadId");

    struct timespec ts;
    blockTime_type *pVccbTime = &THREAD_INFO->call[threadId].callMsgDelay.vccbTime;

    pVccbTime->endTime.msgId = msg_Id;
    pVccbTime->endTime.duUeId = 0;
    pVccbTime->endTime.cuUeId = 0;
    pVccbTime->endTime.time_ms = 0;

    if (clock_gettime(CLOCK_REALTIME, &ts) < 0)
    {
        char errBuf[256];
        strerror_r(errno, errBuf, sizeof(errBuf));
        VCCB_PRINT_ERROR("ERROR(%s) in %s\n", errBuf, __func__);
    }
    else
    {
        pVccbTime->endTime.msgId = msg_Id;
        pVccbTime->endTime.duUeId = ptCi->auCallId;
        pVccbTime->endTime.cuUeId = ptCi->callId;
        pVccbTime->endTime.time_ms = static_cast<uint64_t>((ts.tv_sec * 1000) + (ts.tv_nsec / 1000000));
    }

    memcpy(&ptMsg->data[ptMsg->length], &THREAD_INFO->call[threadId].callMsgDelay, sizeof(NrCallMsgDelay_type));
    length += static_cast<uint32_t>(sizeof(NrCallMsgDelay_type));

    VCCB_PRINT_ERROR("[****] estimate vccb delay (ptMsg->len:%d len:%d thread:%d time_ms:%lu diff:%u)\n", ptMsg->length, length, threadId,
        pVccbTime->endTime.time_ms, static_cast<uint32_t>(pVccbTime->endTime.time_ms - pVccbTime->startTime.time_ms));

    uint32_t position = 0;
    for (uint32_t index = 0; index < static_cast<uint32_t>(sizeof(NrCallMsgDelay_type)); index += 24)
    {
        position = ptMsg->length + index;
        VCCB_PRINT_ERROR("[****] %10u %10u %10u %16lu\n",
            *(reinterpret_cast<uint32_t *>(&ptMsg->data[position])),
            *(reinterpret_cast<uint32_t *>(&ptMsg->data[position + 4])),
            *(reinterpret_cast<uint32_t *>(&ptMsg->data[position + 8])),
            *(reinterpret_cast<uint64_t *>(&ptMsg->data[position + 16])));
    }
}

int16_t FnVCCB_HandleAfterExistingCallRelWaitTimer(void)
{
    if (CFG->acpfInfo.cnfUpgrade.receivedSignalType == SIGUSR2)
    {
        VCCB_PRINTF("timInternalExistingCallRelWait is expired(SIGUSR2), so try to release all calls\n");
        FnVCCB_ReleaseAllCalls(INTERNAL_CALL_RELEASE_CAUSE_CNF_UPGRADE);
    }
    else
    {
        if (CFG->assignedCallCount == 0)
        {
            // change label
            VCCB_PRINTF("timInternalExistingCallRelWait is expired, There is no existing call, so change label to 'changeable'\n");
            FnVCCB_SetPodLabel(__func__, "changeable", "1");
            return GOOD;
        }
        else
        {
#if defined(NEW_HOST_SIM) || defined(IPC_TEST)
            uint32_t timerValue = (uint32_t)(CFG->acpfInfo.cnfUpgrade.upgradeEmergencyCallRelWaitTimerValue * 60 * 100);
#else
            uint32_t timerValue = (uint32_t)(CFG->acpfInfo.cnfUpgrade.upgradeEmergencyCallRelWaitTimerValue * 60 * 1000);
#endif
            if (timerValue == 0)  // don't need to wait for release emergency call.
            {
                VCCB_PRINTF("timInternalExistingCallRelWait is expired, But timerValue for RelEmergencyCallRel is zero, so try to release all calls\n");
                FnVCCB_ReleaseEveryCallAndWaitForTerminating();
            }
            else
            {
                VCCB_PRINTF("timInternalExistingCallRelWait is expired, for %u ms, wait for release emergency call additionally \n", timerValue);

                // To wait for Emergency call release                
                VLIB_AttachTimerNonCore(&CFG->acpfInfo.cnfUpgrade.upgradeEmergencyCallRelWaitTimer,
                    timInternalEmergencyCallRelWait_id, (int)timerValue, VCCB_NONUE_ADDR.MdsPort);  // To VCCB NonUeTask(tNonUe)

                // To check emergency call existing check periodically
                VLIB_AttachTimerNonCore(&CFG->acpfInfo.cnfUpgrade.upgradeEmergencyCallCheckTimer,
                    timInternalEmergencyCallCheck_id, 5000, VCCB_NONUE_ADDR.MdsPort, VCCB_TIMER_PERIODIC);   // To VCCB NonUeTask(tNonUe)
            }
        }
    }

    return GOOD;
}

int16_t FnVCCB_EmergencyCallCheckForCnfUpgrade(void)
{
    uint32_t callId = 0;

    VCCB_PRINTF("Check for Emergency Call existing\n");

    if (CFG->assignedCallCount == 0)  // All Call Release
    {
        // timer cancel
        VCCB_CLEAR_TIMER(&CFG->acpfInfo.cnfUpgrade.upgradeEmergencyCallRelWaitTimer, CANCEL_TIMER);
        VCCB_CLEAR_TIMER(&CFG->acpfInfo.cnfUpgrade.upgradeEmergencyCallCheckTimer, CANCEL_TIMER);

        // change label
        VCCB_PRINTF("during emergencyCallCheck, There is no existing call, so change label to 'changeable'\n");
        FnVCCB_SetPodLabel(__func__, "changeable", "1");
        return GOOD;
    }

    for (callId = 0; callId < VCCB_MAX_CALL_COUNT_PER_CPC; callId++)
    {
        callInfo_type *ptCi = FnVCCB_GetCallInUse(callId);
        if (ptCi != NULL)
        {
            if (ptCi->bitFlag.emergencyCallFlagJustUsingCnfUpgrade) 
                break;
        }
    }

    if (callId >= VCCB_MAX_CALL_COUNT_PER_CPC)
    {
        VCCB_CLEAR_TIMER(&CFG->acpfInfo.cnfUpgrade.upgradeEmergencyCallRelWaitTimer, CANCEL_TIMER);
        VCCB_CLEAR_TIMER(&CFG->acpfInfo.cnfUpgrade.upgradeEmergencyCallCheckTimer, CANCEL_TIMER);

        VCCB_PRINTF("Periodic checking for emergency call, but there is no emergency call\n");
        FnVCCB_ReleaseEveryCallAndWaitForTerminating();
    }

    return GOOD;
}

void FnVCCB_SetPodLabel(const char *func, const char *key, const char *value)
{
    VALID_E_POINT_CHECK_VOID(func);
    VALID_E_POINT_CHECK_VOID(key);
    VALID_E_POINT_CHECK_VOID(value);

    K8sPodLabelParam_Type podLabel;
    memset(&podLabel, 0, sizeof(podLabel));

    strncpy(podLabel.labelKey, key, sizeof(podLabel.labelKey)-1);
    strncpy(podLabel.labelValue, value, sizeof(podLabel.labelValue)-1);
#ifdef __CNF__
    // int k8sApiSetPodLabel(const char *PodName, const char *Namespace, const K8sPodLabelParam_Type *podLabelSetParamPtr)
    k8sApiSetPodLabel(ENV->podInfo.podName, CFG->k8sNamespace, &podLabel);
#endif
    VCCB_PRINTF("k8sApiSetPodLabel key:%s, value:%s (%s)\n", podLabel.labelKey, podLabel.labelValue, func);
}

// Set minimum 10sec(by FnVCCB_InitCfgAcpfInfo), other case, set (inputParater + offset(5sec))
void FnVCCB_SetCnfAllCallRelWaitTimerValue(int timerValue)
{    
    if(CFG->acpfInfo.cnfUpgrade.upgradeAllCallRelWaitTimerValue < (uint32_t)(timerValue + 5000))
        CFG->acpfInfo.cnfUpgrade.upgradeAllCallRelWaitTimerValue = (uint32_t)(timerValue + 5000); // offset 5 sec
}

void FnVCCB_ReleaseEveryCallAndWaitForTerminating()
{
    uint32_t timerValue = CFG->acpfInfo.cnfUpgrade.upgradeAllCallRelWaitTimerValue;

    FnVCCB_ReleaseAllCalls(INTERNAL_CALL_RELEASE_CAUSE_CNF_UPGRADE);

    VLIB_AttachTimerNonCore(&CFG->acpfInfo.cnfUpgrade.upgradeTerminatingCallRelWaitTimer,
        timInternalTerminatingCallRelease_id, (int)timerValue, VCCB_NONUE_ADDR.MdsPort);  // To VCCB NonUeTask(tNonUe)

    VCCB_PRINTF("upgradeTerminatingCallRelWaitTimer Result(TimerValue:%d, TimerId:%d)\n", timerValue,
            CFG->acpfInfo.cnfUpgrade.upgradeTerminatingCallRelWaitTimer.id);
}

/****************************************************
 * @brief      This function passes the structure to which BandNr belongs in BandNrCapa.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  bandNr : nr band / uint16_t
 * @return     NULL, Pointer
 ****************************************************/
bandNrUeCapa_type *FnVCCB_GetBandNrUeCapa(callInfo_type *ptCi, uint16_t bandNr)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptCi);

    uint16_t bandNrIdx = VLIB_GetNrBandIndex(*ptCi, bandNr);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VAL(bandNrIdx, 0, (MAX_NUM_UECAPA_NR_BANDS - 1), NULL);

    return &ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR[bandNrIdx];
}

void FnVCCB_InitGnbSliceStatCounterList(int gnbNum)
{
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
    for (int loop = 0; loop < MAX_SLICE_STAT_YANG; loop++)
    {
        pGnb->sliceStatCounterList[loop].usage = 0;
        pGnb->sliceStatCounterList[loop].plmnIndex = 0;
        pGnb->sliceStatCounterList[loop].sNssai.sst = 0;
        pGnb->sliceStatCounterList[loop].sNssai.sd = 0xFFFFFF;
    }
}

uint32_t calcIncreasedCount(uint32_t prevCount, uint32_t curCount)
{
    int64_t increasedCount = (int64_t)curCount - (int64_t)prevCount;

    if (increasedCount >= 0) return (uint32_t)increasedCount;
    else return (UINT32_MAX - prevCount + 1) + curCount;
}

void FnVCCB_GetCallReleaseCountForCallDropRatioHigh(uint32_t &callReleaseCount, uint32_t &abnormalCallReleaseCount)
{
    uint32_t diffCallRelease = 0;
    uint32_t diffAbnormal = 0;

    auto &rDropAlarm = CFG->acpfInfo.callDropRatioHighAlarm;
    for (int thId = 0; thId < MAX_CALL_THREAD_NUM_VCCB; thId++)
    {
        diffCallRelease += calcIncreasedCount(rDropAlarm.prevCallReleaseCount[thId], 
                                              rDropAlarm.currCallReleaseCount[thId]);
        diffAbnormal += calcIncreasedCount(rDropAlarm.prevAbnormalCallReleaseCount[thId], 
                                           rDropAlarm.currAbnormalCallReleaseCount[thId]);

        // Update previous db
        rDropAlarm.prevCallReleaseCount[thId] = rDropAlarm.currCallReleaseCount[thId];
        rDropAlarm.prevAbnormalCallReleaseCount[thId] = rDropAlarm.currAbnormalCallReleaseCount[thId];
    }

    callReleaseCount = diffCallRelease;
    abnormalCallReleaseCount = diffAbnormal;
}

// Set Emergency only with establishmentCause
void FnVCCB_SetEmergencyCallInCslWithEstCause(callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;

    bool iPrint = false;

    // 1. Check FOO
    if (!(FOO.VF_CallSummaryLogs_VZW)) return;

    // 2. Check Emergency with establishmentCause
    if (rCall.emergencyRequestedForCsl != VCCB_FLAG_ON)
    {
        if (DBG->flag.logBasicStatCsl) iPrint = true;

        // 1. Check establishmentCause
        if (rCall.ueInfo.establishmentCause == ci_emergency)
        {
            rCall.emergencyRequestedForCsl = VCCB_FLAG_ON;
            if (iPrint)
            {
                VCCB_PRINT_CALL_INFORMATIVE(&rCall, "[CSL][Emergency] Cause(ci_emergencys). Set Emergency\n");
            }
        }
    }
}

//  Set VoNR and Emergency with QosFlow Info (5QI, priorityLevel)
void FnVCCB_SetVonrAndEmergencyCallInCslWithQosFlow(callInfo_type &rCall, uint8_t priorityLevel, uint8_t fiveQi)
{
    AUTO_TRACE_FUNC;

    bool iPrint = false;

    // 1. Check FOO
    if (!(FOO.VF_CallSummaryLogs_VZW)) return;

    if (DBG->flag.logBasicStatCsl) iPrint = true;

    // 2. Check VoNR
    if (rCall.vonrRequestedForCsl != VCCB_FLAG_ON)
    {
        if (fiveQi == VONR_5QI)
        {
            rCall.vonrRequestedForCsl = VCCB_FLAG_ON;
        }
    }

    // 3. Check Emergency with QosFlow Info
    if (rCall.emergencyRequestedForCsl != VCCB_FLAG_ON)
    {
        // 2. Check 5QI and Priority.
        if (FnVCCB_CheckEmergencyCallByQosFlowInfo(rCall, priorityLevel, fiveQi, selectPlmnType_ServedUE_PLMN, iPrint) == TRUE)
        {
            rCall.emergencyRequestedForCsl = VCCB_FLAG_ON;
            if (iPrint)
            {
                VCCB_PRINT_CALL_INFORMATIVE(&rCall, "[CSL][Emergency] fiveQi=%u, ARP=%u. Set Emergency.\n", fiveQi, priorityLevel);
            }
        }
    }
}

// [Hand-In] Set VoNR and Emergency with QosFlow Info (5QI, priorityLevel) - FGR-MC1009, MC1010, MC3002 26A 
void FnVCCB_SetVonrAndEmergencyCallForCsl(callInfo_type &callInfo)
{
    AUTO_TRACE_FUNC;
    callInfo_type *ptCi = &callInfo;

    // Init
    ptCi->vonrRequestedForCsl = ptCi->emergencyRequestedForCsl = 0xFF;

    uint8_t fiveqi = 0;
    for (uint16_t pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        if (!IS_VALID_NODE(PDU_NODE, ptCi, &(ptCi->pduSess[pduIdx]))) continue;

        for (uint16_t pduQosIdx = 0; pduQosIdx < MAX_QOS_FLOW_PER_PDU_SESS; pduQosIdx++)
        {
            uint16_t qosIdx = ptCi->pduSess[pduIdx].qosFlowIndex[pduQosIdx];
            if (qosIdx >= MAX_QOS_FLOW_PER_CALL) continue;

            qosFlowInfo_type *ptQi = &ptCi->qosFlow[qosIdx];
            if (ptQi->usage != CI_use) continue;

            VLIB_getFiveQi(ptQi, &fiveqi);

            VCCB_PRINT_CALL_COMMENT(
                ptCi, "%s qosIdx(%d) flowId(%u) qosFlowStatus(%u) priorityLevel(%u) fiveqi(%u) \n",
                __func__, qosIdx, ptQi->flowId, ptQi->qosFlowStatus, ptQi->qosParam.allocAndRetent.priorityLevel, fiveqi);

            FnVCCB_SetVonrAndEmergencyCallInCslWithQosFlow(*ptCi, ptQi->qosParam.allocAndRetent.priorityLevel, fiveqi);
        }
    }
}

uint64_t FnVCCB_TacAndSvnAsBcdImeisv(uint32_t tac, uint8_t svn)
{
    AUTO_TRACE_FUNC;

    uint64_t emptyImeisv = 0;
    unsigned char* buf = reinterpret_cast<unsigned char*>(&emptyImeisv);

    for (int8_t remainingChunks = 3; remainingChunks >= 0; remainingChunks--)
    {
        uint8_t digits = static_cast<uint8_t>(tac % 10);
        tac /= 10;
        digits |= static_cast<uint8_t>(((tac % 10) << 4));
        tac /= 10;
        buf[remainingChunks] = digits;
    }
    uint8_t digits = svn % 10;
    svn /= 10;
    digits |= static_cast<uint8_t>(((svn % 10) << 4));
    buf[7] = digits; 

    return emptyImeisv;
}

/****************************************************
 * @brief      This function returns the index of IMEISV feature control entry matching provide TAC/SVN
 *             std::lower_bound is used to lookup in O(log n) as entries are guaranteed to be sorted
 * @param[in]  tac : IMEISV tac, 0 .. 99'999'999
 * @param[in]  svn : IMEISV svn, 0 .. 99
 * @return     index of found entry or MAX_IMEISV_FEATURE_CONTROL_INFORMATION_ENTRIES, return type is decltype(std::distance)
 ****************************************************/
int64_t FnVCCB_FindIMEISVFeatureControlInfoEntryIndex(const uint64_t callMaskedImeisv)
{
    AUTO_TRACE_FUNC;

    ImeisvFeatureControlInformation_type const& imeisvFeatControl = CFG->imeisvFeatControlInfo;
    ImeisvFeatureControlInformationEntry_type const* entriesEnd = imeisvFeatControl.entries + imeisvFeatControl.noOfEntries;
    auto it = std::lower_bound(
            imeisvFeatControl.entries,
            entriesEnd,
            callMaskedImeisv,
            ImeisvFeatureControlInformationEntryComp{});
    if ((it == entriesEnd) || (it->maskedImeisv != callMaskedImeisv))
    {
        return MAX_IMEISV_FEATURE_CONTROL_INFORMATION_ENTRIES;
    }

    return std::distance(imeisvFeatControl.entries, it);
}

/****************************************************
 * @brief      This function converts numOfBytes in the range [startIndex, startIndex + numOfBytes) from BCD to binary
 *             In case of invalid indices it returns UINT64_T MAX
 * @param[in]  imeisvContainer : reference to structure containing a byte array representing masked IMEISV
 * @param[in]  startIndex      : index at which the range of bytes to convert starts
 * @param[in]  numOfBytes      : number of bytes to take into account when converting
 * @return     binary number converted from the bytes, uint64_t
 ****************************************************/
uint64_t FnVCCB_ConvertMaskedIMEISVBytesToNumber(const VccbMaskedIMEISV_type& imeisvContainer, std::size_t startIndex, std::size_t numOfBytes)
{
    AUTO_TRACE_FUNC;

    if (startIndex >= MASKED_IMEISV_BUF_SIZE) return std::numeric_limits<uint64_t>::max();
    if (startIndex + numOfBytes > MASKED_IMEISV_BUF_SIZE) return std::numeric_limits<uint64_t>::max();
    uint64_t converted = 0;
    for (std::size_t index = startIndex; index < startIndex + numOfBytes; index++)
    {
        uint8_t byte = imeisvContainer.value[index];
        converted *= 100;
        converted += ((byte & 0xF0) >> 4) * 10U;
        converted += (byte & 0x0F);
    }
    return converted;
}

/****************************************************
 * @brief      This function obtains the index of IMEISV Feat Control entry matching the TAC, SVN pair of the input callInfo_type
 * @param[in]  call : reference to callInfo
 * @return     index of found IMEISV Feat Control Entry or MAX_IMEISV_FEATURE_CONTROL_INFORMATION_ENTRIES
 *             return type is decltype(std::distance())
 ****************************************************/
int64_t FnVCCB_FindIMEISVFeatureControlInfoEntryIndexForCall(const callInfo_type& call)
{
    AUTO_TRACE_FUNC;

    constexpr uint8_t clearSnrMaskAsArrray[] = {0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0xFF};
    if (!call.ueInfo.imeisvBuf.maskedIMEISVPresent)
    {
        return MAX_IMEISV_FEATURE_CONTROL_INFORMATION_ENTRIES;
    }
    uint64_t clearSnrMask = 0;
    // To be independent from endianness
    memcpy(&clearSnrMask, clearSnrMaskAsArrray, sizeof(uint64_t));

    uint64_t callMaskedImeisv = 0;
    memcpy(&callMaskedImeisv, call.ueInfo.imeisvBuf.maskedIMEISV.value, sizeof(uint64_t));
    callMaskedImeisv &= clearSnrMask;

    return FnVCCB_FindIMEISVFeatureControlInfoEntryIndex(callMaskedImeisv);
}

/****************************************************
 * @brief      This function obtains the Feature Support flags matching the TAC, SVN pair of the input callInfo_type
 * @param[in]  call : reference to callInfo
 * @return     std::optional<ImeisvFeatureSupport_type> - nullopt if not found, optional value otherwise
 ****************************************************/
std::optional<ImeisvFeatureSupport_type> FnVCCB_GetIMEISVFeatureSupportForCall(const callInfo_type& call)
{
    AUTO_TRACE_FUNC;

    if (!CFG->imeisvFeatControlInfo.featureControlEnabled)
    {
        return std::nullopt;
    }

    const int64_t entryIndex = FnVCCB_FindIMEISVFeatureControlInfoEntryIndexForCall(call);
    if (MAX_IMEISV_FEATURE_CONTROL_INFORMATION_ENTRIES <= entryIndex)
    {
        return std::nullopt;
    }

    return CFG->imeisvFeatControlInfo.entries[entryIndex].featureSupport;
}

// End of file
