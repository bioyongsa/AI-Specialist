#include "ComRrcUnpackMgr.h"
#include "ComInclude.h"

#include "nrrrcUnpack.h"

#ifdef VCCB_IPC_TEST
uint64_t RrcUnpackMgr::unpackCount;

/**
 * @brief This function returns the current unpack count.
 *
 * @return uint64_t The current unpack count.
 */
uint64_t RrcUnpackMgr::getUnpackCount(void) { return unpackCount; }

/**
 * @brief This function sets the unpack count to the specified value.
 *
 * @param cnt The value to set the unpack count to.
 */
void RrcUnpackMgr::setUnpackCount(uint64_t cnt) { unpackCount = cnt; }

/**
 * @brief This function increments the unpack count by 1.
 */
void RrcUnpackMgr::incUnpackCount(void) { unpackCount++; }
#endif

/**
 * @brief This function is used to get the transaction ID based on the usage, PDU number, and length values.
 *
 * @param usage Indicates whether the transaction ID is being used or not.
 * @param pduNum The PDU number of the message.
 * @param length The length of the message.
 *
 * @return Returns the calculated transaction ID.
 */
uint32_t RrcUnpackMgr::getTransactionId(bool usage, bool isEutra, uint16_t pduNum, uint16_t length)
{
    // Create a temporary buffer to store the transaction ID values
    RrcUnpackMgrDBTransactionId_type tmpBuff;

    // Set the usage bit in the temporary buffer
    SET_BITFIELD_N(tmpBuff.usage, usage, e_BitMask_1bit);

    // Set the RatType in the temporary buffer
    SET_BITFIELD_N(tmpBuff.isEutra, isEutra, e_BitMask_1bit);

    // Set the PDU number in the temporary buffer
    SET_BITFIELD_N(tmpBuff.pduNum, pduNum, e_BitMask_14bit);

    // Set the length in the temporary buffer
    tmpBuff.length = (length & UINT16_MAX);

    // Return the calculated transaction ID
    return tmpBuff.transactionId;
};

/**
 * @brief Returns the unpack buffer for the given call thread ID.
 *
 * @param threadId The call thread ID.
 * @return msgUnpack_type* The unpack buffer for the call thread.
 */
msgUnpack_type *RrcUnpackMgr::GetUnpackBuffer(uint8_t threadId)
{
    // Check if the thread ID is within the valid range and return if it's not
    VCCB_CHECK_E_RANGE_AND_NULL(threadId, MAX_CALL_THREAD_NUM_VCCB);

    // Get the unpack buffer for the call thread
    RrcUnpackMgrDB_type *ptBuffer = GetUnpackMgrBuffer(threadId);
    VALID_E_POINT_CHECK_NULL(ptBuffer);

    return &ptBuffer->data;
}

/**
 * @brief This function retrieves the RRC unpack manager buffer for the given thread ID.
 *
 * @param threadId The thread ID for which the buffer is required.
 * @return RrcUnpackMgrDB_type* A pointer to the RRC unpack manager buffer for the given thread ID.
 */
RrcUnpackMgrDB_type *RrcUnpackMgr::GetUnpackMgrBuffer(uint8_t threadId)
{
    // Check if the thread ID is within the valid range and return if it's not
    VCCB_CHECK_E_RANGE_AND_NULL(threadId, MAX_CALL_THREAD_NUM_VCCB);

    return &THREAD_INFO->call[threadId].buf.unpack.rrc;
}

/**
 * @brief Initializes the unpack buffer for the given call thread ID.
 *
 * @param threadId The call thread ID.
 */
void RrcUnpackMgr::Init(uint8_t threadId)
{
    // Check if the thread ID is within the valid range and return if it's not
    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);

    // Get the unpack buffer for the call thread
    RrcUnpackMgrDB_type *ptBuffer = GetUnpackMgrBuffer(threadId);
    VALID_E_POINT_CHECK_VOID(ptBuffer);

    // Ignore the message if the unpack buffer is already in clear
    if (ptBuffer->id.transactionId == 0) return;

    // Reset the transaction ID to 0
    ptBuffer->id.transactionId = 0;

    // Reset the unpack offset to 0
    ptBuffer->data.unpackMsgOffset = 0;
}

/**
 * @brief Unpacks the given NRRRC message into the unpack buffer for the given call thread ID.
 *
 * This function unpacks the given NRRRC message into the unpack buffer for the specified call thread ID. It uses the
 * provided PDU number and encoded message buffer to determine which message to unpack. The unpack buffer is initialized
 * before unpacking if forced unpacking is enabled or the debug flag is off.
 *
 * @param threadId The call thread ID.
 * @param pduNum The PDU number of the NRRRC message.
 * @param pEnc The encoded message buffer.
 * @param len The length of the encoded message buffer.
 * @param isForcedUnpack If true, the unpack buffer will be initialized before unpacking the message.
 * @param isEutra If true, the message is an EUTRA RRC message.
 * @return int16_t Returns GOOD if the message is successfully unpacked, ERROR otherwise.
 */
int16_t RrcUnpackMgr::Unpack(
    uint8_t threadId, uint16_t pduNum, unsigned char *pEnc, long len, bool isForcedUnpack, bool isEutra)
{
    // Check if the thread ID is within the valid range and return an error if it's not
    VCCB_CHECK_E_RANGE_AND_RETURN(threadId, MAX_CALL_THREAD_NUM_VCCB);

    // Get the unpack buffer for the call thread
    RrcUnpackMgrDB_type *ptBuffer = GetUnpackMgrBuffer(threadId);
    msgUnpack_type *ptUnpack = GetUnpackBuffer(threadId);

    VALID_E_POINT_CHECK_ERROR_PARAM2(ptBuffer, ptUnpack);

    // Determine whether to use the legacy algorithm(Leagacy or Forced) or the enhanced algorithm
    const bool isLegacyAlgorithm = (isForcedUnpack == true || DBG->flag.RrcUnpackMgr == VCCB_FLAG_OFF);
    const bool isEnhancedAlgorithm = !isLegacyAlgorithm;

    // Define a lambda function to unpack the message and check the result
    auto procUnpack = [&](short (*pFunc)(msgUnpack_type *, unsigned char *, long), const char *pFuncName) -> int16_t
    {
        uint32_t transId = 0;

        if (isEnhancedAlgorithm == true)
        {
            // Calculate the transaction ID based on the usage, PDU number, and length values
            transId = getTransactionId(true, isEutra, pduNum, static_cast<uint16_t>(len));

            // If the unpack buffer already contains the desired PDU, return GOOD
            if (ptBuffer->id.transactionId == transId) return GOOD;
        }

        // Unpack the message using the specified function
        int16_t status = pFunc(ptUnpack, pEnc, len);

#ifdef VCCB_IPC_TEST
        incUnpackCount();
#endif

        // Check the unpack status and handle errors
        switch (status)
        {
            // If the unpacking is successful, update the transaction ID and return GOOD
            case GOOD:
                if (isEnhancedAlgorithm == true)
                {
                    ptBuffer->id.transactionId = transId;
                }
                return GOOD;

            // If there is an error during unpacking, print an error message and return ERROR
            default:
                VCCB_PRINTF_ERR("%s ERROR(ret:%d)\n", pFuncName, status);
                return ERROR;
        }
    };

    // If forced unpacking is enabled or the debug flag is off, initialize the unpack buffer
    if (isLegacyAlgorithm == true)
    {
        if (ptBuffer->id.transactionId != 0)
        {
            Init(threadId);
        }
    }

#define UNPACK_PDU(_pduNum, _func) \
    case _pduNum:                  \
        return procUnpack(_func, #_func)

    if (isEutra)  // EUTRA
    {
        // Switch statement to handle different PDU numbers
        switch (pduNum)
        {
            // If the PDU number is unknown, print an error message and return ERROR
            default:
                VCCB_PRINTF_ERR("Unknown PDU(EUTRA, %d)\n", pduNum);
                return ERROR;
        }
    }
    else  // NR
    {
        // Switch statement to handle different PDU numbers
        switch (pduNum)
        {
            // Unpack the HandoverPreparationInformation PDU and call the procUnpack lambda function
            UNPACK_PDU(NRRRC_HandoverPreparationInformation_PDU, UnpackNRRRC_HandoverPreparationInformation);
            // Unpack the NRRRC_CG_ConfigInfo PDU and call the procUnpack lambda function
            UNPACK_PDU(NRRRC_CG_ConfigInfo_PDU, UnpackNRRRC_CG_ConfigInfo);

            /* Message based PDU */
            case NRRRC_BCCH_BCH_Message_PDU:
            case NRRRC_BCCH_DL_SCH_Message_PDU:
            case NRRRC_DL_CCCH_Message_PDU:
            case NRRRC_DL_DCCH_Message_PDU:
            case NRRRC_MCCH_Message_r17_PDU:
            case NRRRC_PCCH_Message_PDU:
            case NRRRC_UL_CCCH_Message_PDU:
            case NRRRC_UL_CCCH1_Message_PDU:
            case NRRRC_UL_DCCH_Message_PDU:
            case NRRRC_SBCCH_SL_BCH_Message_PDU:
            case NRRRC_SCCH_Message_PDU:
                VCCB_PRINTF_ERR("Not Allowed PDU(Message Based PDU, %d)\n", pduNum);
                return ERROR;

            // If the PDU number is unknown, print an error message and return ERROR
            default:
                VCCB_PRINTF_ERR("Unknown PDU(NR, %d)\n", pduNum);
                return ERROR;
        }
    }

#undef UNPACK_PDU
}

/**
 * @brief This function unpacks the given RRC message using the NRRRC library.
 *
 * @param threadId The thread ID of the calling function.
 * @param pduNum The PDU number of the RRC message to be unpacked.
 * @param pEnc The encoded RRC message buffer.
 * @param len The length of the encoded RRC message buffer.
 * @param isForcedUnpack If true, the unpacking process will be forced even if the message is already unpacked.
 * @return int16_t Returns GOOD if the unpacking is successful, otherwise returns ERROR.
 */
int16_t RrcUnpackMgr::NrUnpack(uint8_t threadId, uint16_t pduNum, unsigned char *pEnc, long len, bool isForcedUnpack)
{
    return Unpack(threadId, pduNum, pEnc, len, isForcedUnpack, false /*NR*/);
}

/**
 * @brief Unpacks the given E-UTRA encoded message using the NRRRC library.
 *
 * @param threadId The thread ID of the calling thread.
 * @param pduNum The PDU number of the message to unpack.
 * @param pEnc The encoded message buffer.
 * @param len The length of the encoded message buffer.
 * @param isForcedUnpack If true, the unpacking process will be forced even if the message is already unpacked.
 * @return int16_t Returns GOOD if the unpacking is successful, otherwise returns ERROR.
 */
int16_t RrcUnpackMgr::EutraUnpack(uint8_t threadId, uint16_t pduNum, unsigned char *pEnc, long len, bool isForcedUnpack)
{
    return Unpack(threadId, pduNum, pEnc, len, isForcedUnpack, true /*EUTRA*/);
}

/**
 * @brief This function retrieves the pointer to the unpacked NRRRC_HandoverPreparationInformation structure from the
 * unpack buffer.
 *
 * @param threadId The thread ID of the current thread.
 * @return NRRRC_HandoverPreparationInformation* Pointer to the unpacked NRRRC_HandoverPreparationInformation structure.
 */
NRRRC_HandoverPreparationInformation *RrcUnpackMgr::GetNrHandoverPreparationInformation(uint8_t threadId)
{
    // Check if the thread ID is within the valid range and return an error if it's not
    VCCB_CHECK_E_RANGE_AND_NULL(threadId, MAX_CALL_THREAD_NUM_VCCB);

    msgUnpack_type *ptUnpack = RrcUnpackMgr::GetUnpackBuffer(threadId);
    VALID_E_POINT_CHECK_NULL(ptUnpack);

    return reinterpret_cast<NRRRC_HandoverPreparationInformation *>(&ptUnpack->unpack[0] + ptUnpack->unpackMsgOffset);
}

/**
 * @brief This function retrieves the pointer to the unpacked NRRRC_CG_ConfigInfo structure from the
 * unpack buffer.
 *
 * @param threadId The thread ID of the current thread.
 * @return NRRRC_CG_ConfigInfo* Pointer to the unpacked NRRRC_CG_ConfigInfo structure.
 */
NRRRC_CG_ConfigInfo *RrcUnpackMgr::GetNrCGConfigInfo(uint8_t threadId)
{
    // Check if the thread ID is within the valid range and return an error if it's not
    VCCB_CHECK_E_RANGE_AND_NULL(threadId, MAX_CALL_THREAD_NUM_VCCB);

    msgUnpack_type *ptUnpack = RrcUnpackMgr::GetUnpackBuffer(threadId);
    VALID_E_POINT_CHECK_NULL(ptUnpack);

    return reinterpret_cast<NRRRC_CG_ConfigInfo *>(&ptUnpack->unpack[0] + ptUnpack->unpackMsgOffset);
}
