/**
 * @file     : VccbStructCppInterface.cpp
 * @brief    : source file for operators defined for objects from VccbStruct.h
 *
 * @author   : m.ciurej@samsung.com
 * @date     : 2022/02/10
 *
 * Copyright 2022 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information). One
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * one entered into with Samsung.
 */

#include "VccbStructCppInterface.hpp"
#include "VccbStructCInterface.h"
#include "ComGlobalData.h"
#include "ComLibIpcApi.h"
#include "ComAutoNtrace.hpp"

/****************************************************************************
 * @brief           Checks if two objects of smtc1_type are equal.
 *
 * @param[in]       first : First object. / smtc1_type&
 * @param[in]       second : Second object. / smtc1_type&
 * @return          The result of comparison. / bool
 ****************************************************************************/
bool operator==(const smtc1_type &first, const smtc1_type &second)
{
    AUTO_TRACE_FUNC;

    return first.periodicityAndOffset.periodicity == second.periodicityAndOffset.periodicity &&
           first.periodicityAndOffset.offset == second.periodicityAndOffset.offset &&
           first.duration == second.duration;
}

/****************************************************************************
 * @brief           Checks if two objects of smtc1_type are different.
 *
 * @param[in]       first : First object. / smtc1_type&
 * @param[in]       second : Second object. / smtc1_type&
 * @return          The result of comparison. / bool
 ****************************************************************************/
bool operator!=(const smtc1_type &first, const smtc1_type &second)
{
    AUTO_TRACE_FUNC;

    return !(first == second);
}

/****************************************************************************
 * @brief           Checks relation between two smtc1_type objects.
 *
 * @param[in]       first : First object. / smtc1_type&
 * @param[in]       second : Second object. / smtc1_type&
 * @return          The result of comparison. / bool
 ****************************************************************************/
bool operator<(const smtc1_type &first, const smtc1_type &second)
{
    AUTO_TRACE_FUNC;

    if (first.periodicityAndOffset.periodicity < second.periodicityAndOffset.periodicity)
    {
        return true;
    }
    if ((first.periodicityAndOffset.periodicity == second.periodicityAndOffset.periodicity) &&
        (first.periodicityAndOffset.offset < second.periodicityAndOffset.offset))
    {
        return true;
    }
    if ((first.periodicityAndOffset.periodicity == second.periodicityAndOffset.periodicity) &&
        (first.periodicityAndOffset.offset == second.periodicityAndOffset.offset) && (first.duration < second.duration))
    {
        return true;
    }

    return false;
}

/****************************************************************************
 * @brief           Checks if two smtc2_type objects are different.
 *
 * @param[in]       first : First object. / smtc2_type&
 * @param[in]       second : Second object. / smtc2_type&
 * @return          The result of comparison. / bool
 ****************************************************************************/
bool operator!=(const smtc2_type &first, const smtc2_type &second)
{
    AUTO_TRACE_FUNC;

    if (first.usage != second.usage)
    {
        return true;
    }

    if (first.usage == CI_use)
    {
        if (first.numPCIs != second.numPCIs)
        {
            return true;
        }

        for (uint8_t i = 0; (i < first.numPCIs) && (i < MAX_NUM_OF_PCIS_SMTC2); ++i)
        {
            if (first.PCIs[i] != second.PCIs[i])
            {
                return true;
            }
        }

        if (first.smtc2Periodicity != second.smtc2Periodicity)
        {
            return true;
        }
    }

    return false;
}

/****************************************************************************
 * @brief           Checks if two ssbMeasurementConfiguration objects are
 *                  different.
 *
 * @param[in]       first : First object. / ssbMeasurementConfiguration_type&
 * @param[in]       second : Second object. / ssbMeasurementConfiguration_type&
 * @return          The result of comparison. / bool
 ****************************************************************************/
bool operator!=(const ssbMeasurementConfiguration_type &first, const ssbMeasurementConfiguration_type &second)
{
    AUTO_TRACE_FUNC;

    if (first.usage != second.usage)
    {
        return true;
    }

    if (first.usage == CI_use)
    {
        if (first.ssbToMeasure != second.ssbToMeasure)
        {
            return true;
        }

        switch (first.ssbToMeasure)
        {
            case ssbToMeasure_shortBitmap:  // 4 bits
                if ((first.ssbValue & 0xF) != (second.ssbValue & 0xF))
                {
                    return true;
                }
                break;

            case ssbToMeasure_mediumBitmap:  // 8 bits
                if ((first.ssbValue & 0xFF) != (second.ssbValue & 0xFF))
                {
                    return true;
                }
                break;

            case ssbToMeasure_longBitmap:  // 64 bits
                if (first.ssbValue != second.ssbValue)
                {
                    return true;
                }
                break;

            default:
                VCCB_PRINT_ERROR("ERROR: Invalid bitmap type chosen (%d) in ssbMeasurementConfiguration comparison!\n",
                    first.ssbToMeasure);
                break;
        }
    }

    return false;
}

/****************************************************************************
 * @brief           Checks if two ssbConfigMobilityUe_type objects are
 *                  different.
 *
 * @param[in]       first : First object. / ssbConfigMobilityUe_type&
 * @param[in]       second : Second object. / ssbConfigMobilityUe_type&
 * @return          The result of comparison. / bool
 ****************************************************************************/
bool operator!=(const ssbConfigMobilityUe_type &first, const ssbConfigMobilityUe_type &second)
{
    AUTO_TRACE_FUNC;

    if (first.usage != second.usage)
    {
        return true;
    }

    if (first.usage == CI_use)
    {
        if (first.ssbMeasurementConfiguration != second.ssbMeasurementConfiguration)
        {
            return true;
        }

        if (first.deriveSSB_IndexFromCell != second.deriveSSB_IndexFromCell)
        {
            return true;
        }
    }

    return false;
}

/****************************************************************************
 * @brief           Checks if two thresholdNR_type objects are different.
 *
 * @param[in]       first : First object. / thresholdNR_type&
 * @param[in]       second : Second object. / thresholdNR_type&
 * @return          The result of comparison. / bool
 ****************************************************************************/
bool operator!=(const thresholdNR_type &first, const thresholdNR_type &second)
{
    AUTO_TRACE_FUNC;

    if (first.thresholdRSRP.usage != second.thresholdRSRP.usage)
    {
        return true;
    }
    if (first.thresholdRSRP.usage == CI_use)
    {
        if (first.thresholdRSRP.value != second.thresholdRSRP.value)
        {
            return true;
        }
    }
    if (first.thresholdRSRQ.usage != second.thresholdRSRQ.usage)
    {
        return true;
    }
    if (first.thresholdRSRQ.usage == CI_use)
    {
        if (first.thresholdRSRQ.value != second.thresholdRSRQ.value)
        {
            return true;
        }
    }
    if (first.thresholdSINR.usage != second.thresholdSINR.usage)
    {
        return true;
    }
    if (first.thresholdSINR.usage == CI_use)
    {
        if (first.thresholdSINR.value != second.thresholdSINR.value)
        {
            return true;
        }
    }

    return false;
}

/****************************************************************************
 * @brief           Checks if two csi_rs_ResourceMobility_type objects
 *                  are different.
 *
 * @param[in]       first : First object. / csi_rs_ResourceMobility_type&
 * @param[in]       second : Second object. / csi_rs_ResourceMobility_type&
 * @return          The result of comparison. / bool
 ****************************************************************************/
bool operator!=(const csi_rs_ResourceMobility_type &first, const csi_rs_ResourceMobility_type &second)
{
    AUTO_TRACE_FUNC;

    if (first.csi_RS_Index != second.csi_RS_Index)
    {
        return true;
    }
    if (first.slotConfig.slotConfigLength != second.slotConfig.slotConfigLength)
    {
        return true;
    }
    if (first.slotConfig.value != second.slotConfig.value)
    {
        return true;
    }
    if (first.associatedSsb.usage != second.associatedSsb.usage)
    {
        return true;
    }
    if (first.associatedSsb.usage == CI_use)
    {
        if (first.associatedSsb.ssbIndex != second.associatedSsb.ssbIndex)
        {
            return true;
        }
        if (first.associatedSsb.isQuasiColocated != second.associatedSsb.isQuasiColocated)
        {
            return true;
        }
    }
    if (first.frequencyDomainAllocation.choice != second.frequencyDomainAllocation.choice)
    {
        return true;
    }
    if (first.frequencyDomainAllocation.value != second.frequencyDomainAllocation.value)
    {
        return true;
    }
    if (first.firstOFDMSymbolInTimeDomain != second.firstOFDMSymbolInTimeDomain)
    {
        return true;
    }
    if (first.sequenceGenerationConfig != second.sequenceGenerationConfig)
    {
        return true;
    }

    return false;
}

/****************************************************************************
 * @brief           Checks if two csi_rs_CellMobility_type objects
 *                  are different.
 *
 * @param[in]       first : First object. / csi_rs_CellMobility_type&
 * @param[in]       second : Second object. / csi_rs_CellMobility_type&
 * @return          The result of comparison. / bool
 ****************************************************************************/
bool operator!=(const csi_rs_CellMobility_type &first, const csi_rs_CellMobility_type &second)
{
    AUTO_TRACE_FUNC;

    if (first.pci != second.pci)
    {
        return true;
    }
    if (first.measurementBw.nrOfPrbs != second.measurementBw.nrOfPrbs)
    {
        return true;
    }
    if (first.measurementBw.startPrb != second.measurementBw.startPrb)
    {
        return true;
    }
    if (first.density != second.density)
    {
        return true;
    }
    if (first.csi_rs_ResourceList_Mobility.numItems != second.csi_rs_ResourceList_Mobility.numItems)
    {
        return true;
    }

    for (uint8_t i = 0; (i < first.csi_rs_ResourceList_Mobility.numItems) && (i < MAX_NR_OF_CSI_RS_RESOURCES_RRM); ++i)
    {
        if (first.csi_rs_ResourceList_Mobility.items[i] != second.csi_rs_ResourceList_Mobility.items[i])
        {
            return true;
        }
    }

    return false;
}

/****************************************************************************
 * @brief           Checks if two qOffsetSSBRangeList_type objects are
 *                  different.
 *
 * @param[in]       first : First object. / qOffsetSSBRangeList_type&
 * @param[in]       second : Second object. / qOffsetSSBRangeList_type&
 * @return          The result of comparison. / bool
 ****************************************************************************/
bool operator!=(const qOffsetSSBRangeList_type &first, const qOffsetSSBRangeList_type &second)
{
    AUTO_TRACE_FUNC;

    if (first.rsrpOffsetSSB != second.rsrpOffsetSSB)
    {
        return true;
    }
    if (first.rsrqOffsetSSB != second.rsrqOffsetSSB)
    {
        return true;
    }
    if (first.sinrOffsetSSB != second.sinrOffsetSSB)
    {
        return true;
    }

    return false;
}

/****************************************************************************
 * @brief           Checks if two reportQuantity_type objects are different.
 *
 * @param[in]       first : First object. / reportQuantity_type&
 * @param[in]       second : Second object. / reportQuantity_type&
 * @return          the result of comparison. / bool
 ****************************************************************************/
bool operator!=(const reportQuantity_type &first, const reportQuantity_type &second)
{
    AUTO_TRACE_FUNC;

    if (first.rsrp != second.rsrp)
    {
        return true;
    }
    if (first.rsrq != second.rsrq)
    {
        return true;
    }
    if (first.sinr != second.sinr)
    {
        return true;
    }

    return false;
}

/****************************************************************************
 * @brief           Checks if two cellToMeasure_type objects are different.
 *
 * @param[in]       first : First object. / cellToMeasure_type&
 * @param[in]       second : Second object. / cellToMeasure_type&
 * @return          The result of comparison. / bool
 ****************************************************************************/
bool operator!=(const cellToMeasure_type &first, const cellToMeasure_type &second)
{
    AUTO_TRACE_FUNC;

    if (first.pci != second.pci)
    {
        return true;
    }
    if (first.cellIndividualOffset != second.cellIndividualOffset)
    {
        return true;
    }

    return false;
}

/****************************************************************************
 * @brief           Checks if two sMeasure_type objects are different.
 *
 * @param[in]       first : First object. / sMeasure_type&
 * @param[in]       second : Second object. / sMeasure_type&
 * @return          The result of comparison. / bool
 ****************************************************************************/
bool operator!=(const sMeasure_type &first, const sMeasure_type &second)
{
    AUTO_TRACE_FUNC;

    if (first.usage != second.usage)
    {
        return true;
    }
    if (first.usage == CI_use)
    {
        if (first.choice != second.choice)
        {
            return true;
        }
        if (first.value != second.value)
        {
            return true;
        }
    }

    return false;
}

/****************************************************************************
 * @brief           Checks if two filterConfig_type objects are
 *                  different.
 *
 * @param[in]       first : First object. / filterConfig_type&
 * @param[in]       second : Second object. / filterConfig_type&
 * @return          The result of comparison. / bool
 ****************************************************************************/
bool operator!=(const filterConfig_type &first, const filterConfig_type &second)
{
    AUTO_TRACE_FUNC;

    if (first.filterCoefficientRSRP != second.filterCoefficientRSRP)
    {
        return true;
    }
    if (first.filterCoefficientRSRQ != second.filterCoefficientRSRQ)
    {
        return true;
    }
    if (first.filterCoefficientSINR != second.filterCoefficientSINR)
    {
        return true;
    }

    return false;
}

/****************************************************************************
 * @brief           Checks if two quantityConfigRS_type objects are
 *                  different.
 *
 * @param[in]       first : First object. / quantityConfigRS_type&
 * @param[in]       second : Second object. / quantityConfigRS_type&
 * @return          The result of comparison. / bool
 ****************************************************************************/
bool operator!=(const quantityConfigRS_type &first, const quantityConfigRS_type &second)
{
    AUTO_TRACE_FUNC;

    if (first.usage != second.usage)
    {
        return true;
    }
    if (first.usage == CI_use)
    {
        if (first.ssbFilterConfig != second.ssbFilterConfig)
        {
            return true;
        }
        if (first.csRsFilterConfig != second.csRsFilterConfig)
        {
            return true;
        }
    }

    return false;
}

/****************************************************************************
 * @brief           Checks if two quantityConfigurationNR_type objects are
 *                  different.
 *
 * @param[in]       first : First object. / quantityConfigurationEUTRA_type&
 * @param[in]       second : Second object. / quantityConfigurationEUTRA_type&
 * @return          The result of comparison. / bool
 ****************************************************************************/
bool operator!=(const quantityConfigurationNR_type &first, const quantityConfigurationNR_type &second)
{
    AUTO_TRACE_FUNC;

    if (first.usage != second.usage)
    {
        return true;
    }
    if (first.usage == CI_use)
    {
        if (first.quantityConfigCell != second.quantityConfigCell)
        {
            return true;
        }
        if (first.quantityConfigRS_Index != second.quantityConfigRS_Index)
        {
            return true;
        }
    }

    return false;
}

/****************************************************************************
 * @brief           Checks if two quantityConfigurationEUTRA_type objects are
 *                  different.
 *
 * @param[in]       first : First object. / quantityConfigurationEUTRA_type&
 * @param[in]       second : Second object. / quantityConfigurationEUTRA_type&
 * @return          The result of comparison. / bool
 ****************************************************************************/
bool operator!=(const quantityConfigurationEUTRA_type &first, const quantityConfigurationEUTRA_type &second)
{
    AUTO_TRACE_FUNC;

    if (first.usage != second.usage)
    {
        return true;
    }
    if (first.usage == CI_use)
    {
        if (first.filterConfig != second.filterConfig)
        {
            return true;
        }
    }

    return false;
}

/****************************************************************************
 * @brief           Checks if two gapConfig_type objects are
 *                  different.
 *
 * @param[in]       first : First object. / quantityConfigRS_type&
 * @param[in]       second : Second object. / quantityConfigRS_type&
 * @return          The result of comparison. / bool
 ****************************************************************************/
bool operator!=(const gapConfig_type &first, const gapConfig_type &second)
{
    AUTO_TRACE_FUNC;

    if (first.gapOffset != second.gapOffset)
    {
        return true;
    }
    if (first.mgl != second.mgl)
    {
        return true;
    }
    if (first.mgrp != second.mgrp)
    {
        return true;
    }
    if (first.mgta != second.mgta)
    {
        return true;
    }
    if (first.m.refServCellIndicatorFlag != second.m.refServCellIndicatorFlag)
    {
        return true;
    }
    else if (VCCB_FLAG_ON == first.m.refServCellIndicatorFlag)
    {
        if (first.refServCellIndicator != second.refServCellIndicator)
        {
            return true;
        }
    }

    return false;
}

/****************************************************************************
 * @brief           Checks if two measGapConfig_type objects are
 *                  different.
 *
 * @param[in]       first : First object. / quantityConfigRS_type&
 * @param[in]       second : Second object. / quantityConfigRS_type&
 * @return          The result of comparison. / bool
 ****************************************************************************/
bool operator!=(const measGapConfig_type &first, const measGapConfig_type &second)
{
    AUTO_TRACE_FUNC;

    if (first.flag != second.flag)
    {
        return true;
    }
    if (VCCB_FLAG_ON == first.flag)
    {
        if (first.gapConfig != second.gapConfig)
        {
            return true;
        }
    }

    return false;
}

/****************************************************************************
 * @brief           Checks relation between two measurementObjectNRDu_type objects
 * @param[in]       lhs : First object.
 * @param[in]       rhs : Second object.
 * @return          The result of comparison
 ****************************************************************************/
bool operator<(const measurementObjectNRDu_type &lhs, const measurementObjectNRDu_type &rhs)
{
    AUTO_TRACE_FUNC;

    if (lhs.ssbFrequency < rhs.ssbFrequency)
    {
        return true;
    }
    if ((lhs.ssbFrequency == rhs.ssbFrequency) && (lhs.ssbSubcarrierSpacing < rhs.ssbSubcarrierSpacing))
    {
        return true;
    }
    if ((lhs.ssbFrequency == rhs.ssbFrequency) && (lhs.ssbSubcarrierSpacing == rhs.ssbSubcarrierSpacing) &&
        (lhs.smtc1 < rhs.smtc1))
    {
        return true;
    }
    return false;
}

/****************************************************************************
 * @brief           Checks relation between two measurementObjectNRDu_type objects
 * @param[in]       lhs : First object.
 * @param[in]       rhs : Second object.
 * @return          The result of comparison
 ****************************************************************************/
bool operator<(const measurementObjectEUTRADu_type &lhs, const measurementObjectEUTRADu_type &rhs)
{
    AUTO_TRACE_FUNC;

    if (lhs.overlappedCarrierFreq < rhs.overlappedCarrierFreq)
    {
        return true;
    }
    if ((lhs.overlappedCarrierFreq == rhs.overlappedCarrierFreq) &&
        (lhs.allowedMeasBandwidth < rhs.allowedMeasBandwidth))
    {
        return true;
    }
    if ((lhs.overlappedCarrierFreq == rhs.overlappedCarrierFreq) &&
        (lhs.allowedMeasBandwidth == rhs.allowedMeasBandwidth) && (lhs.presenceAntennaPort1 < rhs.presenceAntennaPort1))
    {
        return true;
    }
    if ((lhs.overlappedCarrierFreq == rhs.overlappedCarrierFreq) &&
        (lhs.allowedMeasBandwidth == rhs.allowedMeasBandwidth) &&
        (lhs.presenceAntennaPort1 == rhs.presenceAntennaPort1) && (lhs.widebandRSRQMeas < rhs.widebandRSRQMeas))
    {
        return true;
    }
    return false;
}

/****************************************************************************
 * @brief           Checks relation between two measurementObjectDu_type objects
 * @param[in]       lhs : First object.
 * @param[in]       rhs : Second object.
 * @return          The result of comparison. / bool
 ****************************************************************************/
bool operator<(const measurementObjectDu_type &lhs, const measurementObjectDu_type &rhs)
{
    AUTO_TRACE_FUNC;

    if (lhs.objectId < rhs.objectId)
    {
        return true;
    }
    if ((lhs.objectId == rhs.objectId) && (lhs.ratType < rhs.ratType))
    {
        return true;
    }
    if ((lhs.objectId == rhs.objectId) && (lhs.ratType == rhs.ratType))
    {
        if (measRatNr == lhs.ratType)
        {
            if (lhs.rat.nr < rhs.rat.nr)
            {
                return true;
            }
        }
        else if (measRatEutra == lhs.ratType)
        {
            if (lhs.rat.eutra < rhs.rat.eutra)
            {
                return true;
            }
        }
    }
    return false;
}

/****************************************************************************
 * @brief           Checks if two measurementObjectNRDu_type objects are different.
 * @param[in]       lhs : First object.
 * @param[in]       rhs : Second object.
 * @return          The result of comparison
 ****************************************************************************/
bool operator!=(const measurementObjectNRDu_type &lhs, const measurementObjectNRDu_type &rhs)
{
    AUTO_TRACE_FUNC;

    return ((lhs.ssbFrequency != rhs.ssbFrequency) || (lhs.ssbSubcarrierSpacing != rhs.ssbSubcarrierSpacing) ||
            (lhs.smtc1 != rhs.smtc1));
}

/****************************************************************************
 * @brief           Checks if two measurementObjectNRDu_type objects are different.
 * @param[in]       lhs : First object.
 * @param[in]       rhs : Second object.
 * @return          The result of comparison
 ****************************************************************************/
bool operator!=(const measurementObjectEUTRADu_type &lhs, const measurementObjectEUTRADu_type &rhs)
{
    AUTO_TRACE_FUNC;

    return ((lhs.overlappedCarrierFreq != rhs.overlappedCarrierFreq) ||
            (lhs.allowedMeasBandwidth != rhs.allowedMeasBandwidth) ||
            (lhs.presenceAntennaPort1 != rhs.presenceAntennaPort1) || (lhs.widebandRSRQMeas != rhs.widebandRSRQMeas));
}

bool operator==(const timerT312_type &lhs, const timerT312_type &rhs)
{
    return (lhs.useT312 == rhs.useT312) && (!lhs.useT312 || (lhs.timerT312 == rhs.timerT312));
}

bool operator!=(const timerT312_type &lhs, const timerT312_type &rhs) { return !(lhs == rhs); }

bool operator==(const blackCellsUe_type &first, const blackCellsUe_type &second)
{
    if (first.numItems > MAX_NR_OF_PCI_RANGES)
    {
        VCCB_PRINT_ERROR(
            "ERROR: Installed configuration: incorrect number of blacklisted cells (%hu) in "
            "VCCB_CheckIfMeasObjectChanged, allowed "
            "range %d - %d!\n",
            first.numItems, 0, MAX_NR_OF_PCI_RANGES);
    }

    if (second.numItems > MAX_NR_OF_PCI_RANGES)
    {
        VCCB_PRINT_ERROR(
            "ERROR: New configuration: incorrect number of blacklisted cells (%hu) in VCCB_CheckIfMeasObjectChanged, "
            "allowed range "
            "%d - %d!\n",
            second.numItems, 0, MAX_NR_OF_PCI_RANGES);
    }

    if (first.numItems != second.numItems)
    {
        return false;
    }
    for (uint8_t i = 0; i < MIN(MAX_NR_OF_PCI_RANGES, first.numItems); i++)
    {
        bool copyFound = false;
        for (uint8_t j = 0; j < MIN(MAX_NR_OF_PCI_RANGES, second.numItems); j++)
        {
            if (first.rangeElements[i].pciRangeIndex == second.rangeElements[j].pciRangeIndex &&
                first.rangeElements[i].pciRange == second.rangeElements[j].pciRange)
            {
                copyFound = true;
                break;
            }
        }
        if (!copyFound)
        {
            return false;
        }
    }
    return true;
}

bool operator==(const blackCellsEutra_type &first, const blackCellsEutra_type &second)
{
    const auto maxRangeElements = VCCB_ARRAY_COUNT(first.rangeElements);
    if (first.numItems > maxRangeElements)
    {
        VCCB_PRINT_ERROR(
            "ERROR: Installed configuration: incorrect number of blacklisted cells eutra (%hu), "
            "allowed range %d - %lu!\n",
            first.numItems, 0, maxRangeElements);
    }

    if (second.numItems > maxRangeElements)
    {
        VCCB_PRINT_ERROR(
            "ERROR: New configuration: incorrect number of blacklisted cells eutra (%hu), "
            "allowed range "
            "%d - %lu!\n",
            second.numItems, 0, maxRangeElements);
    }

    if (first.numItems != second.numItems)
    {
        return false;
    }
    for (uint8_t i = 0; i < MIN(maxRangeElements, first.numItems); i++)
    {
        bool copyFound = false;
        for (uint8_t j = 0; j < MIN(maxRangeElements, second.numItems); j++)
        {
            if (first.rangeElements[i].cellIndexEutra == second.rangeElements[j].cellIndexEutra &&
                first.rangeElements[i].physCellIdRange == second.rangeElements[j].physCellIdRange)
            {
                copyFound = true;
                break;
            }
        }
        if (!copyFound)
        {
            return false;
        }
    }
    return true;
}

bool operator<(const upmCgi_type &a, const upmCgi_type &b)
{
    if (a.rat < b.rat) return true;
    if (a.rat > b.rat) return false;
    return (a.cgi < b.cgi);
}

/**
 * @brief           Checks if two objects of measuredFrequencies_type are equal.
 *
 * @param[in]       first : First object. / measuredFrequencies_type&
 * @param[in]       second : Second object. / measuredFrequencies_type&
 * @return          The result of comparison. / bool
 */
bool operator==(const measuredFrequencies_type &first, const measuredFrequencies_type &second)
{
    AUTO_TRACE_FUNC;
    if (first.numItems != second.numItems)
    {
        return false;
    }
    for (uint8_t i = 0; i < first.numItems; i++)
    {
        if (first.frequencies[i] != second.frequencies[i])  // Assuming that frequencies have been ordered.
        {
            return false;
        }
    }
    return true;
}

bool operator<(const cgi_type &n1, const cgi_type &n2)
{
    AUTO_TRACE_FUNC;
    if (n1.plmn.s2.mcc < n2.plmn.s2.mcc) return true;
    if (n1.plmn.s2.mnc < n2.plmn.s2.mnc) return true;
    if ((VCOM_CheckPlmnIdentical(&n1.plmn, &n2.plmn) == TRUE) && (n1.ci < n2.ci)) return true;
    return false;
}

bool operator==(const measTriggerUe_type &first, const measTriggerUe_type &second)
{
    return first.quantity == second.quantity && first.value == second.value;
}
bool operator!=(const measTriggerUe_type &first, const measTriggerUe_type &second)
{
    return !(first == second);
}

bool operator==(const measDoubleTriggerUe_type &first, const measDoubleTriggerUe_type &second)
{
    return first.quantity == second.quantity && first.th1_value == second.th1_value &&
           first.th2_value == second.th2_value;
}

bool operator!=(const measDoubleTriggerUe_type &first, const measDoubleTriggerUe_type &second)
{
    return !(first == second);
}

bool operator==(const pciRange_type &first, const pciRange_type &second)
{
    if(first.pciStart == second.pciStart && first.pciType == second.pciType)
    {
        if(first.pciType == pciType_single)
        {
            return true;
        }
        else if(first.pciType == pciType_range && first.pciRange == second.pciRange)
        {
            return true;
        }
    }
    return false;
}

bool operator!=(const pciRange_type &first, const pciRange_type &second) { return !(first == second); }

bool operator==(const vccbGlobalGnbId_type &first, const vccbGlobalGnbId_type &second)
{
    return first.gnbId.id == second.gnbId.id && first.gnbId.idLength == second.gnbId.idLength &&
           first.plmn.longId == second.plmn.longId;
}

bool operator==(const TceAddress_type& lhs, const TceAddress_type& rhs)
{
    bool areEqual = false;

    if (lhs.ip.MdsIp.IpVer != rhs.ip.MdsIp.IpVer)
    {
        areEqual = false;
    }
    else if (lhs.ip.MdsIp.IpVer != TCE_FQDN &&
             MdsIp_TypeCmp(&lhs.ip.MdsIp, &rhs.ip.MdsIp) == 0 &&
            lhs.ip.MdsPort == rhs.ip.MdsPort)
    {
        areEqual = true;
    }
    else if (lhs.ip.MdsIp.IpVer == TCE_FQDN &&
             strcasecmp(lhs.fqdn, rhs.fqdn) == 0 &&
            lhs.ip.MdsPort == rhs.ip.MdsPort)
    {
        areEqual = true;
    }

    return areEqual;
}
bool operator!=(const TceAddress_type& lhs, const TceAddress_type& rhs)
{
    return !(lhs == rhs);
}

bool operator==(const optionalDelta_type &lhs, const optionalDelta_type &rhs)
{
    if (lhs.usage != rhs.usage)
    {
        return false;
    }
    if (lhs.usage == false && rhs.usage == false)
    {
        return true;
    }
    // else lhs.usage == true && rhs.usage == true
    return lhs.delta == rhs.delta;
}

bool operator==(const optionalDeltaPerTrigger_type &lhs, const optionalDeltaPerTrigger_type &rhs)
{
    return (lhs.trigger1Delta == rhs.trigger1Delta) && (lhs.trigger2Delta == rhs.trigger2Delta);
}

bool operator==(const fr1PowerClassSavedDeltas_type &lhs, const fr1PowerClassSavedDeltas_type &rhs)
{
    return (lhs.pc1SavedDelta == rhs.pc1SavedDelta) && (lhs.pc15SavedDelta == rhs.pc15SavedDelta) &&
           (lhs.pc2SavedDelta == rhs.pc2SavedDelta);
}

bool operator!=(const fr1PowerClassSavedDeltas_type &lhs, const fr1PowerClassSavedDeltas_type &rhs)
{
    return !(lhs == rhs);
}

bool operator==(const ssbMeasTiming_type &lhs, const ssbMeasTiming_type &rhs)
{
    return (lhs.ssbFrequency == rhs.ssbFrequency) && (lhs.ssbSubcarrierSpacing == rhs.ssbSubcarrierSpacing) &&
           (lhs.smtc1 == rhs.smtc1);
}

bool operator!=(const ssbMeasTiming_type &lhs, const ssbMeasTiming_type &rhs) { return !(lhs == rhs); }

bool operator==(const redirectionInfoEutra_type &lhs, const redirectionInfoEutra_type &rhs)
{
    return ((lhs.carrierFreq == rhs.carrierFreq) && (lhs.overlappedCarrierFreq == rhs.overlappedCarrierFreq));
}

bool operator<(const ImeisvFeatureControlInformationEntry_type& lhs, const ImeisvFeatureControlInformationEntry_type& rhs)
{
    return lhs.maskedImeisv < rhs.maskedImeisv;
}

bool operator!=(const UlGapFr2Config_type &lhs, const UlGapFr2Config_type &rhs)
{
    AUTO_TRACE_FUNC;

    if (lhs.usage != rhs.usage)
    {
        return true;
    }

    if (VCCB_FLAG_OFF == lhs.usage)
    {
        return false;
    }

    if ((lhs.refFR2_ServCellAsyncCA_present != rhs.refFR2_ServCellAsyncCA_present) ||
        (lhs.ugl != rhs.ugl) ||
        (lhs.ugrp != rhs.ugrp) ||
        (lhs.gapOffset != rhs.gapOffset))
    {
        return true;
    }

    if ((VCCB_FLAG_ON == lhs.refFR2_ServCellAsyncCA_present) &&
        (lhs.refFR2_ServCellAsyncCA != rhs.refFR2_ServCellAsyncCA))
    {
        return true;
    }

    return false;
}
