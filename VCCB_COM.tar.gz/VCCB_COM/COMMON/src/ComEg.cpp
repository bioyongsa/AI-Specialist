#include "ComEg.h"
#include "ComInclude.h"
#include "ComEgMgr.h"

void printGetEgInfoMenu(void)
{
    AUTO_TRACE_FUNC;

    LOGCMD("\n================================================================\n");
    LOGCMD("| GET EG(Event Gather) INFO \n");
    LOGCMD("================================================================\n");
    LOGCMD("| get eg info             : print eg information\n");
    LOGCMD("| get eg all              : print eg all(0-2) level log\n");
    LOGCMD("| get eg 1                : print eg 1-2      level log\n");
    LOGCMD("| get eg 2                : print eg 2        level log\n");
    LOGCMD("================================================================\n");
}

int getEgInfo(int32_t argc, char *argv[])
{
    AUTO_TRACE_FUNC;

    if (argc != 2)
    {
        printGetEgInfoMenu();
        return GOOD;
    }

    if (!strcasecmp(argv[1], "info"))
    {
        ComEgMgr::instance()->displayEgInfo();
    }
    else if (!strcasecmp(argv[1], "all"))
    {
        ComEgMgr::instance()->displayEglog(0);
    }
    else if (!strcasecmp(argv[1], "1"))
    {
        ComEgMgr::instance()->displayEglog(1);
    }
    else if (!strcasecmp(argv[1], "2"))
    {
        ComEgMgr::instance()->displayEglog(2);
    }
    else
    {
        printGetEgInfoMenu();
    }

    return GOOD;
}

void printSetEgInfoMenu(void)
{
    AUTO_TRACE_FUNC;

    LOGCMD("\n================================================================\n");
    LOGCMD("| SET EG(Event Gather) INFO \n");
    LOGCMD("================================================================\n");
    LOGCMD("| log eg clear            : clear eg log information\n");
    LOGCMD("| log eg flag on/off      : set eg flag  information\n");
    LOGCMD("| log eg level 0/1/2      : set eg level information\n");
    LOGCMD("================================================================\n");
}

int setEgInfo(int32_t argc, char *argv[])
{
    AUTO_TRACE_FUNC;

    if (argc < 2 || argc > 3)
    {
        printSetEgInfoMenu();
        return GOOD;
    }

    if (!strcasecmp(argv[1], "clear"))
    {
        ComEgMgr::instance()->clear();
        LOGCMD("\n EG Clear Complete\n");
    }
    else if (!strcasecmp(argv[1], "flag"))
    {
        if (!strcasecmp(argv[2], "on"))
        {
            ComEgMgr::instance()->setEgFlag(true);
        }
        else if (!strcasecmp(argv[2], "off"))
        {
            ComEgMgr::instance()->setEgFlag(false);
        }
        else
        {
            printSetEgInfoMenu();
        }
    }
    else if (!strcasecmp(argv[1], "level"))
    {
        if (!strcasecmp(argv[2], "0") || !strcasecmp(argv[2], "1") || !strcasecmp(argv[2], "2"))
        {
            int32_t egNewLevel = util::str::vccb_strtol<int32_t>(argv[2]);
            ComEgMgr::instance()->setEgLevel(egNewLevel);
        }
        else
        {
            printSetEgInfoMenu();
        }
    }
    else
    {
        printSetEgInfoMenu();
    }

    return GOOD;
}

void utilEGput_(int level, const char *event, const char *File, int32_t Line)
{
    if ((!GetgEgFlag()) or (level < GetEgLevel()))
    {
        return;
    }

    if (event == nullptr or File == nullptr)
    {
        return;
    }

    char fileName[121] = {
        0,
    };

    snprintf(fileName, sizeof(fileName), "%s:%d", File, Line);

    ComEgMgr::instance()->gather(event, fileName, level);

    return;
}