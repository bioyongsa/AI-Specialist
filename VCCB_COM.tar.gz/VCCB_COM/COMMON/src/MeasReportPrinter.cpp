#include "ComLibUtility.h"
#include "ComInclude.h"
#include "FeatCallProc.h"
#include "FeatMeasurements.hpp"
#include "MeasReportPrinter.hpp"

namespace
{
uint16_t getBandIndicator(const measurementObjectUe_type& pSelectMeasObj)
{
    AUTO_TRACE_FUNC;

    if (pSelectMeasObj.conf.ratType == measRatNr)
    {
        return pSelectMeasObj.conf.rat.nr.minimal.freqBandIndicatorNR;
    }
    else if (pSelectMeasObj.conf.ratType == measRatEutra)
    {
        return GetEutraBandIndicatorByEARFCN(pSelectMeasObj.conf.rat.eutra.minimal.overlappedCarrierFreq);
    }
    return BAND_NOT_FOUND;
}

std::optional<uint16_t> setOptionalIfFlagOn(uint8_t flag, uint16_t field)
{
    AUTO_TRACE_FUNC;

    if (VCCB_FLAG_ON == flag)
    {
        return field;
    }
    return std::nullopt;
}
}  // namespace

MeasReportPrinter::CellMeasResult MeasReportPrinter::getMeasQuantityResultNR(const measResultNR_type& rRes) const
{
    AUTO_TRACE_FUNC;

    CellMeasResult cellMeasResult;
    cellMeasResult.pci = setOptionalIfFlagOn(rRes.physCellIdFlag, rRes.physCellId);

    if (rRes.cellResults.resultsSSB_CellFlag == VCCB_FLAG_ON)
    {
        const measQuantityResults_type& cellQuantity = rRes.cellResults.resultsSSB_Cell;
        cellMeasResult.rsrp = setOptionalIfFlagOn(cellQuantity.rsrpFlag, cellQuantity.rsrp);
        cellMeasResult.rsrq = setOptionalIfFlagOn(cellQuantity.rsrqFlag, cellQuantity.rsrq);
        cellMeasResult.sinr = setOptionalIfFlagOn(cellQuantity.sinrFlag, cellQuantity.sinr);
    }
    cellMeasResult.mrType = MeasReportPrinter::CellMeasResult::MeasReportType::NR;
    return cellMeasResult;
}

MeasReportPrinter::CellMeasResult MeasReportPrinter::getMeasQuantityResultEutra(const measResultEUTRA_type& rRes) const
{
    AUTO_TRACE_FUNC;

    CellMeasResult cellMeasResult;
    cellMeasResult.pci = std::optional(rRes.pci);

    const measQuantityResults_type& cellQuantity = rRes.measResultEutra;
    cellMeasResult.rsrp = setOptionalIfFlagOn(cellQuantity.rsrpFlag, cellQuantity.rsrp);
    cellMeasResult.rsrq = setOptionalIfFlagOn(cellQuantity.rsrqFlag, cellQuantity.rsrq);
    cellMeasResult.sinr = setOptionalIfFlagOn(cellQuantity.sinrFlag, cellQuantity.sinr);
    cellMeasResult.mrType = MeasReportPrinter::CellMeasResult::MeasReportType::EUTRA;
    return cellMeasResult;
}

template <typename T>
void addToBuffIfElementExist(MeasReportPrinter::Line buff, int& offset, std::optional<T> var)
{
    AUTO_TRACE_FUNC;

    if (var)
    {
        LOGBUF(buff, MeasReportPrinter::MAX_LINE_LEN, &offset, "%5u   ", var.value());
    }
    else
    {
        LOGBUF(buff, MeasReportPrinter::MAX_LINE_LEN, &offset, "%5s   ", "-");
    }
}

template <typename T>
void addCommentIfElementExist(MeasReportPrinter::Line buff, int& offset, const char* comment, std::optional<T> var)
{
    AUTO_TRACE_FUNC;

    if (var)
    {
        LOGBUF(buff, MeasReportPrinter::MAX_LINE_LEN, &offset, "%s%u", comment, var.value());
    }
}

void MeasReportPrinter::getMeasResultServingCell()
{
    AUTO_TRACE_FUNC;

    for (uint32_t MeasResult2NrIdx = 0; MeasResult2NrIdx < measResultList2NR.nrofFreq; MeasResult2NrIdx++)
    {
        const measResult2NR_type& measResult2NR = measResultList2NR.measResult2NR[MeasResult2NrIdx];
        if (measResult2NR.measResultServingCell_Flag != VCCB_FLAG_ON) continue;

        const measResultNR_type& rRes = measResult2NR.measResultServingCell;
        const uint16_t& servCellId = rRes.servCellId;

        ServingCellMeasResult currServingCellMeasResult{};
        currServingCellMeasResult.servCellId = servCellId;
        currServingCellMeasResult.isPcell = (servCellId == rCi.servCellIndex) ? true : false;

        // Add quantities, pci and ssbArfcn
        currServingCellMeasResult.servingCell = getMeasQuantityResultNR(rRes);
        currServingCellMeasResult.servingCell.ssbArfcn = (measResult2NR.ssbFrequency_Flag == VCCB_FLAG_ON)
                                                             ? std::optional(measResult2NR.ssbFrequency)
                                                             : std::nullopt;

        // Add bestNbr info
        for (size_t measResultNbrIdx = 0; measResultNbrIdx < measResult2NR.measResultNeighCellListNR.nrofCellReport;
             measResultNbrIdx++)
        {
            const measResultNR_type& rNbrResults =
                measResult2NR.measResultNeighCellListNR.measResultNR[measResultNbrIdx];

            if (rNbrResults.isBestNbrResultFlag)
            {
                currServingCellMeasResult.bestNeighbor = getMeasQuantityResultNR(rNbrResults);
                break;
            }
        }
        sCResults.push_back(currServingCellMeasResult);
    }
}

void MeasReportPrinter::printMeasResultServingCell()
{
    AUTO_TRACE_FUNC;

    // loop over all ServingCellMeasResults
    for (auto& currentSCell : sCResults)
    {
        if (lines.size() >= MR_LINES_LEN) break;

        int offset = 0;
        Line& currLine = lines.allocate();
        // Add ServingCell quantities
        const CellMeasResult& currResult = currentSCell.servingCell;
        addToBuffIfElementExist(currLine, offset, currResult.pci);
        addToBuffIfElementExist(currLine, offset, currResult.rsrp);
        addToBuffIfElementExist(currLine, offset, currResult.rsrq);
        addToBuffIfElementExist(currLine, offset, currResult.sinr);

        LOGBUF(currLine, MAX_LINE_LEN, &offset, "%s    ", (currentSCell.isPcell) ? "PCell" : "SCell");
        LOGBUF(currLine, MAX_LINE_LEN, &offset, "servCellId:%u ", currentSCell.servCellId);

        addCommentIfElementExist(currLine, offset, "ssbArfcn:", currResult.ssbArfcn);

        // Add BestNbrs
        if (currentSCell.bestNeighbor)
        {
            if (lines.size() >= MR_LINES_LEN) break;

            const CellMeasResult& currBestResult = currentSCell.bestNeighbor.value();

            offset = 0;
            Line& bestNbrLine = lines.allocate();
            addToBuffIfElementExist(bestNbrLine, offset, currBestResult.pci);
            addToBuffIfElementExist(bestNbrLine, offset, currBestResult.rsrp);
            addToBuffIfElementExist(bestNbrLine, offset, currBestResult.rsrq);
            addToBuffIfElementExist(bestNbrLine, offset, currBestResult.sinr);

            LOGBUF(bestNbrLine, MAX_LINE_LEN, &offset, "%s", "BestNbr");
        }
    }
}

void MeasReportPrinter::getMeasResultNbrCell(const measurementObjectUe_type& selectMeasObj)
{
    AUTO_TRACE_FUNC;

    const uint32_t ssbFreqToMatch = VCCB_GetMeasObjectSsbFreq(selectMeasObj);

    const measResult2NR_type* measResult2NRItEnd =
        measResultList2NR.measResult2NR + MIN(measResultList2NR.nrofFreq, MAX_NUM_FREQ);

    const measResult2NR_type* foundMeasResult2NR = std::find_if(measResultList2NR.measResult2NR, measResult2NRItEnd,
        [&](const measResult2NR_type& measResult2NR)
        { return (measResult2NR.ssbFrequency_Flag == TRUE) && (measResult2NR.ssbFrequency == ssbFreqToMatch); });
    if (foundMeasResult2NR == measResult2NRItEnd)
    {
        return;
    }

    for (uint32_t index = 0; index < foundMeasResult2NR->measResultNeighCellListNR.nrofCellReport; index++)
    {
        const measResultNR_type& rResult = foundMeasResult2NR->measResultNeighCellListNR.measResultNR[index];

        CellMeasResult currNbrResult = getMeasQuantityResultNR(rResult);
        nbrResults.push_back(currNbrResult);
    }
}

void MeasReportPrinter::getMeasResultEutraNbrCell()
{
    AUTO_TRACE_FUNC;

    for (uint32_t index = 0; index < measResultList2EUTRA.numReportCell; index++)
    {
        const measResultEUTRA_type& rResult = measResultList2EUTRA.measResult[index];

        CellMeasResult currNbrResult = getMeasQuantityResultEutra(rResult);
        nbrResultsEutra.push_back(currNbrResult);
    }
}

void MeasReportPrinter::printNbrCell(const NbrCellResults& results)
{
    AUTO_TRACE_FUNC;

    // loop over all nbrResults/nbrEutraResults
    for (auto &currNbrResults : results)
    {
        if (lines.size() >= MR_LINES_LEN) break;

        int offset = 0;
        Line& line = lines.allocate();
        addToBuffIfElementExist(line, offset, currNbrResults.pci);
        addToBuffIfElementExist(line, offset, currNbrResults.rsrp);
        addToBuffIfElementExist(line, offset, currNbrResults.rsrq);
        addToBuffIfElementExist(line, offset, currNbrResults.sinr);

        if (MeasReportPrinter::CellMeasResult::MeasReportType::NR == currNbrResults.mrType)
        {
            LOGBUF(line, MAX_LINE_LEN, &offset, "Nbr");
        }
        else if (MeasReportPrinter::CellMeasResult::MeasReportType::EUTRA == currNbrResults.mrType)
        {
            LOGBUF(line, MAX_LINE_LEN, &offset, "EutraNbr");
        }
    }
}

void MeasReportPrinter::printHeaders()
{
    AUTO_TRACE_FUNC;

    int strLen = 0;
    Line& l1 = lines.allocate();
    LOGBUF(l1, MAX_LINE_LEN, &strLen, "                           MEASUREMENT REPORT");

    strLen = 0;
    Line& l2 = lines.allocate();
    LOGBUF(l2, MAX_LINE_LEN, &strLen, "  pci    rsrp    rsrq   sinr    class    additional info");

    strLen = 0;
    Line& l3 = lines.allocate();
    LOGBUF(l3, MAX_LINE_LEN, &strLen, "-----   -----   -----   -----   -----   -----------------------------");
}

void MeasReportPrinter::formatMeasResultList(const measurementObjectUe_type& selectMeasObj)
{
    AUTO_TRACE_FUNC;

    printHeaders();
    getMeasResultServingCell();
    printMeasResultServingCell();
    getMeasResultNbrCell(selectMeasObj);
    printNbrCell(this->nbrResults);
    getMeasResultEutraNbrCell();
    printNbrCell(this->nbrResultsEutra);
}

void MeasReportPrinter::formatHeader(const measurementIdentity_type& selectMeasIdx,
    const measurementObjectUe_type& selectMeasObj, const reportConfigurationInstalledUe_type& selectRptCfg)
{
    AUTO_TRACE_FUNC;
    enumMeasRatType ratType = VCCB_GetRatType(static_cast<enumMeasurementReportType>(selectRptCfg.conf.reportType));

    uint32_t measFreq = 0;
    if (measRatEutra == ratType)
    {
        measFreq = VCCB_GetMeasObjectCarrierFreq(selectMeasObj);
    }
    else if (RSType_SSB == selectRptCfg.conf.rsType)
    {
        measFreq = VCCB_GetMeasObjectSsbFreq(selectMeasObj);
    }

    auto& line = lines.allocate();
    int strLen = 0;
    LOGBUF(line, MAX_LINE_LEN, &strLen, "[measId:%d] [MO id:%d %s:%d band:%d] [RC id:%d event:%s feature:%d]",
        selectMeasIdx.objectId + 1, selectMeasIdx.measObjectId + 1, (ratType == measRatNr ? "ssbArfcn" : "earfcn"),
        measFreq, getBandIndicator(selectMeasObj), selectMeasIdx.reportConfigId + 1,
        VLIB_ReportConfigTypeToStr(selectRptCfg.conf.reportType), selectRptCfg.conf.reportPurpose);
}

MeasReportPrinter::MeasReportPrinter(const callInfo_type& rCallInfo, const measResultList2NR_type& mrltList2NR,
    const measResultNeighCellsEUTRA_type& mrList2EUTRA) :
    rCi(rCallInfo),
    measResultList2NR(mrltList2NR),
    measResultList2EUTRA(mrList2EUTRA)
{
}

MeasReportPrinter::~MeasReportPrinter() = default;