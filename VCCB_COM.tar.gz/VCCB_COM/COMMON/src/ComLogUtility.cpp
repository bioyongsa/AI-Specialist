/**
 * @file        VlogUtility.c
 * @brief       functions for logging utility
 */

#include "ComLogUtility.hpp"
#include "ComInclude.h"
#include "ComLibUtility.h"
#include "ComTimeUtil.h"
#include "ComEndian.h"

#include "FeatCommon.h"
#include "FeatCallProc.h"

#include "MsgVccbSend.h"

#include "log_util.h"

#define TO_STRING_IN_SWITCH(__value) case __value: return #__value;

/****************************************************************************
 * @brief           Outputs the Conditional Statistics Type Name
 * @return          const char : state name
 ****************************************************************************/
const char *FnVCCB_GetStrChoStatisticTypeName(int family, int typeId)
{
    AUTO_TRACE_FUNC;

    switch (family)
    {
        case STAT_CHO_OUT:
        case STAT_CHO_OUT_GLOBAL_ID:
            switch (typeId)
            {
                case ChoTotalOut_PrepAtt:
                    return "ChoTotalOut_PrepAtt";
                case ChoXnOut_PrepAtt:
                    return "Cho_PrepAtt";
                case ChoXnOut_PrepComplete:
                    return "Cho_PrepComplete";
                case ChoXnOut_PrepFail_XnFail:
                    return "Cho_PrepFail_XnFail";
                case ChoXnOut_PrepFail_gNBFail:
                    return "Cho_PrepFail_gNBFail";
                case ChoXnOut_PrepFail_RrcFail:
                    return "Cho_PrepFail_RrcFail";
                case ChoXnOut_PrepCancel:
                    return "Cho_PrepCancel";
                case ChoXnOut_ExeAccess:
                    return "Cho_ExeAccess";
                case ChoXnOut_ExeSuccess:
                    return "Cho_ExeSuccess";
                case ChoXnOut_ExeFail_gNBFail:
                    return "Cho_ExeFail_gNBFail";
                case ChoXnOut_ExeFail_XnFail:
                    return "Cho_ExeFail_XnFail";
                case ChoXnOut_ExeFail_F1Fail:
                    return "Cho_ExeFail_F1Fail";
                case ChoXnOut_ExeFail_E1Fail:
                    return "Cho_ExeFail_E1Fail";
                case ChoXnOut_CandidateRel_CandidateInit:
                    return "Cho_CandidateInit (Xn Conditional Handover Cancel after CHO preparation)";
                case ChoXnOut_CandidateRel_gNBTimeout:
                    return "Cho_gNBTimeout (candidate release timer expiry after CHO preparation)";
                case ChoXnOut_CandidateRel_ConfigChange:
                    return "Cho_ConfigChange (Source config change after CHO preparation)";
                case ChoXnOut_CandidateRel_gNBCancel:
                    return "Cho_gNBCancel (source gNB error or call release, etc after CHO preparation)";
                case ChoXnOutWithMrdc_PrepAtt:
                    return "ChoWithMrdc_PrepAtt";
                case ChoXnOutWithMrdc_PrepComplete:
                    return "ChoWithMrdc_PrepComplete";
                case ChoXnOutWithMrdc_PrepFail_XnFail:
                    return "ChoWithMrdc_PrepFail_XnFail";
                case ChoXnOutWithMrdc_PrepFail_gNBFail:
                    return "ChoWithMrdc_PrepFail_gNBFail";
                case ChoXnOutWithMrdc_PrepFail_RrcFail:
                    return "ChoWithMrdc_PrepFail_RrcFail";
                case ChoXnOutWithMrdc_PrepCancel:
                    return "ChoWithMrdc_PrepCancel";
                case ChoXnOutWithMrdc_ExeAccess:
                    return "ChoWithMrdc_ExeAccess";
                case ChoXnOutWithMrdc_ExeSuccess:
                    return "ChoWithMrdc_ExeSuccess";
                case ChoXnOutWithMrdc_ExeFail_gNBFail:
                    return "ChoWithMrdc_ExeFail_gNBFail";
                case ChoXnOutWithMrdc_ExeFail_XnFail:
                    return "ChoWithMrdc_ExeFail_XnFail";
                case ChoXnOutWithMrdc_ExeFail_F1Fail:
                    return "ChoWithMrdc_ExeFail_F1Fail";
                case ChoXnOutWithMrdc_ExeFail_E1Fail:
                    return "ChoWithMrdc_ExeFail_E1Fail";
                case ChoXnOutWithMrdc_CandidateRel_CandidateInit:
                    return "ChoWithMrdc_CandidateInit (Xn Conditional Handover Cancel after CHO preparation)";
                case ChoXnOutWithMrdc_CandidateRel_gNBTimeout:
                    return "ChoWithMrdc_gNBTimeout (candidate release timer expiry after CHO preparation)";
                case ChoXnOutWithMrdc_CandidateRel_ConfigChange:
                    return "ChoWithMrdc_ConfigChange (Source config change after CHO preparation)";
                case ChoXnOutWithMrdc_CandidateRel_gNBCancel:
                    return "ChoWithMrdc_gNBCancel (source gNB error or call release, etc after CHO preparation)";
                default:
                    return "CHO_OUT(UNKNOWN)";
            }
            break;

        case STAT_CHO_IN:
        case STAT_CHO_IN_GLOBAL_ID:
            switch (typeId)
            {
                case ChoXnIn_PrepAtt:
                    return "ChoXnIn_PrepAtt";
                case ChoXnIn_PrepSuccess:
                    return "Cho_PrepSuccess";
                case ChoXnIn_PrepFail_gNBFail:
                    return "Cho_PrepFail_gNBFail";
                case ChoXnIn_PrepFail_F1Fail:
                    return "Cho_PrepFail_F1Fail";
                case ChoXnIn_PrepFail_E1Fail:
                    return "Cho_PrepFail_E1Fail";
                case ChoXnIn_ExeAccess:
                    return "Cho_ExeAccess";
                case ChoXnIn_ExeSuccess:
                    return "Cho_ExeSuccess";
                case ChoXnIn_ExeFail_XnFail:
                    return "Cho_ExeFail_XnFail";
                case ChoXnIn_ExeFail_gNBFail:
                    return "Cho_ExeFail_gNBFail";
                case ChoXnIn_ExeFail_F1Fail:
                    return "Cho_ExeFail_F1Fail";
                case ChoXnIn_ExeFail_E1Fail:
                    return "Cho_ExeFail_E1Fail";
                case ChoXnIn_ExeFail_NgFail:
                    return "Cho_ExeFail_NgFail";
                case ChoXnIn_CandidateRelease_gNBTimeout:
                    return "Cho_gNBTimeout (candidate release timer expiry after CHO preparation)";
                case ChoXnIn_CandidateRelease_SrcInit:
                    return "Cho_SrcInit (Xn Handover Cancel after CHO preparation)";
                case ChoXnIn_CandidateRelease_DuInit:
                    return "Cho_DuInit (CHO Candidate Release by DU after CHO preparation)";
                case ChoXnIn_CandidateRelease_UpInit:
                    return "Cho_UpInit (CHO Candidate Release by UP after CHO preparation)";
                case ChoXnIn_CandidateRelease_gNBCancel:
                    return "Cho_gNBCancel (target gNB error after CHO preparation)";
                case ChoXnInWithMrdc_PrepAtt:
                    return "ChoWithMrdc_PrepAtt";
                case ChoXnInWithMrdc_PrepSuccess:
                    return "ChoWithMrdc_PrepSuccess";
                case ChoXnInWithMrdc_PrepFail_gNBFail:
                    return "ChoWithMrdc_PrepFail_gNBFail";
                case ChoXnInWithMrdc_PrepFail_F1Fail:
                    return "ChoWithMrdc_PrepFail_F1Fail";
                case ChoXnInWithMrdc_PrepFail_E1Fail:
                    return "ChoWithMrdc_PrepFail_E1Fail";
                case ChoXnInWithMrdc_ExeAccess:
                    return "ChoWithMrdc_ExeAccess";
                case ChoXnInWithMrdc_ExeSuccess:
                    return "ChoWithMrdc_ExeSuccess";
                case ChoXnInWithMrdc_ExeFail_XnFail:
                    return "ChoWithMrdc_ExeFail_XnFail";
                case ChoXnInWithMrdc_ExeFail_gNBFail:
                    return "ChoWithMrdc_ExeFail_gNBFail";
                case ChoXnInWithMrdc_ExeFail_F1Fail:
                    return "ChoWithMrdc_ExeFail_F1Fail";
                case ChoXnInWithMrdc_ExeFail_E1Fail:
                    return "ChoWithMrdc_ExeFail_E1Fail";
                case ChoXnInWithMrdc_ExeFail_NgFail:
                    return "ChoWithMrdc_ExeFail_NgFail";
                case ChoXnInWithMrdc_CandidateRelease_gNBTimeout:
                    return "ChoWithMrdc_gNBTimeout (candidate release timer expiry after CHO preparation)";
                case ChoXnInWithMrdc_CandidateRelease_SrcInit:
                    return "ChoWithMrdc_SrcInit (Xn Handover Cancel after CHO preparation)";
                case ChoXnInWithMrdc_CandidateRelease_DuInit:
                    return "ChoWithMrdc_DuInit (CHO Candidate Release by DU after CHO preparation)";
                case ChoXnInWithMrdc_CandidateRelease_UpInit:
                    return "ChoWithMrdc_UpInit (CHO Candidate Release by UP after CHO preparation)";
                case ChoXnInWithMrdc_CandidateRelease_gNBCancel:
                    return "ChoWithMrdc_gNBCancel (target gNB error after CHO preparation)";
                default:
                    return "CHO_IN(UNKNOWN)";
            }
            break;

        default:
            return "CHO_IN/OUT(UNKNOWN)";
    }
}

/****************************************************************************
 * @brief           Outputs the message name.
 * @details         If an unused message is received from the handler, output the message name.
 * @param[in]       ptCi : Pointer of callInfo_type
 * @param[in]       ptAll : Pointer of message_type
 * @param[in]       ptUnpack : Point of msgUnpack_type
 * @return          void
 ****************************************************************************/
void VCOM_InvalidMessageHandler(callInfo_type *ptCi, const message_type *ptAll, const msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptAll);
    VALID_E_POINT_CHECK_VOID(ptUnpack);

    const char *pMsgName = strMsgId(ptUnpack->msgId);

    if (pMsgName == NULL)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Message Not Handled(T:0x%X, I:0x%X, S:%d)\n", ptAll->msgHdr.msgType, ptUnpack->msgId, ptCi->state);
    }
    else if (timInternalMdtDataRetrieval_id == ptUnpack->msgId)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "MDT retrieval timer TMOUT\n");
    }
    else if (timInternalTraceDeactivation_id == ptUnpack->msgId)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Internal Trace Deactivation timer TMOUT\n");
    }
    else
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Message Not Handled(T:0x%X, I:0x%X, In:%s, S:%d)\n", ptAll->msgHdr.msgType,
            ptUnpack->msgId, pMsgName, ptCi->state);
    }

    if (DBG->log.logStoreSctpMsg == VCCB_FLAG_OFF)
    {
        int16_t status = GOOD;

        switch (ptAll->msgHdr.msgType)
        {
            case SctpDataTransfer_id:
                status = FnVCCB_SaveShm_For_SctpDataTransfer(ptAll, ptCi->myThreadId);
                VCCB_RETURN_ON_CALL_VOID(ptCi, status, "FnVCCB_SaveShm_For_SctpDataTransfer ERROR!!\n");
                break;

            default:
                break;
        }
    }
}  // }}}

/**
 * @brief msgId to string
 *
 * @param [in] ptCi
 * @return GOOD
 * @return ERROR
 */
const char *strMsgId(uint16_t msgType) { return FnLIB_GetMsgIdToString(msgType); }

/**
 * @brief bearerType to string
 *
 * @param [in] ptCi
 * @return GOOD
 * @return ERROR
 */
const char *FnVCCB_GetStrBearerType(int bearerType)
{
    switch (bearerType)
    {
        case MN_Term_MCG_Bearer:
            return "MN_MCG";
        case SN_Term_SCG_Bearer:
            return "SN_SCG";
        case SN_Term_SPLIT_Bearer:
            return "SN_SPLIT";
        case MN_Term_SPLIT_Bearer:
            return "MN_SPLIT";
        case SN_Term_MCG_Bearer:
            return "SN_MCG";
        case MN_Term_SCG_Bearer:
            return "MN_SCG";
        case SN_Term_Undetermined:
            return "SN_Undetm";
        case MN_Term_Undetermined:
            return "MN_Undetm";
        case INIT_BEARER_TYPE:
            return "DC_Init";
        default:
            return "Invalid";
    }
}

const char *FnVCCB_GetStrPduSplitType(enumPduSplitStatus pduSplitType)
{
    switch (pduSplitType)
    {
        case MNTerm_PDU:
            return "MNTerm_PDU";
        case SNTerm_PDU:
            return "SNTerm_PDU";
        case Split_PDU:
            return "Split_PDU";
        case End_PDU:
            return "End_PDU";
        default:
            return "Invalid";
    }
}

const char *FnVCCB_GetStrBuffType(enumBuffType type)
{
    switch (type)
    {
        case buffType1024:
            return "buffType1024";
        case buffType2048:
            return "buffType2048";
        case buffType4096:
            return "buffType4096";
        case buffType9216:
            return "buffType9216";
        default:
            return "Invalid";
    }
}

/**
 * @brief enumCommonStatus_type to string
 *
 * @param [in] ptCi
 * @return GOOD
 * @return ERROR
 */
const char *FnVCCB_GetStrCommonStatus(enumCommonStatus_type bearerType)
{
    return FnLIB_GetCommonStatusToString((uint16_t)bearerType);
}

/**
 * @brief enumSABearerStatus_type to string
 *
 * @param [in] ptCi
 * @return GOOD
 * @return ERROR
 */
const char *FnVCCB_GetStrSABearerStatus(enumSABearerStatus_type bearerType)
{
    return FnLIB_GetSaBearerStatusToString((uint16_t)bearerType);
}

const char *FnVCCB_GetSnodeRelReason(enumSNodeRelReasonType reason)
{
#define SNODE_REL_REASON(REL_REASON) \
    case REL_REASON:                 \
        return #REL_REASON;
    switch (reason)
    {
        SNODE_REL_REASON(MrdcRelCause_NoCause);
        SNODE_REL_REASON(MrdcRelCause_InactivityRelease);
        SNODE_REL_REASON(MrdcRelCause_CallRelease);
        SNODE_REL_REASON(MrdcRelCause_CellAdministration);
        SNODE_REL_REASON(MrdcRelCause_EpsFallBack);
        SNODE_REL_REASON(MrdcRelCause_EmergencyFallBack);
        SNODE_REL_REASON(MrdcRelCause_QosFlowRelease);
        SNODE_REL_REASON(MrdcRelCause_Reestablishment);
        SNODE_REL_REASON(MrdcRelCause_RelReqRecv);
        SNODE_REL_REASON(MrdcRelCause_XnResetFull);
        SNODE_REL_REASON(MrdcRelCause_XnResetPartial);
        SNODE_REL_REASON(MrdcRelCause_XnStateDisabled);
        SNODE_REL_REASON(MrdcRelCause_SnRelbyResetIntraNrdc);
        SNODE_REL_REASON(MrdcRelCause_SCGFailure);
        SNODE_REL_REASON(MrdcRelCause_RRCInactive);
        SNODE_REL_REASON(MrdcRelCause_SNModifyFailed);
        SNODE_REL_REASON(MrdcRelCause_ConcurrentNotAllowed);
        SNODE_REL_REASON(MrdcRelCause_UEPowerSaving);
        SNODE_REL_REASON(MrdcRelCause_Handover);
        SNODE_REL_REASON(MrdcRelCause_OtherReason);

        default:
            return "Unknown rel cause";
    }
#undef SNODE_REL_REASON
}

const char *FnVCCB_GetSnodeRelOprType(enumMrdcSNRelOpr_type type)
{
#define SNODE_REL_OPR_TYPE(OPER_TYPE) \
    case OPER_TYPE:                   \
        return #OPER_TYPE;
    switch (type)
    {
        SNODE_REL_OPR_TYPE(MRDC_SNREL_OPR_XN_ImplicitlyDeletion);
        SNODE_REL_OPR_TYPE(MRDC_SNREL_OPR_XN_Fallback);
        SNODE_REL_OPR_TYPE(MRDC_SNREL_OPR_XN_Deletion);
        SNODE_REL_OPR_TYPE(MRDC_SNREL_OPR_INTERNAL_Fallback);

        default:
            return "Unknown rel operation type";
    }
#undef SNODE_REL_OPR_TYPE
}

const char *FnVCCB_GetMrdcUeContextType(const callInfo_type *ptCi)
{
    int type = ptCi->mrdcInfo.ueCtxType;

    if (!IS_INTRA_GNB_NRDC(ptCi))
    {
        switch (type)
        {
            case UECTX_NRDC_MN:
                return "Inter gNB NRDC MN";
            case UECTX_NRDC_SN:
                return "Inter gNB NRDC SN";
            case UECTX_NEDC_MN:
                return "NEDC MN";
            default:
                return "Unknown DC type";
        }
    }
    else
    {
        switch (type)
        {
            case UECTX_NRDC_MN:
                return "Intra gNB NRDC MN";
            case UECTX_NRDC_SN:
                return "Intra gNB NRDC SN";
            default:
                return "Unknown DC type";
        }
    }
}

/**
 * @brief initialize peerInfo of logging info
 *
 * @param [in] ptCi
 * @param [in] apType BLK_E1/BLK_F1/BLK_X2/etc...
 * @param [in] ptPeerInfo
 * @return N/A
 */
VCCB_INLINE void logInitIntMsgPeerInfo(peerInfo_type *ptPeerInfo, const uint8_t apType)
{
    AUTO_TRACE_FUNC;

    // Validation Check.
    VALID_E_POINT_CHECK_VOID(ptPeerInfo);

    ptPeerInfo->apType = apType;
    ptPeerInfo->assocIdx = 0xFFFF;
    ptPeerInfo->apId = 0xFFFFFFFFFFFFFFFF;
    ptPeerInfo->apUeId = 0xFFFFFFFF;
    ptPeerInfo->invalidFlag = 0;
    return;
}

VCCB_INLINE void FnVCCB_FillPeerInfo_Invalid(peerInfo_type *ptPeerInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptPeerInfo);

    logInitIntMsgPeerInfo(ptPeerInfo, BLK_UNKNOWN);

    ptPeerInfo->invalidFlag |= (SHMLOG_INVALID_APUEID | SHMLOG_INVALID_APID);
}

VCCB_INLINE void FnVCCB_FillPeerInfo_NG(
    const callInfo_type *ptCi, peerInfo_type *ptPeerInfo, const int64_t peerApUeId, const uint16_t endPointIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptPeerInfo);

    ptPeerInfo->apType = BLK_NG;

    ptPeerInfo->assocIdx = endPointIdx;
    amfIdentifier_type amfId = ptCi->servedGuami.amf;
    ptPeerInfo->apId = (uint64_t)GET_AMFI_FROM_REGION_SET_POINTER(amfId.regionId, amfId.setId, amfId.pointer);
    if (peerApUeId == PEER_UE_ID_UNDEFINED)
    {
        ptPeerInfo->invalidFlag |= SHMLOG_INVALID_APUEID;
        ptPeerInfo->apUeId = ptCi->ngCallId;
    }
    else
    {
        ptPeerInfo->apUeId = static_cast<uint64_t>(peerApUeId);
    }
}

VCCB_INLINE void FnVCCB_FillPeerInfo_XN_SN(const callInfo_type *ptCi, peerInfo_type *ptPeerInfo)
{
    ptPeerInfo->apUeId = ptCi->xnCallId;

    if (VHCM_isSaHandoverUE(ptCi))
    {
        if (ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_MGNB_INTERMNHO)
        {
            if (GET_SGNB_ADD_REQ_TGT_FLAG(ptCi->flag.setupFlag))
            {
                if (ptPeerInfo->assocIdx == ptCi->hoInfo.targetGnb.xnIdx)
                {
                    ptPeerInfo->apUeId = ptCi->hoInfo.targetGnb.gNBInfo.mGnbUeXnapId;
                }
            }
        }
    }
}

VCCB_INLINE void FnVCCB_FillPeerInfo_XN_MN(const callInfo_type *ptCi, peerInfo_type *ptPeerInfo)
{
    if (IsAvailable_MrdcInfo())
    {
        if (VHCM_isSaHandoverUE(ptCi) && ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_config_ue)
        {
            if (ptPeerInfo->assocIdx == ptCi->mrdcInfo.SNInfo[TGT_SN].epIdx)
            {
                if (ptCi->mrdcInfo.SNInfo[TGT_SN].m.ueXnAPID)
                    ptPeerInfo->apUeId = ptCi->mrdcInfo.SNInfo[TGT_SN].ueXnAPID;
            }
        }

        if (ptCi->mrdcInfo.SNInfo[SRC_SN].state == SN_STATE_ACTIVE)
        {
            if (ptPeerInfo->assocIdx == ptCi->mrdcInfo.SNInfo[SRC_SN].epIdx)
            {
                if (ptCi->mrdcInfo.SNInfo[SRC_SN].m.ueXnAPID)
                    ptPeerInfo->apUeId = ptCi->mrdcInfo.SNInfo[SRC_SN].ueXnAPID;
            }
        }
    }
}

void FnVCCB_FillPeerInfo_XN_ApUeId(const callInfo_type *ptCi, peerInfo_type *ptPeerInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptPeerInfo);

    // apUeId
    ptPeerInfo->invalidFlag |= SHMLOG_INVALID_APUEID;

    if (IS_NRDC_SN(ptCi))
    {
        FnVCCB_FillPeerInfo_XN_SN(ptCi, ptPeerInfo);
    }
    else
    {
        uint8_t isRreUE = (ptCi->stateCmd == RrcReestablish_cmd);

        ptPeerInfo->apUeId = ptCi->endPointInfo.xnGnbId;  // default

        // Overwrite
        if (VHCM_isSaHandoverUE(ptCi) || isRreUE)
        {
            if (ptPeerInfo->assocIdx == ptCi->endPointInfo.xnIdx)  // ho & rre
            {
                ptPeerInfo->apUeId = ptCi->xnCallId;
            }
        }

        FnVCCB_FillPeerInfo_XN_MN(ptCi, ptPeerInfo);
    }
}

VCCB_INLINE void FnVCCB_FillPeerInfo_XN(
    const callInfo_type *ptCi, peerInfo_type *ptPeerInfo, const int64_t peerApUeId, const uint16_t endPointIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptPeerInfo);

    xnNbrInfo_type *pXnNbr = FnVCCB_GetXnNbrInfo(ptCi->gnbNum, endPointIdx);

    // apType
    ptPeerInfo->apType = BLK_XN;

    // assocIdx
    ptPeerInfo->assocIdx = endPointIdx;

    // apId
    ptPeerInfo->apId = ptCi->endPointInfo.xnGnbId;

    if (pXnNbr != NULL)  // Overwrite
    {
        ptPeerInfo->apId = pXnNbr->gnbId.id;
    }

    // apUeId
    if (peerApUeId == PEER_UE_ID_UNDEFINED)
    {
        FnVCCB_FillPeerInfo_XN_ApUeId(ptCi, ptPeerInfo);
    }
    else
    {
        ptPeerInfo->apUeId = static_cast<uint64_t>(peerApUeId);
    }
}

VCCB_INLINE void FnVCCB_FillPeerInfo_X2(
    const callInfo_type *ptCi, peerInfo_type *ptPeerInfo, const int64_t peerApUeId, const uint16_t endPointIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptPeerInfo);

    ptPeerInfo->apType = BLK_X2;

    ptPeerInfo->assocIdx = endPointIdx;
    ptPeerInfo->apId = GNBINFO[ptCi->gnbNum % MAX_GNB_PER_SYS].x2Nbr[endPointIdx % MAX_ENB_PER_GNB_CU_CP].enbId;
    if (peerApUeId == PEER_UE_ID_UNDEFINED)
    {
        ptPeerInfo->invalidFlag |= SHMLOG_INVALID_APUEID;
        ptPeerInfo->apUeId = ptCi->eNBInfo.mEnbUeX2apId;
    }
    else
    {
        ptPeerInfo->apUeId = static_cast<uint64_t>(peerApUeId);
    }
}

VCCB_INLINE void FnVCCB_FillPeerInfo_F1(
    const callInfo_type *ptCi, peerInfo_type *ptPeerInfo, const int64_t peerApUeId, const uint16_t endPointIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptPeerInfo);

    ptPeerInfo->apType = BLK_F1;
    ptPeerInfo->assocIdx = endPointIdx;

    ptPeerInfo->apId = GNBINFO[ptCi->gnbNum % MAX_GNB_PER_SYS].gnbDu[endPointIdx % MAX_GNB_DU_PER_GNB_CU_CP].gnbDuId;
    if (peerApUeId == PEER_UE_ID_UNDEFINED)
    {
        ptPeerInfo->invalidFlag |= SHMLOG_INVALID_APUEID;
        ptPeerInfo->apUeId = ptCi->auCallId;
    }
    else
    {
        ptPeerInfo->apUeId = static_cast<uint64_t>(peerApUeId);
    }
}

VCCB_INLINE void FnVCCB_FillPeerInfo_E1(
    const callInfo_type *ptCi, peerInfo_type *ptPeerInfo, const int64_t peerApUeId, const uint16_t endPointIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptPeerInfo);

    ptPeerInfo->apType = BLK_E1;
    ptPeerInfo->assocIdx = endPointIdx;
    ptPeerInfo->apId =
        GNBINFO[ptCi->gnbNum % MAX_GNB_PER_SYS].aupf.gnbCuUp[endPointIdx % MAX_GNB_CU_UP_PER_GNB_CU_CP].aupfId;
    if (peerApUeId == PEER_UE_ID_UNDEFINED)
    {
        uint16_t loop;

        ptPeerInfo->invalidFlag |= SHMLOG_INVALID_APUEID;
        ptPeerInfo->apUeId = ptCi->upCallId[0];
        for (loop = 0; loop < MAX_CU_UP_PER_CALL; ++loop)
        {
            if (ptCi->endPointInfo.aupf[loop].e1Idx == endPointIdx)
            {
                ptPeerInfo->apUeId = ptCi->upCallId[loop];
                break;
            }
        }
    }
    else
    {
        ptPeerInfo->apUeId = static_cast<uint64_t>(peerApUeId);
    }
}

VCCB_INLINE void FnVCCB_FillPeerInfo_Spec(const callInfo_type *ptCi, peerInfo_type *ptPeerInfo,
    const int64_t peerApUeId, uint16_t endPointIdx, enumNrInterface_type interface)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptPeerInfo);

    switch (interface)
    {
        case interface_ng:
            FnVCCB_FillPeerInfo_NG(ptCi, ptPeerInfo, peerApUeId, endPointIdx);
            return;

        case interface_xn:
            FnVCCB_FillPeerInfo_XN(ptCi, ptPeerInfo, peerApUeId, endPointIdx);
            return;

        case interface_x2:
            FnVCCB_FillPeerInfo_X2(ptCi, ptPeerInfo, peerApUeId, endPointIdx);
            return;

        case interface_f1:
            FnVCCB_FillPeerInfo_F1(ptCi, ptPeerInfo, peerApUeId, endPointIdx);
            return;

        case interface_e1:
            FnVCCB_FillPeerInfo_E1(ptCi, ptPeerInfo, peerApUeId, endPointIdx);
            return;

        default:
            FnVCCB_FillPeerInfo_Invalid(ptPeerInfo);
            return;
    }
}

/**
 * @brief initialize peerInfo of logging info
 *
 * @param [in] ptCi
 * @param [in] apType BLK_E1/BLK_F1/BLK_X2/etc...
 * @param [in] ptPeerInfo
 * @return N/A
 */
void logInitExtMsgPeerInfo(const callInfo_type *ptCi, enumDirection direction, uint8_t *ptMsg,
    peerInfo_type *ptPeerInfo, const int64_t peerApUeId)
{
    AUTO_TRACE_FUNC;

    // Validation Check.
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptPeerInfo);
    if (NULL == ptMsg)
    {
        FnVCCB_FillPeerInfo_Invalid(ptPeerInfo);
        return;
    }

    message_type *ptAll = (message_type *)ptMsg;
    uint16_t endPointIdx;
    enumNrInterface_type interface;
    uint16_t msgId = ptAll->msgHdr.msgType;

    if (direction == TX_MSG)
    {
        uint16_t endianMsgId = msgId;
        ENDIAN_CONVERT(endianMsgId);

        if (SctpDataTransfer_id == endianMsgId) msgId = SctpDataTransfer_id;
    }

    switch (msgId)
    {
        case msgCallSetupReq_VnmbVccb_id:
        case msgCallResumeInd_VnmbVccb_id:
        case InternalRelayCallResumeInd_id:
        case InternalSendMeasReport_id:
            endPointIdx = ((msgCallSetupReq_type *)ptMsg)->endPointIdx;
            interface = ((msgCallSetupReq_type *)ptMsg)->interface;
            FnVCCB_FillPeerInfo_Spec(ptCi, ptPeerInfo, peerApUeId, endPointIdx, interface);
            return;

        case msgRetrieveUeContextRequest_VnmbVccb_id:
            endPointIdx = ((msgRetrieveUeContextRequest_type *)ptMsg)->endPointIdx;
            interface = ((msgRetrieveUeContextRequest_type *)ptMsg)->interface;
            FnVCCB_FillPeerInfo_Spec(ptCi, ptPeerInfo, peerApUeId, endPointIdx, interface);
            return;

        case msgRetrieveUeContextResult_VnmbVccb_id:
            endPointIdx = ((msgRetrieveUeContextResult_type *)ptMsg)->endPointIdx;
            interface = ((msgRetrieveUeContextResult_type *)ptMsg)->interface;
            FnVCCB_FillPeerInfo_Spec(ptCi, ptPeerInfo, peerApUeId, endPointIdx, interface);
            return;

        case msgTransferMessage_VnmbVccb_id:
        case msgTransferMessage_VccbVnmb_id:
            endPointIdx = static_cast<uint16_t>(((msgTransferMessage_type *)ptMsg)->endPointIdx);
            interface = ((msgTransferMessage_type *)ptMsg)->interface;
            FnVCCB_FillPeerInfo_Spec(ptCi, ptPeerInfo, peerApUeId, endPointIdx, interface);
            return;

        case SctpDataTransfer_id:
            // InitValue
            ptPeerInfo->invalidFlag = 0;

            endPointIdx = ((SctpDataType *)ptMsg)->endPointIdx;
            interface = ((SctpDataType *)ptMsg)->interface;
            FnVCCB_FillPeerInfo_Spec(ptCi, ptPeerInfo, peerApUeId, endPointIdx, interface);
            return;

        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "invalid messageType(0x%X, %s), \n", msgId, strMsgId(msgId));
            FnVCCB_FillPeerInfo_Invalid(ptPeerInfo);
            return;
    }
}

/**
 * @fn bool checkAndUploadShmLog(uint32_t msgSize)
 * @brief  Check and upload Shared memory log
 * @param  msgSize [in]
 * @return bool
 */
bool checkAndUploadShmLog(uint32_t msgSize)
{
    AUTO_TRACE_FUNC;

    const uint32_t wIdx = VCCB_LOG->wIdx;

    // RANGE CHECK
    if ((wIdx >= MAX_SHM_LOG_CNT + 1) ||    // wIdx >= 2000001
        (msgSize >= MAX_SHM_LOG_DATA_SIZE)) // P260304-00119: Add range-check for invalid message size.
    {
        return false;
    }

    bool isProc = false;

    if (wIdx == MAX_SHM_LOG_CNT)  // wIdx == 200000
        isProc = true;
    else if ((VCCB_LOG->logMeta[wIdx].dataOffset + msgSize) >= MAX_SHM_LOG_DATA_SIZE)  // wIdx < 200000
        isProc = true;

    if (isProc == true)
    {
        // VCCB_PRINTF("wIdx=%d/%d, dataOffset=dataOffset(%d)+msgSize(%d)/%d\n", VCCB_LOG->wIdx, MAX_SHM_LOG_CNT,
        //            VCCB_LOG->logMeta[MIN(VCCB_LOG->wIdx, MAX_SHM_LOG_CNT)].dataOffset, msgSize,
        //            MAX_SHM_LOG_DATA_SIZE);
        if (!(DBG->log.logCtlMask & NO_VCCB_LOG_ITSCP_UPLOAD))
        {
            VLIB_UploadShmLogs();
        }
        VCCB_LOG->rIdx = wIdx;
        VCCB_LOG->wIdx = 0;
        VCCB_LOG->logMeta[0].dataOffset = 0;
    }

    // At this point, dataOffset + msgSize is always within MAX_SHM_LOG_DATA_SIZE.
    return true;
}


/**
 * @brief logging Vccb String Logs
 *
 * @param [in] level
 * @param [in] briefStrLen
 * @param [in] *briefStr
 * @return N/A
 */
void logShmStr(uint8_t level, uint32_t briefStrLen, uint8_t *briefStr)
{
    AUTO_TRACE_FUNC;

    // Validation Check.
    VALID_E_POINT_CHECK_VOID(briefStr);

    // ---------- RECURSIVE CALL PROTECTION START ----------
    // DO NOT USE VCCB_CHECK_E_RANGE_AND_VOID WHEN CHECKING VCCB_LOG->wIdx IN THIS FUNCTION!!!
    if (VCCB_LOG->wIdx >= MAX_SHM_LOG_CNT + 1)
    {
        VCCB_PRINTF("VCCB_LOG->wIdx is out of range (%llu:%llu)\n", 
            (unsigned long long)VCCB_LOG->wIdx, (unsigned long long)MAX_SHM_LOG_CNT + 1);

        MUTEX_LOCK(&VCCB_LOG->mutex_write);
        VCCB_LOG->rIdx = 0;
        VCCB_LOG->wIdx = 0;
        VCCB_LOG->logMeta[0].dataOffset = 0;
        MUTEX_UNLOCK(&VCCB_LOG->mutex_write);

        VCCB_PRINTF("Cleared VCCB_LOG offsets (rIdx, wIdx, logMeta[0].dataOffset)\n");
        return;
    }
    // ---------- RECURSIVE CALL PROTECTION  END  ----------

    VccbDbgLog_type *pDbgLog = &DBG->log;

    if (!(pDbgLog->logCtlMask & NO_VCCB_LOG_ITSCP_PRINT) && (pDbgLog->logStoreDebugTrace == 0) &&
        (pDbgLog->logStoreDebugLevel >= level))
    {
        shmLogMeta_type *pShmLogMeta;
        shmLogStr_type *pShmLogStr;

        MUTEX_LOCK(&VCCB_LOG->mutex_write);
        if (!checkAndUploadShmLog(0))
        {
            uint32_t local_wIdx = VCCB_LOG->wIdx;
            MUTEX_UNLOCK(&VCCB_LOG->mutex_write);
            VCCB_PRINT_ERROR("%s failed! (wIdx=%u)\n", __func__, local_wIdx);
            return;
        }

        pShmLogMeta = (shmLogMeta_type *)&VCCB_LOG->logMeta[VCCB_LOG->wIdx];
        /* set next offset */
        /* offset calculation is done first, to reduce mutex delay */
        VCCB_LOG->wIdx++;

        if (VCCB_LOG->wIdx >= MAX_SHM_LOG_CNT + 1)
        {
            VCCB_PRINT_ERROR("%s is out of range (%llu:%llu)\n", "VCCB_LOG->wIdx", (unsigned long long)VCCB_LOG->wIdx,
                (unsigned long long)MAX_SHM_LOG_CNT + 1);
            MUTEX_UNLOCK(&VCCB_LOG->mutex_write);
            return;
        };

        VCCB_LOG->logMeta[VCCB_LOG->wIdx].dataOffset = pShmLogMeta->dataOffset;
        MUTEX_UNLOCK(&VCCB_LOG->mutex_write);
        /* update log detail info */
        ComTimeUtil::get_current_time(pShmLogMeta->loggingTime);
        /* Multi-gNB //pShmLogMeta->gnbId          = GNBINFO.globalGnbId.gnbId.id;    */
        pShmLogMeta->gnbNum = UNKNOWN_GNB_NUM;
        pShmLogMeta->vmId = static_cast<uint8_t>(CFG->vm.unitId);
        pShmLogMeta->type = SHMLOG_STR;
        pShmLogStr = (shmLogStr_type *)&pShmLogMeta->u.logStr;
        memcpy(pShmLogStr->brief, briefStr, MIN(briefStrLen, SHM_LOG_BRIEF_LEN));
        pShmLogStr->detailInfoLen = 0;
        pShmLogStr->debugLevel = level;
    }
}

/**
 * @brief logging Vccb String Detail Logs
 *
 * @param [in] briefStrLen
 * @param [in] *briefStr
 * @param [in] detailStrLen
 * @param [in] *detailStr
 * @return N/A
 */
void logShmStrDetail(uint32_t briefStrLen, uint8_t *briefStr, uint32_t detailStrLen, uint8_t *detailStr)
{
    AUTO_TRACE_FUNC;

    // Validation Check.
    VALID_E_POINT_CHECK_VOID(briefStr);
    VALID_E_POINT_CHECK_VOID(detailStr);
    VCCB_CHECK_E_RANGE_AND_VOID(VCCB_LOG->wIdx, MAX_SHM_LOG_CNT + 1);

    VccbDbgLog_type *pDbgLog = &DBG->log;

    if (!(pDbgLog->logCtlMask & NO_VCCB_LOG_ITSCP_PRINT))
    {
        shmLogMeta_type *pShmLogMeta;
        shmLogStr_type *pShmLogStr;

        MUTEX_LOCK(&VCCB_LOG->mutex_write);
        if (!checkAndUploadShmLog(detailStrLen))
        {
            uint32_t local_wIdx = VCCB_LOG->wIdx;
            MUTEX_UNLOCK(&VCCB_LOG->mutex_write);
            VCCB_PRINT_ERROR("%s failed! (wIdx=%u, length=%u)\n", __func__, local_wIdx, detailStrLen);
            return;
        }

        pShmLogMeta = (shmLogMeta_type *)&VCCB_LOG->logMeta[VCCB_LOG->wIdx];
        VCCB_CHECK_E_RANGE_AND_UNLOCK_VOID(
            pShmLogMeta->dataOffset + detailStrLen, SHM_LOG_SIZE * (MAX_SHM_LOG_CNT + 1), &VCCB_LOG->mutex_write);

        /* set next offset */
        /* offset caculation is done first, to reduce mutex delay */
        VCCB_LOG->wIdx++;
        if (VCCB_LOG->wIdx >= MAX_SHM_LOG_CNT + 1)
        {
            VCCB_PRINT_ERROR("%s is out of range (%llu:%llu)\n", "VCCB_LOG->wIdx", (unsigned long long)VCCB_LOG->wIdx,
                (unsigned long long)MAX_SHM_LOG_CNT + 1);
            MUTEX_UNLOCK(&VCCB_LOG->mutex_write);
            return;
        };

        VCCB_LOG->logMeta[VCCB_LOG->wIdx].dataOffset = pShmLogMeta->dataOffset + detailStrLen;
        MUTEX_UNLOCK(&VCCB_LOG->mutex_write);
        /* update log detail info */
        ComTimeUtil::get_current_time(pShmLogMeta->loggingTime);
        /* Multi-gNB //pShmLogMeta->gnbId          = GNBINFO.globalGnbId.gnbId.id;    */
        pShmLogMeta->gnbNum = UNKNOWN_GNB_NUM;
        pShmLogMeta->vmId = static_cast<uint8_t>(CFG->vm.unitId);
        pShmLogMeta->type = SHMLOG_STR;
        pShmLogStr = (shmLogStr_type *)&pShmLogMeta->u.logStr;
        memcpy(pShmLogStr->brief, briefStr, MIN(briefStrLen, SHM_LOG_BRIEF_LEN));
        if (briefStrLen == SHM_LOG_BRIEF_LEN)
        {
            pShmLogStr->brief[briefStrLen - 2] = '\n';
        }
        pShmLogStr->brief[sizeof(pShmLogStr->brief) - 1] = 0;
        pShmLogStr->detailInfoLen = detailStrLen;
        pShmLogStr->debugLevel = 0;
        memcpy((char *)&VCCB_LOG_DATA[pShmLogMeta->dataOffset], detailStr, detailStrLen);
    }
}

#define LOG_SHM_COMMON_MSG(_call, _logMeta, _logType, _length)                                                         \
    {                                                                                                                  \
        /* set next offset */                                                                                          \
        /* offset caculation is done first, to reduce mutex delay */                                                   \
        VCCB_LOG->wIdx++;                                                                                              \
        if (VCCB_LOG->wIdx >= MAX_SHM_LOG_CNT + 1)                                                                     \
        {                                                                                                              \
            VCCB_PRINT_ERROR("%s is out of range (%llu:%llu)\n", "VCCB_LOG->wIdx", (unsigned long long)VCCB_LOG->wIdx, \
                (unsigned long long)MAX_SHM_LOG_CNT + 1);                                                              \
            MUTEX_UNLOCK(&VCCB_LOG->mutex_write);                                                                      \
            return;                                                                                                    \
        };                                                                                                             \
        VCCB_LOG->logMeta[VCCB_LOG->wIdx].dataOffset = _length;                                                        \
        MUTEX_UNLOCK(&VCCB_LOG->mutex_write);                                                                          \
        /* update log detail info */                                                                                   \
        ComTimeUtil::get_current_time(_logMeta.loggingTime);                                                           \
        /* Multi-gNB //pShmLogMeta->gnbId          = GNBINFO.globalGnbId.gnbId.id;    */                               \
        _logMeta.gnbNum = static_cast<uint8_t>(_call.gnbNum);                                                          \
        _logMeta.vmId = static_cast<uint8_t>(CFG->vm.unitId);                                                          \
        _logMeta.type = _logType;                                                                                      \
    }

#define LOG_SHM_COMMON_MSG_WITH_PREV_LOG_INDEX(_call, _logMeta, _logType, _logIndex, _length) \
    {                                                                                         \
        LOG_SHM_COMMON_MSG(_call, _logMeta, _logType, _length)                                \
        if (_call.callId < MAX_CALL_NUM_VCCB)                                                 \
        {                                                                                     \
            _logMeta.previousLogIndex = VCCB_LOG->previousLogIndex[_call.callId];             \
            VCCB_LOG->previousLogIndex[_call.callId] = _logIndex;                             \
        }                                                                                     \
        else                                                                                  \
        {                                                                                     \
            _logMeta.previousLogIndex = 0xFFFFFFFF;                                           \
        }                                                                                     \
    }

uint8_t FnVCCB_getUeContextType(const callInfo_type *ptCi)
{
    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        return LOG_DC_ENDC;
    }
    else if (ptCi->callType == E_CALLTYPE_SA)
    {
        if (IS_SELECTED_MRDC(MRDC_NEDC))
        {
            return LOG_DC_NEDC;
        }
        else if (IS_SELECTED_MRDC(MRDC_NRDC))
        {
            if (IS_NRDC_MN(ptCi))
            {
                return LOG_DC_NRDC_MN;
            }
            else if (IS_NRDC_SN(ptCi))
            {
                return LOG_DC_NRDC_SN;
            }
        }
        return LOG_DC_NONE;
    }

    return LOG_DC_UNKNOWN;
}

VCCB_STATIC_INLINE bool FnVCCB_FilterByGnbNum(uint16_t targetGnbNum)
{
    VccbDbgLogFilter_type &rDbgLogFilter = DBG->log.filter;

    if (FALSE == rDbgLogFilter.flag.gnb) return true;
    if (MAX_GNB_PER_SYS <= targetGnbNum) return true;

    if (UNKNOWN_GNB_NUM == rDbgLogFilter.gnbInfo.gnbNum)
    {
        uint32_t filteredGnbId = rDbgLogFilter.gnbInfo.gnbId;
        uint16_t filteredGnbNum = UNKNOWN_GNB_NUM;

        if (GOOD != VLIB_GetGnbNumFromId(&filteredGnbNum, filteredGnbId))
        {
            VCCB_PRINT_ERROR("VLIB_GetGnbNumFromId ERROR(filteredGnbId=%u) in %s\n", filteredGnbId, __func__);
            VCCB_INIT_DBG_GNB_LOG_FILTER(rDbgLogFilter);
            return true;
        }

        rDbgLogFilter.gnbInfo.gnbNum = filteredGnbNum;
        VCCB_PRINT_COMMENT("Found gnbNum(%u) from gnbId(%u) in %s\n", filteredGnbNum, filteredGnbId, __func__);
        VCCB_PRINT_COMMENT("GnbId(%u) filter ON\n", filteredGnbId);
    }

    if (rDbgLogFilter.gnbInfo.gnbNum == targetGnbNum)
    {
        return true;
    }
    return false;
}

VCCB_STATIC_INLINE void FnVCCB_FilterCellNumByGnb(VccbDbgLogFilter_type &rDbgLogFilter, uint16_t gnbNum, uint8_t &count)
{
    VccbCellInfo_type *const pCellInfo = CELLINFO;
    const uint8_t cellIdCount = rDbgLogFilter.cellInfo.cellIdCount;
    
    for (uint8_t idx = 0; idx < MIN(cellIdCount, MAX_FILTERED_CELLID_NUM); idx++)
    {
        uint16_t cellNum;
        if (GOOD != FnVCCB_GetCellNumFromCellId(gnbNum, rDbgLogFilter.cellInfo.cellId[idx], &cellNum))
        {
            continue;
        }

        VCCB_CHECK_E_RANGE_AND_CONTINUE(cellNum, MAX_CELL_NUM_VCCB);
        if (TRUE == pCellInfo[cellNum].isFilteredForLog) continue;
        
        pCellInfo[cellNum].isFilteredForLog = TRUE;
        count++;
    }
}

bool FnVCCB_FilterByCellNum(uint16_t targetCellNum)
{
    VccbDbgLogFilter_type &rDbgLogFilter = DBG->log.filter;

    if (FALSE == rDbgLogFilter.flag.cell) return true;
    if (0 == rDbgLogFilter.cellInfo.cellIdCount) return true;
    if (MAX_CELL_NUM_VCCB <= targetCellNum) return true;

    VccbCellInfo_type *const pCellInfo = CELLINFO;

    if (0 == rDbgLogFilter.cellInfo.totalCellNumByGnb)
    {
        const uint16_t filteredGnbNum = rDbgLogFilter.gnbInfo.gnbNum;
        uint8_t count = 0;

        for (uint16_t cellNum = 0; cellNum < MAX_CELL_NUM_VCCB; cellNum++)
        {
            pCellInfo[cellNum].isFilteredForLog = FALSE;
        }

        if (TRUE == rDbgLogFilter.flag.gnb && filteredGnbNum < MAX_GNB_PER_SYS)
        {
            FnVCCB_FilterCellNumByGnb(rDbgLogFilter, filteredGnbNum, count);
        }
        else
        {
            for (uint16_t gnbNum = 0; gnbNum < MAX_GNB_PER_SYS; gnbNum++)
            {
                if (EQUIP != GNBINFO[gnbNum].status) continue;
                FnVCCB_FilterCellNumByGnb(rDbgLogFilter, gnbNum, count);
            }
        }

        if (0 == count)
        {
            VCCB_PRINT_ERROR("None of the cells are filtered in %s\n", __func__);
            VCCB_INIT_DBG_CELL_LOG_FILTER(rDbgLogFilter);
            return true;
        }

        rDbgLogFilter.cellInfo.totalCellNumByGnb = count;
    }

    if (TRUE == pCellInfo[targetCellNum].isFilteredForLog)
    {
        return true;
    }
    return false;
}

static inline void initLogMetaUe(LogMetaUe_type &logMetaUe)
{
    logMetaUe.vccbCallId = UNKNOWN_VCCB_CALLID;
    logMetaUe.cuCpUeId = UNKNOWN_CP_CALLID;
    logMetaUe.callType = E_CALLTYPE_UNKNOWN;
    logMetaUe.dcType = LOG_DC_UNKNOWN;
    logMetaUe.state = STATE_VCCB_NOT_USED;
    logMetaUe.stateCmd = Idle_cmd;
    logMetaUe.ueId.usage = CI_no_use;
    logMetaUe.servCellNum = -1;
    logMetaUe.servPcid = -1;
    logMetaUe.newCellNum = -1;
    logMetaUe.traceVoNR = FALSE;
    logMetaUe.debugTrace = 0;
    logMetaUe.ueType = UE_TYPE_ALL;
}

static inline void setLogMetaUe(LogMetaUe_type &logMetaUe, const callInfo_type &call)
{
    logMetaUe.vccbCallId = call.callId;
    logMetaUe.cuCpUeId = call.gnbCuUeId;
    logMetaUe.callType = call.callType;
    logMetaUe.dcType = FnVCCB_getUeContextType(&call);
    logMetaUe.state = call.state;
    logMetaUe.stateCmd = call.stateCmd;
    logMetaUe.ueId = call.ueInfo.ueId;
    logMetaUe.servCellNum = static_cast<int16_t>(call.servCellNum);
    logMetaUe.servPcid =
                (call.servCellNum < MAX_CELL_NUM_VCCB) ? static_cast<int16_t>(CELLINFO[call.servCellNum].phyCellId) : -1;
    logMetaUe.newCellNum = static_cast<int16_t>(call.hoInfo.targetCellNum);
    logMetaUe.traceVoNR = call.traceVoNR;
    logMetaUe.debugTrace = call.debugTrace;
    logMetaUe.ueType = (TRUE == call.redCapUeInfo.redCapUeFlag);
}

static inline void setShmLogCallStr(shmLogCallStr_type &logCallStr, const callInfo_type &call, const uint8_t level,
    uint32_t briefStrLen, uint8_t *briefStr, const uint8_t isCrrLogging)
{
    VALID_E_POINT_CHECK_VOID(briefStr);

    if (IS_VALID_PTCI(&call) == TRUE)
    {
        if (isCrrLogging == TRUE)
        {
            logCallStr.crrId = call.cause.callFault.callFaultCause;
            logCallStr.msgId = static_cast<uint16_t>(call.cause.callFault.msgId);
            logCallStr.callState = call.cause.callFault.callState;
            logCallStr.stateCmd = call.cause.callFault.stateCmd;
        }
        else
        {
            logCallStr.crrId = UNKNOWN_CRR_ID;
        }
    }
    else
    {
        logCallStr.crrId = UNKNOWN_CRR_ID;
    }
    logCallStr.debugLevel = level;

    if (briefStrLen < SHM_LOG_BRIEF_LEN)
    {
        briefStr[briefStrLen++] = '\0';
    }
    else
    {
        briefStr[SHM_LOG_BRIEF_LEN - 2] = '\n';
        briefStr[SHM_LOG_BRIEF_LEN - 1] = '\0';
    }

    memcpy(logCallStr.brief, briefStr, MIN(briefStrLen, SHM_LOG_BRIEF_LEN));
    logCallStr.detailInfoLen = 0;
}

static inline void setShmCRR(shmLogCRR_type &logCRR, const callInfo_type &call)
{
    if (IS_VALID_PTCI(&call) == TRUE)
    {
        logCRR.crrId = call.cause.callFault.callFaultCause;
        logCRR.msgId = static_cast<uint16_t>(call.cause.callFault.msgId);
        logCRR.state = static_cast<enumVccbCallState_type>(call.cause.callFault.callState);
        logCRR.stateCmd = static_cast<enumStateCmd_type>(call.cause.callFault.stateCmd);
    }
    else
    {
        logCRR.crrId = UNKNOWN_CRR_ID;
    }
}

void logShmCRR(const callInfo_type &call)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(VCCB_LOG->wIdx, MAX_SHM_LOG_CNT + 1);

    if (false == FnVCCB_FilterByGnbNum(call.gnbNum)) return;
    if (false == FnVCCB_FilterByCellNum(call.servCellNum)) return;

    const VccbDbgLog_type &dbgLog = DBG->log;

    if (!(dbgLog.logCtlMask & NO_VCCB_LOG_ITSCP_PRINT) &&
        ((dbgLog.logStoreDebugTrace == 0) || ((dbgLog.logStoreDebugTrace == 1) && (call.debugTrace == 1))))
    {
        MUTEX_LOCK(&VCCB_LOG->mutex_write);
        if (!checkAndUploadShmLog(0))
        {
            uint32_t local_wIdx = VCCB_LOG->wIdx;
            MUTEX_UNLOCK(&VCCB_LOG->mutex_write);
            VCCB_PRINT_CALL_ERROR(&call, "%s failed! (wIdx=%u)\n", __func__, local_wIdx);
            return;
        }

        const uint32_t logIndex = VCCB_LOG->wIdx;
        shmLogMeta_type &logMeta = VCCB_LOG->logMeta[logIndex];
        LOG_SHM_COMMON_MSG_WITH_PREV_LOG_INDEX(call, logMeta, SHMLOG_CRR, logIndex, logMeta.dataOffset);

        if (IS_VALID_PTCI(&call) == TRUE)
        {
            setLogMetaUe(logMeta.ue, call);
        }
        else
        {
            initLogMetaUe(logMeta.ue);
        }

        shmLogCRR_type &logCRR = logMeta.u.logCRR;
        setShmCRR(logCRR, call);
    }
}

void logShmStrCall(const callInfo_type *ptCi, uint8_t level, uint32_t briefStrLen, uint8_t *briefStr, uint8_t isCrrLogging)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    const auto &call = *ptCi;
    VALID_E_POINT_CHECK_VOID(briefStr);
    VCCB_CHECK_E_RANGE_AND_VOID(VCCB_LOG->wIdx, MAX_SHM_LOG_CNT + 1);

    if (false == FnVCCB_FilterByGnbNum(call.gnbNum)) return;
    if (false == FnVCCB_FilterByCellNum(call.servCellNum)) return;

    const VccbDbgLog_type &dbgLog = DBG->log;

    if (!(dbgLog.logCtlMask & NO_VCCB_LOG_ITSCP_PRINT) &&
        ((dbgLog.logStoreDebugTrace == 0) || ((dbgLog.logStoreDebugTrace == 1) && (call.debugTrace == 1))) &&
        (dbgLog.logStoreDebugLevel >= level))
    {
        MUTEX_LOCK(&VCCB_LOG->mutex_write);
        if (!checkAndUploadShmLog(0))
        {
            uint32_t local_wIdx = VCCB_LOG->wIdx;
            MUTEX_UNLOCK(&VCCB_LOG->mutex_write);
            VCCB_PRINT_CALL_ERROR(ptCi, "%s failed! (wIdx=%u)\n", __func__, local_wIdx);
            return;
        }

        const uint32_t logIndex = VCCB_LOG->wIdx;
        shmLogMeta_type &logMeta = VCCB_LOG->logMeta[logIndex];
        LOG_SHM_COMMON_MSG_WITH_PREV_LOG_INDEX(call, logMeta, SHMLOG_EXTRA_DEBUG, logIndex, logMeta.dataOffset);

        if (IS_VALID_PTCI(ptCi) == TRUE)
        {
            setLogMetaUe(logMeta.ue, call);
        }
        else
        {
            initLogMetaUe(logMeta.ue);
        }

        shmLogCallStr_type &logCallStr = logMeta.u.logCallStr;
        setShmLogCallStr(logCallStr, call, level, briefStrLen, briefStr, isCrrLogging);
    }
}

void logShmMscGenStr(const VccbDbgLog_type &dbgLog, const callInfo_type *ptCi, uint8_t level, uint32_t briefStrLen, uint8_t *briefStr)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(briefStr);
    VCCB_CHECK_E_RANGE_AND_VOID(VCCB_LOG->wIdx, MAX_SHM_LOG_CNT + 1);

    // If this mscGen is not ON, it does not work.
    if (dbgLog.logMscGen == 0) return;

    // If the collection level is low, we do not collect.
    if (dbgLog.logMscGenDebugLevel < level) return;

    const auto &call = *ptCi;

    if (false == FnVCCB_FilterByGnbNum(ptCi->gnbNum)) return;
    if (false == FnVCCB_FilterByCellNum(ptCi->servCellNum)) return;

    // 1) ShmMeta
    MUTEX_LOCK(&VCCB_LOG->mutex_write);
    if (!checkAndUploadShmLog(0))
    {
        uint32_t local_wIdx = VCCB_LOG->wIdx;
        MUTEX_UNLOCK(&VCCB_LOG->mutex_write);
        VCCB_PRINT_CALL_ERROR(ptCi, "%s failed! (wIdx=%u)\n", __func__, local_wIdx);
        return;
    }

    const uint32_t logIndex = VCCB_LOG->wIdx;
    shmLogMeta_type &logMeta = VCCB_LOG->logMeta[logIndex];
    LOG_SHM_COMMON_MSG_WITH_PREV_LOG_INDEX(call, logMeta, SHMLOG_MSCGEN, logIndex, logMeta.dataOffset); // MUTEX_UNLOCK

    if (IS_VALID_PTCI(ptCi) == TRUE)
    {
        setLogMetaUe(logMeta.ue, call);
    }
    else
    {
        initLogMetaUe(logMeta.ue);
    }

    // 2) ShmLogMscGen
    {
        shmLogMscGen_type &logMscGen = logMeta.u.logMscGen;

        const size_t maxOfBuff = MIN(sizeof(logMscGen.u.str.brief), static_cast<size_t>(briefStrLen));
        int length = 0;

        logMscGen.shmType = e_ShmLogMscGenType_String;
        logMscGen.debugLevel = (level & e_BitMask_3bit);

        length = snprintf(logMscGen.u.str.brief, maxOfBuff, "%s", briefStr);

        // If an output error is encountered, a negative value is returned.
        if (length < 0)
        {
            length = 0;
        }
        else if (static_cast<size_t>(length) >= maxOfBuff)
        {
            length = (static_cast<int>(maxOfBuff) - 1);
        }

        logMscGen.u.str.brief[length] = 0;
    }
}

static inline void setShmLogStat(shmLogStatPm_type &logStat, const int method, const int mFamily, const int mType,
    const VccbPmUpdateVal_type pmUpdateVal, const VccbPmKey_type &rPmKey)
{
    logStat.pmCallType = method;
    logStat.mFamily = mFamily;
    logStat.mType = mType;
    logStat.updateVal.u.updateValFloat = pmUpdateVal.u.updateValFloat;
    logStat.updateVal.u.updateValUll = pmUpdateVal.u.updateValUll;
    logStat.updateVal.u.updateValInt = pmUpdateVal.u.updateValInt;
    logStat.updateVal.uType = pmUpdateVal.uType;
    memcpy(&logStat.keyList[0], &rPmKey.keyList[0], sizeof(logStat.keyList));
}

void logShmStat(const int method, const int mFamily, const int mType, const VccbPmUpdateVal_type &pmUpdateVal,
    const VccbPmKey_type &pmKey)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(VCCB_LOG->wIdx, MAX_SHM_LOG_CNT + 1);

    const VccbDbgLog_type &dbgLog = DBG->log;

    if (!(dbgLog.logCtlMask & NO_VCCB_LOG_ITSCP_PRINT) && (dbgLog.logStoreDebugTrace == 0) &&
        (dbgLog.logStoreStatistics == 1))
    {
        MUTEX_LOCK(&VCCB_LOG->mutex_write);
        if (!checkAndUploadShmLog(0))
        {
            uint32_t local_wIdx = VCCB_LOG->wIdx;
            MUTEX_UNLOCK(&VCCB_LOG->mutex_write);
            VCCB_PRINT_ERROR("%s failed! (wIdx=%u)\n", __func__, local_wIdx);
            return;
        }

        shmLogMeta_type &logMeta = VCCB_LOG->logMeta[VCCB_LOG->wIdx];
        /* set next offset */
        /* offset caculation is done first, to reduce mutex delay */
        VCCB_LOG->wIdx++;

        if (VCCB_LOG->wIdx >= MAX_SHM_LOG_CNT + 1)
        {
            VCCB_PRINT_ERROR("%s is out of range (%llu:%llu)\n", "VCCB_LOG->wIdx", (unsigned long long)VCCB_LOG->wIdx,
                (unsigned long long)MAX_SHM_LOG_CNT + 1);
            MUTEX_UNLOCK(&VCCB_LOG->mutex_write);
            return;
        };

        VCCB_LOG->logMeta[VCCB_LOG->wIdx].dataOffset = logMeta.dataOffset;
        MUTEX_UNLOCK(&VCCB_LOG->mutex_write);
        /* update log detail info */
        ComTimeUtil::get_current_time(logMeta.loggingTime);
        /* Multi-gNB //logMeta.gnbId = GNBINFO.globalGnbId.gnbId.id;    */
        logMeta.gnbNum = UNKNOWN_GNB_NUM;
        logMeta.vmId = static_cast<uint8_t>(CFG->vm.unitId);
        initLogMetaUe(logMeta.ue);
        logMeta.type = SHMLOG_STAT;

        shmLogStatPm_type &logStat = logMeta.u.logStatPm;
        setShmLogStat(logStat, method, mFamily, mType, pmUpdateVal, pmKey);
    }
}

void logShmStatCall(const callInfo_type *ptCi, const int method, const int mFamily, const int mType,
    const VccbPmUpdateVal_type &pmUpdateVal, const VccbPmKey_type &pmKey)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    const auto &call = *ptCi;
    VCCB_CHECK_E_RANGE_AND_VOID(VCCB_LOG->wIdx, MAX_SHM_LOG_CNT + 1);

    if (false == FnVCCB_FilterByGnbNum(call.gnbNum)) return;

    const VccbDbgLog_type &dbgLog = DBG->log;

    if (!(dbgLog.logCtlMask & NO_VCCB_LOG_ITSCP_PRINT) && (dbgLog.logStoreDebugTrace == 0) &&
        (dbgLog.logStoreStatistics == 1))
    {
        MUTEX_LOCK(&VCCB_LOG->mutex_write);
        if (!checkAndUploadShmLog(0))
        {
            uint32_t local_wIdx = VCCB_LOG->wIdx;
            MUTEX_UNLOCK(&VCCB_LOG->mutex_write);
            VCCB_PRINT_CALL_ERROR(ptCi, "%s failed! (wIdx=%u)\n", __func__, local_wIdx);
            return;
        }

        const uint32_t logIndex = VCCB_LOG->wIdx;
        shmLogMeta_type &logMeta = VCCB_LOG->logMeta[logIndex];
        LOG_SHM_COMMON_MSG_WITH_PREV_LOG_INDEX(call, logMeta, SHMLOG_STAT, logIndex, logMeta.dataOffset);
        setLogMetaUe(logMeta.ue, call);

        shmLogStatPm_type &logStat = logMeta.u.logStatPm;
        setShmLogStat(logStat, method, mFamily, mType, pmUpdateVal, pmKey);
    }
}

static inline void setShmLogMsgFlow(shmLogMsgFlow_type &logMsgFlow, const enumDirection direction, const uint16_t msgId,
    const uint32_t msgSize, const peerInfo_type &peerInfo)
{
    logMsgFlow.direction = direction;
    logMsgFlow.peer = peerInfo;
    logMsgFlow.msgId = msgId;
    logMsgFlow.msgLen = msgSize;
#ifdef VCCB_IPC_TEST
    logMsgFlow.sim.clearFlag = 0;
#endif
}

/**
 * @brief logging Vccb Internal Message Flows //VNMB, VNLB, VCLB, VTMB, etc..
 *
 * @param [in] ptCi : callInfo
 * @param [in] direction : direction of message. RX_MSG/TX_MSG
 * @param [in] apType : peer block information. BLK_VNMB, BLK_VNLB, BLK_VCLB, etc..
 * @param [in] msgId : message Id.
 * @param [in] msgSize : length of message to logging(store)
 * @param [in] ptMsg : sctpDataType or CallSetupReq msg. It is for the information of PeerInfo and message length, data.
 * @return N/A
 */
void logShmIntMsg(const callInfo_type *ptCi, enumDirection direction, uint8_t apType, uint16_t msgId, uint32_t msgSize,
    uint8_t *ptMsg)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    const auto &call = *ptCi;
    VALID_E_POINT_CHECK_VOID(ptMsg);
    VCCB_CHECK_E_RANGE_AND_VOID(VCCB_LOG->wIdx, MAX_SHM_LOG_CNT + 1);

    if (false == FnVCCB_FilterByGnbNum(call.gnbNum)) return;
    if (false == FnVCCB_FilterByCellNum(call.servCellNum)) return;

    peerInfo_type peerInfo;
    // Initialize PeerInfo for Logging
    logInitIntMsgPeerInfo(&peerInfo, apType);

    const messageHdr_type &msgHdr = *(messageHdr_type *)ptMsg;
    if (direction == RX_MSG)
    {
        peerInfo.apId = msgHdr.src.unitId;
        peerInfo.apUeId = msgHdr.src.contextId;
    }
    else if (direction == TX_MSG)
    {
        peerInfo.apId = msgHdr.dst.unitId;
        peerInfo.apUeId = msgHdr.dst.contextId;
    }

    const VccbDbgLog_type &dbgLog = DBG->log;

    // DSH PRINT
    if (!(dbgLog.logCtlMask & NO_VCCB_LOG_DSH_PRINT))
    {
        LOGFLOW(ptCi, PL_ERROR, "[%s] %5s %5d,%5d [0x%04x] %16s %s\n", getDirection(direction),
            getNodeName(peerInfo.apType), peerInfo.apId, peerInfo.apUeId, msgId, FnVCCB_GetStrStateName(call.state),
            strMsgId(msgId));
    }

    // LOG STORE to SHM
    if (!(dbgLog.logCtlMask & NO_VCCB_LOG_ITSCP_PRINT) &&
        ((dbgLog.logStoreDebugTrace == 0) || ((dbgLog.logStoreDebugTrace == 1) && (call.debugTrace == 1))))
    {
        MUTEX_LOCK(&VCCB_LOG->mutex_write);
        if (!checkAndUploadShmLog(msgSize))  // Check and Upload SHM Log to EMS
        {
            uint32_t local_wIdx = VCCB_LOG->wIdx;
            MUTEX_UNLOCK(&VCCB_LOG->mutex_write);
            VCCB_PRINT_CALL_ERROR(ptCi, "%s failed! (wIdx=%u, length=%u)\n", __func__, local_wIdx, msgSize);
            return;
        }

        const uint32_t logIndex = VCCB_LOG->wIdx;
        shmLogMeta_type &logMeta = VCCB_LOG->logMeta[logIndex];
        VCCB_CHECK_E_RANGE_AND_UNLOCK_VOID(
            logMeta.dataOffset + msgSize, SHM_LOG_SIZE * (MAX_SHM_LOG_CNT + 1), &VCCB_LOG->mutex_write);
        LOG_SHM_COMMON_MSG(call, logMeta, SHMLOG_MSG, logMeta.dataOffset + msgSize);

        if (call.callId < MAX_CALL_NUM_VCCB)
        {
            if (msgCallSetupReq_VnmbVccb_id == msgId)
            {
                logMeta.previousLogIndex = 0xFFFFFFFF;
            }
            else
            {
                logMeta.previousLogIndex = VCCB_LOG->previousLogIndex[call.callId];
            }
            VCCB_LOG->previousLogIndex[call.callId] = logIndex;
        }
        else
        {
            logMeta.previousLogIndex = 0xFFFFFFFF;
        }
        setLogMetaUe(logMeta.ue, call);

        shmLogMsgFlow_type &logMsgFlow = logMeta.u.logMsgFlow;
        setShmLogMsgFlow(logMsgFlow, direction, msgId, msgSize, peerInfo);

        memcpy((char *)&VCCB_LOG_DATA[logMeta.dataOffset], ptMsg, msgSize);
    }
}

/**
 * @brief logging Vccb Internal NonUE or UnknownUE Message Flows //VNMB, VNLB, VCLB, VTMB, etc..
 *
 * @param [in] direction : direction of message. RX_MSG/TX_MSG
 * @param [in] apType : peer block information. BLK_VNMB, BLK_VNLB, BLK_VCLB, etc..
 * @param [in] msgId : message Id.
 * @param [in] msgSize : length of message to logging(store)
 * @param [in] ptMsg : sctpDataType or CallSetupReq msg. It is for the information of PeerInfo and message length, data.
 * @return N/A
 */
void logShmNonUeIntMsg(
    enumDirection direction, uint8_t apType, uint16_t msgId, uint32_t msgSize, uint8_t *ptMsg, uint8_t invalidFlag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptMsg);
    VCCB_CHECK_E_RANGE_AND_VOID(VCCB_LOG->wIdx, MAX_SHM_LOG_CNT + 1);

    peerInfo_type peerInfo;
    // Initialize PeerInfo for Logging
    logInitIntMsgPeerInfo(&peerInfo, apType);
    peerInfo.invalidFlag = invalidFlag;

    const VccbDbgLog_type &dbgLog = DBG->log;

    // DSH PRINT
    if (!(dbgLog.logCtlMask & NO_VCCB_LOG_DSH_PRINT))
    {
        LOGFPRT(PL_ERROR, "[%s] %5s [0x%04x] %s\n", getDirection(direction), getNodeName(peerInfo.apType), msgId,
            strMsgId(msgId));
    }

#ifdef IPC_TEST
    if (sizeof(message_type) < msgSize)
    {
        LOGFPRT(PL_ERROR, "[%s] %5s [0x%04x] %s : MsgSize(%d) Overload Protection!!\n", getDirection(direction),
            getNodeName(peerInfo.apType), msgId, strMsgId(msgId), msgSize);
        return;
    }
#endif

    // LOG STORE to SHM
    if (!(dbgLog.logCtlMask & NO_VCCB_LOG_ITSCP_PRINT) && (dbgLog.logStoreDebugTrace == 0))
    {
        MUTEX_LOCK(&VCCB_LOG->mutex_write);
        if (!checkAndUploadShmLog(msgSize))  // Check and Upload SHM Log to EMS
        {
            uint32_t local_wIdx = VCCB_LOG->wIdx;
            MUTEX_UNLOCK(&VCCB_LOG->mutex_write);
            VCCB_PRINT_ERROR("%s failed! (wIdx=%u, length=%u)\n", __func__, local_wIdx, msgSize);
            return;
        }

        shmLogMeta_type &logMeta = VCCB_LOG->logMeta[VCCB_LOG->wIdx];
        VCCB_CHECK_E_RANGE_AND_UNLOCK_VOID(
            logMeta.dataOffset + msgSize, SHM_LOG_SIZE * (MAX_SHM_LOG_CNT + 1), &VCCB_LOG->mutex_write);

        /* set next offset */
        /* offset caculation is done first, to reduce mutex delay */
        VCCB_LOG->wIdx++;

        if (VCCB_LOG->wIdx >= MAX_SHM_LOG_CNT + 1)
        {
            VCCB_PRINT_ERROR("%s is out of range (%llu:%llu)\n", "VCCB_LOG->wIdx", (unsigned long long)VCCB_LOG->wIdx,
                (unsigned long long)MAX_SHM_LOG_CNT + 1);
            MUTEX_UNLOCK(&VCCB_LOG->mutex_write);
            return;
        };

        VCCB_LOG->logMeta[VCCB_LOG->wIdx].dataOffset = logMeta.dataOffset + msgSize;
        MUTEX_UNLOCK(&VCCB_LOG->mutex_write);
        /* update log detail info */
        ComTimeUtil::get_current_time(logMeta.loggingTime);
        /* Multi-gNB //pShmLogMeta->gnbId          = GNBINFO.globalGnbId.gnbId.id;    */
        logMeta.gnbNum = UNKNOWN_GNB_NUM;
        logMeta.vmId = static_cast<uint8_t>(CFG->vm.unitId);
        initLogMetaUe(logMeta.ue);
        logMeta.type = SHMLOG_MSG;

        shmLogMsgFlow_type &logMsgFlow = logMeta.u.logMsgFlow;
        setShmLogMsgFlow(logMsgFlow, direction, msgId, msgSize, peerInfo);

        memcpy((char *)&VCCB_LOG_DATA[logMeta.dataOffset], ptMsg, msgSize);
    }
}

/**
 * @brief logging Vccb External Message Flows //E1, F1, X2, etc..
 *
 * @param [in] ptCi : callInfo
 * @param [in] direction : direction of message. RX_MSG/TX_MSG
 * @param [in] msgId : message Id.
 * @param [in] ptMsg : sctpDataType or CallSetupReq msg. It is for the information of PeerInfo and message length, data.
 * @param [in] peerUeId : peer Ue Id.
 * @return N/A
 */
void logShmExtMsg(
    const callInfo_type *ptCi, enumDirection direction, uint16_t msgId, const void *ptMsg, const int64_t peerApUeId)
{
    AUTO_TRACE_FUNC;

    // Validation Check.
    VALID_E_POINT_CHECK_VOID(ptCi);
    const auto &call = *ptCi;
    VALID_E_POINT_CHECK_VOID(ptMsg);
    VCCB_CHECK_E_RANGE_AND_VOID(VCCB_LOG->wIdx, MAX_SHM_LOG_CNT + 1);

    if (false == FnVCCB_FilterByGnbNum(call.gnbNum)) return;
    if (false == FnVCCB_FilterByCellNum(call.servCellNum)) return;

    message_type *ptAll = (message_type *)ptMsg;
    uint16_t msgIdForInternal = ptAll->msgHdr.msgType;
    uint32_t length = 0;
    uint8_t *data = NULL;
    peerInfo_type peerInfo;
    uint32_t rxPdcpSnOfF1RrcDeliveryReport = 0;

    if (direction == TX_MSG)
    {
        uint16_t endianMsgId = msgIdForInternal;
        ENDIAN_CONVERT(endianMsgId);

        if (SctpDataTransfer_id == endianMsgId) msgIdForInternal = SctpDataTransfer_id;
    }

    switch (msgIdForInternal)
    {
        case msgCallSetupReq_VnmbVccb_id:
        case msgCallResumeInd_VnmbVccb_id:
        case InternalRelayCallResumeInd_id:
            length = ((msgCallSetupReq_type *)ptMsg)->length;
            data = ((msgCallSetupReq_type *)ptMsg)->data;
            logInitExtMsgPeerInfo(ptCi, direction, (uint8_t *)ptAll, &peerInfo, peerApUeId);
            break;

        case msgRetrieveUeContextRequest_VnmbVccb_id:
            length = ((msgRetrieveUeContextRequest_type *)ptMsg)->length;
            data = ((msgRetrieveUeContextRequest_type *)ptMsg)->data;
            logInitExtMsgPeerInfo(ptCi, direction, (uint8_t *)ptAll, &peerInfo, peerApUeId);
            break;

        case msgRetrieveUeContextResult_VnmbVccb_id:
            length = ((msgRetrieveUeContextResult_type *)ptMsg)->length;
            data = ((msgRetrieveUeContextResult_type *)ptMsg)->data;
            logInitExtMsgPeerInfo(ptCi, direction, (uint8_t *)ptAll, &peerInfo, peerApUeId);
            break;

        case msgTransferMessage_VnmbVccb_id:
        case msgTransferMessage_VccbVnmb_id:
            length = ((msgTransferMessage_type *)ptMsg)->length;
            data = ((msgTransferMessage_type *)ptMsg)->data;
            logInitExtMsgPeerInfo(ptCi, direction, (uint8_t *)ptAll, &peerInfo, peerApUeId);
            break;

        case SctpDataTransfer_id:
            length = ((SctpDataType *)ptMsg)->length;
            data = ((SctpDataType *)ptMsg)->data;
            logInitExtMsgPeerInfo(ptCi, direction, (uint8_t *)ptAll, &peerInfo, peerApUeId);
            rxPdcpSnOfF1RrcDeliveryReport = ((SctpDataType *)ptMsg)->reserved_3;
            break;

        default:
            VCCB_PRINT_CALL_ERROR(
                ptCi, "invalid messageType(0x%X, %s), \n", msgIdForInternal, strMsgId(msgIdForInternal));
            return;
    }

    const VccbDbgLog_type &dbgLog = DBG->log;
    // DSH PRINT
    if (!(dbgLog.logCtlMask & NO_VCCB_LOG_DSH_PRINT))
    {
        LOGFLOW(ptCi, PL_ERROR, "[%s] %5s %5d,%5d [0x%04x] %16s %s\n", getDirection(direction),
            getNodeName(peerInfo.apType), peerInfo.apId, peerInfo.apUeId, msgId, FnVCCB_GetStrStateName(call.state),
            strMsgId(msgId));
    }

    // LOG STORE to SHM
    if (!(dbgLog.logCtlMask & NO_VCCB_LOG_ITSCP_PRINT) &&
        ((dbgLog.logStoreDebugTrace == 0) || ((dbgLog.logStoreDebugTrace == 1) && (call.debugTrace == 1))))
    {
        MUTEX_LOCK(&VCCB_LOG->mutex_write);
        if (!checkAndUploadShmLog(length))  // Check and Upload SHM Log to EMS
        {
            uint32_t local_wIdx = VCCB_LOG->wIdx;
            MUTEX_UNLOCK(&VCCB_LOG->mutex_write);
            VCCB_PRINT_CALL_ERROR(ptCi, "%s failed! (wIdx=%u, length=%u)\n", __func__, local_wIdx, length);
            return;
        }

        const uint32_t logIndex = VCCB_LOG->wIdx;
        shmLogMeta_type &logMeta = VCCB_LOG->logMeta[logIndex];
        VCCB_CHECK_E_RANGE_AND_UNLOCK_VOID(
            logMeta.dataOffset + length, SHM_LOG_SIZE * (MAX_SHM_LOG_CNT + 1), &VCCB_LOG->mutex_write);
        LOG_SHM_COMMON_MSG_WITH_PREV_LOG_INDEX(call, logMeta, SHMLOG_MSG, logIndex, logMeta.dataOffset + length);
        setLogMetaUe(logMeta.ue, call);

        shmLogMsgFlow_type &logMsgFlow = logMeta.u.logMsgFlow;
        setShmLogMsgFlow(logMsgFlow, direction, msgId, length, peerInfo);
        if (msgId == F1_RRCDeliveryReport_id)
        {
            logMsgFlow.upCallId = rxPdcpSnOfF1RrcDeliveryReport;
        }

        memcpy((char *)&VCCB_LOG_DATA[logMeta.dataOffset], data, length);
    }
}

/**
 * @brief logging Vccb RRC Message Flows
 *
 * @param [in] ptCi : callInfo
 * @param [in] direction : direction of message. RX_MSG/TX_MSG
 * @param [in] msgId : message Id.
 * @param [in] msgSize : message size to store.
 * @param [in] ptMsg : message pointer to store.
 * @param [in] ptSctp : [OPTIONAL] for the information of PeerInfo and message length, data.
 * @param [in] peerUeId : peer Ue Id.
 * @return N/A
 */
void logShmRrcMsg(const callInfo_type *ptCi, enumDirection direction, uint16_t msgId, uint32_t msgSize, uint8_t *ptMsg,
    uint8_t *ptPeerInfoMsg, const int64_t peerApUeId)
{
    AUTO_TRACE_FUNC;

    // Validation Check.
    VALID_E_POINT_CHECK_VOID(ptCi);
    const auto &call = *ptCi;
    VALID_E_POINT_CHECK_VOID(ptPeerInfoMsg);
    VALID_E_POINT_CHECK_VOID(ptMsg);
    VCCB_CHECK_E_RANGE_AND_VOID(VCCB_LOG->wIdx, MAX_SHM_LOG_CNT + 1);

    if (false == FnVCCB_FilterByGnbNum(call.gnbNum)) return;
    if (false == FnVCCB_FilterByCellNum(call.servCellNum)) return;

    peerInfo_type peerInfo;
    // Initialize PeerInfo for Logging
    logInitExtMsgPeerInfo(ptCi, direction, ptPeerInfoMsg, &peerInfo, peerApUeId);
    peerInfo.apType = BLK_UE;

    if ((NRRRC_RrcRelease_id == msgId) && (call.ueInfo.ueId.iRNTI != UNKNOWN_IRNTI))
    {
        peerInfo.apUeId = GET_IRNTI_UE_ID(call.ueInfo.ueId.iRNTI);
    }
    else if (NRRRC_RrcResumeRequest1_id == msgId)
    {
        peerInfo.apUeId = GET_IRNTI_UE_ID(call.ueInfo.rrcResumeInfo.resumeIRNTI);
    }

    const VccbDbgLog_type &dbgLog = DBG->log;
    // DSH PRINT
    if (!(dbgLog.logCtlMask & NO_VCCB_LOG_DSH_PRINT))
    {
        LOGFLOW(ptCi, PL_ERROR, "[%s] %5s %5d,%5d [0x%04x] %16s %s\n", getDirection(direction),
            getNodeName(peerInfo.apType), peerInfo.apId, peerInfo.apUeId, msgId, FnVCCB_GetStrStateName(call.state),
            strMsgId(msgId));
    }

    // LOG STORE to SHM
    if (!(dbgLog.logCtlMask & NO_VCCB_LOG_ITSCP_PRINT) &&
        ((dbgLog.logStoreDebugTrace == 0) || ((dbgLog.logStoreDebugTrace == 1) && (call.debugTrace == 1))))
    {
        MUTEX_LOCK(&VCCB_LOG->mutex_write);
        if (!checkAndUploadShmLog(msgSize))  // Check and Upload SHM Log to EMS
        {
            uint32_t local_wIdx = VCCB_LOG->wIdx;
            MUTEX_UNLOCK(&VCCB_LOG->mutex_write);
            VCCB_PRINT_CALL_ERROR(ptCi, "%s failed! (wIdx=%u, length=%u)\n", __func__, local_wIdx, msgSize);
            return;
        }

        const uint32_t logIndex = VCCB_LOG->wIdx;
        shmLogMeta_type &logMeta = VCCB_LOG->logMeta[logIndex];
        VCCB_CHECK_E_RANGE_AND_UNLOCK_VOID(
            logMeta.dataOffset + msgSize, SHM_LOG_SIZE * (MAX_SHM_LOG_CNT + 1), &VCCB_LOG->mutex_write);
        LOG_SHM_COMMON_MSG_WITH_PREV_LOG_INDEX(call, logMeta, SHMLOG_MSG, logIndex, logMeta.dataOffset + msgSize);
        setLogMetaUe(logMeta.ue, call);

        shmLogMsgFlow_type &logMsgFlow = logMeta.u.logMsgFlow;
        setShmLogMsgFlow(logMsgFlow, direction, msgId, msgSize, peerInfo);

        // Save PDCP SN
        logMsgFlow.upCallId = call.dlNasAckInfo.savedSendingDlNasPdcpSn;

        memcpy((char *)&VCCB_LOG_DATA[logMeta.dataOffset], ptMsg, msgSize);
    }
}

/**
 * @fn int appendLogmeasResult2NR(char *buffer, int buffSize, measResult2NR_type *ptMeasResult2NR)
 * @brief   append log string of measResultList2NR to buffer
 * @param   buffer              [in] Buffer
 * @param   buffSize            [in] Buffer size
 * @param   ptMeasResult2NR [in] pointer of measResult2NR_type
 * @param   pCheckPrintFunc     [in] function pointer for comparison function checking if specific result should be
 * printed
 * @return  appended string length
 */
int appendLogmeasResult2NR(char *buffer, int buffSize, measResult2NR_type *ptMeasResult2NR,
    bool (*pCheckPrintFunc)(measResultNR_type *ptMeasResult2NR))
{
    int j;
    int strLen = 0;

    measResultListNR_type *ptMeasResultListNR = NULL;
    measResultNR_type *ptMeasResultNR = NULL;
    measResultNR_type *ptMeasResultServingCell = NULL;

#define LOG_BUF buffer + strLen

    if (ptMeasResult2NR->ssbFrequency_Flag == TRUE)
    {
        strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), "freq:%d ", ptMeasResult2NR->ssbFrequency);
    }
    else
    {
        strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), "freq:- ");
    }

    ptMeasResultListNR = &ptMeasResult2NR->measResultNeighCellListNR;

    strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), "nC:%d ", ptMeasResultListNR->nrofCellReport);

    for (j = 0; j < MIN(ptMeasResultListNR->nrofCellReport, MAX_NUM_CELL_REPORT); j++)
    {
        ptMeasResultNR = &ptMeasResultListNR->measResultNR[j];

        if (pCheckPrintFunc(ptMeasResultNR) == false) continue;

        if (ptMeasResultNR->physCellIdFlag == TRUE)
        {
            strLen +=
                snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), "n%d[pci:%d ", j, ptMeasResultNR->physCellId);
        }
        else
        {
            strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), "n%d[pci:- ", j);
        }

        if (ptMeasResultNR->cellResults.resultsSSB_CellFlag == TRUE)
        {
            if (ptMeasResultNR->cellResults.resultsSSB_Cell.rsrpFlag == TRUE)
            {
                strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), "%d|",
                    ptMeasResultNR->cellResults.resultsSSB_Cell.rsrp);
            }
            else
            {
                strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), "-|");
            }

            if (ptMeasResultNR->cellResults.resultsSSB_Cell.rsrqFlag == TRUE)
            {
                strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), "%d",
                    ptMeasResultNR->cellResults.resultsSSB_Cell.rsrq);
            }
            else
            {
                strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), "-");
            }
        }
        else
        {
            strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), "-|-");
        }

        if (ptMeasResultNR->cgiInfoFlag == TRUE && ptMeasResultNR->cgiInfo.plmn_IdentityInfoList_Flag == TRUE &&
            ptMeasResultNR->cgiInfo.plmn_IdentityInfoList.nrofPLMN_IdentityInfo > 0)
        {
            strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), " nci:%lu]",
                ptMeasResultNR->cgiInfo.plmn_IdentityInfoList.plmn_IdentityInfo[0].cellIdentity);
        }
        else
        {
            strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), " nci:-]");
        }

        // First matching record printed, break;
        break;
    }
    ptMeasResultServingCell = &ptMeasResult2NR->measResultServingCell;

    if (pCheckPrintFunc(ptMeasResultServingCell) == false) 
    {
        return strLen;
    }

    if (ptMeasResultServingCell->physCellIdFlag == TRUE)
    {
        strLen +=
            snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), "s[pci:%d ", ptMeasResultServingCell->physCellId);
    }
    else
    {
        strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), "s[pci:- ");
    }

    if (ptMeasResultServingCell->cellResults.resultsSSB_CellFlag == TRUE)
    {
        if (ptMeasResultServingCell->cellResults.resultsSSB_Cell.rsrpFlag == TRUE)
        {
            strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), "%d|",
                ptMeasResultServingCell->cellResults.resultsSSB_Cell.rsrp);
        }
        else
        {
            strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), "-|");
        }

        if (ptMeasResultServingCell->cellResults.resultsSSB_Cell.rsrqFlag == TRUE)
        {
            strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), "%d]",
                ptMeasResultServingCell->cellResults.resultsSSB_Cell.rsrq);
        }
        else
        {
            strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), "-]");
        }
    }
    else
    {
        strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), "-|-");
    }

    if (ptMeasResultServingCell->cgiInfoFlag == TRUE &&
        ptMeasResultServingCell->cgiInfo.plmn_IdentityInfoList_Flag == TRUE &&
        ptMeasResultServingCell->cgiInfo.plmn_IdentityInfoList.nrofPLMN_IdentityInfo > 0)
    {
        strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), " nci:%lu]",
            ptMeasResultServingCell->cgiInfo.plmn_IdentityInfoList.plmn_IdentityInfo[0].cellIdentity);
    }
    else
    {
        strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), " nci:-]");
    }

    return strLen;
}

/**
 * @fn int FnVCCB_appendLogMeasResultList2NR_Core(char *buffer, int buffSize, measResultList2NR_type
 *ptMeasResultList2NR, bool (*pCheckFunc)(measResult2NR_type *ptMeasResult2NR), bool
 (*pCheckPrintFunc)(measResultNR_type *ptMeasResult2NR), bool printCandCnt, const int maxNumberOfOutputFrequencies
 * @brief   append log string of measResultList2NR to buffer
 * @param   buffer              [in] Buffer
 * @param   buffSize            [in] Buffer size
 * @param   ptMeasResultList2NR [in] pointer of measResultList2NR_type
 * @param   pCheckFunc          [in] function pointer for comparison function checking if MeasFreq meets conditions to
 print its element
 * @param   pCheckPrintFunc     [in] function pointer for comparison function checking if specific result should be
 printed
 * @param   maxNumberOfOutputFrequencies [in] maximum number of frequencies to print in log
 * @return  appended string length
 */
VCCB_STATIC_INLINE
int FnVCCB_appendLogMeasResultList2NR_Core(char *buffer, int buffSize, measResultList2NR_type *ptMeasResultList2NR,
    bool (*pCheckFunc)(measResult2NR_type *ptMeasResult2NR),
    bool (*pCheckPrintFunc)(measResultNR_type *ptMeasResult2NR),
    bool printCandCnt = false,
    const int maxNumberOfOutputFrequencies = 1)
{
    int strLen = 0;
    int tgtMeasFreqCnt = 0;
    int measFreqIdx = 0;
    uint16_t candCnt = 0;
    int numberOfOutputFrequencies = 0;
    measResult2NR_type *ptMeasResult2NR = NULL;

    VALID_E_POINT_CHECK_ZERO(buffer);
    VALID_E_POINT_CHECK_ZERO(ptMeasResultList2NR);
    VALID_E_POINT_CHECK_ZERO(pCheckFunc);

    for (measFreqIdx = 0; measFreqIdx < ptMeasResultList2NR->nrofFreq; measFreqIdx++)
    {
        ptMeasResult2NR = &ptMeasResultList2NR->measResult2NR[measFreqIdx];

        if (pCheckFunc(ptMeasResult2NR) == true)
        {
            tgtMeasFreqCnt++;
            if (true == CHECK_CONDITION_NCI(&ptMeasResult2NR->measResultServingCell) && true == printCandCnt)
            {
                candCnt++;
            }
        }

        auto ptMeasResultNeighCellListNR = &ptMeasResult2NR->measResultNeighCellListNR;
        for (uint8_t loop = 0; loop < UMIN(ptMeasResultNeighCellListNR->nrofCellReport, MAX_NUM_CELL_REPORT); loop++)
        {
            if (false == printCandCnt)
            {
                break;
            }

            if (pCheckPrintFunc(&ptMeasResultNeighCellListNR->measResultNR[loop]) == true)
            {
                candCnt++;
                VCCB_CHECK_E_RANGE_AND_BREAK(candCnt, MAX_NUM_CANDIDATE_CELL_FOR_PSCELL);
            }
        }
    }

    if (tgtMeasFreqCnt == 0) return 0;

#define LOG_BUF buffer + strLen

    if (true == printCandCnt)
    {
        strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), "totCand:%d ", candCnt);
    }
    strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), "nF:%d ", tgtMeasFreqCnt);

    for (measFreqIdx = 0; measFreqIdx < ptMeasResultList2NR->nrofFreq; measFreqIdx++)
    {
        ptMeasResult2NR = &ptMeasResultList2NR->measResult2NR[measFreqIdx];

        if (pCheckFunc(ptMeasResult2NR) == false) continue;

        strLen += appendLogmeasResult2NR(LOG_BUF, buffSize - strLen, ptMeasResult2NR, pCheckPrintFunc);

        numberOfOutputFrequencies++;

        if (numberOfOutputFrequencies >= maxNumberOfOutputFrequencies) break;

        strLen += snprintf(LOG_BUF, static_cast<size_t>(buffSize - strLen), ", ");
    }

    return strLen;
}

/**
 * @fn int appendLogMeasResultList2NR(char *buffer, int buffSize, measResultList2NR_type *ptMeasResultList2NR)
 * @brief   append log string of measResultList2NR to buffer
 * @param   buffer              [in] Buffer
 * @param   buffSize            [in] Buffer size
 * @param   ptMeasResultList2NR [in] pointer of measResultList2NR_type
 * @return  appended string length
 */
int appendLogMeasResultList2NR(char *buffer, int buffSize, measResultList2NR_type *ptMeasResultList2NR)
{
    auto checkConditionAll = [](measResult2NR_type *ptMeasResult2NR)
    {
        if (ptMeasResult2NR == NULL) return false;
        return true;
    };

    auto checkConditionPrintAll = [](measResultNR_type *ptMeasResultNR)
    {
        if (ptMeasResultNR == NULL) return false;
        return true;
    };

    return FnVCCB_appendLogMeasResultList2NR_Core(
        buffer, buffSize, ptMeasResultList2NR, checkConditionAll, checkConditionPrintAll);
}

/**
 * @fn int appendLogMeasResultList2NR_FR1(char *buffer, int buffSize, measResultList2NR_type *ptMeasResultList2NR)
 * @brief   append log string of measResultList2NR to buffer
 * @param   buffer              [in] Buffer
 * @param   buffSize            [in] Buffer size
 * @param   ptMeasResultList2NR [in] pointer of measResultList2NR_type
 * @param   maxNumberOfOutputFrequencies [in] maximum number of frequencies to print in log
 * @return  appended string length
 */
int FnVCCB_appendLogMeasResultList2NR_FR1(
    char *buffer, int buffSize, measResultList2NR_type *ptMeasResultList2NR, const int maxNumberOfOutputFrequencies)
{
    auto checkConditionFr1 = [](measResult2NR_type *ptMeasResult2NR)
    {
        if (ptMeasResult2NR == NULL) return false;
        if (ptMeasResult2NR->ssbFrequency_Flag == FALSE) return false;
        if (FnVCCB_IsFr1Freq(ptMeasResult2NR->ssbFrequency) == false) return false;
        return true;
    };

    auto checkConditionPrintAll = [](measResultNR_type *ptMeasResultNR)
    {
        if (ptMeasResultNR == NULL) return false;
        return true;
    };

    return FnVCCB_appendLogMeasResultList2NR_Core(
        buffer, buffSize, ptMeasResultList2NR, checkConditionFr1, checkConditionPrintAll, false, maxNumberOfOutputFrequencies);
}

/**
 * @fn int appendLogMeasResultList2NR_FR2(char *buffer, int buffSize, measResultList2NR_type *ptMeasResultList2NR)
 * @brief   append log string of measResultList2NR to buffer
 * @param   buffer              [in] Buffer
 * @param   buffSize            [in] Buffer size
 * @param   ptMeasResultList2NR [in] pointer of measResultList2NR_type
 * @param   maxNumberOfOutputFrequencies [in] maximum number of frequencies to print in log
 * @return  appended string length
 */
int FnVCCB_appendLogMeasResultList2NR_FR2(
    char *buffer, int buffSize, measResultList2NR_type *ptMeasResultList2NR, const int maxNumberOfOutputFrequencies)
{
    auto checkConditionFr2 = [](measResult2NR_type *ptMeasResult2NR)
    {
        if (ptMeasResult2NR == NULL) return false;
        if (ptMeasResult2NR->ssbFrequency_Flag == FALSE) return false;
        if (FnVCCB_IsFr2Freq(ptMeasResult2NR->ssbFrequency) == false) return false;
        return true;
    };

    auto checkConditionPrintAll = [](measResultNR_type *ptMeasResultNR)
    {
        if (ptMeasResultNR == NULL) return false;
        return true;
    };

    return FnVCCB_appendLogMeasResultList2NR_Core(
        buffer, buffSize, ptMeasResultList2NR, checkConditionFr2, checkConditionPrintAll, false, maxNumberOfOutputFrequencies);
}

/**
 * @fn int FnVCCB_appendLogMeasResultList2NR_NCI(char *buffer, int buffSize, measResultList2NR_type
 * *ptMeasResultList2NR)
 * @brief   append log string of measResultList2NR with NRCGI included to buffer
 * @param   buffer              [in] Buffer
 * @param   buffSize            [in] Buffer size
 * @param   ptMeasResultList2NR [in] pointer of measResultList2NR_type
 * @param   maxNumberOfOutputFrequencies [in] maximum number of frequencies to print in log
 * @return  appended string length
 */
int FnVCCB_appendLogMeasResultList2NR_NCI(
    char *buffer, int buffSize, measResultList2NR_type *ptMeasResultList2NR, const int maxNumberOfOutputFrequencies)
{
    auto checkConditionNCI = [](measResult2NR_type *ptMeasResult2NR)
    {
        if (ptMeasResult2NR == NULL)
        {
            return false;
        }

        const auto &NeighCL = ptMeasResult2NR->measResultNeighCellListNR;

        for (int i = 0; i < MIN(NeighCL.nrofCellReport, MAX_NUM_CELL_REPORT); i++)
        {
            if (CHECK_CONDITION_NCI(&NeighCL.measResultNR[i]))
            {
                return true;
            }
        }

        return CHECK_CONDITION_NCI(&ptMeasResult2NR->measResultServingCell);
    };

    auto checkConditionPrintNciCandidate = [](measResultNR_type *ptMeasResultNR)
    {
        if (ptMeasResultNR == NULL)
        {
            return false;
        }

        return CHECK_CONDITION_NCI(ptMeasResultNR);
    };

    return FnVCCB_appendLogMeasResultList2NR_Core(buffer, buffSize, ptMeasResultList2NR, checkConditionNCI,
        checkConditionPrintNciCandidate, true, maxNumberOfOutputFrequencies);
}

/**
 * @brief This function is to print VRRM log.
 * @param [in] level : print level
 * @param [in] fmt : context for print.
 * @return void
 * @exception N /A
 */
void VRRM_PRINT(uint8_t level, const char *fmt, ...)
{
    AUTO_TRACE_FUNC;

    int length, blen;
    va_list argPtr;
    char vrrmLogBuf[1024];

    if (fmt == NULL)
    {
        return;
    }

    memset(&vrrmLogBuf, 0, 1024);

    snprintf(vrrmLogBuf, 9, "        ");
    //#endif
    blen = (int)strnlen(vrrmLogBuf, 1024);

    va_start(argPtr, fmt);

    length = vsnprintf(vrrmLogBuf + blen, static_cast<size_t>(1024 - blen), fmt, argPtr);

    if ((length + blen) < 1024)
    {
        vrrmLogBuf[length + blen] = 0;
    }
    else
    {
        vrrmLogBuf[1023] = 0;
    }

    va_end(argPtr);

    //==========(SRKIM) From now on, level means PL_XXX, not VRRM_XXX ===============
    dusPrint("VRRM", level, vrrmLogBuf);
    //==============================================================================
}

#undef LOG_BUF

void FnVCCB_RequestLogFishing(callInfo_type *ptCi, uint16_t eventId)
{
    AUTO_TRACE_FUNC;
    int loop;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(eventId, LOG_FISHING_MANUAL_EVENT_ID_END);

    VccbLogFishingEvent_type *pLogFishingEvent = NULL;
    for (loop = 0; loop < MIN(VCCB_LOG_FISHING->eventCount, VCCB_MAX_LOG_FISHING_EVENT_COUNT); loop++)
    {
        if (eventId == VCCB_LOG_FISHING->eventList[loop].eventId)
        {
            pLogFishingEvent = &VCCB_LOG_FISHING->eventList[loop];
            if (ptCi->myThreadId < MAX_CALL_THREAD_NUM_VCCB)
            {
                pLogFishingEvent->occurrenceCount[ptCi->myThreadId]++;
            }
            break;
        }
    }

    if (pLogFishingEvent != NULL)
    {
        if (DBG->logFishing.status == VCCB_FLAG_ON && pLogFishingEvent->isLogging == TRUE &&
            gLogFishingRequestCount[ptCi->myThreadId] < DBG->logFishing.maxRequestPerSecondPerThread &&
            pLogFishingEvent->wIdx < MAX_SHM_LOG_FISHING_CNT)
        {
            const auto &loggingTime = VCCB_LOG_FISHING->logMeta[pLogFishingEvent->wIdx].loggingTime;
            const auto &timeElapsed = ComTimeUtil::get_elapsed_time(loggingTime);
            if ((DBG->logFishing.minLogKeepingTime == 0) ||
                (timeElapsed.tv_sec > ((long)DBG->logFishing.minLogKeepingTime) * 60))
            {
                int status = FnVCCB_SendInternalLogFishingRequest(ptCi, eventId);
                if (status == ERROR)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendInternalLogFishingRequest ERROR!\n");
                }
            }
        }
    }
    else
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "pLogFishingEvent in null(eventId=%d) in %s\n", eventId, __func__);
    }
    return;
}

void FnVCCB_PrintMeasResultList2NR(callInfo_type *ptCi, measResultList2NR_type *ptMeasResultList, const char *ptBuffName,
    enumFrFreq_type mode, const int maxNumberOfOutputFrequencies)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM3(ptCi, ptMeasResultList, ptBuffName);

    char measResultLogBuf[1024];
    int buffSize = sizeof(measResultLogBuf);
    int writeLength = 0;

    measResultLogBuf[0] = '\0';

    switch (mode)
    {
        case e_FR1Freq:  // Only FR1
            writeLength = FnVCCB_appendLogMeasResultList2NR_FR1(
                measResultLogBuf, buffSize, ptMeasResultList, maxNumberOfOutputFrequencies);
            break;

        case e_FR2Freq:  // Only FR2
            writeLength = FnVCCB_appendLogMeasResultList2NR_FR2(
                measResultLogBuf, buffSize, ptMeasResultList, maxNumberOfOutputFrequencies);
            break;

        default:  // All
            writeLength = appendLogMeasResultList2NR(measResultLogBuf, buffSize, ptMeasResultList);
            break;
    }

    if (writeLength == 0) return;

    // Protection Code
    measResultLogBuf[(buffSize - 1)] = '\0';

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "%s %s\n", ptBuffName, measResultLogBuf);
}

void FnVCCB_PrintMeasResultList2NR_NCI(callInfo_type *ptCi, measResultList2NR_type *ptMeasResultList,
    const char *ptBuffName, const int maxNumberOfOutputFrequencies)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM3(ptCi, ptMeasResultList, ptBuffName);

    char measResultLogBuf[1024];
    int buffSize = sizeof(measResultLogBuf);
    int writeLength = 0;

    measResultLogBuf[0] = '\0';

    writeLength = FnVCCB_appendLogMeasResultList2NR_NCI(
        measResultLogBuf, buffSize, ptMeasResultList, maxNumberOfOutputFrequencies);

    if (writeLength == 0) return;

    // Protection Code
    measResultLogBuf[(buffSize - 1)] = '\0';

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "%s %s\n", ptBuffName, measResultLogBuf);
}

const char *FnVCCB_GetStrActivityNotifLvl(const enumActivityNotifLvl_type level)
{
    switch (level)
    {
        case activityNotifLvl_UE:
            return "UE";
        case activityNotifLvl_DRB:
            return "DRB";
        default:
            return "PDU";
    }
}
void VCCB_PrintDrxConfigInfo(VccbDrxConfigInfo_type &drxConfig, const char *ptFuncName)
{
    VCCB_PRINT_CMD("[C-DRX] DrxConfig Update(%s)\n", ptFuncName);
    if (drxConfig.isPresent != VCCB_FLAG_ON)
    {
        VCCB_PRINT_CMD("[C-DRX] DrxConfig is Not Present!\n");
        return;
    }
    if (drxConfig.storeType == VCCB_LONG_CYCLE_START_OFFSET)
    {
        VCCB_PRINT_CMD("value : longCycleStartOffset(%u)\n", drxConfig.storeData.longCycleStartOffset);
    }
    else
    {
        VCCB_PRINT_CMD("value : drxConfig(%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u)\n",
            drxConfig.storeData.drxConfig.drxLongCycleStartOffsetType,
            drxConfig.storeData.drxConfig.drxLongCycleStartOffset, drxConfig.storeData.drxConfig.drxInactivityTimer,
            drxConfig.storeData.drxConfig.drxHarqRttTimerDL, drxConfig.storeData.drxConfig.drxHarqRttTimerUL,
            drxConfig.storeData.drxConfig.drxRetransmissionTimerDL,
            drxConfig.storeData.drxConfig.drxRetransmissionTimerUL, drxConfig.storeData.drxConfig.shortDrxFlag,
            drxConfig.storeData.drxConfig.drxShortCycle, drxConfig.storeData.drxConfig.drxShortCycleTimer,
            drxConfig.storeData.drxConfig.drxSlotOffset);
    }
    return;
}

/**
 * @brief EstablishmentCause to string
 */
const char *FnVCCB_GetEstablishmentCauseString(const NRRRC_EstablishmentCause cause)
{
    switch (cause)
    {
        case NRRRC_EstablishmentCause_emergency:
            return "emergency";
        case NRRRC_EstablishmentCause_highPriorityAccess:
            return "highPriorityAccess";
        case NRRRC_EstablishmentCause_mt_Access:
            return "mt_Access";
        case NRRRC_EstablishmentCause_mo_Signalling:
            return "mo_Signalling";
        case NRRRC_EstablishmentCause_mo_Data:
            return "mo_Data";
        case NRRRC_EstablishmentCause_mo_VoiceCall:
            return "mo_VoiceCall";
        case NRRRC_EstablishmentCause_mo_VideoCall:
            return "mo_VideoCall";
        case NRRRC_EstablishmentCause_mo_SMS:
            return "mo_SMS";
        case NRRRC_EstablishmentCause_mps_PriorityAccess:
            return "mps_PriorityAccess";
        case NRRRC_EstablishmentCause_mcs_PriorityAccess:
            return "mcs_PriorityAccess";
        case NRRRC_EstablishmentCause_spare6:
            return "spare6";
        case NRRRC_EstablishmentCause_spare5:
            return "spare5";
        case NRRRC_EstablishmentCause_spare4:
            return "spare4";
        case NRRRC_EstablishmentCause_spare3:
            return "spare3";
        case NRRRC_EstablishmentCause_spare2:
            return "spare2";
        case NRRRC_EstablishmentCause_spare1:
            return "spare1";
        default:
            return "unknown";
    }
}

/**
 * @brief ResumeCause to string
 */
const char *FnVCCB_GetResumeCauseString(const NRRRC_ResumeCause cause)
{
    switch (cause)
    {
        case NRRRC_ResumeCause_emergency:
            return "emergency";
        case NRRRC_ResumeCause_highPriorityAccess:
            return "highPriorityAccess";
        case NRRRC_ResumeCause_mt_Access:
            return "mt_Access";
        case NRRRC_ResumeCause_mo_Signalling:
            return "mo_Signalling";
        case NRRRC_ResumeCause_mo_Data:
            return "mo_Data";
        case NRRRC_ResumeCause_mo_VoiceCall:
            return "mo_VoiceCall";
        case NRRRC_ResumeCause_mo_VideoCall:
            return "mo_VideoCall";
        case NRRRC_ResumeCause_mo_SMS:
            return "mo_SMS";
        case NRRRC_rna_Update:
            return "rna_Update";
        case NRRRC_ResumeCause_mps_PriorityAccess:
            return "mps_PriorityAccess";
        case NRRRC_ResumeCause_mcs_PriorityAccess:
            return "mcs_PriorityAccess";
        case NRRRC_ResumeCause_spare1:
            return "spare1";
        case NRRRC_ResumeCause_spare2:
            return "spare2";
        case NRRRC_ResumeCause_spare3:
            return "spare3";
        case NRRRC_mt_SDT_v1810:
            return "mt_SDT_v1810";
        case NRRRC_srs_PosConfigOrActivationReq_v1800:
            return "srs_PosConfigOrActivationReq_v1800";
        default:
            return "unknown";
    }
}

/**
 * @brief x2Cause to string
 */
const char *FnVCCB_GetX2CauseToStr(const uint32_t cause)
{
    switch (cause)
    {
        TO_STRING_IN_SWITCH(CAUSE_NO_FAULT);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerHandoverDesirableForRadioReasons);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerTimeCriticalHandover);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerResourceOptimisationHandover);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerReduceLoadInServingCell);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerPartialHandover);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerUnknownNewEnbUeX2apId);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerUnknownOldEnbUeX2apId);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerUnknownPairOfUeX2apId);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerHoTargetNotAllowed);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerTx2relocoverallExpiry);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerTrelocoverallExpiry);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerCellNotAvailable);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerNoRadioResourcesAvailableInTargetCell);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerInvalidMMEGroupID);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerUnknownMMECode);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerEncryptionAndOrIntegrityProtectionAlgorithmsNotSupported);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerReportCharacteristicsEmpty);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerNoReportPeriodicity);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerExistingMeasurementID);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerUnknownEnbMeasurementID);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerMeasurementTemporarilyNotAvailable);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerUnspecified);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerLoadBalancing);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerHandoverOptimisation);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerValueOutOfAllowedRange);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerMultipleErabIdInstances);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerSwitchOffOngoing);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerNotSupportedQciValue);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerMeasurementNotSupportedForTheObject);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerTdcoverallExpiry);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerTdcprepExpiry);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerActionDesirableForRadioReasons);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerReduceLoad);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerResourceOptimisation);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerTimeCriticalAction);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerTargetNotAllowed);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerNoRadioResourcesAvailable);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerInvalidQosCombination);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerEncryptionAlgorithmsNotSupported);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerProcedureCancelled);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerRrmPurpose);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerImproveUserBitRate);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerUserInactivity);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerRadioConnectionWithUeLost);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerFailureInTheRadioInterfaceProcedure);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerBearerOptionNotSupported);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerMcgMobility);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerScgMobility);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerCountReachesMaxValue);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerUnknownOldEngnbUeX2apId);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerPdcpOverload);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerCHOCPCResourcesToBeChanged);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerUEPowerSaving);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerInsufficientUeCapabilities);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerNormalRelease);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerUnknownEutranNodeMeasurementId);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerScgActivationDeactivationFailure);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerScgDeactivationFailureDueToDataTransmission);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerUpIntegrityProtectionNotPossible);
        TO_STRING_IN_SWITCH(CauseX2apRadioNetworkLayerEnd);

        TO_STRING_IN_SWITCH(CauseX2apTransportNetworkLayerTransportResourceUnavailable);
        TO_STRING_IN_SWITCH(CauseX2apTransportNetworkLayerUnspecified);
        TO_STRING_IN_SWITCH(CauseX2apTransportNetworkLayerEnd);

        TO_STRING_IN_SWITCH(CauseX2apProtocolTransferSyntaxError);
        TO_STRING_IN_SWITCH(CauseX2apProtocolAbstractSyntaxErrorReject);
        TO_STRING_IN_SWITCH(CauseX2apProtocolAbstractSyntaxErrorIgnoreAndNotify);
        TO_STRING_IN_SWITCH(CauseX2apProtocolMessageNotCompatibleWithReceiverState);
        TO_STRING_IN_SWITCH(CauseX2apProtocolSemanticError);
        TO_STRING_IN_SWITCH(CauseX2apProtocolUnspecified);
        TO_STRING_IN_SWITCH(CauseX2apProtocolAbstractSyntaxErrorFalselyConstructedMessage);
        TO_STRING_IN_SWITCH(CauseX2apProtocolEnd);

        TO_STRING_IN_SWITCH(CauseX2apMiscControlProcessingOverload);
        TO_STRING_IN_SWITCH(CauseX2apMiscHardwareFailure);
        TO_STRING_IN_SWITCH(CauseX2apMiscOMIntervention);
        TO_STRING_IN_SWITCH(CauseX2apMiscNotEnoughUserPlaneProcessingResources);
        TO_STRING_IN_SWITCH(CauseX2apMiscUnspecified);
        TO_STRING_IN_SWITCH(CauseX2apMiscEnd);

        default:
            return "Unknown X2Cause";
    }
}

/**
 * @brief xnCause to string
 */
const char *FnVCCB_GetXNCauseToStr(const uint32_t cause)
{
    switch (cause)
    {
        TO_STRING_IN_SWITCH(CAUSE_NO_FAULT);

        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerCellNotAvailable);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerHandoverDesirableForRadioReasons);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerHandoverTargetNotAllowed);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerInvalidAmfSetId);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerNoRadioResourcesAvailableInTargetCell);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerPartialHandover);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerReduceLoadInServingCell);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerResourceOptimisationHandover);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerTimeCriticalHandover);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerTxnRelocOverallExpiry);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerTxnRelocPrepExpiry);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerUnknownGuamiId);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerUnknownLocalNgranNodeUeXnapId);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerInconsistentRemoteNgranNodeUeXnapId);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerEncryptionAndOrIntegrityProtectionAlgorithmsNotSupported);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerProtectionAlgorithmsNotSupported);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerMultiplePduSessionIdInstances);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerUnknownPduSessionId);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerUnknownQosFlowId);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerMultipleQosFlowIdInstances);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerSwitchOffOngoing);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerNotSupported5qiValue);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerTxnDcOverallExpiry);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerTxnDcPrepExpiry);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerActionDesirableForRadioReasons);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerReduceLoad);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerResourceOptimisation);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerTimeCriticalAction);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerTargetNotAllowed);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerNoRadioResourcesAvailable);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerInvalidQosCombination);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerEncryptionAlgorithmsNotSupported);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerProcedureCancelled);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerRrmPurpose);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerImproveUserBitRate);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerUserInactivity);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerRadioConnectionWithUeLost);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerFailureInTheRadioInterfaceProcedure);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerBearerOptionNotSupported);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerUpIntegrityProtectionNotPossible);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerUpConfidentialityProtectionNotPossible);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerResourcesNotAvailableForTheSlice);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerUeMaximumIntegrityProtectedDataRateReason);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerCpIntegrityProtectionFailure);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerUpIntegrityProtectionFailure);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerSlicesNotSupportedByNgran);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerMnMobility);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerSnMobility);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerCountReachesMaxValue);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerUnknownOldNgranNodeUeXnapId);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerPdcpOverload);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerDrbIdNotAvailable);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerUnspecified);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerUeContextIdNotKnown);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerNonRelocationOfContext);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerCHOCPCResourcesToBeChanged);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerRSNNotAvailableForTheUP);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerNPNAccessDenied);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerReportCharacteristicsEmpty);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerExistingMeasurementID);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerMeasurementTemporarilyNotAvailable);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerMeasurementNotSupportedForTheObject);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerUEPowerSaving);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerNotExistingNGRANNode2MeasurementID);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerInsufficientUECapabilities);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerNormalRelease);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerScgActivationDeactivationFailure);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerValueOutOfAllowedRange);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerScgDeactivationFailureDueToDataTransmission);
        TO_STRING_IN_SWITCH(CauseXnapRadioNetworkLayerEnd);

        TO_STRING_IN_SWITCH(CauseXnapTransportLayerTransportResourceUnavailable);
        TO_STRING_IN_SWITCH(CauseXnapTransportLayerUnspecified);
        TO_STRING_IN_SWITCH(CauseXnapTransportLayerEnd);

        TO_STRING_IN_SWITCH(CauseXnapProtocolTransferSyntaxError);
        TO_STRING_IN_SWITCH(CauseXnapProtocolAbstractSyntaxErrorReject);
        TO_STRING_IN_SWITCH(CauseXnapProtocolAbstractSyntaxErrorIgnoreAndNotify);
        TO_STRING_IN_SWITCH(CauseXnapProtocolMessageNotCompatibleWithReceiverState);
        TO_STRING_IN_SWITCH(CauseXnapProtocolSemanticError);
        TO_STRING_IN_SWITCH(CauseXnapProtocolAbstractSyntaxErrorFalselyConstructedMessage);
        TO_STRING_IN_SWITCH(CauseXnapProtocolUnspecified);
        TO_STRING_IN_SWITCH(CauseXnapProtocolEnd);

        TO_STRING_IN_SWITCH(CauseXnapMiscControlProcessingOverload);
        TO_STRING_IN_SWITCH(CauseXnapMiscHardwareFailure);
        TO_STRING_IN_SWITCH(CauseXnapMiscOMIntervention);
        TO_STRING_IN_SWITCH(CauseXnapMiscNotEnoughUserPlaneProcessingResources);
        TO_STRING_IN_SWITCH(CauseXnapMiscUnspecified);
        TO_STRING_IN_SWITCH(CauseXnapMiscEnd);

        default:
            return "Unknown XNCause";
    }
}

/**
 * @brief ngCause to string
 */
const char *FnVCCB_GetNGCauseToStr(const uint32_t cause)
{
    switch (cause)
    {
        TO_STRING_IN_SWITCH(CAUSE_NO_FAULT);

        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerUnspecified);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerTxnrelocoverallExpiry);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerSuccessfulHandover);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerReleaseDueToNgranGeneratedReason);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerReleaseDueTo5gcGeneratedReason);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerHandoverCancelled);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerPartialHandover);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerHandoverFailureInTarget5gcNgranNodeOrTargetSystem);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerHandoverTargetNotAllowed);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerTngrelocoverallExpiry);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerTngrelocprepExpiry);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerCellNotavailable);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerUnknownTargetID);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerNoRadioResourcesAvailableInTargetCell);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerUnknownLocalUeNgapID);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerInconsistentRemoteUeNgapID);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerHandoverDesirableForRadioReasons);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerTimeCriticalHandover);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerResourceOptimisationHandover);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerReduceLoadInServingCell);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerUserInactivity);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerRadioConnectionWithUeLost);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerRadioResourcesNotAvailable);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerInvalidQosCombination);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerFailureInTheRadioInterfaceProcedure);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerInteractionWithOtherProcedure);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerUnknownPduSessionID);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerUnknownQosFlowID);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerMultiplePduSessionIdInstances);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerMultipleQosFlowIdInstances);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerEncryptionAndOrIntegrityProtectionAlgorithmsNotSupported);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerNgIntraSystemHandoverTriggered);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerNgInterSystemHandoverTriggered);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerXnHandoverTriggered);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerNotSupported5qiValue);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerUeContextTransfer);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerImsVoiceEpsFallbackOrRatFallbackTriggered);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerUpIntegrityProtectionNotPossible);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerUpConfidentialityProtectionNotPossible);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerSliceNotSupported);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerUeInRrcInactiveStateNotReachable);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerRedirection);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerResourcesNotAvailableForTheSlice);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerUeMaximumIntegrityProtectedDataRateReason);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerReleaseDueToCnDetectedMobility);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerN26InterfaceNotAvailable);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerReleaseDueToPreEmption);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerMultipleLocationReportingReferenceIDInstances);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerRSNNotAvailableForTheUP);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerNPNAccessDenied);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerCAGOnlyAccessDenied);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerInsufficientUeCapabilities);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerRedcapUeNotSupported);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerUnknownMBSSessionID);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerIndicatedMBSSessionAreaInformationNotServedByTheGNB);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerInconsistentSliceInfoForTheSession);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerMisalignedAssociationForMulticastUnicast);
        TO_STRING_IN_SWITCH(CauseNgapRadioNetworkLayerEnd);

        TO_STRING_IN_SWITCH(CauseNgapTransportLayerTransportResourceUnavailable);
        TO_STRING_IN_SWITCH(CauseNgapTransportLayerUnspecified);
        TO_STRING_IN_SWITCH(CauseNgapTransportLayerEnd);

        TO_STRING_IN_SWITCH(CauseNgapNasNormalRelease);
        TO_STRING_IN_SWITCH(CauseNgapNasAuthenticationFailure);
        TO_STRING_IN_SWITCH(CauseNgapNasDeregister);
        TO_STRING_IN_SWITCH(CauseNgapNasUnspecified);
        TO_STRING_IN_SWITCH(CauseNgapNasUeNotInPlmnServingArea);
        TO_STRING_IN_SWITCH(CauseNgapNasEnd);

        TO_STRING_IN_SWITCH(CauseNgapProtocolTransferSyntaxError);
        TO_STRING_IN_SWITCH(CauseNgapProtocolAbstractSyntaxErrorReject);
        TO_STRING_IN_SWITCH(CauseNgapProtocolAbstractSyntaxErrorIgnoreAndNotify);
        TO_STRING_IN_SWITCH(CauseNgapProtocolMessageNotCompatibleWithReceiverState);
        TO_STRING_IN_SWITCH(CauseNgapProtocolSemanticError);
        TO_STRING_IN_SWITCH(CauseNgapProtocolAbstractSyntaxErrorFalselyConstructedMessage);
        TO_STRING_IN_SWITCH(CauseNgapProtocolUnspecified);
        TO_STRING_IN_SWITCH(CauseNgapProtocolEnd);

        TO_STRING_IN_SWITCH(CauseNgapMiscControlProcessingOverload);
        TO_STRING_IN_SWITCH(CauseNgapMiscNotEnoughUserPlaneProcessingResources);
        TO_STRING_IN_SWITCH(CauseNgapMiscHardwareFailure);
        TO_STRING_IN_SWITCH(CauseNgapMiscOMIntervention);
        TO_STRING_IN_SWITCH(CauseNgapMiscUnknownPlmn);
        TO_STRING_IN_SWITCH(CauseNgapMiscUnspecifiedFailure);
        TO_STRING_IN_SWITCH(CauseNgapMiscEnd);

        default:
            return "Unknown NGCause";
    }
}

/**
 * @brief f1Cause to string
 */
const char *FnVCCB_GetF1CauseToStr(const uint32_t cause)
{
    switch (cause)
    {
        TO_STRING_IN_SWITCH(CAUSE_NO_FAULT);

        TO_STRING_IN_SWITCH(CauseF1apRadioUnspecified);
        TO_STRING_IN_SWITCH(CauseF1apRadioRLFailure);
        TO_STRING_IN_SWITCH(CauseF1apRadioUnknownOrAlreadyAllocatedCuUeF1apId);
        TO_STRING_IN_SWITCH(CauseF1apRadioUnknownOrAlreadyAllocatedDuUeF1apId);
        TO_STRING_IN_SWITCH(CauseF1apRadioUnknownInconsistentPairOfUeF1apId);
        TO_STRING_IN_SWITCH(CauseF1apRadioInteraction);
        TO_STRING_IN_SWITCH(CauseF1apRadioNotSupportedQCI);
        TO_STRING_IN_SWITCH(CauseF1apRadioDesirableRadioReasons);
        TO_STRING_IN_SWITCH(CauseF1apRadioUnavailableRadioReasons);
        TO_STRING_IN_SWITCH(CauseF1apRadioProcedureCancelled);
        TO_STRING_IN_SWITCH(CauseF1apRadioNormalRelease);
        TO_STRING_IN_SWITCH(CauseF1apRadioCellNotAvailable);
        TO_STRING_IN_SWITCH(CauseF1apRadioRLFailureothers);
        TO_STRING_IN_SWITCH(CauseF1apRadioUeRejection);
        TO_STRING_IN_SWITCH(CauseF1apRadioResourcesNotAvailableForTheSlice);
        TO_STRING_IN_SWITCH(CauseF1apRadioAmfInitiatedAbnormalRelease);
        TO_STRING_IN_SWITCH(CauseF1apRadioReleaseDueToPreEmption);
        TO_STRING_IN_SWITCH(CauseF1apRadioPlmnNotServedByTheGnbCu);
        TO_STRING_IN_SWITCH(CauseF1apRadioMultipleDrbIdInstances);
        TO_STRING_IN_SWITCH(CauseF1apRadioUnknownDrbId);
        TO_STRING_IN_SWITCH(CauseF1apRadioMultipleBhRlcChIdInstances);
        TO_STRING_IN_SWITCH(CauseF1apRadioUnknownBhRlcChId);
        TO_STRING_IN_SWITCH(CauseF1apRadioChoCpcResourcesToBeChanged);
        TO_STRING_IN_SWITCH(CauseF1apRadioNpnNotSupported);
        TO_STRING_IN_SWITCH(CauseF1apRadioNpnAccessDenied);
        TO_STRING_IN_SWITCH(CauseF1apRadioGnbCuCellCapacityExceeded);
        TO_STRING_IN_SWITCH(CauseF1apRadioReportCharacteristicsEmpty);
        TO_STRING_IN_SWITCH(CauseF1apRadioExistingMeasurementID);
        TO_STRING_IN_SWITCH(CauseF1apRadioMeasurementTemporarilyNotAvailable);
        TO_STRING_IN_SWITCH(CauseF1apRadioMeasurementNotSupportedForTheObject);
        TO_STRING_IN_SWITCH(CauseF1apRadioUnknownBAPAddress);
        TO_STRING_IN_SWITCH(CauseF1apRadioUnknownBAPRoutingID);
        TO_STRING_IN_SWITCH(CauseF1apRadioInsufficientUeCapabilities);
        TO_STRING_IN_SWITCH(CauseF1apRadioScgActivationDeactivationFailure);
        TO_STRING_IN_SWITCH(CauseF1apRadioScgDeactivationFailureDueToDataTransmission);
        TO_STRING_IN_SWITCH(CauseF1apRadioRequestedItemNotSupportedOnTime);
        TO_STRING_IN_SWITCH(CauseF1apRadioUnknownOrAlreadyAllocatedGnbCuMbsF1apId);
        TO_STRING_IN_SWITCH(CauseF1apRadioUnknownOrAlreadyAllocatedGnbDuMbsF1apId);
        TO_STRING_IN_SWITCH(CauseF1apRadioUnknownOrInconsistentPairOfMbsF1apId);
        TO_STRING_IN_SWITCH(CauseF1apRadioUnknownOrInconsistentMrbId);
        TO_STRING_IN_SWITCH(CauseF1apRadioTatSdtExpiry);
        TO_STRING_IN_SWITCH(CauseF1apRadioEnd);

        TO_STRING_IN_SWITCH(CauseF1apTransportUnspecified);
        TO_STRING_IN_SWITCH(CauseF1apTransportResourceUnavailable);
        TO_STRING_IN_SWITCH(CauseF1apTransportUnknownTNLAddressForIAB);
        TO_STRING_IN_SWITCH(CauseF1apTransportUnknownUPTNLInformationForIAB);
        TO_STRING_IN_SWITCH(CauseF1apTransportEnd);

        TO_STRING_IN_SWITCH(CauseF1apProtocolTransferSyntaxError);
        TO_STRING_IN_SWITCH(CauseF1apProtocolAbstractSyntaxErrorReject);
        TO_STRING_IN_SWITCH(CauseF1apProtocolAbstractSyntaxErrorIgnore);
        TO_STRING_IN_SWITCH(CauseF1apProtocolMessageNotCompatible);
        TO_STRING_IN_SWITCH(CauseF1apProtocolSemanticError);
        TO_STRING_IN_SWITCH(CauseF1apProtocolAbstractSyntaxError);
        TO_STRING_IN_SWITCH(CauseF1apProtocolUnspecified);
        TO_STRING_IN_SWITCH(CauseF1apProtocolEnd);

        TO_STRING_IN_SWITCH(CauseF1apMiscControlProcessingOverload);
        TO_STRING_IN_SWITCH(CauseF1apMiscUnavailableResources);
        TO_STRING_IN_SWITCH(CauseF1apMiscHardwareFailure);
        TO_STRING_IN_SWITCH(CauseF1apMiscOMIntervention);
        TO_STRING_IN_SWITCH(CauseF1apMiscUnspecifiedFailure);
        TO_STRING_IN_SWITCH(CauseF1apMiscEnd);

        default:
            return "Unknown F1Cause";
    }
}

/**
 * @brief e1Cause to string
 */
const char *FnVCCB_GetE1CauseToStr(const uint32_t cause)
{
    switch (cause)
    {
        TO_STRING_IN_SWITCH(CAUSE_NO_FAULT);

        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerUnspecified);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpUeE1apId);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpUeE1apId);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfUeE1apId);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerInteractionWithOtherProcedure);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerPdcpCountWrapAround);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerNotSupportedQciValue);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerNotSupported5QiValue);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerEncryptionAlgorithmsNotSupported);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerIntegrityProtectionAlgorithmsNotSupported);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerUpIntegrityProtectionNotPossible);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerUpConfidentialityProtectionNotPossible);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerMultiplePduSessionIdInstances);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerUnknownPduSessionId);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerMultipleQosFlowIdInstances);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerUnknownQosFlowId);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerMultipleDrbIdInstances);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerUnknownDrbId);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerInvalidQosCombination);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerProcedureCancelled);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerNormalRelease);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerNoRadioResourcesAvailable);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerActionDesirableForRadioReasons);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerResourcesNotAvailableForTheSlice);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerPdcpConfigurationNotSupported);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerUeDlMaxIPDataRateReason);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerUpIntegrityProtectionFailure);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerReleaseDueToPreEmption);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerRSNNotAvailableForTheUP);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerNPNNotSupported);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerReportCharacteristicsEmpty);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerExistingMeasurementID);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerMeasurementTemporarilyNotAvailable);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerMeasurementNotSupportedForTheObject);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerScgActivationDeactivationFailure);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerScgDeactivationFailureDueToDataTransmission);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuCpMbsE1apId);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerUnknownOrAlreadyAllocatedGnbCuUpMbsE1apId);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerUnknownOrInconsistentPairOfMbsE1apId);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerUnknownOrInconsistentMrbId);
        TO_STRING_IN_SWITCH(CauseE1apRadioNetworkLayerEnd);

        TO_STRING_IN_SWITCH(CauseE1apTransportLayerUnspecified);
        TO_STRING_IN_SWITCH(CauseE1apTransportLayerTransportResourceUnavailable);
        TO_STRING_IN_SWITCH(CauseE1apTransportLayerUnknownTNLAddressForIAB);
        TO_STRING_IN_SWITCH(CauseE1apTransportLayerEnd);

        TO_STRING_IN_SWITCH(CauseE1apProtocolTransferSyntaxError);
        TO_STRING_IN_SWITCH(CauseE1apProtocolAbstractSyntaxErrorReject);
        TO_STRING_IN_SWITCH(CauseE1apProtocolAbstractSyntaxErrorIgnoreAndNotify);
        TO_STRING_IN_SWITCH(CauseE1apProtocolMessageNotCompatibleWithReceiverState);
        TO_STRING_IN_SWITCH(CauseE1apProtocolSemanticError);
        TO_STRING_IN_SWITCH(CauseE1apProtocolAbstractSyntaxErrorFalselyConstructedMessage);
        TO_STRING_IN_SWITCH(CauseE1apProtocolUnspecified);
        TO_STRING_IN_SWITCH(CauseE1apProtocolEnd);
        
        TO_STRING_IN_SWITCH(CauseE1apMiscControlProcessingOverload);
        TO_STRING_IN_SWITCH(CauseE1apMiscNotEnoughUserPlaneProcessingResources);
        TO_STRING_IN_SWITCH(CauseE1apMiscHardwareFailure);
        TO_STRING_IN_SWITCH(CauseE1apMiscOMIntervention);
        TO_STRING_IN_SWITCH(CauseE1apMiscUnspecified);
        TO_STRING_IN_SWITCH(CauseE1apMiscEnd);

        default:
            return "Unknown E1Cause";
    }
}
