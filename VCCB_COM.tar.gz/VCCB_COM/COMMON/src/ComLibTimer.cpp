/**
 * @file        VlibTimer.c
 * @brief       functions for timer
 */
/*----------------------------------------------------------------------------
 * Define    :    Include Header Files
 * ---------------------------------------------------------------------------
 */
#include "ComLibTimer.h"
#include "ComInclude.h"
#include "ComLibUtility.h"
#include "ComEndian.h"
#include "ComNRRRCEnumsToValues.h"

#include "FeatConditionalHo.h"

/**
 * @brief     Get timer duration based on timer type
 * @param     tmrId : timer type
 * @return    time duration
 */
int VLIB_GetTimerVal(uint16_t tmrId)
{
    AUTO_TRACE_FUNC;
    int timerIdx = tmrId - MSGBASE_TIMER;
    if ((timerIdx >= MAX_VCCB_TIMER) || (timerIdx < 0))
    {
        VCCB_PRINT_ERROR("Timer ID Invalid (id=%d).\n", tmrId);

        return 0;
    }

    return (CFG->timer.value[timerIdx]);
}

/**
 * @brief     Get timer duration based on timer type
 * @param     tmrId : timer type
 * @return    time duration
 */
uint32_t VLIB_GetTimerVal_FromYangOrCfg(uint16_t tmrId, const callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ZERO(ptCi);

    uint32_t timerValue = 0;
    yangTimer_type *pYangTimer = NULL;
    uint8_t profileIdx = 0;
    uint8_t callType = ptCi->callType;
    uint16_t gnbNum = ptCi->gnbNum;
    uint16_t servCellNum = ptCi->servCellNum;

    if (gnbNum >= MAX_GNB_PER_SYS)
    {
        VCCB_PRINT_ERROR("Invalid gnbNum(%d) - tmrId(%d)\n", gnbNum, tmrId);

        return timerValue;  // 0
    }

    pYangTimer = &GNBINFO[gnbNum].yangTimer;

    if (callType == E_CALLTYPE_SA)
    {
        switch (tmrId)
        {
            /* NRRRC */
            case timNRRRC_RRCSetup_id:
                UPDATE_RRC_SA_TIMER_VALUE(timerValue, rrcSetup, gnbNum, servCellNum, tmrId);
                break;
            case timNRRRC_RRCReestablish_id:
                UPDATE_RRC_SA_TIMER_VALUE(timerValue, rrcReestablish, gnbNum, servCellNum, tmrId);
                break;
            case timNRRRC_RRCReconfig_id:
                UPDATE_RRC_SA_TIMER_VALUE(timerValue, rrcReconfig, gnbNum, servCellNum, tmrId);
                break;
            case timNRRRC_SecurityModeCommand_id:
                UPDATE_RRC_SA_TIMER_VALUE(timerValue, rrcSecurityModeCommand, gnbNum, servCellNum, tmrId);
                break;
            case timNRRRC_UECapabilityEnquiry_id:
                UPDATE_RRC_SA_TIMER_VALUE(timerValue, rrcUeCapabilityEnquiry, gnbNum, servCellNum, tmrId);
                break;
            case timNRRRC_MRWaitForRedirection_id:
                timerValue = pYangTimer->rrcMRWaitForRedirection;
                break;
            case timNRRRC_RRCResume_id:
                UPDATE_RRC_SA_TIMER_VALUE(timerValue, rrcResume, gnbNum, servCellNum, tmrId);
                break;
            case timNRRRC_RRCResumeRequest1_id:
                timerValue =
                    IS_REDCAP_UE(ptCi) ? 
                        (uint32_t)(GNBINFO[gnbNum].RrcInactiveInfo.redCapResumeWaitTimer * 1000) : 
                        (uint32_t)(GNBINFO[gnbNum].RrcInactiveInfo.resumeWaitTimer * 1000);  // unit defined in YANG : sec;
                break;
            case timNRRRC_UEInformationResponse_id:
                timerValue = pYangTimer->rrcUeInformationResponse;
                break;

            /* internal */
            case timInternalULNasTimeToWait_id:
                UPDATE_RRC_SA_TIMER_VALUE(timerValue, rrcUlInformationTransferTimeToWait, gnbNum, servCellNum, tmrId);
                break;
            case timInternalRreTimeToWait_id:
                if (FnVCCB_IsVoNRCall(const_cast<callInfo_type *>(ptCi)) == TRUE)
                {
                    timerValue = pYangTimer->internalRreTimeToWaitForVonr;
                }
                else
                {
                    timerValue = pYangTimer->internalRreTimeToWait;
                }
                break;
            case timInternalIntraGnbHandoverComplete_id:
                timerValue = pYangTimer->intraGnbHandoverComplete;
                break;
            case timInternalNrdcScgRelWait_id:
                timerValue = 5000;              // SVR24B FGR-CC5203: constant value as 5sec. (suggested by system design team)
                break;
            case timInternalMrOrPduSetupForRfspRedirection_id:
                timerValue = pYangTimer->internalIratRedirectTimeForAccessControl;
                break;

            case timInternalLtmCellSwitchPreparation_id:
                timerValue = GNBINFO[gnbNum].cfg.gnbMobilityConfig.ltmConfig.cellSwitchPreparationTimer;
                break;
            case timInternalLtmCellSwitchComplete_id:
                timerValue = GNBINFO[gnbNum].cfg.gnbMobilityConfig.ltmConfig.cellSwitchTimer;
                break;
                
            /* f1 */
            case timF1_UeContextSetup_id:
                timerValue = pYangTimer->f1UeContextSetup;
                break;
            case timF1_UeContextRelease_id:
                timerValue = pYangTimer->f1UeContextRelease;
                break;
            case timInternalHandoverQuery_id:  // 'timInternalHandoverQuery_id' has the same Timer Value as
                                               // 'timF1_UeContextModification_id'.
            case timF1_UeContextModification_id:
                timerValue = pYangTimer->f1UeContextModification;
                break;

            case timF1_AccessSuccess_id:
                if (servCellNum < MAX_CELL_NUM_VCCB)
                {
                    timerValue = CELLINFO[servCellNum].mobilityConfig.conditionalHandoverConfig.f1AccessSuccess;
                    break;
                }
                timerValue = 0;
                break;
            case timF1_RrcDeliveryReportForDlNas_id:
                UPDATE_RRC_SA_TIMER_VALUE(timerValue, f1RrcDeliveryReportTimeToWait, gnbNum, servCellNum, tmrId);
                break;
            case timF1AccessSuccessRach_id:
                timerValue = GNBINFO[gnbNum].cfg.nrdc.randomAccessTimer;
                break;

            /* e1 */
            case timE1_BearerContextSetup_id:
                timerValue = pYangTimer->e1BearerContextSetup;
                break;
            case timE1_BearerContextModification_id:
                timerValue = pYangTimer->e1BearerContextModification;
                break;
            case timE1_BearerContextRelease_id:
                timerValue = pYangTimer->e1BearerContextRelease;
                break;

            /* ng */
            case timNG_InitialContextSetup_id:
                timerValue = pYangTimer->ngInitialContextSetup;
                break;
            case timNG_UEContextRelease_id:
                timerValue = pYangTimer->ngUeContextRelease;
                break;
            case timNG_RelocPrep_id:
                timerValue = pYangTimer->ngRelocPrep;
                break;
            case timNG_RelocOverall_id:
                timerValue = pYangTimer->ngRelocOverall;
                break;
            case timNG_HandoverComplete_id:
                timerValue = pYangTimer->ngHandoverComplete;
                break;
            case timNG_PathSwitch_id:
                timerValue = pYangTimer->ngPathSwitch;
                break;
            case timNG_PDUSessModifyConfirm_id:
                timerValue = pYangTimer->ngPduSessionModifyConfirm;
                break;
            case timNG_NRPPa_ECIDMeasOnDemand_id:
                timerValue = pYangTimer->ngNrppaOndemand;
                break;

            /* xn */
            case timXN_RelocPrep_id:
                timerValue = pYangTimer->xnRelocPrep;
                break;
            case timXN_RelocOverall_id:
                timerValue = pYangTimer->xnRelocOverall;
                break;
            case timXN_HandoverComplete_id:
                timerValue = pYangTimer->xnHandoverComplete;
                break;
            case timXN_RetrieveUEContext_id:
                timerValue = pYangTimer->xnRetrieveUeContext;
                break;
            case timXN_DcPrepare_id:
                timerValue = pYangTimer->xnDcPrep;
                break;
            case timXN_DcOverall_id:
                timerValue = pYangTimer->xnDcOverall;
                break;
            case timXN_UeContextRelease_id:
                timerValue = pYangTimer->xnUeContextRelease;
                break;
            case timXN_ReleaseConfirm_id:
                timerValue = pYangTimer->xnSnInitSnRelease;
                break;
            case timXN_ChangeConfirm_id:
                timerValue = pYangTimer->xnSnChangeConfirm;
                break;
            case timXN_ModificationConfirm_id:
                timerValue = pYangTimer->xnSnInitSnModification;
                break;
            case timXN_SNodeAddition_id:
                timerValue = pYangTimer->xnSnAddition;
                break;
            case timXN_SNodeModification_id:
                timerValue = pYangTimer->xnMnInitSnModification;
                break;
            case timXN_SNodeRelease_id:
                timerValue = pYangTimer->xnMnInitSnRelease;
                break;
            case timXN_SnStatusTransfer_id:
                timerValue = pYangTimer->xnSnStatusTransfer;
                break;

            case timXN_HandoverSuccess_id:
                if (servCellNum < MAX_CELL_NUM_VCCB)
                {
                    timerValue = CELLINFO[servCellNum].mobilityConfig.conditionalHandoverConfig.xnHandoverSuccess;
                    break;
                }
                timerValue = 0;
                break;

            default:
                timerValue = 2000;
                VCCB_PRINT_ERROR("Invalid Timer ID(%d, %s) in VLIB_GetTimerVal_FromYangOrCfg(SA, timerValue:%u)\n",
                    tmrId, strMsgId(tmrId), timerValue);
                break;
        }
    }
    else  // E_CALLTYPE_NSA
    {
        switch (tmrId)
        {
            case timX2_DcOverall_id:
                timerValue = pYangTimer->x2DcOverall;
                break;
            case timX2_UeContextRelease_id:
                timerValue = pYangTimer->x2UeContextRelease;
                break;
            case timX2_SgNBReleaseConfirm_id:
                timerValue = pYangTimer->x2SgNbReleaseConfirm;
                break;
            case timX2_SnStatusTransfer_id:
#ifndef NEW_HOST_SIM
                if (STATE_DCIntraDuHo_X2SnStatus == ptCi->state || STATE_DCInterDuHo_X2SnStatus == ptCi->state ||
                    STATE_DCNonDuHo_X2SnStatus == ptCi->state)  // inter-MN HO case
                {
                    timerValue = pYangTimer->x2SnStatusTransfer;  // default : 100ms
                }
                else
                {
                    timerValue = (uint32_t)VLIB_GetTimerVal(tmrId);  // default : 1s
                }
#else
                timerValue = 5000;
#endif
                break;
            case timE1_BearerContextSetup_id:
                timerValue = pYangTimer->endcE1BearerContextSetup;
                break;
            case timE1_BearerContextModification_id:
                timerValue = pYangTimer->endcE1BearerContextModification;
                break;
            case timE1_BearerContextRelease_id:
                timerValue = pYangTimer->endcE1BearerContextRelease;
                break;
            case timF1_UeContextSetup_id:
                timerValue = pYangTimer->endcF1UeContextSetup;
                break;
            case timF1_UeContextRelease_id:
                timerValue = pYangTimer->endcF1UeContextRelease;
                break;
            case timF1_UeContextModification_id:
                timerValue = pYangTimer->endcF1UeContextModification;
                break;
            case timAnrSgNBModificationRefuseRetry_id:  //FGS-SF0502::FR112 the same value as timNRRRC_RRCReconfig_id is used.
            case timNRRRC_RRCReconfig_id:  // old name is 'timNRRRC_RRCConnectionReconfig_id' For EN-DC SRB3 Case
                UPDATE_RRC_ENDC_TIMER_VALUE(timerValue, rrcReconfig, gnbNum, servCellNum, tmrId);
                break;
            case timInternalDddsIndication_id:
                timerValue = GNBINFO[gnbNum].cfg.randomAccessTimerValue;
                break;    
            default:
                timerValue = 2000;

                VCCB_PRINT_ERROR("Invalid Timer ID(%d, %s) in VLIB_GetTimerVal_FromYangOrCfg(NSA, timerValue:%u)\n",
                    tmrId, strMsgId(tmrId), timerValue);
                break;
        }
    }

    return timerValue;
}

/**
 * @brief     Set timer duration for Suspend Resume Timer in SCG Failure Handling Operation
 * @param     callInfo_type : call info
 * @return    time duration
 */
uint32_t VLIB_GetTimerValue_ScgSuspendResume(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    uint32_t minTimVal, tmpTimVal;
    uint8_t weightFactor;
    uint16_t qci;
    uint8_t maxWeightFactor = 0;
    uint16_t timQci = MAX_QCI_VALUE;
    int erabIdx;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, (uint32_t)-1);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, (uint32_t)-1);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    for (erabIdx = 0; erabIdx < MAX_ERAB_PER_CALL; erabIdx++)
    {
        if (ptCi->erabInfo[erabIdx].usage != CI_use)
        {
            continue;
        }

        qci = ptCi->erabInfo[erabIdx].erabQos.qciValue.QCI;
        if (qci >= MAX_QCI_VALUE)
        {
            continue;
        }
        weightFactor = pGnb->cfg.scgFailureHandlingInfo.suspendTimerPerQci[qci].weightFactor;
        if (timQci == MAX_QCI_VALUE)
        {
            timQci = qci;
        }

        if (weightFactor > maxWeightFactor)
        {
            maxWeightFactor = weightFactor;
            timQci = qci;
        }
        else if (weightFactor == maxWeightFactor)
        {
            // suspendTimer range:  0 - 3600000, or -1(infinity).
            //-1 after casting for uint32_t value is out of timer range - it will be interpreted as infinity
            tmpTimVal = (uint32_t)pGnb->cfg.scgFailureHandlingInfo.suspendTimerPerQci[qci].suspendTimer;
            minTimVal = (uint32_t)pGnb->cfg.scgFailureHandlingInfo.suspendTimerPerQci[timQci].suspendTimer;

            if (tmpTimVal < minTimVal)
            {
                timQci = qci;
            }
        }
    }

    if (MAX_QCI_VALUE == timQci)
    {
        minTimVal = (uint32_t)pGnb->cfg.scgFailureHandlingInfo.defaultTimerValue;
        VCCB_PRINT_MSG("timQci out of range (timQci = %d), minTimVal set to default value (%d)\n", timQci, minTimVal);

        return minTimVal;
    }

    // suspendTimer range:  0 - 3600000, or -1(infinity).
    //-1 after casting for uint32_t value is out of timer range - it will be interpreted as infinity
    minTimVal = (uint32_t)pGnb->cfg.scgFailureHandlingInfo.suspendTimerPerQci[timQci].suspendTimer;

    return minTimVal;
}

/**
 * @brief     Attach timer based on timer type
 * @param     pTimer : timer pointer
 * @param     contextId : context ID
 * @param     messageType : message type
 * @param     coreId: If Timer is for each Call, coreId is callthread num. Othercase, coreId is 0
 */
void VLIB_AttachTimerCore(timerInfo_type *pTimer, uint32_t contextId, uint16_t messageType, uint16_t transactionId,
    uint8_t specificValue, int timeVal, uint16_t timerPort, uint8_t ensTimerType, uint8_t coreId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pTimer);

    messageHdr_type msg;

    TimerOption_Type tmrOpt;
    memset(&tmrOpt, 0, sizeof(tmrOpt));
    tmrOpt.useCoreAffinity = ENS_CORE_USING;
    tmrOpt.coreId = coreId;

    msg.msgType = messageType;
    msg.src.unitType = (uint8_t)VCOM_getUnitType(BLOCK_VCCB);
    msg.src.unitId = CFG->vm.unitId;
    msg.src.blockType = BLOCK_VCCB;
    msg.src.contextId = contextId;
    msg.dst.unitType = (uint8_t)VCOM_getUnitType(BLOCK_VCCB);
    msg.dst.unitId = CFG->vm.unitId;
    msg.dst.blockType = BLOCK_VCCB;
    msg.dst.contextId = contextId;
    msg.reserved = specificValue;

    // ensTimer fills the last 4 byte area with TimerId. ( msg.tmr.msgContents[5] = tmr->timerId; in ENS Lib)
    // Therefore, the transactionId and reserved1 areas are unavailable.
    msg.transactionId = 0;
    msg.reserved1 = 0;

    if (pTimer->id > 0)
    {
        VCCB_PRINT_DATA("pTimer->id == %d (< 0)\n", pTimer->id);
        VCCB_CLEAR_TIMER(pTimer, CANCEL_TIMER);
    }

    ENDIAN_CONVERT(msg.msgType);

    switch (ensTimerType)
    {
        case VCCB_TIMER_PERIODIC:  // ensAddPeriodicTimer()
        {
#ifndef NEW_HOST_SIM
            pTimer->id = ensAddPeriodicTimer(
                MDS_ATTR_IP_TYPE_IIIP, timerPort, (long unsigned)timeVal, 0, (pTmrMsg_Type)&msg, sizeof(TmrMsg_Type), &tmrOpt);
#else
            pTimer->id = ensAddPeriodicTimer(
                MDS_ATTR_IP_TYPE_IIIP, timerPort, (long unsigned)timeVal, 0, (pTmrMsg_Type)&msg, sizeof(TmrMsg_Type), NULL);
#endif
            break;
        }
        case VCCB_TIMER_START_AT:  // ensAddAbsoluteTimer()
        {
            struct tm sTime;
            time_t currentTime, startTime;
            EnsDate_Type ensDate;

            currentTime = time(NULL);
            localtime_r(&currentTime, &sTime);

            ensDate.year = sTime.tm_year + 1900;  // tm_year = 0 (1900)
            ensDate.mon = sTime.tm_mon + 1;       // tm_mon = 0 (JAN)
            ensDate.day = sTime.tm_mday;
            ensDate.hour = timeVal >> 8;
            ensDate.min = timeVal & 0xFF;
            ensDate.sec = 0;

            sTime.tm_hour = ensDate.hour;
            sTime.tm_min = ensDate.min;

            startTime = timelocal(&sTime);

            // check if time already passed or not
            if (difftime(startTime, currentTime) <= 0)
            {
                ensDate.day++;
            }

            pTimer->id = ensAddAbsoluteTimer(
                MDS_ATTR_IP_TYPE_IIIP, timerPort, &ensDate, (pTmrMsg_Type)&msg, sizeof(TmrMsg_Type), &tmrOpt);
        }
        break;

        default:  // ensAddTemporaryTimer()
        {
#ifndef NEW_HOST_SIM
            pTimer->id = ensAddTemporaryTimer(
                MDS_ATTR_IP_TYPE_IIIP, timerPort, (long unsigned)timeVal, (pTmrMsg_Type)&msg, sizeof(TmrMsg_Type), &tmrOpt);
#else
            pTimer->id = ensAddTemporaryTimer(
                MDS_ATTR_IP_TYPE_IIIP, timerPort, (long unsigned)timeVal, (pTmrMsg_Type)&msg, sizeof(TmrMsg_Type), NULL);
#endif
            break;
        }
    }

    if (pTimer->id <= 0)
    {
        VCCB_PRINT_ERROR("ensAddTimer Fail\n");
        VCCB_PRINTF_ERR(
            " ensAddTimer : timerType(%d), timerId(%d), msgType(%s/0x%x), timeVal(%d), callId(%d), coreId(%d), "
            "spec(%u)\n",
            ensTimerType, pTimer->id, strMsgId(messageType), messageType, timeVal, contextId, coreId,
            FnVCCB_GetSpecificValueInExpiredTimer(&msg));
        return;
    }

    pTimer->contextId = (uint16_t)contextId;
    pTimer->type = messageType;
    pTimer->transactionId = transactionId;
    pTimer->port = timerPort;
    pTimer->val = timeVal;

    VCCB_PRINT_COMMENT("Attach Timer Success!! Id(%d), msg(%s/%d), val(%d) spec(%u)\n", pTimer->id,
        strMsgId(pTimer->type), pTimer->type, pTimer->val, FnVCCB_GetSpecificValueInExpiredTimer(&msg));
}

inline uint16_t VLIB_GetCallAddr(uint32_t cuCpUeId)
{
    uint8_t threadId = (uint8_t)VCCB_GET_CALL_THREAD_ID(cuCpUeId);
    return VCCB_CALL_ADDR[threadId].MdsPort;
}

void FnVCCB_DetachCallMultiTimer(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    MACRO_CHECK_AND_DETACH(ptCi->callMultiTimer.x2);
    MACRO_CHECK_AND_DETACH(ptCi->callMultiTimer.e1);
    MACRO_CHECK_AND_DETACH(ptCi->callMultiTimer.f1);
    MACRO_CHECK_AND_DETACH(ptCi->callMultiTimer.rrc);
    MACRO_CHECK_AND_DETACH(ptCi->callMultiTimer.ng);
    MACRO_CHECK_AND_DETACH(ptCi->callMultiTimer.xn);
    MACRO_CHECK_AND_DETACH(ptCi->callMultiTimer.spec);

    return;
}

// INTRA_NR_ANR_24A
uint32_t FnVCCB_GetTimeForAnrNormalUe(uint16_t messageType, uint8_t isAutonomousGap)
{
    AUTO_TRACE_FUNC;
    const int ANR_T321_TIMER_MARGIN_1000_MS = 1000;
    uint32_t timeVal = 0;

    switch (messageType)
    {
        case timAnrReportCgi_t321Fr1_id:
            timeVal = (2000 + ANR_T321_TIMER_MARGIN_1000_MS);
            break;
        case timAnrReportCgi_t321Fr2_id:
            if (TRUE == isAutonomousGap)
                timeVal = (5000 + ANR_T321_TIMER_MARGIN_1000_MS);  // T321 from spec. for FR2(useautonomousGaps) + 1sec (margin)
            else
                timeVal = (16000 + ANR_T321_TIMER_MARGIN_1000_MS);  // T321 from spec. for FR2 + 1sec (margin)
            break;
        case timIRatAnrReportCgi_t321_id:
            if (TRUE == isAutonomousGap)
                timeVal = (200 + ANR_T321_TIMER_MARGIN_1000_MS);  // T321 from spec. for EUTRA(useautonomousGaps) + 1sec (margin)
            else
                timeVal = (1000 + ANR_T321_TIMER_MARGIN_1000_MS);  // T321 from spec. for EUTRA + 1sec (margin)
            break;
        default:
            break;
    }

    return timeVal;
}

uint32_t FnVCCB_GetTimeForAnrRedCapUe(uint16_t messageType, uint8_t isAutonomousGap)
{
    AUTO_TRACE_FUNC;
    const int ANR_T321_TIMER_MARGIN_1000_MS = 1000;
    uint32_t timeVal = 0;

    if (FALSE == isAutonomousGap) return FnVCCB_GetTimeForAnrNormalUe(messageType, isAutonomousGap);

    switch (messageType)
    {
        case timAnrReportCgi_t321Fr1_id:
            timeVal = (3000 + ANR_T321_TIMER_MARGIN_1000_MS);
            break;
        case timAnrReportCgi_t321Fr2_id:
            timeVal = (6000 + ANR_T321_TIMER_MARGIN_1000_MS);
            break;
        case timIRatAnrReportCgi_t321_id:
            timeVal = FnVCCB_GetTimeForAnrNormalUe(messageType, isAutonomousGap);
            break;
        default:
            break;
    }

    return timeVal;
}

// For RedCap UE, one sec of guard time is added to the T321 standard timer.
uint32_t FnVCCB_AttachTimerGetTimeForAnr(callInfo_type *ptCi, uint16_t messageType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ZERO(ptCi);

    if (IS_REDCAP_UE(ptCi)) 
    {
        return FnVCCB_GetTimeForAnrRedCapUe(messageType, GET_REPORT_CGI_AUTONOMOUS_GAP_FLAG(ptCi));
    }

    return FnVCCB_GetTimeForAnrNormalUe(messageType, GET_REPORT_CGI_AUTONOMOUS_GAP_FLAG(ptCi));
}

/**
 * @brief This function returns timLbMrReceived_id timer value for NSA calls.
 * 
 * @param rCi call info
 * @param rTimerValue output timer value
 */
void VCCB_NSA_GetTimerValue_LbMrReceived(const callInfo_type &rCi, uint32_t &rTimerValue)
{
    AUTO_TRACE_FUNC;

    const auto cellNum = (VCCB_ENDC_IsHoOngoing(rCi) ? rCi.hoInfo.targetCellNum : rCi.servCellNum);
    VCCB_CHECK_VALID_CELLNUM_VOID(cellNum);
    const auto &rCell = CELLINFO[cellNum];

    rTimerValue = rCell.lbCfg.pscellChangeLbInfo.mrWaitTimer;
    if (NSA_LB_MR_WAIT_TIMER_MAX < rTimerValue)
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "%s: value out of range (%u) - use default (%u).\n", __FUNCTION__, rTimerValue, NSA_LB_MR_WAIT_TIMER_DEFAULT);
        rTimerValue = NSA_LB_MR_WAIT_TIMER_DEFAULT;
    }
}

/**
 * @brief This function returns timLbMrReceived_id timer value for SA calls.
 * 
 * @param rCi call info
 * @param rTimerValue output timer value
 */
void VCCB_SA_GetTimerValue_LbMrReceived(const callInfo_type &rCi, uint32_t &rTimerValue)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_VALID_CELLNUM_VOID(rCi.servCellNum);
    const auto &rCell = CELLINFO[rCi.servCellNum];

    rTimerValue = rCell.lbCfg.connModeLbInfo.mrWaitTimer;
    if ((LB_MIN_MR_WAIT_TIME > rTimerValue) || (LB_MAX_MR_WAIT_TIME < rTimerValue))
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "%s: value out of range (%u) - use default (%u).\n", __FUNCTION__, rTimerValue, LB_DEFAULT_MR_WAIT_TIME);
        rTimerValue = LB_DEFAULT_MR_WAIT_TIME;
    }
}

/**
 * @brief This function returns timLbMrReceived_id timer value depending on call state.
 *        In state IDLE, timer value of serving cell is returned.
 *        During NSA PSCell Change, timer value of target cell is returned.
 * 
 * @param rCall call info
 * @param rTimerValue output timer value
 * @return int GOOD / ERROR
 */
int16_t VCCB_GetTimerValue_LbMrReceived(const callInfo_type &rCall, uint32_t &rTimerValue)
{
    AUTO_TRACE_FUNC;

    if (VCCB_IsEndcSn(rCall))
    {
        VCCB_NSA_GetTimerValue_LbMrReceived(rCall, rTimerValue);
    }
    else
    {
        VCCB_SA_GetTimerValue_LbMrReceived(rCall, rTimerValue);
    }

    return GOOD;
}

int16_t FnVCCB_AttachTimerGetTime(callInfo_type *ptCi, uint16_t messageType, uint32_t *pTimeValue)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR_PARAM2(ptCi, pTimeValue);

    uint32_t timeVal = 0;
    uint8_t deltaDelay = 2;  // ms, some window required for receiving Meas Report

    const uint16_t servCellNum = ptCi->servCellNum;
    const uint16_t gnbNum = ptCi->gnbNum;

    switch (messageType)
    {
        case timInternalResourceRelease_id:
        case timInternalCaModTrigger_id:
        case timInternalMeasReconfigDelay_id:
        case timInternalInterGnbSnStatusTransfer_id:
        case timInternalRetrieveUeContextResult_id:
        case timX2_BcInformationResponse_id:
            timeVal = (uint32_t)VLIB_GetTimerVal(messageType);
            if (timeVal == 0)
            {
                VCCB_PRINT_MSG("timeVal(%d->%d)\n", timeVal, 5000);
                timeVal = 5000;  // TODO
            }
            break;
        case timInternalUeMeasForSon_id:
        {
            if (ERROR == FnVCCB_FindUeMeasForSonTimerReportInterval(*ptCi, timeVal))
            {
                VCCB_PRINT_MSG("Report Interval out of index or cannot find reports for UE Measurement for SON\n");
                return ERROR;
            }
            break;
        }
        /* NRRRC */
        case timNRRRC_RRCSetup_id:
        case timNRRRC_RRCReestablish_id:
        case timNRRRC_RRCReconfig_id:
        case timNRRRC_RRCResume_id:
        case timNRRRC_SecurityModeCommand_id:
        case timNRRRC_UECapabilityEnquiry_id:
        case timNRRRC_MRWaitForRedirection_id:
        case timNRRRC_RRCResumeRequest1_id:
        case timNRRRC_UEInformationResponse_id:
        /* internal */
        case timInternalULNasTimeToWait_id:
        case timInternalRreTimeToWait_id:
        case timInternalIntraGnbHandoverComplete_id:
        case timInternalHandoverQuery_id:
        case timInternalDddsIndication_id:
        case timF1AccessSuccessRach_id:
        case timAnrSgNBModificationRefuseRetry_id:
        case timInternalNrdcScgRelWait_id:
        case timInternalLtmCellSwitchPreparation_id:
        case timInternalLtmCellSwitchComplete_id:
        case timInternalMrOrPduSetupForRfspRedirection_id:
        /* f1 */
        case timF1_UeContextSetup_id:
        case timF1_UeContextRelease_id:
        case timF1_UeContextModification_id:
        case timF1_AccessSuccess_id:
        case timF1_RrcDeliveryReportForDlNas_id:
        /* e1 */
        case timE1_BearerContextSetup_id:
        case timE1_BearerContextModification_id:
        case timE1_BearerContextRelease_id:
        /* x2 */
        case timX2_DcOverall_id:
        case timX2_SnStatusTransfer_id:
        case timX2_UeContextRelease_id:
        case timX2_SgNBReleaseConfirm_id:
        /* ng */
        case timNG_InitialContextSetup_id:
        case timNG_UEContextRelease_id:
        case timNG_RelocPrep_id:
        case timNG_RelocOverall_id:
        case timNG_HandoverComplete_id:
        case timNG_PathSwitch_id:
        case timNG_PDUSessModifyConfirm_id:
        case timNG_NRPPa_ECIDMeasOnDemand_id:
        /* xn */
        case timXN_DcPrepare_id:
        case timXN_DcOverall_id:
        case timXN_RelocPrep_id:
        case timXN_RelocOverall_id:
        case timXN_HandoverComplete_id:
        case timXN_RetrieveUEContext_id:
        case timXN_UeContextRelease_id:
        case timXN_ReleaseConfirm_id:
        case timXN_ChangeConfirm_id:
        case timXN_ModificationConfirm_id:
        case timXN_SNodeAddition_id:
        case timXN_SNodeModification_id:
        case timXN_SNodeRelease_id:
        case timXN_SnStatusTransfer_id:
        case timXN_HandoverSuccess_id:
            timeVal = VLIB_GetTimerVal_FromYangOrCfg(messageType, ptCi);
            if (timeVal == 0)
            {
                VCCB_PRINT_MSG("timeVal(%d->%d)\n", timeVal, 5000);
                timeVal = 5000;  // TODO
            }
            break;
        case timXN_SNodeReconfigurationComplete_id:
        case timXN_SNodeReconfigurationConfirm_id:
        {
            timeVal = 3000;
            break;
        }
        break;

        case timInternalUserInactivitySig_id:
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);

            if (ptCi->callType == E_CALLTYPE_NSA)
            {
                timeVal = (uint32_t)(GNBINFO[gnbNum].UserInactivity.signalingTimer * 1000);
            }
            else  // SA CALL
            {
                if (IS_NRDC_SN(ptCi))
                {
                    timeVal = (uint32_t)(GNBINFO[gnbNum].UserInactivityNrdcSN.signalingTimer * 1000);
                }
                else
                {
                    SET_REDCAP_OR_NORM_VAL(ptCi, timeVal,
                        static_cast<uint32_t>(GNBINFO[gnbNum].UserInactivitySA.redCap.signalingTimer * 1000),
                        static_cast<uint32_t>(GNBINFO[gnbNum].UserInactivitySA.signalingTimer * 1000));
                }
            }
            if (timeVal == 0)  // Abnormal case. Shall never occur
            {
                VCCB_PRINT_MSG("timeVal(%d->%d)\n", timeVal, 1000);
                timeVal = 10000;  // default
            }
            break;

        case timXN_SNodeReleaseRequired_id:
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);

            timeVal = (uint32_t)(GNBINFO[gnbNum].UserInactivityNrdcSN.xnReleaseTimer * 1000);
            if (timeVal == 0)  // Abnormal case. Shall never occur
            {
                VCCB_PRINT_MSG("timeVal(%d->%d)\n", timeVal, 1800000);
                timeVal = 1800000;  // default (30min)
            }
            break;

        case timX2_SgNBReleaseRequired_id:  // For UserInactivity with eNB of other vendors
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);

            timeVal = (uint32_t)(GNBINFO[gnbNum].UserInactivity.x2ReleaseTimer * 1000);

            if (timeVal == 0)  // Abnormal case. Shall never occur
            {
                VCCB_PRINT_MSG("timeVal(%d->%d)\n", timeVal, 1800000);
                timeVal = 1800000;  // default (30min)
            }
            break;

        case timInternalScgSuspendResume_id:
            timeVal = VLIB_GetTimerValue_ScgSuspendResume(ptCi);
            if (timeVal > MAX_SUSPEND_TIMER_VALUE)
            {
                VCCB_PRINT_MSG("timeVal = infinity, SCGSuspendResume Timer not attached\n");

                return ERROR;
            }
            else if (0 == timeVal)
            {
                timeVal = 5000;
                VCCB_PRINT_MSG("timeVal(%d->%d)\n", 0, timeVal);
            }
            break;

        case timInternalEndcFr2Meas_id:
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            timeVal = GNBINFO[gnbNum].cfg.endcFr2MeasureableSettings.timer;
            if ((0 == timeVal) || (10000 < timeVal))
            {
                VCCB_PRINT_MSG("timeVal out of range, EndcFr2Meas Timer not attached\n");

                return ERROR;
            }
            break;

        case timInternalMgapReTrigger_id:
        {
            timeVal = 200;
            break;
        }

        case timInternalPeriodicA4Deactivation_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            timeVal = (uint32_t)GNBINFO[gnbNum].cfg.periodicA4Measurement.deactTimer;
            break;
        }

        case timInternalPeriodicA4Reactivation_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            timeVal = (uint32_t)GNBINFO[gnbNum].cfg.periodicA4Measurement.reactTimer;
            break;
        }

        case timInternalPeriodicPccChangeMrGatheringTimer_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            if (E_CALLTYPE_SA == ptCi->callType)
            {
                timeVal = (uint32_t)GNBINFO[gnbNum].multiCarrierOperation.mrGatheringTimer;
            }
            break;
        }

        case timInternalSlbPccChangeMeasReactivationTimer_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            if (E_CALLTYPE_SA == ptCi->callType)
            {
                timeVal = static_cast<uint32_t>(GNBINFO[gnbNum].multiCarrierOperation.measReactivationTimer);
            }
            break;
        }

        case timInternalSlbPccChangeMrGatheringTimer_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            if (E_CALLTYPE_SA == ptCi->callType)
            {
                timeVal = static_cast<uint32_t>(GNBINFO[gnbNum].multiCarrierOperation.mrGatheringTimer);
            }
            break;
        }

        case timSccGatheringWaiting_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            if (E_CALLTYPE_SA == ptCi->callType)
            {
                timeVal = (uint32_t)GNBINFO[gnbNum].multiCarrierOperation.sccMrGatheringTimer;
            }
            break;
        }

        case timMrsMrGatheringWaiting_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            if (E_CALLTYPE_SA == ptCi->callType) // else check
            {
                timeVal = (uint32_t)GNBINFO[gnbNum].multiCarrierOperation.mrsMrGatheringTimer;
            }
            break;
        }

        case timInternalPeriodicPccChangeMeasReactivationTimer_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            if (E_CALLTYPE_SA == ptCi->callType)
            {
                timeVal = (uint32_t)GNBINFO[gnbNum].multiCarrierOperation.measReactivationTimer;
            }
            break;
        }

        case timInternalInterRatPccChangeWaiting_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            if (E_CALLTYPE_SA == ptCi->callType)
            {
                timeVal = (uint32_t)GNBINFO[gnbNum].multiCarrierOperation.interRatPccChangeTimer;
            }
            break;
        }

        case timAnrReportCgi_t321Fr1_id:
        case timAnrReportCgi_t321Fr2_id:
        case timIRatAnrReportCgi_t321_id:
        {
            timeVal = FnVCCB_AttachTimerGetTimeForAnr(ptCi, messageType); // INTRA_NR_ANR_24A
            break;
        }

        case timLbMrReceived_id:
        {
            return VCCB_GetTimerValue_LbMrReceived(*ptCi, *pTimeValue);
        }
        case timIratLbMrReceived_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(servCellNum, MAX_CELL_NUM_VCCB);
            timeVal = CELLINFO[servCellNum].lbCfg.connModeIratLbInfo.mrWaitTimer;
            if ((timeVal < LB_MIN_MR_WAIT_TIME) || (timeVal > LB_MAX_MR_WAIT_TIME))
            {
                VCCB_PRINT_MSG("timeVal out of range(%d), iratLbMrWaitTimer with default time\n", timeVal);
                timeVal = LB_DEFAULT_MR_WAIT_TIME; // by default
            }
            break;
        }
        case timVoNrLbMrReceived_id: // FGR-LC0712
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(servCellNum, MAX_CELL_NUM_VCCB);
            timeVal = CELLINFO[servCellNum].lbCfg.voNrLbInfo.mrWaitTimer;
            if ((timeVal < LB_MIN_MR_WAIT_TIME) || (timeVal > LB_MAX_MR_WAIT_TIME))
            {
                VCCB_PRINT_MSG("timeVal out of range(%d), voNRLbMrWaitTimer with default time\n", timeVal);
                timeVal = LB_DEFAULT_MR_WAIT_TIME; // by default
            }
            break;
        }
        case timInternalForcedHoRestriction_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            if (E_CALLTYPE_SA == ptCi->callType)
            {
                timeVal = GNBINFO[gnbNum].cfg.forcedRestriction.timer;
            }
            else
            {
                timeVal = GNBINFO[gnbNum].cfg.endcForcedRestriction.timer;
            }
            break;
        }
        case timInternalWaitHighestPriorityMr_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            VCCB_CHECK_E_RANGE_AND_RETURN(servCellNum, MAX_CELL_NUM_VCCB);
            timeVal = CELLINFO[servCellNum].mobilityConfig.waitTimerForFreqPrior;
            break;
        }
        case timInternalHoTriggering_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            VCCB_CHECK_E_RANGE_AND_RETURN(servCellNum, MAX_CELL_NUM_VCCB);
            timeVal = (uint32_t)(CELLINFO[servCellNum].mobilityConfig.mobilityTriggerTimer *
                       CELLINFO[servCellNum].mobilityConfig.waitTimerForFreqPrior);
            break;
        }
        case timInternalIratMeasForSaPriHo_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            timeVal = GNBINFO[gnbNum].yangTimer.iratMeasTimerForSaPriorization;
            break;
        }
        case timInternalAlternateGap_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            timeVal = (uint32_t)GNBINFO[gnbNum].cfg.measGap.alternateMeasGapConfig.timer;
            break;
        }

        case timNRRRC_RNAUpdate_id:
        {
            if (GET_RRC_STATE(ptCi) == RRC_INACTIVE)
            {
                uint16_t t380[8] = {300, 600, 1200, 1800, 3600, 7200, 21600, 43200};  // unit : sec
                // PeriodicRNAU-TimerValue ::=
                //         ENUMERATED { min5, min10, min20, min30, min60, min120, min360, min720}
                timeVal = (uint32_t)(t380[MIN(ptCi->ueInfo.RrcInactiveInfo.t380, 7)] * 2 * 1000);  // unit : msec
            }
            else
            {
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "Not in RRC Inactive State(%d)(0:idle/1:inact/2:conn)\n", GET_RRC_STATE(ptCi));
                return ERROR;
            }
            break;
        }
        case timNG_NRPPa_ECIDMeasPeriodicty_id:
        {
            uint32_t tNrppaMeasPeriodicity[13] = {
                120, 240, 480, 640, 1024, 2048, 5120, 10240, 60000, 360000, 720000, 1800000, 3600000};  // unit : msec
            /* ECID Measurement Periodicity Timer Value ::= */
            /* ENUMERATED { 120ms, 240ms, 480ms, 640ms, 1024ms, 2048ms, 5120ms, 10240ms, 1min, 6min, 12min, 30min,
             * 60min} */
            timeVal = (tNrppaMeasPeriodicity[MIN(ptCi->NrPpaContext.measurementPeriodicity, 12)] +
                       deltaDelay); /* unit : msec */
            break;
        }

        case timNG_NRPPa_ECIDMeasPeriodictyAoA_id:
        {
            uint32_t tNrppaMeasPeriodicityAoA[14] = {
                160, 320, 640, 1280, 2560, 5120, 10240, 20480, 40960, 61440, 81920, 368640, 737280, 1843200};  // unit : msec
            /* ECID Measurement AoA Periodicity Timer Value ::= */
            timeVal = (tNrppaMeasPeriodicityAoA[MIN(ptCi->NrPpaContext.measurementPeriodicityAoA, 13)] +
                       deltaDelay); /* unit : msec */
            break;
        }

        case timNRRRC_UlDedicatedMessageSegment_id:
        {
            timeVal = 2000;  // default
            break;
        }
        case timInternalMdtDataRetrieval_id:
        {
            timeVal = (uint32_t)(CFG->globalTraceInfo.loggedRetrieveTimer * 1000);
            break;
        }
        case timInternalTraceDeactivation_id:
        {
            uint8_t modVal = CFG->globalTraceInfo.deactTimer;
            modVal = modVal>0 ? modVal : 1;
            timeVal = (uint32_t)((ptCi->callId % modVal) * 1000) + 1;
            break;
        }
        case timInternalTraceBuffFlush_id:
        {
            timeVal = CFG->globalTraceInfo.msgAggregatedTime;
            break;
        }
        case timInternalNewBandMrWait_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(servCellNum, MAX_CELL_NUM_VCCB);
            timeVal = CELLINFO[servCellNum].scgBandSelectionConfig.mr_collection_timer;
            if (timeVal > 6000)
            {
                VCCB_PRINT_MSG("mr_collection_timer is invalid(%u), so default value will be applied!!\n", timeVal);
                timeVal = 500;
            }
            break;
        }
        // SVR22B FGR-CC5203: SCG Suspend Timer
        case timInternalNrdcScgSuspend_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            timeVal = (uint32_t)GNBINFO[gnbNum].cfg.scgFailureHandlingInfoNrDc.suspendTimer;
            break;
        }
        case timInternalLongCallDetect_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            if (TRUE == VCOM_IsHostSim())
            {
                timeVal = (uint32_t)(GNBINFO[gnbNum].yangTimer.cpLongCallDetectTime * 1000); // timer interval in seconds for tests
            }
            else
            {
                timeVal = (uint32_t)(GNBINFO[gnbNum].yangTimer.cpLongCallDetectTime * 1000 * 60); // timer interval in minutes
            }
            if (timeVal == 0)
            {
                return ERROR;
            }
            break;
        }
        // SVR23A FGR-MC1024: Traffic Based Mobility FR40
        case timInternalTrfBasedHoMeas_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            timeVal = GNBINFO[gnbNum].yangTimer.measRelTime;
            break;
        }
        case timInternalIratMeasForMrs_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            timeVal = GNBINFO[gnbNum].yangTimer.measRelTime;
            break;
        }
        case timSccMeasReact_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            if (ptCi->callType == E_CALLTYPE_SA)
            {
                timeVal = (uint32_t)(GNBINFO[gnbNum].multiCarrierOperation.sccMeasReactivationTimer + GNBINFO[gnbNum].multiCarrierOperation.sccMrGatheringTimer);
            }
            break;
        }

        case timInternalLongPeriodicDeactivation_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            timeVal = static_cast<uint32_t>(GNBINFO[gnbNum].cfg.longPeriodicMeas.deactTimer) * 1000;
            break;
        }

        case timInternalLongPeriodicReactivation_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            timeVal = static_cast<uint32_t>(GNBINFO[gnbNum].cfg.longPeriodicMeas.reactTimer) * 1000;
            break;
        }

#ifdef __CNF__
        case timInternalRedisExpireUpdate_id:
        {
            timeVal = 60000;
            break;
        }
#endif
        case timInternalSliceAwareLbWaitTimer_id: //SVR23B FGR-LC0710
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            timeVal = (uint32_t)GNBINFO[gnbNum].sliceAwareLbInfo.waitTimerValue;
            break;
        }
        case timInternalForcedHoMobility_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            timeVal = GNBINFO[gnbNum].cfg.gnbMobilityConfig.callReleaseTimerByUplinkStatusIndication;
            break;
        }
        // SVR24B FGR-MC1007 FR380
        case timInternalSaToNsaBorderMobilityBlindRedirection_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            timeVal = GNBINFO[gnbNum].cfg.gnbMobilityConfig.saToNsaBorderMobility.blindRedirectionTimer;
            break;
        }
        // SVR24B FGR-MC1007 FR391
        case timInternalTimerBasedMrBasedRedirection_id:
        {
            if (ERROR == FnVCCB_GetTimerValueOfMrBasedRedirection(*ptCi, timeVal))
            {
                VCCB_PRINT_MSG("mrBasedRedirectionTimer value cannot find\n");
                return ERROR;
            }
            break;
        }

        case timInternalCaPeriodicMeas_id:
        {
            if (ERROR == FnVCCB_FindCaPeriodicalTimerValue(*ptCi, timeVal))
            {
                VCCB_PRINT_MSG("Cannot find report config for Ca periodical or incorrect value of interval or amount\n");
                return ERROR;
            }
            break;
        }

        case timInternalE1InactNotiDuringSNRelease_id:  // SVR25B FGR-CC0103
        {
            timeVal = 1500;
            break;
        }

        case timInternalSpecificSliceForcedMobility_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            timeVal = GNBINFO[gnbNum].cfg.gnbMobilityConfig.sliceAware.specificSliceConfig.mrWaitTimer;
            if (timeVal == 0)
            {
                VCCB_PRINT_MSG("mrBasedRedirectionTimer value cannot find\n");
                timeVal = SPECIFIC_SLICE_DEFAULT_MR_WAIT_TIME;
            }
            break;
        }

        case timInternalSpecificSliceForcedMobilityNrPrior_id:
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
            timeVal = GNBINFO[gnbNum].cfg.gnbMobilityConfig.sliceAware.specificSliceConfig.nrPriorityTimer;
            if (timeVal == 0)
            {
                VCCB_PRINT_MSG("nr-priority-timer value cannot find\n");
                timeVal = SPECIFIC_SLICE_DEFAULT_MR_WAIT_TIME;
            }
            break;
        }

        default:
            timeVal = (uint32_t)VLIB_GetTimerVal(messageType);
            break;
            // SRKIM....TBD : ensDelTimer Fail (-606)
            // timNqdsInitReq_id 0xD95a (55642)
            // timX2SetupAudit_id 0xD97C(55676)
            // break;
    }

    *pTimeValue = timeVal;
    return GOOD;
}

VCCB_STATIC_INLINE
int16_t FnVCCB_GetTransactionId(const uint32_t msgId, const int16_t transactionId)
{
    switch (msgId)
    {
        case timNRRRC_RNAUpdate_id:
        case timNG_NRPPa_ECIDMeasPeriodicty_id:
            return transactionId;

        default:
            return VLIB_IncTimTransactionId(transactionId);
    }
}

/**
 * @brief     Attach timer with Specific Value
 * @param     pTimer : timer pointer
 * @param     callInfo_type : call info
 * @param     msgId : timer id
 * @param     specificValue : Value to include when timer expires
 */
void FnVCCB_AttachTimerWithSpecificValue(
    timerInfo_type *pTimer, callInfo_type *ptCi, uint16_t msgId, uint8_t specificValue)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(pTimer, ptCi);

    int16_t status = GOOD;
    uint32_t timeVal = 0;
    int16_t transactionId = FnVCCB_GetTransactionId(msgId, (int16_t)ptCi->transactionId);
    uint16_t port = VLIB_GetCallAddr(ptCi->gnbCuUeId);

    status = FnVCCB_AttachTimerGetTime(ptCi, msgId, &timeVal);
    VCCB_RETURN_ON_CALL_VOID(ptCi, status, "FnVCCB_AttachTimerGetTime(%s/%d) Error!\n", strMsgId(msgId), msgId);

    VLIB_AttachTimerCore(pTimer, ptCi->gnbCuUeId, msgId, (uint16_t)transactionId, specificValue, (int)timeVal, port,
        VCCB_TIMER_TEMPORARY, (uint8_t)(ptCi->myThreadId + 1));
}

/**
 * @brief     Acquire Specific Value from expired timer.
 * @param     pTimer : timer pointer
 */
uint16_t FnVCCB_GetSpecificValueInExpiredTimer(messageHdr_type *pTimer)
{
    VALID_E_POINT_CHECK_RET_VAL(pTimer, UINT16_MAX);
    return pTimer->reserved;
}

/**
 * @brief     Attach timer
 * @param     pTimer : timer pointer
 * @param     callInfo_type : call info
 * @param     messageType : message type
 */
void VLIB_AttachTimer(timerInfo_type *pTimer, callInfo_type *ptCi, uint16_t msgId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(pTimer, ptCi);

    int16_t status = GOOD;
    uint32_t timeVal = 0;
    int16_t transactionId = FnVCCB_GetTransactionId(msgId, (int16_t)ptCi->transactionId);
    uint16_t port = VLIB_GetCallAddr(ptCi->gnbCuUeId);

    status = FnVCCB_AttachTimerGetTime(ptCi, msgId, &timeVal);
    VCCB_RETURN_ON_CALL_VOID(ptCi, status, "FnVCCB_AttachTimerGetTime(%s/%d) Error!\n", strMsgId(msgId), msgId);

    VLIB_AttachTimerCore( pTimer, ptCi->gnbCuUeId, msgId, (uint16_t)transactionId, 0, (int)timeVal, port, 
        VCCB_TIMER_TEMPORARY, (uint8_t)(ptCi->myThreadId + 1));
}

/**
 * @brief     Detach timer
 * @param     pTimer : timer pointer
 * Do not call the function directly, use the macro below!!
 * #define VCCB_CLEAR_TIMER(_pTimer, _type)
 */

void VLIB_DetachTimer(timerInfo_type *pTimer)
{
    AUTO_TRACE_FUNC;
    int ret;

    VALID_E_POINT_CHECK_VOID(pTimer);

    if (pTimer->id <= 0)
    {
#ifdef IPC_TEST
        VCCB_PRINT_COMMENT("Check the timer Id!!!(%d)\n", pTimer->id);
#endif
        // Nothing
        if (pTimer->id != -1)
        {
            pTimer->id = -1;
        }

        return;
    }

    ret = ensDelTimer(pTimer->id, NULL);
    if (ret < 0)
    {
        VCCB_PRINT_COMMENT("ensDelTimer Fail (%d) : id(%d)\n", ret, pTimer->id);
    }

    VCCB_PRINT_COMMENT("Detach Timer Success!! timerId(%d), msgType(%s/%d), timerValue(%d)\n", pTimer->id,
        strMsgId(pTimer->type), pTimer->type, pTimer->val);

    pTimer->id = -1;
}

void VLIB_DetachTimerNonCore(timerInfo_type *pTimer)
{
    AUTO_TRACE_FUNC;
    int ret;

    VALID_E_POINT_CHECK_VOID(pTimer);

    if (pTimer->id <= 0)
    {
#ifdef IPC_TEST
        VCCB_PRINT_COMMENT("Check the timer Id!!!(%d)\n", pTimer->id);
#endif
        // Nothing
        if (pTimer->id != -1)
        {
            pTimer->id = -1;
        }

        return;
    }

    ret = ensDelTimer(pTimer->id, NULL);
    if (ret < 0)
    {
        VCCB_PRINT_COMMENT("ensDelTimer Fail (%d) : id(%d)\n", ret, pTimer->id);
    }

    if (DBG->log.logStoreStatThrdInternalMsg == VCCB_FLAG_ON)
    {
        VCCB_PRINT_COMMENT("Detach Timer Success!! timerId(%d), msgType(%s/%d), timerValue(%d)\n", pTimer->id,
            strMsgId(pTimer->type), pTimer->type, pTimer->val);
    }

    pTimer->id = -1;
}

/**
 * @brief   During switchover there is a need to attach timers on now-active which were attached on now-standby.
 *          If the timer id is greater than 0 it is assumed that the timer was attached on now-standby.
 *          The timer type is reused.
 * @param   ptCi    : call info
 * @param   pTimer  : timer pointer
 */
void VLIB_AttachTimerAfterSwitchover(callInfo_type *ptCi, timerInfo_type *pTimer)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pTimer);

    if (0 < pTimer->id)
    {
        VCCB_CLEAR_TIMER(pTimer, INIT_TIMER);
        VLIB_AttachTimer(pTimer, ptCi, pTimer->type);
    }
}

/**
 * @brief   This function is used to clear timers associated with a call. It is used in 2 contexts
 *          a) switchover, CPC/VCCB goes from active to standby
 *              In this scenario all active (started) timers should be cancelled (deleted in ENS).
 *          b) switchover, CPC/VCCB goes from standby to active
 *              In this scenario all active (started) timers should be:
 *              > initialized as they don't have resources in ENS.
 *              > ignored (includeDBStateHandleTimer) as they will be handled outside of this function.
 * @param   ptCi    : call info
 * @param   option  : INIT (simply assign -1 to id) or CANCEL (delete timer in ENS)
 * @param   includeDBStateHandleTimer  : if db state timers needs to be cleared set this variable to ON, 
 *                                       otherwise set it to OFF
 */
void FnVCCB_clearAllCallTimer(callInfo_type *ptCi, enumTimerType option, uint8_t includeDBStateHandleTimer)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    /* INFO FOR DEVELOPERS
    place your timer in this if-section if you want to handle your timer differently in RscCall::recoveryDB, 
    for example you want to restart it with VLIB_AttachTimerAfterSwitchover function. */
    if (includeDBStateHandleTimer == VCCB_FLAG_ON)
    {
        VCCB_CLEAR_TIMER(&ptCi->timer, option);
        VCCB_CLEAR_TIMER(&ptCi->forcedReleaseTimer, option);

        VCCB_CLEAR_TIMER(&ptCi->CallUserInactivity.sigInactivityTimer, option);
        VCCB_CLEAR_TIMER(&ptCi->CallUserInactivity.releaseTimer, option);

        VCCB_CLEAR_TIMER(&ptCi->saPriorHOTimer, option);
        VCCB_CLEAR_TIMER(&ptCi->saHoMrQueueInfo.t4, option);
        VCCB_CLEAR_TIMER(&ptCi->saHoMrQueueInfo.t5, option);

        VCCB_CLEAR_TIMER(&ptCi->endcFr2MeasTimer, option);
        VCCB_CLEAR_TIMER(&ptCi->forcedHO.timer, option);
        VCCB_CLEAR_TIMER(&ptCi->longCallDetectionTimer, option);
        VCCB_CLEAR_TIMER(&ptCi->rlfHandlingTimer, option);

        if (ptCi->callType == E_CALLTYPE_SA)
        {
            VCCB_CLEAR_TIMER(&ptCi->ueInfo.RrcInactiveInfo.guardTimer, option);
            VCCB_CLEAR_TIMER(&ptCi->pccData.interRatWaitingTmr, option);
            VCCB_CLEAR_TIMER(&ptCi->nrppaTimer, option);
            VCCB_CLEAR_TIMER(&ptCi->nrppaTimerAoA, option);
        }

        VCCB_CLEAR_TIMER(&ptCi->measurementsConfigShared.pa4m.timer, option);
        VCCB_CLEAR_TIMER(&ptCi->measurementsConfigShared.lpm.timer, option);
        VCCB_CLEAR_TIMER(&ptCi->measurementsConfigShared.altgap.timer, option);
        VCCB_CLEAR_TIMER(&ptCi->pccData.pccTmr, option);
        VCCB_CLEAR_TIMER(&ptCi->pccData.slbTmr, option);
        VCCB_CLEAR_TIMER(&ptCi->ueMeasForSon.measTimer, option);
        VCCB_CLEAR_TIMER(&ptCi->ueMeasForSon.measDelayTimer, option);
        VCCB_CLEAR_TIMER(&ptCi->saToNsaBorderHoInfo.timer, option); 
        VCCB_CLEAR_TIMER(&ptCi->caModTriggerTimer, option);
        VCCB_CLEAR_TIMER(&ptCi->caInfo.caPeriodicMeasTimer, option);
        VCCB_CLEAR_TIMER(&ptCi->ustmInfo.timer, option);
        VCCB_CLEAR_TIMER(&ptCi->specificSliceForcedHoInfo.timer, option); 
    }

    VCCB_CLEAR_TIMER(&ptCi->mgapReTriggerTimer, option);
    VCCB_CLEAR_TIMER(&ptCi->scgSuspendResumeTimer, option);
    VCCB_CLEAR_TIMER(&ptCi->lbMrTimer, option);
    VCCB_CLEAR_TIMER(&ptCi->iratLbMrWaitTimer, option);

    VCCB_CLEAR_TIMER(&ptCi->anrInfo.reportCgiTimer, option);
    VCCB_CLEAR_TIMER(&ptCi->anrInfo.refuseRetryTimer, option);

    VCCB_CLEAR_TIMER(&ptCi->finalizeInterMnHo.timer, option);

    VCCB_CLEAR_TIMER(&ptCi->mroInfo.waitUeInfoResp, option);
    VCCB_CLEAR_TIMER(&ptCi->voNrLbMrWaitTimer, option);  // FGR-LC0712

    if (ptCi->callType == E_CALLTYPE_SA)
    {
        VCCB_CLEAR_TIMER(&ptCi->secuModeCmpTimer, option);
        VCCB_CLEAR_TIMER(&ptCi->dlNasWaitingAckTimer, option);
        VCCB_CLEAR_TIMER(&ptCi->ulDedicatedMsgSegTimer, option);
        VCCB_CLEAR_TIMER(&ptCi->ueCapaEnquiry.ueCapaInfoTimer, option);
        VCCB_CLEAR_TIMER(&ptCi->redirectionInfo.mrWaitTimer, option);

        for (uint8_t condCellIdx = 0; condCellIdx < MAX_NUM_COND_CELLS; condCellIdx++)
        {
            conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForIndex(ptCi, condCellIdx);

            if (ptCondCell == NULL) continue;

            FnVCCB_CancelConditionalCellTimer(ptCondCell, option);
        }
    }

    VCCB_CLEAR_TIMER(&ptCi->mrsInfo.mrsMrGatheringTimer, option);
    VCCB_CLEAR_TIMER(&ptCi->mrsInfo.responseWaitTimer, option);
    VCCB_CLEAR_TIMER(&ptCi->mrsInfo.interRatMrWaitTimer, option);
    VCCB_CLEAR_TIMER(&ptCi->sccData.sccGatheringTimer, option);
    VCCB_CLEAR_TIMER(&ptCi->sccData.sccMeasReactTimer, option);
    VCCB_CLEAR_TIMER(&ptCi->f1AccessSuccessRachTimer, option);

    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        VCCB_CLEAR_TIMER(&ptCi->dddsIndicationTimer, option);
    }

    VCCB_CLEAR_TIMER(&ptCi->sliceAwareLbInfo.waitTimer, option);  // SVR23B FGR-LC0710

    VCCB_CLEAR_TIMER(&ptCi->timerBasedMrBasedRedirectInfo.timer, option);

    for (int hoGnbIdx = 0; hoGnbIdx < MAX_GNB_PER_CALL; hoGnbIdx++)
    {
        if (!IS_VALID_NODE(GNB_NODE, ptCi, &(ptCi->gnbInfo[hoGnbIdx]))) continue;
        VCCB_CLEAR_TIMER(&ptCi->gnbInfo[hoGnbIdx].timer, option);

        if (ptCi->callType == E_CALLTYPE_NSA)
        {
            for (int erabIdx = 0; erabIdx < MAX_ERAB_PER_CALL; erabIdx++)
            {
                if (IS_VALID_NODE(PATH_NODE, &(ptCi->gnbInfo[hoGnbIdx]), &(ptCi->gnbInfo[hoGnbIdx].dlPath[erabIdx])))
                {
                    VCCB_CLEAR_TIMER(&ptCi->gnbInfo[hoGnbIdx].dlPath[erabIdx].timer, option);
                }
                if (IS_VALID_NODE(PATH_NODE, &(ptCi->gnbInfo[hoGnbIdx]), &(ptCi->gnbInfo[hoGnbIdx].ulPath[erabIdx])))
                {
                    VCCB_CLEAR_TIMER(&ptCi->gnbInfo[hoGnbIdx].ulPath[erabIdx].timer, option);
                }
            }
        }
    }

    for (uint16_t ltmCellIdx =0; ltmCellIdx < MAX_NUM_LTM_CELLS; ltmCellIdx++)
    {
        VCCB_CLEAR_TIMER(&ptCi->ltmUeInfo.cellList[ltmCellIdx].handle.ltmCellReleaseTimer, option);
    }

    // FGR-LC0703 - reset in Statnd-By
    ptCi->periodicLbGuardTimeStamp = tickGetMono();

#ifdef __CNF__
    VCCB_CLEAR_TIMER(&ptCi->redisExpireUpdateTimer, option);
#endif
}

/**
 * @brief     Search in call info is it report type and report purpose for UE Meas for SON. It is necessary to decide which
 *            report interval choose. If this report are installed, set timer to value from report interval and increase it for 1 second.
 *            Modification of timer based on FR10 from UE Measurement for SON feature for 24A.
 * @param     ptCi : call info
 * @param     pTimeValue : timer reference
 * @return    Error code: ERROR if reportInterval is not defined in enum, if cannot find report type or report purpose,
 *            GOOD if timer is set.
 */
int16_t FnVCCB_FindUeMeasForSonTimerReportInterval(const callInfo_type &rCi, uint32_t &rTimeValue)
{
    AUTO_TRACE_FUNC;
    const measurementsConfiguration_type &measConf = rCi.measurementsConfiguration;

    for (const reportConfigurationInstalledUe_type &reportConfig : measConf.reportConfigurations.installedItems)
    {
        if (CI_use != reportConfig.usage)
        {
            continue;
        }
        if ((measReport_periodical == reportConfig.conf.reportType && periodicalPurpose_ueMeasForSon == reportConfig.conf.reportPurpose) ||
            (measReport_periodicalInterRat == reportConfig.conf.reportType && periodicalInterRATPurpose_ueMeasForSon == reportConfig.conf.reportPurpose))
        {        
            /* 25A UMfS FR10. Measurement allowed time value: configured reportInterval value * 3 + 1 (s) */
            rTimeValue = 3 * reportIntervalToValue(static_cast<enumReportInterval>(reportConfig.conf.reportInterval)); /* unit : msec */
            if (0U == rTimeValue)
            {
                return ERROR;
            }
            rTimeValue += 1000U; /* reportInterval + 1 (s) */
            return GOOD;
        }
    }
    return ERROR;
}

/**
 * @brief     FGR-MC1007 NR Connected Mobility Control FR391
 *            Get timer value for MR Based redirect operation
 * @param     rCall : call info
 * @param     rTimeValue : timer value reference
 * @return    Error code: ERROR if reportInterval is not defined in enum, if cannot find report type or report purpose,
 *            GOOD if timer is set.
 */
int16_t FnVCCB_GetTimerValueOfMrBasedRedirection(callInfo_type &rCall, uint32_t &rTimeValue)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_VALID_GNBNUM_ERROR(rCall.gnbNum);

    uint16_t gnbNum = rCall.gnbNum;
    uint8_t svcGrpId = 0xFF;
    uint8_t isReleaseProcedure = FALSE;

    if ((GOOD != FnVCCB_GetServiceGroupId(&rCall, &svcGrpId, isReleaseProcedure)) || (svcGrpId >= MAX_SVC_GRP_DB_NUM))
    {
        svcGrpId = 0;
    }

    if (GNBINFO[gnbNum].cfg.svcGrpBasedCfg[svcGrpId].usage == CI_use)
    {
        rTimeValue = GNBINFO[gnbNum].cfg.svcGrpBasedCfg[svcGrpId].mrBasedRedirectionTimer;
    }

    if (rTimeValue < 100)
    {
        VCCB_PRINT_MSG("mrBasedRedirectionTimer is invalid(gnbNum:%u/svcGrpId:%u/val:%u), "
            "so default value(3sec) will be applied\n", gnbNum, svcGrpId, rTimeValue);
        rTimeValue = 3000; // default value
    }

    return GOOD;   
}

/**
 * @brief     Set timer to reportInterval for Ca periodical multiplied by its reportAmount - 1 and next
 *            increased by 1 second. Modification of timer based on 25A FGR-RC0100 FR480.
 * @param     ptCi : call info
 * @param     pTimeValue : timer reference
 * @return    GOOD (timer is set)/ERROR (cannot find report config or incorrect interval/amount)
 */
int16_t FnVCCB_FindCaPeriodicalTimerValue(const callInfo_type &rCi, uint32_t &rTimeValue)
{
    AUTO_TRACE_FUNC;
    const measurementsConfiguration_type &measConf = rCi.measurementsConfiguration;

    for (const reportConfigurationInstalledUe_type &reportConfig : measConf.reportConfigurations.installedItems)
    {
        if (CI_use != reportConfig.usage)
        {
            continue;
        }
        if ((measReport_periodical == reportConfig.conf.reportType) &&
            (periodicalPurpose_scellRelease == reportConfig.conf.reportPurpose))
        {
            const uint8_t reportAmount =
                    VCCM_enumReportAmount2value(static_cast<enumReportAmount>(reportConfig.conf.reportAmount));
            const uint32_t reportInterval =
                    reportIntervalToValue(static_cast<enumReportInterval>(reportConfig.conf.reportInterval));
            if ((0xFF == reportAmount) || (0U == reportInterval))
            {
                return ERROR;
            }

            rTimeValue = reportInterval * static_cast<uint8_t>(reportAmount - 1) + 1000U; /* unit : msec */
            return GOOD;
        }
    }
    return ERROR;
}

/**
 * @brief     Attach timer based on timer type for Non-UE
 * @param     pTimer : timer pointer
 * @param     messageType : message type
 * @note      Newly added for timInternalStatisticsItem*_id
 */
void VLIB_AttachTimerNonCore(timerInfo_type *pTimer, uint16_t messageType, int timeVal, uint16_t timerPort, uint8_t ensTimerType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pTimer);

    messageHdr_type msg;

    msg.msgType = messageType;
    msg.src.unitType = (uint8_t)VCOM_getUnitType(BLOCK_VCCB);
    msg.src.unitId = CFG->vm.unitId;
    msg.src.blockType = BLOCK_VCCB;
    msg.src.contextId = 0xFFFFFFFF;
    msg.dst.unitType = (uint8_t)VCOM_getUnitType(BLOCK_VCCB);
    msg.dst.unitId = CFG->vm.unitId;
    msg.dst.blockType = BLOCK_VCCB;
    msg.dst.contextId = 0xFFFFFFFF;
    msg.reserved = 0;
    msg.transactionId = 0;
    msg.reserved1 = 0;

    if (pTimer->id > 0)
    {
        if (DBG->log.logStoreStatThrdInternalMsg == VCCB_FLAG_ON)
        {
            VCCB_PRINT_DATA("pTimer->id == %d (< 0)\n", pTimer->id);
        }
        VCCB_CLEAR_TIMER(pTimer, CANCEL_TIMER);
    }

    ENDIAN_CONVERT(msg.msgType);

    if (ensTimerType == VCCB_TIMER_PERIODIC)
    {
        pTimer->id = ensAddPeriodicTimer(
            MDS_ATTR_IP_TYPE_IIIP, timerPort, (long unsigned)timeVal, 0, (pTmrMsg_Type)&msg, sizeof(TmrMsg_Type), NULL);

        if (pTimer->id <= 0)
        {
            VCCB_PRINT_ERROR("ensAddPeriodicTimer Fail\n");
            VCCB_PRINTF_ERR(
                " ensAddPeriodicTimer : timerId(%d), msgType(0x%x), timeVal(%d)\n", pTimer->id, messageType, timeVal);
            return;
        }            
    }
    else
    {
        pTimer->id = ensAddTemporaryTimer(
            MDS_ATTR_IP_TYPE_IIIP, timerPort, (long unsigned)timeVal, (pTmrMsg_Type)&msg, sizeof(TmrMsg_Type), NULL);

        if (pTimer->id <= 0)
        {
            VCCB_PRINT_ERROR("ensAddTemporaryTimer Fail\n");
            VCCB_PRINTF_ERR(
                " ensAddTemporaryTimer : timerId(%d), msgType(0x%x), timeVal(%d)\n", pTimer->id, messageType, timeVal);
            return;
        }
    }

    pTimer->contextId = 0;
    pTimer->type = messageType;
    pTimer->transactionId = 0;
    pTimer->port = timerPort;
    pTimer->val = timeVal;

    if (DBG->log.logStoreStatThrdInternalMsg == VCCB_FLAG_ON)
    {
        VCCB_PRINT_COMMENT("Attach Timer Success!! Id(%d), msg(%s/%d), val(%d)\n", pTimer->id,
            strMsgId(pTimer->type), pTimer->type, pTimer->val);
    }
}

/* EOF */
