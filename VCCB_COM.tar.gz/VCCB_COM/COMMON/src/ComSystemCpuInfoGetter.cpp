/**
 * @file         : ComSystemCpuInfoGetter.cpp
 * @brief       : source of system cpu info
 *
 * @author    : hohyun.kang@samsung.com
 * @date      : 2018/12/06
 *
 * Copyright 2018 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#include "ComSystemCpuInfoGetter.hpp"
#include "ComAutoNtrace.hpp"
#include "ComGlobalData.h"
#include "ComLibIpcApi.h"

#ifndef __CNF__
#include "HardwareInterface.h"
#include "CpuloadInterface.h"
#endif

extern "C" {
#ifndef __CNF__
int hal_get_maxcpunum(void);
#ifdef __NVGNB__
int hal_get_linux_core_num(void);
#endif
char cpuGetLoad(int cpuid, int duration);
char hal_get_cpuload_one_demand(int cpuid, unsigned int demand);
int hal_get_cpuload_all(int cpuid, HAL_CPULOAD_t *hal_per_load);
#endif
}

ComSystemCpuInfoGetter::ComSystemCpuInfoGetter(void) : m_maxCpuNum(-1) { m_initializeCpuIdMap(); }

ComSystemCpuInfoGetter::~ComSystemCpuInfoGetter(void) {}

void ComSystemCpuInfoGetter::m_initializeCpuIdMap(void)
{
    AUTO_TRACE_FUNC;

    m_cpuIdMap[-1] = cpuId::CPU_ALL_AVERAGE;
    m_cpuIdMap[0] = cpuId::CPU_0;
    m_cpuIdMap[1] = cpuId::CPU_1;
    m_cpuIdMap[2] = cpuId::CPU_2;
    m_cpuIdMap[3] = cpuId::CPU_3;
    m_cpuIdMap[4] = cpuId::CPU_4;
    m_cpuIdMap[5] = cpuId::CPU_5;
    m_cpuIdMap[6] = cpuId::CPU_6;
    m_cpuIdMap[7] = cpuId::CPU_7;
    m_cpuIdMap[8] = cpuId::CPU_8;
    m_cpuIdMap[9] = cpuId::CPU_9;
    m_cpuIdMap[10] = cpuId::CPU_10;
    m_cpuIdMap[11] = cpuId::CPU_11;
    m_cpuIdMap[12] = cpuId::CPU_12;
    m_cpuIdMap[13] = cpuId::CPU_13;
    m_cpuIdMap[14] = cpuId::CPU_14;
    m_cpuIdMap[15] = cpuId::CPU_15;
    m_cpuIdMap[16] = cpuId::CPU_16;
    m_cpuIdMap[17] = cpuId::CPU_17;
    m_cpuIdMap[18] = cpuId::CPU_18;
    m_cpuIdMap[19] = cpuId::CPU_19;
    m_cpuIdMap[20] = cpuId::CPU_20;
}

bool ComSystemCpuInfoGetter::m_isCpuIdExisted(const int id)
{
    AUTO_TRACE_FUNC;

    return (m_cpuIdMap.find(id) != m_cpuIdMap.end() ? true : false);
}

#ifdef __CNF__
int ComSystemCpuInfoGetter::t_getMaxCpuNum(void) { return ERROR; }
// int ComSystemCpuInfoGetter::t_getCpuLoad200ms(const cpuId) { return ERROR; }
int ComSystemCpuInfoGetter::t_getCpuLoad3sec(const cpuId) { return ERROR; }
// int ComSystemCpuInfoGetter::t_getCpuLoad5min(const cpuId) { return ERROR; }
// int ComSystemCpuInfoGetter::t_getCpuLoadOneDemand(const cpuId, const int) { return ERROR; }
// int ComSystemCpuInfoGetter::t_getCpuLoadAllPeriodSupported(const cpuId) { return ERROR; }

#else
int ComSystemCpuInfoGetter::t_getMaxCpuNum(void)
{
    AUTO_TRACE_FUNC;

#ifdef __NVGNB__
    if ((m_maxCpuNum = hal_get_linux_core_num()) < 0)
#else
    if ((m_maxCpuNum = hal_get_maxcpunum()) < 0)
#endif
    {
        VCCB_PRINT_ERROR("fail to get hal_get_maxcpunum\n");
    }
    return m_maxCpuNum;
}

// int ComSystemCpuInfoGetter::t_getCpuLoad200ms(const cpuId id)
//{
//    AUTO_TRACE_FUNC;
//
//    int returnValue = -1;
//    if ((returnValue = cpuGetLoad(static_cast<int>(id), HAL_CPULOAD_DURATION_200MSEC)) < 0)
//    {
//        VCCB_PRINT_ERROR("fail to get cpuGetLoad(200ms)\n");
//    }
//    return returnValue;
//}

int ComSystemCpuInfoGetter::t_getCpuLoad3sec(const cpuId id)
{
    AUTO_TRACE_FUNC;

    int returnValue = -1;
    if ((returnValue = cpuGetLoad(static_cast<int>(id), HAL_CPULOAD_DURATION_3SEC)) < 0)
    {
        VCCB_PRINT_ERROR("fail to get cpuGetLoad(3sec)\n");
    }
    return returnValue;
}

// int ComSystemCpuInfoGetter::t_getCpuLoad5min(const cpuId id)
//{
//    AUTO_TRACE_FUNC;
//
//    int returnValue = -1;
//    if ((returnValue = cpuGetLoad(static_cast<int>(id), HAL_CPULOAD_DURATION_5MIN)) < 0)
//    {
//        VCCB_PRINT_ERROR("fail to get cpuGetLoad(5min)\n");
//    }
//    return returnValue;
//}

// bool ComSystemCpuInfoGetter::m_checkAvailablePeriod(const int periodSec)
//{
//    AUTO_TRACE_FUNC;
//
//    return (periodSec > 0 && periodSec < 30 ? true : false);
//}

// int ComSystemCpuInfoGetter::t_getCpuLoadOneDemand(const cpuId id, const int periodSec)
//{
//    AUTO_TRACE_FUNC;
//
//    int returnValue = -1;
//
//    if (m_checkAvailablePeriod(periodSec) == false) return returnValue;
//
//    if ((returnValue = hal_get_cpuload_one_demand(static_cast<int>(id), periodSec)) < 0)
//    {
//        VCCB_PRINT_ERROR("fail to get hal_get_cpuload_5min\n");
//    }
//    return returnValue;
//}

// int ComSystemCpuInfoGetter::t_getCpuLoadAllPeriodSupported(const cpuId id)
//{
//    AUTO_TRACE_FUNC;
//
//    HAL_CPULOAD_t tCpuLoad;
//    memset(&tCpuLoad, 0, sizeof(HAL_CPULOAD_t));
//
//    int returnValue = -1;
//    if ((returnValue = hal_get_cpuload_all(static_cast<int>(id), &tCpuLoad)) < 0)
//    {
//        VCCB_PRINT_ERROR("fail to get hal_get_cpuload_all\n");
//        return returnValue;
//    }
//
//    VCCB_PRINT_COMMENT("=============== [cpu load all] ===============\n");
//    VCCB_PRINT_COMMENT("VCCB) cpuload average 200ms %3i%% \n", tCpuLoad.load_200ms);
//    VCCB_PRINT_COMMENT("VCCB) cpuload average 3sec %3i%% \n", tCpuLoad.load_3sec);
//    VCCB_PRINT_COMMENT("VCCB) cpuload average 5min %3i%% \n", tCpuLoad.load_5min);
//    VCCB_PRINT_COMMENT("=======================================\n");
//
//    return returnValue;
//}
#endif  // __CNF__

bool ComSystemCpuInfoGetter::t_getCpuId(const int id, cpuId &rCpuId)
{
    AUTO_TRACE_FUNC;
    if (m_isCpuIdExisted(id) == false)
    {
        VCCB_PRINT_ERROR("the id %d requested is not existed in map\n", id);
        return false;
    }

    rCpuId = m_cpuIdMap[id];
    return true;
}
