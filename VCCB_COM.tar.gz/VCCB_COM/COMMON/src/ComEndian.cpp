#include "ComEndian.h"
#include "ComGlobalData.h"
#include "ComLibIpcApi.h"
#include "ComAutoNtrace.hpp"
#include "ComLibUtility.h"

#include "msg_id_5g_cucp.h"
#include "DbiInterface.h"

#if (__BYTE_ORDER == __LITTLE_ENDIAN)

#define ENDIAN_PTALL_FUNC_REGISTER(msgId, structName)       \
    case msgId:                                             \
        VLIB_Endian_##structName((structName *)ptAll, dir); \
        break

#define ENDIAN_PTALL_FUNC_MESSAGE_TYPE(msgId, structName)     \
    case msgId:                                               \
        VLIB_Endian_##structName((message_type *)ptAll, dir); \
        break

void VLIB_ByteOrder(void *src, uint32_t len)
{
    VALID_E_POINT_CHECK_VOID(src);

    switch (len)
    {
        // 64bit
        case sizeof(uint64_t):
            *((uint64_t *)src) = htobe64(*(uint64_t *)src);
            break;
        // 32bit
        case sizeof(uint32_t):
            *((uint32_t *)src) = htobe32(*(uint32_t *)src);
            break;
        // 16bit
        case sizeof(uint16_t):
            // Changed to htons due to compile warning.
            *((uint16_t *)src) = (htons)(*(uint16_t *)src);
            break;

        default:
            break;
    }
}

/********************************
 *
 *  COMMON STRUCT FUNC
 *
 *********************************/
void VLIB_Endian_msgHdr(msgHdr_type *p, int dir)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(p);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(dir, ci_Tx, ci_Rx);

    ENDIAN_CONVERT(p->version);
    ENDIAN_CONVERT(p->reserved);
    ENDIAN_CONVERT(p->msgType);
}

static __inline void VLIB_Endian_MdsIp_Type(MdsIp_Type *p, enumDirection_type dir)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(p);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(dir, ci_Tx, ci_Rx);

    if (p->IpVer == MDS_IPV4 || p->IpVer == IPV4)  // only ipv4 = int, ipv6 = byte
        ENDIAN_CONVERT(p->Ip.V4);

    ENDIAN_CONVERT(p->IpVer);
}

static __inline void VLIB_Endian_MdsAddr_Type(MdsAddr_Type *p, enumDirection_type dir)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(p);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(dir, ci_Tx, ci_Rx);

    VLIB_Endian_MdsIp_Type(&p->MdsIp, dir);
    ENDIAN_CONVERT(p->MdsPort);
}

static __inline void VLIB_Endian_plmnId_type(plmnId_type *p, enumDirection_type dir)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(p);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(dir, ci_Tx, ci_Rx);

    ENDIAN_CONVERT(p->longId);
}

static __inline void VLIB_Endian_msgNewPciNotifyVccbOsab_type(msgNewPciNotifyVccbOsab_type *p, enumDirection_type dir)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(p);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(dir, ci_Tx, ci_Rx);

    VLIB_Endian_MdsAddr_Type(&p->address, dir);

    // p->servCgi
    VLIB_Endian_plmnId_type(&p->servCgi.plmn, dir);
    ENDIAN_CONVERT(p->servCgi.gnbIdLength);
    for (int i = 0; i < 3; i++)
    {
        ENDIAN_CONVERT(p->servCgi.reserved[i]);
    }
    ENDIAN_CONVERT(p->servCgi.ci);

    ENDIAN_CONVERT(p->uNotify.pciNotifyNr.rsType);
    ENDIAN_CONVERT(p->ueBasedCgiAvailability);
    ENDIAN_CONVERT(p->callId);
    ENDIAN_CONVERT(p->mrType);

    if (nrType == p->objType)
    {
        ENDIAN_CONVERT(p->uNotify.pciNotifyNr.pci);
        ENDIAN_CONVERT(p->uNotify.pciNotifyNr.ssbFreq);
    }
    else
    {
        ENDIAN_CONVERT(p->uNotify.pciNotifyEu.pci);
        ENDIAN_CONVERT(p->uNotify.pciNotifyEu.earfcnDl);
    }
    ENDIAN_CONVERT(p->objType);
}

static __inline void VLIB_Endian_msgNcgiRequestOsabVccb_type(msgNcgiRequestOsabVccb_type *p, enumDirection_type dir)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(p);
    messageHdr_type *pHdr;
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(dir, ci_Tx, ci_Rx);

    pHdr = (messageHdr_type *)p;
    // note : OAM Send this msg with endian converted callId
    ENDIAN_CONVERT(pHdr->dst.contextId);

    ENDIAN_CONVERT(p->reserved);
    ENDIAN_CONVERT(p->mrType);

    if (nrType == p->objType)
    {
        ENDIAN_CONVERT(p->uReq.cgiReqNr.pci);
        ENDIAN_CONVERT(p->uReq.cgiReqNr.rsType);
        ENDIAN_CONVERT(p->uReq.cgiReqNr.ssbFreq);
    }
    else
    {
        ENDIAN_CONVERT(p->uReq.cgiReqEu.pci);
        ENDIAN_CONVERT(p->uReq.cgiReqEu.earfcnDl);
    }
    ENDIAN_CONVERT(p->objType);
}

static __inline void VLIB_Endian_msgNcgiNotifyVccbOsab_type(msgNcgiNotifyVccbOsab_type *p, enumDirection_type dir)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(p);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(dir, ci_Tx, ci_Rx);

    VLIB_Endian_plmnId_type(&p->servCgi.plmn, dir);
    ENDIAN_CONVERT(p->servCgi.gnbIdLength);
    for (int i = 0; i < 3; i++)
    {
        ENDIAN_CONVERT(p->servCgi.reserved[i]);
    }
    ENDIAN_CONVERT(p->servCgi.ci);

    ENDIAN_CONVERT(p->endPointNGIdx);
    ENDIAN_CONVERT(p->mrType);
    if (nrType == p->objType)
    {
        ENDIAN_CONVERT(p->uNotify.ncgiInfo.pci);
        ENDIAN_CONVERT(p->uNotify.ncgiInfo.numNrCgi);
        ENDIAN_CONVERT(p->uNotify.ncgiInfo.subcarrierSpacing);
        ENDIAN_CONVERT(p->uNotify.ncgiInfo.ssbFreq);
        ENDIAN_CONVERT(p->uNotify.ncgiInfo.saAvailability);

        for (int i = 0; i < MAX_NUM_ANR_NRCGI; i++)
        {
            ENDIAN_CONVERT(p->uNotify.ncgiInfo.ncgi[i].numPlmn);
            for (int j = 0; j < MAX_ANR_PLMN; j++)
            {
                VLIB_Endian_plmnId_type(&p->uNotify.ncgiInfo.ncgi[i].plmn[j], dir);
            }
            VLIB_Endian_plmnId_type(&p->uNotify.ncgiInfo.ncgi[i].cgi.plmn, dir);
            ENDIAN_CONVERT(p->uNotify.ncgiInfo.ncgi[i].cgi.ci);
            ENDIAN_CONVERT(p->uNotify.ncgiInfo.ncgi[i].tac);
        }
    }
    else
    {
        ENDIAN_CONVERT(p->uNotify.ecgiInfo.pci);
        ENDIAN_CONVERT(p->uNotify.ecgiInfo.numEutraCgi);
        ENDIAN_CONVERT(p->uNotify.ecgiInfo.earfcnDl);

        for (int i = 0; i < MAX_NUM_ECGI; i++)
        {
            ENDIAN_CONVERT(p->uNotify.ecgiInfo.ecgi[i].numPlmn);
            for (int j = 0; j < MAX_ANR_PLMN; j++)
            {
                VLIB_Endian_plmnId_type(&p->uNotify.ecgiInfo.ecgi[i].plmn[j], dir);
            }
            VLIB_Endian_plmnId_type(&p->uNotify.ecgiInfo.ecgi[i].cgi.plmn, dir);
            ENDIAN_CONVERT(p->uNotify.ecgiInfo.ecgi[i].cgi.ci);
            ENDIAN_CONVERT(p->uNotify.ecgiInfo.ecgi[i].tac);
        }
    }
    ENDIAN_CONVERT(p->objType);
}

static __inline void VLIB_Endian_msgNcgiFailureVccbOsab_type(msgNcgiFailureVccbOsab_type *p, enumDirection_type dir)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(p);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(dir, ci_Tx, ci_Rx);

    VLIB_Endian_plmnId_type(&p->servCgi.plmn, dir);
    ENDIAN_CONVERT(p->servCgi.gnbIdLength);
    for (int i = 0; i < 3; i++)
    {
        ENDIAN_CONVERT(p->servCgi.reserved[i]);
    }
    ENDIAN_CONVERT(p->servCgi.ci);

    if (nrType == p->objType)
    {
        ENDIAN_CONVERT(p->uFailure.failInfoNr.pci);
        ENDIAN_CONVERT(p->uFailure.failInfoNr.rsType);
        ENDIAN_CONVERT(p->uFailure.failInfoNr.ssbFreq);
    }
    else
    {
        ENDIAN_CONVERT(p->uFailure.failInfoEu.pci);
        ENDIAN_CONVERT(p->uFailure.failInfoEu.earfcnDl);
    }

    ENDIAN_CONVERT(p->cause);
    ENDIAN_CONVERT(p->objType);
}

static __inline void VLIB_Endian_msgInvalidNcrNotifyVccbOsab_type(
    msgInvalidNcrNotifyVccbOsab_type *p, enumDirection_type dir)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(p);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(dir, ci_Tx, ci_Rx);

    VLIB_Endian_plmnId_type(&p->servCgi.plmn, dir);
    ENDIAN_CONVERT(p->servCgi.gnbIdLength);
    for (int i = 0; i < 3; i++)
    {
        ENDIAN_CONVERT(p->servCgi.reserved[i]);
    }
    ENDIAN_CONVERT(p->servCgi.ci);
    ENDIAN_CONVERT(p->objType);
    ENDIAN_CONVERT(p->ncrIndex);
    ENDIAN_CONVERT(p->reserved);
}

static __inline void VLIB_Endian_msgMGMTInformStartAckNotiSwm_type(message_type *p, enumDirection_type dir)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(p);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(dir, ci_Tx, ci_Rx);

    ENDIAN_CONVERT(p->transactionId);
    ENDIAN_CONVERT(p->contextId);
    ENDIAN_CONVERT(p->reserved);
    ENDIAN_CONVERT(p->dataLen);
}

static __inline void VLIB_Endian_msgDBInformPldNotiDbiAll_type(
    msgDBInformPldNotiDbiAll_type *p, enumDirection_type dir)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(p);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(dir, ci_Tx, ci_Rx);

    ENDIAN_CONVERT(p->relId);
    ENDIAN_CONVERT(p->updateType);
    ENDIAN_CONVERT(p->numOfPKey);
    
    const int maxOfKeyIndex = MIN(p->numOfPKey, MAX_NUM_OF_PKEY);
    for (int keyIndex = 0; keyIndex < maxOfKeyIndex; keyIndex++)
    {
        ENDIAN_CONVERT(p->tpKey[keyIndex]);
    }
}

int FnVCCB_EndianConvertForPLDTuple(int relId, char *pData)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pData);
    
    vccbPldAttributeInfo_type *pInfo = NULL;

    int index;
    int minValue = MIN(CFG->pld.numOfPldWithData, MAX_NUM_SUBSCRIBE_PLD);
    for (index = 0; index < minValue; index++)
    {
        pInfo = &CFG->pld.pldAttInfo[index];
        if (pInfo->relationId == relId) 
            break;
    }

    if (index == minValue) // Cannot find relation id in pldAttInfo
    {
        VCCB_PRINTF("%s: Relation ID(0x%x) cannot be found in pldAttInfo!\n", __func__, relId);
        return ERROR;
    }

    attributeInfo *pAttrInfo = pInfo->attInfo;

    uint32_t offset = 0;
    uint32_t tmpInt;
    uint16_t tmpShort;
    unsigned long tmpLong;

    for (unsigned int i = 0; i < MIN(pInfo->numOfAttribute, DBI_MAX_LOOP_CNT_ATTR); i++)
    {
        switch (pAttrInfo[i].type)
        {
            case ATTR_TYPE_CHAR:
            case ATTR_TYPE_UCHAR:
            case ATTR_TYPE_STRING:
                offset += (uint32_t)pAttrInfo[i].length;
                break;

            case ATTR_TYPE_SHORT:
            case ATTR_TYPE_USHORT:
                for (uint16_t idx = 0; idx < MIN(pAttrInfo[i].length, DBI_MAX_LOOP_CNT); idx++)
                {
                    memcpy((void*)&tmpShort, pData + offset, sizeof(short));
                    tmpShort = (htons)(tmpShort);
                    memcpy(pData + offset, (void*)&tmpShort, sizeof(short));
                    offset += (uint32_t)sizeof(short);
                }
                break;

            case ATTR_TYPE_INT:
            case ATTR_TYPE_UINT:
            case ATTR_TYPE_IPV4_ADDRESS:
                for (uint16_t idx = 0; idx < MIN(pAttrInfo[i].length, DBI_MAX_LOOP_CNT); idx++)
                {
                    memcpy((void*)&tmpInt, pData + offset, sizeof(int));
                    tmpInt = htobe32(tmpInt);
                    memcpy(pData + offset, (void*)&tmpInt, sizeof(int));
                    offset += (uint32_t)sizeof(int);
                }
                break;

            case ATTR_TYPE_LONG:
            case ATTR_TYPE_ULONG:
                for (uint16_t idx = 0; idx < MIN(pAttrInfo[i].length, DBI_MAX_LOOP_CNT); idx++)
                {
                    memcpy((void*)&tmpLong, pData + offset, sizeof(long));
                    if (sizeof(long) == 4)
                    {
                        tmpLong = htobe32((uint32_t)tmpLong);
                    }
                    else
                    {
                        tmpLong = htobe64(tmpLong);
                    }
                    memcpy(pData + offset, (void*)&tmpLong, sizeof(long));
                    offset += (uint32_t)sizeof(long);
                }
                break;

            case ATTR_TYPE_FLOAT:
                for (uint16_t idx = 0; idx < MIN(pAttrInfo[i].length, DBI_MAX_LOOP_CNT); idx++)
                {
                    memcpy((void*)&tmpInt, pData + offset, sizeof(float));
                    tmpInt = htobe32(tmpInt);
                    memcpy(pData + offset, (void*)&tmpInt, sizeof(float));
                    offset += (uint32_t)sizeof(float);
                }
                break;

            case ATTR_TYPE_IPV6_ADDRESS:
                offset += (uint32_t)(pAttrInfo[i].length * 16);
                break;

            case ATTR_TYPE_MAC_ADDRESS:
                offset += (uint32_t)(pAttrInfo[i].length * 6);
                break;

            default:
                VCCB_PRINTF("%s: Unknown Attribute Type ERROR!!(%d)\n", __func__, pAttrInfo[i].type);
                return ERROR;
        }
    }

    return GOOD;
}

static __inline void VLIB_Endian_msgDBInformPldWithDataNotiDbiAll_type(
    msgDBInformPldWithDataNotiDbiAll_type *p, enumDirection_type dir)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(p);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(dir, ci_Tx, ci_Rx);

    ENDIAN_CONVERT(p->relId);
    ENDIAN_CONVERT(p->updateType);
    ENDIAN_CONVERT(p->numOfPKey);
    
    const int maxOfKeyIndex = MIN(p->numOfPKey, MAX_NUM_OF_PKEY);
    for (int keyIndex = 0; keyIndex < maxOfKeyIndex; keyIndex++)
    {
        ENDIAN_CONVERT(p->tpKey[keyIndex]);
    }

    ENDIAN_CONVERT(p->dataSize);
    
    if (ERROR == FnVCCB_EndianConvertForPLDTuple(p->relId, (char *)p + sizeof(msgDBInformPldWithDataNotiDbiAll_type)))
    {
        // To get UserPLD Data using dbiGetTuple when ERROR happened
        p->dataSize = 0;
    }
}

/********************************
 *
 *  API
 *
 *********************************/
void VLIB_MsgByteOrder(bigMessage_type *ptAll, enumDirection_type dir)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptAll);

    if (dir == ci_Rx)  // always change
        VLIB_Endian_msgHdr(&ptAll->msgHdr, dir);

    switch (ptAll->msgHdr.msgType)
    {
        /*************************************************************************/
        /* Single-directional conversion to Network Order = Tx Only              */
        /*************************************************************************/

        /*************************************************************************/
        /* Bidirectional conversion between Network Order and Host Order = Tx/Rx */
        /*************************************************************************/

        // OSAB
        ENDIAN_PTALL_FUNC_REGISTER(msgNewPciNotifyVccbOsab_id, msgNewPciNotifyVccbOsab_type);
        ENDIAN_PTALL_FUNC_REGISTER(msgNcgiRequestOsabVccb_id, msgNcgiRequestOsabVccb_type);
        ENDIAN_PTALL_FUNC_REGISTER(msgNcgiNotifyVccbOsab_id, msgNcgiNotifyVccbOsab_type);
        ENDIAN_PTALL_FUNC_REGISTER(msgNcgiFailureVccbOsab_id, msgNcgiFailureVccbOsab_type);
        ENDIAN_PTALL_FUNC_REGISTER(msgInvalidNcrNotifyVccbOsab_id, msgInvalidNcrNotifyVccbOsab_type);
        ENDIAN_PTALL_FUNC_MESSAGE_TYPE(msgMGMTInformStartAckNotiSwm_id, msgMGMTInformStartAckNotiSwm_type);

        // DBI
        ENDIAN_PTALL_FUNC_REGISTER(msgDBInformPldNotiDbiAll_id, msgDBInformPldNotiDbiAll_type);
        ENDIAN_PTALL_FUNC_REGISTER(msgDBInformPldWithDataNotiDbiAll_id, msgDBInformPldWithDataNotiDbiAll_type);

        default:
            break;
    }

    if (dir == ci_Tx)  // always change
        VLIB_Endian_msgHdr(&ptAll->msgHdr, dir);
}

#else

#pragma message("This System is Big Endian. the endian conversion is applied.")

#endif
