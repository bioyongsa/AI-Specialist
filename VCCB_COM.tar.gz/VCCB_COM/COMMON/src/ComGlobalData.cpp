/**
 * @file       VccbGlobalData.c
 * @brief      File containing all globals used by VCCB block
 */

/*----------------------------------------------------------------------------
 * Define    :    Include Header Files
 * ---------------------------------------------------------------------------
 */
#include "ComGlobalData.h"
#include "ComLibIpcApi.h"
#include "RscProto.h"

/*---<For IPC>-------------------------------------------------*/
/**
 * @brief VCCB block global data structure
 */
static VccbInfo_type gVccbInfo;
VccbInfo_type *FnVCCB_GetgVccbInfo() { return &gVccbInfo; }

VccbSegmentPoolInfo_type *GetgSegmentPoolInfo_()
{
    if (gVccbInfo.capa == NULL)
    {
        return NULL;
    }
    return gVccbInfo.capa;
}

segmentPoolBuffer_type *GetgSegmentPoolBuffer_()
{
    if (gVccbInfo.capa == NULL)
    {
        return NULL;
    }
    return (gVccbInfo.capa->segmentPoolBuffer);
}

segmentPoolManager_type *GetgSegmentPoolManager_()
{
    if (gVccbInfo.capa == NULL)
    {
        return NULL;
    }
    return &gVccbInfo.capa->segmentPoolManager;
}

// Get Handover Preparation DB
uint8_t *FnVCCB_Get_HandoverPreparationBufferForCallDB(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_NULL(ptCi);
    VALID_E_POINT_CHECK_NULL(EXTERNAL_INFO.call);

    const uint32_t callId = ptCi->callId;

    if (IS_VALID_PTCI(ptCi) == FALSE)  // CALL DB JOB
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid Call Info!! (%p, %p~%p)\n", ptCi, &ENV->callInfo[0],
            &ENV->callInfo[MAX_CALL_NUM_VCCB]);
        return NULL;
    }

    if (IS_VALID_CALLID_VCCB(callId) == false)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid Call Id(%u, 0~%u)!!\n", callId, VCCB_MAX_CALL_COUNT_PER_CPC);
        return NULL;
    }

    return EXTERNAL_INFO.call[callId].mobility.rrcHandoverPreparation;
}

// pthread_mutex_t gMemoryUsageMtx          = PTHREAD_MUTEX_INITIALIZER; // [SAM_GV_IMPROVEMENT]
static pthread_mutex_t gMemoryUsageMtx_ = PTHREAD_MUTEX_INITIALIZER;  // [SAM_GV_IMPROVEMENT]
pthread_mutex_t *GetgMemoryUsageMtx_() { return &gMemoryUsageMtx_; }  // [SAM_GV_IMPROVEMENT]

#ifdef HOST_SIM
uint16_t gSendbackUe = 1; /**< Sendback Merge */
#endif                    // #ifdef HOST_SIM

/*------------------------<For VRRM>-----------------------------------------------*/

// Multi-Thread

// [SAM_GV_IMPROVEMENT] on 20200417
static pthread_mutex_t
    gVrrmCellCfgMtx_[MAX_CELL_PER_VNF]; /**< VCCB block global Mutex table for each CA Cell Cfg structure */
pthread_mutex_t *GetgVrrmCellCfgMtx_() { return gVrrmCellCfgMtx_; };
static pthread_mutex_t gVrrmGnbCfgMtx_ =
    PTHREAD_MUTEX_INITIALIZER; /**< VCCB block global Mutex for Enb Config structure */
pthread_mutex_t *GetgVrrmGnbCfgMtx_() { return &gVrrmGnbCfgMtx_; };
static pthread_mutex_t gActiveUeBitmapMtx_ =
    PTHREAD_MUTEX_INITIALIZER; /**< VCCB block global Mutex for ActiveUeBitmap */
pthread_mutex_t *GetgActiveUeBitmapMtx_() { return &gActiveUeBitmapMtx_; };
static pthread_mutex_t gAuditTaskMtx_ = PTHREAD_MUTEX_INITIALIZER; /**< VCCB block global Mutex for Audit Task */
pthread_mutex_t *GetgAuditTaskMtx_() { return &gAuditTaskMtx_; };
static pthread_mutex_t gCellNumAllocMtx_ =
    PTHREAD_MUTEX_INITIALIZER; /**< VCCB block global Mutex for cellNum Allocation PLD vs Confd Task*/
pthread_mutex_t *GetCellNumAllocMtx_() { return &gCellNumAllocMtx_; };
static pthread_mutex_t gCellHistUpdateMtx_[MAX_CELL_PER_VNF]; /**< VCCB block global Mutex table for each cellnum */
pthread_mutex_t *GetgCellHistUpdateMtx_() { return gCellHistUpdateMtx_; };
static pthread_mutex_t gCellUeMeasForSonMtx_[MAX_CELL_PER_VNF];
pthread_mutex_t *GetgCellUeMeasForSonMtx_() { return gCellUeMeasForSonMtx_; };
static pthread_mutex_t gIRNTIAllocMtx_[MAX_GNB_CU_CP_FUNCTION_PER_SYS];
pthread_mutex_t *GetgIRNTIAllocMtx_() { return gIRNTIAllocMtx_; };
#ifdef __CNF__
static pthread_mutex_t gDistCodeMtx_[MAX_DIST_CODE_PER_SYS];
pthread_mutex_t *GetgDistCodeMtx_() { return gDistCodeMtx_; };
#endif

// SVR26A FGR-CC3103 IODT RACS(UE Radio Capability Signaling Optimization)
static pthread_rwlock_t gRacsCapaIdListMtx_;                          /**< VCCB block global Mutex table for RACA CAPA ID List */
static pthread_rwlock_t gRacsCapaBufferListMtx_[MAX_UE_CAPA_ID_CNT];  /**< VCCB block global Mutex table for RACA CAPA ID List */
pthread_rwlock_t    *GetgRacsCapaIdListMtx_()     { return &gRacsCapaIdListMtx_; }
pthread_rwlock_t    *GetgRacsCapaBufferListMtx_() { return gRacsCapaBufferListMtx_; }

#ifndef HOST_SIM
uint8_t gCaBandComDebug = 0; /**< VCCB block global variable for enabling additional logs for CA */
#else
uint8_t gCaBandComDebug = 1; /**< VCCB block global variable for enabling additional logs for CA */
#endif

uint8_t gCslDebugFlag = False; /**< VCCB block global variable for enabling additional logs for CSL */

static uint32_t gSeed_ = 0;                // [SAM_GV_IMPROVEMENT]
uint32_t *GetgSeed_() { return &gSeed_; }  // [SAM_GV_IMPROVEMENT]

// char gVccbLogCodeName[MAX_VCCB_LOG_CODE+1][MAX_VCCB_LP_CODE_STRING] = // [SAM_GV_IMPROVEMENT]
static char gVccbLogCodeName_[MAX_VCCB_LOG_CODE + 1][MAX_VCCB_LP_CODE_STRING] =  // [SAM_GV_IMPROVEMENT]
    {{"VccbRestarted"}, {"RST_MW_INIT"}, {"RST_MEM_ALLOC"}, {"RST_TASK_INIT"}, {"RST_MUTEX_INIT"}, {"RST_MUTEX_ST"},
        {"RST_IP_PORT"}, {"RST_DB_SUB"}, {"RST_DB_INIT"}, {"RST_SRC_IP"}, {"RST_SRC_PORT"}, {"ANR"}, {"MAX_LOG_CODE"}};
char *GetgVccbLogCodeName_(int code) { return gVccbLogCodeName_[code]; }  // [SAM_GV_IMPROVEMENT]

// for Log fishing
// uint8_t gLogFishingRequestCount = 0;
static uint8_t gLogFishingRequestCount_[VCCB_CALL_THREAD_NUM] = {0};          // [SAM_GV_IMPROVEMENT]
uint8_t *GetgLogFishingRequestCount_() { return gLogFishingRequestCount_; };  // [SAM_GV_IMPROVEMENT]

// uint8_t gLastDfcbCallThread[VCCB_CALL_THREAD_NUM]; // for NVGNB
static uint8_t gLastDfcbCallThread_[VCCB_CALL_THREAD_NUM];  // for NVGNB
uint8_t *GetgLastDfcbCallThread() { return gLastDfcbCallThread_; };

static uint8_t gLastDfcbRRCThread_[VCCB_CALL_THREAD_NUM];  // for NVGNB
uint8_t *GetgLastDfcbRRCThread() { return gLastDfcbRRCThread_; };

// uint8_t gLastVupbCallThread[VCCB_CALL_THREAD_NUM]; // for NVGNB
static uint8_t gLastVupbCallThread_[VCCB_CALL_THREAD_NUM];
uint8_t *GetgLastVupbCallThread() { return gLastVupbCallThread_; };

// uint16_t                gAnrMrCountCellNum;
static uint16_t gAnrMrCountCellNum_;                                         // [SAM_GV_IMPROVEMENT]
uint16_t *GetgAnrMrCountCellNum_() { return &gAnrMrCountCellNum_; }          // [SAM_GV_IMPROVEMENT]
static uint16_t gIRatAnrMrCountCellNum_;                                     // [SAM_GV_IMPROVEMENT]
uint16_t *GetgIRatAnrMrCountCellNum_() { return &gIRatAnrMrCountCellNum_; }  // [SAM_GV_IMPROVEMENT]

// [SAM_GV_IMPROVEMENT_22A]
static bool sTriggerOndemandHandoverByPLD_;
bool *GetsTriggerOndemandHandoverByPLD_() { return &sTriggerOndemandHandoverByPLD_; }
static uint16_t mappingCellNumAndPldCellIdx_[MAX_CELL_PER_VNF];
uint16_t *GetmappingCellNumAndPldCellIdx() { return mappingCellNumAndPldCellIdx_; };

static VccbSystem_type gSystemType = e_VCCB_ACPF_VNF;

VccbSystem_type VCOM_getSystemType(void) { return gSystemType; }

void FnVCCB_setSystemType(VccbSystem_type status) { gSystemType = status; }

static uint8_t gHostSim =
#if defined(NEW_HOST_SIM) && (!defined(__CNF__) || defined(IPC_TEST))
    TRUE;
#else
    FALSE;
#endif

uint8_t FnVCCB_IsIpcTest(void) {
#ifdef VCCB_IPC_TEST
    return DBG->checkGbrUe;
#else
    return CHECK_GBR_UE_DBG_MODE_VAL;
#endif
}

uint8_t VCOM_IsHostSim(void) { return gHostSim; }

uint8_t VCOM_getUnitType(uint16_t block)
{
    uint8_t unitType = UNIT_TYPE_NULL;

    if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
    {
        switch (block)
        {
            case BLOCK_VCCB:
                unitType = CPP;
                break;
            case BLOCK_VNMB:
                unitType = CIP;
                break;
            case BLOCK_VNLB:
                unitType = CSP;
                break;
            case BLOCK_VTMB:
                unitType = CTP;
                break;
            case BLOCK_OSAB:
                unitType = CMP;
                break;
            case BLOCK_VCSB:
                unitType = SNP;
                break;
            default:
                break;
        }
    }
    else  // e_VCCB_ACPF_VNF
    {
        switch (block)
        {
            case BLOCK_VCCB:
                unitType = CPC;
                break;
            case BLOCK_VNMB:
                unitType = CIC;
                break;
            case BLOCK_VNLB:
                unitType = CIC;
                break;
            case BLOCK_VTMB:
                unitType = CMC;
                break;
            case BLOCK_VCLB:
                unitType = CPC;
                break;
            case BLOCK_OSAB:
                unitType = CMC;
                break;
            case BLOCK_VCSB:
                unitType = CMC;
                break;
            default:
                break;
        }
    }
    return unitType;
}

// [SAM_GV_IMPROVEMENT_22A]
static bool gEgSetFlag_ = false;
bool GetgEgFlag() { return gEgSetFlag_; }
void SetgEgFlag(bool egSetFlag) { gEgSetFlag_ = egSetFlag; }

static int32_t gEgLevel_ = 0;
int32_t GetEgLevel() { return gEgLevel_; }
void SetEgLevel(int32_t egLevel) { gEgLevel_ = egLevel; }

static VccbStatisticsItemCollect_type gStatisticsItemCollect_[VCCB_CALL_THREAD_NUM + 1];
VccbStatisticsItemCollect_type *GetgStatisticsItemCollect_() { return gStatisticsItemCollect_; };

static VccbStatisticsItemUpdate_type  gStatisticsItemUpdate_[VCCB_CALL_THREAD_NUM + 1];
VccbStatisticsItemUpdate_type  *GetgStatisticsItemUpdate_() { return gStatisticsItemUpdate_; };

#define GLOBAL_ARR2D(__TYPE, __VAR, __FUNC, __ROW, __COL) \
    static __TYPE __VAR[__ROW][__COL];                    \
    __TYPE(*__FUNC()) [__COL] { return __PTR; }

#define GLOBAL_ARR3D(__TYPE, __VAR, __FUNC, __ROW, __COL1, __COL2) \
    static __TYPE __VAR[__ROW][__COL1][__COL2];                    \
    __TYPE(*__FUNC()) [__COL1][__COL2] { return __VAR; }

// Thread, msg(Coll[0]/Update[1]), Prev[1]/Curr[0]
// uint32_t gCallStatisticsMessageCount[VCCB_CALL_THREAD_NUM][STATTISTICS_METHOD_TYPE_MAX][STATISTICS_MESSAGE_TIME_MAX] = {0, };

// [SAM_GV_IMPROVEMENT]
GLOBAL_ARR3D(uint32_t, gCallStatisticsMessageCount_, GetgCallStatisticsMessageCount_, \
        VCCB_CALL_THREAD_NUM, STATISTICS_METHOD_TYPE_MAX, STATISTICS_MESSAGE_TIME_MAX)

/* EOF */
