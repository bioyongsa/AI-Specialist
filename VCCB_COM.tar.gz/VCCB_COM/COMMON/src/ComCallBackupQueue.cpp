
#ifdef __CNF__
#include "lz4.h"
#include "ComCallBackupQueue.h"
#include "ComGlobalData.h"
#include "ComLibIpcApi.h"
#include "ComLibTimer.h"

/*****************About Ring Queue*****************/

/*
    Maximum queued count                                            -> itscp_vccb get env ha info
    queue Full count                                                -> itscp_vccb get env ha info
    Displays the number of commands processed periodically          -> itscp_vccb set dbg flag extDbDbug on
    Abnormal operating debug count                                  -> TO DO
    Queue Initialization Command                                    -> itscp_vccb get env ha buffflush
*/
void FnVCCB_InitCallQ(uint32_t threadId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);
    auto &callBackupQueue = ENV->redis.callBackupQueue[threadId];

    size_t size = sizeof(callBackupQueue.queue);

    MUTEX_LOCK(&callBackupQueue.callQueueMutex);

    callBackupQueue.frontIdx = 0;
    callBackupQueue.rearIdx = 0;
    callBackupQueue.maxEnqueueCnt = 0;
    callBackupQueue.queueOverCnt = 0;
    callBackupQueue.qFullCnt = 0;
    memset(callBackupQueue.queue, 0, size);

    MUTEX_UNLOCK(&callBackupQueue.callQueueMutex);
}

uint32_t FnVCCB_GetQueueSize(const uint8_t threadId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_FALSE(threadId, MAX_CALL_THREAD_NUM_VCCB);
    const auto &callBackupQueue = ENV->redis.callBackupQueue[threadId];

    int32_t rearIdx = callBackupQueue.rearIdx % VCCB_MAX_CALL_CTX_BACKUP_BUFF;
    int32_t frontIdx = callBackupQueue.frontIdx % VCCB_MAX_CALL_CTX_BACKUP_BUFF;
    if (rearIdx < frontIdx)
    {
        rearIdx += VCCB_MAX_CALL_CTX_BACKUP_BUFF;
    }
    return (uint32_t)(rearIdx - frontIdx);
}

int is_queue_full(uint16_t threadId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(threadId, MAX_CALL_THREAD_NUM_VCCB);
    const auto &callBackupQueue = ENV->redis.callBackupQueue[threadId];

    int32_t rearIdx = callBackupQueue.rearIdx % VCCB_MAX_CALL_CTX_BACKUP_BUFF;
    int32_t frontIdx = callBackupQueue.frontIdx % VCCB_MAX_CALL_CTX_BACKUP_BUFF;
    if (frontIdx == (rearIdx + 1) % VCCB_MAX_CALL_CTX_BACKUP_BUFF)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

int is_queue_empty(uint16_t threadId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(threadId, MAX_CALL_THREAD_NUM_VCCB);

    if (FnVCCB_GetQueueSize(static_cast<uint8_t>(threadId)) == 0)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

const char *FnVCCB_GetBackUpTypeStr(enumBackupType_type backUpType)
{
    switch (backUpType)
    {
        case BACKUP_TYPE_SET:
            return "BACKUP_TYPE_SET";
        case BACKUP_TYPE_DEL:
            return "BACKUP_TYPE_DEL";
        case BACKUP_TYPE_UPDATE_STATE:
            return "BACKUP_TYPE_UPDATE_STATE";
        case BACKUP_TYPE_UPDATE_EXPIRE:
            return "BACKUP_TYPE_UPDATE_EXPIRE";
        default:
            return "UNKNOWN";
    }
}

int FnVCCB_CompAndPushCallInfo(callInfo_type *ptCi, const int enqueueIndex, enumBackupType_type backupType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(enqueueIndex, VCCB_MAX_CALL_CTX_BACKUP_BUFF);

    extDbCallBackupQueueNode_type &node = ENV->redis.callBackupQueue[ptCi->myThreadId].queue[enqueueIndex];

    node.callId = VCCB_GET_DIST_CALL_ID(ptCi->gnbCuUeId);
    node.distCode = VCCB_GET_DIST_CODE(ptCi->gnbCuUeId);
    node.backupType = backupType;
    node.state = ptCi->state;

    if (backupType == BACKUP_TYPE_SET)
    {
        auto &compressedCallInfoBuffer = THREAD_INFO->call[ptCi->myThreadId].buf.compressedCallInfo[enqueueIndex];
        int ret = LZ4_compress_default(
            (char *)ptCi, compressedCallInfoBuffer.data, sizeof(*ptCi), sizeof(compressedCallInfoBuffer.data));
        if (ret <= 0)
        {
            VCCB_PRINTF("[Redis DB] Lz4 Compress is failed(callInfo_type)\n");

            return ERROR;
        }
        // return the number of bytes written into node of return 0 if compression fails
        node.len = ret;
        node.callThreadId = ptCi->myThreadId;
        node.bufferIndex = enqueueIndex;
    }
    return GOOD;
}

int FnVCCB_EnqueueRedisCallQ(callInfo_type *ptCi, enumBackupType_type backupType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    auto &callBackupQueue = ENV->redis.callBackupQueue[ptCi->myThreadId];

    if (DBG->flag.extDbDbug == TRUE)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "EnqueueRedisCallQ %s\n", FnVCCB_GetBackUpTypeStr(backupType));
    }

    int32_t enqueue_Idx = (callBackupQueue.rearIdx + 1) % VCCB_MAX_CALL_CTX_BACKUP_BUFF;
    if (DBG->flag.extDbTestFlag == TRUE)
    {
        // ExtDb TestMode
        return GOOD;
    }
    if (is_queue_full(ptCi->myThreadId))
    {
        callBackupQueue.queueOverCnt++;
        // VCCB_PRINTF("[Redis DB][CallQ] EXT DB CMD QUEUE IS FULL!!(threadNum : %u backupType : %s)\n", ptCi->myThreadId,
        //     FnVCCB_GetBackUpTypeStr(backupType));
        if (callBackupQueue.qFullCnt > VCCB_MAX_CALL_CTX_BUFF_Q_FULL)
        {
            VCCB_PRINT_DATA("[Redis DB][CallQ] %d threads Ext Db Queue is Flushed\n", ptCi->myThreadId);
            FnVCCB_InitCallQ(ptCi->myThreadId);
            callBackupQueue.flushedCnt++;
        }
        else
        {
            callBackupQueue.qFullCnt++;
            return ERROR;
        }
        callBackupQueue.qFullCnt = 0;
        return ERROR;
    }
    if (callBackupQueue.qFullCnt != 0)
    {
        callBackupQueue.qFullCnt = 0;
    }

    if (ERROR == FnVCCB_CompAndPushCallInfo(ptCi, enqueue_Idx, backupType))
    {
        VCCB_PRINTF("[Redis DB][CallQ] Enqueue ExtDB CMD FAIL!\n");
        return ERROR;
    }
    callBackupQueue.rearIdx = enqueue_Idx;

    if (callBackupQueue.maxEnqueueCnt < FnVCCB_GetQueueSize(ptCi->myThreadId))
    {
        callBackupQueue.maxEnqueueCnt = FnVCCB_GetQueueSize(ptCi->myThreadId);
    }
    return GOOD;
}

extDbCallBackupQueueNode_type *FnVCCB_DequeueRedisCallQ(uint16_t threadId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_NULL(threadId, MAX_CALL_THREAD_NUM_VCCB);
    auto &callBackupQueue = ENV->redis.callBackupQueue[threadId];

    if (is_queue_empty(threadId))
    {
        return NULL;
    }
    MUTEX_LOCK(&callBackupQueue.callQueueMutex);
    int32_t dequeue_idx = (callBackupQueue.frontIdx + 1) % VCCB_MAX_CALL_CTX_BACKUP_BUFF;
    callBackupQueue.frontIdx = dequeue_idx;
    MUTEX_UNLOCK(&callBackupQueue.callQueueMutex);

    return &callBackupQueue.queue[dequeue_idx];
}
#endif
