#include "ComPrint.h"

#include "ComInline.h"
#include "ComLogUtility.hpp"

#include "StateCommon.h"

#define LOCAL_LOG_BUF_LEN     1024
#define LOCAL_LOG_BUF_BIG_LEN 4096
#define LOCAL_LOG_BUF_SUB_LEN 975

#define MACRO_VS_N_PRINTF(__logBuf, __bufSize, __length, __fmt, __ret)  \
    do                                                                  \
    {                                                                   \
        int __setNullIdx = 0;                                           \
        va_list __argPtr;                                               \
        va_start(__argPtr, __fmt);                                      \
        __length = vsnprintf(__logBuf, __bufSize, __fmt, __argPtr);     \
        va_end(__argPtr);                                               \
        if (__length < 0)                                               \
        {                                                               \
            __ret;                                                      \
        }                                                               \
        else if (0 <= __length && __length < (int)__bufSize)            \
        {                                                               \
            __setNullIdx = __length;                                    \
        }                                                               \
        else                                                            \
        {                                                               \
            __setNullIdx = (__bufSize - 1);                             \
            __length = __bufSize;                                       \
        }                                                               \
        __logBuf[__setNullIdx] = 0;                                     \
    } while (0)

#define GET_LOG_LEVEL(__printLevel) (0x00FF & __printLevel)

#ifdef IPC_TEST
#define VCCB_DUS_PRINT(__blkName, __level, ...) printf(__VA_ARGS__)
#else
#define VCCB_DUS_PRINT(__blkName, __level, ...) dusPrint(__blkName, __level, __VA_ARGS__)
#endif

/*
    Util
*/
static inline int FnVCCB_GetCallId(const callInfo_type *const ptCi) { return IS_VALID_PTCI(ptCi) ? (int)ptCi->callId : -1; }

/*
    Checker :: It is used to check whether output is possible in the current state.
*/

// dusPrint
static inline bool FnVCCB_IsActiveDusPrint(const int printLevel)
{
    auto &dbg = *DBG;
    auto &dbgLog = dbg.log;

    const uint16_t level = GET_LOG_LEVEL(printLevel);

    if ((level != NO_HDR_PL_CMD) &&
        ((dbgLog.logCtlMask & NO_VCCB_LOG_DSH_PRINT) || (level % NO_HDR_PL_CMD) > dbg.localLevel))
    {
        return false;
    }

    return true;
}

// logShmStr
static inline bool FnVCCB_IsActiveLogShmStr(const int printLevel)
{
    const uint16_t level = GET_LOG_LEVEL(printLevel);

    auto &dbgLog = DBG->log;

    if (!(dbgLog.logCtlMask & NO_VCCB_LOG_ITSCP_PRINT) && (dbgLog.logStoreDebugTrace == 0) &&
        (dbgLog.logStoreDebugLevel >= level))
    {
        return true;
    }

    return false;
}

// logShmStrDetail
static inline bool FnVCCB_IsActiveLogShmStrDetail()
{
    auto &dbgLog = DBG->log;

    if (!(dbgLog.logCtlMask & NO_VCCB_LOG_ITSCP_PRINT))
    {
        return true;
    }

    return false;
}

// logShmStrCall
static inline bool FnVCCB_IsActiveLogShmStrCall(const int printLevel, const uint8_t debugTrace)
{
    auto &dbgLog = DBG->log;

    const uint16_t level = GET_LOG_LEVEL(printLevel);

    if (((dbgLog.logStoreDebugTrace && debugTrace) || !(dbgLog.logStoreDebugTrace)) &&
        (level <= dbgLog.logStoreDebugLevel))
    {
        return true;
    }

    return false;
}

/**
 * @brief     This function provides printing for the UE.
 * @param     ptCi : call context pointer
 * @param     file : file name
 * @param     line : line number
 * @param     level : print level
 * @param     fmt : formatted contents
 */
void FnVCCB_UeBasedPrint(const callInfo_type *ptCi, const char *file, const int line, const int level, const int isCrrLogging,
    const char *fmt, ...)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, fmt);

    if (DBG->flag.fdebug_msg != YES)
    {
        return;
    }

    const bool isActiveDusPrint = FnVCCB_IsActiveDusPrint(level);
    const bool isActiveLogShmStrCall = FnVCCB_IsActiveLogShmStrCall(level, ptCi->debugTrace);

    /* If dus debug and shmLog debug are disabled, return */
    if (isActiveDusPrint == false && isActiveLogShmStrCall == false)
    {
        return;
    }

    int length = 0;
    char LogBufSub[LOCAL_LOG_BUF_SUB_LEN];

    MACRO_VS_N_PRINTF(LogBufSub, sizeof(LogBufSub), length, fmt, return);

    if (isActiveDusPrint == true)
    {
        if (file != NULL)
        {
            VCCB_DUS_PRINT(VCCB_BLK_NAME, level, "[%6d] %4d[%18s %5d] %s", FnVCCB_GetCallId(ptCi), ptCi->servCellNum, FnVCCB_GetFileName(file),
                line, LogBufSub);
        }
        else
        {
            VCCB_DUS_PRINT(VCCB_BLK_NAME, level, "[%6d] %4d %s", FnVCCB_GetCallId(ptCi), ptCi->servCellNum, LogBufSub);
        }
    }

    // Store to SHM Log.
    if (isActiveLogShmStrCall == true)
    {
        logShmStrCall(ptCi, (uint8_t)level, (uint32_t)length, (uint8_t *)LogBufSub, (uint8_t)isCrrLogging);
    }
}

static inline bool FnVCCB_IsPrintCase_iPrintWithDebug(const callInfo_type *ptCi, const bool debugFlag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // When Debug Mode is On
    if (debugFlag == true) return true;

    // When a specific UE Trace is On
    if (ptCi->debugTrace == VCCB_FLAG_ON) return true;

    return false;
}

/**
 * @brief     This function provides printing for the UE.
 * @param     ptCi : call context pointer
 * @param     file : file name
 * @param     line : line number
 * @param     level : print level
 * @param     debugFlag : debug flag
 * @param     fmt : formatted contents
 */
void FnVCCB_UeBasedPrintWithDebug(const callInfo_type *ptCi, const char *pFuncName, const char *pFileName, const int line,
    const int level, const bool debugFlag, const char *fmt, ...)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM3(ptCi, pFuncName, pFileName);
    VALID_E_POINT_CHECK_VOID(fmt);

    uint16_t printLevel = (uint16_t)level;

    // 1. Print Level Decision
    {
        if (FnVCCB_IsPrintCase_iPrintWithDebug(ptCi, debugFlag) == true)
        {
            // Change Print Level From 'VCCB_PRINT_CALL_COMMENT' To 'VCCB_PRINT_CALL_ERROR'
            printLevel = PL_ERROR;
        }
    }

    // 2. Not Valid Print Level Ignore
    if (printLevel > PL_UNKNOWN)
    {
        return;
    }

    int length = 0;
    char printBuffer[LOCAL_LOG_BUF_LEN];

    // 3. Fill Local Buffer
    {
        MACRO_VS_N_PRINTF(printBuffer, sizeof(printBuffer), length, fmt, return);
    }

    // 4. Print Log
    FnVCCB_UeBasedPrint(ptCi, FnVCCB_GetFileName(pFileName), line, printLevel, FALSE, printBuffer);
    utilEGput(1, pFuncName, pFileName, line);
}

/**
 * @brief     This function provides printing for the UE with MSC-GEN.
 * @param     ptCi : call context pointer
 * @param     level : print level
 * @param     fmt : formatted contents
 */
void FnVCCB_UeBasedPrintWithMscGen(const VccbDbgLog_type &dbgLog, const callInfo_type *ptCi, const int level, const char *fmt, ...)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, fmt);

    int length = 0;
    char LogBufSub[LOCAL_LOG_BUF_SUB_LEN];

    MACRO_VS_N_PRINTF(LogBufSub, sizeof(LogBufSub), length, fmt, return);

    logShmMscGenStr(dbgLog, ptCi, (uint8_t)level, (uint32_t)length, (uint8_t *)LogBufSub);
}

/**
 * @brief     call based Print function
 * @param     blkName : block name
 * @param     level : print level
 */
void iPRINTF(const callInfo_type *ptCi, const int level, const char *fmt, ...)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, fmt);

    const bool isActiveDusPrint = FnVCCB_IsActiveDusPrint(level);

    if (isActiveDusPrint == false)
    {
        return;
    }

    int length = 0;
    char logBuf[LOCAL_LOG_BUF_LEN];

    MACRO_VS_N_PRINTF(logBuf, sizeof(logBuf), length, fmt, return);

    // always true
    // if (isActiveDusPrint == true)
    {
        VCCB_DUS_PRINT(VCCB_BLK_NAME, level, "%4d, %d%s", FnVCCB_GetCallId(ptCi), ptCi->servCellNum, logBuf);
    }
}

/**
 * @brief     This function provides printing for the Non-UE.
 * @param     file : file name
 * @param     level : print level
 */
void FnVCCB_NonUeBasedPrint(const char *file, const int line, const int level, const char *fmt, ...)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(file, fmt);

    const bool isActiveDusPrint = FnVCCB_IsActiveDusPrint(level);
    const bool isActiveLogShmStr = FnVCCB_IsActiveLogShmStr(level);

    if (isActiveDusPrint == false && isActiveLogShmStr == false) return;

    int length = 0;
    char logBuf[LOCAL_LOG_BUF_LEN];

    {
        char logSubBuf[LOCAL_LOG_BUF_SUB_LEN];

        MACRO_VS_N_PRINTF(logSubBuf, sizeof(logSubBuf), length, fmt, return);

        length = snprintf(logBuf, sizeof(logBuf), "   [%18s %5d] %s", FnVCCB_GetFileName(file), line, logSubBuf);
        if (!(0 <= length && length < (int)sizeof(logBuf)))
        {
            length = (sizeof(logBuf) - 1);
        }
        logBuf[length] = 0;
    }

    if (isActiveDusPrint == true)
    {
        VCCB_DUS_PRINT(VCCB_BLK_NAME, level, "%s", logBuf);
    }

    if (isActiveLogShmStr == true)
    {
        if ((length) < SHM_LOG_BRIEF_LEN)
        {
            logBuf[length] = 0;
            logShmStr((uint8_t)level, (uint32_t)(length + 1), (uint8_t *)logBuf);
        }
        else
        {
            logBuf[SHM_LOG_BRIEF_LEN - 2] = '\n';
            logBuf[SHM_LOG_BRIEF_LEN - 1] = 0;
            logShmStr((uint8_t)level, SHM_LOG_BRIEF_LEN, (uint8_t *)logBuf);
        }
    }
}

/**
 * @brief     Print function
 * @param     level : print level
 */
void iPRINTNF(const int level, const char *fmt, ...)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(fmt);

    if (!DBG->flag.fdebug_msg)
    {
        return;
    }

    const bool isActiveDusPrint = FnVCCB_IsActiveDusPrint(level);

    if (isActiveDusPrint == false)
    {
        return;
    }

    int length = 0;
    char logBuf[LOCAL_LOG_BUF_LEN];

    MACRO_VS_N_PRINTF(logBuf, sizeof(logBuf), length, fmt, return);

    // always true
    // if (isActiveDusPrint == true)
    {
        VCCB_DUS_PRINT(VCCB_BLK_NAME, level, "       %s", logBuf);
    }
}

/**
 * @brief     Print function without header format
 */
void iPRINTNH(const char *fmt, ...)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(fmt);

    const int level = NO_HDR_PL_CMD;
    const bool isActiveDusPrint = FnVCCB_IsActiveDusPrint(level);

    if (isActiveDusPrint == false)
    {
        return;
    }

    int length = 0;
    char logBuf[LOCAL_LOG_BUF_LEN];

    MACRO_VS_N_PRINTF(logBuf, sizeof(logBuf), length, fmt, return);

    // always true
    // if (isActiveDusPrint == true)
    {
        VCCB_DUS_PRINT(VCCB_BLK_NAME, level, "%s", logBuf);
    }
}

/**
 * @brief     This function provides printing for the ASN.
 */
int FnVCCB_AsnPrint(const char *fmt, ...)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(fmt);

    const int level = PL_ERROR;
    const bool isActiveDusPrint = FnVCCB_IsActiveDusPrint(level);

    int length = 0;
    char logBuf[LOCAL_LOG_BUF_BIG_LEN];

    MACRO_VS_N_PRINTF(logBuf, sizeof(logBuf), length, fmt, return -1);

    if (isActiveDusPrint == true)
    {
        VCCB_DUS_PRINT(VCCB_BLK_NAME, level, "%s", logBuf);
    }

    if (length < SHM_LOG_BRIEF_LEN)
    {
        if (FnVCCB_IsActiveLogShmStr(0) == true)
        {
            logShmStr(0, (uint32_t)length, (uint8_t *)logBuf);
        }
    }
    else
    {
        if (FnVCCB_IsActiveLogShmStrDetail() == true)
        {
            logShmStrDetail(SHM_LOG_BRIEF_LEN, (uint8_t *)logBuf, (uint32_t)length, (uint8_t *)logBuf);
        }
    }

#ifdef VCCB_IPC_TEST // For ASN Error Debug In GTEST.
    printf("[ASN] %.*s\n", length, logBuf);
#endif

    return length;
}

/**
 * @brief     This function provides write to buffer.
 */
void FnVCCB_BufferPrint(
    char *pLogBuf, int LogBufMaxSize, int *pLogBufUseSize /*Last Write Index For Append*/, const char *fmt, ...)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM3(pLogBuf, pLogBufUseSize, fmt);

    va_list argPtr;
    int length;

    char *pWritePointer = pLogBuf + *pLogBufUseSize;
    const int limitLen = LogBufMaxSize - *pLogBufUseSize;

    VCCB_CHECK_E_RANGE_AND_VOID(*pLogBufUseSize, LogBufMaxSize);

    va_start(argPtr, fmt);
    length = vsnprintf(pWritePointer, (size_t)limitLen, fmt, argPtr);
    va_end(argPtr);

    *pLogBufUseSize += length;
}

/**
 * @brief This function prints the Ue History Handling information in the log.
 * 
 * @param ptCi Pointer to callInfo_type structure.
 * @param fmt Format string.
 */
void FnVCCB_UeHistoryHandlingPrint(callInfo_type *ptCi, const char *fmt, ...)
{
    int length = 0;
    char printBuffer[LOCAL_LOG_BUF_LEN];

    MACRO_VS_N_PRINTF(printBuffer, sizeof(printBuffer), length, fmt, return);

    VCCB_PRINT_CALL_ERROR(ptCi, "[UHI-S, %s] %s", FnVCCB_GetUeTypeString(ptCi), printBuffer);

    VCCB_PRINT_CALL_MSCGEN_INFORMATIVE(ptCi, "(UHI-S, %s) %s", FnVCCB_GetUeTypeString(ptCi), printBuffer);
}