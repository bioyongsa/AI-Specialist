/**
 * @file        ComLibRsc.c
 * @brief       functions for RSC
 */
/*----------------------------------------------------------------------------
 * Define    :    Include Header Files
 * ---------------------------------------------------------------------------
 */
#include "ComLibRsc.h"
#include "ComGlobalData.h"
#include "ComAutoNtrace.hpp"
#include "ComLibIpcApi.h"
#include "ComLibUtility.h"
#include "ComLibStatistic.h"
#include "ComTimeUtil.h"
#include "RscProto.h"
#include "FeatRbInfo.h"

uint8_t FnVCCB_GetSliceStatIndexFromYangWithDrb(callInfo_type &rCall, callDRBInfo_type &rDrb)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VAL(rCall.gnbNum, MAX_GNB_PER_SYS, MAX_SLICE_STAT_YANG);
    VCCB_CHECK_E_RANGE_AND_VAL(rDrb.pduIdxInCall, MAX_PDU_SESS_PER_CALL, MAX_SLICE_STAT_YANG);

    uint8_t plmnIndex = 0;
    uint32_t sstSdVal = 0;

    const VccbGnbInfo_type *const pGnb = &GNBINFO[rCall.gnbNum];
    sstSdVal = rCall.pduSess[rDrb.pduIdxInCall].sNssai.sstSd;

    for (uint8_t sliceDbIdx = 0; sliceDbIdx < MAX_SLICE_STAT_YANG; sliceDbIdx++)
    {
        if (pGnb->sliceStatCounterList[sliceDbIdx].usage != EQUIP) continue;

        plmnIndex = pGnb->sliceStatCounterList[sliceDbIdx].plmnIndex;
        if (plmnIndex < MAX_PLMN_INDEX)
        {
            const plmnIdInfo_type *pGnbPlmn = &pGnb->plmnIndexInfo[plmnIndex];
            if (pGnbPlmn->shmStatus != EQUIP) continue;

            // If plmn & slice is matched, then return index
            if ((pGnbPlmn->longId == rCall.ueInfo.servedPlmn.longId) &&
                (pGnb->sliceStatCounterList[sliceDbIdx].sNssai.sstSd == sstSdVal))
            {
                return sliceDbIdx;
            }
        }
    }

    return MAX_SLICE_STAT_YANG;
}

int8_t FnVCCB_GetSliceStatValueFromYangWithDrb(callInfo_type &rCall, callDRBInfo_type &rDrb, uint32_t &rSstSdVal)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(rCall.gnbNum, MAX_GNB_PER_SYS);

    uint8_t sliceIdx = FnVCCB_GetSliceStatIndexFromYangWithDrb(rCall, rDrb);
    if (IS_VALID_SLICE_STAT_YANG_INDEX(sliceIdx))
    {
        const VccbGnbInfo_type *const pGnb = &GNBINFO[rCall.gnbNum];

        rSstSdVal = pGnb->sliceStatCounterList[sliceIdx].sNssai.sstSd;
        return GOOD;
    }

    return BREAK;
}

void FnVCCB_DelCellDrbCountWithMarkedInfoOfSaRrcConn(callInfo_type *ptCi, uint16_t drbIdxInCall)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdxInCall, MAX_DRB_PER_SA_CALL);

    uint8_t prev5Qi;
    uint16_t prevCellNum;
    uint8_t prevPlmnIdx;
    uint8_t redCapUe;
    uint8_t prevSliceIdx;

    if ((ptCi->callType != E_CALLTYPE_SA) || IS_NRDC_SN(ptCi))
    {
        return;
    }

    callDRBInfo_type *ptDi = &ptCi->drb[drbIdxInCall];
    if (ptDi->drbConnStat.drbCountFlagOfRrcConn != FLAG_ON)  // Call Count collected already.
    {
        return;
    }

    // Get Saved 5Qi
    prevCellNum = ptDi->drbConnStat.markedCellNumForDrbConnStatOfRrcConn;
    prev5Qi = ptDi->drbConnStat.marked5qiForDrbConnStatOfRrcConn;
    prevPlmnIdx = ptDi->drbConnStat.markedPlmnIdxForDrbConnStatOfRrcConn;
    redCapUe = ptDi->drbConnStat.drbCountFlagOfRedCapRrcConn;
    prevSliceIdx = ptDi->drbConnStat.markedSliceIdxForDrbConnStatOfRrcConn;

    VCCB_CHECK_E_RANGE_AND_VOID(prevCellNum, MAX_CELL_NUM_VCCB);
    // Always True..
    // VCCB_CHECK_E_RANGE_AND_VOID(prev5Qi, MAX_5QI_VALUE);

    VccbCellInfo_type* const pCell = &CELLINFO[prevCellNum];
    // Mutex Start >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[prevCellNum]);

    // 1. DRB 5Qi
    if (redCapUe)
    {
        if (VCCB_FLAG_ON == DBG->flag.logRedCap)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "assignedRedCapDrbCount5Qi[%d]RrcConn--(CellNum=%d)\n", prev5Qi, prevCellNum);
        }
    }
    else
    {
        if (pCell->cfg.assignedDrbCount5QiRrcConn[prev5Qi] > 0) pCell->cfg.assignedDrbCount5QiRrcConn[prev5Qi]--;
    }

    // 2. DRB 5Qi with Multi-Plmn (20C)
    if (IS_VALID_PLMNNUM(prevPlmnIdx))
    {
        if (redCapUe)
        {
            if (pCell->cfg.assignedRedCapDrbCount5QiWithPlmnRrcConn[prev5Qi][prevPlmnIdx] > 0)
            {
                pCell->cfg.assignedRedCapDrbCount5QiWithPlmnRrcConn[prev5Qi][prevPlmnIdx]--;
                if (VCCB_FLAG_ON == DBG->flag.logRedCap)
                {
                    VCCB_PRINT_CALL_COMMENT(ptCi, "assignedRedCapDrbCount5Qi[%d]WithPlmn[%d]RrcConn--(CellNum=%d, Count=%d)\n)",
                        prev5Qi, prevPlmnIdx, prevCellNum,
                        pCell->cfg.assignedRedCapDrbCount5QiWithPlmnRrcConn[prev5Qi][prevPlmnIdx]);
                }
            }
        }
        else
        {
            if (pCell->cfg.assignedDrbCount5QiWithPlmnRrcConn[prev5Qi][prevPlmnIdx] > 0)
                pCell->cfg.assignedDrbCount5QiWithPlmnRrcConn[prev5Qi][prevPlmnIdx]--;
        }
    }

    // 3. DRB with PLMN-Slice (26A)
    if (IS_VALID_SLICE_STAT_YANG_INDEX(prevSliceIdx))
    {
        if (pCell->cfg.assignedDrbCountWithPlmnSliceRrcConn[prevSliceIdx] > 0)
            pCell->cfg.assignedDrbCountWithPlmnSliceRrcConn[prevSliceIdx]--;
    }

    VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[prevCellNum]);
    // Mutex End <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    ptDi->drbConnStat.drbCountFlagOfRrcConn = FLAG_OFF;
    // DRB Holding Time is handled in VLIB_FreeCallDrbInfoUnderPdu()

    // No need to Consider Redundancy.

    return;
}

void FnVCCB_DelCellDrbCountWithMarkedInfoOfSaRrcInact(callInfo_type *ptCi, uint16_t drbIdxInCall)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdxInCall, MAX_DRB_PER_SA_CALL);

    uint8_t prev5Qi;
    uint16_t prevCellNum;
    uint8_t prevPlmnIdx;
    uint8_t redCapUe;
    uint8_t prevSliceIdx;

    if ((ptCi->callType != E_CALLTYPE_SA) || IS_NRDC_SN(ptCi))
    {
        return;
    }

    callDRBInfo_type *ptDi = &ptCi->drb[drbIdxInCall];
    if (ptDi->drbConnStat.drbCountFlagOfRrcInact != FLAG_ON)  // Call Count collected already.
    {
        return;
    }

    // Get Saved 5Qi
    prevCellNum = ptDi->drbConnStat.markedCellNumForDrbConnStatOfRrcInact;
    prev5Qi = ptDi->drbConnStat.marked5qiForDrbConnStatOfRrcInact;
    prevPlmnIdx = ptDi->drbConnStat.markedPlmnIdxForDrbConnStatOfRrcInact;
    redCapUe = ptDi->drbConnStat.drbCountFlagOfRedCapRrcInact;
    prevSliceIdx = ptDi->drbConnStat.markedSliceIdxForDrbConnStatOfRrcInact;

    VCCB_CHECK_E_RANGE_AND_VOID(prevCellNum, MAX_CELL_NUM_VCCB);
    // Always True..
    // VCCB_CHECK_E_RANGE_AND_VOID(prev5Qi, MAX_5QI_VALUE);

    VccbCellInfo_type* const pCell = &CELLINFO[prevCellNum];
    // Mutex Start >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[prevCellNum]);
    // 1. DRB 5Qi
    if (redCapUe)
    {
        if (VCCB_FLAG_ON == DBG->flag.logRedCap)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "assignedRedCapDrbCount5Qi[%d]RrcInact--(CellNum=%d)\n", prev5Qi, prevCellNum);
        }
    }
    else
    {
        if (pCell->cfg.assignedDrbCount5QiRrcInact[prev5Qi] > 0)
        {
            pCell->cfg.assignedDrbCount5QiRrcInact[prev5Qi]--;
        }
    }

    // 2. DRB 5Qi with Multi-Plmn (20C)
    if (IS_VALID_PLMNNUM(prevPlmnIdx))
    {
        if (redCapUe)
        {
            if (pCell->cfg.assignedRedCapDrbCount5QiWithPlmnRrcInact[prev5Qi][prevPlmnIdx] > 0)
            {
                pCell->cfg.assignedRedCapDrbCount5QiWithPlmnRrcInact[prev5Qi][prevPlmnIdx]--;
                if (VCCB_FLAG_ON == DBG->flag.logRedCap)
                {
                    VCCB_PRINT_CALL_COMMENT(ptCi, "assignedRedCapDrbCount5Qi[%d]WithPlmn[%d]RrcInact--(CellNum=%d, Count=%d)\n", 
                        prev5Qi, prevPlmnIdx, prevCellNum,
                        pCell->cfg.assignedRedCapDrbCount5QiWithPlmnRrcInact[prev5Qi][prevPlmnIdx]);
                }
            }
        }
        else
        {
            if (pCell->cfg.assignedDrbCount5QiWithPlmnRrcInact[prev5Qi][prevPlmnIdx] > 0)
                pCell->cfg.assignedDrbCount5QiWithPlmnRrcInact[prev5Qi][prevPlmnIdx]--;
        }
    }

    // 3. DRB with PLMN-Slice (26A)
    if (IS_VALID_SLICE_STAT_YANG_INDEX(prevSliceIdx))
    {
        pCell->cfg.assignedDrbCountWithPlmnSliceRrcInact[prevSliceIdx]++;
    }

    VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[prevCellNum]);
    // Mutex End <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    ptDi->drbConnStat.drbCountFlagOfRrcInact = FLAG_OFF;
    ptDi->drbConnStat.drbCountFlagOfRedCapRrcInact = FLAG_OFF;

    // DRB Holding Time is handled in VLIB_FreeCallDrbInfoUnderPdu()
    // No need to Consider Redundancy.

    return;
}

void FnVCCB_AddCellDrbCountOfSaRrcConn(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdxInCall)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdxInCall, MAX_DRB_PER_SA_CALL);

    uint8_t selected5Qi;
    uint16_t qosIdxInCall;
    uint8_t plmnIdx;
    uint8_t sliceIdx = MAX_SLICE_STAT_YANG;

    if ((ptCi->callType != E_CALLTYPE_SA) || IS_NRDC_SN(ptCi))
    {
        return;
    }

    callDRBInfo_type *ptDi = &ptCi->drb[drbIdxInCall];
    if (ptDi->drbConnStat.drbCountFlagOfRrcConn == FLAG_ON)  // Call Count collected already.
    {
        return;
    }

    // Get selected 5Qi
    qosIdxInCall = ptDi->drbQosIdxInCall;
    VCCB_CHECK_E_RANGE_AND_VOID(qosIdxInCall, MAX_QOS_FLOW_PER_CALL);

    VLIB_getFiveQi(&ptCi->qosFlow[qosIdxInCall], &selected5Qi);
    plmnIdx = VLIB_findCellPlmnIndex(cellNum, ptCi->ueInfo.servedPlmn.longId);
    if (FOO.VF_ConnInfoPlmnSnssaiCounterConfig)
    {
        sliceIdx = FnVCCB_GetSliceStatIndexFromYangWithDrb(*ptCi, *ptDi);
    }

    // Always True..
    // VCCB_CHECK_E_RANGE_AND_VOID(selected5Qi, MAX_5QI_VALUE);

    VccbCellInfo_type* const pCell = &CELLINFO[cellNum];
    // Mutex Start >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[cellNum]);

    // 1. DRB 5Qi
    if (IS_REDCAP_UE(ptCi))
    {
        if (VCCB_FLAG_ON == DBG->flag.logRedCap)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "assignedRedCapDrbCount5Qi[%d]RrcConn++(CellNum=%d)\n", selected5Qi, cellNum);
        }
    }
    else
        pCell->cfg.assignedDrbCount5QiRrcConn[selected5Qi]++;

    // 2. DRB 5Qi with Multi-Plmn (20C)
    if (IS_VALID_PLMNNUM(plmnIdx))
    {
        if (IS_REDCAP_UE(ptCi))
        {
            pCell->cfg.assignedRedCapDrbCount5QiWithPlmnRrcConn[selected5Qi][plmnIdx]++;
            if (VCCB_FLAG_ON == DBG->flag.logRedCap)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "assignedRedCapDrbCount5Qi[%d]WithPlmn[%d]RrcConn++(CellNum=%d, Count=%d)\n",
                    selected5Qi, plmnIdx, cellNum, pCell->cfg.assignedRedCapDrbCount5QiWithPlmnRrcConn[selected5Qi][plmnIdx]);
            }
        }
        else
            pCell->cfg.assignedDrbCount5QiWithPlmnRrcConn[selected5Qi][plmnIdx]++;
    }

    // 3. DRB with PLMN-Slice (26A)
    if (IS_VALID_SLICE_STAT_YANG_INDEX(sliceIdx))
    {
        pCell->cfg.assignedDrbCountWithPlmnSliceRrcConn[sliceIdx]++;
    }

    VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[cellNum]);
    // Mutex End <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    ptDi->drbConnStat.markedCellNumForDrbConnStatOfRrcConn = cellNum;
    ptDi->drbConnStat.marked5qiForDrbConnStatOfRrcConn = selected5Qi;
    ptDi->drbConnStat.markedPlmnIdxForDrbConnStatOfRrcConn = plmnIdx;
    ptDi->drbConnStat.markedSliceIdxForDrbConnStatOfRrcConn = sliceIdx;
    ptDi->drbConnStat.drbCountFlagOfRrcConn = FLAG_ON;
    ptDi->drbConnStat.drbCountFlagOfRedCapRrcConn = IS_REDCAP_UE(ptCi);

    // No need to Consider Redundancy.
    return;
}

void FnVCCB_AddCellDrbCountOfSaRrcInact(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdxInCall)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdxInCall, MAX_DRB_PER_SA_CALL);

    uint8_t selected5Qi;
    uint16_t qosIdxInCall;
    uint8_t plmnIdx;
    uint8_t sliceIdx = MAX_SLICE_STAT_YANG;

    if ((ptCi->callType != E_CALLTYPE_SA) || IS_NRDC_SN(ptCi))
    {
        return;
    }

    callDRBInfo_type *ptDi = &ptCi->drb[drbIdxInCall];
    if (ptDi->drbConnStat.drbCountFlagOfRrcInact == FLAG_ON)  // Call Count collected already.
    {
        return;
    }

    // Get selected 5Qi
    qosIdxInCall = ptDi->drbQosIdxInCall;
    VCCB_CHECK_E_RANGE_AND_VOID(qosIdxInCall, MAX_QOS_FLOW_PER_CALL);

    VLIB_getFiveQi(&ptCi->qosFlow[qosIdxInCall], &selected5Qi);
    plmnIdx = VLIB_findCellPlmnIndex(cellNum, ptCi->ueInfo.servedPlmn.longId);
    if (FOO.VF_ConnInfoPlmnSnssaiCounterConfig)
    {
        sliceIdx = FnVCCB_GetSliceStatIndexFromYangWithDrb(*ptCi, *ptDi);
    }


    // Always True..
    // VCCB_CHECK_E_RANGE_AND_VOID(selected5Qi, MAX_5QI_VALUE);

    VccbCellInfo_type* const pCell = &CELLINFO[cellNum];
    // Mutex Start >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[cellNum]);

    // 1. DRB 5Qi
    if (IS_REDCAP_UE(ptCi))
    {
        if (VCCB_FLAG_ON == DBG->flag.logRedCap)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "assignedRedCapDrbCount5Qi[%d]RrcInact++(CellNum=%d)\n", selected5Qi, cellNum);
        }
    }
    else
    {
        pCell->cfg.assignedDrbCount5QiRrcInact[selected5Qi]++;
    }

    // 2. DRB 5Qi with Multi-Plmn (20C)
    if (IS_VALID_PLMNNUM(plmnIdx))
    {
        if (IS_REDCAP_UE(ptCi))
        {
            pCell->cfg.assignedRedCapDrbCount5QiWithPlmnRrcInact[selected5Qi][plmnIdx]++;
            if (VCCB_FLAG_ON == DBG->flag.logRedCap)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi,
                    "assignedRedCapDrbCount5Qi[%d]WithPlmn[%d]RrcInact++(CellNum=%d, Count=%d)\n", selected5Qi, plmnIdx,
                    cellNum, pCell->cfg.assignedRedCapDrbCount5QiWithPlmnRrcInact[selected5Qi][plmnIdx]);
            }
        }
        else
        {
            pCell->cfg.assignedDrbCount5QiWithPlmnRrcInact[selected5Qi][plmnIdx]++;
        }
    }

    // 3. DRB with PLMN-Slice (26A)
    if (IS_VALID_SLICE_STAT_YANG_INDEX(sliceIdx))
    {
        pCell->cfg.assignedDrbCountWithPlmnSliceRrcInact[sliceIdx]++;
    }


    VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[cellNum]);
    // Mutex End <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    ptDi->drbConnStat.markedCellNumForDrbConnStatOfRrcInact = cellNum;
    ptDi->drbConnStat.marked5qiForDrbConnStatOfRrcInact = selected5Qi;
    ptDi->drbConnStat.markedPlmnIdxForDrbConnStatOfRrcInact = plmnIdx;
    ptDi->drbConnStat.markedSliceIdxForDrbConnStatOfRrcInact = sliceIdx;
    ptDi->drbConnStat.drbCountFlagOfRrcInact = FLAG_ON;
    ptDi->drbConnStat.drbCountFlagOfRedCapRrcInact = IS_REDCAP_UE(ptCi);;

    return;
}

/**
 * @brief        Decrement drb counter per cell per qci.
 * @details      This function is used to decrement drb count assigned to one cell.
 * @param [in]   cellNum: cell identifier
 * @param [in]   erabIdx: erab identifier
 * @param [in]   useOldQciFlag: TRUE or FALSE (Decrease CellDrbCount using old QCI value or current QCI value)
 * @return       GOOD, ERROR
 * @date         2017-07-11
 */
void VRRM_delCellDrbCount(callInfo_type *ptCi, uint16_t cellNum, uint16_t erabIdx, int useOldQciFlag)
{
    AUTO_TRACE_FUNC;

    uint16_t qci = 0;
    uint32_t curCallCnt = 0;
    uint32_t newCallCnt = 0;

    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t plmnIdx = VLIB_findCellPlmnIndex(cellNum, ptCi->ueInfo.servedPlmn.longId);

    if (cellNum >= MAX_CELL_NUM_VCCB)
    {
        // VCCB_PRINT_ERROR("VRRM_delCellDrbCount cellNum[%d] out of range!!(callId:%d)\n", cellNum, ptCi->callId);

        return;
    }

    if (erabIdx >= MAX_ERAB_PER_CALL)
    {
        // VCCB_PRINT_ERROR("VRRM_delCellDrbCount erabIdx[%d] out of range!!(callId:%d)\n", erabIdx, ptCi->callId);

        return;
    }

    if (ptCi->erabInfo[erabIdx].callCountFlag == FLAG_OFF)
    {
        return;
    }

    if (useOldQciFlag == TRUE)
    {
        qci = ptCi->erabInfo[erabIdx].erabQos.qciValue.oldQCI;
    }
    else
    {
        qci = ptCi->erabInfo[erabIdx].erabQos.qciValue.QCI;
    }

    if (qci >= MAX_QCI_VALUE)
    {
        VCCB_PRINT_ERROR("VRRM_delCellDrbCount qci[%d] out of range!!(callId:%d)\n", qci, ptCi->callId);

        return;
    }

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[cellNum]);

    if (pCell->cfg.assignedDrbCount[qci] > 0)
    {
        pCell->cfg.assignedDrbCount[qci]--;
    }

    if (E_CALLTYPE_NSA == ptCi->callType)
    {
        if (pCell->cfg.assignedEnDcDrbCount[qci] > 0)
        {
            pCell->cfg.assignedEnDcDrbCount[qci]--;
        }

        if (IS_VALID_PLMNNUM(plmnIdx))
            if (pCell->cfg.assignedEnDcDrbCountWithPlmn[qci][plmnIdx] > 0)
            {
                pCell->cfg.assignedEnDcDrbCountWithPlmn[qci][plmnIdx]--;
            }
    }
    VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[cellNum]);

    if ((TRUE == ptCi->erabInfo[erabIdx].rbInfo.pdcpInfo.headerCompression.ulRohcEnabled) &&
        (TRUE == ptCi->erabInfo[erabIdx].rbInfo.pdcpInfo.headerCompression.useProfile006))
    {
        VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[cellNum]);
        if (pCell->cfg.assignedULOnlyRoHCErabCount[qci] > 0)
        {
            curCallCnt = pCell->cfg.assignedULOnlyRoHCErabCount[qci];

            pCell->cfg.assignedULOnlyRoHCErabCount[qci]--;

            newCallCnt = pCell->cfg.assignedULOnlyRoHCErabCount[qci];
        }
        VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[cellNum]);

        // decrement total DRB count with removed ERAB max_CID count
        if (ptCi->ueInfo.roHCCapability.curAllocatedRohcCid > 0)
        {
            ptCi->ueInfo.roHCCapability.curAllocatedRohcCid =
            (uint16_t)(ptCi->ueInfo.roHCCapability.curAllocatedRohcCid -
                       ptCi->erabInfo[erabIdx].rbInfo.pdcpInfo.headerCompression.ulRohcMaxSession);
        }

        VCCB_PRINT_LOG_ROHC(ptCi,
            "CellDrbCount for QCI[%d] From [%d] => To [%d]/ New Allocated Context sessions %d\t Total "
            "Sessions %d\n",
            qci, curCallCnt, newCallCnt, ptCi->ueInfo.roHCCapability.curAllocatedRohcCid,
            ptCi->erabInfo[erabIdx].rbInfo.pdcpInfo.headerCompression.ulRohcMaxSession);
    }
    ptCi->erabInfo[erabIdx].callCountFlag = FLAG_OFF;

    return;
}
/**
 * @brief This function is to assign RBID & Logical channel ID .
 * @param [in] ptCi : The pointer for the call context.
 * @param [in] ptRi : The pointer for the ERAB context.
 * @param [out] errCause :  The reason why operation fail.
 * @return GOOD : The operation success.
 * @return ERROR : The operation fail.
 * @exception N /A
 */
int VRRM_assignRB(callInfo_type *ptCi, callERABInfo_type *ptRi, uint16_t *errCause)
{
    AUTO_TRACE_FUNC;
    uint8_t index = 0;
    uint32_t allocRbIdMask = 0, allocLochIdMask = 0;
    cellConfig_type *ptCellCfg = NULL;

    if (errCause == NULL)
    {
        VRRM_PRINT(VRRM_ERROR, "[%s   %d] Invalid input parameter(errCause)\n", __FILE__, __LINE__);

        return ERROR;
    }

    if (ptCi == NULL)
    {
        VRRM_PRINT(VRRM_ERROR, "[%s   %d] Invalid input parameter(ptCi)\n", __FILE__, __LINE__);
        *errCause = CauseCpInternalInvalidCallContext;

        return ERROR;
    }

    if (ptRi == NULL)
    {
        VRRM_PRINT(VRRM_ERROR, "[%s   %d] Invalid input parameter(ptRi)\n", __FILE__, __LINE__);
        *errCause = CauseCpInternalInvalidCallContext;

        return ERROR;
    }

    if (ptRi->erabIdx >= MAX_ERAB_PER_CALL)
    {
        VRRM_PRINT(VRRM_ERROR, "[%s   %d] ptRi->erabIdx(=%d) is invalid\n", __FILE__, __LINE__, ptRi->erabIdx);

        *errCause = CauseCpInternalInvalidCallContext;

        return ERROR;
    }

    if (!IS_VALID_CELLNUM(ptCi->servCellNum))
    {
        VRRM_PRINT(VRRM_ERROR, "[%s   %d] Invalid cellNum(%d)\n", __FILE__, __LINE__, ptCi->servCellNum);
        *errCause = CauseCpInternalInvalidCallContext;

        return ERROR;
    }

    if (!IS_VALID_CALLID_VCCB(ptCi->callId))
    {
        VRRM_PRINT(VRRM_ERROR, "[%s   %d] Invalid input parameter(callId = %u)\n", __FILE__, __LINE__, ptCi->callId);
        *errCause = CauseCpInternalInvalidCallContext;

        return ERROR;
    }

    ptCellCfg = &CELLINFO[ptCi->servCellNum].cfg;

    // rbId in (erabInfo==Usage) check
    for (index = 0; index < MAX_ERAB_PER_CALL; index++)
    {
        if (ptCi->erabInfo[index].usage && (ptRi->erabIdx != index) && ptCi->erabInfo[index].rbInfo.rbId < MAX_DRB_ID) //range check to not allow bit shift over allocRbIdMask type length
        {
            allocRbIdMask = allocRbIdMask | ((uint32_t)1 << (ptCi->erabInfo[index].rbInfo.rbId - 1));
        }
    }

    VRRM_PRINT(VRRM_DBGMSG, "[%s   %d] callId[%u]'s allocated rbId List[%u] lochId List[%u]\n", __FILE__, __LINE__,
        ptCi->callId, allocRbIdMask, allocLochIdMask);

    // Is available or Not for allocation RBID & LGCID
    if ((allocRbIdMask == DRBID_FULL_MASK) || (allocLochIdMask == LGCID_FULL_MASK))
    {
        VRRM_PRINT(VRRM_ERROR, "[%s   %d] Allocated RBID was full\n", __FILE__, __LINE__);
        *errCause = CauseCpInternalResourceAllocFail;

        return ERROR;
    }

    // DRB ID Allocation each Allocation Mode
    switch (ptCellCfg->drbAllocMode)
    {
        case descendMode:  // Descending Mode : High ID -> Low ID

            // Allocation DRB ID
            for (index = (MaxDrbId - 1); index > MinDrbId; index--)
            {
                if ((allocRbIdMask & ((uint32_t)1 << index)) == False)
                {
                    ptCi->erabInfo[ptRi->erabIdx].rbInfo.rbId = (uint8_t)(index + 1);
                    break;
                }
            }

            break;

        case otherMode:  // Ascending Mode  : "MinDrbId =3", Low ID -> High ID

            // Allocation DRB ID
            for (index = (MinDrbId + 1); index < MaxDrbId; index++)
            {
                if ((allocRbIdMask & ((uint32_t)1 << index)) == False)
                {
                    ptCi->erabInfo[ptRi->erabIdx].rbInfo.rbId = (uint8_t)(index + 1);
                    break;
                }
            }

            VRRM_PRINT(VRRM_DBGMSG, "[%s   %d] callId[%d]'s allocated rbId[%d]\n", __FILE__, __LINE__, ptCi->callId,
                ptCi->erabInfo[ptRi->erabIdx].rbInfo.rbId);
            break;

        default:  // Ascending Mode : Low ID -> High ID

            // Allocation DRB ID
            for (index = (MinDrbId - 1); index < MaxDrbId; index++)
            {
                if ((allocRbIdMask & ((uint32_t)1 << index)) == False)
                {
                    ptCi->erabInfo[ptRi->erabIdx].rbInfo.rbId = (uint8_t)(index + 1);
                    break;
                }
            }

            VRRM_PRINT(VRRM_DBGMSG, "[%s   %d] callId[%d]'s allocated rbId[%d]\n", __FILE__, __LINE__, ptCi->callId,
                ptCi->erabInfo[ptRi->erabIdx].rbInfo.rbId);
            break;

    }  // End of switch(drbAllocMode)

    return GOOD;
}

/**
 * @brief        Decrement SA drb counter per cell per qci.
 * @details      This function is used to decrement SA drb count assigned to one cell.
 * @param [in]   cellNum: cell identifier
 * @param [in]   drbIdx: drb identifier
 * @param [in]   useOldQciFlag: TRUE or FALSE (Decrease CellDrbCount using old QCI value or current QCI value)
 * @return       GOOD, ERROR
 * @date         2019-12-11
 */
void VRRM_delCellassignedULOnlyRoHCDrbCount(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdx, int useOldQciFlag)
{
    AUTO_TRACE_FUNC;
    (void)useOldQciFlag;

    uint8_t prev5Qi;
    uint16_t prevCellNum;
    uint16_t drbQosIdxInCall;
    uint32_t curCallCnt = 0;
    uint32_t newCallCnt = 0;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (cellNum >= MAX_CELL_NUM_VCCB)
    {
        VCCB_PRINT_ERROR(
            "VRRM_delCellassignedULOnlyRoHCDrbCount cellNum[%d] out of range!!(callId:%d)\n", cellNum, ptCi->callId);

        return;
    }

    if (drbIdx >= MAX_DRB_PER_SA_CALL)
    {
        VCCB_PRINT_ERROR(
            "VRRM_delCellassignedULOnlyRoHCDrbCount drbIdx[%d] out of range!!(callId:%d)\n", drbIdx, ptCi->callId);

        return;
    }

    callDRBInfo_type *ptDi = NULL;
    ptDi = &ptCi->drb[drbIdx];

    if (ptDi->drbConnStat.UlRoHCdrbCountFlagRrcConn != VCCB_FLAG_ON)  // Call Count not collected, no deletion needed.
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "VRRM_delCellassignedULOnlyRoHCDrbCount for drb[%d] already decremented\n", drbIdx);
        return;
    }

    if (CI_use != ptDi->usage)
    {
        VCCB_PRINT_ERROR(
            "VRRM_delCellassignedULOnlyRoHCDrbCount drbIdx[%d] out of range!!(callId:%d)\n", drbIdx, ptCi->callId);

        return;
    }

    // Get Saved 5Qi
    prevCellNum = ptDi->drbConnStat.markedCellNumForUlRoHCDrbRrcConnStat;
    prev5Qi = ptDi->drbConnStat.marked5qiForUlRoHCDrbRrcConnStat;

    VCCB_CHECK_E_RANGE_AND_VOID(prevCellNum, MAX_CELL_NUM_VCCB);
    // Always True..
    //VCCB_CHECK_E_RANGE_AND_VOID(prev5Qi, MAX_5QI_VALUE);

    drbQosIdxInCall = ptDi->drbQosIdxInCall;
    if (drbQosIdxInCall >= MAX_QOS_FLOW_PER_CALL ||
        !IS_VALID_NODE(QOSFLOW_NODE, ptCi, &(ptCi->qosFlow[drbQosIdxInCall])))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "%s representative qosFlow for drbIdx[%d] is invalid!!(callId:%d)\n", __func__, drbIdx, ptCi->callId);

        return;
    }

    /*
    if (useOldQciFlag == TRUE)
    {
        qci = ptCi->erabInfo[drbIdx].erabQos.qciValue.oldQCI;
    }
    else
    {
        qci = ptCi->erabInfo[drbIdx].erabQos.qciValue.QCI;
    }*/

    {
        VccbCellInfo_type *const pCell = &CELLINFO[prevCellNum];

        VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[prevCellNum]);
        if (pCell->cfg.assignedULOnlyRoHCDrbCountRrcConn[prev5Qi] > 0)
        {
            curCallCnt = pCell->cfg.assignedULOnlyRoHCDrbCountRrcConn[prev5Qi];

            pCell->cfg.assignedULOnlyRoHCDrbCountRrcConn[prev5Qi]--;

            newCallCnt = pCell->cfg.assignedULOnlyRoHCDrbCountRrcConn[prev5Qi];
        }
        VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[prevCellNum]);

        // update ROHC Context count availble after DRB deletion
        if (ptCi->ueInfo.roHCCapability.curAllocatedRohcCid > 0)
        {
            ptCi->ueInfo.roHCCapability.curAllocatedRohcCid = 
            (uint16_t)(ptCi->ueInfo.roHCCapability.curAllocatedRohcCid - 
                    ptCi->drb[drbIdx].rbInfo.pdcpInfo.headerCompression.ulRohcMaxSession);
        }    

        ptDi->drbConnStat.UlRoHCdrbCountFlagRrcConn = VCCB_FLAG_OFF;

        VCCB_PRINT_LOG_ROHC(ptCi,
            "assignedULOnlyRoHCDrbCountRrcConn[5qi:%d]-- (CellNum[%d] count:[%d]=>[%d]) / curAllocatedRohcCid %d / Total "
            "Sessions %d\n",
            prev5Qi, prevCellNum, curCallCnt, newCallCnt, ptCi->ueInfo.roHCCapability.curAllocatedRohcCid,
            ptCi->drb[drbIdx].rbInfo.pdcpInfo.headerCompression.ulRohcMaxSession);
    }

    return;
}
/**
 * @brief        Decrement  ULOnlyRoHC call counter per Cell.
 * @details      This function is used to decrement ULOnlyRoHC call count assigned to one Cell.
 * @param [in]   cellNum: subCell identifier
 * @return       GOOD, ERROR
 * @date         2019-09-23
 */
void VRRM_delULOnlyRoHCCellCallCount(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    uint32_t curCallCnt = 0;
    uint32_t newCallCnt = 0;
    uint16_t prevCellNum;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (cellNum >= MAX_CELL_NUM_VCCB)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "VRRM_delULOnlyRoHCCellCallCount cellNum[%d] out of range!!\n", cellNum);
        return;
    }

    if (ptCi->isULOnlyRoHCCall == VCCB_FLAG_OFF)
    {
        return;
    }

    prevCellNum = ptCi->rrcConnStat.markedCellNumForULOnlyRoHCRrcConnStat;
    VCCB_CHECK_E_RANGE_AND_VOID(prevCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type* const pCell = &CELLINFO[prevCellNum];
    VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[prevCellNum]);

    if (ptCi->callType == E_CALLTYPE_SA)
    {
        if (pCell->cfg.assignedULOnlyRoHCCellCallCountSA > 0)
        {
            curCallCnt = pCell->cfg.assignedULOnlyRoHCCellCallCountSA;
            pCell->cfg.assignedULOnlyRoHCCellCallCountSA--;

            newCallCnt = pCell->cfg.assignedULOnlyRoHCCellCallCountSA;
        }
    }
    else
    {
        if (pCell->cfg.assignedULOnlyRoHCCellCallCount > 0)
        {
            curCallCnt = pCell->cfg.assignedULOnlyRoHCCellCallCount;

            pCell->cfg.assignedULOnlyRoHCCellCallCount--;

            newCallCnt = pCell->cfg.assignedULOnlyRoHCCellCallCount;
        }
    }
    VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[prevCellNum]);

    VCCB_PRINT_LOG_ROHC(ptCi, "ULOnlyRoHCCellCount-- (CellNum [%d] Before [%d] => After [%d]) \n", prevCellNum,
        curCallCnt, newCallCnt);

    ptCi->isULOnlyRoHCCall = VCCB_FLAG_OFF;

    return;
}
/**
 * @brief         ULOnlyRoHC SA DRB in Call .
 * @details      This function is used to coutn if there is any SA DRB in with UL only RoHC in call per cell.
 * @param [in]   ptCi
 * @date         2019-12-02
 */
void VRRM_addCellassignedULOnlyRoHCDrbCount(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdx)
{
    AUTO_TRACE_FUNC;

    uint8_t selected5Qi = 0;
    uint16_t drbQosIdxInCall;
    uint32_t curCallCnt = 0;
    uint32_t newCallCnt = 0;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (cellNum >= MAX_CELL_NUM_VCCB)
    {
        VCCB_PRINT_ERROR(
            "VRRM_addCellassignedULOnlyRoHCDrbCount cellNum[%d] out of range!!(callId:%d)\n", cellNum, ptCi->callId);

        return;
    }

    if (drbIdx >= MAX_DRB_PER_SA_CALL)
    {
        VCCB_PRINT_ERROR(
            "VRRM_addCellassignedULOnlyRoHCDrbCount drbIdx[%d] out of range!!(callId:%d)\n", drbIdx, ptCi->callId);

        return;
    }

    callDRBInfo_type *ptDi = NULL;
    ptDi = &ptCi->drb[drbIdx];

    if (CI_use != ptDi->usage)
    {
        VCCB_PRINT_ERROR(
            "VRRM_addCellassignedULOnlyRoHCDrbCount drbIdx[%d] out of range!!(callId:%d)\n", drbIdx, ptCi->callId);

        return;
    }

    if (ptDi->drbConnStat.UlRoHCdrbCountFlagRrcConn == VCCB_FLAG_ON)  // Call Count collected already.
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "VRRM_addCellassignedULOnlyRoHCDrbCount for drbIdx[%d] already collected\n",drbIdx);
        return;
    }

    drbQosIdxInCall = ptDi->drbQosIdxInCall;
    if (drbQosIdxInCall >= MAX_QOS_FLOW_PER_CALL ||
        !IS_VALID_NODE(QOSFLOW_NODE, ptCi, &(ptCi->qosFlow[drbQosIdxInCall])))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "%s representative qosFlow for drbIdx[%d] is invalid!!(callId:%d)\n", __func__, drbIdx, ptCi->callId);

        return;
    }

    VLIB_getFiveQi(&ptCi->qosFlow[drbQosIdxInCall], &selected5Qi);

    if ((ptCi->drb[drbIdx].rbInfo.pdcpInfo.headerCompression.ulRohcEnabled == TRUE) &&
        (ptCi->drb[drbIdx].rbInfo.pdcpInfo.headerCompression.useProfile006 == TRUE))
    {
        // increment ulonlyrohc ue num
        if (ptCi->isULOnlyRoHCCall == VCCB_FLAG_ON)
        {
            // Compare new values with marked value.
            // If Diff, then del/add cell call count.
            if(ptCi->rrcConnStat.markedCellNumForULOnlyRoHCRrcConnStat != cellNum)
            {
                VRRM_delULOnlyRoHCCellCallCount(ptCi, cellNum);
                VRRM_addULOnlyRoHCCellCallCount(ptCi, cellNum);
            }         
        }
        else
        {
            VRRM_addULOnlyRoHCCellCallCount(ptCi, cellNum);
        }

        VccbCellInfo_type* const pCell = &CELLINFO[cellNum];
        VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[cellNum]);

        curCallCnt = pCell->cfg.assignedULOnlyRoHCDrbCountRrcConn[selected5Qi];

        pCell->cfg.assignedULOnlyRoHCDrbCountRrcConn[selected5Qi]++;

        newCallCnt = pCell->cfg.assignedULOnlyRoHCDrbCountRrcConn[selected5Qi];
        VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[cellNum]);

        VCCB_PRINT_LOG_ROHC(ptCi, "assignedULOnlyRoHCDrbCountRrcConn[5qi:%d]++ (CellNum[%d] count:[%d]=>[%d]) \n", selected5Qi, cellNum,
            curCallCnt, newCallCnt);
        // Increment the ROHC allocated Sessions on every DRB addition.
        VCCB_PRINT_LOG_ROHC(ptCi, "Update CIDs after new DRB allocation. Current allocation was:[%d] Requested is:[%d]\n",
            ptCi->ueInfo.roHCCapability.curAllocatedRohcCid, ptCi->drb[drbIdx].rbInfo.pdcpInfo.headerCompression.ulRohcMaxSession);

        ptCi->ueInfo.roHCCapability.curAllocatedRohcCid = 
            (uint16_t)(ptCi->ueInfo.roHCCapability.curAllocatedRohcCid + 
                    ptCi->drb[drbIdx].rbInfo.pdcpInfo.headerCompression.ulRohcMaxSession);
        ptCi->ueInfo.roHCCapability.tempAllocatedRohcCid = 0;

        ptDi->drbConnStat.markedCellNumForUlRoHCDrbRrcConnStat = cellNum;
        ptDi->drbConnStat.marked5qiForUlRoHCDrbRrcConnStat = selected5Qi;
        ptDi->drbConnStat.UlRoHCdrbCountFlagRrcConn = VCCB_FLAG_ON;
    }

    return;
}

/**
 * @brief        Increment ULOnlyRoHC call counter per cell.
 * @details      This function is used to increment ULOnlyRoHC call count assigned to one cell.
 * @param [in]   cellNum: cell identifier
 * @return       GOOD, ERROR
 * @date         2019-09-23
 */
void VRRM_addULOnlyRoHCCellCallCount(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    uint32_t curCallCnt = 0;
    uint32_t newCallCnt = 0;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (cellNum >= MAX_CELL_NUM_VCCB)
    {
        VCCB_PRINT_ERROR("VRRM_addULOnlyRoHCCellCallCount cellNum[%d] out of range!!\n", cellNum);

        return;
    }

    if (ptCi->isULOnlyRoHCCall == VCCB_FLAG_ON)  // Cell Call Count collected already.
    {
        // call count already incremented return
        VCCB_PRINT_ERROR("VRRM_addULOnlyRoHCCellCallCount cellCallCount already incremented\n");

        return;
    }

    VccbCellInfo_type* const pCell = &CELLINFO[cellNum];
    VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[cellNum]);

    if (ptCi->callType == E_CALLTYPE_SA)
    {
        curCallCnt = pCell->cfg.assignedULOnlyRoHCCellCallCountSA;
        pCell->cfg.assignedULOnlyRoHCCellCallCountSA++;

        newCallCnt = pCell->cfg.assignedULOnlyRoHCCellCallCountSA;
    }
    else
    {
        curCallCnt = pCell->cfg.assignedULOnlyRoHCCellCallCount;

        pCell->cfg.assignedULOnlyRoHCCellCallCount++;

        newCallCnt = pCell->cfg.assignedULOnlyRoHCCellCallCount;
    }
    VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[cellNum]);

    VCCB_PRINT_LOG_ROHC(ptCi, "ULOnlyRoHCCellCount++ (CellNum [%d] Before [%d] => After [%d]) \n", cellNum,
        curCallCnt, newCallCnt);
    
    ptCi->rrcConnStat.markedCellNumForULOnlyRoHCRrcConnStat = cellNum;
    ptCi->isULOnlyRoHCCall = VCCB_FLAG_ON;

    return;
}

// RRC Conn
void FnVCCB_CalculateDrbHoldingTimeOfSaRrcConn(callInfo_type *ptCi, uint16_t drbIdxInCall, uint8_t actFlag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdxInCall, MAX_DRB_PER_SA_CALL);

    if ((ptCi->callType != E_CALLTYPE_SA) || IS_NRDC_SN(ptCi))
    {
        return;
    }

    callDRBInfo_type *ptDi = &ptCi->drb[drbIdxInCall];
    Stopwatch_type &stopwatch = ptDi->drbConnStat.drbHoldingTimeOfRrcConn;

    if (actFlag == CAL_START)
    {
        if(stopwatch.isRunning == true) return;

        ComTimeUtil::stopwatch_start(stopwatch);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_start in %s\n", __func__);
    }
    else  // CAL_STOP
    {
        if(stopwatch.isRunning == false) return;

        const struct timespec holdingTime = ComTimeUtil::stopwatch_stop(stopwatch);
        if (holdingTime.tv_sec < 0 && holdingTime.tv_nsec < 0)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "stopwatch_stop ERROR in %s\n", __func__);
            return;
        }

        float holdingTimeInSecond = ComTimeUtil::getTimeSecondInFloat(holdingTime);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_stop(holdingTime:%f sec) in %s\n", (double)holdingTimeInSecond, __func__);

        uint8_t selected5Qi;
        uint16_t qosIdxInCall;
        qosIdxInCall = ptDi->drbQosIdxInCall;
        VCCB_CHECK_E_RANGE_AND_VOID(qosIdxInCall, MAX_QOS_FLOW_PER_CALL);
        VLIB_getFiveQi(&ptCi->qosFlow[qosIdxInCall], &selected5Qi);

        if (IS_REDCAP_UE(ptCi))
        {
            int redCapFamily = STAT_DRB_CONN_INFO_REDCAP_PLMN;

            if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
                redCapFamily = STAT_CP_DRB_CONN_INFO_REDCAP_PLMN;

            MACRO_STAT_PMSI(redCapFamily, DrbHoldingTimeAvg, ptCi, holdingTimeInSecond, selected5Qi, 0, 0, 0);
        }
        else
        {
            MACRO_STAT_PMSI(STAT_DRB_CONN_INFO, DrbHoldingTimeAvg, ptCi, holdingTimeInSecond, selected5Qi, 0, 0, 0);
            if (FOO.VF_MultipleOperatorCNSupport)
            {
                MACRO_STAT_PMSI(STAT_DRB_CONN_INFO_PLMN, DrbHoldingTimeAvgPlmn, ptCi, holdingTimeInSecond, selected5Qi, 0, 0, 0);
            }
        }

        // DRB with PLMN-Slice (26A)
        if (FOO.VF_ConnInfoPlmnSnssaiCounterConfig)
        {
            uint32_t sstSdVal = 0;
            if (GOOD == FnVCCB_GetSliceStatValueFromYangWithDrb(*ptCi, *ptDi, sstSdVal))
            {
                MACRO_STAT_PMSI(STAT_DRB_CONN_INFO_PLMN_SNSSAI, DrbHoldingTimeAvg, ptCi, holdingTimeInSecond, selected5Qi, sstSdVal, 0, 0);
            }
        }

    }
    return;
}

void FnVCCB_CalculateDrbHoldingTimeOfSaRrcInact(callInfo_type *ptCi, uint16_t drbIdxInCall, uint8_t actFlag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdxInCall, MAX_DRB_PER_SA_CALL);

    if ((ptCi->callType != E_CALLTYPE_SA) || IS_NRDC_SN(ptCi))
    {
        return;
    }

    callDRBInfo_type *ptDi = &ptCi->drb[drbIdxInCall];
    Stopwatch_type &stopwatch = ptDi->drbConnStat.drbHoldingTimeOfRrcInact;

    if (actFlag == CAL_START)
    {
        if(stopwatch.isRunning == true) return; 

        ComTimeUtil::stopwatch_start(stopwatch);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_start in %s\n", __func__);
    }
    else  // CAL_STOP
    {
        if(stopwatch.isRunning == false) return;

        const struct timespec holdingTime = ComTimeUtil::stopwatch_stop(stopwatch);
        if (holdingTime.tv_sec < 0 && holdingTime.tv_nsec < 0)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "stopwatch_stop ERROR in %s\n", __func__);
            return;
        }
        
        float holdingTimeInSecond = ComTimeUtil::getTimeSecondInFloat(holdingTime);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_stop(holdingTime:%f sec) in %s\n", (double)holdingTimeInSecond, __func__);

        uint8_t selected5Qi;
        uint16_t qosIdxInCall;
        qosIdxInCall = ptDi->drbQosIdxInCall;
        VCCB_CHECK_E_RANGE_AND_VOID(qosIdxInCall, MAX_QOS_FLOW_PER_CALL);
        VLIB_getFiveQi(&ptCi->qosFlow[qosIdxInCall], &selected5Qi);

        if (IS_REDCAP_UE(ptCi))
        {
            int redCapFamily = STAT_DRB_CONN_INFO_REDCAP_PLMN;

            if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
                redCapFamily = STAT_CP_DRB_CONN_INFO_REDCAP_PLMN;

            MACRO_STAT_PMSI(redCapFamily, InactDrbHoldingTimeAvg, ptCi, holdingTimeInSecond, selected5Qi, 0, 0, 0);
        }
        else
        {
            MACRO_STAT_PMSI(STAT_DRB_CONN_INFO, InactDrbHoldingTimeAvg, ptCi, holdingTimeInSecond, selected5Qi, 0, 0, 0);
            if (FOO.VF_MultipleOperatorCNSupport)
            {
                MACRO_STAT_PMSI(
                    STAT_DRB_CONN_INFO_PLMN, InactDrbHoldingTimeAvgPlmn, ptCi, holdingTimeInSecond, selected5Qi, 0, 0, 0);
            }
        }

        // DRB with PLMN-Slice (26A)
        if (FOO.VF_ConnInfoPlmnSnssaiCounterConfig)
        {
            uint32_t sstSdVal = 0;
            if (GOOD == FnVCCB_GetSliceStatValueFromYangWithDrb(*ptCi, *ptDi, sstSdVal))
            {
                MACRO_STAT_PMSI(
                    STAT_DRB_CONN_INFO_PLMN_SNSSAI, InactDrbHoldingTimeAvgPlmn, ptCi, holdingTimeInSecond, selected5Qi, sstSdVal, 0, 0);
            }
        }
    }
    return;
}

// RRC ConnInact
void FnVCCB_CalculateDrbHoldingTimeOfSaRrcConnInact(callInfo_type *ptCi, uint16_t drbIdxInCall, uint8_t actFlag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdxInCall, MAX_DRB_PER_SA_CALL);

    if ((ptCi->callType != E_CALLTYPE_SA) || IS_NRDC_SN(ptCi))
    {
        return;
    }

    callDRBInfo_type *ptDi = &ptCi->drb[drbIdxInCall];
    Stopwatch_type &stopwatch = ptDi->drbConnStat.drbHoldingTimeOfRrcConnInact;

    if (actFlag == CAL_START)
    {
        if(stopwatch.isRunning == true) return; 

        ComTimeUtil::stopwatch_start(stopwatch);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_start in %s\n", __func__);
    }
    else  // CAL_STOP
    {
        if(stopwatch.isRunning == false) return; 

        const struct timespec holdingTime = ComTimeUtil::stopwatch_stop(stopwatch);
        if (holdingTime.tv_sec < 0 && holdingTime.tv_nsec < 0)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "stopwatch_stop ERROR in %s\n", __func__);
            return;
        }

        float holdingTimeInSecond = ComTimeUtil::getTimeSecondInFloat(holdingTime);
        VCCB_PRINT_CALL_COMMENT(ptCi, "stopwatch_stop(holdingTime:%f sec) in %s\n", (double)holdingTimeInSecond, __func__);

        uint8_t selected5Qi;
        uint16_t qosIdxInCall;

        qosIdxInCall = ptDi->drbQosIdxInCall;
        VCCB_CHECK_E_RANGE_AND_VOID(qosIdxInCall, MAX_QOS_FLOW_PER_CALL);
        VLIB_getFiveQi(&ptCi->qosFlow[qosIdxInCall], &selected5Qi);

        if (IS_REDCAP_UE(ptCi))
        {
            int redCapFamily = STAT_DRB_CONN_INFO_REDCAP_PLMN;

            if (e_VCCB_ACPF_CNF == VCOM_getSystemType())
                redCapFamily = STAT_CP_DRB_CONN_INFO_REDCAP_PLMN;

            MACRO_STAT_PMSI(redCapFamily, ConnInactDrbHoldingTimeAvg, ptCi, holdingTimeInSecond, selected5Qi, 0, 0, 0);
        }
        else
        {
            MACRO_STAT_PMSI(STAT_DRB_CONN_INFO, ConnInactDrbHoldingTimeAvg, ptCi, holdingTimeInSecond, selected5Qi, 0, 0, 0);
            if (FOO.VF_MultipleOperatorCNSupport)
            {
                MACRO_STAT_PMSI(STAT_DRB_CONN_INFO_PLMN, ConnInactDrbHoldingTimeAvgPlmn, ptCi, holdingTimeInSecond, selected5Qi, 0, 0, 0);
            }
        }

        // DRB with Plmn-Slice (26A)
        if (FOO.VF_ConnInfoPlmnSnssaiCounterConfig)
        {
            uint32_t sstSdVal = 0;
            if (GOOD == FnVCCB_GetSliceStatValueFromYangWithDrb(*ptCi, *ptDi, sstSdVal))
            {
                MACRO_STAT_PMSI(STAT_DRB_CONN_INFO_PLMN_SNSSAI, ConnInactDrbHoldingTimeAvgPlmn, ptCi, holdingTimeInSecond, selected5Qi, sstSdVal, 0, 0);
            }
        }

    }
    return;
}

void FnVCCB_CalculateDrbSetupTime(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t actFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptDi);

    Stopwatch_type &stopwatch = ptDi->drbConnStat.drbSetupTime;

    if (actFlag == CAL_START)
    {
        uint8_t fiveQi = 0;
        uint16_t drbQosIdxInCall = ptDi->drbQosIdxInCall;

        if (drbQosIdxInCall >= MAX_QOS_FLOW_PER_CALL)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "FnVCCB_CalculateDrbSetupTime invalid drbQosIdxInCall(%u) for STAT_DRB_SETUP_TIME_DU_ID statistics \n",
                drbQosIdxInCall);
            return;
        }
        VLIB_getFiveQi(&ptCi->qosFlow[drbQosIdxInCall], &fiveQi);
        if (fiveQi != VONR_5QI)
        {
            return;
        }

        ComTimeUtil::stopwatch_start(stopwatch);
        VCCB_PRINT_CALL_COMMENT(ptCi, "DRB SETUP 5QI=1, stopwatch_start in %s\n", __func__);
    }
    else
    {
        const struct timespec timeElapsed = ComTimeUtil::stopwatch_stop(stopwatch);
        if (timeElapsed.tv_sec < 0 && timeElapsed.tv_nsec < 0)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "stopwatch_stop ERROR in %s\n", __func__);
            return;
        }

        const float timeElapsedInMilliSecond = ComTimeUtil::getTimeMilliSecondInFloat(timeElapsed);
        VCCB_PRINT_CALL_COMMENT(ptCi, "DRB Setup 5QI=1 stopwatch_stop(timeElapsed:%f) in %s\n", (double)timeElapsedInMilliSecond, __func__);

        VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
        const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

        if (FOO.VF_BasicoperationForSa_DrbSetupTime)
        {
            int mType = DrbSetupTimeAvg;
            if (IS_REDCAP_UE(ptCi))
            {
                mType = DrbSetupTimeAvg_RedCap;
            }
            MACRO_STAT_PMGAUGE(STAT_DRB_SETUP_TIME_DU_ID, mType, ptCi, timeElapsedInMilliSecond, ptCi->gnbNum, pCell->cellIdentity, VONR_5QI, 0);
        }

        // CSL for DRB Setup Time
        FnVCCB_CollectStatCSL_DrbSetupTime(ptCi, timeElapsedInMilliSecond);

    }

    return;
}

void FnVCCB_CompareAndAddDrbCountOfSaRrcConn(callInfo_type *ptCi, uint16_t newCellNum, uint16_t drbIdxInCall)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(newCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdxInCall, MAX_DRB_PER_SA_CALL);

    uint8_t selected5Qi;
    uint16_t qosIdxInCall;
    uint8_t plmnIdx;
    uint8_t sliceIdx = MAX_SLICE_STAT_YANG;
    callDRBInfo_type *ptDi = &ptCi->drb[drbIdxInCall];

    if ((ptCi->callType != E_CALLTYPE_SA) || IS_NRDC_SN(ptCi))
    {
        return;
    }

    if (ptDi->drbConnStat.drbCountFlagOfRrcConn == FLAG_ON)  // Call Count collected already.
    {
        qosIdxInCall = ptDi->drbQosIdxInCall;
        VCCB_CHECK_E_RANGE_AND_VOID(qosIdxInCall, MAX_QOS_FLOW_PER_CALL);

        // Get New Requested Value
        VLIB_getFiveQi(&ptCi->qosFlow[qosIdxInCall], &selected5Qi);
        plmnIdx = VLIB_findCellPlmnIndex(newCellNum, ptCi->ueInfo.servedPlmn.longId);
        if (FOO.VF_ConnInfoPlmnSnssaiCounterConfig)
        {
            sliceIdx = FnVCCB_GetSliceStatIndexFromYangWithDrb(*ptCi, *ptDi);
        }

        // Compare new values with marked value.
        // If Diff, then del/add drb count.
        if ((ptDi->drbConnStat.markedCellNumForDrbConnStatOfRrcConn != newCellNum) ||
            (ptDi->drbConnStat.marked5qiForDrbConnStatOfRrcConn != selected5Qi) ||
            (ptDi->drbConnStat.markedPlmnIdxForDrbConnStatOfRrcConn  != plmnIdx) ||
            (ptDi->drbConnStat.markedSliceIdxForDrbConnStatOfRrcConn != sliceIdx))
        {
            FnVCCB_DelCellDrbCountWithMarkedInfoOfSaRrcConn(ptCi, drbIdxInCall);
            FnVCCB_AddCellDrbCountOfSaRrcConn(ptCi, newCellNum, drbIdxInCall);
        }
    }
    else
    {
        FnVCCB_AddCellDrbCountOfSaRrcConn(ptCi, newCellNum, drbIdxInCall);
    }

    return;
}

void FnVCCB_CompareAndAddDrbCountOfSaRrcInact(callInfo_type *ptCi, uint16_t newCellNum, uint16_t drbIdxInCall)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(newCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdxInCall, MAX_DRB_PER_SA_CALL);

    uint8_t selected5Qi;
    uint16_t qosIdxInCall;
    uint8_t plmnIdx;
    uint8_t sliceIdx = MAX_SLICE_STAT_YANG;
    callDRBInfo_type *ptDi = &ptCi->drb[drbIdxInCall];

    if ((ptCi->callType != E_CALLTYPE_SA) || IS_NRDC_SN(ptCi))
    {
        return;
    }

    if (ptDi->drbConnStat.drbCountFlagOfRrcInact == FLAG_ON)  // Call Count collected already.
    {
        qosIdxInCall = ptDi->drbQosIdxInCall;
        VCCB_CHECK_E_RANGE_AND_VOID(qosIdxInCall, MAX_QOS_FLOW_PER_CALL);

        // Get New Requested Value
        VLIB_getFiveQi(&ptCi->qosFlow[qosIdxInCall], &selected5Qi);
        plmnIdx = VLIB_findCellPlmnIndex(newCellNum, ptCi->ueInfo.servedPlmn.longId);
        if (FOO.VF_ConnInfoPlmnSnssaiCounterConfig)
        {
            sliceIdx = FnVCCB_GetSliceStatIndexFromYangWithDrb(*ptCi, *ptDi);
        }

        // Compare new values with marked value.
        // If Diff, then del/add drb count.
        if ((ptDi->drbConnStat.markedCellNumForDrbConnStatOfRrcInact != newCellNum) ||
            (ptDi->drbConnStat.marked5qiForDrbConnStatOfRrcInact != selected5Qi) ||
            (ptDi->drbConnStat.markedPlmnIdxForDrbConnStatOfRrcInact  != plmnIdx) ||
            (ptDi->drbConnStat.markedSliceIdxForDrbConnStatOfRrcInact != sliceIdx))

        {
            FnVCCB_DelCellDrbCountWithMarkedInfoOfSaRrcInact(ptCi, drbIdxInCall);
            FnVCCB_AddCellDrbCountOfSaRrcInact(ptCi, newCellNum, drbIdxInCall);
        }
    }
    else
    {
        FnVCCB_AddCellDrbCountOfSaRrcInact(ptCi, newCellNum, drbIdxInCall);
    }

    return;
}

void FnVCCB_UpdateAllDrbCountAndHoldTimeOfSaUe(callInfo_type *ptCi, uint16_t cellNum, uint8_t rrcStatType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    uint16_t callDrbIdx = 0;

    if ((ptCi->callType != E_CALLTYPE_SA) || IS_NRDC_SN(ptCi))
    {
        return;
    }

    for (callDrbIdx = 0; callDrbIdx < MAX_DRB_PER_SA_CALL; callDrbIdx++)
    {
        if (CI_use != ptCi->drb[callDrbIdx].usage) continue;
        
        callDRBInfo_type* ptDi = &ptCi->drb[callDrbIdx];
        if (rrcStatType == VCCB_STAT_RRC_CONNECTED)
        {
            FnVCCB_DelCellDrbCountWithMarkedInfoOfSaRrcInact(ptCi, callDrbIdx);
            FnVCCB_CalculateDrbHoldingTimeOfSaRrcInact(ptCi, callDrbIdx, CAL_STOP);

            if( VCCB_IS_SN_TERM_DRB_WITH_ONLY_CHECK_BEARER_TYPE(ptDi) ) // SN Term
            {
                // Delete Count(RRC Conn), Stop Hold Time (RRC Conn, ConnInact)
                FnVCCB_DelCellDrbCountWithMarkedInfoOfSaRrcConn(ptCi, callDrbIdx);
                FnVCCB_CalculateDrbHoldingTimeOfSaRrcConnInact(ptCi, callDrbIdx, CAL_STOP);
                FnVCCB_CalculateDrbHoldingTimeOfSaRrcConn(ptCi, callDrbIdx, CAL_STOP);
            }
            else // MN-Term or Normal DRB.
            {
                // Add Count(RRC Conn), Start Hold Time(RRC Conn, ConnInact)
                FnVCCB_CompareAndAddDrbCountOfSaRrcConn(ptCi, cellNum, callDrbIdx);
                FnVCCB_CalculateDrbHoldingTimeOfSaRrcConnInact(ptCi, callDrbIdx, CAL_START);
                FnVCCB_CalculateDrbHoldingTimeOfSaRrcConn(ptCi, callDrbIdx, CAL_START);
            }
        }
        else  // VCCB_STAT_RRC_INACTIVE
        {
            FnVCCB_DelCellDrbCountWithMarkedInfoOfSaRrcConn(ptCi, callDrbIdx);
            FnVCCB_CalculateDrbHoldingTimeOfSaRrcConn(ptCi, callDrbIdx, CAL_STOP);

            FnVCCB_CompareAndAddDrbCountOfSaRrcInact(ptCi, cellNum, callDrbIdx);
            FnVCCB_CalculateDrbHoldingTimeOfSaRrcConnInact(ptCi, callDrbIdx, CAL_START);
            FnVCCB_CalculateDrbHoldingTimeOfSaRrcInact(ptCi, callDrbIdx, CAL_START);
        }

        // Clear SN TERM Event.
        if( VCCB_IS_SN_TERM_DRB_WITH_ONLY_CHECK_BEARER_TYPE(ptDi) )
        {
            ptDi->retainStat.inSessionFlagByE1 = VCCB_FLAG_OFF;
            CLEAR_DRB_RETAIN_STAT_EVENT(ptDi);
            SET_DRB_RETAIN_STAT_CAPABLE_FLAG(ptDi, VCCB_FLAG_OFF);
        }
    }
}

void FnVCCB_FinalizeSaConnStat_AfterCleaningBearer(callInfo_type *ptCi, uint16_t cellNum, uint8_t rrcStatType)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    // DRB Count
    FnVCCB_UpdateAllDrbCountAndHoldTimeOfSaUe(ptCi, cellNum, rrcStatType);
    // Decide VoNr Emergency Call                                     /* Collect Retain Stat */
    FnVCCB_UpdateVoNrEmergencyCallAndReleaseStat(ptCi, VCCB_FLAG_ON);
    // VoNR & Emergency Call Count Stat
    FnVCCB_UpdateVonrEmerCountAndHoldTimeOfSaUe(ptCi, ptCi->servCellNum, rrcStatType);

    // FGR-CC5200:FR760 FR770
    FnVCCB_FinalizeNrdcSnConnStat(ptCi, cellNum);
    return;
}

// FGR-CC5200:FR760 FR770 FR740 FR750
// update conn stats of holdingTime
void FnVCCB_FinalizeNrdcSnConnStat(callInfo_type *ptCi, uint16_t cellNum)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    // FR760 FR770
    FnVCCB_NrdcSnConnInfoStatsCmd(ptCi, cellNum, ConnInfoStatsCmd_Increase);
    FnVCCB_NrdcSnConnInfoStatsCmd(ptCi, cellNum, ConnInfoStatsCmd_HoldingTimeStart);

    // FR740 FR750
    FnVCCB_UpdateAllNrdcSnTermDrbCountAndHoldTime(ptCi, cellNum);
}

void FnVCCB_UpdateVoNrEmergencyCallAndReleaseStat(callInfo_type *ptCi, uint8_t releaseStatFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (FnVCCB_IsVoNrEmergencyCall(ptCi) == TRUE)
    {
        ptCi->rrcConnStat.vonrEmerCallFlag = VCCB_FLAG_ON;
    }
    else  // Not VoNrEmergency Call
    {
        if(ptCi->rrcConnStat.vonrEmerCallFlag == VCCB_FLAG_ON)
        {
            if (releaseStatFlag == VCCB_FLAG_ON)
            {
                if (ptCi->retainStatOfVonrEmer.savedEventCategory != No_CallDrb_RetainCategory)
                {
                    // VoNR Emergency Call Release
                    MACRO_STAT_PMCC_RETAIN(STAT_VONR_EMERGENCY_RELEASE, ptCi, NULL, ptCi->retainStatOfVonrEmer.savedEventCategory,
                            ptCi->retainStatOfVonrEmer.savedEventItem, 0, FALSE);
                }

            }
        }
        ptCi->rrcConnStat.vonrEmerCallFlag = VCCB_FLAG_OFF;
    }

    // Clear VoNr Event.
    CLEAR_RETAIN_STAT_EVENT(ptCi->retainStatOfVonrEmer);

    return;
}

void FnVCCB_UpdateVonrEmerCountAndHoldTimeOfSaUe(callInfo_type *ptCi, uint16_t cellNum, uint8_t statType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if ((ptCi->callType != E_CALLTYPE_SA) || IS_NRDC_SN(ptCi))
    {
        return;
    }

    if (statType == VCCB_STAT_RRC_CONNECTED)
    {
        // Delete Count(RRC Inactive), Hold Time (RRC Inactive)
        // Currently Not Support RRC Inactive Count/Hold Time

        // Add Count(RRC Conn), Hold Time(RRC Conn, ConnInact)
        if(ptCi->rrcConnStat.vonrEmerCallFlag == VCCB_FLAG_ON)
        {
            FnVCCB_CompareAndAddVonrEmerCountOfSaRrcConn(ptCi, cellNum);
        }
        else
        {
            FnVCCB_DelCellVonrEmerCountWithMarkedInfoOfSaRrcConn(ptCi);
        }
    }

    else  // VCCB_STAT_RRC_INACTIVE
    {
        // Delete Count(RRC Conn), Hold Time (RRC Conn)
        FnVCCB_DelCellVonrEmerCountWithMarkedInfoOfSaRrcConn(ptCi);

        // Add Count(RRC Inactive), Hold Time(RRC Inactive, ConnInact)
        // Currently Not Support RRC Inactive Count/Hold Time
    }

    return;
}

void FnVCCB_CompareAndAddVonrEmerCountOfSaRrcConn(callInfo_type *ptCi, uint16_t newCellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(newCellNum, MAX_CELL_NUM_VCCB);

    if ((ptCi->callType != E_CALLTYPE_SA) || IS_NRDC_SN(ptCi))
    {
        return;
    }

    if (ptCi->rrcConnStat.vonrEmerCountFlagOfRrcConn == VCCB_FLAG_ON)  // Call Count collected already.
    {
        // Compare new values with marked value.
        // If Diff, then del/add VoNrEmer count.
        if(ptCi->rrcConnStat.markedCellNumForVonrEmerRrcConn!= newCellNum)
        {
            FnVCCB_DelCellVonrEmerCountWithMarkedInfoOfSaRrcConn(ptCi);
            FnVCCB_AddCellVonrEmerCountOfSaRrcConn(ptCi, newCellNum);
        }
    }
    else
    {
        FnVCCB_AddCellVonrEmerCountOfSaRrcConn(ptCi, newCellNum);
    }

    return;
}

void FnVCCB_AddCellVonrEmerCountOfSaRrcConn(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    if ((ptCi->callType != E_CALLTYPE_SA) || IS_NRDC_SN(ptCi))
    {
        return;
    }

    if (ptCi->rrcConnStat.vonrEmerCountFlagOfRrcConn == VCCB_FLAG_ON)  // Call Count collected already.
    {
        return;
    }

    VccbCellInfo_type* pCell = &CELLINFO[cellNum];
    // Update Count
    // Mutex Start >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[cellNum]);

    pCell->cfg.vonrEmerCellRrcConnectionCount++;

    VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[cellNum]);
    // Mutex End <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    // Update Call Info
    ptCi->rrcConnStat.markedCellNumForVonrEmerRrcConn = cellNum;
    ptCi->rrcConnStat.vonrEmerCountFlagOfRrcConn = VCCB_FLAG_ON;

    return;
}

void FnVCCB_DelCellVonrEmerCountWithMarkedInfoOfSaRrcConn(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    uint16_t prevCellNum;

    if (ptCi->rrcConnStat.vonrEmerCountFlagOfRrcConn!= VCCB_FLAG_ON)  // It's not counted.
    {
        return;
    }

    // Get Saved Info
    prevCellNum = ptCi->rrcConnStat.markedCellNumForVonrEmerRrcConn;
    VCCB_CHECK_E_RANGE_AND_VOID(prevCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type* const pCell = &CELLINFO[prevCellNum];
    // Update Count
    // Mutex Start >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[prevCellNum]);

    if (pCell->cfg.vonrEmerCellRrcConnectionCount > 0)
    {
        pCell->cfg.vonrEmerCellRrcConnectionCount--;
    }

    VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[prevCellNum]);
    // Mutex End <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    // Update Call Info
    ptCi->rrcConnStat.vonrEmerCountFlagOfRrcConn           = VCCB_FLAG_OFF;
    ptCi->rrcConnStat.markedCellNumForVonrEmerRrcConn = 0xFFFF;

    return;
}

/**
 * @brief        update SA drb counter per cell per qci.
 * @details      This function is used to update SA drb count assigned to one cell.
 * @param [in]   ptCi
 * @return       GOOD, ERROR
 * @date         2019-12-11
 */
void FnVCCB_CompareAndAddRohcDrbCountInRrcConn(callInfo_type *ptCi, uint16_t cellNum, uint16_t callDrbIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(callDrbIdx, MAX_DRB_PER_SA_CALL);

    uint8_t selected5Qi;
    uint16_t qosIdxInCall;

    qosIdxInCall = ptCi->drb[callDrbIdx].drbQosIdxInCall;
    VCCB_CHECK_E_RANGE_AND_VOID(qosIdxInCall, MAX_QOS_FLOW_PER_CALL);
    
    // Get New Requested Value
    VLIB_getFiveQi(&ptCi->qosFlow[qosIdxInCall], &selected5Qi);

    {
        if (((ptCi->drb[callDrbIdx].rbInfo.pdcpInfoPrev.headerCompression.ulRohcEnabled == TRUE) &&
             (ptCi->drb[callDrbIdx].rbInfo.pdcpInfoPrev.headerCompression.useProfile006 == TRUE)) &&
            ((ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.headerCompression.ulRohcEnabled == FALSE) &&
             (ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.headerCompression.useProfile006 == FALSE)))
        {
            // decrement counter
            VRRM_delCellassignedULOnlyRoHCDrbCount(ptCi, cellNum, callDrbIdx, FALSE);
        }
        else if (((ptCi->drb[callDrbIdx].rbInfo.pdcpInfoPrev.headerCompression.ulRohcEnabled == FALSE) &&
                  (ptCi->drb[callDrbIdx].rbInfo.pdcpInfoPrev.headerCompression.useProfile006 == FALSE)) &&
                 ((ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.headerCompression.ulRohcEnabled == TRUE) &&
                  (ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.headerCompression.useProfile006 == TRUE)))
        {
            // if prev is disabled, new status is enabled. inc counter

            if (ptCi->drb[callDrbIdx].drbConnStat.UlRoHCdrbCountFlagRrcConn == VCCB_FLAG_ON)  // Call Count collected already.
            {
                // Compare new values with marked value.
                // If Diff, then del/add drb count.
                if ((ptCi->drb[callDrbIdx].drbConnStat.markedCellNumForUlRoHCDrbRrcConnStat != cellNum) ||
                    (ptCi->drb[callDrbIdx].drbConnStat.marked5qiForUlRoHCDrbRrcConnStat != selected5Qi))
                {
                    VRRM_delCellassignedULOnlyRoHCDrbCount(ptCi, cellNum, callDrbIdx, FALSE);
                    VRRM_addCellassignedULOnlyRoHCDrbCount(ptCi, cellNum, callDrbIdx);
                }
            }
            else
            {
                VRRM_addCellassignedULOnlyRoHCDrbCount(ptCi, cellNum, callDrbIdx);
            }                                    
        }
        else if (((ptCi->drb[callDrbIdx].rbInfo.pdcpInfoPrev.headerCompression.ulRohcEnabled == TRUE) &&
                  (ptCi->drb[callDrbIdx].rbInfo.pdcpInfoPrev.headerCompression.useProfile006 == TRUE)) &&
                ((ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.headerCompression.ulRohcEnabled == TRUE) &&
                  (ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.headerCompression.useProfile006 == TRUE)))
        {
            // if prev is enabled, and Intra gNB RRE/HO new status will be enabled. inc counter

            if (ptCi->drb[callDrbIdx].drbConnStat.UlRoHCdrbCountFlagRrcConn == VCCB_FLAG_ON)  // Call Count collected already.
            {
                // Compare new values with marked value.
                // If Diff, then del/add drb count.
                if ((ptCi->drb[callDrbIdx].drbConnStat.markedCellNumForUlRoHCDrbRrcConnStat != cellNum) ||
                    (ptCi->drb[callDrbIdx].drbConnStat.marked5qiForUlRoHCDrbRrcConnStat != selected5Qi))
                {
                    VRRM_delCellassignedULOnlyRoHCDrbCount(ptCi, cellNum, callDrbIdx, FALSE);
                    VRRM_addCellassignedULOnlyRoHCDrbCount(ptCi, cellNum, callDrbIdx);
                }
            }
            else
            {
                VRRM_addCellassignedULOnlyRoHCDrbCount(ptCi, cellNum, callDrbIdx);
            }                                    
        }

        ptCi->ueInfo.roHCCapability.tempAllocatedRohcCid = 0;
    }

    {
        if ((ptCi->drb[callDrbIdx].rbInfo.pdcpInfoPrev.headerCompression.symmetricRohcEnabled == TRUE) &&
            (ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.headerCompression.symmetricRohcEnabled == FALSE))
        {
            // decrement counter
            FnVCCB_delSymmRoHCDrbCountInRrcConn(ptCi, cellNum, callDrbIdx);
        }
        else if ((ptCi->drb[callDrbIdx].rbInfo.pdcpInfoPrev.headerCompression.symmetricRohcEnabled == FALSE) &&
                (ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.headerCompression.symmetricRohcEnabled == TRUE))
        {
            // if prev is disabled, new status is enabled. inc counter
            if (ptCi->drb[callDrbIdx].drbConnStat.SymmRoHCdrbCountFlagRrcConn == VCCB_FLAG_ON)  // Call Count collected already.
            {
                // Compare new values with marked value.
                // If Diff, then del/add drb count.
                if ((ptCi->drb[callDrbIdx].drbConnStat.markedCellNumForSymmRoHCDrbRrcConnStat != cellNum) ||
                    (ptCi->drb[callDrbIdx].drbConnStat.marked5qiForSymmRoHCDrbRrcConnStat != selected5Qi))
                {
                    FnVCCB_delSymmRoHCDrbCountInRrcConn(ptCi, cellNum, callDrbIdx);
                    FnVCCB_addSymmRoHCDrbCountInRrcConn(ptCi, cellNum, callDrbIdx);
                }
            }
            else
            {
                FnVCCB_addSymmRoHCDrbCountInRrcConn(ptCi, cellNum, callDrbIdx);
            }
        }
        else if ((ptCi->drb[callDrbIdx].rbInfo.pdcpInfoPrev.headerCompression.symmetricRohcEnabled == TRUE) &&
                (ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.headerCompression.symmetricRohcEnabled == TRUE))
        {
            // if prev is enabled, and Intra gNB RRE/HO/Resume new status will be enabled. inc counter
            if (ptCi->drb[callDrbIdx].drbConnStat.SymmRoHCdrbCountFlagRrcConn == VCCB_FLAG_ON)  // Call Count collected already.
            {
                // Compare new values with marked value.
                // If Diff, then del/add drb count.
                if ((ptCi->drb[callDrbIdx].drbConnStat.markedCellNumForSymmRoHCDrbRrcConnStat != cellNum) ||
                    (ptCi->drb[callDrbIdx].drbConnStat.marked5qiForSymmRoHCDrbRrcConnStat != selected5Qi))
                {
                    FnVCCB_delSymmRoHCDrbCountInRrcConn(ptCi, cellNum, callDrbIdx);
                    FnVCCB_addSymmRoHCDrbCountInRrcConn(ptCi, cellNum, callDrbIdx);
                }
            }
            else
            {
                FnVCCB_addSymmRoHCDrbCountInRrcConn(ptCi, cellNum, callDrbIdx);
            }
        }

        ptCi->ueInfo.roHCCapability.tempAllocatedRohcCid = 0;
    }
    return;
}

/**
 * @brief        update SA drb counter per cell per qci.
 * @details      This function is used to update SA drb count.
 * @param [in]   ptCi
 * @return       GOOD, ERROR
 * @date         2019-12-11
 */
void FnVCCB_CompareAndAddEhcDrbCountInRrcConn(callInfo_type *ptCi, uint16_t callDrbIdx, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(callDrbIdx, MAX_DRB_PER_SA_CALL);

    uint8_t selected5Qi;
    uint16_t qosIdxInCall;

    qosIdxInCall = ptCi->drb[callDrbIdx].drbQosIdxInCall;
    VCCB_CHECK_E_RANGE_AND_VOID(qosIdxInCall, MAX_QOS_FLOW_PER_CALL);

    // Get New Requested Value
    VLIB_getFiveQi(&ptCi->qosFlow[qosIdxInCall], &selected5Qi);

    {
        if ((ptCi->drb[callDrbIdx].rbInfo.pdcpInfoPrev.ethernetCompression.ehcEnabled == TRUE) &&
            (ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcEnabled == FALSE))
        {
            // decrement counter
            FnVCCB_delEHCDrbCountInRrcConn(ptCi, callDrbIdx, cellNum);
        }
        else if ((ptCi->drb[callDrbIdx].rbInfo.pdcpInfoPrev.ethernetCompression.ehcEnabled == FALSE) &&
                 (ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcEnabled == TRUE))
        {
            // if prev is disabled, new status is enabled. inc counter
            if (ptCi->drb[callDrbIdx].drbConnStat.EHCdrbCountFlagRrcConn == VCCB_FLAG_ON)  // Call Count collected already.
            {
                // Compare new values with marked value.
                // If Diff, then del/add drb count.
                if ((ptCi->drb[callDrbIdx].drbConnStat.marked5qiForEHCDrbRrcConnStat != selected5Qi) ||
                    (ptCi->drb[callDrbIdx].drbConnStat.markedCellNumForEHCDrbRrcConnStat != cellNum))
                {
                    FnVCCB_delEHCDrbCountInRrcConn(ptCi, callDrbIdx, cellNum);
                    FnVCCB_addEHCDrbCountInRrcConn(ptCi, callDrbIdx, cellNum);
                }
            }
            else
            {
                FnVCCB_addEHCDrbCountInRrcConn(ptCi, callDrbIdx, cellNum);
            }
        }
        else if ((ptCi->drb[callDrbIdx].rbInfo.pdcpInfoPrev.ethernetCompression.ehcEnabled == TRUE) &&
                 (ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcEnabled == TRUE))
        {
            // if prev is enabled, and Intra gNB RRE/HO/Resume new status will be enabled. inc counter
            if (ptCi->drb[callDrbIdx].drbConnStat.EHCdrbCountFlagRrcConn == VCCB_FLAG_ON)  // Call Count collected already.
            {
                // Compare new values with marked value.
                // If Diff, then del/add drb count.
                if ((ptCi->drb[callDrbIdx].drbConnStat.marked5qiForEHCDrbRrcConnStat != selected5Qi) ||
                    (ptCi->drb[callDrbIdx].drbConnStat.markedCellNumForEHCDrbRrcConnStat != cellNum))
                {
                    FnVCCB_delEHCDrbCountInRrcConn(ptCi, callDrbIdx, cellNum);
                    FnVCCB_addEHCDrbCountInRrcConn(ptCi, callDrbIdx, cellNum);
                }
            }
            else
            {
                FnVCCB_addEHCDrbCountInRrcConn(ptCi, callDrbIdx, cellNum);
            }
        }

        ptCi->ueInfo.ehcCapability.tempAllocatedEhcCid = 0;
    }
    return;
}

void FnVCCB_UpdateRohcDrbCount(callInfo_type *ptCi, uint16_t cellNum, uint8_t rrcStatType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t callDrbIdx = 0;

    if ((ptCi->callType != E_CALLTYPE_SA))
    {
        return;
    }

    for (callDrbIdx = 0; callDrbIdx < MAX_DRB_PER_SA_CALL; callDrbIdx++)
    {
        if (CI_use != ptCi->drb[callDrbIdx].usage) continue;

        if (rrcStatType == VCCB_STAT_RRC_CONNECTED)
        {
            // Delete Count(RRC Inactive)
            if ((ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.headerCompression.ulRohcEnabled == TRUE) &&
                (ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.headerCompression.useProfile006 == TRUE))
            {
                FnVCCB_delULRoHCDrbCountInRrcInact(ptCi, cellNum, callDrbIdx);
            }

            if (ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.headerCompression.symmetricRohcEnabled == TRUE)
            {
                FnVCCB_delSymmRoHCDrbCountInRrcInact(ptCi, cellNum, callDrbIdx);
            }

            // Add Count(RRC Conn)
            FnVCCB_CompareAndAddRohcDrbCountInRrcConn(ptCi, cellNum, callDrbIdx);
        }
        else  // VCCB_STAT_RRC_INACTIVE
        {
            // Delete Count(RRC Conn)
            if ((ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.headerCompression.ulRohcEnabled == TRUE) &&
                (ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.headerCompression.useProfile006 == TRUE))
            {
                VRRM_delCellassignedULOnlyRoHCDrbCount(ptCi, cellNum, callDrbIdx, FALSE);
            }

            if (ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.headerCompression.symmetricRohcEnabled == TRUE)
            {
                FnVCCB_delSymmRoHCDrbCountInRrcConn(ptCi, cellNum, callDrbIdx);
            }

            // Add Count(RRC Inactive)
            FnVCCB_CompareAndAddRohcDrbCountInRrcInact(ptCi, cellNum, callDrbIdx);
        }
    }
}

void FnVCCB_UpdateEhcDrbCount(callInfo_type *ptCi, uint8_t rrcStatType, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t callDrbIdx = 0;
    uint8_t resetEhcDrbCount = !(IS_NON_DC(ptCi));

    if ((ptCi->callType != E_CALLTYPE_SA) || (FOO.VF_EHC == FALSE))
    {
        return;
    }

    for (callDrbIdx = 0; callDrbIdx < MAX_DRB_PER_SA_CALL; callDrbIdx++)
    {
        if (CI_use != ptCi->drb[callDrbIdx].usage) continue;

        if (resetEhcDrbCount)
        {
            FnVCCB_InitEhcContext(&ptCi->drb[callDrbIdx]);
            continue;
        }

        if (rrcStatType == VCCB_STAT_RRC_CONNECTED)
        {
            // Delete Count(RRC Inactive)
            if (ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcEnabled == TRUE)
            {
                FnVCCB_delEHCDrbCountInRrcInact(ptCi, callDrbIdx, cellNum);
            }

            // Add Count(RRC Conn)
            FnVCCB_CompareAndAddEhcDrbCountInRrcConn(ptCi, callDrbIdx, cellNum);
        }
        else  // VCCB_STAT_RRC_INACTIVE
        {
            // Delete Count(RRC Conn)
            if (ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcEnabled == TRUE)
            {
                FnVCCB_delEHCDrbCountInRrcConn(ptCi, callDrbIdx, cellNum);
            }

            // Add Count(RRC Inactive)
            FnVCCB_CompareAndAddEhcDrbCountInRrcInact(ptCi, callDrbIdx, cellNum);
        }
    }

    if (resetEhcDrbCount)
    {
        ptCi->ueInfo.ehcCapability.curAllocatedEhcCid = 0;
        ptCi->ueInfo.ehcCapability.tempAllocatedEhcCid = 0;
    }
}

/**
 * @brief        Decrement  SymmRoHC call counter per Cell.
 * @details      This function is used to decrement Symmteric RoHC call count assigned to one Cell.
 * @param [in]   cellNum: subCell identifier
 * @return       GOOD, ERROR
 */
void FnVCCB_delSymmRoHCCellCallCount(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    uint32_t curCallCnt = 0;
    uint32_t newCallCnt = 0;
    uint16_t prevCellNum;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        return;
    }

    if (ptCi->isSymmRoHCCall == VCCB_FLAG_OFF)
    {
        return;
    }

    prevCellNum = ptCi->rrcConnStat.markedCellNumForSymmRoHCRrcConnStat;
    VCCB_CHECK_E_RANGE_AND_VOID(prevCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type* const pCell = &CELLINFO[prevCellNum];
    VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[prevCellNum]);

    if (pCell->cfg.assignedSymmRoHCCellCallCount > 0)
    {
        curCallCnt = pCell->cfg.assignedSymmRoHCCellCallCount;
        pCell->cfg.assignedSymmRoHCCellCallCount--;

        newCallCnt = pCell->cfg.assignedSymmRoHCCellCallCount;
    }

    VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[prevCellNum]);

    VCCB_PRINT_LOG_ROHC(ptCi, "assignedSymmRoHCCellCallCount-- (CellNum:[%d] count:[%d]=>[%d]) \n", prevCellNum,
        curCallCnt, newCallCnt);

    ptCi->isSymmRoHCCall = VCCB_FLAG_OFF;

    return;
}

/**
 * @brief        Increment SymmRoHC call counter per cell.
 * @details      This function is used to increment SymmRoHC call count assigned to one cell.
 * @param [in]   cellNum: cell identifier
 * @return       GOOD, ERROR
 */
void FnVCCB_addSymmRoHCCellCallCount(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    uint32_t curCallCnt = 0;
    uint32_t newCallCnt = 0;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        return;
    }

    if (ptCi->isSymmRoHCCall == VCCB_FLAG_ON)  // Cell Call Count collected already.
    {
        // call count already incremented return
        VCCB_PRINT_ERROR("FnVCCB_addSymmRoHCCellCallCount cellCallCount already incremented\n");
        return;
    }

    VccbCellInfo_type* const pCell = &CELLINFO[cellNum];
    VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[cellNum]);

    curCallCnt = pCell->cfg.assignedSymmRoHCCellCallCount;
    pCell->cfg.assignedSymmRoHCCellCallCount++;

    newCallCnt = pCell->cfg.assignedSymmRoHCCellCallCount;

    VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[cellNum]);

    VCCB_PRINT_LOG_ROHC(ptCi, "assignedSymmRoHCCellCallCount++ (CellNum:[%d] count:[%d]=>[%d]) \n", cellNum,
        curCallCnt, newCallCnt);
    
    ptCi->rrcConnStat.markedCellNumForSymmRoHCRrcConnStat = cellNum;
    ptCi->isSymmRoHCCall = VCCB_FLAG_ON;

    return;
}

void FnVCCB_addSymmRoHCDrbCountInRrcConn(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdx, MAX_DRB_PER_SA_CALL);

    uint8_t selected5Qi = 0;
    uint16_t drbQosIdxInCall;
    uint32_t curCallCnt = 0;
    uint32_t newCallCnt = 0;

    callDRBInfo_type *ptDi = &ptCi->drb[drbIdx];

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        return;
    }

    if (ptDi->drbConnStat.SymmRoHCdrbCountFlagRrcConn == VCCB_FLAG_ON)  // Call Count collected already.
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "FnVCCB_addSymmRoHCDrbCountInRrcConn for drbIdx[%d] already collected\n",drbIdx);
        return;
    }

    drbQosIdxInCall = ptDi->drbQosIdxInCall;
    if (drbQosIdxInCall >= MAX_QOS_FLOW_PER_CALL ||
        !IS_VALID_NODE(QOSFLOW_NODE, ptCi, &(ptCi->qosFlow[drbQosIdxInCall])))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "%s representative qosFlow for drbIdx[%d] is invalid!!(callId:%d)\n", __func__, drbIdx, ptCi->callId);
        return;
    }

    VLIB_getFiveQi(&ptCi->qosFlow[drbQosIdxInCall], &selected5Qi);

    if (TRUE == ptCi->drb[drbIdx].rbInfo.pdcpInfo.headerCompression.symmetricRohcEnabled)
    {
        // increment SymmRohc ue num
        if (ptCi->isSymmRoHCCall == VCCB_FLAG_ON)
        {
            // Compare new values with marked value.
            // If Diff, then del/add cell call count.
            if(ptCi->rrcConnStat.markedCellNumForSymmRoHCRrcConnStat != cellNum)
            {
                FnVCCB_delSymmRoHCCellCallCount(ptCi, cellNum);
                FnVCCB_addSymmRoHCCellCallCount(ptCi, cellNum);
            }
        }
        else
        {
            FnVCCB_addSymmRoHCCellCallCount(ptCi, cellNum);
        }

        VccbCellInfo_type* const pCell = &CELLINFO[cellNum];
        VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[cellNum]);

        curCallCnt = pCell->cfg.assignedSymmRoHCDrbCountRrcConn[selected5Qi];

        pCell->cfg.assignedSymmRoHCDrbCountRrcConn[selected5Qi]++;

        newCallCnt = pCell->cfg.assignedSymmRoHCDrbCountRrcConn[selected5Qi];
        VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[cellNum]);

        VCCB_PRINT_LOG_ROHC(ptCi, "assignedSymmRoHCDrbCountRrcConn[5qi:%d]++ (CellNum:[%d] count:[%d]=>[%d]) \n", selected5Qi, cellNum,
            curCallCnt, newCallCnt);
        // Increment the ROHC allocated Sessions on every DRB addition.
        VCCB_PRINT_LOG_ROHC(ptCi, "Update CIDs after new DRB allocation. Current allocation was:[%d] Requested is:[%d]\n",
            ptCi->ueInfo.roHCCapability.curAllocatedRohcCid, ptCi->drb[drbIdx].rbInfo.pdcpInfo.headerCompression.symmetricRohcMaxSession);

        ptCi->ueInfo.roHCCapability.curAllocatedRohcCid = 
            (uint16_t)(ptCi->ueInfo.roHCCapability.curAllocatedRohcCid + 
                    ptCi->drb[drbIdx].rbInfo.pdcpInfo.headerCompression.symmetricRohcMaxSession);
        ptCi->ueInfo.roHCCapability.tempAllocatedRohcCid = 0;

        ptDi->drbConnStat.markedCellNumForSymmRoHCDrbRrcConnStat = cellNum;
        ptDi->drbConnStat.marked5qiForSymmRoHCDrbRrcConnStat = selected5Qi;
        ptDi->drbConnStat.SymmRoHCdrbCountFlagRrcConn = VCCB_FLAG_ON;
    }

    return;
}

void FnVCCB_addEHCDrbCountInRrcConn(callInfo_type *ptCi, uint16_t drbIdx, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdx, MAX_DRB_PER_SA_CALL);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    uint8_t selected5Qi = 0;
    uint16_t drbQosIdxInCall;

    callDRBInfo_type *ptDi = &ptCi->drb[drbIdx];

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        return;
    }

    if (ptDi->drbConnStat.EHCdrbCountFlagRrcConn == VCCB_FLAG_ON)  // Call Count collected already.
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "EHCdrbCountFlagRrcConn for drbIdx[%d] already collected\n", drbIdx);
        return;
    }

    drbQosIdxInCall = ptDi->drbQosIdxInCall;
    if (drbQosIdxInCall >= MAX_QOS_FLOW_PER_CALL ||
        !IS_VALID_NODE(QOSFLOW_NODE, ptCi, &(ptCi->qosFlow[drbQosIdxInCall])))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "%s representative qosFlow for drbIdx[%d] is invalid!!(callId:%d)\n", __func__, drbIdx, ptCi->callId);
        return;
    }

    VLIB_getFiveQi(&ptCi->qosFlow[drbQosIdxInCall], &selected5Qi);

    if (TRUE == ptCi->drb[drbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcEnabled)
    {
        ptCi->ueInfo.ehcCapability.curAllocatedEhcCid =
            (uint16_t)(ptCi->ueInfo.ehcCapability.curAllocatedEhcCid +
                       ptCi->drb[drbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_ul +
                       ptCi->drb[drbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl);

        ptCi->ueInfo.ehcCapability.tempAllocatedEhcCid = 0;
        ptDi->drbConnStat.marked5qiForEHCDrbRrcConnStat = selected5Qi;
        ptDi->drbConnStat.markedCellNumForEHCDrbRrcConnStat = cellNum;

        ptDi->drbConnStat.EHCdrbCountFlagRrcConn = VCCB_FLAG_ON;

        VCCB_PRINT_LOG_EHC(ptCi,
            "FnVCCB_addEHCDrbCountInRrcConn 5qi[%d] CellNum[%d] / curAllocatedEhcCid %d / Total "
            "Sessions %d\n",
            selected5Qi, cellNum, ptCi->ueInfo.ehcCapability.curAllocatedEhcCid,
            (ptCi->drb[drbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_ul +
                ptCi->drb[drbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl));
    }

    return;
}

/**
 * @brief        Decrement SA drb counter per cell per qci.
 * @details      This function is used to decrement SA drb count assigned to one cell.
 * @param [in]   cellNum: cell identifier
 * @param [in]   drbIdx: drb identifier
 * @return       GOOD, ERROR
 */
void FnVCCB_delSymmRoHCDrbCountInRrcConn(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdx)
{
    AUTO_TRACE_FUNC;

    uint8_t prev5Qi;
    uint16_t prevCellNum;
    uint16_t drbQosIdxInCall;
    uint32_t curCallCnt = 0;
    uint32_t newCallCnt = 0;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdx, MAX_DRB_PER_SA_CALL);

    callDRBInfo_type *ptDi = NULL;
    ptDi = &ptCi->drb[drbIdx];

    if (ptDi->drbConnStat.SymmRoHCdrbCountFlagRrcConn != VCCB_FLAG_ON)  // Call Count not collected, no deletion needed.
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "FnVCCB_delSymmRoHCDrbCountInRrcConn for drb[%d] already decremented\n", drbIdx);
        return;
    }

    // Get Saved 5Qi
    prevCellNum = ptDi->drbConnStat.markedCellNumForSymmRoHCDrbRrcConnStat;
    prev5Qi = ptDi->drbConnStat.marked5qiForSymmRoHCDrbRrcConnStat;

    VCCB_CHECK_E_RANGE_AND_VOID(prevCellNum, MAX_CELL_NUM_VCCB);
    // Always True..
    //VCCB_CHECK_E_RANGE_AND_VOID(prev5Qi, MAX_5QI_VALUE);

    drbQosIdxInCall = ptDi->drbQosIdxInCall;
    if (drbQosIdxInCall >= MAX_QOS_FLOW_PER_CALL ||
        !IS_VALID_NODE(QOSFLOW_NODE, ptCi, &(ptCi->qosFlow[drbQosIdxInCall])))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "%s representative qosFlow for drbIdx[%d] is invalid!!(callId:%d)\n", __func__, drbIdx, ptCi->callId);
        return;
    }

    {
        VccbCellInfo_type *const pCell = &CELLINFO[prevCellNum];

        VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[prevCellNum]);
        if (pCell->cfg.assignedSymmRoHCDrbCountRrcConn[prev5Qi] > 0)
        {
            curCallCnt = pCell->cfg.assignedSymmRoHCDrbCountRrcConn[prev5Qi];

            pCell->cfg.assignedSymmRoHCDrbCountRrcConn[prev5Qi]--;

            newCallCnt = pCell->cfg.assignedSymmRoHCDrbCountRrcConn[prev5Qi];
        }
        VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[prevCellNum]);

        // update ROHC Context count available after DRB deletion
        if (ptCi->ueInfo.roHCCapability.curAllocatedRohcCid > 0)
        {
            ptCi->ueInfo.roHCCapability.curAllocatedRohcCid = 
            (uint16_t)(ptCi->ueInfo.roHCCapability.curAllocatedRohcCid - 
                    ptCi->drb[drbIdx].rbInfo.pdcpInfo.headerCompression.symmetricRohcMaxSession);
        }

        ptDi->drbConnStat.SymmRoHCdrbCountFlagRrcConn = VCCB_FLAG_OFF;

        VCCB_PRINT_LOG_ROHC(ptCi,
            "assignedSymmRoHCDrbCountRrcConn[5qi:%d]-- (CellNum:[%d] count:[%d]=>[%d]) / curAllocatedRohcCid %d / Total "
            "Sessions %d\n",
            prev5Qi, prevCellNum, curCallCnt, newCallCnt, ptCi->ueInfo.roHCCapability.curAllocatedRohcCid,
            ptCi->drb[drbIdx].rbInfo.pdcpInfo.headerCompression.symmetricRohcMaxSession);
    }

    return;
}

/**
 * @brief        Decrement SA drb counter per cell per qci.
 * @details      This function is used to decrement SA drb count.
 * @param [in]   drbIdx: drb identifier
 * @return       GOOD, ERROR
 */
void FnVCCB_delEHCDrbCountInRrcConn(callInfo_type *ptCi, uint16_t drbIdx, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdx, MAX_DRB_PER_SA_CALL);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    uint16_t drbQosIdxInCall;
    callDRBInfo_type *ptDi = NULL;
    ptDi = &ptCi->drb[drbIdx];

    uint8_t prev5Qi = ptDi->drbConnStat.marked5qiForEHCDrbRrcConnStat;

    if (ptDi->drbConnStat.EHCdrbCountFlagRrcConn != VCCB_FLAG_ON)  // Call Count not collected, no deletion needed.
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "EHCdrbCountFlagRrcConn for drb[%d] already decremented\n", drbIdx);
        return;
    }

    drbQosIdxInCall = ptDi->drbQosIdxInCall;
    if (drbQosIdxInCall >= MAX_QOS_FLOW_PER_CALL ||
        !IS_VALID_NODE(QOSFLOW_NODE, ptCi, &(ptCi->qosFlow[drbQosIdxInCall])))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "%s representative qosFlow for drbIdx[%d] is invalid!!(callId:%d)\n", __func__, drbIdx, ptCi->callId);
        return;
    }

    {
        // update EHC Context count available after DRB deletion
        if (ptCi->ueInfo.ehcCapability.curAllocatedEhcCid > 0)
        {
            ptCi->ueInfo.ehcCapability.curAllocatedEhcCid =
                (uint16_t)(ptCi->ueInfo.ehcCapability.curAllocatedEhcCid -
                           (ptCi->drb[drbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_ul +
                           ptCi->drb[drbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl));
        }

        ptDi->drbConnStat.EHCdrbCountFlagRrcConn = VCCB_FLAG_OFF;

        VCCB_PRINT_LOG_EHC(ptCi,
            "FnVCCB_delEHCDrbCountInRrcConn 5qi[%d] CellNum[%d] / curAllocatedEhcCid %d / Total "
            "Sessions %d\n",
            prev5Qi, cellNum, ptCi->ueInfo.ehcCapability.curAllocatedEhcCid,
            (ptCi->drb[drbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_ul +
                ptCi->drb[drbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl));
    }

    return;
}

/**
 * @brief        update SA drb counter per cell per qci.
 * @details      This function is used to update SA drb count assigned to one cell.
 * @param [in]   ptCi
 * @return       GOOD, ERROR
 */
void FnVCCB_CompareAndAddRohcDrbCountInRrcInact(callInfo_type *ptCi, uint16_t cellNum, uint16_t callDrbIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(callDrbIdx, MAX_DRB_PER_SA_CALL);

    uint8_t selected5Qi;
    uint16_t qosIdxInCall;

    qosIdxInCall = ptCi->drb[callDrbIdx].drbQosIdxInCall;
    VCCB_CHECK_E_RANGE_AND_VOID(qosIdxInCall, MAX_QOS_FLOW_PER_CALL);
    
    // Get New Requested Value
    VLIB_getFiveQi(&ptCi->qosFlow[qosIdxInCall], &selected5Qi);

    if ((ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.headerCompression.ulRohcEnabled == TRUE) &&
        (ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.headerCompression.useProfile006 == TRUE))
    {
        // at least one DRB  with Ul rohc enabled.
        if (ptCi->drb[callDrbIdx].drbConnStat.UlRoHCdrbCountFlagRrcInact == VCCB_FLAG_ON)  // Call Count collected already.
        {
            // Compare new values with marked value.
            // If Diff, then del/add drb count.
            if ((ptCi->drb[callDrbIdx].drbConnStat.markedCellNumForUlRoHCDrbRrcInactStat != cellNum) ||
                (ptCi->drb[callDrbIdx].drbConnStat.marked5qiForUlRoHCDrbRrcInactStat != selected5Qi))
            {
                FnVCCB_delULRoHCDrbCountInRrcInact(ptCi, cellNum, callDrbIdx);
                FnVCCB_addULRoHCDrbCountInRrcInact(ptCi, cellNum, callDrbIdx);
            }
        }
        else
        {
            FnVCCB_addULRoHCDrbCountInRrcInact(ptCi, cellNum, callDrbIdx);
        }
    }

    if (ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.headerCompression.symmetricRohcEnabled == TRUE)
    {
        // at least one DRB  with Symmteric rohc enabled.
        if (ptCi->drb[callDrbIdx].drbConnStat.SymmRoHCdrbCountFlagRrcInact == VCCB_FLAG_ON)  // Call Count collected already.
        {
            // Compare new values with marked value.
            // If Diff, then del/add drb count.
            if ((ptCi->drb[callDrbIdx].drbConnStat.markedCellNumForSymmRoHCDrbRrcInactStat != cellNum) ||
                (ptCi->drb[callDrbIdx].drbConnStat.marked5qiForSymmRoHCDrbRrcInactStat != selected5Qi))
            {
                FnVCCB_delSymmRoHCDrbCountInRrcInact(ptCi, cellNum, callDrbIdx);
                FnVCCB_addSymmRoHCDrbCountInRrcInact(ptCi, cellNum, callDrbIdx);
            }
        }
        else
        {
            FnVCCB_addSymmRoHCDrbCountInRrcInact(ptCi, cellNum, callDrbIdx);
        }
    }

    return;
}

/**
 * @brief        update SA drb counter per cell per qci.
 * @details      This function is used to update SA drb count.
 * @param [in]   ptCi
 * @return       GOOD, ERROR
 */
void FnVCCB_CompareAndAddEhcDrbCountInRrcInact(callInfo_type *ptCi, uint16_t callDrbIdx, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(callDrbIdx, MAX_DRB_PER_SA_CALL);

    uint8_t selected5Qi;
    uint16_t qosIdxInCall;

    qosIdxInCall = ptCi->drb[callDrbIdx].drbQosIdxInCall;
    VCCB_CHECK_E_RANGE_AND_VOID(qosIdxInCall, MAX_QOS_FLOW_PER_CALL);

    // Get New Requested Value
    VLIB_getFiveQi(&ptCi->qosFlow[qosIdxInCall], &selected5Qi);

    if (ptCi->drb[callDrbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcEnabled == TRUE)
    {
        // at least one DRB  with Ehc enabled.
        if (ptCi->drb[callDrbIdx].drbConnStat.EHCdrbCountFlagRrcInact == VCCB_FLAG_ON)  // Call Count collected already.
        {
            // Compare new values with marked value.
            // If Diff, then del/add drb count.
            if ((ptCi->drb[callDrbIdx].drbConnStat.marked5qiForEHCDrbRrcInactStat != selected5Qi) ||
                (ptCi->drb[callDrbIdx].drbConnStat.markedCellNumForEHCDrbRrcInactStat != cellNum))
            {
                FnVCCB_delEHCDrbCountInRrcInact(ptCi, callDrbIdx, cellNum);
                FnVCCB_addEHCDrbCountInRrcInact(ptCi, callDrbIdx, cellNum);
            }
        }
        else
        {
            FnVCCB_addEHCDrbCountInRrcInact(ptCi, callDrbIdx, cellNum);
        }
    }

    return;
}

void FnVCCB_delULRoHCDrbCountInRrcInact(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdx, MAX_DRB_PER_SA_CALL);

    uint8_t prev5Qi;
    uint16_t prevCellNum;
    uint16_t drbQosIdxInCall;
    uint32_t curCallCnt = 0;
    uint32_t newCallCnt = 0;

    callDRBInfo_type *ptDi = &ptCi->drb[drbIdx];

    if (ptDi->drbConnStat.UlRoHCdrbCountFlagRrcInact != VCCB_FLAG_ON)  // Call Count not collected, no deletion needed.
    {
        return;
    }

    // Get Saved 5Qi
    prevCellNum = ptDi->drbConnStat.markedCellNumForUlRoHCDrbRrcInactStat;
    prev5Qi = ptDi->drbConnStat.marked5qiForUlRoHCDrbRrcInactStat;

    VCCB_CHECK_E_RANGE_AND_VOID(prevCellNum, MAX_CELL_NUM_VCCB);
    // Always True..
    //VCCB_CHECK_E_RANGE_AND_VOID(prev5Qi, MAX_5QI_VALUE);

    drbQosIdxInCall = ptDi->drbQosIdxInCall;
    if (drbQosIdxInCall >= MAX_QOS_FLOW_PER_CALL ||
        !IS_VALID_NODE(QOSFLOW_NODE, ptCi, &(ptCi->qosFlow[drbQosIdxInCall])))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "%s representative qosFlow for drbIdx[%d] is invalid!!(callId:%d)\n", __func__, drbIdx, ptCi->callId);
        return;
    }

    {
        VccbCellInfo_type *const pCell = &CELLINFO[prevCellNum];

        VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[prevCellNum]);
        if (pCell->cfg.assignedULOnlyRoHCDrbCountRrcInact[prev5Qi] > 0)
        {
            curCallCnt = pCell->cfg.assignedULOnlyRoHCDrbCountRrcInact[prev5Qi];

            pCell->cfg.assignedULOnlyRoHCDrbCountRrcInact[prev5Qi]--;

            newCallCnt = pCell->cfg.assignedULOnlyRoHCDrbCountRrcInact[prev5Qi];
        }
        VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[prevCellNum]);

        // update ROHC Context count available after DRB deletion
        if (ptCi->ueInfo.roHCCapability.curAllocatedRohcCid > 0)
        {
            ptCi->ueInfo.roHCCapability.curAllocatedRohcCid = 
            (uint16_t)(ptCi->ueInfo.roHCCapability.curAllocatedRohcCid - 
                    ptCi->drb[drbIdx].rbInfo.pdcpInfo.headerCompression.ulRohcMaxSession);
        }     

        ptDi->drbConnStat.UlRoHCdrbCountFlagRrcInact = VCCB_FLAG_OFF;

        VCCB_PRINT_LOG_ROHC(ptCi,
            "assignedULOnlyRoHCDrbCountRrcInact[5qi:%d]-- (CellNum[%d] count:[%d]=>[%d]) / curAllocatedRohcCid %d / Total "
            "Sessions %d\n",
            prev5Qi, prevCellNum, curCallCnt, newCallCnt, ptCi->ueInfo.roHCCapability.curAllocatedRohcCid,
            ptCi->drb[drbIdx].rbInfo.pdcpInfo.headerCompression.ulRohcMaxSession);
    }

    return;
}

void FnVCCB_addULRoHCDrbCountInRrcInact(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdx)
{
    AUTO_TRACE_FUNC;

    uint8_t selected5Qi = 0;
    uint16_t drbQosIdxInCall;
    uint32_t curCallCnt = 0;
    uint32_t newCallCnt = 0;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdx, MAX_DRB_PER_SA_CALL);

    callDRBInfo_type *ptDi = &ptCi->drb[drbIdx];

    if (ptDi->drbConnStat.UlRoHCdrbCountFlagRrcInact == VCCB_FLAG_ON)  // Call Count collected already.
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "FnVCCB_addULRoHCDrbCountInRrcInact for drbIdx[%d] already collected\n",drbIdx);
        return;
    }

    drbQosIdxInCall = ptDi->drbQosIdxInCall;
    if (drbQosIdxInCall >= MAX_QOS_FLOW_PER_CALL ||
        !IS_VALID_NODE(QOSFLOW_NODE, ptCi, &(ptCi->qosFlow[drbQosIdxInCall])))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "%s representative qosFlow for drbIdx[%d] is invalid!!(callId:%d)\n", __func__, drbIdx, ptCi->callId);
        return;
    }

    VLIB_getFiveQi(&ptCi->qosFlow[drbQosIdxInCall], &selected5Qi);

    VccbCellInfo_type* const pCell = &CELLINFO[cellNum];
    VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[cellNum]);

    curCallCnt = pCell->cfg.assignedULOnlyRoHCDrbCountRrcInact[selected5Qi];

    pCell->cfg.assignedULOnlyRoHCDrbCountRrcInact[selected5Qi]++;

    newCallCnt = pCell->cfg.assignedULOnlyRoHCDrbCountRrcInact[selected5Qi];
    VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[cellNum]);

    VCCB_PRINT_LOG_ROHC(ptCi, "assignedULOnlyRoHCDrbCountRrcInact[5qi:%d]++ (CellNum:[%d] count:[%d]=>[%d]) \n", selected5Qi, cellNum,
        curCallCnt, newCallCnt);
    // Increment the ROHC allocated Sessions on every DRB addition.
    VCCB_PRINT_LOG_ROHC(ptCi, "Update CIDs after new DRB allocation. Current allocation was:[%d] Requested is:[%d]\n",
        ptCi->ueInfo.roHCCapability.curAllocatedRohcCid, ptCi->drb[drbIdx].rbInfo.pdcpInfo.headerCompression.ulRohcMaxSession);

    ptCi->ueInfo.roHCCapability.curAllocatedRohcCid = 
        (uint16_t)(ptCi->ueInfo.roHCCapability.curAllocatedRohcCid + 
                ptCi->drb[drbIdx].rbInfo.pdcpInfo.headerCompression.ulRohcMaxSession);
    
    ptCi->ueInfo.roHCCapability.tempAllocatedRohcCid = 0;

    ptDi->drbConnStat.markedCellNumForUlRoHCDrbRrcInactStat = cellNum;
    ptDi->drbConnStat.marked5qiForUlRoHCDrbRrcInactStat = selected5Qi;
    ptDi->drbConnStat.UlRoHCdrbCountFlagRrcInact = VCCB_FLAG_ON;

    return;
}

void FnVCCB_delSymmRoHCDrbCountInRrcInact(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdx)
{
    AUTO_TRACE_FUNC;

    uint8_t prev5Qi;
    uint16_t prevCellNum;
    uint16_t drbQosIdxInCall;
    uint32_t curCallCnt = 0;
    uint32_t newCallCnt = 0;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdx, MAX_DRB_PER_SA_CALL);

    callDRBInfo_type *ptDi = &ptCi->drb[drbIdx];

    if (ptDi->drbConnStat.SymmRoHCdrbCountFlagRrcInact != VCCB_FLAG_ON)  // Call Count not collected, no deletion needed.
    {
        return;
    }

    // Get Saved 5Qi
    prevCellNum = ptDi->drbConnStat.markedCellNumForSymmRoHCDrbRrcInactStat;
    prev5Qi = ptDi->drbConnStat.marked5qiForSymmRoHCDrbRrcInactStat;

    VCCB_CHECK_E_RANGE_AND_VOID(prevCellNum, MAX_CELL_NUM_VCCB);
    // Always True..
    //VCCB_CHECK_E_RANGE_AND_VOID(prev5Qi, MAX_5QI_VALUE);

    drbQosIdxInCall = ptDi->drbQosIdxInCall;
    if (drbQosIdxInCall >= MAX_QOS_FLOW_PER_CALL ||
        !IS_VALID_NODE(QOSFLOW_NODE, ptCi, &(ptCi->qosFlow[drbQosIdxInCall])))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "%s representative qosFlow for drbIdx[%d] is invalid!!(callId:%d)\n", __func__, drbIdx, ptCi->callId);
        return;
    }

    {
        VccbCellInfo_type *const pCell = &CELLINFO[prevCellNum];

        VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[prevCellNum]);
        if (pCell->cfg.assignedSymmRoHCDrbCountRrcInact[prev5Qi] > 0)
        {
            curCallCnt = pCell->cfg.assignedSymmRoHCDrbCountRrcInact[prev5Qi];

            pCell->cfg.assignedSymmRoHCDrbCountRrcInact[prev5Qi]--;

            newCallCnt = pCell->cfg.assignedSymmRoHCDrbCountRrcInact[prev5Qi];
        }
        VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[prevCellNum]);

        // update ROHC Context count available after DRB deletion
        if (ptCi->ueInfo.roHCCapability.curAllocatedRohcCid > 0)
        {
            ptCi->ueInfo.roHCCapability.curAllocatedRohcCid = 
            (uint16_t)(ptCi->ueInfo.roHCCapability.curAllocatedRohcCid - 
                    ptCi->drb[drbIdx].rbInfo.pdcpInfo.headerCompression.symmetricRohcMaxSession);
        }

        ptDi->drbConnStat.SymmRoHCdrbCountFlagRrcInact = VCCB_FLAG_OFF;

        VCCB_PRINT_LOG_ROHC(ptCi,
            "assignedSymmRoHCDrbCountRrcInact[5qi:%d]-- (CellNum[%d] count:[%d]=>[%d]) / curAllocatedRohcCid %d / Total "
            "Sessions %d\n",
            prev5Qi, prevCellNum, curCallCnt, newCallCnt, ptCi->ueInfo.roHCCapability.curAllocatedRohcCid,
            ptCi->drb[drbIdx].rbInfo.pdcpInfo.headerCompression.symmetricRohcMaxSession);
    }

    return;
}

void FnVCCB_delEHCDrbCountInRrcInact(callInfo_type *ptCi, uint16_t drbIdx, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    uint16_t drbQosIdxInCall;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdx, MAX_DRB_PER_SA_CALL);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    callDRBInfo_type *ptDi = &ptCi->drb[drbIdx];
    uint8_t prev5Qi = ptDi->drbConnStat.marked5qiForEHCDrbRrcInactStat;

    if (ptDi->drbConnStat.EHCdrbCountFlagRrcInact != VCCB_FLAG_ON)  // Call Count not collected, no deletion needed.
    {
        return;
    }

    drbQosIdxInCall = ptDi->drbQosIdxInCall;
    if (drbQosIdxInCall >= MAX_QOS_FLOW_PER_CALL ||
        !IS_VALID_NODE(QOSFLOW_NODE, ptCi, &(ptCi->qosFlow[drbQosIdxInCall])))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "%s representative qosFlow for drbIdx[%d] is invalid!!(callId:%d)\n", __func__, drbIdx, ptCi->callId);
        return;
    }

    {
        // update EHC Context count available after DRB deletion
        if (ptCi->ueInfo.ehcCapability.curAllocatedEhcCid > 0)
        {
            ptCi->ueInfo.ehcCapability.curAllocatedEhcCid =
                (uint16_t)(ptCi->ueInfo.ehcCapability.curAllocatedEhcCid -
                           (ptCi->drb[drbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_ul +
                           ptCi->drb[drbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl));
        }

        ptDi->drbConnStat.EHCdrbCountFlagRrcInact = VCCB_FLAG_OFF;

        VCCB_PRINT_LOG_EHC(ptCi,
            "FnVCCB_delEHCDrbCountInRrcInact 5qi[%d] CellNum[%d] / curAllocatedEhcCid %d / Total "
            "Sessions %d\n",
            prev5Qi, cellNum, ptCi->ueInfo.ehcCapability.curAllocatedEhcCid,
            (ptCi->drb[drbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_ul +
                ptCi->drb[drbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl));
    }

    return;
}

// FGR-CC5200:FR740 FR750
void FnVCCB_CompareAndAddNrdcSnTermDrbCount(callInfo_type *ptCi, uint16_t newCellNum, uint16_t drbIdxInCall)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(newCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdxInCall, MAX_DRB_PER_SA_CALL);

    if (!IS_SUPPORT_CollectNrdcSnTermDrbConnStats(ptCi))
    {
        return;
    }

    callDRBInfo_type &drb = ptCi->drb[drbIdxInCall];
    uint8_t selected5Qi = 0;

    if (drb.drbConnStat.drbCountFlagOfRrcConn == FLAG_ON)  // Call Count collected already.
    {
        uint16_t qosIdxInCall = drb.drbQosIdxInCall;;
        VCCB_CHECK_E_RANGE_AND_VOID(qosIdxInCall, MAX_QOS_FLOW_PER_CALL);

        // Get New Requested Value
        VLIB_getFiveQi(&ptCi->qosFlow[qosIdxInCall], &selected5Qi);
        uint8_t plmnIdx = VLIB_findCellPlmnIndex(newCellNum, ptCi->ueInfo.servedPlmn.longId);

        // del/add snTermDrbConn count if key values(cellNum, plmnIdx, 5qi) are changed.
        if (drb.drbConnStat.markedCellNumForDrbConnStatOfRrcConn != newCellNum ||
            drb.drbConnStat.marked5qiForDrbConnStatOfRrcConn != selected5Qi ||
            drb.drbConnStat.markedPlmnIdxForDrbConnStatOfRrcConn != plmnIdx)
        {
            FnVCCB_NrdcSnTermDrbConnInfoStatsCmd(ptCi, drb.drbConnStat.markedCellNumForDrbConnStatOfRrcConn, drbIdxInCall, ConnInfoStatsCmd_Decrease);
            FnVCCB_NrdcSnTermDrbConnInfoStatsCmd(ptCi, newCellNum, drbIdxInCall, ConnInfoStatsCmd_Increase);
        }
    }
    else
    {
        FnVCCB_NrdcSnTermDrbConnInfoStatsCmd(ptCi, newCellNum, drbIdxInCall, ConnInfoStatsCmd_Increase);
    }
}

// FGR-CC5200:FR740 FR750
void FnVCCB_UpdateAllNrdcSnTermDrbCountAndHoldTime(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    uint16_t callDrbIdx = 0;
    bool isIntraSNMobility = false;

    if (!IS_SUPPORT_CollectNrdcSnTermDrbConnStats(ptCi))
    {
        return;
    }

    switch (ptCi->hoInfo.hoType.initiated)
    {
        case HO_TYPE_SA_MGNB_INITIATED:
        case HO_TYPE_SA_MGNB_INTERMNHO:
        case HO_TYPE_SA_SGNB_INITIATED:
        case HO_TYPE_SA_MN_INIT_SCG_RESUME:
            isIntraSNMobility = true;
            break;
        default:
            break;
    }

    for (callDrbIdx = 0; callDrbIdx < MAX_DRB_PER_SA_CALL; callDrbIdx++)
    {
        callDRBInfo_type &drb = ptCi->drb[callDrbIdx];

        if (CI_use != drb.usage) continue;
        if (drb.bearerType.val != SN_Term_SCG_Bearer && drb.bearerType.val != SN_Term_SPLIT_Bearer)
        {
            continue;
        }

        FnVCCB_CompareAndAddNrdcSnTermDrbCount(ptCi, cellNum, callDrbIdx);
        if (isIntraSNMobility)
        {
            // Keep HoldingTime. Don't need to start Stopwatch
        }
        else
        {
            FnVCCB_NrdcSnTermDrbConnInfoStatsCmd(ptCi, cellNum, callDrbIdx, ConnInfoStatsCmd_HoldingTimeStart);
        }
    }
}

void FnVCCB_addSymmRoHCDrbCountInRrcInact(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdx, MAX_DRB_PER_SA_CALL);

    uint8_t selected5Qi = 0;
    uint16_t drbQosIdxInCall;
    uint32_t curCallCnt = 0;
    uint32_t newCallCnt = 0;

    callDRBInfo_type *ptDi = &ptCi->drb[drbIdx];

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        return;
    }

    if (ptDi->drbConnStat.SymmRoHCdrbCountFlagRrcInact == VCCB_FLAG_ON)  // Call Count collected already.
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "FnVCCB_addSymmRoHCDrbCountInRrcInact for drbIdx[%d] already collected\n",drbIdx);
        return;
    }

    drbQosIdxInCall = ptDi->drbQosIdxInCall;
    if (drbQosIdxInCall >= MAX_QOS_FLOW_PER_CALL ||
        !IS_VALID_NODE(QOSFLOW_NODE, ptCi, &(ptCi->qosFlow[drbQosIdxInCall])))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "%s representative qosFlow for drbIdx[%d] is invalid!!(callId:%d)\n", __func__, drbIdx, ptCi->callId);
        return;
    }

    VLIB_getFiveQi(&ptCi->qosFlow[drbQosIdxInCall], &selected5Qi);

    VccbCellInfo_type* const pCell = &CELLINFO[cellNum];
    VRRM_MUTEX_LOCK(&gVrrmCellCfgMtx[cellNum]);

    curCallCnt = pCell->cfg.assignedSymmRoHCDrbCountRrcInact[selected5Qi];

    pCell->cfg.assignedSymmRoHCDrbCountRrcInact[selected5Qi]++;

    newCallCnt = pCell->cfg.assignedSymmRoHCDrbCountRrcInact[selected5Qi];
    VRRM_MUTEX_UNLOCK(&gVrrmCellCfgMtx[cellNum]);

    VCCB_PRINT_LOG_ROHC(ptCi, "assignedSymmRoHCDrbCountRrcInact[5qi:%d]++ (CellNum:[%d] count:[%d]=>[%d]) \n", selected5Qi, cellNum,
        curCallCnt, newCallCnt);
    // Increment the ROHC allocated Sessions on every DRB addition.
    VCCB_PRINT_LOG_ROHC(ptCi, "Update CIDs after new DRB allocation. Current allocation was:[%d] Requested is:[%d]\n",
        ptCi->ueInfo.roHCCapability.curAllocatedRohcCid, ptCi->drb[drbIdx].rbInfo.pdcpInfo.headerCompression.symmetricRohcMaxSession);

    ptCi->ueInfo.roHCCapability.curAllocatedRohcCid = 
        (uint16_t)(ptCi->ueInfo.roHCCapability.curAllocatedRohcCid + 
                ptCi->drb[drbIdx].rbInfo.pdcpInfo.headerCompression.symmetricRohcMaxSession);
    
    ptCi->ueInfo.roHCCapability.tempAllocatedRohcCid = 0;

    ptDi->drbConnStat.markedCellNumForSymmRoHCDrbRrcInactStat = cellNum;
    ptDi->drbConnStat.marked5qiForSymmRoHCDrbRrcInactStat = selected5Qi;
    ptDi->drbConnStat.SymmRoHCdrbCountFlagRrcInact = VCCB_FLAG_ON;   

    return;
}

void FnVCCB_addEHCDrbCountInRrcInact(callInfo_type *ptCi, uint16_t drbIdx, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdx, MAX_DRB_PER_SA_CALL);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    uint8_t selected5Qi = 0;
    uint16_t drbQosIdxInCall;

    callDRBInfo_type *ptDi = &ptCi->drb[drbIdx];

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        return;
    }

    if (ptDi->drbConnStat.EHCdrbCountFlagRrcInact == VCCB_FLAG_ON)  // Call Count collected already.
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "EHCdrbCountFlagRrcInact for drbIdx[%d] already collected\n", drbIdx);
        return;
    }

    drbQosIdxInCall = ptDi->drbQosIdxInCall;
    if (drbQosIdxInCall >= MAX_QOS_FLOW_PER_CALL ||
        !IS_VALID_NODE(QOSFLOW_NODE, ptCi, &(ptCi->qosFlow[drbQosIdxInCall])))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "%s representative qosFlow for drbIdx[%d] is invalid!!(callId:%d)\n", __func__, drbIdx, ptCi->callId);
        return;
    }

    VLIB_getFiveQi(&ptCi->qosFlow[drbQosIdxInCall], &selected5Qi);

    ptCi->ueInfo.ehcCapability.curAllocatedEhcCid =
        (uint16_t)(ptCi->ueInfo.ehcCapability.curAllocatedEhcCid +
                   ptCi->drb[drbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_ul +
                   ptCi->drb[drbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl);

    ptCi->ueInfo.ehcCapability.tempAllocatedEhcCid = 0;

    ptDi->drbConnStat.marked5qiForEHCDrbRrcInactStat = selected5Qi;
    ptDi->drbConnStat.markedCellNumForEHCDrbRrcInactStat = cellNum;
    ptDi->drbConnStat.EHCdrbCountFlagRrcInact = VCCB_FLAG_ON;

    VCCB_PRINT_LOG_EHC(ptCi,
            "FnVCCB_addEHCDrbCountInRrcInact 5qi[%d] CellNum[%d] / curAllocatedEhcCid %d / Total "
            "Sessions %d\n",
            selected5Qi, cellNum, ptCi->ueInfo.ehcCapability.curAllocatedEhcCid,
            (ptCi->drb[drbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_ul +
                ptCi->drb[drbIdx].rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl));

    return;
}
