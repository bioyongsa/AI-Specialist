#include "ComCoreAffinity.h"

uint8_t ComCoreAffinity::GetIrqCoreCount(void)
{
    constexpr uint8_t MINIMUM_NUM_OF_VCORES_TO_SEPARATE_IRQ_VCORES = 8;
    constexpr uint8_t IRQ_CORES_FOR_MAX = 3;

    if (CORE_NUM_VCCB < MINIMUM_NUM_OF_VCORES_TO_SEPARATE_IRQ_VCORES)
    {
        return 0; // No affinity for IRQ
    }
    if (CORE_NUM_VCCB >= MINIMUM_NUM_OF_VCORES_TO_SEPARATE_IRQ_VCORES && CORE_NUM_VCCB < 22)
    {
        return 1;
    }
    if (CORE_NUM_VCCB >= 22 && CORE_NUM_VCCB < 34)
    {
        return 2;
    }
    
    // CORE_NUM_VCCB >= 34
    return IRQ_CORES_FOR_MAX; 
}

#if defined(__VNF__) && !defined(NEW_HOST_SIM)
void ComCoreAffinity::InitHasAffinity(void)
{
    if (e_VCCB_ACPF_VNF != VCOM_getSystemType()) return;

    // Set CPU Affinity to avoid IRQ cores (# of IRQ cores may vary depend on VNF flavors)
    uint8_t firstCore = ComCoreAffinity::GetIrqCoreCount();
    uint8_t lastCore = static_cast<uint8_t>(CORE_NUM_VCCB - 1);

    VCCB_PRINTF("[DBG] hasSetCpuAffinity -> s: %u, l: %u\n", firstCore, lastCore);

    int ret = hasSetCpuAffinity(firstCore, lastCore);
    if (ret < 0)
    {
        VCCB_PRINTF("hasSetCpuAffinity Error (%d)\n", ret);
    }
}
#endif

void ComCoreAffinity::InitCallThreadAffinityForNVGNB(const uint8_t myThreadId)
{
    AUTO_TRACE_FUNC;
    if (e_VCCB_NVGNB != VCOM_getSystemType()) return;

    // Set dedicated core per callThread (one by one)
    cpu_set_t mask;
    CPU_ZERO(&mask);

    uint8_t firstCore = static_cast<uint8_t>(CORE_NUM_VCCB - MAX_CALL_THREAD_NUM_VCCB);
    if (firstCore > CORE_NUM_VCCB)
    {
        firstCore = 0;
    }

    VCCB_PRINTF(" CORE_NUM_VCCB = %d, callBaseCpuId = %d\n", CORE_NUM_VCCB, firstCore);
    CPU_SET(static_cast<size_t>(firstCore + (myThreadId % MAX_CALL_THREAD_NUM_VCCB)), &mask);

    const int rc = sched_setaffinity(0, sizeof(cpu_set_t), &mask);
    if (rc < 0)
    {
        VCCB_PRINT_CRITICAL("sched_setaffinity ERROR(rc=%d) in %s\n", rc, __func__);
        perror("sched_setaffinity\n");
#ifdef VCCB_IPC_TEST
        throw std::runtime_error("sched_setaffinity failed");
#else
        VCCB_EXIT(EXIT_SCHED_SETAFFINITY_FAIL);
#endif
    }
}

void ComCoreAffinity::InitWorkerThreadAffinityForVNF(enumVccbTaskAffinity_type affinityType)
{
    /**
     * Default Task Affinity Policy for VCCB (as of SVR25A)
     * (Contact jw97.son, youngdong77.lee, swson for more details.)
     * 
     * 1. If there are extra vCores available (hasExtraCores is true):
     *    - CALL TASK       : All cores from firstCore and ending just before lastCore
     *    - STATISTICS TASK : Only the last core
     *    - DEFAULT         : All cores from firstCore to lastCore
     *    e.g., [--IRQ--][--------------CALL--------------][-STAT-]
     *                   [-----------AUDIT/OAM/PLD/etc.-----------]
     * 
     * 2. If there are no extra vCores:
     *    - All cores from firstCore to lastCore
     *    e.g., [--IRQ--][----------CALL/STAT/AUDIT/etc.----------]
     */

    AUTO_TRACE_FUNC;
    if (e_VCCB_ACPF_VNF != VCOM_getSystemType()) return;

    uint8_t NUM_OF_IRQ_VCORES = ComCoreAffinity::GetIrqCoreCount();
    if (NUM_OF_IRQ_VCORES < 1) return; // No affinity for IRQ

    const uint8_t firstCore = NUM_OF_IRQ_VCORES;
    const uint8_t lastCore = static_cast<uint8_t>(CORE_NUM_VCCB - 1);
    const bool hasExtraCores = (CORE_NUM_VCCB - (NUM_OF_IRQ_VCORES + MAX_CALL_THREAD_NUM_VCCB) > 0);

    cpu_set_t mask;
    CPU_ZERO(&mask);

    if (hasExtraCores) 
    {
        switch (affinityType) 
        {
            case VCCB_TASK_AFFINITY_CALL:
                // CALL TASK: firstCore ~ lastCore-1
                for (uint8_t i = firstCore; i < lastCore; ++i) CPU_SET(i, &mask);
                break;
            case VCCB_TASK_AFFINITY_STAT:
                // STATISTICS TASK: lastCore only
                CPU_SET(lastCore, &mask);
                break;
            default:
                // DEFAULT: firstCore ~ lastCore
                for (uint8_t i = firstCore; i <= lastCore; ++i) CPU_SET(i, &mask);
        }
    }
    else 
    {
        // No extra cores: Use all cores (except IRQ cores)
        for (uint8_t i = firstCore; i <= lastCore; ++i) CPU_SET(i, &mask);
    }

    const int rc = sched_setaffinity(0, sizeof(cpu_set_t), &mask);
    if (rc < 0)
    {
        VCCB_PRINT_CRITICAL("sched_setaffinity ERROR(rc=%d) in %s\n", rc, __func__);
        perror("sched_setaffinity\n");
#ifdef VCCB_IPC_TEST
        throw std::runtime_error("sched_setaffinity failed");
#else
        VCCB_EXIT(EXIT_SCHED_SETAFFINITY_FAIL);
#endif
    }
    return;
}