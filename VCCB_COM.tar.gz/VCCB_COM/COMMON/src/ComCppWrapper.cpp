/**
 * @file     : MainCppWrapper.cpp
 * @brief   : source of
 *
 * @author   : hohyun.kang@samsung.com
 * @date     : 2018/12/06
 *
 * Copyright 2018 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#include "ComCppWrapper.h"
#include "ComInclude.h"
#include "ComSystemMonitor.hpp"
#include "ComLibUtility.h"
#include "IRNTIManager.h"
#include "MsgQueueManager.h"

#define VCCB_PRINT_ON_EXCEPTION_ERROR(__fmt, __args...)                              \
    catch (const std::exception &e)                                                  \
    {                                                                                \
        VCCB_PRINTF("Exception(f:%s):(C:%s): " __fmt, __func__, e.what(), ##__args); \
        return ERROR;                                                                \
    }                                                                                \
    catch (...)                                                                      \
    {                                                                                \
        VCCB_PRINTF("Exception(f:%s):(C:Unknown): " __fmt, __func__, ##__args);      \
        return ERROR;                                                                \
    }

#define VCCB_PRINT_ON_EXCEPTION_NULL(__fmt, __args...)                               \
    catch (const std::exception &e)                                                  \
    {                                                                                \
        VCCB_PRINTF("Exception(f:%s):(C:%s): " __fmt, __func__, e.what(), ##__args); \
        return NULL;                                                                 \
    }                                                                                \
    catch (...)                                                                      \
    {                                                                                \
        VCCB_PRINTF("Exception(f:%s):(C:Unknown): " __fmt, __func__, ##__args);      \
        return NULL;                                                                 \
    }

#define VCCB_PRINT_ON_EXCEPTION_VOID(__fmt, __args...)                                                               \
    catch (const std::exception &e) { VCCB_PRINTF("Exception(f:%s):(C:%s): " __fmt, __func__, e.what(), ##__args); } \
    catch (...) { VCCB_PRINTF("Exception(f:%s):(C:Unknown): " __fmt, __func__, ##__args); }

/***************************************************************************
 * g_systemMonitor ::
 **************************************************************************/

static ComSystemMonitor g_systemMonitor;  // [SAM_GV_IMPROVEMENT]

int getMaxCpuNum(void)
{
    AUTO_TRACE_FUNC;

    int maxCpuNum = 1;

    try
    {
        maxCpuNum = g_systemMonitor.getMaxCpuNum();
    }
    VCCB_PRINT_ON_EXCEPTION_ERROR("HAL(getMaxCpuNum) Error!\n");

    return maxCpuNum;
}

int getCpuLoad3sec(const int cpuId)
{
    AUTO_TRACE_FUNC;

    int cpuLoad = 0;

    try
    {
        cpuLoad = g_systemMonitor.getCpuLoad3sec(cpuId);
    }
    VCCB_PRINT_ON_EXCEPTION_ERROR("HAL(getCpuLoad3sec) Error!\n");

    return cpuLoad;
}

/***************************************************************************
 * nbrReadQue :: queue<unsigned short>
 **************************************************************************/

static queue<unsigned short> nbrReadQue;
static char nbrGnbReadQueueFlag[MAX_GNB_CU_CP_FUNCTION_PER_SYS] = {
    false,
};  // NBR_AUDIT_22B

void pushNbrReadQue(unsigned short value)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(value, MAX_GNB_PER_SYS);

    if (nbrGnbReadQueueFlag[value])  // existed in queue
    {
        VCCB_PRINTF("[NBR_ADIT] pushNbrReadQue, gnbNum:%d already existed\n", value);
        return;
    }

    try
    {
        nbrReadQue.push(value);
        VCCB_PRINTF("pushNbrReadQue, gnbNum:%d\n", value);
        nbrGnbReadQueueFlag[value] = true;
    }
    VCCB_PRINT_ON_EXCEPTION_VOID("push(gnbNum:%d) Error!\n", value);
}

void popNbrReadQue(unsigned short *pValue)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pValue);

    try
    {
        *pValue = nbrReadQue.front();
    }
    VCCB_PRINT_ON_EXCEPTION_VOID("front(gnbNum:%d) Error!\n", *pValue);

    try
    {
        nbrReadQue.pop();
        VCCB_PRINTF("popNbrReadQue, gnbNum:%d\n", *pValue);
        if (*pValue < MAX_GNB_PER_SYS)
        {
            nbrGnbReadQueueFlag[*pValue] = false;
        }
    }
    VCCB_PRINT_ON_EXCEPTION_VOID("pop(gnbNum:%d) Error!\n", *pValue);
}

int emptyNbrReadQue()
{
    AUTO_TRACE_FUNC;

    try
    {
        return nbrReadQue.empty();
    }
    catch (const std::exception &e)
    {
        VCCB_PRINTF("Exception(f:%s):(C:%s): empty Error!\n", __func__, e.what());
    }
    catch (...)
    {
        VCCB_PRINTF("Exception(f:%s):(C:Unknown): empty Error!\n", __func__);
    }

    return true;
}

/***************************************************************************
 * nbrEnbCell :: map<cgi_type, uint32_t, cgiCmp_type> :: TODO
 **************************************************************************/

// nbrEnbCellInfo
// [SAM_GV_IMPROVEMENT_20C]
struct cgiCmp_type
{
    bool operator()(const cgi_type &lhs, const cgi_type &rhs) const
    {
        return (lhs.plmn.longId < rhs.plmn.longId) || ((lhs.plmn.longId == rhs.plmn.longId) && (lhs.ci < rhs.ci));
    }
};

map<cgi_type, uint32_t /* index of GNBINFO[gnbNum].nbrEnbCell */, cgiCmp_type> static nbrEnbCell
    [MAX_GNB_CU_CP_FUNCTION_PER_SYS];  // CDB_PATH_CU_CP_FUNC_ENTRIES/neighbor-enb/neighbor-enb-entries/neighbor-enb-cell/neighbor-enb-cell-entries

// get EnbNbrCell DB
nbrEnbCellInfo_type *getNbrEnbCell(uint16_t gnbNum, cgi_type cgi)
{  // {{{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, NULL);
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    auto valIter = nbrEnbCell[gnbNum].find(cgi);
    if (IS_STD_MAP_NOT_FOUND(valIter, nbrEnbCell[gnbNum]))
    {
        return NULL;
    }
    else
    {
        if (valIter->second < MAX_NBR_ENB_CELL_PER_GNB)
            return &(pGnb->nbrEnbCell[valIter->second]);
        else
            return NULL;
    }
}  // }}}

// get EnbNbrCell DB
int16_t getNbrEnbCellByCellNbrIdx(uint16_t cellNum, uint16_t nbrIdx, nbrEnbCellInfo_type **ppNbr)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ppNbr);
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    uint16_t gnbNum = pCell->gnbNum;
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);

    if (N_EQUIP == pCell->eutraNbr[nbrIdx].status) return ERROR;

    cgi_type cgi;
    cgi.ci = 0;
    cgi.ci = ((uint64_t)pCell->eutraNbr[nbrIdx].targetEnbId << 8) + pCell->eutraNbr[nbrIdx].cellId;
    cgi.plmn = pCell->eutraNbr[nbrIdx].plmn;

    nbrEnbCellInfo_type *nbr = getNbrEnbCell(gnbNum, cgi);
    if (NULL == nbr)
    {
        return ERROR;
    }

    if (EQUIP != nbr->status)
    {
        return ERROR;
    }

    // return Pointer
    *ppNbr = nbr;
    return GOOD;
}  // }}}

uint32_t getNbrEnbCellEmptyIndex(VccbGnbInfo_type *pGnb)
{  // {{{
    VALID_E_POINT_CHECK_RET_VAL(pGnb, MAX_NBR_ENB_CELL_PER_GNB);

#ifdef IPC_TEST
    for (uint32_t i = 0; i < MAX_NBR_ENB_CELL_PER_GNB; i++)
    {
        if (EQUIP != pGnb->nbrEnbCell[i].status)
        {
            return i;
        }
    }
#else
    uint32_t index = pGnb->nbrEnbIndexPos;
    uint32_t cnt = 0;

    do
    {
        if (index >= MAX_NBR_ENB_CELL_PER_GNB) index = 0;
        if (EQUIP == (pGnb->nbrEnbCell + index)->status)
        {
            ++index;
            continue;
        }
        pGnb->nbrEnbIndexPos = index + 1;
        return index;

    } while ((++cnt) < MAX_NBR_ENB_CELL_PER_GNB);
#endif
    return MAX_NBR_ENB_CELL_PER_GNB;
}  // }}}

void SetNbrEnbCellInfoForInit(nbrEnbCellInfo_type *pNbrEnbCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pNbrEnbCell);

    pNbrEnbCell->status = N_EQUIP;
    pNbrEnbCell->earfcnUl = 0xFFFFFFFF;
    pNbrEnbCell->bandwidthDl = 0xFF;
    pNbrEnbCell->bandwidthUl = 0xFF;
    pNbrEnbCell->nedc_support = -1;
    pNbrEnbCell->nonNeighbor = VCCB_FLAG_OFF;

    for (uint32_t plmn_Index = 0; plmn_Index < MAX_NUM_PLMN_LTE; plmn_Index++)
    {
        pNbrEnbCell->cellPlmnInfo[plmn_Index].plmnIndex = plmn_Index;
        pNbrEnbCell->cellPlmnInfo[plmn_Index].shmStatus = N_EQUIP;
        pNbrEnbCell->cellPlmnInfo[plmn_Index].longId = 0xFFFFFF;
    }

    return;
}

// set EnbNbrCell DB
nbrEnbCellInfo_type *setNbrEnbCell(uint16_t gnbNum, cgi_type cgi)
{  // {{{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, &GNBINFO[0].nbrEnbCell_dummy);
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    if (NULL != getNbrEnbCell(gnbNum, cgi))
    {  // found
        return getNbrEnbCell(gnbNum, cgi);
    }
    else
    {  // not found
        // assign NeighborGnbCellIndex for new NeighborGnbCell
        uint32_t nbrEnbCellIndex = getNbrEnbCellEmptyIndex(pGnb);
        if (MAX_NBR_ENB_CELL_PER_GNB <= nbrEnbCellIndex)
        {
            VCCB_PRINT_ERROR("[NBR_ADIT] Error getNbrEnbCellEmptyIndex gnbNum:%d, ci:%lu plmn.longId:0x%x num:%lu/%d\n",
                gnbNum, cgi.ci, cgi.plmn.longId, nbrEnbCell[gnbNum].size(), MAX_NBR_ENB_CELL_PER_GNB);

            // Check reach the limit and then set flag to reset & read NBR for this GNB one hour later
            SET_AUDIT_RESET_NBR_ENB_CELL(gnbNum);  // NBR_AUDIT_22B
            return &(pGnb->nbrEnbCell_dummy);
        }

        nbrEnbCellInfo_type *pNbrEnbCell = &(pGnb->nbrEnbCell[nbrEnbCellIndex]);
        SetNbrEnbCellInfoForInit(pNbrEnbCell);
        pNbrEnbCell->status = EQUIP;

        cgi.plmn.s2.reserved = 0;
        nbrEnbCell[gnbNum].insert(pair<cgi_type, uint32_t>(cgi, nbrEnbCellIndex));

        pNbrEnbCell->cellId = cgi.ci % 256;
        pNbrEnbCell->enbId = (uint32_t)cgi.ci / 256;
        pNbrEnbCell->plmn = cgi.plmn;
        return pNbrEnbCell;
    }

}  // }}}

// delete EnbNbrCell DB
void deleteNbrEnbCell(uint16_t gnbNum, cgi_type cgi)
{  // {{{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    auto valIter = nbrEnbCell[gnbNum].find(cgi);
    if (IS_STD_MAP_NOT_FOUND(valIter, nbrEnbCell[gnbNum]))
    {
        return;
    }
    else
    {
        if (valIter->second < MAX_NBR_ENB_CELL_PER_GNB)
        {
            VCCB_PRINTF("%s GNBINFO[%d].nbrEnbCell[%d] ci:%lu plmn.longId:0x%x \n", __func__, gnbNum, valIter->second,
                cgi.ci, cgi.plmn.longId);

            pGnb->nbrEnbCell[valIter->second].status = N_EQUIP;
            nbrEnbCell[gnbNum].erase(cgi);
        }
    }
}  // }}}

void deleteNbrEnbCellByEnbId(uint16_t gnbNum, uint32_t nbrEnbId, plmnId_type plmn)
{  // {{{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);

    // update cellsToMeasRemove, and exist cellIndex
    for (auto it = nbrEnbCell[gnbNum].begin(); it != nbrEnbCell[gnbNum].end();)
    {
        cgi_type cgi;
        cgi = it->first;
        it++;

        // VCCB_PRINTF("it-> cellId : %d, enbId : %d, plmn : mcc:%x, mnc:%x, longId :%x\n",
        //     ((it->first).ci % 256),
        //     ((it->first).ci >> 8),
        //     ((it->first).plmn.s2.mcc),
        //     ((it->first).plmn.s2.mnc) ,
        //     ((it->first).plmn.longId) );
        if (nbrEnbId == (cgi.ci >> 8) && plmn.longId == cgi.plmn.longId)
        {
            // delete
            deleteNbrEnbCell(gnbNum, cgi);
            // VCCB_PRINTF("delete nbr \n");
            // if (it->second < MAX_NBR_ENB_CELL_PER_GNB)
            // {
            //     GNBINFO[gnbNum].nbrEnbCell[it->second].status = N_EQUIP;
            //     nbrEnbCell[gnbNum].erase(it->first);
            // }
        }
    }
}  // }}}

// clear EnbNbrCell DB
void clearNbrEnbCell(uint16_t gnbNum)
{  // {{{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

#ifndef IPC_TEST
    VCCB_PRINTF("+++++ %s gnbNum:%d \n", __func__, gnbNum);
#endif

    nbrEnbCell[gnbNum].clear();

    for (int i = 0; i < MAX_NBR_ENB_CELL_PER_GNB; i++)
    {
        pGnb->nbrEnbCell[i].status = N_EQUIP;
    }

}  // }}}

void getNbrEnbCellNum(uint16_t gnbNum, uint32_t *num)  // NBR_AUDIT_22B
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(num);
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);

    *num = (uint32_t)nbrEnbCell[gnbNum].size();
}

/***************************************************************************
 * nbrGnbCell :: map<cgi_type, uint32_t, cgiCmp_type>
 **************************************************************************/

// nbrGnbCellInfo
// [SAM_GV_IMPROVEMENT_20C]
map<cgi_type, uint32_t /* index of GNBINFO[gnbNum].nbrGnbCell */, cgiCmp_type> static nbrGnbCell
    [MAX_GNB_CU_CP_FUNCTION_PER_SYS];  // CDB_PATH_CU_CP_FUNC_ENTRIES/neighbor-gnb/neighbor-gnb-entries/neighbor-gnb-cell/neighbor-gnb-cell-entries

// get GnbNbrCell DB
nbrGnbCellInfo_type *getNbrGnbCell(uint16_t gnbNum, VccbGnbInfo_type *pGnb, cgi_type cgi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(pGnb);
    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, NULL);

    nbrGnbCellInfo_type *pResult = NULL;

    try
    {
        auto valIter = nbrGnbCell[gnbNum].find(cgi);
        if (!IS_STD_MAP_NOT_FOUND(valIter, nbrGnbCell[gnbNum]))
        {
            if (valIter->second < MAX_NBR_GNB_CELL_PER_GNB)
            {
                pResult = &(pGnb->nbrGnbCell[valIter->second]);
            }
        }
    }
    VCCB_PRINT_ON_EXCEPTION_NULL("find(gnbNum:%d) Error!\n", gnbNum);

    return pResult;
}  // }}}

nbrGnbCellInfo_type *getNbrGnbCellByNbrIdx(const VccbCellInfo_type &cell, uint16_t nbrIdx)
{
    VCCB_CHECK_E_RANGE_AND_NULLPTR(nbrIdx, MAX_NBR_PER_CELL)
    const nbrCellInfo_type *pCellNbr = &cell.Nbr[nbrIdx];
    if (N_EQUIP == pCellNbr->status) return nullptr;

    VCCB_CHECK_E_RANGE_AND_NULLPTR(cell.gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *pGnb = &GNBINFO[cell.gnbNum];

    if (VCCB_IS_INTRA_GNB_NEIGHBOR_FOR_CELL_NBR(pGnb, pCellNbr))
    {
        uint16_t nbrCellNum = MAX_CELL_NUM_VCCB;
        VCCB_GET_INTRA_GNB_NBR_CELLNUM_FROM_CELL_IDENTITY(pGnb, pCellNbr->targetCellId, nbrCellNum, MAX_CELL_NUM_VCCB);
        VCCB_CHECK_E_RANGE_AND_NULLPTR(nbrCellNum, MAX_CELL_NUM_VCCB);

        VccbCellInfo_type *pNbrCell = &CELLINFO[nbrCellNum];
        if (N_EQUIP == pNbrCell->status)
        {
            return nullptr;
        }
        return &pNbrCell->intraGnbNbrInfo;
    }
    else
    {
        cgi_type cgi = FnVCCB_GetCellNbr_NRCGI(*pCellNbr);
        nbrGnbCellInfo_type *nbr = getNbrGnbCell(cell.gnbNum, pGnb, cgi);
        if (nbr == nullptr || nbr->status == N_EQUIP) return nullptr;
        return nbr;
    }
}

// get GnbNbrCell DB
int16_t getNbrGnbCellByCellNbrIdx(uint16_t cellNum, uint16_t nbrIdx, nbrGnbCellInfo_type **ppNbr)
{  // {{{
    AUTO_TRACE_FUNC;

    const uint16_t max_cell_num_vccb = MAX_CELL_NUM_VCCB;

    VALID_E_POINT_CHECK_ERROR(ppNbr);
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_NBR_PER_CELL);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, max_cell_num_vccb);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    if (N_EQUIP == pCell->Nbr[nbrIdx].status) return ERROR;

    // if IntraGnb Nbr Cell return NbrInformation from Intra Gnb Cell
    uint16_t gnbNum = pCell->gnbNum;
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
    nbrCellInfo_type *const pCellNbr = &pCell->Nbr[nbrIdx];

    // intraGnbCell
    if (VCCB_IS_INTRA_GNB_NEIGHBOR_FOR_CELL_NBR(pGnb, pCellNbr))
    {
        uint16_t nbrCellNum = max_cell_num_vccb;

        VCCB_GET_INTRA_GNB_NBR_CELLNUM_FROM_CELL_IDENTITY(pGnb, pCellNbr->targetCellId, nbrCellNum, max_cell_num_vccb);
        VCCB_CHECK_E_RANGE_AND_RETURN(nbrCellNum, max_cell_num_vccb);

        VccbCellInfo_type *const pNbrCell = &CELLINFO[nbrCellNum];
        if (N_EQUIP == pNbrCell->status)
        {
            return ERROR;
        }

        *ppNbr = &(pNbrCell->intraGnbNbrInfo);
    }
    else
    {
        cgi_type cgi;
        // Initialize gnbId.idLength with serving gNB id Len
        pCell->Nbr[nbrIdx].targetGnbId.gnbId.idLength = pGnb->globalGnbId.gnbId.idLength;

        int16_t status = FnVCCB_Fill_CellNbr_NRCGI(cellNum, nbrIdx, &cgi);
        if (status == ERROR)
        {
            return ERROR;
        }

        nbrGnbCellInfo_type *nbr = getNbrGnbCell(gnbNum, pGnb, cgi);
        if (NULL == nbr)
        {
            return ERROR;
        }

        if (N_EQUIP == nbr->status)
        {
            return ERROR;
        }

        *ppNbr = nbr;
    }

    return GOOD;
}  // }}}

int16_t getIntraGnbNbrDataByNrPciAndArfcn(uint16_t cellNum, const uint16_t nrPci, const uint32_t ssbArfcn, uint16_t *pNbrIdx, nbrGnbCellInfo_type **ppNbr)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pNbrIdx);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VALID_E_POINT_CHECK_ERROR(ppNbr);
    nbrGnbCellInfo_type *pNbr = NULL;

    for (uint16_t cellNbrIdx = 0; cellNbrIdx < MAX_NBR_PER_CELL; ++cellNbrIdx)
    {
        if (!VCCB_IS_INTRA_GNB_NEIGHBOR(cellNum, cellNbrIdx))
        {
            continue;
        }

        if (GOOD == getNbrGnbCellByCellNbrIdx(cellNum, cellNbrIdx, &pNbr))
        {
            if ((nrPci == pNbr->nrPci) && (ssbArfcn == pNbr->ssbArfcn))
            {
                *pNbrIdx = cellNbrIdx;
                *ppNbr = pNbr;
                return GOOD;
            }
        }
    }

    return BREAK;
}

uint32_t getNbrGnbCellEmptyIndex(VccbGnbInfo_type *pGnb)
{  // {{{
    VALID_E_POINT_CHECK_RET_VAL(pGnb, MAX_NBR_GNB_CELL_PER_GNB);

#ifdef IPC_TEST
    for (uint32_t i = 0; i < MAX_NBR_GNB_CELL_PER_GNB; i++)
    {
        if (EQUIP != pGnb->nbrGnbCell[i].status)
        {
            return i;
        }
    }
#else
    uint32_t cnt = 0;
    uint32_t index = pGnb->nbrGnbIndexPos;

    do
    {
        if (index >= MAX_NBR_GNB_CELL_PER_GNB) index = 0;
        if (EQUIP == (pGnb->nbrGnbCell + index)->status)
        {
            ++index;
            continue;
        }
        pGnb->nbrGnbIndexPos = index + 1;
        return index;

    } while ((++cnt) < MAX_NBR_GNB_CELL_PER_GNB);
#endif
    return MAX_NBR_GNB_CELL_PER_GNB;
}  // }}}

void SetNbrGnbCellInfoForInit(nbrGnbCellInfo_type *pNbrGnbCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pNbrGnbCell);

    pNbrGnbCell->status = N_EQUIP;
    pNbrGnbCell->fiveGsTacStatus = N_EQUIP;
    pNbrGnbCell->configuredTacStatus = N_EQUIP;
    pNbrGnbCell->nonNeighbor = VCCB_FLAG_OFF;

    pNbrGnbCell->nrArfcnDl = 0;
    pNbrGnbCell->nrArfcnUl = 0;
    pNbrGnbCell->smtcStatus = CI_no_use;

    for (uint32_t plmn_Index = 0; plmn_Index < MAX_PLMN_INDEX; plmn_Index++)
    {
        pNbrGnbCell->cellPlmnInfo[plmn_Index].plmnIndex = plmn_Index;
        pNbrGnbCell->cellPlmnInfo[plmn_Index].shmStatus = N_EQUIP;
        pNbrGnbCell->cellPlmnInfo[plmn_Index].longId = 0xFFFFFF;
    }

    for (int band_Index = 0; band_Index < MAX_FREQBAND_PER_CELL; band_Index++)
    {
        pNbrGnbCell->freqBandInfoList[band_Index].nRFrequencyBand = 0;
        pNbrGnbCell->freqBandInfoList[band_Index].status = N_EQUIP;
    }

    pNbrGnbCell->configuredTacIndication = CI_no_use;  // CONFIG_TAC_IND_21C
    pNbrGnbCell->cellDirection = VCCB_CELLDIR_BOTH;    // NR_CONN_MC_23A
    pNbrGnbCell->voNrSupport = TRUE;                   // NR_CONN_MC_23B - VoNR HO supported by default
    pNbrGnbCell->redcapBroadcastInfo = -1;             // SVR23B FGR-MC1027 Connected mobility control for RedCap UE
    pNbrGnbCell->deactivationIndication = VCCB_NBR_GNB_CELL_ACTIVATE;  // NR_CONN_MC_23B - VoNR HO supported by default
    pNbrGnbCell->cacBackOffTime = 0;
    pNbrGnbCell->saAvailable = 0xFF; // set savailable all TRUE

    return;
}

// set GnbNbrCell DB
nbrGnbCellInfo_type *setNbrGnbCell(uint16_t gnbNum, cgi_type cgi)
{  // {{{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, &GNBINFO[0].nbrGnbCell_dummy);
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    if (NULL != getNbrGnbCell(gnbNum, pGnb, cgi))
    {  // found
        return getNbrGnbCell(gnbNum, pGnb, cgi);
    }
    else
    {  // not found
        // assign NeighborGnbCellIndex for new NeighborGnbCell
        uint32_t nbrGnbCellIndex = getNbrGnbCellEmptyIndex(pGnb);
        if (MAX_NBR_GNB_CELL_PER_GNB <= nbrGnbCellIndex)
        {
            VCCB_PRINT_ERROR("[NBR_ADIT] Error getNbrGnbCellEmptyIndex gnbNum:%d, ci:%lu plmn.longId:0x%x num:%lu/%d\n",
                gnbNum, cgi.ci, cgi.plmn.longId, nbrGnbCell[gnbNum].size(), MAX_NBR_GNB_CELL_PER_GNB);

            // Check reach the limit and then set flag to reset & read NBR for this GNB one hour later
            SET_AUDIT_RESET_NBR_GNB_CELL(gnbNum);  // NBR_IPROVE_22B
            return &(pGnb->nbrGnbCell_dummy);
        }

        nbrGnbCellInfo_type *pNbrGnbCell = &(pGnb->nbrGnbCell[nbrGnbCellIndex]);
        SetNbrGnbCellInfoForInit(pNbrGnbCell);
        pNbrGnbCell->status = EQUIP;

        cgi.plmn.s2.reserved = 0;

        try
        {
            nbrGnbCell[gnbNum].insert(pair<cgi_type, uint32_t>(cgi, nbrGnbCellIndex));
            return pNbrGnbCell;
        }
        VCCB_PRINT_ON_EXCEPTION_NULL("insert(gnbNum:%d, nbrGnbCellIndex:%d) Error!\n", gnbNum, nbrGnbCellIndex);
    }
}  // }}}

// delete GnbNbrCell DB
void deleteNbrGnbCell(uint16_t gnbNum, cgi_type cgi)
{  // {{{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    try  // for find
    {
        auto valIter = nbrGnbCell[gnbNum].find(cgi);
        if (IS_STD_MAP_NOT_FOUND(valIter, nbrGnbCell[gnbNum]))
        {
            return;
        }
        else
        {
            if (valIter->second < MAX_NBR_GNB_CELL_PER_GNB)
            {
                try  // for erase
                {
                    VCCB_PRINTF("%s GNBINFO[%d].nbrGnbCell[%d] ci:%lu plmn.longId:0x%x \n", __func__, gnbNum,
                        valIter->second, cgi.ci, cgi.plmn.longId);

                    pGnb->nbrGnbCell[valIter->second].status = N_EQUIP;
                    nbrGnbCell[gnbNum].erase(cgi);
                }
                VCCB_PRINT_ON_EXCEPTION_VOID("erase(gnbNum:%d) Error!\n", gnbNum);
            }
        }

        return;
    }
    VCCB_PRINT_ON_EXCEPTION_VOID("find(gnbNum:%d) Error!\n", gnbNum);
}  // }}}

void deleteNbrGnbCellByGnbId(uint16_t gnbNum, vccbGlobalGnbId_type nbrGnbId)
{  // {{{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);

    const uint8_t gnbIdLength = GNBINFO[gnbNum].globalGnbId.gnbId.idLength;

    // update cellsToMeasRemove, and exist cellIndex
    try
    {
        for (auto it = nbrGnbCell[gnbNum].begin(); it != nbrGnbCell[gnbNum].end();)
        {
            cgi_type cgi;
            cgi = it->first;
            it++;

            if (nbrGnbId.gnbId.id == VLIB_NrCellId2GnbId(gnbIdLength, cgi.ci) &&
                nbrGnbId.plmn.longId == cgi.plmn.longId)
            {
                // delete
                deleteNbrGnbCell(gnbNum, cgi);
            }
        }
    }
    VCCB_PRINT_ON_EXCEPTION_VOID("begin,end(gnbNum:%d) Error!\n", gnbNum);
}  // }}}

// clear GnbNbrCell DB
void clearNbrGnbCell(uint16_t gnbNum)
{  // {{{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

#ifndef IPC_TEST
    VCCB_PRINTF("+++++ %s gnbNum:%d \n", __func__, gnbNum);
#endif

    try
    {
        nbrGnbCell[gnbNum].clear();

        for (int i = 0; i < MAX_NBR_GNB_CELL_PER_GNB; i++)
        {
            pGnb->nbrGnbCell[i].status = N_EQUIP;
        }
    }
    VCCB_PRINT_ON_EXCEPTION_VOID("clear(gnbNum:%d) Error!\n", gnbNum);

}  // }}}

void getNbrGnbCellNum(uint16_t gnbNum, uint32_t *num)  // NBR_AUDIT_22B
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(num);
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);

    *num = (uint32_t)nbrGnbCell[gnbNum].size();
}

/****************************************************************************
 * @brief           This function searches the NBR in the GNB based on NRCGI.
 * @param[in,out]   ptCi : call information / callInfo_type
 * @param[in]       cellNum : Base CellNum / uint16_t
 * @param[in]       targetCellIdentity : CGI to find / cgi_type
 * @return          Valid address value or NULL / nbrGnbCellInfo_type*
 ****************************************************************************/
nbrGnbCellInfo_type *getNbrGnbCellByCgiInCellNbr(uint16_t cellNum, cgi_type targetCellIdentity)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_VALID_CELLNUM_NULL(cellNum);

    const VccbCellInfo_type *const ptCell = &CELLINFO[cellNum];
    nbrGnbCellInfo_type *ptGnbNbr = NULL;
    uint16_t nbrIdx = MAX_NBR_PER_CELL;
    int16_t status = GOOD;
    cgi_type nbrCgi;

    for (nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)
    {
        if (ptCell->Nbr[nbrIdx].status == N_EQUIP) continue;

        status = FnVCCB_Fill_CellNbr_NRCGI(cellNum, nbrIdx, &nbrCgi);
        if (status == ERROR) continue;

        // cgi not same
        if (FnVCCB_CheckCgiIdentical(&nbrCgi, &targetCellIdentity) == FALSE) continue;

        // cgi same
        status = getNbrGnbCellByCellNbrIdx(cellNum, nbrIdx, &ptGnbNbr);
        if (status != GOOD) continue;
        if (ptGnbNbr == NULL) continue;
        if (N_EQUIP == ptGnbNbr->status) continue;

        return ptGnbNbr;
    }

    return NULL;
}
