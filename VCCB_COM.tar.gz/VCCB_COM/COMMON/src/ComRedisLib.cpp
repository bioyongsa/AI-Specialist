#ifdef __CNF__
#include "ComRedisLib.h"
#include "ComInclude.h"
#include "ComLibUtility.h"
#include "MainAuditTask.h"
#include "stdarg.h"
#include "ComRedisReply.hpp"

void FnVCCB_RedisMakeCallHashesKey(char (&key)[REDIS_KEY_LEN], uint16_t groupIndex, uint32_t dataIndex)
{
    snprintf(key, (size_t)REDIS_KEY_LEN, "dist#%04u:call#%u", groupIndex, dataIndex);
}

void FnVCCB_RedisMakeGnbHashesKey(char (&key)[REDIS_KEY_LEN], uint16_t groupIndex, uint32_t dataIndex)
{
    snprintf(key, (size_t)REDIS_KEY_LEN, "vccb#%02u:gnb#%u", groupIndex, dataIndex);
}

void FnVCCB_RedisMakeCellHashesKey(char (&key)[REDIS_KEY_LEN], uint16_t groupIndex, uint32_t dataIndex)
{
    snprintf(key, (size_t)REDIS_KEY_LEN, "vccb#%02u:cell#%u", groupIndex, dataIndex);
}

void FnVCCB_RedisMakeCfgHashesKey(char (&key)[REDIS_KEY_LEN], uint16_t groupIndex)
{
    snprintf(key, (size_t)REDIS_KEY_LEN, "vccb#%02u:cfg", groupIndex);
}

void FnVCCB_RedisMakeCallSortedSetKey(char (&key)[REDIS_KEY_LEN], uint16_t groupIndex)
{
    snprintf(key, (size_t)REDIS_KEY_LEN, "dist#%04u:callSet", groupIndex);
}

void FnVCCB_RedisMakeGnbSortedSetKey(char (&key)[REDIS_KEY_LEN], uint16_t groupIndex)
{
    snprintf(key, (size_t)REDIS_KEY_LEN, "vccb#%02u:gnbSet", groupIndex);
}

void FnVCCB_RedisMakeCellSortedSetKey(char (&key)[REDIS_KEY_LEN], uint16_t groupIndex)
{
    snprintf(key, (size_t)REDIS_KEY_LEN, "vccb#%02u:cellSet", groupIndex);
}

int FnVCCB_GetIdFromZrange(char *cmd, int cmdLen)
{
    VALID_E_POINT_CHECK_ERROR(cmd);
    AUTO_TRACE_FUNC;
    int idx, buffIdx = 0;
    char buff[10];
    int ret = ERROR;
    int sharpCnt = 0;
    for (idx = 0;; idx++)
    {
        if (buffIdx >= 10)
        {
            break;
        }
        if (idx == cmdLen)
        {
            buff[buffIdx] = '\0';
            ret = GOOD;
            break;
        }
        if (sharpCnt == 2)
        {
            buff[buffIdx] = cmd[idx];
            buffIdx++;
        }
        else if (cmd[idx] == '#')
        {
            sharpCnt++;
        }
    }
    if (ret == ERROR)
    {
        VCCB_PRINTF("[Redis DB] Failed to obtain id in cmd(%s)\n", cmd);
        return ret;
    }

    ret = util::str::vccb_strtol<int>(buff);
    return ret;
}

void FnVCCB_InitRedisContext(VccbRedisConnection_type &connection)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(connection.info);
    connection.info->redisAccessAlarmFlag = VCCB_FLAG_OFF;
    connection.info->redisAccessFailCnt = 0;
    for (int contextIdx = 0; contextIdx < REDIS_MAX_CONTEXT_CNT; contextIdx++)
    {
        connection.context[contextIdx] = NULL;
        connection.info->isContextConnected[contextIdx] = FALSE;
        connection.info->serverUpTime[contextIdx] = -1;
        connection.info->redisCommandCount[contextIdx] = 0;
        connection.info->disConnectedCount[contextIdx] = 0;
    }
}

uint32_t FnVCCB_RedisGetCommandCount(VccbRedisConnection_type const &connection, int contextIdx)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(contextIdx, REDIS_MAX_CONTEXT_CNT, 0);
    VALID_E_POINT_CHECK_RET_VAL(connection.info, 0);
    return connection.info->redisCommandCount[contextIdx];
}

void FnVCCB_ChangeReadRedisDBContext(VccbRedisConnection_type &connection, int contextIdx)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(contextIdx, REDIS_MAX_CONTEXT_CNT);
    VALID_E_POINT_CHECK_VOID(connection.info);
    for (int i = 0; i < REDIS_MAX_CONTEXT_CNT; i++)
    {
        if (i == contextIdx)
        {
            continue;
        }
        if (IS_REDIS_CONNECTED(connection, i) == FALSE)
        {
            VCCB_PRINTF("[Redis DB][ReadDbUpdate] All Redis DB connections are disconnected.\n");
            continue;
        }
        if (connection.info->readContextIdx != i)
        {
            connection.info->readContextIdx = i;
            VCCB_PRINTF("[Redis DB][ReadDbUpdate] Read Context is Changed(%d -> %d)\n", contextIdx, i);
        }
    }
    return;
}

void FnVCCB_RedisFreeContext(VccbRedisConnection_type &connection, int contextIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(connection.context);
    VALID_E_POINT_CHECK_VOID(connection.info);
    VCCB_CHECK_E_RANGE_AND_VOID(contextIdx, REDIS_MAX_CONTEXT_CNT);
    if (connection.context[contextIdx] == NULL) return;
    redisFree(connection.context[contextIdx]);
    connection.context[contextIdx] = NULL;
    return;
}

void FnVCCB_RedisDisconnected(VccbRedisConnection_type &connection, int contextIdx)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(contextIdx, REDIS_MAX_CONTEXT_CNT);
    connection.info->isContextConnected[contextIdx] = FALSE;
    connection.info->disConnectedCount[contextIdx]++;
    FnVCCB_RedisFreeContext(connection, contextIdx);
    connection.info->serverUpTime[contextIdx] = -1;
    if (contextIdx == connection.info->readContextIdx)
    {
        FnVCCB_ChangeReadRedisDBContext(connection, contextIdx);
    }
}

void FnVCCB_DisconnectRedisDb(VccbRedisConnection_type &connection)
{
    for (int contextIdx = 0; contextIdx < REDIS_MAX_CONTEXT_CNT; contextIdx++)
    {
        FnVCCB_RedisDisconnected(connection, contextIdx);
    }
}

int FnVCCB_RedisCommandWithoutReply(VccbRedisConnection_type &connection, const int contextIdx, const char *format, ...)
{
    AUTO_TRACE_FUNC;
    va_list ap;
    redisContext *c = NULL;
    VALID_E_POINT_CHECK_ERROR(connection.info);
    VALID_E_POINT_CHECK_ERROR(connection.context);
    int result = GOOD;
    for (int redisDbIdx = 0; redisDbIdx < REDIS_MAX_CONTEXT_CNT; redisDbIdx++)
    {
        if (IS_TARGET_REDIS(redisDbIdx, contextIdx)) continue;
        if (IS_REDIS_CONNECTED(connection, redisDbIdx) != TRUE) continue;
        VALID_E_POINT_CHECK_ERROR(connection.context[redisDbIdx]);
        c = connection.context[redisDbIdx];
        va_start(ap, format);
        VccbRedisReply reply;
        reply.newReply(static_cast<redisReply *>(redisvCommand(c, format, ap)));
        va_end(ap);
        if (reply.getReply() == NULL || c->err == REDIS_ERR_EOF)
        {
            // Disconnect detected
            VCCB_PRINTF("[Redis DB] %s is Failed(err(%d))\n", __func__, c->err);
            VCCB_PRINTF("[Redis DB] Fail cause : %s\n", c->errstr);
            FnVCCB_RedisDisconnected(connection, redisDbIdx);
            result = ERROR;
            continue;
        }
        if (reply.getReply()->type == REDIS_REPLY_ERROR)
        {
            VCCB_PRINTF("[Redis DB] %s is ERROR(%s)\n", __func__, reply.getReply()->str);
            result = ERROR;
            continue;
        }
        connection.info->redisCommandCount[redisDbIdx]++;
    }
    return result;
}

int FnVCCB_RedisCommandGetReply(
    VccbRedisConnection_type &connection, const int contextIdx, redisReply **reply, const char *format, ...)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(connection.info);
    va_list ap;
    redisContext *c = NULL;
    int targetContextIdx;
    if (contextIdx == REDIS_BOTH_SIDE)
    {
        targetContextIdx = REDIS_GET_ACTIVE_IDX(connection);
    }
    else
    {
        targetContextIdx = contextIdx;
    }
    if (IS_REDIS_CONNECTED(connection, targetContextIdx) != TRUE) return ERROR;
    VALID_E_POINT_CHECK_ERROR(connection.context[targetContextIdx]);
    c = connection.context[targetContextIdx];
    va_start(ap, format);
    *reply = static_cast<redisReply *>(redisvCommand(c, format, ap));
    va_end(ap);
    if (*reply == NULL || c->err == REDIS_ERR_EOF)
    {
        // Disconnect detected
        VCCB_PRINTF("[Redis DB] %s is Failed(err(%d))\n", __func__, c->err);
        VCCB_PRINTF("[Redis DB] Fail cause : %s\n", c->errstr);
        FnVCCB_RedisDisconnected(connection, targetContextIdx);
        return ERROR;
    }
    if ((*reply)->type == REDIS_REPLY_ERROR)
    {
        VCCB_PRINTF("[Redis DB] %s is ERROR(%s)\n", __func__, (*reply)->str);
        return ERROR;
    }
    connection.info->redisCommandCount[targetContextIdx]++;
    return GOOD;
}

int FnVCCB_RedisAppend(VccbRedisConnection_type &connection, const int contextIdx, const char *format, ...)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(connection.info);
    va_list ap;
    int result;
    int ret = GOOD;
    redisContext *c = NULL;

    for (int redisDbIdx = 0; redisDbIdx < REDIS_MAX_CONTEXT_CNT; redisDbIdx++)
    {
        if (IS_TARGET_REDIS(redisDbIdx, contextIdx)) continue;
        if (IS_REDIS_CONNECTED(connection, redisDbIdx) != TRUE) continue;
        VALID_E_POINT_CHECK_ERROR(connection.context[redisDbIdx]);
        c = connection.context[redisDbIdx];
        va_start(ap, format);
        result = redisvAppendCommand(c, format, ap);
        va_end(ap);
        if (result == REDIS_ERR)
        {
            VCCB_PRINTF("[Redis DB] %s Append is Failed(err(%d), %d)\n", __func__, c->err, result);
            VCCB_PRINTF("[Redis DB] Fail cause : %s\n", c->errstr);
            ret = ERROR;
        }
        else
        {
            connection.info->appendedCommandCount[redisDbIdx]++;
        }
        connection.info->redisCommandCount[redisDbIdx]++;
    }
    return ret;
}

int FnVCCB_SendPipelinedCmd(VccbRedisConnection_type &connection, int targetDb)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(connection.info);
    VALID_E_POINT_CHECK_ERROR(connection.context);
    int i;
    int ret = GOOD;
    for (int contextIdx = 0; contextIdx < REDIS_MAX_CONTEXT_CNT; contextIdx++)
    {
        if (targetDb != REDIS_BOTH_SIDE && targetDb != contextIdx) continue;
        for (i = 0; i < connection.info->appendedCommandCount[contextIdx]; i++)
        {
            VALID_E_POINT_CHECK_ERROR(connection.context[contextIdx]);
            if (IS_REDIS_CONNECTED(connection, contextIdx) != TRUE) continue;
            VccbRedisReply reply;
            if (redisGetReply(connection.context[contextIdx], (void **)(reply.getReplyDoublePointer())) != REDIS_OK ||
                reply.getReply() == NULL)
            {
                VCCB_PRINTF("redisGetReply err[%s]\n", connection.context[contextIdx]->errstr);
                ret = ERROR;
                continue;
            }
        }
        connection.info->appendedCommandCount[contextIdx] = 0;
    }
    return ret;
}

int FnVCCB_RedisPing(VccbRedisConnection_type &connection, int contextIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(connection.info);
    VALID_E_POINT_CHECK_ERROR(connection.context);
    VALID_E_POINT_CHECK_ERROR(connection.context[contextIdx]);
    if (IS_REDIS_CONNECTED(connection, contextIdx) != TRUE) return ERROR;
    VccbRedisReply reply;
    reply.newReply(static_cast<redisReply *>(redisCommand(connection.context[contextIdx], "PING")));

    if (reply.getReply() == NULL || connection.context[contextIdx]->err == REDIS_ERR_EOF)
    {
        // Disconnect detected
        VCCB_PRINTF("[Redis DB] %s is Failed(err(%d))\n", __func__, connection.context[contextIdx]->err);
        VCCB_PRINTF("[Redis DB] Fail cause : %s\n", connection.context[contextIdx]->errstr);
        FnVCCB_RedisDisconnected(connection, contextIdx);
        return ERROR;
    }
    if (reply.getReply()->type == REDIS_REPLY_STATUS)
    {
        if (!strncasecmp("PONG", reply.getReply()->str, reply.getReply()->len) && reply.getReply()->len != 0)
        {
            connection.info->isContextConnected[contextIdx] = TRUE;
            return GOOD;
        }
    }
    VCCB_PRINTF("[Redis DB] %s is ERROR(%s)\n", __func__, reply.getReply()->str);
    FnVCCB_RedisDisconnected(connection, contextIdx);
    return ERROR;
}

int FnVCCB_CheckUpTime(VccbRedisConnection_type &connection, int contextIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(connection.context);
    VCCB_CHECK_E_RANGE_AND_RETURN(contextIdx, REDIS_MAX_CONTEXT_CNT);
    VALID_E_POINT_CHECK_ERROR(connection.context[contextIdx]);
    if (IS_REDIS_CONNECTED(connection, contextIdx) != TRUE) return ERROR;
    VccbRedisReply reply;
    reply.newReply(static_cast<redisReply *>(redisCommand(connection.context[contextIdx], "INFO Server")));
    if (reply.getReply() == NULL || connection.context[contextIdx]->err == REDIS_ERR_EOF)
    {
        // Disconnect detected
        FnVCCB_RedisDisconnected(connection, contextIdx);
        VCCB_PRINTF("[Redis DB][UpTime] Redis[%d] redisCommand reply is NULL\n", contextIdx);
        return ERROR;
    }
    if (reply.getReply()->type != REDIS_REPLY_STRING)
    {
        VCCB_PRINTF("[Redis DB][UpTime] Redis[%d] INFO Command Error(Type:%d)\n", contextIdx, reply.getReply()->type);
        return ERROR;
    }
    // VCCB_PRINTF("INFO Server(%d) > \n%s\n", (int)reply->len, reply->str);
    int upTime = 0;
    char *pSearchedLineBegin = strstr(reply.getReply()->str, "uptime_in_seconds:");
    char compChar;
    if (NULL != pSearchedLineBegin)
    {
        char *pUpInSecondsBegin = strstr(pSearchedLineBegin, ":");
        if (pUpInSecondsBegin == NULL)
        {
            VCCB_PRINTF("[Redis DB][UpTime] Redis[%d] pUpInSecondsBegin is Null !!\n", contextIdx);
            return ERROR;
        }
        pUpInSecondsBegin++;
        upTime = 0;
        for (int i = 0;; i++)
        {
            compChar = pUpInSecondsBegin[i];
            if (compChar > '9' || compChar < '0') break;
            upTime = upTime * 10 + (compChar - '0');
        }
    }
    return upTime;
}

int FnVCCB_SetRedisKeepAlive(redisContext *pRedisContext, const int contextIdx)
{
    VALID_E_POINT_CHECK_ERROR(pRedisContext);

    int ret = GOOD;
    ret = redisSetTimeout(pRedisContext, {HIREDIS_CONNECT_TIMEOUT, 0});  // 1sec
    if (ret == REDIS_ERR)
    {
        VCCB_PRINTF("[Redis DB] REDIS_%d - redisSetTimeout Failed cause : %s\n", contextIdx, pRedisContext->errstr);
        return ERROR;
    }

    // TCP keep alive is set. (10 s)
    ret = redisEnableKeepAliveWithInterval(pRedisContext, HIREDIS_COMMAND_TIMEOUT);  // 10sec
    if (ret == REDIS_ERR)
    {
        VCCB_PRINTF("[Redis DB] REDIS_%d - redisEnableKeepAliveWithInterval Failed cause : %s\n", contextIdx,
            pRedisContext->errstr);
        return ERROR;
    }

    VCCB_PRINTF("[Redis DB] REDIS_%d - redisSetTimeout(%d sec)/redisEnableKeepAliveWithInterval(%d sec) Success\n", contextIdx,
        HIREDIS_CONNECT_TIMEOUT, HIREDIS_COMMAND_TIMEOUT);

    return GOOD;
}

int FnVCCB_ConnectRedisContext(VccbRedisConnection_type &connection, const int contextIdx, const int port)
{
    VALID_E_POINT_CHECK_ERROR(connection.context);
    VALID_E_POINT_CHECK_ERROR(connection.info);

    char *svcName = NULL;
    if (ERROR == FnVCCB_GetPodSvcName(&svcName, VCCB_REDIS, contextIdx, ENV->podInfo))
    {
        VCCB_PRINTF("[%s] FnVCCB_GetPodSvcName ERROR!!\n", __func__);
        return ERROR;
    }

    enumVccbPodDeploymentKind_type podDeploymentKind = FnVCCB_GetPodDeploymentKind(VCCB_REDIS);
    if (VCCB_UNKNOWN_DEPLOYMENT_KIND_POD == podDeploymentKind)
    {
        VCCB_PRINTF("[%s] FnVCCB_GetPodDeploymentKind ERROR!!\n", __func__);
        return ERROR;
    }

    MdsIp_Type destIp;
    if (ERROR == FnVCCB_GetKasIp(destIp, svcName, podDeploymentKind))
    {
        VCCB_PRINTF("[%s] FnVCCB_GetKasIp ERROR!!\n", __func__);
        return ERROR;
    }

    char StrIp[INET6_ADDRSTRLEN];
    memset(StrIp, 0, sizeof(StrIp));

    if (ERROR == FnVCCB_ConvertMdsIptoChar(destIp, StrIp))
    {
        VCCB_PRINTF("FnVCCB_ConvertMdsIptoChar is Failed!!\n");
        return ERROR;
    }

#ifdef IPC_TEST
    if (contextIdx == 0)
    snprintf(StrIp, sizeof("127.0.0.1"), "127.0.0.1");
    else if (contextIdx == 1)
    snprintf(StrIp, sizeof("127.0.0.2"), "127.0.0.2");
#endif

    VCCB_PRINTF("[REDIS DB][Conn] REDIS_%d : %s\n", contextIdx, StrIp);

    connection.context[contextIdx] = redisConnectWithTimeout(StrIp, port, {HIREDIS_CONNECT_TIMEOUT, 0});
    if (connection.context[contextIdx] == NULL || connection.context[contextIdx]->err != 0)
    {
        if (connection.context[contextIdx])
        {
            VCCB_PRINTF("[Redis DB][Conn] REDIS_%d Connection Failed : %s\n", contextIdx,
                connection.context[contextIdx]->errstr);
        }
        else
        {
            VCCB_PRINTF("[Redis DB][Conn] REDIS_%d Connection Failed : Null is Returned\n", contextIdx);
        }
        return ERROR;
    }

    connection.info->isContextConnected[contextIdx] = TRUE;
   
    if (ERROR == FnVCCB_SetRedisKeepAlive(connection.context[contextIdx], contextIdx))
    {
        VCCB_PRINTF("[Redis DB][Conn] REDIS_%d - FnVCCB_SetRedisKeepAlive is failed!!\n", contextIdx);
        FnVCCB_RedisDisconnected(connection, contextIdx);
        return ERROR;
    }

#ifndef IPC_TEST
    static int _retryCount[REDIS_MAX_CONTEXT_CNT] = {0, 0};
    const char *_RedisPassword[2] = { REDIS_PASSWORD_NEW, REDIS_PASSWORD_OLD };

    auto &retryCount = _retryCount[contextIdx];
    const char *RedisPassword = _RedisPassword[retryCount%2];

    VccbRedisReply reply;
    if (ERROR ==
        FnVCCB_RedisCommandGetReply(connection, contextIdx, reply.getReplyDoublePointer(), "AUTH %s", RedisPassword))
    {
        VCCB_PRINTF("[Redis DB][Conn] (AUTH %s) is failed!! - %d \n", RedisPassword, retryCount);
        retryCount++;
        FnVCCB_RedisDisconnected(connection, contextIdx);
        return ERROR;
    }
#endif  // IPC_TEST

    return GOOD;
}

int FnVCCB_SelectActiveRedisDb(VccbRedisConnection_type &connection)
{
    int result = ERROR;
    VALID_E_POINT_CHECK_ERROR(connection.info);
    for (int contextIdx = 0; contextIdx < REDIS_MAX_CONTEXT_CNT; contextIdx++)
    {
        connection.info->serverUpTime[contextIdx] = FnVCCB_CheckUpTime(connection, contextIdx);
        if (connection.info->serverUpTime[contextIdx] != ERROR)
        {
            result = GOOD;
        }
    }

    if (result == ERROR)
    {
        // All Redis DB is Disconnected while Check UpTime
        VCCB_PRINTF("[Redis DB][Conn] The connection to all servers failed.\n");
        return ERROR;
    }

    connection.info->readContextIdx =
        (connection.info->serverUpTime[REDIS_0] > connection.info->serverUpTime[REDIS_1]) ? 0 : 1;
    VCCB_PRINTF("[Redis DB][Conn] Redis[%d] is Read DB(UpTime [REDIS_0]:%d, [REDIS_1]:%d)\n",
        connection.info->readContextIdx, connection.info->serverUpTime[REDIS_0],
        connection.info->serverUpTime[REDIS_1]);
    VCCB_PRINTF("[Redis DB][Conn] Redis DB is Connected.\n");
    return GOOD;
}

int FnVCCB_ConnectRedisDb(VccbRedisConnection_type &connection)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(connection.info);
    int contextIdx = 0;
    int condForRedisConnection = ERROR;

#ifdef IPC_TEST
    int port[2] = {6379, 6380};
#endif

    for (contextIdx = 0; contextIdx < REDIS_MAX_CONTEXT_CNT; contextIdx++)
    {
        if (IS_REDIS_CONNECTED(connection, contextIdx) == TRUE)
        {
            condForRedisConnection = GOOD;
            continue;
        }
#ifdef IPC_TEST
        if (ERROR == FnVCCB_ConnectRedisContext(connection, contextIdx, port[contextIdx]))
        {
            VCCB_PRINTF("[%s] FnVCCB_ConnectRedisContext ERROR(contextIdx : %d)!!\n", __func__, contextIdx);
            continue;
        }
#else
        if (ERROR == FnVCCB_ConnectRedisContext(connection, contextIdx, VCCB_REDIS_PORT))
        {
            VCCB_PRINTF("[%s] FnVCCB_ConnectRedisContext ERROR(contextIdx : %d)!!\n", __func__, contextIdx);
            continue;
        }
#endif  // IPC_TEST

        VCCB_PRINTF("[Redis DB][Conn] REDIS_%d Connection Success\n", contextIdx);
        condForRedisConnection = GOOD;
    }

    if (condForRedisConnection == ERROR)
    {
        VCCB_PRINTF("[Redis DB][Conn] The connection to all servers failed.\n");
        return ERROR;
    }

    if (ERROR == FnVCCB_SelectActiveRedisDb(connection))
    {
        VCCB_PRINTF("[%s] FnVCCB_SelectActiveRedisDb ERROR!!\n", __func__);
        return ERROR;
    }
    return GOOD;
}

int PingToServer(VccbRedisConnection_type &connection)
{
    AUTO_TRACE_FUNC;
    int result = GOOD;
    if (DBG->flag.extDbTestFlag == TRUE)
    {
        FnVCCB_ChangeReadRedisDBContext(connection, REDIS_0);
        result = ERROR;
        return result;
    }
    for (int contextIdx = 0; contextIdx < REDIS_MAX_CONTEXT_CNT; contextIdx++)
    {
        if (ERROR == FnVCCB_RedisPing(connection, contextIdx))
        {
            result = ERROR;
        }
    }
    return result;
}

#endif  // __CNF__
