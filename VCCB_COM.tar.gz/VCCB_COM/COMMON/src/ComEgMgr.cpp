#include <string.h>
#include "ComGlobalData.h"
#include "ComLibIpcApi.h"
#include "ComEgMgr.h"
#include "ComTimeUtil.h"

const uint32_t MAX_EG_LOCATION_LEN = 120;
const uint32_t MAX_EVENT_SIZE = 30;

ComEgMgr* ComEgMgr::instance_ = 0;
std::mutex ComEgMgr::newLock_;

ComEgMgr::ComEgMgr() { ComTimeUtil::get_current_time(startTime_); }

ComEgMgr::~ComEgMgr() {}

ComEgMgr* ComEgMgr::instance()
{
    if (instance_ == 0)
    {
        newLock_.lock();
        if (instance_ == 0)
        {
            instance_ = new ComEgMgr();
        }
        newLock_.unlock();
    }

    return instance_;
}

void ComEgMgr::gather(const char* egevent, const char* location, int32_t egLevel)
{
    if (egevent == nullptr or location == nullptr or (egLevel < 0))
    {
        return;
    }

    if (egLevel > EG_MAX_LEVEL)
    {
        egLevel = EG_MAX_LEVEL;
    }

    size_t eventLen = strnlen(egevent, MAX_EVENT_SIZE);
    size_t locationLen = strnlen(location, MAX_EG_LOCATION_LEN);
    size_t keyLocPos = locationLen;
    if (keyLocPos > MAX_EVENT_SIZE)
    {
        keyLocPos = MAX_EVENT_SIZE;
    }

    uint32_t mutexIdx = 0;
    if (locationLen > 0)
    {
        mutexIdx = ((uint32_t)location[0] + (uint32_t)location[keyLocPos - 1] + (uint32_t)locationLen) % EG_POOL_CNT;
    }
    else
    {
        mutexIdx = 0;
    }

    std::lock_guard<std::mutex> lock(egMutex_[mutexIdx]);
    StlMapEgCount& levelMapRef = egLevelMap_[mutexIdx][egLevel];
    string egLocation = location;
    StlMapEgCount::iterator iter = levelMapRef.find(egLocation);
    if (iter == levelMapRef.end())
    {
        char cEventString[MAX_EVENT_SIZE + 1];
        strncpy(cEventString, egevent, MIN(eventLen, MAX_EVENT_SIZE));  // cut 30 char, null is not check
        cEventString[eventLen] = '\0';  // always fill null, it is 0 ~ MAX_EVENT_SIZE(30), but db is 31.

        string eventString(MAX_EVENT_SIZE + 1, 0);  // Print 30 char, 1 char for null.
        eventString = cEventString;

        levelMapRef[egLocation].count = 1;
        levelMapRef[egLocation].causeStr = eventString;
    }
    else
    {
        (*iter).second.count++;
    }
    return;
}

void ComEgMgr::clear()
{
    for (uint32_t idx = 0; idx < EG_POOL_CNT; idx++)
    {
        std::lock_guard<std::mutex> lock(egMutex_[idx]);
        for (uint32_t lvl = 0; lvl <= EG_MAX_LEVEL; lvl++)
        {
            StlMapEgCount emptyMap;
            egLevelMap_[idx][lvl].swap(emptyMap);
        }
    }

    ComTimeUtil::get_current_time(startTime_);

    return;
}

// std::string ComEgMgr::displayCmdOut(int32_t inLevel)
//{
//    if (inLevel < 0)
//    {
//        inLevel = 0;
//    }
//
//    StlMapEgCount levelMap[EG_MAX_LEVEL + 1];
//
//    for (uint32_t idx = 0; idx < EG_POOL_CNT; idx++)
//    {
//        std::lock_guard<std::mutex> lock(egMutex_[idx]);
//        for (uint32_t lvl = inLevel; lvl <= EG_MAX_LEVEL; lvl++)
//        {
//            levelMap[lvl].insert(egLevelMap_[idx][lvl].begin(), egLevelMap_[idx][lvl].end());
//        }
//    }
//
//    ostringstream oss;
//    char tmp[100] = {
//        0,
//    };
//
//    oss << "\t EG Set Flag   = " << (GetgEgFlag() ? "ON" : "OFF") << endl;
//    oss << "\t EG Start Time = " << makeTimeValStr(startTime_) << endl;
//
//    for (uint32_t lvl = inLevel; lvl <= EG_MAX_LEVEL; lvl++)
//    {
//        if (lvl == 0)
//            oss << "\t [LEVEL 0  : NORMAL EVENT]" << endl;
//        else
//            oss << "\t [LEVEL " << lvl << "  : ERROR EVENT]" << endl;
//
//        oss << "\t ------------------------------------------------------------------------------" << endl;
//        oss << "\t EVENT                          | COUNT        | LOCATION                      " << endl;
//        oss << "\t ------------------------------------------------------------------------------" << endl;
//
//        StlMapEgCount::iterator iter;
//        for (iter = levelMap[lvl].begin(); iter != levelMap[lvl].end(); ++iter)
//        {
//            oss << "\t ";
//            snprintf(tmp, sizeof(tmp), "%-30s", (*iter).second.causeStr.c_str());
//            oss << tmp << " | ";
//            snprintf(tmp, sizeof(tmp), "%12lu", (*iter).second.count);
//            oss << tmp << " | ";
//            oss << (*iter).first.c_str() << endl;
//        }
//
//        oss << "\t ------------------------------------------------------------------------------" << endl;
//        oss << "\t TOTAL EVENT LIST : " << (int)levelMap[lvl].size() << endl << endl;
//    }
//
//    return oss.str();
//}

void ComEgMgr::setEgFlag(bool newFlag)
{
    bool oldFlag = GetgEgFlag();
    SetgEgFlag(newFlag);
    LOGCMD("\t EG Set Flag   : %s ====> %s \n", (oldFlag ? "ON" : "OFF"), (GetgEgFlag() ? "ON" : "OFF"));
}

void ComEgMgr::setEgLevel(int32_t newLevel)
{
    int32_t oldLevel = GetEgLevel();
    SetEgLevel(newLevel);
    LOGCMD("\t EG Set Level  : %d ====> %d \n", oldLevel, GetEgLevel());
}

void ComEgMgr::displayEgInfo()
{
    LOGCMD("\t EG Set Flag   = %s \n", (GetgEgFlag() ? "ON" : "OFF"));
    LOGCMD("\t EG Set LEVEL  = %d \n", GetEgLevel());
}
void ComEgMgr::displayEglog(int32_t inLevel)
{
    if (inLevel < 0)
    {
        inLevel = 0;
    }

    StlMapEgCount levelMap[EG_MAX_LEVEL + 1];

    for (uint32_t idx = 0; idx < EG_POOL_CNT; idx++)
    {
        std::lock_guard<std::mutex> lock(egMutex_[idx]);
        for (uint32_t lvl = (uint32_t)inLevel; lvl <= EG_MAX_LEVEL; lvl++)
        {
            levelMap[lvl].insert(egLevelMap_[idx][lvl].begin(), egLevelMap_[idx][lvl].end());
        }
    }

    LOGCMD("\t EG Set Flag   = %s \n", (GetgEgFlag() ? "ON" : "OFF"));
    LOGCMD("\t EG Start Time = %s \n", makeTimeValStr(startTime_).c_str());

    for (uint32_t lvl = (uint32_t)inLevel; lvl <= EG_MAX_LEVEL; lvl++)
    {
        if (lvl == 0)
            LOGCMD("\n\t [LEVEL 0  : NORMAL EVENT] \n");
        else
            LOGCMD("\n\t [LEVEL %d  : ERROR EVENT] \n", lvl);

        LOGCMD("\t ------------------------------------------------------------------------------\n");
        LOGCMD("\t EVENT                          | COUNT        | LOCATION                      \n");
        LOGCMD("\t ------------------------------------------------------------------------------\n");

        StlMapEgCount::iterator iter;
        for (iter = levelMap[lvl].begin(); iter != levelMap[lvl].end(); ++iter)
        {
            LOGCMD("\t %-30s | %12lu | %s \n", (*iter).second.causeStr.c_str(), (*iter).second.count,
                (*iter).first.c_str());
        }

        LOGCMD("\t ------------------------------------------------------------------------------\n");
        LOGCMD("\t TOTAL EVENT LIST : %d \n", (int)levelMap[lvl].size());
    }

    return;
}

std::string ComEgMgr::makeTimeValStr(const struct timeval& timeVal)
{
    struct tm res;
    struct tm* utx = localtime_r((const time_t*)&timeVal.tv_sec, &res);
    char timeStr[38] = {
        0,
    };

    if (utx)
    {
        uint16_t month = (uint16_t)(res.tm_mon + 1);
        uint16_t day = (uint16_t)res.tm_mday;
        uint16_t hour = (uint16_t)res.tm_hour;
        uint16_t minute = (uint16_t)res.tm_min;
        uint16_t second = (uint16_t)res.tm_sec;
        uint32_t usec = (uint32_t)timeVal.tv_usec;

        snprintf(timeStr, sizeof(timeStr), "%02d-%02d %02d:%02d:%02d:%03u", month, day, hour, minute, second,
            (uint32_t)usec / 1000);
    }
    else
    {
        snprintf(timeStr, sizeof(timeStr), "%02d-%02d %02d:%02d:%02d:%03u", 0, 0, 0, 0, 0,
            (uint32_t)(timeVal.tv_usec) / 1000);
    }

    return timeStr;
}
