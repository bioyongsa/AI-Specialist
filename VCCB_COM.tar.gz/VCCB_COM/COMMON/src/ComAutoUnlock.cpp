#include "ComAutoUnlock.hpp"
#include "ComMacro.h"

ComAutoUnlock::ComAutoUnlock(pthread_mutex_t *_mutex) : mutex(_mutex) { MUTEX_LOCK(mutex); }
ComAutoUnlock::~ComAutoUnlock() { MUTEX_UNLOCK(mutex); }