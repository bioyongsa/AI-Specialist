#ifdef __CNF__
#include "ComRedisReply.hpp"

VccbRedisReply::VccbRedisReply() { this->pReply = NULL; }
VccbRedisReply::~VccbRedisReply() { freeReplyObject(this->pReply); }
redisReply* VccbRedisReply::getReply() { return this->pReply; }
redisReply** VccbRedisReply::getReplyDoublePointer() { return &this->pReply; }
void VccbRedisReply::newReply(redisReply *reply)
{
    this->pReply = reply;
}
#endif