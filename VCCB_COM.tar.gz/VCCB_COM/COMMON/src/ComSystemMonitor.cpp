/**
 * @file         : ComSystemMonitor.cpp
 * @brief       : source of system monitor
 *
 * @author    : hohyun.kang@samsung.com
 * @date      : 2018/12/06
 *
 * Copyright 2018 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#include "ComSystemMonitor.hpp"
#include "ComMacro.h"
#include "ComAutoNtrace.hpp"

ComSystemMonitor::ComSystemMonitor(void) {}

ComSystemMonitor::~ComSystemMonitor(void) {}

int ComSystemMonitor::getMaxCpuNum(void)
{
    AUTO_TRACE_FUNC;

    ComSystemCpuInfoGetter cpuInfo;
    return cpuInfo.t_getMaxCpuNum();
}

// int ComSystemMonitor::getCpuLoad200ms(const int id)
//{
//    AUTO_TRACE_FUNC;
//
//    ComSystemCpuInfoGetter cpuInfo;
//
//    cpuId rCpuId;
//    if (cpuInfo.t_getCpuId(id, rCpuId) == false)
//    {
//        return -1;
//    }
//    return cpuInfo.t_getCpuLoad200ms(rCpuId);
//}

int ComSystemMonitor::getCpuLoad3sec(const int id)
{
    AUTO_TRACE_FUNC;

    ComSystemCpuInfoGetter cpuInfo;

    cpuId rCpuId;
    if (cpuInfo.t_getCpuId(id, rCpuId) == false)
    {
        return -1;
    }
    return cpuInfo.t_getCpuLoad3sec(rCpuId);
}

// int ComSystemMonitor::getCpuLoad5min(const int id)
//{
//    AUTO_TRACE_FUNC;
//
//    ComSystemCpuInfoGetter cpuInfo;
//
//    cpuId rCpuId;
//    if (cpuInfo.t_getCpuId(id, rCpuId) == false)
//    {
//        return -1;
//    }
//    return cpuInfo.t_getCpuLoad5min(rCpuId);
//}

// int ComSystemMonitor::getCpuLoadOneDemand(const int id, const int periodSec)
//{
//    AUTO_TRACE_FUNC;
//
//    ComSystemCpuInfoGetter cpuInfo;
//
//    cpuId rCpuId;
//    if (cpuInfo.t_getCpuId(id, rCpuId) == false)
//    {
//        return -1;
//    }
//    return cpuInfo.t_getCpuLoadOneDemand(rCpuId, periodSec);
//}