/**
 * @file     : VccbStructCInterface.cpp
 * @brief    : source file for operators defined for objects from VccbStruct.h
 *
 * @author   : m.ciurej@samsung.com
 * @date     : 2022/02/10
 *
 * Copyright 2022 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information). One
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * one entered into with Samsung.
 */

#include "VccbStructCInterface.h"
#include "ComMacro.h"
#include "ComGlobalData.h"
#include "ComLibIpcApi.h"
#include "ComAutoNtrace.hpp"

int16_t VCOM_CheckPlmnIdentical(const plmnId_type *p1, const plmnId_type *p2)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(p1);
    VALID_E_POINT_CHECK_FALSE(p2);
    if (p1->s2.mcc != p2->s2.mcc)
    {
        return FALSE;
    }
    if (p1->s2.mnc != p2->s2.mnc)
    {
        return FALSE;
    }
    return TRUE;
}

int16_t FnVCCB_CheckCgiIdentical(const cgi_type *p1, const cgi_type *p2)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(p1);
    VALID_E_POINT_CHECK_FALSE(p2);
    if (VCOM_CheckPlmnIdentical(&p1->plmn, &p2->plmn) == FALSE)
    {
        return FALSE;
    }
    if (p1->ci != p2->ci)
    {
        return FALSE;
    }
    return TRUE;
}

// Compare for MdsIp_Type
// return value as for standard *cmp functions
int MdsIp_TypeCmp(const MdsIp_Type *lip, const MdsIp_Type *rip)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ZERO(lip);
    VALID_E_POINT_CHECK_ZERO(rip);

    int ret = 0;

    if (lip->IpVer != rip->IpVer)
    {
        // IPV6 comes after IPV4
        ret = (rip->IpVer == MDS_IPV6) ? -1 : 1;
    }
    else if (lip->IpVer == MDS_IPV4)
    {
        ret = (lip->Ip.V4 < rip->Ip.V4) ? -1 : (lip->Ip.V4 > rip->Ip.V4) ? 1 : 0;
    }
    else  // MDS_IPV6
    {
        ret = memcmp(lip->Ip.V6, rip->Ip.V6, IPV6_ADDRLEN);
    }
    return ret;
}

//copy elements from cgi_type to csl_cgi_type
//cgi_type default alignment
//csl_cgi_type pragma pack(1) alignment
void copyCgiToCslCgi(const cgi_type* cgi, csl_cgi_type* csl_cgi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(cgi, csl_cgi);

    csl_cgi->plmn = cgi->plmn;
    memcpy(csl_cgi->reserved, cgi->reserved, sizeof(cgi->reserved));
    csl_cgi->ci = cgi->ci;
}