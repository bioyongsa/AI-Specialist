#include "ComAutoNtrace.hpp"
#include "DusInterface.h"
#include "mw_ntrace_tag.h"

ComAutoNtrace::ComAutoNtrace(const char* name)
{
    if (name) NTRACE_BEGIN_NAME(NTRACE_TAG_APP_VCCB, name);
}

ComAutoNtrace::~ComAutoNtrace() { NTRACE_END(NTRACE_TAG_APP_VCCB); }