/**
 * @file     : ComContainers.hpp
 * @brief    : files with own containers implementation
 *
 * @author   : Michal Ciurej ID:m.ciurej email:m.ciurej@samsung.com
 * @date     : 2022/08/01
 *
 * Copyright 2022 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef VCCB_COM_ComContainers_HPP_
#define VCCB_COM_ComContainers_HPP_

#include <algorithm>
#include <initializer_list>
#include <functional>

#include "VccbDefine.h"
#include "ComInclude.h"
#include "ComGlobalData.h"
#include "ComMacro.h"
#include "ComPrint.h"

/*
 * Provides Implementation of unordered Set, with maximal capacity defined as a template parameter.
 *
 * staticUnorderedSet was tested in order to compare its efficiency against std::set.
 * Tests indicate that there is no visible difference in efficiency for small number
 * of objects (up to 100) for small types (like int or long long).
 */
template <typename T, size_t N, typename KeyEqual = std::equal_to<T>>
class staticUnorderedSet
{
    T tab_[N];
    size_t size_ = 0;
    KeyEqual comparer_;

public:
    staticUnorderedSet(const KeyEqual& comparer = KeyEqual()) : comparer_(comparer) {}
    bool empty() const { return 0 == size_; }
    bool full() const { return N == size_; }
    size_t size() const { return size_; }
    constexpr std::size_t capacity() const noexcept { return N; }
    void clear() { size_ = 0; }
    bool contains(const T& toCheck) const { return cend() != find(toCheck); }
    const T* cbegin() const { return tab_; }
    const T* cend() const { return tab_ + size_; }
    T* begin() { return tab_; }
    T* end() { return tab_ + size_; }
    const T* begin() const { return tab_; }
    const T* end() const { return tab_ + size_; }
    bool insert(const T& toAdd)
    {
        if (!full() && !contains(toAdd))
        {
            tab_[size_++] = toAdd;
            return true;
        }
        return false;
    }
    bool erase(const T& toErase)
    {
        auto result = std::remove_if(begin(), end(), [this, &toErase](const T& it) { return comparer_(toErase, it); });
        if (end() != result)
        {
            size_--;
            return true;
        }
        return false;
    }
    const T* find(const T& toFind) const
    {
        return std::find_if(cbegin(), cend(), [this, &toFind](const T& it) { return comparer_(toFind, it); });
    }
};

/****************************************************************************
 * @brief           simpleVector
 *                  Specially prepared class which is an imitation of std::vector from STL.
 *                  It supports basic operation in the same way as std::vector does
 *                  including iteration over collection. It is allocated entirely on a stack
 *                  with a template parameter N defining vector's capacity. SimpleVector can not
 *                  contain more values than it was declared. Even push_back or allocate are not
 *                  able to add new elements after size equals capacity.
 *                      Methods push_back and allocate are safe  when size == capacity,
 *                  they will not try to go beyond vector's memory, just return reference to specially
 *                  prepared field invalid_ and then invoke invalid_memory_access function.
 ****************************************************************************/
template <typename T, size_t N>
class simpleVector
{
public:
    typedef size_t size_type;
    typedef std::ptrdiff_t difference_type;
    typedef T *pointer;
    typedef const T *const_pointer;
    typedef T &reference;
    typedef const T &const_reference;
    typedef T value_type;
    typedef T* iterator;
    typedef const T* const_iterator;

private:
    T tab_[N];  // In the future when compiler will be newer than 4.8.5 there will be T tab_[N]{};
    size_t size_{0};
    T invalid_{};

    simpleVector(size_t count) : size_(count <= N ? count : N) {}

    // Throwing an exception in a noexcept function ends in a termination with no additional information
    // It is preferable to add a log to VCCB to inform users that something is going wrong
    void invalid_memory_access(const size_t n) const noexcept
    {
#ifdef NEW_HOST_SIM
        VCCB_PRINT_CRITICAL("[simpleVector][Out of Range] Out of Range access detected - index %lu when size is %lu!\n", n, size_);
#else
        (void)n;
#endif
    }

    void invalid_memory_access() const noexcept
    {
#ifdef NEW_HOST_SIM
        VCCB_PRINT_CRITICAL("[simpleVector][Out of Range] Attempt to access invalid element detected - size %lu, N %lu\n", size_, N);
#endif
    }

public:
    simpleVector() {}
    simpleVector(std::initializer_list<T> init) : simpleVector(init.size())
    // If there are too many objects in initializer list only N first objects will be inserted.
    // All other elements will not be taken into account but just ommited.
    {
        size_t i = 0;
        for (const auto& item : init)
        {
            if (i >= size_) return;
            tab_[i++] = item;
        }
    }
    T& operator[](size_t n)
    {
        if (n >= size_)
        {
            invalid_memory_access(n);
            return invalid_;
        }
        return tab_[n];
    }
    const T& operator[](size_t n) const
    {
        if (n >= size_)
        {
            invalid_memory_access(n);
            return invalid_;
        }
        return tab_[n];
    }
    size_t size() const noexcept { return size_; }
    void push_back(const T& toAdd) noexcept
    {
        if (size_ < N)
        {
            tab_[size_++] = toAdd;
        }
        else
        {
            invalid_memory_access();
        }
    }
    T& allocate() noexcept
    {
        if (size_ < N)
        {
            size_++;
            return back();
        }
        invalid_memory_access();
        return invalid_;
    }
    void pop() noexcept
    {
        if (size_ > 0)
        {
            --size_;
        }
        else
        {
            invalid_memory_access();
        }
    }
    void pop_back() noexcept
    {
        pop();
    }
    T& front() noexcept
    {
        if (size_ > 0)
        {
            return tab_[0];
        }
        invalid_memory_access();
        return invalid_;
    }
    const T& front() const noexcept
    {
        if (size_ > 0)
        {
            return tab_[0];
        }
        invalid_memory_access();
        return invalid_;
    }
    T& back() noexcept
    {
        if (size_ > 0)
        {
            return tab_[size_ - 1];
        }
        invalid_memory_access();
        return invalid_;
    }
    const T& back() const noexcept
    {
        if (size_ > 0)
        {
            return tab_[size_ - 1];
        }
        invalid_memory_access();
        return invalid_;
    }
    bool empty() const noexcept { return size_ == 0; }
    bool full() const noexcept { return size_ == N; }
    void clear() noexcept { size_ = 0; }
    iterator begin() noexcept { return &tab_[0]; }
    iterator end() noexcept { return tab_ + size_; }
    const_iterator begin() const noexcept { return &tab_[0]; }
    const_iterator end() const noexcept { return tab_ + size_; }
    const_iterator cbegin() const noexcept { return &tab_[0]; }
    const_iterator cend() const noexcept { return tab_ + size_; }
    bool operator==(const simpleVector<T, N>& toCompare) const
    {
        if (size_ != toCompare.size())
        {
            return false;
        }
        for (uint i = 0; i < size_; i++)
        {
            if (tab_[i] != toCompare[i])
            {
                return false;
            }
        }
        return true;
    }
    bool operator!=(const simpleVector<T, N>& toCompare) const { return !(*this == toCompare); }
    constexpr std::size_t capacity() const noexcept { return N; }
    std::reverse_iterator<iterator> rbegin() { return std::reverse_iterator<iterator>(tab_ + size_); }
    std::reverse_iterator<iterator> rend() { return std::reverse_iterator<iterator>(&tab_[0]); }
    iterator erase(iterator first, iterator last)
    {
        if (empty() || (first >= last) || (first < begin() || first >= end()) || (last <= begin() || last > end()))
        {
            return last;
        }
        const uint16_t difference = (uint16_t)(last - first);
        for (iterator item = first; item + difference < end(); item++)
        {
            *item = *(item + difference);
        }
        size_ -= difference;
        return first;
    }
    iterator erase(iterator toErase) { return erase(toErase, toErase + 1); }
};

/****************************************************************************
 * @brief           staticMapper
 *                  Specially prepared class which was created to handle counter mapping.
 *                  staticMapper class template is a container that stores key-value pairs.
 *                  It is designed to be a lightweight alternative to std::map for cases where the number 
 *                  of elements and their types are known at compile-time.
 *                  staticMapper class is implemented using a standard library array (named storage) 
 *                  and supports logarithmic-time lookup operations using the get_value method. 
 *                  makeMap function is a helper function that creates an instance of 
 *                  staticMapper from an array of key-value pairs.
 ****************************************************************************/
template <typename KeyT, typename ValueT, std::size_t N>
class staticMapper
{
private:
    std::array<std::pair<KeyT, ValueT>, N> storage = {};
    
    // Private constructor to prevent users from creating staticMapper with wrong size. For example, below compiles:
    //   auto x = staticMapper<int, int, 2>({99, -99}) 
    // and creates a map with with 2 entries {99, -99}, {0, 0}. It may surprise a user that key 0 is created.
    // Even worse scenario is:
    //   auto y = staticMapper<int, int, 3>({1,11}, {0, 13})
    // which creates a map with 2 entries {1,11}, {0, *0*}, value 13 for key 0 is overwritten with 0. It may lead to bugs.
    staticMapper(const std::pair<KeyT, ValueT> (&init)[N])
    {
        std::copy_n(begin(init), N, begin(storage));
        std::sort(begin(storage), end(storage));
    }
    staticMapper(){};

    // Utility function `makeMap` is added so users can create `staticMapper` without worrying about its size 
    // as it is deduced from the argument init
    template <typename MakeKeyT, typename MakeValueT, std::size_t MakeN>
    friend auto makeMap(const std::pair<MakeKeyT, MakeValueT> (&init)[MakeN]);

    template <typename MakeKeyT, typename MakeValueT>
    friend auto makeMap();

public:
    std::optional<ValueT> getValue(KeyT key) const
    {
        auto it = lower_bound(
            begin(storage), end(storage), key, [](const std::pair<KeyT, ValueT>& p, KeyT k) { return p.first < k; });
        if (it == end(storage) || it->first != key)
        {
            return std::nullopt;
        }
        return it->second;
    }

    std::size_t size() const noexcept { return N; }
};

template <typename Key, typename Value, std::size_t N>
auto makeMap(const std::pair<Key, Value> (&init)[N])
{
    return staticMapper<Key, Value, N>(init);
}

template <typename Key, typename Value>
auto makeMap()
{
    return staticMapper<Key, Value, 0>();
}

#endif /* VCCB_COM_ComContainers_HPP_ */
