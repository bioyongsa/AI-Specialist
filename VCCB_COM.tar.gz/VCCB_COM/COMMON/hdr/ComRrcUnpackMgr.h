
#ifndef VCCB_MSG_COMMON_ComRrcUnpackMgr_H_
#define VCCB_MSG_COMMON_ComRrcUnpackMgr_H_

#include "ComInclude.min.h"

class RrcUnpackMgr
{
public:
    // For Init Thread
    static void Init(uint8_t threadId);

    // For Unpack Buffer
    static msgUnpack_type *GetUnpackBuffer(uint8_t threadId);
    static RrcUnpackMgrDB_type *GetUnpackMgrBuffer(uint8_t threadId);

    // For IE Buffer
    static NRRRC_HandoverPreparationInformation *GetNrHandoverPreparationInformation(uint8_t threadId);
    static NRRRC_CG_ConfigInfo *GetNrCGConfigInfo(uint8_t threadId);

    // For Unpack
    static int16_t Unpack(uint8_t threadId, uint16_t pduNum, unsigned char *pEnc, long len, bool isForcedUnpack = false, bool isEutra = false);
    static int16_t NrUnpack(uint8_t threadId, uint16_t pduNum, unsigned char *pEnc, long len, bool isForcedUnpack = false);
    static int16_t EutraUnpack(uint8_t threadId, uint16_t pduNum, unsigned char *pEnc, long len, bool isForcedUnpack = false);

#ifdef VCCB_IPC_TEST
    // For Debug
    static uint64_t unpackCount;
    static uint64_t getUnpackCount(void);
    static void setUnpackCount(uint64_t cnt);
    static void incUnpackCount(void);
#endif

protected:
    static uint32_t getTransactionId(bool usage, bool isEutra, uint16_t pduNum, uint16_t length);
};

#endif