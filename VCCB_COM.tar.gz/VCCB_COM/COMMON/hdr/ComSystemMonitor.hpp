/**
 * @file         : ComSystemMonitor.hpp
 * @brief       : header of system monitor
 *
 * @author    : hohyun.kang@samsung.com
 * @date       : 2018/12/06
 *
 * Copyright 2018 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef VCCB_COM_ComSystemMonitor_HPP_
#define VCCB_COM_ComSystemMonitor_HPP_

#include "ComSystemCpuInfoGetter.hpp"

/**
 * @class    ComSystemMonitor
 * @brief    has a function to
 *
 * @remark
 *
 * @see
 *
 * Copyright 2018 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

class ComSystemMonitor
{
public:
    explicit ComSystemMonitor(void);
    virtual ~ComSystemMonitor(void);

    int getMaxCpuNum(void);
    // int getCpuLoad200ms(const int cpuId);
    int getCpuLoad3sec(const int cpuId);
    // int getCpuLoad5min(const int cpuId);
    // int getCpuLoadOneDemand(const int cpuId, const int periodSec);

private:
    ComSystemMonitor(const ComSystemMonitor&);
    ComSystemMonitor& operator=(const ComSystemMonitor&);
};

#endif /* VCCB_COM_ComSystemMonitor_HPP_ */