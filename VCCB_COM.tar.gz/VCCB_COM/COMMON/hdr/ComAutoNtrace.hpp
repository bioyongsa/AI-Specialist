/**
 * @file     : ComAutoNtrace.hpp
 * @brief    : header of
 *
 * @author   : hohyun.kang@samsung.com
 * @date     : 2018/12/06
 *
 * Copyright 2018 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */


#ifndef VCCB_COM_ComAutoNtrace_HPP_
#define VCCB_COM_ComAutoNtrace_HPP_

/**
 * @class        ComAutoNtrace
 * @brief        auto check ntrace
 *
 * RAII wrapper for ntrace macros.
 *
 * @remark
 *
 * @see
 *
 * Copyright 2018 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

class ComAutoNtrace
{
public:
    ComAutoNtrace(const char* name);
    ~ComAutoNtrace();
};

#endif /* VCCB_COM_ComAutoNtrace_HPP_ */
