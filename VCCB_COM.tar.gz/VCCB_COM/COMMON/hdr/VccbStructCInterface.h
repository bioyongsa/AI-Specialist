/**
 * @file     : VccbStructCInterface.h
 * @brief    : header file for functions used as operators defined for objects from VccbStruct.h
 *
 * @author   : m.ciurej.samsung.com
 * @date     : 2022/02/10
 *
 * Copyright 2022 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information). One
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * one entered into with Samsung.
 */
#ifndef VCCB_COM_VccbStructCInterface_H_
#define VCCB_COM_VccbStructCInterface_H_

#include "msg_type_call_5g.h"

int16_t VCOM_CheckPlmnIdentical(const plmnId_type *p1, const plmnId_type *p2);
int16_t FnVCCB_CheckCgiIdentical(const cgi_type *p1, const cgi_type *p2);
int MdsIp_TypeCmp(const MdsIp_Type *lip, const MdsIp_Type *rip);
void copyCgiToCslCgi(const cgi_type* cgi, csl_cgi_type* csl_cgi);

#endif  // VCCB_COM_VccbStructCInterface_H_