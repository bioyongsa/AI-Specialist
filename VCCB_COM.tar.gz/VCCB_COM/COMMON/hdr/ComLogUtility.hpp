#ifndef VCCB_COM_ComLogUtility_HPP_
#define VCCB_COM_ComLogUtility_HPP_

#include "VccbStruct.h"

#define TAB_SIZE 4

bool checkAndUploadShmLog(uint32_t msgSize);
void logInitExtMsgPeerInfo(const callInfo_type *ptCi, enumDirection direction, uint8_t *ptMsg,
    peerInfo_type *ptPeerInfo, const int64_t peerApUeId);
void logShmStr(uint8_t level, uint32_t briefStrLen, uint8_t *briefStr);
void logShmStrDetail(uint32_t briefStrLen, uint8_t *briefStr, uint32_t detailStrLen, uint8_t *detailStr);
void logShmStrCall(
    const callInfo_type *ptCi, uint8_t level, uint32_t briefStrLen, uint8_t *briefStr, uint8_t isCrrLogging);
void logShmMscGenStr(const VccbDbgLog_type &dbgLog, const callInfo_type *ptCi, uint8_t level, uint32_t briefStrLen, uint8_t *briefStr);
void logShmStat(const int method, const int mFamily, const int mType, const VccbPmUpdateVal_type &pmUpdateVal,
    const VccbPmKey_type &pmKey);
void logShmStatCall(const callInfo_type *ptCi, const int method, const int mFamily, const int mType,
    const VccbPmUpdateVal_type &pmUpdateVal, const VccbPmKey_type &pmKey);
void logShmIntMsg(const callInfo_type *ptCi, enumDirection direction, uint8_t apType, uint16_t msgId, uint32_t msgSize,
    uint8_t *ptMsg);
void logShmNonUeIntMsg(
    enumDirection direction, uint8_t apType, uint16_t msgId, uint32_t msgSize, uint8_t *ptMsg, uint8_t invalidFlag);
void logShmExtMsg(
    const callInfo_type *ptCi, enumDirection direction, uint16_t msgId, const void *ptMsg, const int64_t peerApUeId);
void logShmRrcMsg(const callInfo_type *ptCi, enumDirection direction, uint16_t msgId, uint32_t msgSize, uint8_t *ptMsg,
    uint8_t *ptPeerInfoMsg, const int64_t peerApUeId);
void VCOM_InvalidMessageHandler(callInfo_type *ptCi, const message_type *ptAll, const msgUnpack_type *ptUnpack);
const char *strMsgId(uint16_t msgType);
const char *FnVCCB_GetStrBearerType(int bearerType);
const char *FnVCCB_GetStrPduSplitType(enumPduSplitStatus pduSplitType);
const char *FnVCCB_GetStrBuffType(enumBuffType type);
const char *FnVCCB_GetStrCommonStatus(enumCommonStatus_type bearerType);
const char *FnVCCB_GetStrSABearerStatus(enumSABearerStatus_type bearerType);
const char *FnVCCB_GetSnodeRelReason(enumSNodeRelReasonType reason);
const char *FnVCCB_GetSnodeRelOprType(enumMrdcSNRelOpr_type type);
const char *FnVCCB_GetMrdcUeContextType(const callInfo_type *ptCi);
int appendLogMeasResultList2NR(char *buffer, int buffSize, measResultList2NR_type *ptMeasResultList2NR);
int FnVCCB_appendLogMeasResultList2NR_FR1(char *, int, measResultList2NR_type *, const int);
int FnVCCB_appendLogMeasResultList2NR_FR2(char *, int, measResultList2NR_type *, const int);
int FnVCCB_appendLogMeasResultList2NR_NCI(char *, int, measResultList2NR_type *, const int);

void FnVCCB_RequestLogFishing(callInfo_type *ptCi, uint16_t eventId);

void FnVCCB_PrintMeasResultList2NR(callInfo_type *, measResultList2NR_type *, const char *, enumFrFreq_type, const int);
void FnVCCB_PrintMeasResultList2NR_NCI(callInfo_type *, measResultList2NR_type *, const char *, const int);

const char *FnVCCB_GetStrChoStatisticTypeName(int family, int typeId);
const char *FnVCCB_GetStrActivityNotifLvl(enumActivityNotifLvl_type level);
void VCCB_PrintDrxConfigInfo(VccbDrxConfigInfo_type &drxConfig, const char *ptFuncName);

const char *FnVCCB_GetEstablishmentCauseString(NRRRC_EstablishmentCause cause);
const char *FnVCCB_GetResumeCauseString(NRRRC_ResumeCause cause);
const char *FnVCCB_GetX2CauseToStr(const uint32_t cause);
const char *FnVCCB_GetXNCauseToStr(const uint32_t cause);
const char *FnVCCB_GetNGCauseToStr(const uint32_t cause);
const char *FnVCCB_GetF1CauseToStr(const uint32_t cause);
const char *FnVCCB_GetE1CauseToStr(const uint32_t cause);

#endif  // VCCB_COM_ComLogUtility_HPP_
