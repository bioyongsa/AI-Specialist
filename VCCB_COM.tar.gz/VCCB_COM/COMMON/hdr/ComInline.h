#ifndef VCCB_COM_INLINE_H_
#define VCCB_COM_INLINE_H_

#include <string.h>
#include "ComEg.h"
#include "ComLibIpcApi.h"
#include "ComGlobalData.h"
#include "FeatMrdc.h"
#include "ComMacro.h"

static inline const char *FnVCCB_GetFileName(const char *pFileName)
{
    if (pFileName == NULL)
    {
        return "Unknown FileName";
    }

    // The strrchr() function returns a pointer to the first occurrence of the character c in the string s.
    const char *pDst = strrchr(pFileName, '/');

    if (pDst == NULL)
    {
        // NULL if the character is not found
        return pFileName;
    }

    // The strchr() and strrchr() functions return a pointer to the matched character
    //            hear
    //             v
    // VCCB_COM/src/ComLogUtility.cpp

    return pDst + 1;
}

static inline const char *FnVCCB_GetStrStateName(enumVccbCallState_type state)
{
    switch (state)
    {
        case 0 ...(MAX_VCCB_STATE - 1):
            return ENV->fnTable.state[state].name;

        default:
            return "STATE_VCCB_NOT_USED";
    }
}

static inline bool FnVCCB_IsMrdcForSa(const callInfo_type *ptCi)
{
    if (ptCi == NULL) return false;

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        return false;
    }

    if (!IsAvailable_MrdcInfo())
    {
        return false;
    }

    return true;
}

static inline bool FnVCCB_IsNrdcMn(const callInfo_type *ptCi)
{
    if (ptCi == NULL) return false;

    if (FnVCCB_IsMrdcForSa(ptCi) == false)
    {
        return false;
    }

    if (ptCi->mrdcInfo.ueCtxType != UECTX_NRDC_MN)
    {
        return false;
    }

    return true;
}

static inline bool FnVCCB_IsNrdcSn(const callInfo_type *ptCi)
{
    if (ptCi == NULL) return false;

    if (FnVCCB_IsMrdcForSa(ptCi) == false)
    {
        return false;
    }

    if (ptCi->mrdcInfo.ueCtxType != UECTX_NRDC_SN)
    {
        return false;
    }

    return true;
}

static inline bool FnVCCB_IsNrdcAll(const callInfo_type *ptCi)
{
    if (ptCi == NULL) return false;

    if (FnVCCB_IsNrdcMn(ptCi))
    {
        return true;
    }

    if (FnVCCB_IsNrdcSn(ptCi))
    {
        return true;
    }

    return false;
}

static inline bool FnVCCB_IsNedcMn(const callInfo_type *ptCi)
{
    if (ptCi == NULL) return false;

    if (FnVCCB_IsMrdcForSa(ptCi) == false)
    {
        return false;
    }

    if (ptCi->mrdcInfo.ueCtxType != UECTX_NEDC_MN)
    {
        return false;
    }

    return true;
}

/**
 * @brief Returns true if call type if NSA.
 * 
 * @param call info
 * @return true 
 * @return false 
 */
inline bool VCCB_IsEndcSn(const callInfo_type &call)
{
    return (E_CALLTYPE_NSA == call.callType);
}

/**
 * @brief Following is the condition to identify the Cell as 'SA enabled'. '5GS TAC' and 'Configured TAC Indication' is
          delivered via F1 interface from DU.
          - '5GS TAC' value is valid (not 0)
          - 'Configured TAC Indication' is not configured
 *
 * @param cell info
 * @return true
 * @return false
 */
inline bool VCCB_IsCellSaReady(const VccbCellInfo_type &cell)
{
    return ((EQUIP == cell.pldState) && (EQUIP == cell.tacStatus) && (CI_no_use == cell.configuredTacIndication));
}

static inline bool FnVCCB_IsMrdcMn(const callInfo_type *ptCi)
{
    if (ptCi == NULL) return false;

    if (FnVCCB_IsNrdcMn(ptCi))
    {
        return true;
    }

    if (FnVCCB_IsNedcMn(ptCi))
    {
        return true;
    }

    return false;
}

static inline bool FnVCCB_IsMrdcSn(const callInfo_type *ptCi)
{
    if (ptCi == NULL) return false;

    if (VCCB_IsEndcSn(*ptCi))
    {
        return true;
    }

    if (FnVCCB_IsNrdcSn(ptCi))
    {
        return true;
    }

    return false;
}

static inline bool FnVCCB_IsMrdcAll(const callInfo_type *ptCi)
{
    if (ptCi == NULL) return false;

    if (FnVCCB_IsMrdcMn(ptCi))
    {
        return true;
    }

    if (FnVCCB_IsMrdcSn(ptCi))
    {
        return true;
    }

    return false;
}

static inline bool FnVCCB_IsNonDc(const callInfo_type *ptCi)
{
    if (ptCi == NULL) return false;

    if (FnVCCB_IsMrdcAll(ptCi))
    {
        return false;
    }

    return true;
}

static inline int16_t VHCM_isSaHandoverUE(const callInfo_type *ptCi)
{  // {{{
    if (ptCi == NULL) return FALSE;

    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        return FALSE;
    }

    switch (ptCi->hoInfo.hoType.initiated)
    {
        case HO_TYPE_SA_INTRA_GNB_INTRA_DU_HANDOVER:
        case HO_TYPE_SA_INTRA_GNB_INTER_DU_HANDOVER:
        case HO_TYPE_SA_INTER_GNB_NG_HANDOVER:
        case HO_TYPE_SA_INTER_GNB_XN_HANDOVER:
        case HO_TYPE_SA_INTER_SYSTEM_INTER_RAT_HANDOVER:
        case HO_TYPE_SA_INTRA_SYSTEM_INTER_RAT_HANDOVER:
        case HO_TYPE_SA_SGNB_INITIATED:
        case HO_TYPE_SA_MGNB_INITIATED:
        case HO_TYPE_SA_MGNB_INTERMNHO:
        case HO_TYPE_SA_SGNB_INITIATED_INTER_SN_CHANGE:
        case HO_TYPE_SA_MGNB_INITIATED_INTER_SN_CHANGE:
        case HO_TYPE_SA_MGNB_INTERMNHO_INTER_SN_CHANGE:
            return TRUE;

        case HO_TYPE_SA_INIT:
        case HO_TYPE_MAX_OF_SA_HANDOVER:
            return FALSE;

        default:
            break;
    }

    switch (ptCi->stateCmd)
    {
        case IntraRatHO_cmd:
        case InterRatHO_cmd:
            return TRUE;

        default:
            break;
    }

    return FALSE;
}  // }}}

static inline bool FnVCCB_IsConditionalHandoverUE(callInfo_type *ptCi)
{
    if (ptCi == NULL) return false;

    // Valid Handover UE.
    if (VHCM_isSaHandoverUE(ptCi) == FALSE) return false;

    return (ptCi->hoInfo.conditionalHandover) ? true : false;
}

static inline bool FnVCCB_IsSetupedConditionalCell(callInfo_type *ptCi)
{
    if (ptCi == NULL) return false;

    return (ptCi->condHoInfo.numOfCellList > 0);
}

static inline bool FnVCCB_IsEmptyConditionalCell(callInfo_type *ptCi)
{
    if (ptCi == NULL) return false;

    return (ptCi->condHoInfo.numOfCellList == 0);
}

static inline bool FnVCCB_IsSetupedLtmCell(callInfo_type *ptCi)
{
    if (ptCi == nullptr) return false;
    return (ptCi->ltmUeInfo.numOfCellList > 0);
}

static inline bool FnVCCB_IsEmptyLtmCell(callInfo_type *ptCi)
{
    if (ptCi == NULL) return false;

    return (ptCi->ltmUeInfo.numOfCellList == 0);
}

static inline bool FnVCCB_IsValidFiveGsTac(uint32_t fiveGsTac) { return (fiveGsTac <= 0 || fiveGsTac == 0xFFFFFE) ? false : true; }

static inline bool FnVCCB_IsCellQualified_ForPSCell_BasedOnTAC(
    const uint8_t configuredTacInd, const uint8_t fiveGsTacStatus, const uint32_t fiveGsTac)
{
    if (configuredTacInd == CI_use)
    {
        return true;
    }
    if (fiveGsTacStatus == EQUIP && FnVCCB_IsValidFiveGsTac(fiveGsTac))
    {
        return true;
    }
    return false;
}

static inline bool FnVCCB_IsFr1Freq(uint32_t ssbArfcn)  // INTEGER (0..3279165)
{
    switch (ssbArfcn)
    {
        case MIN_A6_NR_ARFCN ... MAX_A6_NR_ARFCN:
            return false;

        case 0 ...(MIN_A6_NR_ARFCN - 1):
            return true;

        default:
            return false;
    }
}

static inline bool FnVCCB_IsFr2Freq(uint32_t ssbArfcn)  // INTEGER (0..3279165)
{
    switch (ssbArfcn)
    {
        case MIN_A6_NR_ARFCN ... MAX_A6_NR_ARFCN:
            return true;

        case 0 ...(MIN_A6_NR_ARFCN - 1):
            return false;

        default:
            return false;
    }
}

static inline void FnVCCB_InitCellGroupConfig(callInfo_type *ptCi)
{
    if (ptCi == NULL) return;

    // mcg cellgroupconfig release
    ptCi->cellGroupConfig.numocts = 0;

    // scg cellgroupconfig release
    if (FnVCCB_CheckValid_MrdcSNRBConfig(&ptCi->mrdcInfo))
        FnVCCB_Mrdc_Init_octetString(ptCi, &ptCi->mrdcInfo.scgRBConfig);

    return;
}

static inline uint16_t FnVCCB_GetSpidIdx(callInfo_type *ptCi)
{
    uint16_t spidIdx = 0;

    if (ptCi == NULL) return 0;

    spidIdx = ptCi->ueInfo.rfsp.subscriberProfile;

    return --spidIdx;
}

static inline void FnVCCB_InitCallThreadBuffer(VccbCallThreadBufferInfo_type *pCallThreadBuf)
{
    if (pCallThreadBuf == NULL) return;

    // VccbCallThreadBufCandidateCellInfoListRxBuf_s :: measResultList2NR_type
    {
        measResultList2NR_type *ptMeasResultList2NR = NULL;

        ptMeasResultList2NR = &pCallThreadBuf->measResultList2NRRx.candidateCellInfoListMN_SCG;
        ptMeasResultList2NR->nrofFreq = 0;

        ptMeasResultList2NR = &pCallThreadBuf->measResultList2NRRx.candidateCellInfoListMN;
        ptMeasResultList2NR->nrofFreq = 0;

        ptMeasResultList2NR = &pCallThreadBuf->measResultList2NRRx.candidateCellInfoListSN;
        ptMeasResultList2NR->nrofFreq = 0;
    }

    // VccbCallThreadBufCandidateCellInfoListRxBuf_s :: measResultServFreqListNR_type
    {
        measResultServFreqListNR_type *pMeasResultServFreqListNR = NULL;

        pMeasResultServFreqListNR = &pCallThreadBuf->measResultList2NRRx.candidateCellInfoListNR;
        pMeasResultServFreqListNR->numResult = 0;
    }

    // measResultNeighCellsEUTRA_type
    {
        measResultNeighCellsEUTRA_type *pMeasResultNeighCellsEUTRA = NULL;

        pMeasResultNeighCellsEUTRA = &pCallThreadBuf->measResultListEutraRx;
        pMeasResultNeighCellsEUTRA->numReportCell = 0;
    }
}

static inline allwedPlmnList_type *FnVCCB_GetAllowedPlmnListByMRL(
    const callInfo_type *ptCi, hoRestrictInfo_type *pMrl, const enumInternalRatRestriction_type ratRestriction)
{
    if (ptCi == NULL || pMrl == NULL) return NULL;

    switch (ratRestriction)
    {
        case MyRATRestriction:

            if (IS_MRDC_SN(ptCi)) return &pMrl->allowedPlmnList[SecondaryRATRestriction];

            return &pMrl->allowedPlmnList[PrimaryRATRestriction];

        case OtherNeRATRestriction:
        default:
            if (IS_MRDC_SN(ptCi)) return &pMrl->allowedPlmnList[PrimaryRATRestriction];

            return &pMrl->allowedPlmnList[SecondaryRATRestriction];
    }
}

// FGR-LC0302 gNB Overload Control
static inline bool FnVCCB_IsDuOverload(VccbGnbInfo_type *ptGnb, uint16_t endPointF1Idx)
{
    if (ptGnb == NULL)
    {
        return false;
    }

    if (VCOM_getSystemType() == e_VCCB_NVGNB)
    {
        return false;
    }

    if (endPointF1Idx >= MAX_GNB_DU_PER_GNB_CU_CP) return false;

    return (ptGnb->gnbDu[endPointF1Idx].overloadStatus == ci_overload) ? true : false;
}

static inline bool FnVCCB_IsNonSsbCell(const VccbCellInfo_type *pCell)
{
    if (pCell == NULL) return false;

    return (FALSE == pCell->isCellSSB);
}

static inline bool FnVCCB_IsExistSaHoTargetDU(callInfo_type *ptCi)
{  // {{{
    if (ptCi == NULL) return false;

    return (GET_F1_RESOURCE_TGT_FLAG(ptCi->flag.setupFlag) && !GET_F1_RESOURCE_TGT_FLAG(ptCi->flag.respFlag));
}  // }}}

static inline bool FnVCCB_IsExistLtmTargetDU(callInfo_type *ptCi, ltmCellInfo_type *pLtmCandi)
{
    if (ptCi == NULL) return false;
    if (pLtmCandi == NULL) return false;

    return (pLtmCandi->handle.flag.setup == TRUE && pLtmCandi->handle.flag.receivedDuUeId == TRUE);
}

static inline bool FnVCCB_CollectSaHandoverStat(callInfo_type *ptCi)
{  // {{{
    if (ptCi == NULL) return false;

    // SVR22C FGR-MC1400 Conditional Handover does not collect statistics.
    if (FnVCCB_IsConditionalHandoverUE(ptCi) == true) return false;
    if (ptCi->hoInfo.isLtmCellSwitch == true) return false;

    // SVR23B FGR-LC0711 IRAT LB Handover does not collect statistics.
    if (ptCi->hoInfo.hoType.rat == HO_TYPE_INTER_RAT && ptCi->hoInfo.isIratLbHo == TRUE) return false;

    return true;
}  // }}}

static inline bool FnVCCB_CollectChoStat(callInfo_type *ptCi)
{  // {{{
    if (ptCi == NULL) return false;

    // SVR22C FGR-MC1400 Conditional Handover
    if (FnVCCB_IsEmptyConditionalCell(ptCi) == true) return false;

    return true;
}  // }}}

/**
 * @brief Returns true if Masked IMEISV field needs to be forwarded to via:
 *            F1_UEContextSetupRequest
 *            Xn_HandoverRequest
 *            Xn_SNodeAdditionRequest
 *            Xn_RetrieveUEContextResponse
 *        Related feature: FGR-CC0351 / Device Aware Call Control / FR10
 * 
 * @return true 
 * @return false 
 */
inline bool VCCB_DACC_ForwardMaskedImeisv()
{
    return (VCCB_FLAG_ON == DBG->flag.DACC_forwardMaskedImeisv);
}

/**
 * @brief Returns true if Masked IMEISV field is stored in call info.
 * 
 * @param call info
 * @return true 
 * @return false 
 */
inline bool VXIL_Check_MaskedIMEISVPresent(const callInfo_type &call)
{
    return (OPT_PRESENT == call.ueInfo.imeisvBuf.maskedIMEISVPresent);
}

/**
 * @brief Returns true if SCG UE History Information Handling is ON
 * 
 * @param gnbNum
 * @return true 
 * @return false 
 */
static inline bool FnVCCB_IsActiveScgUeHistoryHandling(uint16_t gnbNum)
{
    // FGR-CC5201, 24B, FR480.CACP.SR1.HD1.DD1

    if (gnbNum >= MAX_GNB_PER_SYS)
    {
        return false;
    }

    auto &gnbInfo = GNBINFO[gnbNum];

    if (gnbInfo.status != EQUIP)
    {
        return false;
    }

    return (gnbInfo.cfg.scgUeHistoryHandlingOnOff == VCCB_FLAG_ON);
}

/**
 * @brief Returns true if given call is idle.
 * 
 * @param call info
 * @return true 
 * @return false 
 */
inline bool VCCB_IsCallIdle(const callInfo_type &call)
{
    return (((E_CALLTYPE_SA == call.callType) && (STATE_Conn == call.state)) ||
            ((E_CALLTYPE_NSA == call.callType) && (STATE_DB == call.state)));
}

/**
 * @brief Returns true if given call is EN-DC and HO is ongoing.
 * 
 * @param call info
 * @return true 
 * @return false 
 */
inline bool VCCB_ENDC_IsHoOngoing(const callInfo_type &call)
{
    return ((E_CALLTYPE_NSA == call.callType) && (IntraRatHO_cmd == call.stateCmd));
}

/**
 * @brief Returns current UE serving PLM if call state is IDLE.
 *        Returns target cell UE serving PLMN if EN-DC call state is HO.
 * 
 * @param call info
 */
inline plmnId_type VCCB_GetUeServingPlmn(const callInfo_type &call)
{
    return (VCCB_ENDC_IsHoOngoing(call) ? call.hoInfo.tgtPlmn : call.ueInfo.servedPlmn);
}

/**
 * @brief Returns true if a given action is queued for later processing.
 * 
 * @param call info
 * @param action to find in call's queue
 * @return true 
 * @return false 
 */
inline bool VCCB_Q_IsActionQueued(const callInfo_type &call, enqueuedAction action)
{
    return std::find(std::begin(call.actionQueue), std::end(call.actionQueue), action) != std::end(call.actionQueue);
}

/**
 * @brief Remove a given action from call's queue. If action is not present, no change will occur.
 * 
 * @param call info
 * @param action to be removed
 */
inline void VCCB_Q_RemoveQueuedAction(callInfo_type &call, enqueuedAction action)
{
    std::fill(
        std::remove(std::begin(call.actionQueue), std::end(call.actionQueue), action),
        std::end(call.actionQueue),
        ENQUEUE_NO_ACTION
    );
}

/**
 * @brief Returns true if the call is EN-DC and intra-SN PSCell Change is ongoing.
 * 
 */
inline bool VCCB_NSA_IsIntraSnHo(const callInfo_type &call)
{
    return ((E_CALLTYPE_NSA == call.callType) && (IntraRatHO_cmd == call.stateCmd) &&
            (call.hoInfo.hoType.nb == HO_TYPE_INTRA_NB));
}

/**
 * @brief Returns true if the call is EN-DC and inter-DU PSCell Change is ongoing.
 * 
 */
inline bool VCCB_NSA_IsInterDuHo(const callInfo_type &call)
{
    return (VCCB_NSA_IsIntraSnHo(call) && (HO_TYPE_INTER_DU == call.hoInfo.hoType.du));
}

/**
 * @brief Returns true if the call:
 *          - EN-DC; and
 *          - inter-DU PSCell Change is ongoing; and
 *          - interDuHoWithoutSourceDu flag is on.
 * 
 *        "inter-DU HO without source DU" is added to reuse "inter-DU HO" procedure to handle the following scenario:
 *          - "SN term Split" -> "SN term MCG" bearer type change (SCG/DU is released),
 *          - X2 SgNB Modification Request (cause mCG-Mobility, "SN term MCG" -> "SN term Split", Candidate Cell Info List MN)
 * 
 */
inline bool VCCB_NSA_IsInterDuNoScgHo(const callInfo_type &call)
{
    return (VCCB_NSA_IsInterDuHo(call) && (TRUE == call.hoInfo.interDuHoWithoutSourceDu));
}

/**
 * @brief Returns true if the call is EN-DC and SN change is ongoing.
 *
 */
inline bool VCCB_NSA_IsSnChange(const callInfo_type &call)
{
    return ((E_CALLTYPE_NSA == call.callType) && (SgNBAddition_cmd == call.stateCmd) &&
            (SgnbAddTrigInd_Unknown != call.hoInfo.sgnbAddTrigInd));
}

/**
 * @brief Returns max vtmb units number depending on the architecture
 *
 */
inline int VCCB_GetMaxVtmbUnits()
{
#ifdef __CNF__
    return VCCB_MAX_POD_ID_NUM;
#else
    return VCCB_MAX_HA_UNIT_NUM;
#endif
}

static inline bool FnVCCB_IsSupportedHandInPartialServiceType(callInfo_type *ptCi, enumHoStatType type)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);

    // service-type-sa/service-type-onoff"
    if(CFG->acpfInfo.serviceTypeOnOff != TRUE) return false;

    // Parital opration type only
    if (type != HO_PrepFail_E1Fail && type != HO_PrepFail_F1Fail) return false;

    return true;
} 

static inline enumNrLbmConfigurationIndex_type FnVCCB_GetNrLbmParamIndexWithWindowIndexAndPurpose(
    uint8_t windowIndex, uint8_t purpose)
{
    switch (windowIndex)
    {
        case 0:
            return purpose == LBM_PURPOSE_UPDATE ? NR_LBM_WINDOW0_UPDATE : NR_LBM_WINDOW0_FALLBACK;
        case 1:
            return purpose == LBM_PURPOSE_UPDATE ? NR_LBM_WINDOW1_UPDATE : NR_LBM_WINDOW1_FALLBACK;
        default:
            return NR_LBM_DISABLE;
    }
}

static inline bool FnVCCB_IsImmediateHandoverUE(callInfo_type &rCall)
{
    if (VHCM_isSaHandoverUE(&rCall) != TRUE) return false;

    bool isLtmOrChoHo = (rCall.hoInfo.conditionalHandover || rCall.hoInfo.ltmHandover);

    return (isLtmOrChoHo == false);
}

#endif  // VCCB_COM_INLINE_H_
