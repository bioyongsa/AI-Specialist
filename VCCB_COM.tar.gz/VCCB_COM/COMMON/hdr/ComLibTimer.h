#ifndef VCCB_COM_ComLibTimer_H_
#define VCCB_COM_ComLibTimer_H_

/*----------------------------------------------------------------------------
 * Define    :    Include Header Files
 * ---------------------------------------------------------------------------
 */
#include <VccbStruct.h>

/*----------------------------------------------------------------------------
 * Define    :    Function ProtoType
 * ---------------------------------------------------------------------------
 */
void VLIB_AttachTimer(timerInfo_type *pTimer, callInfo_type *ptCi, uint16_t msgId);
void FnVCCB_AttachTimerWithSpecificValue(
    timerInfo_type *pTimer, callInfo_type *ptCi, uint16_t msgId, uint8_t specificValue);
void VLIB_AttachTimerCore(timerInfo_type *pTimer, uint32_t contextId, uint16_t messageType, uint16_t transactionId,
    uint8_t specificValue, int timeVal, uint16_t timerPort, uint8_t ensTimerType, uint8_t coreId);
uint16_t FnVCCB_GetSpecificValueInExpiredTimer(messageHdr_type *pTimer);
void VLIB_AttachTimerAfterSwitchover(callInfo_type *ptCi, timerInfo_type *pTimer);

void VLIB_DetachTimer(timerInfo_type *pTimer);
void FnVCCB_DetachCallMultiTimer(callInfo_type *ptCi);

int VLIB_GetTimerVal(uint16_t tmrId);
uint32_t VLIB_GetTimerVal_FromYangOrCfg(uint16_t tmrId, const callInfo_type *ptCi);
void FnVCCB_clearAllCallTimer(callInfo_type *ptCi, enumTimerType option, uint8_t includeDBStateHandleTimer);
int16_t FnVCCB_FindUeMeasForSonTimerReportInterval(const callInfo_type &rCi, uint32_t &rTimeValue);
int16_t FnVCCB_GetTimerValueOfMrBasedRedirection(callInfo_type &rCall, uint32_t &rTimeValue);
int16_t FnVCCB_FindCaPeriodicalTimerValue(const callInfo_type &rCi, uint32_t &rTimeValue);

void VLIB_DetachTimerNonCore(timerInfo_type *pTimer);
void VLIB_AttachTimerNonCore(timerInfo_type *pTimer, uint16_t messageType, int timeVal, uint16_t timerPort, uint8_t ensTimerType=VCCB_TIMER_TEMPORARY);

#endif
