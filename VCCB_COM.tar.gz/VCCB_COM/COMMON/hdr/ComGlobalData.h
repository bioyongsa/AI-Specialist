/**
 * @file        VccbGlobalData.h
 * @brief       GlobalData of VCCB
 *
 * @author      Access S/W Lab.
 * @date        2018/05/05
 * @version
 */

#ifndef VCCB_COM_ComGlobalData_H_
#define VCCB_COM_ComGlobalData_H_

/*----------------------------------------------------------------------------
 * Define    :    Include Header Files
 * ---------------------------------------------------------------------------
 */
/* External */
#include "MdsInterface.h"

/* Internal */
#include "ComLibRsc.h"
#include "misc_util.h"

/* --------------------------for CallInfo --------------------------*/

VccbInfo_type *FnVCCB_GetgVccbInfo();

extern uint32_t *GetgSeed_();  // [SAM_GV_IMPROVEMENT]
#define gSeed (*GetgSeed_())   // [SAM_GV_IMPROVEMENT]

extern char *GetgVccbLogCodeName_(int code);  // [SAM_GV_IMPROVEMENT]

extern pthread_mutex_t *GetgMemoryUsageMtx_();    // [SAM_GV_IMPROVEMENT]
#define gMemoryUsageMtx (*GetgMemoryUsageMtx_())  // [SAM_GV_IMPROVEMENT]

extern uint8_t *GetgLogFishingRequestCount_();                   // [SAM_GV_IMPROVEMENT]
#define gLogFishingRequestCount (GetgLogFishingRequestCount_())  // [SAM_GV_IMPROVEMENT]

// SAM GV Improvement
extern uint8_t *GetgLastDfcbCallThread();
#define gLastDfcbCallThread (GetgLastDfcbCallThread())

extern uint8_t *GetgLastDfcbRRCThread();
#define gLastDfcbRRCThread (GetgLastDfcbRRCThread())

extern uint8_t *GetgLastVupbCallThread();
#define gLastVupbCallThread (GetgLastVupbCallThread())

extern VccbSegmentPoolInfo_type *GetgSegmentPoolInfo_();  // [SAM_GV_IMPROVEMENT]
#define gRrcSegCapaInfo (*GetgSegmentPoolInfo_())  // [SAM_GV_IMPROVEMENT]

extern segmentPoolManager_type *GetgSegmentPoolManager_();  // [SAM_GV_IMPROVEMENT]
#define gRrcSegNode (*GetgSegmentPoolManager_())    // [SAM_GV_IMPROVEMENT]

extern segmentPoolBuffer_type *GetgSegmentPoolBuffer_();  // [SAM_GV_IMPROVEMENT]
#define gRrcSegBuf (GetgSegmentPoolBuffer_())     // [SAM_GV_IMPROVEMENT]

/* --------------------------for RRM --------------------------*/
extern pthread_mutex_t *GetgVrrmGnbCfgMtx_();   // [SAM_GV_IMPROVEMENT]
#define gVrrmGnbCfgMtx (*GetgVrrmGnbCfgMtx_())  // [SAM_GV_IMPROVEMENT]

extern pthread_mutex_t *GetgVrrmCellCfgMtx_();   // [SAM_GV_IMPROVEMENT]
#define gVrrmCellCfgMtx (GetgVrrmCellCfgMtx_())  // [SAM_GV_IMPROVEMENT]

extern pthread_mutex_t *GetgActiveUeBitmapMtx_();       // [SAM_GV_IMPROVEMENT]
#define gActiveUeBitmapMtx (*GetgActiveUeBitmapMtx_())  // [SAM_GV_IMPROVEMENT]

extern pthread_mutex_t *GetgAuditTaskMtx_();  // [SAM_GV_IMPROVEMENT]
#define gAuditTaskMtx (*GetgAuditTaskMtx_())  // [SAM_GV_IMPROVEMENT]

extern pthread_mutex_t *GetCellNumAllocMtx_();
#define gCellNumAllocMtx (*GetCellNumAllocMtx_())

extern pthread_mutex_t *GetgCellHistUpdateMtx_();
#define gCellHistUpdateMtx (GetgCellHistUpdateMtx_())

extern pthread_mutex_t *GetgCellUeMeasForSonMtx_();
#define gCellUeMeasForSonMtx (GetgCellUeMeasForSonMtx_())

extern pthread_mutex_t *GetgIRNTIAllocMtx_();
#define gIRNTIAllocMtx (GetgIRNTIAllocMtx_())

#ifdef __CNF__
extern pthread_mutex_t *GetgDistCodeMtx_();
#define gDistCodeMtx (GetgDistCodeMtx_())
#endif

// SVR26A FGR-CC3103 IODT RACS(UE Radio Capability Signaling Optimization)
extern pthread_rwlock_t *GetgRacsCapaIdListMtx_();
extern pthread_rwlock_t *GetgRacsCapaBufferListMtx_();
#define gRacsCapaIdListMtx     (GetgRacsCapaIdListMtx_())
#define gRacsCapaBufferListMtx (GetgRacsCapaBufferListMtx_())


extern uint16_t *GetgAnrMrCountCellNum_();                      // [SAM_GV_IMPROVEMENT]
#define gAnrMrCountCellNum (*GetgAnrMrCountCellNum_())          // [SAM_GV_IMPROVEMENT]
extern uint16_t *GetgIRatAnrMrCountCellNum_();                  // [SAM_GV_IMPROVEMENT]
#define gIRatAnrMrCountCellNum (*GetgIRatAnrMrCountCellNum_())  // [SAM_GV_IMPROVEMENT]

VccbSystem_type VCOM_getSystemType(void);
void FnVCCB_setSystemType(VccbSystem_type status);
uint8_t FnVCCB_IsIpcTest(void);
uint8_t VCOM_IsHostSim(void);
uint8_t VCOM_getUnitType(uint16_t block);

// [SAM_GV_IMPROVEMENT_22A]
bool GetgEgFlag();
void SetgEgFlag(bool egSetFlag);

int32_t GetEgLevel();
void SetEgLevel(int32_t egLevel);

extern bool *GetsTriggerOndemandHandoverByPLD_();
#define sTriggerOndemandHandoverByPLD *GetsTriggerOndemandHandoverByPLD_()
extern uint16_t *GetmappingCellNumAndPldCellIdx();
#define mappingCellNumAndPldCellIdx GetmappingCellNumAndPldCellIdx()

// Get Handover Preparation DB
uint8_t *FnVCCB_Get_HandoverPreparationBufferForCallDB(callInfo_type *ptCi);

extern VccbStatisticsItemCollect_type *GetgStatisticsItemCollect_();
#define gStatisticsItemCollect (GetgStatisticsItemCollect_())

extern VccbStatisticsItemUpdate_type  *GetgStatisticsItemUpdate_();
#define gStatisticsItemUpdate (GetgStatisticsItemUpdate_())

// [SAM_GV_IMPROVEMENT
extern uint32_t (*GetgCallStatisticsMessageCount_())[STATISTICS_METHOD_TYPE_MAX][STATISTICS_MESSAGE_TIME_MAX];
#define gCallStatisticsMessageCount (GetgCallStatisticsMessageCount_())

#endif  // VCCB_COM_ComGlobalData_H_
/* EOF */
