#ifndef VCCB_COM_TimeUtil_H_
#define VCCB_COM_TimeUtil_H_

#include "VccbStruct.h"

namespace ComTimeUtil
{
int get_current_time(struct timespec &ts);
int get_current_time(struct timeval &tv);
struct timespec get_elapsed_time(const struct timespec &past);
struct timespec get_elapsed_time(const struct timespec &now, const struct timespec &past);
struct timeval get_elapsed_time(const struct timeval &past);
struct timeval get_elapsed_time(const struct timeval &now, const struct timeval &past);
void stopwatch_start(Stopwatch_type &stopwatch);
struct timespec stopwatch_stop(Stopwatch_type &stopwatch);
struct timespec stopwatch_get_elapsed_time(const Stopwatch_type &stopwatch);

static inline float getTimeSecondInFloat(const struct timespec &time)
{
    return (float)((float)(time.tv_sec) + ((float)(time.tv_nsec) / 1000000000.0F));
}
static inline float getTimeMilliSecondInFloat(const struct timespec &time)
{
    return (float)(((float)(time.tv_sec) * 1000.0F) + ((float)(time.tv_nsec) / 1000000.0F));
}
}  // namespace ComTimeUtil

static inline float FnVCCB_GetTimeMilliSecond(const struct timespec *pTimespec)
{
    return (float)(((float)(pTimespec->tv_sec) * 1000.0F) + ((float)(pTimespec->tv_nsec) / 1000000.0F));
}

static inline uint64_t FnVCCB_GetTimeNanoSecond(const struct timespec *pTimespec)
{
    return (static_cast<uint64_t>(pTimespec->tv_sec) * 1000000000UL) + static_cast<uint64_t>(pTimespec->tv_nsec);
}

#endif