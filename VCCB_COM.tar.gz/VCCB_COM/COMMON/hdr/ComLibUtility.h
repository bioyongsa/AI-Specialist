#ifndef VCCB_COM_ComLibUtility_H_
#define VCCB_COM_ComLibUtility_H_

#include "VccbStruct.h"
#include "ComInclude.h"

bool FnVCCB_IsSaRreUE(const callInfo_type &callInfo);
bool FnVCCB_IsSaMobilityUE(const callInfo_type &callInfo);
bool FnVCCB_IsSaIntraGnbHoUE(const callInfo_type &callInfo);
bool FnVCCB_IsSaIntraGnbRreUE(const callInfo_type &callInfo);
bool FnVCCB_IsSaIntraGnbMobilityUE(const callInfo_type &callInfo);

uint16_t FnVCCB_GetTargetCellNumForUpm(const callInfo_type * const ptCi);

typedef enum
{
    /*  0 */ VCCB_HAS_KEY_START = 0,  //[NOTICE] Do not use key=0(zero key is used for while-loop escape condition)
    /*  1 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_0 = 1,
    /*  2 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_1,
    /*  3 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_2,
    /*  4 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_3,
    /*  5 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_4,
    /*  6 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_5,
    /*  7 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_6,
    /*  8 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_7,
    /*  9 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_8,
    /* 10 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_9,
    /* 11 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_10,
    /* 12 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_11,
    /* 13 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_12,
    /* 14 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_13,
    /* 15 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_14,
    /* 16 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_15,
    /* 17 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_16,
    /* 18 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_17,
    /* 19 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_18,
    /* 20 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_19,
    /* 21 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_20,
    /* 22 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_21,
    /* 23 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_22,
    /* 24 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_23,
    /* 25 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_24,
    /* 26 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_25,
    /* 27 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_26,
    /* 28 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_27,
    /* 29 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_28,
    /* 30 */ VCCB_HAS_KEY_CALL_INFO_CHUNK_29,
    /* 31 */ VCCB_HAS_KEY_CELL_INFO_1,
    /* 32 */ VCCB_HAS_KEY_CELL_INFO_2,
    /* 33 */ VCCB_HAS_KEY_GNB_ENV_INFO_GNB_0,
    /* 34 */ VCCB_HAS_KEY_GNB_ENV_INFO_GNB_1,
    /* 35 */ VCCB_HAS_KEY_GNB_ENV_INFO_GNB_2,
    /* 36 */ VCCB_HAS_KEY_GNB_ENV_INFO_GNB_3,
    /* 37 */ VCCB_HAS_KEY_GNB_ENV_INFO_GNB_4,
    /* 38 */ VCCB_HAS_KEY_GNB_ENV_INFO_GNB_5,
    /* 39 */ VCCB_HAS_KEY_GNB_ENV_INFO_GNB_6,
    /* 40 */ VCCB_HAS_KEY_GNB_ENV_INFO_GNB_7,
    /* 41 */ VCCB_HAS_KEY_GNB_ENV_INFO_GNB_8,
    /* 42 */ VCCB_HAS_KEY_GNB_ENV_INFO_GNB_9,
    /* 43 */ VCCB_HAS_KEY_GNB_ENV_INFO_GNB_10,
    /* 44 */ VCCB_HAS_KEY_GNB_ENV_INFO_GNB_11,
    /* 45 */ VCCB_HAS_KEY_GNB_ENV_INFO_GNB_12,
    /* 46 */ VCCB_HAS_KEY_GNB_ENV_INFO_GNB_13,
    /* 47 */ VCCB_HAS_KEY_GNB_ENV_INFO_GNB_14,
    /* 48 */ VCCB_HAS_KEY_GNB_ENV_INFO_GNB_15,
    /* 49 */ VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_0,
    /* 50 */ VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_1,
    /* 51 */ VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_2,
    /* 52 */ VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_3,
    /* 53 */ VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_4,
    /* 54 */ VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_5,
    /* 55 */ VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_6,
    /* 56 */ VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_7,
    /* 57 */ VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_8,
    /* 58 */ VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_9,
    /* 59 */ VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_10,
    /* 60 */ VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_11,
    /* 61 */ VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_12,
    /* 62 */ VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_13,
    /* 63 */ VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_14,
    /* 64 */ VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_15,
    /* 65 */ VCCB_HAS_KEY_GNB_NUM_INFO,  // has_sync is not used but dump from active is needed
    /* 66 */ VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_0,
    /* 67 */ VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_1,
    /* 68 */ VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_2,
    /* 69 */ VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_3,
    /* 70 */ VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_4,
    /* 71 */ VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_5,
    /* 72 */ VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_6,
    /* 73 */ VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_7,
    /* 74 */ VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_8,
    /* 75 */ VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_9,
    /* 76 */ VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_10,
    /* 77 */ VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_11,
    /* 78 */ VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_12,
    /* 79 */ VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_13,
    /* 80 */ VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_14,
    /* 81 */ VCCB_HAS_KEY_GNB_SUPPORT_BAND_INFO_GNB_15,
    /* 82 */ VCCB_HAS_KEY_END
} VCCB_HAS_KEY_REDUNDANCY;

typedef enum
{
    VCCB_HAS_SYNC_TYPE_CALL,
    VCCB_HAS_SYNC_TYPE_CELL,
} VCCB_HAS_SYNC_TYPE;

int FnVCCB_ExecuteCommand(const char *ptCmd);

int16_t VLIB_FreeCallPduInfo(callInfo_type *ptCi, uint16_t pduIdx);
int16_t VLIB_FreeCallSrbInfo(callInfo_type *ptCi, uint16_t srbIdx);
int16_t VLIB_FreeCallErabInfo(callInfo_type *ptCi, uint16_t erabIdx);
int16_t VLIB_FreeCallGnbInfo(callInfo_type *ptCi, uint16_t gnbIdx);
int16_t VLIB_FreeCallDrbInfoUnderPdu(callInfo_type *ptCi, uint16_t pduIdx, uint16_t pduDrbIdx);
int16_t VLIB_FreeCallQosFlowInfoUnderPdu(callInfo_type *ptCi, uint16_t pduIdx, uint16_t pduQosIdx);
int16_t VLIB_FreePathInfo(callInfo_type *ptCi, uint16_t gnbIdx, uint16_t erabIdx, uint16_t pathType);
int16_t VLIB_FillCallErabInfo_New(callInfo_type *ptCi, callERABInfo_type *ptRi, uint16_t msgId);

int16_t VLIB_AllocPathInfo(callInfo_type *ptCi, uint16_t gnbIdx, uint16_t erabIdx, uint16_t pathType);
int16_t VLIB_AllocCallGnbInfo(callInfo_type *ptCi, uint16_t *ptGnbIdx);
int16_t VLIB_AllocCallErabInfo(uint32_t msgId, callInfo_type *ptCi, uint8_t erabIdx);
void VLIB_SetCurrentTime(vccbTimeInfo_type *ptTime);
void VLIB_ConvertTimeToTm(vccbTimeInfo_type *ptTime, struct tm *ptTm);
void VIIL_calcTimeDiff(vccbTimeInfo_type *ptTimeTarget, vccbTimeInfo_type *ptTimeStart, vccbTimeInfo_type *ptTimeEnd);
int16_t VLIB_AllocCallSrbInfo(callInfo_type *ptCi, uint8_t srbIdx);
uint16_t GetMaxCIDAsSession(uint16_t choiceSession);
uint16_t GetMaxEhcCIDAsSession(uint16_t choiceSession);
// int16_t FnVCCB_FillCallRbInfoPer5qi(callInfo_type *ptCi, callDRBInfo_type *ptDi);

int16_t VLIB_getArfcnFromMeasResult2NR(measResult2NR_type *ptMeasResult2NR, enumRSType rsType, uint32_t *arfcn);
int16_t VLIB_CheckSplitDrb(callInfo_type *ptCi);
int16_t VLIB_CheckEnableForSpidbasedUlPathSwitch(callInfo_type *ptCi, uint16_t cellNum);
int16_t VLIB_CheckToMakeA1A2UlPrimaryPathSwitch(callInfo_type *ptCi, uint16_t cellNum);
int16_t VLIB_GetReleaseCallInfo(msgCallReleaseCommand_type *ptMsg, uint16_t interface, uint16_t gnbNum,
    uint16_t endPointIdx, uint32_t callId, callInfo_type **ptCi, VccbReleaseCallSelectionCause_type &rSelectionCause); // 23A_NRRetainability
int16_t VLIB_GetGnbNumFromId(uint16_t *gnbNum, uint32_t gnbId);

void VLIB_getPriorityLevelQos(qosFlowInfo_type *ptQi, uint16_t *ptPriorityLevel);
void VLIB_getFiveQi(qosFlowInfo_type *ptQi, uint8_t *ptFiveQi);

uint8_t VLIB_findCellPlmnIndex(uint16_t cellNum, uint32_t plmnLongId);

uint8_t convertNeDcScgFailType(uint8_t failInfo);      // NEDC_SCG_FAILURE_20C
uint8_t convertNeDcScgFailInfo(uint8_t failType);      // NEDC_SCG_FAILURE_20C
uint8_t getMgnbInitRelSenbIdx(uint8_t failInfo);       // NEDC_SCG_FAILURE_20C
uint32_t VLIB_GetNedcSnodeEnbId(callInfo_type *ptCi);  // NEDC_SCG_FAILURE_20C

int16_t VLIB_IncTimTransactionId(int16_t transactionId);
int16_t VLIB_IncRRCTransactionId(uint8_t *transactionId);

int VLIB_CheckAddrOfPool(const char *file, int line, uint32_t type, const void *base, const void *ptr, int *ptCause);

struct timespec tickGetMono(void);
long VLIB_getTickDifference(struct timespec prevTime);
long VLIB_getTickDifferenceWithTime(struct timespec prevTime, struct timespec specTime);  // ODF_HO_21B
long long VLIB_getTickDifferenceNanoSec(struct timespec prevTime);

void VLIB_CallFaultSave(callInfo_type *ptCi, uint32_t msgId, uint16_t cause, const char *fnName);
const char *VLIB_FailureTypeToStr(uint32_t failureType);
const char *VLIB_FailureTypeToStr_r16(uint32_t failureType);
const char *VLIB_RreCauseToStr(uint16_t cause);
const char *VLIB_ScgFailureCauseToStr(uint16_t cause);
const char *VLIB_UeAllPowerClassToStr(uint16_t pc);
const char *VLIB_ReportConfigTypeToStr(uint32_t repType);

int VLIB_HexstrToInt(uint32_t numByte, unsigned char *value, uint32_t len, uint32_t *intValue);
int16_t FnVCCB_Fill_CellInfo_NRCGI(const uint16_t cellNum, cgi_type *ptOut);
int16_t FnVCCB_Fill_CellNbr_NRCGI(const uint16_t cellNum, const uint16_t nbrIdx, cgi_type *ptOut);
cgi_type FnVCCB_GetCellNbr_NRCGI(const nbrCellInfo_type &cellNbr);
int16_t FnVCCB_Fill_CellEutraNbr_ECGI(const uint16_t cellNum, const uint16_t nbrIdx, cgi_type *ptOut);
uint64_t VLIB_GnbIdCellId2NrCellId(const gnbId_type *pGnbId, uint16_t cellId);
uint16_t VLIB_NrCellId2CellId(const uint8_t gnbIdLen, const uint64_t NCI_36bit);
uint32_t VLIB_NrCellId2GnbId(const uint8_t gnbIdLen, const uint64_t NCI_36bit);

void VLIB_UploadShmLogs(void);
void FnVCCB_UploadShmLogAll(void);
void VLIB_UploadShmFishingLogs(void);

enumActivityNotificationMode getInactivityVendor(callInfo_type *ptCi);

void VLIB_FillSuspendTimeStartCsl(callInfo_type *ptCi);
void VLIB_FillSuspendTimeEndCsl(callInfo_type *ptCi);

void VLIB_InitCallErabInfo(callInfo_type *ptCi, callERABInfo_type *ptRi, uint8_t erabIdx);
void VLIB_InitCallSrbInfo(callInfo_type *ptCi, callSRBInfo_type *ptSi, uint8_t srbIdx);

void FnVCCB_InitCellRscInfo(sonCellPrbRsc_type *pCellRscInfo);
void FnVCCB_InitCellCacInfo(sonCellSliceCac_type *pCellCacInfo); // SVR23B FGR-L0706 NR Resource Status Reporting
void VLIB_Store_PLDCellPlmnIndexInfo(VccbCellInfo_type *pCell);

int16_t FnVCCB_SyncData(const uint8_t threadId, unsigned long unsynced, char *pAddr, const int hasKey);

int FnVCCB_GetHasKeyByCallId(const uint32_t callId);
int16_t FnVCCB_BackupCallInfoPartial(callInfo_type *ptCi, void *addr, const unsigned long size);
int16_t FnVCCB_BackupCallInfo(callInfo_type *ptCi);

int FnVCCB_GetHasKeyByCellNum(const uint32_t cellNum);
void FnVCCB_BackupCellInfoPartial(uint16_t cellNum, void *addr, const unsigned long size);
void FnVCCB_BackupCellInfo(uint16_t cellNum);
void FnVCCB_BackupCellNbrInfo(uint16_t cellNum);
void FnVCCB_BackupCellEutraNbrInfo(uint16_t cellNum);
#if defined(__CNF__) || defined(IPC_TEST)
void FnVCCB_RedisUpdateGnbInfoFlagOn(uint16_t gnbNum);
void FnVCCB_RedisUpdateGnbNumInfoFlagOn(void);
void FnVCCB_RedisUpdateCellInfoFlagOn(uint16_t cellNum);
#endif
void FnVCCB_InitGnbInfo(uint16_t gnbNum);
void FnVCCB_InitGnbRrcSaTimerProfile(int gnbNum, int profileIndex);
void FnVCCB_InitGnbRrcEndcTimerProfile(int gnbNum, int profileIndex);
void FnVCCB_InitNrdcRfspBasedUlPathSwitchCtrl(NrdcCellInfo_type *pNrdcCellInfo);
void FnVCCB_InitCellInfo(void);
void FnVCCB_InitTimerValue();
void FnVCCB_InitAllowedCaConfig(void);
void VCCB_InitMeasObjectBlacklistCells_PerPlmn(measurementObjectBlacklistCells_PlmnSupportEntry_type &plmnSupportEntry);
void VCCB_InitMeasObjectBlacklistCells(VccbCellInfo_type *pCell);
void VCCB_InitYangCbrsInfo(cbrsInfo_type *pCbrsInfo);

int16_t VIIL_CrrClassification(uint16_t callFaultCause);

void VHCM_StateTriggerEventForSNAddition(callInfo_type *ptCi, int type, const char *fnName);

uint16_t VCCB_FindF1IndexUelocated(callInfo_type *ptCi);
int16_t FnVCCB_GetCellNumFromCellId(uint16_t gnbNum, uint16_t cellIdentity, uint16_t *pCellNum);
int16_t VCCM_GetCellNumFromNrCgi(uint16_t gnbNum, cgi_type *pNRCGI, uint16_t *pCellNum, bool logOpt);
uint16_t FnVCCB_GetCellNumFromNbrInfo(const nbrCellInfo_type &rNbrCellInfo);

void VCCB_SetBearerReleaseInfo(releaseInfo_type *ptRelInfo, releaseTrigger_type triggerType, uint16_t cause);
void VLIB_updateSuspendedCellInfo(callInfo_type *ptCi);
uint8_t FnVCCB_GetMappedRRCEstablishmentCause(uint8_t resumeCause);

int16_t VLIB_checkRadioBearerStatusForMobility(callInfo_type *ptCi);  // NG_HOREQ_PDU_QFI_DIFF_21B

void VLIB_SetStatusToFailforAllRequestedPduAndQosFlow(callInfo_type *ptCi, uint16_t cause);
void VLIB_SetStatusToFailforAllRequestedBearerWithForced(callInfo_type *ptCi, uint16_t forcedCause);
uint8_t VLIB_GetPduSessionNumOnSetupOrModi(callInfo_type *ptCi);
bool FnVCCB_IsMandatoryF1DRBsSetupList(callInfo_type *ptCi);
void VLIB_CancelNasPduByFailedPDU(callInfo_type *ptCi);
int16_t VLIB_IsCommonValidStateOfPduQosDrb(uint8_t status);
int16_t VLIB_IsCommonValidStateOfPduQosDrbForQosMonitoring(uint8_t status);

uint16_t VLIB_GetGnbNumFromGnbIdx(uint32_t gnbId, uint8_t gnbNum);

int16_t VLIB_GetNbrGnbNrCellIdByPciAndFreq(callInfo_type *ptCi, uint32_t usedFreq,
    const measResultNR_type *ptMeasResultNR, enumRSType rsType, uint64_t *ptNci);
int16_t VLIB_GetNbrEnbEutraCellIdByPciAndFreq(
    callInfo_type *ptCi, uint32_t earfcnDl, uint16_t physCellId, uint64_t *ptEci);

int16_t FnVCCB_GetNbrPlmnList(
    callInfo_type *ptCi, uint16_t cellNum, uint16_t nbrIdx, allowedPlmnList_Type *pOutPlmnList);

int16_t VLIB_IsInServiceCell(callInfo_type *ptCi, uint16_t cellNum, uint16_t printErrorLog);
int16_t VLIB_IsCellBarred(callInfo_type *ptCi, uint16_t cellNum, uint16_t printErrorLog);

int16_t FnVCCB_CheckFailCond_InterRatHoOrRedirection(callInfo_type *ptCi, uint16_t msgId, enumCheckHoOrRedirectionState_type checkState);
void FnVCCB_CheckAndSetVoiceFallbackIndicator(callInfo_type *ptCi);

int16_t FnVCCB_ExistSNTermBearerToBeSetupInCall(
    callInfo_type *ptCi, uint8_t needAMBearerCheck, uint8_t needSplitBearerCheck);
int16_t FnVCCB_ExistSNTermBearerToBeReleaseInCall(callInfo_type *ptCi);
int16_t FnVCCB_ExistSNTermBearerInPdu(callInfo_type *ptCi, callPDUSessInfo_type *ptPi);
int16_t FnVCCB_ExistValidSNTermBearerInPdu(callInfo_type *ptCi, callPDUSessInfo_type *ptPi);
int16_t FnVCCB_ExistMNTermBearerInNrdcSN(callInfo_type *ptCi);
int16_t FnVCCB_GetDRBIndexFromDRBId(callInfo_type *ptCi, uint8_t drbId, uint8_t *pDrbIndex);
uint16_t FnVCCB_GetPDUSessIndexFromPDUSessID(callInfo_type *ptCi, uint16_t pduSessId);
int16_t FnVCCB_IsSameTwoTransportLayerInfo(transportLayerInfo_type *s1, transportLayerInfo_type *s2);
int16_t FnVCCB_CheckDuplicatedPDUSessionID(NGAP_PDUSessionResourceSetupListCxtReq_type *ptList);

void VLIB_CreateRedirectionInfoNrFromMeasObjectDb(
    redirectionInfoNr_type *output, const measurementObjectNRBaseDb_type *);
void VLIB_CreateRedirectionInfoNrFromMeasObjectUe(redirectionInfoNr_type *output, const measurementObjectNRUe_type *);
void VLIB_CreateRedirectionInfoEutraFromMeasObjectDb(
    redirectionInfoEutra_type *output, const measurementObjectEUTRABaseDb_type *, uint32_t overlappedCarrierFreq);
void VLIB_CreateRedirectionInfoEutraFromMeasObjectUe(
    redirectionInfoEutra_type *output, const measurementObjectEUTRAUe_type *);
bool FnVCCB_IsSetupOrModify(uint8_t brStatus);
int16_t FnVCCB_IsCallToBackup(callInfo_type *ptCi);
int16_t FnVCCB_BackupCallRestrictInfo(callInfo_type *ptCi);
void FnVCCB_BackupCallLocRpt(callInfo_type *ptCi);
void FnVCCB_BackupE1InactivityInfo(callInfo_type *ptCi, uint8_t drbFlag);
void FnVCCB_ConvertUndefinedCRR(callInfo_type *ptCi, uint16_t *pCause);
void VLIB_FreeNRPPaData(callInfo_type *ptCi);
void FnVCCB_fillF1_Cause(uint16_t f1Cause, F1_Cause *ptCause);

void FnVCCB_UpdateGnbSupportBand_byCellPLDUpdate(
    uint16_t cellNum, uint8_t gnbNum, const PLDCellStatus *pNewPld, enumCellPldUpdateOption_type pldUpdateOption);
void FnVCCB_UpdateGnbSupportedBandList(uint16_t cellNum, uint8_t gnbNum, cellBand_changedInfo_type *pChgInfo);
uint8_t FnVCCB_isAlreadyExist_inGnbBand(gnbSupportedBandInfo_type *pBandList, uint16_t value);

callPDUSessInfo_type *FnVCCB_FindCallPduInfo_FromPduSessId(callInfo_type *, const uint8_t, uint16_t *);
callDRBInfo_type *FnVCCB_FindCallDrbInfo_FromDrbId(callInfo_type *, const uint8_t, uint16_t *);
int FnVCCB_GetActiveUnitId(uint16_t blockType);

int16_t FnVCCB_UpdateRRCInactStateAndDoActionIfExpiry(callInfo_type *ptCi, enumRRCInactiveEvent_type event);

void FnVCCB_RecordTime(timeRecord_type *t);

bool FnVCCB_IsExistActiveSNTermDrb_NrdcSN(const callInfo_type *ptCi);
bool FnVCCB_CheckNeedSendActivityNotiToMN_DRBLevel_NrdcSN(const callInfo_type *ptCi);

int16_t FnVCCB_TimeToBCD(const vccbTimeInfo_type *const pTimeInfo, uint8_t *const pBcdTime, uint8_t len);

int VLIB_IsAnyFr2MoThatCanBeConfOnUe(callInfo_type *ptCi);
int VLIB_GetDrbIdxByDrbId(const callInfo_type *ptCi, uint8_t drbId, uint8_t *pDrbIdx);
int VLIB_IsPdcpBufBasedFr2PscellChgSatisfied(callInfo_type *ptCi);
uint8_t VLIB_CountDrbWithAboveDlTrafficThldFlagOn(const callInfo_type *ptCi);
uint8_t VLIB_CountDrbWithAboveDlTrafficThldFlagOn_SA(const callInfo_type *ptCi);
int16_t FnVCCB_GetServiceGroupIdByDrb(
    callInfo_type *ptCi, uint8_t *ptSvcGrpId, callDRBInfo_type *pDrb, uint8_t isReleaseProcedure);
int16_t FnVCCB_GetServiceGroupId(callInfo_type *ptCi, uint8_t *ptSvcGrpId, uint8_t isReleaseProcedure);
int16_t FnVCCB_GetDefaultServiceGroupPriority(callInfo_type *ptCi, serviceGroupPriorities_type *ptSvcGrpPriorities);
int16_t FnVCCB_GetServiceGroupIdByDrbWithPriorityTable(callInfo_type *ptCi, uint8_t *ptSvcGrpId, callDRBInfo_type *pDrb,
    const serviceGroupPriorities_type *ptSvcGrpPriorities, uint8_t isReleaseProcedure);
int16_t FnVCCB_GetServiceGroupIdWithPriorityTable(
    callInfo_type *ptCi, uint8_t *ptSvcGrpId, const serviceGroupPriorities_type *ptSvcGrpPriorities, uint8_t isReleaseProcedure);

cgi_type FnVCCB_GetNrcgiFromCellInfo(const VccbCellInfo_type *ptCell);
cgi_type FnVCCB_GetNrcgiFromCellNum(uint16_t cellNum);
void FnVCCB_InitFreqAutoConfig(VccbCellInfo_type *pCell);

void VLIB_Init_NrppaMeasId(callInfo_type *ptCi);
uint16_t FnVCCB_GetRfspValue(callInfo_type *ptCi);

void FnVCCB_InitMultiCarrierOperation(uint16_t gnbNum);

void FnVCCB_Buffer_RightShift(unsigned char buffer[MAX_DAT_LEN], const unsigned int length, const uint8_t offset);
void FnVCCB_InitSnStatusFlag(callInfo_type *ptCi);
bool FnVCCB_IsSnStatusReceivedFromSNode(callInfo_type *ptCi);

void FnVCCB_InitQosFlowDataFwdInfo(QosFlowDataFwdInfo_type *ptInfo);
void FnVCCB_InitPduDataFwdTunnel(PduDataFwdTunnel_type *ptInfo);
void FnVCCB_InitDrbDataFwdTunnel(DrbDataFwdTunnel_type *ptInfo);
void FnVCCB_InitDrbPdcpSnStatus(DrbPdcpSnStatus_type *ptInfo);
void FnVCCB_InitAllDrb_DataFwdTunnelAndSnStatus(callInfo_type *ptCi);
int16_t FnVCCB_IsVoNrEmergencyCall(callInfo_type *ptCi);

bool FnVCCB_IsGnbBlocklisted(callInfo_type *ptCi, vccbGlobalGnbId_type gnbId);
bool FnVCCB_CheckValidStateOfPduQosDrb(uint8_t status, uint8_t isReleaseProcedure);
int FnVCCB_GetLongDrxCycleTime(enumVccbLongDrxCycle_type longDrxCycle);
int FnVCCB_GetShortDrxCycleTime(enumVccbShortDrxCycle_type shortDrxCycle);

uint32_t VLIB_CheckUpperLimit(const char *file, int line, uint32_t limit, uint32_t val);
int16_t FnVCCB_IsVoNRCall(callInfo_type *ptCi);
int16_t FnVCCB_ExistUeAssistanceInformation(const callInfo_type *ptCi);

bool FnVCCB_CheckMroEnabled(uint8_t checkType, callInfo_type *ptCi);

int VLIB_GetDrbIdxByDrbId_NSA(const callInfo_type *ptCi, uint8_t drbId, uint8_t *pDrbIdx);
int VLIB_GetDrbIdxByDrbId_SA(const callInfo_type *ptCi, uint8_t drbId, uint8_t *pDrbIdx);
void FnVCCB_SetInitTimer(const uint32_t msgId, const int timeValue);
enumActivityNotifLvl_type FnVCCB_Get_UserInactivity_NotiLevel(const callInfo_type *const ptCi);

bool FnVCCB_setSpidCounterIndex(callInfo_type *ptCi, uint16_t &SPID);
bool FnVCCB_IsQciAndSpidStatSuppConfigured(callInfo_type *ptCi, callERABInfo_type *ptRi);

#ifdef __CNF__
int FnVCCB_GetAcpfNeId(int64_t& neId);
int FnVCCB_GetPodId(uint16_t& unitType, uint16_t& unitId);
int FnVCCB_GetAcpfRedundancyMode(enumCnfHaSupport_type& isSupportHA);
int FnVCCB_GetK8sNamespace(char (&k8sNamespace)[VCCB_MAX_K8S_NAMESPACE_NAME_LEN + 1]);
int FnVCCB_GetPodNamePrefix(char (&podNamePrefix)[VCCB_MAX_CNF_PREFIX_LEN + 1]);
int FnVCCB_GetK8sImage(char (&swVer)[SW_VER_STR_LENGTH], const char (&podName)[VCCB_MAX_POD_NAME_LENGTH + 1], const char (&k8sNamespace)[VCCB_MAX_K8S_NAMESPACE_NAME_LEN + 1]);
int FnVCCB_MakePodSvcName(char *buff, size_t buffSize, enumVccbPod_type podType, int unitId);
int FnVCCB_GetPodSvcName(char *svcName[], const enumVccbPod_type podType, const int unitIdx,  struct VccbEnvInfo_type::VccbEnvPodInfo_s& podInfo);
int FnVCCB_SetAllPodsSvcName(struct VccbEnvInfo_type::VccbEnvPodInfo_s& podInfo, const char (&podNamePrefix)[VCCB_MAX_CNF_PREFIX_LEN + 1], const uint16_t unitId);
enumVccbPodDeploymentKind_type FnVCCB_GetPodDeploymentKind(const enumVccbPod_type potType);
enumVccbPod_type FnVCCB_GetBlockPodType(const int blockType);
const char *FnVCCB_GetPodTypeStr(enumVccbPod_type podType);
int FnVCCB_GetTerminationCallReleaseWaitSeconds(uint16_t &terminationCallReleaseWaitSeconds);
#endif //__CNF__

void FnVCCB_HandleNrCallMsgDelayStart(msgCallSetupReq_type *ptMsg, uint8_t threadId, uint16_t msgId);
void FnVCCB_HandleNrCallMsgDelayEnd(callInfo_type *ptCi, SctpDataTransfer_type *ptMsg, uint16_t msg_Id, uint32_t &length);

int16_t FnVCCB_HandleAfterExistingCallRelWaitTimer(void);
int16_t FnVCCB_EmergencyCallCheckForCnfUpgrade(void);
void FnVCCB_SetPodLabel(const char *func, const char *key, const char *value);
void FnVCCB_ReleaseEveryCallAndWaitForTerminating();
void FnVCCB_SetCnfAllCallRelWaitTimerValue(int timerValue);

const char *FnVCCB_GetBearerTypeStr(enumBearerType bearerType);
bool FnVCCB_IsAoAPeriodicitySame(callInfo_type *ptCi);
void FnVCCB_InitUeSliceMBRList(ueSliceMbrList_type (&ueSliceMbrList)[MAX_NR_OF_SLICE_MBR]);
bool FnVCCB_IsSameSNSSAI(const callSNSSAI_type &s1, const callSNSSAI_type &s2);
bandNrUeCapa_type *FnVCCB_GetBandNrUeCapa(callInfo_type *ptCi, uint16_t bandNr);

#ifdef IPC_TEST
bool FnVCCB_IsUeTypeSupportSvcGrpCfg(bool isRedcapUe, uint8_t ueType);
#endif

void FnVCCB_InitGnbSliceStatCounterList(int gnbNum);

uint32_t calcIncreasedCount(uint32_t prevCount, uint32_t curCount);
int16_t FnVCCB_CheckAbnormalCallReleaseForCallDropRatioHigh(uint16_t callFaultCause);
void FnVCCB_GetCallReleaseCountForCallDropRatioHigh(uint32_t &callReleaseCount, uint32_t &abnormalCallReleaseCount);

void FnVCCB_SetEmergencyCallInCslWithEstCause(callInfo_type &rCall);
void FnVCCB_SetVonrAndEmergencyCallInCslWithQosFlow(callInfo_type &rCall, uint8_t priorityLevel, uint8_t fiveQi);
void FnVCCB_SetVonrAndEmergencyCallForCsl(callInfo_type &rCall); 

uint64_t FnVCCB_TacAndSvnAsBcdImeisv(uint32_t tac, uint8_t svn);
int64_t FnVCCB_FindIMEISVFeatureControlInfoEntryIndex(uint64_t maskedImeisvWithoutSnr);
std::optional<ImeisvFeatureSupport_type> FnVCCB_GetIMEISVFeatureSupportForCall(const callInfo_type& call);

template <typename IMEISVContainer>
void FnVCCB_Store_MaskedIMEISV(callInfo_type& call, const IMEISVContainer& imeisvContainer)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(imeisvContainer.length, (MASKED_IMEISV_LENGTH_MAX + 1));

    VccbMaskedIMEISV_type& callImeisv = call.ueInfo.imeisvBuf.maskedIMEISV;

    call.ueInfo.imeisvBuf.maskedIMEISVPresent = OPT_PRESENT;
    callImeisv.length = static_cast<uint16_t>(imeisvContainer.length);
    memcpy(callImeisv.value, imeisvContainer.value, MASKED_IMEISV_BUF_SIZE);
}

#endif
