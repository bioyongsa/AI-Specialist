#ifndef VCCB_CDB_ComRedisReply_H_
#define VCCB_CDB_ComRedisReply_H_

#ifdef __CNF__
#include "VccbDefine.h"


#ifdef __VALKEY__
#include "ComRedisLib.h"
#else
#include "hiredis.h"
#endif

class VccbRedisReply
{
private:
    redisReply* pReply;

public:
    VccbRedisReply();
    ~VccbRedisReply();
    redisReply* getReply();
    redisReply** getReplyDoublePointer();
    void newReply(redisReply *reply);
};
#endif

#endif  // VCCB_CDB_ComRedisReply_H_
