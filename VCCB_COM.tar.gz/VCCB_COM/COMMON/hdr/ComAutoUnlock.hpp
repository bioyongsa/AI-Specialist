/**
 * @file     : ComAutoUnlock.hpp
 * @brief    : header of
 *
 * @author   : i9859.park@samsung.com
 * @date     : 2019/09/19
 *
 * Copyright 2019 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef VCCB_COM_ComAutoUnlock_HPP_
#define VCCB_COM_ComAutoUnlock_HPP_

/**
 * @class        ComAutoUnlock
 * @brief        auto unlock process
 *
 * RAII wrapper for pthread lock and unlock macros.
 *
 * @remark
 *
 * @see
 *
 * Copyright 2019 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#include <pthread.h>

class ComAutoUnlock
{
private:
    pthread_mutex_t *mutex;

public:
    ComAutoUnlock(pthread_mutex_t *_mutex);
    ~ComAutoUnlock();
};

#endif /* VCCB_COM_ComAutoUnlock_HPP_ */