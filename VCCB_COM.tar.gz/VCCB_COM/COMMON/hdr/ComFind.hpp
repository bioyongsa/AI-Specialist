/**
 * @file     : ComFind.hpp
 * @brief    : header of utility finding functions
 *
 * @author   : k.laskowski2@partner.samsung.com
 * @date     : 2020/10/07
 *
 * Copyright 2020 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef VCCB_COM_ComFind_HPP_
#define VCCB_COM_ComFind_HPP_

#include <algorithm>
#include <iterator>
#include <utility>

namespace util
{
constexpr std::nullptr_t NOT_FOUND = nullptr;
constexpr int NOT_FOUND_IDX = -1;

/****************************************************************************
 * @brief           Returns the first element from range [array[0], array[limit])
 *                  for which predicate returns true.
 *
 * @param           array : array of N ElementType
 * @param           limit : range end
 * @param           predicate : unary predicate which returns ​true for the required element
 *
 * @return          pointer to the found element. If an element is not found NOT_FOUND is returned.
 *
 * @remark          if limit parameter is greater than N (array size) then it is clamped to N to prevent
 *                  undefined behavior caused by accessing possibly not allocated memory.
 *                  User is responsible for detecting it.
 ****************************************************************************/
template <typename ElementType, std::size_t N, typename Predicate>
ElementType* findObjectIfExist(ElementType (&array)[N], std::size_t limit, Predicate&& predicate)
{
    if (limit > N)
    {
        limit = N;
    }

    auto begin = array;
    auto end = array + limit;
    auto result = std::find_if(begin, end, std::forward<Predicate>(predicate));
    if (result == end)
    {
        return NOT_FOUND;
    }
    return result;
}

/****************************************************************************
 * @brief           Returns the first element from range [array[0], array[N])
 *                  for which predicate return true.
 *
 * @param           array : array of N ElementType
 * @param           predicate : unary predicate which returns ​true for the required element
 *
 * @return          pointer to the found element. If an element is not found NOT_FOUND is returned.
 ****************************************************************************/
template <typename ElementType, std::size_t N, typename Predicate>
ElementType* findObjectIfExist(ElementType (&array)[N], Predicate&& predicate)
{
    return findObjectIfExist(array, N, std::forward<Predicate>(predicate));
}

/****************************************************************************
 * @brief           Returns the index of the first element from range
 *                  [array[0], array[limit]) for which predicate returns true.
 *
 * @param           array : array of N ElementType
 * @param           limit : range end
 * @param           predicate : unary predicate which returns ​true for the required element
 *
 * @return          index of the found element. If an element is not found NOT_FOUND_IDX is returned.
 *
 * @remark          if limit parameter is greater than N (array size) then it is clamped to N to prevent
 *                  undefined behavior caused by accessing possibly not allocated memory.
 *                  User is responsible for detecting it.
 ****************************************************************************/
template <typename ElementType, std::size_t N, typename Predicate>
int findObjectIdxIfExist(ElementType (&array)[N], std::size_t limit, Predicate&& predicate)
{
    auto result = findObjectIfExist(array, limit, std::forward<Predicate>(predicate));
    if (result == NOT_FOUND)
    {
        return NOT_FOUND_IDX;
    }
    return (int)std::distance(std::begin(array), result);
}

/****************************************************************************
 * @brief           Returns the index of the first element from range
 *                  [array[0], array[N]) for which predicate returns true.
 *
 * @param           array : array of N ElementType
 * @param           predicate : unary predicate which returns ​true for the required element
 *
 * @return          index of the found element. If an element is not found NOT_FOUND_IDX is returned.
 ****************************************************************************/
template <typename ElementType, std::size_t N, typename Predicate>
int findObjectIdxIfExist(ElementType (&array)[N], Predicate&& predicate)
{
    return findObjectIdxIfExist(array, N, std::forward<Predicate>(predicate));
}

}  // namespace util

#endif /* VCCB_COM_ComFind_HPP_ */
