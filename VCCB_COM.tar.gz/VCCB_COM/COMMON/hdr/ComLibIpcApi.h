/****************************************************************
 * System      : 5G vNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : VlibIpcApi.h
 * Description :
 * Author      :
 * Dept.       : NG Access Lab.
 * Created     : 2016.08.01
 * Procedures defined :
 * Procedures called  :
 * Version     :
 * Revision history   :
 *          date      :
 *       revised by   :
 * revised information:
 ****************************************************************/

#ifndef VCCB_COM_ComLibIpcApi_H_
#define VCCB_COM_ComLibIpcApi_H_

/*----------------------------------------------------------------------------
 * Define    :    Include Header Files
 * ---------------------------------------------------------------------------
 */
/* External */
/* Internal */
#include "VccbStruct.h"
#include "ComLogUtility.hpp"
#include "ComEg.h"
#include "ComInline.h"
#include "ComPrint.h"

/*----------------------------------------------------------------------------
 * Define    :    Function ProtoType
 * ---------------------------------------------------------------------------
 */

int FnVCCB_IsActivePod(const int podType, const int podId);
int32_t FnVCCB_GetActivePodId(uint16_t podType);
int FnVCCB_GetVnmbIpAndPort(const int unitId);
int FnVCCB_GetVnlbIpAndPort(const int unitId);
int FnVCCB_UpdateVnmbIpAndPortForCNF(const int unitId);
int FnVCCB_UpdateVnlbIpAndPortForCNF(const int unitId);
int FnVCCB_UpdateOsabIpAndPortForCNF(const int unitId);
int FnVCCB_UpdateVtmbIpAndPortForCNF(const int unitId);
int FnVCCB_GetVcsbIpAndPort(const int unitId);
int FnVCCB_GetVtmbIpAndPort(const int unitId);
int FnVCCB_GetOsabIpAndPort(const int unitId);
int FnVCCB_GetVclbIpAndPort(void);
int FnVCCB_GetNanoHandle();
int FnVCCB_GetVccbNanoHandle(void);
int FnVCCB_GetVcsbNanoHandle(const int unitId);
int FnVCCB_GetVtmbNanoHandle(const int unitId);
int FnVCCB_GetVclbNanoHandle(void);
void FnVCCB_CleanupVtmbConnections(const int unitId);

int VLIB_getMdsIp(pMdsIp_Type pMdsIp, const int blockType, const int unitId);
int FnVCCB_GetKasIp(MdsIp_Type &rMdsIp, const char *const svcName, const enumVccbPodDeploymentKind_type podDeploymentKind);
int FnVCCB_GetIpAndPort(void);
int FnVCCB_ConvertMdsIptoChar(MdsIp_Type mdsIp, char *convIp);
void FnVCCB_SetTrafficManagementDSCP(void);
void FnVCCB_SetTrafficManagementDSCPNano(const int unitId);
int16_t VLIB_SendMsg(int txHandle, MdsAddr_Type *destAddr, char *myMsg, uint32_t len, const int isNanoSupport);
int16_t VLIB_SendBigIpcMsg(int txHandle, MdsAddr_Type *destAddr, char *myMsg, uint32_t len);
int16_t FnVCCB_SendMessageToInternalTaskWithBigMsg(
    const uint32_t msgId, const uint8_t callThreadId, char *pMsg, const uint32_t length);
int VLIB_GetExtIpAndPort(void);

#endif
