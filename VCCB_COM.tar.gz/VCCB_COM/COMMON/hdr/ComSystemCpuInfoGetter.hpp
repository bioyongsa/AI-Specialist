/**
 * @file         : ComSystemCpuInfoGetter.hpp
 * @brief       : header of system monitor
 *
 * @author    : hohyun.kang@samsung.com
 * @date       : 2018/12/06
 *
 * Copyright 2018 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef VCCB_COM_ComSystemCpuInfoGetter_HPP_
#define VCCB_COM_ComSystemCpuInfoGetter_HPP_

/**
 * @class    ComSystemCpuInfoGetter
 * @brief    has a function to
 *
 * @remark
 *
 * @see
 *
 * Copyright 2018 by Samsung Electronics, Inc.,
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
#include <map>
#include "ComSystemMonitor.hpp"

enum class cpuId
{
    CPU_ALL_AVERAGE = -1,
    CPU_0 = 0,
    CPU_1,
    CPU_2,
    CPU_3,
    CPU_4,
    CPU_5,
    CPU_6,
    CPU_7,
    CPU_8,
    CPU_9,
    CPU_10,
    CPU_11,
    CPU_12,
    CPU_13,
    CPU_14,
    CPU_15,
    CPU_16,
    CPU_17,
    CPU_18,
    CPU_19,
    CPU_20,
};

class ComSystemCpuInfoGetter
{
    friend class ComSystemMonitor;

public:
    explicit ComSystemCpuInfoGetter(void);
    virtual ~ComSystemCpuInfoGetter(void);

protected:
    int t_getMaxCpuNum(void);
    // int t_getCpuLoad200ms(const cpuId id);
    int t_getCpuLoad3sec(const cpuId id);
    // int t_getCpuLoad5min(const cpuId id);
    // int t_getCpuLoadOneDemand(const cpuId id, const int periodSec);
    // int t_getCpuLoadAllPeriodSupported(const cpuId id);
    bool t_getCpuId(const int id, cpuId& rCpuId);

private:
    typedef std::map<const int, cpuId> CPUID_MAP;
    ComSystemCpuInfoGetter(const ComSystemCpuInfoGetter&);
    ComSystemCpuInfoGetter& operator=(const ComSystemCpuInfoGetter&);

    void m_initializeCpuIdMap(void);
    bool m_isCpuIdExisted(const int id);
    // bool m_checkAvailablePeriod(const int periodSec);
    int m_maxCpuNum;
    CPUID_MAP m_cpuIdMap;
};

#endif /* VCCB_COM_ComSystemCpuInfoGetter_HPP_ */