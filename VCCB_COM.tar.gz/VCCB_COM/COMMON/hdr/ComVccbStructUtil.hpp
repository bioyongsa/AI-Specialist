/**
 * @file     : ComVccbStructUtil.hpp
 * @brief    : header of utility functions for VccbStruct
 *
 * @author   : k.laskowski2@samsung.com
 * @date     : 2023/06/30
 *
 * Copyright 2023 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef VCCB_COM_VccbStructUtil_HPP_
#define VCCB_COM_VccbStructUtil_HPP_

#include "cp_def.h"
#include "ComInclude.h"
#include <algorithm>

template <typename T, unsigned N>
inline size_t VCCB_CountUsedElements(T (&arr)[N])
{
    return static_cast<size_t>(std::count_if(std::begin(arr), std::end(arr), 
                                             [](const T &item) { return CI_use == item.usage; }));
}

template <typename T, unsigned N>
inline bool VCCB_NoneElementUsed(T (&arr)[N])
{
    return std::none_of(std::begin(arr), std::end(arr), [](const T &item) { return CI_use == item.usage; });
}

/*
 * CellInfoIterator iterates from given ptr to CELLINFO[MAX_CELL_NUM_VCCB].
 * If ptr is past CELLINFO[MAX_CELL_NUM_VCCB] or before CELLINFO[0], iteration defaults to 0..MAX_CELL_NUM_VCCB
 *
 * Range based for loop users are advised to always use references or const references to avoid risk of copying. 
 * i.e. for (auto &cell: CELLINFO) or for (auto const &cell: CELLINFO)
 */
class CellInfoIterator
{
    public:
        using iterator_category = std::bidirectional_iterator_tag;
        using difference_type = std::ptrdiff_t;
        using value_type = VccbCellInfo_type;
        using pointer = VccbCellInfo_type*;
        using reference = VccbCellInfo_type&;

        CellInfoIterator(pointer ptr) : m_ptr(ptr) {}

        reference operator*() const { return *m_ptr; }
        pointer operator->() { return m_ptr; }
        CellInfoIterator& operator++() { m_ptr++; return *this; }
        CellInfoIterator operator++(int) { CellInfoIterator tmp = *this; ++(*this); return tmp; }
        CellInfoIterator& operator--() { m_ptr--; return *this; };
        CellInfoIterator operator--(int) { CellInfoIterator tmp = *this; --(*this); return tmp; }
        bool operator==(const CellInfoIterator& rhs) { return this->m_ptr == rhs.m_ptr; }
        bool operator!=(const CellInfoIterator& rhs) { return this->m_ptr != rhs.m_ptr; }
        bool operator<(const CellInfoIterator& rhs) { return this->m_ptr < rhs.m_ptr; }

    private:
        pointer m_ptr;
};

inline CellInfoIterator begin(VccbCellInfo_type *& ptr)
{ 
    VccbCellInfo_type * cellInfoPtr = CELLINFO;
    if (ptr >= (cellInfoPtr + MAX_CELL_NUM_VCCB) || ptr < cellInfoPtr)
    {
        return CellInfoIterator(&cellInfoPtr[0]);
    }
    return CellInfoIterator(ptr);
}
inline CellInfoIterator end(VccbCellInfo_type *&) { return CellInfoIterator(&CELLINFO[MAX_CELL_NUM_VCCB]); }
inline CellInfoIterator const cbegin(VccbCellInfo_type *& ptr)
{
    VccbCellInfo_type * cellInfoPtr = CELLINFO;
    if (ptr >= (cellInfoPtr + MAX_CELL_NUM_VCCB) || ptr < cellInfoPtr)
    {
        return CellInfoIterator(&cellInfoPtr[0]);
    }
    return CellInfoIterator(ptr);
}
inline CellInfoIterator const cend(VccbCellInfo_type *&) { return CellInfoIterator(&CELLINFO[MAX_CELL_NUM_VCCB]); }

#endif /* VCCB_COM_ComUtil_HPP_ */
