#ifndef VCCB_COM_ComPrint_H_
#define VCCB_COM_ComPrint_H_

#include "ComInclude.min.h"

void FnVCCB_UeBasedPrint(const callInfo_type *, const char *, const int, const int, const int, const char *, ...);
void FnVCCB_UeBasedPrintWithDebug(const callInfo_type *, const char *, const char *, const int, const int, const bool, const char *, ...);
void FnVCCB_UeBasedPrintWithMscGen(const VccbDbgLog_type &dbgLog, const callInfo_type *ptCi, const int level, const char *fmt, ...);
void iPRINTF(const callInfo_type *, const int, const char *, ...);
void FnVCCB_NonUeBasedPrint(const char *, const int, const int, const char *, ...);
void iPRINTNF(const int, const char *, ...);
void iPRINTNH(const char *, ...);
int FnVCCB_AsnPrint(const char *, ...);
void FnVCCB_BufferPrint(char *pLogBuf, int LogBufMaxSize, int *pLogBufUseSize, const char *fmt, ...);
void FnVCCB_UeHistoryHandlingPrint(callInfo_type *ptCi, const char *fmt, ...);

#endif