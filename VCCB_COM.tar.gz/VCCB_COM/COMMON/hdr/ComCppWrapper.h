/**
 * @file     : ComCppWrapper.h
 * @brief        : header of
 *
 * @author   : hohyun.kang@samsung.com
 * @date     : 2018/12/06
 *
 * Copyright 2018 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef VCCB_COM_ComCppWrapper_H_
#define VCCB_COM_ComCppWrapper_H_

#include "VccbStruct.h"

int getMaxCpuNum(void);
int getCpuLoad3sec(const int cpuId);

void pushNbrReadQue(unsigned short value);
void popNbrReadQue(unsigned short *value);
int emptyNbrReadQue();

// get Enb
void SetNbrEnbCellInfoForInit(nbrEnbCellInfo_type *pNbrEnbCell);
nbrEnbCellInfo_type *getNbrEnbCell(uint16_t gnbNum, cgi_type cgi);
nbrEnbCellInfo_type *setNbrEnbCell(uint16_t gnbNum, cgi_type cgi);

int16_t getNbrEnbCellByCellNbrIdx(uint16_t cellNum, uint16_t nbrIdx, nbrEnbCellInfo_type **ppNbr);
void deleteNbrEnbCell(uint16_t gnbNum, cgi_type cgi);
void deleteNbrEnbCellByEnbId(uint16_t gnbNum, uint32_t nbrEnbId, plmnId_type plmn);
void clearNbrEnbCell(uint16_t gnbNum);

// get Gnb
void SetNbrGnbCellInfoForInit(nbrGnbCellInfo_type *pNbrGnbCell);
nbrGnbCellInfo_type *getNbrGnbCell(uint16_t gnbNum, VccbGnbInfo_type *pGnb, cgi_type cgi);
int16_t getNbrGnbCellByCellNbrIdx(uint16_t cellNum, uint16_t nbrIdx, nbrGnbCellInfo_type **ppNbr);
nbrGnbCellInfo_type *getNbrGnbCellByNbrIdx(const VccbCellInfo_type &cell, uint16_t nbrIdx);
int16_t getIntraGnbNbrDataByNrPciAndArfcn(uint16_t cellNum, const uint16_t nrPci, uint32_t ssbArfcn, uint16_t *pNbrIdx, nbrGnbCellInfo_type **ppNbr);
nbrGnbCellInfo_type *setNbrGnbCell(uint16_t gnbNum, cgi_type cgi);
void deleteNbrGnbCell(uint16_t gnbNum, cgi_type cgi);
void deleteNbrGnbCellByGnbId(uint16_t gnbNum, vccbGlobalGnbId_type nbrGnbId);
void clearNbrGnbCell(uint16_t gnbNum);

nbrGnbCellInfo_type *getNbrGnbCellByCgiInCellNbr(uint16_t cellNum, cgi_type targetCellIdentity);

void getNbrGnbCellNum(uint16_t gnbNum, uint32_t *num);  // NBR_AUDIT_22B
void getNbrEnbCellNum(uint16_t gnbNum, uint32_t *num);  // NBR_AUDIT_22B

#endif /* VCCB_COM_ComCppWrapper_H_ */
