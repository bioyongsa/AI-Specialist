#ifndef VCCB_COM_CoreAffinity_H_
#define VCCB_COM_CoreAffinity_H_

#include "ComInclude.min.h"
#include "ComPrint.h"
#include "ComMacro.h"
#include "ComGlobalData.h"
#include "ComEg.h"
#include "HasInterface.h"

namespace ComCoreAffinity
{

// Helper function
uint8_t GetIrqCoreCount(void);

// Initial configuration
#if defined(__VNF__) && !defined(NEW_HOST_SIM)
void InitHasAffinity(void);
#endif
void InitCallThreadAffinityForNVGNB(uint8_t myThreadId);
void InitWorkerThreadAffinityForVNF(enumVccbTaskAffinity_type affinityType);

}

#endif // VCCB_COM_CoreAffinity_H_