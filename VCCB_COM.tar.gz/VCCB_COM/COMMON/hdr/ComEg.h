#ifndef VCCB_COM_ComEg_H_
#define VCCB_COM_ComEg_H_

#include <stdint.h>

int getEgInfo(int32_t argc, char *argv[]);
int setEgInfo(int32_t argc, char *argv[]);
void utilEGput_(int32_t level, const char *event, const char *File, int32_t Line);

#ifdef IPC_TEST
#define utilEGput(level, event, fileName, line)
#define VCCB_EG_PUT(_level, _failStr)
#else
#define utilEGput(level, event, fileName, line) (GetgEgFlag()) ? utilEGput_(level, event, fileName, line) : (void)0
#define VCCB_EG_PUT(_level, _failStr)           utilEGput(_level, _failStr, __FILENAME__, __LINE__)
#endif

#endif /* VCCB_COM_ComEg_H_ */
