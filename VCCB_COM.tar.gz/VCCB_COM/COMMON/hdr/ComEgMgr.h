#ifndef VCCB_COM_ComEgMgr_H_
#define VCCB_COM_ComEgMgr_H_

#include <string>
#include <map>
#include <mutex>
#include <sys/time.h>

#define EG_POOL_CNT  64
#define EG_MAX_LEVEL 2

class ComEgMgr
{
public:
    static ComEgMgr* instance();

    void gather(const char* egEvent, const char* location, int32_t egLevel);
    void clear();
    // std::string displayCmdOut(int32_t inLevel);
    void setEgFlag(bool newFlag);
    void setEgLevel(int32_t newLevel);
    void displayEgInfo();
    void displayEglog(int32_t inLevel);
    std::string makeTimeValStr(const struct timeval& timeVal);

private:
    ComEgMgr();
    ~ComEgMgr();
    static ComEgMgr* instance_;
    static std::mutex newLock_;

    struct EGInfo_t
    {
        uint64_t count;
        std::string causeStr;
    };
    typedef std::map<std::string, EGInfo_t> StlMapEgCount;

    struct timeval startTime_;

    std::mutex egMutex_[EG_POOL_CNT];
    StlMapEgCount egLevelMap_[EG_POOL_CNT][EG_MAX_LEVEL + 1];
};
#endif
