#pragma once

#include "ComContainers.hpp"
#include "VccbStruct.h"
#include <string>

class MeasReportPrinter
{
public:
    static constexpr int MAX_LINE_LEN = 256;
    static constexpr int MR_LINES_LEN = 25;  // maximal measurement report requires this amount of lines

    using Line = char[MeasReportPrinter::MAX_LINE_LEN];
    using Lines = simpleVector<Line, MeasReportPrinter::MR_LINES_LEN>;

    MeasReportPrinter(const callInfo_type& rCi, const measResultList2NR_type& measResultList2NR,
        const measResultNeighCellsEUTRA_type& measResultList2EUTRA);

    ~MeasReportPrinter();

    void formatMeasResultList(const measurementObjectUe_type& selectMeasObj);
    void formatHeader(const measurementIdentity_type& selectMeasIdx, const measurementObjectUe_type& selectMeasObj,
        const reportConfigurationInstalledUe_type& selectRptCfg);

    const Lines getLines() const { return lines; };

private:
    struct CellMeasResult
    {
        std::optional<uint16_t> pci;
        std::optional<uint16_t> rsrp;
        std::optional<uint16_t> rsrq;
        std::optional<uint16_t> sinr;

        std::optional<uint32_t> ssbArfcn;

        enum class MeasReportType
        {
            NR,
            EUTRA
        };
        MeasReportType mrType;
    };

    struct ServingCellMeasResult
    {
        bool isPcell;

        uint16_t servCellId;

        CellMeasResult servingCell;
        std::optional<CellMeasResult> bestNeighbor;
    };

    using ServingCellResults = simpleVector<ServingCellMeasResult, MAX_NR_OF_SERVING_CELLS>;
    using NbrCellResults = simpleVector<CellMeasResult, MAX_NUM_CELL_REPORT>;

    void getMeasResultServingCell();
    void getMeasResultNbrCell(const measurementObjectUe_type& selectMeasObj);
    void getMeasResultEutraNbrCell();
    void printMeasResultServingCell();
    void printNbrCell(const NbrCellResults& results);
    void printHeaders();
    CellMeasResult getMeasQuantityResultNR(const measResultNR_type& rRes) const;
    CellMeasResult getMeasQuantityResultEutra(const measResultEUTRA_type& rRes) const;

    const callInfo_type& rCi;
    const measResultList2NR_type& measResultList2NR;
    const measResultNeighCellsEUTRA_type& measResultList2EUTRA;
    ServingCellResults sCResults;
    NbrCellResults nbrResults;
    NbrCellResults nbrResultsEutra;
    Lines lines;
};