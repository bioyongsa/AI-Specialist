/****************************************************************
 * System      : 5G vNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : ComMacro.h
 * Description :
 * Author      :
 * Dept.       : NW Access Lab.
 * Created     : 2016.08.01
 * Procedures defined :
 * Procedures called  :
 * Version     :
 * Revision history   :
 *          date      :
 *       revised by   :
 * revised information:
 ****************************************************************/

#ifndef VCCB_ComMacro_H_
#define VCCB_ComMacro_H_

#include "VccbMacro.h"

/*
   In c++(Modern C++17), add [[nodiscard]] attribute to the function that require return check.
   If return check is not performed in the caller that use the function, compile warning is occurred to improve it.
   In c(from gcc4.5), adding __attribute__((warn_unused_result)) attribute has the same effect.
   Although  __attribute__((warn_unused_result)) is available for both .c and .cpp,
   it is recommended [[nodiscard]] be used for .cpp and __attribute__((warn_unused_result)) be used for .c
   */
#define WARN_UNUSED __attribute__((warn_unused_result))
/*
   usage> int WARN_UNUSED myFunc(int a);
   */
#define WARN_UNUSED_CPLUS [[nodiscard]]
/*
   usage> WARN_UNUSED_CPLUS int myFunc(int a);
   */

/**
 * @brief   MACRO for Gtest
 */
#if defined(IPC_TEST)
#define VCCB_STATIC
#define VCCB_INLINE
#else
#define VCCB_STATIC static
#define VCCB_INLINE inline
#endif

#define IS_TRACE_LOG_ACTIVE (DBG->flag.logTraceCsl)

#define VCCB_STATIC_INLINE VCCB_STATIC VCCB_INLINE

//************************** USE THESE MACROs *********************************
// Function verifying number and type of varargs at compilation time.
void check_args(const char *format, ...) __attribute__((format(printf, 1, 2)));

#if defined(IPC_TEST) || defined(HOST_SIM_COV_TEST)
/* skip to check the print argument for ipc test or HOSTSIM coverage test*/
#define VCCB_CHECK_ARGS(__fmt, __args...)

#ifdef __CALL_GRIND__
#define VCCB_PRINT_COMMON_1(__level, __eg_level, __fmt, __args...) \
    if (0) check_args(__fmt, ##__args)

#define VCCB_PRINT_COMMON_2(__level, __fmt, __args...) \
    if (0) check_args(__fmt, ##__args)

#define VCCB_PRINT_COMMON_3(__level, __fmt, __args...) \
    if (0) check_args(__fmt, ##__args)

#else

// Print :: This output is for the entire system. (No CALL)
#define VCCB_PRINT_COMMON_1(__level, __eg_level, __fmt, __args...) VCCB_PRINT_COMMON_3(__level, __fmt, ##__args)

#define VCCB_PRINT_COMMON_2(__level, __fmt, __args...) VCCB_PRINT_COMMON_3(__level, __fmt, ##__args)

#define VCCB_PRINT_COMMON_3(__level, __fmt, __args...)                                 \
    do                                                                                 \
    {                                                                                  \
        VCCB_CHECK_ARGS(__fmt, ##__args);                                              \
        if (DBG->flag.fdebug_msg)                                                      \
        {                                                                              \
            FnVCCB_NonUeBasedPrint(__FILE__, __LINE__, __level, __fmt, ##__args);      \
        }                                                                              \
    } while (0)

#endif

#else
#define VCCB_CHECK_ARGS(__fmt, __args...) \
    if (0) check_args(__fmt, ##__args)

// Print :: This output is for the entire system. (No CALL)
#define VCCB_PRINT_COMMON_1(__level, __eg_level, __fmt, __args...)                                                     \
    do                                                                                                                 \
    {                                                                                                                  \
        VCCB_CHECK_ARGS(__fmt, ##__args);                                                                              \
        if ((DBG->flag.fdebug_msg) && ((__level <= DBG->localLevel) || (!(DBG->log.logStoreDebugTrace) &&              \
                                                                           (__level <= DBG->log.logStoreDebugLevel)))) \
        {                                                                                                              \
            FnVCCB_NonUeBasedPrint(__FILE__, __LINE__, __level, __fmt, ##__args);                                      \
        }                                                                                                              \
        VCCB_EG_PUT(__eg_level, __FUNCTION__);                                                                         \
    } while (0)

#define VCCB_PRINT_COMMON_2(__level, __fmt, __args...)                                                                 \
    do                                                                                                                 \
    {                                                                                                                  \
        VCCB_CHECK_ARGS(__fmt, ##__args);                                                                              \
        if ((DBG->flag.fdebug_msg) && ((__level <= DBG->localLevel) || (!(DBG->log.logStoreDebugTrace) &&              \
                                                                           (__level <= DBG->log.logStoreDebugLevel)))) \
        {                                                                                                              \
            FnVCCB_NonUeBasedPrint(__FILE__, __LINE__, __level, __fmt, ##__args);                                      \
        }                                                                                                              \
    } while (0)

#define VCCB_PRINT_COMMON_3(__level, __fmt, __args...)                                 \
    do                                                                                 \
    {                                                                                  \
        VCCB_CHECK_ARGS(__fmt, ##__args);                                              \
        if (DBG->flag.fdebug_msg)                                                      \
        {                                                                              \
            FnVCCB_NonUeBasedPrint(__FILE__, __LINE__, __level, __fmt, ##__args);      \
        }                                                                              \
    } while (0)

#endif

#define VCCB_PRINT_CMD(__fmt, __args...)      VCCB_PRINT_COMMON_3(PL_CMD, __fmt, ##__args)
#define VCCB_PRINT_CRITICAL(__fmt, __args...) VCCB_PRINT_COMMON_1(PL_CRITICAL, 2, __fmt, ##__args)
#define VCCB_PRINT_ERROR(__fmt, __args...)    VCCB_PRINT_COMMON_1(PL_ERROR, 1, __fmt, ##__args)
#define VCCB_PRINT_MSG(__fmt, __args...)      VCCB_PRINT_COMMON_1(PL_MSG, 0, __fmt, ##__args)
#define VCCB_PRINT_DATA(__fmt, __args...)     VCCB_PRINT_COMMON_2(PL_DATA, __fmt, ##__args)
#define VCCB_PRINT_COMMENT(__fmt, __args...)  VCCB_PRINT_COMMON_2(PL_COMMENT, __fmt, ##__args)

// Print :: The output message is mapped to a specific call and output. (CALL)
#ifdef __CALL_GRIND__
#define VCCB_PRINT_CALL_COMMON_1(__level, __eg_level, __ptCi, __crrLogging, __fmt, __args...) \
    do                                                                                        \
    {                                                                                         \
        (void)__ptCi;                                                                         \
        if (0) check_args(__fmt, ##__args);                                                   \
    } while (0)

#define VCCB_PRINT_CALL_COMMON_2(__level, __ptCi, __fmt, __args...) \
    do                                                              \
    {                                                               \
        (void)__ptCi;                                               \
        if (0) check_args(__fmt, ##__args);                         \
    } while (0)

#else

#define VCCB_PRINT_CALL_COMMON_1(__level, __eg_level, __ptCi, __crrLogging, __fmt, __args...)           \
    do                                                                                                  \
    {                                                                                                   \
        VCCB_CHECK_ARGS(__fmt, ##__args);                                                               \
        FnVCCB_UeBasedPrint(__ptCi, __FILE__, __LINE__, __level, __crrLogging, __fmt, ##__args);        \
        VCCB_EG_PUT(__eg_level, __FUNCTION__);                                                          \
    } while (0)

#define VCCB_PRINT_CALL_COMMON_2(__level, __ptCi, __fmt, __args...)                              \
    do                                                                                           \
    {                                                                                            \
        VCCB_CHECK_ARGS(__fmt, ##__args);                                                        \
        FnVCCB_UeBasedPrint(__ptCi, __FILE__, __LINE__, __level, FALSE, __fmt, ##__args);        \
    } while (0)

#endif

#define VCCB_PRINT_CALL_INFORMATIVE(__ptCi, __fmt, __args...) \
    VCCB_PRINT_CALL_COMMON_1(PL_CMD, 2, __ptCi, FALSE, __fmt, ##__args)
#define VCCB_PRINT_CALL_CRITICAL(__ptCi, __fmt, __args...) \
    VCCB_PRINT_CALL_COMMON_1(PL_CRITICAL, 2, __ptCi, FALSE, __fmt, ##__args)
#define VCCB_PRINT_CALL_ERROR(__ptCi, __fmt, __args...) \
    VCCB_PRINT_CALL_COMMON_1(PL_ERROR, 1, __ptCi, FALSE, __fmt, ##__args)
#define VCCB_PRINT_CALL_MSG(__ptCi, __fmt, __args...) \
    VCCB_PRINT_CALL_COMMON_1(PL_MSG, 0, __ptCi, FALSE, __fmt, ##__args)
#define VCCB_PRINT_CALL_DATA(__ptCi, __fmt, __args...)    VCCB_PRINT_CALL_COMMON_2(PL_DATA, __ptCi, __fmt, ##__args)
#define VCCB_PRINT_CALL_COMMENT(__ptCi, __fmt, __args...) VCCB_PRINT_CALL_COMMON_2(PL_COMMENT, __ptCi, __fmt, ##__args)
#define VCCB_PRINT_CALL_CRR(__ptCi, __fmt, __args...) \
    VCCB_PRINT_CALL_COMMON_1(PL_ERROR, 1, __ptCi, TRUE, __fmt, ##__args)

// Print :: It only outputs the result of the function. (CALL)
#define VCCB_PRINT_ON_CAL_COMMON(retError, __ptCi, __resultOfFunc, __msg, __args...) \
    do                                                                               \
    {                                                                                \
        if (retError == __resultOfFunc)                                              \
        {                                                                            \
            VCCB_PRINT_CALL_ERROR((__ptCi), __msg, ##__args);                        \
        }                                                                            \
    } while (0)

// SAM_CC_IMPROVEMENT_23B
#define VCCB_PRINT_WITHOUT_RETURN_ON_CALL_ERROR(__ptCi, __resultOfFunc, __msg, __args...) \
    VCCB_PRINT_ON_CAL_COMMON(ERROR, __ptCi, __resultOfFunc, __msg, ##__args)
#define VCCB_PRINT_WITHOUT_RETURN_ON_CALL_BREAK(__ptCi, __resultOfFunc, __msg, __args...) \
    VCCB_PRINT_ON_CAL_COMMON(BREAK, __ptCi, __resultOfFunc, __msg, ##__args)

// Print :: In case of IMSI TRACE or DEBUG FLAG, it is controlled so that high output can be achieved. (CALL)
#ifdef __CALL_GRIND__
#define VCCB_PRINT_CALL_WITH_DEBUG_TRACE_COMMON(__flag, __ptCi, __fmt, __args...)                          \
    if (0) check_args(__fmt, ##__args)
#else
#define VCCB_PRINT_CALL_WITH_DEBUG_TRACE_COMMON(__flag, __ptCi, __fmt, __args...)                          \
    do                                                                                                     \
    {                                                                                                      \
        VCCB_CHECK_ARGS(__fmt, ##__args);                                                                  \
        FnVCCB_UeBasedPrintWithDebug(__ptCi, __FUNCTION__, __FILE__, __LINE__, PL_COMMENT, (__flag), __fmt, ##__args); \
    } while (0)
#endif

#define VCCB_PRINT_CALL_TGT_SEL(__ptCi, __fmt, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_TRACE_COMMON(DBG->flag.logHoTargetSelection, __ptCi, __fmt, ##__args)
#define VCCB_PRINT_CALL_LOG_MRDC(__ptCi, __fmt, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_TRACE_COMMON(DBG->flag.logMrdcAddition, __ptCi, __fmt, ##__args)
#define VCCB_PRINT_CALL_SA_ON_DEMAND_HO(__ptCi, __fmt, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_TRACE_COMMON(DBG->flag.logOnDemandHO, __ptCi, __fmt, ##__args)
#define VCCB_PRINT_CALL_HO_OVERLOADED_TGT_GNB(__ptCi, __fmt, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_TRACE_COMMON(DBG->flag.logHoOverloadedTgtGnbMgmt, __ptCi, __fmt, ##__args)
#define VCCB_PRINT_CALL_LOG_PLMN(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_TRACE_COMMON(DBG->flag.logPlmn, __ptCi, ##__args)
#define VCCB_PRINT_CALL_LOG_UPM(__ptCi, __fmt, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_TRACE_COMMON(DBG->flag.logUpm, __ptCi, __fmt, ##__args)
#define VCCB_PRINT_CALL_NON_NBR_HO(__ptCi, __fmt, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_TRACE_COMMON(DBG->flag.nonNbrHo, __ptCi, __fmt, ##__args)
#define VCCB_PRINT_CALL_NRDC_BASIC(__ptCi, __fmt, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_TRACE_COMMON(DBG->flag.logNrdcBasic, __ptCi, __fmt, ##__args)
#define VCCB_PRINT_CALL_IDLE_LB(__ptCi, __fmt, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_TRACE_COMMON(DBG->flag.logIdleLB, __ptCi, __fmt, ##__args)
#define VCCB_PRINT_LOG_CA_FUNC_TRACE(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_TRACE_COMMON(DBG->flag.logCa, __ptCi, ##__args)
#define VCCB_PRINT_CALL_HO_SERVICE_TYPE(__ptCi, __fmt, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_TRACE_COMMON(DBG->flag.logHoServiceType, __ptCi, __fmt, ##__args)

// Print :: In case of DEBUG FLAG, it is controlled output can be achieved. (CALL)
#ifdef __CALL_GRIND__
#define VCCB_PRINT_CALL_WITH_DEBUG_COMMON(__flag, __ptCi, ...)                                        \
    if (0) check_args(__VA_ARGS__);
#else
#define VCCB_PRINT_CALL_WITH_DEBUG_COMMON(__flag, __ptCi, ...)                                        \
    do                                                                                                \
    {                                                                                                 \
        VCCB_CHECK_ARGS(__VA_ARGS__);                                                                 \
        FnVCCB_UeBasedPrintWithDebug(__ptCi, __FUNCTION__, __FILE__, __LINE__, INT32_MAX, (__flag), __VA_ARGS__); \
    } while (0);
#endif

#define VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logHoTargetXnSelection, __ptCi, ##__args)
#define VCCB_PRINT_CALL_SA_HO_MR_QUE_ACTION(__ptCi, __fmt, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logHoMrAction, __ptCi, __fmt, ##__args)

// Print :: In case of DEBUG FLAG, it is controlled output can be achieved. (No CALL, ERROR)
#define VCCB_PRINT_WO_CALL_WITH_DEBUG_COMMON(__flag, __fmt, __args...) \
    do                                                                 \
    {                                                                  \
        if ((__flag)) VCCB_PRINT_ERROR(__fmt, ##__args);               \
    } while (0)

#define VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION_WO_CALL(__fmt, __args...) \
    VCCB_PRINT_WO_CALL_WITH_DEBUG_COMMON(DBG->flag.logHoTargetXnSelection, __fmt, ##__args)
#define VCCB_PRINT_SA_ON_DEMAND_HO(__fmt, __args...) \
    VCCB_PRINT_WO_CALL_WITH_DEBUG_COMMON(DBG->flag.logOnDemandHO, __fmt, ##__args)
#define VCCB_PRINT_LOG_MRDC(__fmt, __args...) \
    VCCB_PRINT_WO_CALL_WITH_DEBUG_COMMON(DBG->flag.logMrdcAddition, __fmt, ##__args)
#define VCCB_PRINT_LOG_NRDC_BASIC(__fmt, __args...) \
    VCCB_PRINT_WO_CALL_WITH_DEBUG_COMMON(DBG->flag.logNrdcBasic, __fmt, ##__args)
#define VCCB_PRINT_LOG_IDLE_LB(__fmt, __args...) \
    VCCB_PRINT_WO_CALL_WITH_DEBUG_COMMON(DBG->flag.logIdleLB, __fmt, ##__args)
#define VCCB_PRINT_SA_PERIODIC_LB(__fmt, __args...) \
    VCCB_PRINT_WO_CALL_WITH_DEBUG_COMMON(DBG->flag.periodicLb, __fmt, ##__args)

// Print :: In case of DEBUG FLAG, it is controlled output can be achieved. (No CALL, COMMENT)
#define VCCB_PRINT_WO_CALL_WITH_DEBUG_COMMON_COMMENT(__flag, __args...) \
    do                                                                  \
    {                                                                   \
        if ((__flag)) VCCB_PRINT_CALL_COMMENT(##__args);                \
    } while (0)

#define VCCB_PRINT_CALL_MRO(__ptCi, __args...) \
    if (__ptCi->callType == E_CALLTYPE_SA) VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logMro, __ptCi, ##__args)

#define VCCB_PRINT_LOG_MRO_FUNC \
    if (DBG->flag.logMro) VCCB_PRINT_CALL_DATA(ptCi, "[MRO] ## %s\n", __func__)
#define VCCB_PRINT_LOG_MRO_CGI(__nameOfCgi, __cgi) \
    if (DBG->flag.logMro) VCCB_PRINT_CALL_DATA(ptCi, "[MRO] ## %s : %lu\n", __nameOfCgi, __cgi)
#define VCCB_PRINT_LOG_MRO_PCI_ARFCN(__str, __pci, __freq) \
    if (DBG->flag.logMro) VCCB_PRINT_CALL_DATA(ptCi, "[MRO] ## %s : %u %u\n", __str, __pci, __freq)

#define VCCB_PRINT_LOG_ANR(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logAnr, __ptCi, ##__args)

#define VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logTrfHo, __ptCi, ##__args)

#define VCCB_PRINT_CALL_SA_CHO(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logCho, __ptCi, ##__args)

#define VCCB_PRINT_CALL_MCO_BCBANDPERM(__ptCi, __fmt, __args...) \
    if (DBG->flag.logMcoBcBandPerm) VCCB_PRINT_CALL_DATA(__ptCi, __fmt, ##__args)

#define VCCB_PRINT_CALL_MCO_CHECKBC(__ptCi, __fmt, __args...) \
    if (DBG->flag.logMcoCheckBc) VCCB_PRINT_CALL_DATA(__ptCi, __fmt, ##__args)

#define VCCB_PRINT_CALL_HANDOVER_FAILURE(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logHandoverFailure, __ptCi, ##__args)

#define VCCB_PRINT_LOG_MRS_FUNC(__ptCi, __args...) VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logMrs, __ptCi, ##__args)

#define VCCB_PRINT_CALL_MEASUREMENTS(__ptCi, arg0, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logMeasurements, __ptCi, "[MEAS] " arg0, ##__args)

#define VCCB_PRINT_MEASUREMENTS(arg0, __args...) \
    VCCB_PRINT_WO_CALL_WITH_DEBUG_COMMON(DBG->flag.logMeasurements, "[MEAS] " arg0, ##__args)

#define VCCB_PRINT_CALL_SMTC1_MERGE_ALG(__ptCi, arg0, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logMeasurements, __ptCi, "[smtc1-merge-alg] " arg0, ##__args)

#define VCCB_PRINT_LOG_EXCLUDED_CELLS(__ptCi, arg0, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logMeasurements, __ptCi, "[mo-exclcells] " arg0, ##__args)

#define VCCB_PRINT_LOG_POWER_CLASS(__ptCi, arg0, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logMeasurements, __ptCi, "[PC] " arg0, ##__args)

#define VCCB_PRINT_LOG_USTM(__ptCi, arg0, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logUplinkStatusTriggeredMobility, __ptCi, "[USTM] " arg0, ##__args)

#define VCCB_PRINT_LOG_SA_LB(__ptCi, __args...) VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logSaLb, __ptCi, ##__args)

#define VCCB_PRINT_LOG_VONR_LB(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logVoNrLb, __ptCi, ##__args)

#define VCCB_PRINT_LOG_MCO_SCC(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logMcoScc, __ptCi, ##__args)

#define VCCB_PRINT_LOG_MCO_FUNC(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logMco, __ptCi, ##__args)

#define VCCB_PRINT_LOG_CA_FUNC(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logCa, __ptCi, ##__args)

#define VCCB_PRINT_LOG_ALLOWED_BC_MN_FILTER(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logAllowedBcMnFilter, __ptCi, ##__args)

#define VCCB_PRINT_LOG_MN_BC_RESELECTION(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logMnBcReselection, __ptCi, ##__args)

#define VCCB_PRINT_LOG_CA_TSM(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logCaTsm, __ptCi, ##__args)

// SVR23B FGR-LC0710
#define VCCB_PRINT_LOG_SLICE_LB(__ptCi, __args...) \
    if (__ptCi->callType == E_CALLTYPE_SA) VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logSliceLb, __ptCi, ##__args)

// SVR23B FGR-LC0711
#define VCCB_PRINT_LOG_IRAT_LB(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logIratLb, __ptCi, ##__args)

// SVR24A FGR-MC1022
#define VCCB_PRINT_LOG_FP_MC(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logFpMc, __ptCi, ##__args)

#define VCCB_PRINT_LOG_ROHC(__ptCi, arg0, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logRoHC, __ptCi, "[ROHC] " arg0, ##__args)

#define VCCB_PRINT_UE_SPECIFIC_REPORT_CONFIG(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logUeSpecReportCfg, __ptCi, ##__args)

#define VCCB_PRINT_LOG_EHC(__ptCi, arg0, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logEHC, __ptCi, "[EHC] " arg0, ##__args)

// SVR24B FGR-MC1007
#define VCCB_PRINT_LOG_NC_MC(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logNcMc, __ptCi, ##__args)

#define VCCB_PRINT_LOG_CA_CSL_FUNC(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logCaCsl, __ptCi, ##__args)

// FGS-SF0701 UE Measurement for SON
#define VCCB_PRINT_LOG_UMFS(__ptCi, __fmt, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logUmfs, __ptCi, "[UMfS] " __fmt, ##__args)

// SVR25B FGR-CC5500
#define VCCB_PRINT_LOG_TSM_DU_IW(__ptCi, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logTsmDuIw, __ptCi, ##__args)

//************************** USE THESE MACROs *********************************

#define VCCB_ONE_LOG_PRINT(__logClass, __logCode, __fmt, __args...)                \
    {                                                                              \
        logPrint(VCCB_BLK_NAME, PL_CRITICAL, __LINE__, __logClass, __logCode,      \
            GetgVccbLogCodeName_(__logCode % MAX_VCCB_LOG_CODE), __fmt, ##__args); \
    }

#define VCCB_EXIT(_cause)                                                   \
    {                                                                       \
        VCCB_ONE_LOG_PRINT(LC_ERROR, 0, "EXIT(" #_cause ", %d)\n", _cause); \
        VCCB_PRINTF("EXIT(" #_cause ", %d)\n", _cause);                     \
        fflush(NULL);                                                       \
        thsSleep(VCCB_EXIT_WAIT_TIME);                                      \
        exit(_cause);                                                       \
    }

#define VCCB_CHECK_RTCODE_EXIT(_rtCode, _funcStr, _cause)                           \
    if (_rtCode < 0)                                                                \
    {                                                                               \
        VCCB_ONE_LOG_PRINT(LC_ERROR, 0, _funcStr " Failed : EXIT (%d)\n", _rtCode); \
        VCCB_PRINTF(_funcStr " Failed : EXIT (%d)\n", _rtCode);                     \
        VCCB_EXIT(_cause);                                                          \
    }


#define VCCB_CHECK_RTCODE_KEEP(_rtCode, _funcStr)                                        \
    if (_rtCode < 0)                                                                     \
    {                                                                                    \
        VCCB_ONE_LOG_PRINT(LC_INFO, 0, _funcStr " Failed : Keep going (%d)\n", _rtCode); \
        VCCB_PRINTF(_funcStr " Failed : Keep going (%d)\n", _rtCode);                    \
    }

#define VCCB_CHECK_RTCODE_SLEEP(_rtCode, _funcStr, _id)                                 \
    if (_rtCode < 0)                                                                    \
    {                                                                                   \
        VCCB_ONE_LOG_PRINT(LC_INFO, 0, _funcStr " Failed (%d), id=%d\n", _rtCode, _id); \
        VCCB_PRINTF(_funcStr " Failed (%d), id=%d\n", _rtCode, _id);                    \
        thsSleep(VCCB_SLEEP_WAIT_TIME);                                                 \
    }                                                                                   \
    else                                                                                \
    {                                                                                   \
        break;                                                                          \
    }

#define VCCB_CHECK_MUTEX_RTCODE_EXIT(_rtCode, _funcStr, _cause)                     \
    if (0 != _rtCode)                                                               \
    {                                                                               \
        VCCB_ONE_LOG_PRINT(LC_ERROR, 0, _funcStr " Failed : EXIT (%d)\n", _rtCode); \
        VCCB_PRINTF(_funcStr " Failed : EXIT (%d)\n", _rtCode);                     \
        VCCB_EXIT(_cause);                                                         \
    }

#define VCCB_RETURN_ON_COMMON_WO_CALL(__resultOfFunc, __errorCaseCheckValue, __return, __msg, __args...) \
    do                                                                                                   \
    {                                                                                                    \
        if (__resultOfFunc == __errorCaseCheckValue)                                                     \
        {                                                                                                \
            VCCB_PRINT_ERROR(__msg, ##__args);                                                           \
            __return;                                                                                    \
        }                                                                                                \
    } while (0)

#define VCCB_RETURN_ON_ERROR(__func, __msg, __args...) \
    VCCB_RETURN_ON_COMMON_WO_CALL(__func, ERROR, return ERROR, __msg, ##__args)
#define VCCB_RETURN_ON_VOID(__func, __msg, __args...) \
    VCCB_RETURN_ON_COMMON_WO_CALL(__func, ERROR, return, __msg, ##__args)

#define VCCB_RETURN_ON_COMMON_W_CALL_EQ(__ptCi, __resultOfFunc, __errorCaseCheckValue, __return, __msg, __args...) \
    do                                                                                                             \
    {                                                                                                              \
        if (__resultOfFunc == __errorCaseCheckValue)                                                               \
        {                                                                                                          \
            VCCB_PRINT_CALL_ERROR(__ptCi, __msg, ##__args);                                                        \
            __return;                                                                                              \
        }                                                                                                          \
    } while (0)

#define VCCB_RETURN_ON_CALL_ERROR(__ptCi, __func, __msg, __args...) \
    VCCB_RETURN_ON_COMMON_W_CALL_EQ(__ptCi, __func, ERROR, return ERROR, __msg, ##__args)
#define VCCB_RETURN_ON_CALL_VOID(__ptCi, __func, __msg, __args...) \
    VCCB_RETURN_ON_COMMON_W_CALL_EQ(__ptCi, __func, ERROR, return, __msg, ##__args)

#define VCCB_RETURN_ON_COMMON_W_CALL_NEQ(__ptCi, __result, __checkValue, __return, __msg, __args...) \
    do                                                                                               \
    {                                                                                                \
        if (__result != __checkValue)                                                                \
        {                                                                                            \
            VCCB_PRINT_CALL_ERROR(__ptCi, __msg, ##__args);                                          \
            __return;                                                                                \
        }                                                                                            \
    } while (0)

#define VCCB_RETURN_ERROR_ON_CALL_NOT_GOOD(__ptCi, __result, __msg, __args...) \
    VCCB_RETURN_ON_COMMON_W_CALL_NEQ(__ptCi, __result, GOOD, return ERROR, __msg, ##__args)

#define VCCB_PRINT_ON_COMMON_W_CALL_NEQ(__ptCi, __result, __checkValue, __msg, __args...) \
    do                                                                                    \
    {                                                                                     \
        if (__result != __checkValue)                                                     \
        {                                                                                 \
            VCCB_PRINT_CALL_ERROR(__ptCi, __msg, ##__args);                               \
        }                                                                                 \
    } while (0)

#define VCCB_PRINT_WITHOUT_RETURN_ON_CALL_NOT_GOOD(__ptCi, __result, __msg, __args...) \
    VCCB_PRINT_ON_COMMON_W_CALL_NEQ(__ptCi, __result, GOOD, __msg, ##__args)

#define VCCB_RETURN_ON_CALL_GOTO(__ptCi, __func, __goto, __msg, __args...) \
    VCCB_RETURN_ON_COMMON_W_CALL_EQ(__ptCi, __func, ERROR, goto __goto, __msg, ##__args)

#define VCCB_RETURN_ON_CALL_ERROR_W_DETACH_TIMER(__ptCi, __func, __timer, __msg, __args...)                          \
    VCCB_RETURN_ON_COMMON_W_CALL_EQ(__ptCi, __func, ERROR, VCCB_CLEAR_TIMER(__timer, CANCEL_TIMER); \
                                    return ERROR, __msg, ##__args)

#define VCCB_RETURN_ON_COMMON_W_CALL_NE(__ptCi, __resultOfFunc, __GoodCaseCheckValue, __return, __msg, __args...) \
    do                                                                                                            \
    {                                                                                                             \
        if (__resultOfFunc != __GoodCaseCheckValue)                                                               \
        {                                                                                                         \
            VCCB_PRINT_CALL_ERROR(__ptCi, __msg, ##__args);                                                       \
            __return;                                                                                             \
        }                                                                                                         \
    } while (0)

#define VCCB_ASN_RETURN_ON_CALL_ERROR(__ptCi, __func, __msg, __args...) \
    VCCB_RETURN_ON_COMMON_W_CALL_NE(__ptCi, __func, ASN_OK, return ERROR, __msg, ##__args)

#define VCCB_RETURN_ON_CALL_OR_NONUE_ASN1_THREAD_CALL_NERROR(__ptCi, __func, __msg, __args...) \
    do                                                                                   \
    {                                                                                    \
        if (&THREAD_INFO->nonUeAsn1.tempCallInfo != __ptCi)                              \
        {                                                                                \
            VCCB_RETURN_ON_CALL_ERROR(__ptCi, __func, __msg, ##__args);                  \
        }                                                                                \
        else                                                                             \
        {                                                                                \
            VCCB_RETURN_ON_ERROR(__func, __msg, ##__args);                               \
        }                                                                                \
    } while (0)

#define VCCB_GOTO_ON_CALL_ERROR(__goto, __result, __ptCi, func, msg, args...) \
    do                                                                        \
    {                                                                         \
        if (ERROR == func)                                                    \
        {                                                                     \
            VCCB_PRINT_CALL_ERROR(__ptCi, msg, ##args);                       \
            __result = ERROR;                                                 \
            goto __goto;                                                      \
        }                                                                     \
    } while (0)

#define VCCB_RETURN_ON_CALL_NBREAK(__ptCi, __resultOfFunc, __msg, __args...) \
    do                                                                       \
    {                                                                        \
        if (BREAK == __resultOfFunc)                                         \
        {                                                                    \
            VCCB_PRINT_CALL_COMMENT((__ptCi), __msg, ##__args);              \
            return BREAK;                                                    \
        }                                                                    \
    } while (0)

#define VCCB_RETURN_ON_CALL_NMULTI_UP_ERROR(__ptCi, __resultOfFunc, __msg, __args...) \
    do                                                                                \
    {                                                                                 \
        if (MULTI_UP_ERROR == __resultOfFunc)                                         \
        {                                                                             \
            VCCB_PRINT_CALL_ERROR((__ptCi), __msg, ##__args);                         \
            return MULTI_UP_ERROR;                                                    \
        }                                                                             \
    } while (0)

#define UINT64_SIZE (sizeof(uint64_t) * 8)

#define NG1_INTERFACE 1

#define MSG_SCREEN_CHKBIT(p, i) ((p[i / UINT64_SIZE] & (1ULL << (i % UINT64_SIZE))) ? TRUE : FALSE)

//-----------------------------------------------------
// 1. Flags in callInfo_type
//-----------------------------------------------------
// RRC_CONNECTION_FLAG : 0
#define ON_RRC_CONNECTION_FLAG(p)  ONBIT(p, RRC_CONNECTION_FLAG)
#define OFF_RRC_CONNECTION_FLAG(p) OFFBIT(p, RRC_CONNECTION_FLAG)
#define GET_RRC_CONNECTION_FLAG(p) GETBIT(p, RRC_CONNECTION_FLAG)

// NGC_CONNECTION_FLAG : 1
#define ON_NGC_CONNECTION_FLAG(p)  ONBIT(p, NGC_CONNECTION_FLAG)
#define OFF_NGC_CONNECTION_FLAG(p) OFFBIT(p, NGC_CONNECTION_FLAG)
#define GET_NGC_CONNECTION_FLAG(p) GETBIT(p, NGC_CONNECTION_FLAG)

// UE_CAPA_INQUIRY_FLAG : 2
#define ON_UE_CAPA_INQUIRY_FLAG(p)  ONBIT(p, UE_CAPA_INQUIRY_FLAG)
#define OFF_UE_CAPA_INQUIRY_FLAG(p) OFFBIT(p, UE_CAPA_INQUIRY_FLAG)
#define GET_UE_CAPA_INQUIRY_FLAG(p) GETBIT(p, UE_CAPA_INQUIRY_FLAG)

// RRC_RECONFIG_FLAG : 3
#define ON_RRC_RECONFIG_FLAG(p)  ONBIT(p, RRC_RECONFIG_FLAG)
#define OFF_RRC_RECONFIG_FLAG(p) OFFBIT(p, RRC_RECONFIG_FLAG)
#define GET_RRC_RECONFIG_FLAG(p) GETBIT(p, RRC_RECONFIG_FLAG)

// UE_CTXT_MODIFY_FLAG : 4
#define ON_UE_CTXT_MODIFY_FLAG(p)  ONBIT(p, UE_CTXT_MODIFY_FLAG)
#define OFF_UE_CTXT_MODIFY_FLAG(p) OFFBIT(p, UE_CTXT_MODIFY_FLAG)
#define GET_UE_CTXT_MODIFY_FLAG(p) GETBIT(p, UE_CTXT_MODIFY_FLAG)

// SECURITY_MODE_CMD_FLAG : 5
// setupFlag - Set to ON just before sending SecurityModeCommand(MakeMsgNRRRC_SecurityModeCommand) for distinguish
// whether security settings(DL/UL Integrity) are required. respFlag - Set to ON after sending SecurityModeCommand and
// set to OFF after receiving SecurityModeComplete for distinguish whether security settings(UL ciphering) are required.
#define ON_SECURITY_MODE_CMD_FLAG(p)  ONBIT(p, SECURITY_MODE_CMD_FLAG)
#define OFF_SECURITY_MODE_CMD_FLAG(p) OFFBIT(p, SECURITY_MODE_CMD_FLAG)
#define GET_SECURITY_MODE_CMD_FLAG(p) GETBIT(p, SECURITY_MODE_CMD_FLAG)

// NMB_UE_RESOURCE_FLAG : 6
#define ON_NMB_UE_RESOURCE_FLAG(p)  ONBIT(p, NMB_UE_RESOURCE_FLAG)
#define OFF_NMB_UE_RESOURCE_FLAG(p) OFFBIT(p, NMB_UE_RESOURCE_FLAG)
#define GET_NMB_UE_RESOURCE_FLAG(p) GETBIT(p, NMB_UE_RESOURCE_FLAG)

// F1_UECAPA_EUTRA_OMIT : 7
#define ON_F1_UECAPA_EUTRA_OMIT(p)  ONBIT(p, F1_UECAPA_EUTRA_OMIT)
#define OFF_F1_UECAPA_EUTRA_OMIT(p) OFFBIT(p, F1_UECAPA_EUTRA_OMIT)
#define GET_F1_UECAPA_EUTRA_OMIT(p) GETBIT(p, F1_UECAPA_EUTRA_OMIT)

// SN_NODE_MOD_ACK_RCV_FLAG : 8
#define ON_SN_NODE_MOD_ACK_RCV_FLAG(p)  ONBIT(p, SN_NODE_MOD_ACK_RCV_FLAG)
#define OFF_SN_NODE_MOD_ACK_RCV_FLAG(p) OFFBIT(p, SN_NODE_MOD_ACK_RCV_FLAG)
#define GET_SN_NODE_MOD_ACK_RCV_FLAG(p) GETBIT(p, SN_NODE_MOD_ACK_RCV_FLAG)

// SN_NODE_REL_ACK_RCV_FLAG : 9
#define ON_SN_NODE_REL_ACK_RCV_FLAG(p)  ONBIT(p, SN_NODE_REL_ACK_RCV_FLAG)
#define OFF_SN_NODE_REL_ACK_RCV_FLAG(p) OFFBIT(p, SN_NODE_REL_ACK_RCV_FLAG)
#define GET_SN_NODE_REL_ACK_RCV_FLAG(p) GETBIT(p, SN_NODE_REL_ACK_RCV_FLAG)

// E1_REL_COMPLT_RCV_FLAG  : 10
#define ON_E1_REL_COMPLT_RCV_FLAG(p)  ONBIT(p, E1_REL_COMPLT_RCV_FLAG)
#define OFF_E1_REL_COMPLT_RCV_FLAG(p) OFFBIT(p, E1_REL_COMPLT_RCV_FLAG)
#define GET_E1_REL_COMPLT_RCV_FLAG(p) GETBIT(p, E1_REL_COMPLT_RCV_FLAG)

// F1_REL_COMPLT_RCV_FLAG  : 11
#define ON_F1_REL_COMPLT_RCV_FLAG(p)  ONBIT(p, F1_REL_COMPLT_RCV_FLAG)
#define OFF_F1_REL_COMPLT_RCV_FLAG(p) OFFBIT(p, F1_REL_COMPLT_RCV_FLAG)
#define GET_F1_REL_COMPLT_RCV_FLAG(p) GETBIT(p, F1_REL_COMPLT_RCV_FLAG)

// MENB_CONNECTION_FLAG : 12
#define ON_MENB_CONNECTION_FLAG(p)  ONBIT(p, MENB_CONNECTION_FLAG)
#define OFF_MENB_CONNECTION_FLAG(p) OFFBIT(p, MENB_CONNECTION_FLAG)
#define GET_MENB_CONNECTION_FLAG(p) GETBIT(p, MENB_CONNECTION_FLAG)

// SGNB_MOD_CONF_FLAG : 13
#define ON_SGNB_MOD_CONF_FLAG(p)  ONBIT(p, SGNB_MOD_CONF_FLAG)
#define OFF_SGNB_MOD_CONF_FLAG(p) OFFBIT(p, SGNB_MOD_CONF_FLAG)
#define GET_SGNB_MOD_CONF_FLAG(p) GETBIT(p, SGNB_MOD_CONF_FLAG)

// F1_CTXT_MODRSP_FLAG : 14
#define ON_F1_CTXT_MODRSP_FLAG(p)  ONBIT(p, F1_CTXT_MODRSP_FLAG)
#define OFF_F1_CTXT_MODRSP_FLAG(p) OFFBIT(p, F1_CTXT_MODRSP_FLAG)
#define GET_F1_CTXT_MODRSP_FLAG(p) GETBIT(p, F1_CTXT_MODRSP_FLAG)

// E1_CTXT_MODRSP_FLAG : 15
#define ON_E1_CTXT_MODRSP_FLAG(p)  ONBIT(p, E1_CTXT_MODRSP_FLAG)
#define OFF_E1_CTXT_MODRSP_FLAG(p) OFFBIT(p, E1_CTXT_MODRSP_FLAG)
#define GET_E1_CTXT_MODRSP_FLAG(p) GETBIT(p, E1_CTXT_MODRSP_FLAG)

// SGNB_REC_CMPL_FLAG : 16
#define ON_SGNB_REC_CMPL_FLAG(p)  ONBIT(p, SGNB_REC_CMPL_FLAG)
#define OFF_SGNB_REC_CMPL_FLAG(p) OFFBIT(p, SGNB_REC_CMPL_FLAG)
#define GET_SGNB_REC_CMPL_FLAG(p) GETBIT(p, SGNB_REC_CMPL_FLAG)

// SGNB_MOD_REQ_FLAG : 17
#define ON_SGNB_MOD_REQ_FLAG(p)  ONBIT(p, SGNB_MOD_REQ_FLAG)
#define OFF_SGNB_MOD_REQ_FLAG(p) OFFBIT(p, SGNB_MOD_REQ_FLAG)
#define GET_SGNB_MOD_REQ_FLAG(p) GETBIT(p, SGNB_MOD_REQ_FLAG)

// F1_RESOURCE_FLAG : 18
#define ON_F1_RESOURCE_FLAG(p)  ONBIT(p, F1_RESOURCE_FLAG)
#define OFF_F1_RESOURCE_FLAG(p) OFFBIT(p, F1_RESOURCE_FLAG)
#define GET_F1_RESOURCE_FLAG(p) GETBIT(p, F1_RESOURCE_FLAG)

// E1_RESOURCE_FLAG : 19
#define ON_E1_RESOURCE_FLAG(p)  ONBIT(p, E1_RESOURCE_FLAG)
#define OFF_E1_RESOURCE_FLAG(p) OFFBIT(p, E1_RESOURCE_FLAG)
#define GET_E1_RESOURCE_FLAG(p) GETBIT(p, E1_RESOURCE_FLAG)

// F1_RESOURCE_FLAG : 20
#define ON_F1_RESOURCE_TGT_FLAG(p)  ONBIT(p, F1_RESOURCE_TGT_FLAG)
#define OFF_F1_RESOURCE_TGT_FLAG(p) OFFBIT(p, F1_RESOURCE_TGT_FLAG)
#define GET_F1_RESOURCE_TGT_FLAG(p) GETBIT(p, F1_RESOURCE_TGT_FLAG)

// F1_REL_COMPLT_RCV_FLAG  : 21
#define ON_F1_REL_CMP_RCV_TGT_FLAG(p)  ONBIT(p, F1_REL_CMP_RCV_TGT_FLAG)
#define OFF_F1_REL_CMP_RCV_TGT_FLAG(p) OFFBIT(p, F1_REL_CMP_RCV_TGT_FLAG)
#define GET_F1_REL_CMP_RCV_TGT_FLAG(p) GETBIT(p, F1_REL_CMP_RCV_TGT_FLAG)

// CGCFINFO_NEED_FWD_FLAG : 22
#define ON_CGCFINFO_NEED_FWD_FLAG(p)  ONBIT(p, CGCFINFO_NEED_FWD_FLAG)
#define OFF_CGCFINFO_NEED_FWD_FLAG(p) OFFBIT(p, CGCFINFO_NEED_FWD_FLAG)
#define GET_CGCFINFO_NEED_FWD_FLAG(p) GETBIT(p, CGCFINFO_NEED_FWD_FLAG)

// UECAPA_NEED_FWD_FLAG : 23
#define ON_UECAPA_NEED_FWD_FLAG(p)  ONBIT(p, UECAPA_NEED_FWD_FLAG)
#define OFF_UECAPA_NEED_FWD_FLAG(p) OFFBIT(p, UECAPA_NEED_FWD_FLAG)
#define GET_UECAPA_NEED_FWD_FLAG(p) GETBIT(p, UECAPA_NEED_FWD_FLAG)

// SGNB_MOD_REQ_FLAG : 24
#define ON_SGNB_ADD_REQ_FLAG(p)  ONBIT(p, SGNB_ADD_REQ_FLAG)
#define OFF_SGNB_ADD_REQ_FLAG(p) OFFBIT(p, SGNB_ADD_REQ_FLAG)
#define GET_SGNB_ADD_REQ_FLAG(p) GETBIT(p, SGNB_ADD_REQ_FLAG)

// SCG_CELLGROUPCONFIG_REQ : 25
#define ON_NO_SGNB_REC_COMP_FLAG(p)  ONBIT(p, NO_SGNB_REC_COMP_FLAG)
#define OFF_NO_SGNB_REC_COMP_FLAG(p) OFFBIT(p, NO_SGNB_REC_COMP_FLAG)
#define GET_NO_SGNB_REC_COMP_FLAG(p) GETBIT(p, NO_SGNB_REC_COMP_FLAG)

// SCG_CELLGROUPCONFIG_REQ : 26
#define ON_SCG_CELLGROUPCONFIG_REQ(p)  ONBIT(p, SCG_CELLGRPCFG_REQ_FLAG)
#define OFF_SCG_CELLGROUPCONFIG_REQ(p) OFFBIT(p, SCG_CELLGRPCFG_REQ_FLAG)
#define GET_SCG_CELLGROUPCONFIG_REQ(p) GETBIT(p, SCG_CELLGRPCFG_REQ_FLAG)

// BAND_COMB_CHG_FLAG : 27
#define ON_BAND_COMB_CHG_FLAG(p)  ONBIT(p, BAND_COMB_CHG_FLAG)
#define OFF_BAND_COMB_CHG_FLAG(p) OFFBIT(p, BAND_COMB_CHG_FLAG)
#define GET_BAND_COMB_CHG_FLAG(p) GETBIT(p, BAND_COMB_CHG_FLAG)

// SGNB_ADD_REQ_TGT_FLAG : 28
#define ON_SGNB_ADD_REQ_TGT_FLAG(p)  ONBIT(p, SGNB_ADD_REQ_TGT_FLAG)
#define OFF_SGNB_ADD_REQ_TGT_FLAG(p) OFFBIT(p, SGNB_ADD_REQ_TGT_FLAG)
#define GET_SGNB_ADD_REQ_TGT_FLAG(p) GETBIT(p, SGNB_ADD_REQ_TGT_FLAG)

// MENB_CONN_TGT_FLAG : 29
#define ON_MENB_CONN_TGT_FLAG(p)  ONBIT(p, MENB_CONN_TGT_FLAG)
#define OFF_MENB_CONN_TGT_FLAG(p) OFFBIT(p, MENB_CONN_TGT_FLAG)
#define GET_MENB_CONN_TGT_FLAG(p) GETBIT(p, MENB_CONN_TGT_FLAG)

// X2_SN_STATUS_FLAG : 30
#define ON_X2_SN_STATUS_FLAG(p)  ONBIT(p, X2_SN_STATUS_FLAG)
#define OFF_X2_SN_STATUS_FLAG(p) OFFBIT(p, X2_SN_STATUS_FLAG)
#define GET_X2_SN_STATUS_FLAG(p) GETBIT(p, X2_SN_STATUS_FLAG)

// NG_INIT_SETUP_FLAG : 32
#define ON_NG_INIT_SETUP_FLAG(p)  ONBIT(p, NG_INIT_SETUP_FLAG)
#define OFF_NG_INIT_SETUP_FLAG(p) OFFBIT(p, NG_INIT_SETUP_FLAG)
#define GET_NG_INIT_SETUP_FLAG(p) GETBIT(p, NG_INIT_SETUP_FLAG)

// MENB_SRC_X2_REL_REQ_FLAG : 33
#define ON_MENB_SRC_X2_REL_REQ_FLAG(p)  ONBIT(p, MENB_SRC_X2_REL_REQ_FLAG)
#define OFF_MENB_SRC_X2_REL_REQ_FLAG(p) OFFBIT(p, MENB_SRC_X2_REL_REQ_FLAG)
#define GET_MENB_SRC_X2_REL_REQ_FLAG(p) GETBIT(p, MENB_SRC_X2_REL_REQ_FLAG)

// SN_STATUS_FLAG : 34
#define ON_SN_STATUS_FLAG(p)  ONBIT(p, SN_STATUS_FLAG)
#define OFF_SN_STATUS_FLAG(p) OFFBIT(p, SN_STATUS_FLAG)
#define GET_SN_STATUS_FLAG(p) GETBIT(p, SN_STATUS_FLAG)

// E1_PDCP_SN_FLAG : 35
#define ON_E1_PDCP_SN_FLAG(p)  ONBIT(p, E1_PDCP_SN_FLAG)
#define OFF_E1_PDCP_SN_FLAG(p) OFFBIT(p, E1_PDCP_SN_FLAG)
#define GET_E1_PDCP_SN_FLAG(p) GETBIT(p, E1_PDCP_SN_FLAG)

// F1_CELLGROUPCONFIG_FLAG : 36
#define ON_F1_CELLGROUPCONFIG_FLAG(p)  ONBIT(p, F1_CELLGROUPCONFIG_FLAG)
#define OFF_F1_CELLGROUPCONFIG_FLAG(p) OFFBIT(p, F1_CELLGROUPCONFIG_FLAG)
#define GET_F1_CELLGROUPCONFIG_FLAG(p) GETBIT(p, F1_CELLGROUPCONFIG_FLAG)

// F1_RESOURCE_FLAG : 37
#define ON_F1_RSC_PREPARATION_FLAG(p)  ONBIT(p, F1_RSC_PREPARATION_FLAG)
#define OFF_F1_RSC_PREPARATION_FLAG(p) OFFBIT(p, F1_RSC_PREPARATION_FLAG)
#define GET_F1_RSC_PREPARATION_FLAG(p) GETBIT(p, F1_RSC_PREPARATION_FLAG)

// F1_RESOURCE_OLD_FLAG : 38
#define ON_F1_RESOURCE_OLD_FLAG(p)  ONBIT(p, F1_RESOURCE_OLD_FLAG)
#define OFF_F1_RESOURCE_OLD_FLAG(p) OFFBIT(p, F1_RESOURCE_OLD_FLAG)
#define GET_F1_RESOURCE_OLD_FLAG(p) GETBIT(p, F1_RESOURCE_OLD_FLAG)

// PDU_SESSION_PROC_NO_RESP : 42
#define ON_PDU_SESSION_PROC_NO_RESP(p)  ONBIT(p, PDU_SESSION_PROC_NO_RESP)
#define OFF_PDU_SESSION_PROC_NO_RESP(p) OFFBIT(p, PDU_SESSION_PROC_NO_RESP)
#define GET_PDU_SESSION_PROC_NO_RESP(p) GETBIT(p, PDU_SESSION_PROC_NO_RESP)

// NRRRC_CELLGROUPCONFIG_FLAG : 43
#define ON_NRRRC_CELLGROUPCONFIG_FLAG(p)  ONBIT(p, NRRRC_CELLGROUPCONFIG_FLAG)
#define OFF_NRRRC_CELLGROUPCONFIG_FLAG(p) OFFBIT(p, NRRRC_CELLGROUPCONFIG_FLAG)
#define GET_NRRRC_CELLGROUPCONFIG_FLAG(p) GETBIT(p, NRRRC_CELLGROUPCONFIG_FLAG)

// ALLOWED_BAND_COMB_CHG_FLAG : 44
#define ON_ALLOWED_BAND_COMB_CHG_FLAG(p)  ONBIT(p, ALLOWED_BAND_COMB_CHG_FLAG)
#define OFF_ALLOWED_BAND_COMB_CHG_FLAG(p) OFFBIT(p, ALLOWED_BAND_COMB_CHG_FLAG)
#define GET_ALLOWED_BAND_COMB_CHG_FLAG(p) GETBIT(p, ALLOWED_BAND_COMB_CHG_FLAG)

// F1_CTXT_MODRSP_TGT_FLAG : 45
#define ON_F1_CTXT_MODRSP_TGT_FLAG(p)  ONBIT(p, F1_CTXT_MODRSP_TGT_FLAG)
#define OFF_F1_CTXT_MODRSP_TGT_FLAG(p) OFFBIT(p, F1_CTXT_MODRSP_TGT_FLAG)
#define GET_F1_CTXT_MODRSP_TGT_FLAG(p) GETBIT(p, F1_CTXT_MODRSP_TGT_FLAG)

// NAS_STORED_FLAG : 46
#define ON_NAS_STORED_FLAG(p)  ONBIT(p, NAS_STORED_FLAG)
#define OFF_NAS_STORED_FLAG(p) OFFBIT(p, NAS_STORED_FLAG)
#define GET_NAS_STORED_FLAG(p) GETBIT(p, NAS_STORED_FLAG)

// NRRRC_UE_ASSISTANCE_INFO_FLAG : 47
#define ON_NRRRC_UE_ASSISTANCE_INFO_FLAG(p)  ONBIT(p, NRRRC_UE_ASSISTANCE_INFO_FLAG)
#define OFF_NRRRC_UE_ASSISTANCE_INFO_FLAG(p) OFFBIT(p, NRRRC_UE_ASSISTANCE_INFO_FLAG)
#define GET_NRRRC_UE_ASSISTANCE_INFO_FLAG(p) GETBIT(p, NRRRC_UE_ASSISTANCE_INFO_FLAG)

// PDUSESS_MODIFY_CONFIRM_FLAG : 48
#define ON_PDUSESS_MODIFY_CONFIRM_FLAG(p)  ONBIT(p, PDUSESS_MODIFY_CONFIRM_FLAG)
#define OFF_PDUSESS_MODIFY_CONFIRM_FLAG(p) OFFBIT(p, PDUSESS_MODIFY_CONFIRM_FLAG)
#define GET_PDUSESS_MODIFY_CONFIRM_FLAG(p) GETBIT(p, PDUSESS_MODIFY_CONFIRM_FLAG)

// XN_U_ADDRESS_IND_FLAG : 49
#define ON_XN_U_ADDRESS_INDICATION_FLAG(p)  ONBIT(p, XN_U_ADDRESS_IND_FLAG)
#define OFF_XN_U_ADDRESS_INDICATION_FLAG(p) OFFBIT(p, XN_U_ADDRESS_IND_FLAG)
#define GET_XN_U_ADDRESS_INDICATION_FLAG(p) GETBIT(p, XN_U_ADDRESS_IND_FLAG)

// MGNB_CONNECTION_FLAG : 50
#define ON_MGNB_CONNECTION_FLAG(p)  ONBIT(p, MGNB_CONNECTION_FLAG)
#define OFF_MGNB_CONNECTION_FLAG(p) OFFBIT(p, MGNB_CONNECTION_FLAG)
#define GET_MGNB_CONNECTION_FLAG(p) GETBIT(p, MGNB_CONNECTION_FLAG)

// SN_NODE_REL_REQ_WAIT_FLAG : 52
#define ON_SN_NODE_REL_REQ_WAIT_FLAG(p)  ONBIT(p, SN_NODE_REL_REQ_WAIT_FLAG)
#define OFF_SN_NODE_REL_REQ_WAIT_FLAG(p) OFFBIT(p, SN_NODE_REL_REQ_WAIT_FLAG)
#define GET_SN_NODE_REL_REQ_WAIT_FLAG(p) GETBIT(p, SN_NODE_REL_REQ_WAIT_FLAG)

// SN_NODE_ADD_ACK_RCV_FLAG : 54
#define ON_SN_NODE_ADD_ACK_RCV_FLAG(p)  ONBIT(p, SN_NODE_ADD_ACK_RCV_FLAG)
#define OFF_SN_NODE_ADD_ACK_RCV_FLAG(p) OFFBIT(p, SN_NODE_ADD_ACK_RCV_FLAG)
#define GET_SN_NODE_ADD_ACK_RCV_FLAG(p) GETBIT(p, SN_NODE_ADD_ACK_RCV_FLAG)

// SN_NODE_CHANGE_CONFIRM_RCV_FLAG : 55
#define ON_SN_NODE_CHANGE_CONFIRM_RCV_FLAG(p)  ONBIT(p, SN_NODE_CHANGE_CONFIRM_RCV_FLAG)
#define OFF_SN_NODE_CHANGE_CONFIRM_RCV_FLAG(p) OFFBIT(p, SN_NODE_CHANGE_CONFIRM_RCV_FLAG)
#define GET_SN_NODE_CHANGE_CONFIRM_RCV_FLAG(p) GETBIT(p, SN_NODE_CHANGE_CONFIRM_RCV_FLAG)

// XN_UE_CONTEXT_RELEASE_RCV_FLAG : 57
#define ON_XN_UE_CONTEXT_RELEASE_RCV_FLAG(p)  ONBIT(p, XN_UE_CONTEXT_RELEASE_RCV_FLAG)
#define OFF_XN_UE_CONTEXT_RELEASE_RCV_FLAG(p) OFFBIT(p, XN_UE_CONTEXT_RELEASE_RCV_FLAG)
#define GET_XN_UE_CONTEXT_RELEASE_RCV_FLAG(p) GETBIT(p, XN_UE_CONTEXT_RELEASE_RCV_FLAG)

// SN_ADDITION_PREPARATION_FLAG : 58
#define ON_SN_ADDITION_PREPARATION_FLAG(p)  ONBIT(p, SN_ADDITION_PREPARATION_FLAG)
#define OFF_SN_ADDITION_PREPARATION_FLAG(p) OFFBIT(p, SN_ADDITION_PREPARATION_FLAG)
#define GET_SN_ADDITION_PREPARATION_FLAG(p) GETBIT(p, SN_ADDITION_PREPARATION_FLAG)

// TRF_BASED_NR_TO_EUTRA_HO_REQUIRED : 59
#define ON_TRF_BASED_NR_TO_EUTRA_HO_REQUIRED(p)  ONBIT(p, TRF_BASED_NR_TO_EUTRA_HO_REQUIRED)
#define OFF_TRF_BASED_NR_TO_EUTRA_HO_REQUIRED(p) OFFBIT(p, TRF_BASED_NR_TO_EUTRA_HO_REQUIRED)
#define GET_TRF_BASED_NR_TO_EUTRA_HO_REQUIRED(p) GETBIT(p, TRF_BASED_NR_TO_EUTRA_HO_REQUIRED)

// MGNB_CONNECTION_TGT_FLAG : 60
#define ON_MGNB_CONNECTION_TGT_FLAG(p)  ONBIT(p, MGNB_CONNECTION_TGT_FLAG)
#define OFF_MGNB_CONNECTION_TGT_FLAG(p) OFFBIT(p, MGNB_CONNECTION_TGT_FLAG)
#define GET_MGNB_CONNECTION_TGT_FLAG(p) GETBIT(p, MGNB_CONNECTION_TGT_FLAG)

// F1_ACCESS_SUCCESS_FLAG : 62
#define ON_F1_ACCESS_SUCCESS_FLAG(p)  ONBIT(p, F1_ACCESS_SUCCESS_FLAG)
#define OFF_F1_ACCESS_SUCCESS_FLAG(p) OFFBIT(p, F1_ACCESS_SUCCESS_FLAG)
#define GET_F1_ACCESS_SUCCESS_FLAG(p) GETBIT(p, F1_ACCESS_SUCCESS_FLAG)

// CONFIGRESTRICTINFO_NEED_FWD_FLAG : 63
#define ON_CONFIGRESTRICTINFO_NEED_FWD_FLAG(p)  ONBIT(p, CONFIGRESTRICTINFO_NEED_FWD_FLAG)
#define OFF_CONFIGRESTRICTINFO_NEED_FWD_FLAG(p) OFFBIT(p, CONFIGRESTRICTINFO_NEED_FWD_FLAG)
#define GET_CONFIGRESTRICTINFO_NEED_FWD_FLAG(p) GETBIT(p, CONFIGRESTRICTINFO_NEED_FWD_FLAG)

//-----------------------------------------------------
// 2. Flags in callSRBInfo_type & callERABInfo_type
//-----------------------------------------------------

// DRB_E1_MODIFY_FLAG
#define ON_DRB_E1_MODIFY_FLAG(p)  ONBIT_U32(p, DRB_E1_MODIFY_FLAG)
#define OFF_DRB_E1_MODIFY_FLAG(p) OFFBIT_U32(p, DRB_E1_MODIFY_FLAG)

// DRB_SRC_CFG_FLAG
#define ON_DRB_SRC_CFG_FLAG(p)  ONBIT_U32(p, DRB_SRC_CFG_FLAG)
#define OFF_DRB_SRC_CFG_FLAG(p) OFFBIT_U32(p, DRB_SRC_CFG_FLAG)
#define GET_DRB_SRC_CFG_FLAG(p) GETBIT_U32(p, DRB_SRC_CFG_FLAG)

// DRB_SRC_CFG_FLAG
#define ON_DRB_SRC_CFG_DUPL_FLAG(p)  ONBIT_U32(p, DRB_SRC_CFG_DUPL_FLAG)
#define OFF_DRB_SRC_CFG_DUPL_FLAG(p) OFFBIT_U32(p, DRB_SRC_CFG_DUPL_FLAG)
#define GET_DRB_SRC_CFG_DUPL_FLAG(p) GETBIT(p, DRB_SRC_CFG_DUPL_FLAG)

// DRB_SRC_MCG_CFG_FLAG
#define ON_DRB_SRC_SCG_CFG_FLAG(p)  ONBIT(p, DRB_SRC_SCG_CFG_FLAG)
#define OFF_DRB_SRC_SCG_CFG_FLAG(p) OFFBIT(p, DRB_SRC_SCG_CFG_FLAG)
#define GET_DRB_SRC_SCG_CFG_FLAG(p) GETBIT(p, DRB_SRC_SCG_CFG_FLAG)

// DRB_SRC_MCG_CFG_FLAG
#define ON_DRB_SRC_MCG_CFG_FLAG(p)  ONBIT(p, DRB_SRC_MCG_CFG_FLAG)
#define OFF_DRB_SRC_MCG_CFG_FLAG(p) OFFBIT(p, DRB_SRC_MCG_CFG_FLAG)
#define GET_DRB_SRC_MCG_CFG_FLAG(p) GETBIT(p, DRB_SRC_MCG_CFG_FLAG)

// DRB_RELEASED_IN_SESSION_FLAG
#define ON_DRB_RELEASED_IN_SESSION_FLAG(p)  ONBIT_U32(p, DRB_RELEASED_IN_SESSION_FLAG)
#define OFF_DRB_RELEASED_IN_SESSION_FLAG(p) OFFBIT_U32(p, DRB_RELEASED_IN_SESSION_FLAG)
#define GET_DRB_RELEASED_IN_SESSION_FLAG(p) GETBIT_U32(p, DRB_RELEASED_IN_SESSION_FLAG)

//-----------------------------------------------------
// 3. Flags in callPDUSessioninfo
//-----------------------------------------------------
#define ON_PDU_SESS_E1_MODIFY_FLAG(p)  ONBIT_U32(p, PDU_SESS_E1_MODIFY_FLAG)
#define OFF_PDU_SESS_E1_MODIFY_FLAG(p) OFFBIT_U32(p, PDU_SESS_E1_MODIFY_FLAG)

#define ON_PDU_SESS_E1_SETUP_FLAG(p)  ONBIT_U32(p, PDU_SESS_E1_SETUP_FLAG)
#define OFF_PDU_SESS_E1_SETUP_FLAG(p) OFFBIT_U32(p, PDU_SESS_E1_SETUP_FLAG)

#define ON_PDUSESS_MODIFY_CONFIRM_TRANSFER_FLAG(p)  ONBIT(p, PDUSESS_MODIFY_CONFIRM_TRANSFER_FLAG)
#define OFF_PDUSESS_MODIFY_CONFIRM_TRANSFER_FLAG(p) OFFBIT(p, PDUSESS_MODIFY_CONFIRM_TRANSFER_FLAG)
#define GET_PDUSESS_MODIFY_CONFIRM_TRANSFER_FLAG(p) GETBIT(p, PDUSESS_MODIFY_CONFIRM_TRANSFER_FLAG)

#ifdef VCCB_IPC_TEST
#define VCCB_CLEAR_REQCOUNT_FORIPCTEST(_x)    (_x = 0)
#define VCCB_INCREASE_REQCOUNT_FORIPCTEST(_x) (_x++)
#else
#define VCCB_CLEAR_REQCOUNT_FORIPCTEST(_x)
#define VCCB_INCREASE_REQCOUNT_FORIPCTEST(_x)
#endif

#define CLEAR_ALL_PDUSESS_MODIFY_CONFIRM_TRANSFER_FLAG(_ptCi)                                \
    do                                                                                       \
    {                                                                                        \
        int _loop = 0;                                                                       \
        for (_loop = 0; _loop < MAX_PDU_SESS_PER_CALL; _loop++)                              \
        {                                                                                    \
            if ((_ptCi)->pduSess[_loop].usage != CI_use) continue;                           \
            OFF_PDUSESS_MODIFY_CONFIRM_TRANSFER_FLAG((_ptCi)->pduSess[_loop].flag.respFlag); \
        }                                                                                    \
    } while (0)

/////////////////////////////////////////////////////////////////////////////////////////////////////
// mrdcFlag 
/////////////////////////////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------
// 4. mrdcFlags in callPDUSessioninfo
//-----------------------------------------------------
// mrdcFlag.respFlag
#define ON_PDUSESS_TO_BE_ADDED_TO_SN_FLAG(p)  ONBIT(p, PDUSESS_TO_BE_ADDED_TO_SN_FLAG)
#define OFF_PDUSESS_TO_BE_ADDED_TO_SN_FLAG(p) OFFBIT(p, PDUSESS_TO_BE_ADDED_TO_SN_FLAG)
#define GET_PDUSESS_TO_BE_ADDED_TO_SN_FLAG(p) GETBIT(p, PDUSESS_TO_BE_ADDED_TO_SN_FLAG)

#define ON_PDUSESS_TO_BE_MODIFIED_TO_SN_FLAG(p)  ONBIT(p, PDUSESS_TO_BE_MODIFIED_TO_SN_FLAG)
#define OFF_PDUSESS_TO_BE_MODIFIED_TO_SN_FLAG(p) OFFBIT(p, PDUSESS_TO_BE_MODIFIED_TO_SN_FLAG)
#define GET_PDUSESS_TO_BE_MODIFIED_TO_SN_FLAG(p) GETBIT(p, PDUSESS_TO_BE_MODIFIED_TO_SN_FLAG)

#define ON_PDUSESS_TO_BE_RELEASED_TO_SN_FLAG(p)  ONBIT(p, PDUSESS_TO_BE_RELEASED_TO_SN_FLAG)
#define OFF_PDUSESS_TO_BE_RELEASED_TO_SN_FLAG(p) OFFBIT(p, PDUSESS_TO_BE_RELEASED_TO_SN_FLAG)
#define GET_PDUSESS_TO_BE_RELEASED_TO_SN_FLAG(p) GETBIT(p, PDUSESS_TO_BE_RELEASED_TO_SN_FLAG)

#define SET_DRBS_TO_BE_RELEASED_TO_SN_FLAG_PER_PDUSESS(_pPi, _isSnTerm, _onOff)                     \
    do                                                                                              \
    {                                                                                               \
        uint8_t idx = 0;                                                                            \
        for (idx = 0; idx < MAX_DRB_PER_PDU_SESS; idx++)                                            \
        {                                                                                           \
            uint16_t drbIdx = (_pPi)->drbIndex[idx];                                                \
                                                                                                    \
            if (drbIdx >= MAX_DRB_PER_SA_CALL) continue;                                            \
                                                                                                    \
            callDRBInfo_type *pDi = &ptCi->drb[drbIdx];                                             \
            if (pDi->usage != CI_use) continue;                                                     \
            if (!pDi->selectedBearerTypeFrozenFlag) continue;                                       \
                                                                                                    \
            if (_isSnTerm)                                                                          \
            {                                                                                       \
                if (_onOff)                                                                         \
                {                                                                                   \
                    ON_SNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(pDi->mrdcFlag.respFlag);                \
                }                                                                                   \
                else                                                                                \
                {                                                                                   \
                    OFF_SNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(pDi->mrdcFlag.respFlag);               \
                }                                                                                   \
            }                                                                                       \
            else if (pDi->bearerType.val == MN_Term_SPLIT_Bearer)                                   \
            {                                                                                       \
                if (_onOff)                                                                         \
                {                                                                                   \
                    ON_MNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(pDi->mrdcFlag.respFlag);                \
                }                                                                                   \
                else                                                                                \
                {                                                                                   \
                    OFF_MNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(pDi->mrdcFlag.respFlag);               \
                }                                                                                   \
            }                                                                                       \
        }                                                                                           \
    } while (0)
//-----------------------------------------------------
// 5. mrdcFlags in callQosFlowInfo
//-----------------------------------------------------
// mrdcFlag.respFlag
#define ON_QOSFLOW_TO_BE_SETUP_TO_SN_FLAG(p)  ONBIT(p, QOSFLOW_TO_BE_SETUP_TO_SN_FLAG)
#define OFF_QOSFLOW_TO_BE_SETUP_TO_SN_FLAG(p) OFFBIT(p, QOSFLOW_TO_BE_SETUP_TO_SN_FLAG)
#define GET_QOSFLOW_TO_BE_SETUP_TO_SN_FLAG(p) GETBIT(p, QOSFLOW_TO_BE_SETUP_TO_SN_FLAG)

#define ON_QOSFLOW_TO_BE_MODIFIED_TO_SN_FLAG(p)  ONBIT(p, QOSFLOW_TO_BE_MODIFIED_TO_SN_FLAG)
#define OFF_QOSFLOW_TO_BE_MODIFIED_TO_SN_FLAG(p) OFFBIT(p, QOSFLOW_TO_BE_MODIFIED_TO_SN_FLAG)
#define GET_QOSFLOW_TO_BE_MODIFIED_TO_SN_FLAG(p) GETBIT(p, QOSFLOW_TO_BE_MODIFIED_TO_SN_FLAG)

#define ON_QOSFLOW_TO_BE_RELEASED_TO_SN_FLAG(p)  ONBIT(p, QOSFLOW_TO_BE_RELEASED_TO_SN_FLAG)
#define OFF_QOSFLOW_TO_BE_RELEASED_TO_SN_FLAG(p) OFFBIT(p, QOSFLOW_TO_BE_RELEASED_TO_SN_FLAG)
#define GET_QOSFLOW_TO_BE_RELEASED_TO_SN_FLAG(p) GETBIT(p, QOSFLOW_TO_BE_RELEASED_TO_SN_FLAG)

#define SET_DRB_TO_BE_RELEASED_TO_SN_FLAG_BY_QOSFLOW(_ptCi, _onOff)                   \
    do                                                                                \
    {                                                                                 \
        uint8_t drbIdx, qosIdx;                                                       \
        bool allQosFlowsTobeReleased = true;                                          \
        for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)                      \
        {                                                                             \
            callDRBInfo_type *pDi = &(_ptCi)->drb[drbIdx];                            \
                                                                                      \
            if (pDi->usage != CI_use) continue;                                       \
            if (!pDi->selectedBearerTypeFrozenFlag) continue;                         \
            if (pDi->bearerType.val == MN_Term_MCG_Bearer) continue;                  \
                                                                                      \
            allQosFlowsTobeReleased = true;                                           \
            for (qosIdx = 0; qosIdx < MAX_QOS_FLOW_PER_DRB; qosIdx++)                 \
            {                                                                         \
                uint16_t qosFlowIndex = pDi->qosFlowIndex[qosIdx];                    \
                if (qosFlowIndex >= MAX_QOS_FLOW_PER_CALL) continue;                  \
                                                                                      \
                qosFlowInfo_type *pQi = &ptCi->qosFlow[qosFlowIndex];                 \
                                                                                      \
                if (pQi->usage != CI_use) continue;                                   \
                if (!GET_QOSFLOW_TO_BE_RELEASED_TO_SN_FLAG(pQi->mrdcFlag.respFlag))   \
                {                                                                     \
                    allQosFlowsTobeReleased = false;                                  \
                    break;                                                            \
                }                                                                     \
            }                                                                         \
                                                                                      \
            if (!allQosFlowsTobeReleased)                                             \
            {                                                                         \
                continue;                                                             \
            }                                                                         \
                                                                                      \
            if (pDi->bearerType.termPoint == TermPoint_Sn)                        \
            {                                                                         \
                if (_onOff)                                                           \
                {                                                                     \
                    ON_SNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(pDi->mrdcFlag.respFlag);  \
                }                                                                     \
                else                                                                  \
                {                                                                     \
                    OFF_SNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(pDi->mrdcFlag.respFlag); \
                }                                                                     \
            }                                                                         \
            else                                                                      \
            {                                                                         \
                if (_onOff)                                                           \
                {                                                                     \
                    ON_MNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(pDi->mrdcFlag.respFlag);  \
                }                                                                     \
                else                                                                  \
                {                                                                     \
                    OFF_MNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(pDi->mrdcFlag.respFlag); \
                }                                                                     \
            }                                                                         \
        }                                                                             \
    } while (0)
//-----------------------------------------------------
// 6. mrdcFlags in callDrbInfo
//-----------------------------------------------------
// mrdcFlag.respFlag
#define ON_MNTERM_DRB_TO_BE_SETUP_TO_SN_FLAG(p)  ONBIT(p, MNTERM_DRB_TO_BE_SETUP_TO_SN_FLAG)
#define OFF_MNTERM_DRB_TO_BE_SETUP_TO_SN_FLAG(p) OFFBIT(p, MNTERM_DRB_TO_BE_SETUP_TO_SN_FLAG)
#define GET_MNTERM_DRB_TO_BE_SETUP_TO_SN_FLAG(p) GETBIT(p, MNTERM_DRB_TO_BE_SETUP_TO_SN_FLAG)

#define ON_MNTERM_DRB_TO_BE_MODIFIED_TO_SN_FLAG(p)  ONBIT(p, MNTERM_DRB_TO_BE_MODIFIED_TO_SN_FLAG)
#define OFF_MNTERM_DRB_TO_BE_MODIFIED_TO_SN_FLAG(p) OFFBIT(p, MNTERM_DRB_TO_BE_MODIFIED_TO_SN_FLAG)
#define GET_MNTERM_DRB_TO_BE_MODIFIED_TO_SN_FLAG(p) GETBIT(p, MNTERM_DRB_TO_BE_MODIFIED_TO_SN_FLAG)

#define ON_MNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(p)  ONBIT(p, MNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG)
#define OFF_MNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(p) OFFBIT(p, MNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG)
#define GET_MNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(p) GETBIT(p, MNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG)

#define ON_SNTERM_DRB_TO_BE_SETUP_TO_SN_FLAG(p)  ONBIT(p, SNTERM_DRB_TO_BE_SETUP_TO_SN_FLAG)
#define OFF_SNTERM_DRB_TO_BE_SETUP_TO_SN_FLAG(p) OFFBIT(p, SNTERM_DRB_TO_BE_SETUP_TO_SN_FLAG)
#define GET_SNTERM_DRB_TO_BE_SETUP_TO_SN_FLAG(p) GETBIT(p, SNTERM_DRB_TO_BE_SETUP_TO_SN_FLAG)

#define ON_SNTERM_DRB_TO_BE_MODIFIED_TO_SN_FLAG(p)  ONBIT(p, SNTERM_DRB_TO_BE_MODIFIED_TO_SN_FLAG)
#define OFF_SNTERM_DRB_TO_BE_MODIFIED_TO_SN_FLAG(p) OFFBIT(p, SNTERM_DRB_TO_BE_MODIFIED_TO_SN_FLAG)
#define GET_SNTERM_DRB_TO_BE_MODIFIED_TO_SN_FLAG(p) GETBIT(p, SNTERM_DRB_TO_BE_MODIFIED_TO_SN_FLAG)

#define ON_SNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(p)  ONBIT(p, SNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG)
#define OFF_SNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(p) OFFBIT(p, SNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG)
#define GET_SNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(p) GETBIT(p, SNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG)
//////////////////////////////////////////////////////////////////////////////////////////////////////
// mrdc event flag
#define ON_MRDC_EVENT_FLAG(_event, _flag) \
    do                                    \
    {                                     \
        (_event).f_##_flag = VCCB_FLAG_ON;\
    } while (0)
#define OFF_MRDC_EVENT_FLAG(_event, _flag) \
    do                                    \
    {                                     \
        (_event).f_##_flag = VCCB_FLAG_OFF;\
    } while (0)
#define GET_MRDC_EVENT_FLAG(_event, _flag) ((_event).f_##_flag) 
#define GET_MRDC_EVENT_FLAG_ALL(_event) ((_event).val) 

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------
// 7. toRespFlag in flag in callInfo
//-----------------------------------------------------

// 0. TO_RSP_VNMB_CALL_SETUP - Internal - Call Setup
#define ON_TO_RSP_VNMB_CALL_SETUP(p)  ONBIT((p)->flag.toRespFlag, TO_RSP_VNMB_CALL_SETUP)
#define OFF_TO_RSP_VNMB_CALL_SETUP(p) OFFBIT((p)->flag.toRespFlag, TO_RSP_VNMB_CALL_SETUP)
#define GET_TO_RSP_VNMB_CALL_SETUP(p) GETBIT((p)->flag.toRespFlag, TO_RSP_VNMB_CALL_SETUP)

// 1. TO_RSP_XN_SN_ADDITION_REQUEST - XN 8.3.1 S-NG-RAN node Addition Preparation
#define ON_TO_RSP_XN_SN_ADDITION_REQUEST(p)  ONBIT((p)->flag.toRespFlag, TO_RSP_XN_SN_ADDITION_REQUEST)
#define OFF_TO_RSP_XN_SN_ADDITION_REQUEST(p) OFFBIT((p)->flag.toRespFlag, TO_RSP_XN_SN_ADDITION_REQUEST)
#define GET_TO_RSP_XN_SN_ADDITION_REQUEST(p) GETBIT((p)->flag.toRespFlag, TO_RSP_XN_SN_ADDITION_REQUEST)

// 2. TO_RSP_XN_SN_MODIFICATION_REQUEST - XN 8.3.3 M-NG-RAN node initiated S-NG-RAN node Modification Preparation
#define ON_TO_RSP_XN_SN_MODIFICATION_REQUEST(p)  ONBIT((p)->flag.toRespFlag, TO_RSP_XN_SN_MODIFICATION_REQUEST)
#define OFF_TO_RSP_XN_SN_MODIFICATION_REQUEST(p) OFFBIT((p)->flag.toRespFlag, TO_RSP_XN_SN_MODIFICATION_REQUEST)
#define GET_TO_RSP_XN_SN_MODIFICATION_REQUEST(p) GETBIT((p)->flag.toRespFlag, TO_RSP_XN_SN_MODIFICATION_REQUEST)

// 3. TO_RSP_XN_SN_MODIFICATION_REQUIRED - XN 8.3.4 S-NG-RAN node initiated S-NG-RAN node Modification
#define ON_TO_RSP_XN_SN_MODIFICATION_REQUIRED(p)  ONBIT((p)->flag.toRespFlag, TO_RSP_XN_SN_MODIFICATION_REQUIRED)
#define OFF_TO_RSP_XN_SN_MODIFICATION_REQUIRED(p) OFFBIT((p)->flag.toRespFlag, TO_RSP_XN_SN_MODIFICATION_REQUIRED)
#define GET_TO_RSP_XN_SN_MODIFICATION_REQUIRED(p) GETBIT((p)->flag.toRespFlag, TO_RSP_XN_SN_MODIFICATION_REQUIRED)

// 4. TO_RSP_XN_SN_CHANGE_REQUIRED - XN 8.3.5 S-NG-RAN node initiated S-NG-RAN node Change
#define ON_TO_RSP_XN_SN_CHANGE_REQUIRED(p)  ONBIT((p)->flag.toRespFlag, TO_RSP_XN_SN_CHANGE_REQUIRED)
#define OFF_TO_RSP_XN_SN_CHANGE_REQUIRED(p) OFFBIT((p)->flag.toRespFlag, TO_RSP_XN_SN_CHANGE_REQUIRED)
#define GET_TO_RSP_XN_SN_CHANGE_REQUIRED(p) GETBIT((p)->flag.toRespFlag, TO_RSP_XN_SN_CHANGE_REQUIRED)

// 5. TO_RSP_XN_SN_RELEASE_REQUEST - XN 8.3.6 M-NG-RAN node initiated S-NG-RAN node Release
#define ON_TO_RSP_XN_SN_RELEASE_REQUEST(p)  ONBIT((p)->flag.toRespFlag, TO_RSP_XN_SN_RELEASE_REQUEST)
#define OFF_TO_RSP_XN_SN_RELEASE_REQUEST(p) OFFBIT((p)->flag.toRespFlag, TO_RSP_XN_SN_RELEASE_REQUEST)
#define GET_TO_RSP_XN_SN_RELEASE_REQUEST(p) GETBIT((p)->flag.toRespFlag, TO_RSP_XN_SN_RELEASE_REQUEST)

// 6. TO_RSP_XN_SN_RELEASE_REQUIRED - XN 8.3.7 S-NG-RAN node initiated S-NG-RAN node Release
#define ON_TO_RSP_XN_SN_RELEASE_REQUIRED(p)  ONBIT((p)->flag.toRespFlag, TO_RSP_XN_SN_RELEASE_REQUIRED)
#define OFF_TO_RSP_XN_SN_RELEASE_REQUIRED(p) OFFBIT((p)->flag.toRespFlag, TO_RSP_XN_SN_RELEASE_REQUIRED)
#define GET_TO_RSP_XN_SN_RELEASE_REQUIRED(p) GETBIT((p)->flag.toRespFlag, TO_RSP_XN_SN_RELEASE_REQUIRED)

// 7. TO_RSP_XN_HANDOVER_PREPARATION - XN 8.2.1 Handover Preparation
#define ON_TO_RSP_XN_HANDOVER_PREPARATION(p)  ONBIT((p)->flag.toRespFlag, TO_RSP_XN_HANDOVER_PREPARATION)
#define OFF_TO_RSP_XN_HANDOVER_PREPARATION(p) OFFBIT((p)->flag.toRespFlag, TO_RSP_XN_HANDOVER_PREPARATION)
#define GET_TO_RSP_XN_HANDOVER_PREPARATION(p) GETBIT((p)->flag.toRespFlag, TO_RSP_XN_HANDOVER_PREPARATION)

// 8. TO_RSP_NG_HANDOVER_PREPARATION - NG 8.4.1 Handover Preparation
#define ON_TO_RSP_NG_HANDOVER_PREPARATION(p)  ONBIT((p)->flag.toRespFlag, TO_RSP_NG_HANDOVER_PREPARATION)
#define OFF_TO_RSP_NG_HANDOVER_PREPARATION(p) OFFBIT((p)->flag.toRespFlag, TO_RSP_NG_HANDOVER_PREPARATION)
#define GET_TO_RSP_NG_HANDOVER_PREPARATION(p) GETBIT((p)->flag.toRespFlag, TO_RSP_NG_HANDOVER_PREPARATION)

//-----------------------------------------------------
// Flags for Modification Procedure (used for ptCi->modProcInfo.selectedModProc(uint16_t))
//-----------------------------------------------------
// E1_PROC_REQUIRED_FLAG
#define ON_E1_PROC_REQUIRED_FLAG(p)  ONBIT_U16(p, E1_PROC_REQUIRED_FLAG)
#define OFF_E1_PROC_REQUIRED_FLAG(p) OFFBIT_U16(p, E1_PROC_REQUIRED_FLAG)
#define GET_E1_PROC_REQUIRED_FLAG(p) GETBIT_U16(p, E1_PROC_REQUIRED_FLAG)

// F1_PROC_REQUIRED_FLAG
#define ON_F1_PROC_REQUIRED_FLAG(p)  ONBIT_U16(p, F1_PROC_REQUIRED_FLAG)
#define OFF_F1_PROC_REQUIRED_FLAG(p) OFFBIT_U16(p, F1_PROC_REQUIRED_FLAG)
#define GET_F1_PROC_REQUIRED_FLAG(p) GETBIT_U16(p, F1_PROC_REQUIRED_FLAG)

// ACK_PROC_REQUIRED_FLAG
#define ON_ACK_PROC_REQUIRED_FLAG(p)  ONBIT_U16(p, ACK_PROC_REQUIRED_FLAG)
#define OFF_ACK_PROC_REQUIRED_FLAG(p) OFFBIT_U16(p, ACK_PROC_REQUIRED_FLAG)
#define GET_ACK_PROC_REQUIRED_FLAG(p) GETBIT_U16(p, ACK_PROC_REQUIRED_FLAG)

// RSP_PROC_REQUIRED_FLAG
#define ON_RSP_PROC_REQUIRED_FLAG(p)  ONBIT_U16(p, RSP_PROC_REQUIRED_FLAG)
#define OFF_RSP_PROC_REQUIRED_FLAG(p) OFFBIT_U16(p, RSP_PROC_REQUIRED_FLAG)
#define GET_RSP_PROC_REQUIRED_FLAG(p) GETBIT_U16(p, RSP_PROC_REQUIRED_FLAG)

// F1CPLT_PROC_REQUIRED_FLAG
#define ON_F1CPLT_PROC_REQUIRED_FLAG(p)  ONBIT_U16(p, F1CPLT_PROC_REQUIRED_FLAG)
#define OFF_F1CPLT_PROC_REQUIRED_FLAG(p) OFFBIT_U16(p, F1CPLT_PROC_REQUIRED_FLAG)
#define GET_F1CPLT_PROC_REQUIRED_FLAG(p) GETBIT_U16(p, F1CPLT_PROC_REQUIRED_FLAG)

// XN_PROC_REQUIRED_FLAG
#define ON_XN_PROC_REQUIRED_FLAG(p)  ONBIT_U16(p, XN_PROC_REQUIRED_FLAG)
#define OFF_XN_PROC_REQUIRED_FLAG(p) OFFBIT_U16(p, XN_PROC_REQUIRED_FLAG)
#define GET_XN_PROC_REQUIRED_FLAG(p) GETBIT_U16(p, XN_PROC_REQUIRED_FLAG)
//-----------------------------------------------------

// Flags for ECID Procedure
#define ON_F1_ECID_MEAS_INIT_REQD_FLAG(p)  ONBIT(p, F1_ECID_MEAS_INIT_REQD_FLAG)
#define OFF_F1_ECID_MEAS_INIT_REQD_FLAG(p) OFFBIT(p, F1_ECID_MEAS_INIT_REQD_FLAG)
#define GET_F1_ECID_MEAS_INIT_REQD_FLAG(p) GETBIT(p, F1_ECID_MEAS_INIT_REQD_FLAG)

// Flags for Nrppa Positioning Procedure
#define ON_F1_ECID_SRS_POSITIONING_REQ_FLAG(p)  ONBIT(p, F1_ECID_SRS_POSITIONING_REQ_FLAG)
#define OFF_F1_ECID_SRS_POSITIONING_REQ_FLAG(p) OFFBIT(p, F1_ECID_SRS_POSITIONING_REQ_FLAG)
#define GET_F1_ECID_SRS_POSITIONING_REQ_FLAG(p) GETBIT(p, F1_ECID_SRS_POSITIONING_REQ_FLAG)

// VNB_CONNECTION_FLAG : 0
#define ON_VNB_CONNECTION_FLAG(p)  ONBIT(p, VNB_CONNECTION_FLAG)
#define OFF_VNB_CONNECTION_FLAG(p) OFFBIT(p, VNB_CONNECTION_FLAG)

// #define MIN(val, limit)       (((val) <= (limit)) ? (val) : (limit))  //moved to CALL_APP/Hdr/cp_macro.h
#define UMIN(val, limit) VLIB_CheckUpperLimit(__FILE__, __LINE__, limit, val)

#define IS_VALID_NODE(type, ptCi, ptr) VLIB_CheckAddrOfPool(__FILE__, __LINE__, type, ptCi, ptr, NULL)
#define IS_VALID_NODE_WITH_CAUSE(__type, __ptCi, __ptr, __ptCause)  VLIB_CheckAddrOfPool(__FILE__, __LINE__, __type, __ptCi, __ptr, __ptCause)

#define MUTEX_LOCK(p)   pthread_mutex_lock(p)
#define MUTEX_UNLOCK(p) pthread_mutex_unlock(p)

#define VCCB_WRITE_LOCK(p)      pthread_rwlock_wrlock(p)
#define VCCB_WRITE_UNLOCK(p)    pthread_rwlock_unlock(p)
#define VCCB_READ_LOCK(p)       pthread_rwlock_rdlock(p)
#define VCCB_READ_UNLOCK(p)     pthread_rwlock_unlock(p)

#define SET_STATE_CMD(_stateCmd)             \
    {                                        \
        ptCi->prevStateCmd = ptCi->stateCmd; \
        ptCi->stateCmd = _stateCmd;          \
    }

#define SET_STATE_CMD_REF(_call, _stateCmd)  \
    {                                        \
        _call.prevStateCmd = _call.stateCmd; \
        _call.stateCmd = _stateCmd;          \
    }

#define IS_VALID_PTCI(_ptCi) \
    ((&ENV->callInfo[0] <= _ptCi && _ptCi <= &ENV->callInfo[MAX_CALL_NUM_VCCB]) ? TRUE : FALSE)

// PCELL - UHI
#define IS_VALID_VISITED_CELL_PENDING(_ptCi, _addr) \
    ((_ptCi != NULL) && (_addr == &ptCi->ueHistory.pendingUeHistoryEntry))

#define IS_VALID_VISITED_CELL_UE_HSITORY_ARR(_ptCi, _addr) \
    ((_ptCi != NULL) &&                                    \
        (&ptCi->ueHistory.visitedCell[0] <= _addr && _addr <= &ptCi->ueHistory.visitedCell[MAX_VISITED_CELL - 1]))

#define IS_VALID_VISITED_CELL(_ptCi, _addr) \
    ((IS_VALID_VISITED_CELL_PENDING(_ptCi, _addr)) || (IS_VALID_VISITED_CELL_UE_HSITORY_ARR(_ptCi, _addr)))

// PSCELL - UHI
#define IS_VALID_VISITED_PS_CELL_PENDING(_pScgUHI, _addr) \
    ((_pScgUHI != NULL) && (_addr == &_pScgUHI->pendingEntry))

#define IS_VALID_VISITED_PS_CELL_UE_HSITORY_ARR(_pScgUHI, _addr) \
    ((_pScgUHI != NULL) &&                                    \
        (&_pScgUHI->lastVisitedPSCellList[0] <= _addr && _addr <= &_pScgUHI->lastVisitedPSCellList[MAX_PSCELL_HISTORY_PER_CALL-1]))

#define IS_VALID_VISITED_PS_CELL(_pScgUHI, _addr) \
    ((IS_VALID_VISITED_PS_CELL_PENDING(_pScgUHI, _addr)) || (IS_VALID_VISITED_PS_CELL_UE_HSITORY_ARR(_pScgUHI, _addr)))

#define IS_VALID_VISITED_CELL_RETURN(_ptCi, _addr)                                                                   \
    do                                                                                                               \
    {                                                                                                                \
        if (_addr->getType() == e_UPM_VISITED_PCELL)                                                                 \
        {                                                                                                            \
            if (!(IS_VALID_VISITED_CELL(_ptCi, _addr->getPtr())))                                                    \
            {                                                                                                        \
                VCCB_PRINT_CALL_ERROR(_ptCi, "UPM ERROR !! (Cause: DB is broken !! Range: %p ~ %p, %p / Req: %p)\n", \
                    &ptCi->ueHistory.visitedCell[0], &ptCi->ueHistory.visitedCell[MAX_VISITED_CELL - 1],             \
                    &ptCi->ueHistory.pendingUeHistoryEntry, _addr->getPtr());                                        \
                return ERROR;                                                                                        \
            }                                                                                                        \
        }                                                                                                            \
        else                                                                                                         \
        {                                                                                                            \
            VccbLastVisitedPSCellHandling_type *ptScgUHI = FnVCCB_GetLastVisitedPSCellListDB(_ptCi);                 \
            return IS_VALID_VISITED_PS_CELL(ptScgUHI, _addr->getPtr());                                              \
        }                                                                                                            \
    } while (0)

#define IS_STD_MAP_NOT_FOUND(__iter, __map) (__iter == __map.end())
#define IS_STD_MAP_FOUND(__iter, __map)     (!IS_STD_MAP_NOT_FOUND(__iter, __map))

#define IS_DEBUG(p, i) (p & (1 << i))
#define IS_CELLGROUPCONFIG_FULL(ptCi) \
    ((VCCB_FLAG_ON == (ptCi)->cellGroupConfigFullFlag) && (0 < (ptCi)->cellGroupConfig.numocts))
#define IS_SERVING_DU_BOARD_GCA(ptCi) \
    (BoardType_GCA == GNBINFO[(ptCi)->gnbNum].gnbDu[(ptCi)->endPointInfo.f1Idx].boardType)

#define INIT_FALLBACK_FLAG(_ptCi)                                   \
    {                                                               \
        _ptCi->redirectionInfo.isEPSFallbackRequired = FALSE;       \
        _ptCi->redirectionInfo.emergencyFallbackInd = FALSE;        \
        _ptCi->redirectionInfo.voiceFallbackIndicator = FALSE;      \
        _ptCi->bitFlag.isEmergencyFallbackByAmf = VCCB_FLAG_OFF;    \
    }

#define IS_UPDATED_REDUN_STATE_REQUIRE_IP_AND_PORT_UPDATE(_prevState, _nowState) \
    (((enumRedundancyStateType)_prevState != RedunState_active &&                \
         (enumRedundancyStateType)_prevState != RedunState_single) &&            \
        ((enumRedundancyStateType)_nowState == RedunState_active ||              \
            (enumRedundancyStateType)_nowState == RedunState_single))

#define IS_NAMESPACE_VALID(_nameSpace) !(_nameSpace[0] == '\0')

#define ON_EPS_FALLBACK_REDIRECTION(_ptCi)   (_ptCi->redirectionInfo.isEPSFallbackRequired = TRUE)
#define OFF_EPS_FALLBACK_REDIRECTION(_ptCi)  (_ptCi->redirectionInfo.isEPSFallbackRequired = FALSE)

#define ON_EMERGENCY_FALLBACK_REDIRECTION(_ptCi)   (_ptCi->redirectionInfo.emergencyFallbackInd = TRUE)
#define OFF_EMERGENCY_FALLBACK_REDIRECTION(_ptCi)  (_ptCi->redirectionInfo.emergencyFallbackInd = FALSE)

#define IS_EPS_FALLBACK_CASE(_ptCi)       (_ptCi->redirectionInfo.isEPSFallbackRequired == TRUE)
#define IS_EMERGENCY_FALLBACK_CASE(_ptCi) (_ptCi->redirectionInfo.emergencyFallbackInd == TRUE)

#define IS_FALLBACK_CASE(_ptCi) (IS_EPS_FALLBACK_CASE(_ptCi) || IS_EMERGENCY_FALLBACK_CASE(_ptCi))

#define IS_RFSP_BLIND_INTER_RAT_REDIRECTION(_ptCi) (_ptCi->redirectionInfo.rfspBasedBlind == TRUE)
#define IS_SPECIFIC_SLICE_REDIRECTION(_ptCi) (_ptCi->redirectionInfo.isSpecificSliceRejected == TRUE)

//SVR25B FGR-CC3101
#define IS_SPECIFIC_SLICE_REDIRECT_IN_BASIC_SA(_ptCi)   (_ptCi->redirectionInfo.specificSliceRedirectInBasicSA == TRUE)
//SVR25B FGR-CC3101
#define IS_RFSP_OR_SLICE_REDIRECTION_CASE(_ptCi) \
        (IS_RFSP_BLIND_INTER_RAT_REDIRECTION(_ptCi) || IS_SPECIFIC_SLICE_REDIRECT_IN_BASIC_SA(_ptCi))
//SVR25B FGR-CC3101
#define ON_SPECIFIC_SLICE_REDIRECT_IN_BASIC_SA(_ptCi)                             \
   {                                                                              \
      _ptCi->redirectionInfo.isSpecificSliceRejected = TRUE;                      \
      _ptCi->redirectionInfo.specificSliceRedirectInBasicSA = TRUE;               \
      VCCB_PRINT_CALL_INFORMATIVE(_ptCi, "SPECIFIC_SLICE Redirection is ON.\n");  \
   }

//SVR25B FGR-CC3101
#define CHECK_STATUS_AND_RETURN_FOR_SPECIFIC_SLICE_HO_OR_REDIRECT(_status, _msgId, _cause)   \
    {                                                                       \
        if((_status == STATE_BP_NEED_HO) ||                                 \
           (_status == STATE_BP_NEED_REDIRECT))                             \
        {                                                                   \
            return GOOD; /* HO or Redirect */                               \
        }                                                                   \
        else  /* STATE_BP_REDIRECT_FAIL or ERROR */                         \
        {                                                                   \
            MACRO_CALL_FAULT_SAVE(_msgId, _cause);                          \
            return ERROR; /* Call Release */                                \
        }                                                                   \
    }


#define IS_IRAT_LB_CASE(_reportType, _reportPurpose)                                                     \
    (((_reportType == measReport_B1Eutra) && (_reportPurpose == b1Purpose_loadBalancingIratHandover)) || \
        ((_reportType == measReport_B2Eutra) && (_reportPurpose == b2Purpose_loadBalancingIratHandover)))

#define IS_CAC_TRIGGERED_REDIRECTION_CASE(_ptCi)                 \
    (CELLINFO[(_ptCi)->servCellNum].preemptionWithRedirection && \
        (CauseF1apRadioReleaseDueToPreEmption == (_ptCi)->cause.callFault.callFaultCause))

#define IS_NOT_SUPPORT_FALLBACK_FLAG_IN_MEASOBJ(_ptCi, _pMeasObj)                                \
    ((IS_EMERGENCY_FALLBACK_CASE(_ptCi) && (_pMeasObj->emergencyFallbackSupportFlag != TRUE)) || \
        (IS_EPS_FALLBACK_CASE(_ptCi) && (_pMeasObj->voiceSupportFlag != TRUE)))

#define IS_CELL_INS(_cellNum)                                                             \
    ((_cellNum < MAX_CELL_NUM_VCCB) && (CELLINFO[_cellNum].gnbNum < MAX_GNB_PER_SYS) &&   \
        (CELLINFO[_cellNum].status == EQUIP) && (CELLINFO[_cellNum].pldState == EQUIP) && \
        (CELLINFO[_cellNum].serviceState == CELL_INS) &&                                  \
        (GNBINFO[CELLINFO[_cellNum].gnbNum].pldActivationState == EQUIP))

#define IS_VALID_CELLS_TO_MEAS_CELL_INDEX(__index) \
    (__index <=                                    \
        MAX_EUTRA_OF_CELLS_TO_MEASURE)  // valid range (1~32)
                                        // ptCi->measurementsConfiguration.measurementObjects.installedItems[].rat.eutra.cellsToMeasureEutra.items[].cellIndexEUTRA
#define IS_VALID_CELLS_TO_MEAS_INTERNAL_INDEX(__index) \
    (__index <                                         \
        MAX_EUTRA_OF_CELLS_TO_MEASURE)  // valid range (0~31)
                                        // ptCi->measurementsConfiguration.measurementObjects.installedItems[].rat.eutra.cellsToMeasureEutra.items[__index]

#define IS_ENDC_SCG_TO_RELEASE(_ptCi)                \
    ((E_CALLTYPE_NSA == _ptCi->callType) &&          \
        ((_ptCi->f1Info.f1UeContextToRemove_flag) || \
            (!GET_F1_RESOURCE_FLAG(_ptCi->flag.setupFlag) && (VCCM_AreAllBearersMcgSnTerm(_ptCi)))))

/*******************  VCCM MACRO *********************************/

#define VCCB_PRINTF_COLOR(color, fmt, args...) VCCB_COMMON_LOG_PRINTF("%s" fmt VCCB_C_RESET, color, ##args)

// Please use VCCB_PRINT instead of the macro below.
#define VCCB_PRINTF_BUF(fmt, args...) VCCB_COMMON_LOG_PRINTF_RE_PRINT(fmt, ##args)

#define LOGFLOW iPRINTF   // USE VCCB_PRINT_MSG macro + alpha?
#define LOGFPRT iPRINTNF  // USE VCCB_PRINT_MSG macro
#define LOGCMD  iPRINTNH  // USE VCCB_PRINT_CMD macro
#define LOGBUF  FnVCCB_BufferPrint

#define MAX_DUS_FILE_SIZE 200000

#define MACRO_BIT_TO_OCTET(__lengthBit) (((__lengthBit) + 7) / 8)

#define MACRO_PACK_OCTET(__ptr, __lengthByte, __value)                                                    \
    do                                                                                                    \
    {                                                                                                     \
        uint32_t byteMaxLen = MIN((__lengthByte), sizeof((__ptr)->value));                                \
        uint32_t byteLoopIdx = 0;                                                                         \
        const uint32_t byteMaxBit = (byteMaxLen - 1) * 8;                                                 \
        unsigned char *packPtr = (unsigned char *)&(__ptr)->value;                                        \
        (__ptr)->length = __lengthByte;                                                                   \
        for (byteLoopIdx = 0; byteLoopIdx < byteMaxLen; byteLoopIdx++)                                    \
        {                                                                                                 \
            packPtr[byteLoopIdx] = (unsigned char)((__value >> (byteMaxBit - (8 * byteLoopIdx))) & 0xFF); \
        }                                                                                                 \
    } while (0)

#define MACRO_PACK_BIT_W_VALUE_PTR(__ptr, __lengthBit, __value_bytes_length, __value)                               \
    do                                                                                                              \
    {                                                                                                               \
        uint32_t byteMaxLen = (uint32_t)MIN((unsigned int)MACRO_BIT_TO_OCTET(__lengthBit), __value_bytes_length);   \
        uint32_t byteLoopIdx = 0;                                                                                   \
        uint16_t remainder = __lengthBit % 8;                                                                       \
        const uint32_t byteMaxBit = (byteMaxLen - 1) * 8;                                                           \
        unsigned char *packPtr = (unsigned char *)(__ptr)->value;                                                   \
        uint64_t tempValue = (uint64_t)__value;                                                                     \
        (__ptr)->length = __lengthBit;                                                                              \
        if (remainder > 0)                                                                                          \
        {                                                                                                           \
            (tempValue) = (uint64_t)(__value) << (8 - remainder);                                                   \
        }                                                                                                           \
        for (byteLoopIdx = 0; byteLoopIdx < byteMaxLen; byteLoopIdx++)                                              \
        {                                                                                                           \
            packPtr[byteLoopIdx] = (tempValue >> (byteMaxBit - (8 * byteLoopIdx))) & 0xFF;                          \
        }                                                                                                           \
    } while (0)

#define MACRO_PACK_BIT(__ptr, __lengthBit, __value) \
    MACRO_PACK_BIT_W_VALUE_PTR(__ptr, __lengthBit, sizeof((__ptr)->value), __value)

#define MACRO_UNPACK_OCTET(__ptr, __value, __bitmask)                                  \
    do                                                                       \
    {                                                                        \
        uint32_t byteMaxLen = MIN((__ptr)->length, sizeof((__ptr)->value));  \
        uint32_t byteLoopIdx = 0;                                            \
        unsigned char *packPtr = (unsigned char *)&(__ptr)->value;           \
        (__value) = 0;                                                       \
        for (byteLoopIdx = 0; byteLoopIdx < byteMaxLen; byteLoopIdx++)       \
        {                                                                    \
            (__value) = (uint32_t)(((__value) << 8) + packPtr[byteLoopIdx]) & __bitmask; \
        }                                                                    \
    } while (0)

#define MACRO_UNPACK_BIT(__ptr, __value)                                                                       \
    do                                                                                                         \
    {                                                                                                          \
        uint32_t byteMaxLen = MIN((unsigned int)MACRO_BIT_TO_OCTET((__ptr)->length), sizeof((__ptr)->value)); \
        uint32_t byteLoopIdx = 0;                                                                              \
        unsigned char *packPtr = (unsigned char *)&(__ptr)->value;                                             \
        (__value) = 0;                                                                                         \
        uint32_t length = (__ptr)->length;                                                                     \
        for (byteLoopIdx = 0; byteLoopIdx < byteMaxLen; byteLoopIdx++)                                         \
        {                                                                                                      \
            (__value) = ((__value) << 8) + packPtr[byteLoopIdx];                                               \
        }                                                                                                      \
        if (length % 8 > 0)                                                                                    \
        {                                                                                                      \
            (__value) = (__value) >> (8 - (length % 8));                                                       \
        }                                                                                                      \
    } while (0)

#define MACRO_UNPACK_BIT_8(__ptr, __value)                                                                     \
    do                                                                                                         \
    {                                                                                                          \
        uint32_t byteMaxLen = MIN((unsigned int)MACRO_BIT_TO_OCTET((__ptr)->length), sizeof((__ptr)->value)); \
        uint32_t byteLoopIdx = 0;                                                                              \
        unsigned char *packPtr = (unsigned char *)&(__ptr)->value;                                             \
        (__value) = 0;                                                                                         \
        uint32_t length = (__ptr)->length;                                                                     \
        for (byteLoopIdx = 0; byteLoopIdx < byteMaxLen; byteLoopIdx++)                                         \
        {                                                                                                      \
            (__value) = (uint8_t)(((__value) << 8) + packPtr[byteLoopIdx]);                                    \
        }                                                                                                      \
        if (length % 8 > 0)                                                                                    \
        {                                                                                                      \
            (__value) = (uint8_t)((__value) >> (8 - (length % 8)));                                            \
        }                                                                                                      \
    } while (0)

#define MACRO_UNPACK_BIT_16(__ptr, __value)                                                                    \
    do                                                                                                         \
    {                                                                                                          \
        uint32_t byteMaxLen = MIN((unsigned int)MACRO_BIT_TO_OCTET((__ptr)->length), sizeof((__ptr)->value)); \
        uint32_t byteLoopIdx = 0;                                                                              \
        unsigned char *packPtr = (unsigned char *)&(__ptr)->value;                                             \
        (__value) = 0;                                                                                         \
        uint32_t length = (__ptr)->length;                                                                     \
        for (byteLoopIdx = 0; byteLoopIdx < byteMaxLen; byteLoopIdx++)                                         \
        {                                                                                                      \
            (__value) = (uint16_t)(((__value) << 8) + packPtr[byteLoopIdx]);                                   \
        }                                                                                                      \
        if (length % 8 > 0)                                                                                    \
        {                                                                                                      \
            (__value) = (uint16_t)((__value) >> (8 - (length % 8)));                                           \
        }                                                                                                      \
    } while (0)

#define MACRO_UNPACK_BIT_SINGLE_BYTE(__ptr, __value)                         \
    do                                                                       \
    {                                                                        \
        (__value) = (__ptr)->value;                                          \
        if ((__ptr)->length % 8 > 0)                                         \
        {                                                                    \
            (__value) = (uint8_t)((__value) >> (8 - ((__ptr)->length % 8))); \
        }                                                                    \
    } while (0)

#define PRINT_NG1_OUTGOING_ON_SCREEN(__msgName, __ptPack, __length)  \
    do                                                               \
    {                                                                \
        if (DBG->flag.flog_msgScreen)                                \
        {                                                            \
            LOG_NG1_PrintOutgoingMsg(__msgName, __ptPack, __length); \
        }                                                            \
    } while (0)

#define PRINT_NG1_INCOMING_ON_SCREEN(__msgName, __threadId)  \
    do                                                       \
    {                                                        \
        if (DBG->flag.flog_msgScreen)                        \
        {                                                    \
            LOG_NG1_PrintIncomingMsg(__msgName, __threadId); \
        }                                                    \
    } while (0)

#define PRINT_NGRRC_INCOMING_XCCCH_ON_SCREEN(__msgName, __message, c1Choice) \
    do                                                                       \
    {                                                                        \
        if (DBG->flag.flog_msgScreen)                                        \
        {                                                                    \
            PrintNGRRC_Incoming_xCCCH_Msg(__msgName, __message, c1Choice);   \
        }                                                                    \
    } while (0)

#define PRINT_NGRRC_OUTGOING_XCCCH_ON_SCREEN(__msgName, __message, c1Choice) \
    do                                                                       \
    {                                                                        \
        if (DBG->flag.flog_msgScreen)                                        \
        {                                                                    \
            PrintNGRRC_Outgoing_xCCCH_Msg(__msgName, __message, c1Choice);   \
        }                                                                    \
    } while (0)

#define PRINT_NGRRC_INCOMING_XDCCH_ON_SCREEN(__msgName, __message, c1Choice) \
    do                                                                       \
    {                                                                        \
        if (DBG->flag.flog_msgScreen)                                        \
        {                                                                    \
            PrintNGRRC_Incoming_xDCCH_Msg(__msgName, __message, c1Choice);   \
        }                                                                    \
    } while (0)

#define PRINT_NGRRC_OUTGOING_XDCCH_ON_SCREEN(__msgName, __message, c1Choice) \
    do                                                                       \
    {                                                                        \
        if (DBG->flag.flog_msgScreen)                                        \
        {                                                                    \
            PrintNGRRC_Outgoing_xDCCH_Msg(__msgName, __message, c1Choice);   \
        }                                                                    \
    } while (0)

#define PRINT_NGRRC_OUTGOING_XDCCH_SEC_ON_SCREEN(__msgName, __message, c1Choice) \
    do                                                                           \
    {                                                                            \
        if (DBG->flag.flog_msgScreen)                                            \
        {                                                                        \
            PrintNGRRC_Outgoing_xDCCH_Sec_Msg(__msgName, __message, c1Choice);   \
        }                                                                        \
    } while (0)

#define RENEW_KEEPALIVE_TIMER(__timerId)                                                                          \
    {                                                                                                             \
        VCCB_CLEAR_TIMER(&ENV->keepAliveInfo.keepAliveTimer, CANCEL_TIMER);                                       \
        ENV->keepAliveInfo.keepAliveTimer.retryCnt = MAX_KEEPALIVE_RETRY_COUNT;                                   \
        VLIB_AttachTimerCore(&ENV->keepAliveInfo.keepAliveTimer, 0, __timerId, 0, 0, VLIB_GetTimerVal(__timerId), \
            VCCB_ADDR.MdsPort, 1, 0);                                                                             \
    }

#define VIIL_BEARER_SVC_CHECK(_bearerSvc, _ptCi)                                           \
    {                                                                                      \
        int16_t _transactionId = 0;                                                        \
        uint32_t _srb, _xrab;                                                              \
        uint32_t _srbCnt = 0;                                                              \
        uint32_t _xrabCnt = 0;                                                             \
        if (_bearerSvc == SIGNALING)                                                       \
        {                                                                                  \
            for (_srb = 0; _srb < MAX_SRB_PER_CALL; _srb++)                                \
            {                                                                              \
                if (!IS_VALID_NODE(SRB_NODE, _ptCi, &(_ptCi->srbInfo[_srb]))) continue;    \
                _srbCnt++;                                                                 \
            }                                                                              \
        }                                                                                  \
        else                                                                               \
        {                                                                                  \
            for (_xrab = 0; _xrab < MAX_XRAB_PER_CALL; _xrab++)                            \
            {                                                                              \
                if (!IS_VALID_NODE(XRAB_NODE, _ptCi, &(_ptCi->xrabInfo[_xrab]))) continue; \
                _xrabCnt++;                                                                \
            }                                                                              \
        }                                                                                  \
        if (!_srbCnt && !_xrabCnt)                                                         \
        {                                                                                  \
            return ERROR;                                                                  \
        }                                                                                  \
    }

// YANG PATH
#define CDB_PATH_MANAGED_ELEM "/managed-element"
#define CDB_PATH_CU_CP_FUNC   CDB_PATH_MANAGED_ELEM "/gnb-cu-cp-function"
#define CDB_PATH_CU_CP_FUNC_ENTRIES \
    CALL_CU_CDB_PATH_CP_FUNCTION_ENTRIES /*CDB_PATH_CU_CP_FUNC "/gnb-cu-cp-function-entries"*/
#define CDB_PATH_CU_CP_FUNC_ENTRY_HKEYPATH_POSITION (4)

#define CDB_PATH_NEIGHBOR_GNB_ENTRIES CDB_PATH_CU_CP_FUNC_ENTRIES "/neighbor-gnb/neighbor-gnb-entries"
#define CDB_PATH_NEIGHBOR_GNB_ENTRIES_WITH_KEY                      \
    CDB_PATH_CU_CP_FUNC_ENTRIES                                     \
    "[%d]/neighbor-gnb/neighbor-gnb-entries{%s}/neighbor-gnb-cell/" \
    "neighbor-gnb-cell-entries"
#define CDB_PATH_NEIGHBOR_GNB_CELL_ENTRIES CDB_PATH_NEIGHBOR_GNB_ENTRIES "/neighbor-gnb-cell/neighbor-gnb-cell-entries"

#define CDB_PATH_NEIGHBOR_ENB_ENTRIES CDB_PATH_CU_CP_FUNC_ENTRIES "/neighbor-enb/neighbor-enb-entries"
#define CDB_PATH_NEIGHBOR_ENB_ENTRIES_WITH_KEY                      \
    CDB_PATH_CU_CP_FUNC_ENTRIES                                     \
    "[%d]/neighbor-enb/neighbor-enb-entries{%s}/neighbor-enb-cell/" \
    "neighbor-enb-cell-entries"
#define CDB_PATH_NEIGHBOR_ENB_CELL_ENTRIES CDB_PATH_NEIGHBOR_ENB_ENTRIES "/neighbor-enb-cell/neighbor-enb-cell-entries"

#define CDB_PATH_SERVICE_GROUP_ID_ENTRIES \
    CDB_PATH_CU_CP_FUNC_ENTRIES "/mobility-config-gnb/service-group-config/service-group-id-entries"
#define CDB_PATH_SERVICE_GROUP_ID_ENTRIES_WITH_KEY \
    CDB_PATH_CU_CP_FUNC_ENTRIES                    \
    "[%d]/mobility-config-gnb/service-group-config/service-group-id-entries{%d}"

#define CDB_PATH_SA_INACTIVITY \
    CDB_PATH_CU_CP_FUNC_ENTRIES "/inactivity-data-sa"
#define CDB_PATH_SA_INACTIVITY_WITH_KEY \
    CDB_PATH_CU_CP_FUNC_ENTRIES "[%d]/inactivity-data-sa"

#define CDB_PATH_SA_INACTIVITY_PROFILE_ENTRIES \
    CDB_PATH_SA_INACTIVITY "/sa-data-inactivity-per-cell-profile-entries"
#define CDB_PATH_SA_INACTIVITY_PROFILE_ENTRIES_WITH_KEY    \
    CDB_PATH_SA_INACTIVITY_WITH_KEY "/sa-data-inactivity-per-cell-profile-entries{%d}"

#define CDB_PATH_SA_INACTIVITY_REDCAP \
    CDB_PATH_CU_CP_FUNC_ENTRIES "/inactivity-data-sa/inactivity-data-sa-redcap"
#define CDB_PATH_SA_INACTIVITY_REDCAP_WITH_KEY \
    CDB_PATH_CU_CP_FUNC_ENTRIES "[%d]/inactivity-data-sa/inactivity-data-sa-redcap"

#define CDB_PATH_PLMN_RFSP_BASED_CONTROL_ENTRIES_FOR_VONR \
    CDB_PATH_CU_CP_FUNC_ENTRIES "/allow-vonr-with-rfsp-info/plmn-rfsp-based-control-entries-for-vonr"

#define CDB_PATH_PLMN_RFSP_BASED_CONTROL_ENTRIES_FOR_VONR_WITH_KEY \
    CDB_PATH_CU_CP_FUNC_ENTRIES "[%d]/allow-vonr-with-rfsp-info/plmn-rfsp-based-control-entries-for-vonr"

#ifdef __NVGNB__
#define CDB_PATH_DU_FUNC CDB_PATH_MANAGED_ELEM "/gnb-du-function"
#endif

// Neighbor

// nbrGnbCell
#define VCCB_GET_INTRA_GNB_NBR_CELLNUM_FROM_CELL_IDENTITY(_pGnbInfo, _cellIdentity, _intraGnbCellNum, _maxCellNumVccb) \
    do \
    { \
        _intraGnbCellNum = _maxCellNumVccb; \
        if (MAX_CELL_IDENTITY > _cellIdentity) \
        { \
            if (_maxCellNumVccb > _pGnbInfo->env.cellNum[_cellIdentity]) \
            { \
                _intraGnbCellNum = _pGnbInfo->env.cellNum[_cellIdentity]; \
            } \
        } \
    } while (0)

#define VCCB_IS_INTRA_GNB_NEIGHBOR_FOR_CELL_NBR(_pGnbInfo, _pCellNbr) \
    (_pCellNbr->targetGnbId.gnbId.id == _pGnbInfo->globalGnbId.gnbId.id && \
        _pCellNbr->targetGnbId.plmn.longId == _pGnbInfo->globalGnbId.plmn.longId)

#define VCCB_IS_INTRA_GNB_NEIGHBOR(_cellNum, _nbrIdx)                  \
    (CELLINFO[_cellNum].Nbr[_nbrIdx].targetGnbId.gnbId.id ==           \
            GNBINFO[CELLINFO[_cellNum].gnbNum].globalGnbId.gnbId.id && \
        CELLINFO[_cellNum].Nbr[_nbrIdx].targetGnbId.plmn.longId ==     \
            GNBINFO[CELLINFO[_cellNum].gnbNum].globalGnbId.plmn.longId)

#define VCCB_IS_INTER_GNB_NEIGHBOR(_cellNum, _nbrIdx) (!VCCB_IS_INTRA_GNB_NEIGHBOR(_cellNum, _nbrIdx))

#define VCCB_GET_INTRA_GNB_NBR_CELLNUM(_cellNum, _nbrIdx, _intraGnbCellNum)      \
    do                                                                           \
    {                                                                            \
        _intraGnbCellNum = MAX_CELL_NUM_VCCB;                                    \
        uint16_t _gnbNum = CELLINFO[_cellNum].gnbNum;                            \
        uint16_t _cellIdentity = CELLINFO[_cellNum].Nbr[_nbrIdx].targetCellId;   \
        if (MAX_CELL_IDENTITY > _cellIdentity)                                   \
        {                                                                        \
            if (MAX_CELL_NUM_VCCB > GNBINFO[_gnbNum].env.cellNum[_cellIdentity]) \
            {                                                                    \
                _intraGnbCellNum = GNBINFO[_gnbNum].env.cellNum[_cellIdentity];  \
            }                                                                    \
        }                                                                        \
    } while (0)
#define VCCB_IS_INTER_FREQ_SSB_FREQ(_cellNum, _ssbFreq) (CELLINFO[_cellNum].ssbArfcn != _ssbFreq)

#define VCCB_IS_VALID_SA_HO_INTRA_NR_HANDOVER_EVENT(__saHoEventType)                             \
    (__saHoEventType != IntraNrHandover_EventA3 && __saHoEventType != IntraNrHandover_EventA4 && \
        __saHoEventType != IntraNrHandover_EventA5)

#define VCCB_IS_VALID_PSCELL_CHANGE_EVENT(__psCellChangeType)                                    \
    (__psCellChangeType != PSCellChange_EventA3 && __psCellChangeType != PSCellChange_EventA4 && \
        __psCellChangeType != PSCellChange_EventA5)

#define VCCB_IS_VALID_INTRA_NR_HANDOVER_PURPOSE(__reportType, __reportPurpose)             \
    ((__reportType == measReport_A3 && __reportPurpose == a3Purpose_intraNrHandover) ||    \
        (__reportType == measReport_A4 && __reportPurpose == a4Purpose_intraNrHandover) || \
        (__reportType == measReport_A5 && __reportPurpose == a5Purpose_intraNrHandover))

#define VCCB_IS_VALID_PSCELL_CHANGE_PURPOSE(__reportType, __reportPurpose)                    \
    ((__reportType == measReport_A3 && __reportPurpose == a3Purpose_nrdcNrPSCellChange) ||    \
        (__reportType == measReport_A4 && __reportPurpose == a4Purpose_nrdcNrPSCellChange) || \
        (__reportType == measReport_A5 && __reportPurpose == a5Purpose_nrdcNrPSCellChange))

#define VCCB_GET_SA_HO_REPORT_TYPE_AND_PURPOSE(__saHoEventType, __reportType, __reportPurpose) \
    if (IntraNrHandover_EventA3 == __saHoEventType)                                            \
    {                                                                                          \
        __reportType = measReport_A3;                                                          \
        __reportPurpose = a3Purpose_intraNrHandover;                                           \
    }                                                                                          \
    else if (IntraNrHandover_EventA5 == __saHoEventType)                                       \
    {                                                                                          \
        __reportType = measReport_A5;                                                          \
        __reportPurpose = a5Purpose_intraNrHandover;                                           \
    }                                                                                          \
    else if (IntraNrHandover_EventA4 == __saHoEventType)                                       \
    {                                                                                          \
        __reportType = measReport_A4;                                                          \
        __reportPurpose = a4Purpose_intraNrHandover;                                           \
    }

#define VCCB_GET_NRDC_SN_HO_REPORT_TYPE_AND_PURPOSE(__saHoEventType, __reportType, __reportPurpose) \
    if (PSCellChange_EventA3 == __saHoEventType)                                                    \
    {                                                                                               \
        __reportType = measReport_A3;                                                               \
        __reportPurpose = a3Purpose_nrdcNrPSCellChange;                                             \
    }                                                                                               \
    else if (PSCellChange_EventA5 == __saHoEventType)                                               \
    {                                                                                               \
        __reportType = measReport_A5;                                                               \
        __reportPurpose = a5Purpose_nrdcNrPSCellChange;                                             \
    }                                                                                               \
    else if (PSCellChange_EventA4 == __saHoEventType)                                               \
    {                                                                                               \
        __reportType = measReport_A4;                                                               \
        __reportPurpose = a4Purpose_nrdcNrPSCellChange;                                             \
    }

#define VCCB_IS_VALID_PCELL_PRIOR_HO_INTRA_NR_HANDOVER_EVENT(__saHoEventType) \
    (__saHoEventType != pcellFreqPriorityHandover_EventA4 && __saHoEventType != pcellFreqPriorityHandover_EventA5)

#define VCCB_GET_PCELL_PRIOR_HO_REPORT_TYPE_AND_PURPOSE(__pcellPriorHoEventType, __reportType, __reportPurpose) \
    if (pcellFreqPriorityHandover_EventA4 == __pcellPriorHoEventType)                                           \
    {                                                                                                           \
        __reportType = measReport_A4;                                                                           \
        __reportPurpose = a4Purpose_PcellPriorHandover;                                                         \
    }                                                                                                           \
    else if (pcellFreqPriorityHandover_EventA5 == __pcellPriorHoEventType)                                      \
    {                                                                                                           \
        __reportType = measReport_A5;                                                                           \
        __reportPurpose = a5Purpose_PcellPriorHandover;                                                         \
    }

#define VCCB_GET_ANR_MNS_PURPOSE(__reportType, __reportPurpose) \
    if (measReport_A3 == __reportType)                          \
    {                                                           \
        __reportPurpose = a3Purpose_AnrMns;                     \
    }                                                           \
    else if (measReport_A5 == __reportType)                     \
    {                                                           \
        __reportPurpose = a5Purpose_AnrMns;                     \
    }                                                           \
    else if (measReport_A4 == __reportType)                     \
    {                                                           \
        __reportPurpose = a4Purpose_AnrMns;                     \
    }

#define VCCB_GET_STR_SA_HO_REPORT(__reportType) \
    (__reportType == measReport_A3              \
            ? "3"                               \
            : (__reportType == measReport_A4 ? "4" : (__reportType == measReport_A5 ? "5" : "unknwon")))

#define VCCB_IS_VALID_SA_HO_INTER_RAT_HANDOVER_EVENT(__saIRATHoEventType) \
    (__saIRATHoEventType != InterRatHandover_EventB1 && __saIRATHoEventType != InterRatHandover_EventB2)

#define VCCB_GET_IRAT_HO_REPORT_TYPE_AND_PURPOSE(__ptCi, __iratHoEventType, __reportType, __reportPurpose) \
    if (InterRatHandover_EventB1 == __iratHoEventType)                                                     \
    {                                                                                                      \
        __reportType = measReport_B1Eutra;                                                                 \
        if (IS_EMERGENCY_FALLBACK_CASE(__ptCi))                                                            \
            __reportPurpose = b1Purpose_saEmergencyFallbackHandover;                                       \
        else if (IS_EPS_FALLBACK_CASE(__ptCi))                                                             \
            __reportPurpose = b1Purpose_saEpsFallbackHandover;                                             \
        else if (IS_RFSP_BLIND_INTER_RAT_REDIRECTION(__ptCi))                                              \
            __reportPurpose = b1Purpose_iratRedirectionForAccessControl;                                   \
        else                                                                                               \
            __reportPurpose = b1Purpose_eutraHandover;                                                     \
    }                                                                                                      \
    else if (InterRatHandover_EventB2 == __iratHoEventType)                                                \
    {                                                                                                      \
        __reportType = measReport_B2Eutra;                                                                 \
        if (IS_EMERGENCY_FALLBACK_CASE(__ptCi))                                                            \
            __reportPurpose = b2Purpose_saEmergencyFallbackHandover;                                       \
        else if (IS_EPS_FALLBACK_CASE(__ptCi))                                                             \
            __reportPurpose = b2Purpose_saEpsFallbackHandover;                                             \
        else                                                                                               \
            __reportPurpose = b2Purpose_eutraHandover;                                                     \
    }

#define VCCB_GET_IRAT_HO_EVENT_TYPE_FROM_YANG(__ptCi, __ptMOBase, __iratEventOnYang)   \
    if (IS_EMERGENCY_FALLBACK_CASE(__ptCi))                                                      \
    {                                                                                            \
        if(__ptMOBase->emergencyFallbackHandoverEvent == FallbackHandover_UsingInterRatHoEvent)  \
            __iratEventOnYang = __ptMOBase->interRatHandoverEvent;                               \
        else                                                                                     \
            __iratEventOnYang = (enumInterRatHandoverEventType)__ptMOBase->emergencyFallbackHandoverEvent;  \
    }                                                                                            \
    else if (IS_EPS_FALLBACK_CASE(__ptCi))                                                       \
    {                                                                                            \
        if(__ptMOBase->epsFallbackHandoverEvent == FallbackHandover_UsingInterRatHoEvent)        \
            __iratEventOnYang = __ptMOBase->interRatHandoverEvent;                               \
        else                                                                                     \
            __iratEventOnYang = (enumInterRatHandoverEventType)__ptMOBase->epsFallbackHandoverEvent;        \
    }                                                                                            \
    else if (IS_RFSP_BLIND_INTER_RAT_REDIRECTION(__ptCi))                                        \
    {                                                                                            \
        __iratEventOnYang = InterRatHandover_EventB1;                                            \
    }                                                                                            \
    else                                                                                         \
    {                                                                                            \
        __iratEventOnYang = __ptMOBase->interRatHandoverEvent;                                   \
    }

#define VCCB_IS_VALID_IRAT_HANDOVER_PURPOSE_FOR_ANR(__reportType, __reportPurpose)                          \
    ((__reportType == measReport_B1Eutra && __reportPurpose == b1Purpose_eutraHandover) ||                  \
        (__reportType == measReport_B1Eutra && __reportPurpose == b1Purpose_eutraRfspHandover ) ||          \
        (__reportType == measReport_B1Eutra && __reportPurpose == b1Purpose_trafficBasedHandover) ||        \
        (__reportType == measReport_B1Eutra && __reportPurpose == b1Purpose_loadBalancingIratHandover) ||   \
        (__reportType == measReport_B1Eutra && __reportPurpose == b1Purpose_saEpsFallbackHandover) ||       \
        (__reportType == measReport_B2Eutra && __reportPurpose == b2Purpose_eutraHandover) ||               \
        (__reportType == measReport_B2Eutra && __reportPurpose == b2Purpose_eutraOnDemandHandover) ||       \
        (__reportType == measReport_B2Eutra && __reportPurpose == b2Purpose_trafficBasedHandover) ||        \
        (__reportType == measReport_B2Eutra && __reportPurpose == b2Purpose_loadBalancingIratHandover ) ||  \
        (__reportType == measReport_B2Eutra && __reportPurpose == b2Purpose_saEpsFallbackHandover))

#define VCCB_IS_NOT_VALID_SA_HO_TRAFFIC_BASED_HANDOVER_EVENT(__trafficBasedHoEventType) \
    (__trafficBasedHoEventType != trafficBasedHandover_EventB1 &&                   \
        __trafficBasedHoEventType != trafficBasedHandover_EventB2)

#define VCCB_GET_TRAFFIC_BASED_HO_REPORT_TYPE_AND_PURPOSE(          \
    __ptCi, __trfBasedHoEventType, __reportType, __reportPurpose)   \
    if (trafficBasedHandover_EventB1 == __trfBasedHoEventType)      \
    {                                                               \
        __reportType = measReport_B1Eutra;                          \
        __reportPurpose = b1Purpose_trafficBasedHandover;           \
    }                                                               \
    else if (trafficBasedHandover_EventB2 == __trfBasedHoEventType) \
    {                                                               \
        __reportType = measReport_B2Eutra;                          \
        __reportPurpose = b2Purpose_trafficBasedHandover;           \
    }

// YANG SESSION
#define VCCB_CDB_WAIT_TIME            100  // ms
#define VCCB_CDB_WAIT_TIME_TO_SEC_CNT (2000 / VCCB_CDB_WAIT_TIME)
#define VCCB_YANG_READ_TIME_THRESHOLD 200  //(200ms)

#define VCCB_SET_GNB_NBR_READ_GNB_NUM(_gnbNum)                                                        \
    do                                                                                                \
    {                                                                                                 \
        if (DBG->flag.nbrYangRead)                                                                    \
        {                                                                                             \
            VCCB_PRINTF("set GNB_NBR_READ_GNB_NUM(%d->%d)\n", CFG->confd.gnbNbr.readGnbNum, _gnbNum); \
        }                                                                                             \
        (CFG->confd.gnbNbr.readGnbNum = _gnbNum);                                                     \
    } while (0)

#define VCCB_SET_GNB_NBR_READ_IDX(_readIdx)                                                     \
    do                                                                                          \
    {                                                                                           \
        if (DBG->flag.nbrYangRead)                                                              \
        {                                                                                       \
            VCCB_PRINTF("set GNB_NBR_READ_IDX(%d->%d)\n", CFG->confd.gnbNbr.readIdx, _readIdx); \
        }                                                                                       \
        (CFG->confd.gnbNbr.readIdx = _readIdx);                                                 \
    } while (0)

#define VCCB_SET_CELL_NBR_READ_GNB_NUM(_gnbNum)                                                         \
    do                                                                                                  \
    {                                                                                                   \
        if (DBG->flag.nbrYangRead)                                                                      \
        {                                                                                               \
            VCCB_PRINTF("set CELL_NBR_READ_GNB_NUM(%d->%d)\n", CFG->confd.cellNbr.readGnbNum, _gnbNum); \
        }                                                                                               \
        (CFG->confd.cellNbr.readGnbNum = _gnbNum);                                                      \
    } while (0)

#define VCCB_SET_CELL_NBR_READ_IDX(_readIdx)                                                      \
    do                                                                                            \
    {                                                                                             \
        if (DBG->flag.nbrYangRead)                                                                \
        {                                                                                         \
            VCCB_PRINTF("set CELL_NBR_READ_IDX(%d->%d)\n", CFG->confd.cellNbr.readIdx, _readIdx); \
        }                                                                                         \
        (CFG->confd.cellNbr.readIdx = _readIdx);                                                  \
    } while (0)

#define VCCB_SET_ENB_NBR_READ_GNB_NUM(_gnbNum)                                                        \
    do                                                                                                \
    {                                                                                                 \
        if (DBG->flag.nbrYangRead)                                                                    \
        {                                                                                             \
            VCCB_PRINTF("set ENB_NBR_READ_GNB_NUM(%d->%d)\n", CFG->confd.enbNbr.readGnbNum, _gnbNum); \
        }                                                                                             \
        (CFG->confd.enbNbr.readGnbNum = _gnbNum);                                                     \
    } while (0)

#define VCCB_SET_ENB_NBR_READ_IDX(_readIdx)                                                     \
    do                                                                                          \
    {                                                                                           \
        if (DBG->flag.nbrYangRead)                                                              \
        {                                                                                       \
            VCCB_PRINTF("set ENB_NBR_READ_IDX(%d->%d)\n", CFG->confd.enbNbr.readIdx, _readIdx); \
        }                                                                                       \
        (CFG->confd.enbNbr.readIdx = _readIdx);                                                 \
    } while (0)

#define VCCB_SET_CELL_EUTRA_NBR_READ_GNB_NUM(_gnbNum)                                                         \
    do                                                                                                        \
    {                                                                                                         \
        if (DBG->flag.nbrYangRead)                                                                            \
        {                                                                                                     \
            VCCB_PRINTF("set EUTRA_NBR_READ_GNB_NUM(%d->%d)\n", CFG->confd.cellEutraNbr.readGnbNum, _gnbNum); \
        }                                                                                                     \
        (CFG->confd.cellEutraNbr.readGnbNum = _gnbNum);                                                       \
    } while (0)

#define VCCB_SET_CELL_EUTRA_NBR_READ_IDX(_readIdx)                                                      \
    do                                                                                                  \
    {                                                                                                   \
        if (DBG->flag.nbrYangRead)                                                                      \
        {                                                                                               \
            VCCB_PRINTF("set EUTRA_NBR_READ_IDX(%d->%d)\n", CFG->confd.cellEutraNbr.readIdx, _readIdx); \
        }                                                                                               \
        (CFG->confd.cellEutraNbr.readIdx = _readIdx);                                                   \
    } while (0)

#define VCCB_READ_NBR_FOR_NEW_GNB(_gnbNum, _startNum, _max_num)                                                  \
    do                                                                                                           \
    {                                                                                                            \
        _startNum = _gnbNum;                                                                                     \
        _max_num = (uint32_t)(_startNum + 1);                                                                    \
        CFG->confd.gnbNbr.readGnbNum = _startNum;                                                                \
        CFG->confd.cellNbr.readGnbNum = _startNum;                                                               \
        CFG->confd.enbNbr.readGnbNum = _startNum;                                                                \
        CFG->confd.cellEutraNbr.readGnbNum = _startNum;                                                          \
        CFG->confd.gnbNbr.readIdx = 0;                                                                           \
        CFG->confd.cellNbr.readIdx = 0;                                                                          \
        CFG->confd.enbNbr.readIdx = 0;                                                                           \
        CFG->confd.cellEutraNbr.readIdx = 0;                                                                     \
        CFG->confd.gnbNbr.numOfInstance = (uint32_t)MAX_NBR_GNB_CELL_PER_GNB;                                    \
        CFG->confd.enbNbr.numOfInstance = (uint32_t)MAX_NBR_ENB_CELL_PER_GNB;                                    \
        VCCB_PRINTF("[DAL] vccb will read nbr Data nbrGnbNum = %d/%d, startGnbNum = %d, max_nbrGnbNum = %d  \n", \
            CFG->confd.gnbNbr.readGnbNum, CFG->confd.cellNbr.readGnbNum, _startNum, _max_num);                   \
    } while (0)

// SESSION MANAGEMENT FOR NBR YANG READ at subscribe task
#define VCCB_DAL_DB_CONNECT_SESSION(_socket, _result)                                 \
    {                                                                                 \
        _result = dal_db_connect(&_socket, DAL_DB_DATA_SOCKET);                       \
        if (DAL_SUCCESS != _result)                                                   \
        {                                                                             \
            VCCB_PRINTF("%s: dal_db_connect Failed(%d)\n", __FUNCTION__, _result);    \
            FnVCCB_DalWrapper_dal_db_close(&_socket, __func__);                       \
            /*return ERROR;     don't return, because this thread is subscribe task */\
        }                                                                             \
    }

#define VCCB_DAL_DB_START_SESSION(_socket, _dbType, _lockType, _result)                  \
    {                                                                                    \
        _result = dal_db_start_session(_socket, _dbType, _lockType);                     \
        if (DAL_SUCCESS != _result)                                                      \
        {                                                                                \
            VCCB_PRINTF("%s: dal_db_start_session Failed(%d)\n", __FUNCTION__, _result); \
            FnVCCB_DalWrapper_dal_db_close(&_socket, __func__);                          \
            /*return ERROR;     don't return, because this thread is subscribe task */   \
        }                                                                                \
    }

#define VCCB_DAL_DB_SET_NAMESPACE(_socket, _result)                                      \
    {                                                                                    \
        _result = dal_db_set_namespace(_socket, VCCB_YANG_NS);                           \
        if (DAL_SUCCESS != _result)                                                      \
        {                                                                                \
            VCCB_PRINTF("%s: dal_db_set_namespace Failed(%d)\n", __FUNCTION__, _result); \
            if (DAL_SUCCESS != dal_db_end_session(_socket))                              \
                VCCB_PRINTF("%s: dal_db_end_session Failed\n", __FUNCTION__);            \
            FnVCCB_DalWrapper_dal_db_close(&_socket, __func__);                          \
            /*return ERROR;     don't return, because this thread is subscribe task */   \
        }                                                                                \
    }

#define VCCB_DAL_DB_END_SESSION(_socket, _result)                                       \
    {                                                                                   \
        _result = dal_db_end_session(_socket);                                          \
        if (DAL_SUCCESS != _result)                                                     \
        {                                                                               \
            VCCB_PRINTF("[DAL] dal_db_end_session failed\n");                           \
            FnVCCB_DalWrapper_dal_db_close(&_socket, __func__);                         \
            /*return ERROR;    don't return, because this thread is subscribe task   \*/\
        }                                                                               \
    }

// STAT macro
// temp
#define MACRO_CALL_STAT(i, j, k)         {};
#define MACRO_CALL_ETC_STAT(i, j, k)     {};
#define MACRO_HO_STAT(i, j)              {};
#define MACRO_CSFB_STAT(i, j)            {};
#define MACRO_PAGING_STAT(i)             {};
#define MACRO_MRO_AT_SETUP_STAT(i, j, k) {};
#define MACRO_RO_STAT(i, j)              {};
#define MACRO_ANR_STAT(i, j)             {};
#define MACRO_UNKNOWN_PCI_STAT(i)        {};

#define IS_SA_CELL_FOR_STAT(_pCell)                         \
    ((_pCell->pldState == EQUIP) && (_pCell->tacStatus == 1) && (_pCell->configuredTacIndication == 0))
#define MACRO_IS_CALL_FAULT_UE(__call)                   ((__call)->cause.callFault.callFaultCause != CAUSE_NO_FAULT)
#define MACRO_CALL_FAULT_SAVE(msgId, cause)              VLIB_CallFaultSave(ptCi, msgId, cause, __FUNCTION__);
#define MACRO_CALL_FAULT_SAVE_REF(_call, _msgId, _cause) VLIB_CallFaultSave(&_call, _msgId, _cause, __FUNCTION__);
#define MACRO_RESET_CALL_FAULT_CAUSES                    VLIB_CallFaultSave(ptCi, 0xFFFFFFFF, CAUSE_NO_FAULT, __FUNCTION__);
#define MACRO_CALL_DROP_STAT()              {};
#define MACRO_MR_STAT(i, j)                 {};
#define MACRO_DISPLAY_HO_INFO()             {};
#define MACRO_MLB_REDIR_STAT(i)             {};
#define MACRO_IRAT_MR_STAT(i, j)            {};
#define MACRO_PREEMPT_HO_STAT()             {};
#define IS_COVERAGE_HOLE                    {};
#define IS_MULTI_PREPARATION                {};
#define MACRO_CA_RECONF_STAT(i, j)          {};
#define MACRO_IRAT_MRO_STAT(i, j, k)        {};
#define MACRO_CCO_STAT(i, j, k, l)          {};
#define MACRO_SCELL_ADD_REL_STAT(i, j)      {};
#define MACRO_UTRAN_MRO_STAT(i, j, k)       {};
#define MACRO_GET_INTERFACE_CAUSE(_ptCi, _cause)                                                   \
    GetInterfaceCause(_cause, &_ptCi->cause.f1Cause, &_ptCi->cause.e1Cause, &_ptCi->cause.x2Cause, \
        &_ptCi->cause.ngCause, &_ptCi->cause.xnCause);

#define MACRO_CSL_STAT(_ptCi, i, j) VLIB_LibStatCSLInfo(ptCi, i, j);

#define VCCB_MRDC_SN_REL_SN_STAT(_mType, _ptCi) \
    do \
    { \
        MACRO_STAT_PMCC(STAT_NRDC_SN_REL_SN, _mType, _ptCi, 0, 0, 0, 0, 0); \
        MACRO_STAT_PMCC(STAT_NRDC_SN_REL_SN_PCELL_NCI, _mType, _ptCi, 0, 0, 0, 0, 0); \
    } while (0)

#define MACRO_STAT_PMCC(_mFam, _mType, _ptCi, a, b, c, d, e) \
    VLIB_LibStatPmCC(_mFam, _mType, _ptCi, a, b, c, d, e, __FUNCTION__);
#define MACRO_STAT_PMCC_VALUE(_mFam, _mType, _ptCi, a, b, c, d, e, _val) \
    VLIB_LibStatPmCC_Value(_mFam, _mType, _ptCi, a, b, c, d, e, _val);
#define MACRO_STAT_PMCC_NAME(_mFam, _mType, _ptCi, a, b, c, d, e, _FuncName) \
    VLIB_LibStatPmCC(_mFam, _mType, _ptCi, a, b, c, d, e, _FuncName);
#define MACRO_STAT_PMCC_MSG(_mFam, _mType, _gnbIdOrNum, _endPointIdx) \
    VLIB_LibStatPmCC_MSG(_mFam, _mType, _gnbIdOrNum, _endPointIdx);
#define MACRO_STAT_PMCC_MSG_PERIODIC(_mFam, _mType, _gnbIdOrNum, _endPointIdx, _threadId) \
    FnVCCB_CollectInterfaceMsgCount(_mFam, _mType, _gnbIdOrNum, _endPointIdx, _threadId);

#define MACRO_STAT_XNAP_MSG_UE_PER_GNB(_mType, direction, _gnbIdOrNum, _endPointIdx)                \
    do                                                                                              \
    {                                                                                               \
        if (direction == RX_MSG)                                                                    \
        {                                                                                           \
            MACRO_STAT_PMCC_MSG(STAT_XNAP_MSG_UE_PER_GNB, Rx_##_mType, gnbIdOrNum, endPointIdx);  \
        }                                                                                           \
        else if (direction == TX_MSG)                                                               \
        {                                                                                           \
            MACRO_STAT_PMCC_MSG(STAT_XNAP_MSG_UE_PER_GNB, Tx_##_mType, gnbIdOrNum, endPointIdx);  \
        }                                                                                           \
    } while (0)

#define MACRO_STAT_PMCC_RETAIN(_mFam, _ptCi, _ptDi, a, b, c, d)                                                             \
    do                                                                                                                      \
    {                                                                                                                       \
        if (_mFam == STAT_VONR_EMERGENCY_RELEASE) /* 23A_NRRetainability */                                                 \
        {                                                                                                                   \
            if (FOO.VF_VONREmergency_Counter)                                                                               \
            {                                                                                                               \
                VLIB_LibStatPmCC_Retain(_mFam, _ptCi, _ptDi, a, b, c, d);                                                   \
            }                                                                                                               \
        }                                                                                                                   \
        else                                                                                                                \
        {                                                                                                                   \
            /* Check SETUP_ACTIVE_DRB_RELEASE */                                                                            \
            if (_mFam == STAT_SETUP_DRB_RELEASE) /* Collect SETUP_ACTIVE_DRB_RELEASE*/                                      \
            {                                                                                                               \
                if (FOO.VF_NRRetainability_ActiveDRBReleaseGlobalID) /* For Only MSO */                                     \
                {                                                                                                           \
                    VLIB_LibStatPmCC_Retain(STAT_SETUP_ACTIVE_DRB_RELEASE_GLOBAL_ID_PLMN, _ptCi, _ptDi, a, b, c, d);        \
                }                                                                                                           \
                else                                                                                                        \
                {                                                                                                           \
                    if (FOO.VF_MultipleOperatorCNSupport) /* For MOCN */                                                    \
                    {                                                                                                       \
                        VLIB_LibStatPmCC_Retain(STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID_PLMN, _ptCi, _ptDi, a, b, c, d);        \
                    }                                                                                                       \
                    if (FOO.VF_NRRetainability_IndexSNSSAI) /* For CAN */                                                   \
                    {                                                                                                       \
                        VLIB_LibStatPmCC_Retain(STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID_PLMN_SNSSAI, _ptCi, _ptDi, a, b, c, d); \
                    }                                                                                                       \
                    VLIB_LibStatPmCC_Retain(STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID, _ptCi, _ptDi, a, b, c, d);                 \
                }                                                                                                           \
                if (FOO.VF_NRRetainability_IndexSNSSAI) /* For CAN */                                                       \
                {                                                                                                           \
                    VLIB_LibStatPmCC_Retain(STAT_SETUP_DRB_RELEASE_DU_ID_PLMN_SNSSAI, _ptCi, _ptDi, a, b, c, d);            \
                }                                                                                                           \
                if (FOO.VF_BasicOperationCounter_PlmnSnssai5QI) /* For JIO */                                               \
                {                                                                                                           \
                    VLIB_LibStatPmCC_Retain(STAT_SETUP_DRB_RELEASE_PLMN_SNSSAI_5QI, _ptCi, _ptDi, a, b, c, d);              \
                    VLIB_LibStatPmCC_Retain(STAT_SETUP_ACTIVE_DRB_RELEASE_PLMN_SNSSAI_5QI, _ptCi, _ptDi, a, b, c, d);       \
                }                                                                                                           \
            }                                                                                                               \
            /* Collect STAT_SETUP_UECONTEXT_RELEASE / STAT_SETUP_DRB_RELEASE */                                             \
            VLIB_LibStatPmCC_Retain(_mFam, _ptCi, _ptDi, a, b, c, d);                                                       \
        }                                                                                                                   \
    } while (0)

#define VCCB_PMKEY_SHIFT(__pPmKey, __shiftIdx)                                  \
    do                                                                          \
    {                                                                           \
        if (__shiftIdx >= VCCB_PMKEY_INDEX1)                                    \
        {                                                                       \
            int32_t _idx;                                                       \
            for (_idx = (MAX_VCCB_STAT_KEY_NUM - 1); _idx > __shiftIdx; _idx--) \
            {                                                                   \
                pPmKey->keyList[_idx] = pPmKey->keyList[_idx - 1];              \
            }                                                                   \
        }                                                                       \
    } while (0)

#define MACRO_STAT_PMCC_QCI(_mFam, _mType, _ptCi, _ptRi, a, b, c, d) \
    VLIB_LibStatPmCC_QCI(_mFam, _mType, _ptCi, _ptRi, a, b, c, d, __FUNCTION__);
#define MACRO_STAT_PMCC_DRB(_mFam, _mType, _ptCi, _ptDi, a, b, c, d) \
    VLIB_LibStatPmCC_DRB(_mFam, _mType, _ptCi, _ptDi, a, b, c, d, __FUNCTION__);
#define MACRO_STAT_PMCC_PDU(_mFam, _mType, _ptCi, _ptPi, a, b, c, d) \
    VLIB_LibStatPmCC_PDU(_mFam, _mType, _ptCi, _ptPi, a, b, c, d, __FUNCTION__);
#define MACRO_STAT_PMCC_QosFlow(_mFam, _mType, _ptCi, _ptPi, _ptQi, a, b, c) \
    VLIB_LibStatPmCC_QosFlow(_mFam, _mType, _ptCi, _ptPi, _ptQi, a, b, c, __FUNCTION__);
#define MACRO_STAT_PMCC_FLOAT(_mFam, _mType, _ptCi, _updateValue, a, b, c, d) \
    VLIB_LibStatPmCC_FLOAT(_mFam, _mType, _ptCi, _updateValue, a, b, c, d);

#define MACRO_STAT_PMGAUGE(_mFam, _mType, _ptCi, _updateValue, a, b, c, d) \
    VLIB_LibStatPmGauge(_mFam, _mType, _ptCi, _updateValue, a, b, c, d);
#define MACRO_STAT_PMSI(_mFam, _mType, _ptCi, _updateValue, a, b, c, d) \
    VLIB_LibStatPmSI(_mFam, _mType, _ptCi, _updateValue, a, b, c, d);
#define MACRO_STAT_PMSI_QCI(_mFam, _mType, _ptCi, _ptRi, _updateValue, a, b, c) \
    FnVCCB_LibStatPmSI_QCI(_mFam, _mType, _ptCi, _ptRi, _updateValue, a, b, c);

#define MACRO_STAT_PMCC_PDU_SETUP_FAMILY_ALL(_mType, _ptCi, _ptPi, a, b, c, d)                            \
    do                                                                                                    \
    {                                                                                                     \
        VLIB_LibStatPmCC_PDU(                                                                             \
            STAT_PDU_SESSION_RESOURCE_SETUP_PLMN_SNSSAI, _mType, _ptCi, _ptPi, a, b, c, d, __FUNCTION__); \
    } while (0)


// Collect DRB Setup Statistics.
// (Collect STAT_DRB_SETUP, STAT_DRB_SETUP_PLMN_SNSSAI always)
// _checkStatType == DRB_SETUP                      ==> Collect STAT_DRB_SETUP, STAT_DRB_SETUP_PLMN_SNSSAI, STAT_DRB_SETUP_GLOBAL_ID_RFSP
// _checkStatType == INITIAL_DRB_SETUP              ==> Collect STAT_DRB_SETUP, STAT_DRB_SETUP_PLMN_SNSSAI, STAT_DRB_SETUP_GLOBAL_ID_RFSP
//                                                              (Init) STAT_INITIAL_DRB_SETUP_DU_ID, STAT_INITIAL_DRB_SETUP_DU_ID_PLMN_SNSSAI
// _checkStatType == DRB_SETUP_IN_PDUSESSION_MODIFY ==> Collect STAT_DRB_SETUP, STAT_DRB_SETUP_PLMN_SNSSAI, STAT_DRB_SETUP_GLOBAL_ID_RFSP
//                                                              (Modify) STAT_PDU_SESSION_RESOURCE_MODIFY_REQUEST_DRB_SETUP
// _checkStatType == MAX_VCCB_DRB_STAT_FAMILY_TYPE  ==> Collect All
//                                                              STAT_DRB_SETUP, STAT_DRB_SETUP_PLMN_SNSSAI, STAT_DRB_SETUP_GLOBAL_ID_RFSP
//                                                              (init)STAT_INITIAL_DRB_SETUP_DU_ID, STAT_INITIAL_DRB_SETUP_DU_ID_PLMN_SNSSAI
//                                                              (Modify)STAT_PDU_SESSION_RESOURCE_MODIFY_REQUEST_DRB_SETUP

#define MACRO_STAT_PMCC_DRB_SETUP_FAMILY_ALL(_mType, _ptCi, _ptDi, a, b, c, d, _checkStatType)                          \
    do                                                                                                                  \
    {                                                                                                                   \
        VLIB_LibStatPmCC_DRB(STAT_DRB_SETUP, _mType, _ptCi, _ptDi, a, b, c, d, __FUNCTION__);                           \
        VLIB_LibStatPmCC_DRB(STAT_DRB_SETUP_PLMN_SNSSAI, _mType, _ptCi, _ptDi, a, b, c, d, __FUNCTION__);               \
        if ((_checkStatType == MAX_VCCB_DRB_STAT_FAMILY_TYPE) || (_checkStatType == INITIAL_DRB_SETUP))                 \
        {                                                                                                               \
            VLIB_LibStatPmCC_DRB(                                                                                       \
                STAT_INITIAL_DRB_SETUP_DU_ID, _mType, _ptCi, _ptDi, a, b, c, d, __FUNCTION__);                          \
            VLIB_LibStatPmCC_DRB(                                                                                       \
                STAT_INITIAL_DRB_SETUP_DU_ID_PLMN_SNSSAI, _mType, _ptCi, _ptDi, a, b, c, d, __FUNCTION__);              \
        }                                                                                                               \
        if (FOO.VF_BasicoperationForSa_ModifyRequest)                                                                   \
        {                                                                                                               \
            if ((_checkStatType == MAX_VCCB_DRB_STAT_FAMILY_TYPE) || (_checkStatType == DRB_SETUP_IN_PDUSESSION_MODIFY))\
            {                                                                                                           \
                VLIB_LibStatPmCC_DRB(                                                                                   \
                STAT_PDU_SESSION_RESOURCE_MODIFY_REQUEST_DRB_SETUP, _mType, _ptCi, _ptDi, a, b, c, d, __FUNCTION__);    \
            }                                                                                                           \
        }                                                                                                               \
        if ((FOO.VF_ServedUEConnectionStatus_InclRFSP) && (FOO.VF_MultipleOperatorRanSupport))                          \
        {                                                                                                               \
            VLIB_LibStatPmCC_DRB(STAT_DRB_SETUP_GLOBAL_ID_RFSP, _mType, _ptCi, _ptDi, a, b, c, d, __FUNCTION__);        \
        }                                                                                                               \
        if (FOO.VF_BasicOperationCounter_PlmnSnssai5QI)                                                                 \
        {                                                                                                               \
            VLIB_LibStatPmCC_DRB(STAT_DRB_SETUP_PLMN_SNSSAI_5QI, _mType, _ptCi, _ptDi, a, b, c, d, __FUNCTION__);       \
        }                                                                                                               \
    } while (0)

#define MACRO_STAT_PMCC_QOS_FLOW_SETUP_FAMILY_ALL(_mType, _ptCi, _ptPi, _ptQi, a, b, c)                                \
    do                                                                                                                 \
    {                                                                                                                  \
        VLIB_LibStatPmCC_QosFlow(STAT_QOS_FLOW_SETUP, _mType, _ptCi, _ptPi, _ptQi, a, b, c, __FUNCTION__);             \
        VLIB_LibStatPmCC_QosFlow(STAT_QOS_FLOW_SETUP_PLMN_SNSSAI, _mType, _ptCi, _ptPi, _ptQi, a, b, c, __FUNCTION__); \
    } while (0)

#define MACRO_STAT_PMCC_DRB_IN_CALL(_ptCi, _mFam, _mType)                            \
    do                                                                               \
    {                                                                                \
        int16_t _loop = 0;                                                           \
        for (_loop = 0; _loop < MAX_DRB_PER_SA_CALL; _loop++)                        \
        {                                                                            \
            if (ptCi->drb[_loop].usage != CI_use) continue;                          \
            MACRO_STAT_PMCC_DRB(_mFam, _mType, ptCi, &ptCi->drb[_loop], 0, 0, 0, 0); \
        }                                                                            \
    } while (0)

#define MACRO_STAT_PMCC_DRB_IN_CALL_FOR_DRB_ERASE(_ptCi, _mFam, _mType)              \
    do                                                                               \
    {                                                                                \
        int16_t _loop = 0, _checkFlag = 0;                                           \
        if( (ptCi->stateCmd == RRCConnection_cmd) ||                                 \
            (ptCi->stateCmd == PDUSetup_cmd     ) ||                                 \
            (ptCi->stateCmd == PDUModify_cmd    ))                                   \
        {                                                                            \
            _checkFlag = VCCB_FLAG_ON;                                               \
        }                                                                            \
        for (_loop = 0; _loop < MAX_DRB_PER_SA_CALL; _loop++)                        \
        {                                                                            \
            if (ptCi->drb[_loop].usage != CI_use) continue;                          \
            /* Check SN Term */                                                      \
            if (VCCB_IS_SN_TERM_DRB_WITH_ONLY_CHECK_BEARER_TYPE(&(ptCi->drb[_loop])))\
                continue;                                                            \
            /* Check Setting Up DRB  */                                              \
            if ((_checkFlag == VCCB_FLAG_ON) &&                                      \
                (ptCi->drb[_loop].firstReqStatusInThisProcedure == S_Setup))         \
            {                                                                        \
                if((ptCi->drb[_loop].drbStatus == S_Setup)       ||                  \
                   (ptCi->drb[_loop].drbStatus == S_Modify)      ||                  \
                   (ptCi->drb[_loop].drbStatus == S_FailToSetup) ||                  \
                   (ptCi->drb[_loop].drbStatus == S_FailToModify))                   \
                {                                                                    \
                    continue;                                                        \
                }                                                                    \
            }                                                                        \
            MACRO_STAT_PMCC_DRB(_mFam, _mType, ptCi, &ptCi->drb[_loop], 0, 0, 0, 0); \
        }                                                                            \
    } while (0)

#define MACRO_STAT_COLLECT_ALL_DRB_SETUP_WITH_CAUSE(_ptCi, _ptDi, _callDrbIdx, _cause)                                      \
    do                                                                                                                      \
    {                                                                                                                       \
        if (_ptDi->drbStatistic.attemptFlag[DRB_SETUP] == ATTEMPT_MADE)                                                     \
        {                                                                                                                   \
            VLIB_DrbSetup_CollectStat_FailedDrbItem(_ptCi, _cause, _callDrbIdx, STAT_DRB_SETUP);                            \
        }                                                                                                                   \
        if (_ptDi->drbStatistic.attemptFlag[DRB_SETUP_PLMN_SNSSAI] == ATTEMPT_MADE)                                         \
        {                                                                                                                   \
            VLIB_DrbSetup_CollectStat_FailedDrbItem(_ptCi, _cause, _callDrbIdx, STAT_DRB_SETUP_PLMN_SNSSAI);                \
        }                                                                                                                   \
        if (_ptDi->drbStatistic.attemptFlag[INITIAL_DRB_SETUP] == ATTEMPT_MADE)                                             \
        {                                                                                                                   \
            VLIB_DrbSetup_CollectStat_FailedDrbItem(_ptCi, _cause, _callDrbIdx, STAT_INITIAL_DRB_SETUP_DU_ID);              \
        }                                                                                                                   \
        if (_ptDi->drbStatistic.attemptFlag[INITIAL_DRB_SETUP_PLMN_SNSSAI] == ATTEMPT_MADE)                                 \
        {                                                                                                                   \
            VLIB_DrbSetup_CollectStat_FailedDrbItem(_ptCi, _cause, _callDrbIdx, STAT_INITIAL_DRB_SETUP_DU_ID_PLMN_SNSSAI);  \
        }                                                                                                                   \
        if (FOO.VF_BasicoperationForSa_ModifyRequest)                                                                       \
        {                                                                                                                   \
            if (_ptDi->drbStatistic.attemptFlag[DRB_SETUP_IN_PDUSESSION_MODIFY] == ATTEMPT_MADE)                            \
            {                                                                                                               \
                VLIB_DrbSetup_CollectStat_FailedDrbItem(                                                                    \
                    _ptCi, _cause, _callDrbIdx, STAT_PDU_SESSION_RESOURCE_MODIFY_REQUEST_DRB_SETUP);                        \
            }                                                                                                               \
        }                                                                                                                   \
        if ((FOO.VF_ServedUEConnectionStatus_InclRFSP) && (FOO.VF_MultipleOperatorRanSupport))                              \
        {                                                                                                                   \
            if (_ptDi->drbStatistic.attemptFlag[DRB_SETUP_GLOBAL_ID_RFSP] == ATTEMPT_MADE)                                  \
            {                                                                                                               \
                VLIB_DrbSetup_CollectStat_FailedDrbItem(                                                                    \
                    _ptCi, _cause, _callDrbIdx, STAT_DRB_SETUP_GLOBAL_ID_RFSP);                                             \
            }                                                                                                               \
        }                                                                                                                   \
        if (FOO.VF_BasicOperationCounter_PlmnSnssai5QI)                                                                     \
        {                                                                                                                   \
            if (_ptDi->drbStatistic.attemptFlag[DRB_SETUP_PLMN_SNSSAI_5QI] == ATTEMPT_MADE)                                 \
            {                                                                                                               \
                VLIB_DrbSetup_CollectStat_FailedDrbItem(                                                                    \
                    _ptCi, _cause, _callDrbIdx, STAT_DRB_SETUP_PLMN_SNSSAI_5QI);                                            \
            }                                                                                                               \
        }                                                                                                                   \
    } while (0)

#define MACRO_F1RLF_CALL_FAULT_SAVE(_msgId, _f1Cause)                                    \
    do                                                                                   \
    {                                                                                    \
        if (_f1Cause == CauseF1apRadioRLFailure)                                         \
        {                                                                                \
            MACRO_CALL_FAULT_SAVE(_msgId, CauseCpInternalDuRlcMaxNumRetx);               \
        }                                                                                \
        else if (_f1Cause == CauseF1apRadioRLFailureothers)                              \
        {                                                                                \
            MACRO_CALL_FAULT_SAVE(_msgId, CauseCpInternalDuULRadioLinkFailure);          \
        }                                                                                \
    } while (0)

#define CHECK_FAMILY_PMCC_ULL(_fam)                                                      \
    ((_fam == STAT_DATA_USAGE_PER_GNB) || (_fam == STAT_DATA_USAGE_PER_GNB_GLOBAL_ID) || \
        (_fam == STAT_DATA_USAGE_PER_GNB_DU_ID)       || \
        (_fam == STAT_ACTIVITY_INFO_DU_ID_PLMN)       || \
        (_fam == STAT_ACTIVITY_INFO_GLOBAL_ID_PLMN)   || \
        (_fam == STAT_ACTIVITY_INFO_SERVICE_TYPE)     || \
        (_fam == STAT_ACTIVITY_INFO_PLMN_SNSSAI_5QI)  || \
        (_fam == STAT_ACTIVITY_INFO_DU_ID_PLMN_SNSSAI))

#define IS_VALID_FAMIDX_TYPE_NVOID(_famIdx, _mType)                                            \
    do                                                                                         \
    {                                                                                          \
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(_famIdx, 0, (MAX_VCCB_FAMILY_TYPE - 1));     \
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(_mType, 0, (MAX_VCCB_STAT_DETAIL_TYPE - 1)); \
    } while (0)

#define IS_VALID_FAMIDX_TYPE_NERROR(_famIdx, _mType)                                            \
    do                                                                                          \
    {                                                                                           \
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(_famIdx, 0, (MAX_VCCB_FAMILY_TYPE - 1));     \
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(_mType, 0, (MAX_VCCB_STAT_DETAIL_TYPE - 1)); \
    } while (0)

#define GET_FAMIDX(_mFamily) FnVCCB_GetLocalFamilyIndexUsingPmFamilyId(_mFamily)

#define GET_CALL_STAT_FLAG(_ptCi, _indexMfamily) _ptCi->stat.flag[_indexMfamily]

#define SET_CALL_STAT_FLAG(_ptCi, _indexMfamily, _statFlag) _ptCi->stat.flag[_indexMfamily] = _statFlag;

// for -Wunused-variable

#define MACRO_RRE_STAT(_ptCi, _type)                                                                                  \
    do                                                                                                                \
    {                                                                                                                 \
        switch (ptCi->ueInfo.reestablishInfo.reestablishType)                                                         \
        {                                                                                                             \
            case RRE_TYPE_INTRA_GNB_RRC_SETUP:                                                                        \
            case RRE_TYPE_INTRA_DU:                                                                                   \
            case RRE_TYPE_INTER_DU:                                                                                   \
                VLIB_LibStatPmCC(STAT_RRC_REESTAB, IntraGnb##_type, _ptCi, 0, 0, 0, 0, 0, __FUNCTION__);              \
                break;                                                                                                \
                                                                                                                      \
            case RRE_TYPE_INTER_GNB_RRC_SETUP:                                                                        \
            case RRE_TYPE_INTER_GNB:                                                                                  \
                VLIB_LibStatPmCC(STAT_RRC_REESTAB, InterGnb##_type, _ptCi, 0, 0, 0, 0, 0, __FUNCTION__);              \
                break;                                                                                                \
                                                                                                                      \
            default:                                                                                                  \
                VCCB_PRINT_COMMENT(                                                                                   \
                    "%s:Invalid reestablish type(%d)\n", __FUNCTION__, ptCi->ueInfo.reestablishInfo.reestablishType); \
                break;                                                                                                \
        }                                                                                                             \
    } while (0)

#define MACRO_MRO_STAT(__mFamily, __mType, __ptCi, __source_cgi, __target_cgi)                                  \
    FnVCCB_LibStatMroEvent(__func__, __LINE__, #__mFamily, __mFamily, #__mType, __mType, __ptCi, #__source_cgi, \
        __source_cgi, #__target_cgi, __target_cgi)

/* need to use
#define     MACRO_CALL_STAT(i,j,k)      VLIB_CallStatInfo(ptCi, i, j, k);
#define     MACRO_CALL_ETC_STAT(i,j,k)  VLIB_LibStatCallEvent(ptCi, i, j, k);
#define     MACRO_HO_STAT(i,j)          VLIB_HandoverStatInfo(ptCi, i, j);
#define     MACRO_CSFB_STAT(i,j)        VLIB_CSFallbackStatInfo(ptCi, i, j);
#define     MACRO_PAGING_STAT(i)        VLIB_LibStatPagingEvent(i);
#define     MACRO_MRO_AT_SETUP_STAT(i,j,k)       VLIB_LibStatMroAtSetupEvent(i,j,k);
#define     MACRO_RO_STAT(i,j)          VLIB_LibStatRoEvent(i,j);
#define     MACRO_ANR_STAT(i,j)         VLIB_LibStatAnrEvent(i,j);
#define     MACRO_UNKNOWN_PCI_STAT(i)   VLIB_LibStatUnknownPciEvent(ptCi,i);
#define     MACRO_CSL_STAT(i,j)         VLIB_LibStatCSLInfo(i,j);
#define     MACRO_CALL_FAULT_SAVE(i,j)  VLIB_CallFaultSave(ptCi, i, j);
#define     MACRO_CALL_DROP_STAT()      VLIB_CallDropStatInfo(ptCi);
#define     MACRO_MR_STAT(i,j)          VLIB_LibStatMeasurement(ptCi,i,j);
#define     MACRO_DISPLAY_HO_INFO()     VLIB_DisplayHoSourceCellInfo(ptCi);
#define     MACRO_MLB_REDIR_STAT(i)     VLIB_LibStatMlbRedirEvent(ptCi, i);
#define     MACRO_IRAT_MR_STAT(i,j)     VLIB_LibStatIRatMrEvent(ptCi,i,j);
#define     MACRO_PREEMPT_HO_STAT()     VLIB_LibStatPreemptHoEvent(ptCi);    // SLR300_A015
#define     IS_COVERAGE_HOLE            VLIB_CheckCoverageHole(ptCi)
#define     IS_MULTI_PREPARATION        VLIB_CheckMultiPreparation(ptCi)
#define     MACRO_CA_RECONF_STAT(i,j)   VLIB_CAreconfigStat(ptCi,i,j);
#define     MACRO_IRAT_MRO_STAT(i,j,k)  VLIB_LibStatIRatMroEvent(i,j,k);
#define     MACRO_CCO_STAT(i,j,k,l)     VLIB_LibStatCcoEvent(i,j,k,l);        // SLR310_A049
#define     MACRO_SCELL_ADD_REL_STAT(i,j) VLIB_LibStatScellAddRel(ptCi,i,j); //SLR410 A094
#define     MACRO_UTRAN_MRO_STAT(i,j,k) VLIB_LibStatUtranMroEvent(i,j,k); // SLR500_B_0592
*/

/*******************  VLIB MACRO *********************************/

#define IS_TIMER_VALID(__timer) ((__timer).id > 0)
// Please use VCCB_CLEAR_TIMER(_pTimer, INIT_TIMER) instread of INIT_TIMER(__timer)
// #define INIT_TIMER(__timer)     ((__timer).id = -1)

/*******************  VRRM MACRO *********************************/

// #ifdef HOST_SIM
#define VRRM_SHOW       iPRINTNH
#define VRRM_SHOW_BLANK iPRINTNH
#define VRRM_SHOW_CMD   iPRINTNH
#define VRRM_MESSAGE    iPRINTNH
#define VRRM_MSG_NH     iPRINTNH
/*
#else
#define VRRM_SHOW(fmt, args...)         dusPrint(VRRM_BLK_NAME, VRRM_PO_SHOW, fmt, ##args)
#define VRRM_SHOW_BLANK(fmt, args...)   dusPrint(VRRM_BLK_NAME, NO_HDR_PL_CMD, fmt, ##args)
#define VRRM_SHOW_CMD(fmt, args...)     dusPrint(VRRM_BLK_NAME, VRRM_PO_INIT, fmt, ##args)
#define VRRM_MESSAGE(fmt, args...)      dusPrint(VRRM_BLK_NAME, VRRM_PO_MESSAGE, fmt, ##args)
#define VRRM_MSG_NH(fmt, args...)       dusPrint(VRRM_BLK_NAME, VRRM_PO_MSG_NH, fmt, ##args)
#endif
*/

#define HEX2ASCII(h)  ((((h) < ' ') || ((h) > '~')) ? '.' : (h))
#define VRRM_PRSTRING "          "
#define VRRM_BAR1     VRRM_MESSAGE("------------------------------------------------------------\n")
#define VRRM_BAR2     VRRM_MESSAGE("============================================================\n")

#define VRRM_BLANK    0  // PL_CMD
#define VRRM_CRITICAL 1  // PL_CRITICAL
#define VRRM_ERROR    2  // PL_ERROR
#define VRRM_SIG      3  // PL_MSG
#define VRRM_DATA     4  // PL_DATA
#define VRRM_DBGMSG   5  // PL_COMMENT

#define VCCB_HANDLE_DAL_RETURN_VALUE(__dalResult, __appType)                                         \
    if (DAL_SUCCESS != __dalResult)                                                                  \
    {                                                                                                \
        switch (__dalResult)                                                                         \
        {                                                                                            \
            case DAL_ERR:                                                                            \
            {                                                                                        \
                VCCB_PRINTF_ERR("[DAL][" #__appType "][%s] %s\n", __FUNCTION__,                      \
                    dal_db_get_errcode_str(dal_db_get_error_code(__dalResult)));                     \
                break;                                                                               \
            }                                                                                        \
            case DAL_EOF:                                                                            \
            {                                                                                        \
                VCCB_PRINTF_ERR("[DAL][" #__appType "][%s] Socket has been closed\n", __FUNCTION__); \
                break;                                                                               \
            }                                                                                        \
            case DAL_SOCK_CONNECT_FAIL:                                                              \
            {                                                                                        \
                VCCB_PRINTF_ERR("[DAL][" #__appType "][%s] Connection failed\n", __FUNCTION__);      \
                break;                                                                               \
            }                                                                                        \
            case DAL_INVALID_PARAM:                                                                  \
            {                                                                                        \
                VCCB_PRINTF_ERR("[DAL][" #__appType "][%s] Invalid params\n", __FUNCTION__);         \
                break;                                                                               \
            }                                                                                        \
            default:                                                                                 \
                break;                                                                               \
        }                                                                                            \
    }

#define VCCB_HANDLE_DAL_RETURN_VALUE_IF_FAIL_RETURN_FAILURE(__dalResult, __appType) \
    {                                                                               \
        VCCB_HANDLE_DAL_RETURN_VALUE(__dalResult, __appType)                        \
        if (DAL_SUCCESS != __dalResult)                                             \
        {                                                                           \
            return ERROR;                                                           \
        }                                                                           \
    }

#define VCCB_HANDLE_DAL_RETURN_VALUE_IF_FAIL_BREAK(__dalResult, __appType) \
    {                                                                      \
        VCCB_HANDLE_DAL_RETURN_VALUE(__dalResult, __appType)               \
        if (DAL_SUCCESS != __dalResult)                                    \
        {                                                                  \
            break;                                                         \
        }                                                                  \
    }

#define VCCB_HANDLE_DAL_RETURN_VALUE_CONSIDERING_CRITICALITY(__dalResult, __appType, __criticality) \
    {                                                                                               \
        VCCB_HANDLE_DAL_RETURN_VALUE(__dalResult, __appType)                                        \
        if (DAL_SUCCESS != __dalResult)                                                             \
        {                                                                                           \
            if (CRITICAL == __criticality)                                                          \
                break;                                                                              \
            else if (NON_CRITICAL == __criticality)                                                 \
                continue;                                                                           \
        }                                                                                           \
    }

#define VCCB_HANDLE_DAL_RETURN_VALUE_IF_LESS_THAN_ZERO_RETURN_STATUS(__dalResult, __appType) \
    {                                                                                        \
        VCCB_HANDLE_DAL_RETURN_VALUE(__dalResult, __appType)                                 \
        if (0 > __dalResult)                                                                 \
        {                                                                                    \
            return __dalResult;                                                              \
        }                                                                                    \
    }

#define VCCB_HANDLE_DAL_RETURN_VALUE_IF_LESS_THAN_ZERO_RETURN_STATUS_AND_FREEMEM(__dalResult, __appType, __memPtr) \
    {                                                                                                              \
        VCCB_HANDLE_DAL_RETURN_VALUE(__dalResult, __appType)                                                       \
        if (0 > __dalResult)                                                                                       \
        {                                                                                                          \
            if (NULL != __memPtr)                                                                                  \
            {                                                                                                      \
                dal_free(__memPtr);                                                                                \
                __memPtr = NULL;                                                                                   \
            }                                                                                                      \
            return __dalResult;                                                                                    \
        }                                                                                                          \
    }

#define VCCB_HANDLE_DAL_SIZE_IF_CORRECT_AND_RETURN(__dalSize, __appType)                            \
    {                                                                                               \
        switch (__dalSize)                                                                          \
        {                                                                                           \
            case 0:                                                                                 \
            {                                                                                       \
                VCCB_PRINTF_ERR("[DAL][" #__appType "][%s] Size is 0\n", __FUNCTION__);             \
                return DAL_SUCCESS;                                                                 \
            }                                                                                       \
            default:                                                                                \
            {                                                                                       \
                VCCB_HANDLE_DAL_RETURN_VALUE_IF_LESS_THAN_ZERO_RETURN_STATUS(__dalSize, __appType); \
                break;                                                                              \
            }                                                                                       \
        }                                                                                           \
    }

#define NULL_BLOCK_DAL_SUBSCRIPTION(__pointer) \
    {                                          \
        if (__pointer == NULL)                 \
        {                                      \
            return DAL_DB_ITER_STOP;           \
        }                                      \
    }

#define NOT_GOOD_BLOCK_DAL_SUBSCRIPTION(__status) \
    {                                             \
        if (__status != GOOD)                     \
        {                                         \
            return DAL_DB_ITER_STOP;              \
        }                                         \
    }

#define RETURN_ERROR_WHEN_HKEYPATH_DEPTH_TOO_LARGE(__depth) \
    {                                                       \
        if (__depth >= DAL_MAXDEPTH)                        \
        {                                                   \
            return ERROR;                                   \
        }                                                   \
    }

#define SET_MEAS_OBJECT_AND_CONFIG_UPDATE_FLAG(__cellNum) \
    {                                                     \
        CELLINFO[__cellNum].cfg.measConfigUpdateFlag = 1; \
        CELLINFO[__cellNum].cfg.measObjUpdateFlag = 1;    \
    }

#define SET_MEAS_CONFIG_UPDATE_FLAG(__cellNum)            \
    {                                                     \
        CELLINFO[__cellNum].cfg.measConfigUpdateFlag = 1; \
    }

#define SET_SPLIT_DRB_UL_PDCP_PATH_ENDC(__ptCi, __path)                                              \
    {                                                                                                \
        int __erabIdx = 0;                                                                           \
        for (__erabIdx = 0; __erabIdx < MAX_ERAB_PER_CALL; __erabIdx++)                              \
        {                                                                                            \
            if (__ptCi->erabInfo[__erabIdx].usage != CI_use)                                         \
            {                                                                                        \
                continue;                                                                            \
            }                                                                                        \
                                                                                                     \
            if (SPLIT_Bearer == __ptCi->erabInfo[__erabIdx].bearerType)                              \
            {                                                                                        \
                __ptCi->erabInfo[__erabIdx].ulPdcpPathPrev = __ptCi->erabInfo[__erabIdx].ulPdcpPath; \
                __ptCi->erabInfo[__erabIdx].ulPdcpPath = __path;                                     \
            }                                                                                        \
        }                                                                                            \
    }

#define SET_MOD_ON_ULP_IN_IDLE(__ptCi, __erabInfo)                                              \
    do                                                                                            \
    {                                                                                           \
        if (VCCM_IsUeIdleState(__ptCi->callType, __ptCi->state))                                \
        {                                                                                        \
            __erabInfo.ulPdcpPathToMod = UlConfigBearer_ModOn;                                    \
        }                                                                                       \
    } while(0)            


#define SET_SPLIT_DRB_UL_PDCP_PATH_NEDC(__ptCi, __path)                                  \
    {                                                                                    \
        int __drbIdx = 0;                                                                \
        for (__drbIdx = 0; __drbIdx < MAX_DRB_PER_SA_CALL; __drbIdx++)                   \
        {                                                                                \
            if (__ptCi->drb[__drbIdx].usage != CI_use)                                   \
            {                                                                            \
                continue;                                                                \
            }                                                                            \
                                                                                         \
            if ((MN_Term_SPLIT_Bearer == __ptCi->drb[__drbIdx].bearerType.val) ||        \
                (MN_Term_SPLIT_Bearer == __ptCi->drb[__drbIdx].reqBearerType.val))       \
            {                                                                            \
                __ptCi->drb[__drbIdx].ulPdcpPathPrev = __ptCi->drb[__drbIdx].ulPdcpPath; \
                __ptCi->drb[__drbIdx].ulPdcpPath = __path;                               \
                __ptCi->drb[__drbIdx].snDrbStatus = S_Modify;                            \
            }                                                                            \
        }                                                                                \
    }

#define SET_SPLIT_PER_DRB_UL_PDCP_PATH_NEDC(__ptCi, __path, __drbIdx)                    \
    {                                                                                    \
        if ((MN_Term_SPLIT_Bearer == __ptCi->drb[__drbIdx].bearerType.val) ||            \
            (MN_Term_SPLIT_Bearer == __ptCi->drb[__drbIdx].reqBearerType.val))           \
        {                                                                                \
            __ptCi->drb[__drbIdx].ulPdcpPathPrev = __ptCi->drb[__drbIdx].ulPdcpPath;     \
            __ptCi->drb[__drbIdx].ulPdcpPath = __path;                                   \
            __ptCi->drb[__drbIdx].snDrbStatus = S_Modify;                                \
        }                                                                                \
    }

#define SET_SPLIT_DRB_UL_PDCP_PATH_NRDC(__ptCi, __path, __drbIdx)                        \
    {                                                                                    \
        if ((MN_Term_SPLIT_Bearer == __ptCi->drb[__drbIdx].bearerType.val) ||            \
            (SN_Term_SPLIT_Bearer == __ptCi->drb[__drbIdx].bearerType.val))              \
        {                                                                                \
            __ptCi->drb[__drbIdx].ulPdcpPathPrev = __ptCi->drb[__drbIdx].ulPdcpPath;     \
            __ptCi->drb[__drbIdx].ulPdcpPath = __path;                                   \
            __ptCi->drb[__drbIdx].snDrbStatus = S_Modify;                                \
        }                                                                                \
    }

#define SET_CALL_ERAB_INFO_USAGE_OFF(__ptCi, __erabIdx)                              \
    {                                                                                \
        if (__ptCi->erabInfo[__erabIdx].usage == CI_use)                             \
        {                                                                            \
            __ptCi->erabInfo[__erabIdx].usage = CI_no_use;                           \
            if (__ptCi->numERAB > 0)                                                 \
            {                                                                        \
                __ptCi->numERAB--;                                                   \
            }                                                                        \
            if (__ptCi->erabInfo[__erabIdx].erabStatus != ERAB_FailToSetup)          \
            {                                                                        \
                VRRM_delCellDrbCount(__ptCi, __ptCi->servCellNum, __erabIdx, FALSE); \
            }                                                                        \
            __ptCi->erabInfo[__erabIdx].addSuccessFlagForStat = FLAG_OFF;            \
        }                                                                            \
    }

#define SET_MRS_STATE(_ptCi, _state)                                                                          \
    {                                                                                                         \
        VCCB_PRINT_CALL_COMMENT(_ptCi, "[MRS] State change [%u -> %u]\n", (_ptCi)->mrsInfo.mrsState, _state); \
        (_ptCi)->mrsInfo.mrsState = (_state);                                                                 \
    }

#define SET_MRS_REJECT_STATUS(_ptCi)                                   \
    {                                                                  \
        VCCB_PRINT_CALL_COMMENT(_ptCi, "[MRS] Set rejectedStatus \n"); \
        (_ptCi)->mrsInfo.rejectStatus = VCCB_FLAG_ON;                  \
    }

#define SET_PDU_STATUS(__ptCi, __pduIdx, __status)                                                   \
    do \
    {                                                                                                \
        if (DBG->flag.statusDebug)                                                                   \
        {                                                                                            \
            if (__ptCi->pduSess[__pduIdx].pduSessStatus != __status)                                 \
            {                                                                                        \
                VCCB_PRINT_CALL_INFORMATIVE(__ptCi,                                                  \
                    "PDU(idx:%d, pduSessId:%d) status is update to (%d:%s) in func %s!\n", __pduIdx, \
                    __ptCi->pduSess[__pduIdx].pduSessId, __status,                                   \
                    FnVCCB_GetStrSABearerStatus((enumSABearerStatus_type)__status), __func__);       \
            }                                                                                        \
        }                                                                                            \
        if (__ptCi->pduSess[__pduIdx].pduSessStatus == S_Idle)                                       \
        {                                                                                            \
            __ptCi->pduSess[__pduIdx].firstReqStatusInThisProcedure = __status;                      \
        }                                                                                            \
        __ptCi->pduSess[__pduIdx].prevPduSessStatus = __ptCi->pduSess[__pduIdx].pduSessStatus;       \
        __ptCi->pduSess[__pduIdx].pduSessStatus = __status;                                          \
        if (__status == S_Idle)                                                                      \
        {                                                                                            \
            __ptCi->pduSess[__pduIdx].firstReqStatusInThisProcedure = __status;                      \
        }                                                                                            \
    }while(0)

#define SET_DRB_STATUS(__ptCi, __drbIdx, __status)                                                                    \
do \
    {                                                                                                                 \
        if (DBG->flag.statusDebug)                                                                                \
        {                                                                                                             \
            if (__ptCi->drb[__drbIdx].drbStatus != __status)                                                          \
            {                                                                                                         \
                VCCB_PRINT_CALL_INFORMATIVE(__ptCi, "DRB(idx:%d, dRBId:%d) status is update to (%d:%s)! in %s\n", \
                    __drbIdx, __ptCi->drb[__drbIdx].dRBId, __status,                                              \
                    FnVCCB_GetStrSABearerStatus((enumSABearerStatus_type)__status),  __func__);                       \
            }                                                                                                         \
        }                                                                                                             \
        if (__ptCi->drb[__drbIdx].drbStatus == S_Idle)                                                                \
        {                                                                                                             \
            __ptCi->drb[__drbIdx].firstReqStatusInThisProcedure = __status;                                           \
        }                                                                                                             \
        __ptCi->drb[__drbIdx].prevDrbStatus = __ptCi->drb[__drbIdx].drbStatus;                                        \
        __ptCi->drb[__drbIdx].drbStatus = __status;                                                 \
        if (__status == S_Idle)                                                                                       \
        {                                                                                                             \
            __ptCi->drb[__drbIdx].firstReqStatusInThisProcedure = S_Idle;                                             \
        }                                                                                                             \
    } while(0)

#define SET_QOSFLOW_STATUS(__ptCi, __qosIdx, __status)                                                                 \
    do                                                                                                                 \
    {                                                                                                                  \
        if (DBG->flag.statusDebug)                                                                                 \
        {                                                                                                              \
            if (__ptCi->qosFlow[__qosIdx].qosFlowStatus != __status)                                                   \
            {                                                                                                          \
                VCCB_PRINT_CALL_INFORMATIVE(__ptCi, "QOS(idx:%d, flowId:%d) status is update to (%d:%s)! in %s\n", \
                    __qosIdx, __ptCi->qosFlow[__qosIdx].flowId, __status,                                          \
                    FnVCCB_GetStrSABearerStatus((enumSABearerStatus_type)__status), __func__);                         \
            }                                                                                                          \
        }                                                                                                              \
        if (__ptCi->qosFlow[__qosIdx].qosFlowStatus == S_Idle)                                                     \
        {                                                                                                              \
            __ptCi->qosFlow[__qosIdx].firstReqStatusInThisProcedure = __status;                                        \
        }                                                                                                              \
        __ptCi->qosFlow[__qosIdx].prevQosFlowStatus = __ptCi->qosFlow[__qosIdx].qosFlowStatus;                         \
        __ptCi->qosFlow[__qosIdx].qosFlowStatus = __status;                                                            \
        if (__status == S_Idle)                                                                                    \
        {                                                                                                              \
            __ptCi->qosFlow[__qosIdx].firstReqStatusInThisProcedure = __status;                                        \
        }                                                                                                              \
    } while (0)


#define SET_COND_CELL_STATUS(__ptCi, __condIdx, __status) FnVCCB_SetConditionalCellStatus(__ptCi, __condIdx, __status)

// This macro is called when a state change to the DC bearer is required.
#define SET_MRDC_REQ_BEARER_STATUS(__ptCi, __ptDi, __bearerType)                                  \
    do                                                                                            \
    {                                                                                             \
        VLIB_setReqBearerTypeForMrDc(__ptCi, __ptDi, __bearerType, __func__); \
    } while (0)

// This macro is called when the state of the DC bearer has changed.
#define SET_MRDC_BEARER_STATUS(__ptCi, __ptDi, __bearerType)                                   \
    do                                                                                         \
    {                                                                                          \
        VLIB_setBearerTypeForMrDc(__ptCi, __ptDi, (int)__bearerType, __func__); \
    } while (0)

// This macro is used to finally determine the bearer type according to the DC mode.
#define SET_MRDC_SELECTED_BEARER(__ptCi, __ptDi, __flag, __bearerType)                                         \
    do                                                                                                         \
    {                                                                                                          \
        VLIB_setSelectedBearerTypeForMrDc(__ptCi, __ptDi, __flag, (int)__bearerType, __func__); \
    } while (0)

#define RESET_DRB_ID_IN_POOL(__ptCi)                                        \
    {                                                                       \
        for (int __drbIdx = 0; __drbIdx < MAX_NRRRC_DRBID_3GPP; __drbIdx++) \
        {                                                                   \
            OFF_BIT_DRB_ID_IN_POOL(__ptCi, __drbIdx);                       \
        }                                                                   \
        for (int __drbId = 0; __drbId < MAX_DRB_PER_SA_CALL; __drbId++)     \
        {                                                                   \
            if (__ptCi->drb[__drbId].usage == CI_use)                       \
            {                                                               \
                ON_BIT_DRB_ID_IN_POOL(__ptCi, __ptCi->drb[__drbId].dRBId);  \
            }                                                               \
        }                                                                   \
    }

// DRB ID is managed per bit units of drbIdPool.
// Allocate DRB ID using drbIdPool(bit index:0~31, drbId:index+1(Range:1~32))
// bit value 0 means currently not used and 1 means already allocated.
#define ALLOCATE_DRB_ID_AND_RETURN(__ptCi, __ptDi, __isDrbIdAllocated)                                             \
    {                                                                                                              \
        uint8_t __index;                                                                                           \
        for (__index = 0; __index < MAX_NRRRC_DRBID_3GPP; __index++)                                               \
        {                                                                                                          \
            if (!GETBIT(__ptCi->drbIdPool, __index)) /* Find not allocated DRB ID */                               \
            {                                                                                                      \
                __ptDi->dRBId = (uint8_t)(__index + 1);                                                            \
                break;                                                                                             \
            }                                                                                                      \
        }                                                                                                          \
        if (__index >= MAX_NRRRC_DRBID_3GPP)                                                                       \
        {                                                                                                          \
            if (__isDrbIdAllocated == false) /* All DRB IDs allocated, release call. */                            \
            {                                                                                                      \
                VCCB_PRINT_CALL_ERROR(__ptCi, "Fail to allocated DRB ID...\n");                                    \
                return ERROR;                                                                                      \
            }                                                                                                      \
            if (FOO.VF_CipheringandIntegrityProtectionforSA_23B == TRUE)                                           \
            {                                                                                                      \
                VCCB_PRINT_CALL_INFORMATIVE(__ptCi, "Failed to allocate DRB ID, reset all DRB ID bits in pool\n"); \
                __isDrbIdAllocated = false;                                                                        \
            }                                                                                                      \
            else                                                                                                   \
            {                                                                                                      \
                VCCB_PRINT_CALL_ERROR(__ptCi, "Fail to allocated DRB ID...\n");                                    \
                return ERROR;                                                                                      \
            }                                                                                                      \
        }                                                                                                          \
    }

// Allocate DRB ID in drbIdPool(bit index:0~31bit, drbId:index+1(Range:1~32))
#define ON_BIT_DRB_ID_IN_POOL(__ptCi, __dRBId)                  \
    {                                                           \
        if ((__dRBId > 0) && (__dRBId <= MAX_NRRRC_DRBID_3GPP)) \
        {                                                       \
            ONBIT_U32(__ptCi->drbIdPool, (__dRBId - 1));        \
        }                                                       \
    }

// Release DRB ID in drbIdPool(bit index:0~31bit, drbId:index+1(Range:1~32))
#define OFF_BIT_DRB_ID_IN_POOL(__ptCi, __dRBId)                 \
    {                                                           \
        if ((__dRBId > 0) && (__dRBId <= MAX_NRRRC_DRBID_3GPP)) \
        {                                                       \
            OFFBIT_U32(__ptCi->drbIdPool, (__dRBId - 1));       \
        }                                                       \
    }

#define EXECUTE_FNPDCP_C_DLSRB_AFTER_SECURITY_CHECK_RETURN(                                                  \
    __ptCi, __ptSi, __ptRrcData, __ptPdcpData, __rrcDataLen, __pdcpDataLen)                                  \
    {                                                                                                        \
        int _pdcpStatus;                                                                                     \
        VCCB_PRINT_CALL_COMMENT(__ptCi, " securityInfo mode(%d) integrityAlgo(%d) cipherAlgo(%d)\n",         \
            __ptCi->security.pdcpCtx.securityInfo.mode, __ptCi->security.pdcpCtx.securityInfo.integrityAlgo, \
            __ptCi->security.pdcpCtx.securityInfo.cipherAlgo);                                               \
        _pdcpStatus = FnPDCP_C_DlSrb(                                                                        \
            &__ptCi->security.pdcpCtx, &__ptSi->pdcpRbContext, __ptRrcData, __ptPdcpData, __rrcDataLen);     \
        if (_pdcpStatus <= 0)                                                                                \
        {                                                                                                    \
            VCCB_PRINT_CALL_ERROR(__ptCi, "FnPDCP_C_DlSrb ERROR(%d)!\n", _pdcpStatus);                       \
            return ERROR;                                                                                    \
        }                                                                                                    \
        __pdcpDataLen = (uint16_t)_pdcpStatus;                                                               \
    }

#define EXECUTE_FNPDCP_C_DLSRB_AFTER_SECURITY_CHECK_NRETURN(                                                 \
    __ptCi, __ptSi, __ptRrcData, __ptPdcpData, __rrcDataLen, __pdcpDataLen)                                  \
    {                                                                                                        \
        int _pdcpStatus;                                                                                     \
        VCCB_PRINT_CALL_COMMENT(__ptCi, " securityInfo mode(%d) integrityAlgo(%d) cipherAlgo(%d)\n",         \
            __ptCi->security.pdcpCtx.securityInfo.mode, __ptCi->security.pdcpCtx.securityInfo.integrityAlgo, \
            __ptCi->security.pdcpCtx.securityInfo.cipherAlgo);                                               \
        _pdcpStatus = FnPDCP_C_DlSrb(                                                                        \
            &__ptCi->security.pdcpCtx, &__ptSi->pdcpRbContext, __ptRrcData, __ptPdcpData, __rrcDataLen);     \
        if (_pdcpStatus <= 0)                                                                                \
        {                                                                                                    \
            VCCB_PRINT_CALL_ERROR(__ptCi, "FnPDCP_C_DlSrb ERROR(%d)!\n", _pdcpStatus);                       \
            return ERROR;                                                                                    \
        }                                                                                                    \
        __pdcpDataLen = (uint16_t)_pdcpStatus;                                                               \
    }

#define SET_CALL_RETAIN_STAT_CAPABLE_FLAG(__ptCi, __flagOnOff) \
    do                                                         \
    {                                                          \
        (__ptCi)->retainStat.capableFlag = __flagOnOff;        \
    } while (0)

#define SET_DRB_RETAIN_STAT_CAPABLE_FLAG(__ptDi, __flagOnOff) \
    do                                                        \
    {                                                         \
        (__ptDi)->retainStat.capableFlag = __flagOnOff;       \
    } while (0)

#define SET_ON_ALL_RETAIN_STAT_CAPABLE_FLAG(__ptCi, __includeSetupFail, __isInterGnbOperation) \
    do                                                                                         \
    {                                                                                          \
        VLIB_SetOnAllRetainStatCapableFlag(__ptCi, __includeSetupFail, __isInterGnbOperation); \
    } while (0)


#define UPDATE_DRB_ABNORMAL_REL_STAT_CAUSE_5QI(__dst, __cause)      \
    do                                                              \
    {                                                               \
        if(__cause < Retain_AbnRel_CauseStatMAX)                    \
        {                                                           \
            __dst = __cause;                                        \
        }                                                           \
    } while (0)

#define CLEAR_RETAIN_STAT_EVENT(__retainStat)                        \
    do                                                               \
    {                                                                \
        __retainStat.savedEventCategory = No_CallDrb_RetainCategory; \
        __retainStat.savedEventItem     = No_CallDrb_RetainItem;     \
        __retainStat.abnRelCause5qi     = Retain_AbnRel_CslMAX;      \
    } while (0)

#define CLEAR_DRB_RETAIN_STAT_EVENT(__ptDi)                                         \
    do                                                                              \
    {                                                                               \
        __ptDi->retainStat.savedEventCategory = No_CallDrb_RetainCategory;          \
        __ptDi->retainStat.savedEventItem = No_CallDrb_RetainItem;                  \
        __ptDi->retainStat.abnRelCause5qi = Retain_AbnRel_CslMAX;                   \
        __ptDi->retainStatForAmfReq.savedEventCategory = No_CallDrb_RetainCategory; \
        __ptDi->retainStatForAmfReq.savedEventItem = No_CallDrb_RetainItem;         \
        __ptDi->retainStatForAmfReq.abnRelCause5qi = Retain_AbnRel_CslMAX;                   \
    } while (0)

#define ACTIVE_DRB_RETAIN_OFFSET 1          /* Offset from Noraml_DRB_Retain_Family */

#define MACRO_STAT_IS_NRRETAIN_UE_FAMILY(_mFamily)     \
    ((STAT_SETUP_UECONTEXT_RELEASE               == _mFamily) || \
     (STAT_SETUP_ACTIVE_UECONTEXT_RELEASE_DU_ID  == _mFamily))

#define SET_AMF_REQUEST_ORIGINAL_FLAG(_flag_AmfRequestBySpecialSave, _flag_AmfRequestByOriginal)   \
            if(_flag_AmfRequestBySpecialSave == VCCB_FLAG_OFF)                                                     \
            {                                                                                                      \
                _flag_AmfRequestByOriginal = VCCB_FLAG_ON;                                                         \
            }
#define SET_AMF_REQUEST_NORMAL_WITH_ORGINAL_RETAIN(_flag_AmfRequestByOriginal, _flag_AmfRequest_Normal)            \
            if(_flag_AmfRequestByOriginal == VCCB_FLAG_ON)                                                         \
            {                                                                                                      \
                _flag_AmfRequest_Normal = VCCB_FLAG_ON;                                                            \
            }

#define SET_VONR_EMER_RETAIN_STAT_CAPABLE_FLAG(__ptCi, __flagOnOff) \
    do                                                              \
    {                                                               \
        (__ptCi)->retainStatOfVonrEmer.capableFlag = __flagOnOff;   \
    } while (0)

#define SET_QOSFLOW_RETAIN_STAT_CAPABLE_FLAG(__ptQi, __flagOnOff) \
    do                                                            \
    {                                                             \
        (__ptQi)->retainStat.capableFlag = __flagOnOff;           \
    } while (0)

#define SAVE_RESET_EVENT_FOR_RETAIN_STATE(__ptCi, __resetType, __cause)                          \
    do                                                                                           \
    {                                                                                            \
        if (__ptCi->callType == E_CALLTYPE_SA)                                                   \
        {                                                                                        \
            if (__resetType == NG_RESET_BY_AMF)                                                  \
                VLIB_SaveEventForCallRetainStat(__ptCi, RetainCategory_NgResetByAMF, __cause);   \
            else if (__resetType == NG_RESET_BY_RAN)                                             \
                VLIB_SaveEventForCallRetainStat(__ptCi, RetainCategory_NgResetByGNB, __cause);   \
            else if (__resetType == NG_RESET_BY_LINK_FAIL)                                       \
                VLIB_SaveEventForCallRetainStat(__ptCi, RetainCategory_NgcLinkFailure, __cause); \
        }                                                                                        \
    } while (0)

#define MACRO_IS_SERVICE_TYPE_STAT_ON() (CFG->acpfInfo.serviceTypeOnOff == TRUE)

// STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID : Global
// STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID_PLMN : For MOCN
// STAT_SETUP_ACTIVE_DRB_RELEASE_GLOBAL_ID_PLMN : VF_NRRetainability_ActiveDRBReleaseGlobalID (For Only MSO)
// STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID_PLMN_SNSSAI : VF_NRRetainability_IndexSNSSAI (for CAN)
#define MACRO_STAT_IS_NRRETAIN_ACTIVEFAMILY(_mFamily)     \
    ((STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID             == _mFamily) || \
     (STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID_PLMN        == _mFamily) || \
     (STAT_SETUP_ACTIVE_DRB_RELEASE_GLOBAL_ID_PLMN    == _mFamily) || \
     (STAT_SETUP_ACTIVE_DRB_RELEASE_PLMN_SNSSAI_5QI   == _mFamily) || \
     (STAT_SETUP_ACTIVE_DRB_RELEASE_DU_ID_PLMN_SNSSAI == _mFamily))

// STAT_SETUP_DRB_RELEASE                   : Global
// STAT_SETUP_DRB_RELEASE_DU_ID_PLMN_SNSSAI : VF_NRRetainability_IndexSNSSAI (for CAN)
#define MACRO_STAT_IS_NRRETAIN_DRBRELFAMILY(_mFamily)           \
    ((STAT_SETUP_DRB_RELEASE                    == _mFamily) || \
     (STAT_SETUP_DRB_RELEASE_DU_ID_PLMN_SNSSAI  == _mFamily) || \
     (STAT_SETUP_DRB_RELEASE_PLMN_SNSSAI_5QI    == _mFamily) || \
     (MACRO_STAT_IS_NRRETAIN_ACTIVEFAMILY(_mFamily)       ))

// for DrbRelbyGnb_UeContextRelReq_withDrbRelbyPreemption
#define MACRO_STAT_IS_COLLECT_UECTXTREQUEST_BYPREEMPTION(_mFamily) \
    ((STAT_VONR_EMERGENCY_RELEASE       == _mFamily)  ||         \
     (MACRO_STAT_IS_NRRETAIN_DRBRELFAMILY(_mFamily) ))

#define VHCM_SA_HO_STAT(__ptCi, __type)                                                                            \
    do                                                                                                             \
    {                                                                                                              \
        if (FnVCCB_CollectSaHandoverStat(__ptCi) == true)                                                          \
        {                                                                                                          \
            char _buf[MAX_VCCB_STAT_FUNC_NAME];                                                                    \
            snprintf(_buf, MAX_VCCB_STAT_FUNC_NAME, "%.*s:%d", (MAX_VCCB_STAT_FUNC_NAME - 6), __func__, __LINE__); \
            _buf[MAX_VCCB_STAT_FUNC_NAME - 1] = '\0';                                                              \
            VLIB_StatSaHandover(__ptCi, __type, (char *)_buf);                                                     \
        }                                                                                                          \
    } while (0)

#define CHO_STAT(__ptCi, __type, __cgi)                     \
    do                                                      \
    {                                                       \
        if (FnVCCB_CollectChoStat(__ptCi) == true)          \
        {                                                   \
            FnVCCB_StatChoHandover(__ptCi, __type, &__cgi); \
        }                                                   \
    } while (0)

// TODO: need to remove the VLIB_StatNrdcAdd
#define VLIB_StatNrdcAdd(__ptCi, __type) VCCB_MRDC_SN_ADD_STAT(__ptCi, __type)

#define VCCB_MRDC_SN_ADD_STAT(__ptCi, __type)                                                                  \
    do                                                                                                         \
    {                                                                                                          \
        char _buf[MAX_VCCB_STAT_FUNC_NAME];                                                                    \
        snprintf(_buf, MAX_VCCB_STAT_FUNC_NAME, "%.*s:%d", (MAX_VCCB_STAT_FUNC_NAME - 6), __func__, __LINE__); \
        _buf[MAX_VCCB_STAT_FUNC_NAME - 1] = '\0';                                                              \
        FnVCCB_StatMrdcSnAdd(__ptCi, __type, (char *)_buf);                                                    \
        VHCM_StateTriggerEventForSNAddition(__ptCi, __type, (char *)_buf);                                     \
    } while (0)

#define VCCB_MRDC_SN_REL_MN_STAT(__type, __ptCi, __reserved)                                                   \
    do                                                                                                         \
    {                                                                                                          \
        MACRO_STAT_PMCC(STAT_NRDC_SN_REL_MN, __type, __ptCi, __reserved, 0, 0, 0, 0);                          \
        MACRO_STAT_PMCC(STAT_NRDC_SN_REL_MN_PSCELL_NCI, __type, __ptCi, __reserved, 0, 0, 0, 0);               \
    } while (0)                                                                                                \

#define IS_VIRTUAL_FAMILY(_family) \
    ((_family) >= V_STAT_NRDC_SN_MOD_MN_MNInitiated && (_family) <= V_STAT_NRDC_SN_MOD_SN_SNInitiated)
#define CONVERT_FAMILY_VIRTUAL2ACTUAL(_vFamily, _aFamily)                                                       \
    do                                                                                                          \
    {                                                                                                           \
        if ((_vFamily) == V_STAT_NRDC_SN_MOD_MN_MNInitiated || (_vFamily) == V_STAT_NRDC_SN_MOD_MN_SNInitiated) \
        {                                                                                                       \
            (_aFamily) = STAT_NRDC_SN_MOD_MN;                                                                   \
        }                                                                                                       \
        else                                                                                                    \
        {                                                                                                       \
            (_aFamily) = STAT_NRDC_SN_MOD_SN;                                                                   \
        }                                                                                                       \
    } while (0)

#define VCCB_MRDC_SN_HO_STAT(__ptCi, __type)                                                                   \
    do                                                                                                         \
    {                                                                                                          \
        char _buf[MAX_VCCB_STAT_FUNC_NAME];                                                                    \
        snprintf(_buf, MAX_VCCB_STAT_FUNC_NAME, "%.*s:%d", (MAX_VCCB_STAT_FUNC_NAME - 6), __func__, __LINE__); \
        _buf[MAX_VCCB_STAT_FUNC_NAME - 1] = '\0';                                                              \
        FnVCCB_StatNrdcSnChange(__ptCi, __type, (char *)_buf);                                                 \
    } while (0)

#define VHCM_SA_PP_HO_STAT(__ptCi)       \
    do                                   \
    {                                    \
        VLIB_StatPingPongHandover(ptCi); \
    } while (0)

#define GET_XN_RECEIVED_AMF_EXIST_FLAG(__ptCi) (THREAD_INFO->call[__ptCi->myThreadId].buf.hoAmfTnlAddrInfo.existFlag)

#define GET_XN_RECEIVED_TNL_ADDR(__ptCi) (THREAD_INFO->call[__ptCi->myThreadId].buf.hoAmfTnlAddrInfo.addr)

#define GET_XN_AMF_CALL_FAULT_CAUSE(__ptCi) (THREAD_INFO->call[__ptCi->myThreadId].buf.hoAmfTnlAddrInfo.cause)

#define SET_XN_RECEIVED_TNL_ADDR_INFO(__ptCi, __addr)                                                    \
    {                                                                                                    \
        const uint8_t callThreadId = __ptCi->myThreadId;                                                 \
        if (callThreadId < MAX_CALL_THREAD_NUM_VCCB)                                                     \
        {                                                                                                \
            hoAmfTnlAddrInfo_type *ptAmfTnlAddr = &THREAD_INFO->call[callThreadId].buf.hoAmfTnlAddrInfo; \
            ptAmfTnlAddr->existFlag = VCCB_FLAG_ON;                                                      \
            ptAmfTnlAddr->addr = __addr;                                                                 \
            ptAmfTnlAddr->cause = AMF_ASSIGN_FAIL_INVALID_SET_ID;                                        \
        }                                                                                                \
        else                                                                                             \
        {                                                                                                \
            VCCB_PRINT_CALL_ERROR(__ptCi, "callThreadId %u ERROR in %s\n", callThreadId, __func__);      \
        }                                                                                                \
    }

#define SET_XN_AMF_CALL_FAULT_CAUSE(__ptCi, __cause)                                                \
    {                                                                                               \
        const uint8_t callThreadId = __ptCi->myThreadId;                                            \
        if (callThreadId < MAX_CALL_THREAD_NUM_VCCB)                                                \
        {                                                                                           \
            THREAD_INFO->call[callThreadId].buf.hoAmfTnlAddrInfo.cause = __cause;                   \
        }                                                                                           \
        else                                                                                        \
        {                                                                                           \
            VCCB_PRINT_CALL_ERROR(__ptCi, "callThreadId %u ERROR in %s\n", callThreadId, __func__); \
        }                                                                                           \
    }

#define INIT_XN_RECEIVED_TNL_ADDR_INFO(__ptCi)                                                           \
    {                                                                                                    \
        const uint8_t callThreadId = __ptCi->myThreadId;                                                 \
        if (callThreadId < MAX_CALL_THREAD_NUM_VCCB)                                                     \
        {                                                                                                \
            hoAmfTnlAddrInfo_type *ptAmfTnlAddr = &THREAD_INFO->call[callThreadId].buf.hoAmfTnlAddrInfo; \
            ptAmfTnlAddr->existFlag = VCCB_FLAG_OFF;                                                     \
            ptAmfTnlAddr->addr.IpVer = 0;                                                                \
            ptAmfTnlAddr->addr.Ip.V4 = 0;                                                                \
            uint16_t _loop;                                                                              \
            for (_loop = 0; _loop < ADDRLEN_IPV6; _loop++)                                               \
            {                                                                                            \
                ptAmfTnlAddr->addr.Ip.V6[_loop] = 0;                                                     \
            }                                                                                            \
        }                                                                                                \
        else                                                                                             \
        {                                                                                                \
            VCCB_PRINT_CALL_ERROR(__ptCi, "callThreadId %u ERROR in %s\n", callThreadId, __func__);      \
        }                                                                                                \
    }

#define INIT_NAS_INFORMATION(__NasDB)            \
    {                                            \
        __NasDB.nasPduPresent = OPT_NOT_PRESENT; \
        __NasDB.numNasMsg = 0;                   \
    }

#define SET_PDU_SESSION_ID_IN_NAS_INFO(__NasDB, __pduSessionId)          \
    {                                                                    \
        if (__NasDB.numNasMsg < VCCB_MAX_NAS_NUM_PER_CALL)               \
        {                                                                \
            __NasDB.nasPduSessionId[__NasDB.numNasMsg] = __pduSessionId; \
        }                                                                \
    }

#ifdef IPC_TEST
#define SET_UE_LONG_DRX_CYCLE_CAPA_FOR_ANR(__ptCi)                 \
    {                                                              \
        __ptCi->ueInfo.ueCapa.nr.fddCapa.mac.longDRX_Cycle = TRUE; \
        __ptCi->ueInfo.ueCapa.nr.tddCapa.mac.longDRX_Cycle = TRUE; \
    }
#endif

#define GET_INTRA_NR_ANR_LONG_DRX_TIMER_VAL(__longDrx, __timerVal) \
    {                                                              \
        switch (__longDrx)                                         \
        {                                                          \
            case F1_LongDRXCycleLength_ms10:                       \
                __timerVal = 10;                                   \
                break;                                             \
            case F1_LongDRXCycleLength_ms20:                       \
                __timerVal = 20;                                   \
                break;                                             \
            case F1_LongDRXCycleLength_ms32:                       \
                __timerVal = 32;                                   \
                break;                                             \
            case F1_LongDRXCycleLength_ms40:                       \
                __timerVal = 40;                                   \
                break;                                             \
            case F1_ms60:                                          \
                __timerVal = 60;                                   \
                break;                                             \
            case F1_LongDRXCycleLength_ms64:                       \
                __timerVal = 64;                                   \
                break;                                             \
            case F1_ms70:                                          \
                __timerVal = 70;                                   \
                break;                                             \
            case F1_LongDRXCycleLength_ms80:                       \
                __timerVal = 80;                                   \
                break;                                             \
            case F1_LongDRXCycleLength_ms128:                      \
                __timerVal = 128;                                  \
                break;                                             \
            case F1_LongDRXCycleLength_ms160:                      \
                __timerVal = 160;                                  \
                break;                                             \
            case F1_LongDRXCycleLength_ms256:                      \
                __timerVal = 256;                                  \
                break;                                             \
            case F1_LongDRXCycleLength_ms320:                      \
                __timerVal = 320;                                  \
                break;                                             \
            case F1_LongDRXCycleLength_ms512:                      \
                __timerVal = 512;                                  \
                break;                                             \
            case F1_LongDRXCycleLength_ms640:                      \
                __timerVal = 640;                                  \
                break;                                             \
            case F1_ms1024:                                        \
                __timerVal = 1024;                                 \
                break;                                             \
            case F1_ms1280:                                        \
                __timerVal = 1280;                                 \
                break;                                             \
            case F1_ms2048:                                        \
                __timerVal = 2048;                                 \
                break;                                             \
            case F1_ms2560:                                        \
                __timerVal = 2560;                                 \
                break;                                             \
            case F1_ms5120:                                        \
                __timerVal = 5120;                                 \
                break;                                             \
            case F1_ms10240:                                       \
                __timerVal = 10240;                                \
                break;                                             \
            default:                                               \
                break;                                             \
        }                                                          \
    }

#define GET_INTRA_NR_ANR_LONG_DRX(__ptCi, __timerVal)                                                       \
    GET_INTRA_NR_ANR_LONG_DRX_TIMER_VAL(((CELLINFO[__ptCi->servCellNum].nrArfcnDl < MIN_A6_NR_ARFCN)        \
                                                ? (CELLINFO[__ptCi->servCellNum].anrInfo.longDrxCycleFr1)   \
                                                : (CELLINFO[__ptCi->servCellNum].anrInfo.longDrxCycleFr2)), \
        __timerVal)

#define GET_DRX_RELEASE_FLAG(_ptCi)     _ptCi->drxCuInfo.drxReleaseFlag
#define SET_DRX_RELEASE_FLAG_ON(_ptCi)  _ptCi->drxCuInfo.drxReleaseFlag = VCCB_FLAG_ON
#define SET_DRX_RELEASE_FLAG_OFF(_ptCi) _ptCi->drxCuInfo.drxReleaseFlag = VCCB_FLAG_OFF

#define IS_ANR_MNS_ALL_WEEKDAY_SCHEDULE_ON(_gnbNum)                                                               \
    (GNBINFO[gnbNum].mnsScheduleInfo.schedule[0] == ON && GNBINFO[gnbNum].mnsScheduleInfo.schedule[1] == ON &&    \
        GNBINFO[gnbNum].mnsScheduleInfo.schedule[2] == ON && GNBINFO[gnbNum].mnsScheduleInfo.schedule[3] == ON && \
        GNBINFO[gnbNum].mnsScheduleInfo.schedule[4] == ON && GNBINFO[gnbNum].mnsScheduleInfo.schedule[5] == ON && \
        GNBINFO[gnbNum].mnsScheduleInfo.schedule[6] == ON)

#define IS_ANR_MNS_ALL_WEEKDAY_SCHEDULE_OFF(_gnbNum)                                                                \
    (GNBINFO[gnbNum].mnsScheduleInfo.schedule[0] == OFF && GNBINFO[gnbNum].mnsScheduleInfo.schedule[1] == OFF &&    \
        GNBINFO[gnbNum].mnsScheduleInfo.schedule[2] == OFF && GNBINFO[gnbNum].mnsScheduleInfo.schedule[3] == OFF && \
        GNBINFO[gnbNum].mnsScheduleInfo.schedule[4] == OFF && GNBINFO[gnbNum].mnsScheduleInfo.schedule[5] == OFF && \
        GNBINFO[gnbNum].mnsScheduleInfo.schedule[6] == OFF)

#define VCCB_STORE_DIFF_CAPA(_oldVal, _newVal) (_oldVal = (_newVal) ? TRUE : _oldVal)

#define VCCB_UPDATE_XDD_FDD_CAPA(_fdd, _tdd, _fr1, _fr2)                                                        \
    {                                                                                                           \
        if ((_fdd != _tdd) && (_fr1 == FALSE && _fr2 == FALSE))                                                 \
        {                                                                                                       \
            VCCB_PRINT_CRITICAL(                                                                                \
                "XDD is different(fdd=%d, tdd=%d), but FRX is all '0'(fr1=%d, fr2=%d), update FRX capa as all " \
                "support\n",                                                                                    \
                _fdd, _tdd, _fr1, _fr2);                                                                        \
            _fr1 = _fr2 = TRUE;                                                                                 \
        }                                                                                                       \
        if ((_fr1 != _fr2) && (_fdd == FALSE && _tdd == FALSE))                                                 \
        {                                                                                                       \
            VCCB_PRINT_CRITICAL(                                                                                \
                "FRX is different(fr1=%d, fr2=%d), but XDD is all '0'(fdd=%d, tdd=%d), update XDD capa as all " \
                "support\n",                                                                                    \
                _fr1, _fr2, _fdd, _tdd);                                                                        \
            _fdd = _tdd = TRUE;                                                                                 \
        }                                                                                                       \
    }

#define VCCB_GET_GNB_NUM_FROM_ID_COMMON(_gnbId, _gnbNum, _ret)                                                       \
    {                                                                                                                \
        if (VCOM_getSystemType() == e_VCCB_NVGNB || (TRUE == FOO.VF_MultipleOperatorRanSupport))                     \
        {                                                                                                            \
            VCCB_PRINTF(                                                                                             \
                "[%s] VLIB_GetGnbNumFromId ERROR!! NVGNB or MORAN doesn't use this MACRO!! gnbNum(%d)\n", __func__, _gnbNum); \
            VCCB_PRINT_ERROR(                                                                                        \
                "[%s] VLIB_GetGnbNumFromId ERROR!! NVGNB or MORAN doesn't use this MACRO!! gnbNum(%d)\n", __func__, _gnbNum); \
        }                                                                                                            \
        else                                                                                                         \
        {                                                                                                            \
            if (GOOD != VLIB_GetGnbNumFromId(&_gnbNum, _gnbId))                                                      \
            {                                                                                                        \
                VCCB_PRINTF("[%s] VLIB_GetGnbNumFromId ERROR!! gnbId(%d)\n", __func__, _gnbId);                      \
                VCCB_PRINT_ERROR("[%s] VLIB_GetGnbNumFromId ERROR!! gnbId(%d)\n", __func__, _gnbId);                 \
                _ret;                                                                                                \
            }                                                                                                        \
            VCCB_CHECK_RANGE_AND_RETURN_COMMON(_gnbNum, MAX_GNB_PER_SYS, #_gnbNum, _ret)                             \
        }                                                                                                            \
    }

#define VCCB_GET_GNB_NUM_FROM_ID_BREAK(_gnbId, _gnbNum)       VCCB_GET_GNB_NUM_FROM_ID_COMMON(_gnbId, _gnbNum, break)
#define VCCB_GET_GNB_NUM_FROM_ID_CONTINUE(_gnbId, _gnbNum)    VCCB_GET_GNB_NUM_FROM_ID_COMMON(_gnbId, _gnbNum, continue)
#define VCCB_GET_GNB_NUM_FROM_ID_RETURN(_gnbId, _gnbNum)      VCCB_GET_GNB_NUM_FROM_ID_COMMON(_gnbId, _gnbNum, return ERROR)
#define VCCB_GET_GNB_NUM_FROM_ID_RETURN_GOOD(_gnbId, _gnbNum) VCCB_GET_GNB_NUM_FROM_ID_COMMON(_gnbId, _gnbNum, return GOOD)
#define VCCB_GET_GNB_NUM_FROM_ID_RETURN_VOID(_gnbId, _gnbNum) VCCB_GET_GNB_NUM_FROM_ID_COMMON(_gnbId, _gnbNum, return)

#define VCCB_GET_ECGI(__enbId, __cellId) (__enbId << 8 | __cellId)

#define VCCB_CHECK_DUPLEX_TYPE_ERROR(__dupType)                                                                     \
    if ((ci_DUPLEXTYPE_FDD != __dupType) && (ci_DUPLEXTYPE_TDD != __dupType) && (CI_DUPLEXTYPE_SDL != __dupType) && \
        (CI_DUPLEXTYPE_SUL != __dupType))                                                                           \
    {                                                                                                               \
        VCCB_PRINT_ERROR("Wrong Duplex Type!\n");                                                                   \
        return ERROR;                                                                                               \
    }

//------------------------------------------------------------------------------
// VCCB RANGE CHECK MACRO (MAX)
//------------------------------------------------------------------------------
// - NON-UE BASE
#define VCCB_CHECK_RANGE_AND_RETURN_COMMON(__index, __max, __comment, __ret)                                        \
    if (__index >= __max)                                                                                           \
    {                                                                                                               \
        VCCB_PRINT_ERROR(                                                                                           \
            "%s is out of range (%llu:%llu)\n", __comment, (unsigned long long)__index, (unsigned long long)__max); \
        __ret;                                                                                                      \
    }

#define VCCB_CHECK_E_RANGE_AND_CONTINUE(__index, __max) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON(__index, __max, #__index, continue)
#define VCCB_CHECK_E_RANGE_AND_BREAK(__index, __max) VCCB_CHECK_RANGE_AND_RETURN_COMMON(__index, __max, #__index, break)
#define VCCB_CHECK_E_RANGE_AND_GOTO(__index, __max, __goto) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON(__index, __max, #__index, goto __goto)

/** Version for ComAutoNtrace */
#define VCCB_CHECK_RANGE_AND_RETURN_VOID(__index, __max, __comment) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON(__index, __max, __comment, return)
#define VCCB_CHECK_RANGE_AND_RETURN_ERROR(__index, __max, __comment) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON(__index, __max, __comment, return ERROR)

#define VCCB_CHECK_E_RANGE_AND_RETURN(__index, __max) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON(__index, __max, #__index, return ERROR)
#define VCCB_CHECK_E_RANGE_AND_NULL(__index, __max) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON(__index, __max, #__index, return NULL)
#define VCCB_CHECK_E_RANGE_AND_NULLPTR(__index, __max) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON(__index, __max, #__index, return nullptr)
#define VCCB_CHECK_E_RANGE_AND_FALSE(__index, __max) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON(__index, __max, #__index, return FALSE)
#define VCCB_CHECK_E_RANGE_AND_GOOD(__index, __max) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON(__index, __max, #__index, return GOOD)
#define VCCB_CHECK_E_RANGE_AND_VOID(__index, __max) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON(__index, __max, #__index, return)
#define VCCB_CHECK_E_RANGE_AND_DAL_STOP(__index, __max) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON(__index, __max, #__index, return DAL_DB_ITER_STOP)
#define VCCB_CHECK_E_RANGE_AND_VAL(__index, __max, __val) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON(__index, __max, #__index, return __val)
#define VCCB_CHECK_E_RANGE_AND_UNLOCK_VOID(__index, __max, __p) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON(__index, __max, #__index, MUTEX_UNLOCK(__p); return)

// - UE BASE
#define VCCB_CALL_CHECK_RANGE_AND_RETURN_COMMON(__call, __index, __max, __comment, __ret)         \
    if (__index >= __max)                                                                         \
    {                                                                                             \
        VCCB_PRINT_CALL_ERROR(__call, "%s is out of range (%d:%d)\n", __comment, __index, __max); \
        __ret;                                                                                    \
    }

#define VCCB_CALL_CHECK_RANGE_AND_CONTINUE(__call, __index, __max, __comment) \
    VCCB_CALL_CHECK_RANGE_AND_RETURN_COMMON(__call, __index, __max, __comment, continue)
#define VCCB_CALL_CHECK_RANGE_AND_BREAK(__call, __index, __max, __comment) \
    VCCB_CALL_CHECK_RANGE_AND_RETURN_COMMON(__call, __index, __max, __comment, break)
#define VCCB_CALL_CHECK_RANGE_AND_GOTO(__call, __index, __max, __comment, __goto) \
    VCCB_CALL_CHECK_RANGE_AND_RETURN_COMMON(__call, __index, __max, __comment, goto __goto)

/** Version for ComAutoNtrace */
#define VCCB_CALL_CHECK_RANGE_AND_RETURN(__call, __index, __max, __comment) \
    VCCB_CALL_CHECK_RANGE_AND_RETURN_COMMON(__call, __index, __max, __comment, return ERROR)
#define VCCB_CALL_CHECK_RANGE_AND_RETURN_ZERO(__call, __index, __max, __comment) \
    VCCB_CALL_CHECK_RANGE_AND_RETURN_COMMON(__call, __index, __max, __comment, return 0)
#define VCCB_CALL_CHECK_RANGE_AND_RETURN_VOID(__call, __index, __max, __comment) \
    VCCB_CALL_CHECK_RANGE_AND_RETURN_COMMON(__call, __index, __max, __comment, return)

/** Version for ComAutoNtrace */

//------------------------------------------------------------------------------
// VCCB VALID POINTER MACRO
//------------------------------------------------------------------------------

#define VCCB_CHECK_VALID_CELLNUM_ERROR(__cellNum) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON((__cellNum), MAX_CELL_NUM_VCCB, #__cellNum, return ERROR)
#define VCCB_CHECK_VALID_CELLNUM_VOID(__cellNum) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON((__cellNum), MAX_CELL_NUM_VCCB, #__cellNum, return)
#define VCCB_CHECK_VALID_CELLNUM_FALSE(__cellNum) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON((__cellNum), MAX_CELL_NUM_VCCB, #__cellNum, return FALSE)
#define VCCB_CHECK_VALID_CELLNUM_ZERO(__cellNum) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON((__cellNum), MAX_CELL_NUM_VCCB, #__cellNum, return 0)
#define VCCB_CHECK_VALID_CELLNUM_NULL(__cellNum) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON((__cellNum), MAX_CELL_NUM_VCCB, #__cellNum, return NULL)
#define VCCB_CHECK_VALID_CELLNUM_RET_VAL(__cellNum, __ret_val) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON((__cellNum), MAX_CELL_NUM_VCCB, #__cellNum, return __ret_val)

#define VCCB_CHECK_VALID_GNBNUM_FALSE(__gnbNum) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON((__gnbNum), MAX_GNB_PER_SYS, #__gnbNum, return FALSE)
#define VCCB_CHECK_VALID_GNBNUM_ERROR(__gnbNum) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON((__gnbNum), MAX_GNB_PER_SYS, #__gnbNum, return ERROR)
#define VCCB_CHECK_VALID_GNBNUM_VOID(__gnbNum) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON((__gnbNum), MAX_GNB_PER_SYS, #__gnbNum, return)
#define VCCB_CHECK_VALID_GNBNUM_NULL(__gnbNum) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON((__gnbNum), MAX_GNB_PER_SYS, #__gnbNum, return NULL)
#define VCCB_CHECK_VALID_GNBNUM_RET_VAL(__gnbNum, __ret_val) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON((__gnbNum), MAX_GNB_PER_SYS, #__gnbNum, return __ret_val)

//------------------------------------------------------------------------------
// VCCB RANGE CHECK MACRO (MIN ~ MAX)
//------------------------------------------------------------------------------

#define VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_COMMON(__val, __min, __max, __ret)                                     \
    if (!((__min) <= (__val) && (__val) <= (__max)))                                                               \
    {                                                                                                              \
        VCCB_PRINT_ERROR(                                                                                          \
            "Invalid Range(Name:%s, Value:%lld, Min:%d, Max:%d)\n", #__val, (long long)(__val), (__min), (__max)); \
        __ret;                                                                                                     \
    }

#define VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VAL(__val, __min, __max, __ret_val) \
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_COMMON(__val, __min, __max, return __ret_val)
#define VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(__val, __min, __max) \
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_COMMON(__val, __min, __max, return ERROR)
#define VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(__val, __min, __max) \
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_COMMON(__val, __min, __max, return)
#define VCCB_CHECK_RANGE_MIN_MAX_AND_CONTINUE(__val, __min, __max) \
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_COMMON(__val, __min, __max, continue)

//------------------------------------------------------------------------------
// VCCB VALID POINTER MACRO
//------------------------------------------------------------------------------

#define VALID_E_POINT_CHECK_COMMON_RET(__ptr, __ret)              \
    if ((__ptr) == NULL)                                          \
    {                                                             \
        VCCB_PRINT_ERROR("%s (=NULL) in %s\n", #__ptr, __func__); \
        __ret;                                                    \
    }

#define VALID_E_POINT_CHECK_COMMON_RET_PARAM2(__ptr1, __ptr2, __ret)                           \
    if ((__ptr1) == NULL || (__ptr2) == NULL)                                                  \
    {                                                                                          \
        VCCB_PRINT_ERROR("%s(%p) %s(%p) in %s\n", #__ptr1, __ptr1, #__ptr2, __ptr2, __func__); \
        __ret;                                                                                 \
    }

#define VALID_E_POINT_CHECK_COMMON_RET_PARAM3(__ptr1, __ptr2, __ptr3, __ret)                                           \
    if ((__ptr1) == NULL || (__ptr2) == NULL || (__ptr3) == NULL)                                                      \
    {                                                                                                                  \
        VCCB_PRINT_ERROR("%s(%p) %s(%p) %s(%p) in %s\n", #__ptr1, __ptr1, #__ptr2, __ptr2, #__ptr3, __ptr3, __func__); \
        __ret;                                                                                                         \
    }

#define VALID_E_POINT_CHECK_CONTINUE(_ptr_) VALID_E_POINT_CHECK_COMMON_RET(_ptr_, continue)
#define VALID_E_POINT_CHECK_BREAK(_ptr_)    VALID_E_POINT_CHECK_COMMON_RET(_ptr_, break)

/** Version for ComAutoNtrace */
#define VALID_E_POINT_CHECK_ERROR(_ptr_)   VALID_E_POINT_CHECK_COMMON_RET(_ptr_, return ERROR)
#define VALID_E_POINT_CHECK_FALSE(_ptr_)   VALID_E_POINT_CHECK_COMMON_RET(_ptr_, return FALSE)
#define VALID_E_POINT_CHECK_NULL(_ptr_)    VALID_E_POINT_CHECK_COMMON_RET(_ptr_, return NULL)
#define VALID_E_POINT_CHECK_NULLPTR(_ptr_) VALID_E_POINT_CHECK_COMMON_RET(_ptr_, return nullptr)
#define VALID_E_POINT_CHECK_ZERO(_ptr_)    VALID_E_POINT_CHECK_COMMON_RET(_ptr_, return 0)
#define VALID_E_POINT_CHECK_DAL_ITER_STOP(_ptr_) \
    VALID_E_POINT_CHECK_COMMON_RET(_ptr_, return DAL_DB_ITER_STOP)
#define VALID_E_POINT_CHECK_DAL_ERROR(_ptr_)      VALID_E_POINT_CHECK_COMMON_RET(_ptr_, return DAL_ERR)
#define VALID_E_POINT_CHECK_VOID(_ptr_)           VALID_E_POINT_CHECK_COMMON_RET(_ptr_, return)
#define VALID_E_POINT_CHECK_RET_VAL(_ptr_, _ret_) VALID_E_POINT_CHECK_COMMON_RET(_ptr_, return _ret_)

#define VALID_E_POINT_CHECK_ERROR_PARAM2(_ptr1_, _ptr2_) \
    VALID_E_POINT_CHECK_COMMON_RET_PARAM2(_ptr1_, _ptr2_, return ERROR)
#define VALID_E_POINT_CHECK_VOID_PARAM2(_ptr1_, _ptr2_) \
    VALID_E_POINT_CHECK_COMMON_RET_PARAM2(_ptr1_, _ptr2_, return)

#define VALID_E_POINT_CHECK_ERROR_PARAM3(_ptr1_, _ptr2_, _ptr3_) \
    VALID_E_POINT_CHECK_COMMON_RET_PARAM3(_ptr1_, _ptr2_, _ptr3_, return ERROR)
#define VALID_E_POINT_CHECK_VOID_PARAM3(_ptr1_, _ptr2_, _ptr3_) \
    VALID_E_POINT_CHECK_COMMON_RET_PARAM3(_ptr1_, _ptr2_, _ptr3_, return)

#define VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(__ptCi, __ptAll, __ptUnpack) \
    {                                                                           \
        VALID_E_POINT_CHECK_ERROR_PARAM3(__ptCi, __ptAll, __ptUnpack);          \
    }

#define VALID_E_POINTER_CHECK_FOR_STATE_FUNC_VOID(__ptCi, __ptAll, __ptUnpack) \
    {                                                                          \
        VALID_E_POINT_CHECK_VOID_PARAM3(__ptCi, __ptAll, __ptUnpack);          \
    }

//------------------------------------------------------------------------------
// VCCB INCREASE LOCAL STATE MACRO
//------------------------------------------------------------------------------

// - DEPTH 0
#define INCREASE_THREAD_SAFE_COMMON_DEPTH_0(__inc_var) \
    do                                                 \
    {                                                  \
        __inc_var++;                                   \
    } while (0)

#define INCREASE_LOCAL_MAIN_MSG_STAT(__msg) \
    INCREASE_THREAD_SAFE_COMMON_DEPTH_0(VCCB_STAT->localStat.mainTaskMsgStat.__msg)
#define INCREASE_LOCAL_HAS_COMM_STAT(__hasStat) \
    INCREASE_THREAD_SAFE_COMMON_DEPTH_0(VCCB_STAT->localStat.hasComStat.__hasStat)

// - DEPTH 1 - Call Thread
#define INCREASE_THREAD_SAFE_COMMON_DEPTH_1(__thread, __var, __inc_var) \
    do                                                                  \
    {                                                                   \
        const uint32_t Limit = MAX_CALL_THREAD_NUM_VCCB;                \
        if (0 < Limit && Limit <= VCCB_ARRAY_COUNT(__var))              \
        {                                                               \
            __var[__thread % Limit].__inc_var++;                        \
        }                                                               \
    } while (0)

#define INCREASE_LOCAL_MSG_STAT(__thread, __msg) \
    INCREASE_THREAD_SAFE_COMMON_DEPTH_1(__thread, VCCB_STAT->localStat.nrMsgStat, __msg.currCount)

#define INCREASE_LOCAL_HAS_CALL_STAT(__thread, __hasStat) \
    INCREASE_THREAD_SAFE_COMMON_DEPTH_1(__thread, VCCB_STAT->localStat.hasCallStat, __hasStat)
#define INCREASE_LOCAL_HAS_CALL_STAT1(__thread, __hasStat) \
    INCREASE_THREAD_SAFE_COMMON_DEPTH_1(__thread, VCCB_STAT->localStat.hasCallStat1, __hasStat)

#define INCREASE_LOCAL_HO_STAT(__thread, __val) \
    INCREASE_THREAD_SAFE_COMMON_DEPTH_1(__thread, VCCB_STAT->localStat.hoDebugStatInfo, __val)  // ODF_HO_21B

// - DEPTH 2 - Call Thread + VNMB Call Thread
#define INCREASE_LOCAL_MSG_STAT_DST(__thread, __msg, __dst)                                \
    do                                                                                     \
    {                                                                                      \
        const uint32_t Limit = MAX_CALL_THREAD_NUM_VCCB;                                   \
        if (0 < Limit && Limit <= VCCB_ARRAY_COUNT(VCCB_STAT->localStat.nrMsgStat))        \
        {                                                                                  \
            if (__dst < VNMB_CALL_THREAD_NUM)                                              \
            {                                                                              \
                VCCB_STAT->localStat.nrMsgStat[__thread % Limit].__msg[__dst].currCount++; \
            }                                                                              \
        }                                                                                  \
    } while (0)

//------------------------------------------------------------------------------
// Timer Check and Detech MACRO
//------------------------------------------------------------------------------

#define MACRO_CHECK_AND_DETACH(__timer)                 \
    do                                                  \
    {                                                   \
        if ((__timer).id > 0)                           \
        {                                               \
            VCCB_CLEAR_TIMER(&(__timer), CANCEL_TIMER); \
        }                                               \
    } while (0)

//------------------------------------------------------------------------------
// Timer Clear MACRO
// Choose INIT_TIMER when timeout message is received
// Choose CANCEL_TIMER except above.
//------------------------------------------------------------------------------

#define VCCB_CLEAR_TIMER(_pTimer, _type)   \
    do                                     \
    {                                      \
        switch (_type)                     \
        {                                  \
            case INIT_TIMER:               \
                (_pTimer)->id = -1;        \
                break;                     \
            default:                       \
                VLIB_DetachTimer(_pTimer); \
                break;                     \
        }                                  \
    } while (0)

//------------------------------------------------------------------------------
// State Check MACRO : SN init SgNB Rel shall trigger after received Reconfig Complete.
// In case that UE send SCG Fail before Reconfig, Reconfig Complete could be sent.
//------------------------------------------------------------------------------
#define CHECK_STATE_RELEASE_BY_SCG_FAILURE_AFTER_HO_CPLT(__state)                                   \
    ((STATE_DCIntraDuHo_E1DrbModResume == __state) || (STATE_DCIntraDuHo_X2SnStatus == __state) ||  \
        (STATE_DCInterDuHo_E1DrbModResume == __state) || (STATE_DCInterDuHo_X2SnStatus == __state)) \
        ? TRUE                                                                                      \
        : FALSE

//------------------------------------------------------------------------------
// StateCmd Check MACRO
//------------------------------------------------------------------------------
// For NSA
#define CHECK_STATECMD_RELEASE(_p)                                                            \
    ((_p->stateCmd == SgNBReleaseRequest_cmd) || (_p->stateCmd == SgNBReleaseRequired_cmd) || \
        (_p->stateCmd == SgNBReleaseConfirm_cmd) || (_p->stateCmd == X2UeContextRelease_cmd))

#define CHECK_NOT_STATECMD_RELEASE(_p)                                                          \
    ((_p->stateCmd != SgNBReleaseRequest_cmd) && (_p->stateCmd != SgNBReleaseRequired_cmd) &&   \
        (_p->stateCmd != SgNBReleaseConfirm_cmd) && (_p->stateCmd != X2UeContextRelease_cmd) && \
        (_p->state != STATE_Conn_RelCmd) && (_p->state != STATE_Conn_RelCmpl))

// For SA
#define CHECK_STATECMD_RELEASE_MRDC_SN(_p)                                                        \
    ((_p->stateCmd == MrdcSnNodeRelRequest_cmd) || (_p->stateCmd == MrdcSnNodeRelRequired_cmd) || \
        (_p->stateCmd == MrdcSnNodeRelConfirm_cmd))

#define CHECK_SA_STATE_RELEASE(_p)                                            \
    ((_p->state == STATE_Conn_RelCmpl) || (_p->state == STATE_Conn_RelCmd) || \
        (IS_NRDC_SN(_p) && CHECK_STATECMD_RELEASE_MRDC_SN(_p)))

#define IS_SUPPORT_ENDC_SRB3_UECAPA(_p) \
    ((_p)->ueInfo.ueCapa.mrdc.tddCapaAdd.general.srb3_support && GNBINFO[(_p)->gnbNum].cfg.srb3Support)

#define IS_SUPPORT_NRDC_SRB3_UECAPA(_p)          \
    ((_p)->ueInfo.ueCapa.nr.nrdc.srb3_general || \
        (_p)->ueInfo.ueCapa.nr.nrdc.tddCapaAdd.general.srb3_support)  // for 22A Scope
#define IS_SUPPORT_NRDC_SRB3_YANG(_p) ((_p)->gnbNum < MAX_GNB_PER_SYS && GNBINFO[(_p)->gnbNum].cfg.nrdcSrb3Switch)
#define IS_SUPPORT_NRDC_SRB3(_p)      (IS_NRDC_SN(_p) && IS_SUPPORT_NRDC_SRB3_UECAPA(_p) && IS_SUPPORT_NRDC_SRB3_YANG(_p))
#define IS_SUPPORT_NrdcPdcchBlindDetection_YANG(_p) ((_p)->gnbNum < MAX_GNB_PER_SYS && GNBINFO[(_p)->gnbNum].cfg.nrdc.supportPdcchBlindDetection) // FR900


// SVR25B FGR-CC3101
#define IS_STATECMD_FOR_CHECKING_SPECIFIC_SLICE(_ptCi)  \
    (((_ptCi)->stateCmd == RRCConnection_cmd) ||          \
        ((_ptCi)->stateCmd == PDUSetup_cmd)   ||          \
        ((_ptCi)->stateCmd == PDUModify_cmd))

//-------------------------------------------------------------------------------
// VNFC Redundancy macros
//-------------------------------------------------------------------------------
#define HAS_NOTINITIALIZED -1

#define HAS_BACKUP_DATA_CALL_PARTIAL(_ptCi, _addr, _size)                                            \
    {                                                                                                \
        if (ERROR == FnVCCB_BackupCallInfoPartial(_ptCi, _addr, _size))                              \
        {                                                                                            \
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_BackupCallInfoPartial ERROR in %s\n", __FUNCTION__); \
        }                                                                                            \
    }

#if defined(__NVGNB__) || defined(IPC_TEST) || defined(__CNF__) || \
    defined(HOST_SIM_COV_TEST)  // VNFC Redundancy feature

#define HAS_BACKUP_DATA(_key, _addr, _size)
#define HAS_BACKUP_DATA_PER_GNB(_gnbNum, _key, _addr, _size)
#define STANDBY_RETURN_OK
#define IS_UPGRADE_RELAY         0
#define STANDBY_IS_UPGRADE_RELAY 0
#define STANDBY_NONRELAY_RETURN_OK(_msgId)
#define HAS_BLOCK_DAL_READER
#define HAS_BLOCK_DAL_SUBSCRIPTION_NOT_SYNC_CONTINUE
#define HAS_BLOCK_DAL_SUBSCRIPTION_STANDBY_CONTINUE
#define HAS_BLOCK_DAL_SUBSCRIPTION
#define HAS_NOTINITIALIZED_RETURN_OK
#define HAS_NOTINITIALIZED_RETURN
#define GET_REDUNDANT_CPC_ID (CFG->vm.unitId)

#else  // VNFC Redundancy feature ON

#define HAS_BACKUP_DATA(_key, _addr, _size)                                                                    \
    {                                                                                                          \
        int RtCode;                                                                                            \
        if (CFG->hasCpc.State == HAS_NOTINITIALIZED)                                                           \
        {                                                                                                      \
            VCCB_PRINT_COMMENT("%s:HAS not initialized.\n", __FUNCTION__);                                     \
        }                                                                                                      \
        else if (DBG->flag.isSkipHasDirectSync)                                                                \
        {                                                                                                      \
            VCCB_PRINT_COMMENT("%s:HAS Backup Skipped due to flag.", __FUNCTION__);                            \
        }                                                                                                      \
        else                                                                                                   \
        {                                                                                                      \
            MACRO_STATIC_ASSERT((_size) <= VCCB_MAX_CHUNK_SIZE, "Sync Chunk TOO LARGE");                       \
            INCREASE_LOCAL_HAS_COMM_STAT(hasDirectSync_Att);                                                   \
            VCCB_PRINT_COMMENT("%s: hasDirectSync() (comm) is called (%lu)\n", __FUNCTION__, (_size));         \
            RtCode = hasDirectSync((_key), (_addr), (_size));                                                  \
            if (RtCode < 0)                                                                                    \
            {                                                                                                  \
                INCREASE_LOCAL_HAS_COMM_STAT(hasDirectSync_Fail);                                              \
                VCCB_PRINTF_ERR(                                                                               \
                    "%s(LINE:%d) : hasDirectSync(key:%d) fail(%d)\n", __FUNCTION__, __LINE__, (_key), RtCode); \
                VCCB_PRINT_CRITICAL(                                                                           \
                    "%s(LINE:%d) : hasDirectSync(key:%d) fail(%d)\n", __FUNCTION__, __LINE__, (_key), RtCode); \
            }                                                                                                  \
            else                                                                                               \
            {                                                                                                  \
                INCREASE_LOCAL_HAS_COMM_STAT(hasDirectSync_Succ);                                              \
                VCCB_STAT->localStat.hasComStat.syncedSize += (uint32_t)_size;                                 \
            }                                                                                                  \
        }                                                                                                      \
    }

#define HAS_BACKUP_DATA_PER_GNB(_gnbNum, _key, _addr, _size)                                                    \
    {                                                                                                           \
        int RtCode;                                                                                             \
        if (CFG->hasCpc.State == HAS_NOTINITIALIZED)                                                            \
        {                                                                                                       \
            VCCB_PRINT_COMMENT("%s:HAS not initialized.\n", __FUNCTION__);                                      \
        }                                                                                                       \
        else if (DBG->flag.isSkipHasDirectSync)                                                                 \
        {                                                                                                       \
            VCCB_PRINT_COMMENT("%s:HAS Backup Skipped due to flag.", __FUNCTION__);                             \
        }                                                                                                       \
        else                                                                                                    \
        {                                                                                                       \
            if ((_gnbNum) >= MAX_GNB_PER_SYS)                                                                   \
                VCCB_PRINT_CRITICAL("%s:gnbNum(%lu) is too BIG\n", __FUNCTION__, (unsigned long)_gnbNum);       \
            MACRO_STATIC_ASSERT((_size) <= VCCB_MAX_CHUNK_SIZE, "Sync Chunk TOO LARGE");                        \
            INCREASE_LOCAL_HAS_COMM_STAT(hasDirectSync_Att);                                                    \
            VCCB_PRINT_COMMENT("%s: hasDirectSync() (comm) is called (%lu)\n", __FUNCTION__, (_size));          \
            RtCode = hasDirectSync((_key) + _gnbNum, (_addr), (_size));                                         \
            if (RtCode < 0)                                                                                     \
            {                                                                                                   \
                INCREASE_LOCAL_HAS_COMM_STAT(hasDirectSync_Fail);                                               \
                VCCB_PRINTF_ERR("%s(LINE:%d) : hasDirectSync(key:%llu) fail(%d)\n", __FUNCTION__, __LINE__,     \
                    (unsigned long long)((_key) + (_gnbNum)), RtCode);                                          \
                VCCB_PRINT_CRITICAL("%s(LINE:%d) : hasDirectSync(key:%llu) fail(%d)\n", __FUNCTION__, __LINE__, \
                    (unsigned long long)((_key) + (_gnbNum)), RtCode);                                          \
            }                                                                                                   \
            else                                                                                                \
            {                                                                                                   \
                INCREASE_LOCAL_HAS_COMM_STAT(hasDirectSync_Succ);                                               \
                VCCB_STAT->localStat.hasComStat.syncedSize += (uint32_t)_size;                                  \
            }                                                                                                   \
        }                                                                                                       \
    }

#define HAS_NOTINITIALIZED_RETURN_OK                 \
    {                                                \
        if (CFG->hasCpc.State == HAS_NOTINITIALIZED) \
        {                                            \
            return GOOD;                             \
        }                                            \
    }

#define HAS_NOTINITIALIZED_RETURN                    \
    {                                                \
        if (CFG->hasCpc.State == HAS_NOTINITIALIZED) \
        {                                            \
            return;                                  \
        }                                            \
    }

#define IS_STANDBY_AND_SYNC (CFG->hasCpc.State == HAS_STANDBY && CFG->hasCpc.SyncMode == HAS_SYNC_MODE)

#define IS_STANDBY_AND_NOT_SYNC (CFG->hasCpc.State == HAS_STANDBY && CFG->hasCpc.SyncMode != HAS_SYNC_MODE)

#define HAS_BLOCK_DAL_READER     \
    {                            \
        if (IS_STANDBY_AND_SYNC) \
        {                        \
            return DAL_SUCCESS;  \
        }                        \
    }

#define HAS_BLOCK_DAL_SUBSCRIPTION_NOT_SYNC_CONTINUE \
    {                                                \
        if (IS_STANDBY_AND_NOT_SYNC)                 \
        {                                            \
            continue;                                \
        }                                            \
    }

#define HAS_BLOCK_DAL_SUBSCRIPTION_STANDBY_CONTINUE \
    {                                               \
        if (CFG->hasCpc.State == HAS_STANDBY)       \
        {                                           \
            continue;                               \
        }                                           \
    }

#define HAS_BLOCK_DAL_SUBSCRIPTION   \
    {                                \
        if (IS_STANDBY_AND_SYNC)     \
        {                            \
            return DAL_DB_ITER_STOP; \
        }                            \
    }

#define STANDBY_RETURN_OK        \
    {                            \
        if (IS_STANDBY_AND_SYNC) \
        {                        \
            return GOOD;         \
        }                        \
    }

#define IS_UPGRADE_RELAY \
    (CFG->pldCpcState.upgradeStatus == CU_UPGRADE_RELEASE || CFG->pldCpcState.upgradeStatus == CU_UPGRADE_RELAY)

#define STANDBY_IS_UPGRADE_RELAY (CFG->hasCpc.State == HAS_STANDBY && IS_UPGRADE_RELAY)

#define STANDBY_NONRELAY_RETURN_OK(_msgId)                                                                      \
    {                                                                                                           \
        if (CFG->hasCpc.State == HAS_STANDBY && !IS_UPGRADE_RELAY)                                              \
        {                                                                                                       \
            VCCB_PRINT_ERROR("Message(msgId:0x%X,%s) ignored in STANDBY_NONRELAY\n", _msgId, strMsgId(_msgId)); \
            return GOOD;                                                                                        \
        }                                                                                                       \
    }

#define GET_REDUNDANT_CPC_ID (REDUNDANCY_NONE != CFG->hasCpc.HaType ? CFG->vm.unitId / 2 : CFG->vm.unitId)

#endif  // defined(__NVGNB__) || defined(IPC_TEST) || defined(__CNF__) || defined(HOST_SIM_COV_TEST)

#define GET_ARR_SIZE(__arr) (sizeof((__arr)) / sizeof((__arr)[0]))

//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< NEDC
#define IsAvailable_MrdcInfoWithCallInfo(_ptCi) (((_ptCi)->mrdcInfo.usage == CI_use) ? true : false)
#define IsAvailable_MrdcInfo()                  IsAvailable_MrdcInfoWithCallInfo(ptCi)

//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< SliceMappingUsageForDrbMapping
#define IsSupport_SliceMappingUsage_Yang(_gnbNum) \
    ((_gnbNum) < MAX_GNB_PER_SYS && GNBINFO[ptCi->gnbNum].cfg.qosDrbMappingConf.isSliceMappingSupported == VCCB_FLAG_ON)
#define IsSupport_SliceMappingUsage(_gnbNum) \
    IsSupport_SliceMappingUsage_Yang(_gnbNum)

//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< SliceMappingUsageForDrbMapping
#define IsSupport_PlmnMappingUsage_Yang(_gnbNum) \
    ((_gnbNum) < MAX_GNB_PER_SYS && GNBINFO[ptCi->gnbNum].cfg.qosDrbMappingConf.isPlmnMappingSupported == VCCB_FLAG_ON)
#define IsSupport_PlmnMappingUsage(_gnbNum) IsSupport_PlmnMappingUsage_Yang(_gnbNum)

#define IsSupport_RoHC_VoNR()                (FOO.VF_RoHCforVoNR)
#define Is_Support_NullSecurityCounter()     (FOO.VF_CipheringandIntegrityProtectionforSA_22B)
#define Is_Support_NrDlTdoa()                (FOO.VF_NRDownlinkTimeDifferenceOfArrival_22C)
#define Is_Support_MultiRttPositioning_23B() (FOO.VF_MultiRttPositioning_23B)

////////////
#define ON_MRDC_RSC_SETUP_FLAG(_flag)                             \
    do                                                            \
    {                                                             \
        if (IsAvailable_MrdcInfo())                               \
        {                                                         \
            ptCi->mrdcInfo.rscSetupFlag.f_##_flag = VCCB_FLAG_ON; \
        }                                                         \
    } while (0)

#define OFF_MRDC_RSC_SETUP_FLAG(_flag)                             \
    do                                                             \
    {                                                              \
        if (IsAvailable_MrdcInfo())                                \
        {                                                          \
            ptCi->mrdcInfo.rscSetupFlag.f_##_flag = VCCB_FLAG_OFF; \
        }                                                          \
    } while (0)

#define IS_ON_MRDC_RSC_SETUP_FLAG(_flag) (ptCi->mrdcInfo.rscSetupFlag.f_##_flag ? TRUE : FALSE)
///////////
#define ON_MRDC_XN_RCVINDICATOR_FLAG(_flag)                             \
    do                                                                  \
    {                                                                   \
        if (IsAvailable_MrdcInfo())                                     \
        {                                                               \
            ptCi->mrdcInfo.rcvXnInfoIndicator.f_##_flag = VCCB_FLAG_ON; \
        }                                                               \
    } while (0)

#define OFF_MRDC_XN_RCVINDICATOR_FLAG(_flag)                             \
    do                                                                   \
    {                                                                    \
        if (IsAvailable_MrdcInfo())                                      \
        {                                                                \
            ptCi->mrdcInfo.rcvXnInfoIndicator.f_##_flag = VCCB_FLAG_OFF; \
        }                                                                \
    } while (0)

#define CLEAR_MRDC_XN_RCVINDICATOR_FLAG()                \
    do                                                   \
    {                                                    \
        if (IsAvailable_MrdcInfo())                      \
        {                                                \
            ptCi->mrdcInfo.rcvXnInfoIndicator.value = 0; \
        }                                                \
    } while (0)

#define IS_ON_MRDC_XN_RCVINDICATOR_FLAG(_flag) (ptCi->mrdcInfo.rcvXnInfoIndicator.f_##_flag ? TRUE : FALSE)

#define ON_MRDC_XN_SNDINDICATOR_FLAG(_flag)                             \
    do                                                                  \
    {                                                                   \
        if (IsAvailable_MrdcInfo())                                     \
        {                                                               \
            ptCi->mrdcInfo.sndXnInfoIndicator.f_##_flag = VCCB_FLAG_ON; \
        }                                                               \
    } while (0)

#define OFF_MRDC_XN_SNDINDICATOR_FLAG(_flag)                             \
    do                                                                   \
    {                                                                    \
        if (IsAvailable_MrdcInfo())                                      \
        {                                                                \
            ptCi->mrdcInfo.sndXnInfoIndicator.f_##_flag = VCCB_FLAG_OFF; \
        }                                                                \
    } while (0)

#define CLEAR_MRDC_XN_SNDINDICATOR_FLAG()                \
    do                                                   \
    {                                                    \
        if (IsAvailable_MrdcInfo())                      \
        {                                                \
            ptCi->mrdcInfo.sndXnInfoIndicator.value = 0; \
        }                                                \
    } while (0)

#define IS_ON_MRDC_XN_SNDINDICATOR_FLAG(_flag) (ptCi->mrdcInfo.sndXnInfoIndicator.f_##_flag ? TRUE : FALSE)

//////////
#define ON_MRDC_NEED_MODIFY_FLAG(_flag)                        \
    do                                                          \
    {                                                           \
        if (IsAvailable_MrdcInfo())                             \
        {                                                       \
            ptCi->mrdcInfo.needModify.f_##_flag = VCCB_FLAG_ON; \
        }                                                       \
    } while (0)

#define OFF_MRDC_NEED_MODIFY_FLAG(_flag)                        \
    do                                                           \
    {                                                            \
        if (IsAvailable_MrdcInfo())                              \
        {                                                        \
            ptCi->mrdcInfo.needModify.f_##_flag = VCCB_FLAG_OFF; \
        }                                                        \
    } while (0)

#define CLEAR_MRDC_NEED_MODIFY_FLAG()           \
    do                                           \
    {                                            \
        if (IsAvailable_MrdcInfo())              \
        {                                        \
            ptCi->mrdcInfo.needModify.value = 0; \
        }                                        \
    } while (0)

#define IS_ON_MRDC_NEED_MODIFY_FLAG(_flag) (ptCi->mrdcInfo.needModify.f_##_flag ? TRUE : FALSE)
////////////////////////////////////////////////////////////////////////////////////////////////////
#define ON_E1_MRDC_CTRL_FLAG(_drbIdx, _flag)                                 \
    do                                                                       \
    {                                                                        \
        if ((_drbIdx) < MAX_DRB_PER_SA_CALL && IsAvailable_MrdcInfo())       \
        {                                                                    \
            ptCi->mrdcInfo.e1MrdcCtrlFlag[_drbIdx].f_##_flag = VCCB_FLAG_ON; \
        }                                                                    \
    } while (0)

#define OFF_E1_MRDC_CTRL_FLAG(_drbIdx, _flag)                                 \
    do                                                                        \
    {                                                                         \
        if ((_drbIdx) < MAX_DRB_PER_SA_CALL && IsAvailable_MrdcInfo())        \
        {                                                                     \
            ptCi->mrdcInfo.e1MrdcCtrlFlag[_drbIdx].f_##_flag = VCCB_FLAG_OFF; \
        }                                                                     \
    } while (0)

#define CLEAR_E1_MRDC_CTRL_FLAG(_drbIdx)                      \
    do                                                        \
    {                                                         \
        if (IsAvailable_MrdcInfo())                           \
        {                                                     \
            ptCi->mrdcInfo.e1MrdcCtrlFlag[_drbIdx].value = 0; \
        }                                                     \
    } while (0)

#define CLEAR_E1_MRDC_CTRL_FLAG_ALL()                                        \
    do                                                                       \
    {                                                                        \
        if (IsAvailable_MrdcInfo())                                          \
        {                                                                    \
            for (uint8_t drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++) \
            {                                                                \
                ptCi->mrdcInfo.e1MrdcCtrlFlag[drbIdx].value = 0;             \
            }                                                                \
        }                                                                    \
    } while (0)

// The type of _pDi is DRBInfo_type *
#define IS_ON_E1_MRDC_CTRL_FLAG(_pDi, _flag)                                                                 \
    ((_pDi) && ((_pDi)-ptCi->drb) >= 0 && ((_pDi)-ptCi->drb) < MAX_DRB_PER_SA_CALL && IsAvailable_MrdcInfo() \
            ? (ptCi->mrdcInfo.e1MrdcCtrlFlag[(_pDi)-ptCi->drb].f_##_flag ? TRUE : FALSE)                     \
            : FALSE)

// The type of _drbIdx is uint8_t
#define GET_E1_MRDC_CTRL_FLAG(_drbIdx, _flag) (IsAvailable_MrdcInfo() ? ptCi->mrdcInfo.e1MrdcCtrlFlag[_drbIdx].f_##_flag : 0)
#define GET_E1_MRDC_CTRL_FLAG_VALUE(_drbIdx) (IsAvailable_MrdcInfo() ? ptCi->mrdcInfo.e1MrdcCtrlFlag[_drbIdx].value : 0)
///////////////////////////////////////////////////////////////////////////////////////////////////////
#define SET_MRDC_PROCEDURE(_ptCi, _code, _purpose, _initiator)               \
    do                                                                       \
    {                                                                        \
        (_ptCi)->mrdcInfo.procedure.code = _code & e_BitMask_4bit;           \
        (_ptCi)->mrdcInfo.procedure.purpose = _purpose & (uint8_t)e_BitMask_8bit;     \
        (_ptCi)->mrdcInfo.procedure.initiator = _initiator & e_BitMask_1bit; \
    } while (0)

#define SET_MRDC_PROCEDURE_SNREL_OPRTYPE(_ptCi, _snRelOprType)    \
    do                                                            \
    {                                                             \
        (_ptCi)->mrdcInfo.procedure.snRelOprType = _snRelOprType; \
    } while (0)

#define INIT_MRDC_PROCEDURE(_ptCi)             \
    do                                         \
    {                                          \
        (_ptCi)->mrdcInfo.procedure.value = 0; \
    } while (0)

#define GET_MRDC_PROCEDURE_CODE(_ptCi)          ((_ptCi)->mrdcInfo.procedure.code)
#define GET_MRDC_PROCEDURE_PURPOSE(_ptCi)       ((_ptCi)->mrdcInfo.procedure.purpose)
#define GET_MRDC_PROCEDURE_INITIATOR(_ptCi)     ((_ptCi)->mrdcInfo.procedure.initiator)
#define GET_MRDC_PROCEDURE_SNREL_OPRTYPE(_ptCi) ((_ptCi)->mrdcInfo.procedure.snRelOprType)
#define IS_NRDC_SNREL_INVOKED(_ptCi) \
    (IsAvailable_MrdcInfoWithCallInfo(_ptCi) && GET_MRDC_PROCEDURE_CODE(_ptCi) == MRDC_PROC_CODE_SnRel)

// FGR-CC5200:FR10
#define IS_PCELL_FR1(_cellNum) (((_cellNum) < MAX_CELL_NUM_VCCB) && FnVCCB_IsFr1Freq(CELLINFO[_cellNum].ssbArfcn))
// FGR-CC5200:FR494
#define GET_STRICT_SD_CHECK_YANG(_ptCi, _pGnb) ((_pGnb)->cfg.nrdc.check_strict_sd)
// FGR-CC5200:FR482
#define GET_REMOVE_MEAS_ADD_REJECT_YANG(_ptCi) \
    ((_ptCi)->gnbNum < MAX_GNB_PER_SYS && GNBINFO[(_ptCi)->gnbNum].cfg.nrdc.remove_meas_add_reject)
// FGR-CC5200:FR483
#define IS_CAC_BACKOFF_ON_YANG(_ptCi) \
    (MAX_GNB_PER_SYS > (_ptCi)->gnbNum && CI_use == GNBINFO[(_ptCi)->gnbNum].cfg.nrdc.cacBackOff.usage)
// FGR-CC5200:FR103
#define IS_SPLIT_BEARER_ALLOWED_WO_NON_GBR_RSC_OFFERED_IE(_ptCi) \
    (MAX_GNB_PER_SYS > (_ptCi)->gnbNum &&                        \
        VCCB_FLAG_OFF == GNBINFO[(_ptCi)->gnbNum].cfg.nrdc.checkNonGbrResourceOfferedIe)

// FGR-SV1101
#define IS_TERM_POINT_ON_PEER_NODE(_ptCi, _ptDi)                                \
    ((IS_MRDC_MN(_ptCi) && _ptDi->reqBearerType.val == SN_Term_SPLIT_Bearer) || \
        (IS_MRDC_SN(_ptCi) && _ptDi->reqBearerType.val == MN_Term_SPLIT_Bearer))

#define ON_CAC_REJECTED_BY_SN_DU_FLAG(_ptCi)                     \
    do                                                           \
    {                                                            \
        (_ptCi)->mrdcInfo.cacRejectedBySnDu_Flag = VCCB_FLAG_ON; \
    } while (0)
#define OFF_CAC_REJECTED_BY_SN_DU_FLAG(_ptCi)                     \
    do                                                            \
    {                                                             \
        (_ptCi)->mrdcInfo.cacRejectedBySnDu_Flag = VCCB_FLAG_OFF; \
    } while (0)
#define GET_CAC_REJECTED_BY_SN_DU_FLAG(_ptCi) ((_ptCi)->mrdcInfo.cacRejectedBySnDu_Flag)

// FGR-CC5200:FR1030:SVR25A
#define ON_CAC_REJECTED_BY_SN_UP_FLAG(_ptCi)                     \
    do                                                           \
    {                                                            \
        (_ptCi)->mrdcInfo.cacRejectedBySnUp_Flag = VCCB_FLAG_ON; \
    } while (0)
#define OFF_CAC_REJECTED_BY_SN_UP_FLAG(_ptCi)                     \
    do                                                            \
    {                                                             \
        (_ptCi)->mrdcInfo.cacRejectedBySnUp_Flag = VCCB_FLAG_OFF; \
    } while (0)
#define GET_CAC_REJECTED_BY_SN_UP_FLAG(_ptCi) ((_ptCi)->mrdcInfo.cacRejectedBySnUp_Flag)

#define INIT_MN_SELECT_PSCELL_FREQ(_ptCi)                                \
    do                                                                   \
    {                                                                    \
        if (IS_NRDC_MN(_ptCi))                                           \
        {                                                                \
            (_ptCi)->mrdcInfo.SNInfo[SRC_SN].psCell.pScellFrequency = 0; \
        }                                                                \
    } while (0)

#define SET_MN_SELECT_PSCELL_FREQ(_ptCi, _freq)                                \
    do                                                                         \
    {                                                                          \
        if (IS_NRDC_MN(_ptCi))                                                 \
        {                                                                      \
            (_ptCi)->mrdcInfo.SNInfo[SRC_SN].psCell.pScellFrequency = (_freq); \
        }                                                                      \
    } while (0)
// FGR-CC5200:FR483
#define SET_MN_SELECT_PSCELL_NRCGI(_ptCi, _pGnbNbrCell)         \
    do                                                          \
    {                                                           \
        FnVCCB_NrdcSetMnSelectPSCellNrcgi(_ptCi, _pGnbNbrCell); \
    } while (0)

#define GET_MN_SELECT_PSCELL_FREQ(_ptCi) ((_ptCi)->mrdcInfo.SNInfo[SRC_SN].psCell.pScellFrequency)
// FGR-CC5200:FR640
#define IS_VALID_STAT_CTX_REL_TYPE(_mType)            ((_mType) < PSCellDrop_END)

// FGR-CC5200:FR640
#define GET_STAT_NRDC_CTX_REL_CTRL_CellId(_ptCi, _id) ((_ptCi)->mrdcInfo.stat.nrdcCtxRel[_id].ctrl.outstandingCellId)
#define SET_STAT_NRDC_CTX_REL_CTRL_CellId(_ptCi, _id, _ci) \
    ((_ptCi)->mrdcInfo.stat.nrdcCtxRel[_id].ctrl.outstandingCellId = _ci)

// FGR-CC5200:FR640
#define GET_STAT_CTX_REL_ReleaseType(_ptCi, _id) ((_ptCi)->mrdcInfo.stat.nrdcCtxRel[_id].releaseType)
#define SET_STAT_CTX_REL_ReleaseType(_ptCi, _id, _type) ((_ptCi)->mrdcInfo.stat.nrdcCtxRel[_id].releaseType = (enumNrdcCtxRel_type)_type)

// FGR-CC5200:FR641 FGR-CC5021:FR609 FGR-CC5203:FR231 STAT_NRDC_CTX_REL_SERVICE_TYPE
#define IS_SERVICE_TYPE_INDEX_VALID_FOR_STAT_NRDC_CTX_REL_SERVICE_TYPE(_ptCi) ((_ptCi)->mrdcInfo.stat.isNrdcCtxRelServiceTypeValid)

#define GET_SERVICE_TYPE_INDEX_FOR_STAT_NRDC_CTX_REL_SERVICE_TYPE(_ptCi, _serviceTypeList) \
    do                                                                                     \
    {                                                                                      \
        uint64_t markedServiceType = (_ptCi)->mrdcInfo.stat.nrdcCtxRelServiceType;         \
        for (uint32_t idx = 0; idx < MAX_SERVICE_TYPE_NUM; idx++)                          \
        {                                                                                  \
            if (GETBIT(markedServiceType, idx))                                            \
            {                                                                              \
                _serviceTypeList.insert(idx);                                              \
            }                                                                              \
        }                                                                                  \
    } while (0)

#define CLEAR_SERVICE_TYPE_INDEX_FOR_STAT_NRDC_CTX_REL_SERVICE_TYPE(_ptCi)                  \
    do                                                                                      \
    {                                                                                       \
        (_ptCi)->mrdcInfo.stat.isNrdcCtxRelServiceTypeValid = VCCB_FLAG_OFF;                \
        (_ptCi)->mrdcInfo.stat.nrdcCtxRelServiceType = 0;                                   \
    } while(0)

#define SET_SERVICE_TYPE_INDEX_FOR_STAT_NRDC_CTX_REL_SERVICE_TYPE(_ptCi)                                               \
    do                                                                                                                 \
    {                                                                                                                  \
        CLEAR_SERVICE_TYPE_INDEX_FOR_STAT_NRDC_CTX_REL_SERVICE_TYPE(_ptCi);                                            \
        if (IS_SUPPORT_CollectNrdcCtxRelServiceTypeStats(_ptCi))                                                       \
        {                                                                                                              \
            uint64_t serviceType = 0;                                                                                  \
            std::set<uint32_t> serviceTypeList;                                                                        \
            MACRO_GET_CALL_SERVICE_TYPE(_ptCi, serviceTypeList);                                                       \
            for (auto iter : serviceTypeList)                                                                          \
            {                                                                                                          \
                ONBIT(serviceType, iter);                                                                              \
            }                                                                                                          \
            VCCB_PRINT_CALL_INFORMATIVE(                                                                               \
                _ptCi, "[NRDC][SN] Set ServiceTypeIndex(0x%llx) - LSB:#0/MSB:#63\n", (long long unsigned)serviceType); \
            (_ptCi)->mrdcInfo.stat.isNrdcCtxRelServiceTypeValid = VCCB_FLAG_ON;                                        \
            (_ptCi)->mrdcInfo.stat.nrdcCtxRelServiceType = serviceType;                                                \
        }                                                                                                              \
    } while (0)

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define IsReady_UeCapa_EUTRA()                         \
    (ptCi->ueContainerEUTRA.rxFlag == VCCB_FLAG_ON) && \
        ((ptCi->ueContainerEUTRA.numocts > 0) || (ptCi->ueContainerEUTRA_Ext.capaLength > 0))
#define IsReady_UeCapa_MRDC()                         \
    (ptCi->ueContainerMRDC.rxFlag == VCCB_FLAG_ON) && \
        ((ptCi->ueContainerMRDC.numocts > 0) || (ptCi->ueContainerMRDC_Ext.capaLength > 0))
#define IsReady_UeCapa_NEDC() (IsReady_UeCapa_EUTRA() && IsReady_UeCapa_MRDC())

#define NEDC_PowerAllocMode(_cellNum) CELLINFO[_cellNum].nedcPowerConfig.nedcOperatorSpecificPowerAllocation
#define NEDC_PowerOffset(_cellNum)    CELLINFO[_cellNum].nedcPowerConfig.nedcPowerOffsetNrFr1

#define RESET_APPLIED_FREQBAND_LIST()                    \
    do                                                   \
    {                                                    \
        ptCi->ueInfo.ueCapa.appliedFreqBandList.num = 0; \
    } while (0)

#define SET_MRDC_XN_EP(status)                                          \
    do                                                                  \
    {                                                                   \
        ptCi->endPointInfo.xnIdx = ptCi->mrdcInfo.SNInfo[SRC_SN].epIdx; \
        status = GOOD;                                                  \
    } while (0)

#define IS_SN_ADDITION_ONGOING(_ptCi)                                                                  \
    (((STATE_SNAddPrepare_E1Mod1 <= (_ptCi)->state) && (STATE_SNAddComplt_XnMod >= (_ptCi)->state)) || \
        ((STATE_Conn == (_ptCi)->state) &&                                                             \
            ((MrdcE1ScgAdd_cmd == (_ptCi)->stateCmd) || (MrdcXnSNAdd_cmd == (_ptCi)->stateCmd))))

#define IS_SN_ONLY_MOBILITY_ONGOING(_ptCi) \
    ((STATE_MN_INTER_SN_Pre_SN <= (_ptCi)->state) && (STATE_MN_INTER_SN_Complete >= (_ptCi)->state)) || \
    ((STATE_MN_SNMob_TxStop <= (_ptCi)->state) && (STATE_MN_SNMob_TxResume >= (_ptCi)->state))

#define IS_SN_RELEASE_ONGOING_LRC(_ptCi)\
      ((STATE_SNRelPrepare_E1Mod <= (_ptCi)->state) && (STATE_SNRelComplt_E1Mod >= (_ptCi)->state)) || \
      ((STATE_Intra_Cell_SnRelA <= (_ptCi)->state) && (STATE_Intra_Cell_SnRelB >= (_ptCi)->state))

#define IS_SUPPORT_ENC_XNSNStatusTransfer(_ptCi) ((_ptCi)->xnStatusTransferEnhancementOnOff == VCCB_FLAG_ON)

#define IS_NOT_MRDC_SCG_RELEASE_ONGOING(_ptCi)                                               \
        (((TRUE == IsAvailable_MrdcInfoWithCallInfo(_ptCi)) && (FALSE == IS_NRDC_SNREL_INVOKED(_ptCi))) &&  \
         !((IntraRatHO_cmd == (_ptCi)->stateCmd  || IntraCellHO_cmd == (_ptCi)->stateCmd) && \
           (ci_scg_released_ue == (_ptCi)->mrdcInfo.mobilityCfg.ueState)))

// NEDC_SCG_FAILURE_20C START

// #define NEDC_SCG_FAILURE_FEATURE_ON() (TRUE == FOO.VF_SCGFailureHandlingforNEDC) - obsolete since 2020.10.27
#define NEDC_SCG_FAILURE_FEATURE_ON() \
    (TRUE == FOO.VF_BasicOperationforNEDC_CALL)  // unified into F_BasicOperationforNEDC_CALL
#define NEDC_SCG_FAILURE_HANDLING_MODE(_gnbNum, _failType) \
    GNBINFO[_gnbNum].cfg.scgFailureHandlingInfo.nedc_failureCauseType[_failType].handlingOption
#define NEDC_SCG_FAILURE_BLACKCELL_FEATURE_ON(_gnbNum) GNBINFO[_gnbNum].cfg.blackCellInfo.support
#define NEDC_SCG_FAILURE_BLACKCELL_TIME(_gnbNum)       GNBINFO[_gnbNum].cfg.blackCellInfo.time
#define NEDC_SCG_FAILURE_QUEUEING_REQUIRED()           (ptCi->stateCmd != Idle_cmd || ptCi->state != STATE_Conn)
#define NEDC_SCG_FAILURE_BLACKLIST(_idx)               (ptCi->ueInfo.blacklistedCell.blacklist[_idx])
#define NEDC_SCG_FAILURE_HAPPEN()                      (ptCi->nedcScgFailCauseInfo != 0xFF)
#define NRDC_SCG_FAILURE_HAPPEN()                      (ptCi->nrdcScgFailureInfo.failType != NRDC_SCG_FAIL_CAUSE_TYPE_MAX)

#define IS_SCG_SUSPENDED(_ptCi)                                            \
    ((NrDcScgFailure_MnInit_Suspend == _ptCi->nrdcScgFailureInfo.event) || \
        (NrDcScgFailure_SnInit_Suspend == _ptCi->nrdcScgFailureInfo.event))

#define IS_SCG_RESUMING(_ptCi) (NrDcScgFailure_MnInit_Resume == (_ptCi)->nrdcScgFailureInfo.event)

#define IS_NRDC_SCG_FAILURE_HANDLING_ONGOING(_ptCi) (IS_SCG_SUSPENDED(_ptCi) || IS_SCG_RESUMING(_ptCi))

#define IS_NRDC_HO_SCG_RESUME(_ptCi)                             \
    (IS_NRDC_SN(_ptCi) && (IntraRatHO_cmd == _ptCi->stateCmd) && \
        (HO_TYPE_SA_MN_INIT_SCG_RESUME == _ptCi->hoInfo.hoType.initiated))

// RETAIN_STAT_HO_21A
#define IS_INTER_GNB_HO()                                                   \
    ((ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_INTER_GNB_NG_HANDOVER) || \
        (ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_INTER_GNB_XN_HANDOVER))

// RETAIN_STAT_HO_21C
#define IS_INTER_GNB_NG_HO() (ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_INTER_GNB_NG_HANDOVER)

// RETAIN_STAT_HO_21C
#define IS_INTER_GNB_XN_HO() (ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_INTER_GNB_XN_HANDOVER)

#define IS_INTERRAT_HO()                                                              \
    ((ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_INTER_SYSTEM_INTER_RAT_HANDOVER) || \
        (ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_INTRA_SYSTEM_INTER_RAT_HANDOVER))  // TBD

// RETAIN_STAT_HO_21C
#define IS_ONDEMAND_HO() (TRUE == ptCi->onDemandInfo.hoTriggered) 
#define IS_ONDEMAND_REDIRECT() (TRUE == ptCi->redirectionInfo.onDemandRedirect)
#define IS_ONDEMAND_RELEASE() (TRUE == ptCi->onDemandInfo.release)

#define IS_USTM_ONGOING(_ptCi) (IS_TIMER_VALID(_ptCi->ustmInfo.timer) || (TRUE == _ptCi->ustmInfo.measConfFilteringActive))
#define IS_USTM_HO(_ptCi) (TRUE == (_ptCi)->ustmInfo.intraNrHandoverTriggered)
#define IS_USTM_REDIRECT(_ptCi) (TRUE == (_ptCi)->ustmInfo.redirectionTriggered)
#define IS_USTM_RELEASE(_ptCi) (TRUE == (_ptCi)->ustmInfo.releaseTriggered)

#define IS_INTRA_RAT_REDIRECTION() (INTRA_RAT_REDIRECTION == ptCi->redirectionInfo.redirType)
#define IS_INTER_RAT_REDIRECTION() (INTER_RAT_REDIRECTION == ptCi->redirectionInfo.redirType)

#define IS_INTRA_GNB_HO()                                                         \
    ((ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_INTRA_GNB_INTRA_DU_HANDOVER) || \
        (ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_INTRA_GNB_INTER_DU_HANDOVER))

#define VHCM_RETAIN_STAT_INTRA_GNB_HO()                                                       \
    do                                                                                        \
    {                                                                                         \
        if (IS_INTRA_GNB_HO())                                                                \
        {                                                                                     \
            VLIB_SaveEventForCallRetainStat(ptCi, RetainCategory_IntraGnbHandover, 0);        \
            VLIB_CollectRetainStat_IntraGnbHO(ptCi);                                          \
            uint32_t collectFailToSetupStat = VCCB_FLAG_OFF;                                  \
            SET_ON_ALL_RETAIN_STAT_CAPABLE_FLAG(ptCi, collectFailToSetupStat, VCCB_FLAG_OFF); \
        }                                                                                     \
    } while (0)

// for STAT_NEDC_SCG_FAIL_OPER family
#define VHCM_NEDC_SCG_FAILURE_STAT()       \
    do                                     \
    {                                      \
        if (NEDC_SCG_FAILURE_FEATURE_ON()) \
        {                                  \
            VLIB_StatNedcScgFailure(ptCi); \
        }                                  \
    } while (0)
#define RESET_NEDC_SCG_FAILINFO()          \
    do                                     \
    {                                      \
        ptCi->nedcScgFailCauseInfo = 0xFF; \
    } while (0)

// NEDC_SCG_FAILURE_20C END

// NRDC_SCG_FAILURE_21D
#define NRDC_SCG_FAILURE_FEATURE_ON() (FOO.VF_BasicOperationforNRDC_CALL)  // included in NRDC basic function

// SVR23A FGR-CC5203
#define NRDC_SCG_FAILURE_BLOCKGNB_FEATURE_ON(_ptCi) \
    (NRDC_SCG_FAILURE_FEATURE_ON() && _ptCi->blockListInfo.usage == VCCB_FLAG_ON)

#define VHCM_NRDC_SCG_FAILURE_STAT()       \
    do                                     \
    {                                      \
        if (NRDC_SCG_FAILURE_FEATURE_ON()) \
        {                                  \
            VLIB_StatNrdcScgFailure(ptCi); \
        }                                  \
    } while (0)

#define RESET_NRDC_SCG_FAILINFO(_ptCi)                                      \
    do                                                                      \
    {                                                                       \
        _ptCi->nrdcScgFailureInfo.failType = NRDC_SCG_FAIL_CAUSE_TYPE_MAX;  \
        _ptCi->nrdcScgFailureInfo.event = NrDcScgFailure_NoEvent;           \
        _ptCi->nrdcScgFailureInfo.prevEvent = NrDcScgFailure_NoEvent;       \
        _ptCi->nrdcScgFailureInfo.failAction = NrDcScgFailureSnRelease;     \
        _ptCi->nrdcScgFailureInfo.scgMrIncluded = VCCB_FLAG_OFF;            \
        _ptCi->nrdcScgFailureInfo.A4Configured = VCCB_FLAG_OFF;             \
        _ptCi->nrdcScgFailureInfo.snRelFlag = VCCB_FLAG_OFF;                \
        _ptCi->nrdcScgFailureInfo.preserveFlag = VCCB_FLAG_OFF;             \
        _ptCi->nrdcScgFailureInfo.targetPsCellNum = UINT16_MAX;             \
        _ptCi->nrdcScgFailureInfo.targetPsCellBand = UINT16_MAX;            \
        _ptCi->hoInfo.hoType.initiated = HO_TYPE_SGNB_INITIATED;            \
    } while (0)

// SVR24A FGR-CC5203 FR230
#define CONVERT_AND_SAVE_NRDC_CTX_REL(_ptCi, _msgId)                                        \
    do                                                                                      \
    {                                                                                       \
        int relType = FnVCCB_NrdcCtxRelStat_ConvertXnCauseToSnCtxRelType(_ptCi, _msgId);    \
        if (IS_VALID_STAT_CTX_REL_TYPE(relType))                                            \
        {                                                                                   \
            FnVCCB_NrdcCtxRelStat_SaveSnRelType(_ptCi, relType, SRC_SN);                    \
        }                                                                                   \
    } while (0)

// NRDC_SCG_FAILURE_22C2
#define NOT_ALLOW_SN_ADDITION_UE_SIGNATURE(_ptCi)                 \
    (VCCB_FLAG_ON == _ptCi->nrdcScgFailureInfo.ueSignatureFlag && \
        VCCB_FLAG_ON != _ptCi->nrdcScgFailureInfo.allowSNAdditionUECustomSignature)

#define NOT_ALLOW_SN_ADDITION_DURING_RRC_INACTIVE_TRANSITION(_ptCi) (_ptCi->ueInfo.rrcResumeInfo.preventSNAddFlag)

#define SET_E1_CELL_GROUP_UL_CONFIG_FOR_SCG_HANDLING_MNTERM(_pCellGroup, _ulConfig)                                 \
    do                                                                                                              \
    {                                                                                                               \
        if (MN_Term_SPLIT_Bearer == pDRBInfo->bearerType.val)                                                       \
        {                                                                                                           \
            if ((MrdcScgFailSuspend_cmd == ptCi->stateCmd && STATE_MN_SCGSuspend_XnMod == ptCi->state) ||           \
                (MrdcScgFailResume_cmd == ptCi->stateCmd &&                                                         \
                    (STATE_MN_SCGResume_XnMod == ptCi->state || STATE_MN_SCGResume_F1ReconfigCmpl == ptCi->state))) \
            {                                                                                                       \
                _pCellGroup->bit_mask |= E1_Cell_Group_Information_Item_uL_Configuration_present;                   \
                _pCellGroup->uL_Configuration = _ulConfig;                                                          \
            }                                                                                                       \
        }                                                                                                           \
    } while (0)

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// NG_HOREQ_PDU_QFI_DIFF_21B
#define HO_PDU_QFI_CHECK_RQD() \
    (ptCi->hoInfo.hoType.nb == HO_TYPE_INTER_NB && ptCi->hoInfo.isTarget == True && IntraRatHO_cmd == ptCi->stateCmd)

#define CREATE_DRB_ON_PDU_MACRO(_ptCi, _ptPi, _drbIdxInPdu, _drbIdxInCall)                                           \
    do                                                                                                               \
    {                                                                                                                \
        if ((ERROR == VLIB_AllocCallDrbInfo(_ptCi, _ptPi, &_drbIdxInPdu)) || (_drbIdxInPdu >= MAX_DRB_PER_PDU_SESS)) \
        {                                                                                                            \
            VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_AllocCallDrbInfo Macro ERROR!\n");                                     \
            return ERROR;                                                                                            \
        }                                                                                                            \
                                                                                                                     \
        _drbIdxInCall = ptPi->drbIndex[_drbIdxInPdu];                                                                \
        VCCB_CHECK_E_RANGE_AND_RETURN(_drbIdxInCall, MAX_DRB_PER_SA_CALL);                                           \
                                                                                                                     \
        SET_DRB_STATUS(_ptCi, _drbIdxInCall, S_Setup);                                                               \
                                                                                                                     \
        ptDi = &ptCi->drb[_drbIdxInCall];                                                                            \
                                                                                                                     \
        ptDi->pduIdxInCall = pdu_idx;                                                                                \
    } while (0)

// ODF_HO_21B START

#define INIT_FLAG_FALSE(_flag) (_flag = false)  // ODF_HO_21B
#define IS_FLAG_TRUE(_flag)    (_flag == true)  // ODF_HO_21B
#define TRIGGER_ODF_HO(_flag)                     \
    {                                             \
        if (IS_FLAG_TRUE(_flag))                  \
        {                                         \
            VIIL_sendInternalTriggerOnDemandHo(); \
        }                                         \
    }

#define ODHO_CELL_OPERATION_MODE(_cellNum)           ((CELLINFO[_cellNum].onDemandHoInfo.operationMode))
#define ODHO_CELL_PREFER_RAT_FOR_VOICECALL(_cellNum) ((CELLINFO[_cellNum].onDemandHoInfo.preferRatForVoiceCall))
#define ODHO_CELL_PREFER_RAT_FOR_DATACALL(_cellNum)  ((CELLINFO[_cellNum].onDemandHoInfo.preferRatForDataCall))

#define IS_SUPPORT_ODHO(_cellNum)         ((CELLINFO[_cellNum].onDemandHoInfo.onDemandHoSupport == TRUE))

/* cell shutdown time(struct timespec) */
#define IS_INITIAL_SHUTDOWN_TIME(_shutdownTime) ((_shutdownTime.tv_sec == 0) && (_shutdownTime.tv_nsec == 0))

/* call release time expired */
#define IS_CALL_RELEASE_TIMER_EXPIRED(_cellNum) (ENV->onDemandLoadDistCtrl.shutdownCellInfo[_cellNum].expiredFlag)

// ODF_HO_21B END

// NR_CONN_MC_23A SDL definition is changed as of 23A, DL-only direction for inter gNB, MAX_A6_NR_ARFCN for intra gNB
#define IS_NBR_SDLCELL(_ptNbrGnbCell) (MAX_A6_NR_ARFCN == _ptNbrGnbCell->nrArfcnUl)
#define IS_IF_HO_WITH_MGAP(_ptCi, _tgtSsbFreq)      \
    (VCCB_IS_INTER_FREQ_SSB_FREQ(_ptCi->servCellNum, _tgtSsbFreq) && (_ptCi->hoInfo.mrWithMGap == TRUE))

#define RESET_SN_COUNTER()                          \
    do                                              \
    {                                               \
        ptCi->security.snCounter = -1;              \
        ptCi->security.snCounterChangeFlag = FALSE; \
    } while (0)

#define INCREASE_SN_COUNTER()                                                      \
    do                                                                             \
    {                                                                              \
        ptCi->security.snCounter++;                                                \
        ptCi->security.snCounterChangeFlag = TRUE;                                 \
        if (ptCi->security.snCounter >= 65535)                                     \
        {                                                                          \
            if (ERROR == VLIB_EnqueueIntraCellHO(ptCi))                            \
            {                                                                      \
                VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_EnqueueIntraCellHO ERROR !!\n"); \
            }                                                                      \
        }                                                                          \
    } while (0)

#define VCCB_CANDIDATE_CELL_PRINT(__step, __listForSort)                                                         \
    do                                                                                                           \
    {                                                                                                            \
        VCCB_PRINT_CALL_COMMENT(ptCi, #__step "\n");                                                             \
        VCCB_PRINT_CALL_COMMENT(ptCi, "[id] pcid | cellNum | priority | rsrp | ueCount\n");                      \
        uint16_t _loop = 0;                                                                                      \
        for (_loop = 0; _loop < MIN((__listForSort).nrofCells, MAX_NUM_CANDIDATE_CELL_FOR_PSCELL); _loop++)      \
        {                                                                                                        \
            VCCB_PRINT_CALL_COMMENT(ptCi, "[%2d] %4d | %7d | %8d | %4.*d | %7d\n", _loop,                        \
                (__listForSort).candidateCell[_loop].physCellId, (__listForSort).candidateCell[_loop].cellNum,   \
                (__listForSort).candidateCell[_loop].priority,                                                   \
                (FALSE != (__listForSort).candidateCell[_loop].rsrpFlag),                                        \
                ((__listForSort).candidateCell[_loop].rsrpFlag ? (__listForSort).candidateCell[_loop].rsrp : 0), \
                (__listForSort).candidateCell[_loop].ueCount);                                                   \
        }                                                                                                        \
    } while (0)

#define VCCB_CANDIDATES_NR_FREQ_ITEMS_PRINT(__step, _candidatesNrFreqItems, _numCandidateNrFreqItems) \
    do                                                                                                \
    {                                                                                                 \
        VCCB_PRINT_CALL_COMMENT(ptCi, #__step "\n");                                                  \
        VCCB_PRINT_CALL_COMMENT(ptCi,                                                                 \
            "[id] usage | freqIdx | targetMeasObjectEntriesindex | cellReselectionPriority | "        \
            "cellReselectionSubpriorityUsage | cellReselectionSubpriority\n");                        \
        uint16_t loop = 0;                                                                            \
        for (loop = 0; loop < MIN(_numCandidateNrFreqItems, MAX_NUM_RFSP_NR_FREQS); loop++)           \
        {                                                                                             \
            VCCB_PRINT_CALL_COMMENT(ptCi, "[%2d] %5d | %7d | %28d | %23d | %31d | %26d\n", loop,      \
                _candidatesNrFreqItems[loop].usage, _candidatesNrFreqItems[loop].freqIdx,             \
                _candidatesNrFreqItems[loop].targetMeasObjectEntriesindex,                            \
                _candidatesNrFreqItems[loop].cellReselectionPriority,                                 \
                _candidatesNrFreqItems[loop].cellReselectionSubpriorityUsage,                         \
                _candidatesNrFreqItems[loop].cellReselectionSubpriority);                             \
        }                                                                                             \
    } while (0)

#define VCCB_CANDIDATES_NR_FREQ_ITEMS_NRDC_PRINT(__step, _candidatesNrFreqItems, _numCandidateNrFreqItems) \
    do                                                                                                     \
    {                                                                                                      \
        VCCB_PRINT_CALL_COMMENT(ptCi, #__step "\n");                                                       \
        VCCB_PRINT_CALL_COMMENT(ptCi,                                                                      \
            "[id] usage | freqIdx | tgtMeasObjEntriesidx | Priority | "                                    \
            "SubpriorityUsage | Subpriority\n");                                                           \
        uint16_t loop = 0;                                                                                 \
        for (loop = 0; loop < MIN(_numCandidateNrFreqItems, MAX_NUM_RFSP_NR_FREQS); loop++)                \
        {                                                                                                  \
            VCCB_PRINT_CALL_COMMENT(ptCi, "[%2d] %5d | %7d | %20d | %8d | %16d | %11d\n", loop,            \
                _candidatesNrFreqItems[loop].usage, _candidatesNrFreqItems[loop].freqIdx,                  \
                _candidatesNrFreqItems[loop].targetMeasObjectEntriesindex,                                 \
                _candidatesNrFreqItems[loop].nrdcCellReselectionPriority,                                  \
                _candidatesNrFreqItems[loop].nrdcCellReselectionSubpriorityUsage,                          \
                _candidatesNrFreqItems[loop].nrdcCellReselectionSubpriority);                              \
        }                                                                                                  \
    } while (0)

// SVR25A FGR-CC5005:FR40
#define VCCB_PRINT_LOG_NSA_CSL_DROP_RATE(_ptCi)                                                                          \
    do                                                                                                               \
    {                                                                                                                \
        if (DBG->flag.logNsaStatCsl)                                                                                 \
        {                                                                                                            \
            for (uint8_t loop = 0; loop < MAX_QCI_HISTORY_STORING_CAPACITY; ++loop)                                  \
            {                                                                                                        \
                auto LRQ = _ptCi->qciCount.LatestReleasedQci[loop];                                                  \
                VCCB_PRINT_CALL_INFORMATIVE(_ptCi,                                                                   \
                    "%s qci(%d), gNBInitErabRel(%d), gNBInitAbErabRel(%d), gNBInitAbErabRelAct(%d)\n", __FUNCTION__, \
                    LRQ.qci, LRQ.gNBInitiatedErabRelease, LRQ.gNBInitiatedAbnormalErabRelease,                       \
                    LRQ.gNBInitiatedAbnormalErabReleaseWithActiveBearer);                                            \
                VCCB_PRINT_CALL_INFORMATIVE(_ptCi,                                                                   \
                    "MeNBInitErabRel(%d), MeNBInitAbErabRel(%d), MeNBInitAbErabRelAct(%d)\n",                        \
                    LRQ.MeNBInitiatedErabRelease, LRQ.MeNBInitiatedAbnormalErabRelease,                              \
                    LRQ.MeNBInitiatedAbnormalErabReleaseWithActiveBearer);                                           \
            }                                                                                                        \
        }                                                                                                            \
    } while (0)

// SVR25A FGR-CC5000:FR3590
#define VCCB_PRINT_LOG_NSA_CSL_ACCESSIBILITY(_ptCi)                                                                    \
    do                                                                                                             \
    {                                                                                                              \
        if (DBG->flag.logNsaStatCsl)                                                                               \
        {                                                                                                          \
            for (uint8_t loop = 0; loop < MAX_QCI_HISTORY_STORING_CAPACITY; ++loop)                                \
            {                                                                                                      \
                auto qciAccess = _ptCi->qciCount.QciAttemptSuccessData[loop];                                      \
                VCCB_PRINT_CALL_INFORMATIVE(_ptCi, "%s qci(%d), att(%d), succ(%d)\n", __FUNCTION__, qciAccess.qci, \
                    qciAccess.attempt, qciAccess.success);                                                         \
            }                                                                                                      \
        }                                                                                                          \
    } while (0)

#define GET_DRBIDX(_drbID, _drbIdx, _rtCode)                                          \
    do                                                                                \
    {                                                                                 \
        uint8_t loop;                                                                 \
        for (loop = 0; loop < MAX_DRB_PER_SA_CALL; loop++)                            \
        {                                                                             \
            if (!IS_VALID_NODE(DRB_NODE, ptCi, &ptCi->drb[loop])) continue;           \
            if (ptCi->drb[loop].dRBId == _drbID) break;                               \
        }                                                                             \
        if (loop >= MAX_DRB_PER_SA_CALL)                                              \
        {                                                                             \
            VCCB_PRINT_CALL_ERROR(ptCi, "Cannot find matched DRB id(%ld)\n", _drbID); \
            return _rtCode;                                                           \
        }                                                                             \
        _drbIdx = loop;                                                               \
    } while (0)

#define SET_QOSFLOW_STATUS_PER_DRB(_status)                                   \
    do                                                                        \
    {                                                                         \
        uint8_t _drbQosIdx = 0;                                               \
        uint16_t qosFlowIdx = 0;                                              \
        for (_drbQosIdx = 0; _drbQosIdx < MAX_QOS_FLOW_PER_DRB; _drbQosIdx++) \
        {                                                                     \
            qosFlowIdx = ptDi->qosFlowIndex[_drbQosIdx];                      \
            if (qosFlowIdx >= MAX_QOS_FLOW_PER_CALL) continue;                \
            if ((ptCi->qosFlow[qosFlowIdx].qosFlowStatus == S_Idle) ||        \
                (ptCi->qosFlow[qosFlowIdx].qosFlowStatus == S_Setup) ||       \
                (ptCi->qosFlow[qosFlowIdx].qosFlowStatus == S_Modify))        \
            {                                                                 \
                SET_QOSFLOW_STATUS(ptCi, qosFlowIdx, _status);                \
            }                                                                 \
        }                                                                     \
    } while (0)

#define SET_ALL_QOSFLOW_STATUS_PER_DRB(_status)                                        \
    do                                                                             \
    {                                                                              \
        uint8_t _drbQosIdx = 0; \
        uint16_t qosFlowIdx = 0;                                                    \
        for (_drbQosIdx = 0; _drbQosIdx < MAX_QOS_FLOW_PER_DRB; _drbQosIdx++)      \
        {                                                                          \
            qosFlowIdx = ptDi->qosFlowIndex[_drbQosIdx]; \
            if (qosFlowIdx >= MAX_QOS_FLOW_PER_CALL) continue; \
            SET_QOSFLOW_STATUS(ptCi, qosFlowIdx, _status);     \
        }                                                                          \
    } while (0)

#define SET_DRB_STATUS_PER_PDUSESS(_ptCi, _pduIdx, _status)     \
    do                                                          \
    {                                                           \
        if (!(_ptCi)) break;                                    \
        if ((_pduIdx) >= MAX_PDU_SESS_PER_CALL) break;          \
                                                                \
        uint16_t loop = 0, drbIdx = 0;                          \
        for (loop = 0; loop < MAX_DRB_PER_PDU_SESS; loop++)     \
        {                                                       \
            drbIdx = (_ptCi)->pduSess[_pduIdx].drbIndex[loop];  \
            if (drbIdx >= MAX_DRB_PER_SA_CALL) continue;        \
            if ((_ptCi)->drb[drbIdx].usage != CI_use) continue; \
            SET_DRB_STATUS(_ptCi, drbIdx, _status);             \
        }                                                       \
    } while (0)

#define SET_QOSFLOW_STATUS_PER_PDUSESS(_ptCi, _pduIdx, _status)         \
    do                                                                  \
    {                                                                   \
        if (!(_ptCi)) break;                                            \
        if ((_pduIdx) >= MAX_PDU_SESS_PER_CALL) break;                  \
                                                                        \
        uint16_t loop = 0, qosflowIdx = 0;                              \
        for (loop = 0; loop < MAX_QOS_FLOW_PER_PDU_SESS; loop++)        \
        {                                                               \
            qosflowIdx = (_ptCi)->pduSess[_pduIdx].qosFlowIndex[loop];  \
            if (qosflowIdx >= MAX_QOS_FLOW_PER_CALL) continue;          \
            if ((_ptCi)->qosFlow[qosflowIdx].usage != CI_use) continue; \
            SET_QOSFLOW_STATUS(_ptCi, qosflowIdx, _status);             \
        }                                                               \
    } while (0)

#define IS_SUPPORT_RRC_INACTIVE(_ptCi)                                              \
    ((FOO.VF_RRCInactiveDay1 == TRUE) && (_ptCi->callType == E_CALLTYPE_SA) &&      \
     (_ptCi->ueInfo.RrcInactiveInfo.ability == RRC_INACTIVE_SUPPORT))

#define IS_SUPPORT_RRC_INACTIVE_REF(_call)                                          \
    ((FOO.VF_RRCInactiveDay1 == TRUE) && (_call.callType == E_CALLTYPE_SA) &&       \
     (_call.ueInfo.RrcInactiveInfo.ability == RRC_INACTIVE_SUPPORT))

#define IS_RRC_INACTIVE_TO_RRC_IDLE(_ptCi)                                          \
    (_ptCi->ueInfo.rrcResumeInfo.goingToRRCIdleFlag && not _ptCi->ranPagingInfo.dlDataFlag)

#define VCCB_IS_SIGNALING_TIMER_EXPIRED(_ptCi)                                              \
    ((N_EQUIP == ptCi->CallUserInactivity.featureEnabled) ||                                \
        ((UserInactivityState_SIG_EXPIRED == ptCi->CallUserInactivity.ueInactivityState) || \
            (UserInactivityState_DATA_SIG_EXPIRED == ptCi->CallUserInactivity.ueInactivityState)))

#define MACRO_STAT_PMCC_DCCOM_DU_HO(_ptCi)                                                                             \
    do                                                                                                                 \
    {                                                                                                                  \
        if (HO_TYPE_MENB_INITIATED == _ptCi->hoInfo.hoType.initiated)                                                  \
        {                                                                                                              \
            MACRO_STAT_PMCC(                                                                                           \
                STAT_MENB_INIT_SGNB_MOD_MCGMOB_PER_GNB, EndcModByMenbMcgMobPrepFail_DuTimeout, _ptCi, 0, 0, 0, 0, 0);  \
        }                                                                                                              \
        else if (HO_TYPE_MENB_INTERMNHO == _ptCi->hoInfo.hoType.initiated)                                             \
        {                                                                                                              \
            VCCB_NSA_PegSgnbAddIntraLteHoNoSgnbChg(*(_ptCi), EndcAddLteHoNoSgnbChgPrepFail_DuTimeout);                   \
            VLIB_StatErabAddInterMnHO(_ptCi, ErabAddFail_DuTimeout, TRUE);                                             \
        }                                                                                                              \
        else                                                                                                           \
        {                                                                                                              \
            VCCB_NSA_PegIntraSnPscellChange(*(_ptCi), EndcIntraChgPrepFail_DuTimeout);                             \
        }                                                                                                              \
    } while (0)

#define MACRO_STAT_NG_ESTAB_GROUP(_ptCi, _item)                                              \
    do                                                                                       \
    {                                                                                        \
        MACRO_STAT_PMCC(STAT_NG_ESTAB, _item, _ptCi, 0, 0, 0, 0, 0);                         \
        if (FOO.VF_NRRetainability_IndexSNSSAI && FALSE == IS_REDCAP_UE(_ptCi)) /* CAN Only */\
        {                                                                                    \
            MACRO_STAT_PMCC(STAT_NG_ESTAB_DU_ID_PLMN, _item, _ptCi, 0, 0, 0, 0, 0);          \
        }                                                                                    \
    } while (0)

#define SET_MOD_EVENT_FLAG(_ptCi, _eventFlag, _flag) _ptCi->modProcInfo.eventFlag._eventFlag = _flag;

#define CHECK_MOD_EVENT_WITHOUT_STATECMD(_ptCi, _eventFlag) (_ptCi->modProcInfo.eventFlag._eventFlag == VCCB_FLAG_ON)
#define CHECK_MOD_EVENT_WITH_STATECMD(_ptCi, _eventFlag)                                                 \
    (((SgNBModification_cmd == (_ptCi)->stateCmd) || (SgnbInitBearerRelease_cmd == (_ptCi)->stateCmd) || \
         (MrdcXnSNMod_cmd == (_ptCi)->stateCmd)) &&                                                      \
        ((_ptCi)->modProcInfo.eventFlag._eventFlag == VCCB_FLAG_ON))

#define INIT_MOD_PROC_INFO(_ptCi)                                                       \
    {                                                                                   \
        memset(&_ptCi->modProcInfo.eventFlag, 0, sizeof(_ptCi->modProcInfo.eventFlag)); \
        _ptCi->modProcInfo.selectedModProc = 0;                                         \
    }

#define SET_NOT_ADMITTED_ERAB_STATUS(_pErabList, _pErab, _choice, _cause)              \
    {                                                                                  \
        if (_pErabList->n < X2_maxnoofBearers)                                         \
        {                                                                              \
            _pErabList->e_RAB_Item[ptERABsNotAdmitted->n].e_RAB_ID = _pErab->e_RAB_ID; \
            _pErabList->e_RAB_Item[ptERABsNotAdmitted->n].cause.choice = _choice;      \
            _pErabList->e_RAB_Item[ptERABsNotAdmitted->n].cause.cause = _cause;        \
            _pErabList->n++;                                                           \
        }                                                                              \
    }

#define GET_UNIT_ID(_iRNTI)             ((_iRNTI >> (LEN_IRNTI_UE_ID + LEN_IRNTI_GNB_ID)) & MAX_UNIT_ID)
#define GET_IRNTI_UE_ID(_iRNTI)         ((_iRNTI >> LEN_IRNTI_GNB_ID) & MAX_IRNTI_UE_ID)
#define GET_LSB16BIT_OF_GNB_ID(_iRNTI)  (_iRNTI & BITMASK_OF_LSB16BIT_OF_GNB_ID)
#define SET_RRC_STATE(_ptCi, _rRCstate) _ptCi->rRCState = _rRCstate
#define GET_RRC_STATE(_ptCi)            _ptCi->rRCState

#define SET_PROC_FOR_STAT(_ptCi, _procForStat) _ptCi->procForStat = _procForStat
#define GET_PROC_FOR_STAT(_ptCi)               _ptCi->procForStat

#define GET_RAN_PAGING_CYCLE(_ptCi) \
    MIN(ptCi->ueInfo.RrcInactiveInfo.pagingDrx, GNBINFO[ptCi->gnbNum].RrcInactiveInfo.ranPagingCycle)
#define MACRO_GET_INTERFACE_CAUSE_WITHOUT_CALLINFO(_getCauseg, _reqCause)                                            \
    GetInterfaceCause(_reqCause, &_getCauseg.f1Cause, &_getCauseg.e1Cause, &_getCauseg.x2Cause, &_getCauseg.ngCause, \
        &_getCauseg.xnCause);

#define SET_PA4M_STATE(_ptCi, _state)                                                                          \
    do                                                                                                         \
    {                                                                                                          \
        VCCB_PRINT_CALL_COMMENT(                                                                               \
            _ptCi, "[PA4M] State change [%u -> %u]\n", (_ptCi)->measurementsConfigShared.pa4m.state, _state); \
        (_ptCi)->measurementsConfigShared.pa4m.state = (_state);                                              \
    } while (0)

#define SET_LPM_STATE(_ptCi, _state)                                                                            \
    do                                                                                                          \
    {                                                                                                           \
        VCCB_PRINT_CALL_COMMENT(                                                                                \
            _ptCi, "[LPM] State change [%u -> %u]\n", (_ptCi)->measurementsConfigShared.lpm.state, _state);    \
        (_ptCi)->measurementsConfigShared.lpm.state = (_state);                                                \
    } while (0)

#define SET_PCC_STATE(_ptCi, _state)                                                                                    \
    do                                                                                                                  \
    {                                                                                                                   \
        VCCB_PRINT_CALL_COMMENT(_ptCi, "[PCC] State change [%u -> %u] mode [%u] \n", (_ptCi)->pccData.state, _state,    \
            (_ptCi)->pccData.pccMode);                                                                                  \
        (_ptCi)->pccData.state = (_state);                                                                              \
    } while (0)

#define IS_PCC_PSCELL_SELECTED(_ptCi) \
    ((NULL != (_ptCi)) &&             \
        ((PCC_NrDcSNAddition == (_ptCi)->pccData.state) && (MAX_NBR_PER_CELL > (_ptCi)->pccData.pscellNbrIdx)))

#define CLEAR_PCC_PSCELL_SELECTION(_ptCi)                     \
    do                                                        \
    {                                                         \
        if (NULL != (_ptCi))                                  \
        {                                                     \
            (_ptCi)->pccData.pscellNbrIdx = MAX_NBR_PER_CELL; \
        }                                                     \
    } while (0)

#define SET_SCC_STATE(_ptCi, _state)                                                                       \
    do                                                                                                     \
    {                                                                                                      \
        VCCB_PRINT_CALL_COMMENT(_ptCi, "[SCC] State change [%u -> %u]\n", (_ptCi)->sccData.state, _state); \
        (_ptCi)->sccData.state = (_state);                                                                 \
    } while (0)

#define SET_IRATPCC_STATE(_ptCi, _state)                                                            \
    do                                                                                              \
    {                                                                                               \
        VCCB_PRINT_CALL_COMMENT(                                                                    \
            _ptCi, "[IRAT PCC] State change [%u -> %u]\n", (_ptCi)->pccData.interRatState, _state); \
        (_ptCi)->pccData.interRatState = (_state);                                                  \
    } while (0)

#define SET_ALTGAP_STATE(_ptCi, _state)                                                   \
    do                                                                                    \
    {                                                                                     \
        VCCB_PRINT_CALL_COMMENT(_ptCi, "[Altgap without PA4M] State change [%u -> %u]\n", \
            (_ptCi)->measurementsConfigShared.altgap.stateWithoutPa4m, _state);          \
        (_ptCi)->measurementsConfigShared.altgap.prev_stateWithoutPa4m =                 \
            (_ptCi)->measurementsConfigShared.altgap.stateWithoutPa4m;                   \
        (_ptCi)->measurementsConfigShared.altgap.stateWithoutPa4m = (_state);            \
    } while (0)

#define CHECK_CA_CELL_VALIDITY_AND_RETURN(_ptCaCell)                                    \
    do                                                                                  \
    {                                                                                   \
        VALID_E_POINT_CHECK_ERROR(_ptCaCell);                                           \
        VCCB_CHECK_E_RANGE_AND_RETURN(_ptCaCell->frequencyRange, FrequencyRangeCa_MAX); \
        VCCB_CHECK_E_RANGE_AND_RETURN(_ptCaCell->duplexMode, MAX_DUPLEX_MODE);          \
    } while (0)

#define VCCB_CALL_RELEASE_TRIGGER(_ptCi) VCCB_CallAutoRelease(_ptCi, __func__, __LINE__)

/* FR1/FR2 */
#define IS_FR1(_ssbArfcn) (FnVCCB_IsFr1Freq(_ssbArfcn))
#define IS_FR2(_ssbArfcn) (FnVCCB_IsFr2Freq(_ssbArfcn))

/* CHO */
#define IS_CHO(_ptCi) (FnVCCB_IsConditionalHandoverUE(_ptCi))

/* NRDC */
#define IS_NRDC_MN(_ptCi) (FnVCCB_IsNrdcMn(_ptCi))
#define IS_NRDC_SN(_ptCi) (FnVCCB_IsNrdcSn(_ptCi))
#define IS_NRDC(_ptCi)    (FnVCCB_IsNrdcAll(_ptCi))

/* NEDC */
#define IS_NEDC_MN(_ptCi) (FnVCCB_IsNedcMn(_ptCi))
#define IS_NEDC(_ptCi)    IS_NEDC_MN(_ptCi)

/* ENDC */
#define IS_ENDC_SN(_ptCi) (VCCB_IsEndcSn(*(_ptCi)))
#define IS_ENDC(_ptCi)    IS_ENDC_SN(_ptCi)

#define IS_ENDC_HO_Send_MCG_DlTxStop(_ptCi)                                                                      \
    ((!((IntraRatHO_cmd == ptCi->stateCmd) && (VCCB_FLAG_ON == GNBINFO[ptCi->gnbNum].cfg.onlyNrScgStopResume) && \
          (HO_TYPE_SGNB_INITIATED == ptCi->hoInfo.hoType.initiated) &&                                           \
          (HO_TYPE_INTRA_NB == ptCi->hoInfo.hoType.nb)) &&                                                       \
         !((IntraRatHO_cmd == ptCi->stateCmd) && (SCG_Bearer == pERABInfo->preveBearerType) &&                   \
             ((STATE_DB == ptCi->state) || (STATE_DCInterDuHo_F1UeCtxSetReq == ptCi->state)))) ||                \
        (IS_FULLCONFIGURATION_IN_PROCESS(ptCi)))
#define IS_ENDC_HO_SCGFailureResume_UL_PATH(_ptCi, _statusChg)                                    \
    (((IntraRatHO_cmd == (_ptCi)->stateCmd)) &&                                                   \
        (((STATE_DB == (_ptCi)->state) || (STATE_DCInterDuHo_F1UeCtxSetReq == (_ptCi)->state)) || \
            ((E1_DL_TX_Stop_stop == _statusChg) && (VCCB_FLAG_ON == (_ptCi)->scgFailureFlag))))
#define IS_ENDC_HO_ROLLBACK_UL_PATH(_ptCi, _statusChg)                                        \
    ((IntraRatHO_cmd == ptCi->stateCmd) && (STATE_DCInterDuHo_F1SrcDuRecov == ptCi->state) && \
        (TRUE == ptCi->hoInfo.endcHoRollbackActive) && (E1_DL_TX_Stop_resume == _statusChg))

/* MRDC - EN/NR/NE-DC */
#define IS_MRDC_MN(_ptCi) (FnVCCB_IsMrdcMn(_ptCi))
#define IS_MRDC_SN(_ptCi) (FnVCCB_IsMrdcSn(_ptCi))
#define IS_MRDC(_ptCi)    (FnVCCB_IsMrdcAll(_ptCi))
#define IS_NON_DC(_ptCi)    (FnVCCB_IsNonDc(_ptCi))

//<<< NRDC

#define IS_GNB_OR_MRDC_MN(_ptCi) (!IS_NRDC_SN(_ptCi))  // call which is interworking with NG-C

/* to support mobility */
#define IS_MRDC_TYPE_FOR_CELLNUM(_ptCi, _cellNum, _x) ((_x) == FnVCCB_DecideMrdcTypeForCell(_ptCi, _cellNum))

#define IS_SELECTED_MRDC(_x)     (ptCi->selectedMrdcType == (_x))
#define GET_SELECTED_MRDC(_ptCi) ((_ptCi)->selectedMrdcType)
#define IS_MRDC_ACTIVE(_ptCi)    (IsAvailable_MrdcInfo() && (_ptCi)->mrdcInfo.SNInfo[SRC_SN].state == SN_STATE_ACTIVE)

#define IS_MN_TERM_DRB(_pDrb)  \
    (IsAvailable_MrdcInfo() && (_pDrb)->bearerType.termPoint == TermPoint_Mn)
#define IS_SN_TERM_DRB(_pDrb)  \
    (IsAvailable_MrdcInfo() && (_pDrb)->bearerType.termPoint == TermPoint_Sn)

#define VCCB_IS_ANR_REPORT_CGI_PROCEDURE(_ptCi) \
    (_ptCi->state >= STATE_Anr_MnSnCoordination && _ptCi->state <= STATE_Anr_Rollback)

#define IS_ON_NRDC_SN_REPORT_CGI(_ptCi) \
    (TRUE == FOO.VF_IntraNrANR && IS_NRDC_SN(_ptCi) && GET_REPORT_CGI_SN_FLAG(_ptCi) == VCCB_FLAG_ON)
#define IS_ON_REPORT_CGI_DUPLICATE_PCI(_ptCi)                         \
    (((_ptCi)->anrInfo.reportCgi.reportCgiDuplPci == VCCB_FLAG_ON &&  \
         (_ptCi)->anrInfo.reportCgi.reportCgiFlag == VCCB_FLAG_ON) || \
        (VCCB_IS_ANR_REPORT_CGI_PROCEDURE(_ptCi)))

#define GET_REPORT_CGI_SN_FLAG(_ptCi) (_ptCi->anrInfo.reportCgi.reportCgiSnFlag)
#define SET_REPORT_CGI_SN_FLAG(_ptCi, _state)                                                                        \
    do                                                                                                               \
    {                                                                                                                \
        VCCB_PRINT_LOG_ANR(                                                                              \
            _ptCi, "(ANR) change reportCgiSnFlag      [%u -> %u]\n", (_ptCi)->anrInfo.reportCgi.reportCgiSnFlag, _state); \
        (_ptCi)->anrInfo.reportCgi.reportCgiSnFlag = (_state);                                                       \
    } while (0)
#define GET_REPORT_CGI_FLAG(_ptCi) ((_ptCi)->anrInfo.reportCgi.reportCgiFlag)
#define SET_REPORT_CGI_FLAG(_ptCi, _state)                                                                            \
    do                                                                                                                \
    {                                                                                                                 \
        VCCB_PRINT_LOG_ANR(                                                                            \
            _ptCi, "(ANR) change reportCgiFlag        [%u -> %u]\n", (_ptCi)->anrInfo.reportCgi.reportCgiFlag, _state); \
        (_ptCi)->anrInfo.reportCgi.reportCgiFlag = (_state);                                                          \
    } while (0)
#define GET_REPORT_CGI_DUPL_PCI(_ptCi) ((_ptCi)->anrInfo.reportCgi.reportCgiDuplPci)
#define SET_REPORT_CGI_DUPL_PCI(_ptCi, _state)                                                                         \
    do                                                                                                                 \
    {                                                                                                                  \
        VCCB_PRINT_LOG_ANR(                                                                             \
            _ptCi, "(ANR) change reportCgiDuplPci     [%u -> %u]\n", (_ptCi)->anrInfo.reportCgi.reportCgiDuplPci, _state); \
        (_ptCi)->anrInfo.reportCgi.reportCgiDuplPci = (_state);                                                        \
    } while (0)
#define GET_REPORT_CGI_NON_NEIGHBOR(_ptCi) ((_ptCi)->anrInfo.reportCgi.reportCgiNonNeighbor)
#define SET_REPORT_CGI_NON_NEIGHBOR(_ptCi, _state)                                                 \
    do                                                                                             \
    {                                                                                              \
        VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) change reportCgiNonNeighbor [%u -> %u]\n", \
            (_ptCi)->anrInfo.reportCgi.reportCgiNonNeighbor, _state);                              \
        (_ptCi)->anrInfo.reportCgi.reportCgiNonNeighbor = (_state);                                \
    } while (0)

#define GET_REPORT_CGI_AUTONOMOUS_GAP_FLAG(_ptCi) (_ptCi->anrInfo.reportCgi.autonomousGapsFlag)
#define SET_REPORT_CGI_AUTONOMOUS_GAP_FLAG(_ptCi, _state)                                        \
    do                                                                                           \
    {                                                                                            \
        VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) change autonomousGapsFlag   [%u -> %u]\n", \
            (_ptCi)->anrInfo.reportCgi.autonomousGapsFlag, _state);                              \
        (_ptCi)->anrInfo.reportCgi.autonomousGapsFlag = (_state);                                \
    } while (0)

#define IS_REPORT_CGI_FOR_HANDOVER(_ptCi) \
    (GET_REPORT_CGI_DUPL_PCI(_ptCi) == VCCB_FLAG_ON || GET_REPORT_CGI_NON_NEIGHBOR(_ptCi) == VCCB_FLAG_ON)

#define IS_REPORT_CGI_HANDOVER_TARGET(_ptCi)                                     \
    ((_ptCi)->saHoMrQueueInfo.reportCgiHandoverType == RCHO_Type_duplicatePci || \
        (_ptCi)->saHoMrQueueInfo.reportCgiHandoverType == RCHO_Type_nonNeighborCell)
#define GET_REPORT_CGI_LONG_DRX_STATUS(_ptCi) (_ptCi->anrInfo.reportCgi.longDrxStatus)
#define SET_REPORT_CGI_LONG_DRX_STATUS(_ptCi, _state)                                                            \
    do                                                                                                           \
    {                                                                                                            \
        VCCB_PRINT_LOG_ANR(                                                                       \
            _ptCi, "(ANR) change longDrxStatus        [%u -> %u]\n", (_ptCi)->anrInfo.reportCgi.longDrxStatus, _state); \
        (_ptCi)->anrInfo.reportCgi.longDrxStatus = (_state);                                                     \
    } while (0)

#define GET_REPORT_CGI_FAIL_BY_T321(_ptCi) ((_ptCi)->anrInfo.reportCgi.reportCgiFailByT321)
#define SET_REPORT_CGI_FAIL_BY_T321(_ptCi, _state)                                                                             \
    do                                                                                                                         \
    {                                                                                                                          \
        VCCB_PRINT_LOG_ANR(                                                                                                    \
            _ptCi, "(ANR) change reportCgiFailByT321  [%u -> %u]\n", (_ptCi)->anrInfo.reportCgi.reportCgiFailByT321, _state);  \
        (_ptCi)->anrInfo.reportCgi.reportCgiFailByT321 = (_state);        \
    } while (0)

#define GET_REPORT_CGI_FAIL_BY_INVALID_CGI(_ptCi) ((_ptCi)->anrInfo.reportCgi.reportCgiFailByInvalidCgi)
#define SET_REPORT_CGI_FAIL_BY_INVALID_CGI(_ptCi, _state)                                 \
    do                                                                                    \
    {                                                                                     \
        VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) change reportCgiFailByInvalidCgi  [%u -> %u]\n", \
            (_ptCi)->anrInfo.reportCgi.reportCgiFailByInvalidCgi, _state);                \
        (_ptCi)->anrInfo.reportCgi.reportCgiFailByInvalidCgi = (_state);                  \
    } while (0)

// FGS-SF0502 FR760 26A
#define GET_REPORT_CGI_STAT_COLLECT_REQUIRED(_ptCi)        ((_ptCi)->anrInfo.reportCgiStatCollectRequired)
#define SET_REPORT_CGI_STAT_COLLECT_REQUIRED(_ptCi, _state)                           \
    do                                                                                \
    {                                                                                 \
        VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) reportCgiStatCollectRequired  [%u -> %u]\n", \
            (_ptCi)->anrInfo.reportCgiStatCollectRequired, _state);         \
        (_ptCi)->anrInfo.reportCgiStatCollectRequired = (_state);           \
    } while (0)

#define GET_REPORT_CGI_TGT_FREQ_TYPE(_ptCi) (_ptCi->anrInfo.reportCgiTgtFreqType)
#define SET_REPORT_CGI_TGT_FREQ_TYPE(_ptCi, _val)                               \
    do                                                                              \
    {                                                                               \
        VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) change retportCgiTgtFreqType        [%u -> %u]\n", \
            (_ptCi)->anrInfo.reportCgiTgtFreqType, _val);                      \
        (_ptCi)->anrInfo.reportCgiTgtFreqType = (_val);                        \
    } while (0)

#define MACRO_INIT_MR_INFO(_ptCi)                                                            \
    do                                                                                      \
    {                                                                                       \
        (_ptCi)->mrInfo.reportType = 0xFF;                                                  \
        (_ptCi)->mrInfo.reportPurpose = 0xFF;                                               \
    } while (0)

#define MACRO_SET_MR_INFO(_ptCi, _reportType, _reportPurpose)                               \
    do                                                                                      \
    {                                                                                       \
        (_ptCi)->mrInfo.reportType = _reportType;                                           \
        (_ptCi)->mrInfo.reportPurpose = _reportPurpose;                                     \
    } while (0)

#define GET_REPORT_TYPE_AND_PURPOSE(_ptCi, _reportType, _reportPurpose)                               \
    do                                                                                      \
    {                                                                                       \
        if (((_ptCi)->mrInfo.reportType == measReport_reportCGI && (_ptCi)->mrInfo.reportPurpose == reportCgiPurpose_ReportCgi_Handover) ||           \
            ((_ptCi)->mrInfo.reportType == measReport_reportCGIEutra && (_ptCi)->mrInfo.reportPurpose == reportCgiPurpose_ReportCgiEutra_Handover))   \
        {                                                                                                                                             \
            _reportType = (_ptCi)->anrInfo.reportType;                                                                                                \
            _reportPurpose = (_ptCi)->anrInfo.reportPurpose;                                                                                          \
        }                                                                                                                                             \
        else                                                                                                                                          \
        {                                                                                                                                             \
            _reportType = (_ptCi)->mrInfo.reportType;                                                                                                 \
            _reportPurpose = (_ptCi)->mrInfo.reportPurpose;                                                                                           \
        }                                                                                                                                             \
        VCCB_PRINT_LOG_NC_MC((_ptCi), "(NCMC) report(type/purpose) (%d)(%d/%d)(mr:%d/%d)(anr:%d/%d)\n",                                               \
            IS_REPORT_CGI_FOR_HANDOVER(_ptCi), reportType, reportPurpose,                                                                             \
            ptCi->mrInfo.reportType, ptCi->mrInfo.reportPurpose, ptCi->anrInfo.reportType, ptCi->anrInfo.reportPurpose);                              \
    } while (0)

#define GET_HO_REPORT_TYPE_AND_PURPOSE(_ptCi, _reportType, _reportPurpose)                               \
    do                                                                                      \
    {                                                                                       \
        if (IS_REPORT_CGI_FOR_HANDOVER(_ptCi) &&                                                                                                      \
            (((_ptCi)->mrInfo.reportType == measReport_reportCGI && (_ptCi)->mrInfo.reportPurpose == reportCgiPurpose_ReportCgi_Handover) ||          \
             ((_ptCi)->mrInfo.reportType == measReport_reportCGIEutra && (_ptCi)->mrInfo.reportPurpose == reportCgiPurpose_ReportCgiEutra_Handover))) \
        {                                                                                                                                             \
            _reportType = (_ptCi)->anrInfo.reportType;                                                                                                \
            _reportPurpose = (_ptCi)->anrInfo.reportPurpose;                                                                                          \
        }                                                                                                                                             \
        else                                                                                                                                          \
        {                                                                                                                                             \
            _reportType = (_ptCi)->mrInfo.reportType;                                                                                                 \
            _reportPurpose = (_ptCi)->mrInfo.reportPurpose;                                                                                           \
        }                                                                                                                                             \
        VCCB_PRINT_LOG_NC_MC((_ptCi), "(NCMC) report(type/purpose) (%d)(%d/%d)(mr:%d/%d)(anr:%d/%d)\n",                                               \
            IS_REPORT_CGI_FOR_HANDOVER(_ptCi), reportType, reportPurpose,                                                                             \
            ptCi->mrInfo.reportType, ptCi->mrInfo.reportPurpose, ptCi->anrInfo.reportType, ptCi->anrInfo.reportPurpose);                              \
    } while (0)


// SA Call in PCell (SA, NRDC-MN, NEDC-MN)
#define IS_SA_CALL_IN_PCELL(_ptCi)  (E_CALLTYPE_SA == _ptCi->callType && !IS_NRDC_SN(_ptCi))

// Timer is valid and exclude report CGI HO case
#define IS_ANR_REPORT_CGI_IN_PROGRESS(_ptCi)                                                \
    (GET_REPORT_CGI_FLAG(_ptCi) && IS_TIMER_VALID(_ptCi->anrInfo.reportCgiTimer) &&         \
    !IS_REPORT_CGI_FOR_HANDOVER(_ptCi))                                                 \

// 25A FGS-SF0502 FR230
#define IS_NR_ANR_ON(_pCell) (ON == _pCell->anrInfo.anrSwitch)
#define IS_NR_UNDERUSED_NCR_DELETE_ON(_pCell) (ON == _pCell->anrInfo.underusedNcrDeleteSwitch)
#define IS_NR_MR_COUNT_COLLECT_CONDITION(_pCell) \
    (IS_NR_ANR_ON(_pCell) && IS_NR_UNDERUSED_NCR_DELETE_ON(_pCell))

// 25A FGS-SF0502 FR240
#define IS_NR_INVALID_NCR_DELTE_ON(_pCell) (ON == _pCell->anrInfo.invalidNcrDeleteSwitch)
#define IS_NR_INVALID_NCR_NOTIFY_CONDITION(_pCell) \
    (IS_NR_ANR_ON(_pCell) && IS_NR_INVALID_NCR_DELTE_ON(_pCell))

// 25B FGS-SF0502 FR152 - set bit 15 (MSB): availability flag
#define APPLY_PLMN_SA_AVAILABILITY(_saAvailability)                                 \
    do                                                                              \
    {                                                                               \
        ONBIT_U16(_saAvailability, 15);                                             \
    } while (0)

// 25A FGS-SF0503 FR170
#define IS_IRAT_ANR_ON(_pCell) (ON == _pCell->irat_anrInfo.anrSwitch)
#define IS_IRAT_UNDERUSED_NCR_DELETE_ON(_pCell) (ON == _pCell->irat_anrInfo.underusedNcrDeleteSwitch)
#define IS_IRAT_MR_COUNT_COLLECT_CONDITION(_pCell) \
    (IS_IRAT_ANR_ON(_pCell) && IS_IRAT_UNDERUSED_NCR_DELETE_ON(_pCell))

// 25A FGS-SF0503 FR180
#define IS_IRAT_INVALID_NCR_DELTE_ON(_pCell) (ON == _pCell->irat_anrInfo.invalidNcrDeleteSwitch)
#define IS_IRAT_INVALID_NCR_NOTIFY_CONDITION(_pCell) \
        (IS_IRAT_ANR_ON(_pCell) && IS_IRAT_INVALID_NCR_DELTE_ON(_pCell))

#define IS_STRONGEST_PCI(_mrNbrIdx) (0 == _mrNbrIdx)

#define IS_INTRA_GNB_NRDC_MN(_ptCi) \
    ((IS_NRDC_MN(_ptCi) && (_ptCi)->mrdcInfo.SNInfo[SRC_SN].epIdx == XNIDX_FOR_INTRA_GNB_NRDC))
#define IS_INTRA_GNB_NRDC_SN(_ptCi) ((IS_NRDC_SN(_ptCi) && (_ptCi)->endPointInfo.xnIdx == XNIDX_FOR_INTRA_GNB_NRDC))

#define IS_INTRA_GNB_NRDC(_ptCi) (IS_INTRA_GNB_NRDC_MN(_ptCi) || IS_INTRA_GNB_NRDC_SN(_ptCi))

#define IS_MULTI_UP(_ptCi) ((_ptCi)->endPointInfo.srvAupfNum > 1)
#define COLLECT_NRDC_STAT_NERROR(__ptCi, __status, __type) \
    {                                                      \
        if (ERROR == __status)                             \
        {                                                  \
            VLIB_StatNrdcAdd(__ptCi, __type);              \
        }                                                  \
    }

#define VCCB_IS_SN_TERM_DRB_WITH_ONLY_CHECK_BEARER_TYPE(_ptDi) ((_ptDi)->bearerType.termPoint == TermPoint_Sn)

// one time state is only valid during one transaction between request and response.
#define SET_DRB_OTS(_pDi, _oneTimestate)                                      \
    do                                                                        \
    {                                                                         \
        if ((_pDi) && (_pDi)->usage == CI_use && (_pDi)->drbStatus == S_Idle) \
        {                                                                     \
            (_pDi)->drbStatus = _oneTimestate;                                \
            (_pDi)->oneTimeStateFlag = VCCB_FLAG_ON;                          \
        }                                                                     \
    } while (0)

#define CLEAR_ALL_DRB_OTS(_ptCi)                                             \
    do                                                                       \
    {                                                                        \
        if (_ptCi)                                                           \
        {                                                                    \
            for (uint8_t drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++) \
            {                                                                \
                if ((_ptCi)->drb[drbIdx].oneTimeStateFlag)                   \
                {                                                            \
                    (_ptCi)->drb[drbIdx].drbStatus = S_Idle;                 \
                    (_ptCi)->drb[drbIdx].oneTimeStateFlag = VCCB_FLAG_OFF;   \
                }                                                            \
            }                                                                \
        }                                                                    \
    } while (0)

#define VCCB_IS_REMOVE_SKIP_STATE_IN_NRDC_SN(_ptCi)                                                \
    (!(_ptCi)->bitFlag.isDrbPreemptionCase &&                                                      \
        ((_ptCi->state == STATE_SN_SNModPrepare_F1Mod1) || (_ptCi->state == STATE_SN_SNModExec) || \
            (_ptCi->state == STATE_SN_SNModComplt_F1E1Mod)))

// Bearer Type Change from SNTerm to MNTerm
#define IS_BTC_SNTERM_TO_MNTERM(_ptCi, _ptDi)                            \
    (IS_NRDC_MN(ptCi) && (_ptDi)->reqBearerType.val == MN_Term_MCG_Bearer && (_ptDi)->bearerType.termPoint == TermPoint_Sn && \
        (GET_MRDC_PROCEDURE_CODE(_ptCi) == MRDC_PROC_CODE_SnRel || (_ptCi)->stateCmd == MrdcDrbBasedFallback_cmd))

#define IS_NRDC_MN_MGAP_PROGRESS_STATE(_ptCi) \
    ((_ptCi)->state >= STATE_MGap_F1CtxMod && (_ptCi)->state <= STATE_MGap_F1RecCmpl)
#define IS_NRDC_MN_BASIC_PROGRESS_STATE(_ptCi) \
    ((_ptCi)->state >= STATE_SNAddPrepare_E1Mod1 && (_ptCi)->state <= STATE_SNRelComplt_E1Mod)
#define IS_NRDC_SN_BASIC_PROGRESS_STATE(_ptCi) \
    ((_ptCi)->state >= STATE_SN_SNAddPrepare_E1Setup && (_ptCi)->state <= STATE_SN_SNRelExec)
#define IS_NRDC_BASIC_PROGRESS_STATE(_ptCi) \
    (IS_NRDC_MN_BASIC_PROGRESS_STATE(_ptCi) || IS_NRDC_SN_BASIC_PROGRESS_STATE(_ptCi))

#define ON_RCV_DlTrfStatusRptForNrdcAddition(_ptCi)                       \
    do                                                                    \
    {                                                                     \
        (_ptCi)->bitFlag.rcvDlTrfStatusRptForNrdcAddition = VCCB_FLAG_ON; \
    } while (0)

#define OFF_RCV_DlTrfStatusRptForNrdcAddition(_ptCi)                       \
    do                                                                     \
    {                                                                      \
        (_ptCi)->bitFlag.rcvDlTrfStatusRptForNrdcAddition = VCCB_FLAG_OFF; \
    } while (0)

#define GET_RCV_DlTrfStatusRptForNrdcAddition(_ptCi) ((_ptCi)->bitFlag.rcvDlTrfStatusRptForNrdcAddition)

#define ON_RCV_UlTrfStatusRptForNrdcAddition(_ptCi)                       \
    do                                                                    \
    {                                                                     \
        (_ptCi)->bitFlag.rcvUlTrfStatusRptForNrdcAddition = VCCB_FLAG_ON; \
    } while (0)

#define OFF_RCV_UlTrfStatusRptForNrdcAddition(_ptCi)                       \
    do                                                                     \
    {                                                                      \
        (_ptCi)->bitFlag.rcvUlTrfStatusRptForNrdcAddition = VCCB_FLAG_OFF; \
    } while (0)

#define GET_RCV_UlTrfStatusRptForNrdcAddition(_ptCi) ((_ptCi)->bitFlag.rcvUlTrfStatusRptForNrdcAddition)

#define OFF_RCV_TrfStatusRptForNrdcAddition(_ptCi)                         \
    do                                                                     \
    {                                                                      \
        (_ptCi)->bitFlag.rcvDlTrfStatusRptForNrdcAddition = VCCB_FLAG_OFF; \
        (_ptCi)->bitFlag.rcvUlTrfStatusRptForNrdcAddition = VCCB_FLAG_OFF; \
    } while (0)

#define GET_RCV_TrfStatusRptForNrdcAddition(_ptCi) \
    (GET_RCV_DlTrfStatusRptForNrdcAddition(_ptCi) || GET_RCV_UlTrfStatusRptForNrdcAddition(_ptCi))

#define IS_NRDC_BEARER(_ptDi)                                             \
    ((_ptDi)->usage == CI_use && (_ptDi)->selectedBearerTypeFrozenFlag && \
        ((_ptDi)->selectedBearerType.val == MN_Term_SPLIT_Bearer || (_ptDi)->selectedBearerType.val == SN_Term_SPLIT_Bearer || (_ptDi)->selectedBearerType.val == SN_Term_SCG_Bearer))

#define DOES_PDUSESS_NeedToBeModified_WO_QOSFLOW(_pPi)                                                         \
    (/*TBD (_pPi)->sNssai.fNeedModify ||*/ (_pPi)->nGuUlInfo.fNeedModify || (_pPi)->snNGuUlInfo.fNeedModify || \
        ((_pPi)->pduSessAmbrPresent && ((_pPi)->fNeedModify_pduSessAmbrDL || (_pPi)->fNeedModify_pduSessAmbrUL)))

#define DOES_PDUSESS_NeedToBeModified_WO_QOSFLOW_FOR_UP(_pPi)               \
    (/*TBD (_pPi)->sNssai.fNeedModify ||*/ (_pPi)->nGuUlInfo.fNeedModify || \
        ((_pPi)->pduSessAmbrPresent && (_pPi)->fNeedModify_pduSessAmbrDL))

#define VCCB_IS_X2_CAUSE(_cause)                         \
    ((_cause == CauseCpInternalNsaX2SctpOutOfService) || \
        (_cause >= CAUSE_BASE_X2AP_RADIONETWORK && _cause < CauseX2apMax))
#define VCCB_IS_NG_CAUSE(_cause)                        \
    ((_cause == CauseCpInternalSaNgSctpOutOfService) || \
        (_cause >= CAUSE_BASE_NGAP_RADIONETWORK && _cause < CauseNgapMax))
#define VCCB_IS_XN_CAUSE(_cause)                        \
    ((_cause == CauseCpInternalSaXnSctpOutOfService) || \
        (_cause >= CAUSE_BASE_XNAP_RADIONETWORK && _cause < CauseXnapMax))

#define ON_BITFLAG_NEED_XNUADDRIND_FOR_DLUPTNL(_ptCi)                 \
    do                                                                \
    {                                                                 \
        (_ptCi)->bitFlag.needXnUAddrIndForSnTermSplit = VCCB_FLAG_ON; \
    } while (0)

#define OFF_BITFLAG_NEED_XNUADDRIND_FOR_DLUPTNL(_ptCi)                 \
    do                                                                 \
    {                                                                  \
        (_ptCi)->bitFlag.needXnUAddrIndForSnTermSplit = VCCB_FLAG_OFF; \
    } while (0)

#define GET_BITFLAG_NEED_XNUADDRIND_FOR_DLUPTNL(_ptCi) ((_ptCi)->bitFlag.needXnUAddrIndForSnTermSplit)

#define VCCB_IS_HAS_BACKUP_REQUIRED_DURING_PLD_READ_PER_RELATION() \
    ((CFG->pld.isInitialReadDone == FALSE) || (CFG->pld.needAuditWithHasBackup == TRUE))

#define SAVE_USER_INACT_FOR_NAS_MESSAGE(_ptCi, _backupInfo)                          \
    do                                                                               \
    {                                                                                \
        _backupInfo.changedFlag = VCCB_FLAG_OFF;                                     \
        _backupInfo.ueInactivityState = _ptCi->CallUserInactivity.ueInactivityState; \
        if (_ptCi->CallUserInactivity.sigInactivityTimer.id > 0)                     \
            _backupInfo.sigInactivityTimerExit = VCCB_FLAG_ON;                       \
        else                                                                         \
            _backupInfo.sigInactivityTimerExit = VCCB_FLAG_OFF;                      \
        if (_ptCi->CallUserInactivity.releaseTimer.id > 0)                           \
            _backupInfo.x2ReleaseTimerExist = VCCB_FLAG_ON;                          \
        else                                                                         \
            _backupInfo.x2ReleaseTimerExist = VCCB_FLAG_OFF;                         \
    } while (0)

#define CHECK_IF_NAS_CHANGED_FOR_USER_INACT(_ptCi, _backupInfo)                                                        \
    do                                                                                                                 \
    {                                                                                                                  \
        uint8_t changedFlag = VCCB_FLAG_OFF;                                                                           \
        if (_backupInfo.ueInactivityState != _ptCi->CallUserInactivity.ueInactivityState)                              \
        {                                                                                                              \
            changedFlag = VCCB_FLAG_ON;                                                                                \
        }                                                                                                              \
        if (((_backupInfo.sigInactivityTimerExit == VCCB_FLAG_ON) &&                                                   \
                (_ptCi->CallUserInactivity.sigInactivityTimer.id <= 0)) ||                                             \
            ((_backupInfo.sigInactivityTimerExit == VCCB_FLAG_OFF) &&                                                  \
                (_ptCi->CallUserInactivity.sigInactivityTimer.id > 0)))                                                \
        {                                                                                                              \
            changedFlag = VCCB_FLAG_ON;                                                                                \
        }                                                                                                              \
        if (((_backupInfo.x2ReleaseTimerExist == VCCB_FLAG_ON) && (_ptCi->CallUserInactivity.releaseTimer.id <= 0)) || \
            ((_backupInfo.x2ReleaseTimerExist == VCCB_FLAG_OFF) && (_ptCi->CallUserInactivity.releaseTimer.id > 0)))   \
        {                                                                                                              \
            changedFlag = VCCB_FLAG_ON;                                                                                \
        }                                                                                                              \
        _backupInfo.changedFlag = changedFlag;                                                                         \
    } while (0)

#define IS_EXHAUSTED_RETRIAL_CNT_FOR_BLIND_SN_ADDITION(_ptCi) \
    ((_ptCi)->blindModeSNAddReTrialCnt >= MAX_RETRIAL_CNT_BLIND_SN_ADDITION)

#define VERIFY_MRDC_UEAMBR_RATIO(_mnDlRatio, _mnUlRatio, _snDlRatio, _snUlRatio)                 \
    do                                                                                           \
    {                                                                                            \
        if (mnDlRatio == 0 || mnDlRatio > 100)                                                   \
        {                                                                                        \
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid mnDlRatio(%lu) => default 100 !\n", mnDlRatio); \
            mnDlRatio = 100;                                                                     \
        }                                                                                        \
                                                                                                 \
        if (mnUlRatio == 0 || mnUlRatio > 100)                                                   \
        {                                                                                        \
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid mnUlRatio(%lu) => default 100 !\n", mnUlRatio); \
            mnUlRatio = 100;                                                                     \
        }                                                                                        \
                                                                                                 \
        if (snDlRatio == 0 || snDlRatio > 100)                                                   \
        {                                                                                        \
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid snDlRatio(%lu) => default 100 !\n", snDlRatio); \
            snDlRatio = 100;                                                                     \
        }                                                                                        \
                                                                                                 \
        if (snUlRatio == 0 || snUlRatio > 100)                                                   \
        {                                                                                        \
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid snUlRatio(%lu) => default 100 !\n", snUlRatio); \
            snUlRatio = 100;                                                                     \
        }                                                                                        \
    } while (0)

#define DOES_NEED_MRDC_UEAMBR_DISTRIBUTION(_ptCi)                                                         \
    (IS_MRDC_MN(_ptCi) && !(IS_NRDC_SNREL_INVOKED(_ptCi) || ptCi->stateCmd == MrdcSNAddPrepareFail_cmd || \
                              ptCi->mrdcInfo.queuedSNodeRelCause != MrdcRelCause_NoCause))

#define IS_SUPPORT_UE_CAPA_INFO(_ptCi)                                       \
    ((FOO.VF_NrRachParaOpt == TRUE) && (_ptCi->callType == E_CALLTYPE_SA) && \
        (_ptCi->ueInfo.ueCapa.nr.rachReportR16 == VCCB_FLAG_ON))

// [FGS-SF0505] NR RACH Parameter Optimization
// This flag is set on when vccb send NRRRC_UEInformationRequest and used to prevent duplicate transmission of
// NRRRC_UEInformationRequest messages.
#define ON_VCCB_UE_INFO_REQ_FLAG(_ptCi)             \
    do                                         \
    {                                          \
        (_ptCi)->ueInfoReqFlag = VCCB_FLAG_ON; \
    } while (0)
#define OFF_VCCB_UE_INFO_REQ_FLAG(_ptCi)             \
    do                                          \
    {                                           \
        (_ptCi)->ueInfoReqFlag = VCCB_FLAG_OFF; \
    } while (0)
#define GET_VCCB_UE_INFO_REQ_FLAG(_ptCi) ((_ptCi)->ueInfoReqFlag)

#define VCCB_IS_SAME_GNB(_gnbId, _plmnLongId, _ptCiGnbNum)    \
    ((_gnbId) == GNBINFO[_ptCiGnbNum].globalGnbId.gnbId.id && \
        (_plmnLongId) == GNBINFO[_ptCiGnbNum].globalGnbId.plmn.longId)

#define INIT_UE_CAPA_ENQUIRY_NEED_FLAG(_ptCi)                                \
    {                                                                        \
        _ptCi->ueCapaEnquiry.needEnquiryBitFlag = UE_CAPA_REQ_RAT_TYPE_NONE; \
        _ptCi->ueCapaEnquiry.needEnqurity3Step = VCCB_FLAG_OFF;              \
    }

#define TWO_BYTE_TO_BINARY(byte)                                                                                      \
    (byte & 0x8000 ? '1' : '0'), (byte & 0x4000 ? '1' : '0'), (byte & 0x2000 ? '1' : '0'),                            \
        (byte & 0x1000 ? '1' : '0'), (byte & 0x800 ? '1' : '0'), (byte & 0x400 ? '1' : '0'),                          \
        (byte & 0x200 ? '1' : '0'), (byte & 0x100 ? '1' : '0'), (byte & 0x80 ? '1' : '0'), (byte & 0x40 ? '1' : '0'), \
        (byte & 0x20 ? '1' : '0'), (byte & 0x10 ? '1' : '0'), (byte & 0x08 ? '1' : '0'), (byte & 0x04 ? '1' : '0'),   \
        (byte & 0x02 ? '1' : '0'), (byte & 0x01 ? '1' : '0')

#define VCCB_MRDC_FREE_BUFFER(_ptCi, _pBuff) VLIB_FreeBuffer(_ptCi, _pBuff, __FUNCTION__)

#define UPDATE_RRC_SA_TIMER_VALUE(_timerValue, _yangName, _gnbNum, _servCellNum, _tmrId)                            \
    {                                                                                                               \
        if (_servCellNum < MAX_CELL_NUM_VCCB)                                                                       \
        {                                                                                                           \
            profileIdx = CELLINFO[_servCellNum].profileDBInfo.rrcSaTimerProfileIdx;                                 \
            if (profileIdx < MAX_RRC_SA_TIMER_PROFILE_PER_GNB)                                                      \
            {                                                                                                       \
                if (GNBINFO[_gnbNum].rrcSaTimerProfile[profileIdx].usage == CI_use)                                 \
                {                                                                                                   \
                    _timerValue = GNBINFO[_gnbNum].rrcSaTimerProfile[profileIdx]._yangName;                         \
                }                                                                                                   \
                else                                                                                                \
                {                                                                                                   \
                    VCCB_PRINT_ERROR("Invalid usage(%d) - _tmrId(%s/%d)\n", profileIdx, strMsgId(_tmrId), _tmrId);  \
                }                                                                                                   \
            }                                                                                                       \
            else                                                                                                    \
            {                                                                                                       \
                VCCB_PRINT_ERROR("Invalid profileIdx(%d) - _tmrId(%s/%d)\n", profileIdx, strMsgId(_tmrId), _tmrId); \
            }                                                                                                       \
        }                                                                                                           \
        else                                                                                                        \
        {                                                                                                           \
            VCCB_PRINT_ERROR("Invalid cellNum(%d) - _tmrId(%s/%d)\n", _servCellNum, strMsgId(_tmrId), _tmrId);      \
        }                                                                                                           \
    }

#define UPDATE_RRC_ENDC_TIMER_VALUE(_timerValue, _yangName, _gnbNum, _servCellNum, _tmrId)                          \
    {                                                                                                               \
        if (_servCellNum < MAX_CELL_NUM_VCCB)                                                                       \
        {                                                                                                           \
            profileIdx = CELLINFO[_servCellNum].profileDBInfo.rrcEndcTimerProfileIdx;                               \
            if (profileIdx < MAX_RRC_ENDC_TIMER_PROFILE_PER_GNB)                                                    \
            {                                                                                                       \
                if (GNBINFO[_gnbNum].rrcEndcTimerProfile[profileIdx].usage == CI_use)                               \
                {                                                                                                   \
                    _timerValue = GNBINFO[_gnbNum].rrcEndcTimerProfile[profileIdx]._yangName;                       \
                }                                                                                                   \
                else                                                                                                \
                {                                                                                                   \
                    VCCB_PRINT_ERROR("Invalid usage(%d) - _tmrId(%s/%d)\n", profileIdx, strMsgId(_tmrId), _tmrId);  \
                }                                                                                                   \
            }                                                                                                       \
            else                                                                                                    \
            {                                                                                                       \
                VCCB_PRINT_ERROR("Invalid profileIdx(%d) - _tmrId(%s/%d)\n", profileIdx, strMsgId(_tmrId), _tmrId); \
            }                                                                                                       \
        }                                                                                                           \
        else                                                                                                        \
        {                                                                                                           \
            VCCB_PRINT_ERROR("Invalid cellNum(%d) - _tmrId(%s/%d)\n", _servCellNum, strMsgId(_tmrId), _tmrId);      \
        }                                                                                                           \
        if (_timerValue <= 0) _timerValue = 1000;                                                                   \
    }

#define IS_FR2BAND_28GHZ_39GHZ(_bandIndi) (((_bandIndi) == FR2_39GHz_n260) || ((_bandIndi) == FR2_28GHz_n261))

#define IS_SUPPORTABLE_ScgBandSelectionForNrdc_Foo() (FOO.VF_SCGBandSelectionforNRDC)

#define IS_SUPPORTABLE_ScgBandSelectionForNrdc_Yang(_cellNum) \
    ((_cellNum) < MAX_CELL_NUM_VCCB &&                        \
        CELLINFO[_cellNum].scgBandSelectionConfig.load_based_fr2_band_selection_option == VCCB_FLAG_ON)

#define FAST_ACCESS_BOUNDARY_TIME_NOT_SET  0 
#define IS_FAST_ACCESS_BAND_SELECTION_MODE(_cellNum) \
    ((_cellNum) < MAX_CELL_NUM_VCCB &&                        \
        CELLINFO[_cellNum].scgBandSelectionConfig.load_based_fr2_band_selection_option == VCCB_FLAG_ON &&   \
        CELLINFO[_cellNum].scgBandSelectionConfig.bandSelectionMode == SCG_BAND_SEL_MODE_FastAccess )
    
#define IS_SUPPORTABLE_ScgBandSelectionForNrdc(_cellNum) \
    (IS_SUPPORTABLE_ScgBandSelectionForNrdc_Foo() && IS_SUPPORTABLE_ScgBandSelectionForNrdc_Yang(_cellNum))

#define IS_WAITING_FOR_FR2SCGBAND_MR_COLLECTION(_ptCi)                   \
    (IS_SUPPORTABLE_ScgBandSelectionForNrdc((_ptCi)->servCellNum) &&     \
        not IS_FAST_ACCESS_BAND_SELECTION_MODE((_ptCi)->servCellNum) &&  \
        (_ptCi)->loadBasedNrdcScgBandSelectInfo.usage == VCCB_FLAG_ON && \
        (_ptCi)->loadBasedNrdcScgBandSelectInfo.newBandMrWaitTimer.id > 0)

#define UPDATE_RSU_TRANS_ID(_pCellInfo) \
    do                                  \
    {                                   \
        if (!(_pCellInfo))              \
        {                               \
            break;                      \
        }                               \
        (_pCellInfo)->rsuTransId++;     \
    } while (0)

#define VCCB_IS_INTER_PLMN(_srvPlmn, _tgtPlmn) (_srvPlmn.longId != _tgtPlmn.longId)

#define IS_CALL_PSCELL_FR1(_ptCi) (MIN_A6_NR_ARFCN > CELLINFO[(_ptCi)->servCellNum].ssbArfcn)

#define IS_PDCP_BUFFER_BASED_FR2_PSCELL_CHANGE_ENABLED(_gnbNum) \
    (VCCB_FLAG_ON == GNBINFO[_gnbNum].cfg.gnbMobilityConfig.pdcpBufferBasedFr2PSCellChange.featureEnabled)

#define IS_RRC_INACTIVE_UE_LEVEL(_ptCi) \
    (((IS_REDCAP_UE(_ptCi) && _ptCi->ueInfo.RrcInactiveInfo.redCapActivityNotificationLevel == activityNotifLvl_UE) ||  \
     ((not IS_REDCAP_UE(_ptCi)) && _ptCi->ueInfo.RrcInactiveInfo.activityNotificationLevel == activityNotifLvl_UE)))

#define IS_RRC_INACTIVE_DRB_LEVEL(_ptCi) \
    ((IS_REDCAP_UE(_ptCi) && _ptCi->ueInfo.RrcInactiveInfo.redCapActivityNotificationLevel == activityNotifLvl_DRB) ||  \
     ((not IS_REDCAP_UE(_ptCi)) && _ptCi->ueInfo.RrcInactiveInfo.activityNotificationLevel == activityNotifLvl_DRB))

#define INIT_RRC_INACTIVE_TRANSITION_REPORT(_ptCi)                                              \
    do                                                                                          \
    {                                                                                           \
        _ptCi->ueInfo.RrcInactiveInfo.newInactReportType = NGAP_cancel_report;                  \
        _ptCi->ueInfo.RrcInactiveInfo.oldInactReportType = NGAP_cancel_report;                  \
        _ptCi->ueInfo.RrcInactiveInfo.transitionReportedBy = 0;                                 \
        _ptCi->ueInfo.RrcInactiveInfo.singleReportByPathSwitch = RRC_INACTIVE_REPORT_SENT_NONE; \
    } while (0)

#define IS_SUPPORT_TO_REL_PREF_RRC_INACTIVE(_ptCi)                                            \
    ((FOO.VF_RRCInactiveDay1 == TRUE) && (_ptCi->callType == E_CALLTYPE_SA) &&                \
        (GNBINFO[_ptCi->gnbNum].ueRelPrefGnbConfig.releasePreferenceOnOff == VCCB_FLAG_ON) && \
        (_ptCi->ueNrRrcOtherConfig.newConfig.ueRelPrefConfig.releasePreferenceInactiveFlag == VCCB_FLAG_ON))

#define CAN_UE_REPORT_SINR(_ptCi, _frequency)                                                       \
    ((_frequency) < MIN_A6_NR_ARFCN ? !!((_ptCi)->ueInfo.ueCapa.nr.fr1Capa.measAndMob.ss_SINR_Meas) \
                                    : !!((_ptCi)->ueInfo.ueCapa.nr.fr2Capa.measAndMob.ss_SINR_Meas))

#define NEED_TO_SEND_F1_COMPLETE_INDICATION(_ptCi) ((_ptCi)->cellGroupConfig.numocts > 0)

// NBR_AUDIT_22B Start
#define IS_NBR_AUDIT_ENABLED()  (CFG->confd.nbrAudit.nbrAuditEnabled)
#define SET_NBR_AUDIT_ENABLED() (CFG->confd.nbrAudit.nbrAuditEnabled = VCCB_FLAG_ON)

// IS_NBR_AUDIT_ENABLED() is excluded to free to turn on and off the Audit function during operation.
#define SET_INITIAL_READ_NBR_GNB_CELL(_gnbNum)                                     \
    do                                                                             \
    {                                                                              \
        if (_gnbNum < MAX_GNB_PER_SYS)                                             \
        {                                                                          \
            CFG->confd.nbrAudit.initialReadNbrGnbCellFlag[_gnbNum] = VCCB_FLAG_ON; \
        }                                                                          \
    } while (0)
#define SET_INITIAL_READ_CELL_NBR(_gnbNum)                                      \
    do                                                                          \
    {                                                                           \
        if (_gnbNum < MAX_GNB_PER_SYS)                                          \
        {                                                                       \
            CFG->confd.nbrAudit.initialReadCellNbrFlag[_gnbNum] = VCCB_FLAG_ON; \
        }                                                                       \
    } while (0)
#define SET_INITIAL_READ_NBR_ENB_CELL(_gnbNum)                                     \
    do                                                                             \
    {                                                                              \
        if (_gnbNum < MAX_GNB_PER_SYS)                                             \
        {                                                                          \
            CFG->confd.nbrAudit.initialReadNbrEnbCellFlag[_gnbNum] = VCCB_FLAG_ON; \
        }                                                                          \
    } while (0)
#define SET_INITIAL_READ_CELL_EUTRA_NBR(_gnbNum)                                     \
    do                                                                               \
    {                                                                                \
        if (_gnbNum < MAX_GNB_PER_SYS)                                               \
        {                                                                            \
            CFG->confd.nbrAudit.initialReadCellEutraNbrFlag[_gnbNum] = VCCB_FLAG_ON; \
        }                                                                            \
    } while (0)

#define UPDATE_GNB_SYNC_CNT(_gnbNum)                              \
    do                                                            \
    {                                                             \
        if (IS_NBR_AUDIT_ENABLED() && _gnbNum < MAX_GNB_PER_SYS)  \
        {                                                         \
            if (VCCB_FLAG_ON == CFG->confd.nbrAudit.nbrAuditFlag) \
            {                                                     \
                CFG->confd.nbrAudit.syncGnbCnt[_gnbNum]++;        \
            }                                                     \
        }                                                         \
    } while (0)

#define UPDATE_AUDIT_MISS_NBR_GNB_CELL_CNT(_gnbNum, _cgi)                                                             \
    do                                                                                                                \
    {                                                                                                                 \
        if (IS_NBR_AUDIT_ENABLED() && _gnbNum < MAX_GNB_PER_SYS)                                                      \
        {                                                                                                             \
            if (CFG->confd.nbrAudit.initialReadNbrGnbCellFlag[_gnbNum] && !CFG->confd.nbrAudit.nbrAuditForceFlag)     \
            {                                                                                                         \
                CFG->confd.nbrAudit.misNbrGnbCellCnt[_gnbNum]++;                                                      \
                VCCB_PRINTF(                                                                                          \
                    "[NBR_ADIT] Not Found GNB Cell GNB:%d ci:%lu longId:0x%x\n", _gnbNum, _cgi.ci, _cgi.plmn.longId); \
            }                                                                                                         \
        }                                                                                                             \
    } while (0)
#define UPDATE_AUDIT_MISS_NBR_ENB_CELL_CNT(_gnbNum, _cgi)                                                             \
    do                                                                                                                \
    {                                                                                                                 \
        if (IS_NBR_AUDIT_ENABLED() && _gnbNum < MAX_GNB_PER_SYS)                                                      \
        {                                                                                                             \
            if (CFG->confd.nbrAudit.initialReadNbrEnbCellFlag[_gnbNum] && !CFG->confd.nbrAudit.nbrAuditForceFlag)     \
            {                                                                                                         \
                CFG->confd.nbrAudit.misNbrEnbCellCnt[_gnbNum]++;                                                      \
                VCCB_PRINTF(                                                                                          \
                    "[NBR_ADIT] Not Found ENB Cell GNB:%d ci:%lu longId:0x%x\n", _gnbNum, _cgi.ci, _cgi.plmn.longId); \
            }                                                                                                         \
        }                                                                                                             \
    } while (0)
#define UPDATE_AUDIT_MISS_CELL_NBR_CNT(_gnbNum, _cellNum, _nbrIdx)                                                     \
    do                                                                                                                 \
    {                                                                                                                  \
        if (IS_NBR_AUDIT_ENABLED() && _gnbNum < MAX_GNB_PER_SYS && _cellNum < MAX_CELL_PER_VNF)                        \
        {                                                                                                              \
            if (CFG->confd.nbrAudit.initialReadCellNbrFlag[_gnbNum] && !CFG->confd.nbrAudit.nbrAuditForceFlag)         \
            {                                                                                                          \
                CFG->confd.nbrAudit.misCellNbrCnt[_cellNum]++;                                                         \
                VCCB_PRINTF("[NBR_ADIT] Mismatched Cell NBR GNB:%d Cell:%d nbrIdx:%u \n", _gnbNum, _cellNum, _nbrIdx); \
            }                                                                                                          \
        }                                                                                                              \
    } while (0)
#define UPDATE_AUDIT_MISS_CELL_EUTRA_NBR_CNT(_gnbNum, _cellNum, _nbrIdx)                                             \
    do                                                                                                               \
    {                                                                                                                \
        if (IS_NBR_AUDIT_ENABLED() && _gnbNum < MAX_GNB_PER_SYS && _cellNum < MAX_CELL_PER_VNF)                      \
        {                                                                                                            \
            if (CFG->confd.nbrAudit.initialReadCellEutraNbrFlag[_gnbNum] && !CFG->confd.nbrAudit.nbrAuditForceFlag)  \
            {                                                                                                        \
                CFG->confd.nbrAudit.misCellEutraNbrCnt[_cellNum]++;                                                  \
                VCCB_PRINTF(                                                                                         \
                    "[NBR_ADIT] Mismatched Cell EUTRA NBR GNB:%d Cell:%d nbrIdx:%u \n", _gnbNum, _cellNum, _nbrIdx); \
            }                                                                                                        \
        }                                                                                                            \
    } while (0)

#define SET_AUDIT_RESET_NBR_GNB_CELL(_gnbNum)                              \
    do                                                                     \
    {                                                                      \
        if (IS_NBR_AUDIT_ENABLED() && _gnbNum < MAX_GNB_PER_SYS)           \
        {                                                                  \
            CFG->confd.nbrAudit.needToReset[_gnbNum] = VCCB_FLAG_ON;       \
            VCCB_PRINT_ERROR("[NBR_ADIT] needToReset GNB:%d \n", _gnbNum); \
        }                                                                  \
    } while (0)
#define SET_AUDIT_RESET_NBR_ENB_CELL(_gnbNum)                                 \
    do                                                                        \
    {                                                                         \
        if (IS_NBR_AUDIT_ENABLED() && _gnbNum < MAX_GNB_PER_SYS)              \
        {                                                                     \
            CFG->confd.nbrAudit.needToResetEnb[_gnbNum] = VCCB_FLAG_ON;       \
            VCCB_PRINT_ERROR("[NBR_ADIT] needToResetEnb GNB:%d \n", _gnbNum); \
        }                                                                     \
    } while (0)

#define UPDATE_GNB_AUDIT_GNB_CELL_CNT(_gnbNum, _num)                       \
    do                                                                     \
    {                                                                      \
        if (IS_NBR_AUDIT_ENABLED() && _gnbNum < MAX_GNB_PER_SYS)           \
        {                                                                  \
            if (VCCB_FLAG_ON == CFG->confd.nbrAudit.nbrAuditFlag)          \
            {                                                              \
                CFG->confd.nbrAudit.auditNbrGnbCellCnt[_gnbNum][1] = _num; \
            }                                                              \
        }                                                                  \
    } while (0)
#define UPDATE_GNB_AUDIT_ENB_CELL_CNT(_gnbNum, _num)                       \
    do                                                                     \
    {                                                                      \
        if (IS_NBR_AUDIT_ENABLED() && _gnbNum < MAX_GNB_PER_SYS)           \
        {                                                                  \
            if (VCCB_FLAG_ON == CFG->confd.nbrAudit.nbrAuditFlag)          \
            {                                                              \
                CFG->confd.nbrAudit.auditNbrEnbCellCnt[_gnbNum][1] = _num; \
            }                                                              \
        }                                                                  \
    } while (0)
// NBR_AUDIT_22B End

#define VCCB_PRINT_CALL_PRINT_FOR_BW(__ptCi, __args...) \
    do                                                  \
    {                                                   \
        if (DBG->flag.logIntraNrBW)                     \
            VCCB_PRINT_CALL_ERROR(__ptCi, ##__args);    \
        else                                            \
            VCCB_PRINT_CALL_COMMENT(__ptCi, ##__args);  \
    } while (0)

// Idle Mobility Control for NR(IMC)
#define IS_NOT_ALLOWED_PLMN_SUPPORT(_pMeasObjControl, _selectedPlmnIdentity)                    \
    (((_selectedPlmnIdentity) < MAX_PLMN_INDEX) &&                                              \
        (CI_use == (_pMeasObjControl)->plmnBasedControl.plmn[(_selectedPlmnIdentity)].usage) && \
        (plmnOption_notAllowed == (_pMeasObjControl)->plmnBasedControl.plmn[(_selectedPlmnIdentity)].option))

#define IS_NOT_ALLOWED_PLMN_BASED_CONTROL(_pMeasObjControl) \
    ((notMatchedPlmn_notAllowed == (_pMeasObjControl)->plmnBasedControl.notMatchedPlmnOption))

#define VCCB_CA_PROFILE_SUPPORT(_ptCi)                                               \
    (((_ptCi)->caProfileIdx >= 0) && ((_ptCi)->caProfileIdx < MAX_CA_PROFILE_NUM) && \
        ((_ptCi)->gnbNum < MAX_GNB_PER_SYS) &&                                       \
        (GNBINFO[(_ptCi)->gnbNum].idleMobilityControl.caProfileBasedIdleLbSwitch))

#define VCCB_MAKE_BC_KEYS(freqBandIndicator, nrCaBandwidthClassDL, nrCaBandwidthClassUL) \
    (((uint64_t)(freqBandIndicator)*324) + (((uint64_t)(nrCaBandwidthClassDL)) * 18) +   \
        (((uint64_t)(nrCaBandwidthClassUL))))

#define FREE_TEMP_UE_RESOURCE(_ptTemCi)                                             \
    do                                                                              \
    {                                                                               \
        /* Free UE Big capa if allocated */                                         \
        if(_ptTemCi->bitFlag.doNotReleaseExtNrUeCapa == VCCB_FLAG_OFF)              \
        {                                                                           \
            FnVCCB_FreeUeCapabilityInfoPerRatType(_ptTemCi, UE_NR_Capability);      \
        }                                                                           \
        if(_ptTemCi->bitFlag.doNotReleaseExtMrdcUeCapa == VCCB_FLAG_OFF)            \
        {                                                                           \
            FnVCCB_FreeUeCapabilityInfoPerRatType(_ptTemCi, UE_MRDC_Capability);    \
        }                                                                           \
        FnVCCB_FreeUeCapabilityInfoPerRatType(_ptTemCi, UE_EUTRA_Capability);       \
    } while (0)    

#define HAS_CALL_CANDIDATECELLINFOLISTMN(_ptCi)     \
    ((VCCB_FLAG_ON == (_ptCi)->cgConfigInfoFlag) && \
        (VCCB_FLAG_ON == (_ptCi)->cgConfigInfo.candidateCellInfoListMN_Flag))

#define IS_WAITING_FOR_DL_NAS_ACK(_ptCi) (_ptCi->dlNasWaitingAckTimer.id > 0)

#define VCCB_GET_SRB_ID_FOR_DLNAS(_ptCi, _srbId)                  \
    do                                                            \
    {                                                             \
        if (IS_VALID_NODE(SRB_NODE, _ptCi, &(_ptCi->srbInfo[1]))) \
        {                                                         \
            _srbId = ID_SRB2;                                     \
        }                                                         \
        else                                                      \
        {                                                         \
            _srbId = ID_SRB1;                                     \
        }                                                         \
    } while (0)

#define GET_NEED_TO_MODIFY_DL_UEAMBR(_ptCi) ((_ptCi)->ueInfo.ambr.fNeedModify_aggrMbrDl)
#define GET_NEED_TO_MODIFY_UL_UEAMBR(_ptCi) ((_ptCi)->ueInfo.ambr.fNeedModify_aggrMbrUl)

#define SET_NEED_TO_MODIFY_DL_UEAMBR(_ptCi, _onOff)            \
    do                                                         \
    {                                                          \
        (_ptCi)->ueInfo.ambr.fNeedModify_aggrMbrDl = (_onOff); \
    } while (0)

#define SET_NEED_TO_MODIFY_UL_UEAMBR(_ptCi, _onOff)            \
    do                                                         \
    {                                                          \
        (_ptCi)->ueInfo.ambr.fNeedModify_aggrMbrUl = (_onOff); \
    } while (0)

#define COVERT_VALUE_FROM_DB_TO_SPEC(_internalVal) (_internalVal + 1)  // PlusOne

#define RETURN_BASED_SET_BIT_MASK(__ptCi, __status, __bit_mask, __bit) \
    FnVCCB_ReturnBasedSetBitMask(__func__, __ptCi, __status, &__bit_mask, #__bit, __bit)

#define NEED_DlTrfStatusRptCfg_TO_BE_REFRESHED_PER_PDUSESS(_ptCi, _pduIdx) \
    ((_ptCi) && !IS_NRDC_SN(_ptCi) && ((_ptCi)->trafficMonitoringCfg.toBeRefreshedBitMap.pduSessIdx & (1 << (_pduIdx))))

#define NEED_DlTrfStatusRptCfg_TO_BE_REFRESHED_PER_DRB(_ptCi, _drbIdx) \
    ((_ptCi) && !IS_NRDC_SN(_ptCi) && ((_ptCi)->trafficMonitoringCfg.toBeRefreshedBitMap.drbIdx & (1 << (_drbIdx))))

#define NEED_TO_AUDIT_AUPF(_timer, _flag) ((_timer != 0) && (GET_E1_RESOURCE_FLAG(_flag)))

#define VCCB_CHECK_VALID_HO_ATTEMPT_STAT_TYPE_VOID(__type) \
    do                                                     \
    {                                                      \
        switch (__type)                                    \
        {                                                  \
            case HO_Att:                                   \
            case HO_PrepSucc:                              \
            case HO_Succ:                                  \
                break;                                     \
            default:                                       \
                return;                                    \
        }                                                  \
    } while (0)

#define SET_UEASSISTANCEINFO_FLAG_TO_BE_SEND(_flag, _target)    \
    {                                                           \
        ON_NRRRC_UE_ASSISTANCE_INFO_FLAG(_flag);                \
        (_target).isUpdated_Flag = VCCB_FLAG_ON;                \
    }

#define NEED_TO_REJECT_IF_PSCELL_BELOW_THLD(_ptGnb) \
    (VCCB_FLAG_ON == (_ptGnb)->cfg.gnbMobilityConfig.endcRejectRequestNoCellAboveThreshold)

#define IS_RPTCFG_FOR_NRDC_ADDITION(_pRptCfg) \
    ((_pRptCfg)->conf.reportType == measReport_A4 && (_pRptCfg)->conf.reportPurpose == a4Purpose_NrdcAddition)
#define IS_RPTCFG_FOR_NEDC_ADDITION(_pRptCfg) \
    ((_pRptCfg)->conf.reportType == measReport_B1Eutra && (_pRptCfg)->conf.reportPurpose == b1Purpose_NedcSnAddition)
#define IS_RPTCFG_FOR_MRDC_ADDITION(_pRptCfg) \
    (IS_RPTCFG_FOR_NRDC_ADDITION(_pRptCfg) || IS_RPTCFG_FOR_NEDC_ADDITION(_pRptCfg))

#define IS_PER_CELL_SEL_THLD_ENABLED(_pCell)                                                        \
    ((TRUE == FOO.VF_MobilityforENDC_PerCellSelectionThreshold) &&                                  \
        ((NOT_CONFIGURED != (_pCell)->mobilityConfig.endcPscellSelectionThreshold.thresholdRsrp) || \
            (NOT_CONFIGURED != (_pCell)->mobilityConfig.endcPscellSelectionThreshold.thresholdRsrq)))

#define IS_TRIGGERING_QUANTITY_RSRP(_quantityInfo) \
    (!(_quantityInfo).isTriggeringOptionSinr && (choice_rsrp_option == (_quantityInfo).triggeringOption))

#define IS_TRIGGERING_QUANTITY_RSRQ(_quantityInfo) \
    (!(_quantityInfo).isTriggeringOptionSinr && (choice_rsrq_option == (_quantityInfo).triggeringOption))

#define CHECK_MRO_HO_TRIGGER_IMMEDIATE \
    ((ptCi->mroInfo.hoTriggerType == MRO_HO_TRIGGER_IMMEDIATE) || (ptCi->mroInfo.hoTriggerType == MRO_HO_TRIGGER_NONE))

#define INIT_CELL_TIME_FOR_ODF(_pCtrl, _cellIdx)                     \
    {                                                                \
        _pCtrl->shutdownCellInfo[_cellIdx].shutdownTime.tv_sec = 0;  \
        _pCtrl->shutdownCellInfo[_cellIdx].shutdownTime.tv_nsec = 0; \
        _pCtrl->shutdownCellInfo[_cellIdx].expiredFlag = false;      \
    }

#define COMPARE_NRBAND_REQ_LIMIT_INFO(_ptCi, _gnbRequestedNrBand, _ueAppliedNrBand)                 \
    (IS_REDCAP_UE(_ptCi) ||  /* Redcap UE do not check following param*/                            \
      ((_ueAppliedNrBand.maxBandwidthRequestedDl == _gnbRequestedNrBand.maxBandwidthRequestedDl) && \
       (_ueAppliedNrBand.maxBandwidthRequestedUl == _gnbRequestedNrBand.maxBandwidthRequestedUl) && \
       (_ueAppliedNrBand.maxCarriersRequestedDl == _gnbRequestedNrBand.maxCarriersRequestedDl) &&   \
       (_ueAppliedNrBand.maxCarriersRequestedUl == _gnbRequestedNrBand.maxCarriersRequestedUl)))

#define COMPARE_EUTRABAND_REQ_LIMIT_INFO(_ptCi, _gnbRequestedEutraBand, _ueAppliedEutraBand)              \
    (IS_REDCAP_UE(_ptCi) ||  /* Redcap UE do not check following param*/                                  \
      ((_ueAppliedEutraBand.caBandwidthClassDlEutra == _gnbRequestedEutraBand.caBandwidthClassDlEutra) && \
       (_ueAppliedEutraBand.caBandwidthClassUlEutra == _gnbRequestedEutraBand.caBandwidthClassUlEutra)))

#define IS_MRO_ENABLED(_mroType, _ptCi)           (FnVCCB_CheckMroEnabled(_mroType, _ptCi))
#define SET_RLF_REPORT_AVAILABLE_FLAG(_ptCi, _ptIE) (FnVCCB_UpdateRlfReportAvailableFlag(_ptCi, _ptIE))

// SVR23B FGR-LC0710
#define IS_CPC_CPU_OVERLOAD_CONDITION(__val)                            \
    (((__val > 0) && (CFG->overloadStatus >= critical && CFG->overloadStatus <= minor) && \
         (__val >= CFG->overloadStatus))                                                  \
            ? TRUE                                                                        \
            : FALSE)

/*
[CPC Overload Enum (CFG->overloadStatus)]
typedef enum {
    indeterminate = 0,
    critical,
    major,
    minor,
    warning,
    cleared
} ;

[YANG Overload Enum(__val)]
typedef enum {
no-overload-control = 0,
cpu-load-critical,
cpu-load-major,
cpu-load-minor
}
*/

// SVR23B: FGR-LC0302
#define GET_CPC_OVERLOAD_STATE() (CFG->overloadStatus)
#define IS_AVAILABLE_UNDER_CPC_OVERLOAD(__val) \
    ((CFG->overloadControl.ueSigCpuOverloadControl.ueSigCpuOverloadAction == FALSE) || (CFG->overloadStatus == indeterminate) || (__val == 0) || ((__val < CFG->overloadStatus) ? TRUE : FALSE))

/* For FGR-LC0703 (Load Balancing between FR1 Carriers) */
#define LB_INIT_MEAS_STATE(_ptCi)                                 \
    {                                                             \
        VCCB_PRINT_LOG_SA_LB(_ptCi, "[SALB] Init SA LB info \n"); \
        ptCi->saMeas.lbIFMeasState = LB_MEAS_STATE_NOT_SELECTED;  \
        VCCB_CLEAR_TIMER(&_ptCi->lbMrTimer, CANCEL_TIMER);        \
    }

// For FGR-LC0711
#define IRAT_LB_INIT_MEAS_STATE(_ptCi)                                  \
    {                                                                   \
        VCCB_PRINT_LOG_IRAT_LB(_ptCi, "[IRATLB] Init IRAT LB info \n"); \
        FnVCCB_GetSaMeas(*(_ptCi)).iratLbHoTriggered = FALSE;           \
        FnVCCB_GetSaMeas(*(_ptCi)).iratLbHoState = LB_MEAS_STATE_NOT_SELECTED; \
        (_ptCi)->hoInfo.isIratLbHo = FALSE;                             \
        VCCB_CLEAR_TIMER(&_ptCi->iratLbMrWaitTimer, CANCEL_TIMER);      \
    }

// SVR24B FGR-LC0712
#define SET_VONR_LB_NOT_SUPPORT_STATE(_ptCi)                                        \
    do                                                                              \
    {                                                                               \
        VCCB_PRINT_LOG_VONR_LB(_ptCi, "[VONRLB] STATE VONR_LB_NOT_SUPPORT \n");     \
        _ptCi->saMeas.voNrLbState = VONR_LB_NOT_SUPPORT;                             \
        VCCB_CLEAR_TIMER(&_ptCi->voNrLbMrWaitTimer, INIT_TIMER);                    \
    } while(0)

#define SET_VONR_LB_INIT_STATE(_ptCi)                                               \
    do                                                                              \
    {                                                                               \
        VCCB_PRINT_LOG_VONR_LB(_ptCi, "[VONRLB] STATE VONR_LB_INIT \n");            \
        _ptCi->saMeas.voNrLbState = VONR_LB_INIT;                                    \
        VCCB_CLEAR_TIMER(&_ptCi->voNrLbMrWaitTimer, INIT_TIMER);                    \
    } while(0)

#define SET_VONR_LB_INACTIVE_STATE(_ptCi)                                           \
    do                                                                              \
    {                                                                               \
        VCCB_PRINT_LOG_VONR_LB(_ptCi, "[VONRLB] STATE VONR_LB_INACTIVE \n");        \
        _ptCi->saMeas.voNrLbState = VONR_LB_INACTIVE;                                \
        VCCB_CLEAR_TIMER(&_ptCi->voNrLbMrWaitTimer, INIT_TIMER);                    \
    } while (0)

#define SET_VONR_LB_ACTIVE_STATE(_ptCi)                                             \
    do                                                                              \
    {                                                                               \
        VCCB_PRINT_LOG_VONR_LB(_ptCi, "[VONRLB] STATE VONR_LB_ACTIVE \n");          \
        _ptCi->saMeas.voNrLbState = VONR_LB_ACTIVE;                                  \
        VCCB_CLEAR_TIMER(&_ptCi->voNrLbMrWaitTimer, INIT_TIMER);                    \
    } while (0)

#define IS_VONR_LB_NR_HANDOVER_PURPOSE(__reportType, __reportPurpose)             \
    (__reportType == measReport_A5 && __reportPurpose == a5Purpose_voNrNRLoadBalancing)

#define IS_LB_NR_HANDOVER_PURPOSE(__reportType, __reportPurpose)             \
    ((__reportType == measReport_A4 && __reportPurpose == a4Purpose_NRLoadBalancing) || \
     (__reportType == measReport_A5 && __reportPurpose == a5Purpose_NRLoadBalancing))

#define SET_NEED_CALL_RELEASE_WO_HO_CANCEL(_ptCi)                                    \
    do                                                                              \
    {                                                                               \
        (_ptCi)->hoInfo.cancelControl.needCallReleaseWithoutHoCancelProcess = true; \
    } while (0);

#define IS_ON_NEED_CALL_RELEASE_WO_HO_CANCEL(_ptCi) ((_ptCi)->hoInfo.cancelControl.needCallReleaseWithoutHoCancelProcess == true)

#define SET_NEED_BLIND_REDIRECTION_WO_HO_CANCEL(_ptCi)                                    \
    do                                                                              \
    {                                                                               \
        (_ptCi)->hoInfo.cancelControl.needServiceBorderBlindRediretion = true; \
    } while (0);

#define IS_ON_BLIND_REDIRECTION_WO_HO_CANCEL(_ptCi) ((_ptCi)->hoInfo.cancelControl.needServiceBorderBlindRediretion == true)

// STAT_HO_EUTRAN_OUT
#define VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_EUTRAN_OUT_STAT(__mType, __type) \
    do                                                                      \
    {                                                                       \
        switch (__mType)                                                    \
        {                                                                   \
            case InterSysLTE_Out_Succ:                                      \
                __type = HO_Succ;                                           \
                break;                                                      \
            default:                                                        \
                __type = HO_TYPE_MAX;                                       \
                break;                                                      \
        }                                                                   \
    } while (0)

#define VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_EUTRAN_FREQ_OUT_STAT(__mType, __type) \
    do                                                                      \
    {                                                                       \
        switch (__mType)                                                    \
        {                                                                   \
            case InterSysLTE_Out_Succ_FREQ_OUT:                             \
            case InterSysLTE_Out_EPSFallback_Succ_FREQ_OUT:                 \
            case InterSysLTE_Out_EmergencyFallback_Succ_FREQ_OUT:           \
                __type = HO_Succ;                                           \
                break;                                                      \
            default:                                                        \
                __type = HO_TYPE_MAX;                                       \
                break;                                                      \
        }                                                                   \
    } while (0)

#define VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_EUTRAN_REDCAP_STAT(__mType, __type) \
    do                                                                      \
    {                                                                       \
        switch (__mType)                                                    \
        {                                                                   \
            case InterSysLTE_Out_Succ_RedCap:                               \
            case InterSysLTE_Out_EPSFallback_Succ_RedCap:                   \
            case InterSysLTE_Out_EmergencyFallback_Succ_RedCap:             \
                __type = HO_Succ;                                           \
                break;                                                      \
            default:                                                        \
                __type = HO_TYPE_MAX;                                       \
                break;                                                      \
        }                                                                   \
    } while (0)


#define VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_EUTRAN_OUT_STAT(__mType, __type) \
    do                                                                        \
    {                                                                         \
        switch (__mType)                                                      \
        {                                                                     \
            case InterSysLTE_Out_HandoverCancel:                              \
                __type = HO_HandoverCancel;                                   \
                break;                                                        \
            case InterSysLTE_Out_RRE:                                         \
                __type = HO_RRE;                                              \
                break;                                                        \
            default:                                                          \
                __type = HO_TYPE_MAX;                                         \
                break;                                                        \
        }                                                                     \
    } while (0)

#define VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_EUTRAN_FREQ_OUT_STAT(__mType, __type) \
    do                                                                        \
    {                                                                         \
        switch (__mType)                                                      \
        {                                                                     \
            case InterSysLTE_Out_HandoverCancel_FREQ_OUT:                     \
                __type = HO_HandoverCancel;                                   \
                break;                                                        \
            case InterSysLTE_Out_RRE_FREQ_OUT:                                \
                __type = HO_RRE;                                              \
                break;                                                        \
            default:                                                          \
                __type = HO_TYPE_MAX;                                         \
                break;                                                        \
        }                                                                     \
    } while (0)

#define VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_EUTRAN_REDCAP_STAT(__mType, __type) \
    do                                                                        \
    {                                                                         \
        switch (__mType)                                                      \
        {                                                                     \
            case InterSysLTE_Out_HandoverCancel_RedCap:                       \
                __type = HO_HandoverCancel;                                   \
                break;                                                        \
            case InterSysLTE_Out_RRE_RedCap:                                  \
                __type = HO_RRE;                                              \
                break;                                                        \
            default:                                                          \
                __type = HO_TYPE_MAX;                                         \
                break;                                                        \
        }                                                                     \
    } while (0)


// STAT_HO_EUTRAN_OUT_FALLBACK
#define VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_EUTRAN_OUT_FALLBACK_STAT(__mType, __type) \
    do                                                                               \
    {                                                                                \
        switch (__mType)                                                             \
        {                                                                            \
            case InterSysLTE_Out_EPSFallback_Succ:                                   \
                __type = HO_Succ;                                                    \
                break;                                                               \
            default:                                                                 \
                __type = HO_TYPE_MAX;                                                \
                break;                                                               \
        }                                                                            \
    } while (0)

// STAT_HO_EUTRAN_IN
#define VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_EUTRAN_IN_STAT(__mType, __type) \
    do                                                                     \
    {                                                                      \
        switch (__mType)                                                   \
        {                                                                  \
            case InterSysLTE_In_Succ:                                      \
                __type = HO_Succ;                                          \
                break;                                                     \
            default:                                                       \
                __type = HO_TYPE_MAX;                                      \
                break;                                                     \
        }                                                                  \
    } while (0)

#define VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_EUTRAN_IN_REDCAP_STAT(__mType, __type) \
    do                                                                     \
    {                                                                      \
        switch (__mType)                                                   \
        {                                                                  \
            case InterSysLTE_In_Succ_RedCap:                               \
                __type = HO_Succ;                                          \
                break;                                                     \
            default:                                                       \
                __type = HO_TYPE_MAX;                                      \
                break;                                                     \
        }                                                                  \
    } while (0)


#define VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_EUTRAN_IN_STAT(__mType, __type) \
    do                                                                       \
    {                                                                        \
        switch (__mType)                                                     \
        {                                                                    \
            case InterSysLTE_In_HandoverCancel:                              \
                __type = HO_HandoverCancel;                                  \
                break;                                                       \
            case InterSysLTE_In_RRE:                                         \
                __type = HO_RRE;                                             \
                break;                                                       \
            default:                                                         \
                __type = HO_TYPE_MAX;                                        \
                break;                                                       \
        }                                                                    \
    } while (0)

#define VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_EUTRAN_IN_REDCAP_STAT(__mType, __type) \
    do                                                                       \
    {                                                                        \
        switch (__mType)                                                     \
        {                                                                    \
            case InterSysLTE_In_HandoverCancel_RedCap:                       \
                __type = HO_HandoverCancel;                                  \
                break;                                                       \
            case InterSysLTE_In_RRE_RedCap:                                  \
                __type = HO_RRE;                                             \
                break;                                                       \
            default:                                                         \
                __type = HO_TYPE_MAX;                                        \
                break;                                                       \
        }                                                                    \
    } while (0)

// STAT_HO_OUT
#define VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_OUT_STAT(__mType, __type) \
    do                                                               \
    {                                                                \
        switch (__mType)                                             \
        {                                                            \
            case IntraGnbOut_Succ:                                   \
            case IntraGnbOutWithNedc_Succ:                           \
            case IntraGnbOutwithNrdc_Succ:                           \
            case InterXnOut_Succ:                                    \
            case InterXnOutWithNedc_Succ:                            \
            case InterXnOutwithNrdc_Succ:                            \
            case InterNgOut_Succ:                                    \
            case InterNgOutWithNedc_Succ:                            \
            case InterNgOutwithNrdc_Succ:                            \
                __type = HO_Succ;                                    \
                break;                                               \
            default:                                                 \
                __type = HO_TYPE_MAX;                                \
                break;                                               \
        }                                                            \
    } while (0)

#define VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_OUT_SERVICE_TYPE_STAT(__mType, __type) \
    do                                                                            \
    {                                                                             \
        switch (__mType)                                                          \
        {                                                                         \
            case IntraGnbOut_Succ_SERVICE_TYPE:                                   \
            case IntraGnbOutWithNedc_Succ_SERVICE_TYPE:                           \
            case IntraGnbOutwithNrdc_Succ_SERVICE_TYPE:                           \
            case InterXnOut_Succ_SERVICE_TYPE:                                    \
            case InterXnOutWithNedc_Succ_SERVICE_TYPE:                            \
            case InterXnOutwithNrdc_Succ_SERVICE_TYPE:                            \
            case InterNgOut_Succ_SERVICE_TYPE:                                    \
            case InterNgOutWithNedc_Succ_SERVICE_TYPE:                            \
            case InterNgOutwithNrdc_Succ_SERVICE_TYPE:                            \
                __type = HO_Succ;                                                 \
                break;                                                            \
            default:                                                              \
                __type = HO_TYPE_MAX;                                             \
                break;                                                            \
        }                                                                         \
    } while (0)

#define VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_OUT_STAT(__mType, __type) \
    do                                                                 \
    {                                                                  \
        switch (__mType)                                               \
        {                                                              \
            case IntraGnbOut_HandoverCancel:                           \
            case IntraGnbOutWithNedc_HandoverCancel:                   \
            case IntraGnbOutwithNrdc_HandoverCancel:                   \
            case InterXnOut_HandoverCancel:                            \
            case InterXnOutWithNedc_HandoverCancel:                    \
            case InterXnOutwithNrdc_HandoverCancel:                    \
            case InterNgOut_HandoverCancel:                            \
            case InterNgOutWithNedc_HandoverCancel:                    \
            case InterNgOutwithNrdc_HandoverCancel:                    \
                __type = HO_HandoverCancel;                            \
                break;                                                 \
            case IntraGnbOut_RRE:                                      \
            case IntraGnbOutWithNedc_RRE:                              \
            case IntraGnbOutwithNrdc_RRE:                              \
            case InterXnOut_RRE:                                       \
            case InterXnOutWithNedc_RRE:                               \
            case InterXnOutwithNrdc_RRE:                               \
            case InterNgOut_RRE:                                       \
            case InterNgOutWithNedc_RRE:                               \
            case InterNgOutwithNrdc_RRE:                               \
                __type = HO_RRE;                                       \
                break;                                                 \
            default:                                                   \
                __type = HO_TYPE_MAX;                                  \
                break;                                                 \
        }                                                              \
    } while (0)

// STAT_HO_IN, STAT_HO_IN_SERVICE_TYPE
#define VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_IN_STAT(__mType, __type) \
    do                                                              \
    {                                                               \
        switch (__mType)                                            \
        {                                                           \
            case IntraGnbIn_Succ:                                   \
            case IntraGnbInWithNedc_Succ:                           \
            case IntraGnbInWithNrdc_Succ:                           \
            case InterXnIn_Succ:                                    \
            case InterXnInWithNedc_Succ:                            \
            case InterXnInWithNrdc_Succ:                            \
            case InterNgIn_Succ:                                    \
            case InterNgInWithNedc_Succ:                            \
            case InterNgInWithNrdc_Succ:                            \
                __type = HO_Succ;                                   \
                break;                                              \
            default:                                                \
                __type = HO_TYPE_MAX;                               \
                break;                                              \
        }                                                           \
    } while (0)

#define VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_IN_STAT(__mType, __type) \
    do                                                                \
    {                                                                 \
        switch (__mType)                                              \
        {                                                             \
            case IntraGnbIn_HandoverCancel:                           \
            case IntraGnbInWithNedc_HandoverCancel:                   \
            case IntraGnbInWithNrdc_HandoverCancel:                   \
            case InterXnIn_HandoverCancel:                            \
            case InterXnInWithNedc_HandoverCancel:                    \
            case InterXnInWithNrdc_HandoverCancel:                    \
            case InterNgIn_HandoverCancel:                            \
            case InterNgInWithNedc_HandoverCancel:                    \
            case InterNgInWithNrdc_HandoverCancel:                    \
                __type = HO_HandoverCancel;                           \
                break;                                                \
            case IntraGnbIn_RRE:                                      \
            case IntraGnbInWithNedc_RRE:                              \
            case IntraGnbInWithNrdc_RRE:                              \
            case IntraGnbInVoNR_RRE:                                  \
            case InterXnIn_RRE:                                       \
            case InterXnInWithNedc_RRE:                               \
            case InterXnInWithNrdc_RRE:                               \
            case InterNgIn_RRE:                                       \
            case InterNgInWithNedc_RRE:                               \
            case InterNgInWithNrdc_RRE:                               \
                __type = HO_RRE;                                      \
                break;                                                \
            default:                                                  \
                __type = HO_TYPE_MAX;                                 \
                break;                                                \
        }                                                             \
    } while (0)

#define VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_IN_REDCAP_STAT(__mType, __type) \
    do                                                              \
    {                                                               \
        switch (__mType)                                            \
        {                                                           \
            case IntraGnbIn_Succ_RedCap:                            \
            case InterXnIn_Succ_RedCap:                             \
            case InterNgIn_Succ_RedCap:                             \
                __type = HO_Succ;                                   \
                break;                                              \
            default:                                                \
                __type = HO_TYPE_MAX;                               \
                break;                                              \
        }                                                           \
    } while (0)


#define VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_IN_REDCAP_STAT(__mType, __type) \
    do                                                                \
    {                                                                 \
        switch (__mType)                                              \
        {                                                             \
            case IntraGnbIn_HandoverCancel_RedCap:                    \
            case InterXnIn_HandoverCancel_RedCap:                     \
            case InterNgIn_HandoverCancel_RedCap:                     \
                __type = HO_HandoverCancel;                           \
                break;                                                \
            case IntraGnbIn_RRE_RedCap:                                \
            case InterXnIn_RRE_RedCap:                                \
            case InterNgIn_RRE_RedCap:                                \
                __type = HO_RRE;                                      \
                break;                                                \
            default:                                                  \
                __type = HO_TYPE_MAX;                                 \
                break;                                                \
        }                                                             \
    } while (0)

// STAT_HO_INTRA_FREQ_OUT
#define VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_INTRA_FREQ_OUT_STAT(__mType, __type) \
    do                                                                          \
    {                                                                           \
        switch (__mType)                                                        \
        {                                                                       \
            case IntraFreqOut_Succ:                                             \
                __type = HO_Succ;                                               \
                break;                                                          \
            default:                                                            \
                __type = HO_TYPE_MAX;                                           \
                break;                                                          \
        }                                                                       \
    } while (0)

#define VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_INTRA_FREQ_OUT_REDCAP_STAT(__mType, __type) \
    do                                                                          \
    {                                                                           \
        switch (__mType)                                                        \
        {                                                                       \
            case IntraFreqOut_Succ_RedCap:                                      \
                __type = HO_Succ;                                               \
                break;                                                          \
            default:                                                            \
                __type = HO_TYPE_MAX;                                           \
                break;                                                          \
        }                                                                       \
    } while (0)


#define VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_INTRA_FREQ_OUT_STAT(__mType, __type) \
    do                                                                            \
    {                                                                             \
        switch (__mType)                                                          \
        {                                                                         \
            case IntraFreqOut_HandoverCancel:                                     \
                __type = HO_HandoverCancel;                                       \
                break;                                                            \
            case IntraFreqOut_RRE:                                                \
                __type = HO_RRE;                                                  \
                break;                                                            \
            default:                                                              \
                __type = HO_TYPE_MAX;                                             \
                break;                                                            \
        }                                                                         \
    } while (0)

#define VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_INTRA_FREQ_OUT_REDCAP_STAT(__mType, __type) \
    do                                                                            \
    {                                                                             \
        switch (__mType)                                                          \
        {                                                                         \
            case IntraFreqOut_HandoverCancel_RedCap:                              \
                __type = HO_HandoverCancel;                                       \
                break;                                                            \
            case IntraFreqOut_RRE_RedCap:                                         \
                __type = HO_RRE;                                                  \
                break;                                                            \
            default:                                                              \
                __type = HO_TYPE_MAX;                                             \
                break;                                                            \
        }                                                                         \
    } while (0)


// STAT_HO_INTER_FREQ_OUT
#define VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_INTER_FREQ_OUT_STAT(__mType, __type) \
    do                                                                          \
    {                                                                           \
        switch (__mType)                                                        \
        {                                                                       \
            case InterFreqOutWithGap_Succ:                                      \
            case InterFreqOutWithoutGap_Succ:                                   \
                __type = HO_Succ;                                               \
                break;                                                          \
            default:                                                            \
                __type = HO_TYPE_MAX;                                           \
                break;                                                          \
        }                                                                       \
    } while (0)

#define VCCB_GET_ADDL_HO_SUCC_TYPE_FROM_HO_INTER_FREQ_OUT_REDCAP_STAT(__mType, __type) \
    do                                                                          \
    {                                                                           \
        switch (__mType)                                                        \
        {                                                                       \
            case InterFreqOutWithGap_Succ_RedCap:                               \
            case InterFreqOutWithoutGap_Succ_RedCap:                            \
                __type = HO_Succ;                                               \
                break;                                                          \
            default:                                                            \
                __type = HO_TYPE_MAX;                                           \
                break;                                                          \
        }                                                                       \
    } while (0)


#define VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_INTER_FREQ_OUT_STAT(__mType, __type) \
    do                                                                            \
    {                                                                             \
        switch (__mType)                                                          \
        {                                                                         \
            case InterFreqOutWithGap_HandoverCancel:                              \
            case InterFreqOutWithoutGap_HandoverCancel:                           \
                __type = HO_HandoverCancel;                                       \
                break;                                                            \
            case InterFreqOutWithGap_RRE:                                         \
            case InterFreqOutWithoutGap_RRE:                                      \
                __type = HO_RRE;                                                  \
                break;                                                            \
            default:                                                              \
                __type = HO_TYPE_MAX;                                             \
                break;                                                            \
        }                                                                         \
    } while (0)

#define VCCB_GET_ADDL_HO_CANCEL_TYPE_FROM_HO_INTER_FREQ_OUT_REDCAP_STAT(__mType, __type) \
    do                                                                            \
    {                                                                             \
        switch (__mType)                                                          \
        {                                                                         \
            case InterFreqOutWithGap_HandoverCancel_RedCap:                       \
            case InterFreqOutWithoutGap_HandoverCancel_RedCap:                    \
                __type = HO_HandoverCancel;                                       \
                break;                                                            \
            case InterFreqOutWithGap_RRE_RedCap:                                  \
            case InterFreqOutWithoutGap_RRE_RedCap:                               \
                __type = HO_RRE;                                                  \
                break;                                                            \
            default:                                                              \
                __type = HO_TYPE_MAX;                                             \
                break;                                                            \
        }                                                                         \
    } while (0)


// NR_CONN_MC_23B
#define IS_OVERLOADED_TGT_GNB_CONTROL_ENABLED(_gnbNum) \
    (TRUE == GNBINFO[_gnbNum].cfg.restrictHoToOverloadedGnb.featureEnabled)
#define OVERLOADED_HO_TGT_GNB_LIST(_gnbNum) (GNBINFO[_gnbNum].overloadedTgtGnb)

// IRAT_HO_23B
#define IS_IRAT_HO_TARGET_NON_NBR_CELL() (IS_INTERRAT_HO() && TRUE == ptCi->hoInfo.nonNbrCell)

// MACRO TO REPRESENTS UNDEFINED PEER UE ID VALUE
#define PEER_UE_ID_UNDEFINED -1LL

#define IS_REDCAP_UE(_ptCi) (TRUE == (_ptCi)->redCapUeInfo.redCapUeFlag)
#define IS_REDCAP_UE_REF(_call) (TRUE == _call.redCapUeInfo.redCapUeFlag)

#define IS_VALID_NR_BAND(__nrBand)                    \
    (((__nrBand) >= MIN_NR_FREQ_BAND_IND) && ((__nrBand) <= MAX_NR_FREQ_BAND_IND))

#define IS_CA_AVAILABLE(_ptCi, _caAvailable)                                           \
    ((caAvailable_On == _caAvailable) ||                                               \
     ((caAvailable_OnSaOnly == _caAvailable) && (E_CALLTYPE_SA == _ptCi->callType)) || \
     ((caAvailable_OnNsaOnly == _caAvailable) && (E_CALLTYPE_NSA == _ptCi->callType)))

#define IS_RRC_SUSPEND_COMPLETED(_ptCi) \
    ((_ptCi->state == STATE_Inact_Suspend) || (_ptCi->state == STATE_Inact_ResumeReq))

// Validate arrays indexer
#define VCCB_CHECK_ITERATOR_VOID(__iter)                                           \
    do                                                                             \
    {                                                                              \
        if (0 > __iter)                                                            \
        {                                                                          \
            VCCB_PRINTF("%s, Invalid iterator! value=%d\n", __FUNCTION__, __iter); \
            return;                                                                \
        }                                                                          \
    } while (0)

#define OTHER_VENDOR_SN_IS_ALLOWED(_ptCi) \
    (DBG->flag.allowOtherVendorSn ||      \
        ((ptCi->gnbNum) < MAX_GNB_PER_SYS && GNBINFO[ptCi->gnbNum].cfg.nrdc.allowOtherVendorSn))
#define OTHER_VENDOR_MN_IS_ALLOWED(_ptCi) \
    (DBG->flag.allowOtherVendorMn ||      \
        ((ptCi->gnbNum) < MAX_GNB_PER_SYS && GNBINFO[ptCi->gnbNum].cfg.nrdc.allowOtherVendorMn))

// Only for NR-DC Addition
#define OTHER_VENDOR_IS_ALLOWED_FOR_NRDC(_ptCi)                                                 \
    ((ptCi->callType == E_CALLTYPE_SA && !IS_NRDC_SN(_ptCi) && OTHER_VENDOR_SN_IS_ALLOWED()) || \
        (IS_NRDC_SN(_ptCi) && OTHER_VENDOR_MN_IS_ALLOWED(_ptCi)))

// Procedure MACRO when UEContextModificationRequest is received from AMF
#define E1_MODIFY_MSG_SEND_AND_SET_STATE_FOR_UE_CTXT_MOD_PROC(_ptCi, _state)                               \
    do                                                                                                     \
    {                                                                                                      \
        int _status = VEIL_sendE1SetupModRelRequest(_ptCi, E1Procedure_BearerContextModification);         \
        VCCB_RETURN_ON_CALL_ERROR(_ptCi, _status, "VEIL_sendE1SetupModRelRequest(Modification) ERROR!\n"); \
        VLIB_AttachTimer(&_ptCi->timer, _ptCi, timE1_BearerContextModification_id);                        \
        VLIB_SetCurStateAll(_ptCi, _state);                                                                \
    } while (0)

#define F1_MODIFY_MSG_SEND_AND_SET_STATE_FOR_UE_CTXT_MOD_PROC(_ptCi, _state)                            \
    do                                                                                                  \
    {                                                                                                   \
        int _status = VFIL_sendF1_UeContextModificationRequest(_ptCi, NULL);                            \
        VCCB_RETURN_ON_CALL_ERROR(_ptCi, _status, "VFIL_sendF1_UeContextModificationRequest ERROR!\n"); \
        VLIB_AttachTimer(&_ptCi->timer, _ptCi, timF1_UeContextModification_id);                         \
        VLIB_SetCurStateAll(_ptCi, _state);                                                             \
    } while (0)

#define RRC_RECONFIG_MSG_SEND_AND_SET_STATE_FOR_UE_CTXT_MOD_PROC(_ptCi, _state)                              \
    do                                                                                                       \
    {                                                                                                        \
        int _status = FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer(_ptCi, FALSE, FALSE, ID_SRB1);  \
        if (_status != GOOD)                                                                                 \
        {                                                                                                    \
            VCCB_PRINT_CALL_ERROR(_ptCi, "FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer ERROR!\n"); \
            return ERROR;                                                                                    \
        }                                                                                                    \
        VLIB_SetCurStateAll(_ptCi, _state);                                                                  \
        VLIB_AttachTimer(&_ptCi->timer, _ptCi, timNRRRC_RRCReconfig_id);                                     \
    } while (0)

#define NG_RSP_MSG_SEND_AND_PROCEDURE_DONE_FOR_UE_CTXT_MOD_PROC(_ptCi)                                              \
    do                                                                                                              \
    {                                                                                                               \
        if (GET_RSP_PROC_REQUIRED_FLAG(_ptCi->modProcInfo.selectedModProc))                                         \
        {                                                                                                           \
            auto ngapSender = MsgNgapSender::createMessageSender(_ptCi, NG_UEContextModificationResponseAllAmf_id); \
            VALID_E_POINT_CHECK_ERROR(ngapSender);                                                                  \
            int _status = ngapSender->sendMsg();                                                                    \
            VCCB_RETURN_ON_CALL_ERROR(_ptCi, _status, "sendMsg(NG_UEContextModificationResponseAllAmf) ERROR!\n");  \
        }                                                                                                           \
        VCCM_SetStableState_CallSetup(_ptCi);                                                                       \
    } while (0)

#define PRINT_E1_CELL_GROUP_TO_MODIFY_DL_TX_STOP(_ptCi, _cellGroup, _cellGroupId)                               \
    do                                                                                                          \
    {                                                                                                           \
        if (IS_LOG_TRAFFIC(_ptCi) && _cellGroup.bit_mask & E1_dL_TX_Stop_present)                               \
        {                                                                                                       \
            if (IS_NRDC_SN(_ptCi))                                                                              \
            {                                                                                                   \
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[TRAFFIC, TX, SN]: %s-TX %s! (DRB ID:%u)\n",                 \
                    _cellGroupId == CellGroupId_MCG ? "MCG" : "SCG",                                            \
                    _cellGroup.dL_TX_Stop == E1_DL_TX_Stop_stop ? "STOP" : "RESUME",                            \
                    pDRBInfo->dRBId);                                                                           \
            }                                                                                                   \
            else                                                                                                \
            {                                                                                                   \
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[TRAFFIC, TX, MN]: %s-TX %s! (DRB ID:%u)\n",                 \
                    _cellGroupId == CellGroupId_MCG ? "MCG" : "SCG",                                            \
                    _cellGroup.dL_TX_Stop == E1_DL_TX_Stop_stop ? "STOP" : "RESUME",                            \
                    pDRBInfo->dRBId);                                                                           \
            }                                                                                                   \
        }                                                                                                       \
    } while (0)

#ifdef VCCB_IPC_TEST
#define IS_LOG_TRAFFIC(__ptCi) (DBG->flag.logTraffic == VCCB_FLAG_ON && (__ptCi->callType == E_CALLTYPE_SA))
#else
#define IS_LOG_TRAFFIC(__ptCi) (DBG->flag.logTraffic == VCCB_FLAG_ON && (__ptCi->callType == E_CALLTYPE_SA) && IS_MRDC(__ptCi))
#endif

#define SET_DRX_DISABLED_FOR_SRS(_ptCi, _type)             \
    do                                                     \
    {                                                      \
        (_ptCi)->drxCuInfo.srsConfigTriggeredType = _type; \
    } while (0)

#define UNSET_DRX_DISABLED_FOR_SRS(_ptCi)                               \
    do                                                                  \
    {                                                                   \
        (_ptCi)->drxCuInfo.srsConfigTriggeredType = SRS_Not_Configured; \
    } while (0)

#define GET_DRX_DISABLED_FOR_SRS_TYPE(_ptCi) ((_ptCi)->drxCuInfo.srsConfigTriggeredType)

#define IS_DRX_DISABLED_FOR_SRS(_ptCi) ((_ptCi)->drxCuInfo.srsConfigTriggeredType != SRS_Not_Configured)

#define VCCB_RETURN_ON_CALL_PARTIAL_RESPONSE_ERROR(__ptCi, __resultOfFunc, __msg, __args...) \
    do                                                                                       \
    {                                                                                        \
        if (RESPONSE_WITH_PARTIAL_SUCCESS == __resultOfFunc)                                 \
        {                                                                                    \
            VCCB_PRINT_CALL_ERROR((__ptCi), __msg, ##__args);                                \
            return RESPONSE_WITH_PARTIAL_SUCCESS;                                            \
        }                                                                                    \
    } while (0)

#define VCCB_CHECK_PLD_UPDATE_TYPE_AND_PRINT_WARNING(_updateType, _validType)                           \
    do                                                                                                  \
    {                                                                                                   \
        if (_updateType != _validType)                                                                  \
        {                                                                                               \
            VCCB_PRINTF("[%s] Warning! Unsupported Type %d(%s). Assuming the type as %s!\n",            \
                    __func__, _updateType, updateTypeToStr(_updateType), updateTypeToStr(_validType));  \
        }                                                                                               \
    } while (0)

#define VCCB_REPORT_CGI_STAT(__ptCi, __type, __autonomousGapFlag)                                              \
    do                                                                                                         \
    {                                                                                                          \
        char _buf[MAX_VCCB_STAT_FUNC_NAME];                                                                    \
        snprintf(_buf, MAX_VCCB_STAT_FUNC_NAME, "%.*s:%d", (MAX_VCCB_STAT_FUNC_NAME - 6), __func__, __LINE__); \
        _buf[MAX_VCCB_STAT_FUNC_NAME - 1] = '\0';                                                              \
        FnVCCB_CollectReportCgiStat(__ptCi, __type, __autonomousGapFlag, (char *)_buf);                        \
    } while (0)

#define VCCB_FLAG_ON_FOR_DBG_LOG_NRDC_BASIC(_flag) \
    do                                             \
    {                                              \
        if (DBG->flag.logNrdcBasic == true)        \
        {                                          \
            _flag = true;                          \
        }                                          \
    } while (0)

// Print :: The output message is mapped to a specific call and output. (CALL)
#ifdef __CALL_GRIND__
#define VCCB_PRINT_CALL_MSCGEN_COMMON(__level, __ptCi, __fmt, __args...)    \
    {                                                                       \
        (void)__ptCi;                                                       \
        if (0) check_args(__fmt, ##__args);                                 \
    }

#else

#define VCCB_PRINT_CALL_MSCGEN_COMMON(__level, __ptCi, __fmt, __args...)                \
    {                                                                                   \
        const VccbDbgLog_type &dbgLog = DBG->log;                                       \
        if (dbgLog.logMscGen == 1)                                                      \
        {                                                                               \
            VCCB_CHECK_ARGS(__fmt, ##__args);                                           \
            FnVCCB_UeBasedPrintWithMscGen(dbgLog, __ptCi, __level, __fmt, ##__args);    \
        }                                                                               \
    }

#endif

#define VCCB_PRINT_CALL_MSCGEN_INFORMATIVE(__ptCi, __fmt, __args...)   VCCB_PRINT_CALL_MSCGEN_COMMON(PL_CMD, __ptCi, __fmt, ##__args)
#define VCCB_PRINT_CALL_MSCGEN_CRITICAL(__ptCi, __fmt, __args...)      VCCB_PRINT_CALL_MSCGEN_COMMON(PL_CRITICAL, __ptCi, __fmt, ##__args)
#define VCCB_PRINT_CALL_MSCGEN_ERROR(__ptCi, __fmt, __args...)         VCCB_PRINT_CALL_MSCGEN_COMMON(PL_ERROR, __ptCi, __fmt, ##__args)
#define VCCB_PRINT_CALL_MSCGEN_MSG(__ptCi, __fmt, __args...)           VCCB_PRINT_CALL_MSCGEN_COMMON(PL_MSG, __ptCi, __fmt, ##__args)
#define VCCB_PRINT_CALL_MSCGEN_DATA(__ptCi, __fmt, __args...)          VCCB_PRINT_CALL_MSCGEN_COMMON(PL_DATA, __ptCi, ##__args)
#define VCCB_PRINT_CALL_MSCGEN_COMMENT(__ptCi, __fmt, __args...)       VCCB_PRINT_CALL_MSCGEN_COMMON(PL_COMMENT, __ptCi, ##__args)


#define MACRO_GET_CALL_SERVICE_TYPE(_ptCi, _serviceListSet)      \
    if(CFG->acpfInfo.serviceTypeOnOff==TRUE) {                   \
        if( FnVCCB_GetCallServiceType(_ptCi, _serviceListSet) == ERROR) \
        _serviceListSet.clear();                                 \
    }


#define MACRO_GET_DRB_SERVICE_TYPE(_ptCi, _ptDi, _serviceListSet)       \
    if(CFG->acpfInfo.serviceTypeOnOff==TRUE) {                          \
        if( FnVCCB_GetDrbServiceType(_ptCi, _ptDi, _serviceListSet) == ERROR ) \
        _serviiceListSet.clear();                                       \
    }

#define IS_VALID_QUEUEING_ACTION(_action) \
    ((ENQUEUE_NO_ACTION < _action && ENQUEUE_ACTION_MAXSIZE > _action))

#define VCCB_MOBILITY_INTRA_NR_STAT_CSL_MAX 255
#define VCCB_MOBILITY_INTER_RAT_STAT_CSL_MAX 128

#define VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(val)      \
    do                                                     \
    {                                                      \
        if ((val) < (VCCB_MOBILITY_INTRA_NR_STAT_CSL_MAX)) (val)++; \
    } while (0)

#define VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(val)               \
    do                                                               \
    {                                                                \
        if ((val) < (VCCB_MOBILITY_INTER_RAT_STAT_CSL_MAX)) (val)++; \
    } while (0)

#define VCCB_CSL_STAT_UPDATE_HO_INTRA_FREQ_OUT(_rCall, _mType)                                                     \
    do                                                                                                             \
    {                                                                                                              \
        switch (_mType)                                                                                            \
        {                                                                                                          \
            case IntraFreqOut_Att: /*IntraFreqOut_Att_RedCap*/                                                     \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.intraNrIntraFreqAtt);      \
                break;                                                                                             \
            case IntraFreqOut_PrepSucc: /*IntraFreqOut_PrepSucc_RedCap*/                                           \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.intraNrIntraFreqPrepSucc); \
                break;                                                                                             \
            case IntraFreqOut_Succ: /*IntraFreqOut_Succ_RedCap*/                                                   \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.intraNrIntraFreqSucc);     \
                break;                                                                                             \
            case IntraFreqOut_HandoverCancel: /*IntraFreqOut_HandoverCancel_RedCap*/                               \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(                                                          \
                    _rCall.cslInfo.cslMobilityInfo.intraNrIntraFreqHandoverCancel);                                \
                break;                                                                                             \
            case IntraFreqOut_RRE: /*IntraFreqOut_RRE_RedCap*/                                                     \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.intraNrIntraFreqRre);      \
                break;                                                                                             \
            default:                                                                                               \
                break;                                                                                             \
        }                                                                                                          \
    } while (0)

#define VCCB_CSL_STAT_UPDATE_HO_INTER_FREQ_OUT(_rCall, _mType)                                                \
    do                                                                                                        \
    {                                                                                                         \
        switch (_mType)                                                                                       \
        {                                                                                                     \
            case InterFreqOutWithGap_Att:    /*InterFreqOutWithGap_Att_RedCap*/                               \
            case InterFreqOutWithoutGap_Att: /*InterFreqOutWithoutGap_Att_RedCap*/                            \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.intraNrInterFreqAtt); \
                break;                                                                                        \
            case InterFreqOutWithGap_PrepSucc:    /*InterFreqOutWithGap_PrepSucc_RedCap*/                     \
            case InterFreqOutWithoutGap_PrepSucc: /*InterFreqOutWithoutGap_PrepSucc_RedCap*/                  \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.intraNrInterFreqPrepSucc); \
                break;                                                                                        \
            case InterFreqOutWithGap_Succ:    /*InterFreqOutWithGap_Succ_RedCap*/                             \
            case InterFreqOutWithoutGap_Succ: /*InterFreqOutWithoutGap_Succ_RedCap*/                          \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.intraNrInterFreqSucc); \
                break;                                                                                        \
            case InterFreqOutWithGap_HandoverCancel:    /*InterFreqOutWithGap_HandoverCancel_RedCap*/         \
            case InterFreqOutWithoutGap_HandoverCancel: /*InterFreqOutWithoutGap_HandoverCancel_RedCap*/      \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.intraNrInterFreqHandoverCancel); \
                break;                                                                                        \
            case InterFreqOutWithGap_RRE:    /*InterFreqOutWithGap_RRE_RedCap*/                               \
            case InterFreqOutWithoutGap_RRE: /*InterFreqOutWithoutGap_RRE_RedCap*/                            \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.intraNrInterFreqRre); \
                break;                                                                                        \
            default:                                                                                          \
                break;                                                                                        \
        }                                                                                                     \
    } while (0)

// SVR25B FGR-MC1009/MC1010 FR600
#define VCCB_CSL_STAT_UPDATE_HO_OUT(_rCall, _mType)                                                           \
    do                                                                                                        \
    {                                                                                                         \
        switch (_mType)                                                                                       \
        {                                                                                                     \
            case IntraGnbOut_Att:                                                                             \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.intraGnbHoAttCnt);    \
                break;                                                                                        \
            case IntraGnbOut_PrepSucc:                                                                        \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.intraGnbHoPrepCnt);   \
                break;                                                                                        \
            case IntraGnbOut_Succ:                                                                            \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.intraGnbHoExecCnt);   \
                break;                                                                                        \
            case IntraGnbOut_HandoverCancel:                                                                  \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.intraGnbHoCancelCnt); \
                break;                                                                                        \
            case IntraGnbOut_RRE:                                                                             \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.intraGnbHoRreCnt);    \
                break;                                                                                        \
            case InterXnOut_Att:                                                                              \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interGnbXnHoAttCnt);  \
                break;                                                                                        \
            case InterXnOut_PrepSucc:                                                                         \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interGnbXnHoPrepCnt); \
                break;                                                                                        \
            case InterXnOut_Succ:                                                                             \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interGnbXnHoExecCnt); \
                break;                                                                                        \
            case InterXnOut_HandoverCancel:                                                                   \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interGnbXnHoCancelCnt);\
                break;                                                                                        \
            case InterXnOut_RRE:                                                                              \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interGnbXnHoRreCnt);  \
                break;                                                                                        \
            case InterNgOut_Att:                                                                              \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interGnbNgHoAttCnt);  \
                break;                                                                                        \
            case InterNgOut_PrepSucc:                                                                         \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interGnbNgHoPrepCnt); \
                break;                                                                                        \
            case InterNgOut_Succ:                                                                             \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interGnbNgHoExecCnt); \
                break;                                                                                        \
            case InterNgOut_HandoverCancel:                                                                   \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interGnbNgHoCancelCnt);\
                break;                                                                                        \
            case InterNgOut_RRE:                                                                              \
                VCCB_INCREASE_MOBILITY_INTRA_NR_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interGnbNgHoRreCnt);  \
                break;                                                                                        \
            default:                                                                                          \
                break;                                                                                        \
        }                                                                                                     \
    } while (0)

#define VCCB_CSL_STAT_UPDATE_HO_EUTRAN_FREQ_OUT(_rCall, _mType)                                                       \
    do                                                                                                                \
    {                                                                                                                 \
        switch (_mType)                                                                                               \
        {                                                                                                             \
            case InterSysLTE_Out_Att_FREQ_OUT:                                                                        \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interSysLteAtt);             \
                break;                                                                                                \
            case InterSysLTE_Out_PrepSucc_FREQ_OUT:                                                                   \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interSysLtePrepSucc);        \
                break;                                                                                                \
            case InterSysLTE_Out_Succ_FREQ_OUT:                                                                       \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interSysLteSucc);            \
                break;                                                                                                \
            case InterSysLTE_Out_HandoverCancel_FREQ_OUT:                                                             \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interSysLteHandoverCancel);  \
                break;                                                                                                \
            case InterSysLTE_Out_RRE_FREQ_OUT:                                                                        \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interSysLteRre);             \
                break;                                                                                                \
            case InterSysLTE_Out_EPSFallback_Att_FREQ_OUT:                                                            \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interSysLteAttEpsFallback);  \
                break;                                                                                                \
            case InterSysLTE_Out_EPSFallback_PrepSucc_FREQ_OUT:                                                       \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(                                                            \
                    _rCall.cslInfo.cslMobilityInfo.interSysLtePrepSuccEpsFallback);                                   \
                break;                                                                                                \
            case InterSysLTE_Out_EPSFallback_Succ_FREQ_OUT:                                                           \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interSysLteSuccEpsFallback); \
                break;                                                                                                \
            case InterSysLTE_Out_EPSFallback_HandoverCancel_FREQ_OUT:                                                 \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(                                                            \
                    _rCall.cslInfo.cslMobilityInfo.interSysLteHandoverCancelEpsFallback);                             \
                break;                                                                                                \
            case InterSysLTE_Out_EPSFallback_RRE_FREQ_OUT:                                                            \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interSysLteRreEpsFallback);  \
                break;                                                                                                \
            case InterSysLTE_Out_EmergencyFallback_Att_FREQ_OUT:                                                      \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(                                                            \
                    _rCall.cslInfo.cslMobilityInfo.interSysLteAttEmergencyFallback);                                  \
                break;                                                                                                \
            case InterSysLTE_Out_EmergencyFallback_PrepSucc_FREQ_OUT:                                                 \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(                                                            \
                    _rCall.cslInfo.cslMobilityInfo.interSysLtePrepSuccEmergencyFallback);                             \
                break;                                                                                                \
            case InterSysLTE_Out_EmergencyFallback_Succ_FREQ_OUT:                                                     \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(                                                            \
                    _rCall.cslInfo.cslMobilityInfo.interSysLteSuccEmergencyFallback);                                 \
                break;                                                                                                \
            case InterSysLTE_Out_EmergencyFallback_HandoverCancel_FREQ_OUT:                                           \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(                                                            \
                    _rCall.cslInfo.cslMobilityInfo.interSysLteHandoverCancelEmergencyFallback);                       \
                break;                                                                                                \
            case InterSysLTE_Out_EmergencyFallback_RRE_FREQ_OUT:                                                      \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(                                                            \
                    _rCall.cslInfo.cslMobilityInfo.interSysLteRreEmergencyFallback);                                  \
                break;                                                                                                \
            default:                                                                                                  \
                break;                                                                                                \
        }                                                                                                             \
    } while (0)

#define VCCB_CSL_STAT_UPDATE_HO_EUTRAN_FREQ_OUT_REDCAP(_rCall, _mType)                                                \
    do                                                                                                                \
    {                                                                                                                 \
        switch (_mType)                                                                                               \
        {                                                                                                             \
            case InterSysLTE_Out_Att_RedCap:                                                                          \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interSysLteAtt);             \
                break;                                                                                                \
            case InterSysLTE_Out_PrepSucc_RedCap:                                                                     \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interSysLtePrepSucc);        \
                break;                                                                                                \
            case InterSysLTE_Out_Succ_RedCap:                                                                         \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interSysLteSucc);            \
                break;                                                                                                \
            case InterSysLTE_Out_HandoverCancel_RedCap:                                                               \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interSysLteHandoverCancel);  \
                break;                                                                                                \
            case InterSysLTE_Out_RRE_RedCap:                                                                          \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interSysLteRre);             \
                break;                                                                                                \
            case InterSysLTE_Out_EPSFallback_Att_RedCap:                                                              \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interSysLteAttEpsFallback);  \
                break;                                                                                                \
            case InterSysLTE_Out_EPSFallback_PrepSucc_RedCap:                                                         \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(                                                            \
                    _rCall.cslInfo.cslMobilityInfo.interSysLtePrepSuccEpsFallback);                                   \
                break;                                                                                                \
            case InterSysLTE_Out_EPSFallback_Succ_RedCap:                                                             \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interSysLteSuccEpsFallback); \
                break;                                                                                                \
            case InterSysLTE_Out_EPSFallback_HandoverCancel_RedCap:                                                   \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(                                                            \
                    _rCall.cslInfo.cslMobilityInfo.interSysLteHandoverCancelEpsFallback);                             \
                break;                                                                                                \
            case InterSysLTE_Out_EPSFallback_RRE_RedCap:                                                              \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(_rCall.cslInfo.cslMobilityInfo.interSysLteRreEpsFallback);  \
                break;                                                                                                \
            case InterSysLTE_Out_EmergencyFallback_Att_RedCap:                                                        \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(                                                            \
                    _rCall.cslInfo.cslMobilityInfo.interSysLteAttEmergencyFallback);                                  \
                break;                                                                                                \
            case InterSysLTE_Out_EmergencyFallback_PrepSucc_RedCap:                                                   \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(                                                            \
                    _rCall.cslInfo.cslMobilityInfo.interSysLtePrepSuccEmergencyFallback);                             \
                break;                                                                                                \
            case InterSysLTE_Out_EmergencyFallback_Succ_RedCap:                                                       \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(                                                            \
                    _rCall.cslInfo.cslMobilityInfo.interSysLteSuccEmergencyFallback);                                 \
                break;                                                                                                \
            case InterSysLTE_Out_EmergencyFallback_HandoverCancel_RedCap:                                             \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(                                                            \
                    _rCall.cslInfo.cslMobilityInfo.interSysLteHandoverCancelEmergencyFallback);                       \
                break;                                                                                                \
            case InterSysLTE_Out_EmergencyFallback_RRE_RedCap:                                                        \
                VCCB_INCREASE_MOBILITY_INTER_RAT_CSL_STAT(                                                            \
                    _rCall.cslInfo.cslMobilityInfo.interSysLteRreEmergencyFallback);                                  \
                break;                                                                                                \
            default:                                                                                                  \
                break;                                                                                                \
        }                                                                                                             \
    } while (0)

#define VCCB_RETAIN_STAT_CSL_ORDER_MAX               255
#define MACRO_INCREASE_RETAIN_STAT_CSL_COLLECT_ORDER(_ptCi)                                         \
    do                                                                                                  \
    {                                                                                                   \
        if (FOO.VF_CallSummaryLogs_KPI)                                                                 \
        {                                                                                               \
            if (_ptCi->cslInfo.retainStatInfo.collectOrder < VCCB_RETAIN_STAT_CSL_ORDER_MAX)     \
            {                                                                                           \
                _ptCi->cslInfo.retainStatInfo.collectOrder++;                                        \
            }                                                                                           \
            else                                                                                        \
            {                                                                                           \
                FnVCCB_RearrangeCslCollectOrder_RetainStat(_ptCi);                                      \
            }                                                                                           \
        }                                                                                               \
    } while (0)

#define SET_HO_CANCEL_FOR_PDU(_ptCi, _flagOnOff)            \
    do                                                      \
    {                                                       \
        _ptCi->hoInfo.needHoCancelForPdu = _flagOnOff;      \
    } while (0)

// Inter-gNB HO 
#define IS_HO_CANCEL_REQUIRED_FOR_PDU(_ptCi)   (_ptCi->hoInfo.needHoCancelForPdu == true)

#define GET_ALREADY_RELEASED_TO_UE(_ptDi)   (FnVCCB_IsDrbReleasedToUe(_ptDi))
#define SET_ALREADY_RELEASED_TO_UE(_ptDi, _value)                                                       \
    do {                                                                                                \
        _ptDi->alreadyReleasedByF1Partial_intraGnbOnlyUsed = _value;                                    \
    } while(0)

#define GET_NEED_SEND_TX_STOP_BY_FORCE(_ptDi)   (FnVCCB_NeedToSendTxStopForFailedDrb(_ptDi))
#define SET_NEED_SEND_TX_STOP_BY_FORCE(_ptDi, _value)                                                   \
    do {                                                                                                \
        _ptDi->needToSendTxStopByF1Partial_intraGnbOnlyUsed = _value;                                   \
    } while(0)

#define GET_NEED_RELEASE_FAIL_DRB_FROM_AMF(_ptDi)   (FnVCCB_NeedToReleaseFailedDrbFromAmf(_ptDi))
#define SET_NEED_RELEASE_FAIL_DRB_FROM_AMF(_ptDi, _value)                                               \
    do {                                                                                                \
        _ptDi->needToReleaseAmfByF1Partial_intraGnbOnlyUsed = _value;                                   \
    } while(0)

#define VHCM_SA_HO_IN_PARTIAL_FAIL_SERVICE_TYPE_STAT(__ptCi, __hoStatType)            \
    do                                                                                \
    {                                                                                 \
        if (FnVCCB_IsSupportedHandInPartialServiceType(__ptCi, __hoStatType) == true) \
        {                                                                             \
            FnVCCB_GetHandInFailedDrbsServiceType(__ptCi, __hoStatType);              \
        }                                                                             \
    } while (0)

#define VCCB_IS_VALID_LBM_PARAM_IDX_FOR_CONNECTED_LB(__Idx) \
    (((__Idx) >= NR_LBM_WINDOW0_UPDATE) && ((__Idx) <= NR_LBM_WINDOW1_FALLBACK))

// LBM Disabled
#define VCCB_CONN_LB_GET_DEFAULT_AVAIL_RSC_THRESHOLD(thresholdType) \
    do                                                      \
    {                                                       \
        switch (thresholdType)                              \
        {                                                   \
            case CONN_LB_THRESHOLD_GROUP0:                  \
                return connModeLbInfo.availRscThreshold;    \
            case CONN_LB_THRESHOLD_GROUP1:                  \
                return connModeLbInfo.availRscThreshold1;   \
            case CONN_LB_THRESHOLD_GROUP2:                  \
                return connModeLbInfo.availRscThreshold2;   \
            case CONN_LB_THRESHOLD_GROUP3:                  \
                return connModeLbInfo.availRscThreshold3;   \
            default:                                        \
                return 0;                                   \
        }                                                   \
    } while (0)

#define STAT_IS_MOBILITY_SERVICETYPE_FAMILY(_mFamily)                                                             \
    ((STAT_HO_EUTRAN_OUT_SERVICE_TYPE == _mFamily) || (STAT_HO_EUTRAN_OUT_FALLBACK_SERVICE_TYPE == _mFamily) ||   \
        (STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE == _mFamily) || (STAT_HO_EUTRAN_IN_SERVICE_TYPE == _mFamily) ||     \
        (STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE == _mFamily) || (STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE == _mFamily) || \
        (STAT_HO_OUT_SERVICE_TYPE == _mFamily) || (STAT_HO_IN_SERVICE_TYPE == _mFamily) ||                        \
        (STAT_REDIR_EUTRAN_OUT_SERVICE_TYPE == _mFamily) || (STAT_REDIR_NR_OUT_SERVICE_TYPE == _mFamily))


// The types of STAT_HO_OUT_SERVICE_TYPE and STAT_HO_OUT are all the same except HoNR_Out.
// Below MACRO is for handling STAT_HO_OUT_SERVICE_TYPE based on STAT_HO_OUT.        
#define STAT_HO_OUT_SERVICE_TYPE_OFFSET 1
#define STAT_HO_OUT_TYPE_FROM_SERVICE_TYPE(_familyId, _mType)                                      \
    do                                                                                             \
    {                                                                                              \
        if (_familyId == STAT_HO_OUT_SERVICE_TYPE) _mType -= STAT_HO_OUT_SERVICE_TYPE_OFFSET; \
    } while (0)

#define STAT_SERVICE_TYPE_FROM_HO_OUT_TYPE(_familyId, _mType)                                      \
    do                                                                                             \
    {                                                                                              \
        if (_familyId == STAT_HO_OUT_SERVICE_TYPE) _mType += STAT_HO_OUT_SERVICE_TYPE_OFFSET; \
    } while (0)
  
    
#define VCCB_COLLECT_AS_SECURITY_STAT(__ptCi)                                                                          \
    do                                                                                                                 \
    {                                                                                                                  \
        if (TRUE == Is_Support_NullSecurityCounter())                                                                  \
        {                                                                                                              \
            if (__ptCi->security.pdcpCtx.securityInfo.integrityAlgo == EIA0)                                           \
            {                                                                                                          \
                /*  Pegg the EIA0 Counter */                                                                           \
                MACRO_STAT_PMCC(STAT_AS_SECURITY_GLOBAL_ID_DU_ID, IntegrityAlgoNia0DuringSMC_GlobalId_DUID, __ptCi, 0, \
                    0, 0, 0, 0);                                                                                       \
            }                                                                                                          \
            if (__ptCi->security.pdcpCtx.securityInfo.cipherAlgo == EEA0)                                              \
            {                                                                                                          \
                /* Pegg the EEA0 Counter */                                                                            \
                MACRO_STAT_PMCC(STAT_AS_SECURITY_GLOBAL_ID_DU_ID, EncryptionAlgoNea0DuringSMC_GlobalId_DUID, __ptCi,   \
                    0, 0, 0, 0, 0);                                                                                    \
            }                                                                                                          \
        }                                                                                                              \
    } while (0)

#define SET_SLICE_REJECT_CAUSE(_ptCi) \
    do \
    { \
        (_ptCi)->hoInfo.sliceRejectionStats = TRUE; \
    } while (0)

#define VCCB_PRINT_CALL_LTM(__ptCi, __args...) VCCB_PRINT_CALL_WITH_DEBUG_COMMON(DBG->flag.logLtm, __ptCi, ##__args)

#define IS_LTM_PREP_MR(_reportType, _reportPurpose) (_reportType == measReport_A3 && _reportPurpose == a3Purpose_LtmPreparation)

#define VCCB_SET_RX_NOT_SUPPORT_SLICE_ON_SETUP_DRB_WITH_QOSFLOW_PDU(__ptCi, __ptDi)  \
    do                                                                              \
    {                                                                               \
        if ((__ptDi->drbStatus == S_Setup) || (__ptDi->drbStatus == S_Modify))      \
        {                                                                           \
            if(__ptDi->firstReqStatusInThisProcedure == S_Setup)                    \
            {                                                                       \
                __ptDi->rxNotSupportSlice = VCCB_FLAG_ON;                           \
            }                                                                       \
            /* It's possilbe (DRB : Modify, QosFlow: Setup) */                      \
            FnVCCB_SetQosFlowAsNotSupportSliceByDrb(__ptCi, __ptDi);                \
            FnVCCB_SetPduAsNotSupportSliceByDrb(__ptCi, __ptDi);                    \
        }                                                                           \
    } while (0)


#define VCCB_CHECK_LIST_COUNT_AND_RETURN(__itemCount, __listSize) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON(__itemCount, __listSize + 1, #__itemCount, return ERROR)
#define VCCB_CHECK_LIST_COUNT_AND_VAL(__itemCount, __listSize, __retVal) \
    VCCB_CHECK_RANGE_AND_RETURN_COMMON(__itemCount, __listSize + 1, #__itemCount, return __retVal)

#define IS_IN_CALL_RELEASE_PROCEDURE(ptCi) ((ptCi)->RelFlag == TRUE)

#define VCCB_SET_RX_DU_NOT_SUPPORT_VONR_5QI_ON_SETUP_DRB(__ptCi, __ptDi)                \
    do                                                                                  \
    {                                                                                   \
        if( (__ptDi->firstReqStatusInThisProcedure == S_Setup) &&                       \
            ((__ptDi->drbStatus == S_Setup) || (__ptDi->drbStatus == S_Modify)))        \
        {                                                                               \
            uint16_t qosFlowIdx = __ptDi->drbQosIdxInCall;                              \
            if (qosFlowIdx < MAX_QOS_FLOW_PER_CALL)                                     \
            {                                                                           \
                uint8_t fiveQi = 0;                                                     \
                VLIB_getFiveQi(&__ptCi->qosFlow[qosFlowIdx], &fiveQi);                  \
                if (fiveQi == VONR_5QI) __ptDi->rxDuNotSupportVoNr5qi = VCCB_FLAG_ON;   \
            }                                                                           \
        }                                                                               \
    } while (0)

#define MACRO_SAVE_REQUESTED_QOSFLOW_PARAM(__ptQi)                          \
{                                                                           \
    /* Save QosFlow Param */                                                \
    __ptQi->requestedQosParam.arp = __ptQi->qosParam.allocAndRetent.priorityLevel;   \
    if(ci_qos_char_non_dynamic_5qi == __ptQi->qosParam.qosCharacteristics)  \
    {                                                                       \
        __ptQi->requestedQosParam.fiveQi = __ptQi->qosParam.nonDyna.fiveQi; \
    }                                                                       \
    else                                                                    \
    {                                                                       \
        __ptQi->requestedQosParam.fiveQi = 0xFF;                            \
    }                                                                       \
    /* Set Save Flag */                                                     \
    __ptQi->isSavedRequestedQosParam = VCCB_FLAG_ON;                        \
}

#define MACRO_SAVE_REQUESTED_PDU_PARAM(__ptPi)              \
    do {                                                    \
        /* Save PDU Param */                                \
        __ptPi->requestedPduParam.sNssai = __ptPi->sNssai;  \
        /* Set Saved Flag */                                \
        __ptPi->isSavedRequestedPduParam = VCCB_FLAG_ON;    \
    } while (0)

#define GET_CSL_INIT_VALUE(_value) \
    (std::numeric_limits<std::remove_reference<decltype(_value)>::type>::max())

/**
 * @brief Macro to check NCI condition of MR (can be used for both serving and neigh cells)
 * @param ptMeasResultNR Pointer to measResultNR_type structure
 * @return true if conditions are met, false otherwise
 */
#define CHECK_CONDITION_NCI(ptMeasResultNR)                                            \
    ((nullptr != (ptMeasResultNR)) && (TRUE == (ptMeasResultNR)->cgiInfoFlag) &&       \
        (TRUE == (ptMeasResultNR)->cgiInfo.plmn_IdentityInfoList_Flag) &&              \
        (0 < (ptMeasResultNR)->cgiInfo.plmn_IdentityInfoList.nrofPLMN_IdentityInfo) && \
        (MAX_NUM_PLMN >= (ptMeasResultNR)->cgiInfo.plmn_IdentityInfoList.nrofPLMN_IdentityInfo))

#define CHECK_SRB1_STATE_AND_MAKE_SRB1_FOR_RRCSETUP_WITH_RRCSETUP_COMPLETE(_ptCi)                       \
    do                                                                                                  \
    {                                                                                                   \
        if ((_ptCi->bitFlag.isRrcSetupReqWithRrcSetupComplete) && (_ptCi->srbInfo[0].usage != CI_use))  \
        {                                                                                               \
            if (ERROR == FnVCCB_SendF1_DLRRCMessageTransfer_RRCSetup(_ptCi, VCCB_FLAG_OFF))             \
            {                                                                                           \
                VCCB_PRINT_CALL_ERROR(_ptCi, "MakeSRB1(isRrcSetupReqWithRrcSetupComplete) ERROR!!\n");  \
            }                                                                                           \
            /* SRB State is S_Setup */                                                                  \
        }                                                                                               \
    } while (0)

#define VCCB_COMMON_SET_UE_PLMN_WITH_RRC_SETUP_COMPLETE(_pRrcUnpack, _ptCi)                                         \
    do                                                                                                              \
    {                                                                                                               \
        if (NRRRC_RrcSetupComplete_id == _pRrcUnpack->msgId && _ptCi->servCellNum < MAX_CELL_NUM_VCCB)              \
        {                                                                                                           \
            NRRRC_RRCSetupComplete *ptMsgRrcCmpl =                                                                  \
                reinterpret_cast<NRRRC_RRCSetupComplete *>(&_pRrcUnpack->unpack[0] + _pRrcUnpack->unpackMsgOffset); \
            NRRRC_RRCSetupComplete_IEs *ptIE = &ptMsgRrcCmpl->criticalExtensions.u.rrcSetupComplete;                \
                                                                                                                    \
            if (NRRRC_criticalExtensions_rrcSetupComplete_chosen == ptMsgRrcCmpl->criticalExtensions.choice)        \
            {                                                                                                       \
                plmnId_type plmn;                                                                                   \
                int16_t _status = FnVCCB_GetPlmnBySelectedPlmnIdentity(_ptCi, ptIE->selectedPLMN_Identity, &plmn);  \
                if (_status == GOOD)                                                                                \
                {                                                                                                   \
                    _ptCi->ueInfo.selectedPlmnIdentity = ptIE->selectedPLMN_Identity;                               \
                    _ptCi->ueInfo.servedPlmn.longId = plmn.longId;                                                  \
                    _ptCi->managementTraceInfo.tracePLMNavailable = TRUE;                                           \
                }                                                                                                   \
            }                                                                                                       \
        }                                                                                                           \
    } while (0)

#define MACRO_CHECK_AND_SET_LTE_FALLBACK_TRIGGERED(__ptCi)                                  \
    do                                                                                      \
    {                                                                                       \
        if( (IS_EPS_FALLBACK_CASE(__ptCi)) ||                                               \
            ( (IS_EMERGENCY_FALLBACK_CASE(__ptCi)) &&                                       \
              (__ptCi->bitFlag.isEmergencyFallbackByAmf == VCCB_FLAG_OFF)))                 \
        {                                                                                   \
            FnVCCB_SetLteFallbackTriggeredForVoNR(__ptCi);                                  \
        }                                                                                   \
    } while (0)

#endif  // VCCB_VccbMacro_H_
