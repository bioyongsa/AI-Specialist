#ifndef VCCB_CDB_CALL_BACKUP_QUEUE_H_
#define VCCB_CDB_CALL_BACKUP_QUEUE_H_

#ifdef __CNF__
#include "VccbStruct.h"

#define VCCB_MAX_CALL_CTX_BUFF_Q_FULL VCCB_MAX_CALL_CTX_BACKUP_BUFF * 10

uint32_t FnVCCB_GetQueueSize(const uint8_t threadId);
int FnVCCB_EnqueueRedisCallQ(callInfo_type *ptCi, enumBackupType_type backupType);
extDbCallBackupQueueNode_type *FnVCCB_DequeueRedisCallQ(uint16_t threadId);

#ifdef IPC_TEST
void FnVCCB_InitCallQ(uint32_t threadId);
#endif //IPC_TEST

#endif //__CNF__
#endif // VCCB_CDB_CALL_BACKUP_QUEUE_H_