#ifndef VCCB_CDB_CdbRedisLib_H_
#define VCCB_CDB_CdbRedisLib_H_

#ifdef __CNF__
#include "VccbStruct.h"

#ifdef __VALKEY__
#include "valkey.h"

#define redisCommand                    valkeyCommand
#define redisCommandArgv                valkeyCommandArgv
#define redisConnectWithTimeout         valkeyConnectWithTimeout
#define redisContext                    valkeyContext
#define redisEnableKeepAliveWithInterval    valkeyEnableKeepAliveWithInterval
#define redisFree                       valkeyFree
#define redisGetReply                   valkeyGetReply
#define redisReply                      valkeyReply
#define redisSetTimeout                 valkeySetTimeout
#define redisvCommand                   valkeyvCommand
#define redisvAppendCommand             valkeyvAppendCommand

// ERROR CODE
#define REDIS_ERR               VALKEY_ERR
#define REDIS_OK                VALKEY_OK

#define REDIS_ERR_IO            VALKEY_ERR_IO
#define REDIS_ERR_EOF           VALKEY_ERR_EOF
#define REDIS_ERR_PROTOCOL      VALKEY_ERR_PROTOCOL
#define REDIS_ERR_OOM           VALKEY_ERR_OOM
#define REDIS_ERR_TIMEOUT       VALKEY_ERR_TIMEOUT
#define REDIS_ERR_OTHER         VALKEY_ERR_OTHER

#define REDIS_REPLY_STRING      VALKEY_REPLY_STRING
#define REDIS_REPLY_ARRAY       VALKEY_REPLY_ARRAY
#define REDIS_REPLY_INTEGER     VALKEY_REPLY_INTEGER
#define REDIS_REPLY_NIL         VALKEY_REPLY_NIL
#define REDIS_REPLY_STATUS      VALKEY_REPLY_STATUS
#define REDIS_REPLY_ERROR       VALKEY_REPLY_ERROR
#define REDIS_REPLY_DOUBLE      VALKEY_REPLY_DOUBLE
#define REDIS_REPLY_BOOL        VALKEY_REPLY_BOOL
#define REDIS_REPLY_MAP         VALKEY_REPLY_MAP
#define REDIS_REPLY_SET         VALKEY_REPLY_SET
#define REDIS_REPLY_ATTR        VALKEY_REPLY_ATTR
#define REDIS_REPLY_PUSH        VALKEY_REPLY_PUSH
#define REDIS_REPLY_BIGNUM      VALKEY_REPLY_BIGNUM
#define REDIS_REPLY_VERB        VALKEY_REPLY_VERB


#else
#include "hiredis.h"
#endif

#define VCCB_REDIS_PRINT_DATA(__fmt, __args...) \
    do                                          \
    {                                           \
        if (DBG->flag.extDbDbug == TRUE)        \
        {                                       \
            VCCB_PRINT_ERROR(__fmt, ##__args);  \
        }                                       \
    } while (0)

typedef struct VccbRedisConnection_s
{
    VccbEnvRedisConnectionInfo_Type *info;
    redisContext *context[REDIS_MAX_CONTEXT_CNT];
} VccbRedisConnection_type;

#define REDIS_0 0
#define REDIS_1 1
#define VCCB_MAX_PIPELINED_DB_CMD 1000
#define REDIS_DB_EXPIRE_TIME 300
#define REDIS_CALL_DB_EXPIRE_TIME 300
#define REDIS_BOTH_SIDE -1
#define VCCB_CNF_HOSTNAME_BUFF_SIZE 128
#define VCCB_REDIS_PORT 6379
#define REDIS_KEY_LEN 25
#define REDIS_COMMAND_LEN 50
#define HIREDIS_CONNECT_TIMEOUT 1
#define HIREDIS_COMMAND_TIMEOUT 10

#define MAX_EXT_DB_AUDIT_CALL_COUNT           (MAX_CALL_COUNT_PER_DISTCODE / 50)
#define REDIS_PASSWORD_OLD                    "access_redis_db"
#define REDIS_PASSWORD_NEW                    "S@msungs2cM2MU$ersPWRedis"
#define IS_TARGET_REDIS(_idx, _condition)     (_condition != REDIS_BOTH_SIDE && _idx != _condition)
#define REDIS_GET_ACTIVE_IDX(_connection)     (_connection.info->readContextIdx)
#define REDIS_GET_STANDBY_IDX(_connection)    (_connection.info->readContextIdx == 0) ? 1 : 0
#define IS_REDIS_CONNECTED(_connection, _idx) (_connection.info->isContextConnected[_idx])
#define IS_ALL_REDIS_DISCONNECTED(_connection) \
    (!IS_REDIS_CONNECTED(_connection, REDIS_0) && !IS_REDIS_CONNECTED(_connection, REDIS_1))

// Make Redis Key
void FnVCCB_RedisMakeCallSortedSetKey(char (&key)[REDIS_KEY_LEN], uint16_t groupIndex);
void FnVCCB_RedisMakeCellSortedSetKey(char (&key)[REDIS_KEY_LEN], uint16_t groupIndex);
void FnVCCB_RedisMakeGnbSortedSetKey(char (&key)[REDIS_KEY_LEN], uint16_t groupIndex);
void FnVCCB_RedisMakeCfgHashesKey(char (&key)[REDIS_KEY_LEN], uint16_t groupIndex);
void FnVCCB_RedisMakeCellHashesKey(char (&key)[REDIS_KEY_LEN], uint16_t groupIndex, uint32_t dataIndex);
void FnVCCB_RedisMakeGnbHashesKey(char (&key)[REDIS_KEY_LEN], uint16_t groupIndex, uint32_t dataIndex);
void FnVCCB_RedisMakeCallHashesKey(char (&key)[REDIS_KEY_LEN], uint16_t groupIndex, uint32_t dataIndex);
int FnVCCB_GetIdFromZrange(char *cmd, int cmdLen);

// Redis Command
int FnVCCB_RedisAppend(VccbRedisConnection_type &connection, const int contextIdx, const char *format, ...);
int FnVCCB_RedisCommandWithoutReply(
    VccbRedisConnection_type &connection, const int contextIdx, const char *format, ...);
int FnVCCB_RedisCommandGetReply(
    VccbRedisConnection_type &connection, const int contextIdx, redisReply **reply, const char *format, ...);
int FnVCCB_SendPipelinedCmd(VccbRedisConnection_type &connection, int targetDb);
int PingToServer(VccbRedisConnection_type &connection);
int FnVCCB_ConnectRedisDb(VccbRedisConnection_type &connection);

// Redis Resource Management
uint32_t FnVCCB_RedisGetCommandCount(VccbRedisConnection_type const &connection, int contextIdx);
void FnVCCB_RedisFreeContext(VccbRedisConnection_type &connection, int contextIdx);
void FnVCCB_InitRedisContext(VccbRedisConnection_type &connection);
void FnVCCB_DisconnectRedisDb(VccbRedisConnection_type &connection);
void FnVCCB_RedisDisconnected(VccbRedisConnection_type &connection, int contextIdx);

#endif  //__CNF__
#endif  // VCCB_CDB_CdbRedisLib_H_
