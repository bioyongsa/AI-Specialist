#ifndef VCCB_COM_ComEndian_H_
#define VCCB_COM_ComEndian_H_

#include <endian.h>

// Only Real Target and Little Endian System
#if (__BYTE_ORDER == __LITTLE_ENDIAN)

#include <VccbStruct.h>

#define CONVERT_HOST_ORDER(_PT_ALL_) VLIB_MsgByteOrder(_PT_ALL_, ci_Rx)
#define CONVERT_NET_ORDER(_PT_ALL_)  VLIB_MsgByteOrder(_PT_ALL_, ci_Tx)
#define ENDIAN_CONVERT(x)                  \
    do                                     \
    {                                      \
        if (2 <= sizeof(x))                \
        {                                  \
            VLIB_ByteOrder(&x, sizeof(x)); \
        }                                  \
    } while (0)

void VLIB_MsgByteOrder(bigMessage_type *, enumDirection_type);
void VLIB_ByteOrder(void *src, uint32_t len);

#else

#define CONVERT_HOST_ORDER(_PT_ALL_)
#define CONVERT_NET_ORDER(_PT_ALL_)
#define ENDIAN_CONVERT(x)

#endif  //#if (!defined(HOST_SIM) &&  __BYTE_ORDER == __LITTLE_ENDIAN)

#endif  //#ifndef VCCB_COM_ComEndian_H_
