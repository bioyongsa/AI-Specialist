/**
 * @file        ComNRRRCEnumsToValues.h
 * @brief       Maps NR RRC enums to its corresponding values
 */

#ifndef VCCB_COM_ComNRRRCEnumsToValues_H_
#define VCCB_COM_ComNRRRCEnumsToValues_H_

#include "VccbStruct.h"

static inline int32_t qOffsetRangeToValue(enumQOffsetRange e)
{
    switch (e)
    {
        case qOffset_minus_24:
            return -24;
        case qOffset_minus_22:
            return -22;
        case qOffset_minus_20:
            return -20;
        case qOffset_minus_18:
            return -18;
        case qOffset_minus_16:
            return -16;
        case qOffset_minus_14:
            return -14;
        case qOffset_minus_12:
            return -12;
        case qOffset_minus_10:
            return -10;
        case qOffset_minus_8:
            return -8;
        case qOffset_minus_6:
            return -6;
        case qOffset_minus_5:
            return -5;
        case qOffset_minus_4:
            return -4;
        case qOffset_minus_3:
            return -3;
        case qOffset_minus_2:
            return -2;
        case qOffset_minus_1:
            return -1;
        case qOffset_0:
            return 0;
        case qOffset_plus_1:
            return 1;
        case qOffset_plus_2:
            return 2;
        case qOffset_plus_3:
            return 3;
        case qOffset_plus_4:
            return 4;
        case qOffset_plus_5:
            return 5;
        case qOffset_plus_6:
            return 6;
        case qOffset_plus_8:
            return 8;
        case qOffset_plus_10:
            return 10;
        case qOffset_plus_12:
            return 12;
        case qOffset_plus_14:
            return 14;
        case qOffset_plus_16:
            return 16;
        case qOffset_plus_18:
            return 18;
        case qOffset_plus_20:
            return 20;
        case qOffset_plus_22:
            return 22;
        case qOffset_plus_24:
            return 24;
        default:
            return 0;
    }
}

static inline int32_t nrValueToQOOffsetRange(int32_t v)
{
    switch (v)
    {
        case -24:
            return qOffset_minus_24;
        case -22:
            return qOffset_minus_22;
        case -20:
            return qOffset_minus_20;
        case -18:
            return qOffset_minus_18;
        case -16:
            return qOffset_minus_16;
        case -14:
            return qOffset_minus_14;
        case -12:
            return qOffset_minus_12;
        case -10:
            return qOffset_minus_10;
        case -8:
            return qOffset_minus_8;
        case -6:
            return qOffset_minus_6;
        case -5:
            return qOffset_minus_5;
        case -4:
            return qOffset_minus_4;
        case -3:
            return qOffset_minus_3;
        case -2:
            return qOffset_minus_2;
        case -1:
            return qOffset_minus_1;
        case 0:
            return qOffset_0;
        case 1:
            return qOffset_plus_1;
        case 2:
            return qOffset_plus_2;
        case 3:
            return qOffset_plus_3;
        case 4:
            return qOffset_plus_4;
        case 5:
            return qOffset_plus_5;
        case 6:
            return qOffset_plus_6;
        case 8:
            return qOffset_plus_8;
        case 10:
            return qOffset_plus_10;
        case 12:
            return qOffset_plus_12;
        case 14:
            return qOffset_plus_14;
        case 16:
            return qOffset_plus_16;
        case 18:
            return qOffset_plus_18;
        case 20:
            return qOffset_plus_20;
        case 22:
            return qOffset_plus_22;
        case 24:
            return qOffset_plus_24;
        default:
            return qOffset_0;
    }
}

static inline int32_t eutraQOffsetRangeToValue(enumEutraQOffsetRange e)
{
    switch (e)
    {
        case eutraQOffsetRange_noUse:
            return 0;
        case eutraQOffsetRange_minus_24:
            return -24;
        case eutraQOffsetRange_minus_22:
            return -22;
        case eutraQOffsetRange_minus_20:
            return -20;
        case eutraQOffsetRange_minus_18:
            return -18;
        case eutraQOffsetRange_minus_16:
            return -16;
        case eutraQOffsetRange_minus_14:
            return -14;
        case eutraQOffsetRange_minus_12:
            return -12;
        case eutraQOffsetRange_minus_10:
            return -10;
        case eutraQOffsetRange_minus_8:
            return -8;
        case eutraQOffsetRange_minus_6:
            return -6;
        case eutraQOffsetRange_minus_5:
            return -5;
        case eutraQOffsetRange_minus_4:
            return -4;
        case eutraQOffsetRange_minus_3:
            return -3;
        case eutraQOffsetRange_minus_2:
            return -2;
        case eutraQOffsetRange_minus_1:
            return -1;
        case eutraQOffsetRange_0:
            return 0;
        case eutraQOffsetRange_plus_1:
            return 1;
        case eutraQOffsetRange_plus_2:
            return 2;
        case eutraQOffsetRange_plus_3:
            return 3;
        case eutraQOffsetRange_plus_4:
            return 4;
        case eutraQOffsetRange_plus_5:
            return 5;
        case eutraQOffsetRange_plus_6:
            return 6;
        case eutraQOffsetRange_plus_8:
            return 8;
        case eutraQOffsetRange_plus_10:
            return 10;
        case eutraQOffsetRange_plus_12:
            return 12;
        case eutraQOffsetRange_plus_14:
            return 14;
        case eutraQOffsetRange_plus_16:
            return 16;
        case eutraQOffsetRange_plus_18:
            return 18;
        case eutraQOffsetRange_plus_20:
            return 20;
        case eutraQOffsetRange_plus_22:
            return 22;
        case eutraQOffsetRange_plus_24:
            return 24;
        default:
            return 0;
    }
}

static inline enumEutraQOffsetRange eutraValueToQOffsetRange(int32_t v)
{
    switch (v)
    {
        case -24:
            return eutraQOffsetRange_minus_24;
        case -22:
            return eutraQOffsetRange_minus_22;
        case -20:
            return eutraQOffsetRange_minus_20;
        case -18:
            return eutraQOffsetRange_minus_18;
        case -16:
            return eutraQOffsetRange_minus_16;
        case -14:
            return eutraQOffsetRange_minus_14;
        case -12:
            return eutraQOffsetRange_minus_12;
        case -10:
            return eutraQOffsetRange_minus_10;
        case -8:
            return eutraQOffsetRange_minus_8;
        case -6:
            return eutraQOffsetRange_minus_6;
        case -5:
            return eutraQOffsetRange_minus_5;
        case -4:
            return eutraQOffsetRange_minus_4;
        case -3:
            return eutraQOffsetRange_minus_3;
        case -2:
            return eutraQOffsetRange_minus_2;
        case -1:
            return eutraQOffsetRange_minus_1;
        case 0:
            return eutraQOffsetRange_0;
        case 1:
            return eutraQOffsetRange_plus_1;
        case 2:
            return eutraQOffsetRange_plus_2;
        case 3:
            return eutraQOffsetRange_plus_3;
        case 4:
            return eutraQOffsetRange_plus_4;
        case 5:
            return eutraQOffsetRange_plus_5;
        case 6:
            return eutraQOffsetRange_plus_6;
        case 8:
            return eutraQOffsetRange_plus_8;
        case 10:
            return eutraQOffsetRange_plus_10;
        case 12:
            return eutraQOffsetRange_plus_12;
        case 14:
            return eutraQOffsetRange_plus_14;
        case 16:
            return eutraQOffsetRange_plus_16;
        case 18:
            return eutraQOffsetRange_plus_18;
        case 20:
            return eutraQOffsetRange_plus_20;
        case 22:
            return eutraQOffsetRange_plus_22;
        case 24:
            return eutraQOffsetRange_plus_24;
        default:
            return eutraQOffsetRange_noUse;
    }
}

static inline uint32_t reportIntervalToValue(enumReportInterval e)
{
    switch(e)
    {
        case reportInterval_ms120:
            return 120U;
        case reportInterval_ms240:
            return 240U;
        case reportInterval_ms480:
            return 480U;
        case reportInterval_ms640:
            return 640U;
        case reportInterval_ms1024:
            return 1024U;
        case reportInterval_ms2048:
            return 2048U;
        case reportInterval_ms5120:
            return 5120U;
        case reportInterval_ms10240:
            return 10240U;
        case reportInterval_ms20480:
            return 20480U;
        case reportInterval_ms40960:
            return 40960U;
        case reportInterval_min1:
            return 60000U;
        case reportInterval_min6:
            return 360000U;
        case reportInterval_min12:
            return 720000U;
        case reportInterval_min30:
            return 1800000U;
        default:
            return 0U;
    }
}

static inline uint8_t VCCM_enumReportAmount2value(enumReportAmount reportAmount)
{
    switch (reportAmount)
    {
        case reportAmount_r1:
            return 1;
        case reportAmount_r2:
            return 2;
        case reportAmount_r4:
            return 4;
        case reportAmount_r8:
            return 8;
        case reportAmount_r16:
            return 16;
        case reportAmount_r32:
            return 32;
        case reportAmount_r64:
            return 64;
        case reportAmount_infinity:
        default:
            return 0xFF;
    }
}

static inline uint16_t pciRangeTovalue(enumPciRangeType pciRange)
{
    switch (pciRange)
    {
        case PciRange_n4:
            return 4;
        case PciRange_n8:
            return 8;
        case PciRange_n12:
            return 12;
        case PciRange_n16:
            return 16;
        case PciRange_n24:
            return 24;
        case PciRange_n32:
            return 32;
        case PciRange_n48:
            return 48;
        case PciRange_n64:
            return 64;
        case PciRange_n84:
            return 84;
        case PciRange_n96:
            return 96;
        case PciRange_n128:
            return 128;
        case PciRange_n168:
            return 168;
        case PciRange_n252:
            return 252;
        case PciRange_n504:
            return 504;
        case PciRange_n1008:
            return 1008;
        default:
            return 0;
    }
};

#endif // VCCB_COM_ComNRRRCEnumsToValues_H_
