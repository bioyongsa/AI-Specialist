/**
 * @file        ComInclude.h
 * @brief       This is a file commonly included in VCCB. It is referenced in the Source(*.c, *.cpp) file by default.
 *              Proceed with caution when appending to this file. File changes become more associative and cause slow builds. Add minimal.
 * 
 * @author      Call S/W R&D Group/Samsung Electronics
 * @date        2022/11/11
 * @version
 */

#ifndef VCCB_COM_INCLUDE_H_
#define VCCB_COM_INCLUDE_H_

#include "ComInclude.min.h"

// Message Struct
#include "msg_def_call_5g.h"
#include "msg_type_5g_cucp.h"
#include "mbox_id_call_5g.h"
#include "msg_id_5g_cucp.h"
#include "mbox_id_oam_lte.h"
#include "mbox_id_oam.h"
#include "cp_def.h"
#include "CallCommon.h"
#include "cp_macro.h"
#include "cause_call_5g.h"

#include "PM_FAMILY_ID.h"

// Global (CFG, ENV, ...)
#include "ComGlobalData.h"

#include "ComInline.h"

// Automation Wrapper
#include "ComAutoNtrace.hpp"  // Only CPP Include, NTRACE Wrapper
#include "ComAutoUnlock.hpp"  // Only CPP Include, LOCK Wrapper

#include "ComPrint.h"     // For Log
#include "ComLibIpcApi.h" // For Ipc
#include "ComLibTimer.h"  // For Timer
#include "ComLibStatistic.h"

#include "VccbStructCInterface.h"
#include "VccbStructCppInterface.hpp"

#include "ComCppWrapper.h"

#include "RscCall.h"
#include "RscProto.h"

#endif // VCCB_COM_INCLUDE_H_
