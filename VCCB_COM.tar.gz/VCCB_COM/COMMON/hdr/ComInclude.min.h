/**
 * @file        ComInclude.min.h
 * @brief       This is a file commonly included in VCCB. It is referenced in the Header(*.h) file by default.
 *              Proceed with caution when appending to this file. File changes become more associative and cause slow builds. Add minimal.
 * 
 * @author      Call S/W R&D Group/Samsung Electronics
 * @date        2022/11/11
 * @version
 */

#ifndef VCCB_COM_INCLUDE_MIN_H_
#define VCCB_COM_INCLUDE_MIN_H_

// System
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

// C Standard Header
#include <pthread.h>

#include <map>
#include <set>
#include <list>
#include <array>
#include <queue>
#include <deque>
#include <bitset>
#include <string>
#include <vector>
#include <exception>
#include <algorithm>
#include <iostream>
#include <sstream>
#include <iterator>
#include <numeric>
#include <memory>
#include <unordered_map>
#include <unordered_set>
#include <functional> //From ComContainers.hpp

#include <sys/time.h>
#include <sys/timeb.h>

#include "VccbDefine.h"
#include "VccbStruct.h"

// As of c 17, when the name conflicts with 'namespace std',
// data type ambiguity occurs, so it is called separately.
// - using namespace std;
using std::map;
using std::set;
using std::list;
using std::array;
using std::queue;
using std::deque;
using std::bitset;
using std::string;
using std::vector;
using std::exception;
using std::iostream;
using std::iterator;
using std::unordered_map;
using std::unordered_set;
using std::make_shared;
using std::shared_ptr;
using std::pair;
using std::min;
using std::find_if;
using std::begin;
using std::end;

#endif // VCCB_COM_INCLUDE_MIN_H_