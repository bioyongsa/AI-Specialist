/**
 * @file     : ComRangeAdaptors.hpp
 * @brief    : header of range adaptors
 *
 * @author   : k.laskowski2@samsung.com
 * @date     : 2023-07-17
 *
 * Copyright 2023 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#include <iterator>

namespace rangeAdaptors
{

template <typename Iterator>
class Range
{
public:
    Range(Iterator begin, Iterator end) : begin_(begin), end_(end) {}

    Iterator begin() const { return begin_; }
    Iterator end() const { return end_; }

private:
    Iterator begin_;
    Iterator end_;
};

// This class and a concept of filtering ranges is *heavily* influenced by Boost.Range adaptors. To read more visit:
// https://theboostcpplibraries.com/boost.range-adaptors
template <typename Iterator, typename Predicate>
class FilterIterator
{
    typedef std::iterator_traits<Iterator> iteratorTraits;

public:
    // I decided to lower the category of FilterIterator to the simplest one: LegacyInputIterator in order to implement
    // the smallest number of operations. 
    // Q: Why FilterIterator category cannot be simply inherited from Iterator? 
    // A: FilterIterator cannot provide all operations base Iterator provide. For example iterator to C-array meets
    // LegacyRandomAccessIterator requirements but FilterIterator cannot provide one of its operation "a+n" as it is not
    // aware of number of elements satisfying a predicate.
    typedef typename std::input_iterator_tag iterator_category;
 
    // Inherit all other properties from base Iterator.
    typedef typename iteratorTraits::value_type value_type;
    typedef typename iteratorTraits::difference_type difference_type;
    typedef typename iteratorTraits::reference reference;
    typedef typename iteratorTraits::pointer pointer;

    FilterIterator(Predicate predicate, Iterator begin, Iterator end) :
        predicate_(predicate),
        current_(begin),
        end_(end)
    {
        satisfyPredicate();
    }

    reference operator*() const { return *current_; }

    FilterIterator& operator++()
    {
        ++current_;
        satisfyPredicate();
        return *this;
    }
    pointer operator->() const { return current_.operator->(); }

    bool operator==(const FilterIterator& rhs) const { return current_ == rhs.current_; }

    bool operator!=(const FilterIterator& rhs) const { return !(*this == rhs); }

private:
    void satisfyPredicate()
    {
        while (current_ != end_ && !predicate_(*current_))
        {
            ++current_;
        }
    }
    Predicate predicate_;
    Iterator current_;
    Iterator end_;
};

template <typename Container, typename Predicate>
auto filtered(Container& c, Predicate predicate) -> Range<FilterIterator<decltype(std::begin(c)), Predicate>>
{
    using WrappedIteratorType = decltype(std::begin(c));
    using FilterIteratorType = FilterIterator<WrappedIteratorType, Predicate>;

    auto begin = FilterIteratorType(predicate, std::begin(c), std::end(c));
    auto end = FilterIteratorType(predicate, std::end(c), std::end(c));
    return Range<FilterIteratorType>{begin, end};
}
}  // namespace rangeAdaptors