/**
 * @file     : ComAsnUtil.hpp
 * @brief    : header of asn utility functions
 *
 * @author   : p.kups@partner.samsung.com
 * @date     : 2023/06/28
 *
 * Copyright 2023 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef VCCB_COM_ComAsnUtil_HPP_
#define VCCB_COM_ComAsnUtil_HPP_

#include "compat_glibc.h"
#include "ComInline.h"
#include "ComGlobalData.h"
#include "VccbDefine.h"
#include "ComMacro.h"
#include <cstdint>

namespace asn
{
namespace util
{

/****************************************************************************
 *  @brief Allocates array of elements in global memory
 ****************************************************************************/
template <typename T>
int16_t VCCB_GlobalAlloc(T *&ptT, int num)
{
    if (0 != fnGlobalValueAlloc((unsigned char **)&ptT, (int)sizeof(T) * num))
    {
        VCCB_PRINT_ERROR("ERROR: fnGlobalValueAlloc failed sizeof(T)(%zu) num(%d)!\n", sizeof(T), num);

        return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 *  @brief Link elements in array
 ****************************************************************************/
template <typename T>
int16_t VCCB_ConnectLinkedList(T *ptT, int num)
{
    if (0 != fnConnectLinkedList((void *)ptT, sizeof(T), num))
    {
        VCCB_PRINT_ERROR("ERROR: fnConnectLinkedList failed num(%d)!\n", num);

        return ERROR;
    }

    return GOOD;
}

class SupportedBitmask
{
public:
    SupportedBitmask(uint32_t x) : supportedBitmask_(x) {}
    bool isOtherBitmaskSupported(uint32_t x) const {return (~((supportedBitmask_) | ~(x)) == 0); } 
private:
    uint32_t supportedBitmask_;
};

template <typename T> T* ptUnpackConvert(msgUnpack_type *ptUnpack)
{
    return reinterpret_cast<T*>(&ptUnpack->unpack[0] + ptUnpack->unpackMsgOffset);
}

} // util
} // asn

#endif /* VCCB_COM_ComAsnUtil_HPP_ */