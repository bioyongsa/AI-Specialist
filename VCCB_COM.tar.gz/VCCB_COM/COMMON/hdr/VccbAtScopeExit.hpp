#pragma once

namespace Vccb
{

/**
 * @brief Execute a callable at the scope exit.
 * 
 * @tparam T 
 */
template <typename T>
class AtScopeExit
{
private:
    T _callable;

public:
    explicit AtScopeExit(T callable) :
        _callable(std::move(callable))
    {}
    ~AtScopeExit()
    {
        _callable();
    }
};

/**
 * @brief Make an instance of class AtScopeExit.
 *        Usage:
 *          auto action = MakeAtScopeExit([](){});
 * 
 * @tparam T 
 * @param callable 
 * @return AtScopeExit<T> 
 */
template <typename T>
inline AtScopeExit<T> MakeAtScopeExit(T&& callable)
{
    return AtScopeExit<T>(std::forward<T>(callable));
}

} // namespace Vccb
