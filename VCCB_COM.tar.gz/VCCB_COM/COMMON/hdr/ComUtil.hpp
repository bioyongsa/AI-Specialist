/**
 * @file     : ComUtil.hpp
 * @brief    : header of utility functions
 *
 * @author   : k.laskowski2@partner.samsung.com
 * @date     : 2020/11/25
 *
 * Copyright 2020 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef VCCB_COM_ComUtil_HPP_
#define VCCB_COM_ComUtil_HPP_

#include "compat_glibc.h"

namespace util
{
template <typename T, size_t N>
constexpr size_t arraySize(T (&)[N])
{
    return N;
}

template <typename T, unsigned N>
unsigned minOfArraySizeAndNumOfElems(T (&)[N], unsigned int size)
{
    return MIN(N, size);
}

namespace str
{
template <typename T, typename ParseFunc>
static T str_to_num(const char* inputStr, ParseFunc parseFunc)
{
    if (inputStr == nullptr)
    {
        return 0;
    }

    char* endptr = nullptr;
    auto result = parseFunc(inputStr, &endptr, 10);

    if (endptr == inputStr || *endptr != '\0')
    {
        return 0;
    }

    if (result < std::numeric_limits<T>::min() || result > std::numeric_limits<T>::max())
    {
        return 0;
    }

    return static_cast<T>(result);
}

template <typename T>
static T vccb_strtol(const char* inputStr)
{
    return str_to_num<T>(inputStr, std::strtol);
}

template <typename T>
static T vccb_strtoll(const char* inputStr)
{
    return str_to_num<T>(inputStr, std::strtoll);
}

template <typename T>
static T vccb_strtoul(const char* inputStr)
{
    return str_to_num<T>(inputStr, std::strtoul);
}

template <typename T>
static T vccb_strtoull(const char* inputStr)
{
    return str_to_num<T>(inputStr, std::strtoull);
}
};  // namespace str

}  // namespace util

#endif /* VCCB_COM_ComUtil_HPP_ */
