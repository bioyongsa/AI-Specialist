/**
 * @file     : VccbStructCppInterface.hpp
 * @brief    : header file for operators defined for objects from VccbStruct.h
 *
 * @author   : m.ciurej@samsung.com
 * @date     : 2022/02/10
 *
 * Copyright 2022 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information). One
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * one entered into with Samsung.
 */

#ifndef VCCB_COM_VccbStructCppInterface_HPP_
#define VCCB_COM_VccbStructCppInterface_HPP_

#include "VccbStruct.h"

bool operator==(const measGapConfig_type &first, const measGapConfig_type &second);
bool operator==(const measuredFrequencies_type &first, const measuredFrequencies_type &second);
bool operator!=(const smtc1_type &first, const smtc1_type &second);
bool operator==(const smtc1_type &first, const smtc1_type &second);
bool operator<(const smtc1_type &first, const smtc1_type &second);
bool operator!=(const smtc2_type &first, const smtc2_type &second);
bool operator!=(const ssbMeasurementConfiguration_type &first, const ssbMeasurementConfiguration_type &second);
bool operator!=(const ssbConfigMobilityUe_type &first, const ssbConfigMobilityUe_type &second);
bool operator!=(const thresholdNR_type &first, const thresholdNR_type &second);
bool operator!=(const csi_rs_ResourceMobility_type &first, const csi_rs_ResourceMobility_type &second);
bool operator!=(const csi_rs_CellMobility_type &first, const csi_rs_CellMobility_type &second);
bool operator!=(const qOffsetSSBRangeList_type &first, const qOffsetSSBRangeList_type &second);
bool operator!=(const reportQuantity_type &first, const reportQuantity_type &second);
bool operator!=(const cellToMeasure_type &first, const cellToMeasure_type &second);
bool operator!=(const sMeasure_type &first, const sMeasure_type &second);
bool operator!=(const filterConfig_type &first, const filterConfig_type &second);
bool operator!=(const quantityConfigRS_type &first, const quantityConfigRS_type &second);
bool operator!=(const quantityConfigurationNR_type &first, const quantityConfigurationNR_type &second);
bool operator!=(const quantityConfigurationEUTRA_type &first, const quantityConfigurationEUTRA_type &second);
bool operator!=(const gapConfig_type &first, const gapConfig_type &second);
bool operator!=(const measGapConfig_type &first, const measGapConfig_type &second);
bool operator<(const measurementObjectNRDu_type &lhs, const measurementObjectNRDu_type &rhs);
bool operator<(const measurementObjectEUTRADu_type &lhs, const measurementObjectEUTRADu_type &rhs);
bool operator<(const measurementObjectDu_type &lhs, const measurementObjectDu_type &rhs);
bool operator!=(const measurementObjectNRDu_type &lhs, const measurementObjectNRDu_type &rhs);
bool operator!=(const measurementObjectEUTRADu_type &lhs, const measurementObjectEUTRADu_type &rhs);
bool operator!=(const timerT312_type &lhs, const timerT312_type &rhs);
bool operator==(const blackCellsUe_type &first, const blackCellsUe_type &second);
bool operator==(const blackCellsEutra_type &first, const blackCellsEutra_type &second);
bool operator<(const upmCgi_type &a, const upmCgi_type &b);
bool operator<(const cgi_type &n1, const cgi_type &n2);
bool operator==(const measTriggerUe_type &first, const measTriggerUe_type &second);
bool operator!=(const measTriggerUe_type &first, const measTriggerUe_type &second);
bool operator==(const measDoubleTriggerUe_type &first, const measDoubleTriggerUe_type &second);
bool operator!=(const measDoubleTriggerUe_type &first, const measDoubleTriggerUe_type &second);
bool operator==(const pciRange_type &first, const pciRange_type &second);
bool operator!=(const pciRange_type &first, const pciRange_type &second);
bool operator==(const vccbGlobalGnbId_type &first, const vccbGlobalGnbId_type &second);
bool operator==(const TceAddress_type& lhs, const TceAddress_type& rhs);
bool operator!=(const TceAddress_type& lhs, const TceAddress_type& rhs);
bool operator==(const optionalDelta_type &lhs, const optionalDelta_type &rhs);
bool operator==(const optionalDeltaPerTrigger_type &lhs, const optionalDeltaPerTrigger_type &rhs);
bool operator==(const fr1PowerClassSavedDeltas_type &lhs, const fr1PowerClassSavedDeltas_type &rhs);
bool operator!=(const fr1PowerClassSavedDeltas_type &lhs, const fr1PowerClassSavedDeltas_type &rhs);
bool operator==(const ssbMeasTiming_type &lhs, const ssbMeasTiming_type &rhs);
bool operator!=(const ssbMeasTiming_type &lhs, const ssbMeasTiming_type &rhs);
bool operator==(const redirectionInfoEutra_type &lhs, const redirectionInfoEutra_type &rhs);
bool operator<(const ImeisvFeatureControlInformationEntry_type& lhs, const ImeisvFeatureControlInformationEntry_type& rhs);
struct ImeisvFeatureControlInformationEntryComp
{
    bool operator()(const ImeisvFeatureControlInformationEntry_type& elem, const uint64_t imeisv)
    {
        return elem.maskedImeisv < imeisv;
    }
};
bool operator!=(const UlGapFr2Config_type &lhs, const UlGapFr2Config_type &rhs);

#endif  // VCCB_COM_VccbStructCppInterface_HPP_