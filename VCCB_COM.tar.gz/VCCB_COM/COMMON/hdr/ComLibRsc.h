#ifndef VCCB_COM_ComLibRsc_H_
#define VCCB_COM_ComLibRsc_H_

/*----------------------------------------------------------------------------
 * Define    :    Include Header Files
 * ---------------------------------------------------------------------------
 */
#include "ComInclude.min.h"

// SLR450_A074
typedef struct vrrmCellLoadState_s
{
    uint8_t state;              // 0:uncongested state, 1:congested state
    uint8_t ambrEnableChgFlag;  // 1: PLD ambrEnable has changed use -> no_use. 0 : else

    timerInfo_type timer;
} vrrmCellLoadState_type;

typedef enum
{
    ascendMode,   // Low ID -> High ID
    descendMode,  // High ID -> Low ID
    otherMode     // ascendMode, "MinDrbId=3"
} enumDRBallocMode_type;

typedef enum
{
    vrrmUNCONGESTED,  // UE AMBR control off
    vrrmCONGESTED     // UE AMBR control on
} enumCellLoadState_type;

typedef enum
{
    VRRM_CALL_CNT = 0,
    VRRM_DRB_CNT = 1
} vrrmThresCall_type;

typedef enum
{
    MinDrbId = MIN_DRB_ID,
    MaxDrbId = MAX_DRB_ID,
    MinLochId = 3,
    MaxLochId = 10
} enumRBrange;

void VRRM_delCellDrbCount(callInfo_type *ptCi, uint16_t cellNum, uint16_t erabIdx, int useOldQciFlag);
int VRRM_assignRB(callInfo_type *ptCi, callERABInfo_type *ptRi, uint16_t *errCause);
void VRRM_delCellassignedULOnlyRoHCDrbCount(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdx, int useOldQciFlag);
void VRRM_addCellassignedULOnlyRoHCDrbCount(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdx);
void VRRM_delULOnlyRoHCCellCallCount(callInfo_type *ptCi, uint16_t cellNum);
void VRRM_addULOnlyRoHCCellCallCount(callInfo_type *ptCi, uint16_t cellNum);

void FnVCCB_FinalizeSaConnStat_AfterCleaningBearer(callInfo_type *ptCi, uint16_t cellNum, uint8_t rrcStatType);
void FnVCCB_FinalizeNrdcSnConnStat(callInfo_type *ptCi, uint16_t cellNum);
void FnVCCB_CompareAndAddDrbCountOfSaRrcConn(callInfo_type *ptCi, uint16_t newCellNum, uint16_t drbIdxInCall);
void FnVCCB_CompareAndAddDrbCountOfSaRrcInact(callInfo_type *ptCi, uint16_t newCellNum, uint16_t drbIdxInCall);
void FnVCCB_CompareAndAddVonrEmerCountOfSaRrcConn(callInfo_type *ptCi, uint16_t newCellNum);

void FnVCCB_CalculateDrbHoldingTimeOfSaRrcConn(callInfo_type *ptCi, uint16_t drbIdxInCall, uint8_t actFlag);
void FnVCCB_CalculateDrbHoldingTimeOfSaRrcInact(callInfo_type *ptCi, uint16_t drbIdxInCall, uint8_t actFlag);
void FnVCCB_CalculateDrbHoldingTimeOfSaRrcConnInact(callInfo_type *ptCi, uint16_t drbIdxInCall, uint8_t actFlag);
void FnVCCB_CalculateDrbSetupTime(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t actFlag);

void FnVCCB_AddCellDrbCountOfSaRrcConn(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdxInCall);
void FnVCCB_AddCellDrbCountOfSaRrcInact(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdxInCall);
void FnVCCB_AddCellVonrEmerCountOfSaRrcConn(callInfo_type *ptCi, uint16_t cellNum);

void FnVCCB_DelCellDrbCountWithMarkedInfoOfSaRrcConn(callInfo_type *ptCi, uint16_t drbIdxInCall);
void FnVCCB_DelCellDrbCountWithMarkedInfoOfSaRrcInact(callInfo_type *ptCi, uint16_t drbIdxInCall);
void FnVCCB_DelCellVonrEmerCountWithMarkedInfoOfSaRrcConn(callInfo_type *ptCi);

void FnVCCB_UpdateAllDrbCountAndHoldTimeOfSaUe(callInfo_type *ptCi, uint16_t cellNum, uint8_t rrcStatType);
void FnVCCB_UpdateVonrEmerCountAndHoldTimeOfSaUe(callInfo_type *ptCi, uint16_t cellNum, uint8_t statType);
void FnVCCB_UpdateVoNrEmergencyCallAndReleaseStat(callInfo_type *ptCi, uint8_t releaseStatFlag);

void FnVCCB_CompareAndAddRohcDrbCountInRrcConn(callInfo_type *ptCi, uint16_t cellNum, uint16_t callDrbIdx);
void FnVCCB_UpdateRohcDrbCount(callInfo_type *ptCi, uint16_t cellNum, uint8_t rrcStatType);

void FnVCCB_CompareAndAddNrdcSnTermDrbCount(callInfo_type *ptCi, uint16_t newCellNum, uint16_t drbIdxInCall);
void FnVCCB_UpdateAllNrdcSnTermDrbCountAndHoldTime(callInfo_type *ptCi, uint16_t cellNum);
void FnVCCB_CompareAndAddRohcDrbCountInRrcInact(callInfo_type *ptCi, uint16_t cellNum, uint16_t callDrbIdx);
void FnVCCB_addSymmRoHCDrbCountInRrcConn(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdx);
void FnVCCB_delSymmRoHCDrbCountInRrcConn(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdx);
void FnVCCB_addSymmRoHCDrbCountInRrcInact(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdx);
void FnVCCB_delSymmRoHCDrbCountInRrcInact(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdx);
void FnVCCB_delSymmRoHCCellCallCount(callInfo_type *ptCi, uint16_t cellNum);
void FnVCCB_addSymmRoHCCellCallCount(callInfo_type *ptCi, uint16_t cellNum);

void FnVCCB_addULRoHCDrbCountInRrcInact(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdx);
void FnVCCB_delULRoHCDrbCountInRrcInact(callInfo_type *ptCi, uint16_t cellNum, uint16_t drbIdx);

void FnVCCB_UpdateEhcDrbCount(callInfo_type *ptCi, uint8_t rrcStatType, uint16_t cellNum);
void FnVCCB_CompareAndAddEhcDrbCountInRrcConn(callInfo_type *ptCi, uint16_t callDrbIdx, uint16_t cellNum);
void FnVCCB_addEHCDrbCountInRrcConn(callInfo_type *ptCi, uint16_t drbIdx, uint16_t cellNum);
void FnVCCB_delEHCDrbCountInRrcConn(callInfo_type *ptCi, uint16_t drbIdx, uint16_t cellNum);
void FnVCCB_CompareAndAddEhcDrbCountInRrcInact(callInfo_type *ptCi, uint16_t callDrbIdx, uint16_t cellNum);
void FnVCCB_delEHCDrbCountInRrcInact(callInfo_type *ptCi, uint16_t drbIdx, uint16_t cellNum);
void FnVCCB_addEHCDrbCountInRrcInact(callInfo_type *ptCi, uint16_t drbIdx, uint16_t cellNum);

#endif
