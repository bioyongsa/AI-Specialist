/**
 * @file     : ComConsecutiveIdsPool.hpp
 * @brief    : header of id pools
 *
 * Copyright 2023 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */
#pragma once
#include <array>
#include <cstdint>
#include <optional>

namespace util
{

/****************************************************************************
 * @brief           ConsecutiveIdsPool
 *                  Class which represents container contains range of positive 
 *                  values <From, To> with occupy and free states.  User can occupy 
 *                  and free specific value or receive first not occupied value in range.
 *                  At the beginning of object lifetime, all values are not occupied.
 *                  Following class doesn't use dynamic allocation.
 *                  Method occupy - occupy specific id in IdsPool
 *                  Method isOccupied - check if id is occupied in IdsPool
 *                  Method take - get first not occupied id from IdsPool
 *                  Method free - free specific id in idsPool
 *                  Method clear - free all ids in idsPool
 ****************************************************************************/
template <uint32_t From, uint32_t To>
class ConsecutiveIdsPool
{
public:
    ConsecutiveIdsPool()
    {
        static_assert(From <= To, "Cannot create empty pool!");
        idsPool.fill(false);
    }

    void occupy(const uint32_t id)
    {
        if(id >= From && id <= To)
        {
            idsPool[id - From] = true;
        }
    }

    bool isOccupied(const uint32_t id)
    {
        if(id >= From && id <= To)
        {
            return idsPool[id - From];
        }
        return false;
    }

    std::optional<uint32_t> take()
    {
        for(size_t i = 0; i < idsPool.size(); i++)
        {
            if(idsPool[i] == false)
            {   
                idsPool[i] = true;
                return std::make_optional<uint32_t>(i + From);
            }
        }
        return std::nullopt;
    }

    void free(const uint32_t id)
    {
        if(id >= From && id <= To)
        {
            idsPool[id - From] = false;
        }
    }

    void clear()
    {
        idsPool.fill(false);
    }

private:
    std::array<bool, To - From + 1> idsPool;
};

}