/**
 * @file        FeatMro.cpp
 * @brief       Utility functions for MRO
 */

#include "FeatMro.h"

#include "FeatCommon.h"
#include "FeatSon.h"
#include "FeatMro.h"
#include "FeatTrace.h"
#include "FeatCallInfo.h"
#include "FeatConditionalHo.h"

#include "ComInclude.h"
#include "ComLibUtility.h"

#include "MsgNrRrcStore.h"
#include "MsgNgapSend.h"
#include "MsgNgapStore.h"
#include "MsgXnapSend.h"

#include "ngapUnpackMsg.h"
#include "xnapUnpackMsg.h"

#include "NRRRC.h"

void FnVCCB_LibStatMroEvent(const char *pFuncName, const uint64_t lineNumber, const char *pStrFamily, int mFamily,
    const char *pStrMtype, int mType, callInfo_type *ptCi, const char *pStrSrcCgi, cgi_type *pSrcCgi,
    const char *pStrTgtCgi, cgi_type *pTgtCgi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pFuncName);
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pSrcCgi);

    // MRO
    if (mFamily == STAT_MRO_PER_NBR)
    {
        VALID_E_POINT_CHECK_VOID(pTgtCgi);
        switch (mType)
        {
            case TooLateHoRlfBeforeA2Mr:
            case TooLateHoRlfBeforeTriggering:
            case TooLateHoRlfAfterTriggering:
            case TooEarlyHoRlfAfterHo:
            case TooEarlyHoHof:
            case HoToWrongCellRlfAfterHoTarget:
            case HoToWrongCellHofTarget:
            case HoToWrongCellRlfAfterHoOther:
            case HoToWrongCellHofOther:
            case HoToWrongCellRlfAfterHoTargetToOther:
                MACRO_STAT_PMCC(STAT_MRO_PER_NBR, MroProblem, ptCi, pSrcCgi->ci, pTgtCgi->ci, 0, 0, 0);
                break;

            default:
                break;
        }

        MACRO_STAT_PMCC(STAT_MRO_PER_NBR, mType, ptCi, pSrcCgi->ci, pTgtCgi->ci, 0, 0, 0);
    }
    else if (mFamily == STAT_MRO_PER_CELL)
    {
        if (pTgtCgi != NULL)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[MRO-STAT] In case of STAT_MRO_PER_CELL, pTgtCgi have to be NULL.\n");
            return;
        }
        switch (mType)
        {
            case CoverageHole:
                MACRO_STAT_PMCC(STAT_MRO_PER_CELL, CoverageHole, ptCi, pSrcCgi->ci, 0, 0, 0, 0);
                break;
            default:
                break;
        }
    }
    else if (mFamily == STAT_MRO_PER_EUTRA_NBR)
    {
        VALID_E_POINT_CHECK_VOID(pTgtCgi);
        switch (mType)
        {
            case TooLateHo_EUTRA:
            case PingPongHo_EUTRA:
            case UnnecessaryHo_EUTRA:
                MACRO_STAT_PMCC(STAT_MRO_PER_EUTRA_NBR, MroProblem, ptCi, pSrcCgi->ci, pTgtCgi->ci, 0, 0, 0);
                break;

            default:
                break;
        }

        MACRO_STAT_PMCC(STAT_MRO_PER_EUTRA_NBR, mType, ptCi, pSrcCgi->ci, pTgtCgi->ci, 0, 0, 0);
    }
    else if (mFamily == STAT_COVERAGE_PROBLEM_DU_ID)
    {
        // 24A FGS-SF0509 FR190
        if (pTgtCgi != NULL)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[MRO-STAT] In case of STAT_COVERAGE_PROBLEM_DU_ID, pTgtCgi have to be NULL.\n");
            return;
        }

        switch (mType)
        {
            case DlCovProblem:
            case UlCovProblem:
            case OtherFailure:
                MACRO_STAT_PMCC(STAT_COVERAGE_PROBLEM_DU_ID, mType, ptCi, pSrcCgi->ci, 0, 0, 0, 0);
                break;
            
            default:
                break;
        }
    }
    else
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[MRO-STAT] Wrong Family ID(%x) for MRO STAT\n", mFamily);
        return;
    }

    FnVCCB_libStatUpmRlf_ForMRO(ptCi, mType, pSrcCgi, pTgtCgi);

    if (pTgtCgi != NULL)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MRO-STAT] %s %s (%s: %X/%llu, %s: %X/%llu) in [%llu:%s].\n", pStrFamily,
            pStrMtype, pStrSrcCgi, pSrcCgi->plmn.longId, 1LL * pSrcCgi->ci, pStrTgtCgi, pTgtCgi->plmn.longId,
            1LL * pTgtCgi->ci, 1LL * lineNumber, pFuncName);
    }
    else
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MRO-STAT] %s %s (%s: %X/%llu, %s) in [%llu:%s].\n", pStrFamily, pStrMtype,
            pStrSrcCgi, pSrcCgi->plmn.longId, 1LL * pSrcCgi->ci, pStrTgtCgi, 1LL * lineNumber, pFuncName);
    }
}

/****************************************************************************
   4. MRO-related message processing
****************************************************************************/

// 4.0 MRO Main function
// {{{
int16_t FnVCCB_procMRO(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    int8_t status = GOOD;

    if (!IS_MRO_ENABLED(MRO_TYPE_ANY, ptCi))
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] Intra and Inter MRO both are OFF\n");
        return status;
    }

    // no need to unpack rrc msg -> already unpacked in VCCB_GetMsgUnpack_checkMsgId
    if (&THREAD_INFO->nonUeAsn1.tempCallInfo != ptCi)  // no need to unpack msg in case of NonUeAsn1 thread : already unpacked.
    {
        // Unpack XN msg
        if (ptAll->msgHdr.msgType == msgTransferMessage_VnmbVccb_id)
        {
            msgTransferMessage_type *ptMsg = NULL;
            ptMsg = (msgTransferMessage_type *)ptAll;
            if (ptMsg->interface == interface_xn)
            {
                status = (int8_t)fnXNAP_UnpackMsg(ptUnpack, (char *)ptMsg->data, (int)ptMsg->length);
                if (ASN_OK != status)
                {
                    VCCB_PRINT_ERROR("XNAP Decoding Impossible(%d) \n", status);
                    return ERROR;
                }
            }
            else  // interface_ng
            {
                status = (int8_t)fnNGAP_UnpackMsg(ptUnpack, (char *)ptMsg->data, (int)ptMsg->length);
                if (ASN_OK != status)
                {
                    VCCB_PRINT_ERROR("NGAP Decoding Impossible(%d) \n", status);
                    return ERROR;
                }
            }
        }
    }

    if ((ptUnpack->msgId == NRRRC_RrcReestablishmentComplete_id) || (ptUnpack->msgId == NRRRC_RrcSetupComplete_id) ||
        (ptUnpack->msgId == XN_FailureIndication_id) || (ptUnpack->msgId == XN_HandoverReport_id) ||
        (ptUnpack->msgId == NG_DownlinkRANConfigurationTransferAmfAll_id))
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] Rcv new MSG. ptCi->mroInfo.ue.msgId(0x%X->0x%X)\n", 
            ptCi->mroInfo.ue.msgId, ptUnpack->msgId);
        ptCi->mroInfo.ue.msgId = ptUnpack->msgId;        
    }
    switch (ptUnpack->msgId)
    {
        case NRRRC_RrcSetupComplete_id:  // fallback case
        case NRRRC_RrcReestablishmentComplete_id:
            FnVCCB_procMRO_MSG5(ptCi);
            break;

        case NRRRC_UEInformationResponseR16_id:
            VCCB_CLEAR_TIMER(&ptCi->mroInfo.waitUeInfoResp, CANCEL_TIMER);            
            FnVCCB_procMRO_NRRRC_RrcUEInformationResponse(ptCi, ptUnpack);
            status = STATEALL_BREAK;
            break;

        case timNRRRC_UEInformationResponse_id:
            VLIB_InitMroInfo(ptCi);
            VLIB_InitRlfReportInfo(ptCi);
            break;

        case XN_FailureIndication_id:
            // Stored in Call All state (FnVCCB_ALL_XnapFailureIndication)

            FnVCCB_procMRO_FailureIndication(ptCi);
            VLIB_InitMroInfo(ptCi);
            VLIB_InitRlfReportInfo(ptCi);
            status = STATEALL_BREAK;
            break;

        case XN_HandoverReport_id:
            // stored in MainMainTask

            /*Check ImmediateHandover, FGS-SF0509 and FGS-SF0510 handle only ImmediateHandover*/
            if (ptCi->mroInfo.ho_report.cause == CauseXnapRadioNetworkLayerHandoverDesirableForRadioReasons)
            {
                // [IRAT MRO Fig 11] Handover Report Type == Inter-system Ping-pong
                if (ptCi->mroInfo.ho_report.handoverReportType == XNAP_intersystempingpong)
                    FnVCCB_procMRO_InterSystem_HoReport_InterSystemPingpong(ptCi, interface_xn);
                else
                    FnVCCB_procMRO_HoReport(ptCi, interface_xn);
            }
            else
            {
                VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (XN HO Rpt) HO cause is NOT Radio Reason(%d)\n",
                    ptCi->mroInfo.ho_report.cause);
            }

            VLIB_InitMroInfo(ptCi);
            VLIB_InitRlfReportInfo(ptCi);
            status = STATEALL_BREAK;
            break;

        case NG_DownlinkRANConfigurationTransferAmfAll_id:
            if (&THREAD_INFO->nonUeAsn1.tempCallInfo != ptCi)  // no need to store msg in case of NonUeAsn1 thread : already stored.
            {
                status = (int8_t)VNIL_StoreNGAP_DownlinkRanConfigurationTransfer(ptCi, ptAll, ptUnpack);
                if (ERROR == status)
                {
                    VCCB_PRINT_ERROR("VNIL_StoreNGAP_DownlinkRanConfigurationTransfer ERROR(%d)(%d) \n",
                        ptCi->mroInfo.ue.msgId, status);
                    return ERROR;
                }
            }

            if (ptCi->mroInfo.sonInfo.isInterSystem != TRUE)
            {
                switch (ptCi->mroInfo.sonInfo.choice)  // AC-1182
                {
                    case NGAP_SONInformationReport_failureIndicationInformation_chosen:
                        FnVCCB_procMRO_FailureIndication(ptCi);
                        break;

                    case NGAP_SONInformationReport_hOReportInformation_chosen:
                        /*Check ImmediateHandover, FGS-SF0509 and FGS-SF0510 handle only ImmediateHandover*/
                        if (ptCi->mroInfo.sonInfo.hoRpt.handoverCause != CauseNgapRadioNetworkLayerHandoverDesirableForRadioReasons)
                        {
                            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NG HO Rpt) HO cause is NOT Radio Reason(%d)\n",
                                ptCi->mroInfo.ho_report.cause);
                            break;
                        }

                        // [IRAT MRO Fig 11] Handover Report Type == Inter-system Ping-pong
                        if (ptCi->mroInfo.sonInfo.hoRpt.handoverReportType == HoRptType_InterSysPingPong)
                            FnVCCB_procMRO_InterSystem_HoReport_InterSystemPingpong(ptCi, interface_ng);
                        else
                            FnVCCB_procMRO_HoReport(ptCi, interface_ng);
                        break;
                    default:
                        VCCB_PRINT_CALL_ERROR(
                            ptCi, "Invalid sonInfo.choice(%d) in %s!!!\n", ptCi->mroInfo.sonInfo.choice, __func__);
                        break;
                }
            }
            else  // inter-system NG Handover Report
            {
                FnVCCB_procMRO_InterSystem_HoReport_UnnecessaryHoDetect(ptCi);
            }
            
            VLIB_InitMroInfo(ptCi);
            VLIB_InitRlfReportInfo(ptCi);
            break;

        default:
            // Not Related with MRO message.
            break;
    }

    return status;
}
// }}}

int16_t FnVCCB_PrepareXNAP_FailureIndication_w_RlfReport(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    cgi_type lastServingCellCgi;
    FnVCCB_Convert_to_cgi_type(&lastServingCellCgi, NULL, &ptCi->rlfReportInfo.LastServingCellId);

    uint16_t xnIdx = FnVCCB_GetXnIdxFromCgi(ptCi, &lastServingCellCgi);
    if (xnIdx < MAX_XN_NBR_PER_GNB)
    {
        VCCB_PRINT_CALL_MRO(ptCi,
            "[MRO] (UE-based) Send Failure Ind (xnIdx:%d/ lastServingCell:%X-%lu/ failreType:%d)\n", xnIdx,
            lastServingCellCgi.plmn.longId, lastServingCellCgi.ci, ptCi->mroInfo.rlf_report.connectionFailureType);
        return FnVCCB_SendXNMessage(XN_FailureIndication_id, ptCi, &xnIdx, nullptr);
    }
    else
    {
        // Check trackingAreaCode-r16 of last serving cell
        if (ptCi->rlfReportInfo.LastServingCellId.tacFlag == OPT_PRESENT)
        {
            ptCi->mroInfo.ableToSendNgSonConfigTransfer.isAble = TRUE;
            ptCi->mroInfo.ableToSendNgSonConfigTransfer.tAC = ptCi->rlfReportInfo.LastServingCellId.tac;
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (SndFailureInd) lastServingCell has trackingAreaCode-r16 (%d)\n",
                ptCi->rlfReportInfo.LastServingCellId.tac);
            return BREAK;  // next step : send NG Failure Indication
        }
    }

    // Send Failure Indication to one or more gNBs
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    int16_t status = GOOD;

    nbrCellInfo_type *ptCellNbrs;
    nbrGnbCellInfo_type *ptNbrGnbCell;
    CGI_Info_Logging_type lastServingCellCGI = ptCi->rlfReportInfo.LastServingCellId;

    ptCellNbrs = pCell->Nbr;
    for (uint16_t nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)
    {
        if (N_EQUIP == ptCellNbrs[nbrIdx].status) continue;

        if (VCCB_IS_INTRA_GNB_NEIGHBOR(ptCi->servCellNum, nbrIdx)) continue;

        status = (int16_t)getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &ptNbrGnbCell);
        if (status != GOOD) continue;
        if (N_EQUIP == ptNbrGnbCell->status) continue;

        if (!VCOM_CheckPlmnIdentical(&ptNbrGnbCell->globalGnbId.plmn, &lastServingCellCGI.plmn) ||
            (VLIB_GnbIdCellId2NrCellId(&ptNbrGnbCell->globalGnbId.gnbId, ptNbrGnbCell->cellId) !=
                lastServingCellCGI.ci))
        {
            continue;
        }

        // if xn connection disable, check TAC and send NG Failure Ind
        if (TRUE == ptNbrGnbCell->fiveGsTacStatus)
        {
            ptCi->mroInfo.ableToSendNgSonConfigTransfer.isAble = TRUE;
            ptCi->mroInfo.ableToSendNgSonConfigTransfer.tAC = ptNbrGnbCell->fiveGsTac;

            VCCB_PRINT_CALL_MRO(ptCi,
                "[MRO] (SndFailureInd) NBR found with lastServingCell (cN:%d/ nbrIdx:%d/ 5GsTac:%d)\n",
                ptCi->servCellNum, nbrIdx, ptNbrGnbCell->fiveGsTac);

            return BREAK;  // next step : send NG Failure Indication
        }
        else
        {
            VCCB_PRINT_CALL_MRO(ptCi,
                "[MRO] (SndFailureInd) NBR found with lastServingCell but has no TAC(cN:%d/ nbrIdx:%d)\n",
                ptCi->servCellNum, nbrIdx);

            return GOOD;
        }
    }

    VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (SndFailureInd) No NBR found with lastServingCell(%X-%lu) conFailureType(%d)!!\n",
        ptCi->rlfReportInfo.LastServingCellId.plmn.longId, ptCi->rlfReportInfo.LastServingCellId.ci,
        ptCi->mroInfo.rlf_report.connectionFailureType);

    return GOOD;
}

int16_t FnVCCB_PrepareXNAP_FailureIndication_wo_RlfReport(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // 26B FGS-SF0509:FR10 Use xnIdx required by XN Retrieve UE Context procedure by RRE procedure
    if (ptCi->mroInfo.ue.msgId != NRRRC_RrcReestablishmentComplete_id)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "[MRO] msg5 ID is wrong(%d). Stop sending XN Failure Indication\n", ptCi->mroInfo.ue.msgId);
        return ERROR;
    }

    // ref: ptCi->endPointInfo.xnIdx is configured by VCCM_RRE_XnUeRtrv_XN_RetrieveUEContextResponse
    if (ptCi->endPointInfo.xnIdx < MAX_XN_NBR_PER_GNB)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-based) Send Failure Ind using Retrieve UE Context result (xnIdx:%d)\n",
            ptCi->endPointInfo.xnIdx);
        return FnVCCB_SendXNMessage(XN_FailureIndication_id, ptCi, &ptCi->endPointInfo.xnIdx, nullptr);
    }

    // abnormal case
    VCCB_PRINT_CALL_ERROR(ptCi, "[MRO] (NW-based) XN end-point is not valid(%d)\n", ptCi->endPointInfo.xnIdx);
    return ERROR;
}

int16_t FnVCCB_PrepareXNAP_FailureIndication(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // Send Failure Indication to one gNB
    if (ptCi->rlfReportInfo.received == OPT_PRESENT)
    {
        return FnVCCB_PrepareXNAP_FailureIndication_w_RlfReport(ptCi);
    }
    else
    {
        return FnVCCB_PrepareXNAP_FailureIndication_wo_RlfReport(ptCi);
    }
}

// 4.1 Upon Receiving MSG5
// {{{
void FnVCCB_procMRO_MSG5_noRlfInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!IS_MRO_ENABLED(MRO_RAT_NR, ptCi)) return;

    // [ALGO] msg5 == RRCReestablishmentComplete
    if (ptCi->mroInfo.ue.msgId != NRRRC_RrcReestablishmentComplete_id)
    {
        // end
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-based) msg5(%X) is not NRRRC_RrcReestablishmentComplete_id(%X)\n",
            ptCi->mroInfo.ue.msgId, NRRRC_RrcReestablishmentComplete_id);
        return;
    }

    // [ALGO] ReestablishmentCause != reconfigurationfailure
    if (ptCi->mroInfo.msg5.rreCause == NRRRC_reconfigurationFailure)
    {
        // end
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-based) rreCause(%X) is NRRRC_reconfigurationFailure\n",
            ptCi->mroInfo.msg5.rreCause);
        return;
    }

    // [ALGO] The cell matching with ReestabUE-Identity belongs to this gNB?
    if ((ptCi->ueInfo.reestablishInfo.reestablishType != RRE_TYPE_INTER_GNB) &&
        (ptCi->ueInfo.reestablishInfo.reestablishType != RRE_TYPE_INTER_GNB_RRC_SETUP))
    {
        // Intra gNB RRE
        // NW-based HOP classification upon receiving MSG5
        FnVCCB_NWBasedMRO(ptCi);
    }
    else
    {
        // Inter gnb RRE
        // Failure Indication wo RLF-report
        int16_t status = FnVCCB_PrepareXNAP_FailureIndication(ptCi);
        if (GOOD != status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendXNMessage(XN_FailureIndication_id) returns (%d)!\n", status);
            return;
        }
    }
    return;
}

void FnVCCB_procMRO_NRRRC_RrcUEInformationResponse(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptUnpack);

    if (ptCi->mroInfo.waitRrcUeInfoResp != TRUE)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] NRRRC_RrcUEInformationResponse msg is not expected!\n");
        return;
    }
    else if (ptCi->mroInfo.ue.msgId != NRRRC_RrcSetupComplete_id &&
             ptCi->mroInfo.ue.msgId != NRRRC_RrcReestablishmentComplete_id)
    {
        ptCi->mroInfo.waitRrcUeInfoResp = FALSE;
        VCCB_PRINT_CALL_MRO(
            ptCi, "[MRO] NRRRC_RrcUEInformationResponse msg is not expected! msgId(%d)\n", ptCi->mroInfo.ue.msgId);
        return;
    }
    else  // retrieve of RLF-report which is requested by MRO
    {
        ptCi->mroInfo.waitRrcUeInfoResp = FALSE;
    }

    if (ptCi->rlfReportInfo.received != OPT_PRESENT)
    {
        // Init rlf report
        VLIB_InitRlfReportInfo(ptCi);
        
        if (VRIL_StoreNRRRC_UEInformationResponse(ptCi, ptUnpack) != GOOD)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VRIL_StoreNRRRC_UEInformationResponse ERROR!\n");
            VLIB_InitMroInfo(ptCi);            
            VLIB_InitRlfReportInfo(ptCi);                 
            return;
        }
    }

    if (ptCi->rlfReportInfo.received == OPT_PRESENT)
    {
        if (GOOD == FnVCCB_PreProcess_UebasedMRO_byMSG5(ptCi))
        {
            FnVCCB_UeBasedMRO_RLFReport(ptCi);            
        }
        else
        {
            // MRO is not avilable OR finished
        }
    }
    else
    {
        FnVCCB_procMRO_MSG5_noRlfInfo(ptCi);
    }

    VLIB_InitMroInfo(ptCi);
    VLIB_InitRlfReportInfo(ptCi);            
    return;
}

void FnVCCB_procMRO_MSG5(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    VLIB_InitRlfReportInfo(ptCi); // either UE-based or NW-based, init acqired RLF Report before start

    // [ALGO] rlf-InfoAvailable == true
    if (ptCi->mroInfo.msg5.m.rlfInfoAvailable == TRUE || // MSG5 == RRC Setup Complete
        ptCi->mroInfo.waitRrcUeInfoResp == TRUE)         // MSG5 == RRC Reestablishment Complete
    {
        // Do nothing. watiting UE Information Response
    }
    else
    {
        FnVCCB_procMRO_MSG5_noRlfInfo(ptCi);
        VLIB_InitMroInfo(ptCi);
    }
}
// }}}

// 4.2 Upon recieving Failure Indication (NG/XN) (fig 5.)
// {{{
void FnVCCB_procMRO_FailureIndication(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    // [ALGO] RLF-report included?
    if (ptCi->rlfReportInfo.received == OPT_PRESENT /*true*/)
    {
        if (GOOD == FnVCCB_PreProcess_UebasedMRO_byFailureInd(ptCi))
        {            
            FnVCCB_UeBasedMRO_RLFReport(ptCi);
        }
    }
    else
    {
        if (ptCi->mroInfo.sonInfo.choice == NGAP_SONInformationReport_failureIndicationInformation_chosen)
        {  // NG Failure Indication
            // For IRAT MRO, RLF Report is always transmitted. No NW Based MRO.
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] Discard Failure Ind w/o RLF-Report-r16\n");
            return;
        }
        else  // XN Failure Indication
        {
            /* NW-based MRO works for Intra-NR MRO only
               If the latest ho type is IRAT HO, Failure Indication w/o RLF-Report-r16 should be discarded*/
            if (ptCi->mroInfo.ue.hoInitiated == HO_TYPE_SA_INTER_SYSTEM_INTER_RAT_HANDOVER)
            {
                VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-based) discard. latest HO type is IRAT HO\n");
                return;
            }

            if (ptCi->mroInfo.failure_ind.m.rreConnRestabIndicator == OPT_PRESENT)
            {
                // SVR24A FR22
                switch (ptCi->mroInfo.failure_ind.rre.rrcConnReestabIndicator)
                {
                    case XNAP_handoverFailure:
                        FnVCCB_NWBasedMRO_handoverFailure(ptCi);
                        break;
                    case XNAP_otherFailure:
                        FnVCCB_NWBasedMRO_otherFailure(ptCi);
                        break;
                    default:
                        VCCB_PRINT_CALL_MRO(ptCi, 
                            "[MRO] (NW-based) discard. RRE cause other(%d) than handoverFailure(1) or otherFailure(2) \n",
                            ptCi->mroInfo.failure_ind.rre.rrcConnReestabIndicator);
                        break;
                }
            }
            else
            {
                // UE context is already founded.
                FnVCCB_NWBasedMRO_FailureIndication(ptCi);
            }
        }
    }
}
// }}}

// 4.3 Upon Receiving Ho Report
// {{{
void FnVCCB_procMRO_HoReport(callInfo_type *ptCi, uint8_t interface)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    /* HO Report can be sent by IRAT MRO for Inter-system ping-pong or Unnecessary HO detection
        - Inter-system ping-pong is handled by FnVCCB_procMRO_InterSystem_HoReport_InterSystemPingpong()
        - Unnecessary HO detection is handled by FnVCCB_procMRO_InterSystem_HoReport_UnnecessaryHoDetect()
       At this point, only possible case is Intra-NR MRO */
    if (!IS_MRO_ENABLED(MRO_RAT_NR, ptCi)) return;

    // [ALGO] RLF-report included?
    if (ptCi->rlfReportInfo.received == OPT_PRESENT /*true*/)
    {
        /* [24A HLD 2.2.1.3] SS doesn't send HO report for Coverage Hole(= ReestablishmentCellId not exist) */
        if (ptCi->mroInfo.rlf_report.m.reestablishmentCellId == OPT_PRESENT)
        {
            // UE-based HOP classification
            if (FnVCCB_UeBasedMRO_HOP(ptCi) == GOOD)
                return;
        }
    }
    else
    {
        // NW-based HOP classification upon receiving handover report
        if (interface == interface_xn)
            FnVCCB_NWBasedMRO_XN_HoReport(ptCi);
    }
}
// }}}

/****************************************************************************
   5. UE-based MRO
****************************************************************************/
// {{{
// 5.1 RLF Report Preprocessing
// {{{
//[1-2]
void FnVCCB_UeBasedMRO_RLFReport(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    if (ptCi->rlfReportInfo.choice == EUTRA_RlfReport)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[CHK] no algorithm case. There is no rLFReport\n");
        return;
    }

    /* 
        Available actions using nr-RLF-Report-r16 : 
        - 1.Intra-NR MRO HOP / 2.Intra-NR MRO Coverage Hole / 3.IRAT MRO / 4.CPD(Coverage Problem Detection)

        Limitation : 
        - 1 & 2 cannot happen at the same time
        - 1 & 3 cannot happen at the same time
        - 2 & 3 can    happen at the same time
        - 4 happens all the time
    */

    /* Intra-NR MRO */
    if (ptCi->mroInfo.rlf_report.m.reestablishmentCellId == OPT_PRESENT)  // reestablishmentCellId Exists
    {
        // UE-based HOP classification
        if (FnVCCB_UeBasedMRO_HOP(ptCi) == GOOD)
        {
            // no action
        }
        else
        {
            /* IRAT MRO */
            FnVCCB_IratMro_HOP(ptCi);
        }
    }
    else
    {
        // UE-Based Coverage Hole classification
        FnVCCB_UeBasedMRO_CoverageHole(ptCi);

        /* IRAT MRO */
        FnVCCB_IratMro_HOP(ptCi);
    }   

    /* [24A FR100, FR190, FR191] */
    fnVCCB_UeBasedMRO_CovergeProblemDetection(ptCi);

    return;
}
// }}}

// 5.2 HOP Classification Upon Receiving Failure Indication or MSG5
// {{{
void FnVCCB_UeBasedMRO_HOP_Msg5OrFailureIndication_rlf_tooLate(callInfo_type *ptCi, CGI_Info_Logging_type *recoveryCell)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(recoveryCell);

    if (ptCi->mroInfo.rlf_report.c.isNrFailedPCellId_r16 != TRUE ||
        ptCi->mroInfo.rlf_report.c.isNrFailedCellGlobalId != TRUE)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (UE-tooLate) no vliad nrFailedPCellId (rat:%d/choice:%d)\n"
            , ptCi->mroInfo.rlf_report.c.isNrFailedPCellId_r16, ptCi->mroInfo.rlf_report.c.isNrFailedCellGlobalId);
        return;
    }

    // cgi_type *nrPreviousCell = &ptCi->mroInfo.rlf_report.nrPreviousCellId; //not used
    CGI_Info_Logging_type *nrFailedPCellId = &ptCi->mroInfo.rlf_report.nrFailedPCellId;

    cgi_type nrFailedCellCgi, recoveryCellCgi;
    FnVCCB_Convert_to_cgi_type(&nrFailedCellCgi, NULL, nrFailedPCellId);
    FnVCCB_Convert_to_cgi_type(&recoveryCellCgi, NULL, recoveryCell);

    // [ALGO] recovery cell != nrFailedPCellId
    if (VCOM_CheckCgiLoggingTypeIdentical(recoveryCell, nrFailedPCellId))
    {
        VCCB_PRINT_CALL_MRO(
            ptCi, "[MRO] (UE-tooLate) recoveryCell(%lu) != nrFailedPCellId(%lu)\n", recoveryCell->ci, nrFailedPCellId->ci);
        return;
    }

    // [ALGO] An outgoing HO in progress exists?
    if (isOutGoingHo(ptCi))
    {
        // tooLateHoRlfAfterTriggering(nrFailedPCellId, recovery cell)
        MACRO_MRO_STAT(STAT_MRO_PER_NBR, TooLateHoRlfAfterTriggering, ptCi, &nrFailedCellCgi, &recoveryCellCgi);

        ptCi->cslInfo.cslRreInfo.rlfCause = csl_Too_Late_Ho_Rlf_After_Triggering;

        return;
    }

    // [ALGO] recovery cell is Inter-freq. neighbor?
    uint16_t cellNum = MAX_CELL_NUM_VCCB;
    nbrGnbCellInfo_type *ptGnbNbr = NULL;

    if (GOOD != VCCM_GetCellNumFromNrCgi(ptCi->gnbNum, &nrFailedCellCgi, &cellNum, false))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "cannot get cell num from CGI(%lu)\n", nrFailedCellCgi.ci);
        return;
    }
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    ptGnbNbr = getNbrGnbCellByCgiInCellNbr(cellNum, recoveryCellCgi);
    if (NULL == ptGnbNbr || N_EQUIP == ptGnbNbr->status)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (UE-tooLate) no neighbor case for recovery cell(%lu), ptGnbNbr(%p)\n",
            recoveryCellCgi.ci, ptGnbNbr);
        return;
    }

    if (ptGnbNbr->ssbArfcn != CELLINFO[cellNum].ssbArfcn) /*check inter freq */
    {
        // [ALGO] A2 for inter-freq. measurement received?
        if (ptCi->mroInfo.ue.isA2Installed != TRUE /* no: A2 isn't installed */)
        {
            // tooLateHoRlfBeforeA2Mr(nrFailedPCellId, recovery cell)
            MACRO_MRO_STAT(STAT_MRO_PER_NBR, TooLateHoRlfBeforeA2Mr, ptCi, &nrFailedCellCgi, &recoveryCellCgi);

            ptCi->cslInfo.cslRreInfo.rlfCause = csl_Too_Late_Ho_Rlf_Before_A2_Mr;
            return;
        }
    }

    // tooLateHoRlfBeforeTriggering(nrFailedPCellId, recovery cell)
    MACRO_MRO_STAT(STAT_MRO_PER_NBR, TooLateHoRlfBeforeTriggering, ptCi, &nrFailedCellCgi, &recoveryCellCgi);

    ptCi->cslInfo.cslRreInfo.rlfCause = csl_Too_Late_Ho_Rlf_Before_Triggering;

    return;
}

void FnVCCB_UeBasedMRO_HOP_Msg5OrFailureIndication_rlf_tooEarly(
    callInfo_type *ptCi, CGI_Info_Logging_type *recoveryCell)  // now
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(recoveryCell);

    // [ALGO] nrPreviousCell exist?
    if (ptCi->mroInfo.rlf_report.m.previousPCellId != OPT_PRESENT ||
        ptCi->mroInfo.rlf_report.c.isNrPreviousPCellId != TRUE)
    {
        // discard
        VCCB_PRINT_CALL_MRO(
            ptCi, "[MRO] (inStoreUeCntxt) no valid nrPreviousPCell (presence:%d/rat:%d)\n",
            ptCi->mroInfo.rlf_report.m.previousPCellId, ptCi->mroInfo.rlf_report.c.isNrPreviousPCellId);
        return;
    }

    CGI_Info_Logging_type *nrPreviousCellId = &ptCi->mroInfo.rlf_report.nrPreviousCellId;
    CGI_Info_Logging_type *nrFailedPCellId = &ptCi->mroInfo.rlf_report.nrFailedPCellId;

    cgi_type nrPreviousCellCgi, nrFailedPCellCgi, recoveryCellCgi;
    FnVCCB_Convert_to_cgi_type(&nrPreviousCellCgi, NULL, nrPreviousCellId);
    FnVCCB_Convert_to_cgi_type(&nrFailedPCellCgi, NULL, nrFailedPCellId);
    FnVCCB_Convert_to_cgi_type(&recoveryCellCgi, NULL, recoveryCell);

    // [ALGO] recovery cell == nrPreviousCell
    if (VCOM_CheckCgiLoggingTypeIdentical(recoveryCell,
            nrPreviousCellId))  // recoveryCell == ptCi->mroInfo.rlf_report.m.nrPreviousCell)
    {
        // [ALGO] nrPreviousCell belongs to thie gNB
        if (VLIB_isCellBelongsToGnb(&nrPreviousCellId->plmn, &nrPreviousCellId->ci,
                ptCi->gnbNum))  // nrPreviousCell belongs to this gNB
        {
            // tooEarlyHoRlfAfterHo(nrPreviousCell, nrFailedPCellId)
            MACRO_MRO_STAT(STAT_MRO_PER_NBR, TooEarlyHoRlfAfterHo, ptCi, &nrPreviousCellCgi, &nrFailedPCellCgi);
        }
        else
        {
            // send HO report to nrPreviousCell - Too early HO
            if (GOOD != FnVCCB_SendHandoverReport(ptCi, XNAP_hoTooEarly))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendHandoverReport ERROR!\n");
                return;
            }
        }

        ptCi->cslInfo.cslRreInfo.rlfCause = csl_Too_Early_Ho_Rlf;
    }
    else
    {
        // [ALGO] recovery cell == nrFailedPCellId
        if (ptCi->mroInfo.rlf_report.c.isNrFailedPCellId_r16 != TRUE ||
            ptCi->mroInfo.rlf_report.c.isNrFailedCellGlobalId != TRUE)
        {
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (inStoreUeCntxt) no valid nrFailedPCellId (rat:%d/isCGI:%d\n",
                ptCi->mroInfo.rlf_report.c.isNrFailedPCellId_r16, 
                ptCi->mroInfo.rlf_report.c.isNrFailedCellGlobalId);
            return;
        }
        else if (VCOM_CheckCgiLoggingTypeIdentical(recoveryCell, nrFailedPCellId))
        {
            // discard
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (inStoreUeCntxt) recoveryCell(%llx) == nrFailedPCellId(%llx)\n",
                1ULL * recoveryCell->ci, 1ULL * nrFailedPCellId->ci);
            return;
        }

        // [ALGO] nrPreviousCell belongs to thie gNB
        if (VLIB_isCellBelongsToGnb(&nrPreviousCellId->plmn, &nrPreviousCellId->ci,
                ptCi->gnbNum))  // nrPreviousCell belongs to this gNB
        {
            // hoToWrongCellRlfAfterHoTarget(nrPreviousCell, nrFailedPCellId)
            MACRO_MRO_STAT(
                STAT_MRO_PER_NBR, HoToWrongCellRlfAfterHoTarget, ptCi, &nrPreviousCellCgi, &nrFailedPCellCgi);

            // hoToWrongCellRlfAfterHoOther(nrPreviousCell, recoveryCell)
            MACRO_MRO_STAT(STAT_MRO_PER_NBR, HoToWrongCellRlfAfterHoOther, ptCi, &nrPreviousCellCgi, &recoveryCellCgi);

            // hoToWrongCellRlfAfterHoTargetToOther(nrFailedPCellId, recoveryCell)
            MACRO_MRO_STAT(
                STAT_MRO_PER_NBR, HoToWrongCellRlfAfterHoTargetToOther, ptCi, &nrFailedPCellCgi, &recoveryCellCgi);
        }
        else
        {
            // send HO report to nrPreviousCell - HO to wrong cell RLF
            if (GOOD != FnVCCB_SendHandoverReport(ptCi, XNAP_hoToWrongCell))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendHandoverReport ERROR!\n");
                return;
            }

            // hoToWrongCellRlfAfterHoTargetToOther(nrFailedPCellId, recoveryCell)
            MACRO_MRO_STAT(
                STAT_MRO_PER_NBR, HoToWrongCellRlfAfterHoTargetToOther, ptCi, &nrFailedPCellCgi, &recoveryCellCgi);
        }

        ptCi->cslInfo.cslRreInfo.rlfCause = csl_Ho_To_Wrong_Cell_Rlf;
    }
}

void FnVCCB_UeBasedMRO_HOP_Msg5OrFailureIndication_rlf(callInfo_type *ptCi, CGI_Info_Logging_type *recoveryCell)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(recoveryCell);

    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (ptCi->mroInfo.rlf_report.c.isNrFailedPCellId_r16 != TRUE ||
        ptCi->mroInfo.rlf_report.c.isNrFailedCellGlobalId != TRUE)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (UE-Msg5FailureInd) no valid failedPCellId (rat:%d/isCGI:%d)\n",
            ptCi->mroInfo.rlf_report.c.isNrFailedPCellId_r16, 
            ptCi->mroInfo.rlf_report.c.isNrFailedCellGlobalId);
        return;
    }

    /* [ALGO v.51 Fig 13 updated] No send Failure Indication
    int16_t status = GOOD;

    CGI_Info_Logging_type *nrFailedPCellId = &ptCi->mroInfo.rlf_report.nrFailedPCellId;
    
    if (!VLIB_isCellBelongsToGnb(&nrFailedPCellId->plmn, &nrFailedPCellId->ci, ptCi->gnbNum))
    {
        status = FnVCCB_SendXNMessage(XN_FailureIndication_id, ptCi);
        if (status != GOOD)
        {
            VCCB_RETURN_ON_CALL_VOID(ptCi, status, "FnVCCB_SendXNMessage(XN_FailureIndication_id) ERROR!\n");
        }
        return;
    }*/
    
    // Is too early?
    if ((ptCi->mroInfo.rlf_report.m.timeConnFailure == OPT_PRESENT) &&
        (ptCi->mroInfo.rlf_report.timeConnFailure <= pGnb->mroInfo.tStoreUeCtxt))  // YANG DB
    {
        FnVCCB_UeBasedMRO_HOP_Msg5OrFailureIndication_rlf_tooEarly(ptCi, recoveryCell);
    }
    else  // too late
    {
        FnVCCB_UeBasedMRO_HOP_Msg5OrFailureIndication_rlf_tooLate(ptCi, recoveryCell);
    }
}

void FnVCCB_UeBasedMRO_HOP_Msg5OrFailureIndication_hof(callInfo_type *ptCi, CGI_Info_Logging_type *recoveryCell)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(recoveryCell);

    uint16_t previousCellNum = MAX_CELL_NUM_VCCB;

    CGI_Info_Logging_type *nrPreviousCellId = &ptCi->mroInfo.rlf_report.nrPreviousCellId;
    CGI_Info_Logging_type *nrFailedPCellId = &ptCi->mroInfo.rlf_report.nrFailedPCellId;  // not used

    cgi_type nrPreviousCellCgi, nrFailedPCellCgi, recoveryCellCgi;
    FnVCCB_Convert_to_cgi_type(&nrPreviousCellCgi, NULL, nrPreviousCellId);    
    FnVCCB_Convert_to_cgi_type(&recoveryCellCgi, NULL, recoveryCell);    

    if (ptCi->mroInfo.rlf_report.m.previousPCellId != OPT_PRESENT ||
        ptCi->mroInfo.rlf_report.c.isNrPreviousPCellId != TRUE)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (UE-hof) no valid nrPreviousPcellId (presence:%d/rat:%d)\n",
            ptCi->mroInfo.rlf_report.m.previousPCellId, ptCi->mroInfo.rlf_report.c.isNrPreviousPCellId);
        return;
    }

    if (ptCi->mroInfo.rlf_report.c.isNrFailedPCellId_r16 != TRUE)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (UE-hof) no valid nrFailedPCellId (choice is eutra)\n");
        return;
    }
    
    // At this point, it's certain that previousCellNum belongs to this gNB
    //if (!VLIB_isCellBelongsToGnb(&nrPreviousCellId->plmn, &nrPreviousCellId->ci, ptCi->gnbNum))
    if (GOOD != VCCM_GetCellNumFromNrCgi(ptCi->gnbNum, &nrPreviousCellCgi, &previousCellNum, false))
    {
        // discard
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (UE-hof) Can't get cellNum from nrPreviousCell(%llx). gnbNum(%x)\n",
            1ULL * nrPreviousCellId->ci, ptCi->gnbNum);
        return;
    }
    VCCB_CHECK_VALID_CELLNUM_VOID(previousCellNum);   
    
    if (ptCi->mroInfo.rlf_report.c.isNrFailedCellGlobalId == TRUE)
    {
        FnVCCB_Convert_to_cgi_type(&nrFailedPCellCgi, NULL, nrFailedPCellId);
    }
    else
    {
        // [ALGO 5.2] Even nrFailedPCellId choice is pci-arfcn-r16, 
        // if connectionFailureType == hof, MRO can collect stat. for the unique NCR matching with nrFailedPCellId

        if ( GOOD != FnVCCB_GetCGIWithPciArfcn(
                previousCellNum, ptCi->mroInfo.rlf_report.nrFailedPci, ptCi->mroInfo.rlf_report.nrFailedFreq, &nrFailedPCellCgi))
        {
            VCCB_PRINT_CALL_MRO(ptCi, 
                "[MRO] (UE-hof) No nbr found. (previousCellNum:%d/ nrFailedPCI:%d/ nfFreqCarrier:%d)\n",
                previousCellNum, ptCi->mroInfo.rlf_report.nrFailedPci, ptCi->mroInfo.rlf_report.nrFailedFreq);
            return;
        }
    }


    if (VCOM_CheckCgiLoggingTypeIdentical(recoveryCell, nrPreviousCellId))
    {
        // tooEarlyHoHof(nrPreviousCell, nrFailedPCellId)
        MACRO_MRO_STAT(STAT_MRO_PER_NBR, TooEarlyHoHof, ptCi, &nrPreviousCellCgi, &nrFailedPCellCgi);

        ptCi->cslInfo.cslRreInfo.rlfCause = csl_Too_Early_Ho_Hof;
    }
    else if (!VCOM_CheckCgiLoggingTypeIdentical(recoveryCell, nrFailedPCellId))
    {
        // hoToWrongCellHofTarget(nrPreviousCell, nrFailedPCellId)
        MACRO_MRO_STAT(STAT_MRO_PER_NBR, HoToWrongCellHofTarget, ptCi, &nrPreviousCellCgi, &nrFailedPCellCgi);

        // hoToWrongCellHofOther(nrPreviousCell, recoveryCell)
        MACRO_MRO_STAT(STAT_MRO_PER_NBR, HoToWrongCellHofOther, ptCi, &nrPreviousCellCgi, &recoveryCellCgi);

        ptCi->cslInfo.cslRreInfo.rlfCause = csl_Ho_To_Wrong_Cell_Hof;
    }
    else
    {
        VCCB_PRINT_CALL_MRO(ptCi, 
            "[MRO] (UE-hof) recoveryCell(%lu) == nrFailedPcell(%lu) != nrPreviousCell(%lu)\n",
            recoveryCell->ci, nrFailedPCellId->ci, nrPreviousCellId->ci)
    }

    return;
}

/**
 * @brief UE-based HOP classification upon receiving failure Indication or MSG5
 **/
//[2-2]
void FnVCCB_UeBasedMRO_HOP_Msg5OrFailureIndication(callInfo_type *ptCi, CGI_Info_Logging_type *recoveryCell)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(recoveryCell);

    if (ptCi->rlfReportInfo.choice == EUTRA_RlfReport)
    {
        // no rLFReport
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] No HOP for eutra-RLF-Report-r16\n");
        return;
    }

    /*Check ImmediateHandover, FGS-SF0509 and FGS-SF0510 handle only ImmediateHandover*/
    if (!CHECK_MRO_HO_TRIGGER_IMMEDIATE)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (UE-Msg5OrFailureInd) Discard. MRO is allowed for IMHO UE only(%d)\n",
            ptCi->mroInfo.hoTriggerType);
        return;
    }

    if (ptCi->mroInfo.rlf_report.connectionFailureType == NRRRC_connectionFailureType_r16_rlf)
    {
        FnVCCB_UeBasedMRO_HOP_Msg5OrFailureIndication_rlf(ptCi, recoveryCell);
    }
    else /* HOF */
    {
        FnVCCB_UeBasedMRO_HOP_Msg5OrFailureIndication_hof(ptCi, recoveryCell);
    }
}
// }}}

/**
 * @brief 5.3 UE-based HOP Classification Upon Receiving Handover Report
 **/
//[2-3]
void FnVCCB_UeBasedMRO_HOP_HandoverReport(callInfo_type *ptCi, CGI_Info_Logging_type *recoveryCell, uint8_t interface)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(recoveryCell);

    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    // RLF report ...
    if (ptCi->rlfReportInfo.choice == EUTRA_RlfReport)
    {
        // discard
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (UE-HoRpt) Dicard eutra-RLF-Report-r16\n");
        return;
    }

    // [ALGO] connectionFailureType
    if (ptCi->mroInfo.rlf_report.connectionFailureType == NRRRC_hof /*hof*/)
    {
        // discard
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MRO] (UE-HoRpt) connectionFailureType hof is not supported\n");
        return;
    }

    if (ERROR == FnVCCB_UeBasedMRO_HOP_HandoverReport_CheckCellCgi(ptCi, interface))
    {
        return;
    }
    
    CGI_Info_Logging_type *nrPreviousCellId = &ptCi->mroInfo.rlf_report.nrPreviousCellId;
    CGI_Info_Logging_type *nrFailedPCellId = &ptCi->mroInfo.rlf_report.nrFailedPCellId;

    cgi_type nrPreviousCellCgi, nrFailedPCellCgi, recoveryCellCgi;
    FnVCCB_Convert_to_cgi_type(&nrPreviousCellCgi, NULL, nrPreviousCellId);
    FnVCCB_Convert_to_cgi_type(&nrFailedPCellCgi, NULL, nrFailedPCellId);
    FnVCCB_Convert_to_cgi_type(&recoveryCellCgi, NULL, recoveryCell);

    // [ALGO] nrPreviousCell belongs to this gNB
    if ((ptCi->mroInfo.rlf_report.m.previousPCellId != OPT_PRESENT) ||
        (ptCi->mroInfo.rlf_report.c.isNrPreviousPCellId != TRUE))
    {
        VCCB_PRINT_CALL_MRO(ptCi,
            "[MRO] (UE-HoRpt) Discard. no valid previousPCellId(presence:%d/ rat:%d)\n",
            ptCi->mroInfo.rlf_report.m.previousPCellId, ptCi->mroInfo.rlf_report.c.isNrPreviousPCellId);
        return;
    }
    if (!VLIB_isCellBelongsToGnb(&nrPreviousCellId->plmn, &nrPreviousCellId->ci, ptCi->gnbNum))
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (UE-HoRpt) nrPreviousCell(ci:%lu) and current gNB(gnbNum:%d) is different gNB\n",
            nrPreviousCellId->ci, ptCi->gnbNum);
        return;
    }

    // [ALGO] timeConnFailure <= t-store-ue-cntxt
    if ((ptCi->mroInfo.rlf_report.m.timeConnFailure != OPT_PRESENT) ||
        (ptCi->mroInfo.rlf_report.timeConnFailure > pGnb->mroInfo.tStoreUeCtxt))
    {
        // discard
        if (ptCi->mroInfo.rlf_report.m.timeConnFailure != OPT_PRESENT)
        {
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (UE-HoRpt) Discard. no timeConnFailure\n");
        }
        else
        {
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (UE-HoRpt) Discard. timeConnFailure(%d) > tStoreUeCtxt(%d)\n",
                ptCi->mroInfo.rlf_report.timeConnFailure, pGnb->mroInfo.tStoreUeCtxt);
        }
        return;
    }

    if (ptCi->mroInfo.rlf_report.c.isNrFailedPCellId_r16 != TRUE ||
        ptCi->mroInfo.rlf_report.c.isNrFailedCellGlobalId != TRUE)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (UE-HoRpt) no valid nrFailedPCellId (rat:%d/choice:%d)\n",
            ptCi->mroInfo.rlf_report.c.isNrFailedPCellId_r16, ptCi->mroInfo.rlf_report.c.isNrFailedCellGlobalId);
        return;
    }

    // [ALGO] recovery cell == nrPreviousPCell
    if (VCOM_CheckCgiLoggingTypeIdentical(recoveryCell, nrPreviousCellId))
    {
        // tooEarlyHoRlfAfterHo(nrPreviousCell, nrFailedPCellId)
        MACRO_MRO_STAT(STAT_MRO_PER_NBR, TooEarlyHoRlfAfterHo, ptCi, &nrPreviousCellCgi, &nrFailedPCellCgi);
    }
    else if (!VCOM_CheckCgiLoggingTypeIdentical(recoveryCell, nrFailedPCellId))
    {
        // hoToWrongCellRlfAfterHoTarget(nrPreviousCell, nrFailedPCellId)
        MACRO_MRO_STAT(STAT_MRO_PER_NBR, HoToWrongCellRlfAfterHoTarget, ptCi, &nrPreviousCellCgi, &nrFailedPCellCgi);

        // hoToWrongCellRlfAfterHoOther(nrPreviousCell, recovery Cell)
        MACRO_MRO_STAT(STAT_MRO_PER_NBR, HoToWrongCellRlfAfterHoOther, ptCi, &nrPreviousCellCgi, &recoveryCellCgi);
    }
    else
    {
        // discard
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (UE-HoRpt) recovery cell(%lu) = nrFailedPCell(%lu) != nrPreviousCell(%lu)\n",
            recoveryCell->ci, nrFailedPCellId->ci, nrPreviousCellId->ci);
        return;
    }
}
// }}}

// 5.2 + 5.3 HOP Classification
// {{{
int16_t FnVCCB_UeBasedMRO_HOP(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (!IS_MRO_ENABLED(MRO_RAT_NR, ptCi)) return ERROR;

    CGI_Info_Logging_type *recoveryCell;

    // [ALGO Fig 12] previousPCellId == (absent or nrPreviousPcell)
    if (ptCi->mroInfo.rlf_report.m.previousPCellId == OPT_PRESENT &&
        ptCi->mroInfo.rlf_report.c.isNrPreviousPCellId == FALSE)
    {
        return ERROR; //next: IRAT MRO
    }

    recoveryCell = &ptCi->mroInfo.rlf_report.reestablishmentCellId;
    
    VCCB_PRINT_CALL_COMMENT(ptCi, "[MRO] (HOP) recovery cell is %X-%lu\n", recoveryCell->plmn.longId, recoveryCell->ci);

    /* [ALGO Fig 12] trigger == HO report
        In case of Failure Indication, VCCB already found UE context
        ptCi is not temp call. So, no need to check 'UE Context exist'*/
    
    switch (ptCi->mroInfo.ue.msgId)
    {
        case XN_FailureIndication_id:
        case NRRRC_RrcReestablishmentComplete_id:
            FnVCCB_UeBasedMRO_HOP_Msg5OrFailureIndication(ptCi, recoveryCell);
            break;
        
        case NRRRC_RrcSetupComplete_id: 
            // [ALGO 4.1] NW/UE based HOP classification can only be triggered by RRCReestablishmetComplete
            break;
        
        case XN_HandoverReport_id:
            FnVCCB_UeBasedMRO_HOP_HandoverReport(ptCi, recoveryCell, interface_xn);
            break;

        case NG_DownlinkRANConfigurationTransferAmfAll_id:
            if (ptCi->mroInfo.sonInfo.isInterSystem == TRUE)
                break;

            if (ptCi->mroInfo.sonInfo.choice == NGAP_SONInformationReport_failureIndicationInformation_chosen)
                FnVCCB_UeBasedMRO_HOP_Msg5OrFailureIndication(ptCi, recoveryCell);
            else if (ptCi->mroInfo.sonInfo.choice == NGAP_SONInformationReport_hOReportInformation_chosen)
                FnVCCB_UeBasedMRO_HOP_HandoverReport(ptCi, recoveryCell, interface_ng);
            break;

        default:
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] no UE based HOP for msgId(%x)\n", ptCi->mroInfo.ue.msgId);
            break;
    }

    return GOOD;
}
// }}}

// 5.4 Coverage Hole Classification
// {{{
void FnVCCB_UeBasedMRO_CoverageHole(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    CGI_Info_Logging_type *nrPreviousCellId = NULL, *nrFailedPCellId = NULL;

    cgi_type nrPreviousCellCgi, nrFailedPCellCgi;    

    uint16_t previousCellNum = MAX_CELL_NUM_VCCB;

    if (!IS_MRO_ENABLED(MRO_RAT_NR, ptCi)) return;

    if (ptCi->mroInfo.rlf_report.c.isNrFailedPCellId_r16 != TRUE)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (CovH) Discard. failedPCellId is EUTRA\n");
        return;
    }

    if (ptCi->mroInfo.rlf_report.c.isNrFailedCellGlobalId == TRUE)
    {
        nrFailedPCellId = &ptCi->mroInfo.rlf_report.nrFailedPCellId;
        VCCB_PRINT_LOG_MRO_CGI("nrFailedPCellId", nrFailedPCellId->ci);        
        FnVCCB_Convert_to_cgi_type(&nrFailedPCellCgi, NULL, nrFailedPCellId);
    }
    else
    {
        VCCB_PRINT_LOG_MRO_PCI_ARFCN("nrFailedPCellId", ptCi->mroInfo.rlf_report.nrFailedPci, ptCi->mroInfo.rlf_report.nrFailedFreq);
    }
    
    if (ptCi->mroInfo.rlf_report.m.previousPCellId == OPT_PRESENT &&
        ptCi->mroInfo.rlf_report.c.isNrPreviousPCellId == TRUE)
    {
        nrPreviousCellId = &ptCi->mroInfo.rlf_report.nrPreviousCellId;
        VCCB_PRINT_LOG_MRO_CGI("nrPreviousCellId", nrPreviousCellId->ci);            
        FnVCCB_Convert_to_cgi_type(&nrPreviousCellCgi, NULL, nrPreviousCellId);
    }
    
    cgi_type *from = NULL;
    cgi_type *to = NULL;    

    // [ALGO] connectionFailureType
    if (ptCi->mroInfo.rlf_report.connectionFailureType == NRRRC_connectionFailureType_r16_rlf /*rlf*/)
    {
        // nrFailedPCellId choice must be cellGlobalId for RLF
        if (ptCi->mroInfo.rlf_report.c.isNrFailedCellGlobalId != TRUE)
        {
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (CovH) Discard. nrFailedPCellId choice is pci-arfcn-r16\n");
            return;
        }
        if (!VLIB_isCellBelongsToGnb(&nrFailedPCellId->plmn, &nrFailedPCellId->ci, ptCi->gnbNum))
        {
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (CovH) Discard. nrFailedPCellId no belongs to this gNB\n");
            return;            
        }

        from = &nrFailedPCellCgi;        
        
        // [ALGO] timeConnFailure <= t-store-ue-cntxt
        if ((ptCi->mroInfo.rlf_report.m.timeConnFailure != OPT_PRESENT) ||
            (ptCi->mroInfo.rlf_report.timeConnFailure > pGnb->mroInfo.tStoreUeCtxt))
        {
            MACRO_MRO_STAT(STAT_MRO_PER_CELL, CoverageHole, ptCi, from, NULL);

            VCCB_PRINT_CALL_MRO(ptCi, "[MRO STAT] CoverageHole(failedCell:%lu) within t-store-ue-cntxt\n", from->ci);
            return;
        }

        // [ALGO] nrPreviousCell exists?
        if ((ptCi->mroInfo.rlf_report.m.previousPCellId != OPT_PRESENT) ||
            (ptCi->mroInfo.rlf_report.c.isNrPreviousPCellId != TRUE))
        {
            MACRO_MRO_STAT(STAT_MRO_PER_CELL, CoverageHole, ptCi, from, NULL);
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO STAT] CoverageHole(failedCell:%lu) without nrPreviousPCell\n", from->ci);
            return;
        }

        to = &nrPreviousCellCgi;

        MACRO_MRO_STAT(STAT_MRO_PER_NBR, CoverageHoleNbr, ptCi, from, to);
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO STAT] CoverageHole(failedCell:%lu/previous:%lu)\n", from->ci, to->ci);
        return;
    }
    else  // connectionFailureType == hof
    {
        if ((ptCi->mroInfo.rlf_report.m.previousPCellId != OPT_PRESENT) ||
            (ptCi->mroInfo.rlf_report.c.isNrPreviousPCellId != TRUE))
        {
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (CovH) Discard. nrPreviousPCellId(presence:%d/rat:%d)\n",
                ptCi->mroInfo.rlf_report.m.previousPCellId, ptCi->mroInfo.rlf_report.c.isNrPreviousPCellId);
            return;
        }
        // Check that nrPreviousCell belongs to this gNB and get cellNum
        else if (GOOD != VCCM_GetCellNumFromNrCgi(ptCi->gnbNum, &nrPreviousCellCgi, &previousCellNum, false))
        {
                // discard
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (CovH) nrPreviousCell(%llx) and current gnb(%x) is different gNB\n",
                1ULL * nrPreviousCellCgi.ci, ptCi->gnbNum);
            return;
        }
        VCCB_CHECK_VALID_CELLNUM_VOID(previousCellNum);

        from = &nrPreviousCellCgi;

        // Fill nrFailedPCellCgi if nrFailedPCellId choice is pci-arfcn-r16
        if (ptCi->mroInfo.rlf_report.c.isNrFailedCellGlobalId == TRUE)
        {
            to = &nrFailedPCellCgi;
        }
        else
        {
            memset(&nrFailedPCellCgi, 0x00, sizeof(nrFailedPCellCgi));

            // [ALGO 5.2] nrFailedPCellId is a unique NCR of nrPreviousCell ?       
            if ( GOOD == FnVCCB_GetCGIWithPciArfcn(
                previousCellNum, ptCi->mroInfo.rlf_report.nrFailedPci, 
                ptCi->mroInfo.rlf_report.nrFailedFreq, &nrFailedPCellCgi))
            {
                to = &nrFailedPCellCgi;
            }
            else
            {
                VCCB_PRINT_CALL_MRO(ptCi, 
                    "[MRO] (CovH) No NBR found. (previousCellNum:%d/ nrFailredPci:%d/ nrFailedFreq(%d))\n",
                    previousCellNum, ptCi->mroInfo.rlf_report.nrFailedPci, ptCi->mroInfo.rlf_report.nrFailedFreq)
            }            
        }        

        if (to != NULL)
        {            
            MACRO_MRO_STAT(STAT_MRO_PER_NBR, CoverageHoleNbr, ptCi, from, to);
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO STAT] CoverageHoleNbr(previous:%lu/failed:%lu)\n", from->ci, to->ci);
            return;
        }
        else
        {
            MACRO_MRO_STAT(STAT_MRO_PER_CELL, CoverageHole, ptCi, from, NULL);
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO STAT] CoverageHole(previous:%lu)\n", from->ci);
            return;
        }
    }
}
// }}}

/****************************************************************************
   6. NW-based MRO
****************************************************************************/
// {{{
void FnVCCB_NWBasedMRO(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    switch (ptCi->mroInfo.ue.msgId)
    {
        case NRRRC_RrcReestablishmentComplete_id:
            FnVCCB_NWBasedMRO_MSG5(ptCi);
            break;

        default:
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] not supported message. msgId(%02x)\n", ptCi->mroInfo.ue.msgId);
            break;
    }
}

// 6.1 HOP Classification Upon Receiving MSG5
// {{{
// [3-3]
void FnVCCB_NWBasedMRO_MSG5(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    /* NW-based MRO works for Intra-NR MRO only
       If the latest ho type is IRAT HO, Failure Indication w/o RLF-Report-r16 should be discarded*/
    if (ptCi->mroInfo.ue.hoInitiated == HO_TYPE_SA_INTER_SYSTEM_INTER_RAT_HANDOVER)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-based) discard. latest HO type is IRAT HO\n");
        return;
    }

    // [ALGO] ReestablishmentCause
    switch (ptCi->mroInfo.msg5.rreCause)
    {
        case NRRRC_handoverFailure:
            FnVCCB_NWBasedMRO_handoverFailure(ptCi);
            break;
        case NRRRC_otherFailure:
            FnVCCB_NWBasedMRO_otherFailure(ptCi);
            break;
        default:
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] not supported rreCause(%d)\n", ptCi->mroInfo.msg5.rreCause);
            break;
    }
}

//[3-3]
void FnVCCB_NWBasedMRO_handoverFailure(callInfo_type *ptCi)
{
    // When this function is exectued, MSG5 is always have to be RRE Complete.(RRE case only)
    // Intra gNB RRE case only

    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    cgi_type *sourceCellCGI = &ptCi->mroInfo.ue.sourceCellCGI; // source cell of HO, Intra gNB RRE Case
    cgi_type *targetCellCGI = &ptCi->mroInfo.ue.targetCellCGI; // target cell of HO, Intra gNB RRE Case
    cgi_type *reestabCellCGI = NULL; // target cell of RRE

    if (ptCi->mroInfo.ue.msgId == NRRRC_RrcReestablishmentComplete_id) 
    {
        // Trigger event = MSG5
        reestabCellCGI = &ptCi->mroInfo.msg5.targetCellCGI;
    }
    else 
    {
        // Trigger event = Failure Ind (SVR24A FR22)
        reestabCellCGI = &ptCi->mroInfo.failure_ind.rre.rreCellCGI; 
    }

    VCCB_PRINT_LOG_MRO_CGI("sourceCellCGI", sourceCellCGI->ci);
    VCCB_PRINT_LOG_MRO_CGI("targetCellCGI", targetCellCGI->ci);
    VCCB_PRINT_LOG_MRO_CGI("reestabCellCGI", reestabCellCGI->ci);

    /*Check ImmediateHandover, FGS-SF0509 and FGS-SF0510 handle only ImmediateHandover*/
    if (!CHECK_MRO_HO_TRIGGER_IMMEDIATE)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-MSG-HOF) Discard. MRO is allowed for IMHO UE only(%d)\n",
            ptCi->mroInfo.hoTriggerType);
        return;
    }

    // [ALGO] An outgoing HO in progress exists?
    if (isOutGoingHo(ptCi))
    {
        // [ALGO] reestab. cell == source
        if (FnVCCB_CheckCgiIdentical(reestabCellCGI, sourceCellCGI))
        {
            // tooEarlyHoHof(source, target)
            MACRO_MRO_STAT(STAT_MRO_PER_NBR, TooEarlyHoHof, ptCi, sourceCellCGI, targetCellCGI);

            ptCi->cslInfo.cslRreInfo.rlfCause = csl_Too_Early_Ho_Hof;
        }
        // [ALGO] reestab. cell == target
        else if (!FnVCCB_CheckCgiIdentical(reestabCellCGI, targetCellCGI))
        {
            // HoToWrongCellHofTarget(source, target)
            MACRO_MRO_STAT(STAT_MRO_PER_NBR, HoToWrongCellHofTarget, ptCi, sourceCellCGI, targetCellCGI);

            // HoToWrongCellHofOther(source, reestab. cell)
            MACRO_MRO_STAT(STAT_MRO_PER_NBR, HoToWrongCellHofOther, ptCi, sourceCellCGI, reestabCellCGI);

            ptCi->cslInfo.cslRreInfo.rlfCause = csl_Ho_To_Wrong_Cell_Hof;
        }
        else
        {
            // discard
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-MSG5-HOF) reestabCell(%lu) == targetCell(%lu) != sourceCell(%lu)\n",
                reestabCellCGI->ci, targetCellCGI->ci, sourceCellCGI->ci);
        }
    }
    else
    {
        // discard
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-MSG5-HOF) Discard. no outgoing HO\n");
    }
}

int16_t FnVCCB_PrepareXNAP_HandoverReport(callInfo_type *ptCi, uint8_t hoReportType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint16_t xnIdx = MAX_XN_NBR_PER_GNB;
    cgi_type nbrCellCGI, *ptNbrCellCGI;

    int16_t status = GOOD;    
    
    if (hoReportType == XNAP_intersystempingpong ) //Inter-system PP detected during HO procedure
    {
        ptNbrCellCGI = &ptCi->mroInfo.ue.sourceCellCGI;
    }
    else
    {
        if (ptCi->rlfReportInfo.received == OPT_PRESENT) // UE based MRO
        {
            if (ptCi->mroInfo.rlf_report.m.previousPCellId != OPT_PRESENT ||
                ptCi->mroInfo.rlf_report.c.isNrPreviousPCellId != TRUE)
            {
                // defense code
                return ERROR;
            }

            ptNbrCellCGI = &nbrCellCGI;
            FnVCCB_Convert_to_cgi_type(ptNbrCellCGI, NULL, &ptCi->mroInfo.rlf_report.nrPreviousCellId);
        }
        else  // NW based MRO
        {
            ptNbrCellCGI = &ptCi->mroInfo.ue.sourceCellCGI;
        }
    }
    

    xnIdx = FnVCCB_GetXnIdxFromCgi(ptCi, ptNbrCellCGI);
    if (xnIdx < MAX_XN_NBR_PER_GNB)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] Send HO Report (xnIdx:%d/ hoRptType:%d/ srcCell:%X-%lu)\n",
                        xnIdx, hoReportType, ptNbrCellCGI->plmn.longId, ptNbrCellCGI->ci);
        return FnVCCB_SendXNMessage(XN_HandoverReport_id, ptCi, &hoReportType, &xnIdx);
    }
    else
    {
        // Check trackingAreaCode-r16 of last serving cell
        if (hoReportType != XNAP_intersystempingpong)
        {
            if (ptCi->rlfReportInfo.received == OPT_PRESENT) //UE-based MRO
            {
                if (ptCi->mroInfo.rlf_report.nrPreviousCellId.tacFlag == OPT_PRESENT)
                {
                    ptCi->mroInfo.ableToSendNgSonConfigTransfer.isAble = TRUE;
                    ptCi->mroInfo.ableToSendNgSonConfigTransfer.tAC = ptCi->mroInfo.rlf_report.nrPreviousCellId.tac;
                    ptCi->mroInfo.ableToSendNgSonConfigTransfer.hoReportType = (uint8_t)(hoReportType&0x03);

                    VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (SndHoRpt) previousPCell has trackingAreaCode-r16 (%d)\n", 
                        ptCi->mroInfo.rlf_report.nrPreviousCellId.tac);
                    return BREAK;  // next step : send NG HO report
                }
                // else, search NCRT to get TAC
            }
            else // NW-based MRO
            {
                VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (SndHoRpt) (NW-based) no XN connection for sourceCell(plmn:%X/ci:%lu)\n", 
                    ptCi->mroInfo.ue.sourceCellCGI.plmn.longId, ptCi->mroInfo.ue.sourceCellCGI.ci);
                return GOOD;
            }
        }
        // else, search NCRT to get TAC
    }

    /* Search NCRT to get TAC to send NG Handover Report */
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);    
    
    nbrCellInfo_type *ptCellNbrs;
    nbrGnbCellInfo_type *ptNbrGnbCell;    

    uint16_t nbrIdx = 0;
    
    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];    
    ptCellNbrs = pCell->Nbr;

    for (nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)
    {
        if (N_EQUIP == ptCellNbrs[nbrIdx].status) continue;

        if (VCCB_IS_INTRA_GNB_NEIGHBOR(ptCi->servCellNum, nbrIdx)) continue;

        status = (int16_t)getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &ptNbrGnbCell);
        if (status != GOOD) continue;
        if (N_EQUIP == ptNbrGnbCell->status) continue;

        if (!VCOM_CheckPlmnIdentical(&ptNbrGnbCell->globalGnbId.plmn, &ptNbrCellCGI->plmn) ||
            (VLIB_GnbIdCellId2NrCellId(&ptNbrGnbCell->globalGnbId.gnbId, ptNbrGnbCell->cellId) != ptNbrCellCGI->ci))
        {
            continue;
        }

        if (TRUE == ptNbrGnbCell->fiveGsTacStatus)
        {
            ptCi->mroInfo.ableToSendNgSonConfigTransfer.isAble = TRUE;
            ptCi->mroInfo.ableToSendNgSonConfigTransfer.tAC = ptNbrGnbCell->fiveGsTac;
            ptCi->mroInfo.ableToSendNgSonConfigTransfer.hoReportType = (uint8_t)(hoReportType&0x03);

            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (SndHoRpt) NBR found with sourcellCell (cN:%d/ nbrIdx:%d/ 5GsTac:%d)\n",
                    ptCi->servCellNum, nbrIdx, ptNbrGnbCell->fiveGsTac);

            return BREAK;  // next step : send NG HO report
        }
        else
        {
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (SndHoRpt) NBR found with sourcellCell but has no TAC(cN:%d/ nbrIdx:%d)\n", 
                ptCi->servCellNum, nbrIdx);

            return GOOD;
        }
    }

    VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (SndHoRpt) No NBR found with CGI(plmn:0x%X/ci:%lu):", 
        ptNbrCellCGI->plmn.longId, ptNbrCellCGI->ci);
    return GOOD;
}

//[3-3]
void FnVCCB_NWBasedMRO_otherFailure(callInfo_type *ptCi)
{
    // When this function is exectued, MSG5 is always have to be RRE Complete.(RRE case only)
    // Intra gNB RRE case only

    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    const VccbDbgInfo_type *const pDbg = DBG;

    cgi_type *sourceCellCGI = &ptCi->mroInfo.ue.sourceCellCGI;  // source cell of HO, Intra gNB RRE Case
    cgi_type *targetCellCGI = &ptCi->mroInfo.ue.targetCellCGI;  // target cell of HO, Intra gNB RRE Case
    cgi_type *lastServingCell = NULL;
    cgi_type *reestabCellCGI = NULL;
    cgi_type servedCellCGI;

    if (ptCi->mroInfo.ue.msgId == NRRRC_RrcReestablishmentComplete_id) 
    {
        // Trigger event = MSG5
        lastServingCell = &ptCi->mroInfo.msg5.sourceCellCGI;
        reestabCellCGI = &ptCi->mroInfo.msg5.targetCellCGI;
    }
    else 
    {
        // Trigger event = Failure Ind (SVR24A FR22)
        servedCellCGI = FnVCCB_GetNrcgiFromCellNum(ptCi->servCellNum);
        lastServingCell = &servedCellCGI;
        reestabCellCGI = &ptCi->mroInfo.failure_ind.rre.rreCellCGI;
    }

    VCCB_PRINT_LOG_MRO_CGI("sourceCellCGI",   sourceCellCGI->ci);
    VCCB_PRINT_LOG_MRO_CGI("targetCellCGI",   targetCellCGI->ci);
    VCCB_PRINT_LOG_MRO_CGI("lastServingCell", lastServingCell->ci);
    VCCB_PRINT_LOG_MRO_CGI("reestabCellCGI",  reestabCellCGI->ci);

    /*Check ImmediateHandover, FGS-SF0509 and FGS-SF0510 handle only ImmediateHandover*/
    if (!CHECK_MRO_HO_TRIGGER_IMMEDIATE)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-otherF) Discard. MRO is allowed for IMHO UE only(%d)\n",
            ptCi->mroInfo.hoTriggerType);
        return;
    }

    long long tStoreUeCntxt = (long long)pGnb->mroInfo.tStoreUeCtxt * 100;  // unit : ms, tStoreUeCtxt unit is 100ms

    long long diffTime = 0;
    if ((ptCi->mroInfo.ue.timestamp.tv_sec != -1) && (ptCi->mroInfo.ue.timestamp.tv_nsec != -1))  // timer is started
    {
        diffTime = VLIB_getTickDifference(ptCi->mroInfo.ue.timestamp);  // unit : ms
    }
    if (pDbg->value.mroDiffTime >= 0)
    {
        diffTime = pDbg->value.mroDiffTime;
    }

    VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-otherF) mroDiffTime(%lld ms), tStoreUeCntxt(%llu ms)\n", 
        diffTime, tStoreUeCntxt);

    // [ALGO] Successful incoming HO within t-store-ue-cntxt?
    if ((diffTime <= tStoreUeCntxt) && (diffTime != 0))  // 'diffTime = 0' means it's NOT incoming HO
    {
        // [ALGO] last serving cell == target
        if (!FnVCCB_CheckCgiIdentical(lastServingCell, targetCellCGI))  // if last serving cell != target, discard
        {
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-otherF) last serving cell CGI(ci:%lu) and target cell CGI(ci:%lu) is diff\n",
                lastServingCell->ci, targetCellCGI->ci);
            return;
        }

        // [ALGO] reestab. cell == source
        if (FnVCCB_CheckCgiIdentical(reestabCellCGI, sourceCellCGI))
        {
            if (VLIB_isCellBelongsToGnb(&sourceCellCGI->plmn, &sourceCellCGI->ci,
                    ptCi->gnbNum))
            {
                // tooEarlyHoRlfAfterHo(source, target)
                MACRO_MRO_STAT(STAT_MRO_PER_NBR, TooEarlyHoRlfAfterHo, ptCi, sourceCellCGI, targetCellCGI);
            }
            else
            {
                // Send HO report to source cell - HO Too early
                int16_t status = FnVCCB_PrepareXNAP_HandoverReport(ptCi, XNAP_hoTooEarly);
                if (GOOD != status)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendXNMessage(XN_HandoverReport_id) returns (%d)!\n", status);
                    return;
                }
            }
            
            ptCi->cslInfo.cslRreInfo.rlfCause = csl_Too_Early_Ho_Rlf;
        }
        // [ALGO] reestab. cell == target
        else if (!FnVCCB_CheckCgiIdentical(reestabCellCGI, targetCellCGI))  // if reestab. cell == target, discard
        {
            // [ALGO] source cell belongs to thie gNB
            if (VLIB_isCellBelongsToGnb(&sourceCellCGI->plmn, &sourceCellCGI->ci,
                    ptCi->gnbNum))  // TODO: need to add the plmn...
            {
                // hoToWrongCellRlfAfterHoTarget(source, target)
                MACRO_MRO_STAT(STAT_MRO_PER_NBR, HoToWrongCellRlfAfterHoTarget, ptCi, sourceCellCGI, targetCellCGI);

                // hoToWrongCellRlfAfterHoOther(source, reestab. cell)
                MACRO_MRO_STAT(STAT_MRO_PER_NBR, HoToWrongCellRlfAfterHoOther, ptCi, sourceCellCGI, reestabCellCGI);

                // hoToWrongCellRlfAfterHoTargetToOther(target, reestab. cell)
                MACRO_MRO_STAT(
                    STAT_MRO_PER_NBR, HoToWrongCellRlfAfterHoTargetToOther, ptCi, targetCellCGI, reestabCellCGI);
            }
            else
            {
                // Send HO report to source cell - HO to wrong cell
                int16_t status = FnVCCB_PrepareXNAP_HandoverReport(ptCi, XNAP_hoToWrongCell);
                if (GOOD != status)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendXNMessage(XN_HandoverReport_id) returns (%d)!\n", status);
                    return;
                }

                // hoToWrongCellRlfAfterHoTarget(target, reestab. cell)
                MACRO_MRO_STAT(STAT_MRO_PER_NBR, HoToWrongCellRlfAfterHoTarget, ptCi, targetCellCGI, reestabCellCGI);
            }

            ptCi->cslInfo.cslRreInfo.rlfCause = csl_Ho_To_Wrong_Cell_Rlf;
        }
        else
        {
            VCCB_PRINT_CALL_MRO(ptCi,
                "[MRO] (NW-otherF) reestabCell(%lu) == targetCell(%lu) != sourceCell(%lu)\n", 
                reestabCellCGI->ci, targetCellCGI->ci, sourceCellCGI->ci);
        }
    }
    else
    {
        // [ALGO] An outgoing HO in progress exists?
        if (isOutGoingHo(ptCi))
        {
            // [ALGO] last serving cell == source
            if (!FnVCCB_CheckCgiIdentical(lastServingCell, sourceCellCGI))
            {
                VCCB_PRINT_CALL_MRO(ptCi,
                    "[MRO] (NW-otherF) last serving cell CGI(ci:%lu) and source cell CGI(ci:%lu) is diff\n", lastServingCell->ci,
                    sourceCellCGI->ci);
                return;
            }

            // [ALGO] reestab. cell != lastServingCell
            if (FnVCCB_CheckCgiIdentical(reestabCellCGI, lastServingCell))
            {
                VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-otherF) rre cell CGI(ci:%lu) and last serving cell CGI(ci:%lu) is same\n",
                    reestabCellCGI->ci, lastServingCell->ci);
                return;
            }

            // tooLateHoRlfAfterTriggering(source, reestab. cell)
            MACRO_MRO_STAT(STAT_MRO_PER_NBR, TooLateHoRlfAfterTriggering, ptCi, sourceCellCGI, reestabCellCGI);

            ptCi->cslInfo.cslRreInfo.rlfCause = csl_Too_Late_Ho_Rlf_After_Triggering;

        }
        else
        {
            // [ALGO] reestab. cell != last serving cell
            if (FnVCCB_CheckCgiIdentical(reestabCellCGI, lastServingCell))
            {
                VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-otherF) rre cell CGI(ci:%lu) and last serving cell CGI(ci:%lu) is same\n",
                    reestabCellCGI->ci, lastServingCell->ci);
                return;
            }

            // [ALGO] reestab. cell is inter-freq. neighbor?
            uint16_t cellNum = MAX_CELL_NUM_VCCB;
            nbrGnbCellInfo_type *ptGnbNbr = NULL;

            if (GOOD != VCCM_GetCellNumFromNrCgi(ptCi->gnbNum, lastServingCell, &cellNum, false))
            {
                VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-otherF) cannot get cell num from CGI(%lu)\n", lastServingCell->ci);
                return;
            }
            VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

            ptGnbNbr = getNbrGnbCellByCgiInCellNbr(cellNum, *reestabCellCGI);
            if (NULL == ptGnbNbr || N_EQUIP == ptGnbNbr->status)
            {
                VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-otherF) no neighbor case for rre cell(ci:%lu), ptGnbNbr(%p)\n",
                    reestabCellCGI->ci, ptGnbNbr);
                return;
            }

            if (ptGnbNbr->ssbArfcn != CELLINFO[cellNum].ssbArfcn /*check the freq */)
            {
                // [ALGO] A2 for inter-freq. measurement received?
                if (ptCi->mroInfo.ue.isA2Installed != TRUE /* no: A2 isn't installed */)
                {
                    // tooLateHoRlfBeforeA2Mr(serving, rre cell)
                    MACRO_MRO_STAT(STAT_MRO_PER_NBR, TooLateHoRlfBeforeA2Mr, ptCi, lastServingCell, reestabCellCGI);

                    ptCi->cslInfo.cslRreInfo.rlfCause = csl_Too_Late_Ho_Rlf_Before_A2_Mr;
                    return;
                }
            }

            // tooLateHoRlfBeforeTriggering(serving, rre cell)
            MACRO_MRO_STAT(STAT_MRO_PER_NBR, TooLateHoRlfBeforeTriggering, ptCi, lastServingCell, reestabCellCGI);

            ptCi->cslInfo.cslRreInfo.rlfCause = csl_Too_Late_Ho_Rlf_Before_Triggering;
        }
    }
}
// }}}

// 6.2 HOP Classification Upon Receiving Failure Indication
// {{{
//[3-1]
void FnVCCB_NWBasedMRO_FailureIndication(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!IS_MRO_ENABLED(MRO_RAT_NR, ptCi)) return;

    // When VCCB recieve failure indication, it means REUL was already updated.(rrcReconfigurationComplete recieved)
    // So VCCB can use 'mroInfo.reul' DB.

    cgi_type servedCellCGI = FnVCCB_GetNrcgiFromCellNum(ptCi->servCellNum);

    cgi_type *sourceCellCGI = &ptCi->mroInfo.ue.sourceCellCGI;
    cgi_type *targetCellCGI = &ptCi->mroInfo.ue.targetCellCGI;
    cgi_type *lastServingCell = &servedCellCGI;
    cgi_type *reestabCellCGI = &ptCi->mroInfo.failure_ind.rre.rreCellCGI;

    VCCB_PRINT_LOG_MRO_CGI("sourceCellCGI", sourceCellCGI->ci);
    VCCB_PRINT_LOG_MRO_CGI("targetCellCGI", targetCellCGI->ci);
    VCCB_PRINT_LOG_MRO_CGI("lastServingCell", lastServingCell->ci);
    VCCB_PRINT_LOG_MRO_CGI("reestabCellCGI", reestabCellCGI->ci);

    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    const VccbDbgInfo_type *const pDbg = DBG;

    /*Check ImmediateHandover, FGS-SF0509 and FGS-SF0510 handle only ImmediateHandover*/
    if (!CHECK_MRO_HO_TRIGGER_IMMEDIATE)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-FailInd) Discard. MRO is allowed for IMHO UE only(%d)\n",
            ptCi->mroInfo.hoTriggerType);
        return;
    }
    
    long long tStoreUeCntxt = (long long)pGnb->mroInfo.tStoreUeCtxt * 100;  // tStoreUeCntxt unit : ms, tStoreUeCtxt unit : 100ms
    long long diffTime = 0;
    if ((ptCi->mroInfo.ue.timestamp.tv_sec != -1) && (ptCi->mroInfo.ue.timestamp.tv_nsec != -1))  // timer is started
    {
        diffTime = VLIB_getTickDifference(ptCi->mroInfo.ue.timestamp);  // unit : ms
    }
    if (pDbg->value.mroDiffTime >= 0)
    {
        diffTime = pDbg->value.mroDiffTime;
    }
    
    VCCB_PRINT_CALL_MRO(
        ptCi, "[MRO] mroDiffTime(%lld ms), tStoreUeCntxt(%llu ms)\n", diffTime, tStoreUeCntxt);
    
    // [ALGO] Successful incoming HO within t-store-ue-cntxt?
    if ((diffTime <= tStoreUeCntxt) && (diffTime != 0))  // 'diffTime = 0' means it's NOT incoming HO
    {
        // [ALGO] last serving cell == target
        if (!FnVCCB_CheckCgiIdentical(lastServingCell, targetCellCGI))
        {
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-FailInd) Discard Failure Ind. last serving cell(plmn:%X/ci:%lu) != target cell(plmn:%X/ci:%lu)\n",
                lastServingCell->plmn.longId, lastServingCell->ci, targetCellCGI->plmn.longId, targetCellCGI->ci);
            return;
        }

        // [ALGO] reestab. cell == source
        if (FnVCCB_CheckCgiIdentical(reestabCellCGI, sourceCellCGI))
        {
            // [ALGO] source cell belongs to this gNB
            if (VLIB_isCellBelongsToGnb(&sourceCellCGI->plmn, &sourceCellCGI->ci,
                    ptCi->gnbNum))  // TODO: need to add the plmn...
            {
                // tooEarlyHoRlfAfterHo(source, target)
                MACRO_MRO_STAT(STAT_MRO_PER_NBR, TooEarlyHoRlfAfterHo, ptCi, sourceCellCGI, targetCellCGI);
            }
            else
            {
                // Send HO report to source cell - HO Too Early
                int16_t status = FnVCCB_PrepareXNAP_HandoverReport(ptCi, XNAP_hoTooEarly);
                if (GOOD != status)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "[MRO] (NW-FailInd) FnVCCB_SendXNMessage(XN_HandoverReport_id) returns (%d)!\n", status);
                }
            }

            ptCi->cslInfo.cslRreInfo.rlfCause = csl_Too_Early_Ho_Rlf;
        }
        else
        {
            // [ALGO] reestab. cell == target
            if (FnVCCB_CheckCgiIdentical(reestabCellCGI, targetCellCGI))
            {
                VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-FailInd) Discard Failure Ind. rre cell(plmn:%X/ci:%lu) == target cell(plmn:%X/ci:%lu)\n",
                    reestabCellCGI->plmn.longId, reestabCellCGI->ci, targetCellCGI->plmn.longId, targetCellCGI->ci);
                return;
            }

            // [ALGO] source cell belongs to this gNB
            if (VLIB_isCellBelongsToGnb(&sourceCellCGI->plmn, &sourceCellCGI->ci,
                    ptCi->gnbNum))  // TODO: need to add the plmn...
            {
                // hoToWrongCellRlfAfterHoTarget(source, target)
                MACRO_MRO_STAT(STAT_MRO_PER_NBR, HoToWrongCellRlfAfterHoTarget, ptCi, sourceCellCGI, targetCellCGI);

                // hoToWrongCellRlfAfterHoOther(source, reestab. cell)
                MACRO_MRO_STAT(STAT_MRO_PER_NBR, HoToWrongCellRlfAfterHoOther, ptCi, sourceCellCGI, reestabCellCGI);

                // hoToWrongCellRlfAfterHoTargetToOther(target, reestab. cell)
                MACRO_MRO_STAT(
                    STAT_MRO_PER_NBR, HoToWrongCellRlfAfterHoTargetToOther, ptCi, targetCellCGI, reestabCellCGI);
            }
            else
            {
                // Send HO report to source cell - HO to wrong cell
                int16_t status = FnVCCB_PrepareXNAP_HandoverReport(ptCi, XNAP_hoToWrongCell);
                if (GOOD != status)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendXNMessage(XN_HandoverReport_id) returns (%d)!\n", status);
                }

                // hoToWrongCellRlfAfterHoTargetToOther(target, reestab. cell)
                MACRO_MRO_STAT(
                    STAT_MRO_PER_NBR, HoToWrongCellRlfAfterHoTargetToOther, ptCi, targetCellCGI, reestabCellCGI);
            }
            
            ptCi->cslInfo.cslRreInfo.rlfCause = csl_Ho_To_Wrong_Cell_Rlf;
        }
    }
    else
    {
        // [ALGO] An outgoing HO in progress exists?
        if (isOutGoingHo(ptCi))
        {
            // [ALGO] last serving cell == source
            if (!FnVCCB_CheckCgiIdentical(lastServingCell, sourceCellCGI))
            {
                VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-FailInd) Discard Failure Ind. last serving cell(plmn:%X/ci:%lu) == source cell(plmn:%X/ci:%lu)\n",
                    lastServingCell->plmn.longId, lastServingCell->ci, sourceCellCGI->plmn.longId, sourceCellCGI->ci);
                return;
            }

            // [ALGO] reestab. cell == target
            if (FnVCCB_CheckCgiIdentical(reestabCellCGI, targetCellCGI))
            {
                // [ALGO] wrong classification if failure type is HOF
                if (0 /*TODO: need to add the condition*/)
                {
                    VCCB_PRINT_CALL_MRO(
                        ptCi, "[MRO] (NW-FailInd) failure type(%d) isn't HOF(%d)\n", 0 /*which DB??*/, 0 /*which value??*/);
                    return;
                }

                // tooLateHoRlfAfterTriggering(source, reestab. cell)
                MACRO_MRO_STAT(STAT_MRO_PER_NBR, TooLateHoRlfAfterTriggering, ptCi, sourceCellCGI, reestabCellCGI);

                ptCi->cslInfo.cslRreInfo.rlfCause = csl_Too_Late_Ho_Rlf_After_Triggering;
            }
            else
            {
                // [ALGO] HO command transmitted?
                if (ptCi->mroInfo.isHoCmdTransmitted == TRUE)
                {
                    // [ALGO] wrong classification if failure type is RLF (too late HO case..)
                    if (0 /*TODO: need to add the condition*/)  // MUST TODO
                    {
                        VCCB_PRINT_CALL_MRO(
                            ptCi, "[MRO] (NW-FailInd) failure type(%d) isn't HOF(%d)\n", 0 /*which DB??*/, 0 /*which value??*/);
                        return;
                    }

                    // hoToWrongCellHofTarget(source, target)
                    MACRO_MRO_STAT(STAT_MRO_PER_NBR, HoToWrongCellHofTarget, ptCi, sourceCellCGI, targetCellCGI);

                    // hoToWrongCellHofOther(source, reestab. cell)
                    MACRO_MRO_STAT(STAT_MRO_PER_NBR, HoToWrongCellHofOther, ptCi, sourceCellCGI, reestabCellCGI);

                    ptCi->cslInfo.cslRreInfo.rlfCause = csl_Ho_To_Wrong_Cell_Hof;
                }
                else
                {
                    // tooLateHoRlfAfterTriggering(source, reestab. cell)
                    MACRO_MRO_STAT(STAT_MRO_PER_NBR, TooLateHoRlfAfterTriggering, ptCi, sourceCellCGI, reestabCellCGI);

                    ptCi->cslInfo.cslRreInfo.rlfCause = csl_Too_Late_Ho_Rlf_After_Triggering;
                }
            }
        }
        else
        {
            // [ALGO] reestab. cell != last serving cell
            if (FnVCCB_CheckCgiIdentical(reestabCellCGI, lastServingCell))
            {
                VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-FailInd) rre cell(plmn:%x/ci:%lu) == last serving cell(plmn:%X/ci:%lu)\n",
                    reestabCellCGI->plmn.longId, reestabCellCGI->ci, lastServingCell->plmn.longId, lastServingCell->ci);
                return;
            }

            // [ALGO] reestab. cell is inter-freq. neighbor?
            nbrGnbCellInfo_type *ptGnbNbr = NULL;
            ptGnbNbr = getNbrGnbCellByCgiInCellNbr(ptCi->servCellNum, *reestabCellCGI);

            if (pDbg->flag.mroSkipFindNbrGnbCell == FALSE)
            {
                if (NULL == ptGnbNbr || N_EQUIP == ptGnbNbr->status)
                {
                    VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-FailInd) no neighbor found for rre cell(plmn:%X/ci:%lu), ptGnbNbr(%p)\n",
                        reestabCellCGI->plmn.longId, reestabCellCGI->ci, ptGnbNbr);
                    return;
                }

                if (ptGnbNbr->ssbArfcn != pCell->ssbArfcn /*check the freq */)
                {
                    // [ALGO] A2 for inter-freq. measurement received?
                    if (ptCi->mroInfo.ue.isA2Installed != TRUE /* no: A2 isn't installed */)
                    {
                        // tooLateHoRlfBeforeA2Mr(serving, rre cell)
                        MACRO_MRO_STAT(STAT_MRO_PER_NBR, TooLateHoRlfBeforeA2Mr, ptCi, lastServingCell, reestabCellCGI);

                        ptCi->cslInfo.cslRreInfo.rlfCause = csl_Too_Late_Ho_Rlf_Before_A2_Mr;
                        return;
                    }
                }
            }

            // tooLateHoRlfBeforeTriggering(serving, rre cell)
            MACRO_MRO_STAT(STAT_MRO_PER_NBR, TooLateHoRlfBeforeTriggering, ptCi, lastServingCell, reestabCellCGI);

            ptCi->cslInfo.cslRreInfo.rlfCause = csl_Too_Late_Ho_Rlf_Before_Triggering;
        }
    }
    return;
}
// }}}

void FnVCCB_procMRO_InterSystem_HoReport_InterSystemPingpong(callInfo_type *ptCi, uint8_t interface)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!IS_MRO_ENABLED(MRO_RAT_LTE, ptCi)) return;

    switch (interface)
    {
        case interface_xn:
            // IRAT MRO Fig 11: Receive HO report via XN
            MACRO_MRO_STAT(STAT_MRO_PER_EUTRA_NBR, PingPongHo_EUTRA, ptCi, &ptCi->mroInfo.ho_report.sourceCellCGI,
                &ptCi->mroInfo.ho_report.targetCellInEutranCGI);
            return;

            break;
        case interface_ng:
            // IRAT MRO Fig 11: Receive HO report via NG
            MACRO_MRO_STAT(STAT_MRO_PER_EUTRA_NBR, PingPongHo_EUTRA, ptCi,
                &ptCi->mroInfo.sonInfo.hoRpt.sourceCellCgi, &ptCi->mroInfo.sonInfo.hoRpt.targetCellInEutranCGI);

            break;

        default:
            VCCB_PRINT_CALL_MRO(
                ptCi, "[MRO] (Inter-sys PP) Dicard. invalid interface(%d)\n", interface);
            break;
    }

    return;
}

void FnVCCB_procMRO_InterSystem_HoReport_UnnecessaryHoDetect(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!IS_MRO_ENABLED(MRO_RAT_LTE, ptCi)) return;

    // IRAT MRO : Receive Inter System HO report via NG
    if ((ptCi->mroInfo.sonInfo.m.rcvdInterSysHO_UnnecessaryHO == OPT_PRESENT) &&
        (ptCi->mroInfo.sonInfo.m.earlyIRATHO != OPT_PRESENT))
    {
        MACRO_MRO_STAT(STAT_MRO_PER_EUTRA_NBR, UnnecessaryHo_EUTRA, ptCi, &ptCi->mroInfo.sonInfo.hoRpt.sourceCellCgi,
            &ptCi->mroInfo.sonInfo.hoRpt.targetCellInEutranCGI);
    }
    else
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-IS-HoRpt) Discard. (UnnecessaryHO:%d/ earflyIRATHO:%d)\n",
            ptCi->mroInfo.sonInfo.m.rcvdInterSysHO_UnnecessaryHO,
            ptCi->mroInfo.sonInfo.m.earlyIRATHO);
    }

    return;
}

// 6.3 HOP Classification Upon Receiving HO Report
// {{{
//[3-2]
void FnVCCB_NWBasedMRO_XN_HoReport(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    cgi_type *sourceCellCGI = &ptCi->mroInfo.ho_report.sourceCellCGI;
    cgi_type *targetCellCGI = &ptCi->mroInfo.ho_report.targetCellCGI;

    VCCB_PRINT_LOG_MRO_CGI("sourceCellCGI", sourceCellCGI->ci);
    VCCB_PRINT_LOG_MRO_CGI("targetCellCGI", targetCellCGI->ci);

    // [ALGO] Source Cell CGI belongs to this gNB?
    if (!VLIB_isCellBelongsToGnb(&sourceCellCGI->plmn, &sourceCellCGI->ci, ptCi->gnbNum))
    {
        // discard
        VCCB_PRINT_CALL_MRO(ptCi, 
            "[MRO] (NW-XN-HoRpt) Discard. source cell(plmn:%X/ci:%lu) no belongs to this gNB\n", 
            sourceCellCGI->plmn.longId, sourceCellCGI->ci);
        return;
    }

    // [ALGO] Source Cell CGI != Target Cell CGI
    if (FnVCCB_CheckCgiIdentical(sourceCellCGI, targetCellCGI))
    {
        // discard
        VCCB_PRINT_CALL_MRO(ptCi, 
            "[MRO] (NW-XN-HoRpt) Discard. source cell(plmn:%X/ci:%lu) == target cell(plmn:%X/ci:%lu)\n",
            sourceCellCGI->plmn.longId, sourceCellCGI->ci, targetCellCGI->plmn.longId, targetCellCGI->ci);
        return;
    }

    // [ALGO] Handover Report Type
    switch (ptCi->mroInfo.ho_report.handoverReportType)
    {
        case XNAP_hoTooEarly: /*Too early HO*/
        {
            // tooEarlyHoRlfAfterHo(source, target)
            MACRO_MRO_STAT(STAT_MRO_PER_NBR, TooEarlyHoRlfAfterHo, ptCi, sourceCellCGI, targetCellCGI);
            break;
        }
        case XNAP_hoToWrongCell: /*HO to wrong cell*/
        {
            // [ALGO] Re-establishment Cell CGI is NR Cell Identity?
            if (ptCi->mroInfo.ho_report.m.rreCellCGI != OPT_PRESENT)
            {
                // discard
                VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (NW-XN-HoRpt) Discard. no reestablishmentCellId\n");
                break;
            }
            cgi_type *rreCellCGI = &ptCi->mroInfo.ho_report.rreCellCGI;

            // [ALGO] Re-establishemt Cell != Source Cell CGI
            if (FnVCCB_CheckCgiIdentical(rreCellCGI, sourceCellCGI))
            {
                // discard
                VCCB_PRINT_CALL_MRO(
                    ptCi, "[MRO] (NW-XN-HoRpt) Discard. RRE cell(plmn:%X/ci:%lu) == source cell(plmn:%X/ci:%lu)\n", 
                    rreCellCGI->plmn.longId, rreCellCGI->ci, sourceCellCGI->plmn.longId, sourceCellCGI->ci);
                break;
            }

            // [ALGO] Re-establishemt Cell != Target Cell CGI
            if (FnVCCB_CheckCgiIdentical(rreCellCGI, targetCellCGI))
            {
                // discard
                VCCB_PRINT_CALL_MRO(
                    ptCi, "[MRO] (NW-XN-HoRpt) Discard. RRE cell(plmn:%X/ci:%lu) == target cell(plmn:%X/ci:%lu)\n", 
                    rreCellCGI->plmn.longId, rreCellCGI->ci, targetCellCGI->plmn.longId, targetCellCGI->ci);
                break;
            }

            // hoToWrongCellRlfAfterHoTarget(source, target)
            MACRO_MRO_STAT(STAT_MRO_PER_NBR, HoToWrongCellRlfAfterHoTarget, ptCi, sourceCellCGI, targetCellCGI);
            // hoToWrongCellRlfAfterHoOther(source, rre Cell)
            MACRO_MRO_STAT(STAT_MRO_PER_NBR, HoToWrongCellRlfAfterHoOther, ptCi, sourceCellCGI, rreCellCGI);
            break;
        }
        default:
        {
            // discard
            VCCB_PRINT_CALL_ERROR(
                ptCi, "[MRO] (NW-XN-HoRpt) Discard. not supported handoverReportType(%d)\n", ptCi->mroInfo.ho_report.handoverReportType);
            break;
        }
    }
}

//[22B ALGO] Failure Indication Transmit Procedure
int16_t FnVCCB_SendFailureIndication(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    const VccbDbgInfo_type *const pDbg = DBG;
    int16_t status = GOOD;    

    if (ptCi->rlfReportInfo.choice == NR_RlfReport)  // nr-RLF-Report
    {
        ptCi->mroInfo.ableToSendNgSonConfigTransfer.isAble = FALSE; //init

        status = FnVCCB_PrepareXNAP_FailureIndication(ptCi);
        if (status != BREAK)
        {
            if (ERROR == status)
                VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendXNMessage(XN_HandoverReport_id) ERROR!\n");
            return status;
        }
        else // status == BREAK, it means that need to send NG message
        {
            if (pDbg->flag.mroSkipFindNbrGnbCell == FALSE)
            {
                if (TRUE != ptCi->mroInfo.ableToSendNgSonConfigTransfer.isAble)  
                {
                    VCCB_PRINT_CALL_MRO(ptCi, "[MRO] Can't send NG Failure IND\n");
                    return ERROR;
                }
            }
            else
            {
                ptCi->mroInfo.ableToSendNgSonConfigTransfer.isAble = TRUE;  // debug code
                ptCi->mroInfo.ableToSendNgSonConfigTransfer.tAC = 1;  // debug code
                VCCB_PRINT_CALL_MRO(ptCi, "[MRO] set ableToSendNgSonConfigTransfer for debug\n");                
            }

            status = VNIL_SendNGAP_UplinkRanConfigurationTransfer(ptCi, sonConfig_failureInd);
            if (ERROR == status)  // NG Failure indi. w RLF-report
            {
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "VNIL_SendNGAP_UplinkRanConfigurationTransfer(sonConfig_failureInd) ERROR!\n");
                return ERROR;
            }
        }
    }
    else
    {
        if ((ptCi->mroInfo.rlf_report.failedPCellIdEutra.plmnIdentityEutraEpc_present) == OPT_PRESENT &&
            (ptCi->mroInfo.rlf_report.failedPCellIdEutra.cellIdentityEutraEpc_present) == OPT_PRESENT &&
            (ptCi->mroInfo.rlf_report.failedPCellIdEutra.trackingAreaCodeEutraEpc_present) == OPT_PRESENT)
        {
            status = VNIL_SendNGAP_UplinkRanConfigurationTransfer(ptCi, interSysSonConfig_failureInd);
            if (ERROR == status)  // NG Inter-system Failure indi. w RLF-report
            {
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "VNIL_SendNGAP_UplinkRanConfigurationTransfer(interSysSonConfig_failureInd) ERROR!\n");
                return status;
            }
        }
        else
        {
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] can't send Inter-system Failure Indication(%d/%d/%d)\n",
                ptCi->mroInfo.rlf_report.failedPCellIdEutra.plmnIdentityEutraEpc_present,
                ptCi->mroInfo.rlf_report.failedPCellIdEutra.cellIdentityEutraEpc_present,
                ptCi->mroInfo.rlf_report.failedPCellIdEutra.trackingAreaCodeEutraEpc_present);
            // END
        }
    }
    return status;
}

int16_t FnVCCB_SendHandoverReport(callInfo_type *ptCi, uint8_t hoReportType)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    const VccbDbgInfo_type *const pDbg = DBG;
    // Send HO Report IE via NG/XN to Last serving NR Cell(using mroInfo.ue.sourceCellCGI).
    int16_t status = GOOD;

    ptCi->mroInfo.ableToSendNgSonConfigTransfer.isAble = FALSE; //init

    status = FnVCCB_PrepareXNAP_HandoverReport(ptCi, hoReportType);
    if (BREAK != status)
    {
        if (ERROR == status)
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendXNMessage(XN_HandoverReport_id) ERROR!\n");
        return status;
    }
    else if (BREAK == status)  // Last serving cell xn connection is unavailable
    {
        if (pDbg->flag.mroSkipFindNbrGnbCell == FALSE)
        {
            // trackingAreaCode are existed in Last Serving Cell?
            if (TRUE != ptCi->mroInfo.ableToSendNgSonConfigTransfer.isAble)
            {
                VCCB_PRINT_CALL_MRO(ptCi, "[MRO] Can't send NG HO RPT");
                return ERROR;
            }
        }
        else
        {
            ptCi->mroInfo.ableToSendNgSonConfigTransfer.isAble = TRUE;  // debug code
            ptCi->mroInfo.ableToSendNgSonConfigTransfer.tAC = 1;  // debug code
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] set ableToSendNgSonConfigTransfer for debug");            
        }

        ptCi->mroInfo.ableToSendNgSonConfigTransfer.hoReportType = (hoReportType & e_BitMask_2bit);
        status = VNIL_SendNGAP_UplinkRanConfigurationTransfer(ptCi, sonConfig_handoverRpt);
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VNIL_SendNGAP_UplinkRanConfigurationTransfer(sonConfig_handoverRpt) ERROR!\n");
            return status;
        }
    }
    return status;
}

void FnVCCB_Convert_to_cgi_type(cgi_type *pDst, CGI_InfoEutraLogging_type *pEutraSrc, CGI_Info_Logging_type *pNRSrc)
{
    VALID_E_POINT_CHECK_VOID(pDst);

    if (NULL != pEutraSrc && NULL == pNRSrc)
    {
        pDst->ci = pEutraSrc->cellIdentityEutraEpc;
        memcpy(&pDst->plmn, &pEutraSrc->plmnIdentityEutraEpc, sizeof(pDst->plmn));
    }
    else if (NULL == pEutraSrc && NULL != pNRSrc)
    {
        pDst->ci = pNRSrc->ci;
        memcpy(&pDst->plmn, &pNRSrc->plmn, sizeof(pDst->plmn));
    }
    else
    {
        VCCB_PRINT_ERROR("FnVCCB_Convert_to_cgi_type(pEutraSrc,pNRSrc NULL) ERROR!\n");
    }
}

int16_t FnVCCB_GetCGIWithPciArfcn(uint16_t cellNum, uint16_t pci, uint32_t arfcn, cgi_type *tgtCgi)
{
    const uint16_t maxCellNumVccb = MAX_CELL_NUM_VCCB;
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, maxCellNumVccb);
    VALID_E_POINT_CHECK_ERROR(tgtCgi);

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    uint16_t uniqueNbrIdx = maxCellNumVccb;

    for (uint16_t nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)
    {
        nbrCellInfo_type *pCellNbr = &pCell->Nbr[nbrIdx];

        if (pCellNbr->status != EQUIP) continue;

        nbrGnbCellInfo_type *ptNbrGnbCell;

        if (GOOD != getNbrGnbCellByCellNbrIdx(cellNum, nbrIdx, &ptNbrGnbCell)) continue;

        if (ptNbrGnbCell->nrPci == pci && ptNbrGnbCell->ssbArfcn == arfcn)
        {
            if (uniqueNbrIdx < maxCellNumVccb) //duplicate
            {
                VCCB_PRINT_COMMENT("[MRO] duplicate NCR. pci(%d) arfcn(%d) cellNum(%d)\n", pci, arfcn, cellNum);
                return ERROR;
            }

            uniqueNbrIdx = nbrIdx;
            tgtCgi->ci = VLIB_GnbIdCellId2NrCellId(&ptNbrGnbCell->globalGnbId.gnbId, ptNbrGnbCell->cellId);
            tgtCgi->plmn.longId = ptNbrGnbCell->globalGnbId.plmn.longId;
        }
    }

    VCCB_PRINT_COMMENT("[MRO] pci(%d) arfcn(%d) cellNum(%d) nbrIdx(%d)\n", pci, arfcn, cellNum, uniqueNbrIdx);

    if (uniqueNbrIdx < maxCellNumVccb)
        return GOOD;
    else
        return ERROR;
}

void FnVCCB_SetMroHandoverTriggerType(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint16_t hoTriggerType = MRO_HO_TRIGGER_NONE;

    if (FnVCCB_IsConditionalHandoverUE(ptCi) == TRUE)
    {
        hoTriggerType = MRO_HO_TRIGGER_CONDITIONAL;
    }
    else if (ptCi->hoInfo.isLbHo == TRUE)
    {
        hoTriggerType = MRO_HO_TRIGGER_LOAD_BALANCING;
    }
    else
    {   
        hoTriggerType = MRO_HO_TRIGGER_IMMEDIATE;
    }

    ptCi->mroInfo.hoTriggerType = (hoTriggerType & e_BitMask_3bit);

    VCCB_PRINT_CALL_MRO(ptCi, "[MRO] ## ptCi->mroInfo.hoTriggerType : %d\n", ptCi->mroInfo.hoTriggerType);

    return;
}

// Inter-RAT MRO for LTE ALGO 5.2 (HLD Fig 3)
void FnVCCB_IratMro_HOP(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (!IS_MRO_ENABLED(MRO_RAT_LTE, ptCi)) return;

    VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (IRAT) type(%d), connFail(%d), reest(%d), reconn(%d)\n",
        ptCi->rlfReportInfo.choice, ptCi->mroInfo.rlf_report.connectionFailureType,
        ptCi->mroInfo.rlf_report.m.reestablishmentCellId, ptCi->mroInfo.rlf_report.m.reconnectCellId);
 
    // SVR23A IRAT MRO ALGO v1.41 Fig 14 updated
    if (ptCi->mroInfo.rlf_report.connectionFailureType != NRRRC_connectionFailureType_r16_rlf)
    {
        return;
    }
    // [ALGO] Fig12
    else if (ptCi->mroInfo.rlf_report.m.reestablishmentCellId != OPT_PRESENT &&
        ptCi->mroInfo.rlf_report.m.reconnectCellId != OPT_PRESENT)
    {
        return;
    }

    VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (IRAT) timeConnFailure(%d), iratMroInfo.tStoreUeCtxt(%d)\n",
        ptCi->mroInfo.rlf_report.timeConnFailure, pGnb->iratMroInfo.tStoreUeCtxt);

    if ((OPT_PRESENT == ptCi->mroInfo.rlf_report.m.timeConnFailure) &&
        (ptCi->mroInfo.rlf_report.timeConnFailure <= pGnb->iratMroInfo.tStoreUeCtxt))
    {        
        // If nrFailedPCellId choice == pci-arfcn-r16, don't send HO report
        if (ptCi->mroInfo.rlf_report.c.isNrFailedPCellId_r16 != TRUE ||
            ptCi->mroInfo.rlf_report.c.isNrFailedCellGlobalId != TRUE)
        {
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (IRAT) Discard. nrFailedPCell:%d/ isCGI:%d\n",
                ptCi->mroInfo.rlf_report.c.isNrFailedPCellId_r16, ptCi->mroInfo.rlf_report.c.isNrFailedCellGlobalId);
            return;
        }

        if (ptCi->mroInfo.rlf_report.m.previousPCellId != OPT_PRESENT ||
            ptCi->mroInfo.rlf_report.c.isNrPreviousPCellId == TRUE)
        {
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (IRAT) Discard. previousPCell(presence:%d/ rat:%d)\n",
                ptCi->mroInfo.rlf_report.m.previousPCellId, ptCi->mroInfo.rlf_report.c.isNrPreviousPCellId);
            return;
        }
        
        if (ptCi->mroInfo.rlf_report.m.reestablishmentCellId == OPT_PRESENT)
        {
            if (VCOM_CheckCgiLoggingTypeIdentical(
                &ptCi->mroInfo.rlf_report.nrFailedPCellId, &ptCi->mroInfo.rlf_report.reestablishmentCellId))
            {
                VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (IRAT) Discard. nrFailedPcellId(%lu) == reestabCell(%lu)\n",
                    ptCi->mroInfo.rlf_report.nrFailedPCellId.ci, 
                    ptCi->mroInfo.rlf_report.reestablishmentCellId.ci);
                return;
            }
        }

        if (ptCi->mroInfo.rlf_report.m.reconnectCellId == OPT_PRESENT &&
            ptCi->mroInfo.rlf_report.c.isNrReconnectCellId_r16 == TRUE)
        {
            if (VCOM_CheckCgiLoggingTypeIdentical(
                &ptCi->mroInfo.rlf_report.nrFailedPCellId, &ptCi->mroInfo.rlf_report.nrReconnectCellId))
            {
                VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (IRAT) Discard. nrFailedPcellId(%lu) == nrReconnectCellId(%lu)\n",
                    ptCi->mroInfo.rlf_report.nrFailedPCellId.ci, 
                    ptCi->mroInfo.rlf_report.nrReconnectCellId.ci);
                return;
            }
        }

        //[22B ALGO] Send Inter-system HO report IE via NG : (Too Early Inter-system HO)
        if ((ptCi->mroInfo.rlf_report.eutraPreviousCellId.plmnIdentityEutraEpc_present) == OPT_PRESENT &&
            (ptCi->mroInfo.rlf_report.eutraPreviousCellId.cellIdentityEutraEpc_present) == OPT_PRESENT &&
            (ptCi->mroInfo.rlf_report.eutraPreviousCellId.trackingAreaCodeEutraEpc_present) == OPT_PRESENT)
        {
            VNIL_SendNGAP_UplinkRanConfigurationTransfer(ptCi, interSysSonConfig_handoverRpt);
        }
        else
        {
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] can't send Inter-system Handover Report(%d/%d/%d)\n",
                ptCi->mroInfo.rlf_report.eutraPreviousCellId.plmnIdentityEutraEpc_present,
                ptCi->mroInfo.rlf_report.eutraPreviousCellId.cellIdentityEutraEpc_present,
                ptCi->mroInfo.rlf_report.eutraPreviousCellId.trackingAreaCodeEutraEpc_present);
        }
    }
    else{
        if ((ptCi->mroInfo.rlf_report.m.previousPCellId != OPT_PRESENT) &&
            (ptCi->mroInfo.rlf_report.m.reconnectCellId == OPT_PRESENT) &&
            (ptCi->mroInfo.rlf_report.c.isNrReconnectCellId_r16 == FALSE) &&  // EUTRA
            (ptCi->mroInfo.rlf_report.m.reestablishmentCellId != OPT_PRESENT))  // SVR23A IRAT MRO ALGO v1.41 Fig 14 updated
        {
            // Collect Too late HO Statistics (Too late inter-system From nrFailedPCellId To eturaReconnectCellId)
            cgi_type nrFailedPCellCgi, eutraReconnectCellCgi;
            FnVCCB_Convert_to_cgi_type(&nrFailedPCellCgi, NULL, &ptCi->mroInfo.rlf_report.nrFailedPCellId);
            FnVCCB_Convert_to_cgi_type(&eutraReconnectCellCgi, &ptCi->mroInfo.rlf_report.eutraReconnectCellId, NULL);
            MACRO_MRO_STAT(STAT_MRO_PER_EUTRA_NBR, TooLateHo_EUTRA, ptCi, &nrFailedPCellCgi, &eutraReconnectCellCgi);
        }
        else
        {
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (IRAT) Discard. prev:%d/ recon:(%d/%d)/ reest:%d\n",
                ptCi->mroInfo.rlf_report.m.previousPCellId, ptCi->mroInfo.rlf_report.m.reconnectCellId,
                ptCi->mroInfo.rlf_report.c.isNrReconnectCellId_r16,
                ptCi->mroInfo.rlf_report.m.reestablishmentCellId);
        }
    }
}

uint16_t FnVCCB_GetXnIdxFromCgi(callInfo_type *ptCi, cgi_type *nbrCellCgi)
{
    AUTO_TRACE_FUNC;

    if (ptCi == NULL || nbrCellCgi == NULL)
        return MAX_XN_NBR_PER_GNB;

    if (ptCi->gnbNum >= MAX_GNB_PER_SYS)
        return MAX_XN_NBR_PER_GNB;

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    vccbGlobalGnbId_type targetGnbId;

    targetGnbId.gnbId.idLength = pGnb->globalGnbId.gnbId.idLength;
    targetGnbId.gnbId.id =
        VLIB_NrCellId2GnbId(pGnb->globalGnbId.gnbId.idLength, nbrCellCgi->ci);
    targetGnbId.plmn = nbrCellCgi->plmn;

    // Find XN connection
    uint16_t xnIdx = fnVLIB_FindXnEndPointIndexByGnbId(ptCi->gnbNum, &targetGnbId);
    if (xnIdx >= MAX_XN_NBR_PER_GNB)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] No XN connection gnbId:%d (ci:%lu/plmn:%X)\n",
            targetGnbId.gnbId.id, nbrCellCgi->ci, nbrCellCgi->plmn.longId);
    }

    return xnIdx;
}

// Update when HO triggered on Source gNB
void FnVCCB_UpdateMroHoInfoOnSourceGnb(callInfo_type *ptCi, uint16_t hoTypeRat, uint16_t hoTypeNb)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    /* [HO TYPE]
        - Intra-gNB HO : HO_TYPE_INTRA_RAT + HO_TYPE_INTRA_NB 
        - Inter-gNB HO : HO_TYPE_INTRA_RAT + HO_TYPE_INTER_NB
        - Inter-RAT HO : HO_TYPE_INTER_RAT + HO_TYPE_INTER_NB */

    if (hoTypeRat == HO_TYPE_INTRA_RAT && hoTypeNb == HO_TYPE_INTRA_NB)
        VLIB_InitMroInfo(ptCi); // init when it's Intra-gNB HO
    
    ptCi->mroInfo.ue.timestamp.tv_sec = -1;  //timestamp is used to recognize incoming HO 
    ptCi->mroInfo.ue.timestamp.tv_nsec = -1;
    
    ptCi->mroInfo.ue.hoInitiated = ptCi->hoInfo.hoType.initiated;
    
    if (hoTypeRat == HO_TYPE_INTRA_RAT)
    {
        FnVCCB_SetMroHandoverTriggerType(ptCi);

        ptCi->mroInfo.ue.sourceCellCGI = ptCi->nRCGI;
        ptCi->mroInfo.ue.targetCellCGI = ptCi->hoInfo.cgi;
        
        ptCi->mroInfo.upmAlgoInfoInstalled = ptCi->upmInfo.upmAlgoInfoInstalled;
        
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] ## SA HO triggered on Source gNB(src:%X-%lu/ tgt:%X-%lu)\n",
            ptCi->mroInfo.ue.sourceCellCGI.plmn.longId, ptCi->mroInfo.ue.sourceCellCGI.ci,
            ptCi->mroInfo.ue.targetCellCGI.plmn.longId, ptCi->mroInfo.ue.targetCellCGI.ci);
    }
}

void FnVCCB_UpdateMroHoInfoOnTargetGnb(callInfo_type *ptCi, const cgi_type *ptCgi, bool isHandInCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptCgi);

    if (isHandInCell == TRUE) // Update targetCellCGI with hand-in NR cell
    {
        ptCi->mroInfo.ue.targetCellCGI = *ptCgi;
        
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] ## update ptCi->mroInfo.ue.targetCellCGI on Target gNB(plmn:%X/ci:%lu)\n",
            ptCi->mroInfo.ue.targetCellCGI.plmn.longId, ptCi->mroInfo.ue.targetCellCGI.ci);
    }
    else // update sourceCellCGI with lastest visited NR cell
    {
        ptCi->mroInfo.ue.sourceCellCGI = *ptCgi;

        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] ## update ptCi->mroInfo.ue.sourceCellCGI on Target gNB(plmn:%X/ci:%lu)\n",
            ptCi->mroInfo.ue.sourceCellCGI.plmn.longId, ptCi->mroInfo.ue.sourceCellCGI.ci);
    }    
}

int16_t FnVCCB_UeBasedMRO_HOP_HandoverReport_CheckCellCgi(callInfo_type *ptCi, uint8_t interface)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    cgi_type *sourceCellCGI, *targetCellCGI, *rreCellCGI;
    uint8_t hoReportType;
    bool rreCellExist = false;

    if (interface == interface_xn)
    {
        sourceCellCGI = &ptCi->mroInfo.ho_report.sourceCellCGI;
        targetCellCGI = &ptCi->mroInfo.ho_report.targetCellCGI;
        rreCellCGI = &ptCi->mroInfo.ho_report.rreCellCGI;
        rreCellExist = (ptCi->mroInfo.ho_report.m.rreCellCGI == OPT_PRESENT);
        hoReportType = (enumHoRptType)ptCi->mroInfo.ho_report.handoverReportType;
    }
    else // interface == interface_ng
    {
        sourceCellCGI = &ptCi->mroInfo.sonInfo.hoRpt.sourceCellCgi;
        targetCellCGI = &ptCi->mroInfo.sonInfo.hoRpt.targetCellCgi;
        rreCellCGI = &ptCi->mroInfo.sonInfo.hoRpt.reestablishmentCellCgi;        
        rreCellExist = (ptCi->mroInfo.sonInfo.hoRpt.m.reestablishmentCellCgi == OPT_PRESENT);
        hoReportType = (enumHoRptType)ptCi->mroInfo.sonInfo.hoRpt.handoverReportType;
    }

    VCCB_PRINT_LOG_MRO_CGI("sourceCellCGI", sourceCellCGI->ci);
    VCCB_PRINT_LOG_MRO_CGI("targetCellCGI", targetCellCGI->ci);
    VCCB_PRINT_LOG_MRO_CGI("rreCellCGI", rreCellCGI->ci);

    // [ALGO] Source Cell CGI(=nrPreviousCell) belongs to this gNB?
    if (!VLIB_isCellBelongsToGnb(&sourceCellCGI->plmn, &sourceCellCGI->ci, ptCi->gnbNum))
    {
        // discard
        VCCB_PRINT_CALL_MRO(ptCi,
            "[MRO] (UE-HoRpt) sourceCellCGI(ci:%lu) and current gNB(gnbNum:%d) is different gNB\n", sourceCellCGI->ci,
            ptCi->gnbNum);
        return ERROR;
    }

    // [ALGO] Source Cell CGI != Target Cell CGI
    if (FnVCCB_CheckCgiIdentical(sourceCellCGI, targetCellCGI))
    {
        // discard
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (UE-HoRpt) source cell CGI(%lu) and target cell CGI(%lu) is same\n",
            sourceCellCGI->ci, targetCellCGI->ci);
        return ERROR;
    }

    switch (hoReportType)
    {
        case HoRptType_HoTooEarly:
            break;
        
        case HoRptType_HoToWrongCell:
            // [ALGO] Re-establishment Cell CGI is NR Cell Identity?
            if (not rreCellExist)
            {
                // discard
                VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (UE-HoRpt) There is no rreCellCGI\n");
                return ERROR;
            }

            if (FnVCCB_CheckCgiIdentical(rreCellCGI, sourceCellCGI))
            {
                // discard
                VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (UE-HoRpt) Discard. rreCellCGI(%lu) == sourceCellCGI(%lu)\n",
                    rreCellCGI->ci, sourceCellCGI->ci);
                return ERROR;
            }
            if (FnVCCB_CheckCgiIdentical(rreCellCGI, targetCellCGI))
            {
                // discard
                VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (UE-HoRpt) Discard. rreCellCGI(%lu) == targetCellCGI(%lu)\n",
                    rreCellCGI->ci, targetCellCGI->ci);
                return ERROR;
            }            
            break;

        default:  // HoRptType_InterSysPingPong
            return ERROR; //discard
    }

    return GOOD;
}

/* [IRAT MRO 23B HLD Fig1 (same for Intra-NR MRO)] */
uint8_t FnVCCB_PreValidate_RlfReport(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    
    uint8_t mroType = 0x00;

    if (ptCi == NULL)
        return mroType;    

    if (!IS_MRO_ENABLED(MRO_TYPE_ANY, ptCi))
        return mroType;    

    if (ptCi->rlfReportInfo.received != OPT_PRESENT)
        return mroType;

    if (ptCi->rlfReportInfo.choice == NR_RlfReport)
    {
        if (IS_MRO_ENABLED(MRO_RAT_NR, ptCi))
        {
            if (ptCi->mroInfo.rlf_report.m.reestablishmentCellId != OPT_PRESENT)
            {
                mroType |= UE_BASED_MRO_TYPE_INTRA_NR_COVERAGE_HOLE;
            }
            else
            {
                if (ptCi->mroInfo.rlf_report.m.previousPCellId != OPT_PRESENT ||
                    ptCi->mroInfo.rlf_report.c.isNrPreviousPCellId == TRUE)
                {
                    mroType |= UE_BASED_MRO_TYPE_INTRA_NR_HO_PROBLEM;
                }
            }
        }
        
        if (IS_MRO_ENABLED(MRO_RAT_NR_CPD, ptCi))
        {
            mroType |= UE_BASED_MRO_TYPE_INTRA_NR_COVERAGE_PROBLEM;
        }

        if (IS_MRO_ENABLED(MRO_RAT_LTE, ptCi))
        {
            if (ptCi->mroInfo.rlf_report.m.reestablishmentCellId != OPT_PRESENT)
            {
                if (ptCi->mroInfo.rlf_report.m.reconnectCellId == OPT_PRESENT)
                    mroType |= UE_BASED_MRO_TYPE_IRAT_HO_PROBLEM;
            }
            else
            {
                if (ptCi->mroInfo.rlf_report.m.previousPCellId == OPT_PRESENT &&
                    ptCi->mroInfo.rlf_report.c.isNrPreviousPCellId != TRUE)
                    {
                        mroType |= UE_BASED_MRO_TYPE_IRAT_HO_PROBLEM;
                    }
            }
        }
    }
    else
    {
        if (IS_MRO_ENABLED(MRO_RAT_NR, ptCi))        
        {
            if (ptCi->mroInfo.ue.msgId == NRRRC_RrcSetupComplete_id ||
                ptCi->mroInfo.ue.msgId == NRRRC_RrcReestablishmentComplete_id)
            {
                mroType |= UE_BASED_MRO_TYPE_IRAT_HO_PROBLEM;
            }
        }
    }

    return mroType;
}

/* [IRAT MRO 23B HLD Fig 2 and 3(same for Intra-NR MRO)]
   return GOOD  : kepp going MRO procedure on this gNB
   return BREAK : MRO procedure is all done
   return ERROR : MRO procedure is not available
*/
int16_t FnVCCB_PreProcess_UebasedMRO_byMSG5(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t result = ERROR;
    
    uint8_t mroType = FnVCCB_PreValidate_RlfReport(ptCi);

    if (mroType == 0)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (UeInfoRsp) rlfReport Pre-validation failed(mroType is 0)\n");
        return ERROR;
    }

    switch (ptCi->rlfReportInfo.choice)
    {
        case EUTRA_RlfReport :
            if (mroType & UE_BASED_MRO_TYPE_IRAT_HO_PROBLEM)
            {
                FnVCCB_SendFailureIndication(ptCi);  // send Inter System Too Early HO : LTE to NR HOF
            }
            result = BREAK;

            break;
            
        case NR_RlfReport :
        {
            if (mroType == UE_BASED_MRO_TYPE_INTRA_NR_HO_PROBLEM) // only possible scenario is Intra-NR HOP
            {
                // [ALGO 4.1] Intra-NR HOP classification can be triggered by RRCReestablishmetComplete but not RRCSetupComplete
                if (ptCi->mroInfo.ue.msgId == NRRRC_RrcSetupComplete_id)
                {
                    return ERROR;
                }
            }

            // [22B ALGO] Does Last Serving Cell belong to this gNB?
            int16_t status = FnVCCB_VerifyLastServingCellFromNrRlfReport(ptCi);
            if (status == BREAK)  // failed to get last serving cell from RLF report
            {
                result = ERROR;
            }
            else if (status == ERROR)  // lastServingCell belongs to inter-gNB
            {
                if (ERROR == FnVCCB_SendFailureIndication(ptCi))  // Failure indi. w/ RLF-report
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendFailureIndication ERROR!\n");
                }
                result = ERROR;
            }
            else // lastServingCell belongs to this gNB
            {
                result = GOOD;
            }
        }
            break;
        default :
            result = ERROR; //invalid choice. ignore
            break;
    }

    return result;
}

/* [IRAT MRO 23B HLD Fig 4(same for Intra-NR MRO)]
   return GOOD  : MRO is available
   return ERROR : MRO is not available
*/
int16_t FnVCCB_PreProcess_UebasedMRO_byFailureInd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint8_t mroType = FnVCCB_PreValidate_RlfReport(ptCi);

    if (mroType == 0)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (FailureInd) rlfReport Pre-validation failed(mroType is 0)\n");
        return ERROR;
    }

    /* UE context has been found in main thread
       checking "ptTmpCi->rlfReportInfo.choice == NR_RlfReport" has been done in main thread 
       checkubg whether or not last serving cell belons to this gNB has been done in main thread */

    return GOOD;
}

void FnVCCB_UpdateRlfReportAvailableFlag(callInfo_type *ptCi, NRRRC_UE_MeasurementsAvailable_r16 *ptIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptIE);

    /* MRO requests UE Information only on receiving RRC Setup Complete or RRC Reestablishment Complete
       RRC Reconfiguration Complete nor RRC Resume Complete are not the cases MRO supports*/

    if (!IS_MRO_ENABLED(MRO_TYPE_ANY, ptCi))
    {
        return;
    }

    if (NRRRC_rlf_InfoAvailable_r16_present & ptIE->bit_mask)
        ptCi->mroInfo.msg5.m.rlfInfoAvailable = TRUE;

    return;        
}

bool FnVCCB_MRO_CPD_IsValidMeasQuantityResult(callInfo_type *ptCi, NRRRC_MeasQuantityResults *ptIE)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptIE, false);
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, false);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if ((ptIE->bit_mask & NRRRC_MeasQuantityResults_rsrp_present) &&
        (ptIE->rsrp >= pGnb->mroInfo.cpdThRsrp))
    {
        if (ptIE->bit_mask & NRRRC_MeasQuantityResults_rsrq_present)
        {
            if (ptIE->rsrq >= pGnb->mroInfo.cpdThRsrq)
            {
                // RSRP (Valid), RSRQ (Valid)
                return true;
            }
        }
        else
        {
            // RSRP (Valid), RSRQ (Not present)
            return true;
        }
    }

    return false;
}

void FnVCCB_MRO_CPD_PrintMeasResult(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (CPD) - CPD Threshold (rsrp:%d/rsrp:%d) \n",
        pGnb->mroInfo.cpdThRsrp, pGnb->mroInfo.cpdThRsrq);

    VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (CPD) - measResult : LastServCell (present:%d/rsrp:%d) \n",
        ptCi->mroInfo.rlf_report.m.measResultLastServCellRsrp,
        ptCi->mroInfo.rlf_report.measResultLastServCellRsrp);

    VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (CPD) - measResult : NeighCell    (present:%d/rsrp:%d/pci:%d/freq:%u) \n",
        ptCi->mroInfo.rlf_report.m.measResultNeighCellRsrp,
        ptCi->mroInfo.rlf_report.measResultNeighCellRsrp,
        ptCi->mroInfo.rlf_report.measResultNeighCellPci,
        ptCi->mroInfo.rlf_report.measResultNeighCellSsbFreq);

    return;
}

int FnVCCB_MRO_CPD_DetermineCovProblemType(callInfo_type *ptCi, uint8_t connectionFailureType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    FnVCCB_MRO_CPD_PrintMeasResult(ptCi);

    if ((ptCi->mroInfo.rlf_report.m.measResultLastServCellRsrp != OPT_PRESENT) && 
        (ptCi->mroInfo.rlf_report.m.measResultNeighCellRsrp != OPT_PRESENT))
    {
        /* Step 1) DlCovProblem : there's no best cell */
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (CPD) DlCovProblem(0) : Best cell is not exist \n");

        return DlCovProblem;
    }
    else if (connectionFailureType == NRRRC_connectionFailureType_r16_rlf)
    {
        /* Step 2_1) UlCovProblem : last serving cell == best cell */
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (CPD) - Connection failure type (RLF) (cause:%d) \n",
            ptCi->mroInfo.rlf_report.rlfCause);

        if (ptCi->mroInfo.rlf_report.m.measResultLastServCellRsrp == OPT_PRESENT)
        {
            if ((ptCi->mroInfo.rlf_report.rlfCause == NRRRC_rlf_Cause_r16_randomAccessProblem) || 
                (ptCi->mroInfo.rlf_report.rlfCause == NRRRC_rlf_Cause_r16_rlc_MaxNumRetx))
            {
                if ((ptCi->mroInfo.rlf_report.m.measResultNeighCellRsrp != OPT_PRESENT) ||
                    (ptCi->mroInfo.rlf_report.measResultLastServCellRsrp >= ptCi->mroInfo.rlf_report.measResultNeighCellRsrp))
                {
                    VCCB_PRINT_CALL_MRO(ptCi, "[MRO] UlCovProblem(1) : Last serving cell is strongest \n");

                    return UlCovProblem;
                }
            }
        }
    }
    else if (connectionFailureType == NRRRC_hof)
    {
        /* Step 2_2) UlCovProblem : nrFailedPCellID == strongest neighbor cell */
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (CPD) - Connection failure type (HOF) \n");
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (CPD) - NrFailedPcell(ch:%d/cgi:%d/pci:%d/freq:%d) \n",
            ptCi->mroInfo.rlf_report.c.isNrFailedPCellId_r16,
            ptCi->mroInfo.rlf_report.c.isNrFailedCellGlobalId,
            ptCi->mroInfo.rlf_report.nrFailedPci,
            ptCi->mroInfo.rlf_report.nrFailedFreq);

        if (ptCi->mroInfo.rlf_report.m.measResultNeighCellRsrp == OPT_PRESENT)
        {
            bool isHoTgtStorgestNbrCell = FnVCCB_MRO_DoesPciArfcnBelongToNrFailedPCell(ptCi, 
                    ptCi->mroInfo.rlf_report.measResultNeighCellPci, ptCi->mroInfo.rlf_report.measResultNeighCellSsbFreq);

            if (isHoTgtStorgestNbrCell)
            {
                if ((ptCi->mroInfo.rlf_report.m.measResultLastServCellRsrp != OPT_PRESENT) ||
                    (ptCi->mroInfo.rlf_report.measResultNeighCellRsrp >= ptCi->mroInfo.rlf_report.measResultLastServCellRsrp))
                {
                    VCCB_PRINT_CALL_MRO(ptCi, 
                        "[MRO] (CPD) UlCovProblem(1) : Neighbor cell is strongest and belong to nrFailedPCellID (pci-ssbFreq) \n");

                    return UlCovProblem;
                }
            }
        }
    }

    /* Step 3) OtherFailure : rest of cases*/
    VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (CPD) OtherFailure(2) : There's no DL/UL problem \n");

    return OtherFailure;
}

bool FnVCCB_MRO_DoesPciArfcnBelongToNrFailedPCell(callInfo_type *ptCi, uint16_t pci, uint32_t arfcn)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if ((ptCi->mroInfo.rlf_report.c.isNrFailedPCellId_r16 == TRUE) ||
        (ptCi->mroInfo.rlf_report.c.isNrFailedCellGlobalId == FALSE))
    {
        if ((ptCi->mroInfo.rlf_report.nrFailedPci == pci) &&
            (ptCi->mroInfo.rlf_report.nrFailedFreq == arfcn))
        {
            return true;
        }
    }

    return false;
}


/* [24A FR100, FR190, FR191] Intra-NR MRO CPD */
/*
 * @brief      This API detects coverage problem using measured results in RLF-Report-r16
 * @param      ptCi : call context
 */
void fnVCCB_UeBasedMRO_CovergeProblemDetection(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VCCB_PRINT_LOG_MRO_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t connectionFailureType = ptCi->mroInfo.rlf_report.connectionFailureType;

    CGI_Info_Logging_type *nrPreviousCellId = NULL, *nrFailedPCellId = NULL;
    cgi_type *lastServingCell = NULL;
    cgi_type nrPreviousCellCgi, nrFailedPCellCgi;
    uint16_t previousCellNum = MAX_CELL_NUM_VCCB;

    if (!IS_MRO_ENABLED(MRO_RAT_NR_CPD, ptCi))
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (CPD) Discard. CPD switch is off \n");
        return;
    }

    if (ptCi->mroInfo.rlf_report.c.isNrFailedPCellId_r16 != TRUE)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (CPD) Discard. failedPCellId is EUTRA\n");
        return;
    }

    if (connectionFailureType == NRRRC_connectionFailureType_r16_rlf)
    {
        if (ptCi->mroInfo.rlf_report.c.isNrFailedCellGlobalId != TRUE)
        {
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (CPD) Discard. nrFailedPCellId choice is pci-arfcn-r16\n");
            return;
        }

        nrFailedPCellId = &ptCi->mroInfo.rlf_report.nrFailedPCellId;
        VCCB_PRINT_LOG_MRO_CGI("nrFailedPCellId", nrFailedPCellId->ci);        
        FnVCCB_Convert_to_cgi_type(&nrFailedPCellCgi, NULL, nrFailedPCellId);

        if (!VLIB_isCellBelongsToGnb(&nrFailedPCellId->plmn, &nrFailedPCellId->ci, ptCi->gnbNum))
        {
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (CPD) Discard. nrFailedPCellId no belongs to this gNB\n");
            return;            
        }

        lastServingCell = &nrFailedPCellCgi;
    }
    else // connectionFailureType == NRRRC_hof
    {
        if ((ptCi->mroInfo.rlf_report.m.previousPCellId != OPT_PRESENT) ||
            (ptCi->mroInfo.rlf_report.c.isNrPreviousPCellId != TRUE))
        {
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (CPD) Discard. nrPreviousPCellId(presence:%d/rat:%d)\n",
                ptCi->mroInfo.rlf_report.m.previousPCellId, ptCi->mroInfo.rlf_report.c.isNrPreviousPCellId);
            return;
        }

        nrPreviousCellId = &ptCi->mroInfo.rlf_report.nrPreviousCellId;
        VCCB_PRINT_LOG_MRO_CGI("nrPreviousCellId", nrPreviousCellId->ci);            
        FnVCCB_Convert_to_cgi_type(&nrPreviousCellCgi, NULL, nrPreviousCellId);        

        // Check that nrPreviousCell belongs to this gNB and get cellNum
        if (GOOD != VCCM_GetCellNumFromNrCgi(ptCi->gnbNum, &nrPreviousCellCgi, &previousCellNum, false))
        {
                // discard
            VCCB_PRINT_CALL_MRO(ptCi, "[MRO] (CPD) nrPreviousCell(%llx) and current gnb(%x) is different gNB\n",
                1ULL * nrPreviousCellCgi.ci, ptCi->gnbNum);
            return;
        }
        VCCB_CHECK_VALID_CELLNUM_VOID(previousCellNum);

        lastServingCell = &nrPreviousCellCgi;
    }

    int mType = FnVCCB_MRO_CPD_DetermineCovProblemType(ptCi, connectionFailureType);

    if (mType != ERROR)
    {
        MACRO_MRO_STAT(STAT_COVERAGE_PROBLEM_DU_ID, mType, ptCi, lastServingCell, NULL);
    }

    return;
}

/* SVR23A FGS-SF0510:FR50 */
/*
 * @brief      This API determines whether Inter-system Measurement Configuration IE should be configured.
 * @param      ptCi : call context
 */
bool ProcInterSystemMeasurementConfiguration::FnVCCB_IncludeInterSysMeasConfig(callInfo_type *ptCi, enumMeasurementReportType reportType, uint8_t reportPurpose)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (!IS_MRO_ENABLED(MRO_RAT_LTE, ptCi)) return false;

    if ((reportType == measReport_B1Eutra && reportPurpose == b1Purpose_eutraHandover) ||
        (reportType == measReport_B2Eutra && reportPurpose == b2Purpose_eutraHandover))
    {
        uint32_t randVal = FnVCCB_GetRandomValue(__func__, ptCi->gnbNum, 100);
        randVal++;  // range [1..100]

        if ((pGnb->iratMroInfo.ueMeasRate != 0) && (pGnb->iratMroInfo.ueMeasRate >= randVal))
        {
            VCCB_PRINT_CALL_MRO(ptCi, "[MRODBG] ## Need to include InterSysMeasConfig IE (ueMeasRate(%d)>=randVal(%d))\n",
                pGnb->iratMroInfo.ueMeasRate, randVal);
            return true;
        }
    }

    return false;
}

// }}}
// }}}
