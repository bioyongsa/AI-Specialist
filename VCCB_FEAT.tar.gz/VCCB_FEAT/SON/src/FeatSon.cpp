/**
 * @file        FeatSon.cpp
 * @brief       Utility functions for Full Son
 */
#include "FeatSon.h"

#include "FeatCommon.h"
#include "FeatHo.h"
#include "FeatMro.h"
#include "FeatCallInfo.h"
#include "FeatCallProc.h"
#include "FeatMrl.h"
#include "FeatAnr.hpp"

#include "MsgNrRrcMake.h"

#include "ComInclude.h"
#include "ComLibUtility.h"

#include "StateCommon.h"
#include "StateMeasurements.h"

#include "MsgCommonStore.h"

#include "s1apUnpackIE.h"
#include "MsgOamStore.h"
#include "MsgOamSend.h"
#include "FeatUpm.hpp"
#include "FeatUeHistory.h"
#include <type_traits>

/****************************************************************************
                UTIL
****************************************************************************/
// {{{

int16_t VCOM_CheckCgiLoggingTypeIdentical(CGI_Info_Logging_type *ptCgi1, CGI_Info_Logging_type *ptCgi2)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCgi1);
    VALID_E_POINT_CHECK_FALSE(ptCgi2);

    if (VCOM_CheckPlmnIdentical(&ptCgi1->plmn, &ptCgi2->plmn) == FALSE) return FALSE;

    if (ptCgi1->ci != ptCgi2->ci) return FALSE;

    if (ptCgi1->tacFlag != ptCgi2->tacFlag || ptCgi1->tac != ptCgi2->tac) return FALSE;

    return TRUE;
}  // }}}

// }}}
/****************************************************************************
                ANR ( Automatic Neighbor Relation )
****************************************************************************/
// {{{

BOOL VIIL_AnrIsGBRUe(callInfo_type *ptCi)
{  // {{{
    // this function can be used when STATE_DB, STATE_Conn.
    // in this function, there is no qosFlowStatus check, so only STATE_DB and STATE_Conn are available.
    AUTO_TRACE_FUNC;
    int loop;

    uint8_t isDirectReturnCase = FnVCCB_IsIpcTest();
    if (isDirectReturnCase < CHECK_GBR_UE_DBG_MODE_VAL) return static_cast<BOOL>(isDirectReturnCase);

    if (E_CALLTYPE_SA == ptCi->callType)
    {
        for (uint16_t drbIdx = 0; drbIdx < MAX_DRB_PER_UE; drbIdx++)
        {
            callDRBInfo_type *ptDi = &ptCi->drb[drbIdx];

            if (!IS_VALID_NODE(DRB_NODE, ptCi, ptDi)) continue;

            // ptDi->drbStatus == S_Null (NRDC SN)
            if (VLIB_IsCommonValidStateOfPduQosDrb(ptDi->drbStatus) != GOOD || ptDi->drbStatus == S_Null) continue;

            for (uint8_t qIdx = 0; qIdx < MAX_QOS_FLOW_PER_DRB; qIdx++)
            {
                uint16_t qosFlowIndex = ptDi->qosFlowIndex[qIdx];

                if (qosFlowIndex >= MAX_QOS_FLOW_PER_CALL) continue;

                qosFlowInfo_type *ptQi = &ptCi->qosFlow[qosFlowIndex];

                if (CI_use != ptQi->usage) continue;
                if (VLIB_IsCommonValidStateOfPduQosDrb(ptQi->qosFlowStatus) != GOOD) continue;
                if (OPT_PRESENT == ptQi->qosParam.gbrQosInformationPresent)
                {
                    VCCB_PRINT_CALL_COMMENT(ptCi, "%s GBR UE\n",__func__);
                    return True;
                }
            }
        }
    }
    else if (E_CALLTYPE_NSA == ptCi->callType)  // E_CALLTYPE_NSA or NSA Pkg
    {
        callERABInfo_type *ptRi;
        for (loop = 0; loop < MAX_ERAB_PER_CALL; loop++)
        {
            if (CI_use == ptCi->erabInfo[loop].usage)
            {
                ptRi = &ptCi->erabInfo[loop];
                if (ptRi->erabQos.qciValue.gbrType == ci_GBR)
                {
                    VCCB_PRINT_CALL_COMMENT(ptCi, "%s: UE has at least one GBR bearer.\n", __FUNCTION__);
                    return True;
                }
            }
        }
    }
    return False;
}  // }}}

int16_t FnVCCB_getUeAutonomousGaps(callInfo_type *ptCi, uint16_t cellNum, uint8_t ratType)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    uint32_t freq = pCell->nrArfcnDl;
    const bool isFr1 = (freq < MIN_A6_NR_ARFCN);

    if (ratType == nrType)
    {
        if (ptCi->callType == E_CALLTYPE_SA)
        {
            if (IS_NRDC(ptCi))
            {
                return (isFr1 ? ptCi->ueInfo.ueCapa.nr.fr1Capa.measAndMob.nrAutonomousGaps_NRDC
                              : ptCi->ueInfo.ueCapa.nr.fr2Capa.measAndMob.nrAutonomousGaps_NRDC);
            }

            if (IS_NEDC_MN(ptCi))
            {
                return (isFr1 ? ptCi->ueInfo.ueCapa.nr.fr1Capa.measAndMob.nrAutonomousGaps_NEDC
                              : ptCi->ueInfo.ueCapa.nr.fr2Capa.measAndMob.nrAutonomousGaps_NEDC);
            }

            // SA UE(no NR-DC/NE-DC UE) in MN
            return (isFr1 ? ptCi->ueInfo.ueCapa.nr.fr1Capa.measAndMob.nrAutonomousGaps
                          : ptCi->ueInfo.ueCapa.nr.fr2Capa.measAndMob.nrAutonomousGaps);
        }

        // E_CALLTYPE_NSA
        return (isFr1 ? ptCi->ueInfo.ueCapa.nr.fr1Capa.measAndMob.nrAutonomousGaps_ENDC
                      : ptCi->ueInfo.ueCapa.nr.fr2Capa.measAndMob.nrAutonomousGaps_ENDC);
    }

    // Inter RAT
    if (IS_NRDC_MN(ptCi))  // (UE (with NR-DC UE) in MN)
    {
        return ptCi->ueInfo.ueCapa.nr.measAndMob.eutraAutonomousGaps_NRDCR16;
    }

    if (IS_NEDC_MN(ptCi))  // There is no inter rat meas object for NR-DC SN
    {
        return ptCi->ueInfo.ueCapa.nr.measAndMob.eutraAutonomousGaps_NEDCR16;
    }

    // (SA UE (no MR-DC UE) in MN)
    return ptCi->ueInfo.ueCapa.nr.measAndMob.eutraAutonomousGapsR16;
}  // }}}

uint16_t FnVCCB_getAutoGapsSwitch(callInfo_type *ptCi, uint16_t cellNum, uint8_t ratType)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    if (nrType == ratType)
    {
        return pCell->anrInfo.autonomousGapsSwitch;
    }

    return pCell->irat_anrInfo.eutraAutonomousGapsSwitch;
}  // }}}

uint8_t FnVCCB_IsSupportUeAutonomousGaps(callInfo_type *ptCi, uint16_t cellNum, uint8_t ratType)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    uint16_t autoGapsSwitch = FnVCCB_getAutoGapsSwitch(ptCi, cellNum, ratType);
    if (ON != autoGapsSwitch)
    {
        return FALSE;
    }

    return (uint8_t)FnVCCB_getUeAutonomousGaps(ptCi, cellNum, ratType);
}  // }}}

uint8_t FnVCCB_getUeBasedAnrSwitch(callInfo_type *ptCi, uint16_t cellNum, uint8_t ratType)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    if (nrType == ratType)
    {
        return (uint8_t)pCell->anrInfo.ueBasedAnrSwitch;
    }

    return (uint8_t)pCell->irat_anrInfo.ueBasedAnrSwitch;
}  // }}}

int16_t FnVCCB_getUeCgiReport(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    if (E_CALLTYPE_SA == ptCi->callType)
    {
        if (IS_NRDC(ptCi))
        {
            return ptCi->ueInfo.ueCapa.nr.measAndMob.cgi_Reporting_NRDC;
        }

        if (IS_NEDC_MN(ptCi))
        {
            return ptCi->ueInfo.ueCapa.nr.measAndMob.cgi_Reporting_NEDC;
        }

        // SA UE(no NR-DC/NE-DC UE) in MN
        return ptCi->ueInfo.ueCapa.nr.measAndMob.cgi_Reporting;
    }

    // ENDC UE
    return ptCi->ueInfo.ueCapa.mrdc.cgi_Reporting;
}  // }}}

int16_t FnVCCB_getCellReportCgiSwitch(callInfo_type *ptCi, uint16_t cellNum)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    if (E_CALLTYPE_SA == ptCi->callType)
    {
        if (IS_NRDC(ptCi))
        {
            return pCell->anrInfo.reportCgiNrdcSwitch;
        }

        if (IS_NEDC_MN(ptCi))
        {
            return pCell->anrInfo.reportCgiNedcSwitch;
        }

        // SA UE(no NR-DC/NE-DC UE) in MN
        return pCell->anrInfo.reportCgiSwitch;
    }

    // ENDC UE
    return pCell->anrInfo.reportCgiEndcSwitch;
}  // }}}

/****************************************************************************
 * (Intra-NR) ReportCGI capability check
 * reportCgiSwitch from FnVCCB_getReportCgiSwitch
    'fr1' or 'fr1&fr2' if the target NR cell is operating on FR1
    'fr2' or 'fr1&fr2' if the target NR cell is operating on FR2
****************************************************************************/
int16_t FnVCCB_getReportCgiSwitch(callInfo_type *ptCi, uint16_t cellNum, uint32_t freq)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    const uint8_t reportCgiSwitch = (uint8_t)FnVCCB_getCellReportCgiSwitch(ptCi, cellNum);
    const bool isFr1 = (freq < MIN_A6_NR_ARFCN);
    const bool isFr2 = (freq >= MIN_A6_NR_ARFCN);

    if (isFr1 && REPORTCGI_FR2_ON == reportCgiSwitch)
    {
        return REPORTCGI_OFF;
    }

    if (isFr2 && REPORTCGI_FR1_ON == reportCgiSwitch)
    {
        return REPORTCGI_OFF;
    }

    return reportCgiSwitch;
}  // }}}

int16_t FnVCCB_getUeEutraCgiReport(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    if (IS_NRDC_MN(ptCi))  // (UE (with NR-DC UE) in MN)
    {
        return ptCi->ueInfo.ueCapa.nr.measAndMob.eutra_cgi_Reporting_NRDC;
    }

    if (IS_NEDC_MN(ptCi))  // There is no inter rat meas for NR-DC SN
    {
        return ptCi->ueInfo.ueCapa.nr.measAndMob.eutra_cgi_Reporting_NEDC;
    }

    // (SA UE (no MR-DC UE) in MN)
    return ptCi->ueInfo.ueCapa.nr.measAndMob.eutra_cgi_Reporting;
}  // }}}

/****************************************************************************
 * (Inter-RAT) ReportCGI capability check
 * eutra-report-cgi-switch / eutra-report-cgi-nrdc-switch : OFF/ON
 ****************************************************************************/
int16_t FnVCCB_getEutraReportCgiSwitch(callInfo_type *ptCi, uint16_t cellNum)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    if (IS_NRDC_MN(ptCi))  // (UE (with NR-DC UE) in MN)
    {
        return (int16_t)pCell->irat_anrInfo.eutraReportCgiNrdcSwitch;
    }

    if (IS_NEDC_MN(ptCi))
    {
        return (int16_t)pCell->irat_anrInfo.eutraReportCgiNedcSwitch;
    }

    // (SA UE (no MR-DC UE) in MN)
    return (int16_t)pCell->irat_anrInfo.eutraReportCgiSwitch;
}  // }}}

uint16_t FnVCCB_getAnrLongDrxCycle(callInfo_type *ptCi, uint16_t cellNum, uint8_t ratType, uint32_t freq)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    const bool isFr1 = (freq < MIN_A6_NR_ARFCN);
    const BOOL isGBRUe = VIIL_AnrIsGBRUe(ptCi); // SVR24B FGS-SF0502 FR192, FR193

    if (nrType == ratType)
    {
        // SVR24B FGS-SF0502 FR192, FR193
        // long-drx-cycle-fr1-gbr or long-drx-cycle-fr2-gbr
        if (isGBRUe)
        {
            return (isFr1 ? pCell->anrInfo.longDrxCycleFr1Gbr : pCell->anrInfo.longDrxCycleFr2Gbr);
        }
        else
        {
            return (isFr1 ? pCell->anrInfo.longDrxCycleFr1 : pCell->anrInfo.longDrxCycleFr2);
        }
    }

    if (isGBRUe)
    {
        return pCell->irat_anrInfo.longDrxCycleGbr;
    }
    else
    {
        return pCell->irat_anrInfo.longDrxCycle;
    }
}  // }}}

bool FnVCCB_CheckUeBasedReportCgi(callInfo_type *ptCi, uint8_t ueCgiReporting, uint8_t ueAutonomousGap,
    uint8_t ueBasedAnrSwitch, uint8_t reportCgiSwitch, uint8_t gbrUeSwitch)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (VCCB_FLAG_ON != ptCi->ueContainerNR.rxFlag)
    {
        VCCB_PRINT_LOG_ANR(ptCi, "(ANR) ueContainerNR.rxFlag is disabled\n");
        return false;
    }

    // UE support
    if (ueCgiReporting != TRUE)
    {
        VCCB_PRINT_LOG_ANR(ptCi, "(ANR) ueCgiReporting is disabled\n");
        return false;
    }

    // Feature is disabled
    if ((ON != ueBasedAnrSwitch) || ((FALSE == reportCgiSwitch)))
    {
        VCCB_PRINT_LOG_ANR(
            ptCi, "(ANR) ueBasedAnrSwitch(%d) or reportCgiSwitch(%d) is disabled\n", ueBasedAnrSwitch, reportCgiSwitch);
        return false;
    }

    const auto fName = __FUNCTION__;
    const auto isGbrUe = (True == VIIL_AnrIsGBRUe(ptCi));

    // Returns true if Autonomous Gap is allowed for GBR UE in ConfD.
    auto isAutoGapAllowedForGbrUe = [gbrUeSwitch]()
    {
        return (
            gbrUeSwitch == REPORT_CGI_GBR_SWITCH_TYPE_BOTH || gbrUeSwitch == REPORT_CGI_GBR_SWITCH_TYPE_AUTONOMOUS_GAP);
    };

    // Returns true if DRX is allowed for GBR UE in ConfD.
    auto isDrxAllowedForGbrUe = [gbrUeSwitch]()
    { return (gbrUeSwitch == REPORT_CGI_GBR_SWITCH_TYPE_BOTH || gbrUeSwitch == REPORT_CGI_GBR_SWITCH_TYPE_DRX); };

    // Returns true if Autonomous Gap can be used for CGI reporting.
    auto canAutoGapsBeUsed = [ueAutonomousGap, isGbrUe, &isAutoGapAllowedForGbrUe]()
    {
        if (TRUE != ueAutonomousGap)
        {
            return false;
        }
        if (isGbrUe && not isAutoGapAllowedForGbrUe())
        {
            return false;
        }
        return true;
    };

    // Returns true if DRX can be used for CGI reporting.
    auto canDrxBeUsed = [isGbrUe, &isDrxAllowedForGbrUe, &ptCi, &fName]()
    {
        if (isGbrUe && not isDrxAllowedForGbrUe())
        {
            return false;
        }
        // FGR-CC5001 FR237
        // SVR24B FGS-SF0502 FR122 - No ReportCGI If DRX is Off by positioning SRS
        if (IS_DRX_DISABLED_FOR_SRS(ptCi))
        {
            VCCB_PRINT_LOG_ANR(ptCi, "(ANR) [%s] drxDisabledForSRS(%d) drxCuInfo.status(%s) \n", fName,
                IS_DRX_DISABLED_FOR_SRS(ptCi), (ptCi->drxCuInfo.status ? "ON" : "OFF"));
            return false;
        }
        // check the DRX capa
        if (FALSE == VCCM_getUeLongDrxCycleCapa(ptCi, ptCi->servCellNum))
        {
            VCCB_PRINT_LOG_ANR(ptCi, "(ANR) [%s] UE capa does not support long DRX\n", fName);
            return false;
        }
        return true;
    };

    if (not canAutoGapsBeUsed() && not canDrxBeUsed())
    {
        VCCB_PRINT_LOG_ANR(ptCi, "(ANR) Neither AGap nor DRX can be used for CGI reporting.\n");
        return false;
    }

    return true;
}  // }}}

bool FnVCCB_IsSupportUeBasedReportCgiForAnr(callInfo_type *ptCi, uint8_t ratType, uint16_t pci, uint32_t freq)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->servCellNum, MAX_CELL_NUM_VCCB, false);

    uint16_t cellNum = ptCi->servCellNum;

    if (true == FnVCCB_IsReportCgiRunning(ptCi))
    {
        return false;
    }

    // SVR24B FGS-SF0502 FR194
    // 24B Check ANR Target PCI is in CA SCells
    uint8_t foundSCellIdx = 0;
    if (nrType == ratType)
    {
        if (GOOD == VLIB_FindSCellWithPciArfcn(ptCi, pci, freq, RSType_SSB, &foundSCellIdx, FALSE))
        {
            VCCB_PRINT_LOG_ANR(ptCi,
                "(ANR) Not supported UEBasedReportCgi : pci(%u) freq(%u) in Scell(%u)\n", pci, freq, foundSCellIdx);
            return false;
        }
    }

    // get parameter
    const uint8_t ueBasedAnrSwitch = FnVCCB_getUeBasedAnrSwitch(ptCi, cellNum, ratType);
    const uint8_t ueAutonomousGap = FnVCCB_IsSupportUeAutonomousGaps(ptCi, cellNum, ratType);
    const uint8_t ueCgiReporting = (nrType == ratType) ? (uint8_t)FnVCCB_getUeCgiReport(ptCi)
                                                        : (uint8_t)FnVCCB_getUeEutraCgiReport(ptCi);
    const uint8_t reportCgiSwitch = (nrType == ratType) ? (uint8_t)FnVCCB_getReportCgiSwitch(ptCi, cellNum, freq)
                                                        : (uint8_t)FnVCCB_getEutraReportCgiSwitch(ptCi, cellNum);

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    uint8_t gbrUeSwitch = REPORT_CGI_GBR_SWITCH_TYPE_AUTONOMOUS_GAP;
    if (nrType == ratType)
    {
        gbrUeSwitch = (uint8_t)pCell->anrInfo.reportCgiGbrSwitch;
    }
    else
    {
		gbrUeSwitch = (uint8_t)pCell->irat_anrInfo.eutraReportCgiGbrSwitch;
	}

    // check the condition
    return FnVCCB_CheckUeBasedReportCgi(ptCi, ueCgiReporting, ueAutonomousGap, ueBasedAnrSwitch, reportCgiSwitch, gbrUeSwitch);
}  // }}}

int16_t FnVCCB_checkAnrPlmnTranslation(
    uint16_t gnbNum, PLMN_IdentityList_type &pPlmnIdentityList)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);

    struct VccbGnbInfo_type::anrPlmnInfo_s *pAnrPlmn = &GNBINFO[gnbNum].anrPlmnInfo;
    uint8_t nrOfPLMNIdentity = MIN(pPlmnIdentityList.nrofPLMN_Identity, MAX_NUM_PLMN);
    uint8_t plmnIdx = 0;
    uint16_t plmn_Identity_idx = 0;

    // find actualPlmn yang
    for (plmn_Identity_idx = 0; plmn_Identity_idx < nrOfPLMNIdentity; plmn_Identity_idx++)
    {
        if (pPlmnIdentityList.plmn_Identity[plmn_Identity_idx].longId == pAnrPlmn->actPlmn.longId)
        {
            return BREAK;
        }
    }

    // find receivedPlmn yang
    plmn_Identity_idx = 0;
    for (plmnIdx = 0; plmnIdx < MAX_PLMN_INDEX; plmnIdx++)
    {
        if (pPlmnIdentityList.plmn_Identity[plmn_Identity_idx].longId == pAnrPlmn->rcvPlmn[plmnIdx].longId)
        {
            return GOOD;
        }
    }

    return BREAK;
}

bool FnVCCB_getActPlmnSupport(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (ptCi->gnbNum < MAX_GNB_PER_SYS)
    {
        const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
        return pGnb->anrPlmnInfo.plmnTranslationSwitch;
    }

    return false;
}

uint32_t FnVCCB_getActPlmn(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (ptCi->gnbNum < MAX_GNB_PER_SYS)
    {
        const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
        return pGnb->anrPlmnInfo.actPlmn.longId;
    }

    return 0;
}

class ReportCgiPlmnIdInfoHandle
{
public:
    ReportCgiPlmnIdInfoHandle(callInfo_type &rCall, PLMN_IdentityInfoList_type &data, msgNcgiNotifyVccbOsab_type &msg,
        anrCgiFailCause_type &rCause, uint16_t &gnbIdLength) :
        call(rCall),
        plmnIdInfoList(data),
        msgNcgiNotify(msg),
        cause(rCause),
        pGnbIdLength(gnbIdLength),
        isSaTacExist(false),
        m_tac(),
        m_ci(0xFFFFFFFFFFFFFFFF)
    {
        plmnList.clear();
    }
    bool updateCgiInfo();
    const uint16_t PRIMARY_PLMN_IDX = 0;

private:
    callInfo_type &call;
    PLMN_IdentityInfoList_type &plmnIdInfoList;
    msgNcgiNotifyVccbOsab_type &msgNcgiNotify;
    anrCgiFailCause_type &cause;
    uint16_t &pGnbIdLength;
    bool isSaTacExist;
    int32_t m_tac;
    uint64_t m_ci;
    unordered_set<uint32_t> plmnList;

    void addPlmnList(uint32_t longId, uint16_t plmnIdInfoIdx)
    {
        uint16_t &numPlmn = msgNcgiNotify.uNotify.ncgiInfo.ncgi[0].numPlmn;

        if (numPlmn >= MAX_ANR_PLMN || plmnIdInfoIdx >= MAX_ANR_PLMN)
        {
            VCCB_PRINT_CALL_INFORMATIVE(
                &call, "numPlmn(%d), plmnIdInfoIdx(%d) exceeded the MAX_ANR_PLMN(%d)\n", 
                numPlmn, plmnIdInfoIdx, MAX_ANR_PLMN);
            return;
        }

        if (plmnList.find(longId) == plmnList.end())  // duplicate check
        {
            // SVR25B Set SA Availability
            PLMN_IdentityInfo_type &plmnIdInfo = plmnIdInfoList.plmn_IdentityInfo[plmnIdInfoIdx];

            if(isValidTacExistInPlmnIdentityInfo(plmnIdInfo)) // 0: Not available, 1: Available
            { 
                ONBIT_U16(msgNcgiNotify.uNotify.ncgiInfo.saAvailability, numPlmn);
            }

            plmnList.insert(longId);
            msgNcgiNotify.uNotify.ncgiInfo.ncgi[0].plmn[numPlmn++].longId = longId;
        }
    }

    bool isValidTacVal(int32_t tac) { return (tac <= 0 || tac == 0xFFFFFE) ? false : true; }

    bool isValidTacExistInPlmnIdentityInfo(PLMN_IdentityInfo_type plmnIdInfo)
    {
        if (plmnIdInfo.trackingAreaCodeFlag == FALSE) return false;
        return isValidTacVal(static_cast<int32_t>(plmnIdInfo.trackingAreaCode));
    }

    void translation()
    {
        auto &plmnIdInfo = plmnIdInfoList.plmn_IdentityInfo[PRIMARY_PLMN_IDX];

        // Add act plmn
        if (FnVCCB_getActPlmnSupport(&call) &&
            (GOOD == FnVCCB_checkAnrPlmnTranslation(call.gnbNum, plmnIdInfo.plmn_IdentityList)))
        {
            addPlmnList(FnVCCB_getActPlmn(&call), PRIMARY_PLMN_IDX);
        }

        // Add rest of plmns in plmnIdInfo
        for (auto plmnIdx = 0; plmnIdx < plmnIdInfo.plmn_IdentityList.nrofPLMN_Identity; plmnIdx++)
        {
            addPlmnList(plmnIdInfo.plmn_IdentityList.plmn_Identity[plmnIdx].longId, PRIMARY_PLMN_IDX);
        }
    }

    int32_t getFirstSaTac()
    {
        for (auto idx = 0; idx < plmnIdInfoList.nrofPLMN_IdentityInfo; idx++)
        {
            if (m_ci != plmnIdInfoList.plmn_IdentityInfo[idx].cellIdentity) continue;

            if (isValidTacExistInPlmnIdentityInfo(plmnIdInfoList.plmn_IdentityInfo[idx]))
                return static_cast<int32_t>(plmnIdInfoList.plmn_IdentityInfo[idx].trackingAreaCode);
        }
        return -1;
    }

    bool isValidCondition(PLMN_IdentityInfo_type &plmnIdInfo)
    {
        if (m_ci != plmnIdInfo.cellIdentity) return false;

        bool isValidTac = isValidTacExistInPlmnIdentityInfo(plmnIdInfo);

        if (isSaTacExist && isValidTac)
        {
            if (m_tac == static_cast<int32_t>(plmnIdInfo.trackingAreaCode)) return true;

            return false;
        }

        return true;
    }

    void updatePlmnList()
    {
        updatePrimaryPlmn();

        for (uint16_t idx = 0; idx < plmnIdInfoList.nrofPLMN_IdentityInfo; idx++)
        {
            updatePlmnFromPLMNIdentityInfo(idx);
        }
    }

    void updatePlmnFromPLMNIdentityInfo(uint16_t storeIdx)
    {
        PLMN_IdentityInfo_type &plmnIdInfo = plmnIdInfoList.plmn_IdentityInfo[storeIdx];
        if (not isValidCondition(plmnIdInfo)) return;

        // PRIMARY_PLMN will not be stored again by using unordered_set in addPlmnList()
        for (uint16_t plmnIdx = 0; plmnIdx < plmnIdInfo.plmn_IdentityList.nrofPLMN_Identity; plmnIdx++)
        {
            addPlmnList(plmnIdInfo.plmn_IdentityList.plmn_Identity[plmnIdx].longId, storeIdx);
        }
    }

    void updatePrimaryPlmn()
    {
        const auto primaryPlmnId =
            plmnIdInfoList.plmn_IdentityInfo[PRIMARY_PLMN_IDX].plmn_IdentityList.plmn_Identity[PRIMARY_PLMN_IDX].longId;
        addPlmnList(primaryPlmnId, PRIMARY_PLMN_IDX);
    }
};

bool ReportCgiPlmnIdInfoHandle::updateCgiInfo()
{
    cause = acquisitionFailure;

    // update ci, firstSaTac, GnbIdLength
    m_ci = msgNcgiNotify.uNotify.ncgiInfo.ncgi[0].cgi.ci = plmnIdInfoList.plmn_IdentityInfo[0].cellIdentity;
    if (plmnIdInfoList.plmn_IdentityInfo[0].gnbIdLengthFlag == VCCB_FLAG_ON)
    {
        pGnbIdLength = plmnIdInfoList.plmn_IdentityInfo[0].gnbIdLength;
    }
    m_tac = msgNcgiNotify.uNotify.ncgiInfo.ncgi[0].tac = getFirstSaTac();
    isSaTacExist = isValidTacVal(m_tac);

    // SA Availability introduced as of 25B - backward compatibility w/ OSAB
    APPLY_PLMN_SA_AVAILABILITY(msgNcgiNotify.uNotify.ncgiInfo.saAvailability); 

    // Add all plmnId needed
    if (plmnIdInfoList.nrofPLMN_IdentityInfo == 1)
    {
        translation();
    }
    else
    {
        updatePlmnList();
    }

    auto& numPlmn = msgNcgiNotify.uNotify.ncgiInfo.ncgi[0].numPlmn;
    if (numPlmn > 0)
    {
        msgNcgiNotify.uNotify.ncgiInfo.ncgi[0].cgi.plmn = msgNcgiNotify.uNotify.ncgiInfo.ncgi[0].plmn[0];
    }

    return (numPlmn > 0 ? true : false);
}

int16_t FnVCCB_UpdateCGIInfoFromCellAccessRelatedInfo(CellAccessRelatedInfo_EUTRA_EPC_type &mrCgiInfo, anrCgiInfo &cgiInfo)
{
    AUTO_TRACE_FUNC;

    // always ecgiIdx is 0. check only first cgi-info.
    uint8_t numPlmn = MIN(mrCgiInfo.plmn_IdentityList_eutra_epc.nrofPLMN_Identity, MAX_NUM_PLMN_LTE);
    
    if (numPlmn <= 0)
        return ERROR;

    for (uint8_t plmnIdx = 0; plmnIdx < numPlmn; plmnIdx++)
    {
        cgiInfo.plmn[plmnIdx].longId = mrCgiInfo.plmn_IdentityList_eutra_epc.plmn_Identity[plmnIdx].longId;
    }

    cgiInfo.numPlmn = numPlmn;
    cgiInfo.cgi.plmn = cgiInfo.plmn[0];

    cgiInfo.tac = (int32_t)mrCgiInfo.trackingAreaCode_eutra_epc;
    cgiInfo.cgi.ci = mrCgiInfo.cellIdentity_eutra_epc;
    return GOOD;
}

int16_t FnVCCB_GetCgiFromMeasureResultEutra(measResultNeighCellsEUTRA_type *ptMeasResultList2EUTRA, anrCgiInfo &anrCgi)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptMeasResultList2EUTRA);

    if (0 == ptMeasResultList2EUTRA->numReportCell)
    {
        return ERROR;
    }

    // always nbrCellIdx is 0. check only first nbrCellInfo
    const int nbrCellIdx = 0;

    auto &measResultEutra = ptMeasResultList2EUTRA->measResult[nbrCellIdx];

    if (TRUE != measResultEutra.cgiInfoFlag)
    {
        // VCCB_PRINT_LOG_ANR(ptCi, "(ANR) cgi_info is not present(%d)\n", measResultEutra.cgiInfoFlag);
        return ERROR;
    }

    if (TRUE != measResultEutra.cgiInfo.cgi_info_EPC_Flag)
    {
        // VCCB_PRINT_LOG_ANR(
        //     ptCi, "(ANR) cgi_info_EPC is not present(%d)\n", measResultEutra.cgiInfo.cgi_info_EPC_Flag);
        return ERROR;
    }

    CellAccessRelatedInfo_EUTRA_EPC_type *ptMrCgiInfo = &measResultEutra.cgiInfo.cgi_info_EPC.cgi_info_EPC_legacy;

    if (0 == ptMrCgiInfo->plmn_IdentityList_eutra_epc.nrofPLMN_Identity)
    {
        // VCCB_PRINT_LOG_ANR(
        //     ptCi, "(ANR) nrofPLMN_Identity : %d\n", ptMrCgiInfo->plmn_IdentityList_eutra_epc.nrofPLMN_Identity);
        return ERROR;
    }

    if (ERROR == FnVCCB_UpdateCGIInfoFromCellAccessRelatedInfo(*ptMrCgiInfo, anrCgi))
    {
        return ERROR;
    }
    return GOOD;
}  // }}}

int16_t FnVCCB_updateNcgi(callInfo_type *ptCi, measResultList2NR_type *pMeasResultList2NR,
    msgNcgiNotifyVccbOsab_type *pNcgiNoti, anrCgiFailCause_type *pCause, uint16_t *pGnbIdLength)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pMeasResultList2NR, false);
    VALID_E_POINT_CHECK_RET_VAL(pNcgiNoti, false);
    VALID_E_POINT_CHECK_RET_VAL(pCause, false);
    VALID_E_POINT_CHECK_RET_VAL(pGnbIdLength, false);

    // set return value
    pNcgiNoti->uNotify.ncgiInfo.numNrCgi = 0;

    uint8_t maxNumFreq = MIN(pMeasResultList2NR->nrofFreq, MAX_NUM_FREQ);
    uint8_t freqIdx;
    uint32_t usedFreq;
    bool findFlag = false;

    for (freqIdx = 0; freqIdx < maxNumFreq; freqIdx++)
    {
        auto &measResult = pMeasResultList2NR->measResult2NR[freqIdx];

        if (TRUE == measResult.ssbFrequency_Flag && RSType_SSB == ptCi->anrInfo.rsType)
        {
            usedFreq = measResult.ssbFrequency;
        }
        else if (TRUE == measResult.refFreqCSI_RS_Flag && RSType_CSIRS == ptCi->anrInfo.rsType)
        {
            usedFreq = measResult.refFreqCSI_RS;
        }
        else
        {
            continue;
        }

        if (usedFreq != ptCi->anrInfo.freq)
        {
            continue;
        }

        if (0 == measResult.measResultNeighCellListNR.nrofCellReport)
        {
            continue;
        }

        // always nbrCellIdx is 0. check only first nbrCellInfo
        uint8_t nbrCellIdx = 0;
        {
            auto &nbrMeasResult = measResult.measResultNeighCellListNR.measResultNR[nbrCellIdx];

            if (TRUE != nbrMeasResult.cgiInfoFlag || TRUE != nbrMeasResult.physCellIdFlag)
            {
                VCCB_PRINT_LOG_ANR(ptCi, "(ANR) cgiInfo or physCellId is not present(%d/%d)\n",
                    nbrMeasResult.cgiInfoFlag, nbrMeasResult.physCellIdFlag);

                *pCause = acquisitionFailure;
                return ERROR;
            }

            if (nbrMeasResult.physCellId != ptCi->anrInfo.pci)
            {
                VCCB_PRINT_LOG_ANR(ptCi, "(ANR) pci does not match : mr.pci(%d) anrInfo.pci(%d)\n",
                    nbrMeasResult.physCellId, ptCi->anrInfo.pci);

                *pCause = acquisitionFailure;
                return ERROR;
            }

            if (TRUE == nbrMeasResult.cgiInfo.noSIB1_Flag)
            {
                VCCB_PRINT_LOG_ANR(ptCi, "(ANR) cgiInfo.noSIB1_Flag(%d)\n", nbrMeasResult.cgiInfo.noSIB1_Flag);

                *pCause = noSIB1;
                return ERROR;
            }

            if (TRUE != nbrMeasResult.cgiInfo.plmn_IdentityInfoList_Flag)
            {
                VCCB_PRINT_LOG_ANR(ptCi,
                    "(ANR) cgiInfo.plmn_IdentityInfoList_Flag(%d)\n",nbrMeasResult.cgiInfo.plmn_IdentityInfoList_Flag);

                *pCause = acquisitionFailure;
                return ERROR;
            }

            PLMN_IdentityInfoList_type *pPlmnIdentityInfoList = &nbrMeasResult.cgiInfo.plmn_IdentityInfoList;

            if (0 == pPlmnIdentityInfoList->nrofPLMN_IdentityInfo)
            {
                VCCB_PRINT_LOG_ANR(ptCi, "(ANR) nrofPLMN_IdentityInfo:%d\n",
                        pPlmnIdentityInfoList->nrofPLMN_IdentityInfo);

                *pCause = acquisitionFailure;
                return ERROR;
            }

            ReportCgiPlmnIdInfoHandle handle(*ptCi, *pPlmnIdentityInfoList, *pNcgiNoti, *pCause, *pGnbIdLength);
            findFlag = handle.updateCgiInfo();
        }
    }

    if (!findFlag)
    {
        *pCause = acquisitionFailure;
        return ERROR;
    }

    return GOOD;
}

int16_t FnVCCB_getServingCellFromMeasResultList2NR(
    callInfo_type *ptCi, measResultList2NR_type *ptMeasResultList2NR, uint8_t *ptServIdx)
{
    // in case of inter-freq, need to find pcell ([0] : neighCell, [1]~ : servingCell)
    // in case of intra-freq ([0] : neighCell+servingCell)
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMeasResultList2NR);
    VALID_E_POINT_CHECK_ERROR(ptServIdx);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptMeasResultList2NR->nrofFreq, MAX_NUM_FREQ + 1);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];

    uint8_t freqIdx = 0;
    uint16_t cellPci = pCell->phyCellId;
    uint32_t cellFreq = pCell->ssbArfcn;
    measResult2NR_type *ptMeasResult2NR = ptMeasResultList2NR->measResult2NR;

    for (freqIdx = 0; freqIdx < ptMeasResultList2NR->nrofFreq; freqIdx++)
    {
        VCCB_PRINT_LOG_ANR(ptCi, "(ANR) nrofFreq:%d freqIdx:%d ssb:%d pci:%d\n", ptMeasResultList2NR->nrofFreq,
            freqIdx, ptMeasResult2NR[freqIdx].ssbFrequency, ptMeasResult2NR[freqIdx].measResultServingCell.physCellId);

        if (TRUE != ptMeasResult2NR[freqIdx].measResultServingCell_Flag) continue;
        if (TRUE != ptMeasResult2NR[freqIdx].ssbFrequency_Flag) continue;
        if (cellFreq != ptMeasResult2NR[freqIdx].ssbFrequency) continue;
        if (TRUE != ptMeasResult2NR[freqIdx].measResultServingCell.physCellIdFlag) continue;
        if (cellPci != ptMeasResult2NR[freqIdx].measResultServingCell.physCellId) continue;

        *ptServIdx = freqIdx;
        break;
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(*ptServIdx, MAX_NUM_FREQ);
    return GOOD;
}

bool FnVCCB_checkAnrMnsThreshold_withMeasResult(
    callInfo_type *ptCi, uint32_t anrFreq, measResultNR_type *pServResult, measResultNR_type *pNeighResult)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pServResult, false);
    VALID_E_POINT_CHECK_RET_VAL(pNeighResult, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->servCellNum, MAX_CELL_NUM_VCCB, false);
    VccbCellInfo_type *ptCell = &CELLINFO[ptCi->servCellNum];
    measColocCellInfo_type *ptMeasColocCell = &ptCell->measColocInfo;

    int16_t thValue = 0, compValue = 0;
    measQuantityResults_type *ptServQuantity;
    measQuantityResults_type *ptNeighQuantity;

    if (pNeighResult->cellResults.resultsSSB_CellFlag != TRUE)
    {
        VCCB_PRINT_LOG_ANR(ptCi, "(ANR) no ssb result of neighCell\n");
        return false;
    }
    ptNeighQuantity = &pNeighResult->cellResults.resultsSSB_Cell;

    if (ptCell->ssbArfcn == anrFreq)  // Intra-Freq MNS
    {
        if (pServResult->cellResults.resultsSSB_CellFlag != TRUE)
        { /* There is no compare information */
            VCCB_PRINT_LOG_ANR(ptCi, "(ANR) no ssb result of servCell\n");
            return false;
        }
        ptServQuantity = &pServResult->cellResults.resultsSSB_Cell;

        VCCB_PRINT_LOG_ANR(ptCi,
            "(ANR) measThType(%d %d/%d) ServingCell:rsrp/rsrq(%d/%d) NeighCell:rsrp/rsrq(%d/%d)\n",
            ptMeasColocCell->measThresholdTypeAnr, ptMeasColocCell->measRsrpOffsetAnr,
            ptMeasColocCell->measRsrqOffsetAnr, ptServQuantity->rsrpFlag ? ptServQuantity->rsrp : -1,
            ptServQuantity->rsrqFlag ? ptServQuantity->rsrq : -1,
            ptNeighQuantity->rsrpFlag ? ptNeighQuantity->rsrp : -1,
            ptNeighQuantity->rsrqFlag ? ptNeighQuantity->rsrq : -1);

        if (MEAS_TH_RSRP == ptMeasColocCell->measThresholdTypeAnr)
        {
            if (TRUE != ptServQuantity->rsrpFlag || TRUE != ptNeighQuantity->rsrpFlag)
            {
                return false;
            }

            thValue = (int16_t)((int16_t)ptServQuantity->rsrp + ptMeasColocCell->measRsrpOffsetAnr);
            compValue = (int16_t)ptNeighQuantity->rsrp;
        }
        else if (MEAS_TH_RSRQ == ptMeasColocCell->measThresholdTypeAnr)
        {
            if (TRUE != ptServQuantity->rsrqFlag || TRUE != ptNeighQuantity->rsrqFlag)
            {
                return false;
            }

            thValue = (int16_t)((int16_t)ptServQuantity->rsrq + ptMeasColocCell->measRsrqOffsetAnr);
            compValue = (int16_t)ptNeighQuantity->rsrq;
        }

        // For Intra-Freq, compare the max/min value with the rsrp(rsrq) value.
        // if rsrp/rsrq is 127(max value), trigger MNS procedure.
        if (MAX_RSRQ_RSRP_THRESHOLD == compValue)
        {
            return true;
        }
        // if rsrp/rsrq is 0(min value), MR drop.
        if (MIN_RSRQ_RSRP_THRESHOLD == compValue)
        {
            return false;
        }
    }
    else  // Inter-Freq MNS
    {
        VCCB_PRINT_LOG_ANR(ptCi, "(ANR) measThType(%d %d/%d) NeighCell:rsrp/rsrq(%d/%d)\n",
            ptMeasColocCell->measThresholdTypeAnr, ptMeasColocCell->measRsrpThresholdAnr,
            ptMeasColocCell->measRsrqThresholdAnr, ptNeighQuantity->rsrpFlag ? ptNeighQuantity->rsrp : -1,
            ptNeighQuantity->rsrqFlag ? ptNeighQuantity->rsrq : -1);

        if (MEAS_TH_RSRP == ptMeasColocCell->measThresholdTypeAnr)
        {
            if (TRUE != ptNeighQuantity->rsrpFlag)
            {
                return false;
            }

            thValue = ptMeasColocCell->measRsrpThresholdAnr;
            compValue = (int16_t)ptNeighQuantity->rsrp;
        }
        else if (MEAS_TH_RSRQ == ptMeasColocCell->measThresholdTypeAnr)
        {
            if (TRUE != ptNeighQuantity->rsrqFlag)
            {
                return false;
            }

            thValue = ptMeasColocCell->measRsrqThresholdAnr;
            compValue = (int16_t)ptNeighQuantity->rsrq;
        }
        else
        {  // MEAS_TH_DISABLE
            return false;
        }
    }

    if (compValue > thValue)
    {
        return true;
    }

    return false;
}

bool FnVCCB_checkIratAnrMnsThreshold_withMeasResult(callInfo_type *ptCi, measResultEUTRA_type *pNeighResult)
{
    // SVR23A FGS-SF0503 FR20
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pNeighResult, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->servCellNum, MAX_CELL_NUM_VCCB, false);
    VccbCellInfo_type *ptCell = &CELLINFO[ptCi->servCellNum];
    measColocCellInfo_type *ptMeasColocCell = &ptCell->measColocInfo;

    measQuantityResults_type *ptNeighQuantity = NULL;
    ptNeighQuantity = &pNeighResult->measResultEutra;

    VCCB_PRINT_LOG_ANR(ptCi, "(ANR) measThType(%d %d/%d) NeighCell:rsrp/rsrq(%d/%d)\n",
        ptMeasColocCell->measThresholdTypeIratAnr, ptMeasColocCell->measRsrpThresholdIratAnr,
        ptMeasColocCell->measRsrqThresholdIratAnr, ptNeighQuantity->rsrpFlag ? ptNeighQuantity->rsrp : -1,
        ptNeighQuantity->rsrqFlag ? ptNeighQuantity->rsrq : -1);

    if (MEAS_TH_RSRP == ptMeasColocCell->measThresholdTypeIratAnr)
    {
        if (FALSE == ptNeighQuantity->rsrpFlag)
        {
            return false;
        }

        if (ptMeasColocCell->measRsrpThresholdIratAnr < ptNeighQuantity->rsrp)
        {
            return true;
        }
    }
    else if (MEAS_TH_RSRQ == ptMeasColocCell->measThresholdTypeIratAnr)
    {
        if (FALSE == ptNeighQuantity->rsrqFlag)
        {
            return false;
        }

        if (ptMeasColocCell->measRsrqThresholdIratAnr < ptNeighQuantity->rsrq)
        {
            return true;
        }
    }
    else
    {  // MEAS_TH_DISABLE
        return false;
    }

    return false;
}

int16_t FnVCCB_SetReportCgiHandoverAnrInfo(
    callInfo_type *ptCi, uint8_t ratType, uint16_t pci, uint32_t freq)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (RCHO_Type_nonNeighborCell == ptCi->saHoMrQueueInfo.reportCgiHandoverType)
    {
        VCCB_PRINT_CALL_NON_NBR_HO(ptCi, "Set anrInfo for reportCgiNonNeighbor HO !!\n");
        SET_REPORT_CGI_NON_NEIGHBOR(ptCi, VCCB_FLAG_ON);
    }
    else  // RCHO_Type_duplicatePci
    {
        SET_REPORT_CGI_DUPL_PCI(ptCi, VCCB_FLAG_ON);
    }
    SET_REPORT_CGI_FLAG(ptCi, VCCB_FLAG_ON);
    ptCi->anrInfo.ratType = ratType;
    ptCi->anrInfo.pci = pci;
    ptCi->anrInfo.freq = freq;
    ptCi->anrInfo.mrType = anrMrTypeMobility;
    ptCi->anrInfo.rsType = RSType_SSB;

    return GOOD;
}

void FnVCCB_DeactivateReportCgi(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    // FGR-CC5001 FR236 - follow FR221 if CGI reporting timeout occurred.
    if (VCCB_IsEndcSn(*ptCi))
    {
        if ((VCCB_FLAG_ON == GET_REPORT_CGI_FLAG(ptCi)) && (VCCB_FLAG_ON == GET_REPORT_CGI_FAIL_BY_T321(ptCi)) &&
            (VCCB_FLAG_ON == GET_REPORT_CGI_DUPL_PCI(ptCi)))
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "%s: Start PSCell change caused by ReportCGI T321.\n", __FUNCTION__);
            if (GOOD == VCCM_EnqueueActionMr(ptCi, MR_ACTION_PSCELLCHANGE))
            {
                // Do not trigger ReportCGI removal - it will be done during HO measurements reconfiguration.
                return;
            }
        }
    }

    shared_ptr<ReportCgiProcedure> rcHandler =
        FnVCCB_MakeRcHandler(*ptCi, IS_REPORT_CGI_FOR_HANDOVER(ptCi) ? e_REPORT_CGI_HANDOVER : e_REPORT_CGI_ANR);
    rcHandler->deactivate();
}

int16_t FnVCCB_TriggerReportCgiHandover(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    enumAnrObjType ratType = (ptCi->reportCgiHoInfo.relType == INTER_RAT_NB ? eutraType : nrType);
    uint16_t pci = ptCi->reportCgiHoInfo.pci;
    uint32_t freq = ptCi->reportCgiHoInfo.freq;

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Start %s Report CGI Handover ratType:%s, freq:%d, pci:%d \n",
        ptCi->saHoMrQueueInfo.reportCgiHandoverType == RCHO_Type_duplicatePci ? "Duplicate PCI" : "Non-neighbor",
        (ratType == eutraType ? "Inter RAT" : "Intra NR"), freq, pci);

    shared_ptr<ReportCgiProcedure> rcHandler = FnVCCB_MakeRcHandler(*ptCi, e_REPORT_CGI_HANDOVER);
    return rcHandler->activate(ratType, pci, freq, anrMrTypeMobility, RSType_SSB);
}

void FnVCCB_SetReportCgiTimer(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (VCCB_FLAG_OFF == GET_REPORT_CGI_FLAG(ptCi))
    {
        return;
    }

    if (eutraType == ptCi->anrInfo.ratType)
    {
        VLIB_AttachTimer(&ptCi->anrInfo.reportCgiTimer, ptCi, timIRatAnrReportCgi_t321_id);
        VCCB_PRINT_LOG_ANR(ptCi, "(ANR) AttachTimer IRatAnrReportCgi_t321 (id:%u)\n", ptCi->anrInfo.reportCgiTimer.id);
        return;
    }

    if (ptCi->anrInfo.freq < MIN_A6_NR_ARFCN)
    {
        VLIB_AttachTimer(&ptCi->anrInfo.reportCgiTimer, ptCi, timAnrReportCgi_t321Fr1_id);
        VCCB_PRINT_LOG_ANR(ptCi, "(ANR) AttachTimer AnrReportCgi_t321Fr1 (id:%u)\n", ptCi->anrInfo.reportCgiTimer.id);
        return;
    }

    VLIB_AttachTimer(&ptCi->anrInfo.reportCgiTimer, ptCi, timAnrReportCgi_t321Fr2_id);
    VCCB_PRINT_LOG_ANR(ptCi, "(ANR) AttachTimer AnrReportCgi_t321Fr2 (id:%u)\n", ptCi->anrInfo.reportCgiTimer.id);
    return;
}

void FnVCCB_SetReportCgiTimerForNRDC(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!IS_NRDC_MN(ptCi))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not IS_NRDC_MN in %s!\n", __FUNCTION__);
        return;
    }

    if (VCCB_FLAG_OFF == GET_REPORT_CGI_SN_FLAG(ptCi))
    {
        VCCB_PRINT_LOG_ANR(ptCi, "(ANR) Not support(reportCgiSnFlag:false)!\n");
        return;   
    }

    if (ptCi->mrdcInfo.SNInfo[SRC_SN].reportCgi.ssbFrequency < MIN_A6_NR_ARFCN)
    {
        // FR1
        VLIB_AttachTimer(&ptCi->anrInfo.reportCgiTimer, ptCi, timAnrReportCgi_t321Fr1_id);
        return;
    }

    // FR2
    VLIB_AttachTimer(&ptCi->anrInfo.reportCgiTimer, ptCi, timAnrReportCgi_t321Fr2_id);
}

void VIIL_InitReportCgi(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    ptCi->anrInfo.pci = 0;
    ptCi->anrInfo.freq = 0;
    ptCi->anrInfo.longDrxValue = 0;
    ptCi->anrInfo.reportCgi.rcvModRefuseFlag = VCCB_FLAG_OFF;
    SET_REPORT_CGI_FLAG(ptCi, VCCB_FLAG_OFF);
    SET_REPORT_CGI_LONG_DRX_STATUS(ptCi, VCCB_FLAG_OFF);
    SET_REPORT_CGI_STAT_COLLECT_REQUIRED(ptCi, VCCB_FLAG_OFF); // 26A
    VLIB_ConfigDrxCuInfo(ptCi);
}

/**
 * @brief       This function checks whether the reportCgi procedure for SN can be performed
 *              when XN_SnodeModificationRequired is received from NRDC-MN.
 * @details     [FGS-SF0502] Intra-NR ANR
 * @param[in]   ptCi        : pointer to call info
 * @param[out]  status : GOOD  (Trigger ReportCgi For SN on MN)
 *                       BREAK (Do not trigger ReportCgi For SN on MN, send XN_SNodeModificationRefuse)
 *                       ERROR (return ERROR)
 */
int16_t FnVCCB_NrdcMnTriggerReportCgiSn(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_PRINT_LOG_ANR(ptCi,
        "(ANR) ueCtxType:%d reportCgiFlag(MN:%d SN:%d) rcvFlag(reportCgiRequestNr:%d requestedCellInfo:%d)\n",
        ptCi->mrdcInfo.ueCtxType, GET_REPORT_CGI_FLAG(ptCi), GET_REPORT_CGI_SN_FLAG(ptCi),
        IS_ON_MRDC_XN_RCVINDICATOR_FLAG(reportCgiRequestNr), IS_ON_MRDC_XN_RCVINDICATOR_FLAG(requestedCellInfo));

    if (VCCB_FLAG_ON == GET_REPORT_CGI_FLAG(ptCi) || VCCB_FLAG_ON == GET_REPORT_CGI_SN_FLAG(ptCi))
    {
        // Already reportCGI operation is being performed in MN or SN. 
        return BREAK;
    }

    if (!IS_ON_MRDC_XN_RCVINDICATOR_FLAG(requestedCellInfo))
    {
        return BREAK;
    }

    // accept reportCGI
    SET_REPORT_CGI_SN_FLAG(ptCi, VCCB_FLAG_ON);
    return GOOD;
}

// }}}
/****************************************************************************
                REPORT CGI FOR HANDOVER
****************************************************************************/
// {{{
/**
 * @brief Returns CGI reporting mode for GBR UE.
 *        It works for SA and NSA.
 * 
 * @param rCi call info
 * @param rGnbMobCfg gNB mobility config
 * @return uint8_t reportCgiGbrSwitch_type
 */
inline uint8_t VCCB_GetUeBasedCgiReportingForHandoverGbr(
    const callInfo_type &rCi, const gnbMobilityConfig_type &rGnbMobCfg)
{
    return (VCCB_IsEndcSn(rCi) ? rGnbMobCfg.ueBasedCgiReportingForEndcPscellChangeGbr
                               : rGnbMobCfg.ueBasedCgiReportingForHandoverGbr);
}

bool FnVCCB_IsSupportUeBasedReportCgiForMobility(callInfo_type *ptCi, uint8_t ratType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->servCellNum, MAX_CELL_NUM_VCCB, false);
    uint16_t gnbNum = ptCi->gnbNum;
    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, false);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint16_t cellNum = ptCi->servCellNum;
    const uint8_t ueCgiReporting =
        (nrType == ratType) ? (uint8_t)FnVCCB_getUeCgiReport(ptCi) : (uint8_t)FnVCCB_getUeEutraCgiReport(ptCi);
    const uint8_t ueAutonomousGap = (uint8_t)FnVCCB_getUeAutonomousGaps(ptCi, cellNum, ratType);
    const auto ueBasedCgiReportingForHoGbr =
        VCCB_GetUeBasedCgiReportingForHandoverGbr(*ptCi, pGnb->cfg.gnbMobilityConfig);

    return FnVCCB_CheckUeBasedReportCgi(ptCi, ueCgiReporting, ueAutonomousGap, ON, TRUE, ueBasedCgiReportingForHoGbr);
}

/**
 * @brief Returns true if CGI reporting for handover is enabled for a cell.
 *        It works for SA and NSA.
 * 
 * @param rCi call info
 * @param rCell cell info
 * @return true 
 * @return false 
 */
inline bool VCCB_GetUeBasedCgiReportingForHo(const callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    return (VCCB_IsEndcSn(rCi) ? !!rCell.mobilityConfig.ueBasedCgiReportingForEndcPscellChange
                               : !!rCell.mobilityConfig.ueBasedCgiReportingForHo);
}

bool FnVCCB_IsDuplicatedPciReportCgiCondition(callInfo_type *ptCi, uint8_t ratType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->servCellNum, MAX_CELL_NUM_VCCB, false);

    uint16_t cellNum = ptCi->servCellNum;

    if (not VCCB_GetUeBasedCgiReportingForHo(*ptCi, CELLINFO[cellNum]))
    {
        return false;
    }

    return FnVCCB_IsSupportUeBasedReportCgiForMobility(ptCi, ratType);
}

int16_t FnVCCB_FillHandoverInfoFromReportCgiHoInfo(callInfo_type *ptCi, uint16_t candidateNbrIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(candidateNbrIdx, MAX_DUPL_PCI_NBR_PER_CELL);

    saReportCgiHandoverInfo_type *pReportCgiHoInfo = &ptCi->reportCgiHoInfo;

    ptCi->qInfo.qRelType = pReportCgiHoInfo->qRelType[candidateNbrIdx];
    ptCi->qInfo.qTargetCellNum = (uint16_t)pReportCgiHoInfo->qTargetCellNum[candidateNbrIdx];
    ptCi->qInfo.qTargetCellBand = (uint16_t)pReportCgiHoInfo->qTargetCellBand[candidateNbrIdx];
    ptCi->qInfo.qTargetNbrIdx = pReportCgiHoInfo->qTargetNbrIdx[candidateNbrIdx];
    ptCi->hoInfo.selectedTAI = pReportCgiHoInfo->selectedTAI[candidateNbrIdx];
    ptCi->hoInfo.reportConfigQuantitySaHo = pReportCgiHoInfo->reportConfigQuantitySaHo;

    return GOOD;
}

int16_t FnVCCB_SelectTgtCellFromEcgiInfoAndStartHandover(
    callInfo_type *ptCi, measResultNeighCellsEUTRA_type *ptMeasResultList2EUTRA, cgi_type cgi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMeasResultList2EUTRA);

    uint16_t candidateNbrIdx = 0;
    uint16_t gnbNum = ptCi->gnbNum;
    uint16_t cellNum = ptCi->servCellNum;
    uint16_t eutraNbrIdx = MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL;
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    bool findFlag = false;
    uint16_t maxNumCandidate = MIN(ptCi->reportCgiHoInfo.qNumNbr, MAX_DUPL_PCI_NBR_PER_CELL);
    for (candidateNbrIdx = 0; candidateNbrIdx < maxNumCandidate; candidateNbrIdx++)
    {
        nbrEnbCellInfo_type *pNbrEnbCell = NULL;
        eutraNbrIdx = ptCi->reportCgiHoInfo.qTargetNbrIdx[candidateNbrIdx];
        VCCB_CHECK_E_RANGE_AND_CONTINUE(eutraNbrIdx, MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL);

        // find targetCellNum (received cgi)
        if (ERROR == getNbrEnbCellByCellNbrIdx(ptCi->servCellNum, eutraNbrIdx, &pNbrEnbCell))
        {
            continue;
        }
        VCCB_PRINT_CALL_TGT_SEL(ptCi, "enbId:%d cellId:%d ECGI:%d\n", pNbrEnbCell->enbId,
            pNbrEnbCell->cellId, VCCB_GET_ECGI(pNbrEnbCell->enbId, pNbrEnbCell->cellId));

        if ((VCCB_GET_ECGI(pNbrEnbCell->enbId, pNbrEnbCell->cellId) != cgi.ci) ||
            (pNbrEnbCell->plmn.longId != cgi.plmn.longId))
        {
            continue;
        }

        if (ERROR == FnVCCB_FillHandoverInfoFromReportCgiHoInfo(ptCi, candidateNbrIdx))
        {
            continue;
        }

        findFlag = true;
        break;
    }

    if (!findFlag)  // received Target CGI != neighbor
    {
        // end of ReportCGI procedure
        VCCB_PRINT_CALL_TGT_SEL(
            ptCi, "Received ECGI is not nbr(ci:%lu, longId:%d)\n", cgi.ci, cgi.plmn.longId);
        return ERROR;
    }

    // start handover
    VCCB_PRINT_CALL_COMMENT(ptCi, "INTER RAT HO triggered\n");
    auto hoInputDb = StartSaHandoverDb(ptCi->anrInfo.reportType, ptCi->anrInfo.reportPurpose, ptCi->anrInfo.reportConfigQuantitySaHo);
    if (ERROR == VHCM_StartSaHandover_InterRAT(ptCi, eutraNbrIdx, HoPurpose_DLQuality, hoInputDb))
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi, "VHCM_StartSaHandover_InterRAT ERROR\n");
        return ERROR;
    }

    return GOOD;
}

int16_t FnVCCB_FillCGConfigAndStartSaHandoverNrdcSN(callInfo_type *ptCi, uint16_t cellNum,
    measResultList2NR_type *ptMeasResultList2NR, candidateNbrInformation_type *pCand)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMeasResultList2NR);
    VALID_E_POINT_CHECK_ERROR(pCand);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    int16_t status = GOOD;
    if (INTER_NB == ptCi->qInfo.qRelType)
    {
        status = VCCM_FillMeasResultCGConfigInfoForInterNbHo_NrdcSN(cellNum, ptMeasResultList2NR, pCand);
        if (ERROR == status) 
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_FillCGConfigAndStartSaHandoverNrdcSN VCCM_FillMeasResultCGConfigInfoForInterNbHo_NrdcSN ERROR !!\n");
            return ERROR;
        }
    }

    // TODO: need to update MR (CGI information for PS cell change), when cucp select target mr info should be included
    // cgi from neighbor info store Meas Result
    long len = sizeof(ptCi->hoInfo.measResultList2NRPacked);
    status = MakeMsgNRRRC_MeasResultList2NR(ptCi, ptMeasResultList2NR, ptCi->hoInfo.measResultList2NRPacked, &len);
    if (GOOD != status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_FillCGConfigAndStartSaHandoverNrdcSN MakeMsgNRRRC_MeasResultList2NR ERROR !!\n");

        return GOOD;
    }
    ptCi->qInfo.measResultList2NRSize = static_cast<uint16_t>(len);
    ptCi->qInfo.measResult2NRType = CandidateCellInfoList_SN;

    return GOOD;
}

int16_t FnVCCB_FillCGConfigAndStartSaHandoverNrdcSN_CgiInfo(
    callInfo_type *ptCi, uint16_t cellNum, measResultList2NR_type *ptMeasResultList2NR)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMeasResultList2NR);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    int16_t status = GOOD;
    if (INTER_NB == ptCi->qInfo.qRelType)
    {
        status = VCCM_FillMeasResultCGConfigInfoForInterNbHo_Common(
            ptMeasResultList2NR, cellNum, ptCi->qInfo.qTargetNbrIdx, ptCi->reportCgiHoInfo.freqIdx, ptCi->reportCgiHoInfo.pciIdx);
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "FnVCCB_FillCGConfigAndStartSaHandoverNrdcSN_CgiInfo VCCM_FillMeasResultCGConfigInfoForInterNbHo_NrdcSN ERROR "
                "!!\n");
            return ERROR;
        }
    }

    // store Meas Result
    long len = sizeof(ptCi->hoInfo.measResultList2NRPacked);
    status = MakeMsgNRRRC_MeasResultList2NR(ptCi, ptMeasResultList2NR, ptCi->hoInfo.measResultList2NRPacked, &len);
    if (GOOD != status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "MakeMsgNRRRC_MeasResultList2NR ERROR !!\n");

        return GOOD;
    }
    ptCi->qInfo.measResultList2NRSize = static_cast<uint16_t>(len);
    ptCi->qInfo.measResult2NRType = CandidateCellInfoList_SN;

    return GOOD;
}


int16_t FnVCCB_SelectTgtCellFromEcgiInfoAndStartHandover_NewAlgorithm(
    callInfo_type *ptCi, cgi_type cgi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    hoRestrictInfo_type *ptHrl = &THREAD_INFO->call[ptCi->myThreadId].buf.hoRestrictInfo;

    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    candidateNbrList_type candidateCellList;
    candidateCellList.numNbr = 0;
    candidateCellList.maxRank = CANDIDATE_CELL_MAX_RANK;

    // find the cell nbr with cgi
    uint16_t nbrIdx;
    for (nbrIdx = 0; nbrIdx < MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL; nbrIdx++)
    {
        if (N_EQUIP == pCell->eutraNbr[nbrIdx].status) continue;

        cgi_type eCgi;
        if (ERROR == FnVCCB_Fill_CellEutraNbr_ECGI(ptCi->servCellNum, nbrIdx, &eCgi)) continue;
        if (FnVCCB_CheckCgiIdentical(&eCgi, &cgi) == FALSE) continue;
        break;
    }

    if (nbrIdx >= MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL)
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi, "there is no cgi matched nbr (cgi:%lu, longId:%x) \n", cgi.ci, cgi.plmn.longId);
        return ERROR;
    }

    if (FALSE == pCell->eutraNbr[nbrIdx].isHoAllowed)
    {
        VCCB_PRINT_CALL_TGT_SEL(
            ptCi, "call(%d) cell eutraNbr(%d) is not isHoAllowed FALSE\n", ptCi->callId, nbrIdx);
        return ERROR;
    }

    nbrEnbCellInfo_type *ptNbrEnbCell = NULL;
    if (GOOD != getNbrEnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &ptNbrEnbCell))
    {
        return ERROR;
    }

    if (GOOD != VLIB_DecompressHoRestrictInfo(ptCi, ptHrl))
    {
        return ERROR;
    }

    if (GOOD != VCCM_ConditionallyUpdateIdxsOfBestCells_EUTRA(ptCi, nbrIdx,
                ptHrl, &candidateCellList, ptNbrEnbCell))
    {
        return ERROR;
    }

    if (candidateCellList.numNbr > 0)
    {
        auto hoInputDb = StartSaHandoverDb(ptCi->anrInfo.reportType, ptCi->anrInfo.reportPurpose, ptCi->anrInfo.reportConfigQuantitySaHo);
        if (GOOD == VHCM_StartSaHandover_InterRAT(ptCi, nbrIdx, HoPurpose_DLQuality, hoInputDb))
        {
            return GOOD;
        }
    }

    return BREAK;
}

int16_t FnVCCB_SelectTgtCellFromNcgiInfoAndStartHandover_NewAlgorithm(
    callInfo_type *ptCi, measurementObjectUe_type *pMeasObj, cgi_type cgi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMeasObj);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    hoRestrictInfo_type *ptHrl = &THREAD_INFO->call[ptCi->myThreadId].buf.hoRestrictInfo;

    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    nbrGnbCellInfo_type *ptNbrGnbCell = NULL;

    uint32_t usedFreq = ptCi->anrInfo.freq;
    enumHandoverTriggerType hoTrigger = e_HoTrigger_ImmediateHandover;

    candidateNbrList_type candidateCellList;
    candidateCellList.numNbr = 0;
    candidateCellList.maxRank = CANDIDATE_CELL_MAX_RANK;

    uint16_t nbrIdx;
    for (nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)
    {
        if (N_EQUIP == pCell->Nbr[nbrIdx].status) continue;

        cgi_type nbrCgi;
        if (ERROR == FnVCCB_Fill_CellNbr_NRCGI(ptCi->servCellNum, nbrIdx, &nbrCgi)) continue;
        if (FnVCCB_CheckCgiIdentical(&nbrCgi, &cgi) == FALSE) continue;
        break;
    }

    if (nbrIdx >= MAX_NBR_PER_CELL)
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi, "there is no cgi matched nbr (cgi:%lu, longId:%x) \n", cgi.ci, cgi.plmn.longId);
        return ERROR;
    }

    if (FALSE == pCell->Nbr[nbrIdx].isHoAllowed)
    {
        VCCB_PRINT_CALL_TGT_SEL(
            ptCi, "call(%d) cell Nbr(%d) is not isHoAllowed FALSE\n", ptCi->callId, nbrIdx);
        return ERROR;
    }

    if (GOOD != getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &ptNbrGnbCell))
    {
        return ERROR;
    }

    if (GOOD != VLIB_DecompressHoRestrictInfo(ptCi, ptHrl))
    {
        return ERROR;
    }

    int16_t status = VCCM_ConditionallyUpdateIdxsOfBestCells_NR(ptCi, usedFreq, nbrIdx,
        ptHrl, &candidateCellList, &(pMeasObj->conf.rat.nr), hoTrigger, ptNbrGnbCell);

    if (status == HO_BREAK_SPECIFIC_SLICE)
    {
        ptCi->specificSliceForcedHoInfo.forcedMobilityCgiReport = TRUE;
        return ERROR;
    }

    if (status != GOOD)
    {
        return ERROR;
    }

    if (candidateCellList.numNbr > 0)
    {
        uint16_t relType = VCCB_IS_INTRA_GNB_NEIGHBOR(ptCi->servCellNum, nbrIdx) ? INTRA_NB : INTER_NB;
        auto hoInputDb = StartSaHandoverDb(ptCi->anrInfo.reportType, ptCi->anrInfo.reportPurpose, ptCi->anrInfo.reportConfigQuantitySaHo);

        if (GOOD == FnVCCB_StartSaHandover(ptCi, nbrIdx, relType, hoInputDb))
        {
            return GOOD;
        }
    }

    return BREAK;
}

int16_t FnVCCB_SelectTgtCellFromNcgiInfoAndStartHandover(
    callInfo_type *ptCi, measResultList2NR_type *ptMeasResultList2NR, cgi_type cgi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMeasResultList2NR);

    uint16_t candidateNbrIdx = 0;
    uint16_t gnbNum = ptCi->gnbNum;
    uint16_t cellNum = ptCi->servCellNum;
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    bool findFlag = false;
    saReportCgiHandoverInfo_type *pMrInfo = &ptCi->reportCgiHoInfo;
    uint16_t maxNumCandidate = MIN(pMrInfo->qNumNbr, MAX_DUPL_PCI_NBR_PER_CELL);

    for (candidateNbrIdx = 0; candidateNbrIdx < maxNumCandidate; candidateNbrIdx++)
    {
        // find target
        uint16_t relType = pMrInfo->qRelType[candidateNbrIdx];
        cgi_type targetCgi;
        if (relType == INTRA_NB)
        {
            uint16_t targetCellNum = (uint16_t)pMrInfo->qTargetCellNum[candidateNbrIdx];
            VCCB_CHECK_E_RANGE_AND_CONTINUE(targetCellNum, MAX_CELL_NUM_VCCB);
            targetCgi = FnVCCB_GetNrcgiFromCellNum(targetCellNum);
        }
        else
        {
            uint16_t targetNbrIdx = pMrInfo->qTargetNbrIdx[candidateNbrIdx];
            VCCB_CHECK_E_RANGE_AND_CONTINUE(targetNbrIdx, MAX_NBR_PER_CELL);
            if (ERROR == FnVCCB_Fill_CellNbr_NRCGI(cellNum, targetNbrIdx, &targetCgi))
            {
                continue;
            }
        }

        if ((targetCgi.ci != cgi.ci) || (targetCgi.plmn.longId != cgi.plmn.longId))
        {
            continue;
        }

        if (ERROR == FnVCCB_FillHandoverInfoFromReportCgiHoInfo(ptCi, candidateNbrIdx))
        {
            continue;
        }

        findFlag = true;
        break;
    }

    if (!findFlag)  // received Target CGI != neighbor
    {
        // end of ReportCGI procedure
        VCCB_PRINT_CALL_TGT_SEL(
            ptCi, "Received NCGI is not nbr(ci:%lu, longId:%d)\n", cgi.ci, cgi.plmn.longId);
        return ERROR;
    }

    // start handover
    if (IS_NRDC_SN(ptCi))
    {
        if (ERROR == FnVCCB_FillCGConfigAndStartSaHandoverNrdcSN_CgiInfo(ptCi, cellNum, ptMeasResultList2NR))
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi, "FnVCCB_FillCGConfigAndStartSaHandoverNrdcSN ERROR\n");
            return ERROR;
        }

        if (ERROR == FnVCCB_StartSaHandoverSN(ptCi, ptCi->qInfo.qRelType,
                         {ptCi->qInfo.qTargetCellNum, ptCi->qInfo.qTargetCellBand}, ptCi->qInfo.qTargetNbrIdx))
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi, "FnVCCB_StartSaHandoverSN ERROR\n");
            return ERROR;
        }
    }
    else
    {
        uint16_t relType = INTRA_NB;

        if (ERROR == FnVCCB_GetHandoverNbrType(ptCi->servCellNum, ptCi->qInfo.qTargetNbrIdx, &relType))
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi, "FnVCCB_GetHandoverNbrType ERROR\n");
            return ERROR;
        }

        auto hoInputDb = StartSaHandoverDb(ptCi->anrInfo.reportType, ptCi->anrInfo.reportPurpose, ptCi->anrInfo.reportConfigQuantitySaHo);
        if (ERROR == FnVCCB_StartSaHandover(ptCi, ptCi->qInfo.qTargetNbrIdx, relType, hoInputDb))
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi, "FnVCCB_StartSaHandover ERROR\n");
            return ERROR;
        }
    }

    return GOOD;
}

int16_t FnVCCB_SelectTgtCellFromOriginMRInfoAndStartHandover(
    callInfo_type *ptCi, measResultList2NR_type *ptMeasResultList2NR)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMeasResultList2NR);

    uint16_t cellNum = ptCi->servCellNum;
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    candidateNbrList_type candidateCellList;
    candidateCellList.numNbr = 0;
    candidateCellList.maxRank = CANDIDATE_CELL_MAX_RANK;

    candidateCellList.nbrList[0].nbrIdx = ptCi->reportCgiHoInfo.qTargetNbrIdx[0];
    candidateCellList.nbrList[0].selectedTAI = ptCi->reportCgiHoInfo.selectedTAI[0];
    candidateCellList.nbrList[0].freqIdx = ptCi->reportCgiHoInfo.freqIdx;
    candidateCellList.nbrList[0].pciIdx = ptCi->reportCgiHoInfo.pciIdx;

    if (ERROR == FnVCCB_FillHandoverInfoFromReportCgiHoInfo(ptCi, 0))
    {
        return ERROR;
    }

    // start handover
    if (VCCB_IsEndcSn(*ptCi))
    {
        // FGR-CC5001 FR236 - follow FR221 in case of CGI acquisition failure.
        if (INTRA_NB == ptCi->qInfo.qRelType)
        {
            return VHCM_StartHandover(ptCi, {ptCi->qInfo.qTargetCellNum, ptCi->qInfo.qTargetCellBand}, 0);
        }
        else
        {
            return VHCM_StartSgNBChange(ptCi, ptCi->qInfo.qTargetNbrIdx, 0);
        }
    }
    else if (IS_NRDC_SN(ptCi))
    {
        if (ERROR == FnVCCB_FillCGConfigAndStartSaHandoverNrdcSN(ptCi, cellNum, ptMeasResultList2NR, &candidateCellList.nbrList[0]))
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi, "FnVCCB_FillCGConfigAndStartSaHandoverNrdcSN ERROR\n");
            return ERROR;
        }

        if (ERROR == FnVCCB_StartSaHandoverSN(
                         ptCi, ptCi->qInfo.qRelType, {ptCi->qInfo.qTargetCellNum, ptCi->qInfo.qTargetCellBand}, ptCi->qInfo.qTargetNbrIdx))
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi, "FnVCCB_StartSaHandoverSN ERROR\n");
            return ERROR;
        }
    }
    else
    {
        uint16_t relType = INTRA_NB;

        if (ERROR == FnVCCB_GetHandoverNbrType(ptCi->servCellNum, ptCi->qInfo.qTargetNbrIdx, &relType))
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi, "FnVCCB_GetHandoverNbrType ERROR\n");
            return ERROR;
        }

        auto hoInputDb = StartSaHandoverDb(ptCi->anrInfo.reportType, ptCi->anrInfo.reportPurpose, ptCi->anrInfo.reportConfigQuantitySaHo);
        if (ERROR == FnVCCB_StartSaHandover(ptCi, ptCi->qInfo.qTargetNbrIdx, relType, hoInputDb))
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi, "FnVCCB_StartSaHandover ERROR\n");
            return ERROR;
        }
    }

    return GOOD;
}

// }}}
/****************************************************************************
                UPM ( UE Level Ping Pong HO Minimization )
****************************************************************************/
// {{{
upmCellInfo_type *FnVCCB_GetUpmCellInfoDb(callInfo_type *ptCi, uint16_t targetCellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_NULLPTR(ptCi);
    VCCB_CHECK_VALID_CELLNUM_NULL(targetCellNum);
    if (IS_MRDC_SN(ptCi)) return &CELLINFO[targetCellNum].psCellUpmInfo;

    return &CELLINFO[targetCellNum].upmInfo;
}

VCCB_STATIC
const char *VCOM_Print_enumQOffsetRange(enumQOffsetRange e)
{  // {{{
    AUTO_TRACE_FUNC;

    const char *pRet = "?dB";

    switch (e)
    {
        case qOffset_minus_24:
            pRet = "-24dB";
            break;
        case qOffset_minus_22:
            pRet = "-22dB";
            break;
        case qOffset_minus_20:
            pRet = "-20dB";
            break;
        case qOffset_minus_18:
            pRet = "-18dB";
            break;
        case qOffset_minus_16:
            pRet = "-16dB";
            break;
        case qOffset_minus_14:
            pRet = "-14dB";
            break;
        case qOffset_minus_12:
            pRet = "-12dB";
            break;
        case qOffset_minus_10:
            pRet = "-10dB";
            break;
        case qOffset_minus_8:
            pRet = "-8dB";
            break;
        case qOffset_minus_6:
            pRet = "-6dB";
            break;
        case qOffset_minus_5:
            pRet = "-5dB";
            break;
        case qOffset_minus_4:
            pRet = "-4dB";
            break;
        case qOffset_minus_3:
            pRet = "-3dB";
            break;
        case qOffset_minus_2:
            pRet = "-2dB";
            break;
        case qOffset_minus_1:
            pRet = "-1dB";
            break;
        case qOffset_0:
            pRet = "0dB";
            break;
        case qOffset_plus_1:
            pRet = "1dB";
            break;
        case qOffset_plus_2:
            pRet = "2dB";
            break;
        case qOffset_plus_3:
            pRet = "3dB";
            break;
        case qOffset_plus_4:
            pRet = "4dB";
            break;
        case qOffset_plus_5:
            pRet = "5dB";
            break;
        case qOffset_plus_6:
            pRet = "6dB";
            break;
        case qOffset_plus_8:
            pRet = "8dB";
            break;
        case qOffset_plus_10:
            pRet = "10dB";
            break;
        case qOffset_plus_12:
            pRet = "12dB";
            break;
        case qOffset_plus_14:
            pRet = "14dB";
            break;
        case qOffset_plus_16:
            pRet = "16dB";
            break;
        case qOffset_plus_18:
            pRet = "18dB";
            break;
        case qOffset_plus_20:
            pRet = "20dB";
            break;
        case qOffset_plus_22:
            pRet = "22dB";
            break;
        case qOffset_plus_24:
            pRet = "24dB";
            break;
        default:
            break;
    };

    return pRet;
}  // }}}

VCCB_STATIC
int32_t VCOM_InputCIOvalForUPM(int32_t curVal, int32_t minVal, int32_t maxVal)
{  // {{{
    AUTO_TRACE_FUNC;

    curVal = MIN(curVal, maxVal);
    curVal = MAX(curVal, minVal);

    return curVal;
}  // }}}

VCCB_STATIC
int16_t VCOM_CheckHoCauseForUPM(const visitedNrCellInfo_type *ptVisitedNrCell)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptVisitedNrCell);

    // No Cuase is Activie Case
    if (ptVisitedNrCell->hoCausePresent == OPT_NOT_PRESENT) return GOOD;

    // RR(RadioReasons) Cause is Activie Case
    if (ptVisitedNrCell->hoCause == CauseNgapRadioNetworkLayerHandoverDesirableForRadioReasons) return GOOD;

    return ERROR;
}  // }}}

VCCB_STATIC
int16_t VCOM_GetStayTime_NR(shared_ptr<VisitedCell> ptVisited, uint32_t *pPpTime)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptVisited);
    VALID_E_POINT_CHECK_ERROR(pPpTime);

    *pPpTime = ptVisited->getNrStayTime();

    return GOOD;
}  // }}}

int16_t VCOM_GetStayTime_EUTRA(visitedOctetStringCellInfo_type *ptEutraCell, uint32_t *pPpTime)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptEutraCell);
    VALID_E_POINT_CHECK_ERROR(pPpTime);

    LastVisitedEUTRANCellInformation_type visitedEutraCell;
    int status = fnS1AP_UnpackLastVisitedEUTRANCellInformation_type(
        &visitedEutraCell, (char *)ptEutraCell->data, ptEutraCell->numocts);
    if (status != ASN_OK)
    {
        VCCB_PRINT_ERROR("fnS1AP_UnpackLastVisitedEUTRANCellInformation_type Error(%d)!\n", status);
        return ERROR;
    }

    if (visitedEutraCell.m.time_UE_StayedInCell_EnhancedGranularityPresent == OPT_PRESENT)
        *pPpTime = visitedEutraCell.time_UE_StayedInCell_EnhancedGranularity;
    else
        *pPpTime = visitedEutraCell.time_UE_StayedInCell * (uint32_t)10;

    return GOOD;
}  // }}}

VCCB_STATIC
int16_t VCOM_GetStayTime(shared_ptr<VisitedCell> ptVisited, uint32_t *pPpTime)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptVisited);
    VALID_E_POINT_CHECK_ERROR(pPpTime);

    if (ptVisited->getRatType() == ci_nr)
    {
        return VCOM_GetStayTime_NR(ptVisited, pPpTime);
    }
    else if (ptVisited->getRatType() == ci_eutra)
    {
        return VCOM_GetStayTime_EUTRA(ptVisited->getEutraCell(), pPpTime);
    }

    return ERROR;
}  // }}}

VCCB_STATIC
int16_t VCOM_GetHOCauseForMRO_NR(visitedNrCellInfo_type *ptVisitedNrCell, uint16_t *hoCause)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptVisitedNrCell);
    VALID_E_POINT_CHECK_ERROR(hoCause);
    if (ptVisitedNrCell->hoCausePresent == OPT_PRESENT)
    {
        *hoCause = ptVisitedNrCell->hoCause;
        return GOOD;
    }
    else
    {
        return ERROR;
    }
}  // }}}

VCCB_STATIC
int16_t VCOM_GetHOCauseForMRO_EUTRA(
    visitedOctetStringCellInfo_type *ptEutraCell, unsigned short *choice, uint16_t *hoCause)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptEutraCell);
    VALID_E_POINT_CHECK_ERROR(hoCause);

    LastVisitedEUTRANCellInformation_type visitedEutraCell;
    int status = fnS1AP_UnpackLastVisitedEUTRANCellInformation_type(
        &visitedEutraCell, (char *)ptEutraCell->data, ptEutraCell->numocts);
    if (status != ASN_OK)
    {
        VCCB_PRINT_ERROR("fnS1AP_UnpackLastVisitedEUTRANCellInformation_type Error(%d)!\n", status);
        return ERROR;
    }

    if (visitedEutraCell.m.hOCauseValuePresent != OPT_PRESENT)
    {
        VCCB_PRINT_ERROR(
            "VCOM_GetHOCauseForMRO_EUTRA Error : hOCauseValuePresent(%d)!\n", visitedEutraCell.m.hOCauseValuePresent);
        return ERROR;
    }

    *choice = visitedEutraCell.hOCauseValue.choice;

    switch (*choice)
    {
        case S1AP_radioNetwork_chosen:
            *hoCause = visitedEutraCell.hOCauseValue.u.radioNetwork;
            break;

        case S1AP_transport_chosen:
            *hoCause = visitedEutraCell.hOCauseValue.u.transport;
            break;

        case S1AP_nas_chosen:
            *hoCause = visitedEutraCell.hOCauseValue.u.nas;
            break;

        case S1AP_protocol_chosen:
            *hoCause = visitedEutraCell.hOCauseValue.u.protocol;
            break;

        case S1AP_misc_chosen:
            *hoCause = visitedEutraCell.hOCauseValue.u.misc;
            break;

        default:
            break;
    }

    return GOOD;
}  // }}}

VCCB_STATIC
int16_t VCOM_GetHOCauseForMRO(shared_ptr<VisitedCell> ptVisited, unsigned short *choice, uint16_t *hoCause)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptVisited);
    VALID_E_POINT_CHECK_ERROR(hoCause);

    if (ptVisited->getType() == 2) return GOOD;

    if (ptVisited->getRatType() == ci_nr)
    {
        return VCOM_GetHOCauseForMRO_NR(ptVisited->getNrCell(), hoCause);
    }
    else if (ptVisited->getRatType() == ci_eutra)
    {
        return VCOM_GetHOCauseForMRO_EUTRA(ptVisited->getEutraCell(), choice, hoCause);
    }

    return ERROR;
}  // }}}

bool FnVCCB_IsValidVisitedCell(
    callInfo_type *ptCi, shared_ptr<VisitedCell> _addr)
{  // {{{
    if (_addr->getType() == e_UPM_VISITED_PCELL)
    {
        return IS_VALID_VISITED_CELL(ptCi, _addr->getPtr());
    }
    else
    {
        VccbLastVisitedPSCellHandling_type *ptScgUHI = FnVCCB_GetLastVisitedPSCellListDB(ptCi);
        return IS_VALID_VISITED_PS_CELL(ptScgUHI, _addr->getPtr());
    }
}

// This function retrieves the data of ReOrderUeHistoryDB and determines the data normality.
shared_ptr<VisitedCell> VCOM_GetReOrderUeHistoryDB(
    callInfo_type *ptCi, const vector<shared_ptr<VisitedCell>> &vReOrderUeHistoryDB, uint32_t idx)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptCi);

    shared_ptr<VisitedCell> pRes = NULL;

    if (idx < vReOrderUeHistoryDB.size())
    {
        pRes = vReOrderUeHistoryDB.at(idx);

        if (not FnVCCB_IsValidVisitedCell(ptCi, pRes))
        {
            return NULL;
        }

        return pRes;
    }

    VCCB_PRINT_CALL_DATA(
        ptCi, "[UPM] Out Of Range DB (vReOrderUeHistoryDB, Req:%u, Size:%zu)\n", idx, vReOrderUeHistoryDB.size());

    return NULL;
}  // }}}

shared_ptr<VisitedCell> FnVCCB_GetVisitedCellDb(callInfo_type *ptCi, uint16_t ueHistoryIdx)
{
    if(IS_MRDC_SN(ptCi))
    {
        VccbLastVisitedPSCellHandling_type *ptScgUHI = FnVCCB_GetLastVisitedPSCellListDB(ptCi);
        return make_shared<VisitedPSCellInfo>(&ptScgUHI->lastVisitedPSCellList[ueHistoryIdx % MAX_PSCELL_HISTORY_PER_CALL]);
    }

    return make_shared<VisitedCellInfo>(&ptCi->ueHistory.visitedCell[ueHistoryIdx % MAX_VISITED_CELL]);
}

/**
 * @brief This function inserts the serving cell information into the temporary vector for the UE history information.
 * 
 * @param ptCi Pointer to the call information structure.
 * @param tmpDB Temporary vector to store the visited cell information.
 * @param visitedPScell Structure to store the visited PSCell information.
 */
VCCB_STATIC_INLINE
void FnVCCB_InsertUeHistoryInformation_ForServingCell(
    callInfo_type *ptCi,
    vector<shared_ptr<VisitedCell>> &tmpDB)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    // Lambda function to insert the serving entry for the PCell-UPM
    auto InsertPcellServingEntry = [&]()
    {
        // If the pending entry usage flag is set to CI_use, insert it into the temporary vector
        if (ptCi->ueHistory.pendingUeHistoryEntry.usage == CI_use)
        {
            tmpDB.push_back(make_shared<VisitedCellInfo>(&ptCi->ueHistory.pendingUeHistoryEntry));
        }
    };

    // Lambda function to insert the serving entry for the PSCell-UPM
    auto InsertPScellServingEntry = [&]()
    {
        // Get a pointer to the last visited PSCell list database
        VccbLastVisitedPSCellHandling_type *ptScgUHI = FnVCCB_GetLastVisitedPSCellListDB(ptCi);

        // Check if the pointer to the last visited PSCell list database is valid
        if (ptScgUHI == NULL)
        {
            // Log the error and return
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetLastVisitedPSCellListDB Error in %s\n", __func__);
            return;
        }

        ptScgUHI->pendingEntry.clearFlags = 0;

        if (ptScgUHI->u.sn.isPScellStartTimeValid == VCCB_FLAG_ON)
        {
            if (FnVCCB_FillLastVisitedPSCellInformation_CurrentPScell(ptCi, ptScgUHI, &ptScgUHI->pendingEntry) == ERROR)
            {
                // Log the error and return
                VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_FillLastVisitedPSCellInformation_CurrentPScell Error in %s\n", __func__);
                return;
            }
        }

        // If the visitedPScell usage flag is set to CI_use, insert it into the temporary vector
        if (ptScgUHI->pendingEntry.usage == CI_use)
        {
            tmpDB.push_back(make_shared<VisitedPSCellInfo>(&ptScgUHI->pendingEntry));
        }
    };

    // Check if the call is an MRDC SN call
    if (IS_MRDC_SN(ptCi))
    {
        // Insert the serving entry for the PSCell-UPM
        InsertPScellServingEntry();
    }
    else
    {
        // Insert the serving entry for the PCell-UPM
        InsertPcellServingEntry(); // PCell-UPM
    }
}

/**
 * @brief This function is used to insert the entry for the PCell-UPM or PSCell-UPM into the UE history information.
 * 
 * @param ptCi Pointer to the call information.
 * @param tmpDB Temporary vector to store the visited cell information.
 */
VCCB_STATIC_INLINE
void FnVCCB_InsertUeHistoryInformation(
    callInfo_type *ptCi,
    vector<shared_ptr<VisitedCell>> &tmpDB)
{
    // Check if the call information pointer is vali
    VALID_E_POINT_CHECK_VOID(ptCi);

    // Function to insert the entry for the PCell-UPM or PSCell-UPM
    auto InsertList = [&](enumUpmMode_type upmMode)
    {
        uint16_t ueHistIdx = UINT16_MAX;

        // Calculate the maximum number of entries in the NGAP Spec
        const uint16_t MAX_SPEC_ENTRIES =
            static_cast<uint16_t>((upmMode == e_UPM_PCELL) ?
                NGAP_maxnoofCellsinUEHistoryInfo : NGAP_maxnoofPSCellsPerPrimaryCellinUEHistoryInfo);

        // Calculate the maximum number of entries in the UE history database
        const uint16_t MAX_DB_ENTRIES =
            static_cast<uint16_t>((upmMode == e_UPM_PCELL) ? MAX_VISITED_CELL : MAX_PSCELL_HISTORY_PER_CALL);

        // Calculate the maximum number of entries in the UE history database minus 1
        const uint16_t MAX_DB_ENTRIES_MINUS_1 = (MAX_DB_ENTRIES - 1U);

        // Function to get the UE History Index for PCell or PSCell
        auto GetUeHistIdx = [&ptCi, &upmMode]() -> uint16_t
        {
            switch(upmMode)
            {
                case e_UPM_PCELL:
                    return ptCi->ueHistory.lastIdx;

                case e_UPM_PSCELL:
                {
                    VccbLastVisitedPSCellHandling_type *ptScgUHI = FnVCCB_GetLastVisitedPSCellListDB(ptCi);

                    // Check if the pointer to the last visited PSCell list database is valid
                    if (ptScgUHI == NULL)
                    {
                        VCCB_PRINT_CALL_ERROR(ptCi, "ptScgUHI is NULL in InsertList in FnVCCB_InsertUeHistoryInformation\n");
                        return static_cast<uint16_t>(UINT16_MAX);
                    }

                    return ptScgUHI->lastIndex;
                }

                default:
                    VCCB_PRINT_CALL_ERROR(ptCi, "Unknown UpmMode(%u) in InsertList in FnVCCB_InsertUeHistoryInformation\n", upmMode);
                    return static_cast<uint16_t>(UINT16_MAX);
            }
        };

        // Get the UE History Index for PCell or PSCell
        {
            ueHistIdx = GetUeHistIdx();
            if (ueHistIdx == UINT16_MAX)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "GetUeHistIdx failed\n");
                return;
            }

            // Ensure the index is within the range of the UE history database
            ueHistIdx = MIN(ueHistIdx, MAX_DB_ENTRIES_MINUS_1);
        }

        // Iterate through the UE history database
        for (uint16_t idx = 0; idx < MAX_DB_ENTRIES; idx++)
        {
            // Check if the temporary vector has reached its maximum capacity
            if (tmpDB.size() >= MAX_SPEC_ENTRIES) break;

            // Get a shared_ptr to the visited cell information at the current index
            shared_ptr<VisitedCell> ptVisited = FnVCCB_GetVisitedCellDb(ptCi, ueHistIdx);
            if (ptVisited == NULL)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "ptVisited(cur:%u) is not NULL, STOP\n", idx);
                break;
            }

            // Check if the visited cell information at the current index is not in use
            if (ptVisited->getUsage()!= CI_use) break;

            // Checked the Visited Cell Information, but there is an invalid area, so exclude this area and process it.
            if (ptVisited->checkNotAllowedLastVisitedCell() == true) break;

            // Add the visited cell information to the temporary vector
            tmpDB.push_back(ptVisited);

            // Update the index for the next iteration (circular queue operation)
            if (ueHistIdx == 0) ueHistIdx = MAX_DB_ENTRIES_MINUS_1;
            else ueHistIdx--;
        }
    };

    // Check if the call is an MRDC SN call
    if (IS_MRDC_SN(ptCi))
    {
        // Insert the entry for the PSCell-UPM
        InsertList(e_UPM_PSCELL);
    }
    else
    {
        // Insert the entry for the PCell-UPM
        InsertList(e_UPM_PCELL);
    }
}

/**
 * @brief Reorders the UE history information for UPM.
 * 
 * This function reorders the UE history information based on the latest and oldest information. The input is the
 * original UE history information and the output is the reordered UE history information.
 * 
 * @param ptCi Pointer to call information.
 * @param vReOrderUeHistoryDB Reference to the reordered UE history information.
 * @param visitedPScell Reference to the last visited PSCell information.
 * @return int16_t Returns GOOD if successful, ERROR otherwise.
 */
VCCB_STATIC
int16_t VCOM_ReOrderUeHistoryInformationForUPM(
    callInfo_type *ptCi,
    vector<shared_ptr<VisitedCell>> &vReOrderUeHistoryDB)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // 1. Input
    //           latest  Old
    //               v   v
    // | D | C | B | A | F | E |
    //
    //             |
    //             v
    //
    // 2. Output
    //  Old                 latet
    //   v                   v
    // | F | E | D | C | B | A |

    vector<shared_ptr<VisitedCell>> tmpDB;

    // This function checks if it is necessary to refer to
    // the UE History Information based on the current call information.
    auto CheckNeedToReferUeHistoryInformation = [&ptCi]()
    {
        if (IS_MRDC_SN(ptCi)) // PSCell-UPM
        {
            if (FnVCCB_IsPCellChange_ForPSCellInformationInSN(ptCi) == Changed)
            {
                // PCell Change has occurred, so the UE History Information is initialized.
                VCCB_PRINT_CALL_LOG_UPM(ptCi, "[UPM] PCell Change has occurred, so the UE History Information is initialized.\n");

                return false;
            }
            else
            {
                // PCell Change has not occurred, so the existing UE History Information DB is used.
                VCCB_PRINT_CALL_LOG_UPM(ptCi, "[UPM] PCell Change has not occurred, so the existing UE History Information DB is used.\n");

                return true;
            }
        }

        return true; // PCell-UPM
    };

    // 1. Extract Ue History Information (Order and Seq)
    if (CheckNeedToReferUeHistoryInformation() == true)
    {
        if (FnVCCB_IsSaIntraGnbMobilityUE(*ptCi))
        {
            FnVCCB_InsertUeHistoryInformation_ForServingCell(ptCi, tmpDB);
        }

        FnVCCB_InsertUeHistoryInformation(ptCi, tmpDB);
    }

    // 3. Reverse Order
    {
        vReOrderUeHistoryDB.clear();

        // This procedure is to reverse the order of tmpDB. That is, it is rearranged from oldest to newest.
        for (auto it = tmpDB.rbegin(); it != tmpDB.rend(); it++)
        {
            vReOrderUeHistoryDB.push_back(*it);
        }

        VCCB_PRINT_CALL_LOG_UPM(
            ptCi, "[UPM] 1. Reorder Ue History Information size(%zu)\n", vReOrderUeHistoryDB.size());
    }

    return GOOD;
}  // }}}

// This function checks if the UPM is in a suitable state for operation.
VCCB_STATIC
int16_t VCOM_ValidationCheckUeHistoryInformationForUPM(
    callInfo_type *ptCi, vector<shared_ptr<VisitedCell>> &vReOrderUeHistoryDB)
{  // {{{
    int16_t ueHistorySize = 0;

    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    const size_t MAX_OF_UHI_DB = vReOrderUeHistoryDB.size();

    if (vReOrderUeHistoryDB.empty() == true || MAX_OF_UHI_DB == 0)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Ue History Information Data is Empty!! (size: %zu,%d)\n", MAX_OF_UHI_DB, ueHistorySize);
        return BREAK;
    }

    ueHistorySize = (int16_t)(((int16_t)MAX_OF_UHI_DB /*unsign to sign*/) - 1);
    ueHistorySize = MIN(ueHistorySize, (MAX_VISITED_CELL - 1));

    if (ueHistorySize < 0)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Ue History Information Data is Invalid Range!! (size: %zu,%d)\n", MAX_OF_UHI_DB, ueHistorySize);
        return BREAK;
    }

    if (MAX_OF_UHI_DB > MAX_VISITED_CELL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Ue History Information Data Range Over!! (size: %zu,%d, Limit(%d))\n",
            MAX_OF_UHI_DB, ueHistorySize, MAX_VISITED_CELL);
        return BREAK;
    }

    // The same cell overlaps consecutively
    for (int16_t idx = 0; idx < ueHistorySize; idx++)
    {
        shared_ptr<VisitedCell> pCurr = VCOM_GetReOrderUeHistoryDB(ptCi, vReOrderUeHistoryDB, (uint32_t)idx);
        shared_ptr<VisitedCell> pNext = VCOM_GetReOrderUeHistoryDB(ptCi, vReOrderUeHistoryDB, (uint32_t)(idx + 1));

        // Valid Protection
        if (pCurr == NULL || pNext == NULL)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_GetReOrderUeHistoryDB Error (%p(%u), %p(%u))!!\n", pCurr.get(), idx, pNext.get(), idx + 1);
            return BREAK;
        }

        // Compare the same RATs.
        if (pCurr->getRatType() != pNext->getRatType()) continue;

        // NR Cell only.
        if (pCurr->getRatType() != ci_nr) continue;

        // 1st check : Compare the same CGI. ->  The same CGI is continuously configured in UE History.
        // Candidate Error Case : ( Detect : CELL #A -> CELL #A )
        //
        cgi_type currCgi = pCurr->getNrCgi();
        cgi_type nextCgi = pNext->getNrCgi();
        if (FnVCCB_CheckCgiIdentical(&currCgi, &nextCgi) == FALSE) continue;

        // 2nd check : Comapare the target CGI -> If the detected information is not my cell information, ignore it.
        // Ignore Case : ( #B | #A | #A , HandIn Cell is #B) : There is no effect on UPM calculation.
        // Error Case  : ( #A | #B | #B , HandIn Cell is #B) : You cannot determine the priority or algorithm for the
        // same duplicate cell.
        if (FnVCCB_CheckCgiIdentical(&currCgi, &ptCi->upmInfo.upmAlgoInfoNew.targetCgi) == FALSE) continue;

        // This Case is Invalid Case
        VCCB_PRINT_CALL_ERROR(ptCi,
            "Ue History Information Data is invalid! (The same cell overlaps sequentially, %llu/0x%02X/0x%02X)\n",
            1ULL * pCurr->getNrCgi().ci, pCurr->getNrCgi().plmn.s2.mcc, pCurr->getNrCgi().plmn.s2.mnc);

        return BREAK;
    }

    // Check if LastVisitedCell is different from TargetCgi.
    shared_ptr<VisitedCell> pLast = VCOM_GetReOrderUeHistoryDB(ptCi, vReOrderUeHistoryDB, (uint32_t)ueHistorySize);
    if (pLast == NULL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_GetReOrderUeHistoryDB Error!!\n");
        return BREAK;
    }

    if (pLast->getRatType() == ci_nr)
    {
        // It was instructed to handover to the same cell.
        cgi_type cgi = pLast->getNrCgi();
        if (FnVCCB_CheckCgiIdentical(&cgi, &ptCi->upmInfo.upmAlgoInfoNew.targetCgi) == TRUE)
        {
            // This Case is Invalid Case
            VCCB_PRINT_CALL_ERROR(ptCi,
                "Ue History Information Data is invalid! (Same Cell Hand-In, %llu/0x%02X/0x%02X)\n",
                1ULL * pLast->getNrCgi().ci, pLast->getNrCgi().plmn.s2.mcc,
                pLast->getNrCgi().plmn.s2.mnc);
            return BREAK;
        }
    }

    return GOOD;
}  // }}}

// This function extracts only UE History Index, which is the same CGI as the Serving Cell.
VCCB_STATIC
int16_t VCOM_ExtractsLastVisitedCellForUPM(callInfo_type *ptCi, vector<shared_ptr<VisitedCell>> &vReOrderUeHistoryDB,
    vector<int> &vIndexOfServingCell)  // Upm Service Cell of Index Value in vReOrderUeHistoryDB
{                                      // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // 1. Input
    //             serving  serving
    //                v       v
    // CGI      | F | A | D | A | B | C |
    // DB INDEX | 0 | 1 | 2 | 3 | 4 | 5 |
    //
    //             |
    //             v
    //
    // 2. Output
    // | 1 | 3 |

    vIndexOfServingCell.clear();

    const size_t MAX_OF_UHI_DB = vReOrderUeHistoryDB.size();

    for (uint16_t idx = 0; idx < MAX_OF_UHI_DB; idx++)
    {
        shared_ptr<VisitedCell> ptVisited = VCOM_GetReOrderUeHistoryDB(ptCi, vReOrderUeHistoryDB, idx);
        if (ptVisited == NULL)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_GetReOrderUeHistoryDB Error!!\n");
            return ERROR;
        }

        if (ptVisited->getUsage() != CI_use) break;

        if (ptVisited->getRatType() != ci_nr) continue;

        cgi_type cgi = ptVisited->getNrCgi();
        if (FnVCCB_CheckCgiIdentical(&ptCi->upmInfo.upmAlgoInfoNew.targetCgi, &cgi) == FALSE)
            continue;

        vIndexOfServingCell.push_back(idx);
    }

    VCCB_PRINT_CALL_LOG_UPM(
        ptCi, "[UPM] 2. Extract Index of Hand-In Cell History DB size(%zu)\n", vIndexOfServingCell.size());

    return GOOD;
}  // }}}

/*
    This function make decision pingpong with calculating the total time interval of candidate ping Pong Handover for
   MRO. This function have to be executed after executing VCOM_ReOrderUeHistoryInformationForUPM

    'return BREAK' means not PingPong.
    'return ERROR' means there was error while processing Pingpong detection.
     'return GOOD' means PingPong.
*/

VCCB_STATIC
int16_t VCOM_isPingPongHOForMRO(
    callInfo_type *ptCi, const vector<shared_ptr<VisitedCell>> &vReOrderUeHistoryDB, int16_t *pUeHistoryIdx)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    //// TC #1
    // 1. Input
    //                               startIndex (latest cell)
    //                                   v
    // | A | E | A | D | C | B | A | B | C |
    // |NR |NR |NR |LTE|LTE|LTE|NR |LTE|LTE|
    //
    // 2. Output
    //                         |<-   t   ->|
    //                           v
    // | A | E | A | D | C | B | A | B | C |
    // |NR |NR |NR |LTE|LTE|LTE|NR |LTE|LTE|
    // |RR |RR |RR |RR |RR |RR |RR |RR |RR |

    //// TC #2
    // 1. Input
    //                               startIndex (latest cell)
    //                                   v
    // | A | E | A | D | C | B | A | B | C |
    // |NR |NR |NR |LTE|LTE|LTE|LTE|LTE|NR |
    // |RR |RR |RR |RR |RR |RR |RR |RR |RR |
    //
    // 2. Output
    //                               startIndex == endIdx => not pingpong
    //                                   v
    // | A | E | A | D | C | B | A | B | C |
    // |NR |NR |NR |LTE|LTE|LTE|LTE|LTE|NR |
    // |RR |RR |RR |RR |RR |RR |RR |RR |RR |

    //// TC #3
    // 1. Input
    //                               startIndex (latest cell)
    //                                   v
    // | A | E | A | D | C | B | A | B | C |
    // |LTE|LTE|LTE|LTE|LTE|LTE|LTE|LTE|LTE|
    //
    // 2. Output
    //
    // v                                      => not pingpong (there is no NR Cell)
    // | A | E | A | D | C | B | A | B | C |
    // |LTE|LTE|LTE|LTE|LTE|LTE|LTE|LTE|LTE|

    //// TC #4
    // 1. Input
    //                               startIndex (latest cell)
    //                                   v
    // | A | E | A | D | C | B | A | B | C |
    // |NR |NR |NR |LTE|LTE|LTE|NR |LTE|LTE|
    //
    // 2. Output
    //                         |<-   t   ->|
    //                           v           => not pingpong (NR Cell but cause is not RR)
    // | A | E | A | D | C | B | A | B | C |
    // |NR |NR |NR |LTE|LTE|LTE|NR |LTE|LTE|
    // |RR |RR |RR |RR |RR |RR |?? |RR |RR |

    uint32_t totalStayTime = 0;

    int16_t status = GOOD;
    uint32_t stayTime = 0;
    unsigned short choice = 0;
    uint16_t hoCause = 0;
    int16_t ueHistoryIdx = 0;
    int16_t startIndex = 0;
    shared_ptr<VisitedCell> ptVisited;

    const size_t MAX_OF_UHI_DB = vReOrderUeHistoryDB.size();

    if (MAX_OF_UHI_DB == 0) return BREAK;

    startIndex = int16_t((int16_t)MAX_OF_UHI_DB - 1);

    for (ueHistoryIdx = startIndex; ueHistoryIdx >= 0; ueHistoryIdx--)
    {
        ptVisited = VCOM_GetReOrderUeHistoryDB(ptCi, vReOrderUeHistoryDB, (uint32_t)ueHistoryIdx);
        if (ptVisited == NULL)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_GetReOrderUeHistoryDB Error!!\n");
            return ERROR;
        }

        IS_VALID_VISITED_CELL_RETURN(ptCi, ptVisited);

        // If Not Support case, No Ping Pong Handover
        if (ptVisited->getRatType() != ci_nr && ptVisited->getRatType() != ci_eutra)
        {
            if (DBG->flag.logMro)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "[MRO] Detect Inter-RAT Case(%u), This is for information collected so far.\n", ptVisited->getRatType());
            }

            totalStayTime = 0;
            return BREAK;
        }

        if (ptVisited->getRatType() == ci_nr)
        {
            break;  // Range of checking Pingpong : from NR cell to NR cell
        }

        if (GOOD != VCOM_GetHOCauseForMRO(ptVisited, &choice, &hoCause))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_GetHOCauseForMRO Error!!\n");
            return ERROR;
        }

        else if (ptVisited->getRatType() == ci_eutra)
        {
            if (choice != S1AP_radioNetwork_chosen || hoCause != S1AP_handover_desirable_for_radio_reason)
            {
                VCCB_PRINT_CALL_MRO(ptCi, "[MRODBG] Invalid cause in eutra visited cell (start:%d/idx:%d/choice:%d/cause:%d)\n",
                    startIndex, ueHistoryIdx, choice, hoCause);
                return BREAK;
            }
        }

        // Check Stay Time
        status = VCOM_GetStayTime(ptVisited, &stayTime);  // TODO : Change name (VCOM_GetStayTime)
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCOM_GetStayTime ERROR!!\n");

        // Stay Time Range Check
        VCCB_CHECK_E_RANGE_AND_RETURN(stayTime, MAX_VISITED_CELL_STAY_TIME_FOR_NR);

        totalStayTime += stayTime;
    }

    if (ptVisited == NULL)
    {
        return BREAK;
    }

    if ((ueHistoryIdx == startIndex) ||  // case of TC #2 : If last visited cell is NR cell, not pingpong.
        (ueHistoryIdx < 0 &&             // case of TC #3 , TC #4
            ((ptVisited->getRatType() != ci_nr) || (hoCause != CauseNgapRadioNetworkLayerHandoverDesirableForRadioReasons))))
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRODBG] Last visited cell is NR cell or no NR cell has been visited. \n")
        return BREAK;
    }

    if (totalStayTime > GNBINFO[ptCi->gnbNum].iratMroInfo.pingPongIratHoTimer)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRODBG] totalStayTime(%d) > pingPongIratHoTimer(%d)\n",
            totalStayTime, GNBINFO[ptCi->gnbNum].iratMroInfo.pingPongIratHoTimer);
        return BREAK;
    }

    *pUeHistoryIdx = ueHistoryIdx;

    return GOOD;
}  // }}}

/*
    'return BREAK' means not PingPong.
    'return ERROR' means there was error while processing Pingpong detection.
     'return GOOD' means PingPong.
*/
int16_t VCOM_IntersystemPingpongDetection(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (!IS_MRO_ENABLED(MRO_RAT_LTE, ptCi)) return BREAK;

    if (IS_MRDC_SN(ptCi)) return BREAK;

    int16_t status = GOOD;

    vector<shared_ptr<VisitedCell>> vReOrderUeHistoryDB;
    vector<int> vIndexOfServingCell;
    int16_t lastServingNrCellIdx = 0;
    shared_ptr<VisitedCell> ptlastServingNrCell = NULL;
    shared_ptr<VisitedCell> ptPingpongEutraCell = NULL;

    LastVisitedEUTRANCellInformation_type pingpongEutraCell;

    if (ptCi->stateCmd != InterRatHO_cmd)  // Inter system Pingpong have to be Inter RAT HO.
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Inter system Pinpong must be Inter RAT HO.(%d)\n", ptCi->stateCmd);
        return BREAK;
    }

    // This function defines UE History information sequentially.
    status = VCOM_ReOrderUeHistoryInformationForUPM(ptCi, vReOrderUeHistoryDB);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_ReOrderUeHistoryInformationForUPM ERROR!!\n");
        return ERROR;
    }

    if (vReOrderUeHistoryDB.size() <= 1)
    {
        if (DBG->flag.logMro)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[MRO] First Handover UE, It is not Candidate PP HO UE. (size:%d)\n", (int)vReOrderUeHistoryDB.size());
        }
        return BREAK;
    }

    // Check Inter-system pingpong using UE History Information
    status = VCOM_isPingPongHOForMRO(ptCi, vReOrderUeHistoryDB, &lastServingNrCellIdx);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_isPingPongHOForMRO ERROR!\n");
        return ERROR;
    }
    else if (status == BREAK)
    {
        VCCB_PRINT_CALL_MRO(ptCi, "[MRODBG] Not pingpong.\n");
        return status;
    }

    if (status == GOOD)  // pingpong is deteted.
    {
        ptlastServingNrCell = VCOM_GetReOrderUeHistoryDB(ptCi, vReOrderUeHistoryDB, (uint32_t)lastServingNrCellIdx);
        ptPingpongEutraCell = VCOM_GetReOrderUeHistoryDB(ptCi, vReOrderUeHistoryDB, (uint32_t)(lastServingNrCellIdx + 1));

        VALID_E_POINT_CHECK_ERROR(ptlastServingNrCell);
        VALID_E_POINT_CHECK_ERROR(ptPingpongEutraCell);

        if (ptlastServingNrCell->getUsage() != CI_use || ptlastServingNrCell->getRatType() != ci_nr)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "ratType of Last serving NR Cell ERROR!\n");
            return ERROR;
        }
        if (ptPingpongEutraCell->getUsage() != CI_use || ptPingpongEutraCell->getRatType() != ci_eutra)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "ratType of Pingpong Eutra Cell ERROR!\n");
            return ERROR;
        }

        status = (int16_t)fnS1AP_UnpackLastVisitedEUTRANCellInformation_type(&pingpongEutraCell,
            (char *)ptPingpongEutraCell->getEutraCell()->data, ptPingpongEutraCell->getEutraCell()->numocts);
        if (status != ASN_OK)
        {
            VCCB_PRINT_ERROR("fnS1AP_UnpackLastVisitedEUTRANCellInformation_type Error(%d)!\n", status);
            return ERROR;
        }

        //[IRAT MRO] Update MRO DB : UE sourceCellCGI, targetCellCGI, targetCellCGIInEutran
        ptCi->mroInfo.ue.sourceCellCGI = ptlastServingNrCell->getNrCgi();
        ptCi->mroInfo.ue.targetCellCGI = ptCi->nRCGI;
        S1_StorePLMN_Identity(
            &ptCi->mroInfo.ue.targetCellCGIInEutran.plmn, &pingpongEutraCell.global_Cell_ID.pLMNIdentity);
        S1_StoreCellIdentity(&ptCi->mroInfo.ue.targetCellCGIInEutran.ci, &pingpongEutraCell.global_Cell_ID.cell_ID);

        cgi_type cgi =ptlastServingNrCell->getNrCgi();
        if (VLIB_isCellBelongsToGnb(&cgi.plmn,
                &cgi.ci,
                ptCi->gnbNum))  // last serving nr cell from UE histroy Information.
        {
            MACRO_MRO_STAT(STAT_MRO_PER_EUTRA_NBR, PingPongHo_EUTRA, ptCi, &ptCi->mroInfo.ue.sourceCellCGI,
                &ptCi->mroInfo.ue.targetCellCGIInEutran);
        }
        else
        {
            // Send HO Report IE via NG/XN to Last serving NR Cell(using mroInfo.ue.sourceCellCGI).
            ptCi->mroInfo.needPingPongHORpt = TRUE;
        }
    }

    return status;
}

// This function calculates the total time interval of candidate ping Pong Handover.
VCCB_STATIC
int16_t VCOM_GetPingPongTimeForUPM(callInfo_type *ptCi, const vector<shared_ptr<VisitedCell>> &vReOrderUeHistoryDB,
    uint32_t *pTotalStayTime, uint16_t startIndex, uint8_t partialPpTimeFlag)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pTotalStayTime);
    VCCB_CHECK_E_RANGE_AND_RETURN(startIndex, vReOrderUeHistoryDB.size());

    //// TC #1 - partialPpTimeFlag is FALSE
    // 1. Input
    //       startIndex                         Hand-In Cell is 'A'
    //           v
    // | A | E | A | D | C | B | A | B | A |
    // | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
    //
    // 2. Output
    //           | <-- TotalStayTime --> |      <= TotalStayTime is 7.
    //           v                       v
    // | A | E | A | D | C | B | A | B | A |
    // | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |

    //// TC #2 - partialPpTimeFlag is TRUE
    // 1. Input
    //                      startIndex          Hand-In Cell is 'A'
    //                           v
    // | A | E | A | D | C | B | A | B | C |
    // | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
    //
    // 2. Output
    //                             |<- t ->|    <= t is 2. (stop lastIndex)
    //                           v
    // | A | E | A | D | C | B | A | B | C |
    // |   |   |   |   |   |   |   | 1 | 1 |

    //// TC #3 - partialPpTimeFlag is TRUE
    // 1. Input
    //      startIndex                          Hand-In Cell is 'A'
    //           v
    // | A | E | A | D | C | B | A | B | C |
    // | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
    //
    // 2. Output
    //             |<-   t   ->|                <= t is 3. (stop Hand-In CGI)
    //           v               v
    // | A | E | A | D | C | B | A | B | C |
    // |   |   |   | 1 | 1 | 1 |   |   |   |

    *pTotalStayTime = 0;

    int16_t status = GOOD;
    uint32_t stayTime = 0;

    for (uint16_t ueHistoryIdx = startIndex; ueHistoryIdx < vReOrderUeHistoryDB.size(); ueHistoryIdx++)
    {
        shared_ptr<VisitedCell> ptVisited= VCOM_GetReOrderUeHistoryDB(ptCi, vReOrderUeHistoryDB, ueHistoryIdx);
        if (ptVisited == NULL)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_GetReOrderUeHistoryDB Error!!\n");
            return ERROR;
        }
        // IS_VALID_VISITED_CELL_RETURN(ptCi, ptVisited); //TODO:bchanee

        // If Not Support case, No Ping Pong Handover
        if (ptVisited->getRatType() != ci_nr && ptVisited->getRatType() != ci_eutra)
        {
            VCCB_PRINT_CALL_LOG_UPM(ptCi,
                "[UPM] Detect Inter-RAT Case(%u), This is for information collected so far.\n", ptVisited->getRatType());

            *pTotalStayTime = 0;
            return BREAK;
        }

        if (partialPpTimeFlag == TRUE)
        {
            if (ptVisited->getRatType() == ci_nr)
            {
                // Search Complete : Serving(this Point) ~ Serving(ppHandOut_CellIndex)
                cgi_type nrCgi =ptVisited->getNrCgi();
                if (FnVCCB_CheckCgiIdentical(&ptCi->upmInfo.upmAlgoInfoNew.targetCgi, &nrCgi) ==
                    TRUE)
                {
                    if (ueHistoryIdx == startIndex)
                        continue;
                    else
                        break;
                }
            }
        }

        // Check Stay Time
        status = VCOM_GetStayTime(ptVisited, &stayTime);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCOM_GetStayTime ERROR!!\n");

        // Stay Time Range Check
        VCCB_CHECK_E_RANGE_AND_RETURN(stayTime, MAX_VISITED_CELL_STAY_TIME_FOR_NR);

        *pTotalStayTime += stayTime;
    }

    return GOOD;
}  // }}}

VCCB_STATIC
enumQOffsetRange VCOM_GetCIOoffsetForUPM(callInfo_type *ptCi, uint16_t targetCellNum, uint8_t numPingPongHO)
{  // {{{
    AUTO_TRACE_FUNC;

    upmCellInfo_type *p = NULL;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, qOffset_0);  // 0
    VCCB_CHECK_E_RANGE_AND_VAL(targetCellNum, MAX_CELL_NUM_VCCB, qOffset_0);

    p = FnVCCB_GetUpmCellInfoDb(ptCi, targetCellNum);
    VALID_E_POINT_CHECK_RET_VAL(p, qOffset_0);  // 0

    VCCB_CHECK_E_RANGE_AND_VAL(p->hoCount, numPingPongHO + 1, qOffset_0);

    numPingPongHO = MIN(numPingPongHO, MAX_PINGPONG_HO_NBR);

    int32_t retVal = p->cioInitialOffset + (p->cioWeight * (numPingPongHO - p->hoCount));

    retVal = VCOM_InputCIOvalForUPM(retVal, qOffset_minus_24, qOffset_plus_24);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VAL(
        retVal, qOffset_minus_24, qOffset_plus_24, qOffset_minus_24);

    VCCB_PRINT_CALL_LOG_UPM(ptCi, "[UPM] offset(%u) = init(%u) + [ weight(%u) * [ num(%u) - condNum(%u) ] ]\n", retVal,
        p->cioInitialOffset, p->cioWeight, numPingPongHO, p->hoCount);

    return static_cast<enumQOffsetRange>(retVal);
}  // }}}

VCCB_STATIC
int16_t VCOM_CalcCIOForUPM(
    callInfo_type *ptCi, uint16_t targetCellNum, map<upmCgi_type /*ppTargetCell*/, int /*hoCount*/> &mCgiPingPongHoDB)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_VALID_CELLNUM_ERROR(targetCellNum);
    upmCellInfo_type *const pUpmInfo = FnVCCB_GetUpmCellInfoDb(ptCi, targetCellNum);
    VALID_E_POINT_CHECK_ERROR(pUpmInfo);

    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (mCgiPingPongHoDB.empty() == true) return GOOD;

    uint32_t dbIdx = 0;

    // Proc
    for (auto it = mCgiPingPongHoDB.begin(); it != mCgiPingPongHoDB.end(); it++)
    {
        if (dbIdx >= MAX_PINGPONG_HO_NBR) break;

        nbrGnbCellInfo_type *ptGnbNbr = NULL;
        upmPingPongNbr_type *ptUpmNbr = &ptCi->upmInfo.upmAlgoInfoNew.nbr[dbIdx++];

        ptUpmNbr->status = EQUIP;

        // apply only nr cell
        if (it->first.rat != ci_nr) continue;

        ptUpmNbr->cgi = it->first.cgi;
        ptUpmNbr->numPingPongHO = ((uint8_t)MIN(it->second, MAX_PINGPONG_HO_NBR)) & e_BitMask_6bit;

        if (ptUpmNbr->numPingPongHO < pUpmInfo->hoCount) continue;

        ptGnbNbr = getNbrGnbCellByCgiInCellNbr(targetCellNum, ptUpmNbr->cgi);
        if (ptGnbNbr == NULL)
        {
            uint32_t gnbId = VLIB_NrCellId2GnbId(pGnb->globalGnbId.gnbId.idLength, ptUpmNbr->cgi.ci);

            VCCB_PRINT_CALL_LOG_UPM(ptCi, "[UPM] Not Found Neighbor Cell(PLMN:0x%X, ci:%llu, type:%s-GNB)\n",
                ptUpmNbr->cgi.plmn.longId, 1ULL * ptUpmNbr->cgi.ci,
                (gnbId == pGnb->globalGnbId.gnbId.id ? "INTRA" : "INTER"));

            continue;  // Not Found Neighbor Cell
        }

        ptUpmNbr->cioUsage = CI_use;
        ptUpmNbr->cioOffset = VCOM_GetCIOoffsetForUPM(ptCi, targetCellNum, ptUpmNbr->numPingPongHO);
    }

    return GOOD;
}  // }}}

// In this class, Template Methods Pattern is defined for the purpose of removing duplicate codes of BlackList and
// CgiList.
class UpmMapListAbstract
{
protected:
    map<upmCgi_type /*ppTargetCell*/, int /*not used*/> mapList; /* NRCGI, ECGI, ... */

public:
    bool IsExist(upmCgi_type &searchCgi)
    {
        AUTO_TRACE_FUNC;

        auto it_blackList = mapList.find(searchCgi);

        if (IS_STD_MAP_FOUND(it_blackList, mapList))
        {
            return true;
        }

        return false;
    }

    int16_t Add(upmCgi_type &InputCgi, int initValue)
    {
        AUTO_TRACE_FUNC;

        pair<map<upmCgi_type, int>::iterator, bool> pr;

        pr = mapList.insert(pair<upmCgi_type, int /*not used*/>(InputCgi, initValue));

        return (pr.second == false ? ERROR : GOOD);
    }
};

// This class is used to configure the Black List to exclude from the calculation target of the UPM algorithm.
class ConcreteUpmBlackList : public UpmMapListAbstract
{
public:
    int16_t Add(upmCgi_type &InputCgi)
    {
        AUTO_TRACE_FUNC;

        return UpmMapListAbstract::Add(InputCgi, 0);
    }
};

// This class is used to hold information computed by the UPM algorithm.
class ConcreteUpmCgiList : public UpmMapListAbstract
{
public:
    int16_t Add(upmCgi_type &InputCgi)
    {
        AUTO_TRACE_FUNC;

        return UpmMapListAbstract::Add(InputCgi, 1);  // Default 1 Ping Pong
    }

    void IncreaseHandoverCount(upmCgi_type &InputCgi)
    {
        AUTO_TRACE_FUNC;

        auto it = mapList.find(InputCgi);

        it->second++;  // Increase Ping-Pong Handover Count.
    }

    map<upmCgi_type, int> &GetDatabase()
    {
        AUTO_TRACE_FUNC;

        return mapList;
    }
};

// Template Method Pattern
class UpmProcAbstract
{
private:
    bool isNeedToRun = false;

    UpmProcAbstract() {}  // limit default constructor

protected:
    callInfo_type *ptCi = NULL;

public:
    UpmProcAbstract(callInfo_type &refCallInfo)
    {
        AUTO_TRACE_FUNC;
        SetCallInfo(&refCallInfo);
    }

    virtual ~UpmProcAbstract() {}

    bool IsNeedToRun(void)
    {
        AUTO_TRACE_FUNC;
        return isNeedToRun;
    }

    void SetNeedToRun(const char *ptName, bool sw)
    {
        AUTO_TRACE_FUNC;

        VALID_E_POINT_CHECK_VOID(ptName);

        // In the case of a business that does not support UPM, it cannot be turned on. (Always off)
        if (FOO.VF_UPM == FALSE) return;

        VCCB_PRINT_CALL_LOG_UPM(ptCi, "[UPM] change %s from %d to %d.\n", ptName, isNeedToRun, sw);

        isNeedToRun = sw;
    }

    void SetCallInfo(callInfo_type *ptCallInfo)
    {
        AUTO_TRACE_FUNC;
        ptCi = ptCallInfo;
    }

    void DetectUnknownRat()
    {
        AUTO_TRACE_FUNC;
        SetNeedToRun(__func__, false);
    }

    void DetectNotAllowedHandoverCause()
    {
        AUTO_TRACE_FUNC;
        SetNeedToRun(__func__, false);
    }
    
    virtual int16_t execute(bool isPingPongHO, const vector<shared_ptr<VisitedCell>> &vReOrderUeHistoryDB,
        const int HandInCellIdx, const int HandoutCellIdx) = 0;
};

class ConcreteUpmAlgorithm : public UpmProcAbstract {
public:
    ConcreteUpmAlgorithm(callInfo_type &refCallInfo) : UpmProcAbstract::UpmProcAbstract(refCallInfo)
    {
        // UPM : Algorithm follows Cell's settings.
        SetNeedToRun(__func__, IsUpmSupportedCell());
    }
    
    int16_t execute(bool isPingPongHO, const vector<shared_ptr<VisitedCell>> &vReOrderUeHistoryDB,
        const int /*HandInCellIdx*/, const int HandoutCellIdx) override
    {
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(HandoutCellIdx, 0, (int)(vReOrderUeHistoryDB.size() - 1));

        upmCgi_type searchCgi;
        memset(&searchCgi, 0x00, sizeof(searchCgi));

        // Retrieves Last Visitied Cell Information.
        shared_ptr<VisitedCell> ptPreviousCell = VCOM_GetReOrderUeHistoryDB(ptCi, vReOrderUeHistoryDB, (uint32_t)HandoutCellIdx);
        VALID_E_POINT_CHECK_ERROR(ptPreviousCell);

        // It is targeted only when moving from NR Cell to NR CELL.
        if (ptPreviousCell->getRatType() != ci_nr) return GOOD;

        // Fill NRCGI
        searchCgi.rat = ptPreviousCell->getRatType();
        searchCgi.cgi = ptPreviousCell->getNrCgi();

        // It checks whether it is included in the Time Window.
        int16_t status = ProcHoTimeWindow(vReOrderUeHistoryDB, HandoutCellIdx);
        VCCB_RETURN_ON_CALL_ERROR(
            ptCi, status, "ProcHoTimeWindow Error! (%u, %llu)\n", searchCgi.rat, 1ULL * searchCgi.cgi.ci);
        if (status == BREAK) return GOOD;

        // Perform Black List operation.
        status = ProcBlackList(searchCgi, isPingPongHO);
        VCCB_RETURN_ON_CALL_ERROR(
            ptCi, status, "ProcBlackList Error! (%u, %llu)\n", searchCgi.rat, 1ULL * searchCgi.cgi.ci);
        if (status == BREAK) return GOOD;

        // Perform Cgi List operation.
        status = ProcCgiList(searchCgi);
        VCCB_RETURN_ON_CALL_ERROR(
            ptCi, status, "ProcCgiList Error! (%u, %llu)\n", searchCgi.rat, 1ULL * searchCgi.cgi.ci);

        return GOOD;
    }

    void DetectTimeWindowOver()
    {
        AUTO_TRACE_FUNC;
        SetNeedToRun(__func__, false);
    }

    map<upmCgi_type, int> &GetCgiPingPongHoDB()
    {
        AUTO_TRACE_FUNC;
        return cgiList.GetDatabase();
    }

private:
    ConcreteUpmBlackList blackList;
    ConcreteUpmCgiList cgiList;

    // Indicates whether the cell to which the UPM algorithm is applied.
    bool IsUpmSupportedCell()
    {
        AUTO_TRACE_FUNC;

        VCCB_CHECK_E_RANGE_AND_VAL(ptCi->upmInfo.upmAlgoInfoNew.targetCellNum, MAX_CELL_NUM_VCCB, false);

        upmCellInfo_type * pUpmCellInfo = FnVCCB_GetUpmCellInfoDb(ptCi, ptCi->upmInfo.upmAlgoInfoNew.targetCellNum);
        VALID_E_POINT_CHECK_RET_VAL(pUpmCellInfo, false);
        if (pUpmCellInfo->upmSwitch == FALSE) return false;

        return true;
    }

    bool ProcHoTimeWindow(const vector<shared_ptr<VisitedCell>> &vReOrderUeHistoryDB, const int HandoutCellIdx)
    {
        AUTO_TRACE_FUNC;

        VCCB_CHECK_E_RANGE_AND_VAL(ptCi->upmInfo.upmAlgoInfoNew.targetCellNum, MAX_CELL_NUM_VCCB, ERROR);
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(HandoutCellIdx, 0, (int)(vReOrderUeHistoryDB.size() - 1));

        uint32_t sumOfUeStayTime = 0;

        int16_t status = VCOM_GetPingPongTimeForUPM(ptCi, vReOrderUeHistoryDB, &sumOfUeStayTime, (uint16_t)HandoutCellIdx, FALSE);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCOM_GetPingPongTimeForUPM Error!\n");
        upmCellInfo_type * pUpmCellInfo = FnVCCB_GetUpmCellInfoDb(ptCi, ptCi->upmInfo.upmAlgoInfoNew.targetCellNum);
        VALID_E_POINT_CHECK_RET_VAL(pUpmCellInfo, false);

        // Calculation is stopped because Inter-RAT is detected.
        if (status == BREAK)
        {
            DetectUnknownRat();
            return BREAK;
        }

        // If Time-window over, Stop Upm Algorism
        if (sumOfUeStayTime >= pUpmCellInfo->hoTimeWindow)
        {
            DetectTimeWindowOver();
            return BREAK;
        }

        return GOOD;
    }

    int16_t ProcBlackList(upmCgi_type &searchCgi, bool isPingPongHO)
    {
        AUTO_TRACE_FUNC;

        // In case of Black List, this CGI is excluded from the target.
        if (blackList.IsExist(searchCgi))
        {
            // Found on BlackListDB. it is not calculate this CGI any more.
            return BREAK;
        }

        // If Not Ping Pong Handover, Add Black List.
        if (isPingPongHO == false)
        {
            // From the moment when Ping Pong Handover is not detected,
            // it is excluded from the calculation of the UPM algorithm.
            int16_t status = blackList.Add(searchCgi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "Add ERROR !! (rat:%u, ci:%llu plmn:%X/%X)\n", searchCgi.rat,
                1ULL * searchCgi.cgi.ci, searchCgi.cgi.plmn.s2.mcc, searchCgi.cgi.plmn.s2.mnc);

            return BREAK;
        }

        return GOOD;
    }

    int16_t ProcCgiList(upmCgi_type &searchCgi)
    {
        AUTO_TRACE_FUNC;

        // If it is a target that has already been collected, increase the Handover Count.
        if (cgiList.IsExist(searchCgi))
        {
            cgiList.IncreaseHandoverCount(searchCgi);
            return GOOD;
        }

        // If it is not registered, it is newly registered and the Handover Count is collected once.
        return cgiList.Add(searchCgi);
    }
};

class ConcreteUpmStatistics : public UpmProcAbstract
{
public:
    ConcreteUpmStatistics(callInfo_type &refCallInfo) : UpmProcAbstract::UpmProcAbstract(refCallInfo)
    {
        AUTO_TRACE_FUNC;

        // UPM : Statistics should always be provided.
        SetNeedToRun(__func__, true);

        ptStatInfo = &ptCi->upmInfo.upmStatInfo;
    }

    int16_t execute(bool isPingPongHO, const vector<shared_ptr<VisitedCell>> &vReOrderUeHistoryDB,
        const int /*HandInCellIdx*/, const int HandoutCellIdx) override
    {
        AUTO_TRACE_FUNC;

        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(HandoutCellIdx, 0, (int)(vReOrderUeHistoryDB.size() - 1));

        // 1) PingPong 구간?? ?�닐 경우, ?�계 ?�집 ?�작?? 중단?�야 ?�다.
        if (isPingPongHO == false)
        {
            DetectNonConsecutivePingPong();
            return GOOD;
        }

        // Retrieves Last Visitied Cell Information.
        shared_ptr<VisitedCell> ptPreviousCell = VCOM_GetReOrderUeHistoryDB(ptCi, vReOrderUeHistoryDB, (uint32_t)HandoutCellIdx);
        VALID_E_POINT_CHECK_ERROR(ptPreviousCell);

        // 2) ?�계 ?�집 ?�??? Cell?�? NR�?? 지?�한??.
        if (IsCollectStatistics(ptPreviousCell) == false)
        {
            // 1) 최근 PingPong ?�단 구간?? 경우, ?�집?? 불�??��?�?? ?�작?? 중단?�다.
            if (ptCi->upmInfo.upmStatInfo.upmStatFlag == FALSE)
            {
                DetectCollectionCellIsInterRAT();
                return GOOD;
            }

            // 2) 최근 PingPong ?�단 구간?? ?�닌 경우, ?? 구간?�? ?�집 ?�??�이 ?�니므�?? Skip?�다.
            return GOOD;
        }

        int16_t status = ProcStatisitcs(ptPreviousCell, isPingPongHO);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "ProcStatisitcs Error!\n");

        return GOOD;
    }

private:
    upmStatInfoForCall_type *ptStatInfo = NULL;

    void DetectNonConsecutivePingPong()
    {
        AUTO_TRACE_FUNC;
        SetNeedToRun(__func__, false);
    }

    void DetectCollectionCellIsInterRAT()
    {
        AUTO_TRACE_FUNC;
        SetNeedToRun(__func__, false);
    }

    bool IsCollectStatistics(shared_ptr<VisitedCell> ptPreviousCell)
    {
        AUTO_TRACE_FUNC;

        VALID_E_POINT_CHECK_RET_VAL(ptPreviousCell, false);

        // 1) Intra-NR Only : Only NR Cells are subject to statistics collection.
        if (ptPreviousCell->getRatType() != ci_nr)
        {
            // If it is not an NR Cell, it is not subject to statistics collection. No more statistics gathering action
            // is required.
            return false;
        }

        return true;
    }

    void ActiveStatisitcs(shared_ptr<VisitedCell> ptPreviousCell)
    {
        AUTO_TRACE_FUNC;

        VALID_E_POINT_CHECK_VOID(ptPreviousCell);

        ptStatInfo->upmStatFlag = TRUE;
        ptStatInfo->targetCgi = ptPreviousCell->getNrCgi();  // HandOut Cell
        ptStatInfo->numPingPongHO = 1;
        ptStatInfo->upmStoreCellNum = ptCi->upmInfo.upmAlgoInfoNew.targetCellNum;
    }

    void IncreaseStatisitcs(shared_ptr<VisitedCell> ptPreviousCell, bool isPingPongHO)
    {
        AUTO_TRACE_FUNC;

        VALID_E_POINT_CHECK_VOID(ptPreviousCell);

        if (isPingPongHO == false) return;

        cgi_type cgi = ptPreviousCell->getNrCgi();
        if (FnVCCB_CheckCgiIdentical(&ptStatInfo->targetCgi, &cgi) == FALSE) return;

        ptStatInfo->numPingPongHO++;
    }

    int16_t ProcStatisitcs(shared_ptr<VisitedCell> ptPreviousCell, bool isPingPongHO)
    {
        AUTO_TRACE_FUNC;

        VALID_E_POINT_CHECK_ERROR(ptPreviousCell);

        // If it is a target that has already been collected, increase the Handover Count.
        if (ptStatInfo->upmStatFlag == TRUE)
        {
            IncreaseStatisitcs(ptPreviousCell, isPingPongHO);
            return GOOD;
        }

        // If it is not registered, it is newly registered and the Handover Count is collected once.
        ActiveStatisitcs(ptPreviousCell);
        return GOOD;
    }
};
class UpmProcMain  // Main Controller
{
private:
    shared_ptr<ConcreteUpmAlgorithm> algorithm;
    shared_ptr<ConcreteUpmStatistics> statistics;

    uint32_t sumOfUeStayTime = 0;

public:
    UpmProcMain(callInfo_type &refCallInfo)
    {
        algorithm = make_shared<ConcreteUpmAlgorithm>(refCallInfo);
        statistics = make_shared<ConcreteUpmStatistics>(refCallInfo);
    }

    int16_t Proc(callInfo_type *ptCi, const vector<shared_ptr<VisitedCell>> &vReOrderUeHistoryDB,
        const vector<int> &vIndexOfServingCell)
    {
        AUTO_TRACE_FUNC;

        VALID_E_POINT_CHECK_ERROR(ptCi);

        int16_t status = GOOD;

        // rbegin(reverse-begin) and rend(reverse-end) are reverse reference indicators.
        for (auto it = vIndexOfServingCell.rbegin(); it != vIndexOfServingCell.rend(); it++)
        {
            if (algorithm->IsNeedToRun() == false && statistics->IsNeedToRun() == false) break;

            int handInCellIndex = *it;
            int handOutCellIndex = *it + 1;

            status = EachServingCell(ptCi, vReOrderUeHistoryDB, handInCellIndex, handOutCellIndex);
            VCCB_RETURN_ON_CALL_ERROR(
                ptCi, status, "EachServingToServing Error(in: %u, out: %u)!\n", handInCellIndex, handOutCellIndex);
        }

        status = VCOM_CalcCIOForUPM(ptCi, ptCi->upmInfo.upmAlgoInfoNew.targetCellNum, algorithm->GetCgiPingPongHoDB());
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCOM_CalcCIOForUPM Error!\n");

        return GOOD;
    }

    int16_t EachServingCell(callInfo_type *ptCi, const vector<shared_ptr<VisitedCell>> &vReOrderUeHistoryDB,
        const int HandInCellIdx, const int HandoutCellIdx)
    {
        AUTO_TRACE_FUNC;

        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(HandInCellIdx, 0, (int)(vReOrderUeHistoryDB.size() - 1));
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(HandoutCellIdx, 0, (int)(vReOrderUeHistoryDB.size() - 1));

        int16_t status = GOOD;
        bool isPingPongHO = false;

        status = VCOM_GetPingPongTimeForUPM(ptCi, vReOrderUeHistoryDB, &sumOfUeStayTime, (uint16_t)HandoutCellIdx, TRUE);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCOM_GetPingPongTimeForUPM ERROR!!\n");
        if (status == BREAK)  // Detect : Unsupport Inter-RAT(UTRA or GERAN) Ue History Information
        {
            // If there is an unsupported RAT(UTRA or GERAN), the previous history is ignored.
            algorithm->DetectUnknownRat();
            statistics->DetectUnknownRat();
        }
        else
        {
            isPingPongHO = IsPingPongHandover(ptCi, vReOrderUeHistoryDB, HandInCellIdx);
        }

        if (algorithm->IsNeedToRun())
            algorithm->execute(isPingPongHO, vReOrderUeHistoryDB, HandInCellIdx, HandoutCellIdx);

        if (statistics->IsNeedToRun())
            statistics->execute(isPingPongHO, vReOrderUeHistoryDB, HandInCellIdx, HandoutCellIdx);

        return GOOD;
    }

    bool IsPingPongHandover(
        callInfo_type *ptCi, const vector<shared_ptr<VisitedCell>> &vReOrderUeHistoryDB, const int HandInCellIdx)
    {
        AUTO_TRACE_FUNC;

        VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(HandInCellIdx, 0, (int)(vReOrderUeHistoryDB.size() - 1));

        int16_t status = GOOD;

        const shared_ptr<VisitedCell> ptVisitedServCell =
            VCOM_GetReOrderUeHistoryDB(ptCi, vReOrderUeHistoryDB, (uint32_t)HandInCellIdx);
        VALID_E_POINT_CHECK_RET_VAL(ptVisitedServCell, false);

        // 1) Intra-NR Only
        if (ptVisitedServCell->getRatType() != ci_nr) return false;

        if (IS_MRDC_SN(ptCi))
        {
            // if MRDC case, Not used ho cause.
        }
        else
        {
            // 2) Handove Cause : VCOM_CheckHoCauseForUPM
            status = VCOM_CheckHoCauseForUPM(ptVisitedServCell->getNrCell());
            if (status != GOOD)
            {
                algorithm->DetectNotAllowedHandoverCause();
                statistics->DetectNotAllowedHandoverCause();
                return false;
            }
        }

        // 3) StayTime : sumOfUeStayTime <= ptCellUpminfo->hoTimer
        if ((float)sumOfUeStayTime > GetHandoverTimer(ptCi)) return false;

        return true;
    }

    float GetHandoverTimer(callInfo_type *ptCi)
    {
        AUTO_TRACE_FUNC;

        VALID_E_POINT_CHECK_RET_VAL(ptCi, FLT_MIN);
        VCCB_CHECK_E_RANGE_AND_VAL(ptCi->upmInfo.upmAlgoInfoNew.targetCellNum, MAX_CELL_NUM_VCCB, FLT_MIN);
        upmCellInfo_type * upmCellInfo = FnVCCB_GetUpmCellInfoDb(ptCi, ptCi->upmInfo.upmAlgoInfoNew.targetCellNum);
        VALID_E_POINT_CHECK_RET_VAL(upmCellInfo, FLT_MIN);
        return upmCellInfo->hoTimer;
    }
};

/**
 * @brief This function retrieves the cell number and CGI for the given call information.
 * 
 * @param ptCi Pointer to the call information structure.
 * @param pCellNum Pointer to store the retrieved cell number.
 * @param pCgi Pointer to store the retrieved CGI.
 * 
 * @return GOOD if successful, ERROR otherwise.
 */
int16_t FnVCCB_GetCellNumAndCgi_ForUPM(callInfo_type *ptCi, uint16_t *pCellNum, cgi_type *pCgi)
{
    // Check if the input parameters are valid.
    VALID_E_POINT_CHECK_ERROR_PARAM3(ptCi, pCellNum, pCgi);

    // Initialize the cell number variable.
    uint16_t cellNum = ptCi->servCellNum; // the target cell number based on the state command.
    
    switch(ptCi->stateCmd)
    {
        case IntraRatHO_cmd:
            if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
            {
                cellNum = ptCi->hoInfo.targetCellNum;
            }
            break;

        default:
            break;
    }

    // Check if the cell number is within the valid range.
    if (cellNum >= MAX_CELL_NUM_VCCB)
    {
        return ERROR;
    }

    // 1) CellNum
    // Store the retrieved cell number in the output parameter.
    *pCellNum = cellNum;

    // 2) NRCGI
    // Fill the CGI structure with the information from the specified cell.
    FnVCCB_Fill_CellInfo_NRCGI(cellNum, pCgi);

    // Return GOOD to indicate success.
    return GOOD;
}

/**
 * @brief Prepares the UPM data from the call information.
 * 
 * This function initializes the UPM Algorithm Information (New CIO) and UPM Statistics Information for the given call.
 * It also retrieves the target cell number and CGI for UPM using the function FnVCCB_GetCellNumAndCgi_ForUPM.
 * 
 * @param ptCi Pointer to the call information.
 * @return GOOD if successful, ERROR otherwise.
 */
int16_t FnVCCB_PrepareUPMDataFromCall(callInfo_type *ptCi)
{
    // Check if the input pointer is valid.
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    // Initialize UPM Algorithm Information (New CIO)
    FnVCCB_InitUpmAlgoInfo(&ptCi->upmInfo.upmAlgoInfoNew);

    // Initialize UPM Statistics Information
    FnVCCB_InitUpmStatInfo(&ptCi->upmInfo.upmStatInfo);

    // Get Cell Num and CGI for UPM
    status = FnVCCB_GetCellNumAndCgi_ForUPM(ptCi,
        &ptCi->upmInfo.upmAlgoInfoNew.targetCellNum,
        &ptCi->upmInfo.upmAlgoInfoNew.targetCgi);

    // Active UPM Algo Info
    ptCi->upmInfo.upmAlgoInfoNew.usage = (VCCB_FLAG_ON & e_BitMask_1bit);

    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_GetCellNumAndCgi_ForUPM ERROR!!\n");

    return GOOD;
};

/**
 * @brief This function prepares the UPM data from the UE History Information.
 * 
 * @param ptCi Pointer to call information.
 * @param vReOrderUeHistoryDB Vector of shared pointers to visited cells in the reordered UE History Information.
 * @param vIndexOfServingCell Vector of indexes of the serving cell from the reordered UE History Information.
 * @return enumUpmAction_type Returns e_UpmTurnsOffOperation if UPM should be turned off, e_UpmRequiresCalculation if UPM calculation is required, and e_UpmTurnsOffOperation if UPM calculation is not required.
 */
enumUpmAction_type FnVCCB_PrepareUPMDataFromUeHistoryInformation(
    callInfo_type *ptCi,
    vector<shared_ptr<VisitedCell>> &vReOrderUeHistoryDB,
    vector<int> &vIndexOfServingCell)
{
    // Check if the input pointer is valid.
    VALID_E_POINT_CHECK_RET_VAL(ptCi, e_UpmTurnsOffOperation);

    int16_t status = GOOD;

    // Reorder the UE History Information for UPM. (To sequentially)
    status = VCOM_ReOrderUeHistoryInformationForUPM(ptCi, vReOrderUeHistoryDB);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_ReOrderUeHistoryInformationForUPM ERROR!!\n");
        return e_UpmTurnsOffOperation;
    }

    // If it is the first handover, it is not a candidate for Ping Pong handover.
    if (vReOrderUeHistoryDB.size() <= 1)
    {
        VCCB_PRINT_CALL_LOG_UPM(ptCi, "[UPM] Detect!, First Handover UE, It is not Candidate PP HO UE. (size:%d)\n", (int)vReOrderUeHistoryDB.size());

        return e_UpmTurnsOffOperation;
    }

    // Check if the UE History Information is suitable for UPM operation.
    status = VCOM_ValidationCheckUeHistoryInformationForUPM(ptCi, vReOrderUeHistoryDB);
    switch(status)
    {
        default:
        case ERROR:
            VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_ValidationCheckUeHistoryInformationForUPM ERROR!!\n");
            return e_UpmTurnsOffOperation;

        case BREAK:
            VCCB_PRINT_CALL_ERROR(ptCi, "UPM Ignore Ue History Information!! UeHistoryInformation is Invalid!\n");
            return e_UpmTurnsOffOperation;

        case GOOD:
            break;
    }

    // Extract the indexes of the serving cell from the UE History Information.
    status = VCOM_ExtractsLastVisitedCellForUPM(ptCi, vReOrderUeHistoryDB, vIndexOfServingCell);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_ExtractsLastVisitedCellForUPM ERROR!\n");
        return e_UpmTurnsOffOperation;
    }

    // If it is the first hand-in UE for the target cell, no processing is required.
    if (vIndexOfServingCell.size() == 0)
    {
        VCCB_PRINT_CALL_LOG_UPM(
                ptCi, "[UPM] Detect!, First UE that came to servingCell, It is not Candidate PP HO UE.\n");

        return e_UpmTurnsOffOperation;
    }

    return e_UpmRequiresCalculation;
}

/**
 * @brief This function processes UPM for the given call.
 * 
 * @param ptCi Pointer to the call information structure.
 * @return int16_t Returns GOOD if successful, ERROR otherwise.
 */
VCCB_STATIC
int16_t VCOM_ProcUPM(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    vector<shared_ptr<VisitedCell>> vReOrderUeHistoryDB;
    vector<int> vIndexOfServingCell;

    // Prepare
    {
        enumUpmAction_type action;

        status = FnVCCB_PrepareUPMDataFromCall(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_PrepareUPMDataFromCall ERROR!!\n");

        action = FnVCCB_PrepareUPMDataFromUeHistoryInformation(ptCi, vReOrderUeHistoryDB, vIndexOfServingCell);
        if (action != e_UpmRequiresCalculation)
        {
            VCOM_DisableUPM(ptCi);
            return GOOD;
        }
    }

    // Processing
    {
        UpmProcMain proc(*ptCi);

        status = proc.Proc(ptCi, vReOrderUeHistoryDB, vIndexOfServingCell);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCOM_ProcUPM(Class) ERROR!!\n");

        if (ptCi->upmInfo.upmStatInfo.upmStatFlag == TRUE)
        {
            VCCB_PRINT_CALL_LOG_UPM(ptCi, "[%sCell, UPM-STAT] ci=%llu, numPingPongHO=%u, upmStatFlag=%u, upmStoreCellNum=%u\n",
                (IS_MRDC_SN(ptCi) ? "PS" : "P"),
                1ULL * ptCi->upmInfo.upmStatInfo.targetCgi.ci, ptCi->upmInfo.upmStatInfo.numPingPongHO,
                ptCi->upmInfo.upmStatInfo.upmStatFlag, ptCi->upmInfo.upmStatInfo.upmStoreCellNum);
        }

        if (DBG->flag.logUpm) {
            for (uint32_t loop = 0; loop < MAX_PINGPONG_HO_NBR; loop++)
            {
                if (ptCi->upmInfo.upmAlgoInfoNew.nbr[loop].status == N_EQUIP) break;

                VCCB_PRINT_CALL_ERROR(ptCi, "[%sCell, UPM-ALGO] ci=%llu, numPingPongHO=%u, cioUsage=%u, cioOffset=%u\n",
                    (IS_MRDC_SN(ptCi) ? "PS" : "P"),
                    1ULL * ptCi->upmInfo.upmAlgoInfoNew.nbr[loop].cgi.ci,
                    ptCi->upmInfo.upmAlgoInfoNew.nbr[loop].numPingPongHO, ptCi->upmInfo.upmAlgoInfoNew.nbr[loop].cioUsage,
                    ptCi->upmInfo.upmAlgoInfoNew.nbr[loop].cioOffset);
            }
        }
    }

    return GOOD;
}  // }}}

void FnVCCB_InitUpmAlgoInfo(upmAlgoInfoForCall_type *p)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(p);

    memset(p, 0x00, sizeof(upmAlgoInfoForCall_type));  // Clear UPM Info.
    p->targetCellNum = MAX_CELL_NUM_VCCB;
}

void FnVCCB_InitUpmStatInfo(upmStatInfoForCall_type *p)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(p);

    memset(p, 0x00, sizeof(upmStatInfoForCall_type));  // Clear UPM Info.
}

void FnVCCB_CancelUPM(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    FnVCCB_InitUpmAlgoInfo(&ptCi->upmInfo.upmAlgoInfoNew);  // Clear UPM Info (New CIO)
    FnVCCB_InitUpmStatInfo(&ptCi->upmInfo.upmStatInfo);     // Clear UPM Info (Stat)

}  // }}}

void VCOM_DisableUPM(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    FnVCCB_InitUpmAlgoInfo(&ptCi->upmInfo.upmAlgoInfoInstalled);  // Clear UPM Info (Installed CIO)
    FnVCCB_InitUpmAlgoInfo(&ptCi->upmInfo.upmAlgoInfoNew);        // Clear UPM Info (New CIO)
    FnVCCB_InitUpmStatInfo(&ptCi->upmInfo.upmStatInfo);           // Clear UPM Info (Stat)

}  // }}}

/**
 * @brief This function checks the conditions for UPM operation in MN.
 * 
 * @param ptCi Pointer to call information.
 * @return enumUpmAction_type Returns the required UPM action based on the conditions.
 */
VCCB_STATIC_INLINE
enumUpmAction_type FnVCCB_CheckUPMOperationConditions_MN(callInfo_type *ptCi)
{
    // Check if the input pointer is valid
    VALID_E_POINT_CHECK_RET_VAL(ptCi, e_UpmTurnsOffOperation);

    // Rules for UPM operation in MN:
    // The operation of UPM depends on "ptCi->hoInfo".

    // If SA handover is not in progress, UPM is disabled.
    if (VHCM_isSaHandoverUE(ptCi) == FALSE)  
    {
        VCCB_PRINT_CALL_LOG_UPM(ptCi, "[UPM] Disalbed UPM, UPM only works when SA handover is in progress. !!\n");
        return e_UpmTurnsOffOperation; // Disable UPM
    }

    // If the handover type is inter-gNB and the target is not the target gNB, no action.
    if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTER_NB && ptCi->hoInfo.isTarget == FALSE)
    {
        VCCB_PRINT_CALL_LOG_UPM(ptCi, "[UPM] No action, Inter-gNB Source-gNB\n");
        return e_UpmDoesNothing; // no action, Inter-gNB source-gNB
    }

    // If the hand-in cell is not found, no action.
    if (ptCi->hoInfo.targetCellNum >= MAX_CELL_NUM_VCCB)
    {
        VCCB_PRINT_CALL_LOG_UPM(ptCi, "[UPM] No action, Hand-In Cel is Not Found\n");
        return e_UpmDoesNothing;  // no action, target cell not found
    }

    // If the state command is IntraCellHO_cmd, UPM is not allowed.
    if (ptCi->stateCmd == IntraCellHO_cmd)
    {
        VCCB_PRINT_CALL_LOG_UPM(ptCi, "[UPM] No action, Intra-Cell(by Security) Handover\n");
        return e_UpmDoesNothing;  // No action, same cell handover
    }

    // If the hand-in cell is the same cell as the current cell, UPM is not allowed.
    if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
    {
        if (ptCi->servCellNum == ptCi->hoInfo.targetCellNum)
        {
            VCCB_PRINT_CALL_LOG_UPM(ptCi, "[UPM] No action, Intra-Cell(by HO) Handover\n");
            return e_UpmDoesNothing;  // No action, same cell handover
        }
    }

    return e_UpmRequiresCalculation; // UPM can be performed
}

/**
 * @brief This function checks the conditions for performing UPM operations in SN.
 * 
 * @param ptCi: Pointer to callInfo_type structure
 * @return enumUpmAction_type: Returns the required UPM action based on the conditions.
 */
VCCB_STATIC_INLINE
enumUpmAction_type FnVCCB_CheckUPMOperationConditions_SN(callInfo_type *ptCi)
{
    // Check if the input pointer is valid
    VALID_E_POINT_CHECK_RET_VAL(ptCi, e_UpmTurnsOffOperation);

    switch(ptCi->stateCmd)
    {
        // Intra-SN Mobility
        case IntraRatHO_cmd:
            // The operation of UPM in MN is maintained the same, so there is no problem.
            return FnVCCB_CheckUPMOperationConditions_MN(ptCi);

        // Basic Operation, Inter-SN Mobility
        case MrdcXnSNAdd_cmd:
            return e_UpmRequiresCalculation;
        
        // Not Design
        default:
            return e_UpmDoesNothing;
    }
}

/**
 * @brief This function checks the conditions for performing UPM operation based on the call type (MN or SN).
 * 
 * @param ptCi Pointer to call information structure.
 * @return enumUpmAction_type Returns the action to be taken by UPM.
 */
VCCB_STATIC_INLINE
enumUpmAction_type FnVCCB_CheckUPMOperationConditions(callInfo_type *ptCi)
{
    // Check if the input pointer is valid
    VALID_E_POINT_CHECK_RET_VAL(ptCi, e_UpmTurnsOffOperation);

    // Check Feature ON/OFF
    if (FOO.VF_UPM == FALSE)
    {
        return e_UpmDoesNothing;
    }

    /*  In the case of Call Release, if called, the current setting is maintained.
        Recalculation is unnecessary, and there is no need to disable UPM.
        (There is no problem if you upm disable it if necessary.) */
    if (ptCi->bitFlag.startProcessOfReleaseSaCall == VCCB_FLAG_ON)
    {
        /*  In the case of call release, there is an operation to give a response to NG Ue Ctxt Cmd Complete
            using the UE History Information, and in this situation, recalculation occurs.
            Since it is an unnecessary operation, do not process it, and the related feature is 'FGR-MC1001 Paging for NR feature.'. */
        return e_UpmDoesNothing;
    }

    // Determine whether the call is an MN or SN call based on the call type
    if (IS_MRDC_SN(ptCi))
    {
        // If the call is an SN call, call the appropriate function to check UPM operation conditions
        return FnVCCB_CheckUPMOperationConditions_SN(ptCi);
    }

    // If the call is an MN call, call the appropriate function to check UPM operation conditions
    return FnVCCB_CheckUPMOperationConditions_MN(ptCi);
}

/**
 * @brief This function prepares the UE Level Pingpong Minimization for NR (UPM) feature for the given call.
 *        If an error occurs during processing, VCOM_DisableUPM is called.
 * 
 * @param ptCi The pointer to the call information.
 * @return int16_t Returns GOOD if the preparation is successful, ERROR otherwise.
 */
int16_t VCOM_UpdateUPM_Prepare(callInfo_type *ptCi)
{  // {{{

    AUTO_TRACE_FUNC;

    // Check if the input pointer is valid
    VALID_E_POINT_CHECK_ERROR(ptCi);

    // Check the operation conditions for UPM
    switch(FnVCCB_CheckUPMOperationConditions(ptCi))
    {
        // If UPM is disabled due to operation conditions
        default:
        case e_UpmTurnsOffOperation:
        {
            VCCB_PRINT_CALL_LOG_UPM(ptCi, "[UPM] Disabled UPM, Operation Condition\n");
            VCOM_DisableUPM(ptCi);
            return GOOD;
        }

        // If no action is required for UPM
        case e_UpmDoesNothing:
        {
            return GOOD;
        }

        // If UPM requires calculation
        case e_UpmRequiresCalculation:
        {
            int16_t status = VCOM_ProcUPM(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCOM_ProcUPM ERROR!!\n");
            return GOOD;
        }
    }
}  // }}}

int16_t VCOM_UpdateUPM_Finalize(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (ptCi->upmInfo.upmAlgoInfoNew.targetCellNum >= MAX_CELL_NUM_VCCB) return GOOD;

    // Update From 'New' to 'Installed'
    ptCi->upmInfo.upmAlgoInfoInstalled = ptCi->upmInfo.upmAlgoInfoNew;

    // Init New DB
    FnVCCB_InitUpmAlgoInfo(&ptCi->upmInfo.upmAlgoInfoNew);  // Clear UPM Info (New CIO)

    return GOOD;
}  // }}}

VCCB_STATIC
int32_t FnVCCB_GetCIOminForUPM(uint16_t cellNum, const int nbrIdx, const int8_t cioCell, upmCellInfo_type *ptUpmCellInfo)
{
    VALID_E_POINT_CHECK_RET_VAL(ptUpmCellInfo, qOffset_0);

    // if (ptUpmCellInfo->nbrCioMinUsage == TRUE)
    //     CioMin = CioCell(NBR CIO, 0~30) - (maxCioReduction(YANG, 0~30) + min-cio-delta(YANG, -30~0))
    // else
    //     CioMin = CioCell(NBR CIO, 0~30) - maxCioReduction(YANG, 0~30)

    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    //TODO:bchanee
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    int16_t calcCioReduction = ptUpmCellInfo->maxCioReduction;

    // If Yang is On, Apply CIOminDelta
    if (ptUpmCellInfo->nbrCioMinUsage == TRUE && nbrIdx < MAX_NBR_PER_CELL)
    {
        const int8_t cioMinDelta = pCell->Nbr[nbrIdx].cioMinDelta;
        calcCioReduction = (int16_t)VCOM_InputCIOvalForUPM((calcCioReduction + cioMinDelta), qOffset_minus_24, qOffset_plus_24);
    }

    // Calc CioMin
    int32_t cioMin = VCOM_InputCIOvalForUPM((cioCell - calcCioReduction), qOffset_minus_24, qOffset_plus_24);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VAL(
        cioMin, qOffset_minus_24, qOffset_plus_24, static_cast<enumQOffsetRange>(cioCell));

    return cioMin;
}

VCCB_STATIC
enumQOffsetRange VCCB_GetCIOmForUPM(const uint16_t cellNum, const int nbrIdx, const int8_t cioCell,
    upmCellInfo_type *ptUpmCellInfo, const uint8_t cioOffset)
{
    // Calculates relative coordinates based on the cioCell value.
    VALID_E_POINT_CHECK_RET_VAL(ptUpmCellInfo, qOffset_0);

    // 0-1. Check CioCell(NBR CIO, 0 ~ 30)
    // cioCell parameter
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VAL(cioCell, qOffset_minus_24, qOffset_plus_24, qOffset_0);

    // 0-2. Check CioOffset each Nbr(UPM Algorithm, 0~30)
    // cioOffset parameter
    VCCB_CHECK_E_RANGE_AND_VAL(cioOffset, (qOffset_plus_24 + 1), static_cast<enumQOffsetRange>(cioCell));

    // 1. Calc CioMin
    int32_t cioMin = FnVCCB_GetCIOminForUPM(cellNum, nbrIdx, cioCell, ptUpmCellInfo);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VAL(
        cioMin, qOffset_minus_24, qOffset_plus_24, static_cast<enumQOffsetRange>(cioCell));

    // 2. Calc CioM ::= CioCell(NBR CIO, 0 ~ 30) - CioOffset each Nbr(UPM Algorithm, 0~30)
    int32_t cioM = VCOM_InputCIOvalForUPM((cioCell - cioOffset), cioMin, cioCell);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VAL(
        cioM, qOffset_minus_24, qOffset_plus_24, static_cast<enumQOffsetRange>(cioCell));

    return static_cast<enumQOffsetRange>(cioM);
}

VCCB_STATIC
void VCOM_FillCIOmForUPM(callInfo_type *ptCi, const uint16_t cellNum, cellsToMeasInfo_type *pCellToMeas, const upmPingPongNbr_type *ptNbr,
    upmCellInfo_type *ptUpmCellInfo)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM3(ptCi, pCellToMeas, ptNbr);
    VALID_E_POINT_CHECK_VOID(ptUpmCellInfo);

    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    qOffsetSSBRangeList_type *ptOut = &(pCellToMeas->cellIndividualOffset);

#define UPDATE_UPM_CIO(__var) \
    __var = (VCCB_GetCIOmForUPM(cellNum, pCellToMeas->idx, __var, ptUpmCellInfo, ptNbr->cioOffset) & 0x1F)

    UPDATE_UPM_CIO(ptOut->rsrpOffsetSSB);
    UPDATE_UPM_CIO(ptOut->rsrqOffsetSSB);
    UPDATE_UPM_CIO(ptOut->sinrOffsetSSB);
}  // }}}

/* 20C ~ */
// GOOD indicates that CIO is applied.
// BREAK indicates that CIO it not need applied.
// ERROR indicates that Function error.
int16_t VCOM_UpdateCIOmForUPM(callInfo_type *ptCi, cellsToMeasInfo_type *pCellToMeas)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pCellToMeas);

    /* Check UPM Feature Support */
    if (FOO.VF_UPM == FALSE) return BREAK;

    uint16_t targetCellNum = FnVCCB_GetTargetCellNumForUpm(ptCi);
    VCCB_CHECK_VALID_CELLNUM_ERROR(targetCellNum);

    upmAlgoInfoForCall_type *ptUpmAlogoInfo = FnVCCB_GetUpmAlgoInfo(ptCi);
    VALID_E_POINT_CHECK_RET_VAL(ptUpmAlogoInfo, BREAK);

    upmCellInfo_type *ptUpmCellInfo = NULL;
    ptUpmCellInfo = FnVCCB_GetUpmCellInfoDb(ptCi, targetCellNum);
    VALID_E_POINT_CHECK_RET_VAL(ptUpmCellInfo, BREAK);

    /* Check UPM CIO Support */
    if (ptUpmCellInfo->upmSwitch == FALSE) return BREAK;

    // Update CIO Proc
    for (uint32_t idx = 0; idx < MAX_PINGPONG_HO_NBR; idx++)
    {
        upmPingPongNbr_type *ptUpmPpNbr = &ptUpmAlogoInfo->nbr[idx];

        // It consists of a series of EQUIP.
        if (ptUpmPpNbr->status == N_EQUIP) break;

        // It is used only when the CIO needs to be applied.
        if (ptUpmPpNbr->cioUsage == CI_no_use) continue;

        // Check if PLMN + CellIdentity is the same.
        if (FnVCCB_CheckCgiIdentical(&pCellToMeas->cgi, &ptUpmPpNbr->cgi) == FALSE) continue;

        qOffsetSSBRangeList_type prevCio;

        prevCio = pCellToMeas->cellIndividualOffset;

        VCOM_FillCIOmForUPM(ptCi, targetCellNum, pCellToMeas, ptUpmPpNbr, ptUpmCellInfo);

        VCCB_PRINT_CALL_LOG_UPM(ptCi, "[UPM] Apply CIO!! (Pci=%u, OffsetSSB=%s/%s/%s -> OffsetSSB=%s/%s/%s)!\n",
            pCellToMeas->pci,
            VCOM_Print_enumQOffsetRange((enumQOffsetRange)prevCio.rsrpOffsetSSB),
            VCOM_Print_enumQOffsetRange((enumQOffsetRange)prevCio.rsrqOffsetSSB),
            VCOM_Print_enumQOffsetRange((enumQOffsetRange)prevCio.sinrOffsetSSB),
            VCOM_Print_enumQOffsetRange((enumQOffsetRange)pCellToMeas->cellIndividualOffset.rsrpOffsetSSB),
            VCOM_Print_enumQOffsetRange((enumQOffsetRange)pCellToMeas->cellIndividualOffset.rsrqOffsetSSB),
            VCOM_Print_enumQOffsetRange((enumQOffsetRange)pCellToMeas->cellIndividualOffset.sinrOffsetSSB));

        return GOOD;  // GOOD indicates that CIO is applied.
    }

    return BREAK;  // BREAK indicates that CIO it not need applied.
}  // }}}

int16_t FnVCCB_IsAppliedUpmCioToNbr(callInfo_type *ptCi, cgi_type *pSearchCgi, upmAlgoInfoForCall_type *ptDB)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(pSearchCgi);
    VALID_E_POINT_CHECK_FALSE(ptDB);

    // Update  CIO Proc
    for (uint32_t idx = 0; idx < MAX_PINGPONG_HO_NBR; idx++)
    {
        upmPingPongNbr_type *ptUpmPpNbr = &ptDB->nbr[idx];

        // It consists of a series of EQUIP.
        if (ptUpmPpNbr->status == N_EQUIP) break;

        // It is used only when the CIO needs to be applied.
        if (ptUpmPpNbr->cioUsage == CI_no_use) continue;

        // Check if PLMN + CellIdentity is the same.
        if (FnVCCB_CheckCgiIdentical(pSearchCgi, &ptUpmPpNbr->cgi) == TRUE)
        {
            return TRUE;
        }
    }

    return FALSE;
}

void FnVCCB_libStatUpmRlf_ForMRO(callInfo_type *ptCi, int mType, cgi_type *pSrcCgi, cgi_type *pTgtCgi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pSrcCgi);
    VALID_E_POINT_CHECK_VOID(pTgtCgi);

    if (FOO.VF_UPM == FALSE)
    {
        return;
    }

    STAT_UPM_RLF_NR_ITEM stat = UpmHoOutAtt_NR;
    cgi_type targetKey = *pTgtCgi;  // Default is Target CGI.

    switch (mType)
    {
        // TooLate, RRE occurs befre HO.
        case TooLateHoRlfBeforeTriggering:
            stat = TooLateHoRlfBeforeTriggeringUpm_NR;
            break;
        case TooLateHoRlfAfterTriggering:
            stat = TooLateHoRlfAfterTriggeringUpm_NR;
            break;

        // HoToWrong, RRE occurs after HO.
        case HoToWrongCellRlfAfterHoOther:
            stat = HoToWrongCellRlfAfterHoOtherUpm_NR;
            targetKey = ptCi->mroInfo.ue.targetCellCGI;
            break;
        case HoToWrongCellHofOther:
            stat = HoToWrongCellHofOtherUpm_NR;
            targetKey = ptCi->mroInfo.ue.targetCellCGI;
            break;

        default:
            return;
    }

    if (FnVCCB_IsAppliedUpmCioToNbr(ptCi, &targetKey, &ptCi->mroInfo.upmAlgoInfoInstalled) == FALSE)
    {
        return;
    }

    MACRO_STAT_PMCC(STAT_UPM_RLF_NR, stat, ptCi, pSrcCgi->ci, pTgtCgi->ci, (int)pTgtCgi->plmn.longId, 0, 0);
}

void FnVCCB_libStatUpmRlf_ForHO(callInfo_type *ptCi, enumHoStatType mType, cgi_type *pSrcCgi, cgi_type *pTgtCgi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pSrcCgi);
    VALID_E_POINT_CHECK_VOID(pTgtCgi);

    if (FOO.VF_UPM == FALSE)
    {
        return;
    }

    if (ptCi->hoInfo.hoType.rat != HO_TYPE_INTRA_RAT)
    {
        return;
    }

    STAT_UPM_RLF_NR_ITEM stat = UpmHoOutAtt_NR;
    switch (mType)
    {
        case HO_Att:
            stat = UpmHoOutAtt_NR;
            break;
        case HO_PrepSucc:
            stat = UpmHoOutPrepSucc_NR;
            break;
        case HO_Succ:
            stat = UpmHoOutSucc_NR;
            break;
        default:
            return;
    }

    if (FnVCCB_IsAppliedUpmCioToNbr(ptCi, pTgtCgi, &ptCi->upmInfo.upmAlgoInfoInstalled) == FALSE)
    {
        return;
    }

    MACRO_STAT_PMCC(STAT_UPM_RLF_NR, stat, ptCi, pSrcCgi->ci, pTgtCgi->ci, (int)pTgtCgi->plmn.longId, 0, 0);
}

/**
 * @brief This function retrieves the upmStatInfoForCall_type pointer based on the state command of the callInfo_type structure.
 * 
 * @param ptCi Pointer to the callInfo_type structure.
 * @return upmStatInfoForCall_type* Pointer to the upmStatInfoForCall_type structure.
 */
upmStatInfoForCall_type* FnVCCB_GetUpmStatInfo(callInfo_type *ptCi)
{
    // Check if the input pointer is valid
    VALID_E_POINT_CHECK_NULL(ptCi);

    // If the state command is RrcReestablish_cmd, return the pointer to the reestablishInfo.upmStatInfo
    if (ptCi->stateCmd == RrcReestablish_cmd)
    {
        return &ptCi->ueInfo.reestablishInfo.upmStatInfo;
    }

    // Otherwise, return the pointer to the upmInfo.upmStatInfo
    return &ptCi->upmInfo.upmStatInfo;
}

/**
 * @brief This function retrieves the upmAlgoInfoForCall_type pointer based on the state command of the callInfo_type structure.
 * 
 * @param ptCi - Pointer to the callInfo_type structure
 * @return upmAlgoInfoForCall_type* - Pointer to the upmAlgoInfoForCall_type structure
 */
upmAlgoInfoForCall_type* FnVCCB_GetUpmAlgoInfo(callInfo_type *ptCi)
{
    // Check if the input pointer is valid
    VALID_E_POINT_CHECK_NULL(ptCi);

    // If the UE is SA mobility or the state command is MrdcXnSNAdd_cmd,
    // return a pointer to the NEW upmAlgoInfoForCall_type structure.
    if (FnVCCB_IsSaMobilityUE(*ptCi) || ptCi->stateCmd == MrdcXnSNAdd_cmd)
    {
        if (ptCi->upmInfo.upmAlgoInfoNew.usage == VCCB_FLAG_ON)
        {
            return &ptCi->upmInfo.upmAlgoInfoNew;
        }
    }

    // Otherwise, return a pointer to the INSTALLED upmAlgoInfoForCall_type structure.
    return &ptCi->upmInfo.upmAlgoInfoInstalled;
}

// SVR23B FGR-MC1027 Connected mobility control for RedCap UE
void FnVCCB_UpdateRedcapFlag(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if(E_CALLTYPE_SA == ptCi->callType)
    {
        ptCi->redCapUeInfo.redCapUeFlag = ptCi->redCapUeInfo.supportOfRedCap_r17;
    }

    return;
}

int16_t FnVCCB_VerifyLastServingCellFromNrRlfReport(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    
    if (!ptCi->rlfReportInfo.isLastServingCellValid)
    {
        VCCB_PRINT_ERROR("Last Serving NR Cell is not available in nr-RLF-Report ERROR!\n");
        return BREAK;
    }

    CGI_Info_Logging_type *ptLastServingCell = &ptCi->rlfReportInfo.LastServingCellId;

    if (FALSE == VLIB_isCellBelongsToGnb(&ptLastServingCell->plmn, &ptLastServingCell->ci, ptCi->gnbNum))
    {
        VCCB_PRINT_ERROR("Last serving cell no belongs to this gNB(plmn:%x/ci:%lu/gnbNum:%d/conFailType:%d)\n",
            ptLastServingCell->plmn.longId, ptLastServingCell->ci, ptCi->gnbNum, ptCi->mroInfo.rlf_report.connectionFailureType);
        return ERROR;  // discard
    }
    
    return GOOD;
}

bool FnVCCB_IsReportCgiRunning(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    //during reportCgi handover, ANR reportCgi, ANR NRDC SN reportCGi, vccb cannot start new reportCgi procedure
    if (GET_REPORT_CGI_FLAG(ptCi) || GET_REPORT_CGI_SN_FLAG(ptCi))
    {
        VCCB_PRINT_LOG_ANR(ptCi, "(ANR) FnVCCB_IsReportCgiRunning(reportCgiFlag:%d reportCgiFlagSn:%d)\n",
            GET_REPORT_CGI_FLAG(ptCi), GET_REPORT_CGI_SN_FLAG(ptCi));
        return true;
    }

    // during ANR report Cgi procedure vccb cannot start new reportCgi procedure
    if (VCCB_IS_ANR_REPORT_CGI_PROCEDURE(ptCi))
    {
        VCCB_PRINT_LOG_ANR(ptCi, "(ANR) FnVCCB_IsReportCgiRunning(state:%d)\n", ptCi->state);
        return true;
    }

    // during t321 timer, send failure ncgiFailure to osab
    if (IS_TIMER_VALID(ptCi->anrInfo.reportCgiTimer))
    {
        VCCB_PRINT_LOG_ANR(ptCi, "(ANR) FnVCCB_IsReportCgiRunning(running timer:%d)\n", ptCi->anrInfo.reportCgiTimer.id);
        return true;
    }

    return false;
}

/**
 * @brief     This function provides a function to obtain the NR SERVING CGI of a specific cell.
 * @param     cellNum : uint32_t
 * @return    anr_cgi_type { ci, plmn, gnbIdLength }
 */
anr_cgi_type FnVCCB_GetNrServCgiFromCellNum(uint32_t cellNum)
{
    AUTO_TRACE_FUNC;

    anr_cgi_type cgi;

    memset(&cgi, 0x00, sizeof(cgi));

    // {{{ For CELLINFO
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, cgi);

    const VccbCellInfo_type *ptCell = &CELLINFO[cellNum];
    // }}}

    // {{{ For GNBINFO
    const uint8_t gnbNum = ptCell->gnbNum;

    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, cgi);

    const VccbGnbInfo_type *const ptGnb = &GNBINFO[gnbNum];
    // }}}

    cgi.plmn.longId = ptGnb->globalGnbId.plmn.longId;
    cgi.gnbIdLength = ptGnb->globalGnbId.gnbId.idLength;
    cgi.ci = ptCell->cgi.ci;

    return cgi;
}

/**
 * @brief This function is used to make the message 'sgNcgiNotifyVccbOsab_type' for ECGI notification to OSAB.
 * 
 * @param ptCi: Pointer to call information
 * @param ecgiNoti: Reference to the ECGI notification message structure
 * @param reportedCGI: Reported CGI information
 */
void FnVCCB_MakeMsgEcgiNotifyVccbOsab(callInfo_type *ptCi, msgNcgiNotifyVccbOsab_type *pEcgiNoti ,anrCgiInfo reportedCGI)
{
    VALID_E_POINT_CHECK_VOID(pEcgiNoti);

    const int ecgiIdx = 0;

    pEcgiNoti->uNotify.ecgiInfo.ecgi[ecgiIdx] = reportedCGI;
    pEcgiNoti->uNotify.ecgiInfo.numEutraCgi = 1;

    // MAX_NUM_ECGI is changed from 1 to 6 on SVR23A
    // VCCB_CHECK_RANGE_AND_RETURN_ERROR(ecgiIdx, MAX_NUM_ECGI, "numEutraCgi");

    pEcgiNoti->uNotify.ecgiInfo.pci = ptCi->anrInfo.pci;
    pEcgiNoti->uNotify.ecgiInfo.earfcnDl = ptCi->anrInfo.freq;

    pEcgiNoti->servCgi = FnVCCB_GetNrServCgiFromCellNum(ptCi->servCellNum);
    pEcgiNoti->mrType = (enumAnrMrType)ptCi->anrInfo.mrType;
    pEcgiNoti->objType = eutraType;
    pEcgiNoti->endPointNGIdx = ptCi->endPointInfo.ngIdx;
}

/**
 * @brief This function processes the ANR Report CGI Measurement Report message.
 * 
 * @param ptCi: Pointer to call information
 * @param cgiAcquired: Boolean indicating if the CGI was acquired
 * @param reportedCGI: Structure containing the reported CGI information
 */
void FnVCCB_ProcessANRReportCGIEutraMeasurementReport(callInfo_type *ptCi, bool cgiAcquired, anrCgiInfo reportedCGI)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (not cgiAcquired)
    {
        // ECGI_REPORT_ANR STAT - FGS-SF0503 FR530
        VCCB_REPORT_CGI_STAT(ptCi, CGI_REPORT_RESULT_FAIL_NULL_CGI_MR,  GET_REPORT_CGI_AUTONOMOUS_GAP_FLAG(ptCi));
    }
    else //cgiAcquired == true
    {
        // ECGI_REPORT_ANR STAT - FGS-SF0503 FR530
        VCCB_REPORT_CGI_STAT(ptCi, CGI_REPORT_RESULT_SUCC, GET_REPORT_CGI_AUTONOMOUS_GAP_FLAG(ptCi));

        msgNcgiNotifyVccbOsab_type ecgiNotiMsg;
        FnVCCB_MakeMsgEcgiNotifyVccbOsab(ptCi, &ecgiNotiMsg, reportedCGI);
        if (ERROR == VIIL_send_msgNcgiNotifyVccbOsab(ptCi, &ecgiNotiMsg))
        {                           
            VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_send_msgNcgiNotifyVccbOsab Error (%s)\n", __func__);
        }                                                   
        return;                 
    }


    // If the above step fails, send a failure message to OSAB
    if (ERROR == VIIL_send_msgNcgiFailureVccbOsab(ptCi, acquisitionFailure))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_send_msgNcgiFailureVccbOsab Error(%d)\n", acquisitionFailure);
    }
}

// }}}
