/**
 * @file        FeatLb.cpp
 * @brief       Utility functions for Load Balance
 */
#include "FeatLb.hpp"

#include "ComInclude.h"
#include "ComLibUtility.h"

#include "FeatCallProc.h"
#include "FeatCommon.h"
#include "FeatHo.h"
#include "FeatMcoStruct.hpp"
#include "FeatMeasurements.hpp"
#include "FeatCa.hpp"

#include "StateCommon.h"
#include "StateCa.h"
#include "StateMco.h"
#include "MsgVccbSend.h"
#include <chrono>
#include "access_common_yang.h"


/****************************************************************************
 * Goto Feature
    [FGR-LC0703] Load Balancing between NR Carriers
    [FGR-LC0711] NR Inter-RAT Load Balancing to LTE
    [FGR-LC0712] VoNR Load Balancing
    [FGR-LC0710] Slice LB (Slice Aware Connected Mode Load Balancing)
    [FGR-LC0708] Load based PSCell Change for EN-DC
****************************************************************************/

/****************************************************************************
                UTIL
****************************************************************************/
//{{{

/**
 * @brief Update Load Balancing Handover flag
 * @details incoming handover : check Cause and VoNR
 *          LB Cause + VoNR : isVoNrLbHo = TRUE
 *          LB Cause + non-VoNR : isLbHo = TRUE
 * @details outgoing handover : check Report type and purpose
 *          measReport_A4 + a4Purpose_NRLoadBalancing or
 *          measReport_A5 + a5Purpose_NRLoadBalancing : isLbHo = TRUE
 *          measReport_A5 + a5Purpose_voNrNRLoadBalancing : isVoNrLbHo = TRUE
 * @param [in] ptCi : pointer of callInfo_type
 */
void FnVCCB_UpdateIsLbHoFlag(callInfo_type *ptCi, StartSaHandoverDb& hoInputDb)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    // There is no update in ptCi->saHoMrQueueInfo in case of PCC Change
    if ((TRUE == ptCi->hoInfo.pccChangeHoFlag) || (TRUE == ptCi->hoInfo.slbPccChangeHoFlag)) return;

    ptCi->hoInfo.isLbHo = ptCi->hoInfo.isIratLbHo = ptCi->hoInfo.isVoNrLbHo = FALSE;

    /*Incoming HO*/
    if (ptCi->hoInfo.isTarget == TRUE)
    {
        switch (ptCi->hoInfo.hoType.initiated)
        {
            case HO_TYPE_SA_INTER_GNB_XN_HANDOVER:
                if (ptCi->cause.xnCause == CauseXnapRadioNetworkLayerReduceLoadInServingCell)
                {
                    if (ptCi->hoInfo.isVonrCall == TRUE)  // FGR-LC0712
                    {
                        ptCi->hoInfo.isVoNrLbHo = TRUE;
                    }
                    else
                    {
                        ptCi->hoInfo.isLbHo = TRUE;
                    }
                }
                break;

            case HO_TYPE_SA_INTER_GNB_NG_HANDOVER:
                if (ptCi->cause.ngCause == CauseNgapRadioNetworkLayerReduceLoadInServingCell)
                {
                    if (ptCi->hoInfo.isVonrCall == TRUE)  // FGR-LC0712
                    {
                        ptCi->hoInfo.isVoNrLbHo = TRUE;
                    }
                    else
                    {
                        ptCi->hoInfo.isLbHo = TRUE;
                    }
                }
                break;

            default:
                break;
        }
        return;
    }

    /*Outgoing HO*/
    uint8_t reportType = hoInputDb.getReportType();
    uint8_t reportPurpose = hoInputDb.getReportPurpose();

    // FGR-LC0703
    if ((reportType == measReport_A4 && reportPurpose == a4Purpose_NRLoadBalancing) ||
        (reportType == measReport_A5 && reportPurpose == a5Purpose_NRLoadBalancing))
    {
        ptCi->hoInfo.isLbHo = TRUE;
    }

    // FGR-LC0711
    if (IS_IRAT_LB_CASE(reportType, reportPurpose))
    {
        ptCi->hoInfo.isIratLbHo = TRUE;
    }

    // FGR-LC0712
    if (reportType == measReport_A5 && reportPurpose == a5Purpose_voNrNRLoadBalancing)
    {
        ptCi->hoInfo.isVoNrLbHo = TRUE;
    }

    return;
}

uint8_t FnVCCB_IsLoadBalancingHandoverAllowed(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(ptCi->gnbNum, MAX_GNB_PER_SYS);

    uint8_t plmnIndex = 0;
    if (GOOD != VLIB_getMultipleGnbPlmnIndexInfo(ptCi, &plmnIndex, ptCi->ueInfo.servedPlmn.longId))
    {
        return TRUE;
    }

    uint8_t svcGrpId = FnVCCB_GetSvcGrpId(*ptCi, FALSE);
    VCCB_CHECK_E_RANGE_AND_FALSE(svcGrpId, MAX_SVC_GRP_DB_NUM);

    SvcGrpBasedCfg_type *pSvcGrp = &GNBINFO[ptCi->gnbNum].cfg.svcGrpBasedCfg[svcGrpId];
    if ((CI_use == pSvcGrp->usage) && (svcGrpId > 0) && (FALSE == pSvcGrp->loadBalancingHandoverAllowed))
    {
        VCCB_PRINT_CALL_CRITICAL(ptCi, "LoadBalancingHandoverAllowed svcGrpBasedCfg: svcGrpId(%d) !!\n", svcGrpId);
        return FALSE;
    }

    return TRUE;
}

bool VCCM_CheckIfTargetCellIsOverloaded(
    callInfo_type &rCall, uint16_t nbrIdx, int16_t lbAction, uint8_t targetCellLoadCheckType)
{
    const uint8_t voNrLbMode = 1;  // lbAction = 0(lbMode) or 1(voNrLbMode)

    if (lbAction == voNrLbMode)  // FGR-LC0712 VoNR LB
    {
        uint8_t isSelectableTargetCell = FnVCCB_IsSelectableTargetCellForVoNrLB(&rCall, nbrIdx);
        if (FALSE == isSelectableTargetCell)
        {
            return true;  // Target is overloaded (Unselectable cell)
        }

        VCCB_PRINT_LOG_VONR_LB(&rCall, "[VONRLB] Target cell is selected. Trigger VONRLB HO (nbr:%d)\n", nbrIdx);
    }
    else
    {
        if (LB_LOAD_NOT_AVAILABLE == VCCM_CheckTargetCellResourceLoadInfo(&rCall, nbrIdx, targetCellLoadCheckType))
        {
            return true;  // Target is overload
        }

        VCCB_PRINT_LOG_SA_LB(&rCall, "[SALB] Target cell is selected. Trigger LB HO (nbr:%d)\n", nbrIdx);
    }

    return false;
}

/**
 * @brief Returns true if LB-related measurements are installed on UE.
 * 
 * @param call info
 * @return true 
 * @return false 
 */
bool VCCB_CheckLbMeasActivated(const callInfo_type &call)
{
    AUTO_TRACE_FUNC;

    const measurementsConfiguration_type &ueMeasConf = call.measurementsConfiguration;

    for (const reportConfigurationInstalledUe_type &ueReportConf : ueMeasConf.reportConfigurations.installedItems)
    {
        if (CI_use != ueReportConf.usage)
        {
            continue;
        }
        if (not VCCB_IsLbReportTypePurpose(call, static_cast<enumMeasurementReportType>(ueReportConf.conf.reportType),
                ueReportConf.conf.reportPurpose))
        {
            continue;
        }
        // Is it really installed on UE?
        for (const measurementIdentity_type &ueMeasId : ueMeasConf.measurementIdentities.installedItems)
        {
            if (CI_use != ueMeasId.usage)
            {
                continue;
            }
            if (ueMeasId.reportConfigId == ueReportConf.objectId)
            {
                return true;
            }
        }
    }
    return false;
}

/**
 * @brief Returns configured CPU overloaded level for SA and NSA calls.
 * 
 * @param rCi call info
 * @return uint8_t 
 */
inline uint8_t VCCB_LB_GetOverloadedLevel(const callInfo_type &rCi)
{
    return (VCCB_IsEndcSn(rCi) ? CFG->overloadControl.ueSigCpuOverloadControl.overloadedLevelPscellChangeLb
                               : CFG->overloadControl.ueSigCpuOverloadControl.overloadedLevelIntraNrLb);
}

/**
 * @brief Returns either dlCapacity or ulCapacity or MIN(dlCapacity, ulCapacity) depending on resourceModeOption.
 * 
 * @param resourceModeOption 
 * @param dlCapacity 
 * @param ulCapacity 
 * @return uint8_t dlCapacity or ulCapacity or MIN(dlCapacity, ulCapacity) or 0xFF
 */
uint8_t VCCB_LB_GetCellAvailableResource(enumLbResourceModeOption_type resourceModeOption, uint8_t dlCapacity, uint8_t ulCapacity)
{
    AUTO_TRACE_FUNC;

    switch (resourceModeOption)
    {
        case LB_RESOURCE_MODE_OPTION_MIN_DL_UL:
            return MIN(dlCapacity, ulCapacity);

        case LB_RESOURCE_MODE_OPTION_DL:
            return dlCapacity;

        case LB_RESOURCE_MODE_OPTION_UL:
            return ulCapacity;

        default:
            break;
    }

    return 0xFF; // invalid value.
}

/**
 * @brief Calculates and returns effective available resource for a given cell / neighbor cell.
 * 
 * @param resourceModeOption Resource mode option (MIN_DL_UL, DL, or UL)
 * @param cellPrbRsc Cell PRB resource information containing capacity values and CCCV
 * @return uint8_t Effective available resource value based on resource mode option
 */
template <typename T>
uint8_t VCCB_LB_GetCellEffectiveAvailableResource(
    enumLbResourceModeOption_type resourceModeOption, const T &cellPrbRsc)
{
    AUTO_TRACE_FUNC;

    const auto effectiveDlCapacityValue = static_cast<uint8_t>((cellPrbRsc.dlCapacityValue * cellPrbRsc.dlCCCV) / 100);
    const auto effectiveUlCapacityValue = static_cast<uint8_t>((cellPrbRsc.ulCapacityValue * cellPrbRsc.ulCCCV) / 100);

    return VCCB_LB_GetCellAvailableResource(resourceModeOption, effectiveDlCapacityValue, effectiveUlCapacityValue);
}

/**
 * @brief Returns true if load balancing feature is enabled either for SA or NSA.
 * 
 * @param call info
 * @param connModeLBInfo load balancing connected mode info
 * @return true 
 * @return false 
 */
inline bool VCCB_IsLbFeatureEnabled(const callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    bool isNsaLbEnabled = (E_CALLTYPE_NSA == rCi.callType) && rCell.lbCfg.pscellChangeLbInfo.pscellChangeLbSwitch;
    bool isSaLbEnabled =
        (E_CALLTYPE_SA == rCi.callType) &&
        (VCCB_FLAG_ON == FnVCCB_GetIntraNrLbSwitch(rCell, rCell.lbCfg.connModeLbInfo, IS_REDCAP_UE(&rCi)));

    return (isNsaLbEnabled || isSaLbEnabled);
}

/**
 * @brief Returns true if PDCCH CCE based load evaluation is enabled. Works for SA and NSA calls.
 * 
 * @param rCi call info
 * @param rCell cell info
 * @return true 
 * @return false 
 */
inline bool VCCB_LB_IsPdcchCceBasedLoadEvaluateSupport(const callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    return VCCB_IsEndcSn(rCi) ? rCell.lbCfg.pscellChangeLbInfo.pdcchCceBasedLoadEvaluateSupport
                              : (enabled == rCell.lbCfg.connModeLbInfo.pdcchCceBasedLoadEvaluateSupport);
}

inline int VCCB_LB_GetUlCceFailureRateThreshold(const callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    return (VCCB_IsEndcSn(rCi) ? rCell.lbCfg.pscellChangeLbInfo.ulCceFailureRateThreshold
                               : rCell.lbCfg.connModeLbInfo.ulCceFailureRateThreshold);
}

inline int VCCB_LB_GetPdcchCceUsageThreshold(const callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    return (VCCB_IsEndcSn(rCi) ? rCell.lbCfg.pscellChangeLbInfo.pdcchCceUsageThreshold
                               : rCell.lbCfg.connModeLbInfo.pdcchCceUsageThreshold);
}

inline int VCCB_LB_GetTargetUlCceFailureRateThreshold(const callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    return (VCCB_IsEndcSn(rCi) ? rCell.lbCfg.pscellChangeLbInfo.targetUlCceFailureRateThreshold
                               : rCell.lbCfg.connModeLbInfo.targetUlCceFailureRateThreshold);
}

inline int VCCB_LB_GetTargetPdcchCceUsageThreshold(const callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    return (VCCB_IsEndcSn(rCi) ? rCell.lbCfg.pscellChangeLbInfo.targetPdcchCceUsageThreshold
                               : rCell.lbCfg.connModeLbInfo.targetPdcchCceUsageThreshold);
}

inline int VCCB_LB_GetResourceDelta(const callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    return (VCCB_IsEndcSn(rCi) ? rCell.lbCfg.pscellChangeLbInfo.rscDelta
                               : FnVCCB_GetResourceDelta(rCell, IS_REDCAP_UE(&rCi)));
}

inline int VCCB_LB_GetUeDelta(const callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    return (VCCB_IsEndcSn(rCi) ? rCell.lbCfg.pscellChangeLbInfo.ueDelta : rCell.lbCfg.connModeLbInfo.ueDelta);
}

/**
 * @brief Returns the effective resource delta value based on call type (EN-DC or SA).
 * 
 * @param rCi Reference to call information structure
 * @param rCell Reference to cell information structure
 * @return int Effective resource delta value from the appropriate configuration
 */
inline int VCCB_LB_GetEffectiveResourceDelta(const callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    return (VCCB_IsEndcSn(rCi) ? rCell.lbCfg.pscellChangeLbInfo.effRscDelta : rCell.lbCfg.connModeLbInfo.effRscDelta);
}

std::array<int, CONN_LB_THRESHOLD_GROUP_MAX> VCCB_LB_GetAvailableResourceThreshold(
    const callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    const auto &pscellChangeLbInfo = rCell.lbCfg.pscellChangeLbInfo;

    // NSA.
    if (VCCB_IsEndcSn(rCi))
    {
        return {pscellChangeLbInfo.availRscThreshold[0], pscellChangeLbInfo.availRscThreshold[1],
            pscellChangeLbInfo.availRscThreshold[2], pscellChangeLbInfo.availRscThreshold[3]};
    }
    // SA.
    return {FnVCCB_GetAvailRscThresholdGroup(rCi, rCell, CONN_LB_THRESHOLD_GROUP0),
        FnVCCB_GetAvailRscThresholdGroup(rCi, rCell, CONN_LB_THRESHOLD_GROUP1),
        FnVCCB_GetAvailRscThresholdGroup(rCi, rCell, CONN_LB_THRESHOLD_GROUP2),
        FnVCCB_GetAvailRscThresholdGroup(rCi, rCell, CONN_LB_THRESHOLD_GROUP3)};
}

std::array<int, CONN_LB_THRESHOLD_GROUP_MAX> VCCB_LB_GetAvailableUeThreshold(
    const callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    const auto &pscellChangeLbInfo = rCell.lbCfg.pscellChangeLbInfo;
    const auto &connModeLbInfo = rCell.lbCfg.connModeLbInfo;

    // NSA.
    if (VCCB_IsEndcSn(rCi))
    {
        return {pscellChangeLbInfo.availUeThreshold[0], pscellChangeLbInfo.availUeThreshold[1],
            pscellChangeLbInfo.availUeThreshold[2], pscellChangeLbInfo.availUeThreshold[3]};
    }
    // SA.
    return {connModeLbInfo.availUeThreshold, connModeLbInfo.availUeThreshold1, connModeLbInfo.availUeThreshold2,
        connModeLbInfo.availUeThreshold3};
}

/**
 * @brief Returns the effective available resource threshold values for different threshold groups.
 * 
 * @param rCi Reference to call information structure
 * @param rCell Reference to cell information structure
 * @return std::array<int, CONN_LB_THRESHOLD_GROUP_MAX> Array of effective available resource threshold values
 *         For NSA (EN-DC): Returns configured effective available resource thresholds
 *         For SA: Returns array of zeros (feature not implemented for SA)
 */
std::array<int, CONN_LB_THRESHOLD_GROUP_MAX> VCCB_LB_GetEffectiveAvailableResourceThreshold(const callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    const auto &pscellChangeLbInfo = rCell.lbCfg.pscellChangeLbInfo;

    // NSA.
    if (VCCB_IsEndcSn(rCi))
    {
        return {pscellChangeLbInfo.effAvailRscThreshold[0], pscellChangeLbInfo.effAvailRscThreshold[1],
            pscellChangeLbInfo.effAvailRscThreshold[2], pscellChangeLbInfo.effAvailRscThreshold[3]};
    }
    // SA.
    else
    {
        const auto &connModeLbInfo = rCell.lbCfg.connModeLbInfo;
        return {connModeLbInfo.availEffRscThreshold, connModeLbInfo.availEffRscThreshold1,
            connModeLbInfo.availEffRscThreshold2, connModeLbInfo.availEffRscThreshold3};
    }
}

uint8_t VCCB_LB_GetThresholdGroup(
    const callInfo_type &rCi, const VccbCellInfo_type &rCell, const measurementObjectNRBaseDb_type &mo, uint8_t moIdx)
{
    return (VCCB_IsEndcSn(rCi) ? mo.loadBalancingThresholdGroupPscellChange
                               : FnVCCB_GetLbThresholdGroup(rCell, mo, moIdx, IS_REDCAP_UE(&rCi)));
}

/**
 * @brief Returns configured load-evaluate-mode value for SA and NSA calls.
 * 
 * @param rCi call info
 * @param rCell cell info
 * @return enumLoadEvalMode_Type 
 */
inline enumLoadEvalMode_Type VCCB_LB_GetLoadEvaluateMode(const callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    return (VCCB_IsEndcSn(rCi) ? rCell.lbCfg.pscellChangeLbInfo.loadEvaluateMode
                               : FnVCCB_GetLoadEvaluateMode(rCell, rCell.lbCfg.connModeLbInfo, IS_REDCAP_UE(&rCi)));
}

/**
 * @brief Returns configured resource-mode-option value for SA and NSA calls.
 * 
 * @param rCi 
 * @param rCell 
 * @return enumLbResourceModeOption_type 
 */
inline enumLbResourceModeOption_type VCCB_LB_GetResourceModeOption(
    const callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    return (VCCB_IsEndcSn(rCi) ? rCell.lbCfg.pscellChangeLbInfo.resourceModeOption
                               : rCell.lbCfg.connModeLbInfo.resourceModeOption);
}

/**
 * @brief Returns max of available-resource-threshold..available-resource-threshold3 for SA and NSA calls.
 * 
 * @param rCi call info
 * @param rCell cell info
 * @return int max of available-resource-threshold..available-resource-threshold3
 */
int VCCB_LB_GetMaxAvailableResourceThreshold(const callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    AUTO_TRACE_FUNC;

    int result = 0;

    if (VCCB_IsEndcSn(rCi))
    {
        const auto &pscellChangeLbInfo = rCell.lbCfg.pscellChangeLbInfo;
        result = *std::max_element(
            std::begin(pscellChangeLbInfo.availRscThreshold), std::end(pscellChangeLbInfo.availRscThreshold));
    }
    else
    {
        const auto availRscThreshold = FnVCCB_GetAvailRscThresholdGroup(rCi, rCell, CONN_LB_THRESHOLD_GROUP0);
        const auto availRscThreshold1 = FnVCCB_GetAvailRscThresholdGroup(rCi, rCell, CONN_LB_THRESHOLD_GROUP1);
        const auto availRscThreshold2 = FnVCCB_GetAvailRscThresholdGroup(rCi, rCell, CONN_LB_THRESHOLD_GROUP2);
        const auto availRscThreshold3 = FnVCCB_GetAvailRscThresholdGroup(rCi, rCell, CONN_LB_THRESHOLD_GROUP3);
        result = std::max({availRscThreshold, availRscThreshold1, availRscThreshold2, availRscThreshold3});
    }

    return result;
}

/**
 * @brief Returns the maximum effective available resource threshold value among all threshold groups.
 * 
 * @param rCi Reference to call information structure
 * @param rCell Reference to cell information structure
 * @return int Maximum effective available resource threshold value
 *         For NSA (EN-DC): Returns maximum of configured effective available resource thresholds
 *         For SA: Returns 0 (feature not implemented for SA)
 */
int VCCB_LB_GetMaxEffectiveAvailableResourceThreshold(const callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    AUTO_TRACE_FUNC;

    int result = 0;

    if (VCCB_IsEndcSn(rCi))
    {
        const auto &pscellChangeLbInfo = rCell.lbCfg.pscellChangeLbInfo;
        result = *std::max_element(
            std::begin(pscellChangeLbInfo.effAvailRscThreshold), std::end(pscellChangeLbInfo.effAvailRscThreshold));
    }
    else
    {
        const auto &connModeLbInfo = rCell.lbCfg.connModeLbInfo;
        result = std::max({connModeLbInfo.availEffRscThreshold, connModeLbInfo.availEffRscThreshold1,
            connModeLbInfo.availEffRscThreshold2, connModeLbInfo.availEffRscThreshold3});
    }

    return result;
}

/**
 * @brief Returns max of available-ue-threshold..available-ue-threshold3 for SA and NSA calls.
 * 
 * @param rCi call info
 * @param rCell cell info
 * @return int max of available-ue-threshold..available-ue-threshold3
 */
int VCCB_LB_GetMaxAvailableUeThreshold(const callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    AUTO_TRACE_FUNC;

    int result = 0;

    if (VCCB_IsEndcSn(rCi))
    {
        const auto &pscellChangeLbInfo = rCell.lbCfg.pscellChangeLbInfo;
        result = *std::max_element(
            std::begin(pscellChangeLbInfo.availUeThreshold), std::end(pscellChangeLbInfo.availUeThreshold));
    }
    else
    {
        const auto &connModeLbInfo = rCell.lbCfg.connModeLbInfo;
        result = std::max({connModeLbInfo.availUeThreshold, connModeLbInfo.availUeThreshold1,
            connModeLbInfo.availUeThreshold2, connModeLbInfo.availUeThreshold3});
    }

    return result;
}

/**
 * @brief Returns true if CPU is overloaded. Works for SA and NSA calls.
 * 
 * @param call info
 * @return true 
 * @return false 
 */
bool VCCB_LB_IsCpuOverloaded(const callInfo_type &call)
{
    AUTO_TRACE_FUNC;

    if (VCCB_FLAG_ON == CFG->overloadControl.ueSigCpuOverloadControl.ueSigCpuOverloadAction)
    {
        const auto threshold = VCCB_LB_GetOverloadedLevel(call);
        VCCB_PRINT_LOG_SA_LB(&call, "[LB] CPU Ovld(%d), Thd(%d)\n", CFG->overloadStatus, threshold);
        if (TRUE == IS_CPC_CPU_OVERLOAD_CONDITION(threshold))
        {
            VCCB_PRINT_LOG_SA_LB(&call, "[LB] CPU Overload\n");
            return true;
        }
    }

    return false;
}

namespace
{
const int MIN_RESOURCE_DELTA = -100;
const int MAX_RESOURCE_DELTA = 100;

const int MIN_UE_DELTA = 0;
const int MAX_UE_DELTA = 100;

const int MIN_EFFECTIVE_RESOURCE_DELTA = 0;
const int MAX_EFFECTIVE_RESOURCE_DELTA = 100;

/**
 * @brief Returns true if PRB load is in valid range [0..100].
 * 
 * @param load value
 * @return true 
 * @return false 
 */
inline bool IsValidPrbRange(int load)
{
    return ((100 >= load) && (0 <= load));
}

/**
 * @brief Returns true if delta value is in valid range.
 * 
 * @param delta value
 * @return true 
 * @return false 
 */
inline bool IsValidDeltaRange(int delta, enumLoadEvalMode_Type loadMode)
{
    int minV = 0;
    int maxV = 0;

    switch (loadMode)
    {
        case loadEvalMode_resource:
            minV = MIN_RESOURCE_DELTA;
            maxV = MAX_RESOURCE_DELTA;
            break;
        case loadEvalMode_ue:
            minV = MIN_UE_DELTA;
            maxV = MAX_UE_DELTA;
            break;
        case loadEvalMode_effective_resource:
            minV = MIN_EFFECTIVE_RESOURCE_DELTA;
            maxV = MAX_EFFECTIVE_RESOURCE_DELTA;
            break;
        default:
            return false;
    }

    return (minV <= delta) && (delta <= maxV);
}
} // namespace

// }}}

/****************************************************************************
    [FGR-LC0703] Load Balancing between NR Carriers
****************************************************************************/
// {{{

uint8_t VCCM_CheckLoadBalancingTrigger(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_VALID_CELLNUM_FALSE(ptCi->servCellNum);

    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    // FGR-LC0703 (FR35)
    if (VCCM_CheckLbByNSSAI(ptCi))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[SALB] NSSAI LB\n");
        return FALSE;
    }

    // Check for an Emergency Call
    if (VCCM_CheckEmergencyCall(ptCi))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[SALB] Call Cause is Emergency\n");
        return FALSE;
    }

    // Check for VoNR
    if (FnVCCB_IsVoNRCall(ptCi))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[SALB] VoNR is in service \n");
        return FALSE;
    }

    // RFSP based priority Call
    if (FnVCCB_GetSaMeas(*ptCi).rfspHoSupport)
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[SALB] RFSP based priority Call is true \n");
        return FALSE;
    }

    // SVR24A FGR-LC0703
    // FGR-LC0708 FR100 - stop load balancing function if CPU is overloaded.
    if (VCCB_LB_IsCpuOverloaded(*ptCi))
    {
        // Cause is logged by the above function.
        return FALSE;
    }

    // SVR24A FGR-LC0703
    if ((FnVCCB_isRfspSpecificUE(ptCi, ptCi->servCellNum) != nullptr) &&
        (pCell->cellRfspSpecificMeasCtrl.supportLbFpHoUsage != CI_use))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[SALB] RFSP Specific UE\n");
        return FALSE;
    }

    return TRUE;
}

static inline bool FnVCCB_CheckSkipLoadBalancingCondition(const connModeLBInfo_type &rLbInfo, const sonCellPrbRsc_type &rCellPrb)
{
    return (rLbInfo.skipAvailableUeThreshold > rCellPrb.numAvailUe);
}

/**
 * @brief [FGR-LC0703] Load Balancing between FR1 Carriers
 * @details Check if serving cell is overloaded for triggering SA LB Handover
 * @param [in] pointer of callInfo_type, cellNum
 */
void VCCM_CheckServingCellResourceLoadInfo(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    connModeLBInfo_type *ptConnInfo = &pCell->lbCfg.connModeLbInfo;

    // 1. Check if UE is valid (FR33)
    if (VCCM_CheckValidUeForTriggeringSaLb(ptCi) != GOOD)
    {
        return;
    }

    // 2. Init SA LB Info when UE access event occurs
    LB_INIT_MEAS_STATE(ptCi);
    ptCi->saLbHoExecuted = TRUE;

    // 3. Check load balancing usage
    uint8_t usage = FnVCCB_GetIntraNrLbSwitch(*pCell, *ptConnInfo, IS_REDCAP_UE(ptCi));
    if (usage != VCCB_FLAG_ON)
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[SALB] Load balancing is off \n");
        return;
    }

    // Check LB skipping condition (FR35)
    if (FnVCCB_CheckSkipLoadBalancingCondition(*ptConnInfo, pCell->cellRscInfo))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[SALB] Skipping Condition \n");
        return;
    }

    // 4. Check function priorities condition
    if (VCCM_CheckLoadBalancingTrigger(ptCi) == FALSE)
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[SALB] Cannot trigger load balancing due to function priorities \n");
        return;
    }

    // 5. Check cell load condition
    if ((FnVCCB_IsServingCellOverloaded_PdcchCceSaLb(ptCi) == LB_LOAD_OVERLOAD) ||
        (FnVCCB_IsServingCellOverloaded_AvailRscSaLb(ptCi) == LB_LOAD_OVERLOAD))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[SALB] Serving is overloaded. Need to configure LB measurement \n");
        FnVCCB_GetSaMeas(*ptCi).lbIFMeasState = LB_MEAS_STATE_SELECTED;
        VLIB_AttachTimer(&ptCi->lbMrTimer, ptCi, timLbMrReceived_id);
    }

    return;
}

/**
 * @brief Check Target Cell is not overloaded.
 * @param [in] pointer of callInfo_type, nbrCellIdx
 * @return LB_LOAD_NOT_OVERLOAD(Not overloaded)/LB_LOAD_NOT_AVAILABLE(Overloded or N/A)
 */
int16_t VCCM_CheckTargetCellResourceLoadInfo(callInfo_type *ptCi, uint16_t nbrCellIdx, uint8_t loadCheckType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, LB_LOAD_NOT_AVAILABLE);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->servCellNum, MAX_CELL_NUM_VCCB, LB_LOAD_NOT_AVAILABLE);

    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];
    connModeLBInfo_type *ptConnInfo = &pCell->lbCfg.connModeLbInfo;

    if (not VCCB_IsEndcSn(*ptCi))  // [SA LB] FGR-LC0703
    {
        // 1.Check load balancing usage
        uint8_t usage = FnVCCB_GetIntraNrLbSwitch(*pCell, *ptConnInfo, IS_REDCAP_UE(ptCi));
        if ((usage != VCCB_FLAG_ON) || (FnVCCB_GetSaMeas(*ptCi).lbIFMeasState != LB_MEAS_STATE_SELECTED))
        {
            return LB_LOAD_NOT_AVAILABLE;
        }

        // 2. Check function priorities for SA LB trigger
        if (VCCM_CheckLoadBalancingTrigger(ptCi) == FALSE)
        {
            VCCB_PRINT_LOG_SA_LB(ptCi, "[SALB] Cannot trigger load balancing due to function priorities \n");
            return LB_LOAD_NOT_AVAILABLE;
        }

        // 3. Check cell load condition
        if (loadCheckType & LB_LOAD_CHECK_PDCCH_CCE)
        {
            if (LB_LOAD_NOT_OVERLOAD != FnVCCB_IsTargetCellOverloaded_PdcchCceLb(ptCi, nbrCellIdx))
            {
                return LB_LOAD_NOT_AVAILABLE;  // Target cell overload
            }
        }

        if (loadCheckType & LB_LOAD_CHECK_AVAIL_RSC)
        {
            if (LB_LOAD_NOT_OVERLOAD != FnVCCB_IsTargetCellOverloaded_AvailRscLb(ptCi, nbrCellIdx))
            {
                return LB_LOAD_NOT_AVAILABLE;  // Target cell overload
            }
        }

        return LB_LOAD_NOT_OVERLOAD; // Target cell is not overloaded
    }

    // 3. Check cell load condition
    if (loadCheckType & LB_LOAD_CHECK_AVAIL_RSC)
    {
        if (LB_LOAD_NOT_OVERLOAD != VCCM_IsTargetCellOverloaded_AvailRscLb(ptCi, nbrCellIdx))
        {
            return LB_LOAD_NOT_AVAILABLE; // Target cell overload or N/A
        }
    }

    if (loadCheckType & LB_LOAD_CHECK_PDCCH_CCE)
    {
        if (LB_LOAD_NOT_OVERLOAD != VCCM_IsTargetCellOverloaded_PdcchCceLb(ptCi, nbrCellIdx))
        {
            return LB_LOAD_NOT_AVAILABLE; // Target cell overload or N/A
        }
    }

    return LB_LOAD_NOT_OVERLOAD; // Target cell is not overloaded
}

/**
 * @brief [FGR-LC0703] Load Balancing between FR1 Carriers (FR33)
 * @details Check if UE is valid for triggering SA LB Handover
 * @param [in] pointer of callInfo_type
 * @return GOOD(Valid) / ERROR(Invalid)
 */
int16_t VCCM_CheckValidUeForTriggeringSaLb(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (ptCi->saLbHoExecuted == TRUE)
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[SALB] Load balancing is already triggered \n");

        // FGR-LC0703 (FR110)
        if (VCCM_CheckLbByNSSAI(ptCi))
        {
            VCCB_PRINT_LOG_SA_LB(ptCi, "[SALB] Load balancing stopped by NSSAI LB \n");
            LB_INIT_MEAS_STATE(ptCi);
        }
        return ERROR;
    }

    if ((ptCi->stateCmd == IntraRatHO_cmd) || (ptCi->stateCmd == InterRatHO_cmd))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[SALB] Cannot Trigger Load Balancing during HO \n");
        return ERROR;
    }

    if ((ptCi->ueContainerNR.rxFlag != 0) &&
        (IS_FALLBACK_CASE(ptCi)) &&
        (ptCi->redirectionInfo.actualRedirectionMethod != BLIND_REDIR_ONLY))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[SALB] Cannot trigger load balancing by fallback \n");
        return ERROR;
    }

    return GOOD;
}

/**
 * @brief Checks cell resource availability and computes available resources based on capacity values for RedCap.
 * @param[in] rCellPrb Reference to cell PRB resource structure containing capacity values and redcap status.
 * @param[in] rConnInfo Reference to connection mode LB information structure for resource computation.
 * @param[out] rCellAvailRsc parameter to store computed available resource value.
 * @return int16_t - Returns GOOD if computation is successful, LB_LOAD_NOT_AVAILABLE if redcap values are not updated.
 */
int16_t FnVCCB_GetCellAvailableResource_RedCap(const sonCellPrbRsc_type &rCellPrb, const connModeLBInfo_type &rConnInfo, uint8_t &rCellAvailRsc)
{
    if (rCellPrb.dlCapacityValueRedcap == NOT_UPDATED || rCellPrb.ulCapacityValueRedcap == NOT_UPDATED)
    {
        return LB_LOAD_NOT_AVAILABLE;
    }

    uint8_t dlCapacityValue = (uint8_t)MIN(rCellPrb.dlCapacityValue, rCellPrb.dlCapacityValueRedcap);
    uint8_t ulCapacityValue = (uint8_t)MIN(rCellPrb.ulCapacityValue, rCellPrb.ulCapacityValueRedcap);
    rCellAvailRsc = VCCB_LB_GetCellAvailableResource(rConnInfo.resourceModeOption, dlCapacityValue, ulCapacityValue);

    return GOOD;
}

/**
 * @brief [FGR-LC0703] Load Balancing between FR1 Carriers (FR90)
 *        [FGR-LC0708] Load based PSCell Change for EN-DC (FR30)
 * @details Check if serving cell is overloaded based on PDCCH CCE failRate/usage
 * @param [in] pointer of callInfo_type, rsType, usedFreq
 * @return LB_LOAD_OVERLOAD(Overload) / LB_LOAD_NOT_OVERLOAD(Not overload) / LB_LOAD_NOT_AVAILABLE(N/A)
 */
int16_t VCCM_IsServingCellOverloaded_PdcchCceLb(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, LB_LOAD_NOT_AVAILABLE);

    // FGR-LC0708 - use target cell number during intra-SN PSCell Change.
    auto cellNum = ptCi->servCellNum;
    if (VCCB_NSA_IsIntraSnHo(*ptCi))
    {
        cellNum = ptCi->hoInfo.targetCellNum;
    }
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    sonCellPrbRsc_type *ptCellPrb = &pCell->cellRscInfo;

    // Check Load balancing usage
    if (not VCCB_IsLbFeatureEnabled(*ptCi, *pCell))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "%s: LB feature disabled.\n", __FUNCTION__);
        return LB_LOAD_NOT_AVAILABLE;  // N/A
    }

    if (not VCCB_LB_IsPdcchCceBasedLoadEvaluateSupport(*ptCi, *pCell))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "%s: PDCCH CCE condition check disabled.\n", __FUNCTION__);
        return LB_LOAD_NOT_AVAILABLE;  // N/A
    }

    // Check PDCCH CCE load condition
    if ((ptCellPrb->ulCceFailRate != NOT_UPDATED) && (ptCellPrb->dlCceUsage != NOT_UPDATED) && (ptCellPrb->ulCceUsage != NOT_UPDATED))
    {
        const auto ulCceFailureRateThreshold = VCCB_LB_GetUlCceFailureRateThreshold(*ptCi, *pCell);
        const auto pdcchCceUsageThreshold    = VCCB_LB_GetPdcchCceUsageThreshold(*ptCi, *pCell);

        if ((ptCellPrb->ulCceFailRate >= ulCceFailureRateThreshold) &&
            ((ptCellPrb->dlCceUsage + ptCellPrb->ulCceUsage) >= pdcchCceUsageThreshold))
        {
            VCCB_PRINT_LOG_SA_LB(ptCi,
                "[LB] (Serving/Overload) PDCCH CCE load (ulFailRate:rate(%d)>=Th(%d) && usage:dl(%d)+ul(%d)>=Th(%d))\n",
                ptCellPrb->ulCceFailRate, ulCceFailureRateThreshold,
                ptCellPrb->dlCceUsage, ptCellPrb->ulCceUsage, pdcchCceUsageThreshold);
            return LB_LOAD_OVERLOAD; // Overload
        }
        else
        {
            VCCB_PRINT_LOG_SA_LB(ptCi,
                "[LB] (Serving/Normal) PDCCH CCE load (ulFailRate:rate(%d)<Th(%d) || usage:dl(%d)+ul(%d)<Th(%d))\n",
                ptCellPrb->ulCceFailRate, ulCceFailureRateThreshold,
                ptCellPrb->dlCceUsage, ptCellPrb->ulCceUsage, pdcchCceUsageThreshold);
            return LB_LOAD_NOT_OVERLOAD; // Not overload
        }
    }
    else
    {
        VCCB_PRINT_LOG_SA_LB(ptCi,
            "[LB] (Serving/Error) PDCCH CCE load (ulCceFailRate(%d)/dlCceUsage(%d)/ulCceUsage(%d)\n",
            ptCellPrb->ulCceFailRate, ptCellPrb->dlCceUsage, ptCellPrb->ulCceUsage);
    }

    return LB_LOAD_NOT_AVAILABLE; // N/A
}

int16_t VCCM_IsServingCellOverloaded_PdcchCceSaLb_RedCap(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, LB_LOAD_NOT_AVAILABLE);

    auto cellNum = ptCi->servCellNum;
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    connModeLBInfo_type *ptConnInfo = &pCell->lbCfg.connModeLbInfo;
    sonCellPrbRsc_type *ptCellPrb = &pCell->cellRscInfo;

    if (enabled != ptConnInfo->pdcchCceBasedLoadEvaluateSupport)
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "%s: PDCCH CCE condition check disabled.\n", __FUNCTION__);
        return LB_LOAD_NOT_AVAILABLE;  // N/A
    }

    // Check PDCCH CCE load condition
    bool isRedCapCceUpdated = (ptCellPrb->ulCceFailRateRedcap != NOT_UPDATED && ptCellPrb->dlCceUsageRedcap != NOT_UPDATED && ptCellPrb->ulCceUsageRedcap != NOT_UPDATED);
    bool isNormalCceUpdated = (ptCellPrb->dlCceUsage != NOT_UPDATED && ptCellPrb->ulCceUsage != NOT_UPDATED);

    if (isRedCapCceUpdated && isNormalCceUpdated)
    {
        int16_t normalUsage = static_cast<int16_t>(ptCellPrb->dlCceUsage + ptCellPrb->ulCceUsage);
        int16_t redCapUsage = static_cast<int16_t>(ptCellPrb->dlCceUsageRedcap + ptCellPrb->ulCceUsageRedcap);

        if ((ptCellPrb->ulCceFailRateRedcap >= ptConnInfo->redCapUeLbInfo.ulCceFailureRateThreshold) &&
            (MAX(normalUsage, redCapUsage) >= ptConnInfo->redCapUeLbInfo.pdcchCceUsageThreshold))
        {
            VCCB_PRINT_LOG_SA_LB(ptCi,
                "[RedCap LB] (Serving/Overload) PDCCH CCE load (ulFailRate:rate(%d)>=Th(%d) && usage:max(normalUsage(%d), redCapUsage(%d))>=Th(%d))\n",
                ptCellPrb->ulCceFailRateRedcap, ptConnInfo->redCapUeLbInfo.ulCceFailureRateThreshold,
                normalUsage, redCapUsage, ptConnInfo->redCapUeLbInfo.pdcchCceUsageThreshold);
            return LB_LOAD_OVERLOAD; // Overload
        }
        else
        {
            VCCB_PRINT_LOG_SA_LB(ptCi,
                "[RedCap LB] (Serving/Normal) PDCCH CCE load (ulFailRate:rate(%d)<Th(%d) || usage:max(normalUsage(%d), redCapUsage(%d))<Th(%d))\n",
                ptCellPrb->ulCceFailRateRedcap, ptConnInfo->redCapUeLbInfo.ulCceFailureRateThreshold,
                normalUsage, redCapUsage, ptConnInfo->redCapUeLbInfo.pdcchCceUsageThreshold);
            return LB_LOAD_NOT_OVERLOAD; // Not overload
        }
    }
    else
    {
        VCCB_PRINT_LOG_SA_LB(ptCi,
            "[RedCap LB] (Serving/Error) PDCCH CCE load "
            "ulCceFailRate_RedCap(%d)/dlCceUsage_RedCap(%d)/ulCceUsage_RedCap(%d)/dlCceUsage(%d)/ulCceUsage(%d)\n",
            ptCellPrb->ulCceFailRateRedcap, ptCellPrb->dlCceUsageRedcap, ptCellPrb->ulCceUsageRedcap,
            ptCellPrb->dlCceUsage, ptCellPrb->ulCceUsage);
    }

    return LB_LOAD_NOT_AVAILABLE; // N/A
}

int16_t FnVCCB_IsServingCellOverloaded_PdcchCceSaLb(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, LB_LOAD_NOT_AVAILABLE);

    auto cellNum = ptCi->servCellNum;
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    uint8_t redCapOperationMode = pCell->lbCfg.connModeLbInfo.redCapOperationMode;
    if (IS_REDCAP_UE(ptCi) && redCapOperationMode == access_s5gtype_disable)
    {
        // no action
        return LB_LOAD_NOT_AVAILABLE;
    }
    else if (IS_REDCAP_UE(ptCi) && redCapOperationMode == access_s5gtype_redcap_specific)
    {
        // redcap specific action
        return VCCM_IsServingCellOverloaded_PdcchCceSaLb_RedCap(ptCi);
    }
    else
    {
        // normal action
        return VCCM_IsServingCellOverloaded_PdcchCceLb(ptCi);
    }
}

/**
 * @brief [FGR-LC0703] Load Balancing between FR1 Carriers
 *        [FGR-LC0708] Load based PSCell Change for EN-DC (FR30)
 * @details Check if serving cell is overloaded based on available resource for triggering LB Handover
 * @param [in] pointer of callInfo_type
 * @return LB_LOAD_OVERLOAD(Overload) / LB_LOAD_NOT_OVERLOAD(Not overload) / LB_LOAD_NOT_AVAILABLE(N/A)
 */
int16_t VCCM_IsServingCellOverloaded_AvailRscLb(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, LB_LOAD_NOT_AVAILABLE);

    // FGR-LC0708 - use target cell number during intra-SN PSCell Change.
    auto cellNum = ptCi->servCellNum;
    if (VCCB_NSA_IsIntraSnHo(*ptCi))
    {
        cellNum = ptCi->hoInfo.targetCellNum;
    }
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    sonCellPrbRsc_type *ptCellPrb = &pCell->cellRscInfo;

    int servCellAvailRsc = 0;
    int availThreshold = 0;

    // Check Load balancing usage
    if (not VCCB_IsLbFeatureEnabled(*ptCi, *pCell))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "%s: LB feature disabled.\n", __FUNCTION__);
        return LB_LOAD_NOT_AVAILABLE;  // N/A
    }

    const auto resourceModeOption = VCCB_LB_GetResourceModeOption(*ptCi, *pCell);
    const auto loadEvaluateMode   = VCCB_LB_GetLoadEvaluateMode(*ptCi, *pCell);
    switch (loadEvaluateMode)
    {
        case loadEvalMode_resource:
            servCellAvailRsc = VCCB_LB_GetCellAvailableResource(
                resourceModeOption, ptCellPrb->dlCapacityValue, ptCellPrb->ulCapacityValue);
            availThreshold = VCCB_LB_GetMaxAvailableResourceThreshold(*ptCi, *pCell);
            break;

        case loadEvalMode_ue:
            servCellAvailRsc = ptCellPrb->numAvailUe;
            availThreshold = VCCB_LB_GetMaxAvailableUeThreshold(*ptCi, *pCell);
            break;

        case loadEvalMode_effective_resource:
            servCellAvailRsc = VCCB_LB_GetCellEffectiveAvailableResource(resourceModeOption, *ptCellPrb);
            availThreshold   = VCCB_LB_GetMaxEffectiveAvailableResourceThreshold(*ptCi, *pCell);
            break;

        default:
            return LB_LOAD_NOT_AVAILABLE;  // N/A
    }

    if (IsValidPrbRange(servCellAvailRsc) && IsValidPrbRange(availThreshold))
    {
        if (servCellAvailRsc < availThreshold)
        {
            VCCB_PRINT_LOG_SA_LB(ptCi,
                "[LB] (Serving/Overload) RESOURCE load (mode:%d/opt:%d)(servAvailRsc(%d)<availTh(%d))\n",
                loadEvaluateMode, resourceModeOption, servCellAvailRsc, availThreshold);
            return LB_LOAD_OVERLOAD;  // Overload
        }
        else
        {
            VCCB_PRINT_LOG_SA_LB(ptCi,
                "[LB] (Serving/Normal) RESOURCE load (mode:%d/opt:%d)(servAvailRsc(%d)>=availTh(%d))\n",
                loadEvaluateMode, resourceModeOption, servCellAvailRsc, availThreshold);
            return LB_LOAD_NOT_OVERLOAD;  // Not overload
        }
    }
    else
    {
        VCCB_PRINT_LOG_SA_LB(
            ptCi, "[LB] invalid value - servCellAvailRsc(%d), availThreshold(%d).\n", servCellAvailRsc, availThreshold);
    }

    return LB_LOAD_NOT_AVAILABLE;  // N/A
}

/**
 **  @brief Check if cell with specified cellNum is overloaded
 **  @param cellNum *ptCi
 **  @return int16_t GOOD/BREAK//ERROR - GOOD if cell is not overloaded, BREAK if overloaded
 **                  ERROR in case of any error (or load balancing not used)
 **/
int16_t VCCM_CheckCellOverloadStatus(const callInfo_type *const ptCi, const uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    sonCellPrbRsc_type *ptCellPrb = &pCell->cellRscInfo;

    // Check Load balancing usage
    if (not VCCB_IsLbFeatureEnabled(*ptCi, *pCell))
    {
        return ERROR;
    }

    // Check Serving Cell Load depending on loadEvaluateMode
    const auto loadEvaluateMode = VCCB_LB_GetLoadEvaluateMode(*ptCi, *pCell);
    if (loadEvalMode_resource == loadEvaluateMode)
    {
        const auto threshold    = VCCB_LB_GetMaxAvailableResourceThreshold(*ptCi, *pCell);
        const auto servCellLoad = MIN(ptCellPrb->dlCapacityValue, ptCellPrb->ulCapacityValue);
        if (servCellLoad < threshold)
        {
            return BREAK;
        }
    }
    else if (loadEvalMode_ue == loadEvaluateMode)
    {
        const auto threshold = VCCB_LB_GetMaxAvailableUeThreshold(*ptCi, *pCell);
        if (ptCellPrb->numAvailUe < threshold)
        {
            return BREAK;
        }
    }
    else
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "%s: unhandled loadEvaluateMode(%u).", __FUNCTION__, loadEvaluateMode);
    }

    return GOOD;
}

int16_t VCCM_IsServingCellOverloaded_AvailRscSaLb_RedCap(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, LB_LOAD_NOT_AVAILABLE);

    auto cellNum = ptCi->servCellNum;
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    connModeLBInfo_type *ptConnInfo = &pCell->lbCfg.connModeLbInfo;
    sonCellPrbRsc_type *ptCellPrb = &pCell->cellRscInfo;

    uint8_t servCellAvailRsc = 0;
    uint8_t availThreshold = 0;

    uint8_t temp1_max = MAX(ptConnInfo->redCapUeLbInfo.availRscThreshold, ptConnInfo->redCapUeLbInfo.availRscThreshold1);
    uint8_t temp2_max = MAX(ptConnInfo->redCapUeLbInfo.availRscThreshold2, ptConnInfo->redCapUeLbInfo.availRscThreshold3);
    availThreshold = MAX(temp1_max, temp2_max);

    if (FnVCCB_GetCellAvailableResource_RedCap(*ptCellPrb, *ptConnInfo, servCellAvailRsc) == LB_LOAD_NOT_AVAILABLE)
    {
        VCCB_PRINT_LOG_SA_LB(ptCi,
            "[RedCap LB] (Serving/Not_Available) Invalid Capacity Value dlCapacityValueRedcap(%d)/ulCapacityValueRedcap(%d)\n",
            ptCellPrb->dlCapacityValueRedcap, ptCellPrb->ulCapacityValueRedcap);
        return LB_LOAD_NOT_AVAILABLE;  // N/A
    }

    if (IsValidPrbRange(servCellAvailRsc) && IsValidPrbRange(availThreshold))
    {
        if (servCellAvailRsc < availThreshold)
        {
            VCCB_PRINT_LOG_SA_LB(ptCi,
                "[RedCap LB] (Serving/Overload) RESOURCE load (opt:%d)(servAvailRsc(%d)<availTh(%d))\n",
                ptConnInfo->resourceModeOption, servCellAvailRsc, availThreshold);
            return LB_LOAD_OVERLOAD;  // Overload
        }
        else
        {
            VCCB_PRINT_LOG_SA_LB(ptCi,
                "[RedCap LB] (Serving/Normal) RESOURCE load (opt:%d)(servAvailRsc(%d)>=availTh(%d))\n",
                ptConnInfo->resourceModeOption, servCellAvailRsc, availThreshold);
            return LB_LOAD_NOT_OVERLOAD;  // Not overload
        }
    }

    return LB_LOAD_NOT_AVAILABLE; // N/A
}

int16_t FnVCCB_IsServingCellOverloaded_AvailRscSaLb(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, LB_LOAD_NOT_AVAILABLE);

    auto cellNum = ptCi->servCellNum;
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    uint8_t redCapOperationMode = pCell->lbCfg.connModeLbInfo.redCapOperationMode;
    if (IS_REDCAP_UE(ptCi) && redCapOperationMode == access_s5gtype_disable)
    {
        // no action
        return LB_LOAD_NOT_AVAILABLE;
    }
    else if (IS_REDCAP_UE(ptCi) && redCapOperationMode == access_s5gtype_redcap_specific)
    {
        // redcap specific action
        return VCCM_IsServingCellOverloaded_AvailRscSaLb_RedCap(ptCi);
    }
    else
    {
        // normal action
        return VCCM_IsServingCellOverloaded_AvailRscLb(ptCi);
    }
}

/**
 * @brief [FGR-LC0703] Load Balancing between FR1 Carriers (FR50)
 *        [FGR-LC0708] Load based PSCell Change for EN-DC (FR30)
 * @details Check if serving cell is overloaded based on available resource for HO target selection
 * @param [in] pointer of callInfo_type, srType, usedFreq
 * @return LB_LOAD_OVERLOAD(Overload) / LB_LOAD_NOT_OVERLOAD(Not overload) / LB_LOAD_NOT_AVAILABLE(N/A)
 */
int16_t VCCM_IsServingCellOverloaded_AvailRscByPriorGroupLb(callInfo_type *ptCi, enumRSType rsType, uint32_t usedFreq)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, LB_LOAD_NOT_AVAILABLE);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->servCellNum, MAX_CELL_NUM_VCCB, LB_LOAD_NOT_AVAILABLE);

    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];
    connModeLBInfo_type *ptConnInfo = &pCell->lbCfg.connModeLbInfo;
    sonCellPrbRsc_type *ptCellPrb = &pCell->cellRscInfo;

    // Check Load balancing usage
    if (not VCCB_IsLbFeatureEnabled(*ptCi, *pCell))
    {
        return LB_LOAD_NOT_AVAILABLE; // N/A
    }

    if(rsType != RSType_SSB)
    {
        return LB_LOAD_NOT_AVAILABLE;
    }

    // Check available resource condition based on MO LB prioirty group
    for (uint8_t objIdx = 0; objIdx < MAX_NR_OF_OBJECT_ID_DB; ++objIdx)
    {
        measurementObjectNRBaseDb_type *ptMO = &pCell->measurementsData.measurementObjectsNRDb[objIdx].base;

        if (ptMO->usage != CI_use) continue;

        if (ptMO->ssbFrequency == usedFreq)

        {
            if (LB_LOAD_OVERLOAD == FnVCCB_Check_LoadBalancingPriorityGroup(ptCi, ptMO, objIdx, ptConnInfo, ptCellPrb))
            {
                return LB_LOAD_OVERLOAD; // overload
            }
        }
    }

    return LB_LOAD_NOT_OVERLOAD; // Not overload
}

/**
 * @brief [FGR-LC0703] Load Balancing between FR1 Carriers (FR50)
 *        [FGR-LC0708] Load based PSCell Change for EN-DC (FR50)
 * @details Check if serving cell is overloaded and set required target cell load check type
 * @param [in] pointer of callInfo_type, rsType, usedFreq
 * @return GOOD/ERROR
 */
void VCCM_CheckServingCellOverloadForTargetSelection(
    callInfo_type *ptCi, uint8_t *targetCellLoadCheckType, enumRSType rsType, uint32_t usedFreq, int16_t isServingPdcchOverloaded)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(targetCellLoadCheckType);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];

    if (VCCM_IsServingCellOverloaded_AvailRscByPriorGroupLb(ptCi, rsType, usedFreq) == LB_LOAD_OVERLOAD)
    {
        *targetCellLoadCheckType |= LB_LOAD_CHECK_AVAIL_RSC;

        if (VCCB_LB_IsPdcchCceBasedLoadEvaluateSupport(*ptCi, *pCell))
        {
            *targetCellLoadCheckType |= LB_LOAD_CHECK_PDCCH_CCE;
        }
    }
    else if (isServingPdcchOverloaded == LB_LOAD_OVERLOAD)
    {
        *targetCellLoadCheckType |= LB_LOAD_CHECK_PDCCH_CCE;
    }

    if (*targetCellLoadCheckType == LB_LOAD_CHECK_NONE)
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[LB] Not need to check target cell load (Serving is normal) \n");
    }
    else
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[LB] Required load check type for target freq(%d) (Rsc:%s/Pdcch:%s) \n",
            usedFreq,
            (*targetCellLoadCheckType & LB_LOAD_CHECK_AVAIL_RSC)? "T":"F",
            (*targetCellLoadCheckType & LB_LOAD_CHECK_PDCCH_CCE)? "T":"F");
    }

    return;
}

/**
 * @brief [FGR-LC0703] Load Balancing between FR1 Carriers (FR90)
 *        [FGR-LC0708] Load based PSCell Change for EN-DC (FR50)
 * @details Check if target cell is overloaded based on PDCCH CCE failRate/usage
 * @param [in] pointer of callInfo_type, rsType, usedFreq
 * @return LB_LOAD_OVERLOAD(Overload) / LB_LOAD_NOT_OVERLOAD(Not overload) / LB_LOAD_NOT_AVAILABLE(N/A)
 */
int16_t VCCM_IsTargetCellOverloaded_PdcchCceLb(callInfo_type *ptCi, uint16_t nbrCellIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, LB_LOAD_NOT_AVAILABLE);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->servCellNum, MAX_CELL_NUM_VCCB, LB_LOAD_NOT_AVAILABLE);
    VCCB_CHECK_E_RANGE_AND_VAL(nbrCellIdx, MAX_NBR_PER_CELL, LB_LOAD_NOT_AVAILABLE);


    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];
    sonNbrPrbRsc_type *ptNbrRsc = &pCell->cellRscInfo.nbrPrb[nbrCellIdx];

    // Check Load balancing usage
    if (not VCCB_IsLbFeatureEnabled(*ptCi, *pCell))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "%s: LB feature disabled.\n", __FUNCTION__);
        return LB_LOAD_NOT_AVAILABLE;  // N/A
    }

    if (not VCCB_LB_IsPdcchCceBasedLoadEvaluateSupport(*ptCi, *pCell))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "%s: PDCCH CCE condition check disabled.\n", __FUNCTION__);
        return LB_LOAD_NOT_AVAILABLE;  // N/A
    }

    if (ON != ptNbrRsc->isRsUpdate)
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "%s: NBR(%u) has no resource info.\n", __FUNCTION__, nbrCellIdx);
        return LB_LOAD_NOT_AVAILABLE;  // N/A
    }

    if ((ptNbrRsc->ulCceFailRate != NOT_UPDATED) && (ptNbrRsc->dlCceUsage != NOT_UPDATED) && (ptNbrRsc->ulCceUsage != NOT_UPDATED))
    {
        const auto targetUlCceFailureRateThreshold = VCCB_LB_GetTargetUlCceFailureRateThreshold(*ptCi, *pCell);
        const auto targetPdcchCceUsageThreshold    = VCCB_LB_GetTargetPdcchCceUsageThreshold(*ptCi, *pCell);

        if ((ptNbrRsc->ulCceFailRate < targetUlCceFailureRateThreshold) &&
            ((ptNbrRsc->dlCceUsage + ptNbrRsc->ulCceUsage) < targetPdcchCceUsageThreshold))
        {
            VCCB_PRINT_LOG_SA_LB(ptCi,
                "[LB] (Target/Normal) PDCCH CCE load (ulFailRate(rate(%d)<Th(%d) && usage(dl(%d)+ul(%d)<Th(%d))\n",
                ptNbrRsc->ulCceFailRate, targetUlCceFailureRateThreshold,
                ptNbrRsc->dlCceUsage, ptNbrRsc->ulCceUsage, targetPdcchCceUsageThreshold);
            return LB_LOAD_NOT_OVERLOAD; // Not overload
        }
        else
        {
            VCCB_PRINT_LOG_SA_LB(ptCi,
                "[LB] (Target/Overload) PDCCH CCE load (ulFailRate(rate(%d)>=Th(%d) || usage(dl(%d)+ul(%d)>=Th(%d))\n",
                ptNbrRsc->ulCceFailRate, targetUlCceFailureRateThreshold,
                ptNbrRsc->dlCceUsage, ptNbrRsc->ulCceUsage, targetPdcchCceUsageThreshold);
            return LB_LOAD_OVERLOAD; // Overload
        }
    }
    else
    {
        VCCB_PRINT_LOG_SA_LB(ptCi,
            "[LB] (Target/Error) PDCCH CCE load (ulCceFailRate(%d)/dlCceUsage(%d)/ulCceUsage(%d)\n",
            ptNbrRsc->ulCceFailRate, ptNbrRsc->dlCceUsage, ptNbrRsc->ulCceUsage);
    }

    return LB_LOAD_NOT_AVAILABLE; // N/A
}

int16_t VCCM_IsTargetCellOverloaded_PdcchCceLb_RedCap(callInfo_type *ptCi, uint16_t nbrCellIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, LB_LOAD_NOT_AVAILABLE);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->servCellNum, MAX_CELL_NUM_VCCB, LB_LOAD_NOT_AVAILABLE);
    VCCB_CHECK_E_RANGE_AND_VAL(nbrCellIdx, MAX_NBR_PER_CELL, LB_LOAD_NOT_AVAILABLE);

    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];
    connModeLBInfo_type *ptConnInfo = &pCell->lbCfg.connModeLbInfo;

    // Get Target CellNum via NBR Cell Index
    uint16_t targetCellNum = FnVCCB_GetCellNumFromNbrInfo(pCell->Nbr[nbrCellIdx]);
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(targetCellNum, LB_LOAD_NOT_AVAILABLE);
    VccbCellInfo_type *pTargetCell = &CELLINFO[targetCellNum];
    sonCellPrbRsc_type *ptTargetCellPrb = &pTargetCell->cellRscInfo;

    if (enabled != ptConnInfo->pdcchCceBasedLoadEvaluateSupport)
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "%s: PDCCH CCE condition check disabled.\n", __FUNCTION__);
        return LB_LOAD_NOT_AVAILABLE;  // N/A
    }

    // Check Load balancing usage
    if (not VCCB_IsLbFeatureEnabled(*ptCi, *pCell))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "%s: LB feature disabled.\n", __FUNCTION__);
        return LB_LOAD_NOT_AVAILABLE;  // N/A
    }

    bool isRedCapCceUpdated = (ptTargetCellPrb->ulCceFailRateRedcap != NOT_UPDATED && ptTargetCellPrb->dlCceUsageRedcap != NOT_UPDATED && ptTargetCellPrb->ulCceUsageRedcap != NOT_UPDATED);
    bool isNormalCceUpdated = (ptTargetCellPrb->dlCceUsage != NOT_UPDATED && ptTargetCellPrb->ulCceUsage != NOT_UPDATED);

    if (isRedCapCceUpdated && isNormalCceUpdated)
    {
        int16_t normalUsage = static_cast<int16_t>(ptTargetCellPrb->dlCceUsage + ptTargetCellPrb->ulCceUsage);
        int16_t redCapUsage = static_cast<int16_t>(ptTargetCellPrb->dlCceUsageRedcap + ptTargetCellPrb->ulCceUsageRedcap);

        if ((ptTargetCellPrb->ulCceFailRateRedcap < ptConnInfo->redCapUeLbInfo.targetUlCceFailureRateThreshold) &&
            (MAX(normalUsage, redCapUsage) < ptConnInfo->redCapUeLbInfo.targetPdcchCceUsageThreshold))
        {
            VCCB_PRINT_LOG_SA_LB(ptCi,
                "[RedCap LB] (Target/Normal) PDCCH CCE load (ulFailRate(rate(%d)<Th(%d) && usage(max(normalUsage(%d), redCapUsage(%d))<Th(%d))\n",
                ptTargetCellPrb->ulCceFailRateRedcap, ptConnInfo->redCapUeLbInfo.targetUlCceFailureRateThreshold,
                normalUsage, redCapUsage, ptConnInfo->redCapUeLbInfo.targetPdcchCceUsageThreshold);
            return LB_LOAD_NOT_OVERLOAD; // Not overload
        }
        else
        {
            VCCB_PRINT_LOG_SA_LB(ptCi,
                "[RedCap LB] (Target/Overload) PDCCH CCE load (ulFailRate(rate(%d)>=Th(%d) || usage(max(normalUsage(%d), redCapUsage(%d))>=Th(%d))\n",
                ptTargetCellPrb->ulCceFailRateRedcap, ptConnInfo->redCapUeLbInfo.targetUlCceFailureRateThreshold,
                normalUsage, redCapUsage, ptConnInfo->redCapUeLbInfo.targetPdcchCceUsageThreshold);
            return LB_LOAD_OVERLOAD; // Overload
        }
    }
    else
    {
        VCCB_PRINT_LOG_SA_LB(ptCi,
            "[RedCap LB] (Target/Error) PDCCH CCE load "
            "ulCceFailRate_RedCap(%d)/dlCceUsage_RedCap(%d)/ulCceUsage_RedCap(%d)/dlCceUsage(%d)/ulCceUsage(%d)\n",
            ptTargetCellPrb->ulCceFailRateRedcap, ptTargetCellPrb->dlCceUsageRedcap, ptTargetCellPrb->ulCceUsageRedcap, ptTargetCellPrb->dlCceUsage, ptTargetCellPrb->ulCceUsage);
    }

    return LB_LOAD_NOT_AVAILABLE; // N/A
}

int16_t FnVCCB_IsTargetCellOverloaded_PdcchCceLb(callInfo_type *ptCi, uint16_t nbrCellIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, LB_LOAD_NOT_AVAILABLE);

    auto cellNum = ptCi->servCellNum;
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    uint8_t redCapOperationMode = pCell->lbCfg.connModeLbInfo.redCapOperationMode;
    if (IS_REDCAP_UE(ptCi) && redCapOperationMode == access_s5gtype_disable)
    {
        // no action
        return LB_LOAD_NOT_AVAILABLE;
    }
    else if (IS_REDCAP_UE(ptCi) && redCapOperationMode == access_s5gtype_redcap_specific)
    {
        // redcap specific action
        return VCCM_IsTargetCellOverloaded_PdcchCceLb_RedCap(ptCi, nbrCellIdx);
    }
    else
    {
        // normal action
        return VCCM_IsTargetCellOverloaded_PdcchCceLb(ptCi, nbrCellIdx);
    }
}

/**
 * @brief Returns TRUE if the target cell is overloaded based on load condition.
 * 
 * @param call info
 * @param servCellAvailRsc either serving cell available resource or available UEs
 * @param tgtCellAvailRsc either target cell available resource or available UEs
 * @param delta value from LB configuration
 * @param connInfo used to log debug info
 * @return int16_t LB_LOAD_OVERLOAD(overloaded)/LB_LOAD_NOT_OVERLOAD(normal)
 */
int16_t VCCM_IsTargetCellOverloaded_AvailRscLb_Check(const callInfo_type &call, int servCellAvailRsc,
    int tgtCellAvailRsc, int delta, enumLbResourceModeOption_type resourceModeOption,
    enumLoadEvalMode_Type loadEvaluateMode)
{
    AUTO_TRACE_FUNC;

    // FGR-LC0708 - NSA LB has slightly different overload condition than SA.
    // FGR-LC0703 as well from SVR26A
    if (tgtCellAvailRsc > (servCellAvailRsc + delta))
    {
        VCCB_PRINT_LOG_SA_LB(&call,
                "[LB] (Target/Normal) RESOURCE load (mode:%d/opt:%d)(tgtAvail(%d)>servAvail(%d)+delta(%d))\n",
                loadEvaluateMode, resourceModeOption, tgtCellAvailRsc, servCellAvailRsc, delta);
        return LB_LOAD_NOT_OVERLOAD;  // Not overload
    }
    else
    {
        VCCB_PRINT_LOG_SA_LB(&call,
                "[LB] (Target/Overload) RESOURCE load (mode:%d/opt:%d)(tgtAvail(%d)<=servAvail(%d)+delta(%d))\n",
                loadEvaluateMode, resourceModeOption, tgtCellAvailRsc, servCellAvailRsc, delta);
        return LB_LOAD_OVERLOAD;  // Overload
    }
}

/**
 * @brief [FGR-LC0703] Load Balancing between FR1 Carriers (FR50)
 *        [FGR-LC0708] Load based PSCell Change for EN-DC (FR50)
 * @details Check if target cell is overloaded based on available resource load
 * @param [in] pointer of callInfo_type, nbrCellIdx
 * @return LB_LOAD_OVERLOAD(Overload) / LB_LOAD_NOT_OVERLOAD(Not overload) / LB_LOAD_NOT_AVAILABLE(N/A)
 */
int16_t VCCM_IsTargetCellOverloaded_AvailRscLb(callInfo_type *ptCi, uint16_t nbrCellIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, LB_LOAD_NOT_AVAILABLE);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->servCellNum, MAX_CELL_NUM_VCCB, LB_LOAD_NOT_AVAILABLE);
    VCCB_CHECK_E_RANGE_AND_VAL(nbrCellIdx, MAX_NBR_PER_CELL, LB_LOAD_NOT_AVAILABLE);

    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];
    sonCellPrbRsc_type *ptCellPrb = &pCell->cellRscInfo;
    sonNbrPrbRsc_type *ptNbrRsc = &pCell->cellRscInfo.nbrPrb[nbrCellIdx];

    int servCellAvailRsc = 0;
    int tgtCellAvailRsc = 0;
    int delta = 0;

    // Check Load balancing usage
    if (not VCCB_IsLbFeatureEnabled(*ptCi, *pCell))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "%s: LB feature disabled.\n", __FUNCTION__);
        return LB_LOAD_NOT_AVAILABLE;  // N/A
    }

    if (ON != ptNbrRsc->isRsUpdate)
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "%s: NBR(%u) has no resource info.\n", __FUNCTION__, nbrCellIdx);
        return LB_LOAD_NOT_AVAILABLE;  // N/A
    }

    const auto resourceModeOption = VCCB_LB_GetResourceModeOption(*ptCi, *pCell);
    const auto loadEvaluateMode = VCCB_LB_GetLoadEvaluateMode(*ptCi, *pCell);
    switch (loadEvaluateMode)
    {
        case loadEvalMode_resource:
            servCellAvailRsc = VCCB_LB_GetCellAvailableResource(
                resourceModeOption, ptCellPrb->dlCapacityValue, ptCellPrb->ulCapacityValue);
            tgtCellAvailRsc = VCCB_LB_GetCellAvailableResource(
                resourceModeOption, ptNbrRsc->dlCapacityValue, ptNbrRsc->ulCapacityValue);
            delta = VCCB_LB_GetResourceDelta(*ptCi, *pCell);
            break;

        case loadEvalMode_ue:
            servCellAvailRsc = ptCellPrb->numAvailUe;
            tgtCellAvailRsc = ptNbrRsc->numAvailUe;
            delta = VCCB_LB_GetUeDelta(*ptCi, *pCell);
            break;

        case loadEvalMode_effective_resource:
            servCellAvailRsc = VCCB_LB_GetCellEffectiveAvailableResource(resourceModeOption, *ptCellPrb);
            tgtCellAvailRsc  = VCCB_LB_GetCellEffectiveAvailableResource(resourceModeOption, *ptNbrRsc);
            delta            = VCCB_LB_GetEffectiveResourceDelta(*ptCi, *pCell);
            break;

        default:
            return LB_LOAD_NOT_AVAILABLE;  // N/A
    }

    if (IsValidPrbRange(servCellAvailRsc) && IsValidPrbRange(tgtCellAvailRsc) && IsValidDeltaRange(delta, loadEvaluateMode))
    {
        return VCCM_IsTargetCellOverloaded_AvailRscLb_Check(
            *ptCi, servCellAvailRsc, tgtCellAvailRsc, delta, resourceModeOption, loadEvaluateMode);
    }
    else
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[LB] invalid value - servCellAvailRsc(%d), tgtCellAvailRsc(%d), delta(%d).\n",
            servCellAvailRsc, tgtCellAvailRsc, delta);
    }

    return LB_LOAD_NOT_AVAILABLE;  // N/A
}

int16_t VCCM_IsTargetCellOverloaded_AvailRscLb_RedCap(callInfo_type *ptCi, uint16_t nbrCellIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, LB_LOAD_NOT_AVAILABLE);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->servCellNum, MAX_CELL_NUM_VCCB, LB_LOAD_NOT_AVAILABLE);
    VCCB_CHECK_E_RANGE_AND_VAL(nbrCellIdx, MAX_NBR_PER_CELL, LB_LOAD_NOT_AVAILABLE);

    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];
    connModeLBInfo_type *ptConnInfo = &pCell->lbCfg.connModeLbInfo;
    sonCellPrbRsc_type *ptCellPrb = &pCell->cellRscInfo;

    // Get Target CellNum via NBR Cell Index
    uint16_t targetCellNum = FnVCCB_GetCellNumFromNbrInfo(pCell->Nbr[nbrCellIdx]);
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(targetCellNum, LB_LOAD_NOT_AVAILABLE);
    VccbCellInfo_type *pTargetCell = &CELLINFO[targetCellNum];
    sonCellPrbRsc_type *ptTargetCellPrb = &pTargetCell->cellRscInfo;

    // Check Load balancing usage
    if (not VCCB_IsLbFeatureEnabled(*ptCi, *pCell))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "%s: LB feature disabled.\n", __FUNCTION__);
        return LB_LOAD_NOT_AVAILABLE;  // N/A
    }

    uint8_t servCellAvailRsc = 0, tgtCellAvailRsc = 0;
    if (FnVCCB_GetCellAvailableResource_RedCap(*ptCellPrb, *ptConnInfo, servCellAvailRsc) == LB_LOAD_NOT_AVAILABLE)
    {
        VCCB_PRINT_LOG_SA_LB(ptCi,
            "[RedCap LB] Invalid Capacity Value (serving)dlCapacityValueRedcap(%d)/ulCapacityValueRedcap(%d)\n",
            ptCellPrb->dlCapacityValueRedcap, ptCellPrb->ulCapacityValueRedcap);
        return LB_LOAD_NOT_AVAILABLE;  // N/A
    }
 
    if (FnVCCB_GetCellAvailableResource_RedCap(*ptTargetCellPrb, *ptConnInfo, tgtCellAvailRsc) == LB_LOAD_NOT_AVAILABLE)
    {
        VCCB_PRINT_LOG_SA_LB(ptCi,
            "[RedCap LB] Invalid Capacity Value (target)dlCapacityValueRedcap(%d)/ulCapacityValueRedcap(%d)\n",
            ptTargetCellPrb->dlCapacityValueRedcap, ptTargetCellPrb->ulCapacityValueRedcap);
        return LB_LOAD_NOT_AVAILABLE;  // N/A
    }

    uint8_t delta = FnVCCB_GetResourceDelta(*pCell, IS_REDCAP_UE(ptCi));

    if (IsValidPrbRange(servCellAvailRsc) && IsValidPrbRange(tgtCellAvailRsc) && IsValidDeltaRange(delta, loadEvalMode_resource))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[RedCap LB] RESOURCE load (opt:%d)(tgtAvail(%d), servAvail(%d), delta(%d))\n",
            ptConnInfo->resourceModeOption, tgtCellAvailRsc, servCellAvailRsc, delta);

        const auto resourceModeOption = VCCB_LB_GetResourceModeOption(*ptCi, *pCell);
        return VCCM_IsTargetCellOverloaded_AvailRscLb_Check(
            *ptCi, servCellAvailRsc, tgtCellAvailRsc, delta, resourceModeOption, loadEvalMode_resource);
    }

    return LB_LOAD_NOT_AVAILABLE;  // N/A
}

int16_t FnVCCB_IsTargetCellOverloaded_AvailRscLb(callInfo_type *ptCi, uint16_t nbrCellIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, LB_LOAD_NOT_AVAILABLE);
    VCCB_CHECK_E_RANGE_AND_VAL(nbrCellIdx, MAX_NBR_PER_CELL, LB_LOAD_NOT_AVAILABLE);

    auto cellNum = ptCi->servCellNum;
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    uint8_t redCapOperationMode = pCell->lbCfg.connModeLbInfo.redCapOperationMode;
    if (IS_REDCAP_UE(ptCi) && redCapOperationMode == access_s5gtype_disable)
    {
        // no action
        return LB_LOAD_NOT_AVAILABLE;
    }
    else if (IS_REDCAP_UE(ptCi) && redCapOperationMode == access_s5gtype_redcap_specific)
    {
        // redcap specific action
        return VCCM_IsTargetCellOverloaded_AvailRscLb_RedCap(ptCi, nbrCellIdx);
    }
    else
    {
        // normal action
        return VCCM_IsTargetCellOverloaded_AvailRscLb(ptCi, nbrCellIdx);
    }
}

/**
 * @brief [FGR-LC0703] Load Balancing between FR1 Carriers (FR35/FR110)
 * @details Check if the LB is in operation by FGR-LC0710
 * @param [in] pointer of callInfo_type
 * @return TRUE/FALSE
 */
uint8_t VCCM_CheckLbByNSSAI(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    uint8_t isLbTriggeredByNSSAI = FALSE;

    VCCB_CHECK_E_RANGE_AND_FALSE(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (IS_TIMER_VALID(ptCi->sliceAwareLbInfo.waitTimer))
    {
        isLbTriggeredByNSSAI = TRUE;
    }
    else if (ptCi->sliceAwareLbInfo.tgtSliceIdx < MAX_ACTIVE_SLICE_NUM)
    {
        isLbTriggeredByNSSAI = TRUE;
    }
    else if ((pGnb->sliceAwareLbInfo.sliceLbswitch == TRUE) &&
             (FnVCCB_CheckConfiguredLbSliceList(ptCi) == GOOD) &&
             (ptCi->sliceAwareLbDecisionCount < MAX_SLICE_LB_DECISION))
    {
        isLbTriggeredByNSSAI = TRUE;
    }

    return isLbTriggeredByNSSAI; // N/A
}

/**
 * @brief [FGR-LC0703] Load Balancing between FR1 Carriers
 * @details Check if the cell is overlaod based on MO LB priority group
 * @param [in] pointer of measurementObjectNRBaseDb_type, pointer of connModeLBInfo_type, pointer of sonCellPrbRsc_type
 * @return LB_LOAD_OVERLOAD(overload) / LB_LOAD_NOT_AVAILABLE(not overload or N/A)
 */
int8_t VCCM_Check_LoadBalancingPriorityGroup(const measurementObjectNRBaseDb_type *ptMO, const uint8_t measObjectIdx,
    const sonCellPrbRsc_type *ptCellPrb, const callInfo_type &rCall, const VccbCellInfo_type &cellInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptMO, LB_LOAD_NOT_AVAILABLE);
    VALID_E_POINT_CHECK_RET_VAL(ptCellPrb, LB_LOAD_NOT_AVAILABLE);

    int thresholdValue = 0, cellAvailRsc = 0;

    const auto grpNum = VCCB_LB_GetThresholdGroup(rCall, cellInfo, *ptMO, measObjectIdx);
    if (MAX_LB_PRIOR_GRP <= grpNum)
    {
        VCCB_PRINT_LOG_SA_LB(&rCall, "[LB] (Serving/Not_Available) Invalid Threshold Group (grpNum:%d)\n", grpNum);
        return LB_LOAD_NOT_AVAILABLE;
    }

    const auto resourceModeOption = VCCB_LB_GetResourceModeOption(rCall, cellInfo);
    const auto loadEvaluateMode = VCCB_LB_GetLoadEvaluateMode(rCall, cellInfo);
    switch (loadEvaluateMode)
    {
        case loadEvalMode_resource:
        {
            const auto thresholds = VCCB_LB_GetAvailableResourceThreshold(rCall, cellInfo);
            thresholdValue = thresholds[grpNum];
            cellAvailRsc = VCCB_LB_GetCellAvailableResource(resourceModeOption, ptCellPrb->dlCapacityValue, ptCellPrb->ulCapacityValue);
            break;
        }

        case loadEvalMode_ue:
        {
            const auto thresholds = VCCB_LB_GetAvailableUeThreshold(rCall, cellInfo);
            thresholdValue = thresholds[grpNum];
            cellAvailRsc = ptCellPrb->numAvailUe;
            break;
        }

        case loadEvalMode_effective_resource:
        {
            const auto thresholds = VCCB_LB_GetEffectiveAvailableResourceThreshold(rCall, cellInfo);
            thresholdValue = thresholds[grpNum];
            cellAvailRsc = VCCB_LB_GetCellEffectiveAvailableResource(resourceModeOption, *ptCellPrb);
            break;
        }

        default:
            return LB_LOAD_NOT_AVAILABLE;
    }

    if (IsValidPrbRange(cellAvailRsc) && IsValidPrbRange(thresholdValue))
    {
        if (cellAvailRsc < thresholdValue)
        {
            VCCB_PRINT_LOG_SA_LB(&rCall,
                "[LB] (Serving/Overload) RESOURCE load (mode:%d/opt:%d)(cellAvailRsc(%d)<thresholdValue(%d))\n",
                loadEvaluateMode, resourceModeOption, cellAvailRsc, thresholdValue);
            return LB_LOAD_OVERLOAD;
        }
        else
        {
            VCCB_PRINT_LOG_SA_LB(&rCall,
                "[LB] (Serving/Normal) RESOURCE load (mode:%d/opt:%d)(cellAvailRsc(%d)>=thresholdValue(%d))\n",
                loadEvaluateMode, resourceModeOption, cellAvailRsc, thresholdValue);
            return LB_LOAD_NOT_OVERLOAD;
        }
    }
    else
    {
        VCCB_PRINT_LOG_SA_LB(
            &rCall, "[LB] invalid value - cellAvailRsc(%d), thresholdValue(%d).\n", cellAvailRsc, thresholdValue);
    }

    return LB_LOAD_NOT_AVAILABLE;  // Not overload or N/A
}

int8_t VCCM_Check_LoadBalancingPriorityGroup_RedCap(
    const measurementObjectNRBaseDb_type *ptMO, const uint8_t measObjectIdx, const connModeLBInfo_type *ptConnInfo, const sonCellPrbRsc_type *ptCellPrb, const callInfo_type &rCall, const VccbCellInfo_type &cellInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptMO, LB_LOAD_NOT_AVAILABLE);
    VALID_E_POINT_CHECK_RET_VAL(ptConnInfo, LB_LOAD_NOT_AVAILABLE);
    VALID_E_POINT_CHECK_RET_VAL(ptCellPrb, LB_LOAD_NOT_AVAILABLE);

    uint8_t thresholdValue = 0;
    uint8_t cellAvailRsc = 0;

    uint8_t arrRscTh[MAX_LB_PRIOR_GRP] = {
        ptConnInfo->redCapUeLbInfo.availRscThreshold,
        ptConnInfo->redCapUeLbInfo.availRscThreshold1,
        ptConnInfo->redCapUeLbInfo.availRscThreshold2,
        ptConnInfo->redCapUeLbInfo.availRscThreshold3 };

    uint8_t grpNum = FnVCCB_GetLbThresholdGroup(cellInfo, *ptMO, measObjectIdx, IS_REDCAP_UE(&rCall));

    if (grpNum >= MAX_LB_PRIOR_GRP)
        return LB_LOAD_NOT_AVAILABLE;

    thresholdValue = arrRscTh[grpNum];

    if (FnVCCB_GetCellAvailableResource_RedCap(*ptCellPrb, *ptConnInfo, cellAvailRsc) == LB_LOAD_NOT_AVAILABLE)
    {
        VCCB_PRINT_LOG_SA_LB(&rCall,
            "[RedCap LB] (Serving/Not_Available) Invalid Capacity Value dlCapacityValueRedcap(%d)/ulCapacityValueRedcap(%d)\n",
            ptCellPrb->dlCapacityValueRedcap, ptCellPrb->ulCapacityValueRedcap);
        return LB_LOAD_NOT_AVAILABLE;  // N/A
    }

    if (IsValidPrbRange(cellAvailRsc) && IsValidPrbRange(thresholdValue))
    {
        if (cellAvailRsc < thresholdValue)
        {
            VCCB_PRINT_LOG_SA_LB(&rCall,
                "[RedCap LB] (Serving/Overload) RESOURCE load (opt:%d)(cellAvailRsc(%d)<thresholdValue(%d))\n",
                ptConnInfo->resourceModeOption, cellAvailRsc, thresholdValue);
            return LB_LOAD_OVERLOAD; // Overload
        }
    }

    VCCB_PRINT_LOG_SA_LB(&rCall,
        "[RedCap LB] (Serving/Not_Available) Invalid Value or Not Overload (opt:%d)(cellAvailRsc(%d), thresholdValue(%d))\n",
        ptConnInfo->resourceModeOption, cellAvailRsc, thresholdValue);
    return LB_LOAD_NOT_AVAILABLE; // Not overload or N/A
}

int8_t FnVCCB_Check_LoadBalancingPriorityGroup(const callInfo_type *ptCi, const measurementObjectNRBaseDb_type *ptMO,
    const uint8_t measObjectIdx, const connModeLBInfo_type *ptConnInfo, const sonCellPrbRsc_type *ptCellPrb)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, LB_LOAD_NOT_AVAILABLE);
    VALID_E_POINT_CHECK_RET_VAL(ptMO, LB_LOAD_NOT_AVAILABLE);
    VALID_E_POINT_CHECK_RET_VAL(ptConnInfo, LB_LOAD_NOT_AVAILABLE);
    VALID_E_POINT_CHECK_RET_VAL(ptCellPrb, LB_LOAD_NOT_AVAILABLE);

    auto cellNum = ptCi->servCellNum;
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    uint8_t redCapOperationMode = pCell->lbCfg.connModeLbInfo.redCapOperationMode;
    if (IS_REDCAP_UE(ptCi) && redCapOperationMode == access_s5gtype_disable)
    {
        // no action
        return LB_LOAD_NOT_AVAILABLE;
    }
    else if (IS_REDCAP_UE(ptCi) && redCapOperationMode == access_s5gtype_redcap_specific)
    {
        // redcap specific action
        return VCCM_Check_LoadBalancingPriorityGroup_RedCap(ptMO, measObjectIdx, ptConnInfo, ptCellPrb, *ptCi, *pCell);
    }
    else
    {
        // normal action
        return VCCM_Check_LoadBalancingPriorityGroup(ptMO, measObjectIdx, ptCellPrb, *ptCi, *pCell);
    }
}

/**
 *  @brief This function releases LB measurement(make LB state LB_MEAS_STATE_NOT_SELECTED) when the LB timer expires.
 *  @param callInfo_type* ptCi
 *  @return int16_t GOOD/break (1/0)
 */
int16_t VCCB_LbMrWaitTimerAction(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, BREAK);

    VCCB_CLEAR_TIMER(&ptCi->lbMrTimer, INIT_TIMER);
    ptCi->periodicLbGuardTimeStamp = tickGetMono();

    FnVCCB_GetSaMeas(*ptCi).lbIFMeasState = LB_MEAS_STATE_NOT_SELECTED;
    ptCi->saPrevInfo.saMeas.lbIFMeasState = LB_MEAS_STATE_NOT_SELECTED;
    ptCi->nsaMeas.nsaLbMeasState = NSA_LB_MEAS_STATE_INACTIVE;

    if (VCCB_CheckLbMeasActivated(*ptCi))
    {
        if (!VCCM_IsUeIdleState(ptCi->callType, ptCi->state))
        {
            if (ERROR == VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_LB_MEAS_DEACTIVE))
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "VCCM_enqueueAction(ENQUEUE_ACTION_LB_MEAS_DEACTIVE) fail\n");
                return ERROR;
            }
        }
        else  // if UE is IDLE state,
        {
            if (ERROR == VCCM_TriggerMeasReconfig(ptCi))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_TriggerMeasReconfig ERROR!\n");
                return ERROR;
            }
        }
    }

    // Process LB timer only in ALL handle.
    return BREAK;
}  // }}}

bool FnVCCB_CheckDropConditionForLbMr(callInfo_type *ptCi, const enumMeasurementReportType reportType, const uint8_t reportPurpose)
{
    AUTO_TRACE_FUNC;

    if ((reportType == measReport_A4 && reportPurpose == a4Purpose_NRLoadBalancing) ||
        (reportType == measReport_A5 && reportPurpose == a5Purpose_NRLoadBalancing))
    {
        VALID_E_POINT_CHECK_RET_VAL(ptCi, true);

        if (FnVCCB_GetSaMeas(*ptCi).lbIFMeasState == LB_MEAS_STATE_NOT_SELECTED)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "FGR-LC0703 lbMeasState not selected\n");
            LB_INIT_MEAS_STATE(ptCi);
            return true;
        }

        if (TRUE != VCCM_CheckLoadBalancingTrigger(ptCi))
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "FGR-LC0703 Load Balancing cannot be triggered\n");
            return true;
        }
    }

    return false;
}

// }}}

/****************************************************************************
    [FGR-LC0711] NR Inter-RAT Load Balancing to LTE
****************************************************************************/
// {{{

uint8_t FnVCCM_CheckServingCellResourceLoadInfoForIratLbHo(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);
    saMeasStateInfo_type &rSaMeasState = FnVCCB_GetSaMeas(*ptCi);

    if (rSaMeasState.iratLbHoTriggered == VCCB_FLAG_ON)
    {
        VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] IRAT LB Overload Already Checked\n");
        return TRUE;
    }

    VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] Triggering IRAT LB\n");
    IRAT_LB_INIT_MEAS_STATE(ptCi);
    rSaMeasState.iratLbHoTriggered = VCCB_FLAG_ON;

    rSaMeasState.iratLbHoState = FnVCCM_CheckOverLoadForIratLbHo(ptCi, cellNum);
    if(rSaMeasState.iratLbHoState == LB_MEAS_STATE_SELECTED)
    {
        VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] IRAT LB Triggered\n");
        FnVCCM_SetIratLbMrWaitTimer(ptCi);
        return TRUE;
    }

    return FALSE;
}

uint8_t FnVCCM_CheckOverLoadForIratLbHo(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, LB_MEAS_STATE_NOT_SELECTED);
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, LB_MEAS_STATE_NOT_SELECTED);

    if (FnVCCM_CheckInterRatLoadBalancingTrigger(ptCi, cellNum) != TRUE)
    {
        VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] Cannot Trigger IRAT LB HO\n");
        return LB_MEAS_STATE_NOT_SELECTED;
    }

    // Check Resource Overload
    if((FnVCCM_CheckOverLoadForIratLbHo_PdcchCce(ptCi, cellNum) != TRUE) &&
        (FnVCCM_CheckOverLoadForIratLbHo_AvailRsc(ptCi, cellNum) != TRUE))
    {
        VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] Serving Cell Not Overloaded\n");
        return LB_MEAS_STATE_NOT_SELECTED;
    }

    VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] Serving Cell Overloaded\n");
    return LB_MEAS_STATE_SELECTED;
}

uint8_t FnVCCM_CheckInterRatLoadBalancingTrigger(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    connModeIratLbInfo_type *ptRatConnInfo = &pCell->lbCfg.connModeIratLbInfo;
    cellRfspSpecificMeasCtrl_type *ptCellRfspSpecificMeasCtrl = &pCell->cellRfspSpecificMeasCtrl;

    // Check Load balancing usage
    if (ptRatConnInfo->usage != VCCB_FLAG_ON)
    {
        VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] IRAT LB Not Used\n");
        return FALSE;
    }

    if ((ptCi->stateCmd == IntraRatHO_cmd) || (ptCi->stateCmd == InterRatHO_cmd))
    {
        VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] Other Handover Triggered\n");
        return FALSE;
    }

    // Check HO ForcedHoRestriction Timer
    if (VHCM_isForcedHoRestriction(ptCi) == TRUE)
    {
        VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] ForcedHoRestrction Timer Running\n");
        return FALSE;
    }

    // VoNR UE
    if (FnVCCB_IsVoNRCall(ptCi))
    {
        VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] VoNR UE \n");
        return FALSE;
    }

    if (VCCM_CheckLbByNSSAI(ptCi))
    {
        VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] Slice Aware LB\n");
        return FALSE;
    }

    // Check for an Emergency Call
    if (VCCM_CheckEmergencyCall(ptCi))
    {
        VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] Emergency Call\n");
        return FALSE;
    }

    // Check RFSP Configured UE
    if (FnVCCB_GetSaMeas(*ptCi).rfspHoSupport)
    {
        VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] RFSP based priority Call Configured\n");
        return FALSE;
    }

    // Check load-balancing-handover-allowed
    if (FnVCCB_IsLoadBalancingHandoverAllowed(ptCi) == FALSE)
    {
        VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] LB HO Not Allowed\n");
        return FALSE;
    }

    // Check nr-to-eutra-handover-not-allowed
    if (FnVCCB_IsNrToEutraHoNotAllowedFromSvcGrp(ptCi) == TRUE) // NR_CON_MC_22C2
    {
        VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] NrToEutraHoNotAllowed TRUE\n");
        return FALSE;
    }

    // SVR24A FGR-LC0711
    // Check support-lb-fp-ho
    if ((FnVCCB_isRfspSpecificUE(ptCi, cellNum) != nullptr) &&
        (ptCellRfspSpecificMeasCtrl->supportLbFpHoUsage != CI_use))
    {
        VCCB_PRINT_LOG_IRAT_LB (ptCi, "[IRATLB] LB FP HO Not Support\n");
        return FALSE;
    }

    // SVR24A FGR-LC0711
    // Check overloaded-level-intra-nr-lb
    if (VCCB_FLAG_ON == CFG->overloadControl.ueSigCpuOverloadControl.ueSigCpuOverloadAction)
    {
        uint8_t overloadedLevelInterRatLb = CFG->overloadControl.ueSigCpuOverloadControl.overloadedLevelInterRatLb;
        VCCB_PRINT_LOG_IRAT_LB (ptCi, "[IRATLB] CPU Ovld(%d), Thd(%d)\n", CFG->overloadStatus, overloadedLevelInterRatLb);
        if (IS_CPC_CPU_OVERLOAD_CONDITION(overloadedLevelInterRatLb))
        {
            VCCB_PRINT_LOG_IRAT_LB (ptCi, "[IRATLB] CPU Overload\n");
            return FALSE;
        }
    }

    return TRUE;
}

uint8_t FnVCCM_CheckOverLoadForIratLbHo_PdcchCce(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    sonCellPrbRsc_type *ptCellPrb = &pCell->cellRscInfo;
    connModeIratLbInfo_type *ptRatConnInfo = &pCell->lbCfg.connModeIratLbInfo;

    // Check PDCCH CCE Overload
    if (ptRatConnInfo->pdcchCceBasedLoadEvaluateSupport == enabled)
    {
        VCCB_PRINT_LOG_IRAT_LB(ptCi,
            "[IRATLB] Target cell PDCCH CCE load : ulFailRate(rate:%d/Th:%f), usage(dl(%d)+ul(%d)/Th:%f)\n",
            ptCellPrb->ulCceFailRate, (double)ptRatConnInfo->ulCceFailureRateThreshold,
            ptCellPrb->dlCceUsage, ptCellPrb->ulCceUsage, (double)ptRatConnInfo->pdcchCceUsageThreshold);

        if ((ptCellPrb->ulCceFailRate != NOT_UPDATED) && (ptCellPrb->dlCceUsage != NOT_UPDATED) && (ptCellPrb->ulCceUsage != NOT_UPDATED))
        {
            if ((static_cast<float>(ptCellPrb->ulCceFailRate) >= ptRatConnInfo->ulCceFailureRateThreshold) &&
                (static_cast<float>(ptCellPrb->dlCceUsage + ptCellPrb->ulCceUsage) >=
                    ptRatConnInfo->pdcchCceUsageThreshold))
            {
                return TRUE;
            }
        }
    }

    return FALSE;
}

uint8_t FnVCCM_CheckOverLoadForIratLbHo_AvailRsc(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    sonCellPrbRsc_type *ptCellPrb = &pCell->cellRscInfo;
    connModeIratLbInfo_type *ptRatConnInfo = &pCell->lbCfg.connModeIratLbInfo;

    uint8_t availThreshold = 0;
    uint8_t availResource = 0;

    if (ptRatConnInfo->loadEvaluateMode == loadEvalMode_resource)
    {
        availThreshold = ptRatConnInfo->availableResourceThreshold;

        switch(ptRatConnInfo->resourceModeOption)
        {
            case LB_RESOURCE_MODE_OPTION_MIN_DL_UL:
                availResource = MIN(ptCellPrb->dlCapacityValue, ptCellPrb->ulCapacityValue);
                break;
            case LB_RESOURCE_MODE_OPTION_DL:
                availResource = ptCellPrb->dlCapacityValue;
                break;
            case LB_RESOURCE_MODE_OPTION_UL:
                availResource = ptCellPrb->ulCapacityValue;
                break;
            default:
                VCCB_PRINT_CALL_ERROR(ptCi, "[IRATLB] Invalid load-evaluate-mode(%d)\n", ptRatConnInfo->resourceModeOption);
                return FALSE;
        }
    }
    else // load-evaluate-mode-ue
    {
        availThreshold = ptRatConnInfo->availableUeThreshold;
        availResource = ptCellPrb->numAvailUe;
    }

    if (availResource >= availThreshold)
    {
        VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] availResource(%d) >= availThreshold(%d)\n", availResource, availThreshold);
        return FALSE;
    }

    VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] availResource(%d) < availThreshold(%d)\n", availResource, availThreshold);
    return TRUE;
}

void FnVCCM_SetIratLbMrWaitTimer(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (FnVCCB_GetSaMeas(*ptCi).iratLbHoState != LB_MEAS_STATE_SELECTED)
    {
        return;
    }

    if (ptCi->iratLbMrWaitTimer.id <= 0)
    {
        VLIB_AttachTimer(&ptCi->iratLbMrWaitTimer, ptCi, timIratLbMrReceived_id);
    }

    VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] iratLbMrWaitTimer Attached\n");
    return;
}

int16_t FnVCCB_IratLbMrWaitTimerAction(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, BREAK);

    VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] iratLbMrWaitTimer TIMEOUT\n");
    VCCB_CLEAR_TIMER(&ptCi->iratLbMrWaitTimer, INIT_TIMER);

    FnVCCB_GetSaMeas(*ptCi).iratLbHoState = LB_MEAS_STATE_NOT_SELECTED;

    if (ERROR == VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_IRAT_LB_MEAS_DEACTIVE))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "VCCM_enqueueAction(ENQUEUE_ACTION_IRAT_LB_MEAS_DEACTIVE) fail\n");
        return ERROR;
    }

    return GOOD;
}  // }}}

// }}}

/****************************************************************************
    [FGR-LC0712] VoNR Load Balancing
****************************************************************************/
// {{{

/**
 * @brief This API is used before configuring measConfig to the UE and after receiving MR for VoNR LB.
 * @details Check condition for VoNR LB (VoNR LB usage, Call type, VoNR UE, Emergency call, CPU overload)
 * @param [in] pointer of callInfo_type
 * @return TRUE(Allowed VoNR LB) / FALSE (Not allowed VoNR LB)
 */
uint8_t FnVCCB_IsAllowedUeForVoNrLoadBalancing(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_VALID_CELLNUM_FALSE(ptCi->servCellNum);

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    voNrLbInfo_type *ptVoNrLbInfo = &pCell->lbCfg.voNrLbInfo;

    // Enabled Feature
    if (ptVoNrLbInfo->usage != VCCB_FLAG_ON)
    {
        VCCB_PRINT_LOG_VONR_LB(ptCi, "[VONRLB] Not Enabled VoNR LB \n");
        return FALSE;
    }

    // Check CallType
    if (E_CALLTYPE_SA != ptCi->callType)
    {
        VCCB_PRINT_LOG_VONR_LB(ptCi, "[VONRLB] Not E_CALLTYPE_SA \n");
        return FALSE;
    }

    // VoNR UE
    if (TRUE != FnVCCB_IsVoNRCall(ptCi))
    {
        VCCB_PRINT_LOG_VONR_LB(ptCi, "[VONRLB] Not VoNR UE \n");
        return FALSE;
    }

    // Emergency Call
    if (VCCM_CheckEmergencyCall(ptCi))
    {
        VCCB_PRINT_LOG_VONR_LB(ptCi, "[VONRLB] Emergency Call\n");
        return FALSE;
    }

    // CPU Overloaded
    if (VCCB_FLAG_ON == CFG->overloadControl.ueSigCpuOverloadControl.ueSigCpuOverloadAction)
    {
        uint8_t overloadedLevelVoNrLb = CFG->overloadControl.ueSigCpuOverloadControl.overloadedLevelVoNrLb;
        VCCB_PRINT_LOG_VONR_LB(ptCi, "[VONRLB] CPU Ovld(%d), Thd(%d)\n", CFG->overloadStatus, overloadedLevelVoNrLb);
        if (IS_CPC_CPU_OVERLOAD_CONDITION(overloadedLevelVoNrLb))
        {
            VCCB_PRINT_LOG_VONR_LB(ptCi, "[VONRLB] CPU Overload\n");
            return FALSE;
        }
    }

    return TRUE;
}

/**
 * @brief [FGR-LC0712] VoNR Load Balancing (FR90)
 * @details Check if serving cell is overloaded based on UL CCE failRate
 * @param [in] pointer of callInfo_type
 * @return TRUE(Overload) / FALSE(Not overload) / ERROR(N/A)
 */
int16_t FnVCCB_IsServingCellOverloadedForVoNrLB(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    voNrLbInfo_type *ptVoNrLbInfo = &pCell->lbCfg.voNrLbInfo;
    sonCellPrbRsc_type *ptCellPrb = &pCell->cellRscInfo;

    // Enabled Feature
    if (ptVoNrLbInfo->usage != VCCB_FLAG_ON)
    {
        VCCB_PRINT_LOG_VONR_LB(ptCi, "[VONRLB] Error: vonr-load-balancing-switch is off(%d)\n", ptVoNrLbInfo->usage);
        return ERROR;  // N/A
    }

    // Only from UL CCE Failure Rate
    if (ptCellPrb->ulCceFailRate != NOT_UPDATED)
    {
        if (ptCellPrb->ulCceFailRate >= ptVoNrLbInfo->ulCceFailureRateThreshold)
        {
            VCCB_PRINT_LOG_VONR_LB(ptCi, "[VONRLB] Serving cell is overloaded. ulCceFailRate(%d) >= Th(%d)\n",
                ptCellPrb->ulCceFailRate, ptVoNrLbInfo->ulCceFailureRateThreshold);
            return TRUE;  // Overload
        }
        else
        {
            VCCB_PRINT_LOG_VONR_LB(ptCi, "[VONRLB] Serving cell is not overloaded. ulCceFailRate(%d) < Th(%d)\n",
                ptCellPrb->ulCceFailRate, ptVoNrLbInfo->ulCceFailureRateThreshold);
            return FALSE;  // Not overload
        }
    }

    VCCB_PRINT_LOG_VONR_LB(ptCi, "[VONRLB] ulCceFailRate is not updated. Serving cell is not overloaded.\n");
    return FALSE;  // Not overload
}

/**
 * @brief [FGR-LC0712] VoNR Load Balancing (FR70)
 * @details Check if neighbor cell can be selected as a target cell based on UL CCE failRate
 * @param [in] ptCi : pointer of callInfo_type
 * @param [in] nbrCellIdx : neighbor cell index
 * @return TRUE(Cell is not overloaded, Selectable cell) / FALSE(Cell is overloaded, Unselectable cell)
 */
uint8_t FnVCCB_IsSelectableTargetCellForVoNrLB(callInfo_type *ptCi, uint16_t nbrCellIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_FALSE(nbrCellIdx, MAX_NBR_RELATION_TABLE_PER_CELL);

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    voNrLbInfo_type *ptVoNrLbInfo = &pCell->lbCfg.voNrLbInfo;
    sonNbrPrbRsc_type *ptNbrRsc = &pCell->cellRscInfo.nbrPrb[nbrCellIdx];

    // Enabled Feature
    if (ptVoNrLbInfo->usage != VCCB_FLAG_ON)
    {
        VCCB_PRINT_LOG_VONR_LB(ptCi, "[VONRLB] Error: vonr-load-balancing-switch is off(%d)\n", ptVoNrLbInfo->usage);
        return FALSE;  // Unselectable cell
    }

    // Only from UL CCE Failure Rate
    if (ptNbrRsc->ulCceFailRate != NOT_UPDATED)
    {
        if (ptNbrRsc->ulCceFailRate >= ptVoNrLbInfo->targetUlCceFailureRateThreshold)
        {
            VCCB_PRINT_LOG_VONR_LB(ptCi,
                "[VONRLB] Target cell is overloaded(nbrIdx:%u). ulCceFailRate(%d) >= Th(%d)\n", nbrCellIdx,
                ptNbrRsc->ulCceFailRate, ptVoNrLbInfo->targetUlCceFailureRateThreshold);
            return FALSE;  // Overload (Unselectable cell)
        }
        else
        {
            VCCB_PRINT_LOG_VONR_LB(ptCi,
                "[VONRLB] Target cell is not overloaded(nbrIdx:%u). ulCceFailRate(%d) < Th(%d)\n", nbrCellIdx,
                ptNbrRsc->ulCceFailRate, ptVoNrLbInfo->targetUlCceFailureRateThreshold);
            return TRUE;  // Not overload (Selectable cell)
        }
    }

    VCCB_PRINT_LOG_VONR_LB(
        ptCi, "[VONRLB] ulCceFailRate is not updated. Target cell is overloaded(nbrIdx:%u).\n", nbrCellIdx);
    return FALSE;  // Overload (Unselectable cell)
}

/**
 * @brief This function update VoNR LB State.
 * @details State : NOT_SUPPORT && VoNR : true -> State : INIT,
 * @details State : (INIT || ACTIVE || INACTIVE) && VoNR : false -> State : NOT_SUPPORT
 * @param [in] ptCi : pointer of callInfo_type
 * @param [in] cellNum : cell number
 */
void FnVCCB_UpdateVoNrLbState(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_VALID_CELLNUM_VOID(cellNum);

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    voNrLbInfo_type *ptVoNrLbInfo = &pCell->lbCfg.voNrLbInfo;

    // Enabled
    if (VCCB_FLAG_ON != ptVoNrLbInfo->usage) return;

    uint8_t isVoNR = (uint8_t)FnVCCB_IsVoNRCall(ptCi);
    uint8_t state = FnVCCB_GetSaMeas(*ptCi).voNrLbState;

    switch (state)
    {
        case VONR_LB_NOT_SUPPORT:
            if (TRUE == isVoNR)
            {
                VCCB_PRINT_LOG_VONR_LB(ptCi, "[VONRLB] %s Non VoNR -> VoNR \n", __func__);
                SET_VONR_LB_INIT_STATE(ptCi);  // Trigger VoNR LB
            }
            break;

        default:  // VONR_LB_INIT, VONR_LB_INACTIVE, VONR_LB_ACTIVE
            if (FALSE == isVoNR)
            {
                VCCB_PRINT_LOG_VONR_LB(ptCi, "[VONRLB] %s VoNR -> Non-VoNR STATE(%d)\n", __func__, state);
                if (VONR_LB_ACTIVE == state)  // Timer cancel
                {
                    VCCB_CLEAR_TIMER(&ptCi->voNrLbMrWaitTimer, CANCEL_TIMER);
                }

                SET_VONR_LB_NOT_SUPPORT_STATE(ptCi);
            }
            break;
    }
}

/**
 * @brief This function removes VoNR LB Measurement Config when Timer is expired.
 * @param [in] ptCi : pointer of callInfo_type
 */
void FnVCCB_DeleteVoNrLbMeasConfig(callInfo_type *ptCi)  // FGR-LC0712
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (TRUE == FnVCCB_CheckMeasInstalledByCallbackId(ptCi, FUN_2_MEASREPORTCALLBACKID(FnVCCB_ProcMrVoNRLoadBalancing)))
    {
        if (ERROR == VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_VONR_LB_MEAS_DEACTIVATE))
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "VCCM_enqueueAction(ENQUEUE_ACTION_VONR_LB_MEAS_DEACTIVATE) fail\n");
        }
    }
}

/**
 * @brief This function will be used when VoNR LB MR wait timer is expired.
 * @details Set VoNR LB state to Inactive, and remove Measurement Config for VoNR LB.
 * @param [in] ptCi : pointer of callInfo_type
 */
int16_t FnVCCB_VoNrLbMrWaitTimerAction(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, ERROR);

    if (VONR_LB_ACTIVE != FnVCCB_GetSaMeas(*ptCi).voNrLbState) return GOOD;

    SET_VONR_LB_INACTIVE_STATE(ptCi);

    FnVCCB_DeleteVoNrLbMeasConfig(ptCi);

    return GOOD;
}

/****************************************************************************
 * @brief       Attach MrWaitTimer for VoNR LB when RRC Reconfiguration Complete is received.
 * @param[in]   ptCi : Pointer to call configuration. / callInfo_type*
 ****************************************************************************/
void FnVCCB_CommitVoNrLB(callInfo_type *ptCi)  // FGR-LC0712
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    // Running Timer
    if (IS_TIMER_VALID(ptCi->voNrLbMrWaitTimer))
    {
        return;
    }

    // FGR-LC0712 After committing Measurement Configuration, attach the timer.
    if (TRUE == FnVCCB_CheckMeasInstalledByCallbackId(ptCi, FUN_2_MEASREPORTCALLBACKID(FnVCCB_ProcMrVoNRLoadBalancing)))
    {
        SET_VONR_LB_ACTIVE_STATE(ptCi);

        VCCB_PRINT_LOG_VONR_LB(ptCi, "[VONRLB] voNrLbMrWaitTimer Attached \n");
        VLIB_AttachTimer(&ptCi->voNrLbMrWaitTimer, ptCi, timVoNrLbMrReceived_id);
    }
}

// }}}

/****************************************************************************
    [FGR-LC0710] Slice LB (Slice Aware Connected Mode Load Balancing)
****************************************************************************/
// {{{

int16_t FnVCCB_CheckToTriggerSliceAwareLoadBalancing(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    // FR20
    if (IS_TIMER_VALID(ptCi->sliceAwareLbInfo.waitTimer))
    {
        if (IS_REDCAP_UE(ptCi)) // 25A FR20 defense code : cancel the timer if running 
        {
            VCCB_CLEAR_TIMER(&ptCi->sliceAwareLbInfo.waitTimer, CANCEL_TIMER);
            VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) cancel timer for RedCap UE\n");    
        }

        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) check timer. already being performed (tmr:%d)\n",
            ptCi->sliceAwareLbInfo.waitTimer.id);
        return ERROR;
    }

    // 25A FR20
    if (IS_REDCAP_UE(ptCi)) 
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) Don't trigger for RedCap UE!! \n");
        return ERROR; 
    }

    // FR32
    // Move to the start of the FnVCCB_TriggerSliceAwareLoadBalancing function

    // FR30, FR11
    if (IS_CPC_CPU_OVERLOAD_CONDITION(CFG->overloadControl.ueSigCpuOverloadControl.overloadedLevelSliceLb) == TRUE)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) check loadStatus (YANG.overloadedLevelSliceLb:%d) >= cpuOvSts(%d)\n",
            CFG->overloadControl.ueSigCpuOverloadControl.overloadedLevelSliceLb, CFG->overloadStatus);

        ptCi->sliceAwareLbDecisionCount = MAX_SLICE_LB_DECISION;
        return ERROR;
    }

    // FR20
    if (pGnb->sliceAwareLbInfo.sliceLbswitch != TRUE )
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) check YANG(GnbNum:%d).sliceLbswitch(%d) != T \n",
            ptCi->gnbNum, pGnb->sliceAwareLbInfo.sliceLbswitch);
        return ERROR;
    }

    // FR20
    int16_t ret = FnVCCB_CheckConfiguredLbSliceList(ptCi);
    if (ret != GOOD)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) CheckConfiguredLbSliceList=E \n");
        return ERROR;
    }

    return GOOD;
}

//SVR23B FGR-LC0710
int16_t FnVCCB_SelectTargetSlice(callInfo_type *ptCi, uint8_t prevTgtSliceIdx, uint8_t &newTgtSliceIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint8_t highestPriority = 0xFF;

    uint8_t plmnIdx = VLIB_FindGnbPlmnIndexOfCall(ptCi);
    if (!IS_VALID_PLMNNUM(plmnIdx)) return ERROR;

    newTgtSliceIdx = MAX_ACTIVE_SLICE_NUM;

    for (uint8_t sliceIdx = 0; sliceIdx < MAX_ACTIVE_SLICE_NUM; sliceIdx++)
    {
        const sliceLoadControlInfo_type *pSlice = FnVCCB_GetSliceLoadControlInfo(ptCi->gnbNum, sliceIdx);
        if (pSlice == NULL) continue;

        if (plmnIdx != pSlice->plmnIndex) continue;

        if (prevTgtSliceIdx == sliceIdx) continue;

        for (uint16_t callPduIdx = 0; callPduIdx < MAX_PDU_SESS_PER_CALL; callPduIdx++)
        {
            if (ptCi->pduSess[callPduIdx].usage != CI_use) continue;
            
            if (pSlice->sNssai.sstSd != ptCi->pduSess[callPduIdx].sNssai.sstSd) continue;

            if (highestPriority == 0xFF)
            {
                highestPriority = pSlice->priority;
                newTgtSliceIdx = sliceIdx;
            }
            else if (highestPriority <= pSlice->priority)
            {
                highestPriority = pSlice->priority;
                newTgtSliceIdx = sliceIdx;
            }
        }
    }

    if (newTgtSliceIdx >= MAX_ACTIVE_SLICE_NUM)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) There's no valid target slice Index \n"); 
        return ERROR;
    }

    if ((prevTgtSliceIdx < MAX_ACTIVE_SLICE_NUM) &&
        (pGnb->sliceLoadControlInfo[newTgtSliceIdx].priority <= pGnb->sliceLoadControlInfo[prevTgtSliceIdx].priority))
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) Previous target slice's priority is still higher (new(%d)<=prev(%d)) \n",
            pGnb->sliceLoadControlInfo[newTgtSliceIdx].priority, pGnb->sliceLoadControlInfo[prevTgtSliceIdx].priority); 
        return ERROR;
    }

    VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) New target slice is found (sliceIdx:%d/plmnIdx:%d/sstsd:0x%X/priority:%d)\n", 
        newTgtSliceIdx, plmnIdx, pGnb->sliceLoadControlInfo[newTgtSliceIdx].sNssai.sstSd, 
        pGnb->sliceLoadControlInfo[newTgtSliceIdx].priority);

    return GOOD;
}

int32_t FnVCCB_GetSliceCapacityForIntraCell_Common(callInfo_type *ptCi, uint16_t cellNum, uint8_t targetSliceIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, SLICE_LB_INVALID_CAPACITY);
    VCCB_CHECK_E_RANGE_AND_VAL(targetSliceIdx, MAX_ACTIVE_SLICE_NUM, SLICE_LB_INVALID_CAPACITY);        
    
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(cellNum, SLICE_LB_INVALID_CAPACITY);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    
    uint8_t gnbPlmnIndex = VLIB_FindGnbPlmnIndexOfCall(ptCi);
    VCCB_CHECK_E_RANGE_AND_VAL(gnbPlmnIndex, MAX_PLMN_INDEX, SLICE_LB_INVALID_CAPACITY);

    uint8_t isSdlCell = 0;
    const sliceCacInfo_type *pSliceCac = NULL;

    const sliceLoadControlInfo_type *pSlice = FnVCCB_GetSliceLoadControlInfo(ptCi->gnbNum, targetSliceIdx);
    VALID_E_POINT_CHECK_RET_VAL(pSlice, SLICE_LB_INVALID_CAPACITY);

    const sonCellSliceCac_type *ptCellCacInfo = &pCell->cellCacInfo;
    uint16_t sliceCacCount = (uint16_t)UMIN(ptCellCacInfo->sliceCount, MAX_ACTIVE_SLICE_NUM);
    
    for (uint16_t sliceCacIdx = 0; sliceCacIdx < sliceCacCount; sliceCacIdx++)
    {
        pSliceCac = &ptCellCacInfo->sliceCac[sliceCacIdx];

        if (pSliceCac->sliceIndex == targetSliceIdx)
        {
            // Check PCell Violation rate
            if ((cellNum == ptCi->servCellNum) && (pSlice->sliceAwareLbConf.slaViolationSwitch == VCCB_FLAG_ON))
            {
                if (FnVCCB_CheckSlaViolationCell(ptCi, cellNum, sliceCacIdx, targetSliceIdx) != GOOD)
                {
                    return SLICE_LB_INVALID_CAPACITY;
                }
            }

            isSdlCell = (uint8_t)VCCM_CheckNRSDLCell(pCell);
            
            int32_t capacity = FnVCCB_CalculateSliceCapacity(ptCi, 
                (int32_t)pSliceCac->dlSliceCapacity, (int32_t)pSliceCac->ulSliceCapacity, isSdlCell);

            VCCB_PRINT_LOG_SLICE_LB(ptCi,
                "(SLB)  SAC(intra): %d (ce:%d/sliceIdx:%d/plmnIdx:%d/cacIdx:%d) (dl:%d/ul:%d/sdl:%d) \n", 
                    capacity, cellNum, pSliceCac->sliceIndex, gnbPlmnIndex, sliceCacIdx, 
                    pSliceCac->dlSliceCapacity, pSliceCac->ulSliceCapacity, isSdlCell);

            return capacity;
        }
    }

    return SLICE_LB_INVALID_CAPACITY;
}

// FR40, FR41
//SVR23B FGR-LC0710
int32_t FnVCCB_GetSliceCapacityForIntraCell(callInfo_type *ptCi, uint16_t cellNum, uint8_t targetSliceIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, SLICE_LB_INVALID_CAPACITY);
    
    if (IS_REDCAP_UE(ptCi))
    {
        return FnVCCB_GetSliceCapacityForIntraCell_Common(ptCi, cellNum, targetSliceIdx);
    }    
    
    return FnVCCB_GetSliceCapacityForIntraCell_Common(ptCi, cellNum, ptCi->sliceAwareLbInfo.tgtSliceIdx);
}

//SVR23B FGR-LC0710
int16_t FnVCCB_CheckSupportedSliceForInterCell(
    callInfo_type *ptCi, cgi_type cgi, uint8_t gnbIdLength, nbrGnbCellInfo_type *pNbrGnbCellInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_RET_VAL(pNbrGnbCellInfo, BREAK);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    const sliceLoadControlInfo_type* pTargetSlice = FnVCCB_GetSliceLoadControlInfo(ptCi->gnbNum, ptCi->sliceAwareLbInfo.tgtSliceIdx);
    VALID_E_POINT_CHECK_ERROR(pTargetSlice);
    
    /* Get target gNB ID from cgi*/
    vccbGlobalGnbId_type targetGnbId;
    targetGnbId.gnbId.idLength = gnbIdLength;
    targetGnbId.gnbId.id = VLIB_NrCellId2GnbId(targetGnbId.gnbId.idLength, cgi.ci);
    targetGnbId.plmn = cgi.plmn;

    /* Get XN end point */
    uint16_t xnEndPointIdx = fnVLIB_FindXnEndPointIndexByGnbId(ptCi->gnbNum, &targetGnbId);
    if (xnEndPointIdx >= MAX_XN_NBR_PER_GNB)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) check _FindXnEndPointIndexByGnbId (gnbNum:%d/nci:%lu)\n", ptCi->gnbNum, cgi.ci);
        return BREAK;
    }

    /* Get TAC of target cell */
    if (pNbrGnbCellInfo->fiveGsTacStatus != TRUE) 
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) check NbrGnbCellInfo (nci:%lu/fiveGsTacStatus=F)\n", cgi.ci);
        return BREAK;
    }
    if (pNbrGnbCellInfo->fiveGsTac == 0) 
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) check NbrGnbCellInfo (nci:%lu/fiveGsTac=0)\n", cgi.ci);
        return BREAK;
    }
    if (!IS_FR2(pNbrGnbCellInfo->ssbArfcn)) 
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) check NbrGnbCellInfo (nci:%lu/IS_FR2=F/ssbArfcn:%d)\n", 
                cgi.ci, pNbrGnbCellInfo->ssbArfcn);
        return ERROR;
    }
    
    uint32_t fivsGsTac = pNbrGnbCellInfo->fiveGsTac;
    
    const xnTaiInfo_type *const ptXnTai = &pGnb->xnGnbInfo[xnEndPointIdx];    
    
    if (ptXnTai->status != EQUIP)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) check xnGnbInfo (nci:%lu/status=N_EQUIP/xnEndPointIdx:%d)\n", 
                cgi.ci, xnEndPointIdx);
        return BREAK;
    }

    if (ptXnTai->serviceState != OpState_enabled)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) check xnGnbInfo (nci:%lu/serviceState=disable/xnEndPointIdx:%d)\n", 
                cgi.ci, xnEndPointIdx);
        return BREAK;
    }

    const callSNSSAI_type &tgtSlice = pTargetSlice->sNssai;    
    uint32_t maxTaiSupportCnt = MIN(ptXnTai->taiSupportCnt, MAX_XN_TAI_SUPPORT_COUNT);
    uint32_t taiIdx;
    for (taiIdx = 0; taiIdx < maxTaiSupportCnt; taiIdx++)
    {
        /* Compare PLMN */
        if (ptCi->ueInfo.servedPlmn.longId != ptXnTai->plmn[taiIdx]) continue;

        /* Compare TAC */
        if (fivsGsTac != ptXnTai->tac[taiIdx]) continue;

        /* Compre S-NSSAI */
        if (tgtSlice.sstSd == ptXnTai->sNssai[taiIdx]) break;
    }

    if (taiIdx < maxTaiSupportCnt)
    {
        return GOOD;
    }
    else
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) check xnGnbInfo TAC (nci:%lu/xnEndPointIdx:%d/sstsd:0x%x/tac:%d)\n", 
            cgi.ci, xnEndPointIdx, tgtSlice.sstSd, fivsGsTac);
        return BREAK;
    }
}

int32_t FnVCCB_CalculateSliceCapacityForInterCell(callInfo_type *ptCi, cgi_type cgi, sonNbrPrbRsc_type *ptNbrRsc, nbrGnbCellInfo_type *pNbrGnbCellInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptNbrRsc, SLICE_LB_INVALID_CAPACITY);
    VALID_E_POINT_CHECK_RET_VAL(pNbrGnbCellInfo, SLICE_LB_INVALID_CAPACITY);

    const uint8_t isSdlCell = FnVCCB_IsNbrSDLCell(ptCi, pNbrGnbCellInfo);

    /*
        slice capacity = (dl(or ul)capacityValue * (dlTotalBandwidth / nbr cell's BW) * dl(or ul)CCCV) / 100

        note) 
            capacityValue : msgSonResourceStatusIndVcsbVccb.cellPrb[X].nbrPrb[Y].dl(or ul)CapacityValue
            dlTotalBandwidth : msgSonResourceStatusIndVcsbVccb.cellPrb[X].nbrPrb[Y].dlTotalBandwidth
            nbr cell's BW is determined by SCS and RB of nbr cell
            - SCS : neighbor-gnb/neighbor-gnb-entries/neighbor-gnb-cell/neighbor-gnb-cell-entries/nr-scs-dl
            - RB : neighbor-gnb/neighbor-gnb-entries/neighbor-gnb-cell/neighbor-gnb-cell-entries/nrb-dl
            CCCV : msgSonResourceStatusIndVcsbVccb.cellPrb[X].nbrPrb[Y].dl(or ul)CCCV
    */
    
    const uint32_t nbrCellBW = pNbrGnbCellInfo->bandwidthDl; // "Dl" is not a mistake. Using DL to get nbr cell's BW is design

    if (nbrCellBW == 0)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB)  SAC(inter): 0 (nbrCellBW is ZERO. cgi:%lu)\n", cgi.ci);
        return 0;
    }
    if (static_cast<uint32_t>(ptNbrRsc->dlTotalBandwidth) < nbrCellBW)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB)  SAC(inter): 0 (dlTotalBandwidth %d < nbrCellBW %d. cgi:%lu)\n", 
            ptNbrRsc->dlTotalBandwidth, nbrCellBW, cgi.ci);
        return 0;
    }

    const float ratedNbrCellBw = static_cast<float>(ptNbrRsc->dlTotalBandwidth) / static_cast<float>(nbrCellBW);
    
    const float totalDlCccv = ratedNbrCellBw * static_cast<float>(ptNbrRsc->dlCCCV);
    const float totalUlCccv = ratedNbrCellBw * static_cast<float>(ptNbrRsc->ulCCCV);

    const int32_t sliceCapacityDl = static_cast<int32_t>((static_cast<float>(ptNbrRsc->dlCapacityValue) * totalDlCccv) / 100);
    const int32_t sliceCapacityUl = static_cast<int32_t>((static_cast<float>(ptNbrRsc->ulCapacityValue) * totalUlCccv) / 100);

    int32_t capacity = FnVCCB_CalculateSliceCapacity(ptCi, sliceCapacityDl, sliceCapacityUl, isSdlCell);

    VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB)  SAC(inter): %d(=[%dor%d]*(%d/%d*[%dor%d])/100), ci:%lu,scs:%d,rb:%d,sdl:%d)\n",
        capacity, ptNbrRsc->dlCapacityValue, ptNbrRsc->ulCapacityValue,
        ptNbrRsc->dlTotalBandwidth, nbrCellBW, ptNbrRsc->dlCCCV, ptNbrRsc->ulCCCV,
        cgi.ci, pNbrGnbCellInfo->nrScsDl, pNbrGnbCellInfo->nrbDl, isSdlCell);

    return capacity;
}

// FR42
//SVR23B FGR-LC0710
int32_t FnVCCB_GetSliceCapacityForInterCell(callInfo_type *ptCi, cgi_type cgi, uint8_t gnbIdLength, CellNum_type spCellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, SLICE_LB_INVALID_CAPACITY);

    nbrGnbCellInfo_type *pNbrGnbCellInfo = VLIB_GetNbrGnbCellInfoBasedOnCgi(ptCi, cgi, gnbIdLength);
    if (pNbrGnbCellInfo == NULL) 
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) check NbrGnbCellInfo (nci:%lu/pNbrGnbCellInfo=NULL)\n", cgi.ci);
        return 0;
    }

    int16_t status = FnVCCB_CheckSupportedSliceForInterCell(ptCi, cgi, gnbIdLength, pNbrGnbCellInfo);
    if (status == ERROR)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) check _CheckSupportedSliceForInterCell (nci:%lu/len:%d)\n", 
            cgi.ci, gnbIdLength);
        return SLICE_LB_INVALID_CAPACITY;
    }
    else if (status == BREAK)
    {
        return 0; 
    }

    VCCB_CHECK_E_RANGE_AND_VAL(spCellNum, MAX_CELL_NUM_VCCB, SLICE_LB_INVALID_CAPACITY);
    VccbCellInfo_type *pCell = &CELLINFO[spCellNum];

    uint16_t maxNbrIdx = (uint16_t)UMIN(MAX_NBR_RELATION_TABLE_PER_CELL, MAX_NBR_PER_CELL);
    uint16_t cellNbrIdx = VLIB_GetNbrIdxBasedOnCgi(pCell, cgi);

    if (cellNbrIdx >= maxNbrIdx)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) check cellNbrIdx(%d) >= maxNbr(%d) \n", cellNbrIdx, maxNbrIdx);
        return 0; 
    }

    sonNbrPrbRsc_type *ptNbrRsc = &pCell->cellRscInfo.nbrPrb[cellNbrIdx];
    if (ptNbrRsc->usage != EQUIP)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) check RUS (nbr:%d/usage:%d) \n", cellNbrIdx, ptNbrRsc->usage);
        return 0; 
    }

    if (ptNbrRsc->isRsUpdate != ON)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) check RUS (nbr:%d/update:%d) \n", cellNbrIdx, ptNbrRsc->isRsUpdate);
        return SLICE_LB_INVALID_CAPACITY; 
    }

    return FnVCCB_CalculateSliceCapacityForInterCell(ptCi, cgi, ptNbrRsc, pNbrGnbCellInfo);
}

// FR40, FR41, FR42
//SVR23B FGR-LC0710
int32_t FnVCCB_GetSliceCapacityForScell(callInfo_type *ptCi, scellInfo_type *pScell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, SLICE_LB_INVALID_CAPACITY);
    VALID_E_POINT_CHECK_RET_VAL(pScell, SLICE_LB_INVALID_CAPACITY);

    int32_t capacity = SLICE_LB_INVALID_CAPACITY;     
    uint32_t gnbId = VLIB_NrCellId2GnbId(pScell->gnbIdLength, pScell->cgi.ci);

    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, SLICE_LB_INVALID_CAPACITY);
    if (VCCB_IS_SAME_GNB(gnbId, pScell->cgi.plmn.longId, ptCi->gnbNum))
    {
        uint16_t cellIdentity = VLIB_NrCellId2CellId(pScell->gnbIdLength, pScell->cgi.ci);
        VCCB_CHECK_E_RANGE_AND_VAL(cellIdentity, MAX_CELL_IDENTITY, SLICE_LB_INVALID_CAPACITY);

        uint16_t cellNum = GNBINFO[ptCi->gnbNum].env.cellNum[cellIdentity];
        VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, SLICE_LB_INVALID_CAPACITY);

        capacity = FnVCCB_GetSliceCapacityForIntraCell(ptCi, cellNum);
    }
    else // FR42
    {
        if (!IS_FR2(pScell->ssbArfcn))
        {
            VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) _GetSliceCapacityForScell (IS_FR2=F) (ssbArfcn:%u) \n", pScell->ssbArfcn);
            return SLICE_LB_INVALID_CAPACITY;
        }

        capacity = FnVCCB_GetSliceCapacityForInterCell(ptCi, pScell->cgi, pScell->gnbIdLength, ptCi->servCellNum);
    }

    if (capacity <= SLICE_LB_INVALID_CAPACITY)
    {
        // FR41
        return SLICE_LB_INVALID_CAPACITY;
    }
    
    return capacity;
}

// FR40, FR41, FR42
//SVR23B FGR-LC0710
int16_t FnVCCB_CheckSliceCapacity(callInfo_type *ptCi, uint16_t tgtSliceIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(tgtSliceIdx, MAX_ACTIVE_SLICE_NUM);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    int32_t totalCapacity = SLICE_LB_INVALID_CAPACITY;
    
    totalCapacity = FnVCCB_GetSliceCapacityForIntraCell(ptCi, ptCi->servCellNum);
    if (totalCapacity <= SLICE_LB_INVALID_CAPACITY) 
    {
        // FR41
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) check GetSliceCapacityForIntraCell (pcell:%d/capacity:%d) \n", 
            ptCi->servCellNum, totalCapacity);
        return ERROR;
    }

    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (uint16_t sCellIdx = 0; sCellIdx < MAX_SCELL_PER_CALL; sCellIdx++)
    {
        scellInfo_type *pScell = &scells[sCellIdx];

        if (pScell->state != SCELL_STATE_ADDED) continue;

        int32_t sCellCapacity = FnVCCB_GetSliceCapacityForScell(ptCi, pScell);

        if (sCellCapacity <= SLICE_LB_INVALID_CAPACITY)
        {
            // FR41
            VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) Check GetSliceCapacityForScell (scellidx:%d/capacity:%d) \n", 
                sCellIdx, sCellCapacity);
            return ERROR;
        }
        else 
        {
            // FR40
            totalCapacity += sCellCapacity;
        }
    }
 
    const sliceAwareLbConf_type *pSliceLbConf = &pGnb->sliceLoadControlInfo[tgtSliceIdx].sliceAwareLbConf;
    int32_t tgtThreshold = FnVCCB_CalculateSliceCapacity(ptCi, 
        (int32_t)pSliceLbConf->capacityThresholdDl, (int32_t)pSliceLbConf->capacityThresholdUl, false);

    if ((totalCapacity > SLICE_LB_INVALID_CAPACITY) && (totalCapacity <= tgtThreshold))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "(SLB) Trigger PCC Change : totCapa(%d) <= threshold(%d) \n", 
            totalCapacity, tgtThreshold);

        return GOOD;
    }

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "(SLB) Not trigger PCC change : totCapa(%d) > threshold(%d) \n", 
        totalCapacity, tgtThreshold);

    return ERROR;
}

//SVR23B FGR-LC0710
int16_t FnVCCB_CheckToRestartSliceAwareLoadBalancing(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
   
    // FR33 1. check if serving slice released
    if (FnVCCB_IsTargetSliceConfigured(ptCi, ptCi->sliceAwareLbInfo.tgtSliceIdx) != GOOD)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) Target slice has been released \n");
        return GOOD;
    }

    // FR33 2. check if new slice has a higher priority
    uint8_t newTargetSliceIdx = MAX_ACTIVE_SLICE_NUM;

    if (FnVCCB_SelectTargetSlice(ptCi, ptCi->sliceAwareLbInfo.tgtSliceIdx, newTargetSliceIdx) == GOOD)
    {
        return GOOD;
    }

    return ERROR;
}

//SVR23B FGR-LC0710
int16_t FnVCCB_CheckToStopSliceAwareLoadBalancing(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t ret;

    // FR34
    /* Check VoNR */
    ret = FnVCCB_IsVoNRCall(ptCi);
    if (ret == TRUE) 
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) IsVoNRCall=T \n");
        return GOOD;
    }
    
    // FR34
    /* Check Emergency */
    ret = VCCM_CheckEmergencyCall(ptCi);
    if (ret == TRUE) 
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) CheckEmergencyCall=T \n");
        return GOOD;
    }
    
    // FR34
    /* Check NR-DC establishment */
    if (IS_NRDC(ptCi)) 
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) IS_NRDC=T \n");
        return GOOD;
    }

    return ERROR;
}

//SVR23B FGR-LC0710
int16_t FnVCCB_CheckToStopDecisionSliceAwareLoadBalancing(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);

    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    int16_t ret;

    if (IS_REDCAP_UE(ptCi)) // 25A FR31
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) Stop for RedCap UE!!! \n");
        return GOOD;
    }

    // FR32
    if (ptCi->sliceAwareLbDecisionCount >= MAX_SLICE_LB_DECISION)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) check sliceAwareLbDecisionCount(%d) >= MAX\n", ptCi->sliceAwareLbDecisionCount);
        return GOOD;
    }

    // FR30, FR11
    if (IS_CPC_CPU_OVERLOAD_CONDITION(CFG->overloadControl.ueSigCpuOverloadControl.overloadedLevelSliceLb) == TRUE)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) check loadStatus (YANG.overloadedLevelSliceLb:%d) >= cpuOvSts(%d)\n",
            CFG->overloadControl.ueSigCpuOverloadControl.overloadedLevelSliceLb, CFG->overloadStatus);

        ptCi->sliceAwareLbDecisionCount = MAX_SLICE_LB_DECISION;
        return GOOD;
    }

    // FR20
    VCCB_CHECK_E_RANGE_AND_GOOD(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    if (pGnb->sliceAwareLbInfo.sliceLbswitch != TRUE )
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) check YANG(GnbNum:%d).sliceLbswitch(%d) != T \n",
            ptCi->gnbNum, pGnb->sliceAwareLbInfo.sliceLbswitch);
        return GOOD;
    }

    // FR31
    /* Check VoNR */
    ret = FnVCCB_IsVoNRCall(ptCi);
    if (ret == TRUE)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) IsVoNRCall=T \n");
        return GOOD;
    }

    // FR31
    /* Check Emergency */
    ret = VCCM_CheckEmergencyCall(ptCi);
    if (ret == TRUE)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) CheckEmergencyCall=T \n");
        return GOOD;
    }

    // FR31
    /* Check RFSP */
    ret = FnVCCB_CheckIfRfspBasedMobilityIsActiveForCall(ptCi);
    if (ret == GOOD)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) CheckIfRfspBasedMobilityIsActiveForCall=T \n");
        return GOOD;
    }

    // FR31
    /* Check Priority based scell selection */
    ret = FnVCCB_IsScellFreqPrioFlagOn(ptCi);
    if (ret)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) IsScellFreqPrioFlagOn=T \n");
        return GOOD;
    }

    // FR31
    /* Check NR-DC establishment */
    if (IS_NRDC(ptCi))
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) IS_NRDC=T \n");
        return GOOD;
    }

    // FR31 (SVR24A)
    if ((FnVCCB_isRfspSpecificUE(ptCi, ptCi->servCellNum) != nullptr) && 
        (pCell->cellRfspSpecificMeasCtrl.supportLbFpHoUsage != CI_use)) 
    {
        // ref) FGR-MC1023 (FR21)
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) RFSP Specific UE = T \n");
        return GOOD;
    } 
    
    // FR31 (SVR24A)
    if (IS_USTM_ONGOING(ptCi)) // ref) FGR-MC1029
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) USTM forced HO UE = T \n");
        return GOOD;
    }

    // FR31 (SVR24A) : Check UE count in Slice LB operation
    auto &opCounts = McoSlbOpCounts::getOpCounts();
    if (opCounts.checkIfSlbOpCountAboveThresholdAndIncrement()) // ref) FGR-LC0710 (FR143)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) Current SLB operation count is over maxCntSlb(%d) \n", 
            CFG->overloadControl.mcoSlbOpCountOverloadControl.maxCntSlb);
        return GOOD;
    }

    return ERROR;
}

int8_t FnVCCB_HandleOnGoingSliceAwareLoadBalancing(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) Slice LB is on-going (Target slice idx : %d) \n",
        ptCi->sliceAwareLbInfo.tgtSliceIdx);

    // FR34
    if (FnVCCB_CheckToStopSliceAwareLoadBalancing(ptCi) == GOOD)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) ## Stop Slice LB \n");
        FnVCCB_StopSliceAwarePccChange(ptCi);
        VLIB_InitSliceLbInfo(ptCi);

        return ERROR;
    }

    // FR33
    if (ptCi->sliceAwareLbInfo.triggerEvent == TRUE)
    {
        if (FnVCCB_CheckToRestartSliceAwareLoadBalancing(ptCi) != GOOD)
        {
            ptCi->sliceAwareLbInfo.triggerEvent = FALSE;

            return ERROR;
        }
        else
        {
            VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) ## Restart Slice LB \n");
            FnVCCB_StopSliceAwarePccChange(ptCi);
            VLIB_ResetSliceLbInfo(ptCi);

            return GOOD;
        }
    }

    return GOOD;
}

//SVR23B FGR-LC0710
void FnVCCB_TriggerSliceAwareLoadBalancing(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->callType != E_CALLTYPE_SA) return;

    // FR32
    if (ptCi->sliceAwareLbDecisionCount >= MAX_SLICE_LB_DECISION) return;

    // FR33, FR34
    if (ptCi->sliceAwareLbInfo.tgtSliceIdx < MAX_ACTIVE_SLICE_NUM)
    {
        if (FnVCCB_HandleOnGoingSliceAwareLoadBalancing(ptCi) != GOOD)
        {
            return;
        }
    }

    if (ptCi->sliceAwareLbInfo.triggerEvent != TRUE) return;

    VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) ## Check to trigger Slice LB \n");

    ptCi->sliceAwareLbInfo.triggerEvent = FALSE;

    // FR20, FR30, FR32
    if (FnVCCB_CheckToTriggerSliceAwareLoadBalancing(ptCi) != GOOD) return;

    // Attach timer and wait 
    VLIB_AttachTimer(&ptCi->sliceAwareLbInfo.waitTimer, ptCi, timInternalSliceAwareLbWaitTimer_id);

    if (ptCi->gnbNum < MAX_GNB_PER_SYS)
    {
        const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "(SLB) ## Attach wait timer (id:%d/val:%d)\n", 
            ptCi->sliceAwareLbInfo.waitTimer.id, pGnb->sliceAwareLbInfo.waitTimerValue); 
    }
    else
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "(SLB) ## Attach wait timer (id:%d)\n", 
            ptCi->sliceAwareLbInfo.waitTimer.id); 
    }

    return;
}

//SVR23B FGR-LC0710
// STEP2 : FR21, FR31, FR40, FR41, FR42
void FnVCCB_DecisionSliceAwareLoadBalancing(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t targetSliceIdx = MAX_ACTIVE_SLICE_NUM;
    int16_t ret;
    
    VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) ## Decide Slice LB (tmr:%d)\n", 
            ptCi->sliceAwareLbInfo.waitTimer.id);

    VCCB_CLEAR_TIMER(&ptCi->sliceAwareLbInfo.waitTimer, CANCEL_TIMER);

    // FR31
    if (FnVCCB_CheckToStopDecisionSliceAwareLoadBalancing(ptCi) == GOOD)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) Stop to decide Slice LB \n");
        return;
    }

    // FR21
    if (FnVCCB_SelectTargetSlice(ptCi, MAX_ACTIVE_SLICE_NUM, targetSliceIdx) != GOOD)
    {
        return;
    }

    ptCi->sliceAwareLbInfo.tgtSliceIdx = targetSliceIdx;

    // FR40
    /* Calculate total slice capacity of Pcell and Scells and compre it with threshold*/
    ret = FnVCCB_CheckSliceCapacity(ptCi, ptCi->sliceAwareLbInfo.tgtSliceIdx);
    if (ret == GOOD)
    {
        ptCi->sliceAwareLbDecisionCount++;
        FnVCCB_TriggerSliceAwarePccChange(ptCi);
    }
    else
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) _CheckSliceCapacity != GOOD \n");
        VLIB_InitSliceLbInfo(ptCi);
    }
    
    return;
}

//SVR23B FGR-LC0710
void FnVCCB_SetSliceLbTriggerEvent(callInfo_type *ptCi, uint16_t eventType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->sliceAwareLbInfo.triggerEvent != TRUE)
    {
        if (eventType == S_Release)
        {
            if (ptCi->sliceAwareLbInfo.tgtSliceIdx >= MAX_ACTIVE_SLICE_NUM)
                return;
        }

        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) Set triggerEvent (%d)->(1) (eventType:%d) \n", 
            ptCi->sliceAwareLbInfo.triggerEvent, eventType);

        ptCi->sliceAwareLbInfo.triggerEvent = TRUE;
    }

    return;
}

int32_t FnVCCB_CalculateSliceCapacity_Common(callInfo_type *ptCi, int32_t dlCapacity, int32_t ulCapacity, uint8_t isSdlCell, uint8_t targetSliceIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, SLICE_LB_INVALID_CAPACITY);
    
    int32_t capacity = SLICE_LB_INVALID_CAPACITY;
    uint8_t tgtSliceTransType = 0xFF;

    const sliceLoadControlInfo_type* pSlice = FnVCCB_GetSliceLoadControlInfo(ptCi->gnbNum, targetSliceIdx);
    VALID_E_POINT_CHECK_RET_VAL(pSlice, SLICE_LB_INVALID_CAPACITY);
    
    const sliceAwareLbConf_type *pSliceLbConf = &pSlice->sliceAwareLbConf;
    
    tgtSliceTransType = pSliceLbConf->sliceTransmissionType;

    switch (tgtSliceTransType)
    {
        case SLICE_TRANSMISSION_TYPE_DL:
            capacity = dlCapacity;
            break;

        case SLICE_TRANSMISSION_TYPE_UL:
            capacity = (isSdlCell)? 0 : ulCapacity;
            break;

        default:
            capacity = SLICE_LB_INVALID_CAPACITY;
            break;
    }

    return capacity;   
}

 /**
 * @brief [FGR-LC0710] Slice Aware Connected Mode Load Balancing (FR40)
 * @details Get slice transmission type
 * @param [in] pointer of callInfo_type, sliceIndex
 * @return uint8_t sliceTransmissionType
 */
int32_t FnVCCB_CalculateSliceCapacity(callInfo_type *ptCi, int32_t dlCapacity, int32_t ulCapacity, uint8_t isSdlCell, uint8_t targetSliceIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, SLICE_LB_INVALID_CAPACITY);
    
    if (IS_REDCAP_UE(ptCi))
    {
        return FnVCCB_CalculateSliceCapacity_Common(ptCi, dlCapacity, ulCapacity, isSdlCell, targetSliceIdx);
    }    
    
    return FnVCCB_CalculateSliceCapacity_Common(ptCi, dlCapacity, ulCapacity, isSdlCell, ptCi->sliceAwareLbInfo.tgtSliceIdx);
}

 /**
 * @brief [FGR-LC0710] Slice Aware Connected Mode Load Balancing (FR40)
 * @details Check if cell SLA violation.
 * @param [in] pointer of callInfo_type, cellNum, sliceCacIndex
 * @return uint8_t GOOD/ERROR
 */
int8_t FnVCCB_CheckSlaViolationCell(
    callInfo_type *ptCi, uint16_t cellNum, uint16_t sliceCacIndex, uint8_t targetSliceIndex)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);
    VCCB_CHECK_E_RANGE_AND_RETURN(sliceCacIndex, MAX_ACTIVE_SLICE_NUM);
    VCCB_CHECK_E_RANGE_AND_RETURN(targetSliceIndex, MAX_ACTIVE_SLICE_NUM);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    
    int8_t slaViolationRate = -1;
    uint16_t slaViolationTh = 0;

    const sliceLoadControlInfo_type* pSlice = FnVCCB_GetSliceLoadControlInfo(ptCi->gnbNum, targetSliceIndex);
    VALID_E_POINT_CHECK_ERROR(pSlice);
    
    const sliceCacInfo_type *pSliceCac = &pCell->cellCacInfo.sliceCac[sliceCacIndex];
    
    if (pSlice->sliceAwareLbConf.slaViolationSwitch != VCCB_FLAG_ON) return GOOD;

    uint8_t tgtSliceTransType = pSlice->sliceAwareLbConf.sliceTransmissionType;

    switch (tgtSliceTransType)
    {
        case SLICE_TRANSMISSION_TYPE_DL:
            slaViolationRate = pSliceCac->dlUeTputViolationRate;
            slaViolationTh = pSlice->sliceAwareLbConf.slaViolationThDl;
            break;

        case SLICE_TRANSMISSION_TYPE_UL:
            slaViolationRate = pSliceCac->ulUeTputViolationRate;
            slaViolationTh = pSlice->sliceAwareLbConf.slaViolationThUl;
            break;

        default:
            VCCB_PRINT_LOG_SLICE_LB(ptCi, 
                "(SLB) (SLA Violation) N/A : Invalid Transmission type!! (ce:%d/tmType:%d) \n",
                cellNum, tgtSliceTransType);
            return ERROR;
    }

    if (slaViolationRate <= SLICE_LB_INVALID_CAPACITY)
    {
        VCCB_PRINT_LOG_SLICE_LB(
            ptCi, "(SLB) (SLA Violation) Invalid rate : Stop to check capacity (ce:%d/tmType:%d/slaRate:%d) \n",
            cellNum, tgtSliceTransType, slaViolationRate);
        return ERROR;
    }
    else if (slaViolationRate <= slaViolationTh)
    {
        VCCB_PRINT_LOG_SLICE_LB(
            ptCi, "(SLB) (SLA Violation) Normal : Stop to check capacity (ce:%d/tmType:%d/slaRate(%d)<=slaTh(%d)) \n",
            cellNum, tgtSliceTransType, slaViolationRate, slaViolationTh);
        return ERROR;
    }

    VCCB_PRINT_LOG_SLICE_LB(
        ptCi, "(SLB) (SLA Violation) Violated : Keep checking capaity (ce:%d/tmType:%d/slaRate(%d)>slaTh(%d)) \n",
        cellNum, tgtSliceTransType, slaViolationRate, slaViolationTh);

    return GOOD;
}


 /**
 * @brief [FGR-LC0710] Slice Aware Connected Mode Load Balancing (FR22)
 * @details Check if slice which is configured in UE supports SLA violation switch.
 * @param [in] pointer of callInfo_type, cellNum, sliceCacIndex
 * @return uint8_t GOOD/ERROR
 */
int8_t FnVCCB_SliceLb_CheckSlaViolationEnabledUe(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    
    uint8_t plmnIndex = VLIB_FindGnbPlmnIndexOfCall(ptCi);
    if (!IS_VALID_PLMNNUM(plmnIndex))
    {
        return ERROR;
    }

    const sliceLoadControlInfo_type *pSlice = NULL;

    for (uint8_t sliceIdx = 0; sliceIdx < MAX_ACTIVE_SLICE_NUM; sliceIdx++)
    {
        pSlice = FnVCCB_GetSliceLoadControlInfo(ptCi->gnbNum, sliceIdx);
        if (pSlice == NULL) continue;
        
        if (pSlice->plmnIndex != plmnIndex) continue;

        if (pSlice->sliceAwareLbConf.slaViolationSwitch != VCCB_FLAG_ON) continue;

        for (uint8_t callPduIdx = 0; callPduIdx < MAX_PDU_SESS_PER_CALL; callPduIdx++)
        {
            if (ptCi->pduSess[callPduIdx].usage != CI_use) continue;
            
            if (ptCi->pduSess[callPduIdx].sNssai.sstSd == pSlice->sNssai.sstSd)
            {
                return GOOD;
            }
        }
    }

    return ERROR;    
}

//SVR23B FGR-LC0710
int16_t FnVCCB_IsTargetSliceConfigured(callInfo_type *ptCi, uint8_t tgtSliceIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(tgtSliceIdx, MAX_ACTIVE_SLICE_NUM);

    uint16_t callPduIdx;

    int plmnIdx = VLIB_FindGnbPlmnIndexOfCall(ptCi);
    if (!IS_VALID_PLMNNUM(plmnIdx))
    {
        return ERROR;
    }

    const sliceLoadControlInfo_type* pTargetSlice = FnVCCB_GetSliceLoadControlInfo(ptCi->gnbNum, tgtSliceIdx);
    VALID_E_POINT_CHECK_ERROR(pTargetSlice);

    if (pTargetSlice->plmnIndex != plmnIdx)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) plmnIdx not matched(%d - %d) \n",
            pTargetSlice->plmnIndex, plmnIdx);
        return ERROR;
    }

    for (callPduIdx = 0; callPduIdx < MAX_PDU_SESS_PER_CALL; callPduIdx++)
    {
        if (ptCi->pduSess[callPduIdx].usage != CI_use) continue;
        if (ptCi->pduSess[callPduIdx].sNssai.sstSd == pTargetSlice->sNssai.sstSd)
        {
            break;
        }
    }

    if (callPduIdx == MAX_PDU_SESS_PER_CALL)
    {
        VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) target Slice is not setup(plmnIdx:%d/sstsd:0x%X/priority:%d)\n",
                pTargetSlice->plmnIndex,
                pTargetSlice->sNssai.sstSd,
                pTargetSlice->priority);

        return ERROR;
    }

    return GOOD;
}

//SVR23B FGR-LC0710
int16_t FnVCCB_CheckConfiguredLbSliceList(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint8_t plmnIdx = VLIB_FindGnbPlmnIndexOfCall(ptCi);
    if (!IS_VALID_PLMNNUM(plmnIdx))
    {
        return ERROR;
    }

    for (uint8_t sliceIdx = 0; sliceIdx < MAX_ACTIVE_SLICE_NUM; sliceIdx++)
    {
        const sliceLoadControlInfo_type* pSlice = FnVCCB_GetSliceLoadControlInfo(ptCi->gnbNum, sliceIdx);
        if (pSlice == NULL) continue;

        if (plmnIdx != pSlice->plmnIndex) continue;

        for (auto callPduIdx = 0; callPduIdx < MAX_PDU_SESS_PER_CALL; callPduIdx++)
        {
            if (ptCi->pduSess[callPduIdx].usage != CI_use) continue;

            if (ptCi->pduSess[callPduIdx].sNssai.sstSd == pSlice->sNssai.sstSd)
            {
                VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) At least one valid slice is configured (sliceIdx:%d/plmnIdx:%d/pduIdx:%d/sstsd:0x%X) \n",
                    sliceIdx, plmnIdx, callPduIdx, pSlice->sNssai.sstSd);
                return GOOD;
            }
        }
    }

    return ERROR;
}

bool FnVCCB_CheckAvailableLbSlice(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    bool result = true;

    if (ptCi->callType != E_CALLTYPE_SA) result = false;

    /* Check slice-aware-load-balancing-switch */
    else if (pGnb->sliceAwareLbInfo.sliceLbswitch != TRUE ) result = false;

    /* Check slice-load-control-info-entries */
    else if (FnVCCB_CheckConfiguredLbSliceList(ptCi) != GOOD) result = false;

    return result;
}

//SVR23B FGR-LC0710
void VLIB_ResetSliceLbInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    VCCB_PRINT_LOG_SLICE_LB(ptCi, "(SLB) _ResetSliceLbInfo (tmr:%d)\n", ptCi->sliceAwareLbInfo.waitTimer.id);

    ptCi->sliceAwareLbInfo.tgtSliceIdx = MAX_ACTIVE_SLICE_NUM;
    VCCB_CLEAR_TIMER(&ptCi->sliceAwareLbInfo.waitTimer, CANCEL_TIMER);
}

//SVR23B FGR-LC0710
void VLIB_InitSliceLbInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    ptCi->sliceAwareLbInfo.triggerEvent = FALSE;
    ptCi->sliceAwareLbInfo.tgtSliceIdx = MAX_ACTIVE_SLICE_NUM;
    VCCB_CLEAR_TIMER(&ptCi->sliceAwareLbInfo.waitTimer, INIT_TIMER);
}

// }}}

/****************************************************************************
    [FGR-LC0703] Load Balancing between NR Carriers
****************************************************************************/
/****************************************************************************
                LBM ( Load Balancing Management )
****************************************************************************/
enumNrLbmConfigurationIndex_type FnVCCB_AdjustNrLbmIndexForParameterType(
    const enumNrLbmConfigurationIndex_type index, const enumLbmParameterType_type parameterType)
{
    if (parameterType == LBM_PARAMETER_TYPE_CELL_CONFIG)
    {
        return ((index >= NR_LBM_WINDOW0_UPDATE) ? NR_LBM_WINDOW0_UPDATE : NR_LBM_DISABLE);
    }
    else
    {
        return index;
    }
}

bool FnVCCB_IsAffectedByLbmParameter(const VccbCellInfo_type &cellInfo, const bool isRedCapUe)
{
    if (not isRedCapUe) return true;

    // RedCap UE && normal UE mode
    uint8_t redCapOperationMode = cellInfo.lbCfg.connModeLbInfo.redCapOperationMode;
    return (redCapOperationMode == access_s5gtype_normal);
}

void FnVCCB_InitlbmConfiguration(cellLbmConfiguration_type &lbmConfiguration, const uint8_t windowIndex)
{
    // Use a lookup table to map window indices to their respective LBM configurations
    const enumNrLbmConfigurationIndex_type windowToLbmConfig[MAX_NR_LBM_WINDOW_SIZE][MAX_NR_LBM_PURPOSE_SIZE] = {
        {NR_LBM_WINDOW0_UPDATE, NR_LBM_WINDOW0_FALLBACK},
        {NR_LBM_WINDOW1_UPDATE, NR_LBM_WINDOW1_FALLBACK}
    };

    // Check if the window index is valid and initialize the LBM configurations
    if (windowIndex < MAX_NR_LBM_WINDOW_SIZE)
    {
        for (int i = 0; i < MAX_NR_LBM_PURPOSE_SIZE; i++) // Loop through update and fallback purposes
        {
            memset(&lbmConfiguration.lbmConnModeLbInfo.lbmConnModeLbEntry[windowToLbmConfig[windowIndex][i]],
                   0xFF, sizeof(lbmConfiguration.lbmConnModeLbInfo.lbmConnModeLbEntry[windowToLbmConfig[windowIndex][i]]));
        }
    }
}


void FnVCCB_InitlbmConfiguration(cellLbmConfiguration_type &lbmConfiguration, const uint8_t windowIndex, const uint8_t purpose)
{
    // Use a lookup table to map window indices and purposes to their respective LBM configurations
    const enumNrLbmConfigurationIndex_type windowToLbmConfig[MAX_NR_LBM_WINDOW_SIZE][MAX_NR_LBM_PURPOSE_SIZE] = {
        {NR_LBM_WINDOW0_UPDATE, NR_LBM_WINDOW0_FALLBACK},
        {NR_LBM_WINDOW1_UPDATE, NR_LBM_WINDOW1_FALLBACK}
    };

    // Check if the window index is valid and get the corresponding LBM configuration index
    if (windowIndex < MAX_NR_LBM_WINDOW_SIZE)
    {
        uint8_t entriesIndex = windowToLbmConfig[windowIndex][purpose == LBM_PURPOSE_UPDATE ? 0 : 1];

        // Validate the entries index and initialize the memory with 0xFF
        if (VCCB_IS_VALID_LBM_PARAM_IDX_FOR_CONNECTED_LB(entriesIndex))
        {
            memset(&lbmConfiguration.lbmConnModeLbInfo.lbmConnModeLbEntry[entriesIndex],
                   0xFF, sizeof(lbmConfiguration.lbmConnModeLbInfo.lbmConnModeLbEntry[entriesIndex]));
        }
    }
}

uint8_t FnVCCB_GetIntraNrLbSwitch(
    const VccbCellInfo_type &cellInfo, const connModeLBInfo_type &connModeLbInfo, const bool isRedCapUe)
{
    // In 25B, LB operation for RedCap UE is not affected by LBM parameter.
    if (not FnVCCB_IsAffectedByLbmParameter(cellInfo, isRedCapUe)) return connModeLbInfo.usage;

    uint32_t adjustedLbmIndex =
        FnVCCB_AdjustNrLbmIndexForParameterType(cellInfo.nrLbmConfigurationIndex, LBM_PARAMETER_TYPE_CELL_CONFIG);
    const lbmConnModeLbInfo_type &lbmConnModeLbInfo = cellInfo.lbCfg.lbmConfiguration.lbmConnModeLbInfo;
    /*
        NR_LBM_DISABLE           : lbCfg.connModeLbInfo.availRscThreshold
        NR_LBM_WINDOW0_UPDATE     : lbCfg.lbmConfiguration.availRscThreshold
    */
    switch (adjustedLbmIndex)
    {
        case NR_LBM_DISABLE:
            return connModeLbInfo.usage;
        case NR_LBM_WINDOW0_UPDATE:
            return lbmConnModeLbInfo.usage;

        default:
            break;
    }

    return connModeLbInfo.usage;
}

enumLoadEvalMode_Type FnVCCB_GetLoadEvaluateMode(
    const VccbCellInfo_type &cellInfo, const connModeLBInfo_type &connModeLbInfo, const bool isRedCapUe)
{
    // In 25B, LB operation for RedCap UE is not affected by LBM parameter.
    if (not FnVCCB_IsAffectedByLbmParameter(cellInfo, isRedCapUe)) return connModeLbInfo.loadEvaluateMode;

    uint32_t adjustedLbmIndex =
        FnVCCB_AdjustNrLbmIndexForParameterType(cellInfo.nrLbmConfigurationIndex, LBM_PARAMETER_TYPE_CELL_CONFIG);
    const lbmConnModeLbInfo_type &lbmConnModeLbInfo = cellInfo.lbCfg.lbmConfiguration.lbmConnModeLbInfo;

    switch (adjustedLbmIndex)
    {
        case NR_LBM_DISABLE:
            return connModeLbInfo.loadEvaluateMode;
        case NR_LBM_WINDOW0_UPDATE:
            return lbmConnModeLbInfo.loadEvaluateMode;

        default:
            break;
    }

    return connModeLbInfo.loadEvaluateMode;
}

uint8_t FnVCCB_GetLbThresholdGroup(const VccbCellInfo_type &cellInfo, const measurementObjectNRBaseDb_type &measObj,
    const uint8_t measObjectIdx, const bool isRedCapUe)
{
    // In 25B, LB operation for RedCap UE is not affected by LBM parameter.
    if (not FnVCCB_IsAffectedByLbmParameter(cellInfo, isRedCapUe)) return measObj.loadBalancingThresholdGroup;

    uint32_t adjustedLbmIndex =
        FnVCCB_AdjustNrLbmIndexForParameterType(cellInfo.nrLbmConfigurationIndex, LBM_PARAMETER_TYPE_CELL_CONFIG);
    const lbmConnModeLbInfo_type &lbmConnModeLbInfo = cellInfo.lbCfg.lbmConfiguration.lbmConnModeLbInfo;

    switch (adjustedLbmIndex)
    {
        case NR_LBM_DISABLE:
            return measObj.loadBalancingThresholdGroup;
        case NR_LBM_WINDOW0_UPDATE:
            if (measObjectIdx >= MAX_NR_OF_OBJECT_ID_DB) break;
            if (lbmConnModeLbInfo.loadBalancingThresholdGroup[measObjectIdx] == NOT_UPDATED) break;
            return static_cast<uint8_t>(lbmConnModeLbInfo.loadBalancingThresholdGroup[measObjectIdx]);

        default:
            break;
    }

    return measObj.loadBalancingThresholdGroup;
}

// uint8_t FnVCCB_GetAvailRscThreshold(
//     const VccbCellInfo_type &cellInfo, const connModeLBInfo_type &connModeLbInfo, const bool isRedCapUe)
// {
//     // In 25B, LB operation for RedCap UE is not affected by LBM parameter.
//     if (not FnVCCB_IsAffectedByLbmParameter(cellInfo, isRedCapUe)) return connModeLbInfo.availRscThreshold;

//     uint32_t adjustedLbmIndex =
//         FnVCCB_AdjustNrLbmIndexForParameterType(cellInfo.nrLbmConfigurationIndex, LBM_PARAMETER_TYPE_ENTRY);
//     if (adjustedLbmIndex >= MAX_NR_LBM_CONFIG_ENTRIES) return connModeLbInfo.availRscThreshold;

//     const lbmConnModeLbInfo_type &lbmConnModeLbInfo = cellInfo.lbCfg.lbmConfiguration.lbmConnModeLbInfo;
//     /*
//         NR_LBM_DISABLE           : lbCfg.connModeLbInfo.availRscThreshold
//         NR_LBM_WINDOW0_UPDATE     : lbCfg.lbmConfiguration.availRscThreshold[NR_LBM_WINDOW0_UPDATE]
//         NR_LBM_WINDOW0_FALLBACK   : lbCfg.lbmConfiguration.availRscThreshold[NR_LBM_WINDOW0_FALLBACK]
//         NR_LBM_WINDOW1_UPDATE     : lbCfg.lbmConfiguration.availRscThreshold[NR_LBM_WINDOW1_UPDATE]
//         NR_LBM_WINDOW1_FALLBACK   : lbCfg.lbmConfiguration.availRscThreshold[NR_LBM_WINDOW1_FALLBACK]
//     */
//     switch (adjustedLbmIndex)
//     {
//         case NR_LBM_DISABLE:
//             return connModeLbInfo.availRscThreshold;
//         case NR_LBM_WINDOW0_UPDATE:
//         case NR_LBM_WINDOW0_FALLBACK:
//         case NR_LBM_WINDOW1_UPDATE:
//         case NR_LBM_WINDOW1_FALLBACK:
//             if (lbmConnModeLbInfo.lbmConnModeLbEntry[adjustedLbmIndex].availRscThreshold == NOT_UPDATED) break;
//             return static_cast<uint8_t>(lbmConnModeLbInfo.lbmConnModeLbEntry[adjustedLbmIndex].availRscThreshold);

//         default:
//             break;
//     }
//     return connModeLbInfo.availRscThreshold;
// }

// uint8_t FnVCCB_GetAvailRscThreshold1(
//     const VccbCellInfo_type &cellInfo, const connModeLBInfo_type &connModeLbInfo, const bool isRedCapUe)
// {
//     // In 25B, LB operation for RedCap UE is not affected by LBM parameter.
//     if (not FnVCCB_IsAffectedByLbmParameter(cellInfo, isRedCapUe)) return connModeLbInfo.availRscThreshold1;

//     uint32_t adjustedLbmIndex =
//         FnVCCB_AdjustNrLbmIndexForParameterType(cellInfo.nrLbmConfigurationIndex, LBM_PARAMETER_TYPE_ENTRY);
//     if (adjustedLbmIndex >= MAX_NR_LBM_CONFIG_ENTRIES) return connModeLbInfo.availRscThreshold1;

//     const lbmConnModeLbInfo_type &lbmConnModeLbInfo = cellInfo.lbCfg.lbmConfiguration.lbmConnModeLbInfo;

//     switch (adjustedLbmIndex)
//     {
//         case NR_LBM_DISABLE:
//             return connModeLbInfo.availRscThreshold1;
//         case NR_LBM_WINDOW0_UPDATE:
//         case NR_LBM_WINDOW0_FALLBACK:
//         case NR_LBM_WINDOW1_UPDATE:
//         case NR_LBM_WINDOW1_FALLBACK:
//             if (lbmConnModeLbInfo.lbmConnModeLbEntry[adjustedLbmIndex].availRscThreshold1 == NOT_UPDATED) break;
//             return static_cast<uint8_t>(lbmConnModeLbInfo.lbmConnModeLbEntry[adjustedLbmIndex].availRscThreshold1);

//         default:
//             break;
//     }

//     return connModeLbInfo.availRscThreshold1;
// }

// uint8_t FnVCCB_GetAvailRscThreshold2(
//     const VccbCellInfo_type &cellInfo, const connModeLBInfo_type &connModeLbInfo, const bool isRedCapUe)
// {
//     // In 25B, LB operation for RedCap UE is not affected by LBM parameter.
//     if (not FnVCCB_IsAffectedByLbmParameter(cellInfo, isRedCapUe)) return connModeLbInfo.availRscThreshold2;

//     uint32_t adjustedLbmIndex =
//         FnVCCB_AdjustNrLbmIndexForParameterType(cellInfo.nrLbmConfigurationIndex, LBM_PARAMETER_TYPE_ENTRY);
//     if (adjustedLbmIndex >= MAX_NR_LBM_CONFIG_ENTRIES) return connModeLbInfo.availRscThreshold2;

//     const lbmConnModeLbInfo_type &lbmConnModeLbInfo = cellInfo.lbCfg.lbmConfiguration.lbmConnModeLbInfo;

//     switch (adjustedLbmIndex)
//     {
//         case NR_LBM_DISABLE:
//             return connModeLbInfo.availRscThreshold2;
//         case NR_LBM_WINDOW0_UPDATE:
//         case NR_LBM_WINDOW0_FALLBACK:
//         case NR_LBM_WINDOW1_UPDATE:
//         case NR_LBM_WINDOW1_FALLBACK:
//             if (lbmConnModeLbInfo.lbmConnModeLbEntry[adjustedLbmIndex].availRscThreshold2 == NOT_UPDATED) break;
//             return static_cast<uint8_t>(lbmConnModeLbInfo.lbmConnModeLbEntry[adjustedLbmIndex].availRscThreshold2);

//         default:
//             break;
//     }
//     return connModeLbInfo.availRscThreshold2;
// }

// uint8_t FnVCCB_GetAvailRscThreshold3(
//     const VccbCellInfo_type &cellInfo, const connModeLBInfo_type &connModeLbInfo, const bool isRedCapUe)
// {
//     // In 25B, LB operation for RedCap UE is not affected by LBM parameter.
//     if (not FnVCCB_IsAffectedByLbmParameter(cellInfo, isRedCapUe)) return connModeLbInfo.availRscThreshold3;

//     uint32_t adjustedLbmIndex =
//         FnVCCB_AdjustNrLbmIndexForParameterType(cellInfo.nrLbmConfigurationIndex, LBM_PARAMETER_TYPE_ENTRY);
//     if (adjustedLbmIndex >= MAX_NR_LBM_CONFIG_ENTRIES) return connModeLbInfo.availRscThreshold3;

//     const lbmConnModeLbInfo_type &lbmConnModeLbInfo = cellInfo.lbCfg.lbmConfiguration.lbmConnModeLbInfo;

//     switch (adjustedLbmIndex)
//     {
//         case NR_LBM_DISABLE:
//             return connModeLbInfo.availRscThreshold3;
//         case NR_LBM_WINDOW0_UPDATE:
//         case NR_LBM_WINDOW0_FALLBACK:
//         case NR_LBM_WINDOW1_UPDATE:
//         case NR_LBM_WINDOW1_FALLBACK:
//             if (lbmConnModeLbInfo.lbmConnModeLbEntry[adjustedLbmIndex].availRscThreshold3 == NOT_UPDATED) break;
//             return static_cast<uint8_t>(lbmConnModeLbInfo.lbmConnModeLbEntry[adjustedLbmIndex].availRscThreshold3);

//         default:
//             break;
//     }
//     return connModeLbInfo.availRscThreshold3;
// }


uint8_t FnVCCB_GetAvailRscThresholdGroup(const callInfo_type &rCi, const VccbCellInfo_type &rCell, const uint8_t thresholdGroupType)
{
    const auto &connModeLbInfo = rCell.lbCfg.connModeLbInfo;

    // In 25B, LB operation for RedCap UE is not affected by LBM parameter.
    const auto isRedCapUe = IS_REDCAP_UE(&rCi);
    if (not FnVCCB_IsAffectedByLbmParameter(rCell, isRedCapUe))
    {
        VCCB_CONN_LB_GET_DEFAULT_AVAIL_RSC_THRESHOLD(thresholdGroupType);
    }

    uint32_t adjustedLbmIndex =
        FnVCCB_AdjustNrLbmIndexForParameterType(rCell.nrLbmConfigurationIndex, LBM_PARAMETER_TYPE_ENTRY);
    if (adjustedLbmIndex >= MAX_NR_LBM_CONFIG_ENTRIES)
    {
        VCCB_CONN_LB_GET_DEFAULT_AVAIL_RSC_THRESHOLD(thresholdGroupType);
    }

    const lbmConnModeLbInfo_type &lbmConnModeLbInfo = rCell.lbCfg.lbmConfiguration.lbmConnModeLbInfo;

    switch (adjustedLbmIndex)
    {
        case NR_LBM_DISABLE:
        VCCB_CONN_LB_GET_DEFAULT_AVAIL_RSC_THRESHOLD(thresholdGroupType);
        case NR_LBM_WINDOW0_UPDATE:
        case NR_LBM_WINDOW0_FALLBACK:
        case NR_LBM_WINDOW1_UPDATE:
        case NR_LBM_WINDOW1_FALLBACK:
            switch (thresholdGroupType)
            {
                case CONN_LB_THRESHOLD_GROUP0:
                    if (lbmConnModeLbInfo.lbmConnModeLbEntry[adjustedLbmIndex].availRscThreshold == NOT_UPDATED) break;
                    return static_cast<uint8_t>(
                        lbmConnModeLbInfo.lbmConnModeLbEntry[adjustedLbmIndex].availRscThreshold);
                case CONN_LB_THRESHOLD_GROUP1:
                    if (lbmConnModeLbInfo.lbmConnModeLbEntry[adjustedLbmIndex].availRscThreshold1 == NOT_UPDATED) break;
                    return static_cast<uint8_t>(
                        lbmConnModeLbInfo.lbmConnModeLbEntry[adjustedLbmIndex].availRscThreshold1);
                case CONN_LB_THRESHOLD_GROUP2:
                    if (lbmConnModeLbInfo.lbmConnModeLbEntry[adjustedLbmIndex].availRscThreshold2 == NOT_UPDATED) break;
                    return static_cast<uint8_t>(
                        lbmConnModeLbInfo.lbmConnModeLbEntry[adjustedLbmIndex].availRscThreshold2);
                case CONN_LB_THRESHOLD_GROUP3:
                    if (lbmConnModeLbInfo.lbmConnModeLbEntry[adjustedLbmIndex].availRscThreshold3 == NOT_UPDATED) break;
                    return static_cast<uint8_t>(
                        lbmConnModeLbInfo.lbmConnModeLbEntry[adjustedLbmIndex].availRscThreshold3);
                default:
                    break;
            }
        default:
            break;
    }

    VCCB_CONN_LB_GET_DEFAULT_AVAIL_RSC_THRESHOLD(thresholdGroupType);

    return 0;  // by default
}

uint8_t FnVCCB_GetResourceDelta(const VccbCellInfo_type &cellInfo, const bool isRedCapUe)
{
    const auto &connModeLbInfo = cellInfo.lbCfg.connModeLbInfo;

    // In 25B, LB operation for RedCap UE is not affected by LBM parameter.
    if (not FnVCCB_IsAffectedByLbmParameter(cellInfo, isRedCapUe)) return connModeLbInfo.rscDelta;

    uint32_t adjustedLbmIndex =
        FnVCCB_AdjustNrLbmIndexForParameterType(cellInfo.nrLbmConfigurationIndex, LBM_PARAMETER_TYPE_ENTRY);
    if (adjustedLbmIndex >= MAX_NR_LBM_CONFIG_ENTRIES) return connModeLbInfo.rscDelta;

    const lbmConnModeLbInfo_type &lbmConnModeLbInfo = cellInfo.lbCfg.lbmConfiguration.lbmConnModeLbInfo;

    switch (adjustedLbmIndex)
    {
        case NR_LBM_DISABLE:
            return connModeLbInfo.rscDelta;
        case NR_LBM_WINDOW0_UPDATE:
        case NR_LBM_WINDOW0_FALLBACK:
        case NR_LBM_WINDOW1_UPDATE:
        case NR_LBM_WINDOW1_FALLBACK:
            if (lbmConnModeLbInfo.lbmConnModeLbEntry[adjustedLbmIndex].rscDelta == NOT_UPDATED) break;
            return static_cast<uint8_t>(lbmConnModeLbInfo.lbmConnModeLbEntry[adjustedLbmIndex].rscDelta);
        default:
            break;
    }
    return connModeLbInfo.rscDelta;
}

/****************************************************************************
    [FGR-LC0708] Load based PSCell Change for EN-DC
****************************************************************************/
// {{{

namespace
{
/**
 * @brief Initialize load balancing state machine for NSA.
 * 
 * @param call info
 */
inline void VCCB_NSA_ResetLbState(callInfo_type &call)
{
    VCCB_CLEAR_TIMER(&call.lbMrTimer, CANCEL_TIMER);
}

/**
 * @brief FGR-LC0708 Load based PSCell Change for EN-DC (FR33)
 *        Returns true if the first SCG or Split bearer is generated.
 * 
 * @param call info
 * @return true 
 * @return false 
 */
bool VCCB_NSA_IsFirstScgSplitBearerAdded(const callInfo_type &call)
{
    AUTO_TRACE_FUNC;

    int erabsToBeAdded = 0;

    for (int i = 0; i < MAX_ERAB_PER_CALL; ++i)
    {
        if (CI_use != call.erabInfo[i].usage)
        {
            continue;
        }
        const auto hasScgResource =
            ((SCG_Bearer == call.erabInfo[i].bearerType) || (SPLIT_Bearer == call.erabInfo[i].bearerType));
        if (not hasScgResource)
        {
            VCCB_PRINT_LOG_SA_LB(&call, "%s: MCG ERAB(%u) omitted!\n", __FUNCTION__, call.erabInfo[i].eRABId);
            continue;
        }
        const auto isEstablished = (ERAB_Idle == call.erabInfo[i].erabStatus);
        if (isEstablished)
        {
            VCCB_PRINT_LOG_SA_LB(
                &call, "%s: SCG/Split ERAB(%u) already established!\n", __FUNCTION__, call.erabInfo[i].eRABId);
            return false;
        }
        const auto isBeingAdded = (ERAB_Setup == call.erabInfo[i].erabStatus);
        const auto isChangedFromMcgToScgSplit =
            ((ERAB_Modify == call.erabInfo[i].erabStatus) && (MCG_Bearer == call.erabInfo[i].preveBearerType));
        if (isBeingAdded || isChangedFromMcgToScgSplit)
        {
            ++erabsToBeAdded;
        }
    }

    return (0 < erabsToBeAdded);
}

/**
 * @brief FGR-LC0708 Load based PSCell Change for EN-DC (FR34)
 *        Returns true if LB feature is applicable for UE's SPID.
 * 
 * @param call info
 * @param cell with LB configuration
 * @return true 
 * @return false 
 */
bool VCCB_NSA_IsLbPossibleForSpid(const callInfo_type &call, const VccbCellInfo_type &cell)
{
    AUTO_TRACE_FUNC;

    // LB is allowed for UE without SPID.
    if (OPT_NOT_PRESENT == call.ueInfo.rfsp.rfspPresent)
    {
        VCCB_PRINT_LOG_SA_LB(&call, "%s: UE has no SPID - feature allowed.\n", __FUNCTION__);
        return true;
    }
    // Convert SPID value to SPID-index.
    if ((1 > call.ueInfo.rfsp.subscriberProfile) || (MAX_SPID_VALUE < call.ueInfo.rfsp.subscriberProfile))
    {
        VCCB_PRINT_LOG_SA_LB(&call, "%s: Invalid SPID value(%u).\n", __FUNCTION__, call.ueInfo.rfsp.subscriberProfile);
        return true;  // LB allowed as VCCB cannot verify if SPID is disallowed.
    }
    const auto spidIdx = call.ueInfo.rfsp.subscriberProfile - 1;
    // LB is allowed for SPID without entry spidLbSupportEntries.
    if (CI_use != cell.lbCfg.spidLbSupport.spidLbSupportEntries[spidIdx].usage)
    {
        VCCB_PRINT_LOG_SA_LB(&call, "%s: Feature allowed - no matching configuration for SPID(%u).\n", __FUNCTION__,
            call.ueInfo.rfsp.subscriberProfile);
        return true;
    }
    // Result depnds on the configured value.
    return (TRUE == cell.lbCfg.spidLbSupport.spidLbSupportEntries[spidIdx].supportLbPscellChange);
}

/**
 * @brief FGR-LC0708 Load based PSCell Change for EN-DC (FR34)
 *        Returns true if LB feature is applicable for call with specific ERABs and QCIs.
 * 
 * @param call info
 * @param gnbNum for QCI configuration
 * @return true 
 * @return false 
 */
bool VCCB_NSA_IsLbPossibleForQci(const callInfo_type &call, uint8_t gnbNum)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_VALID_GNBNUM_RET_VAL(gnbNum, true);
    const auto &gnb = GNBINFO[gnbNum];

    // It is enough that one QCI is disabled to disable LB for UE.
    for (const auto &erab : call.erabInfo)
    {
        if (CI_use != erab.usage)
        {
            continue;
        }
        if (MAX_QCI_VALUE <= erab.erabQos.qciValue.QCI)
        {
            VCCB_PRINT_LOG_SA_LB(&call, "%s: ERAB(%u) has invalid QCI(%u) value!\n", __FUNCTION__, erab.eRABId,
                erab.erabQos.qciValue.QCI);
            continue;
        }
        const auto &qciSupportEntry = gnb.qciSupport[erab.erabQos.qciValue.QCI];
        // Allow QCI that has no matching entry in ConfD.
        if (FALSE == qciSupportEntry.usage)
        {
            VCCB_PRINT_LOG_SA_LB(&call, "%s: QCI(%u) has no matching config - allowed for LB.\n", __FUNCTION__,
                erab.erabQos.qciValue.QCI);
            continue;
        }
        if (FALSE == qciSupportEntry.supportLbPscellChange)
        {
            VCCB_PRINT_LOG_SA_LB(
                &call, "%s: LB for QCI(%u) disabled in configuration.\n", __FUNCTION__, erab.erabQos.qciValue.QCI);
            return false;
        }
    }
    return true;
}

/**
 * @brief Returns true if there is forced mobility restriction timer going.
 * 
 * @param call info
 * @return true 
 * @return false 
 */
bool VCCB_NSA_IsWaitingForcedMobRestrictionTimer(const callInfo_type &call)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_VALID_GNBNUM_RET_VAL(call.gnbNum, false);
    const VccbGnbInfo_type &gnb = GNBINFO[call.gnbNum];

    const auto isFeatureEnabled = (VCCB_FLAG_ON == gnb.cfg.endcForcedRestriction.featureEnabled);
    const auto isNotTimerEvent  = (FALSE == call.bitFlag.isEndcForcedRestrictionTimerProcessing);

    return (isFeatureEnabled && isNotTimerEvent);
}

/**
 * @brief Returns true if VCCB is processing forced mobility restriction timer expiry right now.
 * 
 * @param call info
 * @return true 
 * @return false 
 */
bool VCCB_NSA_IsProcessingForcedMobRestrictionTimer(const callInfo_type &call)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_VALID_GNBNUM_RET_VAL(call.gnbNum, false);
    const VccbGnbInfo_type &gnb = GNBINFO[call.gnbNum];

    const auto isFeatureEnabled = (VCCB_FLAG_ON == gnb.cfg.endcForcedRestriction.featureEnabled);
    const auto isTimerEvent     = (TRUE == call.bitFlag.isEndcForcedRestrictionTimerProcessing);

    return (isFeatureEnabled && isTimerEvent);
}

/**
 * @brief Returns current LB measurements state (works also during HO).
 * 
 * @param call info
 * @return NsaLbMeasState_enum 
 */
inline NsaLbMeasState_enum VCCB_NSA_GetLbMeasState(const callInfo_type &call)
{
    return (VCCB_ENDC_IsHoOngoing(call)
                ? static_cast<NsaLbMeasState_enum>(call.hoInfo.nsaLbMeasState)
                : static_cast<NsaLbMeasState_enum>(call.nsaMeas.nsaLbMeasState));
}

/**
 * @brief FGR-LC0708 Load based PSCell Change for EN-DC (FR33)
 *        Returns true if LB is applicable in current scenario.
 * 
 * @param call info
 * @return true 
 * @return false 
 */
bool VCCB_NSA_IsLbApplicableScenario(callInfo_type &call)
{
    AUTO_TRACE_FUNC;

    if (VCCB_NSA_IsFirstScgSplitBearerAdded(call))
    {
        // Exclude SN Change with forced mobility restriction timer.
        if (VCCB_NSA_IsSnChange(call) && VCCB_NSA_IsWaitingForcedMobRestrictionTimer(call))
        {
            VCCB_PRINT_LOG_SA_LB(&call, "%s: No, waiting forced mobility restriction timer.\n", __FUNCTION__);
            VCCB_NSA_SetLbMeasState(call, NSA_LB_MEAS_STATE_UNKNOWN); // State will be checked again.
            return false;
        }
        VCCB_PRINT_LOG_SA_LB(&call, "%s: Yes, applicable during first SCG/Split bearer addition.\n", __FUNCTION__);
        return true;
    }
    if (VCCB_NSA_IsIntraSnHo(call))
    {
        if (VCCB_NSA_IsWaitingForcedMobRestrictionTimer(call))
        {
            VCCB_PRINT_LOG_SA_LB(&call, "%s: No, waiting forced mobility restriction timer.\n", __FUNCTION__);
            VCCB_NSA_SetLbMeasState(call, NSA_LB_MEAS_STATE_UNKNOWN); // State will be checked again.
            return false;
        }
        VCCB_PRINT_LOG_SA_LB(&call, "%s: Yes, applicable during intra-SN PSCell Change.\n", __FUNCTION__);
        return true;
    }
    if (VCCB_NSA_IsProcessingForcedMobRestrictionTimer(call))
    {
        VCCB_PRINT_LOG_SA_LB(
            &call, "%s: Yes, applicable after forced mobility restriction timer expired.\n", __FUNCTION__);
        return true;
    }
    VCCB_PRINT_LOG_SA_LB(&call, "%s: No, unsupported scenario.\n", __FUNCTION__);
    return false;
}
} // namespace

/**
 * @brief Set current LB measurements state (works also during HO).
 * 
 * @param call info
 * @param state new LB measurements state
 */
void VCCB_NSA_SetLbMeasState(callInfo_type &call, NsaLbMeasState_enum state)
{
    if (VCCB_ENDC_IsHoOngoing(call))
    {
        VCCB_PRINT_LOG_SA_LB(&call, "%s: [HO] (%u) -> (%u)\n", __FUNCTION__, call.hoInfo.nsaLbMeasState, state);
        call.hoInfo.nsaLbMeasState = state;
    }
    else
    {
        VCCB_PRINT_LOG_SA_LB(
            &call, "%s: (%u) -> (%u)\n", __FUNCTION__, call.nsaMeas.nsaLbMeasState, state);
        call.nsaMeas.nsaLbMeasState = state;
    }
}

/**
 * @brief Returns true if MR for EN-DC LB PSCell Change processing is needed.
 *        The function verifies if:
 *         - CPU is not overloaded.
 *         - There is no LB deactivation task queued.
 * 
 * @return true 
 * @return false 
 */
bool VCCB_NSA_NeedToProcessLbPscellChangeMr(const callInfo_type &call)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(call.servCellNum, false);

    const auto &pscell = CELLINFO[call.servCellNum];
    const auto &lbInfo = pscell.lbCfg.pscellChangeLbInfo;

    // FGR-LC0708 FR10 - feature on/off option.
    if (not lbInfo.pscellChangeLbSwitch)
    {
        VCCB_PRINT_LOG_SA_LB(&call, "%s: LB is off.\n", __FUNCTION__);
        return false;
    }
    // FGR-LC0708 FR100 - stop load balancing function if CPU is overloaded.
    if (VCCB_LB_IsCpuOverloaded(call))
    {
        // Cause is logged by the above function.
        return false;
    }
    // Ignore MR if LB timer action is already queued.
    if (VCCB_Q_IsActionQueued(call, ENQUEUE_ACTION_LB_MEAS_DEACTIVE))
    {
        VCCB_PRINT_LOG_SA_LB(&call, "%s: No, LB deactivation already queued.\n", __FUNCTION__);
        return false;
    }

    return true;
}

/**
 * @brief Returns true if:
 *        - available RRC Connection Capacity Value of Serving Cell < skipping-available-ue-threshold
 * 
 * @param rCell cell info
 * @return true 
 * @return false 
 */
inline bool VCCB_NSA_IsSkippingConditionSatisfied(const VccbCellInfo_type &rCell)
{
    return (rCell.cellRscInfo.numAvailUe < rCell.lbCfg.pscellChangeLbInfo.skipAvailableUeThreshold);
}

/**
 * @brief FGR-LC0708 Load based PSCell Change for EN-DC
 *        Check if the feature is applicable by veryfing:
 *         - FOO, current scenario, SPID, QCI, CPU.
 * 
 * @param call info
 * @param cellNum where LB measurements are being configured
 */
void VCCB_NSA_DetermineLbMeasState(callInfo_type &call, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_VALID_CELLNUM_VOID(cellNum);

    const VccbCellInfo_type &cell  = CELLINFO[cellNum];
    const auto &pscellChangeLbInfo = cell.lbCfg.pscellChangeLbInfo;

    VCCB_NSA_SetLbMeasState(call, NSA_LB_MEAS_STATE_INACTIVE);

    // FGR-LC0708 FR10 - feature on/off option.
    if (not pscellChangeLbInfo.pscellChangeLbSwitch)
    {
        VCCB_PRINT_LOG_SA_LB(&call, "%s: LB is off.\n", __FUNCTION__);
        return;
    }
    // FGR-LC0708 FR34 - disable feature for configured SPID.
    if (not VCCB_NSA_IsLbPossibleForSpid(call, cell))
    {
        VCCB_PRINT_LOG_SA_LB(&call, "%s: LB disabled based on SPID configuration.\n", __FUNCTION__);
        return;
    }
    // FGR-LC0708 FR34 - disable feature for configured QCI.
    if (not VCCB_NSA_IsLbPossibleForQci(call, cell.gnbNum))
    {
        VCCB_PRINT_LOG_SA_LB(&call, "%s: LB disabled based on QCI configuration.\n", __FUNCTION__);
        return;
    }
    // FGR-LC0708 FR100 - disable feature if CPU is overloaded.
    if (VCCB_LB_IsCpuOverloaded(call))
    {
        // Cause is logged by the above function.
        return;
    }
    // FGR-LC0708 FR33 - UE has at least one SCG or Split bearer.
    if (not VCCB_NSA_IsLbApplicableScenario(call))
    {
        // Cause is logged by the above function.
        return;
    }
    // FGR-LC0708 FR34 - skipping condition is satisfied.
    if (VCCB_NSA_IsSkippingConditionSatisfied(cell))
    {
        VCCB_PRINT_LOG_SA_LB(&call, "%s: LB disabled based on skipping condition.\n", __FUNCTION__);
        return;
    }

    VCCB_NSA_SetLbMeasState(call, NSA_LB_MEAS_STATE_ACTIVE);
    return;
}

/**
 * @brief FGR-LC0708 Load based PSCell Change for EN-DC
 *        Returns true if LB measurements shall be installed on UE.
 * 
 * @param call info
 * @param cellNum where LB measurements are being configured
 * @return true 
 * @return false 
 */
bool VCCB_NSA_IsLbFeatureApplicable(callInfo_type &call, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    const auto currentLbState = VCCB_NSA_GetLbMeasState(call);
    VCCB_PRINT_LOG_SA_LB(&call, "%s: LB measurements state is (%u).\n", __FUNCTION__, currentLbState);
    if (NSA_LB_MEAS_STATE_UNKNOWN == currentLbState)
    {
        VCCB_NSA_DetermineLbMeasState(call, cellNum);
    }

    // Feature is applicable.
    return (NSA_LB_MEAS_STATE_ACTIVE == VCCB_NSA_GetLbMeasState(call));
}

/**
 * @brief FGR-LC0708 Load based PSCell Change for EN-DC
 *        Actions performed on successful intra-SN PSCell Change.
 * 
 * @param call info
 */
void VCCB_NSA_LbFinalizeIntraSnHo(callInfo_type &call)
{
    AUTO_TRACE_FUNC;

    // FGR-LC0708 - reset LB state only if LB is inactive on target cell.
    if (not VCCB_CheckLbMeasActivated(call))
    {
        VCCB_NSA_ResetLbState(call);
    }
    // FGR-LC0708 - after successful intra-SN HO cancel queued LB meas-reconfig action.
    if (VCCB_Q_IsActionQueued(call, ENQUEUE_ACTION_LB_MEAS_DEACTIVE))
    {
        VCCB_Q_RemoveQueuedAction(call, ENQUEUE_ACTION_LB_MEAS_DEACTIVE);
    }
    // Save new LB measurements state.
    call.nsaMeas.nsaLbMeasState = call.hoInfo.nsaLbMeasState;
}

// FGR-LC0703 FGR-LC0712 26A only using strongest PCI only
bool FnVCCB_IsStrongestPciOnlyModeForLB(callInfo_type &rCall, tgtSelectionParam_type tgtSelParam)
{   
    VCCB_CHECK_E_RANGE_AND_VAL(rCall.servCellNum, MAX_CELL_NUM_VCCB, false);

    const VccbCellInfo_type *const pCell = &CELLINFO[rCall.servCellNum];

    if (IS_VONR_LB_NR_HANDOVER_PURPOSE(tgtSelParam.reportType, tgtSelParam.reportPurpose) &&
            pCell->lbCfg.voNrLbInfo.targetCellSelectionStrongestOnly)
    {   
        VCCB_PRINT_LOG_VONR_LB(&rCall, "[VONRLB] Only the cell with the highest signal strength as the target cell \n");
        return true;
    }

    if (IS_LB_NR_HANDOVER_PURPOSE(tgtSelParam.reportType, tgtSelParam.reportPurpose) &&
            pCell->lbCfg.connModeLbInfo.targetCellSelectionStrongestOnly)
    {   
        VCCB_PRINT_LOG_SA_LB(&rCall, "[SALB] Only the cell with the highest signal strength as the target cell \n");
        return true;
    }

    return false;
}


////// per ACPF //////
void FnVCCB_InitPeriodicLbInfo()
{
    AUTO_TRACE_FUNC;

    periodicLbInfo_type &rPeriodicLbInfo = CFG->periodicLbInfo;

    rPeriodicLbInfo.cntMaxAvailableUePerThread = MAX_PERIODIC_LB_SELECTABLE_UE_PER_THREAD; // 10
    rPeriodicLbInfo.startUeIndex = 0;
    rPeriodicLbInfo.cntMaxSearchableUe = MAX_PERIODIC_LB_SEARCH_UE_PER_UE_SELECTION; // 10000
}

bool FnVCCB_IsCellPeriodicLbSwitchEnabled(uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);

    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    if (pCell->status == N_EQUIP) return false;
    if (pCell->serviceState == CELL_OOS) return false;

    return (pCell->lbCfg.connModeLbInfo.periodicLbSwitch == TRUE);
}

bool FnVCCB_IsAnyCellPeriodicLbSwitchEnabled()
{
    AUTO_TRACE_FUNC;

    for (uint16_t cellNum = 0; cellNum < MAX_CELL_NUM_VCCB; cellNum++)
    {
        if (FnVCCB_IsCellPeriodicLbSwitchEnabled(cellNum))
            return true;
    }

    return false;
}

bool FnVCCB_IsPeriodicLbGuardTimerRunning(struct timespec periodicLbGuardTimeStamp, const uint16_t periodicLbGuardTime)
{   
    AUTO_TRACE_FUNC;

    auto diffTime = VLIB_getTickDifference(periodicLbGuardTimeStamp);
    if (diffTime < periodicLbGuardTime)
    {
        return true;
    }

    return false;
}  

bool FnVCCB_IsPeriodicLbTriggerAllowed(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    connModeLBInfo_type *ptConnInfo = &pCell->lbCfg.connModeLbInfo;

    // Check load balancing usage
    uint8_t usage = FnVCCB_GetIntraNrLbSwitch(*pCell, *ptConnInfo, IS_REDCAP_UE(ptCi));
    if (usage != VCCB_FLAG_ON)
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[PLB] Load balancing is off \n");
        return false;
    }

    if ((ptCi->stateCmd == IntraRatHO_cmd) || (ptCi->stateCmd == InterRatHO_cmd))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[PLB] Cannot Trigger Load Balancing during HO \n");
        return false;
    }

    if ((ptCi->ueContainerNR.rxFlag != 0) &&
        (IS_FALLBACK_CASE(ptCi)) &&
        (ptCi->redirectionInfo.actualRedirectionMethod != BLIND_REDIR_ONLY))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[PLB] Cannot trigger load balancing by fallback \n");
        return false;
    }

    // Check skipping condition (FR35)
    if (FnVCCB_CheckSkipLoadBalancingCondition(*ptConnInfo, pCell->cellRscInfo))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[PLB] Skipping LB condition \n");
        return false;
    }

    // Check function priorities condition
    if (VCCM_CheckLoadBalancingTrigger(ptCi) == FALSE)
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[PLB] Cannot trigger load balancing due to function priorities \n");
        return false;
    }

    // Check cell load condition
    if ((FnVCCB_IsServingCellOverloaded_PdcchCceSaLb(ptCi) != LB_LOAD_OVERLOAD) &&
        (FnVCCB_IsServingCellOverloaded_AvailRscSaLb(ptCi) != LB_LOAD_OVERLOAD))
    {
        VCCB_PRINT_LOG_SA_LB(ptCi, "[PLB] Serving is not overloaded. \n");
        return false;
    }

    return true;
}

void FnVCCB_SelectUeForPeriodicLb()
{
    AUTO_TRACE_FUNC;

    const uint8_t maxCallThreadId = MAX_CALL_THREAD_NUM_VCCB;
    const uint32_t maxCallNum = MAX_CALL_NUM_VCCB;
    const uint32_t maxCellNum = MAX_CELL_NUM_VCCB;

    periodicLbInfo_type &rPeriodicLbInfo = CFG->periodicLbInfo;

    uint8_t cntTotalSelectedUe = 0;
    uint8_t cntSelectedUePerCell[maxCellNum] = {0, };
    uint8_t cntTotalSearchedUe = 0;

    for (uint8_t threadId = 0; threadId < maxCallThreadId; threadId++)
    {
        rPeriodicLbInfo.selectedUePerThread[threadId].numUe = 0;
    }

    uint32_t callId = (rPeriodicLbInfo.startUeIndex < maxCallNum ? rPeriodicLbInfo.startUeIndex : 0);

    for (;callId < maxCallNum; callId++)
    {
        if (cntTotalSearchedUe >= rPeriodicLbInfo.cntMaxSearchableUe ||
            cntTotalSelectedUe >= rPeriodicLbInfo.cntMaxAvailableTotalUe)
        {
            break;
        }
        cntTotalSearchedUe++;

        callInfo_type *ptCi = FnVCCB_GetCallInUse(callId);
        if (ptCi == NULL) continue;

        const uint16_t cellNum = ptCi->servCellNum;
        VCCB_CHECK_E_RANGE_AND_CONTINUE(cellNum, maxCellNum);

        const uint8_t myThreadId = ptCi->myThreadId;
        VCCB_CHECK_E_RANGE_AND_CONTINUE(myThreadId, maxCallThreadId);
        targetUeListInfo_type &selectedUePerThread = rPeriodicLbInfo.selectedUePerThread[myThreadId];

        if (cntSelectedUePerCell[cellNum] >= rPeriodicLbInfo.cntMaxAvailableUePerCell)
        {
            continue;
        }

        if (selectedUePerThread.numUe >= rPeriodicLbInfo.cntMaxAvailableUePerThread)
        {
            continue;
        }

        if (not FnVCCB_IsCellPeriodicLbSwitchEnabled(cellNum))
        {
            continue;
        }

        if (IS_TIMER_VALID(ptCi->lbMrTimer))
        {
            continue;
        }

        if (FnVCCB_IsPeriodicLbGuardTimerRunning(ptCi->periodicLbGuardTimeStamp, rPeriodicLbInfo.periodicLbGuardTime))
        {
            continue;
        }

        if ((ptCi->stateCmd != Idle_cmd) || (ptCi->state != STATE_Conn))
        {
            continue;
        }

        if (ptCi->callType == E_CALLTYPE_NSA || IS_NRDC_SN(ptCi))
        {
            continue;
        }

        if (not FnVCCB_IsPeriodicLbTriggerAllowed(ptCi, cellNum))
        {
            continue;
        }

        cntTotalSelectedUe++;
        cntSelectedUePerCell[cellNum]++;
        selectedUePerThread.callId[selectedUePerThread.numUe++] = callId;
    }

    rPeriodicLbInfo.startUeIndex = (callId < maxCallNum ? callId : 0);

    for (uint8_t threadId = 0; threadId < maxCallThreadId; threadId++)
    {
        if (rPeriodicLbInfo.selectedUePerThread[threadId].numUe == 0) continue;

        FnVCCB_SendInternalTriggerPeriodicLbToCall(threadId);
    }
}

void FnVCCB_HandlePeriodicLbHo(message_type *ptAll, uint8_t threadId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptAll);
    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);

    VCCB_PRINT_SA_PERIODIC_LB("[PLB] %s threadId:%u \n", __func__, threadId);

    targetUeListInfo_type &selectedUePerThread = CFG->periodicLbInfo.selectedUePerThread[threadId];
    const uint32_t maxCellNum = MAX_CELL_NUM_VCCB;
    uint32_t numUe = MIN(selectedUePerThread.numUe, MAX_PERIODIC_LB_SELECTABLE_UE_PER_THREAD);

    for (uint32_t index = 0; index < numUe; index++)
    {
        uint32_t callId = selectedUePerThread.callId[index];

        // Get ptCi
        callInfo_type *ptCi = FnVCCB_GetCallInUse(callId);
        if (ptCi == NULL)
        {
            VCCB_PRINT_LOG_SA_LB(ptCi, "[PLB] %s callId:%d Not CI_use !! \n", __func__, callId);
            continue;
        }

        // Check myThreadId :: exceptional case
        if (ptCi->myThreadId != threadId)
        {
            VCCB_PRINT_LOG_SA_LB(ptCi, "[PLB] %s callId:%d ptCi->myThreadId:%d threadId:%d ERROR !! \n",
                __func__, callId, ptCi->myThreadId, threadId);
            continue;
        }

        // Range check :: ue served cell num
        if (ptCi->servCellNum >= maxCellNum)
        {
            VCCB_PRINT_LOG_SA_LB(
                ptCi, "[PLB] %s callId:%d wrong Cell:%d !! \n", __func__, callId, ptCi->servCellNum);
            continue;
        }

        if ((ptCi->stateCmd != Idle_cmd) || (ptCi->state != STATE_Conn))
        {
            VCCB_PRINT_LOG_SA_LB(ptCi, "[PLB] %s State of callinfo is wrong !! \n", __func__);
            continue;
        }


        ptCi->saLbHoExecuted = FALSE; // FGR-LC0703 (FR220) - triggered by periodic LB

        int16_t status = VCCM_TriggerMeasReconfig(ptCi);
        if (status != GOOD)
        {
            VCCB_PRINT_LOG_SA_LB(ptCi, "[PLB] %s VCCM_TriggerMeasReconfig Fail(%d) !! \n", __func__, status);
        }
        VCCB_PRINT_LOG_SA_LB(ptCi, "[PLB] %s VCCM_TriggerMeasReconfig SUCCESS !! \n", __func__);
    }
}


// }}}
