/**
 * @file        FeatAnr.cpp
 * @brief       This function provides a function for controlling the operation of the ANR Feature.
 */

#include "ComLibStatistic.h"
#include "FeatAnr.hpp"

#include "FeatCommon.h"
#include "FeatCallProc.h"
#include "FeatSon.h"
#include "FeatMeasurements.hpp"
#include "FeatNonNeighborHo.h"

#include "MsgOamSend.h"

#include "ComInclude.h"
#include "ComLibUtility.h"

// class AnrMRProc
// AnrMRProc::~AnrMRProc()
// {  // {{{
//     AUTO_TRACE_FUNC;

//     sendNewPciNotifyIfRequired();
// }  // }}}

void AnrMRProc::sendNewPciNotifyIfRequired()
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(_ptCi);
    VCCB_CHECK_VALID_CELLNUM_VOID(_ptCi->servCellNum);

    if (true == _sendNewPciNotifyAttemptFlag)
    {
        return;
    }

    _sendNewPciNotifyAttemptFlag = true;

    // SVR25A FGS-SF0502 FR230, FR240, FR740
    if (GOOD != CheckStrongestPci())
    {
        return;
    }

    // SVR25A FGS-SF0502 FR55
    if (GOOD != CheckAnrSchedule())
    {
        return;
    }

    if (GOOD != CheckAnrActivate())
    {
        return;
    }

    if (GOOD != CheckNewPci())
    {
        return;
    }

    if (true == IsAnrTargetSmallCell())
    {
        return;
    }

    VCCB_PRINT_LOG_ANR(_ptCi,
        "(ANR) mrType:%d pci:%d freq:%d reportType:%d m.s:%d mrIdx:%d pciType(mrdc):%d anrUnknownPciState:%d\n", _mrType,
        _anrPci, _anrFreq, _reportType, _mobilityState, _mrNbrIdx, _pciType, _anrUnknownPciState);

    if (true != sendNewPciNotify())
    {
        VCCB_PRINT_LOG_ANR(_ptCi,"(ANR) no send NewPciNotify\n");
    }
    return;
}

bool AnrMRProc::IsAnrTargetSmallCell()
{
    AUTO_TRACE_FUNC;
    if (nrType == getAnrRatType(_reportType))
    {
        if (FnVCCB_IsNrSmallCellPci(_ptCi, _anrPci, _smallCellListIndex))
        {
            VCCB_PRINT_CALL_INFORMATIVE(
                _ptCi, "[ANR:%s] Skip ANR: pci(%d) NR smallCellListIndex(%d)! freq(%d) \n", __func__, 
                _anrPci, _smallCellListIndex, _anrFreq);
            return true;
        }
    }
    else
    {
        if (FnVCCB_IsEutraSmallCellPci(_ptCi, _anrPci, _smallCellListIndex))
        {
            VCCB_PRINT_CALL_INFORMATIVE(
                _ptCi, "[ANR:%s] Skip ANR: pci(%d) EUTRA smallCellListIndex(%d)! freq(%d) \n", __func__, 
                _anrPci, _smallCellListIndex, _anrFreq);
            return true;
        }
    }
    return false;
}

int16_t AnrMRProc::CheckNewPci()
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(_ptCi);

    if (_anrUnknownPciState == ANR_NBR_UNKNOWN) // from CheckStrongestPci()
    {
        return GOOD;
    }

    return DecideUnknownPci(false);
}  // }}}

int16_t AnrMRProc::CheckStrongestPci()
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(_ptCi);

    // Check ANR Allow list
    if (false == IsAnrTargetReportTypeAndPurpose(_ptCi))
    {
        return ERROR;
    }

    return DecideUnknownPci(true);
}  // }}}

int16_t AnrMRProc::DecideUnknownPci(bool strongestPci)
{
    AUTO_TRACE_FUNC;

    uint16_t mrNbrIdx = (strongestPci ? 0 : 1);

    if (nrType == getAnrRatType(_reportType))
    {
        if (measReport_A4 == _reportType && a4Purpose_NrdcAddition == _reportPurpose)
        {
            return DecideNrdcUnknownPci(_ptCi, mrNbrIdx);
        }
        else
        {
            return DecideNrUnknownPci(_ptCi, mrNbrIdx);
        }
    }
    else
    {
        if (measReport_B1Eutra == _reportType && b1Purpose_NedcSnAddition == _reportPurpose)
        {
            return DecideNedcUnknownPci(_ptCi, mrNbrIdx);
        }
        else
        {
            return DecideEutraUnknownPci(_ptCi, mrNbrIdx);
        }
    }
}

bool AnrMRProc::ShouldCollectMrCount()
{
    VCCB_CHECK_E_RANGE_AND_RETURN(_ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pCell = &CELLINFO[_ptCi->servCellNum];
    if (nrType == getAnrRatType(_reportType))
    {
        return (IS_NR_MR_COUNT_COLLECT_CONDITION(pCell));
    }
    else
    {
        return (IS_IRAT_MR_COUNT_COLLECT_CONDITION(pCell));
    }
}

int16_t AnrMRProc::DecideNrdcUnknownPci(callInfo_type *ptCi, uint16_t startMrNbrIdx)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    uint16_t idx = 0, nbrIdx = 0, allowedNcrCnt = 0;
    uint32_t xnIdx = 0;
    uint32_t usedFreq = 0;
    uint8_t max_num_cell_report = MAX_NUM_CELL_REPORT;

    measResultList2NR_type *ptMeasResultList2NR =
        &THREAD_INFO->call[ptCi->myThreadId].buf.measResultList2NRRx.candidateCellInfoListSN;
    measResult2NR_type *ptMeasResult2NR = ptMeasResultList2NR->measResult2NR;
    measResultNR_type *ptMeasResultNR = NULL;

    _anrUnknownPciState = ANR_EMPTY_NBR_RESULT;
    _pciType = mrdcPciType_EMPTY;

    if (0 == ptMeasResultList2NR->nrofFreq)
    {
        return ERROR;
    }

    if (0 == ptMeasResult2NR[idx].measResultNeighCellListNR.nrofCellReport)
    {
        return ERROR;
    }

    max_num_cell_report = MIN(ptMeasResult2NR[idx].measResultNeighCellListNR.nrofCellReport, MAX_NUM_CELL_REPORT);

    if (IsCheckStrongestPci() || (IS_STRONGEST_PCI(startMrNbrIdx)))
    {
        max_num_cell_report = 1;
    }

    if (GOOD != VLIB_getArfcnFromMeasResult2NR(&ptMeasResult2NR[idx], _rsType, &usedFreq))
    {
        return ERROR;
    }
    _anrFreq = usedFreq;

    for (_mrNbrIdx = startMrNbrIdx; _mrNbrIdx < max_num_cell_report; _mrNbrIdx++)
    {
        ptMeasResultNR = &ptMeasResult2NR[idx].measResultNeighCellListNR.measResultNR[_mrNbrIdx];

        if (FALSE == ptMeasResultNR->physCellIdFlag)
        {
            return ERROR;
        }

        _anrPci = ptMeasResultNR->physCellId;
        _anrUnknownPciState = ANR_NBR_UNKNOWN;
        bool smallCellPci = FnVCCB_IsNrSmallCellPci(ptCi, _anrPci, _smallCellListIndex); // INTRA_NR_ANR_24A

        VCCB_PRINT_CALL_COMMENT(ptCi, "mrNbrIdx(%d) pci(%d) ssbFreq(%d) smallCellPci(%d:%d) In MR!\n", 
                _mrNbrIdx, _anrPci, _anrFreq, smallCellPci, _smallCellListIndex);

        bool needToCollectMrCount{};
        for (nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)  // go through all the neighbors
        {
            xnIdx = MAX_XN_NBR_PER_GNB;

            if (N_EQUIP == pCell->Nbr[nbrIdx].status)
            {
                continue;
            }

            nbrGnbCellInfo_type *ptNbrGnbCell;

            if (GOOD != getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &ptNbrGnbCell))
            {
                continue;
            }
            if (GOOD != VCCM_ComparePcisAndFreqsOfNbrCell(ptMeasResultNR, _anrFreq, _rsType, ptNbrGnbCell))
            {
                continue;
            }

            _anrUnknownPciState = ANR_NBR_KNOWN;

            if (IS_STRONGEST_PCI(_mrNbrIdx) && (true != smallCellPci)) 
            {
                allowedNcrCnt++;
                FnVCCB_CheckAndSendInvalidNCR(ptCi, nbrIdx, nrType);

                setNeedToCollectMrCount(needToCollectMrCount);
                if (needToCollectMrCount)
                {
                    AccumulateMrCount(nbrIdx);
                }
            }

            xnIdx = fnVLIB_FindXnEndPointIndexByNbrIdx(ptCi, ptCi->servCellNum, nbrIdx, NULL);
            if ((xnIdx >= MAX_XN_NBR_PER_GNB) && (VCCB_IS_INTER_GNB_NEIGHBOR(ptCi->servCellNum, nbrIdx)))
            {
                _pciType = mrdcPciType_A;
            }
        }

        if (IS_STRONGEST_PCI(_mrNbrIdx) && (true != smallCellPci)) 
        {
            bool knownFlag = (_anrUnknownPciState == ANR_NBR_UNKNOWN) ? false : true;
            if (_reportType == measReport_A4 && _reportPurpose == a4Purpose_NrdcAddition)
            {
                VLIB_StatUnKnownPciCount(
                        ptCi, _anrPci, knownFlag, _anrFreq, NRMeas_NRDC_Addition, _smallCellListIndex, allowedNcrCnt);
            }
        }

        // Known PCI && Inter-gNB NCR && Not configured gNB in endPointXn
        if (_pciType == mrdcPciType_A)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "mrNbrIdx : %d mrdcPciType_A\n", _mrNbrIdx);
            return GOOD;
        }

        // Unknown PCI
        if (ANR_NBR_UNKNOWN == _anrUnknownPciState)
        {
            _pciType = mrdcPciType_B;
            VCCB_PRINT_CALL_COMMENT(ptCi, "mrNbrIdx : %d mrdcPciType_B\n", _mrNbrIdx);
            return GOOD;
        }
    }

    return GOOD;
}  // }}}

int16_t AnrMRProc::DecideNedcUnknownPci(callInfo_type *ptCi, uint16_t startMrNbrIdx)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    uint8_t max_num_cell_report = MAX_NUM_CELL_REPORT;
    uint16_t nbrIdx = 0;
    uint16_t xnIdx = 0;
    enbId_type enbId;

    measResultNeighCellsEUTRA_type *ptMeasResultList2EUTRA =
        &THREAD_INFO->call[ptCi->myThreadId].buf.measResultListEutraRx;
    _anrFreq = ptMeasResultList2EUTRA->earfcnDl;
    _anrUnknownPciState = ANR_EMPTY_NBR_RESULT;
    _pciType = mrdcPciType_EMPTY;

    if (0 == ptMeasResultList2EUTRA->numReportCell)
    {
        return ERROR;
    }

    max_num_cell_report = MIN(ptMeasResultList2EUTRA->numReportCell, MAX_NUM_CELL_REPORT);

    if (IsCheckStrongestPci() || (IS_STRONGEST_PCI(startMrNbrIdx)))
    {
        max_num_cell_report = 1;
    }

    for (_mrNbrIdx = startMrNbrIdx; _mrNbrIdx < max_num_cell_report; _mrNbrIdx++)
    {
        measResultEUTRA_type *ptMeasResultEUTRA = &ptMeasResultList2EUTRA->measResult[_mrNbrIdx];
        _anrPci = ptMeasResultEUTRA->pci;
        _anrUnknownPciState = ANR_NBR_UNKNOWN;

        VCCB_PRINT_CALL_COMMENT(ptCi, "mrNbrIdx(%d) pci(%d) earfcnDl(%d) In MR!\n", _mrNbrIdx, _anrPci, _anrFreq);

        bool needToCollectMrCount{};
        for (nbrIdx = 0; nbrIdx < MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL; nbrIdx++)  // go through all the neighbors
        {
            xnIdx = MAX_XN_NBR_PER_GNB;

            if (EQUIP != pCell->eutraNbr[nbrIdx].status)
            {
                continue;
            }

            nbrEnbCellInfo_type *pNbrEnbCell = NULL;

            if (GOOD != getNbrEnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &pNbrEnbCell))
            {
                continue;
            }
            if ((pNbrEnbCell->pci != _anrPci) || (pNbrEnbCell->earfcnDl != _anrFreq))
            {
                continue;
            }
            if (false == _mnsFlag && IS_STRONGEST_PCI(_mrNbrIdx))
            {
                /* If strongest pci is smallCell pci, then VCCB skip ANR operation. */
                if (FnVCCB_IsEutraSmallCellPci(ptCi, _anrPci, _smallCellListIndex))
                {
                    VCCB_PRINT_LOG_ANR(
                        ptCi, "(ANR) [DecideNedcUnknownPci] strongestPCI(%d) is LTE SmallCell! freq(%d) \n", _anrPci, _anrFreq);
                    return BREAK;
                }
                
                setNeedToCollectMrCount(needToCollectMrCount);
                if (needToCollectMrCount)
                {
                    AccumulateMrCount(nbrIdx);
                }
            }

            _anrUnknownPciState = ANR_NBR_KNOWN;

            enbId.id = pNbrEnbCell->enbId;
            enbId.idType = macro_ng_enb_id;
            xnIdx = fnVLIB_FindXnEndPointIndexByEnbId(ptCi->gnbNum, &enbId, &pNbrEnbCell->plmn);
            if ((xnIdx >= MAX_XN_NBR_PER_GNB) && (FALSE != pNbrEnbCell->nedc_support))
            {
                _pciType = mrdcPciType_A;
                VCCB_PRINT_CALL_COMMENT(ptCi, "mrNbrIdx : %d mrdcPciType_A\n", _mrNbrIdx);
                return GOOD;
            }
        }

        if (_anrUnknownPciState == ANR_NBR_UNKNOWN)
        {
            _pciType = mrdcPciType_B;
            VCCB_PRINT_CALL_COMMENT(ptCi, "mrNbrIdx : %d mrdcPciType_B\n", _mrNbrIdx);
            return GOOD;
        }
    }
    return GOOD;
}  // }}}

int16_t AnrMRProc::DecideEutraUnknownPci(callInfo_type *ptCi, uint16_t startMrNbrIdx)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    uint8_t max_num_cell_report = 0;
    uint16_t nbrIdx = 0, allowedNcrCnt = 0;
    measResultNeighCellsEUTRA_type *ptMeasResultList2EUTRA =
        &THREAD_INFO->call[ptCi->myThreadId].buf.measResultListEutraRx;
    uint8_t hoAllowedFlag = VCCB_FLAG_OFF;

    if (0 == ptMeasResultList2EUTRA->numReportCell)
    {
        return ERROR;
    }

    max_num_cell_report = MIN(ptMeasResultList2EUTRA->numReportCell, MAX_NUM_CELL_REPORT);

    if (IsCheckStrongestPci() || (IS_STRONGEST_PCI(startMrNbrIdx)))
    {
        max_num_cell_report = 1;
    }

    _anrFreq = ptMeasResultList2EUTRA->earfcnDl;
    _anrUnknownPciState = ANR_EMPTY_NBR_RESULT;

    for (_mrNbrIdx = startMrNbrIdx; _mrNbrIdx < max_num_cell_report; _mrNbrIdx++)
    {
        measResultEUTRA_type *ptMeasResultEUTRA = &ptMeasResultList2EUTRA->measResult[_mrNbrIdx];
        _anrPci = ptMeasResultEUTRA->pci;
        _anrUnknownPciState = ANR_NBR_UNKNOWN;

        VCCB_PRINT_CALL_COMMENT(ptCi, "mrNbrIdx(%d) pci(%d) earfcnDl(%d) In MR!\n", _mrNbrIdx, _anrPci, _anrFreq);

        if ((true == _mnsFlag) && (false == FnVCCB_checkIratAnrMnsThreshold_withMeasResult(ptCi, ptMeasResultEUTRA)))
        {
            return ERROR;
        }

        // [23B] if strongest pci is smallCell pci, then VCCB skip ANR operation and doesn't collect MR COUNT stats.
        if ((IS_STRONGEST_PCI(_mrNbrIdx)) && (FnVCCB_IsEutraSmallCellPci(ptCi, _anrPci, _smallCellListIndex)))
        {
            VCCB_PRINT_LOG_ANR(
                ptCi, "(ANR) [DecideEutraUnknownPci] strongestPCI(%d) is LTE SmallCell! freq(%u)\n", _anrPci, _anrFreq);
            return ERROR;
        }

        bool needToCollectMrCount{};
        for (nbrIdx = 0; nbrIdx < MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL; nbrIdx++)  // go through all the neighbors
        {
            if (N_EQUIP == pCell->eutraNbr[nbrIdx].status)
            {
                continue;
            }

            nbrEnbCellInfo_type *ptNbrEnbCell = NULL;

            if (GOOD != getNbrEnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &ptNbrEnbCell))
            {
                continue;
            }
            if ((ptNbrEnbCell->pci != _anrPci) || (ptNbrEnbCell->earfcnDl != _anrFreq))
            {
                continue;
            }

            _anrUnknownPciState = ANR_NBR_KNOWN;

            if (IS_STRONGEST_PCI(_mrNbrIdx))
            {
                // Collects statistics if it is not a FnVCCB_IsEutraSmallCellPci.
                setNeedToCollectMrCount(needToCollectMrCount);
                if (false == _mnsFlag && needToCollectMrCount)
                {
                    AccumulateMrCount(nbrIdx);
                }

                if (TRUE == pCell->eutraNbr[nbrIdx].isHoAllowed)
                {
                    hoAllowedFlag = VCCB_FLAG_ON;
                    allowedNcrCnt++; // FGS-SF0503 FR501
                }
            }
        }

        if (IS_STRONGEST_PCI(_mrNbrIdx))
        {
            BOOL knownFlag =
                (ANR_NBR_UNKNOWN == _anrUnknownPciState) ? False : True;  // check ANR_EMPTY_NBR_RESULT -> pass
            if (VCCB_IS_VALID_IRAT_HANDOVER_PURPOSE_FOR_ANR(_reportType, _reportPurpose))  // EUTRA HANDOVER
            {
                VLIB_StatEutraUnKnownPciCount(ptCi, _anrPci, knownFlag, _anrFreq, hoAllowedFlag, _smallCellListIndex, allowedNcrCnt);
            }

            if(knownFlag == False) return GOOD;
        }
    }

    return GOOD;
}  // }}}

int16_t AnrMRProc::DecideNrUnknownPci(callInfo_type *ptCi, uint16_t startMrNbrIdx)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    uint8_t idx = 0, servIdx = MAX_FREQ_NUM, max_num_cell_report = 0;
    uint16_t nbrIdx = 0, allowedNcrCnt = 0; // 25B
    uint32_t usedFreq = 0;

    measResultList2NR_type *ptMeasResultList2NR =
        &THREAD_INFO->call[ptCi->myThreadId].buf.measResultList2NRRx.candidateCellInfoListSN;
    measResult2NR_type *ptMeasResult2NR = ptMeasResultList2NR->measResult2NR;
    measResultNR_type *ptServMeasResultNR = NULL;  // ServingCell
    measResultNR_type *ptMeasResultNR = NULL;

    if ((0 == ptMeasResultList2NR->nrofFreq) || 
            (0 == ptMeasResult2NR[idx].measResultNeighCellListNR.nrofCellReport))
    {
        return ERROR;
    }

    max_num_cell_report = MIN(ptMeasResult2NR[idx].measResultNeighCellListNR.nrofCellReport, MAX_NUM_CELL_REPORT);

    if (IsCheckStrongestPci() || (IS_STRONGEST_PCI(startMrNbrIdx)))
    {
        max_num_cell_report = 1;
    }

    if (GOOD != VLIB_getArfcnFromMeasResult2NR(&ptMeasResult2NR[idx], _rsType, &usedFreq))
    {
        return ERROR;
    }
    _anrFreq = usedFreq;
    _anrUnknownPciState = ANR_EMPTY_NBR_RESULT;

    if (true == _mnsFlag)
    {
        if (GOOD != FnVCCB_getServingCellFromMeasResultList2NR(ptCi, ptMeasResultList2NR, &servIdx))
        {
            VCCB_PRINT_LOG_ANR(ptCi, "(ANR) not found measResultServingCell (servIdx:%d)\n", servIdx);
            return ERROR;
        }

        VCCB_CHECK_E_RANGE_AND_RETURN(servIdx, MAX_NUM_FREQ);
        ptServMeasResultNR = &ptMeasResult2NR[servIdx].measResultServingCell;
    }

    for (_mrNbrIdx = startMrNbrIdx; _mrNbrIdx < max_num_cell_report; _mrNbrIdx++)
    {
        ptMeasResultNR = &ptMeasResult2NR[idx].measResultNeighCellListNR.measResultNR[_mrNbrIdx];

        if (FALSE == ptMeasResultNR->physCellIdFlag)
        {
            return ERROR;
        }

        if ((true == _mnsFlag) &&
            (false == FnVCCB_checkAnrMnsThreshold_withMeasResult(ptCi, _anrFreq, ptServMeasResultNR, ptMeasResultNR)))
        {
            return ERROR;
        }

        _anrPci = ptMeasResultNR->physCellId;
        _anrUnknownPciState = ANR_NBR_UNKNOWN;

        VCCB_PRINT_CALL_COMMENT(ptCi, "(ANR) mrNbrIdx(%d) pci(%d) ssbFreq(%d) In MR!\n", _mrNbrIdx, _anrPci, _anrFreq);

        // INTRA_NR_ANR_24A - If the strongest PCI is NR Small Cell PCI, 
        // Skip ANR operation and doesn't collect MR COUNT stats and doesn't send invalid NCR
        if (IS_STRONGEST_PCI(_mrNbrIdx) && (FnVCCB_IsNrSmallCellPci(ptCi, _anrPci, _smallCellListIndex))) 
        {
            VCCB_PRINT_CALL_INFORMATIVE(
                    ptCi, "[ANR:%s] Skip ANR: strongestPCI(%d) smallCellListIndex(%d)! freq(%u) \n", __func__, 
                    _anrPci, _smallCellListIndex, _anrFreq);
            return ERROR;
        }

        bool needToCollectMrCount{};
        for (nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)  // go through all the neighbors
        {
            if (N_EQUIP == pCell->Nbr[nbrIdx].status)
            {
                continue;
            }

            nbrGnbCellInfo_type *ptNbrGnbCell;

            if (GOOD != getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &ptNbrGnbCell))
            {
                continue;
            }
            if (GOOD != VCCM_ComparePcisAndFreqsOfNbrCell(ptMeasResultNR, _anrFreq, _rsType, ptNbrGnbCell))
            {
                continue;
            }

            _anrUnknownPciState = ANR_NBR_KNOWN;

            if (IS_STRONGEST_PCI(_mrNbrIdx))
            {
                FnVCCB_CheckAndSendInvalidNCR(ptCi, nbrIdx, nrType);

                setNeedToCollectMrCount(needToCollectMrCount);
                if (false == _mnsFlag && needToCollectMrCount)
                {
                    AccumulateMrCount(nbrIdx);
                }

                if (VCCB_IS_VALID_INTRA_NR_HANDOVER_PURPOSE(_reportType, _reportPurpose))
                {
                    if (pCell->Nbr[nbrIdx].isHoAllowed) allowedNcrCnt++;
                }
                else if (VCCB_IS_VALID_PSCELL_CHANGE_PURPOSE(_reportType, _reportPurpose)) 
                {
                    allowedNcrCnt++;
                }
            }
        }

        if (IS_STRONGEST_PCI(_mrNbrIdx))
        {
            bool knownFlag =
                (ANR_NBR_UNKNOWN == _anrUnknownPciState) ? False : True;  // check ANR_EMPTY_NBR_RESULT -> pass
            if (VCCB_IS_VALID_INTRA_NR_HANDOVER_PURPOSE(_reportType, _reportPurpose))  // INTRA NR HANDOVER
            {
                VLIB_StatUnKnownPciCount(ptCi, _anrPci, knownFlag, _anrFreq, NRMeas_HO, _smallCellListIndex, allowedNcrCnt);
            }
            else if (VCCB_IS_VALID_PSCELL_CHANGE_PURPOSE(_reportType, _reportPurpose))  // NRDC PSCELL CHANGED
            {
                VLIB_StatUnKnownPciCount(ptCi, _anrPci, knownFlag, _anrFreq, NRMeas_NRDC_PSCell_Change, _smallCellListIndex, allowedNcrCnt);
            }
        }

        if (ANR_NBR_UNKNOWN == _anrUnknownPciState)
        {
            return GOOD;
        }
    }

    return GOOD;
}  // }}}

void AnrMRProc::FnVCCB_CheckAndSendInvalidNCR(callInfo_type *ptCi, uint16_t nbrIdx, enumAnrObjType ratType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(nbrIdx, MAX_NBR_PER_CELL);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];

    // 1) anr-switch && invalid-ncr-delete-switch ON // 25A FGS-SF0502 FR240
    if (IS_NR_INVALID_NCR_NOTIFY_CONDITION(pCell) != TRUE)
    {
        VCCB_PRINT_LOG_ANR(ptCi, "(ANR) %s: anrSwitch(%d) invalidNcrDeleteSwitch(%d) OFF\n",
                __func__, pCell->anrInfo.anrSwitch, pCell->anrInfo.invalidNcrDeleteSwitch);
        return;
    }

    // 2) NCR is Intra-gNB
    if (!VCCB_IS_INTRA_GNB_NEIGHBOR(ptCi->servCellNum, nbrIdx))
    {
        VCCB_PRINT_LOG_ANR(ptCi, "(ANR) Inter-gNB NCR(serv[%d] nbr[%d])\n", ptCi->servCellNum, nbrIdx);
        return;
    }

    // 3) NCR is out-of-service (no check VLIB_IsCellBarred in ANR)
    uint16_t tempTargetCellNum = MAX_CELL_NUM_VCCB;
    VCCB_GET_INTRA_GNB_NBR_CELLNUM(ptCi->servCellNum, nbrIdx, tempTargetCellNum);
    VCCB_CHECK_E_RANGE_AND_VOID(tempTargetCellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *ptTgtCell = &CELLINFO[tempTargetCellNum];

    if (EQUIP == ptTgtCell->pldState && CELL_INS == ptTgtCell->serviceState)
    {
        return;
    }

    // 4) out-of-service configuration in invalid-ncr-condition  // FGS-SF0502 FR243
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    if (pGnb->anrGnbInfo.invalidNcrCondition.outOfService != true)
    {
        return;
    }

    VCCB_PRINT_LOG_ANR(ptCi, "(ANR) NCR[%d] is Out-Of-Service (pldState:%d serviceState:%d)\n",
        tempTargetCellNum, ptTgtCell->pldState, ptTgtCell->serviceState);

    if (GOOD != VIIL_send_msgInvalidNcrNotifyVccbOsab(ptCi, nbrIdx, ratType))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "VIIL_send_msgInvalidNcrNotifyVccbOsab ERROR\n");
    }

    return;
}

bool AnrMRProc::CheckUeBasedCgiAvailability()
{  // {{{
    AUTO_TRACE_FUNC;

    sendNewPciNotifyIfRequired();

    return _ueBasedCgiAvailability;
}  // }}}

bool AnrMRProc::DecideUeBasedCgiAvailability()
{
    AUTO_TRACE_FUNC;

    if (_caMrFlag)
    {
        _mobilityState = VCCB_FLAG_OFF;
    }

    if (_mobilityState == VCCB_FLAG_ON)
    {
        _ueBasedCgiAvailability = false;
    }
    else
    {
        _ueBasedCgiAvailability =
            FnVCCB_IsSupportUeBasedReportCgiForAnr(_ptCi, getAnrRatType(_reportType), _anrPci, _anrFreq);
    }

    return _ueBasedCgiAvailability;
}

// AnrMobilityMRProc
bool AnrMobilityMRProc::sendNewPciNotify()
{  // {{{
    AUTO_TRACE_FUNC;
    // FGS-SF0502 FR91
    // mobilityState = off && unknownPci              => send: cgiAvailable = true
    // mobilityState = on  && unknownPci && mrIdx = 0 => send: cgiAvailable = false

    // FGS-SF0502 FR52 : In case of CA MR, only check about mrIdx=0
    // unknownPci && mrIdx = 0 => send: cgiAvailable = true
    // knownPci && mrIdx = 0   => return
    if (ANR_NBR_UNKNOWN != _anrUnknownPciState)
    {
        return false;
    }

    const uint8_t anrRatType =  getAnrRatType(_reportType);

    if (_caMrFlag)
    {
        if (!IS_STRONGEST_PCI(_mrNbrIdx))
        {
            return false;
        }

        if (ERROR == VIIL_send_msgNewPciNotifyVccbOsab(_ptCi, _mrType, DecideUeBasedCgiAvailability(),
                         _anrPci, _anrFreq, anrRatType, VCCB_FLAG_OFF))
        {
            VCCB_PRINT_CALL_ERROR(_ptCi, "VIIL_send_msgNewPciNotifyVccbOsab Error(CA)\n");
            return false;
        }

        return true;
    }

    if (!IS_STRONGEST_PCI(_mrNbrIdx) && VCCB_FLAG_ON == _mobilityState)
    {
        return false;
    }

    // 24B EPS Fallback case
    if ((measReport_B1Eutra == _reportType && (b1Purpose_saEpsFallbackHandover == _reportPurpose)) ||
        (measReport_B2Eutra == _reportType && (b2Purpose_saEpsFallbackHandover == _reportPurpose)))
    {
        _mrType = anrMrTypeEpsFallback;
        _needCgiRequestNoti = VCCB_FLAG_ON;
    }

    if (ERROR == VIIL_send_msgNewPciNotifyVccbOsab(_ptCi, _mrType, DecideUeBasedCgiAvailability(),
                     _anrPci, _anrFreq, anrRatType, _needCgiRequestNoti))
    {
        VCCB_PRINT_CALL_ERROR(_ptCi, "VIIL_send_msgNewPciNotifyVccbOsab Error(MOB)\n");
        return false;
    }

    return true;
}  // }}}

int16_t AnrMobilityMRProc::CheckAnrActivate()
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(_ptCi);
    VCCB_CHECK_VALID_CELLNUM_ERROR(_ptCi->servCellNum);

    VccbCellInfo_type *pCell = &CELLINFO[_ptCi->servCellNum];

    if (nrType == getAnrRatType(_reportType))
    {  // PSCellChange for EN-DC or NR-DC/IntraNrHandover/ScellAddition or Change(anrMrTypeMobility)
        if (OFF == pCell->anrInfo.anrSwitch)
        {
            VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) MOB-anrSwitch:%d\n", pCell->anrInfo.anrSwitch);
            return ERROR;
        }

        if (measReport_A2 == _reportType && a2Purpose_scellRelease == _reportPurpose)
        {
            VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) MOB-Not supported purpose\n");
            return ERROR;
        }

        // ScellAddition or Change (CA)
        if ((measReport_A4 == _reportType && a4Purpose_scellAddition == _reportPurpose) ||
            (measReport_A6 == _reportType && a6Purpose_sCellChange == _reportPurpose))
        {
            _caMrFlag = true;
            if (OFF == pCell->anrInfo.caMrSwitch)
            {
                VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) MOB-caMrSwitch:%d\n", pCell->anrInfo.caMrSwitch);
                return ERROR;
            }
            return GOOD;
        }

        // PSCellChange for EN-DC or NR-DC/IntraNrHandover
        if (OFF == pCell->anrInfo.mobilityMrSwitch)
        {
            VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) MOB-mobilityMrSwitch:%d\n", pCell->anrInfo.mobilityMrSwitch);
            return ERROR;
        }
    }
    else
    {  // InterRatHandover(anrMrTypeMobility)
        if (OFF == pCell->irat_anrInfo.anrSwitch)
        {
            VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) MOB-IratAnrSwitch:%d\n", pCell->irat_anrInfo.anrSwitch);
            return ERROR;
        }

        // [24B] EPS Fallback
        if ((measReport_B1Eutra == _reportType && (b1Purpose_saEpsFallbackHandover == _reportPurpose)) ||
            (measReport_B2Eutra == _reportType && (b2Purpose_saEpsFallbackHandover == _reportPurpose)))
        {
            if (OFF == pCell->irat_anrInfo.epsFallbackMrSwitch)
            {
                VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) MOB-epsFallbackMrSwitch:%d\n", pCell->irat_anrInfo.epsFallbackMrSwitch);
                return ERROR;
            }
            return GOOD;
        }

        if (OFF == pCell->irat_anrInfo.eutraMobilityMrSwitch)
        {
            VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) MOB-eutraMobilityMrSwitch:%d\n", pCell->irat_anrInfo.eutraMobilityMrSwitch);
            return ERROR;
        }
    }

    return GOOD;
}  // }}}

// AnrNrdcMRProc
bool AnrNrdcMRProc::sendNewPciNotify()
{  // {{{
    AUTO_TRACE_FUNC;

    // FGS-SF0503 FR101, FGS-SF0502 FR51
    // mobilityState = off && (pciTypeA||pciTypeB)    => send: cgiAvailable = (pciTypeA ? false:true)
    // mobilityState = on  && pciTypeB && mrIdx = 0   => send: cgiAvailable = false
    if (mrdcPciType_EMPTY == _pciType) return false;

    if (VCCB_FLAG_ON == _mobilityState)
    {
        if (!IS_STRONGEST_PCI(_mrNbrIdx)) return false;
    }
    else  // (VCCB_FLAG_OFF == _mobilityState)
    {
        if (mrdcPciType_A == _pciType) _mobilityState = VCCB_FLAG_ON;
    }

    if (ERROR == VIIL_send_msgNewPciNotifyVccbOsab(_ptCi, _mrType, DecideUeBasedCgiAvailability(),
                     _anrPci, _anrFreq, getAnrRatType(_reportType), VCCB_FLAG_OFF))
    {
        VCCB_PRINT_CALL_ERROR(_ptCi, "VIIL_send_msgNewPciNotifyVccbOsab Error(NRDC)\n");
        return false;
    }

    return true;
}  // }}}

int16_t AnrNrdcMRProc::CheckAnrActivate()
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(_ptCi);
    VCCB_CHECK_VALID_CELLNUM_ERROR(_ptCi->servCellNum);

    VccbCellInfo_type *pCell = &CELLINFO[_ptCi->servCellNum];

    // NrdcAddition(anrMrTypeNrdc)
    if (OFF == pCell->anrInfo.anrSwitch)
    {
        VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) NRDC-anrSwitch:%d\n", pCell->anrInfo.anrSwitch);
        return ERROR;
    }
    if (OFF == pCell->anrInfo.nrdcAdditionMrSwitch)
    {
        VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) NRDC-nrdcAdditionMrSwitch:%d\n", pCell->anrInfo.nrdcAdditionMrSwitch);
        return ERROR;
    }

    return GOOD;
}  // }}}

// AnrNedcMRProc
bool AnrNedcMRProc::sendNewPciNotify()
{  // {{{
    AUTO_TRACE_FUNC;

    // FGS-SF0503 FR71, FGS-SF0502 FR101
    // mobilityState = off && (pciTypeA||pciTypeB)    => send: cgiAvailable = (pciTypeA ? false:true)
    // mobilityState = on  && pciTypeB && mrIdx = 0   => send: cgiAvailable = false
    if (mrdcPciType_EMPTY == _pciType) return false;

    if (VCCB_FLAG_ON == _mobilityState)
    {
        if (!IS_STRONGEST_PCI(_mrNbrIdx)) return false;
    }
    else  // (VCCB_FLAG_OFF == _mobilityState)
    {
        if (mrdcPciType_A == _pciType) _mobilityState = VCCB_FLAG_ON;
    }

    if (ERROR == VIIL_send_msgNewPciNotifyVccbOsab(_ptCi, _mrType, DecideUeBasedCgiAvailability(),
                     _anrPci, _anrFreq, getAnrRatType(_reportType), VCCB_FLAG_OFF))
    {
        VCCB_PRINT_CALL_ERROR(_ptCi, "VIIL_send_msgNewPciNotifyVccbOsab Error(NEDC)\n");
        return false;
    }

    return true;
}  // }}}

int16_t AnrNedcMRProc::CheckAnrActivate()
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(_ptCi);
    VCCB_CHECK_VALID_CELLNUM_ERROR(_ptCi->servCellNum);

    VccbCellInfo_type *pCell = &CELLINFO[_ptCi->servCellNum];

    // NedcSNodeAddition(anrMrTypeNedc)
    if (OFF == pCell->irat_anrInfo.anrSwitch)
    {
        VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) NEDC-IratAnrSwitch:%d\n", pCell->irat_anrInfo.anrSwitch);
        return ERROR;
    }
    if (OFF == pCell->irat_anrInfo.nedcAdditionMrSwitch)
    {
        VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) NEDC-nedcAdditionMrSwitch:%d\n", pCell->irat_anrInfo.nedcAdditionMrSwitch);
        return ERROR;
    }

    return GOOD;
}  // }}}

// SVR25A FGS-SF0502 FR55
int16_t AnrMRProc::CheckAnrSchedule()
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(_ptCi);
    VCCB_CHECK_VALID_CELLNUM_ERROR(_ptCi->servCellNum);

    if (false == IsCheckAnrScheduleCondition())
        return GOOD;

    // Check NCR addition based on ANR schedule
    if (false == VCCM_CheckAnrMnsSchedule(_ptCi))
    {
        VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) [%s] Not MNS schedule time. mrType(%d)\n", __func__, _mrType);
        return ERROR;
    }
    return GOOD;
}

// AnrMnsMRProc
bool AnrMnsMRProc::sendNewPciNotify()
{  // {{{
    AUTO_TRACE_FUNC;

    if (ERROR == VIIL_send_msgNewPciNotifyVccbOsab(_ptCi, _mrType, DecideUeBasedCgiAvailability(),
                     _anrPci, _anrFreq, getAnrRatType(_reportType), VCCB_FLAG_OFF))
    {
        VCCB_PRINT_CALL_ERROR(_ptCi, "VIIL_send_msgNewPciNotifyVccbOsab Error(MNS)\n");
        return false;
    }

    return true;
}  // }}}

int16_t AnrMnsMRProc::CheckAnrActivate()
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(_ptCi);
    VCCB_CHECK_VALID_CELLNUM_ERROR(_ptCi->servCellNum);

    VccbCellInfo_type *pCell = &CELLINFO[_ptCi->servCellNum];

    if (false == _mnsFlag)
    {
        VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) MNS-mnsFlag:%d\n", _mnsFlag);
        return ERROR;
    }

    // UEMeasForSON(anrMrTypeMns)
    if (nrType == getAnrRatType(_reportType))
    {  // Intra-NR MNS
        if (OFF == pCell->anrInfo.anrSwitch)
        {
            VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) MNS-anrSwitch:%d\n", pCell->anrInfo.anrSwitch);
            return ERROR;
        }
        if (OFF == pCell->anrInfo.mnsSwitch)
        {
            VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) MNS-mnsSwitch:%d\n", pCell->anrInfo.mnsSwitch);
            return ERROR;
        }
        if (MEAS_TH_DISABLE == pCell->measColocInfo.measThresholdTypeAnr)
        {
            VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) MNS-measThTypeAnr:%d\n", pCell->measColocInfo.measThresholdTypeAnr);
            return ERROR;
        }
    }
    else
    {  // Inter-RAT MNS
        if (OFF == pCell->irat_anrInfo.anrSwitch)
        {
            VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) MNS-IratAnrSwitch:%d\n", pCell->irat_anrInfo.anrSwitch);
            return ERROR;
        }
        if (MEAS_TH_DISABLE == pCell->measColocInfo.measThresholdTypeIratAnr)
        {
            VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) MNS-measThTypeIratAnr:%d\n", pCell->measColocInfo.measThresholdTypeIratAnr);
            return ERROR;
        }
    }

    return GOOD;
}  // }}}

bool AnrMRProc::IsAnrTargetReportTypeAndPurpose(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    VCCB_PRINT_LOG_ANR(_ptCi, "(ANR) IsAnrTargetReportTypeAndPurpose: reportType(%d), reportPurpose(%d) \n", _reportType, _reportPurpose);

    if (measReport_A3 == _reportType)
    {
        switch (_reportPurpose)
        {
            case a3Purpose_NRPSCellChange:      // A3 en-dc-nr-pscell-change-purpose
            case a3Purpose_intraNrHandover:     // A3 intra-nr-handover-purpose
            case a3Purpose_nrdcNrPSCellChange:  // A3 nr-dc-nr-pscell-change-purpose
                return true;
            default:
                break;
        }
    }
    else if (measReport_A4 == _reportType)
    {
        switch (_reportPurpose)
        {
            case a4Purpose_NRPSCellChange:      // A4 en-dc-nr-pscell-change-purpose
            case a4Purpose_FreqPrioPSCellChange:// A4 en-dc-fp-inter-frequency-nr-pscell-change-purpose [25B] FGS-SF0502 FR56 
            case a4Purpose_intraNrHandover:     // A4 intra-nr-handover-purpose
            case a4Purpose_PcellPriorHandover:  // A4 pcell-freq-prioritization-handover-purpose
            case a4Purpose_nrdcNrPSCellChange:  // A4 nr-dc-nr-pscell-change-purpose
            case a4Purpose_NRLoadBalancing:     // A4 load-balancing-FR1-purpose
            case a4Purpose_NrdcAddition:        // A4 nr-dc-sn-addition-purpose
            case a4Purpose_scellAddition:       // A4 scell-addition-purpose
                return true;
            default:
                break;
        }
    }
    else if (measReport_A5 == _reportType)
    {
        switch (_reportPurpose)
        {
            case a5Purpose_NRPSCellChange:           // A5 en-dc-nr-pscell-change-purpose
            case a5Purpose_FreqPrioPSCellChange:     // A5 en-dc-fp-inter-frequency-nr-pscell-change-purpose [25B] FGS-SF0502 FR56 
            case a5Purpose_intraNrHandover:          // A5 intra-nr-handover-purpose
            case a5Purpose_intraNrRfspHandover:      // A5 intra-nr-rfsp-handover-purpose

            case a5Purpose_intraNrOnDemandHandover:  // A5 intra-nr-on-demand-handover-purpose
            case a5Purpose_nrdcRfspPSCellChange:     // A5 nr-dc-rfsp-pscell-change-purpose
            case a5Purpose_PcellPriorHandover:       // A5 pcell-freq-prioritization-handover-purpose
            case a5Purpose_NRLoadBalancing:          // A5 load-balancing-FR1-purpose

            case a5Purpose_nrdcNrPSCellChange:       // A5 nr-dc-nr-pscell-change-purpose
                return true;
            default:
                break;
        }
    }
    else if (measReport_A6 == _reportType)
    {
        switch (_reportPurpose)
        {
            case a6Purpose_sCellChange:  // A6 scell-change-purpose
                return true;
            default:
                break;
        }
    }
    else if (measReport_B1Eutra == _reportType)
    {
        switch (_reportPurpose)
        {
            case b1Purpose_eutraHandover:              // B1 eutra-handover-purpose
            case b1Purpose_eutraRfspHandover:          // B1 eutra-rfsp-handover-purpose
            case b1Purpose_trafficBasedHandover:       // B1 traffic-based-nr-eutra-handover
            case b1Purpose_loadBalancingIratHandover:  // B1 load-balancing-irat-handover-purpose
            case b1Purpose_NedcSnAddition:             // B1 nedc-sn-addition-purpose
            case b1Purpose_saEpsFallbackHandover:      // B1 eps-fallback-purpose (24B)
                return true;
            default:
                break;
        }
    }
    else if (measReport_B2Eutra == _reportType)
    {
        switch (_reportPurpose)
        {
            case b2Purpose_eutraHandover:              // B2 eutra-handover-purpose
            case b2Purpose_eutraOnDemandHandover:      // B2 eutra-on-demand-handover-purpose
            case b2Purpose_trafficBasedHandover:       // B2 traffic-based-nr-eutra-handover
            case b2Purpose_loadBalancingIratHandover:  // B2 load-balancing-irat-handover-purpose
            case b2Purpose_saEpsFallbackHandover:      // B2 eps-fallback-purpose (24B)
                return true;
            default:
                break;
        }
    }
    else if (measReport_periodical == _reportType)
    {
        switch (_reportPurpose)
        {
            case periodicalPurpose_ueMeasForSon:  // Periodical ue-meas-for-son-purpose
                return true;
            default:
                break;
        }
    }
    else if (measReport_periodicalInterRat == _reportType)
    {
        switch (_reportPurpose)
        {
            case periodicalInterRATPurpose_ueMeasForSon:  // InterRAT Periodical ue-meas-for-son-purpose
                return true;
            default:
                break;
        }
    }

    return false;
}

void AnrMRProc::AccumulateMrCount(uint16_t nbrIndex)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(_ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(_ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *pCell = &CELLINFO[_ptCi->servCellNum];
 
    if (TRUE == FOO.VF_IntraNrANR || TRUE == FOO.VF_InterRatAnrWithLte)
    {
        if (CFG->anrMrCountSendFlag == FALSE)
        {
            VCCB_CHECK_E_RANGE_AND_VOID(_ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
            if (nrType == getAnrRatType(_reportType))
            {
                VCCB_CHECK_E_RANGE_AND_VOID(nbrIndex, MAX_NBR_PER_CELL);
                pCell->Nbr[nbrIndex].mrCount[_ptCi->myThreadId]++;
            }
            else
            {
                VCCB_CHECK_E_RANGE_AND_VOID(nbrIndex, MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL);
                pCell->eutraNbr[nbrIndex].mrCount[_ptCi->myThreadId]++;
            }
        }
    }
}

void ReportCgiProcedure::FnVCCB_StartAnrReportCgiWithDRX()
{
    AUTO_TRACE_FUNC;

    if (ERROR == VFIL_sendF1_UeContextModificationRequest(&rCall, NULL))
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "VFIL_sendF1_UeContextModificationRequest ERROR\n");
        if (VCCB_FLAG_OFF == GET_REPORT_CGI_FLAG((&rCall)))
        {
            return;
        }
        // send msgNcgiFailure only when reportCgiFlag ON
        if (ERROR == VIIL_send_msgNcgiFailureVccbOsab(&rCall, notAvailable))  // changed cause
        {
            VCCB_PRINT_CALL_ERROR(&rCall, "VIIL_send_msgNcgiFailureVccbOsab ERROR(notAvailable)\n");
        }
        VIIL_InitReportCgi(&rCall);
        return;
    }
    if ((rCall.callType == E_CALLTYPE_SA && !IS_NRDC_SN(&rCall)) ||
        (rCall.srb3Idx < MAX_SRB_PER_CALL && GET_REPORT_CGI_FLAG((&rCall)) == VCCB_FLAG_OFF))
    {
        VLIB_SetCurStateAll(&rCall, STATE_Anr_F1Config);
    }
    else  // E_CALLTYPE_NSA
    {
        callInfo_type *ptCi = &rCall;
        SET_STATE_CMD(MeasAnrSpecificCntl_cmd);
        VLIB_SetCurStateAll(&rCall, STATE_Anr_MnSnCoordination);
    }
    VLIB_AttachTimer(&rCall.timer, &rCall, timF1_UeContextModification_id);
}
// this function should be called after setting reportCgiFlag and Drx
void ReportCgiProcedure::FnVCCB_StartAnrReportCgiWithoutDRX()
{
    AUTO_TRACE_FUNC;

    if (ERROR == VCCB_PrepareNewMeasConfig(&rCall))
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "VCCB_PrepareNewMeasConfig ERROR\n");
        VCCB_ClearNewMeasConfig(rCall, VCCB_FLAG_ON);
        return;
    }
    if (E_CALLTYPE_NSA == rCall.callType)
    {
        callInfo_type *ptCi = &rCall;
        SET_STATE_CMD(MeasAnrSpecificCntl_cmd);
        rCall.cause.x2Cause = CauseX2apMiscUnspecified;
        if (GOOD != VXIL_sendX2_SgNBModificationRequired(&rCall))
        {
            SET_STATE_CMD(Idle_cmd);
            VCCB_PRINT_CALL_ERROR(&rCall, "VXIL_sendX2_SgNBModificationRequired ERROR\n");
            return;
        }
        VLIB_AttachTimer(&rCall.timer, &rCall, timX2_DcOverall_id);
        VLIB_SetCurStateAll(&rCall, STATE_Anr_MnSnCoordination);
    }
    else if (IS_NRDC_SN(&rCall))
    {
        // some IE need to be sent only for ANR request. stateCmd is used to indicate anr purpose
        callInfo_type *ptCi = &rCall;
        SET_STATE_CMD(MeasAnrSpecificCntl_cmd);
        rCall.cause.xnCause = CauseXnapMiscUnspecified;
        if (ERROR == FnVCCB_SendXNMessage(XN_SNodeModificationRequired_id, &rCall))
        {
            VCCB_PRINT_CALL_ERROR(&rCall, "FnVCCB_SendXNMessage(XN_SNodeModificationRequired_id) ERROR\n");
            return;
        }
        VLIB_AttachTimer(&rCall.callMultiTimer.xn, &rCall, timXN_DcOverall_id);
        VLIB_SetCurStateAll(&rCall, STATE_Anr_MnSnCoordination);
    }
    else
    {
        if (ERROR == VCCM_SendRRCReconfigSrbX(&rCall))
        {
            VCCB_PRINT_CALL_ERROR(&rCall, "VCCM_SendRRCReconfigSrbX ERROR\n");
            return;
        }
        VLIB_AttachTimer(&rCall.timer, &rCall, timNRRRC_RRCReconfig_id);
        VLIB_SetCurStateAll(&rCall, STATE_Anr_RrcConfig);
    }
}

shared_ptr<ReportCgiProcedure> FnVCCB_MakeRcHandler(callInfo_type &rCall, enumReportCgi_type type, message_type *ptAll)
{
    if (type == e_REPORT_CGI_HANDOVER) return make_shared<HandoverRcHandler>(rCall);

    return make_shared<AnrRcHandler>(rCall, ptAll);
}

void ReportCgiProcedure::commonProcedure(void)
{
    VCCB_PRINT_CALL_INFORMATIVE(((&rCall)),
        "[StartAnrReportCgi]  cId:(%u) ueS(%d) T(%s) Cgi(%d) Sn(%d) DuplPci(%d) non(%d)"
        " aGap(%d) drxS(%d) p(%u) f(%u) GBR(%u)\n",
        rCall.anrInfo.servCellId, rCall.state, getRcType() == e_REPORT_CGI_ANR ? "ANR" : "HO",
        GET_REPORT_CGI_FLAG((&rCall)), GET_REPORT_CGI_SN_FLAG((&rCall)), GET_REPORT_CGI_DUPL_PCI((&rCall)),
        GET_REPORT_CGI_NON_NEIGHBOR((&rCall)), GET_REPORT_CGI_AUTONOMOUS_GAP_FLAG((&rCall)),
        GET_REPORT_CGI_LONG_DRX_STATUS((&rCall)), rCall.anrInfo.pci, rCall.anrInfo.freq,
        rCall.anrInfo.anrGbrUe);
    if (FALSE == GET_REPORT_CGI_AUTONOMOUS_GAP_FLAG((&rCall)))
    {
        FnVCCB_StartAnrReportCgiWithDRX();
    }
    else
    {
        FnVCCB_StartAnrReportCgiWithoutDRX();
    }
}

int16_t AnrRcHandler::validate(enumAnrObjType _ratType)
{
    uint16_t ncgiReqPci;
    uint32_t ncgiReqfreq;
    (void)_ratType;
    if (nrType == ncgiReq->objType)
    {
        ncgiReqPci = ncgiReq->uReq.cgiReqNr.pci;
        ncgiReqfreq = ncgiReq->uReq.cgiReqNr.ssbFreq;
    }
    else
    {
        ncgiReqPci = ncgiReq->uReq.cgiReqEu.pci;
        ncgiReqfreq = ncgiReq->uReq.cgiReqEu.earfcnDl;
    }

    VCCB_PRINT_LOG_ANR((&rCall), "(ANR) freq:%d pci:%d mrType:%d ratType:%d rsType:%d\n", ncgiReqfreq, ncgiReqPci,
        ncgiReq->mrType, ncgiReq->objType,
        static_cast<int>(nrType == ncgiReq->objType ? ncgiReq->uReq.cgiReqNr.rsType : -1));

    // SVR24B FGS-SF0503 FR73
    if (TRUE == ncgiReq->cgiRequestUnavailable)
    {
        if ((STATE_Fallback_MeasReport == rCall.state) && (anrMrTypeEpsFallback == ncgiReq->mrType))
        {
            VCCB_PRINT_LOG_ANR((&rCall), "(ANR) EpsFallback but cgiRequestUnavailabe is TRUE \n");
            return ERROR;
        }

        // BREAK is considered an abnormal case because it is not EpsFallback scenario. So, operation isn't performed.
        VCCB_PRINT_LOG_ANR(&rCall, "(ANR) No EpsFallback(state:%d, mrType:%d) but cgiRequestUnavailabe is TRUE \n",
            rCall.state, ncgiReq->mrType);
        return BREAK;
    }

    if (false == FnVCCB_IsSupportUeBasedReportCgiForAnr(&rCall, ncgiReq->objType, ncgiReqPci, ncgiReqfreq))
    {
        VCCB_PRINT_LOG_ANR(&rCall, "(ANR) not support UEBasedReportCgi for cellNum(%d) ratType(%d)\n",
            rCall.servCellNum, ncgiReq->objType);
        return ERROR;
    }

    if (NULL == FnVCCB_FindMeasurementObjectUeFromInstalledItemsByReportCgiFreq(
                    &rCall, ncgiReqfreq, (ncgiReq->objType == nrType) ? measRatNr : measRatEutra))
    {
        VCCB_PRINT_LOG_ANR(&rCall, "(ANR) Uninstalled frequency(%u).\n", ncgiReqfreq);
        return ERROR;
    }

    return GOOD;
}

void FnVCCB_CgiReportAbnormalStat(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // FGS-SF0502/FGS-SF0503 26A - ANR purpose only, Not HO case
    // For example, handover happens and call released while reportCGI for ANR
    if (GET_REPORT_CGI_STAT_COLLECT_REQUIRED(ptCi))
    {
        if (ptCi->anrInfo.ratType == eutraType) // 26A PKG only handles the eutraType. nrType has to be added later TODO_TODO.
        {
            VCCB_PRINT_LOG_ANR(ptCi, "CGI_REPORT_RESULT_CANCEL while Call Release\n");
            VCCB_REPORT_CGI_STAT(ptCi, CGI_REPORT_RESULT_CANCEL, ptCi->saPrevInfo.reportCgi.autonomousGapsFlag); 
        }
    }
}
