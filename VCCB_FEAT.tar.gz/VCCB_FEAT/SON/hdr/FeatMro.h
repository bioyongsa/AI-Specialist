/**
 * @file        FeatMro.h
 * @brief       Utility functions for MRO
 */

#ifndef VCCB_FEAT_FeatMro_H_
#define VCCB_FEAT_FeatMro_H_

#include "VccbStruct.h"

int16_t FnVCCB_procMRO(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack);
void FnVCCB_UeBasedMRO_CoverageHole(callInfo_type *ptCi);
void FnVCCB_LibStatMroEvent(const char *pFuncName, const uint64_t lineNumber, const char *pStrFamily, int mFamily,
    const char *pStrMtype, int mType, callInfo_type *ptCi, const char *pStrSrcCgi, cgi_type *pSrcCgi,
    const char *pStrTgtCgi, cgi_type *pTgtCgi);
void FnVCCB_Convert_to_cgi_type(cgi_type *pDst, CGI_InfoEutraLogging_type *pEutraSrc, CGI_Info_Logging_type *pNRSrc);
int16_t FnVCCB_SendHandoverReport(callInfo_type *ptCi, uint8_t hoReportType);
void FnVCCB_IratMro_HOP(callInfo_type *ptCi);
uint16_t FnVCCB_GetXnIdxFromCgi(callInfo_type *ptCi, cgi_type *nbrCellCgi);

void FnVCCB_SetMroHandoverTriggerType(callInfo_type *ptCi);
void FnVCCB_UpdateMroHoInfoOnSourceGnb(callInfo_type *ptCi, uint16_t hoTypeRat, uint16_t hoTypeNb);
void FnVCCB_UpdateMroHoInfoOnTargetGnb(callInfo_type *ptCi, const cgi_type *ptCgi, bool isHandInCell);
void FnVCCB_UpdateRlfReportAvailableFlag(callInfo_type *ptCi, NRRRC_UE_MeasurementsAvailable_r16 *ptIE);

void FnVCCB_procMRO_MSG5(callInfo_type *ptCi);
void FnVCCB_procMRO_MSG5_noRlfInfo(callInfo_type *ptCi);
void FnVCCB_procMRO_NRRRC_RrcUEInformationResponse(callInfo_type *ptCi, msgUnpack_type *ptUnpack);
void FnVCCB_procMRO_FailureIndication(callInfo_type *ptCi);
void FnVCCB_procMRO_HoReport(callInfo_type *ptCi, uint8_t interface);

int16_t FnVCCB_PreProcess_UebasedMRO_byMSG5(callInfo_type *ptCi);
int16_t FnVCCB_PreProcess_UebasedMRO_byFailureInd(callInfo_type *ptCi);

void FnVCCB_UeBasedMRO_RLFReport(callInfo_type *ptCi);
int16_t FnVCCB_UeBasedMRO_HOP(callInfo_type *ptCi);
void FnVCCB_UeBasedMRO_HOP_HandoverReport(callInfo_type *ptCi, CGI_Info_Logging_type *recoveryCell, uint8_t interface);
int16_t FnVCCB_UeBasedMRO_HOP_HandoverReport_CheckCellCgi(callInfo_type *ptCi, uint8_t interface);

void FnVCCB_NWBasedMRO(callInfo_type *ptCi);
void FnVCCB_NWBasedMRO_MSG5(callInfo_type *ptCi);
void FnVCCB_NWBasedMRO_handoverFailure(callInfo_type *ptCi);
void FnVCCB_NWBasedMRO_otherFailure(callInfo_type *ptCi);
void FnVCCB_NWBasedMRO_FailureIndication(callInfo_type *ptCi);
void FnVCCB_NWBasedMRO_XN_HoReport(callInfo_type *ptCi);
void FnVCCB_procMRO_InterSystem_HoReport_UnnecessaryHoDetect(callInfo_type *ptCi);
void FnVCCB_procMRO_InterSystem_HoReport_InterSystemPingpong(callInfo_type *ptCi, uint8_t interface);

int16_t FnVCCB_SendFailureIndication(callInfo_type *ptCi);

int16_t FnVCCB_GetCGIWithPciArfcn(uint16_t cellNum, uint16_t pci, uint32_t arfcn, cgi_type *tgtCgi);

bool FnVCCB_MRO_CPD_IsValidMeasQuantityResult(callInfo_type *ptCi, NRRRC_MeasQuantityResults *ptIE);
bool FnVCCB_MRO_DoesPciArfcnBelongToNrFailedPCell(callInfo_type *ptCi, uint16_t pci, uint32_t arfcn);
int FnVCCB_MRO_CPD_DetermineCovProblemType(callInfo_type *ptCi, uint8_t connectionFailureType);
void fnVCCB_UeBasedMRO_CovergeProblemDetection(callInfo_type *ptCi);
int16_t FnVCCB_PrepareXNAP_FailureIndication(callInfo_type *ptCi);

/*
* @brief    Determines whether Inter-system Measurement Configuration IE should be configured.
*/
class ProcInterSystemMeasurementConfiguration // SVR23A FGS-SF0510:FR50
{
public:
    /*
    * @brief    Handle dequeued MR.
    * @param    _ptCi Pointer to callInfo_type structure.
    */
    ProcInterSystemMeasurementConfiguration(callInfo_type *ptCi) : _ptCi(ptCi)
    {
        _ptCi->mroInfo.interSystemMeasConfigFlag = false; //init

        SetReportConfigInfo();
    }

    ~ProcInterSystemMeasurementConfiguration() {
        _ptCi->mroInfo.interSystemMeasConfigFlag = false;
    };

    bool FnVCCB_IncludeInterSysMeasConfig(callInfo_type *ptCi, enumMeasurementReportType reportType, uint8_t reportPurpose);

protected:
    callInfo_type *_ptCi;
    
    void SetReportConfigInfo() 
    {
        enumMeasurementReportType _reportType = _ptCi->saHoMrQueueInfo.reportType;
        uint8_t _reportPurpose = _ptCi->saHoMrQueueInfo.reportPurpose;

        _ptCi->mroInfo.interSystemMeasConfigFlag = FnVCCB_IncludeInterSysMeasConfig(_ptCi, _reportType, _reportPurpose);
    }
};

#endif  // VCCB_FEAT_FeatMro_H_