/**
 * @file        FeatAnr.h
 * @brief       Utility functions for Handover
 */

#ifndef VCCB_FEAT_FeatAnr_H_
#define VCCB_FEAT_FeatAnr_H_

#include "VccbStruct.h"
#include "ComLibUtility.h"
#include "FeatSon.h"
#include "ComInclude.h"
#include "MsgF1apSend.h"
#include "MsgXnapSend.h"
#include "MsgX2apSend.h"
#include "MsgNrRrcSend.h"
#include "StateMeasGap.h"
#include "StateCommon.h"
#include "ComMacro.h"

class AnrMRProc
{
public:
    AnrMRProc(callInfo_type *ptCi, enumMeasurementReportType reportType, uint8_t reportPurpose, enumRSType rsType,
        enumAnrMrType mrType, bool mnsFlag, measurementObjectUe_type *pMeasObj) :
        _mobilityState(VCCB_FLAG_ON),
        _anrUnknownPciState(ANR_EMPTY_NBR_RESULT),
        _mrNbrIdx(0),
        _anrPci(0xFFFF),
        _anrFreq(0),
        _mnsFlag(mnsFlag),
        _pciType(mrdcPciType_EMPTY),
        _ptCi(ptCi),
        _rsType(rsType),
        _mrType(mrType),
        _reportType(reportType),
        _reportPurpose(reportPurpose),
        _sendNewPciNotifyAttemptFlag(false),
        _caMrFlag(false),
        _smallCellListIndex(-1),
        _needCgiRequestNoti(VCCB_FLAG_OFF),
        _ueBasedCgiAvailability(false),
        _mrCountCollectYangEnabled(ShouldCollectMrCount())
    {
        SetSmallCellListIndex(pMeasObj);
    }
    AnrMRProc(callInfo_type *ptCi, enumMeasurementReportType reportType, uint8_t reportPurpose, enumAnrMrType mrType) :
        _mobilityState(VCCB_FLAG_ON),
        _anrUnknownPciState(ANR_EMPTY_NBR_RESULT),
        _mrNbrIdx(0),
        _anrPci(0xFFFF),
        _anrFreq(0),
        _mnsFlag(false),
        _pciType(mrdcPciType_EMPTY),
        _ptCi(ptCi),
        _rsType(RSType_SSB),
        _mrType(mrType),
        _reportType(reportType),
        _reportPurpose(reportPurpose),
        _sendNewPciNotifyAttemptFlag(false),
        _caMrFlag(false),
        _smallCellListIndex(-1),
        _needCgiRequestNoti(VCCB_FLAG_OFF),
        _ueBasedCgiAvailability(false),
        _mrCountCollectYangEnabled(ShouldCollectMrCount())
    {
    }
    AnrMRProc(callInfo_type *ptCi, enumMeasurementReportType reportType, uint8_t reportPurpose, enumAnrMrType mrType,
        measurementObjectUe_type *pMeasObj) :
        _mobilityState(VCCB_FLAG_ON),
        _anrUnknownPciState(ANR_EMPTY_NBR_RESULT),
        _mrNbrIdx(0),
        _anrPci(0xFFFF),
        _anrFreq(0),
        _mnsFlag(false),
        _pciType(mrdcPciType_EMPTY),
        _ptCi(ptCi),
        _rsType(RSType_SSB),
        _mrType(mrType),
        _reportType(reportType),
        _reportPurpose(reportPurpose),
        _sendNewPciNotifyAttemptFlag(false),
        _caMrFlag(false),
        _smallCellListIndex(-1),
        _needCgiRequestNoti(VCCB_FLAG_OFF),
        _ueBasedCgiAvailability(false),
        _mrCountCollectYangEnabled(ShouldCollectMrCount())
    {
        SetSmallCellListIndex(pMeasObj);
    }

    virtual ~AnrMRProc(){};

    void setMobilityState(int _state)
    {
        _mobilityState = VCCB_FLAG_OFF;
        if (GOOD == _state) _mobilityState = VCCB_FLAG_ON;
    }

    void sendNewPciNotifyIfRequired();
    bool CheckUeBasedCgiAvailability();
    bool DecideUeBasedCgiAvailability();

    // FGR-SF0503 FR72 ANR can decide EUTRA Smallcell PCI 
    void setSmallCellListIndex(int8_t _index) { _smallCellListIndex = _index; }
    int8_t getSmallCellListIndex(void) { return _smallCellListIndex; }

protected:
    // SVR25A FGS-SF0502 FR55, SVR25A FGS-SF0503 FR75
    virtual bool IsCheckAnrScheduleCondition()
    {
        VccbCellInfo_type &rCell = CELLINFO[_ptCi->servCellNum];
        if (nrType == getAnrRatType(_reportType))
        {
            return (ON == rCell.anrInfo.ncrAddSchedUsageSwitch);
        }
        else
        {
            return (ON == rCell.irat_anrInfo.eutraNcrAddSchedUsageSwitch);
        }
    };
    int16_t CheckAnrSchedule(); // SVR25A FGS-SF0502 FR55
    virtual bool sendNewPciNotify() = 0;
    virtual int16_t CheckAnrActivate() = 0;
    int16_t CheckStrongestPci(); // SVR25A 
    int16_t CheckNewPci();
    int16_t DecideUnknownPci(bool strongestPci); 
    int16_t DecideNrUnknownPci(callInfo_type *, uint16_t);
    int16_t DecideEutraUnknownPci(callInfo_type *, uint16_t);
    int16_t DecideNedcUnknownPci(callInfo_type *, uint16_t);
    int16_t DecideNrdcUnknownPci(callInfo_type *, uint16_t);
    bool IsCheckStrongestPci()
    {
        if (true == _mnsFlag || true == _caMrFlag || VCCB_FLAG_ON == _mobilityState)
        {
            return true;
        }
        return false;
    }
    void FnVCCB_CheckAndSendInvalidNCR(callInfo_type *, uint16_t nbrIdx, enumAnrObjType ratType);
    uint8_t getAnrRatType(enumMeasurementReportType reportType)
    {
        return (measReport_reportCGI >= reportType ? nrType : eutraType);
    }
    bool IsAnrTargetReportTypeAndPurpose(callInfo_type *);
    bool IsAnrTargetSmallCell();
    void SetSmallCellListIndex(measurementObjectUe_type *pMeasObj) {
        const bool isEutra = (measRatEutra == pMeasObj->conf.ratType);
        _smallCellListIndex = isEutra ? pMeasObj->conf.rat.eutra.minimal.smallCellPciListIndex
                                      : pMeasObj->conf.rat.nr.minimal.smallCellPciListIndex;
    }

    int16_t _mobilityState;  //(VCCB_FLAG_ON: The UE is now in mobility procedure, VCCB_FLAG_OFF: The UE is not in
                             // mobility procedure.)
    uint16_t _anrUnknownPciState;
    uint16_t _mrNbrIdx;
    uint16_t _anrPci;
    uint32_t _anrFreq;
    bool _mnsFlag;
    int16_t _pciType;
    callInfo_type *_ptCi;
    enumRSType _rsType;
    enumAnrMrType _mrType;
    enumMeasurementReportType _reportType;
    uint8_t _reportPurpose;
    bool _sendNewPciNotifyAttemptFlag;
    bool _caMrFlag;
    int8_t _smallCellListIndex;   // FGR-SF0503 FR72 ANR can decide lte smallcell Pci.
    uint8_t _needCgiRequestNoti;  // 24B FGR-SF0503 FR73
    bool _ueBasedCgiAvailability;
    bool ShouldCollectMrCount();
    bool _mrCountCollectYangEnabled;
    void AccumulateMrCount(uint16_t nbrIndex);
    void setNeedToCollectMrCount(bool &val)
    {
        // already set skip
        if (val) return;
        if (not _mrCountCollectYangEnabled) return;
        if (FnVCCB_CheckAndUpdateMeasPciStat(
                _ptCi, _anrPci, _anrFreq, static_cast<enumAnrObjType>(getAnrRatType(_reportType)), false) == True)
        {
            val = true;
        }
    }
};

class AnrMobilityMRProc : public AnrMRProc
{
public:
    AnrMobilityMRProc(callInfo_type *ptCi, enumMeasurementReportType reportType, uint8_t reportPurpose,
        enumRSType rsType, bool mnsFlag, measurementObjectUe_type *pMeasObj) :
        AnrMRProc(ptCi, reportType, reportPurpose, rsType, anrMrTypeMobility, mnsFlag, pMeasObj)
    {
    }

    AnrMobilityMRProc(callInfo_type *ptCi, enumMeasurementReportType reportType, uint8_t reportPurpose) :
        AnrMRProc(ptCi, reportType, reportPurpose, anrMrTypeMobility)
    {
    }

    AnrMobilityMRProc(callInfo_type *ptCi, enumMeasurementReportType reportType, uint8_t reportPurpose,
        measurementObjectUe_type *pMeasObj) :
        AnrMRProc(ptCi, reportType, reportPurpose, anrMrTypeMobility, pMeasObj)
    {
    }

    ~AnrMobilityMRProc() { sendNewPciNotifyIfRequired(); };

    virtual bool sendNewPciNotify();
    virtual int16_t CheckAnrActivate();

private:
};

class AnrNrdcMRProc : public AnrMRProc
{
public:
    AnrNrdcMRProc(callInfo_type *ptCi, enumMeasurementReportType reportType, uint8_t reportPurpose) :
        AnrMRProc(ptCi, reportType, reportPurpose, anrMrTypeNrdc)
    {
    }
    AnrNrdcMRProc(callInfo_type *ptCi, enumMeasurementReportType reportType, uint8_t reportPurpose,
        measurementObjectUe_type *pMeasObj) :
        AnrMRProc(ptCi, reportType, reportPurpose, anrMrTypeNrdc, pMeasObj)
    {
    }

    ~AnrNrdcMRProc() { sendNewPciNotifyIfRequired(); };

    virtual bool sendNewPciNotify();
    virtual int16_t CheckAnrActivate();

private:
};

class AnrNedcMRProc : public AnrMRProc
{
public:
    AnrNedcMRProc(callInfo_type *ptCi, enumMeasurementReportType reportType, uint8_t reportPurpose) :
        AnrMRProc(ptCi, reportType, reportPurpose, anrMrTypeNedc)
    {
    }
    AnrNedcMRProc(callInfo_type *ptCi, enumMeasurementReportType reportType, uint8_t reportPurpose,
        measurementObjectUe_type *pMeasObj) :
        AnrMRProc(ptCi, reportType, reportPurpose, anrMrTypeNedc, pMeasObj)
    {
    }

    ~AnrNedcMRProc() { sendNewPciNotifyIfRequired(); };

    virtual bool sendNewPciNotify();
    virtual int16_t CheckAnrActivate();

private:
};

class AnrMnsMRProc : public AnrMRProc
{
public:
    AnrMnsMRProc(callInfo_type *ptCi, enumMeasurementReportType reportType, uint8_t reportPurpose, enumRSType rsType,
        bool mnsFlag, measurementObjectUe_type *pMeasObj) :
        AnrMRProc(ptCi, reportType, reportPurpose, rsType, anrMrTypeMns, mnsFlag, pMeasObj)
    {
    }

    ~AnrMnsMRProc() { sendNewPciNotifyIfRequired(); };

    virtual bool sendNewPciNotify();
    virtual int16_t CheckAnrActivate();

private:
    bool IsCheckAnrScheduleCondition() override {return true;} // SVR25A FGS-SF0502 FR55
};

typedef enum
{
    e_REPORT_CGI_ANR = 1U,
    e_REPORT_CGI_HANDOVER = 2U,
} enumReportCgi_type;

class ReportCgiProcedure
{
public:
    ReportCgiProcedure(enumReportCgi_type _type, callInfo_type &_rCall) : rCall(_rCall), rcType(_type) {}
    int16_t activate(enumAnrObjType _ratType, uint16_t _pci, uint32_t _freq, uint8_t _mrType, uint8_t _rsType)
    {
        auto retVal = validate(_ratType);
        if (retVal != GOOD) return retVal;

        setReportCgiUeParameter(_ratType, _pci, _freq, _mrType, _rsType);
        decideDrxParameter();
        commonProcedure();
        return GOOD;
    }
    void deactivate()
    {
        clearReportCgiDbForDeactivate();
        commonProcedure();
    }

    void decideDrxParameter(void)
    {
        rCall.anrInfo.anrGbrUe = (VIIL_AnrIsGBRUe(&rCall) ? true : false);  // INTRA_NR_ANR_24A for FR760
        SET_REPORT_CGI_AUTONOMOUS_GAP_FLAG((&(rCall)), (isAutonomousGapEnabled() ? 1 : 0));
        SET_REPORT_CGI_LONG_DRX_STATUS(&rCall, VCCB_FLAG_OFF);
        if (GET_REPORT_CGI_AUTONOMOUS_GAP_FLAG((&rCall))==FALSE)
        {
            updateLongDrx();
        }
    }

    enumReportCgi_type getRcType() { return rcType; }
    bool isSupportReportCgiForGbrUe(uint8_t gbrUeSwitch)
    {
        if (REPORT_CGI_GBR_SWITCH_TYPE_BOTH == gbrUeSwitch || REPORT_CGI_GBR_SWITCH_TYPE_AUTONOMOUS_GAP == gbrUeSwitch)
            return true;
        return false;
    }
    void setReportCgiUeParameter(
        enumAnrObjType _ratType, uint16_t _pci, uint32_t _freq, uint8_t _mrType, uint8_t _rsType)
    {
        rCall.anrInfo.reportCgi.clearFlag = 0;  // Init 26A

        setReportCgiFlag();
        rCall.anrInfo.ratType = static_cast<uint8_t>(_ratType);
        rCall.anrInfo.pci = _pci;
        rCall.anrInfo.freq = _freq;
        rCall.anrInfo.mrType = _mrType;
        rCall.anrInfo.rsType = _rsType;

        VccbCellInfo_type *pCell = &CELLINFO[rCall.servCellNum];
        rCall.anrInfo.servCellId = pCell->cellIdentity;
        setReportTypePurpose();
        setTriggerQuantity();
    }

protected:
    // Pure virtual functions for derived classes to implement
    virtual int16_t validate(enumAnrObjType _ratType) = 0;
    virtual bool isAutonomousGapEnabled() = 0;
    virtual void setReportCgiFlag() = 0;
    virtual void setReportTypePurpose()
    {
        // SVR25A FGR-MC1007 FR382
        rCall.anrInfo.reportType = 0xFF;
        rCall.anrInfo.reportPurpose = 0xFF;
    };
    virtual void setTriggerQuantity()
    {
        rCall.anrInfo.reportConfigQuantitySaHo = 0xFF;  
    };
    virtual uint8_t getGbrUeSwitch() = 0;
    callInfo_type &rCall;

private:
    enumReportCgi_type rcType;
    void clearReportCgiDbForDeactivate(void)
    {
        rCall.anrInfo.pci = 0;
        rCall.anrInfo.freq = 0;
        rCall.anrInfo.longDrxValue = 0;

        // reportCgiFlag indicating the current status of the report CGI and
        // initialize only the longDrxStatus, which is a variable that can determine that the anr long drx cycle value
        // must be transmitted to the f1ap modification request.

        // The remaining variables are initialized when the anr deactivation procedure is completed.
        SET_REPORT_CGI_FLAG(&rCall, VCCB_FLAG_OFF);
        SET_REPORT_CGI_LONG_DRX_STATUS((&rCall), VCCB_FLAG_OFF);
        SET_REPORT_CGI_STAT_COLLECT_REQUIRED((&rCall), VCCB_FLAG_OFF); // FGS-SF0502 FR760 26A
        VLIB_ConfigDrxCuInfo(&rCall);
    }
    void commonProcedure(void);
    void updateLongDrx(void)
    {
        SET_REPORT_CGI_LONG_DRX_STATUS((&rCall), VCCB_FLAG_ON);
        rCall.anrInfo.longDrxValue =
            FnVCCB_getAnrLongDrxCycle((&rCall), rCall.servCellNum, rCall.anrInfo.ratType, rCall.anrInfo.freq);
        VCCB_PRINT_LOG_ANR((&rCall), "set long drx value for reportCgi anrLongDrx(status:%u/%u), drxCuInfo:%d/%u)\n",
            GET_REPORT_CGI_LONG_DRX_STATUS((&rCall)), rCall.anrInfo.longDrxValue, rCall.drxCuInfo.status,
            rCall.drxCuInfo.longCycle);
    }
    void FnVCCB_StartAnrReportCgiWithDRX();
    void FnVCCB_StartAnrReportCgiWithoutDRX();
};
class HandoverRcHandler : public ReportCgiProcedure
{
public:
    HandoverRcHandler(callInfo_type &_rCi) : ReportCgiProcedure(e_REPORT_CGI_HANDOVER, _rCi) {}

protected:
    int16_t validate(enumAnrObjType _ratType) override
    {
        if (rCall.reportCgiHoInfo.usage == CI_no_use) return ERROR;

        if (rCall.saHoMrQueueInfo.mrBufferUpdateCnt != rCall.reportCgiHoInfo.mrBufferUpdateCnt) return ERROR;

        // during reportCGI, return ERROR
        if (FnVCCB_IsReportCgiRunning(&rCall) == true) return ERROR;

        if (FnVCCB_IsSupportUeBasedReportCgiForMobility(&rCall, static_cast<uint8_t>(_ratType)) == false) return ERROR;

        return GOOD;
    }
    void setReportCgiFlag() override
    {
        if (RCHO_Type_nonNeighborCell == rCall.saHoMrQueueInfo.reportCgiHandoverType)
        {
            VCCB_PRINT_CALL_NON_NBR_HO((&rCall), "Set anrInfo for reportCgiNonNeighbor HO !!\n");
            SET_REPORT_CGI_NON_NEIGHBOR((&rCall), VCCB_FLAG_ON);
        }
        else  // RCHO_Type_duplicatePci
        {
            SET_REPORT_CGI_DUPL_PCI((&rCall), VCCB_FLAG_ON);
        }
        SET_REPORT_CGI_FLAG((&rCall), VCCB_FLAG_ON);
    }
    uint8_t getGbrUeSwitch() override
    {
        const VccbGnbInfo_type *const pGnb = &GNBINFO[rCall.gnbNum];
        return (VCCB_IsEndcSn(rCall) ? pGnb->cfg.gnbMobilityConfig.ueBasedCgiReportingForEndcPscellChangeGbr
                                     : pGnb->cfg.gnbMobilityConfig.ueBasedCgiReportingForHandoverGbr);
    }
    bool isAutonomousGapEnabled() override
    {
        if (FALSE == FnVCCB_getUeAutonomousGaps((&(rCall)), rCall.servCellNum, rCall.anrInfo.ratType))
        {
            return false;
        }
        if (not rCall.anrInfo.anrGbrUe)
        {
            return true;
        }
        return isSupportReportCgiForGbrUe(getGbrUeSwitch());
    }
    void setReportTypePurpose() override
    {
        rCall.anrInfo.reportType = rCall.saHoMrQueueInfo.reportType;
        rCall.anrInfo.reportPurpose = rCall.saHoMrQueueInfo.reportPurpose;
    }
    void setTriggerQuantity() override
    {
        rCall.anrInfo.reportConfigQuantitySaHo = rCall.saHoMrQueueInfo.reportConfigQuantitySaHo;
    }
};
// Derived class for Feature2
class AnrRcHandler : public ReportCgiProcedure
{
public:
    AnrRcHandler(callInfo_type &_rCi, message_type *ptAll) : ReportCgiProcedure(e_REPORT_CGI_ANR, _rCi)
    {
        ncgiReq = reinterpret_cast<msgNcgiRequestOsabVccb_type *>(ptAll);
        VCCB_CLEAR_TIMER(&rCall.ueMeasForSon.measDelayTimer, CANCEL_TIMER);
        VCCB_CLEAR_TIMER(&rCall.anrInfo.refuseRetryTimer, CANCEL_TIMER);
    }

protected:
    int16_t validate(enumAnrObjType _ratType) override;
    void setReportCgiFlag() override
    {
        SET_REPORT_CGI_FLAG((&rCall), VCCB_FLAG_ON);
        SET_REPORT_CGI_STAT_COLLECT_REQUIRED((&rCall), VCCB_FLAG_ON); // FGS-SF0502 FR760 26A
    }
    uint8_t getGbrUeSwitch() override
    {
        VCCB_CHECK_E_RANGE_AND_VAL(
            rCall.servCellNum, MAX_CELL_NUM_VCCB, static_cast<uint8_t>(REPORT_CGI_GBR_SWITCH_TYPE_OFF));
        // SVR24B FGS-SF0502 FR192, FR193
        const VccbCellInfo_type *const pCell = &CELLINFO[rCall.servCellNum];
        return (nrType == rCall.anrInfo.ratType) ? pCell->anrInfo.reportCgiGbrSwitch
                                                 : pCell->irat_anrInfo.eutraReportCgiGbrSwitch;
    }
    bool isAutonomousGapEnabled() override
    {
        if (FALSE == FnVCCB_IsSupportUeAutonomousGaps(((&rCall)), rCall.servCellNum, rCall.anrInfo.ratType))
        {
            return false;
        }
        if (not rCall.anrInfo.anrGbrUe)
        {
            return true;
        }
        return isSupportReportCgiForGbrUe(getGbrUeSwitch());
    }

private:
    msgNcgiRequestOsabVccb_type *ncgiReq;
};
shared_ptr<ReportCgiProcedure> FnVCCB_MakeRcHandler(
    callInfo_type &rCall, enumReportCgi_type type, message_type *ptAll = nullptr);

void FnVCCB_StartAnrReportCgiWithDRX(callInfo_type *ptCi);
void FnVCCB_StartAnrReportCgiWithoutDRX(callInfo_type *ptCi);
void FnVCCB_CgiReportAbnormalStat(callInfo_type *ptCi);

#endif  // VCCB_FEAT_FeatAnr_H_
