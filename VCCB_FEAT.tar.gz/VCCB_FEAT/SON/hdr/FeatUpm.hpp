#ifndef VCCB_FEAT_FeatUpm_H_
#define VCCB_FEAT_FeatUpm_H_

#include "VccbStruct.h"

typedef enum {
    e_UPM_PCELL  = 1U,
    e_UPM_PSCELL = 2U
} enumUpmMode_type;

typedef enum {
    e_UPM_VISITED_PCELL     = 1U,
    e_UPM_VISITED_PSCELL    = 2U,
} enumUpmVisited_type;

class VisitedCell
{
protected:
    enumUpmVisited_type type;

    // This Variable Debugging
    union
    {
        // if type == e_UPM_VISITED_PCELL
        visitedCellInfo_type* pCell;

        // if type == e_UPM_VISITED_PSCELL
        VccbLastVisitedPSCellInformation_type* psCell;

        // debug
        void *pVoid;
    } ptr;

public:
    VisitedCell(void *_pPtr, enumUpmVisited_type _type) : type(_type) { ptr.pVoid = _pPtr; }

    virtual cgi_type getCgi() = 0;
    virtual cgi_type getNrCgi() = 0;
    //virtual cgi_type getEutraCgi() { return tempCgi; }
    virtual bool checkNotAllowedLastVisitedCell() = 0;
    virtual bool isVisitedCellNrRatType() { return true; }
    virtual uint16_t getUsage() = 0;
    virtual uint8_t getRatType() = 0;
    virtual visitedOctetStringCellInfo_type* getEutraCell() { return nullptr; }
    virtual uint32_t getNrStayTime() = 0;
    virtual visitedNrCellInfo_type* getNrCell() { return nullptr; }
    enumUpmVisited_type getType() { return type; }
    virtual void* getPtr() = 0;
};

class VisitedCellInfo : public VisitedCell
{
private:
    visitedCellInfo_type* getVisitedCellPtr() { return reinterpret_cast<visitedCellInfo_type *>(ptr.pVoid); }

    VisitedCellInfo() = delete;

public:
    VisitedCellInfo(visitedCellInfo_type* upmVisitedell) : VisitedCell(upmVisitedell, e_UPM_VISITED_PCELL) {}

    uint16_t getUsage() override { return getVisitedCellPtr()->usage; }
    cgi_type getCgi() override { return getNrCgi(); }
    cgi_type getNrCgi() override { return getVisitedCellPtr()->uRat.nrCell.cgi; }
    bool checkNotAllowedLastVisitedCell() override
    {
        if (getVisitedCellPtr()->ratType != ci_nr && getVisitedCellPtr()->ratType != ci_eutra)
        {
            return true;
        }
        return false;
    }
    bool isVisitedCellNrRatType() override { return (getVisitedCellPtr()->ratType == ci_nr) ? true : false; }
    uint8_t getRatType() override { return getVisitedCellPtr()->ratType; }
    virtual uint32_t getNrStayTime() override
    {
        // No Cuase is Activie Case
        if (getVisitedCellPtr()->uRat.nrCell.stayTimeEnhancedPresent == OPT_PRESENT)
            return getVisitedCellPtr()->uRat.nrCell.stayTimeEnhanced;
        else
            return getVisitedCellPtr()->uRat.nrCell.stayTime * 10;
    }
    visitedNrCellInfo_type* getNrCell() override { return &(getVisitedCellPtr()->uRat.nrCell); }
    visitedOctetStringCellInfo_type* getEutraCell() override { return &(getVisitedCellPtr()->uRat.eutraCell); }
    virtual void* getPtr() override { return getVisitedCellPtr(); }
};

class VisitedPSCellInfo : public VisitedCell
{
private:
    VccbLastVisitedPSCellInformation_type* getVisitedCellPtr() { return reinterpret_cast<VccbLastVisitedPSCellInformation_type *>(ptr.pVoid); }

    VisitedPSCellInfo() = delete;

public:
    VisitedPSCellInfo(VccbLastVisitedPSCellInformation_type* psCellUpmVisitedCell) :
        VisitedCell(psCellUpmVisitedCell, e_UPM_VISITED_PSCELL)
    {
    }

    uint16_t getUsage() override { return getVisitedCellPtr()->usage; }
    cgi_type getCgi() override { return getNrCgi(); }
    cgi_type getNrCgi() override { return getVisitedCellPtr()->pSCellID; }
    bool checkNotAllowedLastVisitedCell() override
    {
        if (getVisitedCellPtr()->pSCellID_Present == VCCB_FLAG_OFF)
        {
            return true;
        }
        if (getVisitedCellPtr()->ratType != ci_nr)
        {
            return true;
        }
        return false;
    }
    uint8_t getRatType() override { return getVisitedCellPtr()->ratType; }
    virtual uint32_t getNrStayTime() override
    {
        return static_cast<uint32_t>(getVisitedCellPtr()->timeStay );
    }
    virtual void* getPtr() override { return getVisitedCellPtr(); }
};
#endif