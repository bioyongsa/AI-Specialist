/**
 * @file        FeatSon.h
 * @brief       Utility functions for SON
 */

#ifndef VCCB_FEAT_FeatSon_H_
#define VCCB_FEAT_FeatSon_H_

#include "VccbStruct.h"
// #include "access_common_yang.h"

/****************************************************************************
                UTIL
****************************************************************************/
int16_t VCOM_GetStayTime_EUTRA(visitedOctetStringCellInfo_type *ptEutraCell, uint32_t *pPpTime);
int16_t VCOM_CheckCgiLoggingTypeIdentical(CGI_Info_Logging_type *ptCgi1, CGI_Info_Logging_type *ptCgi2);
void FnVCCB_UpdateRedcapFlag(callInfo_type *ptCi);
anr_cgi_type FnVCCB_GetNrServCgiFromCellNum(uint32_t cellNum);

/****************************************************************************
                ANR ( Automatic Neighbor Relation )
****************************************************************************/
BOOL VIIL_AnrIsGBRUe(callInfo_type *ptCi);

uint8_t FnVCCB_getUeBasedAnrSwitch(callInfo_type *ptCi, uint16_t cellNum, uint8_t ratType);
uint16_t FnVCCB_getAnrLongDrxCycle(callInfo_type *ptCi, uint16_t cellNum, uint8_t ratType, uint32_t freq);
void VIIL_InitReportCgi(callInfo_type *ptCi);
void FnVCCB_SetReportCgiTimer(callInfo_type *ptCi);
void FnVCCB_SetReportCgiTimerForNRDC(callInfo_type *ptCi);
bool FnVCCB_IsSupportUeBasedReportCgiForAnr(callInfo_type *ptCi, uint8_t ratType, uint16_t pci, uint32_t freq);
uint8_t FnVCCB_IsSupportUeAutonomousGaps(callInfo_type *ptCi, uint16_t cellNum, uint8_t ratType);

int16_t FnVCCB_updateNcgi(callInfo_type *ptCi, measResultList2NR_type *pMeasResultList2NR,
    msgNcgiNotifyVccbOsab_type *pNcgiNoti, anrCgiFailCause_type *pCause, uint16_t *pGnbIdLength);
int16_t FnVCCB_updateEcgiFromPlmnIdentityInfo(
    CellAccessRelatedInfo_EUTRA_EPC_type *ptMrCgiInfo, msgNcgiNotifyVccbOsab_type *pEcgiNoti);
int16_t FnVCCB_getServingCellFromMeasResultList2NR(
    callInfo_type *ptCi, measResultList2NR_type *ptMeasResultList2NR, uint8_t *ptServIdx);
bool FnVCCB_checkAnrMnsThreshold_withMeasResult(
    callInfo_type *ptCi, uint32_t anrFreq, measResultNR_type *pServResult, measResultNR_type *pNeighResult);
bool FnVCCB_checkIratAnrMnsThreshold_withMeasResult(callInfo_type *ptCi, measResultEUTRA_type *pNeighResult);

int16_t FnVCCB_NrdcMnTriggerReportCgiSn(callInfo_type *ptCi);
bool FnVCCB_IsReportCgiRunning(callInfo_type *ptCi);
int16_t FnVCCB_getUeAutonomousGaps(callInfo_type *ptCi, uint16_t cellNum, uint8_t ratType);
int16_t FnVCCB_GetCgiFromMeasureResultEutra(measResultNeighCellsEUTRA_type *ptMeasResultList2EUTRA, anrCgiInfo &anrCgi);
void FnVCCB_ProcessANRReportCGIEutraMeasurementReport(callInfo_type *ptCi, bool cgiAcquired, anrCgiInfo reportedCGI);

/****************************************************************************
                REPORT CGI FOR HANDOVER
****************************************************************************/
bool FnVCCB_IsSupportUeBasedReportCgiForMobility(callInfo_type *ptCi, uint8_t ratType);
bool FnVCCB_IsDuplicatedPciReportCgiCondition(callInfo_type *ptCi, uint8_t ratType);
int16_t FnVCCB_IsReportCgiMrValid(callInfo_type *ptCi);
int16_t FnVCCB_TriggerReportCgiHandover(callInfo_type *ptCi);
void FnVCCB_DeactivateReportCgi(callInfo_type *ptCi);
int16_t FnVCCB_SetReportCgiHandoverAnrInfo(callInfo_type *ptCi, uint8_t ratType, uint16_t pci, uint32_t freq);
int16_t FnVCCB_FillHandoverInfoFromReportCgiHoInfo(callInfo_type *ptCi, uint16_t candidateNbrIdx);

int16_t FnVCCB_SelectTgtCellFromNcgiInfoAndStartHandover_NewAlgorithm(
    callInfo_type *ptCi, measurementObjectUe_type *pMeasObj, cgi_type cgi);
int16_t FnVCCB_SelectTgtCellFromEcgiInfoAndStartHandover_NewAlgorithm(callInfo_type *ptCi, cgi_type cgi);
int16_t FnVCCB_SelectTgtCellFromNcgiInfoAndStartHandover(
    callInfo_type *ptCi, measResultList2NR_type *ptMeasResultList2NR, cgi_type cgi);
int16_t FnVCCB_SelectTgtCellFromEcgiInfoAndStartHandover(
    callInfo_type *ptCi, measResultNeighCellsEUTRA_type *ptMeasResultList2EUTRA, cgi_type cgi);
int16_t FnVCCB_SelectTgtCellFromOriginMRInfoAndStartHandover(
    callInfo_type *ptCi, measResultList2NR_type *ptMeasResultList2NR);

/****************************************************************************
                UPM ( UE Level Ping Pong HO Minimization )
****************************************************************************/
int16_t VCOM_UpdateUPM_Prepare(callInfo_type *ptCi);
int16_t VCOM_UpdateUPM_Finalize(callInfo_type *ptCi);
int16_t VCOM_UpdateCIOmForUPM(callInfo_type *ptCi, cellsToMeasInfo_type *pCellToMeas);
void FnVCCB_CancelUPM(callInfo_type *ptCi);
void VCOM_DisableUPM(callInfo_type *ptCi);

void FnVCCB_InitUpmAlgoInfo(upmAlgoInfoForCall_type *p);
void FnVCCB_InitUpmStatInfo(upmStatInfoForCall_type *p);

void FnVCCB_libStatUpmRlf_ForMRO(callInfo_type *ptCi, int mType, cgi_type *pSrcCgi, cgi_type *pTgtCgi);
void FnVCCB_libStatUpmRlf_ForHO(callInfo_type *ptCi, enumHoStatType mType, cgi_type *pSrcCgi, cgi_type *pTgtCgi);

upmStatInfoForCall_type* FnVCCB_GetUpmStatInfo(callInfo_type *ptCi);
upmAlgoInfoForCall_type* FnVCCB_GetUpmAlgoInfo(callInfo_type *ptCi);

#ifdef IPC_TEST
int16_t VCOM_ProcUPM(callInfo_type *ptCi);
int16_t FnVCCB_PrepareUPMDataFromCall(callInfo_type *ptCi);
#endif

/****************************************************************************
                MRO ( Mobility Robustness Optimization )
****************************************************************************/
int16_t VCOM_IntersystemPingpongDetection(callInfo_type *ptCi);
int16_t FnVCCB_VerifyLastServingCellFromNrRlfReport(callInfo_type *ptCi); //MRO + MDT


#endif  // VCCB_FEAT_FeatSon_H_
