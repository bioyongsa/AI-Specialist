/**
 * @file        FeatLbm.hpp
 * @brief       Functionality related to the VCCB side of Load Balancing Manager
 */

#ifndef VCCB_FEAT_FeatLbm_H_
#define VCCB_FEAT_FeatLbm_H_
#include <array>
#include "ComGlobalData.h"
#include <VccbStruct.h>

class PldSonOpStatusIndexManager {
private:
    std::array<CellNum_type, MAX_CELL_PER_VNF> dbIndexToCellNum;

    PldSonOpStatusIndexManager() { init(); }

    // Delete copy/move constructor and assignment
    PldSonOpStatusIndexManager(PldSonOpStatusIndexManager const&) = delete;
    PldSonOpStatusIndexManager(PldSonOpStatusIndexManager&&) = delete;
    PldSonOpStatusIndexManager& operator=(PldSonOpStatusIndexManager const&) = delete;
    PldSonOpStatusIndexManager& operator=(PldSonOpStatusIndexManager&&) = delete;

public:
    static PldSonOpStatusIndexManager& instance()
    {
        static PldSonOpStatusIndexManager mgr;
        return mgr;
    }

    void init()
    {
        std::fill(dbIndexToCellNum.begin(), dbIndexToCellNum.end(), MAX_CELL_NUM_VCCB);
    }

    CellNum_type getCellNumOfDbIndex(const uint16_t dbIndex) const
    {
        if (dbIndex >= MAX_CELL_PER_VNF)
        {
            return MAX_CELL_NUM_VCCB;
        }

        return dbIndexToCellNum[dbIndex];
    }

    void deleteDbIndex(const uint16_t dbIndex)
    {
        if (dbIndex >= MAX_CELL_PER_VNF)
        {
            return;
        }

        dbIndexToCellNum[dbIndex] = MAX_CELL_NUM_VCCB;
    }

    void insertDbIndexCellNumPair(const uint16_t dbIndex, const CellNum_type cellNum)
    {
        if (dbIndex >= MAX_CELL_PER_VNF)
        {
            return;
        }

        dbIndexToCellNum[dbIndex] = cellNum;
    }
};

#endif
