/**
 * @file        FeatLb.h
 * @brief       Utility functions for LB
 */

#ifndef VCCB_FEAT_FeatLb_H_
#define VCCB_FEAT_FeatLb_H_

#include "VccbStruct.h"
#include "StateMeasurements.h"
#include "access_common_yang.h"

/****************************************************************************
                UTIL
****************************************************************************/
void FnVCCB_UpdateIsLbHoFlag(callInfo_type *ptCi, StartSaHandoverDb& hoInputDb);
uint8_t FnVCCB_IsLoadBalancingHandoverAllowed(callInfo_type *ptCi);
bool VCCM_CheckIfTargetCellIsOverloaded(
    callInfo_type &rCall, uint16_t nbrIdx, int16_t lbAction, uint8_t targetCellLoadCheckType);
bool VCCB_CheckLbMeasActivated(const callInfo_type &call);

/****************************************************************************
    [FGR-LC0703] Load Balancing between NR Carriers
****************************************************************************/
uint8_t VCCM_CheckLoadBalancingTrigger(callInfo_type *ptCi);
void VCCM_CheckServingCellResourceLoadInfo(callInfo_type *ptCi, uint16_t cellNum);
int16_t VCCM_CheckTargetCellResourceLoadInfo(callInfo_type *ptCi, uint16_t nbrCellIdx, uint8_t loadCheckType);
int16_t VCCM_CheckValidUeForTriggeringSaLb(callInfo_type *ptCi);
int16_t FnVCCB_IsServingCellOverloaded_PdcchCceSaLb(callInfo_type *ptCi);
int16_t FnVCCB_IsServingCellOverloaded_AvailRscSaLb(callInfo_type *ptCi);
int16_t VCCM_IsServingCellOverloaded_PdcchCceLb(callInfo_type *ptCi);
int16_t VCCM_IsServingCellOverloaded_AvailRscLb(callInfo_type *ptCi);
int16_t VCCM_CheckCellOverloadStatus(const callInfo_type *const ptCi, const uint16_t cellNum);

void VCCM_CheckServingCellOverloadForTargetSelection(
    callInfo_type *ptCi, uint8_t *targetCellLoadCheckType, enumRSType rsType, uint32_t usedFreq, int16_t isServingPdcchOverloaded);
int16_t VCCM_IsTargetCellOverloaded_PdcchCceLb(callInfo_type *ptCi, uint16_t nbrCellIdx);
int16_t VCCM_IsTargetCellOverloaded_AvailRscLb(callInfo_type *ptCi, uint16_t nbrCellIdx);
int16_t FnVCCB_IsTargetCellOverloaded_PdcchCceLb(callInfo_type *ptCi, uint16_t nbrCellIdx);
int16_t FnVCCB_IsTargetCellOverloaded_AvailRscLb(callInfo_type *ptCi, uint16_t nbrCellIdx);
uint8_t VCCM_CheckLbByNSSAI(callInfo_type *ptCi);
int8_t VCCM_Check_LoadBalancingPriorityGroup(
    const measurementObjectNRBaseDb_type *ptMO, const uint8_t measObjectIdx, const sonCellPrbRsc_type *ptCellPrb, const callInfo_type &rCall, const VccbCellInfo_type &cellInfo);
int8_t FnVCCB_Check_LoadBalancingPriorityGroup(const callInfo_type *ptCi, const measurementObjectNRBaseDb_type *ptMO, const uint8_t measObjectIdx,
    const connModeLBInfo_type *ptConnInfo, const sonCellPrbRsc_type *ptCellPrb);
int16_t VCCB_LbMrWaitTimerAction(callInfo_type *ptCi);
bool FnVCCB_CheckDropConditionForLbMr(callInfo_type *ptCi, const enumMeasurementReportType reportType, const uint8_t reportPurpose);
void FnVCCB_InitPeriodicLbInfo();
bool FnVCCB_IsAnyCellPeriodicLbSwitchEnabled();
void FnVCCB_SelectUeForPeriodicLb();
void FnVCCB_HandlePeriodicLbHo(message_type *ptAll, uint8_t threadId);

/**
 * @brief Returns true if the given report type and purpose is for SA Load based HO.
 * 
 * @param reportType 
 * @param reportPurpose 
 * @return true 
 * @return false 
 */
inline bool VCCB_SA_IsLbHoReportTypePurpose(enumMeasurementReportType reportType, uint8_t reportPurpose)
{
    return (((measReport_A4 == reportType) && (a4Purpose_NRLoadBalancing == reportPurpose)) ||
            ((measReport_A5 == reportType) && (a5Purpose_NRLoadBalancing == reportPurpose)));
}

/****************************************************************************
    [FGR-LC0711] NR Inter-RAT Load Balancing to LTE
****************************************************************************/
uint8_t FnVCCM_CheckServingCellResourceLoadInfoForIratLbHo(callInfo_type *ptCi, uint16_t cellNum);
uint8_t FnVCCM_CheckOverLoadForIratLbHo(callInfo_type *ptCi, uint16_t cellNum);
uint8_t FnVCCM_CheckInterRatLoadBalancingTrigger(callInfo_type *ptCi, uint16_t cellNum);
uint8_t FnVCCM_CheckOverLoadForIratLbHo_PdcchCce(callInfo_type *ptCi, uint16_t cellNum);
uint8_t FnVCCM_CheckOverLoadForIratLbHo_AvailRsc(callInfo_type *ptCi, uint16_t cellNum);
void FnVCCM_SetIratLbMrWaitTimer(callInfo_type *ptCi);
int16_t FnVCCB_IratLbMrWaitTimerAction(callInfo_type *ptCi);

/****************************************************************************
    [FGR-LC0712] VoNR Load Balancing
****************************************************************************/
uint8_t FnVCCB_IsAllowedUeForVoNrLoadBalancing(callInfo_type *ptCi);
int16_t FnVCCB_IsServingCellOverloadedForVoNrLB(callInfo_type *ptCi);
uint8_t FnVCCB_IsSelectableTargetCellForVoNrLB(callInfo_type *ptCi, uint16_t nbrCellIdx);
void FnVCCB_UpdateVoNrLbState(callInfo_type *ptCi, uint16_t cellNum);
int16_t FnVCCB_VoNrLbMrWaitTimerAction(callInfo_type *ptCi);
void FnVCCB_CommitVoNrLB(callInfo_type *ptCi);

/****************************************************************************
    [FGR-LC0710] Slice LB (Slice Aware Connected Mode Load Balancing)
****************************************************************************/
// SVR23B 
void FnVCCB_TriggerSliceAwareLoadBalancing(callInfo_type *ptCi);
int8_t FnVCCB_HandleOnGoingSliceAwareLoadBalancing(callInfo_type *ptCi);
void FnVCCB_DecisionSliceAwareLoadBalancing(callInfo_type *ptCi);
void FnVCCB_SetSliceLbTriggerEvent(callInfo_type *ptCi, uint16_t eventType);
int32_t FnVCCB_GetSliceCapacityForInterCell(callInfo_type *ptCi, cgi_type cgi, uint8_t gnbIdLength, CellNum_type spCellNum);
int32_t FnVCCB_GetSliceCapacityForIntraCell(callInfo_type *ptCi, CellNum_type cellNum, uint8_t targetSliceIdx = MAX_ACTIVE_SLICE_NUM);
// SVR24A
int8_t FnVCCB_SliceLb_CheckSlaViolationEnabledUe(callInfo_type *ptCi);
int32_t FnVCCB_CalculateSliceCapacity(
    callInfo_type *ptCi, int32_t dlCapacity, int32_t ulCapacity, uint8_t isSdlCell, uint8_t targetSliceIdx = MAX_ACTIVE_SLICE_NUM);
int8_t FnVCCB_CheckSlaViolationCell(
    callInfo_type *ptCi, uint16_t cellNum, uint16_t sliceCacIndex, uint8_t targetSliceIndex);
int16_t FnVCCB_IsTargetSliceConfigured(callInfo_type *ptCi, uint8_t tgtSliceIdx); //SVR23B FGR-LC0710
int16_t FnVCCB_CheckConfiguredLbSliceList(callInfo_type *ptCi); //SVR23B FGR-LC0710
bool FnVCCB_CheckAvailableLbSlice(callInfo_type *ptCi);
void VLIB_ResetSliceLbInfo(callInfo_type *ptCi); //SVR23B FGR-LC0710
void VLIB_InitSliceLbInfo(callInfo_type *ptCi); //SVR23B FGR-LC0710
int16_t FnVCCB_SelectTargetSlice(callInfo_type *ptCi, uint8_t prevTgtSliceIdx, uint8_t &newTgtSliceIdx);

/****************************************************************************
    [FGR-LC0708] Load based PSCell Change for EN-DC
****************************************************************************/

/**
 * @brief Returns true if the given report type and purpose is for EN-DC Load based PSCell Change.
 * 
 * @param reportType 
 * @param reportPurpose 
 * @return true 
 * @return false 
 */
inline bool VCCB_NSA_IsLbHoReportTypePurpose(enumMeasurementReportType reportType, uint8_t reportPurpose)
{
    return (((measReport_A4 == reportType) && (a4Purpose_EndcLbPscellChange == reportPurpose)) ||
            ((measReport_A5 == reportType) && (a5Purpose_EndcLbPscellChange == reportPurpose)));
}

/**
 * @brief Returns true if given report type and purpose and for load balancing.
 *        It works for both SA and NSA.
 * 
 * @param call info
 * @param reportType 
 * @param reportPurpose 
 * @return true 
 * @return false 
 */
inline bool VCCB_IsLbReportTypePurpose(const callInfo_type &call, enumMeasurementReportType reportType, uint8_t reportPurpose)
{
    return (((E_CALLTYPE_NSA == call.callType) && VCCB_NSA_IsLbHoReportTypePurpose(reportType, reportPurpose)) ||
            ((E_CALLTYPE_SA == call.callType) && VCCB_SA_IsLbHoReportTypePurpose(reportType, reportPurpose)));
}

bool VCCB_NSA_NeedToProcessLbPscellChangeMr(const callInfo_type &call);
bool VCCB_NSA_IsLbFeatureApplicable(callInfo_type &call, uint16_t cellNum);
void VCCB_NSA_LbFinalizeIntraSnHo(callInfo_type &call);
void VCCB_NSA_SetLbMeasState(callInfo_type &call, NsaLbMeasState_enum state);

enumNrLbmConfigurationIndex_type FnVCCB_AdjustNrLbmIndexForParameterType(const enumNrLbmConfigurationIndex_type index, const enumLbmParameterType_type parameterType);
bool FnVCCB_IsAffectedByLbmParameter(const VccbCellInfo_type &cellInfo, const bool isRedCapUe);
uint8_t FnVCCB_GetIntraNrLbSwitch(const VccbCellInfo_type &cellInfo, const connModeLBInfo_type &connModeLbInfo, const bool isRedCapUe);
enumLoadEvalMode_Type FnVCCB_GetLoadEvaluateMode(const VccbCellInfo_type &cellInfo, const connModeLBInfo_type &connModeLbInfo, const bool isRedCapUe);
uint8_t FnVCCB_GetLbThresholdGroup(const VccbCellInfo_type &cellInfo, const measurementObjectNRBaseDb_type &measObj, const uint8_t measObjectIdx, const bool isRedCapUe);
// uint8_t FnVCCB_GetAvailRscThreshold(const VccbCellInfo_type &cellInfo, const connModeLBInfo_type &connModeLbInfo, const bool isRedCapUe);
// uint8_t FnVCCB_GetAvailRscThreshold1(const VccbCellInfo_type &cellInfo, const connModeLBInfo_type &connModeLbInfo, const bool isRedCapUe);
// uint8_t FnVCCB_GetAvailRscThreshold2(const VccbCellInfo_type &cellInfo, const connModeLBInfo_type &connModeLbInfo, const bool isRedCapUe);
// uint8_t FnVCCB_GetAvailRscThreshold3(const VccbCellInfo_type &cellInfo, const connModeLBInfo_type &connModeLbInfo, const bool isRedCapUe);
uint8_t FnVCCB_GetAvailRscThresholdGroup(const callInfo_type &rCi, const VccbCellInfo_type &rCell, const uint8_t thresholdGroupType);
uint8_t VCCB_LB_GetThresholdGroup(const callInfo_type &rCi, const VccbCellInfo_type &rCell, const measurementObjectNRBaseDb_type &mo, uint8_t moIdx);
uint8_t FnVCCB_GetResourceDelta(const VccbCellInfo_type &cellInfo, const bool isRedCapUe);

void FnVCCB_InitlbmConfiguration(cellLbmConfiguration_type &lbmConfiguration, const uint8_t windowIndex);
void FnVCCB_InitlbmConfiguration(cellLbmConfiguration_type &lbmConfiguration, const uint8_t windowIndex, const uint8_t purpose);

bool FnVCCB_IsStrongestPciOnlyModeForLB(callInfo_type &rCall, tgtSelectionParam_type tgtSelParam);

#endif  // VCCB_FEAT_FeatLb_H_
