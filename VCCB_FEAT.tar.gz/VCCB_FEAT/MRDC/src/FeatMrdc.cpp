/**
 * @file        FeatMrdc.cpp
 * @brief       utility functions
 */

#include "FeatMrdc.h"
#include "FeatMrdcApi.h"
#include "FeatTrafficMeasurements.hpp"
#include "FeatUlPathControlNRDC.h"
#include "FeatCapaHandling.h"
#include "FeatCallProc.h"
#include "FeatCallInfo.h"
#include "FeatCommon.h"
#include "FeatHo.h"
#include "FeatRrcSegment.h"
#include "FeatScgFailureNRDC.h"
#include "FeatMeasurements.hpp"
#include "FeatFullConfig.h"
#include "FeatNrdcMnBcReselection.hpp"

#include "CdbUtil.h"

#include "ComInclude.h"
#include "ComLibUtility.h"
#include "ComUtil.hpp"
#include "ComContainers.hpp"

#include "StateCommon.h"
#include "StateMeasurements.h"
#include "StateHandleAll.h"
#include "StateHandleSaMrdc.h"
#include "StateMco.h"

#include "MsgXnapStore.h"
#include "MsgNrRrcStore.h"
#include "MsgE1apMake.h"
#include "MsgE1apSend.h"
#include "MsgXnapSend.h"

/////////////////////////////////////////////////////////////////////////////////////////////////////////
static const uint8_t nedcPC2PowerOffset_NRTable[MAX_NEDC_POWER_OFFSET] = {25, 24, 23, 23, 21, 21, 19};
static const uint8_t nedcPC2PowerOffset_LTETable[MAX_NEDC_POWER_OFFSET] = {19, 21, 23, 23, 24, 24, 25};
static const uint8_t nedcPC3PowerOffset_NRTable[MAX_NEDC_POWER_OFFSET] = {22, 21, 20, 20, 18, 18, 16};
static const uint8_t nedcPC3PowerOffset_LTETable[MAX_NEDC_POWER_OFFSET] = {16, 18, 20, 20, 21, 21, 22};
/////////////////////////////////////////////////////////////////////////////////////////////////////////
// These structures should be referred only in FeatMrdc.c.
// So they have been defined in FeatMrdc.c rather than FeatMrdc.h

typedef enum
{
    NORMAL_FREE,
    FORCED_FREE
} enumMrdcBuffFreeModeType;

typedef struct
{
    unsigned short buffType;
    unsigned char unVolatile;
    unsigned char used;
    unsigned int callId;
    time_t allocTime;
} buffComHdrType;

typedef struct
{
    char buff[1024];
} buff1024Type;

typedef struct
{
    char buff[2048];
} buff2048Type;

typedef struct
{
    char buff[4096];
} buff4096Type;

// extended from buff8192Type to buff9216Type
typedef struct
{
    char buff[9216];
} buff9216Type;

typedef struct buff1024NodeType_
{
    buffComHdrType hdr;
    buff1024Type *buff;
    struct buff1024NodeType_ *next;
} buff1024NodeType;

typedef struct buff2048NodeType_
{
    buffComHdrType hdr;
    buff2048Type *buff;
    struct buff2048NodeType_ *next;
} buff2048NodeType;

typedef struct buff4096NodeType_
{
    buffComHdrType hdr;
    buff4096Type *buff;
    struct buff4096NodeType_ *next;
} buff4096NodeType;

typedef struct buff9216NodeType_
{
    buffComHdrType hdr;
    buff9216Type *buff;
    struct buff9216NodeType_ *next;
} buff9216NodeType;

typedef struct
{
    unsigned int initFlag;
    unsigned int noOfElem;  // MAX_CALL_PER_CPC's 10%

    buffCtrlStatsType allocStats[MAX_BUFF_TYPE_FOR_STATS];
    buffCtrlStatsType freeStats[MAX_BUFF_TYPE_FOR_STATS];
    struct
    {
        uint32_t attempt;
        uint32_t success;
        // uint32_t fail;
    } freeStatsAudit[MAX_BUFF_TYPE_FOR_STATS];

    /*
      It is recommended that buffer control node and buffer Data Node should be separated to keep
      linked-List integrity against even if data node is overrun by malfunction.
       */
    buff1024NodeType *buffNode1024;
    buff2048NodeType *buffNode2048;
    buff4096NodeType *buffNode4096;
    buff9216NodeType *buffNode9216;

    buff1024NodeType *root1024;
    buff2048NodeType *root2048;
    buff4096NodeType *root4096;
    buff9216NodeType *root9216;

    buff1024Type *buff1024;
    buff2048Type *buff2048;
    buff4096Type *buff4096;
    buff9216Type *buff9216;
} mrdcBufferCtrlType;

typedef struct
{
    pthread_mutex_t mutex_Buff1024;
    pthread_mutex_t mutex_Buff2048;
    pthread_mutex_t mutex_Buff4096;
    pthread_mutex_t mutex_Buff9216;
} mrdcMutexType;

#if 1
#define MAX_LOCAL_STR_SIZE 2048
typedef struct
{
    uint8_t drbId;
    uint8_t selectedBearerTypeFrozenFlag;
    uint8_t selectedBearerType;
    uint8_t reqBearerType;
    uint8_t bearerType;

    union
    {
        struct
        {
            uint8_t isDefaultDrb : 1;
            uint8_t isVonr       : 1;
            uint8_t isEmergency  : 1;
        };
    } property;
} dbgDrbInfo_type;

typedef struct {
    std::vector<dbgDrbInfo_type> vMnTermMcgDrbList;
    std::vector<dbgDrbInfo_type> vMnTermSplitDrbList;
    std::vector<dbgDrbInfo_type> vSnTermSplitDrbList;
    std::vector<dbgDrbInfo_type> vSnTermScgDrbList;

    uint8_t totalDrbCnt;
} drbInformation_type;


typedef struct {
    char mrLogBuf[MAX_LOCAL_STR_SIZE];
    int strLen;
} drbInformation_OutputBuffer_type;
#else
#define MAX_LOCAL_STR_SIZE 300
typedef struct {
    typedef struct
    {
        uint8_t drbCnt[MRDC_BEARER_TYPE_END + 1];
        uint8_t drbId[MRDC_BEARER_TYPE_END + 1][MAX_DRB_PER_CALL];
    } drbInformation_drbStruct_type;

    typedef struct
    {
        uint8_t isDefaultDrb : 1;
        uint8_t isVonr       : 1;
        uint8_t isEmergency  : 1;
    } drbInformation_extensionDrbStruct_type;

    bool diffPrint;

    uint8_t totalDrbCnt;
    drbInformation_drbStruct_type current;
    drbInformation_drbStruct_type diff;
    drbInformation_extensionDrbStruct_type extensionDrbInfo[MRDC_BEARER_TYPE_END + 1][MAX_DRB_PER_CALL];
} drbInformation_type;


typedef struct {
    char mrLogBuf[MAX_LOCAL_STR_SIZE];
    int strLen;
} drbInformation_OutputBuffer_type;
#endif

///////////////////////////////////////////////////////////////////////////

static mrdcBufferCtrlType gMrdcBuffCtrl;
static mrdcMutexType gMrdcMutex;
///////////////////////////////////////////////////////////////////////////
#define AddBuffToFreeList(_buffType, _discriminator, _nodeIdx, _freeMode, _callId, _failCause)    \
    do /* free buffer */                                                                          \
    {                                                                                             \
        MUTEX_LOCK(&gMrdcMutex.mutex_Buff##_discriminator);                                       \
                                                                                                  \
        buff##_discriminator##NodeType *pNode = &gMrdcBuffCtrl.buffNode##_discriminator[_nodeIdx];\
                                                                                                  \
        if (!pNode->hdr.used)                                                                     \
        {                                                                                         \
            MUTEX_UNLOCK(&gMrdcMutex.mutex_Buff##_discriminator);                                 \
            _failCause = MRDC_BUFF_CAUSE_ALREADY_FREE;                                            \
            break;                                                                                \
        }                                                                                         \
                                                                                                  \
        if ((_freeMode) == FORCED_FREE)                                                           \
        {                                                                                         \
        }                                                                                         \
        else                                                                                      \
        {                                                                                         \
            if ((_callId) != pNode->hdr.callId)                                                   \
            {                                                                                     \
                MUTEX_UNLOCK(&gMrdcMutex.mutex_Buff##_discriminator);                             \
                _failCause = MRDC_BUFF_CAUSE_INVALID_CALLID;                                      \
                break;                                                                            \
            }                                                                                     \
        }                                                                                         \
                                                                                                  \
        memset(pNode, 0, sizeof(buff##_discriminator##NodeType));                                 \
        pNode->hdr.buffType = _buffType;                                                          \
        pNode->buff = &gMrdcBuffCtrl.buff##_discriminator[_nodeIdx];                              \
                                                                                                  \
        if (gMrdcBuffCtrl.root##_discriminator)                                                   \
        {                                                                                         \
            pNode->next = gMrdcBuffCtrl.root##_discriminator;                                     \
        }                                                                                         \
        gMrdcBuffCtrl.root##_discriminator = pNode;                                               \
                                                                                                  \
        MUTEX_UNLOCK(&gMrdcMutex.mutex_Buff##_discriminator);                                     \
    } while (0)

#define RemoveBuffFromFreeList(_pBuff, _discriminator, _flag, _callId)                     \
    do /* alloc buffer */                                                                  \
    {                                                                                      \
        if (!gMrdcBuffCtrl.initFlag) break;                                                \
                                                                                           \
        MUTEX_LOCK(&gMrdcMutex.mutex_Buff##_discriminator);                                \
                                                                                           \
        buff##_discriminator##NodeType *pNode = NULL;                                      \
                                                                                           \
        if (gMrdcBuffCtrl.root##_discriminator)                                            \
        {                                                                                  \
            pNode = gMrdcBuffCtrl.root##_discriminator;                                    \
            pNode->hdr.used = 1;                                                           \
            pNode->hdr.unVolatile = _flag;                                                 \
            pNode->hdr.callId = _callId;                                                   \
            pNode->hdr.allocTime = time(NULL);                                             \
            _pBuff = (char *)pNode->buff;                                                  \
            gMrdcBuffCtrl.root##_discriminator = gMrdcBuffCtrl.root##_discriminator->next; \
        }                                                                                  \
                                                                                           \
        MUTEX_UNLOCK(&gMrdcMutex.mutex_Buff##_discriminator);                              \
    } while (0)
///////////////////////////////////////////////////////////////////////////
class SupportableFeatureSetDecisionforAllowedBC  // for NRDC-MN
{
private:
    callInfo_type *_ptCi;
    bool _forNrdc;
    uint16_t _cellNum;
    FeatureSets_type *_pFeatureSets;

    uint16_t _nrScsDlofCell, _nrScsUlofCell;
    uint16_t _bandwidthDlofCell, _bandwidthUlofCell, supportedBwDL;
    uint64_t _allowedCnt, _rejectedCnt, _rejectedInvalidParaCnt, _rejectedFsNotReadyCnt;

    uint8_t _featureSetDl[MAX_NUM_DL_FEATURESET + 1];
    // uint8_t featureSetUl[MAX_NUM_UL_FEATURESET+1];
    uint8_t _featureSetsDownlinkPerCC[MAX_NUM_FEATURESETS_PER_CC + 1];
    // uint8_t featureSetsUplinkPerCC[MAX_NUM_FEATURESETS_PER_CC+1];

    uint16_t convertSupportedBwDL2Decimal(bool isV1710, bool isFr2, uint8_t enumBandWidth);

public:
    SupportableFeatureSetDecisionforAllowedBC(callInfo_type *ptCi, uint16_t cellNum, bool forNrdc)
    {
        _ptCi = ptCi;
        _forNrdc = forNrdc;
        _cellNum = cellNum;
        _pFeatureSets = NULL;

        _nrScsDlofCell = _nrScsUlofCell = ci_Nr_scsMAX;
        _bandwidthDlofCell = _bandwidthUlofCell = supportedBwDL = 0;
        _allowedCnt = _rejectedCnt = _rejectedInvalidParaCnt = _rejectedFsNotReadyCnt = 0;

        memset(_featureSetDl, 0xFF, sizeof(_featureSetDl));
        memset(_featureSetsDownlinkPerCC, 0xFF, sizeof(_featureSetsDownlinkPerCC));

        if (_ptCi && _ptCi->myThreadId < MAX_CALL_THREAD_NUM_VCCB)
        {
            _pFeatureSets = &THREAD_INFO->call[_ptCi->myThreadId].buf.featureSets;
        }
        if (_cellNum < MAX_CELL_NUM_VCCB)
        {
            VccbCellInfo_type *pCell = &CELLINFO[_cellNum];

            _nrScsDlofCell = pCell->nrScsDl;
            _nrScsUlofCell = pCell->nrScsUl;
            _bandwidthDlofCell = pCell->intraGnbNbrInfo.bandwidthDl;
            _bandwidthUlofCell = pCell->intraGnbNbrInfo.bandwidthUl;
        }
    }

    bool isSupportableFeatureSetforAllowedBC(callInfo_type *_ptCi, uint16_t fsDL, uint16_t fsUL);
    void showInternalStats(callInfo_type *_ptCi);
};

void SupportableFeatureSetDecisionforAllowedBC::showInternalStats(callInfo_type *ptCi)
{
    _ptCi = ptCi;
    VALID_E_POINT_CHECK_VOID(_ptCi);

    VCCB_PRINT_CALL_LOG_MRDC(_ptCi,
        "[NRDC][FS] Internal Stats(allowedCnt(%lu) rejectedCnt(%lu) rejectedInvalidParaCnt(%lu) "
        "rejectedFsNotReadyCnt(%lu)!\n",
        _allowedCnt, _rejectedCnt, _rejectedInvalidParaCnt, _rejectedFsNotReadyCnt);
}

uint16_t SupportableFeatureSetDecisionforAllowedBC::convertSupportedBwDL2Decimal(
    bool isV1710, bool isFr2, uint8_t enumBandWidth)
{
// FGR-CC5200:FR150
#define MAX_NUM_OF_FR1_BANDWIDTH       11
#define MAX_NUM_OF_FR2_BANDWIDTH       4
#define MAX_NUM_OF_FR1_BANDWIDTH_V1710 15
#define MAX_NUM_OF_FR2_BANDWIDTH_V1710 7

    static const uint16_t fr1_bandwidth[MAX_NUM_OF_FR1_BANDWIDTH] = {5, 10, 15, 20, 25, 30, 40, 50, 60, 80, 100};
    static const uint16_t fr2_bandwidth[MAX_NUM_OF_FR2_BANDWIDTH] = {50, 100, 200, 400};
    static const uint16_t fr1_bandwidth_v1710[MAX_NUM_OF_FR1_BANDWIDTH_V1710] = {
        5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 60, 70, 80, 90, 100};
    static const uint16_t fr2_bandwidth_v1710[MAX_NUM_OF_FR2_BANDWIDTH_V1710] = {50, 100, 200, 400, 800, 1600, 2000};

    if (isV1710)
    {
        if (isFr2)
        {
            if (enumBandWidth >= MAX_NUM_OF_FR2_BANDWIDTH_V1710)
            {
                VCCB_PRINT_ERROR("Invalid v1710 fr2 enumBandWidth(%u) in %s!!\n", enumBandWidth, __func__);
                return 0;
            }
            return fr2_bandwidth_v1710[enumBandWidth];
        }
        else
        {
            if (enumBandWidth >= MAX_NUM_OF_FR1_BANDWIDTH_V1710)
            {
                VCCB_PRINT_ERROR("Invalid v1710 fr1 enumBandWidth(%u) in %s!!\n", enumBandWidth, __func__);
                return 0;
            }
            return fr1_bandwidth_v1710[enumBandWidth];
        }
    }
    else
    {
        if (isFr2)
        {
            if (enumBandWidth >= MAX_NUM_OF_FR2_BANDWIDTH)
            {
                VCCB_PRINT_ERROR("Invalid fr2 enumBandWidth(%u) in %s!!\n", enumBandWidth, __func__);
                return 0;
            }
            return fr2_bandwidth[enumBandWidth];
        }
        else
        {
            if (enumBandWidth >= MAX_NUM_OF_FR1_BANDWIDTH)
            {
                VCCB_PRINT_ERROR("Invalid fr1 enumBandWidth(%u) in %s!!\n", enumBandWidth, __func__);
                return 0;
            }
            return fr1_bandwidth[enumBandWidth];
        }
    }

#undef MAX_NUM_OF_FR1_BANDWIDTH
#undef MAX_NUM_OF_FR2_BANDWIDTH
#undef MAX_NUM_OF_FR1_BANDWIDTH_V1710
#undef MAX_NUM_OF_FR2_BANDWIDTH_V1710
}

bool SupportableFeatureSetDecisionforAllowedBC::isSupportableFeatureSetforAllowedBC(callInfo_type *ptCi, uint16_t fsDL, uint16_t fsUL)
{
    _ptCi = ptCi;
    VALID_E_POINT_CHECK_RET_VAL(_ptCi, false);

    if (!_forNrdc)  // in current scope, it is no need to check the detail featureSets in nedc
    {
        _allowedCnt++;
        return true;
    }

    if (!_pFeatureSets)
    {
        _rejectedCnt++;
        _rejectedFsNotReadyCnt++;
        return false;
    }

    if (_pFeatureSets->nrOfFeatureSetsDownlink == 0 /*|| _pFeatureSets->nrOfFeatureSetsUplink == 0*/)
    {
        _rejectedCnt++;
        _rejectedFsNotReadyCnt++;
        return false;
    }

    // 1 ~ MAX_NUM_DL_FEATURESET
    if (fsDL == 0 || fsDL > MAX_NUM_DL_FEATURESET || fsUL == 0 /* TBD || fsUL > MAX_NUM_DL_FEATURESET */)
    {
        _rejectedCnt++;
        _rejectedInvalidParaCnt++;
        return false;
    }

    if (0xFF != _featureSetDl[fsDL])
    {
        if (_featureSetDl[fsDL])
        {
            _allowedCnt++;
            return true;
        }
        else
        {
            _rejectedCnt++;
            return false;
        }
    }
    _featureSetDl[fsDL] = VCCB_FLAG_OFF;
    featureSetDownlink_type &featureSetDownLinkBuff = _pFeatureSets->featureSetsDownlink[fsDL - 1];
    // TBD, featureSetUplink_type &featureSetsUplink = _pFeatureSets->featureSetsUplink[fsUL-1];

    int maxIdx = MIN(featureSetDownLinkBuff.nrOfFeatureSetPerCCIds, MAX_NR_OF_SERVING_CELLS);
    for (int fsIdx = 0; fsIdx < maxIdx; fsIdx++)
    {
        uint16_t featureSetDownlinkPerCCId = featureSetDownLinkBuff.featureSetDownlinkPerCCIds[fsIdx];

        // 1 ~ MAX_NUM_FEATURESETS_PER_CC
        if (featureSetDownlinkPerCCId == 0 || featureSetDownlinkPerCCId > MAX_NUM_FEATURESETS_PER_CC
            /*|| featureSetUplinkPerCCId == 0 || featureSetUplinkPerCCId > MAX_NUM_FEATURESETS_PER_CC*/)
        {
            continue;
        }

        if (0xFF != _featureSetsDownlinkPerCC[featureSetDownlinkPerCCId])
        {
            if (_featureSetsDownlinkPerCC[featureSetDownlinkPerCCId])
            {
                _featureSetDl[fsDL] = VCCB_FLAG_ON;
                _allowedCnt++;
                return true;
            }
            else
            {
                continue;
            }
        }
        _featureSetsDownlinkPerCC[featureSetDownlinkPerCCId] = VCCB_FLAG_OFF;

        FeatureSetDownlinkPerCC_type &featureSetsDownlinkPerCCBuff =
            _pFeatureSets->featureSetsDownlinkPerCC[featureSetDownlinkPerCCId - 1];
        // FGR-CC5200:FR150
        uint16_t supportedBwDecimal =
            convertSupportedBwDL2Decimal(featureSetsDownlinkPerCCBuff.supportedBandwidthDL_v1710,
                featureSetsDownlinkPerCCBuff.supportedBandwidthDL_isFr2,
                featureSetsDownlinkPerCCBuff.supportedBandWidthDL_value);

        if (featureSetsDownlinkPerCCBuff.supportedSubcarrierSpacingDL == _nrScsDlofCell &&
            supportedBwDecimal >= _bandwidthDlofCell)
        {
            _featureSetsDownlinkPerCC[featureSetDownlinkPerCCId] = VCCB_FLAG_ON;
            _featureSetDl[fsDL] = VCCB_FLAG_ON;
            _allowedCnt++;
            VCCB_PRINT_CALL_LOG_MRDC(_ptCi,
                "[NRDC][FS] Matched(fsIdx(%d) CCId(%d)|sup_Scs_Dl(%u)==Scs_Cell(%u) && sup_Bw(%u)>="
                "BwDl_Cell(%u))!\n",
                fsIdx, featureSetDownlinkPerCCId, featureSetsDownlinkPerCCBuff.supportedSubcarrierSpacingDL,
                _nrScsDlofCell, supportedBwDecimal, _bandwidthDlofCell);
            return true;
        }
        else
        {
            VCCB_PRINT_CALL_LOG_MRDC(_ptCi,
                "[NRDC][FS] Not matched(fsIdx(%d) CCId(%d)|sup_Scs_Dl(%u)==Scs_Cell(%u) && sup_Bw(%u)>="
                "BwDl_Cell(%u))!\n",
                fsIdx, featureSetDownlinkPerCCId, featureSetsDownlinkPerCCBuff.supportedSubcarrierSpacingDL,
                _nrScsDlofCell, supportedBwDecimal, _bandwidthDlofCell);
        }
    }
    _rejectedCnt++;

    return false;
}
/**
 * @brief   buffer management
 */
static void _FreeBuff(unsigned short buffType, unsigned long nodeIdx, enumMrdcBuffFreeModeType freeMode, unsigned int callId,
    enumMrdcBuffCause_type &failCause)
{
    AUTO_TRACE_FUNC;
    switch (buffType)
    {
        case buffType1024:
            AddBuffToFreeList(buffType, 1024, nodeIdx, freeMode, callId, failCause);
            break;

        case buffType2048:
            AddBuffToFreeList(buffType, 2048, nodeIdx, freeMode, callId, failCause);
            break;

        case buffType4096:
            AddBuffToFreeList(buffType, 4096, nodeIdx, freeMode, callId, failCause);
            break;

        case buffType9216:
            AddBuffToFreeList(buffType, 9216, nodeIdx, freeMode, callId, failCause);
            break;

        default:
            // unreachable...
            return;
    }
}

/**
 * @brief   buffer management
 */
static char *_GetBufferCore(unsigned int buffType, unsigned char unVolatileFlag, unsigned int callId)
{
    AUTO_TRACE_FUNC;
    char *pBuff = NULL;

    switch (buffType)
    {
        case buffType1024:
            RemoveBuffFromFreeList(pBuff, 1024, unVolatileFlag, callId);
            break;

        case buffType2048:
            RemoveBuffFromFreeList(pBuff, 2048, unVolatileFlag, callId);
            break;

        case buffType4096:
            RemoveBuffFromFreeList(pBuff, 4096, unVolatileFlag, callId);
            break;

        case buffType9216:
            RemoveBuffFromFreeList(pBuff, 9216, unVolatileFlag, callId);
            break;

        default:
            // unreachable...
            return NULL;
    }

    return pBuff;
}

/**
 * @brief   buffer management
 */
static char *_GetBuffer(unsigned int buffType, unsigned char unVolatileFlag, unsigned int callId)
{
    AUTO_TRACE_FUNC;
    char *pBuff = NULL;

    unsigned int eBufType;

    // if allocation is failed, continue for the next bigger buffer.
    for (eBufType = buffType; eBufType < MAX_BUFF_TYPE; eBufType++)
    {
        pBuff = _GetBufferCore(eBufType, unVolatileFlag, callId);
        if (pBuff) break;
    }

    return pBuff;
}

static void _MakeMrdcFreeNodePool(void)
{
    AUTO_TRACE_FUNC;
    // this shall be called when block is initialized or mrdcBuff needs to be recomposited
    uint32_t loop;

    buff1024NodeType *pNode1024 = gMrdcBuffCtrl.buffNode1024;
    buff2048NodeType *pNode2048 = gMrdcBuffCtrl.buffNode2048;
    buff4096NodeType *pNode4096 = gMrdcBuffCtrl.buffNode4096;
    buff9216NodeType *pNode9216 = gMrdcBuffCtrl.buffNode9216;

    for (loop = 0; loop < gMrdcBuffCtrl.noOfElem; loop++)
    {
        memset(&pNode1024[loop], 0, sizeof(buff1024NodeType));
        pNode1024[loop].hdr.buffType = buffType1024;
        pNode1024[loop].buff = &gMrdcBuffCtrl.buff1024[loop];
        if (gMrdcBuffCtrl.root1024)
        {
            pNode1024[loop].next = gMrdcBuffCtrl.root1024;
        }
        gMrdcBuffCtrl.root1024 = &pNode1024[loop];

        memset(&pNode2048[loop], 0, sizeof(buff2048NodeType));
        pNode2048[loop].hdr.buffType = buffType2048;
        pNode2048[loop].buff = &gMrdcBuffCtrl.buff2048[loop];
        if (gMrdcBuffCtrl.root2048)
        {
            pNode2048[loop].next = gMrdcBuffCtrl.root2048;
        }
        gMrdcBuffCtrl.root2048 = &pNode2048[loop];

        memset(&pNode4096[loop], 0, sizeof(buff4096NodeType));
        pNode4096[loop].hdr.buffType = buffType4096;
        pNode4096[loop].buff = &gMrdcBuffCtrl.buff4096[loop];
        if (gMrdcBuffCtrl.root4096)
        {
            pNode4096[loop].next = gMrdcBuffCtrl.root4096;
        }
        gMrdcBuffCtrl.root4096 = &pNode4096[loop];

        memset(&pNode9216[loop], 0, sizeof(buff9216NodeType));
        pNode9216[loop].hdr.buffType = buffType9216;
        pNode9216[loop].buff = &gMrdcBuffCtrl.buff9216[loop];
        if (gMrdcBuffCtrl.root9216)
        {
            pNode9216[loop].next = gMrdcBuffCtrl.root9216;
        }
        gMrdcBuffCtrl.root9216 = &pNode9216[loop];
    }
}

/**
 * @brief   buffer management
 */
int VLIB_InitBuffMgmt(void)
{
    AUTO_TRACE_FUNC;
    unsigned long totSize = 0;

    memset(&gMrdcBuffCtrl, 0, sizeof(gMrdcBuffCtrl));

    gMrdcBuffCtrl.noOfElem = static_cast<unsigned int>(VCCB_MAX_CALL_COUNT_PER_CPC * 0.09);

#ifdef IPC_TEST
#else
    VCCB_PRINTF("gMrdcBuffCtrl.noOfElem = %u\n", gMrdcBuffCtrl.noOfElem);
#endif

    gMrdcBuffCtrl.buffNode1024 = (buff1024NodeType *)malloc(sizeof(buff1024NodeType) * gMrdcBuffCtrl.noOfElem);
    // totSize += sizeof(buff1024NodeType)*gMrdcBuffCtrl.noOfElem;
    if (!gMrdcBuffCtrl.buffNode1024)
    {
        goto MEM_ALLOC_EXCEPTION_HANDLING;
    }

    gMrdcBuffCtrl.buffNode2048 = (buff2048NodeType *)malloc(sizeof(buff2048NodeType) * gMrdcBuffCtrl.noOfElem);
    // totSize += sizeof(buff2048NodeType)*gMrdcBuffCtrl.noOfElem;
    if (!gMrdcBuffCtrl.buffNode2048)
    {
        goto MEM_ALLOC_EXCEPTION_HANDLING;
    }

    gMrdcBuffCtrl.buffNode4096 = (buff4096NodeType *)malloc(sizeof(buff4096NodeType) * gMrdcBuffCtrl.noOfElem);
    // totSize += sizeof(buff4096NodeType)*gMrdcBuffCtrl.noOfElem;
    if (!gMrdcBuffCtrl.buffNode4096)
    {
        goto MEM_ALLOC_EXCEPTION_HANDLING;
    }

    gMrdcBuffCtrl.buffNode9216 = (buff9216NodeType *)malloc(sizeof(buff9216NodeType) * gMrdcBuffCtrl.noOfElem);
    // totSize += sizeof(buff9216NodeType)*gMrdcBuffCtrl.noOfElem;
    if (!gMrdcBuffCtrl.buffNode9216)
    {
        goto MEM_ALLOC_EXCEPTION_HANDLING;
    }

    // buffer pool allocation.
    gMrdcBuffCtrl.buff1024 = (buff1024Type *)malloc(sizeof(buff1024Type) * gMrdcBuffCtrl.noOfElem);
    totSize += sizeof(buff1024Type) * gMrdcBuffCtrl.noOfElem;
    if (!gMrdcBuffCtrl.buff1024)
    {
        goto MEM_ALLOC_EXCEPTION_HANDLING;
    }

    gMrdcBuffCtrl.buff2048 = (buff2048Type *)malloc(sizeof(buff2048Type) * gMrdcBuffCtrl.noOfElem);
    totSize += sizeof(buff2048Type) * gMrdcBuffCtrl.noOfElem;
    if (!gMrdcBuffCtrl.buff2048)
    {
        goto MEM_ALLOC_EXCEPTION_HANDLING;
    }

    gMrdcBuffCtrl.buff4096 = (buff4096Type *)malloc(sizeof(buff4096Type) * gMrdcBuffCtrl.noOfElem);
    totSize += sizeof(buff4096Type) * gMrdcBuffCtrl.noOfElem;
    if (!gMrdcBuffCtrl.buff4096)
    {
        goto MEM_ALLOC_EXCEPTION_HANDLING;
    }
    gMrdcBuffCtrl.buff9216 = (buff9216Type *)malloc(sizeof(buff9216Type) * gMrdcBuffCtrl.noOfElem);
    totSize += sizeof(buff9216Type) * gMrdcBuffCtrl.noOfElem;
    if (!gMrdcBuffCtrl.buff9216)
    {
        goto MEM_ALLOC_EXCEPTION_HANDLING;
    }

#ifdef IPC_TEST
#else
    VCCB_PRINTF("total buffer size = %luMB (%lu bytes)\n", totSize / 1024 / 1024, totSize);
#endif

    _MakeMrdcFreeNodePool();
    gMrdcBuffCtrl.initFlag = 1;

    return GOOD;

MEM_ALLOC_EXCEPTION_HANDLING:
    VLIB_FreeBuffMgmt();
    return ERROR;
}

/**
 * @brief   buffer management
 */
void VLIB_FreeBuffMgmt(void)
{
    AUTO_TRACE_FUNC;
    gMrdcBuffCtrl.initFlag = 0;

    if (gMrdcBuffCtrl.buffNode1024) free(gMrdcBuffCtrl.buffNode1024);
    if (gMrdcBuffCtrl.buffNode2048) free(gMrdcBuffCtrl.buffNode2048);
    if (gMrdcBuffCtrl.buffNode4096) free(gMrdcBuffCtrl.buffNode4096);
    if (gMrdcBuffCtrl.buffNode9216) free(gMrdcBuffCtrl.buffNode9216);
    if (gMrdcBuffCtrl.buff1024) free(gMrdcBuffCtrl.buff1024);
    if (gMrdcBuffCtrl.buff2048) free(gMrdcBuffCtrl.buff2048);
    if (gMrdcBuffCtrl.buff4096) free(gMrdcBuffCtrl.buff4096);
    if (gMrdcBuffCtrl.buff9216) free(gMrdcBuffCtrl.buff9216);

    gMrdcBuffCtrl.buffNode1024 = NULL;
    gMrdcBuffCtrl.buffNode2048 = NULL;
    gMrdcBuffCtrl.buffNode4096 = NULL;
    gMrdcBuffCtrl.buffNode9216 = NULL;
    gMrdcBuffCtrl.buff1024 = NULL;
    gMrdcBuffCtrl.buff2048 = NULL;
    gMrdcBuffCtrl.buff4096 = NULL;
    gMrdcBuffCtrl.buff9216 = NULL;
}

/**
 * @brief   buffer management
 *
 * purpose : this api is to allocate buffer
 * This api is to be used when data needs to be stored for short time as a message relay after some steps.
 * This api can be used to overcome the following a few of shortcomings.
 *   - There is too much memory waste to save a large size message in callInfo to save for a while.
 *   - It can't guarantee the mutual exclusion for data if that is stored in the global DB based on call-thread for some
 * transactions. Because the context switching of thread will occur.
 */
char *VLIB_GetBuffer(callInfo_type *ptCi, unsigned int size, unsigned char unvolatileFlag)
{
    AUTO_TRACE_FUNC;
    enumMrdcBuffCause_type failCause = MRDC_BUFF_CAUSE_NORMAL;

    if (!ptCi)
    {
        return NULL;
    }

    unsigned int buffType = 0;
    char *pBuff = 0;

    if (0 == size)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Error, required size 0 is no need to get buffer !\n");

        return NULL;
    }
    if (size > sizeof(buff9216Type))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Error, too Big buffer(%u) is required !\n", size);

        return NULL;
    }
    else if (size > sizeof(buff4096Type))
    {
        buffType = buffType9216;
    }
    else if (size > sizeof(buff2048Type))
    {
        buffType = buffType4096;
    }
    else if (size > sizeof(buff1024Type))
    {
        buffType = buffType2048;
    }
    else
    {
        buffType = buffType1024;
    }

    VCCB_CHECK_E_RANGE_AND_NULL(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    uint8_t myThreadId = ptCi->myThreadId;
    gMrdcBuffCtrl.allocStats[buffType].attempt[myThreadId]++;
    DBG->mrdcBuffCtrlStats.allocStats[buffType].attempt[myThreadId]++;
    pBuff = _GetBuffer(buffType, unvolatileFlag, ptCi->callId);
    if (!pBuff)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Error, _getBuffer(type:%d) !\n", buffType);
        failCause = MRDC_BUFF_CAUSE_NO_AVAIL_RESOURCE;
    }

    if (MRDC_BUFF_CAUSE_NORMAL == failCause)
    {
        gMrdcBuffCtrl.allocStats[buffType].success[myThreadId]++;
        DBG->mrdcBuffCtrlStats.allocStats[buffType].success[myThreadId]++;
    }
    else if (failCause < MRDC_BUFF_CAUSE_END)
    {
        DBG->mrdcBuffCtrlStats.allocStats[buffType].fail[MRDC_BUFF_CAUSE_NO_AVAIL_RESOURCE]++;
    }

    return pBuff;
}

/**
 * @brief   buffer management
 */
void VLIB_FreeBuffer(callInfo_type *ptCi, char *pBuff, const char *fnName)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(fnName);
    enumMrdcBuffCause_type failCause = MRDC_BUFF_CAUSE_NORMAL;

    unsigned short buffType = MAX_BUFF_TYPE;
    unsigned long offset = 0, nodeIdx = 0, spare = 0;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pBuff);

    if (pBuff >= (char *)gMrdcBuffCtrl.buff1024 &&
        pBuff < ((char *)gMrdcBuffCtrl.buff1024 + sizeof(buff1024Type) * gMrdcBuffCtrl.noOfElem))
    {
        buffType = buffType1024;
        offset = (unsigned long)(pBuff - (char *)gMrdcBuffCtrl.buff1024);
    }
    else if (pBuff >= (char *)gMrdcBuffCtrl.buff2048 &&
             pBuff < ((char *)gMrdcBuffCtrl.buff2048 + sizeof(buff2048Type) * gMrdcBuffCtrl.noOfElem))
    {
        buffType = buffType2048;
        offset = (unsigned long)(pBuff - (char *)gMrdcBuffCtrl.buff2048);
    }
    else if (pBuff >= (char *)gMrdcBuffCtrl.buff4096 &&
             pBuff < ((char *)gMrdcBuffCtrl.buff4096 + sizeof(buff4096Type) * gMrdcBuffCtrl.noOfElem))
    {
        buffType = buffType4096;
        offset = (unsigned long)(pBuff - (char *)gMrdcBuffCtrl.buff4096);
    }
    else if (pBuff >= (char *)gMrdcBuffCtrl.buff9216 &&
             pBuff < ((char *)gMrdcBuffCtrl.buff9216 + sizeof(buff9216Type) * gMrdcBuffCtrl.noOfElem))
    {
        buffType = buffType9216;
        offset = (unsigned long)(pBuff - (char *)gMrdcBuffCtrl.buff9216);
    }
    else
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Error, invalid buffer pointer(0x%p) is used in VLIB_FreeBuffer of %s!\n", pBuff, fnName);
        failCause = MRDC_BUFF_CAUSE_NO_AVAIL_RESOURCE;
        goto COLLECT_MRDC_BUFF_STAT;
    }

    switch (buffType)
    {
        case buffType1024:
            nodeIdx = offset / sizeof(buff1024Type);
            spare = offset - nodeIdx * sizeof(buff1024Type);
            break;

        case buffType2048:
            nodeIdx = offset / sizeof(buff2048Type);
            spare = offset - nodeIdx * sizeof(buff2048Type);
            break;

        case buffType4096:
            nodeIdx = offset / sizeof(buff4096Type);
            spare = offset - nodeIdx * sizeof(buff4096Type);
            break;

        case buffType9216:
            nodeIdx = offset / sizeof(buff9216Type);
            spare = offset - nodeIdx * sizeof(buff9216Type);
            break;

        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "invalid buffType(%u)!\n", buffType);
            failCause = MRDC_BUFF_CAUSE_NO_AVAIL_RESOURCE;
            goto COLLECT_MRDC_BUFF_STAT;
    }

    if (spare || (nodeIdx >= gMrdcBuffCtrl.noOfElem))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "Error, invalid buffer pointer(0x%p), address align doesn't matched(nodeIdx:%lu, spare:%lu) in "
            "VLIB_FreeBuffer of %s!\n",
            pBuff, nodeIdx, spare, fnName);
        failCause = MRDC_BUFF_CAUSE_NO_AVAIL_RESOURCE;
        goto COLLECT_MRDC_BUFF_STAT;
    }

    _FreeBuff(buffType, nodeIdx, NORMAL_FREE, ptCi->callId, failCause);

COLLECT_MRDC_BUFF_STAT:
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    uint8_t myThreadId = ptCi->myThreadId;
    gMrdcBuffCtrl.freeStats[buffType].attempt[myThreadId]++;
    DBG->mrdcBuffCtrlStats.freeStats[buffType].attempt[myThreadId]++;
    if (MRDC_BUFF_CAUSE_NORMAL == failCause)
    {
        gMrdcBuffCtrl.freeStats[buffType].success[myThreadId]++;
        DBG->mrdcBuffCtrlStats.freeStats[buffType].success[myThreadId]++;
    }
    else if (failCause < MRDC_BUFF_CAUSE_END)
    {
       DBG->mrdcBuffCtrlStats.freeStats[buffType].fail[failCause]++;
    }

    return;
}

/**
 * @brief   buffer management
 */
int FnVCCB_InitMrdcMutexes(pthread_mutexattr_t *pAttr)
{
    int rCode = 0;

    if (!pAttr)
    {
        return EXIT_MUTEXATTR_INIT_FAIL;
    }

    rCode = pthread_mutex_init(&gMrdcMutex.mutex_Buff1024, pAttr);
    if (rCode) return EXIT_MUTEXATTR_INIT_FAIL;

    rCode = pthread_mutex_init(&gMrdcMutex.mutex_Buff2048, pAttr);
    if (rCode) return EXIT_MUTEXATTR_INIT_FAIL;

    rCode = pthread_mutex_init(&gMrdcMutex.mutex_Buff4096, pAttr);
    if (rCode) return EXIT_MUTEXATTR_INIT_FAIL;

    rCode = pthread_mutex_init(&gMrdcMutex.mutex_Buff9216, pAttr);
    if (rCode) return EXIT_MUTEXATTR_INIT_FAIL;

    return 0;
}

bool FnVCCB_CheckValidEndPointXn_ForSN(uint16_t epIdx)
{
    // Included inside Xn DB.
    if (epIdx < MAX_XN_NBR_PER_GNB) return true;

    // In the case of Intra Xn.
    if (epIdx == XNIDX_FOR_INTRA_GNB_NRDC) return true;

    return false;
}

/**
 * @brief Initialize MRDC MNInfo structure.
 *
 * This function initializes the given MRDC MNInfo structure by setting all its members to their default values.
 *
 * @param ptMnInfo Pointer to the MRDC MNInfo structure to be initialized.
 */
void FnVCCB_InitMrdcMnInfo(MNInfo_type *ptMnInfo)
{
    // Check if the input pointer is valid
    VALID_E_POINT_CHECK_VOID(ptMnInfo);

    // Set all members of the MRDC MNInfo structure to their default values
    memset(ptMnInfo, 0x00, sizeof(MNInfo_type));
}

/**
 * @brief Initialize MRDC SNInfo structure.
 *
 * This function initializes the given MRDC SNInfo structure by setting all its members to their default values.
 *
 * @param ptSnInfo Pointer to the MRDC SNInfo structure to be initialized.
 */
void FnVCCB_InitMrdcSnInfo(SNInfo_type *ptSnInfo)
{
    // Check if the input pointer is valid
    VALID_E_POINT_CHECK_VOID(ptSnInfo);

    // Set all members of the MRDC SNInfo structure to their default values
    memset(ptSnInfo, 0x00, sizeof(SNInfo_type));

    // Set the endpoint index to its maximum value
    ptSnInfo->epIdx = MAX_XN_NBR_PER_GNB;

    // Set the neighbor index to its maximum value
    ptSnInfo->nbrIdx = MAX_NBR_PER_CELL;
}

/**
 * @brief   VLIB_AllocMrdcInfo
 */

int16_t VLIB_AllocMrdcInfo(callInfo_type *ptCi, enumMrdcUeCtxType_type ueCtxType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    /*
    T.B.D
    if (ptCi->pMrdcInfo) {
        VLIB_ReleaseMrdcInfo(ptCi);
    }

    ptCi->pMrdcInfo = VLIB_AllocPoolInfo(...);
*/
    // This is proctection code to avoid the leakage of NRSC_SN_CONN_INFO Stats.
    // FGR-CC5200:FR760 FR770
    //FnVCCB_NrdcSnConnInfoStatsCmd(ptCi, ptCi->servCellNum, ConnInfoStatsCmd_HoldingTimeStop); // can't guarantee the valid holdingTime
    if (ptCi->mrdcInfo.stat.nrdcSnConnInfo.connNoAvgUpdatedFlag)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ConnInfoStatsCmd_Decrease is forced to execute in %s!!!\n", __func__);
        FnVCCB_NrdcSnConnInfoStatsCmd(ptCi, ptCi->servCellNum, ConnInfoStatsCmd_Decrease);
    }

    memset(&ptCi->mrdcInfo, 0, sizeof(ptCi->mrdcInfo));

    ptCi->mrdcInfo.usage = CI_use;
    ptCi->mrdcInfo.ueCtxType = ueCtxType;

    ptCi->mrdcInfo.mobilityCfg.ueState = ci_scg_config_ue;

    FnVCCB_InitMrdcSnInfo(&ptCi->mrdcInfo.SNInfo[SRC_SN]);
    FnVCCB_InitMrdcSnInfo(&ptCi->mrdcInfo.SNInfo[TGT_SN]);

    FnVCCB_InitMrdcMnInfo(&ptCi->mrdcInfo.MNInfo[SRC_MN]);
    FnVCCB_InitMrdcMnInfo(&ptCi->mrdcInfo.MNInfo[TGT_MN]);

    return GOOD;
}

/**
 * @brief : This function updates the bearer type again.
 */
void FnVCCB_ReUpdateBearerType(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    int32_t bearerType = MN_Term_MCG_Bearer;
    int32_t selectedBearerType = MN_Term_MCG_Bearer;

    callDRBInfo_type *ptDi = NULL;
    int drbIdx = 0;

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        ptDi = &ptCi->drb[drbIdx];

        if (ptDi->usage != CI_use) continue;

        if (ptDi->pduIdxInCall >= MAX_PDU_SESS_PER_CALL) continue;

        bearerType = static_cast<int32_t>(ptDi->bearerType.val);

        // update the selectedBearerTypeFrozenFlag for inter MN mobility (requirement from basic feature)
        if (ptDi->selectedBearerTypeFrozenFlag != TRUE)
        {
            switch (bearerType)
            {
                case SN_Term_SCG_Bearer:
                case SN_Term_SPLIT_Bearer:
                case SN_Term_MCG_Bearer: // Not Supported
                    //selectedBearerType = SN_Term_Undetermined;  // bearerType is decided from SN side (basic design)
                    selectedBearerType = SN_Term_Default_Bearer;  // bearerType is decided from SN side (basic design)
                    // tempCode for FnVCCB_WillAllQosflowsOfSNTermBeCleared(basic design)
                    FnVCCB_SetSDAPatSNFlagOfQosFlow(ptCi, ptDi, VCCB_FLAG_ON);
                    break;
                default:
                    selectedBearerType = bearerType;
                    break;
            }

            SET_MRDC_SELECTED_BEARER(ptCi, ptDi, TRUE, selectedBearerType);
        }
        // *********************

        SET_MRDC_REQ_BEARER_STATUS(ptCi, ptDi, bearerType);
    }
}

// This function attempts to change only the information mapped to CALL.
void FnVCCB_UpdateCallInfoForHandover_SnRelease(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    ptCi->mrdcInfo.mobilityCfg.ueState = ci_scg_released_ue;

    ptCi->hoInfo.sgnbAddTrigInd = SgnbAddTrigInd_Unknown;  // SA, NR/NEDC-MN

    OFF_MRDC_XN_RCVINDICATOR_FLAG(scgCellGrpCfg);
    OFF_MRDC_XN_RCVINDICATOR_FLAG(scgRBCfg);
}

// This function attempts to change the DRB of CALL.
void FnVCCB_UpdateBearerTypeForHandover_SnRelease(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t drbIdx;
    int32_t bearerType = MN_Term_MCG_Bearer;
    callDRBInfo_type *ptDi;

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        ptDi = &ptCi->drb[drbIdx];
        if (ptDi->usage != CI_use) continue;
        if (ptDi->pduIdxInCall >= MAX_PDU_SESS_PER_CALL) continue;

        bearerType = static_cast<int32_t>(ptDi->bearerType.val);

        SET_MRDC_REQ_BEARER_STATUS(ptCi, ptDi, MN_Term_MCG_Bearer);

        if (ptDi->drbStatus == S_Null)
        {
            /* need to drbStatus as setup */
        }
        else
        {
            // skip partial bearer
            if (VLIB_IsCommonValidStateOfPduQosDrb(ptDi->drbStatus) != GOOD) continue;
        }

        // TODO: set S_Setup for S_Null (SN bearer) ??
        // need to check the SN release procedures....
        // TODO: how to set for..... DU...
        switch (bearerType)
        {
            case MN_Term_SPLIT_Bearer:
                if(DBG->flag.SNAdditionRejectE1Mod)   //Default is ON
                {
                    if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTER_NB && ptCi->hoInfo.isTarget == TRUE)
                    {
                        // Change MN_Term_Split_Bearer status to S_Modify only when PDU Status is Modify
                        // MN_SPlit drb will not be setup when F1 Setup after SN Release during interDU H/O.
                        if (ptCi->pduSess[ptDi->pduIdxInCall].pduSessStatus == S_Modify)
                        {
                            SET_DRB_STATUS(ptCi, drbIdx, S_Modify);
                        }
                    }
                }
                break;
            //case SN_Term_Undetermined:
            case SN_Term_SCG_Bearer:
            case SN_Term_SPLIT_Bearer:
                switch (ptDi->drbStatus)
                {
                    case S_Null:
                    case S_Idle:
                        SET_DRB_STATUS(ptCi, drbIdx, S_Setup);
                        break;
                    default:
                        break;
                }

                // TODO: In case of partial PDU, additional processing condition is required

                if (FnVCCB_DoesPDUSessExistAtMN(ptCi, ptDi->pduIdxInCall))
                {
                    SET_PDU_STATUS(ptCi, ptDi->pduIdxInCall, S_Modify);
                }
                else
                {
                    SET_PDU_STATUS(ptCi, ptDi->pduIdxInCall, S_Setup);
                }
                break;
            default:
                break;
        }
    }
}

/**
 * @brief : FnVCCB_UpdateBearerTypeForHandover : This function is used in the Target-gNB of the Inter-gNB and stores
 * MR-DC information of the hand-in UE.
 */
int16_t FnVCCB_UpdateBearerTypeForHandover(callInfo_type *ptCi, enumMrdcHoScenario_type type)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (!IsAvailable_MrdcInfo())
    {
        return GOOD;
    }

    if (!VHCM_isSaHandoverUE(ptCi))
    {
        goto SN_RELEASE;
    }

    // WO SN Change
    if (type == MrdcHoWithoutSnChange)
    {
        FnVCCB_ReUpdateBearerType(ptCi);

        ptCi->mrdcInfo.mobilityCfg.ueState = ci_scg_config_ue;

        if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
            ptCi->hoInfo.sgnbAddTrigInd = SgnbAddTrigInd_IntraMnHo;  // SA, NR/NEDC-MN
        else
            ptCi->hoInfo.sgnbAddTrigInd = SgnbAddTrigInd_InterMnHo;  // SA, NR/NEDC-MN

        // update AMBR for inter gnb handover
        FnVCCB_ReproduceUeAMBRforMRDC(ptCi);
        FnVCCB_ReproduceUeSliceMBRforMRDC(*ptCi);

        return GOOD;
    }

    // With SN Change
    if (type == MrdcHoWithSnChange)
    {
        FnVCCB_ReUpdateBearerType(ptCi);

        ptCi->mrdcInfo.mobilityCfg.ueState = ci_scg_config_ue;

        if (ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_SGNB_INITIATED_INTER_SN_CHANGE)  // SN Init Mobility
        {
            ptCi->hoInfo.sgnbAddTrigInd = SgnbAddTrigInd_SnChange;  // SA, NR/NEDC-MN
        }
        else  // MN Init Mobility
        {
            if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
                ptCi->hoInfo.sgnbAddTrigInd = SgnbAddTrigInd_IntraMnHo;  // SA, NR/NEDC-MN
            else
                ptCi->hoInfo.sgnbAddTrigInd = SgnbAddTrigInd_InterMnHo;  // SA, NR/NEDC-MN
        }

        // update AMBR for inter gnb handover
        FnVCCB_ReproduceUeAMBRforMRDC(ptCi);
        FnVCCB_ReproduceUeSliceMBRforMRDC(*ptCi);

        return GOOD;
    }

SN_RELEASE:
    // SN release
    // if (type == MrdcHoWithSnRelease) or else
    {
        FnVCCB_UpdateBearerTypeForHandover_SnRelease(ptCi);

        FnVCCB_UpdateCallInfoForHandover_SnRelease(ptCi);

        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger SN Release(Bearer Change), MR-DC UE -> SA UE.\n");
        
        if (VCCB_FLAG_ON == ptCi->ueInfo.sliceMbrInfo.isSliceMBRListProvided)
        {
            FnVCCB_ClearUeSliceMBRforNRDC(*ptCi);
            ptCi->ueInfo.sliceMbrInfo.fNeedModifySN = VCCB_FLAG_OFF;
        }
    }

    return GOOD;
}

/**
 * @brief : VLIB_AllocMrdcInfoForHandover : This function is used in the Target-gNB of the Inter-gNB and stores MR-DC
 * information of the hand-in UE.
 */
int16_t VLIB_AllocMrdcInfoForHandover(callInfo_type *ptCi, enumMrdcUeCtxType_type ueCtxType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // 1) When ueCtxtType allows update, only the case of 'UECTX_NONE' is allowed.
    if (IsAvailable_MrdcInfo())
    {
        if (ptCi->mrdcInfo.ueCtxType == UECTX_NONE)
        {
            ptCi->mrdcInfo.ueCtxType = ueCtxType;
        }

        return GOOD;
    }

    // 2) Called only when alloc is made first among'NRRRC Handover Preparation' or'XN Handover Request'.

    // It is defined as an MR-DC UE.
    int16_t status = VLIB_AllocMrdcInfo(ptCi, ueCtxType);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VLIB_AllocMrdcInfo ERROR!\n");

    if (!IsAvailable_MrdcInfo())
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "false, IsAvailable_MrdcInfo!!\n");

        return ERROR;
    }

    ptCi->mrdcInfo.SNInfo[SRC_SN].epIdx = XNIDX_FOR_UNKNOWN_SN;
    ptCi->mrdcInfo.SNInfo[TGT_SN].epIdx = XNIDX_FOR_UNKNOWN_SN;

    return GOOD;
}

/**
 * @brief : This function starts the DC resource allocation by referring to the IE of the XNAP HO Request.
 */
void FnVCCB_XNAP_HandoverRequest_DecisionMrdcUE(callInfo_type *ptCi, XN_HandoverRequest_type *ptMsg)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptMsg);

    if (ptMsg->m.uEContextRefAtSNHORequestPresent == OPT_NOT_PRESENT)
    {
        return;
    }

    switch (ptMsg->uEContextRefAtSN_HORequest.globalNG_RANNode_ID.choice)
    {
        case XNAP_GlobalNG_RANNode_ID_gNB_chosen:
            VCCB_PRINT_CALL_COMMENT(ptCi, "- exist RAN-Node-ID : GNB (NR-DC).\n");
            VLIB_AllocMrdcInfoForHandover(ptCi, UECTX_NRDC_MN);
            FnVCCB_SetSelectedMrdcType(ptCi, ptCi->servCellNum, MRDC_NRDC);

            break;
        case XNAP_GlobalNG_RANNode_ID_ng_eNB_chosen:
            VCCB_PRINT_CALL_COMMENT(ptCi, "- exist RAN-Node-ID : ENB (NE-DC).\n");
            VLIB_AllocMrdcInfoForHandover(ptCi, UECTX_NEDC_MN);
            FnVCCB_SetSelectedMrdcType(ptCi, ptCi->servCellNum, MRDC_NEDC);
            break;
        default:
            VCCB_PRINT_CALL_COMMENT(ptCi, "- exist RAN-Node-ID : Unknown(%d).\n",
                ptMsg->uEContextRefAtSN_HORequest.globalNG_RANNode_ID.choice);
            VLIB_AllocMrdcInfoForHandover(ptCi, UECTX_NONE);
            FnVCCB_SetSelectedMrdcType(ptCi, ptCi->servCellNum, MRDC_NONE);
            break;
    }

    // 9. O - UE Context Reference at the S-NG-RAN node in XN Handover Request
    FnVCCB_XNAP_UEContextRefAtSN_HORequest(ptCi, &ptMsg->uEContextRefAtSN_HORequest);
}

/**
 * @brief : This function starts the DC resource allocation by referring to the IE of the NRRRC AS Config.
 */
void FnVCCB_NRRRC_AsConfig_DecisionMrdcUE(callInfo_type *ptCi, NRRRC_AS_Config *p)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    if (p->bit_mask & NRRRC_sourceSCG_NR_Config_present)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "- exist sourceSCG_NR_Config (NR-DC).\n");
        VLIB_AllocMrdcInfoForHandover(ptCi, UECTX_NRDC_MN);

        return;
    }

    if (p->bit_mask & NRRRC_sourceSCG_EUTRA_Config_present)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "- exist sourceSCG_EUTRA_Config (NE-DC).\n");
        VLIB_AllocMrdcInfoForHandover(ptCi, UECTX_NEDC_MN);

        return;
    }

    if (p->bit_mask & NRRRC_sourceSCG_Configured_present)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "- exist sourceSCG_Configured (Unknown, %d).\n", p->sourceSCG_Configured);
        VLIB_AllocMrdcInfoForHandover(ptCi, UECTX_NONE);

        return;
    }
}

void FnVCCB_Mrdc_FreeBuffer_octetString(callInfo_type *ptCi, octetStringType *ptOct)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptOct);

    if (FnVCCB_CheckValid_octetString(ptOct))
    {
        VCCB_MRDC_FREE_BUFFER(ptCi, (char *)ptOct->value);
        ptOct->value = NULL;
        ptOct->length = 0;
    }
}

void FnVCCB_Mrdc_Init_octetString(callInfo_type *ptCi, octetStringType *ptOct)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptOct);

    if (!ptCi->loadBasedNrdcScgBandSelectInfo.usage && !IsAvailable_MrdcInfo())  // Silent Ignore
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "IsAvailable_MrdcInfo() == false in %s!\n", __func__);
        return;
    }

    /* If exists data, Clear DB */
    FnVCCB_Mrdc_FreeBuffer_octetString(ptCi, ptOct);

    /* Init Value, forced Init */
    ptOct->value = NULL;
    ptOct->length = 0;
}

int16_t FnVCCB_Mrdc_Store_octetString(
    const char *ptFunc, callInfo_type *ptCi, octetStringType *ptDestOct, const NRRRC__octet1 *ptSrcOctet)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptFunc);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDestOct);
    VALID_E_POINT_CHECK_ERROR(ptSrcOctet);

    if (!ptCi->loadBasedNrdcScgBandSelectInfo.usage && !IsAvailable_MrdcInfo())  // Silent Ignore
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "IsAvailable_MrdcInfo() == false in %s!\n", __func__);

        return GOOD;
    }

    FnVCCB_Mrdc_Init_octetString(ptCi, ptDestOct);

    ptDestOct->value = (unsigned char *)VLIB_GetBuffer(ptCi, ptSrcOctet->length, VCCB_FLAG_OFF);
    if (NULL == ptDestOct->value)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Fail, VLIB_GetBuffer in %s!\n", ptFunc);

        return ERROR;
    }

    memcpy(ptDestOct->value, ptSrcOctet->value, ptSrcOctet->length);
    ptDestOct->length = (uint16_t)ptSrcOctet->length;

    return GOOD;
}

int16_t FnVCCB_Mrdc_Fill_octetString(NRRRC__octet1 *ptDestOct, const octetStringType *ptSrcOctet)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptDestOct);
    VALID_E_POINT_CHECK_ERROR(ptSrcOctet);

    if (FnVCCB_CheckValid_octetString(ptSrcOctet) == false)
    {
        return ERROR;
    }

    ptDestOct->length = (unsigned int)ptSrcOctet->length;
    ptDestOct->value = ptSrcOctet->value;

    return GOOD;
}

// scgCellGrpConfig
int16_t VLIB_CheckValid_MrdcScgCellGrpConfig(mrdcInfo_type *pMrdcInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pMrdcInfo);

    int16_t status = FnVCCB_CheckValid_octetString(&pMrdcInfo->scgCellGrpConfig);

    return status;
}
void VLIB_Init_MrdcScgCellGrpConfig(callInfo_type *ptCi, mrdcInfo_type *pMrdcInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pMrdcInfo);

    FnVCCB_Mrdc_Init_octetString(ptCi, &pMrdcInfo->scgCellGrpConfig);
}
int16_t VLIB_Store_MrdcScgCellGrpConfig(callInfo_type *ptCi, mrdcInfo_type *pMrdcInfo, NRRRC__octet1 *pSrcOctet)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMrdcInfo);
    VALID_E_POINT_CHECK_ERROR(pSrcOctet);

    int16_t status = FnVCCB_Mrdc_Store_octetString(__func__, ptCi, &pMrdcInfo->scgCellGrpConfig, pSrcOctet);
    if (status != GOOD)
    {
        return status;
    }

    ON_MRDC_XN_RCVINDICATOR_FLAG(scgCellGrpCfg);

    return GOOD;
}
int16_t VLIB_Fill_MrdcScgCellGrpConfig(mrdcInfo_type *pMrdcInfo, NRRRC__octet1 *pTgtOctet)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pMrdcInfo);
    VALID_E_POINT_CHECK_ERROR(pTgtOctet);

    int16_t status = FnVCCB_Mrdc_Fill_octetString(pTgtOctet, &pMrdcInfo->scgCellGrpConfig);

    return status;
}

// scgRBConfig - TODO : Duplicated Code
int16_t FnVCCB_CheckValid_MrdcSNRBConfig(mrdcInfo_type *pMrdcInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pMrdcInfo);

    int16_t status = FnVCCB_CheckValid_octetString(&pMrdcInfo->scgRBConfig);

    return status;
}
int16_t FnVCCB_Store_MrdcScgRBConfig_ForPack(callInfo_type *ptCi, NRRRC__octet1 *pSrcOctet)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pSrcOctet);

    int16_t status = FnVCCB_Mrdc_Store_octetString(__func__, ptCi, &ptCi->mrdcInfo.scgRBConfig, pSrcOctet);

    return status;
}
int16_t FnVCCB_Store_NrdcScgRBConfig(callInfo_type *ptCi, NRRRC__seq118 *pSrcOctet)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pSrcOctet);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    if (!IsAvailable_MrdcInfo())  // Silent Ignore
    {
        return BREAK;
    }

    if (!pSrcOctet->value || !pSrcOctet->length)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR, Invalid value data(%p) for scgRBConfig OctetString!\n", pSrcOctet->value);

        return ERROR;
    }

    NRRRC__octet1 octet;
    octet.value = pSrcOctet->value;
    octet.length = pSrcOctet->length;

    int16_t status = FnVCCB_Mrdc_Store_octetString(__func__, ptCi, &ptCi->mrdcInfo.scgRBConfig, &octet);
    if (status != GOOD)
    {
        return status;
    }

    ON_MRDC_XN_RCVINDICATOR_FLAG(scgRBCfg);

    return GOOD;
}

int16_t FnVCCB_Fill_MrdcscgRBConfig(mrdcInfo_type *pMrdcInfo, NRRRC__octet1 *pTgtOctet)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pMrdcInfo);
    VALID_E_POINT_CHECK_ERROR(pTgtOctet);

    int16_t status = FnVCCB_Mrdc_Fill_octetString(pTgtOctet, &pMrdcInfo->scgRBConfig);

    return status;
}

void VLIB_FreeBuffAllMrdcInfo(callInfo_type *ptCi, int printLevel)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    mrdcInfo_type *pMrdcInfo = &ptCi->mrdcInfo;
    VALID_E_POINT_CHECK_VOID(pMrdcInfo);

    union
    {
        struct
        {
            uint16_t candidateCellInfoListMN   : 1;
            uint16_t candidateCellInfoListSN   : 1;
            uint16_t scgCellGrpConfig          : 1;
            uint16_t scgRBConfig               : 1;
            uint16_t measResultSCG_EUTRA       : 1;
            uint16_t uLInformationTransferMRDC : 1;
        } u;
        uint16_t bitmask;
    } b;

    b.bitmask = 0;

    b.u.candidateCellInfoListMN = (pMrdcInfo->candidateCellInfoListMN.length > 0 ? 1 : 0);
    b.u.candidateCellInfoListSN = (pMrdcInfo->candidateCellInfoListSN.length > 0 ? 1 : 0);
    b.u.scgCellGrpConfig = (pMrdcInfo->scgCellGrpConfig.length > 0 ? 1 : 0);
    b.u.scgRBConfig = (pMrdcInfo->scgRBConfig.length > 0 ? 1 : 0);
    b.u.measResultSCG_EUTRA = (pMrdcInfo->measResultSCG_EUTRA.length > 0 ? 1 : 0);
    b.u.uLInformationTransferMRDC = (pMrdcInfo->uLInformationTransferMRDC.length > 0 ? 1 : 0);

    FnVCCB_Mrdc_Init_octetString(ptCi, &pMrdcInfo->candidateCellInfoListMN);
    FnVCCB_Mrdc_Init_octetString(ptCi, &pMrdcInfo->candidateCellInfoListSN);
    FnVCCB_Mrdc_Init_octetString(ptCi, &pMrdcInfo->scgCellGrpConfig);
    FnVCCB_Mrdc_Init_octetString(ptCi, &pMrdcInfo->scgRBConfig);
    FnVCCB_Mrdc_Init_octetString(ptCi, &pMrdcInfo->measResultSCG_EUTRA);
    FnVCCB_Mrdc_Init_octetString(ptCi, &pMrdcInfo->uLInformationTransferMRDC);

    if (b.bitmask && ptCi->state == STATE_Conn)
    {
        switch (printLevel)
        {
            case PL_CMD ... PL_ERROR:
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "MrdcInfo is initialized with bitmask(%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c) in %s\n",
                    TWO_BYTE_TO_BINARY(b.bitmask), __FUNCTION__);
                break;
            case PL_MSG ... PL_COMMENT:
                VCCB_PRINT_CALL_COMMENT(ptCi,
                    "MrdcInfo is initialized with bitmask(%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c) in %s\n",
                    TWO_BYTE_TO_BINARY(b.bitmask), __FUNCTION__);
                break;
            default:
                break;
        }
    }
}

void FnVCCB_SetSDAPatSNFlagOfQosFlow(callInfo_type *ptCi, callDRBInfo_type *pDi, uint8_t flag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pDi);

    qosFlowInfo_type *pQi = NULL;
    uint16_t loopIdx = 0, qosFlowIndex = 0;

    for (loopIdx = 0; loopIdx < MAX_QOS_FLOW_PER_DRB; loopIdx++)
    {
        qosFlowIndex = pDi->qosFlowIndex[loopIdx];
        if (qosFlowIndex >= MAX_QOS_FLOW_PER_CALL) continue;

        pQi = &ptCi->qosFlow[qosFlowIndex];

        if (pQi->usage != CI_use) continue;

        pQi->isSDAPatSN = flag & 1;
    }
}

// for NEDC, NRDC
void VLIB_InitMrdcBearerType(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t drbIdx = 0;

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        callDRBInfo_type *ptDi = &ptCi->drb[drbIdx];

        if (ptDi->usage != CI_use)
        {
            continue;
        }

        ptDi->reqBearerType.val = INIT_BEARER_TYPE;
        ptDi->bearerType.val = MN_Term_MCG_Bearer;

        ptDi->snDrbStatus = S_BEARER_STATUS_END;

        FnVCCB_SetSDAPatSNFlagOfQosFlow(ptCi, ptDi, VCCB_FLAG_OFF);
    }
}

void VLIB_ReleaseMrdcInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // This is proctection code to avoid the leakage of NRSC_SN_CONN_INFO Stats.
    // FGR-CC5200:FR760 FR770
    Stopwatch_type &stopwatch = ptCi->mrdcInfo.stat.nrdcSnConnInfo.holdingTimeStopWatch;
    if (stopwatch.isRunning)
    {
        FnVCCB_NrdcSnConnInfoStatsCmd(ptCi, ptCi->servCellNum, ConnInfoStatsCmd_HoldingTimeStop);
    }

    if (ptCi->mrdcInfo.stat.nrdcSnConnInfo.connNoAvgUpdatedFlag)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ConnInfoStatsCmd_Decrease is forced to execute in %s!!!\n", __func__);
        FnVCCB_NrdcSnConnInfoStatsCmd(ptCi, ptCi->servCellNum, ConnInfoStatsCmd_Decrease);
    }

    FnVCCB_ClearInstantFlagOfMrdcInfo(ptCi);

    VLIB_FreeBuffAllMrdcInfo(ptCi, PL_COMMENT);

    // Reset the SN CID Allocation.
    ptCi->ueInfo.roHCCapability.curAllocatedSNRohcCid = 0;

    ptCi->mrdcInfo.usage = CI_no_use;

    ptCi->mrdcInfo.rscSetupFlag.value = 0;
    ptCi->mrdcInfo.mobilityCfg.value = 0;
    ptCi->mrdcInfo.selectedBC.bandCombinationIndex = 0;
    ptCi->mrdcInfo.selectedBC.requestedFeatureSets = 0;
    ptCi->mrdcInfo.selectedBC.prevBandCombinationIndex = 0;
    ptCi->mrdcInfo.selectedBC.prevRequestedFeatureSets = 0;
}

void VLIB_InitMrdcProperty(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!IsAvailable_MrdcInfo())
    {
        VCCB_PRINT_ERROR("!IsAvailable_MrdcInfo() ERROR, in %s!!\n", __FUNCTION__);

        return;
    }

    RESET_NRDC_SCG_FAILINFO(ptCi);

    FnVCCB_UpdateNrdcMnCsl(*ptCi, NRDC_CSL_UPDATE_REL); //SVR26A:FGR-CC5200:FR1080,FR1081

    VLIB_ReleaseMrdcInfo(ptCi);
    VLIB_InitMrdcBearerType(ptCi);
    // Clear measuredFrequenciesSN received from SN
    ptCi->measurementsConfigShared.mGapConfiguration.freqSnNew.numItems = 0;

    for (int idx = 0; idx < MAX_DRB_PER_SA_CALL; idx++)
    {
        callDRBInfo_type *pDi = &ptCi->drb[idx];

        if (pDi->usage != CI_use) continue;

        //pDi->needSnTermSplitMcgLegTobeSetup = VCCB_FLAG_OFF;
        //pDi->snTermSplitFlag = VCCB_FLAG_OFF;

        memset(&pDi->xNuDlInfo, 0, sizeof(pDi->xNuDlInfo));
        memset(&pDi->xNuUlInfo, 0, sizeof(pDi->xNuUlInfo));
    }

    for (int pdusessIdx = 0; pdusessIdx < MAX_PDU_SESS_PER_CALL; pdusessIdx++)
    {
        callPDUSessInfo_type *pPi = &ptCi->pduSess[pdusessIdx];

        if (pPi->usage != CI_use) continue;

        memset(&pPi->snNGuDlInfo, 0, sizeof(pPi->snNGuDlInfo));
        memset(&pPi->snNGuUlInfo, 0, sizeof(pPi->snNGuUlInfo));
    }
}

// Move XnapMake.cpp to FeatMRDC.c
// This api will be called by MN when sends SNodeAddition/SNodeModification Request to SN if new PDUSession is to be
// added in SN
void FnVCCB_InitSnNGuUlInfo(callInfo_type *ptCi, callPDUSessInfo_type *pPi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pPi);

    if (pPi->usage == CI_use)
    {
        pPi->snNGuUlInfo = pPi->nGuUlInfo;
    }
}

// this api shall be called at SN
bool FnVCCB_NeedSNTermBearerTobeAddModRelSN(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    uint16_t idx = 0;
    for (idx = 0; idx < MAX_DRB_PER_SA_CALL; idx++)
    {
        callDRBInfo_type *pDi = &ptCi->drb[idx];

        if (pDi->usage != CI_use) continue;
        if (!pDi->selectedBearerTypeFrozenFlag) continue;

        //if (pDi->terminationPoint == SN_Terminated &&
        if (pDi->bearerType.termPoint == TermPoint_Sn &&
            (pDi->drbStatus == S_Setup || pDi->drbStatus == S_Modify || pDi->drbStatus == S_Release))
        {
            return true;
        }
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "not found for SNTermBearerTobeAddModRel!\n");

    return false;
}

/**
 * @brief : VLIB_IsAllowedEutraCellforPLMN ()
 */
bool VLIB_IsAllowedEutraCellforPLMN(callInfo_type *ptCi, nbrEnbCellInfo_type *eutranCell, hoRestrictInfo_type *ptHrl)
{
    AUTO_TRACE_FUNC;

    if (!(ptCi && eutranCell && ptHrl))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Null Point error (ptCi:%p, eutranCell:%p, ptHrl:%p)!!\n", ptCi, eutranCell, ptHrl);

        // return false;
        return true;
    }

    // uint32_t tac = (uint32_t)eutranCell->tac;

    if (eutranCell->plmn.longId != ptHrl->servedPlmn.longId)
    {
        int eplmnIdx = 0, maxIdx = (int)(UMIN(X2_maxnoofEPLMNs, (uint32_t)ptHrl->numEplmn));

        for (eplmnIdx = 0; eplmnIdx < maxIdx; eplmnIdx++)
        {
            if (eutranCell->plmn.longId == ptHrl->ePlmn[eplmnIdx].longId)
            {
                break;
            }
        }

        if (eplmnIdx >= maxIdx)
        {
            return false;
        }
    }

    // if (true == VLIB_IsForbidden5GcTAC(ptCi, ptHrl, &eutranCell->plmn, tac))
    // {
    //
    //     return false;
    // }

    return true;
}

/**
 * @brief : VLIB_IsForbidden5GcTAC ()
 */
// bool VLIB_IsForbidden5GcTAC(callInfo_type *ptCi, hoRestrictInfo_type *ptHrl, plmnId_type *pPlmn, uint32_t tac)
// {
//     /* In NEDC, this api is holden until eutra-nbr has the 3bytes-Tac.
//        If eNB supports 5GC, the Tac 3bytes-Tac should be applied. */
//     AUTO_TRACE_FUNC;
//
//     UNUSED4(ptCi, ptHrl, pPlmn, tac);
//
//
//     return false;
//
//     //////////////////////////////////////////////////////////////////////////////////
//     uint16_t taIdx;
//
//     if (!(ptCi && ptHrl && pPlmn))
//     {
//         VCCB_PRINT_CALL_ERROR(ptCi, "Null Point error (ptCi:%p, ptHrl:%p, pPlmn:%p)!!\n", ptCi, ptHrl, pPlmn);
//
//         return false;
//     }
//
//     for (taIdx = 0; taIdx < MIN(ptHrl->numForbidTaPlmn, X2_maxnoofEPLMNsPlusOne); taIdx++)
//     {
//         if (ptHrl->forbiddenTA[taIdx].plmn.longId != pPlmn->longId)
//         {
//             continue;
//         }
//
//         // ptHrl->forbiddenTA are sorted in ascending order
//         if (NULL != bsearch(&tac, ptHrl->forbiddenTA[taIdx].fiveGTac,
//                             MIN(ptHrl->forbiddenTA[taIdx].numTac, NG_MaxnoofForbTACs), sizeof(uint32_t),
//                             VLIB_QsortUint32AscendingOrder))
//         {
//             VCCB_PRINT_COMMENT("Found forbiddenTA(0x%x) in %s\n", tac, __FUNCTION__);
//
//             return true;
//         }
//     }
//
//
//     return false;
// }

/**
 * @brief : VLIB_StoreBestMeasResultEutraCGI ()
 */
void VLIB_StoreBestMeasResultEutraCGI(
    callInfo_type *ptCi, measResultEUTRA_type *ptBestMeasResultEUTRA, nbrEnbCellInfo_type *pBestEnbCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptBestMeasResultEUTRA);
    VALID_E_POINT_CHECK_VOID(pBestEnbCell);

    ptBestMeasResultEUTRA->cgiInfoFlag = TRUE;
    ptBestMeasResultEUTRA->cgiInfo.cgi_info_EPC_Flag = TRUE;
    ptBestMeasResultEUTRA->cgiInfo.cgi_info_EPC.cgi_info_EPC_legacy.plmn_IdentityList_eutra_epc.nrofPLMN_Identity = 1;
    ptBestMeasResultEUTRA->cgiInfo.cgi_info_EPC.cgi_info_EPC_legacy.plmn_IdentityList_eutra_epc.plmn_Identity[0]
        .longId = pBestEnbCell->plmn.longId;
    ptBestMeasResultEUTRA->cgiInfo.cgi_info_EPC.cgi_info_EPC_legacy.trackingAreaCode_eutra_epc = pBestEnbCell->tac;

    // [TODO] ECI would be made with dependency to the type of enb.
    // By default, the macroType is used in the current implementation.
    ptBestMeasResultEUTRA->cgiInfo.cgi_info_EPC.cgi_info_EPC_legacy.cellIdentity_eutra_epc =
        (pBestEnbCell->enbId << 8 | pBestEnbCell->cellId);

    VCCB_PRINT_CALL_COMMENT(ptCi, "enbId(%llu), bestEnbCell(%u), ECI(%u), longId(%u) is set in %s\n",
        1ULL * pBestEnbCell->enbId, pBestEnbCell->cellId,
        ptBestMeasResultEUTRA->cgiInfo.cgi_info_EPC.cgi_info_EPC_legacy.cellIdentity_eutra_epc,
        pBestEnbCell->plmn.longId, __FUNCTION__);
}

// NRDC
void FnVCCB_StoreBestMeasResultNRCGI(
    callInfo_type *ptCi, measResultNR_type *pBestMeasResultNR, nbrGnbCellInfo_type *pBestGnbCellInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pBestMeasResultNR);
    VALID_E_POINT_CHECK_VOID(pBestGnbCellInfo);

    pBestMeasResultNR->cgiInfoFlag = TRUE;
    pBestMeasResultNR->cgiInfo.plmn_IdentityInfoList_Flag = TRUE;
    pBestMeasResultNR->cgiInfo.plmn_IdentityInfoList.nrofPLMN_IdentityInfo = 1;
    PLMN_IdentityInfo_type *pPlmn_IdentityInfo = &pBestMeasResultNR->cgiInfo.plmn_IdentityInfoList.plmn_IdentityInfo[0];
    pPlmn_IdentityInfo->plmn_IdentityList.nrofPLMN_Identity = 1;
    pPlmn_IdentityInfo->plmn_IdentityList.plmn_Identity[0].longId = pBestGnbCellInfo->cellPlmnInfo[0].longId;
    pPlmn_IdentityInfo->cellIdentity =
        VLIB_GnbIdCellId2NrCellId(&pBestGnbCellInfo->globalGnbId.gnbId, pBestGnbCellInfo->cellId);
    pPlmn_IdentityInfo->cellReservedForOperatorUse = NRRRC_notReserved;
}

int FnVCCB_IsAllowedEarfcnforAllowedBCList_Proc(callInfo_type *ptCi, uint16_t bitMapIdx, uint16_t bitOffset)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    const uint16_t maxDbIdx = GET_ARR_SIZE(ptCi->ueInfo.allowedBCListEutraBandIndiBitMap);
    if (bitMapIdx >= maxDbIdx)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid bitMapIdx(%u) vs maxDbIdx(%u)!!\n", bitMapIdx, maxDbIdx);

        return false;
    }

    if (ptCi->ueInfo.allowedBCListEutraBandIndiBitMap[bitMapIdx] & (1 << bitOffset))
    {
        return true;
    }

    return false;
}

/**
 * @brief : VLIB_IsAllowedEarfcnforAllowedBCList ()
 */
bool VLIB_IsAllowedEarfcnforAllowedBCList(callInfo_type *ptCi, uint32_t earfcnDl)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    uint16_t bandInd = 0, bitMapIdx = 0, bitOffset = 0;
    bool res = false;

    bandInd = GetEutraBandIndicatorByEARFCN(earfcnDl);
    if (!bandInd || bandInd > NRRRC_maxBandsEUTRA)
    {  // 3GPP. FreqBandIndicatorEUTRA : 1..maxBandsEUTRA(256)

        return false;
    }

    bitMapIdx = bandInd / 8;
    bitOffset = bandInd % 8;

    res = FnVCCB_IsAllowedEarfcnforAllowedBCList_Proc(ptCi, bitMapIdx, bitOffset);

    return res;
}

bool FnVCCB_IsAllowedNrBandforAllowedBCList(callInfo_type *ptCi, uint16_t bandInd)
{
    AUTO_TRACE_FUNC;

    uint16_t bitMapIdx = 0, bitOffset = 0;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    uint16_t maxDbIdx =
        sizeof(ptCi->ueInfo.allowedBCListNrBandIndiBitMap) / sizeof(ptCi->ueInfo.allowedBCListNrBandIndiBitMap[0]);
    bitMapIdx = bandInd / 8;
    bitOffset = bandInd % 8;

    if (bitMapIdx >= maxDbIdx)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid NR bitMapIdx(%u) vs maxDbIdx(%u)!!\n", bitMapIdx, maxDbIdx);

        return false;
    }

    if (ptCi->ueInfo.allowedBCListNrBandIndiBitMap[bitMapIdx] & (1 << bitOffset))
    {
        return true;
    }

    return false;
}
/**
 * @brief Check if bearer parameters need to be modified during XN modification
 * @param[in] ptDrb: Pointer of drb
 * @return TRUE, FALSE
 */
uint8_t VLIB_checkXN_SnNeedModify_AfterBearerMod(callDRBInfo_type *ptDrb)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptDrb);
    if ((ptDrb->usage != CI_use) ||
        ((ptDrb->bearerType.val != MN_Term_SPLIT_Bearer) && (ptDrb->selectedBearerType.val != MN_Term_SPLIT_Bearer)))
    {
        return FALSE;
    }

    if ((S_Setup == ptDrb->snDrbStatus) || (S_Modify == ptDrb->snDrbStatus) || (S_Release == ptDrb->snDrbStatus) ||
        (ptDrb->ulPdcpPath != ptDrb->ulPdcpPathPrev))
    {
        return TRUE;
    }

    return FALSE;
}

/*****************************************************************************
 * @brief : VLIB_IsSNModificationRequired ()
 * Function responsible for validation if NEDC modify procedure should be performed
 * @param[in/out]   ptCi :      Call information / callInfo_type
 * @return          status :    true/false bool
 ****************************************************************************/
bool VLIB_IsSNModificationRequired(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    uint8_t drbIdx = 0;
    uint8_t numSplitBearerToRelease = 0, numSplitBearer = 0;
    uint8_t isModificationRequired = FALSE;
    callDRBInfo_type *ptDrb = NULL;

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        ptDrb = &ptCi->drb[drbIdx];
        if ((ptDrb->usage != CI_use) ||
            ((ptDrb->bearerType.val != MN_Term_SPLIT_Bearer) && (ptDrb->selectedBearerType.val != MN_Term_SPLIT_Bearer)))
        {
            continue;
        }

        numSplitBearer++;

        if (TRUE == VLIB_checkXN_SnNeedModify_AfterBearerMod(&ptCi->drb[drbIdx]))
        {
            isModificationRequired = TRUE;
            if (S_Release == ptCi->drb[drbIdx].snDrbStatus)
            {
                numSplitBearerToRelease++;
            }
        }
    }

    if (numSplitBearer <= numSplitBearerToRelease)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi,
            "Enqueue SNode Release - split bearers to release (%d), total number split bearers (%d)\n",
            numSplitBearerToRelease, numSplitBearer);

        if (ERROR == VLIB_EnqueueXnReleaseSNode(ptCi, MrdcRelCause_QosFlowRelease))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_EnqueueXnReleaseSNode ERROR !!\n");
        }
    }

    return isModificationRequired;
}

/*****************************************************************************
 * @brief : VLIB_IsAnySpiltDrbAddMod()
 * Function responsibilty is validation if modification other than DRB release required
 * @param[in/out]   ptCi :      Call information / callInfo_type
 * @return          status :    true/false bool
 ****************************************************************************/
bool VLIB_IsAnySpiltDrbAddMod(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    uint8_t drbIdx = 0;
    callDRBInfo_type *ptDrb = NULL;

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        ptDrb = &ptCi->drb[drbIdx];
        if ((ptDrb->usage != CI_use) ||
            ((ptDrb->bearerType.val != MN_Term_SPLIT_Bearer) && (ptDrb->selectedBearerType.val != MN_Term_SPLIT_Bearer)))
        {
            continue;
        }

        if (TRUE == VLIB_checkXN_SnNeedModify_AfterBearerMod(&ptCi->drb[drbIdx]))
        {
            if (S_Release != ptCi->drb[drbIdx].snDrbStatus)
            {
                return TRUE;
            }
        }
    }

    return FALSE;
}

void FnVCCB_ReproduceUeAMBRforMRDC(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    uint64_t dlUeAmbr = 0, ulUeAmbr = 0;
    uint64_t mnDlRatio = 100, mnUlRatio = 100, snDlRatio = 100, snUlRatio = 100;
    uint8_t plmnIdx = MAX_PLMN_INDEX;
    MrdcBearerTypeCnt_type bearerStats;
    bool mnTerm, snTerm, mcgLeg, scgLeg;

    if (!IS_MRDC_MN(ptCi))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not IS_MRDC_MN in %s!!\n", __FUNCTION__);

        return;
    }

    dlUeAmbr = ptCi->ueInfo.ambr.aggrMbrDl;
    ulUeAmbr = ptCi->ueInfo.ambr.aggrMbrUl;

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (IS_NEDC_MN(ptCi))
    {
        const nedcUeAmbrConfig_type *pUeAmbrConfig = &pGnb->nedcUeAmbrConfig;

        mnDlRatio = pUeAmbrConfig->mnDlRatio;
        mnUlRatio = pUeAmbrConfig->mnUlRatio;
        snDlRatio = 100 - mnDlRatio;
        snUlRatio = 100 - mnUlRatio;

        ptCi->mrdcInfo.ueAmbrDlMN = (dlUeAmbr * mnDlRatio) / 100;
        ptCi->mrdcInfo.ueAmbrDlSN = (dlUeAmbr * snDlRatio) / 100;

        ptCi->mrdcInfo.ueAmbrUlMN = (ulUeAmbr * mnUlRatio) / 100;
        ptCi->mrdcInfo.ueAmbrUlSN = (ulUeAmbr * snUlRatio) / 100;

        goto RESULT_UE_AMBR;
    }
    else
    {
        if (GOOD != VLIB_getMultipleGnbPlmnIndexInfo(ptCi, &plmnIdx, ptCi->ueInfo.servedPlmn.longId))
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "VLIB_getMultipleGnbPlmnIndexInfo ERROR in %s, so plmnIdx#0 will be used as default!!\n", __FUNCTION__);
            plmnIdx = 0;
        }

        if (!IS_VALID_PLMNNUM(plmnIdx))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Invalid plmnIdx(%d) in %s, so plmnIdx#0 will be used as default!!\n", plmnIdx, __FUNCTION__);
            plmnIdx = 0;
        }

        const nrdcUeAmbrConfig_type *pUeAmbrConfig = &pGnb->nrdcUeAmbrConfig[plmnIdx];
        if (pUeAmbrConfig->usage != CI_use)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "nrdcUeAmbrConfig(%u) is not equipped !\n", plmnIdx);
        }
        else
        {
            mnDlRatio = pUeAmbrConfig->mnDlRatio;
            mnUlRatio = pUeAmbrConfig->mnUlRatio;
            snDlRatio = pUeAmbrConfig->snDlRatio;
            snUlRatio = pUeAmbrConfig->snUlRatio;
        }
    }

    VERIFY_MRDC_UEAMBR_RATIO(mnDlRatio, mnUlRatio, snDlRatio, snUlRatio);

    memset(&bearerStats, 0, sizeof(bearerStats));
    FnVCCB_GetMrdcBearerCnt(ptCi, &bearerStats);
    // can consider both the current bearer and next bearer by means of reqBearer stats
    // note) mn-term-scg and sn-term-mcg bearerTypes are not supported.
    //       so mnTerm always has mcg-leg and snTerm always has scg-leg.
    mnTerm = bearerStats.reqBearerCnt.noofMnTermMcg || bearerStats.reqBearerCnt.noofMnTermSplit;
    snTerm = bearerStats.reqBearerCnt.noofSnTermSplit || bearerStats.reqBearerCnt.noofSnTermScg;
    mcgLeg = mnTerm || bearerStats.reqBearerCnt.noofSnTermSplit;
    scgLeg = snTerm || bearerStats.reqBearerCnt.noofMnTermSplit;

    // DL UE-AMBR SETTING
    if (mnTerm && snTerm)
    {
        ptCi->mrdcInfo.ueAmbrDlMN = (dlUeAmbr * mnDlRatio) / 100;
        ptCi->mrdcInfo.ueAmbrDlSN = (dlUeAmbr * snDlRatio) / 100;
    }
    else if (snTerm)
    {
        ptCi->mrdcInfo.ueAmbrDlSN = dlUeAmbr;

        // ptCi->mrdcInfo.ueAmbrDlMN = 0;
        ptCi->mrdcInfo.ueAmbrDlMN = dlUeAmbr;
        VCCB_PRINT_CALL_DATA(ptCi, ">>> Only snTerm but, ueAmbrDlMN is set as dummy against abnormal case!!\n");
    }
    else
    {
        ptCi->mrdcInfo.ueAmbrDlMN = dlUeAmbr;

        // ptCi->mrdcInfo.ueAmbrDlSN = 0;
        ptCi->mrdcInfo.ueAmbrDlSN = dlUeAmbr;
        VCCB_PRINT_CALL_DATA(ptCi, ">>> Only mnTerm but, ueAmbrDlSN is set as dummy against abnormal case!!\n");
    }

    // UL UE-AMBR SETTING
    if (mcgLeg && scgLeg)
    {
        ptCi->mrdcInfo.ueAmbrUlMN = (ulUeAmbr * mnUlRatio) / 100;
        ptCi->mrdcInfo.ueAmbrUlSN = (ulUeAmbr * snUlRatio) / 100;
    }
    else if (scgLeg)
    {
        ptCi->mrdcInfo.ueAmbrUlSN = ulUeAmbr;

        // ptCi->mrdcInfo.ueAmbrUlMN = 0;
        ptCi->mrdcInfo.ueAmbrUlMN = ulUeAmbr;
        VCCB_PRINT_CALL_DATA(ptCi, ">>> Only scgLeg but, ueAmbrUlMN is set as dummy against abnormal case!!\n");
    }
    else  // actually not happened except for SNRelease procedure
    {
        ptCi->mrdcInfo.ueAmbrUlMN = ulUeAmbr;

        // ptCi->mrdcInfo.ueAmbrUlSN = 0;
        ptCi->mrdcInfo.ueAmbrUlSN = ulUeAmbr;
        VCCB_PRINT_CALL_DATA(ptCi, ">>> Only mcgLeg but, ueAmbrUlSN is set as dummy against abnormal case!!\n");
    }

RESULT_UE_AMBR:
    VCCB_PRINT_CALL_DATA(ptCi, ">>> Mrdc UeAmbr Ratio: mnDlRatio(%lu) mnUlRatio(%lu) snDlRatio(%lu) snUlRatio(%lu)!!\n",
        mnDlRatio, mnUlRatio, snDlRatio, snUlRatio);
    VCCB_PRINT_CALL_DATA(ptCi,
        ">>> Mrdc UeAmbr : ueAmbrDlMN(%lu) ueAmbrUlMN(%lu) ueAmbrDlSN(%lu) ueAmbrUlSN(%lu)!!\n",
        ptCi->mrdcInfo.ueAmbrDlMN, ptCi->mrdcInfo.ueAmbrUlMN, ptCi->mrdcInfo.ueAmbrDlSN,
        ptCi->mrdcInfo.ueAmbrUlSN);
}

void FnVCCB_ClearUeSliceMBRforNRDC(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    std::fill_n(rCi.ueInfo.sliceMbrInfo.ueSliceMbrDlSN, MAX_NR_OF_SLICE_MBR, MAX_EXTENDED_BITRATE);
    std::fill_n(rCi.ueInfo.sliceMbrInfo.ueSliceMbrUlSN, MAX_NR_OF_SLICE_MBR, MAX_EXTENDED_BITRATE);
    std::fill_n(rCi.ueInfo.sliceMbrInfo.ueSliceMbrDlMN, MAX_NR_OF_SLICE_MBR, MAX_EXTENDED_BITRATE);
    std::fill_n(rCi.ueInfo.sliceMbrInfo.ueSliceMbrUlMN, MAX_NR_OF_SLICE_MBR, MAX_EXTENDED_BITRATE);
}
/**
 * @brief Reproduce UE-Slice-MBR configuration for MRDC
 * @param [in]  rCi                 : callInfo_type &
 */
void FnVCCB_ReproduceUeSliceMBRforMRDC(callInfo_type &rCi, bool skipCfgUpdate)
{
    AUTO_TRACE_FUNC;

    if (!IS_MRDC_MN(&rCi) || VCCB_FLAG_OFF == rCi.ueInfo.sliceMbrInfo.isSliceMBRListProvided)
    {
        return;
    }

    VCCB_CHECK_E_RANGE_AND_VOID(rCi.gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type &rGnb = GNBINFO[rCi.gnbNum];

    const ueSliceMbrList_type (&detSliceMbr)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.detSliceMbr;
    uint64_t oldUeSliceMbrDlSN[MAX_NR_OF_SLICE_MBR];
    uint64_t oldUeSliceMbrUlSN[MAX_NR_OF_SLICE_MBR];
    uint64_t oldUeSliceMbrDlMN[MAX_NR_OF_SLICE_MBR];
    uint64_t oldUeSliceMbrUlMN[MAX_NR_OF_SLICE_MBR];
    uint8_t sliceMbrIdx = 0;
    bool isAnyDeterminedSliceMBRInUse = false;

    if (VCCB_FLAG_ON == rCi.ueInfo.sliceMbrInfo.fNeedModifyUl || VCCB_FLAG_ON == rCi.ueInfo.sliceMbrInfo.fNeedModifyDl)
    {
        // if subscribed UE-Slice-MBR has changed, fNeedModifyUl or fNeedModifyDl is set to VCCB_FLAG_ON
        // in such case the SN needs also be updated
        rCi.ueInfo.sliceMbrInfo.fNeedModifySN = VCCB_FLAG_ON;
    }

    for (sliceMbrIdx = 0; sliceMbrIdx < MAX_NR_OF_SLICE_MBR; ++sliceMbrIdx)
    {
        oldUeSliceMbrDlSN[sliceMbrIdx] = rCi.ueInfo.sliceMbrInfo.ueSliceMbrDlSN[sliceMbrIdx];
        oldUeSliceMbrUlSN[sliceMbrIdx] = rCi.ueInfo.sliceMbrInfo.ueSliceMbrUlSN[sliceMbrIdx];
        oldUeSliceMbrDlMN[sliceMbrIdx] = rCi.ueInfo.sliceMbrInfo.ueSliceMbrDlMN[sliceMbrIdx];
        oldUeSliceMbrUlMN[sliceMbrIdx] = rCi.ueInfo.sliceMbrInfo.ueSliceMbrUlMN[sliceMbrIdx];
    }

    FnVCCB_ClearUeSliceMBRforNRDC(rCi);  // set MAX_EXTENDED_BITRATE in NRDC UE-Slice-MBR related tables

    if (VCCB_FLAG_OFF == rGnb.cfg.nrSliceMbrOnOff)
    {
        // if OFF, there is no need to reproduce UE-Slice-MBR for NRDC, MAX_EXTENDED_BITRATE will be used
        return;
    }

    // check if new NRDC ueSliceMBR config should be read from database
    // Do not update to secure against abnormal cases where values in database are changed during ongoing procedure
    if (!skipCfgUpdate)
    {
        FnVCCB_GetNrdcUeSliceMbrConfig(rCi);
    }
    const nrdcUeSliceMbrConfig_type &sliceMbrConfig = rCi.ueInfo.sliceMbrInfo.nrdcUeSliceMbrCfg;

    VCCB_PRINT_CALL_DATA(&rCi, ">>> Mrdc UeSliceMbr Ratio: mnDlRatio(%d) mnUlRatio(%d) snDlRatio(%d) snUlRatio(%d)!!\n",
        sliceMbrConfig.mnDlRatio, sliceMbrConfig.mnUlRatio, sliceMbrConfig.snDlRatio, sliceMbrConfig.snUlRatio);

    MrdcBearerTypeCnt_type bearerStats;
    bool mnTerm, snTerm, mcgLeg, scgLeg;
    memset(&bearerStats, 0, sizeof(bearerStats));
    FnVCCB_GetMrdcBearerCnt(&rCi, &bearerStats);
    // can consider both the current bearer and next bearer by means of reqBearer stats
    // note) mn-term-scg and sn-term-mcg bearerTypes are not supported.
    //       so mnTerm always has mcg-leg and snTerm always has scg-leg.
    mnTerm = bearerStats.reqBearerCnt.noofMnTermMcg || bearerStats.reqBearerCnt.noofMnTermSplit;
    snTerm = bearerStats.reqBearerCnt.noofSnTermSplit || bearerStats.reqBearerCnt.noofSnTermScg;
    mcgLeg = mnTerm || bearerStats.reqBearerCnt.noofSnTermSplit;
    scgLeg = snTerm || bearerStats.reqBearerCnt.noofMnTermSplit;

    // DL UE-Slice-MBR SETTING
    for (sliceMbrIdx = 0; sliceMbrIdx < MAX_NR_OF_SLICE_MBR; ++sliceMbrIdx)
    {
        if (CI_use != rCi.ueInfo.sliceMbrInfo.detSliceMbr[sliceMbrIdx].usage)
        {
            continue;
        }

        isAnyDeterminedSliceMBRInUse = true;

        if (mnTerm && snTerm)
        {
            rCi.ueInfo.sliceMbrInfo.ueSliceMbrDlMN[sliceMbrIdx] =
                (detSliceMbr[sliceMbrIdx].bitRateDl * sliceMbrConfig.mnDlRatio) / 100;
            rCi.ueInfo.sliceMbrInfo.ueSliceMbrDlSN[sliceMbrIdx] =
                (detSliceMbr[sliceMbrIdx].bitRateDl * sliceMbrConfig.snDlRatio) / 100;
        }
        else if (snTerm)
        {
            rCi.ueInfo.sliceMbrInfo.ueSliceMbrDlSN[sliceMbrIdx] = detSliceMbr[sliceMbrIdx].bitRateDl;

            // rCi.ueInfo.sliceMbrInfo.ueSliceMbrDlMN[sliceMbrIdx] = 0;
            rCi.ueInfo.sliceMbrInfo.ueSliceMbrDlMN[sliceMbrIdx] = detSliceMbr[sliceMbrIdx].bitRateDl;
            VCCB_PRINT_CALL_DATA(&rCi, ">>> Only snTerm but, ueSliceMbrDlMN is set as dummy against abnormal case!!\n");
        }
        else
        {
            rCi.ueInfo.sliceMbrInfo.ueSliceMbrDlMN[sliceMbrIdx] = detSliceMbr[sliceMbrIdx].bitRateDl;

            // rCi.ueInfo.sliceMbrInfo.ueSliceMbrDlSN[sliceMbrIdx] = 0;
            rCi.ueInfo.sliceMbrInfo.ueSliceMbrDlSN[sliceMbrIdx] = detSliceMbr[sliceMbrIdx].bitRateDl;
            VCCB_PRINT_CALL_DATA(&rCi, ">>> Only mnTerm but, ueSliceMbrDlSN is set as dummy against abnormal case!!\n");
        }

        // UL UE-Slice-MBR SETTING
        if (mcgLeg && scgLeg)
        {
            rCi.ueInfo.sliceMbrInfo.ueSliceMbrUlMN[sliceMbrIdx] =
                (detSliceMbr[sliceMbrIdx].bitRateUl * sliceMbrConfig.mnUlRatio) / 100;
            rCi.ueInfo.sliceMbrInfo.ueSliceMbrUlSN[sliceMbrIdx] =
                (detSliceMbr[sliceMbrIdx].bitRateUl * sliceMbrConfig.snUlRatio) / 100;
        }
        else if (scgLeg)
        {
            rCi.ueInfo.sliceMbrInfo.ueSliceMbrUlSN[sliceMbrIdx] = detSliceMbr[sliceMbrIdx].bitRateUl;

            // rCi.ueInfo.sliceMbrInfo.ueSliceMbrUlMN[sliceMbrIdx] = 0;
            rCi.ueInfo.sliceMbrInfo.ueSliceMbrUlMN[sliceMbrIdx] = detSliceMbr[sliceMbrIdx].bitRateUl;
            VCCB_PRINT_CALL_DATA(&rCi, ">>> Only scgLeg but, ueSliceMbrUlMN is set as dummy against abnormal case!!\n");
        }
        else  // actually not happened except for SNRelease procedure
        {
            rCi.ueInfo.sliceMbrInfo.ueSliceMbrUlMN[sliceMbrIdx] = detSliceMbr[sliceMbrIdx].bitRateUl;

            // rCi.ueInfo.sliceMbrInfo.ueSliceMbrUlSN[sliceMbrIdx] = 0;
            rCi.ueInfo.sliceMbrInfo.ueSliceMbrUlSN[sliceMbrIdx] = detSliceMbr[sliceMbrIdx].bitRateUl;
            VCCB_PRINT_CALL_DATA(&rCi, ">>> Only mcgLeg but, ueSliceMbrUlSN is set as dummy against abnormal case!!\n");
        }
    }

    if (isAnyDeterminedSliceMBRInUse)
    {
        // check and set modify flags if needed
        if (VCCB_FLAG_OFF == rCi.ueInfo.sliceMbrInfo.fNeedModifySN &&
            (0 != memcmp(rCi.ueInfo.sliceMbrInfo.ueSliceMbrDlSN, oldUeSliceMbrDlSN, sizeof(rCi.ueInfo.sliceMbrInfo.ueSliceMbrDlSN)) ||
             0 != memcmp(rCi.ueInfo.sliceMbrInfo.ueSliceMbrUlSN, oldUeSliceMbrUlSN, sizeof(rCi.ueInfo.sliceMbrInfo.ueSliceMbrUlSN))))
        {
            rCi.ueInfo.sliceMbrInfo.fNeedModifySN = VCCB_FLAG_ON;
        }
        if (VCCB_FLAG_OFF == rCi.ueInfo.sliceMbrInfo.fNeedModifyDl &&
            0 != memcmp(rCi.ueInfo.sliceMbrInfo.ueSliceMbrDlMN, oldUeSliceMbrDlMN, sizeof(rCi.ueInfo.sliceMbrInfo.ueSliceMbrDlMN)))
        {
            rCi.ueInfo.sliceMbrInfo.fNeedModifyDl = VCCB_FLAG_ON;
        }
        if (VCCB_FLAG_OFF == rCi.ueInfo.sliceMbrInfo.fNeedModifyUl &&
            0 != memcmp(rCi.ueInfo.sliceMbrInfo.ueSliceMbrUlMN, oldUeSliceMbrUlMN, sizeof(rCi.ueInfo.sliceMbrInfo.ueSliceMbrUlMN)))
        {
            rCi.ueInfo.sliceMbrInfo.fNeedModifyUl = VCCB_FLAG_ON;
        }
    }
}

/**
 * @brief Get NR-DC UE-Slice-MBR configuration for UE served PLMN
 * @param [in]  rCi                 : callInfo_type &
 * @param [in/out] sliceMbrConfig   : nrdcUeSliceMbrConfig_type &
 */
void FnVCCB_GetNrdcUeSliceMbrConfig(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(rCi.gnbNum, MAX_GNB_PER_SYS);
    nrdcUeSliceMbrConfig_type &sliceMbrConfig = rCi.ueInfo.sliceMbrInfo.nrdcUeSliceMbrCfg;

    uint8_t plmnIdx = MAX_PLMN_INDEX;
    if (GOOD != VLIB_getMultipleGnbPlmnIndexInfo(&rCi, &plmnIdx, rCi.ueInfo.servedPlmn.longId))
    {
        VCCB_PRINT_CALL_ERROR(&rCi,
            "VLIB_getMultipleGnbPlmnIndexInfo ERROR in %s, so plmnIdx#0 will be used as default!\n", __FUNCTION__);
        plmnIdx = 0;
    }

    if (!IS_VALID_PLMNNUM(plmnIdx))
    {
        VCCB_PRINT_CALL_ERROR(
            &rCi, "Invalid plmnIdx(%d) in %s, so plmnIdx#0 will be used as default!\n", plmnIdx, __FUNCTION__);
        plmnIdx = 0;
    }

    const nrdcUeSliceMbrConfig_type &pUeSliceMbrConfig = GNBINFO[rCi.gnbNum].nrdcUeSliceMbrConfig[plmnIdx];

    if (CI_use != pUeSliceMbrConfig.usage)
    {
        VCCB_PRINT_CALL_ERROR(
            &rCi, "nrdcUeSliceMbrConfig(%u) is not equipped! Set default value (100) for all ratios!\n", plmnIdx);
        sliceMbrConfig.mnDlRatio = 100;
        sliceMbrConfig.mnUlRatio = 100;
        sliceMbrConfig.snDlRatio = 100;
        sliceMbrConfig.snUlRatio = 100;

        return;
    }

    sliceMbrConfig.mnDlRatio = pUeSliceMbrConfig.mnDlRatio;
    sliceMbrConfig.mnUlRatio = pUeSliceMbrConfig.mnUlRatio;
    sliceMbrConfig.snDlRatio = pUeSliceMbrConfig.snDlRatio;
    sliceMbrConfig.snUlRatio = pUeSliceMbrConfig.snUlRatio;
}

/**
 * @brief : bit-mask setting for CGConfigInfo
 */
int16_t VLIB_Set_CGConfigInfoPresent(callInfo_type *ptCi, uint32_t *pBitMask)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pBitMask);

    if (!IsAvailable_MrdcInfo())
    {
        return ERROR;
    }

    *pBitMask = 0;

    if (ptCi->stateCmd == MrdcXnSNAdd_cmd)
    {
        *pBitMask |= NRRRC_ue_CapabilityInfo_present;
        *pBitMask |= NRRRC_CG_ConfigInfo_IEs_configRestrictInfo_present;
        *pBitMask |= NRRRC_measConfigMN_present;
        *pBitMask |= NRRRC_mcg_RB_Config_present;

        if (IS_NRDC_MN(ptCi))
        {
            *pBitMask |= NRRRC_candidateCellInfoListMN_present;
        }
        else
        {
            *pBitMask |= NRRRC_CG_ConfigInfo_IEs_nonCriticalExtension_present;
        }
    }
    else if (IS_NRDC_MN(ptCi) && ptCi->stateCmd == MrdcXnSNMod_cmd &&
             FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_BearerTypeChange) == true)
    {
        *pBitMask |= NRRRC_mcg_RB_Config_present;
    }
    else if (ptCi->stateCmd == IntraRatHO_cmd)
    {
        switch (ptCi->state)
        {
            case STATE_INTER_DU_SnAdd:
            case STATE_INTER_DU_SnMod:
            case STATE_INTRA_DU_SnAdd:
            case STATE_INTRA_DU_SnMod:
                *pBitMask |= NRRRC_measConfigMN_present;
                *pBitMask |= NRRRC_CG_ConfigInfo_IEs_configRestrictInfo_present;

                // Send the XN SNodeAdditionRequest for Intra MN Inter SN Change (21D)
                if (FnVCCB_IsInterSnMobilityInMn(ptCi))  // make it as function
                {
                    *pBitMask |= NRRRC_ue_CapabilityInfo_present;
                    *pBitMask |= NRRRC_candidateCellInfoListMN_present;
                    *pBitMask |= NRRRC_CG_ConfigInfo_IEs_scg_RB_Config_present;
                    if (IS_FULLCONFIGURATION_NOT_IN_PROCESS(ptCi))
                    {
                        *pBitMask |= NRRRC_sourceConfigSCG_present;
                    }
                }
                // Send the XN SNodeModificationRequest for Intra MN without SN Change (21C)
                else
                {
                    // Include the MR to relay
                    if (IS_NRDC_MN(ptCi))
                    {
                        *pBitMask |= NRRRC_ue_CapabilityInfo_present;
                        *pBitMask |= NRRRC_candidateCellInfoListMN_present;
                    }
                }
                break;
            case STATE_INTER_Pre_DU_S:  // Send the XN SNodeModificationRequest for Inter MN without SN Change (21C)
                                        // With DU Query.
            case STATE_INTER_Pre_SN_T:  // Send the XN SNodeAdditionRequest for Inter MN without SN Change (21C)

                *pBitMask |= NRRRC_CG_ConfigInfo_IEs_scg_RB_Config_present;
                if (IS_FULLCONFIGURATION_NOT_IN_PROCESS(ptCi))
                {
                    *pBitMask |= NRRRC_sourceConfigSCG_present;
                }
                *pBitMask |= NRRRC_measConfigMN_present;
                *pBitMask |= NRRRC_CG_ConfigInfo_IEs_configRestrictInfo_present;

                // Send the XN SNodeAdditionRequest for Intra MN Inter SN Change (21D)
                if (FnVCCB_IsInterSnMobilityInMn(ptCi))  // make it as function
                {
                    *pBitMask |= NRRRC_ue_CapabilityInfo_present;
                    *pBitMask |= NRRRC_candidateCellInfoListMN_present;
                }
                else  // Inter MN without SN Change (21C)
                {
                    // Include the MR to relay
                    if (IS_NRDC_MN(ptCi))
                    {
                        *pBitMask |= NRRRC_ue_CapabilityInfo_present;
                        *pBitMask |= NRRRC_candidateCellInfoListMN_present;
                    }
                }
                break;

            case STATE_MN_INTER_SN_Pre_SN:  // Send the XN SNodeAdditionRequest for Inter SN Change (21D)
                *pBitMask |= NRRRC_ue_CapabilityInfo_present;
                *pBitMask |= NRRRC_CG_ConfigInfo_IEs_configRestrictInfo_present;
                *pBitMask |= NRRRC_measConfigMN_present;
                *pBitMask |= NRRRC_CG_ConfigInfo_IEs_candidateCellInfoListSN_present;
                *pBitMask |= NRRRC_CG_ConfigInfo_IEs_scg_RB_Config_present;
                if (IS_FULLCONFIGURATION_NOT_IN_PROCESS(ptCi))
                {
                    *pBitMask |= NRRRC_sourceConfigSCG_present;
                }
                break;
            default:
                break;
        }
    }
    // SVR22B FGR-CC5203: SCG Failure Handling NR-DC (FR50)
    else if (ptCi->stateCmd == MrdcScgFailSuspend_cmd)
    {
        if (ptCi->nrdcScgFailureInfo.failType <= NrDcScgFailCause_dl_srb3IntegrityFailure)
        {
            *pBitMask |= NRRRC_scgFailureInfo_present;
        }
        else
        {
            *pBitMask |= NRRRC_CG_ConfigInfo_IEs_nonCriticalExtension_present;
        }
        *pBitMask |= NRRRC_candidateCellInfoListMN_present;
    }
    // SVR22B FGR-CC5203: SCG Failure Handling NR-DC (FR50)
    // 22C2: feature refactoring
    else if (ptCi->stateCmd == MrdcScgFailResume_cmd)
    {
        *pBitMask |= NRRRC_candidateCellInfoListMN_present;
    }
    else
    {
        if (IS_ON_MRDC_NEED_MODIFY_FLAG(powerDistribution) || ptCi->state == STATE_UEAssiInfo_XNMod)
        {
            *pBitMask |= NRRRC_CG_ConfigInfo_IEs_configRestrictInfo_present;
        }
    }
    // NRRRC_measConfigMN_present

    // NEDC_SCG_FAILURE_20C
    if (NEDC_SCG_FAILURE_HAPPEN())
    {
        *pBitMask |= NRRRC_CG_ConfigInfo_IEs_nonCriticalExtension_present;
    }

    if ((MeasGapCntl_cmd == ptCi->stateCmd) || (CaMod_cmd == ptCi->stateCmd))
    {
        *pBitMask |= NRRRC_measConfigMN_present;
    }

    if (ptCi->cgConfigInfo.ueAssistanceInformationSCG_v1620_Flag)
    {
        *pBitMask |= NRRRC_CG_ConfigInfo_IEs_nonCriticalExtension_present;
    }

    // Nothing to fill
    if (*pBitMask == 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "*pBitMask == 0 !!\n");

        return ERROR;
    }

    return GOOD;
}

void FnVCCB_DecidePdcchBlindDetectionSCG(
    callInfo_type *ptCi, uint16_t cellNum, configRestrictInfoSCG_type *pCfgRestrictInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pCfgRestrictInfo);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    pCfgRestrictInfo->pdcchBlindDetectionSCG_Flag = VCCB_FLAG_OFF;

    if (DBG->flag.pdcchBlindDetectionSCG == VCCB_FLAG_OFF ||
            !IS_SUPPORT_NrdcPdcchBlindDetection_YANG(ptCi)) // FR900
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "skip DecidePdcchBlindDetectionSCG due to (dbgCfg:%s, YangCfg:%s)\n",
                DBG->flag.pdcchBlindDetectionSCG ? "ON":"OFF", IS_SUPPORT_NrdcPdcchBlindDetection_YANG(ptCi) ? "ON":"OFF");
        return;
    }

    if (!IS_NRDC_MN(ptCi))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "skip DecidePdcchBlindDetectionSCG due to Not NRDC_MN\n");
        return;
    }

    PhyParameters_type &phyParameters = ptCi->ueInfo.ueCapa.nr.phyParameters;
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    int estimatedValue = 0;

    if (phyParameters.present.phyParametersFrxDiff && phyParameters.phyParametersFrxDiff.present.pdcch_BlindDetectionCA)
    {
        estimatedValue =
            MIN(pCell->pdcchConfig.minBlindDetectionScg, phyParameters.phyParametersFrxDiff.pdcch_BlindDetectionCA - 1);

        // valid range : MIN_PDCCH_BLIND_DETECTION_SCG(1) ~ MAX_PDCCH_BLIND_DETECTION_SCG(15) according to 3gpp.
        if (estimatedValue < MIN_PDCCH_BLIND_DETECTION_SCG || estimatedValue > MAX_PDCCH_BLIND_DETECTION_SCG)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "Wrong pdcch-blindDetectionSCG(%d) calculated with "
                "MIN(minBlindDetectionScg(%u),pdcch_BlindDetectionCA(%u)-1) !\n",
                estimatedValue, pCell->pdcchConfig.minBlindDetectionScg,
                phyParameters.phyParametersFrxDiff.pdcch_BlindDetectionCA);
            return;
        }

        VCCB_PRINT_CALL_COMMENT(ptCi, "estimated pdcch-blindDetectionSCG is (%d) !\n", estimatedValue);

        pCfgRestrictInfo->pdcchBlindDetectionSCG = (uint8_t)estimatedValue;
        pCfgRestrictInfo->pdcchBlindDetectionSCG_Flag = VCCB_FLAG_ON;
        return;
    }
    else
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "Not a condition to configure pdcch-blindDetectionSCG. If you want please check UE NR Capa(%u,%u)\n",
            phyParameters.present.phyParametersFrxDiff,
            phyParameters.phyParametersFrxDiff.present.pdcch_BlindDetectionCA);
        return;
    }
}

/**
 * @brief : this api shall be called after storing UeCapabilityInformation.
 */
void VLIB_Set_MrdcConfigRestrictionInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    configRestrictInfoSCG_type *pCfgRestrictInfo = &ptCi->cgConfigInfo.configRestrictInfo;
    int16_t status = GOOD;

    // init configRestrictInfoFlags
    ptCi->cgConfigInfo.configRestrictInfoFlag = VCCB_FLAG_OFF;
    pCfgRestrictInfo->value = 0;

    if (IS_SELECTED_MRDC(MRDC_NEDC))
    {
        status = VLIB_Set_NedcPowerCoordination(ptCi, &pCfgRestrictInfo->powerCoordination_FR1);
        VCCB_RETURN_ON_CALL_VOID(ptCi, status, "VLIB_Set_NedcPowerCoordination ERROR!!\n");
        pCfgRestrictInfo->powerCoordination_FR1_Flag = VCCB_FLAG_ON;
    }
    /*
           In current scope, no need to distribute power to SN.
           MN will use FR1 and SN will use FR2.
    */

    status = VLIB_Set_MrdcServCellIndexRangeSCG(ptCi, &pCfgRestrictInfo->servCellIndexRangeSCG);
    VCCB_RETURN_ON_CALL_VOID(ptCi, status, "VLIB_Set_MrdcServCellIndexRangeSCG ERROR!!\n");
    pCfgRestrictInfo->servCellIndexRangeSCG_Flag = VCCB_FLAG_ON;

    if (pCfgRestrictInfo->allowedBC_ListMRDC.nrofBandComb > 0)
    {
        pCfgRestrictInfo->allowedBC_ListMRDC_Flag = VCCB_FLAG_ON;
    }

    // The next condition check could be removed according to the scenario scope of pdcch-blindDetectionSCG to be
    // delivered to SN
    if (FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnAdd, MRDC_PROC_PURPOSE_BearerTypeChange))
    {
        // SVR23B FGR-CC5200 Basic Operation For NR-DC :: FR910 :: MN VCCB determine pdcch-BlindDetectionSCG
        FnVCCB_DecidePdcchBlindDetectionSCG(ptCi, ptCi->servCellNum, pCfgRestrictInfo);
    }
    else
    {
        if (IS_MRDC(ptCi) && ptCi->stateCmd == IntraRatHO_cmd && ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_config_ue)
        {
            FnVCCB_DecidePdcchBlindDetectionSCG(ptCi, ptCi->hoInfo.targetCellNum, pCfgRestrictInfo);
        }
    }

    if (pCfgRestrictInfo->value)
    {
        ptCi->cgConfigInfo.configRestrictInfoFlag = VCCB_FLAG_ON;
    }
}

int16_t FnVCCB_SetAvailablePSCellBand(
        callInfo_type *ptCi,
        bandCombinationInfo_type *pAllowedBandComb,
        AvailableFSsPerFSCombination_type &availableFSs)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pAllowedBandComb);

    uint16_t bitMapIdx = 0, bitOffset = 0;
    uint16_t maxDbIdx = sizeof(ptCi->ueInfo.allowedBCListNrBandIndiBitMap) / sizeof(ptCi->ueInfo.allowedBCListNrBandIndiBitMap[0]);
    uint16_t loop1, maxLoop1 = MIN(availableFSs.noofBands, MAX_BANDS_PER_COMB);

    for (loop1 = 0; loop1 < maxLoop1; loop1++)
    {
        uint16_t loop2, maxLoop2 = MIN(availableFSs.bands[loop1].noofFsIdx, MAX_NUM_FEATURESETSPERBAND);
        for (loop2 = 0; loop2 < maxLoop2; loop2++)
        {
            uint16_t fsIdx = availableFSs.bands[loop1].fsIdx[loop2];

            if (fsIdx >= MAX_NUM_FEATURESETSPERBAND) continue;

            if (GETBIT_U8TABLE(pAllowedBandComb->allowedFeatureSetsBitmask, fsIdx))
            {
                break;
            }
        }

        if (loop2 < maxLoop2)
        {
            bitMapIdx = availableFSs.bands[loop1].freqBandIndicator / 8;
            bitOffset = availableFSs.bands[loop1].freqBandIndicator % 8;

            if (bitMapIdx >= maxDbIdx) continue;

            ptCi->ueInfo.allowedBCListNrBandIndiBitMap[bitMapIdx] |= (uint8_t)(1 << bitOffset);
        }
    }

    return GOOD;
}

void FnVCCB_updateMrdcPrevInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // It's SA or MN function
    if (IS_MRDC_SN(ptCi))
    {
        return;
    }

    ptCi->prevSelectedMrdcType = ptCi->selectedMrdcType;

    // TODO: update.. what??
    uint8_t drbIdx;
    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        callDRBInfo_type *ptDi = &ptCi->drb[drbIdx];

        if (ptDi->usage != CI_use) continue;

        ptDi->prevSelectedBearerTypeFrozenFlag = ptDi->selectedBearerTypeFrozenFlag;
        ptDi->prevSelectedBearerType = ptDi->selectedBearerType;
        ptDi->prevReqBearerType = ptDi->reqBearerType;
    }
}

void FnVCCB_restoreMrdcPrevInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // It's SA or MN function
    if (IS_MRDC_SN(ptCi))
    {
        return;
    }

    ptCi->selectedMrdcType = ptCi->prevSelectedMrdcType;

    // TODO: restore.. what??
    uint8_t drbIdx;
    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        callDRBInfo_type *ptDi = &ptCi->drb[drbIdx];

        if (ptDi->usage != CI_use) continue;

        ptDi->selectedBearerTypeFrozenFlag = ptDi->prevSelectedBearerTypeFrozenFlag;
        ptDi->selectedBearerType = ptDi->prevSelectedBearerType;
        ptDi->reqBearerType = ptDi->prevReqBearerType;
    }
}

// Make BC List for Ho cancel case
void FnVCCB_recoveryMrdcInfoForHandoverCancel(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    if (IS_MRDC_SN(ptCi))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "This function is used only in SA MN in %s!\n", __FUNCTION__);

        return;
    }

    // INTER-GNB Handover doesn't need to recovery DB
    if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTER_NB)
    {
        return;
    }

    int16_t status = GOOD;
    CellNum_type cellNum = ptCi->servCellNum;  // servcellNum is recovery cellnum(= handout cell)
    VCCB_CHECK_VALID_CELLNUM_VOID(cellNum);
    FreqBandInd_type cellBand = ptCi->servCellBand;

    FnVCCB_restoreMrdcPrevInfo(ptCi);

    if (ptCi->selectedMrdcType == MRDC_NONE)
    {
        return;
    }

    // Re-Generate Processing
    bandCombinationInfoList_type *pCurrAllowedBCList = &ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC;
    if (FnVCCB_CheckPcellInfoChangedforAllowedBC(ptCi, cellNum, cellBand))
    {
        if (IS_SELECTED_MRDC(MRDC_NEDC))
        {
            status = VLIB_Set_MrdcAllowedBCListMRDC(ptCi, cellNum, cellBand, pCurrAllowedBCList, FALSE, TRUE);
            if (status == ERROR)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "VLIB_Set_MrdcAllowedBCListMRDC(EUTRA) Error\n");
            }
        }
        else
        {
            bigmsgUnpack_type *ptUnpackUeCapa = &THREAD_INFO->call[ptCi->myThreadId].buf.unpack.ueCapa;
            NRRRC_UE_NR_Capability *ptMsg = NULL;

            // 1) Unpack
            if (FnVCCB_Wrapper_UnpackNRRRC_UE_NR_Capability(ptCi, ptUnpackUeCapa) == ERROR)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_Wrapper_UnpackNRRRC_UE_NR_Capability Error! in %s!!\n", __func__);

                return;
            }

            ptMsg = (NRRRC_UE_NR_Capability *)(&ptUnpackUeCapa->unpack[0] + ptUnpackUeCapa->unpackMsgOffset);

            // 2) Store
            if (ERROR == FnVCCB_MakeAllowedBCList(ptCi, cellNum, cellBand, ptMsg, TRUE))
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "FnVCCB_MakeAllowedBCList Error! in %s!!\n", __func__);
            }
        }
    }
    else if (CELLINFO[cellNum].cellIdentity != pCurrAllowedBCList->cellIdentity)
    {
        // update SelectedBandEntryMNBitMap in case of pCell change, even if there is no need to refresh AllowedBCList
        VLIB_UpdateSelectedBandEntryMNBitMap(ptCi, cellNum);
    }

    ptCi->mrdcInfo.selectedBC.bandCombinationIndex = ptCi->mrdcInfo.selectedBC.prevBandCombinationIndex;
    ptCi->mrdcInfo.selectedBC.requestedFeatureSets = ptCi->mrdcInfo.selectedBC.prevRequestedFeatureSets;
    FnVCCB_ProcessMnBcReselection(ptCi, MnBCReselectionConditionChecker::HO_CANCLE);
}

/**
 * @brief    Gets band of scell candidates based on CA configurations and fills set with them
 *
 * @param    [in] ptCi : pointer to call context
 * @param    [in] cellNum : spCell cellNum
 * @param    [out] ptScellCandidatesBands : pointer to unordered set of scell candidates bands
 */
void VLIB_GetScellCandidatesBands(callInfo_type *ptCi, CellNum_type cellNum, staticUnorderedSet<uint16_t, MAX_COLOCCELL> *ptScellCandidatesBands)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptScellCandidatesBands);

    ptScellCandidatesBands->clear();

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (!IS_CA_AVAILABLE(ptCi, pCell->nrCarrierAggregationInfo.caAvailable))
    {
        return;
    }

    uint16_t pCellBand = VLIB_GetFreqBandIndForCell(ptCi, pCell);
    VCCB_CHECK_E_RANGE_AND_VOID(pCellBand - 1, MAX_NUM_NR_BAND);

    if (CaOperation_Off == pGnb->carrierAggregationInfo.bandOperationMode[pCellBand - 1].caOperationMode)
    {
        return;
    }

    uint16_t maxLoop = MAX_CELL_PER_DU;
#ifdef __NVGNB__
    maxLoop = MAX_CELL_NUM_VCCB;
#endif

    const uint8_t currColocCellInfoUsage = pCell->cuColocCellInfo.colocCellInfoUsage;

    if (CI_use == currColocCellInfoUsage)
    {
        maxLoop = MAX_COLOCCELL;
    }

    for (uint16_t colocCellIdxLoop = 0; colocCellIdxLoop < maxLoop; colocCellIdxLoop++)
    {
        uint16_t scellBand = BAND_NOT_FOUND;
        if (CI_no_use == currColocCellInfoUsage)
        {
#ifdef __NVGNB__
            const VccbCellInfo_type *const pCellofNVGNB = &CELLINFO[colocCellIdxLoop];

            if ((pCellofNVGNB->status != EQUIP) || (pCellofNVGNB->pldState != EQUIP))
            {
                continue;
            }
            uint16_t duCellNum = colocCellIdxLoop;
#else
            gnbDuInfo_type *pGnbDu = &pGnb->gnbDu[pCell->endPointF1Index];
            if (EQUIP != pGnbDu->cellInDu[colocCellIdxLoop].status)
            {
                continue;
            }
            uint16_t duCellNum = pGnbDu->cellInDu[colocCellIdxLoop].cellNum;
#endif
            scellBand = VLIB_GetFreqBandIndForCellNum(ptCi, duCellNum);
        }
        else
        {
            colocCellEntries_type* const colocCell = &pCell->cuColocCellInfo.colocCellEntries[colocCellIdxLoop];
            if ((CI_no_use == colocCell->usage) || (TRUE != colocCell->useforNrca))
            {
                continue;
            }

            cgi_type cgi;
            cgi.ci = VLIB_GnbIdCellId2NrCellId(&colocCell->globalGnbId.gnbId, colocCell->cellId);
            cgi.plmn = colocCell->globalGnbId.plmn;
            uint8_t gnbIdLength = colocCell->globalGnbId.gnbId.idLength;

            const nbrGnbCellInfo_type *ptCell = VLIB_GetNbrGnbCellInfoBasedOnCgi(ptCi, cgi, gnbIdLength);
            if (NULL == ptCell)
            {
                continue;
            }

            scellBand = VLIB_GetFreqBandIndForNeighborCellWithCustomSpCell(ptCi, ptCell, cellNum, false);
        }

        if ((BAND_NOT_FOUND != scellBand) &&
            (MAX_FR1_NR_BAND >= scellBand)) // only FR1 bands should be handled
        {
            ptScellCandidatesBands->insert(scellBand);
        }
    }
}

/**
 * @brief    Fills selectedBandEntryMNBitMap marking bands which can be used by scell candidates
 *
 * @param    [in] ptCi : pointer to call context
 * @param    [in] pBandCombList : pointer to UE supported band combinations
 * @param    [in] cellNum : spCell cellNum
 * @param    [out] pDst : pointer band combination info list which will be filled
 */
void VLIB_FillselectedBandEntryMNBitMap(callInfo_type *ptCi, bandCombinationList_type *pBandCombList, CellNum_type cellNum, bandCombinationInfoList_type *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pDst);
    VALID_E_POINT_CHECK_VOID(pBandCombList);

    staticUnorderedSet<uint16_t, MAX_COLOCCELL> scellCandidatesBands;
    VLIB_GetScellCandidatesBands(ptCi, cellNum, &scellCandidatesBands);

    const bool noScellCandidates = scellCandidatesBands.empty();
    const uint16_t nrOfAllowedBC = MIN(pDst->nrofBandComb, MAX_NUM_BAND_COMB);
    const uint16_t nrOfBandCombinations = MIN(pBandCombList->num, MAX_BAND_COMBS);

    for (uint16_t bCInfoIdx = 0; bCInfoIdx < nrOfAllowedBC; ++bCInfoIdx)
    {
        bandCombinationInfo_type &rBandCombinationInfo = pDst->bandCombinationInfo[bCInfoIdx];
        rBandCombinationInfo.selectedBandEntryMNBitMap = 0;

        const uint32_t bandCombinationIndex = (uint32_t)(rBandCombinationInfo.bandCombinationIndex - 1);
        if (noScellCandidates ||
            (nrOfBandCombinations <= bandCombinationIndex))
        {
            continue;
        }

        BandCombination_type &rBandCombination = pBandCombList->bandCombination[bandCombinationIndex];
        const uint32_t noOfBands = MIN(rBandCombination.num, MAX_BANDS_PER_COMB);

        for (uint16_t bandIdx = 0; bandIdx < noOfBands; ++bandIdx)
        {
            const uint16_t freqBandIndicator = rBandCombination.band[bandIdx].freqBandIndicator;

            if (scellCandidatesBands.contains(freqBandIndicator))
            {
                ONBIT_U32(rBandCombinationInfo.selectedBandEntryMNBitMap, bandIdx);
            }
        }
    }
}

/**
 * @brief    Updates selectedBandEntryMNBitMap even if MrdcAllowedBCListMRDC is not updated
 *
 * @param    [in] ptCi : pointer to call context
 * @param    [in] cellNum : spCell cellNum
 */
void VLIB_UpdateSelectedBandEntryMNBitMap(callInfo_type *ptCi, CellNum_type cellNum)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_VALID_CELLNUM_VOID(cellNum);
    bandCombinationList_type *pBandCombList = nullptr;
    if (IS_SELECTED_MRDC(MRDC_NEDC))
    {
        pBandCombList = VRIL_GetEutraNrBandCombinationList(ptCi);
    }
    else
    {
        pBandCombList = VRIL_GetBandCombinationList(ptCi);
    }
    VALID_E_POINT_CHECK_VOID(pBandCombList);
    bandCombinationInfoList_type *pDst = &ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC;
    VLIB_FillselectedBandEntryMNBitMap(ptCi, pBandCombList, cellNum, pDst);
    pDst->cellIdentity = CELLINFO[cellNum].cellIdentity;
}

/**
 * @brief This function sets the flags for generating MRDC Gen DB.
 *
 * @param ptCi Pointer to call information structure.
 * @param isNRCapa Indicates whether the UE supports NR capability.
 * @param isHandoverCase Indicates whether the current scenario is a handover case.
 * @param isNedcGen Reference to the flag for generating NE-DC Gen DB.
 * @param isNrdcGen Reference to the flag for generating NR-DC Gen DB.
 */
void FnVCCB_SetMrdcGenDBFlags(
    const callInfo_type *ptCi,
    const uint8_t isNRCapa,
    const uint8_t isHandoverCase,
    bool &isNedcGen,
    bool &isNrdcGen)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    isNedcGen = isNrdcGen = false;

    // Selection Generate Target DB
    if (isHandoverCase == TRUE)
    {
        if (isNRCapa == TRUE)
        {
            isNrdcGen = true;  // NR-DC, SA
        }
        else
        {
            isNedcGen = true;  // NE-DC
        }
    }
    else /* Basic */
    {
        if (IS_SELECTED_MRDC(MRDC_NRDC) && isNRCapa)
        {
            isNrdcGen = true;
        }
        else if (IS_SELECTED_MRDC(MRDC_NEDC) && !isNRCapa)
        {
            isNedcGen = true;
        }
    }
}

/**
 * @brief This function determines whether to generate the AllowedBCList for the given UE Capability Information.
 *
 * @param ptCi Pointer to the call information structure.
 * @param isNedcGen Indicates whether the generalized BC list for NEDC is used.
 * @param isNrdcGen Indicates whether the generalized BC list for NRDC is used.
 * @return true if the AllowedBCList should be generated, false otherwise.
 */
bool FnVCCB_ShouldGenerateAllowedBCList(const callInfo_type *ptCi, const bool isNedcGen, const bool isNrdcGen)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (isNrdcGen == true)
    {
        return true;
    }

    if (isNedcGen == true)
    {
        // this has been already destined when NRCapability is stored.
        return IsSupport_NEDC_UeCapa(ptCi);
    }

    return false;
}

/**
 * @brief
 */
int16_t VLIB_Set_MrdcAllowedBCListMRDC(callInfo_type *ptCi, CellNum_type cellNum, FreqBandInd_type cellBand,
    bandCombinationInfoList_type *pDst, uint8_t isNRCapa, uint8_t isHandoverCase)
{
    /*
           This api sets AllowedBCList to the cgConfigInfo.configRestrictionInfo.allowedBC_ListMRDC.
    */
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *ptCell = &CELLINFO[cellNum];
    uint16_t selectedBCCnt = 0, selectedFSPerBandCnt = 0;
    uint8_t selectedPowerClass = UePowerClass_Pc2;

    bool isNedcGen = false;
    bool isNrdcGen = false;

    // Selection Generate Target DB
    FnVCCB_SetMrdcGenDBFlags(ptCi, isNRCapa, isHandoverCase, isNedcGen, isNrdcGen);

    // Always Init DB
    FnVCCB_InitAllowedBCList(ptCi, pDst);

    // Generate Processing
    if (FnVCCB_ShouldGenerateAllowedBCList(ptCi, isNedcGen, isNrdcGen) == false)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "AllowedBCList is not composited(%d/%u), genFlag(%u/%u), isNrCapa(%d) for MRDC in %s!\n",
            IS_SELECTED_MRDC(MRDC_NEDC), IS_SELECTED_MRDC(MRDC_NRDC),
            static_cast<unsigned>(isNrdcGen), static_cast<unsigned>(isNedcGen),
            isNRCapa, __FUNCTION__);

        return BREAK;
    }

    bandCombinationList_type *pBandCombList = NULL;
    MrdcFeatureSetCombinationList_type *pFeatureSetCombList = NULL;

    if (IS_SELECTED_MRDC(MRDC_NEDC))
    {
        pBandCombList = VRIL_GetEutraNrBandCombinationList(ptCi);
        pFeatureSetCombList = VRIL_GetEutraNrFeatureSetCombinationList(ptCi);
    }
    else
    {
        pBandCombList = VRIL_GetBandCombinationList(ptCi);
        pFeatureSetCombList = VRIL_GetFeatureSetCombinationList(ptCi);
    }

    VALID_E_POINT_CHECK_ERROR(pBandCombList);
    VALID_E_POINT_CHECK_ERROR(pFeatureSetCombList);

    if (cellBand == BAND_NOT_FOUND)
    {
        cellBand = VLIB_GetFreqBandIndForCell(ptCi, ptCell);
        if (!cellBand)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: cellBand is invalid in %s!\n", __FUNCTION__);

            return ERROR;
        }

        VCCB_PRINT_CALL_COMMENT(ptCi, "cellBand is invalid in %s using band(%u)\n", __FUNCTION__, cellBand);
    }

    if (pBandCombList->num == 0 || pFeatureSetCombList->num == 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR, pBandCombList->num(%u) or pFeatureSetCombList->num(%u) is zero (Nr=%u, Mrdc=%u)\n",
            pBandCombList->num, pFeatureSetCombList->num, isNrdcGen, isNedcGen);

        return ERROR;
    }

    uint16_t maxLoop = MIN(pBandCombList->num, MAX_BAND_COMBS);
    uint16_t nrofAllowedFeatureSets = 0;
    SupportableFeatureSetDecisionforAllowedBC featureSetDecision(ptCi, cellNum, isNrdcGen);

    for (int cIdx = 0; cIdx < maxLoop; cIdx++)
    {
        const BandCombination_type *pBandComb = &pBandCombList->bandCombination[cIdx];

        if (pBandComb->featureSetCombination >= pFeatureSetCombList->num ||
            pBandComb->featureSetCombination >= MAX_MRDC_FS_COMBS)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "Invalid featureSetCombination(%u) vs num of fsComb(%u), MAX_MRDC_FS_COMBS(%d)\n",
                pBandComb->featureSetCombination, pFeatureSetCombList->num, MAX_MRDC_FS_COMBS);
            continue;
        }

        if (selectedBCCnt >= MAX_NUM_BAND_COMB)
        {
            break;
        }

        // FGR-CC5200:FR150
        if ((IS_SELECTED_MRDC(MRDC_NRDC) &&
                (!pBandComb->caParametersNRDC_present && !pBandComb->supportedNumberTAG_present)) ||
            (IS_SELECTED_MRDC(MRDC_NEDC) && !(pBandComb->ne_DC_BC_present || pBandComb->nedcOnly_present)))
        {
            continue;
        }

        const MrdcFeatureSetCombination_type *pFeatureSetComb =
            &pFeatureSetCombList->mrdcFeatureSetCombination[pBandComb->featureSetCombination];

        pDst->bandCombinationInfo[selectedBCCnt].powerClassPresent = 0;
        pDst->bandCombinationInfo[selectedBCCnt].selectedBandEntryMNBitMap = 0;
        pDst->bandCombinationInfo[selectedBCCnt].bandCombinationIndex = UNKNOWN_BAND_COMBINATION_INDEX;
        nrofAllowedFeatureSets = 0;
        memset(pDst->bandCombinationInfo[selectedBCCnt].allowedFeatureSetsBitmask, 0x00,
            sizeof(pDst->bandCombinationInfo[selectedBCCnt].allowedFeatureSetsBitmask));

        selectedFSPerBandCnt = 0;

        AvailableFSsPerFSCombination_type availableFSs;
        uint16_t maxLoop1 = MIN3((uint16_t)pFeatureSetComb->num, (uint16_t)pBandComb->num, MAX_BANDS_PER_COMB);
        uint32_t available_pcellband_idx = 0;

        availableFSs.noofBands = 0;

        // FGR-CC5200:FR1010
        uint8_t CA_BandwidthClassNR_a_cnt = 0;
        uint16_t freqBandIndiPerBandCombination[MAX_BANDS_PER_COMB];
        for (uint32_t bIdx = 0; bIdx < maxLoop1; bIdx++)
        {
            const BandParameters_type *pBandParam = &pBandComb->band[bIdx];
            const MrdcFeatureSetPerBand_type *pFeatureSetPerBand = &pFeatureSetComb->featureSetPerBand[bIdx];

            uint16_t maxLoop2 = MIN(pFeatureSetPerBand->num, MAX_NUM_FEATURESETSPERBAND);

            bandWithAvailableFSs_type &availableBand = availableFSs.bands[availableFSs.noofBands];
            availableBand.noofFsIdx = 0;
            availableBand.freqBandIndicator = 0;

            freqBandIndiPerBandCombination[bIdx] = pBandParam->freqBandIndicator;
#define MIN_FR2_BAND_INDICATOR 257
            if (ci_nr == pBandParam->ratType && pBandParam->freqBandIndicator < MIN_FR2_BAND_INDICATOR)
            {
                // FGR-CC5200:FR1010
                if (pBandParam->nrCaBandwidthClassDL == CA_BandwidthClassNR_a)
                {
                    CA_BandwidthClassNR_a_cnt++;
                }
                else if (pBandParam->nrCaBandwidthClassDL > CA_BandwidthClassNR_a)
                {
                    CA_BandwidthClassNR_a_cnt = (CA_BandwidthClassNR_a_cnt + 2U) & e_BitMask_8bit;
                }
            }
            for (uint16_t fIdx = 0; fIdx < maxLoop2; fIdx++)
            {
                if (pFeatureSetPerBand->featureSet[fIdx].dlSetId && pFeatureSetPerBand->featureSet[fIdx].ulSetId)
                {
                    availableBand.fsIdx[availableBand.noofFsIdx] = fIdx;

                    if (!nrofAllowedFeatureSets && (pBandParam->ratType == ci_nr) &&
                        (pFeatureSetPerBand->ratType == ci_nr) && (pBandParam->freqBandIndicator == cellBand)
                        && featureSetDecision.isSupportableFeatureSetforAllowedBC(ptCi,
                               pFeatureSetPerBand->featureSet[fIdx].dlSetId,
                               pFeatureSetPerBand->featureSet[fIdx].ulSetId)
                    )
                    {
                        if (selectedFSPerBandCnt >= MAX_NUM_FEATURESETSPERBAND)
                        {
                            break;
                        }
                        selectedFSPerBandCnt++;
                        ONBIT_U8TABLE(pDst->bandCombinationInfo[selectedBCCnt].allowedFeatureSetsBitmask, fIdx);
                    }
                    availableBand.noofFsIdx++;
                }
            }

            if (availableBand.noofFsIdx > 0)
            {
                availableBand.freqBandIndicator = pBandParam->freqBandIndicator;
                availableFSs.noofBands++;
            }

            if (selectedFSPerBandCnt > 0)
            {
                nrofAllowedFeatureSets = selectedFSPerBandCnt;
                available_pcellband_idx = bIdx;
                selectedFSPerBandCnt = 0;
            }
        }

        if (nrofAllowedFeatureSets)
        {
            pDst->bandCombinationInfo[selectedBCCnt].bandCombinationIndex = (cIdx + 1) & 0x1FFFF;
            pDst->bandCombinationInfo[selectedBCCnt].powerClassPresent = pBandComb->powerClass_present;
            pDst->bandCombinationInfo[selectedBCCnt].selectedBandEntryMNIndex = available_pcellband_idx & 0xFF;

            // FGR-CC5200:FR1010
            if (CA_BandwidthClassNR_a_cnt >= 2)
            {
                pDst->bandCombinationInfo[selectedBCCnt].isSupportFR1Ca = VCCB_FLAG_ON;
            }
            else
            {
                pDst->bandCombinationInfo[selectedBCCnt].isSupportFR1Ca = VCCB_FLAG_OFF;
            }

            for (uint8_t idx = 0; idx < maxLoop1; ++idx)
            {
                pDst->bandCombinationInfo[selectedBCCnt].freqBandIndi[idx] = freqBandIndiPerBandCombination[idx];
            }
            pDst->bandCombinationInfo[selectedBCCnt].noofFreqBandIndi = maxLoop1 & e_BitMask_8bit;

            if (IS_SELECTED_MRDC(MRDC_NEDC))
            {
                uint16_t idx = 0, bitMapIdx = 0, bitOffset = 0;
                uint8_t maxDbIdx = sizeof(ptCi->ueInfo.allowedBCListEutraBandIndiBitMap) /
                                   sizeof(ptCi->ueInfo.allowedBCListEutraBandIndiBitMap[0]);

                for (idx = 0; idx < maxLoop1; idx++)
                {
                    if (pBandComb->band[idx].ratType == ci_eutra)
                    {
                        bitMapIdx = pBandComb->band[idx].freqBandIndicator / 8;
                        bitOffset = pBandComb->band[idx].freqBandIndicator % 8;

                        if (bitMapIdx >= maxDbIdx) continue;

                        ptCi->ueInfo.allowedBCListEutraBandIndiBitMap[bitMapIdx] |= (uint8_t)(1 << bitOffset);
                    }
                }
            }
            else  // NRDC
            {
                if (ERROR == FnVCCB_SetAvailablePSCellBand( ptCi, &pDst->bandCombinationInfo[selectedBCCnt], availableFSs))
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SetAvailablePSCellBand ERROR!\n");
                }
            }

            /* selects pc2 if all allowedBandCombinations are pc2. otherwise selects pc3 */
            if (!pBandComb->powerClass_present)
            {
                selectedPowerClass = UePowerClass_Pc3;
            }

            selectedBCCnt++;
        }
    }

    pDst->powerClass = selectedPowerClass;
    pDst->nrofBandComb = selectedBCCnt;

    VLIB_FillselectedBandEntryMNBitMap(ptCi, pBandCombList, cellNum, pDst);

    featureSetDecision.showInternalStats(ptCi);
    VLIB_DbgPrint_AllowedBCList(ptCi, pDst, isNrdcGen, true);

    VCCB_PRINT_CALL_COMMENT(ptCi, "selected AllowedBCList(cnt:%u, powerClass:%u)\n", selectedBCCnt, selectedPowerClass);

    if (pDst->nrofBandComb <= 0)
    {
        return ERROR;
    }

    if (isNrdcGen == true)
    {
        SET_SUPPORT_NRDC_UECAPA(ptCi, VCCB_FLAG_ON);
        VCCB_PRINT_CALL_ERROR(ptCi, "SET_SUPPORT_NRDC_UECAPA ON!!\n");
    }

    pDst->mrdcType = GET_SELECTED_MRDC(ptCi);
    pDst->cellIdentity = ptCell->cellIdentity;
    pDst->pcellBandIndi = cellBand;
    pDst->nrScsDl = ptCell->nrScsDl;
    pDst->bandwidthDl = ptCell->intraGnbNbrInfo.bandwidthDl;
    return GOOD;
}

/**
 * @brief :
 */
int16_t VLIB_Set_NedcPowerCoordination(callInfo_type *ptCi, powerCoordination_FR1_type *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    uint8_t P_FR1_dBm = 23, P_NR_FR1_dBm = 23, P_LTE_dBm = 23;
    uint8_t powerOffset = NEDC_PowerOffset(ptCi->servCellNum);  // 1 ~ 7

    if (!IsAvailable_MrdcInfo())
    {
        return ERROR;
    }

    if (powerOffset > MAX_NEDC_POWER_OFFSET)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Error, Invalid power offset(%u) !\n", powerOffset);
        powerOffset = 1;
    }

    uint8_t requestPowerClass = UePowerClass_Pc3;
    if (FnVCCB_IsNeBasicPowerMode(ptCi->servCellNum) && powerOffset >= 1)
    {
        if (ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC.powerClass == UePowerClass_Pc2)
        {
            P_FR1_dBm = 26;
            P_NR_FR1_dBm = nedcPC2PowerOffset_NRTable[powerOffset - 1];
            P_LTE_dBm = nedcPC2PowerOffset_LTETable[powerOffset - 1];
            requestPowerClass = UePowerClass_Pc2;
        }
        else
        {  // If there are no power class 2 capability, power class 3 is assumed
            P_FR1_dBm = 23;
            P_NR_FR1_dBm = nedcPC3PowerOffset_NRTable[powerOffset - 1];
            P_LTE_dBm = nedcPC3PowerOffset_LTETable[powerOffset - 1];
        }
    }
    else
    {
        P_FR1_dBm = 23;
        P_NR_FR1_dBm = 23;
        P_LTE_dBm = 23;
    }

    pDst->pMaxNR_FR1_Flag = VCCB_FLAG_ON;
    pDst->pMaxEUTRA_Flag = VCCB_FLAG_ON;
    pDst->pMaxUE_FR1_Flag = VCCB_FLAG_ON;
    pDst->pMaxNR_FR1 = P_NR_FR1_dBm;  // for gNB
    pDst->pMaxEUTRA = P_LTE_dBm;      // for eNB
    pDst->pMaxUE_FR1 = P_FR1_dBm;     // for eNB

    /*
    if the ne-dc-operator-specific-power-allocation or ne-dc-power-offset-nr-fr1 of the ne-dc-power-config container is
    changed, pMaxNR-FR1 should be delivered to MAC S/W of DU and powerCoordination-FR1 should be delivered to the S-Node
    during the next SNModification procedure.

    If P_LTE_dBm updated or P_FR1_dBm updated is changed,
        p-maxEUTRA, p-maxUE-FR1 should be delivered to SCG eNB, using powerCoordination-FR1 IE in Xn I/F;

    If P_NR_FR1_dBm is changed
        P_NR_FR1_dBm should be delivered to MAC S/W block;
*/

    VCCB_PRINT_CALL_COMMENT(ptCi,
        "Set MrdcPowerCoordination w/ pMaxNR-FR1(%u), pMaxEUTRA(%u), pMaxUE-FR1(%u), powerClass(%u)\n",
        pDst->pMaxNR_FR1, pDst->pMaxEUTRA, pDst->pMaxUE_FR1, requestPowerClass);

    return GOOD;
}

/**
 * @brief :
 */
int16_t VLIB_Set_MrdcServCellIndexRangeSCG(callInfo_type *ptCi, servCellIndexRangeSCG_type *pCellIdxRange)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pCellIdxRange);

    const uint16_t nedc_lowBound = 1, nedc_upBound = 7;
    const uint16_t nrdc_lowBound = 8, nrdc_upBound = 31; // TODO lowBound should be 16.

    if (IS_SELECTED_MRDC(MRDC_NEDC))
    {
        pCellIdxRange->lowBound = nedc_lowBound;
        pCellIdxRange->upBound = nedc_upBound;
        if (DBG->mrdcServCellIndexRangeSCG.usage.nedc)
        {
            pCellIdxRange->lowBound = DBG->mrdcServCellIndexRangeSCG.nedc.lowBound;
            pCellIdxRange->upBound = DBG->mrdcServCellIndexRangeSCG.nedc.upBound;
        }
    }
    else
    {
        pCellIdxRange->lowBound = nrdc_lowBound;
        pCellIdxRange->upBound = nrdc_upBound;
        if (DBG->mrdcServCellIndexRangeSCG.usage.nrdc)
        {
            pCellIdxRange->lowBound = DBG->mrdcServCellIndexRangeSCG.nrdc.lowBound;
            pCellIdxRange->upBound = DBG->mrdcServCellIndexRangeSCG.nrdc.upBound;
        }
    }

    return GOOD;
}

/**
 * @brief :
 */
void VLIB_Set_MrdcScgConfigQuery(callInfo_type *ptCi, enumVccbFlag flag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    /* set scgConfigQuery to 'VCCB_FLAG_ON' before send SN modification request*/
    ptCi->ueInfo.scgConfigQuery = flag;

    if (flag == VCCB_FLAG_ON)
    {
        /* Clear DB */
        FnVCCB_Mrdc_Init_octetString(ptCi, &ptCi->mrdcInfo.scgCellGrpConfig);
        FnVCCB_Mrdc_Init_octetString(ptCi, &ptCi->mrdcInfo.scgRBConfig);
    }
}

/**
 * @brief :
 */
int16_t VLIB_Get_MrdcScgConfigQuery(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    if (ptCi->ueInfo.scgConfigQuery == VCCB_FLAG_ON)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

// NEDC_SCG_FAILURE_20C
int16_t VLIB_Check_Need_Mn2SnContainer(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    // Check SCGFailureEUTRA case
    if (NEDC_SCG_FAILURE_HAPPEN())
    {
        return TRUE;
    }

    switch (ptCi->state)
    {
        case STATE_INTRA_DU_SnAdd:
        case STATE_INTRA_DU_SnMod:
        case STATE_INTER_DU_SnAdd:
        case STATE_INTER_DU_SnMod:
            return TRUE;
        default:
            break;
    }

    // SVR22B FGR-CC5203: FR50: In order to include Candidate Cell List
    if ((ptCi->stateCmd == MrdcScgFailSuspend_cmd) || (ptCi->stateCmd == MrdcScgFailResume_cmd))
    {
        return TRUE;
    }

    return FALSE;
}

/*
 * @brief Check if power distribution need to be updated
 * @param callInfo_type *ptCi
 * @return int16_t GOOD/ERROR (1/-1)
 */
int16_t VLIB_CheckPowerDistributionNEDC(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint32_t selectedBCIdx = ptCi->mrdcInfo.selectedBC.bandCombinationIndex;
    uint16_t bcIdx = 0;
    powerCoordination_FR1_type *pPowerCoordination = &ptCi->cgConfigInfo.configRestrictInfo.powerCoordination_FR1;
    configRestrictInfoSCG_type *pCfgRestrInfo = &ptCi->cgConfigInfo.configRestrictInfo;
    int16_t P_FR1_dBm_prev = pPowerCoordination->pMaxUE_FR1;
    int16_t P_NR_FR1_dBm_prev = pPowerCoordination->pMaxNR_FR1;
    int16_t P_LTE_dBm_prev = pPowerCoordination->pMaxEUTRA;
    bandCombinationInfoList_type *pAllowedBCList = &ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC;
    int maxBCIdx = (int)(UMIN((uint32_t)pAllowedBCList->nrofBandComb, MAX_BAND_COMBS));

    for (bcIdx = 0; bcIdx < maxBCIdx; ++bcIdx)
    {
        if (pAllowedBCList->bandCombinationInfo[bcIdx].bandCombinationIndex == selectedBCIdx)
        {
            break;
        }
    }
    if (bcIdx >= maxBCIdx)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "VLIB_CheckPowerDistributionNEDC - invalid bandCombinationIndex (%d) ERROR!!\n", selectedBCIdx);

        return ERROR;
    }

    uint8_t requestedPowerClass =
        (pAllowedBCList->bandCombinationInfo[bcIdx].powerClassPresent) ? (UePowerClass_Pc2) : (UePowerClass_Pc3);
    ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC.powerClass = requestedPowerClass;

    int16_t status = VLIB_Set_NedcPowerCoordination(ptCi, &pCfgRestrInfo->powerCoordination_FR1);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VLIB_Set_NedcPowerCoordination ERROR!!\n");

    if ((P_FR1_dBm_prev != pPowerCoordination->pMaxUE_FR1) || (P_NR_FR1_dBm_prev != pPowerCoordination->pMaxNR_FR1) ||
        (P_LTE_dBm_prev != pPowerCoordination->pMaxEUTRA))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi,
            "power value need to be updated P_FR1_dBm(%d->%d), P_NR_FR1_dBm(%d->%d), P_LTE_dBm(%d->%d) \n",
            P_FR1_dBm_prev, pPowerCoordination->pMaxUE_FR1, P_NR_FR1_dBm_prev, pPowerCoordination->pMaxNR_FR1,
            P_LTE_dBm_prev, pPowerCoordination->pMaxEUTRA);

        status = VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_POWER_DISTRIBUTION_UPDATE);
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "VCCM_enqueueAction(ENQUEUE_ACTION_POWER_DISTRIBUTION_UPDATE) fail\n");
        }
    }

    return GOOD;
}


// This api will be used to stop mrdc-procedure for bearerType change without sn-release.
// This api should not be called during mn call-release.
void FnVCCB_TerminateOngoingMrdcProcedureAtMN(callInfo_type *ptCi, int ctrlFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!IsAvailable_MrdcInfo())
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "!IsAvailable_MrdcInfo() ERROR !\n");
        return;
    }

    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);
    FnVCCB_DetachCallMultiTimer(ptCi);

    if (ctrlFlag & NRDC_FINALIZE_CTRL_SetBearerStatusToStable)
    {
        VCCM_SetStableState_CallSetup(ptCi);
    }

    if (ctrlFlag & NRDC_FINALIZE_CTRL_InitInstantInfo)
    {
        FnVCCB_InitAllDrb_DataFwdTunnelAndSnStatus(ptCi);
        FnVCCB_ClearAllMrdcFlags(ptCi);
        FnVCCB_ClearInstantFlagOfMrdcInfo(ptCi);
        VLIB_FreeBuffAllMrdcInfo(ptCi, PL_COMMENT);
    }

    if (ctrlFlag & NRDC_FINALIZE_CTRL_RestoreAllBearerType)
    {
        FnVCCB_restoreMrdcPrevInfo(ptCi);
    }
}
/**
 ** @brief :
 **/
void VLIB_FinalizeSNRelMrdc(callInfo_type *ptCi, int ctrlFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!IsAvailable_MrdcInfo())
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "!IsAvailable_MrdcInfo() ERROR !\n");
        return;
    }

    VCCB_PRINT_CALL_DATA(ptCi, "VLIB_FinalizeSNRelMrdc(ctrlFlag:D'%d, H'0x%x)!\n", ctrlFlag, (uint32_t)ctrlFlag);

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // step1. mandatory, initialize all instant flags and release buffers
    // NRDC_FINALIZE_CTRL_SetBearerStatusToStable shall not be activated during release of sa-call(mn)
    int actionFlag = ctrlFlag & NRDC_FINALIZE_CTRL_InitInstantInfo;
    FnVCCB_TerminateOngoingMrdcProcedureAtMN(ptCi, actionFlag);
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // step2. collects nrdc-related stats
    if (ctrlFlag & NRDC_FINALIZE_CTRL_CollectStats)
    {
        // FGR-CC5200:FR760 FR770
        FnVCCB_NrdcSnConnInfoStatsCmd(ptCi, ptCi->servCellNum, ConnInfoStatsCmd_HoldingTimeStop);
        FnVCCB_NrdcSnConnInfoStatsCmd(ptCi, ptCi->servCellNum, ConnInfoStatsCmd_Decrease);
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // step3. release mrdc property
    if (ctrlFlag & NRDC_FINALIZE_CTRL_ReleaseMrdcProperty)
    {
        VLIB_InitMrdcProperty(ptCi);
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // step4. Others#1;
    // The next operations shall not trigger other procedure with including change of state or stateCmd rather than event queuing.
    if (ctrlFlag & NRDC_FINALIZE_CTRL_PrepareOthers)
    {
        FnVCCB_ReinstallMrdcBaseInfoAfterMobility(ptCi, ptCi->servCellNum, ptCi->servCellBand, 0xff);
        FnVCCB_Finalize_UeCapaEnquiryIfNeeded_ForSA(ptCi, ptCi->servCellNum, VCCB_FLAG_ON);

        // SVR25B FGR-CC0103 FR680 (only if sn release procedure has triggered by RRC state transition to RRC_Inactive)
        if (IS_SUPPORT_RRC_INACTIVE(ptCi) &&
            ptCi->ueInfo.rrcResumeInfo.preventSNAddFlag == TRUE &&
            ptCi->ranPagingInfo.dlDataFlag == VCCB_FLAG_OFF)
        {
            if (ptCi->ueInfo.rrcResumeInfo.actionInSNRelease == SN_REL_IN_RRC_INACTIVE_DECIDED_AND_CONFIRMED)
            {
                int16_t status = FnVCCB_UpdateRRCInactStateAndDoActionIfExpiry(ptCi, RRCInactiveEvent_SIGNAL_EXPIRY);
                if (status != GOOD)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_UpdateRRCInactStateAndDoActionIfExpiry ERROR in %s\n", __FUNCTION__);
                }
            }
            else
            {
                ptCi->ueInfo.rrcResumeInfo.actionInSNRelease = SN_REL_IN_RRC_INACTIVE_DECIDED_AND_WAIT_INACTNOTI;

                // run 1.5 sec timer
                VLIB_AttachTimer(&ptCi->ueInfo.rrcResumeInfo.timerWaitE1InactNoti, ptCi, timInternalE1InactNotiDuringSNRelease_id);

                VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                    "[RRCInactive] Wait current state for RRC suspend and run timInternalE1InactNotiDuringSNRelease timer! (id:%u/val:%u)!\n",
                    ptCi->ueInfo.rrcResumeInfo.timerWaitE1InactNoti.id,
                    ptCi->ueInfo.rrcResumeInfo.timerWaitE1InactNoti.val);
            }
        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // step5. set stable state and stateCmd
    if (ctrlFlag & NRDC_FINALIZE_CTRL_SetBearerStatusToStable)
    {
        VCCM_SetStableState_CallSetup(ptCi);
        // collects drb-related stats
        if (ctrlFlag & NRDC_FINALIZE_CTRL_CollectStats)
        {
            // for Retainability, Served ue connection stats
            FnVCCB_FinalizeSaConnStat_AfterCleaningBearer(ptCi, ptCi->servCellNum, VCCB_STAT_RRC_CONNECTED);
        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // step6. Others#2;
    // The next operations shall not trigger other procedure with including change of state or stateCmd
    //      rather than event queuing or run-to-completion.
    if (ctrlFlag & NRDC_FINALIZE_CTRL_PrepareOthers)
    {
        // Trigger Location Report after SN Release
        int16_t status = VCCM_HandleLocationReportForMRDC(ptCi);
        if (status != GOOD)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_HandleLocationReportForMRDC ERROR in %s\n", __FUNCTION__);
        }

        FnVCCB_InitiateInterRatPccChange(ptCi);
        FnVCCB_InitiateCapabilityAwareCarrierChangePCC(ptCi, true);
    }
}

void FnVCCB_ClearSnMrdcInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!IsAvailable_MrdcInfo())
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "!IsAvailable_MrdcInfo() ERROR !\n");

        return;
    }

    // FGR-CC5200:FR760 FR770
    FnVCCB_NrdcSnConnInfoStatsCmd(ptCi, ptCi->servCellNum, ConnInfoStatsCmd_HoldingTimeStop);
    FnVCCB_NrdcSnConnInfoStatsCmd(ptCi, ptCi->servCellNum, ConnInfoStatsCmd_Decrease);

    FnVCCB_ClearAllMrdcRespFlag(ptCi);  // under construction

    VLIB_InitMrdcProperty(ptCi);

    FnVCCB_RefreshMrdcSelectedBearerType(ptCi);
}

bool FnVCCB_DoesNeedReconfigforMrdcAdd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (IsAvailable_MrdcInfo())
    {
        return false;
    }

    if (ptCi->numPDUSess == 0 || ptCi->state == STATE_E2C_capa)
    {
        return false;
    }

    if (VCCB_MR_BASED_NRDC_ADD_MODE(ptCi, ptCi->servCellNum))
    {
        if (IS_SUPPORT_NRDC(ptCi, ptCi->servCellNum))
        {
            if (ptCi->ueCapaEnquiry.rxUeCapaInfoBitFlag & UE_CAPA_REQ_RAT_TYPE_NR)
            {
                return true;
            }
        }
    }

    if (FnVCCB_IsNedcModeMode2(ptCi->servCellNum))
    {
        if (IsSupport_NEDC(ptCi, ptCi->servCellNum))
        {
            if ((ptCi->ueCapaEnquiry.rxUeCapaInfoBitFlag & UE_CAPA_REQ_RAT_TYPE_MRDC) &&
                (ptCi->ueCapaEnquiry.rxUeCapaInfoBitFlag & UE_CAPA_REQ_RAT_TYPE_EUTRA))

            {
                return true;
            }
        }
    }

    return false;
}

/**
 * @brief : This function is in charge of changing the reqBearerType used in MR-DC.
 */
void VLIB_setReqBearerTypeForMrDc(
    callInfo_type *ptCi, callDRBInfo_type *pDRBInfo, int type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pDRBInfo);
    VALID_E_POINT_CHECK_VOID(fnName);

    if (pDRBInfo->usage != CI_use)
    {
        return;
    }

    if (pDRBInfo->reqBearerType.val != static_cast<uint8_t>(type))
    {
        if (DBG->flag.statusDebug)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "DC Drb#%d sts(%s), br(%s), reqBr(%s->%s) in %s.\n", (int)pDRBInfo->dRBId,
                FnVCCB_GetStrSABearerStatus((enumSABearerStatus_type)pDRBInfo->drbStatus),
                FnVCCB_GetStrBearerType(pDRBInfo->bearerType.val), FnVCCB_GetStrBearerType(pDRBInfo->reqBearerType.val),
                FnVCCB_GetStrBearerType(type), fnName);
        }

        pDRBInfo->reqBearerType.val = static_cast<uint8_t>(type);
    }
}

/**
 * @brief : This function is in charge of changing the bearerType used in MR-DC.
 */
void VLIB_setBearerTypeForMrDc(
    callInfo_type *ptCi, callDRBInfo_type *pDRBInfo, int type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pDRBInfo);
    VALID_E_POINT_CHECK_VOID(fnName);

    if (pDRBInfo->usage != CI_use)
    {
        return;
    }

    if (pDRBInfo->bearerType.val != static_cast<uint8_t>(type))
    {
        if (DBG->flag.statusDebug)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "DC Drb#%d sts(%s), reqBr(%s), br(%s->%s) in %s.\n", (int)pDRBInfo->dRBId,
                FnVCCB_GetStrSABearerStatus((enumSABearerStatus_type)pDRBInfo->drbStatus),
                FnVCCB_GetStrBearerType((int)pDRBInfo->reqBearerType.val), FnVCCB_GetStrBearerType((int)pDRBInfo->bearerType.val),
                FnVCCB_GetStrBearerType(type), fnName);
        }

        pDRBInfo->bearerType.val = static_cast<uint8_t>(type);
    }
}

/**
 * @brief : This function is in charge of changing the bearerType used in MR-DC.
 */
void VLIB_setSelectedBearerTypeForMrDc(
    callInfo_type *ptCi, callDRBInfo_type *pDRBInfo, uint8_t flag, int32_t type, const char *fnName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pDRBInfo);
    VALID_E_POINT_CHECK_VOID(fnName);

    if (pDRBInfo->usage != CI_use)
    {
        return;
    }

    if (pDRBInfo->selectedBearerType.val != type || pDRBInfo->selectedBearerTypeFrozenFlag != flag)
    {
        if (DBG->flag.statusDebug || DBG->flag.logMrdcAddition)
        {
            VCCB_PRINT_CALL_LOG_MRDC(ptCi, "DC Drb#%d sts(%s), br(%s), frozen(%d->%d), selBr(%s->%s) in %s.\n",
                (int)pDRBInfo->dRBId, FnVCCB_GetStrSABearerStatus((enumSABearerStatus_type)pDRBInfo->drbStatus),
                FnVCCB_GetStrBearerType((int)pDRBInfo->bearerType.val), (int)pDRBInfo->selectedBearerTypeFrozenFlag, (int)flag,
                FnVCCB_GetStrBearerType((int)pDRBInfo->selectedBearerType.val), FnVCCB_GetStrBearerType(type), fnName);
        }

        pDRBInfo->selectedBearerTypeFrozenFlag = flag;
        pDRBInfo->selectedBearerType.val = static_cast<uint8_t>(type);
    }
}

/**
 * @brief : This function is used to cancel reqBearerType and return bearerType to its original type.
 */
void VLIB_CancelBearerTypeForMrDc(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    int drbIdx = 0;
    callDRBInfo_type *pDRBInfo = NULL;

    if (!IsAvailable_MrdcInfo())
    {
        return;
    }

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        pDRBInfo = &ptCi->drb[drbIdx];

        if (pDRBInfo->usage != CI_use) continue;

        // Return to the state before the change.
        SET_MRDC_REQ_BEARER_STATUS(ptCi, pDRBInfo, pDRBInfo->bearerType.val);
    }
}

bool FnVCCB_DoesPDUSessExistAtMN(callInfo_type *ptCi, uint16_t pduIdxInCall)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(pduIdxInCall, MAX_PDU_SESS_PER_CALL, false);

    int drbIdx = 0;
    callDRBInfo_type *pDRBInfo = NULL;

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        pDRBInfo = &ptCi->drb[drbIdx];

        if (pDRBInfo->usage != CI_use) continue;
        if (!pDRBInfo->selectedBearerTypeFrozenFlag) continue;

        if (pDRBInfo->pduIdxInCall == pduIdxInCall && ptCi->pduSess[pduIdxInCall].isE1Setupped &&
            (pDRBInfo->bearerType.val == MN_Term_SPLIT_Bearer || pDRBInfo->bearerType.val == MN_Term_MCG_Bearer))
        {
            return true;
        }
    }

    return false;
}

/**
 * @brief : This function is used to update reqBearerType to MN_Term_MCG_Bearer during MRDC Release Procedure.
 */
void VLIB_UpdateBearerTypeForMrDcRelease(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    int drbIdx = 0;
    callDRBInfo_type *pDRBInfo = NULL;

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        pDRBInfo = &ptCi->drb[drbIdx];

        if (pDRBInfo->usage != CI_use) continue;

        // Change SCG Bearer -> MCG Bearer
        SET_MRDC_REQ_BEARER_STATUS(ptCi, pDRBInfo, MN_Term_MCG_Bearer);
    }
}

/**
 * @brief : This function finally determines the bearer type.
 */
void VLIB_FinalizeBearerTypeForMrDc(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    callDRBInfo_type *pDRBInfo = NULL;
    int drbIdx = 0;

    if (!IsAvailable_MrdcInfo())
    {
        return;
    }

    if (IS_NRDC_MN(ptCi))
    {
        if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
        {
            FnVCCB_SetMrdcBearerTypeToStable(ptCi);

            return;
        }
    }

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        pDRBInfo = &ptCi->drb[drbIdx];

        if (pDRBInfo->usage != CI_use) continue;

        if (IS_NRDC_MN(ptCi) && pDRBInfo->reqBearerType.termPoint == TermPoint_Sn)
        {
            if (pDRBInfo->reqBearerType.val == SN_Term_SCG_Bearer)
            {
                SET_DRB_STATUS(ptCi, drbIdx, S_Null);
            }
            if (pDRBInfo->reqBearerType.val == SN_Term_SPLIT_Bearer)
            { // ex: In case of Inter-MN HO w/ or w/o SN change, there's no valid UL TNL info
                if (pDRBInfo->f1uUlInfo.numTLAbit == 0) 
                {
                    memcpy(&pDRBInfo->f1uUlInfo, &pDRBInfo->xNuUlInfo, sizeof(pDRBInfo->f1uUlInfo));
                }
            }

#ifdef IPC_TEST
            pDRBInfo->mCG_E1STOP = FALSE;
            pDRBInfo->sCG_E1STOP = FALSE;
#endif
        }

        // Change to the final determined value.
        if (IS_VALID_NrdcBearerType(pDRBInfo->reqBearerType))
        {
            SET_MRDC_BEARER_STATUS(ptCi, pDRBInfo, pDRBInfo->reqBearerType.val);
        }
    }
}

/**
 * @brief : This function finally determines the bearer type.
 */
int16_t VLIB_IsAnyBearerTypeChangingPerPDUSess(callInfo_type *ptCi, callPDUSessInfo_type *ptPDUSess)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptPDUSess);

    callDRBInfo_type *ptDrb = NULL;
    int drbIdx = 0, idx = 0;

    for (idx = 0; idx < MAX_DRB_PER_PDU_SESS; idx++)
    {
        drbIdx = ptPDUSess->drbIndex[idx];
        if (drbIdx >= MAX_DRB_PER_SA_CALL) continue;

        ptDrb = &ptCi->drb[drbIdx];

        if (ptDrb->usage != CI_use) continue;

        if (!ptDrb->selectedBearerTypeFrozenFlag) continue;

        if (ptDrb->ulPdcpPath == ptDrb->ulPdcpPathPrev)
        {
            //if (ptDrb->reqBearerType == ptDrb->bearerType)
            if (!IS_BearerType_Changing(*ptDrb))
            {
                continue;
            }
        }

        return GOOD;
    }

    return ERROR;
}

/**
 * @brief : This function will be called if MainUnit is switch-over.
 */
void VLIB_ReconfigMrdcInfoAfterSwitchOver(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->mrdcInfo.usage != CI_use)
    {
        return;
    }

    // init octetStringType variables
    ptCi->mrdcInfo.candidateCellInfoListMN.value = 0;
    ptCi->mrdcInfo.candidateCellInfoListMN.length = 0;

    ptCi->mrdcInfo.candidateCellInfoListSN.value = 0;
    ptCi->mrdcInfo.candidateCellInfoListSN.length = 0;

    ptCi->mrdcInfo.scgCellGrpConfig.value = 0;
    ptCi->mrdcInfo.scgCellGrpConfig.length = 0;

    ptCi->mrdcInfo.scgRBConfig.value = 0;
    ptCi->mrdcInfo.scgRBConfig.length = 0;

    ptCi->mrdcInfo.measResultSCG_EUTRA.value = 0;
    ptCi->mrdcInfo.measResultSCG_EUTRA.length = 0;

    ptCi->mrdcInfo.uLInformationTransferMRDC.value = 0;
    ptCi->mrdcInfo.uLInformationTransferMRDC.length = 0;

    ptCi->loadBasedNrdcScgBandSelectInfo.measResultList2NR.value = 0;
    ptCi->loadBasedNrdcScgBandSelectInfo.measResultList2NR.length = 0;

    return;
}

static void getBuffMgmtAllocState(enumBuffType buffType, uint32_t *pFreeCnt)
{
    buff1024NodeType *pNode = NULL;
    uint32_t nodeIdx = 0;

    switch (buffType)
    {
        case buffType1024:
            if (!gMrdcBuffCtrl.root1024)
            {
                LOGCMD("ERROR, gMrdcBuffCtrl.root1024 is NULL\n");
                return;
            }
            pNode = gMrdcBuffCtrl.root1024;
            break;

        case buffType2048:
            if (!gMrdcBuffCtrl.root2048)
            {
                LOGCMD("ERROR, gMrdcBuffCtrl.root2048 is NULL\n");
                return;
            }
            pNode = (buff1024NodeType *)gMrdcBuffCtrl.root2048;
            break;

        case buffType4096:
            if (!gMrdcBuffCtrl.root4096)
            {
                LOGCMD("ERROR, gMrdcBuffCtrl.root4096 is NULL\n");
                return;
            }
            pNode = (buff1024NodeType *)gMrdcBuffCtrl.root4096;
            break;

        case buffType9216:
            if (!gMrdcBuffCtrl.root9216)
            {
                LOGCMD("ERROR, gMrdcBuffCtrl.root9216 is NULL\n");
                return;
            }
            pNode = (buff1024NodeType *)gMrdcBuffCtrl.root9216;
            break;

        default:
            return;
    }

    uint32_t freeCnt = 0;
    while (pNode && nodeIdx < gMrdcBuffCtrl.noOfElem)
    {
        freeCnt++;
        pNode = pNode->next;
        nodeIdx++;
    }

    *pFreeCnt = freeCnt;
}

/**
 * @brief : dsh_GetMrdcBuffInfo ()
   display the information of buffMgmt
 */
int dsh_GetMrdcBuffInfo(int32_t argc, char *argv[])
{
    AUTO_TRACE_FUNC;
    (void)argc;
    (void)argv;

    int loop = 0, loop2 = 0;

    LOGCMD("\n");
    LOGCMD("=========================================================================================\n");
    LOGCMD("Buffer Size : %5d (KB)\n", (1024 + 2048 + 4096 + 9216) * gMrdcBuffCtrl.noOfElem / 1024);
    LOGCMD("initFlag    : %5d\n", gMrdcBuffCtrl.initFlag);
    LOGCMD("noOfElem    : %5d\n", gMrdcBuffCtrl.noOfElem);
    LOGCMD("-----------------------------------------------------------------------------------------\n");

    // pthread_mutex_t
    LOGCMD("mutex_Buff1024 : __lock(%d) __count(%d) __owner(%d) __kind(%d) __nusers(%d) __spins(%d)\n",
        gMrdcMutex.mutex_Buff1024.__data.__lock, gMrdcMutex.mutex_Buff1024.__data.__count,
        gMrdcMutex.mutex_Buff1024.__data.__owner, gMrdcMutex.mutex_Buff1024.__data.__kind,
        gMrdcMutex.mutex_Buff1024.__data.__nusers, gMrdcMutex.mutex_Buff1024.__data.__spins);
    LOGCMD("mutex_Buff2048 : __lock(%d) __count(%d) __owner(%d) __kind(%d) __nusers(%d) __spins(%d)\n",
        gMrdcMutex.mutex_Buff2048.__data.__lock, gMrdcMutex.mutex_Buff2048.__data.__count,
        gMrdcMutex.mutex_Buff2048.__data.__owner, gMrdcMutex.mutex_Buff2048.__data.__kind,
        gMrdcMutex.mutex_Buff2048.__data.__nusers, gMrdcMutex.mutex_Buff2048.__data.__spins);
    LOGCMD("mutex_Buff4096 : __lock(%d) __count(%d) __owner(%d) __kind(%d) __nusers(%d) __spins(%d)\n",
        gMrdcMutex.mutex_Buff4096.__data.__lock, gMrdcMutex.mutex_Buff4096.__data.__count,
        gMrdcMutex.mutex_Buff4096.__data.__owner, gMrdcMutex.mutex_Buff4096.__data.__kind,
        gMrdcMutex.mutex_Buff4096.__data.__nusers, gMrdcMutex.mutex_Buff4096.__data.__spins);
    LOGCMD("mutex_Buff9216 : __lock(%d) __count(%d) __owner(%d) __kind(%d) __nusers(%d) __spins(%d)\n",
        gMrdcMutex.mutex_Buff9216.__data.__lock, gMrdcMutex.mutex_Buff9216.__data.__count,
        gMrdcMutex.mutex_Buff9216.__data.__owner, gMrdcMutex.mutex_Buff9216.__data.__kind,
        gMrdcMutex.mutex_Buff9216.__data.__nusers, gMrdcMutex.mutex_Buff9216.__data.__spins);
    LOGCMD("-----------------------------------------------------------------------------------------\n");

    uint32_t freeCnt = 0;
    LOGCMD("buffNode1024 begin(%14p), buff1024 begin(%14p)\n", gMrdcBuffCtrl.buffNode1024, gMrdcBuffCtrl.buff1024);
    LOGCMD("buffNode2048 begin(%14p), buff2048 begin(%14p)\n", gMrdcBuffCtrl.buffNode2048, gMrdcBuffCtrl.buff2048);
    LOGCMD("buffNode4096 begin(%14p), buff4096 begin(%14p)\n", gMrdcBuffCtrl.buffNode4096, gMrdcBuffCtrl.buff4096);
    LOGCMD("buffNode9216 begin(%14p), buff9216 begin(%14p)\n", gMrdcBuffCtrl.buffNode9216, gMrdcBuffCtrl.buff9216);

    getBuffMgmtAllocState(buffType1024, &freeCnt);
    LOGCMD("root1024 (%14p, freeNodeCnt:%lu)\n", gMrdcBuffCtrl.root1024, freeCnt);
    getBuffMgmtAllocState(buffType2048, &freeCnt);
    LOGCMD("root2048 (%14p, freeNodeCnt:%lu)\n", gMrdcBuffCtrl.root2048, freeCnt);
    getBuffMgmtAllocState(buffType4096, &freeCnt);
    LOGCMD("root4096 (%14p, freeNodeCnt:%lu)\n", gMrdcBuffCtrl.root4096, freeCnt);
    getBuffMgmtAllocState(buffType9216, &freeCnt);
    LOGCMD("root9216 (%14p, freeNodeCnt:%lu)\n", gMrdcBuffCtrl.root9216, freeCnt);

    for (loop = 0; loop < MAX_BUFF_TYPE_FOR_STATS; loop++)
    {
        uint32_t attempt = 0, success = 0;
        for (loop2 = 0; loop2 < VCCB_CALL_THREAD_NUM; loop2++)
        {
            attempt += gMrdcBuffCtrl.allocStats[loop].attempt[loop2];
            success += gMrdcBuffCtrl.allocStats[loop].success[loop2];
        }
        LOGCMD("%s allocStats     : attempt(%lu) succ(%lu)\n", FnVCCB_GetStrBuffType((enumBuffType)loop), attempt,
            success);
        attempt = 0, success = 0;
        for (loop2 = 0; loop2 < VCCB_CALL_THREAD_NUM; loop2++)
        {
            attempt += gMrdcBuffCtrl.freeStats[loop].attempt[loop2];
            success += gMrdcBuffCtrl.freeStats[loop].success[loop2];
        }
        LOGCMD("%s freeStats      : attempt(%lu) succ(%lu)\n", FnVCCB_GetStrBuffType((enumBuffType)loop), attempt,
            success);
        LOGCMD("%s freeStatsAudit : attempt(%lu) succ(%lu)\n", FnVCCB_GetStrBuffType((enumBuffType)loop),
            gMrdcBuffCtrl.freeStatsAudit[loop].attempt, gMrdcBuffCtrl.freeStatsAudit[loop].success);
    }
    LOGCMD("-----------------------------------------------------------------------------------------\n");

    return GOOD;
}

int dsh_SetMrdcBuffInit(int32_t argc, char *argv[])
{
    AUTO_TRACE_FUNC;
    (void)argc;
    (void)argv;

    VLIB_FreeBuffMgmt();

    if (GOOD != VLIB_InitBuffMgmt())
    {
        LOGCMD("Fail, VLIB_InitBuffMgmt!\n");
    }
    else
    {
        LOGCMD("OK, MrdcBuffer is recomposited !\n");
    }

    return GOOD;
}

int dsh_SetMrdcMutexInit(int32_t argc, char *argv[])
{
    AUTO_TRACE_FUNC;

    (void)argc;
    (void)argv;

    int rc = 0;
    pthread_mutexattr_t attr;

    rc = pthread_mutexattr_init(&attr);
    if (rc)
    {
        LOGCMD("Fail(%d), pthread_mutexattr_init !\n", rc);

        return ERROR;
    }

    rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE_NP);
    if (rc)
    {
        LOGCMD("Fail(%d), pthread_mutexattr_settype !\n", rc);

        return ERROR;
    }

    rc = FnVCCB_InitMrdcMutexes(&attr);
    if (rc)
    {
        LOGCMD("Fail, VLIB_InitBuffMgmtMutexs !\n");
    }

    if (pthread_mutexattr_destroy(&attr))
    {
        LOGCMD("ERROR(%d) pthread_mutexattr_destroy !\n");
    }

    if (!rc)
    {
        LOGCMD("OK, mutex for MrdcBuffer is reinitialized !\n");

        return GOOD;
    }

    return ERROR;
}

void VLIB_DbgPrint_MrdcFeatureSetCombinationList(
    callInfo_type *ptCi, MrdcFeatureSetCombinationList_type *pMrdcFsCombList)
{
    AUTO_TRACE_FUNC;

    if (!DBG->flag.logMrdcFsCombList && !DBG->flag.logMrdcAddition)
    {
        return;
    }

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pMrdcFsCombList);

    int idx = 0, maxIdx = (int)(UMIN(pMrdcFsCombList->num, MAX_MRDC_FS_COMBS));
    char buff[4096];
    int offset = 0, buffSize = sizeof(buff) - 1;
    const int max_char_per_line = 1024;

    offset += snprintf(buff + offset, max_char_per_line, "MrdcFSCombList(num:%u)", pMrdcFsCombList->num);
    VCCB_PRINT_CALL_MSG(ptCi, "%s\n", buff);
    offset = 0;
    buff[0] = 0;

    for (idx = 0; idx < maxIdx; idx++)
    {
        MrdcFeatureSetCombination_type *pFsComb = &pMrdcFsCombList->mrdcFeatureSetCombination[idx];
        int idx2 = 0, maxIdx2 = (int)(UMIN(pFsComb->num, MAX_BANDS_PER_COMB));

        offset += snprintf(buff + offset, max_char_per_line, "[idx:%02d] MrdcFSComb(num:%u)", idx, pFsComb->num);
        VCCB_PRINT_CALL_MSG(ptCi, "%s\n", buff);
        offset = 0;
        buff[0] = 0;

        for (idx2 = 0; idx2 < maxIdx2; idx2++)
        {
            MrdcFeatureSetPerBand_type *pFs = &pFsComb->featureSetPerBand[idx2];
            int idx3 = 0, maxIdx3 = (int)(UMIN(pFs->num, MAX_NUM_FEATURESETSPERBAND));

            offset += snprintf(buff + offset, max_char_per_line, "..FS(n:%u,T:%d)|", pFs->num, pFs->ratType);

            for (idx3 = 0; idx3 < maxIdx3; idx3++)
            {
                if (offset + max_char_per_line >= buffSize) goto PRINT_BUFF;
                offset += snprintf(buff + offset, max_char_per_line, "(%2u,%2u)", pFs->featureSet[idx3].dlSetId,
                    pFs->featureSet[idx3].ulSetId);
            }

            VCCB_PRINT_CALL_MSG(ptCi, "%s\n", buff);
            offset = 0;
            buff[0] = 0;
        }
    }

PRINT_BUFF:
    VCCB_PRINT_CALL_MSG(ptCi, "%s\n", buff);
}

void VLIB_DbgPrint_MrdcBandCombList(callInfo_type *ptCi, bandCombinationList_type *pMrdcBandCombList)
{
    AUTO_TRACE_FUNC;

    if (!DBG->flag.logMrdcBandCombList && !DBG->flag.logMrdcAddition)
    {
        return;
    }

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pMrdcBandCombList);

    uint32_t idx = 0, maxIdx = UMIN(pMrdcBandCombList->num, MAX_BAND_COMBS);
    char buff[4096];
    int offset = 0, buffSize = sizeof(buff) - 1;
    const int max_char_per_line = 1024;

    offset += snprintf(buff + offset, max_char_per_line, "MrdcBandComList(n:%u)", pMrdcBandCombList->num);
    VCCB_PRINT_CALL_MSG(ptCi, "%s\n", buff);
    offset = 0;
    buff[0] = 0;

    for (idx = 0; idx < maxIdx; idx++)
    {
        BandCombination_type *pBandComb = &pMrdcBandCombList->bandCombination[idx];
        uint32_t idx2 = 0, maxIdx2 = UMIN(pBandComb->num, MAX_BANDS_PER_COMB);

        offset += snprintf(buff + offset, max_char_per_line, "[%02u] MrdcBandComb(n:%u,pc:%u,fsCombId:%u)", idx,
            pBandComb->num, pBandComb->powerClass_present, pBandComb->featureSetCombination);
        VCCB_PRINT_CALL_MSG(ptCi, "%s\n", buff);
        offset = 0;
        buff[0] = 0;

        offset += snprintf(buff + offset, max_char_per_line, "..");

        for (idx2 = 0; idx2 < maxIdx2; idx2++)
        {
            BandParameters_type *pBandParam = &pBandComb->band[idx2];

            if (offset + max_char_per_line >= buffSize) goto PRINT_BUFF;
            offset += snprintf(
                buff + offset, max_char_per_line, "(%d,%u)", pBandParam->ratType, pBandParam->freqBandIndicator);
        }

        VCCB_PRINT_CALL_MSG(ptCi, "%s\n", buff);
        offset = 0;
        buff[0] = 0;
    }

PRINT_BUFF:
    VCCB_PRINT_CALL_MSG(ptCi, "%s\n", buff);
}

// this api shall be called during storing UECapability.
void VLIB_DbgPrint_AllowedBCList(
    callInfo_type *ptCi, bandCombinationInfoList_type *pBandCombList, bool isNrdcBC, bool isBandComListBufferValid)
{
    AUTO_TRACE_FUNC;

    if (!DBG->flag.logMrdcAllowedBCList && !DBG->flag.logMrdcAddition)
    {
        return;
    }

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pBandCombList);

    bandCombinationList_type *pBCListBuff = NULL;
    if (isBandComListBufferValid)
    {
        pBCListBuff = VRIL_GetBandCombinationList(ptCi);
    }

    char buff[4096];
    int offset = 0, buffSize = sizeof(buff) - 1;
    const int max_char_per_line = 1024;
#define INIT_BUFF_POS() \
    do                  \
    {                   \
        offset = 0;     \
        buff[0] = 0;    \
    } while (0)

    VCCB_PRINT_CALL_MSG(ptCi, "-----------------------------------------\n");
    VCCB_PRINT_CALL_MSG(
        ptCi, "\tAllowedBCList(n:%u, pc:%u)\n", pBandCombList->nrofBandComb, pBandCombList->powerClass);
    VCCB_PRINT_CALL_MSG(ptCi, "-----------------------------------------\n");

    INIT_BUFF_POS();
    const uint32_t maxBandCombInfoIdx = UMIN(pBandCombList->nrofBandComb, 1U * MAX_NUM_BAND_COMB);
    for (uint32_t idx = 0; idx < maxBandCombInfoIdx; idx++)
    {
        bandCombinationInfo_type *pBandCombInfo = &pBandCombList->bandCombinationInfo[idx];

        // WGID:700278 UNREACHABLE_CODE - if (offset + max_char_per_line >= buffSize) goto PRINT_BUFF;
        VCCB_PRINT_CALL_MSG(ptCi, "[%02d] BandCombInfo(bandCombIdx:%u, pc_present:%u, mnIdx:%u)\n", idx,
            pBandCombInfo->bandCombinationIndex, pBandCombInfo->powerClassPresent, pBandCombInfo->selectedBandEntryMNIndex);

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        if (isBandComListBufferValid && pBCListBuff)
        {
            int bandBCIndex = pBandCombInfo->bandCombinationIndex - 1;
            if (bandBCIndex >= 0 && bandBCIndex < MAX_BAND_COMBS)
            {
                BandCombination_type *pBC = &pBCListBuff->bandCombination[bandBCIndex];
                const int maxBandIdx = MIN(pBC->num, MAX_BANDS_PER_COMB);

                offset += snprintf(buff + offset, max_char_per_line, "\tbandList> ");
                for (int idx2 = 0; idx2 < maxBandIdx; idx2++)
                {
                    BandParameters_type *pBandParam = &pBC->band[idx2];

                    if (offset + max_char_per_line >= buffSize) goto PRINT_BUFF;

                    if (pBandCombInfo->selectedBandEntryMNIndex == idx2)
                    {
                        offset += snprintf(buff + offset, max_char_per_line, "<");
                    }
                    offset += snprintf(buff + offset, max_char_per_line, "%u", pBandParam->freqBandIndicator);
                    if (pBandCombInfo->selectedBandEntryMNIndex == idx2)
                    {
                        offset += snprintf(buff + offset, max_char_per_line, ">");
                    }
                    offset += snprintf(buff + offset, max_char_per_line, " ");
                }

                VCCB_PRINT_CALL_MSG(ptCi, "%s <featureSetCombinationIndex:%u>\n", buff, pBC->featureSetCombination);
                INIT_BUFF_POS();
            }
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////

        // WGID:700278 UNREACHABLE_CODE - if (offset + max_char_per_line >= buffSize) goto PRINT_BUFF;
        offset += snprintf(buff + offset, max_char_per_line, "\tfsSetList> ");

        uint32_t noofAllowedFS = 0;
        const int maxIdx2 = MAX_NUM_FEATURESETSPERBAND;
        for (int idx2 = 0; idx2 < maxIdx2; idx2++)
        {
            if (!GETBIT_U8TABLE(pBandCombInfo->allowedFeatureSetsBitmask, idx2))
            {
                continue;
            }

            noofAllowedFS++;
            const int fsIdx = idx2 + 1;

            if (offset + max_char_per_line >= buffSize) goto PRINT_BUFF;
            offset += snprintf(buff + offset, max_char_per_line, "%d ", fsIdx);
        }

        VCCB_PRINT_CALL_MSG(ptCi, "%s <noofAllowedFS:%u>\n", buff, noofAllowedFS);
        INIT_BUFF_POS();
    }

PRINT_BUFF:
    if (offset > 0)
    {
        VCCB_PRINT_CALL_MSG(ptCi, "%s\n", buff);
        INIT_BUFF_POS();
        VCCB_PRINT_CALL_MSG(ptCi, "~~~ may be truncated ~~~~\n");
        INIT_BUFF_POS();
    }

    VCCB_PRINT_CALL_MSG(ptCi, "--------------------------\n");
    VCCB_PRINT_CALL_MSG(ptCi, "available band for pscell >\n");

    int maxBitMapIdx = 0;
    if (isNrdcBC)
    {
        maxBitMapIdx =
            sizeof(ptCi->ueInfo.allowedBCListNrBandIndiBitMap) / sizeof(ptCi->ueInfo.allowedBCListNrBandIndiBitMap[0]);
    }
    else
    {
        maxBitMapIdx = sizeof(ptCi->ueInfo.allowedBCListEutraBandIndiBitMap) /
                       sizeof(ptCi->ueInfo.allowedBCListEutraBandIndiBitMap[0]);
    }

    for (int bitMapIdx = 0; bitMapIdx < maxBitMapIdx; bitMapIdx++)
    {
        int bandIndicator = 0, chgLineCnt = 0;
        const int maxUint8bits = 8;

        if (!ptCi->ueInfo.allowedBCListNrBandIndiBitMap[bitMapIdx])  // union parameter
        {
            continue;
        }

        for (int bitPos = 0; bitPos < maxUint8bits; bitPos++)
        {
            if (GETBIT(ptCi->ueInfo.allowedBCListNrBandIndiBitMap[bitMapIdx], bitPos))
            {
                bandIndicator = bitMapIdx * 8 + bitPos;

                if (offset + max_char_per_line >= buffSize) break;

                offset += snprintf(buff + offset, max_char_per_line, " %d", bandIndicator);
                if (++chgLineCnt >= 16)
                {
                    VCCB_PRINT_CALL_MSG(ptCi, "%s\n", buff);
                    INIT_BUFF_POS();
                    chgLineCnt = 0;
                }
            }
        }
    }

    VCCB_PRINT_CALL_MSG(ptCi, "%s\n", buff);

    if (offset + max_char_per_line >= buffSize)
    {
        INIT_BUFF_POS();
        VCCB_PRINT_CALL_MSG(ptCi, "~~~ may be truncated ~~~~\n");
    }

    VCCB_PRINT_CALL_MSG(ptCi, "-----------------------------------------\n");

#undef INIT_BUFF_POS
}

/**
 *  @brief Enqueues Action for Xn SNode Release (by MN)
 *  @param callInfo_type *ptCi
 *  @param enumSNodeRelReasonType releaseReason
 *  @return int16_t GOOD/ERROR (1/-1)
 */
int16_t VLIB_EnqueueXnReleaseSNode(callInfo_type *ptCi, enumSNodeRelReasonType releaseReason)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    ptCi->mrdcInfo.queuedSNodeRelCause = releaseReason;

    if (MrdcRelCause_SCGFailure == releaseReason)  // NRDC_SCG_FAILURE_21D
    {
        ptCi->mrdcInfo.queuedScgFailCauseInfo = ptCi->nrdcScgFailCauseInfo;
    }

    status = VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_XN_RELEASE_SNODE);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "ENQUEUE_ACTION(XN_RELEASE_SNODE by MN) ERROR !!\n");

    return GOOD;
}

/*
 *  @brief Enqueues Action for SnNGuTNL Update
 *  @param callInfo_type *ptCi
 *  @return int16_t GOOD/ERROR (1/-1)
 */
int16_t FnVCCB_EnqueueSnNGuTNLUpdate(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "ENQUEUE_ACTION(ENQUEUE_ACTION_SN_ULTNL_UPDATE)!!\n");

    if (ERROR == VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_SN_ULTNL_UPDATE))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ENQUEUE_ACTION(ENQUEUE_ACTION_SN_ULTNL_UPDATE, XN_SNodeModificationRequest_id) ERROR !!\n");
        return ERROR;
    }

    return GOOD;
}

/*
 * @brief     Commit NEDC RadioBearerConfig when RRCReconfigurationComplete received
 * @param     ptCi : call context
 */
void VLIB_CommitRadioBearerConfigNEDC(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    int drbIdx = 0;
    callDRBInfo_type *ptDi = NULL;

    VALID_E_POINT_CHECK_VOID(ptCi);

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        ptDi = &ptCi->drb[drbIdx];
        if (CI_use != ptDi->usage)
        {
            continue;
        }

        if (MN_Term_SPLIT_Bearer != ptDi->bearerType.val)
        {
            continue;
        }

        ptDi->ulPdcpPathPrev = ptDi->ulPdcpPath;
    }
}

/****************************************************************************
 * Function      : VLIB_SetNeDcBearerStatusToIdle
 * Description   : This function will set bearer status to idle
 * Proc called   :
 * Proc calling  :
 * Input         :
 * Output        :
 * Update History:
 ***************************************************************************/
void VLIB_SetNeDcBearerStatusToIdle(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t drbIdx = 0;

    if (!IsAvailable_MrdcInfo())
    {
        if (DBG->flag.statusDebug)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Call is not NE-DC, skipping NeDc Bearer Status marking\n");
        }

        return;
    }

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        if (!IS_VALID_NODE(DRB_NODE, ptCi, &(ptCi->drb[drbIdx]))) continue;

        callDRBInfo_type *ptDi = &ptCi->drb[drbIdx];

        if (ptDi->usage != CI_use)
        {
            continue;
        }

        switch (ptDi->snDrbStatus)
        {
            case S_Setup:
                VCCB_PRINT_CALL_COMMENT(ptCi, " dRBId=%d goes Idle from S_Setup state.\n", ptDi->dRBId);
                break;
            case S_Modify:
                VCCB_PRINT_CALL_COMMENT(ptCi, " dRBId=%d goes Idle from S_Modify state.\n", ptDi->dRBId);
                break;
            case S_Release:
                VCCB_PRINT_CALL_COMMENT(ptCi, " dRBId=%d goes Idle from S_Release state.\n", ptDi->dRBId);
                if (MN_Term_SPLIT_Bearer == ptDi->bearerType.val)
                {
                    ptDi->bearerType.val = MN_Term_MCG_Bearer;
                }

                break;
            case S_FailToSetup:
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "dRBId=%d  invalid DRB status(S_FailToSetup) during DRB processing operation.\n", ptDi->dRBId);
                break;
            default:
                break;
        }

        ptDi->snDrbStatus = S_Idle;
        ptDi->prevSnDrbStatus = S_Idle;
    }

    return;
}

void FnVCCB_SetSelectedMrdcType(callInfo_type *ptCi, uint16_t cellNum, enumMrdcType_type selectedMrdcType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (selectedMrdcType < MRDC_END)
    {
        ptCi->selectedMrdcType = selectedMrdcType;

        return;
    }

    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    // succeeded mrdc type
    if (IsAvailable_MrdcInfo() && ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC_Flag &&
        ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC.nrofBandComb > 0)
    {
        if (ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC.mrdcType == MRDC_NEDC && IsSupport_NEDC_Foo() &&
            IsSupport_NEDC_Yang(cellNum))
        {
            ptCi->selectedMrdcType = MRDC_NEDC;
            VCCB_PRINT_CALL_INFORMATIVE(
                ptCi, "mrdc type(%d, NEDC) is succeeded! (cellNum:%u)\n", ptCi->selectedMrdcType, cellNum);

            return;
        }
        else if (ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC.mrdcType == MRDC_NRDC &&
                 IS_SUPPORT_NRDC_FOO() && IS_SUPPORT_NRDC_Yang(cellNum))
        {
            ptCi->selectedMrdcType = MRDC_NRDC;
            VCCB_PRINT_CALL_INFORMATIVE(
                ptCi, "mrdc type(%d, NRDC) is succeeded! (cellNum:%u)\n", ptCi->selectedMrdcType, cellNum);

            return;
        }
    }

    ptCi->selectedMrdcType = FnVCCB_DecideMrdcTypeForCell(ptCi, cellNum);
    VCCB_PRINT_CALL_MSG(ptCi, "selected mrdc type is (%d) (cellNum:%u)\n", ptCi->selectedMrdcType, cellNum);
}

void FnVCCB_SetMrdcBearerTypeToStable(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t drbIdx = 0;
    callDRBInfo_type *ptDi = NULL;

    if (!IsAvailable_MrdcInfo())  // Silent Ignore
    {
        return;
    }

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        ptDi = &ptCi->drb[drbIdx];

        if (ptDi->usage != CI_use) continue;
        if (!ptDi->selectedBearerTypeFrozenFlag) continue;
        if (ptDi->reqBearerType.val == ptDi->bearerType.val) continue;

        if (!IS_VALID_NrdcBearerType(ptDi->reqBearerType) || ptCi->stateCmd == MrdcSNAddPrepareFail_cmd)
        {
            SET_MRDC_REQ_BEARER_STATUS(ptCi, ptDi, INIT_BEARER_TYPE);
            VCCB_PRINT_CALL_ERROR(ptCi, "drb(idx:%u, id:%u) is Invalid reqBearerType(H'%02x) or SNAddPrepareFail(stateCmd:%d) in %s!\n",
                    drbIdx, ptDi->dRBId, ptDi->reqBearerType.val, ptCi->stateCmd, __func__);
            continue;
        }

        SET_MRDC_BEARER_STATUS(ptCi, ptDi, ptDi->reqBearerType.val);

        if (ptDi->reqBearerType.termPoint == TermPoint_Sn)
        {
            FnVCCB_SetSDAPatSNFlagOfQosFlow(ptCi, ptDi, VCCB_FLAG_ON);
            //ptDi->terminationPoint = SN_Terminated; Deprecated

            //if (!ptDi->snTermSplitFlag) // Deprecated
            if (ptDi->reqBearerType.val == SN_Term_SCG_Bearer)
            {
                SET_DRB_STATUS(ptCi, drbIdx, S_Null);
            }

#ifdef IPC_TEST
            ptDi->mCG_E1STOP = FALSE;
            ptDi->sCG_E1STOP = FALSE;
#endif
        }
        else
        {
            FnVCCB_SetSDAPatSNFlagOfQosFlow(ptCi, ptDi, VCCB_FLAG_OFF);
            //ptDi->terminationPoint = MN_Terminated; // Deprecated
        }
    }
}

void FnVCCB_FinalizePduChgforMrdc(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!IsAvailable_MrdcInfo())
    {
        return;
    }
    if (!IS_SELECTED_MRDC(MRDC_NRDC))
    {
        return;
    }

    if (IS_NRDC_SNREL_INVOKED(ptCi))
    {
        VLIB_FinalizeSNRelMrdc(ptCi, 0xff);
    }
    else
    {
        FnVCCB_TerminateOngoingMrdcProcedureAtMN(ptCi, NRDC_FINALIZE_CTRL_InitInstantInfo);

        if (FALSE == FnVCCB_CheckAllowedConcurrentNRDCandVoNR(ptCi, ptCi->servCellNum))
        {
            VCCB_PRINT_CALL_INFORMATIVE(
                ptCi, "VoNR and NR-DC is not allowed same time! MN-init SN Release procedure will be triggered!\n");

            if (ERROR == VLIB_EnqueueXnReleaseSNode(ptCi, MrdcRelCause_ConcurrentNotAllowed))
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "VLIB_EnqueueXnReleaseSNode fail\n");
            }
        }
        else
        {
            if (FnVCCB_NeedChangMnTermMcgToOther(ptCi))
            {
                VCCB_PRINT_CALL_DATA(ptCi, "enqueueAction w/ ENQUEUE_ACTION_BEARERTYPE_CHANGE !!\n");
                if (ERROR == VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_BEARERTYPE_CHANGE))
                {
                    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "VCCM_enqueueAction(ENQUEUE_ACTION_BEARERTYPE_CHANGE) fail\n");
                }
            }
        }
        VCCM_SetStableState_CallSetup(ptCi);
    }

    FnVCCB_ClearNeedModifyFlagforPDUSess(ptCi);
}

void FnVCCB_DecidePduSplitStatus(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    const uint32_t localStrSize = 300;

    char mrLogBuf[localStrSize];
    int strLen = 0;

    uint8_t pduCnt[End_PDU + 1];
    uint8_t pduId[End_PDU + 1][MAX_PDU_SESS_PER_CALL];

    memset(&pduCnt, 0x00, sizeof(pduCnt));
    memset(&pduId, 0x00, sizeof(pduId));

    uint8_t pdusessIdx = 0, pduSplitType = 0, pduSplitIdx = 0;

    LOGBUF(mrLogBuf, localStrSize, &strLen, "PDU split STATUS) ");
    for (pdusessIdx = 0; pdusessIdx < MAX_PDU_SESS_PER_CALL; pdusessIdx++)
    {
        callPDUSessInfo_type *pPi = &ptCi->pduSess[pdusessIdx];
        enumPduSplitStatus pduType = End_PDU;
        if (pPi->usage != CI_use) continue;

        if (FnVCCB_CanbeSplitPDUSession(ptCi, pPi))
        {
            pduType = Split_PDU;
        }
        else if (FnVCCB_IsAnySnTermPerPDU(ptCi, pPi, current_bearerType))
        {
            pduType = SNTerm_PDU;
        }
        else
        {
            pduType = MNTerm_PDU;
        }

        pduId[pduType][pduCnt[pduType]] = pdusessIdx;
        pduCnt[pduType]++;
        pPi->splitStatus = pduType;
    }

    for (pduSplitType = 0; pduSplitType <= End_PDU; pduSplitType++)
    {
        if (pduCnt[pduSplitType] == 0) continue;

        if (pduSplitType > 0)
        {
            LOGBUF(mrLogBuf, localStrSize, &strLen, ", ");
        }

        LOGBUF(mrLogBuf, localStrSize, &strLen, "%s:(", FnVCCB_GetStrPduSplitType((enumPduSplitStatus)pduSplitType));

        const uint32_t maxLen = MIN(pduCnt[pduSplitType], MAX_PDU_SESS_PER_CALL);

        for (pduSplitIdx = 0; pduSplitIdx < maxLen; pduSplitIdx++)
        {
            LOGBUF(mrLogBuf, localStrSize, &strLen, "%u", pduId[pduSplitType][pduSplitIdx]);

            if (pduSplitIdx < (maxLen - 1))
            {
                LOGBUF(mrLogBuf, localStrSize, &strLen, ",");
            }
        }

        LOGBUF(mrLogBuf, localStrSize, &strLen, ")");
    }

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "%.*s\n", localStrSize, mrLogBuf);
}

bool FnVCCB_CanbeSplitPDUSessionfromScgNonSplit(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (!IsAvailable_MrdcInfo())
    {
        return false;
    }
    if (!IS_NRDC_MN(ptCi))
    {
        return false;
    }

    if (IS_NRDC_SNREL_INVOKED(ptCi))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Split bcz SNREL has already been in progress in %s!\n", __FUNCTION__);
        return false;
    }

    uint8_t pdusessIdx = 0;
    for (pdusessIdx = 0; pdusessIdx < MAX_PDU_SESS_PER_CALL; pdusessIdx++)
    {
        callPDUSessInfo_type *pPi = &ptCi->pduSess[pdusessIdx];

        if (pPi->usage != CI_use) continue;

        if (FnVCCB_CanbeSplitPDUSession(ptCi, pPi) && (SNTerm_PDU == pPi->splitStatus))
        {
            return true;
        }
    }

    return false;
}

bool FnVCCB_CanbeSplitPDUSession(callInfo_type *ptCi, callPDUSessInfo_type *pPi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pPi, false);

    bool currMnTerm = false, currSnTerm = false, willBeMnTerm = false, willBeSnTerm = false;
    uint8_t idx = 0;

    for (idx = 0; idx < MAX_DRB_PER_PDU_SESS; idx++)
    {
        uint16_t drbIdx = pPi->drbIndex[idx];

        if (drbIdx >= MAX_DRB_PER_SA_CALL) continue;

        callDRBInfo_type *pDi = &ptCi->drb[drbIdx];

        if (pDi->usage != CI_use) continue;
        if (!pDi->selectedBearerTypeFrozenFlag) continue;

        if (pDi->bearerType.val == pDi->reqBearerType.val)
        {
            switch (pDi->bearerType.val)
            {
                case MN_Term_MCG_Bearer:
                case MN_Term_SPLIT_Bearer:
                //case MN_Term_SCG_Bearer: // Not Supported
                    currMnTerm = true;
                    break;

                case SN_Term_SPLIT_Bearer:
                case SN_Term_SCG_Bearer:
                //case SN_Term_MCG_Bearer: // Not Supported
                    currSnTerm = true;
                    break;

                default:
                    break;
            }
        }
        else if (pDi->bearerType.val == MN_Term_MCG_Bearer && pDi->reqBearerType.val == INIT_BEARER_TYPE)
        {
            currMnTerm = true;
        }
        else if (pDi->bearerType.val == MN_Term_MCG_Bearer && pDi->reqBearerType.termPoint == TermPoint_Sn)
        {
            willBeSnTerm = true;
        }
        else if (pDi->bearerType.val == MN_Term_MCG_Bearer && pDi->reqBearerType.val == MN_Term_SPLIT_Bearer)
        {
            currMnTerm = true;
        }
        else if (pDi->bearerType.termPoint == TermPoint_Sn && pDi->reqBearerType.val == MN_Term_MCG_Bearer)
        {
            willBeMnTerm = true;
        }
        else if (pDi->bearerType.val == MN_Term_SPLIT_Bearer && pDi->reqBearerType.val == MN_Term_MCG_Bearer)
        {
            currMnTerm = true;
        }
    }

    return (currMnTerm || willBeMnTerm) && (currSnTerm || willBeSnTerm);
}

// MN will used this api to check whether a specific pudSession has been already setup in SN.
bool FnVCCB_IsNewPDUSessAtSN(callInfo_type *ptCi, callPDUSessInfo_type *pPi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pPi, false);

    bool mnTermSplit = FnVCCB_IsAnySpecificBearerPerPDUSess(ptCi, pPi, MN_Term_SPLIT_Bearer);
    bool snTerm = !!FnVCCB_ExistSNTermBearerInPdu(ptCi, pPi);

    return !(mnTermSplit || snTerm);
}

// MN will use this api whether PDUSessionRelease is required instead of PUDSessionModification according to its the
// state os qosflows
bool FnVCCB_NeedSNPDUSessTobeReleasedUnsolicitedly(callInfo_type *ptCi, callPDUSessInfo_type *ptPi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptPi, false);

    uint16_t qosFlowIdxInPdu = 0;
    for (qosFlowIdxInPdu = 0; qosFlowIdxInPdu < MAX_QOS_FLOW_PER_PDU_SESS; qosFlowIdxInPdu++)
    {
        if (ptPi->qosFlowIndex[qosFlowIdxInPdu] >= MAX_QOS_FLOW_PER_CALL) continue;

        qosFlowInfo_type *ptQi = &ptCi->qosFlow[ptPi->qosFlowIndex[qosFlowIdxInPdu]];
        if (ptQi->drbIdxInCall >= MAX_DRB_PER_SA_CALL) continue;

        callDRBInfo_type *ptDi = &ptCi->drb[ptQi->drbIdxInCall];
        if (ptDi->usage != CI_use) continue;
        if (!ptDi->selectedBearerTypeFrozenFlag) continue;
        if (ptDi->bearerType.val != MN_Term_SPLIT_Bearer && ptDi->bearerType.termPoint != TermPoint_Sn)
        {
            continue;
        }

        if (ptQi->usage != CI_use) continue;

        if (ptQi->qosFlowStatus != S_Release)
        {
            return false;
        }
    }

    return true;
}

// during bearerType change from mn-term-scg to sn-term bearer
bool FnVCCB_DoesPDUSessNeedTobeReleasedAtMnUp(callInfo_type *ptCi, callPDUSessInfo_type *ptPi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptPi, false);

    if (ptPi->usage != CI_use)
    {
        return false;
    }

    if (!IS_NRDC_MN(ptCi))
    {
        return false;
    }

    uint16_t drbIdxInPdu = 0, drbIdxInCall = 0;
    for (drbIdxInPdu = 0; drbIdxInPdu < MAX_DRB_PER_PDU_SESS; drbIdxInPdu++)
    {
        drbIdxInCall = ptPi->drbIndex[drbIdxInPdu];
        if (drbIdxInCall >= MAX_DRB_PER_SA_CALL) continue;

        callDRBInfo_type *ptDi = &ptCi->drb[drbIdxInCall];
        if (ptDi->usage != CI_use) continue;
        if (!ptDi->selectedBearerTypeFrozenFlag) continue;

        if ((ptDi->bearerType.val == MN_Term_MCG_Bearer || ptDi->bearerType.val == MN_Term_SPLIT_Bearer) &&
            ptDi->reqBearerType.termPoint != TermPoint_Sn)
        {
            return false;
        }
        else if (ptDi->reqBearerType.val ==
                 MN_Term_MCG_Bearer)  // Actually this condition statement will be unreachable because this api will be
                                      // called during offloading(mn-term-scg => others)
        {
            return false;
        }
    }

    return true;
}

void FnVCCB_ClearQosflowMrdcFlagPerType(callInfo_type *ptCi, uint8_t flagType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(flagType, MRDC_FLAG_END);

    uint8_t idx = 0;
    for (idx = 0; idx < MAX_QOS_FLOW_PER_CALL; idx++)
    {
        qosFlowInfo_type *ptQi = &ptCi->qosFlow[idx];
        if (ptQi->usage != CI_use) continue;

        switch (flagType)
        {
            case MRDC_FLAG_RESP:
                ptQi->mrdcFlag.respFlag = 0;
                break;

            case MRDC_FLAG_EVENT:
                ptQi->mrdcFlag.qosFlowEventFlag.val = 0; // union
                break;

            case MRDC_FLAG_ALL:
                memset(&ptQi->mrdcFlag, 0, sizeof(ptQi->mrdcFlag));
                break;

            default:
                // Unreachable

                VCCB_PRINT_CALL_ERROR(ptCi, "Invalid flagType(%d) in %s!\n", flagType, __func__);
                return;
        }
    }
}

void FnVCCB_ClearDrbMrdcFlagPerType(callInfo_type *ptCi, uint8_t flagType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(flagType, MRDC_FLAG_END);

    uint8_t idx = 0;
    for (idx = 0; idx < MAX_DRB_PER_SA_CALL; idx++)
    {
        callDRBInfo_type *ptDi = &ptCi->drb[idx];
        if (ptDi->usage != CI_use) continue;

        switch (flagType)
        {
            case MRDC_FLAG_RESP:
                ptDi->mrdcFlag.respFlag = 0;
                break;

            case MRDC_FLAG_EVENT:
                ptDi->mrdcFlag.drbEventFlag.val = 0; // union
                break;

            case MRDC_FLAG_ALL:
                memset(&ptDi->mrdcFlag, 0, sizeof(ptDi->mrdcFlag));
                break;

            default:
                // Unreachable

                VCCB_PRINT_CALL_ERROR(ptCi, "Invalid flagType(%d) in %s!\n", flagType, __func__);
                return;
        }
    }
}

void FnVCCB_ClearPDUSessMrdcFlagPerType(callInfo_type *ptCi, uint8_t flagType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(flagType, MRDC_FLAG_END);

    uint8_t pduSessIdx;
    for (pduSessIdx = 0; pduSessIdx < MAX_PDU_SESS_PER_CALL; pduSessIdx++)
    {
        callPDUSessInfo_type *pPi = &ptCi->pduSess[pduSessIdx];
        if (pPi->usage != CI_use) continue;

        pPi->mrdcFlag.respFlag = 0;
        switch (flagType)
        {
            case MRDC_FLAG_RESP:
                pPi->mrdcFlag.respFlag = 0;
                break;

            case MRDC_FLAG_EVENT:
                pPi->mrdcFlag.pduSessEventFlag.val = 0; // union
                break;

            case MRDC_FLAG_ALL:
                memset(&pPi->mrdcFlag, 0, sizeof(pPi->mrdcFlag));
                break;

            default:
                // Unreachable

                VCCB_PRINT_CALL_ERROR(ptCi, "Invalid flagType(%d) in %s!\n", flagType, __func__);
                return;
        }
    }
}

void FnVCCB_ClearAllMrdcRespFlag(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    FnVCCB_ClearQosflowMrdcFlagPerType(ptCi, MRDC_FLAG_RESP);
    FnVCCB_ClearPDUSessMrdcFlagPerType(ptCi, MRDC_FLAG_RESP);
    FnVCCB_ClearDrbMrdcFlagPerType(ptCi, MRDC_FLAG_RESP);
}

void FnVCCB_ClearAllMrdcFlags(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    FnVCCB_ClearQosflowMrdcFlagPerType(ptCi, MRDC_FLAG_ALL);
    FnVCCB_ClearPDUSessMrdcFlagPerType(ptCi, MRDC_FLAG_ALL);
    FnVCCB_ClearDrbMrdcFlagPerType(ptCi, MRDC_FLAG_ALL);
}

void FnVCCB_ClearMrdcRespFlagforBothQosflowsAndDrbsPerPDU(callInfo_type *ptCi, callPDUSessInfo_type *ptPi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptPi);

    uint16_t qosflowIdxInPdu = 0, drbIdxInPdu = 0, drbIdxInCall = 0;

    for (qosflowIdxInPdu = 0; qosflowIdxInPdu < MAX_QOS_FLOW_PER_PDU_SESS; qosflowIdxInPdu++)
    {
        if (ptPi->qosFlowIndex[qosflowIdxInPdu] >= MAX_QOS_FLOW_PER_CALL) continue;

        qosFlowInfo_type *ptQi = &ptCi->qosFlow[ptPi->qosFlowIndex[qosflowIdxInPdu]];

        if (ptQi->usage != CI_use) continue;

        ptQi->mrdcFlag.respFlag = 0;
    }

    for (drbIdxInPdu = 0; drbIdxInPdu < MAX_DRB_PER_PDU_SESS; drbIdxInPdu++)
    {
        drbIdxInCall = ptPi->drbIndex[drbIdxInPdu];

        if (drbIdxInCall >= MAX_DRB_PER_SA_CALL) continue;

        callDRBInfo_type *ptDi = &ptCi->drb[drbIdxInCall];

        if (ptDi->usage != CI_use) continue;

        ptDi->mrdcFlag.respFlag = 0;
    }
}
void FnVCCB_SetQosflowMrdcRespFlagPerDRBforSNModify(callInfo_type *ptCi, callDRBInfo_type *pDi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pDi);

    if (!(GET_SNTERM_DRB_TO_BE_SETUP_TO_SN_FLAG(pDi->mrdcFlag.respFlag) ||
            GET_SNTERM_DRB_TO_BE_MODIFIED_TO_SN_FLAG(pDi->mrdcFlag.respFlag) ||
            GET_SNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(pDi->mrdcFlag.respFlag) || pDi->drbStatus == S_Null ||
            pDi->drbStatus == S_Null_Release))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid mrdcFlag(%u) of DRB(drbID:%u)!\n", pDi->mrdcFlag.respFlag, pDi->dRBId);

        return;
    }

    uint8_t qIdx = 0;
    for (qIdx = 0; qIdx < MAX_QOS_FLOW_PER_DRB; qIdx++)
    {
        uint16_t qosflowIndex = pDi->qosFlowIndex[qIdx];
        if (qosflowIndex >= MAX_QOS_FLOW_PER_CALL) continue;

        qosFlowInfo_type *pQi = &ptCi->qosFlow[qosflowIndex];

        if (pQi->usage != CI_use) continue;

        if (GET_SNTERM_DRB_TO_BE_SETUP_TO_SN_FLAG(pDi->mrdcFlag.respFlag))
        {
            ON_QOSFLOW_TO_BE_SETUP_TO_SN_FLAG(pQi->mrdcFlag.respFlag);
        }
        else if (GET_SNTERM_DRB_TO_BE_MODIFIED_TO_SN_FLAG(pDi->mrdcFlag.respFlag))
        {
            if (pQi->qosFlowStatus == S_Modify)
            {
                ON_QOSFLOW_TO_BE_MODIFIED_TO_SN_FLAG(pQi->mrdcFlag.respFlag);
            }
            else if (pQi->qosFlowStatus == S_Release)
            {
                ON_QOSFLOW_TO_BE_RELEASED_TO_SN_FLAG(pQi->mrdcFlag.respFlag);
            }
        }
        else if (GET_SNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(pDi->mrdcFlag.respFlag))
        {  // Not support in current scope; TBD, all qosflow in a snterm-drb are going to be deleted.
            ON_QOSFLOW_TO_BE_RELEASED_TO_SN_FLAG(pQi->mrdcFlag.respFlag);
        }
        else if (pDi->drbStatus == S_Null)
        {
            if (pQi->qosFlowStatus == S_Modify)
            {
                ON_QOSFLOW_TO_BE_MODIFIED_TO_SN_FLAG(pQi->mrdcFlag.respFlag);
            }
            else if (pQi->qosFlowStatus == S_Release)
            {
                ON_QOSFLOW_TO_BE_RELEASED_TO_SN_FLAG(pQi->mrdcFlag.respFlag);
            }
        }
        else if (pDi->drbStatus == S_Null_Release)
        {
            ON_QOSFLOW_TO_BE_RELEASED_TO_SN_FLAG(pQi->mrdcFlag.respFlag);
        }
    }
}

void FnVCCB_SetDrbMrdcRespFlagsForSNModify(callInfo_type *ptCi, uint8_t *pPduSessInSn)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pPduSessInSn);

    uint8_t drbIdx = 0;
    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        callDRBInfo_type *pDi = &ptCi->drb[drbIdx];

        if (pDi->usage != CI_use) continue;

        pDi->mrdcFlag.respFlag = 0;

        if (pDi->pduIdxInCall < MAX_PDU_SESS_PER_CALL)
        {
            if (pDi->bearerType.val == MN_Term_SPLIT_Bearer || pDi->bearerType.termPoint == TermPoint_Sn)
            {
                pPduSessInSn[pDi->pduIdxInCall]++;
            }
        }

        switch (pDi->drbStatus)
        {
            case S_Idle:
                if (FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_BearerTypeChange) == true &&
                    pDi->bearerType.val == MN_Term_MCG_Bearer &&
                    (pDi->reqBearerType.val == MN_Term_SPLIT_Bearer || pDi->reqBearerType.termPoint == TermPoint_Sn))
                {
                    if (pDi->reqBearerType.val == MN_Term_SPLIT_Bearer)
                    {
                        ON_MNTERM_DRB_TO_BE_SETUP_TO_SN_FLAG(pDi->mrdcFlag.respFlag);
                    }
                    else
                    {
                        ON_SNTERM_DRB_TO_BE_SETUP_TO_SN_FLAG(pDi->mrdcFlag.respFlag);
                        FnVCCB_SetQosflowMrdcRespFlagPerDRBforSNModify(ptCi, pDi);
                    }
                }
                break;

            case S_Modify:
                if (FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_PDUSessionChange) == true)
                {
                    if (pDi->bearerType.val == MN_Term_SPLIT_Bearer)
                    {
                        ON_MNTERM_DRB_TO_BE_MODIFIED_TO_SN_FLAG(pDi->mrdcFlag.respFlag);
                    }
                    else if (pDi->bearerType.termPoint == TermPoint_Sn)
                    {
                        ON_SNTERM_DRB_TO_BE_MODIFIED_TO_SN_FLAG(pDi->mrdcFlag.respFlag);
                        FnVCCB_SetQosflowMrdcRespFlagPerDRBforSNModify(ptCi, pDi);
                    }
                }
                break;

            case S_Release:
                if (FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_PDUSessionChange) == true)
                {
                    if (pDi->bearerType.val == MN_Term_SPLIT_Bearer)
                    {
                        ON_MNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(pDi->mrdcFlag.respFlag);
                    }
                    //else if (pDi->bearerType == SN_Term_Undetermined && pDi->snTermSplitFlag)
                    else if (pDi->bearerType.val == SN_Term_SPLIT_Bearer)
                    {
                        ON_SNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(pDi->mrdcFlag.respFlag);
                        FnVCCB_SetQosflowMrdcRespFlagPerDRBforSNModify(ptCi, pDi);
                    }
                }
                break;

            case S_Null:
            case S_Null_Release:
                if (FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_PDUSessionChange) == true)
                {
                    //if (pDi->bearerType == SN_Term_Undetermined)
                    if (pDi->bearerType.val == SN_Term_SCG_Bearer)
                    {
                        FnVCCB_SetQosflowMrdcRespFlagPerDRBforSNModify(ptCi, pDi);
                    }
                    else
                    {
                        VCCB_PRINT_CALL_ERROR(ptCi,
                            "Invalid bearerType(%d) for drbStatus(%d vs S_Null | S_Null_Release) Error in %s!\n",
                            pDi->bearerType.val, pDi->drbStatus, __FUNCTION__);
                    }
                }
                break;

            case S_Setup:
            default:
                break;
        }
    }
}

void FnVCCB_SetPDUSessMrdcRespFlagForSNModify(callInfo_type *ptCi, uint8_t *pPduSessInSn)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pPduSessInSn);

    uint8_t pdusessIdx = 0;
    for (pdusessIdx = 0; pdusessIdx < MAX_PDU_SESS_PER_CALL; pdusessIdx++)
    {
        callPDUSessInfo_type *pPi = &ptCi->pduSess[pdusessIdx];

        if (pPi->usage != CI_use) continue;

        OFF_PDUSESS_TO_BE_ADDED_TO_SN_FLAG(pPi->mrdcFlag.respFlag);
        OFF_PDUSESS_TO_BE_MODIFIED_TO_SN_FLAG(pPi->mrdcFlag.respFlag);
        OFF_PDUSESS_TO_BE_RELEASED_TO_SN_FLAG(pPi->mrdcFlag.respFlag);

        switch (pPi->pduSessStatus)
        {
            case S_Idle:
                if (FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_BearerTypeChange) &&
                        FnVCCB_IsAnyBearerInOffloadingPerPDUSess(ptCi, pPi))
                {
                    if (pPduSessInSn[pdusessIdx] > 0)
                    {
                        ON_PDUSESS_TO_BE_MODIFIED_TO_SN_FLAG(pPi->mrdcFlag.respFlag);
                    }
                    else
                    {
                        ON_PDUSESS_TO_BE_ADDED_TO_SN_FLAG(pPi->mrdcFlag.respFlag);
                    }
                }
                break;

            case S_Modify:
                if (FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_PDUSessionChange) == true &&
                    pPduSessInSn[pdusessIdx] > 0)
                {
                    ON_PDUSESS_TO_BE_MODIFIED_TO_SN_FLAG(pPi->mrdcFlag.respFlag);

                    if (FnVCCB_NeedSNPDUSessTobeReleasedUnsolicitedly(
                            ptCi, pPi))  // to prevent from being dummy pduSession without any qosflows
                    {
                        VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                            "PDUSess[state:%d, id:%u] will be released bcz its all qosflows are to be released!!\n",
                            pPi->pduSessStatus, pPi->pduSessId);

                        OFF_PDUSESS_TO_BE_MODIFIED_TO_SN_FLAG(pPi->mrdcFlag.respFlag);
                        FnVCCB_ClearMrdcRespFlagforBothQosflowsAndDrbsPerPDU(ptCi, pPi);
                        ON_PDUSESS_TO_BE_RELEASED_TO_SN_FLAG(pPi->mrdcFlag.respFlag);
                    }
                }
                break;

            case S_Release:
                if (FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_PDUSessionChange) == true &&
                    pPduSessInSn[pdusessIdx] > 0)
                {
                    ON_PDUSESS_TO_BE_RELEASED_TO_SN_FLAG(pPi->mrdcFlag.respFlag);
                }
                break;

            case S_Setup:
            default:
                break;
        }
    }
}

void FnVCCB_SetMrdcRespFlagsForSNModify(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t pduSessInSn[MAX_PDU_SESS_PER_CALL] = {0};

    if (!IS_NRDC_MN(ptCi))
    {
        return;
    }

    FnVCCB_ClearQosflowMrdcFlagPerType(ptCi, MRDC_FLAG_RESP);

    FnVCCB_SetDrbMrdcRespFlagsForSNModify(ptCi, pduSessInSn);

    FnVCCB_SetPDUSessMrdcRespFlagForSNModify(ptCi, pduSessInSn);
}

void FnVCCB_ClearInstantFlagOfMrdcInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    INIT_MRDC_PROCEDURE(ptCi);

    ptCi->mrdcInfo.snRejCause.present = 0;

    CLEAR_MRDC_XN_RCVINDICATOR_FLAG();
    CLEAR_MRDC_XN_SNDINDICATOR_FLAG();
    ptCi->mrdcInfo.needModify.value = 0;

    ptCi->mrdcInfo.sNodeRelCause = MrdcRelCause_NoCause;

    // This value must not be initialized for queuing events.
    // ptCi->mrdcInfo.queuedSNodeRelCause = MrdcRelCause_NoCause;

    uint8_t idx;
    for (idx = 0; idx < MAX_DRB_PER_SA_CALL; idx++)
    {
        ptCi->mrdcInfo.e1MrdcCtrlFlag[idx].value = 0;
    }

    ptCi->mrdcInfo.sNodeRelReqSkipSendFlag = 0;
    ptCi->mrdcInfo.sNodeRelRqrdRcvFlag = 0;
}

int16_t FnVCCB_NeedSnNGuUlTnlUpdate(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint8_t pduSessIdx;
    for (pduSessIdx = 0; pduSessIdx < MAX_PDU_SESS_PER_CALL; pduSessIdx++)
    {
        callPDUSessInfo_type *pPi = &ptCi->pduSess[pduSessIdx];
        if (pPi->usage != CI_use) continue;

        if (pPi->snNGuUlInfo.fNeedModify)
        {
            return GOOD;
        }
    }

    return ERROR;
}

bool FnVCCB_NeedNGuUlTnlUpdate(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    for (int pduSessIdx = 0; pduSessIdx < MAX_PDU_SESS_PER_CALL; pduSessIdx++)
    {
        callPDUSessInfo_type &rPdu = ptCi->pduSess[pduSessIdx];
        if (rPdu.usage != CI_use) continue;

        if (rPdu.nGuUlInfo.fNeedModify)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[NGU-UL-TNL] Changed for PDU(%d)\n", rPdu.pduSessId);
            return true;
        }
    }

    return false;
}

// [23.003]
// The SD field has a reserved value "no SD value associated with the SST" defined as hexadecimal FFFFFF.
// In certain protocols, the SD field is not included to indicate that no SD value is associated with the SST.
bool FnVCCB_IsSameSnssaiforMrdc(bool check_strict_sd, callSNSSAI_type sNssai_yang, callSNSSAI_type sNssai_internalDB)
{
    // FGR-CC5200:FR94
    if (check_strict_sd)
    {
        if (sNssai_yang.sstSd != sNssai_internalDB.sstSd)
        {
            return false;
        }
    }
    else
    {
        if (sNssai_yang.sst != sNssai_internalDB.sst)
        {
            return false;
        }

        if (sNssai_yang.sd != ASTERISK_SD && sNssai_yang.sstSd != sNssai_internalDB.sstSd)
        {
            return false;
        }
    }

    return true;
}

void FnVCCB_SetReqBearerTypeforFallback(callInfo_type *ptCi, bool isSnRel)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t idx = 0;

    if (isSnRel)  // drb based fallback
    {
        if (MRDC_SNREL_OPR_XN_Deletion == GET_MRDC_PROCEDURE_SNREL_OPRTYPE(ptCi) ||
            MRDC_SNREL_OPR_XN_ImplicitlyDeletion == GET_MRDC_PROCEDURE_SNREL_OPRTYPE(ptCi))
        {
            return;
        }
    }

    for (idx = 0; idx < MAX_DRB_PER_SA_CALL; idx++)
    {
        callDRBInfo_type *pDi = &ptCi->drb[idx];

        if (pDi->usage != CI_use) continue;
        if (!pDi->selectedBearerTypeFrozenFlag) continue;
        if (pDi->bearerType.val == MN_Term_MCG_Bearer) continue;

        if (!isSnRel)  // drb based fallback
        {
            if ((pDi->bearerType.val == MN_Term_SPLIT_Bearer &&
                    GET_MNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(pDi->mrdcFlag.respFlag)) ||
                (pDi->bearerType.termPoint == TermPoint_Sn &&
                    GET_SNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(pDi->mrdcFlag.respFlag)))
            {
                SET_MRDC_REQ_BEARER_STATUS(ptCi, pDi, MN_Term_MCG_Bearer);
            }
            else
            {
                VCCB_PRINT_CALL_COMMENT(ptCi,
                    "drb(idx(%u), id(%u)) is skipped due to <bearerType(%d), mrdcFlag.respFlag(%u)> in %s\n", idx,
                    pDi->dRBId, pDi->bearerType.val, pDi->mrdcFlag.respFlag, __func__);
            }
            continue;
        }
        SET_MRDC_REQ_BEARER_STATUS(ptCi, pDi, MN_Term_MCG_Bearer);
    }
}

void FnVCCB_SetReqBearerTypeforOffloading(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t idx = 0;
    for (idx = 0; idx < MAX_DRB_PER_SA_CALL; idx++)
    {
        callDRBInfo_type *pDi = &ptCi->drb[idx];

        if (pDi->usage != CI_use) continue;
        if (!pDi->selectedBearerTypeFrozenFlag) continue;

        if (pDi->reqBearerType.val == INIT_BEARER_TYPE)
        {
            pDi->reqBearerType.val = pDi->selectedBearerType.val;
        }
    }
}

void FnVCCB_SetSNRelOprType(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    switch (ptCi->mrdcInfo.sNodeRelCause)
    {
        case MrdcRelCause_NoCause:
        case MrdcRelCause_InactivityRelease:
        case MrdcRelCause_CallRelease:
        case MrdcRelCause_CellAdministration:
        case MrdcRelCause_EpsFallBack:
        case MrdcRelCause_EmergencyFallBack:
            SET_MRDC_PROCEDURE_SNREL_OPRTYPE(ptCi, MRDC_SNREL_OPR_XN_ImplicitlyDeletion);
            break;

        case MrdcRelCause_XnResetFull:
        case MrdcRelCause_XnResetPartial:
        case MrdcRelCause_XnStateDisabled:
        case MrdcRelCause_SnRelbyResetIntraNrdc:
        case MrdcRelCause_ForcedRelease:
            SET_MRDC_PROCEDURE_SNREL_OPRTYPE(ptCi, MRDC_SNREL_OPR_INTERNAL_Fallback);
            break;

        case MrdcRelCause_SCGFailure:
        case MrdcRelCause_RelReqRecv:
        case MrdcRelCause_ConcurrentNotAllowed:
        case MrdcRelCause_Handover:
        case MrdcRelCause_UEPowerSaving:
        case MrdcRelCause_DCprepareTimeOut:
        case MrdcRelCause_OtherReason:
        case MrdcRelCause_Reestablishment:
        case MrdcRelCause_RRCInactive:
            SET_MRDC_PROCEDURE_SNREL_OPRTYPE(ptCi, MRDC_SNREL_OPR_XN_Fallback);
            break;

        case MrdcRelCause_QosFlowRelease:
            SET_MRDC_PROCEDURE_SNREL_OPRTYPE(ptCi, MRDC_SNREL_OPR_XN_Deletion);
            break;

        default:
            SET_MRDC_PROCEDURE_SNREL_OPRTYPE(ptCi, MRDC_SNREL_OPR_Unknown);
    }

    VCCB_PRINT_CALL_ERROR(ptCi, "SNode Release operation type is selected as %s in %s\n",
        FnVCCB_GetSnodeRelOprType((enumMrdcSNRelOpr_type)GET_MRDC_PROCEDURE_SNREL_OPRTYPE(ptCi)), __FUNCTION__);
}

void FnVCCB_Conn_SetPDUSessAndDrbStatusForE1BearerFallback(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t idx;

    for (idx = 0; idx < MAX_DRB_PER_SA_CALL; idx++)
    {
        callDRBInfo_type *pDi = &ptCi->drb[idx];

        if (pDi->usage != CI_use) continue;
        if (!pDi->selectedBearerTypeFrozenFlag) continue;
        if (pDi->pduIdxInCall >= MAX_PDU_SESS_PER_CALL) continue;

        if (ptCi->stateCmd == MrdcDrbBasedFallback_cmd &&
            (pDi->bearerType.val != MN_Term_SPLIT_Bearer ||
                !GET_MNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(pDi->mrdcFlag.respFlag)))
        {
            continue;
        }

        if (pDi->bearerType.val == MN_Term_SPLIT_Bearer)
        {
            pDi->prevDrbStatus = pDi->drbStatus;
            pDi->drbStatus = S_Modify;
            ptCi->pduSess[pDi->pduIdxInCall].prevPduSessStatus = ptCi->pduSess[pDi->pduIdxInCall].pduSessStatus;
            ptCi->pduSess[pDi->pduIdxInCall].pduSessStatus = S_Modify;
        }
        else if (pDi->bearerType.termPoint == TermPoint_Sn &&
                 (GET_MRDC_PROCEDURE_INITIATOR(ptCi) == MRDC_PROC_INITIATOR_SN ||
                     GET_MRDC_PROCEDURE_SNREL_OPRTYPE(ptCi) == MRDC_SNREL_OPR_INTERNAL_Fallback))
        {
            pDi->prevDrbStatus = pDi->drbStatus;
            pDi->drbStatus = S_Setup;
            ptCi->pduSess[pDi->pduIdxInCall].prevPduSessStatus = ptCi->pduSess[pDi->pduIdxInCall].pduSessStatus;

            if (FnVCCB_DoesPDUSessExistAtMN(ptCi, pDi->pduIdxInCall))
            {
                ptCi->pduSess[pDi->pduIdxInCall].pduSessStatus = S_Modify;
            }
            else
            {
                ptCi->pduSess[pDi->pduIdxInCall].pduSessStatus = S_Setup;
            }
        }
    }
}

void FnVCCB_SNModFbkPrepare_XnMod_SetPDUSessAndDrbStatusForE1BearerFallback(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t idx;

    if (ptCi->stateCmd != MrdcDrbBasedFallback_cmd)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "stateCmd(%d) is not MrdcDrbBasedFallback_cmd ERROR in %s!\n", ptCi->stateCmd, __func__);

        return;
    }

    for (idx = 0; idx < MAX_DRB_PER_SA_CALL; idx++)
    {
        callDRBInfo_type *pDi = &ptCi->drb[idx];

        if (pDi->usage != CI_use) continue;
        if (!pDi->selectedBearerTypeFrozenFlag) continue;
        if (pDi->pduIdxInCall >= MAX_PDU_SESS_PER_CALL) continue;

        if (pDi->bearerType.termPoint != TermPoint_Sn ||
            !GET_SNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(pDi->mrdcFlag.respFlag))
        {
            continue;
        }

        pDi->prevDrbStatus = pDi->drbStatus;
        pDi->drbStatus = S_Setup;
        ptCi->pduSess[pDi->pduIdxInCall].prevPduSessStatus = ptCi->pduSess[pDi->pduIdxInCall].pduSessStatus;

        if (FnVCCB_DoesPDUSessExistAtMN(ptCi, pDi->pduIdxInCall))
        {
            ptCi->pduSess[pDi->pduIdxInCall].pduSessStatus = S_Modify;
        }
        else
        {
            ptCi->pduSess[pDi->pduIdxInCall].pduSessStatus = S_Setup;
        }
    }
}

void FnVCCB_SNRelPrepare_XnRel_SetPDUSessAndDrbStatusForE1BearerFallback(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t idx;

    for (idx = 0; idx < MAX_DRB_PER_SA_CALL; idx++)
    {
        callDRBInfo_type *pDi = &ptCi->drb[idx];

        if (pDi->usage != CI_use) continue;
        if (!pDi->selectedBearerTypeFrozenFlag) continue;
        if (pDi->pduIdxInCall >= MAX_PDU_SESS_PER_CALL) continue;

        if (!GET_E1_RESOURCE_FLAG(ptCi->flag.setupFlag) || pDi->bearerType.termPoint == TermPoint_Sn)
        {
            pDi->prevDrbStatus = pDi->drbStatus;
            pDi->drbStatus = S_Setup;
            ptCi->pduSess[pDi->pduIdxInCall].prevPduSessStatus = ptCi->pduSess[pDi->pduIdxInCall].pduSessStatus;

            if (GET_E1_RESOURCE_FLAG(ptCi->flag.setupFlag) && FnVCCB_DoesPDUSessExistAtMN(ptCi, pDi->pduIdxInCall))
            {
                ptCi->pduSess[pDi->pduIdxInCall].pduSessStatus = S_Modify;
            }
            else
            {
                ptCi->pduSess[pDi->pduIdxInCall].pduSessStatus = S_Setup;
            }
        }
    }
}

void FnVCCB_SNRelPrepare_F1Mod_SetPDUSessAndDrbStatusForE1BearerFallback(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t idx;

    for (idx = 0; idx < MAX_DRB_PER_SA_CALL; idx++)
    {
        callDRBInfo_type *pDi = &ptCi->drb[idx];

        if (pDi->usage != CI_use) continue;
        if (!pDi->selectedBearerTypeFrozenFlag) continue;
        if (pDi->pduIdxInCall >= MAX_PDU_SESS_PER_CALL) continue;

        if (pDi->bearerType.termPoint == TermPoint_Sn)
        {
            //if (!pDi->snTermSplitFlag)  // scg bearer
            if (pDi->bearerType.val == SN_Term_SCG_Bearer)
            {
                pDi->prevDrbStatus = pDi->drbStatus;
                pDi->drbStatus = S_Modify;
                ptCi->pduSess[pDi->pduIdxInCall].prevPduSessStatus = ptCi->pduSess[pDi->pduIdxInCall].pduSessStatus;
                ptCi->pduSess[pDi->pduIdxInCall].pduSessStatus = S_Modify;
            }
            ptCi->pduSess[pDi->pduIdxInCall].nGuDlInfo.fNeedModify = VCCB_FLAG_ON;  // for PDUSessionModifyIndi
        }
    }
}

void FnVCCB_SNModFbkPrepare_F1Mod_SetPDUSessAndDrbStatusForE1BearerFallback(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t idx;

    if (ptCi->stateCmd != MrdcDrbBasedFallback_cmd)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "stateCmd(%d) is not MrdcDrbBasedFallback_cmd ERROR in %s!\n", ptCi->stateCmd, __func__);

        return;
    }

    for (idx = 0; idx < MAX_DRB_PER_SA_CALL; idx++)
    {
        callDRBInfo_type *pDi = &ptCi->drb[idx];

        if (pDi->usage != CI_use) continue;
        if (!pDi->selectedBearerTypeFrozenFlag) continue;
        if (pDi->pduIdxInCall >= MAX_PDU_SESS_PER_CALL) continue;

        if (pDi->bearerType.termPoint != TermPoint_Sn ||
            !GET_SNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(pDi->mrdcFlag.respFlag))
        {
            continue;
        }
        /*
        if (!pDi->snTermSplitFlag) // scg bearer
        {
            pDi->prevDrbStatus = pDi->drbStatus;
            pDi->drbStatus = S_Modify;
            ptCi->pduSess[pDi->pduIdxInCall].prevPduSessStatus = ptCi->pduSess[pDi->pduIdxInCall].pduSessStatus;
            ptCi->pduSess[pDi->pduIdxInCall].pduSessStatus = S_Modify;
        }
        */
        ptCi->pduSess[pDi->pduIdxInCall].nGuDlInfo.fNeedModify = VCCB_FLAG_ON;  // for PDUSessionModifyIndi
    }
}

void FnVCCB_SetPDUSessAndDrbStatusForE1BearerFallback(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!IS_MRDC_MN(ptCi))
    {
        return;
    }

    if (!IS_NRDC_SNREL_INVOKED(ptCi) && ptCi->stateCmd != MrdcDrbBasedFallback_cmd)
    {
        return;
    }

    switch (ptCi->state)
    {
        case STATE_Conn:
            FnVCCB_Conn_SetPDUSessAndDrbStatusForE1BearerFallback(ptCi);
            break;

        case STATE_SNModFbkPrepare_XnMod:
            FnVCCB_SNModFbkPrepare_XnMod_SetPDUSessAndDrbStatusForE1BearerFallback(ptCi);
            break;

        case STATE_SNRelPrepare_XnRel:
            FnVCCB_SNRelPrepare_XnRel_SetPDUSessAndDrbStatusForE1BearerFallback(ptCi);
            break;

        case STATE_SNRelPrepare_F1Mod:
            FnVCCB_SNRelPrepare_F1Mod_SetPDUSessAndDrbStatusForE1BearerFallback(ptCi);
            break;

        case STATE_SNModFbkPrepare_F1Mod:
            FnVCCB_SNModFbkPrepare_F1Mod_SetPDUSessAndDrbStatusForE1BearerFallback(ptCi);
            break;

        default:
            break;
    }
}

void FnVCCB_SNRelPrepare_E1Mod2_SetPDUSessAndDrbStatusForF1BearerFallback(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t idx;

    for (idx = 0; idx < MAX_DRB_PER_SA_CALL; idx++)
    {
        callDRBInfo_type *pDi = &ptCi->drb[idx];

        if (pDi->usage != CI_use) continue;
        if (!pDi->selectedBearerTypeFrozenFlag) continue;
        if (pDi->pduIdxInCall >= MAX_PDU_SESS_PER_CALL) continue;
        if (pDi->drbStatus != S_Setup) continue;

        if (pDi->bearerType.val == SN_Term_SPLIT_Bearer)  // split bearer
        {
            pDi->prevDrbStatus = pDi->drbStatus;
            pDi->drbStatus = S_Modify;
            ptCi->pduSess[pDi->pduIdxInCall].prevPduSessStatus = ptCi->pduSess[pDi->pduIdxInCall].pduSessStatus;
            ptCi->pduSess[pDi->pduIdxInCall].pduSessStatus = S_Modify;
        }
    }
}

void FnVCCB_SNModFbkPrepare_E1Mod2_SetPDUSessAndDrbStatusForF1BearerFallback(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    FnVCCB_SNRelPrepare_E1Mod2_SetPDUSessAndDrbStatusForF1BearerFallback(ptCi);
}

void FnVCCB_SNRelPrepare_E1Mod_SetPDUSessAndDrbStatusForF1BearerFallback(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    FnVCCB_SNRelPrepare_E1Mod2_SetPDUSessAndDrbStatusForF1BearerFallback(ptCi);
}

void FnVCCB_SetPDUSessAndDrbStatusForF1BearerFallback(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!IS_NRDC_MN(ptCi))
    {
        return;
    }

    switch (ptCi->state)
    {
        case STATE_SNRelPrepare_E1Mod:
            FnVCCB_SNRelPrepare_E1Mod_SetPDUSessAndDrbStatusForF1BearerFallback(ptCi);
            break;

        case STATE_SNRelPrepare_E1Mod2:
        case STATE_SNRelPrepare_E1Setup:
            FnVCCB_SNRelPrepare_E1Mod2_SetPDUSessAndDrbStatusForF1BearerFallback(ptCi);
            break;

        case STATE_SNModFbkPrepare_E1Mod2:
        case STATE_SNModFbkPrepare_E1Setup:
            FnVCCB_SNModFbkPrepare_E1Mod2_SetPDUSessAndDrbStatusForF1BearerFallback(ptCi);
            break;

        default:
            break;
    }
}

int16_t FnVCCB_StoreSBCList(callInfo_type *ptCi, NRRRC_RF_Parameters *pMsg)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMsg);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    // step 1
    bandCombinationList_type *pTempBandComList = VRIL_GetBandCombinationList(ptCi);
    VALID_E_POINT_CHECK_ERROR(pTempBandComList);

    // step 2
    uint16_t noofNrdcSupportableBC = 0, noofNrdcSupportableBC_v1630 = 0;
    uint32_t dbIdx = 0;
    uint32_t maxIdx = UMIN((uint32_t)pTempBandComList->num, MAX_BAND_COMBS);
    if (pMsg->bit_mask[NRRRC_RF_Parameters_supportedBandCombinationList_v1560_present_byte] &
        NRRRC_RF_Parameters_supportedBandCombinationList_v1560_present)
    {
        struct NRRRC_BandCombinationList_v1560_ *pNext = pMsg->supportedBandCombinationList_v1560;
        while (pNext && dbIdx < maxIdx)
        {
            NRRRC_BandCombination_v1560 *pBandComb_v1560 = &pNext->value;
            if (pBandComb_v1560->bit_mask & NRRRC_ca_ParametersNRDC_present)
            {
                pTempBandComList->bandCombination[dbIdx].caParametersNRDC_present = VCCB_FLAG_ON;
                VRIL_StoreNRRRC_CA_ParametersNRDC(&pTempBandComList->bandCombination[dbIdx].caParametersNRDC, &pBandComb_v1560->ca_ParametersNRDC);
                noofNrdcSupportableBC++;

                if (pBandComb_v1560->ca_ParametersNRDC.bit_mask & NRRRC_featureSetCombinationDC_present)
                {
                    pTempBandComList->bandCombination[dbIdx].featureSetCombination =
                        pBandComb_v1560->ca_ParametersNRDC.featureSetCombinationDC;
                }
                // FGR-CC5200:FR150
                if ((pBandComb_v1560->ca_ParametersNRDC.bit_mask & NRRRC_ca_ParametersNR_ForDC_present) &&
                    (pBandComb_v1560->ca_ParametersNRDC.ca_ParametersNR_ForDC.bit_mask &
                        NRRRC_supportedNumberTAG_present))
                {
                    pTempBandComList->bandCombination[dbIdx].supportedNumberTAG_present = OPT_PRESENT & e_BitMask_1bit;
                }
            }
            else
            {
                pTempBandComList->bandCombination[dbIdx].caParametersNRDC_present = VCCB_FLAG_OFF;
            }

            dbIdx++;
            pNext = pNext->next;
        }
    }
    else
    {
        for (dbIdx = 0; dbIdx < maxIdx; dbIdx++)
        {
            pTempBandComList->bandCombination[dbIdx].caParametersNRDC_present = VCCB_FLAG_OFF;
        }

        VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "NRRRC_RF_Parameters_supportedBandCombinationList_v1560_present is not in %s!\n", __FUNCTION__);
    }

    if (pMsg->bit_mask[NRRRC_RF_Parameters_supportedBandCombinationList_v1630_present_byte] & NRRRC_RF_Parameters_supportedBandCombinationList_v1630_present)
    {
        dbIdx = 0;
        struct NRRRC_BandCombinationList_v1630_ *pNext = pMsg->supportedBandCombinationList_v1630;
        while (pNext && dbIdx < maxIdx)
        {
            NRRRC_BandCombination_v1630 *pBandComb_v1630 = &pNext->value;
            if (pBandComb_v1630->bit_mask & NRRRC_ca_ParametersNRDC_v1630_present)
            {
                pTempBandComList->bandCombination[dbIdx].caParametersNRDC_v1630_present = VCCB_FLAG_ON;
                VRIL_StoreNRRRC_CA_ParametersNRDC_v1630(&pTempBandComList->bandCombination[dbIdx].caParametersNRDC_v1630, &pBandComb_v1630->ca_ParametersNRDC_v1630);
                noofNrdcSupportableBC_v1630++;
            }
            else
            {
                pTempBandComList->bandCombination[dbIdx].caParametersNRDC_v1630_present = VCCB_FLAG_OFF;
            }

            dbIdx++;
            pNext = pNext->next;
        }
    }
    else
    {
        for (dbIdx = 0; dbIdx < maxIdx; dbIdx++)
        {
            pTempBandComList->bandCombination[dbIdx].caParametersNRDC_v1630_present = VCCB_FLAG_OFF;
        }

        VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "NRRRC_RF_Parameters_supportedBandCombinationList_v1630_present is not in %s!\n", __FUNCTION__);
    }

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "noofNrdcSupportableBC(D'%u) noofNrdcSupportableBC_v1630(D'%u) \n", noofNrdcSupportableBC, noofNrdcSupportableBC_v1630);

    return GOOD;
}

bool cmpProfilePriority(const std::pair<int, int> &a, const std::pair<int, int> &b)
{
    if (a.second == b.second)
        return a.first < b.first;  // if priority is same, ca profile idx Smaller values ??좏릡ave higher priority.
    return a.second > b.second;    // if priority is large, the priority is high.
}

int16_t FnVCCB_SetCaProfileBasedImc(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    uint8_t caIdx = 0, bIdx = 0;
    bandCombinationList_type *pNrBandCombListBuff = VRIL_GetBandCombinationList(ptCi);
    VALID_E_POINT_CHECK_ERROR(pNrBandCombListBuff);
    VccbGnbInfo_type::idleMobilityControl_s *pIdleMobilityControl = &GNBINFO[ptCi->gnbNum].idleMobilityControl;
    caProfile_type *pCaProfileList = NULL;
    nrBand_IdleLB_type *pNrBandList = NULL;
    uint64_t bcKeys_s = 0;  // 18 * 18 * 1025 = 332,100

    std::map<uint8_t, uint8_t, std::greater<uint8_t>> prioritymap;
    for (caIdx = 0; caIdx < MAX_CA_PROFILE_NUM; caIdx++)  // 4
    {
        pCaProfileList = &pIdleMobilityControl->caProfileList[caIdx];
        if (CI_use == pCaProfileList->usage)
        {
            prioritymap[caIdx] = pCaProfileList->profilePriority;  //[ca profile idx, priority] map
        }
    }

    if (prioritymap.empty())
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: There is no valid priority in %s\n", __func__);
        // couldn't find idx
        ptCi->caProfileIdx = -1;
        return GOOD;
    }

    std::vector<std::pair<uint8_t, uint8_t>> sortedvec(prioritymap.begin(), prioritymap.end());
    sort(sortedvec.begin(), sortedvec.end(), cmpProfilePriority);

    int num_keys[MAX_BAND_COMBS];
    uint64_t keys[MAX_BAND_COMBS * MAX_BANDS_PER_COMB] = {0};
    int bclListIdx = 0, bcIdx = 0;
    const int bclNum = MIN(pNrBandCombListBuff->num, MAX_BAND_COMBS);
    for (bclListIdx = 0; bclListIdx < bclNum; bclListIdx++)  // Max is 1024
    {
        auto &bc = pNrBandCombListBuff->bandCombination[bclListIdx];
        const int NUM_B = MIN(bc.num, MAX_BANDS_PER_COMB);
        for (bcIdx = 0; bcIdx < NUM_B; bcIdx++)  // Max is 15
        {
            auto &band = bc.band[bcIdx];
            bcKeys_s = VCCB_MAKE_BC_KEYS(band.freqBandIndicator, band.nrCaBandwidthClassDL, band.nrCaBandwidthClassUL);
            keys[bclListIdx * MAX_BANDS_PER_COMB + bcIdx] = bcKeys_s;
        }
        num_keys[bclListIdx] = bcIdx;
    }

    for (const auto &sortedvecIt : sortedvec)
    {
        std::vector<uint64_t> yangConfigNrbandKeys;
        pCaProfileList = &pIdleMobilityControl->caProfileList[sortedvecIt.first];
        for (bIdx = 0; bIdx < MAX_NR_BAND_IDLELB_NUM; bIdx++)  // 4
        {
            pNrBandList = &pCaProfileList->nrBandList[bIdx];
            if (CI_use == pNrBandList->usage)
            {
                bcKeys_s = VCCB_MAKE_BC_KEYS(pNrBandList->freqBandIndicator, pNrBandList->nrCaBandwidthClassDL,
                    pNrBandList->nrCaBandwidthClassUL);
                yangConfigNrbandKeys.push_back(bcKeys_s);
            }
        }

        if (yangConfigNrbandKeys.empty())
        {
            continue;
        }

        bool isMatched = false;
        const int bcBuffNum = MIN(pNrBandCombListBuff->num, MAX_BAND_COMBS);
        int keyidx = 0;
        for (int i = 0; i < bcBuffNum; i++)
        {
            isMatched = true;
            for (const auto &yangNrBandKeyit : yangConfigNrbandKeys)
            {
                for (keyidx = 0; keyidx < num_keys[i]; keyidx++)
                {
                    if (keys[i * MAX_BANDS_PER_COMB + keyidx] == yangNrBandKeyit)
                    {
                        break;
                    }
                }
                // not matched
                if (keyidx == num_keys[i])
                {
                    isMatched = false;
                    break;
                }
            }
            if (true == isMatched)
            {
                ptCi->caProfileIdx = (int8_t)sortedvecIt.first;
                VCCB_PRINT_CALL_COMMENT(ptCi,
                    "[IMC] Set caProfileIdx(%d) bclNum(%d) bcIdx(%d) bcBuffNumIdx(%d) in %s\n", ptCi->caProfileIdx,
                    bclNum, bcIdx, i, __FUNCTION__);
                return GOOD;
            }
        }
    }

    // couldn't find idx
    VCCB_PRINT_CALL_COMMENT(ptCi, "[IMC] Set caProfileIdx(%d) bclNum(%d) bcIdx(%d) in %s\n", ptCi->caProfileIdx, bclNum,
        bcIdx, __FUNCTION__);
    ptCi->caProfileIdx = -1;
    return GOOD;
}

int16_t FnVCCB_MakeAllowedBCList(
    callInfo_type *ptCi, CellNum_type cellNum, FreqBandInd_type cellBand, NRRRC_UE_NR_Capability *pMsg, uint8_t isHandoverCase)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMsg);

    if (IS_MRDC_SN(ptCi))
    {
        return GOOD;
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    // featureSetCombinations will be stored in FnVCCB_StoreSBCList->VRIL_GetBandCombinationList
    if (!(pMsg->bit_mask & NRRRC_UE_NR_Capability_featureSetCombinations_present))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "NRRRC_UE_NR_Capability_featureSetCombinations_present is not presented in %s!\n", __FUNCTION__);

        return ERROR;
    }

    if (ERROR == FnVCCB_StoreSBCList(ptCi, &pMsg->rf_Parameters))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_StoreSBCList Error in %s!\n", __FUNCTION__);

        return ERROR;
    }

    int16_t status = VLIB_Set_MrdcAllowedBCListMRDC(
        ptCi, cellNum, cellBand, &ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC, TRUE, isHandoverCase);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_Set_MrdcAllowedBCListMRDC Error in %s!\n", __FUNCTION__);
    }

    return GOOD;
}

void FnVCCB_AuditMrdcBufferPerBuffType(enumBuffType buffType)
{
    AUTO_TRACE_FUNC;
    buff1024NodeType *node = NULL;
    time_t currTime = time(NULL);
    long int diff = 0;
    uint32_t idx = 0;
    enumMrdcBuffCause_type failCause = MRDC_BUFF_CAUSE_NORMAL;

    switch (buffType)
    {
        case buffType1024:
            if (!gMrdcBuffCtrl.buffNode1024)
            {
                return;
            }
            node = gMrdcBuffCtrl.buffNode1024;
            break;

        case buffType2048:
            if (!gMrdcBuffCtrl.buffNode2048)
            {
                return;
            }
            node = (buff1024NodeType *)gMrdcBuffCtrl.buffNode2048;
            break;

        case buffType4096:
            if (!gMrdcBuffCtrl.buffNode4096)
            {
                return;
            }
            node = (buff1024NodeType *)gMrdcBuffCtrl.buffNode4096;
            break;

        case buffType9216:
            if (!gMrdcBuffCtrl.buffNode9216)
            {
                return;
            }
            node = (buff1024NodeType *)gMrdcBuffCtrl.buffNode9216;
            break;

        default:
            return;
    }

    for (idx = 0; idx < gMrdcBuffCtrl.noOfElem; idx++)
    {
        if (node[idx].hdr.used)
        {
            diff = currTime - node[idx].hdr.allocTime;
            VCCB_PRINT_ERROR("time diff %ld!\n", currTime - node[idx].hdr.allocTime);
            if (diff > MRDC_BUFF_AUDIT_PERIOD)
            {
                _FreeBuff(buffType, idx, FORCED_FREE, 0, failCause);
                gMrdcBuffCtrl.freeStatsAudit[buffType].attempt++;
                DBG->mrdcBuffCtrlStats.freeStatsAudit[buffType].attempt++;

                if (MRDC_BUFF_CAUSE_NORMAL == failCause)
                {
                    gMrdcBuffCtrl.freeStatsAudit[buffType].success++;
                    DBG->mrdcBuffCtrlStats.freeStatsAudit[buffType].success++;
                }
                else if (MRDC_BUFF_CAUSE_NORMAL < failCause && failCause < MRDC_BUFF_CAUSE_END)
                {
                    DBG->mrdcBuffCtrlStats.freeStatsAudit[buffType].fail[failCause]++;
                }
                else
                {
                    failCause = MRDC_BUFF_CAUSE_OTHER_FAILURE;
                    DBG->mrdcBuffCtrlStats.freeStatsAudit[buffType].fail[failCause]++;
                }
            }
            else if (diff < 0)
            {
                node[idx].hdr.allocTime = currTime;
            }
        }
    }
}

void FnVCCB_AuditMrdcBuffer(void)
{
    AUTO_TRACE_FUNC;
    static uint32_t modulo1 = 0, modulo2 = 0;

    if (++modulo1 % 3)
    {
        return;
    }

    if (!gMrdcBuffCtrl.initFlag || !gMrdcBuffCtrl.noOfElem)
    {
        VCCB_PRINT_ERROR("initFlag(%u), noOfElem(%u) so exited in %s\n", gMrdcBuffCtrl.initFlag, gMrdcBuffCtrl.noOfElem,
            __FUNCTION__);
        return;
    }

    ++modulo2;

    FnVCCB_AuditMrdcBufferPerBuffType(static_cast<enumBuffType>(modulo2 % MAX_BUFF_TYPE));
}

#ifdef IPC_TEST
int16_t FnVCCB_CheckMrdcBuffer(void)
{
    AUTO_TRACE_FUNC;
    int loop = 0, loop2 = 0;

    for (loop = 0; loop <= buffType9216; loop++)
    {
        uint32_t attempt = 0, success = 0;
        for (loop2 = 0; loop2 < VCCB_CALL_THREAD_NUM; loop2++)
        {
            attempt = attempt + gMrdcBuffCtrl.allocStats[loop].attempt[loop2];
            success = success + gMrdcBuffCtrl.allocStats[loop].success[loop2];
        }
        if (attempt != success)
        {
            return ERROR;
        }

        if (gMrdcBuffCtrl.freeStatsAudit[loop].attempt > 0)
        {
            return ERROR;
        }
    }

    return GOOD;
}

int16_t FnVCCB_CheckAuditMrdcBuffer(void)
{
    AUTO_TRACE_FUNC;
    int loop = 0, availableBuffCnt = 0;
    for (loop = 0; loop < MAX_BUFF_TYPE_FOR_STATS; loop++)
    {
        if (gMrdcBuffCtrl.freeStatsAudit[loop].attempt != gMrdcBuffCtrl.freeStatsAudit[loop].success)
        {
            return ERROR;
        }
    }

    availableBuffCnt = 0;

    auto procAvailableBuffCnt = [&availableBuffCnt](auto pBuff)
    {
        if (pBuff == NULL) return;

        availableBuffCnt++;

        while (pBuff->next)
        {
            availableBuffCnt++;
            pBuff = pBuff->next;
        }
    };

    procAvailableBuffCnt(gMrdcBuffCtrl.root1024);
    procAvailableBuffCnt(gMrdcBuffCtrl.root2048);
    procAvailableBuffCnt(gMrdcBuffCtrl.root4096);
    procAvailableBuffCnt(gMrdcBuffCtrl.root9216);

    VCCB_PRINT_ERROR("availableBuffCnt%d noOfElem%d!!\n", availableBuffCnt, gMrdcBuffCtrl.noOfElem);
    if (gMrdcBuffCtrl.noOfElem * MAX_BUFF_TYPE != (unsigned int)availableBuffCnt)
    {
        return ERROR;
    }
    return GOOD;
}

void FnVCCB_TestAuditMrdcBufferPerBuffType(enumBuffType buffType)
{
    AUTO_TRACE_FUNC;
    buff1024NodeType *node = NULL;
    node = gMrdcBuffCtrl.buffNode1024;
    uint32_t idx = 0;
    VCCB_PRINT_ERROR("%s called!\n", __FUNCTION__);

    switch (buffType)
    {
        case buffType1024:
            if (!gMrdcBuffCtrl.buffNode1024)
            {
                return;
            }
            node = gMrdcBuffCtrl.buffNode1024;
            break;

        case buffType2048:
            if (!gMrdcBuffCtrl.buffNode2048)
            {
                return;
            }
            node = (buff1024NodeType *)gMrdcBuffCtrl.buffNode2048;
            break;

        case buffType4096:
            if (!gMrdcBuffCtrl.buffNode4096)
            {
                return;
            }
            node = (buff1024NodeType *)gMrdcBuffCtrl.buffNode4096;
            break;

        case buffType9216:
            if (!gMrdcBuffCtrl.buffNode9216)
            {
                return;
            }
            node = (buff1024NodeType *)gMrdcBuffCtrl.buffNode9216;
            break;

        default:
            return;
    }

    for (idx = 0; idx < gMrdcBuffCtrl.noOfElem; idx++)
    {
        if (node[idx].hdr.used)
        {
            VCCB_PRINT_ERROR("time %ld -= 61 called! %s\n", node[idx].hdr.allocTime, __FUNCTION__);
            node[idx].hdr.allocTime -= 61;
        }
    }
}
#endif

/**
 * @brief       This function specifies the MRDC bearer type to be referenced by environment elements such as
 * State/StateCmd.
 *
 * @param [in] ptCi
 * @param [in] ptRrc - packed RRC message to be transferred, before applying security
 * @return GOOD
 * @return ERROR
 */
int FnVCCB_ReferenceBearerTypeAccordingToState(callInfo_type *ptCi, callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, INIT_BEARER_TYPE);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, INIT_BEARER_TYPE);

    // DRB is S_Modify when INTER_DU_Prepare (F1_UEContextSetupResponse case...)
    int curBearerType = static_cast<int>(FnVCCB_getSaDrbBearerType(ptCi, ptDi, current_bearerType));

    // 1) Defines a case where the bearer type should be viewed differently for each state machine.
    //    If it does not correspond to the switch below, the operation corresponding to "2)" is performed.
    // switch (ptCi->state)
    //{
    //    case STATE_Conn:
    //         break;       // Activate it if necessary
    //    default:
    //        break;
    //}

    // In case of Non-DC, you only need to refer to the current Bearer Type.
    if (IS_MRDC(ptCi) == false) return curBearerType;

    // 2) If the above selection conditions are not satisfied, a fixed value is assigned.
    switch (ptCi->stateCmd)
    {
        case IntraRatHO_cmd:
        case InterRatHO_cmd:

            // For MR-DC UE
            if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTER_NB)
            {
                if (ptCi->hoInfo.isTarget)  // Target-gNB
                {
                    return static_cast<int>(FnVCCB_getSaDrbBearerType(ptCi, ptDi, request_bearerType));
                }
                else  // Source-gNB
                {
                    return curBearerType;
                }
            }
            else  // TODO :: Check Intra-gNB Case
            {
                // For HO, It indicates the case to look at the Current Bearer. SN Term SCG -> MN Term MCG.
                if (true == FnVCCB_IsBearerControlOnCurrentBearerType(ptCi))
                {
                    return curBearerType;
                }

                return static_cast<int>(FnVCCB_getSaDrbBearerType(ptCi, ptDi, request_bearerType));
            }

        default:

            return curBearerType;
    }
}

/**
 * @brief This is a function that determines whether MN controls E1 Cell Group Control for DRB.
 */
VCCB_STATIC_INLINE
void FnVCCB_DecisionMrdc_E1CellGroupControlForDrbForMN(
    callInfo_type *ptCi, callDRBInfo_type *ptDi, bool *pMcgCtrl, bool *pScgCtrl)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptDi);
    VALID_E_POINT_CHECK_VOID(pMcgCtrl);
    VALID_E_POINT_CHECK_VOID(pScgCtrl);

    int bearerType = FnVCCB_ReferenceBearerTypeAccordingToState(ptCi, ptDi);

    switch (ptCi->state)
    {
        // start/stop for mn scg leg.
        case STATE_MN_INTER_SN_E1Stop:
        case STATE_MN_INTER_SN_Complete:
            switch (bearerType)
            {
                case MN_Term_SPLIT_Bearer:
                    *pScgCtrl = true;
                    break;

                case MN_Term_MCG_Bearer:
                default:
                    break;
            }
            break;

        case STATE_INTER_DU_Cancel:
        case STATE_INTRA_DU_Cancel:
        {
            *pMcgCtrl = true;
            *pScgCtrl = false;

            uint8_t curBearerType = FnVCCB_getSaDrbBearerType(ptCi, ptDi, current_bearerType);

            switch (curBearerType)
            {
                case MN_Term_SPLIT_Bearer:
                    if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_config_ue)
                    {
                        *pScgCtrl = true;
                    }
                    else
                    {
                        /*  SCG Resume, Ignore
                        - HO Cancel occurs during the 'Intra-MN XX-DU with SN Release' procedure, it is changed to the NRDC Basic Release procedure.
                        - the SCG Leg of MN Term SPLIT has already been deleted, do not RESUME it. */
                    }
                    break;

                //case MN_Term_MCG_Bearer:
                default:
                    break;
            }

            break;
        }
        case STATE_SNRelPrepare_F1Mod:
            *pScgCtrl = false;
            *pMcgCtrl = false;
            if (bearerType == MN_Term_SPLIT_Bearer && IS_ON_E1_MRDC_CTRL_FLAG(ptDi, scgDel)) // In case of SN Initiated Release, E1BearerContextModificaiotnReq includes ul-config on SNRelPrepare_F1Mod state
            {
                *pMcgCtrl = true;
            }
            break;

        case STATE_SNModFbkPrepare_F1Mod ... STATE_SNModFbkComplt_XnMod:
            *pMcgCtrl = false;
            *pScgCtrl = false;
            break;

        case STATE_RRE_RreCmpl:
        case STATE_RRE_F1SetupMod:
        case STATE_RRE_RRCRecCmpl:  // resume
        case STATE_RRE_Switch:      // resume
            *pMcgCtrl = true;
            *pScgCtrl = false;
            break;

        case STATE_SNAddPrepare_XnAdd:
            // for Ul Path Control
            // reqBearerType is additionally used in this state
            if (FnVCCB_getSaDrbBearerType(ptCi, ptDi, request_bearerType) == MN_Term_SPLIT_Bearer)
            {
                *pMcgCtrl = true;
                *pScgCtrl = true;
            }
            else
            {
                *pMcgCtrl = true;
            }
            break;

        // start/stop for all leg.
        default:
            switch (bearerType)
            {
                case MN_Term_SPLIT_Bearer:
                    *pMcgCtrl = true;
                    *pScgCtrl = true;
                    break;

                case MN_Term_MCG_Bearer:
                    *pMcgCtrl = true;
                    break;

                default:
                    break;
            }
            break;
    }

    // protection code
    if (!IsAvailable_MrdcInfo() || !IS_ON_MRDC_RSC_SETUP_FLAG(e1_scgSetup) || IS_ON_E1_MRDC_CTRL_FLAG(ptDi, scgDel))
    {
        if (*pScgCtrl == true)
        {
            *pScgCtrl = false;
        }
    }
}

/**
 * @brief This is a function that determines whether SN controls E1 Cell Group Control for DRB.
 */
VCCB_STATIC_INLINE
void FnVCCB_DecisionMrdc_E1CellGroupControlForDrbForSN(
    callInfo_type *ptCi, callDRBInfo_type *ptDi, bool *pMcgCtrl, bool *pScgCtrl)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptDi);
    VALID_E_POINT_CHECK_VOID(pMcgCtrl);
    VALID_E_POINT_CHECK_VOID(pScgCtrl);

    int bearerType = FnVCCB_ReferenceBearerTypeAccordingToState(ptCi, ptDi);
    bool flagBasedControl = false;

    switch (bearerType)
    {
        case SN_Term_SPLIT_Bearer:
            *pMcgCtrl = true;
            *pScgCtrl = true;
            break;

            // case SN_Term_MCG_Bearer:
            //     *pMcgCtrl = true;
            //     break;

        case SN_Term_SCG_Bearer:
            *pScgCtrl = true;
            break;

        default:
            break;
    }

    switch (ptCi->stateCmd)
    {
        case MrdcXnSNMod_cmd:
            if ((ptCi->state == STATE_Conn) &&
                FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_McgMobility) == true)
            {
                flagBasedControl = true;
            }
            break;

        case ReconfigComplete_cmd:
            if ((ptCi->state == STATE_SN_SNModComplt_F1E1Mod) &&
                FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_McgMobility) == true)
            {
                flagBasedControl = true;
            }
            break;

        default:
            break;
    }

    if (flagBasedControl == true)
    {
        *pMcgCtrl = false;
        *pScgCtrl = false;

        if (IS_ON_E1_MRDC_CTRL_FLAG(ptDi, mcgMod_txStop) || IS_ON_E1_MRDC_CTRL_FLAG(ptDi, mcgMod_txResume))
        {
            *pMcgCtrl = true;
        }
        if (IS_ON_E1_MRDC_CTRL_FLAG(ptDi, scgMod_txStop))
        {
            *pScgCtrl = true;
        }
    }
}

/**
 * @brief This function decides whether to control E1 Cell Group Control for DRB.
 */
void FnVCCB_DecisionMrdc_E1CellGroupControlForDrb(
    callInfo_type *ptCi, callDRBInfo_type *ptDi, bool *pMcgCtrl, bool *pScgCtrl)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptDi);
    VALID_E_POINT_CHECK_VOID(pMcgCtrl);
    VALID_E_POINT_CHECK_VOID(pScgCtrl);

    *pMcgCtrl = false;
    *pScgCtrl = false;

    // NSA always on. protection code.
    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        *pMcgCtrl = true;
        return;
    }

    if (IS_NRDC_SN(ptCi))
    {
        FnVCCB_DecisionMrdc_E1CellGroupControlForDrbForSN(ptCi, ptDi, pMcgCtrl, pScgCtrl);
        return;
    }
    else  // MN and gNB
    {
        FnVCCB_DecisionMrdc_E1CellGroupControlForDrbForMN(ptCi, ptDi, pMcgCtrl, pScgCtrl);
        return;
    }
}

/**
 * @brief Review whether the DRB is included in the MN UP. If it is an inclusive relationship, this is a case in which
 * MN UP must be controlled.
 * @param[in] ptCi: Pointer of callInfo_type
 * @param[in] ptDi: Pointer of drb
 * @return true, false
 */
bool FnVCCB_IsNeedControl_MN_UP_ForDrb(callInfo_type *ptCi, callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, true);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, true);

    bool mcgCtrl = false, scgCtrl = false;

    FnVCCB_DecisionMrdc_E1CellGroupControlForDrb(ptCi, ptDi, &mcgCtrl, &scgCtrl);

    if (mcgCtrl == true || scgCtrl == true)
    {
        return true;  // it is an MN term bearer.
    }
    else
    {
        return false;  // it is an SN term bearer.
    }
}

/**
 * @brief Review whether the QOS is included in the MN UP. If it is an inclusive relationship, this is a case in which
 * MN UP must be controlled.
 * @param[in] ptCi: Pointer of callInfo_type
 * @param[in] ptDi: Pointer of drb
 * @return true, false
 */
bool FnVCCB_IsNeedControl_MN_UP_ForQos(callInfo_type *ptCi, qosFlowInfo_type *ptQi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, true);
    VALID_E_POINT_CHECK_RET_VAL(ptQi, true);

    if (ptQi->drbIdxInCall >= MAX_DRB_PER_SA_CALL)
    {
        return true;
    }

    return FnVCCB_IsNeedControl_MN_UP_ForDrb(ptCi, &ptCi->drb[ptQi->drbIdxInCall]);  // DRB
}

/**
 * @brief Review whether the DRB is included in the SN UP. If it is an inclusive relationship, this is a case in which
 * SN UP must be controlled.
 * @param[in] ptCi: Pointer of callInfo_type
 * @param[in] ptDi: Pointer of drb
 * @return true, false
 */
bool FnVCCB_IsNeedControl_SN_UP_ForDrb(callInfo_type *ptCi, callDRBInfo_type *ptDi)
{
    return !(FnVCCB_IsNeedControl_MN_UP_ForDrb(ptCi, ptDi));
}

/**
 * @brief Review whether the QOS is included in the SN UP. If it is an inclusive relationship, this is a case in which
 * SN UP must be controlled.
 * @param[in] ptCi: Pointer of callInfo_type
 * @param[in] ptDi: Pointer of drb
 * @return true, false
 */
bool FnVCCB_IsNeedControl_SN_UP_ForQos(callInfo_type *ptCi, qosFlowInfo_type *ptQi)
{
    return !(FnVCCB_IsNeedControl_MN_UP_ForQos(ptCi, ptQi));
}

void FnVCCB_set_MrdcSnRelMnEvent(callInfo_type *ptCi, uint32_t type)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    if (type >= STAT_MRDC_SN_REL_MN_END)
    {
        return;
    }
    if (!IsAvailable_MrdcInfo())
    {
        return;
    }

    ONBIT_U8TABLE(ptCi->mrdcInfo.stat.mrdcSnRelMn, type);
}

void FnVCCB_set_MrdcSnRelSnEvent(callInfo_type *ptCi, uint32_t type)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    if (type >= STAT_MRDC_SN_REL_SN_END)
    {
        return;
    }
    if (!IsAvailable_MrdcInfo())
    {
        return;
    }

    ONBIT_U8TABLE(ptCi->mrdcInfo.stat.mrdcSnRelSn, type);
}

bool FnVCCB_get_MrdcSnRelMnEvent(callInfo_type *ptCi, uint32_t type)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    if (type >= STAT_MRDC_SN_REL_MN_END)
    {
        return false;
    }
    if (!IsAvailable_MrdcInfo())
    {
        return false;
    }

    return GETBIT_U8TABLE(ptCi->mrdcInfo.stat.mrdcSnRelMn, type);
}

bool FnVCCB_get_MrdcSnRelSnEvent(callInfo_type *ptCi, uint32_t type)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    if (type >= STAT_MRDC_SN_REL_SN_END)
    {
        return false;
    }
    if (!IsAvailable_MrdcInfo())
    {
        return false;
    }

    return GETBIT_U8TABLE(ptCi->mrdcInfo.stat.mrdcSnRelSn, type);
}

void FnVCCB_setOff_MrdcSnRelMnEvent(callInfo_type *ptCi, uint32_t type)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    if (type >= STAT_MRDC_SN_REL_MN_END)
    {
        return;
    }
    if (!IsAvailable_MrdcInfo())
    {
        return;
    }
    OFFBIT_U8TABLE(ptCi->mrdcInfo.stat.mrdcSnRelMn, type);
}

void FnVCCB_setOff_MrdcSnRelSnEvent(callInfo_type *ptCi, uint32_t type)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    if (type >= STAT_MRDC_SN_REL_SN_END)
    {
        return;
    }
    if (!IsAvailable_MrdcInfo())
    {
        return;
    }
    OFFBIT_U8TABLE(ptCi->mrdcInfo.stat.mrdcSnRelSn, type);
}

void FnVCCB_IncrementNrdcRelStat(callInfo_type *ptCi, int msgId, uint16_t xnCause, uint8_t reserved)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (IS_NRDC_MN(ptCi))
    {
        VCCB_MRDC_SN_REL_MN_STAT(NrdcRelMn_Total, ptCi, reserved);
        // MESSAGE_MAKE, XN_SNodeReleaseRequest_id
        if (XN_SNodeReleaseRequest_id == msgId)
        {
            if (RetainCategory_UeCtxtRelCommandByAMF == ptCi->retainStat.savedEventCategory)            
            {
                VCCB_MRDC_SN_REL_MN_STAT(NrdcRelMn_MnInit_UeContextRelease, ptCi, reserved);
            }
            switch (xnCause)
            {
                case CauseXnapRadioNetworkLayerUserInactivity:
                    VCCB_MRDC_SN_REL_MN_STAT(NrdcRelMn_MnInit_userInactivity, ptCi, reserved);
                    break;
                case CauseXnapRadioNetworkLayerUEPowerSaving:
                    VCCB_MRDC_SN_REL_MN_STAT(NrdcRelMn_MnInit_UeOverheating, ptCi, reserved);
                    break;
                // SVR22B FGR-CC5203: UE Custom Signature
                case CauseXnapRadioNetworkLayerFailureInTheRadioInterfaceProcedure:
                    if (VCCB_FLAG_ON == ptCi->nrdcScgFailureInfo.ueSignatureFlag)
                    {
                        VCCB_MRDC_SN_REL_MN_STAT(NrdcRelMn_MnInit_ueSignature, ptCi, 0);
                        return; // To avoid collecting NrdcScgFailure_t310Expiry for UE Signature call
                    }
                    break;
                default:
                    break;
            }

            const int NrdcRelMn_mapping[STAT_MRDC_SN_REL_MN_END] = {
                NrdcRelMn_MnInit_UeContextRelease,            /* StatMrdcSnRelMn_MnInit_UeContextRelease */
                NrdcRelMn_MnInit_IntraMnMobility,             /* StatMrdcSnRelMn_MnInit_IntraMnMobility */
                NrdcRelMn_MnInit_IntraMnMobilityWithSnChange, /* StatMrdcSnRelMn_MnInit_IntraMnMobilityWithSnChange */
                NrdcRelMn_MnInit_InterMnWithoutUeKeptInd,     /* StatMrdcSnRelMn_MnInit_InterMnWithoutUeKeptInd */
                NrdcRelMn_MnInit_InterMnWithUeKeptInd,        /* StatMrdcSnRelMn_MnInit_InterMnWithUeKeptInd */
                NrdcRelMn_MnInit_InterRatMobillity,           /* StatMrdcSnRelMn_MnInit_InterRatMobility */
                NrdcRelMn_MnInit_IntraNrRedirection,          /* StatMrdcSnRelMn_MnInit_IntraNrRedirection */
                NrdcRelMn_MnInit_t310Expiry,                  /* StatMrdcSnRelMn_MnInit_t310Expiry */
                NrdcRelMn_MnInit_randomAccessProblem,         /* StatMrdcSnRelMn_MnInit_randomAccessProblem */
                NrdcRelMn_MnInit_rlcMaxNumRetx,               /* StatMrdcSnRelMn_MnInit_rlcMaxNumRetx */
                NrdcRelMn_MnInit_synchReconfigFailureSCG,     /* StatMrdcSnRelMn_MnInit_synchReconfigFailureSCG */
                NrdcRelMn_MnInit_scgReconfigFailure,          /* StatMrdcSnRelMn_MnInit_scgReconfigFailure */
                NrdcRelMn_MnInit_t312Expiry,                  /* StatMrdcSnRelMn_MnInit_t312Expiry */
                NrdcRelMn_SnInit_SnMobility,                  /* StatMrdcSnRelMn_SnInit_SnMobility*/
            };

            const uint32_t NrdcRelMn_evenList[] = {
                StatMrdcSnRelMn_MnInit_IntraMnMobility,
                StatMrdcSnRelMn_MnInit_IntraMnMobilityWithSnChange,
                StatMrdcSnRelMn_MnInit_InterMnWithUeKeptInd,
                StatMrdcSnRelMn_MnInit_InterMnWithoutUeKeptInd,
                StatMrdcSnRelMn_MnInit_InterRatMobility,
                StatMrdcSnRelMn_MnInit_IntraNrRedirection,
                StatMrdcSnRelMn_SnInit_SnMobility,
            };

            const int size = sizeof(NrdcRelMn_evenList) / sizeof(NrdcRelMn_evenList[0]);
            int idx;
            for (idx = 0; idx < size; idx++)
            {
                uint32_t event = NrdcRelMn_evenList[idx];
                if (FnVCCB_get_MrdcSnRelMnEvent(ptCi, event))
                {
                    FnVCCB_setOff_MrdcSnRelMnEvent(ptCi, event);
                    if (event >= STAT_MRDC_SN_REL_MN_END) continue;

                    int mType = NrdcRelMn_mapping[event];
                    if (mType == -1) continue;

                    VCCB_MRDC_SN_REL_MN_STAT(mType, ptCi, reserved);
                }
            }

            if (xnCause == CauseXnapRadioNetworkLayerRadioConnectionWithUeLost)
            {
                /*
                 * NRDC_SCG_FAILURE_21D related types
                 * NrdcRelMn_MnInit_t310Expiry                                      = 11,
                 * NrdcRelMn_MnInit_randomAccessProblem                             = 12,
                 * NrdcRelMn_MnInit_rlcMaxNumRetx                                   = 13,
                 * NrdcRelMn_MnInit_synchReconfigFailureSCG                         = 14,
                 * NrdcRelMn_MnInit_scgReconfigFailure                              = 15,
                 * NrdcRelMn_MnInit_t312Expiry                                      = 16,
                 */

                VHCM_NRDC_SCG_FAILURE_STAT();  // NRDC_SCG_FAILURE_21D
            }
        }

        // MESSAGE_STORE, XN_SNodeReleaseRequired_id
        if (XN_SNodeReleaseRequired_id == msgId)
        {
            switch (xnCause)
            {
                case CauseXnapRadioNetworkLayerRadioConnectionWithUeLost:
                    VCCB_MRDC_SN_REL_MN_STAT(NrdcRelMn_SnInit_RadioConnectionWithUeLost, ptCi, reserved);
                    break;
                case CauseXnapRadioNetworkLayerTxnDcOverallExpiry:
                case CauseCpInternalSaTmOutXNSgnbReconfigurationComplete:
                    VCCB_MRDC_SN_REL_MN_STAT(NrdcRelMn_SnInit_TXnDCoverallExpiry, ptCi, reserved);
                    break;
                case CauseXnapRadioNetworkLayerUserInactivity:
                    VCCB_MRDC_SN_REL_MN_STAT(NrdcRelMn_SnInit_userInactivity, ptCi, reserved);
                    break;
                    // FGR-CC5200:FR720, FR723
                case CauseXnapRadioNetworkLayerSwitchOffOngoing:
                    VCCB_MRDC_SN_REL_MN_STAT(NrdcRelMn_SnInit_switchOffOngoing, ptCi, reserved);
                    break;
                default:
                    break;
            }
        }
    }
    else if (IS_NRDC_SN(ptCi))
    {
        VCCB_MRDC_SN_REL_SN_STAT(NrdcRelSn_Total, ptCi);
        switch (xnCause)
        {
            case CauseXnapRadioNetworkLayerRadioConnectionWithUeLost:
                // MESSAGE_STORE, XN_SNodeReleaseRequest_id
                if (XN_SNodeReleaseRequest_id == msgId)
                {
                    VCCB_MRDC_SN_REL_SN_STAT(NrdcRelSn_MnInit_RadioConnectionWithUeLost, ptCi);
                }

                // MESSAGE_MAKE, XN_SNodeReleaseRequired_id
                else if (XN_SNodeReleaseRequired_id == msgId)
                {
                    if (ptCi->cause.f1Cause == CauseF1apRadioRLFailure)
                    {
                        VCCB_MRDC_SN_REL_SN_STAT(NrdcRelSn_SnInit_RLFailureRLC, ptCi);
                    }
                    else if (ptCi->cause.f1Cause == CauseF1apRadioRLFailureothers)
                    {
                        VCCB_MRDC_SN_REL_SN_STAT(NrdcRelSn_SnInit_RLFailureOthers, ptCi);
                    }
                }
                break;

            case CauseXnapRadioNetworkLayerUserInactivity:
                // MESSAGE_STORE, XN_SNodeReleaseRequest_id
                if (XN_SNodeReleaseRequest_id == msgId)
                {
                    VCCB_MRDC_SN_REL_SN_STAT(NrdcRelSn_MnInit_userInactivity, ptCi);
                }

                // MESSAGE_MAKE, XN_SNodeReleaseRequired_id
                if (XN_SNodeReleaseRequired_id == msgId)
                {
                    VCCB_MRDC_SN_REL_SN_STAT(NrdcRelSn_SnInit_userInactivity, ptCi);
                }
                break;

            case CauseXnapRadioNetworkLayerUEPowerSaving:
                // MESSAGE_STORE, XN_SNodeReleaseRequest_id
                if (XN_SNodeReleaseRequest_id == msgId)
                {
                    VCCB_MRDC_SN_REL_SN_STAT(NrdcRelSn_MnInit_UePowerSaving, ptCi);
                }
                break;

            case CauseXnapRadioNetworkLayerMnMobility:
                if (XN_SNodeReleaseRequest_id == msgId)
                {
                    if (ptCi->RelCtxtKeptInd == TRUE)
                    {
                        FnVCCB_set_MrdcSnRelSnEvent(ptCi, StatMrdcSnRelSn_MnInit_MnMobilityWithUeKeptInd);
                    }
                    else
                    {
                        FnVCCB_set_MrdcSnRelSnEvent(ptCi, StatMrdcSnRelSn_MnInit_MnMobilityWithoutUeKeptInd);
                    }
                }
                break;

            // SVR22B FGR-CC5203: UE Custom Signature
            case CauseXnapRadioNetworkLayerFailureInTheRadioInterfaceProcedure:
                if (XN_SNodeReleaseRequest_id == msgId && VCCB_FLAG_ON == ptCi->nrdcScgFailureInfo.ueSignatureFlag)
                {
                    VCCB_MRDC_SN_REL_SN_STAT(NrdcRelSn_MnInit_ueSignature, ptCi);
                    return;         // CHECK!!!!
                }
                break;

                // FGR-CC5200:FR730, FR732
            case CauseXnapRadioNetworkLayerSwitchOffOngoing:
                if (XN_SNodeReleaseRequired_id == msgId)
                {
                    VCCB_MRDC_SN_REL_SN_STAT(NrdcRelSn_SnInit_switchOffOngoing, ptCi);
                }
                break;

            default:
                break;
        }

        const int NrdcRelSn_mapping[STAT_MRDC_SN_REL_SN_END] = {
            NrdcRelSn_MnInit_RadioConnectionWithUeLost,  /* StatMrdcSnRelSn_MnInit_RadioConnectionWithUeLost */
            NrdcRelSn_SnInit_RLFailureRLC,               /* StatMrdcSnRelSn_SnInit_RLFailureRLC */
            NrdcRelSn_SnInit_RLFailureOthers,            /* StatMrdcSnRelSn_SnInit_RLFailureOthers */
            NrdcRelSn_MnInit_MnMobilityWithUeKeptInd,    /* StatMrdcSnRelSn_MnInit_MnMobilityWithUeKeptInd */
            NrdcRelSn_MnInit_MnMobilityWithoutUeKeptInd, /* StatMrdcSnRelSn_MnInit_MnMobilityWithoutUeKeptInd */
            NrdcRelSn_SnInit_SnMobility,                 /* StatMrdcSnRelSn_SnInit_SnMobility */
        };

        const uint32_t NrdcRelSn_evenList[] = {
            StatMrdcSnRelSn_MnInit_MnMobilityWithUeKeptInd,
            StatMrdcSnRelSn_MnInit_MnMobilityWithoutUeKeptInd,
            StatMrdcSnRelSn_SnInit_SnMobility,
        };

        const int size = sizeof(NrdcRelSn_evenList) / sizeof(NrdcRelSn_evenList[0]);
        int idx;
        for (idx = 0; idx < size; idx++)
        {
            uint32_t event = NrdcRelSn_evenList[idx];
            if (FnVCCB_get_MrdcSnRelSnEvent(ptCi, event))
            {
                FnVCCB_setOff_MrdcSnRelSnEvent(ptCi, event);
                if (event >= STAT_MRDC_SN_REL_SN_END) continue;

                int mType = NrdcRelSn_mapping[event];
                if (mType == -1) continue;

                VCCB_MRDC_SN_REL_SN_STAT(mType, ptCi);
            }
        }
    }
}

// SVR22B FGR-CC5203: SCG Failure Handling for NR-DC (FR220)
void FnVCCB_IncrementNrdcScgFailureStat(callInfo_type *ptCi, enumScgFailureStatType_type type)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!IS_NRDC_SN(ptCi))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Not NRDC_SN in %s!!\n", __func__);
        return;
    }

    switch (ptCi->nrdcScgFailureInfo.failType)
    {
        case NrDcScgFailCause_dl_t310Expiry:  // 0
            if (SCG_FAIL_COUNT == type)
            {
                MACRO_STAT_PMCC(STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_t310Expiry_Count, ptCi, 0, 0, 0, 0, 0);  // 0
            }
            else if (SCG_FAIL_SUSPEND == type)
            {
                MACRO_STAT_PMCC(
                    STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_t310Expiry_Suspend, ptCi, 0, 0, 0, 0, 0);  // 11
            }
            else
            {
                MACRO_STAT_PMCC(STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_t310Expiry_Resume, ptCi, 0, 0, 0, 0, 0);  // 21
            }
            break;

        case NrDcScgFailCause_dl_randomAccessProblem:  // 1
            if (SCG_FAIL_COUNT == type)
            {
                MACRO_STAT_PMCC(
                    STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_randomAccessProblem_Count, ptCi, 0, 0, 0, 0, 0);  // 1
            }
            else if (SCG_FAIL_SUSPEND == type)
            {
                MACRO_STAT_PMCC(
                    STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_randomAccessProblem_Suspend, ptCi, 0, 0, 0, 0, 0);  // 12
            }
            else
            {
                MACRO_STAT_PMCC(
                    STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_randomAccessProblem_Resume, ptCi, 0, 0, 0, 0, 0);  // 22
            }
            break;

        case NrDcScgFailCause_dl_rlcMaxRetransmission:  // 2
            if (SCG_FAIL_COUNT == type)
            {
                MACRO_STAT_PMCC(
                    STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_rlcMaxNumRetx_Count, ptCi, 0, 0, 0, 0, 0);  // 2
            }
            else if (SCG_FAIL_SUSPEND == type)
            {
                MACRO_STAT_PMCC(
                    STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_rlcMaxNumRetx_Suspend, ptCi, 0, 0, 0, 0, 0);  // 13
            }
            else
            {
                MACRO_STAT_PMCC(
                    STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_rlcMaxNumRetx_Resume, ptCi, 0, 0, 0, 0, 0);  // 23
            }
            break;

        case NrDcScgFailCause_dl_synchReconfigFailure:  // 3
            if (SCG_FAIL_COUNT == type)
            {
                MACRO_STAT_PMCC(
                    STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_synchReconfigFailureSCG_Count, ptCi, 0, 0, 0, 0, 0);  // 3
            }
            else if (SCG_FAIL_SUSPEND == type)
            {
                MACRO_STAT_PMCC(STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_synchReconfigFailureSCG_Suspend, ptCi, 0, 0, 0,
                    0, 0);  // 14
            }
            else
            {
                MACRO_STAT_PMCC(STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_synchReconfigFailureSCG_Resume, ptCi, 0, 0, 0,
                    0, 0);  // 24
            }
            break;

        case NrDcScgFailCause_dl_scgReconfigFailure:  // 4
            if (SCG_FAIL_COUNT == type)
            {
                MACRO_STAT_PMCC(
                    STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_scgReconfigFailure_Count, ptCi, 0, 0, 0, 0, 0);  // 4
            }
            else if (SCG_FAIL_SUSPEND == type)
            {
                MACRO_STAT_PMCC(
                    STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_scgReconfigFailure_Suspend, ptCi, 0, 0, 0, 0, 0);  // 15
            }
            else
            {
                MACRO_STAT_PMCC(
                    STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_scgReconfigFailure_Resume, ptCi, 0, 0, 0, 0, 0);  // 25
            }
            break;

        case NrDcScgFailCause_dl_srb3IntegrityFailure:  // 5
            if (SCG_FAIL_COUNT == type)
            {
                MACRO_STAT_PMCC(
                    STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_srb3IntegrityFailure_Count, ptCi, 0, 0, 0, 0, 0);  // 6
            }
            else if (SCG_FAIL_SUSPEND == type)
            {
                MACRO_STAT_PMCC(
                    STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_srb3IntegrityFailure_Suspend, ptCi, 0, 0, 0, 0, 0);  // 17
            }
            else
            {
                MACRO_STAT_PMCC(
                    STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_srb3IntegrityFailure_Resume, ptCi, 0, 0, 0, 0, 0);  // 27
            }
            break;

        case NrDcScgFailCause_dl_scglbtFailure:  // 6 (r16)
        case NrDcScgFailCause_dl_bhRLF:          // 9 (r16)
            if (SCG_FAIL_COUNT == type)
            {
                MACRO_STAT_PMCC(STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_others_Count, ptCi, 0, 0, 0, 0,
                    0);  // 8 (only 'Count' is collected)
            }
            break;

        case NrDcScgFailCause_dl_beamFailureRecoveryFailure:  // 7 (r16)
            if (SCG_FAIL_COUNT == type)
            {
                MACRO_STAT_PMCC(STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_beamFailureRecoveryFailure_Count, ptCi, 0, 0,
                    0, 0, 0);  // 7
            }
            else if (SCG_FAIL_SUSPEND == type)
            {
                MACRO_STAT_PMCC(STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_beamFailureRecoveryFailure_Suspend, ptCi, 0, 0,
                    0, 0, 0);  // 18
            }
            else
            {
                MACRO_STAT_PMCC(STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_beamFailureRecoveryFailure_Resume, ptCi, 0, 0,
                    0, 0, 0);  // 28
            }
            break;

        case NrDcScgFailCause_dl_t312Expiry:  // 8 (r16)
            if (SCG_FAIL_COUNT == type)
            {
                MACRO_STAT_PMCC(STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_t312Expiry_Count, ptCi, 0, 0, 0, 0, 0);  // 5
            }
            else if (SCG_FAIL_SUSPEND == type)
            {
                MACRO_STAT_PMCC(
                    STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_t312Expiry_Suspend, ptCi, 0, 0, 0, 0, 0);  // 16
            }
            else
            {
                MACRO_STAT_PMCC(STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_t312Expiry_Resume, ptCi, 0, 0, 0, 0, 0);  // 26
            }
            break;

        case NrDcScgFailCause_ul_outOfSync:  // 10 (DU)
            if (SCG_FAIL_COUNT == type)
            {
                MACRO_STAT_PMCC(STAT_NRDC_SCG_FAILURE, NrdcScgFailure_UL_outOfSync_Count, ptCi, 0, 0, 0, 0, 0);  // 9
            }
            else if (SCG_FAIL_SUSPEND == type)
            {
                MACRO_STAT_PMCC(STAT_NRDC_SCG_FAILURE, NrdcScgFailure_UL_outOfSync_Suspend, ptCi, 0, 0, 0, 0, 0);  // 19
            }
            else
            {
                MACRO_STAT_PMCC(STAT_NRDC_SCG_FAILURE, NrdcScgFailure_UL_outOfSync_Resume, ptCi, 0, 0, 0, 0, 0);  // 29
            }
            break;

        case NrDcScgFailCause_ul_rlcMaxRetransmission:  // 11 (DU)
            if (SCG_FAIL_COUNT == type)
            {
                MACRO_STAT_PMCC(
                    STAT_NRDC_SCG_FAILURE, NrdcScgFailure_UL_rlcMaxNumRetx_Count, ptCi, 0, 0, 0, 0, 0);  // 10
            }
            else if (SCG_FAIL_SUSPEND == type)
            {
                MACRO_STAT_PMCC(
                    STAT_NRDC_SCG_FAILURE, NrdcScgFailure_UL_rlcMaxNumRetx_Suspend, ptCi, 0, 0, 0, 0, 0);  // 20
            }
            else
            {
                MACRO_STAT_PMCC(
                    STAT_NRDC_SCG_FAILURE, NrdcScgFailure_UL_rlcMaxNumRetx_Resume, ptCi, 0, 0, 0, 0, 0);  // 30
            }
            break;

        default:
        case NRDC_SCG_FAIL_CAUSE_TYPE_MAX:  // FR10. collect as others-r16 for unknown failureType
            if (VCCB_FLAG_OFF == ptCi->cgConfigInfo.scgFailureInfoFlag &&
                VCCB_FLAG_OFF == ptCi->cgConfigInfo.scgFailureInfoFlag_v1610)
            {
                if (SCG_FAIL_COUNT == type)
                {
                    MACRO_STAT_PMCC(STAT_NRDC_SCG_FAILURE, NrdcScgFailure_DL_others_Count, ptCi, 0, 0, 0, 0, 0);  // 8
                }
            }
            break;
    }
}

static inline
void FnVCCB_GenerateDrbInformation(callInfo_type &ci, drbInformation_type &drbInfo)
{
    callInfo_type *ptCi = &ci;

    uint32_t drbIdx = 0;

    emergencyArpInfo_type *pEmerArp = FnVCCB_FindEmergencyArpInfo(__func__, ptCi, &ptCi->ueInfo.servedPlmn, false);

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_CALL; drbIdx++)
    {
        callDRBInfo_type *ptDi = &ptCi->drb[drbIdx];
        dbgDrbInfo_type dbgDrbInfo;

        if (ptDi->usage != CI_use) continue;

        drbInfo.totalDrbCnt++;
        memset(&dbgDrbInfo, 0, sizeof(dbgDrbInfo));
        dbgDrbInfo.drbId = ptDi->dRBId;
        dbgDrbInfo.selectedBearerTypeFrozenFlag = ptDi->selectedBearerTypeFrozenFlag;
        dbgDrbInfo.selectedBearerType = ptDi->selectedBearerType.val;
        dbgDrbInfo.reqBearerType = ptDi->reqBearerType.val;
        dbgDrbInfo.bearerType = ptDi->bearerType.val;

        // Default DRB
        dbgDrbInfo.property.isDefaultDrb = ptDi->rbInfo.sdapInfo.defaultDRB == ci_default_drb_true;

        for (int index = 0; index < MAX_QOS_FLOW_PER_DRB; index++)
        {
            uint8_t selected5Qi = UINT8_MAX;

            if (ptDi->qosFlowIndex[index] >= MAX_QOS_FLOW_PER_CALL) continue;
            if (!IS_VALID_NODE(QOSFLOW_NODE, ptCi, &ptCi->qosFlow[ptDi->qosFlowIndex[index]])) continue;

            qosFlowInfo_type *ptQi = &ptCi->qosFlow[ptDi->qosFlowIndex[index]];

            VLIB_getFiveQi(ptQi, &selected5Qi);

            // 5QI#1 = VONR
            if (selected5Qi == VONR_5QI)
            {
                dbgDrbInfo.property.isVonr = VCCB_FLAG_ON;
            }

            // HighARP
            if (pEmerArp != NULL)
            {
                if (FnVCCB_CheckEmergencyBearerItem(__func__, ptCi, pEmerArp, ptQi->qosParam.allocAndRetent.priorityLevel, selected5Qi, false) == TRUE)
                {
                    dbgDrbInfo.property.isEmergency = VCCB_FLAG_ON;
                }
            }
        }

        switch (dbgDrbInfo.bearerType)
        {
            case MN_Term_MCG_Bearer:
                drbInfo.vMnTermMcgDrbList.push_back(dbgDrbInfo);
                break;
            case MN_Term_SPLIT_Bearer:
                drbInfo.vMnTermSplitDrbList.push_back(dbgDrbInfo);
                break;
            case SN_Term_SPLIT_Bearer:
                drbInfo.vSnTermSplitDrbList.push_back(dbgDrbInfo);
                break;
            case SN_Term_SCG_Bearer:
                drbInfo.vSnTermScgDrbList.push_back(dbgDrbInfo);
                break;
            default :
                VCCB_PRINT_CALL_ERROR(ptCi, "Invalid currentBearerType(D'%u, H'%x)\n", dbgDrbInfo.bearerType, dbgDrbInfo.bearerType);
                break;
        }
    }
}

static inline
void FnVCCB_ViewDrbInformation_AppendUeType(callInfo_type &ci, drbInformation_OutputBuffer_type &outBuf)
{
    callInfo_type *ptCi = &ci;

    auto getOptString = [&ptCi]()
    {
        int optCnt = 0;
        string optStr;

        auto setOptStr = [&optCnt, &optStr](const char *pStrFlag)
        {
            if (pStrFlag == NULL) return;

            // preprocessor
            {
                if (optCnt == 0)
                {
                    optStr.append("[");
                }
                else
                {
                    optStr.append(",");
                }
            }

            optStr.append(pStrFlag);
            optCnt++;
        };

        // fill data
        if (IsAvailable_MrdcInfo())
        {
            if (IS_NRDC(ptCi))
            {
                // Adding information on SCG suspend/resume status to NR-DC information
                if (IS_SCG_SUSPENDED(ptCi))
                {
                    setOptStr("S"); // NRDC SCG Suspend
                }
                else if (IS_SCG_RESUMING(ptCi))
                {
                    setOptStr("R"); // NRDC SCG Resume
                }
            }
        }

        if (IS_REDCAP_UE(ptCi))
        {
            setOptStr("RedCap"); // Redcap UE
        }

        if (FnVCCB_IsSetupedConditionalCell(ptCi))
        {
            string strCho = "C" + std::to_string(ptCi->condHoInfo.numOfCellList);
            setOptStr(strCho.c_str()); // Conditional Handover
        }

        // post-processor
        if (optCnt > 0)
        {
            optStr.append("] ");
        }

        return optStr;
    };

    string optString = getOptString();

    if (IsAvailable_MrdcInfo())
    {
        if (IS_NRDC_MN(ptCi))
        {
            LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "NR-DC (MN) %s", optString.c_str());
        }
        else if (IS_NRDC_SN(ptCi))
        {
            LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "NR-DC (SN) %s", optString.c_str());
        }
        else if (IS_NEDC_MN(ptCi))
        {
            LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "NE-DC (MN) %s", optString.c_str());
        }
        else
        {
            LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "Unk-DC (%d) %s", ptCi->selectedMrdcType, optString.c_str());
        }
    }
    else
    {
        LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "Non-DC %s", optString.c_str());
    }
}

static inline
void FnVCCB_ViewDrbInformation_AppendMnUeID(callInfo_type &ci, drbInformation_OutputBuffer_type &outBuf)
{
    callInfo_type *ptCi = &ci;

    bool isValidXnCallId = false;
    uint64_t xnCallId = INVALID_CALL_ID;  // NG-RANnodeUEXnAPID ::= INTEGER (0.. 4294967295)

    if (IS_MRDC_MN(ptCi))
    {
        xnCallId = ptCi->gnbCuUeId;
        isValidXnCallId = true;
    }
    else
    {
        if (INVALID_CALL_ID == ptCi->xnCallId)
        { /* no action*/
        }
        else
        {
            xnCallId = ptCi->xnCallId;
            isValidXnCallId = true;
        }
    }

    if (isValidXnCallId == false)
    {
        LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "MnUeId:- ");
    }
    else
    {
        LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "MnUeId:%u ", xnCallId);
    }
}

static inline
void FnVCCB_ViewDrbInformation_AppendSnUeID(callInfo_type &ci, drbInformation_OutputBuffer_type &outBuf)
{
    callInfo_type *ptCi = &ci;

    if (IS_MRDC_MN(ptCi))
    {
        LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "SnUeId:");

        // SRC_SN Information
        if (ptCi->mrdcInfo.SNInfo[SRC_SN].m.ueXnAPID)
        {
            LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "%u", ptCi->mrdcInfo.SNInfo[SRC_SN].ueXnAPID);
        }
        else
        {
            LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "-");
        }

        // TGT_SN Information
        if (ptCi->mrdcInfo.SNInfo[TGT_SN].m.ueXnAPID)
        {
            LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "->%u", ptCi->mrdcInfo.SNInfo[TGT_SN].ueXnAPID);
        }

        LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, " ");
    }
    else
    {
        if (INVALID_CALL_ID == ptCi->gnbCuUeId)
        { /* no action*/
            LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "SnUeId:- ");
        }
        else
        {
            LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "SnUeId:%u ", ptCi->gnbCuUeId);
        }
    }
}

static inline
void FnVCCB_ViewDrbInformation_AppendUpUeID(callInfo_type &ci, drbInformation_OutputBuffer_type &outBuf)
{
    uint16_t activeUpCnt = 0;

    for (uint16_t servingUpIdx = 0; servingUpIdx < MAX_CU_UP_PER_CALL; ++servingUpIdx)
    {
        if (ci.endPointInfo.aupf[servingUpIdx].usage == CI_use)
        {
            activeUpCnt++;
        }
    }

    if (activeUpCnt == 0) return;

    LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "UpUeId:");

    for (uint16_t servingUpIdx = 0; servingUpIdx < MAX_CU_UP_PER_CALL; ++servingUpIdx)
    {
        if (ci.endPointInfo.aupf[servingUpIdx].usage == CI_use)
        {
            LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "%u ", ci.upCallId[servingUpIdx]);
        }
    }
}

static inline
void FnVCCB_ViewDrbInformation_AppendDuUeID(callInfo_type &ci, drbInformation_OutputBuffer_type &outBuf)
{
    if (GET_F1_RESOURCE_FLAG(ci.flag.setupFlag))
    {
        LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "DuUeId:%u ", ci.auCallId);
    }
}

static inline void FnVCCB_ViewDrbInformation_AppendSvcGrpId(callInfo_type &ci, drbInformation_OutputBuffer_type &outBuf)
{
    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(ci);
    // installed rMeasConf.svcGrpId;
    // new rMeasConf.svcGrpNewId;

    if (ci.usage == CI_use)
    {
        LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "SvcGrpId:%d ", rMeasConf.svcGrpId);
    }
}

static inline
void FnVCCB_ViewDrbInformation_AppendPeerNeID(callInfo_type &ci, drbInformation_OutputBuffer_type &outBuf)
{
    callInfo_type *ptCi = &ci;

    if (IS_MRDC_MN(ptCi))
    {

        if (ptCi->mrdcInfo.SNInfo[SRC_SN].selectedPsCell.locationInfo.present == VCCB_FLAG_ON)
        {
            cgi_type *pTgtCgi = (IS_NRDC_MN(ptCi) ? &ptCi->mrdcInfo.SNInfo[SRC_SN].selectedPsCell.locationInfo.nrCgi
                                                    : &ptCi->mrdcInfo.SNInfo[SRC_SN].selectedPsCell.locationInfo.eCgi);

            LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "SnCI:%llu ",
                (unsigned long long)pTgtCgi->ci);
        }
        else
        {
            LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "SnCI:- ");
        }
    }
    else
    {
        MNInfo_type *ptSrcMnInfo = &ptCi->mrdcInfo.MNInfo[SRC_MN];
        MNInfo_type *ptTgtMnInfo = &ptCi->mrdcInfo.MNInfo[TGT_MN];

        const bool isValidSrcMnCGI = (ptSrcMnInfo->m.mnNRCGI == VCCB_FLAG_ON);
        const bool isValidTgtMnCGI = (ptTgtMnInfo->m.mnNRCGI == VCCB_FLAG_ON);

        if (ptTgtMnInfo->m.mnNRCGI == CI_use)
        {
            LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "MnCI:%s/%llu -> %s/%llu ",
                    (isValidSrcMnCGI ? "O" : "X"), (isValidSrcMnCGI ? ptSrcMnInfo->mnNRCGI.ci : 0),
                    (isValidTgtMnCGI ? "O" : "X"), (isValidTgtMnCGI ? ptTgtMnInfo->mnNRCGI.ci : 0));
        }
        else
        {
            LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "MnCI:%s/%llu ",
                (isValidSrcMnCGI ? "O" : "X"), (isValidSrcMnCGI ? ptSrcMnInfo->mnNRCGI.ci : 0));
        }
    }
}

#if 1
static inline
void FnVCCB_ViewDrbInformation_CurrentDRB(drbInformation_OutputBuffer_type &outBuf, drbInformation_type &drbInfo)
{
    auto sPrintDbgDrbInfo = [&](std::vector<dbgDrbInfo_type> &vDrbInfo)
    {
        if(vDrbInfo.size() == 0) return;

        int prtDrbCnt = 0;

        for (auto &dbgDrbInfo : vDrbInfo)
        {
            if (!prtDrbCnt)
            {
                LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "%s(", FnVCCB_GetStrBearerType(static_cast<int>(dbgDrbInfo.bearerType)));
            }
            else
            {
                LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, ",");
            }

            LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "%u", dbgDrbInfo.drbId);

            if (dbgDrbInfo.property.isDefaultDrb) LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "D");
            if (dbgDrbInfo.property.isVonr) LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "V");
            if (dbgDrbInfo.property.isEmergency) LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "E");

            if (dbgDrbInfo.bearerType != MN_Term_MCG_Bearer ||
                (dbgDrbInfo.bearerType == MN_Term_MCG_Bearer &&
                    (DBG->flag.logNrdcBasic || (dbgDrbInfo.property.isDefaultDrb || dbgDrbInfo.property.isVonr ||
                                                   dbgDrbInfo.property.isEmergency))))
            {
                LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "<%u,%u,%u,%u>",
                    dbgDrbInfo.selectedBearerTypeFrozenFlag, dbgDrbInfo.selectedBearerType, dbgDrbInfo.reqBearerType,
                    dbgDrbInfo.bearerType);
            }
            prtDrbCnt++;
        }
        LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, ") ");
    };

    sPrintDbgDrbInfo(drbInfo.vMnTermMcgDrbList);
    sPrintDbgDrbInfo(drbInfo.vMnTermSplitDrbList);
    sPrintDbgDrbInfo(drbInfo.vSnTermSplitDrbList);
    sPrintDbgDrbInfo(drbInfo.vSnTermScgDrbList);
}
#else
static inline
void FnVCCB_ViewDrbInformation_CurrentDRB(drbInformation_OutputBuffer_type &outBuf, drbInformation_type &drbInfo)
{
    int prtDrbCnt = 0, prtRbCnt = 0;
    uint32_t mrdcRbType = 0, mrdcRbIdx = 0;

    for (mrdcRbType = 0; mrdcRbType <= MRDC_BEARER_TYPE_END; mrdcRbType++)
    {
        if (drbInfo.current.drbCnt[mrdcRbType] == 0) continue;

        if (prtRbCnt > 0) LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, " ");

        LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "%s:(", FnVCCB_GetStrBearerType((enumMrdcBearerType)mrdcRbType));

        const uint32_t maxLen = MIN(drbInfo.current.drbCnt[mrdcRbType], MAX_DRB_PER_CALL);

        prtDrbCnt = 0;

        for (mrdcRbIdx = 0; mrdcRbIdx < maxLen; mrdcRbIdx++)
        {
            if (prtDrbCnt > 0)
            {
                LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, ",");
            }

            LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "%u", drbInfo.current.drbId[mrdcRbType][mrdcRbIdx]);

            if (drbInfo.extensionDrbInfo[mrdcRbType][mrdcRbIdx].isDefaultDrb) LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "D");
            if (drbInfo.extensionDrbInfo[mrdcRbType][mrdcRbIdx].isVonr) LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "V");
            if (drbInfo.extensionDrbInfo[mrdcRbType][mrdcRbIdx].isEmergency) LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "E");

            prtDrbCnt++;
        }

        LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, ")");

        prtRbCnt++;
    }
}

static inline
void FnVCCB_ViewDrbInformation_RequestDRB(drbInformation_OutputBuffer_type &outBuf, drbInformation_type &drbInfo)
{
    int prtDrbCnt = 0, prtRbCnt = 0;
    uint32_t mrdcRbType = 0, mrdcRbIdx = 0;

    LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, " -> ");

    for (mrdcRbType = 0; mrdcRbType <= MRDC_BEARER_TYPE_END; mrdcRbType++)
    {
        if (drbInfo.diff.drbCnt[mrdcRbType] == 0) continue;

        if (prtRbCnt > 0) LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, " ");

        LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "%s:(", FnVCCB_GetStrBearerType((enumMrdcBearerType)mrdcRbType));

        const uint32_t maxLen = MIN(drbInfo.diff.drbCnt[mrdcRbType], MAX_DRB_PER_CALL);

        prtDrbCnt = 0;

        for (mrdcRbIdx = 0; mrdcRbIdx < maxLen; mrdcRbIdx++)
        {
            if (prtDrbCnt > 0)
            {
                LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, ",");
            }

            LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "%u", drbInfo.diff.drbId[mrdcRbType][mrdcRbIdx]);

            prtDrbCnt++;
        }

        LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, ")");

        prtRbCnt++;
    }
}
#endif

static inline
void FnVCCB_ViewDrbInformation_OutputBuffer(callInfo_type &ci, drbInformation_OutputBuffer_type &outBuf)
{
    callInfo_type *ptCi = &ci;

    const int MAX_PRINT_LINE = 3;  // Maximum Limit 3 Line
    const int MAX_SIZE_OF_LINE = (SHM_LOG_BRIEF_LEN - 3);

    if (outBuf.strLen < MAX_SIZE_OF_LINE)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "%.*s\n", MAX_LOCAL_STR_SIZE, outBuf.mrLogBuf);
        VCCB_PRINT_CALL_MSCGEN_INFORMATIVE(ptCi, "%.*s\n", MAX_LOCAL_STR_SIZE, outBuf.mrLogBuf);
    }
    else
    {
        char strLineBuff[MAX_SIZE_OF_LINE + 1] = {'\0'};

        for (int line = 0; line < MIN(MAX_PRINT_LINE, (outBuf.strLen + MAX_SIZE_OF_LINE - 1) / MAX_SIZE_OF_LINE); line++)
        {
            strncpy(strLineBuff, &outBuf.mrLogBuf[line * MAX_SIZE_OF_LINE], MAX_SIZE_OF_LINE);
            strLineBuff[MAX_SIZE_OF_LINE] = '\0';
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "%s\n", strLineBuff);
            VCCB_PRINT_CALL_MSCGEN_INFORMATIVE(ptCi, "%.*s\n", MAX_LOCAL_STR_SIZE, strLineBuff);
        }
    }
}

static inline
void FnVCCB_ViewDrbInformation(callInfo_type &ci, drbInformation_type &drbInfo)
{
    callInfo_type *ptCi = &ci;

    /* DRB Information */
    drbInformation_OutputBuffer_type outBuf;

    /* Initialize */
    outBuf.strLen = 0;
    outBuf.mrLogBuf[0] = '\0';

    // NR-DC (MN), NR-DC (SN), NE-DC (MN), Unk-DC (X), Non-DC, Non-DC(Redcap)
    FnVCCB_ViewDrbInformation_AppendUeType(ci, outBuf);

    if (IsAvailable_MrdcInfo())
    {
        // MnUeId:80
        FnVCCB_ViewDrbInformation_AppendMnUeID(ci, outBuf);

        // SnUeId:188
        FnVCCB_ViewDrbInformation_AppendSnUeID(ci, outBuf);
    }

    // UpUeId:2
    FnVCCB_ViewDrbInformation_AppendUpUeID(ci, outBuf);

    // DuUeId:4
    FnVCCB_ViewDrbInformation_AppendDuUeID(ci, outBuf);

    // MnCI:1966735360 or SnCI:1966784757
    if (IsAvailable_MrdcInfo())
    {
        FnVCCB_ViewDrbInformation_AppendPeerNeID(ci, outBuf);
    }

    // / DRB Cnt:0
    LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, "/ DRB Cnt:%d", drbInfo.totalDrbCnt);

    if (drbInfo.totalDrbCnt > 0)
    {
        LOGBUF(outBuf.mrLogBuf, MAX_LOCAL_STR_SIZE, &outBuf.strLen, " ");

        // MN_MCG:(2v,3Dv,4,6), SN_SCG:(7,8), SN_SPLIT:(1), MN_SPLIT:(5)
        FnVCCB_ViewDrbInformation_CurrentDRB(outBuf, drbInfo);
    }
    FnVCCB_ViewDrbInformation_AppendSvcGrpId(ci, outBuf);

    // Output Buffer.
    FnVCCB_ViewDrbInformation_OutputBuffer(ci, outBuf);
}

void FnVCCB_PrintMrdcDrbInformation(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    /* DRB Information */
    drbInformation_type drbInfo;

    /* Initialize */
    // it is not guranteed that memset of c++ will be work correctly to initialize object attribues.
    //memset(&drbInfo, 0x00, sizeof(drbInformation_type));
    drbInfo.totalDrbCnt = 0;

    FnVCCB_GenerateDrbInformation(*ptCi, drbInfo);

    FnVCCB_ViewDrbInformation(*ptCi, drbInfo);
}

/****************************************************************************
 * @brief           This function indicates whether it is necessary to send an XN SNODE RECONFIGURATION COMPLETE.
 *
 * @param[in]       ptCi : pointer of callinfo / callInfo_type
 * @return          status : true,false / bool
 ****************************************************************************/
bool FnVCCB_NeedToSendXnSNodeReconfigurationComplete(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (!IS_MRDC_MN(ptCi)) return false;

    // default scenario
    if (IS_ON_MRDC_XN_RCVINDICATOR_FLAG(scgCellGrpCfg)) return true;

    if (IS_ON_MRDC_XN_RCVINDICATOR_FLAG(scgRBCfg)) return true;

    return false;
}

/****************************************************************************
 * @brief           This function indicates whether it is necessary to recv an XN SNODE RECONFIGURATION COMPLETE.
 *
 * @param[in]       ptCi : pointer of callinfo / callInfo_type
 * @return          status : true,false / bool
 ****************************************************************************/
bool FnVCCB_NeedToRecvXnSNodeReconfigurationComplete(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (!IS_NRDC_SN(ptCi)) return false;

    // default scenario
    if (IS_ON_MRDC_XN_SNDINDICATOR_FLAG(scgCellGrpCfg)) return true;

    if (IS_ON_MRDC_XN_SNDINDICATOR_FLAG(scgRBCfg)) return true;

    return false;

    // return false;
}

/****************************************************************************
 * @brief           This function indicates a situation in which SN RRC Reconfiguration Complete should be received from
 *the MN side.
 *
 * @param[in]       ptCi : pointer of callinfo / callInfo_type
 * @return          status : true,false / bool
 ****************************************************************************/
VCCB_STATIC VCCB_INLINE bool FnVCCB_ShouldBeReceivedSNRRCReconfigurationCompleteMn(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (!IS_MRDC_MN(ptCi)) return false;

    // if the RRCReconfiguration message includes the mrdc-SecondaryCellGroupConfig with mrdc-SecondaryCellGroup set to
    // nr-SCG: 3> include in the nr-SCG-Response the RRCReconfigurationComplete message;
    if (IS_ON_MRDC_XN_RCVINDICATOR_FLAG(scgCellGrpCfg)) return true;

    return false;
}

/****************************************************************************
 * @brief           This function indicates a situation in which SN RRC Reconfiguration Complete should be received from
 *the SN side.
 *
 * @param[in]       ptCi : pointer of callinfo / callInfo_type
 * @return          status : true,false / bool
 ****************************************************************************/
VCCB_STATIC VCCB_INLINE bool FnVCCB_ShouldBeReceivedSNRRCReconfigurationCompleteSn(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB, false);

    if (!IS_NRDC_SN(ptCi)) return false;

    // if the RRCReconfiguration message includes the mrdc-SecondaryCellGroupConfig with mrdc-SecondaryCellGroup set to
    // nr-SCG: 3> include in the nr-SCG-Response the RRCReconfigurationComplete message;
    if (IS_ON_MRDC_XN_SNDINDICATOR_FLAG(scgCellGrpCfg)) return true;

    // validation fail, need scg-response
    return false;
}

/****************************************************************************
 * @brief           This function indicates a situation in which SN RRC Reconfiguration Complete should be received from
 *the MN/SN side.
 *
 * @param[in]       ptCi : pointer of callinfo / callInfo_type
 * @return          status : true,false / bool
 ****************************************************************************/
uint8_t FnVCCB_ShouldBeReceivedSNRRCReconfigurationComplete(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    bool bRet = false;

    if (IS_MRDC_MN(ptCi)) bRet = FnVCCB_ShouldBeReceivedSNRRCReconfigurationCompleteMn(ptCi);

    if (IS_NRDC_SN(ptCi)) bRet = FnVCCB_ShouldBeReceivedSNRRCReconfigurationCompleteSn(ptCi);

    return (bRet == true ? YES : NO);
}

/****************************************************************************
 * @brief           This function determines whether the RRC Reconfiguration Complete container to be sent to the SN
 *will be included.
 *
 * @param[in]       pRrcReconfBuff : pointer of reconfiguration buffer / RrcReconfigurationCompleteBuff_type
 * @return          status : true,false / bool
 ****************************************************************************/
bool FnVCCB_CanBeIncludedSNRRCReconfigurationComplete(RrcReconfigurationCompleteBuff_type *pRrcReconfBuff)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(pRrcReconfBuff, false);

    // Check Reconfiguration Type
    if (pRrcReconfBuff->responseType == NO_RECONFIGURATION_COMPLETE_PRESENT)
    {
        return false;  // empty reconfiguration cmple
    }

    // Check Length
    if (pRrcReconfBuff->message.length == 0)
    {
        return false;  // empty reconfiguration cmple
    }

    // Check Value Pointer
    if (pRrcReconfBuff->message.value == NULL)
    {
        return false;  // empty reconfiguration cmple
    }

    return true;
}

int FnVCCB_EnqueueActionTrafficStatusReportForNrdc(callInfo_type *ptCi, enumTrafficStatusRptDir_type dir)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    int status = GOOD;

    if (dir == TRF_STATUS_RPT_DL)
    {
        status = VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_DL_TRAFFIC_STATUS_REPORT_FOR_NRDC);
        if (status == ERROR)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "ERROR, VCCM_enqueueAction(ENQUEUE_ACTION_DL_TRAFFIC_STATUS_REPORT_FOR_NRDC)!!\n");
        }
        else
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "enqueue ENQUEUE_ACTION_DL_TRAFFIC_STATUS_REPORT_FOR_NRDC!!\n");
        }
    }
    else
    {
        status = VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_UL_TRAFFIC_STATUS_REPORT_FOR_NRDC);
        if (status == ERROR)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "ERROR, VCCM_enqueueAction(ENQUEUE_ACTION_UL_TRAFFIC_STATUS_REPORT_FOR_NRDC)!!\n");
        }
        else
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "enqueue ENQUEUE_ACTION_UL_TRAFFIC_STATUS_REPORT_FOR_NRDC!!\n");
        }
    }
    return status;
}

bool FnVCCB_IsAnyNrdcBearer(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    for (uint8_t drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; ++drbIdx)
    {
        callDRBInfo_type *pDi = &ptCi->drb[drbIdx];
        if (!IS_NRDC_BEARER(pDi)) continue;
        return true;
    }
    return false;
}
enumMrdcType_type FnVCCB_DecideMrdcTypeForCell(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, MRDC_NONE);
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, MRDC_NONE);
    enumMrdcType_type mrdcType = MRDC_NONE;

    switch (DBG->mrdcTypePrefer.preferType)
    {
        case MRDC_TYPEPREF_NRDC_PREF:
            if (ptCi->snAddFailCntWithSelectedMrdcType <= DBG->mrdcTypePrefer.failoverCnt)
            {
                if (IS_SUPPORT_NRDC_FOO() && IS_SUPPORT_NRDC_Yang(cellNum))
                {
                    mrdcType = MRDC_NRDC;
                }
                else if (IsSupport_NEDC_Foo() && IsSupport_NEDC_Yang(cellNum))
                {
                    mrdcType = MRDC_NEDC;
                }
                else
                {
                    mrdcType = MRDC_NONE;
                }
            }
            else
            {
                if (IsSupport_NEDC_Foo() && IsSupport_NEDC_Yang(cellNum))
                {
                    mrdcType = MRDC_NEDC;
                }
                else
                {
                    mrdcType = MRDC_NONE;
                }
            }
            break;

        case MRDC_TYPEPREF_NEDC_PREF:
            if (ptCi->snAddFailCntWithSelectedMrdcType <= DBG->mrdcTypePrefer.failoverCnt)
            {
                if (IsSupport_NEDC_Foo() && IsSupport_NEDC_Yang(cellNum))
                {
                    mrdcType = MRDC_NEDC;
                }
                else if (IS_SUPPORT_NRDC_FOO() && IS_SUPPORT_NRDC_Yang(cellNum))
                {
                    mrdcType = MRDC_NRDC;
                }
                else
                {
                    mrdcType = MRDC_NONE;
                }
            }
            else
            {
                if (IS_SUPPORT_NRDC_FOO() && IS_SUPPORT_NRDC_Yang(cellNum))
                {
                    mrdcType = MRDC_NRDC;
                }
                else
                {
                    mrdcType = MRDC_NONE;
                }
            }
            break;

        case MRDC_TYPEPREF_NRDC:
            if (IS_SUPPORT_NRDC_FOO() && IS_SUPPORT_NRDC_Yang(cellNum))
            {
                mrdcType = MRDC_NRDC;
            }
            else
            {
                mrdcType = MRDC_NONE;
            }
            break;

        case MRDC_TYPEPREF_NEDC:
            if (IsSupport_NEDC_Foo() && IsSupport_NEDC_Yang(cellNum))
            {
                mrdcType = MRDC_NEDC;
            }
            else
            {
                mrdcType = MRDC_NONE;
            }
            break;

        case MRDC_TYPEPREF_NONE:
            mrdcType = MRDC_NONE;
            break;

        default:
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Invalid preferType(%u) (cellNum:%u).\n", DBG->mrdcTypePrefer.preferType, cellNum);
            mrdcType = MRDC_NONE;
    }

    VCCB_PRINT_CALL_MSG(ptCi, "decided mrdc type is (%d) (cellNum:%u)\n", mrdcType, cellNum);

    return mrdcType;
}

int FnVCCB_CommonCheckTrfStatusRptCfgforNrdc(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    int16_t status = GOOD, a4MeasId = ERROR;

    a4MeasId = VCCB_FindInstalledMeasId_ByFreqReportPurpose(ptCi, 0, measReport_A4, a4Purpose_NrdcAddition);

    if (ptCi->state == STATE_Conn)
    {
        if (!IS_SELECTED_MRDC(MRDC_NRDC))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "Not SELECTED NRDC in %s!!\n", __func__);
            status = ERROR;
            goto CHK_TRF_RPT_CFG_EXCEPTION;
        }
    }
    else
    {
        if (!IS_MRDC_TYPE_FOR_CELLNUM(ptCi, cellNum, MRDC_NRDC))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "Not MRDC_NRDC for cellNum(%u) in %s!!\n", cellNum, __func__);
            status = ERROR;
            goto CHK_TRF_RPT_CFG_EXCEPTION;
        }
    }

    if (!IS_SUPPORT_NRDC(ptCi, cellNum))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Not support NR-DC cellNum(%u)!\n", cellNum);
        status = ERROR;
        goto CHK_TRF_RPT_CFG_EXCEPTION;
    }

    if (!VCCB_TRAFFIC_BASED_NRDC_ADD_MODE(ptCi, cellNum))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Neither Nrdc OprMod3 nor OprMod4 in %s!!\n", __func__);
        status = ERROR;
        goto CHK_TRF_RPT_CFG_EXCEPTION;
    }

    if (IS_NRDC_SN(ptCi))
    {
        status = ERROR;
        goto CHK_TRF_RPT_CFG_EXCEPTION;
    }

    if (IS_NRDC_MN(ptCi) && !(IS_NRDC_SNREL_INVOKED(ptCi) && (STATE_Conn != ptCi->state)))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Already NRDC Connected or in Progress in %s!!\n", __func__);
        status = ERROR;
        goto CHK_TRF_RPT_CFG_EXCEPTION;
    }

    // SVR22C2 FGR-CC5203 FR111
    if (NOT_ALLOW_SN_ADDITION_UE_SIGNATURE(ptCi))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "Sn addition is not allowed by UE Signature call in %s. ueSignature(%d) allowSnAdditionFlag(%d)\n",
            __func__, ptCi->nrdcScgFailureInfo.ueSignatureFlag,
            ptCi->nrdcScgFailureInfo.allowSNAdditionUECustomSignature);
        status = ERROR;
        goto CHK_TRF_RPT_CFG_EXCEPTION;
    }

    if (FALSE == FnVCCB_CheckAllowedConcurrentNRDCandVoNR(ptCi, cellNum))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "TrafficReportConfig for Nrdc is skipped because VoNR is in service and concurrent is not allowed!\n");
        status = ERROR;
        goto CHK_TRF_RPT_CFG_EXCEPTION;
    }

    if (!FnVCCB_IsAnyNrdcBearer(ptCi))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Not FnVCCB_IsAnyNrdcBearer in %s!!\n", __func__);
        status = ERROR;
        goto CHK_TRF_RPT_CFG_EXCEPTION;
    }

    if (FnVCCB_IsNrdcProhibitedByLtmHO(*ptCi, FnVCCB_GetCellSelectionForConfig(ptCi).bandNr))
    {
        VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "NR-DC is prohibited due to LTM-UE in %s!!!\n", __func__);
        status = ERROR;
        goto CHK_TRF_RPT_CFG_EXCEPTION;
    }
    //

    if (FnVCCB_CheckNrdcMode(*ptCi, cellNum, NRDC_MODE4_TRAFFIC_MR_BASED_MODE) && a4MeasId != ERROR)
    {
        if (GET_RCV_TrfStatusRptForNrdcAddition(ptCi))
        {
            VCCB_PRINT_CALL_COMMENT(
                ptCi, "A4 MeasCfg for nrdc-addition has been already installed in %s!!\n", __func__);
            status = BREAK;
            goto CHK_TRF_RPT_CFG_EXCEPTION;
        }
        else
        {
            // cell might be changed from oprMod2 cell to oprMod4 cell.
            VCCB_PRINT_CALL_COMMENT(
                ptCi, "MeasCfg(A4) was installed but Not RCV_DlTrfStatusRptforNrdcAddition in %s!!\n", __func__);
            status = ERROR;
            goto CHK_TRF_RPT_CFG_EXCEPTION;
        }
    }

    if (GET_RCV_TrfStatusRptForNrdcAddition(ptCi))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "TrafficStatusRpt(dl:%llu, ul:%llu) has already done!!\n",
            1ULL * GET_RCV_DlTrfStatusRptForNrdcAddition(ptCi), 1ULL * GET_RCV_UlTrfStatusRptForNrdcAddition(ptCi));
        status = BREAK;
        goto CHK_TRF_RPT_CFG_EXCEPTION;
    }

    return GOOD;

CHK_TRF_RPT_CFG_EXCEPTION:
    if (status == ERROR)
    {
        if (GET_RCV_TrfStatusRptForNrdcAddition(ptCi))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "OFF_RCV_TrfStatusRptforNrdcAddition(prevDl:%llu, prevUl:%llu) in %s!!\n",
                1ULL * GET_RCV_DlTrfStatusRptForNrdcAddition(ptCi), 1ULL * GET_RCV_UlTrfStatusRptForNrdcAddition(ptCi),
                __func__);

            OFF_RCV_TrfStatusRptForNrdcAddition(ptCi);
        }
    }

    return status;
}

int16_t FnVCCB_NeedToDlTrfStatusRptCfgforNrdcAddPerDRB(callInfo_type *ptCi, callDRBInfo_type *pDi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDi);

    if (!pDi->selectedBearerTypeFrozenFlag)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Not selectedBearerTypeFrozenFlag in %s!!\n", __func__);
        return BREAK;
    }

    if (pDi->selectedBearerType.val != MN_Term_SPLIT_Bearer && pDi->selectedBearerType.termPoint != TermPoint_Sn)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Not Candidate for bearerTypeChg in %s!!\n", __func__);
        return BREAK;
    }

    return GOOD;
}

bool FnVCCB_IsSRB3Available(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (!IS_NRDC_SN(ptCi))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Not NRDC_SN in %s!!\n", __func__);
        goto RETURN_FALSE;
    }

    if (ptCi->srb3Idx >= MAX_SRB_PER_CALL)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "srb3 was not setup in %s!!\n", __func__);
        goto RETURN_FALSE;
    }

    if (ptCi->srb3Prohibited)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "srb3 is prohibited(H'0x%x) temporarily in %s!!\n", ptCi->srb3Prohibited, __func__);
        goto RETURN_FALSE;
    }

    return true;

RETURN_FALSE:

    return false;
}

void FnVCCB_InitAllowedBCList(callInfo_type *ptCi, bandCombinationInfoList_type *pAllowedBCList)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pAllowedBCList);

    const uint32_t len = sizeof(*pAllowedBCList) - sizeof(pAllowedBCList->bandCombinationInfoFilteredSelectedBc);
    memset(pAllowedBCList, 0, len);

    const uint32_t len1 = sizeof(ptCi->ueInfo.allowedBCListEutraBandIndiBitMap);
    const uint32_t len2 = sizeof(ptCi->ueInfo.allowedBCListNrBandIndiBitMap);
    const uint32_t maxLen = MAX(len1, len2);
    memset(ptCi->ueInfo.allowedBCListNrBandIndiBitMap, 0, maxLen);
    pAllowedBCList->cellIdentity = MAX_CELL_IDENTITY;

    SET_SUPPORT_NRDC_UECAPA(ptCi, VCCB_FLAG_OFF);
}


/***************************************************************************************
 * Function      : FnVCCB_CheckPcellInfoChangedforAllowedBC
 * Description   : this function is for Pre-check whether to set up a new AllowedBCList
 * Proc called   :
 * Proc calling  :
 * Input         : callInfo_type *, CellNum_type , FreqBandInd_type
 * Output        : bool (true/false)
 * Update History:
 **************************************************************************************/
bool FnVCCB_CheckPcellInfoChangedforAllowedBC(callInfo_type *ptCi, CellNum_type cellNum, FreqBandInd_type cellBand)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);

    // This function is used to check in advance whether to install a new AllowedBCList, so if the band of the target
    // cell is 0 (BAND_NOT_FOUND), it is processed as abnormal and returned false.
    if (cellBand == BAND_NOT_FOUND)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "cellBand is not found (%s)\n", __func__);
        return false;
    }

    bandCombinationInfoList_type *pCurrAllowedBCList = &ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC;
    cellInfo_s *pCell = &CELLINFO[cellNum];

    bool changed = false;

    // if (pCurrAllowedBCList->nrofBandComb == 0)
    // {
    //     changed = true; TODO: need to check
    // }
    if (pCurrAllowedBCList->mrdcType != GET_SELECTED_MRDC(ptCi))
    {
        changed = true;  // TODO: need to check ho case.
    }
    if (pCurrAllowedBCList->pcellBandIndi != cellBand)
    {
        changed = true;
    }
    if (pCurrAllowedBCList->nrScsDl != pCell->nrScsDl)
    {
        changed = true;
    }
    if (pCurrAllowedBCList->bandwidthDl != pCell->intraGnbNbrInfo.bandwidthDl)
    {
        changed = true;
    }

    if (changed)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi,
            "Pcell Info changed: nrofBandComb(%u) selectedMrdcType(%u=>%u) pcellBandIndi(%u=>%u) nrScsDl(%u=>%u) "
            "bandwidthDl(%u=>%u) in %s\n",
            pCurrAllowedBCList->nrofBandComb, pCurrAllowedBCList->mrdcType, GET_SELECTED_MRDC(ptCi),
            pCurrAllowedBCList->pcellBandIndi, cellBand, pCurrAllowedBCList->nrScsDl, pCell->nrScsDl,
            pCurrAllowedBCList->bandwidthDl, pCell->intraGnbNbrInfo.bandwidthDl, __func__);
    }
    return changed;
}

// This api could be called to support nrdc/nedc addition at finalization api after mobility such as HO, RRE, RESUME.
// if ho or rre could continue nrdc-connected state without sn-release, ctrlFlag shall be only MRDCCTRL_RECFG_MEASCFG.
void FnVCCB_ReinstallMrdcBaseInfoAfterMobility(callInfo_type *ptCi, CellNum_type cellNum, FreqBandInd_type cellBand, uint8_t ctrlFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    bandCombinationInfoList_type *pCurrAllowedBCList = &ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC;
    cellInfo_s *pCell = &CELLINFO[cellNum];

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "no need to reinstall mrdc-baseInfo in case of not E_CALLTYPE_SA!\n");

        return;
    }

    if (IS_NRDC_SN(ptCi))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "no need to reinstall mrdc-baseInfo in case of NRDC_SN !\n");

        return;
    }

    // FGR-CC5200:FR482
    if (pCell->cellIdentity != ptCi->nrdcAddCacRejectedFreq.cellId)
    {
        FnVCCB_InitNrdcAddCacRejectedFreq(ptCi);
    }

    if (pCell->cellIdentity != pCurrAllowedBCList->cellIdentity) // cell was changed from AllowedBCList composition point of view or nrdc is not available -> nrdc is available
    {
        OFF_RCV_UlTrfStatusRptForNrdcAddition(ptCi);
    }

    if (!(ptCi->stateCmd == RrcReestablish_cmd && ptCi->ueInfo.reestablishInfo.oldCellNum == ptCi->servCellNum))
    {
        FnVCCB_InitNrdc2NrcaLBCtxt(*ptCi);
    }

    if (GET_RCV_DlTrfStatusRptForNrdcAddition(ptCi))
    {
        uint16_t threshold = 0;

        if (!VCCB_TRAFFIC_BASED_NRDC_ADD_MODE(ptCi, cellNum))
        {
            OFF_RCV_DlTrfStatusRptForNrdcAddition(ptCi);
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "nrdcOprMode of new ServCellNum(%u) is neither 3 nor 4, so rcvDlTrfStatusRptForNrdcAddition is OFF!\n",
                cellNum);
        }
        else if (ERROR == VCCB_GetTrafficMonitoringCfgDB(ptCi, cellNum, NRDC_TRAFFIC_BASED_ADDITION_purpose,
                              THRESHOLD_ABOVE_condition, &threshold))
        {
            OFF_RCV_DlTrfStatusRptForNrdcAddition(ptCi);
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "Yang traffic-monitoring-configuration for nrdcAddition is not configured, so "
                "rcvUlTrfStatusRptForNrdcAddition is OFF!\n");
        }
    }

    if (ctrlFlag & MRDCCTRL_SELECT_MRDCTYPE)
    {
        FnVCCB_SetSelectedMrdcType(ptCi, cellNum, MRDC_END);
    }

    if (ctrlFlag & MRDCCTRL_SELECT_BEARERTYPE)
    {
        FnVCCB_RefreshMrdcSelectedBearerType(ptCi);
    }

    if (ctrlFlag & MRDCCTRL_SET_ALLOWEDBCLIST)
    {
        bool needRefreshAllowedBCList = false;
        uint8_t newSelectedMrdcType = GET_SELECTED_MRDC(ptCi);

        if (FnVCCB_CheckPcellInfoChangedforAllowedBC(ptCi, cellNum, cellBand))
        {
            FnVCCB_InitAllowedBCList(ptCi, pCurrAllowedBCList);
            needRefreshAllowedBCList = true;
        }

        if (newSelectedMrdcType != MRDC_NEDC && newSelectedMrdcType != MRDC_NRDC)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid Selected Mrdc Type(%d) in %s\n", newSelectedMrdcType, __func__);

            return;
        }

        if (needRefreshAllowedBCList)
        {
            int16_t status = GOOD;
            bigmsgUnpack_type *ptUnpackUeCapa = &THREAD_INFO->call[ptCi->myThreadId].buf.unpack.ueCapa;

            switch (newSelectedMrdcType)
            {
                case MRDC_NEDC:
                    if (ptCi->ueContainerMRDC.rxFlag && ptCi->ueContainerEUTRA.rxFlag)
                    {
                        if (GOOD != VRIL_StoreNRRRC_UE_MRDC_Capability_BufferBased_IfNeeded(ptCi))
                        {
                            VCCB_PRINT_CALL_ERROR(ptCi,
                                "VRIL_StoreNRRRC_UE_MRDC_Capability_BufferBased_IfNeeded Error in %s\n", __func__);

                            status = ERROR;
                            break;
                        }

                        if (ERROR == VLIB_Set_MrdcAllowedBCListMRDC(ptCi, cellNum, cellBand, pCurrAllowedBCList, FALSE, FALSE))
                        {
                            VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_Set_MrdcAllowedBCListMRDC Error in %s!\n", __func__);
                            status = ERROR;
                            break;
                        }
                    }
                    else
                    {
                        VCCB_PRINT_CALL_ERROR(ptCi,
                            "Can't recomposite allowedBCList for NEDC due to no Capa(mrdcCapa:%u, eutraCapa:%u)!!\n",
                            ptCi->ueContainerMRDC.rxFlag, ptCi->ueContainerEUTRA.rxFlag);
                        status = ERROR;
                        break;
                    }
                    break;

                case MRDC_NRDC:
                    if (ptCi->ueCapaEnquiry.needEnquiryBitFlag & UE_CAPA_REQ_RAT_TYPE_NR)  // in progress
                    {
                        VCCB_PRINT_CALL_ERROR(ptCi,
                            "Can't recomposite allowedBCList for NRDC bcz UECapabilityEnquiry is in progress!!\n");
                        status = ERROR;
                        break;
                    }
                    else if (ptCi->ueContainerNR.rxFlag)
                    {
                        NRRRC_UE_NR_Capability *ptMsg = NULL;
                        if (FnVCCB_Wrapper_UnpackNRRRC_UE_NR_Capability(ptCi, ptUnpackUeCapa) == ERROR)
                        {
                            VCCB_PRINT_CALL_ERROR(
                                ptCi, "FnVCCB_Wrapper_UnpackNRRRC_UE_NR_Capability Error! in %s!!\n", __func__);
                            status = ERROR;
                            break;
                        }

                        ptMsg =
                            (NRRRC_UE_NR_Capability *)(&ptUnpackUeCapa->unpack[0] + ptUnpackUeCapa->unpackMsgOffset);
                        if (ERROR == FnVCCB_MakeAllowedBCList(ptCi, cellNum, cellBand, ptMsg, FALSE))
                        {
                            VCCB_PRINT_CALL_COMMENT(ptCi, "FnVCCB_MakeAllowedBCList Error! in %s!!\n", __func__);
                            status = ERROR;
                            break;
                        }
                    }
                    else
                    {
                        VCCB_PRINT_CALL_ERROR(ptCi, "Can't recomposite allowedBCList for NRDC due to NO nrCapa!!\n");
                        status = ERROR;
                        break;
                    }
                    break;

                default:
                    // actually unreachable statement.
                    VCCB_PRINT_CALL_ERROR(
                        ptCi, "Invalid Selected Mrdc Type(%d) in %s\n", newSelectedMrdcType, __func__);
                    status = ERROR;
            }

            if (status == ERROR)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "Fail to recomposite AllowedBCList in %s\n", __func__);

                return;
            }
        }
        else if (pCell->cellIdentity != pCurrAllowedBCList->cellIdentity)
        {
            // update SelectedBandEntryMNBitMap in case of pCell change, even if there is no need to refresh AllowedBCList
            VLIB_UpdateSelectedBandEntryMNBitMap(ptCi, cellNum);
        }
    }

    if (ctrlFlag & MRDCCTRL_RECFG_MEASCFG)
    {
        if (ERROR == VCCM_EnqueueActionMeasReconfig(ptCi, MeasReconfigPriorAction_Full))
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "VCCM_EnqueueActionMeasReconfig in %s fail!\n", __func__);
        }
        else
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "VCCM_EnqueueActionMeasReconfig is done!\n");
        }
    }
}

int16_t FnVCCB_RunLoadBasedScgBandSelectionMRBased(callInfo_type *ptCi, frequencyAndBandIndiNR_type &freqAndBandIndi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    bool isFr2FirstMR = false;

    if (!IS_SUPPORTABLE_ScgBandSelectionForNrdc(ptCi->servCellNum))
    {
        ptCi->nrdcAddA4MrReceived.mR1st = freqAndBandIndi;
        return GOOD;
    }

    //SVR26A:FGR-LC0705:FR12
    if(IS_FAST_ACCESS_BAND_SELECTION_MODE(ptCi->servCellNum))
    {
        return GOOD;
    }

    if ((false == FnVCCB_IsAllowedNrBandforAllowedBCList(ptCi, (uint16_t)FR2_39GHz_n260)) ||
        (false == FnVCCB_IsAllowedNrBandforAllowedBCList(ptCi, (uint16_t)FR2_28GHz_n261)))
    {
        ptCi->nrdcAddA4MrReceived.mR1st = freqAndBandIndi;
        return GOOD;
    }

    if (ptCi->loadBasedNrdcScgBandSelectInfo.enqueuedSnAddTriggerFlag)
    {
        VCCB_PRINT_CALL_NRDC_BASIC(
            ptCi, "[SCG-BAND SELC] Ignored MR, bcz loadBasedNrdcScgBandSelectInfo.enqueuedSnAddTriggerFlag is set in %s!\n", __func__);

        return BREAK;
    }

    measResultList2NR_type *pMeasResultList2NR =
        &THREAD_INFO->call[ptCi->myThreadId].buf.measResultList2NRRx.candidateCellInfoListSN;

    measResult2NR_type *pMeasResult2NR = FnVCCB_GetMeasResult2NRforNeighbor(ptCi, pMeasResultList2NR);
    if (pMeasResult2NR == nullptr)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetMeasResult2NRforNeighbor ERROR in %s!!\n", __func__);
        return ERROR;
    }

    uint16_t freqBandIndi = VCCB_GetBandOfMatchingMeasObjectNR(ptCi->measurementsConfiguration, pMeasResult2NR->ssbFrequency);
    if(freqBandIndi == BAND_NOT_FOUND)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_GetBandOfMatchingMeasObjectNR(ssbFreq:%u) ERROR in %s!!!\n",
            pMeasResult2NR->ssbFrequency, __func__);
        return BREAK;
    }

    if (!IS_FR2BAND_28GHZ_39GHZ(freqBandIndi))
    {
        if (!IS_WAITING_FOR_FR2SCGBAND_MR_COLLECTION(ptCi))
        {
            ptCi->nrdcAddA4MrReceived.mR1st = freqAndBandIndi;
            return GOOD;
        }
        VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[SCG-BAND SELC] MR was ignored for freqBandIndi(n%u) in %s!!!\n", freqBandIndi, __func__);

        return BREAK;
    }
    else
    {
        VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[SCG-BAND SELC] MR is for FR2 band (%u)!\n", freqBandIndi);
    }

    if (IS_WAITING_FOR_FR2SCGBAND_MR_COLLECTION(ptCi))
    {
        ptCi->loadBasedNrdcScgBandSelectInfo.mrCollectedCnt++;

        if (freqBandIndi != ptCi->loadBasedNrdcScgBandSelectInfo.fr2Band)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[SCG-BAND SELC] MR Collection for FR2 band(n%u, n%u) is finished !!!\n",
                ptCi->loadBasedNrdcScgBandSelectInfo.fr2Band, freqBandIndi);

            ptCi->nrdcAddA4MrReceived.mR2nd = freqAndBandIndi;
            return FnVCCB_DecideNrdcLoadBasedSCGBand(ptCi, freqBandIndi);
        }
    }
    else
    {
        // The first MR is received.
        ptCi->loadBasedNrdcScgBandSelectInfo.usage = VCCB_FLAG_ON;
        ptCi->loadBasedNrdcScgBandSelectInfo.mrCollectedCnt = 1;
        ptCi->loadBasedNrdcScgBandSelectInfo.enqueuedSnAddTriggerFlag = 0;
        ptCi->loadBasedNrdcScgBandSelectInfo.fr2Band = freqBandIndi;

        VLIB_AttachTimer(&ptCi->loadBasedNrdcScgBandSelectInfo.newBandMrWaitTimer, ptCi, timInternalNewBandMrWait_id);
        isFr2FirstMR = true;
    }

    if (ERROR == FnVCCB_ReCompositeMeasResult2NRwithOnlyNeighCellListNR(ptCi))
    {
        ptCi->loadBasedNrdcScgBandSelectInfo.mrCollectedCnt--;

        VCCB_PRINT_CALL_ERROR(
            ptCi, "FnVCCB_ReCompositeMeasResult2NRwithOnlyNeighCellListNR ERROR in %s!!!\n", __func__);

        if (isFr2FirstMR)
        {
            return ERROR;
        }
    }

    ptCi->nrdcAddA4MrReceived.mR1st = freqAndBandIndi;

    return BREAK;
}

void FnVCCB_SelectScgBandSelOprModeInCapacityBoth(
    callInfo_type *ptCi, uint16_t cellNum, uint16_t newFreqBand, nrdcScgBandSelectionMgmt_type &scgBandSelMgmt)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    uint16_t fr2bandPrev = ptCi->loadBasedNrdcScgBandSelectInfo.fr2Band;
    bool prevIsUL = true, isUL = true;
    uint32_t minimalResourcePrev = MAX_SCG_BAND_SEL_AVAIL_RESOURCE, minimalResource = MAX_SCG_BAND_SEL_AVAIL_RESOURCE;

    VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[SCG-BAND SELC]  Check Operation mode (SCG_BAND_SEL_CapacityOptionBoth)\n");

    // If the second MR is timed out, is2ndMrReceived is set false and Select the pci with the optimal resource within
    // the band with only one received MR.
    bool is2ndMrReceived = (newFreqBand != fr2bandPrev);

    if (is2ndMrReceived)
    {
        // The candidateCellInfoListMN is just used for unpack buffer temporarily.
        measResultList2NR_type *pMeasResultList2NR_prev =
            &THREAD_INFO->call[ptCi->myThreadId].buf.measResultList2NRRx.candidateCellInfoListMN;
        if (ERROR == FnVCCB_RestoreMeasResultList2NRforSelectedFr2Band(ptCi, pMeasResultList2NR_prev))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_RestoreMeasResultList2NRforSelectedFr2Band ERROR in %s!!!\n", __func__);
            return;
        }

        if (GOOD !=
            FnVCCB_GetFr2BandMinimalResource(ptCi, pMeasResultList2NR_prev, fr2bandPrev, prevIsUL, minimalResourcePrev))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "FnVCCB_GetFr2BandMinimalResource for fr2bandPrev(%u), ERROR in %s!!!\n", fr2bandPrev, __func__);
        }
    }

    measResultList2NR_type *pMeasResultList2NR =
        &THREAD_INFO->call[ptCi->myThreadId].buf.measResultList2NRRx.candidateCellInfoListSN;
    if (GOOD != FnVCCB_GetFr2BandMinimalResource(ptCi, pMeasResultList2NR, newFreqBand, isUL, minimalResource))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "FnVCCB_GetFr2BandMinimalResource for newFreqBand(%u), ERROR in %s!!!\n", newFreqBand, __func__);
    }

    // If resources are same, then vccb select newFreqBand. It's because latest mr is more trustworthy
    bool isNewFreqBandRscSmaller = minimalResource <= minimalResourcePrev;
    if (isNewFreqBandRscSmaller)
    {
        scgBandSelMgmt.oprMode = isUL ? SCG_BAND_SEL_OPR_UlCapaBased : SCG_BAND_SEL_OPR_DlCapaBased;
    }
    else
    {
        scgBandSelMgmt.oprMode = prevIsUL ? SCG_BAND_SEL_OPR_UlCapaBased : SCG_BAND_SEL_OPR_DlCapaBased;
    }

    VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[SCG-BAND SELC]  >>> Select %s because n%d's minimal Rsc is smaller!!!\n",
        (scgBandSelMgmt.oprMode == SCG_BAND_SEL_OPR_UlCapaBased) ? "UL Capa based" : "DL Capa based",
        isNewFreqBandRscSmaller ? newFreqBand : fr2bandPrev);
}

int16_t FnVCCB_DecideNrdcLoadBasedSCGBand(callInfo_type *ptCi, uint16_t newFreqBand)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    VCCB_PRINT_CALL_NRDC_BASIC(
        ptCi, "[SCG-BAND SELC] ==========================   START SCG BAND SELECTION   ==========================\n");

    // TODO: uint32_t availableResourceCapa_n260 = 0, availableResourceCapa_n261 = 0;

    VCCB_CLEAR_TIMER(&ptCi->loadBasedNrdcScgBandSelectInfo.newBandMrWaitTimer, CANCEL_TIMER);

    VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[SCG-BAND SELC] **** 1. Set selection mode ****\n");
    if (GOOD != FnVCCB_UpdateNrdcScgBandSelectionMgmtPerCell(ptCi, ptCi->servCellNum, newFreqBand))
    {
        // need to continue legacy nr-dc addition procedure rather than stop
        return GOOD;
    }

    // The candidateCellInfoListMN is just used for unpack buffer temporarily.
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    measResultList2NR_type *pMeasResultList2NR_prev =
        &THREAD_INFO->call[ptCi->myThreadId].buf.measResultList2NRRx.candidateCellInfoListMN;
    measResultList2NR_type *pMeasResultList2NR_new =
        &THREAD_INFO->call[ptCi->myThreadId].buf.measResultList2NRRx.candidateCellInfoListSN;

    // TODO: bool sortedPrev = true, sortedNew = true;

    VccbCellInfo_type const *pCell = FnVCCB_GetCellInfo(ptCi->servCellNum);
    VALID_E_POINT_CHECK_ERROR(pCell);

    scgBandSelectionConfigYang_type const &scgBandSelYang = pCell->scgBandSelectionConfig;

    nrdcScgBandSelectionMgmt_type &scgBandSelMgmt =
        THREAD_INFO->call[ptCi->myThreadId].nrdcScgBandSelMgmtPerCell[ptCi->servCellNum];

    // no need to decompress for packed MrInfo if it has been decompressed during previous step.
    if (SCG_BAND_SEL_OPR_RrcUeBased == scgBandSelMgmt.oprMode ||
        SCG_BAND_SEL_CapacityOptionBoth != scgBandSelYang.scgBandCapacityOption)
    {
        if (ERROR == FnVCCB_RestoreMeasResultList2NRforSelectedFr2Band(ptCi, pMeasResultList2NR_prev))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_RestoreMeasResultList2NRforSelectedFr2Band ERROR in %s!!!\n", __func__);
            //  need to continue legacy nr-dc addition procedure rather than stop
            return GOOD;
        }
    }

    uint16_t fr2bandPrev = ptCi->loadBasedNrdcScgBandSelectInfo.fr2Band;
    availResourcePerMeasResultCellReport_type availRscTuplePrev[MAX_NUM_CELL_REPORT];
    memset(availRscTuplePrev, 0, sizeof(availRscTuplePrev));

    VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[SCG-BAND SELC] **** 2. Get Band's Available Resources ****\n");
    if (FnVCCB_GetFr2BandAvailableResource(ptCi, pMeasResultList2NR_prev, fr2bandPrev, availRscTuplePrev) == ERROR)
    {
        // TODO: sortedPrev = false;
        VCCB_PRINT_CALL_ERROR(
            ptCi, "FnVCCB_RestoreMeasResultList2NRforSelectedFr2Band for fr2bandPrev, ERROR in %s!!!\n", __func__);
    }

    availResourcePerMeasResultCellReport_type availRscTupleNew[MAX_NUM_CELL_REPORT];
    memset(availRscTupleNew, 0, sizeof(availRscTupleNew));

    if (FnVCCB_GetFr2BandAvailableResource(ptCi, pMeasResultList2NR_new, newFreqBand, availRscTupleNew) == ERROR)
    {
        // TODO: sortedNew = false;
        VCCB_PRINT_CALL_ERROR(
            ptCi, "FnVCCB_RestoreMeasResultList2NRforSelectedFr2Band for newFreqBand, ERROR in %s!!!\n", __func__);
    }

    VCCB_PRINT_CALL_ERROR(ptCi, "[SCG-BAND SELC] **** 3. Select measResult ****\n");

    VCCB_PRINT_CALL_ERROR(ptCi, "[SCG-BAND SELC]  n%u's bestAvailRsc:%u, n%u's bestAvailRsc:%u\n", fr2bandPrev,
        availRscTuplePrev[0].availableResource, newFreqBand, availRscTupleNew[0].availableResource);
    uint16_t selectedBand = newFreqBand;
    // Since availRscTuple is already sorted in FnVCCB_GetFr2BandAvailableResource, the index 0 is used.
    if (availRscTuplePrev[0].availableResource > availRscTupleNew[0].availableResource)
    {
        selectedBand = fr2bandPrev;
    }

    VCCB_PRINT_CALL_ERROR(ptCi, "[SCG-BAND SELC]   >>> n%u is selected!!!\n", selectedBand);
    VCCB_PRINT_CALL_NRDC_BASIC(
        ptCi, "[SCG-BAND SELC] ==========================   FINISH SCG BAND SELECTION   =======================\n");

    // 2nd MR
    if (selectedBand == newFreqBand)
    {
        ptCi->loadBasedNrdcScgBandSelectInfo.fr2Band = newFreqBand;

        if (availRscTupleNew[0].ssbArfcn)
        {
            MACRO_STAT_PMCC(STAT_NRDC_SCG_BAND_SELECTION, NumOfSelectionByLB, ptCi,
                (uint64_t)availRscTupleNew[0].ssbArfcn, availRscTupleNew[0].nci, 0, 0, 0);
        }

        if (availRscTuplePrev[0].ssbArfcn)
        {
            MACRO_STAT_PMCC(STAT_NRDC_SCG_BAND_SELECTION, NumOfDiscardedDueToLB, ptCi,
                (uint64_t)availRscTuplePrev[0].ssbArfcn, availRscTuplePrev[0].nci, 0, 0, 0);
        }

        if (ptCi->state == STATE_Conn)
        {
            return GOOD;
        }

        if (ERROR == FnVCCB_ReCompositeMeasResult2NRwithOnlyNeighCellListNR(ptCi))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "#2nd MR, FnVCCB_ReCompositeMeasResult2NRwithOnlyNeighCellListNR ERROR in %s!!!\n", __func__);

            return ERROR;
        }
        else
        {
            VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "enqueueAction w/ ENQUEUE_ACTION_SNADD_AFTER_MR_COLLECTION !!\n");
            if (ERROR == VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_SNADD_AFTER_MR_COLLECTION))
            {
                VCCB_PRINT_CALL_INFORMATIVE(
                    ptCi, "VCCM_enqueueAction(ENQUEUE_ACTION_SNADD_AFTER_MR_COLLECTION) ERROR!\n");

                return ERROR;
            }
            ptCi->loadBasedNrdcScgBandSelectInfo.enqueuedSnAddTriggerFlag = VCCB_FLAG_ON;
        }
    }
    // 1st MR
    else
    {
        if (availRscTuplePrev[0].ssbArfcn)
        {
            MACRO_STAT_PMCC(STAT_NRDC_SCG_BAND_SELECTION, NumOfSelectionByLB, ptCi,
                (uint64_t)availRscTuplePrev[0].ssbArfcn, availRscTuplePrev[0].nci, 0, 0, 0);
        }

        if (availRscTupleNew[0].ssbArfcn)
        {
            MACRO_STAT_PMCC(STAT_NRDC_SCG_BAND_SELECTION, NumOfDiscardedDueToLB, ptCi,
                (uint64_t)availRscTupleNew[0].ssbArfcn, availRscTupleNew[0].nci, 0, 0, 0);
        }

        if (ERROR == FnVCCB_RestoreMeasResultList2NRforSelectedFr2Band(ptCi, pMeasResultList2NR_new))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_RestoreMeasResultList2NRforSelectedFr2Band ERROR in %s!!!\n", __func__);

            return ERROR;
        }

        measResult2NR_type *pSrcMeasResult2NR = FnVCCB_GetMeasResult2NRforNeighbor(ptCi, pMeasResultList2NR_prev);
        if (pSrcMeasResult2NR == nullptr)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetMeasResult2NRforNeighbor for prev ERROR in %s!!\n", __func__);
            return ERROR;
        }

        measResult2NR_type *pDstMeasResult2NR = FnVCCB_GetMeasResult2NRforNeighbor(ptCi, pMeasResultList2NR_new);
        if (pDstMeasResult2NR == nullptr)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetMeasResult2NRforNeighbor for new ERROR in %s!!\n", __func__);
            return ERROR;
        }

        memcpy(pDstMeasResult2NR, pSrcMeasResult2NR, sizeof(measResult2NR_type));
        if (ptCi->state == STATE_Conn)
        {
            return GOOD;
        }
        else
        {
            if (ERROR == FnVCCB_ReCompositeMeasResult2NRwithOnlyNeighCellListNR(ptCi))
            {
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "#1st MR, FnVCCB_ReCompositeMeasResult2NRwithOnlyNeighCellListNR ERROR in %s!!!\n", __func__);

                return ERROR;
            }

            VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "enqueueAction w/ ENQUEUE_ACTION_SNADD_AFTER_MR_COLLECTION !!\n");
            if (ERROR == VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_SNADD_AFTER_MR_COLLECTION))
            {
                VCCB_PRINT_CALL_INFORMATIVE(
                    ptCi, "VCCM_enqueueAction(ENQUEUE_ACTION_SNADD_AFTER_MR_COLLECTION) ERROR!\n");

                return ERROR;
            }
            ptCi->loadBasedNrdcScgBandSelectInfo.enqueuedSnAddTriggerFlag = VCCB_FLAG_ON;
        }
    }

    return BREAK;
}

bool FnVCCB_IsAnySCGLegToBeReleased(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    uint8_t drbIdx = 0;
    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        callDRBInfo_type *ptDi = &ptCi->drb[drbIdx];

        if (ptDi->usage != CI_use) continue;
        if (ptDi->selectedBearerTypeFrozenFlag != TRUE) continue;

        if (GET_SNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(ptDi->mrdcFlag.respFlag))  // scgLeg of SNTerm
        {
            return true;
        }

        if (GET_MNTERM_DRB_TO_BE_RELEASED_TO_SN_FLAG(ptDi->mrdcFlag.respFlag))  // mcgLeg of MNTermSplit
        {
            return true;
        }

        if (ptDi->pduIdxInCall < MAX_PDU_SESS_PER_CALL)
        {
            callPDUSessInfo_type *pPi = &ptCi->pduSess[ptDi->pduIdxInCall];
            if (pPi->usage != CI_use) continue;

            if (GET_PDUSESS_TO_BE_RELEASED_TO_SN_FLAG(pPi->mrdcFlag.respFlag))
            {
                return true;
            }
        }
    }

    return false;
}

int16_t FnVCCB_IsDrbBasedFallbackRequired(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (!FnVCCB_IsAnySCGLegToBeReleased(ptCi))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Not FnVCCB_IsAnySCGLegToBeReleased in %s !\n", __func__);

        return BREAK;
    }

    if (ptCi->cause.xnCause != CauseXnapRadioNetworkLayerActionDesirableForRadioReasons)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not CauseXnapRadioNetworkLayerActionDesirableForRadioReasons in %s !\n", __func__);

        return ERROR;
    }

    return GOOD;
}

int16_t FnVCCB_GetNrdcOprModeByRfsp(callInfo_type *ptCi, uint8_t *operMode, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    uint32_t idx = 0;
    uint8_t servPlmnIndex = MAX_PLMN_INDEX;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);

    if ((ptCi->ueInfo.rfsp.rfspPresent == OPT_PRESENT) && (ptCi->ueInfo.rfsp.indexToRFSP > NO_RFSP_VALUE) &&  // 0
        (ptCi->ueInfo.rfsp.indexToRFSP <= MAX_RFSP_VALUE))                                                    // 256
    {
        servPlmnIndex = VLIB_FindGnbPlmnIndexOfCall(ptCi);
        if (servPlmnIndex < MAX_PLMN_INDEX)
        {
            const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

            for (idx = 0; idx < MAX_NRDC_RFSP_BASED_OPRMODE_YANG_ENTRIES; idx++)
            {
                if (pCell->nrdcCellInfo.nrdcRfspBasedOprMode[idx].usage != CI_use) continue;
                if (pCell->nrdcCellInfo.nrdcRfspBasedOprMode[idx].plmnIndex != servPlmnIndex) continue;
                if (pCell->nrdcCellInfo.nrdcRfspBasedOprMode[idx].rfsp != ptCi->ueInfo.rfsp.indexToRFSP) continue;
                *operMode = pCell->nrdcCellInfo.nrdcRfspBasedOprMode[idx].nrdcOprModeRfsp;
                return GOOD;
            }
        }
    }
    return ERROR;
}

uint8_t FnVCCB_GetNrdcMode(callInfo_type &rCall, uint16_t cellNum)
{
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(cellNum, 0xff);
    uint8_t operMode = 0xff;
    if (FnVCCB_GetNrdcOprModeByRfsp(&rCall, &operMode, cellNum) == GOOD)
    {
        return operMode;
    }
    return NRDC_OPR_MODE(cellNum);
}

bool FnVCCB_CheckNrdcMode(callInfo_type &rCall, uint16_t cellNum, uint8_t checkOperMode)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(cellNum, false);

    return (FnVCCB_GetNrdcMode(rCall, cellNum) == checkOperMode);
}

int16_t FnVCCB_TriggerDrbBasedFallbackAtMN(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    int16_t status = GOOD;

    if (!IS_NRDC_MN(ptCi))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Not IS_NRDC_MN !\n");
        goto RESULT_FAILURE_PROC;
    }

    if (!IS_MRDC_ACTIVE(ptCi))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Not IS_MRDC_ACTIVE !\n");
        goto RESULT_FAILURE_PROC;
    }

    SET_MRDC_PROCEDURE(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_BearerTypeChange, MRDC_PROC_INITIATOR_SN);

    FnVCCB_SetReqBearerTypeforFallback(ptCi, false);
    FnVCCB_ReproduceUeAMBRforMRDC(ptCi);
    FnVCCB_ReproduceUeSliceMBRforMRDC(*ptCi);
    if (FnVCCB_ValidateGFBRComparedToUeSliceMBR(*ptCi) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Sum of GFBR values exceed UE-Slice-MBR! ERROR!\n");
        
        ptCi->cause.ngCause = CauseNgapRadioNetworkLayerRadioResourcesNotAvailable;
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerNoRadioResourcesAvailable;

        if (ERROR == FnVCCB_SendXNMessage(XN_SNodeModificationRefuse_id, ptCi, nullptr, nullptr))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendXNMessage(XN_SNodeModificationRefuse) ERROR in %s!\n", __func__);
        }

        status = VCCB_CALL_RELEASE_TRIGGER(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_CALL_RELEASE_TRIGGER Error!\n");

        return GOOD;
    }

    FnVCCB_InitPdcpSNStatusInfo(ptCi);

    if (FnVCCB_IsAnySpecificBearerAndReqBearer(ptCi, MN_Term_SPLIT_Bearer, MN_Term_MCG_Bearer))
    {
        FnVCCB_SetPDUSessAndDrbStatusForE1BearerFallback(ptCi);

        if (GET_E1_RESOURCE_FLAG(ptCi->flag.setupFlag))
        {
            status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");
            VLIB_SetCurStateAll(ptCi, STATE_SNModFbkPrepare_E1Mod1);
            VLIB_AttachTimer(&ptCi->callMultiTimer.e1, ptCi, timE1_BearerContextModification_id);
        }
        else
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Not GET_E1_RESOURCE_FLAG(ptCi->flag.setupFlag) in %s!\n", __func__);

            return ERROR;
        }
    }
    else
    {
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerActionDesirableForRadioReasons;
        if (ERROR == FnVCCB_SendXNMessage(XN_SNodeModificationRequest_id, ptCi, nullptr, nullptr))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "FnVCCB_SendXNMessage (XN_SNodeModificationRequest_id) ERROR in %s!\n", __func__);

            return ERROR;
        }
        VLIB_AttachTimer(&ptCi->callMultiTimer.xn, ptCi, timXN_DcPrepare_id);
        VLIB_SetCurStateAll(ptCi, STATE_SNModFbkPrepare_XnMod);
    }

    return GOOD;

RESULT_FAILURE_PROC:
    ptCi->cause.xnCause = CauseXnapProtocolMessageNotCompatibleWithReceiverState;
    if (ERROR == FnVCCB_SendXNMessage(XN_SNodeModificationRefuse_id, ptCi, nullptr, nullptr))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendXNMessage(XN_SNodeModificationRefuse) ERROR in %s!\n", __func__);
    }
    SET_STATE_CMD(Idle_cmd);

    return GOOD;
}

bool FnVCCB_NeedNGuTnlTobeModifedPerPDUSess(callInfo_type *ptCi, callPDUSessInfo_type *pPi, uint8_t nguTnlType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pPi, false);

    if (pPi->usage != CI_use) return false;

    transportLayerInfo_type *pNguTnlInfo;
    switch (nguTnlType)
    {
        case NGU_TNL_TYPE_MNDL:
            pNguTnlInfo = &pPi->nGuDlInfo;
            break;
        case NGU_TNL_TYPE_MNUL:
            pNguTnlInfo = &pPi->nGuUlInfo;
            break;
        case NGU_TNL_TYPE_SNDL:
            pNguTnlInfo = &pPi->snNGuDlInfo;
            break;
        case NGU_TNL_TYPE_SNUL:
            pNguTnlInfo = &pPi->snNGuUlInfo;
            break;
        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid nguTnlType(%u) in %s!\n", nguTnlType, __func__);
            return false;
    }

    return pNguTnlInfo->fNeedModify ==
           VCCB_FLAG_ON;  // if fNeedModify is more than 1, then it will be regarded as garbage value (false).
}

bool FnVCCB_NeedNGuTnlTobeModified(callInfo_type *ptCi, uint8_t nguTnlType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    uint8_t pdusessIdx = 0;
    for (pdusessIdx = 0; pdusessIdx < MAX_PDU_SESS_PER_CALL; pdusessIdx++)
    {
        callPDUSessInfo_type *pPi = &ptCi->pduSess[pdusessIdx];
        if (pPi->usage != CI_use) continue;

        if (true == FnVCCB_NeedNGuTnlTobeModifedPerPDUSess(ptCi, pPi, nguTnlType))
        {
            return true;
        }
    }

    return false;
}

bool FnVCCB_NeedDataFwdTnlTobeSentToSN(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    uint8_t drbIdx = 0;

    if (!IS_NRDC_MN(ptCi))
    {
        return false;
    }

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        callDRBInfo_type *pDi = &ptCi->drb[drbIdx];
        if (pDi->usage != CI_use) continue;
        if (!pDi->selectedBearerTypeFrozenFlag) continue;
        if (pDi->bearerType.termPoint != TermPoint_Sn || pDi->reqBearerType.val != MN_Term_MCG_Bearer)
        {
            continue;
        }

        // if (pDi->dataFwdInfo.gtpTunnel.dl.fNeedModify == VCCB_FLAG_ON ||
        //         pDi->dataFwdInfo.gtpTunnel.ul.fNeedModify == VCCB_FLAG_ON)
        {
            return true;
        }
    }

    return false;
}

int16_t FnVCCB_UpdateSnNGuTnl(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_PRINT_CALL_COMMENT(ptCi, "snNGuTnl_Update triggered\n");

    if (FnVCCB_SendXNMessage(XN_SNodeModificationRequest_id, ptCi, nullptr, nullptr) == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendXNMessage(XN_SNodeModificationRequest_id) Error!\n");
        return ERROR;
    }
    VLIB_AttachTimer(&ptCi->callMultiTimer.xn, ptCi, timXN_DcPrepare_id);
    VLIB_SetCurStateAll(ptCi, STATE_NGU_ULTNL_XnMod);

    return GOOD;
}

/****************************************************************************
 * @brief           This function returns the Mrdc Addition procedure status of the SN side
 *                  according to the UE type in the MRDC-SN (ENDC/NRDC).
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @return          'SgNBAddition_cmd' or 'MrdcXnSNAdd_cmd' / uint8_t
 ****************************************************************************/
uint8_t FnVCCB_GetMrdcAdditionCmd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, SgNBAddition_cmd);

    // ENDC-SN
    if (IS_ENDC_SN(ptCi))
    {
        return SgNBAddition_cmd;
    }

    // NRDC_SN

    return MrdcXnSNAdd_cmd;
}

void FnVCCB_Mark_SnNGuDlInfoIfNeedToModifyToSMF(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    uint8_t drbIdx = 0;

    if (ptCi->state != STATE_SNModExec)
    {
        return;
    }

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        callDRBInfo_type *pDi = &ptCi->drb[drbIdx];

        if (pDi->usage != CI_use) continue;
        if (!pDi->selectedBearerTypeFrozenFlag) continue;
        if (!(pDi->bearerType.val == MN_Term_MCG_Bearer && pDi->reqBearerType.termPoint == TermPoint_Sn))
        {
            continue;
        }
        if (pDi->pduIdxInCall >= MAX_PDU_SESS_PER_CALL) continue;

        callPDUSessInfo_type *pPi = &ptCi->pduSess[pDi->pduIdxInCall];
        if (pPi->usage != CI_use) continue;

        pPi->snNGuDlInfo.fNeedModify = VCCB_FLAG_ON;
    }
}


// While BearerType is changed, MCG-RBConfig should be included if bearer is transmitted from MN-Term to SN-Term.
bool FnVCCB_NeedMCGRbCfgTobeIncludedDuringBTC(callInfo_type *ptCi, callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    if (!IS_NRDC_MN(ptCi))
    {
        return false;
    }

    if (ptDi->bearerType.val != MN_Term_MCG_Bearer || ptDi->reqBearerType.termPoint != TermPoint_Sn)
    {
        return false;
    }

    if (ptCi->stateCmd != MrdcXnSNAdd_cmd &&
        !(ptCi->stateCmd == MrdcXnSNMod_cmd &&
            FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_BearerTypeChange) == true))
    {
        return false;
    }

    return true;
}

// MN will call this api during SNRelease or DRBFallback by preemption
void FnVCCB_InitPdcpSNStatusInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    int32_t drbIdx;
    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        callDRBInfo_type *pDi = &ptCi->drb[drbIdx];
        if (pDi->usage != CI_use) continue;

        pDi->dataFwdInfo.snStatus.needSendFlag = 0;
        pDi->dataFwdInfo.snStatus.ulSN = 0;
        pDi->dataFwdInfo.snStatus.dlSN = 0;
        pDi->dataFwdInfo.snStatus.ulHFN = 0;
        pDi->dataFwdInfo.snStatus.dlHFN = 0;
    }
}

// This function is used to perform basic initialization operations for NRDC-SN UEs.
void FnVCCB_InitTempCallInfoForNrdcSn(callInfo_type *ptTmpCi, uint8_t threadId, uint16_t gnbNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptTmpCi);

    VLIB_InitCallInfo(ptTmpCi, threadId, gnbNum, E_CALLTYPE_SA);

    // selectedMrdcType
    ptTmpCi->selectedMrdcType = MRDC_NRDC;

    // mrdcInfo
    if (GOOD != VLIB_AllocMrdcInfo(ptTmpCi, UECTX_NRDC_SN))
    {
        VCCB_PRINT_CALL_ERROR(ptTmpCi, "Fail, VLIB_AllocMrdcInfo for UECTX_NRDC_SN!!\n");
    }
}

bool FnVCCB_IsValidNrdcSnPerGnb_ForMN(callInfo_type *ptCi, const vccbGlobalGnbId_type targetGnbId, XnIdx_type xnIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);

    // 1) SVR23A FGR-CC5203 SCG Failure Handling for NR-DC :: FR130 :: Blocklisted S-Node
    // 2) SVR23B FGR-CC5200 Basic Operation For NR-DC :: FR143 :: Restricted gNB by overload
    // 3) SVR23B FGR-CC5200 Basic operation for NR-DC :: FR840 :: gNB shall block NR-DC with other vendor's gNB
    if (FnVCCB_IsGnbRestrictedforNrdcSn(ptCi, targetGnbId))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "[%s] XnNbrGnb(XnIdx:%u) is restricted (gnbNum: %u)!\n", __func__, xnIdx, ptCi->gnbNum);
        return false;
    }

    const bool isInterGnbNrdc = (xnIdx != XNIDX_FOR_INTRA_GNB_NRDC);
    if (isInterGnbNrdc == true)
    {
        if (FnVCCB_Check_isSegmentedUciCall(ptCi))
        {
            if (GOOD != FnVCCB_IsTargetRrcUlSegSupportable(ptCi, targetGnbId))
            {
                VCCB_PRINT_CALL_DATA(ptCi, "[%X,%u] Skip, Not Support RrcUlSeg in Snode!\n", targetGnbId.plmn.longId,
                    targetGnbId.gnbId.id);
                return false;
            }
        }

        if (FnVCCB_IsPeerGnbOtherVendor(ptCi, ptCi->gnbNum, TRUE, xnIdx, NULL))
        {
            // FGR-CC5200 Basic operation for NR-DC :: FR840
            // gNB shall block NR-DC with other vendor's gNB:
            // - MgNB shall not select other vendor's gNB as SgNB
            // ---------------------------------------------------------------------------
            // FGR-CC5201 Mobility for NR-DC :: FR105
            // In M-Node mobility procedure,
            // M-Node shall not select other vendor gNB's PSCell as a target PSCell
            if (OTHER_VENDOR_IS_ALLOWED_FOR_NRDC(ptCi))
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "OTHER_VENDOR_IS_ALLOWED_FOR_NRDC !\n");
            }
            else
            {
                VCCB_PRINT_CALL_DATA(
                    ptCi, "[%X,%u] Skip, Other Vendor SNode!\n", targetGnbId.plmn.longId, targetGnbId.gnbId.id);
                return false;
            }
        }
    }

    return true;
}

bool FnVCCB_IsValidNrdcSnPerCell_ForMN(
    callInfo_type *ptCi,
    uint16_t cellNum,
    nbrGnbCellInfo_type *pNbr,
    hoRestrictInfo_type *ptHrl,
    candidateNbrInformation_type *ptCandidateCell,
    const enumPSCellEligibilityCheckPerNbr_type filter)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pNbr, false);
    VALID_E_POINT_CHECK_RET_VAL(ptHrl, false);
    VALID_E_POINT_CHECK_RET_VAL(ptCandidateCell, false);

    VCCB_CHECK_E_RANGE_AND_FALSE(ptCandidateCell->nbrIdx, MAX_NBR_PER_CELL);

    //SVR25A FGR-CC5200 FR143
    if (VCCB_IS_INTRA_GNB_NEIGHBOR( cellNum, ptCandidateCell->nbrIdx))
    {
        VccbCellInfo_type const *pCell = FnVCCB_GetCellInfo(ptCandidateCell->cellNum);
        VALID_E_POINT_CHECK_RET_VAL(pCell, false);

        // DU overload check
        VCCB_CHECK_E_RANGE_AND_FALSE(pCell->gnbNum, MAX_GNB_PER_SYS);
        if (FnVCCB_IsDuOverload(&GNBINFO[pCell->gnbNum], pCell->endPointF1Index))
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi, "[NRDC] Skip, candidate DU(epF1Idx:%u, cellNum:%u) is overloaded!\n",
                pCell->endPointF1Index, ptCandidateCell->cellNum);
            return false;
        }

        // SSB cell check
        if (FnVCCB_IsNonSsbCell(pCell))
        {
            VCCB_PRINT_CALL_TGT_SEL(
                ptCi, "[NRDC] Skip, CellNum(%u) is non-SSB Cell\n", ptCandidateCell->cellNum);
            return false;
        }

        // Available cell check
        const bool isCellAvailable = (pCell->serviceState == CELL_INS && pCell->switchingOffOngoing == FALSE);
        if ( !isCellAvailable )
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi, "[NRDC] Skip, CellNum(%u) is not available(%u, %u)\n",
                ptCandidateCell->cellNum, pCell->serviceState, pCell->switchingOffOngoing);
            return false;
        }
    }
    else
    {
        if (FnVCCB_IsInterGnbNbrDeactivated(*pNbr))
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi, "[NRDC] Skip, NbrCell(nbrIdx:%u) is deactivated.\n", ptCandidateCell->nbrIdx);
            return false;
        }
    }

    if (FnVCCB_isNRDC_allowedCell(ptCi, pNbr) == false)
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi, "Skip, configuredTacIndication is not CI_use!\n");
        return false;
    }

    if (FnVCCB_IsNbrSDLCell(ptCi, pNbr))
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi,
            "Skip, gnbNbrCell(ssbArfcn:%u, gnbId:%u, cellId:%u, pci:%u arfcnDl/UL:%u/%u) SDL Cell!\n",
            pNbr->ssbArfcn, pNbr->globalGnbId.gnbId.id, pNbr->cellId, pNbr->nrPci, pNbr->nrArfcnDl, pNbr->nrArfcnUl);
        return false;
    }

    // FGR-CC5201 FR100: 4) Supported NR-DC Combination
    if (FnVCCB_MRDC_checkSupportedBandFromNeighbour(ptCi, cellNum, pNbr, filter) != GOOD)
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi, "Skip, Not Allowed Band Combination!\n");
        return false;
    }

    if (FnVCCB_NRDC_checkTAI(ptCi, cellNum, ptHrl, ptCandidateCell, PROC_MN_SELECT_PSCELL, pNbr) != GOOD)
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi, "Skip, TAI : PLMN & Slice Aware!\n");
        return false;
    }

    // FGR-CC5200:FR482 Check CAC rejected frequency
    if (FnVCCB_IsNrdcAddCacRejectedFreq(ptCi, pNbr->ssbArfcn))
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi,
            "[CAC] nrdcAddCacRejected freq(cellNum:%u, cellId:%u, pci:%u, ssbFreq:%u)!\n", cellNum, pNbr->cellId,
            pNbr->nrPci, pNbr->ssbArfcn);
        return false;
    }

    // FGR-CC5200:FR483, FGR-CC5201:FR109
    if (FnVCCB_IsCacBackOffTimeEffective(
            ptCi, pNbr))  // 25A: check CAC back off timer for initial addition and mobility cases
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi,
            "[NRDC][CAC Backoff] this cell is CAC BackOff state (cellNum:%u, cellId:%u, pci:%u, ssbFreq:%u)\n", cellNum,
            pNbr->cellId, pNbr->nrPci, pNbr->ssbArfcn);
        return false;
    }

    return true;
}

bool FnVCCB_IsValidNrdcSnPerCell_ForSN(
    callInfo_type *ptCi,
    uint16_t cellNum,
    uint16_t nbrIdx,
    nbrGnbCellInfo_type *pNbr,
    hoRestrictInfo_type *ptHrl,
    candidateNbrInformation_type *ptCandidateCell,
    measurementObjectNRUe_type *pMeasObj)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pNbr, false);
    VALID_E_POINT_CHECK_RET_VAL(ptHrl, false);
    VALID_E_POINT_CHECK_RET_VAL(ptCandidateCell, false);
    VALID_E_POINT_CHECK_RET_VAL(pMeasObj, false);

    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);
    VCCB_CHECK_E_RANGE_AND_VAL(nbrIdx, MAX_NBR_PER_CELL, false);

    const smtc1_type requiredSmtc1 = pMeasObj->minimal.smtc1;
    const uint16_t requiredBand = pMeasObj->minimal.freqBandIndicatorNR;
    const enumPSCellEligibilityCheckPerNbr_type filter = CHECK_ALL;

    const bool isIntraGnb = (VCCB_IS_INTRA_GNB_NEIGHBOR(cellNum, nbrIdx) == TRUE);

    uint16_t targetCellNum = MAX_CELL_NUM_VCCB;

    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];

    /*
        FGR-CC5201 FR113 :: SN Init Mobility

        [S-Node]
        When source S-Node choose a target PScell in SN mobility procedure,
        The S-Node shall select a target Pscell which fulfills following condition

        - (23B) DU which candidate PSCell belongs to is not in overloaded state
            * Note: This feature requirement is applicable if a feature FGR-LC0302 gNB Overload Control is available
        - Candidate PSCell is allowed for NR-DC PSCell
            * Refer [FGR-SF0001 NSA/SA Operation Scenario] for details
        - Candidate PSCell is not non-SSB cell
            * Non-SSB cell is defined by SSB-ToMeasure with all zero value
        - [23A] Candidate PSCell is not SDL cell
            * Refer [FGR-CC3301 Call control for NR cell operation] for definition of SDL cell
        - At least one NR-DC band combination is supported with candidate PSCell
        - If Mobility Restriction List (MRL) exists, candidate PSCell supports at least one PLMN of serving PLMN and/or
       Equivalent PLMNs in MRL which are not restricted by any of:
            * RAT Restrictions (PLMN with NR is forbidden),
            * [21D] Forbidden Area Information (PLMN with TAC is Forbidden)
            * Service Area Information (PLMN with TAC is Not Allowed),
            * Core Network Type Restriction for Equivalent PLMNs (PLMN with 5GC is forbidden)
        - (22C) If MRL does not exists, candidate PSCell supports selected PLMN of UE
        - (25A) When source S-Node choose a target PScell in SN mobility procedure, The S-Node shall not select a target Pscell which fulfills following condition
            - (25A) Candidate PSCell is in deactivated state (inter-gNB)
            - (25A) Candidate PSCell is in out-of-service state (intra-gNB)
    */

    if (isIntraGnb == true)
    {
        VCCB_GET_INTRA_GNB_NBR_CELLNUM(cellNum, nbrIdx, targetCellNum);

        if (targetCellNum >= MAX_CELL_NUM_VCCB)
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi,
                "Skip, cell(Id:%u/num:%u)) is Unknown Cell! (cell:%u, nbrIdx:%u)\n", pNbr->cellId, targetCellNum,
                cellNum, nbrIdx);
            return false;
        }

        VccbCellInfo_type *const pTgtCellInfo = &CELLINFO[targetCellNum];

        if (GOOD != VCCM_CheckIntraGnbCellServiceState(ptCi, cellNum, nbrIdx))
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi,
                "Skip, cell(Id:%u/num:%u)) is Out Of Service! (cell:%u, nbrIdx:%u)\n", pNbr->cellId,
                targetCellNum, cellNum, nbrIdx);
            return false;
        }

        // FGR-CC5201 FR114 :: SN Init Mobility
        // - (23B) DU which candidate PSCell belongs to is not in overloaded state
        //     * Note: This feature requirement is applicable if a feature FGR-LC0302 gNB Overload Control is available
        if (FnVCCB_IsDuOverload(pGnb, pTgtCellInfo->endPointF1Index) == true)
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi,
                "Skip, cell(Id:%u/num:%u)) is DU Overload! (cell:%u, nbrIdx:%u)\n", pNbr->cellId, targetCellNum,
                cellNum, nbrIdx);
            return false;
        }

        // FGR-CC5201 FR113 :: SN Init Mobility
        // - Candidate PSCell is not non-SSB cell
        //     * Non-SSB cell is defined by SSB-ToMeasure with all zero value
        if (FnVCCB_IsNonSsbCell(pTgtCellInfo))
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi,
                "Skip, cell(Id:%u/num:%u)) is Not SSB cell! (cell:%u, nbrIdx:%u)\n", pNbr->cellId, targetCellNum,
                cellNum, nbrIdx);
            return false;
        }
    }
    else
    {
        // SVR25A FGR-CC5201::FR113
        if (FnVCCB_IsInterGnbNbrDeactivated(*pNbr))
        {
            VCCB_PRINT_CALL_TGT_SEL(
                ptCi, "cell(%d) nbrIdx(%d) is deactivated cell\n", cellNum, nbrIdx);
            return false;
        }
    }

    // FGR-CC5201 FR113 :: SN Init Mobility
    // - Candidate PSCell is allowed for NR-DC PSCell
    //     * Refer [FGR-SF0001 NSA/SA Operation Scenario] for details
    if (FnVCCB_isNRDC_allowedCell(ptCi, pNbr) == false)
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi,
            "Skip, cell(Id:%u/num:%u)) is not allowed to be NRDC cell! (cell:%u, nbrIdx:%u)\n", pNbr->cellId,
            targetCellNum, cellNum, nbrIdx);
        return false;
    }

    // FGR-CC5201 FR113 :: SN Init Mobility
    // - [23A] Candidate PSCell is not SDL cell
    //     * Refer [FGR-CC3301 Call control for NR cell operation] for definition of SDL cell
    if (FnVCCB_IsNbrSDLCell(ptCi, pNbr))
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi,
            "Skip, gnbNbrCell(ssbArfcn:%u, gnbId:%u, cellId:%u, pci:%u arfcnDl/UL:%u/%u) SDL Cell!\n",
            pNbr->ssbArfcn, pNbr->globalGnbId.gnbId.id, pNbr->cellId, pNbr->nrPci, pNbr->nrArfcnDl, pNbr->nrArfcnUl);

        return false;
    }

    // FGR-CC5201 FR113 :: SN Init Mobility
    // - At least one NR-DC band combination is supported with candidate PSCell
    if (GOOD != FnVCCB_MRDC_checkSupportedBand(ptCi, cellNum, requiredBand, pNbr, filter))
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi,
            "Skip, cell(Id:%u/num:%u)) is Not Allowed BC List! (cell:%u, nbrIdx:%u)\n", pNbr->cellId, targetCellNum,
            cellNum, nbrIdx);
        return false;
    }

    // FGR-CC5201 FR113 :: SN Init Mobility
    // - If Mobility Restriction List (MRL) exists, candidate PSCell supports at least one PLMN of serving PLMN and/or
    // Equivalent PLMNs in MRL which are not restricted by any of:
    //     * RAT Restrictions (PLMN with NR is forbidden),
    //     * [21D] Forbidden Area Information (PLMN with TAC is Forbidden)
    //     * Service Area Information (PLMN with TAC is Not Allowed),
    //     * Core Network Type Restriction for Equivalent PLMNs (PLMN with 5GC is forbidden)
    // - (22C) If MRL does not exists, candidate PSCell supports selected PLMN of UE
    if (FnVCCB_NRDC_checkTAI(ptCi, cellNum, ptHrl, ptCandidateCell, PROC_UNKNOWN, pNbr) != GOOD)
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi,
            "Skip, cell(Id:%u/num:%u)) is Not Allowed PLMN/SLICE! (cell:%u, nbrIdx:%u)\n", pNbr->cellId, targetCellNum,
            cellNum, nbrIdx);
        return false;
    }

    if (GOOD != VCCM_CompareNbrSmtc1Condition(&requiredSmtc1, pNbr))  // NR_CONN_MC_23A modified
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi,
            "Skip, cell(Id:%u/num:%u)) is not match smtc1 offset (cell:%u, nbrIdx:%u, sts:%u, Nbr:%u MeasObj:%u)\n",
            pNbr->cellId, targetCellNum, cellNum, nbrIdx, pNbr->smtcStatus, pNbr->smtc1.periodicityAndOffset.offset,
            requiredSmtc1.periodicityAndOffset.offset);
        return false;
    }

    return true;
}

bool FnVCCB_IsGnbRestrictedforNrdcSnByOvld(callInfo_type *ptCi, const vccbGlobalGnbId_type *targetGnbId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(targetGnbId, false);

    NrdcSnRestrictedGnbsByOvld_type &restrictedGnbs = ptCi->restrictedGnbsforNrdcSn;

    if (DBG->flag.disable_RestrictingGnbTobeSnByOvld == VCCB_FLAG_ON)
    {
        return false;
    }

    const auto maxIdx = util::minOfArraySizeAndNumOfElems(restrictedGnbs.gnbList, restrictedGnbs.noofElm);
    time_t currTime = time(NULL);
    const VccbDbgInfo_type *const pDbg = DBG;
    const auto foundEntry = std::find_if(restrictedGnbs.gnbList, restrictedGnbs.gnbList + maxIdx,
        [&](RestrictedGnb_type blockedGnbInfo)
        {
            if (blockedGnbInfo.globalGnbId.gnbId.id != targetGnbId->gnbId.id ||
                blockedGnbInfo.globalGnbId.plmn.longId != targetGnbId->plmn.longId)
            {
                return false;
            }
            if (pDbg->value.restrictedGnbLifeTime == 0)
            {
                // 0 is infinity
                return true;
            }
            double timeGap = difftime(currTime, blockedGnbInfo.timeStamp);
            if (timeGap < 0)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "difftime ERROR, so blockedGnbInfo.timeStamp is refreshed!\n");
                blockedGnbInfo.timeStamp = time(NULL);
            }
            else if (pDbg->value.restrictedGnbLifeTime < static_cast<uint32_t>(timeGap))
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "restrictedGnbLifeTime is expired(lifetime:%u, difftime:%lf)\n",
                    pDbg->value.restrictedGnbLifeTime, timeGap);
                return false;
            }

            return true;
        });
    if (foundEntry == (restrictedGnbs.gnbList + maxIdx))
    {
        return false;
    }

    return true;
}

bool FnVCCB_IsGnbRestrictedforNrdcSn(callInfo_type *ptCi, const vccbGlobalGnbId_type targetGnbId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    if (FnVCCB_IsGnbBlocklisted(ptCi, targetGnbId))
    {
        VCCB_PRINT_CALL_DATA(ptCi, "Can't be SN for NR-DC due to blocked gnb(plmn:%x, gnbId:%u)!\n",
            targetGnbId.plmn.longId, targetGnbId.gnbId.id);
        return true;
    }

    if (FnVCCB_IsGnbRestrictedforNrdcSnByOvld(ptCi, &targetGnbId))
    {
        VCCB_PRINT_CALL_DATA(ptCi, "Can't be SN for NR-DC due to restricted gnb by overload(plmn:%x, gnbId:%u)!\n",
            targetGnbId.plmn.longId, targetGnbId.gnbId.id);
        return true;
    }

    return false;
}

void FnVCCB_InitRestrictedGnbsforNrdcSn(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    memset(&ptCi->restrictedGnbsforNrdcSn, 0, sizeof(ptCi->restrictedGnbsforNrdcSn));
}

void FnVccb_PrepareNrdcUlTrafficMonitor(
    callInfo_type *ptCi, uint16_t outstandingCellNum, uint16_t tGnbNum, uint16_t tCellIdentity)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    NrdcUlTrafficStatusRptCfg_type &newItem = ptCi->nrdcUlTrafficMonitorCtx.newItem;
    uint8_t action = UL_TRF_MON_Stop;

    newItem.present = static_cast<uint8_t>(VCCB_FLAG_OFF);

    if (ptCi->callType == E_CALLTYPE_NSA || IS_NRDC_SN(ptCi))
    {
        return;
    }

    if (outstandingCellNum >= MAX_CELL_NUM_VCCB)
    {
        if (GOOD != FnVCCB_GetCellNumFromCellId(tGnbNum, tCellIdentity, &outstandingCellNum))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "FnVCCB_GetCellNumFromCellId(gnbNum:%hu, cellIdentity:%u) ERROR!\n", tGnbNum, tCellIdentity);

            // return;  TBD, in 23B, UL Traffic Monitoring IE shall be always included.
            outstandingCellNum = ptCi->servCellNum;
        }
    }

    newItem.present = static_cast<uint8_t>(VCCB_FLAG_ON);
    newItem.outstandingCellNum = outstandingCellNum;

    if (GOOD == FnVCCB_CommonCheckTrfStatusRptCfgforNrdc(ptCi, outstandingCellNum))
    {
        action = UL_TRF_MON_Start;
    }

    newItem.action = action;
}

void FnVccb_InitNrdcUlTrafficMonitorCtx(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    OFF_RCV_UlTrfStatusRptForNrdcAddition(ptCi);
    memset(&ptCi->nrdcUlTrafficMonitorCtx, 0, sizeof(ptCi->nrdcUlTrafficMonitorCtx));
}

void FnVccb_SyncNrdcUlTrafficMonitor(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->nrdcUlTrafficMonitorCtx.newItem.present)
    {
        ptCi->nrdcUlTrafficMonitorCtx.installedItem = ptCi->nrdcUlTrafficMonitorCtx.newItem;
    }
}

void FnVCCB_AddEntryforRestrictedGnbByOvld(callInfo_type *ptCi, vccbGlobalGnbId_type globalGnbId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    NrdcSnRestrictedGnbsByOvld_type &restrictedGnbs = ptCi->restrictedGnbsforNrdcSn;

    time_t currTime = time(NULL);
    if (currTime < 0) return;

    restrictedGnbs.currIdx = restrictedGnbs.currIdx % MAX_RESTRICTED_GNB_BY_OVLD;
    restrictedGnbs.gnbList[restrictedGnbs.currIdx].timeStamp = currTime;
#if defined(IPC_TEST)
    restrictedGnbs.gnbList[restrictedGnbs.currIdx].timeStamp -= (time_t)600;
#endif
    restrictedGnbs.gnbList[restrictedGnbs.currIdx].globalGnbId = globalGnbId;
    restrictedGnbs.currIdx = static_cast<uint8_t>((restrictedGnbs.currIdx + 1) % MAX_RESTRICTED_GNB_BY_OVLD);
    if (restrictedGnbs.noofElm < MAX_RESTRICTED_GNB_BY_OVLD)
    {
        restrictedGnbs.noofElm++;
    }
}

void FnVCCB_DoesPeerTobeRestrictedAfterRejected(callInfo_type *ptCi, XNAP_Cause_type *cause)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(cause);

    if (cause->choice == XNAP_misc_chosen && cause->u.misc == XNAP_control_processing_overload)
    {
        enumSnDifferentiator_type id = SRC_SN;

        if (VHCM_isSaHandoverUE(ptCi))
        {
            id = TGT_SN;
        }

        xnNbrInfo_type *pXnNbr = FnVCCB_GetXnNbrInfo(ptCi->gnbNum, ptCi->mrdcInfo.SNInfo[id].epIdx);
        VALID_E_POINT_CHECK_VOID(pXnNbr);
        vccbGlobalGnbId_type newEntry;

        if (pXnNbr->status == EQUIP && pXnNbr->present.plmnMcc == OPT_PRESENT &&
            pXnNbr->present.plmnMnc == OPT_PRESENT && pXnNbr->present.ngRanNodeId == OPT_PRESENT)
        {
            newEntry.plmn.longId = pXnNbr->plmn.longId;
            newEntry.gnbId = pXnNbr->gnbId;
        }
        else
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "Invalid globalGnbId Info <SN-Id(%d), epIdx(%hu),"
                " XnNbr(status:%d, present(mcc:%u,mnc:%u,ngRanNodeId:%u))!\n",
                id, ptCi->mrdcInfo.SNInfo[id].epIdx, pXnNbr->status, pXnNbr->present.plmnMcc, pXnNbr->present.plmnMnc,
                pXnNbr->present.ngRanNodeId);
            return;
        }

        // SVR23B FGR-CC5200 Basic Operation For NR-DC :: FR419 :: Restricted gNB by overload
        FnVCCB_AddEntryforRestrictedGnbByOvld(ptCi, newEntry);
    }
    else if (cause->choice == XNAP_radioNetwork_chosen &&
             cause->u.radioNetwork == XNAP_no_radio_resources_available_in_target_cell)
    {  // FGR-CC5200:FR482
        FnVCCB_ProcNrdcAddCacReject(ptCi);
    }
    else if (cause->choice == XNAP_radioNetwork_chosen && cause->u.radioNetwork == XNAP_rRM_purpose)
    {
        // FGR-CC5200:FR483
        FnVCCB_ProcNrdcAddCacRejectforCellBackOff(ptCi);
    }
}

void FnVCCB_SetNrdcOverloadControl(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    const VccbCfgInfo_type *const pCfg = CFG;
    const VccbCfgInfo_type::OverloadControl::UeSigCpuOverloadControl &ueSigOvldCtrl =
        CFG->overloadControl.ueSigCpuOverloadControl;

    ptCi->isNrdcDisabledByCpcOvld = false;
    if (e_VCCB_NVGNB != VCOM_getSystemType())
    {
        if (ueSigOvldCtrl.ueSigCpuOverloadAction != VCCB_FLAG_ON)
        {
            return;
        }

        if (CpuOverloadCtrl_noControl ==
                static_cast<enumCpuOverloadCtrlLevel_type>(ueSigOvldCtrl.overloadedLevelNrdc) ||
            CpuOverloadCtrl_cpuMinor < static_cast<enumCpuOverloadCtrlLevel_type>(ueSigOvldCtrl.overloadedLevelNrdc))
        {
            return;
        }

        if (indeterminate != static_cast<AlarmPerceivedSeverity>(pCfg->overloadStatus) &&
            pCfg->overloadStatus <= ueSigOvldCtrl.overloadedLevelNrdc)
        {
            ptCi->isNrdcDisabledByCpcOvld = true;
        }
    }
}


/**
 * @brief    check whether a pdusSession is going to be set up to UP
 * @details  In case of sn-term-split in MN or mn-term-split in SN, it is possible that a pduSession has not been setup to UP.
 * @param [in] pduSess : reference to pduSession
 * @return     true/false
 */
bool FnVCCB_IsPDUSessTobeSetupToUP(const callInfo_type *ptCi, const callPDUSessInfo_type &pduSess)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        return false;
    }

    // NR-DC doesn't support Multi-UP in the current scope.

    if (pduSess.usage != CI_use)
    {
        return false;
    }

    if (pduSess.pduSessStatus == S_Setup ||
            (pduSess.pduSessStatus == S_Modify && !pduSess.isE1Setupped))
    {
        if (IS_NRDC_SN(ptCi))
        {
            if (FnVCCB_IsAnySnTermPerPDU(ptCi, &pduSess, current_bearerType))
            {
                return true;
            }
        }
        else
        {
            return true;
        }
    }

    return false;
}

bool FnVCCB_IsAnyPDUSessTobeSetupToUP(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (IS_NRDC_SN(ptCi) && !FnVCCB_IsAnySnTermPerUE(ptCi, current_bearerType))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Skip AUPFSelection due to No SNTerm Bearers in NRDC-SN\n");
        return false;
    }

    for (auto &pduSession : ptCi->pduSess)
    {
        if (FnVCCB_IsPDUSessTobeSetupToUP(ptCi, pduSession))
        {
            return true;
        }
    }

    return false;
}

// FGR-CC5200:FR482
bool FnVCCB_IsNrdcAddCacRejectedFreq(callInfo_type *ptCi, uint32_t freq)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    NrdcAddCacRejectedFreq_type &rejectedFreq = ptCi->nrdcAddCacRejectedFreq;

    if (!rejectedFreq.bitMask)
    {
        return false;
    }

    for (int entry = 0; entry < MAX_NRDC_ADD_CAC_REJECTED_FREQ; ++entry)
    {
        if (!(rejectedFreq.bitMask & (1 << entry)))
        {
            continue;
        }

        if (rejectedFreq.ssbArfcnList[entry] == freq)
        {
            return true;
        }
    }
    return false;
}

// FGR-CC5200:FR482
void FnVCCB_AddEntryforNrdcAddCacRejectedFreq(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    NrdcAddCacRejectedFreq_type &rejectedFreq = ptCi->nrdcAddCacRejectedFreq;
    uint32_t freq = GET_MN_SELECT_PSCELL_FREQ(ptCi);

    if (FnVCCB_IsNrdcAddCacRejectedFreq(ptCi, freq))
    {
        VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "Warning, NrdcAddCacRejected Freq(%u) has already been registered!\n", freq);
        return;
    }

    if (rejectedFreq.nextIdx >= MAX_NRDC_ADD_CAC_REJECTED_FREQ)
    {
        rejectedFreq.nextIdx = 0;
    }

    if (rejectedFreq.bitMask & (1 << rejectedFreq.nextIdx))
    {
        VCCB_PRINT_CALL_NRDC_BASIC(
            ptCi, "NrdcAddCacRejected Freq(%u) was wrapped around at nextIdx(%u)!\n", freq, rejectedFreq.nextIdx);
    }

    rejectedFreq.cellId = CELLINFO[ptCi->servCellNum].cellIdentity;
    rejectedFreq.ssbArfcnList[rejectedFreq.nextIdx] = freq;
    rejectedFreq.bitMask |= static_cast<uint8_t>(1 << rejectedFreq.nextIdx);
    rejectedFreq.nextIdx = static_cast<uint8_t>((rejectedFreq.nextIdx + 1) % MAX_NRDC_ADD_CAC_REJECTED_FREQ);

    if (ERROR == VCCM_EnqueueActionMeasReconfig(ptCi, MeasReconfigPriorAction_Full))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_EnqueueActionMeasReconfig in %s fail!\n", __func__);
    }
    else
    {
        VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "VCCM_EnqueueActionMeasReconfig is done in %s!\n", __func__);
    }
}

// FGR-CC5200:FR482
void FnVCCB_InitNrdcAddCacRejectedFreq(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    NrdcAddCacRejectedFreq_type &rejectedFreq = ptCi->nrdcAddCacRejectedFreq;

    rejectedFreq.bitMask = 0;
    rejectedFreq.nextIdx = 0;
    rejectedFreq.cellId = 0xFFFF;
}

// FGR-CC5200:FR482
void FnVCCB_ProcNrdcAddCacReject(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnAdd, MRDC_PROC_PURPOSE_BearerTypeChange))
    {
        return;
    }

    if (GET_REMOVE_MEAS_ADD_REJECT_YANG(ptCi))
    {
        if (GET_MN_SELECT_PSCELL_FREQ(ptCi))
        {
            FnVCCB_AddEntryforNrdcAddCacRejectedFreq(ptCi);
        }
    }
    else
    {
        FnVCCB_InitNrdcAddCacRejectedFreq(ptCi);
    }
}

// FGR-CC5200:FR640
int FnVCCB_NrdcCtxRelStat_ConvertSnCallReleaseToSnCtxRelType(enumNrdcSnCallReleaseType_type nrdcSnCallReleaseType)
{
    AUTO_TRACE_FUNC;
    int relType = PSCellDrop_END;
    switch (nrdcSnCallReleaseType)
    {
        case NRDC_SN_CALL_RELEASE_BY_XN_LINK_FAIL:
        {
            relType = PSCellDrop_NrdcAbnormalReleasebySn_XnLinkFail;
            break;
        }
        case NRDC_SN_CALL_RELEASE_BY_RESET_INITIATED_BY_MN:
        {
            relType = PSCellDrop_NrdcAbnormalReleasebyMn_XnReset;
            break;
        }
        default:
        {
            break;
        }
    }
    return relType;
}

// FGR-CC5200:FR640
void FnVCCB_NrdcCtxRelStat_SaveSnRelType(callInfo_type *ptCi, int mType, enumSnDifferentiator_type snType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(snType, MAX_SN);

    if (!IS_SUPPORT_CollectNrdcCtxRelStats(ptCi)) return;

    // nrdcCtxRel type is not allowed to be updated after first save
    enumNrdcCtxRel_type SavedRelType = GET_STAT_CTX_REL_ReleaseType(ptCi, snType);
    if (IS_VALID_STAT_CTX_REL_TYPE(SavedRelType))
    {
        VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[NRDC] NrdcCtxRel.releaseType(%u) has already been saved !!\n", SavedRelType);
        return;
    }

    // check input type is valid
    if (IS_VALID_STAT_CTX_REL_TYPE(mType))
    {
        SET_STAT_CTX_REL_ReleaseType(ptCi, snType, mType);  // save
        VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[NRDC] nrdcCtxRel.releaseType(%d) is updated !!\n", mType);
        return;
    }

    int mNewType = PSCellDrop_END;
    switch (ptCi->cause.callFault.callFaultCause)
    {
        case CauseCpInternalUserInactivity:
            mNewType = PSCellDrop_NrdcNormalReleasebySn_UserInactivity;  // XnCause was not saved to callFault.
            break;
        case CauseF1apRadioReleaseDueToPreEmption:
        case CauseE1apRadioNetworkLayerReleaseDueToPreEmption:
            mNewType = PSCellDrop_NrdcNormalReleasebySn_Preemption;
        default:
            break;
    }
    if (IS_VALID_STAT_CTX_REL_TYPE(mNewType))
    {
        SET_STAT_CTX_REL_ReleaseType(ptCi, snType, mNewType);
    }
}

// FGR-CC5200:FR640
int FnVCCB_NrdcCtxRelStat_ConvertXnCauseToSnCtxRelType(callInfo_type *ptCi, uint16_t msgId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, PSCellDrop_END);
    int relType = PSCellDrop_END;
    switch (ptCi->cause.xnCause)
    {
        case CauseXnapRadioNetworkLayerRadioConnectionWithUeLost:
            // FGR-CC5203: FR230
            if (msgId == XN_SNodeReleaseRequest_id)
            {
                relType = PSCellDrop_NrdcAbnormalReleasebyMn_RadioConnectionWithUeLost;
            }
            else
            {
                switch (ptCi->nrdcScgFailureInfo.failType)
                {
                    case NrDcScgFailCause_dl_t310Expiry:                    // 0
                        relType = PSCellDrop_NrdcAbnormalReleasebySn_DL_t310Expiry;
                        break;
                    case NrDcScgFailCause_dl_randomAccessProblem:           // 1
                        relType = PSCellDrop_NrdcAbnormalReleasebySn_DL_randomAccessProblem;
                        break;
                    case NrDcScgFailCause_dl_rlcMaxRetransmission:          // 2
                        relType = PSCellDrop_NrdcAbnormalReleasebySn_DL_rlcMaxNumRetx;
                        break;
                    case NrDcScgFailCause_dl_synchReconfigFailure:          // 3
                        relType = PSCellDrop_NrdcAbnormalReleasebySn_DL_synchReconfigFailureSCG;
                        break;
                    case NrDcScgFailCause_dl_scgReconfigFailure:            // 4
                        relType = PSCellDrop_NrdcAbnormalReleasebySn_DL_scgReconfigFailure;
                        break;
                    case NrDcScgFailCause_dl_srb3IntegrityFailure:          // 5
                        relType = PSCellDrop_NrdcAbnormalReleasebySn_DL_srb3IntegrityFailure;
                        break;
                    case NrDcScgFailCause_dl_scglbtFailure:                 // 6
                    case NrDcScgFailCause_dl_bhRLF:                         // 9
                        relType = PSCellDrop_NrdcAbnormalReleasebySn_DL_other;
                        break;
                    case NrDcScgFailCause_dl_beamFailureRecoveryFailure:    // 7
                        relType = PSCellDrop_NrdcAbnormalReleasebySn_DL_beamFailureRecoveryFailure;
                        break;
                    case NrDcScgFailCause_dl_t312Expiry:                    // 8
                        relType = PSCellDrop_NrdcAbnormalReleasebySn_DL_t312Expiry;
                        break;
                    case NrDcScgFailCause_ul_outOfSync:                     // 10
                        relType = PSCellDrop_NrdcAbnormalReleasebySn_UL_outOfSync;
                        break;
                    case NrDcScgFailCause_ul_rlcMaxRetransmission:          // 11
                        relType = PSCellDrop_NrdcAbnormalReleasebySn_UL_rlcMaxNumRetx;
                        break;
                    default:
                        relType = PSCellDrop_UnknownbySn;
                        break;
                }
            }
            break;
        case CauseXnapRadioNetworkLayerFailureInTheRadioInterfaceProcedure:
            relType = PSCellDrop_NrdcNormalReleasebyMn_UeSignature;
            break;
        case CauseXnapRadioNetworkLayerUserInactivity:
            relType = PSCellDrop_NrdcNormalReleasebyMn_UserInactivity;
            break;
        case CauseXnapRadioNetworkLayerTimeCriticalAction:
            relType = PSCellDrop_NrdcNormalReleasebyMn_RRE;
            break;
        case CauseXnapRadioNetworkLayerMnMobility:
            if (ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_MGNB_INTERMNHO)
            {
                //Inter MN without SN Change Scenario
            }
            else
            {
                relType = PSCellDrop_NrdcNormalReleasebyMn_MnMobilityWithSnRelease;
            }
            break;

        default:
            if (msgId == XN_SNodeReleaseRequest_id || IS_NRDC_MN(ptCi))
            {
                relType = PSCellDrop_UnknownbyMn;
            }
            else
            {
                relType = PSCellDrop_UnknownbySn;
            }
            break;
    }
    return relType;
}

// FGR-CC5201:FR608
int FnVCCB_NrdcCtxRelStat_ConvertHoTypeToSnCtxRelType(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, PSCellDrop_END);
    int relType = PSCellDrop_END;

    if(ptCi->stateCmd == IntraRatHO_cmd)
    {
        switch (ptCi->hoInfo.hoType.initiated)
        {
            case HO_TYPE_SA_MGNB_INITIATED: // MN Init Mobility, Intra-MN with Intra-SN
            case HO_TYPE_SA_MGNB_INTERMNHO: // MN Init Mobility, Inter-MN with Intra-SN
                relType = PSCellDrop_NrdcNormalReleasebyMn_MnMobilityWithIntraSnMobility;
                break;
            case HO_TYPE_SA_SGNB_INITIATED:  // SN Init Mobility, Intra-SN
                relType = PSCellDrop_NrdcNormalReleasebySn_IntraSnMobility;
                break;
            case HO_TYPE_SA_SGNB_INITIATED_INTER_SN_CHANGE://SN Init Mobility, Inter-SN
                relType = PSCellDrop_NrdcNormalReleasebySn_InterSnMobility;
                break;
            case HO_TYPE_SA_MN_INIT_SCG_RESUME:
                relType = PSCellDrop_UnknownbyMn; // relType does not exist for SCG RESUME
                break;
            default:
                break;
        }
    }
    return relType;
}

// FGR-CC5200:FR640
void FnVCCB_NrdcCtxRelStat_SetCtrlFlag(
    callInfo_type *ptCi, enumSnDifferentiator_type snType, enumNrdcCtxRelCtrlFlag_type flag, enumVccbFlag val)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(snType, MAX_SN);
    mrdcStatistic::NrdcCtxRelStat_s &nrdcCtxRel = ptCi->mrdcInfo.stat.nrdcCtxRel[snType];
    switch (flag)
    {
        case isF1AccSuccforPSCellExpected:
            nrdcCtxRel.ctrl.flag.isF1AccSuccforPSCellExpected = (uint16_t)val & e_BitMask_1bit;
            VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[NRDC] Set isF1AccSuccforPSCellExpected as %u!!\n", val);
            break;
        case isF1AccSuccforPSCellReceived:
            nrdcCtxRel.ctrl.flag.isF1AccSuccforPSCellReceived = (uint16_t)val & e_BitMask_1bit;
            VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[NRDC] Set isF1AccSuccforPSCellReceived as %u!!\n", val);
            break;
        case isDataActive:
            nrdcCtxRel.ctrl.flag.isDataActive = (uint16_t)val & e_BitMask_1bit;
            VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[NRDC] Set isDataActive as %u!!\n", val);
            break;
        case isStatsCollected:
            nrdcCtxRel.ctrl.flag.isStatsCollected = (uint16_t)val & e_BitMask_1bit;
            VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[NRDC] Set isStatsCollected as %u!!\n", val);
            break;
        default:
            VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "Unknown NrdcCtxRelCtrlFlag(%u)!\n", flag);
            break;
    }
}

// FGR-CC5200:FR640
void FnVCCB_NrdcCtxRelStat_SetCtrlInfo(
    callInfo_type *ptCi, enumNrdcCtxRelCtrlFlag_type flag, enumVccbFlag flagVal, uint16_t cellNum, enumSnDifferentiator_type snType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(snType, MAX_SN);

    if (!IS_SUPPORT_CollectNrdcCtxRelStats(ptCi)) return;

    if (flag != isDataActive)
    {
        enumNrdcCtxRel_type SavedRelType = GET_STAT_CTX_REL_ReleaseType(ptCi, snType);
        if (IS_VALID_STAT_CTX_REL_TYPE(SavedRelType))
        {
            VCCB_PRINT_CALL_NRDC_BASIC(
                ptCi, "[NRDC] NrdcCtxRel.releaseType(%u) has already been saved !!\n", SavedRelType);
            return;
        }
    }

    FnVCCB_NrdcCtxRelStat_SetCtrlFlag(ptCi, snType, flag, flagVal);

    /*if cellNum is 0xffff, it means that outstandingCellId will not be set in this time.*/
    VccbCellInfo_type *pCell = FnVCCB_GetCellInfo(cellNum);
    if (pCell != NULL)
    {
        SET_STAT_NRDC_CTX_REL_CTRL_CellId(ptCi, snType, pCell->cgi.ci);
    }
}

// FGR-CC5200:FR640
void FnVCCB_NrdcCtxRelStat_Init(callInfo_type *ptCi, enumSnDifferentiator_type snType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(snType, MAX_SN);

    if (!IS_SUPPORT_CollectNrdcCtxRelStats(ptCi)) return;

    ptCi->mrdcInfo.stat.nrdcCtxRel[snType].ctrl.flag.value = 0;
    ptCi->mrdcInfo.stat.nrdcCtxRel[snType].releaseType = PSCellDrop_END;
    return;
}

// FGR-CC5200:FR640
void FnVCCB_NrdcCtxRelStat_PrepareCollecting(callInfo_type *ptCi, uint16_t cellNum, enumSnDifferentiator_type snType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(snType, MAX_SN);
    /*TBD  if this macro func would be used in common api, next condition check might be used.
      if (!(IS_NRDC_SN(_ptCi) &&
           ((_ptCi)->stateCmd == MrdcXnSNAdd_cmd ||
            ((_ptCi)->stateCmd == IntraRatHO_cmd && ((_ptCi)->hoInfo.hoType.initiated == HO_TYPE_SA_SGNB_INITIATED
      ||
              (_ptCi)->hoInfo.hoType.initiated == HO_TYPE_SA_MGNB_INITIATED ||
              (_ptCi)->hoInfo.hoType.initiated == HO_TYPE_SA_MGNB_INTERMNHO ||
              (_ptCi)->hoInfo.hoType.initiated == HO_TYPE_SA_MN_INIT_SCG_RESUME)))) break; */
    FnVCCB_NrdcCtxRelStat_Init(ptCi, snType);
    FnVCCB_NrdcCtxRelStat_SetCtrlInfo(ptCi, isF1AccSuccforPSCellExpected, VCCB_FLAG_ON, cellNum, snType);
}

// FGR-CC5200:FR640
uint16_t FnVCCB_NrdcCtxRelStat_GetCtrlFlag(
    callInfo_type *ptCi, enumSnDifferentiator_type snType, enumNrdcCtxRelCtrlFlag_type flag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(snType, MAX_SN);
    mrdcStatistic::NrdcCtxRelStat_s &nrdcCtxRel = ptCi->mrdcInfo.stat.nrdcCtxRel[snType];
    switch (flag)
    {
        case isF1AccSuccforPSCellExpected:
            return nrdcCtxRel.ctrl.flag.isF1AccSuccforPSCellExpected;
        case isF1AccSuccforPSCellReceived:
            return nrdcCtxRel.ctrl.flag.isF1AccSuccforPSCellReceived;
        case isDataActive:
            return nrdcCtxRel.ctrl.flag.isDataActive;
        case isStatsCollected:
            return nrdcCtxRel.ctrl.flag.isStatsCollected;
        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "Unknown NrdcCtxRelCtrlFlag(%u)!\n", flag);
            return false;
    }
}

// FGR-CC5200:FR640
void FnVCCB_NrdcCtxRelStat_Collect(callInfo_type *ptCi, const char *fnName, enumSnDifferentiator_type snType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(fnName);
    VCCB_CHECK_E_RANGE_AND_VOID(snType, MAX_SN);
    mrdcStatistic::NrdcCtxRelStat_s &nrdcCtxRel = ptCi->mrdcInfo.stat.nrdcCtxRel[snType];

    if (!IS_SUPPORT_CollectNrdcCtxRelStats(ptCi)) return;

    if (!FnVCCB_NrdcCtxRelStat_GetCtrlFlag(ptCi, snType, isF1AccSuccforPSCellReceived))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[NRDC] isF1AccSuccforPSCellReceived flag is false in %s !\n", __func__);
        return;
    }

    if (FnVCCB_NrdcCtxRelStat_GetCtrlFlag(ptCi, snType, isStatsCollected))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[NRDC] NrdcCtxRel Stats has already been collected in %s !\n", __func__);
        return;
    }
    if (!IS_VALID_STAT_CTX_REL_TYPE(nrdcCtxRel.releaseType))  // not saved before
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "[NRDC] nrdcCtxRel.releaseType was not set before... so PSCellDrop_UnknownbySn will be used in %s !\n",
            __func__);
        nrdcCtxRel.releaseType = PSCellDrop_UnknownbySn;
    }
    uint64_t dtaActivityStatus =
        (uint64_t)(nrdcCtxRel.ctrl.flag.isDataActive ? ActivityStatus_ACTIVE : ActivityStatus_INACTIVE);

    /*
        note)
        The NrdcNormalReleasebyMnTot, NrdcAbnormalReleasebyMnTot, NrdcNormalReleasebySnTot and
       NrdcAbnormalReleasebySnTot are will be collected additionally from stats commApi if statsType is not unknown like
       PSCellDrop_UnknownbyMn, PSCellDrop_UnknownbySn.
    */
    int statType = nrdcCtxRel.releaseType;
    switch (statType)
    {
        case PSCellDrop_UnknownbyMn:
        {
            statType = PSCellDrop_NrdcNormalReleasebyMnTot;
            break;
        }
        case PSCellDrop_UnknownbySn:
        {
            statType = PSCellDrop_NrdcNormalReleasebySnTot;
            break;
        }
        default:
            break;
    }

    // FGR-CC5200:FR641
    // if getCallServiceType() api is supported in sa basic feature,
    // nrdc basic owner shall change this api to support collection of drb based serviceType.
    // i.e) if IS_NRDC_MN is true, "if pDrb->bearerType == SN_Term_Undetermined continue" shall be used instead of "if
    // ptDi->terminationPoint == SN_Terminated continue".
    if (IS_SUPPORT_CollectNrdcCtxRelServiceTypeStats(ptCi))
    {
        std::set<uint32_t> svcTypeStatsList;
        if (IS_SERVICE_TYPE_INDEX_VALID_FOR_STAT_NRDC_CTX_REL_SERVICE_TYPE(ptCi))
        {
            GET_SERVICE_TYPE_INDEX_FOR_STAT_NRDC_CTX_REL_SERVICE_TYPE(ptCi, svcTypeStatsList);
            CLEAR_SERVICE_TYPE_INDEX_FOR_STAT_NRDC_CTX_REL_SERVICE_TYPE(ptCi);
        }
        else
        {
            MACRO_GET_CALL_SERVICE_TYPE(ptCi, svcTypeStatsList);
        }

        for (const auto &svcTypeStats : svcTypeStatsList)
        {
            MACRO_STAT_PMCC_NAME(STAT_NRDC_CTX_REL_SERVICE_TYPE, statType, ptCi, static_cast<uint64_t>(svcTypeStats),
                dtaActivityStatus, 0, 0, 0, fnName);
        }
    }

    MACRO_STAT_PMCC_NAME(STAT_NRDC_CTX_REL, statType, ptCi, dtaActivityStatus, 0, 0, 0, 0, fnName);
    FnVCCB_NrdcCtxRelStat_SetCtrlFlag(ptCi, snType, isStatsCollected, VCCB_FLAG_ON);
}

bool FnVCCB_NeedToTriggerRrcUeBased(callInfo_type *ptCi, uint16_t cellNum)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    VccbCellInfo_type *const pCell = FnVCCB_GetCellInfo(cellNum);
    VALID_E_POINT_CHECK_RET_VAL(pCell, false);
    scgBandSelectionConfigYang_type &scgBandSelYang = pCell->scgBandSelectionConfig;

    VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[SCG-BAND SELC]   Check Operation mode (RRC UE Opr Mode)\n");

    uint16_t overloadedNbrCnt = 0;
    uint16_t maxNbrIdx = (uint16_t)UMIN((uint16_t)MAX_NBR_RELATION_TABLE_PER_CELL, (uint16_t)MAX_NBR_PER_CELL);
    for (uint16_t nbrIdx = 0; nbrIdx < maxNbrIdx; nbrIdx++)
    {
        if (pCell->Nbr[nbrIdx].status != EQUIP) continue;

        sonNbrPrbRsc_type &sonNbr = pCell->cellRscInfo.nbrPrb[nbrIdx];
        if (sonNbr.usage != EQUIP || (sonNbr.isRsUpdate != ON)) continue;

        nbrGnbCellInfo_type *pNbr = NULL;
        if ((GOOD != getNbrGnbCellByCellNbrIdx(cellNum, nbrIdx, &pNbr)) || !pNbr)
        {
            VCCB_PRINT_CALL_NRDC_BASIC(ptCi,
                "[SCG-BAND SELC]   ERROR, getNbrGnbCellByCellNbrIdx(cellNum:%u, nbrIdx:%u, pNbr(%p)) in %s!\n", cellNum,
                nbrIdx, pNbr, __func__);
            continue;
        }

        if (!FnVCCB_GetScgBandSelFR2BandofNbrGnbCellInfo(ptCi, pNbr))
        {
            VCCB_PRINT_CALL_NRDC_BASIC(ptCi,
                "[SCG-BAND SELC]   Neither FR2_39GHz_n260 nor FR2_28GHz_n261(cellNum:%u, nbrIdx:%u, pNbr(%p)) in %s!\n",
                cellNum, nbrIdx, pNbr, __func__);
            continue;
        }

        uint8_t measObjIdx = MAX_NR_OF_OBJECT_ID_DB;
        measurementObjectNRDb_type *ptMeasurementObjectNRDb =
            FnVCCB_FindMeasObjectUsingFrequency(cellNum, pNbr->ssbArfcn, &measObjIdx);
        VALID_E_POINT_CHECK_CONTINUE(ptMeasurementObjectNRDb);
        VCCB_CHECK_E_RANGE_AND_CONTINUE(measObjIdx, MAX_NR_OF_OBJECT_ID_DB);

        VCCB_PRINT_CALL_NRDC_BASIC(ptCi,
            "[SCG-BAND SELC]    Nbr(%u:%u):numAvailUe(%u), "
            "measObj(%u:%u):scgBandThresholdUeCapaNrdc(%u)\n",
            nbrIdx, pNbr->ssbArfcn, sonNbr.numAvailUe, measObjIdx, ptMeasurementObjectNRDb->base.ssbFrequency,
            ptMeasurementObjectNRDb->base.scgBandThresholdUeCapaNrdc);

        if (sonNbr.numAvailUe < ptMeasurementObjectNRDb->base.scgBandThresholdUeCapaNrdc)
        {
            overloadedNbrCnt++;
            VCCB_PRINT_CALL_NRDC_BASIC(ptCi,
                "[SCG-BAND SELC]     Nbr(%u) is Overloaded!! (numAvailUe < "
                "scgBandThresholdUeCapaNrdc)\n",
                nbrIdx);
        }

        if (overloadedNbrCnt > scgBandSelYang.scgBandThresholdEventTrigger)
        {
            VCCB_PRINT_CALL_NRDC_BASIC(ptCi,
                "[SCG-BAND SELC]   >>> Select RRC UE Opr Mode, due to overloadedNbrCnt(%u) > "
                "scgBandThresholdEventTrigger(%u)!\n",
                overloadedNbrCnt, scgBandSelYang.scgBandThresholdEventTrigger);
            return true;
        }
    }

    VCCB_PRINT_CALL_NRDC_BASIC(ptCi,
        "[SCG-BAND SELC]   >>> Not RRC UE Opr Mode due to overloadedNbrCnt(%u) < "
        "scgBandThresholdEventTrigger(%u)!\n",
        overloadedNbrCnt, scgBandSelYang.scgBandThresholdEventTrigger);

    return false;
}

int FnVCCB_UpdateNrdcScgBandSelectionMgmtPerCell(callInfo_type *ptCi, uint16_t cellNum, uint16_t newFreqBand)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type const *pCell = FnVCCB_GetCellInfo(cellNum);
    VALID_E_POINT_CHECK_ERROR(pCell);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    nrdcScgBandSelectionMgmt_type &scgBandSelMgmt =
        THREAD_INFO->call[ptCi->myThreadId].nrdcScgBandSelMgmtPerCell[cellNum];

    scgBandSelectionConfigYang_type const &scgBandSelYang = pCell->scgBandSelectionConfig;
    // bool needToUpdate = false;

    VCCB_PRINT_CALL_NRDC_BASIC(
        ptCi, "[SCG-BAND SELC]  rsuTransId(cell:%u, thread:%u)\n", pCell->rsuTransId, scgBandSelMgmt.rsuTransId);
    if (scgBandSelMgmt.rsuTransId == pCell->rsuTransId)
    {
        VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[SCG-BAND SELC]   rsuTransId has been not changed!\n");
        if (scgBandSelYang.scgBandCapacityOption != SCG_BAND_SEL_CapacityOptionBoth &&
            IS_VALID_ScgBandSelOprMode(scgBandSelMgmt.oprMode))
        {
            return GOOD;
        }
        else if (!pCell->rsuTransId)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[SCG-BAND SELC]   RSU has not been updated !\n");
            return ERROR;
        }
        else
        {
            // need to refresh scgBandSelOprMode in abnormal case...
            VCCB_PRINT_CALL_ERROR(ptCi,
                "[SCG-BAND SELC]   RSU has been updated(transId:%u) but scgBandSelOprMode(%u) has not been "
                "refreshed!\n",
                scgBandSelMgmt.rsuTransId, scgBandSelMgmt.oprMode);
        }
    }

    scgBandSelMgmt.rsuTransId = pCell->rsuTransId;

    /*
    [TBD] In 24A reflects the change of the Yang setting at the reception time of the RSU. If the Yang setting
    change is to be reflected in the SCG selection immediately after the change, the following information must be
    added.

    scgBandSelMgmt.bandSelectionMode = scgBandSelYang.bandSelectionMode;
    scgBandSelMgmt.scgBandCapacityOption = scgBandSelYang.scgBandCapacityOption;
    scgBandSelMgmt.scgBandThresholdEventTrigger = scgBandSelYang.scgBandThresholdEventTrigger;

    for (int objIdx=0; objIdx < MAX_NR_OF_OBJECT_ID_DB; objIdx++)
    {
        measurementObjectNRBaseDb_type &measObjYang = pCell->measurementsData.measurementObjectsNRDb[objIdx].base;
        if (measObjYang.usage == CI_use)
        {
            scgBandSelMgmt.scgBandThresholdUeCapaNrdc[objIdx] = measObjYang.scgBandThresholdUeCapaNrdc;
        }
        else
        {
            scgBandSelMgmt.scgBandThresholdUeCapaNrdc[objIdx] = 70;
        }
    }
    */

    VCCB_PRINT_CALL_NRDC_BASIC(ptCi,
        "[SCG-BAND SELC]  bandSelection mode is set as %u! (CapacityBased:0 EventBased:1)\n",
        scgBandSelYang.bandSelectionMode);

    if (scgBandSelYang.bandSelectionMode == SCG_BAND_SEL_MODE_EventBased &&
        FnVCCB_NeedToTriggerRrcUeBased(ptCi, cellNum))
    {
        // SCG_BAND_SEL_MODE_EventBased
        scgBandSelMgmt.oprMode = SCG_BAND_SEL_OPR_RrcUeBased;
    }
    else
    {
        // SCG_BAND_SEL_MODE_CapacityBased
        VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[SCG-BAND SELC]  scgBandCapacityOption is set as %u! (Dl:0 Ul:1 Both:2)\n",
            scgBandSelYang.scgBandCapacityOption);
        if (scgBandSelYang.scgBandCapacityOption == SCG_BAND_SEL_CapacityOptionBoth)
        {
            scgBandSelMgmt.oprMode = SCG_BAND_SEL_OPR_UlCapaBased;  // default setting
            FnVCCB_SelectScgBandSelOprModeInCapacityBoth(ptCi, cellNum, newFreqBand, scgBandSelMgmt);
        }
        else if (scgBandSelYang.scgBandCapacityOption == SCG_BAND_SEL_CapacityOptionDL)
        {
            scgBandSelMgmt.oprMode = SCG_BAND_SEL_OPR_DlCapaBased;
        }
        else
        {
            scgBandSelMgmt.oprMode = SCG_BAND_SEL_OPR_UlCapaBased;
        }
    }

    VCCB_PRINT_CALL_NRDC_BASIC(ptCi,
        "[SCG-BAND SELC]  operation mode is set as %u! (DL Capa based:1 UL Capa based:2 RRC UE based:3)\n",
        scgBandSelMgmt.oprMode);

    return GOOD;
}

/**
 * @brief   This function is used to store PSCell NR CGI for NR-DC MN
 * @param   ptCi: call information / callInfo_type
 * @param   pNbrGnbCell: neighbor gNB cell information / nbrGnbCellInfo_type
 * @return  void
 */
void FnVCCB_NrdcSetMnSelectPSCellNrcgi(callInfo_type *ptCi, const nbrGnbCellInfo_type *pNbrGnbCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pNbrGnbCell);

    if (IS_NRDC_MN(ptCi) && FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnAdd, MRDC_PROC_PURPOSE_BearerTypeChange))
    {
        SNInfo_type &snInfo = ptCi->mrdcInfo.SNInfo[SRC_SN];

        snInfo.psCell.locationInfo.nrCgi.plmn.longId = pNbrGnbCell->globalGnbId.plmn.longId;
        snInfo.psCell.locationInfo.nrCgi.ci =
            VLIB_GnbIdCellId2NrCellId(&pNbrGnbCell->globalGnbId.gnbId, pNbrGnbCell->cellId);
        snInfo.psCell.locationInfo.present = VCCB_FLAG_ON;
    }
}

/**
 * @brief   This function is used to set the CAC backoff time for a neighbor gNB cell.
 * @param   ptCi: call information / callInfo_type
 * @param   pNbrGnbCell: neighbor gNB cell information / nbrGnbCellInfo_type
 * @return  void
 */
void FnVCCB_SetCacBackOffTime(callInfo_type *ptCi, nbrGnbCellInfo_type *pNbrGnbCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pNbrGnbCell);

    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    // Get the backoff timer value from the gNB Yang configuration
    uint16_t durTimeVal = pGnb->cfg.nrdc.cacBackOff.backoff_timer_val;

    if (MAX_CAC_BACKOFF_TIME_VAL_SEC < durTimeVal)
    {
        durTimeVal = MAX_CAC_BACKOFF_TIME_VAL_SEC;
    }

    struct timespec currTime = tickGetMono();

    long startTimeTick = static_cast<long>(currTime.tv_sec * 1000 + currTime.tv_nsec / 1000000);
    long endTimeTick = startTimeTick + durTimeVal * 1000;

    /*
        Set the CAC backoff time for the neighbor gNB cell
        No need to mutex lock, This value could be overwritten by
        other UEs with the lastest value. But it is not an issue
    */
    pNbrGnbCell->cacBackOffTime = endTimeTick;
    VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[NRDC][CAC Backoff] cell(nci:%u) enters back-off state(start:%ld, end:%ld) for %u sec\n",
        pNbrGnbCell->cellId, startTimeTick, endTimeTick, durTimeVal);
}

/**
 * @brief   This function is used to check if the CAC backoff time for a neighbor gNB cell is effective.
 * @param   ptCi: call information / callInfo_type
 * @param   pNbrGnbCell: neighbor gNB cell information / nbrGnbCellInfo_type
 * @return  true: effective, false: not effective
 */
bool FnVCCB_IsCacBackOffTimeEffective(callInfo_type *ptCi, nbrGnbCellInfo_type *pNbrGnbCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pNbrGnbCell, false);
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, false);

    if (!IS_CAC_BACKOFF_ON_YANG(ptCi))
    {
        return false;
    }

#define INVALIED_BACKOFF_TIME 0

    if (INVALIED_BACKOFF_TIME == pNbrGnbCell->cacBackOffTime)
    {
        return false;
    }

    struct timespec currentTime = tickGetMono();
    long currentTimeTick = static_cast<long>(currentTime.tv_sec * 1000 + currentTime.tv_nsec / 1000000);

    if (currentTimeTick <= pNbrGnbCell->cacBackOffTime)
    {
        // Exception: invalid backoff time
        if (static_cast<long>(MAX_CAC_BACKOFF_TIME_VAL_SEC) < (pNbrGnbCell->cacBackOffTime - currentTimeTick) / 1000)
        {
            pNbrGnbCell->cacBackOffTime = INVALIED_BACKOFF_TIME;
            return false;
        }

        VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[NRDC][CAC Backoff] CAC Backoff Time is not expired(curr:%ld, expire:%ld)\n", currentTimeTick,
            pNbrGnbCell->cacBackOffTime);
        return true;
    }

    // The current time is past the backoff period, so the backoff time is not effective
    VCCB_PRINT_CALL_NRDC_BASIC(
        ptCi, "[NRDC][CAC Backoff] CAC Backoff Time is expired(curr:%ld, end:%ld)\n", currentTimeTick, pNbrGnbCell->cacBackOffTime);
    return false;
}

/**
 * @brief   This function checks whether the CAC backoff condition is met or not.
 *
 * @param   ptCi: Pointer to call information
 * @param   pNbrGnbCell: Pointer to neighbor gNB cell information
 * @return  true: CAC backoff condition is met
 *          false: CAC backoff condition is not met
 */
int FnVCCB_CheckCacBackOffCondition(callInfo_type *ptCi, nbrGnbCellInfo_type **pNbrGnbCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    if (!IS_CAC_BACKOFF_ON_YANG(ptCi))
    {
        return false;
    }

    uint16_t nbrIdx = ptCi->mrdcInfo.SNInfo[SRC_SN].nbrIdx;
    if (MAX_NBR_PER_CELL <= nbrIdx)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid nbrIdx(%u) in %s!!\n", nbrIdx, __func__);
        return false;
    }

    SNInfo_type &snInfo = ptCi->mrdcInfo.SNInfo[SRC_SN];

    if ((GOOD != getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &(*pNbrGnbCell))) || (NULL == (*pNbrGnbCell)))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "getNbrGnbCellByCellNbrIdx(cellNum:%u, nbrIdx:%u) in %s ERROR!!\n",
            ptCi->servCellNum, nbrIdx, __func__);
        return false;
    }

    uint64_t nci = VLIB_GnbIdCellId2NrCellId(&(*pNbrGnbCell)->globalGnbId.gnbId, (*pNbrGnbCell)->cellId);
    if (nci != snInfo.psCell.locationInfo.nrCgi.ci ||
        (*pNbrGnbCell)->globalGnbId.plmn.longId != snInfo.psCell.locationInfo.nrCgi.plmn.longId)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "[NRDC][CAC Backoff] Mismatched nrCgi!! nbr(plmnLongId:%u,nci:%lu), snInfo(plmnLingId:%u, nci:%lu) in %s!!\n",
            (*pNbrGnbCell)->globalGnbId.plmn.longId, nci, snInfo.psCell.locationInfo.nrCgi.plmn.longId,
            snInfo.psCell.locationInfo.nrCgi.ci, __func__);
        return false;
    }
    return true;
}

/**
 * @brief   This function processes the NRDC Add CAC reject due to cell backoff.
 *
 * @param   ptCi: Pointer to call information
 */
void FnVCCB_ProcNrdcAddCacRejectforCellBackOff(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnAdd, MRDC_PROC_PURPOSE_BearerTypeChange))
    {
        return;
    }

    nbrGnbCellInfo_type *pNbrGnbCell = NULL;
    if (true == FnVCCB_CheckCacBackOffCondition(ptCi, &pNbrGnbCell))
    {
        FnVCCB_SetCacBackOffTime(ptCi, pNbrGnbCell);
    }
    else
    {
        FnVCCB_ProcNrdcAddCacReject(ptCi);
    }
}

/**
 * @brief   This function checks whether the PSCell is the same as the NR CGI received from the MN during the NR-DC SN
 * Addition with MN-initiated SN change procedure.
 *
 * @param   ptCi : call information / callInfo_type
 * @return  true if the PSCell is the same as the NR CGI received from the MN, false otherwise
 */
bool FnVCCB_IsPSCellSameAsMnSelection(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    const cgi_type &nrCgiReceivedFromMn = ptCi->mrdcInfo.nrCgiReceivedFromMn;

    if (!IS_NRDC_SN(ptCi))
    {
        return false;
    }

    if (!FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnAdd, MRDC_PROC_PURPOSE_BearerTypeChange))
    {
        return false;
    }

    if (NO_RECEIVE == nrCgiReceivedFromMn.plmn.longId || MULTI_RECEIVE == nrCgiReceivedFromMn.plmn.longId)
    {
        return false;
    }

    VccbGnbInfo_type *pGnb = FnVCCB_GetGnbInfo(ptCi->gnbNum);
    VALID_E_POINT_CHECK_RET_VAL(pGnb, false);

    uint32_t gnbIdFromNCI = VLIB_NrCellId2GnbId(pGnb->globalGnbId.gnbId.idLength, nrCgiReceivedFromMn.ci);
    if (pGnb->globalGnbId.gnbId.id != gnbIdFromNCI)
    {
        return false;
    }

    uint16_t cellIdentityFromNCI = VLIB_NrCellId2CellId(pGnb->globalGnbId.gnbId.idLength, nrCgiReceivedFromMn.ci);
    uint16_t gnbNumFromNCI = MAX_GNB_PER_SYS;

    if (GOOD != VLIB_GetGnbNumFromId(&gnbNumFromNCI, gnbIdFromNCI))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid gnbNumFromNCI(%u) in %s!\n", gnbNumFromNCI, __func__);
        return false;
    }

    uint16_t cellNumFromNCI = FnVCCB_GetCellNum(gnbNumFromNCI, cellIdentityFromNCI);
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(cellNumFromNCI, false);

    VccbCellInfo_type *pCellFromNCI = FnVCCB_GetCellInfo(cellNumFromNCI);
    VALID_E_POINT_CHECK_RET_VAL(pCellFromNCI, false);

    VccbCellInfo_type *pCell = FnVCCB_GetCellInfo(ptCi->servCellNum);
    VALID_E_POINT_CHECK_RET_VAL(pCell, false);

    // Check if the PSCell is in the same gNB as the NCI cell that MN Selected
    if (pCell->endPointF1Index < MAX_GNB_DU_PER_GNB_CU_CP && pCell->endPointF1Index == pCellFromNCI->endPointF1Index)
    {
        return true;
    }

    return false;
}

/**
 * @brief   This function stores the NR CGI received from the MN for the PSCell selected during the NR-DC SN Addition
 * procedure.
 *
 * @param   ptCi : call information / callInfo_type
 * @param   cgiInfo : CGI information / CGI_Info_type
 */
void FnVCCB_StoreNrcgiforMnSelectedPSCell(callInfo_type *ptCi, const CGI_Info_type &cgiInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!IS_NRDC_SN(ptCi))
    {
        return;
    }

    if (MULTI_RECEIVE == ptCi->mrdcInfo.nrCgiReceivedFromMn.plmn.longId)
    {
        return;
    }

    if (FALSE == cgiInfo.plmn_IdentityInfoList_Flag || cgiInfo.plmn_IdentityInfoList.nrofPLMN_IdentityInfo == 0 ||
        cgiInfo.plmn_IdentityInfoList.nrofPLMN_IdentityInfo == 0)
    {
        return;
    }

    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    uint8_t gnbIdLen = pGnb->globalGnbId.gnbId.idLength;
    if (gnbIdLen != cgiInfo.plmn_IdentityInfoList.plmn_IdentityInfo[0].gnbIdLengthFlag)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[WARN] gnbIdLength <received(%u) vs cfg(%u)> in %s\n",
            cgiInfo.plmn_IdentityInfoList.plmn_IdentityInfo[0].gnbIdLength, pGnb->globalGnbId.gnbId.idLength, __func__);
    }

    const uint64_t nrCellId = cgiInfo.plmn_IdentityInfoList.plmn_IdentityInfo[0].cellIdentity;
    const uint32_t gnbId = VLIB_NrCellId2GnbId(gnbIdLen, nrCellId);
    if (gnbId != pGnb->globalGnbId.gnbId.id)
    {
        return;
    }

    if (NO_RECEIVE == ptCi->mrdcInfo.nrCgiReceivedFromMn.plmn.longId)
    {
        ptCi->mrdcInfo.nrCgiReceivedFromMn.plmn.longId =
            cgiInfo.plmn_IdentityInfoList.plmn_IdentityInfo[0].plmn_IdentityList.plmn_Identity[0].longId;
        ptCi->mrdcInfo.nrCgiReceivedFromMn.ci = nrCellId;
        VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[NRDC][CAC BackOff] nrCgiReceivedFromMn(nrCellId : %lu, longId:%u)\n",
            ptCi->mrdcInfo.nrCgiReceivedFromMn.ci, ptCi->mrdcInfo.nrCgiReceivedFromMn.plmn.longId);
    }
    else
    {
        ptCi->mrdcInfo.nrCgiReceivedFromMn.plmn.longId = MULTI_RECEIVE;
        VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[NRDC][CAC BackOff] nrCgiReceivedFromMn MULTI_RECEIVED!\n");
    }
}

void FnVCCB_UpdateReqBearerForSnTermPerPDUSess(callInfo_type *ptCi, callPDUSessInfo_type &rPduSess,  std::vector<uint8_t> &vDrbListTobeSnTermSplit)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    for (uint8_t drbIndex = 0; drbIndex < MAX_DRB_PER_PDU_SESS; drbIndex++)
    {
        uint16_t drbIdxInCall = rPduSess.drbIndex[drbIndex];
        if (drbIdxInCall >= MAX_DRB_PER_SA_CALL) continue;

        callDRBInfo_type &rDrb = ptCi->drb[drbIdxInCall];
        if (rDrb.usage != CI_use) continue;
        if (!rDrb.selectedBearerTypeFrozenFlag) continue;

        if (FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnAdd, MRDC_PROC_PURPOSE_BearerTypeChange) ||
                FnVCCB_IsMrdcProcedure(ptCi, MRDC_PROC_CODE_SnMod, MRDC_PROC_PURPOSE_BearerTypeChange))
        {
            if (rDrb.bearerType.val != MN_Term_MCG_Bearer || rDrb.reqBearerType.val != SN_Term_SPLIT_Bearer)
            {
                continue;
            }
        }
        else
        { // inter-MN Mobility case
            if (rDrb.bearerType.val != SN_Term_SPLIT_Bearer || rDrb.reqBearerType.val != SN_Term_SPLIT_Bearer)
            {
                continue;
            }
        }

        auto entry = std::find(vDrbListTobeSnTermSplit.begin(), vDrbListTobeSnTermSplit.end(), rDrb.dRBId);
        if (entry == vDrbListTobeSnTermSplit.end())
        {
            rDrb.reqBearerType.val = SN_Term_SCG_Bearer;
            VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[NRDC] dRBId(%u)'s reqBearerType was changed(SnTermSplit->SnTermScg)!\n", rDrb.dRBId);
        }
        else
        {
            vDrbListTobeSnTermSplit.erase(entry);
        }
    }
}

static void IncrementNrdcCslCounter(uint16_t &counter)
{
    const uint16_t NRDC_CSL_MAX_VALUE = 65534;

    if (counter == GET_CSL_INIT_VALUE(counter))
    {
        counter = 1;
    }
    else if (counter < NRDC_CSL_MAX_VALUE)
    {
        counter++;
    }
}

void FnVCCB_CollectCslNrdcAddVonr(callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;

    auto &rConnectInfo = rCall.cslInfo.connectInfo;

    if (rConnectInfo.nrdcStatus != GET_CSL_INIT_VALUE(rConnectInfo.nrdcStatus))
    {
        return;
    }

    if (FnVCCB_ExistIdleVoNRQoSFlow(rCall))
    {
        IncrementNrdcCslCounter(rConnectInfo.nrdcAddVonr);
    }
}

void FnVCCB_CollectCslNrdcRelVonr(callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;

    const bool isHoOrReestablishState =
        (rCall.mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue || rCall.stateCmd == RrcReestablish_cmd);

    // HO and RRE are not within the 26A scope.
    if (isHoOrReestablishState || IS_IN_CALL_RELEASE_PROCEDURE(&rCall))
    {
        return;
    }

    auto &rConnectInfo = rCall.cslInfo.connectInfo;

    if (rConnectInfo.nrdcStatus == GET_CSL_INIT_VALUE(rConnectInfo.nrdcStatus)) return;

    if (FnVCCB_ExistIdleVoNRQoSFlow(rCall))
    {
        IncrementNrdcCslCounter(rConnectInfo.nrdcRelVonr);
    }
}

void FnVCCB_UpdateNrdcMnCsl(callInfo_type &rCall, enumNrdcCslUpdate_type updateType)
{
    AUTO_TRACE_FUNC;

    if (not IS_NRDC_MN(&rCall)) return;

    const char* updateTypeString = "UNKNOWN";

    switch (updateType)
    {
        case NRDC_CSL_UPDATE_ADD_INITIAL:
            updateTypeString = "ADD_INITIAL";
            FnVCCB_CollectCslNrdcAddVonr(rCall);
            rCall.cslInfo.connectInfo.nrdcStatus = VCCB_FLAG_ON;
            break;

        case NRDC_CSL_UPDATE_ADD_HO:
            updateTypeString = "ADD_HO";
            rCall.cslInfo.connectInfo.nrdcStatus = VCCB_FLAG_ON;
            break;

        case NRDC_CSL_UPDATE_REL:
            updateTypeString = "REL";
            FnVCCB_CollectCslNrdcRelVonr(rCall);
            if (not IS_IN_CALL_RELEASE_PROCEDURE(&rCall))
            {
                rCall.cslInfo.connectInfo.nrdcStatus = GET_CSL_INIT_VALUE(rCall.cslInfo.connectInfo.nrdcStatus);
            }
            break;

        default:
            VCCB_PRINT_CALL_ERROR(&rCall, 
                "Invalid NRDC CSL update type: %d\n", updateType);
            return;
    }

    VCCB_PRINT_CALL_NRDC_BASIC(&rCall, "[NRDC CSL][MN] %s - Status: %d, Add: %u, Rel: %u\n", updateTypeString,
        rCall.cslInfo.connectInfo.nrdcStatus, rCall.cslInfo.connectInfo.nrdcAddVonr,
        rCall.cslInfo.connectInfo.nrdcRelVonr);
}

void FnVCCB_UpdateNrdcSnCsl(callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;

    if (not IS_NRDC_SN(&rCall)) return;

    rCall.cslInfo.connectInfo.nrdcStatus = VCCB_FLAG_ON;

    VCCB_PRINT_CALL_NRDC_BASIC(&rCall, "[NRDC CSL][SN] Status: %d, Add: %u, Rel: %u\n",
        rCall.cslInfo.connectInfo.nrdcStatus, rCall.cslInfo.connectInfo.nrdcAddVonr,
        rCall.cslInfo.connectInfo.nrdcRelVonr);
}

uint16_t FnVCCB_GetNumofInstalledMeasCfgFreqForNrdcAdd(callInfo_type &rCall)
{
    std::set<uint32_t> ssbFreqSet;
    for (const auto &measObj : rCall.measurementsConfiguration.measurementObjects.installedItems)
    {
        if (measObj.usage != CI_use || measObj.conf.ratType != measRatNr)
        {
            continue;
        }
        
        auto ssbFreq = VCCB_GetMeasObjectSsbFreq(measObj);
        if (not IS_FR2(ssbFreq)) continue;
        if (ssbFreq != 0)
        {
            ssbFreqSet.insert(ssbFreq);
        }
    }
    
    uint8_t numFreq = 0;
    for (uint32_t ssbFreq : ssbFreqSet)
    {
        auto measIdx = VCCB_FindInstalledMeasId_ByFreqReportPurpose(&rCall, ssbFreq, measReport_A4, a4Purpose_NrdcAddition);
        if ( measIdx >= 0 && measIdx < MAX_NR_OF_MEAS_ID)
        {
            numFreq++;
        }
    }
    
    return numFreq;
}
// end
