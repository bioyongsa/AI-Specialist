/****************************************************************
 * System      : 5G gNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatUlPathControlNRDC.c
 * Description : This file contains functions related to management of NRDC UL path.
 * Dept.       : 5G Call SW Lab.
 * Created     : 2022.06.10
 ****************************************************************/

#include "FeatUlPathControlNRDC.h"
#include "FeatMeasurements.hpp"
#include "FeatCommon.h"
#include "FeatCallInfo.h"
#include "FeatRbInfo.h"

#include "ComInclude.h"
#include "ComLibUtility.h"
#include "CdbUtil.h"

#include "MsgE1apSend.h"
#include "MsgXnapSend.h"
#include "MsgNrRrcSend.h"

#include "StateCommon.h"

/****************************************************************************
 * @brief     Get UL primary path mode
 *
 * @param[in] ptCi    : pointer to Call info
 * @param[in] cellNum : index of relevant Cell info
 * @return              UL prmiary path mode
 ****************************************************************************/
enumUlPrimaryPathMode VCCM_GetUlPrimaryPathMode(const callInfo_type *const ptCi, const uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, initial_Undetermined);
    VALID_E_POINT_CHECK_RET_VAL(CELLINFO, initial_Undetermined);
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, initial_Undetermined);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, initial_Undetermined);

    if (FnVCCB_IsNrDcUlPrimaryPathModeInitProbability(cellNum))
    {
        unsigned int randValue = FnVCCB_GetRandomValue(__func__, ptCi->gnbNum, MAX_SCG_PROBABILITYT_VALUE);
        VCCB_CHECK_E_RANGE_AND_VAL(randValue, MAX_SCG_PROBABILITYT_VALUE, initial_Undetermined);

        return (FnVCCB_GetNrdcScgProbability(cellNum) >= randValue) ? initial_SCG : initial_MCG;
    }

    return (FnVCCB_IsNrDcUlPrimaryPathModeInitScg(cellNum)) ? initial_SCG : initial_MCG;
}

/****************************************************************************
 * @brief           Check conditions if DataStall configuration is allowed
 *
 * @param[in] ptCi                          : pointer to Call info
 * @return          status                  : TRUE/FALSE
 ****************************************************************************/
bool VCCM_NrdcIsDataStallConfigurationAllowed(callInfo_type * const ptCi)
{
    return (Idle_cmd == ptCi->stateCmd && (STATE_II == ptCi->state || STATE_Conn == ptCi->state)) ||
           (MrdcXnSNAdd_cmd == ptCi->stateCmd && STATE_II == ptCi->state) ||
           (MrdcE1ScgAdd_cmd == ptCi->stateCmd && STATE_Conn == ptCi->state) ||
           ((IntraRatHO_cmd == ptCi->stateCmd || InterRatHO_cmd == ptCi->stateCmd) && (STATE_II == ptCi->state || STATE_SN_SCGResume_Init == ptCi->state)) ||
           (TRUE == VHCM_isSaHandoverUE(ptCi) && STATE_Conn == ptCi->state);
}

/****************************************************************************
 * @brief           Set Data Stall configuration for NR-DC
 *
 * @param[in,out]   ptCi                    : pointer to Call info
 * @param[in]       cellNum                 : index of relevant Cell info
 * @return          status                  : TRUE/FALSE
 ****************************************************************************/
uint8_t VCCM_NrdcSetDataStallConfiguration(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(CELLINFO);
    VCCB_CHECK_E_RANGE_AND_FALSE(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);

    uint8_t status = FALSE;
    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    // Block after Initial Addition
    if (!VCCM_NrdcIsDataStallConfigurationAllowed(ptCi))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "VCCM_NrdcSetDataStallConfiguration: Blocked\n");
        return status;
    }

    if (GNBINFO[ptCi->gnbNum].cfg.nrdc.ulPrimaryPathDataStallPreventionFlag &&
        NRUL_COV_OFF != pCell->nrdcNrUlCoverageMethod)
    {
        for (callDRBInfo_type &rDi: ptCi->drb)
        {
            rDi.ulPdcpPathPrev = rDi.ulPdcpPath;
            rDi.ulPdcpPath = UlPdcpPath_McgOnly;
            rDi.ulPrimaryPathMode = VCCM_GetUlPrimaryPathMode(ptCi, cellNum);
        }
        ptCi->ulPathControl.prev.nrUlCoverageState = ptCi->ulPathControl.curr.nrUlCoverageState;
        ptCi->ulPathControl.curr.nrUlCoverageState = OUT_NRDC_PSCELL_UL_COVERAGE_STATE;
        if (IS_NRDC_SN(ptCi))
        {
            ptCi->isDataStallPreventionTriggerReceived = UlPath_DataStall_WaitingForTrigger;
            if (NRUL_COV_A1_A2 == pCell->nrdcNrUlCoverageMethod)
            {
                VLIB_AttachTimer(&ptCi->f1AccessSuccessRachTimer, ptCi, timF1AccessSuccessRach_id);
            }
        }
        status = TRUE;
    }

    if (VCCB_FLAG_ON == DBG->flag.logUlPathControl)
    {     
        VCCB_PRINT_CALL_COMMENT(ptCi,
        "[VCCM_NrdcSetDataStallConfiguration] : UlPrimaryPathDataStallPreventionFlag: %u, nrdcNrUlCoverageMethod: %u\n", 
        GNBINFO[ptCi->gnbNum].cfg.nrdc.ulPrimaryPathDataStallPreventionFlag, pCell->nrdcNrUlCoverageMethod);
    }

    return status;
}

/****************************************************************************
 * @brief         Select bearer NRDC UL path value considering all relevant
 *                factors
 *
 * @param[in]     ptCi                : pointer to Call info
 * @param[in,out] ptDi                : pointer to DRB information
 * @param[in]     isIntraHoInProgress : flag indicating if intra HO is ongoing
 * @return        void
 ****************************************************************************/
void VCCM_SelectBearerUlPath_NRDC(
    callInfo_type *const ptCi, callDRBInfo_type *const ptDi, const bool isIntraHoInProgress)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptDi);

    ptDi->ulPdcpPathPrev = ptDi->ulPdcpPath;

    if (ptCi->ulPathControl.curr.nrUlCoverageState == OUT_NRDC_PSCELL_UL_COVERAGE_STATE)
    {
        ptDi->ulPdcpPath = UlPdcpPath_McgOnly;
        return;
    }

    uint16_t cellNum = ptCi->servCellNum;
    if (isIntraHoInProgress)
    {
        cellNum = ptCi->hoInfo.targetCellNum;
        VCCM_UpdateBearerUlDataSplitThresholdFr1Fr2(ptCi, ptDi);
    }

    ptDi->ulPrimaryPathMode = VCCM_GetUlPrimaryPathMode(ptCi, cellNum);

    if (UlPath_DataStall_WaitingForTrigger != ptCi->isDataStallPreventionTriggerReceived)
    {
        ptDi->ulPdcpPath = (ptDi->ulPrimaryPathMode == initial_SCG) ? UlPdcpPath_ScgShared : UlPdcpPath_McgShared;
    }

    if (FnVCCB_IsUlDataSplitThresholdFr1Fr2Infinite(ptDi) || !FnVCCB_GetUeCapaSplitDRB_withUL_Both_MCG_SCG_NRDC(ptCi))
    {
        if (ptDi->ulPdcpPath == UlPdcpPath_ScgShared)
        {
            ptDi->ulPdcpPath = UlPdcpPath_ScgOnly;
        }
        else if (ptDi->ulPdcpPath == UlPdcpPath_McgShared)
        {
            ptDi->ulPdcpPath = UlPdcpPath_McgOnly;
        }
    }

    if (VCCB_FLAG_ON == DBG->flag.logUlPathControl)
    {     
        VCCB_PRINT_CALL_COMMENT(ptCi,
        "[VCCM_SelectBearerUlPath_NRDC] : isUlDataSplitThresholdFr1Fr2Infinite: %d, GetUeCapaSplitDRB: %u\n", 
        FnVCCB_IsUlDataSplitThresholdFr1Fr2Infinite(ptDi), FnVCCB_GetUeCapaSplitDRB_withUL_Both_MCG_SCG_NRDC(ptCi));
    }
}

/****************************************************************************
 * @brief         Update bearer UL data split threshold FR1-FR2 with value
 *                from the target cell during intra HO
 *
 * @param[in,out] ptCi : pointer to Call Info information
 * @param[in,out] ptDi : pointer to DRB information
 * @return        void
 ****************************************************************************/
void VCCM_UpdateBearerUlDataSplitThresholdFr1Fr2(callInfo_type *const ptCi, callDRBInfo_type *const ptDi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptDi);
    uint8_t fiveQi;
    qosFlowInfo_type *ptQi = NULL;
    uint16_t gnbNum;

    auto setUlDataSplitThresholdFr1Fr2 = [&ptCi, &ptDi](pdcpInfo5qi_type *_pPdcpInfo, uint8_t _fiveQi)
    {
        if (_pPdcpInfo == NULL)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, " PdcpIOnfo for 5QI %d is NULL \n", _fiveQi);
            return;
        }

        ptDi->rbInfo.pdcpInfo.ulDataSplitThresholdFr1Fr2 = _pPdcpInfo->ulDataSplitThresholdFr1Fr2;
    };

    if (ERROR == VLIB_SelectRepresentativeQoSFlowInDRB(ptCi, ptDi) || (ptDi->drbQosIdxInCall >= MAX_QOS_FLOW_PER_CALL))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, " Cannot find representative QoS Flow for drbId=%d \n", ptDi->dRBId);
        return;
    }

    ptQi = &ptCi->qosFlow[ptDi->drbQosIdxInCall];

    if (ptQi->usage != CI_use)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, " QoS Flow QoSId=%d is not used \n", ptDi->drbQosIdxInCall);
        return;
    }

    VLIB_getFiveQi(ptQi, &fiveQi);
    gnbNum = ptCi->gnbNum;
    if (gnbNum >= MAX_GNB_PER_SYS)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, " Invalid gnbNum %d \n", gnbNum);
        return;
    }

    pdcpInfo5qi_type *pPdcpInfo = FnVCCB_GetPdcpInfo5qi(ptCi->hoInfo.targetCellNum, gnbNum, fiveQi);
    setUlDataSplitThresholdFr1Fr2(pPdcpInfo, fiveQi);
}

/****************************************************************************
 * @brief       Determine if any MN terminated split bearer
 *              and any SN terminated bearer exist in the current call
 *
 * @param[in]   ptCi                    : pointer to Call info
 * @param[out]  pExistMnTermSplitBearer : pointer to flag defining if
 *                                        any MN terminated split bearer exist
 * @param[out]  pExistSnTermSplitBearer : pointer to flag defining if
 *                                        any SN terminated split bearer exist
 * @return      void
 ****************************************************************************/
void VCCM_InspectSplitBearers(
    const callInfo_type *const ptCi, bool *const pExistMnTermSplitBearer, bool *const pExistSnTermSplitBearer)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pExistMnTermSplitBearer);
    VALID_E_POINT_CHECK_VOID(pExistSnTermSplitBearer);

    size_t drbIdx = 0;
    for (; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        if (ptCi->drb[drbIdx].usage != CI_use) continue;
        if (!ptCi->drb[drbIdx].selectedBearerTypeFrozenFlag) continue;

        switch (ptCi->drb[drbIdx].bearerType.val)
        {
            break;
            case MN_Term_MCG_Bearer:
                *pExistMnTermSplitBearer |=
                    (IS_NRDC_MN(ptCi) && (ptCi->drb[drbIdx].reqBearerType.val == MN_Term_SPLIT_Bearer));
                *pExistSnTermSplitBearer |= 
                    (IS_NRDC_MN(ptCi) && (ptCi->drb[drbIdx].reqBearerType.val == SN_Term_SPLIT_Bearer));

                break;
            case MN_Term_SPLIT_Bearer:
                *pExistMnTermSplitBearer |= IS_NRDC(ptCi);

                break;
            case SN_Term_SPLIT_Bearer:
                *pExistSnTermSplitBearer |= IS_NRDC(ptCi);

                break;
            default:
                continue;
        }
    }
}

/****************************************************************************
 * @brief         Set the flag that enables/disables UL path switching based
 *                on current operation mode and existing split bearers
 *
 * @param[in,out] ptCi : pointer to Call info
 * @return        void
 ****************************************************************************/
void VCCM_UpdateUlPathSwitchingAbility(callInfo_type *const ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(CELLINFO);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    if (NRUL_COV_MAC_DETECTION != CELLINFO[ptCi->servCellNum].nrdcNrUlCoverageMethod)
    {
        return;
    }

    bool existMnTermSplitBearer = false;
    bool existSnTermSplitBearer = false;

    VCCM_InspectSplitBearers(ptCi, &existMnTermSplitBearer, &existSnTermSplitBearer);

    bool wasUlPathSwitchEnabled = ptCi->isUlPathSwitchEnabled;
    ptCi->isUlPathSwitchEnabled = !(existMnTermSplitBearer == existSnTermSplitBearer);

    if (ptCi->isUlPathSwitchEnabled && !wasUlPathSwitchEnabled)
    {
        VCCM_SelectInitialUlPath_NRDC(ptCi);
    }

    if (VCCB_FLAG_ON == DBG->flag.logUlPathControl)
    {     
        VCCB_PRINT_CALL_COMMENT(ptCi,
        "[VCCM_UpdateUlPathSwitchingAbility] : isUlPathSwitchEnabled: %d, wasUlPathSwitchEnabled: %d\n", 
        ptCi->isUlPathSwitchEnabled, wasUlPathSwitchEnabled);
    }
}

/****************************************************************************
 * @brief         Determine if bearer's NRDC UL path value need to be updated
 *                considering all relevant factors
 *
 * @param[in,out] ptDi                : pointer to DRB information
 * @param[in]     isIntraHoInProgress : flag indicating if intra HO is ongoing
 * @param[in]     isNrdcMn            : flag indicating if current gNB is MN
 * @param[in]     isNrdcSn            : flag indicating if current gNB is SN
 * @return        bool                : flag indicating if bearers UL path
 *                                      needs to be updated
 ****************************************************************************/
bool VCCM_IsBearerUlPathUpdateNeeded(
    const callDRBInfo_type *const ptDi, const bool isIntraHoInProgress, const bool isNrdcMn, const bool isNrdcSn)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    if ((ptDi->usage != CI_use) || (!ptDi->selectedBearerTypeFrozenFlag) ||
        (isIntraHoInProgress && (ptDi->ulPdcpPath == UlPdcpPath_McgOnly)))
    {
        return false;
    }

    bool updateNeeded = false;
    switch (ptDi->bearerType.val)
    {
        break;
        case MN_Term_MCG_Bearer:
            updateNeeded = (isNrdcMn && ptDi->reqBearerType.val == MN_Term_SPLIT_Bearer);

            break;
        case MN_Term_SPLIT_Bearer:
            updateNeeded = isNrdcMn;

            break;
        case SN_Term_SPLIT_Bearer:
            updateNeeded = isNrdcSn;

            break;
        default:
            updateNeeded = false;
    }

    return updateNeeded;
}
/****************************************************************************
 * @brief         Select NRDC UL path value for all relevant bearers
 *
 * @param[in,out] ptCi                : pointer to UE Context
 * @param[in]     isIntraHoInProgress : flag indicating if intra HO is ongoing
 * @return        void
 ****************************************************************************/
void VCCM_SelectUlPath_NRDC(callInfo_type *ptCi, const bool isIntraHoInProgress)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    VCCM_UpdateUlPathSwitchingAbility(ptCi);
    if (!ptCi->isUlPathSwitchEnabled)
    {
        return;
    }

    uint16_t cellNum = ptCi->servCellNum;
    if (isIntraHoInProgress)
    {
        cellNum = ptCi->hoInfo.targetCellNum;
    }

    if (FALSE != VCCM_NrdcSetDataStallConfiguration(ptCi, cellNum))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
        "[VCCM_SelectUlPath_NRDC] : Data Stall Prevention triggered, setting ulPath to MCG Only!\n");
    }

    size_t drbIdx = 0;
    for (; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        callDRBInfo_type *const ptDi = &ptCi->drb[drbIdx];
        if (ptDi->usage != CI_use) continue;

        if (VCCM_IsBearerUlPathUpdateNeeded(ptDi, isIntraHoInProgress, IS_NRDC_MN(ptCi), IS_NRDC_SN(ptCi)))
        {
            VCCM_SelectBearerUlPath_NRDC(ptCi, ptDi, isIntraHoInProgress);

            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[Select bearer NRDC UL path] Bearer ID=%u configured with UL path %u. "
                "intra HO is%s in progress.\n",
                ptDi->dRBId, ptDi->ulPdcpPath, isIntraHoInProgress ? "" : "not");
        }
    }
}

/****************************************************************************
 * @brief           Select initial NRDC UL path value
 *
 * @param[in,out]   ptCi                    : pointer to UE Context
 * @return          status                  : void
 ****************************************************************************/
void VCCM_SelectInitialUlPath_NRDC(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    ptCi->ulPathControl.curr.ulPdcpPath = UlPdcpPath_Init;
    ptCi->ulPathControl.curr.ulPrimaryPathMode = initial_Undetermined;

    ptCi->isUlPathSwitchEnabled = true;
    ptCi->ulPathControl.curr.nrUlCoverageState = IN_NRDC_PSCELL_UL_COVERAGE_STATE;

    VCCM_SelectUlPath_NRDC(ptCi, false);
}

int16_t VCCB_NrdcUlPathControl_SendConfigurationToCU(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

    VLIB_SetCurStateAll(ptCi, STATE_SNUPPS_E1DrbMod);
    VLIB_AttachTimer(&ptCi->callMultiTimer.e1, ptCi, timE1_BearerContextModification_id);

    return GOOD;
}

int16_t VCCB_NrdcUlPathControl_SendConfigurationToMN(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = VCCB_PrepareNewMeasConfig(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");

    ptCi->cause.xnCause = CauseXnapRadioNetworkLayerRrmPurpose;
    status = FnVCCB_SendXNMessage(XN_SNodeModificationRequired_id, ptCi, nullptr, nullptr);
    if (GOOD != status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendXNMessage(XN_SNodeModificationRequired_id) ERROR!\n");
        return ERROR;
    }

    VLIB_AttachTimer(&ptCi->callMultiTimer.xn, ptCi, timXN_DcOverall_id);
    VLIB_SetCurStateAll(ptCi, STATE_SNUPPS_XnModRequired);

    return GOOD;
}

int16_t VCCB_NrdcUlPathControl_SendConfigurationToUE(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer(ptCi, FALSE, FALSE, ID_SRB3);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer ERROR !!\n");

    VLIB_SetCurStateAll(ptCi, STATE_SN_SNE1UlPath_RRCRecCmpl);
    VLIB_AttachTimer(&ptCi->timer, ptCi, timNRRRC_RRCReconfig_id);

    return GOOD;
}

bool VCCB_NrdcUlPathControl_IsPathChangeOngoing(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    switch (ptCi->stateCmd)
    {
        case E1UlPathSwitch_cmd:
        case MrUlPathSwitch_cmd:
            return true;

        default:
            return false;
    }
}

void VCCB_NrdcUlPathControl_CollectServiceTypePathChangeStats(callInfo_type *ptCi, uint8_t ulPath)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (IS_SUPPORT_CollectNrdcUlPathChangeServiceTypeStats(ptCi))
    {
        std::set<uint32_t> svcTypeStatsList;
        MACRO_GET_CALL_SERVICE_TYPE(ptCi, svcTypeStatsList);
        for (const auto &svcTypeStats : svcTypeStatsList)
        {
            MACRO_STAT_PMCC(STAT_NRDC_UL_PATH_SWITCH_SERVICE_TYPE, ulPath, ptCi, static_cast<uint64_t>(svcTypeStats), 0, 0, 0, 0);
        }
    }
    
}

void VCCB_NrdcUlPathControl_CollectPathChangeStats(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!(FOO.VF_UlPathControlInNRDC_Stat && 
          VCCB_NrdcUlPathControl_IsPathChangeOngoing(ptCi)))
    {
        return;
    }

    size_t drbIdx = 0;
    for (; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        callDRBInfo_type *const ptDi = &ptCi->drb[drbIdx];

        if (ptDi->usage != CI_use) continue;
        if (ptDi->ulPdcpPathPrev == ptDi->ulPdcpPath) continue;

        if (ptDi->ulPdcpPathPrev == UlPdcpPath_McgOnly)
        {
            if (ptDi->ulPdcpPath == UlPdcpPath_McgShared)
            {
                MACRO_STAT_PMCC(STAT_NRDC_UL_PATH_SWITCH, NrdcUlPathSwitch_CovIn_McgToMcg, ptCi, 0, 0, 0, 0, 0);
                VCCB_NrdcUlPathControl_CollectServiceTypePathChangeStats(ptCi, NrdcUlPathSwitch_CovIn_McgToMcg );
            }
            else
            {
                MACRO_STAT_PMCC(STAT_NRDC_UL_PATH_SWITCH, NrdcUlPathSwitch_CovIn_McgToScg, ptCi, 0, 0, 0, 0, 0);
                VCCB_NrdcUlPathControl_CollectServiceTypePathChangeStats(ptCi, NrdcUlPathSwitch_CovIn_McgToScg );
            }
        }
        else if (ptDi->ulPdcpPathPrev == UlPdcpPath_McgShared)
        {
            MACRO_STAT_PMCC(STAT_NRDC_UL_PATH_SWITCH, NrdcUlPathSwitch_CovOut_McgToMcg, ptCi, 0, 0, 0, 0, 0);
            VCCB_NrdcUlPathControl_CollectServiceTypePathChangeStats(ptCi, NrdcUlPathSwitch_CovOut_McgToMcg );
        }
        else
        {
            MACRO_STAT_PMCC(STAT_NRDC_UL_PATH_SWITCH, NrdcUlPathSwitch_CovOut_ScgToMcg, ptCi, 0, 0, 0, 0, 0);
            VCCB_NrdcUlPathControl_CollectServiceTypePathChangeStats(ptCi, NrdcUlPathSwitch_CovOut_ScgToMcg );
        }
    }
}

