#include "FeatMrdcApi.h"
#include "ComInline.h"
#include "ComGlobalData.h"
#include "ComAutoNtrace.hpp"
#include "FeatCommon.h"

/********************************************************************************************************************************************
 0. COMMON API
****************************************************************************/

/****************************************************************************
 * @brief           This function is used to determine whether the DRB state is serviceable.
 *
 * @param[in]       ptDi : call DRB information / callDRBInfo_type
 * @return          true or false / bool
 ****************************************************************************/
VCCB_STATIC bool FnVCCB_ValidationCheck_ForDRB(const callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    if (ptDi->usage != CI_use)
    {
        return false;
    }

    switch (ptDi->drbStatus)
    {
        case S_Release:
        case S_FailToSetup:
        case S_RelToModify:
            return false;

        default:
            return true;
    }
}

nrdcBearer_type FnVCCB_GetNrdcBearerTypePerBearerTag(const callInfo_type *ptCi, const callDRBInfo_type *ptDi, enumDrbBearerTag_type tag)
{
    nrdcBearer_type bearerType = {TermPoint_End, CellGroup_End};

    VALID_E_POINT_CHECK_RET_VAL(ptCi, bearerType);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, bearerType);

    switch (tag)
    {
        case current_bearerType:
            bearerType = ptDi->bearerType;
            break;

        case request_bearerType:
            bearerType = ptDi->reqBearerType;
            break;

        case select_bearerType:
            bearerType = ptDi->selectedBearerType;
            break;

        default:
            break;
    }

    return bearerType;
}
/****************************************************************************
 * @brief           This function is provided for the purpose of checking the DRB condition for all DRBs set up in the
 *UE.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       isCheckFunc : a pointer to the function to check. / FP_IsCheckFunc
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @param[in]       isDrbStatus : A flag indicating whether the DRB status needs to be checked. / bool
 * @return          true or false / bool
 ****************************************************************************/
VCCB_STATIC bool FnVCCB_IsAnyBearerType_Common_PerUE(
    callInfo_type *ptCi, FP_IsCheckFunc isCheckFunc, enumDrbBearerTag_type tag, bool isDrbStatus)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(isCheckFunc, false);

    callDRBInfo_type *ptDi;
    uint8_t dIdx = 0;

    for (dIdx = 0; dIdx < MAX_DRB_PER_SA_CALL; dIdx++)
    {
        ptDi = &ptCi->drb[dIdx];

        if (ptDi->usage != CI_use) continue;

        if (isDrbStatus == true)
        {
            if (FnVCCB_ValidationCheck_ForDRB(ptDi) == false) continue;
        }

        if (isCheckFunc(ptCi, ptDi, tag) == true)
        {
            return true;
        }
    }

    return false;
}

/****************************************************************************
 * @brief           This function is provided for the purpose of checking the DRB condition for all DRBs set up in the
 *PDU.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       ptPi : pdu information / callPDUSessInfo_type
 * @param[in]       isCheckFunc : a pointer to the function to check. / FP_IsCheckFunc
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @param[in]       isDrbStatus : A flag indicating whether the DRB status needs to be checked. / bool
 * @return          true or false / bool
 ****************************************************************************/
VCCB_STATIC bool FnVCCB_IsAnyBearerType_Common_PerPDU(const callInfo_type *ptCi, const callPDUSessInfo_type *ptPi,
    FP_IsCheckFunc isCheckFunc, enumDrbBearerTag_type tag, bool isDrbStatus)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptPi, false);
    VALID_E_POINT_CHECK_RET_VAL(isCheckFunc, false);

    const callDRBInfo_type *ptDi;
    uint16_t drbIdxInPdu;
    uint16_t drbIdxInCall;

    for (drbIdxInPdu = 0; drbIdxInPdu < MAX_DRB_PER_PDU_SESS; drbIdxInPdu++)
    {
        drbIdxInCall = ptPi->drbIndex[drbIdxInPdu];

        if (drbIdxInCall >= MAX_DRB_PER_SA_CALL) continue;

        ptDi = &ptCi->drb[drbIdxInCall];

        if (ptDi->usage != CI_use) continue;

        if (isDrbStatus == true)
        {
            if (FnVCCB_ValidationCheck_ForDRB(ptDi) == false) continue;
        }

        if (isCheckFunc(ptCi, ptDi, tag) == true)
        {
            return true;
        }
    }

    return false;
}

/****************************************************************************
 * @brief           This function provides the function to bring the DRB type as a common name without distinction to
 *MN/SN.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       ptDi : call DRB information / callDRBInfo_type
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @return          Current DRB status / enumMrdcBearerType
 ****************************************************************************/
uint8_t FnVCCB_getSaDrbBearerType(const callInfo_type *ptCi, const callDRBInfo_type *ptDi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, INIT_BEARER_TYPE);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, INIT_BEARER_TYPE);

    nrdcBearer_type bearerType = {TermPoint_End, CellGroup_End};

    switch (tag)
    {
        case current_bearerType:
            bearerType = ptDi->bearerType;
            break;

        case request_bearerType:
            bearerType = ptDi->reqBearerType;
            break;

        case select_bearerType:
            bearerType = ptDi->selectedBearerType;
            break;

        default:
            bearerType.val = INIT_BEARER_TYPE;
    }

    VCCB_PRINT_COMMENT("tag(%d) isNrdcSn(%d) bearerType(termPoint:%u, cellGroup:%u)\n", tag, IS_NRDC_SN(ptCi), bearerType.termPoint, bearerType.cellGroup);

    return bearerType.val; 
}


/****************************************************************************
 * @brief           This function provides to convert and show the bearer type for easy debugging
 *
 * @param[in]       bearerType
 * @return          convert the bearerType to the string
 ****************************************************************************/
const char *FnVCCB_GetBearerTypeValStr(const int bearerType)
{
    AUTO_TRACE_FUNC;

    switch (bearerType)
    {
        case MN_Term_MCG_Bearer:        // 0x11 (CellGroup_Mcg, TermPoint_Mn)
            return "MN-Term-MCG";
        case MN_Term_SPLIT_Bearer:      // 0x31 (CellGroup_Both, TermPoint_Mn)
            return "MN-Term-SPLIT";
        case SN_Term_SCG_Bearer:        // 0x22 (CellGroup_Scg, TermPoint_Sn)
            return "SN-Term-SCG";
        case SN_Term_SPLIT_Bearer:      // 0x32 (CellGroup_Both, TermPoint_Sn)
            return "SN-Term-SPLIT";
        case MN_Term_SCG_Bearer:        // 0x21 (CellGroup_Scg, TermPoint_Mn)
            return "MN-Term-SCG";
        case SN_Term_MCG_Bearer:        // 0x12 (CellGroup_Mcg, TermPoint_Sn)
            return "SN-Term-MCG";
        default:
            return "UNKNOWN";
    }
}


/********************************************************************************************************************************************
 1. DRB API
****************************************************************************/

// 1.2. Low Level API

/****************************************************************************
 * @brief           This function is used to inquire the details of MRDC DRB. (MN/SN integration code)
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       ptDi : call DRB information / callDRBInfo_type
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @return          mrdc drb information / mrdcDrbDetailInfo
 ****************************************************************************/
mrdcDrbDetailInfo FnVCCB_GetDetailInfoPerDRB(const callInfo_type *ptCi, const callDRBInfo_type *ptDi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    mrdcDrbDetailInfo result;
    memset(&result, 0x00, sizeof(mrdcDrbDetailInfo));

    VALID_E_POINT_CHECK_RET_VAL(ptCi, result);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, result);

    // MN/SN Term 
    result.terminated_point = FnVCCB_GetTermDrbPerDRB(ptCi, ptDi, tag);

    // exist MCG ( 'TRUE' or 'FALSE' )
    result.existMCG = FnVCCB_IsExistMcgPerDRB(ptCi, ptDi, tag);

    // exist SCG ( 'TRUE' or 'FALSE' )
    result.existSCG = FnVCCB_IsExistScgPerDRB(ptCi, ptDi, tag);

    // Split ( 'TRUE' or 'FALSE' )
    result.splitDRB = FnVCCB_IsSplitPerDRB(ptCi, ptDi, tag);

    return result;
}

/****************************************************************************
 * @brief           This function indicates whether the DRB contains MCG(DU). (MN/SN integration code)
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       ptDi : call DRB information / callDRBInfo_type
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @return          TRUE or FALSE / uint32_t
 ****************************************************************************/
bool FnVCCB_IsExistMcgPerDRB(const callInfo_type *ptCi, const callDRBInfo_type *ptDi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    uint8_t bearerType = FnVCCB_getSaDrbBearerType(ptCi, ptDi, tag);

    switch (bearerType)
    {
        case MN_Term_SPLIT_Bearer:
        case SN_Term_SPLIT_Bearer:
        case MN_Term_MCG_Bearer:
        //case SN_Term_MCG_Bearer: // Not Supported
            return TRUE;

        default:
            return FALSE;
    }
}

/****************************************************************************
 * @brief           This function indicates whether the DRB contains SCG(DU). (MN/SN integration code)
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       ptDi : call DRB information / callDRBInfo_type
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @return          TRUE or FALSE / uint32_t
 ****************************************************************************/
bool FnVCCB_IsExistScgPerDRB(const callInfo_type *ptCi, const callDRBInfo_type *ptDi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    uint8_t bearerType = FnVCCB_getSaDrbBearerType(ptCi, ptDi, tag);

    switch (bearerType)
    {
        case MN_Term_SPLIT_Bearer:
        case SN_Term_SPLIT_Bearer:
        case SN_Term_SCG_Bearer:
        //case MN_Term_SCG_Bearer: // Not Supported
            return TRUE;

        default:
            return FALSE;
    }
}

/****************************************************************************
 * @brief           This function indicates whether the DRB contains MCG(DU) and SCG(DU). Its meaning is Split. (MN/SN
 *integration code)
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       ptDi : call DRB information / callDRBInfo_type
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @return          TRUE or FALSE / uint32_t
 ****************************************************************************/
bool FnVCCB_IsSplitPerDRB(const callInfo_type *ptCi, const callDRBInfo_type *ptDi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    uint8_t bearerType = FnVCCB_getSaDrbBearerType(ptCi, ptDi, tag);

    switch (bearerType)
    {
        // SPLIT
        case MN_Term_SPLIT_Bearer:
        case SN_Term_SPLIT_Bearer:
            return TRUE;

        default:
            return FALSE;
    }
}

/****************************************************************************
 * @brief           This function indicates which Termination Point(XX Term, UP) to use. (MN/SN integration code)
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       ptDi : call DRB information / callDRBInfo_type
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @return          MN_Terminated or SN_Terminated / enumPdcpatSgNB
 ****************************************************************************/
enumNrdcBearerTermPointType FnVCCB_GetTermDrbPerDRB(const callInfo_type *ptCi, const callDRBInfo_type *ptDi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, TermPoint_End);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, TermPoint_End);

    nrdcBearer_type bearerType = {TermPoint_End, TermPoint_End};
    switch (tag)
    {
        case current_bearerType:
            bearerType = ptDi->bearerType;
            break;

        case request_bearerType:
            bearerType = ptDi->reqBearerType;
            break;

        case select_bearerType:
            bearerType = ptDi->selectedBearerType;
            break;

        default:
            return TermPoint_End; 
    }

    if (IS_VALID_NrdcBearerType(bearerType))
    {
        return static_cast<enumNrdcBearerTermPointType>(bearerType.termPoint);
    }

    return TermPoint_End;
}

// 1.2. High Level API

/****************************************************************************
 * @brief           This function detects that the termination point is changed. (MN/SN integration code)
 *                  - current vs request
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       ptDi : call DRB information / callDRBInfo_type
 * @return          true or false / bool
 ****************************************************************************/
bool FnVCCB_IsChangedTerminationPoint(const callInfo_type *ptCi, const callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    // Detect Termination Point Change.
    enumNrdcBearerTermPointType currTpType = FnVCCB_GetTermDrbPerDRB(ptCi, ptDi, current_bearerType);
    enumNrdcBearerTermPointType reqTpType =  FnVCCB_GetTermDrbPerDRB(ptCi, ptDi, request_bearerType);

    if (!IS_VALID_NrdcBearerTermPoint(currTpType) || !IS_VALID_NrdcBearerTermPoint(reqTpType))
    {
        return false;
    }

    return currTpType != reqTpType;        
}

/****************************************************************************
 * @brief           This function indicates whether the MN Term Split Or Scg DRB exists in the UE.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       ptDi : call DRB information / callDRBInfo_type
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @return          true or false / bool
 ****************************************************************************/
bool FnVCCB_IsMnTermScgLegPerDRB(const callInfo_type *ptCi, const callDRBInfo_type *ptDi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    nrdcBearer_type bearerType = FnVCCB_GetNrdcBearerTypePerBearerTag(ptCi, ptDi, tag);

    if (!IS_VALID_NrdcBearerType(bearerType))
    {
        return false;
    } 

    if (bearerType.termPoint == TermPoint_Mn &&
            (bearerType.cellGroup == CellGroup_Scg || bearerType.cellGroup == CellGroup_Both))
    {
        return true;
    }

    return false;
}

void FnVCCB_ChangeAllValidDrbStatus(callInfo_type *ptCi, enumSABearerStatus_type drbStatus)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    uint8_t drbIdx;
    callDRBInfo_type *ptDi;
    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        ptDi = &ptCi->drb[drbIdx];
        if (ptDi->usage != CI_use) continue;
        if (ptDi->pduIdxInCall >= MAX_PDU_SESS_PER_CALL) continue;

        if (ptDi->drbStatus == S_Modify)
        {
            SET_DRB_STATUS(ptCi, drbIdx, drbStatus);
        }
    }
}

// SVR22B FGR-CC5203
/****************************************************************************
 * @brief           This function indicates whether the MN Term Split DRB exists in the UE.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       ptDi : call DRB information / callDRBInfo_type
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @return          true or false / bool
 ****************************************************************************/
bool FnVCCB_IsMnTermSplitPerDRB(const callInfo_type *ptCi, const callDRBInfo_type *ptDi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    nrdcBearer_type bearerType = FnVCCB_GetNrdcBearerTypePerBearerTag(ptCi, ptDi, tag);

    if (!IS_VALID_NrdcBearerType(bearerType))
    {
        return false;
    } 

    if (bearerType.val != MN_Term_SPLIT_Bearer)
    {
        return false;
    }

    return true;
}

/****************************************************************************
 * @brief           This function indicates whether the MN Term DRB exists in the UE.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       ptDi : call DRB information / callDRBInfo_type
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @return          true or false / bool
 ****************************************************************************/
bool FnVCCB_IsMnTermPerDRB(const callInfo_type *ptCi, const callDRBInfo_type *ptDi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    nrdcBearer_type bearerType = FnVCCB_GetNrdcBearerTypePerBearerTag(ptCi, ptDi, tag);

    if (!IS_VALID_NrdcBearerType(bearerType))
    {
        if (request_bearerType == tag && bearerType.val == INIT_BEARER_TYPE)
        {
            // In case of abnormal case of calling this function with request_bearer_type even though current_bearer_type should be used for NON-DC bearer in SA or NRDC situation
            // the drb whose reqBearerType is INIT_BEARER_TYPE is also considered as MnTerm.
            return true;
        }
        else
        {
            return false;
        }
    } 

    if (bearerType.termPoint != TermPoint_Mn)
    {
        return false;
    }

    return true;
}

/****************************************************************************
 * @brief           This function indicates whether the SN Term Split DRB exists in the UE.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       ptDi : call DRB information / callDRBInfo_type
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @return          true or false / bool
 ****************************************************************************/
bool FnVCCB_IsSnTermSplitPerDRB(const callInfo_type *ptCi, const callDRBInfo_type *ptDi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    nrdcBearer_type bearerType = FnVCCB_GetNrdcBearerTypePerBearerTag(ptCi, ptDi, tag);

    if (!IS_VALID_NrdcBearerType(bearerType))
    {
        return false;
    } 

    if (bearerType.val != SN_Term_SPLIT_Bearer)
    {
        return false;
    }

    return true;
}

/****************************************************************************
 * @brief           This function indicates whether the SN Term Scg DRB exists in the UE.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       ptDi : call DRB information / callDRBInfo_type
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @return          true or false / bool
 ****************************************************************************/
bool FnVCCB_IsSnTermScgPerDRB(const callInfo_type *ptCi, const callDRBInfo_type *ptDi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    nrdcBearer_type bearerType = FnVCCB_GetNrdcBearerTypePerBearerTag(ptCi, ptDi, tag);

    if (!IS_VALID_NrdcBearerType(bearerType))
    {
        return false;
    } 

    if (bearerType.val != SN_Term_SCG_Bearer)
    {
        return false;
    }

    return true;
}

/****************************************************************************
 * @brief           This function indicates whether the SN Term DRB exists in the UE.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       ptDi : call DRB information / callDRBInfo_type
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @return          true or false / bool
 ****************************************************************************/
bool FnVCCB_IsSnTermPerDRB(const callInfo_type *ptCi, const callDRBInfo_type *ptDi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    nrdcBearer_type bearerType = FnVCCB_GetNrdcBearerTypePerBearerTag(ptCi, ptDi, tag);

    if (!IS_VALID_NrdcBearerType(bearerType))
    {
        return false;
    } 

    if (bearerType.termPoint != TermPoint_Sn)
    {
        return false;
    }

    return true;
}

/********************************************************************************************************************************************
 2. QOS FLOW API
****************************************************************************/
// TODO

/********************************************************************************************************************************************
 3. PDU API
****************************************************************************/

/****************************************************************************
 * @brief           This function indicates whether the MN Term Split Or Scg DRB exists in the PDU.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @return          true or false / bool
 ****************************************************************************/
bool FnVCCB_IsAnyMnTermScgLegPerPDU(const callInfo_type *ptCi, const callPDUSessInfo_type *ptPi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    bool status = false;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptPi, false);

    status = FnVCCB_IsAnyBearerType_Common_PerPDU(ptCi, ptPi, FnVCCB_IsMnTermScgLegPerDRB, tag, true);

    return status;
}

/****************************************************************************
 * @brief           This function indicates whether the MN Term DRB exists in the PDU.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @return          true or false / bool
 ****************************************************************************/
bool FnVCCB_IsAnyMnTermPerPDU(const callInfo_type *ptCi, const callPDUSessInfo_type *ptPi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    bool status = false;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptPi, false);

    status = FnVCCB_IsAnyBearerType_Common_PerPDU(ptCi, ptPi, FnVCCB_IsMnTermPerDRB, tag, true);

    return status;
}

/****************************************************************************
 * @brief           This function indicates whether the SN Term Split Or Scg DRB exists in the PDU.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       tag : pdu session information struct / callPDUSessInfo_type
 * @return          true or false / bool
 ****************************************************************************/
bool FnVCCB_IsAnySnTermSplitPerPDU(const callInfo_type *ptCi, const callPDUSessInfo_type *ptPi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    bool status = false;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptPi, false);

    status = FnVCCB_IsAnyBearerType_Common_PerPDU(ptCi, ptPi, FnVCCB_IsSnTermSplitPerDRB, tag, true);

    return status;
}

/****************************************************************************
 * @brief           This function indicates whether the SN Term DRB exists in the PDU.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       tag : pdu session information struct / callPDUSessInfo_type
 * @return          true or false / bool
 ****************************************************************************/
bool FnVCCB_IsAnySnTermPerPDU(const callInfo_type *ptCi, const callPDUSessInfo_type *ptPi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    bool status = false;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptPi, false);

    status = FnVCCB_IsAnyBearerType_Common_PerPDU(ptCi, ptPi, FnVCCB_IsSnTermPerDRB, tag, true);

    return status;
}

/********************************************************************************************************************************************
 4. UE API
****************************************************************************/

/****************************************************************************
 * @brief           This function indicates whether the MN Term Split Or Scg DRB exists in the UE.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @return          true or false / bool
 ****************************************************************************/
bool FnVCCB_IsAnyMnTermScgLegPerUE(callInfo_type *ptCi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    bool status = false;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    status = FnVCCB_IsAnyBearerType_Common_PerUE(ptCi, FnVCCB_IsMnTermScgLegPerDRB, tag, true);

    return status;
}

// SVR22B FGR-CC5203
/****************************************************************************
 * @brief           This function indicates whether the MN Term Split DRB exists in the UE.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @return          true or false / bool
 ****************************************************************************/
bool FnVCCB_IsAnyMnTermSplitPerUE(callInfo_type *ptCi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    bool status = false;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    status = FnVCCB_IsAnyBearerType_Common_PerUE(ptCi, FnVCCB_IsMnTermSplitPerDRB, tag, true);

    return status;
}

/****************************************************************************
 * @brief           This function indicates whether the MN Term DRB exists in the UE.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @return          true or false / bool
 ****************************************************************************/
bool FnVCCB_IsAnyMnTermPerUE(callInfo_type *ptCi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    bool status = false;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    status = FnVCCB_IsAnyBearerType_Common_PerUE(ptCi, FnVCCB_IsMnTermPerDRB, tag, true);

    return status;
}

/****************************************************************************
 * @brief           This function indicates whether the SN Term Split DRB exists in the UE.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @return          true or false / bool
 ****************************************************************************/
bool FnVCCB_IsAnySnTermSplitPerUE(callInfo_type *ptCi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    bool status = false;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    status = FnVCCB_IsAnyBearerType_Common_PerUE(ptCi, FnVCCB_IsSnTermSplitPerDRB, tag, true);

    return status;
}

/****************************************************************************
 * @brief           This function indicates whether the SN Term DRB exists in the UE.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       tag : key of mrdc bearertype / enumDrbBearerTag_type
 * @return          true or false / bool
 ****************************************************************************/
bool FnVCCB_IsAnySnTermPerUE(callInfo_type *ptCi, enumDrbBearerTag_type tag)
{
    AUTO_TRACE_FUNC;

    bool status = false;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    status = FnVCCB_IsAnyBearerType_Common_PerUE(ptCi, FnVCCB_IsSnTermPerDRB, tag, true);

    return status;
}

/********************************************************************************************************************************************
 5. MRDC INFO API
****************************************************************************/

/****************************************************************************
 * @brief           This function indicates whether a specific MRDC procedure is in progress.
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in]       code : Procedure code to check / enumMrdcProcedureCode_type
 * @param[in]       purpose : Procedure purpose to check / enumMrdcProcedurePurpose_type
 * @return          true or false / bool
 ****************************************************************************/
bool FnVCCB_IsMrdcProcedure(callInfo_type *ptCi, enumMrdcProcedureCode_type code, enumMrdcProcedurePurpose_type purpose)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (GET_MRDC_PROCEDURE_CODE(ptCi) != (unsigned int)code)
        return false;

    if (GET_MRDC_PROCEDURE_PURPOSE(ptCi) != (unsigned int)purpose)
        return false;

    return true;
}

/****************************************************************************
 * @brief Checks if NRDC is allowed with partial success.
 * @param ptCi Pointer to the call information structure.
 * @return bool Returns true if NRDC is allowed with partial success, otherwise false.
 ****************************************************************************/
bool FnVCCB_IsNrdcAllowedPartialSuccess(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);

    switch (ptCi->stateCmd)
    {
        case MrdcXnSNAdd_cmd: //FGR-CC5200
            return GNBINFO[ptCi->gnbNum].cfg.nrdc.supportPartialSuccess;

        case IntraRatHO_cmd: //FGR-CC5201
            return (ptCi->hoInfo.currentlyAllowPartial && FnVCCB_IsPartialHoAllowEnabled(*ptCi));

        default:
            break;
    }

    return false;
}

bool FnVCCB_DoesAnySvcGrpHasLtmCandidateCells(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VAL(rCi.gnbNum, MAX_GNB_PER_SYS, false);
    VccbGnbInfo_type *pGnb = &GNBINFO[rCi.gnbNum];

    for (uint8_t svcGrpId = 0; svcGrpId < MAX_SVC_GRP_DB_NUM; svcGrpId++)
    {
        SvcGrpBasedCfg_type &rSvcGrpBasedCfg = pGnb->cfg.svcGrpBasedCfg[svcGrpId];

        if (rSvcGrpBasedCfg.usage != CI_use) continue;
        if (rSvcGrpBasedCfg.numOfLtmCandidateCell == 0) continue;

        if (svcGrpId == 0) 
        {
            return true;
        }

        svcGrpCfg_type &rSvcGrpIdCfg = pGnb->cfg.svcGrpCfg[svcGrpId];
        if (rSvcGrpIdCfg.usage == CI_use)
        {
            return true;
        }
    }

    return false;
}

bool FnVCCB_IsNrdcCaProhibitedStaticallyByLtmHO(callInfo_type &rCi, const uint16_t bandNr)
{
    // decision based on statical information (UECapability and Yang Configuration)

    if (bandNr == BAND_NOT_FOUND)
    {
        return false;
    }

    if (not FnVCCB_CheckLtmUeCapability(rCi, bandNr)) 
    {
        return false;
    }
    
    if (not FnVCCB_DoesAnySvcGrpHasLtmCandidateCells(rCi)) 
    {
        return false;
    }

    return true;
}

bool FnVCCB_IsNrdcCaProhibitedOperationallyByLtmHO(callInfo_type &rCi)
{
    return FnVCCB_IsSetupedLtmCell(&rCi);
}

bool FnVCCB_IsNrdcProhibitedByLtmHO(callInfo_type &rCi, const uint16_t bandNr)
{
    // In order to ensure the exclusive operation of the nrdc/ca and ltm ho, the nrdc/ca is extensively restricted compared to the LTM-ho.
    bool staticalLtmUeProperty = FnVCCB_IsNrdcCaProhibitedStaticallyByLtmHO(rCi, bandNr);
    bool operationalLtmUeProperty = FnVCCB_IsNrdcCaProhibitedOperationallyByLtmHO(rCi);

    VCCB_PRINT_CALL_COMMENT(&rCi, "<staticalLtmUeProperty:%d, operationalLtmUeProperty:%d> in %s\n", staticalLtmUeProperty, operationalLtmUeProperty, __func__);

    return staticalLtmUeProperty || operationalLtmUeProperty;
}

