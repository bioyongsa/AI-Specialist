#include "FeatNrdc2Nrca.h"

int FnVCCB_QueryRemovedMeasFreqforNrdc(callInfo_type &rCall, uint32_t ssbArfcn)
{
    AUTO_TRACE_FUNC;

    if (ssbArfcn == DONT_CARE_ARFCN)
    {
        if (rCall.nrdc2nrcaLBCtx.noOfEntries > 0)
        {
            return GOOD;
        }

        return ERROR;
    }

    const auto maxIdx =
        util::minOfArraySizeAndNumOfElems(rCall.nrdc2nrcaLBCtx.removedMeasFreq, rCall.nrdc2nrcaLBCtx.noOfEntries);
    for (uint32_t idx = 0; idx < maxIdx; ++idx)
    {
        if (ssbArfcn == rCall.nrdc2nrcaLBCtx.removedMeasFreq[idx])
        {
            return GOOD;
        }
    }

    return ERROR;
}

int FnVCCB_AddRemovedMeasFreqforNrdc(callInfo_type &rCall, uint32_t ssbArfcn)
{
    AUTO_TRACE_FUNC;
    const int maxDbEntries = VCCB_ARRAY_COUNT(rCall.nrdc2nrcaLBCtx.removedMeasFreq);

    if (ssbArfcn == DONT_CARE_ARFCN)
    {
        return ERROR;
    }

    if (rCall.nrdc2nrcaLBCtx.noOfEntries >= maxDbEntries)
    {
        // shifting to keep ordering based on latest registered.
        for (int dstIdx = 0, srcIdx = 1; dstIdx < maxDbEntries - 1; ++dstIdx, ++srcIdx)
        {
            rCall.nrdc2nrcaLBCtx.removedMeasFreq[dstIdx] = rCall.nrdc2nrcaLBCtx.removedMeasFreq[srcIdx];
        }
        rCall.nrdc2nrcaLBCtx.removedMeasFreq[maxDbEntries - 1] = ssbArfcn;
    }
    else
    {
        rCall.nrdc2nrcaLBCtx.removedMeasFreq[rCall.nrdc2nrcaLBCtx.noOfEntries++] = ssbArfcn;
    }

    if (rCall.nrdc2nrcaLBCtx.noOfEntries >= maxDbEntries)
    {
        rCall.nrdc2nrcaLBCtx.noOfEntries = maxDbEntries;
    }

    return GOOD;
}

int FnVCCB_DeleteRemovedMeasFreqforNrdc(callInfo_type &rCall, uint32_t ssbArfcn)
{
    AUTO_TRACE_FUNC;
    const int maxDbEntries = VCCB_ARRAY_COUNT(rCall.nrdc2nrcaLBCtx.removedMeasFreq);

    if (ssbArfcn == DONT_CARE_ARFCN)
    {
        rCall.nrdc2nrcaLBCtx.noOfEntries = 0;
        VCCB_PRINT_CALL_NRDC_BASIC(&rCall, "[NRDC2NRCA] RemovedMeasFreq List for nrdc is reset !\n");
        return GOOD;
    }

    uint8_t entryIdx = 0, maxIdx = MIN(rCall.nrdc2nrcaLBCtx.noOfEntries, maxDbEntries);
    for (entryIdx = 0; entryIdx < maxIdx; ++entryIdx)
    {
        if (ssbArfcn == rCall.nrdc2nrcaLBCtx.removedMeasFreq[entryIdx])
        {
            break;
        }
    }

    if (entryIdx >= maxIdx)
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "[NRDC2NRCA] Can't find ssbArfcn(%u) !\n", ssbArfcn);
        return ERROR;
    }

    // shifting to keep ordering based on latest registered.
    for (int dstIdx = entryIdx, srcIdx = entryIdx + 1; dstIdx < maxIdx - 1; ++dstIdx, ++srcIdx)
    {
        rCall.nrdc2nrcaLBCtx.removedMeasFreq[dstIdx] = rCall.nrdc2nrcaLBCtx.removedMeasFreq[srcIdx];
    }

    if (rCall.nrdc2nrcaLBCtx.noOfEntries > 0)
    {
        rCall.nrdc2nrcaLBCtx.noOfEntries--;
    }

    return GOOD;
}

void FnVCCB_RecoverA4MeasCfgFromRemovedMeasFreq(callInfo_type &rCall, uint32_t ssbArfcn)
{
    AUTO_TRACE_FUNC;

    if (!rCall.nrdc2nrcaLBCtx.needRefresh)
    {
        return;
    }

    rCall.nrdc2nrcaLBCtx.needRefresh = VCCB_FLAG_OFF;

    if (!FnVCCB_IsSupportNrdc2NrcaLB(rCall))
    {
        VCCB_PRINT_CALL_NRDC_BASIC(&rCall, "[NRDC2NRCA] Not FnVCCB_IsSupportNrdc2NrcaLB in %s!!!\n", __func__);
        return;
    }

    if (GOOD != FnVCCB_QueryRemovedMeasFreqforNrdc(rCall, ssbArfcn))
    {
        return;
    }

    if (FnVCCB_IsNrcaBetterThanNrdc(rCall, 0, rCall.servCellNum, 0, RULE_CHECK_SaBandwidth))
    {
        return;  // keep current status.
    }
    else
    {
        VCCB_PRINT_CALL_NRDC_BASIC(&rCall,
            "[NRDC2NRCA] nrdc2nrcaLB status is changed :: bandwidth of Nrdc is better than FR1-Ca in %s!!!\n",
            __func__);
    }

    if (GOOD != FnVCCB_RemovedMeasFreqforNrdc_Cmd(rCall, ssbArfcn, REMOVED_MEASFREQ_Delete))
    {
        VCCB_PRINT_CALL_NRDC_BASIC(&rCall,
            "[NRDC2NRCA] FnVCCB_RemovedMeasFreqforNrdc_Cmd(ssbArfcn(%u), REMOVED_MEASFREQ_Delete) ERROR, in %s!!!\n",
            ssbArfcn, __func__);
    }
    else
    {
        VCCB_PRINT_CALL_NRDC_BASIC(&rCall,
            "[NRDC2NRCA] FnVCCB_RemovedMeasFreqforNrdc_Cmd(ssbArfcn(%u), REMOVED_MEASFREQ_Delete) OK, in %s!!!\n",
            ssbArfcn, __func__);
    }
}

int FnVCCB_RemovedMeasFreqforNrdc_Cmd(callInfo_type &rCall, uint32_t ssbArfcn, enumRemovedMeasFreqCrtl_type ctrlCmd)
{
    AUTO_TRACE_FUNC;
    int status = GOOD;

    if (!FnVCCB_IsSupportNrdc2NrcaLB(rCall))
    {
        VCCB_PRINT_CALL_NRDC_BASIC(&rCall, "[NRDC2NRCA] Not FnVCCB_IsSupportNrdc2NrcaLB in %s!!!\n", __func__);
        return ERROR;
    }

    switch (ctrlCmd)
    {
        case REMOVED_MEASFREQ_Query:
            return FnVCCB_QueryRemovedMeasFreqforNrdc(rCall, ssbArfcn);

        case REMOVED_MEASFREQ_Add:
            return FnVCCB_AddRemovedMeasFreqforNrdc(rCall, ssbArfcn);

        case REMOVED_MEASFREQ_Delete:
            return FnVCCB_DeleteRemovedMeasFreqforNrdc(rCall, ssbArfcn);

        default:
            VCCB_PRINT_CALL_ERROR(&rCall, "Invalid RemovedMeasFreqctrlCmd in %s!!!\n", __func__);
            status = ERROR;
            break;
    }

    return status;
}

bool FnVCCB_IsFR1CaSupportInNRDC(callInfo_type &rCall, uint16_t bandIndi)
{
    AUTO_TRACE_FUNC;

    if (bandIndi == BAND_NOT_FOUND)
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "Invalid bandIndi(%u) in %s!!!\n", bandIndi, __func__);
        return true;  // if it is impossible to check whether fr1ca can be supported in nrdc.
    }

    if (!rCall.cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC_Flag)
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "AllowedBcList is not valid(allowedBC_ListMRDC_Flag :%u) in %s!!!\n",
            rCall.cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC_Flag, __func__);
        return false;  // nrdc can't be supported.
    }

    bandCombinationInfoList_type &allowedBcList = rCall.cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC;
    if (!allowedBcList.nrofBandComb)
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "nrofBandComb of AllowedBcList is 0 in %s!!!\n", __func__);
        return false;
    }

    uint32_t loop = 0, loop2 = 0,
             maxIdx = MIN(allowedBcList.nrofBandComb, VCCB_ARRAY_COUNT(allowedBcList.bandCombinationInfo));
    for (loop = 0; loop < maxIdx; ++loop)
    {
        bandCombinationInfo_type &bandCombInfo = allowedBcList.bandCombinationInfo[loop];
        if (!bandCombInfo.isSupportFR1Ca) continue;

        uint32_t maxIdx2 = MIN(bandCombInfo.noofFreqBandIndi, VCCB_ARRAY_COUNT(bandCombInfo.freqBandIndi));
        for (loop2 = 0; loop2 < maxIdx2; ++loop2)
        {
            if (bandIndi == bandCombInfo.freqBandIndi[loop2])
            {
                return true;
            }
        }
    }

    return false;
}

bool FnVCCB_IsSaBandwidthGreaterThanYangCfg(callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;

    const VccbGnbInfo_type *const pGnb = FnVCCB_GetGnbInfo(rCall.gnbNum);
    VALID_E_POINT_CHECK_RET_VAL(pGnb, false);
    uint32_t bwThYangCfg = static_cast<uint32_t>(pGnb->cfg.nrdc.nrdc2nrcaLB.bwThreshold);
    uint32_t saBandwidth = 0;

    if (GOOD != VLIB_getSumOfBandwidthFromPcellAndInstalledScells(&rCall, &saBandwidth))
    {
        return false;
    }

    if (saBandwidth <= bwThYangCfg)
    {
        return false;
    }
    return true;
}

bool FnVCCB_IsPSCellAvailableResourceLessThanYangCfg(callInfo_type &rCall, uint16_t cellNum, uint16_t nbrIdx)
{
    AUTO_TRACE_FUNC;

    const VccbGnbInfo_type *const pGnb = FnVCCB_GetGnbInfo(rCall.gnbNum);
    VALID_E_POINT_CHECK_RET_VAL(pGnb, false);
    const uint32_t capacityThreshold = static_cast<uint32_t>(pGnb->cfg.nrdc.nrdc2nrcaLB.capacityThreshold);

    const VccbCellInfo_type *const pCell = FnVCCB_GetCellInfo(cellNum);
    VALID_E_POINT_CHECK_RET_VAL(pCell, false);

    VCCB_CHECK_E_RANGE_AND_VAL(nbrIdx, VCCB_ARRAY_COUNT(pCell->cellRscInfo.nbrPrb), false);
    const sonNbrPrbRsc_type &prbRsc = pCell->cellRscInfo.nbrPrb[nbrIdx];

    if (prbRsc.usage != CI_use || prbRsc.isRsUpdate != ON)
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "[NRDC2NRCA] Invalid prbRsc.usage(%d) or prbRsc.isRsUpdate(%d)!!\n", prbRsc.usage,
            prbRsc.isRsUpdate);
        return false;
    }

    if (!prbRsc.dlCCCV)
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "Invalid prbRsc.dlCCCV(%d)!!\n", prbRsc.dlCCCV);
        return false;
    }

    const uint32_t availRsc = static_cast<uint32_t>(prbRsc.dlCapacityValue) * prbRsc.dlCCCV;
    if (availRsc >= capacityThreshold)
    {
        return false;
    }

    return true;
}

//  reestimate whether nr-ca is better than nr-dc to support maximum throughput.
bool FnVCCB_IsNrcaBetterThanNrdc(
    callInfo_type &rCall, uint16_t bandIndi, uint16_t cellNum, uint16_t nbrIdx, enumRuleCheckNrdc2NrcaLB_type ruleChk)
{
    AUTO_TRACE_FUNC;

    if (!FnVCCB_IsSupportNrdc2NrcaLB(rCall))
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "[NRDC2NRCA] Not FnVCCB_IsSupportNrdc2NrcaLB in %s!!!\n", __func__);
        return false;
    }

    if (!FnVCCB_IsNrdcMRBasedOprSupportable(&rCall, cellNum))
    {
        return false;
    }

    if (!(ruleChk & (RULE_CHECK_UeCapa | RULE_CHECK_SaBandwidth | RULE_CHECK_PscellResource)))
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "[NRDC2NRCA] Invalid ruleChk(0x%x) in %s!!!\n", ruleChk, __func__);
        return false;
    }

    if (ruleChk & RULE_CHECK_UeCapa)
    {
        if (FnVCCB_IsFR1CaSupportInNRDC(rCall, bandIndi))
        {
            VCCB_PRINT_CALL_NRDC_BASIC(
                &rCall, "[NRDC2NRCA] [%u] NRDC is better(FnVCCB_IsFR1CaSupportInNRDC)\n", nbrIdx);
            return false;
        }
    }

    if (ruleChk & RULE_CHECK_SaBandwidth)
    {
        if (!FnVCCB_IsSaBandwidthGreaterThanYangCfg(rCall))
        {
            VCCB_PRINT_CALL_NRDC_BASIC(&rCall,
                "[NRDC2NRCA] [%u] NRDC is better(FnVCCB_IsSaBandwidthGreaterThanYangCfg)\n", nbrIdx);
            return false;
        }
    }

    if (ruleChk & RULE_CHECK_PscellResource)
    {
        if (!FnVCCB_IsPSCellAvailableResourceLessThanYangCfg(rCall, cellNum, nbrIdx))
        {
            VCCB_PRINT_CALL_NRDC_BASIC(
                &rCall, "[NRDC2NRCA] [%u] NRDC is better(FnVCCB_IsPSCellAvailableResourceLessThanYangCfg)\n", nbrIdx);
            return false;
        }
    }

    return true;
}

int FnVCCB_GetFrequencyAndBandIndiNRfromReceivedMRforNrdcAdd(
    callInfo_type &rCall, uint32_t ssbFreq, frequencyAndBandIndiNR_type &freqAndBandIndi)
{
    AUTO_TRACE_FUNC;

    if (IS_FREQ_N_BANDINDI_VALID(rCall.nrdcAddA4MrReceived.mR1st) && ssbFreq == rCall.nrdcAddA4MrReceived.mR1st.ssbFreq)
    {
        freqAndBandIndi = rCall.nrdcAddA4MrReceived.mR1st;
        return GOOD;
    }

    if (IS_SUPPORTABLE_ScgBandSelectionForNrdc_Foo() && rCall.loadBasedNrdcScgBandSelectInfo.usage == CI_use &&
        IS_FREQ_N_BANDINDI_VALID(rCall.nrdcAddA4MrReceived.mR2nd) && ssbFreq == rCall.nrdcAddA4MrReceived.mR2nd.ssbFreq)
    {
        freqAndBandIndi = rCall.nrdcAddA4MrReceived.mR2nd;
        return GOOD;
    }

    return ERROR;
}

int FnVCCB_PreChkNrdc2NrcaLB(callInfo_type &rCall, uint32_t ssbFreq)
{
    AUTO_TRACE_FUNC;
    frequencyAndBandIndiNR_type freqAndBandIndi = {DONT_CARE_ARFCN, BAND_NOT_FOUND};

    if (!FnVCCB_IsSupportNrdc2NrcaLB(rCall))
    {
        return BREAK;
    }

    if (!FnVCCB_IsNrdcMRBasedOprSupportable(&rCall, rCall.servCellNum))
    {
        return BREAK;
    }

    if (ERROR == FnVCCB_GetFrequencyAndBandIndiNRfromReceivedMRforNrdcAdd(rCall, ssbFreq, freqAndBandIndi))
    {
        VCCB_PRINT_CALL_ERROR(
            &rCall, "FnVCCB_GetFrequencyAndBandIndiNRfromReceivedMRforNrdcAdd ERROR in %s!!\n", __func__);
        return ERROR;
    }

    if (!IS_FREQ_N_BANDINDI_VALID(freqAndBandIndi))
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "[NRDC2NRCA] freqAndBandIndi(ssbFreq:%u, bandIndi:%u) is Not valid in %s!!\n",
            freqAndBandIndi.ssbFreq, freqAndBandIndi.bandIndiNR, __func__);
        return ERROR;
    }

    if (!FnVCCB_IsNrcaBetterThanNrdc(rCall, freqAndBandIndi.bandIndiNR, rCall.servCellNum, 0,
            static_cast<enumRuleCheckNrdc2NrcaLB_type>(RULE_CHECK_UeCapa | RULE_CHECK_SaBandwidth)))
    {
        VCCB_PRINT_CALL_NRDC_BASIC(&rCall,
            "[NRDC2NRCA] Not FnVCCB_IsNrcaBetterThanNrdc(ssbFreq:%u, bandIndi:%u) in %s!!!\n", freqAndBandIndi.ssbFreq,
            freqAndBandIndi.bandIndiNR, __func__);
        return BREAK;
    }
    return GOOD;
}

int FnVCCB_FinalizeNrdc2NrcaLB(callInfo_type &rCall, uint32_t ssbFreq)
{
    AUTO_TRACE_FUNC;

    std::vector<frequencyAndBandIndiNR_type> vFreqAndBand;
    frequencyAndBandIndiNR_type freqAndBandIndi = {DONT_CARE_ARFCN, BAND_NOT_FOUND};
    bool scgBandSel = false;
    rCall.nrdc2nrcaLBCtx.needMeasReconfig = false;    

    if (ERROR == FnVCCB_GetFrequencyAndBandIndiNRfromReceivedMRforNrdcAdd(rCall, ssbFreq, freqAndBandIndi))
    {
        VCCB_PRINT_CALL_ERROR(
            &rCall, "FnVCCB_GetFrequencyAndBandIndiNRfromReceivedMRforNrdcAdd ERROR in %s!!\n", __func__);
        return ERROR;
    }

    if (!IS_FREQ_N_BANDINDI_VALID(freqAndBandIndi))
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "[NRDC2NRCA] freqAndBandIndi(ssbFreq:%u, bandIndi:%u) is Not valid in  %s!!\n",
            freqAndBandIndi.ssbFreq, freqAndBandIndi.bandIndiNR, __func__);
        return ERROR;
    }

    if (IS_SUPPORTABLE_ScgBandSelectionForNrdc_Foo() && rCall.loadBasedNrdcScgBandSelectInfo.usage == CI_use)
    {
        if (freqAndBandIndi.bandIndiNR != rCall.loadBasedNrdcScgBandSelectInfo.fr2Band)
        {
            //Just warning
            VCCB_PRINT_CALL_ERROR(&rCall,
                "[NRDC2NRCA] freqBandIndi(%u) of ssbFreq(%u) doesn't match with scgBandSelected-fr2Band(%u) in %s\n",
                freqAndBandIndi.bandIndiNR, freqAndBandIndi.ssbFreq, rCall.loadBasedNrdcScgBandSelectInfo.fr2Band,
                __func__);
        }

        scgBandSel = true;
        VCCB_PRINT_CALL_NRDC_BASIC(&rCall, "[NRDC2NRCA] ssbFreq(%u), scgBandSelected-fr2Band(%u) in %s\n",
            freqAndBandIndi.ssbFreq, freqAndBandIndi.bandIndiNR, __func__);
    }

    if (!scgBandSel)
    {
        if (GOOD == FnVCCB_RemovedMeasFreqforNrdc_Cmd(rCall, freqAndBandIndi.ssbFreq, REMOVED_MEASFREQ_Add))
        {
            rCall.nrdc2nrcaLBCtx.needMeasReconfig = true;
            VCCB_PRINT_CALL_NRDC_BASIC(&rCall,
                "[NRDC2NRCA] additional ssbFreq(%u) was registered to RemovedMeasFreqList!!\n",
                freqAndBandIndi.ssbFreq);
        }
        else
        {
            VCCB_PRINT_CALL_NRDC_BASIC(&rCall,
                "[NRDC2NRCA] FnVCCB_RemovedMeasFreqforNrdc_Cmd(additional ssbFreq(%u, REMOVED_MEASFREQ_Add) ERROR!!!\n",
                freqAndBandIndi.ssbFreq);
        }
        return GOOD;
    }

    if (ERROR == FnVCCB_GetFreqAndBandListFromInstalledMeasIdForSCGBandSel(
                     &rCall, measReport_A4, a4Purpose_NrdcAddition, vFreqAndBand))
    {
        VCCB_PRINT_CALL_NRDC_BASIC(
            &rCall, "[NRDC2NRCA] FnVCCB_GetFreqAndBandListFromInstalledMeasIdForSCGBandSel ERROR\n");
        return GOOD;
    }

    for (const auto &freqAndBandTuple : vFreqAndBand)
    {
        if (GOOD == FnVCCB_RemovedMeasFreqforNrdc_Cmd(rCall, freqAndBandTuple.ssbFreq, REMOVED_MEASFREQ_Query))
        {
            VCCB_PRINT_CALL_NRDC_BASIC(&rCall,
                "[NRDC2NRCA] scbBandSel ssbFreq(%u) is already registered in removedMeasFreq for nrdc!!!\n",
                freqAndBandTuple.ssbFreq);
            continue;
        }

        if (GOOD == FnVCCB_RemovedMeasFreqforNrdc_Cmd(rCall, freqAndBandTuple.ssbFreq, REMOVED_MEASFREQ_Add))
        {
            rCall.nrdc2nrcaLBCtx.needMeasReconfig = true;
            VCCB_PRINT_CALL_NRDC_BASIC(&rCall,
                "[NRDC2NRCA] scbBandSel ssbFreq(%u) was registered to RemovedMeasFreqList!!\n",
                freqAndBandTuple.ssbFreq);
        }
        else
        {
            VCCB_PRINT_CALL_NRDC_BASIC(&rCall,
                "[NRDC2NRCA] FnVCCB_RemovedMeasFreqforNrdc_Cmd(scbBandSel ssbFreq(%u, REMOVED_MEASFREQ_Add) ERROR!!!\n",
                freqAndBandTuple.ssbFreq);
        }
    }

    return GOOD;
}