/****************************************************************
 * System      : 5G gNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatUlPathControlNRDC.c
 * Description : This file contains functions related to management of NRDC UL path.
 * Dept.       : 5G Call SW Lab.
 * Created     : 2022.06.10
 ****************************************************************/

#include "FeatUlPathControlENDC.h"
#include "ComInclude.h"
#include "ComLibUtility.h"

#include "CdbUtil.h"

#include "FeatCommon.h"
#include "FeatCallInfo.h"
#include "FeatCallProc.h"
#include "FeatMeasurements.hpp"
#include "FeatRbInfo.h"

/****************************************************************************
 * @brief           Set Data Stall configuration
 *
 * @param[in,out]   ptCi                    : pointer to UE Context
 * @param[in]       cellNum                 : pointer to structure containing info of cell available
 * @return          status                  : void
 ****************************************************************************/
uint8_t VCCM_SetDataStallConfiguration(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(CELLINFO);
    VCCB_CHECK_E_RANGE_AND_FALSE(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);
    uint8_t status = FALSE;

    if (VCCB_FLAG_ON == GNBINFO[ptCi->gnbNum].cfg.qciBasedUlSplitThSwitch || FnVCCB_IsVipUeUlPathSwitchActive(ptCi->gnbNum)) 
    {
       return status;
    }

    if (GNBINFO[ptCi->gnbNum].cfg.ulPrimaryPathDataStallPreventionFlag &&
        NRUL_COV_OFF != CELLINFO[cellNum].nrUlCoverageMethod)
    {
        ptCi->isDataStallPreventionTriggerReceived = UlPath_DataStall_WaitingForTrigger;
        ptCi->ulPathControl.prev.ulPdcpPath = ptCi->ulPathControl.curr.ulPdcpPath;
        ptCi->ulPathControl.prev.nrUlCoverageState = ptCi->ulPathControl.curr.nrUlCoverageState;
        ptCi->ulPathControl.curr.ulPdcpPath = UlPdcpPath_McgOnly;
        ptCi->ulPathControl.curr.nrUlCoverageState = OUT_NR_UL_COVERAGE_STATE;
        if( NRUL_COV_A1_A2 == CELLINFO[cellNum].nrUlCoverageMethod )
        {
            VLIB_AttachTimer(&ptCi->dddsIndicationTimer, ptCi, timInternalDddsIndication_id);
        }
        status = TRUE;

        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[VCCM_SetDataStallConfiguration] : curr.ulPdcpPath = %d, prev.ulPdcpPath = %d\n", 
                            ptCi->ulPathControl.curr.ulPdcpPath, ptCi->ulPathControl.prev.ulPdcpPath);
    }

    return status;
}

/****************************************************************************
 * @brief           Handler for event of Data Stall prevention trigger
 *
 * @param[in,out]   ptCi                    : pointer to UE Context
 *
 * @return          status                  : void
 * ****************************************************************************/
void FnVCCB_DataStallPreventionTriggerHandler(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if( UlPath_DataStall_WaitingForTrigger == ptCi->isDataStallPreventionTriggerReceived )
    {
        ptCi->isDataStallPreventionTriggerReceived = UlPath_DataStall_TriggerReceived;
    }
}


/****************************************************************************
 * @brief           Map X2 Bandwitdth UL enum to value
 *
 * @param[in]       bandwidthUlEnum                    : value of X2 enum
 * @return          lte PRB                 : 
 ****************************************************************************/
uint8_t FnVCCB_mapX2LteBandwidthUlEnumToValue(uint8_t bandwidthUlEnum)
{
    AUTO_TRACE_FUNC;
    
    switch(bandwidthUlEnum)
    {
        case X2AP_bw6:
            return 6;
        case X2AP_bw15:
            return 15;
        case X2AP_bw25:
            return 25;
        case X2AP_bw50:
            return 50;
        case X2AP_bw75:
            return 75;
        case X2AP_bw100:
            return 100;
        case X2AP_bw1:
            return 1;
        default: 
            return 0; //assuming 0 in case its wrongly set
    }
}

/****************************************************************************
 * @brief           Select value TDD NR Bandwidth Ratio Coefficient based on PLDCellStatus
 *
 * @param[in]       pCellStatus             : pointer to PLDCellStatus data
 * @return          value                   : value of tDD_NR_Bandwidth_Ratio_Coefficient
 ****************************************************************************/
float FnVCCB_Get_TDD_NR_BandwidthRatioCoefficient(VccbCellInfo_type *pCell)
{
    float tDD_NR_Bandwidth_Ratio_Coefficient = (float) TDD_NR_BANDWIDTH_RATIO_COEFFICIENT;

    VALID_E_POINT_CHECK_RET_VAL(pCell, tDD_NR_Bandwidth_Ratio_Coefficient);

    if (0 == pCell->numOfTotalSymbols) return tDD_NR_Bandwidth_Ratio_Coefficient;

    // the value is to be rounded off to 0.01, the fraction part of the division is intentionally discarded
    tDD_NR_Bandwidth_Ratio_Coefficient = (float) (0.01 * (100 * pCell->numOfUlSymbols / pCell->numOfTotalSymbols));

    return tDD_NR_Bandwidth_Ratio_Coefficient;
}

/****************************************************************************
 * @brief           Select value TDD LTE Bandwidth Ratio Coefficient based on PLDEutraCellInfo
 *
 * @param[in]       pEutraCell              : pointer to PLDEutraCellInfo data
 * @return          value                   : value of tDD_LTE_Bandwidth_Ratio_Coefficient
 ****************************************************************************/
float FnVCCB_Get_TDD_LTE_BandwidthRatioCoefficient(PLDEutraCellInfo *pEutraCell, uint16_t cellIdentity)
{
    float tDD_LTE_Bandwidth_Ratio_Coefficient = (float) TDD_LTE_BANDWIDTH_RATIO_COEFFICIENT;

    VALID_E_POINT_CHECK_RET_VAL(pEutraCell, tDD_LTE_Bandwidth_Ratio_Coefficient);

    if (cellIdentity > 255) return tDD_LTE_Bandwidth_Ratio_Coefficient;

    uint8_t mIB = pEutraCell->subframeAssignment[cellIdentity] & 0x80; // MIB bit of the subframeAssignment entry
    uint8_t oTh = pEutraCell->subframeAssignment[cellIdentity] & 0x7F; // other bites

    if (0 == mIB) return tDD_LTE_Bandwidth_Ratio_Coefficient;

    switch(oTh) {
        case 0:
            tDD_LTE_Bandwidth_Ratio_Coefficient = (float) 0.6;
        break;
        case 1:
            tDD_LTE_Bandwidth_Ratio_Coefficient = (float) 0.4;
        break;
        case 2:
            tDD_LTE_Bandwidth_Ratio_Coefficient = (float) 0.2;
        break;
        case 3:
            tDD_LTE_Bandwidth_Ratio_Coefficient = (float) 0.3;
        break;
        case 4:
            tDD_LTE_Bandwidth_Ratio_Coefficient = (float) 0.2;
        break;
        case 5:
            tDD_LTE_Bandwidth_Ratio_Coefficient = (float) 0.1;
        break;
        case 6:
            tDD_LTE_Bandwidth_Ratio_Coefficient = (float) 0.5;
        break;
        default:
        break;
    };

    return tDD_LTE_Bandwidth_Ratio_Coefficient;
}

/****************************************************************************
 * @brief           Select initial value for InitialUplink Path based on SCG Threshold functionality
 *
 * @param[in,out]   ptCi                    : pointer to UE Context
 * @param[in]       cellNum                 : cell for which measurement is being configured
 * @return          status                  : void
 ****************************************************************************/
void FnVCCB_SetInitialScgThreshold(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    
    // This API is considered for UL Primary Path for EN-DC.
    if (E_CALLTYPE_SA == ptCi->callType)
    {
        return;
    }
    
    if (VCCB_FLAG_ON == DBG->flag.logUlPathControl)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[scgThreshold] isImpacted %d, isEndcVipUe %u \n",
                FnVCCB_IsUlPathSwitchImpactedByVipUe(ptCi, ptCi->servCellNum), ptCi->isEndcVipUe);
    }
    
    if (FnVCCB_IsUlPathSwitchImpactedByVipUe(ptCi, ptCi->servCellNum) &&
        (FALSE == ptCi->isEndcVipUe))
    {
        ptCi->ulPathControl.curr.ulPdcpPath = UlPdcpPath_McgOnly;
        ptCi->ulPathControl.curr.nrUlCoverageState = OUT_NR_UL_COVERAGE_STATE;
        ptCi->isUlPathSwitchEnabled = false;
        return;
    }
    
    float scgFactor;
    const bool isSplitSupportUE = ptCi->ueInfo.ueCapa.mrdc.tddCapaAdd.general.splitDRB_withUL_Both_MCG_SCG;

    if (VCCB_FLAG_ON == DBG->flag.logUlPathControl)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[scgThreshold] weightNr %d, weightLTE %d \n",
        pCell->scgAdaptation.weightFactorNr, pCell->scgAdaptation.weightFactorLte);
    }

    if(ptCi->ulPathControl.prbUsageInformation != ENB_PRB_VALUE_ABSENCE) 
    {
        float nRBandwidthRatio;
        float compoundA, compoundB, divisor, bandwidthUlLte = BW_MIN_INIT_VALUE; // value for X2AP_bw6 = 0,;
        uint16_t nrScsUl, nrbUl, endPointX2Idx;
        uint8_t eutranCellId = 0;
        nrScsUl = (uint16_t)VLIB_ConvertEnumNrSubCarrierSpacingToKHz((uint8_t)(pCell->nrScsUl));
        nrbUl = (uint16_t)VLIB_ConvertEnumNrSystemBandwidthToNrb(pCell->nRbUl);
        eutranCellId = ((ptCi->eCGI.ci) & 0xFFL);  // eNB ID: 20bits, cell ID : 8bits (TBD: in case of Short Macro eNB)

        nRBandwidthRatio = (float)(nrbUl * (nrScsUl / 15));
        if(ci_DUPLEXTYPE_TDD == pCell->duplexMode)
        {
            nRBandwidthRatio *= FnVCCB_Get_TDD_NR_BandwidthRatioCoefficient(pCell);
        }
        compoundA = float(MAX(1, (nRBandwidthRatio*((float)pCell->cellRscInfo.ulCapacityValue))));

        if (HO_TYPE_MENB_INTERMNHO == ptCi->hoInfo.hoType.initiated)
        {
            endPointX2Idx = ptCi->hoInfo.targetEnb.x2Idx;
        }
        else
        {
            endPointX2Idx = ptCi->endPointInfo.x2Idx;
        }
        
        PLDEutraCellInfo  *const pEutraCell = &CFG->pldEutraCellInfo[ ptCi->gnbNum][endPointX2Idx];
        bandwidthUlLte = (float)FnVCCB_mapX2LteBandwidthUlEnumToValue((uint8_t)pEutraCell->ebandwidthUl[eutranCellId]);
        if(ci_DUPLEXTYPE_TDD == pEutraCell->cellType[eutranCellId])
        {
            bandwidthUlLte *= FnVCCB_Get_TDD_LTE_BandwidthRatioCoefficient(pEutraCell,eutranCellId);
        }
        compoundB = (float)(MAX((float)1, ((float)(bandwidthUlLte * ((uint16_t)(100-ptCi->ulPathControl.prbUsageInformation))))));
        
        scgFactor = (float)(pCell->scgAdaptation.weightFactorNr * compoundA);
        divisor = (float)(pCell->scgAdaptation.weightFactorLte * compoundB) + (float)(pCell->scgAdaptation.weightFactorNr * compoundA);
        if(divisor > 0)
        {
            scgFactor = (float)((float)scgFactor /  divisor);
            scgFactor *= 100;
        }
        else
        {
            scgFactor = 0;
        }
        if (VCCB_FLAG_ON == DBG->flag.logUlPathControl)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[scgThreshold] eutranCellType (%s), NRcellType (%s), bwLte (%7.4f) \n",
            ((pEutraCell->cellType[eutranCellId]==ci_DUPLEXTYPE_TDD) ? "TDD" : "FDD"),
            ((pCell->duplexMode==ci_DUPLEXTYPE_TDD) ? "TDD" : "FDD"),(double)bandwidthUlLte );
            VCCB_PRINT_CALL_COMMENT(ptCi, "[scgThreshold] prbLTE (%d), prbNR (%d) \n",
            ptCi->ulPathControl.prbUsageInformation, (100-pCell->cellRscInfo.ulCapacityValue)); 
            VCCB_PRINT_CALL_COMMENT(ptCi, "[scgThreshold] eBandwidthUl (%d), endpointX2Idx(%d), eutranCellId(%d)\n",
            (int)bandwidthUlLte, endPointX2Idx, eutranCellId );
            VCCB_PRINT_CALL_COMMENT(ptCi, "[scgThreshold] nRBandwidthRatio (%7.4f), compoundA (%7.4f) compoundB (%7.4f)\n",
            (double)nRBandwidthRatio, (double)compoundA, (double)compoundB);
        }
    }
    else
    {
        scgFactor = (float)((float)pCell->scgAdaptation.weightFactorNr / (float)(pCell->scgAdaptation.weightFactorNr + pCell->scgAdaptation.weightFactorLte));
        scgFactor *= 100;
    }

    /* The VCCB compares the random value with the scg-threshold probabilities value (X)
    If X is greater than or equal to the Random value, set it to Initial-SCG.
    If the random value is less than X, it is configured as Initial-MCG. */
    unsigned int randValue = FnVCCB_GetRandomValue(__func__, ptCi->gnbNum, MAX_SCG_PROBABILITYT_VALUE);
    VCCB_CHECK_E_RANGE_AND_VOID(randValue, MAX_SCG_PROBABILITYT_VALUE);
        VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
        if(1 == pGnb->cfg.debugUlPathForceRandValueFlag)
        {
            randValue = pGnb->cfg.forceUlPathRandValue;
        }
    const bool check_isScg = ((unsigned int)(scgFactor) >= randValue);
    ptCi->ulPathControl.curr.ulPrimaryPathMode = (check_isScg) ? initial_SCG : initial_MCG;
    VCCB_PRINT_CALL_COMMENT(ptCi,
    "[scgThreshold] random(%d), scgFactor(%d) !\n",
    randValue, (int)scgFactor);

    VCCB_PRINT_CALL_COMMENT(ptCi,
    "[scgThreshold] isSplitSupportUE(%d), "
    " ulPrimaryPathMode(%d) !\n",
    isSplitSupportUE, ptCi->ulPathControl.curr.ulPrimaryPathMode);

    return;
}

/****************************************************************************
 * @brief           Select initial value for primary ul path
 *
 * @param[in,out]   ptCi                    : pointer to UE Context
 * @return          status                  : void
 ****************************************************************************/
void VCCM_SelectInitialPrimaryUlPath(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(CELLINFO);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    // This API is considered for UL Primary Path for EN-DC.
    if (E_CALLTYPE_SA == ptCi->callType)
    {
        return;
    }

    const bool isSplitSupportUE = ptCi->ueInfo.ueCapa.mrdc.tddCapaAdd.general.splitDRB_withUL_Both_MCG_SCG;

    // Initialize with Init value
    ptCi->ulPathControl.curr.ulPdcpPath = UlPdcpPath_Init;

    // Initialize UL-Primary-Path-Mode value
    FnVCCB_SetUlPrimaryPathMode(ptCi, ptCi->servCellNum);

    // Initialize ulPdcpPath
    VCCM_SetSplitDrbUlPdcpPath(ptCi);

    // Check Threshold of QCI at ENDC NR Addition
    if (UlPdcpPath_McgShared == ptCi->ulPathControl.curr.ulPdcpPath)
    {
        uint8_t mcgOnlyCnt = 0;
        uint8_t erabCnt = 0;
        uint16_t erabIdx = 0;

        for (erabIdx = 0; erabIdx < MAX_ERAB_PER_CALL; erabIdx++)
        {
            if (ptCi->erabInfo[erabIdx].usage != CI_use) continue;

            if (SPLIT_Bearer == ptCi->erabInfo[erabIdx].bearerType)
            {
                erabCnt++;

                if (UlPdcpPath_McgOnly == ptCi->erabInfo[erabIdx].ulPdcpPath)
                {
                    mcgOnlyCnt++;
                }
            }
        }

        // If all DRBs are infinity, set ptCi->ulPathControl.curr.ulPdcpPath: McgOnly and set A1.
        if ((mcgOnlyCnt > 0) && (erabCnt == mcgOnlyCnt))
        {
            ptCi->ulPathControl.curr.ulPdcpPath = UlPdcpPath_McgOnly;
            ptCi->ulPathControl.prev.nrUlCoverageState = ptCi->ulPathControl.curr.nrUlCoverageState;
            ptCi->ulPathControl.curr.nrUlCoverageState = OUT_NR_UL_COVERAGE_STATE;
        }
    }

    VCCB_PRINT_CALL_MSG(ptCi,
        "[Select Initial Primary UL] ulPrimaryPathMode(%d->%d), ulPdcpPath(%u), isSplitSupportUE(%d), "
        "nrUlCoverageState(%d)!\n",
        CELLINFO[ptCi->servCellNum].ulPrimaryPathMode, ptCi->ulPathControl.curr.ulPrimaryPathMode,
        ptCi->ulPathControl.curr.ulPdcpPath, isSplitSupportUE, ptCi->ulPathControl.curr.nrUlCoverageState);

    return;
}

/****************************************************************************
 * @brief           Select initial value for UL Primarypathmode
 *
 * @param[in,out]   ptCi                    : pointer to UE Context
 * @param[in]       cellNum                 : pointer to structure containing temporary info of cell
 *available
 * @return          status                  : void
 ****************************************************************************/
void FnVCCB_SetUlPrimaryPathMode(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(CELLINFO);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    /*
       In case of Handover     : cellNum -> targetCellNum
       In case of Not Handover : cellNum -> servedCellNum
   */

    // This API is considered for UL Primary Path for EN-DC.
    if (E_CALLTYPE_SA == ptCi->callType)
    {
        return;
    }

    if (VCCB_FLAG_ON == DBG->flag.logUlPathControl)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[probabilityBasedSCG] isProbabilityOn %d, adaptationSwitch %u \n",
                FnVCCB_IsUlPrimaryPathModeInitScgProbability(cellNum),
                CELLINFO[cellNum].scgAdaptation.adaptationSwitch );
    }

    if (FnVCCB_IsUlPrimaryPathModeInitDynamicRSRPandRSRQ(cellNum))
    {
        // 'initial-Dynamic-RSRP-RSRQ' is same with 'initial-SCG' after initial attach.
        ptCi->ulPathControl.curr.ulPrimaryPathMode = initial_SCG;
    }
    else if(FnVCCB_IsUlPrimaryPathModeInitScgProbability(cellNum) &&
               (TRUE == CELLINFO[cellNum].scgAdaptation.adaptationSwitch))
    {
        if(cellNum != ptCi->servCellNum)
        {
            FnVCCB_SetInitialScgThreshold(ptCi, cellNum);
        }
        else if (VCCB_FLAG_ON == DBG->flag.logUlPathControl)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[scgThreshold] UE ulPrimaryPathMode %d kept in case of intra cell HO \n",
                ptCi->ulPathControl.curr.ulPrimaryPathMode);
        }
    }
    else if (FnVCCB_IsUlPrimaryPathModeInitScgProbability(cellNum) && 
             (TRUE != CELLINFO[ptCi->servCellNum].scgAdaptation.adaptationSwitch))
    {
        /* The VCCB compares the random value with the scg-probabilities value (X)
          If X is greater than or equal to the Random value, set it to Initial-SCG.
          If the random value is less than X, it is configured as Initial-MCG. */
        unsigned int randValue = FnVCCB_GetRandomValue(__func__, ptCi->gnbNum, MAX_SCG_PROBABILITYT_VALUE);
        VCCB_CHECK_E_RANGE_AND_VOID(randValue, MAX_SCG_PROBABILITYT_VALUE);
        VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
        if(1 == pGnb->cfg.debugUlPathForceRandValueFlag)
        {
            randValue = pGnb->cfg.forceUlPathRandValue;
        }
        const bool check_isScg = (pCell->scgProbability >= randValue);
        ptCi->ulPathControl.curr.ulPrimaryPathMode = (check_isScg) ? initial_SCG : initial_MCG;

        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[scgProbability] scgProbability(%u), randValue(%u), pathMode(%d) !\n",
            pCell->scgProbability, randValue, ptCi->ulPathControl.curr.ulPrimaryPathMode);
    }
    else if (FnVCCB_IsUlPrimaryPathModeInitSCG(cellNum))
    {
        ptCi->ulPathControl.curr.ulPrimaryPathMode = initial_SCG;
    }
    else  // initial-MCG
    {
        ptCi->ulPathControl.curr.ulPrimaryPathMode = initial_MCG;
    }
}

/****************************************************************************
 * @brief           Set Split Drb UlPdcpPath
 *                  call this function need to set DRB's ulPdcpPath
 * @param[in,out]   ptCi :          call information
 ****************************************************************************/
void VCCM_SetSplitDrbUlPdcpPath(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    //TODO 23B Add consideration for Data Stall Prevention vs Packet Inspection
    //As for 23A no design decision was provided and thus no implemention is done
    //Assumption is, never in 23A will PI be used
    // Packet Inspection Based UlPathSwitch
    if (TRUE == FnVCCB_PacketInspectionONQciBasedUlSplitThSwitchOFF(ptCi))
    {
        // Set ulPdcpPath to 'UlPdcpPath_ScgShared' only in case of (QCI9 && packetInspectionQciFlag on) or (QCI128)
        for (uint16_t erabIdx = 0; erabIdx < MAX_ERAB_PER_CALL; erabIdx++)
        {
            if (ptCi->erabInfo[erabIdx].usage != CI_use)
            {
                continue;
            }
            if (SPLIT_Bearer == ptCi->erabInfo[erabIdx].bearerType)
            {
                if (((9 == ptCi->erabInfo[erabIdx].erabQos.qciValue.QCI) &&
                        (VCCB_FLAG_ON == ptCi->erabInfo[erabIdx].packetInspectionQciFlag)) ||
                    (128 == ptCi->erabInfo[erabIdx].erabQos.qciValue.QCI))
                {
                    ptCi->erabInfo[erabIdx].ulPdcpPathPrev = ptCi->erabInfo[erabIdx].ulPdcpPath;
                    ptCi->erabInfo[erabIdx].ulPdcpPath = UlPdcpPath_ScgShared;
                }
                else
                {
                    ptCi->erabInfo[erabIdx].ulPdcpPathPrev = ptCi->erabInfo[erabIdx].ulPdcpPath;
                    ptCi->erabInfo[erabIdx].ulPdcpPath = UlPdcpPath_McgOnly;
                }
            }
        }
    }
    else
    {
        // Update previous DB
        for (uint16_t erabIdx = 0; erabIdx < MAX_ERAB_PER_CALL; erabIdx++)
        {
            if (ptCi->erabInfo[erabIdx].usage != CI_use) continue;

            if (SPLIT_Bearer == ptCi->erabInfo[erabIdx].bearerType)
            {
                ptCi->erabInfo[erabIdx].ulPdcpPathPrev = ptCi->erabInfo[erabIdx].ulPdcpPath;
            }
        }

        // Update yang parameter
        if (GOOD != VCCM_UpdateUlPdcpPathParameter(ptCi))
        {
            return;
        }

        // Update DRB DB
        for (callERABInfo_type &erabInfo : ptCi->erabInfo)
        {
            if (erabInfo.usage != CI_use) continue;

            if (SPLIT_Bearer == erabInfo.bearerType)
            {
                erabInfo.ulPdcpPath = ptCi->ulPathControl.curr.ulPdcpPath;

                const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

                if (VCCB_FLAG_ON == DBG->flag.logUlPathControl)
                {
                    VCCB_PRINT_CALL_COMMENT(ptCi, "ulPdcpPath %u, HighLatencyIndication %s, nrUlCoverageState %u, PreferredUlPrimaryPath %u\n",
                            ptCi->ulPathControl.curr.ulPdcpPath,  ptCi->HighLatencyIndication == 0 ? "High" : "Low", ptCi->ulPathControl.curr.nrUlCoverageState, 
                            pCell->pdcpLatencyPreferredUlPrimaryPath);
                }

                // Update ulPdcpPath from Shared to Only when 'DataSplitThreshold is infinity'
                switch (ptCi->ulPathControl.curr.ulPdcpPath)
                {
                    case UlPdcpPath_McgShared:
                        if (NRRRC_UL_DataSplitThreshold_infinity == FnVCCB_GetUlDataSplitThreshold(ptCi, &erabInfo))
                        {
                            if (High_Latency == ptCi->HighLatencyIndication)
                            {
                                if (PreferredUlPrimaryPath_Scg == pCell->pdcpLatencyPreferredUlPrimaryPath)
                                {
                                    if ((IN_NR_UL_COVERAGE_STATE == ptCi->ulPathControl.curr.nrUlCoverageState) &&
                                        (true != ptCi->ulPathControl.ueCongestionState))
                                    {
                                        erabInfo.ulPdcpPath = UlPdcpPath_ScgOnly;
                                    }
                                    else if (OUT_NR_UL_COVERAGE_STATE == ptCi->ulPathControl.curr.nrUlCoverageState)
                                    {
                                        erabInfo.ulPdcpPath = UlPdcpPath_McgOnly;
                                    }
                                }
                                else
                                {
                                    erabInfo.ulPdcpPath = UlPdcpPath_McgOnly;
                                }
                            }
                            else
                            {
                                erabInfo.ulPdcpPath = UlPdcpPath_McgOnly;
                            }
                        }
                        break;
                    case UlPdcpPath_ScgShared:
                        if (NRRRC_UL_DataSplitThreshold_infinity == FnVCCB_GetUlDataSplitThreshold(ptCi, &erabInfo))
                        {
                            if (High_Latency == ptCi->HighLatencyIndication)
                            {
                                if (PreferredUlPrimaryPath_Scg == pCell->pdcpLatencyPreferredUlPrimaryPath)
                                {
                                    if (IN_NR_UL_COVERAGE_STATE == ptCi->ulPathControl.curr.nrUlCoverageState)
                                    {
                                        erabInfo.ulPdcpPath = UlPdcpPath_ScgOnly;
                                    }
                                    else if (OUT_NR_UL_COVERAGE_STATE == ptCi->ulPathControl.curr.nrUlCoverageState)
                                    {
                                        erabInfo.ulPdcpPath = UlPdcpPath_McgOnly;
                                    }
                                }
                                else
                                {
                                    erabInfo.ulPdcpPath = UlPdcpPath_McgOnly;
                                }
                            }
                            else
                            {
                                erabInfo.ulPdcpPath = UlPdcpPath_ScgOnly;
                            }
                        }
                        break;
                    default:
                        break;
                }
            }
        }
    }
}


/****************************************************************************
 * @brief           Select initial value for Initial-Dynamic-RSRP-RSRQ
 *
 * @param[in,out]   ptCi                    : pointer to UE Context
 * @param[in]       cellNum                 : cell for which measurement is being configured
 * @return          status                  : void
 ****************************************************************************/
void FnVCCB_SetInitialDynamicRsrpRsrq(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    // This API is considered for UL Primary Path for EN-DC.
    if (E_CALLTYPE_SA == ptCi->callType)
    {
        return;
    }
    
    if (VCCB_FLAG_ON == DBG->flag.logUlPathControl)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Init RsrpRsrq IsUlPathSwitchImpactedByVipUe %d, isEndcVipUe %u \n",
                FnVCCB_IsUlPathSwitchImpactedByVipUe(ptCi, ptCi->servCellNum), ptCi->isEndcVipUe);
    }
    if (FnVCCB_IsUlPathSwitchImpactedByVipUe(ptCi, ptCi->servCellNum) &&
        (FALSE == ptCi->isEndcVipUe))
    {
        ptCi->ulPathControl.curr.ulPdcpPath = UlPdcpPath_McgOnly;
        ptCi->ulPathControl.curr.nrUlCoverageState = OUT_NR_UL_COVERAGE_STATE;
        ptCi->isUlPathSwitchEnabled = false;
        return;
    }
    servingCellMeasInitialInfo_type measResult;
    uint8_t yangThreshold = 0;
    uint8_t rsrpRsrqFlag = FALSE;  // flag to check reported NR RSRP/RSRQ implies
    uint8_t rsrpRsrqValue = 0;     // measResult in X2 Addition Request

    const bool isSplitSupportUE = ptCi->ueInfo.ueCapa.mrdc.tddCapaAdd.general.splitDRB_withUL_Both_MCG_SCG;
    FnVCCB_getServingCellMeasInitialInfo(ptCi, &measResult);

    const uint8_t isRSRQ = FnVCCB_IsScgFailureRSRQmodeForDynamicSelection(ptCi->gnbNum);

    if (isRSRQ)  // RSRQ
    {
        yangThreshold = pGnb->cfg.scgFailureHandlingInfo.rsrqThreshold;
        rsrpRsrqFlag = measResult.rsrqFlag;
        rsrpRsrqValue = measResult.rsrq;
    }
    else  // RSRP
    {
        yangThreshold = pGnb->cfg.scgFailureHandlingInfo.rsrpThreshold;
        rsrpRsrqFlag = measResult.rsrpFlag;
        rsrpRsrqValue = measResult.rsrp;
    }

    if(TRUE == VCCM_SetDataStallConfiguration(ptCi, cellNum))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
        "[FnVCCB_SetInitialDynamicRsrpRsrq] : Data Stall Prevention triggered, setting ulPath to MCG Only!\n");
        return;
    }

    if (FnVCCB_IsCongestionStateActive(ptCi))
    {
        ptCi->ulPathControl.curr.ulPdcpPath = UlPdcpPath_McgShared;
    }
    else
    {
        const bool check_value = (rsrpRsrqFlag && rsrpRsrqValue > yangThreshold);
        if (isSplitSupportUE)
        {
            ptCi->ulPathControl.curr.ulPdcpPath = ((check_value) ? UlPdcpPath_ScgShared : UlPdcpPath_McgShared);
        }
        else
        {
            ptCi->ulPathControl.curr.ulPdcpPath = ((check_value) ? UlPdcpPath_ScgOnly : UlPdcpPath_McgOnly);
        }
    }

    VCCB_PRINT_CALL_INFORMATIVE(ptCi,
        "[Dynamic_RSRP_RSRQ] isRSRQ(%d), measResult(rsrp:%d, rsrq:%d), yangThreshold(%d), isSplitSupportUE(%d), "
        "ulPdcpPath(%d) !\n",
        isRSRQ, measResult.rsrp, measResult.rsrq, yangThreshold, isSplitSupportUE, ptCi->ulPathControl.curr.ulPdcpPath);

    return;
}

/****************************************************************************
 * @brief           Set FnVCCB_SetPtciUlPdcpPath
 *                  call this function need to set ptCi's ulPdcpPath
 * @param[in,out]   ptCi :          call information
 * @param[in]       cellNum :       cell for which measurement is being configured
 ****************************************************************************/
void FnVCCB_SetPtciUlPdcpPath(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    /*
        In case of Handover     : cellNum -> targetCellNum
        In case of Not Handover : cellNum -> servedCellNum
    */
    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    const bool isSplitSupportUE = ptCi->ueInfo.ueCapa.mrdc.tddCapaAdd.general.splitDRB_withUL_Both_MCG_SCG;

    if(TRUE == VCCM_SetDataStallConfiguration(ptCi, cellNum))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
        "[FnVCCB_SetPtciUlPdcpPath] : Data Stall Prevention triggered, setting ulPath to MCG Only!\n");
        return;
    }

    if (VCCB_FLAG_ON == DBG->flag.logUlPathControl)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SetPtciUlPdcpPath IsUlPathSwitchImpactedByVipUe %d, isEndcVipUe %u \n",
                FnVCCB_IsUlPathSwitchImpactedByVipUe(ptCi, ptCi->servCellNum), ptCi->isEndcVipUe);
    }

    if (FnVCCB_IsUlPathSwitchImpactedByVipUe(ptCi, cellNum) &&
        (FALSE == ptCi->isEndcVipUe))
    {
        ptCi->ulPathControl.curr.ulPdcpPath = UlPdcpPath_McgOnly;
        ptCi->ulPathControl.curr.nrUlCoverageState = OUT_NR_UL_COVERAGE_STATE;
        ptCi->isUlPathSwitchEnabled = false;
    }
    else
    if (FnVCCB_IsCongestionStateActive(ptCi))
    {
        ptCi->ulPathControl.curr.ulPdcpPath = isSplitSupportUE ? UlPdcpPath_McgShared : UlPdcpPath_McgOnly;
    }
    else
    {
        if (initial_SCG == ptCi->ulPathControl.curr.ulPrimaryPathMode)
        {
            ptCi->ulPathControl.curr.ulPdcpPath = isSplitSupportUE ? UlPdcpPath_ScgShared : UlPdcpPath_ScgOnly;
        }
        else
        {
            ptCi->ulPathControl.curr.ulPdcpPath = isSplitSupportUE ? UlPdcpPath_McgShared : UlPdcpPath_McgOnly;
        }
    }
    
    VCCB_PRINT_CALL_COMMENT(ptCi,
        "[UlPath] : isSplitSupportUE(%d), ulPdcpPath(%d), coverageMethod(%d), ulPrimaryPathMode(%d)\n",
        isSplitSupportUE, ptCi->ulPathControl.curr.ulPdcpPath, pCell->nrUlCoverageMethod, pCell->ulPrimaryPathMode);
}

/****************************************************************************
 * @brief           Check whether it should be set to MCGOnly during 'Intra-SgNB HO(Resume), Intra-MeNB HO'
 * @param[in,out]   ptCi :          call information
 * @return          true/false
 ****************************************************************************/
bool FnVCCB_Check_toSet_McgOnlyUlPathENDC_during_HO(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // This API is considered for UL Primary Path for EN-DC during Intra gNB HO.
    if ((E_CALLTYPE_SA == ptCi->callType) || (IntraRatHO_cmd != ptCi->stateCmd))
    {
        return false;
    }

    /* 1) If thre are several drb but there is a MCG/infinity(threshold) during HO,
          Set all drb to MCGOnly and set A1 measurement. */
    if (UlPdcpPath_McgShared == ptCi->ulPathControl.curr.ulPdcpPath)
    {
        for (callERABInfo_type &erabInfo : ptCi->erabInfo)
        {
            if (erabInfo.usage != CI_use) continue;

            if (SPLIT_Bearer == erabInfo.bearerType)
            {
                if (NRRRC_UL_DataSplitThreshold_infinity == FnVCCB_GetUlDataSplitThreshold(ptCi, &erabInfo))
                {
                    VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                        "[UlPath] Maintain MCG UL path because found Erab(%d) threshold is infinity \n",
                        erabInfo.dRBId);
                    return true;
                }
            }
        }
    }

    /* 2) Maintain MCG path in case of source Cell is already MCG only by ULPathControl or
          All drb's threshold is infinity. */
    else if (UlPdcpPath_McgOnly == ptCi->ulPathControl.curr.ulPdcpPath)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[UlPath] Maintain MCG UL path in case of MCG only \n");
        return true;
    }

    return false;
}

/****************************************************************************
 * @brief           Set VCCM_SetUlPdcpPathParameter
 *                  call this function need to update ptCi's ulPdcpPath
 * @param[in,out]   ptCi :          call information
 * @return          status :        GOOD, BREAK / int16_t
 ****************************************************************************/
int16_t VCCM_UpdateUlPdcpPathParameter(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    // [EN-DC] Initialize UlPdcpPath in case of 'initial-Attach' and 'Inter-SgNB HO' (Initial Conf.)
    if (UlPdcpPath_Init == ptCi->ulPathControl.curr.ulPdcpPath)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "[UlPath] Initialize UlPdcpPath in case of 'initial-Attach' and 'Inter-SgNB HO' \n");
        
        if(TRUE == FnVCCB_MarkCongestionStateUe(ptCi, ptCi->servCellNum))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[FnVCCB_SetPtciUlPdcpPath] : UE Congestion State active\n");
        }

        if (VCCB_FLAG_ON == DBG->flag.logUlPathControl)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[probabilityBasedSCG] isProbabilityOn %d, adaptationSwitch %u \n",
                    FnVCCB_IsUlPrimaryPathModeInitScgProbability(ptCi->servCellNum),
                    CELLINFO[ptCi->servCellNum].scgAdaptation.adaptationSwitch );
        }
        // Initialize ptCi->ulPathControl.curr.ulPdcpPath
        if(FnVCCB_IsUlPrimaryPathModeInitScgProbability(ptCi->servCellNum) &&
           (TRUE == CELLINFO[ptCi->servCellNum].scgAdaptation.adaptationSwitch))
        {
            FnVCCB_SetInitialScgThreshold(ptCi, ptCi->servCellNum);
            FnVCCB_SetPtciUlPdcpPath(ptCi, ptCi->servCellNum);
        }
        else if (FnVCCB_IsUlPrimaryPathModeInitDynamicRSRPandRSRQ(ptCi->servCellNum))
        {
            FnVCCB_SetInitialDynamicRsrpRsrq(ptCi, ptCi->servCellNum);
        }
        else
        {
            FnVCCB_SetPtciUlPdcpPath(ptCi, ptCi->servCellNum);
        }
    }
    // [EN-DC] Initialize UlPdcpPath in case of Handover WO SgNB Change
    else
    {
        if (IntraRatHO_cmd == ptCi->stateCmd)
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->hoInfo.targetCellNum, MAX_CELL_NUM_VCCB);

            if(TRUE == FnVCCB_MarkCongestionStateUe(ptCi, ptCi->hoInfo.targetCellNum))
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "[FnVCCB_SetPtciUlPdcpPath] : UE Congestion State active\n");
            }

            // Set UL Primary Path Mode according to Target cell
            FnVCCB_SetUlPrimaryPathMode(ptCi, ptCi->hoInfo.targetCellNum);

            // 1) Initialize UlPdcpPath in case of Inter-MeNB HO (Initial Conf.)
            if (HO_TYPE_MENB_INTERMNHO == ptCi->hoInfo.hoType.initiated)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "[UlPath] Initialize UlPdcpPath in case of 'Inter-MeNB HO' \n");
                ptCi->ulPathControl.prev.nrUlCoverageState = ptCi->ulPathControl.curr.nrUlCoverageState;
                ptCi->ulPathControl.curr.nrUlCoverageState = IN_NR_UL_COVERAGE_STATE;
                FnVCCB_SetPtciUlPdcpPath(ptCi, ptCi->hoInfo.targetCellNum);
            }
            // 2) Initialize UlPdcpPath in case of 'Intra-SgNB HO, intra-SgNB SCG Resume, Intra-MeNB HO'
            else
            {
                VCCB_PRINT_CALL_COMMENT(
                    ptCi, "[UlPath] Initialize UlPdcpPath in case of 'Intra-SgNB HO and Intra-MeNB HO' \n");

                // Check whether it should be set to MCGOnly during 'Intra-SgNB HO(Resume), Intra-MeNB HO'
                if (true == FnVCCB_Check_toSet_McgOnlyUlPathENDC_during_HO(ptCi))
                {
                    ptCi->ulPathControl.curr.ulPdcpPath = UlPdcpPath_McgOnly;
                    if(TRUE == VCCM_SetDataStallConfiguration(ptCi, ptCi->hoInfo.targetCellNum))
                    {
                        VCCB_PRINT_CALL_COMMENT(ptCi,
                        "[McgOnlyUlPathENDC during HO] : Data Stall Prevention triggered, setting ulPath to MCG Only!\n");
                    }
                    ptCi->ulPathControl.prev.nrUlCoverageState = ptCi->ulPathControl.curr.nrUlCoverageState;
                    ptCi->ulPathControl.curr.nrUlCoverageState = OUT_NR_UL_COVERAGE_STATE;
                    return GOOD;
                }

                // 2.2) Initialize UlPdcpPath according to target cell.
                FnVCCB_SetPtciUlPdcpPath(ptCi, ptCi->hoInfo.targetCellNum);
            }
        }
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Change cell state to Normal/Congestion
 *
 * @param[in,out]   ptMsg   :       cell information
 * @param[in]       cellNum :       cell for which state is being changed
 * @return          status  :       void
 ****************************************************************************/
void FnVCCB_ChangeCellCongestionState(sonCellPrbRsc_type *ptMsg, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptMsg);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    if (VCCB_FLAG_ON == DBG->flag.logUlPathControl)
    {
        VCCB_PRINT_COMMENT("FnVCCB_ChangeCellCongestionState cell %u \n",
                cellNum);
    }
        
    if(NORMAL_STATE == CELLINFO[cellNum].ulPathCongestionBased.congestionState)
    {
        if(ptMsg->ulCceFailRate >= CELLINFO[cellNum].ulPathCongestionBased.ccceFailCongestionInThreshold || 
            (100 - ptMsg->ulCapacityValue) >= CELLINFO[cellNum].ulPathCongestionBased.prbUsageCongestionInThreshold)
        {
            CELLINFO[cellNum].ulPathCongestionBased.congestionState = CONGESTED_STATE;
            VCCB_PRINT_COMMENT("[UlPath][CCCE] Cell state changed to Congestion for cellNum = %d \n", cellNum);
        }
    }
    else if (CONGESTED_STATE == CELLINFO[cellNum].ulPathCongestionBased.congestionState)
    {
        if(ptMsg->ulCceFailRate <= CELLINFO[cellNum].ulPathCongestionBased.ccceFailCongestionOutThreshold && 
            (100 - ptMsg->ulCapacityValue) <= CELLINFO[cellNum].ulPathCongestionBased.prbUsageCongestionOutThreshold)
        {
            CELLINFO[cellNum].ulPathCongestionBased.congestionState = NORMAL_STATE;
            VCCB_PRINT_COMMENT("[UlPath][CCCE] Cell state changed to Normal for cellNum = %d \n", cellNum);
        }
    }

    return;
}

bool FnVCCB_IsVipUeUlPathSwitchActive(uint16_t gnbNum)
{
    return (GNBINFO[gnbNum].cfg.arpBasedUlPathSwitchTimerValue > 0);
}

bool FnVCCB_IsUlPathSwitchImpactedByVipUe(callInfo_type *ptCi, uint16_t cellNum)
{
    return
        (FnVCCB_IsVipUeUlPathSwitchActive(ptCi->gnbNum) &&
         (CELLINFO[cellNum].isUlPathVipUeTimerRunning));
}

bool FnVCCB_IsUlPathSwitchPreventedByVipUe(callInfo_type *ptCi)
{
    return
        ((!ptCi->isUlPathSwitchEnabled) ||
         (FnVCCB_IsUlPathSwitchImpactedByVipUe(ptCi, ptCi->servCellNum) &&
         (ptCi->ulPathControl.curr.nrUlCoverageState == OUT_NR_UL_COVERAGE_STATE) &&
         (FALSE == ptCi->isEndcVipUe)));
}

bool FnVCCB_InstallA1PreventedByVipUe(callInfo_type *ptCi)
{
    return
        ((!ptCi->isUlPathSwitchEnabled) &&
         (FALSE == ptCi->isEndcVipUe));
}


void FnVCCB_StartUlPathVipUeTimer(uint16_t gnbNum, uint16_t cellNum)
{
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    if (VCCB_FLAG_ON == DBG->flag.logUlPathControl)
    {
        VCCB_PRINT_COMMENT("Attempting to start InternalUlPathVipUeTimer gnbNum %u, cellNum %u \n", gnbNum, cellNum);
    }

    if (FALSE == FnVCCB_IsVipUeUlPathSwitchActive(gnbNum))
    {
        return;
    }
    MUTEX_LOCK(&CELLINFO[cellNum].ulPathVipUeTimer.mutex);
    CELLINFO[cellNum].isUlPathVipUeTimerRunning = true;
    VLIB_AttachTimerCore(&CELLINFO[cellNum].UlPathVipUeTimer, cellNum, timInternalUlPathVipUeTimer_id, 0, 0,
        GNBINFO[gnbNum].cfg.arpBasedUlPathSwitchTimerValue*1000, VCCB_NONUE_ADDR.MdsPort, VCCB_TIMER_TEMPORARY, 0);
    MUTEX_UNLOCK(&CELLINFO[cellNum].ulPathVipUeTimer.mutex);
}

void FnVCCB_StopUlPathViUeTimer(uint16_t cellNum)
{
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    
    MUTEX_LOCK(&CELLINFO[cellNum].ulPathVipUeTimer.mutex);
    CELLINFO[cellNum].isUlPathVipUeTimerRunning = false;
    MUTEX_UNLOCK(&CELLINFO[cellNum].ulPathVipUeTimer.mutex);
}

uint8_t FnVCCB_MarkCongestionStateUe(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);
    uint8_t status = FALSE;
    ptCi->ulPathControl.ueCongestionState = false;

    if (FnVCCB_IsVipUeUlPathSwitchActive(ptCi->gnbNum) || VCCB_FLAG_ON == GNBINFO[ptCi->gnbNum].cfg.qciBasedUlSplitThSwitch) return status;

    if(((CONGESTED_STATE == CELLINFO[cellNum].ulPathCongestionBased.congestionState) && (TRUE == CELLINFO[cellNum].ulPathCongestionBased.congestionUlPathEnabled))
        || ((CONGESTED_STATE == CELLINFO[cellNum].ulPathCongestionBased.congestionStateSliceLoad) && (TRUE == CELLINFO[cellNum].ulPathCongestionBased.ulSliceLoadBasedUlPathSwitchingOnOff)))
    {
        ptCi->ulPathControl.ueCongestionState = true;
        status = TRUE;
    }

    return status;

}

bool FnVCCB_IsCongestionStateActive(const callInfo_type *ptCi)
{ 
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (FnVCCB_IsVipUeUlPathSwitchActive(ptCi->gnbNum) || VCCB_FLAG_ON == GNBINFO[ptCi->gnbNum].cfg.qciBasedUlSplitThSwitch) return false;

    return ptCi->ulPathControl.ueCongestionState;
}

bool FnVCCB_PacketInspectionONQciBasedUlSplitThSwitchOFF(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);

    return (VCCB_FLAG_ON == GNBINFO[ptCi->gnbNum].cfg.packetInspectionBasedUlPathSwitch && VCCB_FLAG_ON != GNBINFO[ptCi->gnbNum].cfg.qciBasedUlSplitThSwitch);
}

/**
 * @brief   FGR-CC5003 Ul Path Control in EN-DC
 * @details Check if ENDC call have any ARP 2 bearer. If it does, mark UE as a subject to 
 *          change UE threshold FRs FR220~223.
 *          This function should be called only in case of Initial Addition
 * @param   [in] ptCi : pointer to Call Context
 * @return  void
 */
void FnVCCB_MarkArp2UeForUlPathThreshSwitch(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    // Check VIP UE by ARP2 existence
    uint8_t drbIdx = 0;
    for (drbIdx = 0; drbIdx < MAX_ERAB_PER_CALL; ++drbIdx)
    {
        if (CI_use != ptCi->erabInfo[drbIdx].usage)
        {
            continue;
        }
 
        if (ARP2_VIP_UE == ptCi->erabInfo[drbIdx].erabQos.aRP.priority)
        {
            ptCi->ulPathControl.prev.qci128SwitchFlag = ptCi->ulPathControl.curr.qci128SwitchFlag;
            ptCi->ulPathControl.curr.qci128SwitchFlag = VCCB_FLAG_ON;
            break;
        }
    }
}

/****************************************************************************
 * @brief           FGR-CC5003 Ul Path Control in EN-DC
 * @details         Reset congestion in case when all slices are deleted - FR232
 *
 * @param[in]       pGnb    :       pt to gNBInfo
 * @param[in]       gnbNum  :       gnb number
 ****************************************************************************/
void FnVCCB_ResetCongestion(VccbGnbInfo_type *pGnb, uint16_t gnbNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pGnb);
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    
    uint16_t cellNum;
    VccbCellInfo_type *pCell;

    for (int sliceIdx=0; sliceIdx<MAX_ACTIVE_SLICE_NUM;++sliceIdx)
    {
        if (CI_use == pGnb->sliceLoadControlInfo[sliceIdx].usage) return;
    }

    for (cellNum = 0; cellNum < MAX_CELL_NUM_VCCB; cellNum++)
    {
        pCell = &CELLINFO[cellNum];
        VALID_E_POINT_CHECK_VOID(pCell);

        if (pCell->gnbNum != gnbNum)
        {
            continue;
        }
            
        pCell->ulPathCongestionBased.congestionStateSliceLoad = NORMAL_STATE;
        VCCB_PRINT_COMMENT("[UlPath][SLICE] Cell state changed to Normal for cellNum = %d \n", cellNum);
    }
    
}

/****************************************************************************
 * @brief           FGR-CC5003 Ul Path Control in EN-DC
 * @details         Check if Congestion In conditions for the cell - FR232
 *
 * @param[in]       pGnb    :       pt to gNBInfo
 * @param[in]       pCell   :       pt to Cell info
 * @return          status  :       true/false
 ****************************************************************************/
bool FnVCCB_Check_UlPathENDC_Cell_CongestionIn(VccbGnbInfo_type *pGnb, VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(pGnb, false);
    VALID_E_POINT_CHECK_RET_VAL(pCell, false);
    
    int j = -1;
    for (int i=0; i<MAX_ACTIVE_SLICE_NUM;++i)
    {
       if (i >= pCell->cellCacInfo.sliceCount)
          break;
       if (-1 == pCell->cellCacInfo.sliceCac[i].ulSliceCapacity)
           continue;
       if (! (100 >= pCell->cellCacInfo.sliceCac[i].ulSliceCapacity) )
           continue;
       j = pCell->cellCacInfo.sliceCac[i].sliceIndex;
       if ( j < 0 || j >= MAX_ACTIVE_SLICE_NUM )
           continue;
       if ( pGnb->plmnIndexInfo[pGnb->sliceLoadControlInfo[j].plmnIndex].longId != pCell->cellCacInfo.gnbPlmn.longId
         && EQUIP != pGnb->plmnIndexInfo[pGnb->sliceLoadControlInfo[j].plmnIndex].shmStatus )
           continue;

       // CongestionIn condition fulfilled
       if ( pCell->cellCacInfo.sliceCac[i].ulSliceCapacity
          <= pGnb->sliceLoadControlInfo[j].sliceAwareLbConf.ulSliceCapaThreshUlPathSwitching )
           return TRUE;
    }

    return FALSE;
}

/****************************************************************************
 * @brief           FGR-CC5003 Ul Path Control in EN-DC
 * @details         Check if Congestion Out conditions for the cell - FR232
 *
 * @param[in]       pGnb    :       pt to gNBInfo
 * @param[in]       pCell   :       pt to Cell info
 * @return          status  :       true/false
 ****************************************************************************/
bool FnVCCB_Check_UlPathENDC_Cell_CongestionOut(VccbGnbInfo_type *pGnb, VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(pGnb, false);
    VALID_E_POINT_CHECK_RET_VAL(pCell, false);

    bool valid_config_exists = false;

    int j = -1;
    for (int i=0; i<MAX_ACTIVE_SLICE_NUM;++i)
    {
       if (i >= pCell->cellCacInfo.sliceCount)
          break;
       if (-1 == pCell->cellCacInfo.sliceCac[i].ulSliceCapacity)
           continue;
       if (! (100 >= pCell->cellCacInfo.sliceCac[i].ulSliceCapacity) )
           continue;
       valid_config_exists = true;
       j = pCell->cellCacInfo.sliceCac[i].sliceIndex;
       if ( j < 0 || j >= MAX_ACTIVE_SLICE_NUM )
           continue;
       if ( pGnb->plmnIndexInfo[pGnb->sliceLoadControlInfo[j].plmnIndex].longId != pCell->cellCacInfo.gnbPlmn.longId
         && EQUIP != pGnb->plmnIndexInfo[pGnb->sliceLoadControlInfo[j].plmnIndex].shmStatus )
           continue;

       if ( pCell->cellCacInfo.sliceCac[i].ulSliceCapacity
            >= (pGnb->sliceLoadControlInfo[j].sliceAwareLbConf.ulSliceCapaThreshUlPathSwitching
               + pGnb->sliceLoadControlInfo[j].sliceAwareLbConf.deltaUlSliceCapaUlPathSwitching) )
           continue;

       // no CongestionOut condition fulfilled
       return FALSE;
    }

    return valid_config_exists;
}

/****************************************************************************
 * @brief           FGR-CC5003 Ul Path Control in EN-DC
 * @details         Ul Path  - FR247
 *
 * @param[in,out]   ptCi                    : pointer to UE Context
 * @param[in,out]   erabInfo                : reference for the erab context.
 * @param[in]       cellNum                 : pointer to structure containing temporary info of cell
 * @param[in]       mcgUlTrafficFlag        : ul path configuration for MCG
 * @param[in]       scgUlTrafficFlag        : ul path configuration for SCG
 *available
 * @return          status                  : void
 ****************************************************************************/
void FnVCCB_SetUlPathSwitchwithHighLatency(callInfo_type *ptCi, uint16_t cellNum, uint16_t mcgUlTrafficFlag, 
    uint16_t scgUlTrafficFlag, callERABInfo_type &erabInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    if (((E1_only == mcgUlTrafficFlag) && (E1_no_data == scgUlTrafficFlag)) ||
        ((E1_no_data == mcgUlTrafficFlag) && (E1_only == scgUlTrafficFlag) &&
         (PreferredUlPrimaryPath_Mcg == pCell->pdcpLatencyPreferredUlPrimaryPath)))
    {
        if (UlPdcpPath_McgOnly != erabInfo.ulPdcpPath)
        {
            // UlPdcpPath_ScgShared, UlPdcpPath_McgShared, UlPdcpPath_ScgOnly
            erabInfo.ulPdcpPathEnq = VCCB_FLAG_ON;
            erabInfo.ulPdcpPathEnqToSet = UlPdcpPath_McgOnly;
            SET_MOD_ON_ULP_IN_IDLE(ptCi, erabInfo);
        }
        else
        {
            erabInfo.ulPdcpPathEnq = VCCB_FLAG_OFF;
            erabInfo.ulPdcpPathToMod = UlConfigBearer_ModUnable;
        }
    }
    else
    {
        erabInfo.ulPdcpPathEnq = VCCB_FLAG_ON;
        erabInfo.ulPdcpPathEnqToSet = UlPdcpPath_ScgOnly;
        SET_MOD_ON_ULP_IN_IDLE(ptCi, erabInfo);
    }

}
