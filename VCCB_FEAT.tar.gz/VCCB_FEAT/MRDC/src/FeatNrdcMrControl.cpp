#include "FeatNrdcMrControl.hpp"
#include "VccbDefine.h"
#include "FeatMeasurements.hpp"
#include "ComCppWrapper.h"
#include "ComMacro.h"
#include "ComInline.h"
#include <memory>
#include <numeric>
#include <algorithm>
#include <string>
#include <sstream>
#include "FeatCommon.h"
#include "ComLibUtility.h"

constexpr const char *FAST_ACCESS_LOG_PREFIX = "[FastAccess]";

resourcePair_s NrdcSonNbrResourceManager::calculateAvailableResourcePair(const sonNbrPrbRsc_type &rNbrPrb)
{
    auto totalCCCV = rNbrPrb.ulCCCV + rNbrPrb.dlCCCV;
    if (totalCCCV == 0)
    {
        return INVALID_RESOURCE_PAIR;
    }

    auto calculateAvailableResource = [&](CapacityOption::Type capacityType) -> double
    {
        double capacityValue = (capacityType == CapacityOption::Type::UL) ? rNbrPrb.ulCapacityValue : rNbrPrb.dlCapacityValue;
        double cccvValue = (capacityType == CapacityOption::Type::UL) ? rNbrPrb.ulCCCV : rNbrPrb.dlCCCV;

        return rNbrPrb.dlTotalBandwidth * (capacityValue * cccvValue / static_cast<double>(totalCCCV));
    };

    return {calculateAvailableResource(CapacityOption::Type::DL), calculateAvailableResource(CapacityOption::Type::UL)};
}

void NrdcSonNbrResourceManager::insertToFrequencyResourcesMap(uint32_t nbrSsbFreq, const resourcePair_s &resourcePair)
{
    auto &frequencyResources = _frequencyResourceMap[nbrSsbFreq];
    frequencyResources.dl.emplace_back(resourcePair.dl);
    frequencyResources.ul.emplace_back(resourcePair.ul);
}

void NrdcSonNbrResourceManager::printFrequencyResourcesMap()
{
    if (not DBG->flag.nrdcMrControl) return;

    VCCB_PRINT_CALL_NRDC_MR_CONTROL("[NrdcSonNbrResourceManager] ============= Build Frequency Available Resource Map ===========\n");
    for (const auto &[ssbFreq, frequencyResources] : _frequencyResourceMap)
    {
        VCCB_PRINT_CALL_NRDC_MR_CONTROL("[NrdcSonNbrResourceManager] ssbFreq: %u\n", ssbFreq);
        auto printResource = [&](CapacityOption::Type capacity)
        {
            constexpr size_t LOG_PREFIX_SIZE = 20;
            constexpr size_t LOG_RESOURCE_FORMAT_SIZE = 17;
            auto &resourceList = (capacity == CapacityOption::Type::DL) ? frequencyResources.dl : frequencyResources.ul;
            std::string logstring;
            logstring.reserve(LOG_PREFIX_SIZE + (resourceList.size() * LOG_RESOURCE_FORMAT_SIZE));
            logstring += ((capacity == CapacityOption::Type::DL) ? "[DL] = {" : "[UL] = {");
            bool isFirstData = true;
            for (const auto &resource : resourceList)
            {
                if (!isFirstData)
                {
                    logstring += ", ";
                }
                logstring += std::to_string(resource);
                isFirstData = false;
            }
            logstring += "}\n";
            VCCB_PRINT_CALL_NRDC_MR_CONTROL("[NrdcSonNbrResourceManager] %s", logstring.c_str());
        };

        printResource(CapacityOption::Type::DL);
        printResource(CapacityOption::Type::UL);
    }
    VCCB_PRINT_CALL_NRDC_MR_CONTROL("[NrdcSonNbrResourceManager] =================================================================\n");
}

resourcePair_s NrdcSonNbrResourceManager::calculateSumOfTopNAvailableResourcePair(
    frequencyResource_type &frequencyResources, int loadTopN, SortOrder order)
{
    auto calculateSumOfTopNAvailableResource = [&](std::vector<double> &resourceList)
    {
        if (order == SortOrder::ASCENDING)
        {
            std::nth_element(
                resourceList.begin(), resourceList.begin() + loadTopN, resourceList.end(), std::less<double>());
        }
        else
        {
            std::nth_element(
                resourceList.begin(), resourceList.begin() + loadTopN, resourceList.end(), std::greater<double>());
        }

        return std::accumulate(resourceList.begin(), resourceList.begin() + loadTopN, 0.0);
    };

    return {calculateSumOfTopNAvailableResource(frequencyResources.dl),
        calculateSumOfTopNAvailableResource(frequencyResources.ul)};
}

void NrdcSonNbrResourceManager::buildFrequencyResourceMap()
{
    auto isValidNbrGnbCell = [](const nbrGnbCellInfo_type *pNbrGnbCell)
    { return (pNbrGnbCell != nullptr && IS_FR2(pNbrGnbCell->ssbArfcn)); };

    uint16_t maxNbrIdx = std::min(MAX_NBR_RELATION_TABLE_PER_CELL, MAX_NBR_PER_CELL);
    for (uint16_t nbrIdx = 0; nbrIdx < maxNbrIdx; nbrIdx++)
    {
        const auto *pNbrGnbCell = getNbrGnbCellByNbrIdx(_cell, nbrIdx);
        if (not isValidNbrGnbCell(pNbrGnbCell)) continue;

        const auto &rNbrPrb = _cell.cellRscInfo.nbrPrb[nbrIdx];
        if (not isValidNbrPrb(rNbrPrb)) continue;

        resourcePair_s availableResources = calculateAvailableResourcePair(rNbrPrb);
        if (not resourcePair_s::isValidResourcePair(availableResources))
        {
            VCCB_PRINT_CALL_ERROR(&_call,
                "[NrdcSonNbrResourceManager] nbr[%u] SsbFreq(%u) resource totalCCCV is abnormal!\n", nbrIdx,
                pNbrGnbCell->ssbArfcn);
            continue;
        }

        insertToFrequencyResourcesMap(pNbrGnbCell->ssbArfcn, availableResources);
    }

    printFrequencyResourcesMap();
}

void NrdcMeasIdOrderingDBController::insert(uint32_t ssbFreq, double averageAvailableResource)
{
    if (isFull()) return;
    auto &resourcePerFrequency = _availableResourceDB.rscPerFreq[_availableResourceDB.numOfFreq];
    resourcePerFrequency.ssbFreq = ssbFreq;
    resourcePerFrequency.avgAvailableRsc = averageAvailableResource;
    _availableResourceDB.numOfFreq++;
}
double NrdcMeasIdOrderingDBController::getResource(uint32_t ssbFreq)
{
    auto maxNbrIndex = std::min(static_cast<int>(this->size()), MAX_NR_OF_OBJECT_ID_DB);
    for (int nbrIndex = 0; nbrIndex < maxNbrIndex; nbrIndex++)
    {
        auto &resourcePerFrequency = _availableResourceDB.rscPerFreq[nbrIndex];
        if (resourcePerFrequency.ssbFreq == ssbFreq) return resourcePerFrequency.avgAvailableRsc;
    }
    return INVALID_RESOURCE;
}

int NrdcMeasIdOrderingManager::getLoadTopN(uint32_t ssbFreq)
{
    const measurementObjectNRDb_type *const measObjDB = FnVCCB_GetMeasObjectByFrequency(_cell, ssbFreq);
    VALID_E_POINT_CHECK_ZERO(measObjDB);
    return static_cast<int>(measObjDB->base.numOfCellForNrdcMeasureOrdering);
}

double NrdcMeasIdOrderingManager::selectResourceByOption(resourcePair_s resource)
{
    switch (_capacityOption)
    {
        case CapacityOption::Type::BOTH:
            VCCB_PRINT_CALL_NRDC_MR_CONTROL("[NrdcMeasIdOrderingManager] BOTH Mode: Select %s resource(dl/ul: %f/%f)\n",
                resource.dl < resource.ul ? "DL" : "UL", resource.dl, resource.ul);
            return std::min(resource.dl, resource.ul);
        case CapacityOption::Type::UL:
            return resource.ul;
        case CapacityOption::Type::DL:
        default:
            return resource.dl;
    }
}

double NrdcMeasIdOrderingManager::calculateAverageOfResources(
    NrdcSonNbrResourceManager::frequencyResource_type &frequencyResources, int loadTopNOfFrequency)
{
    int loadTopN = std::min(loadTopNOfFrequency, frequencyResources.size());
    if (loadTopN == 0) return INVALID_RESOURCE;

    resourcePair_s sumOfTopNResources = _sonNbrResourceManager->calculateSumOfTopNAvailableResourcePair(
        frequencyResources, loadTopN, SortOrder::DESCENDING);

    resourcePair_s averageOfTopNResource = sumOfTopNResources / loadTopN;
    return selectResourceByOption(averageOfTopNResource);
}

void NrdcMeasIdOrderingManager::updateAvailableResources()
{
    if (not _transactionIdManager.isResourceUpdated())
    {
        VCCB_PRINT_CALL_NRDC_MR_CONTROL(
            "[NrdcMeasIdOrderingManager] Skip updating DB because rsuTransId is not updated(%u/%u)\n", _cell.rsuTransId,
            _availableResourceDB.getTransId());
        return;
    }

    VALID_E_POINT_CHECK_VOID(_sonNbrResourceManager);
    _sonNbrResourceManager->buildFrequencyResourceMap();

    _availableResourceDB.clear();

    VCCB_PRINT_CALL_NRDC_MR_CONTROL(
        "[NrdcMeasIdOrderingManager] ======= Update Frequency Available Resource with %s Mode ======\n",
        CapacityOption::toString(_capacityOption));
    for (auto &[ssbFreq, resources] : _sonNbrResourceManager->getFrequencyAvailableResourcesMap())
    {
        if (_availableResourceDB.isFull())
        {
            VCCB_PRINT_CALL_ERROR(
                &_call, "[NrdcMeasIdOrderingManager] Db is Full! size:%d\n", _availableResourceDB.size());
            break;
        }

        int loadTopNOfFrequency = getLoadTopN(ssbFreq);
        if (not isValidLoadTopN(loadTopNOfFrequency))
        {
            VCCB_PRINT_CALL_NRDC_MR_CONTROL(
                "[NrdcMeasIdOrderingManager] Invalid loadTopNOfFrequency(%d) for ssbFreq(%u). So MeasIdOrdering is "
                "not supported.\n",
                loadTopNOfFrequency, ssbFreq);
            _availableResourceDB.clear();
            break;
        }

        VCCB_PRINT_CALL_NRDC_MR_CONTROL("[NrdcMeasIdOrderingManager] Frequency: %u\n", ssbFreq);
        double averageOfAvailableResource = calculateAverageOfResources(resources, loadTopNOfFrequency);
        if (not isValidResource(averageOfAvailableResource))
        {
            VCCB_PRINT_CALL_ERROR(&_call,
                "[NrdcMeasIdOrderingManager] Fail to calculate average of %u available resource "
                "(loadTopNOfFrequency:%d)\n",
                ssbFreq, loadTopNOfFrequency);
            continue;
        }

        VCCB_PRINT_CALL_NRDC_MR_CONTROL("[NrdcMeasIdOrderingManager] Available Resource: %f\n", averageOfAvailableResource);
        _availableResourceDB.insert(ssbFreq, averageOfAvailableResource);
    }

    VCCB_PRINT_CALL_NRDC_MR_CONTROL(
        "[NrdcMeasIdOrderingManager] ================= MeasId Ordering DB is updated =================\n");
    _transactionIdManager.updateTransId();
}

double NrdcMeasIdOrderingManager::getAverageAvailableResource(uint32_t frequency)
{
    updateAvailableResources();

    auto averageAvailableResource = _availableResourceDB.getResource(frequency);
    VCCB_PRINT_CALL_NRDC_MR_CONTROL(
        "[NrdcMeasIdOrderingManager] Get average available resource(%f) for frequency(%u)\n", averageAvailableResource,
        frequency);

    return averageAvailableResource;
}

double FnVCCB_GetAvgAvailResourceByFreqForNrdc(const callInfo_type &call, uint32_t targetCellNum, uint32_t ssbFreq)
{
    VCCB_CHECK_E_RANGE_AND_VAL(targetCellNum, MAX_CELL_NUM_VCCB, -1.0);
    const auto &targetCell = CELLINFO[targetCellNum];

    VCCB_CHECK_E_RANGE_AND_VAL(targetCell.gnbNum, MAX_GNB_PER_SYS, -1.0);
    const auto &targetGnb = GNBINFO[targetCell.gnbNum];

    VCCB_CHECK_E_RANGE_AND_VAL(call.myThreadId, MAX_CALL_THREAD_NUM_VCCB, -1.0);
    nrdcMeasIdOrderingMgmt_type &measurementOrderingDb =
        THREAD_INFO->call[call.myThreadId].measIdOrderingMgmt[targetCellNum];

    NrdcMeasIdOrderingManager nrdcMeasOrderDBManager(call, targetCell, targetGnb, measurementOrderingDb);
    return nrdcMeasOrderDBManager.getAverageAvailableResource(ssbFreq);
}

resourcePair_s NrdcScgBandSelectionManager::calculateAverageOfResources()
{
    int loadTopNOfCell = _cell.scgBandSelectionConfig.loadTopN;
    if (not isValidLoadTopN(loadTopNOfCell))
    {
        VCCB_PRINT_CALL_ERROR(&_call, 
            "[NrdcScgBandSelectionManager] Invalid loadTopNOfCell(%d) for Scg Band Selection is not supportable.\n",
            loadTopNOfCell);
        return INVALID_RESOURCE_PAIR;
    }
    else if (loadTopNOfCell == 0)
    {
        VCCB_PRINT_CALL_NRDC_MR_CONTROL(
            "[NrdcScgBandSelectionManager] LoadTopN is zero. No need to calculate LB threshold\n");
        return {0, 0};
    }

    VALID_E_POINT_CHECK_RET_VAL(_sonNbrResourceManager, INVALID_RESOURCE_PAIR);
    _sonNbrResourceManager->buildFrequencyResourceMap();
    if (_sonNbrResourceManager->getMapSize() == 1)
    {
        VCCB_PRINT_CALL_NRDC_MR_CONTROL(
            "[NrdcScgBandSelectionManager] Single Frequency in SonNbrResource. No need to calculate LB "
            "threshold\n");
        return {0, 0};
    }

    resourcePair_s totalSumOfTopNResources = {0, 0};
    int totalTopN = 0;
    for (auto &iter : _sonNbrResourceManager->getFrequencyAvailableResourcesMap())
    {
        auto &resources = iter.second;
        auto loadTopN = std::min(loadTopNOfCell, resources.size());
        if (loadTopN == 0) continue;

        resourcePair_s sumOfTopNResources =
            _sonNbrResourceManager->calculateSumOfTopNAvailableResourcePair(resources, loadTopN, SortOrder::ASCENDING);

        totalSumOfTopNResources += sumOfTopNResources;
        totalTopN += loadTopN;
    }

    if (totalTopN == 0)
    {
        VCCB_PRINT_CALL_ERROR(&_call, 
            "[NrdcScgBandSelectionManager] No valid TopN resources for calculating LB threshold\n");
        return INVALID_RESOURCE_PAIR;
    }

    return totalSumOfTopNResources / totalTopN;
}

void NrdcScgBandSelectionManager::setThreadDBThreshold(resourcePair_s threshold)
{
    _scgBandSelectionThreadDB.dlThForLb = threshold.dl;
    _scgBandSelectionThreadDB.ulThForLb = threshold.ul;
    VCCB_PRINT_CALL_NRDC_MR_CONTROL(
        "[NrdcScgBandSelectionManager] Scg Band Selection Threshold is updated (dl:%f/ul:%f)\n",
        _scgBandSelectionThreadDB.dlThForLb, _scgBandSelectionThreadDB.ulThForLb);
}

int NrdcScgBandSelectionManager::updateLBThreshold()
{
    if (not IS_FAST_ACCESS_BAND_SELECTION_MODE(_call.servCellNum)) return BREAK;

    if (not _transactionIdManager.isResourceUpdated())
    {
        VCCB_PRINT_CALL_NRDC_MR_CONTROL(
            "[NrdcScgBandSelectionManager] Skip updating DB because rsuTransId is not updated(%u)\n",
            _scgBandSelectionThreadDB.rsuTransIdForLb);
        return BREAK;
    }

    resourcePair_s scgBandLbThreshold = calculateAverageOfResources();
    setThreadDBThreshold(scgBandLbThreshold);

    if (not resourcePair_s::isValidResourcePair(scgBandLbThreshold))
    {
        VCCB_PRINT_CALL_ERROR(&_call, "[NrdcScgBandSelectionManager] Invalid LB threshold calculation result\n");
        return ERROR;
    }

    _transactionIdManager.updateTransId();
    return GOOD;
}

int FnVCCB_CalculateLbThresholdForScgBandSel(const callInfo_type &call)
{
    VCCB_CHECK_E_RANGE_AND_RETURN(call.servCellNum, MAX_CELL_NUM_VCCB);
    const auto &servCell = CELLINFO[call.servCellNum];

    VCCB_CHECK_E_RANGE_AND_RETURN(call.myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    nrdcScgBandSelectionMgmt_type &nrdcScgBandSelMgmtPerCell =
        THREAD_INFO->call[call.myThreadId].nrdcScgBandSelMgmtPerCell[call.servCellNum];

    NrdcScgBandSelectionManager scgBandSelectionManager(call, servCell, nrdcScgBandSelMgmtPerCell);
    return scgBandSelectionManager.updateLBThreshold();
}

FastAccessTimerManager::FastAccessTimerManager(callInfo_type& rCall)
    : _call(rCall), _cellNum(0)
{
    _cellNum = FnVCCB_GetCellSelectionForConfig(&_call).cellNum;
}

void FastAccessTimerManager::resetTimer()
{
    _call.fastAccBoundaryTime = FAST_ACCESS_BOUNDARY_TIME_NOT_SET;
}

void FastAccessTimerManager::controlTimer()
{
    if (not hasNrdcMeasConfig())
    {
        resetTimer();
        VCCB_PRINT_CALL_NRDC_MR_CONTROL("%s Timer reset (no NrdcMeasConfig)\n", FAST_ACCESS_LOG_PREFIX);
        return;  // Timer reset. No further processing required.
    }

    auto isCellChanged = (_call.stateCmd == IntraRatHO_cmd || (_call.stateCmd == RrcReestablish_cmd &&
                                                                  _call.ueInfo.reestablishInfo.oldCellNum != _cellNum));
    auto isRrcResume = (_call.stateCmd == RRCResume_cmd);
    if (isCellChanged || isRrcResume)
    {
        resetTimer();
        VCCB_PRINT_CALL_NRDC_MR_CONTROL("%s Timer reset (cell:%d, resume:%d)\n", FAST_ACCESS_LOG_PREFIX, isCellChanged, isRrcResume);
    }
 
    if (isFastAccessModeSupported() && _call.fastAccBoundaryTime == FAST_ACCESS_BOUNDARY_TIME_NOT_SET)
    {
        setTimer();
    }
}

bool FastAccessTimerManager::isActivated() const
{
    if (not isFastAccessModeSupported())
    {
        VCCB_PRINT_CALL_NRDC_MR_CONTROL(
            "%s Fast Access not supported for activation check\n", FAST_ACCESS_LOG_PREFIX);
        return false;
    }

    if (isExpired())
    {
        return false;
    }

    return true;
}

bool FastAccessTimerManager::isFastAccessModeSupported() const
{
    if (_call.callType != E_CALLTYPE_SA) {
        return false;
    }

    if (not IS_FAST_ACCESS_BAND_SELECTION_MODE(_cellNum)) {
        return false;
    }

    return true;
}

bool FastAccessTimerManager::hasNrdcMeasConfig() const
{
    auto measIdx = VCCB_FindInstalledMeasId_ByFreqReportPurpose(&_call, 0, measReport_A4, a4Purpose_NrdcAddition);

    return (measIdx >= 0 && measIdx < MAX_NR_OF_MEAS_ID);
}

void FastAccessTimerManager::setTimer()
{
    VccbCellInfo_type const *pCell = FnVCCB_GetCellInfo(_cellNum);
    VALID_E_POINT_CHECK_VOID(pCell);

    auto mrWaitingTimer = pCell->scgBandSelectionConfig.mrWaitingTimer;
    if(mrWaitingTimer > MAX_MR_WAITING_TIMER_MS) {
        VCCB_PRINT_CALL_ERROR(&_call, "%s Error: Invalid mrWaitingTimer(%u), max allowed: %u\n", 
                              FAST_ACCESS_LOG_PREFIX, mrWaitingTimer, MAX_MR_WAITING_TIMER_MS);
        return;
    }

#ifdef IPC_TEST
    struct timespec currTime;
    currTime.tv_sec = DBG->testTimeValue;
    currTime.tv_nsec = 2000000;
    DBG->testTimeValue += 5;
#else
    struct timespec currTime = tickGetMono();
#endif
    long currentMs = currTime.tv_sec * 1000 + currTime.tv_nsec / 1000000;
    _call.fastAccBoundaryTime = currentMs + mrWaitingTimer;
    
    VCCB_PRINT_CALL_NRDC_MR_CONTROL("%s Timer set for cellNum %u: boundaryTime=%ld(cur:%ld + wait:%u)\n", 
                                   FAST_ACCESS_LOG_PREFIX, _cellNum, _call.fastAccBoundaryTime, currentMs, mrWaitingTimer);
}

bool FastAccessTimerManager::isExpired() const
{
#ifdef IPC_TEST
    struct timespec currTime;
    currTime.tv_sec = DBG->testCurrTime;
    currTime.tv_nsec = 0;
#else
    struct timespec currTime = tickGetMono();
#endif
    long currentMs = currTime.tv_sec * 1000 + currTime.tv_nsec / 1000000;
    bool expired = (currentMs >= _call.fastAccBoundaryTime);
    
    VCCB_PRINT_CALL_NRDC_MR_CONTROL("%s Timer check for cellNum %u: currentMs=%ld, boundaryTime=%ld, expired=%s\n", 
                                   FAST_ACCESS_LOG_PREFIX, _cellNum, currentMs, _call.fastAccBoundaryTime, 
                                   expired ? "true" : "false");
    
    return expired;
}

void FnVCCB_CommitFastAccTimerCtrlForScgBandSel(callInfo_type& rCall)
{
    AUTO_TRACE_FUNC;

    FastAccessTimerManager timerCtrl(rCall);
    timerCtrl.controlTimer();
}

bool FnVCCB_IsFastAccTimerActivated(callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;

    FastAccessTimerManager timerCtrl(rCall);
    return timerCtrl.isActivated();
}

FastAccessConditionChecker::FastAccessConditionChecker(callInfo_type& rCall, const VccbCellInfo_type& rCell, const sonNbrPrbRsc_type& rNbrPrb, const uint32_t ssbFreq) :
    _call(rCall),
    _cell(rCell),
    _nbrPrb(rNbrPrb),
    _ssbFreq(ssbFreq)
{
}

bool FastAccessConditionChecker::checkConditions()
{
    if (not NrdcSonNbrResourceManager::isValidNbrPrb(_nbrPrb))
    {
        VCCB_PRINT_CALL_NRDC_MR_CONTROL("%s NbrPrb is not available!!(usage:%d, isRsUpdate:%d) Skip fast access condition check.\n", FAST_ACCESS_LOG_PREFIX,
            _nbrPrb.usage, _nbrPrb.isRsUpdate);
        return true;
    }

    if (not isLbConditionMet())
    {
        return false;
    }

    const measurementObjectNRDb_type *const measObjDB = FnVCCB_GetMeasObjectByFrequency(_cell, _ssbFreq);
    if (measObjDB == nullptr)
    {
        VCCB_PRINT_CALL_ERROR( &_call, "%s Failed to get measurement object(freq:%d) for NBR\n", FAST_ACCESS_LOG_PREFIX, _ssbFreq);
        return false;
    }

    if (not isOverloadConditionMet(*measObjDB))
    {
        return false;
    }

    if (not isAvailableUeConditionMet(*measObjDB))
    {
        return false;
    }

    return true;
}

bool FastAccessConditionChecker::isLbConditionMet()
{
    if (not isLbThresholdCheckNeeded())
    {
        return true;
    }

    VCCB_CHECK_VALID_CELLNUM_FALSE(_call.servCellNum);
    VCCB_CHECK_VALID_CELLNUM_FALSE(_call.myThreadId);
    const auto &threadDB = THREAD_INFO->call[_call.myThreadId].nrdcScgBandSelMgmtPerCell[_call.servCellNum];

    auto availableResource = NrdcSonNbrResourceManager::calculateAvailableResourcePair(_nbrPrb);
    if (not resourcePair_s::isValidResourcePair(availableResource))
    {
        VCCB_PRINT_CALL_ERROR(&_call, "%s Availabie resource is invalid.\n", FAST_ACCESS_LOG_PREFIX);
        return false;
    }

    bool meetsDlThreshold = (availableResource.dl >= threadDB.dlThForLb);
    bool meetsUlThreshold = (availableResource.ul >= threadDB.ulThForLb);

    VCCB_PRINT_CALL_NRDC_MR_CONTROL("%s LB Threshold check - Opt:(%d), DL: %.2f >= %.2f (%s), UL: %.2f >= %.2f (%s)\n",
        FAST_ACCESS_LOG_PREFIX, _capaOption, availableResource.dl, threadDB.dlThForLb,
        meetsDlThreshold ? "PASS" : "FAIL", availableResource.ul, threadDB.ulThForLb, meetsUlThreshold ? "PASS" : "FAIL");

    switch (_capaOption)
    {
        case SCG_BAND_SEL_CapacityOptionDL:
            return meetsDlThreshold;
        case SCG_BAND_SEL_CapacityOptionUL:
            return meetsUlThreshold;
        case SCG_BAND_SEL_CapacityOptionBoth:
            return (meetsDlThreshold && meetsUlThreshold);
        default:
            VCCB_PRINT_CALL_ERROR(
                &_call, "%s Invalid capacityOption(%d) in %s\n", FAST_ACCESS_LOG_PREFIX, _capaOption, __func__);
            return false;
    }
}

bool FastAccessConditionChecker::isOverloadConditionMet(const measurementObjectNRDb_type &measObjDB)
{
    if (_nbrPrb.dlCapacityValue > 100 || _nbrPrb.ulCapacityValue > 100)
    {
        VCCB_PRINT_CALL_ERROR(&_call, "%s Invalid capacityValue(%d/%d) for NBR.\n",
            FAST_ACCESS_LOG_PREFIX, _nbrPrb.dlCapacityValue, _nbrPrb.ulCapacityValue);
        return false;
    }

    const auto requiredThForDlCapa = measObjDB.base.requiredThresholdForNrdcDlCapa;
    const auto requiredThForUlCapa = measObjDB.base.requiredThresholdForNrdcUlCapa;

    bool meetsDlThreshold = (_nbrPrb.dlCapacityValue >= requiredThForDlCapa);
    bool meetsUlThreshold = (_nbrPrb.ulCapacityValue >= requiredThForUlCapa);

    VCCB_PRINT_CALL_NRDC_MR_CONTROL(
        "%s Overload Threshold check - Opt:(%d), DL: %d >= %d (%s), UL: %d >= %d (%s)\n",
        FAST_ACCESS_LOG_PREFIX, _capaOption, 
        _nbrPrb.dlCapacityValue, requiredThForDlCapa, meetsDlThreshold ? "PASS" : "FAIL", 
        _nbrPrb.ulCapacityValue, requiredThForUlCapa, meetsUlThreshold ? "PASS" : "FAIL");

    switch (_capaOption)
    {
        case SCG_BAND_SEL_CapacityOptionDL:
            return meetsDlThreshold;
        case SCG_BAND_SEL_CapacityOptionUL:
            return meetsUlThreshold;
        case SCG_BAND_SEL_CapacityOptionBoth:
            return (meetsDlThreshold && meetsUlThreshold);
        default:
            VCCB_PRINT_CALL_ERROR(
                &_call, "%s Invalid capacityOption(%d) in %s\n", FAST_ACCESS_LOG_PREFIX, _capaOption, __func__);
            return false;
    }
}

bool FastAccessConditionChecker::isAvailableUeConditionMet(const measurementObjectNRDb_type &measObjDB)
{
    if (_nbrPrb.numAvailUe > 100)
    {
        VCCB_PRINT_CALL_ERROR(&_call, "%s Invalid numAvailUe(%d) for NBR.\n", FAST_ACCESS_LOG_PREFIX, _nbrPrb.numAvailUe);
        return false;
    }

    const auto requiredThresholdForNrdcUe = measObjDB.base.requiredThresholdForNrdcUe;
    bool meetsUeThreshold = (_nbrPrb.numAvailUe >= requiredThresholdForNrdcUe);

    VCCB_PRINT_CALL_NRDC_MR_CONTROL("%s numAvailUe Threshold check - CAPA:(%d), UE: %d >= %d (%s)\n",
        FAST_ACCESS_LOG_PREFIX, _capaOption, _nbrPrb.numAvailUe, requiredThresholdForNrdcUe,
        meetsUeThreshold ? "PASS" : "FAIL");

    return meetsUeThreshold;
}

bool FastAccessConditionChecker::isLbThresholdCheckNeeded()
{
    if (FnVCCB_GetNumofInstalledMeasCfgFreqForNrdcAdd(_call) < 2)
    {
        VCCB_PRINT_CALL_NRDC_MR_CONTROL(
            "%s NBR not multiple FR2 frequency for NR-DC\n", FAST_ACCESS_LOG_PREFIX);
        return false;
    }

    if (_cell.scgBandSelectionConfig.loadTopN <= 0)
    {
        VCCB_PRINT_CALL_NRDC_MR_CONTROL("%s NBR loadTopN(%d) is invalid\n", FAST_ACCESS_LOG_PREFIX,
            _cell.scgBandSelectionConfig.loadTopN);
        return false;
    }

    return true;
}

bool FnVCCB_CheckLoadBasedScgBandSelCondition(callInfo_type &rCall, uint16_t nbrIdx, uint32_t ssbFreq)
{
    AUTO_TRACE_FUNC;

    VccbCellInfo_type const *pCell = FnVCCB_GetCellInfo(rCall.servCellNum);
    VALID_E_POINT_CHECK_FALSE(pCell);

    VCCB_CHECK_E_RANGE_AND_FALSE(nbrIdx, MAX_NBR_RELATION_TABLE_PER_CELL);
    FastAccessConditionChecker checker(rCall, *pCell, pCell->cellRscInfo.nbrPrb[nbrIdx], ssbFreq);
    return checker.checkConditions();
}
