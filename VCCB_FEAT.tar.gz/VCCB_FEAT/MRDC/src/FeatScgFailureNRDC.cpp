/****************************************************************
 * System      : 5G gNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatScgFailureNRDC.cpp
 * Description : This file contains functions relate to the management of NRDC SCG Failure feature
 * Dept.       : Call SW Group.
 * Created     : 2023.09.01
 ****************************************************************/

#include "MsgXnapSend.h"
#include "MsgE1apSend.h"
#include "MsgF1apStore.h"
#include "MsgNrRrcSend.h"

#include "FeatScgFailureNRDC.h"
#include "FeatMeasurements.hpp"
#include "StateHandleSaMrdc.h"
#include "StateHandleAll.h"
#include "StateCommon.h"
#include "StateHandleMrdcSN.h"
#include "ComMacro.h"
#include "ComInclude.h"
#include "ComLibUtility.h"
#include "CdbUtil.h"

#include "FeatCommon.h"

/*
 * @brief   Process of SCG failure handling for the suspension at MN
 * @param   callInfo_type *ptCi
 * @return  int16_t GOOD/ERROR (1/-1)
 */
int16_t FnVCCB_ProcSCGFailWithSuspendMN(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (!IS_NRDC_MN(ptCi))
    {
        return ERROR;
    }

    int16_t status = GOOD;
    SET_STATE_CMD(MrdcScgFailSuspend_cmd);

    // case 1) UE-init suspension case in MN (by NRRRC SCG Failure Information)
    if (NrDcScgFailure_MnInit_Suspend == ptCi->nrdcScgFailureInfo.event)
    {
        // set XnCause
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerRadioConnectionWithUeLost;

        // send SN Modification Request with UE Lost cause
        if (ERROR == FnVCCB_SendXNMessage(XN_SNodeModificationRequest_id, ptCi, nullptr, nullptr))
        {
            return ERROR;
        }
        VLIB_SetCurStateAll(ptCi, STATE_MN_SCGSuspend_XnMod);
        VLIB_AttachTimer(&ptCi->timer, ptCi, timXN_SNodeModification_id);
    }
    // case 2) DU-init suspension case in MN (by XN SNode Modification Required)
    else if (NrDcScgFailure_SnInit_Suspend == ptCi->nrdcScgFailureInfo.event)
    {
        VLIB_SetCurStateAll(ptCi, STATE_MN_SCGSuspend_XnMod);

        if (TRUE == FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType))
        {
            status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

            ON_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);
            VLIB_SetCurStateAll(ptCi, STATE_MN_SCGSuspend_E1Mod);
            VLIB_AttachTimer(&ptCi->callMultiTimer.e1, ptCi, timE1_BearerContextModification_id);
        }
        else
        {
            if (DBG->flag.mrdcScgFailureSuspendResume == TRUE)
            {
                // SVR22B FGR-CC5203: Deconfigure A4 for SCG resume and Update MeasConfig
                ptCi->nrdcScgFailureInfo.A4Configured = VCCB_FLAG_ON;
                status = VCCB_PrepareNewMeasConfig(ptCi);
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");
            }

            status = FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer(ptCi, FALSE, FALSE, ID_SRB1);

            if (status == GOOD)
            {
                VLIB_SetCurStateAll(ptCi, STATE_MN_SCGSuspend_RRCReconfigCmpl);
                VLIB_AttachTimer(&ptCi->timer, ptCi, timNRRRC_RRCReconfig_id);
            }
            else
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer fails !!\n");

                // MN-Init SN-Release
                status = VCCM_ProcSCGFailWithSnRelease(ptCi, MrdcRelCause_SCGFailure);
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_ProcSCGFailWithSnRelease ERROR!\n");
            }
        }
    }
    else
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "nrdcScgFailureInfo.event(%d) => ERROR!\n", ptCi->nrdcScgFailureInfo.event);
        return ERROR;
    }

    VCCB_PRINT_CALL_MSG(ptCi, "FnVCCB_ProcSCGFailWithSuspendMN OK\n");

    return GOOD;
}

/*
 * @brief   Process of SCG failure handling for the suspension at SN
 * @param   callInfo_type *ptCi
 * @return  int16_t GOOD/ERROR (1/-1)
 */
int16_t FnVCCB_ProcSCGFailWithSuspendSN(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (!IS_NRDC_SN(ptCi))
    {
        return ERROR;
    }

    SET_STATE_CMD(MrdcScgFailSuspend_cmd);
    VLIB_SetCurStateAll(ptCi, STATE_SN_SCGSuspend_Init);

    // Update Statistics (Suspend per failureType)
    FnVCCB_IncrementNrdcScgFailureStat(ptCi, SCG_FAIL_SUSPEND);

    if (TRUE == FnVCCB_IsAnySnTermPerUE(ptCi, current_bearerType))
    {
        // send E1 Bearer Context Modification Request for Tx Stop
        if (VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification) == ERROR)
        {
            return ERROR;
        }

        ON_E1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag);
        VLIB_SetCurStateAll(ptCi, STATE_SN_SCGSuspend_E1Mod);
        VLIB_AttachTimer(&ptCi->callMultiTimer.e1, ptCi, timE1_BearerContextModification_id);
    }
    else
    {
        // SVR24B FGR-CC5203
        if (ptCi->nrdcScgFailureInfo.event == NrDcScgFailure_MnInit_Suspend)
        {
            int16_t status = FnVCCB_SendXNMessage(XN_SNodeModificationRequestAcknowledge_id, ptCi, nullptr, nullptr);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status,
                "FnVCCB_SendXNMessage(XN_SNodeModificationRequestAcknowledge) ERROR!\n");

            // If SN RRC Reconfig is included in SNode Modification Request Acknowledge,
            if (FnVCCB_NeedToRecvXnSNodeReconfigurationComplete(ptCi) == true)
            {
                VLIB_SetCurStateAll(ptCi, STATE_SN_SCGSuspend_XnReconfigCmpl);
                VLIB_AttachTimer(&ptCi->timer, ptCi, timXN_SNodeReconfigurationComplete_id);
            }
            else
            {
                // suspend procedure completed in SN!!
                FnVCCB_FinalizeSCGSuspend_MRDC(ptCi);
            }
        }
        else if (ptCi->nrdcScgFailureInfo.event == NrDcScgFailure_SnInit_Suspend)
        {
            int16_t status = FnVCCB_SendXNMessage(XN_SNodeModificationRequired_id, ptCi, nullptr, nullptr);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status,
                "FnVCCB_SendXNMessage(XN_SNodeModificationRequired) ERROR!\n");

            VLIB_SetCurStateAll(ptCi, STATE_SN_SCGSuspend_XnReconfigCmpl);
            VLIB_AttachTimer(&ptCi->timer, ptCi, timXN_SNodeReconfigurationConfirm_id);
        }
        else
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "nrdcScgFailureInfo.event(%d) => ERROR!\n", ptCi->nrdcScgFailureInfo.event);
            return ERROR;
        }

        // start suspend timer
        VLIB_AttachTimer(&ptCi->scgSuspendResumeTimer, ptCi, timInternalNrdcScgSuspend_id);
    }

    VCCB_PRINT_CALL_MSG(ptCi, "FnVCCB_ProcSCGFailWithSuspendSN OK\n");

    return GOOD;
}

/*
 * @brief   Process of SCG failure handling for the resumption at MN
 * @param   callInfo_type *ptCi
 * @return  int16_t GOOD/ERROR (1/-1)
 */
int16_t FnVCCB_ProcSCGFailWithResumeMN(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (!IS_NRDC_MN(ptCi))
    {
        return ERROR;
    }

    int16_t status = GOOD;
    SET_STATE_CMD(MrdcScgFailResume_cmd);

    // 1. MN-Init Resume: send SN Modification Request with UE Lost cause
    if (NrDcScgFailure_MnInit_Resume == ptCi->nrdcScgFailureInfo.event)
    {
        if (DBG->flag.mrdcScgFailureSuspendResume == TRUE)
        {
            // SVR22B FGR-CC5203: Deconfigure A4 for SCG resume and Update MeasConfig
            ptCi->nrdcScgFailureInfo.A4Configured = VCCB_FLAG_OFF;
            status = VCCB_PrepareNewMeasConfig(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");
        }

        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerSnMobility;

        status = FnVCCB_SendXNMessage(XN_SNodeModificationRequest_id, ptCi, nullptr, nullptr);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_SNodeModificationRequest_id) ERROR !!\n");

        VLIB_SetCurStateAll(ptCi, STATE_MN_SCGResume_XnMod);
        VLIB_AttachTimer(&ptCi->timer, ptCi, timXN_SNodeModification_id);
    }

    VCCB_PRINT_CALL_MSG(ptCi, "FnVCCB_ProcSCGFailWithResumeMN OK\n");

    return GOOD;
}

/*
 * @brief   Checker function for the validity of proceeding for the SCG suspension
 * @param   callInfo_type *ptCi
 * @return  int16_t GOOD/ERROR (1/-1)
 */
int16_t FnVCCB_CheckAndProcess_SCGFailureNRDC_SN(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);

    if (!IS_NRDC_SN(ptCi))
    {
        return GOOD;
    }

    int16_t status = GOOD;
    bool needRelease = false;

    // FR60: SN VCCB shall trigger SN-initiated SN release procedure when,
    // - If SCG failure cause is absent in SCG Failure information
    if (FALSE == IS_SCG_SUSPENDED(ptCi) &&
        CauseXnapRadioNetworkLayerRadioConnectionWithUeLost == ptCi->cause.xnCause)
    {
        if (VCCB_FLAG_OFF == ptCi->cgConfigInfo.scgFailureInfoFlag &&
            VCCB_FLAG_OFF == ptCi->cgConfigInfo.scgFailureInfoFlag_v1610) 
        {
            needRelease = true;
            ptCi->mrdcInfo.sNodeRelCause = MrdcRelCause_SCGFailure;

            VCCB_PRINT_CALL_MSG(
                ptCi, "SCG Failure Type is missing\n");

            // Couldn't get any failure causes, so Statistics are not updated here!!
        }
    }

    if (FALSE == needRelease)
    {
        // 1) XnCause: Radio Connection with UE Lost
        if (CauseXnapRadioNetworkLayerRadioConnectionWithUeLost == ptCi->cause.xnCause)
        {
            // Update Statistics (Count per failureType)
            FnVCCB_IncrementNrdcScgFailureStat(ptCi, SCG_FAIL_COUNT);       // UE-Init

            // 1.1) If NO Event for SCG Suspend/Resume and XnCause: Radio Connection w/ UE Lost,
            //    Start SCG Suspend procedure !! ==> MN-Init Suspend @SN
            if (NrDcScgFailure_NoEvent == ptCi->nrdcScgFailureInfo.event)
            {
                ptCi->nrdcScgFailureInfo.event = NrDcScgFailure_MnInit_Suspend;

                if (0 != GNBINFO[ptCi->gnbNum].cfg.scgFailureHandlingInfoNrDc.suspendTimer &&
                        NrDcScgFailureSuspendAndResume == ptCi->nrdcScgFailureInfo.failAction)
                {
                    status = FnVCCB_ProcSCGFailWithSuspendSN(ptCi);
                    if (status == ERROR)
                    {
                        needRelease = true;
                        ptCi->mrdcInfo.sNodeRelCause = MrdcRelCause_SCGSuspendTimeOut;

                        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_ProcSCGFailWithSuspendSN ERROR!\n");
                    }
                }
                // FR10: If suspend timer is 0, it starts SN-init SN-release
                else
                {
                    needRelease = true;
                    ptCi->mrdcInfo.sNodeRelCause = MrdcRelCause_SCGSuspendTimeOut;

                    VCCB_PRINT_CALL_ERROR(ptCi, "SuspendTimer(%d) or failAction(%d). SN release Trigger\n",
                            GNBINFO[ptCi->gnbNum].cfg.scgFailureHandlingInfoNrDc.suspendTimer,
                            ptCi->nrdcScgFailureInfo.failAction);
                }
            }
            // 1.2) If in SCG Suspended status this message comes by 2nd SCGFailureInformation,
            //    SN sends XN SNode Release Required (w/ Radio Connection w/ UE Lost) (FR60 [case C-1-2])
            else
            {
                // FR61. In Suspended  state,
                // SN VCCB shall refuse: Xn:SNode Modification Request (This is NOT SNode Modification Request for
                // resume) SN VCCB shall respond to MN with SNode Modification Reject using Xn Cause 'Radio Connection
                // with UE Lost'
                needRelease = true;
                ptCi->mrdcInfo.sNodeRelCause = MrdcRelCause_SCGFailure;

                VCCB_PRINT_CALL_ERROR(ptCi, "2nd SCGFailure message recv. Sn-init Release!\n");
            }
        }
        // 2) If in SCG Suspended status and XnCause: SN Mobility,
        //    Start SCG Resume procedure !! ===> MN-Init Resume @SN
        else if (IS_SCG_SUSPENDED(ptCi))
        {
            if (CauseXnapRadioNetworkLayerSnMobility == ptCi->cause.xnCause)
            {
                if (VCCB_FLAG_ON == ptCi->cgConfigInfo.candidateCellInfoListMN_Flag)
                {
                    // Deactivating suspend timer part is moved to FnVCCB_Conn_XnapSNodeModificationRequest_Mobility 
                    // as SN VCCB have to hold the timer until SN VCCB selects the target PSCell.

                    ptCi->nrdcScgFailureInfo.event = NrDcScgFailure_MnInit_Resume;

                    // 22C2: feature refactoring
                    ON_SGNB_MOD_REQ_FLAG(ptCi->flag.setupFlag);
                    return BREAK;
                }
                else
                {
                    // FR60.
                    // If SN-Mobility, but without candidateCellInfoListMN, SN VCCB starts SN-init SN release.
                    needRelease = true;
                    ptCi->mrdcInfo.sNodeRelCause = MrdcRelCause_SCGFailure;

                    VCCB_PRINT_CALL_ERROR(ptCi,
                            "candidateCellInfoListMN is absent while starting Resume!\n");
                }
            }
            else
            {
                // FR61.
                // If XnCause is NOT 'SN-Mobility', SN VCCB refuses S-Node Modification Request.
                VCCB_PRINT_CALL_ERROR(ptCi,
                        "XnCause(%d) is NOT SN-Mobility while starting Resume!\n", ptCi->cause.xnCause);

                ptCi->cause.xnCause = CauseXnapRadioNetworkLayerRadioConnectionWithUeLost;
                status = FnVCCB_SendXNMessage(XN_SNodeModificationRequestReject_id, ptCi, nullptr, nullptr);
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status,
                        "FnVCCB_SendXNMessage(XN_SNodeModificationRequestReject) ERROR!\n");
            }
        }
        // 4) For the other cases in Resume procedure, (not designed case)
        else
        {
            needRelease = true;
            ptCi->cause.xnCause = CauseXnapRadioNetworkLayerRadioConnectionWithUeLost;
            ptCi->mrdcInfo.sNodeRelCause = MrdcRelCause_SCGFailure;

            VCCB_PRINT_CALL_ERROR(ptCi,
                "received XN Message, but Invalid state (nrdcScgFailureInfo.event(%d))\n",
                ptCi->nrdcScgFailureInfo.event);
        }
    }

    if (true == needRelease)
    {
        // SVR24B FR300: CRR
        FnVCCB_StatCallFaultPerFailCauseSCGFailure_NRDC(ptCi, XN_SNodeModificationRequest_id);

        ptCi->nrdcScgFailureInfo.failAction = NrDcScgFailureSnRelease;

        // SVR24A FR230
        CONVERT_AND_SAVE_NRDC_CTX_REL(ptCi, XN_SNodeReleaseRequired_id);

        // stop suspend timer if it's running
        VCCB_CLEAR_TIMER(&ptCi->scgSuspendResumeTimer, CANCEL_TIMER);

        if (VCCB_CALL_RELEASE_TRIGGER(ptCi) != GOOD) // Call Job Release
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_CALL_RELEASE_TRIGGER ERROR!\n");
        }
    }
    return GOOD;
}

/*
 * @brief   Handler of SCGFailureInformation in NR-DC
 * @param   callInfo_type *ptCi
 * @return  int16_t GOOD/ERROR (1/-1)
 */
int16_t FnVCCB_HandleSCGFailureInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (IS_NRDC_SN(ptCi))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "FnVCCB_HandleSCGFailureInfo is called in SN -> Discard!\n");
        return GOOD;
    }

    // FR110: UE Signature
    if (VCCB_FLAG_ON == ptCi->nrdcScgFailureInfo.ueSignatureFlag)
    {
        // MN-Init SN-Release
        int16_t status = VCCM_ProcSCGFailWithSnRelease(ptCi, MrdcRelCause_SCGFailure);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_ProcSCGFailWithSnRelease ERROR!\n");

        return status;
    }

    // in SVR22B, supports suspend-and-resume option as well.
    if (NrDcScgFailureSuspendAndResume == ptCi->nrdcScgFailureInfo.failAction)
    {
        // MN-init suspend procedure (SVR22B FGR-CC5203)
        VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "%s, MRDC_RSC_SETUP_FLAG(%d)\n", __FUNCTION__, IS_ON_MRDC_RSC_SETUP_FLAG(xn_snConn));
        ptCi->nrdcScgFailureInfo.event = NrDcScgFailure_MnInit_Suspend;

        VCCB_RETURN_ON_CALL_ERROR(
            ptCi, FnVCCB_ProcSCGFailWithSuspendMN(ptCi), "FnVCCB_ProcSCGFailWithSuspendMN ERROR !!\n");
    }
    // FR70.HD1
    else
    {
        // MN-Init SN-Release
        int16_t status = VCCM_ProcSCGFailWithSnRelease(ptCi, MrdcRelCause_SCGFailure);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_ProcSCGFailWithSnRelease ERROR!\n");
    }

    return GOOD;
}

// SVR22B FGR-CC5203
/*
 * @brief   Handler of SCGFailureInformation in NR-DC
 * @param   callInfo_type *ptCi
 * @return  int16_t GOOD/ERROR (1/-1)
 */
int16_t FnVCCB_HandleF1RLF(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    int16_t status = GOOD;

    if (!IS_NRDC_SN(ptCi))
    {
        return status;
    }

    // Update Statistics (SCG failure count per failureType)
    FnVCCB_IncrementNrdcScgFailureStat(ptCi, SCG_FAIL_COUNT);      // SN-init

    if (NrDcScgFailure_NoEvent == ptCi->nrdcScgFailureInfo.event)
    {
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerRadioConnectionWithUeLost;
        ptCi->nrdcScgFailureInfo.event = NrDcScgFailure_SnInit_Suspend;

        if (0 != pGnb->cfg.scgFailureHandlingInfoNrDc.suspendTimer &&
            NrDcScgFailureSuspendAndResume == ptCi->nrdcScgFailureInfo.failAction)
        {
            ptCi->cause.xnCause = CauseXnapRadioNetworkLayerRadioConnectionWithUeLost;

            status = FnVCCB_ProcSCGFailWithSuspendSN(ptCi);
            if (status == ERROR)
            {
                // SVR24B FR300: CRR
                FnVCCB_StatCallFaultPerFailCauseSCGFailure_NRDC(ptCi, F1_UEContextModificationRequired_id);
                VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_ProcSCGFailWithSuspendSN ERROR!\n");

                ptCi->cause.xnCause = CauseXnapRadioNetworkLayerRadioConnectionWithUeLost;
                ptCi->nrdcScgFailureInfo.failAction = NrDcScgFailureSnRelease;
                ptCi->mrdcInfo.sNodeRelCause = MrdcRelCause_SCGSuspendTimeOut;

                // SVR24A FR230
                CONVERT_AND_SAVE_NRDC_CTX_REL(ptCi, XN_SNodeReleaseRequired_id);

                // Trigger SN-Init SN Release..
                if (VCCB_CALL_RELEASE_TRIGGER(ptCi) != GOOD) // Call Job Release
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_CALL_RELEASE_TRIGGER ERROR!\n");
                }
            }
        }
        // FR10: If suspend timer is 0, it starts SN-init SN-release
        else
        {
            // SVR24B FR300: CRR
            FnVCCB_StatCallFaultPerFailCauseSCGFailure_NRDC(ptCi, F1_UEContextModificationRequired_id);

            ptCi->nrdcScgFailureInfo.failAction = NrDcScgFailureSnRelease;
            ptCi->mrdcInfo.sNodeRelCause = MrdcRelCause_SCGSuspendTimeOut;

            // SVR24A FR230
            CONVERT_AND_SAVE_NRDC_CTX_REL(ptCi, XN_SNodeReleaseRequired_id);

            // Trigger SN-Init SN Release..
            if (VCCB_CALL_RELEASE_TRIGGER(ptCi) != GOOD) // Call Job Release
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_CALL_RELEASE_TRIGGER ERROR!\n");
            }
        }
    }
    else
    {
        // discard DU-Init SCG procedure in the suspended status
        VCCB_PRINT_CALL_ERROR(ptCi,
            "F1_UEContextModificationRequired(RLF) is discarded (stateCmd:%d, nrdcScgFailureInfo.event:%d)\n",
            ptCi->stateCmd, ptCi->nrdcScgFailureInfo.event);
    }

    return GOOD;
}

