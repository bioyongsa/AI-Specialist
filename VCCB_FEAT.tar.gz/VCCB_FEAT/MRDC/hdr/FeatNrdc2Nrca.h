#ifndef VCCB_FEAT_NRDC_2_NRCA_H_
#define VCCB_FEAT_NRDC_2_NRCA_H_
// FGR-CC5200:FR1010

#include "VccbStruct.h"

// Common
#include "ComMacro.h"
#include "ComGlobalData.h"
#include "ComPrint.h"
#include "ComEg.h"
#include "ComUtil.hpp"

// Rsc
#include "RscGnb.h"
#include "RscCall.h"
#include "RscCell.h"

// State
#include "StateMeasurements.h"
#include "StateHandleSaMrdc.h"

#include "FeatCallInfo.h"

VCCB_STATIC_INLINE bool FnVCCB_IsSupportNrdc2NrcaLB(callInfo_type &rCall)
{
    const VccbGnbInfo_type *const pGnb = FnVCCB_GetGnbInfo(rCall.gnbNum);
    VALID_E_POINT_CHECK_RET_VAL(pGnb, false);

    if (!FOO.VF_BasicOperationforNRDC_FR1010)
    {
        return false;
    }

    if (!pGnb->cfg.nrdc.nrdc2nrcaLB.usage)
    {
        return false;
    }

    return true;
}
VCCB_STATIC_INLINE void FnVCCB_InitNrdc2NrcaLBCtxt(callInfo_type &rCall)
{
    rCall.nrdc2nrcaLBCtx.noOfEntries = 0;
    rCall.nrdc2nrcaLBCtx.needRefresh = VCCB_FLAG_OFF;
}
void FnVCCB_RecoverA4MeasCfgFromRemovedMeasFreq(callInfo_type &rCall, uint32_t ssbArfcn);
int FnVCCB_RemovedMeasFreqforNrdc_Cmd(callInfo_type &rCall, uint32_t ssbArfcn, enumRemovedMeasFreqCrtl_type ctrlCmd);
bool FnVCCB_IsNrcaBetterThanNrdc(callInfo_type &rCall, uint16_t bandIndi, uint16_t cellNum, uint16_t nbrIdx, enumRuleCheckNrdc2NrcaLB_type ruleChk);
int FnVCCB_PreChkNrdc2NrcaLB(callInfo_type &rCall, uint32_t ssbFreq);
int FnVCCB_FinalizeNrdc2NrcaLB(callInfo_type &rCall, uint32_t ssbFreq);

#endif  // _FEAT_NRDC_2_NRCA_H_