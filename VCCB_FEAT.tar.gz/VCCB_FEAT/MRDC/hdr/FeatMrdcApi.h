#ifndef VCCB_FEAT_FeatMrdcApi_H_
#define VCCB_FEAT_FeatMrdcApi_H_

#include "VccbStruct.h"

typedef struct
{
    enumNrdcBearerTermPointType terminated_point;  
    bool existMCG;                    // 'TRUE' exist Master Cell Group, 'FALSE' not exist Master Cell Group
    bool existSCG;                    // 'TRUE' exist Secondary Cell Group, 'FALSE' not exist Secondary Cell Group
    bool splitDRB;                    // 'TRUE' XX Term Split, 'FALSE' MCG or SCG Only

} mrdcDrbDetailInfo;

typedef struct
{
    uint32_t reserved;

} mrdcQosFlowDetailInfo;

typedef struct
{
    uint32_t existMnTerm : 1;  // TODO :: TBD
    uint32_t existSnTerm : 1;  // TODO :: TBD
    uint32_t splitPDU    : 1;  // TODO :: TBD

} mrdcPduDetailInfo;

typedef bool (*FP_IsCheckFunc)(const callInfo_type *, const callDRBInfo_type *, enumDrbBearerTag_type);

/****************************************************************************
 0. COMMON API
****************************************************************************/
uint8_t FnVCCB_getSaDrbBearerType(const callInfo_type *, const callDRBInfo_type *, enumDrbBearerTag_type);
const char *FnVCCB_GetBearerTypeValStr(const int);

/****************************************************************************
 1. DRB API
****************************************************************************/

// 1.1 Low Level Api
mrdcDrbDetailInfo FnVCCB_GetDetailInfoPerDRB(const callInfo_type *, const callDRBInfo_type *, enumDrbBearerTag_type);

bool FnVCCB_IsExistMcgPerDRB(const callInfo_type *, const callDRBInfo_type *, enumDrbBearerTag_type);
bool FnVCCB_IsExistScgPerDRB(const callInfo_type *, const callDRBInfo_type *, enumDrbBearerTag_type);
bool FnVCCB_IsSplitPerDRB(const callInfo_type *, const callDRBInfo_type *, enumDrbBearerTag_type);

enumNrdcBearerTermPointType FnVCCB_GetTermDrbPerDRB(const callInfo_type *, const callDRBInfo_type *, enumDrbBearerTag_type);

// 1.2 High Level Api

// 1.2.1 Common
bool FnVCCB_IsChangedTerminationPoint(const callInfo_type *, const callDRBInfo_type *);
void FnVCCB_ChangeAllValidDrbStatus(callInfo_type *, enumSABearerStatus_type );

// 1.2.2 MN Term
bool FnVCCB_IsMnTermScgLegPerDRB(const callInfo_type *, const callDRBInfo_type *, enumDrbBearerTag_type);
bool FnVCCB_IsMnTermPerDRB(const callInfo_type *, const callDRBInfo_type *, enumDrbBearerTag_type);
bool FnVCCB_IsMnTermSplitPerDRB(const callInfo_type *, const callDRBInfo_type *, enumDrbBearerTag_type);

// 1.3.1 SN Term
bool FnVCCB_IsSnTermSplitPerDRB(const callInfo_type *, const callDRBInfo_type *, enumDrbBearerTag_type);
bool FnVCCB_IsSnTermScgPerDRB(const callInfo_type *, const callDRBInfo_type *, enumDrbBearerTag_type);
bool FnVCCB_IsSnTermPerDRB(const callInfo_type *, const callDRBInfo_type *, enumDrbBearerTag_type);

/****************************************************************************
 2. QOS FLOW API
****************************************************************************/

/****************************************************************************
 3. PDU API
****************************************************************************/

// 4.1 MN Term
bool FnVCCB_IsAnyMnTermScgLegPerPDU(const callInfo_type *, const callPDUSessInfo_type *, enumDrbBearerTag_type);
bool FnVCCB_IsAnyMnTermPerPDU(const callInfo_type *, const callPDUSessInfo_type *, enumDrbBearerTag_type);

// 4.2 SN Term
bool FnVCCB_IsAnySnTermSplitPerPDU(const callInfo_type *, const callPDUSessInfo_type *, enumDrbBearerTag_type);
bool FnVCCB_IsAnySnTermPerPDU(const callInfo_type *, const callPDUSessInfo_type *, enumDrbBearerTag_type);

/****************************************************************************
 4. UE API
****************************************************************************/

// 4.1 MN Term
bool FnVCCB_IsAnyMnTermScgLegPerUE(callInfo_type *, enumDrbBearerTag_type);
bool FnVCCB_IsAnyMnTermPerUE(callInfo_type *, enumDrbBearerTag_type);
bool FnVCCB_IsAnyMnTermSplitPerUE(callInfo_type *ptCi, enumDrbBearerTag_type tag);

// 4.2 SN Term
bool FnVCCB_IsAnySnTermSplitPerUE(callInfo_type *, enumDrbBearerTag_type);
bool FnVCCB_IsAnySnTermPerUE(callInfo_type *, enumDrbBearerTag_type);

/****************************************************************************
 5. MRDC INFO API
****************************************************************************/

bool FnVCCB_IsMrdcProcedure(callInfo_type *ptCi, enumMrdcProcedureCode_type code, enumMrdcProcedurePurpose_type purpose);
bool FnVCCB_IsNrdcAllowedPartialSuccess(callInfo_type *ptCi);


bool FnVCCB_IsNrdcCaProhibitedStaticallyByLtmHO(callInfo_type &rCi, const uint16_t bandNr);
bool FnVCCB_IsNrdcProhibitedByLtmHO(callInfo_type &rCi, const uint16_t bandNr);
bool FnVCCB_DoesAnySvcGrpHasLtmCandidateCells(callInfo_type &rCi);
bool FnVCCB_IsNrdcCaProhibitedOperationallyByLtmHO(callInfo_type &rCi);
#endif
