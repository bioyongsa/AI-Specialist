#ifndef VCCB_FEAT_FeatScgFailureNRDC_H_
#define VCCB_FEAT_FeatScgFailureNRDC_H_

#include "VccbStruct.h"

#ifdef __cplusplus
extern "C" {
#endif

int16_t FnVCCB_ProcSCGFailWithSuspendMN(callInfo_type *);
int16_t FnVCCB_ProcSCGFailWithSuspendSN(callInfo_type *);
int16_t FnVCCB_ProcSCGFailWithResumeMN(callInfo_type *);
int16_t FnVCCB_CheckAndProcess_SCGFailureNRDC_SN(callInfo_type *);
int16_t FnVCCB_HandleSCGFailureInfo(callInfo_type *);               // handling NRRRC SCGFailureInfo at MN
int16_t FnVCCB_HandleF1RLF(callInfo_type *);                        // handling F1 UEContextModRequired at SN

#ifdef __cplusplus
};
#endif

#endif
