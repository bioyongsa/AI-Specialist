#ifndef VCCB_FEAT_FeatUlPathControlENDC_H_
#define VCCB_FEAT_FeatUlPathControlENDC_H_

#include "VccbStruct.h"

uint8_t VCCM_SetDataStallConfiguration(callInfo_type *ptCi, uint16_t cellNum);
void FnVCCB_DataStallPreventionTriggerHandler(callInfo_type *ptCi);
void VCCM_SelectInitialPrimaryUlPath(callInfo_type *ptCi);
void FnVCCB_SetUlPrimaryPathMode(callInfo_type *ptCi, uint16_t cellNum);
void VCCM_SetSplitDrbUlPdcpPath(callInfo_type *ptCi);
void FnVCCB_SetInitialDynamicRsrpRsrq(callInfo_type *ptCi, uint16_t cellNum);
void FnVCCB_SetPtciUlPdcpPath(callInfo_type *ptCi, uint16_t cellNum);
bool FnVCCB_Check_toSet_McgOnlyUlPathENDC_during_HO(callInfo_type *ptCi);
int16_t VCCM_UpdateUlPdcpPathParameter(callInfo_type *ptCi);
void FnVCCB_ChangeCellCongestionState(sonCellPrbRsc_type *ptMsg, uint16_t cellNum);
bool FnVCCB_IsVipUeUlPathSwitchActive(uint16_t gnbNum);
bool FnVCCB_IsUlPathSwitchImpactedByVipUe(callInfo_type *ptCi, uint16_t cellNum);
bool FnVCCB_IsUlPathSwitchPreventedByVipUe(callInfo_type *ptCi);
bool FnVCCB_InstallA1PreventedByVipUe(callInfo_type *ptCi);
void FnVCCB_StartUlPathVipUeTimer(uint16_t gnbNum, uint16_t cellNum);
void FnVCCB_StopUlPathViUeTimer(uint16_t cellNum);
uint8_t FnVCCB_MarkCongestionStateUe(callInfo_type *ptCi, uint16_t cellNum);
bool FnVCCB_IsCongestionStateActive(const callInfo_type *ptCi);
bool FnVCCB_PacketInspectionONQciBasedUlSplitThSwitchOFF(callInfo_type *ptCi);
void FnVCCB_MarkArp2UeForUlPathThreshSwitch(callInfo_type *ptCi);
void FnVCCB_ResetCongestion(VccbGnbInfo_type *pGnb, uint16_t gnbNum);
bool FnVCCB_Check_UlPathENDC_Cell_CongestionIn(VccbGnbInfo_type *pGnb, VccbCellInfo_type *pCell);
bool FnVCCB_Check_UlPathENDC_Cell_CongestionOut(VccbGnbInfo_type *pGnb, VccbCellInfo_type *pCell);
void FnVCCB_SetUlPathSwitchwithHighLatency(callInfo_type *ptCi, uint16_t cellNum, uint16_t mcgUlTrafficFlag, uint16_t scgUlTrafficFlag, callERABInfo_type &erabInfo);

#endif
