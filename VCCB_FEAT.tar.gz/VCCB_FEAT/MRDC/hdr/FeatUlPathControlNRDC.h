#ifndef VCCB_FEAT_FeatUlPathControlNRDC_H_
#define VCCB_FEAT_FeatUlPathControlNRDC_H_

#include "VccbStruct.h"

typedef enum
{
    SCG_RESOURCE_UNAVAILABLE = 0,
    SCG_RESOURCE_AVAILABLE = 1,
} enumSamsungUlPathUsageIndication;

uint8_t VCCM_NrdcSetDataStallConfiguration(callInfo_type *ptCi, uint16_t cellNum);
void VCCM_SelectBearerUlPath_NRDC(
    callInfo_type *const ptCi, callDRBInfo_type *const ptDi, const bool isIntraHoInProgress);
void VCCM_InspectSplitBearers(
    const callInfo_type *const ptCi, bool *const pExistMnTermSplitBearer, bool *const pExistSnTermSplitBearer);
void VCCM_UpdateUlPathSwitchingAbility(callInfo_type *const ptCi);
void VCCM_UpdateBearerUlDataSplitThresholdFr1Fr2(callInfo_type *const ptCi, callDRBInfo_type *const ptDi);
void VCCM_SelectUlPath_NRDC(callInfo_type *ptCi, const bool isIntraHoInProgress);
void VCCM_SelectInitialUlPath_NRDC(callInfo_type *ptCi);
int16_t VCCB_NrdcUlPathControl_SendConfigurationToCU(callInfo_type *ptCi);
int16_t VCCB_NrdcUlPathControl_SendConfigurationToMN(callInfo_type *ptCi);
int16_t VCCB_NrdcUlPathControl_SendConfigurationToUE(callInfo_type *ptCi);
bool VCCB_NrdcUlPathControl_IsPathChangeOngoing(callInfo_type *ptCi);
void VCCB_NrdcUlPathControl_CollectPathChangeStats(callInfo_type *ptCi);

#endif
