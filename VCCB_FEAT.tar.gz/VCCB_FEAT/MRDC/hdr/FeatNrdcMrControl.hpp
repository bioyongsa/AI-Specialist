#ifndef VCCB_FEAT_MRDC_MR_CONTROL_HPP_
#define VCCB_FEAT_MRDC_MR_CONTROL_HPP_
#include "VccbStruct.h"
#include <vector>
#include <map>
#include <memory>

#define VCCB_PRINT_CALL_NRDC_MR_CONTROL(__fmt, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_TRACE_COMMON(DBG->flag.nrdcMrControl, &_call, __fmt, ##__args)
double FnVCCB_GetAvgAvailResourceByFreqForNrdc(const callInfo_type &call, uint32_t targetCellNum, uint32_t ssbFreq);
int FnVCCB_CalculateLbThresholdForScgBandSel(const callInfo_type &call);
void FnVCCB_CommitFastAccTimerCtrlForScgBandSel(callInfo_type &rCall);
bool FnVCCB_IsFastAccTimerActivated(callInfo_type &rCall);
bool FnVCCB_CheckLoadBasedScgBandSelCondition(callInfo_type &rCall, uint16_t nbrIdx, uint32_t ssbFreq);

enum class SortOrder
{
    ASCENDING,
    DESCENDING
};

class CapacityOption  // access-enum-nrdc-scg-band-selection-capa-option
{
public:
    enum Type
    {
        DL,
        UL,
        BOTH
    };

    static const char *toString(Type option)
    {
        static const char *const OPTION_STRINGS[] = {"DL", "UL", "BOTH"};
        return OPTION_STRINGS[static_cast<int>(option)];
    }
};

constexpr double EPSILON = 0.000001;  // for compare double value
static bool isValidResource(double resource) { return resource >= -EPSILON; }
constexpr double INVALID_RESOURCE = -1.0;

struct resourcePair_s
{
    double dl;
    double ul;
    resourcePair_s operator/(int divisor) const { return {dl / divisor, ul / divisor}; }
    resourcePair_s &operator+=(const resourcePair_s &other)
    {
        dl += other.dl;
        ul += other.ul;
        return *this;
    }
    bool operator==(const resourcePair_s &other) const
    {
        return std::abs(dl - other.dl) < EPSILON && std::abs(ul - other.ul) < EPSILON;
    }
    static bool isValidResourcePair(resourcePair_s resourcePair)
    {
        return (isValidResource(resourcePair.dl) && isValidResource(resourcePair.ul));
    }
};

inline constexpr resourcePair_s INVALID_RESOURCE_PAIR = {INVALID_RESOURCE, INVALID_RESOURCE};

class NrdcSonNbrResourceManager
{
#ifdef VCCB_IPC_TEST
    friend class NrdcMrControlTest;
#endif
public:
    struct frequencyResource_type
    {
        std::vector<double> dl, ul;
        int size() const { return static_cast<int>(std::min(dl.size(), ul.size())); }
    };
    using FrequencyResourceMap_type = std::map<uint32_t, frequencyResource_type>;
    NrdcSonNbrResourceManager(const callInfo_type &call, const VccbCellInfo_type &cell) : _call(call), _cell(cell) {};

    FrequencyResourceMap_type &getFrequencyAvailableResourcesMap() { return _frequencyResourceMap; }
    int getMapSize() { return static_cast<int>(_frequencyResourceMap.size()); };
    resourcePair_s calculateSumOfTopNAvailableResourcePair(
        frequencyResource_type &frequencyResources, int loadTopN, SortOrder order);
    void buildFrequencyResourceMap();
    static resourcePair_s calculateAvailableResourcePair(const sonNbrPrbRsc_type &rNbrPrb);
    static inline bool isValidNbrPrb(const sonNbrPrbRsc_type &rNbrPrb){ return (rNbrPrb.usage == EQUIP && rNbrPrb.isRsUpdate == ON); }

private:
    const callInfo_type &_call;
    const VccbCellInfo_type &_cell;
    FrequencyResourceMap_type _frequencyResourceMap;

    void insertToFrequencyResourcesMap(uint32_t nbrSsbFreq, const resourcePair_s &resourcePair);
    void printFrequencyResourcesMap();
};

class TransactionIdManager
{
public:
    TransactionIdManager(const VccbCellInfo_type &cell, uint32_t &transId) : _cell(cell), _transId(transId) {};
    bool isResourceUpdated() { return _transId != _cell.rsuTransId; }
    void updateTransId() { _transId = _cell.rsuTransId; }

private:
    const VccbCellInfo_type &_cell;
    uint32_t &_transId;
};

class NrdcMeasIdOrderingDBController
{
public:
    nrdcMeasIdOrderingMgmt_type &_availableResourceDB;
    NrdcMeasIdOrderingDBController(nrdcMeasIdOrderingMgmt_type &measurementOrderingDb) :
        _availableResourceDB(measurementOrderingDb) {};
    void clear() { _availableResourceDB.numOfFreq = 0; }
    uint32_t size() { return _availableResourceDB.numOfFreq; }
    bool isFull() { return size() >= MAX_NR_OF_OBJECT_ID_DB; }
    uint32_t getTransId() { return _availableResourceDB.rsuTransId; }
    void insert(uint32_t ssbFreq, double averageAvailableResource);
    double getResource(uint32_t ssbFreq);
};

class NrdcMeasIdOrderingManager
{
public:
    NrdcMeasIdOrderingManager(const callInfo_type &call, const VccbCellInfo_type &cell, const VccbGnbInfo_type &gnb,
        nrdcMeasIdOrderingMgmt_type &measurementOrderingDb,
        std::unique_ptr<NrdcSonNbrResourceManager> sonNbrResourceManager = nullptr) :
        _call(call),
        _cell(cell),
        _capacityOption(static_cast<CapacityOption::Type>(gnb.cfg.nrdc.capacityOptionForMeasureOrdering)),
        _availableResourceDB(measurementOrderingDb),
        _sonNbrResourceManager(sonNbrResourceManager ? std::move(sonNbrResourceManager)
                                                     : std::make_unique<NrdcSonNbrResourceManager>(call, cell)),
        _transactionIdManager(cell, measurementOrderingDb.rsuTransId) {};

    double getAverageAvailableResource(uint32_t frequency);

private:
    const callInfo_type &_call;
    const VccbCellInfo_type &_cell;
    CapacityOption::Type _capacityOption;
    NrdcMeasIdOrderingDBController _availableResourceDB;
    std::unique_ptr<NrdcSonNbrResourceManager> _sonNbrResourceManager;
    TransactionIdManager _transactionIdManager;

    static const int MAX_LOAD_TOP_N = 7;
    static const int MIN_LOAD_TOP_N = 1;

    int getLoadTopN(uint32_t ssbFreq);
    bool isValidLoadTopN(int loadTopN) { return (loadTopN >= MIN_LOAD_TOP_N && loadTopN <= MAX_LOAD_TOP_N); }
    double selectResourceByOption(resourcePair_s resource);
    double calculateAverageOfResources(
        NrdcSonNbrResourceManager::frequencyResource_type &frequencyResources, int loadTopNOfFrequency);
    void updateAvailableResources();
};

class NrdcScgBandSelectionManager
{
public:
    NrdcScgBandSelectionManager(const callInfo_type &call, const VccbCellInfo_type &cell,
        nrdcScgBandSelectionMgmt_type &scgBandSelectionDb,
        std::unique_ptr<NrdcSonNbrResourceManager> nrdcSonNbrResourceManager = nullptr) :
        _call(call),
        _cell(cell),
        _scgBandSelectionThreadDB(scgBandSelectionDb),
        _sonNbrResourceManager(nrdcSonNbrResourceManager ? std::move(nrdcSonNbrResourceManager)
                                                         : std::make_unique<NrdcSonNbrResourceManager>(call, cell)),
        _transactionIdManager(cell, scgBandSelectionDb.rsuTransIdForLb) {};

    int updateLBThreshold();

private:
    const callInfo_type &_call;
    const VccbCellInfo_type &_cell;
    nrdcScgBandSelectionMgmt_type &_scgBandSelectionThreadDB;
    std::unique_ptr<NrdcSonNbrResourceManager> _sonNbrResourceManager;
    TransactionIdManager _transactionIdManager;

    static const int MAX_LOAD_TOP_N = 32;
    static const int MIN_LOAD_TOP_N = 0;

    void setThreadDBThreshold(resourcePair_s threshold);
    bool isValidLoadTopN(int loadTopN) { return (loadTopN >= MIN_LOAD_TOP_N && loadTopN <= MAX_LOAD_TOP_N); }
    resourcePair_s calculateAverageOfResources();
};

class FastAccessTimerManager
{
public:
    FastAccessTimerManager(callInfo_type& rCall);
    
    void resetTimer();
    void controlTimer();
    bool isActivated() const;
    bool isExpired() const;

private:
    callInfo_type& _call;
    uint16_t _cellNum;
    
    static const int MAX_MR_WAITING_TIMER_MS = 6000;

    bool isFastAccessModeSupported() const;
    bool hasNrdcMeasConfig() const;
    void setTimer();
};

class FastAccessConditionChecker
{
public:
    FastAccessConditionChecker(callInfo_type& rCall, const VccbCellInfo_type& rCell, const sonNbrPrbRsc_type& rNbrPrb, const uint32_t ssbFreq);
    
    bool checkConditions();

private:
    callInfo_type& _call;
    const VccbCellInfo_type& _cell;
    const sonNbrPrbRsc_type& _nbrPrb;
    const uint32_t _ssbFreq;
    const uint8_t _capaOption = _cell.scgBandSelectionConfig.scgBandCapacityOption;
    
    bool isLbConditionMet();
    bool isOverloadConditionMet(const measurementObjectNRDb_type& measObjDB);
    bool isAvailableUeConditionMet(const measurementObjectNRDb_type& measObjDB);
    bool isLbThresholdCheckNeeded();
};
#endif
