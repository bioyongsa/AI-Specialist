
/**
 * @file        FeatMrdc.h
 * @brief       Utility functions for Handover
 */

#ifndef VCCB_FEAT_FeatMrdc_H_
#define VCCB_FEAT_FeatMrdc_H_

#include "VccbStruct.h"
#include "FeatMrdcApi.h"
#include "FeatNrdc2Nrca.h"
#include "NRRRC.h"

int getBuffMgmt(int32_t argc, char *argv[]);

int VLIB_InitBuffMgmt(void);
void VLIB_FreeBuffMgmt(void);
char *VLIB_GetBuffer(callInfo_type *, unsigned int, unsigned char);
void VLIB_FreeBuffer(callInfo_type *, char *, const char *);
int FnVCCB_InitMrdcMutexes(pthread_mutexattr_t *pAttr);
bool FnVCCB_CheckValidEndPointXn_ForSN(uint16_t epIdx);
void FnVCCB_InitMrdcMnInfo(MNInfo_type *ptMnInfo);
void FnVCCB_InitMrdcSnInfo(SNInfo_type *ptSnInfo);
int16_t VLIB_AllocMrdcInfo(callInfo_type *, enumMrdcUeCtxType_type ueCtxType);
void FnVCCB_ReUpdateBearerType(callInfo_type *ptCi);
int16_t FnVCCB_UpdateBearerTypeForHandover(callInfo_type *ptCi, enumMrdcHoScenario_type type);
void FnVCCB_UpdateCallInfoForHandover_SnRelease(callInfo_type *ptCi);
int16_t VLIB_AllocMrdcInfoForHandover(callInfo_type *ptCi, enumMrdcUeCtxType_type ueCtxType);
void FnVCCB_XNAP_HandoverRequest_DecisionMrdcUE(callInfo_type *ptCi, XN_HandoverRequest_type *ptMsg);
void FnVCCB_NRRRC_AsConfig_DecisionMrdcUE(callInfo_type *ptCi, NRRRC_AS_Config *p);
void FnVCCB_InitSnNGuUlInfo(callInfo_type *ptCi, callPDUSessInfo_type *pPi);

void FnVCCB_Mrdc_FreeBuffer_octetString(callInfo_type *ptCi, octetStringType *ptOct);
void FnVCCB_Mrdc_Init_octetString(callInfo_type *ptCi, octetStringType *ptOct);
int16_t FnVCCB_Mrdc_Store_octetString(
    const char *ptFunc, callInfo_type *ptCi, octetStringType *ptDestOct, const NRRRC__octet1 *ptSrcOctet);
int16_t FnVCCB_Mrdc_Fill_octetString(NRRRC__octet1 *ptDestOct, const octetStringType *ptSrcOctet);

// scgCellGrpConfig
int16_t VLIB_CheckValid_MrdcScgCellGrpConfig(mrdcInfo_type *pMrdcInfo);
void VLIB_Init_MrdcScgCellGrpConfig(callInfo_type *ptCi, mrdcInfo_type *pMrdcInfo);
int16_t VLIB_Store_MrdcScgCellGrpConfig(callInfo_type *ptCi, mrdcInfo_type *pMrdcInfo, NRRRC__octet1 *pSrcOctet);
int16_t VLIB_Fill_MrdcScgCellGrpConfig(mrdcInfo_type *pMrdcInfo, NRRRC__octet1 *pTgtOctet);

// scgRBConfig
int16_t FnVCCB_CheckValid_MrdcSNRBConfig(mrdcInfo_type *pMrdcInfo);
int16_t FnVCCB_Store_MrdcScgRBConfig_ForPack(callInfo_type *ptCi, NRRRC__octet1 *pSrcOctet);
int16_t FnVCCB_Store_NrdcScgRBConfig(callInfo_type *ptCi, NRRRC__seq118 *pSrcOctet);
int16_t FnVCCB_Fill_MrdcscgRBConfig(mrdcInfo_type *pMrdcInfo, NRRRC__octet1 *pTgtOctet);

void VLIB_FreeBuffAllMrdcInfo(callInfo_type *ptCi, int printLevel);
void VLIB_ReleaseMrdcInfo(callInfo_type *);
bool VLIB_IsAllowedEutraCellforPLMN(callInfo_type *, nbrEnbCellInfo_type *, hoRestrictInfo_type *);
// bool VLIB_IsForbidden5GcTAC(callInfo_type *, hoRestrictInfo_type *, plmnId_type *, uint32_t);
void VLIB_StoreBestMeasResultEutraCGI(callInfo_type *, measResultEUTRA_type *, nbrEnbCellInfo_type *);
bool VLIB_IsAllowedEarfcnforAllowedBCList(callInfo_type *, uint32_t);
bool VLIB_IsSNModificationRequired(callInfo_type *ptCi);
bool VLIB_IsAnySpiltDrbAddMod(callInfo_type *ptCi);
void FnVCCB_ReproduceUeAMBRforMRDC(callInfo_type *ptCi);
void FnVCCB_ClearUeSliceMBRforNRDC(callInfo_type &rCi);
void FnVCCB_ReproduceUeSliceMBRforMRDC(callInfo_type &rCi, bool skipCfgUpdate = false);
void FnVCCB_GetNrdcUeSliceMbrConfig(callInfo_type &rCi);
void FnVCCB_InitPdcpSNStatusInfo(callInfo_type *ptCi);
int16_t VLIB_Set_CGConfigInfoPresent(callInfo_type *ptCi, uint32_t *pBitMask);
int16_t VLIB_Set_NedcPowerCoordination(callInfo_type *ptCi, powerCoordination_FR1_type *pDst);
int16_t VLIB_Set_MrdcServCellIndexRangeSCG(callInfo_type *ptCi, servCellIndexRangeSCG_type *pCellIdxRange);
void VLIB_Set_MrdcConfigRestrictionInfo(callInfo_type *ptCi);
int16_t FnVCCB_StoreSBCList(callInfo_type *ptCi, NRRRC_RF_Parameters *pMsg);
void FnVCCB_recoveryMrdcInfoForHandoverCancel(callInfo_type *ptCi);
int16_t VLIB_Set_MrdcAllowedBCListMRDC(callInfo_type *ptCi, CellNum_type cellNum, FreqBandInd_type cellBand,
    bandCombinationInfoList_type *pDst, uint8_t isNRCapa, uint8_t isHandoverCase);
void VLIB_UpdateSelectedBandEntryMNBitMap(callInfo_type *ptCi, CellNum_type cellNum);
void FnVCCB_updateMrdcPrevInfo(callInfo_type *ptCi);
void FnVCCB_restoreMrdcPrevInfo(callInfo_type *ptCi);

/* MrdcScgCellGrpConfig */
/* MrdcScgConfigQuery */
void VLIB_Set_MrdcScgConfigQuery(callInfo_type *ptCi, enumVccbFlag flag);
int16_t VLIB_Get_MrdcScgConfigQuery(callInfo_type *ptCi);
/* Finalize */
void VLIB_FinalizeSNRelMrdc(callInfo_type *ptCi, int ctrlFlag);
void VLIB_InitMrdcProperty(callInfo_type *ptCi);

/* mNtoSNContainerPresent */
int16_t VLIB_Check_Need_Mn2SnContainer(callInfo_type *ptCi);  // NEDC_SCG_FAILURE_20C

void FnVCCB_ClearSnMrdcInfo(callInfo_type *ptCi);
bool FnVCCB_DoesNeedReconfigforMrdcAdd(callInfo_type *ptCi);
void VLIB_setReqBearerTypeForMrDc(
    callInfo_type *ptCi, callDRBInfo_type *pDRBInfo, int type, const char *fnName);
void VLIB_setBearerTypeForMrDc(
    callInfo_type *ptCi, callDRBInfo_type *pDRBInfo, int type, const char *fnName);
void VLIB_setSelectedBearerTypeForMrDc(
    callInfo_type *ptCi, callDRBInfo_type *pDRBInfo, uint8_t flag, int type, const char *fnName);

void VLIB_CancelBearerTypeForMrDc(callInfo_type *ptCi);
void VLIB_FinalizeBearerTypeForMrDc(callInfo_type *ptCi);

void VLIB_UpdateBearerTypeForMrDcRelease(callInfo_type *ptCi);
int dsh_GetMrdcBuffInfo(int32_t argc, char *argv[]);
int dsh_SetMrdcBuffInit(int32_t argc, char *argv[]);
int dsh_SetMrdcMutexInit(int32_t argc, char *argv[]);
void VLIB_DbgPrint_MrdcBandCombList(callInfo_type *ptCi, bandCombinationList_type *pMrdcBandCombList);
void VLIB_DbgPrint_MrdcFeatureSetCombinationList(
    callInfo_type *ptCi, MrdcFeatureSetCombinationList_type *pMrdcFsCombList);
void VLIB_DbgPrint_AllowedBCList(callInfo_type *ptCi, bandCombinationInfoList_type *pBandCombList, bool isNrdcBC, bool isBandCombListBuffValid);
int16_t VLIB_IsAnyBearerTypeChangingPerPDUSess(callInfo_type *ptCi, callPDUSessInfo_type *ptPDUSess);
void VLIB_ReconfigMrdcInfoAfterSwitchOver(callInfo_type *ptCi);
int16_t VLIB_EnqueueXnReleaseSNode(callInfo_type *ptCi, enumSNodeRelReasonType releaseReason);
int16_t FnVCCB_EnqueueSnNGuTNLUpdate(callInfo_type *ptCi);
void VLIB_CommitRadioBearerConfigNEDC(callInfo_type *ptCi);
void VLIB_SetNeDcBearerStatusToIdle(callInfo_type *ptCi);
int16_t VLIB_CheckPowerDistributionNEDC(callInfo_type *ptCi);
void VLIB_InitMrdcBearerType(callInfo_type *ptCi);
void FnVCCB_SetSelectedMrdcType(callInfo_type *ptCi, uint16_t cellNum, enumMrdcType_type selectedMrdcType);  // NRDC
void FnVCCB_StoreBestMeasResultNRCGI(callInfo_type *ptCi, measResultNR_type *pBestMeasResultNR,
    nbrGnbCellInfo_type *pBestGnbCellInfo);  // NRDC
void FnVCCB_FinalizePduChgforMrdc(callInfo_type *ptCi);
void FnVCCB_DecidePduSplitStatus(callInfo_type *ptCi);
bool FnVCCB_CanbeSplitPDUSessionfromScgNonSplit(callInfo_type *ptCi);
bool FnVCCB_CanbeSplitPDUSession(callInfo_type *ptCi, callPDUSessInfo_type *pPi);
void FnVCCB_SetMrdcBearerTypeToStable(callInfo_type *ptCi);
void FnVCCB_SetMrdcRespFlagsForSNModify(callInfo_type *ptCi);
void FnVCCB_ClearInstantFlagOfMrdcInfo(callInfo_type *ptCi);
int16_t FnVCCB_NeedSnNGuUlTnlUpdate(callInfo_type *ptCi);
bool FnVCCB_DoesPDUSessExistAtMN(callInfo_type *ptCi, uint16_t pduIdxInCall);
void FnVCCB_SetPDUSessAndDrbStatusForF1BearerFallback(callInfo_type *ptCi);
void FnVCCB_SetPDUSessAndDrbStatusForE1BearerFallback(callInfo_type *ptCi);
void FnVCCB_SetSNRelOprType(callInfo_type *ptCi);
bool FnVCCB_IsSameSnssaiforMrdc(bool check_strict_sd, callSNSSAI_type sNssai_yang, callSNSSAI_type sNssai_internalDB);
void FnVCCB_SetReqBearerTypeforFallback(callInfo_type *ptCi, bool isSnRel);
void FnVCCB_SetReqBearerTypeforOffloading(callInfo_type *ptCi);
int16_t FnVCCB_MakeAllowedBCList(
    callInfo_type *ptCi, CellNum_type cellNum, FreqBandInd_type cellBand, NRRRC_UE_NR_Capability *pMsg, uint8_t isHandoverCase);
bool FnVCCB_IsAllowedNrBandforAllowedBCList(callInfo_type *ptCi, uint16_t bandInd);
void FnVCCB_AuditMrdcBuffer(void);
int16_t FnVCCB_CheckMrdcBuffer(void);
int16_t FnVCCB_CheckAuditMrdcBuffer(void);

bool FnVCCB_IsNewPDUSessAtSN(callInfo_type *ptCi, callPDUSessInfo_type *pPi);
int  FnVCCB_ReferenceBearerTypeAccordingToState(callInfo_type *ptCi, callDRBInfo_type *ptDi);

void FnVCCB_DecisionMrdc_E1CellGroupControlForDrb(
    callInfo_type *ptCi, callDRBInfo_type *ptDi, bool *pMcgCtrl, bool *pScgCtrl);

bool FnVCCB_IsNeedControl_MN_UP_ForDrb(callInfo_type *ptCi, callDRBInfo_type *ptDi);
bool FnVCCB_IsNeedControl_MN_UP_ForQos(callInfo_type *ptCi, qosFlowInfo_type *ptQi);
bool FnVCCB_IsNeedControl_SN_UP_ForDrb(callInfo_type *ptCi, callDRBInfo_type *ptDi);
bool FnVCCB_IsNeedControl_SN_UP_ForQos(callInfo_type *ptCi, qosFlowInfo_type *ptQi);
bool FnVCCB_NeedSNTermBearerTobeAddModRelSN(callInfo_type *ptCi);
void FnVCCB_IncrementNrdcRelStat(callInfo_type *ptCi, int msgId, uint16_t xnCause, uint8_t reserved);

// This function send or wait for XN Snode Reconfiguration Complete.
bool FnVCCB_NeedToSendXnSNodeReconfigurationComplete(callInfo_type *ptCi);
bool FnVCCB_NeedToRecvXnSNodeReconfigurationComplete(callInfo_type *ptCi);

// This function indicates nr/eutra-scgResponse can be included.
bool FnVCCB_CanBeIncludedSNRRCReconfigurationComplete(RrcReconfigurationCompleteBuff_type *pRrcReconfBuff);

// This function indicates nr/eutra-scgResponse should be received.
uint8_t FnVCCB_ShouldBeReceivedSNRRCReconfigurationComplete(callInfo_type *ptCi);

void FnVCCB_UpdateBearerTypeForHandover_SnRelease(callInfo_type *ptCi);

void FnVCCB_IncrementNrdcScgFailureStat(callInfo_type *ptCi, enumScgFailureStatType_type type);
void FnVCCB_PrintMrdcDrbInformation(callInfo_type *ptCi);

bool FnVCCB_NeedSNPDUSessTobeReleasedUnsolicitedly(callInfo_type *ptCi, callPDUSessInfo_type *ptPi);
void FnVCCB_ClearMrdcRespFlagforBothQosflowsAndDrbsPerPDU(callInfo_type *ptCi, callPDUSessInfo_type *ptPi);
void FnVCCB_ClearAllMrdcRespFlag(callInfo_type *ptCi);
void FnVCCB_ClearAllMrdcFlags(callInfo_type *ptCi);
void FnVCCB_set_MrdcSnRelMnEvent(callInfo_type *ptCi, uint32_t type);
void FnVCCB_set_MrdcSnRelSnEvent(callInfo_type *ptCi, uint32_t type);
bool FnVCCB_DoesPDUSessNeedTobeReleasedAtMnUp(callInfo_type *ptCi, callPDUSessInfo_type *ptPi);
int16_t FnVCCB_NeedToDlTrfStatusRptCfgforNrdcAddPerDRB(callInfo_type *ptCi, callDRBInfo_type *pDi);
bool FnVCCB_IsSRB3Available(callInfo_type *ptCi);

void FnVCCB_InitAllowedBCList(callInfo_type *ptCi, bandCombinationInfoList_type *pAllowedBCList);
bool FnVCCB_CheckPcellInfoChangedforAllowedBC(callInfo_type *ptCi, CellNum_type cellNum, FreqBandInd_type cellBand);
void FnVCCB_ReinstallMrdcBaseInfoAfterMobility(callInfo_type *ptCi, CellNum_type cellNum, FreqBandInd_type cellBand, uint8_t ctrlFlag);
int16_t FnVCCB_RunLoadBasedScgBandSelectionMRBased(callInfo_type *ptCi, frequencyAndBandIndiNR_type &freqAndBandIndiNR);
int16_t FnVCCB_DecideNrdcLoadBasedSCGBand(callInfo_type *ptCi, uint16_t newFreqBand);
int16_t FnVCCB_IsDrbBasedFallbackRequired(callInfo_type *ptCi);

bool FnVCCB_CheckNrdcMode(callInfo_type &rCall, uint16_t cellNum, uint8_t checkOperMode);
uint8_t FnVCCB_GetNrdcMode(callInfo_type &rCall, uint16_t cellNum);

void FnVCCB_SNModFbkPrepare_E1Mod2_SetPDUSessAndDrbStatusForF1BearerFallback(callInfo_type *ptCi);
int16_t FnVCCB_TriggerDrbBasedFallbackAtMN(callInfo_type *ptCi);
bool FnVCCB_NeedNGuTnlTobeModified(callInfo_type *ptCi, uint8_t nguTnlType);
bool FnVCCB_NeedDataFwdTnlTobeSentToSN(callInfo_type *ptCi);
int16_t FnVCCB_UpdateSnNGuTnl(callInfo_type *ptCi);
void FnVCCB_SetSDAPatSNFlagOfQosFlow(callInfo_type *ptCi, callDRBInfo_type *pDi, uint8_t flag);
void FnVCCB_Mark_SnNGuDlInfoIfNeedToModifyToSMF(callInfo_type *ptCi);

uint8_t FnVCCB_GetMrdcAdditionCmd(callInfo_type *ptCi);
bool FnVCCB_NeedMCGRbCfgTobeIncludedDuringBTC(callInfo_type *ptCi, callDRBInfo_type *ptDi);
int16_t FnVCCB_SetCaProfileBasedImc(callInfo_type *ptCi);

#ifdef IPC_TEST
void FnVCCB_TestAuditMrdcBufferPerBuffType(enumBuffType buffType);
bool FnVCCB_IsGnbRestrictedforNrdcSnByOvld(callInfo_type *ptCi, const vccbGlobalGnbId_type *targetGnbId);
#endif

void FnVCCB_InitTempCallInfoForNrdcSn(callInfo_type *ptTmpCi, uint8_t threadId, uint16_t gnbNum);

bool FnVCCB_IsValidNrdcSnPerGnb_ForMN(callInfo_type *ptCi, const vccbGlobalGnbId_type targetGnbId, XnIdx_type xnIdx);
bool FnVCCB_IsValidNrdcSnPerCell_ForMN(
    callInfo_type *, uint16_t, nbrGnbCellInfo_type *, hoRestrictInfo_type *, candidateNbrInformation_type *, const enumPSCellEligibilityCheckPerNbr_type filter);
bool FnVCCB_IsValidNrdcSnPerCell_ForSN(
    callInfo_type *, uint16_t , uint16_t , nbrGnbCellInfo_type *, hoRestrictInfo_type *, candidateNbrInformation_type *, measurementObjectNRUe_type *);
bool FnVCCB_IsGnbRestrictedforNrdcSn(callInfo_type *ptCi, const vccbGlobalGnbId_type targetGnbId);
void FnVCCB_InitRestrictedGnbsforNrdcSn(callInfo_type *ptCi);
int FnVCCB_CommonCheckTrfStatusRptCfgforNrdc(callInfo_type *ptCi, uint16_t cellNum);
int FnVCCB_EnqueueActionTrafficStatusReportForNrdc(callInfo_type *ptCi, enumTrafficStatusRptDir_type dir);
bool FnVCCB_IsAnyNrdcBearer(callInfo_type *ptCi);
void FnVccb_PrepareNrdcUlTrafficMonitor(callInfo_type *ptCi, uint16_t outstandingCellNum, uint16_t tGnbNum, uint16_t tCellIdentity);
enumMrdcType_type FnVCCB_DecideMrdcTypeForCell(callInfo_type *ptCi, uint16_t cellNum);
void FnVccb_InitNrdcUlTrafficMonitorCtx(callInfo_type *ptCi);
void FnVccb_SyncNrdcUlTrafficMonitor(callInfo_type *ptCi);
void FnVCCB_DoesPeerTobeRestrictedAfterRejected(callInfo_type *ptCi, XNAP_Cause_type *cause);
void FnVCCB_AddEntryforRestrictedGnbByOvld(callInfo_type *ptCi, vccbGlobalGnbId_type globalGnbId);
void FnVCCB_SetNrdcOverloadControl(callInfo_type *ptCi);
bool FnVCCB_IsPDUSessTobeSetupToUP(const callInfo_type *ptCi, const callPDUSessInfo_type &pduSess);
bool FnVCCB_IsAnyPDUSessTobeSetupToUP(callInfo_type *ptCi);
bool FnVCCB_IsNrdcAddCacRejectedFreq(callInfo_type *ptCi, uint32_t freq);
void FnVCCB_InitNrdcAddCacRejectedFreq(callInfo_type *ptCi);
void FnVCCB_ProcNrdcAddCacReject(callInfo_type *ptCi);
void FnVCCB_DecidePdcchBlindDetectionSCG(callInfo_type *ptCi, uint16_t cellNum, configRestrictInfoSCG_type *pCfgRestrictInfo);
int FnVCCB_NrdcCtxRelStat_ConvertXnCauseToSnCtxRelType(callInfo_type *ptCi, uint16_t msgId);
int FnVCCB_NrdcCtxRelStat_ConvertHoTypeToSnCtxRelType(callInfo_type *ptCi);
void FnVCCB_NrdcCtxRelStat_SaveSnRelType(callInfo_type *ptCi, int mType, enumSnDifferentiator_type snType);
int FnVCCB_NrdcCtxRelStat_ConvertSnCallReleaseToSnCtxRelType(enumNrdcSnCallReleaseType_type nrdcSnCallReleaseType);
void FnVCCB_NrdcCtxRelStat_SetCtrlInfo(
    callInfo_type *ptCi, enumNrdcCtxRelCtrlFlag_type flag, enumVccbFlag flagVal, uint16_t cellNum, enumSnDifferentiator_type snType);
uint16_t FnVCCB_NrdcCtxRelStat_GetCtrlFlag(callInfo_type *ptCi, enumSnDifferentiator_type snType, enumNrdcCtxRelCtrlFlag_type flag);
void FnVCCB_NrdcCtxRelStat_Collect(callInfo_type *ptCi, const char *fnName, enumSnDifferentiator_type snType);
void FnVCCB_NrdcCtxRelStat_PrepareCollecting(callInfo_type *ptCi, uint16_t cellNum, enumSnDifferentiator_type snType);
int FnVCCB_UpdateNrdcScgBandSelectionMgmtPerCell(callInfo_type *ptCi, uint16_t cellNum, uint16_t newFreqBand);
void FnVCCB_TerminateOngoingMrdcProcedureAtMN(callInfo_type *ptCi, int ctrlFlag);
void FnVCCB_ProcNrdcAddCacRejectforCellBackOff(callInfo_type *ptCi);
void FnVCCB_NrdcSetMnSelectPSCellNrcgi(callInfo_type *ptCi, const nbrGnbCellInfo_type *pNbr);
bool FnVCCB_IsCacBackOffTimeEffective(callInfo_type *ptCi, nbrGnbCellInfo_type *pNbrGnbCell);
void FnVCCB_StoreNrcgiforMnSelectedPSCell(callInfo_type *ptCi, const CGI_Info_type &cgiInfo);
bool FnVCCB_IsPSCellSameAsMnSelection(callInfo_type *ptCi);
void FnVCCB_UpdateReqBearerForSnTermPerPDUSess(callInfo_type *ptCi, callPDUSessInfo_type &rPduSess,  std::vector<uint8_t> &vDrbListTobeSnTermSplit);

bool FnVCCB_NeedNGuUlTnlUpdate(callInfo_type *ptCi);
void FnVCCB_CollectCslNrdcRelVonr(callInfo_type &rCall);
void FnVCCB_CollectCslNrdcAddVonr(callInfo_type &rCall);
void FnVCCB_UpdateNrdcMnCsl(callInfo_type &rCall, enumNrdcCslUpdate_type updateType);
void FnVCCB_UpdateNrdcSnCsl(callInfo_type &rCall);
uint16_t FnVCCB_GetNumofInstalledMeasCfgFreqForNrdcAdd(callInfo_type &rCall);

// class caProfileIndexSelector
// {
// private:
//     callInfo_type &call;

//     inline bool isBandMatched(const nrBand_IdleLB_type &src, const BandParameters_type &tgt)
//     {
//         return (src.freqBandIndicator == tgt.freqBandIndicator &&
//                 src.nrCaBandwidthClassDL == tgt.nrCaBandwidthClassDL &&
//                 src.nrCaBandwidthClassUL == tgt.nrCaBandwidthClassUL);
//     };
//     bool isUeBandSupportProfile(const caProfile_type &caProfile, const bandCombinationList_type *ueBandCombList);
//     inline static bool compareProfilePriority(const caProfile_type &a, const caProfile_type &b)
//     {
//         if (a.profilePriority == b.profilePriority) return a.index < b.index;
//         return a.profilePriority > b.profilePriority;
//     };
//     std::vector<caProfile_type> makeSortedCaProfiles();
//     int8_t selectCaProfileIndex(const std::vector<caProfile_type> &caProfiles, const bandCombinationList_type *ueBandCombList);

// public:
//     caProfileIndexSelector(callInfo_type &_call) :
//         call(_call)
//     {
//         call.caProfileIdx = -1;
//     };
//     int8_t run();
// };
#endif //VCCB_FEAT_FeatMrdc_H_
