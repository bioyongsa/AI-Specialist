#ifndef VCCB_FEAT_FeatRrcInactive_H_
#define VCCB_FEAT_FeatRrcInactive_H_

#include "FeatMobility.h"
#include "VccbStruct.h"

int16_t FnVCCB_CheckRRCInactive(callInfo_type *ptCi);
bool FnVCCB_IsAbleToProceedRRCInactive(callInfo_type *ptCi);
int16_t VLIB_StartRRCInactive(callInfo_type *ptCi);
int16_t FnVCCB_IsServingCellSupportRRCInactive(callInfo_type *ptCi);
int FnVCCB_GetSelectedPLMNForRRCResume(const callInfo_type &call, const MobilityType mobilityType,
    const bool isEmergencyCall, plmnId_type *ptPlmn);
long FnVCCB_GetRRCInactiveTimerValue(const callInfo_type &, const int);
void FnVCCB_CommonActionforRRCSetupOrRelease(callInfo_type &, const enumCallReleaseType, const uint32_t);
void FnVCCB_SetAndDecideFullConfig_for_RRCInactive(callInfo_type *);
void FnVCCB_SetRRCInactiveAction_after_RRCResumeRequest(callInfo_type *, const enumActivityStatus_type);
int16_t FnVCCB_BroadcastRanPaging(callInfo_type &);

#endif
