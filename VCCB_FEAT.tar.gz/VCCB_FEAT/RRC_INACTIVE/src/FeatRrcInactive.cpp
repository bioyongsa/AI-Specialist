#include "FeatRrcInactive.h"

#include <algorithm>

#include "RscCall.h"
#include "FeatCallProc.h"
#include "FeatMrdcApi.h"
#include "FeatCommon.h"
#include "FeatConditionalHo.h"
#include "FeatMrl.h"
#include "FeatTrace.h"
#include "FeatTrace.hpp"
#include "ComInclude.h"
#include "ComLibUtility.h" // for MACRO_CALL_FAULT_SAVE(=VLIB_CallFaultSave)
#include "IRNTIManager.h"
#include "StateCommon.h" // for VLIB_PutCi
#include "StateHandleAll.h"
#include "StateHandleSaMrdc.h"
#include "MsgNmbSend.h"
#include "MsgF1apSend.h"
#include "MsgXnapSend.h"

int16_t FnVCCB_CheckRRCInactive(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (ptCi->callType == E_CALLTYPE_SA || IS_NRDC_MN(ptCi))
    {
        bool proceedFlag = FnVCCB_IsAbleToProceedRRCInactive(ptCi);

        //SVR25B FGR-CC0103: Initialize the variable in order to handle E1_BearerContextInactivityNotification after SN-Release
        ptCi->ueInfo.rrcResumeInfo.actionInSNRelease = SN_REL_IN_RRC_INACTIVE_INITIAL_STATE;

        if (proceedFlag == true)
        {
            ptCi->bitFlag.needSuspendXnFlag = FALSE;

            if (VLIB_StartRRCInactive(ptCi) != GOOD)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_StartRRCInactive ERROR!\n");
                if (VCCB_CALL_RELEASE_TRIGGER(ptCi) != GOOD)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_CALL_RELEASE_TRIGGER ERROR!\n");
                }
                return ERROR;
            }
        }
        else
        {
            VCCB_PRINT_CALL_MSG(ptCi, "[RRCInactive] Staying still in RRC_CONNECT!!\n");
        }
    }

    return GOOD;
}

void FnVCCB_DisplayBearerType(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    callDRBInfo_type *pDRBInfo = NULL;

    for (int drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        pDRBInfo = &ptCi->drb[drbIdx];

        if (pDRBInfo->usage != CI_use) continue;

        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "@@BearerType: DRB(%d): %s\n",
            drbIdx, FnVCCB_GetBearerTypeValStr(pDRBInfo->bearerType.val));
    }
}

bool FnVCCB_IsAbleToProceedRRCInactive(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, false);

    bool nrDcMnFlag = IS_NRDC_MN(ptCi);
    bool mnTermFlag = FnVCCB_IsAnyMnTermPerUE(ptCi, current_bearerType);
    bool snTermFlag = FnVCCB_IsAnySnTermPerUE(ptCi, current_bearerType);
    bool sigTimerExpired = VCCB_IS_SIGNALING_TIMER_EXPIRED(ptCi);
    enumActivityStatus_type activityStatus = RscCall::getDataActivityStatus(*ptCi);

    // SVR25A: give detailed information for easy analysis
    VCCB_PRINT_CALL_INFORMATIVE(ptCi,
        "@@SuspendDecision: state(%u)/SIGExp(%u)(feat:%u/state:%u)/activitySt(%u)/NRDC-MN(%u)(MN-Term:%u/SN-Term:%u)/needSuspendXn(%u)\n",
        ptCi->state, sigTimerExpired, ptCi->CallUserInactivity.featureEnabled, ptCi->CallUserInactivity.ueInactivityState,
        activityStatus, nrDcMnFlag, mnTermFlag, snTermFlag, (unsigned int)ptCi->bitFlag.needSuspendXnFlag);

    // a. current state is STATE_Conn ?
    if (ptCi->state != STATE_Conn)
    {
        return false;
    }

    // b. MN SIG timer expired ?
    if (sigTimerExpired == false)
    {
        return false;
    }

    if (nrDcMnFlag)
    {
        FnVCCB_DisplayBearerType(ptCi);

        // c. any MN-term and any SN-term bearers are established ?
        if (mnTermFlag && snTermFlag)
        {
            // d. Rx: XN Activity Noti (inactive) and Rx: E1 Bearer Context Inact. Noti (inactive) ?
            if (activityStatus == ActivityStatus_INACTIVE && ptCi->bitFlag.needSuspendXnFlag == TRUE)
            {
                goto MN_INIT_SN_RELEASE;
            }
            else
            {
                return false;
            }
        }
        // e. only MN-term bearers are established ?
        else if (mnTermFlag)
        {
            // f. Rx: E1 Bearer Context Inact. Noti (inactive) ?
            if (activityStatus == ActivityStatus_INACTIVE)
            {
                goto MN_INIT_SN_RELEASE;
            }
            else
            {
                return false;
            }
        }
        // g. only SN-term bearers are established ?
        else if (snTermFlag)
        {
            // h. Rx: XN Activity Noti (inactive) ?
            if (ptCi->bitFlag.needSuspendXnFlag == TRUE)
            {
                goto MN_INIT_SN_RELEASE;
            }
            else
            {
                return false;
            }
        }
        // just in case: sig only in nrdc state (not sure this case is able to be happened)
        else
        {
            goto MN_INIT_SN_RELEASE;
        }
    }
    else if (ptCi->callType == E_CALLTYPE_SA)   // SA basic call
    {
        ptCi->bitFlag.needSuspendXnFlag = FALSE;    // initialize (just in case..)

        // i. Rx: E1 Bearer Context Inact. Noti (inactive) ?
        if (activityStatus == ActivityStatus_INACTIVE)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }

MN_INIT_SN_RELEASE:
    ptCi->mrdcInfo.sNodeRelCause = MrdcRelCause_RRCInactive;
    ptCi->ueInfo.rrcResumeInfo.preventSNAddFlag = TRUE;                 // SVR25B

    // start MN-init. SN release
    if (ERROR == VCCM_TriggerMgNBInitSNReleaseProcedure(ptCi))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_TriggerMgNBInitSNReleaseProcedure Error !\n");
    }

    return false;
}

int16_t VLIB_StartRRCInactive(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    VCCB_PRINT_CALL_MSG(ptCi, "[RRCInactive] Transit from RRC_CONNECTED to RRC_INACTIVE\n");

    //SVR25B FGR-CC0103: In order to indicate the original value for iat timer
    ptCi->ueInfo.rrcResumeInfo.actionInSNRelease = SN_REL_IN_RRC_INACTIVE_INITIAL_STATE;

    if (FnVCCB_IsServingCellSupportRRCInactive(ptCi) != TRUE)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "ServCell(%d) is not support RRCInactive. Release call instead of Suspend\n", ptCi->servCellNum);

        //MACRO_CALL_FAULT_SAVE(E1_BearerContextInactivityNotification_id, ???);
        if (VCCB_CALL_RELEASE_TRIGGER(ptCi) != GOOD)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_CALL_RELEASE_TRIGGER ERROR!\n");
            VLIB_PutCi(ptCi);
        }
        return GOOD;
    }

    if ((ptCi->hoRestrict.existFlag) && (VCCM_CheckEmergencyCall(ptCi) == FALSE))
    {
        hoRestrictInfo_type &hrl = THREAD_INFO->call[ptCi->myThreadId].buf.hoRestrictInfo;
        const VccbCellInfo_type &cell = CELLINFO[ptCi->servCellNum];
        VCCB_RETURN_ON_CALL_ERROR(
            ptCi, VLIB_DecompressHoRestrictInfo(ptCi, &hrl), "VLIB_DecompressHoRestrictInfo ERROR!\n");

        status = VCCM_CheckPlmnAndTacInMrlAllowedList(ptCi, &hrl, cell.tac, ptCi->ueInfo.servedPlmn.longId);
        if (status != GOOD)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "servingPLMN(%x) is restricted by MRL(%d). Release call instead of Suspend in %s\n",
                ptCi->ueInfo.servedPlmn.longId, status, __func__);
            MACRO_CALL_FAULT_SAVE(InternalUserInactivityUpdate_id, CauseCpInternalUserInactivity);
            if (VCCB_CALL_RELEASE_TRIGGER(ptCi) != GOOD)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_CALL_RELEASE_TRIGGER ERROR!\n");
                VLIB_PutCi(ptCi);
            }
            return GOOD;
        }
    }

    if (ERROR == FnVCCB_ApplyConditionalCellConfig(ptCi, e_ChoApplyByRRCSuspend))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_ApplyConditionalCellConfig ERROR! in %s\n", __func__);
    }

    SET_STATE_CMD(RRCSuspend_cmd);

    // SVR25B FGR-CC6201
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    if (pGnb->RrcInactiveInfo.edrxAllowed == EQUIP)
    {
        ptCi->ueInfo.RrcInactiveInfo.edrxAbility |= static_cast<uint8_t>(RRC_INACTIVE_CP_SUPPORT);
    }
    else
    {
        ptCi->ueInfo.RrcInactiveInfo.edrxAbility &= static_cast<uint8_t>(~RRC_INACTIVE_CP_SUPPORT);
    }

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "RRCInactive edrxAbility(%u) CP(%u) UE(%u) AMF(%u)\n",
        ptCi->ueInfo.RrcInactiveInfo.edrxAbility,
        (ptCi->ueInfo.RrcInactiveInfo.edrxAbility & RRC_INACTIVE_CP_SUPPORT) ? 1 : 0,
        (ptCi->ueInfo.RrcInactiveInfo.edrxAbility & RRC_INACTIVE_UE_SUPPORT) ? 1 : 0,
        (ptCi->ueInfo.RrcInactiveInfo.edrxAbility & RRC_INACTIVE_AMF_SUPPORT) ? 1 : 0);

    // [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
    status = VLIB_stopManagementMdtTrace(ptCi, ptCi->servCellNum);
    VCCB_PRINT_WITHOUT_RETURN_ON_CALL_ERROR(ptCi, status, "[MDT] VLIB_stopManagementMdtTrace cellNum(%i) error.\n",
        ptCi->servCellNum);
    status = VLIB_stopManagementUeThrRfTrace(ptCi, ptCi->servCellNum);
    VCCB_PRINT_WITHOUT_RETURN_ON_CALL_ERROR(ptCi, status, "[UETHR] VLIB_stopManagementUeThrRfTrace cellNum(%i) error.\n",
        ptCi->servCellNum);
    status = VLIB_stopLoggedMdtTrace(ptCi, ptCi->servCellNum);
    VCCB_PRINT_WITHOUT_RETURN_ON_CALL_ERROR(ptCi, status, "[MDT] VLIB_stopLoggedMdtTrace cellNum(%i) error.\n",
        ptCi->servCellNum);
    status = VLIB_stopRlfAndRcefdMdtTrace(ptCi, ptCi->servCellNum);
    VCCB_PRINT_WITHOUT_RETURN_ON_CALL_ERROR(ptCi, status, "[MDT] VLIB_stopRlfAndRcefdMdtTrace cellNum(%i) error.\n",
        ptCi->servCellNum);

    traceMdtStatus_type sessionToDeactivate = {
        .immediate = (mdtImmediate == ptCi->signalingTraceInfo.mdt.mdtStatus),
        .logged = (mdtLogged == ptCi->signalingTraceInfo.mdt.mdtStatus),
        .uethr = (VCCB_FLAG_ON == ptCi->signalingTraceInfo.trace.ueThroughputAndRfTraceFlag),
        .trace = false
    };
    // suppress sending F1_DeactivateTrace
    ptCi->signalingTraceInfo.traceActivationStatus.F1delivered = false;
    deactivateSigMdtTrace(ptCi, sessionToDeactivate, false, ptCi->servCellNum);

    VRRM_delCellNonDssUeCount(ptCi);
    VRRM_delLoggedMdtCapableUeCount(ptCi);

    // DU Query to get masterCellGroup before the suspension (SVR21D)
    ptCi->ueInfo.duConfQuery = VCCB_FLAG_ON;

    if (DBG->flag.isFailToRrcInactive_type01)   return ERROR;

    status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_sendF1_UeContextModificationRequest ERROR!!\n");
        return ERROR;
    }

    ptCi->ueInfo.duConfQuery = VCCB_FLAG_OFF;

    VLIB_AttachTimer(&ptCi->timer, ptCi, timF1_UeContextModification_id);
    VLIB_SetCurStateAll(ptCi, STATE_Inact_F1ModQuery);

    return GOOD;
}

bool FnVCCB_CheckTAIList_RRCInactive(ueInfo_type::VccbUeRrcInactiveInfo_s &rUeRrcInactiveInfo, VccbCellInfo_type &rCell)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_LIST_COUNT_AND_VAL(rUeRrcInactiveInfo.numInactTAI, MAX_INACTIVE_TAI_NUM, false);

    uint16_t numInactTAI = rUeRrcInactiveInfo.numInactTAI;
    uint8_t numOfPLMN = rCell.cellPlmn.numOfPLMN;
    
    for (uint16_t taiIndex = 0; taiIndex < numInactTAI; taiIndex++)
    {
        // 1. check TAC
        if (rUeRrcInactiveInfo.taiList[taiIndex].tac != rCell.tac) continue;

        for (uint8_t plmnIndex = 0; plmnIndex < numOfPLMN; plmnIndex++)
        {
            // 2. check PLMN
            if (rUeRrcInactiveInfo.taiList[taiIndex].plmn.longId == rCell.cellPlmn.servedPlmn[plmnIndex])
            {
                return true;
            }
        }
    }
    
    return false;
}

int16_t FnVCCB_IsServingCellSupportRRCInactive(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    if (IS_NRDC_SN(ptCi))
    {
        // In case of NRDC SN, this function is not required as it shall be released.
        return TRUE;
    }

    VccbCellInfo_type *ptCell = &CELLINFO[ptCi->servCellNum];
    bool checkTAIList = FnVCCB_CheckTAIList_RRCInactive(ptCi->ueInfo.RrcInactiveInfo, *ptCell);

    if (ptCell->tacStatus != EQUIP || ptCell->ranacUsage != EQUIP || checkTAIList == false)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "tacStatus(%d) or ranacUsage(%d) or taiList(%d) of serving cell is not configured\n",
            ptCell->tacStatus, ptCell->ranacUsage, checkTAIList);
        return FALSE;
    }

    return TRUE;
}

static inline bool FnVCCB_IsPLMNIncludedInList(const allowedPlmnList_Type &list, const plmnId_type &plmnId)
{
    const uint32_t listSize = std::min(list.num_plmn, (unsigned int)MAX_NUM_PLMN);
    for (uint32_t i = 0; i < listSize; ++i)
    {
        if (list.plmn[i].longId == plmnId.longId) return true;
    }
    return false;
}

// SVR23B FGR-CC0107 FR661
int FnVCCB_GetSelectedPLMNForRRCResume(const callInfo_type &call, const MobilityType mobilityType,
    const bool isEmergencyCall, plmnId_type *ptPlmn)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_RETURN(call.myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(call.servCellNum, MAX_CELL_NUM_VCCB);

    hoRestrictInfo_type *const ptMrl = &THREAD_INFO->call[call.myThreadId].buf.hoRestrictInfo;
    VCCB_RETURN_ON_CALL_ERROR(
        &call, VLIB_DecompressHoRestrictInfo(&call, ptMrl), "VLIB_DecompressHoRestrictInfo ERROR!\n");

    // 1) Get BPLMN List
    allowedPlmnList_Type allowedCellPlmnList;
    allowedCellPlmnList.num_plmn = 0;
    int status = VLIB_getBPLMN(&call, call.servCellNum, &allowedCellPlmnList);
    if (status == BREAK)
    {
        VCCB_PRINT_CALL_ERROR(&call, "BPLMNList is empty(%u) in %s\n", allowedCellPlmnList.num_plmn, __func__);
        return ERROR;
    }
    else if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(&call, "VLIB_getBPLMN ERROR in %s\n", __func__);
        return ERROR;
    }

    if (call.hoRestrict.existFlag == TRUE)
    {
        const auto &candidatePlmn = call.hoRestrict.servedPlmn;

        if (isEmergencyCall)
        {
            if (FnVCCB_IsPLMNIncludedInList(allowedCellPlmnList, candidatePlmn))
            {
                ptPlmn->longId = candidatePlmn.longId;
                return GOOD;
            }
            else
            {
                VCCB_PRINT_CALL_INFORMATIVE(&call, "servedPlmn is not exist in BPLMN List(%u)(emergencyCall) in %s\n",
                    allowedCellPlmnList.num_plmn, __func__);
                return ERROR;
            }
        }

        // 2) Apply MRL to BPLMN List
        allowedPlmnList_Type allowedPlmnList;
        allowedPlmnList.num_plmn = 0;
        for (uint32_t plmnIdx = 0; plmnIdx < std::min(allowedCellPlmnList.num_plmn, (unsigned int)MAX_NUM_PLMN);
             plmnIdx++)
        {
            const plmnId_type &plmnId = allowedCellPlmnList.plmn[plmnIdx];
            const VccbCellInfo_type *const pCell = &CELLINFO[call.servCellNum];

            if (ERROR == VCCM_CheckPlmnAndTacInMrlAllowedList(&call, ptMrl, pCell->tac, plmnId.longId)) continue;
            allowedPlmnList.plmn[allowedPlmnList.num_plmn++].longId = plmnId.longId;
        }

        if (allowedPlmnList.num_plmn == 0)
        {
            VCCB_PRINT_CALL_INFORMATIVE(
                &call, "MRL applied BPLMN List is empty(%u) in %s\n", allowedPlmnList.num_plmn, __func__);
            return ERROR;
        }

        if (FnVCCB_IsPLMNIncludedInList(allowedPlmnList, candidatePlmn))
        {
            ptPlmn->longId = candidatePlmn.longId;
            return GOOD;
        }
        else
        {
            VCCB_PRINT_CALL_INFORMATIVE(&call,
                "call.hoRestrict.servedPlmn is not exist in MRL applied BPLMN List(%u) in %s\n",
                allowedPlmnList.num_plmn, __func__);
            return ERROR;
        }
    }
    else
    {
        const auto &candidatePlmn =
            (mobilityType == MobilityType::RRC_RESUME_INTRA_GNB) ? call.ueInfo.servedPlmn : call.servedGuami.plmn;

        if (FnVCCB_IsPLMNIncludedInList(allowedCellPlmnList, candidatePlmn))
        {
            ptPlmn->longId = candidatePlmn.longId;
            return GOOD;
        }
        else
        {
            VCCB_PRINT_CALL_INFORMATIVE(&call, "candidatePlmn(%u) is not exist in BPLMN List(%u) in %s\n",
                candidatePlmn.longId, allowedCellPlmnList.num_plmn, __func__);
            return ERROR;
        }
    }
}

long FnVCCB_GetRRCInactiveTimerValue(const callInfo_type &call, const int qos5qi)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_RANGE_AND_RETURN_ERROR(call.gnbNum, MAX_GNB_PER_SYS,
        "FnVCCB_GetRRCInactiveTimerValue error!!(call.gnbNum is INVALID!!");

    VccbGnbInfo_type *const pGnb = &GNBINFO[call.gnbNum];
    const auto *ptCi = &call;
    long retval;

    if (qos5qi < MAX_5QI_VALUE)  // notification-level: DRB-level
    {
        if (RRCSuspend_cmd == call.stateCmd) // once VLIB_StartRRCInactive is called (suspension has begun)
        {
            // SVR25A FGR-CC0103
            if (IS_REDCAP_UE(ptCi))
            {
                // 1. RRC idle timer per DRB
                if (pGnb->RrcInactiveInfo.redCapDrbIdleTimerEntries[qos5qi] == 0)
                {
                    retval = static_cast<E1_Inactivity_Timer>(pGnb->RrcInactiveInfo.redCapRrcIdleTimer);
                }
                else
                {
                    retval = static_cast<E1_Inactivity_Timer>(pGnb->RrcInactiveInfo.redCapDrbIdleTimerEntries[qos5qi]);
                }
            }
            else
            {
                // 1. RRC idle timer per DRB
                if (pGnb->RrcInactiveInfo.drbIdleTimerEntries[qos5qi] == 0)
                {
                    retval = static_cast<E1_Inactivity_Timer>(pGnb->RrcInactiveInfo.rrcIdleTimer);
                }
                else
                {
                    retval = static_cast<E1_Inactivity_Timer>(pGnb->RrcInactiveInfo.drbIdleTimerEntries[qos5qi]);
                }
            }
        }
        else
        {
            // SVR25B FGR-CC0103
            if (ptCi->ueInfo.rrcResumeInfo.actionInSNRelease == SN_REL_IN_RRC_INACTIVE_DECIDED && (not IS_NRDC_SN(ptCi)))
            {
                retval = static_cast<E1_Inactivity_Timer>(1);
            }
            else
            {
                // SVR22C2 FGR-CC0108
                if (IS_SUPPORT_TO_REL_PREF_RRC_INACTIVE(ptCi))
                {
                    // SVR25A FGR-CC0108
                    if (IS_REDCAP_UE(ptCi))
                    {
                        // 2. RRC inactive timer per DRB
                        if (pGnb->RrcInactiveInfo.redCapDrbInactiveTimerEntries[qos5qi] == 0)
                        {
                            retval = static_cast<E1_Inactivity_Timer>((pGnb->RrcInactiveInfo.redCapRrcInactiveTimer * 0.3) + 0.99);
                        }
                        else
                        {
                            retval = static_cast<E1_Inactivity_Timer>((pGnb->RrcInactiveInfo.redCapDrbInactiveTimerEntries[qos5qi] * 0.3) + 0.99);
                        }
                    }
                    else
                    {
                        // 2. RRC inactive timer per DRB
                        if (pGnb->RrcInactiveInfo.drbInactiveTimerEntries[qos5qi] == 0)
                        {
                            retval = static_cast<E1_Inactivity_Timer>((pGnb->RrcInactiveInfo.rrcInactiveTimer * 0.3) + 0.99);
                        }
                        else
                        {
                            retval = static_cast<E1_Inactivity_Timer>((pGnb->RrcInactiveInfo.drbInactiveTimerEntries[qos5qi] * 0.3) + 0.99);
                        }
                    }
                }
                else
                {
                    // SVR25A FGR-CC0108
                    if (IS_REDCAP_UE(ptCi))
                    {
                        // 2. RRC inactive timer per DRB
                        if (pGnb->RrcInactiveInfo.redCapDrbInactiveTimerEntries[qos5qi] == 0)
                        {
                            retval = static_cast<E1_Inactivity_Timer>(pGnb->RrcInactiveInfo.redCapRrcInactiveTimer);
                        }
                        else
                        {
                            retval = static_cast<E1_Inactivity_Timer>(pGnb->RrcInactiveInfo.redCapDrbInactiveTimerEntries[qos5qi]);
                        }
                    }
                    else
                    {
                        // 2. RRC inactive timer per DRB
                        if (pGnb->RrcInactiveInfo.drbInactiveTimerEntries[qos5qi] == 0)
                        {
                            retval = static_cast<E1_Inactivity_Timer>(pGnb->RrcInactiveInfo.rrcInactiveTimer);
                        }
                        else
                        {
                            retval = static_cast<E1_Inactivity_Timer>(pGnb->RrcInactiveInfo.drbInactiveTimerEntries[qos5qi]);
                        }
                    }
                }
            }
        }
    }
    else    // notification-level: UE-level
    {
        if (RRCSuspend_cmd == call.stateCmd) // once VLIB_StartRRCInactive is called (suspension has begun)
        {
            // SVR25A FGR-CC0103
            if (IS_REDCAP_UE(ptCi))
            {
                retval = static_cast<E1_Inactivity_Timer>(pGnb->RrcInactiveInfo.redCapRrcIdleTimer);
            }
            else
            {
                retval = static_cast<E1_Inactivity_Timer>(pGnb->RrcInactiveInfo.rrcIdleTimer);
            }
        }
        else
        {
            // SVR25B FGR-CC0103
            if (ptCi->ueInfo.rrcResumeInfo.actionInSNRelease == SN_REL_IN_RRC_INACTIVE_DECIDED && (not IS_NRDC_SN(ptCi)))
            {
                retval = static_cast<E1_Inactivity_Timer>(1);
            }
            else
            {
                // SVR22C2 FGR-CC0108
                if (IS_SUPPORT_TO_REL_PREF_RRC_INACTIVE(ptCi))
                {
                    // SVR25A FGR-CC0108
                    if (IS_REDCAP_UE(ptCi))
                    {
                        // 2. RRC inactive timer per DRB
                        retval = static_cast<E1_Inactivity_Timer>((pGnb->RrcInactiveInfo.redCapRrcInactiveTimer * 0.3) + 0.99);
                    }
                    else
                    {
                        retval = static_cast<E1_Inactivity_Timer>((pGnb->RrcInactiveInfo.rrcInactiveTimer * 0.3) + 0.99);
                    }
                }
                else
                {
                    // SVR25A FGR-CC0108
                    if (IS_REDCAP_UE(ptCi))
                    {
                        retval = static_cast<E1_Inactivity_Timer>(pGnb->RrcInactiveInfo.redCapRrcInactiveTimer);
                    }
                    else
                    {
                        // 2. RRC inactive timer per DRB
                        retval = static_cast<E1_Inactivity_Timer>(pGnb->RrcInactiveInfo.rrcInactiveTimer);
                    }
                }
            }
        }
    }
    return retval;
}

void FnVCCB_CommonActionforRRCSetupOrRelease(
    callInfo_type &call, const enumCallReleaseType releaseType, const uint32_t contextId
)
{
    AUTO_TRACE_FUNC;
    auto *ptCi = &call;
    int16_t status = GOOD;

    VCCB_PRINT_CALL_INFORMATIVE(&call,
        "[RRCInactive] srcContextId:%u/dstContextId:%u, relType(%u)!!\n", call.gnbCuUeId, contextId, releaseType);

    if (releaseType == eRrcSetup)
    {
        OFF_F1_RSC_PREPARATION_FLAG(call.flag.setupFlag);   // prevent from F1 release

        // srcContextId : dummy callId
        // dstContextId : VNMB temp callId to remove
        status = VIIL_sendCallReleaseIndVccbVnmb(&call, releaseType, UNKNOWN_CP_CALLID, contextId);
    }
    else if (releaseType == eRelease)
    {
        // srcContextId : found old CuCpUeId
        // dstContextId : VNMB temp callId to remove
        status = VIIL_sendCallReleaseIndVccbVnmb(&call, releaseType, call.gnbCuUeId, contextId);
    }

    if (status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(&call, "VIIL_sendCallReleaseIndVccbVnmb Error\n");
    }

    // Old call release
    SET_STATE_CMD(Idle_cmd);

    call.ueInfo.rrcResumeInfo.rrcFallBackFlag = VCCB_FLAG_ON;

    if (VCCB_CALL_RELEASE_TRIGGER(&call) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(&call, "VCCB_CALL_RELEASE_TRIGGER ERROR!\n");
        VLIB_PutCi(&call);
    }
}

// SVR25A FGR-MC1020 NR Full Configuration Support
void FnVCCB_SetAndDecideFullConfig_for_RRCInactive(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->stateCmd == RRCResume_cmd &&
        ptCi->ueInfo.rrcResumeInfo.resumeType == RESUME_TYPE_INTRA_GNB &&
        ptCi->ueInfo.RrcInactiveInfo.resumeCause != NRRRC_rna_Update)
    {
        ptCi->ueInfo.rrcResumeInfo.fullConfigRequiredFlag = TRUE;   // intra-gnb, cu-init full config
    }
    else if (ptCi->state == STATE_Inact_T_XnUeContextReq &&
        ptCi->ueInfo.rrcResumeInfo.resumeType == RESUME_TYPE_INTER_GNB_TARGET &&
        ptCi->ueInfo.RrcInactiveInfo.resumeCause != NRRRC_rna_Update)
    {
        ptCi->ueInfo.rrcResumeInfo.fullConfigRequiredFlag = TRUE;   // inter-gnb, cu-init full config

        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[RRC_Inactive] Full Configuration Procedure will start by unknown IE!\n");
    }
}

// SVR25B FGR-CC0103: Set the next procedure in RRC_INACTIVE on the reception of RRCResumeRequest1
void FnVCCB_SetRRCInactiveAction_after_RRCResumeRequest(
    callInfo_type *ptCi, const enumActivityStatus_type dataActivityStatus
)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    VCCB_PRINT_CALL_INFORMATIVE(ptCi,
        "[RRCInactive] dataActivityStatus(%u), ResumeCause(%u), dlDataFlag(%u), goingToRRCIdle(%u), exceptionalFlag(%u)\n",
        dataActivityStatus, ptCi->ueInfo.RrcInactiveInfo.resumeCause,
        ptCi->ranPagingInfo.dlDataFlag, ptCi->ueInfo.rrcResumeInfo.goingToRRCIdleFlag, ptCi->ranPagingInfo.exceptionalFlag);

    if (ptCi->ranPagingInfo.exceptionalFlag == TRUE)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[RRCInactive] State Transition: RRC_INACTIVE -> RRC_IDLE!\n");
        SET_STATE_CMD(RRCIdle_cmd);
    }
    else
    {
        if (dataActivityStatus == ActivityStatus_INACTIVE || ptCi->ueInfo.rrcResumeInfo.goingToRRCIdleFlag)
        {
            if (ptCi->ranPagingInfo.dlDataFlag == VCCB_FLAG_OFF)
            {
                VCCB_PRINT_CALL_MSG(ptCi, "[RRCInactive] State Transition: RRC_INACTIVE -> RRC_IDLE!\n");
                SET_STATE_CMD(RRCIdle_cmd);
            }
            else
            {
                VCCB_PRINT_CALL_MSG(ptCi, "[RRCInactive] State Transition: RRC_INACTIVE -> RRC_CONNECTED!\n");
                SET_STATE_CMD(RRCResume_cmd);
            }
        }
        else
        {
            if (ptCi->ueInfo.RrcInactiveInfo.resumeCause == NRRRC_rna_Update &&
                ptCi->ranPagingInfo.dlDataFlag == VCCB_FLAG_OFF)
            {
                VCCB_PRINT_CALL_MSG(ptCi, "[RRCInactive] No State Transition: Staying at current state!\n");
                SET_STATE_CMD(RRCSuspend_cmd);
            }
            else
            {
                VCCB_PRINT_CALL_MSG(ptCi, "[RRCInactive] State Transition: RRC_INACTIVE -> RRC_CONNECTED!\n");
                SET_STATE_CMD(RRCResume_cmd);
            }
        }
    }
}

// SVR25B FGR-CC0103: In order to transit into RRC idle state, broadcasts RAN-Paging in RRC inactive state
int16_t FnVCCB_BroadcastRanPaging(callInfo_type &call)
{
    AUTO_TRACE_FUNC;

    auto *ptCi = &call;
    int16_t status = GOOD;

    VCCB_CLEAR_TIMER(&ptCi->ueInfo.RrcInactiveInfo.guardTimer, CANCEL_TIMER);
    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    VCCB_RETURN_ON_CALL_ERROR(ptCi, FnVCCB_SendCallPagingReq(ptCi, procDedicated), "FnVCCB_SendCallPagingReq ERROR!\n");

    // timer to wait RRC Resume Request1 over UL-CCCH1
    VLIB_AttachTimer(&ptCi->timer, ptCi, timNRRRC_RRCResumeRequest1_id);
    VLIB_SetCurStateAll(ptCi, STATE_Inact_ResumeReq);

    return status;
}
