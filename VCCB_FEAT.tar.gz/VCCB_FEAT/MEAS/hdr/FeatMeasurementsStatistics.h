/****************************************************************
 * * System      : 5G
 * * Subsystem   : CALL
 * * Module      : VCCB
 * * File        : FeatMeasurementsStatistics.h
 * * Description :
 * * Author      :
 * * Dept.       :
 * * Created     : 2022.01.18
 * * Version     :
 * ****************************************************************/

#ifndef VCCB_VCCB_FEAT_FeatMeasurementsStatistics_H_
#define VCCB_VCCB_FEAT_FeatMeasurementsStatistics_H_

#include "VccbStruct.h"
#include "NRRRC.h"

void VCCB_CollectMeasReportStatistics(
    callInfo_type *ptCi, NRRRC_MeasResults *pMeasResult, reportConfigurationInstalledUe_type *pSelectRptCfg, measurementObjectUe_type *pSelectMeasObj);

uint8_t FnVCCB_GetTargetFreqTypeForCgiReportStat(callInfo_type *ptCi);
#endif
