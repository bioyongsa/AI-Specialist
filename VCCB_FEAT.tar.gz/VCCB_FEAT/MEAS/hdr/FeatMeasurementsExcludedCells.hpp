/****************************************************************
 * * System      : 5G
 * * Subsystem   : CALL
 * * Module      : VCCB
 * * File        : FeatMeasurementsExcludedCells.hpp
 * * Description :
 * * Author      :
 * * Dept.       :
 * * Created     : 2023.05.10
 * * Version     :
 * ****************************************************************/

#ifndef VCCB_VCCB_FEAT_FeatMeasurementsExcludedCells_H_
#define VCCB_VCCB_FEAT_FeatMeasurementsExcludedCells_H_

#include "VccbStruct.h"
#include "NRRRC.h"

void VCCB_UpdateBlackCells(callInfo_type &rCi, CellNum_type cellNum, measurementObjectNRUe_type &rUeMo);

void VCCB_UpdateEutraBlackCells(CellNum_type cellNum, measurementObjectEUTRAUe_type &rUeMo);

#endif