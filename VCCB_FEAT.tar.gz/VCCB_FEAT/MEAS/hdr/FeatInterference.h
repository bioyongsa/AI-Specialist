/**
 * @file        FeatInterference.h
 * @brief       Utility functions for interference verification (FGR-CC5501)
 */

#ifndef VCCB_FEAT_FeatInterference_H_
#define VCCB_FEAT_FeatInterference_H_

#include "VccbStruct.h"

int16_t VCCM_checkCellFrequencyOverlapWithLtePCell(const callInfo_type* ptCi, const nbrGnbCellInfo_type* pNbrGnbCellInfo);
int16_t VCCM_checkImdInterferenceWithLtePCellAndNrCandidateCell(
    const callInfo_type* ptCi, const nbrGnbCellInfo_type* pNbrGnbCellInfo, const nbrGnbCellInfo_type* pNbrGnbCandidateCellInfo);

#endif
