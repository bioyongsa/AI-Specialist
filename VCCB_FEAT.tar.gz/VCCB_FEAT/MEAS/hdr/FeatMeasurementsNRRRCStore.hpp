#pragma once
#include "VccbStruct.h"
#include "NRRRC.h"

void VCCB_StoreMeasConfigSN_fromSN(callInfo_type *ptCi, NRRRC_MeasConfigSN *pIE);
int16_t VCCB_StoreMeasConfig(callInfo_type *ptCi, NRRRC_MeasConfig *pIE);
int16_t VCCB_StoreMeasGapConfigDu(callInfo_type *ptCi, NRRRC_MeasGapConfig *pSrc);
int16_t VCCB_StoreMeasConfigMN(measConfigMN_type *pDst, NRRRC_MeasConfigMN *pSrc);
int16_t VCCB_Store_SSB_MTC1(smtc1_type *pDst, const NRRRC_SSB_MTC *pSrc);