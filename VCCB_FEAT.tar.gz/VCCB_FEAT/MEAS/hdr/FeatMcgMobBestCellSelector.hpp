#ifndef FEATMCGMOBBESTCELLSELECTOR_HPP
#define FEATMCGMOBBESTCELLSELECTOR_HPP

#include "VccbStruct.h"
#include "ComGlobalData.h"

// Make method virtual during UT.
#ifdef VCCB_IPC_TEST
#define UT_VIRTUAL virtual
#else
#define UT_VIRTUAL
#endif // VCCB_IPC_TEST

/**
 * @brief Data structure used to store information about candidate cells in
 *        VCCM_SelectTgtCellMcgMob function.
 *
 */
struct VCCB_CandidateCellInfo
{
    VCCB_CandidateCellInfo(bool _isNrcgi = false,
        const cellSelection_type &_cellSelection = {static_cast<uint16_t>(MAX_CELL_NUM_VCCB),
            static_cast<uint16_t>(BAND_NOT_FOUND)},
        bool _isBelowThld = false) :
        measValue(0),
        cellSelection(_cellSelection),
        isNrcgi(_isNrcgi),
        isBelowThld(_isBelowThld)
    {
    }

    uint16_t measValue;
    cellSelection_type cellSelection;
    bool isNrcgi;
    bool isBelowThld;
};

/**
 * @brief Class responsible for selection of the best target cell in MCG Mobility scenario.
 *
 */
class VCCB_McgMobBestCellSelector
{
private:
    callInfo_type *_ptCi;
    VCCB_CandidateCellInfo _bestCell;
    bool _isPscellBelowSelThld;
    measQuantityResults_type _measResultPscell;
    bool _hasMeasResultPscell;
    bool _pscellIntraBandCheckOk;

protected:
    /**
     * @brief Function returns true if new measurement (cell) is better than current best.
     *        It takes into account presence of NR-CGI in measurement (for EN-DC calls).
     *
     * @param newCell new candidate cell parameters
     * @return true
     * @return false
     */
    bool _IsNewMeasBetterThanCurrentBest(const VCCB_CandidateCellInfo &rNewCell) const;
    /**
     * @brief Selects value of one of RSRP, RSRQ or SINR (in this order)
     *        and puts it into measValue.
     *        Returns false if no value (RSRP, RSRQ nor SINR) is set in measurement object.
     *
     * @param measResult object with measurements for a cell
     * @param measValue output of selected measurement value
     * @return true
     * @return false
     */
    bool _TrySelectMeasResultValue(const measQuantityResults_type &rMeasResult, uint16_t &rMeasValue) const;
    /**
     * @brief Checks if measurements for given frequency are above ConfD configured threshold.
     *        If there is no threshold configured for given frequency then don't check and return true.
     *        It first tries to compare RSRP (if included in measurement).
     *        If RSRP is not included then RSRQ is tried.
     *        If RSRQ is not included then SIRN is tried.
     *
     * @param measResult object with measurements for a cell
     * @param frequency measured cell frequency
     * @return true
     * @return false
     */
    bool _IsMeasAboveThld(
        const measQuantityResults_type &rMeasResult, uint32_t frequency, VCCB_CandidateCellInfo &rNewCell) const;
    /**
     * @brief Checks if given measurement result should be further considered as HO target cell candidate.
     *        It checks given meas object against current max measurement.
     *        It also verifies if given meas result is above ConfD configured threshold.
     *        Returns true if cell could be new HO target cell (further verification required).
     *        If returns true then newCell.measValue is set to selected meas (RSRP, RSRQ or SINR).
     *        newCell.isPscell - when set TRUE then PSCell check is performed (only compared with current max).
     *                         - when set FALSE then all checks are performed.
     *
     * @param measResult object with measurements for a cell
     * @param frequency measured cell frequency
     * @param newCell new candidate cell parameters (in/out)
     * @return true
     * @return false
     */
    bool _IsNewCellBetterBasedOnMeas(
        const measQuantityResults_type &rMeasResult, uint32_t frequency, VCCB_CandidateCellInfo &rNewCell) const;
    /**
     * @brief This function returns true if given measurement result object
     *        has at least one valid PLMN_IdentityInfo.
     *        Otherwise returns false.
     *
     * @param measResNR measurement result object
     * @return true
     * @return false
     */
    bool _HasMeasResultNrcgi(const measResultNR_type &rMeasResNR) const;
    /**
     * @brief Checks if given cell measurement result satisfies the configured thresholds for serving PSCell.
     *        Returns the status of performed check operation.
     *        Returns GOOD, when:
     *            - none of the serving PSCell thresholds are configured and feature is OFF
     *            - feature is on and considered cell satisfies the threshold
     *        Returns BREAK, when:
     *            - considered cell does not satisfy the throsholds
     *        Returns ERROR, when:
     *            - ptr and range validation error occurs
     *
     * @param measResult measurement result of the cell to be checked against configured thresholds
     * @return int GOOD, BREAK, ERROR
     */
    int _CheckCellAgainstThresholds(const measQuantityResults_type &measResult) const;
    /**
     * @brief Checks if given cell measurement result of neighbour cell is offset-better than PSCell
     *        condition based on triggering quantity.
     *        Check condition operation is performed as follows:
     *            - if triggering quantity value is RSRP, then NBR cell is offset-better when:
     *              NBR-RSRP > (PSCell-RSRP + a3-offset-rsrp) (RSRQ is not checked);
     *            - if triggering quantity value is RSRQ, then NBR cell is offset-better when:
     *              NBR-RSRQ > (PSCell-RSRQ + a3-offset-rsrq) (RSRP is not checked);
     *        Returns the status of performed check operation.
     *        Returns GOOD, when:
     *            - none of the serving PSCell thresholds are configured and feature is OFF
     *            - when feaure is on and nbr cell is offset-better than current PSCell
     *        Returns BREAK, when:
     *            - PSCell measurement result is included in NR MR and the check condition cannot be performed
     *            - when feaure is on and nbr cell is not offset-better than current PSCell
     *            - when feaure is on and cannot compare PSCell and NBR cell due to UE reported quantity and triggering
     * quantity mismatch Returns ERROR, when:
     *            - ptr and range validation error occurs
     *            - no report config for event-A3 with en-dc-nr-pscell-change-purpose configured in DB
     *
     * @param measResultNbr measurement result of the neighbour cell
     * @return int GOOD, BREAK, ERROR
     */
    int _CheckIfNbrCellIsOffsetBetterThanPsCell(const measQuantityResults_type &measResultNbr) const;
    /**
     * @brief Returns true if PSCell intra-band relationship with LTE Pcell is ok.
     * 
     * @return true 
     * @return false 
     */
    bool _VerifyPscellIntraBandRelationWithLtePcell();
    /**
     * @brief Wrapper for VCCB_CanMOAndRCBeAddedWithCandidates fucntion so it can be mocked in UTs.
     * 
     * @param reportConfig 
     * @return true 
     * @return false 
     */
    UT_VIRTUAL
    bool _IsIntraFreqA3PscellChangeRcConfigured(reportConfigurationConfUe_type& reportConfig) const;

public:
    VCCB_McgMobBestCellSelector(callInfo_type *ptCi) :
        _ptCi(ptCi),
        _isPscellBelowSelThld(false),
        _measResultPscell(),
        _hasMeasResultPscell(false),
        _pscellIntraBandCheckOk(true)
    {
    }
    /**
     * @brief This function tries to update current best cell with new one, that is serving cell,
     *        if the new one meets all conditions for MCG Mobility.
     *
     * @param measRes2NR base of measResultNR_type - contains info about frequency
     * @param measResNR measured cell parameters
     */
    void UpdateWithServCell(const measResult2NR_type &rMeasRes2NR, const measResultNR_type &rMeasResNR);
    /**
     * @brief This function tries to update current best cell with new one, i.e. neighbour or SCell,
     *        if the new one meets all conditions for MCG Mobility.
     *
     * @param measRes2NR base of measResultNR_type - contains info about frequency
     * @param measResNR measured cell parameters
     */
    void UpdateWithNeighbourPci(const measResult2NR_type &rMeasRes2NR, const measResultNR_type &rMeasResNR);
    /**
     * @brief Returns true if target cell was successfully selected.
     *
     * @return true
     * @return false
     */
    inline bool IsSelected() const { return (MAX_CELL_NUM_VCCB > _bestCell.cellSelection.cellNum); }
    /**
     * @brief Returns parameters of selected cell.
     *
     * @return const VCCB_CandidateCellInfo&
     */
    inline const VCCB_CandidateCellInfo &GetSelected() const { return _bestCell; }
    /**
     * @brief Returns true if PSCell measurement is below configured endc-pscell-selection-threshold-entries.
     *
     * @return true
     * @return false
     */
    inline bool IsPscellBelowSelThld() const { return _isPscellBelowSelThld; }
    /**
     * @brief Returns true if there was a measurement result for current PSCell in MR.
     * 
     * @return true 
     * @return false 
     */
    inline bool IsPscellMeasResultPresent() const { return _hasMeasResultPscell; }
    /**
     * @brief Returns true if PSCell intra-band relation with LTE PCell was successful.
     * 
     * @return true 
     * @return false 
     */
    inline bool IsPscellIntraBandCheckOk() const { return _pscellIntraBandCheckOk; }
};

#endif  // FEATMCGMOBBESTCELLSELECTOR_HPP
