#pragma once

#include "ComMacro.h"
#include "ComInline.h"
#include "VccbStruct.h"
#include "FeatLtmHo.h"
#include <optional>

std::optional<uint8_t> VCCB_FindCdToNcdMappingIdx(const NcdSsbConfig_type &ncdSsbConfig, uint32_t frequency);

/****************************************************************************
 * @brief           Check if RedCap UE call for SA mode
 *
 * @param[in]       ci : reference to call info / const callInfo_type&
 * @return          status : true/false / bool
 ****************************************************************************/
inline bool VCCB_IsRedCapUeForSA(const callInfo_type &ci)
{
    return E_CALLTYPE_SA == ci.callType && IS_REDCAP_UE((&ci));
}

bool FnVCCB_IsSsbAllowed(const callInfo_type &rCall, const uint32_t ssbFrequency);

enumMeasRatType VCCB_GetRatType(enumMeasurementReportType reportType);

inline uint32_t VCCB_GetMeasObjectSsbFreq(const measurementObjectUe_type &mo)
{
    return mo.conf.rat.nr.minimal.ssbFrequency;
}
inline uint32_t VCCB_GetMeasObjectCarrierFreq(const measurementObjectUe_type &mo)
{
    return mo.conf.rat.eutra.minimal.carrierFreq;
}

bool VCCB_isAssociatedWithCondTriggerConfig(const reportConfigurationConfUe_type &toCheck);
bool VCCB_CheckCondSsbOrAssociatedSsb(const referenceSignalConfigUe_type &rNew);

inline bool FnVCCB_IsInterDuHoNonNrdcSn(const callInfo_type &rCall)
{
    return ((IntraRatHO_cmd == rCall.stateCmd) && (HO_TYPE_INTRA_NB == rCall.hoInfo.hoType.nb) &&
            (HO_TYPE_INTER_DU == rCall.hoInfo.hoType.du) && (false == IS_NRDC_SN(&rCall)) &&
            (e_HoTrigger_LtmHandoverPrep != rCall.hoInfo.cause) && (e_HoTrigger_LtmHandoverExec != rCall.hoInfo.cause));
}

inline bool FnVCCB_IsLtmCandPrepForMeas(const callInfo_type &rCall)
{
    return (((STATE_Ltm_Prep_TgtDuAdd == rCall.state) ||
        (STATE_Ltm_Prep_Cand == rCall.state) ||
        (STATE_Ltm_Prep_Propagation == rCall.state))
        && (false == FnVCCB_IsLtmReleaseCase(rCall))
        && (MAX_NUM_LTM_CELLS > rCall.ltmUeInfo.currCandidateCellIdx)
    );
}

inline mGapDuData_type & FnVCCB_GetMGapDuData(callInfo_type &rCall)
{
    if (FnVCCB_IsLtmCandPrepForMeas(rCall))
    {
        if ((MAX_NUM_LTM_CELLS <= rCall.ltmUeInfo.currCandidateCellIdx) || (nullptr == rCall.ltmUeInfo.ptProcRelatedData))
        {
            static mGapDuData_type dummyMGapDuData = {};
            return dummyMGapDuData;
        }
        return rCall.ltmUeInfo.ptProcRelatedData->mGapDuData[rCall.ltmUeInfo.currCandidateCellIdx];
    }

    if (FnVCCB_IsInterDuHoNonNrdcSn(rCall))
    {
        return rCall.hoInfo.mGapDuTarget;
    }

    return rCall.measurementsConfigShared.mGapDu;
}
inline const mGapDuData_type & FnVCCB_GetMGapDuData(const callInfo_type &rCall)
{
    if (FnVCCB_IsLtmCandPrepForMeas(rCall))
    {
        if ((MAX_NUM_LTM_CELLS <= rCall.ltmUeInfo.currCandidateCellIdx) || (nullptr == rCall.ltmUeInfo.ptProcRelatedData))
        {
            static const mGapDuData_type dummyMGapDuData = {};
            return dummyMGapDuData;
        }
        return rCall.ltmUeInfo.ptProcRelatedData->mGapDuData[rCall.ltmUeInfo.currCandidateCellIdx];
    }

    if (FnVCCB_IsInterDuHoNonNrdcSn(rCall))
    {
        return rCall.hoInfo.mGapDuTarget;
    }

    return rCall.measurementsConfigShared.mGapDu;
}

inline const moListMgap_type &FnVCCB_GetMGapMoDuInstalled(const callInfo_type &rCall)
{
    if (FnVCCB_IsLtmCandPrepForMeas(rCall))
    {
        static const moListMgap_type emptyMoDuInstalled = {};
        return emptyMoDuInstalled;
    }

    return rCall.measurementsConfigShared.mGapConfiguration.moDuInstalled;
}

inline measurementsConfiguration_type &FnVCCB_GetMeasurementsConfiguration(callInfo_type &rCi)
{
    if (FnVCCB_IsLtmCandPrepForMeas(rCi))
    {
        if ((MAX_NUM_LTM_CELLS <= rCi.ltmUeInfo.currCandidateCellIdx) || (nullptr == rCi.ltmUeInfo.ptProcRelatedData))
        {
            static measurementsConfiguration_type dummyMeasConfiguration = {};
            return dummyMeasConfiguration;
        }
        return rCi.ltmUeInfo.ptProcRelatedData->measConf[rCi.ltmUeInfo.currCandidateCellIdx];
    }

    return rCi.measurementsConfiguration;
}
inline const measurementsConfiguration_type &FnVCCB_GetMeasurementsConfiguration(const callInfo_type &rCi)
{
    if (FnVCCB_IsLtmCandPrepForMeas(rCi))
    {
        if ((MAX_NUM_LTM_CELLS <= rCi.ltmUeInfo.currCandidateCellIdx) || (nullptr == rCi.ltmUeInfo.ptProcRelatedData))
        {
            static const measurementsConfiguration_type dummyMeasConfiguration = {};
            return dummyMeasConfiguration;
        }
        return rCi.ltmUeInfo.ptProcRelatedData->measConf[rCi.ltmUeInfo.currCandidateCellIdx];
    }

    return rCi.measurementsConfiguration;
}

inline measurementsProcedure_type &FnVCCB_GetMeasurementsProcedure(callInfo_type &rCi)
{
    if (FnVCCB_IsLtmCandPrepForMeas(rCi))
    {
        if ((MAX_NUM_LTM_CELLS <= rCi.ltmUeInfo.currCandidateCellIdx) || (nullptr == rCi.ltmUeInfo.ptProcRelatedData))
        {
            static measurementsProcedure_type dummyMeasProcedure = {};
            return dummyMeasProcedure;
        }
        return rCi.ltmUeInfo.ptProcRelatedData->measProc[rCi.ltmUeInfo.currCandidateCellIdx];
    }

    return rCi.measurementsProcedure;
}
inline const measurementsProcedure_type &FnVCCB_GetMeasurementsProcedure(const callInfo_type &rCi)
{
    if (FnVCCB_IsLtmCandPrepForMeas(rCi))
    {
        if ((MAX_NUM_LTM_CELLS <= rCi.ltmUeInfo.currCandidateCellIdx) || (nullptr == rCi.ltmUeInfo.ptProcRelatedData))
        {
            static const measurementsProcedure_type dummyMeasProcedure = {};
            return dummyMeasProcedure;
        }
        return rCi.ltmUeInfo.ptProcRelatedData->measProc[rCi.ltmUeInfo.currCandidateCellIdx];
    }

    return rCi.measurementsProcedure;
}

inline reportCgiInfo_type &FnVCCB_GetReportCgi(callInfo_type &rCi)
{
    if (FnVCCB_IsLtmCandPrepForMeas(rCi))
    {
        if ((MAX_NUM_LTM_CELLS <= rCi.ltmUeInfo.currCandidateCellIdx) || (nullptr == rCi.ltmUeInfo.ptProcRelatedData))
        {
            static reportCgiInfo_type dummyReportCgi = {};
            return dummyReportCgi;
        }
        return rCi.ltmUeInfo.ptProcRelatedData->reportCgi[rCi.ltmUeInfo.currCandidateCellIdx];
    }

    return rCi.anrInfo.reportCgi;
}

inline saMeasStateInfo_type &FnVCCB_GetSaMeas(callInfo_type &rCi)
{
    const measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(rCi);
    if (rMeasConf.svcGrpChangeProcedure == FALSE)
    {
        return rCi.saMeas;
    }

    if (FnVCCB_IsLtmCandPrepForMeas(rCi))
    {
        if ((MAX_NUM_LTM_CELLS <= rCi.ltmUeInfo.currCandidateCellIdx) || (nullptr == rCi.ltmUeInfo.ptProcRelatedData))
        {
            static saMeasStateInfo_type dummySaMeasStateInfo = {};
            return dummySaMeasStateInfo;
        }
        return rCi.ltmUeInfo.ptProcRelatedData->saMeas[rCi.ltmUeInfo.currCandidateCellIdx];
    }

    return rCi.saMeas;
}

inline const saMeasStateInfo_type &FnVCCB_GetSaMeas(const callInfo_type &rCi)
{
    const measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(rCi);
    if (rMeasConf.svcGrpChangeProcedure == FALSE)
    {
        return rCi.saMeas;
    }

    if (FnVCCB_IsLtmCandPrepForMeas(rCi))
    {
        if ((MAX_NUM_LTM_CELLS <= rCi.ltmUeInfo.currCandidateCellIdx) || (nullptr == rCi.ltmUeInfo.ptProcRelatedData))
        {
            static const saMeasStateInfo_type dummySaMeasStateInfo = {};
            return dummySaMeasStateInfo;
        }
        return rCi.ltmUeInfo.ptProcRelatedData->saMeas[rCi.ltmUeInfo.currCandidateCellIdx];
    }

    return rCi.saMeas;
}

inline UlGapFr2Config_type &FnVCCB_GetUlGapFr2ConfigDu(callInfo_type &rCall)
{
    if (FnVCCB_IsLtmCandPrepForMeas(rCall))
    {
        if ((MAX_NUM_LTM_CELLS <= rCall.ltmUeInfo.currCandidateCellIdx) || (nullptr == rCall.ltmUeInfo.ptProcRelatedData))
        {
            static UlGapFr2Config_type dummyUlGapFr2Config = {};
            return dummyUlGapFr2Config;
        }
        return rCall.ltmUeInfo.ptProcRelatedData->ulGapFr2ConfigDu[rCall.ltmUeInfo.currCandidateCellIdx];
    }

    if ((IntraRatHO_cmd == rCall.stateCmd) && (HO_TYPE_INTRA_NB == rCall.hoInfo.hoType.nb) &&
        (HO_TYPE_INTER_DU == rCall.hoInfo.hoType.du) &&
        (e_HoTrigger_LtmHandoverPrep != rCall.hoInfo.cause) && (e_HoTrigger_LtmHandoverExec != rCall.hoInfo.cause))
    {
        return rCall.hoInfo.ulGapFr2ConfigDu;
    }

    return rCall.ulGapFr2ConfigDu;
}
inline const UlGapFr2Config_type &FnVCCB_GetUlGapFr2ConfigDu(const callInfo_type &rCall)
{
    if (FnVCCB_IsLtmCandPrepForMeas(rCall))
    {
        if ((MAX_NUM_LTM_CELLS <= rCall.ltmUeInfo.currCandidateCellIdx) || (nullptr == rCall.ltmUeInfo.ptProcRelatedData))
        {
            static const UlGapFr2Config_type dummyUlGapFr2Config = {};
            return dummyUlGapFr2Config;
        }
        return rCall.ltmUeInfo.ptProcRelatedData->ulGapFr2ConfigDu[rCall.ltmUeInfo.currCandidateCellIdx];
    }

    if ((IntraRatHO_cmd == rCall.stateCmd) && (HO_TYPE_INTRA_NB == rCall.hoInfo.hoType.nb) &&
        (HO_TYPE_INTER_DU == rCall.hoInfo.hoType.du) &&
        (e_HoTrigger_LtmHandoverPrep != rCall.hoInfo.cause) && (e_HoTrigger_LtmHandoverExec != rCall.hoInfo.cause))
    {
        return rCall.hoInfo.ulGapFr2ConfigDu;
    }

    return rCall.ulGapFr2ConfigDu;
}

void VCCB_ModifySelectedThresholds_ApplyDelta(const callInfo_type *ptCi, int8_t &value, int16_t delta);
void VCCB_ModifySelectedOffset_ApplyDelta(callInfo_type *ptCi, int8_t &value, int16_t delta);
int8_t VCCB_ApplyDeltaEutra(callInfo_type *ptCi, const measTriggerUe_type &measTriggerQuantity, int16_t delta);
