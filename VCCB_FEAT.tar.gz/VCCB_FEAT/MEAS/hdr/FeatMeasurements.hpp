/**
 * @file        FeatMeasurements.hpp
 * @brief       Measurement Handling functions
 */

#ifndef VCCB_FEAT_FeatMeasurements_HPP_
#define VCCB_FEAT_FeatMeasurements_HPP_

#include "VccbStruct.h"
#include "ComMacro.h"
#include "NRRRC.h"
#include <vector>
#include "ComContainers.hpp"
#include "FeatMeasCommon.hpp"

enum class AddMeasurementStatus
{
    INSTALL_PREP_FAILED = 0,
    NO_MEAS_ID_ADDED,
    MEAS_IDS_ADDED
};

using NcdSsbFreqEntries = simpleVector<NcdSsbFreqEntry_type, MAX_NCD_FREQ_ENTRIES>;

// ******************** ADD MEASUREMENTS ********************

int16_t VCCB_CanMOAndRCBeAdded(callInfo_type *ptCi, CellNum_type cellNum, enumMeasurementReportType reportType,
    uint8_t reportPurpose, Arfcn_type frequency);
bool VCCB_CanMOAndRCBeAddedWithCandidates(callInfo_type &rCi, CellNum_type cellNum,
    enumMeasurementReportType reportType, uint8_t reportPurpose, Arfcn_type frequency,
    reportConfigurationConfUe_type *pRCCandidate, minimalMeasObjectConfUe_type *pMOCandidate);
AddMeasurementStatus VCCB_TryToAddMeasurement(callInfo_type &rCi, const CellNum_type cellNum,
    const enumMeasurementReportType reportType, const uint8_t reportPurpose, const Arfcn_type frequency,
    const enumMeasReportCallbackId_type callbackFuncId);
AddMeasurementStatus VCCB_AddMeasurementWithCandidates(callInfo_type &rCi, const CellNum_type cellNum,
    reportConfigurationConfUe_type &rReportConfigCandidate, minimalMeasObjectConfUe_type &rMeasObjectCandidate,
    const enumMeasReportCallbackId_type callbackFuncId);
int16_t VCCB_AddMeasurementForEutraHandover(callInfo_type *ptCi, uint16_t cellNum, enumMeasurementReportType reportType,
    uint8_t reportPurpose, uint32_t carrierFreq);

AddMeasurementStatus VCCB_AddA2Measurement(callInfo_type *ptCi, CellNum_type cellNum, enumA2Purpose reportPurpose,
    Arfcn_type frequency, enumMeasReportCallbackId_type callbackFuncId);
AddMeasurementStatus VCCB_AddA2Measurement(callInfo_type *ptCi, CellNum_type cellNum, enumA2Purpose reportPurpose,
    Arfcn_type frequency, enumMeasReportCallbackId_type callbackFuncId, int forbiddenQuantitiesBitmask);

AddMeasurementStatus VCCB_AddMeasurementIfPossibleWithForcedQuantities(callInfo_type &rCi, CellNum_type cellNum,
    const enumMeasurementReportType reportType, const uint8_t reportPurpose, Arfcn_type frequency,
    enumMeasReportCallbackId_type callbackFuncId, int forcedQuantitiesBitmask);
AddMeasurementStatus VCCB_AddMeasurementIfPossibleWithForcedQuantity(callInfo_type &rCi, CellNum_type cellNum,
    const enumMeasurementReportType reportType, const uint8_t reportPurpose, Arfcn_type frequency,
    enumMeasReportCallbackId_type callbackFuncId, enumMeasTriggerQuantityChoice forcedQuantity);

int16_t VCCB_AddLateMeasurement(callInfo_type *ptCi, Arfcn_type frequency, enumMeasurementReportType reportType,
    uint8_t reportPurpose, enumMeasReportCallbackId_type callbackFuncId);
int16_t VCCB_AddLateMeasurementIfPossibleWithForcedQuantity(callInfo_type *ptCi, CellNum_type cellNum,
    const enumMeasurementReportType reportType, const uint8_t reportPurpose, Arfcn_type frequency,
    enumMeasReportCallbackId_type callbackFuncId, enumMeasTriggerQuantityChoice forcedQuantity);

void VCCB_AddAnrReportCgiMeasurement(callInfo_type *ptCi, CellNum_type cellNum);
void VCCB_AddAnrMnsReportCgiMeasurement(callInfo_type *ptCi, CellNum_type cellNum);

AddMeasurementStatus VCCB_AddMeasurementForRedCapUeMobilitySa(callInfo_type &rCi, CellNum_type cellNum,
    enumMeasurementReportType reportType, uint8_t reportPurpose, Arfcn_type frequency,
    enumMeasReportCallbackId_type callbackFuncId);

// ******************** ADD MEAS OBJECT ********************

uint8_t VCCB_AddMeasObjectForServCell(
    callInfo_type *ptCi, CellNum_type cellNum, const ssbMeasTiming_type *pSsbMeasTiming, uint16_t freqBandIndicatorNR,
    const simpleVector<uint16_t, MAX_NR_OF_PCI_RANGES> &allowedPciList);
int16_t VCCB_AddEutraMeasObjectOnly(callInfo_type *ptCi, CellNum_type cellNum, measurementObjectEUTRADb_type *ptMO);

// ******************** CREATE CANDIDATES ********************

int16_t FnVCCB_CreateMeasObjectCandidate(callInfo_type &rCall, const enumMeasurementReportType reportType,
    const uint8_t reportPurpose, const CellNum_type cellNum, const Arfcn_type ssbArfcn,
    minimalMeasObjectConfUe_type &measObjectCandidateOut);
int16_t FnVCCB_CreateMeasObjectCandidateForServingCell(callInfo_type &rCall, const enumMeasurementReportType reportType,
    const uint8_t reportPurpose, const CellNum_type cellNum, minimalMeasObjectConfUe_type &measObjectCandidateOut);
int16_t FnVCCB_CreateA2ReportConfigCandidate(callInfo_type &rCall, const CellNum_type cellNum,
    const uint8_t reportPurpose, enumMeasTriggerQuantityChoice thresholdQuantity, int8_t thresholdValue,
    uint8_t reportInterval, uint8_t reportAmount, const minimalMeasObjectConfUe_type &measObjectCandidate,
    reportConfigurationConfUe_type &reportConfigCandidateOut);
reportConfigurationConfUe_type FnVCCB_CreatePeriodicReportConfigCandidate(
    const uint8_t reportPurpose, uint8_t reportInterval, uint8_t reportAmount);

// ******************** CHECKERS ********************

bool VCCB_IsMeasIdInstalled(const callInfo_type &rCi, const enumMeasurementReportType reportType,
    const uint8_t reportPurpose, const Arfcn_type frequency);
int16_t VCCB_CheckIfReportConfigIsIncludedToMeasId(
    callInfo_type *ptCi, enumMeasurementReportType reportType, uint8_t reportPurpose);
int16_t VCCB_CheckIfReportConfigIsAddedNewly(
    callInfo_type *ptCi, enumMeasurementReportType reportType, uint8_t reportPurpose);
int16_t VCCB_CheckIfMeasObjectNrCanBeAdded(
    callInfo_type *ptCi, CellNum_type tgtCellNum, Arfcn_type frequency, enumRSType signalType, int16_t *result);
int16_t VCCB_IsMeasRptObjInDb(
    CellNum_type cellNum, enumMeasurementReportType reportType, uint8_t reportPurpose, Arfcn_type frequency);
int16_t VCCB_IsMeasRptObjEligibleForUe(callInfo_type *ptCi, CellNum_type cellNum, enumMeasurementReportType reportType,
    uint8_t reportPurpose, Arfcn_type frequency);
int16_t VCCB_CheckNewMeasObjectForSCell(callInfo_type *ptCi, Arfcn_type ssbArfcn);
uint8_t fnVCCB_IsSaCapableMO(callInfo_type *ptCi, const measurementObjectNRBaseDb_type *pMeasObjNr);

int VCCM_CheckSupportEutraMeasObject(callInfo_type *ptCi, measurementObjectEUTRADb_type *ptMO);
int VCCM_CheckSupportEutraMeasObject_ForIratHo(callInfo_type *ptCi, measurementObjectEUTRABaseDb_type *ptMO,
    CellNum_type cellNum, enumMeasurementReportType reportType, uint8_t reportPurpose);

bool VCCB_IsMeasGapConfigSet(callInfo_type *ptCi);
bool VCCB_IsCbrsMo(measurementObjectNRBaseDb_type *ptMoDb);
bool VCCB_IsCbrsValidatedMo(measurementObjectNRBaseDb_type *ptMoDb, const uint8_t measObjIndex);

// SVR24A FGR-MC1022
bool FnVCCB_IsCaAwareHandoverByA2Condition(
    callInfo_type *ptCi, uint16_t cellNum, enumMeasurementReportType reportType, uint8_t reportPurpose);
bool FnVCCB_IsScellNbrRelationCellBySsbFreq(callInfo_type *ptCi, uint16_t cellNum, uint32_t ssbFreq);

int16_t VCCB_checkBandwidth(
    const callInfo_type *ptCi, const measurementObjectNRBaseDb_type *pObj, uint16_t bandNR, CellNum_type cellNum);
int16_t VCCB_CheckRfspSpecificSupportPurposeCheck(
    callInfo_type *ptCi, const uint8_t reportType, const uint8_t reportPurpose);
rfspBasedCtrlSpecific_type *FnVCCB_isRfspSpecificUE(callInfo_type *ptCi, CellNum_type cellNum);  // SVR24A FGR-MC1023

// ******************** GETTERS/FINDERS ********************

int16_t VCCB_FindMeasurementObjectById(uint8_t id, const measurementObjectUe_type *array, uint8_t size, uint8_t *idx);
int16_t VCCB_FindReportConfigById(uint8_t id, const reportConfigurationInstalledUe_type *array, uint8_t size, uint8_t *idx);
int16_t VCCB_FindReportConfigById(uint8_t id, const reportConfigurationNewUe_type *array, uint8_t size, uint8_t *idx);
int16_t VCCB_FindMeasurementIdentityById(uint8_t id, measurementIdentity_type *array, uint8_t size, uint8_t *idx);
uint8_t VCCB_FindMatchingMeasIdInMeasProcedure(
    const callInfo_type &rCi, Arfcn_type freq, enumMeasurementReportType wantedReportType, uint8_t wantedReportPurpose);
int16_t VCCB_getMeasObjIdxFreqAutoConfig(callInfo_type *ptCi, CellNum_type cellNum, Arfcn_type ssbFrequency);

measurementObjectNRDb_type *FnVCCB_GetMeasObjectForIntraFrequency(const CellNum_type cellNum);
measurementObjectNRDb_type *FnVCCB_FindMeasObjectUsingFrequency(
    const CellNum_type cellNum, const Arfcn_type ssbFreq, uint8_t *pMeasObjIdx);
const measurementObjectNRDb_type *FnVCCB_GetMeasObjectByFrequency(const VccbCellInfo_type &rCell, const uint32_t ssbFreq);
measurementObjectUe_type *FnVCCB_FindMeasurementObjectUeFromInstalledItemsByFrequency(
    callInfo_type *ptCi, Arfcn_type freq, enumMeasRatType ratType);
measurementObjectUe_type *FnVCCB_FindMeasurementObjectUeFromInstalledItemsByReportCgiFreq(
    callInfo_type *ptCi, Arfcn_type freq, enumMeasRatType ratType);
measurementObjectNRBaseDb_type *VCCB_GetMatchingCbrsMo(Arfcn_type ssbArfcn, CellNum_type cellNum);
measurementObjectUe_type *FnVCCB_FindNRMeasObjectInMeasProc(
    measurementsProcedure_type &rMeasProc, const minimalMeasObjectNRUe_type &rUeMoCandidate);

FreqBandInd_type VCCB_GetBandOfMatchingMeasObjectNR(
    const measurementsConfiguration_type &pUeConf, const Arfcn_type freq);
uint16_t VCCB_GetMoNrBandForUe(const callInfo_type *ptCi, const measurementObjectNRBaseDb_type *pObj);
uint16_t VCCB_GetMoEutraBandForUe(
    callInfo_type *ptCi, const measurementObjectEUTRABaseDb_type *pObj, Arfcn_type *pEarfcn);

const rfspThresholdDelta_type *VCCB_GetRfspDeltasForReportConfig(callInfo_type *ptCi,
    const reportConfigurationConfUe_type *pReportConfig, CellNum_type cellNum,
    const minimalMeasObjectConfUe_type *pMeasObject, const uint8_t svcGrpIdx);
int16_t VCCB_GetEndcSvcGrpId(callInfo_type *ptCi, CellNum_type cellNum, uint8_t *ptSvcGrpId);

smtc1_type FnVCCB_GetEffectiveSmtc1(
    callInfo_type &rCall, CellNum_type cellNum, const measurementObjectNRBaseDb_type &dbObject);
NcdSsbFreqEntries VCCB_GetNcdSsbInterFrequenciesForRedCapUeIntraFrequency(const callInfo_type &rCi);
bool FnVCCB_GetA2MultiTriggerFeatureEnabled(measurementsData_type &rDbConf, uint8_t reportPurpose, Arfcn_type freq);
bool FnVCCB_IsA4ScellAdditionUseAllowedCellsListSet(callInfo_type &rCi, CellNum_type cellNum, Arfcn_type freq);
uint8_t FnVCCB_GetReportConfigQuantitySaHo(const reportConfigurationConfUe_type *pReportConfig);

// *********************************************************************

int16_t VCCB_CommitMeasurementReconfiguration(callInfo_type *ptCi);
bool VCCB_CommitNrRrcMeasConfigUsingAltStructures(callInfo_type &rCi, const measurementsConfiguration_type &measConf,
    const measurementsProcedure_type &measProc, const mGapDuData_type &mgapNew, const saMeasStateInfo_type &saMeas);
void VCCB_CommitDuMo(callInfo_type *ptCi, uint8_t succes);

int16_t VCCM_ClearInstalledMeasConfig(callInfo_type *ptCi);
void VCCB_ClearNewMeasConfig(callInfo_type &rCi, enumVccbFlag clearToRemoveFlag);
void VCCB_ClearMeasGapConfigDu(callInfo_type *ptCi);
void VCCB_ClearCondTriggerConfigFromMeasConfiguration(callInfo_type *ptCi);

int16_t VCCB_RemoveMeasurementIdentity(callInfo_type *ptCi, NRRRC_MeasId measId);
int16_t VCCM_BreakInternalIdxInNewItems(callInfo_type *ptCi);

int16_t VCCB_PrepareNewMeasConfig(callInfo_type *ptCi);
int16_t VCCB_PrepareNewMeasConfigWithTaintedInstalledItems(callInfo_type *ptCi);
int16_t VCCB_PrepareAdditionalMeasConfig(callInfo_type *ptCi);
int16_t VCCM_PrepareAdditionalMeasurementConfig(callInfo_type *ptCi);
int8_t VCCB_PrepareRfspDeltaThreshold(bool isRedcapUe, uint8_t quantity, rfspDeltaTh_type deltaThreshold);

void VCCB_ModifyReportConfiguration_IncludeCommonLocationInfo(
    callInfo_type *ptCi, reportConfigurationConfUe_type *pUeRpt, CellNum_type cellNum);

void FnVCCB_SetIncludeBeamMeas(reportConfigurationConfUe_type &rcCandidate);
void FnVCCB_SetReportQuantityRsIndexes(
    reportConfigurationConfUe_type &rcCandidate, const reportQuantity_type reportQuantity);
void FnVCCB_SetMaxNrOfRsIndexesToReport(
    reportConfigurationConfUe_type &rcCandidate, const uint8_t maxNrOfRsIndexesValue);

void VCCB_FillDuMoWithMeasFreqSn(callInfo_type *ptCi);
void VCCB_FillDuMoWithMeasFreqNrDlTdoa(callInfo_type *ptCi);
int16_t VCCB_DecideMeasGap(callInfo_type *ptCi);

/****************************************************************************
 * @brief  Helper function which return how many measurements can be installed
 * @param  rCi            : reference to UE Context
 * @return uint32_t       : amount of remaining meas ids
 ****************************************************************************/
inline uint32_t VCCB_GetRemainingMeasIds(const callInfo_type &rCi)
{
    const measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(rCi);
    const uint8_t numberOfCurrentUsedIds = rMeasProc.measurementIdentities.numNewItems;
    const size_t maxMeasIds = VCCB_ARRAY_COUNT(rMeasProc.measurementIdentities.newItems);
    if (numberOfCurrentUsedIds >= maxMeasIds)
    {
        return 0;
    }

    return static_cast<uint32_t>(maxMeasIds - numberOfCurrentUsedIds);
}

/****************************************************************************
 * @brief  Helper function dedicated to use during measurement instalation process with
 *         VCCB_CanMOAndRCBeAddedWithCandidates/VCCB_AddMeasurement functions
 * @param  rCi            : reference to UE Context
 * @return bool           : status : false/true
 ****************************************************************************/
inline bool VCCB_IsAnyMeasIdLeft(const callInfo_type &rCi) { return (VCCB_GetRemainingMeasIds(rCi) > 0); }

/****************************************************************************
 * @brief  Helper function which checks that no more measurements can be installed
 * @param  rCi            : reference to UE Context
 * @return bool           : status : false/true
 ****************************************************************************/
inline bool VCCB_IsNoMeasIdsLeft(const callInfo_type &rCi) { return (VCCB_GetRemainingMeasIds(rCi) == 0); }

typedef struct
{
    int32_t rsrpValueSSB;  // -24 ... 24
    int32_t rsrqValueSSB;  // -24 ... 24
    int32_t sinrValueSSB;  // -24 ... 24
} qOffsetRangeValueList_type;

#define pairCellsToMeas std::pair<uint16_t /*pci*/, cellsToMeasInfo_type>
typedef struct
{
    std::vector<uint16_t> pciList;
    uint16_t numList[MAX_PHYSICAL_CELL_ID + 1];
    cellsToMeasInfo_type info[MAX_PHYSICAL_CELL_ID + 1];
} cellsToMeasCandidatesInfo_type;

class SvcGrpChangeProcedureControl
{
public:
    SvcGrpChangeProcedureControl(callInfo_type &rCall) : rMeasConf(FnVCCB_GetMeasurementsConfiguration(rCall))
    {
        rMeasConf.svcGrpChangeProcedure = TRUE;
    }
    ~SvcGrpChangeProcedureControl() { rMeasConf.svcGrpChangeProcedure = FALSE; }

protected:
    measurementsConfiguration_type &rMeasConf;
};

void FnVCCB_AddAllowedCellsToMeasObjectCandidate(
    minimalMeasObjectConfUe_type &measObject, const simpleVector<uint16_t, MAX_NR_OF_PCI_RANGES> &pciList);

// FGR-MC1007 FR500–FR570: NR mobility restriction for ping-pong avoidance
int16_t FnVCCB_ProcessUeHistoryForPingPongAvoidance(callInfo_type &rCall);
bool FnVCCB_SetPingPongAvoidanceSsbFrequency(callInfo_type &rCall, CellNum_type cellNum);
bool FnVCCB_IsPingPongAvoidanceRestrictTimeActive(callInfo_type &rCall);
int16_t FnVCCB_ProcessPingPongAvoidanceRestriction(callInfo_type &rCall, CellNum_type cellNum);
bool FnVCCB_IsPingPongAvoidanceRestrictionByOption(
    callInfo_type &rCall, CellNum_type cellNum, const measurementObjectNRBaseDb_type &rMoNrDb);
bool FnVCCB_IsPingPongAvoidanceRestrictionRequired(uint8_t reportType, uint8_t reportPurpose);
bool FnVCCB_IsPingPongAvoidanceNrRestriction(callInfo_type &rCall, CellNum_type cellNum, const measurementObjectNRBaseDb_type &rMoNrDb);
bool FnVCCB_IsPingPongAvoidanceRestriction(callInfo_type &rCall, CellNum_type cellNum, const measurementObjectNRBaseDb_type &rMoNrDb,
    uint8_t reportType, uint8_t reportPurpose);

#ifdef IPC_TEST
int FnVCCB_AdjustCalculatedCio(int value);
uint16_t FnVCCB_updateCioDeltaNR(int cio);
bool VCCB_UpSortCellsToMeas(pairCellsToMeas &a, pairCellsToMeas &b);
qOffsetRangeValueList_type getQOffsetRangeListInDecibels(const qOffsetSSBRangeList_type &x);
qOffsetRangeValueList_type FnVCCB_CalculatedNrCioInDecibles(
    const qOffsetRangeValueList_type &a, const qOffsetRangeValueList_type &b);
qOffsetSSBRangeList_type FnVCCB_GetNrQOOffsetRangeListFromValueList(qOffsetRangeValueList_type v);
qOffsetRangeValueList_type FnVCCB_AdjustCalculatedNrCioValue(qOffsetRangeValueList_type v);
bool FnVCCB_IsValidCellIndividualOffset(const cellsToMeasInfo_type &candidateCell);
void VCCB_UpdateCellsToMeasureEutra(const callInfo_type *ptCi, measurementObjectEUTRAUe_type *pUeObj,
    CellNum_type cellNum, int8_t eutraSmallCellPciListIdx);
void VCCB_UpdateCellsToMeasureNR(
    callInfo_type *ptCi, measurementObjectNRUe_type *pUeObj, CellNum_type cellNum, int8_t nrSmallCellPciListIdx);
#endif
#endif
