/**
 * @file     : FeatTrafficMeasurements.hpp
 * @brief    : header file for functions related to traffic measurements installed on AUPF
 *
 * @date     : 2022/06/01
 *
 * Copyright 2020 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef VCCB_FEAT_FeatTrafficMeasurements_HPP_
#define VCCB_FEAT_FeatTrafficMeasurements_HPP_

#include "VccbStruct.h"

/**
 * @brief       Traffic Measurement Report callback function definition and callback to purpose mapping definition
 * @details     [FGR-CC8001] DL PDCP traffic status monitoring control (NR)
 */
typedef int16_t (*trafficMeasReportCallback_type)(
    struct callInfo_s *ptCi, struct E1_PrivateMessage *ptMsg, uint8_t reportIdx);

typedef struct
{
    trafficMeasReportCallback_type callback;
    enumTrafficReportingPurpose_type purpose;
} trafficMeasReportCallbackMap_type;

// Measurement management API
int16_t VCCB_TriggerTrafficMeasurementReconfiguration(callInfo_type *ptCi, enqueuedAction);
int16_t VCCB_GetTrafficMonitoringCfgDB(callInfo_type *ptCi, uint16_t cellNum, enumTrafficReportingPurpose_type purpose,
    enumTrafficReportingCondition_type condition, uint16_t *pThreshold);
void VCCB_InitTrafficMeasReportCallbackTable();
void VCCB_SetTrafficMonitoringMeasurements(callInfo_type *ptCi);

// Callbacks
int16_t VCCM_ProcE1PrivateMessage(callInfo_type *ptCi, struct E1_PrivateMessage *pMsg);
int16_t VCCM_ProcReportEnDcTrafficBasedPsCellChange(
    callInfo_type *ptCi, struct E1_PrivateMessage *pMsg, uint8_t reportIdx);
int16_t FnVCCB_ProcReportTrafficBasedNrToEutraHandover(
    callInfo_type *ptCi, struct E1_PrivateMessage *pMsg, uint8_t reportIdx);
int16_t FnVCCB_ProcReportTrafficBasedInterRatPccChange(
    callInfo_type *ptCi, struct E1_PrivateMessage *pMsg, uint8_t reportIdx);
int16_t FnVCCB_ProcReportTrafficBasedMrs(
    callInfo_type *ptCi, struct E1_PrivateMessage *pMsg, uint8_t reportIdx);
int16_t FnVCCB_ProcUlTrafficStatusReportForNrdc(callInfo_type *ptCi);
int16_t FnVCCB_ProcDlTrafficStatusReportForNrdc(callInfo_type *ptCi, struct E1_PrivateMessage *pMsg, uint8_t reportIdx);
int16_t FnVCCB_HandleTrafficStatusReportForNrdc(callInfo_type *ptCi, enqueuedAction action);
void FnVCCB_InitTrafficReportDrbProperty(callInfo_type *ptCi, callDRBInfo_type *pDi);
#endif
