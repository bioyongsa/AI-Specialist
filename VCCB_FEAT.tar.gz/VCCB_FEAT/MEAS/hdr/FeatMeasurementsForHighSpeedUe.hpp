#pragma once

#include "VccbStruct.h"

void VCCB_ModifyReportConfig_HighSpeedUe(const callInfo_type &call, reportConfigurationConfUe_type &ueRpt,
    const reportConfigurationBaseDb_type &dbObject, CellNum_type cellNum);
