/**
 * @file     : FeatMeasurementObjectPriority.hpp
 * @brief    : header file for functions related to measurement object priority feature
 *
 * @author   : k.laskowski2@partner.samsung.com
 * @date     : 2020/10/28
 *
 * Copyright 2020 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#ifndef VCCB_FEAT_FeatMeasurementObjectPriority_HPP_
#define VCCB_FEAT_FeatMeasurementObjectPriority_HPP_

#include "VccbStruct.h"
#include "ComContainers.hpp"
#include "ComConsecutiveIdsPool.hpp"

class MeasurementConfigurationObjectIdAllocator
{
public:
    MeasurementConfigurationObjectIdAllocator(callInfo_type& ci);

    int16_t allocateIdsForMeasurementObjects(const VccbCellInfo_type& servingCell);

private:
    void clearPendingForInstalledItemsToRemove();

    template <enumMeasRatType RatType>
    void assignMeasObjectIds(const VccbCellInfo_type& servingCell);

    callInfo_type& ci_;
};

class MeasIdAllocator
{
public:
    MeasIdAllocator(callInfo_type& ci);
    int16_t alignMeasIdWithMeasObjectId();
    int16_t alignMeasIdWithMeasObjectCapacity();

protected:
    struct MeasIdWithNewItemIndex {
        measurementIdentity_type measId;
        uint8_t newItemIndex;
    };
    using MeasIdsPool = util::ConsecutiveIdsPool<0, MAX_NR_OF_MEAS_ID_3GPP - 1>;
    using MeasIdsList = simpleVector<uint8_t, MAX_NR_OF_MEAS_ID>;
    using MeasIdsPerNewItemIndexList = simpleVector<MeasIdWithNewItemIndex, MAX_NR_OF_MEAS_ID>;
private:
    bool compareNrdcMeasIdsByCapacity(const MeasIdWithNewItemIndex& left, const MeasIdWithNewItemIndex& right);
    int16_t prepareMeasIdsToInstall(
        MeasIdsPool& measIdsPool,
        MeasIdsPerNewItemIndexList& allMeasIds,
        MeasIdsList& currentlyInstalledMeasIds);

    bool assignFreeMeasIds(MeasIdsPool measIdsPool, MeasIdsPerNewItemIndexList& allMeasIds);

    int16_t reassignMeasIds(
        MeasIdsPool measIdsPool,
        MeasIdsPerNewItemIndexList& allMeasIds,
        MeasIdsList& currentlyInstalledMeasIds);

    callInfo_type& rCi;
    measurementsProcedure_type& rMeasProc;
    measurementsConfiguration_type& rMeasConf;

    MeasIdsList reservedMeasIds{};
};

#endif