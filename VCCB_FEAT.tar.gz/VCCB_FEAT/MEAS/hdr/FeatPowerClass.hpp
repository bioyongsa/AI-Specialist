/**
 * @file        FeatPowerClass.hpp
 * @brief       UE Power Class Handling functions
 */

#ifndef VCCB_FEAT_FeatPowerClass_HPP_
#define VCCB_FEAT_FeatPowerClass_HPP_

#include "VccbStruct.h"
#include "ComMacro.h"

typedef struct
{
    uint8_t canPc1BeAppliedToPCell          : 1;
    uint8_t canPc1BeAppliedToMeasObject     : 1;
    uint8_t canPc1dot5BeAppliedToPCell      : 1;
    uint8_t canPc1dot5BeAppliedToMeasObject : 1;
    uint8_t canPc2BeAppliedToPCell          : 1;
    uint8_t canPc2BeAppliedToMeasObject     : 1;
    uint8_t reserved                        : 2;
} PowerClassDeltasApplicabilityFr1_type;

typedef struct
{
    uint8_t canPc1BeAppliedToPCell      : 1;
    uint8_t canPc1BeAppliedToMeasObject : 1;
    uint8_t reserved                    : 6;
} PowerClassDeltasApplicabilityFr2_type;

typedef struct
{
    PowerClassDeltasApplicabilityFr1_type fr1;
    PowerClassDeltasApplicabilityFr2_type fr2;
} PowerClassDeltasApplicability_type;

bool VCCB_AreFr1PowerClassSavedDeltasEffective(const fr1PowerClassSavedDeltas_type &rFr1PcSavedDeltas);
bool VCCB_WillFr1PCStateModifyRCInTheSameWay(const fr1PowerClassState_type& lhs, const fr1PowerClassState_type& rhs);
PowerClassDeltasApplicability_type VCCB_GetWhichPcDeltasAreApplicableUsingMeasObjectCandidate(callInfo_type &rCi,
    const minimalMeasObjectConfUe_type &rMO, const reportConfigurationConfUe_type &rRC, CellNum_type cellNum);
PowerClassDeltasApplicability_type VCCB_GetWhichPcDeltasAreApplicableUsingMeasObjectInstalled(callInfo_type &rCi,
    const measurementObjectConfUe_type &rMO, const reportConfigurationConfUe_type &rRC, CellNum_type cellNum);
    
void FnVCCB_ApplyFR1PowerClassDeltasIfAllConditionsMet(callInfo_type *ptCi);
void VCCB_HandlePowerClassDeltas(callInfo_type *ptCi, reportConfigurationConfUe_type *pReportConfig,
    const minimalMeasObjectConfUe_type &rMoCandidate, CellNum_type cellNum);
void VCCB_ModifyFr1PowerClassDeltasApplicabilityBasedOnCallState(
    callInfo_type &rCi, bool isForPcellMeasObject, PowerClassDeltasApplicabilityFr1_type &applicability);
void VCCB_SaveHighestFr1PowerClassUeCapability(callInfo_type &rCi);

#endif
