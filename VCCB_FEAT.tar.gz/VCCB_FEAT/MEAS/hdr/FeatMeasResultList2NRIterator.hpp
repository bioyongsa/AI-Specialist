#ifndef FEATMEASRESULTLIST2NRITERATOR_HPP
#define FEATMEASRESULTLIST2NRITERATOR_HPP

#include "VccbStruct.h"
#include "ComMacro.h"

/**
 * @brief Base visitor type used by VCCB_MeasResultList2NRIterator.
 *        By implementing its interface different operations can be done
 *        on a measResultList2NR collection (e.g. best cell selection or
 *        other candidates check).
 *
 */
struct VCCB_MeasResultList2NRVisitor
{
    /**
     * @brief Called when serving cell result is present for a frequency.
     *
     */
    virtual void VisitServingCell(const measResult2NR_type &, const measResultNR_type &) = 0;
    /**
     * @brief Called when neighbour cell result is present for a frequency.
     *
     */
    virtual void VisitNeighbourPci(const measResult2NR_type &, const measResultNR_type &) = 0;
    /**
     * @brief This method is used to tell Iterator that any other call to
     *        VisitServingCell or VisitNeighbourPci won't change visitor's state.
     *        Used to stop iteration of measResultList2NR.
     *
     * @return true
     * @return false
     */
    virtual bool IsResultDetermined() = 0;
};

/**
 * @brief Generic iterator class for measResultList2NR.
 *        In cooperation with VCCB_MeasResultList2NRVisitor different results can be achieved.
 *
 */
class VCCB_MeasResultList2NRIterator
{
private:
    const callInfo_type *_ptCi;

protected:
    /**
     * @brief Validation of per-frequency measurement object.
     *
     * @param rMeasRes2NR frequency measurement object
     * @return true
     * @return false
     */
    inline bool _IsValid(const measResult2NR_type &rMeasRes2NR)
    {
        return ((FALSE != rMeasRes2NR.ssbFrequency_Flag) || (FALSE != rMeasRes2NR.refFreqCSI_RS_Flag));
    }
    /**
     * @brief Validation of serving cell measurement object.
     *
     * @return true
     * @return false
     */
    inline bool _IsValidServingCell(const measResultNR_type &) { return true; }
    /**
     * @brief Validation of neighbour cell measurement object.
     *
     * @param rMeasResNR cell measurement object
     * @return true
     * @return false
     */
    inline bool _IsValidNeighbourCell(const measResultNR_type &rMeasResNR)
    {
        return (FALSE != rMeasResNR.physCellIdFlag);
    }

public:
    VCCB_MeasResultList2NRIterator(const callInfo_type *ptCi) : _ptCi(ptCi) {}
    /**
     * @brief Call this method to iterate over all cells in given measResultList2NR.
     *        A implementation of VCCB_MeasResultList2NRVisitor interface is used.
     *        For each cell in measResultList2NR visitor's function VisitServingCell or
     *        VisitNeighbourPci is called.
     *
     * @param measResultList2NR list to iterate over
     * @param visitor implementation of VCCB_MeasResultList2NRVisitor interface
     */
    void IterateAndVisit(const measResultList2NR_type &measResultList2NR, VCCB_MeasResultList2NRVisitor &visitor);
};

/**
 * @brief Implementation of VCCB_MeasResultList2NRVisitor interafce for the purpose of
 *        FGR-CC5001 (Mobility for EN-DC)/FR196.
 *        Checks whether NR-CGI candidates are served by this gNB.
 *        Condition is satisfied if:
 *          - candidateCellInfoListMN has some NR-CGI cells and at least one is served by this gNB (ptCi->gnbNum),
 *          - candidateCellInfoListMN has no NR-CGI cells.
 *
 */
class VCCB_MeasResultList2NRVisitor_IsAnyOfNrcgiCandidateCellServedByThisGnb : public VCCB_MeasResultList2NRVisitor
{
private:
    const callInfo_type *_ptCi;
    bool _foundIntraGnbNrcgiCell;
    int _interGnbNrcgiCellsCount;

protected:
    /**
     * @brief Returns true if cell measurement includes valid NR-CGI object.
     *
     * @param rMeasResNR cell measurement object
     * @return true
     * @return false
     */
    bool _HasMeasResultNrcgi(const measResultNR_type &rMeasResNR) const;
    /**
     * @brief Returns true if given cell is intra-gNB with ptCi->gnbNum.
     *
     * @param rMeasResNR cell measurement object
     * @return true
     * @return false
     */
    bool _IsIntraGnb(const measResultNR_type &rMeasResNR) const;
    /**
     * @brief Returns true if given cell is PSCell (ptCi->servCellNum) of our call.
     *
     * @param rMeasRes2NR frequency measurement object
     * @param rMeasResNR cell measurement object
     * @return true
     * @return false
     */
    bool _IsMeasOfPscell(const measResult2NR_type &rMeasRes2NR, const measResultNR_type &rMeasResNR);
    /**
     * @brief Returns true if call as a SCell of given frequency and matching PCI.
     *
     * @param rMeasRes2NR frequency measurement object
     * @param rMeasResNR cell measurement object
     * @return true
     * @return false
     */
    bool _FindScellByFreqAndPci(const measResult2NR_type &rMeasRes2NR, const measResultNR_type &rMeasResNR);

public:
    VCCB_MeasResultList2NRVisitor_IsAnyOfNrcgiCandidateCellServedByThisGnb(const callInfo_type *ptCi) :
        _ptCi(ptCi),
        _foundIntraGnbNrcgiCell(false),
        _interGnbNrcgiCellsCount(0)
    {
    }
    /**
     * @brief VCCB_MeasResultList2NRVisitor interface impl.
     *
     */
    virtual void VisitServingCell(const measResult2NR_type &rMeasRes2NR, const measResultNR_type &rMeasResNR);
    virtual void VisitNeighbourPci(const measResult2NR_type &, const measResultNR_type &rMeasResNR);
    virtual bool IsResultDetermined() { return _foundIntraGnbNrcgiCell; }
    /**
     * @brief This function tells whether class condition is satisfied (see class description comment)
     *        after whole measResultList2NR was checked.
     *
     * @return true
     * @return false
     */
    inline bool IsSatisfied() { return (_foundIntraGnbNrcgiCell || (0 == _interGnbNrcgiCellsCount)); }
};

#endif  // FEATMEASRESULTLIST2NRITERATOR_HPP
