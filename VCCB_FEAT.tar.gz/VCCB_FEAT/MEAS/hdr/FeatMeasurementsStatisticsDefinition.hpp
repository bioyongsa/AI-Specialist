#pragma once

#include "VccbStruct.h"
#include "ComMacro.h"
#include <optional>

struct OneCategoryStatTypes
{
    int rsrpCount;
    int rsrpSum;
    int rsrqCount;
    int rsrqSum;
    int sinrCount;
    int sinrSum;

    std::optional<int> purposeCount = std::nullopt;
    std::optional<int> rsrpAllOccurences = std::nullopt;
};

struct QuantityCounter
{
    enumMeasurementReportType reportType;
    uint8_t reportPurpose;
    int mFamily;
    OneCategoryStatTypes stats;
    bool (*checkCallType)(callInfo_type*);
};

inline bool AcceptAllCallTypes(callInfo_type* ptCi)
{
    (void)ptCi;
    return true;
}

inline bool IsSaOrNrdcMn(callInfo_type* ptCi)
{
    if (ptCi == NULL) return false;
    bool isNrdcMn = IS_NRDC_MN(ptCi);
    bool isSa = (E_CALLTYPE_SA == ptCi->callType) && (IsAvailable_MrdcInfo() == false);
    return isSa || isNrdcMn;
}

inline bool IsNrdcSn(callInfo_type* ptCi)
{
    bool isNrdcSn = IS_NRDC_SN(ptCi);
    return isNrdcSn;
}

inline bool IsEndc(callInfo_type* ptCi)
{
    if (ptCi == NULL) return false;
    return (E_CALLTYPE_NSA == ptCi->callType);
}

constexpr QuantityCounter MEAS_QUANTITY_COUNTERS[]{
    // STAT_MEAS_REPORT_DU_ID FAMILY
    // A2 cases
    {.reportType = measReport_A2,
        .reportPurpose = a2Purpose_nrdcNRPSCellRelease,  // nr-dc-pscell-release-purpose
        .mFamily = STAT_MEAS_REPORT_DU_ID,
        .stats = {.rsrpCount = MrEventA2PurposePSCellReleaseRsrpCount,
            .rsrpSum = MrEventA2PurposePSCellReleaseRsrpSum,
            .rsrqCount = MrEventA2PurposePSCellReleaseRsrqCount,
            .rsrqSum = MrEventA2PurposePSCellReleaseRsrqSum,
            .sinrCount = MrEventA2PurposePSCellReleaseSinrCount,
            .sinrSum = MrEventA2PurposePSCellReleaseSinrSum},
        .checkCallType = AcceptAllCallTypes},
    {.reportType = measReport_A2,
        .reportPurpose = a2Purpose_NRPSCellRelease,  // en-dc-nr-pscell-release-purpose
        .mFamily = STAT_MEAS_REPORT_DU_ID,
        .stats = {.rsrpCount = MrEventA2PurposePSCellReleaseRsrpCount,
            .rsrpSum = MrEventA2PurposePSCellReleaseRsrpSum,
            .rsrqCount = MrEventA2PurposePSCellReleaseRsrqCount,
            .rsrqSum = MrEventA2PurposePSCellReleaseRsrqSum,
            .sinrCount = MrEventA2PurposePSCellReleaseSinrCount,
            .sinrSum = MrEventA2PurposePSCellReleaseSinrSum},
        .checkCallType = AcceptAllCallTypes},

    // A3 cases
    {.reportType = measReport_A3,
        .reportPurpose = a3Purpose_intraNrHandover,  // intra-nr-handover-purpose
        .mFamily = STAT_MEAS_REPORT_DU_ID,
        .stats = {.rsrpCount = MrEventA3PurposeHandoverRsrpCount,
            .rsrpSum = MrEventA3PurposeHandoverRsrpSum,
            .rsrqCount = MrEventA3PurposeHandoverRsrqCount,
            .rsrqSum = MrEventA3PurposeHandoverRsrqSum,
            .sinrCount = MrEventA3PurposeHandoverSinrCount,
            .sinrSum = MrEventA3PurposeHandoverSinrSum},
        .checkCallType = AcceptAllCallTypes},
    {.reportType = measReport_A3,
        .reportPurpose = a3Purpose_nrdcNrPSCellChange,  // nr-dc-nr-pscell-change-purpose
        .mFamily = STAT_MEAS_REPORT_DU_ID,
        .stats = {.rsrpCount = MrEventA3PurposePSCellChangeRsrpCount,
            .rsrpSum = MrEventA3PurposePSCellChangeRsrpSum,
            .rsrqCount = MrEventA3PurposePSCellChangeRsrqCount,
            .rsrqSum = MrEventA3PurposePSCellChangeRsrqSum,
            .sinrCount = MrEventA3PurposePSCellChangeSinrCount,
            .sinrSum = MrEventA3PurposePSCellChangeSinrSum},
        .checkCallType = AcceptAllCallTypes},
    {.reportType = measReport_A3,
        .reportPurpose = a3Purpose_NRPSCellChange,  // en-dc-nr-pscell-change-purpose
        .mFamily = STAT_MEAS_REPORT_DU_ID,
        .stats = {.rsrpCount = MrEventA3PurposePSCellChangeRsrpCount,
            .rsrpSum = MrEventA3PurposePSCellChangeRsrpSum,
            .rsrqCount = MrEventA3PurposePSCellChangeRsrqCount,
            .rsrqSum = MrEventA3PurposePSCellChangeRsrqSum,
            .sinrCount = MrEventA3PurposePSCellChangeSinrCount,
            .sinrSum = MrEventA3PurposePSCellChangeSinrSum},
        .checkCallType = AcceptAllCallTypes},
    {.reportType = measReport_A3,
        .reportPurpose = a3Purpose_Comp,  // comp-purpose
        .mFamily = STAT_MEAS_REPORT_DU_ID,
        .stats = {.rsrpCount = MrEventA3PurposeULCompRsrpCount,
            .rsrpSum = MrEventA3PurposeULCompRsrpSum,
            .rsrqCount = MrEventA3PurposeULCompRsrqCount,
            .rsrqSum = MrEventA3PurposeULCompRsrqSum,
            .sinrCount = MrEventA3PurposeULCompSinrCount,
            .sinrSum = MrEventA3PurposeULCompSinrSum},
        .checkCallType = AcceptAllCallTypes},

    // A4 cases
    {.reportType = measReport_A4,
        .reportPurpose = a4Purpose_intraNrHandover,  // intra-nr-handover-purpose
        .mFamily = STAT_MEAS_REPORT_DU_ID,
        .stats = {.rsrpCount = MrEventA4PurposeHandoverRsrpCount,
            .rsrpSum = MrEventA4PurposeHandoverRsrpSum,
            .rsrqCount = MrEventA4PurposeHandoverRsrqCount,
            .rsrqSum = MrEventA4PurposeHandoverRsrqSum,
            .sinrCount = MrEventA4PurposeHandoverSinrCount,
            .sinrSum = MrEventA4PurposeHandoverSinrSum},
        .checkCallType = AcceptAllCallTypes},
    {.reportType = measReport_A4,
        .reportPurpose = a4Purpose_nrdcNrPSCellChange,  // nr-dc-nr-pscell-change-purpose
        .mFamily = STAT_MEAS_REPORT_DU_ID,
        .stats = {.rsrpCount = MrEventA4PurposePSCellChangeRsrpCount,
            .rsrpSum = MrEventA4PurposePSCellChangeRsrpSum,
            .rsrqCount = MrEventA4PurposePSCellChangeRsrqCount,
            .rsrqSum = MrEventA4PurposePSCellChangeRsrqSum,
            .sinrCount = MrEventA4PurposePSCellChangeSinrCount,
            .sinrSum = MrEventA4PurposePSCellChangeSinrSum},
        .checkCallType = AcceptAllCallTypes},
    {.reportType = measReport_A4,
        .reportPurpose = a4Purpose_NRPSCellChange,  // en-dc-nr-pscell-change-purpose
        .mFamily = STAT_MEAS_REPORT_DU_ID,
        .stats = {.rsrpCount = MrEventA4PurposePSCellChangeRsrpCount,
            .rsrpSum = MrEventA4PurposePSCellChangeRsrpSum,
            .rsrqCount = MrEventA4PurposePSCellChangeRsrqCount,
            .rsrqSum = MrEventA4PurposePSCellChangeRsrqSum,
            .sinrCount = MrEventA4PurposePSCellChangeSinrCount,
            .sinrSum = MrEventA4PurposePSCellChangeSinrSum},
        .checkCallType = AcceptAllCallTypes},
    {.reportType = measReport_A4,
        .reportPurpose = a4Purpose_NrdcAddition,  // nr-dc-sn-addition-purpose
        .mFamily = STAT_MEAS_REPORT_DU_ID,
        .stats = {.rsrpCount = MrEventA4PurposeSNAdditionRsrpCount,
            .rsrpSum = MrEventA4PurposeSNAdditionRsrpSum,
            .rsrqCount = MrEventA4PurposeSNAdditionRsrqCount,
            .rsrqSum = MrEventA4PurposeSNAdditionRsrqSum,
            .sinrCount = MrEventA4PurposeSNAdditionSinrCount,
            .sinrSum = MrEventA4PurposeSNAdditionSinrSum},
        .checkCallType = AcceptAllCallTypes},

    // A5 cases
    {.reportType = measReport_A5,
        .reportPurpose = a5Purpose_intraNrHandover,  // intra-nr-handover-purpose
        .mFamily = STAT_MEAS_REPORT_DU_ID,
        .stats = {.rsrpCount = MrEventA5PurposeHandoverRsrpCount,
            .rsrpSum = MrEventA5PurposeHandoverRsrpSum,
            .rsrqCount = MrEventA5PurposeHandoverRsrqCount,
            .rsrqSum = MrEventA5PurposeHandoverRsrqSum,
            .sinrCount = MrEventA5PurposeHandoverSinrCount,
            .sinrSum = MrEventA5PurposeHandoverSinrSum},
        .checkCallType = AcceptAllCallTypes},
    {.reportType = measReport_A5,
        .reportPurpose = a5Purpose_nrdcNrPSCellChange,  // nr-dc-nr-pscell-change-purpose
        .mFamily = STAT_MEAS_REPORT_DU_ID,
        .stats = {.rsrpCount = MrEventA5PurposePSCellChangeRsrpCount,
            .rsrpSum = MrEventA5PurposePSCellChangeRsrpSum,
            .rsrqCount = MrEventA5PurposePSCellChangeRsrqCount,
            .rsrqSum = MrEventA5PurposePSCellChangeRsrqSum,
            .sinrCount = MrEventA5PurposePSCellChangeSinrCount,
            .sinrSum = MrEventA5PurposePSCellChangeSinrSum},
        .checkCallType = AcceptAllCallTypes},
    {.reportType = measReport_A5,
        .reportPurpose = a5Purpose_NRPSCellChange,  // en-dc-nr-pscell-change-purpose
        .mFamily = STAT_MEAS_REPORT_DU_ID,
        .stats = {.rsrpCount = MrEventA5PurposePSCellChangeRsrpCount,
            .rsrpSum = MrEventA5PurposePSCellChangeRsrpSum,
            .rsrqCount = MrEventA5PurposePSCellChangeRsrqCount,
            .rsrqSum = MrEventA5PurposePSCellChangeRsrqSum,
            .sinrCount = MrEventA5PurposePSCellChangeSinrCount,
            .sinrSum = MrEventA5PurposePSCellChangeSinrSum},
        .checkCallType = AcceptAllCallTypes},

    // STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE FAMILY
    // A1 cases
    {.reportType = measReport_A1,
        .reportPurpose = a1Purpose_caAwareHandover,  // ca-aware-handover-for-scell-to-pcell-change-purpose
        .mFamily = STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrSaAndNrdcMnA1CaAwareHandoverForScellToPcellChangeRsrpCount,
                .rsrpSum = MrSaAndNrdcMnA1CaAwareHandoverForScellToPcellChangeRsrpSum,
                .rsrqCount = MrSaAndNrdcMnA1CaAwareHandoverForScellToPcellChangeRsrqCount,
                .rsrqSum = MrSaAndNrdcMnA1CaAwareHandoverForScellToPcellChangeRsrqSum,
                .sinrCount = MrSaAndNrdcMnA1CaAwareHandoverForScellToPcellChangeSinrCount,
                .sinrSum = MrSaAndNrdcMnA1CaAwareHandoverForScellToPcellChangeSinrSum,
                .purposeCount = MrSaAndNrdcMnA1CaAwareHandoverForScellToPcellChangeCount,
            },
        .checkCallType = IsSaOrNrdcMn},
    {.reportType = measReport_A1,
        .reportPurpose = a1Purpose_saDeactivateMeasureGap,  // sa-deactivate-meas-gap-purpose
        .mFamily = STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrSaAndNrdcMnA1SaDeactivateMeasGapRsrpCount,
                .rsrpSum = MrSaAndNrdcMnA1SaDeactivateMeasGapRsrpSum,
                .rsrqCount = MrSaAndNrdcMnA1SaDeactivateMeasGapRsrqCount,
                .rsrqSum = MrSaAndNrdcMnA1SaDeactivateMeasGapRsrqSum,
                .sinrCount = MrSaAndNrdcMnA1SaDeactivateMeasGapSinrCount,
                .sinrSum = MrSaAndNrdcMnA1SaDeactivateMeasGapSinrSum,
                .purposeCount = MrSaAndNrdcMnA1SaDeactivateMeasGapCount,
            },
        .checkCallType = IsSaOrNrdcMn},
    // A2 cases
    {.reportType = measReport_A2,
        .reportPurpose = a2Purpose_activateInterFrequencyForSa,  // activate-inter-frequency-purpose
        .mFamily = STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrSaAndNrdcMnA2ActivateInterFrequencyRsrpCount,
                .rsrpSum = MrSaAndNrdcMnA2ActivateInterFrequencyRsrpSum,
                .rsrqCount = MrSaAndNrdcMnA2ActivateInterFrequencyRsrqCount,
                .rsrqSum = MrSaAndNrdcMnA2ActivateInterFrequencyRsrqSum,
                .sinrCount = MrSaAndNrdcMnA2ActivateInterFrequencySinrCount,
                .sinrSum = MrSaAndNrdcMnA2ActivateInterFrequencySinrSum,
                .purposeCount = MrSaAndNrdcMnA2ActivateInterFrequencyCount,
            },
        .checkCallType = IsSaOrNrdcMn},
    {.reportType = measReport_A2,
        .reportPurpose = a2Purpose_activate_inter_rat,  // activate-inter-rat-purpose
        .mFamily = STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrSaAndNrdcMnA2ActivateInterRatRsrpCount,
                .rsrpSum = MrSaAndNrdcMnA2ActivateInterRatRsrpSum,
                .rsrqCount = MrSaAndNrdcMnA2ActivateInterRatRsrqCount,
                .rsrqSum = MrSaAndNrdcMnA2ActivateInterRatRsrqSum,
                .sinrCount = MrSaAndNrdcMnA2ActivateInterRatSinrCount,
                .sinrSum = MrSaAndNrdcMnA2ActivateInterRatSinrSum,
                .purposeCount = MrSaAndNrdcMnA2ActivateInterRatCount,
            },
        .checkCallType = IsSaOrNrdcMn},
    {.reportType = measReport_A2,
        .reportPurpose = a2Purpose_blindInterRatRedirection,  // blind-inter-rat-redirection-purpose
        .mFamily = STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrSaAndNrdcMnA2BlindInterRatRedirectionRsrpCount,
                .rsrpSum = MrSaAndNrdcMnA2BlindInterRatRedirectionRsrpSum,
                .rsrqCount = MrSaAndNrdcMnA2BlindInterRatRedirectionRsrqCount,
                .rsrqSum = MrSaAndNrdcMnA2BlindInterRatRedirectionRsrqSum,
                .sinrCount = MrSaAndNrdcMnA2BlindInterRatRedirectionSinrCount,
                .sinrSum = MrSaAndNrdcMnA2BlindInterRatRedirectionSinrSum,
                .purposeCount = MrSaAndNrdcMnA2BlindInterRatRedirectionCount,
            },
        .checkCallType = IsSaOrNrdcMn},
    {.reportType = measReport_A2,
        .reportPurpose = a2Purpose_scellRelease,  // scell-release-purpose
        .mFamily = STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrSaAndNrdcMnA2ScellReleaseRsrpCount,
                .rsrpSum = MrSaAndNrdcMnA2ScellReleaseRsrpSum,
                .rsrqCount = MrSaAndNrdcMnA2ScellReleaseRsrqCount,
                .rsrqSum = MrSaAndNrdcMnA2ScellReleaseRsrqSum,
                .sinrCount = MrSaAndNrdcMnA2ScellReleaseSinrCount,
                .sinrSum = MrSaAndNrdcMnA2ScellReleaseSinrSum,
                .purposeCount = MrSaAndNrdcMnA2ScellReleaseCount,
            },
        .checkCallType = IsSaOrNrdcMn},
    // A3 cases
    {.reportType = measReport_A3,
        .reportPurpose = a3Purpose_intraNrHandover,  // intra-nr-handover-purpose
        .mFamily = STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrSaAndNrdcMnA3IntraNrHandoverRsrpCount,
                .rsrpSum = MrSaAndNrdcMnA3IntraNrHandoverRsrpSum,
                .rsrqCount = MrSaAndNrdcMnA3IntraNrHandoverRsrqCount,
                .rsrqSum = MrSaAndNrdcMnA3IntraNrHandoverRsrqSum,
                .sinrCount = MrSaAndNrdcMnA3IntraNrHandoverSinrCount,
                .sinrSum = MrSaAndNrdcMnA3IntraNrHandoverSinrSum,
                .purposeCount = MrSaAndNrdcMnA3IntraNrHandoverCount,
            },
        .checkCallType = IsSaOrNrdcMn},
    {.reportType = measReport_A3,
        .reportPurpose = a3Purpose_Comp,  // comp-purpose
        .mFamily = STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrSaAndNrdcMnA3CompRsrpCount,
                .rsrpSum = MrSaAndNrdcMnA3CompRsrpSum,
                .rsrqCount = MrSaAndNrdcMnA3CompRsrqCount,
                .rsrqSum = MrSaAndNrdcMnA3CompRsrqSum,
                .sinrCount = MrSaAndNrdcMnA3CompSinrCount,
                .sinrSum = MrSaAndNrdcMnA3CompSinrSum,
                .purposeCount = MrSaAndNrdcMnA3CompCount,
            },
        .checkCallType = IsSaOrNrdcMn},
    // A4 cases
    {.reportType = measReport_A4,
        .reportPurpose = a4Purpose_intraNrHandover,  // intra-nr-handover-purpose
        .mFamily = STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrSaAndNrdcMnA4IntraNrHandoverRsrpCount,
                .rsrpSum = MrSaAndNrdcMnA4IntraNrHandoverRsrpSum,
                .rsrqCount = MrSaAndNrdcMnA4IntraNrHandoverRsrqCount,
                .rsrqSum = MrSaAndNrdcMnA4IntraNrHandoverRsrqSum,
                .sinrCount = MrSaAndNrdcMnA4IntraNrHandoverSinrCount,
                .sinrSum = MrSaAndNrdcMnA4IntraNrHandoverSinrSum,
                .purposeCount = MrSaAndNrdcMnA4IntraNrHandoverCount,
            },
        .checkCallType = IsSaOrNrdcMn},
    {.reportType = measReport_A4,
        .reportPurpose = a4Purpose_NRLoadBalancing,  // load-balancing-intra-nr-purpose
        .mFamily = STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrSaAndNrdcMnA4LoadBalancingIntraNrRsrpCount,
                .rsrpSum = MrSaAndNrdcMnA4LoadBalancingIntraNrRsrpSum,
                .rsrqCount = MrSaAndNrdcMnA4LoadBalancingIntraNrRsrqCount,
                .rsrqSum = MrSaAndNrdcMnA4LoadBalancingIntraNrRsrqSum,
                .sinrCount = MrSaAndNrdcMnA4LoadBalancingIntraNrSinrCount,
                .sinrSum = MrSaAndNrdcMnA4LoadBalancingIntraNrSinrSum,
                .purposeCount = MrSaAndNrdcMnA4LoadBalancingIntraNrCount,
            },
        .checkCallType = IsSaOrNrdcMn},
    {.reportType = measReport_A4,
        .reportPurpose = a4Purpose_scellAddition,  // scell-addition-purpose
        .mFamily = STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrSaAndNrdcMnA4ScellAdditionRsrpCount,
                .rsrpSum = MrSaAndNrdcMnA4ScellAdditionRsrpSum,
                .rsrqCount = MrSaAndNrdcMnA4ScellAdditionRsrqCount,
                .rsrqSum = MrSaAndNrdcMnA4ScellAdditionRsrqSum,
                .sinrCount = MrSaAndNrdcMnA4ScellAdditionSinrCount,
                .sinrSum = MrSaAndNrdcMnA4ScellAdditionSinrSum,
                .purposeCount = MrSaAndNrdcMnA4ScellAdditionCount,
            },
        .checkCallType = IsSaOrNrdcMn},
    {.reportType = measReport_A4,
        .reportPurpose = a4Purpose_NrdcAddition,  // nr-dc-sn-addition-purpose
        .mFamily = STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrSaAndNrdcMnA4NrDcSnAdditionRsrpCount,
                .rsrpSum = MrSaAndNrdcMnA4NrDcSnAdditionRsrpSum,
                .rsrqCount = MrSaAndNrdcMnA4NrDcSnAdditionRsrqCount,
                .rsrqSum = MrSaAndNrdcMnA4NrDcSnAdditionRsrqSum,
                .sinrCount = MrSaAndNrdcMnA4NrDcSnAdditionSinrCount,
                .sinrSum = MrSaAndNrdcMnA4NrDcSnAdditionSinrSum,
                .purposeCount = MrSaAndNrdcMnA4NrDcSnAdditionCount,
            },
        .checkCallType = IsSaOrNrdcMn},
    // A5 cases
    {.reportType = measReport_A5,
        .reportPurpose = a5Purpose_intraNrHandover,  // intra-nr-handover-purpose
        .mFamily = STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrSaAndNrdcMnA5IntraNrHandoverRsrpCount,
                .rsrpSum = MrSaAndNrdcMnA5IntraNrHandoverRsrpSum,
                .rsrqCount = MrSaAndNrdcMnA5IntraNrHandoverRsrqCount,
                .rsrqSum = MrSaAndNrdcMnA5IntraNrHandoverRsrqSum,
                .sinrCount = MrSaAndNrdcMnA5IntraNrHandoverSinrCount,
                .sinrSum = MrSaAndNrdcMnA5IntraNrHandoverSinrSum,
                .purposeCount = MrSaAndNrdcMnA5IntraNrHandoverCount,
            },
        .checkCallType = IsSaOrNrdcMn},
    {.reportType = measReport_A5,
        .reportPurpose = a5Purpose_intraNrOnDemandHandover,  // intra-nr-on-demand-handover-purpose
        .mFamily = STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrSaAndNrdcMnA5IntraNrOnDemandHandoverRsrpCount,
                .rsrpSum = MrSaAndNrdcMnA5IntraNrOnDemandHandoverRsrpSum,
                .rsrqCount = MrSaAndNrdcMnA5IntraNrOnDemandHandoverRsrqCount,
                .rsrqSum = MrSaAndNrdcMnA5IntraNrOnDemandHandoverRsrqSum,
                .sinrCount = MrSaAndNrdcMnA5IntraNrOnDemandHandoverSinrCount,
                .sinrSum = MrSaAndNrdcMnA5IntraNrOnDemandHandoverSinrSum,
                .purposeCount = MrSaAndNrdcMnA5IntraNrOnDemandHandoverCount,
            },
        .checkCallType = IsSaOrNrdcMn},
    {.reportType = measReport_A5,
        .reportPurpose = a5Purpose_intraNrRfspHandover,  // intra-nr-rfsp-handover-purpose
        .mFamily = STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrSaAndNrdcMnA5IntraNrRfspHandoverRsrpCount,
                .rsrpSum = MrSaAndNrdcMnA5IntraNrRfspHandoverRsrpSum,
                .rsrqCount = MrSaAndNrdcMnA5IntraNrRfspHandoverRsrqCount,
                .rsrqSum = MrSaAndNrdcMnA5IntraNrRfspHandoverRsrqSum,
                .sinrCount = MrSaAndNrdcMnA5IntraNrRfspHandoverSinrCount,
                .sinrSum = MrSaAndNrdcMnA5IntraNrRfspHandoverSinrSum,
                .purposeCount = MrSaAndNrdcMnA5IntraNrRfspHandoverCount,
            },
        .checkCallType = IsSaOrNrdcMn},
    // Periodical cases
    {.reportType = measReport_periodical,
        .reportPurpose = periodicalPurpose_nrppa,  // periodical-purpose-nrppa
        .mFamily = STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrSaAndNrdcMnPeriodicNrppaRsrpCount,
                .rsrpSum = MrSaAndNrdcMnPeriodicNrppaRsrpSum,
                .rsrqCount = MrSaAndNrdcMnPeriodicNrppaRsrqCount,
                .rsrqSum = MrSaAndNrdcMnPeriodicNrppaRsrqSum,
                .sinrCount = MrSaAndNrdcMnPeriodicNrppaSinrCount,
                .sinrSum = MrSaAndNrdcMnPeriodicNrppaSinrSum,
                .purposeCount = MrSaAndNrdcMnPeriodicNrppaCount,
            },
        .checkCallType = IsSaOrNrdcMn},
    {.reportType = measReport_periodical,
        .reportPurpose = periodicalPurpose_ueMeasForSon,  // ue-meas-for-son-purpose
        .mFamily = STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrSaAndNrdcMnPeriodicUeMeasForSonRsrpCount,
                .rsrpSum = MrSaAndNrdcMnPeriodicUeMeasForSonRsrpSum,
                .rsrqCount = MrSaAndNrdcMnPeriodicUeMeasForSonRsrqCount,
                .rsrqSum = MrSaAndNrdcMnPeriodicUeMeasForSonRsrqSum,
                .sinrCount = MrSaAndNrdcMnPeriodicUeMeasForSonSinrCount,
                .sinrSum = MrSaAndNrdcMnPeriodicUeMeasForSonSinrSum,
                .purposeCount = MrSaAndNrdcMnPeriodicUeMeasForSonCount,
            },
        .checkCallType = IsSaOrNrdcMn},

    // STAT_MEAS_REPORT_NRDC_SN_SERVICE_TYPE FAMILY
    // A1 cases
    {.reportType = measReport_A1,
        .reportPurpose = a1Purpose_nrdcDeactivateInterFrequency,  // nr-dc-deactivate-inter-frequency-purpose
        .mFamily = STAT_MEAS_REPORT_NRDC_SN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrNrdcSnA1NrDcDeactivateInterFrequencyRsrpCount,
                .rsrpSum = MrNrdcSnA1NrDcDeactivateInterFrequencyRsrpSum,
                .rsrqCount = MrNrdcSnA1NrDcDeactivateInterFrequencyRsrqCount,
                .rsrqSum = MrNrdcSnA1NrDcDeactivateInterFrequencyRsrqSum,
                .sinrCount = MrNrdcSnA1NrDcDeactivateInterFrequencySinrCount,
                .sinrSum = MrNrdcSnA1NrDcDeactivateInterFrequencySinrSum,
                .purposeCount = MrNrdcSnA1NrDcDeactivateInterFrequencyCount,
            },
        .checkCallType = IsNrdcSn},
    {.reportType = measReport_A1,
        .reportPurpose =
            a1Purpose_nrdcInPScellUlCoverage_ueUlSplitSup,  // nr-dc-in-pscell-ul-coverage-ueulsplit-sup-purpose
        .mFamily = STAT_MEAS_REPORT_NRDC_SN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrNrdcSnA1NrDcInPscellUlCoverageUeUlSplitSupRsrpCount,
                .rsrpSum = MrNrdcSnA1NrDcInPscellUlCoverageUeUlSplitSupRsrpSum,
                .rsrqCount = MrNrdcSnA1NrDcInPscellUlCoverageUeUlSplitSupRsrqCount,
                .rsrqSum = MrNrdcSnA1NrDcInPscellUlCoverageUeUlSplitSupRsrqSum,
                .sinrCount = MrNrdcSnA1NrDcInPscellUlCoverageUeUlSplitSupSinrCount,
                .sinrSum = MrNrdcSnA1NrDcInPscellUlCoverageUeUlSplitSupSinrSum,
                .purposeCount = MrNrdcSnA1NrDcInPscellUlCoverageUeUlSplitSupCount,
            },
        .checkCallType = IsNrdcSn},
    // A2 cases
    {.reportType = measReport_A2,
        .reportPurpose = a2Purpose_nrdcActivateInterFrequency,  // nr-dc-activate-inter-frequency-purpose
        .mFamily = STAT_MEAS_REPORT_NRDC_SN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrNrdcSnA2NrDcActivateInterFrequencyRsrpCount,
                .rsrpSum = MrNrdcSnA2NrDcActivateInterFrequencyRsrpSum,
                .rsrqCount = MrNrdcSnA2NrDcActivateInterFrequencyRsrqCount,
                .rsrqSum = MrNrdcSnA2NrDcActivateInterFrequencyRsrqSum,
                .sinrCount = MrNrdcSnA2NrDcActivateInterFrequencySinrCount,
                .sinrSum = MrNrdcSnA2NrDcActivateInterFrequencySinrSum,
                .purposeCount = MrNrdcSnA2NrDcActivateInterFrequencyCount,
            },
        .checkCallType = IsNrdcSn},
    {.reportType = measReport_A2,
        .reportPurpose = a2Purpose_nrdcNRPSCellRelease,  // nr-dc-pscell-release-purpose
        .mFamily = STAT_MEAS_REPORT_NRDC_SN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrNrdcSnA2NrDcPscellReleaseRsrpCount,
                .rsrpSum = MrNrdcSnA2NrDcPscellReleaseRsrpSum,
                .rsrqCount = MrNrdcSnA2NrDcPscellReleaseRsrqCount,
                .rsrqSum = MrNrdcSnA2NrDcPscellReleaseRsrqSum,
                .sinrCount = MrNrdcSnA2NrDcPscellReleaseSinrCount,
                .sinrSum = MrNrdcSnA2NrDcPscellReleaseSinrSum,
                .purposeCount = MrNrdcSnA2NrDcPscellReleaseCount,
            },
        .checkCallType = IsNrdcSn},
    {.reportType = measReport_A2,
        .reportPurpose = a2Purpose_scellRelease,  // scell-release-purpose
        .mFamily = STAT_MEAS_REPORT_NRDC_SN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrNrdcSnA2ScellReleaseRsrpCount,
                .rsrpSum = MrNrdcSnA2ScellReleaseRsrpSum,
                .rsrqCount = MrNrdcSnA2ScellReleaseRsrqCount,
                .rsrqSum = MrNrdcSnA2ScellReleaseRsrqSum,
                .sinrCount = MrNrdcSnA2ScellReleaseSinrCount,
                .sinrSum = MrNrdcSnA2ScellReleaseSinrSum,
                .purposeCount = MrNrdcSnA2ScellReleaseCount,
            },
        .checkCallType = IsNrdcSn},
    {.reportType = measReport_A2,
        .reportPurpose =
            a2Purpose_nrdcOutOfPScellUlCoverage_ueUlSplitSup,  // nr-dc-out-of-pscell-ul-coverage-ueulsplit-sup-purpose
        .mFamily = STAT_MEAS_REPORT_NRDC_SN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrNrdcSnA2NrDcOutOfPscellUlCoverageUeUlSplitSupRsrpCount,
                .rsrpSum = MrNrdcSnA2NrDcOutOfPscellUlCoverageUeUlSplitSupRsrpSum,
                .rsrqCount = MrNrdcSnA2NrDcOutOfPscellUlCoverageUeUlSplitSupRsrqCount,
                .rsrqSum = MrNrdcSnA2NrDcOutOfPscellUlCoverageUeUlSplitSupRsrqSum,
                .sinrCount = MrNrdcSnA2NrDcOutOfPscellUlCoverageUeUlSplitSupSinrCount,
                .sinrSum = MrNrdcSnA2NrDcOutOfPscellUlCoverageUeUlSplitSupSinrSum,
                .purposeCount = MrNrdcSnA2NrDcOutOfPscellUlCoverageUeUlSplitSupCount,
            },
        .checkCallType = IsNrdcSn},
    // A3 cases
    {.reportType = measReport_A3,
        .reportPurpose = a3Purpose_nrdcNrPSCellChange,  // nr-dc-nr-pscell-change-purpose
        .mFamily = STAT_MEAS_REPORT_NRDC_SN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrNrdcSnA3NrDcNrPscellChangeRsrpCount,
                .rsrpSum = MrNrdcSnA3NrDcNrPscellChangeRsrpSum,
                .rsrqCount = MrNrdcSnA3NrDcNrPscellChangeRsrqCount,
                .rsrqSum = MrNrdcSnA3NrDcNrPscellChangeRsrqSum,
                .sinrCount = MrNrdcSnA3NrDcNrPscellChangeSinrCount,
                .sinrSum = MrNrdcSnA3NrDcNrPscellChangeSinrSum,
                .purposeCount = MrNrdcSnA3NrDcNrPscellChangeCount,
            },
        .checkCallType = IsNrdcSn},
    {.reportType = measReport_A3,
        .reportPurpose = a3Purpose_Comp,  // comp-purpose
        .mFamily = STAT_MEAS_REPORT_NRDC_SN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrNrdcSnA3CompRsrpCount,
                .rsrpSum = MrNrdcSnA3CompRsrpSum,
                .rsrqCount = MrNrdcSnA3CompRsrqCount,
                .rsrqSum = MrNrdcSnA3CompRsrqSum,
                .sinrCount = MrNrdcSnA3CompSinrCount,
                .sinrSum = MrNrdcSnA3CompSinrSum,
                .purposeCount = MrNrdcSnA3CompCount,
            },
        .checkCallType = IsNrdcSn},
    // A4 cases
    {.reportType = measReport_A4,
        .reportPurpose = a4Purpose_nrdcNrPSCellChange,  // nr-dc-nr-pscell-change-purpose
        .mFamily = STAT_MEAS_REPORT_NRDC_SN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrNrdcSnA4NrDcNrPscellChangeRsrpCount,
                .rsrpSum = MrNrdcSnA4NrDcNrPscellChangeRsrpSum,
                .rsrqCount = MrNrdcSnA4NrDcNrPscellChangeRsrqCount,
                .rsrqSum = MrNrdcSnA4NrDcNrPscellChangeRsrqSum,
                .sinrCount = MrNrdcSnA4NrDcNrPscellChangeSinrCount,
                .sinrSum = MrNrdcSnA4NrDcNrPscellChangeSinrSum,
                .purposeCount = MrNrdcSnA4NrDcNrPscellChangeCount,
            },
        .checkCallType = IsNrdcSn},
    {.reportType = measReport_A4,
        .reportPurpose = a4Purpose_scellAddition,  // scell-addition-purpose
        .mFamily = STAT_MEAS_REPORT_NRDC_SN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrNrdcSnA4ScellAdditionRsrpCount,
                .rsrpSum = MrNrdcSnA4ScellAdditionRsrpSum,
                .rsrqCount = MrNrdcSnA4ScellAdditionRsrqCount,
                .rsrqSum = MrNrdcSnA4ScellAdditionRsrqSum,
                .sinrCount = MrNrdcSnA4ScellAdditionSinrCount,
                .sinrSum = MrNrdcSnA4ScellAdditionSinrSum,
                .purposeCount = MrNrdcSnA4ScellAdditionCount,
            },
        .checkCallType = IsNrdcSn},
    // A5 cases
    {.reportType = measReport_A5,
        .reportPurpose = a5Purpose_nrdcNrPSCellChange,  // nr-dc-nr-pscell-change-purpose
        .mFamily = STAT_MEAS_REPORT_NRDC_SN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrNrdcSnA5NrDcNrPscellChangeRsrpCount,
                .rsrpSum = MrNrdcSnA5NrDcNrPscellChangeRsrpSum,
                .rsrqCount = MrNrdcSnA5NrDcNrPscellChangeRsrqCount,
                .rsrqSum = MrNrdcSnA5NrDcNrPscellChangeRsrqSum,
                .sinrCount = MrNrdcSnA5NrDcNrPscellChangeSinrCount,
                .sinrSum = MrNrdcSnA5NrDcNrPscellChangeSinrSum,
                .purposeCount = MrNrdcSnA5NrDcNrPscellChangeCount,
            },
        .checkCallType = IsNrdcSn},
    // Periodical cases
    {.reportType = measReport_periodical,
        .reportPurpose = periodicalPurpose_ueMeasForSon,  // ue-meas-for-son-purpose
        .mFamily = STAT_MEAS_REPORT_NRDC_SN_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrNrdcSnPeriodicUeMeasForSonRsrpCount,
                .rsrpSum = MrNrdcSnPeriodicUeMeasForSonRsrpSum,
                .rsrqCount = MrNrdcSnPeriodicUeMeasForSonRsrqCount,
                .rsrqSum = MrNrdcSnPeriodicUeMeasForSonRsrqSum,
                .sinrCount = MrNrdcSnPeriodicUeMeasForSonSinrCount,
                .sinrSum = MrNrdcSnPeriodicUeMeasForSonSinrSum,
                .purposeCount = MrNrdcSnPeriodicUeMeasForSonCount,
            },
        .checkCallType = IsNrdcSn},

    // STAT_MEAS_REPORT_EUTRA_SERVICE_TYPE FAMILY
    // B1 cases
    {.reportType = measReport_B1Eutra,
        .reportPurpose = b1Purpose_saPriortizationHandover,  // sa-prioritization-using-timer-purpose
        .mFamily = STAT_MEAS_REPORT_EUTRA_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrEutraB1SaPrioritizationUsingTimerRsrpCount,
                .rsrpSum = MrEutraB1SaPrioritizationUsingTimerRsrpSum,
                .rsrqCount = MrEutraB1SaPrioritizationUsingTimerRsrqCount,
                .rsrqSum = MrEutraB1SaPrioritizationUsingTimerRsrqSum,
                .sinrCount = MrEutraB1SaPrioritizationUsingTimerSinrCount,
                .sinrSum = MrEutraB1SaPrioritizationUsingTimerSinrSum,
                .purposeCount = MrEutraB1SaPrioritizationUsingTimerCount,
            },
        .checkCallType = AcceptAllCallTypes},
    {.reportType = measReport_B1Eutra,
        .reportPurpose = b1Purpose_eutraRfspHandover,  // eutra-rfsp-handover-purpose
        .mFamily = STAT_MEAS_REPORT_EUTRA_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrEutraB1EutraRfspHandoverRsrpCount,
                .rsrpSum = MrEutraB1EutraRfspHandoverRsrpSum,
                .rsrqCount = MrEutraB1EutraRfspHandoverRsrqCount,
                .rsrqSum = MrEutraB1EutraRfspHandoverRsrqSum,
                .sinrCount = MrEutraB1EutraRfspHandoverSinrCount,
                .sinrSum = MrEutraB1EutraRfspHandoverSinrSum,
                .purposeCount = MrEutraB1EutraRfspHandoverCount,
            },
        .checkCallType = AcceptAllCallTypes},
    {.reportType = measReport_B1Eutra,
        .reportPurpose = b1Purpose_saToNsaBorderHandover,  // sa-to-nsa-border-handover-purpose
        .mFamily = STAT_MEAS_REPORT_EUTRA_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrEutraB1SaToNsaBorderHandoverRsrpCount,
                .rsrpSum = MrEutraB1SaToNsaBorderHandoverRsrpSum,
                .rsrqCount = MrEutraB1SaToNsaBorderHandoverRsrqCount,
                .rsrqSum = MrEutraB1SaToNsaBorderHandoverRsrqSum,
                .sinrCount = MrEutraB1SaToNsaBorderHandoverSinrCount,
                .sinrSum = MrEutraB1SaToNsaBorderHandoverSinrSum,
                .purposeCount = MrEutraB1SaToNsaBorderHandoverCount,
            },
        .checkCallType = AcceptAllCallTypes},
    // B2 cases
    {.reportType = measReport_B2Eutra,
        .reportPurpose = b2Purpose_eutraHandover,  // eutra-handover-purpose
        .mFamily = STAT_MEAS_REPORT_EUTRA_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrEutraB2EutraHandoverRsrpCount,
                .rsrpSum = MrEutraB2EutraHandoverRsrpSum,
                .rsrqCount = MrEutraB2EutraHandoverRsrqCount,
                .rsrqSum = MrEutraB2EutraHandoverRsrqSum,
                .sinrCount = MrEutraB2EutraHandoverSinrCount,
                .sinrSum = MrEutraB2EutraHandoverSinrSum,
                .purposeCount = MrEutraB2EutraHandoverCount,
            },
        .checkCallType = AcceptAllCallTypes},
    {.reportType = measReport_B2Eutra,
        .reportPurpose = b2Purpose_saEpsFallbackHandover,  // eps-fallback-purpose
        .mFamily = STAT_MEAS_REPORT_EUTRA_SERVICE_TYPE,
        .stats =
            {
                .rsrpCount = MrEutraB2EpsFallbackRsrpCount,
                .rsrpSum = MrEutraB2EpsFallbackRsrpSum,
                .rsrqCount = MrEutraB2EpsFallbackRsrqCount,
                .rsrqSum = MrEutraB2EpsFallbackRsrqSum,
                .sinrCount = MrEutraB2EpsFallbackSinrCount,
                .sinrSum = MrEutraB2EpsFallbackSinrSum,
                .purposeCount = MrEutraB2EpsFallbackCount,
            },
        .checkCallType = AcceptAllCallTypes},

    // STAT_MEAS_REPORT_ENDC FAMILY
    // A1 cases
    {.reportType = measReport_A1,
        .reportPurpose = a1Purpose_deactivateInterFrequency,  // en-dc-deactivate-inter-frequency-purpose
        .mFamily = STAT_MEAS_REPORT_ENDC,
        .stats =
            {
                .rsrpCount = MrEndcA1EnDcDeactivateInterFrequencyRsrpCount,
                .rsrpSum = MrEndcA1EnDcDeactivateInterFrequencyRsrpSum,
                .rsrqCount = MrEndcA1EnDcDeactivateInterFrequencyRsrqCount,
                .rsrqSum = MrEndcA1EnDcDeactivateInterFrequencyRsrqSum,
                .sinrCount = MrEndcA1EnDcDeactivateInterFrequencySinrCount,
                .sinrSum = MrEndcA1EnDcDeactivateInterFrequencySinrSum,
                .purposeCount = MrEndcA1EnDcDeactivateInterFrequencyCount,
            },
        .checkCallType = IsEndc},
    {.reportType = measReport_A1,
        .reportPurpose = a1Purpose_FreqPrioScellToPScellSwitch,  // en-dc-fp-nr-scell-to-pscell-switch-purpose
        .mFamily = STAT_MEAS_REPORT_ENDC,
        .stats =
            {
                .rsrpCount = MrEndcA1EnDcFpNrScellToPscellSwitchRsrpCount,
                .rsrpSum = MrEndcA1EnDcFpNrScellToPscellSwitchRsrpSum,
                .rsrqCount = MrEndcA1EnDcFpNrScellToPscellSwitchRsrqCount,
                .rsrqSum = MrEndcA1EnDcFpNrScellToPscellSwitchRsrqSum,
                .sinrCount = MrEndcA1EnDcFpNrScellToPscellSwitchSinrCount,
                .sinrSum = MrEndcA1EnDcFpNrScellToPscellSwitchSinrSum,
                .purposeCount = MrEndcA1EnDcFpNrScellToPscellSwitchCount,
            },
        .checkCallType = IsEndc},
    {.reportType = measReport_A1,
        .reportPurpose = a1Purpose_inNRULCoverage_ueUlSplitSup,  // en-dc-in-nr-ul-coverage-ueulsplit-sup-purpose
        .mFamily = STAT_MEAS_REPORT_ENDC,
        .stats =
            {
                .rsrpCount = MrEndcA1EnDcInNrUlCoverageUeUlSplitSupRsrpCount,
                .rsrpSum = MrEndcA1EnDcInNrUlCoverageUeUlSplitSupRsrpSum,
                .rsrqCount = MrEndcA1EnDcInNrUlCoverageUeUlSplitSupRsrqCount,
                .rsrqSum = MrEndcA1EnDcInNrUlCoverageUeUlSplitSupRsrqSum,
                .sinrCount = MrEndcA1EnDcInNrUlCoverageUeUlSplitSupSinrCount,
                .sinrSum = MrEndcA1EnDcInNrUlCoverageUeUlSplitSupSinrSum,
                .purposeCount = MrEndcA1EnDcInNrUlCoverageUeUlSplitSupCount,
            },
        .checkCallType = IsEndc},
    // A2 cases
    {.reportType = measReport_A2,
        .reportPurpose = a2Purpose_activateInterFrequency,  // en-dc-activate-inter-frequency-purpose
        .mFamily = STAT_MEAS_REPORT_ENDC,
        .stats =
            {
                .rsrpCount = MrEndcA2EnDcActivateInterFrequencyRsrpCount,
                .rsrpSum = MrEndcA2EnDcActivateInterFrequencyRsrpSum,
                .rsrqCount = MrEndcA2EnDcActivateInterFrequencyRsrqCount,
                .rsrqSum = MrEndcA2EnDcActivateInterFrequencyRsrqSum,
                .sinrCount = MrEndcA2EnDcActivateInterFrequencySinrCount,
                .sinrSum = MrEndcA2EnDcActivateInterFrequencySinrSum,
                .purposeCount = MrEndcA2EnDcActivateInterFrequencyCount,
            },
        .checkCallType = IsEndc},
    {.reportType = measReport_A2,
        .reportPurpose = a2Purpose_NRPSCellRelease,  // en-dc-nr-pscell-release-purpose
        .mFamily = STAT_MEAS_REPORT_ENDC,
        .stats =
            {
                .rsrpCount = MrEndcA2EnDcNrPscellReleaseRsrpCount,
                .rsrpSum = MrEndcA2EnDcNrPscellReleaseRsrpSum,
                .rsrqCount = MrEndcA2EnDcNrPscellReleaseRsrqCount,
                .rsrqSum = MrEndcA2EnDcNrPscellReleaseRsrqSum,
                .sinrCount = MrEndcA2EnDcNrPscellReleaseSinrCount,
                .sinrSum = MrEndcA2EnDcNrPscellReleaseSinrSum,
                .purposeCount = MrEndcA2EnDcNrPscellReleaseCount,
            },
        .checkCallType = IsEndc},
    {.reportType = measReport_A2,
        .reportPurpose = a2Purpose_scellRelease,  // scell-release-purpose
        .mFamily = STAT_MEAS_REPORT_ENDC,
        .stats =
            {
                .rsrpCount = MrEndcA2ScellReleaseRsrpCount,
                .rsrpSum = MrEndcA2ScellReleaseRsrpSum,
                .rsrqCount = MrEndcA2ScellReleaseRsrqCount,
                .rsrqSum = MrEndcA2ScellReleaseRsrqSum,
                .sinrCount = MrEndcA2ScellReleaseSinrCount,
                .sinrSum = MrEndcA2ScellReleaseSinrSum,
                .purposeCount = MrEndcA2ScellReleaseCount,
            },
        .checkCallType = IsEndc},
    {.reportType = measReport_A2,
        .reportPurpose = a2Purpose_outOfNRULCoverage_ueUlSplitSup,  // en-dc-out-of-nr-ul-coverage-ueulsplit-sup-purpose
        .mFamily = STAT_MEAS_REPORT_ENDC,
        .stats =
            {
                .rsrpCount = MrEndcA2EnDcOutOfNrUlCoverageUeUlSplitSupRsrpCount,
                .rsrpSum = MrEndcA2EnDcOutOfNrUlCoverageUeUlSplitSupRsrpSum,
                .rsrqCount = MrEndcA2EnDcOutOfNrUlCoverageUeUlSplitSupRsrqCount,
                .rsrqSum = MrEndcA2EnDcOutOfNrUlCoverageUeUlSplitSupRsrqSum,
                .sinrCount = MrEndcA2EnDcOutOfNrUlCoverageUeUlSplitSupSinrCount,
                .sinrSum = MrEndcA2EnDcOutOfNrUlCoverageUeUlSplitSupSinrSum,
                .purposeCount = MrEndcA2EnDcOutOfNrUlCoverageUeUlSplitSupCount,
            },
        .checkCallType = IsEndc},
    // A3 cases
    {.reportType = measReport_A3,
        .reportPurpose = a3Purpose_NRPSCellChange,  // en-dc-nr-pscell-change-purpose
        .mFamily = STAT_MEAS_REPORT_ENDC,
        .stats =
            {
                .rsrpCount = MrEndcA3EnDcNrPscellChangeRsrpCount,
                .rsrpSum = MrEndcA3EnDcNrPscellChangeRsrpSum,
                .rsrqCount = MrEndcA3EnDcNrPscellChangeRsrqCount,
                .rsrqSum = MrEndcA3EnDcNrPscellChangeRsrqSum,
                .sinrCount = MrEndcA3EnDcNrPscellChangeSinrCount,
                .sinrSum = MrEndcA3EnDcNrPscellChangeSinrSum,
                .purposeCount = MrEndcA3EnDcNrPscellChangeCount,
            },
        .checkCallType = IsEndc},
    {.reportType = measReport_A3,
        .reportPurpose = a3Purpose_Comp,  // comp-purpose
        .mFamily = STAT_MEAS_REPORT_ENDC,
        .stats =
            {
                .rsrpCount = MrEndcA3CompRsrpCount,
                .rsrpSum = MrEndcA3CompRsrpSum,
                .rsrqCount = MrEndcA3CompRsrqCount,
                .rsrqSum = MrEndcA3CompRsrqSum,
                .sinrCount = MrEndcA3CompSinrCount,
                .sinrSum = MrEndcA3CompSinrSum,
                .purposeCount = MrEndcA3CompCount,
            },
        .checkCallType = IsEndc},
    // A4 cases
    {.reportType = measReport_A4,
        .reportPurpose = a4Purpose_NRPSCellChange,  // en-dc-nr-pscell-change-purpose
        .mFamily = STAT_MEAS_REPORT_ENDC,
        .stats =
            {
                .rsrpCount = MrEndcA4EnDcNrPscellChangeRsrpCount,
                .rsrpSum = MrEndcA4EnDcNrPscellChangeRsrpSum,
                .rsrqCount = MrEndcA4EnDcNrPscellChangeRsrqCount,
                .rsrqSum = MrEndcA4EnDcNrPscellChangeRsrqSum,
                .sinrCount = MrEndcA4EnDcNrPscellChangeSinrCount,
                .sinrSum = MrEndcA4EnDcNrPscellChangeSinrSum,
                .purposeCount = MrEndcA4EnDcNrPscellChangeCount,
            },
        .checkCallType = IsEndc},
    {.reportType = measReport_A4,
        .reportPurpose = a4Purpose_scellAddition,  // scell-addition-purpose
        .mFamily = STAT_MEAS_REPORT_ENDC,
        .stats =
            {
                .rsrpCount = MrEndcA4ScellAdditionRsrpCount,
                .rsrpSum = MrEndcA4ScellAdditionRsrpSum,
                .rsrqCount = MrEndcA4ScellAdditionRsrqCount,
                .rsrqSum = MrEndcA4ScellAdditionRsrqSum,
                .sinrCount = MrEndcA4ScellAdditionSinrCount,
                .sinrSum = MrEndcA4ScellAdditionSinrSum,
                .purposeCount = MrEndcA4ScellAdditionCount,
            },
        .checkCallType = IsEndc},
    {.reportType = measReport_A4,
        .reportPurpose = a4Purpose_SpidPrioPSCellChange,  // en-dc-spid-inter-frequency-nr-pscell-change-purpose
        .mFamily = STAT_MEAS_REPORT_ENDC,
        .stats =
            {
                .rsrpCount = MrEndcA4EnDcSpidInterFrequencyNrPscellChangeRsrpCount,
                .rsrpSum = MrEndcA4EnDcSpidInterFrequencyNrPscellChangeRsrpSum,
                .rsrqCount = MrEndcA4EnDcSpidInterFrequencyNrPscellChangeRsrqCount,
                .rsrqSum = MrEndcA4EnDcSpidInterFrequencyNrPscellChangeRsrqSum,
                .sinrCount = MrEndcA4EnDcSpidInterFrequencyNrPscellChangeSinrCount,
                .sinrSum = MrEndcA4EnDcSpidInterFrequencyNrPscellChangeSinrSum,
                .purposeCount = MrEndcA4EnDcSpidInterFrequencyNrPscellChangeCount,
            },
        .checkCallType = IsEndc},
    {.reportType = measReport_A4,
        .reportPurpose = a4Purpose_EndcLbPscellChange,  // en-dc-load-balancing-pscell-change-purpose
        .mFamily = STAT_MEAS_REPORT_ENDC,
        .stats =
            {
                .rsrpCount = MrEndcA4EnDcLoadBalancingPscellChangeRsrpCount,
                .rsrpSum = MrEndcA4EnDcLoadBalancingPscellChangeRsrpSum,
                .rsrqCount = MrEndcA4EnDcLoadBalancingPscellChangeRsrqCount,
                .rsrqSum = MrEndcA4EnDcLoadBalancingPscellChangeRsrqSum,
                .sinrCount = MrEndcA4EnDcLoadBalancingPscellChangeSinrCount,
                .sinrSum = MrEndcA4EnDcLoadBalancingPscellChangeSinrSum,
                .purposeCount = MrEndcA4EnDcLoadBalancingPscellChangeCount,
            },
        .checkCallType = IsEndc},
    // A5 cases
    {.reportType = measReport_A5,
        .reportPurpose = a5Purpose_FreqPrioPSCellChange,  // en-dc-fp-inter-frequency-nr-pscell-change-purpose
        .mFamily = STAT_MEAS_REPORT_ENDC,
        .stats =
            {
                .rsrpCount = MrEndcA5EnDcFpInterFrequencyNrPscellChangeRsrpCount,
                .rsrpSum = MrEndcA5EnDcFpInterFrequencyNrPscellChangeRsrpSum,
                .rsrqCount = MrEndcA5EnDcFpInterFrequencyNrPscellChangeRsrqCount,
                .rsrqSum = MrEndcA5EnDcFpInterFrequencyNrPscellChangeRsrqSum,
                .sinrCount = MrEndcA5EnDcFpInterFrequencyNrPscellChangeSinrCount,
                .sinrSum = MrEndcA5EnDcFpInterFrequencyNrPscellChangeSinrSum,
                .purposeCount = MrEndcA5EnDcFpInterFrequencyNrPscellChangeCount,
            },
        .checkCallType = IsEndc},
    {.reportType = measReport_A5,
        .reportPurpose = a5Purpose_NRPSCellChange,  // en-dc-nr-pscell-change-purpose
        .mFamily = STAT_MEAS_REPORT_ENDC,
        .stats =
            {
                .rsrpCount = MrEndcA5EnDcNrPscellChangeRsrpCount,
                .rsrpSum = MrEndcA5EnDcNrPscellChangeRsrpSum,
                .rsrqCount = MrEndcA5EnDcNrPscellChangeRsrqCount,
                .rsrqSum = MrEndcA5EnDcNrPscellChangeRsrqSum,
                .sinrCount = MrEndcA5EnDcNrPscellChangeSinrCount,
                .sinrSum = MrEndcA5EnDcNrPscellChangeSinrSum,
                .purposeCount = MrEndcA5EnDcNrPscellChangeCount,
            },
        .checkCallType = IsEndc},
    {.reportType = measReport_A5,
        .reportPurpose = a5Purpose_SpidPrioPSCellChange,  // en-dc-spid-inter-frequency-nr-pscell-change-purpose
        .mFamily = STAT_MEAS_REPORT_ENDC,
        .stats =
            {
                .rsrpCount = MrEndcA5EnDcSpidInterFrequencyNrPscellChangeRsrpCount,
                .rsrpSum = MrEndcA5EnDcSpidInterFrequencyNrPscellChangeRsrpSum,
                .rsrqCount = MrEndcA5EnDcSpidInterFrequencyNrPscellChangeRsrqCount,
                .rsrqSum = MrEndcA5EnDcSpidInterFrequencyNrPscellChangeRsrqSum,
                .sinrCount = MrEndcA5EnDcSpidInterFrequencyNrPscellChangeSinrCount,
                .sinrSum = MrEndcA5EnDcSpidInterFrequencyNrPscellChangeSinrSum,
                .purposeCount = MrEndcA5EnDcSpidInterFrequencyNrPscellChangeCount,
            },
        .checkCallType = IsEndc},
    {.reportType = measReport_A5,
        .reportPurpose = a5Purpose_EndcLbPscellChange,  // en-dc-load-balancing-pscell-change-purpose
        .mFamily = STAT_MEAS_REPORT_ENDC,
        .stats =
            {
                .rsrpCount = MrEndcA5EnDcLoadBalancingPscellChangeRsrpCount,
                .rsrpSum = MrEndcA5EnDcLoadBalancingPscellChangeRsrpSum,
                .rsrqCount = MrEndcA5EnDcLoadBalancingPscellChangeRsrqCount,
                .rsrqSum = MrEndcA5EnDcLoadBalancingPscellChangeRsrqSum,
                .sinrCount = MrEndcA5EnDcLoadBalancingPscellChangeSinrCount,
                .sinrSum = MrEndcA5EnDcLoadBalancingPscellChangeSinrSum,
                .purposeCount = MrEndcA5EnDcLoadBalancingPscellChangeCount,
            },
        .checkCallType = IsEndc},
    // Periodical cases
    {.reportType = measReport_periodical,
        .reportPurpose = periodicalPurpose_ueMeasForSon,  // ue-meas-for-son-purpose
        .mFamily = STAT_MEAS_REPORT_ENDC,
        .stats =
            {
                .rsrpCount = MrEndcPeriodicUeMeasForSonRsrpCount,
                .rsrpSum = MrEndcPeriodicUeMeasForSonRsrpSum,
                .rsrqCount = MrEndcPeriodicUeMeasForSonRsrqCount,
                .rsrqSum = MrEndcPeriodicUeMeasForSonRsrqSum,
                .sinrCount = MrEndcPeriodicUeMeasForSonSinrCount,
                .sinrSum = MrEndcPeriodicUeMeasForSonSinrSum,
                .purposeCount = MrEndcPeriodicUeMeasForSonCount,
            },
        .checkCallType = IsEndc},
};

inline bool VCCB_IsFamilyServiceType(const int mFamily)
{
    return (STAT_MEAS_REPORT_SA_AND_NRDC_MN_SERVICE_TYPE == mFamily) || (STAT_MEAS_REPORT_NRDC_SN_SERVICE_TYPE == mFamily) ||
           (STAT_MEAS_REPORT_EUTRA_SERVICE_TYPE == mFamily);
}

inline bool VCCB_IsFamilySPIDIncludingInvalid(const int mFamily)
{
    return (STAT_MEAS_REPORT_ENDC == mFamily);
}
