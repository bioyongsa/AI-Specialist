/****************************************************************
 * System      : 5G
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatMeasurementsNRRRCMake.hpp
 * Description :
 * Author      :
 * Dept.       :
 * Created     : 2022.06.23
 * Version     :
 * ****************************************************************/

#ifndef VCCB_VCCB_FEAT_FeatMeasurementsNRRRCMake_HPP_
#define VCCB_VCCB_FEAT_FeatMeasurementsNRRRCMake_HPP_

#include "VccbStruct.h"
#include "FeatMeasCommon.hpp"
#include "NRRRC.h"

int16_t VCCB_FillMeasConf(callInfo_type *ptCi, NRRRC_MeasConfig *pDst, const bool fullConfig);
int16_t VCCB_FillMeasConfDu(callInfo_type *ptCi, NRRRC_MeasConfig *pDst, const bool fullConfig);
int16_t VCCB_FillMeasConfigMN(callInfo_type *ptCi, NRRRC_MeasConfigMN *pDst);
int16_t VCCB_FillNRRRC_MeasConfigMN(
    callInfo_type *ptCi, NRRRC_MeasConfigMN *pTgt, measConfigMN_type *pSrc, bool setupFlag);
int16_t VCCB_Fill_SSB_MTC1(NRRRC_SSB_MTC *pDst, const smtc1_type *pSrc);
int16_t VCCB_FillMeasConfigSN_toMN(callInfo_type *ptCi, NRRRC_MeasConfigSN *pIE, uint16_t srcConfigFlag);
int16_t VCCB_GetCurrentMeasConfig(callInfo_type *ptCi, NRRRC_MeasConfig *pDst);
int16_t VCCB_CheckIfReportConfigChanged(const reportConfigurationInstalledUe_type *pInstalled, const reportConfigurationNewUe_type *pNew);

inline uint64_t VCCB_GetAllMeasObjectIdsToRemove(const callInfo_type &rCi)
{
    const measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(rCi);
    return (rMeasProc.measurementObjects.idsToRemove |
            rMeasProc.measurementObjects.foreignIdsToRemove);
}

smtc1_type FnVCCB_GetRrcMeasObjectNrSsbSmtc1(const minimalMeasObjectNRUe_type &rMeasObjectNrUe);
uint32_t FnVCCB_GetRrcMeasObjectNrSsbFrequency(const minimalMeasObjectNRUe_type &rMoCandidate);
uint8_t FnVCCB_GetRrcMeasObjectNrSsbScs(const minimalMeasObjectNRUe_type &rMeasObjectNrUe);

#endif
