/****************************************************************
 * System      : 5G gNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatTrafficMeasurements.cpp
 * Description : This file contains functions related to management of Traffic Measurements installed on AUPF
 *(gNB-CU-UP). Dept.       : 5G Call SW Lab. Created     : 2022.06.01
 ****************************************************************/

#include "FeatTrafficMeasurements.hpp"
#include "FeatHo.h"
#include "FeatMco.h"
#include "FeatMco.hpp"
#include "FeatMrdc.h"
#include "FeatCallInfo.h"

#include "CdbUtil.h"

#include "ComInclude.h"
#include "ComLibUtility.h"

#include "FeatCommon.h"

#include "StateCommon.h"
#include "StateMco.h"
#include "StateMeasurements.h"

#include "MsgE1apSend.h"

static trafficMeasReportCallbackMap_type gTrafficMeasReportCallbackTable[enumTraffciMeasReportCallbackId_MAX] = {};

/**
 * @brief       This function triggers E1ModificationRequest procedure for (re)configuration of traffic measurements on serving AUPFs.
 *              It can be used when related call flow scenario does not use E1ModificationRequest but there is a need for traffic measurement reconfiguration.
 *              It can be called direclty or via enqueue mechanism
 *              - [FGR-CC8001] DL PDCP traffic status monitoring control (NR)
 * @description Call state is changed to STATE_TrafficMeas_E1Mod and BearerContextModification message is send.
 *              When successful responses from all serving AUPFs are received Call state is change to Conn/DB
 * @param       ptCi  : call info DB
 * @param       enqueuedAction : when function is called via enqueue mechanism
 * @return      ERROR : can't send E1 BearerContextModificationRequest message
 * @return      GOOD  : send E1 BearerContextModificationRequest message
 */
int16_t VCCB_TriggerTrafficMeasurementReconfiguration(callInfo_type *ptCi, enqueuedAction)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    SET_STATE_CMD(TrfMeasCfg_cmd);
    VLIB_SetCurStateAll(ptCi, STATE_TrfMeasCfg_E1Mod);

    int16_t status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

    VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);

    return GOOD; 
}

/**
 * @brief       Intenral function to check if configuration of requested measurement exists in DB and get threshold
 * value
 * @details     [FGR-CC8001] DL PDCP traffic status monitoring control (NR)
 * @param[in]   ptCi        : pointer to call info
 * @param[in]   cellNum     : cell number
 * @param[in]   purpose     : measurement purpose
 * @param[in]   condition   : measurement condition (below/above)
 * @param[out]  pThreshold  : pointer to retrieved configured threshold
 * @return      GOOD        : Configuration exists and retrieved
 *              ERROR       : Configuration does not exists or retrieve error
 */
int16_t VCCB_GetTrafficMonitoringCfgDB(callInfo_type *ptCi, uint16_t cellNum, enumTrafficReportingPurpose_type purpose,
    enumTrafficReportingCondition_type condition, uint16_t *pThreshold)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pThreshold);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    VccbGnbInfo_type &rGnb = GNBINFO[ptCi->gnbNum];
    int16_t status = ERROR;

    // Check ENDC: mobility-config-gnb/pdcp-buffer-based-fr2-pscell-change separately
    if (TRAFFIC_BASED_ENDC_FR2_PS_CELL_CHANGE_purpose == purpose &&
        IS_PDCP_BUFFER_BASED_FR2_PSCELL_CHANGE_ENABLED(ptCi->gnbNum))
    {
        *pThreshold = rGnb.cfg.gnbMobilityConfig.pdcpBufferBasedFr2PSCellChange.threshold;
        return GOOD;
    }

    // Check traffic-monitoring-configuration
    for (const TrafficMonitoringCfgDb_type &trafficMonCfgDB : pCell->dlTrfStatusCfg)
    {
        if (trafficMonCfgDB.usage != CI_use || trafficMonCfgDB.purpose != purpose)
        {
            continue;
        }

        *pThreshold = THRESHOLD_ABOVE_condition == condition ? trafficMonCfgDB.thAbove : trafficMonCfgDB.thBelow;
        status = GOOD;
        break;
    }

    if (TRAFFIC_BASED_NR_TO_EUTRA_HO_purpose == purpose || TRAFFIC_BASED_MULTI_RAT_CARRIER_CHANGE_purpose == purpose)
    {
        // no need to check traffic-monitoring-configuration-rfsp
        return status;
    }

    if ((TRAFFIC_BASED_INTER_RAT_PCC_CHANGE_purpose == purpose) && (GOOD == status))
    {
        mcoIratPccConfig_type config = FnVCCB_GetCurrentInterRatPccChangeConfig(*ptCi, rGnb, *pCell);
        *pThreshold = config.dlTrafficThresholdForIratPccChg;
    }

    // Check traffic-monitoring-configuration-rfsp
    if ((ptCi->ueInfo.rfsp.rfspPresent == OPT_PRESENT) && (ptCi->ueInfo.rfsp.indexToRFSP > NO_RFSP_VALUE) &&  // 0
        (ptCi->ueInfo.rfsp.indexToRFSP <= MAX_RFSP_VALUE))                                                    // 256
    {
        uint8_t servPlmnIndex = VLIB_FindGnbPlmnIndexOfCall(ptCi);
        if (servPlmnIndex < MAX_PLMN_INDEX)
        {
            for (const TrafficMonitoringCfgRfspDb_type &trafficMonCfgRfspDB : pCell->trfMonitoringCfgRfsp)
            {
                if (trafficMonCfgRfspDB.usage != CI_use || trafficMonCfgRfspDB.plmnIndex != servPlmnIndex ||
                    trafficMonCfgRfspDB.rfsp != ptCi->ueInfo.rfsp.indexToRFSP || trafficMonCfgRfspDB.purpose != purpose)
                {
                    continue;
                }

                *pThreshold = trafficMonCfgRfspDB.threshold;
                status = GOOD;

                VCCB_PRINT_CALL_COMMENT(ptCi,
                    "[TRF MEAS] Applied RFSP(%u) based threshold value(%u) for traffic monitoring measurement "
                    "purpose(%u)\n",
                    ptCi->ueInfo.rfsp.indexToRFSP, *pThreshold, purpose);
                break;
            }
        }
    }

    return status;
}

/**
 * @brief       Intenral function to find existing/allocate new report configuration entry index for requested
 * measurement
 * @details     [FGR-CC8001] DL PDCP traffic status monitoring control (NR)
 * @param[in]   ptCi                    : pointer to call info
 * @param[in]   purpose                 : measurement purpose
 * @param[in]   condition               : measurement condition (below/above)
 * @param[in]   threshold               : threshold to set
 * @param[in]   startMonitoringThr      : threshold for statr trafic monitoring 
 * @return      reportEntryIdx          : index of existing/new report confding entry or MAX_TRF_MONITORING_CFG_PER_CALL in case
 * of failure
 */
static uint8_t VCCB_FindAllocReportCfgIndex(callInfo_type *ptCi, enumTrafficReportingPurpose_type purpose,
    enumTrafficReportingCondition_type condition, uint16_t threshold, uint16_t startMonitoringThr)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_TRF_MONITORING_CFG_PER_CALL);

    // Find existing entry by checking purpose and condition
    for (uint8_t loop = 0; loop < MAX_TRF_MONITORING_CFG_PER_CALL; ++loop)
    {
        if (CI_use == ptCi->trafficMonitoringCfg.trafficReportCfgList[loop].usage &&
            purpose == ptCi->trafficMonitoringCfg.trafficReportCfgList[loop].purpose &&
            condition == ptCi->trafficMonitoringCfg.trafficReportCfgList[loop].condition)
        {
            if (threshold != ptCi->trafficMonitoringCfg.trafficReportCfgList[loop].threshold)
            {
                // Threshold value for existing report configuration was modified
                for (TrafficReportCfgDrb_type &reportCfgDrb : ptCi->trafficMonitoringCfg.trafficReportDrbList)
                {
                    // Need to refresh related DRBs where this report was used
                    if (CI_use == reportCfgDrb.reportIdxList[loop].usage)
                    {
                        reportCfgDrb.isSameCfgFlag = FALSE;
                    }
                }
            }
            ptCi->trafficMonitoringCfg.trafficReportCfgList[loop].threshold = threshold;
            ptCi->trafficMonitoringCfg.trafficReportCfgList[loop].startMonitoringThr = startMonitoringThr;
            ptCi->trafficMonitoringCfg.trafficReportCfgList[loop].keepFlag = TRUE;
            return loop;
        }
    }

    // Allocate new entry
    ptCi->trafficMonitoringCfg.reportIdxAlloc =
        ptCi->trafficMonitoringCfg.reportIdxAlloc % MAX_TRF_MONITORING_CFG_PER_CALL;

    for (uint8_t loop = 0; loop < MAX_TRF_MONITORING_CFG_PER_CALL; ++loop)
    {
        TrafficReportCfg_type &reportCfg =
            ptCi->trafficMonitoringCfg.trafficReportCfgList[ptCi->trafficMonitoringCfg.reportIdxAlloc];

        if (CI_no_use == reportCfg.usage)
        {
            reportCfg.usage = CI_use;
            reportCfg.reportId = ptCi->trafficMonitoringCfg.reportIdxAlloc;
            reportCfg.reportId++;
            reportCfg.purpose = purpose;
            reportCfg.condition = condition;
            reportCfg.threshold = threshold;
            reportCfg.startMonitoringThr = startMonitoringThr;
            reportCfg.keepFlag = TRUE;

            return ptCi->trafficMonitoringCfg.reportIdxAlloc;
        }

        ptCi->trafficMonitoringCfg.reportIdxAlloc =
            (ptCi->trafficMonitoringCfg.reportIdxAlloc + 1U) % MAX_TRF_MONITORING_CFG_PER_CALL;
    }

    return MAX_TRF_MONITORING_CFG_PER_CALL;
}

/**
 * @brief       This function is used to register/install traffic monitoring measurements for given DRB on AUPF.
 * @details     [FGR-CC8001] DL PDCP traffic status monitoring control (NR)
 * @param[in]   ptCi        : pointer to call info
 * @param[in]   cellNum     : cell number
 * @param[in]   drbIdx      : DRB Idx
 * @param[in]   purpose     : measurement purpose
 * @param[in]   condition   : measurement condition (below/above)
 * @return      GOOD        : measurement addition success
 *              ERROR       : measurement addition failure
 */
VCCB_STATIC int16_t VCCB_AddTrafficMeasurement(callInfo_type *ptCi, uint16_t cellNum, uint8_t drbIdx,
    enumTrafficReportingPurpose_type purpose, enumTrafficReportingCondition_type condition,  uint16_t startMonitoringThr)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(drbIdx, MAX_DRB_PER_CALL);

    uint16_t threshold = 0;

    // Check if configuration of requested measurement exists in DB and get threshold value
    int16_t status = VCCB_GetTrafficMonitoringCfgDB(ptCi, cellNum, purpose, condition, &threshold);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status,
        "[TRF MEAS] VCCB_GetTrafficMonitoringCfgDB ERROR. SKIP Add meas purpose(%u) condition(%u) th(%u) drbIdx(%u)\n",
        purpose, condition, threshold, drbIdx);


    // Find existing/allocate new entry in Report ID table
    uint8_t reportCfgIdx = VCCB_FindAllocReportCfgIndex(ptCi, purpose, condition, threshold, startMonitoringThr);
    if (reportCfgIdx >= MAX_TRF_MONITORING_CFG_PER_CALL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "[TRF MEAS] VCCB_FindAllocReportCfgEntry Idx(%u) >= MAX(%u) ERROR. SKIP Add meas purpose(%u) condition(%u) "
            "th(%u) startMonitoringTh(%u) drbIdx(%u)\n",
            reportCfgIdx, MAX_TRF_MONITORING_CFG_PER_CALL, purpose, condition, threshold, startMonitoringThr, drbIdx);
        return ERROR;
    }

    // Add drb report configuration
    TrafficReportCfgDrb_type &reportCfgDrb = ptCi->trafficMonitoringCfg.trafficReportDrbList[drbIdx];
    if (CI_no_use == reportCfgDrb.reportIdxList[reportCfgIdx].usage)
    {
        reportCfgDrb.isSameCfgFlag = FALSE;
    }
    reportCfgDrb.reportIdxList[reportCfgIdx].usage = CI_use;
    reportCfgDrb.reportIdxList[reportCfgIdx].keepFlag = TRUE;

    VCCB_PRINT_CALL_COMMENT(ptCi,
        "[TRF MEAS] Added traffic monitoring measurement repIdx[%u] purpose(%u) condition(%u) th(%u) startMonitoringTh(%u) drbIdx(%u)\n",
        reportCfgIdx, purpose, condition, threshold, startMonitoringThr, drbIdx);

    return GOOD;
}

/**
 *  @brief: This function is to be used for SA
 */
void FnVCCB_InitTrfStatusRptCfgToBeRefreshedBitMapSA(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        return;
    }

    ptCi->trafficMonitoringCfg.toBeRefreshedBitMap.value = 0;
}

void FnVCCB_SetTrfStatusRptCfgToBeRefreshedBitMapSA(callInfo_type *ptCi)
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //This is to check whether toBeRefreshedBitMap.pduSessIdx or toBeRefreshedBitMap.drbIdx has a bitfield of a smaller size than MAX_PDU_SESS_PER_CALL or MAX_DRB_PER_CALL 
    //  at the compile stage due to the change of MAX_PDU_SESS_PER_CALL or MAX_DRB_PER_CALL.
    MACRO_STATIC_ASSERT(MAX_PDU_SESS_PER_CALL <= 16, "toBeRefreshedBitMap.pduSessIdx is too short");
    MACRO_STATIC_ASSERT(MAX_DRB_PER_CALL <= 16, "toBeRefreshedBitMap.drbIdx is too short");
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        return;
    }

    for (uint16_t drbIdx=0; drbIdx < MAX_DRB_PER_CALL; drbIdx++)
    {
        const auto& reportCfgDrb = ptCi->trafficMonitoringCfg.trafficReportDrbList[drbIdx];

        if (reportCfgDrb.isSameCfgFlag == TRUE) continue;

        callDRBInfo_type &rDrb = ptCi->drb[drbIdx];
        if (rDrb.usage != CI_use) continue;

        if (rDrb.drbStatus == S_Release || rDrb.drbStatus == S_FailToSetup || 
                rDrb.drbStatus == S_Null || rDrb.drbStatus == S_Null_Release)
        {
            continue;
        }

        uint16_t pduIdx = rDrb.pduIdxInCall;
        if (pduIdx >= MAX_PDU_SESS_PER_CALL) continue;

        if (ptCi->pduSess[pduIdx].usage != CI_use) continue;

        ptCi->trafficMonitoringCfg.toBeRefreshedBitMap.pduSessIdx |= static_cast<uint16_t>(1U << pduIdx);
        ptCi->trafficMonitoringCfg.toBeRefreshedBitMap.drbIdx |= static_cast<uint16_t>(1U << drbIdx);
    }

    if (DBG->flag.logSaTrfMon)//__VZW_25A_P1.2__
    {
        int trfRptCfgIdx = 0;
        for (TrafficReportCfg_type &reportCfg : ptCi->trafficMonitoringCfg.trafficReportCfgList)
        {
            if (reportCfg.usage == CI_no_use) continue;

            VCCB_PRINT_CALL_INFORMATIVE( ptCi, "trfRptCfg[%d]: purpose(%u) cond(%u) rptId(%u) th(%u) startMonTh(%u) kFlag(%u), isRptByAUPF(%u)\n", 
                    trfRptCfgIdx, reportCfg.purpose, reportCfg.condition, reportCfg.reportId, reportCfg.threshold, 
                    reportCfg.startMonitoringThr, reportCfg.keepFlag, reportCfg.isReportedByAUPF);
            trfRptCfgIdx++;
        }

        int trfRptDrbIdx = -1;
        for (TrafficReportCfgDrb_type &reportDrb : ptCi->trafficMonitoringCfg.trafficReportDrbList)
        {
            trfRptDrbIdx++;

            if (trfRptDrbIdx >= MAX_DRB_PER_CALL) break;

            callDRBInfo_type &rDrb = ptCi->drb[trfRptDrbIdx];

            if (rDrb.usage != CI_use)
            {
                continue;
            }

            VCCB_PRINT_CALL_INFORMATIVE( ptCi, "trfRptDrb[%d]: drbId(%u) drbStatus[%d] isSameCfgFlag(%u) \n", 
                    trfRptDrbIdx, rDrb.dRBId, rDrb.drbStatus, reportDrb.isSameCfgFlag);  

            for (uint8_t rptIdx = 0; rptIdx < MAX_TRF_MONITORING_CFG_PER_CALL; ++rptIdx)
            {
                if (reportDrb.reportIdxList[rptIdx].usage != CI_use)
                {
                    continue;
                }

                VCCB_PRINT_CALL_INFORMATIVE( ptCi, "> rptIdx[%d]: keepFlag(%u) isReportedByAUPF(%u) \n", 
                        rptIdx, reportDrb.reportIdxList[rptIdx].keepFlag, reportDrb.reportIdxList[rptIdx].isReportedByAUPF);  
            }
        }
    }
}

// This api shall be called if drb is released
void FnVCCB_InitTrafficReportDrbProperty(callInfo_type *ptCi, callDRBInfo_type *pDi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pDi);

    uint16_t drbIdx = static_cast<uint16_t>(pDi - ptCi->drb);
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdx, MAX_DRB_PER_CALL);

    TrafficReportCfgDrb_type &reportCfgDrb = ptCi->trafficMonitoringCfg.trafficReportDrbList[drbIdx];
    reportCfgDrb.isSameCfgFlag = TRUE;
    memset(reportCfgDrb.reportIdxList, 0, sizeof(reportCfgDrb.reportIdxList));
}
/**
 * @brief       This function is entry point for other features to register/install traffic monitoring measurements on
 * AUPF.
 * @details     [FGR-CC8001] DL PDCP traffic status monitoring control (NR)
 * @param[in]   ptCi        : pointer to call info
 */
void VCCB_SetTrafficMonitoringMeasurements(callInfo_type *ptCi)
{
    // To Add traffic monitoring measurement on AUPF, register below by using VCCB_AddTrafficMeasurement function
    // To Del traffic monitoring measurement on AUPF, do not register.
    //
    // Measurements management Flow:
    // 1)   E1BearerContextSetup or E1BearerModification procedure triggered by other feature.
    // 2)   VCCB_SetTrafficMonitoringMeasurements(ptCi)
    // 2.1) - Use  VCCB_AddTrafficMeasurement API -- to add/keep related measurement on AUPF
    // 2.2) - Skip VCCB_AddTrafficMeasurement API -- to remove  existing measurement on AUPF
    // 3)   E1 Message sent. Configuration saved locally
    // 4)   Goto #1 according to other feature flow.
    //
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    int16_t status = GOOD;
    bool mrsTriggerFlag = false;
    uint16_t cellNum = ptCi->servCellNum;

    uint16_t startMonitoringNotUsed = std::numeric_limits<uint16_t>::max();
    uint16_t stratMonitoringThreshold = startMonitoringNotUsed;
    // During Intra-gNB HO after NR RRCRconfigComplete select proper serving cell for UP operation
    if (  // NSA states
        (STATE_DCIntraDuHo_RRCRecCmpl == ptCi->state) || (STATE_DCIntraDuHo_X2RecCmpl == ptCi->state) ||
        (STATE_DCIntraDuHo_X2SnStatus == ptCi->state) || (STATE_DCIntraDuHo_X2ModCnf == ptCi->state) ||
        (STATE_DCInterDuHo_RRCRecCmpl == ptCi->state) || (STATE_DCInterDuHo_X2RecCmpl == ptCi->state) ||
        (STATE_DCInterDuHo_X2SnStatus == ptCi->state) || (STATE_DCInterDuHo_X2ModCnf == ptCi->state) ||
        (STATE_DCNonDuHo_X2SnStatus == ptCi->state) || (STATE_DCNonDuHo_X2RecCmpl == ptCi->state) ||
         // SA states
        (STATE_INTRA_DU_Complete == ptCi->state) || (STATE_INTER_DU_Complete == ptCi->state) ||
        (STATE_SN_INTRA_DU_Complete == ptCi->state) || (STATE_SN_INTER_DU_Complete == ptCi->state))
    {
        cellNum = ptCi->hoInfo.targetCellNum;
    }
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    // Initialize flags
    FnVCCB_InitTrfStatusRptCfgToBeRefreshedBitMapSA(ptCi);

    for (TrafficReportCfg_type &reportCfg : ptCi->trafficMonitoringCfg.trafficReportCfgList)
    {
        reportCfg.isReportedByAUPF = FALSE;
    }

    for (TrafficReportCfgDrb_type &reportCfgDrb : ptCi->trafficMonitoringCfg.trafficReportDrbList)
    {
        reportCfgDrb.isSameCfgFlag = TRUE;

        for (TrafficReportCfgDrb_type::ReportCfgPerDRB_s &reportPerDrb : reportCfgDrb.reportIdxList)
        {
            reportPerDrb.keepFlag = FALSE;
            reportPerDrb.isReportedByAUPF = FALSE;
        }
    }

    // Add measurements per DRB
    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        for (uint8_t drbIdx = 0; drbIdx < MAX_ERAB_PER_CALL; ++drbIdx)
        {
            const callERABInfo_type &erabInfo = ptCi->erabInfo[drbIdx];

            if (CI_use != erabInfo.usage)
            {
                continue;
            }

            // Add your measurement below

            // pdcp-buffer-based-fr2-pscell-change purpose
            if (TRUE == VLIB_IsPdcpBufBasedFr2PscellChgSatisfied(ptCi))
            {
                status = VCCB_AddTrafficMeasurement(
                    ptCi, cellNum, drbIdx, TRAFFIC_BASED_ENDC_FR2_PS_CELL_CHANGE_purpose, THRESHOLD_ABOVE_condition,startMonitoringNotUsed);
                if (ERROR == status)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi,
                        "[TRF MEAS] VCCB_AddTrafficMeasurement ERROR drbIdx:%u pupose:%u condition:%u\n", drbIdx,
                        TRAFFIC_BASED_ENDC_FR2_PS_CELL_CHANGE_purpose, THRESHOLD_ABOVE_condition);
                }

                status = VCCB_AddTrafficMeasurement(
                    ptCi, cellNum, drbIdx, TRAFFIC_BASED_ENDC_FR2_PS_CELL_CHANGE_purpose, THRESHOLD_BELOW_condition,startMonitoringNotUsed);
                if (ERROR == status)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi,
                        "[TRF MEAS] VCCB_AddTrafficMeasurement ERROR drbIdx:%u pupose:%u condition:%u\n", drbIdx,
                        TRAFFIC_BASED_ENDC_FR2_PS_CELL_CHANGE_purpose, THRESHOLD_BELOW_condition);
                }
            }

            // Add your measurement above
        }
    }
    else  // SA
    {
        if (STATE_INTRA_DU_Cancel == ptCi->state)
        {
            if(MRS_TRAFFIC_MEAS == ptCi->prevMrsInfo.mrsState || MRS_TRAFFIC_WAIT == ptCi->prevMrsInfo.mrsState)
            {
                mrsTriggerFlag = true;
            }
        }
        else
        {
            if(MRS_TRAFFIC_MEAS == ptCi->mrsInfo.mrsState || MRS_TRAFFIC_WAIT == ptCi->mrsInfo.mrsState)
            {
                mrsTriggerFlag = true;
            }
        }

        if (mrsTriggerFlag == true)
        {
            mrsTriggerFlag = FnVCCB_CheckMultiRatSelection(ptCi, false);
            if(true != mrsTriggerFlag)
            {
                FnVCCB_InitMrsInfo(ptCi, MRS_ALL_INIT);
            }
            VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] mrsTriggerFlag %d !! :: %s \n", mrsTriggerFlag, __FUNCTION__);
        }

        int isFeasibleDlTrfStatusRptCfg = FnVCCB_CommonCheckTrfStatusRptCfgforNrdc(ptCi, cellNum);
        int isFeasibleNrToEutraHo = FnVCCB_CheckCommonDlTrfStatusRptCfgforNrToEutraHo(ptCi, cellNum);
        uint16_t measureCntForNrToEutraHo = 0;

        for (uint8_t drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; ++drbIdx)
        {
            callDRBInfo_type &drb = ptCi->drb[drbIdx];

            if (CI_use != drb.usage)
            {
                continue;
            }

            if (drb.drbStatus == S_Release || drb.drbStatus == S_FailToSetup || 
                    drb.drbStatus == S_Null || drb.drbStatus == S_Null_Release)
            {
                continue;
            }
            // Add your measurement below

            // nr-dc-traffic-based-addition purpose
            if (GOOD == isFeasibleDlTrfStatusRptCfg &&
                GOOD == FnVCCB_NeedToDlTrfStatusRptCfgforNrdcAddPerDRB(ptCi, &drb))
            {
                status = VCCB_AddTrafficMeasurement(
                    ptCi, cellNum, drbIdx, NRDC_TRAFFIC_BASED_ADDITION_purpose, THRESHOLD_ABOVE_condition,startMonitoringNotUsed);
                if (ERROR == status)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi,
                        "[TRF MEAS] VCCB_AddTrafficMeasurement ERROR drbIdx:%u pupose:%u condition:%u\n", drbIdx,
                        NRDC_TRAFFIC_BASED_ADDITION_purpose, THRESHOLD_ABOVE_condition);
                }
            }

            // traffic-based-multi-rat-carrier-change purpose
            if(true == mrsTriggerFlag)
            {
                if (GOOD == FnVCCB_NeedToDlTrfStatusRptCfgforMrsAddPerDRB(ptCi, &drb, false, cellNum))
                {
                    status = VCCB_AddTrafficMeasurement(
                        ptCi, cellNum, drbIdx, TRAFFIC_BASED_MULTI_RAT_CARRIER_CHANGE_purpose, THRESHOLD_ABOVE_condition,startMonitoringNotUsed);
                    if (ERROR == status)
                    {
                        VCCB_PRINT_CALL_ERROR(ptCi, "[MRS] VCCB_AddTrafficMeasurement ERROR drbIdx:%u pupose:%u condition:%u :: %s \n",
                                drbIdx, TRAFFIC_BASED_MULTI_RAT_CARRIER_CHANGE_purpose, THRESHOLD_ABOVE_condition, __FUNCTION__);
                    }
                    else // GOOD
                    {
                        SET_MRS_STATE(ptCi, MRS_TRAFFIC_WAIT);
                        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] Add to Traffic Measure for MRS Success drbIdx:%u pupose:%u condition:%u :: %s \n",
                                drbIdx, TRAFFIC_BASED_MULTI_RAT_CARRIER_CHANGE_purpose, THRESHOLD_ABOVE_condition, __FUNCTION__);
                    }
                }
            }

            // traffic-based-nr-to-eutra-handover purpose
            if (GOOD == isFeasibleNrToEutraHo && 
                GOOD == FnVCCB_NeedToDlTrfStatusRptCfgforNrToEutraHoAddPerDRB(ptCi, &drb, false))
            {
                measureCntForNrToEutraHo++;

                status = VCCB_AddTrafficMeasurement(
                    ptCi, cellNum, drbIdx, TRAFFIC_BASED_NR_TO_EUTRA_HO_purpose, THRESHOLD_ABOVE_condition,startMonitoringNotUsed);
                if (ERROR == status)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi,
                        "[TRF MEAS][TRF_HO] VCCB_AddTrafficMeasurement ERROR drbIdx:%u dRBId:%u TRAFFIC_BASED_NR_TO_EUTRA_HO THRESHOLD_ABOVE\n",
                        drbIdx, drb.dRBId);
                }
                else
                {
                    VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi,
                        "[TRF_HO] AddTrafficMeasurement drbIdx:%u dRBId:%u TRAFFIC_BASED_NR_TO_EUTRA_HO, THRESHOLD_ABOVE\n",
                        drbIdx, drb.dRBId);
                }

                status = VCCB_GetTrafficMonitoringCfgDB(ptCi, cellNum, TRAFFIC_BASED_NR_TO_EUTRA_HO_purpose,THRESHOLD_ABOVE_condition,
                &stratMonitoringThreshold);
                if (ERROR == status)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi,
                            "[TRF MEAS][TRF_HO] VCCB_GetTrafficMonitoringCfgDB ERROR drbIdx:%u dRBId:%u TRAFFIC_BASED_NR_TO_EUTRA_HO THRESHOLD_ABOVE\n",
                        drbIdx, drb.dRBId);
                }
                
                status = VCCB_AddTrafficMeasurement(
                    ptCi, cellNum, drbIdx, TRAFFIC_BASED_NR_TO_EUTRA_HO_purpose, THRESHOLD_BELOW_condition, stratMonitoringThreshold);
                if (ERROR == status)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi,
                        "[TRF MEAS][TRF_HO] VCCB_AddTrafficMeasurement ERROR drbIdx:%u dRBId:%u TRAFFIC_BASED_NR_TO_EUTRA_HO THRESHOLD_BELOW\n",
                        drbIdx, drb.dRBId);
                }
                else
                {
                    VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi,
                        "[TRF_HO] AddTrafficMeasurement drbIdx:%u dRBId:%u TRAFFIC_BASED_NR_TO_EUTRA_HO, THRESHOLD_BELOW\n",
                        drbIdx, drb.dRBId);
                }
            }

            // traffic-based-inter-rat-pcc-change purpose
            if (GOOD == FnVCCB_McoNeedToDlTrfStatusRptCfgForInterRatPccChange(ptCi))
            {
                status = VCCB_AddTrafficMeasurement(
                    ptCi, cellNum, drbIdx, TRAFFIC_BASED_INTER_RAT_PCC_CHANGE_purpose, THRESHOLD_ABOVE_condition,startMonitoringNotUsed);
                if (ERROR == status)
                {
                    SET_IRATPCC_STATE(ptCi, IRatPCCState_Gathering);
                    VCCB_PRINT_CALL_ERROR(ptCi,
                        "[TRF MEAS][IRAT PCC] VCCB_AddTrafficMeasurement ERROR drbIdx:%u purpose:%u condition:%u\n", drbIdx,
                        TRAFFIC_BASED_INTER_RAT_PCC_CHANGE_purpose, THRESHOLD_ABOVE_condition);
                    VCCB_PRINT_CALL_ERROR(ptCi,
                        "[IRAT PCC] Skipping Traffic Check due to VCCB_AddTrafficMeasurement failure\n");
                }
            }
            
            // Add your measurement above
        }

        // Reset in traffic-based-nr-to-eutra-handover purpose
        if (!measureCntForNrToEutraHo) 
        {
            if (ptCi->trafficMonitoringState.TrfBasedNrToEutraHoFlag) // Received traffic monitoring report
            {
                VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi, "[TRF_HO] Terminate traffic monitoring and UE measurement \n");
            }
            ptCi->trafficMonitoringState.TrfBasedNrToEutraHoFlag = VCCB_FLAG_OFF; 
        }
    }

    // Merge old and new configuration
    for (TrafficReportCfgDrb_type &reportCfgDrb : ptCi->trafficMonitoringCfg.trafficReportDrbList)
    {
        for (TrafficReportCfgDrb_type::ReportCfgPerDRB_s &reportPerDrb : reportCfgDrb.reportIdxList)
        {
            if (CI_use != reportPerDrb.usage)
            {
                continue;
            }

            if (FALSE == reportPerDrb.keepFlag)
            {
                reportPerDrb.usage = CI_no_use;
                reportCfgDrb.isSameCfgFlag = FALSE;
            }
        }
    }

    FnVCCB_SetTrfStatusRptCfgToBeRefreshedBitMapSA(ptCi);
}

int16_t FnVCCB_ProcUlTrafficStatusReportForNrdc(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    // SVR22C2 FGR-CC5203 FR111
    if (NOT_ALLOW_SN_ADDITION_UE_SIGNATURE(ptCi))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "not allowed by ue-signature in %s. ueSignature(%d) allowSnAdditionFlag(%d)\n",
            __func__, ptCi->nrdcScgFailureInfo.ueSignatureFlag,
            ptCi->nrdcScgFailureInfo.allowSNAdditionUECustomSignature);
        return BREAK;
    }

    if (FnVCCB_IsNrdcProhibitedByLtmHO(*ptCi, FnVCCB_GetCellSelectionForConfig(ptCi).bandNr))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "NR-DC is prohibited due to LTM-UE in %s!!!\n", __func__);
        return BREAK;
    }

    if (ERROR == FnVCCB_EnqueueActionTrafficStatusReportForNrdc(ptCi, TRF_STATUS_RPT_UL))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_EnqueueActionTrafficStatusReportForNrdc(TRF_STATUS_RPT_UL) ERROR!!\n");
        return BREAK;
    }

    return GOOD;
}

int16_t FnVCCB_ProcDlTrafficStatusReportForNrdc(callInfo_type *ptCi, struct E1_PrivateMessage *pMsg, uint8_t reportIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMsg);
    VCCB_CHECK_E_RANGE_AND_RETURN(reportIdx, MAX_TRF_MONITORING_CFG_PER_CALL);

    // SVR22C2 FGR-CC5203 FR111
    if (NOT_ALLOW_SN_ADDITION_UE_SIGNATURE(ptCi))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "not allowed by ue-signature in %s. ueSignature(%d) allowSnAdditionFlag(%d)\n",
            __func__, ptCi->nrdcScgFailureInfo.ueSignatureFlag,
            ptCi->nrdcScgFailureInfo.allowSNAdditionUECustomSignature);
        return BREAK;
    }

    if (FnVCCB_IsNrdcProhibitedByLtmHO(*ptCi, FnVCCB_GetCellSelectionForConfig(ptCi).bandNr))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "NR-DC is prohibited due to LTM-UE in %s!!!\n", __func__);
        return BREAK;
    }

    uint8_t drbIdx;
    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; ++drbIdx)
    {
        callDRBInfo_type *pDrb = &ptCi->drb[drbIdx];
        TrafficReportCfgDrb_type &reportCfgPerDrb = ptCi->trafficMonitoringCfg.trafficReportDrbList[drbIdx];

        if (CI_use != pDrb->usage || TRUE != reportCfgPerDrb.reportIdxList[reportIdx].isReportedByAUPF)
        {
            continue;
        }

        if (!IS_NRDC_BEARER(pDrb))
        {
            continue;
        }
        break;
    }

    if (drbIdx >= MAX_DRB_PER_SA_CALL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "can't find proper drbId for reportIdx(%u) in %s!\n", reportIdx, __func__);
        return BREAK;
    }

    if (ERROR == FnVCCB_EnqueueActionTrafficStatusReportForNrdc(ptCi, TRF_STATUS_RPT_DL))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_EnqueueActionTrafficStatusReportForNrdc(TRF_STATUS_RPT_DL) ERROR!!\n");
        return BREAK;
    }

    return GOOD;
}

int16_t FnVCCB_HandleTrafficStatusReportForNrdc(callInfo_type *ptCi, enqueuedAction action)
{
    // This api will be called by dequeuing operation only if state is Conn.
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_PRINT_CALL_DATA(ptCi, "deQueuing %s !!\n", queueingActionToStr(action));

    uint16_t cellNum = ptCi->servCellNum;

    if (!IS_SELECTED_MRDC(MRDC_NRDC))  // might be changed during mobility
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not SELECTED NRDC in %s!!\n", __func__);
        return BREAK;
    }

    if (!IS_SUPPORT_NRDC(ptCi, cellNum))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not support NR-DC cellNum(%u)!\n", cellNum);
        return BREAK;
    }

    if (!VCCB_TRAFFIC_BASED_NRDC_ADD_MODE(ptCi, cellNum))  // might be changed during mobility
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Neither Nrdc OprMod3 nor OprMod4 in %s!!\n", __func__);
        return BREAK;
    }

    if (IS_NRDC(ptCi))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Already NR-DC Connected or In Progress in %s!!\n", __func__);
        return BREAK;
    }

    if (!FnVCCB_IsAnyNrdcBearer(ptCi))  // might be changed if there has been the release of pduSession
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not FnVCCB_IsAnyNrdcBearer in %s!!\n", __func__);
        return BREAK;
    }

    if (action == ENQUEUE_ACTION_DL_TRAFFIC_STATUS_REPORT_FOR_NRDC)
    {
        ON_RCV_DlTrfStatusRptForNrdcAddition(ptCi);
        VCCB_PRINT_CALL_DATA(ptCi, "ON_RCV_DlTrfStatusRptforNrdcAddition in %s!!\n", __func__);
    }
    else if (action == ENQUEUE_ACTION_UL_TRAFFIC_STATUS_REPORT_FOR_NRDC)
    {
        ON_RCV_UlTrfStatusRptForNrdcAddition(ptCi);
        VCCB_PRINT_CALL_DATA(ptCi, "ON_RCV_UlTrfStatusRptforNrdcAddition in %s!!\n", __func__);
    }
    else
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid action(%d,%s) in %s!!\n", action, queueingActionToStr(action), __func__);
        return ERROR;
    }

    if (FnVCCB_CheckNrdcMode(*ptCi, cellNum, NRDC_MODE4_TRAFFIC_MR_BASED_MODE))
    {
        if (ERROR != VCCB_FindInstalledMeasId_ByFreqReportPurpose(ptCi, 0, measReport_A4, a4Purpose_NrdcAddition))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "A4 MeasCfg for nrdc-addition is already installed in %s!!\n", __func__);
            return BREAK;
        }

        if (ERROR == VCCM_EnqueueActionMeasReconfig(ptCi, MeasReconfigPriorAction_Full))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_EnqueueActionMeasReconfig in %s ERROR!\n", __func__);
            return BREAK;
        }
        VCCB_PRINT_CALL_DATA(ptCi, "VCCM_EnqueueActionMeasReconfig in %s!!\n", __func__);
    }

    return GOOD;
}

/**
 *  @brief This function initialize gTrafficReportCallbackTable. It shall be called during block initialization.
 */
void VCCB_InitTrafficMeasReportCallbackTable()
{
#define INIT_TRAFFIC_MEASREPORTCALLBACKTABLE_ENTRY(__func, __purpose)                                \
    gTrafficMeasReportCallbackTable[FUN_2_TRAFFIC_MEASREPORTCALLBACKID(__func)].callback = (__func); \
    gTrafficMeasReportCallbackTable[FUN_2_TRAFFIC_MEASREPORTCALLBACKID(__func)].purpose = (__purpose);

    INIT_TRAFFIC_MEASREPORTCALLBACKTABLE_ENTRY(
        VCCM_ProcReportEnDcTrafficBasedPsCellChange, TRAFFIC_BASED_ENDC_FR2_PS_CELL_CHANGE_purpose);
    INIT_TRAFFIC_MEASREPORTCALLBACKTABLE_ENTRY(
        FnVCCB_ProcDlTrafficStatusReportForNrdc, NRDC_TRAFFIC_BASED_ADDITION_purpose);
    INIT_TRAFFIC_MEASREPORTCALLBACKTABLE_ENTRY(
        FnVCCB_ProcReportTrafficBasedNrToEutraHandover, TRAFFIC_BASED_NR_TO_EUTRA_HO_purpose);
    INIT_TRAFFIC_MEASREPORTCALLBACKTABLE_ENTRY(
        FnVCCB_ProcReportTrafficBasedInterRatPccChange, TRAFFIC_BASED_INTER_RAT_PCC_CHANGE_purpose);
    INIT_TRAFFIC_MEASREPORTCALLBACKTABLE_ENTRY(
        FnVCCB_ProcReportTrafficBasedMrs, TRAFFIC_BASED_MULTI_RAT_CARRIER_CHANGE_purpose);

    // Initialize your callback here
}

/**
 * @brief       Proccess Traffic Monitoring Report from AUPF and all realted callback functions
 * @details     [FGR-CC8001] DL PDCP traffic status monitoring control (NR)
 * @param[in]   ptCi  : call information
 * @param[in]   ptMsg : received E1 message (if need to access raw data)
 * @return      GOOD  : processing success
 *              ERROR : processing failure
 */
int16_t VCCM_ProcE1PrivateMessage(callInfo_type *ptCi, struct E1_PrivateMessage *pMsg)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMsg);

    // Find related Report Configurations based on AUPF report and trigger callbacks
    for (uint8_t idx = 0; idx < MAX_TRF_MONITORING_CFG_PER_CALL; ++idx)
    {
        if (CI_use == ptCi->trafficMonitoringCfg.trafficReportCfgList[idx].usage &&
            TRUE == ptCi->trafficMonitoringCfg.trafficReportCfgList[idx].isReportedByAUPF)
        {
            for (trafficMeasReportCallbackMap_type &callbackMap : gTrafficMeasReportCallbackTable)
            {
                if (callbackMap.purpose == ptCi->trafficMonitoringCfg.trafficReportCfgList[idx].purpose)
                {
                    if (nullptr == callbackMap.callback)
                    {
                        VCCB_RETURN_ON_CALL_ERROR(ptCi, ERROR,
                            "Callback not registered in callbackMap (reportIdx:%u, purpose:%u condition:%u) - ERROR!\n",
                            idx, ptCi->trafficMonitoringCfg.trafficReportCfgList[idx].purpose,
                            ptCi->trafficMonitoringCfg.trafficReportCfgList[idx].condition);
                    }
                    else
                    {
                        int16_t status = callbackMap.callback(ptCi, pMsg, idx);
                        VCCB_RETURN_ON_CALL_ERROR(ptCi, status,
                            "callbackMap.callback(ptCi, pMsg, reportIdx:%u) ERROR. purpose:%u condition:%u\n", idx,
                            ptCi->trafficMonitoringCfg.trafficReportCfgList[idx].purpose,
                            ptCi->trafficMonitoringCfg.trafficReportCfgList[idx].condition);
                    }
                    break;
                }
            }
            ptCi->trafficMonitoringCfg.trafficReportCfgList[idx].isReportedByAUPF = FALSE;
            for (TrafficReportCfgDrb_type & reportCfgDrb : ptCi->trafficMonitoringCfg.trafficReportDrbList)
            {
                reportCfgDrb.reportIdxList[idx].isReportedByAUPF = FALSE;
            }
        }
    }

    return GOOD;
}

/**
 * @brief       Callback to handle Report for pdcp-buffer-based-fr2-pscell-change purpose
 * @param[in]   ptCi :              call information
 * @param[in]   ptMsg :             received E1 message (if need to access raw data)
 * @param[in]   reportIdx :         reportIdx of assigned report configuration
 * @return      GOOD  : processing success
 *              ERROR : processing failure
 */
int16_t VCCM_ProcReportEnDcTrafficBasedPsCellChange(
    callInfo_type *ptCi, struct E1_PrivateMessage *pMsg, uint8_t reportIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMsg);
    VCCB_CHECK_E_RANGE_AND_RETURN(reportIdx, MAX_TRF_MONITORING_CFG_PER_CALL);

    for (uint8_t drbIdx = 0; drbIdx < MAX_ERAB_PER_CALL; ++drbIdx)
    {
        const TrafficReportCfgDrb_type &reportCfgPerDrb = ptCi->trafficMonitoringCfg.trafficReportDrbList[drbIdx];

        if (CI_use != ptCi->erabInfo[drbIdx].usage || TRUE != reportCfgPerDrb.reportIdxList[reportIdx].isReportedByAUPF)
        {
            continue;
        }

        if (THRESHOLD_ABOVE_condition == ptCi->trafficMonitoringCfg.trafficReportCfgList[reportIdx].condition)
        {
            // Set given DRB above-dl-traffic-thld flag.
            ptCi->erabInfo[drbIdx].dlTrafficAboveThldFlag = VCCB_FLAG_ON;
            // We need to trigger measurements reconfiguration only if it is first DRB to exceed DL traffic threshold.
            if (VCCB_FLAG_OFF == ptCi->trafficMonitoringState.pdcpFr2PscellChangeFlag)
            {
                VCCB_PRINT_CALL_INFORMATIVE(
                    ptCi, "First DRB is above DL traffic threshold. Schedule FR2 MOs installation.\n");
                // Set proper flag for call that indicates need of FR2 measurements configuration.
                ptCi->trafficMonitoringState.pdcpFr2PscellChangeFlag = VCCB_FLAG_ON;
                // Enqueue measurements reconfiguration.
                if (GOOD != VCCM_EnqueueActionMeasReconfig(ptCi, MeasReconfigPriorAction_Full))
                {
                    VCCB_PRINT_CALL_ERROR(ptCi,
                        "Failed to enqueue measurement reconfig action after receiving DL traffic status report from "
                        "UP.\n");
                    return ERROR;
                }
            }
        }
        else  // THRESHOLD_BELOW_condition
        {
            // Reset given DRB above-dl-traffic-thld flag.
            ptCi->erabInfo[drbIdx].dlTrafficAboveThldFlag = VCCB_FLAG_OFF;
            const uint8_t drbCount = VLIB_CountDrbWithAboveDlTrafficThldFlagOn(ptCi);
            // Uninstall FR2 measurements only if all DRBs are below DL traffic threshold.
            // pdcpFr2PscellChangeFlag flag is checked just-in-case.
            if ((0 == drbCount) && (VCCB_FLAG_ON == ptCi->trafficMonitoringState.pdcpFr2PscellChangeFlag))
            {
                VCCB_PRINT_CALL_INFORMATIVE(
                    ptCi, "All DRBs are below DL traffic threshold. Schedule FR2 MOs deinstallation.\n");
                // Set proper flag for call that indicates need to configure FR2 measurements.
                ptCi->trafficMonitoringState.pdcpFr2PscellChangeFlag = VCCB_FLAG_OFF;
                // Enqueue measurements reconfiguration.
                if (ERROR == VCCM_EnqueueActionMeasReconfig(ptCi, MeasReconfigPriorAction_Full))
                {
                    VCCB_PRINT_CALL_ERROR(ptCi,
                        "Failed to enqueue measurement reconfig action after receiving DL traffic status report from "
                        "UP.\n");
                    return ERROR;
                }
            }
        }
    }

    return GOOD;
}

/**
 * @brief       Callback to handle Report for traffic-based-nr-to-eutra-handover purpose
 * @param[in]   ptCi :              call information
 * @param[in]   ptMsg :             received E1 message (if need to access raw data)
 * @param[in]   reportIdx :         reportIdx of assigned report confiruation
 * @return      GOOD  : processing success
 *              ERROR : processing failure
 */
int16_t FnVCCB_ProcReportTrafficBasedNrToEutraHandover(
    callInfo_type *ptCi, struct E1_PrivateMessage *pMsg, uint8_t reportIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMsg);
    VCCB_CHECK_E_RANGE_AND_RETURN(reportIdx, MAX_TRF_MONITORING_CFG_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    uint16_t cellNum = ptCi->servCellNum;

    // During Intra-gNB HO after NR RRCRconfigComplete form UE send new serving cell to UP
    if (  // NSA states
        (STATE_DCIntraDuHo_RRCRecCmpl == ptCi->state) || (STATE_DCIntraDuHo_X2RecCmpl == ptCi->state) ||
        (STATE_DCIntraDuHo_X2SnStatus == ptCi->state) || (STATE_DCIntraDuHo_X2ModCnf == ptCi->state) ||
        (STATE_DCInterDuHo_RRCRecCmpl == ptCi->state) || (STATE_DCInterDuHo_X2RecCmpl == ptCi->state) ||
        (STATE_DCInterDuHo_X2SnStatus == ptCi->state) || (STATE_DCInterDuHo_X2ModCnf == ptCi->state) ||
        (STATE_DCNonDuHo_X2SnStatus == ptCi->state) || (STATE_DCNonDuHo_X2RecCmpl == ptCi->state) ||
        // SA states
        (STATE_INTRA_DU_Complete == ptCi->state) || (STATE_INTER_DU_Complete == ptCi->state) ||
        (STATE_SN_INTRA_DU_Complete == ptCi->state) || (STATE_SN_INTER_DU_Complete == ptCi->state))
    {
        cellNum = ptCi->hoInfo.targetCellNum;
    }

    VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi, "[TRF_HO] %s reportIdx:%u!!\n", __func__, reportIdx);

    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    if (FnVCCB_CheckNrdcMode(*ptCi, cellNum, NRDC_MODE3_TRAFFIC_BLIND_MODE))
    {
        // traffic-based-handover discard
        ptCi->trafficMonitoringState.TrfBasedNrToEutraHoFlag = VCCB_FLAG_OFF;

        VCCB_PRINT_CALL_ERROR(
            ptCi, "[TRF_HO] NR-DC oprMode(%d) is Traffic Blind mode in cellNum(%u)\n", NRDC_OPR_MODE(cellNum), cellNum);

        return ERROR;
    }

    if (GOOD != FnVCCB_CheckCommonDlTrfStatusRptCfgforNrToEutraHo(ptCi, cellNum))
    {
        // traffic-based-handover discard
        ptCi->trafficMonitoringState.TrfBasedNrToEutraHoFlag = VCCB_FLAG_OFF;

        VCCB_PRINT_CALL_ERROR(
            ptCi, "[TRF_HO] FnVCCB_CheckCommonDlTrfStatusRptCfgforNrToEutraHo ERROR cellNum(%u)\n", cellNum);

        return ERROR;
    }

    for (uint8_t drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; ++drbIdx)
    {
        TrafficReportCfgDrb_type &reportCfgPerDrb = ptCi->trafficMonitoringCfg.trafficReportDrbList[drbIdx];

        if (CI_use != ptCi->drb[drbIdx].usage || TRUE != reportCfgPerDrb.reportIdxList[reportIdx].isReportedByAUPF)
        {
            continue;
        }

        if (GOOD != FnVCCB_NeedToDlTrfStatusRptCfgforNrToEutraHoAddPerDRB(ptCi, &ptCi->drb[drbIdx], false))
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "[TRF_HO] drbIdx:%u dRBId:%u NOT a condition for Traffic based NR to EUTRA HO when traffic monitoring report !!\n", 
                drbIdx, ptCi->drb[drbIdx].dRBId);
            continue; // check all DRBs
        }

        if (THRESHOLD_ABOVE_condition == ptCi->trafficMonitoringCfg.trafficReportCfgList[reportIdx].condition)
        {
            ptCi->drb[drbIdx].dlTrafficAboveThldFlag = VCCB_FLAG_ON;
            VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi, "[TRF_HO] drbIdx:%u dRBId:%u THRESHOLD_ABOVE_condition \n", 
                drbIdx, ptCi->drb[drbIdx].dRBId);
        }
        else  // THRESHOLD_BELOW_condition
        {
            ptCi->drb[drbIdx].dlTrafficAboveThldFlag = VCCB_FLAG_OFF;
            VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi, "[TRF_HO] drbIdx:%u dRBId:%u THRESHOLD_BELOW_condition \n", 
                drbIdx, ptCi->drb[drbIdx].dRBId);
        }
    }

    const uint8_t drbCount = VLIB_CountDrbWithAboveDlTrafficThldFlagOn_SA(ptCi);

    if (drbCount > 0)
    {
        // If one or more DRBs are above DL traffic threshold, need to trigger measurements reconfiguration
        if (VCCB_FLAG_OFF == ptCi->trafficMonitoringState.TrfBasedNrToEutraHoFlag)
        {
            VCCB_PRINT_CALL_INFORMATIVE(
                ptCi, "DRB is above DL traffic threshold. Schedule Bx_TPHO MOs installation.\n");
            ptCi->trafficMonitoringState.TrfBasedNrToEutraHoFlag = VCCB_FLAG_ON;
            if (GOOD != VCCM_EnqueueActionMeasReconfig(ptCi, MeasReconfigPriorAction_Full))
            {
                ptCi->trafficMonitoringState.TrfBasedNrToEutraHoFlag = VCCB_FLAG_OFF;
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "Failed to enqueue measurement reconfig action after receiving DL traffic status report from "
                    "UP.\n");
                return ERROR;
            }
        }
        else
        {
            VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi, "DRB is above DL traffic threshold. Bx_TPHO is already installed.\n");
        }
    }
    else  // If all DRBs are below DL traffic threshold, uninstall Bx_TPHO measurements
    {
        if ((VCCB_FLAG_ON == ptCi->trafficMonitoringState.TrfBasedNrToEutraHoFlag))
        {
            ptCi->trafficMonitoringState.TrfBasedNrToEutraHoFlag = VCCB_FLAG_OFF;

            VCCB_PRINT_CALL_INFORMATIVE(
                ptCi, "All DRBs are below DL traffic threshold. Schedule Bx_TPHO MOs deinstallation.\n");
            if (GOOD != VCCM_EnqueueActionMeasReconfig(ptCi, MeasReconfigPriorAction_Full))
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "Failed to enqueue measurement reconfig action after receiving DL traffic status report from "
                    "UP.\n");
                return ERROR;
            }
        }
        else
        {
            VCCB_PRINT_CALL_INFORMATIVE(
                ptCi, "All DRBs are below DL traffic threshold. Bx_TPHO is already deinstalled.\n");
        }
    }

    return GOOD;
}

/**
 * @brief       Callback to handle Report for traffic-based-inter-rat-pcc-change
 * @param[in]   ptCi :              call information
 * @param[in]   ptMsg :             received E1 message (if need to access raw data)
 * @param[in]   reportIdx :         reportIdx of assigned report configuration
 * @return      GOOD  : processing success
 *              ERROR : processing failure
 */
int16_t FnVCCB_ProcReportTrafficBasedInterRatPccChange(
    callInfo_type *ptCi, struct E1_PrivateMessage *pMsg, uint8_t reportIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR_PARAM2(ptCi, pMsg);
    VCCB_CHECK_RANGE_AND_RETURN_ERROR(reportIdx, MAX_TRF_MONITORING_CFG_PER_CALL, "[IRAT PCC] reportIdx out of range");
    
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, ERROR);
    const VccbGnbInfo_type &rGnb = GNBINFO[ptCi->gnbNum];
    if (!FnVCCB_CheckIfInterRatPccChangeCanOperate(ptCi, rGnb))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[IRAT PCC] STOPPING - Operating conditions not fulfilled when Dl Traffic Report received!\n");
        VCCB_CLEAR_TIMER(&ptCi->pccData.interRatWaitingTmr, CANCEL_TIMER);
        SET_IRATPCC_STATE(ptCi, IRatPCCState_Idle);
        // Remove traffic measurements
        if (ERROR == VCCB_TriggerTrafficMeasurementReconfiguration(ptCi, ENQUEUE_NO_ACTION))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, 
                "[IRAT PCC] Traffic meas trigger failed in FnVCCB_ProcReportTrafficBasedInterRatPccChange.\n");
        }
        return GOOD;
    }

    TrafficReportCfg_type const &trafficReport = ptCi->trafficMonitoringCfg.trafficReportCfgList[reportIdx];
    if (CI_use != trafficReport.usage)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, 
            "[IRAT PCC] Error, reportIdx (%u) not in use in FnVCCB_ProcReportTrafficBasedInterRatPccChange.\n", reportIdx);
        return ERROR;
    }

    if (THRESHOLD_ABOVE_condition != trafficReport.condition)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, 
            "[IRAT PCC] Error, condition is not THRESHOLD_ABOVE_condition in FnVCCB_ProcReportTrafficBasedInterRatPccChange.\n");
        return ERROR;
    }

    SET_IRATPCC_STATE(ptCi, IRatPCCState_Gathering);
    
    // For removal of Traffic Check report
    if (ERROR == VCCB_TriggerTrafficMeasurementReconfiguration(ptCi, ENQUEUE_NO_ACTION))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, 
            "[IRAT PCC] Traffic meas trigger failed in FnVCCB_ProcReportTrafficBasedInterRatPccChange.\n");
    }

    // For the installation of the B1 report
    if (ERROR == VCCM_EnqueueActionMeasReconfig(ptCi, MeasReconfigPriorAction_Full))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, 
            "[IRAT PCC] VCCM_EnqueueActionMeasReconfig failed in FnVCCB_ProcReportTrafficBasedInterRatPccChange\n");
    }
    
    return GOOD;
}

/**
 * @brief       Callback to handle Report for traffic-based-multi-rat-carrier-change purpose (FGR-CC5500)
 * @param[in]   ptCi :              call information
 * @param[in]   ptMsg :             received E1 message (if need to access raw data)
 * @param[in]   reportIdx :         reportIdx of assigned report confiruation
 * @return      GOOD  : processing success
 *              ERROR : processing failure
 */
int16_t FnVCCB_ProcReportTrafficBasedMrs(callInfo_type *ptCi, struct E1_PrivateMessage *pMsg, uint8_t reportIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMsg);
    VCCB_CHECK_E_RANGE_AND_RETURN(reportIdx, MAX_TRF_MONITORING_CFG_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    uint8_t drbIdx = 0;

    if (MRS_TRAFFIC_WAIT != ptCi->mrsInfo.mrsState)
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] mrsState invalid: %d,  %s !!\n", ptCi->mrsInfo.mrsState, __FUNCTION__);
        return GOOD;
    }

    if (false == FnVCCB_CheckMultiRatSelection(ptCi, false))
    {
        FnVCCB_InitMrsInfo(ptCi, MRS_ALL_INIT);
        return GOOD;
    }

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; ++drbIdx)
    {
        TrafficReportCfgDrb_type & reportCfgPerDrb = ptCi->trafficMonitoringCfg.trafficReportDrbList[drbIdx];

        if (CI_use != ptCi->drb[drbIdx].usage ||
                TRUE != reportCfgPerDrb.reportIdxList[reportIdx].isReportedByAUPF)
        {
            VCCB_PRINT_LOG_MRS_FUNC(ptCi,
                    "[MRS](drbIdx:%u, usage:%d) reportIdx : %d !! :: %s \n", 
                    drbIdx, ptCi->drb[drbIdx].usage, reportCfgPerDrb.reportIdxList[reportIdx].isReportedByAUPF, __FUNCTION__);
            continue;
        }

        if (THRESHOLD_ABOVE_condition == ptCi->trafficMonitoringCfg.trafficReportCfgList[reportIdx].condition)
        {
            break;
        }
    }

    if (MAX_DRB_PER_SA_CALL > drbIdx)
    {
        // If one or more DRBs are above DL traffic threshold, need to trigger measurements reconfiguration
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] DRB is above DL traffic threshold. Schedule Bx_TPHO MOs installation.\n");

        SET_MRS_STATE(ptCi, MRS_GATHERING_MEAS);

        if (GOOD != VCCM_EnqueueActionMeasReconfig(ptCi, MeasReconfigPriorAction_Full))
        {
            FnVCCB_InitMrsInfo(ptCi, MRS_ALL_INIT);
            VCCB_PRINT_CALL_ERROR(ptCi,
                    "Failed to enqueue measurement reconfig action after receiving DL traffic status report from UP.\n");
            return ERROR;
        }
    }

    return GOOD;
}

// eof
