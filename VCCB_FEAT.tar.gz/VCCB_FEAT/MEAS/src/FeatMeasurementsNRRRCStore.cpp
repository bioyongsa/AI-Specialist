#include "FeatMeasurementsNRRRCStore.hpp"
#include "FeatMeasCommon.hpp"
#include "ComMacro.h"
#include "ComInclude.h"
#include "ComContainers.hpp"
#include "ComAsnUtil.hpp"

using asn::util::SupportedBitmask;

/****************************************************************************
 * @brief Store NRRRC_GapConfig using delta signalling.
 ****************************************************************************/
template <typename RRCType>
static void VCCB_StoreGapConfig(measGapConfig_type &rDst, RRCType &rSrc)
{
    AUTO_TRACE_FUNC;

    if (NRRRC_setup_5_chosen == rSrc.choice)
    {
        NRRRC_GapConfig &rSrcGapConfig = rSrc.u.setup;

        if (VCCB_FLAG_ON != rDst.flag)
        {
            memset(&rDst.gapConfig.m, 0, sizeof(rDst.gapConfig.m));
        }

        rDst.flag = VCCB_FLAG_ON;
        rDst.gapConfig.gapOffset = static_cast<uint8_t>(rSrcGapConfig.gapOffset);
        rDst.gapConfig.mgl = rSrcGapConfig.mgl & 0x07;
        rDst.gapConfig.mgrp = rSrcGapConfig.mgrp & 0x03;
        rDst.gapConfig.mgta = rSrcGapConfig.mgta & 0x03;
        if (NRRRC_refServCellIndicator_present & rSrcGapConfig.bit_mask)
        {
            rDst.gapConfig.refServCellIndicator = rSrcGapConfig.refServCellIndicator;
            rDst.gapConfig.m.refServCellIndicatorFlag = VCCB_FLAG_ON;
        }
    }
    else
    {
        rDst.flag = VCCB_FLAG_OFF;
    }
}

/****************************************************************************
 * @brief           Store source measGapConfig of the UE. Uses delta signalling.
 * @param[out]      ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       pSrc : Source ASN configuration type. / NRRRC_MeasConfig*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
static int16_t VCCB_StoreMeasGapConfig(callInfo_type *ptCi, NRRRC_MeasGapConfig *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    mGapCfgNode_type &rmGapCfgInstalled = FnVCCB_GetMeasurementsConfiguration(*ptCi).mGapCfgInstalled;
    rmGapCfgInstalled.fr2.flag = VCCB_FLAG_OFF;
    rmGapCfgInstalled.fr1.flag = VCCB_FLAG_OFF;
    rmGapCfgInstalled.ue.flag = VCCB_FLAG_OFF;

    // gapFR2
    if (NRRRC_gapFR2_present & pSrc->bit_mask)
    {
        VCCB_StoreGapConfig(rmGapCfgInstalled.fr2, pSrc->gapFR2);
    }

    // gapFR1
    if (NRRRC_gapFR1_present & pSrc->bit_mask)
    {
        VCCB_StoreGapConfig(rmGapCfgInstalled.fr1, pSrc->gapFR1);
    }

    // gapUE
    if (NRRRC_gapUE_present & pSrc->bit_mask)
    {
        VCCB_StoreGapConfig(rmGapCfgInstalled.ue, pSrc->gapUE);
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Store source measGapConfig from DU. Uses delta signalling.
 * @param[out]      ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       pSrc : Source ASN configuration type. / NRRRC_MeasConfig*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_StoreMeasGapConfigDu(callInfo_type *ptCi, NRRRC_MeasGapConfig *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    mGapCfgNode_type &rmGapCfgDst = FnVCCB_GetMGapDuData(*ptCi).mGapCfgNew;
    // if not received - keep previous values
    // if not related to call type - ignore

    // gapFR2
    if (NRRRC_gapFR2_present & pSrc->bit_mask)
    {
        VCCB_StoreGapConfig(rmGapCfgDst.fr2, pSrc->gapFR2);
    }

    // gapFR1 - SA only
    if ((NRRRC_gapFR1_present & pSrc->bit_mask) && (E_CALLTYPE_NSA != ptCi->callType))
    {
        VCCB_StoreGapConfig(rmGapCfgDst.fr1, pSrc->gapFR1);
    }

    // gapUE - SA only
    if ((NRRRC_gapUE_present & pSrc->bit_mask) && (E_CALLTYPE_NSA != ptCi->callType))
    {
        VCCB_StoreGapConfig(rmGapCfgDst.ue, pSrc->gapUE);
    }

    return GOOD;
}

/****************************************************************************
 * @brief Store NR-RRC MeasConfig in target structure
 * @param[in] pDst: target structure
 * @param[in] pSrc : source structure
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_StoreMeasConfigMN(measConfigMN_type *pDst, NRRRC_MeasConfigMN *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    pDst->measuredFrequenciesMN_Flag = VCCB_FLAG_OFF;
    if (NRRRC_measuredFrequenciesMN_present & pSrc->bit_mask)
    {
        uint8_t numFreqs = 0;
        pDst->measuredFrequenciesMN_Flag = VCCB_FLAG_ON;
        for (auto measuredFreqs = pSrc->measuredFrequenciesMN; NULL != measuredFreqs;
             measuredFreqs = measuredFreqs->next)
        {
            if (MAX_NUM_MEAS_FREQS_MN <= numFreqs)
            {
                VCCB_PRINT_ERROR("Too many measuredFrequenciesMN, maximum is %u!\n", MAX_NUM_MEAS_FREQS_MN);
                return ERROR;
            }

            if (NRRRC_measuredFrequency_present & measuredFreqs->value.bit_mask)
            {
                pDst->measuredFrequenciesMN.nrFreqInfo[numFreqs].measuredFrequencyFlag = VCCB_FLAG_ON;
                pDst->measuredFrequenciesMN.nrFreqInfo[numFreqs].measuredFrequency =
                    measuredFreqs->value.measuredFrequency;
            }
            else
            {
                pDst->measuredFrequenciesMN.nrFreqInfo[numFreqs].measuredFrequencyFlag = VCCB_FLAG_OFF;
            }

            numFreqs++;
        }

        pDst->measuredFrequenciesMN.nrofMeasFreqsMN = numFreqs;
    }

    if (NRRRC_MeasConfigMN_measGapConfig_present & pSrc->bit_mask)
    {
        VCCB_StoreGapConfig(pDst->measGapConfigFR1, pSrc->measGapConfig);
    }

    if (NRRRC_gapPurpose_present & pSrc->bit_mask)
    {
        pDst->gapPurposeFlag = VCCB_FLAG_ON;
        pDst->gapPurpose = pSrc->gapPurpose;
    }

    if (NRRRC_measGapConfigFR2_present & pSrc->bit_mask)
    {
        VCCB_StoreGapConfig(pDst->measGapConfigFR2, pSrc->measGapConfigFR2);
    }

    return GOOD;
}

/****************************************************************************
 * @brief Store MeasConfigSN IE from SN CG-Config in MN UE Context
 * @param  ptCi : Pointer to call configuration. / callInfo_type*
 * @param  pIE            : pointer to NRRRC_MeasConfigSN structure to be stored
 * @return int16_t        : result of operation
 ****************************************************************************/
void VCCB_StoreMeasConfigSN_fromSN(callInfo_type *ptCi, NRRRC_MeasConfigSN *pIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pIE);

    measuredFrequencies_type *pTgtMeasFreq = &ptCi->measurementsConfigShared.mGapConfiguration.freqSnNew;

    pTgtMeasFreq->numItems = 0;

    if (NRRRC_measuredFrequenciesSN_present & pIE->bit_mask)
    {
        for (auto pSrcMeasFreq = pIE->measuredFrequenciesSN; NULL != pSrcMeasFreq; pSrcMeasFreq = pSrcMeasFreq->next)
        {
            if (VCCB_ARRAY_COUNT(pTgtMeasFreq->frequencies) <= pTgtMeasFreq->numItems)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "Number of measuredFrequenciesSN exceeds maxCount(%zu) - skip!\n",
                    VCCB_ARRAY_COUNT(pTgtMeasFreq->frequencies));
                break;
            }

            if (NRRRC_measuredFrequency_present & pSrcMeasFreq->value.bit_mask)
            {
                pTgtMeasFreq->frequencies[pTgtMeasFreq->numItems] = pSrcMeasFreq->value.measuredFrequency;
                pTgtMeasFreq->numItems++;
            }
        }
        std::sort(pTgtMeasFreq->frequencies, pTgtMeasFreq->frequencies + pTgtMeasFreq->numItems);
        auto endIt = std::unique(pTgtMeasFreq->frequencies, pTgtMeasFreq->frequencies + pTgtMeasFreq->numItems);
        pTgtMeasFreq->numItems = static_cast<uint8_t>(endIt - pTgtMeasFreq->frequencies);
    }

    if ((STATE_Conn != ptCi->state) && !(*pTgtMeasFreq == ptCi->measurementsConfigShared.mGapConfiguration.freqSnInstalled))
    {
        VCCB_RETURN_ON_CALL_VOID(ptCi, VCCM_EnqueueActionMeasReconfig(ptCi, MeasReconfigPriorAction_Mgap),
            "VCCM_enqueueAction(ENQUEUE_ACTION_MEAS_RECONFIG) fail!\n");
    }
}

/****************************************************************************
 * @brief           Store ASN defined NRRRC_SSB_MTC object using
 *                  VCCB specific smtc1_type object.
 *
 * @param[in]      pSrc : Pointer to a source object. / NRRRC_SSB_MTC*
 * @param[out]     pDst : Pointer to a destination object. / smtc1_type*
 * @return         status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Store_SSB_MTC1(smtc1_type *pDst, const NRRRC_SSB_MTC *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pSrc);
    VALID_E_POINT_CHECK_ERROR(pDst);

    pDst->duration = static_cast<enumSmtcDuration>(pSrc->duration);

    switch (pSrc->periodicityAndOffset.choice)
    {
        case NRRRC_sf5_chosen:
            pDst->periodicityAndOffset.periodicity = smtc_periodicity_sf5;
            pDst->periodicityAndOffset.offset = static_cast<uint8_t>(pSrc->periodicityAndOffset.u.sf5);
            break;
        case NRRRC_sf10_chosen:
            pDst->periodicityAndOffset.periodicity = smtc_periodicity_sf10;
            pDst->periodicityAndOffset.offset = static_cast<uint8_t>(pSrc->periodicityAndOffset.u.sf10);
            break;
        case NRRRC_sf20_chosen:
            pDst->periodicityAndOffset.periodicity = smtc_periodicity_sf20;
            pDst->periodicityAndOffset.offset = static_cast<uint8_t>(pSrc->periodicityAndOffset.u.sf20);
            break;
        case NRRRC_sf40_chosen:
            pDst->periodicityAndOffset.periodicity = smtc_periodicity_sf40;
            pDst->periodicityAndOffset.offset = static_cast<uint8_t>(pSrc->periodicityAndOffset.u.sf40);
            break;
        case NRRRC_sf80_chosen:
            pDst->periodicityAndOffset.periodicity = smtc_periodicity_sf80;
            pDst->periodicityAndOffset.offset = static_cast<uint8_t>(pSrc->periodicityAndOffset.u.sf80);
            break;
        case NRRRC_sf160_chosen:
            pDst->periodicityAndOffset.periodicity = smtc_periodicity_sf160;
            pDst->periodicityAndOffset.offset = static_cast<uint8_t>(pSrc->periodicityAndOffset.u.sf160);
            break;
        default:
            VCCB_PRINT_ERROR("VCCB_Store_MeasObjectToAddMod ERROR, invalid smtc1!\n");

            return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Store ASN defined NRRRC_SSB_MTC2 object using
 *                  VCCB specific smtc2_type object.
 *
 * @param[in]      pSrc : Pointer to a source object. / NRRRC_SSB_MTC2*
 * @param[out]     pDst : Pointer to a destination object. / smtc2_type*
 ****************************************************************************/
void VCCB_Store_SSB_MTC2(smtc2_type *pDst, NRRRC_SSB_MTC2 *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pSrc);
    VALID_E_POINT_CHECK_VOID(pDst);

    pDst->numPCIs = 0;
    pDst->smtc2Periodicity = static_cast<enumSmtcPeriodicity>(pSrc->periodicity);

    if (pSrc->bit_mask & NRRRC_SSB_MTC2_pci_List_present)
    {
        for (; NULL != pSrc->pci_List && MAX_NUM_OF_PCIS_SMTC2 > pDst->numPCIs;
             pSrc->pci_List = pSrc->pci_List->next, pDst->numPCIs++)
        {
            pDst->PCIs[pDst->numPCIs] = pSrc->pci_List->value;
        }
    }

    pDst->usage = CI_use;
}

/****************************************************************************
 * @brief           Store ASN defined NRRRC_SSB_ConfigMobility object basing
 *                  on current UE configuration.
 *
 * @param[out]      pSrc : Pointer to ASN defined reference signal
 *                         configuration object containing field for
 *                         SSB config mobility. / NRRRC_SSB_ConfigMobility*
 * @param[in]       pDst : Pointer to a destination object. / ssbConfigMobilityUe_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
static int16_t VCCB_StoreSSB_ConfigMobility(ssbConfigMobilityUe_type *pDst, NRRRC_SSB_ConfigMobility *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pSrc);
    VALID_E_POINT_CHECK_ERROR(pDst);

    pDst->deriveSSB_IndexFromCell = static_cast<uint8_t>(pSrc->deriveSSB_IndexFromCell);
    pDst->usage = CI_use;

    if ((pSrc->bit_mask & NRRRC_SSB_ConfigMobility_ssb_ToMeasure_present) &&
        (pSrc->ssb_ToMeasure.choice == NRRRC_setup_11_chosen))
    {
        switch (pSrc->ssb_ToMeasure.u.setup.choice)
        {
            case NRRRC_SSB_ToMeasure_shortBitmap_chosen:
                if (pSrc->ssb_ToMeasure.u.setup.u.shortBitmap.length == 4)
                {
                    pDst->ssbMeasurementConfiguration.ssbValue =
                        (static_cast<uint64_t>(*pSrc->ssb_ToMeasure.u.setup.u.shortBitmap.value) >> 4);
                    pDst->ssbMeasurementConfiguration.ssbToMeasure = ssbToMeasure_shortBitmap;
                }
                else
                {
                    VCCB_PRINT_ERROR("VCCB_StoreSSB_ConfigMobility ERROR, invalid shortBitmap length!\n");

                    return ERROR;
                }
                break;
            case NRRRC_SSB_ToMeasure_mediumBitmap_chosen:
                if (pSrc->ssb_ToMeasure.u.setup.u.mediumBitmap.length == 8)
                {
                    pDst->ssbMeasurementConfiguration.ssbValue = *pSrc->ssb_ToMeasure.u.setup.u.mediumBitmap.value;
                    pDst->ssbMeasurementConfiguration.ssbToMeasure = ssbToMeasure_mediumBitmap;
                }
                else
                {
                    VCCB_PRINT_ERROR("VCCB_StoreSSB_ConfigMobility ERROR, invalid mediumBitmap length!\n");

                    return ERROR;
                }
                break;
            case NRRRC_SSB_ToMeasure_longBitmap_chosen:
                if (pSrc->ssb_ToMeasure.u.setup.u.longBitmap.length == 64)
                {
                    memcpy(&pDst->ssbMeasurementConfiguration.ssbValue, pSrc->ssb_ToMeasure.u.setup.u.longBitmap.value,
                        sizeof(pDst->ssbMeasurementConfiguration.ssbValue));

                    pDst->ssbMeasurementConfiguration.ssbValue = be64toh(pDst->ssbMeasurementConfiguration.ssbValue);
                    pDst->ssbMeasurementConfiguration.ssbToMeasure = ssbToMeasure_longBitmap;
                }
                else
                {
                    VCCB_PRINT_ERROR("VCCB_StoreSSB_ConfigMobility ERROR, invalid longBitmap length!\n");

                    return ERROR;
                }
                break;
            default:
            {
                VCCB_PRINT_ERROR("VCCB_StoreSSB_ConfigMobility ERROR, invalid SSB_ToMeasure bitmap type!\n");

                return ERROR;
            }
        }
        pDst->ssbMeasurementConfiguration.usage = CI_use;
    }

    if (pSrc->bit_mask & NRRRC_SSB_ConfigMobility_ss_RSSI_Measurement_present)
    {
            VCCB_PRINT_ERROR("SSB_ConfigMobility_ss_RSSI_Measurement unsupported!\n");
            return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Store ASN defined NRRRC_ReferenceSignalConfig basing on
 *                  VCCB specific referenceSignalConfigUe_type object.
 *
 * @param[in]      pSrc : Pointer to configuration. / NRRRC_ReferenceSignalConfig*
 * @param[out]     pDst : Pointer to a destination object. / referenceSignalConfigUe_type*
 * @return         status : GOOD, ERROR / int16_t
 ****************************************************************************/
static int16_t VCCB_Store_ReferenceSignalConfig(referenceSignalConfigUe_type *pDst, NRRRC_ReferenceSignalConfig *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pSrc);
    VALID_E_POINT_CHECK_ERROR(pDst);

    if (!(pSrc->bit_mask & NRRRC_ssb_ConfigMobility_present))
    {
        VCCB_PRINT_ERROR(
            "NRRRC_ReferenceSignalConfig , SSB ConfigMobility is not present! Received Bitmask=%d\n", pSrc->bit_mask);
        return ERROR;
    }

    if (pSrc->bit_mask & NRRRC_csi_rs_ResourceConfigMobility_present)
    {
        VCCB_PRINT_ERROR("ERROR: CSI-RS ResourceConfigMobility not supported!\n");
        return ERROR;
    }

    if (VCCB_StoreSSB_ConfigMobility(&pDst->ssbConfigMobility, &pSrc->ssb_ConfigMobility) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_StoreSSB_ConfigMobility failed in VCCB_Store_ReferenceSignalConfig!\n");
        return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Store ASN defined NRRRC_ThresholdNR object using VCCB
                    specific thresholdNR_type object.
 *
 * @param[out]      pSrc : Pointer to a source object. / NRRRC_ThresholdNR*
 * @param[in]       pDst : Pointer to a destination object. / thresholdNR_type*
 ****************************************************************************/
void VCCB_Store_ThresholdNR(thresholdNR_type *pDst, NRRRC_ThresholdNR *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pSrc);
    VALID_E_POINT_CHECK_VOID(pDst);

    if (pSrc->bit_mask & NRRRC_thresholdRSRP_present)
    {
        pDst->thresholdRSRP.value = static_cast<uint8_t>(pSrc->thresholdRSRP);
        pDst->thresholdRSRP.usage = CI_use;
    }

    if (pSrc->bit_mask & NRRRC_thresholdRSRQ_present)
    {
        pDst->thresholdRSRQ.value = static_cast<uint8_t>(pSrc->thresholdRSRQ);
        pDst->thresholdRSRQ.usage = CI_use;
    }

    if (pSrc->bit_mask & NRRRC_thresholdSINR_present)
    {
        pDst->thresholdSINR.value = static_cast<uint8_t>(pSrc->thresholdSINR);
        pDst->thresholdSINR.usage = CI_use;
    }
}

/****************************************************************************
 * @brief           Store ASN defined NRRRC_Q_OffsetRangeList object using
 *                  VCCB specific qOffsetSSBRangeList_type object.
 *
 * @param[in]      pSrc : Pointer to a source object. / NRRRC_Q_OffsetRangeList*
 * @param[out]     pDst : Pointer to a destination object. / qOffsetSSBRangeList_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_StoreQ_OffsetRangeList(qOffsetSSBRangeList_type *pDst, NRRRC_Q_OffsetRangeList *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pSrc);
    VALID_E_POINT_CHECK_ERROR(pDst);

    if ((pSrc->bit_mask & NRRRC_rsrpOffsetCSI_RS_present) || (pSrc->bit_mask & NRRRC_rsrqOffsetCSI_RS_present) ||
        (pSrc->bit_mask & NRRRC_sinrOffsetCSI_RS_present))
    {
        return ERROR;
    }

    if (pSrc->bit_mask & NRRRC_rsrpOffsetSSB_present)
    {
        pDst->rsrpOffsetSSB = pSrc->rsrpOffsetSSB & 0x1F;
    }
    else
    {
        pDst->rsrpOffsetSSB = qOffset_0;
    }

    if (pSrc->bit_mask & NRRRC_rsrqOffsetSSB_present)
    {
        pDst->rsrqOffsetSSB = pSrc->rsrqOffsetSSB & 0x1F;
    }
    else
    {
        pDst->rsrqOffsetSSB = qOffset_0;
    }

    if (pSrc->bit_mask & NRRRC_sinrOffsetSSB_present)
    {
        pDst->sinrOffsetSSB = pSrc->sinrOffsetSSB & 0x1F;
    }
    else
    {
        pDst->sinrOffsetSSB = qOffset_0;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Store ASN defined NRRRC_CellsToAddModList object basing
 *                  on VCCB specific cellsToMeasureList_type object.
 *
 * @param[out]      pSrc : Pointer to a source object. / NRRRC_CellsToAddModList
 * @param[in]       pDst : Pointer to destination configuration / cellsToMeasureList_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
static int16_t VCCB_Store_CellsToAddModList(cellsToMeasureList_type *pDst, NRRRC_CellsToAddModList pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pSrc);
    VALID_E_POINT_CHECK_ERROR(pDst);

    staticUnorderedSet<NRRRC_PhysCellId, VCCB_ARRAY_COUNT(pDst->items)> uniquePhysCellIds;
    for (pDst->numItems = 0; NULL != pSrc && MAX_NR_OF_CELLS_TO_MEASURE > pDst->numItems;
         pSrc = pSrc->next, pDst->numItems++)
    {
        if (!uniquePhysCellIds.insert(pSrc->value.physCellId))
        {
            VCCB_PRINT_ERROR("VCCB_Store_CellsToAddModList ERROR, PCI duplication detected in cellsToAddModList.\n");

            return ERROR;
        }

        pDst->items[pDst->numItems].pci = pSrc->value.physCellId;
        if (ERROR == VCCB_StoreQ_OffsetRangeList(
                         &pDst->items[pDst->numItems].cellIndividualOffset, &pSrc->value.cellIndividualOffset))
        {
            VCCB_PRINT_ERROR("VCCB_Store_CellsToAddModList ERROR, OffsetRangeList ERROR!\n");
            return ERROR;
        }
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Store Store NRRRC_blackCellsToAdd / NRRRC_ExcludedCellsToAdd IE defined in NRRRC_MeasObjectNR
 *
 * @param[in]      src : Pointer to a source object. NRRRC_MeasObjectNR::*blackCellsToAddModList or
 *                 NRRRC_MeasObjectNR::*excludedCellsToAddModList
 * @param[out]     dst : Pointer to configuration already installed on UE.
 *measurementObjectNRUe_type::blackCellsUe_type*
 * @return         status : GOOD, ERROR / int16_t
 ****************************************************************************/
template <typename T>
static int16_t VCCB_Store_ExcludedCellsToAddModList(const T *src, blackCellsUe_type *dst)
{
    constexpr size_t rangeElementsLength = VCCB_ARRAY_COUNT(dst->rangeElements);
    staticUnorderedSet<NRRRC_PCI_RangeIndex, rangeElementsLength> uniqueIndexes;
    uint8_t index = 0;
    for (auto *element = src; (NULL != element) && (rangeElementsLength > index); element = element->next, ++index)
    {
        if (!uniqueIndexes.insert(element->value.pci_RangeIndex))
        {
            VCCB_PRINT_ERROR("%s ERROR, cell index(%d) duplication detected in excluded/black CellsToAddModListNR.\n",
                __FUNCTION__, element->value.pci_RangeIndex);
            return ERROR;
        }
        dst->rangeElements[index].pciRangeIndex = static_cast<uint8_t>(element->value.pci_RangeIndex);
        dst->rangeElements[index].pciRange.pciStart = element->value.pci_Range.start & e_BitMask_10bit;
        if (element->value.pci_Range.bit_mask & NRRRC_PCI_Range_range_present)
        {
            dst->rangeElements[index].pciRange.pciType = pciType_range;
            dst->rangeElements[index].pciRange.pciRange =
                static_cast<uint16_t>(element->value.pci_Range.range) & e_BitMask_4bit;
        }
        else
        {
            dst->rangeElements[index].pciRange.pciType = pciType_single;
        }
    }
    dst->numItems = index;
    return GOOD;
}

static int16_t VCCB_Store_AllowedCellsToAddModList(const NRRRC__seqof180_ *src, pciRangeElements_type &dst)
{
    constexpr size_t rangeElementsLength = VCCB_ARRAY_COUNT(dst.pciRanges);
    staticUnorderedSet<NRRRC_PCI_RangeIndex, rangeElementsLength> uniqueIndexes;
    uint8_t count = 0;
    for (auto *element = src; (NULL != element) && (rangeElementsLength > count); element = element->next, ++count)
    {
        if (!uniqueIndexes.insert(element->value.pci_RangeIndex))
        {
            return ERROR;
        }

        if (element->value.pci_Range.bit_mask & NRRRC_PCI_Range_range_present)
        {
            // ranges not supported
            return BREAK;
        }
        dst.pciRanges[count].pciRangeIndex = static_cast<uint8_t>(element->value.pci_RangeIndex);
        dst.pciRanges[count].pci = element->value.pci_Range.start;
    }
    dst.numOfPciRanges = count;
    return GOOD;
}

/****************************************************************************
 * @brief           Store ASN defined NRRRC_MeasObjectNR type
 *                  to measurementObjectNRUe_type object.
 *
 * @param[in]      pMeasObject : Pointer to a source object / NRRRC_MeasObjectToAddMod*
 * @param[out]     pInstall : Pointer to configuration already installed on UE. / measurementObjectUe_type*

 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_StoreMeasObjectNR(NRRRC_MeasObjectNR *pMeasObject, measurementObjectNRUe_type *pInstall)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pMeasObject);
    VALID_E_POINT_CHECK_ERROR(pInstall);

    // check if MeasObject contains any unsupported parameters, if yes then return
    const uint32_t supportedIEsBitMask =
        NRRRC_MeasObjectNR_ssbFrequency_present | NRRRC_MeasObjectNR_ssbSubcarrierSpacing_present |
        NRRRC_smtc1_present | NRRRC_smtc2_present | NRRRC_MeasObjectNR_absThreshSS_BlocksConsolidation_present |
        NRRRC_MeasObjectNR_nrofSS_BlocksToAverage_present | NRRRC_cellsToAddModList_present |
        NRRRC_excludedCellsToAddModList_present | NRRRC_MeasObjectNR_freqBandIndicatorNR_present |
        NRRRC_t312_r16_present | NRRRC_allowedCellsToAddModList_present;
    SupportedBitmask supportedBitmaskChecker(supportedIEsBitMask);
    if (!supportedBitmaskChecker.isOtherBitmaskSupported(pMeasObject->bit_mask))
    {
        VCCB_PRINT_ERROR("Unsupported parameter(s) in MeasObjectNR! Bitmasks: supported=%u, received=%u\n",
            supportedIEsBitMask, pMeasObject->bit_mask);
        return ERROR;
    }

    // mandatory parameters
    pInstall->minimal.quantityConfigIndex = pMeasObject->quantityConfigIndex;
    if (GOOD !=
        VCCB_Store_ReferenceSignalConfig(&pInstall->minimal.referenceSignalConfig, &pMeasObject->referenceSignalConfig))
    {
        VCCB_PRINT_ERROR("VCCB_StoreMeasObjectNR ERROR, ReferenceSignalConfig ERROR!\n");

        return ERROR;
    }

    if (ERROR == VCCB_StoreQ_OffsetRangeList(&pInstall->minimal.offsetMO, &pMeasObject->offsetMO))
    {
        VCCB_PRINT_ERROR("VCCB_StoreMeasObjectNR ERROR, OffsetRangeList ERROR!\n");
        return ERROR;
    }

    // SSB option - mandatory parameters
    if (pInstall->minimal.referenceSignalConfig.ssbConfigMobility.usage == CI_use)
    {
        if ((pMeasObject->bit_mask & NRRRC_MeasObjectNR_ssbFrequency_present) &&
            (pMeasObject->bit_mask & NRRRC_MeasObjectNR_ssbSubcarrierSpacing_present) &&
            (pMeasObject->bit_mask & NRRRC_smtc1_present))
        {
            pInstall->minimal.ssbFrequency = pMeasObject->ssbFrequency;
            pInstall->minimal.ssbSubcarrierSpacing =
                static_cast<enumSubcarrierSpacing>(pMeasObject->ssbSubcarrierSpacing);
            pInstall->minimal.ncdSsbInfo.usage = false;

            if (GOOD != VCCB_Store_SSB_MTC1(&pInstall->minimal.smtc1, &pMeasObject->smtc1))
            {
                VCCB_PRINT_ERROR("VCCB_StoreMeasObjectNR ERROR, SSB_MTC missing in ssb_ConfigMobility!\n");
                return ERROR;
            }
        }
        else
        {
            VCCB_PRINT_ERROR("VCCB_StoreMeasObjectNR ERROR, mandatory parameters missing in ssb_ConfigMobility!\n");
            return ERROR;
        }
    }

    // Optional parameters
    if (pMeasObject->bit_mask & NRRRC_smtc2_present)
    {
        VCCB_Store_SSB_MTC2(&pInstall->minimal.smtc2, &pMeasObject->smtc2);
    }

    if (pMeasObject->bit_mask & NRRRC_MeasObjectNR_absThreshSS_BlocksConsolidation_present)
    {
        VCCB_Store_ThresholdNR(
            &pInstall->minimal.absThreshSS_BlocksConsolidation, &pMeasObject->absThreshSS_BlocksConsolidation);
    }

    if (pMeasObject->bit_mask & NRRRC_MeasObjectNR_nrofSS_BlocksToAverage_present)
    {
        pInstall->minimal.nrofSS_BlocksToAverage = pMeasObject->nrofSS_BlocksToAverage;
    }

    if (pMeasObject->bit_mask & NRRRC_cellsToAddModList_present)
    {
        if (VCCB_Store_CellsToAddModList(&pInstall->cellsToMeasure, pMeasObject->cellsToAddModList) != GOOD)
        {
            VCCB_PRINT_ERROR("VCCB_StoreMeasObjectNR ERROR, VCCB_Store_CellsToAddModList returned ERROR!\n");
            return ERROR;
        }
    }

    if (pMeasObject->bit_mask & NRRRC_excludedCellsToAddModList_present)
    {
        if (GOOD != VCCB_Store_ExcludedCellsToAddModList(pMeasObject->excludedCellsToAddModList, &pInstall->blackCells))
        {
            return ERROR;
        }
    }

    if (pMeasObject->bit_mask & NRRRC_MeasObjectNR_freqBandIndicatorNR_present)
    {
        pInstall->minimal.freqBandIndicatorNR = pMeasObject->freqBandIndicatorNR;
    }

    if ((pMeasObject->bit_mask & NRRRC_t312_r16_present) &&
        (NRRRC_t312_r16_setup_chosen == pMeasObject->t312_r16.choice))
    {
        pInstall->minimal.T312.useT312 = true;
        pInstall->minimal.T312.timerT312 = pMeasObject->t312_r16.u.setup & 0x7F;
    }
    else
    {
        pInstall->minimal.T312.useT312 = false;
    }

    pInstall->minimal.allowedCells.numOfPciRanges = 0;
    if (pMeasObject->bit_mask & NRRRC_allowedCellsToAddModList_present)
    {
        if (GOOD !=
            VCCB_Store_AllowedCellsToAddModList(pMeasObject->allowedCellsToAddModList, pInstall->minimal.allowedCells))
        {
            return ERROR;
        }
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Store NRRRC_EUTRA_BlackCell / NRRRC_EUTRA_ExcludedCell IE defined in NRRRC_MeasObjectEUTRA
 *
 * @param[in]      src : Pointer to a source object. NRRRC_MeasObjectEUTRA::*blackCellsToAddModListEUTRAN or
 *                 NRRRC_MeasObjectEUTRA::*excludedCellsToAddModListEUTRAN
 * @param[out]     dst : Pointer to configuration already installed on UE.
 *measurementObjectEUTRAUe_type::blackCellsEutra_type*
 * @return         status : GOOD, ERROR / int16_t
 ****************************************************************************/
template <typename T>
static int16_t VCCB_StoreCellsToAddModListEUTRAN(const T *src, blackCellsEutra_type *dst)
{
    constexpr size_t rangeElementsLength = VCCB_ARRAY_COUNT(dst->rangeElements);

    staticUnorderedSet<NRRRC_EUTRA_CellIndex, rangeElementsLength> uniqueExcludedCellIds;
    uint8_t index = 0;

    for (auto *list = src; (NULL != list) && (rangeElementsLength > index); list = list->next, ++index)
    {
        if (!uniqueExcludedCellIds.insert(list->value.cellIndexEUTRA))
        {
            VCCB_PRINT_ERROR(
                "%s ERROR, cell index(%d) duplication detected in excluded/black CellsToAddModListEUTRAN.\n",
                __FUNCTION__, list->value.cellIndexEUTRA);
            return ERROR;
        }
        dst->rangeElements[index].cellIndexEutra = static_cast<uint8_t>(list->value.cellIndexEUTRA);
        dst->rangeElements[index].physCellIdRange.pciStart = list->value.physCellIdRange.start & e_BitMask_10bit;
        if (list->value.physCellIdRange.bit_mask & NRRRC_EUTRA_PhysCellIdRange_range_present)
        {
            dst->rangeElements[index].physCellIdRange.pciType = pciType_range;
            dst->rangeElements[index].physCellIdRange.pciRange =
                static_cast<uint16_t>(list->value.physCellIdRange.range) & e_BitMask_4bit;
        }
        else
        {
            dst->rangeElements[index].physCellIdRange.pciType = pciType_single;
        }
    }
    dst->numItems = index;

    return GOOD;
}

/****************************************************************************
 * @brief           Store ASN defined NRRRC_MeasObjectEUTRA type
 *                  to measurementObjectNRBaseDb_type object.
 *
 * @param[in]      pMeasObject : Pointer to a source object / NRRRC_MeasObjectToAddMod*
 * @param[out]     pInstall : Pointer to configuration already installed on UE. / measurementObjectUe_type*

 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_StoreMeasObjectEUTRA(NRRRC_MeasObjectEUTRA *pMeasObject, measurementObjectEUTRAUe_type *pInstall)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pMeasObject);
    VALID_E_POINT_CHECK_ERROR(pInstall);

    // check if MeasObject contains any unsupported parameters, if yes then return
    const uint8_t supportedIEsBitMask = NRRRC_cellsToAddModListEUTRAN_present |
                                        NRRRC_excludedCellsToAddModListEUTRAN_present |
                                        NRRRC_eutra_Q_OffsetRange_present;

    SupportedBitmask supportedBitmaskChecker(supportedIEsBitMask);
    if (!supportedBitmaskChecker.isOtherBitmaskSupported(pMeasObject->bit_mask))
    {
        VCCB_PRINT_MSG("Unsupported parameter(s) in MeasObjectEUTRA! Bitmasks: supported=%u, received=%u\n",
            supportedIEsBitMask, pMeasObject->bit_mask);
        return ERROR;
    }

    // carrierFreq
    pInstall->minimal.carrierFreq = pMeasObject->carrierFreq;
    pInstall->minimal.overlappedCarrierFreq = pMeasObject->carrierFreq;

    // allowedMeasBandwidth
    pInstall->minimal.allowedMeasBandwidth =
        static_cast<enumEutraAllowedMeasBandwidth_type>(pMeasObject->allowedMeasBandwidth);

    // cellsToRemoveListEUTRAN
    // - not supported

    // cellsToAddModListEUTRAN
    if (pMeasObject->bit_mask & NRRRC_cellsToAddModListEUTRAN_present)
    {
        constexpr size_t eutraCellsAmount = VCCB_ARRAY_COUNT(pInstall->cellsToMeasureEutra.items);

        staticUnorderedSet<NRRRC_EUTRA_PhysCellId, eutraCellsAmount> uniquePhysCellIds;
        uint8_t index = 0;
        for (auto *list = pMeasObject->cellsToAddModListEUTRAN; (NULL != list) && (eutraCellsAmount > index);
             list = list->next, ++index)
        {
            if (!uniquePhysCellIds.insert(list->value.physCellId))
            {
                VCCB_PRINT_ERROR("%s ERROR, PCI duplication detected in cellsToAddModListEUTRAN.\n", __FUNCTION__);
                return ERROR;
            }
            pInstall->cellsToMeasureEutra.items[index].cellIndexEUTRA =
                static_cast<uint8_t>(list->value.cellIndexEUTRA);
            pInstall->cellsToMeasureEutra.items[index].pci = list->value.physCellId;
            pInstall->cellsToMeasureEutra.items[index].cellIndividualOffset =
                static_cast<uint8_t>(list->value.cellIndividualOffset);
        }
        pInstall->cellsToMeasureEutra.numItems = index;
    }

    // blackCellsToRemoveListEUTRAN
    // - not supported

    if (pMeasObject->bit_mask & NRRRC_excludedCellsToAddModListEUTRAN_present)
    {
        if (GOOD !=
            VCCB_StoreCellsToAddModListEUTRAN(pMeasObject->excludedCellsToAddModListEUTRAN, &pInstall->blackCells))
        {
            return ERROR;
        }
    }

    // eutra-PresenceAntennaPort1
    pInstall->minimal.presenceAntennaPort1 = static_cast<uint8_t>(pMeasObject->eutra_PresenceAntennaPort1);

    // eutra-Q-OffsetRange - OPTIONAL
    if (NRRRC_eutra_Q_OffsetRange_present & pMeasObject->bit_mask)
    {
        pInstall->minimal.qOffsetRange = static_cast<enumEutraQOffsetRange>(pMeasObject->eutra_Q_OffsetRange);
    }
    else
    {
        pInstall->minimal.qOffsetRange = eutraQOffsetRange_noUse;
    }

    // widebandRSRQ-Meas
    pInstall->minimal.widebandRSRQMeas = static_cast<uint8_t>(pMeasObject->widebandRSRQ_Meas);

    return GOOD;
}

/****************************************************************************
 * @brief           Store ASN defined NRRRC_MeasObjectToAddMod type
 *                  to measurementObjectUe_type object.
 *
 * @param[in]      pSrc : Pointer to a source object / NRRRC_MeasObjectToAddMod*
 * @param[out]     pInstall : Pointer to configuration already installed on UE. / measurementObjectUe_type*

 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
static int16_t VCCB_StoreMeasObjectToAddMod(NRRRC_MeasObjectToAddMod *pSrc, measurementObjectUe_type *pInstall)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pSrc);
    VALID_E_POINT_CHECK_ERROR(pInstall);

    switch (pSrc->measObject.choice)
    {
        case NRRRC_measObjectNR_chosen:
            pInstall->conf.ratType = measRatNr;
            if (GOOD != VCCB_StoreMeasObjectNR(&pSrc->measObject.u.measObjectNR, &pInstall->conf.rat.nr))
            {
                VCCB_PRINT_ERROR("VCCB_StoreMeasObjectNR ERROR, MO_ID(%d)!\n", pSrc->measObjectId);

                return ERROR;
            }
            break;

        case NRRRC_measObjectEUTRA_chosen:
            pInstall->conf.ratType = measRatEutra;
            if (GOOD != VCCB_StoreMeasObjectEUTRA(&pSrc->measObject.u.measObjectEUTRA, &pInstall->conf.rat.eutra))
            {
                VCCB_PRINT_ERROR("VCCB_StoreMeasObjectEUTRA ERROR, MO_ID(%d)!\n", pSrc->measObjectId);

                return ERROR;
            }
            break;

        default:
            VCCB_PRINT_ERROR("VCCB_Store_MeasObjectToAddMod ERROR, MO_ID(%d) is not supported rat(%u)!\n",
                pSrc->measObjectId, pSrc->measObject.choice);

            return ERROR;
    }

    // mandatory parameters
    pInstall->objectId =
        static_cast<uint8_t>(pSrc->measObjectId - 1);  // max value is 64, NRRRC_MeasObjectId type is auto generated

    // internal fields
    pInstall->internalIdx = MAX_NR_OF_OBJECT_ID;
    pInstall->pending = VCCB_FLAG_ON;
    pInstall->usage = CI_use;
    pInstall->isTainted = VCCB_FLAG_OFF;

    return GOOD;
}

/****************************************************************************
 * @brief Stores MeasObjectToAddModList
 * @param  ptCi           : pointer to UE Context
 * @param  pIE            : pointer to NRRRC_MeasObjectToAddModList structure to be stored
 * @return int16_t        : result of operation
 ****************************************************************************/
static int16_t VCCB_StoreMeasObjectToAddModList(callInfo_type *ptCi, NRRRC_MeasObjectToAddModList_ *pIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pIE);

    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    size_t installedMeasObjects = 0;
    for (; NULL != pIE; pIE = pIE->next)
    {
        // Store MeasObjectToAddMod
        if (VCCB_ARRAY_COUNT(rMeasConf.measurementObjects.installedItems) > installedMeasObjects)
        {
            if (GOOD == VCCB_StoreMeasObjectToAddMod(
                            &pIE->value, &rMeasConf.measurementObjects.installedItems[installedMeasObjects]))
            {
                installedMeasObjects++;
            }
            else
            {
                memset(&rMeasConf.measurementObjects.installedItems[installedMeasObjects], 0,
                    sizeof(measurementObjectUe_type));  // cleanup

                if (pIE->value.measObjectId < 1)
                {
                    VCCB_PRINT_CALL_COMMENT(ptCi, "Invalid measObjectId!\n");
                    continue;
                }
                const uint8_t measIdZeroBased = static_cast<uint8_t>(pIE->value.measObjectId - 1ULL);
                ONBIT(rMeasProc.measurementObjects.foreignIdsToRemove, measIdZeroBased);  // to remove
            }
        }
        else
        {
            if (pIE->value.measObjectId < 1)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "Invalid measObjectId!\n");
                continue;
            }
            const uint8_t measIdZeroBased = static_cast<uint8_t>(pIE->value.measObjectId - 1ULL);
            ONBIT(rMeasProc.measurementObjects.foreignIdsToRemove, measIdZeroBased);  // to remove
        }
    }

    return GOOD;
}

/****************************************************************************
 * @brief Stores ReportConfigToAddModList
 * @param  ptCi           : pointer to UE Context
 * @param  pIE            : pointer to NRRRC_ReportConfigToAddModList structure to be stored
 * @return int16_t        : result of operation
 ****************************************************************************/
static int16_t VCCB_StoreReportConfigToAddModList(callInfo_type *ptCi, NRRRC_ReportConfigToAddModList_ *pIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pIE);

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    // first version removes all received ids
    for (; NULL != pIE; pIE = pIE->next)
    {
        if (pIE->value.reportConfigId < 1)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "Invalid reportConfigId!\n");
            continue;
        }

        const uint8_t measIdZeroBased = static_cast<uint8_t>(pIE->value.reportConfigId - 1ULL);
        ONBIT(rMeasProc.reportConfigurations.foreignIdsToRemove, measIdZeroBased);
    }

    return GOOD;
}

/****************************************************************************
 * @brief Stores MeasIdToAddModList
 * @param  ptCi           : pointer to UE Context
 * @param  pIE            : pointer to NRRRC_MeasIdToAddModList structure to be stored
 * @return int16_t        : result of operation
 ****************************************************************************/
static int16_t VCCB_StoreMeasIdToAddModList(callInfo_type *ptCi, NRRRC_MeasIdToAddModList_ *pIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pIE);

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    // Removes all received ids
    for (; NULL != pIE; pIE = pIE->next)
    {
        if (pIE->value.measId < 1)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "Invalid measId!\n");
            continue;
        }

        const uint8_t measIdZeroBased = static_cast<uint8_t>(pIE->value.measId - 1ULL);
        ONBIT(rMeasProc.measurementIdentities.foreignIdsToRemove, measIdZeroBased);
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Stores NRRRC_FilterConfig object
 *
 * @param[out]      pDst : Pointer to a destination object. / filterConfig_type*
 * @param[in]       pSrc : Pointer to source configuration. / NRRRC_FilterConfig*
 ****************************************************************************/
void VCCB_StoreFilterConfig(filterConfig_type *pDst, NRRRC_FilterConfig *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pDst);
    VALID_E_POINT_CHECK_VOID(pSrc);

    if (NRRRC_filterCoefficientRSRP_present & pSrc->bit_mask)
    {
        pDst->filterCoefficientRSRP = pSrc->filterCoefficientRSRP & 0xF;
    }
    else
    {
        pDst->filterCoefficientRSRP = filterCoefficient_fc4;
    }

    if (NRRRC_filterCoefficientRSRQ_present & pSrc->bit_mask)
    {
        pDst->filterCoefficientRSRQ = pSrc->filterCoefficientRSRQ & 0xF;
    }
    else
    {
        pDst->filterCoefficientRSRQ = filterCoefficient_fc4;
    }

    if (NRRRC_filterCoefficientRS_SINR_present & pSrc->bit_mask)
    {
        pDst->filterCoefficientSINR = pSrc->filterCoefficientRS_SINR & 0xF;
    }
    else
    {
        pDst->filterCoefficientSINR = filterCoefficient_fc4;
    }

    return;
}

/****************************************************************************
 * @brief           Stores NRRRC_QuantityConfigNR object
 *
 * @param[out]      pDst : Pointer to a destination object. / quantityConfigurationNR_type*
 * @param[in]       pSrc : Pointer to source configuration. / NRRRC_QuantityConfigNR*
 ****************************************************************************/
void VCCB_StoreQuantityConfigNR(quantityConfigurationNR_type *pDst, NRRRC_QuantityConfigNR *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pDst);
    VALID_E_POINT_CHECK_VOID(pSrc);

    VCCB_StoreFilterConfig(&pDst->quantityConfigCell.ssbFilterConfig, &pSrc->quantityConfigCell.ssb_FilterConfig);
    VCCB_StoreFilterConfig(&pDst->quantityConfigCell.csRsFilterConfig, &pSrc->quantityConfigCell.csi_RS_FilterConfig);
    pDst->quantityConfigCell.usage = CI_use;

    if (NRRRC_quantityConfigRS_Index_present & pSrc->bit_mask)
    {
        VCCB_StoreFilterConfig(
            &pDst->quantityConfigRS_Index.ssbFilterConfig, &pSrc->quantityConfigRS_Index.ssb_FilterConfig);
        VCCB_StoreFilterConfig(
            &pDst->quantityConfigRS_Index.csRsFilterConfig, &pSrc->quantityConfigRS_Index.csi_RS_FilterConfig);
        pDst->quantityConfigRS_Index.usage = CI_use;
    }
    else
    {
        pDst->quantityConfigRS_Index.usage = CI_no_use;
    }

    return;
}

/****************************************************************************
 * @brief           Stores NRRRC_QuantityConfig object
 *
 * @param[out]      ptCi : pointer to UE Context.
 * @param[in]       pSrc : Pointer to source configuration. / NRRRC_QuantityConfig*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
static int16_t VCCB_StoreQuantityConfig(callInfo_type *ptCi, NRRRC_QuantityConfig *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);
    quantityConfiguration_type *pDst = &rMeasConf.quantityConfigurations.installedItem;

    for (uint8_t index = 0; index < MAX_NR_OF_QUANTITY_CONFIG; ++index)
    {
        pDst->nr[index].usage = CI_no_use;
    }
    pDst->eutra.usage = CI_no_use;

    if (NRRRC_quantityConfigNR_List_present & pSrc->bit_mask)
    {
        uint8_t index = 0;
        for (NRRRC_QuantityConfig::NRRRC__seqof125 *list = pSrc->quantityConfigNR_List; NULL != list;
             list = list->next, ++index)
        {
            VCCB_CHECK_E_RANGE_AND_BREAK(index, MAX_NR_OF_QUANTITY_CONFIG);
            VCCB_StoreQuantityConfigNR(&pDst->nr[index], &list->value);
            pDst->nr[index].usage = CI_use;
        }
    }

    if (NRRRC_quantityConfigEUTRA_present & pSrc->bit_mask)
    {
        VCCB_StoreFilterConfig(&pDst->eutra.filterConfig, &pSrc->quantityConfigEUTRA);
        pDst->eutra.usage = CI_use;
    }

    return GOOD;
}

/****************************************************************************
 * @brief Store NRRRC_GapConfig using delta signalling.
 ****************************************************************************/
template <typename RRCType>
static void VCCB_StoreSMeasureConfig(callInfo_type *ptCi, RRCType &rSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    sMeasure_type &rInstalledSMeasureConfig = FnVCCB_GetMeasurementsConfiguration(*ptCi).sMeasureConfig.installedItem;

    switch (rSrc.choice)
    {
        case NRRRC_ssb_RSRP_chosen:
            rInstalledSMeasureConfig.value = static_cast<uint8_t>(rSrc.u.ssb_RSRP);
            rInstalledSMeasureConfig.choice = choice_SSB;
            rInstalledSMeasureConfig.usage = CI_use;
            break;

        case NRRRC_csi_RSRP_chosen:
            rInstalledSMeasureConfig.value = static_cast<uint8_t>(rSrc.u.csi_RSRP);
            rInstalledSMeasureConfig.choice = choice_CSIRS;
            rInstalledSMeasureConfig.usage = CI_use;
            break;

        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid S-MeasureConfig choice(%u)\n", rSrc.choice);
    }
}

/****************************************************************************
 * @brief Stores MeasConfig
 * @param  ptCi           : pointer to UE Context
 * @param  pIE            : pointer to NRRRC_MeasConfig structure to be stored
 * @return int16_t        : result of operation
 ****************************************************************************/
int16_t VCCB_StoreMeasConfig(callInfo_type *ptCi, NRRRC_MeasConfig *pIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pIE);

    // measObjectToRemoveList
    // - ignore

    // measObjectToAddModList
    if (NRRRC_measObjectToAddModList_present & pIE->bit_mask)
    {
        if (ERROR == VCCB_StoreMeasObjectToAddModList(ptCi, pIE->measObjectToAddModList))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_StoreMeasObjectToAddModList ERROR!\n");
            return ERROR;
        }
    }

    // reportConfigToRemoveList
    // - ignore

    // reportConfigToAddModList
    if (NRRRC_reportConfigToAddModList_present & pIE->bit_mask)
    {
        if (ERROR == VCCB_StoreReportConfigToAddModList(ptCi, pIE->reportConfigToAddModList))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_StoreReportConfigToAddModList ERROR!\n");
            return ERROR;
        }
    }

    // measIdToRemoveList
    // - ignore

    // measIdToAddModList
    if (NRRRC_measIdToAddModList_present & pIE->bit_mask)
    {
        if (ERROR == VCCB_StoreMeasIdToAddModList(ptCi, pIE->measIdToAddModList))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_StoreMeasIdToAddModList ERROR!\n");
            return ERROR;
        }
    }

    // s-MeasureConfig
    if (NRRRC_MeasConfig_s_MeasureConfig_present & pIE->bit_mask)
    {
        VCCB_StoreSMeasureConfig(ptCi, pIE->s_MeasureConfig);
    }

    // quantityConfig
    if (NRRRC_MeasConfig_quantityConfig_present & pIE->bit_mask)
    {
        if (ERROR == VCCB_StoreQuantityConfig(ptCi, &pIE->quantityConfig))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_StoreQuantityConfig ERROR!\n");
            return ERROR;
        }
    }

    // measGapConfig
    if (NRRRC_MeasConfig_measGapConfig_present & pIE->bit_mask)
    {
        if (ERROR == VCCB_StoreMeasGapConfig(ptCi, &pIE->measGapConfig))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_StoreMeasGapConfig ERROR!\n");
            return ERROR;
        }
    }

    // measGapSharingConfig
    // - not supported

    return GOOD;
}