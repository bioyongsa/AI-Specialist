#include "FeatMeasurementsNRRRCMake.hpp"
#include "FeatHo.h"
#include "FeatCommon.h"
#include "FeatFullConfig.h"

#include "ComMacro.h"
#include "ComInclude.h"
#include "ComContainers.hpp"
#include "ComLibUtility.h"
#include "ComUtil.hpp"
#include "ComAsnUtil.hpp"
#include "ComVccbStructUtil.hpp"
#include "ComConsecutiveIdsPool.hpp"
#include "VccbMacro.h"

using asn::util::VCCB_ConnectLinkedList;
using asn::util::VCCB_GlobalAlloc;
using util::ConsecutiveIdsPool;

static struct
{
    struct NRRRC_MeasObjectToRemoveList_ measObjToRemove[MAX_NR_OF_OBJECT_ID_3GPP];
    struct NRRRC_MeasObjectToAddModList_ measObjToAddMod[MAX_NR_OF_OBJECT_ID];
    struct NRRRC_ReportConfigToRemoveList_ rptCfgToRemove[MAX_NR_OF_REPORT_CONFIG_ID_3GPP];
    struct NRRRC_ReportConfigToAddModList_ rptCfgToAddMod[MAX_NR_OF_REPORT_CONFIG_ID];
    struct NRRRC_MeasIdToRemoveList_ measIdToRemove[MAX_NR_OF_MEAS_ID_3GPP];
    struct NRRRC_MeasIdToAddModList_ measIdToAddMod[MAX_NR_OF_MEAS_ID];
} gMeasConf[VCCB_CALL_THREAD_NUM];

namespace
{
inline uint64_t VCCB_GetAllMeasIdIdsToRemove(const callInfo_type &rCi)
{
    const measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(rCi);
    return (rMeasProc.measurementIdentities.itemsToRemove |
            rMeasProc.measurementIdentities.foreignIdsToRemove);
}

inline uint64_t VCCB_GetAllReportConfigIdsToRemove(const callInfo_type &rCi)
{
    const measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(rCi);
    return (rMeasProc.reportConfigurations.idsToRemove |
            rMeasProc.reportConfigurations.foreignIdsToRemove);
}

int16_t VCCB_FillAllowedCellListFullConfig(
    NRRRC__seqof180_ *&allowedCellListToAddMod, const pciRangeElements_type &allowedCells)
{
    allowedCellListToAddMod = nullptr;
    if (allowedCells.numOfPciRanges > 0)
    {
        uint32_t minSize = util::minOfArraySizeAndNumOfElems(allowedCells.pciRanges, allowedCells.numOfPciRanges);
        if (ERROR == VCCB_GlobalAlloc(allowedCellListToAddMod, static_cast<int>(minSize)))
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_GlobalAlloc failed in %s!\n", __FUNCTION__);
            return ERROR;
        }
        for (uint8_t i = 0; i < minSize; ++i)
        {
            auto &currentDst = allowedCellListToAddMod[i].value;
            const auto &pciRange = allowedCells.pciRanges[i];

            currentDst.pci_RangeIndex = pciRange.pciRangeIndex;
            currentDst.pci_Range.bit_mask = 0;  // ranges not supported
            currentDst.pci_Range.start = pciRange.pci;
        }
        if (ERROR == VCCB_ConnectLinkedList(allowedCellListToAddMod, allowedCells.numOfPciRanges))
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in %s!\n", __FUNCTION__);
            return ERROR;
        }
    }
    return GOOD;
}

int16_t VCCB_FillAllowedCellListToRemoveDelta(NRRRC_PCI_RangeIndexList_ *&allowedCellsToRemoveList,
    const pciRangeElements_type &installedPciRanges, const pciRangeElements_type &newPciRanges)
{
    allowedCellsToRemoveList = nullptr;
    if (installedPciRanges.numOfPciRanges <= 0)
    {
        return GOOD;
    }

    simpleVector<uint8_t, MAX_NR_OF_PCI_RANGES> toRemove{};
    for (uint8_t i = 0;
         i < util::minOfArraySizeAndNumOfElems(installedPciRanges.pciRanges, installedPciRanges.numOfPciRanges); i++)
    {
        auto &installedPciRange = installedPciRanges.pciRanges[i];
        bool isMaintained = false;
        for (uint8_t j = 0; j < util::minOfArraySizeAndNumOfElems(newPciRanges.pciRanges, newPciRanges.numOfPciRanges); j++)
        {
            const auto &newPciRange = newPciRanges.pciRanges[j];
            if (newPciRange.pciRangeIndex == installedPciRange.pciRangeIndex)
            {
                isMaintained = true;
                break;
            }
        }
        if (isMaintained)
        {
            continue;
        }
        toRemove.push_back(installedPciRange.pciRangeIndex);
    }

    if (toRemove.empty())
    {
        return GOOD;
    }

    if (ERROR == VCCB_GlobalAlloc(allowedCellsToRemoveList, static_cast<int>(toRemove.size())))
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_GlobalAlloc failed in %s!\n", __FUNCTION__);
        return ERROR;
    }
    for (uint8_t i = 0; i < toRemove.size(); i++)
    {
        allowedCellsToRemoveList[i].value = toRemove[i];
    }
    if (ERROR == VCCB_ConnectLinkedList(allowedCellsToRemoveList, static_cast<int>(toRemove.size())))
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in %s!\n", __FUNCTION__);
        return ERROR;
    }
    return GOOD;
}

int16_t VCCB_FillAllowedCellListToAddModDelta(NRRRC__seqof180_ *&allowedCellListToAddMod,
    const pciRangeElements_type &installedPciRanges, const pciRangeElements_type &newPciRanges)
{
    allowedCellListToAddMod = nullptr;

    if (newPciRanges.numOfPciRanges <= 0)
    {
        return GOOD;
    }

    simpleVector<pciRangeElement_type, MAX_NR_OF_PCI_RANGES> toAddMod{};
    for (uint8_t i = 0;
         i < util::minOfArraySizeAndNumOfElems(newPciRanges.pciRanges, newPciRanges.numOfPciRanges); i++)
    {
        auto &newPciRange = newPciRanges.pciRanges[i];
        bool isInstalled = false;
        bool isModified = false;
        for (uint8_t j = 0;
             j < util::minOfArraySizeAndNumOfElems(installedPciRanges.pciRanges, installedPciRanges.numOfPciRanges); j++)
        {
            const auto &installedPciRange = installedPciRanges.pciRanges[j];
            if (newPciRange.pciRangeIndex == installedPciRange.pciRangeIndex)
            {
                isInstalled = true;
                if (newPciRange.pci != installedPciRange.pci)
                {
                    isModified = true;
                }
                break;
            }
        }
        if (!isInstalled || isModified)
        {
            toAddMod.push_back(newPciRange);
        }
    }

    if (toAddMod.empty())
    {
        return GOOD;
    }

    if (ERROR == VCCB_GlobalAlloc(allowedCellListToAddMod, static_cast<int>(toAddMod.size())))
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_GlobalAlloc failed in %s!\n", __FUNCTION__);
        return ERROR;
    }
    for (uint8_t i = 0; i < toAddMod.size(); i++)
    {
        auto &currentDst = allowedCellListToAddMod[i].value;
        const auto &pciRange = toAddMod[i];
        currentDst.pci_RangeIndex = pciRange.pciRangeIndex;
        currentDst.pci_Range.bit_mask = 0;
        currentDst.pci_Range.start = pciRange.pci;
    }
    if (ERROR == VCCB_ConnectLinkedList(allowedCellListToAddMod, static_cast<int>(toAddMod.size())))
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in %s!\n", __FUNCTION__);
        return ERROR;
    }
    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_FilterConfig object with
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_FilterConfig*
 * @param[in]       pSrc : Pointer to new configuration. / filterConfig_type*
 ****************************************************************************/
void VCCB_FillFilterConfig(NRRRC_FilterConfig *pDst, const filterConfig_type *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pDst);
    VALID_E_POINT_CHECK_VOID(pSrc);

    pDst->bit_mask = 0;

    if (pSrc->filterCoefficientRSRP != filterCoefficient_fc4)
    {
        pDst->filterCoefficientRSRP = static_cast<NRRRC_FilterCoefficient>(pSrc->filterCoefficientRSRP);
        pDst->bit_mask |= NRRRC_filterCoefficientRSRP_present;
    }
    if (pSrc->filterCoefficientRSRQ != filterCoefficient_fc4)
    {
        pDst->filterCoefficientRSRQ = static_cast<NRRRC_FilterCoefficient>(pSrc->filterCoefficientRSRQ);
        pDst->bit_mask |= NRRRC_filterCoefficientRSRQ_present;
    }
    if (pSrc->filterCoefficientSINR != filterCoefficient_fc4)
    {
        pDst->filterCoefficientRS_SINR = static_cast<NRRRC_FilterCoefficient>(pSrc->filterCoefficientSINR);
        pDst->bit_mask |= NRRRC_filterCoefficientRS_SINR_present;
    }

    return;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_MeasTriggerQuantity object
 *                  using VCCB specific measTriggerQuantitySetDb_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_MeasTriggerQuantity*
 * @param[in]       pSrc : reference to a source object. / measTriggerUe_type&
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_MeasTriggerQuantity(NRRRC_MeasTriggerQuantity *pDst, const measTriggerUe_type &rSrc)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pDst);

    switch (rSrc.quantity)
    {
        case choice_rsrp:
            pDst->choice = NRRRC_MeasTriggerQuantity_rsrp_chosen;
            pDst->u.rsrp = (uint8_t)rSrc.value;
            break;
        case choice_rsrq:
            pDst->choice = NRRRC_MeasTriggerQuantity_rsrq_chosen;
            pDst->u.rsrq = (uint8_t)rSrc.value;
            break;
        case choice_sinr:
            pDst->choice = NRRRC_MeasTriggerQuantity_sinr_chosen;
            pDst->u.sinr = (uint8_t)rSrc.value;
            break;
        default:
            VCCB_PRINT_ERROR(
                "ERROR: Invalid measurement trigger quantity chosen (%d) in VCCB_Fill_MeasTriggerQuantity!\n",
                rSrc.quantity);
            return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Returns measTriggerUe_type object responsible for first threshold.
 *
 * @param[in]       from : reference to original field where information is stored.
 * @return          measTriggerUe_type object to return.
 ****************************************************************************/
measTriggerUe_type getFirstThreshold(const measDoubleTriggerUe_type &from)
{
    AUTO_TRACE_FUNC;
    measTriggerUe_type result;
    result.quantity = from.quantity;
    result.value = from.th1_value;
    return result;
}

/****************************************************************************
 * @brief           Returns measTriggerUe_type object responsible for second threshold.
 *
 * @param[in]       from : reference to original field where information is stored.
 * @return          measTriggerUe_type object to return.
 ****************************************************************************/
measTriggerUe_type getSecondThreshold(const measDoubleTriggerUe_type &from)
{
    AUTO_TRACE_FUNC;
    measTriggerUe_type result;
    result.quantity = from.quantity;
    result.value = from.th2_value;
    return result;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_CellsToAddMod object using
 *                  VCCB specific cellToMeasure_type object.
 *
 * @param[out]      pDst : Reference to a destination object. / NRRRC_CellsToAddMod&
 * @param[in]       pSrc : Reference to a source object. / cellToMeasure_type&
 ****************************************************************************/
void VCCB_Fill_CellsToAddMod(NRRRC_CellsToAddMod &pDst, const cellToMeasure_type &pSrc)
{
    AUTO_TRACE_FUNC;

    pDst.physCellId = pSrc.pci;
    pDst.cellIndividualOffset.bit_mask = 0;

    if (pSrc.cellIndividualOffset.rsrpOffsetSSB != qOffset_0)
    {
        pDst.cellIndividualOffset.rsrpOffsetSSB = (NRRRC_Q_OffsetRange)pSrc.cellIndividualOffset.rsrpOffsetSSB;
        pDst.cellIndividualOffset.bit_mask |= NRRRC_rsrpOffsetSSB_present;
    }

    if (pSrc.cellIndividualOffset.rsrqOffsetSSB != qOffset_0)
    {
        pDst.cellIndividualOffset.rsrqOffsetSSB = (NRRRC_Q_OffsetRange)pSrc.cellIndividualOffset.rsrqOffsetSSB;
        pDst.cellIndividualOffset.bit_mask |= NRRRC_rsrqOffsetSSB_present;
    }

    if (pSrc.cellIndividualOffset.sinrOffsetSSB != qOffset_0)
    {
        pDst.cellIndividualOffset.sinrOffsetSSB = (NRRRC_Q_OffsetRange)pSrc.cellIndividualOffset.sinrOffsetSSB;
        pDst.cellIndividualOffset.bit_mask |= NRRRC_sinrOffsetSSB_present;
    }
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_MeasTriggerQuantityOffset
 *                  using VCCB specific measTriggerUe_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_MeasTriggerQuantity*
 * @param[in]       pSrc : reference to a source object. / measTriggerUe_type&
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_MeasTriggerQuantityOffset(NRRRC_MeasTriggerQuantityOffset *pDst, const measTriggerUe_type &rSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);

    switch (rSrc.quantity)
    {
        case choice_rsrp:
            pDst->choice = NRRRC_MeasTriggerQuantity_rsrp_chosen;
            pDst->u.rsrp = rSrc.value;
            break;
        case choice_rsrq:
            pDst->choice = NRRRC_MeasTriggerQuantity_rsrq_chosen;
            pDst->u.rsrq = rSrc.value;
            break;
        case choice_sinr:
            pDst->choice = NRRRC_MeasTriggerQuantity_sinr_chosen;
            pDst->u.sinr = rSrc.value;
            break;
        default:
            VCCB_PRINT_ERROR(
                "ERROR: Invalid measurement trigger quantity offset chosen (%d) in "
                "VCCB_Fill_MeasTriggerQuantityOffset!\n",
                rSrc.quantity);
            return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_MeasTriggerQuantityEUTRA object
 *                  using VCCB specific measTriggerUe_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_MeasTriggerQuantityEUTRA*
 * @param[in]       pSrc : reference to a source object. / measTriggerUe_type&
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_MeasTriggerQuantity(NRRRC_MeasTriggerQuantityEUTRA *pDst, const measTriggerUe_type &rSrc)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pDst);

    switch (rSrc.quantity)
    {
        case choice_rsrp:
            pDst->choice = NRRRC_MeasTriggerQuantityEUTRA_rsrp_chosen;
            pDst->u.rsrp = (uint8_t)rSrc.value;
            break;
        case choice_rsrq:
            pDst->choice = NRRRC_MeasTriggerQuantityEUTRA_rsrq_chosen;
            pDst->u.rsrq = (uint8_t)rSrc.value;
            break;
        case choice_sinr:
            pDst->choice = NRRRC_MeasTriggerQuantityEUTRA_sinr_chosen;
            pDst->u.sinr = (uint8_t)rSrc.value;
            break;
        default:
            VCCB_PRINT_ERROR(
                "ERROR: Invalid measurement trigger quantity chosen (%d) in VCCB_Fill_MeasTriggerQuantity!\n",
                rSrc.quantity);
            return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_EventTriggerConfig object for
 *                  A1 report configuration using VCCB specific
 *                  eventBasedReportConfigurationNRUe_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_EventTriggerConfig*
 * @param[in]       pSrc : Pointer to a source object. / eventBasedReportConfigurationNRUe_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_ReportConfig_A1(NRRRC_EventTriggerConfig *pDst, const eventBasedReportConfigurationNRUe_type *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    pDst->eventId.choice = NRRRC_eventA1_chosen;

    if (VCCB_Fill_MeasTriggerQuantity(&pDst->eventId.u.eventA1.a1_Threshold, pSrc->event.A1.a1_Threshold) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_MeasTriggerQuantity failed in VCCB_Fill_ReportConfig_A1!\n");

        return ERROR;
    }

    pDst->eventId.u.eventA1.reportOnLeave = pSrc->reportOnLeave;
    pDst->eventId.u.eventA1.hysteresis = pSrc->hysteresis;
    pDst->eventId.u.eventA1.timeToTrigger = (NRRRC_TimeToTrigger)pSrc->timeToTrigger;

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_EventTriggerConfig object for
 *                  A2 report configuration using VCCB specific
 *                  eventBasedReportConfigurationNRUe_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_EventTriggerConfig*
 * @param[in]       pSrc : Pointer to a source object. / eventBasedReportConfigurationNRUe_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_ReportConfig_A2(NRRRC_EventTriggerConfig *pDst, const eventBasedReportConfigurationNRUe_type *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    pDst->eventId.choice = NRRRC_eventA2_chosen;

    if (VCCB_Fill_MeasTriggerQuantity(&pDst->eventId.u.eventA2.a2_Threshold, pSrc->event.A2.a2_Threshold) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_MeasTriggerQuantity failed in VCCB_Fill_ReportConfig_A2!\n");

        return ERROR;
    }

    pDst->eventId.u.eventA2.reportOnLeave = pSrc->reportOnLeave;
    pDst->eventId.u.eventA2.hysteresis = pSrc->hysteresis;
    pDst->eventId.u.eventA2.timeToTrigger = (NRRRC_TimeToTrigger)pSrc->timeToTrigger;

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_EventTriggerConfig object for
 *                  A3 report configuration using VCCB specific
 *                  eventBasedReportConfigurationNRUe_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_EventTriggerConfig*
 * @param[in]       pSrc : Pointer to a source object. / eventBasedReportConfigurationNRUe_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_ReportConfig_A3(NRRRC_EventTriggerConfig *pDst, const eventBasedReportConfigurationNRUe_type *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    pDst->eventId.choice = NRRRC_eventA3_chosen;

    if (VCCB_Fill_MeasTriggerQuantityOffset(&pDst->eventId.u.eventA3.a3_Offset, pSrc->event.A3.a3_Offset) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_MeasTriggerQuantityOffset failed in VCCB_Fill_ReportConfig_A3!\n");

        return ERROR;
    }

    pDst->eventId.u.eventA3.reportOnLeave = pSrc->reportOnLeave;
    pDst->eventId.u.eventA3.hysteresis = pSrc->hysteresis;
    pDst->eventId.u.eventA3.timeToTrigger = (NRRRC_TimeToTrigger)pSrc->timeToTrigger;
    pDst->eventId.u.eventA3.useAllowedCellList = FALSE; // currently not supported

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_EventTriggerConfig object for
 *                  A4 report configuration using VCCB specific
 *                  eventBasedReportConfigurationNRUe_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_EventTriggerConfig*
 * @param[in]       pSrc : Pointer to a source object. / eventBasedReportConfigurationNRUe_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_ReportConfig_A4(NRRRC_EventTriggerConfig *pDst, const eventBasedReportConfigurationNRUe_type *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    pDst->eventId.choice = NRRRC_eventA4_chosen;

    if (VCCB_Fill_MeasTriggerQuantity(&pDst->eventId.u.eventA4.a4_Threshold, pSrc->event.A4.a4_Threshold) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_MeasTriggerQuantity failed in VCCB_Fill_ReportConfig_A4!\n");

        return ERROR;
    }

    pDst->eventId.u.eventA4.reportOnLeave = pSrc->reportOnLeave;
    pDst->eventId.u.eventA4.hysteresis = pSrc->hysteresis;
    pDst->eventId.u.eventA4.timeToTrigger = (NRRRC_TimeToTrigger)pSrc->timeToTrigger;
    pDst->eventId.u.eventA4.useAllowedCellList = pSrc->event.A4.useAllowedCellList;

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_EventTriggerConfig object for
 *                  A5 report configuration using  VCCB specific
 *                  eventBasedReportConfigurationNRUe_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_EventTriggerConfig*
 * @param[in]       pSrc : Pointer to a source object. / eventBasedReportConfigurationNRUe_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_ReportConfig_A5(NRRRC_EventTriggerConfig *pDst, const eventBasedReportConfigurationNRUe_type *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    pDst->eventId.choice = NRRRC_eventA5_chosen;

    if (VCCB_Fill_MeasTriggerQuantity(
            &pDst->eventId.u.eventA5.a5_Threshold1, getFirstThreshold(pSrc->event.A5.a5_Thresholds)) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_MeasTriggerQuantity failed in VCCB_Fill_ReportConfig_A5!\n");

        return ERROR;
    }

    if (VCCB_Fill_MeasTriggerQuantity(
            &pDst->eventId.u.eventA5.a5_Threshold2, getSecondThreshold(pSrc->event.A5.a5_Thresholds)) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_MeasTriggerQuantity failed in VCCB_Fill_ReportConfig_A5!\n");

        return ERROR;
    }

    pDst->eventId.u.eventA5.reportOnLeave = pSrc->reportOnLeave;
    pDst->eventId.u.eventA5.hysteresis = pSrc->hysteresis;
    pDst->eventId.u.eventA5.timeToTrigger = (NRRRC_TimeToTrigger)pSrc->timeToTrigger;
    pDst->eventId.u.eventA5.useAllowedCellList = FALSE; // currently not supported

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_EventTriggerConfig object for
 *                  A6 report configuration using VCCB specific
 *                  eventBasedReportConfigurationNRUe_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_EventTriggerConfigInterRAT*
 * @param[in]       pSrc : Pointer to a source object. / eventBasedReportConfigurationNRUe_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_ReportConfig_A6(NRRRC_EventTriggerConfig *pDst, const eventBasedReportConfigurationNRUe_type *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    pDst->eventId.choice = NRRRC_eventA6_chosen;

    if (VCCB_Fill_MeasTriggerQuantityOffset(&pDst->eventId.u.eventA6.a6_Offset, pSrc->event.A6.a6_Offset) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_MeasTriggerQuantityOffset failed in VCCB_Fill_ReportConfig_A6!\n");

        return ERROR;
    }

    pDst->eventId.u.eventA6.reportOnLeave = pSrc->reportOnLeave;
    pDst->eventId.u.eventA6.hysteresis = pSrc->hysteresis;
    pDst->eventId.u.eventA6.timeToTrigger = (NRRRC_TimeToTrigger)pSrc->timeToTrigger;
    pDst->eventId.u.eventA6.useAllowedCellList = FALSE; // currently not supported

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_EventTriggerConfigInterRAT object for
 *                  B1 report configuration using VCCB specific
 *                  eventBasedReportConfigurationInterRatUe_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_EventTriggerConfigInterRAT*
 * @param[in]       pSrc : Pointer to a source object. / eventBasedReportConfigurationInterRatUe_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_ReportConfig_B1Eutra(
    NRRRC_EventTriggerConfigInterRAT *pDst, const eventBasedReportConfigurationInterRatUe_type *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    pDst->eventId.choice = NRRRC_eventB1_chosen;

    if (VCCB_Fill_MeasTriggerQuantity(
            &pDst->eventId.u.eventB1.b1_ThresholdEUTRA, pSrc->event.B1Eutra.b1_thresholdEUTRA) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_MeasTriggerQuantity failed in VCCB_Fill_ReportConfig_B1Eutra!\n");

        return ERROR;
    }

    pDst->eventId.u.eventB1.reportOnLeave = pSrc->reportOnLeave;
    pDst->eventId.u.eventB1.hysteresis = pSrc->hysteresis;
    pDst->eventId.u.eventB1.timeToTrigger = static_cast<NRRRC_TimeToTrigger>(pSrc->timeToTrigger);

    return GOOD;
}

int16_t VCCB_Fill_ReportConfig_condEventA3(
    NRRRC_CondTriggerConfig_r16 *pCondTrigg_r16, const eventBasedReportConfigurationNRUe_type *pSrc)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pCondTrigg_r16);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    pCondTrigg_r16->condEventId.choice = NRRRC_condEventA3_chosen;
    if (VCCB_Fill_MeasTriggerQuantityOffset(
            &pCondTrigg_r16->condEventId.u.condEventA3.a3_Offset, pSrc->event.A3.a3_Offset) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_MeasTriggerQuantityOffset failed in VCCB_Fill_ReportConfig_condEventA3!\n");
        return ERROR;
    }
    pCondTrigg_r16->condEventId.u.condEventA3.hysteresis = pSrc->hysteresis;
    pCondTrigg_r16->condEventId.u.condEventA3.timeToTrigger = static_cast<NRRRC_TimeToTrigger>(pSrc->timeToTrigger);
    return GOOD;
}

int16_t VCCB_Fill_ReportConfig_condTriggerConfig_condEventA3(
    NRRRC_ReportConfigToAddMod *pDst, const reportConfigurationConfUe_type &rNewConf)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pDst);
    pDst->reportConfig.u.reportConfigNR.reportType.choice = NRRRC_condTriggerConfig_r16_chosen;
    NRRRC_CondTriggerConfig_r16 *pCondTrigg_r16 =
        &pDst->reportConfig.u.reportConfigNR.reportType.u.condTriggerConfig_r16;
    if (GOOD != VCCB_Fill_ReportConfig_condEventA3(pCondTrigg_r16, &rNewConf.reportConfiguration.eventBased))
    {
        VCCB_PRINT_ERROR(
            "ERROR: VCCB_Fill_ReportConfig_condEventA3 failed in "
            "VCCB_Fill_ReportConfig_condTriggerConfig_condEventA3!\n");
        return ERROR;
    }
    pCondTrigg_r16->rsType_r16 = static_cast<NRRRC_NR_RS_Type>(rNewConf.rsType);
    return GOOD;
}

int16_t VCCB_Fill_ReportConfig_condEventA5(
    NRRRC_CondTriggerConfig_r16 *pCondTrigg_r16, const eventBasedReportConfigurationNRUe_type *pSrc)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pCondTrigg_r16);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    pCondTrigg_r16->condEventId.choice = NRRRC_condEventA5_chosen;
    if (VCCB_Fill_MeasTriggerQuantity(&pCondTrigg_r16->condEventId.u.condEventA5.a5_Threshold1,
            getFirstThreshold(pSrc->event.A5.a5_Thresholds)) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_MeasTriggerQuantity failed in VCCB_Fill_ReportConfig_condEventA5!\n");
        return ERROR;
    }
    if (VCCB_Fill_MeasTriggerQuantity(&pCondTrigg_r16->condEventId.u.condEventA5.a5_Threshold2,
            getSecondThreshold(pSrc->event.A5.a5_Thresholds)) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_MeasTriggerQuantity failed in VCCB_Fill_ReportConfig_condEventA5!\n");
        return ERROR;
    }
    pCondTrigg_r16->condEventId.u.condEventA5.hysteresis = pSrc->hysteresis;
    pCondTrigg_r16->condEventId.u.condEventA5.timeToTrigger = static_cast<NRRRC_TimeToTrigger>(pSrc->timeToTrigger);
    return GOOD;
}

int16_t VCCB_Fill_ReportConfig_condTriggerConfig_condEventA5(
    NRRRC_ReportConfigToAddMod *pDst, const reportConfigurationConfUe_type &rNewConf)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pDst);
    pDst->reportConfig.u.reportConfigNR.reportType.choice = NRRRC_condTriggerConfig_r16_chosen;
    NRRRC_CondTriggerConfig_r16 *pCondTrigg_r16 =
        &pDst->reportConfig.u.reportConfigNR.reportType.u.condTriggerConfig_r16;
    if (GOOD != VCCB_Fill_ReportConfig_condEventA5(pCondTrigg_r16, &rNewConf.reportConfiguration.eventBased))
    {
        VCCB_PRINT_ERROR(
            "ERROR: VCCB_Fill_ReportConfig_condEventA5 failed in "
            "VCCB_Fill_ReportConfig_condTriggerConfig_condEventA5!\n");
        return ERROR;
    }
    pCondTrigg_r16->rsType_r16 = static_cast<NRRRC_NR_RS_Type>(rNewConf.rsType);
    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_ReportCGI object
 *                  using VCCB specific reportConfigurationInstalledUe_type
 *                  object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_ReportCGI*
 * @param[in]       rNewConf : Reference to a source object conf. / reportConfigurationConfUe_type&
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_ReportConfig_reportCGI(NRRRC_ReportCGI *pDst, const reportConfigurationConfUe_type &rNewConf)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);

    uint16_t pci;
    pDst->bit_mask = 0;

    pci = rNewConf.reportConfiguration.reportCgi.cellForWhichToReportCGI;
    if (pci > MAX_PHYSICAL_CELL_ID)
    {
        return ERROR;
    }
    pDst->cellForWhichToReportCGI = pci;

    if (VCCB_FLAG_ON == rNewConf.reportConfiguration.reportCgi.useAutonomousGaps_flag)
    {
        pDst->bit_mask |= NRRRC_ReportCGI_useAutonomousGaps_r16_present;
        pDst->useAutonomousGaps_r16 = NRRRC_setup;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_ReportCGI_EUTRA object
 *                  using VCCB specific reportConfigurationInstalledUe_type
 *                  object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_ReportCGI_EUTRA*
 * @param[in]       rNewConf : Reference to a source object conf. / reportConfigurationConfUe_type&
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_ReportConfig_reportCGI_EUTRA(
    NRRRC_ReportCGI_EUTRA *pDst, const reportConfigurationConfUe_type &rNewConf)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);

    uint16_t pci;
    pDst->bit_mask = 0;

    pci = rNewConf.reportConfiguration.reportCgiEutra.cellForWhichToReportCGI;
    if (pci > MAX_EUTRA_PHYSICAL_CELL_ID)  // EUTRA-PhysCellId INTEGER (0..503) //PhysCellId INTEGER (0..1007)
    {
        return ERROR;
    }
    pDst->cellForWhichToReportCGI = pci;

    if (VCCB_FLAG_ON == rNewConf.reportConfiguration.reportCgiEutra.useAutonomousGaps_flag)
    {
        pDst->bit_mask |= NRRRC_ReportCGI_EUTRA_useAutonomousGaps_r16_present;
        pDst->useAutonomousGaps_r16 = NRRRC_setup;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills common part of NR RRC Report Config
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Pointer to a destination object.
 * @param[in]       rNewConf : Reference to a source object conf. / reportConfigurationConfUe_type&
 * @return          void
 ****************************************************************************/
template <typename ReportConfigType, typename BitmaskTypeRQR, typename BitmaskTypeNRI, typename BitmaskTypeCLI>
void VCCB_Fill_ReportConfig_Common(callInfo_type *ptCi, ReportConfigType *pDst,
    const reportConfigurationConfUe_type &rNewConf, BitmaskTypeRQR reportQuantityRs_bitmask,
    BitmaskTypeNRI maxNrofRsIndexes_bitmask, BitmaskTypeCLI includeCommonLocationInfo_r16_bitmask)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pDst);

    pDst->bit_mask = 0;
    pDst->rsType = (NRRRC_NR_RS_Type)rNewConf.rsType;
    pDst->reportInterval = (NRRRC_ReportInterval)rNewConf.reportInterval;
    pDst->reportAmount = (NRRRC__enum272)rNewConf.reportAmount;
    pDst->reportQuantityCell.rsrp = rNewConf.reportQuantityCell.rsrp;
    pDst->reportQuantityCell.rsrq = rNewConf.reportQuantityCell.rsrq;
    pDst->reportQuantityCell.sinr = rNewConf.reportQuantityCell.sinr;
    pDst->maxReportCells = rNewConf.maxReportCells;

    if (rNewConf.rat.nr.reportQuantityRsIndexes.usage == CI_use)
    {
        pDst->reportQuantityRS_Indexes.rsrp = rNewConf.rat.nr.reportQuantityRsIndexes.reportQuantity.rsrp;
        pDst->reportQuantityRS_Indexes.rsrq = rNewConf.rat.nr.reportQuantityRsIndexes.reportQuantity.rsrq;
        pDst->reportQuantityRS_Indexes.sinr = rNewConf.rat.nr.reportQuantityRsIndexes.reportQuantity.sinr;
        pDst->bit_mask |= reportQuantityRs_bitmask;
    }

    if (rNewConf.rat.nr.maxNrOfRsIndexesToReport.usage == CI_use)
    {
        pDst->maxNrofRS_IndexesToReport = rNewConf.rat.nr.maxNrOfRsIndexesToReport.value;
        pDst->bit_mask |= maxNrofRsIndexes_bitmask;
    }
    pDst->includeBeamMeasurements = rNewConf.rat.nr.includeBeamMeasurements;

    if (CI_use == rNewConf.rat.nr.includeCommonLocationInfo_r16)
    {
        pDst->bit_mask |= includeCommonLocationInfo_r16_bitmask;
        pDst->includeCommonLocationInfo_r16 = NRRRC_true;
        ptCi->fullConfiguration.interwork.obtainCommonLocation_r16 = TRUE;
    }
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_PeriodicalReportConfig object
 *                  using VCCB specific reportConfigurationInstalledUe_type
 *                  object.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_PeriodicalReportConfig*
 * @param[in]       rNewConf : Reference to a source object conf. / reportConfigurationConfUe_type&
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_ReportConfig_Periodical(
    callInfo_type *ptCi, NRRRC_PeriodicalReportConfig *pDst, const reportConfigurationConfUe_type &rNewConf)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    VCCB_Fill_ReportConfig_Common(ptCi, pDst, rNewConf,
        (unsigned short) NRRRC_PeriodicalReportConfig_reportQuantityRS_Indexes_present,
        (unsigned short) NRRRC_PeriodicalReportConfig_maxNrofRS_IndexesToReport_present,
        (unsigned short) NRRRC_PeriodicalReportConfig_includeCommonLocationInfo_r16_present);

    if (rNewConf.reportConfiguration.periodical.reportAddNeighMeas == CI_use)
    {
        pDst->bit_mask |= NRRRC_reportAddNeighMeas_r16_present;
        pDst->reportAddNeighMeas_r16 = NRRRC_setup;
    }

    pDst->useAllowedCellList = static_cast<ossBoolean>(rNewConf.reportConfiguration.periodical.useWhiteCellList);

    return GOOD;
}

void VCCB_FillReportAddNeighMeasNR(NRRRC_EventTriggerConfig *pDst, const reportConfigurationConfUe_type &rNewConf)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pDst);

    // If addNeighMeasis CI_use (existing operation) or
    // If the reportType is A3 / A4 / A5, set reportAddNeighMeas.
    if (rNewConf.reportConfiguration.eventBased.addNeighMeas != CI_use)
    {
        /* Check ReportType */
        switch (rNewConf.reportType)
        {
            case measReport_A3:
            case measReport_A4:
            case measReport_A5:
                break;

            default:
                return;
        }
    }
    pDst->bit_mask |= NRRRC_reportAddNeighMeas_present;
    pDst->reportAddNeighMeas = NRRRC_setup;
    return;
}

/****************************************************************************
 * @brief           Fills a useT312_r16 of ASN defined NRRRC_EventTriggerConfig object
 *                  call this function only for event based report config - at least one of the Ax
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_EventTriggerConfig*
 * @param[in]       rNewConf : Reference to a source object conf. / reportConfigurationConfUe_type&
 * @return          void :
 ****************************************************************************/
void VCCB_Fill_ReportConfigUseT312(NRRRC_EventTriggerConfig *pDst, const reportConfigurationConfUe_type &rNewConf)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pDst);

    if (true != rNewConf.reportConfiguration.eventBased.useT312)
    {
        return;
    }
    pDst->bit_mask |= NRRRC_useT312_r16_present;
    pDst->useT312_r16 = true;
    return;
}

/****************************************************************************
 * @brief           Fills a part of ASN defined NRRRC_EventTriggerConfig object
 *                  that is common to all event based measurements, using VCCB
 *                  specific eventBasedReportConfigurationNR_type object.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_EventTriggerConfig*
 * @param[in]       rNewConf : Reference to a source object conf. / reportConfigurationConfUe_type&
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_ReportConfig_EventBased_Common(
    callInfo_type *ptCi, NRRRC_EventTriggerConfig *pDst, const reportConfigurationConfUe_type &rNewConf)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    VCCB_Fill_ReportConfig_Common(ptCi, pDst, rNewConf,
        (unsigned int) NRRRC_EventTriggerConfig_reportQuantityRS_Indexes_present,
        (unsigned int) NRRRC_EventTriggerConfig_maxNrofRS_IndexesToReport_present,
        (unsigned int) NRRRC_EventTriggerConfig_includeCommonLocationInfo_r16_present);

    VCCB_FillReportAddNeighMeasNR(pDst, rNewConf);

    // check and set useT312_r16
    VCCB_Fill_ReportConfigUseT312(pDst, rNewConf);

    return GOOD;
}

/****************************************************************************
 * @brief           Fills a part of ASN  object
 *                  that is common to all InterRat measurements, using VCCB
 *                  specific periodicalReportConfigurationInterRat_type object.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Pointer to a destination object.
 * @param[in]       rNewConf : Reference to a source object conf. / reportConfigurationConfUe_type&
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/

template <typename T>
int16_t VCCB_Fill_ReportConfigInterRAT_Common(callInfo_type *ptCi, T *pDst,
    const reportConfigurationConfUe_type &rNewConf, unsigned short includeCommonLocationInfo_r16_bitmask)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    pDst->bit_mask = 0;
    pDst->reportInterval = (NRRRC_ReportInterval)rNewConf.reportInterval;
    pDst->reportAmount = (NRRRC__enum272)rNewConf.reportAmount;
    pDst->reportQuantity.rsrp = rNewConf.reportQuantityCell.rsrp;
    pDst->reportQuantity.rsrq = rNewConf.reportQuantityCell.rsrq;
    pDst->reportQuantity.sinr = rNewConf.reportQuantityCell.sinr;
    pDst->maxReportCells = rNewConf.maxReportCells;

    if (CI_use == rNewConf.rat.nr.includeCommonLocationInfo_r16)
    {
        pDst->bit_mask = static_cast<unsigned char>(pDst->bit_mask | includeCommonLocationInfo_r16_bitmask);
        pDst->includeCommonLocationInfo_r16 = NRRRC_mpsPriorityIndication_r16_true;
        ptCi->fullConfiguration.interwork.obtainCommonLocation_r16 = TRUE;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_EventTriggerConfig object for
 *                  B2 report configuration using VCCB specific
 *                  eventBasedReportConfigurationInterRatUe_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_EventTriggerConfig*
 * @param[in]       pSrc : Pointer to a source object. / eventBasedReportConfigurationInterRatUe_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_ReportConfig_B2Eutra(
    NRRRC_EventTriggerConfigInterRAT *pDst, const eventBasedReportConfigurationInterRatUe_type *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    pDst->eventId.choice = NRRRC_eventB2_chosen;

    if (VCCB_Fill_MeasTriggerQuantity(
            &pDst->eventId.u.eventB2.b2_Threshold1, getFirstThreshold(pSrc->event.B2Eutra.b2_thresholds)) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_MeasTriggerQuantity failed in VCCB_Fill_ReportConfig_B2Eutra!\n");

        return ERROR;
    }

    if (VCCB_Fill_MeasTriggerQuantity(
            &pDst->eventId.u.eventB2.b2_Threshold2EUTRA, getSecondThreshold(pSrc->event.B2Eutra.b2_thresholds)) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_MeasTriggerQuantity failed in VCCB_Fill_ReportConfig_B2Eutra!\n");

        return ERROR;
    }

    pDst->eventId.u.eventB2.reportOnLeave = pSrc->reportOnLeave;
    pDst->eventId.u.eventB2.hysteresis = pSrc->hysteresis;
    pDst->eventId.u.eventB2.timeToTrigger = static_cast<NRRRC_TimeToTrigger>(pSrc->timeToTrigger);

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_ReportConfigToAddMod object with
 *                  a list of report configurations that need to be
 *                  added / modified in UE configuration, basing on diff two
 *                  VCCB specific reportConfigurationInstalledUe_type objects.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_ReportConfigToAddMod*
 * @param[in]       pNew : Pointer to new configuration. / reportConfigurationInstalledUe_type*
 * @return          status : GOOD, ERROR, BREAK / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_ReportConfigToAddMod(
    callInfo_type *ptCi, NRRRC_ReportConfigToAddMod *pDst, reportConfigurationInstalledUe_type *pNew)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pNew);

    auto &rNewConf = pNew->conf;

    if (VCCB_isAssociatedWithCondTriggerConfig(rNewConf))
    {
        VCCB_PRINT_COMMENT("This report config was skipped because it was related to conditional handover!\n");
        return BREAK;
    }

    pDst->reportConfigId =
        static_cast<NRRRC_ReportConfigId>(pNew->objectId + 1);  // need to add 1 to compensate for 1-based indexing

    if ((measReport_B1Eutra == rNewConf.reportType) || (measReport_B2Eutra == rNewConf.reportType))
    {
        pDst->reportConfig.choice = NRRRC_reportConfigInterRAT_chosen;
        pDst->reportConfig.u.reportConfigInterRAT.reportType.choice =
            NRRRC_ReportConfigInterRAT_reportType_eventTriggered_chosen;
        auto &eventTriggered = pDst->reportConfig.u.reportConfigInterRAT.reportType.u.eventTriggered;
        eventTriggered.rsType = static_cast<NRRRC_NR_RS_Type>(rNewConf.rsType);

        int16_t status = VCCB_Fill_ReportConfigInterRAT_Common(
            ptCi, &eventTriggered, rNewConf, NRRRC_EventTriggerConfigInterRAT_includeCommonLocationInfo_r16_present);
        if (status != GOOD)
        {
            VCCB_PRINT_ERROR(
                "ERROR: VCCB_Fill_ReportConfigInterRAT_Common failed in VCCB_Fill_ReportConfigToAddMod!\n");

            return ERROR;
        }
    }
    else if (rNewConf.reportType == measReport_reportCGI)
    {
        pDst->reportConfig.choice = NRRRC_reportConfigNR_chosen;
        pDst->reportConfig.u.reportConfigNR.reportType.choice = NRRRC_ReportConfigNR_reportType_reportCGI_chosen;
        if (VCCB_Fill_ReportConfig_reportCGI(&pDst->reportConfig.u.reportConfigNR.reportType.u.reportCGI, rNewConf) != GOOD)
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_Fill_ReportConfig_reportCGI failed in VCCB_Fill_ReportConfigToAddMod!\n");
            return ERROR;
        }
    }
    else if (rNewConf.reportType == measReport_reportCGIEutra)
    {
        pDst->reportConfig.choice = NRRRC_reportConfigInterRAT_chosen;
        pDst->reportConfig.u.reportConfigInterRAT.reportType.choice =
            NRRRC_ReportConfigInterRAT_reportType_reportCGI_chosen;
        if (VCCB_Fill_ReportConfig_reportCGI_EUTRA(
                &pDst->reportConfig.u.reportConfigInterRAT.reportType.u.reportCGI, rNewConf) != GOOD)
        {
            VCCB_PRINT_ERROR(
                "ERROR: VCCB_Fill_ReportConfig_reportCGI_EUTRA failed in VCCB_Fill_ReportConfigToAddMod!\n");
            return ERROR;
        }
    }
    else
    {
        pDst->reportConfig.choice = NRRRC_reportConfigNR_chosen;
        if (rNewConf.reportType == measReport_periodical)
        {
            pDst->reportConfig.u.reportConfigNR.reportType.choice = NRRRC_ReportConfigNR_reportType_periodical_chosen;
            if (VCCB_Fill_ReportConfig_Periodical(
                    ptCi, &pDst->reportConfig.u.reportConfigNR.reportType.u.periodical, rNewConf) != GOOD)
            {
                VCCB_PRINT_ERROR(
                    "ERROR: VCCB_Fill_ReportConfig_Periodical failed in VCCB_Fill_ReportConfigToAddMod!\n");

                return ERROR;
            }
        }
        else
        {
            pDst->reportConfig.u.reportConfigNR.reportType.choice =
                NRRRC_ReportConfigNR_reportType_eventTriggered_chosen;
            if (VCCB_Fill_ReportConfig_EventBased_Common(
                    ptCi, &pDst->reportConfig.u.reportConfigNR.reportType.u.eventTriggered, rNewConf) != GOOD)
            {
                VCCB_PRINT_ERROR(
                    "ERROR: VCCB_Fill_ReportConfig_EventBased_Common failed in VCCB_Fill_ReportConfigToAddMod!\n");

                return ERROR;
            }
        }
    }

    switch (rNewConf.reportType)
    {
        case measReport_periodical:
            break;

        case measReport_reportCGI:
            break;

        case measReport_reportCGIEutra:
            break;

        case measReport_A1:
            if (VCCB_Fill_ReportConfig_A1(&pDst->reportConfig.u.reportConfigNR.reportType.u.eventTriggered,
                    &rNewConf.reportConfiguration.eventBased) != GOOD)
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_ReportConfig_A1 failed in VCCB_Fill_ReportConfigToAddMod!\n");

                return ERROR;
            }
            break;

        case measReport_A2:
            if (VCCB_Fill_ReportConfig_A2(&pDst->reportConfig.u.reportConfigNR.reportType.u.eventTriggered,
                    &rNewConf.reportConfiguration.eventBased) != GOOD)
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_ReportConfig_A2 failed in VCCB_Fill_ReportConfigToAddMod!\n");

                return ERROR;
            }
            break;

        case measReport_A3:
            if (VCCB_Fill_ReportConfig_A3(&pDst->reportConfig.u.reportConfigNR.reportType.u.eventTriggered,
                    &rNewConf.reportConfiguration.eventBased) != GOOD)
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_ReportConfig_A3 failed in VCCB_Fill_ReportConfigToAddMod!\n");

                return ERROR;
            }
            break;

        case measReport_A4:
            if (VCCB_Fill_ReportConfig_A4(&pDst->reportConfig.u.reportConfigNR.reportType.u.eventTriggered,
                    &rNewConf.reportConfiguration.eventBased) != GOOD)
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_ReportConfig_A4 failed in VCCB_Fill_ReportConfigToAddMod!\n");

                return ERROR;
            }
            break;

        case measReport_A5:
            if (VCCB_Fill_ReportConfig_A5(&pDst->reportConfig.u.reportConfigNR.reportType.u.eventTriggered,
                    &rNewConf.reportConfiguration.eventBased) != GOOD)
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_ReportConfig_A5 failed in VCCB_Fill_ReportConfigToAddMod!\n");

                return ERROR;
            }
            break;

        case measReport_A6:
            if (VCCB_Fill_ReportConfig_A6(&pDst->reportConfig.u.reportConfigNR.reportType.u.eventTriggered,
                    &rNewConf.reportConfiguration.eventBased) != GOOD)
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_ReportConfig_A6 failed in VCCB_Fill_ReportConfigToAddMod!\n");

                return ERROR;
            }
            break;

        case measReport_B1Eutra:
            if (VCCB_Fill_ReportConfig_B1Eutra(&pDst->reportConfig.u.reportConfigInterRAT.reportType.u.eventTriggered,
                    &rNewConf.reportConfiguration.eventInterRat) != GOOD)
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_ReportConfig_B1Eutra failed in VCCB_Fill_ReportConfigToAddMod!\n");

                return ERROR;
            }
            break;

        case measReport_B2Eutra:
            if (VCCB_Fill_ReportConfig_B2Eutra(&pDst->reportConfig.u.reportConfigInterRAT.reportType.u.eventTriggered,
                    &rNewConf.reportConfiguration.eventInterRat) != GOOD)
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_ReportConfig_B2Eutra failed in VCCB_Fill_ReportConfigToAddMod!\n");

                return ERROR;
            }
            break;
        case measReport_periodicalInterRat:
        {
            pDst->reportConfig.choice = NRRRC_reportConfigInterRAT_chosen;
            pDst->reportConfig.u.reportConfigInterRAT.reportType.choice =
                NRRRC_ReportConfigInterRAT_reportType_periodical_chosen;
            auto &periodical = pDst->reportConfig.u.reportConfigInterRAT.reportType.u.periodical;
            int16_t status = VCCB_Fill_ReportConfigInterRAT_Common(
                ptCi, &periodical, rNewConf, NRRRC_PeriodicalReportConfigInterRAT_includeCommonLocationInfo_r16_present);
            VCCB_RETURN_ERROR_ON_CALL_NOT_GOOD(
                ptCi, status, "ERROR: VCCB_Fill_ReportConfigInterRAT_Common failed in %s!\n", __func__);
            break;
        }

        default:
            VCCB_PRINT_ERROR(
                "ERROR: Invalid report configuration type chosen (%hu) in VCCB_Fill_ReportConfigToAddMod!\n",
                rNewConf.reportType);

            return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_QuantityConfigNR object with
 *                  a diff between two VCCB specific
 *                  quantityConfigurationNR_type objects.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_QuantityConfigNR*
 * @param[in]       pInstalled : Pointer to configuration already installed on UE
 *                               (base for the diff). / quantityConfigurationNR_type*
 * @param[in]       pNew : Pointer to new configuration. / quantityConfigurationNR_type*
 * @param[in]       fullConfig : specifies whether pDst should be filled
 *                  with a diff or full configuration. / bool
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_FillQuantityConfigNR(NRRRC_QuantityConfigNR *pDst, const quantityConfigurationNR_type *pInstalled,
    const quantityConfigurationNR_type *pNew, bool fullConfig)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    pDst->bit_mask = 0;

    VCCB_FillFilterConfig(&pDst->quantityConfigCell.ssb_FilterConfig, &pNew->quantityConfigCell.ssbFilterConfig);
    VCCB_FillFilterConfig(&pDst->quantityConfigCell.csi_RS_FilterConfig, &pNew->quantityConfigCell.csRsFilterConfig);

    if ((CI_use == pNew->quantityConfigRS_Index.usage) &&
        (fullConfig || (pInstalled->quantityConfigRS_Index != pNew->quantityConfigRS_Index)))
    {
        VCCB_FillFilterConfig(
            &pDst->quantityConfigRS_Index.ssb_FilterConfig, &pNew->quantityConfigRS_Index.ssbFilterConfig);
        VCCB_FillFilterConfig(
            &pDst->quantityConfigRS_Index.csi_RS_FilterConfig, &pNew->quantityConfigRS_Index.csRsFilterConfig);

        pDst->bit_mask |= NRRRC_quantityConfigRS_Index_present;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_QuantityConfigNR object based
 *                  on current UE configuration.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_QuantityConfigNR*
 * @param[in]       pInstalled : Pointer to configuration already installed on UE
 *                               (base for the diff). / quantityConfigurationNR_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_FillQuantityConfigNR(NRRRC_QuantityConfigNR *pDst, quantityConfigurationNR_type *pInstalled)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);

    pDst->bit_mask = 0;

    VCCB_FillFilterConfig(&pDst->quantityConfigCell.ssb_FilterConfig, &pInstalled->quantityConfigCell.ssbFilterConfig);
    VCCB_FillFilterConfig(
        &pDst->quantityConfigCell.csi_RS_FilterConfig, &pInstalled->quantityConfigCell.csRsFilterConfig);

    if (CI_use == pInstalled->quantityConfigRS_Index.usage)
    {
        VCCB_FillFilterConfig(
            &pDst->quantityConfigRS_Index.ssb_FilterConfig, &pInstalled->quantityConfigRS_Index.ssbFilterConfig);
        VCCB_FillFilterConfig(
            &pDst->quantityConfigRS_Index.csi_RS_FilterConfig, &pInstalled->quantityConfigRS_Index.csRsFilterConfig);

        pDst->bit_mask |= NRRRC_quantityConfigRS_Index_present;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_QuantityConfig object with a diff
 *                  between two arrays of VCCB specific
 *                  quantityConfiguration_type objects.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_QuantityConfig*
 * @param[in]       pInstalled : Pointer to configuration already installed on UE
 *                               (base for the diff). / quantityConfiguration_type*
 * @param[in]       pNew : Pointer to new configuration. / quantityConfiguration_type*
 * @param[in]       fullConfig : specifies whether pDst should be filled
 *                  with a diff or full configuration. / bool
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_FillQuantityConfig(NRRRC_QuantityConfig *pDst, const quantityConfiguration_type *pInstalled,
    const quantityConfiguration_type *pNew, bool fullConfig)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    uint8_t numItems = 0, numHandledItems = 0;
    bool nrChanged = false;

    pDst->bit_mask = 0;

    // Check diff for NR
    for (uint8_t i = 0; i < MAX_NR_OF_QUANTITY_CONFIG; ++i)
    {
        if (CI_use != pNew->nr[i].usage)
        {
            continue;
        }

        numItems++;
        if ((fullConfig) || (pInstalled->nr[i] != pNew->nr[i]))
        {
            nrChanged = true;
        }
    }

    if ((numItems > 0) && (nrChanged))
    {
        if (ERROR == VCCB_GlobalAlloc(pDst->quantityConfigNR_List, numItems))  // Check Init:OK
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_GlobalAlloc failed in VCCB_FillQuantityConfig!\n");

            return ERROR;
        }

        for (uint8_t i = 0; i < MAX_NR_OF_QUANTITY_CONFIG; ++i)
        {
            if (pNew->nr[i].usage == CI_use)
            {
                if (VCCB_FillQuantityConfigNR(&pDst->quantityConfigNR_List[numHandledItems].value, &pInstalled->nr[i],
                        &pNew->nr[i], fullConfig) != GOOD)
                {
                    VCCB_PRINT_ERROR("ERROR: VCCB_FillQuantityConfigNR failed in VCCB_FillQuantityConfig!\n");

                    return ERROR;
                }
                else
                {
                    numHandledItems++;
                    if (numHandledItems == numItems)
                    {
                        break;
                    }
                }
            }
        }

        if (ERROR == VCCB_ConnectLinkedList(pDst->quantityConfigNR_List, numHandledItems))
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in VCCB_FillQuantityConfig!\n");

            return ERROR;
        }

        pDst->bit_mask |= NRRRC_quantityConfigNR_List_present;
    }

    // Check diff for EUTRA
    if ((CI_use == pNew->eutra.usage) && (fullConfig || (pInstalled->eutra != pNew->eutra)))
    {
        VCCB_FillFilterConfig(&pDst->quantityConfigEUTRA, &pNew->eutra.filterConfig);
        pDst->bit_mask |= NRRRC_quantityConfigEUTRA_present;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills NRRRC_ReportConfigToAddModList list, based on
 *                  the supplied arguments.
 *
 * @param[in]       ptCi : Pointer to call configuration / callInfo_type*
 * @param[out]      pDst : Target list of report configurations to add.
 *                         The return value is NULL if there are no configurations
 *                         to add. / NRRRC_ReportConfigToAddModList*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeReportConfigToAddModListInstalled(callInfo_type *ptCi, NRRRC_ReportConfigToAddModList *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);
    uint8_t numItemsToAdd = 0;

    if (ptCi->myThreadId >= MAX_CALL_THREAD_NUM_VCCB)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,  "ERROR: Invalid thread id (%u) in VCCB_MakeReportConfigToAddModListInstalled! "
            "MAX_CALL_THREAD_NUM_VCCB: %u\n", ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

        return ERROR;
    }

    if (VCCB_NoneElementUsed(rMeasConf.reportConfigurations.installedItems))
    {
        *pDst = NULL;

        return GOOD;
    }

    for (auto &rc : rMeasConf.reportConfigurations.installedItems)
    {
        if (CI_use != rc.usage)
        {
            continue;
        }
        const int16_t status = VCCB_Fill_ReportConfigToAddMod(
            ptCi, &(gMeasConf[ptCi->myThreadId].rptCfgToAddMod[numItemsToAdd].value), &rc);
        if (BREAK == status)
        {
            continue;
        }
        if (GOOD != status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "ERROR: VCCB_Fill_ReportConfigToAddMod failed for item with id %hhu in "
                "VCCB_MakeReportConfigToAddModListInstalled!\n",
                rc.objectId);
            return ERROR;
        }
        ++numItemsToAdd;
    }

    if (numItemsToAdd != 0)
    {
        if (ERROR == VCCB_ConnectLinkedList(gMeasConf[ptCi->myThreadId].rptCfgToAddMod, numItemsToAdd))
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "ERROR: VCCB_ConnectLinkedList failed in VCCB_MakeReportConfigToAddModListInstalled!\n");

            return ERROR;
        }
        *pDst = gMeasConf[ptCi->myThreadId].rptCfgToAddMod;
    }
    else
    {
        *pDst = NULL;
    }

    return GOOD;
}

/****************************************************************************
 * @brief Fill NRRRC_GapConfig using delta signalling.
 ****************************************************************************/
template <typename RRCType>
void VCCB_FillGapConfig(RRCType &rDst, const measGapConfig_type &rNew)
{
    AUTO_TRACE_FUNC;

    if (VCCB_FLAG_OFF == rNew.flag)
    {
        rDst.choice = NRRRC_release_5_chosen;
    }
    else
    {
        rDst.choice = NRRRC_setup_5_chosen;

        NRRRC_GapConfig &rDstGapConfig = rDst.u.setup;

        rDstGapConfig.bit_mask = 0;
        rDstGapConfig.gapOffset = rNew.gapConfig.gapOffset;
        rDstGapConfig.mgl = static_cast<NRRRC__enum188>(rNew.gapConfig.mgl);
        rDstGapConfig.mgrp = static_cast<NRRRC__enum189>(rNew.gapConfig.mgrp);
        rDstGapConfig.mgta = static_cast<NRRRC__enum190>(rNew.gapConfig.mgta);
        if (VCCB_FLAG_ON == rNew.gapConfig.m.refServCellIndicatorFlag)
        {
            rDstGapConfig.refServCellIndicator = static_cast<NRRRC__enum191>(rNew.gapConfig.refServCellIndicator);
            rDstGapConfig.bit_mask |= NRRRC_refServCellIndicator_present;
        }
    }
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_SSB_MTC2 structure inside
 *                  NRRRC_MeasObjectNR object using VCCB specific smtc2_type
 *                  and sets the bit masks appropriately.
 *
 * @param[out]      pDst : Pointer to a destination NRRRC_MeasObjectNR
 *                         object. / NRRRC_MeasObjectNR*
 * @param[in]       pSrc : Pointer to a source object. / smtc2_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_SSB_MTC2(NRRRC_MeasObjectNR *pDst, const smtc2_type *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    if (pSrc->usage == CI_use)
    {
        if (pSrc->numPCIs > MAX_NUM_OF_PCIS_SMTC2)
        {
            VCCB_PRINT_ERROR("ERROR: Incorrect number of PCIs (%hu) in VCCB_Fill_SSB_MTC2, maximum allowed: %d!\n",
                pSrc->numPCIs, MAX_NUM_OF_PCIS_SMTC2);

            return ERROR;
        }

        pDst->smtc2.bit_mask = 0;

        if (pSrc->numPCIs > 0)
        {
            if (ERROR == VCCB_GlobalAlloc(pDst->smtc2.pci_List, pSrc->numPCIs))  // Check Init:OK
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_GlobalAlloc failed in VCCB_Fill_SSB_MTC2!\n");

                return ERROR;
            }

            for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(pSrc->PCIs, pSrc->numPCIs); ++i)
            {
                pDst->smtc2.pci_List[i].value = pSrc->PCIs[i];
            }

            if (ERROR == VCCB_ConnectLinkedList(pDst->smtc2.pci_List, pSrc->numPCIs))
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in VCCB_Fill_SSB_MTC2!\n");

                return ERROR;
            }

            pDst->smtc2.bit_mask |= NRRRC_SSB_MTC2_pci_List_present;
        }
        pDst->smtc2.periodicity = (NRRRC__enum260)pSrc->smtc2Periodicity;
        pDst->bit_mask |= NRRRC_smtc2_present;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_SSB_ConfigMobility object with
 *                  a diff between two VCCB specific ssbConfigMobilityUe_type
 *                  objects.
 *
 * @param[out]      pDst : Pointer to ASN defined reference signal
 *                         configuration object containing field for
 *                         SSB config mobility. / NRRRC_ReferenceSignalConfig*
 * @param[in]       pSrc : Pointer to configuration with data to copy from
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_SSB_ConfigMobility_ssbToMeasure(
    NRRRC_ReferenceSignalConfig *pDst, const ssbConfigMobilityUe_type *pSrc)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    switch (pSrc->ssbMeasurementConfiguration.ssbToMeasure)
    {
        case ssbToMeasure_shortBitmap:
            pDst->ssb_ConfigMobility.ssb_ToMeasure.u.setup.choice = NRRRC_SSB_ToMeasure_shortBitmap_chosen;
            if (fnGlobalValueAlloc(&pDst->ssb_ConfigMobility.ssb_ToMeasure.u.setup.u.shortBitmap.value, 1) !=
                0)  // 4 bits   //Check Init:OK
            {
                VCCB_PRINT_ERROR("ERROR: fnGlobalValueAlloc failed in VCCB_Fill_SSB_ConfigMobility_ssbToMeasure!\n");
                return ERROR;
            }
            pDst->ssb_ConfigMobility.ssb_ToMeasure.u.setup.u.shortBitmap.length = 4;
            pDst->ssb_ConfigMobility.ssb_ToMeasure.u.setup.u.shortBitmap.value[0] =
                static_cast<unsigned char>(pSrc->ssbMeasurementConfiguration.ssbValue << 4);
            break;

        case ssbToMeasure_mediumBitmap:
            pDst->ssb_ConfigMobility.ssb_ToMeasure.u.setup.choice = NRRRC_SSB_ToMeasure_mediumBitmap_chosen;
            if (fnGlobalValueAlloc(&pDst->ssb_ConfigMobility.ssb_ToMeasure.u.setup.u.mediumBitmap.value, 1) !=
                0)  // 8 bits  //Check Init:OK
            {
                VCCB_PRINT_ERROR("ERROR: fnGlobalValueAlloc failed in VCCB_Fill_SSB_ConfigMobility_ssbToMeasure!\n");
                return ERROR;
            }
            pDst->ssb_ConfigMobility.ssb_ToMeasure.u.setup.u.mediumBitmap.length = 8;
            pDst->ssb_ConfigMobility.ssb_ToMeasure.u.setup.u.mediumBitmap.value[0] =
                (pSrc->ssbMeasurementConfiguration.ssbValue & 0xFF);
            break;

        case ssbToMeasure_longBitmap:
            pDst->ssb_ConfigMobility.ssb_ToMeasure.u.setup.choice = NRRRC_SSB_ToMeasure_longBitmap_chosen;
            if (fnGlobalValueAlloc(&pDst->ssb_ConfigMobility.ssb_ToMeasure.u.setup.u.longBitmap.value, 8) !=
                0)  // 64 bits   //Check Init:OK
            {
                VCCB_PRINT_ERROR("ERROR: fnGlobalValueAlloc failed in VCCB_Fill_SSB_ConfigMobility_ssbToMeasure!\n");
                return ERROR;
            }
            pDst->ssb_ConfigMobility.ssb_ToMeasure.u.setup.u.longBitmap.length = 64;
            for (uint8_t i = 0; i < 8; ++i)
            {
                pDst->ssb_ConfigMobility.ssb_ToMeasure.u.setup.u.longBitmap.value[i] =
                    static_cast<uint8_t>((pSrc->ssbMeasurementConfiguration.ssbValue >> ((7 - i) * 8)) & 0xFF);
            }
            break;

        default:
            VCCB_PRINT_ERROR("ERROR: Invalid bitmap type chosen (%d) in VCCB_Fill_SSB_ConfigMobility!\n",
                pSrc->ssbMeasurementConfiguration.ssbToMeasure);

            return ERROR;
    }
    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_SSB_ConfigMobility object with
 *                  a diff between two VCCB specific ssbConfigMobilityUe_type
 *                  objects.
 *
 * @param[out]      pDst : Pointer to ASN defined reference signal
 *                         configuration object containing field for
 *                         SSB config mobility. / NRRRC_ReferenceSignalConfig*
 * @param[in]       pInstalled : Pointer to configuration already installed on UE
                                 (base for the diff). / ssbConfigMobilityUe_type*
 * @param[in]       pNew : Pointer to new configuration / ssbConfigMobilityUe_type*
 * @param[in]       fullConfig : Specifies whether pDst should be filled
                                 with a diff or full configuration. / bool
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_SSB_ConfigMobility(NRRRC_ReferenceSignalConfig *pDst, const ssbConfigMobilityUe_type *pInstalled,
    const ssbConfigMobilityUe_type *pNew, bool fullConfig)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    // convert length in bytes to length in bits

    pDst->ssb_ConfigMobility.bit_mask = 0;

    // Check if new measurement configuration includes SSB data
    if (pNew->ssbMeasurementConfiguration.usage == CI_use)
    {
        // Check if SSB configuration is already present on UE and if it needs to be changed
        if (fullConfig || (pInstalled->ssbMeasurementConfiguration != pNew->ssbMeasurementConfiguration))
        {
            pDst->ssb_ConfigMobility.ssb_ToMeasure.choice = NRRRC_setup_11_chosen;

            VCCB_RETURN_ON_ERROR(VCCB_Fill_SSB_ConfigMobility_ssbToMeasure(pDst, pNew),
                "VCCB_Fill_SSB_ConfigMobility_ssbToMeasure ERROR!\n");

            pDst->ssb_ConfigMobility.bit_mask |= NRRRC_SSB_ConfigMobility_ssb_ToMeasure_present;
        }
    }
    else  // SSB not used
    {
        // Deactivate on UE if present
        if ((false == fullConfig) && (pInstalled->ssbMeasurementConfiguration.usage == CI_use))
        {
            if (FOO.VF_SLSI_UESupport)
            {
                // TODO : In case that there is ssb_ToMeasure in source(19A DU) and there is not it(18.3 DU), below
                // code(set ssb_ToMeasure_release) is correct.
                //        But only LSI vender UE could not measure any frequency after receiving ssb_ToMeasure_release.
                //        If not receiving any config(setup nor release), LSI and Q vender UE are working well.(because
                //        ssb_position is same between 19A and 18.3) Therefor, below code wouldn't be used temporary.
            }
            else
            {
                pDst->ssb_ConfigMobility.ssb_ToMeasure.choice = NRRRC_release_11_chosen;
                pDst->ssb_ConfigMobility.bit_mask |= NRRRC_SSB_ConfigMobility_ssb_ToMeasure_present;
            }
        }
    }

    // deriveSSB_IndexFromCell is mandatory
    pDst->ssb_ConfigMobility.deriveSSB_IndexFromCell = static_cast<ossBoolean>(pNew->deriveSSB_IndexFromCell);
    pDst->bit_mask |= NRRRC_ssb_ConfigMobility_present;

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_SSB_ConfigMobility object basing
 *                  on current UE configuration.
 *
 * @param[out]      pDst : Pointer to ASN defined reference signal
 *                         configuration object containing field for
 *                         SSB config mobility. / NRRRC_ReferenceSignalConfig*
 * @param[in]       pInstalled : Pointer to configuration already installed on UE
                                 (base for the diff). / ssbConfigMobilityUe_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_SSB_ConfigMobility(NRRRC_ReferenceSignalConfig *pDst, ssbConfigMobilityUe_type *pInstalled)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);

    pDst->ssb_ConfigMobility.bit_mask = 0;

    // ssb-ToMeasure SetupRelease { SSB-ToMeasure } OPTIONAL
    if (pInstalled->ssbMeasurementConfiguration.usage == CI_use)
    {
        pDst->ssb_ConfigMobility.ssb_ToMeasure.choice = NRRRC_setup_11_chosen;

        VCCB_RETURN_ON_ERROR(VCCB_Fill_SSB_ConfigMobility_ssbToMeasure(pDst, pInstalled),
            "VCCB_Fill_SSB_ConfigMobility_ssbToMeasure ERROR!\n");

        pDst->ssb_ConfigMobility.bit_mask |= NRRRC_SSB_ConfigMobility_ssb_ToMeasure_present;
    }

    // deriveSSB_IndexFromCell BOOLEAN - Mandatory
    pDst->ssb_ConfigMobility.deriveSSB_IndexFromCell = static_cast<ossBoolean>(pInstalled->deriveSSB_IndexFromCell);
    pDst->bit_mask |= NRRRC_ssb_ConfigMobility_present;

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_ReferenceSignalConfig object
 *                  with a diff between two VCCB specific
                    referenceSignalConfigUe_type objects.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_ReferenceSignalConfig*
 * @param[in]       pInstalled : Pointer to configuration already installed on UE
 *                               (base for the diff). / referenceSignalConfigUe_type*
 * @param[in]       pNew : Pointer to new configuration / referenceSignalConfigUe_type*
 * @param[in]       fullConfig : Specifies whether pDst should be filled with
                                 a diff or full configuration. / bool
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_ReferenceSignalConfig(NRRRC_ReferenceSignalConfig *pDst, const referenceSignalConfigUe_type *pInstalled,
    const referenceSignalConfigUe_type *pNew, bool fullConfig)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    pDst->bit_mask = 0;

    if (VCCB_Fill_SSB_ConfigMobility(pDst, &pInstalled->ssbConfigMobility, &pNew->ssbConfigMobility, fullConfig) !=
        GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_SSB_ConfigMobility failed in VCCB_Fill_ReferenceSignalConfig!\n");

        return ERROR;
    }

    return GOOD;
}

int16_t VCCB_Copy_BlackCells(NRRRC_MeasObjectNR *pDst, const blackCellsUe_type *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    if (pSrc->numItems > 0)
    {
        if (ERROR == VCCB_GlobalAlloc(pDst->excludedCellsToAddModList, MAX_NR_OF_PCI_RANGES))  // Check Init:OK
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_GlobalAlloc failed in VCCB_Copy_BlackCells!\n");
            return ERROR;
        }

        for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(pSrc->rangeElements, pSrc->numItems); ++i)
        {
            auto &currentDst = pDst->excludedCellsToAddModList[i].value;
            auto &currentInst = pSrc->rangeElements[i];

            currentDst.pci_RangeIndex = currentInst.pciRangeIndex;
            currentDst.pci_Range.bit_mask = 0;
            currentDst.pci_Range.start = currentInst.pciRange.pciStart;
            if (pciType_range == currentInst.pciRange.pciType)
            {
                currentDst.pci_Range.bit_mask = NRRRC_PCI_Range_range_present;
                currentDst.pci_Range.range = static_cast<NRRRC__enum14>(currentInst.pciRange.pciRange);
            }
        }

        if (ERROR == VCCB_ConnectLinkedList(pDst->excludedCellsToAddModList, pSrc->numItems))
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in VCCB_Copy_BlackCells!\n");
            pDst->excludedCellsToAddModList = NULL;
            return ERROR;
        }
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC__seqof180_ object basing
 *                  on VCCB specific blackCellsUe_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_MeasObjectNR*
 * @param[in]       pInstalled : Pointer to configuration already installed
 *                               on UE (base for the diff). / blackCellsUe_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_BlacklistedCellsToAddMod(NRRRC_MeasObjectNR *pDst, blackCellsUe_type *pInstalled)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);

    pDst->excludedCellsToAddModList = NULL;

    return VCCB_Copy_BlackCells(pDst, pInstalled);
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_ThresholdNR object using VCCB
                    specific thresholdNR_type object.
 *
 * @param[out]      pDst : Reference to a destination object. / NRRRC_ThresholdNR&
 * @param[in]       pSrc : Reference to a source object. / thresholdNR_type&
 ****************************************************************************/
void VCCB_Fill_ThresholdNR(NRRRC_ThresholdNR &pDst, const thresholdNR_type &pSrc)
{
    AUTO_TRACE_FUNC;

    pDst.bit_mask = 0;

    if (pSrc.thresholdRSRP.usage == CI_use)
    {
        pDst.thresholdRSRP = pSrc.thresholdRSRP.value;
        pDst.bit_mask |= NRRRC_thresholdRSRP_present;
    }

    if (pSrc.thresholdRSRQ.usage == CI_use)
    {
        pDst.thresholdRSRQ = pSrc.thresholdRSRQ.value;
        pDst.bit_mask |= NRRRC_thresholdRSRQ_present;
    }

    if (pSrc.thresholdSINR.usage == CI_use)
    {
        pDst.thresholdSINR = pSrc.thresholdSINR.value;
        pDst.bit_mask |= NRRRC_thresholdSINR_present;
    }
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_Q_OffsetRangeList object using
 *                  VCCB specific qOffsetSSBRangeList_type object.
 *
 * @param[out]      pDst : Reference to a destination object. / NRRRC_Q_OffsetRangeList&
 * @param[in]       pSrc : Reference to a source object. / qOffsetSSBRangeList_type&
 ****************************************************************************/
void VCCB_Fill_Q_OffsetRangeList(NRRRC_Q_OffsetRangeList &pDst, const qOffsetSSBRangeList_type &pSrc)
{
    AUTO_TRACE_FUNC;

    pDst.bit_mask = 0;

    if (pSrc.rsrpOffsetSSB != qOffset_0)
    {
        pDst.rsrpOffsetSSB = (NRRRC_Q_OffsetRange)pSrc.rsrpOffsetSSB;
        pDst.bit_mask |= NRRRC_rsrpOffsetSSB_present;
    }

    if (pSrc.rsrqOffsetSSB != qOffset_0)
    {
        pDst.rsrqOffsetSSB = (NRRRC_Q_OffsetRange)pSrc.rsrqOffsetSSB;
        pDst.bit_mask |= NRRRC_rsrqOffsetSSB_present;
    }

    if (pSrc.sinrOffsetSSB != qOffset_0)
    {
        pDst.sinrOffsetSSB = (NRRRC_Q_OffsetRange)pSrc.sinrOffsetSSB;
        pDst.bit_mask |= NRRRC_sinrOffsetSSB_present;
    }
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_ReferenceSignalConfig basing on
 *                  VCCB specific referenceSignalConfigUe_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_ReferenceSignalConfig*
 * @param[in]       pInstalled : Pointer to configuration. / referenceSignalConfigUe_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_ReferenceSignalConfig(NRRRC_ReferenceSignalConfig *pDst, referenceSignalConfigUe_type *pInstalled)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);

    pDst->bit_mask = 0;

    if (pInstalled->ssbConfigMobility.usage == CI_use)
    {
        if (VCCB_Fill_SSB_ConfigMobility(pDst, &pInstalled->ssbConfigMobility) != GOOD)
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_Fill_SSB_ConfigMobility failed in VCCB_Fill_ReferenceSignalConfig!\n");

            return ERROR;
        }
    }

    return GOOD;
}

int16_t VCCB_Copy_CellsToMeasure(NRRRC_CellsToAddModList *pDst, const cellsToMeasureList_type *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    NRRRC_CellsToAddModList cellsToAddMod = NULL;
    *pDst = NULL;

    if (pSrc->numItems > MAX_NR_OF_CELLS_TO_MEASURE)
    {
        VCCB_PRINT_ERROR(
            "ERROR: Installed configuration: incorrect number of cells (%hu) in VCCB_Copy_CellsToMeasure, allowed "
            "range %d - %d!\n",
            pSrc->numItems, 0, MAX_NR_OF_CELLS_TO_MEASURE);

        return ERROR;
    }

    const uint8_t numCellsToAddMod =
        static_cast<uint8_t>(util::minOfArraySizeAndNumOfElems(pSrc->items, pSrc->numItems));
    if (0 == numCellsToAddMod)
    {
        return GOOD;
    }

    if (GOOD != VCCB_GlobalAlloc(cellsToAddMod, MAX_NR_OF_CELLS_TO_MEASURE))  // Check Init:OK
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_GlobalAlloc failed in VCCB_Copy_CellsToMeasure!\n");

        return ERROR;
    }

    for (uint8_t i = 0; i < numCellsToAddMod; ++i)
    {
        VCCB_Fill_CellsToAddMod(cellsToAddMod[i].value, pSrc->items[i]);
    }
    if (ERROR == VCCB_ConnectLinkedList(cellsToAddMod, numCellsToAddMod))
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in VCCB_Copy_CellsToMeasure!\n");

        return ERROR;
    }
    *pDst = cellsToAddMod;

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_CellsToAddModList object basing
 *                  on VCCB specific cellsToMeasureList_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_CellsToAddModList*
 * @param[in]       pSrc : Pointer to the source configuration. / cellsToMeasureList_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_CellsToAddModList(NRRRC_CellsToAddModList *pDst, const cellsToMeasureList_type *pSrc)
{
    AUTO_TRACE_FUNC;

    return VCCB_Copy_CellsToMeasure(pDst, pSrc);
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_MeasObjectNR type
 *                  basing on supplied configuration.
 *
 * @param[out]      pDst : Pointer to a destination object
 * @param[in]       pInstalled : Pointer to measurement object configuration
 * @param[in]       pCell : Pointer to (new) serving cell
 * @return          status : GOOD, ERROR
 ****************************************************************************/
int16_t VCCB_Fill_MeasObjectNR(
    NRRRC_MeasObjectNR *pDst, measurementObjectNRUe_type *pInstalled, VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pCell);

    pDst->bit_mask = 0;

    bool condSSBorAssociatedSSB = VCCB_CheckCondSsbOrAssociatedSsb(pInstalled->minimal.referenceSignalConfig);
    bool condIntraFreqConnected = condSSBorAssociatedSSB && (pInstalled->minimal.ssbFrequency == pCell->ssbArfcn) &&
                                  (pInstalled->minimal.ssbSubcarrierSpacing == pCell->nrScsDl);

    if (condSSBorAssociatedSSB)
    {
        // ssbFrequency
        pDst->ssbFrequency = FnVCCB_GetRrcMeasObjectNrSsbFrequency(pInstalled->minimal);
        pDst->bit_mask |= NRRRC_MeasObjectNR_ssbFrequency_present;

        // ssbSubcarrierSpacing
        pDst->ssbSubcarrierSpacing = static_cast<NRRRC_SubcarrierSpacing>(FnVCCB_GetRrcMeasObjectNrSsbScs(pInstalled->minimal));
        pDst->bit_mask |= NRRRC_MeasObjectNR_ssbSubcarrierSpacing_present;

        // smtc1
        auto smtc1 = FnVCCB_GetRrcMeasObjectNrSsbSmtc1(pInstalled->minimal);
        if (VCCB_Fill_SSB_MTC1(&pDst->smtc1, &smtc1) != GOOD)
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_Fill_SSB_MTC1 failed in VCCB_Fill_MeasObjectNR!\n");
            return ERROR;
        }
        pDst->bit_mask |= NRRRC_smtc1_present;

        // absThreshSS_BlocksConsolidation
        VCCB_Fill_ThresholdNR(
            pDst->absThreshSS_BlocksConsolidation, pInstalled->minimal.absThreshSS_BlocksConsolidation);

        pDst->bit_mask |= NRRRC_MeasObjectNR_absThreshSS_BlocksConsolidation_present;

        // nrofSS_BlocksToAverage
        if (pInstalled->minimal.nrofSS_BlocksToAverage >= 2 &&
            pInstalled->minimal.nrofSS_BlocksToAverage <= NRRRC_maxNrofSS_BlocksToAverage)
        {
            pDst->nrofSS_BlocksToAverage = pInstalled->minimal.nrofSS_BlocksToAverage;
            pDst->bit_mask |= NRRRC_MeasObjectNR_nrofSS_BlocksToAverage_present;
        }
    }

    if (condIntraFreqConnected)
    {
        // smtc2
        if (VCCB_Fill_SSB_MTC2(pDst, &pInstalled->minimal.smtc2) != GOOD)
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_Fill_SSB_MTC2 failed in VCCB_Fill_MeasObjectNR!\n");
            return ERROR;
        }
    }

    // referenceSignalConfig
    if (VCCB_Fill_ReferenceSignalConfig(&pDst->referenceSignalConfig, &pInstalled->minimal.referenceSignalConfig) !=
        GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_ReferenceSignalConfig failed in VCCB_Fill_MeasObjectToAddMod!\n");

        return ERROR;
    }

    // quantityConfigIndex
    pDst->quantityConfigIndex = pInstalled->minimal.quantityConfigIndex;

    // offsetMO
    VCCB_Fill_Q_OffsetRangeList(pDst->offsetMO, pInstalled->minimal.offsetMO);

    // cellsToAddModList
    if (VCCB_Fill_CellsToAddModList(&pDst->cellsToAddModList, &pInstalled->cellsToMeasure) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_CellsToAddModList failed in VCCB_Fill_MeasObjectToAddMod!\n");

        return ERROR;
    }
    if (pDst->cellsToAddModList != NULL)
    {
        pDst->bit_mask |= NRRRC_cellsToAddModList_present;
    }

    // freqBandIndicatorNR-v1530
    if (0 != pInstalled->minimal.freqBandIndicatorNR)
    {
        pDst->freqBandIndicatorNR = pInstalled->minimal.freqBandIndicatorNR;
        pDst->bit_mask |= NRRRC_MeasObjectNR_freqBandIndicatorNR_present;
    }

    // if t312 timer in use
    if (true == pInstalled->minimal.T312.useT312)
    {
        // update NRRRC_MeasObjectNR
        pDst->t312_r16.choice = NRRRC_t312_r16_setup_chosen;
        pDst->t312_r16.u.setup = static_cast<NRRRC_T312_r16>(pInstalled->minimal.T312.timerT312);
        pDst->bit_mask |= NRRRC_t312_r16_present;
    }

    // blackCellsToAddModList
    if (VCCB_Fill_BlacklistedCellsToAddMod(pDst, &pInstalled->blackCells) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_BlacklistedCellsToAddMod failed in VCCB_Fill_MeasObjectToAddMod!\n");

        return ERROR;
    }
    if (pDst->excludedCellsToAddModList != NULL)
    {
        pDst->bit_mask |= NRRRC_excludedCellsToAddModList_present;
    }

    // allowedCellsToAddModList
    if (ERROR == VCCB_FillAllowedCellListFullConfig(pDst->allowedCellsToAddModList, pInstalled->minimal.allowedCells))
    {
        return ERROR;
    }
    if (pDst->allowedCellsToAddModList != NULL)
    {
        pDst->bit_mask |= NRRRC_allowedCellsToAddModList_present;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_MeasObjectEUTRA object basing
 *                  on VCCB specific cellsToMeasureListEutra_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_MeasObjectEUTRA*
 * @param[in]       pInstalled : Pointer to configuration already installed
 *                               on UE (base for the diff). / cellsToMeasureListEutra_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_CellsToAddModListEUTRA(NRRRC_MeasObjectEUTRA *pDst, cellsToMeasureListEutra_type *pInstalled)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);

    struct NRRRC_MeasObjectEUTRA::NRRRC__seqof178 *cellsToAddModListEUTRAN = NULL;

    NRRRC_EUTRA_Cell *cellsToAddMod = NULL;
    pDst->cellsToAddModListEUTRAN = NULL;

    if (!IS_VALID_CELLS_TO_MEAS_CELL_INDEX(pInstalled->numItems))
    {
        VCCB_PRINT_ERROR(
            "ERROR: Installed configuration: incorrect number of cells (%hu) in VCCB_Fill_CellsToAddModListEUTRA, "
            "allowed range %d - %d!\n",
            pInstalled->numItems, 0, MAX_EUTRA_OF_CELLS_TO_MEASURE);

        return ERROR;
    }

    if (0 == pInstalled->numItems)
    {
        return GOOD;
    }

    if (GOOD != VCCB_GlobalAlloc(cellsToAddModListEUTRAN, MAX_EUTRA_OF_CELLS_TO_MEASURE))  // Check Init:OK
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_GlobalAlloc failed in VCCB_Fill_CellsToAddModListEUTRA!\n");

        return ERROR;
    }

    int count = 0;
    for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(pInstalled->items, pInstalled->numItems); ++i)
    {
        if (eutraQOffsetRange_0 == pInstalled->items[i].cellIndividualOffset) continue;

        cellsToAddMod = &cellsToAddModListEUTRAN[count].value;
        cellsToAddMod->cellIndexEUTRA = pInstalled->items[i].cellIndexEUTRA;
        cellsToAddMod->physCellId = pInstalled->items[i].pci;
        cellsToAddMod->cellIndividualOffset = (NRRRC_EUTRA_Q_OffsetRange)pInstalled->items[i].cellIndividualOffset;
        count++;
    }

    if (count == 0)
    {
        pDst->cellsToAddModListEUTRAN = NULL;
        return GOOD;
    }

    if (ERROR == VCCB_ConnectLinkedList(cellsToAddModListEUTRAN, count))
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in VCCB_Fill_CellsToAddModListEUTRA!\n");
        return ERROR;
    }
    pDst->cellsToAddModListEUTRAN = cellsToAddModListEUTRAN;

    return GOOD;
}

int16_t VCCB_Copy_BlackCellsToAddModEutra(NRRRC_MeasObjectEUTRA *pDst, const blackCellsEutra_type *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    pDst->excludedCellsToAddModListEUTRAN = NULL;

    if (pSrc->numItems > 0)
    {
        if (ERROR == VCCB_GlobalAlloc(pDst->excludedCellsToAddModListEUTRAN, VCCB_ARRAY_COUNT(pSrc->rangeElements)))
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_GlobalAlloc failed in VCCB_Copy_BlackCellsEutraToAddMod!\n");
            return ERROR;
        }

        for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(pSrc->rangeElements, pSrc->numItems); ++i)
        {
            auto &currentDst = pDst->excludedCellsToAddModListEUTRAN[i].value;
            auto &currentInst = pSrc->rangeElements[i];

            currentDst.cellIndexEUTRA = currentInst.cellIndexEutra;
            currentDst.physCellIdRange.bit_mask = 0;

            currentDst.physCellIdRange.start = currentInst.physCellIdRange.pciStart;
            if (pciType_range == currentInst.physCellIdRange.pciType)
            {
                currentDst.physCellIdRange.bit_mask = NRRRC_EUTRA_PhysCellIdRange_range_present;
                currentDst.physCellIdRange.range = static_cast<NRRRC__enum256>(currentInst.physCellIdRange.pciRange);
            }
        }

        if (ERROR == VCCB_ConnectLinkedList(pDst->excludedCellsToAddModListEUTRAN, pSrc->numItems))
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in VCCB_Copy_BlackCellsEutraToAddMod!\n");
            pDst->excludedCellsToAddModListEUTRAN = NULL;
            return ERROR;
        }
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC__seqof179_ object basing
 *                  on VCCB specific blackCellsElementEutra_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_MeasObjectEUTRA*
 * @param[in]       pInstalled : Pointer to configuration already installed
 *                               on UE (base for the diff). / blackCellsElementEutra_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_BlacklistedCellsToAddModEutra(NRRRC_MeasObjectEUTRA *pDst, blackCellsEutra_type *pInstalled)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);

    pDst->excludedCellsToAddModListEUTRAN = NULL;

    return VCCB_Copy_BlackCellsToAddModEutra(pDst, pInstalled);
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_MeasObjectEUTRA type
 *                  basing on supplied configuration.
 *                  Prepared MeasObjectEUTRA will be sent to a DU.
 *
 * @param[out]      pDst : Pointer to a destination object
 * @param[in]       pInstalled : Pointer to measurement object configuration
 * @return          status : GOOD, ERROR
 ****************************************************************************/
int16_t VCCB_Fill_MeasObjectEUTRA(NRRRC_MeasObjectEUTRA *pDst, const measurementObjectEUTRADu_type *pInstalled)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);

    pDst->bit_mask = 0;

    // carrierFreq
    pDst->carrierFreq = pInstalled->overlappedCarrierFreq;

    // allowedMeasBandwidth
    pDst->allowedMeasBandwidth = static_cast<NRRRC_EUTRA_AllowedMeasBandwidth>(pInstalled->allowedMeasBandwidth);

    // cellsToRemoveListEUTRAN
    // - not supported

    // cellsToAddModListEUTRAN
    // - not supported

    // blackCellsToRemoveListEUTRAN
    // - not supported

    // blackCellsToAddModListEUTRAN
    // - not supported

    // eutra-PresenceAntennaPort1
    pDst->eutra_PresenceAntennaPort1 = static_cast<NRRRC_EUTRA_PresenceAntennaPort1>(pInstalled->presenceAntennaPort1);

    // eutra-Q-OffsetRange - OPTIONAL
    // - not supported

    // widebandRSRQ-Meas
    pDst->widebandRSRQ_Meas = static_cast<ossBoolean>(pInstalled->widebandRSRQMeas);

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_MeasObjectEUTRA type
 *                  basing on supplied configuration.
 *
 * @param[out]      pDst : Pointer to a destination object
 * @param[in]       pInstalled : Pointer to measurement object configuration
 * @param[in]       pCell : Pointer to (new) serving cell
 * @return          status : GOOD, ERROR
 ****************************************************************************/
int16_t VCCB_Fill_MeasObjectEUTRA(
    NRRRC_MeasObjectEUTRA *pDst, measurementObjectEUTRAUe_type *pInstalled, VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pCell);

    pDst->bit_mask = 0;

    // carrierFreq
    pDst->carrierFreq = pInstalled->minimal.overlappedCarrierFreq;

    // allowedMeasBandwidth
    pDst->allowedMeasBandwidth =
        static_cast<NRRRC_EUTRA_AllowedMeasBandwidth>(pInstalled->minimal.allowedMeasBandwidth);

    // cellsToRemoveListEUTRAN

    // cellsToAddModListEUTRAN
    if (VCCB_Fill_CellsToAddModListEUTRA(pDst, &pInstalled->cellsToMeasureEutra) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_CellsToAddModListEUTRA failed in VCCB_Fill_MeasObjectEUTRA!\n");
        return ERROR;
    }
    if (pDst->cellsToAddModListEUTRAN != NULL)
    {
        pDst->bit_mask |= NRRRC_cellsToAddModListEUTRAN_present;
    }

    // blackCellsToRemoveListEUTRAN - not filled on purpose

    // blackCellsToAddModListEUTRAN
    if (VCCB_Fill_BlacklistedCellsToAddModEutra(pDst, &pInstalled->blackCells) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_BlacklistedCellsToAddModEutra failed in VCCB_Fill_MeasObjectEUTRA!\n");

        return ERROR;
    }
    if (pDst->excludedCellsToAddModListEUTRAN != NULL)
    {
        pDst->bit_mask |= NRRRC_excludedCellsToAddModListEUTRAN_present;
    }

    // eutra-PresenceAntennaPort1
    pDst->eutra_PresenceAntennaPort1 =
        static_cast<NRRRC_EUTRA_PresenceAntennaPort1>(pInstalled->minimal.presenceAntennaPort1);

    // eutra-Q-OffsetRange - OPTIONAL
    if (eutraQOffsetRange_noUse != pInstalled->minimal.qOffsetRange)
    {
        pDst->bit_mask |= NRRRC_eutra_Q_OffsetRange_present;
        pDst->eutra_Q_OffsetRange = static_cast<NRRRC_EUTRA_Q_OffsetRange>(pInstalled->minimal.qOffsetRange);
    }

    // widebandRSRQ-Meas
    pDst->widebandRSRQ_Meas = static_cast<ossBoolean>(pInstalled->minimal.widebandRSRQMeas);

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_Q_OffsetRangeList object using
 *                  DEFAULT dB0 values
 *
 * @param[out]      pDst : Reference to a destination object. / NRRRC_Q_OffsetRangeList&
 ****************************************************************************/
void VCCB_Fill_Q_OffsetRangeList_Default_dB0(NRRRC_Q_OffsetRangeList &pDst)
{
    AUTO_TRACE_FUNC;
    pDst.bit_mask = 0;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_MeasObjectNR type
 *                  basing on supplied configuration.
 *                  Prepared MeasObjectNR will be sent to a DU.
 *
 * @param[out]      pDst : Pointer to a destination object
 * @param[in]       pInstalled : Pointer to measurement object configuration
 * @return          status : GOOD, ERROR
 ****************************************************************************/
int16_t VCCB_Fill_MeasObjectNR(NRRRC_MeasObjectNR *pDst, const measurementObjectNRDu_type *pInstalled)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);

    pDst->bit_mask = 0;

    // ssbFrequency - OPTIONAL
    pDst->ssbFrequency = pInstalled->ssbFrequency;
    pDst->bit_mask |= NRRRC_MeasObjectNR_ssbFrequency_present;

    // ssbSubcarrierSpacing - OPTIONAL
    pDst->ssbSubcarrierSpacing = static_cast<NRRRC_SubcarrierSpacing>(pInstalled->ssbSubcarrierSpacing);
    pDst->bit_mask |= NRRRC_MeasObjectNR_ssbSubcarrierSpacing_present;

    // smtc1 - OPTIONAL
    if (GOOD != VCCB_Fill_SSB_MTC1(&pDst->smtc1, &pInstalled->smtc1))
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_SSB_MTC1 failed in VCCB_Fill_MeasObjectNR!\n");
        return ERROR;
    }
    pDst->bit_mask |= NRRRC_smtc1_present;

    // smtc2 - OPTIONAL
    // - not supported

    // refFreqCSI-RS - OPTIONAL
    // - not supported

    // referenceSignalConfig
    // - hard coded value
    referenceSignalConfigUe_type referenceSignalConfig;
    memset(&referenceSignalConfig, 0, sizeof(referenceSignalConfig));
    referenceSignalConfig.ssbConfigMobility.usage = CI_use;

    if (GOOD != VCCB_Fill_ReferenceSignalConfig(&pDst->referenceSignalConfig, &referenceSignalConfig))
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_ReferenceSignalConfig failed in VCCB_Fill_MeasObjectNR!\n");
        return ERROR;
    }

    // absThreshSS-BlocksConsolidation - OPTIONAL
    // - not supported

    // absThreshCSI-RS-Consolidation - OPTIONAL
    // - not supported

    // nrofSS-BlocksToAverage - OPTIONAL
    // - not supported

    // nrofCSI-RS-ResourcesToAverage - OPTIONAL
    // - not supported

    // quantityConfigIndex
    // - hard coded value
    pDst->quantityConfigIndex = 1;

    // offsetMO
    // - hard coded default value
    VCCB_Fill_Q_OffsetRangeList_Default_dB0(pDst->offsetMO);

    // cellsToRemoveList - OPTIONAL
    // - not supported

    // cellsToAddModList - OPTIONAL
    // - not supported

    // blackCellsToRemoveList - OPTIONAL
    // - not supported

    // blackCellsToAddModList - OPTIONAL
    // - not supported

    // whiteCellsToRemoveList - OPTIONAL
    // - not supported

    // whiteCellsToAddModList - OPTIONAL
    // - not supported

    // freqBandIndicatorNR - OPTIONAL
    // - not supported

    // measCycleSCell - OPTIONAL
    // - not supported

    // smtc3list-r16 - OPTIONAL
    // - not supported

    // rmtc-Config-r16 - OPTIONAL
    // - not supported

    // t312-r16 - OPTIONAL
    // - not supported

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_MeasObjectToAddMod type
 *                  basing on supplied configuration.
 *                  Prepared MeasObjectToAddMod will be sent to a DU.
 *
 * @param[out]      pDst : Pointer to a destination object / NRRRC_MeasObjectToAddMod*
 * @param[in]       pInstalled : Pointer to measuremen object
 *                  configuration. / measurementObjectDu_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_MeasObjectToAddMod(NRRRC_MeasObjectToAddMod *pDst, const measurementObjectDu_type *pInstalled)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);

    pDst->measObjectId =
        static_cast<NRRRC_MeasObjectId>(pInstalled->objectId + 1);  // need to add 1 to compensate for 1-based indexing

    switch (pInstalled->ratType)
    {
        case measRatNr:
            pDst->measObject.choice = NRRRC_measObjectNR_chosen;

            if (GOOD != VCCB_Fill_MeasObjectNR(&pDst->measObject.u.measObjectNR, &pInstalled->rat.nr))
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_MeasObjectNR failed in VCCB_Fill_MeasObjectToAddMod!\n");
                return ERROR;
            }
            break;

        case measRatEutra:
            pDst->measObject.choice = NRRRC_measObjectEUTRA_chosen;

            if (GOOD != VCCB_Fill_MeasObjectEUTRA(&pDst->measObject.u.measObjectEUTRA, &pInstalled->rat.eutra))
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_MeasObjectEUTRA failed in VCCB_Fill_MeasObjectToAddMod!\n");
                return ERROR;
            }
            break;

        default:
            VCCB_PRINT_ERROR("ERROR: Invalid ratType(%u) in VCCB_Fill_MeasObjectToAddMod!\n", pInstalled->ratType);
            return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills NRRRC_MeasObjectToAddModList list for DU common
 *
 * @param[in]       ptCi : Pointer to call configuration / callInfo_type*
 * @param[out]      pDst : Target list of measurement objects to add.
 *                         The return value is NULL if there are no objects
 *                         to add. / NRRRC_MeasObjectToAddModList*
 * @param[in]       pMoDuToAddMod : source data - DU's MO list
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeMeasObjectToAddModListDuCommon(
    callInfo_type *ptCi, NRRRC_MeasObjectToAddModList *pDst, const moListMgap_type *pMoDuToAddMod)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pMoDuToAddMod);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int numAddMod = 0;
    const measurementObjectDu_type *pMoMgap = NULL;

    *pDst = NULL;

    for (uint8_t idx = 0; idx < util::minOfArraySizeAndNumOfElems(pMoDuToAddMod->items, pMoDuToAddMod->numItems); idx++)
    {
        pMoMgap = &pMoDuToAddMod->items[idx];

        if (ERROR ==
            VCCB_Fill_MeasObjectToAddMod(&(gMeasConf[ptCi->myThreadId].measObjToAddMod[numAddMod].value), pMoMgap))
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "ERROR: VCCB_Fill_MeasObjectToAddMod failed for measurement object ID(%u) in "
                "VCCB_MakeMeasObjectToAddModListDuCommon!\n",
                pMoMgap->objectId + 1);
            return ERROR;
        }

        numAddMod++;
    }

    if (0 == numAddMod)
    {
        return GOOD;
    }

    if (ERROR == VCCB_ConnectLinkedList(gMeasConf[ptCi->myThreadId].measObjToAddMod, numAddMod))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "ERROR: VCCB_ConnectLinkedList failed in VCCB_MakeMeasObjectToAddModListDuCommon!\n");
        return ERROR;
    }

    *pDst = gMeasConf[ptCi->myThreadId].measObjToAddMod;

    return GOOD;
}

/****************************************************************************
 * @brief           Fills NRRRC_MeasObjectToAddModList list for DU with diff
 *
 * @param[in]       ptCi : Pointer to call configuration / callInfo_type*
 * @param[out]      pDst : Target list of measurement objects to add.
 *                         The return value is NULL if there are no objects
 *                         to add. / NRRRC_MeasObjectToAddModList*
 * @param[in]       pMoDuList : source data - DU's MO list
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeMeasObjectToAddModListDuDiff(
    callInfo_type *ptCi, NRRRC_MeasObjectToAddModList *pDst, const moListMgap_type *pMoDuList)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pMoDuList);

    const mGapCallConfiguration_type &rmGapConfig = ptCi->measurementsConfigShared.mGapConfiguration;
    moListMgap_type moDuToAddMod;

    measurementObjectDu_type *pMoEnd = std::set_difference(pMoDuList->items,
        pMoDuList->items + pMoDuList->numItems,
        rmGapConfig.moDuInstalled.items,
        rmGapConfig.moDuInstalled.items + rmGapConfig.moDuInstalled.numItems,
        moDuToAddMod.items);

    moDuToAddMod.numItems = static_cast<uint8_t>(pMoEnd - moDuToAddMod.items);

    if (ERROR == VCCB_MakeMeasObjectToAddModListDuCommon(ptCi, pDst, &moDuToAddMod))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "ERROR: VCCB_MakeMeasObjectToAddModListDuCommon failed in VCCB_MakeMeasObjectToAddModListDuDiff!\n");
        return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills NRRRC_MeasObjectToRemoveList list for DU with diff
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target list of measurement objects to remove.
 *                         The return value is NULL if there are no objects
 *                         to remove. / NRRRC_MeasObjectToRemoveList*
 * @param[in]       pMoDuList : source data - DU's MO list
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeMeasObjectToRemoveListDuDiff(
    callInfo_type *ptCi, NRRRC_MeasObjectToRemoveList *pDst, const moListMgap_type *pMoDuList)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pMoDuList);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    const mGapCallConfiguration_type &rmGapConfig = ptCi->measurementsConfigShared.mGapConfiguration;
    *pDst = NULL;
    moListMgap_type moDuToRemove;

    measurementObjectDu_type *pMoEnd = std::set_difference(rmGapConfig.moDuInstalled.items,
        rmGapConfig.moDuInstalled.items + rmGapConfig.moDuInstalled.numItems,
        pMoDuList->items,
        pMoDuList->items + pMoDuList->numItems, moDuToRemove.items);

    moDuToRemove.numItems = static_cast<uint8_t>(pMoEnd - moDuToRemove.items);

    if (0 == moDuToRemove.numItems)
    {
        return GOOD;
    }

    for (uint8_t idx = 0; idx < util::minOfArraySizeAndNumOfElems(moDuToRemove.items, moDuToRemove.numItems); idx++)
    {
        gMeasConf[ptCi->myThreadId].measObjToRemove[idx].value = static_cast<NRRRC_MeasObjectId>(
            moDuToRemove.items[idx].objectId + 1);  // need to add 1 to compensate for 1-based indexing
    }

    if (ERROR == VCCB_ConnectLinkedList(gMeasConf[ptCi->myThreadId].measObjToRemove, moDuToRemove.numItems))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_ConnectLinkedList failed in VCCB_MakeMeasObjectToRemoveListDuDiff!\n");
        return ERROR;
    }

    *pDst = gMeasConf[ptCi->myThreadId].measObjToRemove;

    return GOOD;
}

/****************************************************************************
 * @brief           Fills a useT312_r16 of ASN defined NRRRC_EventTriggerConfig object
 *                  call this function only for event based report config - at least one of the Ax
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_EventTriggerConfig*
 * @param[in]       rNewConf : Reference to a source object. / reportConfigurationConfUe_type&
 * @param[in]       rInstalledConf : Reference to a source object. / reportConfigurationConfUe_type&
 * @return          void :
 ****************************************************************************/
void VCCB_Fill_ReportConfigUseT312(NRRRC_EventTriggerConfig *pDst, const reportConfigurationConfUe_type &rNewConf,
    const reportConfigurationConfUe_type &rInstalledConf)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pDst);

    if (rNewConf.reportConfiguration.eventBased.useT312 != rInstalledConf.reportConfiguration.eventBased.useT312)
    {
        if (true == rNewConf.reportConfiguration.eventBased.useT312)
        {
            pDst->useT312_r16 = true;
        }
        else
        {
            pDst->useT312_r16 = false;
        }
        pDst->bit_mask |= NRRRC_useT312_r16_present;
    }
}

/****************************************************************************
 * @brief           Fills a part of ASN defined NRRRC_EventTriggerConfig object
 *                  that is common to all event based measurements, using VCCB
 *                  specific eventBasedReportConfigurationNR_type object.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_EventTriggerConfig*
 * @param[in]       rNewConf : Reference to a source object. / reportConfigurationConfUe_type&
 * @param[in]       rInstalledConf : Reference to a source object. / reportConfigurationConfUe_type&
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_ReportConfig_EventBased_Common(callInfo_type *ptCi, NRRRC_EventTriggerConfig *pDst,
    const reportConfigurationConfUe_type &rNewConf, const reportConfigurationConfUe_type &rInstalledConf)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    VCCB_Fill_ReportConfig_Common(ptCi, pDst, rNewConf,
        (unsigned int) NRRRC_EventTriggerConfig_reportQuantityRS_Indexes_present,
        (unsigned int) NRRRC_EventTriggerConfig_maxNrofRS_IndexesToReport_present,
        (unsigned int) NRRRC_EventTriggerConfig_includeCommonLocationInfo_r16_present);

    VCCB_FillReportAddNeighMeasNR(pDst, rNewConf);

    // check and set useT312_r16
    VCCB_Fill_ReportConfigUseT312(pDst, rNewConf, rInstalledConf);

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_QuantityConfig object with a diff
 *                  between two arrays of VCCB specific
 *                  quantityConfiguration_type objects.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_QuantityConfig*
 * @param[in]       pInstalled : Pointer to configuration already installed on UE
 *                               (base for the diff). / quantityConfiguration_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_FillQuantityConfig(NRRRC_QuantityConfig *pDst, quantityConfiguration_type *pInstalled)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);

    uint8_t numItems = 0, numHandledItems = 0;

    pDst->bit_mask = 0;

    for (uint8_t i = 0; i < MAX_NR_OF_QUANTITY_CONFIG; ++i)
    {
        if (pInstalled->nr[i].usage == CI_use)
        {
            numItems++;
        }
    }

    if (numItems > 0)
    {
        if (ERROR == VCCB_GlobalAlloc(pDst->quantityConfigNR_List, numItems))  // Check Init:OK
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_GlobalAlloc failed in VCCB_FillQuantityConfig!\n");

            return ERROR;
        }

        for (uint8_t i = 0; i < MAX_NR_OF_QUANTITY_CONFIG; ++i)
        {
            if (pInstalled->nr[i].usage == CI_use)
            {
                if (VCCB_FillQuantityConfigNR(
                        &pDst->quantityConfigNR_List[numHandledItems].value, &pInstalled->nr[i]) != GOOD)
                {
                    VCCB_PRINT_ERROR("ERROR: VCCB_FillQuantityConfigNR failed in VCCB_FillQuantityConfig!\n");

                    return ERROR;
                }
                else
                {
                    numHandledItems++;
                    if (numHandledItems == numItems)
                    {
                        break;
                    }
                }
            }
        }

        if (ERROR == VCCB_ConnectLinkedList(pDst->quantityConfigNR_List, numHandledItems))
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in VCCB_FillQuantityConfig!\n");

            return ERROR;
        }

        pDst->bit_mask |= NRRRC_quantityConfigNR_List_present;
    }

    if (CI_use == pInstalled->eutra.usage)
    {
        VCCB_FillFilterConfig(&pDst->quantityConfigEUTRA, &pInstalled->eutra.filterConfig);
        pDst->bit_mask |= NRRRC_quantityConfigEUTRA_present;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Generic function for finding unreserved IDs.
 *
 * @param           <T> : Target type. / T
 * @return          Boolean value indicating whether item with a given ID is
 *                  already installed on UE. / bool
 ****************************************************************************/
template <typename T>
bool VCCB_UnreservedItemMatcher(T &item)
{
    AUTO_TRACE_FUNC;

    return (item.pending == VCCB_FLAG_OFF);
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_PCI_RangeIndexList_ object basing
 *                  on VCCB specific blackCellsUe_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_MeasObjectNR*
 * @param[in]       pInstalled : Pointer to configuration already installed
 *                               on UE (base for the diff). / blackCellsUe_type*
 * @param[in]       pNew : Pointer to new configuration. / blackCellsUe_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_BlacklistedCellsToRemoveNR(
    NRRRC_MeasObjectNR *pDst, const blackCellsUe_type *pInstalled, const blackCellsUe_type *pNew, bool fullConfig)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    NRRRC_PCI_RangeIndexList_ *blacklistedCellsToRemove = NULL;
    uint8_t numBlacklistedCellsToRemove = 0;
    pDst->excludedCellsToRemoveList = NULL;
    bool found = true;

    if (fullConfig)
    {
        return GOOD;
    }

    if (pInstalled->numItems > MAX_NR_OF_PCI_RANGES)
    {
        VCCB_PRINT_ERROR(
            "ERROR: Installed configuration: incorrect number of cells (%hu) in VCCB_Fill_BlacklistedCellsToRemoveNR, "
            "allowed "
            "range %d - %d!\n",
            pInstalled->numItems, 0, MAX_NR_OF_PCI_RANGES);

        return ERROR;
    }

    if (pNew->numItems > MAX_NR_OF_PCI_RANGES)
    {
        VCCB_PRINT_ERROR(
            "ERROR: New configuration: incorrect number of cells (%hu) in VCCB_Fill_BlacklistedCellsToRemoveNR, "
            "allowed range %d - %d!\n",
            pNew->numItems, 0, MAX_NR_OF_PCI_RANGES);
        return ERROR;
    }

    if (*pNew == *pInstalled)
    {
        return GOOD;
    }

    if (ERROR == VCCB_GlobalAlloc(blacklistedCellsToRemove, MAX_NR_OF_PCI_RANGES))  // Check Init:OK
    {
        VCCB_PRINT_ERROR("ERROR: GlobalAlloc failed in VCCB_Fill_BlacklistedCellsToRemoveNR!\n");

        return ERROR;
    }

    for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(pInstalled->rangeElements, pInstalled->numItems); ++i)
    {
        found = false;

        for (uint8_t j = 0; j < util::minOfArraySizeAndNumOfElems(pNew->rangeElements, pNew->numItems); ++j)
        {
            if (pInstalled->rangeElements[i].pciRangeIndex == pNew->rangeElements[j].pciRangeIndex)
            {
                found = true;
            }
        }

        if (!found)
        {
            blacklistedCellsToRemove[numBlacklistedCellsToRemove].value = pInstalled->rangeElements[i].pciRangeIndex;
            numBlacklistedCellsToRemove++;
        }
    }
    if (0 != numBlacklistedCellsToRemove)
    {
        if (ERROR == VCCB_ConnectLinkedList(blacklistedCellsToRemove, numBlacklistedCellsToRemove))
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in VCCB_Fill_BlacklistedCellsToRemoveNR!\n");

            return ERROR;
        }
        pDst->excludedCellsToRemoveList = blacklistedCellsToRemove;
    }
    else
    {
        pDst->excludedCellsToRemoveList = NULL;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_EUTRA_CellIndexList_ object basing
 *                  on VCCB specific blackCellsEutra_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_MeasObjectEutra*
 * @param[in]       pInstalled : Pointer to configuration already installed
 *                               on UE (base for the diff). / blackCellsEutra_type*
 * @param[in]       pNew : Pointer to new configuration. / blackCellsEutra_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_BlacklistedCellsToRemoveEutra(
    NRRRC_MeasObjectEUTRA *pDst, const blackCellsEutra_type *pInstalled, const blackCellsEutra_type *pNew)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    NRRRC_EUTRA_CellIndexList_ *blacklistedCellsToRemove = NULL;
    uint8_t numBlacklistedCellsToRemove = 0;
    pDst->excludedCellsToRemoveListEUTRAN = NULL;

    if (pInstalled->numItems > VCCB_ARRAY_COUNT(pInstalled->rangeElements))
    {
        VCCB_PRINT_ERROR(
            "ERROR: Installed configuration: incorrect number of cells (%hu) in "
            "VCCB_Fill_BlacklistedCellsToRemoveEutra, "
            "allowed "
            "range %d - %lu!\n",
            pInstalled->numItems, 0, VCCB_ARRAY_COUNT(pInstalled->rangeElements));

        return ERROR;
    }

    if (pNew->numItems > VCCB_ARRAY_COUNT(pNew->rangeElements))
    {
        VCCB_PRINT_ERROR(
            "ERROR: New configuration: incorrect number of cells (%hu) in VCCB_Fill_BlacklistedCellsToRemoveEutra, "
            "allowed "
            "range "
            "%d - %lu!\n",
            pNew->numItems, 0, VCCB_ARRAY_COUNT(pNew->rangeElements));

        return ERROR;
    }

    if (*pNew == *pInstalled)
    {
        return GOOD;
    }

    if (ERROR ==
        VCCB_GlobalAlloc(blacklistedCellsToRemove, VCCB_ARRAY_COUNT(pInstalled->rangeElements)))  // Check Init:OK
    {
        VCCB_PRINT_ERROR("ERROR: GlobalAlloc failed in VCCB_Fill_BlacklistedCellsToRemoveEutra!\n");

        return ERROR;
    }

    for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(pInstalled->rangeElements, pInstalled->numItems); ++i)
    {
        bool found = false;

        for (uint8_t j = 0; j < util::minOfArraySizeAndNumOfElems(pNew->rangeElements, pNew->numItems); ++j)
        {
            if (pInstalled->rangeElements[i].cellIndexEutra == pNew->rangeElements[j].cellIndexEutra)
            {
                found = true;
                break;
            }
        }

        if (!found)
        {
            blacklistedCellsToRemove[numBlacklistedCellsToRemove].value = pInstalled->rangeElements[i].cellIndexEutra;
            numBlacklistedCellsToRemove++;
        }
    }

    if (0 != numBlacklistedCellsToRemove)
    {
        if (ERROR == VCCB_ConnectLinkedList(blacklistedCellsToRemove, numBlacklistedCellsToRemove))
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in VCCB_Fill_BlacklistedCellsToRemoveEutra!\n");

            return ERROR;
        }
        pDst->excludedCellsToRemoveListEUTRAN = blacklistedCellsToRemove;
    }
    else
    {
        pDst->excludedCellsToRemoveListEUTRAN = NULL;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_EUTRA_CellIndexList_ object basing
 *                  on VCCB specific blackCellsEutra_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_MeasObjectEutra*
 * @param[in]       pInstalled : Pointer to configuration already installed
 *                               on UE (base for the diff). / blackCellsEutra_type*
 * @param[in]       pNew : Pointer to new configuration. / blackCellsEutra_type*
 * @param[in]       fullConfig : specifies whether pDst should be filled
 *                  with a diff or full configuration.
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_BlacklistedCellsToRemoveEutra(NRRRC_MeasObjectEUTRA *pDst, const blackCellsEutra_type *pInstalled,
    const blackCellsEutra_type *pNew, bool fullConfig)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    pDst->excludedCellsToRemoveListEUTRAN = NULL;

    if (!fullConfig)
    {
        return VCCB_Fill_BlacklistedCellsToRemoveEutra(pDst, pInstalled, pNew);
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Prepares measGapConfig for SN. Uses delta signaling.
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target ASN configuration type. / NRRRC_MeasConfigMN*
 * @return          void
 ****************************************************************************/
void VCCB_MakeMeasGapConfigSnDiff(callInfo_type *ptCi, NRRRC_MeasConfigMN *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pDst);

    const mGapCallConfiguration_type &rmGapConfig = ptCi->measurementsConfigShared.mGapConfiguration;
    // in case of mgapConfig preparation for SN always use source DU configuration
    const mGapCfgNode_type &rmGapCfgNew = ptCi->measurementsConfigShared.mGapDu.mGapCfgNew;

    // gapUE
    if (rmGapConfig.mGapCfgSn.ue != rmGapCfgNew.ue)
    {
        pDst->bit_mask |= NRRRC_gapPurpose_present;
        pDst->gapPurpose = NRRRC_perUE;

        pDst->bit_mask |= NRRRC_MeasConfigMN_measGapConfig_present;
        VCCB_FillGapConfig(pDst->measGapConfig, rmGapCfgNew.ue);
    }

    // gapFR1
    if (rmGapConfig.mGapCfgSn.fr1 != rmGapCfgNew.fr1)
    {
        pDst->bit_mask |= NRRRC_gapPurpose_present;
        pDst->gapPurpose = NRRRC_perFR1;

        pDst->bit_mask |= NRRRC_MeasConfigMN_measGapConfig_present;
        VCCB_FillGapConfig(pDst->measGapConfig, rmGapCfgNew.fr1);
    }

    // gapFR2 - only NR-DC
    if ((UECTX_NEDC_MN != ptCi->mrdcInfo.ueCtxType) &&
        (rmGapConfig.mGapCfgSn.fr2 != rmGapCfgNew.fr2))
    {
        pDst->bit_mask |= NRRRC_measGapConfigFR2_present;
        VCCB_FillGapConfig(pDst->measGapConfigFR2, rmGapCfgNew.fr2);
    }
}

/****************************************************************************
 * @brief           Prepares measGapConfig for SN. Uses new configuration.
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target ASN configuration type. / NRRRC_MeasConfigMN*
 * @return          void
 ****************************************************************************/
void VCCB_MakeMeasGapConfigSnNew(callInfo_type *ptCi, NRRRC_MeasConfigMN *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pDst);

    // in case of mgapConfig preparation for SN always use source DU configuration
    const mGapCfgNode_type &rmGapCfgNew = ptCi->measurementsConfigShared.mGapDu.mGapCfgNew;

    // gapUE
    if (VCCB_FLAG_ON == rmGapCfgNew.ue.flag)
    {
        pDst->bit_mask |= NRRRC_gapPurpose_present;
        pDst->gapPurpose = NRRRC_perUE;

        pDst->bit_mask |= NRRRC_MeasConfigMN_measGapConfig_present;
        VCCB_FillGapConfig(pDst->measGapConfig, rmGapCfgNew.ue);
    }

    // gapFR1
    if (VCCB_FLAG_ON == rmGapCfgNew.fr1.flag)
    {
        pDst->bit_mask |= NRRRC_gapPurpose_present;
        pDst->gapPurpose = NRRRC_perFR1;

        pDst->bit_mask |= NRRRC_MeasConfigMN_measGapConfig_present;
        VCCB_FillGapConfig(pDst->measGapConfig, rmGapCfgNew.fr1);
    }

    // gapFR2 - only NR-DC
    if ((UECTX_NEDC_MN != ptCi->mrdcInfo.ueCtxType) && (VCCB_FLAG_ON == rmGapCfgNew.fr2.flag))
    {
        pDst->bit_mask |= NRRRC_measGapConfigFR2_present;
        VCCB_FillGapConfig(pDst->measGapConfigFR2, rmGapCfgNew.fr2);
    }
}

/****************************************************************************
 * @brief           Prepares measGapConfig for SN. Force release.
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target ASN configuration type. / NRRRC_MeasConfigMN*
 * @return          void
 ****************************************************************************/
void VCCB_MakeMeasGapConfigSnForceRelease(callInfo_type *ptCi, NRRRC_MeasConfigMN *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pDst);

    measGapConfig_type measGapConfigRelease;
    measGapConfigRelease.flag = VCCB_FLAG_OFF;

    // gapUE / gapFR1
    pDst->bit_mask |= NRRRC_MeasConfigMN_measGapConfig_present;
    VCCB_FillGapConfig(pDst->measGapConfig, measGapConfigRelease);

    // gapFR2 - only NR-DC
    if (UECTX_NEDC_MN != ptCi->mrdcInfo.ueCtxType)
    {
        pDst->bit_mask |= NRRRC_measGapConfigFR2_present;
        VCCB_FillGapConfig(pDst->measGapConfigFR2, measGapConfigRelease);
    }
}

/****************************************************************************
 * @brief           Copies arrays from installedItems and newItem to measConfigMN from XN_SNode. Takes care of
 *allocating memory to measuredFrequenciesMN arrray.
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target ASN configuration type. / NRRRC_MeasConfigMN*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_FillMeasuredFrequenciesMN(callInfo_type *ptCi, NRRRC_MeasConfigMN *pIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pIE);

    if (ERROR == VCCB_GlobalAlloc(pIE->measuredFrequenciesMN, MAX_NR_OF_OBJECT_ID))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_GlobalAlloc ERROR!\n");
        return ERROR;
    }

    uint16_t numItems = 0;
    auto &measObjects = FnVCCB_GetMeasurementsConfiguration(*ptCi).measurementObjects;
    auto &measObjectsProc = FnVCCB_GetMeasurementsProcedure(*ptCi).measurementObjects;

    const bool isDuringMeasReconfiguration = FnVCCB_GetMeasurementsProcedure(*ptCi).tgtCellNum < MAX_CELL_NUM_VCCB;
    auto &items = isDuringMeasReconfiguration ? measObjectsProc.newItems : measObjects.installedItems;
    const size_t itemsSize = isDuringMeasReconfiguration
                                 ? MIN(util::arraySize(measObjectsProc.newItems), measObjectsProc.numNewItems)
                                 : util::arraySize(measObjects.installedItems);
    for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(items, static_cast<unsigned int>(itemsSize)); ++i)
    {
        auto &item = items[i];
        if (CI_no_use == item.usage)
        {
            continue;
        }
        auto &val = pIE->measuredFrequenciesMN[numItems].value;
        val.bit_mask = 0;
        if (measRatNr == item.conf.ratType)
        {
            val.measuredFrequency = VCCB_GetMeasObjectSsbFreq(item);
            val.bit_mask |= NRRRC_measuredFrequency_present;
            numItems++;
        }
        else if (measRatEutra == item.conf.ratType)
        {
            val.measuredFrequency = VLIB_Freq2Arfcn(ConvertDlEarfcnToFreqKhz(VCCB_GetMeasObjectCarrierFreq(item)));
            val.bit_mask |= NRRRC_measuredFrequency_present;
            numItems++;
        }
        else
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "Unknown ratType: %d in function VCCB_FillMeasuredFrequenciesMN was find ERROR!\n", item.conf.ratType);
        }
    }

    if (0 == numItems)
    {
        return GOOD;
    }

    if (ERROR == VCCB_ConnectLinkedList(pIE->measuredFrequenciesMN, numItems))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_ConnectLinkedList ERROR!\n");
        return ERROR;
    }

    pIE->bit_mask |= NRRRC_measuredFrequenciesMN_present;

    return GOOD;
}

/****************************************************************************
 * @brief           Prepares measGapConfig full.
 *
 * @param[in]       rmGapCfg : Reference to source configuration.
 * @param[out]      rDst : Target ASN configuration type.
 ****************************************************************************/
void VCCB_MakeMeasGapConfigFull(const mGapCfgNode_type &rmGapCfg, NRRRC_MeasConfig &rDst)
{
    AUTO_TRACE_FUNC;

    rDst.measGapConfig.bit_mask = 0;

    // gapFR2
    if (VCCB_FLAG_ON == rmGapCfg.fr2.flag)
    {
        rDst.measGapConfig.bit_mask |= NRRRC_gapFR2_present;
        VCCB_FillGapConfig(rDst.measGapConfig.gapFR2, rmGapCfg.fr2);
    }

    // gapFR1
    if (VCCB_FLAG_ON == rmGapCfg.fr1.flag)
    {
        rDst.measGapConfig.bit_mask |= NRRRC_gapFR1_present;
        VCCB_FillGapConfig(rDst.measGapConfig.gapFR1, rmGapCfg.fr1);
    }

    // gapUE
    if (VCCB_FLAG_ON == rmGapCfg.ue.flag)
    {
        rDst.measGapConfig.bit_mask |= NRRRC_gapUE_present;
        VCCB_FillGapConfig(rDst.measGapConfig.gapUE, rmGapCfg.ue);
    }

    if (0 != rDst.measGapConfig.bit_mask)
    {
        rDst.bit_mask |= NRRRC_MeasConfig_measGapConfig_present;
    }
}

/****************************************************************************
 * @brief           Prepares measGapConfig installed.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target ASN configuration type. / NRRRC_MeasConfig*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeMeasGapConfigInstalled(callInfo_type *ptCi, NRRRC_MeasConfig *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    VCCB_MakeMeasGapConfigFull(FnVCCB_GetMeasurementsConfiguration(*ptCi).mGapCfgInstalled, *pDst);

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_ReportConfigToAddMod object with
 *                  a list of report configurations that need to be
 *                  added / modified in UE configuration, basing on diff two
 *                  VCCB specific reportConfigurationInstalledUe_type objects.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_ReportConfigToAddMod*
 * @param[in]       pNew : Pointer to new configuration. / reportConfigurationNewUe_type*
 * @param[in]       pInstalled : Pointer to new configuration. / reportConfigurationInstalledUe_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_ReportConfigToAddMod(callInfo_type *ptCi, NRRRC_ReportConfigToAddMod *pDst,
    const reportConfigurationNewUe_type *pNew, const reportConfigurationInstalledUe_type *pInstalled)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pNew);
    VALID_E_POINT_CHECK_ERROR(pInstalled);

    int16_t status;

    pDst->reportConfigId =
        static_cast<NRRRC_ReportConfigId>(pNew->objectId + 1);  // need to add 1 to compensate for 1-based indexing

    auto &rNewConf = pNew->conf;

    if ((measReport_B1Eutra == rNewConf.reportType) || (measReport_B2Eutra == rNewConf.reportType))
    {
        pDst->reportConfig.choice = NRRRC_reportConfigInterRAT_chosen;
        pDst->reportConfig.u.reportConfigInterRAT.reportType.choice =
            NRRRC_ReportConfigInterRAT_reportType_eventTriggered_chosen;
        auto &eventTriggered = pDst->reportConfig.u.reportConfigInterRAT.reportType.u.eventTriggered;
        eventTriggered.rsType = static_cast<NRRRC_NR_RS_Type>(rNewConf.rsType);
        status = VCCB_Fill_ReportConfigInterRAT_Common(
            ptCi, &eventTriggered, rNewConf, NRRRC_EventTriggerConfigInterRAT_includeCommonLocationInfo_r16_present);
        VCCB_RETURN_ERROR_ON_CALL_NOT_GOOD(
            ptCi, status, "ERROR: VCCB_Fill_ReportConfigInterRAT_Common failed in %s!\n", __func__);
    }
    else if (rNewConf.reportType == measReport_reportCGI)
    {
        pDst->reportConfig.choice = NRRRC_reportConfigNR_chosen;
        pDst->reportConfig.u.reportConfigNR.reportType.choice = NRRRC_ReportConfigNR_reportType_reportCGI_chosen;
        status =
            VCCB_Fill_ReportConfig_reportCGI(&pDst->reportConfig.u.reportConfigNR.reportType.u.reportCGI, rNewConf);
        VCCB_RETURN_ERROR_ON_CALL_NOT_GOOD(
            ptCi, status, "ERROR: VCCB_Fill_ReportConfig_reportCGI failed in %s!\n", __func__);
    }
    else if (rNewConf.reportType == measReport_reportCGIEutra)
    {
        pDst->reportConfig.choice = NRRRC_reportConfigInterRAT_chosen;
        pDst->reportConfig.u.reportConfigInterRAT.reportType.choice =
            NRRRC_ReportConfigInterRAT_reportType_reportCGI_chosen;
        if (VCCB_Fill_ReportConfig_reportCGI_EUTRA(
                &pDst->reportConfig.u.reportConfigInterRAT.reportType.u.reportCGI, rNewConf) != GOOD)
        {
            VCCB_PRINT_ERROR(
                "ERROR: VCCB_Fill_ReportConfig_reportCGI_EUTRA failed in VCCB_Fill_ReportConfigToAddMod!\n");
            return ERROR;
        }
    }
    else
    {
        pDst->reportConfig.choice = NRRRC_reportConfigNR_chosen;
        if (rNewConf.reportType == measReport_periodical)
        {
            pDst->reportConfig.u.reportConfigNR.reportType.choice = NRRRC_ReportConfigNR_reportType_periodical_chosen;
            if (VCCB_Fill_ReportConfig_Periodical(
                    ptCi, &pDst->reportConfig.u.reportConfigNR.reportType.u.periodical, rNewConf) != GOOD)
            {
                VCCB_PRINT_ERROR(
                    "ERROR: VCCB_Fill_ReportConfig_Periodical failed in VCCB_Fill_ReportConfigToAddMod!\n");

                return ERROR;
            }
        }
        else
        {
            pDst->reportConfig.u.reportConfigNR.reportType.choice =
                NRRRC_ReportConfigNR_reportType_eventTriggered_chosen;
            if (VCCB_Fill_ReportConfig_EventBased_Common(ptCi,
                    &pDst->reportConfig.u.reportConfigNR.reportType.u.eventTriggered, rNewConf,
                    pInstalled->conf) != GOOD)
            {
                VCCB_PRINT_ERROR(
                    "ERROR: VCCB_Fill_ReportConfig_EventBased_Common failed in VCCB_Fill_ReportConfigToAddMod!\n");

                return ERROR;
            }
        }
    }

    switch (rNewConf.reportType)
    {
        case measReport_periodical:
            break;

        case measReport_reportCGI:
            break;

        case measReport_reportCGIEutra:
            break;

        case measReport_A1:
            if (VCCB_Fill_ReportConfig_A1(&pDst->reportConfig.u.reportConfigNR.reportType.u.eventTriggered,
                    &rNewConf.reportConfiguration.eventBased) != GOOD)
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_ReportConfig_A1 failed in VCCB_Fill_ReportConfigToAddMod!\n");

                return ERROR;
            }
            break;

        case measReport_A2:
            if (VCCB_Fill_ReportConfig_A2(&pDst->reportConfig.u.reportConfigNR.reportType.u.eventTriggered,
                    &rNewConf.reportConfiguration.eventBased) != GOOD)
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_ReportConfig_A2 failed in VCCB_Fill_ReportConfigToAddMod!\n");

                return ERROR;
            }
            break;

        case measReport_A3:
            if (VCCB_isAssociatedWithCondTriggerConfig(rNewConf))
            {
                if (GOOD != VCCB_Fill_ReportConfig_condTriggerConfig_condEventA3(pDst, rNewConf))
                {
                    VCCB_PRINT_ERROR(
                        "ERROR: VCCB_Fill_ReportConfig_condTriggerConfig_condEventA3 failed in "
                        "VCCB_Fill_ReportConfigToAddMod!\n");
                    return ERROR;
                }
            }
            else if (VCCB_Fill_ReportConfig_A3(&pDst->reportConfig.u.reportConfigNR.reportType.u.eventTriggered,
                         &rNewConf.reportConfiguration.eventBased) != GOOD)
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_ReportConfig_A3 failed in VCCB_Fill_ReportConfigToAddMod!\n");

                return ERROR;
            }
            break;

        case measReport_A4:
            if (VCCB_Fill_ReportConfig_A4(&pDst->reportConfig.u.reportConfigNR.reportType.u.eventTriggered,
                    &rNewConf.reportConfiguration.eventBased) != GOOD)
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_ReportConfig_A4 failed in VCCB_Fill_ReportConfigToAddMod!\n");

                return ERROR;
            }
            break;

        case measReport_A5:
            if (VCCB_isAssociatedWithCondTriggerConfig(rNewConf))
            {
                if (GOOD != VCCB_Fill_ReportConfig_condTriggerConfig_condEventA5(pDst, rNewConf))
                {
                    VCCB_PRINT_ERROR(
                        "ERROR: VCCB_Fill_ReportConfig_condTriggerConfig_condEventA5 failed in "
                        "VCCB_Fill_ReportConfigToAddMod!\n");
                    return ERROR;
                }
            }
            else if (VCCB_Fill_ReportConfig_A5(&pDst->reportConfig.u.reportConfigNR.reportType.u.eventTriggered,
                         &rNewConf.reportConfiguration.eventBased) != GOOD)
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_ReportConfig_A5 failed in VCCB_Fill_ReportConfigToAddMod!\n");

                return ERROR;
            }
            break;

        case measReport_A6:
            if (VCCB_Fill_ReportConfig_A6(&pDst->reportConfig.u.reportConfigNR.reportType.u.eventTriggered,
                    &rNewConf.reportConfiguration.eventBased) != GOOD)
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_ReportConfig_A6 failed in VCCB_Fill_ReportConfigToAddMod!\n");

                return ERROR;
            }
            break;

        case measReport_B1Eutra:
            status =
                VCCB_Fill_ReportConfig_B1Eutra(&pDst->reportConfig.u.reportConfigInterRAT.reportType.u.eventTriggered,
                    &rNewConf.reportConfiguration.eventInterRat);
            VCCB_RETURN_ERROR_ON_CALL_NOT_GOOD(
                ptCi, status, "ERROR: VCCB_Fill_ReportConfig_B1Eutra failed in %s!\n", __func__);
            break;

        case measReport_B2Eutra:
            status =
                VCCB_Fill_ReportConfig_B2Eutra(&pDst->reportConfig.u.reportConfigInterRAT.reportType.u.eventTriggered,
                    &rNewConf.reportConfiguration.eventInterRat);
            VCCB_RETURN_ERROR_ON_CALL_NOT_GOOD(
                ptCi, status, "ERROR: VCCB_Fill_ReportConfig_B2Eutra failed in %s!\n", __func__);
            break;

        case measReport_periodicalInterRat:
        {
            pDst->reportConfig.choice = NRRRC_reportConfigInterRAT_chosen;
            pDst->reportConfig.u.reportConfigInterRAT.reportType.choice =
                NRRRC_ReportConfigInterRAT_reportType_periodical_chosen;
            auto &periodical = pDst->reportConfig.u.reportConfigInterRAT.reportType.u.periodical;
            status = VCCB_Fill_ReportConfigInterRAT_Common(ptCi, &periodical, rNewConf,
                NRRRC_PeriodicalReportConfigInterRAT_includeCommonLocationInfo_r16_present);
            VCCB_RETURN_ERROR_ON_CALL_NOT_GOOD(
                ptCi, status, "ERROR: VCCB_Fill_ReportConfigInterRAT_Common failed in %s!\n", __func__);
            break;
        }

        default:
            VCCB_PRINT_ERROR(
                "ERROR: Invalid report configuration type chosen (%hu) in VCCB_Fill_ReportConfigToAddMod!\n",
                rNewConf.reportType);

            return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC__seqof180_ object basing
 *                  on VCCB specific blackCellsUe_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_MeasObjectNR*
 * @param[in]       pInstalled : Pointer to configuration already installed
 *                               on UE (base for the diff). / blackCellsUe_type*
 * @param[in]       pNew : Pointer to new configuration. / blackCellsUe_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_BlacklistedCellsToAddModNR(
    NRRRC_MeasObjectNR *pDst, const blackCellsUe_type *pInstalled, const blackCellsUe_type *pNew)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    NRRRC__seqof180_ *blacklistedCellsToAddMod = NULL;
    uint8_t numBlacklistedCellsToAddMod = 0;
    pDst->excludedCellsToAddModList = NULL;
    bool needAdd = true;

    if (pInstalled->numItems > MAX_NR_OF_PCI_RANGES)
    {
        VCCB_PRINT_ERROR(
            "ERROR: Installed configuration: incorrect number of cells (%hu) in VCCB_Fill_BlacklistedCellsToAddModNR, "
            "allowed "
            "range %d - %d!\n",
            pInstalled->numItems, 0, MAX_NR_OF_PCI_RANGES);

        return ERROR;
    }

    if (pNew->numItems > MAX_NR_OF_PCI_RANGES)
    {
        VCCB_PRINT_ERROR(
            "ERROR: New configuration: incorrect number of cells (%hu) in VCCB_Fill_BlacklistedCellsToAddModNR, "
            "allowed "
            "range "
            "%d - %d!\n",
            pNew->numItems, 0, MAX_NR_OF_PCI_RANGES);

        return ERROR;
    }

    if (*pNew == *pInstalled)
    {
        return GOOD;
    }

    if (ERROR == VCCB_GlobalAlloc(blacklistedCellsToAddMod, MAX_NR_OF_PCI_RANGES))  // Check Init:OK
    {
        VCCB_PRINT_ERROR("ERROR: GlobalAlloc failed in VCCB_Fill_BlacklistedCellsToAddModNR!\n");

        return ERROR;
    }

    for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(pNew->rangeElements, pNew->numItems); ++i)
    {
        needAdd = true;

        for (uint8_t j = 0; j < util::minOfArraySizeAndNumOfElems(pInstalled->rangeElements, pInstalled->numItems); ++j)
        {
            if (pNew->rangeElements[i].pciRangeIndex == pInstalled->rangeElements[j].pciRangeIndex)
            {
                if (pNew->rangeElements[i].pciRange != pInstalled->rangeElements[j].pciRange)
                {
                    needAdd = true;
                }
                else
                {
                    needAdd = false;
                }
                break;
            }
        }

        if (needAdd == true)
        {
            blacklistedCellsToAddMod[numBlacklistedCellsToAddMod].value.pci_RangeIndex =
                pNew->rangeElements[i].pciRangeIndex;
            blacklistedCellsToAddMod[numBlacklistedCellsToAddMod].value.pci_Range.start =
                pNew->rangeElements[i].pciRange.pciStart;
            blacklistedCellsToAddMod[numBlacklistedCellsToAddMod].value.pci_Range.bit_mask = 0;
            if (pciType_range == pNew->rangeElements[i].pciRange.pciType)
            {
                blacklistedCellsToAddMod[numBlacklistedCellsToAddMod].value.pci_Range.range =
                    static_cast<NRRRC__enum14>(pNew->rangeElements[i].pciRange.pciRange);
                blacklistedCellsToAddMod[numBlacklistedCellsToAddMod].value.pci_Range.bit_mask |=
                    NRRRC_PCI_Range_range_present;
            }
            numBlacklistedCellsToAddMod++;
        }
    }
    if (0 != numBlacklistedCellsToAddMod)
    {
        if (ERROR == VCCB_ConnectLinkedList(blacklistedCellsToAddMod, numBlacklistedCellsToAddMod))
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in VCCB_Fill_BlacklistedCellsToAddModNR!\n");

            return ERROR;
        }
        pDst->excludedCellsToAddModList = blacklistedCellsToAddMod;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC__seqof180_ object basing
 *                  on VCCB specific blackCellsUe_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_MeasObjectNR*
 * @param[in]       pInstalled : Pointer to configuration already installed
 *                               on UE (base for the diff). / blackCellsUe_type*
 * @param[in]       pNew : Pointer to new configuration. / blackCellsUe_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_BlacklistedCellsToAddModNR(
    NRRRC_MeasObjectNR *pDst, const blackCellsUe_type *pInstalled, const blackCellsUe_type *pNew, bool fullConfig)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    pDst->excludedCellsToAddModList = NULL;

    if (fullConfig)
    {
        return VCCB_Copy_BlackCells(pDst, pNew);
    }
    else
    {
        return VCCB_Fill_BlacklistedCellsToAddModNR(pDst, pInstalled, pNew);
    }
}

/****************************************************************************
 * @brief           Fills NRRRC_MeasIdToRemoveList list, based on
 *                  the supplied arguments.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target list of report identities to remove.
 *                         The return value is NULL if there are no
 *                         identites to remove. / NRRRC_MeasIdToRemoveList*
 * @param[in]       itemsToRemove : Bitmap of ids of identites to remove. / uint64_t
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeMeasIdToRemoveList(const callInfo_type *ptCi, NRRRC_MeasIdToRemoveList *pDst, uint64_t itemsToRemove)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    uint8_t numItemsToRemove = 0;

    if (itemsToRemove == 0)
    {
        *pDst = NULL;

        return BREAK;
    }

    for (uint8_t bitIndex = 0; bitIndex < MAX_NR_OF_MEAS_ID_3GPP; bitIndex++)
    {
        if (GETBIT(itemsToRemove, bitIndex))
        {
            gMeasConf[ptCi->myThreadId].measIdToRemove[numItemsToRemove++].value =
                static_cast<NRRRC_MeasId>(bitIndex + 1);  // need to add 1 to compensate for 1-based indexing
        }
    }

    if (ERROR == VCCB_ConnectLinkedList(gMeasConf[ptCi->myThreadId].measIdToRemove, numItemsToRemove))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_ConnectLinkedList failed in VCCB_MakeMeasIdToRemoveList!\n");

        return ERROR;
    }

    *pDst = gMeasConf[ptCi->myThreadId].measIdToRemove;

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_PCI_List object with a list of
 *                  cells that need to be removed from a measurement object
 *                  configuration, basing on diff two VCCB specific
 *                  cellsToMeasureList_type objects.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_PCI_List*
 * @param[in]       pInstalled : Pointer to configuration already installed
 *                               on UE (base for the diff). / cellsToMeasureList_type*
 * @param[in]       pNew : Pointer to new configuration. / cellsToMeasureList_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_CellsToRemoveList(NRRRC_PCI_List *pDst, const cellsToMeasureList_type *pInstalled,
    const cellsToMeasureList_type *pNew, bool fullConfig)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    NRRRC_PCI_List cellsToRemove;
    uint8_t numCellsToRemove = 0;
    bool found = false;
    *pDst = NULL;

    if (fullConfig)
    {
        return GOOD;
    }

    if (pInstalled->numItems > MAX_NR_OF_CELLS_TO_MEASURE)
    {
        VCCB_PRINT_ERROR(
            "ERROR: Installed configuration: incorrect number of cells (%hu) in VCCB_Fill_CellsToRemoveList, allowed "
            "range %d - %d!\n",
            pInstalled->numItems, 0, MAX_NR_OF_CELLS_TO_MEASURE);

        return ERROR;
    }

    if (pNew->numItems > MAX_NR_OF_CELLS_TO_MEASURE)
    {
        VCCB_PRINT_ERROR(
            "ERROR: New configuration: incorrect number of cells (%hu) in VCCB_Fill_CellsToRemoveList, allowed range "
            "%d - %d!\n",
            pNew->numItems, 0, MAX_NR_OF_CELLS_TO_MEASURE);

        return ERROR;
    }

    if (GOOD != VCCB_GlobalAlloc(cellsToRemove, MAX_NR_OF_CELLS_TO_MEASURE))  // Check Init:OK
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_GlobalAlloc failed in VCCB_Fill_CellsToRemoveList!\n");

        return ERROR;
    }

    for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(pInstalled->items, pInstalled->numItems); ++i)
    {
        found = false;

        for (uint8_t j = 0; j < util::minOfArraySizeAndNumOfElems(pNew->items, pNew->numItems); ++j)
        {
            if (pInstalled->items[i].pci == pNew->items[j].pci)
            {
                found = true;
            }
        }

        if (found == false)
        {
            cellsToRemove[numCellsToRemove++].value = pInstalled->items[i].pci;
        }
    }

    if (numCellsToRemove != 0)
    {
        if (ERROR == VCCB_ConnectLinkedList(cellsToRemove, numCellsToRemove))
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in VCCB_Fill_CellsToRemoveList!\n");

            return ERROR;
        }
        *pDst = cellsToRemove;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_MeasObjectToAddMod type
 *                  basing on supplied configuration.
 *
 * @param[out]      pDst : Pointer to a destination object / NRRRC_MeasObjectToAddMod*
 * @param[in]       pInstalled : Pointer to measuremen object
 *                  configuration. / measurementObjectUe_type*
 * @param[in]       pCell : Pointer to (new) serving cell. / VccbCellInfo_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_MeasObjectToAddMod(
    NRRRC_MeasObjectToAddMod *pDst, measurementObjectUe_type *pInstalled, VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pCell);

    pDst->measObjectId =
        static_cast<NRRRC_MeasObjectId>(pInstalled->objectId + 1);  // need to add 1 to compensate for 1-based indexing

    switch (pInstalled->conf.ratType)
    {
        case measRatNr:
            pDst->measObject.choice = NRRRC_measObjectNR_chosen;

            if (GOOD != VCCB_Fill_MeasObjectNR(&pDst->measObject.u.measObjectNR, &pInstalled->conf.rat.nr, pCell))
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_MeasObjectNR failed in VCCB_Fill_MeasObjectToAddMod!\n");

                return ERROR;
            }
            break;

        case measRatEutra:
            pDst->measObject.choice = NRRRC_measObjectEUTRA_chosen;

            if (GOOD !=
                VCCB_Fill_MeasObjectEUTRA(&pDst->measObject.u.measObjectEUTRA, &pInstalled->conf.rat.eutra, pCell))
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_MeasObjectEUTRA failed in VCCB_Fill_MeasObjectToAddMod!\n");

                return ERROR;
            }
            break;

        default:
            VCCB_PRINT_ERROR("ERROR: Invalid ratType(%u) in VCCB_Fill_MeasObjectToAddMod!\n", pInstalled->conf.ratType);

            return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC__choice95 object using VCCB
 *                  specific sMeasure_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / s_MeasureConfig_T *
 * @param[in]       pSrc : Pointer to a source object. / sMeasure_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
template <typename S_MeasureConfig_T>
int16_t VCCB_Fill_S_MeasureConfig(S_MeasureConfig_T *pDst, const sMeasure_type *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    switch (pSrc->choice)
    {
        case choice_SSB:
            pDst->choice = NRRRC_ssb_RSRP_chosen;
            pDst->u.ssb_RSRP = pSrc->value;
            break;

        case choice_CSIRS:
            pDst->choice = NRRRC_csi_RSRP_chosen;
            pDst->u.csi_RSRP = pSrc->value;
            break;

        default:
            VCCB_PRINT_ERROR("ERROR: Invalid S-Measure configuration type chosen (%hu) in VCCB_Fill_S_MeasureConfig!\n",
                pSrc->choice);

            return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Reset NumberOfReportsSent of all measurement identities that links
 *                  to periodical ReportConfig.
 *
 * @param[in]       ptCi : Pointer to call configuration
 * @param[in]       rptCfgIdx : index of new ReportConfig
 ****************************************************************************/
void VCCB_ResetNumberOfReportsSent(callInfo_type *ptCi, uint8_t rptCfgIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(rptCfgIdx, MAX_NR_OF_REPORT_CONFIG_ID);

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);
    reportConfigurationNewUe_type *pUeRptCfg = &rMeasProc.reportConfigurations.newItems[rptCfgIdx];
    measurementIdentity_type *pUeMeasId = nullptr;

    if ((measReport_periodical != pUeRptCfg->conf.reportType) &&
        (measReport_periodicalInterRat != pUeRptCfg->conf.reportType))
    {
        return;
    }

    for (uint8_t measIdIdx = 0; measIdIdx < util::minOfArraySizeAndNumOfElems(rMeasProc.measurementIdentities.newItems,
                                                rMeasProc.measurementIdentities.numNewItems);
         ++measIdIdx)
    {
        pUeMeasId = &rMeasProc.measurementIdentities.newItems[measIdIdx];
        if (CI_no_use == pUeMeasId->usage)
        {
            continue;
        }
        if (pUeRptCfg->objectId != pUeMeasId->reportConfigId)
        {
            continue;
        }

        pUeMeasId->numberOfReportsSent = 0;

        VCCB_PRINT_CALL_COMMENT(ptCi,
            "Periodical ReportConfig idx(%u) id(%u) change - MeasId id(%u) numberOfReportsSent reset\n", rptCfgIdx,
            pUeRptCfg->objectId + 1, pUeMeasId->objectId + 1);
    }
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC__seqof179 object basing
 *                  on VCCB specific blackCellsUe_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_MeasObjectEUTRA*
 * @param[in]       pInstalled : Pointer to configuration already installed
 *                               on UE (base for the diff). / blackCellsEutra_type*
 * @param[in]       pNew : Pointer to new configuration. / blackCellsEutra_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_BlacklistedCellsToAddModEutra(
    NRRRC_MeasObjectEUTRA *pDst, const blackCellsEutra_type *pInstalled, const blackCellsEutra_type *pNew)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    NRRRC_MeasObjectEUTRA::NRRRC__seqof179 *blacklistedCellsToAddMod = NULL;
    uint8_t numBlacklistedCellsToAddMod = 0;
    pDst->excludedCellsToAddModListEUTRAN = NULL;
    bool needAdd = true;

    if (pInstalled->numItems > VCCB_ARRAY_COUNT(pInstalled->rangeElements))
    {
        VCCB_PRINT_ERROR(
            "ERROR: Installed configuration: incorrect number of cells (%hu) in "
            "VCCB_Fill_BlacklistedCellsToAddModEutra, "
            "allowed "
            "range %d - %lu!\n",
            pInstalled->numItems, 0, VCCB_ARRAY_COUNT(pInstalled->rangeElements));

        return ERROR;
    }

    if (pNew->numItems > VCCB_ARRAY_COUNT(pNew->rangeElements))
    {
        VCCB_PRINT_ERROR(
            "ERROR: New configuration: incorrect number of cells (%hu) in VCCB_Fill_BlacklistedCellsToAddModEutra, "
            "allowed "
            "range "
            "%d - %lu!\n",
            pNew->numItems, 0, VCCB_ARRAY_COUNT(pNew->rangeElements));

        return ERROR;
    }

    if (*pNew == *pInstalled)
    {
        return GOOD;
    }

    if (ERROR == VCCB_GlobalAlloc(blacklistedCellsToAddMod, VCCB_ARRAY_COUNT(pNew->rangeElements)))  // Check Init:OK
    {
        VCCB_PRINT_ERROR("ERROR: GlobalAlloc failed in VCCB_Fill_BlacklistedCellsToAddModEutra!\n");

        return ERROR;
    }

    for (uint8_t i = 0; i < MIN(pNew->numItems, VCCB_ARRAY_COUNT(pNew->rangeElements)); ++i)
    {
        needAdd = true;

        for (uint8_t j = 0; j < MIN(pInstalled->numItems, VCCB_ARRAY_COUNT(pInstalled->rangeElements)); ++j)
        {
            if (pNew->rangeElements[i].cellIndexEutra == pInstalled->rangeElements[j].cellIndexEutra)
            {
                needAdd = (pNew->rangeElements[i].physCellIdRange != pInstalled->rangeElements[j].physCellIdRange);
                break;
            }
        }

        if (needAdd)
        {
            blacklistedCellsToAddMod[numBlacklistedCellsToAddMod].value.cellIndexEUTRA =
                static_cast<NRRRC_EUTRA_CellIndex>(pNew->rangeElements[i].cellIndexEutra);
            blacklistedCellsToAddMod[numBlacklistedCellsToAddMod].value.physCellIdRange.start =
                static_cast<NRRRC_EUTRA_PhysCellId>(pNew->rangeElements[i].physCellIdRange.pciStart);
            blacklistedCellsToAddMod[numBlacklistedCellsToAddMod].value.physCellIdRange.bit_mask = 0;
            if (pciType_range == pNew->rangeElements[i].physCellIdRange.pciType)
            {
                blacklistedCellsToAddMod[numBlacklistedCellsToAddMod].value.physCellIdRange.range =
                    static_cast<NRRRC__enum256>(pNew->rangeElements[i].physCellIdRange.pciRange);
                blacklistedCellsToAddMod[numBlacklistedCellsToAddMod].value.physCellIdRange.bit_mask |=
                    NRRRC_EUTRA_PhysCellIdRange_range_present;
            }
            numBlacklistedCellsToAddMod++;
        }
    }

    if (0 != numBlacklistedCellsToAddMod)
    {
        if (ERROR == VCCB_ConnectLinkedList(blacklistedCellsToAddMod, numBlacklistedCellsToAddMod))
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in VCCB_Fill_BlacklistedCellsToAddModEutra!\n");

            return ERROR;
        }
        pDst->excludedCellsToAddModListEUTRAN = blacklistedCellsToAddMod;
    }
    else
    {
        pDst->excludedCellsToAddModListEUTRAN = NULL;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC__seqof179 object basing
 *                  on VCCB specific blackCellsUe_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_MeasObjectEUTRA*
 * @param[in]       pInstalled : Pointer to configuration already installed
 *                               on UE (base for the diff). / blackCellsEutra_type*
 * @param[in]       pNew : Pointer to new configuration. / blackCellsEutra_type*
 * @param[in]       fullConfig : specifies whether pDst should be filled
 *                  with a diff or full configuration.
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_BlacklistedCellsToAddModEutra(NRRRC_MeasObjectEUTRA *pDst, const blackCellsEutra_type *pInstalled,
    const blackCellsEutra_type *pNew, bool fullConfig)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    pDst->excludedCellsToAddModListEUTRAN = NULL;

    if (fullConfig)
    {
        return VCCB_Copy_BlackCellsToAddModEutra(pDst, pNew);
    }
    else
    {
        return VCCB_Fill_BlacklistedCellsToAddModEutra(pDst, pInstalled, pNew);
    }
}

class CellsToAddAndRemoveModListEUTRAFiller
{
public:
    CellsToAddAndRemoveModListEUTRAFiller(
        const cellsToMeasureListEutra_type *pInstalled, cellsToMeasureListEutra_type &newItems, const bool fullConfig);
    int16_t fill(NRRRC_MeasObjectEUTRA &dst);

private:
    int16_t fillCellsToRemoveList(NRRRC_MeasObjectEUTRA &dst);
    int16_t fillCellsToAddModList(NRRRC_MeasObjectEUTRA &dst);
    std::optional<eutra_cell_type> findMatchingInstalledElement(const uint16_t pci) const;

    const cellsToMeasureListEutra_type emptyCellsToMeasureListEutra_{};
    ConsecutiveIdsPool<1, MAX_EUTRA_OF_CELLS_TO_MEASURE> cellIndexEUTRAPool_;
    const cellsToMeasureListEutra_type *pInstalled_;
    cellsToMeasureListEutra_type &newItems_;
};

CellsToAddAndRemoveModListEUTRAFiller::CellsToAddAndRemoveModListEUTRAFiller(
    const cellsToMeasureListEutra_type *pInstalled, cellsToMeasureListEutra_type &newItems, const bool fullConfig) :
    pInstalled_(pInstalled),
    newItems_(newItems)
{
    AUTO_TRACE_FUNC;

    if (fullConfig)
    {
        pInstalled_ = &emptyCellsToMeasureListEutra_;
    }
    else
    {
        for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(pInstalled_->items, pInstalled_->numItems); ++i)
        {
            if (pInstalled_->items[i].cellIndexEUTRA != CELL_INDEX_EUTRA_INIT)
            {
                cellIndexEUTRAPool_.occupy(pInstalled_->items[i].cellIndexEUTRA);
            }
        }
    }
};

int16_t CellsToAddAndRemoveModListEUTRAFiller::fill(NRRRC_MeasObjectEUTRA &dst)
{
    AUTO_TRACE_FUNC;

    if (pInstalled_->numItems > MAX_EUTRA_OF_CELLS_TO_MEASURE)
    {
        VCCB_PRINT_ERROR(
            "ERROR: Installed configuration: incorrect number of cells (%hu) in "
            "CellsToAddAndRemoveModListEUTRAFiller::fill, allowed range %d - %d!\n",
            pInstalled_->numItems, 0, MAX_EUTRA_OF_CELLS_TO_MEASURE);
        return ERROR;
    }

    if (newItems_.numItems > MAX_EUTRA_OF_CELLS_TO_MEASURE)
    {
        VCCB_PRINT_ERROR(
            "ERROR: New configuration: incorrect number of cells (%hu) in CellsToAddAndRemoveModListEUTRAFiller::fill, "
            "allowed range %d - %d!\n",
            newItems_.numItems, 0, MAX_EUTRA_OF_CELLS_TO_MEASURE);
        return ERROR;
    }

    dst.cellsToRemoveListEUTRAN = nullptr;
    dst.cellsToAddModListEUTRAN = nullptr;

    if (ERROR == fillCellsToRemoveList(dst))
    {
        return ERROR;
    }

    if (ERROR == fillCellsToAddModList(dst))
    {
        return ERROR;
    }

    return GOOD;
}

int16_t CellsToAddAndRemoveModListEUTRAFiller::fillCellsToRemoveList(NRRRC_MeasObjectEUTRA &dst)
{
    AUTO_TRACE_FUNC;

    NRRRC_EUTRA_CellIndexList cellsToRemove;
    uint8_t numCellsToRemove = 0;
    staticUnorderedSet<uint16_t, MAX_EUTRA_OF_CELLS_TO_MEASURE> newPCIs;

    if (0 == pInstalled_->numItems)
    {
        return GOOD;
    }

    for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(newItems_.items, newItems_.numItems); ++i)
    {
        newPCIs.insert(newItems_.items[i].pci);
    }

    if (GOOD != VCCB_GlobalAlloc(cellsToRemove, MAX_EUTRA_OF_CELLS_TO_MEASURE))
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_GlobalAlloc failed in fillCellsToRemoveList!\n");
        return ERROR;
    }

    for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(pInstalled_->items, pInstalled_->numItems); ++i)
    {
        if (!newPCIs.contains(pInstalled_->items[i].pci))
        {
            cellsToRemove[numCellsToRemove++].value = pInstalled_->items[i].cellIndexEUTRA;
            cellIndexEUTRAPool_.free(pInstalled_->items[i].cellIndexEUTRA);
        }
    }

    if (0 != numCellsToRemove)
    {
        if (ERROR == VCCB_ConnectLinkedList(cellsToRemove, numCellsToRemove))
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in fillCellsToRemoveList!\n");
            return ERROR;
        }
        dst.cellsToRemoveListEUTRAN = cellsToRemove;
        dst.bit_mask |= NRRRC_cellsToRemoveListEUTRAN_present;
    }

    return GOOD;
}

std::optional<eutra_cell_type> CellsToAddAndRemoveModListEUTRAFiller::findMatchingInstalledElement(
    const uint16_t pci) const
{
    AUTO_TRACE_FUNC;
    for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(pInstalled_->items, pInstalled_->numItems); ++i)
    {
        if (pInstalled_->items[i].pci == pci)
        {
            return std::make_optional(pInstalled_->items[i]);
        }
    }

    return std::nullopt;
}

int16_t CellsToAddAndRemoveModListEUTRAFiller::fillCellsToAddModList(NRRRC_MeasObjectEUTRA &dst)
{
    AUTO_TRACE_FUNC;
    using CellsToAddModList_type = decltype(NRRRC_MeasObjectEUTRA::cellsToAddModListEUTRAN);

    CellsToAddModList_type cellsToAddModListEUTRAN = nullptr;
    NRRRC_EUTRA_Cell *cellsToAddMod = nullptr;
    uint8_t numCellsToAdd = 0;

    if (GOOD != VCCB_GlobalAlloc(cellsToAddModListEUTRAN, MAX_EUTRA_OF_CELLS_TO_MEASURE))
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_GlobalAlloc failed in fillCellsToAddModList!\n");
        return ERROR;
    }

    for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(newItems_.items, newItems_.numItems); ++i)
    {
        auto matchingInstalledItem = findMatchingInstalledElement(newItems_.items[i].pci);
        if (matchingInstalledItem)
        {
            newItems_.items[i].cellIndexEUTRA = matchingInstalledItem->cellIndexEUTRA;

            if (matchingInstalledItem->cellIndividualOffset != newItems_.items[i].cellIndividualOffset)
            {  // item was modified
                cellsToAddMod = &cellsToAddModListEUTRAN[numCellsToAdd++].value;
                cellsToAddMod->cellIndexEUTRA = matchingInstalledItem->cellIndexEUTRA;
                cellsToAddMod->physCellId = matchingInstalledItem->pci;
                cellsToAddMod->cellIndividualOffset =
                    static_cast<NRRRC_EUTRA_Q_OffsetRange>(newItems_.items[i].cellIndividualOffset);
            }
            // item is the same
        }
        else
        {  // new item
            const auto cellIndexEUTRA = cellIndexEUTRAPool_.take();

            if (!cellIndexEUTRA.has_value())
            {
                VCCB_PRINT_ERROR("ERROR: No more available IDs in cellIndexEUTRAPool_!\n");
                return ERROR;
            }

            cellsToAddMod = &cellsToAddModListEUTRAN[numCellsToAdd++].value;
            cellsToAddMod->cellIndexEUTRA = static_cast<NRRRC_EUTRA_CellIndex>(cellIndexEUTRA.value());
            cellsToAddMod->physCellId = static_cast<NRRRC_EUTRA_PhysCellId>(newItems_.items[i].pci);
            cellsToAddMod->cellIndividualOffset =
                static_cast<NRRRC_EUTRA_Q_OffsetRange>(newItems_.items[i].cellIndividualOffset);

            newItems_.items[i].cellIndexEUTRA = static_cast<uint8_t>(cellIndexEUTRA.value());
        }
    }

    if (0 != numCellsToAdd)
    {
        if (ERROR == VCCB_ConnectLinkedList(cellsToAddModListEUTRAN, numCellsToAdd))
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in fillCellsToAddModList!\n");
            return ERROR;
        }
        dst.cellsToAddModListEUTRAN = cellsToAddModListEUTRAN;
        dst.bit_mask |= NRRRC_cellsToAddModListEUTRAN_present;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_MeasObjectEUTRA type
 *                  basing on diff of two VCCB specific measurementObjectUe_type
 *                  objects.
 *
 * @param[out]      pDst : Pointer to a destination object
 * @param[in]       pInstalled : Pointer to configuration already installed
 *                               on UE (base for the diff).
 * @param[in]       pNew : Pointer to new configuration.
 * @param[in]       pCell : Pointer to (new) serving cell.
 * @param[in]       fullConfig : specifies whether pDst should be filled
 *                  with a diff or full configuration.
 * @return          status : GOOD, ERROR
 ****************************************************************************/
int16_t VCCB_Fill_MeasObjectEUTRA(NRRRC_MeasObjectEUTRA *pDst, const measurementObjectEUTRAUe_type *pInstalled,
    measurementObjectEUTRAUe_type *pNew, VccbCellInfo_type *pCell, bool fullConfig)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);
    VALID_E_POINT_CHECK_ERROR(pCell);

    pDst->bit_mask = 0;

    // carrierFreq
    pDst->carrierFreq = pNew->minimal.overlappedCarrierFreq;

    // allowedMeasBandwidth
    pDst->allowedMeasBandwidth = static_cast<NRRRC_EUTRA_AllowedMeasBandwidth>(pNew->minimal.allowedMeasBandwidth);

    // cellsToRemoveListEUTRAN && cellsToAddModListEUTRAN
    CellsToAddAndRemoveModListEUTRAFiller cellsToAddAndRemoveModListEUTRAFiller(
        &pInstalled->cellsToMeasureEutra, pNew->cellsToMeasureEutra, fullConfig);
    if (GOOD != cellsToAddAndRemoveModListEUTRAFiller.fill(*pDst))
    {
        VCCB_PRINT_ERROR("ERROR: CellsToAddAndRemoveModListEUTRAFiller::fill failed in VCCB_Fill_MeasObjectEUTRA!\n");
        return ERROR;
    }

    // blackCellsToRemoveListEUTRAN
    if (GOOD != VCCB_Fill_BlacklistedCellsToRemoveEutra(pDst, &pInstalled->blackCells, &pNew->blackCells, fullConfig))
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_BlacklistedCellsToRemoveEutra failed in VCCB_Fill_MeasObjectEUTRA!\n");

        return ERROR;
    }
    if (NULL != pDst->excludedCellsToRemoveListEUTRAN)
    {
        pDst->bit_mask |= NRRRC_excludedCellsToRemoveListEUTRAN_present;
    }

    // blackCellsToAddModListEUTRAN
    if (GOOD != VCCB_Fill_BlacklistedCellsToAddModEutra(pDst, &pInstalled->blackCells, &pNew->blackCells, fullConfig))
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_BlacklistedCellsToAddModEutra failed in VCCB_Fill_MeasObjectEUTRA!\n");

        return ERROR;
    }
    if (NULL != pDst->excludedCellsToAddModListEUTRAN)
    {
        pDst->bit_mask |= NRRRC_excludedCellsToAddModListEUTRAN_present;
    }

    // eutra-PresenceAntennaPort1
    pDst->eutra_PresenceAntennaPort1 =
        static_cast<NRRRC_EUTRA_PresenceAntennaPort1>(pNew->minimal.presenceAntennaPort1);

    // eutra-Q-OffsetRange - OPTIONAL
    if (eutraQOffsetRange_noUse != pNew->minimal.qOffsetRange)
    {
        pDst->bit_mask |= NRRRC_eutra_Q_OffsetRange_present;
        pDst->eutra_Q_OffsetRange = static_cast<NRRRC_EUTRA_Q_OffsetRange>(pNew->minimal.qOffsetRange);
    }

    // widebandRSRQ-Meas
    pDst->widebandRSRQ_Meas = static_cast<ossBoolean>(pNew->minimal.widebandRSRQMeas);

    return GOOD;
}

int16_t VCCB_Fill_CellsToAddModListDiff(
    NRRRC_CellsToAddModList *pDst, const cellsToMeasureList_type *pInstalled, const cellsToMeasureList_type *pNew)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    NRRRC_CellsToAddModList cellsToAddMod = NULL;
    uint8_t numCellsToAddMod = 0;
    bool needAdd = true;
    *pDst = NULL;

    if (pInstalled->numItems > MAX_NR_OF_CELLS_TO_MEASURE)
    {
        VCCB_PRINT_ERROR(
            "ERROR: Installed configuration: incorrect number of cells (%hu) in VCCB_Fill_CellsToAddModListDiff, "
            "allowed range %d - %d!\n",
            pInstalled->numItems, 0, MAX_NR_OF_CELLS_TO_MEASURE);

        return ERROR;
    }

    if (pNew->numItems > MAX_NR_OF_CELLS_TO_MEASURE)
    {
        VCCB_PRINT_ERROR(
            "ERROR: New configuration: incorrect number of cells (%hu) in VCCB_Fill_CellsToAddModListDiff, allowed "
            "range %d - %d!\n",
            pNew->numItems, 0, MAX_NR_OF_CELLS_TO_MEASURE);

        return ERROR;
    }

    if (GOOD != VCCB_GlobalAlloc(cellsToAddMod, MAX_NR_OF_CELLS_TO_MEASURE))  // Check Init:OK
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_GlobalAlloc failed in VCCB_Fill_CellsToAddModListDiff!\n");

        return ERROR;
    }

    for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(pNew->items, pNew->numItems); ++i)
    {
        needAdd = true;

        for (uint8_t j = 0; j < util::minOfArraySizeAndNumOfElems(pInstalled->items, pInstalled->numItems); ++j)
        {
            if (pNew->items[i].pci == pInstalled->items[j].pci)
            {
                if (pNew->items[i].cellIndividualOffset != pInstalled->items[j].cellIndividualOffset)
                {
                    needAdd = true;
                }
                else
                {
                    needAdd = false;
                }
                break;
            }
        }

        if (needAdd == true)
        {
            VCCB_Fill_CellsToAddMod(cellsToAddMod[numCellsToAddMod].value, pNew->items[i]);
            numCellsToAddMod++;
        }
    }
    if (numCellsToAddMod != 0)
    {
        if (ERROR == VCCB_ConnectLinkedList(cellsToAddMod, numCellsToAddMod))
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in VCCB_Fill_CellsToAddModListDiff!\n");

            return ERROR;
        }
        *pDst = cellsToAddMod;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_CellsToAddModList object using
 *                  two VCCB specific cellsToMeasureList_type objects and mode.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_CellsToAddModList*
 * @param[in]       pInstalled : Pointer to configuration already installed
 *                               on UE (base for the diff). / cellsToMeasureList_type*
 * @param[in]       pNew : Pointer to new configuration. / cellsToMeasureList_type*
 * @param[in]       fullConfig : is full configuration. / bool
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_CellsToAddModList(NRRRC_CellsToAddModList *pDst, const cellsToMeasureList_type *pInstalled,
    const cellsToMeasureList_type *pNew, bool fullConfig)
{
    AUTO_TRACE_FUNC;

    if (fullConfig)
    {
        return VCCB_Copy_CellsToMeasure(pDst, pNew);
    }
    else
    {
        return VCCB_Fill_CellsToAddModListDiff(pDst, pInstalled, pNew);
    }
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_MeasObjectNR type
 *                  basing on diff of two VCCB specific measurementObjectUe_type
 *                  objects.
 *
 * @param[out]      pDst : Pointer to a destination object
 * @param[in]       pInstalled : Pointer to configuration already installed
 *                               on UE (base for the diff).
 * @param[in]       pNew : Pointer to new configuration.
 * @param[in]       pCell : Pointer to (new) serving cell.
 * @param[in]       fullConfig : specifies whether pDst should be filled
 *                  with a diff or full configuration.
 * @return          status : GOOD, ERROR
 ****************************************************************************/
int16_t VCCB_Fill_MeasObjectNR(NRRRC_MeasObjectNR *pDst, const measurementObjectNRUe_type *pInstalled,
    const measurementObjectNRUe_type *pNew, VccbCellInfo_type *pCell, bool fullConfig)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);
    VALID_E_POINT_CHECK_ERROR(pCell);

    pDst->bit_mask = 0;

    bool condSSBorAssociatedSSB = VCCB_CheckCondSsbOrAssociatedSsb(pNew->minimal.referenceSignalConfig);
    bool condIntraFreqConnected = condSSBorAssociatedSSB && (pNew->minimal.ssbFrequency == pCell->ssbArfcn) &&
                                  (pNew->minimal.ssbSubcarrierSpacing == pCell->nrScsDl);

    if (condSSBorAssociatedSSB)
    {
        // ssbFrequency
        pDst->ssbFrequency = FnVCCB_GetRrcMeasObjectNrSsbFrequency(pNew->minimal);
        pDst->bit_mask |= NRRRC_MeasObjectNR_ssbFrequency_present;

        // ssbSubcarrierSpacing
        pDst->ssbSubcarrierSpacing = static_cast<NRRRC_SubcarrierSpacing>(FnVCCB_GetRrcMeasObjectNrSsbScs(pNew->minimal));
        pDst->bit_mask |= NRRRC_MeasObjectNR_ssbSubcarrierSpacing_present;

        // smtc1
        auto smtc1 = FnVCCB_GetRrcMeasObjectNrSsbSmtc1(pNew->minimal);
        if (VCCB_Fill_SSB_MTC1(&pDst->smtc1, &smtc1) != GOOD)
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_Fill_SSB_MTC1 failed in VCCB_Fill_MeasObjectNR!\n");
            return ERROR;
        }
        pDst->bit_mask |= NRRRC_smtc1_present;

        // absThreshSS_BlocksConsolidation
        VCCB_Fill_ThresholdNR(pDst->absThreshSS_BlocksConsolidation, pNew->minimal.absThreshSS_BlocksConsolidation);

        if (pDst->absThreshSS_BlocksConsolidation.bit_mask != 0)
        {
            pDst->bit_mask |= NRRRC_MeasObjectNR_absThreshSS_BlocksConsolidation_present;
        }

        // nrofSS_BlocksToAverage
        if (pNew->minimal.nrofSS_BlocksToAverage >= 2 &&
            pNew->minimal.nrofSS_BlocksToAverage <= NRRRC_maxNrofSS_BlocksToAverage)
        {
            pDst->nrofSS_BlocksToAverage = pNew->minimal.nrofSS_BlocksToAverage;
            pDst->bit_mask |= NRRRC_MeasObjectNR_nrofSS_BlocksToAverage_present;
        }
    }

    if (condIntraFreqConnected)
    {
        // smtc2
        if (VCCB_Fill_SSB_MTC2(pDst, &pNew->minimal.smtc2) != GOOD)
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_Fill_SSB_MTC2 failed in VCCB_Fill_MeasObjectNR!\n");
            return ERROR;
        }
    }

    // referenceSignalConfig
    if (VCCB_Fill_ReferenceSignalConfig(&pDst->referenceSignalConfig, &pInstalled->minimal.referenceSignalConfig,
            &pNew->minimal.referenceSignalConfig, fullConfig) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_ReferenceSignalConfig failed in VCCB_Fill_MeasObjectToAddMod!\n");

        return ERROR;
    }

    // quantityConfigIndex
    pDst->quantityConfigIndex = pNew->minimal.quantityConfigIndex;

    // offsetMO
    VCCB_Fill_Q_OffsetRangeList(pDst->offsetMO, pNew->minimal.offsetMO);

    // cellsToRemoveList
    if (VCCB_Fill_CellsToRemoveList(
            &pDst->cellsToRemoveList, &pInstalled->cellsToMeasure, &pNew->cellsToMeasure, fullConfig) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_CellsToRemoveList failed in VCCB_Fill_MeasObjectToAddMod!\n");

        return ERROR;
    }
    if (pDst->cellsToRemoveList != NULL)
    {
        pDst->bit_mask |= NRRRC_cellsToRemoveList_present;
    }

    // cellsToAddModList
    if (VCCB_Fill_CellsToAddModList(
            &pDst->cellsToAddModList, &pInstalled->cellsToMeasure, &pNew->cellsToMeasure, fullConfig) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_CellsToAddModList failed in VCCB_Fill_MeasObjectToAddMod!\n");

        return ERROR;
    }
    if (pDst->cellsToAddModList != NULL)
    {
        pDst->bit_mask |= NRRRC_cellsToAddModList_present;
    }

    // freqBandIndicatorNR-v1530
    if (0 != pNew->minimal.freqBandIndicatorNR)
    {
        pDst->freqBandIndicatorNR = pNew->minimal.freqBandIndicatorNR;
        pDst->bit_mask |= NRRRC_MeasObjectNR_freqBandIndicatorNR_present;
    }

    // no fulConfig old measurement object uses a timer and new one not - RELEASE
    if (!fullConfig && (true == pInstalled->minimal.T312.useT312) && (false == pNew->minimal.T312.useT312))
    {
        pDst->t312_r16.choice = NRRRC_t312_r16_release_chosen;
        pDst->t312_r16.u.release = 0;
        pDst->bit_mask |= NRRRC_t312_r16_present;
    }
    // no fulConfig and old measurement object doesn't use a timer and new one yes
    // no fulConfig and both old measurement object and new one use timerT312 and old timerT312 differs from the new one
    // yes fulConfig and new uses timer -
    // - SETUP (force new configuration)
    else if ((true == pNew->minimal.T312.useT312) &&
             ((!fullConfig && ((false == pInstalled->minimal.T312.useT312) ||
                                  ((true == pInstalled->minimal.T312.useT312) &&
                                      (pInstalled->minimal.T312.timerT312 != pNew->minimal.T312.timerT312)))) ||
                 fullConfig))
    {
        pDst->t312_r16.choice = NRRRC_t312_r16_setup_chosen;
        pDst->t312_r16.u.setup = static_cast<NRRRC_T312_r16>(pNew->minimal.T312.timerT312);
        pDst->bit_mask |= NRRRC_t312_r16_present;
    }

    // blackCellsToRemoveList
    if (GOOD != VCCB_Fill_BlacklistedCellsToRemoveNR(pDst, &pInstalled->blackCells, &pNew->blackCells, fullConfig))
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_BlacklistedCellsToRemoveNR failed in VCCB_Fill_MeasObjectToAddMod!\n");

        return ERROR;
    }
    if (NULL != pDst->excludedCellsToRemoveList)
    {
        pDst->bit_mask |= NRRRC_excludedCellsToRemoveList_present;
    }

    // blackCellsToAddModList
    if (GOOD != VCCB_Fill_BlacklistedCellsToAddModNR(pDst, &pInstalled->blackCells, &pNew->blackCells, fullConfig))
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_BlacklistedCellsToAddModNR failed in VCCB_Fill_MeasObjectToAddMod!\n");

        return ERROR;
    }
    if (NULL != pDst->excludedCellsToAddModList)
    {
        pDst->bit_mask |= NRRRC_excludedCellsToAddModList_present;
    }

    // allowedCellsToRemoveList
    // allowedCellsToAddModList
    if (fullConfig)
    {
        const pciRangeElements_type emptyPciRanges{};
        if (ERROR == VCCB_FillAllowedCellListToRemoveDelta(
                         pDst->allowedCellsToRemoveList, emptyPciRanges, pNew->minimal.allowedCells))
        {
            return ERROR;
        }
        if (ERROR == VCCB_FillAllowedCellListToAddModDelta(
                         pDst->allowedCellsToAddModList, emptyPciRanges, pNew->minimal.allowedCells))
        {
            return ERROR;
        }
    }
    else
    {
        if (ERROR == VCCB_FillAllowedCellListToRemoveDelta(
                         pDst->allowedCellsToRemoveList, pInstalled->minimal.allowedCells, pNew->minimal.allowedCells))
        {
            return ERROR;
        }
        if (ERROR == VCCB_FillAllowedCellListToAddModDelta(
                         pDst->allowedCellsToAddModList, pInstalled->minimal.allowedCells, pNew->minimal.allowedCells))
        {
            return ERROR;
        }
    }
    if (NULL != pDst->allowedCellsToRemoveList)
    {
        pDst->bit_mask |= NRRRC_allowedCellsToRemoveList_present;
    }
    if (NULL != pDst->allowedCellsToAddModList)
    {
        pDst->bit_mask |= NRRRC_allowedCellsToAddModList_present;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_MeasObjectToAddMod type
 *                  basing on diff of two VCCB specific measurementObjectUe_type
 *                  objects.
 *
 * @param[out]      pDst : Pointer to a destination object / NRRRC_MeasObjectToAddMod*
 * @param[in]       pInstalled : Pointer to configuration already installed
 *                               on UE (base for the diff). / measurementObjectUe_type*
 * @param[in]       pNew : Pointer to new configuration. / measurementObjectUe_type*
 * @param[in]       pCell : Pointer to (new) serving cell. / VccbCellInfo_type*
 * @param[in]       fullConfig : specifies whether pDst should be filled
 *                  with a diff or full configuration. / bool
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_MeasObjectToAddMod(NRRRC_MeasObjectToAddMod *pDst, const measurementObjectUe_type *pInstalledObj,
    measurementObjectUe_type *pNewObj, VccbCellInfo_type *pCell, bool fullConfig)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pInstalledObj);
    VALID_E_POINT_CHECK_ERROR(pNewObj);
    VALID_E_POINT_CHECK_ERROR(pCell);

    pDst->measObjectId =
        static_cast<NRRRC_MeasObjectId>(pNewObj->objectId + 1);  // need to add 1 to compensate for 1-based indexing

    switch (pNewObj->conf.ratType)
    {
        case measRatNr:
            pDst->measObject.choice = NRRRC_measObjectNR_chosen;

            if (GOOD != VCCB_Fill_MeasObjectNR(&pDst->measObject.u.measObjectNR, &pInstalledObj->conf.rat.nr,
                            &pNewObj->conf.rat.nr, pCell, fullConfig))
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_MeasObjectNR failed in VCCB_Fill_MeasObjectToAddMod!\n");

                return ERROR;
            }
            break;

        case measRatEutra:
            pDst->measObject.choice = NRRRC_measObjectEUTRA_chosen;

            if (GOOD != VCCB_Fill_MeasObjectEUTRA(&pDst->measObject.u.measObjectEUTRA, &pInstalledObj->conf.rat.eutra,
                            &pNewObj->conf.rat.eutra, pCell, fullConfig))
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_Fill_MeasObjectEUTRA failed in VCCB_Fill_MeasObjectToAddMod!\n");

                return ERROR;
            }
            break;

        default:
            VCCB_PRINT_ERROR("ERROR: Invalid ratType(%u) in VCCB_Fill_MeasObjectToAddMod!\n", pNewObj->conf.ratType);

            return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills NRRRC_MeasObjectToAddModList list, based on
 *                  the supplied arguments.
 *
 * @param[in]       ptCi : Pointer to call configuration / callInfo_type*
 * @param[out]      pDst : Target list of measurement objects to add.
 *                         The return value is NULL if there are no objects
 *                         to add. / NRRRC_MeasObjectToAddModList*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeMeasObjectToAddModListInstalled(callInfo_type *ptCi, NRRRC_MeasObjectToAddModList *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);
    uint8_t numItemsToAdd = 0;
    uint8_t sortedInstalledItemsIndexes[MAX_NR_OF_OBJECT_ID];

    if (ptCi->myThreadId >= MAX_CALL_THREAD_NUM_VCCB)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: Invalid thread id (%u) in VCCB_MakeMeasObjectToAddModListInstalled! "
            "MAX_CALL_THREAD_NUM_VCCB: %u\n", ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

        return ERROR;
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    const size_t installedMeasObjects = VCCB_CountUsedElements(rMeasConf.measurementObjects.installedItems);
    if (0 == installedMeasObjects)
    {
        *pDst = NULL;

        return GOOD;
    }

    std::iota(std::begin(sortedInstalledItemsIndexes), std::end(sortedInstalledItemsIndexes), 0);
    std::sort(std::begin(sortedInstalledItemsIndexes), std::end(sortedInstalledItemsIndexes),
        [&rMeasConf](uint8_t a, uint8_t b)
        {
            return rMeasConf.measurementObjects.installedItems[a].objectId <
                   rMeasConf.measurementObjects.installedItems[b].objectId;
        });

    for (uint8_t index : sortedInstalledItemsIndexes)
    {
        if (VCCB_ARRAY_COUNT(rMeasConf.measurementObjects.installedItems) <= index)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "ERROR: VCCB_MakeMeasObjectToAddModListInstalled error - measurementObjects.installedItems index i(%u) "
                "goes beyond tab size (%lu)\n",
                index, VCCB_ARRAY_COUNT(rMeasConf.measurementObjects.installedItems));
            return ERROR;
        }

        if (rMeasConf.measurementObjects.installedItems[index].usage == CI_use)
        {
            if (VCCB_Fill_MeasObjectToAddMod(&(gMeasConf[ptCi->myThreadId].measObjToAddMod[numItemsToAdd].value),
                    &(rMeasConf.measurementObjects.installedItems[index]), &CELLINFO[ptCi->servCellNum]) != GOOD)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_Fill_MeasObjectToAddMod failed for measurement object %hu"
                     " in VCCB_MakeMeasObjectToAddModList!\n", index);

                return ERROR;
            }
            ++numItemsToAdd;
        }
    }

    if (numItemsToAdd != 0)
    {
        if (ERROR == VCCB_ConnectLinkedList(gMeasConf[ptCi->myThreadId].measObjToAddMod, numItemsToAdd))
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "ERROR: VCCB_ConnectLinkedList failed in VCCB_MakeMeasObjectToAddModListInstalled!\n");

            return ERROR;
        }
        *pDst = gMeasConf[ptCi->myThreadId].measObjToAddMod;
    }
    else
    {
        *pDst = NULL;
    }

    return GOOD;
}

int16_t VCCB_CheckIfEutraCellsToMeasChanged(
    const cellsToMeasureListEutra_type &pInstalled, const cellsToMeasureListEutra_type &pNew)
{
    AUTO_TRACE_FUNC;
    using PciWithOffset = std::pair<uint16_t, uint8_t>;

    if (pNew.numItems != pInstalled.numItems)
    {
        return GOOD;
    }

    simpleVector<PciWithOffset, MAX_EUTRA_OF_CELLS_TO_MEASURE> installedCellsToMeasure;
    simpleVector<PciWithOffset, MAX_EUTRA_OF_CELLS_TO_MEASURE> newCellsToMeasure;

    for (uint32_t i = 0; i < util::minOfArraySizeAndNumOfElems(pNew.items, pNew.numItems); i++)
    {
        newCellsToMeasure.push_back(std::make_pair(pNew.items[i].pci, pNew.items[i].cellIndividualOffset));
        installedCellsToMeasure.push_back(
            std::make_pair(pInstalled.items[i].pci, pInstalled.items[i].cellIndividualOffset));
    }

    std::sort(newCellsToMeasure.begin(), newCellsToMeasure.end());
    std::sort(installedCellsToMeasure.begin(), installedCellsToMeasure.end());

    for (size_t i = 0; i < newCellsToMeasure.size(); i++)
    {
        if (newCellsToMeasure[i].first != installedCellsToMeasure[i].first ||
            newCellsToMeasure[i].second != installedCellsToMeasure[i].second)
        {
            return GOOD;
        }
    }

    return BREAK;
}

int16_t VCCB_CheckIfMeasObjectChanged(
    const measurementObjectEUTRAUe_type *pInstalled, const measurementObjectEUTRAUe_type *pNew)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    // return GOOD : changed..
    if (!IS_VALID_CELLS_TO_MEAS_CELL_INDEX(pInstalled->cellsToMeasureEutra.numItems))
    {
        VCCB_PRINT_ERROR(
            "ERROR: Installed configuration: incorrect number of cells (%hu) in VCCB_CheckIfMeasObjectChanged, allowed "
            "range %d - %d!\n",
            pInstalled->cellsToMeasureEutra.numItems, 0, MAX_EUTRA_OF_CELLS_TO_MEASURE);
        return ERROR;
    }

    if (!IS_VALID_CELLS_TO_MEAS_CELL_INDEX(pNew->cellsToMeasureEutra.numItems))
    {
        VCCB_PRINT_ERROR(
            "ERROR: New configuration: incorrect number of cells (%hu) in VCCB_CheckIfMeasObjectChanged, allowed range "
            "%d - %d!\n",
            pNew->cellsToMeasureEutra.numItems, 0, MAX_EUTRA_OF_CELLS_TO_MEASURE);
        return ERROR;
    }

    if (pInstalled->minimal.overlappedCarrierFreq != pNew->minimal.overlappedCarrierFreq)
    {
        return GOOD;
    }
    if (pInstalled->minimal.allowedMeasBandwidth != pNew->minimal.allowedMeasBandwidth)
    {
        return GOOD;
    }
    if (GOOD == VCCB_CheckIfEutraCellsToMeasChanged(pInstalled->cellsToMeasureEutra, pNew->cellsToMeasureEutra))
    {
        return GOOD;
    }
    if (pInstalled->minimal.presenceAntennaPort1 != pNew->minimal.presenceAntennaPort1)
    {
        return GOOD;
    }
    if (pInstalled->minimal.qOffsetRange != pNew->minimal.qOffsetRange)
    {
        return GOOD;
    }
    if (pInstalled->minimal.widebandRSRQMeas != pNew->minimal.widebandRSRQMeas)
    {
        return GOOD;
    }
    if (!(pInstalled->blackCells == pNew->blackCells))
    {
        return GOOD;
    }

    return BREAK;  // return BREAK : no changed
}

/****************************************************************************
 * @brief           Implements custom logic for comparing two
 *                  measurementObjectUe_type items.
 *
 * @param[in]       pInstalled : Pointer to measurement object configuration
 *                               installed on UE. / measurementObjectNRUe_type*
 * @param[in]       pNew : Pointer to new measurement object
 *                         configuration. / measurementObjectNRUe_type*
 * @return          status : GOOD (change), ERROR (error), BREAK (no change) / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfMeasObjectChanged(
    const measurementObjectNRUe_type *pInstalled, const measurementObjectNRUe_type *pNew)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    bool found = false;

    if (pInstalled->cellsToMeasure.numItems > MAX_NR_OF_CELLS_TO_MEASURE)
    {
        VCCB_PRINT_ERROR(
            "ERROR: Installed configuration: incorrect number of cells (%hu) in VCCB_CheckIfMeasObjectChanged, allowed "
            "range %d - %d!\n",
            pInstalled->cellsToMeasure.numItems, 0, MAX_NR_OF_CELLS_TO_MEASURE);

        return ERROR;
    }

    if (pNew->cellsToMeasure.numItems > MAX_NR_OF_CELLS_TO_MEASURE)
    {
        VCCB_PRINT_ERROR(
            "ERROR: New configuration: incorrect number of cells (%hu) in VCCB_CheckIfMeasObjectChanged, allowed range "
            "%d - %d!\n",
            pNew->cellsToMeasure.numItems, 0, MAX_NR_OF_CELLS_TO_MEASURE);

        return ERROR;
    }

    if (pNew->minimal.referenceSignalConfig.ssbConfigMobility.usage == CI_use)
    {
        if (FnVCCB_GetRrcMeasObjectNrSsbFrequency(pInstalled->minimal) != FnVCCB_GetRrcMeasObjectNrSsbFrequency(pNew->minimal))
        {
            return GOOD;
        }
        if (FnVCCB_GetRrcMeasObjectNrSsbScs(pInstalled->minimal) != FnVCCB_GetRrcMeasObjectNrSsbScs(pNew->minimal))
        {
            return GOOD;
        }
        if (FnVCCB_GetRrcMeasObjectNrSsbSmtc1(pInstalled->minimal) != FnVCCB_GetRrcMeasObjectNrSsbSmtc1(pNew->minimal))
        {
            return GOOD;
        }
        if (pInstalled->minimal.smtc2 != pNew->minimal.smtc2)
        {
            return GOOD;
        }
        if (pInstalled->minimal.referenceSignalConfig.ssbConfigMobility !=
            pNew->minimal.referenceSignalConfig.ssbConfigMobility)
        {
            return GOOD;
        }
        if (pInstalled->minimal.absThreshSS_BlocksConsolidation != pNew->minimal.absThreshSS_BlocksConsolidation)
        {
            return GOOD;
        }
        if (pInstalled->minimal.nrofSS_BlocksToAverage != pNew->minimal.nrofSS_BlocksToAverage)
        {
            return GOOD;
        }
    }

    if (pInstalled->minimal.quantityConfigIndex != pNew->minimal.quantityConfigIndex)
    {
        return GOOD;
    }
    if (pInstalled->minimal.offsetMO != pNew->minimal.offsetMO)
    {
        return GOOD;
    }

    if (pInstalled->cellsToMeasure.numItems != pNew->cellsToMeasure.numItems)
    {
        return GOOD;
    }

    for (uint8_t i = 0;
         i < util::minOfArraySizeAndNumOfElems(pInstalled->cellsToMeasure.items, pInstalled->cellsToMeasure.numItems);
         ++i)
    {
        found = false;

        for (uint8_t j = 0;
             j < util::minOfArraySizeAndNumOfElems(pNew->cellsToMeasure.items, pNew->cellsToMeasure.numItems); j++)
        {
            if (pInstalled->cellsToMeasure.items[j].pci == pNew->cellsToMeasure.items[i].pci)
            {
                if (pInstalled->cellsToMeasure.items[j].cellIndividualOffset !=
                    pNew->cellsToMeasure.items[i].cellIndividualOffset)
                {
                    return GOOD;
                }
                found = true;
            }
        }

        if (found == false)
        {
            return GOOD;
        }
    }

    if (pInstalled->minimal.freqBandIndicatorNR != pNew->minimal.freqBandIndicatorNR)
    {
        return GOOD;
    }

    if (pInstalled->minimal.T312 != pNew->minimal.T312)
    {
        return GOOD;
    }

    if (!(pInstalled->blackCells == pNew->blackCells))
    {
        return GOOD;
    }

    // allowedCells
    {
        if (pInstalled->minimal.allowedCells.numOfPciRanges != pNew->minimal.allowedCells.numOfPciRanges)
        {
            return GOOD;
        }
        simpleVector<uint16_t, VCCB_ARRAY_COUNT(pInstalled->minimal.allowedCells.pciRanges)> installedPcis{};
        simpleVector<uint16_t, VCCB_ARRAY_COUNT(pInstalled->minimal.allowedCells.pciRanges)> newPcis{};
        for (uint8_t i = 0; i < pInstalled->minimal.allowedCells.numOfPciRanges; i++)
        {
            installedPcis.push_back(pInstalled->minimal.allowedCells.pciRanges[i].pci);
        }
        std::sort(installedPcis.begin(), installedPcis.end());
        for (uint8_t i = 0; i < pNew->minimal.allowedCells.numOfPciRanges; i++)
        {
            newPcis.push_back(pNew->minimal.allowedCells.pciRanges[i].pci);
        }
        std::sort(newPcis.begin(), newPcis.end());
        if (!std::equal(installedPcis.begin(), installedPcis.end(), newPcis.begin(), newPcis.end()))
        {
            return GOOD;
        }
    }

    return BREAK;
}

/****************************************************************************
 * @brief           Implements custom logic for comparing two
 *                  measurementObjectUe_type items.
 *
 * @param[in]       pInstalled : Pointer to measurement object configuration
 *                               installed on UE. / measurementObjectUe_type*
 * @param[in]       pNew : Pointer to new measurement object
 *                         configuration. / measurementObjectUe_type*
 * @return          status : GOOD (change), ERROR (error), BREAK (no change) / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfMeasObjectChanged(
    const measurementObjectUe_type *pInstalledObj, const measurementObjectUe_type *pNewObj)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pInstalledObj);
    VALID_E_POINT_CHECK_ERROR(pNewObj);

    int16_t status = GOOD;

    if (pInstalledObj->usage != pNewObj->usage)
    {
        VCCB_PRINT_ERROR(
            "ERROR: Inconsistent value of usage flag in VCCB_CheckIfMeasObjectChanged: installed %hu, new %hu!\n",
            pInstalledObj->usage, pNewObj->usage);

        return ERROR;
    }

    if (pInstalledObj->objectId != pNewObj->objectId)
    {
        VCCB_PRINT_ERROR(
            "ERROR: Inconsistent value of objectId in VCCB_CheckIfMeasObjectChanged: installed %hu, new %hu!\n",
            pInstalledObj->objectId, pNewObj->objectId);

        return ERROR;
    }

    if (pInstalledObj->conf.ratType != pNewObj->conf.ratType)
    {
        return GOOD;
    }

    switch (pNewObj->conf.ratType)
    {
        case measRatNr:
            status = VCCB_CheckIfMeasObjectChanged(&pInstalledObj->conf.rat.nr, &pNewObj->conf.rat.nr);
            break;

        case measRatEutra:
            status = VCCB_CheckIfMeasObjectChanged(&pInstalledObj->conf.rat.eutra, &pNewObj->conf.rat.eutra);
            break;

        default:
            VCCB_PRINT_ERROR("ERROR: New configuration: incorrect ratType(%u) in VCCB_CheckIfMeasObjectChanged!\n",
                pNewObj->conf.ratType);

            return ERROR;
    }

    return status;
}

/****************************************************************************
 * @brief           Fills NRRRC_MeasObjectToAddModList list, based on
 *                  the supplied arguments.
 *
 * @param[in]       ptCi : Pointer to call configuration / callInfo_type*
 * @param[out]      pDst : Target list of measurement objects to add or modify.
 *                         The return value is NULL if there are no objects
 *                         to add or modify. / NRRRC_MeasObjectToAddModList*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeMeasObjectToAddModList(callInfo_type *ptCi, NRRRC_MeasObjectToAddModList *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    bool fullConfig = true;
    int16_t status = ERROR;
    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);
    measurementObjectUe_type *pUeObj = NULL;
    uint8_t numItemsToModify = 0;
    uint8_t sortedNewItemsIndexes[MAX_NR_OF_OBJECT_ID];
    if (0 == rMeasProc.measurementObjects.numNewItems)
    {
        *pDst = NULL;

        return GOOD;
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(rMeasProc.tgtCellNum, MAX_CELL_NUM_VCCB);

    if (rMeasProc.measurementObjects.numNewItems > VCCB_ARRAY_COUNT(rMeasProc.measurementObjects.newItems))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: Invalid number of items (%hu) in VCCB_MakeMeasObjectToAddModList,"
            " maximum allowed number is %lu!\n",
            rMeasProc.measurementObjects.numNewItems, VCCB_ARRAY_COUNT(rMeasProc.measurementObjects.newItems));

        return ERROR;
    }

    rMeasProc.measurementObjects.itemsToModify = 0;

    for (uint8_t i = 0; i < rMeasProc.measurementObjects.numNewItems; ++i)
    {
        sortedNewItemsIndexes[i] = i;
    }

    std::sort(sortedNewItemsIndexes, &sortedNewItemsIndexes[rMeasProc.measurementObjects.numNewItems],
        [&rMeasProc](uint8_t a, uint8_t b)
        {
            return rMeasProc.measurementObjects.newItems[a].objectId <
                   rMeasProc.measurementObjects.newItems[b].objectId;
        });

    for (uint8_t j = 0; j < rMeasProc.measurementObjects.numNewItems; ++j)
    {
        uint8_t i = sortedNewItemsIndexes[j];

        if (VCCB_ARRAY_COUNT(rMeasProc.measurementObjects.newItems) <= i)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "ERROR: VCCB_MakeMeasObjectToAddModList error - measurementObjects.newItems index "
                "i(%u) goes beyond tab size (%lu)\n",
                i, VCCB_ARRAY_COUNT(rMeasProc.measurementObjects.newItems));
            return ERROR;
        }

        // If given object is not yet installed on the UE, its internalIdx is MAX_NR_OF_OBJECT_ID - in this case we need
        // to assign a new id and send its whole configuration
        if (rMeasProc.measurementObjects.newItems[i].internalIdx >= MAX_NR_OF_OBJECT_ID)
        {
            // Find an empty measurement object slot and put the object in there
            pUeObj = std::find_if(std::begin(rMeasConf.measurementObjects.installedItems),
                std::end(rMeasConf.measurementObjects.installedItems),
                VCCB_UnreservedItemMatcher<measurementObjectUe_type>);

            if (pUeObj != std::end(rMeasConf.measurementObjects.installedItems))
            {
                rMeasProc.measurementObjects.newItems[i].internalIdx =
                    static_cast<uint8_t>(pUeObj - &(rMeasConf.measurementObjects.installedItems[0]));
                pUeObj->pending = VCCB_FLAG_ON;
            }
            else
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "ERROR: VCCB_MakeMeasObjectToAddModList error"
                    " - can't find an empty measurement object slot!\n");

                return ERROR;
            }

            fullConfig = true;
        }
        else  // Already installed on the UE, skip or send diff only
        {
            status = VCCB_CheckIfMeasObjectChanged(
                &(rMeasConf.measurementObjects.installedItems[rMeasProc.measurementObjects.newItems[i].internalIdx]),
                &(rMeasProc.measurementObjects.newItems[i]));
            if (status == ERROR)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "ERROR: VCCB_CheckIfMeasObjectChanged failed for measurement object %hu "
                    "(objectId: %hu) in VCCB_MakeMeasObjectToAddModList!\n",
                    i, rMeasProc.measurementObjects.newItems[i].objectId);

                return ERROR;
            }

            if (status == BREAK)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "Measurement object %hu (objectId: %hu) did not change - skipping!\n", i,
                    rMeasProc.measurementObjects.newItems[i].objectId);
                continue;
            }

            fullConfig = false;
        }

        if (VCCB_Fill_MeasObjectToAddMod(&(gMeasConf[ptCi->myThreadId].measObjToAddMod[numItemsToModify].value),
                &(rMeasConf.measurementObjects.installedItems[rMeasProc.measurementObjects.newItems[i].internalIdx]),
                &(rMeasProc.measurementObjects.newItems[i]), &CELLINFO[rMeasProc.tgtCellNum], fullConfig) != GOOD)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "ERROR: VCCB_Fill_MeasObjectToAddMod failed for measurement object %hu (objectId: "
                "%hu) in VCCB_MakeMeasObjectToAddModList!\n",
                i, rMeasProc.measurementObjects.newItems[i].objectId);

            return ERROR;
        }

        ONBIT(rMeasProc.measurementObjects.itemsToModify, i);
        numItemsToModify++;
    }

    if (numItemsToModify != 0)
    {
        if (ERROR == VCCB_ConnectLinkedList(gMeasConf[ptCi->myThreadId].measObjToAddMod, numItemsToModify))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_ConnectLinkedList failed in VCCB_MakeMeasObjectToAddModList!\n");

            return ERROR;
        }
        *pDst = gMeasConf[ptCi->myThreadId].measObjToAddMod;
    }
    else
    {
        *pDst = NULL;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills NRRRC_MeasIdToAddModList list, based on
 *                  the supplied arguments.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target list of measurement identities to add or modify.
 *                         The return value is NULL if there are no configurations
 *                         to add or modify. / NRRRC_MeasIdToAddModList*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeMeasIdToAddModListNew(callInfo_type *ptCi, NRRRC_MeasIdToAddModList *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    uint8_t itemToAddModIdx = 0;
    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);
    measurementIdentity_type *pUeMeasId = NULL;

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    if (rMeasProc.measurementIdentities.numNewItems > MAX_NR_OF_MEAS_ID)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: Invalid number of items (%hu) in VCCB_MakeMeasIdToAddModListNew, maximum allowed "
            "number is %d!\n", rMeasProc.measurementIdentities.numNewItems, MAX_NR_OF_MEAS_ID);

        return ERROR;
    }

    if (rMeasProc.measurementIdentities.numNewItems == 0)
    {
        *pDst = NULL;

        return GOOD;
    }

    for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(
                                rMeasProc.measurementIdentities.newItems, rMeasProc.measurementIdentities.numNewItems);
         ++i)
    {
        // If given measurement identity is not yet installed on the UE, its internalIdx is MAX_NR_OF_MEAS_ID - in this
        // case we need to install it
        if (rMeasProc.measurementIdentities.newItems[i].internalIdx >= MAX_NR_OF_MEAS_ID)
        {
            /*
            // Find an empty measurement identity slot and put the item in there
            pUeMeasId = std::find_if(&(rMeasConf.measurementIdentities.installedItems[0]),
                                     &(rMeasConf.measurementIdentities.installedItems[MAX_NR_OF_MEAS_ID]),
                                     VCCB_UnreservedItemMatcher<measurementIdentity_type>);

            if(pUeMeasId != &(rMeasConf.measurementIdentities.installedItems[MAX_NR_OF_MEAS_ID]))
            {
                rMeasConf.measurementIdentities.newItems[i].internalIdx = (pUeMeasId -
            &(rMeasConf.measurementIdentities.installedItems[0])); pUeMeasId->pending = VCCB_FLAG_ON;
            }
            else
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_MakeMeasIdToAddModList - can't find an empty measurement
            identity slot!\n");

                return ERROR;
            }
            */

            // Derive internalIdx from objectId
            rMeasProc.measurementIdentities.newItems[i].internalIdx =
                rMeasProc.measurementIdentities.newItems[i].objectId;
            pUeMeasId =
                &rMeasConf.measurementIdentities.installedItems[rMeasProc.measurementIdentities.newItems[i].internalIdx];
            pUeMeasId->pending = VCCB_FLAG_ON;

            // need to add 1 to compensate for 1-based indexing
            gMeasConf[ptCi->myThreadId].measIdToAddMod[itemToAddModIdx].value.measId =
                static_cast<NRRRC_MeasId>(rMeasProc.measurementIdentities.newItems[i].objectId + 1);
            gMeasConf[ptCi->myThreadId].measIdToAddMod[itemToAddModIdx].value.measObjectId =
                static_cast<NRRRC_MeasObjectId>(rMeasProc.measurementIdentities.newItems[i].measObjectId + 1);
            gMeasConf[ptCi->myThreadId].measIdToAddMod[itemToAddModIdx].value.reportConfigId =
                static_cast<NRRRC_ReportConfigId>(rMeasProc.measurementIdentities.newItems[i].reportConfigId + 1);
            itemToAddModIdx++;
        }
        else
        {
            // In case the measurement identity is already installed on the UE, avoid overwriting its data.
            rMeasProc.measurementIdentities.newItems[i].internalIdx = MAX_NR_OF_MEAS_ID;
        }
    }

    if (itemToAddModIdx != 0)
    {
        if (ERROR == VCCB_ConnectLinkedList(gMeasConf[ptCi->myThreadId].measIdToAddMod, itemToAddModIdx))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_ConnectLinkedList failed in VCCB_MakeMeasIdToAddModList!\n");

            return ERROR;
        }
        *pDst = gMeasConf[ptCi->myThreadId].measIdToAddMod;
    }
    else
    {
        *pDst = NULL;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills NRRRC_ReportConfigToAddModList list, based on
 *                  the supplied arguments.
 *
 * @param[in]       ptCi : Pointer to call configuration / callInfo_type*
 * @param[out]      pDst : Target list of report configurations to add or modify.
 *                         The return value is NULL if there are no configurations
 *                         to add or modify. / NRRRC_ReportConfigToAddModList*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeReportConfigToAddModList(callInfo_type *ptCi, NRRRC_ReportConfigToAddModList *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    int16_t status = ERROR;
    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    reportConfigurationInstalledUe_type *pUeRpt = NULL;
    uint8_t numItemsToModify = 0;

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    if (rMeasProc.reportConfigurations.numNewItems > MAX_NR_OF_REPORT_CONFIG_ID)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: Invalid number of items (%hu) in VCCB_MakeReportConfigToAddModList, maximum "
            "allowed number is %d!\n", rMeasProc.reportConfigurations.numNewItems, MAX_NR_OF_REPORT_CONFIG_ID);

        return ERROR;
    }

    if (rMeasProc.reportConfigurations.numNewItems == 0)
    {
        *pDst = NULL;

        return GOOD;
    }

    rMeasProc.reportConfigurations.itemsToModify = 0;

    for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(
                                rMeasProc.reportConfigurations.newItems, rMeasProc.reportConfigurations.numNewItems);
         ++i)
    {
        // If given report is not yet installed on the UE, its reportConfigId is MAX_NR_OF_REPORT_CONFIG_ID - in this
        // case we need to assign a new id and send its whole configuration
        if (rMeasProc.reportConfigurations.newItems[i].internalIdx >= MAX_NR_OF_REPORT_CONFIG_ID)
        {
            auto installedItemsBegin = std::begin(rMeasConf.reportConfigurations.installedItems);
            auto installedItemsEnd = std::end(rMeasConf.reportConfigurations.installedItems);

            // Find an empty report configuration slot and put the report in there
            pUeRpt = std::find_if(installedItemsBegin, installedItemsEnd,
                VCCB_UnreservedItemMatcher<reportConfigurationInstalledUe_type>);

            if (pUeRpt != installedItemsEnd)
            {
                rMeasProc.reportConfigurations.newItems[i].internalIdx =
                    static_cast<uint8_t>(pUeRpt - &(rMeasConf.reportConfigurations.installedItems[0]));
                pUeRpt->pending = VCCB_FLAG_ON;
            }
            else
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_MakeReportConfigToAddModList"
                    " - can't find an empty report configuration slot!\n");

                return ERROR;
            }
        }
        else  // Already installed on the UE, send diff only
        {
            status = VCCB_CheckIfReportConfigChanged(
                &(rMeasConf.reportConfigurations.installedItems[rMeasProc.reportConfigurations.newItems[i].internalIdx]),
                &(rMeasProc.reportConfigurations.newItems[i]));
            if (status == ERROR)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "ERROR: VCCB_CheckIfReportConfigChanged failed for report configuration %hu "
                    "(objectId: %hu) in VCCB_MakeReportConfigToAddModList!\n",
                    i, rMeasProc.reportConfigurations.newItems[i].objectId);

                return ERROR;
            }

            if (status == BREAK)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi,
                    "Report configuration %hu (objectId: %hu) did not change - skipping!\n", i,
                    rMeasProc.reportConfigurations.newItems[i].objectId);
                continue;
            }

            VCCB_ResetNumberOfReportsSent(ptCi, i);
        }

        if (VCCB_Fill_ReportConfigToAddMod(ptCi, &(gMeasConf[ptCi->myThreadId].rptCfgToAddMod[numItemsToModify].value),
                &(rMeasProc.reportConfigurations.newItems[i]),
                &(rMeasConf.reportConfigurations
                        .installedItems[rMeasProc.reportConfigurations.newItems[i].internalIdx])) != GOOD)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "ERROR: VCCB_Fill_ReportConfigToAddMod failed for item %hu in "
                "VCCB_MakeReportConfigToAddModList!\n", i);

            return ERROR;
        }

        ONBIT(rMeasProc.reportConfigurations.itemsToModify, i);
        numItemsToModify++;
    }

    if (numItemsToModify != 0)
    {
        if (ERROR == VCCB_ConnectLinkedList(gMeasConf[ptCi->myThreadId].rptCfgToAddMod, numItemsToModify))
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "ERROR: VCCB_ConnectLinkedList failed in VCCB_MakeReportConfigToAddModList!\n");

            return ERROR;
        }
        *pDst = gMeasConf[ptCi->myThreadId].rptCfgToAddMod;
    }
    else
    {
        *pDst = NULL;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills NRRRC_ReportConfigToRemoveList list, based on
 *                  the supplied arguments.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target list of report configurations to remove.
 *                         The return value is NULL if there are no
 *                         configurations to remove. / NRRRC_MeasObjectToRemoveList*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeReportConfigToRemoveList(const callInfo_type *ptCi, NRRRC_ReportConfigToRemoveList *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    uint8_t numItemsToRemove = 0;
    const uint64_t idsToRemove = VCCB_GetAllReportConfigIdsToRemove(*ptCi);

    if (0 == idsToRemove)
    {
        *pDst = NULL;

        return GOOD;
    }

    for (uint8_t bitIndex = 0; bitIndex < MAX_NR_OF_REPORT_CONFIG_ID_3GPP; bitIndex++)
    {
        if (GETBIT(idsToRemove, bitIndex))
        {
            gMeasConf[ptCi->myThreadId].rptCfgToRemove[numItemsToRemove++].value =
                static_cast<NRRRC_ReportConfigId>(bitIndex + 1);  // need to add 1 to compensate for 1-based indexing
        }
    }

    if (ERROR == VCCB_ConnectLinkedList(gMeasConf[ptCi->myThreadId].rptCfgToRemove, numItemsToRemove))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: VCCB_ConnectLinkedList failed in VCCB_MakeReportConfigToRemoveList!\n");

        return ERROR;
    }

    *pDst = gMeasConf[ptCi->myThreadId].rptCfgToRemove;

    return GOOD;
}

/****************************************************************************
 * @brief           Fills NRRRC_MeasObjectToRemoveList list, based on
 *                  the supplied arguments.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target list of measurement objects to remove.
 *                         The return value is NULL if there are no objects
 *                         to remove. / NRRRC_MeasObjectToRemoveList*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeMeasObjectToRemoveList(const callInfo_type *ptCi, NRRRC_MeasObjectToRemoveList *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    const uint64_t allIdsToRemove = VCCB_GetAllMeasObjectIdsToRemove(*ptCi);
    if (0 == allIdsToRemove)
    {
        *pDst = NULL;

        return GOOD;
    }

    uint8_t numItemsToRemove = 0;
    for (uint8_t bitIndex = 0; bitIndex < MAX_NR_OF_OBJECT_ID_3GPP; bitIndex++)
    {
        if (GETBIT(allIdsToRemove, bitIndex))
        {
            gMeasConf[ptCi->myThreadId].measObjToRemove[numItemsToRemove++].value =
                static_cast<NRRRC_MeasObjectId>(bitIndex + 1);  // need to add 1 to compensate for 1-based indexing
        }
    }

    if (ERROR == VCCB_ConnectLinkedList(gMeasConf[ptCi->myThreadId].measObjToRemove, numItemsToRemove))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: VCCB_ConnectLinkedList failed in VCCB_MakeMeasObjectToRemoveList!\n");

        return ERROR;
    }

    *pDst = gMeasConf[ptCi->myThreadId].measObjToRemove;

    return GOOD;
}

/****************************************************************************
 * @brief           Prepares MeasObjectToAddMod and MeasObjectToRemove lists
 *                  based on call configuration, by comparing currently installed
 *                  measurement configuration with a new one and sets the
 *                  bit mask appropriately.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target ASN configuration type. / NRRRC_MeasConfig*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeMeasObjectConfig(callInfo_type *ptCi, NRRRC_MeasConfig *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    /* no removed list for full configuration */
    if (IS_FULLCONFIGURATION_NOT_IN_PROCESS(ptCi))
    {
        if (0 < VCCB_GetAllMeasObjectIdsToRemove(*ptCi))
        {
            if (VCCB_MakeMeasObjectToRemoveList(ptCi, &pDst->measObjectToRemoveList) != GOOD)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "ERROR: VCCB_MakeMeasObjectToRemoveList failed in VCCB_MakeMeasObjectConfig!\n");

                return ERROR;
            }

            if (pDst->measObjectToRemoveList != NULL)
            {
                pDst->bit_mask |= NRRRC_measObjectToRemoveList_present;
            }
        }
    }

    if (VCCB_MakeMeasObjectToAddModList(ptCi, &pDst->measObjectToAddModList) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: VCCB_MakeMeasObjectToAddModList failed in VCCB_MakeMeasObjectConfig\n");

        return ERROR;
    }

    if (pDst->measObjectToAddModList != NULL)
    {
        pDst->bit_mask |= NRRRC_measObjectToAddModList_present;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Prepares ReportConfigToAddMod and ReportConfigToRemove lists
 *                  based on call configuration, by comparing currently installed
 *                  measurement configuration with a new one and sets the bit mask
 *                  appropriately.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target ASN configuration type. / NRRRC_MeasConfig*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeReportConfig(callInfo_type *ptCi, NRRRC_MeasConfig *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    /* no removed list for full configuration */
    if (IS_FULLCONFIGURATION_NOT_IN_PROCESS(ptCi))
    {
        if (0 < VCCB_GetAllReportConfigIdsToRemove(*ptCi))
        {
            if (VCCB_MakeReportConfigToRemoveList(ptCi, &pDst->reportConfigToRemoveList) != GOOD)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "ERROR: VCCB_MakeReportConfigToRemoveList failed in VCCB_MakeReportConfig!\n");

                return ERROR;
            }

            if (pDst->reportConfigToRemoveList != NULL)
            {
                pDst->bit_mask |= NRRRC_reportConfigToRemoveList_present;
            }
        }
    }

    if (VCCB_MakeReportConfigToAddModList(ptCi, &pDst->reportConfigToAddModList) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: VCCB_MakeReportConfigToAddModList failed in VCCB_MakeReportConfig\n");

        return ERROR;
    }

    if (pDst->reportConfigToAddModList != NULL)
    {
        pDst->bit_mask |= NRRRC_reportConfigToAddModList_present;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Prepares MeasIdToAddMod and MeasIdToRemove lists
 *                  based on call configuration, by comparing currently installed
 *                  measurement configuration with a new one and sets the bit mask
 *                  appropriately.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target ASN configuration type. / NRRRC_MeasConfig*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeMeasIdConfiguration(callInfo_type *ptCi, NRRRC_MeasConfig *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    /* no removed list for full configuration */
    if (IS_FULLCONFIGURATION_NOT_IN_PROCESS(ptCi))
    {
        const uint64_t allMeasIdIdsToRemove = VCCB_GetAllMeasIdIdsToRemove(*ptCi);
        if (0 < allMeasIdIdsToRemove)
        {
            if (VCCB_MakeMeasIdToRemoveList(ptCi, &pDst->measIdToRemoveList, allMeasIdIdsToRemove) != GOOD)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "ERROR: VCCB_MakeMeasIdToRemoveList failed in VCCB_MakeMeasIdConfiguration!\n");

                return ERROR;
            }
            if (NULL != pDst->measIdToRemoveList)
            {
                pDst->bit_mask |= NRRRC_measIdToRemoveList_present;
            }
        }
    }

    if (VCCB_MakeMeasIdToAddModListNew(ptCi, &pDst->measIdToAddModList) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: VCCB_MakeMeasIdToAddModListNew failed in VCCB_MakeMeasIdConfiguration!\n");

        return ERROR;
    }
    if (NULL != pDst->measIdToAddModList)
    {
        pDst->bit_mask |= NRRRC_measIdToAddModList_present;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Prepares s-MeasureConfig based on call configuration, by
 *                  comparing currently installed configuration with values in
 *                  the database and sets the bit mask appropriately.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target ASN configuration type. / NRRRC_MeasConfig*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeS_MeasureConfigNew(callInfo_type *ptCi, NRRRC_MeasConfig *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    const measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    if (MAX_CELL_NUM_VCCB <= rMeasProc.tgtCellNum)
    {
        // If tgtCellNum is MAX_CELL_NUM_VCCB it means that measurement preparation has not been performed and S-Measure
        // should not be made.
        VCCB_PRINT_CALL_COMMENT(ptCi, "tgtCellNum is out of range (%d:%d)\n", rMeasProc.tgtCellNum, MAX_CELL_NUM_VCCB);

        return GOOD;
    }

    measurementsData_type *pDbConf = &(CELLINFO[rMeasProc.tgtCellNum].measurementsData);

    /* Send S-MeasurementConfig only when
     * 1) it is not yet installed and some measurements id are being configured or
     * 2) when it has been configured but changed in database
     * The code assumes that proper S-Measure configuration in database is enforced
     * by database constraints. */

    if (((rMeasConf.sMeasureConfig.installedItem.usage == CI_no_use) && (pDst->bit_mask != 0)) ||
        ((rMeasConf.sMeasureConfig.installedItem.usage == CI_use) &&
            (rMeasConf.sMeasureConfig.installedItem != pDbConf->sMeasureConfig)))
    {
        rMeasProc.sMeasureConfig.newItem = pDbConf->sMeasureConfig;
        if (VCCB_Fill_S_MeasureConfig(&pDst->s_MeasureConfig, &rMeasProc.sMeasureConfig.newItem) != GOOD)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "ERROR: VCCB_Fill_S_MeasureConfig failed in VCCB_MakeS_MeasureConfigNew!\n");

            return ERROR;
        }

        rMeasProc.sMeasureConfig.status = VCCB_FLAG_ON;
        pDst->bit_mask |= NRRRC_MeasConfig_s_MeasureConfig_present;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Prepares quantityConfig based on call configuration, by
 *                  comparing currently installed configuration with values in
 *                  the database and sets the bit mask appropriately.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target ASN configuration type. / NRRRC_MeasConfig*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeQuantityConfigNew(const callInfo_type *ptCi, NRRRC_MeasConfig *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    bool fullConfig = false;
    const measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);
    const measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi))
    {
        fullConfig = true;
    }

    if (DBG->flag.forcedIncludeRRC)
    {
        if (ptCi->state == STATE_SN_INTRA_DU_Exe_MN)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Force Include Meas Config\n");
            fullConfig = true;
        }
    }

    if (VCCB_FillQuantityConfig(&pDst->quantityConfig, &rMeasConf.quantityConfigurations.installedItem,
            &rMeasProc.quantityConfigurations.newItem, fullConfig) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: VCCB_FillQuantityConfig failed in VCCB_MakeQuantityConfigNew!\n");

        return ERROR;
    }
    if (0 != pDst->quantityConfig.bit_mask)
    {
        pDst->bit_mask |= NRRRC_MeasConfig_quantityConfig_present;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Prepares quantityConfig based on current call
 *                  configuration.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target ASN configuration type. / NRRRC_MeasConfig*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeQuantityConfigInstalled(callInfo_type *ptCi, NRRRC_MeasConfig *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);

    if (VCCB_FillQuantityConfig(&pDst->quantityConfig, &rMeasConf.quantityConfigurations.installedItem) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: VCCB_FillQuantityConfig failed in VCCB_MakeQuantityConfigNew!\n");

        return ERROR;
    }
    if (0 != pDst->quantityConfig.bit_mask)
    {
        pDst->bit_mask |= NRRRC_MeasConfig_quantityConfig_present;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Prepares measGapConfig for UE. Uses delta signaling.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target ASN configuration type. / NRRRC_MeasConfig*
 * @param[in]       fullConfig : flag if set TRUE - make IE without delta signaling
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeMeasGapConfig(const callInfo_type *ptCi, NRRRC_MeasConfig *pDst, const bool fullConfig)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    pDst->measGapConfig.bit_mask = 0;

    const mGapCfgNode_type &rmGapCfgNew = FnVCCB_GetMGapDuData(*ptCi).mGapCfgNew;
    const mGapCfgNode_type &rmGapCfgInstalled = FnVCCB_GetMeasurementsConfiguration(*ptCi).mGapCfgInstalled;

    if (fullConfig)
    {
        VCCB_MakeMeasGapConfigFull(rmGapCfgNew, *pDst);
        return GOOD;
    }

    // gapFR2
    if (rmGapCfgInstalled.fr2 != rmGapCfgNew.fr2)
    {
        pDst->measGapConfig.bit_mask |= NRRRC_gapFR2_present;
        VCCB_FillGapConfig(pDst->measGapConfig.gapFR2, rmGapCfgNew.fr2);
    }

    // gapFR1
    if (rmGapCfgInstalled.fr1 != rmGapCfgNew.fr1)
    {
        pDst->measGapConfig.bit_mask |= NRRRC_gapFR1_present;
        VCCB_FillGapConfig(pDst->measGapConfig.gapFR1, rmGapCfgNew.fr1);
    }

    // gapUE
    if (rmGapCfgInstalled.ue != rmGapCfgNew.ue)
    {
        pDst->measGapConfig.bit_mask |= NRRRC_gapUE_present;
        pDst->measGapConfig.gapUE.choice = NRRRC_release_5_chosen;
        VCCB_FillGapConfig(pDst->measGapConfig.gapUE, rmGapCfgNew.ue);
    }

    if (0 != pDst->measGapConfig.bit_mask)
    {
        pDst->bit_mask |= NRRRC_MeasConfig_measGapConfig_present;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills NRRRC_MeasIdToAddModList list, based on
 *                  the supplied arguments.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target list of measurement identities to add or modify.
 *                         The return value is NULL if there are no configurations
 *                         to add or modify. / NRRRC_MeasIdToAddModList*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeMeasIdToAddModListInstalled(callInfo_type *ptCi, NRRRC_MeasIdToAddModList *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    uint8_t itemToAddModIdx = 0;
    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    if (VCCB_NoneElementUsed(rMeasConf.measurementIdentities.installedItems))
    {
        *pDst = NULL;

        return GOOD;
    }

    for (uint8_t i = 0; i < MAX_NR_OF_MEAS_ID; ++i)
    {
        if (CI_use == rMeasConf.measurementIdentities.installedItems[i].usage)
        {
            // need to add 1 to compensate for 1-based indexing
            gMeasConf[ptCi->myThreadId].measIdToAddMod[itemToAddModIdx].value.measId =
                static_cast<NRRRC_MeasId>(rMeasConf.measurementIdentities.installedItems[i].objectId + 1);
            gMeasConf[ptCi->myThreadId].measIdToAddMod[itemToAddModIdx].value.measObjectId =
                static_cast<NRRRC_MeasObjectId>(rMeasConf.measurementIdentities.installedItems[i].measObjectId + 1);
            gMeasConf[ptCi->myThreadId].measIdToAddMod[itemToAddModIdx].value.reportConfigId =
                static_cast<NRRRC_ReportConfigId>(rMeasConf.measurementIdentities.installedItems[i].reportConfigId + 1);
            itemToAddModIdx++;
        }
    }

    if (itemToAddModIdx != 0)
    {
        if (ERROR == VCCB_ConnectLinkedList(gMeasConf[ptCi->myThreadId].measIdToAddMod, itemToAddModIdx))
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "ERROR: VCCB_ConnectLinkedList failed in VCCB_MakeMeasIdToAddModListInstalled!\n");

            return ERROR;
        }
        *pDst = gMeasConf[ptCi->myThreadId].measIdToAddMod;
    }
    else
    {
        *pDst = NULL;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Prepares s-MeasureConfig based on currently installed
 *                  call configuration.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target ASN configuration type. / NRRRC_MeasConfig*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_MakeS_MeasureConfigInstalled(callInfo_type *ptCi, NRRRC_MeasConfig *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);

    if (rMeasConf.sMeasureConfig.installedItem.usage == CI_use)
    {
        if (VCCB_Fill_S_MeasureConfig(&pDst->s_MeasureConfig, &rMeasConf.sMeasureConfig.installedItem) != GOOD)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "ERROR: VCCB_Fill_S_MeasureConfig failed in VCCB_MakeS_MeasureConfigInstalled!\n");

            return ERROR;
        }
        pDst->bit_mask |= NRRRC_MeasConfig_s_MeasureConfig_present;
    }

    return GOOD;
}

/****************************************************************************
 * @brief Fills measuredFrequenciesSN
 * @param  ptCi           : pointer to UE Context
 * @param  pSrcMeasFreq   : pointer to source structure base on which message is filled in
 * @param  pIE            : pointer to NRRRC_MeasConfigSN structure to be filled in
 * @return int16_t        : result of operation
 ****************************************************************************/
int16_t VCCB_FillMeasuredFrequenciesSN(
    callInfo_type *ptCi, const measuredFrequencies_type *pSrcMeasFreq, NRRRC_MeasConfigSN *pIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pSrcMeasFreq);
    VALID_E_POINT_CHECK_ERROR(pIE);

    pIE->bit_mask = 0;

    if (0 == pSrcMeasFreq->numItems)
    {
        return BREAK;
    }

    if (VCCB_ARRAY_COUNT(pSrcMeasFreq->frequencies) < pSrcMeasFreq->numItems)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "pSrcMeasFreq->numItems(%u) is out of range(%zu)!\n", pSrcMeasFreq->numItems,
            VCCB_ARRAY_COUNT(pSrcMeasFreq->frequencies));
        return ERROR;
    }

    if (ERROR == VCCB_GlobalAlloc(pIE->measuredFrequenciesSN, pSrcMeasFreq->numItems))  // Check Init:OK
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_GlobalAlloc ERROR!\n");
        return ERROR;
    }

    for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(pSrcMeasFreq->frequencies, pSrcMeasFreq->numItems); i++)
    {
        pIE->measuredFrequenciesSN[i].value.bit_mask = NRRRC_measuredFrequency_present;
        pIE->measuredFrequenciesSN[i].value.measuredFrequency = pSrcMeasFreq->frequencies[i];
    }

    if (ERROR == VCCB_ConnectLinkedList(pIE->measuredFrequenciesSN, pSrcMeasFreq->numItems))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_ConnectLinkedList ERROR!\n");
        return ERROR;
    }

    pIE->bit_mask = NRRRC_measuredFrequenciesSN_present;

    return GOOD;
}

}  // namespace

/****************************************************************************
 * @brief           Prepares measurement configuration  by comparing
 *                  currently installed configuration with values the
 *                  new one.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target ASN configuration type. / NRRRC_MeasConfig*
 * @param[in]       fullConfig : flag if set TRUE - make IE without delta signaling
 * @return          status : GOOD,
 *                           BREAK (no need to send new measurement
 *                                  configuration),
 *                           ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_FillMeasConf(callInfo_type *ptCi, NRRRC_MeasConfig *pDst, const bool fullConfig)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    pDst->bit_mask = 0;

    if ((MGAPConfigurationPending == ptCi->measurementsConfigShared.mGapConfiguration.mGapMnCtrlState) ||
        (MGAPReleasePending == ptCi->measurementsConfigShared.mGapConfiguration.mGapMnCtrlState))
    {
        return BREAK;
    }

#ifdef NEW_HOST_SIM
    // enables to check if ASN structures related to measurements are filled correctly
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    memset(&gMeasConf[ptCi->myThreadId], 0xff, sizeof(gMeasConf[ptCi->myThreadId]));
#endif

    if (VCCB_MakeMeasObjectConfig(ptCi, pDst) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_MakeMeasObjectConfig failed in VCCB_FillMeasConf!\n");

        return ERROR;
    }

    if (VCCB_MakeReportConfig(ptCi, pDst) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_MakeReportConfig failed in VCCB_FillMeasConf!\n");

        return ERROR;
    }

    if (VCCB_MakeMeasIdConfiguration(ptCi, pDst) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_MakeMeasIdConfiguration failed in VCCB_FillMeasConf!\n");

        return ERROR;
    }

    if (VCCB_MakeS_MeasureConfigNew(ptCi, pDst) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_MakeSMeasureConfig failed in VCCB_FillMeasConf!\n");

        return ERROR;
    }

    if (VCCB_MakeQuantityConfigNew(ptCi, pDst) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_MakeQuantityConfigNew failed in VCCB_FillMeasConf!\n");

        return ERROR;
    }

    if (VCCB_MakeMeasGapConfig(ptCi, pDst, fullConfig) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_MakeMeasGapConfig failed in VCCB_FillMeasConf!\n");

        return ERROR;
    }

    if (pDst->bit_mask == 0)
    {
        return BREAK;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Make measurement configuration for DU
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target ASN configuration type. / NRRRC_MeasConfig*
 * @param[in]       fullConfig : flag if set TRUE - make IE without delta signaling
 * @return          status : GOOD,
 *                           BREAK (no need to send new measurement
 *                                  configuration),
 *                           ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_FillMeasConfDu(callInfo_type *ptCi, NRRRC_MeasConfig *pDst, const bool fullConfig)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    pDst->bit_mask = 0;
    pDst->measObjectToAddModList = NULL;
    pDst->measObjectToRemoveList = NULL;

    mGapDuData_type &rmGapDu = FnVCCB_GetMGapDuData(*ptCi);
    const mGapCallConfiguration_type &rmGapConfig = ptCi->measurementsConfigShared.mGapConfiguration;

    VCCB_PRINT_CALL_COMMENT(ptCi, "[m-gap] FillMeasConfDu FC(%u) Prep(%u) mgrpPreference(%u) mrPurposeInfo(%u)\n",
        fullConfig, rmGapDu.moDuPreparedFlag, rmGapDu.mgrpPreference, rmGapDu.mrPurposeInfo);

    rmGapDu.moDuPreparedFlag = VCCB_FLAG_OFF;
    rmGapDu.moDuSentFlag = VCCB_FLAG_OFF;

    if (fullConfig)
    {
        if (ERROR == VCCB_MakeMeasObjectToAddModListDuCommon(ptCi, &pDst->measObjectToAddModList, &rmGapDu.moDuNew))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "ERROR: VCCB_MakeMeasObjectToAddModListDuCommon failed in VCCB_FillMeasConfDu!\n");
            return ERROR;
        }
    }
    else
    {
        if ((STATE_RRE_RreCmpl == ptCi->state) || (STATE_RRE_SNRel_E1SetupMod == ptCi->state))
        {
            if (ERROR == VCCB_MakeMeasObjectToAddModListDuCommon(ptCi, &pDst->measObjectToAddModList, &rmGapDu.moDuNew))
            {
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "ERROR: VCCB_MakeMeasObjectToAddModListDuCommon failed in VCCB_FillMeasConfDu!\n");
                return ERROR;
            }
        }
        else
        {
            if (ERROR == VCCB_MakeMeasObjectToAddModListDuDiff(ptCi, &pDst->measObjectToAddModList, &rmGapDu.moDuNew))
            {
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "ERROR: VCCB_MakeMeasObjectToAddModListDuDiff failed in VCCB_FillMeasConfDu!\n");
                return ERROR;
            }
        }

        if (ERROR == VCCB_MakeMeasObjectToRemoveListDuDiff(ptCi, &pDst->measObjectToRemoveList, &rmGapDu.moDuNew))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "ERROR: VCCB_MakeMeasObjectToRemoveListDuDiff failed in VCCB_FillMeasConfDu!\n");
            return ERROR;
        }

        // mgrpPreference/mrPurposeInfo IE is significant only if MeasConfig IE is included.
        // If there is no difference in MO list (measObjectToAddModList and measObjectToRemoveList are empty)
        // and only mgrpPreference/mrPurposeInfo needs to be updated then send full MO list.
        if ((NULL == pDst->measObjectToAddModList) && (NULL == pDst->measObjectToRemoveList) &&
            ((rmGapDu.mgrpPreference != rmGapConfig.mgrpPreference) ||
             (rmGapDu.mrPurposeInfo != rmGapConfig.mrPurposeInfo)))
        {
            if (0 == rmGapDu.moDuNew.numItems)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "[m-gap] FillMeasConfDu: MO list empty while mgrpPreference/mrPurposeInfo is changed!\n");
            }
            else if (ERROR == VCCB_MakeMeasObjectToAddModListDuCommon(ptCi, &pDst->measObjectToAddModList, &rmGapDu.moDuNew))
            {
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "ERROR: VCCB_MakeMeasObjectToAddModListDuCommon failed in VCCB_FillMeasConfDu!\n");
                return ERROR;
            }
        }
    }

    if (NULL != pDst->measObjectToRemoveList)
    {
        pDst->bit_mask |= NRRRC_measObjectToRemoveList_present;
    }

    if (NULL != pDst->measObjectToAddModList)
    {
        pDst->bit_mask |= NRRRC_measObjectToAddModList_present;
    }

    if (0 == pDst->bit_mask)
    {
        return BREAK;
    }
    rmGapDu.moDuSentFlag = VCCB_FLAG_ON;

    return GOOD;
}

/****************************************************************************
 * @brief           Fill MeasConfigMN sent from MN to SN
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target ASN configuration type. / NRRRC_MeasConfig*
 * @return          status : GOOD, ERROR, BREAK / int16_t
 ****************************************************************************/
int16_t VCCB_FillMeasConfigMN(callInfo_type *ptCi, NRRRC_MeasConfigMN *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    pDst->bit_mask = 0;

    if (ERROR == VCCB_FillMeasuredFrequenciesMN(ptCi, pDst))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_FillMeasuredFrequenciesMN ERROR!\n");
        return ERROR;
    }

    // measGapConfig + measGapConfigFR2
    if ((IS_SN_ADDITION_ONGOING(ptCi)) || FnVCCB_IsInterSnMobilityInMn(ptCi))
    {
        VCCB_MakeMeasGapConfigSnNew(ptCi, pDst);
    }
    else if (IS_MRDC_MN(ptCi) && FnVCCB_IsMrdcInterMnHOWithoutSnAddition(ptCi))
    {
        // Force explicit release
        VCCB_MakeMeasGapConfigSnForceRelease(ptCi, pDst);
    }
    else
    {
        VCCB_MakeMeasGapConfigSnDiff(ptCi, pDst);
    }

    if (0 == pDst->bit_mask)
    {
        return BREAK;
    }

    ptCi->measurementsConfigShared.mGapConfiguration.mGapCfgSnSentFlag = VCCB_FLAG_ON;
    return GOOD;
}

/****************************************************************************
 * @brief Filling in RRC Message IEs for MeasConfigMN
 * @param  pTgt           : pointer to structure to be filled in
 * @param  pSrc           : pointer to source data structure
 * @param  setupFlag      : true if IE will be included in F1_UEContextSetupRequest, false otherwise
 * @return int16_t        : result of operation
 ****************************************************************************/
int16_t VCCB_FillNRRRC_MeasConfigMN(
    callInfo_type *ptCi, NRRRC_MeasConfigMN *pTgt, measConfigMN_type *pSrc, bool setupFlag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pTgt);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    pTgt->bit_mask = 0;

    if (VCCB_FLAG_ON == pSrc->measuredFrequenciesMN_Flag)
    {
        if (MAX_NUM_MEAS_FREQS_MN < pSrc->measuredFrequenciesMN.nrofMeasFreqsMN)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "nrofMeasFreqsMN is out of range (%d:%d)\n",
                pSrc->measuredFrequenciesMN.nrofMeasFreqsMN, MAX_NUM_MEAS_FREQS_MN);
            return ERROR;
        }

        if (ERROR == VCCB_GlobalAlloc(pTgt->measuredFrequenciesMN, pSrc->measuredFrequenciesMN.nrofMeasFreqsMN))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_GlobalAlloc ERROR!\n");
            return ERROR;
        }

        for (uint32_t i = 0; i < util::minOfArraySizeAndNumOfElems(pSrc->measuredFrequenciesMN.nrFreqInfo,
                                     pSrc->measuredFrequenciesMN.nrofMeasFreqsMN);
             ++i)
        {
            pTgt->measuredFrequenciesMN[i].value.bit_mask = 0;

            if (VCCB_FLAG_ON == pSrc->measuredFrequenciesMN.nrFreqInfo[i].measuredFrequencyFlag)
            {
                pTgt->measuredFrequenciesMN[i].value.bit_mask |= NRRRC_measuredFrequency_present;
                pTgt->measuredFrequenciesMN[i].value.measuredFrequency =
                    pSrc->measuredFrequenciesMN.nrFreqInfo[i].measuredFrequency;
            }
        }

        if (ERROR == VCCB_ConnectLinkedList(pTgt->measuredFrequenciesMN, pSrc->measuredFrequenciesMN.nrofMeasFreqsMN))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_ConnectLinkedList ERROR!\n");
            return ERROR;
        }

        pTgt->bit_mask |= NRRRC_measuredFrequenciesMN_present;
    }

    const bool gapPurposePerUeFlag = ((VCCB_FLAG_ON == pSrc->gapPurposeFlag) && (NRRRC_perUE == pSrc->gapPurpose));
    enumServFreqRange_type duFrType = ServFreqRange_Unknown;
    if (IS_NRDC_SN(ptCi))
    {
        duFrType = VLIB_GetDuCellsFreqRange(ptCi);
    }

    // ENDC-SN
    // NRDC-SN - perUE gap or DU FR1&2 type
    if (((false == IS_NRDC_SN(ptCi)) || gapPurposePerUeFlag || (ServFreqRange_FR2only != duFrType)) &&
        ((false == setupFlag) || (VCCB_FLAG_ON == pSrc->measGapConfigFR1.flag)))
    {
        VCCB_FillGapConfig(pTgt->measGapConfig, pSrc->measGapConfigFR1);
        pTgt->bit_mask |= NRRRC_MeasConfigMN_measGapConfig_present;

        if (VCCB_FLAG_ON == pSrc->gapPurposeFlag)
        {
            pTgt->gapPurpose = static_cast<NRRRC__enum408>(pSrc->gapPurpose);
            pTgt->bit_mask |= NRRRC_gapPurpose_present;
        }
    }

    // NRDC-SN only - perUE gap or DU FR1&2 type
    if (IS_NRDC_SN(ptCi) && (ServFreqRange_FR1only != duFrType) &&
        ((false == setupFlag) || (VCCB_FLAG_ON == pSrc->measGapConfigFR2.flag)))
    {
        VCCB_FillGapConfig(pTgt->measGapConfigFR2, pSrc->measGapConfigFR2);
        pTgt->bit_mask |= NRRRC_measGapConfigFR2_present;
    }

    if (0 == pTgt->bit_mask)
    {
        return BREAK;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Fills ASN defined NRRRC_SSB_MTC object using
 *                  VCCB specific smtc1_type object.
 *
 * @param[out]      pDst : Pointer to a destination object. / NRRRC_SSB_MTC*
 * @param[in]       pSrc : Pointer to a source object. / smtc1_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_Fill_SSB_MTC1(NRRRC_SSB_MTC *pDst, const smtc1_type *pSrc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pDst);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    switch (pSrc->periodicityAndOffset.periodicity)
    {
        case smtc_periodicity_sf5:
            pDst->periodicityAndOffset.choice = NRRRC_sf5_chosen;
            pDst->periodicityAndOffset.u.sf5 = pSrc->periodicityAndOffset.offset;
            break;

        case smtc_periodicity_sf10:
            pDst->periodicityAndOffset.choice = NRRRC_sf10_chosen;
            pDst->periodicityAndOffset.u.sf10 = pSrc->periodicityAndOffset.offset;
            break;

        case smtc_periodicity_sf20:
            pDst->periodicityAndOffset.choice = NRRRC_sf20_chosen;
            pDst->periodicityAndOffset.u.sf20 = pSrc->periodicityAndOffset.offset;
            break;

        case smtc_periodicity_sf40:
            pDst->periodicityAndOffset.choice = NRRRC_sf40_chosen;
            pDst->periodicityAndOffset.u.sf40 = pSrc->periodicityAndOffset.offset;
            break;

        case smtc_periodicity_sf80:
            pDst->periodicityAndOffset.choice = NRRRC_sf80_chosen;
            pDst->periodicityAndOffset.u.sf80 = pSrc->periodicityAndOffset.offset;
            break;

        case smtc_periodicity_sf160:
            pDst->periodicityAndOffset.choice = NRRRC_sf160_chosen;
            pDst->periodicityAndOffset.u.sf160 = pSrc->periodicityAndOffset.offset;
            break;

        default:
            VCCB_PRINT_ERROR("ERROR: Invalid periodicity chosen (%hu) in VCCB_Fill_SSB_MTC1!\n",
                pSrc->periodicityAndOffset.periodicity);

            return ERROR;
    }

    pDst->duration = (NRRRC__enum6)pSrc->duration;

    return GOOD;
}

/****************************************************************************
 * @brief Fills MeasConfigSN IE for CG-Config sent to MN form SN EN-DC/NR-DC
 * @param  ptCi           : pointer to UE Context base on which message is filled in
 * @param  pIE            : pointer to NRRRC_MeasConfigSN structure to be filled in
 * @param  srcConfigFlag  : flag if set TRUE - make IE without delta signaling including existing config
 * @return int16_t        : result of operation
 ****************************************************************************/
int16_t VCCB_FillMeasConfigSN_toMN(callInfo_type *ptCi, NRRRC_MeasConfigSN *pIE, uint16_t srcConfigFlag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pIE);

    const mGapCallConfiguration_type &rmGapConfig = ptCi->measurementsConfigShared.mGapConfiguration;
    const measuredFrequencies_type *pSrcMeasFreq = NULL;
    pIE->bit_mask = 0;

    if ((TRUE == srcConfigFlag) || (MGAPIdle == rmGapConfig.mGapMnCtrlState))
    {
        pSrcMeasFreq = &(rmGapConfig.freqSnInstalled);
    }
    else
    {
        pSrcMeasFreq = &(rmGapConfig.freqSnNew);
    }

    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, VCCB_FillMeasuredFrequenciesSN(ptCi, pSrcMeasFreq, pIE), "VCCB_FillMeasuredFrequenciesSN ERROR!\n");

    if ((0 != pIE->bit_mask) || (MGAPReleasePending == rmGapConfig.mGapMnCtrlState))
    {
        return GOOD;
    }

    return BREAK;
}

/****************************************************************************
 * @brief           Fills pDst with measurement configuration currently
 *                  installed on UE.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[out]      pDst : Target ASN configuration type. / NRRRC_MeasConfig*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_GetCurrentMeasConfig(callInfo_type *ptCi, NRRRC_MeasConfig *pDst)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);

    pDst->bit_mask = 0;

    if (VCCB_MakeMeasObjectToAddModListInstalled(ptCi, &pDst->measObjectToAddModList) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: VCCB_MakeMeasObjectToAddModListInstalled failed in VCCB_GetCurrentMeasConfig!\n");

        return ERROR;
    }
    if (pDst->measObjectToAddModList != NULL)
    {
        pDst->bit_mask |= NRRRC_measObjectToAddModList_present;
    }

    if (VCCB_MakeReportConfigToAddModListInstalled(ptCi, &pDst->reportConfigToAddModList) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: VCCB_MakeReportConfigToAddModListInstalled failed in VCCB_GetCurrentMeasConfig!\n");

        return ERROR;
    }
    if (pDst->reportConfigToAddModList != NULL)
    {
        pDst->bit_mask |= NRRRC_reportConfigToAddModList_present;
    }

    if (VCCB_MakeMeasIdToAddModListInstalled(ptCi, &pDst->measIdToAddModList) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: VCCB_MakeMeasIdToAddModListInstalled failed in VCCB_GetCurrentMeasConfig!\n");

        return ERROR;
    }
    if (pDst->measIdToAddModList != NULL)
    {
        pDst->bit_mask |= NRRRC_measIdToAddModList_present;
    }

    if (VCCB_MakeS_MeasureConfigInstalled(ptCi, pDst) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_MakeSMeasureConfigInstalled failed in VCCB_GetCurrentMeasConfig!\n");

        return ERROR;
    }

    if (VCCB_MakeQuantityConfigInstalled(ptCi, pDst) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_MakeQuantityConfigInstalled failed in VCCB_GetCurrentMeasConfig!\n");

        return ERROR;
    }

    if (VCCB_MakeMeasGapConfigInstalled(ptCi, pDst) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_MakeMeasGapConfigInstalled failed in VCCB_GetCurrentMeasConfig!\n");

        return ERROR;
    }

    if (pDst->bit_mask == 0)
    {
        return BREAK;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Implements custom logic for comparing two
 *                  reportConfigurationInstalledUe_type items.
 *
 * @param[in]       rInstalledConf : Reference to periodic report  configuration
 *                               installed on UE. / reportConfigurationInstalledUe_type&
 * @param[in]       rNewConf : Reference to new periodic report
 *                         configuration. / reportConfigurationInstalledUe_type&
 * @return          status : GOOD (change), ERROR (error), BREAK (no change) / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfReportConfigChanged_ReportCgi(
    const reportConfigurationConfUe_type &rInstalledConf, const reportConfigurationConfUe_type &rNewConf)
{
    AUTO_TRACE_FUNC;

    if (rInstalledConf.reportConfiguration.reportCgi.cellForWhichToReportCGI !=
        rNewConf.reportConfiguration.reportCgi.cellForWhichToReportCGI)
    {
        return GOOD;
    }

    return BREAK;
}

/****************************************************************************
 * @brief           Implements custom logic for comparing two
 *                  reportConfigurationInstalledUe_type items.
 *
 * @param[in]       rInstalledConf : Reference to periodic report  configuration
 *                               installed on UE. / reportConfigurationInstalledUe_type&
 * @param[in]       rNewConf : Reference to new periodic report
 *                         configuration. / reportConfigurationInstalledUe_type&
 * @return          status : GOOD (change), ERROR (error), BREAK (no change) / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfReportConfigChanged_ReportCgiEutra(
    const reportConfigurationConfUe_type &rInstalledConf, const reportConfigurationConfUe_type &rNewConf)
{
    AUTO_TRACE_FUNC;

    if (rInstalledConf.reportConfiguration.reportCgiEutra.cellForWhichToReportCGI !=
        rNewConf.reportConfiguration.reportCgiEutra.cellForWhichToReportCGI)
    {
        return GOOD;
    }

    return BREAK;
}

/****************************************************************************
 * @brief           Implements custom logic for comparing two
 *                  reportConfigurationInstalledUe_type items.
 *
 * @param[in]       rInstalledConf : Reference to periodic report  configuration
 *                               installed on UE. / reportConfigurationInstalledUe_type&
 * @param[in]       rNewConf : Reference to new periodic report
 *                         configuration. / reportConfigurationInstalledUe_type&
 * @return          status : GOOD (change), ERROR (error), BREAK (no change) / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfReportConfigChanged_Periodical(
    const reportConfigurationConfUe_type &rInstalledConf, const reportConfigurationConfUe_type &rNewConf)
{
    AUTO_TRACE_FUNC;

    if (rInstalledConf.rsType != rNewConf.rsType)
    {
        return GOOD;
    }
    if (rInstalledConf.reportInterval != rNewConf.reportInterval)
    {
        return GOOD;
    }
    if (rInstalledConf.reportAmount != rNewConf.reportAmount)
    {
        return GOOD;
    }
    if (rInstalledConf.reportQuantityCell != rNewConf.reportQuantityCell)
    {
        return GOOD;
    }
    if (rInstalledConf.maxReportCells != rNewConf.maxReportCells)
    {
        return GOOD;
    }
    if (rInstalledConf.rat.nr.reportQuantityRsIndexes.usage != rNewConf.rat.nr.reportQuantityRsIndexes.usage)
    {
        return GOOD;
    }
    if ((rNewConf.rat.nr.reportQuantityRsIndexes.usage == CI_use) &&
        (rInstalledConf.rat.nr.reportQuantityRsIndexes.reportQuantity !=
            rNewConf.rat.nr.reportQuantityRsIndexes.reportQuantity))
    {
        return GOOD;
    }
    if (rInstalledConf.rat.nr.maxNrOfRsIndexesToReport.usage != rNewConf.rat.nr.maxNrOfRsIndexesToReport.usage)
    {
        return GOOD;
    }
    if ((rNewConf.rat.nr.maxNrOfRsIndexesToReport.usage == CI_use) &&
        (rInstalledConf.rat.nr.maxNrOfRsIndexesToReport.value != rNewConf.rat.nr.maxNrOfRsIndexesToReport.value))
    {
        return GOOD;
    }
    if (rInstalledConf.rat.nr.includeBeamMeasurements != rNewConf.rat.nr.includeBeamMeasurements)
    {
        return GOOD;
    }
    if (rInstalledConf.reportConfiguration.periodical.useWhiteCellList !=
        rNewConf.reportConfiguration.periodical.useWhiteCellList)
    {
        return GOOD;
    }
    if (rInstalledConf.reportConfiguration.periodical.reportAddNeighMeas !=
        rNewConf.reportConfiguration.periodical.reportAddNeighMeas)
    {
        return GOOD;
    }

    return BREAK;
}

/****************************************************************************
 * @brief           Implements custom logic for comparing common part of:
 *                  A1,A2,A3,A4,A5,A6 an event based report configurations in two
 *                  eventBasedReportConfigurationNR_type items.
 *
 * @param[in]       pInstalled : Pointer to event based report configuration
 *                               installed on UE. / eventBasedReportConfigurationNRUe_type*
 * @param[in]       pNew : Pointer to new event based report
 *                         configuration. / eventBasedReportConfigurationNRUe_type*
 * @return          status : GOOD (change), ERROR (error), BREAK (no change) / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfReportConfigChanged_EventBasedAxCommon(
    const eventBasedReportConfigurationNRUe_type *pInstalled, const eventBasedReportConfigurationNRUe_type *pNew)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    if (pInstalled->useT312 != pNew->useT312)
    {
        return GOOD;
    }

    return BREAK;
}

/****************************************************************************
 * @brief           Implements custom logic for comparing common part of event
 *                  based report configurations in two
 *                  reportConfigurationInstalledUe_type items.
 *
 * @param[in]       pInstalled : Pointer to event based report configuration
 *                               installed on UE. / reportConfigurationInstalledUe_type*
 * @param[in]       pNew : Pointer to new event based report
 *                         configuration. / reportConfigurationInstalledUe_type*
 * @return          status : GOOD (change), ERROR (error), BREAK (no change) / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfReportConfigChanged_EventBasedCommon(
    const reportConfigurationConfUe_type &rInstalledConf, const reportConfigurationConfUe_type &rNewConf)
{
    AUTO_TRACE_FUNC;

    if (rInstalledConf.rsType != rNewConf.rsType)
    {
        return GOOD;
    }
    if (rInstalledConf.reportInterval != rNewConf.reportInterval)
    {
        return GOOD;
    }
    if (rInstalledConf.reportAmount != rNewConf.reportAmount)
    {
        return GOOD;
    }
    if (rInstalledConf.reportQuantityCell != rNewConf.reportQuantityCell)
    {
        return GOOD;
    }
    if (rInstalledConf.maxReportCells != rNewConf.maxReportCells)
    {
        return GOOD;
    }

    if (measRatNr == VCCB_GetRatType((enumMeasurementReportType)rInstalledConf.reportType))
    {
        if (rInstalledConf.rat.nr.reportQuantityRsIndexes.usage != rNewConf.rat.nr.reportQuantityRsIndexes.usage)
        {
            return GOOD;
        }
        if ((rNewConf.rat.nr.reportQuantityRsIndexes.usage == CI_use) &&
            (rInstalledConf.rat.nr.reportQuantityRsIndexes.reportQuantity !=
                rNewConf.rat.nr.reportQuantityRsIndexes.reportQuantity))
        {
            return GOOD;
        }
        if (rInstalledConf.rat.nr.maxNrOfRsIndexesToReport.usage != rNewConf.rat.nr.maxNrOfRsIndexesToReport.usage)
        {
            return GOOD;
        }
        if ((rNewConf.rat.nr.maxNrOfRsIndexesToReport.usage == CI_use) &&
            (rInstalledConf.rat.nr.maxNrOfRsIndexesToReport.value !=
                rNewConf.rat.nr.maxNrOfRsIndexesToReport.value))
        {
            return GOOD;
        }
        if (rInstalledConf.rat.nr.includeBeamMeasurements != rNewConf.rat.nr.includeBeamMeasurements)
        {
            return GOOD;
        }
    }
    if (rInstalledConf.rat.nr.includeCommonLocationInfo_r16 != rNewConf.rat.nr.includeCommonLocationInfo_r16)
    {
        return GOOD;
    }

    return BREAK;
}

/****************************************************************************
 * @brief           Implements custom logic for comparing A1 part of event
 *                  based report configurations in two
 *                  eventBasedReportConfigurationNRUe_type items.
 *
 * @param[in]       pInstalled : Pointer to A1 event based report configuration
 *                               installed on UE. / eventBasedReportConfigurationNRUe_type*
 * @param[in]       pNew : Pointer to new A1 event based report
 *                         configuration. / eventBasedReportConfigurationNRUe_type*
 * @return          status : GOOD (change), ERROR (error), BREAK (no change) / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfReportConfigChanged_EventBasedA1(
    const eventBasedReportConfigurationNRUe_type *pInstalled, const eventBasedReportConfigurationNRUe_type *pNew)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    if (pInstalled->event.A1.a1_Threshold != pNew->event.A1.a1_Threshold)
    {
        return GOOD;
    }
    if (pInstalled->reportOnLeave != pNew->reportOnLeave)
    {
        return GOOD;
    }
    if (pInstalled->hysteresis != pNew->hysteresis)
    {
        return GOOD;
    }
    if (pInstalled->timeToTrigger != pNew->timeToTrigger)
    {
        return GOOD;
    }

    return BREAK;
}

/****************************************************************************
 * @brief           Implements custom logic for comparing A2 part of event
 *                  based report configurations in two
 *                  eventBasedReportConfigurationNRUe_type items.
 *
 * @param[in]       pInstalled : Pointer to A2 event based report configuration
 *                               installed on UE. / eventBasedReportConfigurationNRUe_type*
 * @param[in]       pNew : Pointer to new A2 event based report
 *                         configuration. / eventBasedReportConfigurationNRUe_type*
 * @return          status : GOOD (change), ERROR (error), BREAK (no change) / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfReportConfigChanged_EventBasedA2(
    const eventBasedReportConfigurationNRUe_type *pInstalled, const eventBasedReportConfigurationNRUe_type *pNew)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    if (pInstalled->event.A2.a2_Threshold != pNew->event.A2.a2_Threshold)
    {
        return GOOD;
    }
    if (pInstalled->reportOnLeave != pNew->reportOnLeave)
    {
        return GOOD;
    }
    if (pInstalled->hysteresis != pNew->hysteresis)
    {
        return GOOD;
    }
    if (pInstalled->timeToTrigger != pNew->timeToTrigger)
    {
        return GOOD;
    }

    return BREAK;
}

/****************************************************************************
 * @brief           Implements custom logic for comparing A3 part of event
 *                  based report configurations in two
 *                  eventBasedReportConfigurationNRUe_type items.
 *
 * @param[in]       pInstalled : Pointer to A3 event based report configuration
 *                               installed on UE. / eventBasedReportConfigurationNRUe_type*
 * @param[in]       pNew : Pointer to new A3 event based report
 *                         configuration. / eventBasedReportConfigurationNRUe_type*
 * @return          status : GOOD (change), ERROR (error), BREAK (no change) / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfReportConfigChanged_EventBasedA3(
    const eventBasedReportConfigurationNRUe_type *pInstalled, const eventBasedReportConfigurationNRUe_type *pNew)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    if (pInstalled->event.A3.a3_Offset != pNew->event.A3.a3_Offset)
    {
        return GOOD;
    }
    if (pInstalled->reportOnLeave != pNew->reportOnLeave)
    {
        return GOOD;
    }
    if (pInstalled->hysteresis != pNew->hysteresis)
    {
        return GOOD;
    }
    if (pInstalled->timeToTrigger != pNew->timeToTrigger)
    {
        return GOOD;
    }

    return BREAK;
}

/****************************************************************************
 * @brief           Implements custom logic for comparing A4 part of event
 *                  based report configurations in two
 *                  eventBasedReportConfigurationNRUe_type items.
 *
 * @param[in]       pInstalled : Pointer to A4 event based report configuration
 *                               installed on UE. / eventBasedReportConfigurationNRUe_type*
 * @param[in]       pNew : Pointer to new A4 event based report
 *                         configuration. / eventBasedReportConfigurationNRUe_type*
 * @return          status : GOOD (change), ERROR (error), BREAK (no change) / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfReportConfigChanged_EventBasedA4(
    const eventBasedReportConfigurationNRUe_type *pInstalled, const eventBasedReportConfigurationNRUe_type *pNew)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    if (pInstalled->event.A4.a4_Threshold != pNew->event.A4.a4_Threshold)
    {
        return GOOD;
    }
    if (pInstalled->reportOnLeave != pNew->reportOnLeave)
    {
        return GOOD;
    }
    if (pInstalled->hysteresis != pNew->hysteresis)
    {
        return GOOD;
    }
    if (pInstalled->timeToTrigger != pNew->timeToTrigger)
    {
        return GOOD;
    }
    if (pInstalled->event.A4.useAllowedCellList != pNew->event.A4.useAllowedCellList)
    {
        return GOOD;
    }

    return BREAK;
}

/****************************************************************************
 * @brief           Implements custom logic for comparing A5 part of event
 *                  based report configurations in eventBasedReportConfigurationNRUe_type
 *                  and eventBasedReportConfigurationNRUe_type items.
 *
 * @param[in]       pInstalled : Pointer to A5 event based report configuration
 *                               installed on UE. / eventBasedReportConfigurationNRUe_type*
 * @param[in]       pNew : Pointer to new A5 event based report
 *                         configuration. / eventBasedReportConfigurationNRUe_type*
 * @return          status : GOOD (change), ERROR (error), BREAK (no change) / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfReportConfigChanged_EventBasedA5(
    const eventBasedReportConfigurationNRUe_type *pInstalled, const eventBasedReportConfigurationNRUe_type *pNew)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    if (pInstalled->event.A5.a5_Thresholds != pNew->event.A5.a5_Thresholds)
    {
        return GOOD;
    }
    if (pInstalled->reportOnLeave != pNew->reportOnLeave)
    {
        return GOOD;
    }
    if (pInstalled->hysteresis != pNew->hysteresis)
    {
        return GOOD;
    }
    if (pInstalled->timeToTrigger != pNew->timeToTrigger)
    {
        return GOOD;
    }

    return BREAK;
}

/****************************************************************************
 * @brief           Implements custom logic for comparing A6 part of event
 *                  based report configurations in two
 *                  eventBasedReportConfigurationNRUe_type items.
 *
 * @param[in]       pInstalled : Pointer to A6 event based report configuration
 *                               installed on UE. / eventBasedReportConfigurationNRUe_type*
 * @param[in]       pNew : Pointer to new A6 event based report
 *                         configuration. / eventBasedReportConfigurationNRUe_type*
 * @return          status : GOOD (change), ERROR (error), BREAK (no change) / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfReportConfigChanged_EventBasedA6(
    const eventBasedReportConfigurationNRUe_type *pInstalled, const eventBasedReportConfigurationNRUe_type *pNew)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    if (pInstalled->event.A6.a6_Offset != pNew->event.A6.a6_Offset)
    {
        return GOOD;
    }
    if (pInstalled->reportOnLeave != pNew->reportOnLeave)
    {
        return GOOD;
    }
    if (pInstalled->hysteresis != pNew->hysteresis)
    {
        return GOOD;
    }
    if (pInstalled->timeToTrigger != pNew->timeToTrigger)
    {
        return GOOD;
    }

    return BREAK;
}

/****************************************************************************
 * @brief           Implements custom logic for comparing B1 part of event
 *                  based report configurations in two
 *                  eventBasedReportConfigurationInterRatUe_type items.
 *
 * @param[in]       pInstalled : Pointer to B1 event based report configuration
 *                               installed on UE. / eventBasedReportConfigurationInterRatUe_type*
 * @param[in]       pNew : Pointer to new B1 event based report
 *                         configuration. / eventBasedReportConfigurationInterRatUe_type*
 * @return          status : GOOD (change), ERROR (error), BREAK (no change) / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfReportConfigChanged_EventBased_B1(const eventBasedReportConfigurationInterRatUe_type *pInstalled,
    const eventBasedReportConfigurationInterRatUe_type *pNew)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    if (pInstalled->event.B1Eutra.b1_thresholdEUTRA != pNew->event.B1Eutra.b1_thresholdEUTRA)
    {
        return GOOD;
    }
    if (pInstalled->reportOnLeave != pNew->reportOnLeave)
    {
        return GOOD;
    }
    if (pInstalled->hysteresis != pNew->hysteresis)
    {
        return GOOD;
    }
    if (pInstalled->timeToTrigger != pNew->timeToTrigger)
    {
        return GOOD;
    }

    return BREAK;
}

/****************************************************************************
 * @brief           Implements custom logic for comparing B2 part of event
 *                  based report configurations in two
 *                  eventBasedReportConfigurationInterRatUe_type items.
 *
 * @param[in]       pInstalled : Pointer to B2 event based report configuration
 *                               installed on UE. / eventBasedReportConfigurationInterRatUe_type*
 * @param[in]       pNew : Pointer to new B2 event based report
 *                         configuration. / eventBasedReportConfigurationInterRatUe_type*
 * @return          status : GOOD (change), ERROR (error), BREAK (no change) / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfReportConfigChanged_EventBased_B2(const eventBasedReportConfigurationInterRatUe_type *pInstalled,
    const eventBasedReportConfigurationInterRatUe_type *pNew)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    if (pInstalled->event.B2Eutra.b2_thresholds != pNew->event.B2Eutra.b2_thresholds)
    {
        return GOOD;
    }
    if (pInstalled->reportOnLeave != pNew->reportOnLeave)
    {
        return GOOD;
    }
    if (pInstalled->hysteresis != pNew->hysteresis)
    {
        return GOOD;
    }
    if (pInstalled->timeToTrigger != pNew->timeToTrigger)
    {
        return GOOD;
    }

    return BREAK;
}

/****************************************************************************
 * @brief           Implements a template for further fill.
 *
 * @param[in]       pInstalled : Pointer to periodical InterRat report configuration
 *                               installed on UE. / periodicalReportConfigurationInterRat_type*
 * @param[in]       pNew : Pointer to new periodical InterRat based report
 *                         configuration. / periodicalReportConfigurationInterRat_type*
 * @return          status : GOOD (change), ERROR (error), BREAK (no change) / int16_t
 ****************************************************************************/

int16_t VCCB_CheckIfReportConfigChanged_periodicalInterRat(const periodicalReportConfigurationInterRat_type *pInstalled,
    const periodicalReportConfigurationInterRat_type *pNew)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    return BREAK;
}

/****************************************************************************
 * @brief           Implements custom logic for comparing two
 *                  reportConfigurationInstalledUe_type items.
 *
 * @param[in]       pInstalled : Pointer to report configuration
 *                               installed on UE. / reportConfigurationInstalledUe_type*
 * @param[in]       pNew : Pointer to new report
 *                         configuration. / reportConfigurationNewUe_type*
 * @return          status : GOOD (change), ERROR (error), BREAK (no change) / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfReportConfigChanged(
    const reportConfigurationInstalledUe_type *pInstalled, const reportConfigurationNewUe_type *pNew)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pInstalled);
    VALID_E_POINT_CHECK_ERROR(pNew);

    int16_t status;

    if (pInstalled->usage != pNew->usage)
    {
        VCCB_PRINT_ERROR(
            "ERROR: Inconsistent value of usage flag in VCCB_CheckIfReportConfigChanged: installed %u, new %u\n",
            pInstalled->usage, pNew->usage);

        return ERROR;
    }

    if (pInstalled->conf.reportType != pNew->conf.reportType)
    {
        return GOOD;
    }
    if (pInstalled->conf.reportPurpose != pNew->conf.reportPurpose)
    {
        return GOOD;
    }

    if (pNew->conf.reportType == measReport_periodical)
    {
        status = VCCB_CheckIfReportConfigChanged_Periodical(pInstalled->conf, pNew->conf);

        return status;
    }

    if (pNew->conf.reportType == measReport_reportCGI)
    {
        status = VCCB_CheckIfReportConfigChanged_ReportCgi(pInstalled->conf, pNew->conf);

        return status;
    }

    if (pNew->conf.reportType == measReport_reportCGIEutra)
    {
        status = VCCB_CheckIfReportConfigChanged_ReportCgiEutra(pInstalled->conf, pNew->conf);
        return status;
    }

    status = VCCB_CheckIfReportConfigChanged_EventBasedCommon(pInstalled->conf, pNew->conf);
    if (status == ERROR)
    {
        VCCB_PRINT_ERROR(
            "ERROR: VCCB_CheckIfReportConfigChanged_EventBasedCommon failed in "
            "VCCB_CheckIfReportConfigChanged_EventBasedA6\n");

        return ERROR;
    }

    if (status == GOOD)
    {
        return GOOD;
    }

    switch (pNew->conf.reportType)
    {
        case measReport_A1:
        case measReport_A2:
        case measReport_A3:
        case measReport_A4:
        case measReport_A5:
        case measReport_A6:
            status = VCCB_CheckIfReportConfigChanged_EventBasedAxCommon(
                &pInstalled->conf.reportConfiguration.eventBased, &pNew->conf.reportConfiguration.eventBased);
            if (status == ERROR)
            {
                VCCB_PRINT_ERROR("ERROR: VCCB_CheckIfReportConfigChanged_EventBasedAxCommon failed\n");
                return ERROR;
            }
            if (status == GOOD)
            {
                return GOOD;
            }
            break;
        default:
            break;
    }

    switch (pNew->conf.reportType)
    {
        case measReport_A1:
            status = VCCB_CheckIfReportConfigChanged_EventBasedA1(
                &pInstalled->conf.reportConfiguration.eventBased, &pNew->conf.reportConfiguration.eventBased);

            return status;

        case measReport_A2:
            status = VCCB_CheckIfReportConfigChanged_EventBasedA2(
                &pInstalled->conf.reportConfiguration.eventBased, &pNew->conf.reportConfiguration.eventBased);

            return status;

        case measReport_A3:
            status = VCCB_CheckIfReportConfigChanged_EventBasedA3(
                &pInstalled->conf.reportConfiguration.eventBased, &pNew->conf.reportConfiguration.eventBased);

            return status;

        case measReport_A4:
            status = VCCB_CheckIfReportConfigChanged_EventBasedA4(
                &pInstalled->conf.reportConfiguration.eventBased, &pNew->conf.reportConfiguration.eventBased);

            return status;

        case measReport_A5:
            status = VCCB_CheckIfReportConfigChanged_EventBasedA5(
                &pInstalled->conf.reportConfiguration.eventBased, &pNew->conf.reportConfiguration.eventBased);

            return status;

        case measReport_A6:
            status = VCCB_CheckIfReportConfigChanged_EventBasedA6(
                &pInstalled->conf.reportConfiguration.eventBased, &pNew->conf.reportConfiguration.eventBased);

            return status;

        case measReport_B1Eutra:
            status = VCCB_CheckIfReportConfigChanged_EventBased_B1(
                &pInstalled->conf.reportConfiguration.eventInterRat, &pNew->conf.reportConfiguration.eventInterRat);

            return status;

        case measReport_B2Eutra:
            status = VCCB_CheckIfReportConfigChanged_EventBased_B2(
                &pInstalled->conf.reportConfiguration.eventInterRat, &pNew->conf.reportConfiguration.eventInterRat);

            return status;
        case measReport_periodicalInterRat:
            return VCCB_CheckIfReportConfigChanged_periodicalInterRat(
                &pInstalled->conf.reportConfiguration.periodicalInterRat,
                &pNew->conf.reportConfiguration.periodicalInterRat);
        default:
            VCCB_PRINT_ERROR(
                "ERROR: Incorrect new report configuration type (%hu) in VCCB_CheckIfReportConfigChanged\n",
                pNew->conf.reportType);

            return ERROR;
    }

    return ERROR;
}

/****************************************************************************
 * @brief           Function get NR RRC SSB SMTC1
 *
 * @param[in/out]   rMoCandidate : Reference to minimalMeasObjectConfUe_type
 * @return          mtc1 : smtc1_type
 ******************************************************************************/
smtc1_type FnVCCB_GetRrcMeasObjectNrSsbSmtc1(const minimalMeasObjectNRUe_type &rMeasObjectNrUe)
{
    return rMeasObjectNrUe.ncdSsbInfo.usage == CI_use ?
        rMeasObjectNrUe.ncdSsbInfo.ncdSmtc1 :
        rMeasObjectNrUe.smtc1 ;
}

/****************************************************************************
 * @brief           Function get NR RRC SSB Frequency
 *
 * @param[in/out]   rMoCandidate : Reference to minimalMeasObjectConfUe_type
 * @return          SsbFrequency : uint32_t
 ******************************************************************************/
uint32_t FnVCCB_GetRrcMeasObjectNrSsbFrequency(const minimalMeasObjectNRUe_type &rMeasObjectNrUe)
{
    return rMeasObjectNrUe.ncdSsbInfo.usage == CI_use ?
        rMeasObjectNrUe.ncdSsbInfo.ncdSsbArfcn :
        rMeasObjectNrUe.ssbFrequency;
}

/****************************************************************************
 * @brief           Function get NR RRC SSB Subcarrier spacing
 *
 * @param[in/out]   rMoCandidate : Reference to minimalMeasObjectConfUe_type
 * @return          SsbSubcarrierSpacing : uint8_t
 ******************************************************************************/
uint8_t FnVCCB_GetRrcMeasObjectNrSsbScs(const minimalMeasObjectNRUe_type &rMeasObjectNrUe)
{
    return rMeasObjectNrUe.ncdSsbInfo.usage == CI_use ?
        rMeasObjectNrUe.ncdSsbInfo.ncdSsbSubcarrierSpacing :
        rMeasObjectNrUe.ssbSubcarrierSpacing ;
}
