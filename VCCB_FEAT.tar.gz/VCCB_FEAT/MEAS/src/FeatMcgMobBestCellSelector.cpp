#include "FeatMcgMobBestCellSelector.hpp"
#include "FeatMeasurements.hpp"
#include "FeatCallProc.h"

#include "ComInclude.h"

#include "StateMeasurements.h"
#include "StateCommon.h"

// FGR-CC5001 FR235
inline bool VCCB_ENDC_IsCellUlInterfered(const callInfo_type &rCall, const VccbCellInfo_type &rCell)
{
    return ((E_CALLTYPE_NSA == rCall.callType) ? VCCB_IsCellUlInterfered(rCell) : false);
}

bool VCCB_McgMobBestCellSelector::_IsIntraFreqA3PscellChangeRcConfigured(
    reportConfigurationConfUe_type &reportConfig) const
{
    auto moNotUsed = minimalMeasObjectConfUe_type();
    return VCCB_CanMOAndRCBeAddedWithCandidates(*_ptCi, _ptCi->servCellNum, measReport_A3,
                        a3Purpose_NRPSCellChange, CELLINFO[_ptCi->servCellNum].ssbArfcn, &reportConfig, &moNotUsed);
}

int VCCB_McgMobBestCellSelector::_CheckIfNbrCellIsOffsetBetterThanPsCell(
    const measQuantityResults_type &measResultNbr) const
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(_ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pPscell = &CELLINFO[_ptCi->servCellNum];
    auto reportConfig = reportConfigurationConfUe_type();
    const auto &intraFreqMo = pPscell->measurementsData.measurementObjectsNRDb[INTRAFREQ_OBJECT_IDX].base;

    if (not (IS_ENDC_SN(_ptCi) && IS_PER_CELL_SEL_THLD_ENABLED(pPscell)))
    {
        return GOOD;
    }

    if (not _hasMeasResultPscell)
    {
        VCCB_PRINT_CALL_COMMENT(_ptCi, "No PSCell meas result - offset-better condition cannot be checked.\n");
        return BREAK;
    }

    // Check if NBR cell is offset-better than PSCell based on reported measurements and triggering quantity.
    // if "intra-freq PSCell change event is A3":
    if (PSCellChange_EventA3 == intraFreqMo.nrPSCellChangeEvent)
    {
        // Guard: If intra-freq PSCell change event is A3 then report config with proper purpose must be configured.
        if (not _IsIntraFreqA3PscellChangeRcConfigured(reportConfig))
        {
            VCCB_PRINT_CALL_ERROR(_ptCi, "Failed to get A3 intra-freq PSCell change RC and MO.\n");
            return ERROR;
        }

        const auto &a3Offset = reportConfig.reportConfiguration.eventBased.event.A3.a3_OffsetOrigin;
        // if "triggering quantity is RSRP":
        if (IS_TRIGGERING_QUANTITY_RSRP(a3Offset.quantityInfo))
        {
            // if "PSCell and NBR cell have RSRP measurements":
            if ((TRUE == measResultNbr.rsrpFlag) && (TRUE == _measResultPscell.rsrpFlag))
            {
                // Check NBR-RSRP > (PSCell-RSRP + A3-OFFSET-RSRP).
                // A3 offset is in 0.5dB scale - multiply RSRP meas by 2 to make them comparable.
                const auto result =
                    ((2 * measResultNbr.rsrp) > ((2 * _measResultPscell.rsrp) + a3Offset.values.value_rsrp));
                return (result ? GOOD : BREAK);
            }
            // else "PSCell and NBR cell do not have RSRP":
            // Assume NBR cell is not offset better than PSCell.
            return BREAK;
        }
        // else if "triggering quantity is RSRQ":
        else if (IS_TRIGGERING_QUANTITY_RSRQ(a3Offset.quantityInfo))
        {
            // if "PSCell and NBR cell have RSRQ measurements":
            if ((TRUE == measResultNbr.rsrqFlag) && (TRUE == _measResultPscell.rsrqFlag))
            {
                // Check NBR-RSRQ > (PSCell-RSRQ + A3-OFFSET-RSRQ).
                const auto result = (measResultNbr.rsrq > (_measResultPscell.rsrq + a3Offset.values.value_rsrq));
                return (result ? GOOD : BREAK);
            }
        }

        // if "PSCell and NBR cell have RSRP measurements ('triggering quantity is RSRQ and UE didn't report RSRQ' or
        // 'triggering quantity is SINR')":
        if ((TRUE == measResultNbr.rsrpFlag) && (TRUE == _measResultPscell.rsrpFlag))
        {
            // Check NBR-RSRP > (PSCell-RSRP + DEFAULT-RSRP-OFFSET-1dB).
            const auto result = (measResultNbr.rsrp > (_measResultPscell.rsrp + RSRP_OFFSET_1dB));
            return (result ? GOOD : BREAK);
        }
        // else "PSCell and NBR cell do not have RSRP":
        // Assume NBR cell is not offset better than PSCell.
    }
    // else "intra-freq PSCell change event is A4 or A5":
    else
    {
        // if "PSCell and NBR cell have RSRP measurements":
        if ((TRUE == measResultNbr.rsrpFlag) && (TRUE == _measResultPscell.rsrpFlag))
        {
            // Check NBR-RSRP > (PSCell-RSRP + DEFAULT-RSRP-OFFSET-1dB).
            const auto result = (measResultNbr.rsrp > (_measResultPscell.rsrp + RSRP_OFFSET_1dB));
            return (result ? GOOD : BREAK);
        }
        // else "PSCell and NBR cell do not have RSRP measurements":
        // Assume that NBR cell is not offset-better than PSCell.
    }

    // NBR cell is not offset better than PSCell.
    return BREAK;
}

int VCCB_McgMobBestCellSelector::_CheckCellAgainstThresholds(const measQuantityResults_type &measResult) const
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(_ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pPscell = &CELLINFO[_ptCi->servCellNum];

    if (not (IS_ENDC_SN(_ptCi) && IS_PER_CELL_SEL_THLD_ENABLED(pPscell)))
    {
        return GOOD;
    }

    const auto rsrpThld = pPscell->mobilityConfig.endcPscellSelectionThreshold.thresholdRsrp;
    const auto rsrqThld = pPscell->mobilityConfig.endcPscellSelectionThreshold.thresholdRsrq;
    bool isRsrpThdlMet = true;
    bool isRsrqThdlMet = true;

    if (NOT_CONFIGURED != rsrpThld)
    {
        if (TRUE == measResult.rsrpFlag)
        {
            isRsrpThdlMet = measResult.rsrp > rsrpThld;
        }
    }
    if (NOT_CONFIGURED != rsrqThld)
    {
        if (TRUE == measResult.rsrqFlag)
        {
            isRsrqThdlMet = measResult.rsrq > rsrqThld;
        }
    }

    if ((true == isRsrpThdlMet) && (true == isRsrqThdlMet))
    {
        return GOOD;
    }

    return BREAK;
}

bool VCCB_McgMobBestCellSelector::_VerifyPscellIntraBandRelationWithLtePcell()
{
    _pscellIntraBandCheckOk = true;

    if (VCCB_IsEndcSn(*_ptCi) && (GOOD != VCCB_CheckIntraBandRelationForNrAndLteBand(_ptCi, _ptCi->servCellBand)))
    {
        VCCB_PRINT_CALL_COMMENT(_ptCi,
            "_VerifyPscellIntraBandRelationWithLtePcell: PScell is in intra-band relation with LTE PCell and there's "
            "no band combination supporting it.\n");
        _pscellIntraBandCheckOk = false;
    }

    return _pscellIntraBandCheckOk;
}

void VCCB_McgMobBestCellSelector::UpdateWithServCell(
    const measResult2NR_type &rMeasRes2NR, const measResultNR_type &rMeasResNR)
{
    AUTO_TRACE_FUNC;

    VCCB_CandidateCellInfo newCell(_HasMeasResultNrcgi(rMeasResNR), {_ptCi->servCellNum, _ptCi->servCellBand});
    const measQuantityResults_type *measResult = NULL;
    uint32_t measResultFreq = 0;

    // Only SSB frequency is supported.
    if (TRUE == rMeasResNR.cellResults.resultsSSB_CellFlag)
    {
        measResult = &rMeasResNR.cellResults.resultsSSB_Cell;
        measResultFreq = rMeasRes2NR.ssbFrequency;
    }
    else
    {
        VCCB_PRINT_CALL_COMMENT(_ptCi, "[MCG-MOB] %s: no SSB cell measurement result.\n", __FUNCTION__);
        return;
    }

    // Perform ALL required checks.
    const auto canBePcell         = (GOOD == VCCB_isBandSupportedAsPcellBand(_ptCi, _ptCi->servCellBand));
    const auto isMeasCheckOk      = _IsNewCellBetterBasedOnMeas(*measResult, measResultFreq, newCell);
    const auto isThldCheckOk      = (GOOD == _CheckCellAgainstThresholds(*measResult));
    const auto isIntraBandCheckOk = _VerifyPscellIntraBandRelationWithLtePcell();
    // FGR-CC5001 FR235
    const auto isUlInterfered     = VCCB_ENDC_IsCellUlInterfered(*_ptCi, CELLINFO[newCell.cellSelection.cellNum]);
    if (canBePcell && isMeasCheckOk && isThldCheckOk && isIntraBandCheckOk && (!isUlInterfered))
    {
        _bestCell = newCell;
    }

    // Update PSCell information.
    _isPscellBelowSelThld = newCell.isBelowThld;
    _measResultPscell     = *measResult;
    _hasMeasResultPscell  = true;
}

void VCCB_McgMobBestCellSelector::UpdateWithNeighbourPci(
    const measResult2NR_type &rMeasRes2NR, const measResultNR_type &rMeasResNR)
{
    AUTO_TRACE_FUNC;

    VCCB_CandidateCellInfo newCell(_HasMeasResultNrcgi(rMeasResNR));
    const measQuantityResults_type *measResult = NULL;
    enumRSType measResultType = RSType_SSB;
    uint32_t measResultFreq = 0;

    // Only SSB frequency is supported.
    if (TRUE == rMeasResNR.cellResults.resultsSSB_CellFlag)
    {
        measResult = &rMeasResNR.cellResults.resultsSSB_Cell;
        measResultFreq = rMeasRes2NR.ssbFrequency;
    }
    else
    {
        VCCB_PRINT_CALL_COMMENT(_ptCi, "[MCG-MOB] %s: no SSB cell measurement result.\n", __FUNCTION__);
        return;
    }

    // Perform ALL required checks.
    const auto isPciCheckOk = (GOOD == VCCM_CheckPciCellForHo(_ptCi, rMeasResNR.physCellId, measResultFreq,
                                           measResultType, &newCell.cellSelection));
    const auto isMeasCheckOk = _IsNewCellBetterBasedOnMeas(*measResult, measResultFreq, newCell);
    const auto isThldCheckOk = (GOOD == _CheckCellAgainstThresholds(*measResult));
    const auto isNbrOffCheckOk = (GOOD == _CheckIfNbrCellIsOffsetBetterThanPsCell(*measResult));
    if (isPciCheckOk && isMeasCheckOk && isThldCheckOk && isNbrOffCheckOk)
    {
        _bestCell = newCell;
    }
}

bool VCCB_McgMobBestCellSelector::_IsNewMeasBetterThanCurrentBest(const VCCB_CandidateCellInfo &rNewCell) const
{
    AUTO_TRACE_FUNC;
    if (rNewCell.measValue > _bestCell.measValue)
    {
        if (VCCB_IsEndcSn(*_ptCi))
        {
            if (_bestCell.isNrcgi && (not rNewCell.isNrcgi))
            {
                return false;
            }
        }
        return true;
    }
    else
    {
        if (VCCB_IsEndcSn(*_ptCi))
        {
            if ((not _bestCell.isNrcgi) && rNewCell.isNrcgi)
            {
                return true;
            }
        }
        return false;
    }
}

bool VCCB_McgMobBestCellSelector::_TrySelectMeasResultValue(
    const measQuantityResults_type &rMeasResult, uint16_t &rMeasValue) const
{
    AUTO_TRACE_FUNC;
    if (TRUE == rMeasResult.rsrpFlag)
    {
        rMeasValue = rMeasResult.rsrp;
        return true;
    }
    else if (TRUE == rMeasResult.rsrqFlag)
    {
        rMeasValue = rMeasResult.rsrq;
        return true;
    }
    else if (TRUE == rMeasResult.sinrFlag)
    {
        rMeasValue = rMeasResult.sinr;
        return true;
    }
    return false;
}

bool VCCB_McgMobBestCellSelector::_IsMeasAboveThld(
    const measQuantityResults_type &rMeasResult, uint32_t frequency, VCCB_CandidateCellInfo &rNewCell) const
{
    return (GOOD == VCCM_IsMeasAboveThld(_ptCi, &rMeasResult, frequency, _ptCi->gnbNum, rNewCell.cellSelection.cellNum));
}

bool VCCB_McgMobBestCellSelector::_IsNewCellBetterBasedOnMeas(
    const measQuantityResults_type &rMeasResult, uint32_t frequency, VCCB_CandidateCellInfo &rNewCell) const
{
    AUTO_TRACE_FUNC;
    const VccbCellInfo_type *const pPscell = &CELLINFO[_ptCi->servCellNum];
    // Try to select one of measurement result value (RSRP, RSRQ and SINR - in this order).
    if (not _TrySelectMeasResultValue(rMeasResult, rNewCell.measValue))
    {
        return false;
    }
    // Verify if new measurement is better considering presence of NR-CGI.
    if (not _IsNewMeasBetterThanCurrentBest(rNewCell))
    {
        return false;
    }
    // Mobility for EN-DC FR185: No other check is needed in case that per-cell selection threshold is enabled.
    if (IS_ENDC_SN(_ptCi) && IS_PER_CELL_SEL_THLD_ENABLED(pPscell))
    {
        return true;
    }
    // Verify if this measurement is above configured threshold.
    if (not _IsMeasAboveThld(rMeasResult, frequency, rNewCell))
    {
        rNewCell.isBelowThld = true;
        return false;
    }
    return true;
}

bool VCCB_McgMobBestCellSelector::_HasMeasResultNrcgi(const measResultNR_type &rMeasResNR) const
{
    AUTO_TRACE_FUNC;
    if ((VCCB_FLAG_ON == rMeasResNR.cgiInfoFlag) && (VCCB_FLAG_ON == rMeasResNR.cgiInfo.plmn_IdentityInfoList_Flag) &&
        (0 < rMeasResNR.cgiInfo.plmn_IdentityInfoList.nrofPLMN_IdentityInfo))
    {
        return true;
    }

    return false;
}
