/****************************************************************
 * System      : 5G gNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatMeasCommon.cpp
 * Description : This file contains common functions related with Measurements
 * Dept.       : 5G Call SW Lab.
 * Created     : 2024.05.16
 ****************************************************************/

#include "FeatMeasCommon.hpp"
#include "ComInclude.h"
#include "FeatCommon.h"
#include "ComUtil.hpp"
#include "VccbMacro.h"

/****************************************************************************
 * @brief           Find index of cdToNcdMappingEntries corelated with CD SSB Frequency
 *
 * @param[in]       frequency : Frequency to measure. / Arfcn_type/uint32_t
 * @param[in]       ncdSsbConfig : Reference to ncd-ssb-config. / NcdSsbConfig_type
 * @return          index of cdToNcdMappingEntries: std::optional<uint8_t>
 ****************************************************************************/
std::optional<uint8_t> VCCB_FindCdToNcdMappingIdx(const NcdSsbConfig_type &ncdSsbConfig, uint32_t frequency)
{
    AUTO_TRACE_FUNC;
    if (!ncdSsbConfig.featureEnabled) return std::nullopt;

    for (uint8_t index = 0u; index < util::arraySize(ncdSsbConfig.cdToNcdMappingEntries); index++)
    {
        const auto &cdToNcdMappingEntry = ncdSsbConfig.cdToNcdMappingEntries[index];
        if (cdToNcdMappingEntry.usage == CI_no_use) continue;

        if (cdToNcdMappingEntry.cdSsbFreq == frequency) return index;
    }

    return std::nullopt;
}

/****************************************************************************
 * @brief           Check if SSB frequency is allowed
 *
 * @param[in]       rCall : reference to call info / const callInfo_type&
 * @param[in]       ssbFrequency : Frequency / Arfcn_type/uint32_t
 * @return          status : true/false / bool
 ****************************************************************************/
bool FnVCCB_IsSsbAllowed(const callInfo_type &rCall, const uint32_t ssbFrequency)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_VALID_GNBNUM_RET_VAL(rCall.gnbNum, false);
    const auto &frequencyContainers = GNBINFO[rCall.gnbNum].restrictedSsbFrequencies.ssbFreqEntriesPerTarget;
    const auto containersBegin = std::begin(frequencyContainers);
    const auto containersEnd = std::end(frequencyContainers);
    const bool ueSupportsUsa = rCall.ueInfo.ueCapa.nr.rf.extendedBand_n77_r16;
    const bool ueSupportsCanada = rCall.ueInfo.ueCapa.nr.rf.extendedBand_n77_2_r17;

    auto targetMatcher =
        [](const enumSsbFrequenciesRestriction_type target, const SsbFreqPerTarget_type &frequencyContainer)
    {
        if (CI_use != frequencyContainer.usage) return false;
        if (target == frequencyContainer.target) return true;
        return false;
    };

    auto ssbMatcher = [ssbFrequency](const SsbFreqPerTarget_type &ssbFrequencies)
    {
        if (0 == ssbFrequencies.noOfSsbFreqEntries) return false;
        auto end = std::begin(ssbFrequencies.ssbFreqEntries) + ssbFrequencies.noOfSsbFreqEntries;
        return end != std::find(std::begin(ssbFrequencies.ssbFreqEntries), end, ssbFrequency);
    };

    if (!ueSupportsUsa)
    {
        auto usaMatcher = [&targetMatcher](const auto &frequencyContainer)
        { return targetMatcher(ssbFrequenciesRestriction_n77_usa, frequencyContainer); };
        const auto usaFrequencies = std::find_if(containersBegin, containersEnd, usaMatcher);
        if ((containersEnd != usaFrequencies) && ssbMatcher(*usaFrequencies))
        {
            VCCB_PRINT_CALL_COMMENT(&rCall, "%u ssbFrequency is not allowed because UE does not support USA n77 range restriction!\n",
                    ssbFrequency);
            return false;
        }
    }

    if (!ueSupportsCanada)
    {
        auto canadaMatcher = [&targetMatcher](const auto &frequencyContainer)
        { return targetMatcher(ssbFrequenciesRestriction_n77_2_canada, frequencyContainer); };
        const auto canadaFrequencies = std::find_if(containersBegin, containersEnd, canadaMatcher);
        if ((containersEnd != canadaFrequencies) && ssbMatcher(*canadaFrequencies))
        {
            VCCB_PRINT_CALL_COMMENT(&rCall, "%u ssbFrequency is not allowed because UE does not support Canada n77 range restriction!\n",
                    ssbFrequency);
            return false;
        }
    }
    return true;
}

/****************************************************************************
 *  @brief Return ratType based on reportType
 ****************************************************************************/
enumMeasRatType VCCB_GetRatType(enumMeasurementReportType reportType)
{
    AUTO_TRACE_FUNC;

    switch (reportType)
    {
        case measReport_periodical:
        case measReport_A1:
        case measReport_A2:
        case measReport_A3:
        case measReport_A4:
        case measReport_A5:
        case measReport_A6:
        case measReport_reportCGI:

            return measRatNr;

        case measReport_B1Eutra:
        case measReport_B2Eutra:
        case measReport_periodicalInterRat:
        case measReport_reportCGIEutra:

            return measRatEutra;

        default:
            VCCB_PRINT_ERROR("reportType(%u) not supported!\n", reportType);
            break;
    }

    return measRatUnknown;
}

bool VCCB_isAssociatedWithCondTriggerConfigA3(enumA3Purpose reportPurpose)
{
    return (a3Purpose_ChoExecutionCond1 == reportPurpose) || (a3Purpose_ChoExecutionCond2 == reportPurpose);
}

bool VCCB_isAssociatedWithCondTriggerConfigA5(enumA5Purpose reportPurpose)
{
    return (a5Purpose_ChoExecutionCond1 == reportPurpose) || (a5Purpose_ChoExecutionCond2 == reportPurpose);
}

bool VCCB_isAssociatedWithCondTriggerConfig(const reportConfigurationConfUe_type &toCheck)
{
    switch (toCheck.reportType)
    {
        case measReport_A3:
            return VCCB_isAssociatedWithCondTriggerConfigA3(static_cast<enumA3Purpose>(toCheck.reportPurpose));
        case measReport_A5:
            return VCCB_isAssociatedWithCondTriggerConfigA5(static_cast<enumA5Purpose>(toCheck.reportPurpose));
        default:
            return false;
    }
}

/****************************************************************************
 * @brief           Checks if SSB or associated SSB condition defined
 *                  for MeasObject NR in 3GPP TS 38.331 r20 is fulfilled.
 *
 * @param[in]       rNew : reference to referenceSignalConfig object associated
 *                         with a given MeasObjectNR. / referenceSignalConfigUe_type&
 * @return          result : Result of the check. / bool / true/false
 ****************************************************************************/
bool VCCB_CheckCondSsbOrAssociatedSsb(const referenceSignalConfigUe_type &rNew)
{
    AUTO_TRACE_FUNC;

    return rNew.ssbConfigMobility.usage == CI_use;
}

namespace
{
int8_t VCCB_addDeltaAndClamp(int8_t value, int16_t delta, int8_t lowerLimit, int8_t upperLimit)
{
    AUTO_TRACE_FUNC;
    if ((value + delta) < lowerLimit)
    {
        return lowerLimit;
    }
    else if ((value + delta) > upperLimit)
    {
        return upperLimit;
    }
    else
    {
        return static_cast<int8_t>(value + delta);
    }
}
}  // namespace

/****************************************************************************
 * @brief Modify Threshold by applying Delta
 * @param[in/out]  value      : threshold to modify
 * @param[in]      delta      : Delta threshold to apply
 ****************************************************************************/
void VCCB_ModifySelectedThresholds_ApplyDelta(const callInfo_type *ptCi, int8_t &value, int16_t delta)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    const int8_t thresholdUpperLimit = 127;
    const int8_t thresholdLowerLimit = 0;
    int8_t oldValue = value;
    value = VCCB_addDeltaAndClamp(value, delta, thresholdLowerLimit, thresholdUpperLimit);
    VCCB_PRINT_CALL_COMMENT(ptCi, "Old Threshold Value:%d, New Threshold Value:%d, Delta:%d in %s.\n", oldValue, value,
        delta, __FUNCTION__);
}

/****************************************************************************
 * @brief Modify Offset by applying Delta
 * @param[in/out]  value      : threshold to modify
 * @param[in]      delta      : Delta threshold to apply
 ****************************************************************************/
void VCCB_ModifySelectedOffset_ApplyDelta(callInfo_type *ptCi, int8_t &value, int16_t delta)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    const int8_t offsetUpperLimit = 30;
    const int8_t offsetLowerLimit = -30;
    int8_t oldValue = value;
    value = VCCB_addDeltaAndClamp(value, delta, offsetLowerLimit, offsetUpperLimit);
    VCCB_PRINT_CALL_COMMENT(
        ptCi, "Old Offset Value:%d, New Offset Value:%d, Delta:%d in %s.\n", oldValue, value, delta, __FUNCTION__);
}

/****************************************************************************
 * @brief Return new value after applying delta.
 * @param[in]      measTriggerQuantity      : threshold with to modify
 * @param[in]      delta                    : Eutra Delta threshold to apply
 ****************************************************************************/
int8_t VCCB_ApplyDeltaEutra(callInfo_type *ptCi, const measTriggerUe_type &measTriggerQuantity, int16_t delta)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    int8_t thresholdUpperLimit = 97;  // RSRP-RangeEUTRA
    const int8_t thresholdLowerLimit = 0;
    int8_t oldValue = measTriggerQuantity.value;

    if (choice_rsrp == measTriggerQuantity.quantity)  // RSRP-RangeEUTRA
    {
        thresholdUpperLimit = 97;
    }
    else if (choice_rsrq == measTriggerQuantity.quantity)  // RSRQ-RangeEUTRA
    {
        thresholdUpperLimit = 34;
    }
    else  // SINR-RangeEUTRA
    {
        thresholdUpperLimit = 127;
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "Old Threshold Value:%d, New Threshold Value:%d, Delta:%d in %s.\n", oldValue,
        measTriggerQuantity.value, delta, __FUNCTION__);
    return VCCB_addDeltaAndClamp(measTriggerQuantity.value, delta, thresholdLowerLimit, thresholdUpperLimit);
}