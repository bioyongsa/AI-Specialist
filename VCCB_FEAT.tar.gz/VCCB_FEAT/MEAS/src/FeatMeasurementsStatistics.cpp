#include "FeatMeasurementsStatistics.h"

#include "ComInclude.h"
#include "ComLibUtility.h"
#include "ComUtil.hpp"
#include "ComFind.hpp"
#include "FeatMeasurements.hpp"
#include "FeatMeasurementsStatisticsDefinition.hpp"

namespace
{
class MeasItems
{
public:
    unsigned int rsrpCount{0};
    unsigned int rsrpSum{0};
    unsigned int rsrqCount{0};
    unsigned int rsrqSum{0};
    unsigned int sinrCount{0};
    unsigned int sinrSum{0};

    void AggregateMeasItems(const measResultNR_type& MeasResultNR)
    {
        if (MeasResultNR.cellResults.resultsSSB_CellFlag != VCCB_FLAG_ON)
        {
            return;
        }

        if (MeasResultNR.cellResults.resultsSSB_Cell.rsrpFlag == VCCB_FLAG_ON)
        {
            rsrpSum += MeasResultNR.cellResults.resultsSSB_Cell.rsrp;
            rsrpCount++;
        }
        if (MeasResultNR.cellResults.resultsSSB_Cell.rsrqFlag == VCCB_FLAG_ON)
        {
            rsrqSum += MeasResultNR.cellResults.resultsSSB_Cell.rsrq;
            rsrqCount++;
        }
        if (MeasResultNR.cellResults.resultsSSB_Cell.sinrFlag == VCCB_FLAG_ON)
        {
            sinrSum += MeasResultNR.cellResults.resultsSSB_Cell.sinr;
            sinrCount++;
        }
    }

    void AggregateEutraMeasItems(const measResultEUTRA_type& MeasResultEutra)
    {
        if (MeasResultEutra.measResultEutra.rsrpFlag == VCCB_FLAG_ON)
        {
            rsrpSum += MeasResultEutra.measResultEutra.rsrp;
            rsrpCount++;
        }
        if (MeasResultEutra.measResultEutra.rsrqFlag == VCCB_FLAG_ON)
        {
            rsrqSum += MeasResultEutra.measResultEutra.rsrq;
            rsrqCount++;
        }
        if (MeasResultEutra.measResultEutra.sinrFlag == VCCB_FLAG_ON)
        {
            sinrSum += MeasResultEutra.measResultEutra.sinr;
            sinrCount++;
        }
    }
};

#define FILL_STAT_SOURCE_CELL_MR_FAMILY_STRUCT(counters, TypeAndPurpose) \
    counters.rsrpCount = SourceMr##TypeAndPurpose##RsrpOccurences;  \
    counters.rsrpSum = SourceMr##TypeAndPurpose##RsrpValueSum;      \
    counters.rsrqCount = SourceMr##TypeAndPurpose##RsrqOccurences;  \
    counters.rsrqSum = SourceMr##TypeAndPurpose##RsrqValueSum;      \
    counters.sinrCount = SourceMr##TypeAndPurpose##SinrOccurences;  \
    counters.sinrSum = SourceMr##TypeAndPurpose##SinrValueSum;

bool VCCB_FillMRStructStatSourceCellFamily(
    const enumMeasurementReportType reportType, const uint8_t reportPurpose, OneCategoryStatTypes& counters)
{
    switch (reportType)
    {
        case measReport_A2:
            switch (reportPurpose)
            {
                case a2Purpose_blindInterRatRedirection:
                    FILL_STAT_SOURCE_CELL_MR_FAMILY_STRUCT(counters, A2BlindInterRatRedirection);
                    break;
                case a2Purpose_blindIntraNrRedirectionForSa:
                    FILL_STAT_SOURCE_CELL_MR_FAMILY_STRUCT(counters, A2BlindIntraNrRedirection);
                    break;
                default:
                    return false;
            }
            break;

        case measReport_A3:
            switch (reportPurpose)
            {
                case a3Purpose_intraNrHandover:
                    FILL_STAT_SOURCE_CELL_MR_FAMILY_STRUCT(counters, A3IntraNrHandover);
                    break;
                default:
                    return false;
            }
            break;

        case measReport_B1Eutra:
            switch (reportPurpose)
            {
                case b1Purpose_eutraHandover:
                case b1Purpose_saEmergencyFallbackHandover:
                case b1Purpose_saEpsFallbackHandover:
                    FILL_STAT_SOURCE_CELL_MR_FAMILY_STRUCT(counters, B1EutraHandover);
                    break;
                default:
                    return false;
            }
            break;
        case measReport_B2Eutra:
            switch (reportPurpose)
            {
                case b2Purpose_eutraHandover:
                case b2Purpose_saEmergencyFallbackHandover:
                case b2Purpose_saEpsFallbackHandover:
                    FILL_STAT_SOURCE_CELL_MR_FAMILY_STRUCT(counters, B2EutraHandover);
                    break;
                default:
                    return false;
            }
            break;
        default:
            return false;
    }
    return true;
}

#undef FILL_STAT_SOURCE_CELL_MR_FAMILY_STRUCT

bool VCCB_FillMRStructStatInterRatTargetCellFamily(
    const enumMeasurementReportType reportType, const uint8_t reportPurpose, OneCategoryStatTypes& counters)
{
    switch (reportType)
    {
        case measReport_B1Eutra:
            switch (reportPurpose)
            {
                case b1Purpose_eutraHandover:
                case b1Purpose_saEmergencyFallbackHandover:
                case b1Purpose_saEpsFallbackHandover:
                    counters.rsrpAllOccurences = InterRatTargetMrAllEventsRsrpOccurences;
                    counters.rsrpCount = InterRatTargetMrB1EutraHandoverRsrpOccurences;
                    counters.rsrpSum = InterRatTargetMrB1EutraHandoverRsrpValueSum;
                    counters.rsrqCount = InterRatTargetMrB1EutraHandoverRsrqOccurences;
                    counters.rsrqSum = InterRatTargetMrB1EutraHandoverRsrqValueSum;
                    counters.sinrCount = InterRatTargetMrB1EutraHandoverSinrOccurences;
                    counters.sinrSum = InterRatTargetMrB1EutraHandoverSinrValueSum;
                    break;
                default:
                    return false;
            }
            break;
        case measReport_B2Eutra:
            switch (reportPurpose)
            {
                case b2Purpose_eutraHandover:
                case b2Purpose_saEmergencyFallbackHandover:
                case b2Purpose_saEpsFallbackHandover:
                    counters.rsrpAllOccurences = InterRatTargetMrAllEventsRsrpOccurences;
                    counters.rsrpCount = InterRatTargetMrB2EutraHandoverRsrpOccurences;
                    counters.rsrpSum = InterRatTargetMrB2EutraHandoverRsrpValueSum;
                    counters.rsrqCount = InterRatTargetMrB2EutraHandoverRsrqOccurences;
                    counters.rsrqSum = InterRatTargetMrB2EutraHandoverRsrqValueSum;
                    counters.sinrCount = InterRatTargetMrB2EutraHandoverSinrOccurences;
                    counters.sinrSum = InterRatTargetMrB2EutraHandoverSinrValueSum;
                    break;
                default:
                    return false;
            }
            break;
        default:
            return false;
    }
    return true;
}

bool VCCB_FillMRStructStatNRTargetCellFamily(
    const enumMeasurementReportType reportType, const uint8_t reportPurpose, OneCategoryStatTypes& counters)
{
    switch (reportType)
    {
        case measReport_A3:
            switch (reportPurpose)
            {
                case a3Purpose_intraNrHandover:
                    counters.rsrpAllOccurences = NrTargetMrAllEventsRsrpOccurences;
                    counters.rsrpCount = NrTargetMrA3IntraNrHandoverRsrpOccurences;
                    counters.rsrpSum = NrTargetMrA3IntraNrHandoverRsrpValueSum;
                    counters.rsrqCount = NrTargetMrA3IntraNrHandoverRsrqOccurences;
                    counters.rsrqSum = NrTargetMrA3IntraNrHandoverRsrqValueSum;
                    counters.sinrCount = NrTargetMrA3IntraNrHandoverSinrOccurences;
                    counters.sinrSum = NrTargetMrA3IntraNrHandoverSinrValueSum;
                    break;
                default:
                    return false;
            }
            break;
        default:
            return false;
    }
    return true;
}

bool VCCB_FillMeasReportStruct(const int mFamily, const enumMeasurementReportType reportType,
    const uint8_t reportPurpose, OneCategoryStatTypes& counters)
{
    bool status = false;

    switch (mFamily)
    {
        case STAT_SOURCE_CELL_MR:
            status = VCCB_FillMRStructStatSourceCellFamily(reportType, reportPurpose, counters);
            break;
        case STAT_NR_TARGET_CELL_MR:
            status = VCCB_FillMRStructStatNRTargetCellFamily(reportType, reportPurpose, counters);
            break;
        case STAT_INTER_RAT_TARGET_CELL_MR:
            status = VCCB_FillMRStructStatInterRatTargetCellFamily(reportType, reportPurpose, counters);
            break;
        default:
            VCCB_PRINT_COMMENT("%s Unsupported measurement Family.\n", __func__);
            return status;
    }

    if (!status)
    {
        VCCB_PRINT_COMMENT("%s: Unsupported report Type and Purpose.\n", __func__);
    }

    return status;
}

/****************************************************************************
 * @brief           Updates measurement report quantity counters using the provided statistics.
 *                  This function updates RSRP, RSRQ, and SINR counters (both count and sum) for the
 *                  specified measurement family using the statistical mapping provided.
 *
 * @param[in,out]   ptCi : Pointer to callInfo_type structure
 * @param[in]       mFamily : Measurement family identifier
 * @param[in]       stats : Reference to OneCategoryStatTypes containing counter mappings
 * @param[in]       measItems : Reference to MeasItems containing aggregated measurement data
 * @param[in]       usedFreq : Frequency used for the measurement
 ****************************************************************************/
void VCCB_UpdateMRQuantityCounters(callInfo_type* ptCi, const int mFamily, const OneCategoryStatTypes& stats,
    MeasItems& measItems, const uint64_t optParam1 = 0, const uint64_t optParam2 = 0)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    if (stats.purposeCount.has_value())
    {
        MACRO_STAT_PMCC(mFamily, stats.purposeCount.value(), ptCi, optParam1, optParam2, 0, 0, 0);
    }

    if (measItems.rsrpCount)
    {
        if (stats.rsrpAllOccurences.has_value())
        {
            MACRO_STAT_PMCC_VALUE(mFamily, stats.rsrpAllOccurences.value(), ptCi, optParam1, optParam2, 0, 0, 0, measItems.rsrpCount);
        }
        MACRO_STAT_PMCC_VALUE(mFamily, stats.rsrpCount, ptCi, optParam1, optParam2, 0, 0, 0, measItems.rsrpCount);
        MACRO_STAT_PMCC_VALUE(mFamily, stats.rsrpSum, ptCi, optParam1, optParam2, 0, 0, 0, measItems.rsrpSum);
    }
    if (measItems.rsrqCount)
    {
        MACRO_STAT_PMCC_VALUE(mFamily, stats.rsrqCount, ptCi, optParam1, optParam2, 0, 0, 0, measItems.rsrqCount);
        MACRO_STAT_PMCC_VALUE(mFamily, stats.rsrqSum, ptCi, optParam1, optParam2, 0, 0, 0, measItems.rsrqSum);
    }
    if (measItems.sinrCount)
    {
        MACRO_STAT_PMCC_VALUE(mFamily, stats.sinrCount, ptCi, optParam1, optParam2, 0, 0, 0, measItems.sinrCount);
        MACRO_STAT_PMCC_VALUE(mFamily, stats.sinrSum, ptCi, optParam1, optParam2, 0, 0, 0, measItems.sinrSum);
    }
}

measResultNR_type* VCCB_FindMeasResultServingCell(const uint32_t usedFreq, measResultList2NR_type* ptMeasResultList2NR)
{
    measResult2NR_type* ptMeasResult2NR = nullptr;

    ptMeasResult2NR = util::findObjectIfExist(ptMeasResultList2NR->measResult2NR, ptMeasResultList2NR->nrofFreq,
        [usedFreq](const measResult2NR_type& mr)
        { return mr.measResultServingCell_Flag && mr.ssbFrequency_Flag && (mr.ssbFrequency == usedFreq); });
    if (!ptMeasResult2NR)
    {
        VCCB_PRINT_ERROR("%s ERROR: Cannot find MeasResultServingCell with arfcn:%u !!\n", __func__, usedFreq);
        return nullptr;
    }

    return &ptMeasResult2NR->measResultServingCell;
}

measResult2NR_type* VCCB_FindMeasResult2NR(const uint32_t usedFreq, measResultList2NR_type* ptMeasResultList2NR)
{
    for (uint8_t mrIndex = 0;
         mrIndex < util::minOfArraySizeAndNumOfElems(ptMeasResultList2NR->measResult2NR, ptMeasResultList2NR->nrofFreq);
         mrIndex++)
    {
        if (ptMeasResultList2NR->measResult2NR[mrIndex].ssbFrequency_Flag == TRUE &&
            ptMeasResultList2NR->measResult2NR[mrIndex].ssbFrequency == usedFreq)
        {
            return &ptMeasResultList2NR->measResult2NR[mrIndex];
        }
    }

    VCCB_PRINT_ERROR("%s ERROR: MeasResult2R not found, ssbFrequency Flag is not present!!\n", __func__);
    return nullptr;
}

/****************************************************************************
 * @brief           Extracts measurement items based on report configuration and frequency.
 *                  For A1/A2 reports, processes serving cell measurements.
 *                  For A3/A4/A5 reports, processes neighbor cell measurements (excluding best neighbor results).
 *
 * @param[in,out]   rCi : Reference to callInfo_type structure
 * @param[in]       reportType : Measurement report type
 * @param[in]       selectMeasObj : Reference to measurement object configuration
 * @param[in]       usedFreq : Frequency used for measurement
 * @param[out]      measItems : Reference to MeasItems structure to store aggregated measurements
 * @return          true if measurement items were successfully extracted, false otherwise
 ****************************************************************************/
bool VCCB_GetMeasItemsForCurrentReportConfig(
    callInfo_type& rCi, const enumMeasurementReportType reportType, const uint32_t usedFreq, MeasItems& measItems)
{
    VCCB_CHECK_E_RANGE_AND_VAL(rCi.myThreadId, MAX_CALL_THREAD_NUM_VCCB, false);

    measResultList2NR_type* ptMeasResultList2NR =
        &THREAD_INFO->call[rCi.myThreadId].buf.measResultList2NRRx.candidateCellInfoListSN;
    if (reportType == measReport_A1 || reportType == measReport_A2)
    {
        measResultNR_type* ptMeasResultServingCell = VCCB_FindMeasResultServingCell(usedFreq, ptMeasResultList2NR);
        if (!ptMeasResultServingCell)
        {
            return false;
        }

        measItems.AggregateMeasItems(*ptMeasResultServingCell);
    }
    else if (reportType == measReport_A3 || reportType == measReport_A4 || reportType == measReport_A5 ||
             reportType == measReport_periodical)
    {
        measResult2NR_type* ptMeasResult2NR = VCCB_FindMeasResult2NR(usedFreq, ptMeasResultList2NR);
        if (!ptMeasResult2NR)
        {
            return false;
        }

        for (uint16_t nbrCellIdx = 0;
            nbrCellIdx < MIN(ptMeasResult2NR->measResultNeighCellListNR.nrofCellReport, MAX_NUM_CELL_REPORT);
            nbrCellIdx++)
        {
            if (ptMeasResult2NR->measResultNeighCellListNR.measResultNR[nbrCellIdx].isBestNbrResultFlag == VCCB_FLAG_ON)
            {
                continue;
            }

            measItems.AggregateMeasItems(ptMeasResult2NR->measResultNeighCellListNR.measResultNR[nbrCellIdx]);
        }
    }
    else if (reportType == measReport_B1Eutra || reportType == measReport_B2Eutra)
    {
        measResultNeighCellsEUTRA_type* ptMeasResultList2EUTRA =
            &THREAD_INFO->call[rCi.myThreadId].buf.measResultListEutraRx;

        for (int nbrCellEutraIdx = 0; nbrCellEutraIdx < MIN(ptMeasResultList2EUTRA->numReportCell, MAX_NUM_CELL_REPORT);
            nbrCellEutraIdx++)
        {
            measItems.AggregateEutraMeasItems(ptMeasResultList2EUTRA->measResult[nbrCellEutraIdx]);
        }
    }
    else
    { // Unsupported Report Type
        return false;
    }
    return true;
}
std::optional<uint32_t> VCCB_GetMeasObjectFrequency(
    measurementObjectUe_type& rSelectMeasObj, const enumMeasurementReportType reportType)
{
    std::optional<uint32_t> freq = std::nullopt;
    switch (reportType)
    {
        case measReport_B1Eutra:
        case measReport_B2Eutra:
        case measReport_periodicalInterRat:
            freq = VCCB_GetMeasObjectCarrierFreq(rSelectMeasObj);
            break;
        case measReport_A1:
        case measReport_A2:
        case measReport_A3:
        case measReport_A4:
        case measReport_A5:
        case measReport_A6:
        case measReport_periodical:
            freq = VCCB_GetMeasObjectSsbFreq(rSelectMeasObj);
            break;
        default:
            break;
    }
    return freq;
}

/****************************************************************************
 * @brief           This function is in charge of processing MR's Thresholds (RSRP, RSRQ, SINR) for Source Cell.
 *
 * @param[out]      ptCi : pointer of callInfo_type
 * @param[in]       ptReportType : Report type
 * @param[in]       ptReportPurpose : Report purpose
 * @param[in]       selectMeasObj : measurementObjectUe_type
 ****************************************************************************/
void VCCB_StatSourceCellResults(callInfo_type* ptCi, const enumMeasurementReportType reportType,
    const uint8_t reportPurpose, const measurementObjectUe_type& selectMeasObj)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    measResultList2NR_type* ptMeasResultList2NR =
        &THREAD_INFO->call[ptCi->myThreadId].buf.measResultList2NRRx.candidateCellInfoListSN;

    MeasItems measItems{};

    switch (reportType)
    {
        case measReport_A2:
        {
            uint32_t usedFreq = VCCB_GetMeasObjectSsbFreq(selectMeasObj);

            measResultNR_type* ptMeasResultServingCell = VCCB_FindMeasResultServingCell(usedFreq, ptMeasResultList2NR);
            if (!ptMeasResultServingCell)
            {
                return;
            }

            measItems.AggregateMeasItems(*ptMeasResultServingCell);
            break;
        }
        case measReport_A3:
        {
            measResult2NR_type* ptMeasResult2NR = &ptMeasResultList2NR->measResult2NR[0];

            if (FALSE == ptMeasResult2NR->ssbFrequency_Flag)
            {
                VCCB_PRINT_ERROR("%s ERROR: ssbFrequency Flag is not present!!\n", __func__);
                return;
            }
            for (int nbrCellIdx = 0;
                 nbrCellIdx < MIN(ptMeasResult2NR->measResultNeighCellListNR.nrofCellReport, MAX_NUM_CELL_REPORT);
                 nbrCellIdx++)
            {
                measItems.AggregateMeasItems(ptMeasResult2NR->measResultNeighCellListNR.measResultNR[nbrCellIdx]);
            }
            break;
        }
        case measReport_B1Eutra:
            // fall through
        case measReport_B2Eutra:
        {
            uint64_t eci = 0;
            measResultNeighCellsEUTRA_type* ptMeasResultList2EUTRA =
                &THREAD_INFO->call[ptCi->myThreadId].buf.measResultListEutraRx;

            for (int nbrCellEutraIdx = 0;
                 nbrCellEutraIdx < MIN(ptMeasResultList2EUTRA->numReportCell, MAX_NUM_CELL_REPORT); nbrCellEutraIdx++)
            {
                measResultEUTRA_type* ptRes = &ptMeasResultList2EUTRA->measResult[nbrCellEutraIdx];

                int status =
                    VLIB_GetNbrEnbEutraCellIdByPciAndFreq(ptCi, ptMeasResultList2EUTRA->earfcnDl, ptRes->pci, &eci);
                if (status == ERROR)
                {
                    continue;
                }

                measItems.AggregateEutraMeasItems(*ptRes);
            }
            break;
        }
        default:
            VCCB_PRINT_COMMENT("%s : Unsupported report Type!\n", __func__);
            return;
    }

    OneCategoryStatTypes counters;
    if (!VCCB_FillMeasReportStruct(STAT_SOURCE_CELL_MR, reportType, reportPurpose, counters))
    {
        return;
    }
    VCCB_UpdateMRQuantityCounters(ptCi, STAT_SOURCE_CELL_MR, counters, measItems);
}

/****************************************************************************
 * @brief           This function is in charge of processing MR's Thresholds (RSRP, RSRQ, SINR) for NR Target Cell.
 *
 * @param[out]      ptCi : pointer of callInfo_type
 * @param[in]       reportType : Report type
 * @param[in]       reportPurpose : Report purpose
 * @param[in]       rsType : rs type (ssb-freq, CSI-RS)
 ****************************************************************************/
void VCCB_StatNrTargetCellResults(callInfo_type* ptCi, const enumMeasurementReportType reportType,
    const uint8_t reportPurpose, const enumRSType rsType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    int16_t status = GOOD;
    uint16_t nbrCellIdx = 0;
    uint32_t usedFreq = 0;
    uint64_t nci = 0;

    measResultList2NR_type* ptMeasResultList2NR =
        &THREAD_INFO->call[ptCi->myThreadId].buf.measResultList2NRRx.candidateCellInfoListSN;
    measResult2NR_type* ptMeasResult2NR = &ptMeasResultList2NR->measResult2NR[0];
    measResultNR_type* ptMeasResultNR = NULL;

    if (TRUE == ptMeasResult2NR->ssbFrequency_Flag && RSType_SSB == rsType)
    {
        usedFreq = ptMeasResult2NR->ssbFrequency;
    }
    else if (TRUE == ptMeasResult2NR->refFreqCSI_RS_Flag && RSType_CSIRS == rsType)
    {
        usedFreq = ptMeasResult2NR->refFreqCSI_RS;
    }

    for (nbrCellIdx = 0;
         nbrCellIdx < MIN(ptMeasResult2NR->measResultNeighCellListNR.nrofCellReport, MAX_NUM_CELL_REPORT); nbrCellIdx++)
    {
        ptMeasResultNR = &ptMeasResult2NR->measResultNeighCellListNR.measResultNR[nbrCellIdx];
        if ((FALSE == ptMeasResultNR->physCellIdFlag))
        {
            continue;
        }

        status = VLIB_GetNbrGnbNrCellIdByPciAndFreq(ptCi, usedFreq, ptMeasResultNR, rsType, &nci);
        if (status == ERROR)
        {
            continue;
        }

        MeasItems measItems{};
        measItems.AggregateMeasItems(*ptMeasResultNR);

        OneCategoryStatTypes counters;
        if (!VCCB_FillMeasReportStruct(STAT_NR_TARGET_CELL_MR, reportType, reportPurpose, counters))
        {
            return;
        }
        VCCB_UpdateMRQuantityCounters(ptCi, STAT_NR_TARGET_CELL_MR, counters, measItems, nci);
    }
}

/****************************************************************************
 * @brief           This function is in charge of processing MR's Thresholds (RSRP, RSRQ, SINR) for Inter Rat Target
 *Cell.
 *
 * @param[out]      ptCi : pointer of callInfo_type
 * @param[in]       reportType : Report type
 * @param[in]       reportPurpose : Report purpose
 ****************************************************************************/
void VCCB_StatInterRatTargetCellResults(
    callInfo_type* ptCi, const enumMeasurementReportType reportType, const uint8_t reportPurpose)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    int16_t status = GOOD;
    uint16_t idx = 0;
    uint64_t eci = 0;

    measResultNeighCellsEUTRA_type* ptMeasResultList2EUTRA =
        &THREAD_INFO->call[ptCi->myThreadId].buf.measResultListEutraRx;

    for (idx = 0; idx < MIN(ptMeasResultList2EUTRA->numReportCell, MAX_NUM_CELL_REPORT); idx++)
    {
        measResultEUTRA_type* ptRes = &ptMeasResultList2EUTRA->measResult[idx];

        status = VLIB_GetNbrEnbEutraCellIdByPciAndFreq(ptCi, ptMeasResultList2EUTRA->earfcnDl, ptRes->pci, &eci);
        if (status == ERROR)
        {
            continue;
        }

        MeasItems measItems{};
        measItems.AggregateEutraMeasItems(*ptRes);

        OneCategoryStatTypes counters;
        if (!VCCB_FillMeasReportStruct(STAT_INTER_RAT_TARGET_CELL_MR, reportType, reportPurpose, counters))
        {
            return;
        }
        VCCB_UpdateMRQuantityCounters(ptCi, STAT_INTER_RAT_TARGET_CELL_MR, counters, measItems, eci);
    }
}

void VCCB_CountMeasReportEvents(
    callInfo_type* ptCi, const enumMeasurementReportType reportType, const uint32_t frequency)
{
    switch (reportType)
    {
        case measReport_A1:
            MACRO_STAT_PMCC(STAT_MEAS_REPORT_DU_ID, MrEventA1Count, ptCi, frequency, 0, 0, 0, 0);
            break;
        case measReport_A2:
            MACRO_STAT_PMCC(STAT_MEAS_REPORT_DU_ID, MrEventA2Count, ptCi, frequency, 0, 0, 0, 0);
            break;
        case measReport_A3:
            MACRO_STAT_PMCC(STAT_MEAS_REPORT_DU_ID, MrEventA3Count, ptCi, frequency, 0, 0, 0, 0);
            break;
        case measReport_A4:
            MACRO_STAT_PMCC(STAT_MEAS_REPORT_DU_ID, MrEventA4Count, ptCi, frequency, 0, 0, 0, 0);
            break;
        case measReport_A5:
            MACRO_STAT_PMCC(STAT_MEAS_REPORT_DU_ID, MrEventA5Count, ptCi, frequency, 0, 0, 0, 0);
            break;
        default:
            break;
    }
}

/****************************************************************************
 * @brief           Updates statistics for measurement report thresholds for both source and target cells.
 *                  This function processes source cell statistics and handles neighbor cell statistics
 *                  for both NR and EUTRA target cells based on the measurement results.
 *
 * @param[in,out]   rCi : Reference to callInfo_type structure
 * @param[in]       reportType : Measurement report type
 * @param[in]       reportPurpose : Purpose of the measurement report
 * @param[in]       rSelectMeasObj : Reference to measurement object configuration
 * @param[in]       pMeasResult : Pointer to measurement results containing neighbor cell information
 ****************************************************************************/
void VCCB_UpdateStatsForMeasReportThresholdSourceAndTargetCell(callInfo_type& rCi,
    const enumMeasurementReportType reportType, const uint8_t reportPurpose,
    const measurementObjectUe_type& rSelectMeasObj, reportConfigurationInstalledUe_type& rSelectRptCfg,
    NRRRC_MeasResults* pMeasResult)
{
    VALID_E_POINT_CHECK_VOID(pMeasResult);
    VCCB_StatSourceCellResults(&rCi, reportType, reportPurpose, rSelectMeasObj);

    if (pMeasResult->bit_mask & NRRRC_measResultNeighCells_present)
    {
        switch (pMeasResult->measResultNeighCells.choice)
        {
            case NRRRC_measResultListNR_chosen:
                VCCB_StatNrTargetCellResults(
                    &rCi, reportType, reportPurpose, static_cast<enumRSType>(rSelectRptCfg.conf.rsType));
                break;
            case NRRRC_measResultListEUTRA_chosen:
                VCCB_StatInterRatTargetCellResults(&rCi, reportType, reportPurpose);
                break;
            default:
                break;
        }
    }
}

void VCCB_UpdateMRQuantityServiceTypeCounters(callInfo_type* ptCi, const int mFamily, const OneCategoryStatTypes& stats,
    MeasItems& measItems, const uint32_t usedFreq)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    std::set<uint32_t> serviceTypelist;

    int16_t status = FnVCCB_GetCallServiceType(ptCi, serviceTypelist);
    if (status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "%s FnVCCB_GetCallServiceType ERROR(%d)\n", __func__, status);
        return;
    }

    // No Service type
    if (serviceTypelist.empty())
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "%s Empty service type list - counters not updated (mFamily=%d)\n", __func__, mFamily);
        return;
    }

    for (const auto& serviceType : serviceTypelist)
    {
        VCCB_UpdateMRQuantityCounters(ptCi, mFamily, stats, measItems, usedFreq, serviceType);
    }
}

void VCCB_UpdateMRQuantitySpidCounters(callInfo_type* ptCi, const int mFamily, const OneCategoryStatTypes& stats,
    MeasItems& measItems, const uint32_t usedFreq)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint16_t SPID = SPID_0;
    const bool isSpidStatConfigured = FnVCCB_setSpidCounterIndex(ptCi, SPID);

    // No SPID configured
    if (!isSpidStatConfigured)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "%s No SPID configured - counters not updated (mFamily=%d)\n", __func__, mFamily);
        return;
    }

    VCCB_UpdateMRQuantityCounters(ptCi, mFamily, stats, measItems, usedFreq, SPID);
}
}  // namespace

// INTRA_NR_ANR_24A FR760
uint8_t FnVCCB_GetTargetFreqTypeForCgiReportStat(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, NCGI_REPORT_FREQ_FREQ_TYPE_END);

    uint8_t mGap = VCCB_IsMeasGapConfigSet(ptCi); 

    if (ptCi->anrInfo.ratType == eutraType) // 26A STAT_ECGI_REPORT_ANR
    {                       
        return mGap ? EUTRA_MEASUREMENT_WITH_GAP : EUTRA_MEASUREMENT_WO_GAP;
    }                                       

    uint8_t isFr1 = (IS_FR1(ptCi->anrInfo.freq)) ? TRUE : FALSE;

    if (isFr1)              
    {                               
        return mGap ? (uint8_t)NCGI_REPORT_FREQ_FR1_WITH_MGAP : (uint8_t)NCGI_REPORT_FREQ_FR1_WITHOUT_MGAP;
    }                                               
    else                        
    {                                   
        return mGap ? (uint8_t)NCGI_REPORT_FREQ_FR2_WITH_MGAP : (uint8_t)NCGI_REPORT_FREQ_FR2_WITHOUT_MGAP;
    }                                                   
}

/****************************************************************************
 * @brief           New implementation for collecting measurement report statistics using the updated counter system.
 *                  This function processes measurement reports and updates statistics using the MEAS_QUANTITY_COUNTERS
 *                  lookup table. It handles both threshold statistics and quantity counters for different report types.
 *
 * @param[in,out]   ptCi : Pointer to callInfo_type structure
 * @param[in]       pMeasResult : Pointer to measurement results
 * @param[in]       pSelectRptCfg : Pointer to report configuration
 * @param[in]       pSelectMeasObj : Pointer to measurement object configuration
 ****************************************************************************/
void VCCB_CollectMeasReportStatistics(callInfo_type* ptCi, NRRRC_MeasResults* pMeasResult,
    reportConfigurationInstalledUe_type* pSelectRptCfg, measurementObjectUe_type* pSelectMeasObj)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pMeasResult);
    VALID_E_POINT_CHECK_VOID(pSelectRptCfg);
    VALID_E_POINT_CHECK_VOID(pSelectMeasObj);

    const enumMeasurementReportType reportType = static_cast<enumMeasurementReportType>(pSelectRptCfg->conf.reportType);
    const uint8_t reportPurpose = pSelectRptCfg->conf.reportPurpose;
    auto frequency = VCCB_GetMeasObjectFrequency(*pSelectMeasObj, reportType);
    if (frequency.has_value() == false)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "%s Couldn't find meas object frequency!\n", __func__);
        return;
    }
    const uint32_t usedFreq = frequency.value();

    if (FOO.VF_NRMeasurement_MeasReportThresholdStats)
    {
        VCCB_UpdateStatsForMeasReportThresholdSourceAndTargetCell(
            *ptCi, reportType, reportPurpose, *pSelectMeasObj, *pSelectRptCfg, pMeasResult);
    }

    VCCB_CountMeasReportEvents(ptCi, reportType, usedFreq);

    MeasItems measItems{};
    if (VCCB_GetMeasItemsForCurrentReportConfig(*ptCi, reportType, usedFreq, measItems) == false)
    {
        return;
    }

    for (size_t i = 0; i < VCCB_ARRAY_COUNT(MEAS_QUANTITY_COUNTERS); i++)
    {
        const QuantityCounter& counter = MEAS_QUANTITY_COUNTERS[i];
        if (counter.reportType != reportType || counter.reportPurpose != reportPurpose)
        {
            continue;
        }
        if (counter.checkCallType == nullptr)
        {
            continue;
        }
        if (counter.checkCallType(ptCi) == false)
        {
            continue;
        }

        if (VCCB_IsFamilyServiceType(counter.mFamily))  // Fill ServiceType_SA Indexes
        {
            VCCB_UpdateMRQuantityServiceTypeCounters(ptCi, counter.mFamily, counter.stats, measItems, usedFreq);
        }
        else if (VCCB_IsFamilySPIDIncludingInvalid(counter.mFamily))
        {
            VCCB_UpdateMRQuantitySpidCounters(ptCi, counter.mFamily, counter.stats, measItems, usedFreq);
        }
        else
        {
            VCCB_UpdateMRQuantityCounters(ptCi, counter.mFamily, counter.stats, measItems, usedFreq);
        }
    }
}
