#include "FeatPowerClass.hpp"
#include "ComLibUtility.h"
#include "FeatCallInfo.h"
#include "FeatMeasurements.hpp"
#include "StateCa.h"
#include "FeatCa.hpp"
#include "ComInline.h"
#include "VccbStruct.h"
#include "VccbStructCppInterface.hpp"

namespace
{

/****************************************************************************
 * @brief          This struct represents measurement object data needed for Power Class processing
 ****************************************************************************/
typedef struct
{
    enumMeasRatType ratType;
    // union with eutra will be added if there is at least one member in eutra
    struct
    {
        uint32_t ssbFrequency;
        uint16_t freqBandIndicatorNR;
        enumPowerClass2UeSupportType pc2UeSupport;
        enumPowerClass1dot5UeSupport_type pc1dot5UeSupport;
        enumPowerClass1UeSupportType pc1UeSupport;
        enumFr1PowerClass1UeSupportType fr1Pc1UeSupport;
    } nr;
} measObjectPowerClassInfo_type;

measObjectPowerClassInfo_type FnVCCB_CreateNRMeasObjectInfo(const minimalMeasObjectNRUe_type &rMO)
{
    AUTO_TRACE_FUNC;

    measObjectPowerClassInfo_type mo{};
    mo.ratType = measRatNr;
    mo.nr.ssbFrequency = rMO.ssbFrequency;
    mo.nr.freqBandIndicatorNR = rMO.freqBandIndicatorNR;
    mo.nr.pc2UeSupport = static_cast<enumPowerClass2UeSupportType>(rMO.pc2UeSupport);
    mo.nr.pc1dot5UeSupport = static_cast<enumPowerClass1dot5UeSupport_type>(rMO.pc1dot5UeSupport);
    mo.nr.pc1UeSupport = static_cast<enumPowerClass1UeSupportType>(rMO.pc1UeSupport);
    mo.nr.fr1Pc1UeSupport = static_cast<enumFr1PowerClass1UeSupportType>(rMO.fr1Pc1UeSupport);
    return mo;
}

measObjectPowerClassInfo_type FnVCCB_CreateMeasObjectInfoFromCandidate(const minimalMeasObjectConfUe_type &rMO)
{
    AUTO_TRACE_FUNC;

    if (measRatNr == rMO.ratType)
    {
        return FnVCCB_CreateNRMeasObjectInfo(rMO.rat.nr);
    }
    measObjectPowerClassInfo_type mo{};
    mo.ratType = static_cast<enumMeasRatType>(rMO.ratType);
    return mo;
}

measObjectPowerClassInfo_type FnVCCB_CreateMeasObjectInfoFromInstalled(const measurementObjectConfUe_type &rMO)
{
    AUTO_TRACE_FUNC;

    if (measRatNr == rMO.ratType)
    {
        return FnVCCB_CreateNRMeasObjectInfo(rMO.rat.nr.minimal);
    }
    measObjectPowerClassInfo_type mo{};
    mo.ratType = static_cast<enumMeasRatType>(rMO.ratType);
    return mo;
}

/****************************************************************************
 * @brief          Checks if UE Supports PowerClass given as an argument for a specific NR Band.
 * @param[in]      rCi        : Pointer to call configuration. / const callInfo_type &rCi
 * @param[in]      bandNR     : bandNR to be checked
 * @param[in]      pc         : specific PowerClass
 * @return         status     : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfUESupportPowerClassX(const callInfo_type &rCi, uint16_t bandNR, enumUePowerClass_type pc)
{
    AUTO_TRACE_FUNC;
    uint16_t bandNRidx = VLIB_GetNrBandIndex(rCi, bandNR);

    if (MAX_NUM_UECAPA_NR_BANDS <= bandNRidx)
    {
        return ERROR;
    }

    if (rCi.ueInfo.ueCapa.nr.rf.supportedBandListNR[bandNRidx].ue_PowerClass == pc)
    {
        return GOOD;
    }

    return ERROR;
}

/****************************************************************************
 * @brief          Checks if UE Supports PowerClassV1610 given as an argument for a specific NR Band.
 * @param[in]      rCi        : Pointer to call configuration. / const callInfo_type &rCi
 * @param[in]      bandNR     : bandNR to be checked
 * @param[in]      pc         : specific PowerClassV1610
 * @return         status     : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfUESupportPowerClassX_v1610(
    const callInfo_type &rCi, uint16_t bandNR, enumUePowerClass_v1610_type pc)
{
    AUTO_TRACE_FUNC;
    uint16_t bandNRidx = VLIB_GetNrBandIndex(rCi, bandNR);

    if (MAX_NUM_UECAPA_NR_BANDS <= bandNRidx)
    {
        return ERROR;
    }

    if (rCi.ueInfo.ueCapa.nr.rf.supportedBandListNR[bandNRidx].ue_PowerClass_v1610 == pc)
    {
        return GOOD;
    }

    return ERROR;
}

bool VCCB_CanPc1BeAppliedToPCellFr1(const callInfo_type &rCi, const measurementObjectNRBaseDb_type &rServObj)
{
    AUTO_TRACE_FUNC;

    const bool isPC1SupportedForFr1 = (Fr1PowerClass1UeSupport_Usage == rServObj.fr1Pc1UeSupport);
    if (IS_FR2(rServObj.ssbFrequency) && isPC1SupportedForFr1)
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "Serving measurement object is FR2 but FR1 PC1 support is enabled!\n");
        return false;
    }
 
    uint16_t intraFreqBand = VCCB_GetMoNrBandForUe(&rCi, &rServObj);
    if (!isPC1SupportedForFr1 || (0 == intraFreqBand) ||
        (ERROR == VCCB_CheckIfUESupportPowerClassX(rCi, intraFreqBand, UePowerClass_Pc1)))
    {
        return false;
    }
 
    return true;
}
 
bool VCCB_CanPc1BeAppliedToMeasObjectFr1(const callInfo_type &rCi, const measObjectPowerClassInfo_type &rMoInfo)
{
    AUTO_TRACE_FUNC;
 
    if (measRatNr != rMoInfo.ratType)
    {
        return false;
    }

    const bool isPC1SupportedForFr1 = (Fr1PowerClass1UeSupport_Usage == rMoInfo.nr.fr1Pc1UeSupport);
    if (IS_FR2(rMoInfo.nr.ssbFrequency) && isPC1SupportedForFr1)
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "Measurement object is FR2 but FR1 PC1 support is enabled!\n");
        return false;
    }
 
    if (!isPC1SupportedForFr1 ||
        (ERROR == VCCB_CheckIfUESupportPowerClassX(rCi, rMoInfo.nr.freqBandIndicatorNR, UePowerClass_Pc1)))
    {
        return false;
    }
 
    return true;
}

/****************************************************************************
 * @brief           Check if Power Class 1.5 Delta thresholds for measurement object can be applied
 *
 * @param[in]       rCi           : Pointer to call configuration. / const callInfo_type &rCi
 * @param[in]       finder        : initialized finder object for matching report config and measurement object  / const
 *VCCB_RptCfgAndMeasObjDbFinder&
 ****************************************************************************/
bool VCCB_CanPc1dot5BeAppliedToPCell(const callInfo_type &rCi, const measurementObjectNRBaseDb_type &rServObj)
{
    AUTO_TRACE_FUNC;

    const bool isPC1dot5SupportedForFr1 = (PowerClass1dot5UeSupport_fr1Usage == rServObj.pc1dot5UeSupport);
    if (IS_FR2(rServObj.ssbFrequency) && isPC1dot5SupportedForFr1)
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "Serving measurement object is FR2 but PC1.5 support is set to FR1!\n");
        return false;
    }

    uint16_t intraFreqBand = VCCB_GetMoNrBandForUe(&rCi, &rServObj);
    if (!isPC1dot5SupportedForFr1 || (0 == intraFreqBand) ||
        (ERROR == VCCB_CheckIfUESupportPowerClassX_v1610(rCi, intraFreqBand, UePowerClass_Pc1dot5)))
    {
        return false;
    }

    return true;
}

bool VCCB_CanPc1dot5BeAppliedToMeasObject(const callInfo_type &rCi, const measObjectPowerClassInfo_type &rMoInfo)
{
    AUTO_TRACE_FUNC;

    if (measRatNr != rMoInfo.ratType)
    {
        return false;
    }

    const bool isPC1dot5SupportedForFr1 =
        (PowerClass1dot5UeSupport_fr1Usage == rMoInfo.nr.pc1dot5UeSupport);
    if (IS_FR2(rMoInfo.nr.ssbFrequency) && isPC1dot5SupportedForFr1)
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "Measurement object is FR2 but PC1.5 support is set to FR1!\n");
        return false;
    }

    if (!isPC1dot5SupportedForFr1 || (ERROR == VCCB_CheckIfUESupportPowerClassX_v1610(
                                                   rCi, rMoInfo.nr.freqBandIndicatorNR, UePowerClass_Pc1dot5)))
    {
        return false;
    }

    return true;
}

bool VCCB_CanPc2BeAppliedToPCell(const callInfo_type &rCi, const measurementObjectNRBaseDb_type &rServObj)
{
    AUTO_TRACE_FUNC;

    const bool isPC2SupportedForFr1 = (PowerClass2UeSupport_fr1Usage == rServObj.pc2UeSupport);
    if (IS_FR2(rServObj.ssbFrequency) && isPC2SupportedForFr1)
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "Serving measurement object is FR2 but PC2 support is set to FR1!\n");
        return false;
    }

    uint16_t intraFreqBand = VCCB_GetMoNrBandForUe(&rCi, &rServObj);
    return isPC2SupportedForFr1 && (0 != intraFreqBand) &&
           (ERROR != VCCB_CheckIfUESupportPowerClassX(rCi, intraFreqBand, UePowerClass_Pc2));
}

bool VCCB_CanPc2BeAppliedToMeasObject(const callInfo_type &rCi, const measObjectPowerClassInfo_type &rMoInfo)
{
    AUTO_TRACE_FUNC;

    if (measRatNr != rMoInfo.ratType)
    {
        return false;
    }

    const bool isPC2SupportedForFr1 = (PowerClass2UeSupport_fr1Usage == rMoInfo.nr.pc2UeSupport);
    if (IS_FR2(rMoInfo.nr.ssbFrequency) && isPC2SupportedForFr1)
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "Measurement object is FR2 but PC2 support is set to FR1!\n");
        return false;
    }

    return (isPC2SupportedForFr1 &&
            ERROR != VCCB_CheckIfUESupportPowerClassX(rCi, rMoInfo.nr.freqBandIndicatorNR, UePowerClass_Pc2));
}

/****************************************************************************
 * @brief           Get which Power Class deltas are applicable for FR1.
 *
 * @param[in]       rCi          : Pointer to call configuration. / const callInfo_type &rCi
 * @param[in]       rMoInfo      : reference to meas object info
 * @param[in]       cellNum      : served cell num or target cell num
 ****************************************************************************/
PowerClassDeltasApplicabilityFr1_type VCCB_GetWhichPcDeltasAreApplicableFr1(
    const callInfo_type &rCi, const measObjectPowerClassInfo_type &rMoInfo, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;

    PowerClassDeltasApplicabilityFr1_type result;
    memset(&result, 0, sizeof(result));

    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, result);

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    const uint16_t intraFreqMeasObjIdx = INTRAFREQ_OBJECT_IDX;
    const measurementObjectNRBaseDb_type &rServObj =
        pCell->measurementsData.measurementObjectsNRDb[intraFreqMeasObjIdx].base;

    result.canPc1BeAppliedToPCell = VCCB_CanPc1BeAppliedToPCellFr1(rCi, rServObj);
    result.canPc1BeAppliedToMeasObject = VCCB_CanPc1BeAppliedToMeasObjectFr1(rCi, rMoInfo);
    result.canPc1dot5BeAppliedToPCell = VCCB_CanPc1dot5BeAppliedToPCell(rCi, rServObj);
    result.canPc1dot5BeAppliedToMeasObject = VCCB_CanPc1dot5BeAppliedToMeasObject(rCi, rMoInfo);
    // If PC1 can be applied, UE is PC1 capable, so it cannot be PC2 for the same band - skip PC2 check
    result.canPc2BeAppliedToPCell = !result.canPc1BeAppliedToPCell && VCCB_CanPc2BeAppliedToPCell(rCi, rServObj);
    result.canPc2BeAppliedToMeasObject = !result.canPc1BeAppliedToMeasObject && VCCB_CanPc2BeAppliedToMeasObject(rCi, rMoInfo);

    return result;
}

/****************************************************************************
 * @brief           Get which Power Class deltas are applicable for FR2.
 *
 * @param[in]       rCi          : Pointer to call configuration. / const callInfo_type &rCi
 * @param[in]       rMoInfo      : reference to meas object info
 * @param[in]       cellNum      : served cell num or target cell num
 ****************************************************************************/
PowerClassDeltasApplicabilityFr2_type VCCB_GetWhichPcDeltasAreApplicableFr2(
    const callInfo_type &rCi, const measObjectPowerClassInfo_type &rMoInfo, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;

    PowerClassDeltasApplicabilityFr2_type result;
    memset(&result, 0, sizeof(result));

    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, result);

    uint16_t intraFreqBand = 0;
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    const uint16_t intraFreqMeasObjIdx = INTRAFREQ_OBJECT_IDX;
    measurementObjectNRBaseDb_type *pServObj =
        &pCell->measurementsData.measurementObjectsNRDb[intraFreqMeasObjIdx].base;

    result.canPc1BeAppliedToPCell = true;
    const bool isPC1SupportedForFr2 = (PowerClass1UeSupport_fr2Usage == pServObj->pc1UeSupport);
    if (IS_FR1(pServObj->ssbFrequency) && isPC1SupportedForFr2)
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "Serving measurement object is FR1 but FR2 PC1 support is enabled!\n");
        result.canPc1BeAppliedToPCell = false;
    }
    else
    {
        intraFreqBand = VCCB_GetMoNrBandForUe(&rCi, pServObj);
        if (!isPC1SupportedForFr2 || (intraFreqBand == 0) ||
            (ERROR == VCCB_CheckIfUESupportPowerClassX(rCi, intraFreqBand, UePowerClass_Pc1)))
        {
            result.canPc1BeAppliedToPCell = false;
        }
    }

    result.canPc1BeAppliedToMeasObject = true;

    if (measRatNr != rMoInfo.ratType)
    {
        result.canPc1BeAppliedToMeasObject = false;
        return result;
    }

    const bool isMoPC1SupportedForFr2 = (PowerClass1UeSupport_fr2Usage == rMoInfo.nr.pc1UeSupport);
    if (IS_FR1(rMoInfo.nr.ssbFrequency) && isMoPC1SupportedForFr2)
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "Measurement object is FR1 but FR2 PC1 support is enabled!\n");
        result.canPc1BeAppliedToMeasObject = false;
    }
    else
    {
        if (!isMoPC1SupportedForFr2 ||
            (ERROR == VCCB_CheckIfUESupportPowerClassX(rCi, rMoInfo.nr.freqBandIndicatorNR, UePowerClass_Pc1)))
        {
            result.canPc1BeAppliedToMeasObject = false;
        }
    }

    return result;
}

bool VCCB_CheckIfPCDeltasCanBeAppliedToReportConfig(const reportConfigurationConfUe_type &rRC)
{
    AUTO_TRACE_FUNC;

    // FGR-SO1101:FR470
    if ((measReport_A2 == rRC.reportType && a2Purpose_mdt == rRC.reportPurpose) ||
        (measReport_A2 == rRC.reportType && a2Purpose_triggerPeriodicMdt == rRC.reportPurpose))
    {
        if (VCCB_FLAG_OFF == CFG->globalTraceInfo.a2DeltaThrOnOff)
        {
            return false;
        }
    }
    return true;
}

optionalDelta_type setDelta(int8_t delta)
{
    AUTO_TRACE_FUNC;

    return optionalDelta_type{
        .usage = true,
        .delta = delta,
    };
}

void fillDeltaPCxRelatedToPCell(const reportConfigurationConfUe_type &reportConfig,
    const deltaThInfo_type &pcXDeltaThresholds, optionalDeltaPerTrigger_type &optionalDeltaPerTrigger)
{
    AUTO_TRACE_FUNC;

    const auto &currentEvent_NR = reportConfig.reportConfiguration.eventBased.event;
    const auto &currentEvent_InterRAT = reportConfig.reportConfiguration.eventInterRat.event;

    switch (reportConfig.reportType)
    {
        case measReport_A5:
        {
            switch (currentEvent_NR.A5.a5_Thresholds.quantity)
            {
                case choice_rsrp:
                    optionalDeltaPerTrigger.trigger1Delta = setDelta(pcXDeltaThresholds.a5Th1_DeltaRSRP);
                    break;
                case choice_rsrq:
                    optionalDeltaPerTrigger.trigger1Delta = setDelta(pcXDeltaThresholds.a5Th1_DeltaRSRQ);
                    break;
                default:
                    break;
            }
            break;
        }
        case measReport_B2Eutra:
        {
            switch (currentEvent_InterRAT.B2Eutra.b2_thresholds.quantity)
            {
                case choice_rsrp:
                    optionalDeltaPerTrigger.trigger1Delta = setDelta(pcXDeltaThresholds.b2Th1_DeltaRSRP);
                    break;
                case choice_rsrq:
                    optionalDeltaPerTrigger.trigger1Delta = setDelta(pcXDeltaThresholds.b2Th1_DeltaRSRQ);
                    break;
                default:
                    break;
            }
            break;
        }
        default:
            break;
    }
}

void fillDeltaPCxRelatedToMo(const reportConfigurationConfUe_type &reportConfig,
    const deltaThInfo_type &pcXDeltaThresholds, optionalDeltaPerTrigger_type &optionalDeltaPerTrigger)
{
    AUTO_TRACE_FUNC;

    auto &currentEvent_NR = reportConfig.reportConfiguration.eventBased.event;
    switch (reportConfig.reportType)
    {
        case measReport_A1:
        {
            switch (currentEvent_NR.A1.a1_Threshold.quantity)
            {
                case choice_rsrp:
                    optionalDeltaPerTrigger.trigger1Delta = setDelta(pcXDeltaThresholds.a1ThDeltaRSRP);
                    break;
                case choice_rsrq:
                    optionalDeltaPerTrigger.trigger1Delta = setDelta(pcXDeltaThresholds.a1ThDeltaRSRQ);
                    break;
                default:
                    break;
            }
            break;
        }
        case measReport_A2:
        {
            switch (currentEvent_NR.A2.a2_Threshold.quantity)
            {
                case choice_rsrp:
                    optionalDeltaPerTrigger.trigger1Delta = setDelta(pcXDeltaThresholds.a2ThDeltaRSRP);
                    break;
                case choice_rsrq:
                    optionalDeltaPerTrigger.trigger1Delta = setDelta(pcXDeltaThresholds.a2ThDeltaRSRQ);
                    break;
                default:
                    break;
            }
            break;
        }
        case measReport_A3:
        {
            switch (currentEvent_NR.A3.a3_Offset.quantity)
            {
                case choice_rsrp:
                    optionalDeltaPerTrigger.trigger1Delta = setDelta(pcXDeltaThresholds.a3OffsetDeltaRSRP);
                    break;
                case choice_rsrq:
                    optionalDeltaPerTrigger.trigger1Delta = setDelta(pcXDeltaThresholds.a3OffsetDeltaRSRQ);
                    break;
                default:
                    break;
            }
            break;
        }
        case measReport_A4:
        {
            switch (currentEvent_NR.A4.a4_Threshold.quantity)
            {
                case choice_rsrp:
                    optionalDeltaPerTrigger.trigger1Delta = setDelta(pcXDeltaThresholds.a4ThDeltaRSRP);
                    break;
                case choice_rsrq:
                    optionalDeltaPerTrigger.trigger1Delta = setDelta(pcXDeltaThresholds.a4ThDeltaRSRQ);
                    break;
                default:
                    break;
            }
            break;
        }
        case measReport_A5:
        {
            switch (currentEvent_NR.A5.a5_Thresholds.quantity)
            {
                case choice_rsrp:
                    optionalDeltaPerTrigger.trigger2Delta = setDelta(pcXDeltaThresholds.a5Th2_DeltaRSRP);
                    break;
                case choice_rsrq:
                    optionalDeltaPerTrigger.trigger2Delta = setDelta(pcXDeltaThresholds.a5Th2_DeltaRSRQ);
                    break;
                default:
                    break;
            }
            break;
        }
        default:
            break;
    }
}

optionalDeltaPerTrigger_type getDeltaPCxPerEvent(const reportConfigurationConfUe_type &reportConfig,
    const deltaThInfo_type &pcXDeltaThresholds, bool canBeAppliedToPcell, bool canBeAppliedToMo)
{
    AUTO_TRACE_FUNC;

    optionalDeltaPerTrigger_type result{};
    if (canBeAppliedToPcell)
    {
        fillDeltaPCxRelatedToPCell(reportConfig, pcXDeltaThresholds, result);
    }
    if (canBeAppliedToMo)
    {
        fillDeltaPCxRelatedToMo(reportConfig, pcXDeltaThresholds, result);
    }
    return result;
}

optionalDelta_type getPrioritizedDeltas(
    optionalDelta_type pc1Delta, optionalDelta_type pc15Delta, optionalDelta_type pc2Delta)
{
    AUTO_TRACE_FUNC;

    // pc1 deltas should be selected if both pc1 and pc1.5 deltas can be applied
    if (pc1Delta.usage)
    {
        return pc1Delta;
    }
    // pc1.5 deltas should be selected if both pc1.5 and pc2 deltas can be applied
    if (pc15Delta.usage)
    {
        return pc15Delta;
    }
    return pc2Delta;
}

optionalDeltaPerTrigger_type getDeltasBasedOnSelectedPowerClass(enumUeAllPowerClass_type selectedPowerClass,
    const optionalDeltaPerTrigger_type &pc1Deltas, const optionalDeltaPerTrigger_type &pc15Deltas,
    const optionalDeltaPerTrigger_type &pc2Deltas)
{
    AUTO_TRACE_FUNC;

    switch (selectedPowerClass)
    {
        case PowerClass_Pc1:
        {
            return pc1Deltas;
        }
        case PowerClass_Pc1dot5:
        {
            return pc15Deltas;
        }
        case PowerClass_Pc2:
        {
            return pc2Deltas;
        }
        default:
        {
            return optionalDeltaPerTrigger_type{};
        }
    }
}

optionalDeltaPerTrigger_type getDeltasForLegacyBehavior(enumUeAllPowerClass_type selectedPowerClass,
    enumMeasurementReportType reportType, const fr1PowerClassState_type &fr1PowerClassState)
{
    AUTO_TRACE_FUNC;

    if (fr1PowerClassState.isAssociatedWithPcellMeasObject)
    {
        return getDeltasBasedOnSelectedPowerClass(selectedPowerClass, fr1PowerClassState.savedDeltas.pc1SavedDelta,
            fr1PowerClassState.savedDeltas.pc15SavedDelta, fr1PowerClassState.savedDeltas.pc2SavedDelta);
    }

    optionalDeltaPerTrigger_type result{};
    const auto &pc1Deltas = fr1PowerClassState.savedDeltas.pc1SavedDelta;
    const auto &pc15Deltas = fr1PowerClassState.savedDeltas.pc15SavedDelta;
    const auto &pc2Deltas = fr1PowerClassState.savedDeltas.pc2SavedDelta;
    switch (reportType)
    {
        case measReport_A1:
        {
            result.trigger1Delta =
                getPrioritizedDeltas(pc1Deltas.trigger1Delta, pc15Deltas.trigger1Delta, pc2Deltas.trigger1Delta);
            break;
        }
        case measReport_A2:
        {
            result.trigger1Delta =
                getPrioritizedDeltas(pc1Deltas.trigger1Delta, pc15Deltas.trigger1Delta, pc2Deltas.trigger1Delta);
            break;
        }
        case measReport_A3:
        {
            result.trigger1Delta =
                getPrioritizedDeltas(pc1Deltas.trigger1Delta, pc15Deltas.trigger1Delta, pc2Deltas.trigger1Delta);
            break;
        }
        case measReport_A4:
        {
            result.trigger1Delta =
                getPrioritizedDeltas(pc1Deltas.trigger1Delta, pc15Deltas.trigger1Delta, pc2Deltas.trigger1Delta);
            break;
        }
        case measReport_A5:
        {
            result.trigger1Delta =
                getDeltasBasedOnSelectedPowerClass(selectedPowerClass, pc1Deltas, pc15Deltas, pc2Deltas).trigger1Delta;
            result.trigger2Delta =
                getPrioritizedDeltas(pc1Deltas.trigger2Delta, pc15Deltas.trigger2Delta, pc2Deltas.trigger2Delta);
            break;
        }
        case measReport_B2Eutra:
        {
            result.trigger1Delta =
                getDeltasBasedOnSelectedPowerClass(selectedPowerClass, pc1Deltas, pc15Deltas, pc2Deltas).trigger1Delta;
            break;
        }
        default:
        {
            break;
        }
    }
    return result;
}

void applyPowerClassDelta(callInfo_type *ptCi, reportConfigurationConfUe_type &reportConfig,
    const optionalDeltaPerTrigger_type &optionalDeltaPerTrigger)
{
    AUTO_TRACE_FUNC;

    if (!optionalDeltaPerTrigger.trigger1Delta.usage && !optionalDeltaPerTrigger.trigger2Delta.usage)
    {
        return;
    }

    VCCB_PRINT_LOG_POWER_CLASS(ptCi, "Apply delta for reportConfig(type=%d,purpose=%d)\n", reportConfig.reportType,
        reportConfig.reportPurpose);

    auto &currentEvent_NR = reportConfig.reportConfiguration.eventBased.event;
    auto &currentEvent_InterRAT = reportConfig.reportConfiguration.eventInterRat.event;

    switch (reportConfig.reportType)
    {
        case measReport_A1:
        {
            if (optionalDeltaPerTrigger.trigger1Delta.usage)
            {
                VCCB_ModifySelectedThresholds_ApplyDelta(
                    ptCi, currentEvent_NR.A1.a1_Threshold.value, optionalDeltaPerTrigger.trigger1Delta.delta);
            }
            break;
        }
        case measReport_A2:
        {
            if (optionalDeltaPerTrigger.trigger1Delta.usage)
            {
                VCCB_ModifySelectedThresholds_ApplyDelta(
                    ptCi, currentEvent_NR.A2.a2_Threshold.value, optionalDeltaPerTrigger.trigger1Delta.delta);
            }
            break;
        }
        case measReport_A3:
        {
            if (optionalDeltaPerTrigger.trigger1Delta.usage)
            {
                VCCB_ModifySelectedOffset_ApplyDelta(
                    ptCi, currentEvent_NR.A3.a3_Offset.value, optionalDeltaPerTrigger.trigger1Delta.delta);
            }
            break;
        }
        case measReport_A4:
        {
            if (optionalDeltaPerTrigger.trigger1Delta.usage)
            {
                VCCB_ModifySelectedThresholds_ApplyDelta(
                    ptCi, currentEvent_NR.A4.a4_Threshold.value, optionalDeltaPerTrigger.trigger1Delta.delta);
            }
            break;
        }
        case measReport_A5:
        {
            if (optionalDeltaPerTrigger.trigger1Delta.usage)
            {
                VCCB_ModifySelectedThresholds_ApplyDelta(
                    ptCi, currentEvent_NR.A5.a5_Thresholds.th1_value, optionalDeltaPerTrigger.trigger1Delta.delta);
            }
            if (optionalDeltaPerTrigger.trigger2Delta.usage)
            {
                VCCB_ModifySelectedThresholds_ApplyDelta(
                    ptCi, currentEvent_NR.A5.a5_Thresholds.th2_value, optionalDeltaPerTrigger.trigger2Delta.delta);
            }
            break;
        }
        case measReport_B2Eutra:
        {
            if (optionalDeltaPerTrigger.trigger1Delta.usage)
            {
                VCCB_ModifySelectedThresholds_ApplyDelta(ptCi, currentEvent_InterRAT.B2Eutra.b2_thresholds.th1_value,
                    optionalDeltaPerTrigger.trigger1Delta.delta);
            }
            break;
        }
        default:
            break;
    }
}

bool isPost25ABehavior(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    if (((E_CALLTYPE_SA == rCi.callType) && VCCM_AnySCellSuccessfullyAdded(&rCi)) || (E_CALLTYPE_NSA == rCi.callType))
    {
        return true;
    }
    return false;
}

bool isOptionalDeltaEffective(const optionalDelta_type &rOptDelta)
{
    AUTO_TRACE_FUNC;
    return rOptDelta.usage == true && rOptDelta.delta != 0;
}

bool isOptionalDeltaPerTriggerEffective(const optionalDeltaPerTrigger_type &rOptDeltaPerTrigger)
{
    AUTO_TRACE_FUNC;

    return isOptionalDeltaEffective(rOptDeltaPerTrigger.trigger1Delta) ||
           isOptionalDeltaEffective(rOptDeltaPerTrigger.trigger2Delta);
}

void printFr1PCState(callInfo_type &rCi, const fr1PowerClassState_type &toPrint)
{
    VCCB_PRINT_LOG_POWER_CLASS(&rCi, "FR1 PC Delta State:\n");
    VCCB_PRINT_LOG_POWER_CLASS(&rCi, "- for PCell MO=%d\n", toPrint.isAssociatedWithPcellMeasObject);
    const optionalDeltaPerTrigger_type &pc1 = toPrint.savedDeltas.pc1SavedDelta;
    VCCB_PRINT_LOG_POWER_CLASS(&rCi, "- PC1   delta: trigger1=%3d, trigger2=%3d\n",
        (pc1.trigger1Delta.usage ? pc1.trigger1Delta.delta : 999),
        (pc1.trigger2Delta.usage ? pc1.trigger2Delta.delta : 999));
    const optionalDeltaPerTrigger_type &pc15 = toPrint.savedDeltas.pc15SavedDelta;
    VCCB_PRINT_LOG_POWER_CLASS(&rCi, "- PC1.5 delta: trigger1=%3d, trigger2=%3d\n",
        (pc15.trigger1Delta.usage ? pc15.trigger1Delta.delta : 999),
        (pc15.trigger2Delta.usage ? pc15.trigger2Delta.delta : 999));
    const optionalDeltaPerTrigger_type &pc2 = toPrint.savedDeltas.pc2SavedDelta;
    VCCB_PRINT_LOG_POWER_CLASS(&rCi, "- PC2   delta: trigger1=%3d, trigger2=%3d\n",
        (pc2.trigger1Delta.usage ? pc2.trigger1Delta.delta : 999),
        (pc2.trigger2Delta.usage ? pc2.trigger2Delta.delta : 999));
}

void printPCDeltasApplicability(callInfo_type &rCi, const PowerClassDeltasApplicability_type &toPrint)
{
    VCCB_PRINT_LOG_POWER_CLASS(&rCi, "Delta Applicability:\n");
    VCCB_PRINT_LOG_POWER_CLASS(&rCi, "- FR1 PC1  =(PCell=%d,MO=%d)\n", toPrint.fr1.canPc1BeAppliedToPCell,
        toPrint.fr1.canPc1BeAppliedToMeasObject);
    VCCB_PRINT_LOG_POWER_CLASS(&rCi, "- FR1 PC1.5=(PCell=%d,MO=%d) \n", toPrint.fr1.canPc1dot5BeAppliedToPCell,
        toPrint.fr1.canPc1dot5BeAppliedToMeasObject);
    VCCB_PRINT_LOG_POWER_CLASS(&rCi, "- FR1 PC2  =(PCell=%d,MO=%d)\n", toPrint.fr1.canPc2BeAppliedToPCell,
        toPrint.fr1.canPc2BeAppliedToMeasObject);
    VCCB_PRINT_LOG_POWER_CLASS(&rCi, "- FR2 PC1  =(PCell=%d,MO=%d)\n", toPrint.fr2.canPc1BeAppliedToPCell,
        toPrint.fr2.canPc1BeAppliedToMeasObject);
}

}  // namespace

/****************************************************************************
 * @brief           Function returns whether save deltas can cause report config to be modified
 *
 * @param[in]       rFr1PcSavedDeltas : Reference to FR1 Power Class save deltas.
                    / const fr1PowerClassSavedDeltas_type &
 * @return          false - if it is not possible that saved deltas can modify report config
                    true  - if it is possible (depends on other conditions) that saved deltas can modify report config
 ****************************************************************************/
bool VCCB_AreFr1PowerClassSavedDeltasEffective(const fr1PowerClassSavedDeltas_type &rFr1PcSavedDeltas)
{
    AUTO_TRACE_FUNC;

    return isOptionalDeltaPerTriggerEffective(rFr1PcSavedDeltas.pc1SavedDelta) ||
           isOptionalDeltaPerTriggerEffective(rFr1PcSavedDeltas.pc15SavedDelta) ||
           isOptionalDeltaPerTriggerEffective(rFr1PcSavedDeltas.pc2SavedDelta);
}

/****************************************************************************
 * @brief           Function returns whether two FR1 Power Class states
 *                  will for sure modify report config in the same way.
 *                  If there is a chance that the state can modify report config
 *                  in a different way then function returns false.
 *
 * @param[in]       lhs : first FR1 Power Class state / const fr1PowerClassState_type &
 * @param[in]       rhs : second FR1 Power Class state / const fr1PowerClassState_type &
 * @return          bool
 ****************************************************************************/
bool VCCB_WillFr1PCStateModifyRCInTheSameWay(const fr1PowerClassState_type &lhs, const fr1PowerClassState_type &rhs)
{
    AUTO_TRACE_FUNC;

    if (!VCCB_AreFr1PowerClassSavedDeltasEffective(lhs.savedDeltas) &&
        !VCCB_AreFr1PowerClassSavedDeltasEffective(rhs.savedDeltas))
    {
        return true;
    }
    if (lhs.savedDeltas != rhs.savedDeltas)
    {
        return false;
    }
    return lhs.isAssociatedWithPcellMeasObject == rhs.isAssociatedWithPcellMeasObject;
}

/****************************************************************************
 * @brief           Get which Power Class deltas are applicable.
 *
 * @param[in]       rCi           : Pointer to call configuration. / const callInfo_type &rCi
 * @param[in]       rMO           : reference to meas object
 * @param[in]       rRC           : reference to ue report config
 * @param[in]       cellNum       : served cell num or target cell num
 * @return          structure of power class applicability per FR
 ****************************************************************************/
static PowerClassDeltasApplicability_type VCCB_GetWhichPcDeltasAreApplicable(callInfo_type &rCi,
    const measObjectPowerClassInfo_type &rMO, const reportConfigurationConfUe_type &rRC, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;

    PowerClassDeltasApplicability_type result;
    memset(&result, 0, sizeof(result));

    if (false == VCCB_CheckIfPCDeltasCanBeAppliedToReportConfig(rRC))
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "Power Class Deltas won't be applied as Report Config does not accept it.\n");
        return result;
    }

    // FR1
    if (!(IS_NEDC(&rCi)) && !(IS_NRDC_SN(&rCi)))
    {
        result.fr1 = VCCB_GetWhichPcDeltasAreApplicableFr1(rCi, rMO, cellNum);
    }

    // FR2
    if ((IS_ENDC(&rCi)) || (IS_NRDC_SN(&rCi)))
    {
        result.fr2 = VCCB_GetWhichPcDeltasAreApplicableFr2(rCi, rMO, cellNum);
    }

    printPCDeltasApplicability(rCi, result);

    return result;
}

/****************************************************************************
 * @brief           Get which Power Class deltas are applicable using meas object candidate.
 *                  This function should be used during measurement reconfiguration procedure
 *                  (VCCB_PrepareNewMeasConfig).
 ****************************************************************************/
PowerClassDeltasApplicability_type VCCB_GetWhichPcDeltasAreApplicableUsingMeasObjectCandidate(callInfo_type &rCi,
    const minimalMeasObjectConfUe_type &rMO, const reportConfigurationConfUe_type &rRC, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;

    // first, try NR meas object which is already added for installation
    if (measRatNr == rMO.ratType)
    {
        measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(rCi);
        measurementObjectUe_type *pUeObj = FnVCCB_FindNRMeasObjectInMeasProc(rMeasProc, rMO.rat.nr);
        if (nullptr != pUeObj)
        {
            return VCCB_GetWhichPcDeltasAreApplicable(
                rCi, FnVCCB_CreateNRMeasObjectInfo(pUeObj->conf.rat.nr.minimal), rRC, cellNum);
        }
    }
    // second, if not found use the candidate
    return VCCB_GetWhichPcDeltasAreApplicable(rCi, FnVCCB_CreateMeasObjectInfoFromCandidate(rMO), rRC, cellNum);
}

/****************************************************************************
 * @brief           Get which Power Class deltas are applicable using installed meas object.
 *                  This function should be used outside of measurement reconfiguration procedure 
 *                  (VCCB_PrepareNewMeasConfig).
 ****************************************************************************/
PowerClassDeltasApplicability_type VCCB_GetWhichPcDeltasAreApplicableUsingMeasObjectInstalled(callInfo_type &rCi,
    const measurementObjectConfUe_type &rMO, const reportConfigurationConfUe_type &rRC, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;

    return VCCB_GetWhichPcDeltasAreApplicable(rCi, FnVCCB_CreateMeasObjectInfoFromInstalled(rMO), rRC, cellNum);
}

/****************************************************************************
 * @brief           Handle Power Class deltas with regard to report config
 *                  FR1) save deltas and apply them later if all conditions are met.
 *                  It is necessary as checking if FR1 Power Class deltas can be applied requires response from DU.
 *                  FR2) apply deltas to report config trigger. They do not depend on response from DU.
 * @param[in]       ptCi          : Pointer to call configuration. / callInfo_type*
 * @param[in]       pReportConfig : Pointer to report config to be installed on UE / reportConfigurationConfUe_type *
 * @param[in]       rMoCandidate  : reference to meas object which can be installed on UE
 * @param[in]       cellNum       : served cell num or target cell num
 ****************************************************************************/
void VCCB_HandlePowerClassDeltas(callInfo_type *ptCi, reportConfigurationConfUe_type *pReportConfig,
    const minimalMeasObjectConfUe_type &rMoCandidate, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pReportConfig);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    const auto &cell = CELLINFO[cellNum];
    const auto applicability =
        VCCB_GetWhichPcDeltasAreApplicableUsingMeasObjectCandidate(*ptCi, rMoCandidate, *pReportConfig, cellNum);

    // FR1 - save deltas and apply them later if DU response meets criteria
    pReportConfig->fr1PCState.savedDeltas.pc1SavedDelta =
        getDeltaPCxPerEvent(*pReportConfig, cell.deltaThMeasConfig.fr1.deltaThPc1Info,
            applicability.fr1.canPc1BeAppliedToPCell, applicability.fr1.canPc1BeAppliedToMeasObject);
    pReportConfig->fr1PCState.savedDeltas.pc15SavedDelta =
        getDeltaPCxPerEvent(*pReportConfig, cell.deltaThMeasConfig.fr1.deltaThPc1dot5Info,
            applicability.fr1.canPc1dot5BeAppliedToPCell, applicability.fr1.canPc1dot5BeAppliedToMeasObject);
    pReportConfig->fr1PCState.savedDeltas.pc2SavedDelta =
        getDeltaPCxPerEvent(*pReportConfig, cell.deltaThMeasConfig.fr1.deltaThPc2Info,
            applicability.fr1.canPc2BeAppliedToPCell, applicability.fr1.canPc2BeAppliedToMeasObject);
    pReportConfig->fr1PCState.isAssociatedWithPcellMeasObject =
        ((rMoCandidate.ratType == measRatNr) && (cell.ssbArfcn == rMoCandidate.rat.nr.ssbFrequency));
    printFr1PCState(*ptCi, pReportConfig->fr1PCState);

    // FR2 - apply deltas right away, as they do not depend on DU response
    const auto pc1Deltas = getDeltaPCxPerEvent(*pReportConfig, cell.deltaThMeasConfig.fr2.deltaThPc1Info,
        applicability.fr2.canPc1BeAppliedToPCell, applicability.fr2.canPc1BeAppliedToMeasObject);
    VCCB_PRINT_LOG_POWER_CLASS(ptCi, "Try to apply FR2 deltas\n");
    applyPowerClassDelta(ptCi, *pReportConfig, pc1Deltas);
}

/****************************************************************************
 * @brief           If all FGR-CC4208 conditions are met apply FR1 Power Class deltas
 *                  based on saved deltas stored in fr1PowerClassSavedDeltas.
 *
 * @param[in]       ptCi          : Pointer to call configuration. / callInfo_type*
 ****************************************************************************/
void FnVCCB_ApplyFR1PowerClassDeltasIfAllConditionsMet(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    const bool isPost25A = isPost25ABehavior(*ptCi);

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(
                                rMeasProc.reportConfigurations.newItems, rMeasProc.reportConfigurations.numNewItems);
         ++i)
    {
        reportConfigurationNewUe_type &rcNew = rMeasProc.reportConfigurations.newItems[i];
        VCCB_PRINT_LOG_POWER_CLASS(ptCi, "Process FR1 delta for report config(id=%d,type=%d,purpose=%d)\n",
            rcNew.objectId, rcNew.conf.reportType, rcNew.conf.reportPurpose);

        reportConfigurationConfUe_type &rc = rcNew.conf;
        // Below is the optimization so that VLIB_GetSelectedPowerClass is not called if there is no need.
        // Only first call to VLIB_GetSelectedPowerClass can be expensive,
        // subsequent calls only return value set in call info.
        if (!VCCB_AreFr1PowerClassSavedDeltasEffective(rc.fr1PCState.savedDeltas))
        {
            VCCB_PRINT_LOG_POWER_CLASS(ptCi, "Deltas not effective, do not apply\n");
            continue;
        }

        const enumUeAllPowerClass_type selectedPC = VLIB_GetSelectedPowerClass(*ptCi);
        if (isPost25A)
        {
            VCCB_PRINT_LOG_POWER_CLASS(ptCi,
                "Try to apply FR1 deltas according to post-25A behavior, selected power class=%s\n",
                VLIB_UeAllPowerClassToStr(selectedPC));
            applyPowerClassDelta(ptCi, rc,
                getDeltasBasedOnSelectedPowerClass(selectedPC, rc.fr1PCState.savedDeltas.pc1SavedDelta,
                    rc.fr1PCState.savedDeltas.pc15SavedDelta, rc.fr1PCState.savedDeltas.pc2SavedDelta));
        }
        else
        {
            VCCB_PRINT_LOG_POWER_CLASS(ptCi,
                "Try to apply FR1 deltas according to pre-25A behavior, selected power class=%s\n",
                VLIB_UeAllPowerClassToStr(selectedPC));
            applyPowerClassDelta(ptCi, rc,
                getDeltasForLegacyBehavior(
                    selectedPC, static_cast<enumMeasurementReportType>(rc.reportType), rc.fr1PCState));
        }
    }
}

/****************************************************************************
 * @brief           This function uses current applicability structure and disables applicability of FGR-CC4208 deltas
 *                  (FR1) if conditions are not satisfied. Conditions are described in FGR-CC4208 HLD for SVR25A.
 *
 * @param[in]       rCi : reference to call type info. / callInfo_type&
 * @param[in]       isForPcellMeasObject : true if it is called in the context of PCell Meas Object,
 *                                         false otherwise / bool
 * @param[out]      applicability : structure representing power class delta applicability for FR1 deltas.
 *                                  / PowerClassDeltasApplicabilityFr1_type
 ****************************************************************************/
void VCCB_ModifyFr1PowerClassDeltasApplicabilityBasedOnCallState(
    callInfo_type &rCi, bool isForPcellMeasObject, PowerClassDeltasApplicabilityFr1_type &applicability)
{
    AUTO_TRACE_FUNC;

    const bool isPost25A = isPost25ABehavior(rCi);

    if (isPost25A || isForPcellMeasObject)
    {
        const enumUeAllPowerClass_type selectedPC = VLIB_GetSelectedPowerClass(rCi);
        if (enumUeAllPowerClass_type::PowerClass_Pc1 != selectedPC)
        {
            applicability.canPc1BeAppliedToMeasObject = false;
            VCCB_PRINT_LOG_POWER_CLASS(&rCi,
                "FR1 PC1 MO applicability disabled due to not matching selected power class=%s\n",
                VLIB_UeAllPowerClassToStr(selectedPC));
        }
        if (enumUeAllPowerClass_type::PowerClass_Pc1dot5 != selectedPC)
        {
            applicability.canPc1dot5BeAppliedToMeasObject = false;
            VCCB_PRINT_LOG_POWER_CLASS(&rCi,
                "FR1 PC1.5 MO applicability disabled due to not matching selected power class=%s\n",
                VLIB_UeAllPowerClassToStr(selectedPC));
        }
        if (enumUeAllPowerClass_type::PowerClass_Pc2 != selectedPC)
        {
            applicability.canPc2BeAppliedToMeasObject = false;
            VCCB_PRINT_LOG_POWER_CLASS(&rCi,
                "FR1 PC2 MO applicability disabled due to not matching selected power class=%s\n",
                VLIB_UeAllPowerClassToStr(selectedPC));
        }
    }
}

void VCCB_SaveHighestFr1PowerClassUeCapability(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    const auto &rf = rCi.ueInfo.ueCapa.nr.rf;
    auto bandsBegin = rf.supportedBandListNR;
    auto bandsEnd = bandsBegin + util::minOfArraySizeAndNumOfElems(rf.supportedBandListNR, rf.nrOfBands);

    bool pc1CapaFound = false;
    bool pc15CapaFound = false;
    bool pc2CapaFound = false;

    for (auto band = bandsBegin; band != bandsEnd; ++band)
    {
        if (band->bandNR <= MAX_FR1_NR_BAND)
        {
            if (band->ue_PowerClass == UePowerClass_Pc1)
            {
                pc1CapaFound = true;
                break;
            }
            else if (!pc15CapaFound && band->ue_PowerClass_v1610 == UePowerClass_Pc1dot5)
            {
                pc15CapaFound = true;
            }
            else if (!pc2CapaFound && band->ue_PowerClass == UePowerClass_Pc2)
            {
                pc2CapaFound = true;
            }
        }
    }

    // Set the highest PowerClass level of the UE (PC1 > PC1.5 > PC2)
    if (pc1CapaFound)
    {
        rCi.bitFlag.pc1Capable = VCCB_FLAG_ON;
    }
    else if (pc15CapaFound)
    {
        rCi.bitFlag.pc15Capable = VCCB_FLAG_ON;
    }
    else if (pc2CapaFound)
    {
        rCi.bitFlag.pc2Capable = VCCB_FLAG_ON;
    }
}
