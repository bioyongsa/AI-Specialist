#include "FeatMeasurementsExcludedCells.hpp"
#include <cstdint>

#include "ComMacro.h"
#include "FeatCommon.h"
#include "ComLibUtility.h"
#include "ComInclude.h"
#include "FeatSpeedState.hpp"
#include "ComConsecutiveIdsPool.hpp"
#include "ComContainers.hpp"
#include "ComNRRRCEnumsToValues.h"

using util::ConsecutiveIdsPool;

namespace
{

void VCCB_AssignBlackCellsParameters(
    const measurementObjectBlacklistCells_Set_type &rPerSsbFreq, measurementObjectNRUe_type &rUeMo)
{
    AUTO_TRACE_FUNC;

    if (CI_use != rPerSsbFreq.usage)
    {
        return;
    }

    for (uint16_t idx = 0; idx < VCCB_ARRAY_COUNT(rPerSsbFreq.blacklistCellsPerSsbFreq); idx++)
    {
        if ((CI_use == rPerSsbFreq.blacklistCellsPerSsbFreq[idx].usage) &&
            (rUeMo.minimal.ssbFrequency == rPerSsbFreq.blacklistCellsPerSsbFreq[idx].ssbFreq))
        {
            for (uint8_t idx2 = 0; idx2 < MAX_NR_OF_PCI_RANGES; idx2++)
            {
                const blackCellsElementDb_type &pEntry =
                    (rPerSsbFreq.blacklistCellsPerSsbFreq[idx].blacklistCells[idx2]);
                if (CI_use == pEntry.usage)
                {
                    auto &rangeElement = rUeMo.blackCells.rangeElements[rUeMo.blackCells.numItems];
                    rangeElement.pciRangeIndex = static_cast<uint8_t>(idx2 + 1);
                    rangeElement.pciRange = pEntry.pciRange;
                    rUeMo.blackCells.numItems++;
                }
            }
        }
    }
}

namespace
{
using PciRangeIndexPoolType = ConsecutiveIdsPool<1, MAX_NR_OF_PCI_RANGES>;

void VCCB_AssignSaExcludedCellsForNonHighSpeedUe(
    measurementObjectNRUe_type &rUeMo, const simpleVector<uint16_t, MAX_NR_OF_PCI_RANGES> &highSpeedCellsPcis)
{
    AUTO_TRACE_FUNC;

    PciRangeIndexPoolType freePciRangeIdxs{};

    for (uint8_t idx = 0; idx < rUeMo.blackCells.numItems; ++idx)
    {
        const auto &rangeElement = rUeMo.blackCells.rangeElements[idx];
        if (rangeElement.pciRange.pciStart != 0)
        {
            freePciRangeIdxs.occupy(rangeElement.pciRangeIndex);
        }
    }

    for (auto cellPci : highSpeedCellsPcis)
    {
        if (rUeMo.blackCells.numItems >= MAX_NR_OF_PCI_RANGES)
        {
            break;
        }

        auto &rangeElement = rUeMo.blackCells.rangeElements[rUeMo.blackCells.numItems];
        auto rangeIdx = freePciRangeIdxs.take();
        
        if (rangeIdx.has_value())
        {
            rangeElement.pciRangeIndex = static_cast<uint8_t>(rangeIdx.value());
            rangeElement.pciRange.pciStart = cellPci & e_BitMask_10bit;
            rangeElement.pciRange.pciType = pciType_single;

            ++rUeMo.blackCells.numItems;
        }
    }
}

bool isPciIncluded(uint16_t pci, measurementObjectNRUe_type &rUeMo)
{
    for (uint8_t i = 0; i < rUeMo.blackCells.numItems; i++)
    {
        auto pciRange = rUeMo.blackCells.rangeElements[i].pciRange;

        if (pciRange.pciType == pciType_single)
        {
            if (pci == pciRange.pciStart)
            {
                return true;
            }
        }

        if (pciRange.pciType == pciType_range)
        {
            if (pci >= pciRange.pciStart && pci < pciRange.pciStart + pciRangeTovalue(static_cast<enumPciRangeType>(pciRange.pciRange)))
            {
                return true;
            }
        }
    }

    return false;
}

void VCCB_UpdateSaExcludedCellsForNonHighSpeedUe(
    callInfo_type &rCi, CellNum_type cellNum, measurementObjectNRUe_type &rUeMo)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type &cell = CELLINFO[cellNum];

    if (!cell.ueSpeedStateMobilityConfig.highSpeedCellExcludedCell)
    {
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "Exclude High Speed Cells feature is disabled.\n");
        return;
    }

    if (IS_MRDC_SN(&rCi))
    {
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "Call is MR-DC SN, do not set high speed excluded cells.\n");
        return;
    }

    if (ueSpeedState_High == UeSpeedState::VCCB_GetUeSpeedState(rCi, cellNum))
    {
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "Ue is High Speed don't exclude high speed cells.\n");
        return;
    }

    if (rUeMo.blackCells.numItems >= MAX_NR_OF_PCI_RANGES)
    {
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "No space left for high speed cells.\n");
        return;
    }

    simpleVector<uint16_t, MAX_NR_OF_PCI_RANGES> highSpeedCellsPcis{};

    const size_t spaceLeft = static_cast<size_t>(MAX_NR_OF_PCI_RANGES - rUeMo.blackCells.numItems);

    for (uint16_t cellId = 0; cellId < MAX_CELL_NUM_VCCB; ++cellId)
    {
        if (spaceLeft == highSpeedCellsPcis.size())
        {
            break;
        }

        const VccbCellInfo_type &cellInfo = CELLINFO[cellId];

        if (cellInfo.status != EQUIP || cellInfo.gnbNum != rCi.gnbNum)
        {
            continue;
        }

        if (cellInfo.ssbArfcn == rUeMo.minimal.ssbFrequency &&
            cellInfo.isCellHighSpeed == true)
        {
            if (!isPciIncluded(cellInfo.phyCellId,rUeMo))
            {
                highSpeedCellsPcis.push_back(cellInfo.phyCellId);
            }
        }
    }

    if (highSpeedCellsPcis.empty())
    {
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "No High Speed Cells.\n");
        return;
    }

    VCCB_AssignSaExcludedCellsForNonHighSpeedUe(rUeMo, highSpeedCellsPcis);
}
}  // namespace

void VCCB_AssignBlackCellsEutraParameters(
    measurementObjectBlacklistCells_Set_Eutra_type &rPerCarrierFreq, measurementObjectEUTRAUe_type &rUeMo)
{
    AUTO_TRACE_FUNC;

    auto beginBlacklistCells = std::begin(rPerCarrierFreq.blacklistCellsPerCarrierFreq);
    auto endBlacklistCells = std::end(rPerCarrierFreq.blacklistCellsPerCarrierFreq);

    auto matchingPerCarrierSet = std::find_if(beginBlacklistCells, endBlacklistCells,
        [rUeMo](const measurementObjectBlacklistCells_Set_PerCarrierFreq_type &blacklistCell) {
            return (blacklistCell.carrierFreq == rUeMo.minimal.carrierFreq) &&
                   (CI_use == blacklistCell.usage);
        });

    if (endBlacklistCells != matchingPerCarrierSet)
    {
        for (uint8_t i = 0; i < VCCB_ARRAY_COUNT(matchingPerCarrierSet->blacklistCells); i++)
        {
            auto &pEntry = matchingPerCarrierSet->blacklistCells[i];
            if (CI_use == pEntry.usage)
            {
                auto &rangeElement = rUeMo.blackCells.rangeElements[rUeMo.blackCells.numItems];
                rangeElement.cellIndexEutra = static_cast<uint8_t>(i + 1);
                rangeElement.physCellIdRange = pEntry.range.physCellIdRange;
                rUeMo.blackCells.numItems++;
            }
        }
    }
}

void VCCB_UpdateEndcBlackCells(callInfo_type &rCi, CellNum_type cellNum, measurementObjectNRUe_type &rUeMo)
{
    AUTO_TRACE_FUNC;
    
    VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "Begin setting excluded cells for ENDC.\n");


    const uint8_t servPlmnIndex = VLIB_FindGnbPlmnIndexOfCall(&rCi);
    if (MAX_PLMN_INDEX <= servPlmnIndex)
    {
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "Cannot find call plmn (%d)!\n", servPlmnIndex);
        return;
    }

    const uint16_t spid = rCi.ueInfo.rfsp.subscriberProfile;
    if (!rCi.ueInfo.rfsp.rfspPresent || ((spid < 1) || (spid > MAX_SPID_VALUE)))
    {
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "call does not have SPID configured.\n");
        return;
    }
    const uint16_t spidIdx = static_cast<uint16_t>(spid - 1); // spid is in [1,256] and table is indexed from 0

    uint16_t endcIdx = UNKNOWN_IDX_IN_ENDC_BLACKLIST_CELLS_SETS;
    rUeMo.blackCells.numItems = 0;

    measurementsData_type *pDbConf = &(CELLINFO[cellNum].measurementsData);
    const auto &plmnEntry = pDbConf->measObjectBlacklistCells.refs.plmnSupportEntries[servPlmnIndex];
    const auto &supportedEntry = plmnEntry.spidRefs;

    if (CI_use == plmnEntry.usage)
    {
        if (UNKNOWN_IDX_IN_ENDC_BLACKLIST_CELLS_SETS != supportedEntry.spidEndcIdx[spidIdx])
        {
            endcIdx = supportedEntry.spidEndcIdx[spidIdx];
            VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "get set index:%d for PLMN:%d,SPID(0-based):%d.\n",
                endcIdx, servPlmnIndex, spidIdx);
        }
        else
        {
            endcIdx = supportedEntry.spidDefaultEndcIdx;
            VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "fallback to the default set index for SPID.\n");
        }
    }
    else
    {
        endcIdx = pDbConf->measObjectBlacklistCells.refs.defaultEndcIdx;
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "fallback to the default set index for ENDC.\n");
    }

    if (UNKNOWN_IDX_IN_ENDC_BLACKLIST_CELLS_SETS == endcIdx)
    {
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "selected entry has invalid set index.\n");
        return;
    }

    measurementObjectBlacklistCells_Set_type &rPerSsbFreq =
        (pDbConf->measObjectBlacklistCells.endcBlacklistCellsSets[endcIdx]);

    VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "%d ENDC set index will be used.\n", endcIdx);
    VCCB_AssignBlackCellsParameters(rPerSsbFreq, rUeMo);
}

void VCCB_UpdateRfspBasedBlackCells(
    callInfo_type &rCi, CellNum_type cellNum, uint8_t servPlmnIndex, measurementObjectNRUe_type &rUeMo)
{
    AUTO_TRACE_FUNC;

    VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "Begin setting excluded cells for SA/RFSP.\n");

    uint16_t saIdx = UNKNOWN_IDX_IN_SA_BLACKLIST_CELLS_SETS, rfspIdx = MAX_RFSP_VALUE;

    if (!rCi.ueInfo.rfsp.rfspPresent || (NO_RFSP_VALUE == rCi.ueInfo.rfsp.indexToRFSP))
    {
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "call does not have RFSP configured.\n");
        return;
    }

    rUeMo.blackCells.numItems = 0;

    rfspIdx =
        static_cast<uint16_t>(rCi.ueInfo.rfsp.indexToRFSP - 1);  // rfsp is in [1,256] and table is indexed from 0
    if (MAX_RFSP_VALUE <= rfspIdx)
    {
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "rsfpIdx is out of range.\n");
        return;
    }

    measurementsData_type &dbConf = (CELLINFO[cellNum].measurementsData);
    const auto &plmnEntry = dbConf.measObjectBlacklistCells.refs.plmnSupportEntries[servPlmnIndex];
    const auto &supportedEntry = plmnEntry.rfspRefs;

    if (CI_use == plmnEntry.usage)
    {
        if (UNKNOWN_IDX_IN_SA_BLACKLIST_CELLS_SETS != supportedEntry.rfspSaIdx[rfspIdx])
        {
            saIdx = supportedEntry.rfspSaIdx[rfspIdx];
            VCCB_PRINT_LOG_EXCLUDED_CELLS(
                &rCi, "get set index:%d for PLMN:%d,RFSP(0-based):%d.\n", saIdx, servPlmnIndex, rfspIdx);
        }
        else
        {
            saIdx = supportedEntry.rfspDefaultSaIdx;
            VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "fallback to the default set index for RFSP.\n");
        }
    }
    else
    {
        saIdx = dbConf.measObjectBlacklistCells.refs.defaultSaIdx;
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "fallback to the default set index for SA.\n");
    }

    if (UNKNOWN_IDX_IN_SA_BLACKLIST_CELLS_SETS == saIdx)
    {
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "selected entry has invalid set index.\n");
        return;
    }

    measurementObjectBlacklistCells_Set_type &rPerSsbFreq =
        (dbConf.measObjectBlacklistCells.saBlacklistCellsSets[saIdx]);

    VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "%d SA set index will be used\n", saIdx);
    VCCB_AssignBlackCellsParameters(rPerSsbFreq, rUeMo);
}

bool VCCB_UpdateServiceGroupIdBasedBlackCells(
    callInfo_type &rCi, CellNum_type cellNum, measurementObjectNRUe_type &rUeMo)
{
    AUTO_TRACE_FUNC;

    VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "Begin setting excluded cells for SA/ServiceGroup.\n");

    const measurementsData_type &dbConf = CELLINFO[cellNum].measurementsData;

    const auto &serviceGroupRefs = dbConf.measObjectBlacklistCells.refs.serviceGroupConfig.entries;

    serviceGroupPriorities_type serviceGroupPriorities{};
    size_t configuredServiceGroups = 0;
    for (uint8_t serviceGroupId = MIN_SVC_GRP_CONFIG_ID; serviceGroupId < MAX_SVC_GRP_DB_NUM; serviceGroupId++)
    {
        const auto &elem = serviceGroupRefs[serviceGroupId];
        serviceGroupPriorities.priority[serviceGroupId] = WORST_SVC_GRP_PRIORITY;
        if (CI_use == elem.usage)
        {
            serviceGroupPriorities.priority[serviceGroupId] = elem.priority;
            configuredServiceGroups++;
        }
    }

    if (0 == configuredServiceGroups)
    {
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "No service group ids configured.\n");
        return false;
    }

    uint8_t svcGrpId = INVALID_SVC_GRP_CONFIG_ID;
    if (ERROR == FnVCCB_GetServiceGroupIdWithPriorityTable(
                     &rCi, &svcGrpId, &serviceGroupPriorities, /*isReleaseProcedure = */ FALSE))
    {
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "Can't find service group id.\n");
        return false;
    }
    if ((svcGrpId < MIN_SVC_GRP_CONFIG_ID) || (svcGrpId > MAX_SVC_GRP_CONFIG_ID))
    {
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "Found service group out of range.\n");
        return false;
    }
    if (CI_use != serviceGroupRefs[svcGrpId].usage)
    {
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "Found service group is not configured.\n");
        return false;
    }
    const auto& selectedEntry = serviceGroupRefs[svcGrpId];

    const uint16_t saSetIdx = selectedEntry.saIdx;
    VCCB_PRINT_LOG_EXCLUDED_CELLS(
        &rCi, "Selected set index:%d, best serviceGroupId:%d.\n", saSetIdx, svcGrpId);

    const auto &saSets = dbConf.measObjectBlacklistCells.saBlacklistCellsSets;
    if (VCCB_ARRAY_COUNT(saSets) <= saSetIdx)
    {
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "Selected entry has invalid set index.\n");
        return false;
    }
    
    VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "%d SA set index will be used.\n", saSetIdx);
    VCCB_AssignBlackCellsParameters(saSets[saSetIdx], rUeMo);
    return true;
}

uint8_t VCCB_SelectPreferredOptionForSaBlackCells(callInfo_type &rCi, CellNum_type cellNum, uint8_t servPlmnIndex)
{
    AUTO_TRACE_FUNC;
    const auto defaultOption = moBlacklistCellsSaPreferredOption_followServiceGroup;

    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, defaultOption);
    VCCB_CHECK_E_RANGE_AND_VAL(servPlmnIndex, MAX_PLMN_INDEX, defaultOption);

    const measurementsData_type &dbConf = CELLINFO[cellNum].measurementsData;
    const auto getOptionStr = [](uint8_t option)
    {
        switch (option)
        {
            case moBlacklistCellsSaPreferredOption_followServiceGroup:
                return "followServiceGroup";
            case moBlacklistCellsSaPreferredOption_followRfsp:
                return "followRfsp";
            default:
                return "UNKNOWN";
        }
    };
    const auto &plmnEntry = dbConf.measObjectBlacklistCells.refs.plmnSupportEntries[servPlmnIndex];
    if (CI_use == plmnEntry.usage)
    {
        const uint8_t selectedOption =
            dbConf.measObjectBlacklistCells.refs.plmnSupportEntries[servPlmnIndex].saPreferredOption;
        VCCB_PRINT_LOG_EXCLUDED_CELLS(
            &rCi, "Select %s as preferred configuration option.\n", getOptionStr(selectedOption));
        return selectedOption;
    }
    else
    {
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi,
            "PLMN entry %d not configured, use %s as preferred configuration option.\n", servPlmnIndex,
            getOptionStr(defaultOption));
        return defaultOption;
    }
}

void VCCB_UpdateSaBlackCells(callInfo_type &rCi, CellNum_type cellNum, measurementObjectNRUe_type &rUeMo)
{
    AUTO_TRACE_FUNC;

    const uint8_t servPlmnIndex = VLIB_FindGnbPlmnIndexOfCall(&rCi);
    if (MAX_PLMN_INDEX <= servPlmnIndex)
    {
        VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "Cannot find call plmn (%d)!\n", servPlmnIndex);
        return;
    }

    const uint8_t option = VCCB_SelectPreferredOptionForSaBlackCells(rCi, cellNum, servPlmnIndex);
    if (moBlacklistCellsSaPreferredOption_followServiceGroup == option)
    {
        const bool handled = VCCB_UpdateServiceGroupIdBasedBlackCells(rCi, cellNum, rUeMo);
        if (!handled)
        {
            VCCB_PRINT_LOG_EXCLUDED_CELLS(&rCi, "Fallback to RFSP based configuration.\n");
            VCCB_UpdateRfspBasedBlackCells(rCi, cellNum, servPlmnIndex, rUeMo);
        }
    }
    else if (moBlacklistCellsSaPreferredOption_followRfsp == option)
    {
        VCCB_UpdateRfspBasedBlackCells(rCi, cellNum, servPlmnIndex, rUeMo);
    }

    // FGR-MC1026:FR110
    VCCB_UpdateSaExcludedCellsForNonHighSpeedUe(rCi, cellNum, rUeMo);
}
}

void VCCB_UpdateBlackCells(callInfo_type &rCi, CellNum_type cellNum, measurementObjectNRUe_type &rUeMo)
{
    AUTO_TRACE_FUNC;

    rUeMo.blackCells.numItems = 0;
    memset(rUeMo.blackCells.rangeElements, 0, sizeof(rUeMo.blackCells.rangeElements));

    switch (rCi.callType)
    {
        case E_CALLTYPE_NSA:
        {
            VCCB_UpdateEndcBlackCells(rCi, cellNum, rUeMo);
            break;
        }
        case E_CALLTYPE_SA:
        {
            VCCB_UpdateSaBlackCells(rCi, cellNum, rUeMo);
            break;
        }
        default:
        {
            break;
        }
    }
}

void VCCB_UpdateEutraBlackCells(CellNum_type cellNum, measurementObjectEUTRAUe_type &rUeMo)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    rUeMo.blackCells.numItems = 0;
    memset(rUeMo.blackCells.rangeElements, 0, sizeof(rUeMo.blackCells.rangeElements));

    measurementsData_type &dbConf = (CELLINFO[cellNum].measurementsData);

    measurementObjectBlacklistCells_Set_Eutra_type &rPerCarrierFreq =
        dbConf.measObjectBlacklistCells.eutraBlacklistCellsSet;

    VCCB_AssignBlackCellsEutraParameters(rPerCarrierFreq, rUeMo);
}