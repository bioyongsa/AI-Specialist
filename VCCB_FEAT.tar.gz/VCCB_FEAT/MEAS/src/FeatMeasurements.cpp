#include "FeatMeasurements.hpp"
#include <cstddef>
#include <cstdint>
#include "FeatHo.h"
#include "UplinkStatusTriggeredMobility.hpp"
#include "FeatSon.h"
#include "FeatMrdc.h"
#include "FeatCommon.h"
#include "FeatCallInfo.h"
#include "FeatCallProc.h"
#include "FeatFullConfig.h"
#include "FeatConditionalHo.h"
#include "FeatLb.hpp"
#include "FeatMeasurementObjectPriority.hpp"
#include "FeatMeasurementsExcludedCells.hpp"
#include "ComInclude.h"
#include "ComLibUtility.h"
#include "ComFind.hpp"
#include "ComUtil.hpp"
#include "ComAsnUtil.hpp"
#include "ComVccbStructUtil.hpp"
#include "FeatMeasurementsNRRRCMake.hpp"
#include "FeatPowerClass.hpp"
#include "FeatCa.hpp"
#include "FeatLtmHo.h"
#include "FeatMco.h"
#include "FeatMco.hpp"
#include "FeatMeasurementsForHighSpeedUe.hpp"
#include "FeatMeasCommon.hpp"
#include "FeatSpeedState.hpp"

#include "StateCa.h"
#include "StateCommon.h"
#include "StateMco.h"
#include "StateMeasurements.h"
#include "ComRangeAdaptors.hpp"

#include "ComNRRRCEnumsToValues.h"
#include "VccbStruct.h"
#include "FeatNrdcMrControl.hpp"

MACRO_STATIC_ASSERT(sizeof(reportConfigurationBaseDb_type::measObjectSelection) * 8 >=
                        VCCB_ARRAY_COUNT(measurementsData_type::measurementObjectsNRDb),
    "Number of bits in measObjectSelection must be equal or larger than number of measurementObjectsNRDb elements!");

struct NbrSmtc1PerFreq
{
    simpleVector<smtc1PerFreq_type, MAX_NBR_PER_CELL> smtc1PerFreqEntries{};
    uint16_t cellNumContext{};
};

static NbrSmtc1PerFreq cachedNbrSmtc1PerFreq[VCCB_CALL_THREAD_NUM]{};

constexpr size_t MAX_REPORT_CONFIG_QUANTITIES = 3;
using QuantitiesList = simpleVector<enumMeasTriggerQuantityChoice, MAX_REPORT_CONFIG_QUANTITIES>;

namespace
{
const minimalMeasObjectNRUe_type &getMinimalNrMeasObject(const minimalMeasObjectConfUe_type &mo) { return mo.rat.nr; }
const minimalMeasObjectEUTRAUe_type &getMinimalEutraMeasObject(const minimalMeasObjectConfUe_type &mo)
{
    return mo.rat.eutra;
}
const minimalMeasObjectNRUe_type &getMinimalNrMeasObject(const measurementObjectConfUe_type &mo)
{
    return mo.rat.nr.minimal;
}
const minimalMeasObjectEUTRAUe_type &getMinimalEutraMeasObject(const measurementObjectConfUe_type &mo)
{
    return mo.rat.eutra.minimal;
}

/****************************************************************************
 * @brief           get NR-ARFCN or EARFCN from meas object depending on rat type
 * @param[in]       mo    : meas object
 * @return          arfcn : Arfcn_type
 ****************************************************************************/
template <typename MeasObjectT>
Arfcn_type VCCB_getArfcnFromMeasurementObject(const MeasObjectT &mo)
{
    if (mo.ratType == measRatNr)
    {
        return FnVCCB_GetRrcMeasObjectNrSsbFrequency(getMinimalNrMeasObject(mo));
    }
    else if (mo.ratType == measRatEutra)
    {
        return getMinimalEutraMeasObject(mo).carrierFreq;
    }
    return UNKNOWN_ARFCN;
}

/****************************************************************************
 * @brief           Functor for matching frequency against measurementObjectUe_type or measurementObjectNRBaseDb_type
 *
 * @param[in]       ssbFrequency : SSB frequency to match against. / Arfcn_type/uint32_t
 * @param[in]       rsType : Type of RS to perform. / enumRSType
 ****************************************************************************/
struct VCCB_FrequencyMatcher
{
    VCCB_FrequencyMatcher(Arfcn_type ssbFrequency, enumRSType rsType) : _ssbFrequency(ssbFrequency), _rsType(rsType) {}

    bool operator()(const measurementObjectUe_type &measObj) const
    {
        switch (_rsType)
        {
            case RSType_SSB:

                return (CI_use == measObj.usage) && (measRatNr == measObj.conf.ratType) &&
                       (FnVCCB_GetRrcMeasObjectNrSsbFrequency(measObj.conf.rat.nr.minimal) == _ssbFrequency);

            default:
                VCCB_PRINT_ERROR("ERROR: Invalid rsType (%u) in VCCB_FrequencyMatcher!\n", _rsType);

                return false;
        }
    }

    bool operator()(const measurementObjectNRBaseDb_type &measObj) const
    {
        switch (_rsType)
        {
            case RSType_SSB:

                return (measObj.usage == CI_use) && (measObj.ssbFrequency == _ssbFrequency);

            default:
                VCCB_PRINT_ERROR("ERROR: Invalid rsType (%u) in VCCB_FrequencyMatcher!\n", _rsType);
                return false;
        }
    }

    Arfcn_type _ssbFrequency;
    enumRSType _rsType;
};

/****************************************************************************
 * @brief           Functor for matching report configuration type, purpose
 *                  and specified frequency
 *                  against reportConfigurationDb_type.
 *
 * @param[in]       type : Type of report configuration (periodic/A1/...). / uint32_t
 * @param[in]       purpose : Purpose of report configuration. / uint32_t
 ****************************************************************************/
struct VCCB_ReportCfgSpecFreqMatcher
{
    VCCB_ReportCfgSpecFreqMatcher(Arfcn_type freq, uint8_t measObjSsbDbIdx, uint8_t type, uint8_t purpose) :
        _type(type),
        _purpose(purpose),
        _freq(freq),
        _measObjSsbDbIdx(measObjSsbDbIdx)
    {
    }

    bool operator()(const reportConfigurationDb_type &rptCfg) const
    {
        if ((rptCfg.base.usage != CI_use) || (rptCfg.base.reportType != _type) ||
            (rptCfg.base.reportPurpose != _purpose) || (ALL_MEASOBJECT_SELECTION == rptCfg.base.measObjectSelection) ||
            (rptCfg.base.rsType != RSType_SSB))
        {
            return false;
        }

        if ((_measObjSsbDbIdx >= MAX_NR_OF_OBJECT_ID_DB) ||
            (!GETBIT(rptCfg.base.measObjectSelection, _measObjSsbDbIdx)))
        {
            return false;
        }

        return true;
    }

    uint8_t _type;
    uint8_t _purpose;
    Arfcn_type _freq;
    uint8_t _measObjSsbDbIdx;
};

/****************************************************************************
 * @brief           Functor for matching report configuration type, purpose
 *                  and all frequencies
 *                  against reportConfigurationInstalledUe_type or reportConfigurationDb_type.
 *
 * @param[in]       type : Type of report configuration (periodic/A1/...). / uint32_t
 * @param[in]       purpose : Purpose of report configuration. / uint32_t
 ****************************************************************************/
struct VCCB_ReportCfgAllFreqMatcher
{
    VCCB_ReportCfgAllFreqMatcher(uint8_t type, uint8_t purpose) : _type(type), _purpose(purpose) {}

    bool operator()(const reportConfigurationInstalledUe_type &rptCfg) const
    {
        if ((rptCfg.usage != CI_use) || (rptCfg.conf.reportType != _type) || (rptCfg.conf.reportPurpose != _purpose) ||
            (ALL_MEASOBJECT_SELECTION != rptCfg.conf.measObjectSelection))
        {
            return false;
        }
        return true;
    }

    bool operator()(const reportConfigurationDb_type &rptCfg) const
    {
        if ((rptCfg.base.usage != CI_use) || (rptCfg.base.reportType != _type) ||
            (rptCfg.base.reportPurpose != _purpose) || (ALL_MEASOBJECT_SELECTION != rptCfg.base.measObjectSelection))
        {
            return false;
        }
        return true;
    }

    uint8_t _type;
    uint8_t _purpose;
};

/****************************************************************************
 * @brief           Prepare new smtc1_type structure from two other smtc1_type parameters
 *
 * @param[in]       firstSmtc1  : reference to smtc1_type structure / const smtc1_type&
 * @param[in]       secondSmtc1 : reference to smtc1_type structure / const smtc1_type&
 * @return          mergedSmtc1 : smtc1_type structure / smtc1_type
 ****************************************************************************/
smtc1_type VCCB_MergeSmtc1(const smtc1_type &firstSmtc1, const smtc1_type &secondSmtc1)
{
    smtc1_type mergedSmtc1{};
    mergedSmtc1.periodicityAndOffset.periodicity =
        MAX(firstSmtc1.periodicityAndOffset.periodicity, secondSmtc1.periodicityAndOffset.periodicity);
    mergedSmtc1.duration = MAX(firstSmtc1.duration, secondSmtc1.duration);
    return mergedSmtc1;
}

bool VCCB_MergeSmtc1WithNbrSmtc1IfExist(
    const callInfo_type &rCi, smtc1_type &smtc1Merged, const Arfcn_type measObjectSsbArfcn, const CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(rCi.myThreadId, MAX_CALL_THREAD_NUM_VCCB, false);
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);

    if (cachedNbrSmtc1PerFreq[rCi.myThreadId].cellNumContext != cellNum)
    {
        VCCB_PRINT_CALL_SMTC1_MERGE_ALG(&rCi,
            "VCCB_MergeSmtc1WithNbrSmtc1IfExist() cellNum mismatch between cellNum(%d) and "
            "cachedNbrSmtc1PerFreq[rCi.myThreadId].cellNumContext(%d)\n",
            cellNum, cachedNbrSmtc1PerFreq[rCi.myThreadId].cellNumContext);
        return false;
    }

    const auto &smtc1PerFreqEntries = cachedNbrSmtc1PerFreq[rCi.myThreadId].smtc1PerFreqEntries;
    auto it = std::lower_bound(smtc1PerFreqEntries.begin(), smtc1PerFreqEntries.end(), measObjectSsbArfcn,
        [](const smtc1PerFreq_type &smtc1PerFreq, const Arfcn_type &ssbArfcn)
        { return smtc1PerFreq.ssbArfcn < ssbArfcn; });

    if ((it != smtc1PerFreqEntries.end()) && (it->ssbArfcn == measObjectSsbArfcn))
    {
        VCCB_PRINT_CALL_SMTC1_MERGE_ALG(
            &rCi, "VCCB_MergeSmtc1WithNbrSmtc1IfExist() found SSB:%d \n", measObjectSsbArfcn);
        smtc1Merged = VCCB_MergeSmtc1(smtc1Merged, it->smtc1);
        return true;
    }
    VCCB_PRINT_CALL_SMTC1_MERGE_ALG(
        &rCi, "VCCB_MergeSmtc1WithNbrSmtc1IfExist() not found SSB:%d \n", measObjectSsbArfcn);

    return false;
}

/****************************************************************************
 * @brief           Replace SMTC1 fields (periodicity and duration)
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       cellNum : Cell number to be configured.
 * @param[in]       measObjectSsbArfcn : SSB Arfcn of MO / uint32_t
 * @param[out]      ptSmtc1 : pointer to smtc1_type structure / smtc1_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_SetMergedSmtc1(
    callInfo_type *ptCi, CellNum_type cellNum, Arfcn_type measObjectSsbArfcn, smtc1_type *ptSmtc1)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptSmtc1);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    bool smtc1Found = false;
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    smtc1_type smtc1Merged;
    smtc1Merged.periodicityAndOffset.periodicity = 0;
    smtc1Merged.duration = 0;

    const auto PRINT_MERGE_INFO = [ptCi](const char *ctx, smtc1_type smtc1)
    {
        const unsigned periodicities[] = {5, 10, 20, 40, 80, 160};
        const unsigned periodicity = (smtc1.periodicityAndOffset.periodicity < util::arraySize(periodicities))
                                         ? periodicities[smtc1.periodicityAndOffset.periodicity]
                                         : 999;
        const unsigned offset = smtc1.periodicityAndOffset.offset;

        VCCB_PRINT_CALL_SMTC1_MERGE_ALG(
            ptCi, "merged %s's smtc1(p:sf%d,o:%d,d:%d) \n", ctx, periodicity, offset, smtc1.duration);
    };

    VCCB_PRINT_CALL_SMTC1_MERGE_ALG(ptCi, "BEGIN for %d \n", measObjectSsbArfcn);

    if (measObjectSsbArfcn == pCell->ssbArfcn)
    {
        const smtc1_type &pcellSmtc1 = pCell->measurementsData.measurementObjectsNRDb[INTRAFREQ_OBJECT_IDX].base.smtc1;
        smtc1Merged = VCCB_MergeSmtc1(smtc1Merged, pcellSmtc1);
        smtc1Found = true;

        PRINT_MERGE_INFO("pcell", pcellSmtc1);
    }

    // merge smtc1 of matching serving cell
    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (const scellInfo_type &rSCell : scells)
    {
        if (rSCell.state != SCELL_STATE_ADDED)
        {
            continue;
        }
        if (rSCell.ssbArfcn != measObjectSsbArfcn)
        {
            continue;
        }


        nbrGnbCellInfo_type *ptNbrGnbCell = VLIB_GetNbrGnbCellInfoBasedOnCgi(ptCi, rSCell.cgi, rSCell.gnbIdLength);
        VALID_E_POINT_CHECK_CONTINUE(ptNbrGnbCell);

        smtc1_type scellSmtc1 = ptNbrGnbCell->smtc1;
        smtc1Merged = VCCB_MergeSmtc1(smtc1Merged, scellSmtc1);
        smtc1Found = true;

        PRINT_MERGE_INFO("scell", scellSmtc1);
    }

    smtc1Found = VCCB_MergeSmtc1WithNbrSmtc1IfExist(*ptCi, smtc1Merged, measObjectSsbArfcn, cellNum);

    // fallback to pcell smtc1 if we haven't found any smtc1 to merge so far
    if (!smtc1Found)
    {
        smtc1Merged = pCell->measurementsData.measurementObjectsNRDb[INTRAFREQ_OBJECT_IDX].base.smtc1;
    }

    // always use pcell smtc1 offset
    smtc1Merged.periodicityAndOffset.offset =
        pCell->measurementsData.measurementObjectsNRDb[INTRAFREQ_OBJECT_IDX].base.smtc1.periodicityAndOffset.offset;

    // make sure offset didn't end up equal or greater than periodicity
    const unsigned periodicities[] = {5, 10, 20, 40, 80, 160};
    const unsigned periodicity = (smtc1Merged.periodicityAndOffset.periodicity < util::arraySize(periodicities))
                                     ? periodicities[smtc1Merged.periodicityAndOffset.periodicity]
                                     : 0xFFFFFFFF;
    if (smtc1Merged.periodicityAndOffset.offset >= periodicity)
    {
        VCCB_PRINT_CALL_SMTC1_MERGE_ALG(ptCi, "offset is 0 because it was equal or larger than periodicity!\n");
        smtc1Merged.periodicityAndOffset.offset = 0;
    }

    *ptSmtc1 = smtc1Merged;

    VCCB_PRINT_CALL_SMTC1_MERGE_ALG(ptCi, "END for %d \n", measObjectSsbArfcn);

    return GOOD;
}

/****************************************************************************
 * @brief           Sets smtc1Origin variable for appropriate value.
 *
 * @param[in]       ptCi : Pointer to call configuration / callInfo_type*
 * @param[in]       cellNum : Cell number to be configured.
 * @param[out]      rUeMo : reference to UE's MeasObject. / minimalMeasObjectNRUe_type&
 * @param[in]       rDbObject: reference to data base object. / measurementObjectNRBaseDb_type&
 ****************************************************************************/
void VCCB_SetSmtc1AndItsOrigin(callInfo_type *ptCi, CellNum_type cellNum, minimalMeasObjectNRUe_type &rUeMo,
    const measurementObjectNRBaseDb_type &rDbObject)
{
    AUTO_TRACE_FUNC;

    // initialize
    rUeMo.smtc1 = rDbObject.smtc1;
    rUeMo.smtc1Origin = measObjectSmtc1Origin_manually;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB)

    if (rDbObject.operatorConfiguredSmtc1)
    {
        rUeMo.smtc1Origin = measObjectSmtc1Origin_manually;

        const auto &tgtCell = CELLINFO[cellNum];
        auto isSmtc1Configured = [](const smtc1_type &smtc1)
        {
            return UNKNOWN_SMTC1_DURATION != smtc1.duration &&
                   UNKNOWN_SMTC1_OFFSET != smtc1.periodicityAndOffset.offset &&
                   UNKNOWN_SMTC1_PERIODICITY != smtc1.periodicityAndOffset.periodicity;
        };
        const auto &smtc1Configurable = tgtCell.measurementsData.smtc1ConfigurableIntraFreq;
        if (rUeMo.ssbFrequency == tgtCell.ssbArfcn && isSmtc1Configured(smtc1Configurable))
        {
            // special handling for intra frequency
            // smtc1-configurable of intra freq has precedence over smtc1 of intra freq
            VCCB_PRINT_CALL_COMMENT(ptCi, "[smtc1] meas-object's smtc1 overridden with smtc1-configurable.\n");
            rUeMo.smtc1 = smtc1Configurable;
        }
        else
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[smtc1] meas-object's smtc1 used.\n");
            rUeMo.smtc1 = rDbObject.smtc1;
        }
    }
    else
    {
        smtc1_type mergedSmtc1;
        if (GOOD == VCCB_SetMergedSmtc1(ptCi, cellNum, rUeMo.ssbFrequency, &mergedSmtc1))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[smtc1] merged smtc1 used.\n");

            rUeMo.smtc1Origin = measObjectSmtc1Origin_mergeAlgorithm;
            rUeMo.smtc1 = mergedSmtc1;
        }
        else
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[smtc1] Cannot merge!.\n");

            rUeMo.smtc1 = rDbObject.smtc1;
            rUeMo.smtc1Origin = measObjectSmtc1Origin_manually;
        }
    }
}

/****************************************************************************
 * @brief Class for finding a meas objects
 ****************************************************************************/
struct VCCB_MeasObjDbFinder
{
    VCCB_MeasObjDbFinder(measurementsData_type &rDbConf, enumMeasRatType ratType, Arfcn_type freq);
    bool isValid() const;

    measurementsData_type &_rDbConf;
    measurementObjectNRDb_type *_pDbObjNr;
    measurementObjectEUTRADb_type *_pDbObjEutra;
    enumMeasRatType _ratType;
    uint8_t _pMeasObjDbIdx;

private:
    void findNr(const Arfcn_type freq);
    void findEutra(const Arfcn_type freq);
};

/****************************************************************************
 * @brief Class for finding a report configuration and a meas objects
 ****************************************************************************/
struct VCCB_RptCfgAndMeasObjDbFinder
{
    VCCB_RptCfgAndMeasObjDbFinder(
        measurementsData_type &rDbConf, enumMeasurementReportType reportType, uint8_t reportPurpose, Arfcn_type freq);
    bool isValid() const;

    VCCB_MeasObjDbFinder _measObjectDbFinder;
    measurementsData_type &_rDbConf;
    reportConfigurationDb_type *_pDbRpt;
    ueReportConfigurationDb_type *_pDbUeRpt;
    enumMeasRatType _ratType;
    uint8_t _pRptCfgIdx;

private:
    void findNr(enumMeasurementReportType reportType, uint8_t reportPurpose, Arfcn_type freq);
    void findEutra(enumMeasurementReportType reportType, uint8_t reportPurpose, Arfcn_type freq);
};

class SmtcWindow
{
public:
    SmtcWindow() {}

    SmtcWindow(const measurementObjectUe_type &mo)
    {
        AUTO_TRACE_FUNC;

        if (mo.conf.ratType == measRatEutra)
        {
            initializeEutra();
        }
        else if (mo.conf.ratType == measRatNr)
        {
            initializeNr(mo.conf.rat.nr);
        }
    }

    bool isValid() const { return isValid_; }

    bool isInTheFirstHalfFrame() const { return firstHalfFrame_; }

    bool isInTheSecondHalfFrame() const { return secondHalfFrame_; }

    bool isOnlyInTheFirstHalfFrame() const { return isInTheFirstHalfFrame() && !isInTheSecondHalfFrame(); }

    bool isOnlyInTheSecondHalfFrame() const { return !isInTheFirstHalfFrame() && isInTheSecondHalfFrame(); }

    const char *print() const
    {
        if (isOnlyInTheFirstHalfFrame())
        {
            return "[x| ]";
        }
        if (isOnlyInTheSecondHalfFrame())
        {
            return "[ |x]";
        }
        if (isInTheFirstHalfFrame() && isInTheSecondHalfFrame())
        {
            return "[x|x]";
        }
        return "[ | ]";
    }

private:
    void initializeEutra()
    {
        AUTO_TRACE_FUNC;

        isValid_ = true;
        firstHalfFrame_ = true;
        secondHalfFrame_ = true;
    }

    void initializeNr(const measurementObjectNRUe_type &moNr)
    {
        AUTO_TRACE_FUNC;

        const unsigned periodicities[] = {5, 10, 20, 40, 80, 160};

        const smtc1_type &smtc = moNr.minimal.smtc1;
        const unsigned pIdx = smtc.periodicityAndOffset.periodicity;
        if (pIdx >= util::arraySize(periodicities))
        {
            VCCB_PRINT_ERROR("ERROR: Constructing SmtcWindow, not supported periodicity = %d.\n", pIdx);
            return;
        }
        const unsigned p = periodicities[pIdx];

        const unsigned o = smtc.periodicityAndOffset.offset;
        if (o >= p)
        {
            VCCB_PRINT_ERROR("ERROR: Constructing SmtcWindow, not supported offset = %d.\n", o);
            return;
        }

        isValid_ = true;

        if (p == 5)
        {
            firstHalfFrame_ = true;
            secondHalfFrame_ = true;
            return;
        }

        const unsigned NUMBER_OF_SUBFRAMES = 10;
        if ((o % NUMBER_OF_SUBFRAMES) < (NUMBER_OF_SUBFRAMES / 2))
        {
            firstHalfFrame_ = true;
        }
        else
        {
            secondHalfFrame_ = true;
        }
    }

    bool firstHalfFrame_{false};
    bool secondHalfFrame_{false};
    bool isValid_{false};
};

/****************************************************************************
 * @brief           Function for finding index of matching measurementObjectsNRDb.
 *                  Because of possibility of duplication of intra freq measurementObjectsNRDb
 *                  we iterate starting from last index which relates to
 *gutran-cu-cell-entries/intra-frequency-meas-object and which has priority over all
 *gutran-cu-cell-entries/meas-object-entries.
 *
 * @param[in]       matcher : predicate for measurementObjectsNRDb
 * @param[in]       measData : object containing array of measurementObjectsNRDb
 * @return          index of matching measurementObjectsNRDb within measData.measurementObjectsNRDb
 *                  If there is no matching measurementObjectsNRDb then number of elements in
 *                  measData.measurementObjectsNRDb is returned.
 ****************************************************************************/
uint8_t findIdxOfMatchingMeasObjectNr(const VCCB_FrequencyMatcher &matcher, const measurementsData_type &measData)
{
    const uint8_t numberOfElements = VCCB_ARRAY_COUNT(measData.measurementObjectsNRDb);
    static_assert(numberOfElements * 2 <= 0xFF, "Loop needs to be reorganized!");
    for (uint8_t i = 0; i < numberOfElements; i++)
    {
        const uint8_t newIdx = static_cast<uint8_t>((i + numberOfElements - 1) % numberOfElements);
        if (matcher(measData.measurementObjectsNRDb[newIdx].base))
        {
            return newIdx;
        }
    }

    return numberOfElements;
}

/****************************************************************************

 ****************************************************************************/
uint8_t findIdxOfMatchingReportCfgNrSpecFreq(
    const VCCB_ReportCfgSpecFreqMatcher &matcher, const measurementsData_type &measData)
{
    for (uint8_t newIdx = 0; newIdx < MAX_NR_OF_REPORT_CONFIG_ID_DB; newIdx++)
    {
        if (matcher(measData.reportConfigurationsDb[newIdx]))
        {
            return newIdx;
        }
    }

    return MAX_NR_OF_REPORT_CONFIG_ID_DB;
}

uint8_t findIdxOfMatchingReportCfgNrAllFreq(
    const VCCB_ReportCfgAllFreqMatcher &matcher, const measurementsData_type &measData)
{
    for (uint8_t newIdx = 0; newIdx < MAX_NR_OF_REPORT_CONFIG_ID_DB; newIdx++)
    {
        if (matcher(measData.reportConfigurationsDb[newIdx]))
        {
            return newIdx;
        }
    }

    return MAX_NR_OF_REPORT_CONFIG_ID_DB;
}

uint8_t findIdxOfMatchingReportCfgEutraSpecFreq(
    const VCCB_ReportCfgSpecFreqMatcher &matcher, const measurementsData_type &measData)
{
    for (uint8_t newIdx = 0; newIdx < VCCB_ARRAY_COUNT(measData.reportConfigInterRatDb); newIdx++)
    {
        if (matcher(measData.reportConfigInterRatDb[newIdx]))
        {
            return newIdx;
        }
    }

    return MAX_NR_OF_REPORT_CONFIGIR_ID_DB;
}

uint8_t findIdxOfMatchingReportCfgEutraAllFreq(
    const VCCB_ReportCfgAllFreqMatcher &matcher, const measurementsData_type &measData)
{
    for (uint8_t newIdx = 0; newIdx < VCCB_ARRAY_COUNT(measData.reportConfigInterRatDb); newIdx++)
    {
        if (matcher(measData.reportConfigInterRatDb[newIdx]))
        {
            return newIdx;
        }
    }

    return MAX_NR_OF_REPORT_CONFIGIR_ID_DB;
}

bool CanReportSinrOnSpCell(const callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    return CAN_UE_REPORT_SINR(&rCi, rCell.ssbArfcn);
}

bool CanReportSinrEutra(const callInfo_type &rCi) { return rCi.ueInfo.ueCapa.nr.eutraParam.rsSINRMeasEUTRA; }

/****************************************************************************
 * @brief           Fills measTriggerUe_type according to its database counterpart measTriggerQuantitySetDb_type
 *
 * @param[in]       from : reference to DB field version where information is stored.
 * @param[in]       canReportSinr : additional flag
 * @param[out]      toFill : pointer to measTriggerUe_type field, which must be filled.
 ****************************************************************************/
void VCCB_fromDbTriggerToUeTrigger(
    const measTriggerQuantitySetDb_type &from, measTriggerUe_type *toFill, bool canReportSinr)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(toFill);

    if (from.quantityInfo.isTriggeringOptionSinr && canReportSinr)
    {
        toFill->quantity = choice_sinr;
        toFill->value = from.values.value_sinr;
    }
    else
    {
        switch (from.quantityInfo.triggeringOption)
        {
            case choice_rsrp_option:
                toFill->quantity = choice_rsrp;
                toFill->value = from.values.value_rsrp;
                break;
            case choice_rsrq_option:
                toFill->quantity = choice_rsrq;
                toFill->value = from.values.value_rsrq;
                break;
            default:
                break;
        }
    }
}

/****************************************************************************
 * @brief           Returns measTriggerUe_type object responsible for second threshold.
 *
 * @param[in]       from : reference to original field where information is stored.
 * @return          measTriggerUe_type object to return.
 ****************************************************************************/
measTriggerUe_type getSecondThresholdEutra(const measDoubleTriggerUe_type &from)
{
    AUTO_TRACE_FUNC;
    measTriggerUe_type result;
    result.quantity = from.quantity;
    result.value = from.th2_value;
    return result;
}

/****************************************************************************
 * @brief           Fills measDoubleTriggerUe_type according to its database counterpart
 *                  measDoubleTriggerQuantitySetDb_type
 *
 * @param[in]       from : reference to DB field version where information is stored.
 * @param[in]       canReportSinrOnSpCell : additional flag
 * @param[in]       canReportSinr : additional flag
 * @return          pointer to measDoubleTriggerUe_type field, which must be filled.
 ****************************************************************************/
void VCCB_fromDbTriggerToDoubleUeTrigger(const measDoubleTriggerQuantitySetDb_type &from,
    measDoubleTriggerUe_type *toFill, const bool canReportSinrOnSpCell, bool canReportSinr)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(toFill);

    if (from.quantityInfo.isTriggeringOptionSinr && canReportSinrOnSpCell && canReportSinr)
    {
        toFill->quantity = choice_sinr;
        toFill->th1_value = from.th1_values.value_sinr;
        toFill->th2_value = from.th2_values.value_sinr;
    }
    else
    {
        switch (from.quantityInfo.triggeringOption)
        {
            case choice_rsrp_option:
                toFill->quantity = choice_rsrp;
                toFill->th1_value = from.th1_values.value_rsrp;
                toFill->th2_value = from.th2_values.value_rsrp;
                break;
            case choice_rsrq_option:
                toFill->quantity = choice_rsrq;
                toFill->th1_value = from.th1_values.value_rsrq;
                toFill->th2_value = from.th2_values.value_rsrq;
                break;
            default:
                break;
        }
    }
}

MeasQuantitiesValues_type VCCB_PrepareQuantityValues(
    const MeasQuantitiesValues_type values, const MeasQuantitiesRedCapValues_type redCapValues, bool applyRedcapValues)
{
    return {.value_rsrp = (redCapValues.isValidRsrp && applyRedcapValues) ? redCapValues.valueRsrp : values.value_rsrp,
        .value_rsrq = (redCapValues.isValidRsrq && applyRedcapValues) ? redCapValues.valueRsrq : values.value_rsrq,
        .value_sinr = (redCapValues.isValidSinr && applyRedcapValues) ? redCapValues.valueSinr : values.value_sinr};
}

measTriggerQuantitySetDb_type VCCB_PrepareMeasTriggerQuantitySet(const measTriggerQuantitySetDb_type &quantitySet,
    const MeasQuantitiesRedCapValues_type &redCapQuantitySet, bool applyRedcapValues)
{
    measTriggerQuantitySetDb_type measTriggerQuantity{};
    measTriggerQuantity.quantityInfo = quantitySet.quantityInfo;
    measTriggerQuantity.values = VCCB_PrepareQuantityValues(quantitySet.values, redCapQuantitySet, applyRedcapValues);
    return measTriggerQuantity;
}

measDoubleTriggerQuantitySetDb_type VCCB_PrepareMeasDoubleTriggerQuantitySet(
    const measDoubleTriggerQuantitySetDb_type &quantitySet,
    const MeasDoubleQuantitiesRedCapValues_type &redCapQuantitySet, bool applyRedcapValues)
{
    measDoubleTriggerQuantitySetDb_type measDoubleTriggerQuantity{};
    measDoubleTriggerQuantity.quantityInfo = quantitySet.quantityInfo;
    measDoubleTriggerQuantity.th1_values =
        VCCB_PrepareQuantityValues(quantitySet.th1_values, redCapQuantitySet.th1_values, applyRedcapValues);
    measDoubleTriggerQuantity.th2_values =
        VCCB_PrepareQuantityValues(quantitySet.th2_values, redCapQuantitySet.th2_values, applyRedcapValues);
    return measDoubleTriggerQuantity;
}

callControlConfigurationUe_type VCCB_PrepareA3CallControlCfgUe(const callControlConfigurationDb_type &callControlCfgIn,
    const MeasQuantitiesRedCapValues_type &callControlRedCapThreshold, bool applyRedcapValues)
{
    return {.option = callControlCfgIn.option,
        .thresholdRsrp = (callControlRedCapThreshold.isValidRsrp && applyRedcapValues)
                             ? callControlRedCapThreshold.valueRsrp
                             : callControlCfgIn.thresholdRsrp,
        .thresholdRsrq = (callControlRedCapThreshold.isValidRsrq && applyRedcapValues)
                             ? callControlRedCapThreshold.valueRsrq
                             : callControlCfgIn.thresholdRsrq,
        .thresholdSinr = (callControlRedCapThreshold.isValidSinr && applyRedcapValues)
                             ? callControlRedCapThreshold.valueSinr
                             : callControlCfgIn.thresholdSinr};
}

struct DbToUeTransformConfig
{
    bool canReportSinrNr{false};
    bool canReportSinrOnSpCell{false};
    bool canReportSinrEutra{false};
    bool canReportAddNeighMeasForPeriodical{false};
    bool applyRedcapValues{false};
    bool isReportConfigUeSpecific{false};
};

DbToUeTransformConfig VCCB_PrepareTransformConfig(
    const callInfo_type &rCi, const VccbCellInfo_type &rCell, const Arfcn_type frequency, bool isReportConfigUeSpecific)
{
    return {.canReportSinrNr = CAN_UE_REPORT_SINR(&rCi, frequency),
        .canReportSinrOnSpCell = CanReportSinrOnSpCell(rCi, rCell),
        .canReportSinrEutra = CanReportSinrEutra(rCi),
        .canReportAddNeighMeasForPeriodical = (rCi.ueInfo.ueCapa.nr.measAndMob.reportAddNeighMeasForPeriodic == TRUE),
        .applyRedcapValues = (IS_REDCAP_UE(&rCi) && rCell.supportRedCapDedicatedMeasurement == VCCB_FLAG_ON),
        .isReportConfigUeSpecific = isReportConfigUeSpecific};
}

/****************************************************************************
 * @brief           Fill reportConfigurationConfUe_type based on parameters from reportConfigurationBaseDb_type
 *
 * @param[in]       dbObject : reference to DB version of report config / reportConfigurationBaseDb_type
 * @param[out]      ueObject : reference to UE version of report config / reportConfigurationConfUe_type
 ****************************************************************************/
void VCCB_CreateReportConfigUeFromDb(const reportConfigurationBaseDb_type &dbObject,
    reportConfigurationConfUe_type &ueObject, const DbToUeTransformConfig &transformCfg)
{
    AUTO_TRACE_FUNC;
    memset(&ueObject, 0, sizeof(ueObject));
    ueObject.reportType = dbObject.reportType;
    ueObject.reportPurpose = dbObject.reportPurpose;
    ueObject.rsType = dbObject.rsType;
    ueObject.reportInterval = dbObject.reportInterval;
    ueObject.reportAmount = dbObject.reportAmount;
    ueObject.maxReportCells = dbObject.maxReportCells;
    ueObject.reportQuantityCell = dbObject.reportQuantityCell;
    ueObject.rat = dbObject.rat;

    VCCB_PRINT_MEASUREMENTS(
        "TransformCfg: "
        "sinrNr:%u,"
        "sinrSpCell:%u,"
        "sinrEutra:%u,"
        "addNeighMeas:%u,"
        "redCapVals:%u,"
        "ueSpec:%u\n",
        transformCfg.canReportSinrNr, transformCfg.canReportSinrOnSpCell, transformCfg.canReportSinrEutra,
        transformCfg.canReportAddNeighMeasForPeriodical, transformCfg.applyRedcapValues,
        transformCfg.isReportConfigUeSpecific);

    // If ue specific report config is applied, redcap triggers should not be applied
    bool applyRedcapValuesForBasicReportConfig =
        transformCfg.applyRedcapValues && !transformCfg.isReportConfigUeSpecific;

    switch (dbObject.reportType)
    {
        case measReport_reportCGI:
            ueObject.reportConfiguration.reportCgi = dbObject.reportConfiguration.reportCgi;
            break;
        case measReport_periodical:
            ueObject.reportConfiguration.periodical.useWhiteCellList = false;  // currently not supported
            if (transformCfg.canReportAddNeighMeasForPeriodical)
            {
                ueObject.reportConfiguration.periodical.reportAddNeighMeas =
                    dbObject.reportConfiguration.periodical.reportAddNeighMeas;
            }
            break;
        case measReport_A1:
        case measReport_A2:
        case measReport_A3:
        case measReport_A4:
        case measReport_A5:
        case measReport_A6:
        {
            auto &ueEventBased = ueObject.reportConfiguration.eventBased;
            const auto &dbEventBased = dbObject.reportConfiguration.eventBased;
            const auto &dbEventBasedExt = dbObject.reportConfigExtension.eventBased;
            ueEventBased.addNeighMeas = dbEventBasedExt.addNeighMeas;
            ueEventBased.useT312 = static_cast<bool>(dbObject.useT312);
            ueEventBased.multipleMeasurementQuantitySupport = dbEventBasedExt.multipleMeasurementQuantitySupport;
            ueEventBased.reportOnLeave = dbEventBased.reportOnLeave;
            ueEventBased.hysteresis = dbEventBased.hysteresis;
            ueEventBased.timeToTrigger = dbEventBased.timeToTrigger;

            switch (dbObject.reportType)
            {
                case measReport_A1:
                    ueEventBased.event.A1.a1_ThresholdOrigin =
                        VCCB_PrepareMeasTriggerQuantitySet(dbEventBased.event.A1.a1_Threshold,
                            dbEventBasedExt.event.A1.redCapThreshold, applyRedcapValuesForBasicReportConfig);
                    VCCB_fromDbTriggerToUeTrigger(ueEventBased.event.A1.a1_ThresholdOrigin,
                        &ueEventBased.event.A1.a1_Threshold, transformCfg.canReportSinrNr);
                    break;
                case measReport_A2:
                    ueEventBased.event.A2.a2_ThresholdOrigin =
                        VCCB_PrepareMeasTriggerQuantitySet(dbEventBased.event.A2.a2_Threshold,
                            dbEventBasedExt.event.A2.redCapThreshold, applyRedcapValuesForBasicReportConfig);
                    VCCB_fromDbTriggerToUeTrigger(ueEventBased.event.A2.a2_ThresholdOrigin,
                        &ueEventBased.event.A2.a2_Threshold, transformCfg.canReportSinrNr);
                    ueEventBased.event.A2.multipleTriggerQuantityEnabled = false;
                    break;
                case measReport_A3:
                    ueEventBased.event.A3.a3_OffsetOrigin =
                        VCCB_PrepareMeasTriggerQuantitySet(dbEventBased.event.A3.a3_Offset,
                            dbEventBasedExt.event.A3.redCapOffset, applyRedcapValuesForBasicReportConfig);
                    VCCB_fromDbTriggerToUeTrigger(ueEventBased.event.A3.a3_OffsetOrigin,
                        &ueEventBased.event.A3.a3_Offset,
                        transformCfg.canReportSinrOnSpCell && transformCfg.canReportSinrNr);
                    ueEventBased.event.A3.callControlCfg =
                        VCCB_PrepareA3CallControlCfgUe(dbEventBasedExt.event.A3.callControlCfg,
                            dbEventBasedExt.event.A3.callControlRedCapThreshold, transformCfg.applyRedcapValues);
                    // Even though report config is UE specific, call control A3 thresholds should not depend on it.
                    break;
                case measReport_A4:
                    ueEventBased.event.A4.a4_ThresholdOrigin =
                        VCCB_PrepareMeasTriggerQuantitySet(dbEventBased.event.A4.a4_Threshold,
                            dbEventBasedExt.event.A4.redCapThreshold, applyRedcapValuesForBasicReportConfig);
                    VCCB_fromDbTriggerToUeTrigger(ueEventBased.event.A4.a4_ThresholdOrigin,
                        &ueEventBased.event.A4.a4_Threshold, transformCfg.canReportSinrNr);
                    ueEventBased.event.A4.useAllowedCellList = dbEventBasedExt.event.A4.useAllowedCellList;
                    break;
                case measReport_A5:
                    ueEventBased.event.A5.a5_ThresholdsOrigin =
                        VCCB_PrepareMeasDoubleTriggerQuantitySet(dbEventBased.event.A5.a5_Thresholds,
                            dbEventBasedExt.event.A5.redCapThresholds, applyRedcapValuesForBasicReportConfig);
                    VCCB_fromDbTriggerToDoubleUeTrigger(ueEventBased.event.A5.a5_ThresholdsOrigin,
                        &ueEventBased.event.A5.a5_Thresholds, transformCfg.canReportSinrOnSpCell,
                        transformCfg.canReportSinrNr);
                    break;
                case measReport_A6:
                    VCCB_fromDbTriggerToUeTrigger(dbEventBased.event.A6.a6_Offset, &ueEventBased.event.A6.a6_Offset,
                        transformCfg.canReportSinrNr);
                    ueEventBased.event.A6.a6_OffsetOrigin.quantityInfo = dbEventBased.event.A6.a6_Offset.quantityInfo;
                    ueEventBased.event.A6.a6_OffsetOrigin.values = dbEventBased.event.A6.a6_Offset.values;
                    ueEventBased.event.A6.callControlCfg = {.option = dbEventBased.event.A6.callControlCfg.option,
                        .thresholdRsrp = dbEventBased.event.A6.callControlCfg.thresholdRsrp,
                        .thresholdRsrq = dbEventBased.event.A6.callControlCfg.thresholdRsrq,
                        .thresholdSinr = dbEventBased.event.A6.callControlCfg.thresholdSinr};
                    break;
                default:
                    break;
            }
            break;
        }
        case measReport_reportCGIEutra:
            ueObject.reportConfiguration.reportCgiEutra = dbObject.reportConfiguration.reportCgiEutra;
            break;
        case measReport_B1Eutra:
        case measReport_B2Eutra:
        {
            auto &ueEventBased = ueObject.reportConfiguration.eventInterRat;
            const auto &dbEventBased = dbObject.reportConfiguration.eventInterRat;
            const auto &dbEventBasedExt = dbObject.reportConfigExtension.eventInterRat;
            ueEventBased.multipleMeasurementQuantitySupport = dbEventBased.multipleMeasurementQuantitySupport;
            ueEventBased.reportOnLeave = dbEventBased.reportOnLeave;
            ueEventBased.hysteresis = dbEventBased.hysteresis;
            ueEventBased.timeToTrigger = dbEventBased.timeToTrigger;
            ueEventBased.mgrpPreference = dbEventBasedExt.mgrpPreference;

            switch (dbObject.reportType)
            {
                case measReport_B1Eutra:
                    ueEventBased.event.B1Eutra.b1_thresholdEUTRAOrigin =
                        VCCB_PrepareMeasTriggerQuantitySet(dbEventBased.event.B1Eutra.b1_thresholdEUTRA,
                            dbEventBasedExt.event.B1Eutra.redCapThreshold, applyRedcapValuesForBasicReportConfig);
                    VCCB_fromDbTriggerToUeTrigger(ueEventBased.event.B1Eutra.b1_thresholdEUTRAOrigin,
                        &ueEventBased.event.B1Eutra.b1_thresholdEUTRA, transformCfg.canReportSinrEutra);
                    break;
                case measReport_B2Eutra:
                    ueEventBased.event.B2Eutra.b2_thresholdsOrigin =
                        VCCB_PrepareMeasDoubleTriggerQuantitySet(dbEventBased.event.B2Eutra.b2_thresholds,
                            dbEventBasedExt.event.B2Eutra.redCapThresholds, applyRedcapValuesForBasicReportConfig);
                    VCCB_fromDbTriggerToDoubleUeTrigger(ueEventBased.event.B2Eutra.b2_thresholdsOrigin,
                        &ueEventBased.event.B2Eutra.b2_thresholds, transformCfg.canReportSinrOnSpCell,
                        transformCfg.canReportSinrEutra);
                    break;
                default:
                    break;
            }
            break;
        }
        case measReport_periodicalInterRat:
            ueObject.reportConfiguration.periodicalInterRat = dbObject.reportConfiguration.periodicalInterRat;
            break;
        default:
            break;
    }

    ueObject.fr1PCState = {};
    ueObject.measObjectSelection = dbObject.measObjectSelection;
}

/****************************************************************************
 * @brief           Update minimalMeasObjectConfUe_type for NCD SSB - Intra Freq
 *
 * @param[in]       rCi : Reference to call configuration / callInfo_type*
 * @param[in]       rCell : reference to cell info / const VccbCellInfo_type&
 * @param[out]      rUeMo : reference to UE's MeasObject. / minimalMeasObjectNRUe_type&
 ****************************************************************************/
void VCCB_UpdateIntraFreqMeasObjectCandidateForNcdSsb(
    const callInfo_type &rCi, const VccbCellInfo_type &rCell, minimalMeasObjectNRUe_type &rUeMo)
{
    if (rCell.ncdSsbInfo.usage == CI_use && VCCB_IsRedCapUeForSA(rCi) && rCell.ssbArfcn == rUeMo.ssbFrequency)
    {
        rUeMo.ncdSsbInfo.usage = true;
        rUeMo.ncdSsbInfo.ncdSsbArfcn = rCell.ncdSsbInfo.ncdSsbArfcn;
        rUeMo.ncdSsbInfo.ncdSmtc1 = rCell.ncdSsbInfo.ncdSmtc1;
        rUeMo.ncdSsbInfo.ncdSsbSubcarrierSpacing = rCell.ncdSsbInfo.ncdSsbSubcarrierSpacing;

        VCCB_PRINT_CALL_COMMENT(&rCi, "UE RedCap have NCD Ssb Frequency %u \n", rUeMo.ncdSsbInfo.ncdSsbArfcn);
    }
}

/****************************************************************************
 * @brief           Update minimalMeasObjectConfUe_type for NCD SSB - Inter Freq
 *
 * @param[in]       rCi : Reference to call configuration / callInfo_type*
 * @param[out]      rUeMo : reference to UE's MeasObject. / minimalMeasObjectNRUe_type&
 ****************************************************************************/
void VCCB_UpdateInterFreqMeasObjectCandidateForNcdSsb(
    const callInfo_type &rCi, const NcdSsbFreqEntry_type &ncdSsb, minimalMeasObjectNRUe_type &rUeMo)
{
    rUeMo.ncdSsbInfo.usage = true;
    rUeMo.ncdSsbInfo.ncdSsbArfcn = ncdSsb.ncdSsbFreq;
    rUeMo.ncdSsbInfo.ncdSsbSubcarrierSpacing = rUeMo.ssbSubcarrierSpacing;
    rUeMo.ncdSsbInfo.ncdSmtc1 = ncdSsb.ncdSmtc;
    VCCB_PRINT_CALL_COMMENT(&rCi, "UE RedCap have NCD Ssb Inter Frequency %u\n", rUeMo.ncdSsbInfo.ncdSsbArfcn);
}

minimalMeasObjectNRUe_type VCCB_CreateMeasObjectUeFromDb(
    callInfo_type *ptCi, CellNum_type cellNum, const measurementObjectNRBaseDb_type &dbObject)
{
    minimalMeasObjectNRUe_type ueObject;
    ueObject.ssbFrequency = dbObject.ssbFrequency;
    ueObject.ssbSubcarrierSpacing = dbObject.ssbSubcarrierSpacing;
    VCCB_SetSmtc1AndItsOrigin(ptCi, cellNum, ueObject, dbObject);
    ueObject.smtc2 = dbObject.smtc2;
    ueObject.referenceSignalConfig.ssbConfigMobility.usage = dbObject.referenceSignalConfig.ssbConfigMobility.usage;
    ueObject.referenceSignalConfig.ssbConfigMobility.deriveSSB_IndexFromCell =
        dbObject.referenceSignalConfig.ssbConfigMobility.deriveSSB_IndexFromCell;
    ueObject.referenceSignalConfig.ssbConfigMobility.ssbMeasurementConfiguration =
        dbObject.referenceSignalConfig.ssbConfigMobility.ssbMeasurementConfiguration;
    ueObject.absThreshSS_BlocksConsolidation = dbObject.absThreshSS_BlocksConsolidation;
    ueObject.nrofSS_BlocksToAverage = dbObject.nrofSS_BlocksToAverage;
    ueObject.quantityConfigIndex = dbObject.quantityConfigIndex;
    ueObject.offsetMO = dbObject.offsetMO;
    ueObject.choExecutionCond1Event = dbObject.choExecutionCond1Event;
    ueObject.freqBandIndicatorNR = 0;  // default value
    ueObject.pc1UeSupport = dbObject.pc1UeSupport & 0x03;
    ueObject.pc1dot5UeSupport = dbObject.pc1dot5UeSupport & 0x01;
    ueObject.pc2UeSupport = dbObject.pc2UeSupport & 0x01;
    ueObject.fr1Pc1UeSupport = dbObject.fr1Pc1UeSupport & 0x01;
    ueObject.smallCellPciListIndex = dbObject.smallCellPciListIndex;
    ueObject.ncdSsbInfo.usage = false;
    ueObject.allowedCells.numOfPciRanges = 0;
    return ueObject;
}

minimalMeasObjectEUTRAUe_type VCCB_CreateMeasObjectUeFromDb(const measurementObjectEUTRABaseDb_type &dbObject)
{
    minimalMeasObjectEUTRAUe_type ueObject;
    ueObject.carrierFreq = dbObject.carrierFreq;
    ueObject.overlappedCarrierFreq =
        dbObject.carrierFreq;  // it is done on purpose, if overlapped is different it need to be changed
    ueObject.allowedMeasBandwidth = dbObject.allowedMeasBandwidth;
    ueObject.presenceAntennaPort1 = dbObject.presenceAntennaPort1;
    ueObject.qOffsetRange = dbObject.qOffsetRange;
    ueObject.widebandRSRQMeas = dbObject.widebandRSRQMeas;
    ueObject.smallCellPciListIndex = dbObject.smallCellPciListIndex;
    return ueObject;
}

/****************************************************************************
 * @brief           Report Candidate is modified for UeMeasForSon purpose with hardcoded values.
 *
 * @param[in]       pReportConfigCandidate : pointer to report config which can be installed on UE.
 *****************************************************************************/
void VCCB_ModifyReportConfiguration_UeMeasForSon(reportConfigurationConfUe_type *pReportConfigCandidate)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pReportConfigCandidate);

    pReportConfigCandidate->rsType = RSType_SSB;
    pReportConfigCandidate->reportAmount = reportAmount_r4;
    pReportConfigCandidate->maxReportCells = 8;
    pReportConfigCandidate->reportQuantityCell.rsrp = CI_use;
    pReportConfigCandidate->reportQuantityCell.rsrq = CI_use;
    pReportConfigCandidate->reportQuantityCell.sinr = CI_no_use;
    pReportConfigCandidate->rat.nr.includeBeamMeasurements = FALSE;
    pReportConfigCandidate->reportConfiguration.periodical.useWhiteCellList = FALSE;
}

/****************************************************************************
 * @brief           Report Candidate for CA periodical is modified (FGR-RC0100 FR480).
 *                  It will be modified based on hardcoded values and A2 scell-release.
 *
 * @param[in]       pReportConfigCandidate : pointer to report config which can be installed on UE.
 *****************************************************************************/
void VCCB_ModifyReportConfiguration_PeriodicalScellRelease(
    callInfo_type *ptCi, reportConfigurationConfUe_type *pReportConfigCandidate)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pReportConfigCandidate);

    pReportConfigCandidate->rsType = RSType_SSB;
    pReportConfigCandidate->reportAmount = reportAmount_r4;
    pReportConfigCandidate->reportQuantityCell.rsrp = CI_no_use;
    pReportConfigCandidate->reportQuantityCell.rsrq = CI_no_use;
    pReportConfigCandidate->reportQuantityCell.sinr = CI_no_use;

    const measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);
    const uint16_t numNewItem =
        MIN(MAX_NR_OF_REPORT_CONFIG_ID, rMeasProc.reportConfigurations.numNewItems);
    for (uint8_t idx = 0; idx < numNewItem; ++idx)
    {
        const reportConfigurationNewUe_type &rReportConfig =
            rMeasProc.reportConfigurations.newItems[idx];

        if ((CI_use != rReportConfig.usage) || (measReport_A2 != rReportConfig.conf.reportType) ||
            (a2Purpose_scellRelease != rReportConfig.conf.reportPurpose))
        {
            continue;
        }

        const measTriggerUe_type &rMeasTriggerUe =
            rReportConfig.conf.reportConfiguration.eventBased.event.A2.a2_Threshold;

        if (choice_rsrp == rMeasTriggerUe.quantity)
        {
            pReportConfigCandidate->reportQuantityCell.rsrp = CI_use;
        }
        else if (choice_rsrq == rMeasTriggerUe.quantity)
        {
            pReportConfigCandidate->reportQuantityCell.rsrq = CI_use;
        }
        else if (choice_sinr == rMeasTriggerUe.quantity)
        {
            pReportConfigCandidate->reportQuantityCell.sinr = CI_use;
        }
    }
}

/****************************************************************************
 * @brief           Replaces threshod values if they where set using itscp_vccb spidthreshold command.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in/out]   pUeRpt : Pointer to ue candidate report configuration. / reportConfigurationConfUe_type*
 ****************************************************************************/
void VCCB_ReplaceWithAlternativeSpidBasedThreshold(
    callInfo_type *ptCi, reportConfigurationConfUe_type *pUeRpt, bool CanReportSinrNr)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pUeRpt);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    uint16_t spidIdx = MAX_SPID_VALUE;

    // This Function is for SPID based UL path switching (UL Path Switch for EN-DC)
    if (GOOD != VLIB_CheckEnableForSpidbasedUlPathSwitch(ptCi, ptCi->servCellNum))
    {
        return;
    }

    spidIdx = static_cast<uint16_t>(
        ptCi->ueInfo.rfsp.subscriberProfile - 1);  // spid is in [1,256] and table is indexed from 0
    VCCB_CHECK_E_RANGE_AND_VOID(spidIdx, MAX_SPID_VALUE);

    SpidUlPathSwitchProfile_type *pSpidUlpathSwitchProfile = NULL;
    spidThreshold_type *spidThreshold = NULL;

    int spidBasedUlPathSwitchingProfileIdx =
        CELLINFO[ptCi->servCellNum].profileDBInfo.spidBasedUlPathSwitchingProfileIdx;
    pSpidUlpathSwitchProfile = &GNBINFO[ptCi->gnbNum].SpidUlPathSwitchProfile[spidBasedUlPathSwitchingProfileIdx];
    spidThreshold = &pSpidUlpathSwitchProfile->spidThreshold[spidIdx];

    if ((pUeRpt->reportType == measReport_A1) &&
        (pUeRpt->reportPurpose == a1Purpose_inNRULCoverage_ueUlSplitSup ||
            pUeRpt->reportPurpose == a1Purpose_inNRULCoverage_ueUlSplitNotSup) &&
        spidThreshold->a1LegSwitchStatus &&
        (spidThreshold->a1LegSwitch.choice != choice_sinr ||
            CanReportSinrNr))  // refuse to override threshold to sinr if ue does not support it
    {
        pUeRpt->reportConfiguration.eventBased.event.A1.a1_Threshold.quantity = spidThreshold->a1LegSwitch.choice;
        pUeRpt->reportConfiguration.eventBased.event.A1.a1_Threshold.value =
            static_cast<int8_t>(spidThreshold->a1LegSwitch.threshold);
    }
    else if ((pUeRpt->reportType == measReport_A2) &&
             (pUeRpt->reportPurpose == a2Purpose_outOfNRULCoverage_ueUlSplitSup ||
                 pUeRpt->reportPurpose == a2Purpose_outOfNRULCoverage_ueUlSplitNotSup) &&
             spidThreshold->a2LegSwitchStatus &&
             (spidThreshold->a2LegSwitch.choice != choice_sinr ||
                 CanReportSinrNr))  // refuse to override threshold to sinr if ue does not support it
    {
        pUeRpt->reportConfiguration.eventBased.event.A2.a2_Threshold.quantity = spidThreshold->a2LegSwitch.choice;
        pUeRpt->reportConfiguration.eventBased.event.A2.a2_Threshold.value =
            static_cast<int8_t>(spidThreshold->a2LegSwitch.threshold);
    }
}

/****************************************************************************
 * @brief           Find specific measurements MO index for measurement object, plmn, spid.
 *                  Return ERROR if unavailable.
 *
 * @param[in]       finder         : initialized finder object for matching report config and measurement object
 * @param[in]       servPlmnIdx    : plmn index.
 * @param[in]       spidIdx        : spid index.
 * @param[in]       measObjIdx     : measurement object index.
 * @param[out]      pSpecMeasMOIdx : specific measurements MO index.
 * @return          status         : GOOD, ERROR
 ****************************************************************************/
int16_t VCCB_GetSpecMeasMOIdxForMeasObj(const VCCB_RptCfgAndMeasObjDbFinder &finder, uint8_t servPlmnIdx,
    uint16_t spidIdx, uint8_t measObjIdx, uint8_t *pSpecMeasMOIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pSpecMeasMOIdx);
    VCCB_CHECK_E_RANGE_AND_RETURN(spidIdx, MAX_SPID_VALUE);
    VCCB_CHECK_E_RANGE_AND_RETURN(servPlmnIdx, MAX_PLMN_INDEX);
    VCCB_CHECK_E_RANGE_AND_RETURN(measObjIdx, MAX_NR_OF_OBJECT_ID_DB);

    uint8_t index = 0;
    mobilityMeasurementDelta_type *pMobilityMeasurementDelta = nullptr;

    if ((CI_use != finder._rDbConf.specMeasConfig.plmnEntries[servPlmnIdx].usage) ||
        (CI_use != finder._rDbConf.specMeasConfig.plmnEntries[servPlmnIdx].spidEntries[spidIdx].usage))
    {
        return ERROR;
    }

    for (index = 0; index < MAX_NR_OF_SPEC_MEAS_MO_INDEXES; ++index)
    {
        pMobilityMeasurementDelta =
            &finder._rDbConf.specMeasConfig.plmnEntries[servPlmnIdx].spidEntries[spidIdx].measObjEntries[index];
        if ((CI_use == pMobilityMeasurementDelta->usage) && (measObjIdx == pMobilityMeasurementDelta->measObjIdx))
        {
            *pSpecMeasMOIdx = index;
            return GOOD;
        }
    }

    return ERROR;
}

/****************************************************************************
 * @brief           Modify mobility report config threshold/offset by configured delta.
 *
 * @param[in]       ptCi          : Pointer to call configuration. / callInfo_type*
 * @param[in/out]   pReportConfig : pointer to report config to modify
 * @param[in]       cellNum       : Cell number. / CellNum_type/uint16_t
 * @param[in]       finder        : initialized finder object for matching report config and measurement object  / const
 *VCCB_RptCfgAndMeasObjDbFinder&
 ****************************************************************************/
void VCCB_ModifyReportConfiguration_Mobility(callInfo_type *ptCi, reportConfigurationConfUe_type *pReportConfig,
    CellNum_type cellNum, const VCCB_RptCfgAndMeasObjDbFinder &finder)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pReportConfig);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    int8_t delta = 0, delta2 = 0;
    uint8_t servPlmnIdx = 0, specMeasMOIdx = 0;

    if ((GOOD != VLIB_getMultipleGnbPlmnIndexInfo(ptCi, &servPlmnIdx, ptCi->ueInfo.servedPlmn.longId)) ||
        (MAX_PLMN_INDEX <= servPlmnIdx) || (CI_use != pCell->mobilityConfig.plmn[servPlmnIdx].usage) ||
        (TRUE != pCell->mobilityConfig.plmn[servPlmnIdx].measConfigDeltaEnabled) ||
        (TRUE != ptCi->ueInfo.rfsp.rfspPresent))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "Measurement config delta for Mobility not supported! servPlmnIdx(%d), rfspPresent(%d)\n", servPlmnIdx,
            ptCi->ueInfo.rfsp.rfspPresent);
        return;
    }

    uint8_t measObjIdx = finder._measObjectDbFinder._pMeasObjDbIdx;
    uint16_t spidIdx = static_cast<uint16_t>(ptCi->ueInfo.rfsp.subscriberProfile - 1);

    if (GOOD != VCCB_GetSpecMeasMOIdxForMeasObj(finder, servPlmnIdx, spidIdx, measObjIdx, &specMeasMOIdx))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "Measurement config delta for plmnIdx(%u), spid(%u), measObjIdx(%u) not supported.\n ", servPlmnIdx,
            spidIdx + 1, measObjIdx);
        return;
    }

    VCCB_CHECK_E_RANGE_AND_VOID(spidIdx, MAX_SPID_VALUE);
    VCCB_CHECK_E_RANGE_AND_VOID(specMeasMOIdx, MAX_NR_OF_SPEC_MEAS_MO_INDEXES);

    mobilityMeasurementDelta_type *pMobilityMeasurementDelta =
        &finder._rDbConf.specMeasConfig.plmnEntries[servPlmnIdx].spidEntries[spidIdx].measObjEntries[specMeasMOIdx];

    switch (pReportConfig->reportType)
    {
        case measReport_A1:
        {
            if (a1Purpose_deactivateInterFrequency == pReportConfig->reportPurpose)
            {
                delta = pMobilityMeasurementDelta->a1InterFreqMeasDeactivationThresholdDelta;
            }
            else
            {
                break;
            }
            VCCB_ModifySelectedThresholds_ApplyDelta(
                ptCi, pReportConfig->reportConfiguration.eventBased.event.A1.a1_Threshold.value, delta);
            break;
        }
        case measReport_A2:
        {
            if (a2Purpose_activateInterFrequency == pReportConfig->reportPurpose)
            {
                delta = pMobilityMeasurementDelta->a2InterFreqMeasActivationThresholdDelta;
            }
            else if (a2Purpose_NRPSCellRelease == pReportConfig->reportPurpose)
            {
                delta = pMobilityMeasurementDelta->a2PscellReleaseThresholdDelta;
            }
            else
            {
                break;
            }
            VCCB_ModifySelectedThresholds_ApplyDelta(
                ptCi, pReportConfig->reportConfiguration.eventBased.event.A2.a2_Threshold.value, delta);
            break;
        }
        case measReport_A3:
        {
            if (a3Purpose_NRPSCellChange == pReportConfig->reportPurpose)
            {
                delta = pMobilityMeasurementDelta->a3PscellChangeOffsetDelta;
            }
            else if (a3Purpose_SpidPrioPSCellChange == pReportConfig->reportPurpose)
            {
                delta = pMobilityMeasurementDelta->a3SpidInterFreqPscellChangeOffsetDelta;
            }
            else
            {
                break;
            }
            VCCB_ModifySelectedOffset_ApplyDelta(ptCi, pReportConfig->reportConfiguration.eventBased.event.A3.a3_Offset.value, delta);
            break;
        }
        case measReport_A4:
        {
            if (a4Purpose_NRPSCellChange == pReportConfig->reportPurpose)
            {
                delta = pMobilityMeasurementDelta->a4PscellChangeThresholdDelta;
            }
            else if (a4Purpose_SpidPrioPSCellChange == pReportConfig->reportPurpose)
            {
                delta = pMobilityMeasurementDelta->a4SpidInterFreqPscellChangeThresholDelta;
            }
            else
            {
                break;
            }
            VCCB_ModifySelectedThresholds_ApplyDelta(
                ptCi, pReportConfig->reportConfiguration.eventBased.event.A4.a4_Threshold.value, delta);
            break;
        }
        case measReport_A5:
        {
            if (a5Purpose_NRPSCellChange == pReportConfig->reportPurpose)
            {
                delta = pMobilityMeasurementDelta->a5PscellChangeThreshold1Delta;
                delta2 = pMobilityMeasurementDelta->a5PscellChangeThreshold2Delta;
            }
            else if (a5Purpose_SpidPrioPSCellChange == pReportConfig->reportPurpose)
            {
                delta = pMobilityMeasurementDelta->a5SpidInterFreqPscellChangeThreshol1Delta;
                delta2 = pMobilityMeasurementDelta->a5SpidInterFreqPscellChangeThreshol2Delta;
            }
            else if (a5Purpose_EndcNrPscellChangeDuIndication == pReportConfig->reportPurpose)
            {
                delta = pMobilityMeasurementDelta->a5PscellChangeDuIndicationTh1Delta;
                delta2 = pMobilityMeasurementDelta->a5PscellChangeDuIndicationTh2Delta;
            }
            else if (a5Purpose_EndcPscellChangeUlStatusIndBadUlQuality == pReportConfig->reportPurpose)
            {
                delta = pMobilityMeasurementDelta->a5PscellChangeUlStatusIndBadUlQualityTh1Delta;
                delta2 = pMobilityMeasurementDelta->a5PscellChangeUlStatusIndBadUlQualityTh2Delta;
            }
            else if (a5Purpose_EndcPscellChangeUlStatusIndTddInterference == pReportConfig->reportPurpose)
            {
                delta = pMobilityMeasurementDelta->a5PscellChangeUlStatusIndTddInterferenceTh1Delta;
                delta2 = pMobilityMeasurementDelta->a5PscellChangeUlStatusIndTddInterferenceTh2Delta;
            }
            else
            {
                break;
            }
            VCCB_ModifySelectedThresholds_ApplyDelta(
                ptCi, pReportConfig->reportConfiguration.eventBased.event.A5.a5_Thresholds.th1_value, delta);
            VCCB_ModifySelectedThresholds_ApplyDelta(
                ptCi, pReportConfig->reportConfiguration.eventBased.event.A5.a5_Thresholds.th2_value, delta2);
            break;
        }
        default:
            break;
    }
}

/****************************************************************************
 * @brief           Modify report config (A2 spidPscellRelease) threshold by spid specific offset.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       pDbConf : pointer to cell measurement data
 * @param[in/out]   pReportConfig : pointer to report config to modify
 ****************************************************************************/
void VCCB_ModifyReportConfiguration_A2spidPscellReleaseThreshold(
    callInfo_type *ptCi, measurementsData_type *pDbConf, reportConfigurationConfUe_type *pReportConfig)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pReportConfig);
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pDbConf);

    uint8_t servPlmnIndex = 0;

    if ((measReport_A2 != pReportConfig->reportType) || (a2Purpose_spidPscellRelease != pReportConfig->reportPurpose) ||
        (GOOD != VLIB_getMultipleGnbPlmnIndexInfo(ptCi, &servPlmnIndex, ptCi->ueInfo.servedPlmn.longId)) ||
        (FALSE == ptCi->ueInfo.rfsp.rfspPresent))
    {
        return;
    }

    uint16_t spidIndex = static_cast<uint16_t>(ptCi->ueInfo.rfsp.subscriberProfile - 1);
    VCCB_CHECK_E_RANGE_AND_VOID(spidIndex, MAX_SPID_VALUE);
    VCCB_CHECK_E_RANGE_AND_VOID(servPlmnIndex, MAX_PLMN_INDEX);

    if ((CI_use != pDbConf->specMeasConfig.plmnEntries[servPlmnIndex].usage) ||
        (CI_use != pDbConf->specMeasConfig.plmnEntries[servPlmnIndex].spidEntries[spidIndex].usage))
    {
        return;
    }

    int8_t spidThresholdOffset =
        pDbConf->specMeasConfig.plmnEntries[servPlmnIndex].spidEntries[spidIndex].a2SpidReleaseThresholdOffset;
    VCCB_ModifySelectedThresholds_ApplyDelta(
        ptCi, pReportConfig->reportConfiguration.eventBased.event.A2.a2_Threshold.value, spidThresholdOffset);
}

/****************************************************************************
 * @brief           Modify report quantity of report configuration.
 *                  If UE does not support sinr measurements then
 *                  report quantity sinr should be disabled.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in/out]   reportQuantity : report quantity to modify
 * @param[in]       finder : initialized finder object for matching report config and measurement object  / const
 *VCCB_RptCfgAndMeasObjDbFinder&
 ****************************************************************************/
void VCCB_ModifyReportConfiguration_ReportQuantity(
    callInfo_type *ptCi, reportQuantity_type &reportQuantity, const VCCB_RptCfgAndMeasObjDbFinder &finder)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (CI_no_use == reportQuantity.sinr)
    {
        return;
    }

    if (measRatEutra == finder._ratType)
    {
        reportQuantity.sinr = CanReportSinrEutra(*ptCi) ? CI_use : CI_no_use;
    }
    else if (measRatNr == finder._ratType)
    {
        reportQuantity.sinr =
            CAN_UE_REPORT_SINR(ptCi, finder._measObjectDbFinder._pDbObjNr->base.ssbFrequency) ? CI_use : CI_no_use;
    }

    if (CI_no_use == reportQuantity.sinr)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "reportQuantity.sinr changed to false, because UE does not support sinr "
            "measurements on frequency of corresponding measObject.\n");
    }
}

/****************************************************************************
 * @brief           Function checks if the call configuration allows using of the timer T312.
 *                  Check is done based on the current call Connectivity configuration.
 *
 * @param[in]       ptCi : Pointer to the current call type info
 * @return          bool : true - if configuration allows T312 timer, false - otherwise
 ****************************************************************************/
bool VCCB_CheckEnableT312(callInfo_type const *const ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (E_CALLTYPE_NSA == ptCi->callType)  // EN_DC
    {
        if (true == ptCi->ueInfo.ueCapa.mrdc.pscellT312_EN_DC)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    else if (E_CALLTYPE_SA == ptCi->callType)  // SA or NR_DC
    {
        if (IS_NRDC_SN(ptCi))  // NR_DC
        {
            if (true == ptCi->ueInfo.ueCapa.nr.measAndMob.pscellT312_NR_DC)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else  // SA, Master Node for NE-DC, NR-DC
        {
            if (true == ptCi->ueInfo.ueCapa.nr.measAndMob.pcellT312_SA)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
    return false;
}

bool isEventBasedNR(const uint8_t reportType)
{
    AUTO_TRACE_FUNC;

    if (reportType == measReport_A1 || reportType == measReport_A2 || reportType == measReport_A3 ||
        reportType == measReport_A4 || reportType == measReport_A5 || reportType == measReport_A6)
    {
        return true;
    }
    return false;
}

/****************************************************************************
 * @brief           Modify report Configuration. Sets useT312==true for event based report config, if fulfilled
 *appropriate conditions.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in/out]   pUeRpt : Pointer to ue candidate report configuration. / reportConfigurationConfUe_type*
 *
 * @return          void
 ****************************************************************************/
void VCCB_ModifyReportConfiguration_useT312(callInfo_type *ptCi, reportConfigurationConfUe_type *pUeRpt)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pUeRpt);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    if (!isEventBasedNR(pUeRpt->reportType))
    {
        return;
    }

    // check if gNB enables timer T312
    if (true != GNBINFO[ptCi->gnbNum].cfg.T312.useT312)
    {
        pUeRpt->reportConfiguration.eventBased.useT312 = false;
        return;
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "From configuration useT312 was set to:(%s)\n",
        pUeRpt->reportConfiguration.eventBased.useT312 ? "TRUE" : "FALSE");
    if (!pUeRpt->reportConfiguration.eventBased.useT312)
    {
        return;
    }

    pUeRpt->reportConfiguration.eventBased.useT312 = VCCB_CheckEnableT312(ptCi);
    VCCB_PRINT_CALL_COMMENT(ptCi, "Field eventBasedReportConfigurationNR_type.useT312 was set:(%s)\n",
        pUeRpt->reportConfiguration.eventBased.useT312 ? "TRUE" : "FALSE");
}

rfspDeltaTh_type FnVCCB_PrepareRfspThresholdDeltaValues(const rfspDeltaTh_type values)
{
    rfspDeltaTh_type rfspDeltaTh{};
    rfspDeltaTh.deltaThRsrp =
        (values.redcapThreshold.isValidRsrp) ? values.redcapThreshold.valueRsrp : values.deltaThRsrp;

    rfspDeltaTh.deltaThRsrq =
        (values.redcapThreshold.isValidRsrq) ? values.redcapThreshold.valueRsrq : values.deltaThRsrq;

    rfspDeltaTh.deltaThSinr =
        (values.redcapThreshold.isValidSinr) ? values.redcapThreshold.valueSinr : values.deltaThSinr;

    return rfspDeltaTh;
}


/****************************************************************************
 * @brief           Modify RSRP/RSRQ values by applying Delta
 *
 * @param[in]       ptCi          : Pointer to call configuration. / callInfo_type*
 * @param[in]       pReportConfig : Pointer to report config to be installed on UE / reportConfigurationConfUe_type *
 * @param[in]       pDeltaThInfo   : Pointer to rfspThresholdDelta_type
 ****************************************************************************/
void VCCB_ApplyRfspSpecificDeltaValues(
    callInfo_type *ptCi, reportConfigurationConfUe_type *pReportConfig, const rfspThresholdDelta_type *pDeltaThInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pReportConfig);
    VALID_E_POINT_CHECK_VOID(pDeltaThInfo);

    int8_t deltaValue = 0;
    int8_t deltaValue1 = 0;
    int8_t deltaValue2 = 0;

    switch (pReportConfig->reportType)
    {
        case measReport_A1:
        {
            deltaValue = VCCB_PrepareRfspDeltaThreshold(IS_REDCAP_UE(ptCi),
                pReportConfig->reportConfiguration.eventBased.event.A1.a1_Threshold.quantity, pDeltaThInfo->a1DeltaTh);

            VCCB_ModifySelectedThresholds_ApplyDelta(
                ptCi, pReportConfig->reportConfiguration.eventBased.event.A1.a1_Threshold.value, deltaValue);
            break;
        }
        case measReport_A2:
        {
            deltaValue = VCCB_PrepareRfspDeltaThreshold(IS_REDCAP_UE(ptCi),
                pReportConfig->reportConfiguration.eventBased.event.A2.a2_Threshold.quantity, pDeltaThInfo->a2DeltaTh);

            VCCB_ModifySelectedThresholds_ApplyDelta(
                ptCi, pReportConfig->reportConfiguration.eventBased.event.A2.a2_Threshold.value, deltaValue);
            break;
        }
        case measReport_A3:
        {
            deltaValue = VCCB_PrepareRfspDeltaThreshold(IS_REDCAP_UE(ptCi),
                pReportConfig->reportConfiguration.eventBased.event.A3.a3_Offset.quantity, pDeltaThInfo->a3DeltaTh);

            VCCB_ModifySelectedOffset_ApplyDelta(
                ptCi, pReportConfig->reportConfiguration.eventBased.event.A3.a3_Offset.value, deltaValue);
            break;
        }
        case measReport_A4:
        {
            deltaValue = VCCB_PrepareRfspDeltaThreshold(IS_REDCAP_UE(ptCi),
                pReportConfig->reportConfiguration.eventBased.event.A4.a4_Threshold.quantity, pDeltaThInfo->a4DeltaTh);

            VCCB_ModifySelectedThresholds_ApplyDelta(
                ptCi, pReportConfig->reportConfiguration.eventBased.event.A4.a4_Threshold.value, deltaValue);
            break;
        }
        case measReport_A5:
        {
            deltaValue1 = VCCB_PrepareRfspDeltaThreshold(IS_REDCAP_UE(ptCi),
                pReportConfig->reportConfiguration.eventBased.event.A5.a5_Thresholds.quantity,
                pDeltaThInfo->a5DeltaTh1);
            deltaValue2 = VCCB_PrepareRfspDeltaThreshold(IS_REDCAP_UE(ptCi),
                pReportConfig->reportConfiguration.eventBased.event.A5.a5_Thresholds.quantity,
                pDeltaThInfo->a5DeltaTh2);

            VCCB_ModifySelectedThresholds_ApplyDelta(
                ptCi, pReportConfig->reportConfiguration.eventBased.event.A5.a5_Thresholds.th1_value, deltaValue1);
            VCCB_ModifySelectedThresholds_ApplyDelta(
                ptCi, pReportConfig->reportConfiguration.eventBased.event.A5.a5_Thresholds.th2_value, deltaValue2);
            break;
        }
        case measReport_B1Eutra:
        {
            deltaValue = VCCB_PrepareRfspDeltaThreshold(IS_REDCAP_UE(ptCi),
                pReportConfig->reportConfiguration.eventInterRat.event.B1Eutra.b1_thresholdEUTRA.quantity,
                pDeltaThInfo->b1DeltaTh);

            pReportConfig->reportConfiguration.eventInterRat.event.B1Eutra.b1_thresholdEUTRA.value =
                VCCB_ApplyDeltaEutra(
                    ptCi, pReportConfig->reportConfiguration.eventInterRat.event.B1Eutra.b1_thresholdEUTRA, deltaValue);
            break;
        }
        case measReport_B2Eutra:
        {
            deltaValue1 = VCCB_PrepareRfspDeltaThreshold(IS_REDCAP_UE(ptCi),
                pReportConfig->reportConfiguration.eventInterRat.event.B2Eutra.b2_thresholds.quantity,
                pDeltaThInfo->b2DeltaTh1);
            deltaValue2 = VCCB_PrepareRfspDeltaThreshold(IS_REDCAP_UE(ptCi),
                pReportConfig->reportConfiguration.eventInterRat.event.B2Eutra.b2_thresholds.quantity,
                pDeltaThInfo->b2DeltaTh2);

            VCCB_ModifySelectedThresholds_ApplyDelta(ptCi,
                pReportConfig->reportConfiguration.eventInterRat.event.B2Eutra.b2_thresholds.th1_value, deltaValue1);
            pReportConfig->reportConfiguration.eventInterRat.event.B2Eutra.b2_thresholds.th2_value =
                VCCB_ApplyDeltaEutra(ptCi,
                    getSecondThresholdEutra(
                        pReportConfig->reportConfiguration.eventInterRat.event.B2Eutra.b2_thresholds),
                    deltaValue2);
            break;
        }
        default:
            break;
    }
    VCCB_PRINT_CALL_MSG(ptCi,
        "[RfspSpecificDelta] reportType:%d, reportPurpose:%d, deltaValue:%d, A5/B2(deltaValue1:%d, deltaValue2:%d)\n",
        pReportConfig->reportType, pReportConfig->reportPurpose, deltaValue, deltaValue1, deltaValue2);
}

/****************************************************************************
 * @brief           Apply Rfsp Specific DelTa Threshold If Needed
 *
 * @param[in]       ptCi          : Pointer to call configuration. / callInfo_type*
 * @param[in]       pReportConfig : Pointer to report config to be installed on UE / reportConfigurationConfUe_type *
 * @param[in]       cellNum       : served cell num or target cell num
 * @param[in]       rMo           : reference to meas object which can be installed on UE
 ****************************************************************************/
void VCCB_ApplyRfspSpecificDeltaThresholdIfNeeded(callInfo_type *ptCi, reportConfigurationConfUe_type *pReportConfig,
    CellNum_type cellNum, const minimalMeasObjectConfUe_type &rMo)
{
    AUTO_TRACE_FUNC;

    const rfspThresholdDelta_type *pRfspThDelta = VCCB_GetRfspDeltasForReportConfig(
        ptCi, pReportConfig, cellNum, &rMo, FnVCCB_GetSvcGrpId(*ptCi, FALSE));

    if (nullptr != pRfspThDelta)
    {
        VCCB_ApplyRfspSpecificDeltaValues(ptCi, pReportConfig, pRfspThDelta);
    }
}

/****************************************************************************
 * @brief           Report Candidate is modified for Nrppa purpose.
 *                  It will be modified based on ECID Measurement Initiation Request from AMF
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       pCandidate : pointer to report config which can be installed on UE / reportConfigurationConfUe_type*
 * @param[in]       reportPurpose : Purpose of the target report configuration. / uint8_t
 * @return          status : GOOD
 *****************************************************************************/
int16_t VCCB_ModifyReportConfiguration_NrppaPeriodical(callInfo_type *ptCi,
    reportConfigurationConfUe_type *pReportConfigCandidate, const reportConfigurationBaseDb_type dbObject,
    enumMeasurementReportType reportType)
{
    AUTO_TRACE_FUNC;

    uint8_t searchItem, numMeasQuan, numIratMeasQuan;
    uint8_t includeRsrp = FALSE, includeRsrq = FALSE;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (ptCi->NrPpaContext.reportCharacteristics == NRPPA_ReportCharacteristics_periodic)
    {
        pReportConfigCandidate->reportAmount = reportAmount_infinity;
        pReportConfigCandidate->reportInterval = (enumReportInterval)ptCi->NrPpaContext.measurementPeriodicity;
    }
    else /*On Demand*/
    {
        if (reportType == measReport_periodical)
        {
            pReportConfigCandidate->reportAmount = dbObject.reportAmountNrppa;
        }
        else if (reportType == measReport_periodicalInterRat)
        {
            pReportConfigCandidate->reportAmount = dbObject.reportAmountNrppaIrat;
        }
    }

    /*Mark the item to need measConfig, NR*/
    numMeasQuan =
        (sizeof(ptCi->NrPpaContext.measuredQuantitiesItem) / sizeof(ptCi->NrPpaContext.measuredQuantitiesItem[0]));

    for (searchItem = 0; searchItem < numMeasQuan; searchItem++)
    {
        if (ptCi->NrPpaContext.measuredQuantitiesItem[searchItem] == NRPPA_sS_RSRP)
        {
            includeRsrp = TRUE;
        }
        if (ptCi->NrPpaContext.measuredQuantitiesItem[searchItem] == NRPPA_sS_RSRQ)
        {
            includeRsrq = TRUE;
        }
    }

    /*Mark the item to need measConfig, EUTRA*/
    numIratMeasQuan = (sizeof(ptCi->NrPpaContext.iratMeasuredQuantitiesItem) /
                       sizeof(ptCi->NrPpaContext.iratMeasuredQuantitiesItem[0]));

    for (searchItem = 0; searchItem < numIratMeasQuan; searchItem++)
    {
        if (ptCi->NrPpaContext.iratMeasuredQuantitiesItem[searchItem] == NRPPA_eUTRA)
        {
            includeRsrp = TRUE;
            includeRsrq = TRUE;
        }
    }

    pReportConfigCandidate->reportQuantityCell.rsrp = CI_no_use;
    pReportConfigCandidate->reportQuantityCell.rsrq = CI_no_use;
    pReportConfigCandidate->reportQuantityCell.sinr = CI_no_use;

    if (includeRsrp)
    {
        pReportConfigCandidate->reportQuantityCell.rsrp = CI_use;
    }
    if (includeRsrq)
    {
        pReportConfigCandidate->reportQuantityCell.rsrq = CI_use;
    }

    return GOOD;
}

/**
 * @brief This function sets up beam measurement for LTM
 *        reportQuantityRS-Indexes, maxNrofRS-IndexesToReport, includeBeamMeasurements
 * @param rCall Call information
 * @param reportConfigCandidate The report configuration candidate to be configured for beam measurements.
 * @return void
 */
void FnVCCB_SetBeamMeasurementForLtm(callInfo_type &rCall, reportConfigurationConfUe_type &reportConfigCandidate, CellNum_type cellNum)
{
    if (not FnVCCB_IsBeamMeasConfigNeed(rCall, cellNum))
        return;

    switch (reportConfigCandidate.reportType)
    {
        case measReport_A3:
        case measReport_A4:
        case measReport_A5:
            break;

        default:
            return;
    }

    const uint8_t rsrp = CI_use;
    const uint8_t rsrq = CI_use; // SVR26A no_use -> use FGR-MC1034:FR120
    const uint8_t sinr = CI_no_use;
    reportQuantity_type reportQuantity{rsrp, rsrq, sinr};
    FnVCCB_SetReportQuantityRsIndexes(reportConfigCandidate, reportQuantity);

    const uint8_t maxNrOfRsIndexesValue = 4;
    FnVCCB_SetMaxNrOfRsIndexesToReport(reportConfigCandidate, maxNrOfRsIndexesValue);

    FnVCCB_SetIncludeBeamMeas(reportConfigCandidate);
}

/****************************************************************************
 * @brief           This function disables report config useAllowedCellList
 *                  if measObject added-to-installation version
 *                  do not have allowed cells set. This is needed in case measObject is added separately from reportConfig.
 *
 * @param[in]       ptCi : reference to call configuration. / callInfo_type&
 * @param[in]       rRc : reference to report config which can be installed on UE / reportConfigurationConfUe_type&
 * @param[in]       rMo : reference to meas object which can be installed on UE / minimalMeasObjectConfUe_type&
 *****************************************************************************/
void FnVCCB_CorrectDeadMeasurementDueToAllowedCells(
    callInfo_type &rCall, reportConfigurationConfUe_type &rRc, const minimalMeasObjectConfUe_type &rMo)
{
    AUTO_TRACE_FUNC;

    if ((measRatNr != rMo.ratType) || (measReport_A4 != rRc.reportType) ||
        (FALSE == rRc.reportConfiguration.eventBased.event.A4.useAllowedCellList))
    {
        return;
    }

    // get allowed cells status on a corresponding meas object which is already added for installation
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(rCall);
    const measurementObjectUe_type *pUeObj = FnVCCB_FindNRMeasObjectInMeasProc(rMeasProc, rMo.rat.nr);
    if (pUeObj && (0 == pUeObj->conf.rat.nr.minimal.allowedCells.numOfPciRanges))
    {
        VCCB_PRINT_CALL_MEASUREMENTS(
            &rCall, "A4.useAllowedCellList is disabled because measObject added separately has empty allowedCells.\n");
        rRc.reportConfiguration.eventBased.event.A4.useAllowedCellList = FALSE;
    }
}

/****************************************************************************
 * @brief           Report Candidate is modified with LBM deltas if applicable
 *
 * @param[in]       rCi : Reference to call configuration. / const callInfo_type&
 * @param[in]       cellNum: cellNum of cell on whose configuration the behavior is based (i.e. source or for example HO target)
 * @param[in]       rRCCandidate : reference to report config which can be installed on UE / reportConfigurationConfUe_type&
 * @param[in]       finder : reference to a VCCB_RptCfgAndMeasObjDbFinder object containing selected MO idx information
 * @return          void
 *****************************************************************************/
void FnVCCB_ApplyLbmDeltasIfNeeded(
        const callInfo_type& rCi, const CellNum_type cellNum,
        reportConfigurationConfUe_type& rRCCandidate,
        const VCCB_RptCfgAndMeasObjDbFinder& finder)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_VALID_CELLNUM_VOID(cellNum);

    if (!((measReport_A2 == rRCCandidate.reportType) && (a2Purpose_scellRelease == rRCCandidate.reportPurpose)) &&
            !((measReport_A4 == rRCCandidate.reportType) && (a4Purpose_scellAddition == rRCCandidate.reportPurpose)))
    {
        return;
    }

    const VccbCellInfo_type& rCell = CELLINFO[cellNum];
    if (measRatEutra == finder._measObjectDbFinder._ratType)
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "[LBM Specific Meas] Does not apply to EUTRA!\n");
        return;
    }

    if (NR_LBM_DISABLE == rCell.nrLbmConfigurationIndex)
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "[LBM Specific Meas] NR LBM window is NR_LBM_DISABLE!\n");
        return;
    }

    const uint8_t adjustedLbmWindowIndex = static_cast<uint8_t>(rCell.nrLbmConfigurationIndex - 1);
    const auto beginMo = std::begin(rCell.lbmSpecificMeasurementData.moListPerLbmParameterSet[adjustedLbmWindowIndex].mo);
    const auto endMo = std::end(rCell.lbmSpecificMeasurementData.moListPerLbmParameterSet[adjustedLbmWindowIndex].mo);
    const auto moToApply = std::find_if(
            beginMo,
            endMo,
            [&finder] (const lbmSpecificMeasObject_type& mo)
            {
            return ((CI_use == mo.usage) &&
                    (mo.targetMeasObjectIndex == finder._measObjectDbFinder._pMeasObjDbIdx));
            });
    if (moToApply == endMo)
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "[LBM Specific Meas] Target Meas Object Entries Index (%u) not found in LBM specific meas!\n",
                finder._measObjectDbFinder._pMeasObjDbIdx);
        return;
    }

    int16_t delta = 0;
    VCCB_PRINT_CALL_COMMENT(&rCi, "[LBM Specific Meas] Applying deltas for report type %d, LBM Index: %u!\n",
            rRCCandidate.reportType, adjustedLbmWindowIndex);
    if (measReport_A2 == rRCCandidate.reportType)
    {
        const enumMeasTriggerQuantityChoice quantity =
            static_cast<enumMeasTriggerQuantityChoice>(rRCCandidate.reportConfiguration.eventBased.event.A2.a2_Threshold.quantity);
        switch (quantity)
        {
            case choice_rsrp:
                delta = moToApply->a2ScellReleaseDelta.thDeltaRsrp;
                break;
            case choice_rsrq:
                delta = moToApply->a2ScellReleaseDelta.thDeltaRsrq;
                break;
            default:
                delta = 0;
                break;
        }

        VCCB_ModifySelectedThresholds_ApplyDelta(
                &rCi, rRCCandidate.reportConfiguration.eventBased.event.A2.a2_Threshold.value, delta);
    }
    else if (measReport_A4 == rRCCandidate.reportType)
    {
        const enumMeasTriggerQuantityChoice quantity =
            static_cast<enumMeasTriggerQuantityChoice>(rRCCandidate.reportConfiguration.eventBased.event.A4.a4_Threshold.quantity);
        switch (quantity)
        {
            case choice_rsrp:
                delta = moToApply->a4ScellAdditionDelta.thDeltaRsrp;
                break;
            case choice_rsrq:
                delta = moToApply->a4ScellAdditionDelta.thDeltaRsrq;
                break;
            default:
                delta = 0;
                break;
        }

        VCCB_ModifySelectedThresholds_ApplyDelta(
                &rCi, rRCCandidate.reportConfiguration.eventBased.event.A4.a4_Threshold.value, delta);
    }
}

/****************************************************************************
 * @brief           Part of VCCB_CanMOAndRCBeAddedWithCandidates interface:
 *                  prepares the candidate for the report config (RC) which can be installed on UE.
 *                  Before calling this function you must call VCCB_CanReportConfigBeAdded first and check if it returns
 *                  GOOD!
 *
 * @param[in]       ptCi          : Pointer to call configuration. / callInfo_type*
 * @param[in]       cellNum       : Cell number. / CellNum_type/uint16_t
 * @param[in]       reportType    : Type of the target report configuration. / enumMeasurementReportType
 * @param[in]       reportPurpose : Purpose of the target report configuration. / uint8_t
 * @param[in]       frequency     : Frequency to measure (SSB or CSI-RS). / Arfcn_type/uint32_t
 * @param[in]       finder        : initialized finder object for matching report config and measurement object  / const
 *                                  VCCB_RptCfgAndMeasObjDbFinder&
 * @param[in]       rMoCandidate  : reference to meas object which can be installed on UE
 * @param[in]       dbObject      : reference to DB version of report config / reportConfigurationBaseDb_type
 * @param[in]       isReportConfigUeSpecific : indicates whether ue specific config was used to create pRCCandidate /
 *                                             bool
 * @param[out]      pRCCandidate  : pointer to report config which can be installed on UE /
 *                                  reportConfigurationConfUe_type*
 ****************************************************************************/
void VCCB_PrepareReportConfigUeCandidate(callInfo_type *ptCi, CellNum_type cellNum,
    enumMeasurementReportType reportType, uint8_t reportPurpose, Arfcn_type frequency,
    const VCCB_RptCfgAndMeasObjDbFinder &finder, const minimalMeasObjectConfUe_type &rMoCandidate,
    const reportConfigurationBaseDb_type &dbObject, bool isReportConfigUeSpecific,
    reportConfigurationConfUe_type *pRCCandidate)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pRCCandidate);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    VCCB_CreateReportConfigUeFromDb(dbObject, *pRCCandidate,
        VCCB_PrepareTransformConfig(*ptCi, CELLINFO[cellNum], frequency, isReportConfigUeSpecific));

    // Modify for Nrppa only
    if ((reportType == measReport_periodical && reportPurpose == periodicalPurpose_nrppa) ||
        (reportType == measReport_periodicalInterRat && reportPurpose == periodicalInterRATPurpose_nrppa))
    {
        int16_t status = VCCB_ModifyReportConfiguration_NrppaPeriodical(ptCi, pRCCandidate, dbObject, reportType);
        if (GOOD != status)
        {
            VCCB_PRINT_ERROR("VCCB_ModifyReportConfiguration_NrppaPeriodical ERROR!!\n");
        }
    }
    else if ((measReport_periodical == reportType && periodicalPurpose_ueMeasForSon == reportPurpose) ||
             (measReport_periodicalInterRat == reportType && periodicalInterRATPurpose_ueMeasForSon == reportPurpose))
    {
        VCCB_ModifyReportConfiguration_UeMeasForSon(pRCCandidate);
    }
    else if ((measReport_periodical == reportType && periodicalPurpose_scellRelease == reportPurpose))
    {
        VCCB_ModifyReportConfiguration_PeriodicalScellRelease(ptCi, pRCCandidate);
    }

    // modify trigger quantity
    VCCB_ReplaceWithAlternativeSpidBasedThreshold(ptCi, pRCCandidate, CAN_UE_REPORT_SINR(ptCi, frequency));
    VCCB_HandlePowerClassDeltas(ptCi, pRCCandidate, rMoCandidate, cellNum);
    VCCB_ModifyReportConfiguration_Mobility(ptCi, pRCCandidate, cellNum, finder);
    VCCB_ModifyReportConfiguration_A2spidPscellReleaseThreshold(ptCi, &finder._rDbConf, pRCCandidate);

    VCCB_ModifyReportConfiguration_ReportQuantity(ptCi, pRCCandidate->reportQuantityCell, finder);
    VCCB_ModifyReportConfiguration_IncludeCommonLocationInfo(ptCi, pRCCandidate, cellNum);

    VCCB_ModifyReportConfiguration_useT312(ptCi, pRCCandidate);

    // RFSP Specific Measurement Configuration
    VCCB_ApplyRfspSpecificDeltaThresholdIfNeeded(ptCi, pRCCandidate, cellNum, rMoCandidate);

    // Set Beam Measurement for LTM
    FnVCCB_SetBeamMeasurementForLtm(*ptCi, *pRCCandidate, cellNum);

    // FGR-MC1026
    VCCB_ModifyReportConfig_HighSpeedUe(*ptCi, *pRCCandidate, dbObject, cellNum);

    FnVCCB_CorrectDeadMeasurementDueToAllowedCells(*ptCi, *pRCCandidate, rMoCandidate);

    // FGR-LC0740 LBM
    FnVCCB_ApplyLbmDeltasIfNeeded(*ptCi, cellNum, *pRCCandidate, finder);
}

/****************************************************************************
 * @brief           Sets T312 related fields (timerT312, useT312) based on the current call Connectivity configuration
 *
 * @param[in]       ptCi : Pointer to the current call type info
 * @param[out]      pUeObj : Pointer to the measurement object NR to be set
 * @return          void
 ****************************************************************************/
void VCCB_SetMoT312(callInfo_type const *const ptCi, minimalMeasObjectNRUe_type *pUeObj)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pUeObj);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    gnbConfig_type *const pGnbCfg = &GNBINFO[ptCi->gnbNum].cfg;

    if (VCCB_CheckEnableT312(ptCi))
    {
        pUeObj->T312.timerT312 = pGnbCfg->T312.timerT312;
        pUeObj->T312.useT312 = pGnbCfg->T312.useT312;
    }
    else
    {
        pUeObj->T312.useT312 = false;
    }
}

/****************************************************************************
 * @brief           Prepares meas object NR candidate
 *
 * @param[in]       rCi           : Reference to call configuration. / callInfo_type&
 * @param[in]       cellNum       : Cell number. / uint16_t
 * @param[in]       pMoNrDb       : pointer to meas object NR base / measurementObjectNRBaseDb_type*
 * @param[out]      pMOCandidate  : pointer to meas object which can be installed on UE / measurementObjectConfUe_type*
 * @return          status        : true, false / bool
 ****************************************************************************/
bool VCCB_PrepareMeasObjectNrUeCandidate(callInfo_type &rCi, CellNum_type cellNum,
    const measurementObjectNRBaseDb_type *pMoNrDb, minimalMeasObjectConfUe_type *pMOCandidate)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(pMoNrDb, false);
    VALID_E_POINT_CHECK_RET_VAL(pMOCandidate, false);
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);

    uint16_t nRFrequencyBand = VCCB_GetMoNrBandForUe(&rCi, pMoNrDb);
    if (0 == nRFrequencyBand)
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "MO ssbArfcn(%u) bandNR not supported by UE!\n", pMoNrDb->ssbFrequency);
        return false;
    }

    pMOCandidate->ratType = measRatNr;
    pMOCandidate->rat.nr = VCCB_CreateMeasObjectUeFromDb(&rCi, cellNum, *pMoNrDb);
    pMOCandidate->rat.nr.freqBandIndicatorNR = nRFrequencyBand;
    VCCB_SetMoT312(&rCi, &pMOCandidate->rat.nr);
    const auto &rCell = CELLINFO[cellNum];
    VCCB_UpdateIntraFreqMeasObjectCandidateForNcdSsb(rCi, rCell, pMOCandidate->rat.nr);

    return true;
}

/****************************************************************************
 * @brief           Prepares meas object EUTRA candidate
 *
 * @param[in]       rCi           : Reference to call configuration. / callInfo_type&
 * @param[in]       cellNum       : Cell number. / uint16_t
 * @param[in]       pMoEutraDb    : pointer to meas object EUTRA base / measurementObjectEUTRABaseDb_type*
 * @param[out]      pMOCandidate  : pointer to meas object which can be installed on UE / minimalMeasObjectConfUe_type*
 * @return          status        : true, false / bool
 ****************************************************************************/
bool VCCB_PrepareMeasObjectEutraUeCandidate(
    callInfo_type &rCi, const measurementObjectEUTRABaseDb_type *pMoEutraDb, minimalMeasObjectConfUe_type *pMOCandidate)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(pMoEutraDb, false);
    VALID_E_POINT_CHECK_RET_VAL(pMOCandidate, false);

    pMOCandidate->ratType = measRatEutra;
    pMOCandidate->rat.eutra = VCCB_CreateMeasObjectUeFromDb(*pMoEutraDb);

    Arfcn_type earfcn = 0;
    const uint16_t band = VCCB_GetMoEutraBandForUe(&rCi, pMoEutraDb, &earfcn);
    if (0 == band)
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "MO earfcn(%u) not supported by UE!\n", pMoEutraDb->carrierFreq);
        return false;
    }
    pMOCandidate->rat.eutra.overlappedCarrierFreq = earfcn;
    return true;
}

/****************************************************************************
 * @brief           Part of VCCB_CanMOAndRCBeAddedWithCandidates interface:
 *                  prepares the candidate for the meas object which can be installed on UE.
 *                  Before calling this function you must call VCCB_CanMeasObjBeAdded first and check if it returns
 *true!
 *
 * @param[in]       ptCi          : Pointer to call configuration. / callInfo_type*
 * @param[in]       cellNum       : Cell number. / uint16_t
 * @param[in]       frequency     : Frequency to measure (SSB or CSI-RS). / Arfcn_type/uint32_t
 * @param[in]       finder        : initialized finder object for matching report config and measurement object  / const
 *VCCB_MeasObjDbFinder&
 * @param[out]      pMOCandidate  : pointer to meas object which can be installed on UE / minimalMeasObjectConfUe_type*
 * @return          status        : true, false / bool
 ****************************************************************************/
bool VCCB_PrepareMeasObjectUeCandidate(callInfo_type &rCi, CellNum_type cellNum, const VCCB_MeasObjDbFinder &finder,
    minimalMeasObjectConfUe_type *pMOCandidate)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(pMOCandidate, false);

    bool status{true};

    if (!finder.isValid())
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "DbFinder didn't find matching report config and measurement object!\n");
        return false;
    }

    switch (finder._ratType)
    {
        case measRatNr:
        {
            status = VCCB_PrepareMeasObjectNrUeCandidate(rCi, cellNum, &finder._pDbObjNr->base, pMOCandidate);
            break;
        }
        case measRatEutra:
        {
            status = VCCB_PrepareMeasObjectEutraUeCandidate(rCi, &finder._pDbObjEutra->base, pMOCandidate);
            break;
        }
        default:
            break;
    }

    return status;
}

/****************************************************************************
 * @brief           Functor for matching frequency against measurementObjectUe_type (EUTRA) or
 *measurementObjectEUTRADb_type
 *
 * @param[in]       freq : SSB frequency to match against. / Arfcn_type/uint32_t
 * @param[in]       csirsFrequency : CSI-RS frequency to match against. / Arfcn_type/uint32_t
 ****************************************************************************/
struct VCCB_FrequencyMatcherEutra
{
    VCCB_FrequencyMatcherEutra(Arfcn_type freq) : _freq(freq) {}

    bool operator()(const measurementObjectUe_type &measObj) const
    {
        return (CI_use == measObj.usage) && (measRatEutra == measObj.conf.ratType) &&
               (_freq == measObj.conf.rat.eutra.minimal.carrierFreq);
    }

    bool operator()(const measurementObjectEUTRADb_type &measObj) const
    {
        return (CI_use == measObj.base.usage) && (_freq == measObj.base.carrierFreq);
    }

    Arfcn_type _freq;
};

bool VCCB_IsReportSupportedByUe(const callInfo_type &rCi, enumMeasurementReportType reportType)
{
    AUTO_TRACE_FUNC;

    if (measReport_B1Eutra == reportType || measReport_B2Eutra == reportType)
    {
        if (TRUE != rCi.ueInfo.ueCapa.nr.measAndMob.eventB_MeasAndReport)
        {
            VCCB_PRINT_CALL_COMMENT(&rCi, "UE does NOT support EUTRA measurement and event B triggered reporting.\n");
            return false;
        }
    }
    else if (measReport_periodicalInterRat == reportType)
    {
        if (TRUE != rCi.ueInfo.ueCapa.nr.measAndMob.periodicEUTRA_MeasAndReport)
        {
            VCCB_PRINT_CALL_COMMENT(&rCi, "UE does NOT support periodic EUTRA measurement and reporting.\n");
            return false;
        }
    }

    return true;
}

void VCCB_ClearMeasConfigurationAssociatedWithReportConfig(
    callInfo_type *ptCi, bool (*predicate)(const reportConfigurationConfUe_type &))
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(predicate);

    VCCB_PRINT_CALL_DATA(ptCi, "[clear-meas-conf] BEGIN\n");

    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);
    auto &rc = rMeasConf.reportConfigurations;
    auto &mi = rMeasConf.measurementIdentities;
    auto &mo = rMeasConf.measurementObjects;

    // remove all associated meas ids and collect associated meas object ids and report config ids along the way
    auto doesRcMeetCriteria = [predicate, &rc](uint8_t rcId)
    {
        auto rcBegin = std::begin(rc.installedItems);
        auto rcEnd = std::end(rc.installedItems);
        return rcEnd != std::find_if(rcBegin, rcEnd,
                            [rcId, predicate](const reportConfigurationInstalledUe_type &item)
                            { return (CI_use == item.usage) && (rcId == item.objectId) && predicate(item.conf); });
    };
    auto deactivateMeasId = [ptCi](measurementIdentity_type &item)
    {
        item.usage = CI_no_use;
        VCCB_PRINT_CALL_DATA(ptCi, "[clear-meas-conf] MI with id(%d), measObjectId(%d), reportConfigId(%d) removed.\n",
            item.objectId, item.measObjectId, item.reportConfigId);
    };
    staticUnorderedSet<size_t, VCCB_ARRAY_COUNT(mo.installedItems)> affectedMoIds{};
    staticUnorderedSet<size_t, VCCB_ARRAY_COUNT(rc.installedItems)> affectedRcIds{};
    auto miBegin = std::begin(mi.installedItems);
    auto miEnd = std::end(mi.installedItems);
    std::for_each(miBegin, miEnd,
        [&deactivateMeasId, &doesRcMeetCriteria, &affectedMoIds, &affectedRcIds](measurementIdentity_type &item)
        {
            if (CI_use != item.usage)
            {
                return;
            }
            if (doesRcMeetCriteria(item.reportConfigId))
            {
                deactivateMeasId(item);
                affectedMoIds.insert(item.measObjectId);
                affectedRcIds.insert(item.reportConfigId);
            }
        });

    // remove all affected report configs
    auto rcBegin = std::begin(rc.installedItems);
    auto rcEnd = std::end(rc.installedItems);
    auto deactivateReportConfig = [ptCi, &affectedRcIds](reportConfigurationInstalledUe_type &item)
    {
        if ((CI_use == item.usage) && affectedRcIds.contains(item.objectId))
        {
            item.usage = CI_no_use;
            VCCB_PRINT_CALL_DATA(ptCi, "[clear-meas-conf] RC with id(%d), type(%d), purpose(%d) removed.\n",
                item.objectId, item.conf.reportType, item.conf.reportPurpose);
        }
    };
    std::for_each(rcBegin, rcEnd, deactivateReportConfig);

    // collect used meas objects
    staticUnorderedSet<size_t, VCCB_ARRAY_COUNT(mo.installedItems)> usedMoIds{};
    std::for_each(miBegin, miEnd,
        [&usedMoIds](const measurementIdentity_type &item)
        {
            if (CI_no_use == item.usage)
            {
                return;
            }
            usedMoIds.insert(item.measObjectId);
        });

    // remove meas objects which lost association from removed meas id and is not associated with any other meas id
    auto isOrphaned = [&affectedMoIds, &usedMoIds](const measurementObjectUe_type &moItem)
    {
        if (CI_no_use == moItem.usage)
        {
            return false;
        }
        return affectedMoIds.contains(moItem.objectId) && !usedMoIds.contains(moItem.objectId);
    };
    auto deactivateMeasObject = [ptCi](measurementObjectUe_type &item)
    {
        item.usage = CI_no_use;
        VCCB_PRINT_CALL_DATA(ptCi, "[clear-meas-conf] MO with id(%d), freq(%d) removed.\n", item.objectId,
            ((measRatNr == item.conf.ratType) ? VCCB_GetMeasObjectSsbFreq(item) : VCCB_GetMeasObjectCarrierFreq(item)));
    };
    auto moBegin = std::begin(mo.installedItems);
    auto moEnd = std::end(mo.installedItems);
    std::for_each(moBegin, moEnd,
        [&deactivateMeasObject, &isOrphaned](measurementObjectUe_type &item)
        {
            if (isOrphaned(item))
            {
                deactivateMeasObject(item);
            }
        });

    VCCB_PRINT_CALL_DATA(ptCi, "[clear-meas-conf] END\n");
}

void VCCB_fillQuantityInfo(const enumMeasTriggerQuantityChoice quantity, quantityInfo_type &quantityInfo)
{
    AUTO_TRACE_FUNC;
    if (choice_rsrp == quantity)
    {
        quantityInfo.isTriggeringOptionSinr = false;
        quantityInfo.triggeringOption = choice_rsrp_option;
    }
    else if (choice_rsrq == quantity)
    {
        quantityInfo.isTriggeringOptionSinr = false;
        quantityInfo.triggeringOption = choice_rsrq_option;
    }
    else if (choice_sinr == quantity)
    {
        quantityInfo.isTriggeringOptionSinr = true;
    }
}

void VCCB_FillMultipleTimeToTrigger(const enumMeasTriggerQuantityChoice quantity,
    const eventBasedReportConfigurationExtensionNR_type &src, eventBasedReportConfigurationNR_type &dst)
{
    AUTO_TRACE_FUNC;
    if (choice_rsrp == quantity)
    {
        dst.timeToTrigger = src.event.A2.timeToTriggerRsrp;
    }
    else if (choice_rsrq == quantity)
    {
        dst.timeToTrigger = src.event.A2.timeToTriggerRsrq;
    }
    else if (choice_sinr == quantity)
    {
        dst.timeToTrigger = src.event.A2.timeToTriggerSinr;
    }
}

void VCCB_FillReportConfigQuantityInfoPerReportType(
    reportConfigurationBaseDb_type &reportConfigurationDb, const enumMeasTriggerQuantityChoice quantity)
{
    AUTO_TRACE_FUNC;

    switch (reportConfigurationDb.reportType)
    {
        case measReport_A1:
        {
            VCCB_fillQuantityInfo(
                quantity, reportConfigurationDb.reportConfiguration.eventBased.event.A1.a1_Threshold.quantityInfo);
            break;
        }
        case measReport_A2:
        {
            VCCB_fillQuantityInfo(
                quantity, reportConfigurationDb.reportConfiguration.eventBased.event.A2.a2_Threshold.quantityInfo);
            break;
        }
        case measReport_A3:
        {
            VCCB_fillQuantityInfo(
                quantity, reportConfigurationDb.reportConfiguration.eventBased.event.A3.a3_Offset.quantityInfo);
            break;
        }
        case measReport_A4:
        {
            VCCB_fillQuantityInfo(
                quantity, reportConfigurationDb.reportConfiguration.eventBased.event.A4.a4_Threshold.quantityInfo);
            break;
        }
        case measReport_A5:
        {
            VCCB_fillQuantityInfo(
                quantity, reportConfigurationDb.reportConfiguration.eventBased.event.A5.a5_Thresholds.quantityInfo);
            break;
        }
        case measReport_A6:
        {
            VCCB_fillQuantityInfo(
                quantity, reportConfigurationDb.reportConfiguration.eventBased.event.A6.a6_Offset.quantityInfo);
            break;
        }
        case measReport_B1Eutra:
        {
            VCCB_fillQuantityInfo(quantity,
                reportConfigurationDb.reportConfiguration.eventInterRat.event.B1Eutra.b1_thresholdEUTRA.quantityInfo);
            break;
        }
        case measReport_B2Eutra:
        {
            VCCB_fillQuantityInfo(quantity,
                reportConfigurationDb.reportConfiguration.eventInterRat.event.B2Eutra.b2_thresholds.quantityInfo);
            break;
        }
        case measReport_reportCGI:
        case measReport_reportCGIEutra:
        case measReport_periodical:
        case measReport_periodicalInterRat:
        default:
        {
            VCCB_PRINT_ERROR(
                "VCCB_FillReportConfigQuantityInfoPerReportType() failed, unsupported reportType(%d) to fill "
                "quantityInfo struct\n",
                reportConfigurationDb.reportType);
        };
    }
}

const char *getReportQuantityStr(const uint8_t quantity)
{
    return (choice_rsrp == quantity   ? "(RSRP)"
            : choice_rsrq == quantity ? "(RSRQ)"
            : choice_sinr == quantity ? "(SINR)"
                                      : "Unknown");
}

/****************************************************************************
 * @brief           Get Applicable NCD SSB
 *
 * @param[in]       rCi : Reference to call configuration. / callInfo_type
 * @param[in]       rCell : Reference to cell configuration. / VccbCellInfo_type
 * @param[in]       rMeasObjectCandidate : reference to meas object to install / rMeasObjectCandidate*
 * @return          NcdSsbFreqEntries: simpleVector<NcdSsbFreqEntry_type, MAX_NCD_FREQ_ENTRIES>
 ****************************************************************************/
NcdSsbFreqEntries getApplicableNcdSsbs(
    const callInfo_type &rCi, const VccbCellInfo_type &rCell, const minimalMeasObjectConfUe_type &rMeasObjectCandidate)
{
    AUTO_TRACE_FUNC;
    NcdSsbFreqEntries ncdSsbs{};

    if (measRatNr != rMeasObjectCandidate.ratType)
    {
        return ncdSsbs;
    }

    VCCB_CHECK_E_RANGE_AND_VAL(rCi.gnbNum, MAX_GNB_PER_SYS, ncdSsbs);
    const auto &gnb = GNBINFO[rCi.gnbNum];
    const auto cdSsbFreq = rMeasObjectCandidate.rat.nr.ssbFrequency;

    if (!VCCB_IsRedCapUeForSA(rCi))
    {
        return ncdSsbs;
    }
    if (cdSsbFreq == rCell.ssbArfcn)
    {
        return ncdSsbs;
    }

    if (const auto ncdIndex = VCCB_FindCdToNcdMappingIdx(gnb.ncdSsbConfig, cdSsbFreq); ncdIndex)
    {
        auto range = rangeAdaptors::filtered(gnb.ncdSsbConfig.cdToNcdMappingEntries[ncdIndex.value()].ncdSsbFreqEntries,
            [](const NcdSsbFreqEntry_type &ncdSsb) { return ncdSsb.usage == CI_use; });
        for (const auto &ncdSsb : range)
        {
            ncdSsbs.push_back(ncdSsb);
        }
    }
    return ncdSsbs;
}
void setTaintOnInstalledMeasConfig(callInfo_type &rCi, uint8_t flag)
{
    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(rCi);
    for (auto &installedMO : rMeasConf.measurementObjects.installedItems)
    {
        if (CI_use == installedMO.usage)
        {
            installedMO.isTainted = (flag & e_BitMask_1bit);
        }
    }
    for (auto &installedRC : rMeasConf.reportConfigurations.installedItems)
    {
        if (CI_use == installedRC.usage)
        {
            installedRC.isTainted = (flag & e_BitMask_1bit);
        }
    }
    for (auto &installedMI : rMeasConf.measurementIdentities.installedItems)
    {
        if (CI_use == installedMI.usage)
        {
            installedMI.isTainted = (flag & e_BitMask_1bit);
        }
    }
}

void taintAllInstalledMeasConfig(callInfo_type &rCi) { setTaintOnInstalledMeasConfig(rCi, VCCB_FLAG_ON); }

void clearTaintAllInstalledMeasConfig(callInfo_type &rCi) { setTaintOnInstalledMeasConfig(rCi, VCCB_FLAG_OFF); }

/****************************************************************************
 * @brief  Helper function which convert single quantity choice to meas quantity bitmask
 * @param  quantity            : enumMeasTriggerQuantityChoice
 * @return int (enum MeasurementQuantityBitmask)
 ****************************************************************************/
int VCCB_ConvertMeasQuantityToBitmask(const enumMeasTriggerQuantityChoice quantity)
{
    switch (quantity)
    {
        case choice_rsrp:
        {
            return MeasurementQuantityBitmask_RSRP;
        }
        case choice_rsrq:
        {
            return MeasurementQuantityBitmask_RSRQ;
        }
        case choice_sinr:
        {
            return MeasurementQuantityBitmask_SINR;
        }
        default:
        {
            return MeasurementQuantityBitmask_None;
        }
    }
}

/****************************************************************************
 * @brief  Helper function which convert meas quantity bitmask to quantities list
 * @param  quantitiesBitmask            : int (enum MeasurementQuantityBitmask)
 * @return QuantitiesList
 ****************************************************************************/
QuantitiesList VCCB_PrepareQuantitiesToInstall(const int quantitiesBitmask)
{
    QuantitiesList toInstallQuantitiesList{};
    if (quantitiesBitmask & MeasurementQuantityBitmask_RSRP)
    {
        toInstallQuantitiesList.push_back(choice_rsrp);
    }
    if (quantitiesBitmask & MeasurementQuantityBitmask_RSRQ)
    {
        toInstallQuantitiesList.push_back(choice_rsrq);
    }
    if (quantitiesBitmask & MeasurementQuantityBitmask_SINR)
    {
        toInstallQuantitiesList.push_back(choice_sinr);
    }
    return toInstallQuantitiesList;
}

bool VCCB_CompareTriggerQuantity(const reportConfigurationConfUe_type &lhs, const reportConfigurationConfUe_type &rhs)
{
    if (lhs.reportType != rhs.reportType)
    {
        return false;
    }
    const enumMeasurementReportType reportType = static_cast<enumMeasurementReportType>(lhs.reportType);
    bool triggerIsEqual = true;
    switch (reportType)
    {
        case measReport_A1:
        {
            triggerIsEqual = (lhs.reportConfiguration.eventBased.event.A1.a1_Threshold ==
                              rhs.reportConfiguration.eventBased.event.A1.a1_Threshold);
            break;
        }
        case measReport_A2:
        {
            triggerIsEqual = (lhs.reportConfiguration.eventBased.event.A2.a2_Threshold ==
                              rhs.reportConfiguration.eventBased.event.A2.a2_Threshold);
            break;
        }
        case measReport_A3:
        {
            triggerIsEqual = (lhs.reportConfiguration.eventBased.event.A3.a3_Offset ==
                              rhs.reportConfiguration.eventBased.event.A3.a3_Offset);
            break;
        }
        case measReport_A4:
        {
            triggerIsEqual = (lhs.reportConfiguration.eventBased.event.A4.a4_Threshold ==
                              rhs.reportConfiguration.eventBased.event.A4.a4_Threshold);
            break;
        }
        case measReport_A5:
        {
            triggerIsEqual = (lhs.reportConfiguration.eventBased.event.A5.a5_Thresholds ==
                              rhs.reportConfiguration.eventBased.event.A5.a5_Thresholds);
            break;
        }
        case measReport_A6:
        {
            triggerIsEqual = (lhs.reportConfiguration.eventBased.event.A6.a6_Offset ==
                              rhs.reportConfiguration.eventBased.event.A6.a6_Offset);
            break;
        }
        case measReport_B1Eutra:
        {
            triggerIsEqual = (lhs.reportConfiguration.eventInterRat.event.B1Eutra.b1_thresholdEUTRA ==
                              rhs.reportConfiguration.eventInterRat.event.B1Eutra.b1_thresholdEUTRA);
            break;
        }
        case measReport_B2Eutra:
        {
            triggerIsEqual = (lhs.reportConfiguration.eventInterRat.event.B2Eutra.b2_thresholds ==
                              rhs.reportConfiguration.eventInterRat.event.B2Eutra.b2_thresholds);
            break;
        }
        default:
            break;
    }
    return triggerIsEqual;
}

ssbMeasTiming_type FnVCCB_getCdSsbMeasInfo(const minimalMeasObjectNRUe_type &mo)
{
    AUTO_TRACE_FUNC;

    return ssbMeasTiming_type{
        .ssbFrequency = mo.ssbFrequency, .ssbSubcarrierSpacing = mo.ssbSubcarrierSpacing, .smtc1 = mo.smtc1};
}

ssbMeasTiming_type FnVCCB_getNcdSsbMeasInfo(const ncdSsbInfo_type &ncd)
{
    AUTO_TRACE_FUNC;

    return ssbMeasTiming_type{
        .ssbFrequency = ncd.ncdSsbArfcn, .ssbSubcarrierSpacing = ncd.ncdSsbSubcarrierSpacing, .smtc1 = ncd.ncdSmtc1};
}

void FnVCCB_updateInstalledWithNcdSsbInfoIfNeeded(
    const callInfo_type &rCi, minimalMeasObjectNRUe_type &installedMoNr, const minimalMeasObjectNRUe_type &newMoNr)
{
    AUTO_TRACE_FUNC;

    if (false == newMoNr.ncdSsbInfo.usage)
    {
        return;
    }
    if (true == installedMoNr.ncdSsbInfo.usage)
    {
        return;
    }
    if (FnVCCB_getCdSsbMeasInfo(installedMoNr) != FnVCCB_getNcdSsbMeasInfo(newMoNr.ncdSsbInfo))
    {
        return;
    }

    // this operation is needed because new measObject may not trigger to add/mod corresponding MeasObjectNR
    // and installed measObject will not be updated in VCCB_CommitMeasurementReconfiguration

    // Before:
    // +---------+----------------+----------------------+
    // |         | new measObject | installed measObject |
    // +---------+----------------+----------------------+
    // | CD-SSB  | A              | X                    |
    // | NCD-SSB | X              | (None)               |
    // +---------+----------------+----------------------+
    installedMoNr.ncdSsbInfo = newMoNr.ncdSsbInfo;
    installedMoNr.ssbFrequency = newMoNr.ssbFrequency;
    installedMoNr.ssbSubcarrierSpacing = newMoNr.ssbSubcarrierSpacing;
    installedMoNr.smtc1 = newMoNr.smtc1;
    // After:
    // +---------+----------------+----------------------+
    // |         | new measObject | installed measObject |
    // +---------+----------------+----------------------+
    // | CD-SSB  | A              | A                    |
    // | NCD-SSB | X              | X                    |
    // +---------+----------------+----------------------+

    VCCB_PRINT_CALL_MEASUREMENTS(&rCi, "Overwrite installed measObject: CD-SSB=%d and NCD-SSB=%d\n",
        installedMoNr.ssbFrequency, installedMoNr.ncdSsbInfo.ncdSsbArfcn);
}

}  // namespace

simpleVector<smtc1PerFreq_type, MAX_NBR_PER_CELL> VCCB_GetNbrMergedSmtc1PerSsbFreq(
    const callInfo_type &rCi, const uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, {});

    simpleVector<smtc1PerFreq_type, MAX_NBR_PER_CELL> smtc1PerFreqEntries{};
    simpleVector<uint32_t, MAX_NBR_PER_CELL> ssbArfcns{};

    for (uint16_t nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)
    {
        nbrGnbCellInfo_type *ptNbrGnbCell = nullptr;
        int16_t status = getNbrGnbCellByCellNbrIdx(cellNum, nbrIdx, &ptNbrGnbCell);

        if (nullptr == ptNbrGnbCell)
        {
            continue;
        }

        if (status != GOOD)
        {
            continue;
        }

        if (CI_use != ptNbrGnbCell->smtcStatus)
        {
            continue;
        }

        ssbArfcns.push_back(ptNbrGnbCell->ssbArfcn);
    }

    std::sort(ssbArfcns.begin(), ssbArfcns.end());
    const auto ssbArfcnsEndItAfterUnique = std::unique(ssbArfcns.begin(), ssbArfcns.end());
    ssbArfcns.erase(ssbArfcnsEndItAfterUnique, ssbArfcns.end());

    for (const auto &ssbArfcn : ssbArfcns)
    {
        smtc1PerFreq_type smtc1PerFreq{ssbArfcn, {}};
        smtc1PerFreqEntries.push_back(smtc1PerFreq);
    }

    for (uint16_t nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)
    {
        nbrGnbCellInfo_type *ptNbrGnbCell = nullptr;
        int16_t status = getNbrGnbCellByCellNbrIdx(cellNum, nbrIdx, &ptNbrGnbCell);

        if (nullptr == ptNbrGnbCell)
        {
            continue;
        }

        if (status != GOOD)
        {
            continue;
        }

        if (CI_use != ptNbrGnbCell->smtcStatus)
        {
            continue;
        }

        auto it = std::lower_bound(smtc1PerFreqEntries.begin(), smtc1PerFreqEntries.end(), ptNbrGnbCell->ssbArfcn,
            [](const smtc1PerFreq_type &smtc1PerFreq, const Arfcn_type &ssbArfcn)
            { return smtc1PerFreq.ssbArfcn < ssbArfcn; });

        if ((it != smtc1PerFreqEntries.end()) && (it->ssbArfcn == ptNbrGnbCell->ssbArfcn))
        {
            it->smtc1 = VCCB_MergeSmtc1(ptNbrGnbCell->smtc1, it->smtc1);
            VCCB_PRINT_CALL_SMTC1_MERGE_ALG(&rCi, "Merged smtc1(periodicity %d, duration %d) for SSB:%d \n",
                it->smtc1.periodicityAndOffset.periodicity, it->smtc1.duration, it->ssbArfcn);
        }
    }
    return smtc1PerFreqEntries;
}

class ScopedCachedNbrSmtc1PerFreq
{
    uint8_t threadId;

public:
    ScopedCachedNbrSmtc1PerFreq(const callInfo_type &rCi) : threadId(MAX_CALL_THREAD_NUM_VCCB)
    {
        cellSelection_type cellSelection = FnVCCB_GetCellSelectionForConfig(&rCi);
        const uint16_t cellNum = cellSelection.cellNum;
        VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
        VCCB_CHECK_E_RANGE_AND_VOID(rCi.myThreadId, MAX_CALL_THREAD_NUM_VCCB);
        this->threadId = rCi.myThreadId;

        cachedNbrSmtc1PerFreq[rCi.myThreadId].cellNumContext = cellNum;
        cachedNbrSmtc1PerFreq[rCi.myThreadId].smtc1PerFreqEntries = VCCB_GetNbrMergedSmtc1PerSsbFreq(rCi, cellNum);
    }
    ~ScopedCachedNbrSmtc1PerFreq()
    {
        if (MAX_CALL_THREAD_NUM_VCCB == threadId)
        {
            return;
        }
        cachedNbrSmtc1PerFreq[threadId].cellNumContext = MAX_CELL_NUM_VCCB;
        cachedNbrSmtc1PerFreq[threadId].smtc1PerFreqEntries.clear();
    }
};

uint16_t FnVCCB_updateCioDeltaNR(int cio)
{
    if (cio >= qOffset_plus_24)  // max value
    {
        return qOffset_plus_24;
    }

    if (cio <= qOffset_minus_24)  // min value
    {
        return qOffset_minus_24;
    }

    return static_cast<uint16_t>(cio);
}

qOffsetSSBRangeList_type FnVCCB_CioOptimization(qOffsetSSBRangeList_type cellIndividualOffset, int8_t cioDelta)
{
    qOffsetSSBRangeList_type appliedDeltaCio;
    appliedDeltaCio.rsrpOffsetSSB = (FnVCCB_updateCioDeltaNR(cellIndividualOffset.rsrpOffsetSSB + cioDelta) & 0x1F);
    appliedDeltaCio.rsrqOffsetSSB = (FnVCCB_updateCioDeltaNR(cellIndividualOffset.rsrqOffsetSSB + cioDelta) & 0x1F);
    appliedDeltaCio.sinrOffsetSSB = (FnVCCB_updateCioDeltaNR(cellIndividualOffset.sinrOffsetSSB + cioDelta) & 0x1F);
    return appliedDeltaCio;
}

bool VCCB_UpSortCellsToMeas(pairCellsToMeas &a, pairCellsToMeas &b)
{
    // priority : (FGR-SF0503 FR251)isSmallCellPci =TRUE > rank > idx
    if (a.second.isSmallCellPci == b.second.isSmallCellPci)
    {
        if (a.second.rank < b.second.rank)
        {
            return true;
        }
        if (a.second.rank == b.second.rank)
        {
            if (a.second.idx < b.second.idx)
            {
                return true;
            }
        }
        return false;
    }
    else if (a.second.isSmallCellPci == TRUE)
    {
        return true;
    }
    else
    {
        return false;
    }
}

qOffsetRangeValueList_type getQOffsetRangeListInDecibels(const qOffsetSSBRangeList_type &x)
{
    qOffsetRangeValueList_type result;
    result.rsrpValueSSB = qOffsetRangeToValue(static_cast<enumQOffsetRange>(x.rsrpOffsetSSB));
    result.rsrqValueSSB = qOffsetRangeToValue(static_cast<enumQOffsetRange>(x.rsrqOffsetSSB));
    result.sinrValueSSB = qOffsetRangeToValue(static_cast<enumQOffsetRange>(x.sinrOffsetSSB));
    return result;
}
qOffsetRangeValueList_type FnVCCB_CalculatedNrCioInDecibles(
    const qOffsetRangeValueList_type &a, const qOffsetRangeValueList_type &b)
{
    qOffsetRangeValueList_type result;
    result.rsrpValueSSB = a.rsrpValueSSB + b.rsrpValueSSB;
    result.rsrqValueSSB = a.rsrqValueSSB + b.rsrqValueSSB;
    result.sinrValueSSB = a.sinrValueSSB + b.sinrValueSSB;
    return result;
}
qOffsetSSBRangeList_type FnVCCB_GetNrQOOffsetRangeListFromValueList(qOffsetRangeValueList_type v)
{
    qOffsetSSBRangeList_type result;
    result.rsrpOffsetSSB = static_cast<uint32_t>(nrValueToQOOffsetRange(v.rsrpValueSSB)) & e_BitMask_5bit;
    result.rsrqOffsetSSB = static_cast<uint32_t>(nrValueToQOOffsetRange(v.rsrqValueSSB)) & e_BitMask_5bit;
    result.sinrOffsetSSB = static_cast<uint32_t>(nrValueToQOOffsetRange(v.sinrValueSSB)) & e_BitMask_5bit;
    return result;
}

int FnVCCB_AdjustCalculatedCio(int value)
{
    switch (value)
    {
        case -24 ... - 6:
        case 6 ... 24:
            if (value & 1)
            {
                return value + (value > 0 ? -1 : 1);
            }
            break;
        default:
            if (value < -24)
                value = -24;
            else if (value > 24)
                value = 24;
            break;
    }
    return value;
}

qOffsetRangeValueList_type FnVCCB_AdjustCalculatedNrCioValue(qOffsetRangeValueList_type v)
{
    qOffsetRangeValueList_type result;
    result.rsrpValueSSB = static_cast<int16_t>(FnVCCB_AdjustCalculatedCio(v.rsrpValueSSB));
    result.rsrqValueSSB = static_cast<int16_t>(FnVCCB_AdjustCalculatedCio(v.rsrqValueSSB));
    result.sinrValueSSB = static_cast<int16_t>(FnVCCB_AdjustCalculatedCio(v.sinrValueSSB));
    return result;
}

void FnVCCB_CalculateNrCio(callInfo_type *ptCi, cellsToMeasInfo_type &candidateCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    candidateCell.cellIndividualOffset =
        FnVCCB_CioOptimization(candidateCell.cellIndividualOffset, candidateCell.cioDelta);

    if (candidateCell.cgi.plmn.longId != 0 && ERROR == VCOM_UpdateCIOmForUPM(ptCi, &candidateCell))
    {
        VCCB_PRINT_CALL_DATA(ptCi, "VCOM_UpdateCIOmForUPM Error!!\n");
        return;
    }

    qOffsetRangeValueList_type ncrCioInDecibels = getQOffsetRangeListInDecibels(candidateCell.cellIndividualOffset);
    qOffsetRangeValueList_type smallCellCioInDecibels = getQOffsetRangeListInDecibels(candidateCell.nrSmallCellCio);

    qOffsetRangeValueList_type calculatedNrCioInDecibels =
        FnVCCB_CalculatedNrCioInDecibles(ncrCioInDecibels, smallCellCioInDecibels);
    qOffsetRangeValueList_type adjustCioInDecibels = FnVCCB_AdjustCalculatedNrCioValue(calculatedNrCioInDecibels);
    candidateCell.cellIndividualOffset = FnVCCB_GetNrQOOffsetRangeListFromValueList(adjustCioInDecibels);

    return;
}

bool FnVCCB_IsValidCellIndividualOffset(const cellsToMeasInfo_type &candidateCell)
{
    if (qOffset_0 != candidateCell.cellIndividualOffset.rsrpOffsetSSB ||
        qOffset_0 != candidateCell.cellIndividualOffset.rsrqOffsetSSB ||
        qOffset_0 != candidateCell.cellIndividualOffset.sinrOffsetSSB)
    {
        return true;
    }

    return false;
}

void VCCB_AddCellsToMeasureNR(callInfo_type *ptCi, cellToMeasure_type *items, uint8_t *cellsToMeasCnt,
    const vector<pairCellsToMeas> &vCellsToMeas)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(items);
    VALID_E_POINT_CHECK_VOID(cellsToMeasCnt);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    for (auto iter : vCellsToMeas)
    {
        if (*cellsToMeasCnt >= MAX_NR_OF_CELLS_TO_MEASURE) break;
        if (MAX_PHYSICAL_CELL_ID < iter.first) continue;

        FnVCCB_CalculateNrCio(ptCi, iter.second);
        if (true == FnVCCB_IsValidCellIndividualOffset(iter.second))
        {
            items[*cellsToMeasCnt].pci = iter.second.pci;
            items[*cellsToMeasCnt].cellIndividualOffset = iter.second.cellIndividualOffset;
            (*cellsToMeasCnt)++;
        }
    }
}

void FnVCCB_UpdateCellsToMeasureNrSmallCellPci(
    uint16_t gnbNum, int8_t nrSmallCellPciListIdx, cellsToMeasCandidatesInfo_type &rList)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(nrSmallCellPciListIdx, MAX_NR_SMALLCELL_PCI_ENTRIES);
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);

    // Range check about SmallCellPciListIndex.
    if (nrSmallCellPciListIdx < 0) return;

    VccbGnbInfo_type *pGnb = &GNBINFO[gnbNum];
    VccbNrSmallCellPciList_type *gnbPciRangeList = &pGnb->nrSmallCellPciList[nrSmallCellPciListIdx];

    if (gnbPciRangeList->usage == CI_use)
    {
        uint16_t smallCellPciIdx = 0;
        for (int idx = 0; idx < MAX_NR_SMALLCELL_PCI_RANGE_ENTRIES; idx++)
        {
            VccbNrSmallCellPciRange_type *scPciRangeList = &gnbPciRangeList->pciRange[idx];
            if (CI_use == scPciRangeList->usage)
            {
                uint16_t pciStart = scPciRangeList->pciStart;
                uint16_t pciEnd = MIN(MAX_PHYSICAL_CELL_ID, scPciRangeList->pciEnd);
                for (uint16_t nrPci = pciStart; nrPci <= pciEnd; nrPci++)
                {
                    // pciRangeCheck
                    rList.pciList.push_back(nrPci);

                    // for smallCell pci duplicate check
                    rList.numList[nrPci]++;

                    // use first matched info
                    if (rList.numList[nrPci] == 1)
                    {
                        cellsToMeasInfo_type &smallCellPci = rList.info[nrPci];

                        smallCellPci.isSmallCellPci = TRUE;
                        smallCellPci.pci = nrPci;
                        smallCellPci.rank = -1;
                        smallCellPci.idx = smallCellPciIdx++;
                        smallCellPci.nrSmallCellCio = scPciRangeList->cellIndividualOffset;
                        smallCellPci.cellIndividualOffset = {qOffset_0, qOffset_0, qOffset_0};
                        smallCellPci.cioDelta = 0;
                        smallCellPci.isHoAllowed = TRUE;
                        smallCellPci.cgi.plmn.longId = 0;
                    }
                }
            }
        }
    }
}

bool FnVCCB_CheckNbrIsHandoverAllowed(callInfo_type *ptCi, nbrCellInfo_type *pNbr)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pNbr, false);

    if (ptCi->callType == E_CALLTYPE_SA) return (pNbr->isHoAllowed == TRUE ? true : false);

    return (pNbr->isEndcHoAllowed == TRUE ? true : false);
}

void FnVCCB_UpdateCellsToMeasureByNrCellNbr(callInfo_type *ptCi, CellNum_type cellNum,
    measurementObjectNRUe_type *pUeObj, cellsToMeasCandidatesInfo_type &rList)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pUeObj);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    Arfcn_type ssbFreq = pUeObj->minimal.ssbFrequency;

    for (uint16_t nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)
    {
        nbrCellInfo_type *pNbr = &pCell->Nbr[nbrIdx];
        if (EQUIP != pNbr->status) continue;

        // INTRA_NR_ANR_24A - exclude SA UE && is-handover-allowed == FALSE and NSA UE && is-endc-handover-allowed ==
        // FALSE
        if (!IS_NRDC_SN(ptCi) && FnVCCB_CheckNbrIsHandoverAllowed(ptCi, pNbr) == false) continue;

        nbrGnbCellInfo_type *pNbrGnbCell;

        int16_t status = getNbrGnbCellByCellNbrIdx(cellNum, nbrIdx, &pNbrGnbCell);
        if (status != GOOD) continue;

        if (ssbFreq != pNbrGnbCell->ssbArfcn) continue;
        if (GOOD != VCCM_CompareNbrSmtc1Condition(&pUeObj->minimal.smtc1, pNbrGnbCell)) continue;

        if (MAX_PHYSICAL_CELL_ID < pNbrGnbCell->nrPci) continue;

        rList.pciList.push_back(pNbrGnbCell->nrPci);

        // for ncr pci duplicate check
        rList.numList[pNbrGnbCell->nrPci]++;

        cellsToMeasInfo_type &ncr = rList.info[pNbrGnbCell->nrPci];

        ncr.pci = pNbrGnbCell->nrPci;
        ncr.rank = pNbr->rank;
        ncr.idx = nbrIdx;
        ncr.isSmallCellPci = FALSE;
        ncr.isHoAllowed = pNbr->isHoAllowed;

        ncr.cellIndividualOffset = pNbr->cellIndividualOffset;

        ncr.cioDelta = 0;  // Init
        if (IS_SA_CALL_IN_PCELL(ptCi) && not IS_REDCAP_UE(ptCi))
        {
            ncr.cioDelta = static_cast<int8_t>(pNbr->cioDelta + pNbr->cioDeltaHom);  // cioDelta by MRO
        }

        ncr.nrSmallCellCio = {qOffset_0, qOffset_0, qOffset_0};

        ncr.cgi.plmn.longId = pNbrGnbCell->cellPlmnInfo[0].longId;
        ncr.cgi.ci = VLIB_GnbIdCellId2NrCellId(&pNbrGnbCell->globalGnbId.gnbId, pNbrGnbCell->cellId);
    }
}

void VCCB_UpdateCellsToMeasureNR(
    callInfo_type *ptCi, measurementObjectNRUe_type *pUeObj, CellNum_type cellNum, int8_t nrSmallCellPciListIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pUeObj);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    pUeObj->cellsToMeasure.numItems = 0;
    memset(pUeObj->cellsToMeasure.items, 0, sizeof(pUeObj->cellsToMeasure.items));

    cellsToMeasCandidatesInfo_type cellsToMeas_ncr;
    memset(cellsToMeas_ncr.numList, 0, sizeof(cellsToMeas_ncr.numList));

    FnVCCB_UpdateCellsToMeasureByNrCellNbr(ptCi, cellNum, pUeObj, cellsToMeas_ncr);

    cellsToMeasCandidatesInfo_type cellsToMeas_smallcell;
    memset(cellsToMeas_smallcell.numList, 0, sizeof(cellsToMeas_smallcell.numList));

    if (IS_SA_CALL_IN_PCELL(ptCi))  // cell-individual-offset in small-cell-pci-range-entries
    {
        FnVCCB_UpdateCellsToMeasureNrSmallCellPci(ptCi->gnbNum, nrSmallCellPciListIdx, cellsToMeas_smallcell);
    }

    vector<pairCellsToMeas> vecCellsToMeas;
    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];

    if (pGnb->cfg.gnbMobilityConfig.registerNrSmallCellAsNeighbor == true)
    {
        for (auto &pci : cellsToMeas_ncr.pciList)
        {
            if (MAX_PHYSICAL_CELL_ID < pci) continue;
            if (cellsToMeas_ncr.numList[pci] == 1)
            {
                if (cellsToMeas_smallcell.numList[pci] == 1)
                {
                    cellsToMeas_ncr.info[pci].nrSmallCellCio = cellsToMeas_smallcell.info[pci].nrSmallCellCio;
                    cellsToMeas_ncr.info[pci].isSmallCellPci = TRUE;
                }

                vecCellsToMeas.push_back({pci, cellsToMeas_ncr.info[pci]});
            }
        }
    }
    else
    {
        /* Check Small Cell NCR */
        for (auto &pci : cellsToMeas_smallcell.pciList)
        {
            if (MAX_PHYSICAL_CELL_ID < pci) continue;
            if (cellsToMeas_smallcell.numList[pci] == 1)
            {
                vecCellsToMeas.push_back({pci, cellsToMeas_smallcell.info[pci]});
            }
        }

        /* Check NCR */
        for (auto &pci : cellsToMeas_ncr.pciList)
        {
            if (MAX_PHYSICAL_CELL_ID < pci) continue;
            if (cellsToMeas_smallcell.numList[pci] == 1) continue;  // Skip SmallCell's PCI in NCR
            if (cellsToMeas_ncr.numList[pci] == 1)
            {
                vecCellsToMeas.push_back({pci, cellsToMeas_ncr.info[pci]});
            }
        };
    }

    sort(vecCellsToMeas.begin(), vecCellsToMeas.end(), VCCB_UpSortCellsToMeas);

    uint8_t cellsToMeasCnt = 0;
    VCCB_AddCellsToMeasureNR(ptCi, &(pUeObj->cellsToMeasure.items[0]), &cellsToMeasCnt, vecCellsToMeas);

    pUeObj->cellsToMeasure.numItems = cellsToMeasCnt;
}

enumEutraQOffsetRange FnVCCB_CalculateEutraCio(cellsToMeasInfo_type candidateCell)
{
    AUTO_TRACE_FUNC;
    // NCR CIO
    uint16_t ncrCio = static_cast<uint8_t>(candidateCell.cellIndOffset + static_cast<uint8_t>(candidateCell.cioDelta));
    int32_t ncrCioInDecibels = eutraQOffsetRangeToValue(static_cast<enumEutraQOffsetRange>(ncrCio));
    int32_t smallCellCioInDecibels =
        eutraQOffsetRangeToValue(static_cast<enumEutraQOffsetRange>(candidateCell.eutraSmallCellCio));

    int32_t adjustCioInDecibels = FnVCCB_AdjustCalculatedCio(ncrCioInDecibels + smallCellCioInDecibels);
    return eutraValueToQOffsetRange(adjustCioInDecibels);
}

void VCCB_AddCellsToMeasureEutra(
    eutra_cell_type *items, uint8_t *cellsToMeasCnt, const vector<pairCellsToMeas> &vCellsToMeas, uint16_t gnbNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(items);
    VALID_E_POINT_CHECK_VOID(cellsToMeasCnt);
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);

    for (auto iter : vCellsToMeas)
    {
        if (*cellsToMeasCnt >= MAX_EUTRA_OF_CELLS_TO_MEASURE) break;
        if (TRUE != iter.second.isHoAllowed) continue;
        if (MAX_EUTRA_PHYSICAL_CELL_ID < iter.first) continue;
        // calculate cio
        enumEutraQOffsetRange calculatedCio = FnVCCB_CalculateEutraCio(iter.second);
        if (eutraQOffsetRange_noUse != calculatedCio && eutraQOffsetRange_0 != calculatedCio)
        {
            items[*cellsToMeasCnt].pci = iter.first;
            items[*cellsToMeasCnt].cellIndexEUTRA = CELL_INDEX_EUTRA_INIT;  // set to invalid value first
            items[*cellsToMeasCnt].cellIndividualOffset = static_cast<uint8_t>(calculatedCio);
            (*cellsToMeasCnt)++;
        }
    }
}

void FnVCCB_UpdateCellsToMeasureEutraSmallCellPci(
    uint16_t gnbNum, int8_t eutraSmallCellPciListIdx, cellsToMeasCandidatesInfo_type &rList)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(eutraSmallCellPciListIdx, MAX_EUTRA_SMALLCELL_PCI_ENTRIES);

    // Range check about SmallCellPciListIndex.
    if (eutraSmallCellPciListIdx < 0) return;

    VccbGnbInfo_type *pGnb = &GNBINFO[gnbNum];
    VccbEutraSmallCellPciList_type *gnbPciRangeList = &pGnb->eutraSmallCellPciList[eutraSmallCellPciListIdx];

    if (gnbPciRangeList->usage == CI_use)
    {
        uint16_t smallCellPciIdx = 0;
        for (int idx = 0; idx < MAX_EUTRA_SMALLCELL_PCI_RANGE_ENTRIES; idx++)
        {
            VccbEutraSmallCellPciRange_type *scPciRangeList = &gnbPciRangeList->pciRange[idx];
            if (CI_use == scPciRangeList->usage)
            {
                uint16_t pciStart = scPciRangeList->pciStart;
                uint16_t pciEnd = MIN(MAX_EUTRA_PHYSICAL_CELL_ID, scPciRangeList->pciEnd);
                for (uint16_t eutraPci = pciStart; eutraPci <= pciEnd; eutraPci++)
                {
                    // pciRangeCheck
                    rList.pciList.push_back(eutraPci);

                    // for smallCell pci duplicate check
                    rList.numList[eutraPci]++;

                    // use first matched info
                    if (rList.numList[eutraPci] == 1)
                    {
                        cellsToMeasInfo_type &smallCellPci = rList.info[eutraPci];

                        smallCellPci.isSmallCellPci = TRUE;
                        smallCellPci.pci = eutraPci;
                        smallCellPci.rank = -1;
                        smallCellPci.idx = smallCellPciIdx++;
                        smallCellPci.eutraSmallCellCio = static_cast<int8_t>(scPciRangeList->cellIndividualOffset);
                        smallCellPci.cellIndOffset = eutraQOffsetRange_0;
                        smallCellPci.cioDelta = 0;
                        smallCellPci.isHoAllowed = TRUE;
                    }
                }
            }
        }
    }
}

void FnVCCB_UpdateCellsToMeasureByEutraCellNbr(CellNum_type cellNum, measurementObjectEUTRAUe_type *pUeObj,
    cellsToMeasCandidatesInfo_type &rList, bool applyCioDelta)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pUeObj);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    Arfcn_type earfcnDl = pUeObj->minimal.carrierFreq;

    for (uint16_t nbrIdx = 0; nbrIdx < MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL; nbrIdx++)
    {
        nbrEutraCellInfo_type *pEutraNbr = &pCell->eutraNbr[nbrIdx];
        if (EQUIP != pEutraNbr->status) continue;

        nbrEnbCellInfo_type *pNbrEnbCell;

        int16_t status = getNbrEnbCellByCellNbrIdx(cellNum, nbrIdx, &pNbrEnbCell);
        if (status != GOOD) continue;

        if (earfcnDl != pNbrEnbCell->earfcnDl) continue;

        if (MAX_EUTRA_PHYSICAL_CELL_ID < pNbrEnbCell->pci) continue;

        rList.pciList.push_back(pNbrEnbCell->pci);

        // for ncr pci duplicate check
        rList.numList[pNbrEnbCell->pci]++;

        cellsToMeasInfo_type &ncr = rList.info[pNbrEnbCell->pci];

        ncr.pci = pNbrEnbCell->pci;
        ncr.rank = pEutraNbr->rank;
        ncr.idx = nbrIdx;
        ncr.isSmallCellPci = FALSE;
        ncr.isHoAllowed = pEutraNbr->isHoAllowed;

        // update cio parameters
        ncr.cioDelta = (applyCioDelta) ? pEutraNbr->cioDelta : 0;
        ncr.cellIndOffset = pEutraNbr->cellIndOffset;
        ncr.eutraSmallCellCio = eutraQOffsetRange_0;
    }
}

void VCCB_UpdateCellsToMeasureEutra(const callInfo_type *ptCi, measurementObjectEUTRAUe_type *pUeObj,
    CellNum_type cellNum, int8_t eutraSmallCellPciListIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pUeObj);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    pUeObj->cellsToMeasureEutra.numItems = 0;
    memset(pUeObj->cellsToMeasureEutra.items, 0, sizeof(pUeObj->cellsToMeasureEutra.items));

    cellsToMeasCandidatesInfo_type cellsToMeas_ncr;
    memset(cellsToMeas_ncr.numList, 0, sizeof(cellsToMeas_ncr.numList));

    // FGS-SF0510:FR90  If condition for applying cio delta is added, then add to the lambda
    auto applyCioDelta = [&ptCi]() -> bool { return (IS_REDCAP_UE(ptCi)) ? false : true; };
    FnVCCB_UpdateCellsToMeasureByEutraCellNbr(cellNum, pUeObj, cellsToMeas_ncr, applyCioDelta());

    cellsToMeasCandidatesInfo_type cellsToMeas_smallcell;
    memset(cellsToMeas_smallcell.numList, 0, sizeof(cellsToMeas_smallcell.numList));

    if (IS_SA_CALL_IN_PCELL(ptCi))  // cell-individual-offset in small-cell-pci-range-entries
    {
        FnVCCB_UpdateCellsToMeasureEutraSmallCellPci(ptCi->gnbNum, eutraSmallCellPciListIdx, cellsToMeas_smallcell);
    }

    vector<pairCellsToMeas> vecCellsToMeas;
    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];

    if (pGnb->cfg.gnbMobilityConfig.registerEutraSmallCellAsNeighbor == true)
    {
        for (auto &pci : cellsToMeas_ncr.pciList)
        {
            if (MAX_EUTRA_PHYSICAL_CELL_ID < pci) continue;
            if (cellsToMeas_ncr.numList[pci] == 1)
            {
                if (cellsToMeas_smallcell.numList[pci] == 1)
                {
                    cellsToMeas_ncr.info[pci].eutraSmallCellCio = cellsToMeas_smallcell.info[pci].eutraSmallCellCio;
                    cellsToMeas_ncr.info[pci].isSmallCellPci = TRUE;
                }

                vecCellsToMeas.push_back({pci, cellsToMeas_ncr.info[pci]});
            }
        }
    }
    else
    {
        /* Check Small Cell NCR */
        for (auto &pci : cellsToMeas_smallcell.pciList)
        {
            if (MAX_EUTRA_PHYSICAL_CELL_ID < pci) continue;
            if (cellsToMeas_smallcell.numList[pci] == 1)
            {
                vecCellsToMeas.push_back({pci, cellsToMeas_smallcell.info[pci]});
            }
        }

        /* Check NCR */
        for (auto &pci : cellsToMeas_ncr.pciList)
        {
            if (MAX_EUTRA_PHYSICAL_CELL_ID < pci) continue;
            if (cellsToMeas_smallcell.numList[pci] == 1) continue;  // Skip SmallCell's PCI in NCR
            if (cellsToMeas_ncr.numList[pci] == 1)
            {
                vecCellsToMeas.push_back({pci, cellsToMeas_ncr.info[pci]});
            }
        }
    }

    sort(vecCellsToMeas.begin(), vecCellsToMeas.end(), VCCB_UpSortCellsToMeas);

    uint8_t cellsToMeasCnt = 0;
    VCCB_AddCellsToMeasureEutra(&(pUeObj->cellsToMeasureEutra.items[0]), &cellsToMeasCnt, vecCellsToMeas, ptCi->gnbNum);

    pUeObj->cellsToMeasureEutra.numItems = cellsToMeasCnt;
}

/****************************************************************************
 * @brief           Modify RSRP/RSRQ values by applying Delta
 *
 * @param[in]       ptCi          : Pointer to call configuration. / callInfo_type*
 * @param[in]       pReportConfig : Pointer to report config to be installed on UE / reportConfigurationConfUe_type *
 ****************************************************************************/
int16_t VCCB_CheckRfspSpecificSupportPurposeCheck(
    callInfo_type *ptCi, const uint8_t reportType, const uint8_t reportPurpose)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    if (E_CALLTYPE_SA == ptCi->callType)
    {
        /* [FR11]
        For NR-DC, apply only measurement configuration as following :
        1) Measurement configuration for NR-DC SN Addition (in MN) (21D)
            A4: nr-dc-sn-addition-purpose
        2) Measurement Configuration for NR-DC PSCell Release (in SN) (21D)
            A2: nr-dc-pscell-release-purpose
        3) Measurement Configuration for NR-DC PSCell Change (in SN) (21D)
            A3/A4/A5: nr-dc-nr-pscell-change-purpose
        4) Measurement Configuration for NR-DC UL Path Control (in SN) (22A)
            A1: nr-dc-in-pscell-ul-coverage-ueulsplit-sup-purpose,
                nr-dc-in-pscell-ul-coverage-ueulsplit-notsup-purpose
            A2: nr-dc-out-of-pscell-ul-coverage-ueulsplit-sup-purpose,
                nr-dc-out-of-pscell-ul-coverage-ueulsplit-notsup-purpose

        For SA HO, apply only measurement configuration as following :
        1) Measurement Configuration for Coverage based HO (21D)
            A1: sa-deactivate-meas-gap-purpose
            A2: activate-inter-rat-purpose, activate-inter-frequency-purpose
            A3/A4/A5: intra-nr-handover-purpose
            B1/B2: eutra-handover-purpose
        2) Measurement Configuration for On-Demand Handover (21D)
            A5: intra-nr-on-demand-handover-purpose
            B2: eutra-on-demand-handover-purpose
        3) Measurement Configuration for RFSP Based Handover (21D)
            A5: intra-nr-rfsp-handover-purpose
            B1: eutra-rfsp-handover-purpose
        4) Measurement Configuration for FGR-MC1029 (25B)
            A5: intra-nr-du-triggered-forced-handover-purpose, forced-handover-due-to-bad-ul-quality-purpose,
                forced-handover-due-to-tdd-interference-purpose, forced-handover-due-to-long-rtp-gap-purpose
            B1: eutra-forced-handover-due-to-ul-prb-blanking-purpose, eutra-forced-handover-due-to-bad-ul-quality-purpose,
                eutra-forced-handover-due-to-tdd-interference-purpose, eutra-forced-handover-due-to-long-rtp-gap-purpose
        5) Measurement Configuration for IRAT PCC Change (FGR-CC5500 FR64, FR928) (26A)
            B1/B2: capability-aware-carrier-change-purpose*/

        switch (reportType)
        {
            case measReport_A1:
                if (reportPurpose == a1Purpose_nrdcInPScellUlCoverage_ueUlSplitSup ||
                    reportPurpose == a1Purpose_nrdcInPScellUlCoverage_ueUlSplitNotSup ||
                    reportPurpose == a1Purpose_saDeactivateMeasureGap)
                    return GOOD;
                break;
            case measReport_A2:
                if (reportPurpose == a2Purpose_nrdcNRPSCellRelease ||
                    reportPurpose == a2Purpose_nrdcOutOfPScellUlCoverage_ueUlSplitSup ||
                    reportPurpose == a2Purpose_nrdcOutOfPScellUlCoverage_ueUlSplitNotSup ||
                    reportPurpose == a2Purpose_activate_inter_rat ||
                    reportPurpose == a2Purpose_activateInterFrequencyForSa)
                    return GOOD;
                break;
            case measReport_A3:
                if (reportPurpose == a3Purpose_nrdcNrPSCellChange || reportPurpose == a3Purpose_intraNrHandover)
                    return GOOD;
                break;
            case measReport_A4:
                if (reportPurpose == a4Purpose_nrdcNrPSCellChange || reportPurpose == a4Purpose_NrdcAddition ||
                    reportPurpose == a4Purpose_intraNrHandover)
                    return GOOD;
                break;
            case measReport_A5:
                if (reportPurpose == a5Purpose_nrdcNrPSCellChange || reportPurpose == a5Purpose_intraNrHandover ||
                    reportPurpose == a5Purpose_intraNrOnDemandHandover ||
                    reportPurpose == a5Purpose_intraNrRfspHandover ||
                    reportPurpose == a5Purpose_intraNrDuTriggeredForcedHandover ||
                    reportPurpose == a5Purpose_forcedHandoverDueToBadUlQuality ||
                    reportPurpose == a5Purpose_forcedHandoverDueToTddInterference ||
                    reportPurpose == a5Purpose_forcedHandoverDueToLongRtpGap)
                    return GOOD;
                break;
            case measReport_B1Eutra:
                if (reportPurpose == b1Purpose_eutraHandover || reportPurpose == b1Purpose_eutraRfspHandover ||
                    reportPurpose == b1Purpose_eutraForcedHandoverDueToUlPrbBlanking ||
                    reportPurpose == b1Purpose_eutraForcedHandoverDueToBadUlQuality ||
                    reportPurpose == b1Purpose_eutraForcedHandoverDueToTddInterference ||
                    reportPurpose == b1Purpose_eutraForcedHandoverDueToLongRtpGap ||
                    reportPurpose == b1Purpose_CapabilityAwareCarrierChange)
                    return GOOD;
                break;
            case measReport_B2Eutra:
                if (reportPurpose == b2Purpose_eutraHandover || reportPurpose == b2Purpose_eutraOnDemandHandover ||
                    reportPurpose == b2Purpose_capabilityAwareCarrierChange)
                    return GOOD;
                break;
            default:
                return BREAK;
        }
    }

    return BREAK;
}

/****************************************************************************
 * @brief           Functor for matching overlapped frequency against
 *                  measurementObjectUe_type (EUTRA).
 *
 * @param[in]       freq : overlapped frequency to match against. / Arfcn_type/uint32_t
 * @param[in]       measObj : EUTRA measurement object to match against. / measurementObjectUe_type
 ****************************************************************************/
struct VCCB_OverlappedFrequencyMatcherEutra
{
    VCCB_OverlappedFrequencyMatcherEutra(Arfcn_type freq) : _freq(freq) {}

    bool operator()(const measurementObjectUe_type &measObj) const
    {
        return (CI_use == measObj.usage) && (measRatEutra == measObj.conf.ratType) &&
               (_freq == measObj.conf.rat.eutra.minimal.overlappedCarrierFreq);
    }

private:
    const Arfcn_type _freq;
};

/****************************************************************************
 * @brief           Functor for matching report configuration type and purpose
 *                  against reportConfigurationInstalledUe_type.
 *
 * @param[in]       type : Type of report configuration (periodic/A1/...). / uint8_t
 * @param[in]       purpose : Purpose of report configuration. / uint8_t
 ****************************************************************************/
struct VCCB_ReportConfigurationMatcher
{
    VCCB_ReportConfigurationMatcher(uint8_t type = 0, uint8_t purpose = 0) : _type(type), _purpose(purpose) {}
    bool operator()(const reportConfigurationNewUe_type &rptCfg)
    {
        return (rptCfg.usage == CI_use) && (rptCfg.conf.reportType == _type) && (rptCfg.conf.reportPurpose == _purpose);
    }

    uint8_t _type;
    uint8_t _purpose;
};

/****************************************************************************
 * @brief           Functor for matching report configuration type and purpose
 *                  against reportConfigurationInstalledUe_type not assigned yet.
 *
 * @param[in]       type : Type of report configuration (periodic/A1/...). / uint8_t
 * @param[in]       purpose : Purpose of report configuration. / uint8_t
 ****************************************************************************/
struct VCCB_ReportConfigNaMatcher
{
    VCCB_ReportConfigNaMatcher(uint8_t type = 0, uint8_t purpose = 0) : _type(type), _purpose(purpose) {}
    bool operator()(const reportConfigurationNewUe_type &rptCfg)
    {
        return (rptCfg.usage == CI_use) && (rptCfg.conf.reportType == _type) &&
               (rptCfg.conf.reportPurpose == _purpose) && (rptCfg.internalIdx >= MAX_NR_OF_REPORT_CONFIG_ID);
    }

    uint8_t _type;
    uint8_t _purpose;
};

/****************************************************************************
 * @brief           Functor for matching report configuration candidate (reportConfigurationConfUe_type)
 *                  against report config which will be installed on UE (reportConfigurationNewUe_type)
 *
 * @param[in]       rhs : report config / reportConfigurationNewUe_type
 ****************************************************************************/
struct VCCB_ReportConfigMOSelectMatcher
{
    VCCB_ReportConfigMOSelectMatcher(const reportConfigurationConfUe_type &rhs) : _rhs(rhs) {}

    bool operator()(const reportConfigurationNewUe_type &rcNewUe)
    {
        if (rcNewUe.usage != CI_use)
        {
            return false;
        }

        const reportConfigurationConfUe_type &lhs = rcNewUe.conf;
        if (lhs.reportType != _rhs.reportType)
        {
            return false;
        }

        if (lhs.reportPurpose != _rhs.reportPurpose)
        {
            return false;
        }

        if (lhs.measObjectSelection != _rhs.measObjectSelection)
        {
            return false;
        }

        if (!VCCB_CompareTriggerQuantity(lhs, _rhs))
        {
            return false;
        }

        if (!VCCB_WillFr1PCStateModifyRCInTheSameWay(lhs.fr1PCState, _rhs.fr1PCState))
        {
            return false;
        }

        return true;
    }

private:
    reportConfigurationConfUe_type _rhs;
};

/****************************************************************************
 * @brief           Functor for matching measurement identities based on
 *                  measurement object and report configuration ids.
 *
 * @param[in]       measObjId : Id of a measurement object. / uint8_t
 * @param[in]       rptCfgId : Id of a report configuration. / uint8_t
 ****************************************************************************/
struct VCCB_MeasurementIdentityMatcher
{
    VCCB_MeasurementIdentityMatcher(uint8_t measObjId = 0, uint8_t rptCfgId = 0) :
        _measObjId(measObjId),
        _rptCfgId(rptCfgId)
    {
    }
    bool operator()(const measurementIdentity_type &measId)
    {
        return (measId.usage == CI_use) && (measId.measObjectId == _measObjId) && (measId.reportConfigId == _rptCfgId);
    }

    uint8_t _measObjId;
    uint8_t _rptCfgId;
};

/****************************************************************************
 * @brief           Generic functor for matching items based on ID.
 * @param           <T> : Target type. / T
 *
 * @param[in]       id : Id to match against. / uint8_t
 ****************************************************************************/
template <typename T>
struct VCCB_IdMatcher
{
    VCCB_IdMatcher(uint8_t id = 0) : _id(id) {}
    bool operator()(const T &item) { return (item.usage == CI_use) && (item.objectId == _id); }

    uint8_t _id;
};

/****************************************************************************
 * @brief           Functor for finding measurement identities tied to
 *                  a particular report configuration.
 *
 * @param[in]       rptCfgId : Id of a report configuration. / uint8_t
 ****************************************************************************/
struct VCCB_ReportConfigurationToMeasurementIdentityMatcher
{
    VCCB_ReportConfigurationToMeasurementIdentityMatcher(uint8_t rptCfgId = 0) : _rptCfgId(rptCfgId) {}
    bool operator()(const measurementIdentity_type &measId)
    {
        return (measId.usage == CI_use) && (measId.reportConfigId == _rptCfgId);
    }

    uint8_t _rptCfgId;
};

/****************************************************************************
 * @brief           Generic function for checking whether a particular ID is
 *                  already present in configuration.
 *
 * @param           <TElem> : Type of items in target array. / TElem
 * @param           id : ID to match against. / uint8_t
 * @param           array : Array to search. / TElem*
 * @param           size : Size of the array given by array parameter. / uint8_t
 * @return          Boolean value indicating whether item with a given ID is
 *                  already present in the array. / bool
 ****************************************************************************/
template <typename TElem>
bool VCCB_IsIdAssigned(uint8_t id, TElem *array, uint8_t size)
{
    AUTO_TRACE_FUNC;

    for (uint8_t i = 0; i < size; ++i)
    {
        if ((array[i].pending == VCCB_FLAG_ON) && (array[i].objectId == id))
        {
            return true;
        }
    }

    return false;
}

/****************************************************************************
 * @brief           Assigns IDs
 *
 * @param[in]       ptCi : Pointer to call configuration / callInfo_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
template <typename ConfigT, typename ProcT>
int16_t VCCB_AssignIds(ConfigT &rMeasItems, ProcT &pMeasItems, const uint8_t MAX_NUM)
{
    AUTO_TRACE_FUNC;

    bool idsState[MAX_NUM];
    uint8_t idIdx = 0;

    for (uint8_t i = 0; i < MAX_NUM; ++i)
    {
        idsState[i] = false;
    }

    for (uint8_t bitIndex = 0; bitIndex < MAX_NUM; bitIndex++)
    {
        if (GETBIT(pMeasItems.itemsToRemove, bitIndex))
        {
            rMeasItems.installedItems[bitIndex].pending = VCCB_FLAG_OFF;
        }
    }

    for (uint8_t i = 0; i < MAX_NUM; ++i)
    {
        if ((VCCB_FLAG_ON == rMeasItems.installedItems[i].pending) && (MAX_NUM > rMeasItems.installedItems[i].objectId))
        {
            idsState[rMeasItems.installedItems[i].objectId] = true;
        }
    }

    for (uint8_t i = 0; i < MIN(pMeasItems.numNewItems, MAX_NUM); ++i)
    {
        if (MAX_NUM > pMeasItems.newItems[i].objectId)
        {
            idsState[pMeasItems.newItems[i].objectId] = true;
        }
    }

    for (uint8_t i = 0; i < MIN(pMeasItems.numNewItems, MAX_NUM); ++i)
    {
        // If given object is not yet installed on the UE, its objectId is INVALID_OBJECT_ID
        // In this case we need to assign a new id and send its whole configuration
        if (INVALID_OBJECT_ID == pMeasItems.newItems[i].objectId)
        {
            // Assign new ID
            while ((MAX_NUM > idIdx) && (true == idsState[idIdx]))
            {
                idIdx++;
            }
            if (idIdx >= MAX_NUM)
            {
                VCCB_PRINT_ERROR("Can't assign free ID!\n");
                return ERROR;
            }
            pMeasItems.newItems[i].objectId = idIdx;
            idsState[idIdx] = true;
        }
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Checks if UE supports the NR band
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       freqBandIndicatorNR : Frequency Band Indicator NR / uint16_t
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_ChecksIfUeSupportsNrBand(callInfo_type *ptCi, uint16_t freqBandIndicatorNR)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    for (uint16_t ueCapaIdx = 0;
         ueCapaIdx < util::minOfArraySizeAndNumOfElems(
                         ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR, ptCi->ueInfo.ueCapa.nr.rf.nrOfBands);
         ueCapaIdx++)
    {
        if (freqBandIndicatorNR == ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR[ueCapaIdx].bandNR)
        {
            return GOOD;
        }
    }

    return ERROR;
}

/****************************************************************************
 * @brief           Checks if UE supports the EUTRA band
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       freqBandIndicatorNR : Frequency Band Indicator NR / uint16_t
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfUeSupportsEutraBand(callInfo_type *ptCi, Arfcn_type earfcn)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    uint16_t indicatorValue = GetEutraBandIndicatorByEARFCN(earfcn);
    if (VCCB_FLAG_ON == VLIB_IsEutraBandSupported(ptCi, indicatorValue))
    {
        return GOOD;
    }

    return ERROR;
}

void VCCB_SetMeasObjectNrUeConf(callInfo_type &rCi, measurementObjectConfUe_type &conf,
    const minimalMeasObjectNRUe_type &moCandidate, const CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;

    conf.ratType = measRatNr;
    conf.rat.nr.minimal = moCandidate;
    int8_t smallCellPciListIdx = conf.rat.nr.minimal.smallCellPciListIndex;
    VCCB_UpdateCellsToMeasureNR(&rCi, &conf.rat.nr, cellNum, smallCellPciListIdx);
    VCCB_UpdateBlackCells(rCi, cellNum, conf.rat.nr);
}

void FnVCCB_MergeMeasurementObjectNR(const minimalMeasObjectNRUe_type *pUeMoCandidate, measurementObjectUe_type *pExistingMeasObject)
{
    VALID_E_POINT_CHECK_VOID(pUeMoCandidate);
    VALID_E_POINT_CHECK_VOID(pExistingMeasObject);

    // merge allowed cell list
    auto &existingAllowedCells = pExistingMeasObject->conf.rat.nr.minimal.allowedCells;
    const auto &candidateAllowedCells = pUeMoCandidate->allowedCells;
    for (uint8_t i = 0; i < candidateAllowedCells.numOfPciRanges; i++)
    {
        if (existingAllowedCells.numOfPciRanges >= MAX_NR_OF_PCI_RANGES)
        {
            VCCB_PRINT_COMMENT("%s: Cannot add more allowed cells!\n", __FUNCTION__);
            break;
        }
        const uint16_t newPci = candidateAllowedCells.pciRanges[i].pci;
        bool isFound = false;
        for (uint8_t j = 0; j < existingAllowedCells.numOfPciRanges; j++)
        {
            if (newPci == existingAllowedCells.pciRanges[j].pci)
            {
                isFound = true;
                break;
            }
        }
        if (isFound)
        {
            continue;
        }
        existingAllowedCells.pciRanges[existingAllowedCells.numOfPciRanges++].pci = newPci;
    }
}

/****************************************************************************
 * @brief           Adds a measurement object NR to UE configuration if it's not
 *                  yet present and returns its id (or just returns the id
 *                  if the object is already configured).
 *
 * @param[in/out]   ptCi : Pointer to call configuration / callInfo_type*
 * @param[in]       cellNum : cell for which measurement is being configured
 * @param[in]       pUeMoCandidate : Pointer to NR meas object which need to installed / const
 *minimalMeasObjectNRUe_type*
 * @param[in]       signalType : Type of signal to be measured. / enumRSType
 * @param[out]      pIdx : pointer to Id of the measurement object when installed on UE. / uint8_t*
 * @return          status : GOOD, ERROR, BREAK / int16_t
 ****************************************************************************/
int16_t VCCB_AddMeasurementObjectNR(callInfo_type *ptCi, const CellNum_type cellNum,
    const minimalMeasObjectNRUe_type *pUeMoCandidate, enumRSType signalType, uint8_t *pIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pUeMoCandidate);
    VALID_E_POINT_CHECK_ERROR(pIdx);

    if (RSType_SSB != signalType)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "ERROR: Not supported signal type (%u) in VCCB_AddMeasurementObjectNR!\n", signalType);

        return BREAK;
    }

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    // Check if a measurement object with matching frequency is already scheduled for installation
    measurementObjectUe_type *pExistingMeasObject = FnVCCB_FindNRMeasObjectInMeasProc(rMeasProc, *pUeMoCandidate);
    // Already scheduled, merge, grab the index and return
    if (nullptr != pExistingMeasObject)
    {
        FnVCCB_MergeMeasurementObjectNR(pUeMoCandidate, pExistingMeasObject);
        *pIdx = static_cast<uint8_t>(pExistingMeasObject - (&rMeasProc.measurementObjects.newItems[0]));
        return GOOD;
    }

    // Ensure UE supports the band
    const uint16_t freqBandIndicatorNR = pUeMoCandidate->freqBandIndicatorNR;
    if (GOOD != VCCB_ChecksIfUeSupportsNrBand(ptCi, freqBandIndicatorNR))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: Can't add measurement object - freqBandIndicatorNR(%u) not supported by UE!\n",
            freqBandIndicatorNR);
        return BREAK;
    }

    // Ensure we don't exceed the capacity
    if ((VCCB_FLAG_ON == ptCi->cgConfigInfo.configRestrictInfoFlag) &&
        (ptCi->cgConfigInfo.configRestrictInfo.maxMeasFreqsSCG_NR_Flag == VCCB_FLAG_ON))
    {
        if (rMeasProc.measurementObjects.numNewItems >= ptCi->cgConfigInfo.configRestrictInfo.maxMeasFreqsSCG_NR)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "ERROR: Can't add another measurement object - maximum number of measurement objects "
                "allowed by MN (%hu) reached in VCCB_AddMeasurementObjectNR!\n",
                ptCi->cgConfigInfo.configRestrictInfo.maxMeasFreqsSCG_NR);
            return BREAK;
        }
    }

    if (rMeasProc.measurementObjects.numNewItems >= VCCB_ARRAY_COUNT(rMeasProc.measurementObjects.newItems))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: Can't add another measurement object - maximum number of measurement objects "
            "reached in VCCB_AddMeasurementObjectNR!\n");
        return BREAK;
    }

    // Check referenceSignalConfig
    if (CI_use != pUeMoCandidate->referenceSignalConfig.ssbConfigMobility.usage)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: Can't add another measurement object - ssbMeasurementConfiguration not set "
            "in VCCB_AddMeasurementObjectNR!\n");
        return BREAK;
    }

    // Store the measurement object information along with the UE data
    *pIdx = rMeasProc.measurementObjects.numNewItems;
    measurementObjectUe_type *pUeObj = &rMeasProc.measurementObjects.newItems[*pIdx];
    VCCB_SetMeasObjectNrUeConf(*ptCi, pUeObj->conf, *pUeMoCandidate, cellNum);
    pUeObj->usage = CI_use;
    pUeObj->pending = VCCB_FLAG_ON;
    pUeObj->objectId = INVALID_OBJECT_ID;
    pUeObj->internalIdx = MAX_NR_OF_OBJECT_ID;
    pUeObj->isTainted = VCCB_FLAG_OFF;

    // Increment the elements counter
    ++rMeasProc.measurementObjects.numNewItems;

    return GOOD;
}

void VCCB_SetMeasObjectEutraUeConf(callInfo_type &rCi, measurementObjectConfUe_type &mo,
    const minimalMeasObjectEUTRAUe_type &moCandidate, const CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;

    mo.ratType = measRatEutra;
    mo.rat.eutra.minimal = moCandidate;
    int8_t smallCellPciListIdx = mo.rat.eutra.minimal.smallCellPciListIndex;
    VCCB_UpdateCellsToMeasureEutra(&rCi, &mo.rat.eutra, cellNum, smallCellPciListIdx);
    VCCB_UpdateEutraBlackCells(cellNum, mo.rat.eutra);
}

/****************************************************************************
 * @brief           Adds a measurement object EUTRA to UE configuration if it's not
 *                  yet present and returns its id (or just returns the id
 *                  if the object is already configured).
 *
 * @param[in/out]   ptCi : Pointer to call configuration / callInfo_type*
 * @param[in]       cellNum : cell for which measurement is being configured
 * @param[in]       pUeMoCandidate : Pointer to EUTRA meas object which need to installed / const
 *minimalMeasObjectEUTRAUe_type*
 * @param[out]      idx : Id of the measurement object when installed on UE. / uint8_t*
 * @return          status : GOOD, ERROR, BREAK / int16_t
 ****************************************************************************/
int16_t VCCB_AddMeasurementObjectEUTRA(
    callInfo_type *ptCi, const CellNum_type cellNum, const minimalMeasObjectEUTRAUe_type *pUeMoCandidate, uint8_t *pIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pUeMoCandidate);
    VALID_E_POINT_CHECK_ERROR(pIdx);

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    const Arfcn_type earfcn = pUeMoCandidate->overlappedCarrierFreq;
    VCCB_OverlappedFrequencyMatcherEutra frequencyMatcher(earfcn);

    // Check if a measurement object with matching frequency is already scheduled for installation
    measurementObjectUe_type *pUeObj = NULL;
    pUeObj = std::find_if(&(rMeasProc.measurementObjects.newItems[0]),
        &(rMeasProc.measurementObjects.newItems[rMeasProc.measurementObjects.numNewItems]), frequencyMatcher);

    // Already scheduled, grab the index and return
    if (pUeObj != &(rMeasProc.measurementObjects.newItems[rMeasProc.measurementObjects.numNewItems]))
    {
        *pIdx = static_cast<uint8_t>(pUeObj - (&rMeasProc.measurementObjects.newItems[0]));
        return GOOD;
    }

    // Ensure UE supports the band
    if (GOOD != VCCB_CheckIfUeSupportsEutraBand(ptCi, earfcn))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: Can't add measurement object - earfcn(%u) not supported by UE!\n", earfcn);
        return BREAK;
    }

    // Ensure we don't exceed the capacity
    if ((VCCB_FLAG_ON == ptCi->cgConfigInfo.configRestrictInfoFlag) &&
        (ptCi->cgConfigInfo.configRestrictInfo.maxMeasFreqsSCG_NR_Flag == VCCB_FLAG_ON))
    {
        if (rMeasProc.measurementObjects.numNewItems >= ptCi->cgConfigInfo.configRestrictInfo.maxMeasFreqsSCG_NR)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "ERROR: Can't add another measurement object - maximum number of measurement objects "
                "allowed by MN (%hu) reached in VCCB_AddMeasurementObjectEUTRA!\n",
                ptCi->cgConfigInfo.configRestrictInfo.maxMeasFreqsSCG_NR);
            return BREAK;
        }
    }

    if (rMeasProc.measurementObjects.numNewItems >= VCCB_ARRAY_COUNT(rMeasProc.measurementObjects.newItems))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: Can't add another measurement object - maximum number of measurement objects "
            "reached in VCCB_AddMeasurementObjectEUTRA!\n");
        return BREAK;
    }

    // Store the measurement object information along with the UE data
    *pIdx = rMeasProc.measurementObjects.numNewItems;
    pUeObj = &rMeasProc.measurementObjects.newItems[*pIdx];
    VCCB_SetMeasObjectEutraUeConf(*ptCi, pUeObj->conf, *pUeMoCandidate, cellNum);
    pUeObj->usage = CI_use;
    pUeObj->pending = VCCB_FLAG_ON;
    pUeObj->objectId = INVALID_OBJECT_ID;
    pUeObj->internalIdx = MAX_NR_OF_OBJECT_ID;
    pUeObj->isTainted = VCCB_FLAG_OFF;

    // Increment the elements counter
    ++rMeasProc.measurementObjects.numNewItems;

    return GOOD;
}

/****************************************************************************
 * @brief           Adds a report configuration to UE configuration if it's not
 *                  yet present and returns its id (or just returns the id
 *                  if it is already configured).
 *
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       pUeRptCandidate : Pointer to configuration which need to installed / reportConfigurationConfUe_type
 * @param[out]      pIdx : Pointer to index of the report configuration when installed on UE. / uint8_t*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_AddReportConfiguration(
    callInfo_type *ptCi, const reportConfigurationConfUe_type *pUeRptCandidate, uint8_t *pIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pUeRptCandidate);
    VALID_E_POINT_CHECK_ERROR(pIdx);

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(rMeasProc.tgtCellNum, MAX_CELL_NUM_VCCB);

    // Check if a report configuration with matching type and purpose is already scheduled for installation
    const int result = util::findObjectIdxIfExist(rMeasProc.reportConfigurations.newItems,
        rMeasProc.reportConfigurations.numNewItems, VCCB_ReportConfigMOSelectMatcher(*pUeRptCandidate));

    // Already scheduled, grab the index and return
    if (util::NOT_FOUND_IDX != result)
    {
        *pIdx = static_cast<uint8_t>(result);

        return GOOD;
    }

    // Ensure we don't exceed UE capacity
    if (rMeasProc.reportConfigurations.numNewItems >= MAX_NR_OF_REPORT_CONFIG_ID)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: Can't add another report configuration - maximum number of report configurations "
            "reached in VCCB_AddReportConfiguration!\n");

        return ERROR;
    }

    // Store the reportConfiguration information along with the UE data
    *pIdx = rMeasProc.reportConfigurations.numNewItems;
    reportConfigurationNewUe_type *pUeRpt = &rMeasProc.reportConfigurations.newItems[*pIdx];

    pUeRpt->conf = *pUeRptCandidate;
    pUeRpt->usage = CI_use;
    pUeRpt->pending = VCCB_FLAG_ON;
    pUeRpt->objectId = INVALID_OBJECT_ID;
    pUeRpt->internalIdx = MAX_NR_OF_REPORT_CONFIG_ID;
    pUeRpt->isTainted = VCCB_FLAG_OFF;

    // Increment the elements counter
    ++rMeasProc.reportConfigurations.numNewItems;

    return GOOD;
}

/****************************************************************************
 * @brief Ctor class for finding a meas objects
 ****************************************************************************/
VCCB_MeasObjDbFinder::VCCB_MeasObjDbFinder(measurementsData_type &rDbConf, enumMeasRatType ratType, Arfcn_type freq) :
    _rDbConf(rDbConf),
    _pDbObjNr(nullptr),
    _pDbObjEutra(nullptr),
    _ratType(ratType),
    _pMeasObjDbIdx(0)
{
    AUTO_TRACE_FUNC;

    switch (_ratType)
    {
        case measRatNr:
            findNr(freq);
            break;

        case measRatEutra:
            findEutra(freq);
            break;

        default:
            VCCB_PRINT_ERROR("_ratType(%u) not supported!\n", _ratType);
            break;
    }
}

/****************************************************************************
 * @brief Finds meas objects NR
 ****************************************************************************/
void VCCB_MeasObjDbFinder::findNr(Arfcn_type freq)
{
    AUTO_TRACE_FUNC;

    // Try to find a measurement object with matching frequency/rsType in database
    _pMeasObjDbIdx = findIdxOfMatchingMeasObjectNr(VCCB_FrequencyMatcher(freq, RSType_SSB), _rDbConf);

    if (VCCB_ARRAY_COUNT(_rDbConf.measurementObjectsNRDb) <= _pMeasObjDbIdx)
    {
        VCCB_PRINT_COMMENT("Couldn't find meas object NR freq(%u)!\n", freq);

        return;
    }

    _pDbObjNr = &_rDbConf.measurementObjectsNRDb[_pMeasObjDbIdx];
}

/****************************************************************************
 * @brief Finds a meas objects EUTRA
 ****************************************************************************/
void VCCB_MeasObjDbFinder::findEutra(Arfcn_type freq)
{
    AUTO_TRACE_FUNC;

    measurementObjectEUTRADb_type *pDbObjEutra = nullptr;

    // Try to find a measurement object with matching frequency in database
    pDbObjEutra = std::find_if(&(_rDbConf.measurementObjectsEUTRADb[0]),
        &(_rDbConf.measurementObjectsEUTRADb[MAX_NR_OF_OBJECTEUTRA_ID_DB]), VCCB_FrequencyMatcherEutra(freq));

    _pMeasObjDbIdx = static_cast<uint8_t>(pDbObjEutra - &_rDbConf.measurementObjectsEUTRADb[0]);

    if (MAX_NR_OF_OBJECTEUTRA_ID_DB <= _pMeasObjDbIdx)
    {
        VCCB_PRINT_COMMENT("Couldn't find meas object EUTRA freq(%u)!\n", freq);

        return;
    }

    _pDbObjEutra = &_rDbConf.measurementObjectsEUTRADb[_pMeasObjDbIdx];
}

/****************************************************************************
 * @brief Checks if found and data is valid
 ****************************************************************************/
bool VCCB_MeasObjDbFinder::isValid() const
{
    AUTO_TRACE_FUNC;

    switch (_ratType)
    {
        case measRatNr:
            if (nullptr == _pDbObjNr)
            {
                return false;
            }
            break;

        case measRatEutra:
            if (nullptr == _pDbObjEutra)
            {
                return false;
            }
            break;

        default:
            return false;
    }

    return true;
}

/****************************************************************************
 * @brief Ctor class for finding a report configuration and a meas objects
 ****************************************************************************/
VCCB_RptCfgAndMeasObjDbFinder::VCCB_RptCfgAndMeasObjDbFinder(
    measurementsData_type &rDbConf, enumMeasurementReportType reportType, uint8_t reportPurpose, Arfcn_type freq) :
    _measObjectDbFinder(rDbConf, VCCB_GetRatType(reportType), freq),
    _rDbConf(rDbConf),
    _pDbRpt(nullptr),
    _pDbUeRpt(nullptr),
    _ratType(VCCB_GetRatType(reportType)),
    _pRptCfgIdx(0)
{
    AUTO_TRACE_FUNC;

    switch (_ratType)
    {
        case measRatNr:
            findNr(reportType, reportPurpose, freq);
            break;

        case measRatEutra:
            findEutra(reportType, reportPurpose, freq);
            break;

        default:
            VCCB_PRINT_ERROR("_ratType(%u) not supported!\n", _ratType);
            break;
    }
}

/****************************************************************************
 * @brief Finds a report configuration and a meas objects NR
 ****************************************************************************/
void VCCB_RptCfgAndMeasObjDbFinder::findNr(enumMeasurementReportType reportType, uint8_t reportPurpose, Arfcn_type freq)
{
    AUTO_TRACE_FUNC;

    // Try to find a matching report configuration index in database (same type and purpose)
    uint8_t reportCfgIdx = findIdxOfMatchingReportCfgNrSpecFreq(
        VCCB_ReportCfgSpecFreqMatcher(freq, _measObjectDbFinder._pMeasObjDbIdx, reportType, reportPurpose), _rDbConf);
    if (MAX_NR_OF_REPORT_CONFIG_ID_DB <= reportCfgIdx)
    {
        reportCfgIdx =
            findIdxOfMatchingReportCfgNrAllFreq(VCCB_ReportCfgAllFreqMatcher(reportType, reportPurpose), _rDbConf);
        if (MAX_NR_OF_REPORT_CONFIG_ID_DB <= reportCfgIdx)
        {
            VCCB_PRINT_COMMENT("Couldn't find report config NR!\n");
            return;
        }
    }

    if (RSType_SSB != _rDbConf.reportConfigurationsDb[reportCfgIdx].base.rsType)
    {
        VCCB_PRINT_COMMENT("Unsupported rsType(%u)!\n", _rDbConf.reportConfigurationsDb[reportCfgIdx].base.rsType);
        return;
    }

    _pDbRpt = &_rDbConf.reportConfigurationsDb[reportCfgIdx];
    _pDbUeRpt = _rDbConf.ueSpecificReportConfigurations[reportCfgIdx];
    _pRptCfgIdx = reportCfgIdx;

    return;
}

/****************************************************************************
 * @brief Finds a report configuration and a meas objects EUTRA
 ****************************************************************************/
void VCCB_RptCfgAndMeasObjDbFinder::findEutra(
    enumMeasurementReportType reportType, uint8_t reportPurpose, Arfcn_type freq)
{
    AUTO_TRACE_FUNC;

    // Try to find a matching report configuration Index in database (same type and purpose)
    uint8_t reportCfgIdx = findIdxOfMatchingReportCfgEutraSpecFreq(
        VCCB_ReportCfgSpecFreqMatcher(freq, _measObjectDbFinder._pMeasObjDbIdx, reportType, reportPurpose), _rDbConf);
    if (MAX_NR_OF_REPORT_CONFIGIR_ID_DB <= reportCfgIdx)
    {
        reportCfgIdx =
            findIdxOfMatchingReportCfgEutraAllFreq(VCCB_ReportCfgAllFreqMatcher(reportType, reportPurpose), _rDbConf);
        if (MAX_NR_OF_REPORT_CONFIGIR_ID_DB <= reportCfgIdx)
        {
            VCCB_PRINT_COMMENT("Couldn't find report config EUTRA!\n");
            return;
        }
    }

    _pDbRpt = &_rDbConf.reportConfigInterRatDb[reportCfgIdx];
    _pDbUeRpt = _rDbConf.ueSpecificReportConfigInterRat[reportCfgIdx];
    _pRptCfgIdx = reportCfgIdx;

    return;
}

/****************************************************************************
 * @brief Checks if found and data is valid
 ****************************************************************************/
bool VCCB_RptCfgAndMeasObjDbFinder::isValid() const
{
    AUTO_TRACE_FUNC;

    // p.kups todo: replace it with _measObjectDbFinder->valid(), for some reason svace complains
    switch (_ratType)
    {
        case measRatNr:
            if (nullptr == _measObjectDbFinder._pDbObjNr)
            {
                return false;
            }
            break;
        case measRatEutra:
            if (nullptr == _measObjectDbFinder._pDbObjEutra)
            {
                return false;
            }
            break;
        default:
            return false;
    }

    if (nullptr == _pDbRpt)
    {
        return false;
    }
    if (nullptr == _pDbUeRpt)
    {
        return false;
    }

    return true;
}

/****************************************************************************
 * @brief           Adds a measurement identity to UE configuration if it's not
 *                  yet present and returns its id (or just returns the id
 *                  if it is already configured).
 *
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       moNewItemIdx : idx in the measurementObjects.newItems to the target measurement object. / uint8_t
 * @param[in]       rcNewItemIdx : idx in the reportConfigurations.newItems to the target report config. / uint8_t
 * @param[in]       callbackFuncId : Function to call when measurement report for
 *                                   this measurement identity is received. / enumMeasReportCallbackId_type
 * @param[out]      idx : Id of the measurement identity when installed on UE. / uint8_t*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_AddMeasurementIdentity(callInfo_type *ptCi, uint8_t moNewItemIdx, uint8_t rcNewItemIdx, uint8_t *pIdx,
    enumMeasReportCallbackId_type callbackFuncId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pIdx);

    VCCB_CHECK_E_RANGE_AND_RETURN(moNewItemIdx, MAX_NR_OF_OBJECT_ID);
    VCCB_CHECK_E_RANGE_AND_RETURN(rcNewItemIdx, MAX_NR_OF_REPORT_CONFIG_ID);

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    // Check if a matching measurement identity is already scheduled for installation
    measurementIdentity_type *pUeMeasId = util::findObjectIfExist(
        rMeasProc.measurementIdentities.newItems,
        rMeasProc.measurementIdentities.numNewItems,
        [moNewItemIdx, rcNewItemIdx](const measurementIdentity_type &measId) {
            return (measId.usage == CI_use) && (measId.moNewItemIdx == moNewItemIdx) &&
                    (measId.rcNewItemIdx == rcNewItemIdx);
        });

    // Already scheduled, grab the index and return
    if (pUeMeasId != nullptr)
    {
        *pIdx = static_cast<uint8_t>(pUeMeasId - (&rMeasProc.measurementIdentities.newItems[0]));

        return GOOD;
    }

    // Ensure we don't exceed UE capacity
    if (VCCB_IsNoMeasIdsLeft(*ptCi))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: Can't add another measurement identity - maximum number of measurement identities reached in "
            "VCCB_AddMeasurementIdentity!\n");
        return ERROR;
    }

    // Store the measurementIdentity information along with the UE data
    *pIdx = rMeasProc.measurementIdentities.numNewItems;
    pUeMeasId = &rMeasProc.measurementIdentities.newItems[*pIdx];
    pUeMeasId->usage = CI_use;
    pUeMeasId->pending = VCCB_FLAG_ON;
    pUeMeasId->moNewItemIdx = moNewItemIdx;
    pUeMeasId->measObjectId = INVALID_OBJECT_ID;
    pUeMeasId->rcNewItemIdx = rcNewItemIdx;
    pUeMeasId->reportConfigId = INVALID_OBJECT_ID;
    pUeMeasId->callbackFuncId = callbackFuncId;
    pUeMeasId->objectId = INVALID_OBJECT_ID;
    pUeMeasId->internalIdx = MAX_NR_OF_MEAS_ID;
    pUeMeasId->numberOfReportsSent = 0;
    pUeMeasId->isTainted = VCCB_FLAG_OFF;

    // Increment the elements counter
    ++rMeasProc.measurementIdentities.numNewItems;

    return GOOD;
}

/****************************************************************************
 * @brief           Removes last measurement object from UE configuration
 *                  if it's not used by any report identity.
 *
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       moNewItemIdx : idx in the measurementObjects.newItems to the target measurement object. / uint8_t
 ****************************************************************************/
void VCCB_RemoveLastMeasurementObjectIfUnused(callInfo_type *ptCi, uint8_t moNewItemIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);
    measurementIdentity_type *pUeMeasId = NULL;

    // Check if MeasurementObject was added last
    if (moNewItemIdx != rMeasProc.measurementObjects.numNewItems - 1)
    {
        return;
    }

    const size_t lastNewItemIdx = static_cast<size_t>(rMeasProc.measurementObjects.numNewItems - 1);
    VCCB_CHECK_E_RANGE_AND_VOID(lastNewItemIdx, VCCB_ARRAY_COUNT(rMeasProc.measurementObjects.newItems));

    const unsigned int maxMeasIdNumItems = util::minOfArraySizeAndNumOfElems(
        rMeasProc.measurementIdentities.newItems, rMeasProc.measurementIdentities.numNewItems);
    auto beginMeasIds = &(rMeasProc.measurementIdentities.newItems[0]);
    auto endMeasIds = beginMeasIds + maxMeasIdNumItems;
    pUeMeasId = std::find_if(beginMeasIds, endMeasIds,
        [moNewItemIdx](const measurementIdentity_type &measId)
        { return (measId.usage == CI_use) && (measId.moNewItemIdx == moNewItemIdx); });

    if (pUeMeasId == endMeasIds)
    {
        rMeasProc.measurementObjects.newItems[lastNewItemIdx].usage = CI_no_use;
        rMeasProc.measurementObjects.newItems[lastNewItemIdx].pending = VCCB_FLAG_OFF;
        rMeasProc.measurementObjects.numNewItems--;
    }
}

/****************************************************************************
 * @brief           Removes lest report configuration from UE configuration
 *                  if it's not used by any meas identity.
 *
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       rcNewItemIdx : idx in the reportConfigurations.newItems to the target report config. / uint8_t
 ****************************************************************************/
void VCCB_RemoveLastReportConfigurationIfUnused(callInfo_type *ptCi, uint8_t rcNewItemIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    // Check if ReportConfig was added last
    if (rcNewItemIdx != rMeasProc.reportConfigurations.numNewItems - 1)
    {
        return;
    }

    const size_t lastNewItemIdx = static_cast<size_t>(rMeasProc.reportConfigurations.numNewItems - 1);
    VCCB_CHECK_E_RANGE_AND_VOID(lastNewItemIdx, VCCB_ARRAY_COUNT(rMeasProc.reportConfigurations.newItems));

    const unsigned int maxMeasIdNumItems = util::minOfArraySizeAndNumOfElems(
        rMeasProc.measurementIdentities.newItems, rMeasProc.measurementIdentities.numNewItems);
    auto beginMeasIds = &(rMeasProc.measurementIdentities.newItems[0]);
    auto endMeasIds = beginMeasIds + maxMeasIdNumItems;
    measurementIdentity_type *pUeMeasId = std::find_if(beginMeasIds, endMeasIds,
        [rcNewItemIdx](const measurementIdentity_type &measId)
        { return (measId.usage == CI_use) && (measId.rcNewItemIdx == rcNewItemIdx); });

    if (pUeMeasId == endMeasIds)
    {
        rMeasProc.reportConfigurations.newItems[lastNewItemIdx].usage = CI_no_use;
        rMeasProc.reportConfigurations.newItems[lastNewItemIdx].pending = VCCB_FLAG_OFF;
        rMeasProc.reportConfigurations.numNewItems--;
    }
}

/****************************************************************************
 * @brief           Checking if report with purpose is included to MeasId
 *
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       reportType : Type of the target report configuration. / enumMeasurementReportType
 * @param[in]       reportPurpose : Purpose of the target report configuration. / uint8_t
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfReportConfigIsIncludedToMeasId(
    callInfo_type *ptCi, enumMeasurementReportType reportType, uint8_t reportPurpose)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);
    VCCB_ReportConfigurationMatcher reportConfigurationMatcher(reportType, reportPurpose);

    // Check if a report configuration with matching type and purpose is already scheduled for installation
    const reportConfigurationNewUe_type *pUeRpt = util::findObjectIfExist(
            rMeasProc.reportConfigurations.newItems,
            rMeasProc.reportConfigurations.numNewItems,
            reportConfigurationMatcher);

    if (pUeRpt == nullptr)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "Report (%d) with purpose (%d) is not added to report configuration\n", reportType, reportPurpose);
        return ERROR;
    }

    VCCB_ReportConfigurationToMeasurementIdentityMatcher reportConfigToMeasIdMatcher(pUeRpt->objectId);

    const measurementIdentity_type *pUeMeasId = util::findObjectIfExist(
            rMeasProc.measurementIdentities.newItems,
            rMeasProc.measurementIdentities.numNewItems,
            reportConfigToMeasIdMatcher);

    if (pUeMeasId == nullptr)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "Report (%d) with purpose (%d) is not included to measId\n", reportType, reportPurpose);
        return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Checking if report with purpose is added newly
 *
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       reportType : Type of the target report configuration. / enumMeasurementReportType
 * @param[in]       reportPurpose : Purpose of the target report configuration. / uint8_t
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfReportConfigIsAddedNewly(
    callInfo_type *ptCi, enumMeasurementReportType reportType, uint8_t reportPurpose)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    reportConfigurationNewUe_type *pUeRpt = NULL;
    VCCB_ReportConfigurationMatcher reportConfigurationMatcher(reportType, reportPurpose);

    // Check if a report configuration with matching type and purpose is already scheduled for installation
    pUeRpt = std::find_if(&(rMeasProc.reportConfigurations.newItems[0]),
        &(rMeasProc.reportConfigurations.newItems[rMeasProc.reportConfigurations.numNewItems]),
        reportConfigurationMatcher);

    if (pUeRpt == &(rMeasProc.reportConfigurations.newItems[rMeasProc.reportConfigurations.numNewItems]))
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "Report (%d) with purpose (%d) is not added to report configuration\n", reportType, reportPurpose);

        return ERROR;
    }

    if (pUeRpt->internalIdx < MAX_NR_OF_OBJECT_ID)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "Report (%d) with purpose (%d) is already installed on the UE\n", reportType, reportPurpose);

        return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Check MO's ssb meas timing for a cell
 *
 * @param[in]       pSsbMeasTiming : Pointer to ssb meas timing of a cell
 * @param[in]       pMeasObjNR : Pointer to MeasurementObject
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_CheckMeasObjForCell(
    const ssbMeasTiming_type *pSsbMeasTiming, const measurementObjectNRBaseDb_type *pMeasObjNR)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pSsbMeasTiming);
    VALID_E_POINT_CHECK_ERROR(pMeasObjNR);

    if (pMeasObjNR->ssbFrequency != pSsbMeasTiming->ssbFrequency)
    {
        VCCB_PRINT_COMMENT("ssbArfcn do not match MO(%u) Cell(%u) in VCCB_CheckMeasObjForCell!\n",
            pMeasObjNR->ssbFrequency, pSsbMeasTiming->ssbFrequency);
        return ERROR;
    }

    if (pMeasObjNR->ssbSubcarrierSpacing != pSsbMeasTiming->ssbSubcarrierSpacing)
    {
        VCCB_PRINT_COMMENT("SCS do not match MO(%u) Cell(%u) in VCCB_CheckMeasObjForCell!\n",
            pMeasObjNR->ssbSubcarrierSpacing, pSsbMeasTiming->ssbSubcarrierSpacing);
        return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Check MO's frequency and SCS for a scell
 *
 * @param[in]       pScell : Pointer to scell
 * @param[in]       pMeasObjNR : Pointer to MeasurementObject
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_CheckMeasObjForSCell(const scellInfo_type *pScell, const measurementObjectNRUe_type *pMeasObjNR)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pScell);
    VALID_E_POINT_CHECK_ERROR(pMeasObjNR);

    if (pMeasObjNR->minimal.ssbFrequency != pScell->ssbArfcn)
    {
        VCCB_PRINT_COMMENT("ssbArfcn do not match MO(%u) SCell(%u) in VCCB_CheckMeasObjForSCell!\n",
            pMeasObjNR->minimal.ssbFrequency, pScell->ssbArfcn);
        return ERROR;
    }

    if (pMeasObjNR->minimal.ssbSubcarrierSpacing != pScell->ssbSubcarrierSpacing)
    {
        VCCB_PRINT_COMMENT("SCS do not match MO(%u) Cell(%u) in VCCB_CheckMeasObjForSCell!\n",
            pMeasObjNR->minimal.ssbSubcarrierSpacing, pScell->ssbSubcarrierSpacing);
        return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Get MeasObjectId for a Cell
 *
 * @param[in]       ptCi : Pointer to call configuration
 * @param[in]       newMoIdx : index of MO in newItems
 * @return          meas object id (1..64) / 0 - if not found or error
 ****************************************************************************/
uint8_t VCCB_GetMeasObjectIdForCell(callInfo_type *ptCi, uint8_t newMoIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, 0);

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    if (VCCB_ARRAY_COUNT(rMeasProc.measurementObjects.newItems) < rMeasProc.measurementObjects.numNewItems)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: Invalid numNewItems(%hu) in VCCB_GetMeasObjectIdForCell, maximum allowed number is %lu!\n",
            rMeasProc.measurementObjects.numNewItems, VCCB_ARRAY_COUNT(rMeasProc.measurementObjects.newItems));
        return 0;
    }

    if (newMoIdx >= rMeasProc.measurementObjects.numNewItems)
    {
        // newMoIdx not set
        return 0;
    }

    measurementObjectUe_type *pUeMeasObj = &rMeasProc.measurementObjects.newItems[newMoIdx];

    if (INVALID_OBJECT_ID == pUeMeasObj->objectId)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "MeasObjId is invalid in VCCB_GetMeasObjectIdForCell!\n");
        return 0;
    }

    // found in newItems
    uint8_t objectId = static_cast<uint8_t>(pUeMeasObj->objectId + 1);
    return objectId;
}

/****************************************************************************
 * @brief           Check if new MO match to SCell configuration
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       ssbArfcn : SSB Arfcn of SCell and MO
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_CheckNewMeasObjectForSCell(callInfo_type *ptCi, Arfcn_type ssbArfcn)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    if (rMeasProc.measurementObjects.numNewItems > VCCB_ARRAY_COUNT(rMeasProc.measurementObjects.newItems))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: Invalid number of items (%hu) in VCCB_CheckNewMeasObjectForSCell, maximum allowed number is %lu!\n",
            rMeasProc.measurementObjects.numNewItems, VCCB_ARRAY_COUNT(rMeasProc.measurementObjects.newItems));
        return ERROR;
    }

    measurementObjectUe_type const *pUeMeasObj = util::findObjectIfExist(
        rMeasProc.measurementObjects.newItems,
        rMeasProc.measurementObjects.numNewItems,
        VCCB_FrequencyMatcher(ssbArfcn, RSType_SSB));

    if (pUeMeasObj == nullptr)
    {
        // not found
        VCCB_PRINT_CALL_COMMENT(ptCi, "MO ssbArfcn(%u) not found in VCCB_CheckNewMeasObjectForSCell!\n", ssbArfcn);
        return ERROR;
    }

    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (uint16_t cellIdx = 0; cellIdx < MAX_SCELL_PER_CALL; cellIdx++)
    {
        if (SCELL_STATE_ADDED != scells[cellIdx].state)
        {
            continue;
        }

        if (pUeMeasObj->conf.rat.nr.minimal.ssbFrequency != scells[cellIdx].ssbArfcn)
        {
            continue;
        }

        if (ERROR == VCCB_CheckMeasObjForSCell(&scells[cellIdx], &pUeMeasObj->conf.rat.nr))
        {
            VCCB_PRINT_CALL_COMMENT(
                ptCi, "MO ssbArfcn(%u) not match sCell[%u] SCS configuration!\n", ssbArfcn, cellIdx);
            return ERROR;
        }
        return GOOD;
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "MO ssbArfcn(%u) not match with any SCell!\n", ssbArfcn);
    return ERROR;
}

/****************************************************************************
 * @brief           Set tgtCellMoId for PCell MeasObjectNR.
 *                  Set tgtCellMoSsb for PCell MeasObjectNR if it is NCD-SSB.
 *
 * @param[in]       rCi: reference to the call information. / callInfo_type*
 ****************************************************************************/
void VCCB_SetTargetCellMo(callInfo_type &rCi)
{
    const measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(rCi);
    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(rCi);
    const auto tgtCellNewMoIdx = rMeasProc.tgtCellNewMoIdx;
    rMeasConf.tgtCellMoId = VCCB_GetMeasObjectIdForCell(&rCi, tgtCellNewMoIdx);
    if (tgtCellNewMoIdx >= rMeasProc.measurementObjects.numNewItems)
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "tgtCellNewMoIdx(%u) is out of range(%u)\n", tgtCellNewMoIdx,
            rMeasProc.measurementObjects.numNewItems);
        return;
    }
    const auto &measObjectUe = rMeasProc.measurementObjects.newItems[tgtCellNewMoIdx];
    if ((measObjectUe.usage == CI_use) && (measRatNr == measObjectUe.conf.ratType) &&
        (measObjectUe.conf.rat.nr.minimal.ncdSsbInfo.usage == CI_use))
    {
        rMeasConf.tgtCellMoSsb = measObjectUe.conf.rat.nr.minimal.ncdSsbInfo.ncdSsbArfcn;
    }
    else
    {
        rMeasConf.tgtCellMoSsb = UNKNOWN_ARFCN;
    }
}

/****************************************************************************
 * @brief           Applies MeasObject to PCell and SCells
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_ApplyMeasObjectToCells(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(CELLINFO);

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    if (MAX_CELL_NUM_VCCB <= rMeasProc.tgtCellNum)
    {
        // If tgtCellNum is MAX_CELL_NUM_VCCB it means that measurement preparation has not been performed
        VCCB_PRINT_CALL_COMMENT(ptCi, "tgtCellNum is out of range (%d:%d)\n", rMeasProc.tgtCellNum, MAX_CELL_NUM_VCCB);
        return GOOD;
    }

    VCCB_SetTargetCellMo(*ptCi);
    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (uint16_t cellIdx = 0; cellIdx < MAX_SCELL_PER_CALL; cellIdx++)
    {
        if (SCELL_STATE_ADDED != scells[cellIdx].state)
        {
            continue;
        }

        const uint8_t oldCellMoId = scells[cellIdx].cellMoId;
        scells[cellIdx].cellMoId = (VCCB_GetMeasObjectIdForCell(ptCi, scells[cellIdx].newMoIdx) & 0x7F);

        if ((SCELL_ACTION_KEEP == scells[cellIdx].action) &&
            (oldCellMoId != scells[cellIdx].cellMoId))
        {
            scells[cellIdx].action = SCELL_ACTION_RESETUP;
        }
    }

    return GOOD;
}

int16_t FnVCCB_AllocateIdsForAllowedCells(
    measurementsProcedure_type &rMeasProc, const measurementsConfiguration_type &rMeasConf);

/****************************************************************************
 * @brief           Applies MeasObjectToAddMod and MeasObjectToRemove configuration.
                    Can be called only once during Measurement Configuration.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_ApplyMeasObjectConfig(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);
    measurementObjectUe_type *pNewObj = NULL;
    measurementObjectUe_type *pInstalled = NULL;
    bool condSSBorAssociatedSSB = false;

    if (rMeasProc.measurementObjects.numNewItems > VCCB_ARRAY_COUNT(rMeasProc.measurementObjects.newItems))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: Invalid number of items (%hu) in VCCB_ApplyMeasObjectConfig, maximum allowed "
            "number is %lu!\n", rMeasProc.measurementObjects.numNewItems,
            VCCB_ARRAY_COUNT(rMeasProc.measurementObjects.newItems));
        return ERROR;
    }

    auto setBits = [&rMeasConf, &rMeasProc](uint8_t i)
    {
        ONBIT(rMeasProc.measurementObjects.itemsToRemove, i);
        ONBIT(rMeasProc.measurementObjects.idsToRemove, rMeasConf.measurementObjects.installedItems[i].objectId);
    };

    // if it is tainted set it for removal
    for (uint8_t i = 0; i < VCCB_ARRAY_COUNT(rMeasConf.measurementObjects.installedItems); ++i)
    {
        pInstalled = &rMeasConf.measurementObjects.installedItems[i];
        if (CI_use != pInstalled->usage)
        {
            continue;
        }
        if (VCCB_FLAG_ON == pInstalled->isTainted)
        {
            VCCB_PRINT_CALL_COMMENT(
                ptCi, "[clear-meas-conf] installed measObjectId=%d will be removed\n", pInstalled->objectId + 1);
            setBits(i);
        }
    }

    // Match items already installed on UE with the new configuration
    for (uint8_t i = 0; i < VCCB_ARRAY_COUNT(rMeasConf.measurementObjects.installedItems); ++i)
    {
        pInstalled = &rMeasConf.measurementObjects.installedItems[i];
        if ((CI_use != pInstalled->usage) || (VCCB_FLAG_ON == pInstalled->isTainted))
        {
            continue;
        }

        switch (pInstalled->conf.ratType)
        {
            case measRatNr:
            {
                condSSBorAssociatedSSB =
                    VCCB_CheckCondSsbOrAssociatedSsb(pInstalled->conf.rat.nr.minimal.referenceSignalConfig);

                if (!condSSBorAssociatedSSB)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: condSSBorAssociatedSSB false in VCCB_ApplyMeasObjectConfig!\n");
                    setBits(i);
                    continue;
                }

                VCCB_FrequencyMatcher frequencyMatcher(
                    FnVCCB_GetRrcMeasObjectNrSsbFrequency(pInstalled->conf.rat.nr.minimal), RSType_SSB);

                pNewObj = util::findObjectIfExist(
                    rMeasProc.measurementObjects.newItems, rMeasProc.measurementObjects.numNewItems, frequencyMatcher);

                break;
            }
            case measRatEutra:
            {
                pNewObj = util::findObjectIfExist(
                    rMeasProc.measurementObjects.newItems,
                    rMeasProc.measurementObjects.numNewItems,
                    VCCB_OverlappedFrequencyMatcherEutra(pInstalled->conf.rat.eutra.minimal.overlappedCarrierFreq));
                break;
            }
            default:
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: Unsupported ratType(%u) in VCCB_ApplyMeasObjectConfig!\n",
                    pInstalled->conf.ratType);
                setBits(i);
                continue;
            }
        }

        // If the item is installed but not included in new configuration, mark to delete it
        if (pNewObj == nullptr)
        {
            setBits(i);
        }
        else  // If the item is installed and included in new configuration, save the index of installed item
        {
            pNewObj->objectId = pInstalled->objectId;
            pNewObj->internalIdx = i;

            // try to fix installed carrierFreq
            if (pInstalled->conf.ratType == measRatEutra)
            {
                pInstalled->conf.rat.eutra.minimal.carrierFreq = pNewObj->conf.rat.eutra.minimal.carrierFreq;
            }
            // fix ncd ssb info
            if (pInstalled->conf.ratType == measRatNr)
            {
                FnVCCB_updateInstalledWithNcdSsbInfoIfNeeded(
                    *ptCi, pInstalled->conf.rat.nr.minimal, pNewObj->conf.rat.nr.minimal);
            }
        }
    }

    // Assign ids for allowed cells
    if (ERROR == FnVCCB_AllocateIdsForAllowedCells(rMeasProc, rMeasConf))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: FnVCCB_AllocateIdsForAllowedCells failed!\n");
        return ERROR;
    }

    if (VCCB_FLAG_ON == DBG->flag.prioritizedMeasObjectIds)
    {
        CellNum_type cellNum = rMeasProc.tgtCellNum;
        VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);

        MeasurementConfigurationObjectIdAllocator allocator(*ptCi);
        if (ERROR == allocator.allocateIdsForMeasurementObjects(CELLINFO[cellNum]))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: MeasurementConfigurationObjectIdAllocator failed!\n");
            return ERROR;
        }
    }
    else
    {
        if (ERROR == VCCB_AssignIds(rMeasConf.measurementObjects, rMeasProc.measurementObjects, MAX_NR_OF_OBJECT_ID))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_AssignIds failed for measurementObjects!\n");
            return ERROR;
        }
    }

    if (ERROR == VCCB_ApplyMeasObjectToCells(ptCi))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_ApplyMeasObjectToCells failed for measurementObjects!\n");
        return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Clear Report Config newItems and installedItems state
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 ****************************************************************************/
void VCCB_ClearReportConfigItemsState(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    rMeasProc.reportConfigurations.itemsToRemove = 0;
    rMeasProc.reportConfigurations.idsToRemove = 0;
    for (unsigned int i = 0; i < util::minOfArraySizeAndNumOfElems(
                                     rMeasProc.reportConfigurations.newItems, rMeasProc.reportConfigurations.numNewItems);
         ++i)
    {
        reportConfigurationNewUe_type &rc = rMeasProc.reportConfigurations.newItems[i];
        if (CI_use != rc.usage)
        {
            continue;
        }

        rc.objectId = INVALID_OBJECT_ID;
        rc.internalIdx = MAX_NR_OF_REPORT_CONFIG_ID;
    }
    for (auto &rc : rMeasConf.reportConfigurations.installedItems)
    {
        if (CI_use != rc.usage)
        {
            continue;
        }
        rc.pending = VCCB_FLAG_ON;
    }
}

/****************************************************************************
 * @brief           Applies ReportConfigToAddMod and ReportConfigToRemove configuration
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_ApplyReportConfig(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);
    bool insItemsAssigned[MAX_NR_OF_REPORT_CONFIG_ID];

    simpleVector<uint8_t, MAX_NR_OF_REPORT_CONFIG_ID> indexesToRemove;
    size_t numMatched = 0;

    if (rMeasProc.reportConfigurations.numNewItems > MAX_NR_OF_REPORT_CONFIG_ID)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: Invalid number of items (%hu) in VCCB_ApplyReportConfig, maximum allowed number "
            "is %d!\n", rMeasProc.reportConfigurations.numNewItems, MAX_NR_OF_REPORT_CONFIG_ID);

        return ERROR;
    }

    auto setBits = [&rMeasConf, &rMeasProc](uint8_t i)
    {
        ONBIT(rMeasProc.reportConfigurations.itemsToRemove, i);
        ONBIT(rMeasProc.reportConfigurations.idsToRemove, rMeasConf.reportConfigurations.installedItems[i].objectId);
    };

    // if it is tainted set it for removal
    for (uint8_t i = 0; i < MAX_NR_OF_REPORT_CONFIG_ID; ++i)
    {
        const reportConfigurationInstalledUe_type *pInsRpt = &rMeasConf.reportConfigurations.installedItems[i];
        if (CI_use != pInsRpt->usage)
        {
            continue;
        }
        if (VCCB_FLAG_ON == pInsRpt->isTainted)
        {
            VCCB_PRINT_CALL_COMMENT(
                ptCi, "[clear-meas-conf] installed reportConfigId=%d will be removed\n", pInsRpt->objectId + 1);
            setBits(i);
        }
    }

    // Match items already installed on UE with the new configuration
    // 1st try to find equal report config
    for (uint8_t i = 0; i < MAX_NR_OF_REPORT_CONFIG_ID; ++i)
    {
        insItemsAssigned[i] = false;

        const reportConfigurationInstalledUe_type *pInsRpt = &rMeasConf.reportConfigurations.installedItems[i];

        if ((CI_use != pInsRpt->usage) || (VCCB_FLAG_ON == pInsRpt->isTainted))
        {
            continue;
        }

        for (uint8_t newItemIdx = 0;
             newItemIdx < util::minOfArraySizeAndNumOfElems(
                              rMeasProc.reportConfigurations.newItems, rMeasProc.reportConfigurations.numNewItems);
             ++newItemIdx)
        {
            reportConfigurationNewUe_type *pNewRpt = &rMeasProc.reportConfigurations.newItems[newItemIdx];
            if ((MAX_NR_OF_REPORT_CONFIG_ID <= pNewRpt->internalIdx) &&  // not yet matched
                (false == VCCB_AreFr1PowerClassSavedDeltasEffective(pNewRpt->conf.fr1PCState.savedDeltas)) &&
                (GOOD != VCCB_CheckIfReportConfigChanged(pInsRpt, pNewRpt)))
            {
                // item installed and included in new configuration and equal
                // save the index of installed item
                pNewRpt->objectId = pInsRpt->objectId;
                pNewRpt->internalIdx = i;
                numMatched++;
                insItemsAssigned[i] = true;
                break;
            }
        }
    }
    // 2nd try to find report config with same type and purpose not assigned yet
    for (uint8_t i = 0; i < MAX_NR_OF_REPORT_CONFIG_ID; ++i)
    {
        const reportConfigurationInstalledUe_type *pInsRpt = &rMeasConf.reportConfigurations.installedItems[i];

        if ((CI_use != pInsRpt->usage) || (true == insItemsAssigned[i]) || (VCCB_FLAG_ON == pInsRpt->isTainted))
        {
            continue;
        }
        VCCB_ReportConfigNaMatcher reportConfigurationMatcher;
        reportConfigurationMatcher._type = pInsRpt->conf.reportType;
        reportConfigurationMatcher._purpose = pInsRpt->conf.reportPurpose;

        reportConfigurationNewUe_type *pNewRpt = std::find_if(&(rMeasProc.reportConfigurations.newItems[0]),
            &(rMeasProc.reportConfigurations.newItems[rMeasProc.reportConfigurations.numNewItems]),
            reportConfigurationMatcher);

        // If the item is installed but not included in new configuration, save its index in case we need to delete it
        if (pNewRpt == &(rMeasProc.reportConfigurations.newItems[rMeasProc.reportConfigurations.numNewItems]))
        {
            indexesToRemove.push_back(i);
        }
        else  // If the item is installed and included in new configuration, save the index of installed item
        {
            pNewRpt->objectId = pInsRpt->objectId;
            pNewRpt->internalIdx = i;
            numMatched++;
        }
    }

    // Prepare NRRRC_ReportConfigToRemoveList and NRRRC_ReportConfigToRemoveList if needed
    const size_t numNewNotMatched = rMeasProc.reportConfigurations.numNewItems - numMatched;
    const auto beginInstalledItems = std::begin(rMeasConf.reportConfigurations.installedItems);
    const auto endInstalledItems = std::end(rMeasConf.reportConfigurations.installedItems);
    const size_t numOfInstalledAndNotTainted = static_cast<size_t>(std::count_if(beginInstalledItems, endInstalledItems,
        [](const auto &item) { return (CI_use == item.usage) && (VCCB_FLAG_OFF == item.isTainted); }));
    // check if we exceed capacity and set for removal those report configs which are no longer used.
    if ((numOfInstalledAndNotTainted + numNewNotMatched) > MAX_NR_OF_REPORT_CONFIG_ID)
    {
        for (auto i : indexesToRemove)
        {
            setBits(i);
        }
    }

    if (ERROR ==
        VCCB_AssignIds(rMeasConf.reportConfigurations, rMeasProc.reportConfigurations, MAX_NR_OF_REPORT_CONFIG_ID))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_AssignIds failed for reportConfigurations!\n");

        return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Assigns objectIds in a way that depends on alignMeasIdWithMeasObjectId flag.
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 *
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_assignIdsForMeasIds(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint16_t gnbNum = ptCi->gnbNum;
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);

    MeasIdAllocator allocator(*ptCi);
    // First assign nrdc meas ids if exist
    if (GNBINFO[gnbNum].cfg.nrdc.measureOrderingEnable)
    {
        if (GOOD != allocator.alignMeasIdWithMeasObjectCapacity())
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: alignMeasIdWithMeasObjectCapacity failed for measurementIdentities!\n");
            return ERROR;
        }
    }

    if (GNBINFO[gnbNum].cfg.alignMeasIdWithMeasObjectId)
    {
        if (GOOD != allocator.alignMeasIdWithMeasObjectId())
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: alignMeasIdWithMeasObjectId failed for measurementIdentities!\n");
            return ERROR;
        }
    }
    else
    {
        measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);
        measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);
        if (ERROR ==
            VCCB_AssignIds(rMeasConf.measurementIdentities, rMeasProc.measurementIdentities, MAX_NR_OF_MEAS_ID))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_AssignIds failed for measurementIdentities!\n");
            return ERROR;
        }
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Clear Meas Id newItems and installedItems state
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 ****************************************************************************/
void VCCB_ClearMeasIdentitiesItemsState(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    rMeasProc.measurementIdentities.itemsToRemove = 0;
    for (unsigned int i = 0; i < util::minOfArraySizeAndNumOfElems(rMeasProc.measurementIdentities.newItems,
                                     rMeasProc.measurementIdentities.numNewItems);
         ++i)
    {
        measurementIdentity_type &mi = rMeasProc.measurementIdentities.newItems[i];
        if (CI_use != mi.usage)
        {
            continue;
        }

        mi.objectId = INVALID_OBJECT_ID;
        mi.internalIdx = MAX_NR_OF_MEAS_ID;
        mi.numberOfReportsSent = 0;
    }
    for (auto &mi : rMeasConf.measurementIdentities.installedItems)
    {
        if (CI_use != mi.usage)
        {
            continue;
        }
        mi.pending = VCCB_FLAG_ON;
    }
}

/****************************************************************************
 * @brief           Applies MeasIdToAddMod and MeasIdToRemove configuration
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 *
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_ApplyMeasIdentities(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    if (rMeasProc.measurementIdentities.numNewItems > MAX_NR_OF_MEAS_ID)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: Invalid number of items (%hu) in VCCB_MakeMeasIdConfiguration, maximum allowed "
            "number is %d!\n", rMeasProc.measurementIdentities.numNewItems, MAX_NR_OF_MEAS_ID);
        return ERROR;
    }

    // Match and save indices between newItems and installedItems, so that installed and new measurementIdentities can
    // be compared
    for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(
                                rMeasProc.measurementIdentities.newItems, rMeasProc.measurementIdentities.numNewItems);
         ++i)
    {
        VCCB_CHECK_E_RANGE_AND_RETURN(rMeasProc.measurementIdentities.newItems[i].moNewItemIdx,
            VCCB_ARRAY_COUNT(rMeasProc.measurementObjects.newItems));
        VCCB_CHECK_E_RANGE_AND_RETURN(rMeasProc.measurementIdentities.newItems[i].rcNewItemIdx,
            VCCB_ARRAY_COUNT(rMeasProc.reportConfigurations.newItems));
        rMeasProc.measurementIdentities.newItems[i].measObjectId =
            rMeasProc.measurementObjects.newItems[rMeasProc.measurementIdentities.newItems[i].moNewItemIdx].objectId;
        rMeasProc.measurementIdentities.newItems[i].reportConfigId =
            rMeasProc.reportConfigurations.newItems[rMeasProc.measurementIdentities.newItems[i].rcNewItemIdx].objectId;
    }

    // if it is tainted set it for removal
    for (uint8_t i = 0; i < VCCB_ARRAY_COUNT(rMeasConf.measurementIdentities.installedItems); ++i)
    {
        const auto &installedMI = rMeasConf.measurementIdentities.installedItems[i];
        if (CI_use != installedMI.usage)
        {
            continue;
        }
        if (VCCB_FLAG_ON == installedMI.isTainted)
        {
            VCCB_PRINT_CALL_COMMENT(
                ptCi, "[clear-meas-conf] installed measId=%d will be removed\n", installedMI.objectId + 1);
            ONBIT(rMeasProc.measurementIdentities.itemsToRemove, i);
        }
    }

    // Match items already installed on UE with the new configuration
    const uint64_t allMeasObjectIdsToRemove = VCCB_GetAllMeasObjectIdsToRemove(*ptCi);
    for (uint8_t i = 0; i < MAX_NR_OF_MEAS_ID; ++i)
    {
        if ((CI_use != rMeasConf.measurementIdentities.installedItems[i].usage) ||
            (VCCB_FLAG_ON == rMeasConf.measurementIdentities.installedItems[i].isTainted))
        {
            continue;
        }

        // If meas object is going to be removed then meas id referencing it will be automatically removed by UE.
        // We are deleting it explicitly in order to further procedures to work properly.
        if (GETBIT(allMeasObjectIdsToRemove, rMeasConf.measurementIdentities.installedItems[i].measObjectId))
        {
            ONBIT(rMeasProc.measurementIdentities.itemsToRemove, i);
            continue;
        }

        VCCB_MeasurementIdentityMatcher measurementIdentityMatcher;
        measurementIdentityMatcher._measObjId = rMeasConf.measurementIdentities.installedItems[i].measObjectId;
        measurementIdentityMatcher._rptCfgId = rMeasConf.measurementIdentities.installedItems[i].reportConfigId;

        measurementIdentity_type *pNewMeasId = util::findObjectIfExist(
            rMeasProc.measurementIdentities.newItems,
            rMeasProc.measurementIdentities.numNewItems,
            measurementIdentityMatcher);

        // If the item is installed but not included in new configuration, save its index to delete it later
        if (pNewMeasId == nullptr)
        {
            ONBIT(rMeasProc.measurementIdentities.itemsToRemove, i);
        }
        else  // If the item is installed and included in new configuration, save the index of installed item
        {
            pNewMeasId->internalIdx = rMeasConf.measurementIdentities.installedItems[i].internalIdx;
            pNewMeasId->objectId = rMeasConf.measurementIdentities.installedItems[i].objectId;
            pNewMeasId->numberOfReportsSent = rMeasConf.measurementIdentities.installedItems[i].numberOfReportsSent;
        }
    }

    int16_t status = VCCB_assignIdsForMeasIds(ptCi);
    if (GOOD != status)
    {
        return status;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Clear measGapConfig from DU. Used in inter-DU scenario.
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 ****************************************************************************/
void VCCB_ClearMeasGapConfigDu(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    mGapCfgNode_type &rmGapCfgDst = FnVCCB_GetMGapDuData(*ptCi).mGapCfgNew;

    rmGapCfgDst.fr2.flag = VCCB_FLAG_OFF;

    if (E_CALLTYPE_NSA != ptCi->callType)
    {
        rmGapCfgDst.fr1.flag = VCCB_FLAG_OFF;
        rmGapCfgDst.ue.flag = VCCB_FLAG_OFF;
    }
}

/****************************************************************************
 * @brief           Checks if an object with given id is present
 *                  in an array.
 *
 * @param           <TElem> : Type of items in target array. / TElem
 * @param[in]       id : ID of the object to find. / uint8_t
 * @param[in]       array : Target array to search in. / TElem*
 * @param[in]       size : Size of the array. / uint8_t
 * @param[out]      idx : Index of the item if found. If the element wasn't found
 *                        it's equal to size (GOOD, ERROR). / uint8_t*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
template <typename TElem>
int16_t VCCB_FindObjectById(uint8_t id, TElem *array, uint8_t size, uint8_t *idx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(array);
    VALID_E_POINT_CHECK_ERROR(idx);

    VCCB_IdMatcher<TElem> matcher(id);
    TElem *pObj;

    pObj = std::find_if(&(array[0]), &(array[size]), matcher);

    if (pObj != &(array[size]))
    {
        *idx = static_cast<uint8_t>(pObj - array);
    }
    else
    {
        *idx = size;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Create Report Config for CGI
 *
 * @param[in]       rCi :                call information
 * @return          reportCgi : reportConfigurationConfUe_type
 ****************************************************************************/
reportConfigurationConfUe_type FnVCCB_CreateReportCGICandidate(const callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;
    reportConfigurationConfUe_type reportCgi;
    memset(&reportCgi, 0x0, sizeof(reportConfigurationConfUe_type));

    reportCgi.measObjectSelection = ALL_MEASOBJECT_SELECTION;
    reportCgi.reportType = measReport_reportCGI;
    reportCgi.reportPurpose = (IS_REPORT_CGI_FOR_HANDOVER((&rCi)) == VCCB_FLAG_ON) ? reportCgiPurpose_ReportCgi_Handover
                                                                                   : reportCgiPurpose_ReportCgi;
    reportCgi.reportConfiguration.reportCgi.cellForWhichToReportCGI = rCi.anrInfo.pci;
    reportCgi.rsType = static_cast<enumRSType>(rCi.anrInfo.rsType);

    if (TRUE == GET_REPORT_CGI_AUTONOMOUS_GAP_FLAG((&rCi)))
    {
        reportCgi.reportConfiguration.reportCgi.useAutonomousGaps_flag = VCCB_FLAG_ON;
    }
    else
    {
        reportCgi.reportConfiguration.reportCgi.useAutonomousGaps_flag = VCCB_FLAG_OFF;
    }
    return reportCgi;
}

/****************************************************************************
 * @brief           Create Report Config for CGI EUTRA
 *
 * @param[in]       rCi :                call information
 * @return          reportCgi : reportConfigurationConfUe_type
 ****************************************************************************/
reportConfigurationConfUe_type FnVCCB_CreateReportCGIEutraCandidate(const callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;
    reportConfigurationConfUe_type reportCgi;
    memset(&reportCgi, 0x0, sizeof(reportConfigurationConfUe_type));

    reportCgi.measObjectSelection = ALL_MEASOBJECT_SELECTION;
    reportCgi.reportType = measReport_reportCGIEutra;
    reportCgi.reportPurpose = (IS_REPORT_CGI_FOR_HANDOVER((&rCi)) == VCCB_FLAG_ON)
                                  ? reportCgiPurpose_ReportCgiEutra_Handover
                                  : reportCgiPurpose_ReportCgiEutra;
    reportCgi.reportConfiguration.reportCgiEutra.cellForWhichToReportCGI = rCi.anrInfo.pci;
    reportCgi.rsType = RSType_SSB;

    if (TRUE == GET_REPORT_CGI_AUTONOMOUS_GAP_FLAG((&rCi)))
    {
        reportCgi.reportConfiguration.reportCgiEutra.useAutonomousGaps_flag = VCCB_FLAG_ON;
    }
    else
    {
        reportCgi.reportConfiguration.reportCgiEutra.useAutonomousGaps_flag = VCCB_FLAG_OFF;
    }
    return reportCgi;
}

/****************************************************************************
 * @brief           Create Measurement Object for CGI
 *
 * @param[in]       rCi :                call information
 * @return          minimalMeasObj : std::optional<minimalMeasObjectConfUe_type>
 ****************************************************************************/
std::optional<minimalMeasObjectConfUe_type> CreateMeasObjectNRCandidateForAnrReportCgi(const callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    const enumRSType rsType = static_cast<enumRSType>(rCi.anrInfo.rsType);
    if (RSType_SSB != rsType)
    {
        VCCB_PRINT_ERROR("ERROR: Invalid rsType (%u) in CreateMeasObjectNRCandidateForAnrReportCgi!\n", rsType);
        return std::nullopt;
    }

    const measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(rCi);
    const Arfcn_type freq = rCi.anrInfo.freq;

    auto frequencyNrCdSsbMatcher = [freq](const measurementObjectUe_type &measObj)
    {
        return (CI_use == measObj.usage) && (measRatNr == measObj.conf.ratType) &&
               (measObj.conf.rat.nr.minimal.ssbFrequency == freq);  // compare CD-SSB frequency
    };

    const auto measObjDb = std::find_if(&(rMeasProc.measurementObjects.newItems[0]),
        &(rMeasProc.measurementObjects.newItems[rMeasProc.measurementObjects.numNewItems]), frequencyNrCdSsbMatcher);

    if (measObjDb == &(rMeasProc.measurementObjects.newItems[rMeasProc.measurementObjects.numNewItems]))
    {
        VCCB_PRINT_COMMENT("Couldn't find NR measurement object with freq(%u)!\n", freq);
        return std::nullopt;
    }

    minimalMeasObjectConfUe_type minimalMeasObj;
    minimalMeasObj.ratType = measObjDb->conf.ratType;
    minimalMeasObj.rat.nr = measObjDb->conf.rat.nr.minimal;
    // disable NCD-SSB
    minimalMeasObj.rat.nr.ncdSsbInfo.usage = CI_no_use;
    return minimalMeasObj;
}

/****************************************************************************
 * @brief           Create Measurement Object for CGI EUTRA
 *
 * @param[in]       rCi :                call information
 * @return          minimalMeasObj : std::optional<minimalMeasObjectConfUe_type>
 ****************************************************************************/
std::optional<minimalMeasObjectConfUe_type> CreateMeasObjectEutraCandidateForAnrReportCgi(const callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    const measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(rCi);
    const Arfcn_type freq = rCi.anrInfo.freq;

    const auto measObjDb = std::find_if(&(rMeasProc.measurementObjects.newItems[0]),
        &(rMeasProc.measurementObjects.newItems[rMeasProc.measurementObjects.numNewItems]),
        VCCB_FrequencyMatcherEutra(freq));

    if (measObjDb == &(rMeasProc.measurementObjects.newItems[rMeasProc.measurementObjects.numNewItems]))
    {
        VCCB_PRINT_COMMENT("Couldn't find EUTRA measurement object with freq(%u)!\n", freq);
        return std::nullopt;
    }

    minimalMeasObjectConfUe_type minimalMeasObj;
    minimalMeasObj.ratType = measObjDb->conf.ratType;
    minimalMeasObj.rat.eutra = measObjDb->conf.rat.eutra.minimal;

    return minimalMeasObj;
}

/****************************************************************************
 * @brief           Adds information necessary for performing requested
 *                  measurement to new UE configuration.
 *
 *                  Once report config candidate or meas object candidate is passed to this function it cannot be
 *changed! All modification should be made before this function is called. If report config or meas object is changed
 *within this function measurement configuration could end up in inconsistent state.
 *
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       cellNum : cell for which measurement is being configured / CellNum_type/uint16_t
 * @param[in]       pReportConfigCandidate : pointer to report config to install / reportConfigurationConfUe_type*
 * @param[in]       pMeasObjectCandidate : pointer to meas object to install / measurementObjectConfUe_type*
 * @param[in]       callbackFuncId : Function ID to call when measurement report for
 *                                   this measurement is received. / enumMeasReportCallbackId_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
static int16_t VCCB_AddMeasurement(callInfo_type *ptCi, CellNum_type cellNum,
    const reportConfigurationConfUe_type *pReportConfigCandidate,
    const minimalMeasObjectConfUe_type *pMeasObjectCandidate, enumMeasReportCallbackId_type callbackFuncId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VALID_E_POINT_CHECK_ERROR(pReportConfigCandidate);
    VALID_E_POINT_CHECK_ERROR(pMeasObjectCandidate);

    uint8_t moNewItemIdx = MAX_NR_OF_OBJECT_ID;
    uint8_t rcNewItemIdx = MAX_NR_OF_REPORT_CONFIG_ID;
    uint8_t rptIdId = MAX_NR_OF_MEAS_ID;
    const measurementsData_type *pDbConf = &(CELLINFO[cellNum].measurementsData);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    if ((rMeasProc.tgtCellNum != MAX_CELL_NUM_VCCB) &&
        (rMeasProc.tgtCellNum != cellNum))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: AddMeasurement - measurements are already being configured for cell (%u)!\n",
            rMeasProc.tgtCellNum);

        return ERROR;
    }
    rMeasProc.tgtCellNum = cellNum;

    switch (pMeasObjectCandidate->ratType)
    {
        case measRatNr:
        {
            if (VCCB_FLAG_OFF == rMeasProc.quantityConfigurations.statusNR)
            {
                const auto& src = pDbConf->quantityConfigurations;
                std::copy(begin(src), end(src), rMeasProc.quantityConfigurations.newItem.nr);
                rMeasProc.quantityConfigurations.statusNR = VCCB_FLAG_ON;
            }
            const enumRSType rsType = (enumRSType)pReportConfigCandidate->rsType;
            if (GOOD !=
                VCCB_AddMeasurementObjectNR(ptCi, cellNum, &pMeasObjectCandidate->rat.nr, rsType, &moNewItemIdx))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_AddMeasurementObjectNR failed in VCCB_AddMeasurement!\n");
                return ERROR;
            }
            else
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "Scheduled measObject NR Id(%u) (frequency: %u/%d) for installation\n",
                    moNewItemIdx, FnVCCB_GetRrcMeasObjectNrSsbFrequency(pMeasObjectCandidate->rat.nr), rsType);
            }
            break;
        }
        case measRatEutra:
        {
            if (VCCB_FLAG_OFF == rMeasProc.quantityConfigurations.statusEUTRA)
            {
                rMeasProc.quantityConfigurations.newItem.eutra = pDbConf->quantityConfigurationEUTRA;
                rMeasProc.quantityConfigurations.statusEUTRA = VCCB_FLAG_ON;
            }
            if (GOOD != VCCB_AddMeasurementObjectEUTRA(ptCi, cellNum, &pMeasObjectCandidate->rat.eutra, &moNewItemIdx))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_AddMeasurementObjectEUTRA failed in VCCB_AddMeasurement\n");
                return ERROR;
            }
            else
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "Scheduled measObject EUTRA %hu (frequency: %u/%u) for installation!\n",
                    moNewItemIdx, pMeasObjectCandidate->rat.eutra.carrierFreq,
                    pMeasObjectCandidate->rat.eutra.overlappedCarrierFreq);
            }
            break;
        }
        default:
            VCCB_PRINT_ERROR("ratType(%u) not supported!\n", pMeasObjectCandidate->ratType);
            return ERROR;
    }

    if (GOOD != VCCB_AddReportConfiguration(ptCi, pReportConfigCandidate, &rcNewItemIdx))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: AddReportConfiguration failed in VCCB_AddMeasurement!\n");
        VCCB_RemoveLastMeasurementObjectIfUnused(ptCi, moNewItemIdx);

        return ERROR;
    }
    else
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "Scheduled report configuration %hu (reportType %hu, reportPurpose %hu) for installation!\n", rcNewItemIdx,
            pReportConfigCandidate->reportType, pReportConfigCandidate->reportPurpose);
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(rcNewItemIdx, MAX_NR_OF_REPORT_CONFIG_ID);

    if (GOOD != VCCB_AddMeasurementIdentity(ptCi, moNewItemIdx, rcNewItemIdx, &rptIdId, callbackFuncId))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: AddMeasurementIdentity failed in VCCB_AddMeasurement!\n");
        VCCB_RemoveLastMeasurementObjectIfUnused(ptCi, moNewItemIdx);
        VCCB_RemoveLastReportConfigurationIfUnused(ptCi, rcNewItemIdx);

        return ERROR;
    }
    else
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "Scheduled measurement identity %hu (frequency: %u, reportType %hu, reportPurpose %hu) "
            "for installation!\n",
            rptIdId, VCCB_getArfcnFromMeasurementObject(*pMeasObjectCandidate), pReportConfigCandidate->reportType,
            pReportConfigCandidate->reportPurpose);
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Add Anr Report CGI Measurement
 *
 * @param[in,out]   ptCi :          call information
 * @param[in]       cellNum :       cell for which measurement is being configured
 ****************************************************************************/
void VCCB_AddAnrReportCgiMeasurement(callInfo_type *ptCi, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    int16_t status = GOOD;

    if (ptCi->anrInfo.ratType == nrType)
    {
        if (auto measObjectCandidate = CreateMeasObjectNRCandidateForAnrReportCgi(*ptCi);
            measObjectCandidate.has_value())
        {
            reportConfigurationConfUe_type rptCfgCandidate = FnVCCB_CreateReportCGICandidate(*ptCi);
            status = VCCB_AddMeasurement(ptCi, cellNum, &rptCfgCandidate, &measObjectCandidate.value(),
                FUN_2_MEASREPORTCALLBACKID(VCCM_ProcMrReportCgi));
        }
    }
    else  // eutraType
    {
        if (auto measObjectCandidate = CreateMeasObjectEutraCandidateForAnrReportCgi(*ptCi);
            measObjectCandidate.has_value())
        {
            reportConfigurationConfUe_type rptCfgCandidate = FnVCCB_CreateReportCGIEutraCandidate(*ptCi);
            status = VCCB_AddMeasurement(ptCi, cellNum, &rptCfgCandidate, &measObjectCandidate.value(),
                FUN_2_MEASREPORTCALLBACKID(VCCM_ProcMrReportCgiEutra));
        }
    }

    if (GOOD != status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_AddMeasurement failed in VCCB_AddAnrReportCgiMeasurement!\n");
    }
}

void VCCB_AddAnrMnsReportCgiNrMeasurement(callInfo_type *ptCi, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    measurementsData_type *pDbConf = &(pCell->measurementsData);

    // Find MeasObject in DB
    enumRSType rsType = static_cast<enumRSType>(ptCi->anrInfo.rsType);
    uint8_t measObjDbIdx = findIdxOfMatchingMeasObjectNr(VCCB_FrequencyMatcher(ptCi->anrInfo.freq, rsType), *pDbConf);
    if (VCCB_ARRAY_COUNT(pDbConf->measurementObjectsNRDb) <= measObjDbIdx)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Couldn't find meas object with freq(%u) and rsType(%u) for cell(%u)!\n",
            ptCi->anrInfo.freq, rsType, cellNum);
        return;
    }

    const measurementObjectNRBaseDb_type *pDbObj = &pDbConf->measurementObjectsNRDb[measObjDbIdx].base;
    minimalMeasObjectConfUe_type measObjectCandidate;
    if (!VCCB_PrepareMeasObjectNrUeCandidate(*ptCi, cellNum, pDbObj, &measObjectCandidate))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "MO ssbArfcn(%u) not supported by UE!\n", pDbObj->ssbFrequency);
        return;
    }
    measObjectCandidate.rat.nr.ncdSsbInfo.usage = false;  // disable NCD SSB frequency

    reportConfigurationConfUe_type rptCfgCandidate;
    memset(&rptCfgCandidate, 0, sizeof(reportConfigurationConfUe_type));
    if (VCCB_FLAG_ON == GET_REPORT_CGI_AUTONOMOUS_GAP_FLAG(ptCi))
    {
        rptCfgCandidate.reportConfiguration.reportCgi.useAutonomousGaps_flag = VCCB_FLAG_ON;
    }
    rptCfgCandidate.reportConfiguration.reportCgi.cellForWhichToReportCGI = ptCi->anrInfo.pci;
    rptCfgCandidate.rsType = rsType;
    ONBIT_U32(rptCfgCandidate.measObjectSelection, measObjDbIdx);
    rptCfgCandidate.reportType = measReport_reportCGI;
    rptCfgCandidate.reportPurpose = reportCgiPurpose_ReportCgi;

    if (ERROR == VCCB_AddMeasurement(ptCi, cellNum, &rptCfgCandidate, &measObjectCandidate,
                     FUN_2_MEASREPORTCALLBACKID(VCCM_ProcMrReportCgi)))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "VCCB_AddMeasurement failed when installing measurement with "
            "reportCgiPurpose_ReportCgi (ssbArfcn: %u)\n", pDbObj->ssbFrequency);
    }
    VCCB_PRINT_CALL_COMMENT(ptCi, "install measurement with reportCgiPurpose_ReportCgi (ssbArfcn: %u)\n",
        pDbObj->ssbFrequency);

    return;
}

void VCCB_AddAnrMnsReportCgiEutraMeasurement(callInfo_type *ptCi, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    measurementsData_type *pDbConf = &(pCell->measurementsData);

    // Find MeasObject in DB
    measurementObjectEUTRADb_type *pDbObjEutra = NULL;

    // Try to find a measurement object with matching frequency in database
    pDbObjEutra = std::find_if(&(pDbConf->measurementObjectsEUTRADb[0]),
        &(pDbConf->measurementObjectsEUTRADb[MAX_NR_OF_OBJECTEUTRA_ID_DB]),
        VCCB_FrequencyMatcherEutra(ptCi->anrInfo.freq));

    uint8_t measObjDbIdx = static_cast<uint8_t>(pDbObjEutra - &pDbConf->measurementObjectsEUTRADb[0]);

    if (MAX_NR_OF_OBJECTEUTRA_ID_DB <= measObjDbIdx)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "Couldn't find meas object EUTRA freq(%u) for cell(%u)!\n", ptCi->anrInfo.freq, cellNum);
        return;
    }

    const measurementObjectEUTRABaseDb_type *pDbObj = &pDbConf->measurementObjectsEUTRADb[measObjDbIdx].base;
    minimalMeasObjectConfUe_type measObjectCandidate;
    if (!VCCB_PrepareMeasObjectEutraUeCandidate(*ptCi, pDbObj, &measObjectCandidate))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "MO ssbArfcn(%u) not supported by UE!\n", pDbObj->carrierFreq);
        return;
    }

    reportConfigurationConfUe_type rptCfgCandidate;
    memset(&rptCfgCandidate, 0, sizeof(reportConfigurationConfUe_type));
    if (VCCB_FLAG_ON == GET_REPORT_CGI_AUTONOMOUS_GAP_FLAG(ptCi))
    {
        rptCfgCandidate.reportConfiguration.reportCgiEutra.useAutonomousGaps_flag = VCCB_FLAG_ON;
    }
    rptCfgCandidate.reportConfiguration.reportCgiEutra.cellForWhichToReportCGI = ptCi->anrInfo.pci;
    rptCfgCandidate.rsType = RSType_SSB;
    ONBIT_U32(rptCfgCandidate.measObjectSelection, measObjDbIdx);
    rptCfgCandidate.reportType = measReport_reportCGIEutra;
    rptCfgCandidate.reportPurpose = reportCgiPurpose_ReportCgiEutra;

    if (ERROR == VCCB_AddMeasurement(ptCi, cellNum, &rptCfgCandidate, &measObjectCandidate,
                     FUN_2_MEASREPORTCALLBACKID(VCCM_ProcMrReportCgiEutra)))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "VCCB_AddMeasurement failed when installing measurement with "
            "reportCgiPurpose_ReportCgiEutra (freq: %u)\n", pDbObj->carrierFreq);
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "install measurement with reportCgiPurpose_ReportCgiEutra (freq: %u)\n",
        pDbObj->carrierFreq);

    return;
}

/****************************************************************************
 * @brief           Add Anr MNS Report CGI Measurement
 *
 * @param[in,out]   ptCi :          call information
 * @param[in]       cellNum :       cell for which measurement is being configured
 ****************************************************************************/
void VCCB_AddAnrMnsReportCgiMeasurement(callInfo_type *ptCi, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    switch (ptCi->anrInfo.ratType)
    {
        case nrType:
            VCCB_AddAnrMnsReportCgiNrMeasurement(ptCi, cellNum);
            break;

        case eutraType:
            VCCB_AddAnrMnsReportCgiEutraMeasurement(ptCi, cellNum);
            break;

        default:
            VCCB_PRINT_LOG_ANR(ptCi, "(ANR) ratType is unknown. MNS cannot be trigger.\n");
            break;
    }

    return;
}

/****************************************************************************
 * @brief  Remove new items indicated by ptIdxNotRem
 * @param  ptIdxNotRem   : pointer to table indicating if item is to be removed (0 - remove, 0 < keep).
 * @param  ptIdxMap      : pointer to return table that maps old idx to new idx after removing items.
 * @return void
 ****************************************************************************/
template <typename ItemT, typename ConfigT>
void VCCB_RemoveUnusedNewItems(ConfigT &rMeasItems, const uint8_t MAX_NUM, uint8_t *ptIdxNotRem, uint8_t *ptIdxMap)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptIdxNotRem);
    VALID_E_POINT_CHECK_VOID(ptIdxMap);

    uint8_t newIdx = 0;
    auto lastItem = std::remove_if(rMeasItems.newItems, rMeasItems.newItems + MIN(MAX_NUM, rMeasItems.numNewItems),
        [&](const ItemT &rItem)
        {
            long int idx = &rItem - rMeasItems.newItems;
            if (idx < 0)
            {
                return false;
            }
            if (0 == ptIdxNotRem[idx])
            {
                ptIdxMap[idx] = MAX_NUM;
                return true;
            }
            ptIdxMap[idx] = newIdx;
            newIdx++;
            return false;
        });
    rMeasItems.numNewItems = static_cast<uint8_t>(lastItem - rMeasItems.newItems);
}

/****************************************************************************
 * @brief  Get NR band for UE and MO
 * @param  ptCi           : pointer to UE Context
 * @param  ptMeasObj      : pointer to MeasObj to be checked
 * @return uint16_t       : band value,  0 - no supported band
 ****************************************************************************/
uint16_t VCCB_GetMoNrBandForUe(const callInfo_type *ptCi, const measurementObjectNRBaseDb_type *pObj)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ZERO(ptCi);
    VALID_E_POINT_CHECK_ZERO(pObj);

    for (const freqBand_type &rFreqBand : pObj->freqBandIndicatorDbList.freqBand)
    {
        if (CI_use != rFreqBand.usage)
        {
            continue;
        }
        for (uint32_t ueBIdx = 0;
             ueBIdx < util::minOfArraySizeAndNumOfElems(
                          ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR, ptCi->ueInfo.ueCapa.nr.rf.nrOfBands);
             ueBIdx++)
        {
            if (ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR[ueBIdx].bandNR == rFreqBand.band)
            {
                return rFreqBand.band;
            }
        }
    }

    return 0;
}

/****************************************************************************
 * @brief  Get EUTRA band for UE and MO
 * @param  ptCi           : pointer to UE Context
 * @param  ptMeasObj      : pointer to MeasObj to be checked
 * @return uint16_t       : band value,  0 - no supported band
 ****************************************************************************/
uint16_t VCCB_GetMoEutraBandForUe(
    callInfo_type *ptCi, const measurementObjectEUTRABaseDb_type *pObj, Arfcn_type *pEarfcn)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ZERO(ptCi);
    VALID_E_POINT_CHECK_ZERO(pObj);
    VALID_E_POINT_CHECK_ZERO(pEarfcn);

    const freqBand_type *pFreqBand = NULL;

    if (ptCi->ueInfo.ueCapa.nr.eutraParam.mfbiEUTRA)
    {
        // if UE supports mfbiEUTRA then use overlapping band

        // if overlapping band priority is enabled, the operating band (idx 0) will be checked at the end
        const uint8_t startIdx = pObj->overlappingFreqBandIndicatorPriority ? 1 : 0;

        for (uint8_t i = 0; i < MAX_MEAS_FREQ_BAND_COMMON_NR_EUTRA; i++)
        {
            const uint8_t moBIdx = (i + startIdx) % MAX_MEAS_FREQ_BAND_COMMON_NR_EUTRA;
            pFreqBand = &pObj->freqBandIndicatorDbList.freqBand[moBIdx];
            if (pFreqBand->usage == CI_no_use)
            {
                continue;
            }
            if (VCCB_FLAG_ON == VLIB_IsEutraBandSupported(ptCi, pFreqBand->band))
            {
                *pEarfcn = ConvertDlEarfcn1ToDlEarfcn2(pObj->carrierFreq, pFreqBand->band);
                if (MISCU_INVALID_EARFCN == *pEarfcn)
                {
                    VCCB_PRINT_CALL_ERROR(
                        ptCi, "ERROR convert earfcn(%u) for target band(%u)!\n", pObj->carrierFreq, pFreqBand->band);
                    return BAND_NOT_FOUND;
                }
                return pFreqBand->band;
            }
        }
    }
    else
    {
        // if UE does not support mfbiEUTRA do not use overlapping band
        uint16_t band = GetEutraBandIndicatorByEARFCN(pObj->carrierFreq);
        if (VCCB_FLAG_ON == VLIB_IsEutraBandSupported(ptCi, band))
        {
            *pEarfcn = pObj->carrierFreq;
            return band;
        }
    }

    return BAND_NOT_FOUND;
}

/****************************************************************************
 * @brief  Function verifies whether UE bandNr ChannelBWs contain MeasObj supportedBandwidth
 * @param  ptCi           : pointer to UE bandNr to be checked
 * @param  pObj           : pointer to MeasObj
 * @return int16_t        : GOOD, ERROR, BREAK / int16_t
 ****************************************************************************/
int16_t VCCB_checkMeasObjSupportedBandwidth(
    const callInfo_type *ptCi, const uint16_t bandNrIdx, const measurementObjectNRBaseDb_type *pObj)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(bandNrIdx, MAX_NUM_UECAPA_NR_BANDS);
    VALID_E_POINT_CHECK_ERROR(pObj);

    const bandNrUeCapa_type *pBandNrUeCapa = &ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR[bandNrIdx];

    uint16_t filter = 0, ueBandwidthDlBits = 0, ueBandwidthUlBits = 0;

    // Check FR1 5-80MHz (FR1 5-90MHz for ENDC).
    if ((MIN_A6_NR_ARFCN > pObj->ssbFrequency) &&
        ((ci_nr_bandwidth_80MHz >= pObj->supportedBandwidth) ||
            ((ci_nr_bandwidth_90MHz == pObj->supportedBandwidth) && (IS_ENDC(ptCi)))))

    {
        filter = VLIB_getBandWidthFilter(FrequencyRange_FR1, pObj->supportedBandwidth);

        const bool ueSupport90MHzDl = isUe90MHzSupportDl(ptCi) == GOOD;
        const bool ueSupport90MHzUl = isUe90MHzSupportUl(ptCi) == GOOD;

        // SCS 15KHz.
        ueBandwidthDlBits = VLIB_getCombinedChannelBWsBits(pBandNrUeCapa->channelBWs_DL.frType.fr1.scs_15kHz,
            pBandNrUeCapa->channelBWs_DL_v1590.frType.fr1.scs_15kHz, ueSupport90MHzDl);
        ueBandwidthUlBits = VLIB_getCombinedChannelBWsBits(pBandNrUeCapa->channelBWs_UL.frType.fr1.scs_15kHz,
            pBandNrUeCapa->channelBWs_UL_v1590.frType.fr1.scs_15kHz, ueSupport90MHzUl);
        // Both DL and UL must be supported.
        if (((filter & ueBandwidthDlBits) != 0) && ((filter & ueBandwidthUlBits) != 0))
        {
            return GOOD;
        }

        // SCS 30KHz.
        ueBandwidthDlBits = VLIB_getCombinedChannelBWsBits(pBandNrUeCapa->channelBWs_DL.frType.fr1.scs_30kHz,
            pBandNrUeCapa->channelBWs_DL_v1590.frType.fr1.scs_30kHz, ueSupport90MHzDl);
        ueBandwidthUlBits = VLIB_getCombinedChannelBWsBits(pBandNrUeCapa->channelBWs_UL.frType.fr1.scs_30kHz,
            pBandNrUeCapa->channelBWs_UL_v1590.frType.fr1.scs_30kHz, ueSupport90MHzUl);
        // Both DL and UL must be supported.
        if (((filter & ueBandwidthDlBits) != 0) && ((filter & ueBandwidthUlBits) != 0))
        {
            return GOOD;
        }

        // SCS 60KHz.
        ueBandwidthDlBits = VLIB_getCombinedChannelBWsBits(pBandNrUeCapa->channelBWs_DL.frType.fr1.scs_60kHz,
            pBandNrUeCapa->channelBWs_DL_v1590.frType.fr1.scs_60kHz, ueSupport90MHzDl);
        ueBandwidthUlBits = VLIB_getCombinedChannelBWsBits(pBandNrUeCapa->channelBWs_UL.frType.fr1.scs_60kHz,
            pBandNrUeCapa->channelBWs_UL_v1590.frType.fr1.scs_60kHz, ueSupport90MHzUl);
        // Both DL and UL must be supported.
        if (((filter & ueBandwidthDlBits) != 0) && ((filter & ueBandwidthUlBits) != 0))
        {
            return GOOD;
        }

        VCCB_PRINT_CALL_COMMENT(ptCi, "MO supportedBandwidth(%u) not supported by UE.\n", pObj->supportedBandwidth);
        return BREAK;
    }
    // Check FR2 50-200MHz.
    else if ((MIN_A6_NR_ARFCN <= pObj->ssbFrequency) && (ci_nr_bandwidth_200MHz >= pObj->supportedBandwidth))
    {
        filter = VLIB_getBandWidthFilter(FrequencyRange_FR2, pObj->supportedBandwidth);

        // SCS 60KHz.
        ueBandwidthDlBits = pBandNrUeCapa->channelBWs_DL.frType.fr2.scs_60kHz;
        ueBandwidthUlBits = pBandNrUeCapa->channelBWs_UL.frType.fr2.scs_60kHz;
        // Both DL and UL must be supported.
        if (((filter & ueBandwidthDlBits) != 0) && ((filter & ueBandwidthUlBits) != 0))
        {
            return GOOD;
        }

        // SCS 120KHz.
        ueBandwidthDlBits = pBandNrUeCapa->channelBWs_DL.frType.fr2.scs_120kHz;
        ueBandwidthUlBits = pBandNrUeCapa->channelBWs_UL.frType.fr2.scs_120kHz;
        // Both DL and UL must be supported.
        if (((filter & ueBandwidthDlBits) != 0) && ((filter & ueBandwidthUlBits) != 0))
        {
            return GOOD;
        }

        VCCB_PRINT_CALL_COMMENT(ptCi, "MO supportedBandwidth(%u) not supported by UE!\n", pObj->supportedBandwidth);
        return BREAK;
    }

    return GOOD;
}

/****************************************************************************
 * @brief  Function verifies whether any MeasObj cells bandwidths is supported by UE.
 * @param  ptCi           : pointer to UE Context
 * @param  objFrequency   : measObj ssbFrequency
 * @param  bandNR         : bandNR to be checked
 * @param  cellNum        : measurement configuration target Cell number
 * @return int16_t        : GOOD, ERROR, BREAK / int16_t
 ****************************************************************************/
int16_t VCCB_checkMeasObjCellsBandwidth(
    const callInfo_type *ptCi, Arfcn_type objFrequency, uint16_t bandNR, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    uint16_t nbrIdx = 0;
    nbrGnbCellInfo_type *ptNbrGnbCell = NULL;

    uint8_t noOfCells = 0;

    for (nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)  // go through all the neighbors
    {
        if (N_EQUIP == pCell->Nbr[nbrIdx].status)
        {
            continue;
        }
        if (ERROR == getNbrGnbCellByCellNbrIdx(cellNum, nbrIdx, &ptNbrGnbCell))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[checkMeasObjCellsBandwidth] getNbrGnbCellByCellNbrIdx returned ERROR cellNum(%u), nbrIdx(%u)\n",
                cellNum, nbrIdx);
            continue;
        }
        if (N_EQUIP == ptNbrGnbCell->status)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[checkMeasObjCellsBandwidth] ptNbrGnbCell->status for ptNbrGnbCell->cellId(%u) is N_EQUIP\n",
                ptNbrGnbCell->cellId);
            continue;
        }
        if (ptNbrGnbCell->ssbArfcn != objFrequency)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[checkMeasObjCellsBandwidth] ptNbrGnbCell->ssbArfcn(%u) != objFrequency(%u), "
                "ptNbrGnbCell->cellId(%u)\n",
                ptNbrGnbCell->ssbArfcn, objFrequency, ptNbrGnbCell->cellId);
            continue;
        }

        noOfCells++;

        if (GOOD == VLIB_checkIntraNRChannelBWs(ptCi, ptNbrGnbCell, bandNR, cellNum, FALSE))
        {
            return GOOD;
        }
    }

    if (0 == noOfCells)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "No Neighbor cell with ssbArfcn(%u) is there. Bandwidth Could not be checked now!\n", objFrequency);
        return GOOD;
    }

    VCCB_PRINT_CALL_COMMENT(ptCi,
        "Number of cells with ssbArfcn(%u):(%u). None of them have bandiwdth match with UE!\n", objFrequency,
        noOfCells);
    return BREAK;
}

/****************************************************************************
 * @brief  Function verifies whether or not MeasObj could be installed on UE, because of bandwidth mismatch.
 * @param  ptCi           : pointer to UE Context
 * @param  pObj           : pointer to MeasObj
 * @param  bandNR         : bandNR to be checked
 * @param  cellNum        : measurement configuration target Cell number
 * @return int16_t        : GOOD, ERROR, BREAK / int16_t
 ****************************************************************************/
int16_t VCCB_checkBandwidth(
    const callInfo_type *ptCi, const measurementObjectNRBaseDb_type *pObj, uint16_t bandNR, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pObj);
    uint16_t bandNRidx = static_cast<uint16_t>(bandNR - 1);
    int16_t status = GOOD;
    VCCB_CHECK_E_RANGE_AND_RETURN(bandNRidx, MAX_NUM_NR_BAND);

    for (bandNRidx = 0; bandNRidx < ptCi->ueInfo.ueCapa.nr.rf.nrOfBands; bandNRidx++)
    {
        if (ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR[bandNRidx].bandNR == bandNR)
        {
            break;
        }
    }

    if (bandNRidx >= ptCi->ueInfo.ueCapa.nr.rf.nrOfBands)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "bandNR(%u) not supported by UE!\n", bandNR);
        return ERROR;
    }

    if (0 < pObj->supportedBandwidth)
    {
        // FGR-CC5001 - FR58
        status = VCCB_checkMeasObjSupportedBandwidth(ptCi, bandNRidx, pObj);
    }
    else
    {
        // FGR-CC5001 - FR59
        status = VCCB_checkMeasObjCellsBandwidth(ptCi, pObj->ssbFrequency, bandNR, cellNum);
    }

    return status;
}

/****************************************************************************
 * @brief  Check if MeasObject is eligible for the UE.
 * @param  ptCi           : pointer to UE Context
 * @param  ptMeasObj      : pointer to MeasObj to be checked
 * @param  cellNum        : measurement configuration target Cell number
 * @return int16_t        : GOOD - eligible, ERROR,BREAK / int16_t
 ****************************************************************************/
int16_t VCCB_IsMeasObjectNrEligibleForUe(
    callInfo_type *ptCi, const measurementObjectNRDb_type *pObj, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pObj);

    const measurementObjectNRBaseDb_type *pBaseObj = &pObj->base;
    const measurementObjectNRExtensionDb_type *pExtensionObj = &pObj->extension;

    // Ensure UE supports the band
    uint16_t nRFrequencyBand = VCCB_GetMoNrBandForUe(ptCi, pBaseObj);
    if (0 == nRFrequencyBand)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "MO ssbArfcn(%u) bandNR not supported by UE!\n", pBaseObj->ssbFrequency);
        return BREAK;
    }

    if (GOOD != VCCB_checkBandwidth(ptCi, pBaseObj, nRFrequencyBand, cellNum))
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "MO ssbArfcn(%u) bandNr(%u) not supported!\n", pBaseObj->ssbFrequency, nRFrequencyBand);
        return BREAK;
    }

    // Check DSS support for band
    if (GOOD != VLIB_checkDssAllowed(ptCi, nRFrequencyBand, true, NULL))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "NR band(%u) not eligible for DSS!\n", nRFrequencyBand);
        return BREAK;
    }

    if (GOOD != VLIB_CanPlmnBasedControlBeUsed(ptCi, pExtensionObj->plmnBasedControl))
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "PlmnBasedControl for NR MO with ssbArfcn(%u) does not apply to this UE!\n", pBaseObj->ssbFrequency);
        return BREAK;
    }

    if (not FnVCCB_IsSsbAllowed(*ptCi, pBaseObj->ssbFrequency))
    {
        return BREAK;  // Cause is logged by the checker.
    }

    return GOOD;
}

/****************************************************************************
 * @brief  Check if MeasObject is eligible for the UE.
 * @param  ptCi           : pointer to UE Context
 * @param  ptMeasObj      : pointer to MeasObj to be checked
 * @return int16_t        : GOOD - eligible, ERROR,BREAK / int16_t
 ****************************************************************************/
int16_t VCCB_IsMeasObjectEutraEligibleForUe(callInfo_type *ptCi, const measurementObjectEUTRADb_type *pObj)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pObj);

    const measurementObjectEUTRABaseDb_type *pBase = &pObj->base;
    const measurementObjectEUTRAExtensionDb_type *pExtension = &pObj->extension;

    // Ensure UE supports the band
    Arfcn_type earfcn = 0;
    if (0 == VCCB_GetMoEutraBandForUe(ptCi, pBase, &earfcn))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "MO earfcn(%u) not supported by UE!\n", pBase->carrierFreq);
        return BREAK;
    }

    if (GOOD != VLIB_CanPlmnBasedControlBeUsed(ptCi, pExtension->plmnBasedControl))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "PlmnBasedControl for EUTRA MO with carrierFreq(%u) does not apply to this UE!\n",
            pBase->carrierFreq);
        return BREAK;
    }

    return GOOD;
}

/**
 * @brief This function verifies if ue-specific-report-config-entries X Y has the same
 *        report-type and purpose as corresponding report-config-entries X.
 *        Returns GOOD if ue-specific-report-config-entries X Y is correct.
 *
 * @param ptCi call info pointer
 * @param cellNum cell number
 * @param ratType RAT type (NR or EUTRA)
 * @param rcId report config id
 * @param ueSpecId ue specific id
 * @return int GOOD/BREAK/ERROR
 */
int VCCB_IsUeSpecificReportConfigValid(
    callInfo_type *ptCi, CellNum_type cellNum, enumMeasRatType ratType, uint8_t rcId, uint8_t ueSpecId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ueSpecId, MAX_NR_UE_SPECIFIC_REPORT_CONFIG_DB);
    if (measRatNr == ratType) VCCB_CHECK_E_RANGE_AND_RETURN(rcId, MAX_NR_OF_REPORT_CONFIG_ID_DB);
    if (measRatEutra == ratType) VCCB_CHECK_E_RANGE_AND_RETURN(rcId, MAX_NR_OF_REPORT_CONFIGIR_ID_DB);

    const auto &measDb = CELLINFO[cellNum].measurementsData;
    if (measRatNr == ratType)
    {
        auto &rUeSpecificReportConfigurationsBase = measDb.ueSpecificReportConfigurations[rcId][ueSpecId].base;

        if (rUeSpecificReportConfigurationsBase.usage != CI_use)
        {
            VCCB_PRINT_UE_SPECIFIC_REPORT_CONFIG(ptCi, "UE-SPECIFIC-REPORT-CONFIG[rcId:%d][ueSpecId:%d]: usage - %d\n",
                rcId, ueSpecId, rUeSpecificReportConfigurationsBase.usage);
            return BREAK;
        }
        if ((measDb.reportConfigurationsDb[rcId].base.reportType !=
                rUeSpecificReportConfigurationsBase.reportType) ||
            (measDb.reportConfigurationsDb[rcId].base.reportPurpose !=
                rUeSpecificReportConfigurationsBase.reportPurpose))
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                "UE-SPECIFIC-REPORT-CONFIG: (cellNum %u, rcId %u, ueId %u) report-type (%u-%u) or purpose "
                "(%u-%u) mismatch - "
                "using base RC.\n",
                cellNum, rcId, ueSpecId, measDb.reportConfigurationsDb[rcId].base.reportType,
                rUeSpecificReportConfigurationsBase.reportType,
                measDb.reportConfigurationsDb[rcId].base.reportPurpose,
                rUeSpecificReportConfigurationsBase.reportPurpose);
            return BREAK;
        }
    }
    else if (measRatEutra == ratType)
    {
        auto &rUeSpecificReportConfigInterRatBase = measDb.ueSpecificReportConfigInterRat[rcId][ueSpecId].base;

        if (rUeSpecificReportConfigInterRatBase.usage != CI_use)
        {
            VCCB_PRINT_UE_SPECIFIC_REPORT_CONFIG(ptCi,
                "UE-SPECIFIC-REPORT-CONFIG-IRAT[rcId:%d][ueSpecId:%d] : usage - %d\n", rcId, ueSpecId,
                rUeSpecificReportConfigInterRatBase.usage);
            return BREAK;
        }
        if ((measDb.reportConfigInterRatDb[rcId].base.reportType !=
                rUeSpecificReportConfigInterRatBase.reportType) ||
            (measDb.reportConfigInterRatDb[rcId].base.reportPurpose !=
                rUeSpecificReportConfigInterRatBase.reportPurpose))
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                "UE-SPECIFIC-REPORT-CONFIG-IRAT: (cellNum %u, rcId %u, ueId %u) report-type (%u-%u) or purpose "
                "(%u-%u) mismatch - "
                "using base RC.\n",
                cellNum, rcId, ueSpecId, measDb.reportConfigInterRatDb[rcId].base.reportType,
                rUeSpecificReportConfigInterRatBase.reportType,
                measDb.reportConfigInterRatDb[rcId].base.reportPurpose,
                rUeSpecificReportConfigInterRatBase.reportPurpose);
            return BREAK;
        }
    }
    else
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid rat-type (%d)!\n", static_cast<int>(ratType));
        return ERROR;
    }

    return GOOD;
}

void VCCB_FindUeSpecificIdx(callInfo_type *ptCi, VCCB_RptCfgAndMeasObjDbFinder &finder, uint8_t plmnIndex,
    uint8_t svcGrpIdx, uint8_t *pUeSpecificIdx, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pUeSpecificIdx);
    VCCB_CHECK_E_RANGE_AND_VOID(plmnIndex, MAX_PLMN_INDEX);

    *pUeSpecificIdx = MAX_NR_UE_SPECIFIC_REPORT_CONFIG_DB;

    if (E_CALLTYPE_NSA == ptCi->callType)
    {
        VCCB_CHECK_E_RANGE_AND_VOID(svcGrpIdx, MAX_ENDC_SVCGRP_ID);
        for (uint8_t i = 0; i < MAX_NR_UE_SPECIFIC_REPORT_CONFIG_DB; ++i)
        {
            if (CI_use != finder._pDbUeRpt[i].base.usage)
            {
                continue;
            }
            if (FALSE == finder._pDbUeRpt[i].extension.ueReportConfigEndc.plmn[plmnIndex].svcGrp[svcGrpIdx].isAllowed)
            {
                continue;
            }
            if (VCCB_IsUeSpecificReportConfigValid(ptCi, cellNum, finder._ratType, finder._pRptCfgIdx, i) == GOOD)
            {
                *pUeSpecificIdx = i;
                return;
            }
        }
    }
    else if (E_CALLTYPE_SA == ptCi->callType)
    {
        VCCB_CHECK_E_RANGE_AND_VOID(svcGrpIdx, MAX_SVC_GRP_DB_NUM);

        for (uint8_t ueReportIdx = 0; ueReportIdx < MAX_NR_UE_SPECIFIC_REPORT_CONFIG_DB; ueReportIdx++)
        {
            if (finder._pDbUeRpt[ueReportIdx].base.usage == CI_use)
            {
                if (finder._pDbUeRpt[ueReportIdx].extension.ueReportConfig.allowedSvcGrpId[svcGrpIdx] == false) continue;

                if (VCCB_IsUeSpecificReportConfigValid(
                        ptCi, cellNum, finder._ratType, finder._pRptCfgIdx, ueReportIdx) == GOOD)
                {
                    *pUeSpecificIdx = ueReportIdx;
                    return;
                }
            }
        }
    }

    return;
}

/****************************************************************************
 * @brief           Adds information necessary for performing requested
 *                  measurement to new UE configuration.
 *                  MeasObject shall be already added to UE config.
 *                  Missing ReportConfig can be added as a result of this procedure.
 *
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       frequency : Frequency to measure (SSB or CSI-RS). / Arfcn_type/uint32_t
 * @param[in]       reportType : Type of report configuration. / enumMeasurementReportType
 * @param[in]       reportPurpose : Purpose for installing the measurement. / uint8_t
 * @param[in]       callbackFuncId : Function to call when measurement report for
 *                                   this measurement is received. / enumMeasReportCallbackId_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_AddLateMeasurement(callInfo_type *ptCi, Arfcn_type frequency, enumMeasurementReportType reportType,
    uint8_t reportPurpose, enumMeasReportCallbackId_type callbackFuncId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(rMeasProc.tgtCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(
        rMeasProc.measurementObjects.numNewItems, VCCB_ARRAY_COUNT(rMeasProc.measurementObjects.newItems));

    // Adding new MeasObjects in this function is not supported! There is no VCCB_ApplyMeasObjectConfig in
    // VCCB_PrepareAdditionalMeasConfig.
    measurementObjectUe_type *pUeObj = NULL;
    if (measRatEutra == VCCB_GetRatType(reportType))
    {
        pUeObj = std::find_if(&(rMeasProc.measurementObjects.newItems[0]),
            &(rMeasProc.measurementObjects.newItems[rMeasProc.measurementObjects.numNewItems]),
            VCCB_OverlappedFrequencyMatcherEutra(frequency));
    }
    else
    {
        pUeObj = std::find_if(&(rMeasProc.measurementObjects.newItems[0]),
            &(rMeasProc.measurementObjects.newItems[rMeasProc.measurementObjects.numNewItems]),
            VCCB_FrequencyMatcher(frequency, RSType_SSB));
    }
    if (pUeObj == &(rMeasProc.measurementObjects.newItems[rMeasProc.measurementObjects.numNewItems]))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "MeasObject configuration with frequency(%u) not scheduled!\n", frequency);

        return BREAK;
    }

    if (measReport_A2 == reportType)
    {
        if (AddMeasurementStatus::MEAS_IDS_ADDED != VCCB_AddA2Measurement(ptCi, rMeasProc.tgtCellNum,
                                                        static_cast<enumA2Purpose>(reportPurpose), frequency,
                                                        callbackFuncId))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "Adding measId with reportConfig(%d,%d) and freq(%d) failed in VCCB_AddLateMeasurement()\n", reportType,
                reportPurpose, frequency);
        }
    }
    else
    {
        reportConfigurationConfUe_type reportConfigCandidate;
        minimalMeasObjectConfUe_type measObjectCandidate;
        if (!VCCB_CanMOAndRCBeAddedWithCandidates(*ptCi, rMeasProc.tgtCellNum, reportType, reportPurpose, frequency,
                &reportConfigCandidate, &measObjectCandidate))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "VCCB_CanMOAndRCBeAddedWithCandidates can't find reportConfig(%d,%d) and measObject(%d).\n", reportType,
                reportPurpose, frequency);
            return BREAK;
        }

        if (GOOD != VCCB_AddMeasurement(
                        ptCi, rMeasProc.tgtCellNum, &reportConfigCandidate, &measObjectCandidate, callbackFuncId))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_AddMeasurement failed in VCCB_AddMeasurement!\n");
            return ERROR;
        }
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Adds measurementObject related to serving cell to new UE configuration.
 *
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       cellNum : cell for which measurement is being configured / uint16_t
 * @param[in]       pSsbMeasTiming : SSB meas timing of serving cell for which MO is being configured/
 *ssbMeasTiming_type
 * @param[in]       freqBandIndicatorNR : selected band NR for given serving cell
 * @param[in]       allowedPciList : list of allowed PCIs
 * @return          index of new MO, MAX_NR_OF_OBJECT_ID - in case of ERROR
 ****************************************************************************/
uint8_t VCCB_AddMeasObjectForServCell(
    callInfo_type *ptCi, CellNum_type cellNum, const ssbMeasTiming_type *pSsbMeasTiming, uint16_t freqBandIndicatorNR,
    const simpleVector<uint16_t, MAX_NR_OF_PCI_RANGES> &allowedPciList)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_NR_OF_OBJECT_ID);
    VALID_E_POINT_CHECK_RET_VAL(pSsbMeasTiming, MAX_NR_OF_OBJECT_ID);
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, MAX_NR_OF_OBJECT_ID);

    const enumRSType rsType = RSType_SSB;
    Arfcn_type frequency = pSsbMeasTiming->ssbFrequency;
    int16_t status = GOOD;
    uint8_t measObjDbIdx = MAX_NR_OF_OBJECT_ID_DB;
    uint8_t measObjUeIdx = MAX_NR_OF_OBJECT_ID;
    const measurementsData_type *pDbConf = &(CELLINFO[cellNum].measurementsData);
    const measurementObjectNRBaseDb_type *pDbObj = NULL;
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    if ((rMeasProc.tgtCellNum != MAX_CELL_NUM_VCCB) &&
        (rMeasProc.tgtCellNum != cellNum))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: AddMeasurement - measurements are already being configured for cell (%u)!\n",
            rMeasProc.tgtCellNum);
        return MAX_NR_OF_OBJECT_ID;
    }
    rMeasProc.tgtCellNum = cellNum;

    // Find MeasObject in DB
    measObjDbIdx = findIdxOfMatchingMeasObjectNr(VCCB_FrequencyMatcher(frequency, rsType), *pDbConf);
    if (MAX_NR_OF_OBJECT_ID_DB <= measObjDbIdx)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "Couldn't find meas object with freq(%u) and rsType(%u) for cell(%u)!\n", frequency, rsType, cellNum);
        return MAX_NR_OF_OBJECT_ID;
    }
    pDbObj = &pDbConf->measurementObjectsNRDb[measObjDbIdx].base;

    if (ERROR == VCCB_CheckMeasObjForCell(pSsbMeasTiming, pDbObj))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "MO ssbArfcn(%u) do not match with cell's SCS/SMTC1 in VCCB_AddMeasObjectForServCell!\n",
            pDbObj->ssbFrequency);
        return MAX_NR_OF_OBJECT_ID;
    }

    if (VCCB_FLAG_OFF == rMeasProc.quantityConfigurations.statusNR)
    {
        const auto& src = pDbConf->quantityConfigurations;
        std::copy(begin(src), end(src), rMeasProc.quantityConfigurations.newItem.nr);
        rMeasProc.quantityConfigurations.statusNR = VCCB_FLAG_ON;
    }

    minimalMeasObjectConfUe_type measObjectCandidate;
    if (!VCCB_PrepareMeasObjectNrUeCandidate(*ptCi, cellNum, pDbObj, &measObjectCandidate))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "MO ssbArfcn(%u) not supported by UE!\n", pDbObj->ssbFrequency);
        return MAX_NR_OF_OBJECT_ID;
    }

    // overwrite meas object band and add allowed cells
    measObjectCandidate.rat.nr.freqBandIndicatorNR = freqBandIndicatorNR;
    FnVCCB_AddAllowedCellsToMeasObjectCandidate(measObjectCandidate, allowedPciList);

    status = VCCB_AddMeasurementObjectNR(ptCi, cellNum, &measObjectCandidate.rat.nr, rsType, &measObjUeIdx);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_AddMeasurementObjectNR failed in VCCB_AddMeasObjectForServCell!\n");
        return MAX_NR_OF_OBJECT_ID;
    }
    else if (GOOD == status)
    {
        frequency = FnVCCB_GetRrcMeasObjectNrSsbFrequency(measObjectCandidate.rat.nr);
        VCCB_PRINT_CALL_COMMENT(ptCi, "Scheduled measObject NR %hu (frequency: %u/%d) for installation!\n",
            measObjUeIdx, frequency, rsType);
        return measObjUeIdx;
    }  // else (BREAK == status)

    return MAX_NR_OF_OBJECT_ID;
}

/****************************************************************************
 * @brief           Adds a measurement object EUTRA to UE configuration if it's not yet present.
 *
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       cellNum : cell for which measurement is being configured / uint16_t
 * @param[in]       ptMO : Measurement object to be added
 * @return          status : GOOD/ERROR
 ****************************************************************************/
int16_t VCCB_AddEutraMeasObjectOnly(callInfo_type *ptCi, CellNum_type cellNum, measurementObjectEUTRADb_type *ptMO)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMO);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    uint8_t measObjId = MAX_NR_OF_OBJECT_ID;
    measurementsData_type *pDbConf = &(CELLINFO[cellNum].measurementsData);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    if ((rMeasProc.tgtCellNum != MAX_CELL_NUM_VCCB) &&
        (rMeasProc.tgtCellNum != cellNum))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: AddMeasurement - measurements are already being configured for cell (%u)!\n",
            rMeasProc.tgtCellNum);
        return ERROR;
    }
    rMeasProc.tgtCellNum = cellNum;

    minimalMeasObjectConfUe_type measObjectCandidate;

    if (!VCCB_PrepareMeasObjectEutraUeCandidate(*ptCi, &ptMO->base, &measObjectCandidate))
    {
        return BREAK;
    }

    if (VCCB_FLAG_OFF == rMeasProc.quantityConfigurations.statusEUTRA)
    {
        rMeasProc.quantityConfigurations.newItem.eutra = pDbConf->quantityConfigurationEUTRA;
        rMeasProc.quantityConfigurations.statusEUTRA = VCCB_FLAG_ON;
    }

    if (GOOD != VCCB_AddMeasurementObjectEUTRA(ptCi, cellNum, &measObjectCandidate.rat.eutra, &measObjId))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_AddMeasurementObjectEUTRA failed in VCCB_AddMeasurement\n");
        return ERROR;
    }
    else
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Scheduled measObject EUTRA %hu (frequency: %u/%u) for installation!\n",
            measObjId, measObjectCandidate.rat.eutra.carrierFreq, measObjectCandidate.rat.eutra.overlappedCarrierFreq);
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Execute operations for Periodic A4 measurement upon
                    commitment of the new measurement configuration
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
****************************************************************************/
void VCCB_CommitPa4m(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    measurementsConfigShared_type::s_PeriodicMeasurement_type &pa4m = ptCi->measurementsConfigShared.pa4m;

    if (VCCB_FLAG_OFF == pa4m.needRestartTimerFlag)
    {
        return;
    }
    pa4m.needRestartTimerFlag = VCCB_FLAG_OFF;

    switch (pa4m.state)
    {
        case PeriodicMeasState_Active:
        case PeriodicMeasState_ActiveIdle:
            VLIB_AttachTimer(&pa4m.timer, ptCi, timInternalPeriodicA4Deactivation_id);
            break;

        case PeriodicMeasState_Inactive:
        case PeriodicMeasState_InactiveIdle:
            VLIB_AttachTimer(&pa4m.timer, ptCi, timInternalPeriodicA4Reactivation_id);
            break;

        default:
            break;
    }
}

/****************************************************************************
 * @brief           Execute operations for long periodic measurement upon
                    commitment of the new measurement configuration
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
****************************************************************************/
void VCCB_CommitLpm(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    measurementsConfigShared_type::s_PeriodicMeasurement_type &rLpm = ptCi->measurementsConfigShared.lpm;

    if (VCCB_FLAG_OFF == rLpm.needRestartTimerFlag)
    {
        return;
    }
    rLpm.needRestartTimerFlag = VCCB_FLAG_OFF;

    switch (rLpm.state)
    {
        case PeriodicMeasState_Active:
        case PeriodicMeasState_ActiveIdle:
            VLIB_AttachTimer(&rLpm.timer, ptCi, timInternalLongPeriodicDeactivation_id);
            break;

        case PeriodicMeasState_Inactive:
        case PeriodicMeasState_InactiveIdle:
            VLIB_AttachTimer(&rLpm.timer, ptCi, timInternalLongPeriodicReactivation_id);
            break;

        default:
            break;
    }
}

/****************************************************************************
 * @brief           Execute alternate gap timer trigger
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 ****************************************************************************/
void VCCB_CommitAltGap(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    measurementsConfigShared_type::s_AlternateMeasGap_type &altgap = ptCi->measurementsConfigShared.altgap;

    switch (altgap.stateWithoutPa4m)
    {
        case AltGapStateWithoutPa4m_1:
            switch (altgap.prev_stateWithoutPa4m)
            {
                case AltGapStateWithoutPa4m_2:
                    VLIB_AttachTimer(&altgap.timer, ptCi, timInternalAlternateGap_id);
                    break;
                default:
                    break;
            }
            break;

        case AltGapStateWithoutPa4m_2:
            switch (altgap.prev_stateWithoutPa4m)
            {
                case AltGapStateWithoutPa4m_1:
                case AltGapStateWithoutPa4m_Idle:
                    VLIB_AttachTimer(&altgap.timer, ptCi, timInternalAlternateGap_id);
                    break;
                default:
                    break;
            }
            break;
        default:
            break;
    }
}

void VCCB_CommitPccMeasurements(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (PCC_MeasurementsInstalled == ptCi->pccData.state)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC] activating Gathering Timer in %s\n", __FUNCTION__);
        if (PccMode_Mco == ptCi->pccData.pccMode)
        {
            VLIB_AttachTimer(
                &ptCi->pccData.pccTmr, ptCi, timInternalPeriodicPccChangeMrGatheringTimer_id);
        }
        else
        {
            VLIB_AttachTimer(
                &ptCi->pccData.slbTmr, ptCi, timInternalSlbPccChangeMrGatheringTimer_id);
        }
        SET_PCC_STATE(ptCi, PCC_Gathering);
    }
}

void VCCB_CommitSccMeasurements(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->sccData.state != SCC_NOT_SET && (!FnVCCB_CheckAvailableForSccChange(ptCi))) // Stop SCC
    {
        FnVCCB_InitSccData(ptCi, SCC_ALL_INIT_AND_TIMER_INIT);

        FnVCCB_CalculateTotalMaxBwForCa(ptCi);

        if (VCCM_EnqueueActionMeasReconfig(ptCi, MeasReconfigPriorAction_Full) != GOOD) // For during ReActivationTimer
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_EnqueueActionMeasReconfigis ERROR [ %s ]\n", __FUNCTION__);
        }

        VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] Stop SCC %s!! \n", __FUNCTION__);
    }
    else // original code
    {
        if (ptCi->sccData.state == SCC_MeasConf)
        {
            VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] activating React Timer in %s\n", __FUNCTION__);
            VLIB_AttachTimer(&ptCi->sccData.sccMeasReactTimer, ptCi, timSccMeasReact_id);
            if (ptCi->sccData.sccMeasReactTimer.id <= 0)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "sccMeasReactTimer allocation fail \n");
            }

            if (ptCi->sccData.a4MrSetAndReceived == 0)
            {
                VCCB_PRINT_LOG_MCO_SCC(
                        ptCi, "[SCC] activating Gathering Timer Not Set because a4MrSetAndReceived = 0 %s\n", __FUNCTION__);
                SET_SCC_STATE(ptCi, SCC_Triggered);
            }
            else
            {
                VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] activating Gathering Timer in %s\n", __FUNCTION__);
                VLIB_AttachTimer(&ptCi->sccData.sccGatheringTimer, ptCi, timSccGatheringWaiting_id);
                if (ptCi->sccData.sccGatheringTimer.id <= 0)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "sccGatheringTimer allocation fail \n");
                }
                SET_SCC_STATE(ptCi, SCC_Gathering);
            }
        }
        else
        {
            VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] state(%d) / a4MrSetAndReceived(0x%X) Timer not change !! \n",
                    ptCi->sccData.state, ptCi->sccData.a4MrSetAndReceived);
        }

        VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] sccGatheringTimer(id:%d/val:%dms)/sccMeasReactTimer(id:%d/val:%dms)\n",
            ptCi->sccData.sccGatheringTimer.id, ptCi->sccData.sccGatheringTimer.val, ptCi->sccData.sccMeasReactTimer.id,
            ptCi->sccData.sccMeasReactTimer.val);
    }
}

void VCCB_CommitMrsMeasurements(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->mrsInfo.mrsState != MRS_IDLE && (!FnVCCB_CheckMultiRatSelection(ptCi, false))) // Stop MRS
    {
        FnVCCB_InitMrsInfo(ptCi, MRS_ALL_INIT_AND_TIMER_INIT);

        if (VCCM_EnqueueActionMeasReconfig(ptCi, MeasReconfigPriorAction_Full) != GOOD) // For Eutra Gathering MR or inter Rat HO MR
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_EnqueueActionMeasReconfigis ERROR [ %s ]\n", __FUNCTION__);
        }

        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] Stop MRS %s!! \n", __FUNCTION__);
    }
    else // original code
    {
        if (ptCi->mrsInfo.mrsState == MRS_GATHERING_MEAS && ptCi->mrsInfo.mrsCheckFlag != 0)
        {
            VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] activating Gathering Timer in %s\n", __FUNCTION__);
            VLIB_AttachTimer(&ptCi->mrsInfo.mrsMrGatheringTimer, ptCi, timMrsMrGatheringWaiting_id);

            SET_MRS_STATE(ptCi, MRS_GATHERING_WAIT);
        }
    }

    return;
}

/****************************************************************************
 * @brief           Execute UE Meas for SON timer trigger
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 ****************************************************************************/
void VCCB_CommitUeMeasForSon(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (UeMeasForSonState_timerToBeStarted != ptCi->ueMeasForSon.ueMeasForSonState)
    {
        return;
    }
    ptCi->ueMeasForSon.ueMeasForSonState = UeMeasForSonState_timerRunning;
    VLIB_AttachTimer(&ptCi->ueMeasForSon.measTimer, ptCi, timInternalUeMeasForSon_id);
}

/**
 * @brief Action on RRC Reconfiguration Complete caused by DTM.
 *        Timer timInternalForcedHoMobility_id is started if needed.
 *
 * @param rCall info
 */
void VCCB_CommitDtmMeas(callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;

    // FGR-CC5001 FR152 - Start the timer defined by FR210 of FGR-MC1029.
    if ((E_CALLTYPE_NSA == rCall.callType) && (TRUE == rCall.ustmInfo.measConfFilteringActive) &&
        (rCall.ustmInfo.startTimer == TRUE))
    {
        rCall.ustmInfo.startTimer = FALSE;
        VCCB_USTM_StartTimerIfPossible(rCall);
    }
}

/****************************************************************************
 * @brief           Execute Ca periodical measurements timer start
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 ****************************************************************************/
void VCCB_CommitCaPeriodicMeas(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if ((TRUE == ptCi->caInfo.isPeriodicalOngoing) && (0 >= ptCi->caInfo.caPeriodicMeasTimer.id))  // timer not started
    {
        VLIB_AttachTimer(&ptCi->caInfo.caPeriodicMeasTimer, ptCi, timInternalCaPeriodicMeas_id);
    }
}

/****************************************************************************
 * @brief           Commit measurementsProcedure data to measurementsConfiguration
                    for long periodic measurement.
 * @param[in/out]   rCi : reference to call configuration. / callInfo_type
****************************************************************************/
void VCCB_CommitLpmProc(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    measurementsConfiguration_type &rMeasConf = rCi.measurementsConfiguration;
    const measurementsProcedure_type &rMeasProc = rCi.measurementsProcedure;
    measurementsConfigShared_type &rMeasConfShared = rCi.measurementsConfigShared;
    measurementsConfigShared_type::s_PeriodicMeasurement_type &rLpm = rMeasConfShared.lpm;

    if ((PeriodicMeasState_Stopped == rLpm.state) && (0 == rMeasProc.lpmPurposeMask))
    {
        SET_LPM_STATE(&rCi, PeriodicMeasState_Idle);
    }

    if ((~rMeasConf.lpmPurposeMask) & rMeasProc.lpmPurposeMask) // if ((~oldMask) & newMask)
    {
        // FGR-MC1014 FR831: When another longer periodic A4/A5 measurement is configured,
        // the repetition number of deactivation timer shall be reset and start to increase again.
        VCCB_PRINT_CALL_COMMENT(&rCi, "[LPM] Another measurement purpose is configured: old(0x%x)->new(0x%x), state(%u)\n",
            rMeasConf.lpmPurposeMask, rMeasProc.lpmPurposeMask, rLpm.state);

        rMeasConfShared.lpmRepetitionCount = 0;

        if (PeriodicMeasState_Stopped == rLpm.state)
        {
            SET_LPM_STATE(&rCi, PeriodicMeasState_Active);
            rLpm.needRestartTimerFlag = VCCB_FLAG_ON;
        }
    }

    rMeasConf.lpmPurposeMask = rMeasProc.lpmPurposeMask;
}

void VCCB_CopyReportConfigNewItemIntoInstalledItem(
    reportConfigurationInstalledUe_type &installedItem, const reportConfigurationNewUe_type &newItem)
{
    AUTO_TRACE_FUNC;
    installedItem.usage = newItem.usage;
    installedItem.internalIdx = newItem.internalIdx;
    installedItem.objectId = newItem.objectId;
    installedItem.isTainted = newItem.isTainted;
    installedItem.pending = newItem.pending;
    installedItem.conf = newItem.conf;
}

bool VCCB_CommitNrRrcMeasConfig(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    uint16_t idx = 0;
    measurementsConfiguration_type &rMeasConf = rCi.measurementsConfiguration;
    const measurementsProcedure_type &rMeasProc = rCi.measurementsProcedure;

    if (rMeasProc.measurementIdentities.numNewItems > MAX_NR_OF_MEAS_ID)
    {
        VCCB_PRINT_CALL_ERROR(&rCi,
            "ERROR: Invalid number of measurement identities to add (%hu) in "
            "VCCB_CommitMeasurementReconfiguration, maximum allowed number is %d!\n",
            rMeasProc.measurementIdentities.numNewItems, MAX_NR_OF_MEAS_ID);

        return false;
    }

    // Measurement objects
    for (idx = 0; idx < VCCB_ARRAY_COUNT(rMeasConf.measurementObjects.installedItems); idx++)
    {
        if (GETBIT(rMeasProc.measurementObjects.itemsToRemove, idx))
        {
            rMeasConf.measurementObjects.installedItems[idx].usage = CI_no_use;
        }
    }

    for (idx = 0; idx < VCCB_ARRAY_COUNT(rMeasProc.measurementObjects.newItems); idx++)
    {
        if (GETBIT(rMeasProc.measurementObjects.itemsToModify, idx))
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(rMeasProc.measurementObjects.newItems[idx].internalIdx,
                VCCB_ARRAY_COUNT(rMeasConf.measurementObjects.installedItems));
            rMeasConf.measurementObjects.installedItems[rMeasProc.measurementObjects.newItems[idx].internalIdx] =
                rMeasProc.measurementObjects.newItems[idx];
        }
    }

    // Report configurations
    for (idx = 0; idx < VCCB_ARRAY_COUNT(rMeasConf.reportConfigurations.installedItems); idx++)
    {
        if (GETBIT(rMeasProc.reportConfigurations.itemsToRemove, idx))
        {
            rMeasConf.reportConfigurations.installedItems[idx].usage = CI_no_use;
        }
    }
    for (idx = 0; idx < MAX_NR_OF_REPORT_CONFIG_ID; idx++)
    {
        if (GETBIT(rMeasProc.reportConfigurations.itemsToModify, idx))
        {
            const uint8_t internalIdx = rMeasProc.reportConfigurations.newItems[idx].internalIdx;
            VCCB_CHECK_E_RANGE_AND_VAL(internalIdx, MAX_NR_OF_REPORT_CONFIG_ID, false);
            VCCB_CopyReportConfigNewItemIntoInstalledItem(
                rMeasConf.reportConfigurations.installedItems[internalIdx], rMeasProc.reportConfigurations.newItems[idx]);
        }
    }

    // Measurement identities
    for (idx = 0; idx < MAX_NR_OF_MEAS_ID; idx++)
    {
        if (GETBIT(rMeasProc.measurementIdentities.itemsToRemove, idx))
        {
            rMeasConf.measurementIdentities.installedItems[idx].usage = CI_no_use;
        }
    }

    for (uint8_t i = 0; i < util::minOfArraySizeAndNumOfElems(
                                rMeasProc.measurementIdentities.newItems, rMeasProc.measurementIdentities.numNewItems);
         ++i)
    {
        idx = rMeasProc.measurementIdentities.newItems[i].internalIdx;
        if (MAX_NR_OF_MEAS_ID <= idx)
        {
            // skip elements that not need to be copied.
            continue;
        }
        rMeasConf.measurementIdentities.installedItems[idx] = rMeasProc.measurementIdentities.newItems[i];
    }

    clearTaintAllInstalledMeasConfig(rCi);

    // S-Measure config
    if (rMeasProc.sMeasureConfig.status == VCCB_FLAG_ON)
    {
        rMeasConf.sMeasureConfig.installedItem = rMeasProc.sMeasureConfig.newItem;
        rMeasConf.sMeasureConfig.installedItem.usage = CI_use;
    }

    // Quantity config
    if (rMeasProc.quantityConfigurations.statusNR == VCCB_FLAG_ON)
    {
        const auto& src = rMeasProc.quantityConfigurations.newItem.nr;
        std::copy(begin(src), end(src), rMeasConf.quantityConfigurations.installedItem.nr);
    }
    if (rMeasProc.quantityConfigurations.statusEUTRA == VCCB_FLAG_ON)
    {
        rMeasConf.quantityConfigurations.installedItem.eutra = rMeasProc.quantityConfigurations.newItem.eutra;
    }

    // MeasGapConfig
    rMeasConf.mGapCfgInstalled = FnVCCB_GetMGapDuData(rCi).mGapCfgNew;

    // LPM
    VCCB_CommitLpmProc(rCi);

    VCCB_ClearNewMeasConfig(rCi, VCCB_FLAG_ON);

    return true;
}

bool VCCB_CommitNrRrcMeasConfigUsingAltStructures(callInfo_type &rCi, const measurementsConfiguration_type &measConf,
    const measurementsProcedure_type &measProc, const mGapDuData_type &mgapDuData, const saMeasStateInfo_type &saMeas)
{
    VCCB_PRINT_CALL_MEASUREMENTS(
        &rCi, "Overwrite measurements configuration, procedure and mgap with alternate structures\n");

    rCi.measurementsConfiguration = measConf;
    rCi.measurementsProcedure = measProc;
    rCi.measurementsConfigShared.mGapDu = mgapDuData;
    rCi.saMeas = saMeas;
    return VCCB_CommitNrRrcMeasConfig(rCi);
}

/****************************************************************************
 * @brief           Commits the new measurement configuration. Call this
 *                  function after receiving RRCReconfigurationComplete.
 *
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_CommitMeasurementReconfiguration(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (!VCCB_CommitNrRrcMeasConfig(*ptCi))
    {
        return ERROR;
    }

    FnVCCB_CommitSvcGrpId(*ptCi);

    // Update nsaPrevInfo
    VCCM_SetPrevNsaCallDb(ptCi, NSA_PREV_CALL_DB_TYPE_ALL);

    if (FnVCCB_GetSaMeas(*ptCi).saIfMeasState == SA_IFMEASSTATE_ACTIVE)
    {
        ptCi->mroInfo.ue.isA2Installed = TRUE;
    }
    else
    {
        ptCi->mroInfo.ue.isA2Installed = FALSE;
    }

    // Periodic A4 measurement
    VCCB_CommitPa4m(ptCi);

    // Long periodic measurement
    VCCB_CommitLpm(ptCi);

    // Alternate Gap Timer
    VCCB_CommitAltGap(ptCi);

    // Multi Carrier Operation
    VCCB_CommitPccMeasurements(ptCi);
    VCCB_CommitSccMeasurements(ptCi);
    VCCB_CommitMrsMeasurements(ptCi);

    // UE Meas for SON
    VCCB_CommitUeMeasForSon(ptCi);

    // Conditional Handover
    FnVCCB_CommitUeMeasForCho(ptCi);

    VCCB_CommitDtmMeas(*ptCi);

    // FGR-LC0712
    FnVCCB_CommitVoNrLB(ptCi);

    // FGR-RC0100
    VCCB_CommitCaPeriodicMeas(ptCi);

    // SVR24B FGR-MC1007 FR391
    FnVCCB_MeasConfigCheckAndSetTimerBasedMrBasedRedirection(*ptCi);

    // SVR26A:FGR-LC0705:FR12
    FnVCCB_CommitFastAccTimerCtrlForScgBandSel(*ptCi);

    return GOOD;
}

/****************************************************************************
 * @brief           Triggers MeasReconfig for measId removal
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       measId : id of measurement identity on UE. / NRRRC_MeasConfig*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_RemoveMeasurementIdentity(callInfo_type *ptCi, NRRRC_MeasId measId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    if (ptCi->myThreadId >= MAX_CALL_THREAD_NUM_VCCB)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: Invalid thread id (%u) in VCCB_RemoveMeasurementIdentity! "
            "MAX_CALL_THREAD_NUM_VCCB: %u\n", ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

        return ERROR;
    }

    // Check if not yet committed meas reconfiguration is pending
    if (MAX_CELL_NUM_VCCB != FnVCCB_GetMeasurementsProcedure(*ptCi).tgtCellNum)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: Not committed measConfig pending - cannot trigger measId(%hu) remove\n", measId);

        return BREAK;
    }

    // SVR22B FGR-CC5203: Deconfigure A4 for SCG resume and Update MeasConfig
    ptCi->nrdcScgFailureInfo.A4Configured = VCCB_FLAG_OFF;

    status = VCCM_TriggerMeasReconfigRemoveMeasId(*ptCi, static_cast<uint8_t>(measId));
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_TriggerMeasReconfigRemoveMeasId ERROR!\n");

        return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Check if measReport and measObject are configured in DB.
 *
 * @param[in]       cellNum : Cell number. / uint16_t
 * @param[in]       reportType : Type of the target report configuration. / enumMeasurementReportType
 * @param[in]       reportPurpose : Purpose of the target report configuration. / uint8_t
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_IsMeasRptObjInDb(
    CellNum_type cellNum, enumMeasurementReportType reportType, uint8_t reportPurpose, Arfcn_type frequency)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    // Find MeasObject and related ReportConfiguration in DB
    VCCB_RptCfgAndMeasObjDbFinder finder(CELLINFO[cellNum].measurementsData, reportType, reportPurpose, frequency);
    if (false == finder.isValid())
    {
        VCCB_PRINT_COMMENT("Couldn't find rptCfg(type(%d) purpose(%hu)) measObj(freq(%u)) cellNum(%u)\n", reportType,
            reportPurpose, frequency, cellNum);

        return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Check if measurement object plmn based control can be used on UE
 *                  If provided arguments are invalid returns ERROR.
 *                  If the condition is not met returns BREAK.
 *                  If the condition is met returns GOOD.
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       finder : initialized finder object for matching report config and measurement object  /
 **VCCB_MeasObjDbFinder&
 * @return          status : GOOD, BREAK, ERROR / int16_t
 ****************************************************************************/
int16_t VLIB_CanMeasObjectPlmnBasedControlBeUsed(callInfo_type *ptCi, VCCB_MeasObjDbFinder &finder)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (!finder.isValid())
    {
        return BREAK;
    }

    if (measRatNr == finder._ratType)
    {
        // assume no restrictions on primary serving cell
        if (INTRAFREQ_OBJECT_IDX == finder._pMeasObjDbIdx)
        {
            return GOOD;
        }

        return VLIB_CanPlmnBasedControlBeUsed(ptCi, finder._pDbObjNr->extension.plmnBasedControl);
    }
    if (measRatEutra == finder._ratType)
    {
        return VLIB_CanPlmnBasedControlBeUsed(ptCi, finder._pDbObjEutra->extension.plmnBasedControl);
    }

    // wrong ratType
    return BREAK;
}

/****************************************************************************
 * @brief           Check if selected meas object is CBRS specific
 *                  If provided arguments are invalid returns ERROR.
 *                  If it is CBRS meas object returns GOOD.
 *                  If it is not CBRS meas object returns BREAK.
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       finder : initialized finder object for matching report config and measurement object  /
 *const VCCB_MeasObjDbFinder&
 * @return          status : GOOD, BREAK, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfCbrsMO(callInfo_type *ptCi, const VCCB_MeasObjDbFinder &finder)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (!finder.isValid())
    {
        return ERROR;
    }

    if (measRatNr != finder._ratType)
    {
        return BREAK;
    }

    // meas object for SpCell cannot be treated as CBRS meas object
    if (INTRAFREQ_OBJECT_IDX == finder._pMeasObjDbIdx)
    {
        return BREAK;
    }

    const measurementObjectNRBaseDb_type &rMoDb = finder._pDbObjNr->base;

    if ((CI_use != rMoDb.freqBandIndicatorDbList.freqBand[0].usage) ||
        (CBRS_BAND != rMoDb.freqBandIndicatorDbList.freqBand[0].band))
    {
        return BREAK;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Check if measurement object is CBRS frquency
 ****************************************************************************/
bool VCCB_IsCbrsMo(measurementObjectNRBaseDb_type *ptMoDb)
{
    AUTO_TRACE_FUNC;
    return ((NULL != ptMoDb) && (CI_use == ptMoDb->freqBandIndicatorDbList.freqBand[0].usage) &&
            (CBRS_BAND == ptMoDb->freqBandIndicatorDbList.freqBand[0].band) && ptMoDb->cbrsEnabled);
}

bool VCCB_IsCbrsValidatedMo(measurementObjectNRBaseDb_type *ptMoDb, const uint8_t measObjIndex)
{
    AUTO_TRACE_FUNC;

    if (INTRAFREQ_OBJECT_IDX == measObjIndex)
    {
        return true;
    }

    if (NULL != ptMoDb)
    {
        if ((CI_use == ptMoDb->freqBandIndicatorDbList.freqBand[0].usage) &&
            (CBRS_BAND == ptMoDb->freqBandIndicatorDbList.freqBand[0].band))
        {
            if (FLAG_OFF == ptMoDb->cbrsEnabled)
            {
                return false;
            }
        }
    }
    return true;
}

/****************************************************************************
 * @brief           Get measurement object DB for CBRS carrier
 ****************************************************************************/
measurementObjectNRBaseDb_type *VCCB_GetMatchingCbrsMo(Arfcn_type ssbArfcn, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_NULL(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    for (uint16_t objIdx = START_CBRS_OBJECT_IDX; END_CBRS_OBJECT_IDX > objIdx; ++objIdx)
    {
        measurementObjectNRBaseDb_type *ptMO = &pCell->measurementsData.measurementObjectsNRDb[objIdx].base;
        if ((CI_use == ptMO->usage) && (ssbArfcn == ptMO->ssbFrequency) && (true == VCCB_IsCbrsMo(ptMO)))
        {
            return ptMO;
        }
    }

    return NULL;
}

// SVR24A FGR-MC1023 FR30
/****************************************************************************
 * @brief           Check if measurement object plmn based control can be used on UE
 *                  If provided arguments are invalid returns ERROR.
 *                  If the condition is not met returns BREAK.
 *                  If the condition is met returns GOOD.
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       cellNum : Cell number. / uint16_t
 * @param[in]       finder : initialized finder object for matching report config and measurement object  /
 *VCCB_MeasObjDbFinder&
 * @return          status : GOOD, BREAK, ERROR / int16_t
 ****************************************************************************/
int16_t FnVCCB_CanMeasObjectRfspSpecificMeasConf(callInfo_type *ptCi, CellNum_type cellNum,
    VCCB_MeasObjDbFinder &finder, enumMeasurementReportType reportType, uint8_t reportPurpose)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    if (!finder.isValid())
    {
        return BREAK;
    }

    if (measRatNr == finder._ratType && INTRAFREQ_OBJECT_IDX == finder._pMeasObjDbIdx)
    {
        return GOOD;
    }

    auto isPreventingApplyRfspSpecificDelta = [ptCi]() -> bool
    {
        const uint8_t svcGrpIdx = FnVCCB_GetSvcGrpId(*ptCi, FALSE);
        if (svcGrpIdx >= MAX_SVC_GRP_DB_NUM || ptCi->gnbNum >= MAX_GNB_PER_SYS) return FALSE;
        gnbConfig_type *const pGnbCfg = &GNBINFO[ptCi->gnbNum].cfg;
        return (pGnbCfg->svcGrpBasedCfg[svcGrpIdx].usage == CI_use &&
                pGnbCfg->svcGrpBasedCfg[svcGrpIdx].preventingRfspSpecificDeltaCfg == TRUE);
    };

    if (isPreventingApplyRfspSpecificDelta()) return GOOD;

    /* supported purpose check */
    if (GOOD != VCCB_CheckRfspSpecificSupportPurposeCheck(ptCi, reportType, reportPurpose))
    {
        return GOOD;
    }

    rfspBasedCtrlSpecific_type *pRfsp = nullptr;

    pRfsp = FnVCCB_isRfspSpecificUE(ptCi, cellNum);
    if (pRfsp != nullptr)
    {
        uint8_t rfsp_faIdx = MAX_NUM_RFSP_FREQS;
        if (measRatNr == finder._ratType)
        {
            for (rfsp_faIdx = 0; rfsp_faIdx < MAX_NUM_RFSP_FREQS; rfsp_faIdx++)
            {
                if (CI_use != pRfsp->nrFreqItems[rfsp_faIdx].usage) continue;
                if (pRfsp->nrFreqItems[rfsp_faIdx].targetMeasObjectEntriesindex == INTRAFREQ_OBJECT_IDX) continue;
                if (pRfsp->nrFreqItems[rfsp_faIdx].targetMeasObjectEntriesindex >= MAX_NR_OF_OBJECT_ID_DB) continue;

                uint8_t moIdx = pRfsp->nrFreqItems[rfsp_faIdx].targetMeasObjectEntriesindex;
                measurementObjectNRBaseDb_type *ptMO = &(pCell->measurementsData.measurementObjectsNRDb[moIdx].base);
                if (ptMO->usage != CI_use) continue;

                if (finder._pDbObjNr->base.ssbFrequency == ptMO->ssbFrequency)
                {
                    return GOOD;
                }
            }

            VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                "[isRestrictMeasObj] measObjIdx(%d), ssbFreq(%u) // pDbRpt(Pur:%d, Type:%d) \n", finder._pMeasObjDbIdx,
                finder._pDbObjNr->base.ssbFrequency, reportPurpose, reportType);
        }
        else  // EUTRA
        {
            for (rfsp_faIdx = 0; rfsp_faIdx < MAX_NUM_RFSP_FREQS; rfsp_faIdx++)
            {
                if (CI_use != pRfsp->eutraFreqItems[rfsp_faIdx].usage) continue;
                if (pRfsp->eutraFreqItems[rfsp_faIdx].targetMeasObjectEntriesindex >= MAX_NR_OF_OBJECTEUTRA_ID_DB)
                    continue;

                uint8_t moIdx = pRfsp->eutraFreqItems[rfsp_faIdx].targetMeasObjectEntriesindex;
                measurementObjectEUTRABaseDb_type *ptMO =
                    &(pCell->measurementsData.measurementObjectsEUTRADb[moIdx].base);
                if (ptMO->usage != CI_use) continue;

                if (finder._pDbObjEutra->base.carrierFreq == ptMO->carrierFreq)
                {
                    return GOOD;
                }
            }

            VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                "[isRestrictMeasObj/measRatEutra] measObjIdx(%d), carrFreq(%u) // pDbRpt(Pur:%d, Type:%d). \n",
                finder._pMeasObjDbIdx, finder._pDbObjEutra->base.carrierFreq, reportPurpose, reportType);
        }

        return BREAK;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Check if measurement object are configured in DB
 *                  If provided arguments are invalid returns false
 *                  If the condition is not met returns false
 *                  If the condition is met returns true
 * @param[in]       rCi : Reference to call configuration. / callInfo_type&
 * @param[in]       finder : initialized finder object for matching measurement object  /
 *VCCB_MeasObjDbFinder&
 * @return          status : true, false / bool
 ****************************************************************************/
bool VCCB_CanMeasObjBeAdded(callInfo_type &rCi, CellNum_type cellNum, VCCB_MeasObjDbFinder &finder,
    enumMeasurementReportType reportType, uint8_t reportPurpose)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);

    if (!finder.isValid())
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "DbFinder didn't find matching report config and measurement object!\n");

        return false;
    }

    if (GOOD != VLIB_CanMeasObjectPlmnBasedControlBeUsed(&rCi, finder))
    {
        return false;
    }

    if (GOOD == VCCB_CheckIfCbrsMO(&rCi, finder))
    {
        const auto &moDb = finder._pDbObjNr->base;
        if (!moDb.cbrsEnabled)
        {
            VCCB_PRINT_CALL_COMMENT(&rCi,
                "meas object{f=%d} won't be installed on UE as it is CBRS and it is disabled.\n", moDb.ssbFrequency);

            return false;
        }
    }

    // SVR24A FGR-MC1023 FR30
    if (GOOD != FnVCCB_CanMeasObjectRfspSpecificMeasConf(&rCi, cellNum, finder, reportType, reportPurpose))
    {
        if (measRatNr == finder._ratType)
        {
            const auto &moDb = finder._pDbObjNr->base;
            VCCB_PRINT_CALL_COMMENT(&rCi,
                "meas object{f=%u} won't be installed on UE as it is RfspSpecific and it is disabled.\n",
                moDb.ssbFrequency);
        }
        else
        {
            const auto &moDb = finder._pDbObjEutra->base;
            VCCB_PRINT_CALL_COMMENT(&rCi,
                "meas object{f=%u} won't be installed on UE as it is RfspSpecific and it is disabled.\n",
                moDb.carrierFreq);
        }

        return false;
    }

    switch (finder._ratType)
    {
        case measRatNr:
        {
            measurementObjectNRBaseDb_type *pBaseObj = &finder._pDbObjNr->base;

            if (rCi.onDemandInfo.targetUe == TRUE)  // ODF_HO_21B
            {
                if (pBaseObj && (pBaseObj->supportOnDemandMobility != TRUE))
                {
                    VCCB_PRINT_CALL_SA_ON_DEMAND_HO(&rCi, "[ODF_HO] %s pMeasObjNr->ssbFrequency(%u) Not support \n",
                        __func__, pBaseObj->ssbFrequency);
                    return false;
                }
            }
            else if (FnVCCB_USTM_IsMeasConfFilteringActive(rCi, cellNum))
            {
                if (pBaseObj && (FALSE == pBaseObj->supportForcedMobilityByUplinkStatusIndication))
                {
                    VCCB_PRINT_CALL_COMMENT(&rCi, "NR MO is not supported by DU Forced Mobility!\n");
                    return false;
                }
            }

            const uint16_t band = VCCB_GetMoNrBandForUe(&rCi, pBaseObj);
            if (0 == band)
            {
                VCCB_PRINT_CALL_ERROR(&rCi, "MO ssbArfcn(%u) not supported by UE!\n", pBaseObj->ssbFrequency);
                return false;
            }

            if (FnVCCB_IsPingPongAvoidanceRestriction(rCi, cellNum, *pBaseObj, reportType, reportPurpose) == true)
            {
                VCCB_PRINT_LOG_NC_MC(
                    &rCi, "(PPA) Can't configure measObj for the freq(%u) restricted Nr\n", pBaseObj->ssbFrequency);
                return false;
            }
            break;
        }
        case measRatEutra:
        {
            measurementObjectEUTRABaseDb_type *pBaseObj = &finder._pDbObjEutra->base;

            if (rCi.onDemandInfo.targetUe == TRUE)  // ODF_HO_21B
            {
                if (pBaseObj && (pBaseObj->supportOnDemandMobility != TRUE))
                {
                    VCCB_PRINT_CALL_SA_ON_DEMAND_HO(&rCi, "[ODF_HO] %s pMeasObjEutra->carrierFreq(%u) Not support \n",
                        __func__, pBaseObj->carrierFreq);
                    return false;
                }
            }
            else if (FnVCCB_USTM_IsMeasConfFilteringActive(rCi, cellNum))
            {
                if (pBaseObj && (FALSE == pBaseObj->supportForcedMobilityByUplinkStatusIndication))
                {
                    VCCB_PRINT_CALL_COMMENT(&rCi, "EUTRA MO is not supported by DU Forced Mobility!\n");
                    return false;
                }
            }

            Arfcn_type earfcn = 0;
            const uint16_t band = VCCB_GetMoEutraBandForUe(&rCi, pBaseObj, &earfcn);
            if (0 == band)
            {
                VCCB_PRINT_CALL_ERROR(&rCi, "MO earfcn(%u) not supported by UE!\n", pBaseObj->carrierFreq);
                return false;
            }
            break;
        }
        default:
            return false;
    }

    return true;
}

bool FnVCCB_CanMesObjBandsSupportAllowedBCList(callInfo_type &rCi, VCCB_RptCfgAndMeasObjDbFinder &finder)
{
    AUTO_TRACE_FUNC;

    if (!finder.isValid())
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "DbFinder didn't find matching report config and measurement object!\n");
        return false;
    }

    for (const freqBand_type &rFreqBand : finder._measObjectDbFinder._pDbObjNr->base.freqBandIndicatorDbList.freqBand)
    {
        if (CI_use != rFreqBand.usage)
        {
            continue;
        }
        if (FnVCCB_IsAllowedNrBandforAllowedBCList(&rCi, rFreqBand.band))
        {
            return true;
        }
    }

    return false;
}

/****************************************************************************
 * @brief           Check if report config is configured in DB
 *                  If provided arguments are invalid returns false.
 *                  If the condition is not met returns false.
 *                  If the condition is met returns true.
 *
 * @param[in]       rCi : Reference to call configuration. / callInfo_type&
 * @param[in]       reportType : Type of the target report configuration. / enumMeasurementReportType
 * @param[in]       reportPurpose : Purpose of the target report configuration. / uint8_t
 * @param[in]       finder : initialized finder object for matching report config and measurement object  / const
 *VCCB_RptCfgAndMeasObjDbFinder&
 *
 * @return          status : true, false / bool
 ****************************************************************************/
bool VCCB_CanReportConfigBeAdded(callInfo_type &rCi, enumMeasurementReportType reportType, uint8_t reportPurpose,
    VCCB_RptCfgAndMeasObjDbFinder &finder)
{
    AUTO_TRACE_FUNC;

    if (!VCCB_IsReportSupportedByUe(rCi, reportType))
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "UE does not support %d measurement report.\n", reportType);
        return false;
    }

    if (!finder.isValid())
    {
        return false;
    }

    if (GOOD != VLIB_CanPlmnBasedControlBeUsed(&rCi, finder._pDbRpt->extension.plmnBasedControl))
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "rptCfg(type(%d) purpose(%hu)) plmnBasedControl is not supported for UE\n",
            reportType, reportPurpose);
        return false;
    }

    return true;
}

/****************************************************************************
 * @brief       Get Report Configuration from DB for rCandidate
 *                  Check if ue specific report config can be applied
 *                      - If yes, apply ue specific configuration to rCandidate
 *                      - If no, return with base report config
 * @return      status : int8_t
 *                  GOOD  - if ue specific report config is applied
 *                  BREAK - if base report config is not replaced
 *                  ERROR - if provided arguments are invalid
 ****************************************************************************/
int8_t VCCB_GetReportConfigDb(callInfo_type &rCi, CellNum_type cellNum, enumMeasurementReportType reportType,
    uint8_t reportPurpose, VCCB_RptCfgAndMeasObjDbFinder &finder, reportConfigurationBaseDb_type &rCandidate)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    if (!finder.isValid())
    {
        return ERROR;
    }

    rCandidate = finder._pDbRpt->base;

    uint8_t ueSpecificIdx = MAX_NR_UE_SPECIFIC_REPORT_CONFIG_DB;
    const uint8_t svcGrpIdx = FnVCCB_GetSvcGrpId(rCi, FALSE);
    const uint8_t plmnIndex = VLIB_FindGnbPlmnIndexOfCall(&rCi);
    VCCB_FindUeSpecificIdx(&rCi, finder, plmnIndex, svcGrpIdx, &ueSpecificIdx, cellNum);
    if (ueSpecificIdx < MAX_NR_UE_SPECIFIC_REPORT_CONFIG_DB)
    {
        const auto rptCfgId = finder._pRptCfgIdx;
        measurementsData_type *pDbConf = &(CELLINFO[cellNum].measurementsData);
        switch (finder._ratType)
        {
            case measRatNr:
            {
                rCandidate.reportConfiguration =
                    pDbConf->ueSpecificReportConfigurations[rptCfgId][ueSpecificIdx].base.reportConfiguration;
                break;
            }
            case measRatEutra:
            {
                rCandidate.reportConfiguration =
                    pDbConf->ueSpecificReportConfigInterRat[rptCfgId][ueSpecificIdx].base.reportConfiguration;
                break;
            }
            default:
                return ERROR;
        }

        VCCB_PRINT_CALL_COMMENT(&rCi,
            "Configuration of rptCfg(type(%d) purpose(%hu)) is taken from ueSpecificIdx:%hu\n", reportType,
            reportPurpose, ueSpecificIdx);
        return GOOD;
    }
    // Use base RC.
    return BREAK;
}

bool VCCB_ValidateMeasObjectAndReportConfigCandidates(callInfo_type &rCi, VCCB_RptCfgAndMeasObjDbFinder &finder,
    const CellNum_type cellNum, const enumMeasurementReportType reportType, const uint8_t reportPurpose,
    const Arfcn_type frequency)
{
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);

    if ((CELLINFO[cellNum].ssbArfcn != frequency) && (measRatNr == VCCB_GetRatType(reportType)) &&
        !FnVCCB_IsSsbAllowed(rCi, frequency))
    {
        VCCB_PRINT_CALL_COMMENT(
            &rCi, "Can't configure measObj for the freq(%u) in the not allowed ssb frequency list!\n", frequency);
        return false;
    }

    if (false == finder.isValid())
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "Couldn't find rptCfg(type(%d) purpose(%hu)) measObj(freq(%u)) cellNum(%u)\n",
            reportType, reportPurpose, frequency, cellNum);

        return false;
    }

    if (!VCCB_CanMeasObjBeAdded(rCi, cellNum, finder._measObjectDbFinder, reportType, reportPurpose))
    {
        return false;
    }

    if (reportType == measReport_A4 && reportPurpose == a4Purpose_NrdcAddition &&
        !FnVCCB_CanMesObjBandsSupportAllowedBCList(rCi, finder))
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "No NrBand for freq(%u) to support AllowedBCList!\n", frequency);
        return false;
    }

    // SVR22B FGR-CC5203: CHECK!!!!! (SG) --> TBD
    if (reportType == measReport_A4 && reportPurpose == a4Purpose_NrDcResume &&
        !FnVCCB_CanMesObjBandsSupportAllowedBCList(rCi, finder))
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "No NrBand for freq(%u) to support AllowedBCList!\n", frequency);
        return false;
    }

    if (!VCCB_CanReportConfigBeAdded(rCi, reportType, reportPurpose, finder))
    {
        VCCB_PRINT_CALL_COMMENT(
            &rCi, "Requested ReportConfig reportType=%d purpose=%d cannot be installed.\n", reportType, reportPurpose);
        return false;
    }

    return true;
}

/****************************************************************************
 * @brief           Check if measurement object (MO) and report config (RC) are in the database
 *                  and if they can be installed on UE.
 *                  If provided arguments are invalid returns ERROR.
 *                  If the conditions are not met returns BREAK.
 *                  If the conditions are met returns GOOD.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       cellNum : Cell number. / uint16_t
 * @param[in]       reportType : Type of the target report configuration. / enumMeasurementReportType
 * @param[in]       reportPurpose : Purpose of the target report configuration. / uint8_t
 * @param[in]       frequency : Frequency to measure (SSB or CSI-RS). / Arfcn_type/uint32_t
 * @return          status : GOOD, BREAK, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_CanMOAndRCBeAdded(callInfo_type *ptCi, CellNum_type cellNum, enumMeasurementReportType reportType,
    uint8_t reportPurpose, Arfcn_type frequency)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    reportConfigurationConfUe_type *notUsedRC = nullptr;
    minimalMeasObjectConfUe_type *notUsedMO = nullptr;
    return VCCB_CanMOAndRCBeAddedWithCandidates(
               *ptCi, cellNum, reportType, reportPurpose, frequency, notUsedRC, notUsedMO)
               ? GOOD
               : BREAK;
}

/****************************************************************************
 * @brief           Check if measurement object (MO) and report config (RC) are in the database
 *                  and if they can be installed on UE.
 *                  Additionally, fill MO and RC candidates based on db values if their pointers are not null.
 *
 *                  If provided arguments are invalid returns ERROR.
 *                  If the conditions are not met returns BREAK.
 *                  If the conditions are met returns GOOD and fill the RC candidate.
 *
 * @param[in]       rCi : Reference to call configuration. / callInfo_type&
 * @param[in]       cellNum : Cell number. / uint16_t
 * @param[in]       reportType : Type of the target report configuration. / enumMeasurementReportType
 * @param[in]       reportPurpose : Purpose of the target report configuration. / uint8_t
 * @param[in]       frequency : Frequency to measure (SSB or CSI-RS). / Arfcn_type/uint32_t
 * @param[out]      pRCCandidate : pointer to report config which can be installed on UE /
 *reportConfigurationConfUe_type*
 * @param[out]      pMOCandidate : pointer to meas object which can be installed on UE / minimalMeasObjectConfUe_type*
 * @return          status : true/false, bool
 ****************************************************************************/
bool VCCB_CanMOAndRCBeAddedWithCandidates(callInfo_type &rCi, CellNum_type cellNum,
    enumMeasurementReportType reportType, uint8_t reportPurpose, Arfcn_type frequency,
    reportConfigurationConfUe_type *pRCCandidate, minimalMeasObjectConfUe_type *pMOCandidate)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);

    if (VCCB_IsNoMeasIdsLeft(rCi))
    {
        VCCB_PRINT_CALL_COMMENT(&rCi,
            "VCCB_CanMOAndRCBeAddedWithCandidates(): Cannot install more measurements than %d\n", MAX_NR_OF_MEAS_ID);
        return false;
    }

    VCCB_RptCfgAndMeasObjDbFinder finder(CELLINFO[cellNum].measurementsData, reportType, reportPurpose, frequency);

    if (!VCCB_ValidateMeasObjectAndReportConfigCandidates(rCi, finder, cellNum, reportType, reportPurpose, frequency))
    {
        return false;
    }

    reportConfigurationBaseDb_type dbCandidate;

    const int8_t ueSpecRcApplied = VCCB_GetReportConfigDb(rCi, cellNum, reportType, reportPurpose, finder, dbCandidate);
    if (ERROR == ueSpecRcApplied)
    {
        VCCB_PRINT_CALL_COMMENT(
            &rCi, "VCCB_GetReportConfigDb failed for reportType=%d purpose=%d.\n", reportType, reportPurpose);
        return false;
    }

    if (nullptr != pMOCandidate && nullptr != pRCCandidate)
    {
        if (!VCCB_PrepareMeasObjectUeCandidate(rCi, cellNum, finder._measObjectDbFinder, pMOCandidate))
        {
            return false;
        }
        VCCB_PrepareReportConfigUeCandidate(&rCi, cellNum, reportType, reportPurpose, frequency, finder, *pMOCandidate,
            dbCandidate, ueSpecRcApplied == GOOD, pRCCandidate);
    }

    return true;
}

/****************************************************************************
 * @brief           Add Measurement with specific measObjectCandidate/reportConfigCandidate
 *
 *                  If provided arguments are invalid returns AddMeasurementStatus::NO_MEAS_ID_ADDED.
 *                  If the conditions are met returns
 *                  AddMeasurementStatus::MEAS_IDS_ADDED and add measurement.
 *                  If adding measurement failed return AddMeasurementStatus::NO_MEAS_ID_ADDED.
 *
 * @param[in]       rCi : Reference to call configuration. / callInfo_type*
 * @param[in]       cellNum : Cell number. / uint16_t
 * @param[in]       rReportConfigCandidate : reference to report config to install / rReportConfigCandidate*
 * @param[in]       rMeasObjectCandidate : reference to meas object to install / rMeasObjectCandidate*
 * @param[in]       callbackFuncId : Function to call when measurement report for
 *                                   this measurement identity is received. / enumMeasReportCallbackId_type
 * @return          status : INSTALL_PREP_FAILED, NO_MEAS_ID_ADDED, MEAS_IDS_ADDED / AddMeasurementStatus
 ****************************************************************************/
AddMeasurementStatus VCCB_AddMeasurementWithCandidates(callInfo_type &rCi, const CellNum_type cellNum,
    reportConfigurationConfUe_type &rReportConfigCandidate, minimalMeasObjectConfUe_type &rMeasObjectCandidate,
    const enumMeasReportCallbackId_type callbackFuncId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, AddMeasurementStatus::NO_MEAS_ID_ADDED);
    const auto &rCell = CELLINFO[cellNum];

    const auto applicableNcdSsbs = getApplicableNcdSsbs(rCi, rCell, rMeasObjectCandidate);
    auto installationStatus = AddMeasurementStatus::NO_MEAS_ID_ADDED;

    if (!applicableNcdSsbs.empty())
    {
        for (const auto &ncdSsb : applicableNcdSsbs)
        {
            if (VCCB_IsNoMeasIdsLeft(rCi))
            {
                VCCB_PRINT_CALL_INFORMATIVE(&rCi,
                    "VCCB_AddMeasurementWithCandidates(): Cannot install more measurements than %d\n",
                    MAX_NR_OF_MEAS_ID);
                break;
            }

            if (!FnVCCB_IsSsbAllowed(rCi, ncdSsb.ncdSsbFreq))
            {
                VCCB_PRINT_CALL_COMMENT(&rCi,
                    "VCCB_AddMeasurementWithCandidates(): Cannot install measurement with freq(%d), because it is on "
                    "restricted ssb frequency list!\n",
                    ncdSsb.ncdSsbFreq);
                continue;
            }

            VCCB_UpdateInterFreqMeasObjectCandidateForNcdSsb(rCi, ncdSsb, rMeasObjectCandidate.rat.nr);
            const auto ncdSsbFreq = rMeasObjectCandidate.rat.nr.ncdSsbInfo.ncdSsbArfcn;
            const auto cdSsbFreq = rMeasObjectCandidate.rat.nr.ssbFrequency;

            int status =
                VCCB_AddMeasurement(&rCi, cellNum, &rReportConfigCandidate, &rMeasObjectCandidate, callbackFuncId);

            if (GOOD != status)
            {
                VCCB_PRINT_CALL_ERROR(&rCi,
                    "VCCB_AddMeasurement failed with status [%d] when installing measurement %d with purpose %d "
                    "(cd-ssb:%d/ncd-ssb:%d)\n",
                    status, rReportConfigCandidate.reportType, rReportConfigCandidate.reportPurpose, cdSsbFreq,
                    ncdSsbFreq);
                break;
            }

            installationStatus = AddMeasurementStatus::MEAS_IDS_ADDED;
            VCCB_PRINT_CALL_COMMENT(&rCi, "Add measurement: reportConfig(%s,%d) and MO(cd-ssb:%d/ncd-ssb:%d).\n",
                VLIB_ReportConfigTypeToStr(rReportConfigCandidate.reportType), rReportConfigCandidate.reportPurpose,
                cdSsbFreq, ncdSsbFreq);
        }
    }
    else
    {
        if (GOOD != VCCB_AddMeasurement(&rCi, cellNum, &rReportConfigCandidate, &rMeasObjectCandidate, callbackFuncId))
        {
            return AddMeasurementStatus::NO_MEAS_ID_ADDED;
        }
        return AddMeasurementStatus::MEAS_IDS_ADDED;
    }

    return installationStatus;
}

/****************************************************************************
 * @brief           Prepare measObjectCandidate, reportConfigCandidate and next
 *                  Add Measurement Id Report
 *
 *                  If provided arguments are invalid returns AddMeasurementStatus::INSTALL_PREP_FAILED.
 *                  If the VCCB_CanMOAndRCBeAddedWithCandidates failed returns
 *                  AddMeasurementStatus::INSTALL_PREP_FAILED. If the conditions are met returns
 *                  AddMeasurementStatus::MEAS_IDS_ADDED and add measurement.
 *                  If adding measurement failed return AddMeasurementStatus::NO_MEAS_ID_ADDED.
 *
 * @param[in]       rCi : Reference to call configuration. / callInfo_type*
 * @param[in]       cellNum : Cell number. / uint16_t
 * @param[in]       reportType : Type of the target report configuration. / enumMeasurementReportType
 * @param[in]       reportPurpose : Purpose of the target report configuration. / uint8_t
 * @param[in]       frequency : Frequency to measure (CD-SSB or CSI-RS). / Arfcn_type/uint32_t
 * @param[in]       callbackFuncId : Function to call when measurement report for
 *                                   this measurement identity is received. / enumMeasReportCallbackId_type
 * @return          status : INSTALL_PREP_FAILED, NO_MEAS_ID_ADDED, MEAS_IDS_ADDED / AddMeasurementStatus
 ****************************************************************************/
AddMeasurementStatus VCCB_TryToAddMeasurement(callInfo_type &rCi, const CellNum_type cellNum,
    const enumMeasurementReportType reportType, const uint8_t reportPurpose, const Arfcn_type frequency,
    const enumMeasReportCallbackId_type callbackFuncId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, AddMeasurementStatus::INSTALL_PREP_FAILED);

    reportConfigurationConfUe_type reportConfigCandidate;
    minimalMeasObjectConfUe_type measObjectCandidate;

    if (!VCCB_CanMOAndRCBeAddedWithCandidates(
            rCi, cellNum, reportType, reportPurpose, frequency, &reportConfigCandidate, &measObjectCandidate))
    {
        return AddMeasurementStatus::INSTALL_PREP_FAILED;
    }

    return VCCB_AddMeasurementWithCandidates(rCi, cellNum, reportConfigCandidate, measObjectCandidate, callbackFuncId);
}

/****************************************************************************
 * @brief           Description
 *
 *                  If provided arguments are invalid returns AddMeasurementStatus::INSTALL_PREP_FAILED.
 *                  If the conditions are not met returns AddMeasurementStatus::NO_MEAS_ID_ADDED.
 *                  If the conditions are met returns AddMeasurementStatus::MEAS_ID_ADDED and add measurement.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       cellNum : Cell number. / uint16_t
 * @param[in]       reportType : Type of the target report configuration. / enumMeasurementReportType
 * @param[in]       reportPurpose : Purpose of the target report configuration. / uint8_t
 * @param[in]       frequency : Frequency to measure (SSB or CSI-RS). / Arfcn_type/uint32_t
 * @param[in]       callbackFuncId : Function to call when measurement report for
 *                                   this measurement identity is received. / enumMeasReportCallbackId_type
 * @return          status : INSTALL_PREP_FAILED, NO_MEAS_ID_ADDED, MEAS_IDS_ADDED / AddMeasurementStatus
 ****************************************************************************/
AddMeasurementStatus VCCB_AddA2Measurement(callInfo_type *ptCi, CellNum_type cellNum, enumA2Purpose reportPurpose,
    Arfcn_type frequency, enumMeasReportCallbackId_type callbackFuncId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, AddMeasurementStatus::INSTALL_PREP_FAILED);
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, AddMeasurementStatus::INSTALL_PREP_FAILED);

    return VCCB_AddA2Measurement(
        ptCi, cellNum, reportPurpose, frequency, callbackFuncId, MeasurementQuantityBitmask_None);
}

/****************************************************************************
 * @brief           Description
 *
 *                  If provided arguments are invalid returns AddMeasurementStatus::INSTALL_PREP_FAILED.
 *                  If the conditions are not met returns AddMeasurementStatus::NO_MEAS_ID_ADDED.
 *                  If the conditions are met returns AddMeasurementStatus::MEAS_ID_ADDED and add measurement.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       cellNum : Cell number. / uint16_t
 * @param[in]       reportType : Type of the target report configuration. / enumMeasurementReportType
 * @param[in]       reportPurpose : Purpose of the target report configuration. / uint8_t
 * @param[in]       frequency : Frequency to measure (SSB or CSI-RS). / Arfcn_type/uint32_t
 * @param[in]       callbackFuncId : Function to call when measurement report for
 *                                   this measurement identity is received. / enumMeasReportCallbackId_type
 * @param[in]       forbiddenQuantitiesBitmask : Bitmask to exclude quantities from instaling (Only for Multiple Trigger
 *feature) / int (use enum MeasurementQuantityBitmask to fill)
 * @return          status : INSTALL_PREP_FAILED, NO_MEAS_ID_ADDED, MEAS_IDS_ADDED / AddMeasurementStatus
 ****************************************************************************/
AddMeasurementStatus VCCB_AddA2Measurement(callInfo_type *ptCi, CellNum_type cellNum, enumA2Purpose reportPurpose,
    Arfcn_type frequency, enumMeasReportCallbackId_type callbackFuncId, int forbiddenQuantitiesBitmask)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, AddMeasurementStatus::INSTALL_PREP_FAILED);
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, AddMeasurementStatus::INSTALL_PREP_FAILED);

    if (VCCB_IsNoMeasIdsLeft(*ptCi))
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "VCCB_AddA2Measurement(): Cannot install more measurements than %d\n", MAX_NR_OF_MEAS_ID);
        return AddMeasurementStatus::NO_MEAS_ID_ADDED;
    }

    VCCB_RptCfgAndMeasObjDbFinder finder(CELLINFO[cellNum].measurementsData, measReport_A2, reportPurpose, frequency);

    if (!VCCB_ValidateMeasObjectAndReportConfigCandidates(
            *ptCi, finder, cellNum, measReport_A2, reportPurpose, frequency))
    {
        return AddMeasurementStatus::INSTALL_PREP_FAILED;
    }

    reportConfigurationBaseDb_type dbCandidate;
    const int8_t ueSpecRcApplied =
        VCCB_GetReportConfigDb(*ptCi, cellNum, measReport_A2, reportPurpose, finder, dbCandidate);
    if (ERROR == ueSpecRcApplied)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "VCCB_GetReportConfigDb failed for reportType=A2 purpose=%d.\n", reportPurpose);
        return AddMeasurementStatus::INSTALL_PREP_FAILED;
    }

    minimalMeasObjectConfUe_type measObjectCandidate;
    if (!VCCB_PrepareMeasObjectUeCandidate(*ptCi, cellNum, finder._measObjectDbFinder, &measObjectCandidate))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Cannot prepare MeasObject with %d!\n", frequency);
        return AddMeasurementStatus::INSTALL_PREP_FAILED;
    }

    simpleVector<reportConfigurationConfUe_type, MAX_REPORT_CONFIG_QUANTITIES> reportConfigCandidates;
    auto &a2ReportConfig = dbCandidate.reportConfiguration.eventBased.event.A2;
    auto &a2ReportConfigExt = dbCandidate.reportConfigExtension.eventBased.event.A2;

    if (a2ReportConfigExt.multipleTriggerFeatureEnabled)
    {
        uint8_t requestedQuantities = MeasurementQuantityBitmask_None;
        switch (a2ReportConfigExt.multipleTriggerQuantitySet)
        {
            case quantity_set_rsrp_rsrq:
            {
                requestedQuantities = MeasurementQuantityBitmask_RSRP | MeasurementQuantityBitmask_RSRQ;
                break;
            }
            case quantity_set_rsrp_sinr:
            {
                requestedQuantities = MeasurementQuantityBitmask_RSRP;
                if (CAN_UE_REPORT_SINR(ptCi, frequency))
                {
                    requestedQuantities = requestedQuantities | MeasurementQuantityBitmask_SINR;
                }
                break;
            }
            case quantity_set_rsrp_rsrq_sinr:
            {
                requestedQuantities = MeasurementQuantityBitmask_RSRP | MeasurementQuantityBitmask_RSRQ;
                if (CAN_UE_REPORT_SINR(ptCi, frequency))
                {
                    requestedQuantities = requestedQuantities | MeasurementQuantityBitmask_SINR;
                }
                break;
            }
            default:
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_AddA2Measurement failed, unknown quantity-set in configuration\n");
                return AddMeasurementStatus::INSTALL_PREP_FAILED;
            }
        }
        int toInstallQuantities = requestedQuantities & (~forbiddenQuantitiesBitmask);

        simpleVector<enumMeasTriggerQuantityChoice, MAX_REPORT_CONFIG_QUANTITIES> toInstallQuantitiesList{};
        if (toInstallQuantities & MeasurementQuantityBitmask_RSRP)
        {
            toInstallQuantitiesList.push_back(choice_rsrp);
        }
        if (toInstallQuantities & MeasurementQuantityBitmask_RSRQ)
        {
            toInstallQuantitiesList.push_back(choice_rsrq);
        }
        if (toInstallQuantities & MeasurementQuantityBitmask_SINR)
        {
            toInstallQuantitiesList.push_back(choice_sinr);
        }

        for (const auto &quantity : toInstallQuantitiesList)
        {
            VCCB_fillQuantityInfo(quantity, a2ReportConfig.a2_Threshold.quantityInfo);

            if (a2ReportConfigExt.multipleTimeToTriggerEnabled)
            {
                VCCB_FillMultipleTimeToTrigger(
                    quantity, dbCandidate.reportConfigExtension.eventBased, dbCandidate.reportConfiguration.eventBased);
                VCCB_PRINT_CALL_COMMENT(ptCi, "Multiple Time To Trigger (%d) applied for quantity %s\n",
                    dbCandidate.reportConfiguration.eventBased.timeToTrigger, getReportQuantityStr(quantity));
            }

            reportConfigurationConfUe_type &reportConfigCandidate = reportConfigCandidates.allocate();
            VCCB_PrepareReportConfigUeCandidate(ptCi, cellNum, measReport_A2, reportPurpose, frequency, finder,
                measObjectCandidate, dbCandidate, ueSpecRcApplied == GOOD, &reportConfigCandidate);
            reportConfigCandidate.reportConfiguration.eventBased.event.A2.multipleTriggerQuantityEnabled = true;

            VCCB_PRINT_CALL_COMMENT(ptCi,
                "Multiple Trigger Quantity: A2 RC candidate with purpose(%d) and quantity %s prepared\n", reportPurpose,
                getReportQuantityStr(quantity));
        }
    }
    else
    {
        VCCB_PrepareReportConfigUeCandidate(ptCi, cellNum, measReport_A2, reportPurpose, frequency, finder,
            measObjectCandidate, dbCandidate, ueSpecRcApplied == GOOD, &reportConfigCandidates.allocate());
    }

    auto installationStatus = AddMeasurementStatus::NO_MEAS_ID_ADDED;
    for (const auto &reportConfigCandidate : reportConfigCandidates)
    {
        if (VCCB_IsNoMeasIdsLeft(*ptCi))
        {
            VCCB_PRINT_CALL_INFORMATIVE(
                ptCi, "VCCB_AddA2Measurement(): Cannot install more measurements than %d\n", MAX_NR_OF_MEAS_ID);
            break;
        }

        if (GOOD != VCCB_AddMeasurement(ptCi, cellNum, &reportConfigCandidate, &measObjectCandidate, callbackFuncId))
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "VCCB_AddMeasurement failed when installing measurement %d with purpose %d (ssbArfcn: %u)\n",
                measReport_A2, reportPurpose, frequency);
            break;
        }
        else
        {
            installationStatus = AddMeasurementStatus::MEAS_IDS_ADDED;
        }
    }

    return installationStatus;
}

/****************************************************************************
 * @brief           Description
 *
 *                  If provided arguments are invalid returns INSTALL_PREP_FAILED.
 *                  If the conditions are not met returns INSTALL_PREP_FAILED.
 *                  If the conditions are met returns MEAS_IDS_ADDED and add measurement.
 *
 * @param[in]       rCi : Reference to call configuration. / callInfo_type&
 * @param[in]       cellNum : Cell number. / uint16_t
 * @param[in]       reportType : Type of the target report configuration. / enumMeasurementReportType
 * @param[in]       reportPurpose : Purpose of the target report configuration. / uint8_t
 * @param[in]       frequency : Frequency to measure (SSB or CSI-RS). / Arfcn_type/uint32_t
 * @param[in]       callbackFuncId : Function to call when measurement report for
 *                                   this measurement identity is received. / enumMeasReportCallbackId_type
 * @param[in]       forcedQuantity : Stored quantity choice / enumMeasTriggerQuantityChoice
 * @return          status : INSTALL_PREP_FAILED, NO_MEAS_ID_ADDED, MEAS_IDS_ADDED / AddMeasurementStatus
 ****************************************************************************/
AddMeasurementStatus VCCB_AddMeasurementIfPossibleWithForcedQuantity(callInfo_type &rCi, CellNum_type cellNum,
    const enumMeasurementReportType reportType, const uint8_t reportPurpose, Arfcn_type frequency,
    enumMeasReportCallbackId_type callbackFuncId, enumMeasTriggerQuantityChoice forcedQuantity)
{
    AUTO_TRACE_FUNC;
    return VCCB_AddMeasurementIfPossibleWithForcedQuantities(rCi, cellNum, reportType, reportPurpose, frequency,
        callbackFuncId, VCCB_ConvertMeasQuantityToBitmask(forcedQuantity));
}

/****************************************************************************
 * @brief           Description
 *
 *                  If provided arguments are invalid returns INSTALL_PREP_FAILED.
 *                  If the conditions are not met returns INSTALL_PREP_FAILED.
 *                  If the conditions are met returns MEAS_IDS_ADDED and add measurement.
 *
 * @param[in]       rCi : Reference to call configuration. / callInfo_type&
 * @param[in]       cellNum : Cell number. / uint16_t
 * @param[in]       reportType : Type of the target report configuration. / enumMeasurementReportType
 * @param[in]       reportPurpose : Purpose of the target report configuration. / uint8_t
 * @param[in]       frequency : Frequency to measure (SSB or CSI-RS). / Arfcn_type/uint32_t
 * @param[in]       callbackFuncId : Function to call when measurement report for
 *                                   this measurement identity is received. / enumMeasReportCallbackId_type
 * @param[in]       forcedQuantitiesBitmask : Bitmask to select quantities to install, if forcedQuantities is equal
 *MeasurementQuantityBitmask_None then quantity from DB will be used to install measurement / int (use
 *enum MeasurementQuantityBitmask to fill)
 * @return          status : INSTALL_PREP_FAILED, NO_MEAS_ID_ADDED, MEAS_IDS_ADDED / AddMeasurementStatus
 ****************************************************************************/
AddMeasurementStatus VCCB_AddMeasurementIfPossibleWithForcedQuantities(callInfo_type &rCi, CellNum_type cellNum,
    const enumMeasurementReportType reportType, const uint8_t reportPurpose, Arfcn_type frequency,
    enumMeasReportCallbackId_type callbackFuncId, int forcedQuantitiesBitmask)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, AddMeasurementStatus::INSTALL_PREP_FAILED);

    if (VCCB_IsNoMeasIdsLeft(rCi))
    {
        VCCB_PRINT_CALL_COMMENT(&rCi,
            "VCCB_AddMeasurementIfPossibleWithForcedQuantities(): Cannot install more measurements than %d\n",
            MAX_NR_OF_MEAS_ID);
        return AddMeasurementStatus::NO_MEAS_ID_ADDED;
    }

    VCCB_RptCfgAndMeasObjDbFinder finder(CELLINFO[cellNum].measurementsData, reportType, reportPurpose, frequency);

    if (!VCCB_ValidateMeasObjectAndReportConfigCandidates(rCi, finder, cellNum, reportType, reportPurpose, frequency))
    {
        return AddMeasurementStatus::INSTALL_PREP_FAILED;
    }

    reportConfigurationBaseDb_type dbCandidate;
    const int8_t ueSpecRcApplied = VCCB_GetReportConfigDb(rCi, cellNum, reportType, reportPurpose, finder, dbCandidate);
    if (ERROR == ueSpecRcApplied)
    {
        VCCB_PRINT_CALL_COMMENT(
            &rCi, "VCCB_GetReportConfigDb failed for reportType=%d purpose=%d.\n", reportType, reportPurpose);
        return AddMeasurementStatus::INSTALL_PREP_FAILED;
    }

    minimalMeasObjectConfUe_type measObjectCandidate;
    if (!VCCB_PrepareMeasObjectUeCandidate(rCi, cellNum, finder._measObjectDbFinder, &measObjectCandidate))
    {
        return AddMeasurementStatus::INSTALL_PREP_FAILED;
    }

    simpleVector<reportConfigurationConfUe_type, MAX_REPORT_CONFIG_QUANTITIES> reportConfigCandidates;
    if (MeasurementQuantityBitmask_None == forcedQuantitiesBitmask)
    {
        VCCB_PrepareReportConfigUeCandidate(&rCi, cellNum, reportType, reportPurpose, frequency, finder,
            measObjectCandidate, dbCandidate, ueSpecRcApplied == GOOD, &reportConfigCandidates.allocate());
    }
    else
    {
        QuantitiesList toInstallQuantitiesList = VCCB_PrepareQuantitiesToInstall(forcedQuantitiesBitmask);
        for (const auto &quantity : toInstallQuantitiesList)
        {
            reportConfigurationBaseDb_type dbCandidateWithChangedQuantity = dbCandidate;

            VCCB_FillReportConfigQuantityInfoPerReportType(dbCandidateWithChangedQuantity, quantity);

            reportConfigurationConfUe_type &reportConfigCandidate = reportConfigCandidates.allocate();
            VCCB_PrepareReportConfigUeCandidate(&rCi, cellNum, reportType, reportPurpose, frequency, finder,
                measObjectCandidate, dbCandidateWithChangedQuantity, ueSpecRcApplied == GOOD, &reportConfigCandidate);

            VCCB_PRINT_CALL_COMMENT(&rCi, "RC candidate with purpose(%d),type(%d),quantity(%s) prepared\n",
                reportPurpose, reportType, getReportQuantityStr(quantity));
        }
    }

    auto installationStatus = AddMeasurementStatus::INSTALL_PREP_FAILED;
    for (const auto &reportConfigCandidate : reportConfigCandidates)
    {
        if (VCCB_IsNoMeasIdsLeft(rCi))
        {
            VCCB_PRINT_CALL_INFORMATIVE(&rCi,
                "VCCB_AddMeasurementIfPossibleWithForcedQuantities(): Cannot install more measurements than %d\n",
                MAX_NR_OF_MEAS_ID);
            break;
        }

        if (GOOD != VCCB_AddMeasurement(&rCi, cellNum, &reportConfigCandidate, &measObjectCandidate, callbackFuncId))
        {
            VCCB_PRINT_CALL_ERROR(&rCi,
                "VCCB_AddMeasurement failed when installing measurement %d with purpose %d (ssbArfcn: %u)\n",
                measReport_A2, reportPurpose, frequency);
            break;
        }
        else
        {
            installationStatus = AddMeasurementStatus::MEAS_IDS_ADDED;
        }
    }

    return installationStatus;
}

/****************************************************************************
 * @brief           Check if measReport and measObject are configured in DB and eligible for UE
 *
 * @param[in]       cellNum : Cell number. / uint16_t
 * @param[in]       reportType : Type of the target report configuration. / enumMeasurementReportType
 * @param[in]       reportPurpose : Purpose of the target report configuration. / uint8_t
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_IsMeasRptObjEligibleForUe(callInfo_type *ptCi, CellNum_type cellNum, enumMeasurementReportType reportType,
    uint8_t reportPurpose, Arfcn_type frequency)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    // Find MeasObject and related ReportConfiguration in DB
    VCCB_RptCfgAndMeasObjDbFinder finder(CELLINFO[cellNum].measurementsData, reportType, reportPurpose, frequency);
    if (false == finder.isValid())
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Couldn't find rptCfg(type(%d) purpose(%hu)) measObj(freq(%u)) cellNum(%u)\n",
            reportType, reportPurpose, frequency, cellNum);

        return BREAK;
    }

    // Check MeasObject
    switch (finder._ratType)
    {
        case measRatNr:
            if (GOOD != VCCB_IsMeasObjectNrEligibleForUe(ptCi, finder._measObjectDbFinder._pDbObjNr, cellNum))
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "measObj NR(freq(%u)) is not eligible for UE!\n", frequency);

                return BREAK;
            }
            break;

        case measRatEutra:
            if (GOOD != VCCB_IsMeasObjectEutraEligibleForUe(ptCi, finder._measObjectDbFinder._pDbObjEutra))
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "measObj EUTRA(freq(%u)) is not eligible for UE!\n", frequency);

                return BREAK;
            }
            break;

        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "ratType(%u) not supported!\n", finder._ratType);

            return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           This function is used for the purpose of initializing the installed db set in UE.
 *                 (Breaks the relationship between Installed DB and newItem DB. Accordingly, this is to include All
 *measConfig in RRC Reconfiguration.)
 *
 * @param[in,out]   ptCi :          call information
 * @return          status :        GOOD, ERROR / int16_t
 ****************************************************************************/

int16_t VCCM_BreakInternalIdxInNewItems(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    /* remove the installed item */
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    // reportConfigurations
    for (uint8_t i = 0; i < MAX_NR_OF_REPORT_CONFIG_ID; ++i)
    {
        if (rMeasProc.reportConfigurations.newItems[i].usage == CI_no_use) continue;
        if (rMeasProc.reportConfigurations.newItems[i].internalIdx == MAX_NR_OF_REPORT_CONFIG_ID) continue;

        rMeasProc.reportConfigurations.newItems[i].internalIdx = MAX_NR_OF_REPORT_CONFIG_ID;
    }

    // measurementObjects
    for (auto &item : rMeasProc.measurementObjects.newItems)
    {
        if (item.usage == CI_no_use) continue;
        if (item.internalIdx == MAX_NR_OF_OBJECT_ID) continue;

        item.internalIdx = MAX_NR_OF_OBJECT_ID;
    }

    // measurementIdentities
    for (uint8_t i = 0; i < MAX_NR_OF_MEAS_ID; ++i)
    {
        if (rMeasProc.measurementIdentities.newItems[i].usage == CI_no_use) continue;
        if (rMeasProc.measurementIdentities.newItems[i].internalIdx == MAX_NR_OF_MEAS_ID) continue;

        rMeasProc.measurementIdentities.newItems[i].internalIdx = MAX_NR_OF_MEAS_ID;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           This function is used for the purpose of initializing the installed db set in UE.
 *                  Scenario 1) If it is determined to be Full Config, initialize the installed db before sending HO
 *Ack. Afterwards, the message composed of the new item is included in the HO Ack.
 *
 * @param[in,out]   ptCi :          call information
 * @return          status :        GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_ClearInstalledMeasConfig(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    /* remove the installed item */
    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);

    // reportConfigurations
    for (uint8_t i = 0; i < MAX_NR_OF_REPORT_CONFIG_ID; ++i)
    {
        rMeasConf.reportConfigurations.installedItems[i].usage = CI_no_use;
    }

    // measurementObjects
    for (auto &item : rMeasConf.measurementObjects.installedItems)
    {
        item.usage = CI_no_use;
    }

    // measurementIdentities
    for (uint8_t i = 0; i < MAX_NR_OF_MEAS_ID; ++i)
    {
        rMeasConf.measurementIdentities.installedItems[i].usage = CI_no_use;
    }

    /* s-MeasureConfig */
    rMeasConf.sMeasureConfig.installedItem.usage = CI_no_use;

    /* quantityConfig */
    for (uint8_t i = 0; i < MAX_NR_OF_QUANTITY_CONFIG; ++i)
    {
        rMeasConf.quantityConfigurations.installedItem.nr[i].usage = CI_no_use;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Prepares internal structures for new measurements
 *                  configuration.
 *
 * @param[in/out]   rCi : Reference to call configuration.
 * @param[in]       clearToRemoveFlag : Flag if items to remove shall be cleared
 ****************************************************************************/
void VCCB_ClearNewMeasConfig(callInfo_type &rCi, enumVccbFlag clearToRemoveFlag)
{
    AUTO_TRACE_FUNC;

    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(rCi);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(rCi);

    rMeasProc.pa4mAggregatedPerMiCnt = 0;
    rMeasProc.lpmPurposeMask = 0;

    rMeasProc.tgtCellNum = MAX_CELL_NUM_VCCB;
    rMeasProc.measConfigReadyFlag = FLAG_OFF;
    rMeasConf.svcGrpChangeProcedure = FALSE;

    rMeasProc.tgtCellNewMoIdx = MAX_NR_OF_OBJECT_ID;
    scellList_type &scells = FnVCCB_GetScellInfoList(rCi);
    for (uint16_t cellIdx = 0; cellIdx < MAX_SCELL_PER_CALL; cellIdx++)
    {
        scells[cellIdx].newMoIdx = MAX_NR_OF_OBJECT_ID;
    }

    rMeasProc.measurementObjects.numNewItems = 0;
    rMeasProc.measurementObjects.itemsToModify = 0;
    for (auto &item : rMeasConf.measurementObjects.installedItems)
    {
        if ((item.usage == CI_no_use) && (item.pending == VCCB_FLAG_ON))
        {
            item.pending = VCCB_FLAG_OFF;
        }
        if ((item.usage == CI_use) && (item.pending == VCCB_FLAG_OFF))
        {
            item.pending = VCCB_FLAG_ON;
        }
    }

    rMeasProc.measurementObjects.itemsToRemove = 0;
    rMeasProc.measurementObjects.idsToRemove = 0;
    if (VCCB_FLAG_ON == clearToRemoveFlag)
    {
        rMeasProc.measurementObjects.foreignIdsToRemove = 0;
    }

    rMeasProc.reportConfigurations.numNewItems = 0;
    rMeasProc.reportConfigurations.itemsToModify = 0;
    for (uint8_t i = 0; i < MAX_NR_OF_REPORT_CONFIG_ID; ++i)
    {
        if ((rMeasConf.reportConfigurations.installedItems[i].usage == CI_no_use) &&
            (rMeasConf.reportConfigurations.installedItems[i].pending == VCCB_FLAG_ON))
        {
            rMeasConf.reportConfigurations.installedItems[i].pending = VCCB_FLAG_OFF;
        }
        if ((rMeasConf.reportConfigurations.installedItems[i].usage == CI_use) &&
            (rMeasConf.reportConfigurations.installedItems[i].pending == VCCB_FLAG_OFF))
        {
            rMeasConf.reportConfigurations.installedItems[i].pending = VCCB_FLAG_ON;
        }
    }

    rMeasProc.reportConfigurations.itemsToRemove = 0;
    rMeasProc.reportConfigurations.idsToRemove = 0;
    if (VCCB_FLAG_ON == clearToRemoveFlag)
    {
        rMeasProc.reportConfigurations.foreignIdsToRemove = 0;
    }

    rMeasProc.measurementIdentities.numNewItems = 0;
    for (uint8_t i = 0; i < MAX_NR_OF_MEAS_ID; ++i)
    {
        if ((rMeasConf.measurementIdentities.installedItems[i].usage == CI_no_use) &&
            (rMeasConf.measurementIdentities.installedItems[i].pending == VCCB_FLAG_ON))
        {
            rMeasConf.measurementIdentities.installedItems[i].pending = VCCB_FLAG_OFF;
        }
        if ((rMeasConf.measurementIdentities.installedItems[i].usage == CI_use) &&
            (rMeasConf.measurementIdentities.installedItems[i].pending == VCCB_FLAG_OFF))
        {
            rMeasConf.measurementIdentities.installedItems[i].pending = VCCB_FLAG_ON;
        }
    }

    rMeasProc.measurementIdentities.itemsToRemove = 0;
    if (VCCB_FLAG_ON == clearToRemoveFlag)
    {
        rMeasProc.measurementIdentities.foreignIdsToRemove = 0;
    }
    rMeasProc.sMeasureConfig.status = VCCB_FLAG_OFF;
    rMeasProc.quantityConfigurations.statusNR = VCCB_FLAG_OFF;
    rMeasProc.quantityConfigurations.statusEUTRA = VCCB_FLAG_OFF;

    rCi.measurementsConfigShared.ltmMeasNeeded = FALSE;
}

/****************************************************************************
 * @brief           Applies the new measurement configuration.
 *                  Call this function before sending RRC MeasConfig (FillMeasConf*).
 *
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_ApplyNewMeasConfig(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (ERROR == VCCB_ApplyMeasObjectConfig(ptCi))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_ApplyMeasObjectConfig failed in VCCB_ApplyNewMeasConfig!\n");

        return ERROR;
    }

    if (ERROR == VCCB_ApplyReportConfig(ptCi))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_ApplyReportConfig failed in VCCB_ApplyNewMeasConfig!\n");

        return ERROR;
    }

    if (ERROR == VCCB_ApplyMeasIdentities(ptCi))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_ApplyMeasIdentities failed in VCCB_ApplyNewMeasConfig!\n");

        return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief Decide NeedForGaps Configuration
 * @param ptCi          : call information
 ****************************************************************************/
void VCCB_DecideNeedForGapsConfig(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (FnVCCB_IsLtmCandPrepForMeas(*ptCi))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[m-gap] DecideNeedForGapsConfig: skip for LTM candidate preparation\n");
        return;
    }

    ptCi->needForGapNrUeData.configNewFlag = FLAG_OFF;

    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    gnbConfig_type *const pGnbCfg = &GNBINFO[ptCi->gnbNum].cfg;

    /*
    - Check call type: SA only (EN-DC, NE-DC, NR-DC - not supported)
    - Check UE Capability
    - Check gNB configuration
    */

    bool mrDcFlag = IS_NOT_MRDC_SCG_RELEASE_ONGOING(ptCi);

    VCCB_PRINT_CALL_COMMENT(ptCi,
        "[m-gap] DecideNeedForGapsConfig: callType(%u) dbEnabled(%u) UeCapa(%u) mrDcFlag(%u)\n", ptCi->callType,
        pGnbCfg->measGap.needForGapsNrEnabled, ptCi->ueInfo.ueCapa.nr.measAndMob.nrNeedForGapReportingR16, mrDcFlag);

    if ((E_CALLTYPE_SA != ptCi->callType) || (FLAG_OFF == pGnbCfg->measGap.needForGapsNrEnabled) ||
        (FLAG_OFF == ptCi->ueInfo.ueCapa.nr.measAndMob.nrNeedForGapReportingR16) || (true == mrDcFlag))
    {
        return;
    }

    ptCi->needForGapNrUeData.configNewFlag = FLAG_ON;
    memset(ptCi->needForGapNrUeData.bandFilterNew, 0, sizeof(ptCi->needForGapNrUeData.bandFilterNew));

    for (uint16_t bandIdx = 0;
         bandIdx < util::minOfArraySizeAndNumOfElems(
                       ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR, ptCi->ueInfo.ueCapa.nr.rf.nrOfBands);
         bandIdx++)
    {
        bandNrUeCapa_type *pBandNrUeCapa = &ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR[bandIdx];
        if (GETBIT_U8TABLE(pGnbCfg->measGap.needForGapsNrBandFilterBitmap, pBandNrUeCapa->bandNR - 1))
        {
            ONBIT_U8TABLE(ptCi->needForGapNrUeData.bandFilterNew, pBandNrUeCapa->bandNR - 1);
        }
    }

    // clean previous Information
    if (FLAG_OFF == ptCi->needForGapNrUeData.configInstalledFlag)
    {
        ptCi->needForGapNrUeData.intraFreqServCellIdBitmask = 0;
        ptCi->needForGapNrUeData.intraFreqGapIndBitmask = 0;
        memset(ptCi->needForGapNrUeData.noGapInterFreqInfoBitmap, 0,
            sizeof(ptCi->needForGapNrUeData.noGapInterFreqInfoBitmap));
    }
}

/****************************************************************************
 * @brief  Check if MeasObject inter-freq no need m-gap
 * @param  ptCi           : pointer to UE Context
 * @param  ptMeasObj      : pointer to MeasObj to be checked
 * @return int16_t        : status : GOOD - no need m-gap, ERROR,BREAK / int16_t
 ****************************************************************************/
int16_t VCCB_CheckMeasObjectNrInterFreqNoNeedForGap(callInfo_type *ptCi, const measurementObjectNRUe_type *ptMeasObj)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMeasObj);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    gnbConfig_type *const pGnbCfg = &GNBINFO[ptCi->gnbNum].cfg;

    CellNum_type cellNum = FnVCCB_GetMeasurementsProcedure(*ptCi).tgtCellNum;
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    // Check fr2-gapless-fr1-pcell
    if ((E_CALLTYPE_SA == ptCi->callType) && (VCCB_FLAG_ON == pGnbCfg->measGap.fr2GaplessFr1PcellEnabled) &&
        (MIN_A6_NR_ARFCN <= ptMeasObj->minimal.ssbFrequency) && (MIN_A6_NR_ARFCN > pCell->ssbArfcn) &&
        ((false == IsAvailable_MrdcInfo()) || IS_NRDC_SNREL_INVOKED(ptCi)))
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "[m-gap] inter-freq ssbArfcn(%u) FR MO: gapless for FR1 PCell\n", ptMeasObj->minimal.ssbFrequency);
        return GOOD;
    }

    // Check needForGapsConfigNR
    if (FLAG_OFF == ptCi->needForGapNrUeData.configNewFlag)
    {
        return BREAK;
    }

    for (uint16_t ueCapaIdx = 0;
         ueCapaIdx < util::minOfArraySizeAndNumOfElems(
                         ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR, ptCi->ueInfo.ueCapa.nr.rf.nrOfBands);
         ueCapaIdx++)
    {
        if (ptMeasObj->minimal.freqBandIndicatorNR != ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR[ueCapaIdx].bandNR)
        {
            continue;
        }

        if (GETBIT_U8TABLE(ptCi->needForGapNrUeData.noGapInterFreqInfoBitmap,
                ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR[ueCapaIdx].bandNR - 1))
        {
            VCCB_PRINT_CALL_COMMENT(
                ptCi, "[m-gap] inter-freq NR band(%u): no-gap\n", ptMeasObj->minimal.freqBandIndicatorNR);
            return GOOD;
        }
        else
        {
            return BREAK;
        }
    }

    return BREAK;
}

/****************************************************************************
 * @brief  Check if MeasObject for non serving frequency no need m-gap for SA only call.
 * @param  ptCi           : pointer to UE Context
 * @param  ptUeMeasObj    : pointer to MeasObj to be checked
 * @param  srvCellNrFr1   : true if there are any FR1 serving cells
 * @param  srvCellNrFr2   : true if there are any FR2 serving cells
 * @return int16_t        : status : GOOD - no need m-gap, ERROR,BREAK / int16_t
 ****************************************************************************/
int16_t VCCB_CheckMeasObjectNonServFreqNoNeedGapSA(
    callInfo_type *ptCi, const measurementObjectUe_type *ptUeMeasObj, bool srvCellNrFr1, bool srvCellNrFr2)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUeMeasObj);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const gnbConfig_type &rGnbCfg = GNBINFO[ptCi->gnbNum].cfg;

    const bool independentGapConfig =
        (ptCi->ueInfo.ueCapa.nr.measAndMob.independentGapConfig && (VCCB_FLAG_ON == rGnbCfg.measGap.indepGapEnabledNr));
    const bool isMoFr2 = ((measRatNr == ptUeMeasObj->conf.ratType) &&
                          (MIN_A6_NR_ARFCN <= ptUeMeasObj->conf.rat.nr.minimal.ssbFrequency));
    int16_t result = GOOD;

    // 3GPP 38.133 table 9.1.2-3
    if ((false == independentGapConfig) || ((true == isMoFr2) && (true == srvCellNrFr2)) ||
        ((false == isMoFr2) && (true == srvCellNrFr1)))
    {
        if ((measRatNr == ptUeMeasObj->conf.ratType) &&
            (GOOD == VCCB_CheckMeasObjectNrInterFreqNoNeedForGap(ptCi, &ptUeMeasObj->conf.rat.nr)))
        {
            // no gap - debug already done in above function
            result = GOOD;
        }
        else
        {
            // gap required
            result = BREAK;
        }
    }
    // else, no gap

    if (measRatNr == ptUeMeasObj->conf.ratType)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "[m-gap][SA] gap required(%u) for MO NR ssbArfcn(%u), indepGapCfg(%u), servCells: FR1(%u) FR2(%u).\n",
            GOOD != result, ptUeMeasObj->conf.rat.nr.minimal.ssbFrequency, independentGapConfig, srvCellNrFr1,
            srvCellNrFr2);
    }
    else
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "[m-gap][SA] gap required(%u) for MO EUTRA earfcn(%u), indepGapCfg(%u), servCells: FR1(%u) FR2(%u).\n",
            GOOD != result, ptUeMeasObj->conf.rat.eutra.minimal.overlappedCarrierFreq, independentGapConfig,
            srvCellNrFr1, srvCellNrFr2);
    }

    return result;
}

/****************************************************************************
 * @brief  Check if MN force perUE m-gap by measConfigMN for SN call.
 * @param  ptCi     : pointer to UE Context
 * @return bool     : true/false
 ****************************************************************************/
inline bool VCCB_CheckMnForcedPerUeGapsForSn(const callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    const measConfigMN_type &rMeasConfigMN = ptCi->cgConfigInfo.measConfigMN;

    return ((VCCB_FLAG_ON == rMeasConfigMN.measGapConfigFR1.flag) &&
            (((VCCB_FLAG_ON == rMeasConfigMN.gapPurposeFlag) && (NRRRC_perUE == rMeasConfigMN.gapPurpose)) ||
                (VCCB_FLAG_OFF == rMeasConfigMN.gapPurposeFlag)));
}

/****************************************************************************
 * @brief  Check if MeasObject for non serving frequency no need m-gap for EN-DC call.
 * @param  ptCi           : pointer to UE Context
 * @param  ptUeMeasObj    : pointer to MeasObj to be checked
 * @param  srvCellNrFr2   : true if there are any FR2 serving cells
 * @return int16_t        : status : GOOD - no need m-gap, ERROR,BREAK / int16_t
 ****************************************************************************/
int16_t VCCB_CheckMeasObjectNonServFreqNoNeedGapENDC(
    callInfo_type *ptCi, const measurementObjectUe_type *ptUeMeasObj, bool srvCellNrFr2)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUeMeasObj);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    gnbConfig_type *const pGnbCfg = &GNBINFO[ptCi->gnbNum].cfg;

    const bool independentGapConfig = ((TRUE == ptCi->ueInfo.ueCapa.mrdc.independentGapConfig_support) &&
                                       (VCCB_FLAG_ON == pGnbCfg->measGap.indepGapEnabledEndc) &&
                                       (false == VCCB_CheckMnForcedPerUeGapsForSn(ptCi)));
    const bool isMoFr2 = ((measRatNr == ptUeMeasObj->conf.ratType) &&
                          (MIN_A6_NR_ARFCN <= ptUeMeasObj->conf.rat.nr.minimal.ssbFrequency));
    int16_t result = GOOD;

    // 3GPP 38.133 table 9.1.2-2
    if ((false == independentGapConfig) || (false == isMoFr2) || ((true == isMoFr2) && (true == srvCellNrFr2)))
    {
        // gap required
        result = BREAK;
    }
    // else, no gap

    if (measRatNr == ptUeMeasObj->conf.ratType)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "[m-gap][ENDC] gap required(%u) for MO NR ssbArfcn(%u), indepGapCfg(%u), servCells: FR2(%u).\n",
            GOOD != result, ptUeMeasObj->conf.rat.nr.minimal.ssbFrequency, independentGapConfig, srvCellNrFr2);
    }
    else
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "[m-gap][ENDC] gap required(%u) for MO EUTRA earfcn(%u), indepGapCfg(%u), servCells: FR2(%u).\n",
            GOOD != result, ptUeMeasObj->conf.rat.eutra.minimal.overlappedCarrierFreq, independentGapConfig,
            srvCellNrFr2);
    }

    return result;
}

/****************************************************************************
 * @brief    Local structure for Serving Cell information
 ****************************************************************************/
class VCCB_ServingCellData
{
public:
    VCCB_ServingCellData() : _srvCellNrFr1(false), _srvCellNrFr2(false), _srvCellEutra(false){};

protected:
    bool _srvCellNrFr1, _srvCellNrFr2, _srvCellEutra;
    void VCCB_FillServingCellFrs(callInfo_type *ptCi);
};

/****************************************************************************
 * @brief    Local structure for measurement identities removal from newItems
 ****************************************************************************/
class VCCB_MeasIdsRemover
{
protected:
    typedef struct MeasIdentityToRemove_s
    {
        uint8_t miIdx;
        uint8_t moIdx;
        uint8_t rptIdx;
    } measIdentityToRemove_type;

    VCCB_MeasIdsRemover() : _moIdxRefCnt{}, _rptIdxRefCnt{} {};

    uint8_t VCCB_PrepareMeasIdListToRemove(
        callInfo_type *ptCi, measIdentityToRemove_type measIdToRemList[MAX_NR_OF_MEAS_ID]);
    void VCCB_RemoveFromNewItems(callInfo_type *ptCi,
        const measIdentityToRemove_type measIdToRemList[MAX_NR_OF_MEAS_ID], const uint8_t measIdToRemNum);
    virtual bool VCCB_IsMeasIdToBeRemoved(callInfo_type *ptCi, const VccbGnbInfo_type &rGnb, const uint8_t miIdx) = 0;

private:
    void VCCB_CountReferencesForServingCells(callInfo_type *ptCi);

    uint8_t _moIdxRefCnt[MAX_NR_OF_OBJECT_ID];
    uint8_t _rptIdxRefCnt[MAX_NR_OF_REPORT_CONFIG_ID];
};

/****************************************************************************
 * @brief    Local structure for common periodic measurements information
 ****************************************************************************/
class VCCB_PeriodicMeasDataCommon : public VCCB_ServingCellData, public VCCB_MeasIdsRemover
{
public:
    enum NeedGap : uint8_t
    {
        NeedGap_unknown = 0,
        NeedGap_true,
        NeedGap_false,
    };

    VCCB_PeriodicMeasDataCommon() : _moIdxNeedGap{} {};
    uint8_t VCCB_FindAndRemoveMeasurements(
        callInfo_type *ptCi, measurementsConfigShared_type::s_PeriodicMeasurement_type &rPm);

protected:
    NeedGap _moIdxNeedGap[MAX_NR_OF_OBJECT_ID];

    void VCCB_SetServingCellMoNeedGap(callInfo_type *ptCi);
    bool VCCB_CheckMeasObjectNeedGap(callInfo_type *ptCi, const uint8_t measObjIdx);
    bool VCCB_CheckCpuOverloadCommon(const uint8_t overloadThreshold) const;
    bool VCCB_CheckCpuOverloadSa() const;
    bool VCCB_CheckCpuOverloadEndc() const;
};

/****************************************************************************
 * @brief    Local structure for periodic A4 measurements information
 ****************************************************************************/
class VCCB_PeriodicA4MeasData : public VCCB_PeriodicMeasDataCommon
{
public:
    VCCB_PeriodicA4MeasData() : _allMoSwitch{false} {};
    bool VCCB_CheckEnable(callInfo_type *ptCi);

protected:
    bool _allMoSwitch;

    bool VCCB_IsMeasIdToBeRemoved(callInfo_type *ptCi, const VccbGnbInfo_type &rGnb, const uint8_t miIdx) override;
};

/****************************************************************************
 * @brief    Local structure for long periodic measurements information
 ****************************************************************************/
class VCCB_LongPeriodicMeasData : public VCCB_PeriodicMeasDataCommon
{
public:
    enum LpmPurpose
    {
        LpmPurpose_scellAddition        = 0x01,
        LpmPurpose_PcellPriorHandover   = 0x02,
        LpmPurpose_SpidPrioPSCellChange = 0x04,
    };

    VCCB_LongPeriodicMeasData() : _purposeMask(0), _spidScellAdd(false) {};
    inline uint8_t VCCB_GetPurposeMask() const { return _purposeMask; };
    uint8_t VCCB_GetReportPurposeMaskIfEnabled(callInfo_type &rCi, const longPeriodicMeas_type &rCfgLpm,
        const reportConfigurationConfUe_type &rUeRptCfg) const;
    bool VCCB_CheckEnable(callInfo_type *ptCi);

protected:
    uint8_t _purposeMask;
    bool _spidScellAdd; // ENDC only

    bool VCCB_IsMeasIdToBeRemoved(callInfo_type *ptCi, const VccbGnbInfo_type &rGnb, const uint8_t miIdx) override;
};

/****************************************************************************
 * @brief   Set internally if serving cell MOs need m-gap.
            It considers only MCG cells for SA, MN-NRDC, MN-NEDC.
            It considers only SCG cells for ENDC, SN-NRDC.
 * @param   ptCi    : pointer to UE Context
 ****************************************************************************/
void VCCB_PeriodicMeasDataCommon::VCCB_SetServingCellMoNeedGap(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    // Check serving cells MO Idx
    if (VCCB_ARRAY_COUNT(_moIdxNeedGap) > rMeasProc.tgtCellNewMoIdx)
    {
        _moIdxNeedGap[rMeasProc.tgtCellNewMoIdx] = NeedGap_false;
    }
    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (const scellInfo_type &rScell : scells)
    {
        if (SCELL_STATE_ADDED != rScell.state)
        {
            continue;
        }

        if (VCCB_ARRAY_COUNT(_moIdxNeedGap) > rScell.newMoIdx)
        {
            _moIdxNeedGap[rScell.newMoIdx] = NeedGap_false;
        }
    }
}

/****************************************************************************
 * @brief   Check if MeasObject needs m-gap.
 *          Note: Supports SA only/ENDC operation.
 ****************************************************************************/
bool VCCB_PeriodicMeasDataCommon::VCCB_CheckMeasObjectNeedGap(callInfo_type *ptCi, const uint8_t measObjIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    VCCB_CHECK_E_RANGE_AND_VAL(measObjIdx, MIN(rMeasProc.measurementObjects.numNewItems, MAX_NR_OF_OBJECT_ID), false);
    const measurementObjectUe_type *ptUeMeasObj = &rMeasProc.measurementObjects.newItems[measObjIdx];

    if (NeedGap_true == _moIdxNeedGap[measObjIdx])
    {
        return true;
    }
    else if (NeedGap_false == _moIdxNeedGap[measObjIdx])
    {
        return false;
    }

    // Only non serving freq MO left unchecked.
    if (E_CALLTYPE_NSA == ptCi->callType)
    {
        if (GOOD == VCCB_CheckMeasObjectNonServFreqNoNeedGapENDC(ptCi, ptUeMeasObj, _srvCellNrFr2))
        {
            _moIdxNeedGap[measObjIdx] = NeedGap_false;
            return false;
        }
    }
    else
    {
        if (GOOD == VCCB_CheckMeasObjectNonServFreqNoNeedGapSA(ptCi, ptUeMeasObj, _srvCellNrFr1, _srvCellNrFr2))
        {
            _moIdxNeedGap[measObjIdx] = NeedGap_false;
            return false;
        }
    }

    _moIdxNeedGap[measObjIdx] = NeedGap_true;
    return true;
}

/****************************************************************************
 * @brief   Private function for counting MO references of serving cells.
 ****************************************************************************/
void VCCB_MeasIdsRemover::VCCB_CountReferencesForServingCells(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    if (MAX_NR_OF_OBJECT_ID > rMeasProc.tgtCellNewMoIdx)
    {
        _moIdxRefCnt[rMeasProc.tgtCellNewMoIdx]++;
    }
    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (uint16_t cellIdx = 0; cellIdx < MAX_SCELL_PER_CALL; cellIdx++)
    {
        if (SCELL_STATE_ADDED != scells[cellIdx].state)
        {
            continue;
        }

        if (MAX_NR_OF_OBJECT_ID > scells[cellIdx].newMoIdx)
        {
            _moIdxRefCnt[scells[cellIdx].newMoIdx]++;
        }
    }
}

/****************************************************************************
 * @brief   Function to be called by derived object.
 *          Prepares list of measurement identities to be removed based on conditions implemented by
 *VCCB_IsMeasIdToBeRemoved.
 ****************************************************************************/
uint8_t VCCB_MeasIdsRemover::VCCB_PrepareMeasIdListToRemove(
    callInfo_type *ptCi, measIdentityToRemove_type measIdToRemList[MAX_NR_OF_MEAS_ID])
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ZERO(ptCi);
    VALID_E_POINT_CHECK_ZERO(measIdToRemList);

    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, 0);
    const VccbGnbInfo_type &rGnb = GNBINFO[ptCi->gnbNum];

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    VCCB_CountReferencesForServingCells(ptCi);

    uint8_t measObjIdx = 0, rptCfgIdx = 0;
    measurementIdentity_type *ptUeMeasId = NULL;

    uint8_t measIdToRemCnt = 0;
    for (uint8_t miIdx = 0; miIdx < util::minOfArraySizeAndNumOfElems(rMeasProc.measurementIdentities.newItems,
                                        rMeasProc.measurementIdentities.numNewItems);
         ++miIdx)
    {
        ptUeMeasId = &rMeasProc.measurementIdentities.newItems[miIdx];
        if (CI_use != ptUeMeasId->usage)
        {
            continue;
        }

        if (INVALID_OBJECT_ID != ptUeMeasId->objectId)
        {
            // This MeasIdentity has already assigned ID - delayMeasConfForSaHoIn case.
            // In this case, the MeasIdentity cannot be removed. It will be processed after HO completion
            VCCB_PRINT_CALL_COMMENT(ptCi, "MeasId(%u) is delayed - cannot be removed\n", ptUeMeasId->objectId + 1);
            continue;
        }

        measObjIdx = ptUeMeasId->moNewItemIdx;
        rptCfgIdx = ptUeMeasId->rcNewItemIdx;

        if ((MIN(rMeasProc.measurementObjects.numNewItems, MAX_NR_OF_OBJECT_ID) <= measObjIdx) ||
            (MIN(rMeasProc.reportConfigurations.numNewItems, MAX_NR_OF_REPORT_CONFIG_ID) <= rptCfgIdx))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: Invalid measObjIdx(%u) or rptCfgIdx(%u)!\n", measObjIdx, rptCfgIdx);
            continue;
        }

        // count references for this measurement identity
        _moIdxRefCnt[measObjIdx]++;
        _rptIdxRefCnt[rptCfgIdx]++;

        if (false == VCCB_IsMeasIdToBeRemoved(ptCi, rGnb, miIdx))
        {
            continue;
        }

        measIdToRemList[measIdToRemCnt].miIdx = miIdx;
        measIdToRemList[measIdToRemCnt].moIdx = measObjIdx;
        measIdToRemList[measIdToRemCnt].rptIdx = rptCfgIdx;
        measIdToRemCnt++;
    }

    return measIdToRemCnt;
}

/****************************************************************************
 * @brief   Function to be called by derived object.
 *          Removes given measurement identities from newItems.
 *          Note1: Always call VCCB_PrepareMeasIdListToRemove first.
 *          Note2: Call this function before VCCB_ApplyNewMeasConfig.
 ****************************************************************************/
void VCCB_MeasIdsRemover::VCCB_RemoveFromNewItems(callInfo_type *ptCi,
    const measIdentityToRemove_type measIdToRemList[MAX_NR_OF_MEAS_ID], const uint8_t measIdToRemNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(measIdToRemList);

    if (0 == measIdToRemNum)
    {
        return;
    }

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);
    measurementIdentity_type *ptUeMeasId = NULL;

    uint8_t moIdxMap[MAX_NR_OF_OBJECT_ID];
    uint8_t rptIdxMap[MAX_NR_OF_REPORT_CONFIG_ID];

    for (uint8_t miIdx = 0; miIdx < measIdToRemNum; ++miIdx)
    {
        ptUeMeasId = &rMeasProc.measurementIdentities.newItems[measIdToRemList[miIdx].miIdx];

        _moIdxRefCnt[measIdToRemList[miIdx].moIdx]--;
        _rptIdxRefCnt[measIdToRemList[miIdx].rptIdx]--;
        ptUeMeasId->usage = CI_no_use;
    }

    VCCB_RemoveUnusedNewItems<measurementObjectUe_type>(
        rMeasProc.measurementObjects, MAX_NR_OF_OBJECT_ID, _moIdxRefCnt, moIdxMap);
    // moIdxRefCnt_ is invalid since now

    VCCB_RemoveUnusedNewItems<reportConfigurationNewUe_type>(
        rMeasProc.reportConfigurations, MAX_NR_OF_REPORT_CONFIG_ID, _rptIdxRefCnt, rptIdxMap);
    // rptIdxRefCnt_ is invalid since now

    auto lastMI = std::remove_if(rMeasProc.measurementIdentities.newItems,
        rMeasProc.measurementIdentities.newItems + MIN(MAX_NR_OF_MEAS_ID, rMeasProc.measurementIdentities.numNewItems),
        [](const measurementIdentity_type &mi) { return (CI_use != mi.usage); });
    rMeasProc.measurementIdentities.numNewItems = static_cast<uint8_t>(lastMI - rMeasProc.measurementIdentities.newItems);
    // measIdToRemList is invalid since now

    // re-map indices for MeasIds
    for (uint8_t loop = 0; loop < util::minOfArraySizeAndNumOfElems(rMeasProc.measurementIdentities.newItems,
                                      rMeasProc.measurementIdentities.numNewItems);
         loop++)
    {
        ptUeMeasId = &rMeasProc.measurementIdentities.newItems[loop];

        if ((CI_use != ptUeMeasId->usage) || (INVALID_OBJECT_ID != ptUeMeasId->objectId))
        {
            continue;
        }

        if (VCCB_ARRAY_COUNT(moIdxMap) > ptUeMeasId->moNewItemIdx)
        {
            ptUeMeasId->moNewItemIdx = moIdxMap[ptUeMeasId->moNewItemIdx];
        }
        if (MAX_NR_OF_REPORT_CONFIG_ID > ptUeMeasId->rcNewItemIdx)
        {
            ptUeMeasId->rcNewItemIdx = rptIdxMap[ptUeMeasId->rcNewItemIdx];
        }
    }

    // re-map index for PCell
    if (VCCB_ARRAY_COUNT(moIdxMap) > rMeasProc.tgtCellNewMoIdx)
    {
        rMeasProc.tgtCellNewMoIdx = moIdxMap[rMeasProc.tgtCellNewMoIdx];
    }

    // re-map indices for SCells
    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (scellInfo_type &rSCell : scells)
    {
        if (SCELL_STATE_ADDED != rSCell.state)
        {
            continue;
        }

        if (VCCB_ARRAY_COUNT(moIdxMap) > rSCell.newMoIdx)
        {
            rSCell.newMoIdx = moIdxMap[rSCell.newMoIdx] & 0x1F;
        }
    }

    // clear unused MeasIds
    for (uint8_t loop = rMeasProc.measurementIdentities.numNewItems; loop < MAX_NR_OF_MEAS_ID; loop++)
    {
        ptUeMeasId = &rMeasProc.measurementIdentities.newItems[loop];
        ptUeMeasId->usage = CI_no_use;
    }
}

/****************************************************************************
 * @brief   Function implements measurement identity removal condition for PA4M feature.
 ****************************************************************************/
bool VCCB_PeriodicA4MeasData::VCCB_IsMeasIdToBeRemoved(
    callInfo_type *ptCi, const VccbGnbInfo_type &rGnb, const uint8_t miIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    const periodicA4Meas_type &rPa4mGnbCfg = rGnb.cfg.periodicA4Measurement;

    VCCB_CHECK_E_RANGE_AND_FALSE(miIdx, util::minOfArraySizeAndNumOfElems(rMeasProc.measurementIdentities.newItems,
                                            rMeasProc.measurementIdentities.numNewItems));
    const measurementIdentity_type *ptUeMeasId = &rMeasProc.measurementIdentities.newItems[miIdx];

    const uint8_t measObjIdx = ptUeMeasId->moNewItemIdx;
    const uint8_t rptCfgIdx = ptUeMeasId->rcNewItemIdx;

    VCCB_CHECK_E_RANGE_AND_VAL(measObjIdx, MIN(rMeasProc.measurementObjects.numNewItems, MAX_NR_OF_OBJECT_ID), false);
    VCCB_CHECK_E_RANGE_AND_VAL(
        rptCfgIdx, MIN(rMeasProc.reportConfigurations.numNewItems, MAX_NR_OF_REPORT_CONFIG_ID), false);

    const measurementObjectConfUe_type *ptUeMeasObjConf = &rMeasProc.measurementObjects.newItems[measObjIdx].conf;
    const reportConfigurationConfUe_type *ptUeRptCfg = &rMeasProc.reportConfigurations.newItems[rptCfgIdx].conf;

    if ((measReport_A4 != ptUeRptCfg->reportType) ||
        ((false == _allMoSwitch) &&
            ((a4Purpose_NrdcAddition != ptUeRptCfg->reportPurpose) ||
                (VCCB_FLAG_OFF == rPa4mGnbCfg.snAdditionPurposeEnabled)) &&
            ((E_CALLTYPE_SA != ptCi->callType) || (a4Purpose_scellAddition != ptUeRptCfg->reportPurpose) ||
                (VCCB_FLAG_OFF == rPa4mGnbCfg.caScellAdditionPurposeEnabled))))
    {
        return false;
    }

    // Check need for gap
    if (false == VCCB_CheckMeasObjectNeedGap(ptCi, measObjIdx))
    {
        return false;
    }

    VCCB_PRINT_CALL_COMMENT(ptCi,
        "[PA4M] A4 need m-gap MeasId: idx(%u), Rpt: idx(%u) pur(%u), MO: idx(%u) bandNR(%u)\n", miIdx, rptCfgIdx,
        ptUeRptCfg->reportPurpose, measObjIdx,
        (measRatNr == ptUeMeasObjConf->ratType) ? ptUeMeasObjConf->rat.nr.minimal.freqBandIndicatorNR : 0);

    return true;
}

/****************************************************************************
 * @brief   Checks if measurement report is enabled for LPM feature, then return purpose mask.
 ****************************************************************************/
uint8_t VCCB_LongPeriodicMeasData::VCCB_GetReportPurposeMaskIfEnabled(callInfo_type &rCi, const longPeriodicMeas_type &rCfgLpm,
    const reportConfigurationConfUe_type &rUeRptCfg) const
{
    AUTO_TRACE_FUNC;

    switch (rUeRptCfg.reportType)
    {
        case measReport_A4:
            switch (rUeRptCfg.reportPurpose)
            {
                case a4Purpose_scellAddition:
                    return (_spidScellAdd || ((E_CALLTYPE_SA == rCi.callType) && (VCCB_FLAG_ON == rCfgLpm.scellAddEnabled))) ?
                        LpmPurpose_scellAddition : 0;

                case a4Purpose_PcellPriorHandover:
                    return (VCCB_FLAG_ON == rCfgLpm.saFphoPurposeA4Enabled) ? LpmPurpose_PcellPriorHandover : 0;

                case a4Purpose_SpidPrioPSCellChange:
                    return (VCCB_FLAG_ON == rCfgLpm.endcSpidInterFHoA4Enabled) ? LpmPurpose_SpidPrioPSCellChange : 0;

                default:
                    break;
            }
            break;

        case measReport_A5:
            switch (rUeRptCfg.reportPurpose)
            {
                case a5Purpose_PcellPriorHandover:
                    return (VCCB_FLAG_ON == rCfgLpm.saFphoPurposeA5Enabled) ? LpmPurpose_PcellPriorHandover : 0;

                case a5Purpose_SpidPrioPSCellChange:
                    return (VCCB_FLAG_ON == rCfgLpm.endcSpidInterFHoA5Enabled) ? LpmPurpose_SpidPrioPSCellChange : 0;

                default:
                    break;
            }
            break;

        default:
            break;
    }

    return 0;
}

/****************************************************************************
 * @brief   Function implements measurement identity removal condition for LPM feature.
 ****************************************************************************/
bool VCCB_LongPeriodicMeasData::VCCB_IsMeasIdToBeRemoved(
    callInfo_type *ptCi, const VccbGnbInfo_type &rGnb, const uint8_t miIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    const longPeriodicMeas_type &rCfgLpm = rGnb.cfg.longPeriodicMeas;

    VCCB_CHECK_E_RANGE_AND_FALSE(miIdx, util::minOfArraySizeAndNumOfElems(rMeasProc.measurementIdentities.newItems,
                                            rMeasProc.measurementIdentities.numNewItems));
    const measurementIdentity_type *ptUeMeasId = &rMeasProc.measurementIdentities.newItems[miIdx];

    const uint8_t measObjIdx = ptUeMeasId->moNewItemIdx;
    const uint8_t rptCfgIdx = ptUeMeasId->rcNewItemIdx;

    VCCB_CHECK_E_RANGE_AND_VAL(measObjIdx, MIN(rMeasProc.measurementObjects.numNewItems, MAX_NR_OF_OBJECT_ID), false);
    VCCB_CHECK_E_RANGE_AND_VAL(
        rptCfgIdx, MIN(rMeasProc.reportConfigurations.numNewItems, MAX_NR_OF_REPORT_CONFIG_ID), false);

    const measurementObjectConfUe_type *ptUeMeasObjConf = &rMeasProc.measurementObjects.newItems[measObjIdx].conf;
    const reportConfigurationConfUe_type *ptUeRptCfg = &rMeasProc.reportConfigurations.newItems[rptCfgIdx].conf;

    const uint8_t repPurposeMask = VCCB_GetReportPurposeMaskIfEnabled(*ptCi, rCfgLpm, *ptUeRptCfg);
    if (0 == repPurposeMask)
    {
        return false;
    }

    // Check need for gap
    if (false == VCCB_CheckMeasObjectNeedGap(ptCi, measObjIdx))
    {
        return false;
    }

    VCCB_PRINT_CALL_COMMENT(ptCi,
        "[LPM] A%u need m-gap MId:idx(%u) Rpt:idx(%u)/pur(%u) MO:idx(%u)/band(%u) Pur(0x%x)\n", ptUeRptCfg->reportType,
        miIdx, rptCfgIdx, ptUeRptCfg->reportPurpose, measObjIdx,
        (measRatNr == ptUeMeasObjConf->ratType) ? ptUeMeasObjConf->rat.nr.minimal.freqBandIndicatorNR : 0, repPurposeMask);

    _purposeMask |= repPurposeMask;

    return true;
}

/****************************************************************************
 * @brief           Private function for removing measurement objects, reports and identities
                    for not used items or items which should be uninstalled.
                    This is a helper function for FnVCCB_PostProcessMeasurements.
                    Note: Call this function before VCCB_ApplyNewMeasConfig.
 * @param[in,out]   ptCi :          call information
 ****************************************************************************/
uint8_t VCCB_PeriodicMeasDataCommon::VCCB_FindAndRemoveMeasurements(
    callInfo_type *ptCi, measurementsConfigShared_type::s_PeriodicMeasurement_type &rPm)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ZERO(ptCi);

    VCCB_FillServingCellFrs(ptCi);
    VCCB_SetServingCellMoNeedGap(ptCi);

    uint8_t miIdxCnt = 0;
    measIdentityToRemove_type miIdxList[MAX_NR_OF_MEAS_ID];
    memset(miIdxList, 0, sizeof(miIdxList));

    // Check periodic MeasIdentities
    miIdxCnt = VCCB_PrepareMeasIdListToRemove(ptCi, miIdxList);

    // Extract periodic MeasIdentities from newItems
    if ((miIdxCnt > 0) && ((PeriodicMeasState_Inactive == rPm.state) || (PeriodicMeasState_InactiveIdle == rPm.state)))
    {
        VCCB_RemoveFromNewItems(ptCi, miIdxList, miIdxCnt);
    }
    return miIdxCnt;
}

/****************************************************************************
 * @brief           Check if periodic A4 measurements are enabled for the UE
 * @param[in]       ptCi :          call information
 * @return bool          : true(enabled) / false(disabled)
 ****************************************************************************/
bool VCCB_PeriodicA4MeasData::VCCB_CheckEnable(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);
    const periodicA4Meas_type &rPa4mGnbCfg = GNBINFO[ptCi->gnbNum].cfg.periodicA4Measurement;

    uint8_t servPlmnIdx = 0;
    _allMoSwitch = false;

    if ((IsAvailable_MrdcInfo() && IS_NOT_MRDC_SCG_RELEASE_ONGOING(ptCi)))
    {
        return false;
    }

    if ((E_CALLTYPE_SA == ptCi->callType) && VCCB_CheckCpuOverloadSa())
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[PA4M] CPU overloaded - disabling\n");
        return false;
    }

    if (VCCB_FLAG_ON == rPa4mGnbCfg.enabled)
    {
        _allMoSwitch = true;
        return true;
    }

    if ((E_CALLTYPE_SA == ptCi->callType) && (OPT_PRESENT == ptCi->ueInfo.rfsp.rfspPresent) &&
        (GOOD == VLIB_getMultipleGnbPlmnIndexInfo(ptCi, &servPlmnIdx, ptCi->ueInfo.servedPlmn.longId)) &&
        (MAX_PLMN_INDEX > servPlmnIdx))
    {
        // SA with configured RFSP
        for (uint8_t rfspIdx = 0; MAX_RFSP_INDEX > rfspIdx; rfspIdx++)
        {
            const periodicMeasRfspBased &rRfspBased = rPa4mGnbCfg.rfspBased[servPlmnIdx][rfspIdx];

            if ((CI_use == rRfspBased.usage) && (rRfspBased.rfsp == ptCi->ueInfo.rfsp.subscriberProfile))
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "[PA4M] RFSP based PLMN idx(%u), RFSP val(%u) idx(%u) enabled(%u)\n",
                    servPlmnIdx, ptCi->ueInfo.rfsp.subscriberProfile, rfspIdx, rRfspBased.enabled);
                if (TRUE == rRfspBased.enabled)
                {
                    _allMoSwitch = true;
                    return true;
                }
                break;
            }
        }
    }

    if ((E_CALLTYPE_SA == ptCi->callType) && ((VCCB_FLAG_ON == rPa4mGnbCfg.snAdditionPurposeEnabled) ||
                                                 (VCCB_FLAG_ON == rPa4mGnbCfg.caScellAdditionPurposeEnabled)))
    {
        return true;
    }

    return false;
}

/****************************************************************************
 * @brief           Check if long periodic measurements are enabled for the UE
 * @param[in]       ptCi :          call information
 * @return bool          : true(enabled) / false(disabled)
 ****************************************************************************/
bool VCCB_LongPeriodicMeasData::VCCB_CheckEnable(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);
    const longPeriodicMeas_type &rCfgLpm = GNBINFO[ptCi->gnbNum].cfg.longPeriodicMeas;

    if (E_CALLTYPE_SA == ptCi->callType)
    {
        if (VCCB_CheckCpuOverloadSa())
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[LPM] CPU overloaded - disabling\n");
            return false;
        }

        if (rCfgLpm.rfspBasedFeatureEnabled)
        {
            if (OPT_PRESENT != ptCi->ueInfo.rfsp.rfspPresent)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "[LPM] UE without RFSP - disabling\n");
                return false;
            }

            uint8_t servPlmnIdx = MAX_PLMN_INDEX;
            if ((GOOD != VLIB_getMultipleGnbPlmnIndexInfo(ptCi, &servPlmnIdx, ptCi->ueInfo.servedPlmn.longId)) ||
                (MAX_PLMN_INDEX <= servPlmnIdx))
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "[LPM] Unable to get servPlmnIdx - disabling\n");
                return false;
            }

            uint8_t rfspIdx = 0;
            for (; MAX_RFSP_INDEX > rfspIdx; rfspIdx++)
            {
                const periodicMeasRfspBased &rRfspBased = rCfgLpm.rfspBased[servPlmnIdx][rfspIdx];

                if ((CI_use == rRfspBased.usage) && (rRfspBased.rfsp == ptCi->ueInfo.rfsp.indexToRFSP))
                {
                    VCCB_PRINT_CALL_COMMENT(ptCi, "[LPM] RFSP based PLMN idx(%u), RFSP val(%u) idx(%u) found\n",
                        servPlmnIdx, ptCi->ueInfo.rfsp.subscriberProfile, rfspIdx);
                    break;
                }
            }
            if (MAX_RFSP_INDEX <= rfspIdx)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "[LPM] RFSP based PLMN idx(%u), RFSP val(%u) not found - disabling\n",
                    servPlmnIdx, ptCi->ueInfo.rfsp.subscriberProfile);
                return false;
            }
        }

        if ((VCCB_FLAG_OFF == rCfgLpm.saFphoPurposeA4Enabled) &&
            (VCCB_FLAG_OFF == rCfgLpm.saFphoPurposeA5Enabled) &&
            (VCCB_FLAG_OFF == rCfgLpm.scellAddEnabled))
        {
            return false;
        }
    }
    else  // if ((E_CALLTYPE_SA != ptCi->callType)
    {
        uint16_t spidIdx = FnVCCB_GetSpidIdx(ptCi);
        _spidScellAdd =
            ((VCCB_FLAG_ON == rCfgLpm.endcSpidScellAddEnabled) &&
            (OPT_PRESENT == ptCi->ueInfo.rfsp.rfspPresent) &&
            (spidIdx < MAX_SPID_VALUE) &&
            GETBIT_U8TABLE(rCfgLpm.endcSpidScellAddList, spidIdx));

        if ((VCCB_FLAG_OFF == rCfgLpm.endcSpidInterFHoA4Enabled) &&
            (VCCB_FLAG_OFF == rCfgLpm.endcSpidInterFHoA5Enabled) &&
            (false == _spidScellAdd))
        {
            return false;
        }

        if (VCCB_CheckCpuOverloadEndc())
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[LPM] CPU overloaded - disabling\n");
            return false;
        }
    }

    return true;
}

/****************************************************************************
 * @brief       Check if CPU overload status exceed overload threshold.
 * @param[in]   overloadThreshold : overload threshold
 * @return      bool : true(overloaded) / false(normal)
 ****************************************************************************/
bool VCCB_PeriodicMeasDataCommon::VCCB_CheckCpuOverloadCommon(const uint8_t overloadThreshold) const
{
    AUTO_TRACE_FUNC;

    const VccbCfgInfo_type *const pCfg = CFG;

    return ((VCCB_FLAG_ON ==
                static_cast<enumVccbFlag>(pCfg->overloadControl.ueSigCpuOverloadControl.ueSigCpuOverloadAction)) &&
            (CpuOverloadCtrl_noControl != static_cast<enumCpuOverloadCtrlLevel_type>(overloadThreshold)) &&
            (indeterminate != static_cast<AlarmPerceivedSeverity>(pCfg->overloadStatus)) &&
            (pCfg->overloadStatus <= overloadThreshold));
}

/****************************************************************************
 * @brief       Check if CPU overload status exceed periodic measurements control threshold (PA4M/LPM) for SA/NRDC.
 * @return bool      : true(overloaded) / false(normal)
 ****************************************************************************/
bool VCCB_PeriodicMeasDataCommon::VCCB_CheckCpuOverloadSa() const
{
    AUTO_TRACE_FUNC;
    const VccbCfgInfo_type *const pCfg = CFG;
    return VCCB_CheckCpuOverloadCommon(pCfg->overloadControl.ueSigCpuOverloadControl.pa4mOverloadThreshold);
}

/****************************************************************************
 * @brief       Check if CPU overload status exceed periodic measurements control threshold (LPM) for ENDC.
 * @return bool      : true(overloaded) / false(normal)
 ****************************************************************************/
bool VCCB_PeriodicMeasDataCommon::VCCB_CheckCpuOverloadEndc() const
{
    AUTO_TRACE_FUNC;
    const VccbCfgInfo_type *const pCfg = CFG;
    return VCCB_CheckCpuOverloadCommon(pCfg->overloadControl.ueSigCpuOverloadControl.lpmEndcOverloadThreshold);
}

/****************************************************************************
 * @brief           Post process Measurement Configuration for periodic A4 measurements
 * @param[in,out]   ptCi :          call information
 ****************************************************************************/
void VCCB_PostProcessMeasurementsForPa4m(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    measurementsConfigShared_type::s_PeriodicMeasurement_type &pa4m = ptCi->measurementsConfigShared.pa4m;
    measurementsConfigShared_type::s_AlternateMeasGap_type &altgap = ptCi->measurementsConfigShared.altgap;
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    VCCB_PeriodicA4MeasData pa4mData;

    if (false == pa4mData.VCCB_CheckEnable(ptCi))
    {
        if (PeriodicMeasState_Idle != pa4m.state)
        {
            SET_PA4M_STATE(ptCi, PeriodicMeasState_Idle);
            VCCB_CLEAR_TIMER(&pa4m.timer, CANCEL_TIMER);
        }
        return;
    }

    const uint8_t a4mgapMiCnt = pa4mData.VCCB_FindAndRemoveMeasurements(ptCi, pa4m);
    VCCB_PRINT_CALL_COMMENT(ptCi, "[PA4M] Need m-gap MeasId count(%u)+agg(%u) in state(%u)\n",
        a4mgapMiCnt, rMeasProc.pa4mAggregatedPerMiCnt, pa4m.state);
    rMeasProc.pa4mAggregatedPerMiCnt = static_cast<uint8_t>(rMeasProc.pa4mAggregatedPerMiCnt + a4mgapMiCnt);

    // Set state
    switch (pa4m.state)
    {
        case PeriodicMeasState_Idle:
            if (0 < rMeasProc.pa4mAggregatedPerMiCnt)
            {
                SET_PA4M_STATE(ptCi, PeriodicMeasState_Active);
                pa4m.needRestartTimerFlag = VCCB_FLAG_ON;
                if (AltGapStateWithoutPa4m_Idle != altgap.stateWithoutPa4m)
                {
                    SET_ALTGAP_STATE(ptCi, AltGapStateWithoutPa4m_Idle);
                    VCCB_CLEAR_TIMER(&altgap.timer, CANCEL_TIMER);
                }
            }
            break;

        case PeriodicMeasState_Active:
            if (0 == rMeasProc.pa4mAggregatedPerMiCnt)
            {
                SET_PA4M_STATE(ptCi, PeriodicMeasState_ActiveIdle);
            }
            break;

        case PeriodicMeasState_ActiveIdle:
            if (0 < rMeasProc.pa4mAggregatedPerMiCnt)
            {
                SET_PA4M_STATE(ptCi, PeriodicMeasState_Active);
            }
            break;

        case PeriodicMeasState_Inactive:
            if (0 == rMeasProc.pa4mAggregatedPerMiCnt)
            {
                SET_PA4M_STATE(ptCi, PeriodicMeasState_InactiveIdle);
            }
            break;

        case PeriodicMeasState_InactiveIdle:
            if (0 < rMeasProc.pa4mAggregatedPerMiCnt)
            {
                SET_PA4M_STATE(ptCi, PeriodicMeasState_Inactive);
            }
            break;
        default:
            break;
    }
}

/****************************************************************************
 * @brief           Post process Measurement Configuration for long periodic measurements
 * @param[in,out]   ptCi :          call information
 ****************************************************************************/
void VCCB_PostProcessMeasurementsForLpm(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    measurementsConfigShared_type &rMeasConfShared = ptCi->measurementsConfigShared;
    measurementsConfigShared_type::s_PeriodicMeasurement_type &rLpm = rMeasConfShared.lpm;
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    VCCB_LongPeriodicMeasData lpmData;

    if (false == lpmData.VCCB_CheckEnable(ptCi))
    {
        if (PeriodicMeasState_Idle != rLpm.state)
        {
            SET_LPM_STATE(ptCi, PeriodicMeasState_Idle);
            VCCB_CLEAR_TIMER(&rLpm.timer, CANCEL_TIMER);
        }
        return;
    }

    const uint8_t perMiCnt = lpmData.VCCB_FindAndRemoveMeasurements(ptCi, rLpm);
    VCCB_PRINT_CALL_COMMENT(ptCi, "[LPM] Need m-gap MeasId count(%u) pur(0x%x)|agg(0x%x) in state(%u)\n",
        perMiCnt, lpmData.VCCB_GetPurposeMask(), rMeasProc.lpmPurposeMask, rLpm.state);
    rMeasProc.lpmPurposeMask = rMeasProc.lpmPurposeMask | lpmData.VCCB_GetPurposeMask();

    // Set state
    switch (rLpm.state)
    {
        case PeriodicMeasState_Idle:
            if (0 != rMeasProc.lpmPurposeMask)
            {
                SET_LPM_STATE(ptCi, PeriodicMeasState_Active);
                rLpm.needRestartTimerFlag = VCCB_FLAG_ON;
            }
            break;

        case PeriodicMeasState_Active:
            if (0 == rMeasProc.lpmPurposeMask)
            {
                SET_LPM_STATE(ptCi, PeriodicMeasState_ActiveIdle);
            }
            break;

        case PeriodicMeasState_ActiveIdle:
            if (0 != rMeasProc.lpmPurposeMask)
            {
                SET_LPM_STATE(ptCi, PeriodicMeasState_Active);
            }
            break;

        case PeriodicMeasState_Inactive:
            if (0 == rMeasProc.lpmPurposeMask)
            {
                SET_LPM_STATE(ptCi, PeriodicMeasState_InactiveIdle);
            }
            break;

        case PeriodicMeasState_InactiveIdle:
            if (0 != rMeasProc.lpmPurposeMask)
            {
                SET_LPM_STATE(ptCi, PeriodicMeasState_Inactive);
            }
            break;

        default:
            break;
    }
}

/****************************************************************************
 * @brief           Used when additional processing is required after the 'VCCB_ClearNewMeasConfig' function.
 *
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
VCCB_STATIC_INLINE
void FnVCCB_PostProcessClearNewMeasConfig(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // Conditional Cell Meas Configuration
    FnVCCB_ClearChoNewMeasConfig(ptCi);
}

/****************************************************************************
 * @brief           Used when additional processing is required after the 'VCCM_PrepareMeasurmentConfig' function.
 *
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
VCCB_STATIC_INLINE
void FnVCCB_PostProcessMeasurements(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    VCCB_PostProcessMeasurementsForPa4m(ptCi);
    VCCB_PostProcessMeasurementsForLpm(ptCi);
}

/****************************************************************************
 * @brief           Used when additional processing is required after the 'VCCB_ApplyNewMeasConfig' function.
 *
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
VCCB_STATIC_INLINE
void FnVCCB_PostProcessApplyNewMeasConfig(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (FnVCCB_IsSetupedConditionalCell(ptCi))
    {
        FnVCCB_PostProcessApplyNewMeasConfigForCho(ptCi);
    }
}

/****************************************************************************
 * @brief           Prepares the new measurement configuration.
 *
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_PrepareNewMeasConfig(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    ScopedCachedNbrSmtc1PerFreq scopedCachedNbrSmtc1PerFreq(*ptCi);

    // do not clear items to remove (in case src config items to remove)
    VCCB_ClearNewMeasConfig(*ptCi, VCCB_FLAG_OFF);
    FnVCCB_PostProcessClearNewMeasConfig(ptCi);

    // If there is no UE context on DU and only MCG SN bearers clear measurementsConfiguration. Whole SCG config will be
    // uninstalled from UE.
    if (IS_ENDC_SCG_TO_RELEASE(ptCi))
    {
        VLIB_InitMeasurementsStructs(ptCi);
        VCCM_InitNsaMeasData(ptCi);

        // trigger m-gap release if required.
        if (0 != ptCi->measurementsConfigShared.mGapConfiguration.freqSnInstalled.numItems)
        {
            ptCi->measurementsConfigShared.mGapConfiguration.mGapMnCtrlState = MGAPReleasePending;
        }

        VCCB_PRINT_CALL_COMMENT(
            ptCi, "VCCB_PrepareNewMeasConfig: No SCG resource, skip preparing measurement configuration.\n");
        return GOOD;
    }

    VCCB_RETURN_ON_CALL_ERROR(ptCi, VCCM_PrepareMeasurmentConfig(ptCi), "VCCM_PrepareMeasurmentConfig ERROR!\n");
    FnVCCB_PostProcessMeasurements(ptCi);

    VCCB_RETURN_ON_CALL_ERROR(ptCi, VCCB_ApplyNewMeasConfig(ptCi), "VCCB_ApplyNewMeasConfig ERROR!\n");
    FnVCCB_PostProcessApplyNewMeasConfig(ptCi);

    FnVCCB_GetMeasurementsProcedure(*ptCi).measConfigReadyFlag = FLAG_ON;

    VCCB_DecideNeedForGapsConfig(ptCi);

    if ((E_CALLTYPE_SA == ptCi->callType) && (!IS_NRDC_SN(ptCi)))
    {
        VCCB_RETURN_ON_CALL_ERROR(ptCi, VCCB_DecideMeasGap(ptCi), "VCCB_DecideMeasGap ERROR!\n");
    }

    return GOOD;
}

int16_t VCCB_PrepareNewMeasConfigWithTaintedInstalledItems(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    if (VCCB_FLAG_ON == DBG->flag.taintMeasConfigAfterRRE)
    {
        if (VCCB_FLAG_ON == DBG->flag.removeAllMeasConfigIdsAfterRRE)
        {
            const uint64_t allIds = 0xFFFFFFFFFFFFFFFF;
            VCCB_PRINT_CALL_COMMENT(ptCi, "[clear-meas-conf] all measObjects will be removed.\n");
            rMeasProc.measurementObjects.foreignIdsToRemove = allIds;

            VCCB_PRINT_CALL_COMMENT(ptCi, "[clear-meas-conf] all reportConfigs will be removed.\n");
            rMeasProc.reportConfigurations.foreignIdsToRemove = allIds;

            // meas ids are not removed explicitly as they are removed automatically by UE
            // when either associated measObject or reportConfig is removed
        }

        taintAllInstalledMeasConfig(*ptCi);
    }

    return VCCB_PrepareNewMeasConfig(ptCi);
}

/****************************************************************************
 * @brief           Prepares the additional measurement configuration.
 *
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_PrepareAdditionalMeasConfig(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (MAX_CELL_NUM_VCCB <= FnVCCB_GetMeasurementsProcedure(*ptCi).tgtCellNum)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Measurements were not prepared!\n");

        return GOOD;
    }

    SvcGrpChangeProcedureControl svcGrpChangeProcedureControl(*ptCi);

    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, VCCM_PrepareAdditionalMeasurementConfig(ptCi), "VCCM_PrepareAdditionalMeasurementConfig ERROR!\n");
    VCCB_ClearReportConfigItemsState(ptCi);
    VCCB_ClearMeasIdentitiesItemsState(ptCi);
    FnVCCB_PostProcessMeasurements(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, VCCB_ApplyReportConfig(ptCi), "VCCB_ApplyReportConfig ERROR!\n");
    VCCB_RETURN_ON_CALL_ERROR(ptCi, VCCB_ApplyMeasIdentities(ptCi), "VCCB_ApplyMeasIdentities ERROR!\n");

    return GOOD;
}
/****************************************************************************
 * @brief           Checks if a meas id associated with
                    1. ReportConfig identified by reportType, reportPurpose pair
                    2. MeasObject identified by frequency (ssbArfcn or carrierFreq)
                    is currently installed on UE.

                    If frequency = UNKNOWN_ARFCN, function checks only for installed ReportConfig associated with MeasId

                    If meas id is installed returns true.
                    If meas id is not installed returns false.

 * @param[in]       rCi : Reference to call configuration. / callInfo_type&
 * @param[in]       reportType : ReportConfig's report type
 * @param[in]       reportPurpose : ReportConfig's report purpose
 * @param[in]       frequency : MeasObject's frequency (ssbArfcn or carrierFreq)
 * @return          bool
 ****************************************************************************/
bool VCCB_IsMeasIdInstalled(const callInfo_type &rCi, const enumMeasurementReportType reportType,
    const uint8_t reportPurpose, const Arfcn_type frequency)
{
    AUTO_TRACE_FUNC;

    // Map of measObjectId to an index to moInstalledItems.installedItems of corresponding element
    int moInstalledItemsIndexes[MAX_NR_OF_OBJECT_ID_3GPP] = {};
    // Map of reportConfigId to an index to rcInstalledItems.installedItems of corresponding element
    int rcInstalledItemsIndexes[MAX_NR_OF_REPORT_CONFIG_ID_3GPP] = {};

    // Fill arrays with -1 which indicates not installed meas config item for specific object id
    std::fill_n(moInstalledItemsIndexes, VCCB_ARRAY_COUNT(moInstalledItemsIndexes), -1);
    std::fill_n(rcInstalledItemsIndexes, VCCB_ARRAY_COUNT(rcInstalledItemsIndexes), -1);

    const measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(rCi);
    const auto &moInstalledItems = rMeasConf.measurementObjects;
    for (uint8_t moIdx = 0; moIdx < VCCB_ARRAY_COUNT(moInstalledItems.installedItems); ++moIdx)
    {
        const auto &item = moInstalledItems.installedItems[moIdx];
        if (CI_use != item.usage)
        {
            continue;
        }
        if (item.objectId >= VCCB_ARRAY_COUNT(moInstalledItemsIndexes))
        {
            VCCB_PRINT_CALL_ERROR(
                &rCi, "ERROR: measObjectId(%u) larger than size of moInstalledItemsIndexes array!\n", item.objectId);
            continue;
        }
        moInstalledItemsIndexes[item.objectId] = moIdx;
    }

    const auto &rcInstalledItems = rMeasConf.reportConfigurations;
    for (uint8_t rcIdx = 0; rcIdx < VCCB_ARRAY_COUNT(rcInstalledItems.installedItems); ++rcIdx)
    {
        const auto &item = rcInstalledItems.installedItems[rcIdx];
        if (CI_use != item.usage)
        {
            continue;
        }
        if (item.objectId >= VCCB_ARRAY_COUNT(rcInstalledItemsIndexes))
        {
            VCCB_PRINT_CALL_ERROR(
                &rCi, "ERROR: reportConfigId(%u) larger than size of rcInstalledItemsIndexes array!\n", item.objectId);
            continue;
        }
        rcInstalledItemsIndexes[item.objectId] = rcIdx;
    }

    auto isMoMatched = [&moInstalledItems](const Arfcn_type freq, const int moItemId)
    {
        if (freq == UNKNOWN_ARFCN) return true;

        const auto &installedMo = moInstalledItems.installedItems[moItemId];
        return freq == (installedMo.conf.ratType == measRatNr ? installedMo.conf.rat.nr.minimal.ssbFrequency
                                                              : installedMo.conf.rat.eutra.minimal.carrierFreq);
    };

    const auto &miInstalledItems = rMeasConf.measurementIdentities;
    for (const auto &mi : rangeAdaptors::filtered(
             miInstalledItems.installedItems, [](const measurementIdentity_type &x) { return x.usage == CI_use; }))
    {
        if (mi.measObjectId >= VCCB_ARRAY_COUNT(moInstalledItemsIndexes))
        {
            VCCB_PRINT_CALL_ERROR(&rCi,
                "ERROR: measObjectId(%u) under measId(%u) is larger than size of moInstalledItemsIndexes array!\n",
                mi.measObjectId, mi.objectId);
            continue;
        }
        if (mi.reportConfigId >= VCCB_ARRAY_COUNT(rcInstalledItemsIndexes))
        {
            VCCB_PRINT_CALL_ERROR(&rCi,
                "ERROR: reportConfigId(%u) under measId(%u) is larger than size of rcInstalledItemsIndexes array!\n",
                mi.reportConfigId, mi.objectId);
            continue;
        }

        // Pull items' indexes from arrays by indexes stored in meas id
        // If they are not installed, skip to the next meas id
        // If frequecy is unknown, set default meas object index to avoid loop continuation
        const int moItemIndex = moInstalledItemsIndexes[mi.measObjectId];
        const int rcItemIndex = rcInstalledItemsIndexes[mi.reportConfigId];

        if (moItemIndex == -1)
        {
            VCCB_PRINT_CALL_ERROR(
                &rCi, "ERROR: measObject(%u) under measId(%u) is not installed!\n", mi.measObjectId, mi.objectId);
            continue;
        }
        if (rcItemIndex == -1)
        {
            VCCB_PRINT_CALL_ERROR(
                &rCi, "ERROR: reportConfig(%u) under measId(%u) is not installed!\n", mi.reportConfigId, mi.objectId);
            continue;
        }

        const auto &installedRc = rcInstalledItems.installedItems[rcItemIndex];
        bool isRcMatched = installedRc.conf.reportType == reportType && installedRc.conf.reportPurpose == reportPurpose;

        if (isMoMatched(frequency, moItemIndex) && isRcMatched)
        {
            return true;
        }
    }

    return false;
}

/****************************************************************************
 * @brief           Checks if a measurement object with given frequency can
 *                  be configured on UE.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       frequency : Frequency of the target measurement object. / Arfcn_type/uint32_t
 * @param[in]       signalType : Type of signal to be measured. / enumRSType
 * @param[out]      result : Result of the check (GOOD, ERROR). / uint8_t*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_CheckIfMeasObjectNrCanBeAdded(
    callInfo_type *ptCi, CellNum_type tgtCellNum, Arfcn_type frequency, enumRSType signalType, int16_t *result)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(result);
    VCCB_CHECK_E_RANGE_AND_RETURN(tgtCellNum, MAX_CELL_NUM_VCCB);

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);
    measurementsData_type *pDbConf = &(CELLINFO[tgtCellNum].measurementsData);

    measurementObjectUe_type *pUeObj = NULL;

    // Try to find a measurement object with matching frequency in database
    if (RSType_SSB != signalType)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: Not supported signal type (%u) in VCCB_CheckIfMeasObjectNrCanBeAdded!\n", signalType);

        return ERROR;
    }

    VCCB_FrequencyMatcher frequencyMatcher(frequency, signalType);

    // If not found, return error
    uint8_t dbObjIdx = findIdxOfMatchingMeasObjectNr(frequencyMatcher, *pDbConf);
    if (dbObjIdx >= VCCB_ARRAY_COUNT(pDbConf->measurementObjectsNRDb))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: Couldn't find measurement object with arfcn %u for cell %u in "
            "VCCB_CheckIfMeasObjectNrCanBeAdded!\n",
            frequency, tgtCellNum);

        return ERROR;
    }

    measurementObjectNRDb_type *pDbObj = &pDbConf->measurementObjectsNRDb[dbObjIdx];
    measurementObjectNRBaseDb_type *pBaseObj = &pDbObj->base;

    // Check referenceSignalConfig
    if (CI_use != pBaseObj->referenceSignalConfig.ssbConfigMobility.usage)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "ssbMeasurementConfiguration not set in VCCB_CheckIfMeasObjectNrCanBeAdded!\n");

        return ERROR;
    }

    // Check if a measurement object with matching frequency is already scheduled for installation
    pUeObj = std::find_if(&(rMeasProc.measurementObjects.newItems[0]),
        &(rMeasProc.measurementObjects.newItems[rMeasProc.measurementObjects.numNewItems]), frequencyMatcher);

    // Already scheduled, return GOOD
    if (pUeObj != &(rMeasProc.measurementObjects.newItems[rMeasProc.measurementObjects.numNewItems]))
    {
        *result = GOOD;

        return GOOD;
    }

    // Ensure UE supports the band
    if (GOOD != VCCB_IsMeasObjectNrEligibleForUe(ptCi, pDbObj, tgtCellNum))
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "Can't add measurement object - NR freq (%u) not eligible by UE!\n", pBaseObj->ssbFrequency);

        return ERROR;
    }

    // Ensure we don't exceed the capacity
    if ((VCCB_FLAG_ON == ptCi->cgConfigInfo.configRestrictInfoFlag) &&
        (ptCi->cgConfigInfo.configRestrictInfo.maxMeasFreqsSCG_NR_Flag == VCCB_FLAG_ON))
    {
        if (rMeasProc.measurementObjects.numNewItems >= ptCi->cgConfigInfo.configRestrictInfo.maxMeasFreqsSCG_NR)
        {
            *result = ERROR;

            return GOOD;
        }
    }

    if (rMeasProc.measurementObjects.numNewItems >= VCCB_ARRAY_COUNT(rMeasProc.measurementObjects.newItems))
    {
        *result = ERROR;

        return GOOD;
    }

    *result = GOOD;

    return GOOD;
}

/**
 * @brief Finds the measurement object UE from the installed items based on the given frequency and RAT type.
 *
 * @param ptCi Pointer to the call information structure.
 * @param freq The frequency to search for.
 * @param ratType The RAT type to search for.
 * @return measurementObjectUe_type* Pointer to the measurement object UE if found, otherwise NULL.
 */
measurementObjectUe_type *FnVCCB_FindMeasurementObjectUeFromInstalledItemsByFrequency(
    callInfo_type *ptCi, Arfcn_type freq, enumMeasRatType ratType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ZERO(ptCi);

    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);
    measurementObjectUe_type *pUeMeasObj = NULL;

    if (ratType == measRatEutra)
    {
        pUeMeasObj =
            util::findObjectIfExist(rMeasConf.measurementObjects.installedItems, VCCB_FrequencyMatcherEutra(freq));
    }
    else
    {
        pUeMeasObj = util::findObjectIfExist(
            rMeasConf.measurementObjects.installedItems, VCCB_FrequencyMatcher(freq, RSType_SSB));
    }
    if (pUeMeasObj == util::NOT_FOUND)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "MeasObj not found in FnVCCB_FindMeasurementObjectUeFromInstalledItemsByFrequency with freq: %u ratType: "
            "%d !\n",
            freq, ratType);
        return NULL;
    }

    return pUeMeasObj;
}

/**
 * @brief Finds the measurement object UE from the installed items based on the given report cgi frequency and RAT type.
 *
 * @param ptCi Pointer to the call information structure.
 * @param freq The frequency to search for.
 * @param ratType The RAT type to search for.
 * @return measurementObjectUe_type* Pointer to the measurement object UE if found, otherwise NULL.
 */
measurementObjectUe_type *FnVCCB_FindMeasurementObjectUeFromInstalledItemsByReportCgiFreq(
    callInfo_type *ptCi, Arfcn_type freq, enumMeasRatType ratType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ZERO(ptCi);

    measurementsConfiguration_type &rMeasConf = FnVCCB_GetMeasurementsConfiguration(*ptCi);

    auto frequencyNrCdSsbMatcher = [freq](const measurementObjectUe_type &measObj)
    {
        return (CI_use == measObj.usage) && (measRatNr == measObj.conf.ratType) &&
               (measObj.conf.rat.nr.minimal.ssbFrequency == freq);  // compare CD-SSB frequency
    };

    measurementObjectUe_type *pUeMeasObj = NULL;
    if (ratType == measRatEutra)
    {
        pUeMeasObj =
            util::findObjectIfExist(rMeasConf.measurementObjects.installedItems, VCCB_FrequencyMatcherEutra(freq));
    }
    else
    {
        pUeMeasObj = util::findObjectIfExist(rMeasConf.measurementObjects.installedItems, frequencyNrCdSsbMatcher);
    }
    if (pUeMeasObj == util::NOT_FOUND)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "MeasObj not found in FnVCCB_FindMeasurementObjectUeFromInstalledItemsByReportCgiFreq with freq: %u "
            "ratType: %d !\n",
            freq, ratType);
        return NULL;
    }

    return pUeMeasObj;
}

/****************************************************************************
 * @brief           Checks if a measurement object with given id is present
 *                  in an array.
 *
 * @param[in]       id : ID of the object to find. / uint8_t
 * @param[in]       array : Target array to search in. / measurementObjectUe_type*
 * @param[in]       size : Size of the array. / uint8_t
 * @param[out]      idx : Index of the item if found. If the element wasn't found
 *                        it's equal to size (GOOD, ERROR). / uint8_t*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_FindMeasurementObjectById(uint8_t id, const measurementObjectUe_type *array, uint8_t size, uint8_t *idx)
{
    AUTO_TRACE_FUNC;

    int16_t status;
    status = VCCB_FindObjectById(id, array, size, idx);

    return status;
};

/****************************************************************************
 * @brief           Checks if a report configuration with given id is present
 *                  in an array.
 *
 * @param[in]       id : ID of the object to find. / uint8_t
 * @param[in]       array : Target array to search in. / reportConfigurationInstalledUe_type*
 * @param[in]       size : Size of the array. / uint8_t
 * @param[out]      idx : Index of the item if found. If the element wasn't found
 *                        it's equal to size (GOOD, ERROR). / uint8_t*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_FindReportConfigById(uint8_t id, const reportConfigurationInstalledUe_type *array, uint8_t size, uint8_t *idx)
{
    AUTO_TRACE_FUNC;

    int16_t status;
    status = VCCB_FindObjectById(id, array, size, idx);

    return status;
};

int16_t VCCB_FindReportConfigById(uint8_t id, const reportConfigurationNewUe_type *array, uint8_t size, uint8_t *idx)
{
    AUTO_TRACE_FUNC;

    int16_t status;
    status = VCCB_FindObjectById(id, array, size, idx);

    return status;
};

/****************************************************************************
 * @brief           Checks if a measurement identity with given id is present
 *                  in an array.
 *
 * @param[in]       id : ID of the object to find. / uint8_t
 * @param[in]       array : Target array to search in. / measurementIdentity_type*
 * @param[in]       size : Size of the array. / uint8_t
 * @param[out]      idx : Index of the item if found. If the element wasn't found
 *                        it's equal to size (GOOD, ERROR). / uint8_t*
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_FindMeasurementIdentityById(uint8_t id, measurementIdentity_type *array, uint8_t size, uint8_t *idx)
{
    AUTO_TRACE_FUNC;

    int16_t status;
    status = VCCB_FindObjectById(id, array, size, idx);

    return status;
};

/****************************************************************************
 * @brief           This API provides a function for obtaining Intra Frequency MeasObject.
 *
 * @param[in]       cellNum : Index of CELLINFO. / uint16_t
 * @return          ptMo : MeasObject of Intra-Frequency / measurementObjectNRDb_type*
 ****************************************************************************/
measurementObjectNRDb_type *FnVCCB_GetMeasObjectForIntraFrequency(const CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_NULL(cellNum, MAX_CELL_NUM_VCCB);

    return &CELLINFO[cellNum].measurementsData.measurementObjectsNRDb[INTRAFREQ_OBJECT_IDX];
};

const measurementObjectNRDb_type *FnVCCB_GetMeasObjectByFrequency(
    const VccbCellInfo_type &rCell, const uint32_t ssbFreq)
{
    if (rCell.ssbArfcn == ssbFreq)
    {
        return &rCell.measurementsData.measurementObjectsNRDb[INTRAFREQ_OBJECT_IDX];
    }
    else
    {
        for (uint8_t moIdx = 0; moIdx < (MAX_NR_OF_OBJECT_ID_DB - 1); moIdx++)
        {
            auto &moDB = rCell.measurementsData.measurementObjectsNRDb[moIdx];
            if (moDB.base.usage == CI_use && moDB.base.ssbFrequency == ssbFreq) return &moDB;
        }
        return nullptr;
    }
}
/****************************************************************************
 * @brief           This API provides the operation to find the MeasObject corresponding to the frequency.
 *
 * @param[in]       cellNum : Index of CELLINFO. / uint16_t
 * @param[in]       ssbFreq : Find SSB Frequency. / Arfcn_type/uint32_t
 * @return          ptMo : MeasObject of Intra-Frequency / measurementObjectNRDb_type*
 ****************************************************************************/
measurementObjectNRDb_type *FnVCCB_FindMeasObjectUsingFrequency(
    const CellNum_type cellNum, const Arfcn_type ssbFreq, uint8_t *pMeasObjIdx)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_NULL(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    measurementObjectNRDb_type *ptMO = NULL;

    // Fisrt, Find Serving Frequency
    if (pCell->ssbArfcn == ssbFreq)
    {
        if (pMeasObjIdx != NULL) *pMeasObjIdx = INTRAFREQ_OBJECT_IDX;
        return &pCell->measurementsData.measurementObjectsNRDb[INTRAFREQ_OBJECT_IDX];
    }

    // Finally, All Search Meas Object (There is no need to run the last one, but adjust it according to the DB size.)
    for (uint8_t moIdx = 0; moIdx < (MAX_NR_OF_OBJECT_ID_DB - 1); moIdx++)
    {
        ptMO = &(pCell->measurementsData.measurementObjectsNRDb[moIdx]);

        if (ptMO->base.usage != CI_use) continue;
        if (ptMO->base.ssbFrequency != ssbFreq) continue;

        if (pMeasObjIdx != NULL) *pMeasObjIdx = moIdx;
        return ptMO;
    }

    // Not Found
    return NULL;
};


namespace
{
uint8_t FnVCCB_GetNrDuplexTypeFromSsbFrequency(uint32_t ssbArfcn)
{
    if (ssbArfcn >= MIN_A6_NR_ARFCN)
    {
        return ci_DUPLEXTYPE_TDD;
    }
    if (ssbArfcn >= 600000)
    {
        return ci_DUPLEXTYPE_TDD;
    }
    if (ssbArfcn >= 499200 && ssbArfcn <= 537999)
    {
        return ci_DUPLEXTYPE_TDD;
    }
    if (ssbArfcn >= 514000 && ssbArfcn <= 524000)
    {
        return ci_DUPLEXTYPE_TDD;
    }
    if (ssbArfcn >= 285400 && ssbArfcn <= 303400)
    {
        return ci_DUPLEXTYPE_TDD;
    }
    if (ssbArfcn >= 402000 && ssbArfcn <= 405000)
    {
        return ci_DUPLEXTYPE_TDD;
    }
    if (ssbArfcn >= 376000 && ssbArfcn <= 384000)
    {
        return ci_DUPLEXTYPE_TDD;
    }
    if (ssbArfcn >= 460000 && ssbArfcn <= 480000)
    {
        return ci_DUPLEXTYPE_TDD;
    }
    return ci_DUPLEXTYPE_FDD;
}

static inline bool FnVCCB_CheckSsbFreqRestrictionPingPong(
    callInfo_type &rCall, uint32_t restrictSsbFreq, uint32_t targetSsbFreq)
{
    if (restrictSsbFreq == targetSsbFreq)
    {
        VCCB_PRINT_LOG_NC_MC(&rCall, "(PPA) PPA_RESTRICT (opt:restrict_ssb_freq, freq:%u)\n", restrictSsbFreq);
        return true;
    }
    return false;
}

static bool FnVCCB_CheckBandRestrictionPingPong(callInfo_type &rCall,
    const measurementObjectNRBaseDb_type &rRestrictObj, const measurementObjectNRBaseDb_type &rTargetObj)
{
    (void)rCall;
    for (const freqBand_type &rRestrictFreqBand : rRestrictObj.freqBandIndicatorDbList.freqBand)
    {
        if (CI_use != rRestrictFreqBand.usage)
        {
            continue;
        }
        for (const freqBand_type &rTargetFreqBand : rTargetObj.freqBandIndicatorDbList.freqBand)
        {
            if (CI_use != rTargetFreqBand.usage) continue;
            if (rRestrictFreqBand.band == rTargetFreqBand.band)
            {
                return true;
            }
        }
    }
    return false;
}

static inline bool FnVCCB_CheckFrTypeRestrictionPingPong(
    callInfo_type &rCall, uint32_t restrictSsbFreq, uint32_t targetSsbFreq)
{
    if ((restrictSsbFreq >= MIN_A6_NR_ARFCN && targetSsbFreq >= MIN_A6_NR_ARFCN) ||
        (restrictSsbFreq < MIN_A6_NR_ARFCN && targetSsbFreq < MIN_A6_NR_ARFCN))
    {
        VCCB_PRINT_LOG_NC_MC(&rCall, "(PPA) PPA_RESTRICT (opt:restrict_fr_type, freq:%u)\n", restrictSsbFreq);
        return true;
    }
    return false;
}

static inline bool FnVCCB_CheckDuplexTypeRestrictionPingPong(
    callInfo_type &rCall, uint32_t restrictSsbFreq, uint32_t targetSsbFreq)
{
    if (FnVCCB_GetNrDuplexTypeFromSsbFrequency(restrictSsbFreq) ==
        FnVCCB_GetNrDuplexTypeFromSsbFrequency(targetSsbFreq))
    {
        VCCB_PRINT_LOG_NC_MC(&rCall, "(PPA) PPA_RESTRICT (opt:restrict_duplex_type)\n");
        return true;
    }
    return false;
}
}  // namespace

int16_t FnVCCB_ProcessUeHistoryForPingPongAvoidance(callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;

    if (rCall.ueHistory.ppaRestrict.status != PPA_OFF)
    {
        return (rCall.ueHistory.ppaRestrict.status == PPA_NOT_RESTRICT) ? ERROR : GOOD;
    }

    rCall.ueHistory.ppaRestrict.status = PPA_NOT_RESTRICT;

    uint16_t xnCause = 0;
    uint16_t ngCause = 0;
    if (FnVCCB_GetConfigPingPongAvoidanceCause(rCall, xnCause, ngCause) == false)
    {
        VCCB_PRINT_LOG_NC_MC(&rCall, "(PPA) FnVCCB_GetConfigPingPongAvoidanceCause = false\n");
        return ERROR;
    }

    VCCB_CHECK_VALID_GNBNUM_ERROR(rCall.gnbNum);
    const uint32_t restrictionTimer = FnVCCB_GetPingPongRestrictionWindowSeconds(rCall);

    uint32_t accumulatedStayTime = 0;

    for (uint16_t loop = 0; loop < MAX_VISITED_CELL; loop++)
    {
        const uint16_t vIdx =
            static_cast<uint16_t>((rCall.ueHistory.lastIdx + (MAX_VISITED_CELL - loop)) % MAX_VISITED_CELL);
        visitedCellInfo_type *pVisited = &rCall.ueHistory.visitedCell[vIdx];
        if (pVisited->usage != CI_use)
        {
            break;
        }

        uint32_t cellStayTime = 0;
        if (pVisited->ratType == ci_nr)
        {
            if (pVisited->uRat.nrCell.hoCausePresent == OPT_PRESENT)
            {
                const uint16_t hoCause = pVisited->uRat.nrCell.hoCause;
                if (hoCause == ngCause)
                {
                    rCall.ueHistory.ppaRestrict.status = PPA_RESTRICT;
                    rCall.ueHistory.ppaRestrict.startTime =
                        FnVCCB_GetgVccbInfo()->cfg->tickRestrictionTime % SECONDS_PER_THREE_DAYS;
                    const uint32_t remain =
                        (restrictionTimer > accumulatedStayTime) ? (restrictionTimer - accumulatedStayTime) : 0u;
                    rCall.ueHistory.ppaRestrict.restrictTime = remain % SECONDS_PER_THREE_DAYS;
                    rCall.ueHistory.ppaRestrict.ncgi = pVisited->uRat.nrCell.cgi;
                    rCall.ueHistory.ppaRestrict.measObjIdx = INVALID_OBJECT_ID;
                    rCall.ueHistory.ppaRestrict.ssbFrequency = UNKNOWN_ARFCN;
                    VCCB_PRINT_LOG_NC_MC(&rCall,
                        "(PPA) found restrict source cell: ncgi(plmn:%llX/ci:%lu) startTime(%lu) restricTime(%lu)\n",
                        (unsigned long long)rCall.ueHistory.ppaRestrict.ncgi.plmn.longId,
                        (unsigned long)rCall.ueHistory.ppaRestrict.ncgi.ci,
                        (unsigned long)rCall.ueHistory.ppaRestrict.startTime,
                        (unsigned long)rCall.ueHistory.ppaRestrict.restrictTime);
                    return GOOD;
                }
            }
            if (pVisited->uRat.nrCell.stayTimeEnhancedPresent == OPT_PRESENT)
            {
                cellStayTime = (uint32_t)pVisited->uRat.nrCell.stayTimeEnhanced / 10u;
            }
            else
            {
                cellStayTime = pVisited->uRat.nrCell.stayTime;
            }
        }
        else if (pVisited->ratType == ci_eutra)
        {
            uint32_t stayTicks = 0;
            if (VCOM_GetStayTime_EUTRA(&pVisited->uRat.eutraCell, &stayTicks) != GOOD)
            {
                VCCB_PRINT_LOG_NC_MC(&rCall, "(PPA) Failed to unpack EUTRA stayTime from visited cell[%u]\n", vIdx);
            }
            else
            {
                cellStayTime = stayTicks / 10u;
            }
        }
        else
        {
            VCCB_PRINT_LOG_NC_MC(
                &rCall, "(PPA) skip stayTime for visited cell[%u] ratType(%u)\n", vIdx, pVisited->ratType);
        }

        accumulatedStayTime += cellStayTime;
        if (accumulatedStayTime >= restrictionTimer)
        {
            VCCB_PRINT_LOG_NC_MC(&rCall, "(PPA) Elapsed Time Over [yangTime(%u) >= stayTime(%lu)]\n",
                restrictionTimer, (unsigned long)accumulatedStayTime);
            break;
        }
    }

    VCCB_PRINT_LOG_NC_MC(&rCall, "(PPA) FnVCCB_ProcessUeHistoryForPingPongAvoidance (status:%u)\n",
        rCall.ueHistory.ppaRestrict.status);
    return ERROR;
}

bool FnVCCB_SetPingPongAvoidanceSsbFrequency(callInfo_type &rCall, CellNum_type cellNum)
{
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);

    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    if (rCall.ueHistory.ppaRestrict.ssbFrequency != UNKNOWN_ARFCN)
    {
        return (pCell->ssbArfcn == rCall.ueHistory.ppaRestrict.ssbFrequency) ? false : true;
    }

    const cgi_type sourceCgi = rCall.ueHistory.ppaRestrict.ncgi;
    nbrGnbCellInfo_type *pNbrGnbCell = NULL;

    for (uint16_t nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)
    {
        int16_t status = getNbrGnbCellByCellNbrIdx(rCall.servCellNum, nbrIdx, &pNbrGnbCell);
        if (status != GOOD || pNbrGnbCell == NULL)
        {
            continue;
        }

        cgi_type nbrCgi{};
        nbrCgi.plmn = pNbrGnbCell->globalGnbId.plmn;
        nbrCgi.ci = VLIB_GnbIdCellId2NrCellId(&pNbrGnbCell->globalGnbId.gnbId, pNbrGnbCell->cellId);
        if (nbrCgi.plmn.longId == sourceCgi.plmn.longId && nbrCgi.ci == sourceCgi.ci)
        {
            rCall.ueHistory.ppaRestrict.ssbFrequency = pNbrGnbCell->ssbArfcn;
            VCCB_PRINT_LOG_NC_MC(&rCall,
                "(PPA) Found matching neighbor for OM Intervention cell: nbrIdx:%u, ssbFrequency:%u, CGI(PLMN:%llX, "
                "CI:%lu)\n",
                nbrIdx, pNbrGnbCell->ssbArfcn, (unsigned long long)nbrCgi.plmn.longId, (unsigned long)nbrCgi.ci);
            return (pCell->ssbArfcn == rCall.ueHistory.ppaRestrict.ssbFrequency) ? false : true;
        }
    }
    return false;
}

bool FnVCCB_IsPingPongAvoidanceRestrictTimeActive(callInfo_type &rCall)
{
    uint32_t currTime = FnVCCB_GetgVccbInfo()->cfg->tickRestrictionTime % SECONDS_PER_THREE_DAYS;
    const uint32_t startTime = rCall.ueHistory.ppaRestrict.startTime % SECONDS_PER_THREE_DAYS;
    const uint32_t restrictTime = rCall.ueHistory.ppaRestrict.restrictTime;

    if (currTime < startTime)
    {
        currTime += SECONDS_PER_THREE_DAYS;
    }
    if (currTime >= startTime + restrictTime)
    {
        rCall.ueHistory.ppaRestrict.status = PPA_NOT_RESTRICT;
        VCCB_PRINT_LOG_NC_MC(&rCall,
            "(PPA) ppa restrictTime expired (plmn:%llX/ci:%lu/start:%lu/curr:%lu/restrict:%lu)\n",
            (unsigned long long)rCall.ueHistory.ppaRestrict.ncgi.plmn.longId,
            (unsigned long)rCall.ueHistory.ppaRestrict.ncgi.ci, (unsigned long)startTime, (unsigned long)currTime,
            (unsigned long)restrictTime);
        return false;
    }
    VCCB_PRINT_LOG_NC_MC(&rCall, "(PPA) currTime(%lu) < startTime(%lu) + restrictTime(%lu)\n",
        (unsigned long)currTime, (unsigned long)startTime, (unsigned long)restrictTime);
    return true;
}

int16_t FnVCCB_ProcessPingPongAvoidanceRestriction(callInfo_type &rCall, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;

    if (FnVCCB_ProcessUeHistoryForPingPongAvoidance(rCall) != GOOD)
    {
        return ERROR;
    }
    if (FnVCCB_SetPingPongAvoidanceSsbFrequency(rCall, cellNum) == false)
    {
        return ERROR;
    }
    if (FnVCCB_IsPingPongAvoidanceRestrictTimeActive(rCall) == false)
    {
        return ERROR;
    }
    return GOOD;
}

bool FnVCCB_IsPingPongAvoidanceRestrictionByOption(
    callInfo_type &rCall, CellNum_type cellNum, const measurementObjectNRBaseDb_type &rMoNrDb)
{
    if (rMoNrDb.saCapable != TRUE)
    {
        return false;
    }

    uint8_t measObjIdx = 0;
    measurementObjectNRDb_type *measObjDB = NULL;
    const uint32_t restrictSsbFreq = rCall.ueHistory.ppaRestrict.ssbFrequency;
    const uint8_t storedMeasObjIdx = rCall.ueHistory.ppaRestrict.measObjIdx;

    if (storedMeasObjIdx < (MAX_NR_OF_OBJECT_ID_DB - 1))    // inter freq only
    {
        VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);
        VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
        measObjIdx = storedMeasObjIdx;
        measObjDB = &(pCell->measurementsData.measurementObjectsNRDb[measObjIdx]);
    }
    else
    {
        measObjDB = FnVCCB_FindMeasObjectUsingFrequency(cellNum, restrictSsbFreq, &measObjIdx);
        VALID_E_POINT_CHECK_RET_VAL(measObjDB, false);
        rCall.ueHistory.ppaRestrict.measObjIdx = measObjIdx;
    }

    const uint8_t opt = measObjDB->base.freqRestrictOptionForPingPongAvoidance;
    switch (opt)
    {
        case RESTRICT_OPT_NONE:
            VCCB_PRINT_CALL_ERROR(
                &rCall, "(UHI) NOT PPA_RESTRICT (opt:restrict_none, freq:%u)\n", restrictSsbFreq);
            return false;
        case RESTRICT_OPT_SSB_FREQ:
            return FnVCCB_CheckSsbFreqRestrictionPingPong(rCall, restrictSsbFreq, rMoNrDb.ssbFrequency);
        case RESTRICT_OPT_BAND:
            return FnVCCB_CheckBandRestrictionPingPong(rCall, measObjDB->base, rMoNrDb);
        case RESTRICT_OPT_FR_TYPE:
            return FnVCCB_CheckFrTypeRestrictionPingPong(rCall, restrictSsbFreq, rMoNrDb.ssbFrequency);
        case RESTRICT_OPT_DUPLEX_TYPE:
            return FnVCCB_CheckDuplexTypeRestrictionPingPong(rCall, restrictSsbFreq, rMoNrDb.ssbFrequency);
        case RESTRICT_OPT_ALL:
            return true;
        default:
            break;
    }
    return false;
}

bool FnVCCB_IsPingPongAvoidanceRestrictionRequired(const uint8_t reportType, const uint8_t reportPurpose)
{
    switch (reportType)
    {
        case measReport_A3:
            switch (reportPurpose)
            {
                case a3Purpose_intraNrHandover:
                    return true;
                default:
                    return false;
            }
        case measReport_A4:
            switch (reportPurpose)
            {
                case a4Purpose_intraNrHandover:
                    return true;
                default:
                    return false;
            }
        case measReport_A5:
            switch (reportPurpose)
            {
                case a5Purpose_intraNrHandover:
                    return true;
                default:
                    return false;
            }
        default:
            break;
    }
    return false;
}

bool FnVCCB_IsPingPongAvoidanceNrRestriction(callInfo_type &rCall, CellNum_type cellNum, const measurementObjectNRBaseDb_type &rMoNrDb)
{
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);
    VCCB_PRINT_LOG_NC_MC(&rCall, "(PPA) cellNum(%u) Serv/target Freq (freq:%u/%u)\n", cellNum, CELLINFO[cellNum].ssbArfcn,
        rMoNrDb.ssbFrequency);

    if (FnVCCB_ProcessPingPongAvoidanceRestriction(rCall, cellNum) != GOOD)
    {
        return false;
    }
    if (FnVCCB_IsPingPongAvoidanceRestrictionByOption(rCall, cellNum, rMoNrDb) == true)
    {
        return true;
    }
    return false;
}

bool FnVCCB_IsPingPongAvoidanceRestriction(callInfo_type &rCall, CellNum_type cellNum, const measurementObjectNRBaseDb_type &rMoNrDb,
    uint8_t reportType, uint8_t reportPurpose)
{
    if (FnVCCB_IsPingPongAvoidanceRestrictionRequired(reportType, reportPurpose) == false)
    {
        return false;
    }
    return FnVCCB_IsPingPongAvoidanceNrRestriction(rCall, cellNum, rMoNrDb);
}

/****************************************************************************
 * @brief  Fill measurementObjectNRDu_type
 * @param  rDst         : reference to destination object
 * @param  rSrc         : reference to source object
 ****************************************************************************/
void VCCB_FillMeasurementObjectNRDu(measurementObjectNRDu_type &rDst, const measurementObjectNRUe_type &rSrc)
{
    AUTO_TRACE_FUNC;

    rDst.ssbFrequency = FnVCCB_GetRrcMeasObjectNrSsbFrequency(rSrc.minimal);
    rDst.ssbSubcarrierSpacing = FnVCCB_GetRrcMeasObjectNrSsbScs(rSrc.minimal);
    rDst.smtc1 = FnVCCB_GetRrcMeasObjectNrSsbSmtc1(rSrc.minimal);
}

/****************************************************************************
 * @brief  Fill measurementObjectEUTRADu_type
 * @param  rDst         : reference to destination object
 * @param  rSrc         : reference to source object
 ****************************************************************************/
void VCCB_FillMeasurementObjectEUTRADu(measurementObjectEUTRADu_type &rDst, const measurementObjectEUTRAUe_type &rSrc)
{
    AUTO_TRACE_FUNC;

    rDst.overlappedCarrierFreq = rSrc.minimal.overlappedCarrierFreq;
    rDst.allowedMeasBandwidth = rSrc.minimal.allowedMeasBandwidth;
    rDst.presenceAntennaPort1 = rSrc.minimal.presenceAntennaPort1;
    rDst.widebandRSRQMeas = rSrc.minimal.widebandRSRQMeas;
}

/****************************************************************************
 * @brief  Fill measurementObjectDu_type
 * @param  rDst         : reference to destination object
 * @param  rSrc         : reference to source object
 * @return int16_t      : status : GOOD/ERROR
 ****************************************************************************/
int16_t VCCB_FillMeasurementObjectDu(measurementObjectDu_type &rDst, const measurementObjectUe_type &rSrc)
{
    AUTO_TRACE_FUNC;

    rDst.objectId = INVALID_OBJECT_ID;
    rDst.ueObjectId = rSrc.objectId;
    rDst.local = TRUE;
    rDst.snode = FALSE;
    rDst.ratType = rSrc.conf.ratType;
    switch (rDst.ratType)
    {
        case measRatNr:
            VCCB_FillMeasurementObjectNRDu(rDst.rat.nr, rSrc.conf.rat.nr);
            break;

        case measRatEutra:
            VCCB_FillMeasurementObjectEUTRADu(rDst.rat.eutra, rSrc.conf.rat.eutra);
            break;

        default:
            VCCB_PRINT_ERROR("Not supported MO ratType(%u)!\n", rDst.ratType);
            return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief Functor for matching measurementObjectDu_type
 ****************************************************************************/
struct VCCB_MeasurementObjectDuMatcher
{
    VCCB_MeasurementObjectDuMatcher(const measurementObjectDu_type &rSrc) : _rSrc(rSrc){};

    bool operator()(const measurementObjectDu_type &rTgt) const
    {
        if (rTgt.ratType != _rSrc.ratType)
        {
            return false;
        }

        switch (_rSrc.ratType)
        {
            case measRatNr:
                if (rTgt.rat.nr != _rSrc.rat.nr)
                {
                    return false;
                }
                break;

            case measRatEutra:
                if (rTgt.rat.eutra != _rSrc.rat.eutra)
                {
                    return false;
                }
                break;

            default:
                VCCB_PRINT_ERROR("Not supported MO ratType(%u)!\n", _rSrc.ratType);
                return false;
        }

        return true;
    }

    const measurementObjectDu_type &_rSrc;
};

/****************************************************************************
 * @brief  Finalize moListMgap_type: assign IDs and sort pending items
 ****************************************************************************/
void VCCB_FinalizeMoListMgap(moListMgap_type &pending, const moListMgap_type &installed)
{
    AUTO_TRACE_FUNC;

    bool idsState[MAX_NR_OF_OBJECT_ID_3GPP] = {};

    // Assign pending item ids of corresponding installed item
    for (uint8_t elemIdx = 0; elemIdx < util::minOfArraySizeAndNumOfElems(pending.items, pending.numItems); elemIdx++)
    {
        const measurementObjectDu_type *pRes = std::find_if(installed.items, installed.items + installed.numItems,
            VCCB_MeasurementObjectDuMatcher(pending.items[elemIdx]));

        if ((pRes != installed.items + installed.numItems) && (MAX_NR_OF_OBJECT_ID_3GPP > pRes->objectId))
        {
            // found pending item in corresponding installed items
            pending.items[elemIdx].objectId = pRes->objectId;
            idsState[pRes->objectId] = true;
        }
        else
        {
            pending.items[elemIdx].objectId = INVALID_OBJECT_ID;
        }
    }

    // Assign pending item ids unused
    uint8_t idIdx = 0;
    for (uint8_t elemIdx = 0; elemIdx < util::minOfArraySizeAndNumOfElems(pending.items, pending.numItems); elemIdx++)
    {
        if (INVALID_OBJECT_ID != pending.items[elemIdx].objectId)
        {
            continue;
        }
        while ((MAX_NR_OF_OBJECT_ID_3GPP > idIdx) && (true == idsState[idIdx]))
        {
            idIdx++;
        }
        if (MAX_NR_OF_OBJECT_ID_3GPP <= idIdx)
        {
            VCCB_PRINT_ERROR("[m-gap] Not enough free DU MO ID to be assigned for elemIdx(%u)!\n", elemIdx);
            break;
        }
        pending.items[elemIdx].objectId = idIdx;
        idsState[idIdx] = true;
        idIdx++;
    }

    // Sort pending items
    std::sort(pending.items, pending.items + pending.numItems);
}

/****************************************************************************
 * @brief  Gets SCS and SMTC1 for NBR with given ssbArfcn
 * @param  ptCi           : pointer to UE Context
 * @param  cellNum        : cell number of NBR configuration
 * @param  ssbArfcn       : ssbArfcn of NBR
 * @param  nrScsDl        : return value of SCS DL of NBR
 * @param  nrScsDl        : return value of SMTC1 of NBR
 * @return int16_t        : GOOD - NBR found and returned data is valid, ERROR, BREAK
 ****************************************************************************/
int16_t VCCB_GetScsSmtc1ForNbrSsbArfcn(
    callInfo_type *ptCi, CellNum_type cellNum, Arfcn_type ssbArfcn, uint8_t &nrScsDl, smtc1_type &smtc1)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    uint16_t nbrIdx = 0;
    nbrGnbCellInfo_type *ptNbrGnbCell = nullptr;

    for (nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)  // go through all the neighbors
    {
        if (N_EQUIP == pCell->Nbr[nbrIdx].status)
        {
            continue;
        }
        if (ERROR == getNbrGnbCellByCellNbrIdx(cellNum, nbrIdx, &ptNbrGnbCell))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[GetScsSmtc1ForNbrSsbArfcn] getNbrGnbCellByCellNbrIdx returned ERROR cellNum(%u), nbrIdx(%u)\n",
                cellNum, nbrIdx);
            continue;
        }
        if (N_EQUIP == ptNbrGnbCell->status)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[GetScsSmtc1ForNbrSsbArfcn] ptNbrGnbCell->status(N_EQUIP) for ptNbrGnbCell->cellId(%u)\n",
                ptNbrGnbCell->cellId);
            continue;
        }
        if (ptNbrGnbCell->ssbArfcn != ssbArfcn)
        {
            continue;
        }
        if (CI_no_use == ptNbrGnbCell->smtcStatus)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[GetScsSmtc1ForNbrSsbArfcn] ptNbrGnbCell->smtcStatus(CI_no_use) for ptNbrGnbCell->cellId(%u)\n",
                ptNbrGnbCell->cellId);
            continue;
        }

        nrScsDl = ptNbrGnbCell->nrScsDl;
        smtc1 = ptNbrGnbCell->smtc1;

        return GOOD;
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "No NBR cell with ssbArfcn(%u) for cellNum(%u)!\n", ssbArfcn, cellNum);
    return BREAK;
}

/****************************************************************************
 * @brief  Append freqSnNew to pending.
 *         For MN (NR-DC, NE-DC) only.
 * @param  ptCi           : pointer to UE Context
 * @param  cellNum        : cell number of NBR configuration
 * @param  rPending       : reference to output structure
 ****************************************************************************/
void VCCB_AppendMeasFreqSnToMoListMgap(callInfo_type *ptCi, const CellNum_type cellNum, moListMgap_type &rPending)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    const measuredFrequencies_type &rFreqSnNew = ptCi->measurementsConfigShared.mGapConfiguration.freqSnNew;

    for (uint8_t snIdx = 0; (snIdx < util::minOfArraySizeAndNumOfElems(rFreqSnNew.frequencies, rFreqSnNew.numItems)) &&
                            (MAX_NR_OF_OBJECT_ID_3GPP > rPending.numItems);
         snIdx++)
    {
        // Check if MeasFreqSn is not already added locally
        measurementObjectDu_type *pDst = std::find_if(rPending.items, rPending.items + rPending.numItems,
            [&](const measurementObjectDu_type &rMoPending) {
                return ((measRatNr == rMoPending.ratType) &&
                        (rFreqSnNew.frequencies[snIdx] == rMoPending.rat.nr.ssbFrequency));
            });
        if (pDst != rPending.items + rPending.numItems)
        {
            // MeasFreqSn found, added locally
            pDst->snode = TRUE;
            continue;
        }

        // Check MeasFreqSn is in NRT
        if (GOOD != VCCB_GetScsSmtc1ForNbrSsbArfcn(ptCi, cellNum, rFreqSnNew.frequencies[snIdx],
                        pDst->rat.nr.ssbSubcarrierSpacing, pDst->rat.nr.smtc1))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[m-gap] SCS/SMTC1 not found for measFreqSN(%u) cellNum(%u)\n",
                rFreqSnNew.frequencies[snIdx], cellNum);
            continue;
        }

        pDst->objectId = INVALID_OBJECT_ID;
        pDst->ueObjectId = INVALID_OBJECT_ID;
        pDst->local = FALSE;
        pDst->snode = TRUE;
        pDst->ratType = measRatNr;
        pDst->rat.nr.ssbFrequency = rFreqSnNew.frequencies[snIdx];

        rPending.numItems++;
    }

    ptCi->measurementsConfigShared.mGapConfiguration.freqSnInstalled = rFreqSnNew;
}

/****************************************************************************
 * @brief  Fill moDuNew using freqSnNew
 * @param  ptCi           : pointer to UE Context
 ****************************************************************************/
void VCCB_FillDuMoWithMeasFreqSn(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    moListMgap_type &rPending = FnVCCB_GetMGapDuData(*ptCi).moDuNew;
    const moListMgap_type &rInstalled = ptCi->measurementsConfigShared.mGapConfiguration.moDuInstalled;

    // Copy installed local to new
    rPending.numItems = 0;
    for (uint8_t insIdx = 0; util::minOfArraySizeAndNumOfElems(rInstalled.items, rInstalled.numItems) > insIdx; insIdx++)
    {
        /*skip only snode*/
        if (((TRUE == rInstalled.items[insIdx].snode) && (FALSE == rInstalled.items[insIdx].local)) ||
            ((TRUE == rInstalled.items[insIdx].snode) && (FALSE == rInstalled.items[insIdx].nrDlTdoa)))
        {
            continue;
        }

        measurementObjectDu_type &rDst = rPending.items[rPending.numItems];
        rDst = rInstalled.items[insIdx];
        rDst.snode = FALSE;

        rPending.numItems++;
    }

    VCCB_AppendMeasFreqSnToMoListMgap(ptCi, ptCi->servCellNum, rPending);
    VCCB_FinalizeMoListMgap(rPending, rInstalled);
    FnVCCB_GetMGapDuData(*ptCi).moDuPreparedFlag = VCCB_FLAG_ON;
}

/****************************************************************************
 * @brief  Check if ssbFrequency is SCG serving frequency.
 * @param  ptCi           : pointer to UE Context
 * @param  ssbFrequency   : ssbFrequency to be checked
 * @return int16_t        : status : GOOD - serving freq, ERROR,BREAK / int16_t
 ****************************************************************************/
int16_t VCCB_IsSsbArfcnScgServingFreq(callInfo_type *ptCi, Arfcn_type ssbFrequency)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if ((E_CALLTYPE_SA != ptCi->callType) || (UECTX_NRDC_MN != ptCi->mrdcInfo.ueCtxType) ||
        !IS_NOT_MRDC_SCG_RELEASE_ONGOING(ptCi) || IS_SCG_SUSPENDED(ptCi))
    {
        return BREAK;
    }

    if (ssbFrequency == ptCi->mrdcInfo.SNInfo[SRC_SN].selectedPsCell.pScellFrequency)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "ssbFrequency(%u) is SCG serving-freq (PSCell-NR)\n", ssbFrequency);
        return GOOD;
    }

    for (uint8_t loop = 0; loop < MIN(ptCi->mrdcInfo.SNInfo[SRC_SN].nrofScellNrArfcnDl, (MAX_NUM_SERVING_CELL - 1));
         loop++)
    {
        if (ssbFrequency == ptCi->mrdcInfo.SNInfo[SRC_SN].scellNrArfcnDl[loop])
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "ssbFrequency(%u) is SCG serving-freq (SCell-NR)\n", ssbFrequency);
            return GOOD;
        }
    }

    return BREAK;
}

/****************************************************************************
 * @brief  Check if EARFCN is SCG serving frequency.
 * @param  ptCi           : pointer to UE Context
 * @param  earfcn         : EARFCN to be checked
 * @return int16_t        : status : GOOD - serving freq, ERROR,BREAK / int16_t
 ****************************************************************************/
int16_t VCCB_IsEarfcnScgServingFreq(callInfo_type *ptCi, Arfcn_type earfcn)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if ((E_CALLTYPE_SA != ptCi->callType) || (UECTX_NEDC_MN != ptCi->mrdcInfo.ueCtxType) ||
        !IS_NOT_MRDC_SCG_RELEASE_ONGOING(ptCi))
    {
        return BREAK;
    }

    if (earfcn == ptCi->mrdcInfo.SNInfo[SRC_SN].selectedPsCell.pScellFrequencyEUTRA)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "earfcn(%u) is SCG serving-freq (PSCell-EUTRA)\n", earfcn);
        return GOOD;
    }

    for (uint8_t loop = 0; loop < MIN(ptCi->mrdcInfo.SNInfo[SRC_SN].nrofScellEarfcnDl, (MAX_NUM_SERVING_CELL - 1));
         loop++)
    {
        if (earfcn == ptCi->mrdcInfo.SNInfo[SRC_SN].scellEarfcnDl[loop])
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "earfcn(%u) is SCG serving-freq (SCell-EUTRA)\n", earfcn);
            return GOOD;
        }
    }

    return BREAK;
}

/****************************************************************************
 * @brief  Check if MeasObject is serving frequency. It utilises measObjId.
 * @param  ptCi           : pointer to UE Context
 * @param  ptMeasObj      : pointer to MeasObj to be checked
 * @return int16_t        : status : GOOD - serving freq, ERROR,BREAK / int16_t
 ****************************************************************************/
int16_t VCCB_IsMeasObjectServingFreq(callInfo_type *ptCi, const measurementObjectUe_type *ptMeasObj)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMeasObj);

    const uint8_t measObjId = static_cast<uint8_t>(ptMeasObj->objectId + 1);  // compensate 0 based

    if (measRatNr == ptMeasObj->conf.ratType)
    {
        // ENDC: check with SCG configuration (this gNB)
        // SA, NEDC: check with MCG configuration (this gNB)

        // Check PCell
        if (measObjId == FnVCCB_GetMeasurementsConfiguration(*ptCi).tgtCellMoId)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "MO ID(%d) is serving-freq (PCell)\n", measObjId);
            return GOOD;
        }

        // Check SCells
        scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
        for (uint16_t cellIdx = 0; cellIdx < MAX_SCELL_PER_CALL; cellIdx++)
        {
            if (scells[cellIdx].state != SCELL_STATE_ADDED)
            {
                continue;
            }

            if (measObjId == scells[cellIdx].cellMoId)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "MO ID(%d) is serving-freq (SCell)\n", measObjId);
                return GOOD;
            }
        }

        // Check SCG for NR-DC
        if (GOOD == VCCB_IsSsbArfcnScgServingFreq(ptCi, ptMeasObj->conf.rat.nr.minimal.ssbFrequency))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "MO ID(%d) is SCG serving-freq\n", measObjId);
            return GOOD;
        }

        VCCB_PRINT_CALL_COMMENT(ptCi, "MO ID(%d) is non-serving-freq NR band(%u) FR%u\n", measObjId,
            ptMeasObj->conf.rat.nr.minimal.freqBandIndicatorNR,
            ((MIN_A6_NR_ARFCN <= ptMeasObj->conf.rat.nr.minimal.ssbFrequency) + 1));
    }
    else if (measRatEutra == ptMeasObj->conf.ratType)
    {
        // ENDC: EUTRA MO are not supported in this pkg
        // SA, NRDC: EUTRA MO are always non-serving-freq
        // NEDC: check with SCG configuration (peer ng-eNB)

        // Check SCG for NE-DC
        if (GOOD == VCCB_IsEarfcnScgServingFreq(ptCi, ptMeasObj->conf.rat.eutra.minimal.carrierFreq))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "MO ID(%d) is SCG serving-freq\n", measObjId);
            return GOOD;
        }

        VCCB_PRINT_CALL_COMMENT(ptCi, "MO ID(%d) is non-serving-freq EUTRA\n", measObjId);
    }
    else
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "MO ID(%d) is non-serving-freq ratType(%u)\n", measObjId, ptMeasObj->conf.ratType);
    }

    return BREAK;
}

/****************************************************************************
 * @brief    Local structure for Decide Measurement Gap configuration
 ****************************************************************************/
class VCCB_DecideMeasGapData : public VCCB_ServingCellData
{
public:
    struct MoInfo_s
    {
        uint8_t _idx;
        uint8_t _mgrpPreference;
        uint8_t _mrPurposeInfo;
    };
    using MoInfoList_type = simpleVector<MoInfo_s, MAX_NR_OF_OBJECT_ID>;

    VCCB_DecideMeasGapData(callInfo_type &rCi) :
        _rCi(rCi),
        _rMeasProc(FnVCCB_GetMeasurementsProcedure(_rCi)),
        _numFr1Items(0),
        _numFr2Items(0),
        _numIRatItems(0){};

    int16_t VCCB_CheckMeasurementPurpose();
    int16_t VCCB_SetMeasGap();

protected:
    callInfo_type &_rCi;
    const measurementsProcedure_type &_rMeasProc;
    uint32_t _fr1Items[MAX_NR_OF_OBJECT_ID] = {};
    uint32_t _fr2Items[MAX_NR_OF_OBJECT_ID] = {};
    uint32_t _iRatItems[MAX_NR_OF_OBJECT_ID] = {};
    uint8_t _numFr1Items, _numFr2Items, _numIRatItems;

    MoInfoList_type _fr1ObjIdxItems = {};
    MoInfoList_type _fr2ObjIdxItems = {};
    MoInfoList_type _frxObjIdxItems = {};

    int16_t VCCB_SetMeasGapENDC();
    int16_t VCCB_SetMeasGapSA();
    int16_t VCCB_SetMeasGapNRDC_SN();
    uint8_t VCCB_AlternateMeasGap_FilterMeasObjects(MoInfoList_type &rMoInfoList);

private:
    enum class MeasGapConfiguration
    {
        SmtcMixed,
        Smtc1Halfframe,
        Smtc2Halfframe
    };

    enum class SmtcHalfframe
    {
        First,
        Second
    };

    MeasGapConfiguration VCCB_AlternateMeasGap_GetMeasGapConfiguration(const MoInfoList_type &rMoInfoList);
    uint8_t VCCB_AlternateMeasGap_LeaveThoseWithSmtcInXHalfframe(MoInfoList_type &rMoInfoList, SmtcHalfframe);
    uint8_t VCCB_AlternateMeasGap_FilterMeasObjects_FeatureOff(MoInfoList_type &rMoInfoList);
    void VCCB_AlternateMeasGap_DecideState_Pa4mOn(bool isAlternationNeeded);
    uint8_t VCCB_AlternateMeasGap_FilterMeasObjects_FeatureOn(MoInfoList_type &rMoInfoList);
    void VCCB_AlternateMeasGap_PrintRemoved(const MoInfoList_type &rMoInfoList, const uint8_t numObjIdxItemsNew);
    void VCCB_AlternateMeasGap_DecideState_Pa4mOff(bool isAlternationNeeded);
    void VCCB_MergeFr1AndFr2ObjIdxItems();
};

/****************************************************************************
 * @brief  Update MGRP preference if new value is better(smaller value, not disabled) than existing one.
****************************************************************************/
inline void FnVCCB_UpdateMgrpPreference(uint8_t &rToUpdateMgrpPreference, const uint8_t newMgrpPreference)
{
    if ((MGRP_PREFERENCE_DISABLED == newMgrpPreference) ||
        ((MGRP_PREFERENCE_DISABLED != rToUpdateMgrpPreference) && (newMgrpPreference > rToUpdateMgrpPreference)))
    {
        return;
    }

    rToUpdateMgrpPreference = newMgrpPreference;
}

/****************************************************************************
 * @brief  Update measurement purpose information if new category is more important than existing one.
****************************************************************************/
inline void FnVCCB_UpdateMrPurposeInfo(uint8_t &rToUpdateMrPurposeInfo, const uint8_t rNewMrPurposeInfo)
{
    if ((MrPurposeInfo_null == rNewMrPurposeInfo) ||
        ((MrPurposeInfo_null != rToUpdateMrPurposeInfo) && (rNewMrPurposeInfo > rToUpdateMrPurposeInfo)))
    {
        return;
    }

    rToUpdateMrPurposeInfo = rNewMrPurposeInfo;
}

/****************************************************************************
 * @brief   Get measurement purpose information for given report config
            according to FGR-MC1014 FR932:
 * Category 1: EPS/Emergency FB is included in the measurement purpose(s) for the UE
 * Category 2: inter-RAT mobility excluding FB is included in the measurement purpose(s) for the UE
 * Category 3: intra-NR mobility is included in the measurement purpose(s) for the UE
 * Category 4: ETC
 ****************************************************************************/
uint8_t FnVCCB_GetMrPurposeInfo(const reportConfigurationConfUe_type &rptCfgUe)
{
    AUTO_TRACE_FUNC;

    switch (rptCfgUe.reportType)
    {
        case measReport_A3:
            switch (rptCfgUe.reportPurpose)
            {
                case a3Purpose_intraNrHandover:
                case a3Purpose_ChoPreparation:
                case a3Purpose_ChoExecutionCond1:
                case a3Purpose_ChoExecutionCond2:
                    return MrPurposeInfo_cat3;

                default:
                    break;
            }
            break;

        case measReport_A4:
            switch (rptCfgUe.reportPurpose)
            {
                case a4Purpose_intraNrHandover:
                case a4Purpose_PcellPriorHandover:
                case a4Purpose_NRLoadBalancing:
                case a4Purpose_ChoPreparation:
                case a4Purpose_nrForcedHandoverDueToSpecificSliceAware:
                    return MrPurposeInfo_cat3;

                default:
                    break;
            }
            break;

        case measReport_A5:
            switch (rptCfgUe.reportPurpose)
            {
                case a5Purpose_intraNrHandover:
                case a5Purpose_intraNrOnDemandHandover:
                case a5Purpose_intraNrRfspHandover:
                case a5Purpose_PcellPriorHandover:
                case a5Purpose_CapabilityAwareCarrierChange:
                case a5Purpose_intraNrDuTriggeredForcedHandover:
                case a5Purpose_forcedHandoverDueToBadUlQuality:
                case a5Purpose_forcedHandoverDueToTddInterference:
                case a5Purpose_forcedHandoverDueToLongRtpGap:
                case a5Purpose_NRLoadBalancing:
                case a5Purpose_voNrNRLoadBalancing:
                case a5Purpose_ChoPreparation:
                case a5Purpose_ChoExecutionCond1:
                case a5Purpose_ChoExecutionCond2:
                    return MrPurposeInfo_cat3;

                default:
                    break;
            }
            break;

        case measReport_B1Eutra:
            switch (rptCfgUe.reportPurpose)
            {
                case b1Purpose_saEpsFallbackHandover:
                case b1Purpose_saEmergencyFallbackHandover:
                    return MrPurposeInfo_cat1;

                case b1Purpose_eutraHandover:
                case b1Purpose_eutraRfspHandover:
                case b1Purpose_saPriortizationHandover:
                case b1Purpose_CapabilityAwareCarrierChange:
                case b1Purpose_trafficBasedHandover:
                case b1Purpose_mrsMrGathering:
                case b1Purpose_multiRatSelection:
                case b1Purpose_saToNsaBorderHandover:
                case b1Purpose_eutraForcedHandoverDueToUlPrbBlanking:
                case b1Purpose_eutraForcedHandoverDueToBadUlQuality:
                case b1Purpose_eutraForcedHandoverDueToTddInterference:
                case b1Purpose_eutraForcedHandoverDueToLongRtpGap:
                case b1Purpose_eutraForcedHandoverDueToSpecificSliceAware:
                case b1Purpose_iratRedirectionForAccessControl:
                case b1Purpose_loadBalancingIratHandover:
                    return MrPurposeInfo_cat2;

                default:
                    break;
            }
            break;

        case measReport_B2Eutra:
            switch (rptCfgUe.reportPurpose)
            {
                case b2Purpose_saEpsFallbackHandover:
                case b2Purpose_saEmergencyFallbackHandover:
                    return MrPurposeInfo_cat1;

                case b2Purpose_eutraHandover:
                case b2Purpose_eutraOnDemandHandover:
                case b2Purpose_trafficBasedHandover:
                case b2Purpose_capabilityAwareCarrierChange:
                case b2Purpose_loadBalancingIratHandover:
                    return MrPurposeInfo_cat2;

                default:
                    break;
            }
            break;

        default:
            break;
    }

    return MrPurposeInfo_cat4;
}

inline uint8_t FnVCCB_GetUeSpeedNonStationaryMgrpPreference(const reportConfigurationConfUe_type &rptCfgUe)
{
    return (((measReport_B1Eutra == rptCfgUe.reportType) || (measReport_B2Eutra == rptCfgUe.reportType)) ?
        rptCfgUe.reportConfiguration.eventInterRat.mgrpPreference : MGRP_PREFERENCE_DISABLED);
}

uint8_t FnVCCB_GetUeSpeedStationaryMgrpPreference(const uint8_t statUeMgrpPrefCfg, const uint8_t mrPurposeInfo)
{
    AUTO_TRACE_FUNC;

    switch (statUeMgrpPrefCfg)
    {
        case MGapStatUeMgrpPref_ms160ForAllPurpose:
            return MGRP_PREFERENCE_160MS;

        case MGapStatUeMgrpPref_ms160ExceptFb:
            if (MrPurposeInfo_cat1 != mrPurposeInfo)
            {
                return MGRP_PREFERENCE_160MS;
            }
            break;

        case MGapStatUeMgrpPref_ms160ExceptMobAndFb:
            if (MrPurposeInfo_cat4 == mrPurposeInfo)
            {
                return MGRP_PREFERENCE_160MS;
            }
            break;

        default:
            break;
    }

    return MGRP_PREFERENCE_DISABLED;
}

/****************************************************************************
 * @brief  Set mgap DU data:
    Fill moListMgap_type using rMoInfoList and rMeasProc.measurementObjects.newItems,
    Set mgrpPreference.
 * @param  rCi          : reference to UE Context
 * @param  rmGapDu      : reference to mgap DU data
 * @param  rMoInfoList  : reference to source list
 ****************************************************************************/
void FnVCCB_SetMGapDuDataWithMoInfoList(
    const callInfo_type &rCi, mGapDuData_type &rmGapDu, const VCCB_DecideMeasGapData::MoInfoList_type &rMoInfoList)
{
    AUTO_TRACE_FUNC;

    const measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(rCi);
    moListMgap_type &rMoListMgap = rmGapDu.moDuNew;
    rMoListMgap.numItems = 0;
    rmGapDu.mgrpPreference = MGRP_PREFERENCE_DISABLED;
    rmGapDu.mrPurposeInfo = MrPurposeInfo_null;

    for (uint8_t loop = 0; (rMoInfoList.size() > loop) && (MAX_NR_OF_OBJECT_ID_3GPP > rMoListMgap.numItems); ++loop)
    {
        VCCB_CHECK_E_RANGE_AND_CONTINUE(rMoInfoList[loop]._idx, rMeasProc.measurementObjects.numNewItems);

        if (ERROR == VCCB_FillMeasurementObjectDu(rMoListMgap.items[rMoListMgap.numItems],
                         rMeasProc.measurementObjects.newItems[rMoInfoList[loop]._idx]))
        {
            VCCB_PRINT_CALL_ERROR(&rCi, "VCCB_FillMeasurementObjectDu MO_idx(%u) ERROR!\n", rMoInfoList[loop]._idx);
            continue;
        }

        rMoListMgap.numItems++;
        FnVCCB_UpdateMgrpPreference(rmGapDu.mgrpPreference, rMoInfoList[loop]._mgrpPreference);
        FnVCCB_UpdateMrPurposeInfo(rmGapDu.mrPurposeInfo, rMoInfoList[loop]._mrPurposeInfo);
    }
}

/****************************************************************************
 * @brief  Fill frequency range of serving cells
 * @param  ptCi           : pointer to UE Context
 * @return int16_t        : result of operation
 ****************************************************************************/
void VCCB_ServingCellData::VCCB_FillServingCellFrs(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // Check PCell
    CellNum_type cellNum = FnVCCB_GetMeasurementsProcedure(*ptCi).tgtCellNum;

    if (cellNum >= MAX_CELL_NUM_VCCB)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ptCi->stateCmd(%u): cellNum(%u) is invalid!!\n", ptCi->stateCmd, cellNum);
        return;
    }
    if (MIN_A6_NR_ARFCN <= CELLINFO[cellNum].ssbArfcn)
    {
        // FR2 case
        _srvCellNrFr2 = true;
    }
    else
    {
        // FR1 case
        _srvCellNrFr1 = true;
    }

    // Check SN/MN cells
    if (E_CALLTYPE_NSA == ptCi->callType)
    {
        // EN-DC, EUTRA
        _srvCellEutra = true;
    }
    else if ((E_CALLTYPE_SA == ptCi->callType) && (IsAvailable_MrdcInfo()))
    {
        if (UECTX_NEDC_MN == ptCi->mrdcInfo.ueCtxType)
        {
            // NE-DC, EUTRA
            if (!IS_NOT_MRDC_SCG_RELEASE_ONGOING(ptCi))
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "[m-gap] NEDC Release is ongoing\n");
            }
            else
            {
                _srvCellEutra = true;
                VCCB_PRINT_CALL_COMMENT(ptCi, "[m-gap] NEDC SCG: PSCell earfcnDL(%u), nrofScellEarfcnDl(%u)\n",
                    ptCi->mrdcInfo.SNInfo[SRC_SN].selectedPsCell.pScellFrequencyEUTRA,
                    ptCi->mrdcInfo.SNInfo[SRC_SN].nrofScellEarfcnDl);
            }
        }
        else if (UECTX_NRDC_MN == ptCi->mrdcInfo.ueCtxType)
        {
            // NR-DC, NR
            if (!IS_NOT_MRDC_SCG_RELEASE_ONGOING(ptCi))
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "[m-gap] NRDC Release is ongoing\n");
            }
            else
            {
                // In case SCG suspend: UE still keeps SCG as serving cell.
                VCCB_PRINT_CALL_COMMENT(ptCi, "[m-gap] NRDC SCG: PSCell arfcnDL(%u), nrofScellArfcnDl(%u)\n",
                    ptCi->mrdcInfo.SNInfo[SRC_SN].selectedPsCell.pScellFrequency,
                    ptCi->mrdcInfo.SNInfo[SRC_SN].nrofScellEarfcnDl);

                // SCG PCell
                if (MIN_A6_NR_ARFCN < ptCi->mrdcInfo.SNInfo[SRC_SN].selectedPsCell.pScellFrequency)
                {
                    // FR2 case
                    _srvCellNrFr2 = true;
                }
                else
                {
                    // FR1 case
                    _srvCellNrFr1 = true;
                }

                // SCG SCell
                for (uint16_t cellIdx = 0;
                     cellIdx < MIN(ptCi->mrdcInfo.SNInfo[SRC_SN].nrofScellNrArfcnDl, MAX_NUM_SERVING_CELL - 1);
                     cellIdx++)
                {
                    if (MIN_A6_NR_ARFCN < ptCi->mrdcInfo.SNInfo[SRC_SN].scellNrArfcnDl[cellIdx])
                    {
                        // FR2 case
                        _srvCellNrFr2 = true;
                    }
                    else
                    {
                        // FR1 case
                        _srvCellNrFr1 = true;
                    }
                }
            }
        }
    }

    // Check SCells
    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (uint16_t cellIdx = 0; cellIdx < MAX_SCELL_PER_CALL; cellIdx++)
    {
        if (scells[cellIdx].state != SCELL_STATE_ADDED)
        {
            continue;
        }

        if (MIN_A6_NR_ARFCN <= scells[cellIdx].ssbArfcn)
        {
            // FR2 case
            _srvCellNrFr2 = true;
        }
        else
        {
            // FR1 case
            _srvCellNrFr1 = true;
        }
    }
    return;
}

/****************************************************************************
 * @brief    Check Measurement Purpose for Measurement Gap
 * @return int16_t        : result of operation
 ****************************************************************************/
int16_t VCCB_DecideMeasGapData::VCCB_CheckMeasurementPurpose()
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_RETURN(_rCi.gnbNum, MAX_GNB_PER_SYS);
    const gnbConfig_type &rGnbCfg = GNBINFO[_rCi.gnbNum].cfg;
    const bool getMrPurposeInfoFlag = ((MGapStatUeMgrpPref_disable != rGnbCfg.measGap.statUeMgrpPref) && !IS_MRDC_SN(&_rCi));
    const bool mgrpPrefUeSpeedAllowedFlag = ((MAX_CELL_NUM_VCCB > _rMeasProc.tgtCellNum) &&
        (0 == CELLINFO[_rMeasProc.tgtCellNum].measurementsData.mgrpPrefIRatBtmsk));
    const bool ueSpeedStationaryMgrpCheckFlag = getMrPurposeInfoFlag && mgrpPrefUeSpeedAllowedFlag &&
        (ueSpeedState_Stationary == UeSpeedState::VCCB_GetUeSpeedState(_rCi, _rMeasProc.tgtCellNum));

    uint8_t measObjIdx = 0, rptCfgIdx = 0;
    struct MoChkItem_s
    {
        MoChkItem_s(): isChecked(false), isFr2(false), objIdx(MAX_NR_OF_OBJECT_ID)
            {};

        bool isChecked;
        bool isFr2;
        uint8_t objIdx;
    };
    MoChkItem_s moIdxChkList[MAX_NR_OF_OBJECT_ID] = {};
    const measurementObjectUe_type *ptUeMeasObj = NULL;

    // Check serving cells
    VCCB_FillServingCellFrs(&_rCi);

    // Check active MeasObjects
    for (uint16_t loop = 0; loop < util::minOfArraySizeAndNumOfElems(_rMeasProc.measurementIdentities.newItems,
                                       _rMeasProc.measurementIdentities.numNewItems);
         ++loop)
    {
        if (CI_use != _rMeasProc.measurementIdentities.newItems[loop].usage)
        {
            continue;
        }

        const uint8_t size = static_cast<uint8_t>(util::minOfArraySizeAndNumOfElems(
            _rMeasProc.measurementObjects.newItems, _rMeasProc.measurementObjects.numNewItems));
        if (ERROR == VCCB_FindMeasurementObjectById(_rMeasProc.measurementIdentities.newItems[loop].measObjectId,
                         _rMeasProc.measurementObjects.newItems, size, &measObjIdx))
        {
            VCCB_PRINT_CALL_ERROR(&_rCi, "VCCB_FindMeasurementObjectById ERROR!!\n");
            return ERROR;
        }

        if (ERROR == VCCB_FindReportConfigById(_rMeasProc.measurementIdentities.newItems[loop].reportConfigId,
                         _rMeasProc.reportConfigurations.newItems,
                         MIN(_rMeasProc.reportConfigurations.numNewItems, MAX_NR_OF_REPORT_CONFIG_ID), &rptCfgIdx))
        {
            VCCB_PRINT_CALL_ERROR(&_rCi, "VCCB_FindReportConfigById ERROR!!\n");
            return ERROR;
        }

        if ((util::minOfArraySizeAndNumOfElems(
                 _rMeasProc.measurementObjects.newItems, _rMeasProc.measurementObjects.numNewItems) <= measObjIdx) ||
            (util::minOfArraySizeAndNumOfElems(
                 _rMeasProc.reportConfigurations.newItems, _rMeasProc.reportConfigurations.numNewItems) <= rptCfgIdx))
        {
            VCCB_PRINT_CALL_ERROR(
                &_rCi, "ERROR: Invalid measurement object(%u) or report(%u) configuration!!\n", measObjIdx, rptCfgIdx);
            return ERROR;
        }

        const reportConfigurationConfUe_type &rptCfgUe = _rMeasProc.reportConfigurations.newItems[rptCfgIdx].conf;
        const uint8_t mrPurposeInfo =
            (getMrPurposeInfoFlag ? FnVCCB_GetMrPurposeInfo(rptCfgUe) : static_cast<uint8_t>(MrPurposeInfo_null));
        const uint8_t mgrpPreference = (ueSpeedStationaryMgrpCheckFlag ?
            FnVCCB_GetUeSpeedStationaryMgrpPreference(rGnbCfg.measGap.statUeMgrpPref, mrPurposeInfo) :
            FnVCCB_GetUeSpeedNonStationaryMgrpPreference(rptCfgUe));

        // check if already not processed
        if (moIdxChkList[measObjIdx].isChecked)
        {
            if (MAX_NR_OF_OBJECT_ID > moIdxChkList[measObjIdx].objIdx)
            {
                // MO added to _fr1ObjIdxItems/_fr2ObjIdxItems => update mgrpPreference
                if (moIdxChkList[measObjIdx].isFr2)
                {
                    FnVCCB_UpdateMgrpPreference(_fr2ObjIdxItems[moIdxChkList[measObjIdx].objIdx]._mgrpPreference, mgrpPreference);
                    FnVCCB_UpdateMrPurposeInfo(_fr2ObjIdxItems[moIdxChkList[measObjIdx].objIdx]._mrPurposeInfo, mrPurposeInfo);
                }
                else
                {
                    FnVCCB_UpdateMgrpPreference(_fr1ObjIdxItems[moIdxChkList[measObjIdx].objIdx]._mgrpPreference, mgrpPreference);
                    FnVCCB_UpdateMrPurposeInfo(_fr1ObjIdxItems[moIdxChkList[measObjIdx].objIdx]._mrPurposeInfo, mrPurposeInfo);
                }
            }
            continue;
        }
        moIdxChkList[measObjIdx].isChecked = true;

        ptUeMeasObj = &_rMeasProc.measurementObjects.newItems[measObjIdx];

        switch (ptUeMeasObj->conf.ratType)
        {
            case measRatNr:
                if (RSType_SSB != rptCfgUe.rsType)
                {
                    VCCB_PRINT_CALL_ERROR(&_rCi,
                        "ERROR: Invalid reference signal type(%u) rptCfgIdx(%u) measObjIdx(%u)! - skip\n",
                        rptCfgUe.rsType, rptCfgIdx, measObjIdx);
                    continue;
                }

                if (GOOD != VCCB_CheckMeasObjectNrInterFreqNoNeedForGap(&_rCi, &ptUeMeasObj->conf.rat.nr))
                {
                    if (MIN_A6_NR_ARFCN <= ptUeMeasObj->conf.rat.nr.minimal.ssbFrequency)
                    {
                        moIdxChkList[measObjIdx].isFr2 = true;
                        if (GOOD != VCCB_IsSsbArfcnScgServingFreq(&_rCi, ptUeMeasObj->conf.rat.nr.minimal.ssbFrequency))
                        {
                            moIdxChkList[measObjIdx].objIdx = static_cast<uint8_t>(_fr2ObjIdxItems.size());
                            _fr2ObjIdxItems.push_back(
                                {._idx = measObjIdx, ._mgrpPreference = mgrpPreference, ._mrPurposeInfo = mrPurposeInfo});
                        }
                        if (GOOD != VCCB_IsMeasObjectServingFreq(&_rCi, ptUeMeasObj))
                        {
                            _fr2Items[_numFr2Items++] = ptUeMeasObj->conf.rat.nr.minimal.ssbFrequency;
                        }
                    }
                    else
                    {
                        if (GOOD != VCCB_IsSsbArfcnScgServingFreq(&_rCi, ptUeMeasObj->conf.rat.nr.minimal.ssbFrequency))
                        {
                            moIdxChkList[measObjIdx].objIdx = static_cast<uint8_t>(_fr1ObjIdxItems.size());
                            _fr1ObjIdxItems.push_back(
                                {._idx = measObjIdx, ._mgrpPreference = mgrpPreference, ._mrPurposeInfo = mrPurposeInfo});
                        }
                        if (GOOD != VCCB_IsMeasObjectServingFreq(&_rCi, ptUeMeasObj))
                        {
                            _fr1Items[_numFr1Items++] = ptUeMeasObj->conf.rat.nr.minimal.ssbFrequency;
                        }
                    }
                }
                else
                {
                    VCCB_PRINT_CALL_COMMENT(&_rCi, "MO ID(%d) NR band(%u): no need gap\n", ptUeMeasObj->objectId + 1,
                        ptUeMeasObj->conf.rat.nr.minimal.freqBandIndicatorNR);
                }

                break;

            case measRatEutra:
                if (GOOD == VCCB_IsMeasObjectServingFreq(&_rCi, ptUeMeasObj))
                {
                    continue;
                }
                moIdxChkList[measObjIdx].objIdx = static_cast<uint8_t>(_fr1ObjIdxItems.size());
                _fr1ObjIdxItems.push_back(
                    {._idx = measObjIdx, ._mgrpPreference = mgrpPreference, ._mrPurposeInfo = mrPurposeInfo});
                _iRatItems[_numIRatItems++] =
                    VLIB_Freq2Arfcn(ConvertDlEarfcnToFreqKhz(ptUeMeasObj->conf.rat.eutra.minimal.carrierFreq));
                break;

            default:
                VCCB_PRINT_CALL_COMMENT(
                    &_rCi, "[m-gap] not supported for inter-rat ratType(%u) MO\n", ptUeMeasObj->conf.ratType);
                continue;
        }
    }

    return GOOD;
}

/****************************************************************************
 * @brief    Decide Measurement Gap configuration for EN-DC
 * @return int16_t        : result of operation
 ****************************************************************************/
int16_t VCCB_DecideMeasGapData::VCCB_SetMeasGapENDC()
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_VALID_GNBNUM_ERROR(_rCi.gnbNum);
    gnbConfig_type *const pGnbCfg = &GNBINFO[_rCi.gnbNum].cfg;

    mGapCallConfiguration_type &rmGapConfig = _rCi.measurementsConfigShared.mGapConfiguration;
    mGapDuData_type &rmGapDu = FnVCCB_GetMGapDuData(_rCi);
    uint32_t *ptFreqEnd = rmGapConfig.freqSnNew.frequencies;
    bool mnForcedPerUeGaps = false;

    if (0 < _numIRatItems)
    {
        VCCB_PRINT_CALL_COMMENT(&_rCi, "[m-gap] not supported for inter-rat MO in ENDC\n");
    }

    // 3GPP 38.133 table 9.1.2-2
    // (SVR19A - no interRAT measurement purpose)
    if ((FALSE == _rCi.ueInfo.ueCapa.mrdc.independentGapConfig_support) ||
        (VCCB_FLAG_OFF == pGnbCfg->measGap.indepGapEnabledEndc) ||
        (true == (mnForcedPerUeGaps = VCCB_CheckMnForcedPerUeGapsForSn(&_rCi))))
    {
        VCCB_PRINT_CALL_COMMENT(&_rCi,
            "[m-gap] perUE gap indepGapConfigSupport(%u) indepGapEnabled(%u) mnForcedPerUeGaps(%u)\n",
            _rCi.ueInfo.ueCapa.mrdc.independentGapConfig_support, pGnbCfg->measGap.indepGapEnabledEndc,
            mnForcedPerUeGaps);

        // use per UE gaps
        if ((0 < _numFr1Items) || (0 < _numFr2Items))
        {
            VCCB_PRINT_CALL_COMMENT(
                &_rCi, "[m-gap] perUE gap required for #FR1(%u), #FR2(%u)\n", _numFr1Items, _numFr2Items);
            ptFreqEnd = std::copy(_fr1Items, _fr1Items + _numFr1Items, ptFreqEnd);
            ptFreqEnd = std::copy(_fr2Items, _fr2Items + _numFr2Items, ptFreqEnd);
        }
        else
        {
            VCCB_PRINT_CALL_COMMENT(&_rCi, "[m-gap] perUE gap not required\n");
        }
    }
    else
    {
        // use per FR gaps
        if (0 < _numFr1Items)
        {
            // FR1
            VCCB_PRINT_CALL_COMMENT(&_rCi, "[m-gap] perFR1 gap required for #FR1(%u)\n", _numFr1Items);
            ptFreqEnd = std::copy(_fr1Items, _fr1Items + _numFr1Items, ptFreqEnd);
        }
        else
        {
            // no gap
            VCCB_PRINT_CALL_COMMENT(&_rCi, "[m-gap] perFR1 gap not required\n");
        }

        if (true == _srvCellNrFr2)
        {
            VCCB_PRINT_CALL_COMMENT(&_rCi, "[m-gap] perFR: FR2 MO num(%lu) for DU\n", _fr2ObjIdxItems.size());
            if (0 < _fr2ObjIdxItems.size())
            {
                // FR2
                FnVCCB_SetMGapDuDataWithMoInfoList(_rCi, rmGapDu, _fr2ObjIdxItems);
                VCCB_FinalizeMoListMgap(rmGapDu.moDuNew, rmGapConfig.moDuInstalled);
            }
        }
    }

    rmGapConfig.freqSnNew.numItems =
        static_cast<uint8_t>(ptFreqEnd - rmGapConfig.freqSnNew.frequencies);
    std::sort(rmGapConfig.freqSnNew.frequencies, ptFreqEnd);

    return GOOD;
}

/****************************************************************************
 * @brief    Decide Measurement Gap configuration for SA, NE-DC, NR-DC Master Node
 * @return int16_t        : result of operation
 ****************************************************************************/
int16_t VCCB_DecideMeasGapData::VCCB_SetMeasGapSA()
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_VALID_GNBNUM_ERROR(_rCi.gnbNum);
    const gnbConfig_type &rGnbCfg = GNBINFO[_rCi.gnbNum].cfg;
    mGapDuData_type &rmGapDu = FnVCCB_GetMGapDuData(_rCi);

    const bool isMrdc = IsAvailable_MrdcInfoWithCallInfo(&_rCi) && IS_NOT_MRDC_SCG_RELEASE_ONGOING(&_rCi);
    bool independentGapConfig = false;

    if (VCCB_FLAG_ON == rGnbCfg.measGap.indepGapEnabledNr)
    {
        independentGapConfig = _rCi.ueInfo.ueCapa.nr.measAndMob.independentGapConfig;

        if (isMrdc)
        {
            switch (_rCi.mrdcInfo.ueCtxType)
            {
                case UECTX_NONE:
                    // already set
                    break;

                case UECTX_NRDC_MN:
                    independentGapConfig = _rCi.ueInfo.ueCapa.nr.nrdc.independentGapConfig_support;
                    VCCB_PRINT_CALL_COMMENT(&_rCi, "[m-gap] NR-DC MN independentGapConfig(%u)\n", independentGapConfig);
                    break;

                case UECTX_NEDC_MN:
                    independentGapConfig = _rCi.ueInfo.ueCapa.mrdc.independentGapConfig_support;
                    VCCB_PRINT_CALL_COMMENT(&_rCi, "[m-gap] NE-DC MN independentGapConfig(%u)\n", independentGapConfig);
                    break;

                default:
                    VCCB_PRINT_CALL_ERROR(&_rCi,
                        "[m-gap] Invalid mrdcInfo.ueCtxType(%u)! Assuming independentGapConfig(0)\n",
                        _rCi.mrdcInfo.ueCtxType);
                    independentGapConfig = false;
                    break;
            }
        }
    }
    else
    {
        VCCB_PRINT_CALL_COMMENT(&_rCi, "[m-gap] independentGapConfig disabled\n");
    }

    // 3GPP 38.133 table 9.1.2-3
    if (false == independentGapConfig)
    {
        // use per UE gaps
        VCCB_PRINT_CALL_COMMENT(&_rCi, "[m-gap] perUE: FR1 MO num(%lu) for DU\n", _fr1ObjIdxItems.size());
        VCCB_PRINT_CALL_COMMENT(&_rCi, "[m-gap] perUE: FR2 MO num(%lu) for DU\n", _fr2ObjIdxItems.size());
        if ((0 < _fr1ObjIdxItems.size()) || (0 < _fr2ObjIdxItems.size()))
        {
            VCCB_MergeFr1AndFr2ObjIdxItems();
            if (!isMrdc)
            {
                const uint8_t newNumFrxObjIdxItems = VCCB_AlternateMeasGap_FilterMeasObjects(_frxObjIdxItems);
                VCCB_AlternateMeasGap_PrintRemoved(_frxObjIdxItems, newNumFrxObjIdxItems);
                _frxObjIdxItems.erase(_frxObjIdxItems.begin() + newNumFrxObjIdxItems, _frxObjIdxItems.end());
            }
            FnVCCB_SetMGapDuDataWithMoInfoList(_rCi, rmGapDu, _frxObjIdxItems);
        }
    }
    else
    {
        // use per FR gaps
        if (true == _srvCellNrFr1)
        {
            VCCB_PRINT_CALL_COMMENT(&_rCi, "[m-gap] perFR: FR1 MO num(%lu) for DU\n", _fr1ObjIdxItems.size());
            if (0 < _fr1ObjIdxItems.size())
            {
                if (!isMrdc)
                {
                    const uint8_t newNumFr1ObjIdxItems = VCCB_AlternateMeasGap_FilterMeasObjects(_fr1ObjIdxItems);
                    VCCB_AlternateMeasGap_PrintRemoved(_fr1ObjIdxItems, newNumFr1ObjIdxItems);
                    _fr1ObjIdxItems.erase(_fr1ObjIdxItems.begin() + newNumFr1ObjIdxItems, _fr1ObjIdxItems.end());
                }
                FnVCCB_SetMGapDuDataWithMoInfoList(_rCi, rmGapDu, _fr1ObjIdxItems);
            }
        }

        if (true == _srvCellNrFr2)
        {
            VCCB_PRINT_CALL_COMMENT(&_rCi, "[m-gap] perFR: FR2 MO num(%lu) for DU\n", _fr2ObjIdxItems.size());
            if (0 < _fr2ObjIdxItems.size())
            {
                if (!isMrdc)
                {
                    const uint8_t newNumFr2ObjIdxItems = VCCB_AlternateMeasGap_FilterMeasObjects(_fr2ObjIdxItems);
                    VCCB_AlternateMeasGap_PrintRemoved(_fr2ObjIdxItems, newNumFr2ObjIdxItems);
                    _fr2ObjIdxItems.erase(_fr2ObjIdxItems.begin() + newNumFr2ObjIdxItems, _fr2ObjIdxItems.end());
                }
                FnVCCB_SetMGapDuDataWithMoInfoList(_rCi, rmGapDu, _fr2ObjIdxItems);
            }
        }
    }
    VCCB_AppendMeasFreqSnToMoListMgap(&_rCi, _rMeasProc.tgtCellNum, rmGapDu.moDuNew);
    const moListMgap_type &rMoDuInstalled = FnVCCB_GetMGapMoDuInstalled(_rCi);
    VCCB_FinalizeMoListMgap(rmGapDu.moDuNew, rMoDuInstalled);
    rmGapDu.moDuPreparedFlag = VCCB_FLAG_ON;

    return GOOD;
}

/****************************************************************************
 * @brief    Decide Measurement Gap configuration for NR-DC Secondary Node
 * @return int16_t        : result of operation
 ****************************************************************************/
int16_t VCCB_DecideMeasGapData::VCCB_SetMeasGapNRDC_SN()
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_VALID_GNBNUM_ERROR(_rCi.gnbNum);
    const gnbConfig_type &rGnbCfg = GNBINFO[_rCi.gnbNum].cfg;

    mGapCallConfiguration_type &rmGapConfig = _rCi.measurementsConfigShared.mGapConfiguration;
    uint32_t *ptFreqEnd = rmGapConfig.freqSnNew.frequencies;
    bool mnForcedPerUeGaps = false;

    // 3GPP 38.133 table 9.1.2-3
    if ((FALSE == _rCi.ueInfo.ueCapa.nr.nrdc.independentGapConfig_support) ||
        (VCCB_FLAG_OFF == rGnbCfg.measGap.indepGapEnabledNr) ||
        (true == (mnForcedPerUeGaps = VCCB_CheckMnForcedPerUeGapsForSn(&_rCi))))
    {
        VCCB_PRINT_CALL_COMMENT(&_rCi,
            "[m-gap] perUE gap indepGapConfigSupport(%u) indepGapEnabled(%u) mnForcedPerUeGaps(%u)\n",
            _rCi.ueInfo.ueCapa.nr.nrdc.independentGapConfig_support, rGnbCfg.measGap.indepGapEnabledNr,
            mnForcedPerUeGaps);

        // use per UE gaps
        if ((0 < _numFr1Items) || (0 < _numFr2Items) || (0 < _numIRatItems))
        {
            VCCB_PRINT_CALL_COMMENT(&_rCi, "[m-gap] perUE gap required for #FR1(%u), #FR2(%u), #IRAT(%u)\n",
                _numFr1Items, _numFr2Items, _numIRatItems);
            ptFreqEnd = std::copy(_fr1Items, _fr1Items + _numFr1Items, ptFreqEnd);
            ptFreqEnd = std::copy(_iRatItems, _iRatItems + _numIRatItems, ptFreqEnd);
            ptFreqEnd = std::copy(_fr2Items, _fr2Items + _numFr2Items, ptFreqEnd);
        }
        else
        {
            VCCB_PRINT_CALL_COMMENT(&_rCi, "[m-gap] perUE gap not required\n");
        }
    }
    else
    {
        // use per FR gaps
        if (true == _srvCellNrFr1)
        {
            if ((0 < _numFr1Items) || (0 < _numIRatItems))
            {
                // FR1
                VCCB_PRINT_CALL_COMMENT(
                    &_rCi, "[m-gap] perFR1 gap required for #FR1(%u), #IRAT(%u)\n", _numFr1Items, _numIRatItems);
                ptFreqEnd = std::copy(_fr1Items, _fr1Items + _numFr1Items, ptFreqEnd);
                ptFreqEnd = std::copy(_iRatItems, _iRatItems + _numIRatItems, ptFreqEnd);
            }
        }

        if (true == _srvCellNrFr2)
        {
            if (0 < _numFr2Items)
            {
                // FR2
                VCCB_PRINT_CALL_COMMENT(&_rCi, "[m-gap] perFR2 gap required for #FR2(%u)\n", _numFr2Items);
                ptFreqEnd = std::copy(_fr2Items, _fr2Items + _numFr2Items, ptFreqEnd);
            }
        }
    }

    rmGapConfig.freqSnNew.numItems =
        static_cast<uint8_t>(ptFreqEnd - rmGapConfig.freqSnNew.frequencies);
    std::sort(rmGapConfig.freqSnNew.frequencies, ptFreqEnd);

    return GOOD;
}

/****************************************************************************
 * @brief  Decide which of the initial meas objects to remove based on smtc window.
 *
 * @param  rMoInfoList       : meas object indexes to moUeItems which will be used to fill moDuNew
 * @return uint8_t           : new size of rMoInfoList
 ****************************************************************************/
uint8_t VCCB_DecideMeasGapData::VCCB_AlternateMeasGap_FilterMeasObjects(MoInfoList_type &rMoInfoList)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VAL(_rCi.gnbNum, MAX_GNB_PER_SYS, static_cast<uint8_t>(rMoInfoList.size()));

    const uint8_t featureFlag = GNBINFO[_rCi.gnbNum].cfg.measGap.alternateMeasGapConfig.enabled;
    if (featureFlag == VCCB_FLAG_OFF)
    {
        // if feature is disabled during alt gap operation we need to stop it
        if (AltGapStateWithoutPa4m_Idle != _rCi.measurementsConfigShared.altgap.stateWithoutPa4m)
        {
            SET_ALTGAP_STATE(&_rCi, AltGapStateWithoutPa4m_Idle);
        }

        return VCCB_AlternateMeasGap_FilterMeasObjects_FeatureOff(rMoInfoList);
    }

    return VCCB_AlternateMeasGap_FilterMeasObjects_FeatureOn(rMoInfoList);
}

/****************************************************************************
 * @brief  Get Meas Gap Configuration taking into consideration if gaps are needed for given meas object
 *
 * @param  rMoInfoList       : meas object indexes to moUeItems which will be used to fill moDuNew
 * @return MeasGapConfiguration
 ****************************************************************************/
VCCB_DecideMeasGapData::MeasGapConfiguration VCCB_DecideMeasGapData::VCCB_AlternateMeasGap_GetMeasGapConfiguration(
    const MoInfoList_type &rMoInfoList)
{
    AUTO_TRACE_FUNC;

    const measurementObjectUe_type(&moUeItems)[MAX_NR_OF_OBJECT_ID] = _rMeasProc.measurementObjects.newItems;
    const uint8_t numMoUeItems = _rMeasProc.measurementObjects.numNewItems;

    auto needsGap = [this, &moUeItems, numMoUeItems](uint8_t idx)
    {
        if ((numMoUeItems <= idx) || (MAX_NR_OF_OBJECT_ID <= idx))
        {
            VCCB_PRINT_CALL_ERROR(&_rCi, "ERROR: id = %d to measurementObjects.newItems array is too large!\n", idx);
            return false;
        }

        if (GOOD == VCCB_IsMeasObjectServingFreq(&_rCi, &moUeItems[idx]))
        {
            return false;
        }

        if (GOOD == VCCB_CheckMeasObjectNonServFreqNoNeedGapSA(&_rCi, &moUeItems[idx], _srvCellNrFr1, _srvCellNrFr2))
        {
            VCCB_PRINT_CALL_COMMENT(&_rCi, "MO ID(%d) no need gap\n", moUeItems[idx].objectId + 1);
            return false;
        }

        return true;
    };

    auto getSmtcWindow = [this, &moUeItems, numMoUeItems](uint8_t idx)
    {
        if ((numMoUeItems <= idx) || (MAX_NR_OF_OBJECT_ID <= idx))
        {
            VCCB_PRINT_CALL_ERROR(&_rCi, "ERROR: id = %d to measurementObjects.newItems array is too large!\n", idx);
            return SmtcWindow{};
        }

        return SmtcWindow(moUeItems[idx]);
    };

    auto only1HalfframeAndNeedsGap = [&needsGap, &getSmtcWindow](const MoInfo_s &rMoInfo)
    {
        uint8_t idx = rMoInfo._idx;
        if (!needsGap(idx))
        {
            return false;
        }

        SmtcWindow w{getSmtcWindow(idx)};
        if (!w.isValid())
        {
            return false;
        }
        return w.isOnlyInTheFirstHalfFrame();
    };

    auto only2HalfframeAndNeedsGap = [&needsGap, &getSmtcWindow](const MoInfo_s &rMoInfo)
    {
        uint8_t idx = rMoInfo._idx;
        if (!needsGap(idx))
        {
            return false;
        }

        SmtcWindow w{getSmtcWindow(idx)};
        if (!w.isValid())
        {
            return false;
        }
        return w.isOnlyInTheSecondHalfFrame();
    };

    const bool existOnly1HalfframeAndNeedsGap = std::any_of(rMoInfoList.begin(), rMoInfoList.end(), only1HalfframeAndNeedsGap);
    const bool existOnly2HalfframeAndNeedsGap = std::any_of(rMoInfoList.begin(), rMoInfoList.end(), only2HalfframeAndNeedsGap);

    if (existOnly1HalfframeAndNeedsGap && existOnly2HalfframeAndNeedsGap)
    {
        return MeasGapConfiguration::SmtcMixed;
    }
    if (existOnly1HalfframeAndNeedsGap)
    {
        return MeasGapConfiguration::Smtc1Halfframe;
    }
    if (existOnly2HalfframeAndNeedsGap)
    {
        return MeasGapConfiguration::Smtc2Halfframe;
    }
    return MeasGapConfiguration::Smtc2Halfframe;
}

/****************************************************************************
 * @brief  This function takes rMoInfoList array and
 *         put all elements matching halfframe argument in the beginning and all non
 *         matching elements past them. Return the number of matching elements.
 *
 *         Example:
 *         Before the call for halfframe == First
 *          objIdxItems = [x| ], [ |x], [x| ], [x|x]
 *         After the call
 *          objIdxItems = [x| ], [x| ], [x|x], [ |x]
 *          returned value = 3
 *
 * @param  rMoInfoList       : meas object indexes to moUeItems which will be used to fill moDuNew
 * @param  halfframe         : meas object with this halfframe will be left
 * @return uint8_t           : new size of rMoInfoList
 ****************************************************************************/
uint8_t VCCB_DecideMeasGapData::VCCB_AlternateMeasGap_LeaveThoseWithSmtcInXHalfframe(
    MoInfoList_type &rMoInfoList, SmtcHalfframe halfframe)
{
    AUTO_TRACE_FUNC;

    const measurementObjectUe_type(&moUeItems)[MAX_NR_OF_OBJECT_ID] = _rMeasProc.measurementObjects.newItems;
    const uint8_t numMoUeItems = _rMeasProc.measurementObjects.numNewItems;

    auto getSmtcWindow = [this, &moUeItems, numMoUeItems](uint8_t idx)
    {
        if ((numMoUeItems <= idx) || (MAX_NR_OF_OBJECT_ID <= idx))
        {
            VCCB_PRINT_CALL_ERROR(&_rCi, "ERROR: id = %d to measurementObjects.newItems array is too large!\n", idx);
            return SmtcWindow{};
        }

        return SmtcWindow(moUeItems[idx]);
    };

    auto isIn1Halfframe = [&getSmtcWindow](const MoInfo_s &rMoInfo)
    {
        SmtcWindow w{getSmtcWindow(rMoInfo._idx)};
        if (!w.isValid())
        {
            return false;
        }
        return w.isInTheFirstHalfFrame();
    };

    auto isIn2Halfframe = [&getSmtcWindow](const MoInfo_s &rMoInfo)
    {
        SmtcWindow w{getSmtcWindow(rMoInfo._idx)};
        if (!w.isValid())
        {
            return false;
        }
        return w.isInTheSecondHalfFrame();
    };

    auto begin = rMoInfoList.begin();
    auto end = rMoInfoList.end();
    auto beginFilteredOut = end;
    if (SmtcHalfframe::First == halfframe)
    {
        beginFilteredOut = std::partition(begin, end, isIn1Halfframe);
    }
    if (SmtcHalfframe::Second == halfframe)
    {
        beginFilteredOut = std::partition(begin, end, isIn2Halfframe);
    }

    return static_cast<uint8_t>(std::distance(begin, beginFilteredOut));
}
/****************************************************************************
 * @brief  Decide which of the initial meas objects to remove based on smtc window when feature is off
 *
 * @param  rMoInfoList       : meas object indexes to moUeItems which will be used to fill moDuNew
 * @return uint8_t           : new size of rMoInfoList
 ****************************************************************************/
uint8_t VCCB_DecideMeasGapData::VCCB_AlternateMeasGap_FilterMeasObjects_FeatureOff(MoInfoList_type &rMoInfoList)
{
    AUTO_TRACE_FUNC;

    const auto cfg = VCCB_AlternateMeasGap_GetMeasGapConfiguration(rMoInfoList);
    if (MeasGapConfiguration::Smtc1Halfframe == cfg)
    {
        return VCCB_AlternateMeasGap_LeaveThoseWithSmtcInXHalfframe(
            rMoInfoList, SmtcHalfframe::First);
    }
    return VCCB_AlternateMeasGap_LeaveThoseWithSmtcInXHalfframe(
        rMoInfoList, SmtcHalfframe::Second);
}

/****************************************************************************
* @brief  Change stateWithinPa4m based on its previous value, pa4m.state
*         and the fact that we there are meas object with different smtc windows
*
* @param  isAlternationNeeded   : flag indicating that alternate meas gap is needed as
                                  there are meas object with different smtc windows
****************************************************************************/
void VCCB_DecideMeasGapData::VCCB_AlternateMeasGap_DecideState_Pa4mOn(bool isAlternationNeeded)
{
    AUTO_TRACE_FUNC;

    const auto &pa4m = _rCi.measurementsConfigShared.pa4m;
    auto &state = _rCi.measurementsConfigShared.altgap.stateWithinPa4m;
    const uint8_t stateBefore = state;

    switch (pa4m.state)
    {
        case PeriodicMeasState_Idle:
        {
            break;
        }
        case PeriodicMeasState_ActiveIdle:
        {
            switch (state)
            {
                case AltGapStateWithinPa4m_Idle:
                    state = (isAlternationNeeded ? AltGapStateWithinPa4m_2Now : AltGapStateWithinPa4m_Idle);
                    break;
                default:
                    break;
            }
            break;
        }
        case PeriodicMeasState_InactiveIdle:
        {
            switch (state)
            {
                case AltGapStateWithinPa4m_Idle:
                    state = (isAlternationNeeded ? AltGapStateWithinPa4m_1Before : AltGapStateWithinPa4m_Idle);
                    break;
                default:
                    break;
            }
            break;
        }
        case PeriodicMeasState_Active:
        {
            switch (state)
            {
                case AltGapStateWithinPa4m_1Before:
                    state = (isAlternationNeeded ? AltGapStateWithinPa4m_2Now : AltGapStateWithinPa4m_Idle);
                    break;
                case AltGapStateWithinPa4m_2Before:
                    state = (isAlternationNeeded ? AltGapStateWithinPa4m_1Now : AltGapStateWithinPa4m_Idle);
                    break;
                case AltGapStateWithinPa4m_Idle:
                    state = (isAlternationNeeded ? AltGapStateWithinPa4m_2Now : AltGapStateWithinPa4m_Idle);
                    break;
                default:
                    break;
            }
            break;
        }
        case PeriodicMeasState_Inactive:
        {
            switch (state)
            {
                case AltGapStateWithinPa4m_1Now:
                    state = AltGapStateWithinPa4m_1Before;
                    break;
                case AltGapStateWithinPa4m_2Now:
                    state = AltGapStateWithinPa4m_2Before;
                    break;
                case AltGapStateWithinPa4m_Idle:
                    state = (isAlternationNeeded ? AltGapStateWithinPa4m_1Before : AltGapStateWithinPa4m_Idle);
                    break;
                default:
                    break;
            }
            break;
        }
        default:
            break;
    }

    VCCB_PRINT_CALL_COMMENT(&_rCi, "[m-gap] altgap.stateWithinPa4m old/new: %d/%d.\n", stateBefore, state);
}

/****************************************************************************
 * @brief  Decide which of the initial meas objects to remove based on smtc window when feature is on
 *
 * @param  rMoInfoList       : meas object indexes to moUeItems which will be used to fill moDuNew
 * @return uint8_t           : new size of rMoInfoList
 ****************************************************************************/
uint8_t VCCB_DecideMeasGapData::VCCB_AlternateMeasGap_FilterMeasObjects_FeatureOn(MoInfoList_type &rMoInfoList)
{
    AUTO_TRACE_FUNC;

    const auto cfg = VCCB_AlternateMeasGap_GetMeasGapConfiguration(rMoInfoList);
    const bool isAlternationNeeded = (MeasGapConfiguration::SmtcMixed == cfg);

    if (PeriodicMeasState_Idle == _rCi.measurementsConfigShared.pa4m.state)
    {
        VCCB_AlternateMeasGap_DecideState_Pa4mOff(isAlternationNeeded);
        const auto &altgap = _rCi.measurementsConfigShared.altgap;
        switch (altgap.stateWithoutPa4m)
        {
            case AltGapStateWithoutPa4m_1:
            case AltGapStateWithoutPa4m_1_Idle:
            {
                return VCCB_AlternateMeasGap_LeaveThoseWithSmtcInXHalfframe(rMoInfoList, SmtcHalfframe::First);
            }
            case AltGapStateWithoutPa4m_2:
            case AltGapStateWithoutPa4m_2_Idle:
            {
                return VCCB_AlternateMeasGap_LeaveThoseWithSmtcInXHalfframe(rMoInfoList, SmtcHalfframe::Second);
            }
            case AltGapStateWithoutPa4m_Idle:
            {
                if (MeasGapConfiguration::Smtc1Halfframe == cfg)
                {
                    return VCCB_AlternateMeasGap_LeaveThoseWithSmtcInXHalfframe(rMoInfoList, SmtcHalfframe::First);
                }
                if (MeasGapConfiguration::Smtc2Halfframe == cfg)
                {
                    return VCCB_AlternateMeasGap_LeaveThoseWithSmtcInXHalfframe(rMoInfoList, SmtcHalfframe::Second);
                }
                break;
            }
            default:
            {
                return static_cast<uint8_t>(rMoInfoList.size());
            }
        }
    }

    VCCB_AlternateMeasGap_DecideState_Pa4mOn(isAlternationNeeded);

    const auto &altgap = _rCi.measurementsConfigShared.altgap;
    switch (altgap.stateWithinPa4m)
    {
        case AltGapStateWithinPa4m_Idle:
        {
            if (MeasGapConfiguration::Smtc1Halfframe == cfg)
            {
                return VCCB_AlternateMeasGap_LeaveThoseWithSmtcInXHalfframe(rMoInfoList, SmtcHalfframe::First);
            }
            if (MeasGapConfiguration::Smtc2Halfframe == cfg)
            {
                return VCCB_AlternateMeasGap_LeaveThoseWithSmtcInXHalfframe(rMoInfoList, SmtcHalfframe::Second);
            }
            break;
        }
        case AltGapStateWithinPa4m_1Before:
        case AltGapStateWithinPa4m_2Before:
        {
            // filter all
            return 0;
        }
        case AltGapStateWithinPa4m_1Now:
        {
            return VCCB_AlternateMeasGap_LeaveThoseWithSmtcInXHalfframe(rMoInfoList, SmtcHalfframe::First);
        }
        case AltGapStateWithinPa4m_2Now:
        {
            return VCCB_AlternateMeasGap_LeaveThoseWithSmtcInXHalfframe(rMoInfoList, SmtcHalfframe::Second);
        }
        default:
        {
            break;
        }
    }

    return static_cast<uint8_t>(rMoInfoList.size());
}

/****************************************************************************
 * @brief  Debug function for printing smtc of removed elements from objIdxItems.
 *         Removed elements are in the range: numObjIdxItemsNew..numObjIdxItemsOld
 *
 * @param  rMoInfoList       : meas object indexes to moUeItems which will be used to fill moDuNew
 * @param  numObjIdxItemsNew : new number of elements in objIdxItems
 * @return uint8_t           : new size of rMoInfoList
 ****************************************************************************/
void VCCB_DecideMeasGapData::VCCB_AlternateMeasGap_PrintRemoved(
    const MoInfoList_type &rMoInfoList, const uint8_t numObjIdxItemsNew)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(numObjIdxItemsNew, rMoInfoList.size() + 1);

    const measurementObjectUe_type(&moUeItems)[MAX_NR_OF_OBJECT_ID] = _rMeasProc.measurementObjects.newItems;
    const uint8_t numMoUeItems = _rMeasProc.measurementObjects.numNewItems;

    auto getSmtcWindow = [&moUeItems, numMoUeItems](uint8_t idx)
    {
        if ((numMoUeItems <= idx) || (MAX_NR_OF_OBJECT_ID <= idx))
        {
            return SmtcWindow{};
        }

        return SmtcWindow(moUeItems[idx]);
    };

    std::for_each(rMoInfoList.begin() + numObjIdxItemsNew, rMoInfoList.end(),
        [this, &getSmtcWindow, &moUeItems, numMoUeItems](const MoInfo_s &rMoInfo)
        {
            uint8_t idx = rMoInfo._idx;
            SmtcWindow w{getSmtcWindow(idx)};
            if (!w.isValid())
            {
                return;
            }

            if ((numMoUeItems <= idx) || (MAX_NR_OF_OBJECT_ID <= idx))
            {
                return;
            }

            VCCB_PRINT_CALL_COMMENT(&_rCi, "[m-gap] MO f=%7d won't be available to DU. It's smtc window: %s.\n",
                VCCB_getArfcnFromMeasurementObject(moUeItems[idx].conf), w.print());
        });
}

/****************************************************************************
* @brief  Change stateWithoutPa4m based on its previous value, pa4m.state
*         and the fact that we there are meas object with different smtc windows
*
* @param  isAlternationNeeded   : flag indicating that alternate meas gap is needed as
                                  there are meas object with different smtc windows
****************************************************************************/
void VCCB_DecideMeasGapData::VCCB_AlternateMeasGap_DecideState_Pa4mOff(bool isAlternationNeeded)
{
    AUTO_TRACE_FUNC;

    auto &state = _rCi.measurementsConfigShared.altgap.stateWithoutPa4m;

    switch (state)
    {
        case AltGapStateWithoutPa4m_Idle:
            if (isAlternationNeeded)
            {
                SET_ALTGAP_STATE(&_rCi, AltGapStateWithoutPa4m_2);
            }
            break;
        case AltGapStateWithoutPa4m_2:
            if (!isAlternationNeeded)
            {
                SET_ALTGAP_STATE(&_rCi, AltGapStateWithoutPa4m_2_Idle);
            }
            break;
        case AltGapStateWithoutPa4m_1:
            if (!isAlternationNeeded)
            {
                SET_ALTGAP_STATE(&_rCi, AltGapStateWithoutPa4m_1_Idle);
            }
            break;
        case AltGapStateWithoutPa4m_2_Idle:
            if (isAlternationNeeded)
            {
                SET_ALTGAP_STATE(&_rCi, AltGapStateWithoutPa4m_2);
            }
            break;
        case AltGapStateWithoutPa4m_1_Idle:
            if (isAlternationNeeded)
            {
                SET_ALTGAP_STATE(&_rCi, AltGapStateWithoutPa4m_1);
            }
            break;
        default:
            break;
    }
}

/****************************************************************************
 * @brief  Merge _fr1ObjIdxItems and _fr2ObjIdxItems into _frxObjIdxItems
 ****************************************************************************/
void VCCB_DecideMeasGapData::VCCB_MergeFr1AndFr2ObjIdxItems()
{
    AUTO_TRACE_FUNC;

    _frxObjIdxItems = _fr1ObjIdxItems;
    for (std::size_t loop = 0; ((false == _frxObjIdxItems.full()) && (_fr2ObjIdxItems.size() > loop)); loop++)
    {
        _frxObjIdxItems.push_back(_fr2ObjIdxItems[loop]);
    }
}

/****************************************************************************
 * @brief    Decide Measurement Gap configuration
 * @return int16_t        : result of operation
 ****************************************************************************/
int16_t VCCB_DecideMeasGapData::VCCB_SetMeasGap()
{
    AUTO_TRACE_FUNC;

    if (E_CALLTYPE_NSA == _rCi.callType)
    {
        if (ERROR == VCCB_SetMeasGapENDC())
        {
            VCCB_PRINT_CALL_ERROR(&_rCi, "VCCB_SetMeasGapENDC ERROR!!\n");
            return ERROR;
        }
    }
    else if (IS_NRDC_SN(&_rCi))
    {
        if (ERROR == VCCB_SetMeasGapNRDC_SN())
        {
            VCCB_PRINT_CALL_ERROR(&_rCi, "VCCB_SetMeasGapNRDC_SN ERROR!!\n");
            return ERROR;
        }
    }
    else  // SA, Master Node for NE-DC, NR-DC
    {
        if (ERROR == VCCB_SetMeasGapSA())
        {
            VCCB_PRINT_CALL_ERROR(&_rCi, "VCCB_SetMeasGapSA ERROR!!\n");
            return ERROR;
        }
    }

    return GOOD;
}

/**
 * @brief    Check if no m-gap change required during SN Addition.
 */
bool VCCB_CheckNoMgapChangeDuringSnAdd(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);
    const gnbConfig_type &rGnbCfg = GNBINFO[ptCi->gnbNum].cfg;

    if (VCCB_FLAG_ON == rGnbCfg.forceMgapRelSnAdd)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "[m-gap] Ongoing SN Addition: ueCtxType(%u) forceMgapRelSnAdd(TRUE), gap release\n",
            ptCi->mrdcInfo.ueCtxType);
        return false;
    }

    const bool indepGapCfgOld = ptCi->ueInfo.ueCapa.nr.measAndMob.independentGapConfig;
    const bool indepGapCfgNew =
        ((UECTX_NEDC_MN == ptCi->mrdcInfo.ueCtxType) ? ptCi->ueInfo.ueCapa.mrdc.independentGapConfig_support
                                                     : ptCi->ueInfo.ueCapa.nr.nrdc.independentGapConfig_support);

    bool noGapChangeFlag = ((VCCB_FLAG_OFF == rGnbCfg.measGap.indepGapEnabledNr) || (indepGapCfgOld == indepGapCfgNew));

    if ((UECTX_NEDC_MN == ptCi->mrdcInfo.ueCtxType) && (true == noGapChangeFlag))
    {
        // (The leading / leftmost bit (bit 0) corresponds to the gap pattern 2,
        // the next bit corresponds to the gap pattern 3, as specified in TS 38.133 and so on.
        const uint32_t reqGpMask = 0x301000;  // GP: 2, 3, 11
        const bool suppGpFlag = (reqGpMask == (reqGpMask & ptCi->ueInfo.ueCapa.nr.measAndMob.supportedGapPattern));
        noGapChangeFlag =
            (((true == ptCi->ueInfo.ueCapa.nr.measAndMob.suppGapPatternNRonlyNEDCr16) && (true == suppGpFlag)) ||
                ((false == ptCi->ueInfo.ueCapa.nr.measAndMob.suppGapPatternNRonlyNEDCr16) && (false == suppGpFlag)));

        VCCB_PRINT_CALL_COMMENT(ptCi, "[m-gap] Ongoing SN Addition: suppGP(2,3,11) NR(%u)->NEDC(%u), %s\n", suppGpFlag,
            ptCi->ueInfo.ueCapa.nr.measAndMob.suppGapPatternNRonlyNEDCr16,
            (noGapChangeFlag ? "no gap change" : "gap release"));
    }
    else
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "[m-gap] Ongoing SN Addition: ueCtxType(%u) indepGapCfg old(%u)->new(%u) en(%u), %s\n",
            ptCi->mrdcInfo.ueCtxType, indepGapCfgOld, indepGapCfgNew, rGnbCfg.measGap.indepGapEnabledNr,
            (noGapChangeFlag ? "no gap change" : "gap release"));
    }

    return noGapChangeFlag;
}

/****************************************************************************
* @brief    Decide Measurement Gap configuration
            Function checks whether FR1 or FR2 gap configuration is required.
            Function operates on pending measurement configuration and confirmed Scell list.
            It shall be called after VLIB_CommitSecondaryCellList
            and before VCCB_CommitMeasurementReconfiguration.

* @param  ptCi           : pointer to UE Context
* @return int16_t        : result of operation
****************************************************************************/
int16_t VCCB_DecideMeasGap(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    mGapCallConfiguration_type &rmGapConfig = ptCi->measurementsConfigShared.mGapConfiguration;
    mGapDuData_type &rmGapDu = FnVCCB_GetMGapDuData(*ptCi);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    if (FLAG_OFF == rMeasProc.measConfigReadyFlag)
    {
        return BREAK;
    }
    rMeasProc.measConfigReadyFlag = FLAG_OFF;

    if (MAX_CELL_NUM_VCCB <= rMeasProc.tgtCellNum)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "MeasConfig not ready in VCCB_DecideMeasGap!\n");
        return BREAK;
    }

    if (IS_SN_ADDITION_ONGOING(ptCi))
    {
        if (VCCB_CheckNoMgapChangeDuringSnAdd(ptCi))
        {
            rmGapDu.moDuPreparedFlag = VCCB_FLAG_OFF;
            rmGapConfig.mGapLocalCtrlState = MGAPIdle;
            return BREAK;
        }

        // release mgap
        rmGapDu.moDuPreparedFlag = VCCB_FLAG_ON;
        rmGapConfig.mGapLocalCtrlState = MGAPReleasePending;
        rmGapConfig.freqSnNew.numItems = 0;
        rmGapDu.moDuNew.numItems = 0;

        // force removing M-GAP configuration on UE
        rmGapDu.mGapCfgNew.ue.flag = VCCB_FLAG_OFF;
        rmGapDu.mGapCfgNew.fr1.flag = VCCB_FLAG_OFF;
        rmGapDu.mGapCfgNew.fr2.flag = VCCB_FLAG_OFF;

        return GOOD;
    }

    if (IS_MRDC_MN(ptCi) &&
        (FnVCCB_IsMrdcInterMnHOWithoutSnAddition(ptCi) || FnVCCB_IsMrdcInterMnHOWithSnAddition(ptCi)))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[m-gap] Ongoing MRDC InterMN HO, no gap setup\n");
        return GOOD;
    }

    if (IS_NRDC_SNREL_INVOKED(ptCi))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[m-gap] MRDC SN release invoked, clear SN m-gap data\n");
        rmGapConfig.freqSnNew.numItems = 0;
    }

    // clear current configuration
    if ((E_CALLTYPE_NSA == ptCi->callType) || ((E_CALLTYPE_SA == ptCi->callType) && IS_NRDC_SN(ptCi)))
    {
        // Only for SN (EN-DC/NR-DC)
        rmGapConfig.freqSnNew.numItems = 0;
    }
    rmGapDu.moDuNew.numItems = 0;

    VCCB_DecideMeasGapData mgap(*ptCi);
    if (ERROR == mgap.VCCB_CheckMeasurementPurpose())
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_CheckMeasurementPurpose ERROR!!\n");
        return ERROR;
    }

    if (ERROR == mgap.VCCB_SetMeasGap())
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_SetMeasGap ERROR!!\n");
        return ERROR;
    }

    return GOOD;
}

/**
 * @brief     Commit DU's measurement object for M-gap
 * @param     ptCi : call context
 * @param     success : indicates if DU response (FALSE in case of Reject)
 */
void VCCB_CommitDuMo(callInfo_type *ptCi, uint8_t succes)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (FnVCCB_IsInterDuHoNonNrdcSn(*ptCi) || FnVCCB_IsLtmCandPrepForMeas(*ptCi))
    {
        // postpone commit to VHCM_FinalizeHandover / FnVCCB_CommitDuMoAfterDuChange
        return;
    }

    mGapCallConfiguration_type &rmGapConfig = ptCi->measurementsConfigShared.mGapConfiguration;
    mGapDuData_type &rmGapDu = FnVCCB_GetMGapDuData(*ptCi);

    // if not sent do not commit
    if (VCCB_FLAG_OFF == rmGapDu.moDuSentFlag)
    {
        return;
    }

    rmGapDu.moDuSentFlag = VCCB_FLAG_OFF;

    if (succes)
    {
        rmGapConfig.moDuInstalled = rmGapDu.moDuNew;
        rmGapConfig.mgrpPreference = rmGapDu.mgrpPreference;
        rmGapConfig.mrPurposeInfo = rmGapDu.mrPurposeInfo;
    }
    else
    {
        rmGapDu.moDuNew = rmGapConfig.moDuInstalled;
        rmGapDu.mgrpPreference = rmGapConfig.mgrpPreference;
        rmGapDu.mrPurposeInfo = rmGapConfig.mrPurposeInfo;
    }
}

int VCCM_CheckSupportEutraMeasObject_ForIratHo(callInfo_type *ptCi, measurementObjectEUTRABaseDb_type *ptMO,
    CellNum_type cellNum, enumMeasurementReportType reportType, uint8_t reportPurpose)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMO);

    if (GOOD != VCCB_CanMOAndRCBeAdded(ptCi, cellNum, reportType, reportPurpose, ptMO->carrierFreq))
    {
        return ERROR;
    }

    if (IS_NOT_SUPPORT_FALLBACK_FLAG_IN_MEASOBJ(ptCi, ptMO))
    {
        return ERROR;
    }

    if ((!IS_FALLBACK_CASE(ptCi)) && (!IS_RFSP_BLIND_INTER_RAT_REDIRECTION(ptCi)) )
    {
        // If there is no available neighbor cell, EUTRA measurement is not added.
        if (GOOD != VCCM_checkSaIRATAvailableNbr(ptCi, cellNum, ptMO))
        {
            return ERROR;
        }
    }

    return GOOD;
}

int VCCM_CheckSupportEutraMeasObject(callInfo_type *ptCi, measurementObjectEUTRADb_type *ptMO)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMO);

    if (ptMO->base.usage != CI_use)
    {
        return ERROR;
    }

    if (GOOD != VCCB_IsMeasObjectEutraEligibleForUe(ptCi, ptMO))
    {
        return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Prepare late sCellRelease measurements
 *
 * @param[in,out]   ptCi :          call information
 ****************************************************************************/
void VCCM_AddLateCaMeasurementsForScellRelease(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint16_t cellIdx = 0;
    Arfcn_type ssbArfcn = 0;

    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (cellIdx = 0; cellIdx < MAX_SCELL_PER_CALL; cellIdx++)
    {
        if ((SCELL_STATE_ADDED != scells[cellIdx].state) || (FALSE != scells[cellIdx].isActionQueued))
        {
            continue;
        }

        ssbArfcn = scells[cellIdx].ssbArfcn;

        if (ERROR == VCCB_AddLateMeasurement(ptCi, ssbArfcn, measReport_A2, a2Purpose_scellRelease,
                         FUN_2_MEASREPORTCALLBACKID(VLIB_CaProcessMrScellRelease)))
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "VCCB_AddLateMeasurement failed when installing measurement(A2) with "
                "purpose(ScellRelease) for ssbArfcn(%u)\n",
                ssbArfcn);
        }
        else
        {
            VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: Add Late A2 MR (idx:%d,ssbArfcn:%u,band:%d)\n", cellIdx, ssbArfcn,
                scells[cellIdx].bandNr);
        }
    }
}

/****************************************************************************
 * @brief           Prepare late sCellChange measurements
 *
 * @param[in,out]   ptCi :          call information
 ****************************************************************************/
void VCCM_AddLateCaMeasurementsForScellChange(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint16_t cellIdx = 0;
    Arfcn_type ssbArfcn = 0;

    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (cellIdx = 0; cellIdx < MAX_SCELL_PER_CALL; cellIdx++)
    {
        if ((SCELL_STATE_ADDED != scells[cellIdx].state) || (FALSE != scells[cellIdx].isActionQueued))
        {
            continue;
        }

        ssbArfcn = scells[cellIdx].ssbArfcn;

        if (ERROR == VCCB_AddLateMeasurement(ptCi, ssbArfcn, measReport_A6, a6Purpose_sCellChange,
                         FUN_2_MEASREPORTCALLBACKID(VLIB_CaProcessMrScellChange)))
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "VCCB_AddLateMeasurement failed when installing measurement(A6) with "
                "purpose(sCellChange) for ssbArfcn(%u)\n",
                ssbArfcn);
        }
        else
        {
            VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: Add Late A6 MR (idx:%d,ssbArfcn:%u,band:%d)\n", cellIdx, ssbArfcn,
                scells[cellIdx].bandNr);
        }
    }
}

/****************************************************************************
 * @brief           Prepare late sCellAddition measurements - in case when scell addition was rejected.
 *
 * @param[in,out]   ptCi :          call information
 ****************************************************************************/
void VCCM_AddLateCaMeasurementsForScellAddition(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (SCC_Triggered == ptCi->sccData.state)
    {
        VCCB_PRINT_LOG_CA_FUNC(ptCi, "[SCC] state = SCC_Triggered, skip A4 measurement (AddLateCaMeasurements) \n");
        return;
    }

    if (TRUE == ptCi->caInfo.suspendA4Meas)
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi,
            "CA: Current SCC is equal to or greater than the MAX SCC, skip A4 measurement (AddLateCaMeasurements) \n");
        return;
    }

    if (ptCi->caInfo.releaseCaA4ForVoNROn == TRUE)
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi,
                "CA: skip A4 measurement due to VoNR Setup (AddLateCaMeasurements) \n");
        return;
    }

    constexpr enumMeasurementReportType reportType = measReport_A4;
    constexpr uint8_t reportPurpose = a4Purpose_scellAddition;
    int16_t status = GOOD;

    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (uint16_t cellIdx = 0; cellIdx < MAX_SCELL_PER_CALL; ++cellIdx)
    {
        scellInfo_type &rSCell = scells[cellIdx];
        if ((SCELL_STATE_MRREL != rSCell.state) || (FALSE != rSCell.isActionQueued))
        {
            continue;
        }

        const Arfcn_type ssbArfcn = rSCell.ssbArfcn;
        if (VLIB_findCarrierCell(&ptCi->caInfo.failures, ssbArfcn) == GOOD)
        {
            VCCB_PRINT_LOG_CA_FUNC_TRACE(
                ptCi, "CA: ssbArfcn(%u) is on failedCarrier list, skip late measurement\n", ssbArfcn);
            continue;
        }

        if (VLIB_skipA4MeasconfForSCC(*ptCi, cellIdx))
        {
            VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] received A2 MR Scell (cellIdx : %d), skip measurement \n", cellIdx);
            continue;
        }

        if (TRUE == rSCell.shouldFollowA2Quantity)
        {
            status =
                VCCB_AddLateMeasurementIfPossibleWithForcedQuantity(ptCi, FnVCCB_GetMeasurementsProcedure(*ptCi).tgtCellNum,
                    reportType, reportPurpose, ssbArfcn, FUN_2_MEASREPORTCALLBACKID(VLIB_CaProcessMrScellAddition),
                    static_cast<enumMeasTriggerQuantityChoice>(rSCell.followA2Quantity));
            if (ERROR == status)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "VCCB_AddLateMeasurementIfPossibleWithForcedQuantity failed when installing "
                    "measurement(A4) with purpose(sCellAddition) for ssbArfcn(%u)\n",
                    ssbArfcn);
                continue;
            }
        }
        else
        {
            status = VCCB_AddLateMeasurement(
                ptCi, ssbArfcn, reportType, reportPurpose, FUN_2_MEASREPORTCALLBACKID(VLIB_CaProcessMrScellAddition));
            if (ERROR == status)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "VCCB_AddLateMeasurement failed when installing measurement(A4) with "
                    "purpose(sCellAddition) for ssbArfcn(%u)\n",
                    ssbArfcn);
                continue;
            }
        }

        if (status == GOOD)
        {
            VCCB_PRINT_LOG_CA_FUNC(
                ptCi, "CA: Add Late A4 MR (idx:%d,ssbArfcn:%u,band:%d)\n", cellIdx, ssbArfcn, rSCell.bandNr);
        }

        if ((GOOD == status) && (ptCi->sccData.state == SCC_MeasConf))
        {
            ONBIT_U32(ptCi->sccData.a4MrSetAndReceived, cellIdx);
            rSCell.sccFlag_cellMeasured = FALSE;
            VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] A4 MR setting (scellIdx(%d)/ssbFrequency(%d)/pci(%d) \n", cellIdx,
                rSCell.ssbArfcn, rSCell.pci);
        }
    }

    VCCB_PRINT_LOG_MCO_SCC(
        ptCi, "[SCC] A4 MR setting ( a4MrSetAndReceived : 0x%X )\n", ptCi->sccData.a4MrSetAndReceived);
}

/****************************************************************************
 * @brief           Prepare late sCellChange measurements
 *
 * @param[in,out]   ptCi :          call information
 ****************************************************************************/
void VCCM_AddLateCaMeasurementsPeriodical(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!VCCM_ShouldPeriodicalBeInstalled(ptCi))
    {
        return;
    }

    const uint16_t cellNum = FnVCCB_GetMeasurementsProcedure(*ptCi).tgtCellNum;
    VCCB_CHECK_VALID_CELLNUM_VOID(cellNum);

    if (GOOD == VCCB_AddLateMeasurement(ptCi, CELLINFO[cellNum].ssbArfcn, measReport_periodical,
                    periodicalPurpose_scellRelease, FUN_2_MEASREPORTCALLBACKID(VLIB_CaProcessMrPeriodical)))
    {
        VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: Late Periodical measurement added\n");
        ptCi->caInfo.isPeriodicalOngoing = TRUE;
    }
}

/****************************************************************************
 * @brief           Prepare late Inter RAT PCC measurements
 *
 * @param[in,out]   ptCi :          call information
 ****************************************************************************/
void VCCM_AddLateMeasurementsForInterRatPccChange(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const uint16_t cellNum = FnVCCB_GetMeasurementsProcedure(*ptCi).tgtCellNum;
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (TRUE != pGnb->multiCarrierOperation.interRatPccChange)
    {
        return;
    }

    if (!FnVCCB_CheckIfInterRatPccChangeCanOperate(ptCi, *pGnb))
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "[IRAT PCC] Late measurements will not be installed, IRAT PCC stopping!\n");
        SET_IRATPCC_STATE(ptCi, IRatPCCState_Idle);
        return;
    }

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    const mcoIratPccConfig_type config = FnVCCB_GetCurrentInterRatPccChangeConfig(*ptCi, *pGnb, *pCell);
    if (!config.iratPccChgUsage)
    {
        return;
    }

    uint32_t curBandwidthDl = 0;
    if (GOOD != VLIB_getSumOfBandwidthFromPcellAndInstalledScells(ptCi, &curBandwidthDl))
    {
        return;
    }

    const uint32_t dlLowBwThresholdForInterRat = static_cast<uint32_t>(config.dlBwThresholdForIratPccChg);
    VCCB_PRINT_CALL_COMMENT(ptCi, "[IRAT PCC] InterRAT curBW(%u), tgtBW(%u) BC(%u)\n",
        curBandwidthDl, dlLowBwThresholdForInterRat, VLIB_GetDuSelectionRelatedData(*ptCi).selectedBC);

    const bool ulTrafficDetected = (config.ulAwareThresholdUsageForIratPccChg &&
                                    ptCi->bitFlag.isUlTrfChkReportForIratHoReceived);
    if ((curBandwidthDl >= dlLowBwThresholdForInterRat) && !ulTrafficDetected)
    {
        return;
    }


    for (uint16_t objIdx = 0; objIdx < MAX_NR_OF_OBJECTEUTRA_ID_DB; ++objIdx)
    {
        measurementObjectEUTRADb_type *ptMO = &pCell->measurementsData.measurementObjectsEUTRADb[objIdx];
        measurementObjectEUTRABaseDb_type *ptMOBase = &ptMO->base;

        if (GOOD != VCCM_CheckSupportEutraMeasObject(ptCi, ptMO))
        {
            continue;
        }

        auto typeAndPurpose = FnVCCB_DecideInterRatPccChangeReportTypeAndPurpose(*ptMOBase);
        if (GOOD !=
            VCCM_CheckSupportEutraMeasObject_ForIratHo(ptCi, ptMOBase, ptCi->servCellNum, typeAndPurpose.type, typeAndPurpose.purpose))
        {
            continue;
        }

        if (ERROR == VCCB_AddLateMeasurement(ptCi, ptMOBase->carrierFreq, typeAndPurpose.type, typeAndPurpose.purpose,
                         FUN_2_MEASREPORTCALLBACKID(VCCM_ProcMrInterRatHandover)))
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "VCCB_AddLateMeasurement failed when installing measurement(B1) with "
                "purpose(capabilityAwareCarrierChange) for ssbArfcn(%u)\n",
                ptMOBase->carrierFreq);
        }
    }
}

/****************************************************************************
 * @brief           Prepare additional Measurement Configuration (after SCell modification)
 *
 * @param[in,out]   ptCi :          call information
 * @return          status :        GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_PrepareAdditionalMeasurementConfig(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    // for CA operation
    if ((FLAG_ON == ptCi->caInfo.lateCaMeasurements) || (CaMod_cmd == ptCi->stateCmd))
    {
        if (CaOperation_Mode2 == ptCi->caInfo.mode)
        {
            if (TRUE == ptCi->caInfo.mode2AnyScellReleased)
            {
                VCCM_AddLateCaMeasurementsForScellAddition(ptCi);
            }
            VCCM_AddLateCaMeasurementsForScellRelease(ptCi);
        }
        else if ((CaOperation_Mode3 == ptCi->caInfo.mode) || (CaOperation_Mode5 == ptCi->caInfo.mode))
        {
            VCCM_AddLateCaMeasurementsForScellAddition(ptCi);
            VCCM_AddLateCaMeasurementsForScellRelease(ptCi);
            VCCM_AddLateCaMeasurementsForScellChange(ptCi);
        }
        else if (CaOperation_Mode4 == ptCi->caInfo.mode)
        {
            VCCM_AddLateCaMeasurementsForScellChange(ptCi);
        }

        VCCM_AddLateCaMeasurementsPeriodical(ptCi);
    }
    // for Mobility operation
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);
    if (FLAG_ON == rMeasProc.lateFreqPrioMeas)
    {
        VCCM_AddLateFreqPrioScellToPscellSwitchMeas(ptCi);
    }
    if (FLAG_ON == rMeasProc.lateLbMeas)
    {
        VCCM_AddLateLoadBalancingMeasurementNsa(*ptCi);
    }

    // SA FPHO(CaAwareHandover) for Mobility operation
    if (FLAG_ON == rMeasProc.caAwareMeasNeeded)
    {
        VCCB_AddCaAwareHandoverMeasurementBySCellChange(ptCi);
    }

    if (IRatPCCState_Gathering == ptCi->pccData.interRatState)
    {
        VCCM_AddLateMeasurementsForInterRatPccChange(ptCi);
    }

    return GOOD;
}

/****************************************************************************
 * @brief   Check if MeasGapConfig is configured.
 *          In case SA or MRDC-MN or ENDC-SN perFR2 mgap:
 *              - information is valid after reception of RrcReconfigurationComplete message from UE.
 *          In case NRDC-SN or ENDC-SN perUE/perFR1 mgap
 *              - information is valid after reception of recent CG-ConfigInfo->measConfigMN message from master node.
 *
 * @param   ptCi           : pointer to UE Context
 * @return  int16_t        : status : TRUE - Set, FALSE - Not Set
 ****************************************************************************/
bool VCCB_IsMeasGapConfigSet(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    const mGapCfgNode_type &rmGapCfgInstalled = FnVCCB_GetMeasurementsConfiguration(*ptCi).mGapCfgInstalled;
    const measConfigMN_type &rMeasConfigMN = ptCi->cgConfigInfo.measConfigMN;

    // If one of gapFR2, gapFR1 or gapUE is configured
    if (E_CALLTYPE_NSA == ptCi->callType)
    {
        return ((VCCB_FLAG_ON == rMeasConfigMN.measGapConfigFR1.flag) ||
                (VCCB_FLAG_ON == rmGapCfgInstalled.fr2.flag));
    }
    else if (IS_NRDC_SN(ptCi))
    {
        return ((VCCB_FLAG_ON == rMeasConfigMN.measGapConfigFR1.flag) ||
                (VCCB_FLAG_ON == rMeasConfigMN.measGapConfigFR2.flag));
    }
    else
    {
        return ((VCCB_FLAG_ON == rmGapCfgInstalled.fr2.flag) ||
                (VCCB_FLAG_ON == rmGapCfgInstalled.fr1.flag) ||
                (VCCB_FLAG_ON == rmGapCfgInstalled.ue.flag));
    }

    return false;
}

/****************************************************************************
 * @brief           Get Rfsp Specific DelTa Threshold for ReportConfig
 *
 * @param[in]       ptCi          : Pointer to call configuration. / callInfo_type*
 * @param[in]       pReportConfig : Pointer to UE report config / reportConfigurationConfUe_type *
 * @param[in]       cellNum       : served cell num or target cell num
 * @param[in]       pMeasObject   : Pointer to UE meas object / minimalMeasObjectConfUe_type *
 * @return          pointer to rfsp threshold delta structure.
 *                  If NULL is returned then no rfsp threshold delta should be applied.
 ****************************************************************************/
const rfspThresholdDelta_type *VCCB_GetRfspDeltasForReportConfig(callInfo_type *ptCi,
    const reportConfigurationConfUe_type *pReportConfig, CellNum_type cellNum,
    const minimalMeasObjectConfUe_type *pMeasObject, const uint8_t svcGrpIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULLPTR(ptCi);
    VALID_E_POINT_CHECK_NULLPTR(pReportConfig);
    VALID_E_POINT_CHECK_NULLPTR(pMeasObject);
    VCCB_CHECK_E_RANGE_AND_NULLPTR(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_NULLPTR(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_NULLPTR(svcGrpIdx, MAX_SVC_GRP_DB_NUM);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    rfspBasedCtrlSpecific_type *pRfsp = nullptr;

    auto isPreventingApplyRfspSpecificDelta = [ptCi, svcGrpIdx]() -> bool
    {
        gnbConfig_type *const pGnbCfg = &GNBINFO[ptCi->gnbNum].cfg;
        return (pGnbCfg->svcGrpBasedCfg[svcGrpIdx].usage == CI_use &&
                pGnbCfg->svcGrpBasedCfg[svcGrpIdx].preventingRfspSpecificDeltaCfg == TRUE);
    };

    if (isPreventingApplyRfspSpecificDelta()) return nullptr;

    pRfsp = FnVCCB_isRfspSpecificUE(ptCi, cellNum);
    if (nullptr == pRfsp)
    {
        return nullptr;
    }

    if (GOOD !=
        VCCB_CheckRfspSpecificSupportPurposeCheck(ptCi, pReportConfig->reportType, pReportConfig->reportPurpose))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "VCCB_GetRfspDeltasForReportConfig(): Rfsp Delta is discarded due to unsupported reportType(%d) and "
            "reportPurpose(%d).\n",
            pReportConfig->reportType, pReportConfig->reportPurpose);
        return nullptr;
    }

    uint8_t rfsp_faIdx = MAX_NUM_RFSP_FREQS;
    if (measRatNr == pMeasObject->ratType)
    {
        for (rfsp_faIdx = 0; rfsp_faIdx < MAX_NUM_RFSP_FREQS; rfsp_faIdx++)
        {
            if (CI_use != pRfsp->nrFreqItems[rfsp_faIdx].usage) continue;
            if (pRfsp->nrFreqItems[rfsp_faIdx].targetMeasObjectEntriesindex >= MAX_NR_OF_OBJECT_ID_DB) continue;

            uint8_t moIdx = pRfsp->nrFreqItems[rfsp_faIdx].targetMeasObjectEntriesindex;
            measurementObjectNRBaseDb_type *ptMO = &(pCell->measurementsData.measurementObjectsNRDb[moIdx].base);

            if (ptMO->usage != CI_use) continue;
            if (pMeasObject->rat.nr.ssbFrequency != ptMO->ssbFrequency) continue;

            return &pRfsp->nrFreqItems[rfsp_faIdx].deltaTh;
        }
    }
    else
    {  // EUTRA
        for (rfsp_faIdx = 0; rfsp_faIdx < MAX_NUM_RFSP_FREQS; rfsp_faIdx++)
        {
            if (CI_use != pRfsp->eutraFreqItems[rfsp_faIdx].usage) continue;
            if (pRfsp->eutraFreqItems[rfsp_faIdx].targetMeasObjectEntriesindex >= MAX_NR_OF_OBJECTEUTRA_ID_DB) continue;

            uint8_t moIdx = pRfsp->eutraFreqItems[rfsp_faIdx].targetMeasObjectEntriesindex;
            measurementObjectEUTRABaseDb_type *ptMO = &(pCell->measurementsData.measurementObjectsEUTRADb[moIdx].base);

            if (ptMO->usage != CI_use) continue;
            if (pMeasObject->rat.eutra.carrierFreq != ptMO->carrierFreq) continue;

            return &pRfsp->eutraFreqItems[rfsp_faIdx].deltaTh;
        }
    }
    return nullptr;
}

/****************************************************************************
 * @brief           Finds measurementIdentitiy related to given reportType and reportPurpose and returns its objectId,
 *                  if no such elementcan be found INVALID_OBJECT_ID constant is returned.
                    This can only be called after VCCB_ApplyNewMeasConfig
 *
 * @param[in]       rCi                   : Reference to call configuration. / callInfo_type
 * @param[in]       frequency             : frequency
 * @param[in]       reportType            : reportType
 * @param[in]       reportPurpose   : reportPurpose
 * @return          objectId of found measurementIdentity or INVALID_OBJECT_ID / uint8_t
 ****************************************************************************/
uint8_t VCCB_FindMatchingMeasIdInMeasProcedure(
    const callInfo_type &rCi, Arfcn_type frequency, enumMeasurementReportType reportType, uint8_t reportPurpose)
{
    AUTO_TRACE_FUNC;

    const measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(rCi);
    const auto &mo_newItems = rMeasProc.measurementObjects;
    const auto &rc_newItems = rMeasProc.reportConfigurations;
    const auto &mi_newItems = rMeasProc.measurementIdentities;

    for (const auto &mi : rangeAdaptors::filtered(
             mi_newItems.newItems, [](const measurementIdentity_type &x) { return x.usage == CI_use; }))
    {
        const uint8_t moItemIndex = mi.moNewItemIdx;
        const uint8_t rcItemIndex = mi.rcNewItemIdx;

        if ((MIN(mo_newItems.numNewItems, MAX_NR_OF_OBJECT_ID) <= moItemIndex) ||
            (MIN(rc_newItems.numNewItems, MAX_NR_OF_REPORT_CONFIG_ID) <= rcItemIndex))
        {
            VCCB_PRINT_CALL_ERROR(&rCi, "ERROR: Invalid measObjIdx(%u) or rptCfgIdx(%u)!\n", moItemIndex, rcItemIndex);
            continue;
        }

        const auto &newMo = mo_newItems.newItems[moItemIndex];
        const auto &newRc = rc_newItems.newItems[rcItemIndex];

        if (newMo.usage != CI_use)
        {
            VCCB_PRINT_CALL_ERROR(
                &rCi, "ERROR: measObject(%u) under measId(%u) is not installed!\n", newMo.objectId, mi.objectId);
            continue;
        }
        if (newRc.usage != CI_use)
        {
            VCCB_PRINT_CALL_ERROR(
                &rCi, "ERROR: reportConfig(%u) under measId(%u) is not installed!\n", newRc.objectId, mi.objectId);
            continue;
        }

        bool isMoMatched = frequency == (newMo.conf.ratType == measRatNr ? newMo.conf.rat.nr.minimal.ssbFrequency
                                                                         : newMo.conf.rat.eutra.minimal.carrierFreq);
        bool isRcMatched = newRc.conf.reportType == reportType && newRc.conf.reportPurpose == reportPurpose;

        if (isMoMatched && isRcMatched)
        {
            return mi.objectId;
        }
    }

    return INVALID_OBJECT_ID;
}

uint8_t fnVCCB_IsSaCapableMO(callInfo_type *ptCi, const measurementObjectNRBaseDb_type *pMeasObjNr)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(pMeasObjNr);

    if (TRUE != pMeasObjNr->saCapable)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[fnVCCB_IsSaCapableMO] saCapable is not TRUE\n");
        return FALSE;
    }

    if (IS_REDCAP_UE(ptCi))
    {
        if (pMeasObjNr->redcapAccessAllowed != TRUE)
        {
            VCCB_PRINT_CALL_COMMENT(
                ptCi, "[fnVCCB_IsSaCapableMO] redcapAccessAllowed is not TRUE for MO: %u\n", pMeasObjNr->ssbFrequency);
            return FALSE;
        }
    }

    return TRUE;
}

/****************************************************************************
 *  ** @brief           Get Measurement Object Index for Freq Auto Config
 *   **
 *    ** @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 *     ** @return          status : GOOD, ERROR / int16_t
 *      *****************************************************************************/
int16_t VCCB_getMeasObjIdxFreqAutoConfig(callInfo_type *ptCi, CellNum_type cellNum, Arfcn_type ssbFrequency)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    measurementsData_type *pDbConf = &(pCell->measurementsData);

    /*measObjDbIdx value is 20 for intra frequency*/
    uint8_t measObjDbIdx = findIdxOfMatchingMeasObjectNr(VCCB_FrequencyMatcher(ssbFrequency, RSType_SSB), *pDbConf);
    if (VCCB_ARRAY_COUNT(pDbConf->measurementObjectsNRDb) <= measObjDbIdx)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Couldn't find meas object with freq(%u) and rsType(%u) for cell(%u)!\n",
            ssbFrequency, RSType_SSB, cellNum);
        return ERROR;
    }
    if (measObjDbIdx == INTRAFREQ_OBJECT_IDX)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Freq Auto Config: Not updating for intra frequency\n");
        return GOOD;
    }
    pCell->facMeasResult[measObjDbIdx].ssbFreq = ssbFrequency;
    pCell->facMeasResult[measObjDbIdx].measConfigCount++;
    VCCB_PRINT_CALL_COMMENT(ptCi,
        "Freq Auto Config measConfigCount (%d) with measObjDbIdx (%d), updated for ssb frequency (%d)! \n",
        pCell->facMeasResult[measObjDbIdx].measConfigCount, measObjDbIdx, pCell->facMeasResult[measObjDbIdx].ssbFreq);

    return GOOD;
}

/****************************************************************************
 * @brief           This function is a function that acquires the quality of Report Config.
 *
 * @param[in]       pReportConfig               : Pointer to report config to be installed on UE /
 *reportConfigurationConfUe_type *
 * @return                                      : {choice_rsrp, choice_rsrq, choice_sinr, 0xFF}
 ****************************************************************************/
uint8_t FnVCCB_GetReportConfigQuantitySaHo(const reportConfigurationConfUe_type *pReportConfig)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(pReportConfig, 0xFF);

    auto &currentEvent_NR = pReportConfig->reportConfiguration.eventBased.event;
    auto &currentEvent_EUTRA = pReportConfig->reportConfiguration.eventInterRat.event;

    switch (pReportConfig->reportType)
    {
        case measReport_A1:
        {
            return currentEvent_NR.A1.a1_Threshold.quantity;
        }
        case measReport_A2:
        {
            return currentEvent_NR.A2.a2_Threshold.quantity;
        }
        case measReport_A3:
        {
            return currentEvent_NR.A3.a3_Offset.quantity;
        }
        case measReport_A4:
        {
            return currentEvent_NR.A4.a4_Threshold.quantity;
        }
        case measReport_A5:
        {
            return currentEvent_NR.A5.a5_Thresholds.quantity;
        }
        case measReport_A6:
        {
            return currentEvent_NR.A6.a6_Offset.quantity;
        }
        case measReport_B1Eutra:
        {
            return currentEvent_EUTRA.B1Eutra.b1_thresholdEUTRA.quantity;
        }
        case measReport_B2Eutra:
        {
            return currentEvent_EUTRA.B2Eutra.b2_thresholds.quantity;
        }
        default:
        {
            return 0xFF;
        }
    }
}

FreqBandInd_type VCCB_GetBandOfMatchingMeasObjectNR(
    const measurementsConfiguration_type &rMeasConf, const Arfcn_type ssbFreq)
{
    for (uint8_t idx = 0; idx < VCCB_ARRAY_COUNT(rMeasConf.measurementObjects.installedItems); idx++)
    {
        const measurementObjectUe_type &ptMO = rMeasConf.measurementObjects.installedItems[idx];
        if (ptMO.usage != CI_use) continue;
        if (ptMO.conf.ratType != measRatNr) continue;
        if (ptMO.conf.rat.nr.minimal.ssbFrequency != ssbFreq) continue;

        return ptMO.conf.rat.nr.minimal.freqBandIndicatorNR;
    }
    return BAND_NOT_FOUND;
}

void VCCB_ClearCondTriggerConfigFromMeasConfiguration(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_ClearMeasConfigurationAssociatedWithReportConfig(ptCi, VCCB_isAssociatedWithCondTriggerConfig);
}

// SVR24A FGR-MC1023 FR30
/****************************************************************************
 * @brief           Check whether UE is RFSP Specific UE.
 *
 * @param[in]       ptCi      : Pointer to call configuration. / callInfo_type*
 * @param[in]       cellNum   : served cell num or target cell num
 * @return          rfspBasedCtrlSpecific_type
 ****************************************************************************/
rfspBasedCtrlSpecific_type *FnVCCB_isRfspSpecificUE(callInfo_type *ptCi, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULLPTR(ptCi);
    VCCB_CHECK_E_RANGE_AND_NULLPTR(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    rfspBasedCtrlSpecific_type *pRfsp = nullptr;

    uint8_t servPlmnIndex = 0;

    /* Check SA and cellRfspSpecificMeasCtrl.rfspSpecificUsage */
    if ((E_CALLTYPE_SA != ptCi->callType) || (CI_use != pCell->cellRfspSpecificMeasCtrl.rfspSpecificUsage))
    {
        return nullptr;
    }

    /* Check UE has valid rfsp value, if not valid, return */
    if ((GOOD != VLIB_getMultipleGnbPlmnIndexInfo(ptCi, &servPlmnIndex, ptCi->ueInfo.servedPlmn.longId)) ||
        (OPT_PRESENT != ptCi->ueInfo.rfsp.rfspPresent) || (NO_RFSP_VALUE == ptCi->ueInfo.rfsp.indexToRFSP))
    {
        return nullptr;
    }

    /* Check UE has valid Rfsp Specific MeasConf value, if not valid, return */
    if (GOOD != VCCB_GetRfspSpecificMeasConf(
                    ptCi, cellNum, servPlmnIndex, static_cast<uint16_t>(ptCi->ueInfo.rfsp.indexToRFSP), &pRfsp))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Could not find valid RfspSpecificMeasConf value \n");
        return nullptr;
    }

    /* Check if pRfsp is valid, if not valid, return */
    if (nullptr == pRfsp)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "pRfsp is not initialized!\n");
        return nullptr;
    }

    return pRfsp;
}

// SVR24A FGR-MC1022 FR130
bool FnVCCB_IsCaAwareHandoverByA2Condition(
    callInfo_type *ptCi, uint16_t cellNum, enumMeasurementReportType reportType, uint8_t reportPurpose)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);
    const VccbCellInfo_type *const pSourceCellInfo = &CELLINFO[cellNum];

    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (uint16_t cellIdx = 0; cellIdx < MAX_SCELL_PER_CALL; cellIdx++)
    {
        if (SCELL_STATE_ADDED != scells[cellIdx].state)
        {
            continue;
        }

        VCCB_RptCfgAndMeasObjDbFinder finder(
            CELLINFO[cellNum].measurementsData, reportType, reportPurpose, scells[cellIdx].ssbArfcn);
        if (false == finder.isValid())
        {
            VCCB_PRINT_LOG_FP_MC(ptCi,
                "(FPMC) Couldn't find rptCfg(type(%d) purpose(%hu)) measObj(freq(%u)) cellNum(%u)\n", reportType,
                reportPurpose, scells[cellIdx].ssbArfcn, cellNum);

            // return false;
            continue;
        }

        if (finder._ratType != measRatNr || finder._measObjectDbFinder._pDbObjNr == nullptr)
        {
            VCCB_PRINT_LOG_FP_MC(ptCi,
                "(FPMC) IsCaAwareHandoverByA2Condition (ratType != measRatNr or nullptr)\n");
            continue;
        }

        VCCB_PRINT_LOG_FP_MC(ptCi,
            "(FPMC) IsCaAwareHandoverByA2Condition "
            "(scell)(index:%d/scellIdx:%d/ssbFreq:%u/pci:%u/saCapable:%d/A2HoAllowed:%d/cgi.ci:%lu)\n",
            cellIdx, scells[cellIdx].sCellIndex, scells[cellIdx].ssbArfcn, scells[cellIdx].pci,
            finder._measObjectDbFinder._pDbObjNr->base.saCapable,
            finder._measObjectDbFinder._pDbObjNr->base.caAwareScellToPcellChangeByA2HoAllowed,
            scells[cellIdx].cgi.ci);

        if (finder._measObjectDbFinder._pDbObjNr->base.saCapable != TRUE) continue;
        if (finder._measObjectDbFinder._pDbObjNr->base.caAwareScellToPcellChangeByA2HoAllowed != true) continue;

        uint16_t nbrIdx = VLIB_GetNbrIdxBasedOnCgi(pSourceCellInfo, scells[cellIdx].cgi);
        if (nbrIdx < MAX_NBR_PER_CELL)
        {
            return true;
        }
    }
    return false;
}

bool FnVCCB_GetA2MultiTriggerFeatureEnabled(measurementsData_type &rDbConf, uint8_t reportPurpose, Arfcn_type freq)
{
    VCCB_RptCfgAndMeasObjDbFinder finder(rDbConf, measReport_A2, reportPurpose, freq);

    if (!finder.isValid()) return false;

    return finder._pDbRpt->base.reportConfigExtension.eventBased.event.A2.multipleTriggerFeatureEnabled;
}

bool FnVCCB_IsA4ScellAdditionUseAllowedCellsListSet(callInfo_type &rCi, CellNum_type cellNum, Arfcn_type freq)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);
    const auto reportType = measReport_A4;
    const auto reportPurpose = a4Purpose_scellAddition;
    VCCB_RptCfgAndMeasObjDbFinder finder(CELLINFO[cellNum].measurementsData, reportType, reportPurpose, freq);
    if (!VCCB_ValidateMeasObjectAndReportConfigCandidates(rCi, finder, cellNum, reportType, reportPurpose, freq))
    {
        return false;
    }
    if (finder._pDbRpt == nullptr)
    {
        return false;
    }
    return finder._pDbRpt->base.reportConfigExtension.eventBased.event.A4.useAllowedCellList;
}

// SVR24A FGR-MC1022
bool FnVCCB_IsScellNbrRelationCellBySsbFreq(callInfo_type *ptCi, uint16_t cellNum, uint32_t ssbFreq)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);
    const VccbCellInfo_type *const pSourceCellInfo = &CELLINFO[cellNum];

    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (uint16_t idx = 0; idx < MAX_SCELL_PER_CALL; ++idx)
    {
        if (SCELL_STATE_ADDED != scells[idx].state)
        {
            continue;
        }
        if (ssbFreq != scells[idx].ssbArfcn) continue;

        uint16_t nbrIdx = VLIB_GetNbrIdxBasedOnCgi(pSourceCellInfo, scells[idx].cgi);
        if (nbrIdx < MAX_NBR_PER_CELL)
        {
            return true;
        }
    }
    return false;
}

int16_t FnVCCB_CreateMeasObjectCandidate(callInfo_type &rCall, const enumMeasurementReportType reportType,
    const uint8_t reportPurpose, const CellNum_type cellNum, const Arfcn_type ssbArfcn,
    minimalMeasObjectConfUe_type &measObjectCandidateOut)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    VCCB_MeasObjDbFinder finder(CELLINFO[cellNum].measurementsData, measRatNr, ssbArfcn);
    if (false == finder.isValid())
    {
        VCCB_PRINT_CALL_COMMENT(&rCall, "Couldn't find measObj(freq(%u)) cellNum(%u)\n", ssbArfcn, cellNum);
        return ERROR;
    }

    if (!VCCB_CanMeasObjBeAdded(rCall, cellNum, finder, reportType, reportPurpose))
    {
        return BREAK;
    }

    if (!VCCB_PrepareMeasObjectUeCandidate(rCall, cellNum, finder, &measObjectCandidateOut))
    {
        return BREAK;
    }

    return GOOD;
}

int16_t FnVCCB_CreateMeasObjectCandidateForServingCell(callInfo_type &rCall, const enumMeasurementReportType reportType,
    const uint8_t reportPurpose, const CellNum_type cellNum, minimalMeasObjectConfUe_type &measObjectCandidateOut)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    return FnVCCB_CreateMeasObjectCandidate(
        rCall, reportType, reportPurpose, cellNum, CELLINFO[cellNum].ssbArfcn, measObjectCandidateOut);
}

int16_t FnVCCB_CreateA2ReportConfigCandidate(callInfo_type &rCall, const CellNum_type cellNum,
    const uint8_t reportPurpose, enumMeasTriggerQuantityChoice thresholdQuantity, int8_t thresholdValue,
    uint8_t reportInterval, uint8_t reportAmount, const minimalMeasObjectConfUe_type &measObjectCandidate,
    reportConfigurationConfUe_type &reportConfigCandidateOut)
{
    if ((choice_sinr == thresholdQuantity) && !CAN_UE_REPORT_SINR(&rCall, measObjectCandidate.rat.nr.ssbFrequency))
    {
        VCCB_PRINT_CALL_ERROR(
            &rCall, "FnVCCB_CreateA2ReportConfigCandidate() triggered with SINR quantity. UE not supported SINR.\n");
        return ERROR;
    }

    memset(&reportConfigCandidateOut, 0, sizeof(reportConfigCandidateOut));
    reportConfigCandidateOut.reportType = measReport_A2;
    reportConfigCandidateOut.reportPurpose = reportPurpose;
    reportConfigCandidateOut.rsType = RSType_SSB;
    reportConfigCandidateOut.reportInterval = reportInterval;
    reportConfigCandidateOut.reportAmount = reportAmount;
    reportConfigCandidateOut.maxReportCells = 8;
    reportConfigCandidateOut.reportQuantityCell.rsrp = CI_use;
    reportConfigCandidateOut.reportQuantityCell.rsrq = CI_use;
    reportConfigCandidateOut.reportQuantityCell.sinr = CI_no_use;

    reportConfigCandidateOut.rat.nr.includeBeamMeasurements = false;
    reportConfigCandidateOut.rat.nr.maxNrOfRsIndexesToReport.usage = CI_no_use;
    reportConfigCandidateOut.rat.nr.reportQuantityRsIndexes.usage = CI_no_use;

    reportConfigCandidateOut.fr1PCState = {};
    reportConfigCandidateOut.measObjectSelection = ALL_MEASOBJECT_SELECTION;

    auto &ueEventBased = reportConfigCandidateOut.reportConfiguration.eventBased;
    ueEventBased.addNeighMeas = true;
    ueEventBased.useT312 = false;
    ueEventBased.multipleMeasurementQuantitySupport = false;
    ueEventBased.reportOnLeave = false;
    ueEventBased.hysteresis = 0;
    ueEventBased.timeToTrigger = NRRRC_TimeToTrigger_ms480;

    ueEventBased.event.A2.a2_Threshold.quantity = thresholdQuantity;
    ueEventBased.event.A2.a2_Threshold.value = thresholdValue;
    if (choice_sinr == thresholdQuantity)
    {
        ueEventBased.event.A2.a2_ThresholdOrigin.quantityInfo.isTriggeringOptionSinr = true;
    }
    ueEventBased.event.A2.a2_ThresholdOrigin.quantityInfo.triggeringOption = thresholdQuantity;

    ueEventBased.event.A2.a2_ThresholdOrigin.values.value_rsrp = 39;
    ueEventBased.event.A2.a2_ThresholdOrigin.values.value_rsrq = 81;
    ueEventBased.event.A2.a2_ThresholdOrigin.values.value_sinr = 81;
    ueEventBased.event.A2.multipleTriggerQuantityEnabled = false;

    VCCB_HandlePowerClassDeltas(&rCall, &reportConfigCandidateOut, measObjectCandidate, cellNum);

    return GOOD;
}

reportConfigurationConfUe_type FnVCCB_CreatePeriodicReportConfigCandidate(
    const uint8_t reportPurpose, uint8_t reportInterval, uint8_t reportAmount)
{
    reportConfigurationConfUe_type reportConfigCandidate;
    memset(&reportConfigCandidate, 0, sizeof(reportConfigCandidate));
    reportConfigCandidate.reportType = measReport_periodical;
    reportConfigCandidate.reportPurpose = reportPurpose;
    reportConfigCandidate.rsType = RSType_SSB;
    reportConfigCandidate.reportInterval = reportInterval;
    reportConfigCandidate.reportAmount = reportAmount;
    reportConfigCandidate.maxReportCells = 8;
    reportConfigCandidate.reportQuantityCell.rsrp = CI_use;
    reportConfigCandidate.reportQuantityCell.rsrq = CI_use;
    reportConfigCandidate.reportQuantityCell.sinr = CI_no_use;

    reportConfigCandidate.rat.nr.includeBeamMeasurements = false;
    reportConfigCandidate.rat.nr.maxNrOfRsIndexesToReport.usage = CI_no_use;
    reportConfigCandidate.rat.nr.reportQuantityRsIndexes.usage = CI_no_use;

    reportConfigCandidate.fr1PCState = {};
    reportConfigCandidate.measObjectSelection = ALL_MEASOBJECT_SELECTION;

    reportConfigCandidate.reportConfiguration.periodical.useWhiteCellList = FALSE;

    return reportConfigCandidate;
}

void FnVCCB_SetIncludeBeamMeas(reportConfigurationConfUe_type &rcCandidate)
{
    rcCandidate.rat.nr.includeBeamMeasurements = true;
}

void FnVCCB_SetReportQuantityRsIndexes(
    reportConfigurationConfUe_type &rcCandidate, const reportQuantity_type reportQuantity)
{
    rcCandidate.rat.nr.reportQuantityRsIndexes.usage = CI_use;
    rcCandidate.rat.nr.reportQuantityRsIndexes.reportQuantity = reportQuantity;
}

void FnVCCB_SetMaxNrOfRsIndexesToReport(
    reportConfigurationConfUe_type &rcCandidate, const uint8_t maxNrOfRsIndexesValue)
{
    rcCandidate.rat.nr.maxNrOfRsIndexesToReport.usage = CI_use;
    rcCandidate.rat.nr.maxNrOfRsIndexesToReport.value = maxNrOfRsIndexesValue & e_BitMask_6bit;
}

/****************************************************************************
 * @brief           Description
 *
 *                  If provided arguments are invalid returns ERROR.
 *                  If the conditions are not met returns BREAK.
 *                  If the conditions are met returns GOOD and add measurement.
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in]       cellNum : Cell number. / uint16_t
 * @param[in]       reportType : Type of the target report configuration. / enumMeasurementReportType
 * @param[in]       reportPurpose : Purpose of the target report configuration. / uint8_t
 * @param[in]       frequency : Frequency to measure (SSB or CSI-RS). / Arfcn_type/uint32_t
 * @param[in]       callbackFuncId : Function to call when measurement report for
 *                                   this measurement identity is received. / enumMeasReportCallbackId_type
 * @param[in]       forcedQuantity : Stored quantity choice / enumMeasTriggerQuantityChoice
 * @return          status : GOOD, BREAK, ERROR / int16_t
 ****************************************************************************/
int16_t VCCB_AddLateMeasurementIfPossibleWithForcedQuantity(callInfo_type *ptCi, CellNum_type cellNum,
    const enumMeasurementReportType reportType, const uint8_t reportPurpose, Arfcn_type frequency,
    enumMeasReportCallbackId_type callbackFuncId, enumMeasTriggerQuantityChoice forcedQuantity)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(rMeasProc.tgtCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(
        rMeasProc.measurementObjects.numNewItems, VCCB_ARRAY_COUNT(rMeasProc.measurementObjects.newItems));

    // Adding new MeasObjects in this function is not supported! There is no VCCB_ApplyMeasObjectConfig in
    // VCCB_PrepareAdditionalMeasConfig.
    measurementObjectUe_type *pUeObj = NULL;
    if (measRatEutra == VCCB_GetRatType(reportType))
    {
        pUeObj = std::find_if(&(rMeasProc.measurementObjects.newItems[0]),
            &(rMeasProc.measurementObjects.newItems[rMeasProc.measurementObjects.numNewItems]),
            VCCB_OverlappedFrequencyMatcherEutra(frequency));
    }
    else
    {
        pUeObj = std::find_if(&(rMeasProc.measurementObjects.newItems[0]),
            &(rMeasProc.measurementObjects.newItems[rMeasProc.measurementObjects.numNewItems]),
            VCCB_FrequencyMatcher(frequency, RSType_SSB));
    }
    if (pUeObj == &(rMeasProc.measurementObjects.newItems[rMeasProc.measurementObjects.numNewItems]))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "MeasObject configuration with frequency(%u) not scheduled!\n", frequency);

        return BREAK;
    }

    return VCCB_AddMeasurementIfPossibleWithForcedQuantity(*ptCi, cellNum, reportType, reportPurpose, frequency,
               callbackFuncId, forcedQuantity) == AddMeasurementStatus::MEAS_IDS_ADDED
               ? GOOD
               : BREAK;
}

smtc1_type FnVCCB_GetEffectiveSmtc1(
    callInfo_type &rCall, CellNum_type cellNum, const measurementObjectNRBaseDb_type &dbObject)
{
    AUTO_TRACE_FUNC;

    minimalMeasObjectNRUe_type ueObject;
    ueObject.ssbFrequency = dbObject.ssbFrequency;
    ueObject.ssbSubcarrierSpacing = dbObject.ssbSubcarrierSpacing;
    VCCB_SetSmtc1AndItsOrigin(&rCall, cellNum, ueObject, dbObject);

    return ueObject.smtc1;
}

/****************************************************************************
 * @brief           Modify report Configuration. Set IncludeCommonLocationInfo request:
 *                  - for MDT Trace to get GNSS coordinates in MR
 *
 * @param[in]       ptCi : Pointer to call configuration. / callInfo_type*
 * @param[in/out]   pUeRpt : Pointer to ue candidate report configuration. / reportConfigurationConfUe_type*
 * @param[in]       cellNum : Cell number to be configured.
 ****************************************************************************/
void VCCB_ModifyReportConfiguration_IncludeCommonLocationInfo(
    callInfo_type *ptCi, reportConfigurationConfUe_type *pUeRpt, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pUeRpt);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    MdtSessionConfiguration_type &rMdtSessionCfg = CELLINFO[cellNum].traceSession.mdt.mdtSessionConfiguration;
    bool mdtM1Requested = ptCi->managementTraceInfo.mdtInfo.mdtStatus.ueActFlag;
    bool gnssRequested = rMdtSessionCfg.immediate.measurements.m1.gnssPositioning;
    bool activationExistingRrm = rMdtSessionCfg.immediate.measurements.m1.activationExistingRrm;

    // Signaling MDT has higher priority than Management MDT
    if (mdtImmediate == ptCi->signalingTraceInfo.mdt.mdtStatus)
    {
        mdtM1Requested = ptCi->signalingTraceInfo.mdt.config.immediate.measConfigFlags.m1Flag;
        gnssRequested = ptCi->signalingTraceInfo.mdt.config.immediate.measConfigFlags.locationInfo;
        activationExistingRrm = ptCi->signalingTraceInfo.mdt.config.immediate.measConfigFlags.m1RrmFlag;
    }

    // [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
    // FR90 : VCCB shall support GNSS location information configuration and collection for M1

    if (mdtM1Requested && gnssRequested &&                                 // GNSS reporting required
        TRUE == ptCi->ueInfo.ueCapa.nr.ueBasedPerfMeasParam.gnssLocation)  // And supported by UE
    {
        switch (pUeRpt->reportType)
        {
            case measReport_periodical:
                if (periodicalPurpose_mdt == pUeRpt->reportPurpose ||
                    true == activationExistingRrm)
                {
                    pUeRpt->rat.nr.includeCommonLocationInfo_r16 = CI_use;
                }
                break;
            case measReport_A2:
                if (a2Purpose_mdt == pUeRpt->reportPurpose || a2Purpose_triggerPeriodicMdt == pUeRpt->reportPurpose ||
                    true == activationExistingRrm)
                {
                    pUeRpt->rat.nr.includeCommonLocationInfo_r16 = CI_use;
                }
                break;
            case measReport_periodicalInterRat:
                if (periodicalInterRATPurpose_mdt == pUeRpt->reportPurpose ||
                    true == activationExistingRrm)
                {
                    pUeRpt->rat.nr.includeCommonLocationInfo_r16 = CI_use;
                }
                break;
            case measReport_A1:
            case measReport_A3:
            case measReport_A4:
            case measReport_A5:
            case measReport_A6:
            case measReport_B1Eutra:
            case measReport_B2Eutra:
                if (true == activationExistingRrm)
                {
                    pUeRpt->rat.nr.includeCommonLocationInfo_r16 = CI_use;
                }
                break;
            default:;  // N/A
        }
    }
}

/****************************************************************************
 * @brief           This function answers the question if there is any NCD-SSB available under
 *                  ncd-ssb-config/cd-to-ncd-mapping-entries[cd-ssb-freq=RedCapUe.pcellMeasObject.ssb] different than
 *                  RedCapUe.pcellMeasObject.ssb. As a result return array with NcdSsbEntry mapped to PCell frequency.
 *
 * @param[in]       rCi : reference to call configuration. / callInfo_type&
 * @return          ncdSsbFrequenciesForPcell /simpleVecotr<NcdSsbFreqEntry_type>
 ****************************************************************************/
NcdSsbFreqEntries VCCB_GetNcdSsbInterFrequenciesForRedCapUeIntraFrequency(const callInfo_type &rCi)
{
    NcdSsbFreqEntries ncdSsbFrequenciesForPcell{};
    if (!VCCB_IsRedCapUeForSA(rCi))
    {
        return ncdSsbFrequenciesForPcell;
    }

    VCCB_CHECK_E_RANGE_AND_VAL(rCi.gnbNum, MAX_GNB_PER_SYS, ncdSsbFrequenciesForPcell);
    const auto &gnb = GNBINFO[rCi.gnbNum];
    const measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(rCi);
    const auto pcellMeasObjectIdx = rMeasProc.tgtCellNewMoIdx;
    const auto &newMeasObjects = rMeasProc.measurementObjects;

    if (pcellMeasObjectIdx >= util::minOfArraySizeAndNumOfElems(newMeasObjects.newItems, newMeasObjects.numNewItems))
    {
        VCCB_PRINT_CALL_ERROR(
            &rCi, "[RedCapUe][NCD-SSB] Invalid index (%d) of meas object for PCell!\n", pcellMeasObjectIdx);
        return ncdSsbFrequenciesForPcell;
    }

    const minimalMeasObjectNRUe_type &pcellMeasObject = newMeasObjects.newItems[pcellMeasObjectIdx].conf.rat.nr.minimal;
    const auto pcellCdSsb = pcellMeasObject.ssbFrequency;
    const auto effectivePcellSsb = FnVCCB_GetRrcMeasObjectNrSsbFrequency(pcellMeasObject);
    if (auto ncdIndex = VCCB_FindCdToNcdMappingIdx(gnb.ncdSsbConfig, pcellCdSsb); ncdIndex)
    {
        for (const auto &ncdSsbEntry : gnb.ncdSsbConfig.cdToNcdMappingEntries[ncdIndex.value()].ncdSsbFreqEntries)
        {
            if (ncdSsbEntry.usage != CI_use)
            {
                continue;
            }

            if (ncdSsbEntry.ncdSsbFreq == effectivePcellSsb)
            {
                continue;
            }

            // to avoid ping-pong handovers NCD-SSB with the same value as PCell CD-SSB is not allowed
            if (ncdSsbEntry.ncdSsbFreq == pcellCdSsb)
            {
                continue;
            }

            VCCB_PRINT_CALL_COMMENT(&rCi,
                "[RedCapUe][NCD-SSB] Found NCD-SSB (%d) which is inter frequency for PCell.\n", ncdSsbEntry.ncdSsbFreq);
            ncdSsbFrequenciesForPcell.push_back(ncdSsbEntry);
        }
    }

    return ncdSsbFrequenciesForPcell;
}

/****************************************************************************
 * @brief           Add Measurement for RedCap UE in case mobility
 * @param[in]       rCi : Reference to call configuration. / callInfo_type*
 * @param[in]       cellNum : Cell number. / uint16_t
 * @param[in]       reportType : Type of the target report configuration. / enumMeasurementReportType
 * @param[in]       reportPurpose : Purpose of the target report configuration. / uint8_t
 * @param[in]       frequency : Frequency to measure (CD-SSB or CSI-RS). / Arfcn_type/uint32_t
 * @param[in]       callbackFuncId : Function to call when measurement report for
 *                                   this measurement identity is received. / enumMeasReportCallbackId_type
 * @return          status : INSTALL_PREP_FAILED, NO_MEAS_ID_ADDED, MEAS_IDS_ADDED / AddMeasurementStatus
 ****************************************************************************/
AddMeasurementStatus VCCB_AddMeasurementForRedCapUeMobilitySa(callInfo_type &rCi, CellNum_type cellNum,
    enumMeasurementReportType reportType, uint8_t reportPurpose, Arfcn_type frequency,
    enumMeasReportCallbackId_type callbackFuncId)
{
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, AddMeasurementStatus::INSTALL_PREP_FAILED);
    const auto &cell = CELLINFO[cellNum];
    reportConfigurationConfUe_type reportConfigCandidate;
    minimalMeasObjectConfUe_type measObjectCandidate;

    if (!VCCB_CanMOAndRCBeAddedWithCandidates(
            rCi, cellNum, reportType, reportPurpose, frequency, &reportConfigCandidate, &measObjectCandidate))
        return AddMeasurementStatus::INSTALL_PREP_FAILED;

    auto status = AddMeasurementStatus::NO_MEAS_ID_ADDED;
    for (const auto &ncdSsb : VCCB_GetNcdSsbInterFrequenciesForRedCapUeIntraFrequency(rCi))
    {
        VCCB_UpdateInterFreqMeasObjectCandidateForNcdSsb(rCi, ncdSsb, measObjectCandidate.rat.nr);
        if (GOOD == VCCB_AddMeasurement(&rCi, cellNum, &reportConfigCandidate, &measObjectCandidate, callbackFuncId))
        {
            VCCB_PRINT_CALL_COMMENT(&rCi,
                "[RedCapUe][NCD-SSB] added VCCB_AddMeasurement for Intra NrHandover %u (cdssb: %u)\n",
                ncdSsb.ncdSsbFreq, cell.ssbArfcn);
            status = AddMeasurementStatus::MEAS_IDS_ADDED;
        }
    }

    return status;
}

int8_t VCCB_PrepareRfspDeltaThreshold(bool isRedcapUe, uint8_t quantity, rfspDeltaTh_type deltaThreshold)
{
    rfspDeltaTh_type delta = deltaThreshold;
    if (isRedcapUe)
    {
        delta = FnVCCB_PrepareRfspThresholdDeltaValues(deltaThreshold);
        // if (delta != deltaThreshold)
        {
            // add debug print
        }
    }

    int8_t deltaValue = 0;
    switch (quantity)
    {
        case choice_rsrp:
            deltaValue = delta.deltaThRsrp;
            break;
        case choice_rsrq:
            deltaValue = delta.deltaThRsrq;
            break;
        case choice_sinr:
            deltaValue = delta.deltaThSinr;
            break;
        default:
            break;
    }

    return deltaValue;
}

/****************************************************************************
 * @brief           Find measurement object NR in measurement procedure using meas object candidate SSB frequency.
 *                  If found returns pointer to an element in newItems array.
 *                  Otherwise returns nullptr.
 ****************************************************************************/
measurementObjectUe_type *FnVCCB_FindNRMeasObjectInMeasProc(
    measurementsProcedure_type &rMeasProc, const minimalMeasObjectNRUe_type &rUeMoCandidate)
{
    AUTO_TRACE_FUNC;

    const Arfcn_type frequency = FnVCCB_GetRrcMeasObjectNrSsbFrequency(rUeMoCandidate);
    auto beginNew = &(rMeasProc.measurementObjects.newItems[0]);
    auto endNew = &(rMeasProc.measurementObjects.newItems[util::minOfArraySizeAndNumOfElems(
        rMeasProc.measurementObjects.newItems, rMeasProc.measurementObjects.numNewItems)]);
    measurementObjectUe_type *pUeObj = std::find_if(beginNew, endNew, VCCB_FrequencyMatcher(frequency, RSType_SSB));
    if (pUeObj != endNew)
    {
        return pUeObj;
    }
    return nullptr;
}

int16_t FnVCCB_AllocateIdsForAllowedCells(
    measurementsProcedure_type &rMeasProc, const measurementsConfiguration_type &rMeasConf)
{
    for (uint8_t i = 0;
        i < util::minOfArraySizeAndNumOfElems(rMeasProc.measurementObjects.newItems, rMeasProc.measurementObjects.numNewItems); ++i)
    {
        auto &newMo = rMeasProc.measurementObjects.newItems[i];
        if (newMo.conf.ratType != measRatNr)
        {
            continue;
        }

        pciRangeElements_type &newPciRanges = newMo.conf.rat.nr.minimal.allowedCells;
        if (newPciRanges.numOfPciRanges == 0)
        {
            continue;
        }

        const pciRangeElements_type emptyPciRanges{};
        const pciRangeElements_type *installedPciRanges = &emptyPciRanges;

        // If there is already installed meas object use its allowed cells to to compute the diff
        if (newMo.internalIdx < MAX_NR_OF_OBJECT_ID)
        {
            installedPciRanges =
                &rMeasConf.measurementObjects.installedItems[newMo.internalIdx].conf.rat.nr.minimal.allowedCells;
        }

        constexpr int MinPciRangeIndex = 1;
        constexpr int MaxPciRangeIndex = 8;
        util::ConsecutiveIdsPool<MinPciRangeIndex, MaxPciRangeIndex> pool{};

        // Match with already installed
        constexpr uint8_t TO_BE_INSTALLED_PCI_RANGE_INDEX = 0;
        for (uint8_t j = 0; j < util::minOfArraySizeAndNumOfElems(newPciRanges.pciRanges, newPciRanges.numOfPciRanges); j++)
        {
            auto &newPciRange = newPciRanges.pciRanges[j];
            newPciRange.pciRangeIndex = TO_BE_INSTALLED_PCI_RANGE_INDEX;
            for (uint8_t k = 0; k < util::minOfArraySizeAndNumOfElems(installedPciRanges->pciRanges, installedPciRanges->numOfPciRanges); k++)
            {
                const auto &installedPciRange = installedPciRanges->pciRanges[k];
                if (newPciRange.pci == installedPciRange.pci)
                {
                    newPciRange.pciRangeIndex = installedPciRange.pciRangeIndex;
                    pool.occupy(installedPciRange.pciRangeIndex);
                    break;
                }
            }
        }

        // Assign the rest
        for (uint8_t j = 0; j < util::minOfArraySizeAndNumOfElems(newPciRanges.pciRanges, newPciRanges.numOfPciRanges); j++)
        {
            auto &newPciRange = newPciRanges.pciRanges[j];
            if (newPciRange.pciRangeIndex != TO_BE_INSTALLED_PCI_RANGE_INDEX)
            {
                continue;
            }
            auto newIndex = pool.take();
            if (newIndex.has_value() == false)
            {
                VCCB_PRINT_ERROR("ERROR: PciRange pool out of indexes!\n");
                return ERROR;
            }
            newPciRange.pciRangeIndex = static_cast<uint8_t>(newIndex.value());
        }
    }
    return GOOD;
}

void FnVCCB_AddAllowedCellsToMeasObjectCandidate(
    minimalMeasObjectConfUe_type &measObject, const simpleVector<uint16_t, MAX_NR_OF_PCI_RANGES> &pciList)
{
    if (measObject.ratType != measRatNr)
    {
        return;
    }
    auto &allowedCells = measObject.rat.nr.allowedCells;
    for (uint16_t pci : pciList)
    {
        if (util::findObjectIfExist(allowedCells.pciRanges, allowedCells.numOfPciRanges,
                [pci](const pciRangeElement_type &pciRange) { return pciRange.pci == pci; }) == util::NOT_FOUND)
        {
            if (allowedCells.numOfPciRanges >= MAX_NR_OF_PCI_RANGES)
            {
                VCCB_PRINT_COMMENT("%s: Cannot add more allowed cells!\n", __FUNCTION__);
                return;
            }
            VCCB_PRINT_COMMENT("%s: Allowed cell added. PCI(%u)\n", __FUNCTION__, pci);
            allowedCells.pciRanges[allowedCells.numOfPciRanges++].pci = pci;
        }
    }
}
