#include "FeatMeasurementsForHighSpeedUe.hpp"
#include "FeatMeasCommon.hpp"
#include "FeatSpeedState.hpp"
#include "FeatCommon.h"
#include <array>

namespace
{
constexpr std::array<unsigned int, 16> TTT_VALUES = {
    0, 40, 64, 80, 100, 128, 160, 256, 320, 480, 512, 640, 1024, 1280, 2560, 5120};

constexpr std::array<double, 4> SCALING_FACTORS = {0.25, 0.5, 0.75, 1.0};
constexpr unsigned int defaultTTTIndex = TTT_VALUES.size() - 1;

constexpr unsigned int getIndexOfTheFirstNotLessTTT(unsigned int value)
{
    unsigned int size = static_cast<unsigned int>(TTT_VALUES.size());
    for (unsigned int i = 0; i < size; ++i)
    {
        if (TTT_VALUES[i] >= value)
        {
            return i;
        }
    }

    return defaultTTTIndex;  // last index
}

constexpr auto buildTable()
{
    std::array<std::array<unsigned int, TTT_VALUES.size()>, SCALING_FACTORS.size()> table{};

    for (std::size_t i = 0; i < SCALING_FACTORS.size(); i++)
    {
        for (std::size_t j = 0; j < TTT_VALUES.size(); j++)
        {
            unsigned int scaled = static_cast<unsigned int>(TTT_VALUES[j] * SCALING_FACTORS[i]);
            table[i][j] = getIndexOfTheFirstNotLessTTT(scaled);
        }
    }
    return table;
}

constexpr auto TABLE = buildTable();

enumTimeToTrigger computeHighSpeedTttScaling(enumTimeToTrigger ttt, enumTimeToTriggerScalingFactor_type scalingFactor)
{
    AUTO_TRACE_FUNC;

    size_t tttIndex = static_cast<size_t>(ttt);
    size_t scalingIndex = static_cast<size_t>(scalingFactor);

    if (tttIndex >= TTT_VALUES.size() || scalingIndex >= SCALING_FACTORS.size())
    {
        VCCB_PRINT_ERROR("ERROR: tttIndex: %zu or scalingIndex: %zu out of range\n", tttIndex, scalingIndex);
        return enumTimeToTrigger::timeToTrigger_ms5120;
    }

    return static_cast<enumTimeToTrigger>(TABLE[scalingIndex][tttIndex]);
}

enum class ReportCategory : uint8_t
{
    InterRat = 0,
    IntraRat = 1,
    Unknown = 2
};

ReportCategory getReportCategory(uint8_t reportType)
{
    switch (reportType)
    {
        case measReport_A1:
        case measReport_A2:
        case measReport_A3:
        case measReport_A4:
        case measReport_A5:
        case measReport_A6:
            return ReportCategory::IntraRat;
        case measReport_B1Eutra:
        case measReport_B2Eutra:
            return ReportCategory::InterRat;
        default:
            return ReportCategory::Unknown;
    }
}

/****************************************************************************
 * @brief           Scaling TimeToTrigger if UE is in High Speed
 *
 * @param[in]       call     : reference to the current call type info
 * @param[in/out]   ueRpt    : reference to ue candidate report configuration. / reportConfigurationConfUe_type*
 * @param[in]       dbObject : reference to DB version of report config / reportConfigurationBaseDb_type
 * @return          void
 ****************************************************************************/
void VCCB_ModifyTimeToTrigger_HighSpeed(
    const callInfo_type &call, reportConfigurationConfUe_type &ueRpt, const reportConfigurationBaseDb_type &dbObject)
{
    AUTO_TRACE_FUNC;

    const auto reportTypeEvent = getReportCategory(ueRpt.reportType);

    enumTimeToTrigger scaledTtt{timeToTrigger_ms0};
    if (reportTypeEvent == ReportCategory::IntraRat)
    {
        uint8_t scaling = dbObject.reportConfigExtension.eventBased.timeToTriggerScalingFactor;
        uint8_t ttt = ueRpt.reportConfiguration.eventBased.timeToTrigger;
        scaledTtt = computeHighSpeedTttScaling(
            static_cast<enumTimeToTrigger>(ttt), static_cast<enumTimeToTriggerScalingFactor_type>(scaling));
        ueRpt.reportConfiguration.eventBased.timeToTrigger = static_cast<uint8_t>(scaledTtt) & e_BitMask_4bit;
    }
    else if (reportTypeEvent == ReportCategory::InterRat)
    {
        uint8_t scaling = dbObject.reportConfigExtension.eventInterRat.timeToTriggerScalingFactor;
        uint8_t ttt = ueRpt.reportConfiguration.eventInterRat.timeToTrigger;
        scaledTtt = computeHighSpeedTttScaling(
            static_cast<enumTimeToTrigger>(ttt), static_cast<enumTimeToTriggerScalingFactor_type>(scaling));
        ueRpt.reportConfiguration.eventInterRat.timeToTrigger = static_cast<uint8_t>(scaledTtt) & e_BitMask_4bit;
    }
    else
    {
        return;
    }

    VCCB_PRINT_CALL_MEASUREMENTS(&call, "Field %s.timeToTrigger was set to:(%d)\n",
        (reportTypeEvent == ReportCategory::IntraRat ? "eventBasedReportConfigurationNR_type"
                                                     : "eventInterRatReportConfigurationNR_type"),
        scaledTtt);
}

void VCCB_ModifyA2Threshold_HighSpeed(
    const callInfo_type &call, reportConfigurationConfUe_type &ueRpt, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    if (ueRpt.reportType != measReport_A2)
    {
        return;
    }

    const VccbCellInfo_type &cell = CELLINFO[cellNum];
    int16_t delta = 0;
    const enumMeasTriggerQuantityChoice quantity =
        static_cast<enumMeasTriggerQuantityChoice>(ueRpt.reportConfiguration.eventBased.event.A2.a2_Threshold.quantity);
    switch (quantity)
    {
        case choice_rsrp:
            delta = cell.highSpeedUeMobility.a2DeltaThreshold.rsrp;
            break;
        case choice_rsrq:
            delta = cell.highSpeedUeMobility.a2DeltaThreshold.rsrq;
            break;
        case choice_sinr:
            delta = cell.highSpeedUeMobility.a2DeltaThreshold.sinr;
            break;
        default:
            delta = 0;
            break;
    }

    VCCB_ModifySelectedThresholds_ApplyDelta(
        &call, ueRpt.reportConfiguration.eventBased.event.A2.a2_Threshold.value, delta);
}

}  // namespace

void VCCB_ModifyReportConfig_HighSpeedUe(const callInfo_type &call, reportConfigurationConfUe_type &ueRpt,
    const reportConfigurationBaseDb_type &dbObject, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;

    if (ueSpeedState_High != UeSpeedState::VCCB_GetUeSpeedState(call, cellNum))
    {
        return;
    }

    const VccbCellInfo_type &cell = CELLINFO[cellNum];
    if (false == cell.highSpeedUeMobility.featureEnabled)
    {
        VCCB_PRINT_CALL_MEASUREMENTS(&call, "High Speed Ue Mobility feature is DISABLED");
        return;
    }

    VCCB_ModifyTimeToTrigger_HighSpeed(call, ueRpt, dbObject);
    VCCB_ModifyA2Threshold_HighSpeed(call, ueRpt, cellNum);
}
