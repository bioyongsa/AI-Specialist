#include "FeatMeasResultList2NRIterator.hpp"
#include "FeatCa.hpp"
#include "ComGlobalData.h"
#include "ComLibUtility.h"

///////////////////////////////////////////////
// VCCB_MeasResultList2NRIterator
///////////////////////////////////////////////

void VCCB_MeasResultList2NRIterator::IterateAndVisit(
    const measResultList2NR_type &measResultList2NR, VCCB_MeasResultList2NRVisitor &visitor)
{
    // Iterate over all frequency objects.
    for (unsigned int freqIdx = 0; freqIdx < MIN(measResultList2NR.nrofFreq, MAX_NUM_FREQ); ++freqIdx)
    {
        // Cache and validate frequency object.
        const measResult2NR_type &measResult2NR = measResultList2NR.measResult2NR[freqIdx];
        if (not _IsValid(measResult2NR))
        {
            continue;
        }
        // Process serving cell result.
        if (TRUE == measResult2NR.measResultServingCell_Flag)
        {
            // Cache and validate measurement object.
            const measResultNR_type &measResultNR = measResult2NR.measResultServingCell;
            if (_IsValidServingCell(measResultNR))
            {
                visitor.VisitServingCell(measResult2NR, measResultNR);
                // Finish immediately if visitor needs no more processing.
                if (visitor.IsResultDetermined())
                {
                    return;
                }
            }
        }
        // Process all neighbour cells.
        for (unsigned int nbrIdx = 0;
             nbrIdx < MIN(measResult2NR.measResultNeighCellListNR.nrofCellReport, MAX_NUM_CELL_REPORT); ++nbrIdx)
        {
            // Cache and validate measurement object.
            const measResultNR_type &measResultNR = measResult2NR.measResultNeighCellListNR.measResultNR[nbrIdx];
            if (not _IsValidNeighbourCell(measResultNR))
            {
                continue;
            }
            visitor.VisitNeighbourPci(measResult2NR, measResultNR);
            // Finish immediately if visitor needs no more processing.
            if (visitor.IsResultDetermined())
            {
                return;
            }
        }
    }
}

///////////////////////////////////////////////
// VCCB_MeasResultList2NRVisitor_IsAnyOfNrcgiCandidateCellServedByThisGnb
///////////////////////////////////////////////

bool VCCB_MeasResultList2NRVisitor_IsAnyOfNrcgiCandidateCellServedByThisGnb::_HasMeasResultNrcgi(
    const measResultNR_type &rMeasResNR) const
{
    return ((VCCB_FLAG_ON == rMeasResNR.cgiInfoFlag) &&
            (VCCB_FLAG_ON == rMeasResNR.cgiInfo.plmn_IdentityInfoList_Flag) &&
            (0 < rMeasResNR.cgiInfo.plmn_IdentityInfoList.nrofPLMN_IdentityInfo) &&
            (0 < rMeasResNR.cgiInfo.plmn_IdentityInfoList.plmn_IdentityInfo[0].plmn_IdentityList.nrofPLMN_Identity));
}

bool VCCB_MeasResultList2NRVisitor_IsAnyOfNrcgiCandidateCellServedByThisGnb::_IsIntraGnb(
    const measResultNR_type &rMeasResNR) const
{
    if (_ptCi->gnbNum >= MAX_GNB_PER_SYS) return false;

    const VccbGnbInfo_type *const pGnb = &GNBINFO[_ptCi->gnbNum];

    const uint32_t cellGnbId = VLIB_NrCellId2GnbId(
        pGnb->globalGnbId.gnbId.idLength, rMeasResNR.cgiInfo.plmn_IdentityInfoList.plmn_IdentityInfo[0].cellIdentity);
    if (!VCCB_IS_SAME_GNB(cellGnbId,
            rMeasResNR.cgiInfo.plmn_IdentityInfoList.plmn_IdentityInfo[0].plmn_IdentityList.plmn_Identity[0].longId,
            _ptCi->gnbNum))
    {
        return false;
    }
    return true;
}

bool VCCB_MeasResultList2NRVisitor_IsAnyOfNrcgiCandidateCellServedByThisGnb::_IsMeasOfPscell(
    const measResult2NR_type &rMeasRes2NR, const measResultNR_type &rMeasResNR)
{
    if (_ptCi->servCellNum >= MAX_CELL_NUM_VCCB) return false;

    VccbCellInfo_type *const pCell = &CELLINFO[_ptCi->servCellNum];

    // Verify frequency first.
    if (TRUE == rMeasRes2NR.ssbFrequency_Flag)
    {
        if (pCell->ssbArfcn != rMeasRes2NR.ssbFrequency)
        {
            return false;
        }
    }
    else
    {
        if (pCell->nrArfcnDl != rMeasRes2NR.refFreqCSI_RS)
        {
            return false;
        }
    }
    // Check PCI mismatch.
    if ((TRUE == rMeasResNR.physCellIdFlag) && (pCell->phyCellId != rMeasResNR.physCellId))
    {
        return false;
    }
    // This is measurement of PSCell.
    return true;
}

bool VCCB_MeasResultList2NRVisitor_IsAnyOfNrcgiCandidateCellServedByThisGnb::_FindScellByFreqAndPci(
    const measResult2NR_type &rMeasRes2NR, const measResultNR_type &rMeasResNR)
{
    const scellInfo_type *foundScell = nullptr;
    // Try to find SCell by frequency.
    // Frequency should be unique identifier on scell list.
    const scellList_type &scells = FnVCCB_GetConstScellInfoList(*_ptCi);
    for (int sCellIdx = 0; sCellIdx < MAX_SCELL_PER_CALL; ++sCellIdx)
    {
        if (SCELL_STATE_ADDED != scells[sCellIdx].state)
        {
            continue;
        }
        // Check frequency (unique id).
        if (((FALSE != rMeasRes2NR.ssbFrequency_Flag) &&
                (scells[sCellIdx].ssbArfcn == rMeasRes2NR.ssbFrequency)) ||
            ((FALSE != rMeasRes2NR.refFreqCSI_RS_Flag) &&
                (scells[sCellIdx].nrArfcn == rMeasRes2NR.refFreqCSI_RS)))
        {
            foundScell = &scells[sCellIdx];
            break;
        }
    }
    // SCell not found.
    if (nullptr == foundScell)
    {
        return false;
    }
    // Check if PCI matches with measurement.
    if ((TRUE == rMeasResNR.physCellIdFlag) && (foundScell->pci != rMeasResNR.physCellId))
    {
        return false;
    }
    // SCell found.
    return true;
}

void VCCB_MeasResultList2NRVisitor_IsAnyOfNrcgiCandidateCellServedByThisGnb::VisitServingCell(
    const measResult2NR_type &rMeasRes2NR, const measResultNR_type &rMeasResNR)
{
    // Check as PSCell.
    if (_IsMeasOfPscell(rMeasRes2NR, rMeasResNR))
    {
        if (_HasMeasResultNrcgi(rMeasResNR))
        {
            _foundIntraGnbNrcgiCell = true;
        }
    }
    // Check as SCell.
    else
    {
        // Make sure that it is one of serving cells.
        if (_FindScellByFreqAndPci(rMeasRes2NR, rMeasResNR))
        {
            VisitNeighbourPci(rMeasRes2NR, rMeasResNR);
        }
    }
}

void VCCB_MeasResultList2NRVisitor_IsAnyOfNrcgiCandidateCellServedByThisGnb::VisitNeighbourPci(
    const measResult2NR_type &, const measResultNR_type &rMeasResNR)
{
    if (_HasMeasResultNrcgi(rMeasResNR))
    {
        if (_IsIntraGnb(rMeasResNR))
        {
            _foundIntraGnbNrcgiCell = true;
            return;
        }
        ++_interGnbNrcgiCellsCount;
    }
}
