/**
 * @file     : FeatMeasurementObjectPriority.cpp
 * @brief    : source file for functions related to measurement object priority feature
 *
 * @author   : k.laskowski2@partner.samsung.com
 * @date     : 2020/10/28
 *
 * Copyright 2020 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

#include "FeatMeasurementObjectPriority.hpp"
#include "FeatCommon.h"
#include "FeatMeasCommon.hpp"
#include "ComInclude.h"
#include "ComFind.hpp"
#include "ComUtil.hpp"
#include "FeatNrdcMrControl.hpp"

using util::arraySize;

namespace
{
constexpr uint8_t INTRAFREQ_OBJECT_PRIORITY = MAX_MEAS_OBJECT_PRIORITY + 1;

constexpr uint8_t MAX_MEAS_OBJECT_ID_ENTRIES = 64;

uint8_t convertCiIdToRrcId(uint8_t ciId) { return static_cast<uint8_t>(ciId + 1); }

uint8_t convertRrcIdToCiId(uint8_t rrcId) { return static_cast<uint8_t>(rrcId - 1); }

enum class MeasObjectIdState
{
    FREE,
    ALLOCATED
};

struct MeasObjectIdWithState
{
    uint8_t id;
    MeasObjectIdState state;
};

std::array<MeasObjectIdWithState, MAX_MEAS_OBJECT_ID_ENTRIES> generateAllFreeIds(
    const std::array<uint8_t, MAX_MEAS_OBJECT_ID_ENTRIES>& idsPool)
{
    std::array<MeasObjectIdWithState, MAX_MEAS_OBJECT_ID_ENTRIES> ar;
    for (uint8_t i = 0; i < MAX_MEAS_OBJECT_ID_ENTRIES; i++)
    {
        ar[i].id = static_cast<uint8_t>(idsPool[i]);
        ar[i].state = MeasObjectIdState::FREE;
    }
    return ar;
}

struct FrequencyWithMeasObjectId
{
    uint32_t freq;
    unsigned measObjectId;
    enumUsage_type usage{CI_no_use};
};

template <enumMeasRatType RatType>
uint32_t getFrequency(const measurementObjectUe_type&);

template <>
uint32_t getFrequency<measRatNr>(const measurementObjectUe_type& mo)
{
    return mo.conf.rat.nr.minimal.ncdSsbInfo.usage == CI_use ? mo.conf.rat.nr.minimal.ncdSsbInfo.ncdSsbArfcn
                                                             : mo.conf.rat.nr.minimal.ssbFrequency;
}

template <>
uint32_t getFrequency<measRatEutra>(const measurementObjectUe_type& mo)
{
    return mo.conf.rat.eutra.minimal.carrierFreq;
}

template <enumMeasRatType RatType>
bool isType(const measurementObjectUe_type& mo)
{
    return mo.conf.ratType == RatType;
};

bool hasType(const measurementObjectUe_type& mo)
{
    return mo.conf.ratType == measRatNr || mo.conf.ratType == measRatEutra;
};

template <enumMeasRatType RatType>
struct RatTraits;

template <>
struct RatTraits<measRatNr>
{
    constexpr static std::array<uint8_t, MAX_MEAS_OBJECT_ID_ENTRIES> MEAS_OBJECT_IDS_POOL = {1, 2, 3, 4, 5, 6, 7, 8, 9,
        10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57,
        58, 59, 60, 61, 62, 63, 64, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41};
    constexpr static const char* NAME = "NR";
};

template <>
struct RatTraits<measRatEutra>
{
    constexpr static std::array<uint8_t, MAX_MEAS_OBJECT_ID_ENTRIES> MEAS_OBJECT_IDS_POOL = {22, 23, 24, 25, 26, 27, 28,
        29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56,
        57, 58, 59, 60, 61, 62, 63, 64, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21};
    constexpr static const char* NAME = "EUTRA";
};

struct RangeHelper
{
    bool isAlreadyAdded(unsigned measObjectId) const { return alreadyAdded[measObjectId]; }

    void markAdded(unsigned measObjectId) { alreadyAdded[measObjectId] = true; }

private:
    std::array<unsigned, MAX_MEAS_OBJECT_ID_ENTRIES> alreadyAdded{};
};

struct FrequenciesOfApplicablePrioritizedDbEntries
{
    template <enumMeasRatType RatType>
    static simpleVector<Arfcn_type, MAX_MEAS_OBJECT_ID_ENTRIES> get(const callInfo_type&, const VccbCellInfo_type&);
};

using SsbFrequencies = simpleVector<Arfcn_type, MAX_NCD_FREQ_ENTRIES + 1>;
SsbFrequencies getApplicableSsbsForUeRedCap(
    const callInfo_type& rCi, unsigned moId, const VccbCellInfo_type& rCell, const Arfcn_type cdSsb)
{
    AUTO_TRACE_FUNC;
    SsbFrequencies ssbFrequencies{cdSsb};

    VCCB_CHECK_E_RANGE_AND_VAL(rCi.gnbNum, MAX_GNB_PER_SYS, ssbFrequencies);

    if (moId == INTRAFREQ_OBJECT_IDX)  // intra freq
    {
        if (rCell.ncdSsbInfo.usage == CI_use) ssbFrequencies.push_back(rCell.ncdSsbInfo.ncdSsbArfcn);
    }
    else  // inter freq
    {
        const auto& gnb = GNBINFO[rCi.gnbNum];
        if (auto ncdIndex = VCCB_FindCdToNcdMappingIdx(gnb.ncdSsbConfig, cdSsb); ncdIndex)
        {
            auto& cdToncdSsb = gnb.ncdSsbConfig.cdToNcdMappingEntries[ncdIndex.value()];
            for (const auto& ncdSsb : cdToncdSsb.ncdSsbFreqEntries)
                if (ncdSsb.usage == CI_use && FnVCCB_IsSsbAllowed(rCi, ncdSsb.ncdSsbFreq))
                {
                    ssbFrequencies.push_back(ncdSsb.ncdSsbFreq);
                }
        }
    }
    return ssbFrequencies;
}

template <>
simpleVector<Arfcn_type, MAX_MEAS_OBJECT_ID_ENTRIES> FrequenciesOfApplicablePrioritizedDbEntries::get<measRatNr>(
    const callInfo_type& ci, const VccbCellInfo_type& servingCell)
{
    AUTO_TRACE_FUNC;

    simpleVector<Arfcn_type, MAX_MEAS_OBJECT_ID_ENTRIES> frequencies{};
    simpleVector<unsigned, MAX_MEAS_OBJECT_ID_ENTRIES> indexes{};

    const auto& monr = servingCell.measurementsData.measurementObjectsNRDb;
    for (unsigned i = 0; i < arraySize(monr); i++)
    {
        if (CI_use != monr[i].base.usage)
        {
            continue;
        }

        if (VCCB_IsRedCapUeForSA(ci) && CI_use != monr[i].base.redcapAccessAllowed)
        {
            continue;
        }

        if (indexes.full())
        {
            VCCB_PRINT_CALL_ERROR(&ci, "Too much indexes allocated!\n");
            break;
        }
        indexes.push_back(i);
    }

    auto getPriority = [&monr, &ci](unsigned idx)
    {
        if (idx == INTRAFREQ_OBJECT_IDX)
        {
            return INTRAFREQ_OBJECT_PRIORITY;
        }

        auto plmnIndex = VLIB_FindGnbPlmnIndexOfCall(&ci);
        if (MAX_PLMN_INDEX > plmnIndex && CI_use == monr[idx].extension.plmnBasedControl.plmn[plmnIndex].usage &&
            plmnOption_notAllowed != monr[idx].extension.plmnBasedControl.plmn[plmnIndex].option)
        {
            return monr[idx].extension.plmnSpecific[plmnIndex].moPriority;
        }

        return monr[idx].base.moPriority;
    };

    // sort in descending order using moPriority as a key. Stable, because we want to keep order from the database.
    std::stable_sort(indexes.begin(), indexes.end(),
        [&getPriority](unsigned left, unsigned right) { return getPriority(left) > getPriority(right); });

    if (!VCCB_IsRedCapUeForSA(ci))  // only valid for non-redCap UE with disabled NCD-SSB
    {
        std::transform(indexes.begin(), indexes.end(), std::back_insert_iterator(frequencies),
            [&monr](unsigned i) { return monr[i].base.ssbFrequency; });
    }
    else
    {
        for (const auto& id : indexes)
        {
            auto cdSsb = monr[id].base.ssbFrequency;
            if (frequencies.full())
            {
                VCCB_PRINT_CALL_ERROR(&ci, "There is no place in frequencies array for add %u(CD-SSB)!\n", cdSsb);
                break;
            }
            for (const auto& ssbFreq : getApplicableSsbsForUeRedCap(ci, id, servingCell, cdSsb))
            {
                if (std::find_if(frequencies.begin(), frequencies.end(),
                        [ssbFreq](const auto& freq) { return freq == ssbFreq; }) == frequencies.end())
                {
                    if (frequencies.full())
                    {
                        VCCB_PRINT_CALL_ERROR(&ci, "There is no place in frequencies array for add %u!\n", ssbFreq);
                        break;
                    }
                    frequencies.push_back(ssbFreq);
                }
            }
        }
    }

    // it may happen that in frequencies array there are duplicates, we need to drop them
    auto last = std::unique(frequencies.begin(), frequencies.end());
    frequencies.erase(last, frequencies.end());
    return frequencies;
}

template <>
simpleVector<Arfcn_type, MAX_MEAS_OBJECT_ID_ENTRIES> FrequenciesOfApplicablePrioritizedDbEntries::get<measRatEutra>(
    const callInfo_type& ci, const VccbCellInfo_type& servingCell)
{
    AUTO_TRACE_FUNC;

    simpleVector<Arfcn_type, MAX_MEAS_OBJECT_ID_ENTRIES> frequencies{};
    simpleVector<unsigned, MAX_MEAS_OBJECT_ID_ENTRIES> indexes{};

    auto& moeutra = servingCell.measurementsData.measurementObjectsEUTRADb;
    for (unsigned i = 0; i < arraySize(moeutra); i++)
    {
        if (CI_use != moeutra[i].base.usage)
        {
            continue;
        }

        if (indexes.full())
        {
            VCCB_PRINT_CALL_ERROR(&ci, "Too much indexes allocated!\n");
            break;
        }
        indexes.push_back(i);
    }

    auto getPriority = [&moeutra, &ci](unsigned idx)
    {
        auto plmnIndex = VLIB_FindGnbPlmnIndexOfCall(&ci);
        if (MAX_PLMN_INDEX > plmnIndex && CI_use == moeutra[idx].extension.plmnBasedControl.plmn[plmnIndex].usage &&
            plmnOption_notAllowed != moeutra[idx].extension.plmnBasedControl.plmn[plmnIndex].option)
        {
            return moeutra[idx].extension.plmnSpecific[plmnIndex].moPriorityEutra;
        }

        return moeutra[idx].base.moPriorityEutra;
    };

    // sort in descending order using moPriorityEutra as a key. Stable, because we want to keep order from the database.
    std::stable_sort(indexes.begin(), indexes.end(),
        [&getPriority](unsigned left, unsigned right) { return getPriority(left) > getPriority(right); });

    std::transform(indexes.begin(), indexes.end(), std::back_insert_iterator(frequencies),
        [&moeutra](unsigned i) { return moeutra[i].base.carrierFreq; });

    return frequencies;
}

using FrequencyWithMeasObjectIds = std::array<FrequencyWithMeasObjectId, MAX_NR_OF_OBJECT_ID>;
template <enumMeasRatType RatType>
FrequencyWithMeasObjectIds collectInstalledFrequenciesWithTheirIds(const callInfo_type& ci)
{
    AUTO_TRACE_FUNC;

    auto takeFreqAndId = [](const measurementObjectUe_type& mo)
    {
        FrequencyWithMeasObjectId i;
        i.freq = getFrequency<RatType>(mo);
        i.measObjectId = convertCiIdToRrcId(mo.objectId);
        i.usage = CI_use;
        return i;
    };

    auto sanityChecks = [](const measurementObjectUe_type& mo)
    {
        if (CI_use != mo.usage)
        {
            return false;
        }

        if (!hasType(mo))
        {
            return false;
        }

        if (INVALID_OBJECT_ID == mo.objectId)
        {
            return false;
        }

        return true;
    };

    RangeHelper rangeHelper{};
    unsigned currentIdx = 0;
    FrequencyWithMeasObjectIds installed;
    auto& measObjectConfiguration = FnVCCB_GetMeasurementsConfiguration(ci).measurementObjects;
    auto& measObjectProcedure = FnVCCB_GetMeasurementsProcedure(ci).measurementObjects;

    // add installed && pending && already allocated
    for (auto& mo : measObjectConfiguration.installedItems)
    {
        if (!sanityChecks(mo))
        {
            continue;
        }

        if (VCCB_FLAG_ON != mo.pending)
        {
            continue;
        }

        const unsigned measObjectId = convertCiIdToRrcId(mo.objectId);

        if (rangeHelper.isAlreadyAdded(measObjectId))
        {
            continue;
        }

        if (currentIdx >= installed.size())
        {
            VCCB_PRINT_CALL_ERROR(&ci,
                "More than %zu MeasObjectIds allocated for one UE. It shouldn't have happened.\n", installed.size());
            return installed;
        }
        installed[currentIdx++] = takeFreqAndId(mo);
        rangeHelper.markAdded(measObjectId);
    }

    // add new && already allocated
    for (unsigned i = 0; i < MIN(measObjectProcedure.numNewItems, arraySize(measObjectProcedure.newItems)); ++i)
    {
        auto& mo = measObjectProcedure.newItems[i];

        if (!sanityChecks(mo))
        {
            continue;
        }

        const unsigned measObjectId = convertCiIdToRrcId(mo.objectId);

        if (rangeHelper.isAlreadyAdded(measObjectId))
        {
            continue;
        }

        if (currentIdx >= installed.size())
        {
            VCCB_PRINT_CALL_ERROR(&ci,
                "More than %zu MeasObjectIds allocated for one UE. It shouldn't have happened!\n", installed.size());
            return installed;
        }
        installed[currentIdx++] = takeFreqAndId(mo);
        rangeHelper.markAdded(measObjectId);
    }

    return installed;
}

struct Allocation
{
    uint32_t freq;
    uint8_t measObjectId;
};

}  // namespace

MeasurementConfigurationObjectIdAllocator::MeasurementConfigurationObjectIdAllocator(callInfo_type& ci) : ci_(ci) {}

int16_t MeasurementConfigurationObjectIdAllocator::allocateIdsForMeasurementObjects(
    const VccbCellInfo_type& servingCell)
{
    AUTO_TRACE_FUNC;

    clearPendingForInstalledItemsToRemove();

    assignMeasObjectIds<measRatNr>(servingCell);
    assignMeasObjectIds<measRatEutra>(servingCell);

    return GOOD;
}

void MeasurementConfigurationObjectIdAllocator::clearPendingForInstalledItemsToRemove()
{
    AUTO_TRACE_FUNC;

    auto& measObjectConfiguration = FnVCCB_GetMeasurementsConfiguration(ci_).measurementObjects;
    auto& measObjectProcedure = FnVCCB_GetMeasurementsProcedure(ci_).measurementObjects;

    for (uint8_t i = 0; i < arraySize(measObjectConfiguration.installedItems); i++)
    {
        if (GETBIT(measObjectProcedure.itemsToRemove, i))
        {
            measObjectConfiguration.installedItems[i].pending = VCCB_FLAG_OFF;
        }
    }
}

template <enumMeasRatType RatType>
void MeasurementConfigurationObjectIdAllocator::assignMeasObjectIds(const VccbCellInfo_type& servingCell)
{
    AUTO_TRACE_FUNC;

    using Traits = RatTraits<RatType>;
    auto freeMeasObjectIds = generateAllFreeIds(Traits::MEAS_OBJECT_IDS_POOL);
    const auto installedFreqAndIds = collectInstalledFrequenciesWithTheirIds<RatType>(ci_);

    for (auto& measObjectId : freeMeasObjectIds)
    {
        for (auto& installedId : installedFreqAndIds)
        {
            if (CI_use != installedId.usage)
            {
                continue;
            }
            if (measObjectId.id == installedId.measObjectId)
            {
                measObjectId.state = MeasObjectIdState::ALLOCATED;
            }
        }
    }

    auto frequencies = FrequenciesOfApplicablePrioritizedDbEntries::get<RatType>(ci_, servingCell);
    for (auto& freq : frequencies)
    {
        for (auto& installedFreq : installedFreqAndIds)
        {
            if (CI_use != installedFreq.usage)
            {
                continue;
            }
            if (freq == installedFreq.freq)
            {
                freq = UNKNOWN_ARFCN;
            }
        }
    }

    unsigned allocationsElements = 0;
    Allocation allocations[MAX_MEAS_OBJECT_ID_ENTRIES];
    unsigned idsIdx = 0;
    unsigned freqIdx = 0;
    // for-loop bounded for safety
    for (unsigned i = 0; i < freeMeasObjectIds.size() + frequencies.size(); i++)
    {
        if (idsIdx >= freeMeasObjectIds.size() || freqIdx >= frequencies.size())
        {
            break;
        }

        auto& id = freeMeasObjectIds[idsIdx];
        if (id.state == MeasObjectIdState::ALLOCATED)
        {
            idsIdx++;
            continue;
        }

        auto freq = frequencies[freqIdx];
        if (freq == UNKNOWN_ARFCN)
        {
            freqIdx++;
            continue;
        }

        if (allocationsElements >= arraySize(allocations))
        {
            VCCB_PRINT_CALL_ERROR(&ci_, "Allocations run out of space!\n");
            break;
        }
        auto& allocation = allocations[allocationsElements];
        allocation.measObjectId = id.id;
        id.state = MeasObjectIdState::ALLOCATED;
        allocation.freq = freq;
        allocationsElements++;
        idsIdx++;
        freqIdx++;
    }

    // allocate measObjectId for all new not yet allocated
    auto& measObjectProcedure = FnVCCB_GetMeasurementsProcedure(ci_).measurementObjects;
    for (unsigned i = 0; i < MIN(measObjectProcedure.numNewItems, arraySize(measObjectProcedure.newItems)); ++i)
    {
        auto& mo = measObjectProcedure.newItems[i];
        if (!isType<RatType>(mo))
        {
            continue;
        }

        if (INVALID_OBJECT_ID != mo.objectId)
        {
            continue;
        }

        auto frequency = getFrequency<RatType>(mo);
        auto allocation = util::findObjectIfExist(
            allocations, allocationsElements, [&frequency](const Allocation& e) { return e.freq == frequency; });
        if (allocation == util::NOT_FOUND)
        {
            VCCB_PRINT_CALL_COMMENT(&ci_, "Allocation for %d %s-arfcn cannot be found!\n", frequency, Traits::NAME);

            // if allocation isn't made we try to get the least important free id (start from the back)
            auto freeId = std::find_if(freeMeasObjectIds.rbegin(), freeMeasObjectIds.rend(),
                [](const MeasObjectIdWithState& e) { return e.state == MeasObjectIdState::FREE; });
            if (freeId == freeMeasObjectIds.rend())
            {
                VCCB_PRINT_CALL_ERROR(&ci_, "Allocation for %d %s-arfcn cannot be made!\n", frequency, Traits::NAME);
                continue;
            }
            else
            {
                freeId->state = MeasObjectIdState::ALLOCATED;
                mo.objectId = convertRrcIdToCiId(freeId->id);
            }
        }
        else
        {
            mo.objectId = convertRrcIdToCiId(allocation->measObjectId);
        }
        VCCB_PRINT_CALL_COMMENT(&ci_, "For %d %s-arfcn: allocated measObjectId = %d\n", frequency, Traits::NAME,
            convertCiIdToRrcId(mo.objectId));
    }
}

namespace
{
/****************************************************************************
 * @brief           Function works as an operator< for comparing two measurementIdentity_type object.
 *
 * @param[in]       left, right : References to objects to compare. / measurementIdentity_type
 ****************************************************************************/
bool isLeftBeforeRight(const measurementIdentity_type& left, const measurementIdentity_type& right)
{
    AUTO_TRACE_FUNC;
    if (left.measObjectId < right.measObjectId)
    {
        return true;
    }
    else if (left.measObjectId == right.measObjectId)
    {
        return left.reportConfigId < right.reportConfigId;
    }
    return false;
}

bool isReportConfigNrdc(const reportConfigurationNewUe_type& rc)
{
    return (rc.conf.reportType == measReport_A4 && rc.conf.reportPurpose == a4Purpose_NrdcAddition);
}
// end of namespace
}  // namespace

MeasIdAllocator::MeasIdAllocator(callInfo_type& ci) :
    rCi(ci),
    rMeasProc(FnVCCB_GetMeasurementsProcedure(rCi)),
    rMeasConf(FnVCCB_GetMeasurementsConfiguration(rCi))
{
}

int16_t MeasIdAllocator::prepareMeasIdsToInstall(
    MeasIdsPool& measIdsPool, MeasIdsPerNewItemIndexList& allMeasIds, MeasIdsList& currentlyInstalledMeasIds)
{
    auto& newItemsToInstall = rMeasProc.measurementIdentities;
    for (uint8_t i = 0; i < newItemsToInstall.numNewItems; i++)
    {
        const auto& measId = newItemsToInstall.newItems[i];

        if (measIdsPool.isOccupied(measId.objectId))
        {
            continue;
        }

        allMeasIds.push_back({measId, i});

        if (INVALID_OBJECT_ID == measId.objectId)
        {
            continue;
        }
        else
        {
            if (measId.objectId >= MAX_NR_OF_MEAS_ID)
            {
                VCCB_PRINT_CALL_COMMENT(&rCi, "assigned before objectId is greater than MAX_NR_OF_MEAS_ID\n");
                return ERROR;
            }

            measIdsPool.occupy(measId.objectId);
            currentlyInstalledMeasIds.push_back(measId.objectId);
        }
    }

    return GOOD;
}

// Copying MeasIdsPool is intentional because we do not want to modify the basic MeasIdsPool
bool MeasIdAllocator::assignFreeMeasIds(MeasIdsPool measIdsPool, MeasIdsPerNewItemIndexList& allMeasIds)
{
    int prevMeasId{-1};
    for (size_t i = 0; i < allMeasIds.size(); i++)
    {
        auto& measId = allMeasIds[i].measId;
        if (measId.objectId == INVALID_OBJECT_ID)
        {
            std::optional<uint8_t> freeMeasIdOpt{};
            // it could be while (true) but to play nice with tools for code analysis we bounded it using for loop
            for (int j = 0; j < MAX_NR_OF_MEAS_ID; j++)
            {
                freeMeasIdOpt = measIdsPool.take();
                if (false == freeMeasIdOpt.has_value())
                {
                    return true;
                }
                if (freeMeasIdOpt.value() > prevMeasId)
                {
                    break;
                }
            }
            measId.objectId = static_cast<uint8_t>(freeMeasIdOpt.value());
        }
        else
        {
            auto currMeasId = measId.objectId;
            if (prevMeasId > currMeasId)  // reassignment needed
            {
                return true;
            }
        }
        prevMeasId = allMeasIds[i].measId.objectId;
    }

    return false;
}

// Copying MeasIdsPool is intentional because we do not want to modify the basic MeasIdsPool
int16_t MeasIdAllocator::reassignMeasIds(
    MeasIdsPool measIdsPool, MeasIdsPerNewItemIndexList& allMeasIds, MeasIdsList& currentlyInstalledMeasIds)
{
    VCCB_PRINT_CALL_COMMENT(&rCi, "Reassign objectIds! No possibility for objectIds to remain unchanged.\n");
    // Put currently installed meas ids into pool
    for (const auto& measId : currentlyInstalledMeasIds)
    {
        measIdsPool.free(measId);
    }
    for (size_t i = 0; i < allMeasIds.size(); i++)
    {
        auto& measId = allMeasIds[i].measId;
        auto freeMeasId = measIdsPool.take();
        if (freeMeasId.has_value() == false) return ERROR;
        measId.objectId = static_cast<uint8_t>(freeMeasId.value());
        measId.internalIdx = MAX_NR_OF_MEAS_ID;  // treat every newIteam like it is not on UE yet
        measId.numberOfReportsSent = 0;
    }
    // Remove meas id if it is not used after reassignment
    auto& newItemsToInstall = rMeasProc.measurementIdentities;
    for (const auto& measId : currentlyInstalledMeasIds)
    {
        if (measIdsPool.isOccupied(measId) == false)
        {
            ONBIT(newItemsToInstall.itemsToRemove, measId);
        }
    }
    return GOOD;
}

/****************************************************************************
 * @brief            Assigns ObjectIds in such a way that:
 *                   1) Only 0...63 numbers can be used
 *                   2) measId_x references measObjectId_x and measId_y references measObjectId_y.
 *                      if measObjectId_x > measObjectId_y then measId_x > measId_y
 *                   3) assigning objectId does not affect the already assigned objectIds by other features (like NRDC)
 ****************************************************************************/
int16_t MeasIdAllocator::alignMeasIdWithMeasObjectId()
{
    AUTO_TRACE_FUNC;

    auto& newItemsToInstall = rMeasProc.measurementIdentities;
    VCCB_CHECK_LIST_COUNT_AND_RETURN(newItemsToInstall.numNewItems, MAX_NR_OF_MEAS_ID);

    MeasIdsPerNewItemIndexList allMeasIds{};
    MeasIdsList currentlyInstalledMeasIds{};
    MeasIdsPool measIdsPool{};

    // Prepare measIds pool
    for (auto measId : reservedMeasIds)
    {
        measIdsPool.occupy(measId);
    }

    if (ERROR == prepareMeasIdsToInstall(measIdsPool, allMeasIds, currentlyInstalledMeasIds))
    {
        return ERROR;
    }

    if (allMeasIds.empty())
    {
        return GOOD;
    }

    std::sort(allMeasIds.begin(), allMeasIds.end(),
        [](auto left, auto right) { return isLeftBeforeRight(left.measId, right.measId); });

    bool reassignmentNeeded = assignFreeMeasIds(measIdsPool, allMeasIds);
    if (reassignmentNeeded)
    {
        if (ERROR == reassignMeasIds(measIdsPool, allMeasIds, currentlyInstalledMeasIds))
        {
            return ERROR;
        }
    }

    for (auto& measId : allMeasIds)
    {
        newItemsToInstall.newItems[measId.newItemIndex] = measId.measId;
        reservedMeasIds.push_back(measId.measId.objectId);
    }

    return GOOD;
}

int16_t MeasIdAllocator::alignMeasIdWithMeasObjectCapacity()
{
    AUTO_TRACE_FUNC;

    auto& newItemsToInstall = rMeasProc.measurementIdentities;
    VCCB_CHECK_LIST_COUNT_AND_RETURN(newItemsToInstall.numNewItems, MAX_NR_OF_MEAS_ID);

    MeasIdsPool measIdsPool{};
    MeasIdsPerNewItemIndexList allMeasIds{};
    MeasIdsList currentlyInstalledAllMeasIds{};

    MeasIdsPerNewItemIndexList allNrdcMeasIds{};
    MeasIdsList currentlyInstalledNrdcMeasIds{};

    // Prepare measIds pool
    for (auto measId : reservedMeasIds)
    {
        measIdsPool.occupy(measId);
    }

    if (ERROR == prepareMeasIdsToInstall(measIdsPool, allMeasIds, currentlyInstalledAllMeasIds))
    {
        return ERROR;
    }

    // MeasIds filtering: consider only NRDC measId
    for (auto& measId : allMeasIds)
    {
        const auto& rc = rMeasProc.reportConfigurations.newItems[measId.measId.rcNewItemIdx];
        if (isReportConfigNrdc(rc))
        {
            allNrdcMeasIds.push_back(measId);

            const auto it = std::find(
                begin(currentlyInstalledAllMeasIds), end(currentlyInstalledAllMeasIds), measId.measId.objectId);
            if (it != end(currentlyInstalledAllMeasIds))
            {
                currentlyInstalledNrdcMeasIds.push_back(measId.measId.objectId);
            }
        }
    }

    if (allNrdcMeasIds.empty())
    {
        return GOOD;
    }

    std::sort(allNrdcMeasIds.begin(), allNrdcMeasIds.end(),
        [this](auto left, auto right)
        {
            const auto& leftMo = rMeasProc.measurementObjects.newItems[left.measId.moNewItemIdx];
            const auto& rightMo = rMeasProc.measurementObjects.newItems[right.measId.moNewItemIdx];
            const auto leftCapa = FnVCCB_GetAvgAvailResourceByFreqForNrdc(
                rCi, rMeasProc.tgtCellNum, leftMo.conf.rat.nr.minimal.ssbFrequency);
            const auto rightCapa = FnVCCB_GetAvgAvailResourceByFreqForNrdc(
                rCi, rMeasProc.tgtCellNum, rightMo.conf.rat.nr.minimal.ssbFrequency);

            if (leftCapa != rightCapa)
            {
                return leftCapa > rightCapa;
            }
            else
            {
                return left.measId.measObjectId < right.measId.measObjectId;
            }
        });

    bool reassignmentNeeded = assignFreeMeasIds(measIdsPool, allNrdcMeasIds);
    if (reassignmentNeeded)
    {
        if (ERROR == reassignMeasIds(measIdsPool, allNrdcMeasIds, currentlyInstalledNrdcMeasIds))
        {
            return ERROR;
        }
    }

    for (auto& measId : allNrdcMeasIds)
    {
        newItemsToInstall.newItems[measId.newItemIndex] = measId.measId;
        reservedMeasIds.push_back(measId.measId.objectId);
    }

    return GOOD;
}
