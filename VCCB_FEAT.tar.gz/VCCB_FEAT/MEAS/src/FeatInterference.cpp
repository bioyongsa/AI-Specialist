/****************************************************************
 * System      : 5G gNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatInterference.cpp
 * Description : This file contains functions related interference verification (FGR-CC5501)
 * Dept.       : 5G Call SW Lab.
 * Created     : 2020.12.08
 ****************************************************************/

#include "FeatInterference.h"
#include "ComInclude.h"
#include "FeatCommon.h"

namespace
{
const int CONSIDERED_IMD_REGIONS_NUM = 9;

struct FreqRange_s
{
    FreqRange_s() : lowFreq(0), highFreq(0) {}
    FreqRange_s(uint32_t low, uint32_t high) : lowFreq(low), highFreq(high) {}
    uint32_t lowFreq;
    uint32_t highFreq;
};

struct Arfcn_s
{
    Arfcn_s(uint32_t dl, uint32_t ul) : arfcnDl(dl), arfcnUl(ul) {}
    uint32_t arfcnDl;  // nr-arfcn-dl-point-a/earfcnDl
    uint32_t arfcnUl;  // nr-arfcn-ul-point-a/earfcnUl
};

enum enumDuplexModeCombination
{
    enumDuplexModeCombinationTDD_TDD_TDD = 0,  // 0b000
    enumDuplexModeCombinationTDD_TDD_FDD = 1,  // 0b001
    enumDuplexModeCombinationTDD_FDD_TDD = 2,  // 0b010
    enumDuplexModeCombinationTDD_FDD_FDD = 3,  // 0b011
    enumDuplexModeCombinationFDD_TDD_TDD = 4,  // 0b100
    enumDuplexModeCombinationFDD_TDD_FDD = 5,  // 0b101
    enumDuplexModeCombinationFDD_FDD_TDD = 6,  // 0b110
    enumDuplexModeCombinationFDD_FDD_FDD = 7   // 0b111
};

/****************************************************************************
 * @brief           Calculate DL Frequency range in KHz based on earfcn and bandwidht
 *
 * @param[in]       earfcnDl        : uint32_t
 *                  nrbDl           : uint8_t
 * @return          FreqRange_s
 ****************************************************************************/
FreqRange_s VCCB_getLteDlFrequencyRange(uint32_t earfcnDl, uint8_t nrbDl)
{
    AUTO_TRACE_FUNC;
    FreqRange_s result;

    nrbDl = VLIB_ConvertEnumEutraBandwidthMbwToNrb(nrbDl);
    const uint32_t nrbDlOffset = (12U * 15U * nrbDl / 2U);

    uint32_t midFreq = ConvertDlEarfcnToFreqKhz(earfcnDl);
    result.lowFreq = midFreq - nrbDlOffset;
    result.highFreq = midFreq + nrbDlOffset;

    VCCB_PRINT_MSG("Calculated LTE DL freq range (earfcnDl:%d, nrbDl:%d): <%d:%d>\n", earfcnDl, nrbDl, result.lowFreq,
        result.highFreq);

    return result;
}

/****************************************************************************
 * @brief           Calculate UL Frequency range in KHz based on earfcn and bandwidht
 *
 * @param[in]       earfcnUl        : uint32_t
 *                  nrbUl           : uint8_t
 * @return          FreqRange_s
 ****************************************************************************/
FreqRange_s VCCB_getLteUlFrequencyRange(uint32_t earfcnUl, uint8_t nrbUl)
{
    AUTO_TRACE_FUNC;
    FreqRange_s result;

    nrbUl = VLIB_ConvertEnumEutraBandwidthMbwToNrb(nrbUl);
    const uint32_t nrbUlOffset = (12U * 15U * nrbUl / 2U);

    uint32_t midFreq = ConvertUlEarfcnToFreqKhz(earfcnUl);
    result.lowFreq = midFreq - nrbUlOffset;
    result.highFreq = midFreq + nrbUlOffset;

    VCCB_PRINT_MSG("Calculated LTE UL freq range (earfcnUl:%d, nrbUl:%d): <%d:%d>\n", earfcnUl, nrbUl, result.lowFreq,
        result.highFreq);

    return result;
}

/****************************************************************************
 * @brief           Calculate Frequency range in Khz based on
 *                  arfcn, nrScs and nrb (the same for UL and DL)
 *
 * @param[in]       arfcn (nr-arfcn-dl-point-a / nr-arfcn-ul-point-a)   : uint32_t
 *                  nrScs (nr-scs-dl / nr-scs-ul)                       : uint8_t
 *                  nrb   (nrb-dl / nrb-ul)                             : uint16_t
 * @return          FreqRange_s
 ****************************************************************************/
FreqRange_s VCCB_getNrFrequencyRange(uint32_t arfcn, uint8_t nrScs, uint16_t nrb)
{
    AUTO_TRACE_FUNC;
    FreqRange_s result;
    nrScs = VLIB_ConvertEnumNrSubCarrierSpacingToKHz(nrScs);
    nrb = VLIB_ConvertEnumNrSystemBandwidthToNrb(nrb);
    result.lowFreq = VLIB_Arfcn2Freq(arfcn) - (nrScs / 2U);
    result.highFreq = result.lowFreq + (12U * nrScs * nrb) - (nrScs / 2U);

    VCCB_PRINT_MSG("Calculated NR freq range (arfcn:%d, nrScs:%d, nrb:%d): <%d:%d>\n", arfcn, nrScs, nrb,
        result.lowFreq, result.highFreq);

    return result;
}

/****************************************************************************
 * @brief           Check if two Frequency ranges overlap
 *
 * @param[in]       freq1           : FreqRange_s - first frequency range
 * @param[in]       freq2           : FreqRange_s - second frequency range
 * @return          status          : GOOD (no overlap), ERROR, BREAK (overlap)/ int16_t
 ****************************************************************************/
int16_t VCCB_AreTwoFrequenciesOverlap(FreqRange_s freq1, FreqRange_s freq2)
{
    AUTO_TRACE_FUNC;

    if (freq1.lowFreq >= freq1.highFreq || freq2.lowFreq >= freq2.highFreq)
    {
        VCCB_PRINT_ERROR("Overlap cannot be checked - incorrect ranges, assumed no interference\n");
        return ERROR;
    }
    if (freq1.lowFreq < freq2.highFreq && freq1.highFreq > freq2.lowFreq)
    {
        VCCB_PRINT_MSG("Overlap checked - ranges overlap (freq1 <%d:%d>, freq2 <%d:%d>)\n", freq1.lowFreq,
            freq1.highFreq, freq2.lowFreq, freq2.highFreq);
        return BREAK;
    }
    VCCB_PRINT_MSG("Overlap checked - no overlap (freq1 <%d:%d>, freq2 <%d:%d>)\n", freq1.lowFreq, freq1.highFreq,
        freq2.lowFreq, freq2.highFreq);
    return GOOD;
}

/****************************************************************************
 * @brief           Calculate 9 imd regions (2nd and 3rd order)
 *                  based on two ranges
 *
 * @param[in]       freq1            : first input range / FreqRange_s
 * @param[in]       freq2            : second input range / FreqRange_s
 * @param[out]      imdReqions       : output ranges - 9 imd regions / FreqRange_s[9]
 * @return          void
 ****************************************************************************/
void VCCB_calculateImdRegionsOrder2And3(
    FreqRange_s freq1, FreqRange_s freq2, FreqRange_s imdRegions[CONSIDERED_IMD_REGIONS_NUM])
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(imdRegions);

    imdRegions[0] = FreqRange_s(freq1.lowFreq + freq2.lowFreq, freq1.highFreq + freq2.highFreq);
    imdRegions[1] = FreqRange_s(
        VLIB_PositiveDiffOrZero(freq1.lowFreq, freq2.highFreq), VLIB_PositiveDiffOrZero(freq1.highFreq, freq2.lowFreq));
    imdRegions[2] = FreqRange_s(
        VLIB_PositiveDiffOrZero(freq2.lowFreq, freq1.highFreq), VLIB_PositiveDiffOrZero(freq2.highFreq, freq1.lowFreq));
    imdRegions[3] = FreqRange_s(2 * freq1.lowFreq + freq2.lowFreq, 2 * freq1.highFreq + freq2.highFreq);
    imdRegions[4] = FreqRange_s(VLIB_PositiveDiffOrZero(2 * freq1.lowFreq, freq2.highFreq),
        VLIB_PositiveDiffOrZero(2 * freq1.highFreq, freq2.lowFreq));
    imdRegions[5] = FreqRange_s(freq1.lowFreq + 2 * freq2.lowFreq, freq1.highFreq + 2 * freq2.highFreq);
    imdRegions[6] = FreqRange_s(VLIB_PositiveDiffOrZero(freq1.lowFreq, 2 * freq2.highFreq),
        VLIB_PositiveDiffOrZero(freq1.highFreq, 2 * freq2.lowFreq));
    imdRegions[7] = FreqRange_s(VLIB_PositiveDiffOrZero(2 * freq2.lowFreq, freq1.highFreq),
        VLIB_PositiveDiffOrZero(2 * freq2.highFreq, freq1.lowFreq));
    imdRegions[8] = FreqRange_s(VLIB_PositiveDiffOrZero(freq2.lowFreq, 2 * freq1.highFreq),
        VLIB_PositiveDiffOrZero(freq2.highFreq, 2 * freq1.lowFreq));
}

/****************************************************************************
 * @brief           Calculate 9 imd regions (2nd and 3rd order)
 *                  based on two ranges
 *
 * @param[in]       cellFreqRange                 : Cell Frequency Range / FreqRange_s
 * @param[in]       imdReqions                    : 9 imd regions - input ranges / FreqRange_s[9]
 * @return          status                        : GOOD (no overlap), ERROR, BREAK (overlap found) / int16_t
 ****************************************************************************/
int16_t VCCB_isFrequencyRangeOverlapsWithImd(
    FreqRange_s cellFreqRange, FreqRange_s imdRegions[CONSIDERED_IMD_REGIONS_NUM])
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(imdRegions);

    for (int i = 0; i < CONSIDERED_IMD_REGIONS_NUM; i++)
    {
        if (imdRegions[i].lowFreq == 0 && imdRegions[i].highFreq == 0)
        {
            VCCB_PRINT_MSG("IMD region:%d not valid\n", i + 1);
            continue;
        }
        if (BREAK == VCCB_AreTwoFrequenciesOverlap(cellFreqRange, imdRegions[i]))
        {
            VCCB_PRINT_MSG("Overlap found with imd region:%d\n", i + 1);
            return BREAK;
        }
    }
    return GOOD;
}

/****************************************************************************
 * @brief           Get the Arfcn structure containing Arfcn UL and DL values of the given cell
 *
 * @param[in]       dl      : ArfcnUl value
 * @param[in]       ul      : ArfcnDl value
 * @return          Arfcn_s : A instance of Arfcn_s containing Arfcn UL and DL values
 ****************************************************************************/
Arfcn_s VCCB_getArfcnUlDl(uint32_t dl, uint32_t ul)
{
    AUTO_TRACE_FUNC;
    Arfcn_s result = Arfcn_s(dl, ul);
    return result;
}

/**********************************************************************************
 * @brief           Check if cell duplex mode is FDD
 *
 * @param[in]       arfcn_s          : arfc Struct containing arfcn ul and dl values of the cell
 * @return          bool             : true (FDD), false (TDD)
 *********************************************************************************/
bool VCCB_isCellDuplexModeFdd(Arfcn_s arfcn)
{
    AUTO_TRACE_FUNC;
    return (arfcn.arfcnDl != arfcn.arfcnUl);
}

/****************************************************************************
 * @brief          Returns the current duplex mode combination of the three cells
 *
 * @param[in]      isLteUlCellDuplexModeFdd     : Duplex mode of LTE UL Cell
 * @param[in]      isNrUlCellDuplexModeFdd      : Duplex mode of NR  UL Cell
 * @param[in]      isLteOrNrDlCellDuplexModeFdd : Duplex mode of LTE/NR DL Cell
 * @return         enumDuplexModeCombination    : The current duplex mode combination of the three cells
 ****************************************************************************/
enumDuplexModeCombination VCCB_getDuplexModeCombinationFromEnum(
    bool isLteUlCellDuplexModeFdd, bool isNrUlCellDuplexModeFdd, bool isLteOrNrDlCellDuplexModeFdd)
{
    AUTO_TRACE_FUNC;
    uint8_t cellsDuplexModeCombination = (uint8_t)(
        (isLteUlCellDuplexModeFdd << 2) + (isNrUlCellDuplexModeFdd << 1) + isLteOrNrDlCellDuplexModeFdd);
    enumDuplexModeCombination result = static_cast<enumDuplexModeCombination>(cellsDuplexModeCombination);
    return result;
}

/****************************************************************************
 * @brief           Check if IMD interference detection is enable for the current duplex combination number
 *
 * @param[in]       imdDetectionPerDuplexConfigFromDb : imd-detection-per-duplex YANG leaf decimal value
 * @param[in]       cellsDuplexCombinationNumber      : Duplex mode combination of three cells
 * @return          bool : true  (Enabled IMD check for current cells duplex mode combination)
 *                       : false (Disabled IMD check for current cells duplex mode combination)
 ****************************************************************************/
bool VCCB_isImdInterferenceDetectionPerDuplexEnable(
    uint8_t imdDetectionPerDuplexFromYang, enumDuplexModeCombination cellsDuplexCombinationNumber)
{
    AUTO_TRACE_FUNC;
    bool result = imdDetectionPerDuplexFromYang & (1 << cellsDuplexCombinationNumber);
    return result;
}

/****************************************************************************
 * @brief           Check if bit to check for IMD interference for the current
 *                  duplex mode combination of cells is enable
 *
 * @param[in]       ltePcell                 : earfcn downlink of LTE PCell
 * @param[in]       nrCell                   : nr-arfcn-dl-point-a of NR SCell
 * @param[in]       lteOrNrCell              : earfcn uplink of LTE PCell/ nr-arfcn-ul-point-a of NR SCell
 * @return          enumDuplexModeCombination: One of the values from enumDuplexModeCombination
 ****************************************************************************/
enumDuplexModeCombination VCCB_getDuplexModeCombinationOfCells(Arfcn_s ltePcell, Arfcn_s nrCell, Arfcn_s lteOrNrCell)
{
    AUTO_TRACE_FUNC;
    bool isLteUlCellFdd = VCCB_isCellDuplexModeFdd(ltePcell);
    bool isNrUlCellFdd = VCCB_isCellDuplexModeFdd(nrCell);
    bool isLteOrNrDlCellFdd = VCCB_isCellDuplexModeFdd(lteOrNrCell);

    enumDuplexModeCombination result =
        VCCB_getDuplexModeCombinationFromEnum(isLteUlCellFdd, isNrUlCellFdd, isLteOrNrDlCellFdd);

    return result;
}

}  // namespace

/****************************************************************************
 * @brief           Check neighbour cell frequency overlap with LTE PCell
 *
 * @param[in]       ptCi            : call information / callInfo_type
 * @param[in]       pNbrGnbCellInfo : neighbour cell information to check with LTE PCell / nbrGnbCellInfo_type
 * @return          status          : GOOD (no interference), ERROR, BREAK (interference found) / int16_t
 ****************************************************************************/
int16_t VCCM_checkCellFrequencyOverlapWithLtePCell(const callInfo_type* ptCi, const nbrGnbCellInfo_type* pNbrGnbCellInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pNbrGnbCellInfo);

    if (MIN_A6_NR_ARFCN <= pNbrGnbCellInfo->ssbArfcn)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "Interference Overlap is not checked for  FR2 - target ssbArfcn:%d\n", pNbrGnbCellInfo->ssbArfcn);
        return GOOD;
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "Checked eCGI: mnc: %d, mcc: %d, ci: %llu\n", ptCi->eCGI.plmn.s2.mcc,
        ptCi->eCGI.plmn.s2.mnc, 1ULL * ptCi->eCGI.ci);
    nbrEnbCellInfo_type* nbrEnbCellInfo = getNbrEnbCell(ptCi->gnbNum, ptCi->eCGI);
    if (NULL == nbrEnbCellInfo)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "Interference Overlap cannot be checked - PCell is not found, assumed no interference\n");
        return GOOD;
    }
    FreqRange_s nrDlFrequency =
        VCCB_getNrFrequencyRange(pNbrGnbCellInfo->nrArfcnDl, pNbrGnbCellInfo->nrScsDl, pNbrGnbCellInfo->nrbDl);
    FreqRange_s lteDlFrequency = VCCB_getLteDlFrequencyRange(nbrEnbCellInfo->earfcnDl, nbrEnbCellInfo->bandwidthDl);
    int16_t result = VCCB_AreTwoFrequenciesOverlap(nrDlFrequency, lteDlFrequency);
    if (ERROR == result)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Interference Overlap check ERROR - assumed no interference\n");
        return GOOD;
    }
    if (BREAK == result)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Interference Overlap check - interference found (arfcn: %d, earfcn: %d)\n",
            pNbrGnbCellInfo->nrArfcnDl, nbrEnbCellInfo->earfcnDl);
    }
    return result;
}

/****************************************************************************
 * @brief           Check IMD Interference with target/candidate NR cell DL frequency and with LTE PCell DL frequency
 *
 * @param[in]       ptCi                     : call information / callInfo_type
 * @param[in]       pNbrGnbCellInfo          : neighbour cell information to check with LTE PCell / nbrGnbCellInfo_type
 * @param[in]       pNbrGnbCandidateCellInfo : Candidate/Terget cell information to check if its DL is not IMD
 *interference victim This can be the same or different cell as pNbrGnbCellInfo / nbrGnbCellInfo_type
 * @return          status                   : GOOD (no interference), ERROR, BREAK (interference found) / int16_t
 ****************************************************************************/
int16_t VCCM_checkImdInterferenceWithLtePCellAndNrCandidateCell(
    const callInfo_type* ptCi, const nbrGnbCellInfo_type* pNbrGnbCellInfo, const nbrGnbCellInfo_type* pNbrGnbCandidateCellInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pNbrGnbCellInfo);
    VALID_E_POINT_CHECK_ERROR(pNbrGnbCandidateCellInfo);
    if ((MIN_A6_NR_ARFCN <= pNbrGnbCellInfo->ssbArfcn) || (MIN_A6_NR_ARFCN <= pNbrGnbCandidateCellInfo->ssbArfcn))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "Interference IMD is not checked for FR2 - NR Cell ssbArfcn:%d, NR Candidate ssbArfcn:%d\n",
            pNbrGnbCellInfo->ssbArfcn, pNbrGnbCandidateCellInfo->ssbArfcn);
        return GOOD;
    }
    nbrEnbCellInfo_type* pNbrEnbCellInfo = getNbrEnbCell(ptCi->gnbNum, ptCi->eCGI);
    if (nullptr == pNbrEnbCellInfo)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "Interference Overlap cannot be checked - PCell is not found, assumed no interference\n");
        return GOOD;
    }
    FreqRange_s nrUlFrequency =
        VCCB_getNrFrequencyRange(pNbrGnbCellInfo->nrArfcnUl, pNbrGnbCellInfo->nrScsUl, pNbrGnbCellInfo->nrbUl);
    FreqRange_s lteUlFrequency = VCCB_getLteUlFrequencyRange(pNbrEnbCellInfo->earfcnUl, pNbrEnbCellInfo->bandwidthUl);
    FreqRange_s nrCandidateDlFrequency = VCCB_getNrFrequencyRange(
        pNbrGnbCandidateCellInfo->nrArfcnDl, pNbrGnbCandidateCellInfo->nrScsDl, pNbrGnbCandidateCellInfo->nrbDl);
    FreqRange_s lteDlFrequency = VCCB_getLteDlFrequencyRange(pNbrEnbCellInfo->earfcnDl, pNbrEnbCellInfo->bandwidthDl);

    VCCB_PRINT_MSG("Freq Range: NR UL<%d:%d>, NR Cand. DL<%d:%d>, LTE UL<%d:%d>, LTE DL<%d:%d>\n",
        nrUlFrequency.lowFreq, nrUlFrequency.highFreq, nrCandidateDlFrequency.lowFreq, nrCandidateDlFrequency.highFreq,
        lteUlFrequency.lowFreq, lteUlFrequency.highFreq, lteDlFrequency.lowFreq, lteDlFrequency.highFreq);
    FreqRange_s imdRegions[CONSIDERED_IMD_REGIONS_NUM];
    VCCB_calculateImdRegionsOrder2And3(lteUlFrequency, nrUlFrequency, imdRegions);
    for (int i = 0; i < CONSIDERED_IMD_REGIONS_NUM; i++)
    {
        VCCB_PRINT_MSG("IMD Reg:%d - <%d:%d>\n", i + 1, imdRegions[i].lowFreq, imdRegions[i].highFreq);
    }

    Arfcn_s lteArfcn = VCCB_getArfcnUlDl(pNbrEnbCellInfo->earfcnDl, pNbrEnbCellInfo->earfcnUl);
    Arfcn_s NrCellArfcn = VCCB_getArfcnUlDl(pNbrGnbCellInfo->nrArfcnDl, pNbrGnbCellInfo->nrArfcnUl);
    Arfcn_s candidateNrCellArfcn =
        VCCB_getArfcnUlDl(pNbrGnbCandidateCellInfo->nrArfcnDl, pNbrGnbCandidateCellInfo->nrArfcnUl);

    VCCB_PRINT_MSG("LTE Cell Arfcn(%d/%d), NR Cell Arfcn(%d/%d)\n", lteArfcn.arfcnDl, lteArfcn.arfcnUl,
        NrCellArfcn.arfcnDl, NrCellArfcn.arfcnUl);
    enumDuplexModeCombination cellsDuplexModeComboNumber =
        VCCB_getDuplexModeCombinationOfCells(lteArfcn, NrCellArfcn, candidateNrCellArfcn);
    VCCB_PRINT_MSG("Duplex Mode Combination Number: %d\n", cellsDuplexModeComboNumber);

    VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
    uint8_t imdDetectionPerDuplexFromYang = CELLINFO[ptCi->servCellNum].imdInterferenceDetectionPerDuplex;
    VCCB_PRINT_MSG("IMD Detection Per Duplex YANG Configuration (Decimal): %d\n", imdDetectionPerDuplexFromYang);
    bool isImdInterferenceDetectionPerDuplexEnable =
        VCCB_isImdInterferenceDetectionPerDuplexEnable(imdDetectionPerDuplexFromYang, cellsDuplexModeComboNumber);
    VCCB_PRINT_MSG(
        "Is IMD Detection Enable For The Current Cells Duplex Mode Combination [1 => Yes/0 => No]? Answer : %d \n",
        isImdInterferenceDetectionPerDuplexEnable);
    if (!isImdInterferenceDetectionPerDuplexEnable)
    {
        VCCB_PRINT_MSG(
            "IMD Interference check for the current cells duplex mode combination is disable - assumed no "
            "interference\n");
        return GOOD;
    }

    int16_t result = VCCB_isFrequencyRangeOverlapsWithImd(lteDlFrequency, imdRegions);
    if (ERROR == result)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "LTE DL Freq Interference with IMD regions ERROR - assumed no interference\n");
    }
    if (BREAK == result)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "LTE DL IMD Interference found: nr-arfcn(%d/%d), earfcn(%d/%d)\n",
            pNbrGnbCellInfo->nrArfcnDl, pNbrGnbCellInfo->nrArfcnUl, pNbrEnbCellInfo->earfcnDl,
            pNbrEnbCellInfo->earfcnUl);
        return BREAK;
    }

    result = VCCB_isFrequencyRangeOverlapsWithImd(nrCandidateDlFrequency, imdRegions);
    if (ERROR == result)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "NR candidate DL Freq Interference with IMD regions ERROR - assumed no interference\n");
    }
    if (BREAK == result)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "NR candidate DL IMD Interference found: earfcn(%d/%d), nr-arfcn(%d/%d) Candidate nr-arfcn(%d/%d)\n",
            pNbrEnbCellInfo->earfcnDl, pNbrEnbCellInfo->earfcnUl, pNbrGnbCellInfo->nrArfcnDl,
            pNbrGnbCellInfo->nrArfcnUl, pNbrGnbCandidateCellInfo->nrArfcnDl, pNbrGnbCandidateCellInfo->nrArfcnUl);
        return BREAK;
    }
    return GOOD;
}