/****************************************************************
 * System      : 3GPP 5G
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatTrace.hpp
 * Description : This file contains functions related to Trace features
 * Dept.       : Access SW Lab.
 * Created     : 2023.03.13
 *****************************************************************/
#ifndef VCCB_FEAT_FeatTrace_HPP_
#define VCCB_FEAT_FeatTrace_HPP_

#include "VccbStruct.h"
#include "VccbDefine.h"
#include "ComMacro.h"
#include "ComAutoNtrace.hpp"
#include "MsgCommonUtility.hpp"

int16_t VLIB_deallocateTrsr(callInfo_type *ptCi, uint16_t cellNum, enumJobType job, bool force=false);
int16_t VLIB_stopManagementUeThrRfTrace(callInfo_type *ptCi, uint16_t cellNum, bool isHoCancel=false);
int16_t VLIB_stopManagementMdtTrace(callInfo_type *ptCi, uint16_t cellNum, bool isHoCancel=false);
int16_t VLIB_getDeactivateTraceDuUeId(callInfo_type *ptCi, uint32_t &duUeId, uint16_t cellNum);
int16_t VLIB_activateSigMdtTrace(callInfo_type *ptCi, enumSigActFailResult &result, SignalingTrace_type *oldConfig, bool actInSetup, uint16_t startCellNum = MAX_CELL_NUM_VCCB);
void getSigMdtTraceActivatonStatus(callInfo_type *ptCi, traceMdtStatus_type &status);
void deactivateSigMdtTrace(callInfo_type *ptCi, traceMdtStatus_type &sessionToDeactivate, bool isPutCi = false, uint16_t cellNum = 0xFFFF);
enumTraceMdtReportingStatusType VLIB_checkConfiguredReportingType(callInfo_type *ptCi);
bool VLIB_checkAllowedImsiTacList(callInfo_type *ptCi, const AllowedImeiTacList_type *allowedImeiTacList, uint8_t tacFilterOn);

int16_t TraceDepthLinkToUniversal(X2AP_TraceDepth inDepth, universalTraceDepth_type &outDepth);
int16_t TraceDepthLinkToUniversal(NGAP_TraceDepth inDepth, universalTraceDepth_type &outDepth);
int16_t TraceDepthLinkToUniversal(XNAP_Trace_Depth inDepth, universalTraceDepth_type &outDepth);
void TraceDepthUniversalToXnLink(universalTraceDepth_type inDepth, XNAP_Trace_Depth &outDepth);
void sigMdtUethrIntraGnbReactivation(callInfo_type *ptCi, uint16_t srcCellNum, uint16_t tgtCellNum);
int16_t VLIB_getTceIpFromFqdn(const char* fqdn, MdsIp_Type *const tceIpFromFqdn);
bool VLIB_checkTraceRfspSpidAllowed(callInfo_type *ptCi, int32_t msgId);

/**
 * @brief  Store Trace ID in dedicated structured data format 
 * @param   [out] ptTraceId  : pointer to target structure
 * @param   [in] ptPlmnIdAsn : pointer to source trace id buffer
 */
template <typename T>
void StoreTraceId(TraceId_type* ptTraceId, T* ptPlmnIdAsn)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptTraceId);
    VALID_E_POINT_CHECK_VOID(ptPlmnIdAsn);

    ptTraceId->data[0] = ptPlmnIdAsn[0];
    ptTraceId->data[1] = ptPlmnIdAsn[1];
    ptTraceId->data[2] = ptPlmnIdAsn[2];
}

/**
 * @brief   Compare Trace ID stored in call context with provided one
 * @param   [in] ptCi    : pointer to Call Context
 * @param   [in] traceId : pointer to templated trace id structure
 * @return  bool true for matched comparison fale otherwise
 */
template <typename T>
bool FnVCCB_validateIncomingTraceId(callInfo_type *ptCi, T *traceId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(traceId, false);

    TraceId_type incomingTraceId;
    StoreTraceId(&incomingTraceId, traceId->value+3);

    return (0 == memcmp(&incomingTraceId, &ptCi->signalingTraceInfo.traceReference.traceId, sizeof(incomingTraceId)));
}

bool FnVCCB_extractTacStrFromMaskedIMEISV(const VccbMaskedIMEISV_type *maskedIMEISV, char *outTac);

struct callInfo_type::Trace_s::TraceRecordingSession_s* getTraceSession(callInfo_type *ptCi, uint16_t cellNum, bool withCreate=false);

const char* EnumJobTypeStr(enumJobType enumTraceJobType);
const char* EnumJobTypeStr(const char* strArg);

#define VCCB_PRINT_TRACE_ERROR(__ptCi, __tracearg, __fmt, __args...) \
    if(IS_TRACE_LOG_ACTIVE) VCCB_PRINT_CALL_ERROR(__ptCi, "%s " __fmt, EnumJobTypeStr(__tracearg), ##__args) \

#define VCCB_PRINT_TRACE_COMMENT(__ptCi, __tracearg, __fmt, __args...) \
    if(IS_TRACE_LOG_ACTIVE) VCCB_PRINT_CALL_COMMENT(__ptCi, "%s " __fmt, EnumJobTypeStr(__tracearg), ##__args) \

#define VCCB_PRINT_TRACE_INFORMATIVE(__ptCi, __tracearg, __fmt, __args...) \
    if(IS_TRACE_LOG_ACTIVE) VCCB_PRINT_CALL_INFORMATIVE(__ptCi, "%s " __fmt, EnumJobTypeStr(__tracearg), ##__args) \

#define VCCB_PRINT_TRACE_DATA(__ptCi, __tracearg, __fmt, __args...) \
    if(IS_TRACE_LOG_ACTIVE) VCCB_PRINT_CALL_DATA(__ptCi, "%s " __fmt, EnumJobTypeStr(__tracearg), ##__args) \

#define VCCB_PRINT_TRACE_WITHOUT_RETURN_ON_CALL_ERROR(__ptCi, __resultOfFunc, __tracearg, __msg, __args...) \
    if(IS_TRACE_LOG_ACTIVE) VCCB_PRINT_WITHOUT_RETURN_ON_CALL_ERROR(__ptCi, __resultOfFunc, "%s " __msg, EnumJobTypeStr(__tracearg), ##__args) \

#endif  // VCCB_FEAT_FeatTrace_HPP_
