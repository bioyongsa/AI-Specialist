/****************************************************************
 * System      : 3GPP 5G
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatSecurity.h
 * Description :
 * Author      :
 * Dept.       : Access SW Lab.
 * Created     : 2018.06.15
 * Procedures defined :
 * Procedures called  :
 * Version     :
 * Revision history   :
 *          date      :
 *       revised by   :
 * revised information:
 ****************************************************************/

#ifndef VCCB_FEAT_FeatSecurity_H_
#define VCCB_FEAT_FeatSecurity_H_

#include "VccbStruct.h"

int16_t VLIB_DecideSecurityAlgorithm(callInfo_type *, uint8_t isSecCtxModProc);
void VLIB_ApplySecurityAlgorithm(callInfo_type *, uint8_t isSecCtxModProc);
void VLIB_DeriveKeyRrcIntegrity(callInfo_type *, uint8_t *, uint8_t isSecCtxModProc);
void VLIB_DeriveKeyRrcEncryption(callInfo_type *, uint8_t *, uint8_t isSecCtxModProc);
void VLIB_DeriveKeyUpEncryption(callInfo_type *, uint8_t *, uint8_t isSecCtxModProc);
void VLIB_DeriveKeyUpIntegrity(callInfo_type *, uint8_t *, uint8_t isSecCtxModProc);
int16_t VLIB_DeriveKeyNGRANStar(callInfo_type *, uint16_t, uint32_t, uint8_t *);

// For KDF & Integrity...
extern "C" {
extern int fnKDF_HMAC_SHA_256(uint8_t *pInputKey, uint32_t inputKeyLength, uint8_t *pInputString,
    uint32_t inputStringLength, uint8_t *pOutKey, uint32_t outKeyLength);
extern int fnIntegrityProtection_GetMacI(uint8_t *pInputKey, uint32_t inputKeyLength, uint32_t algorithm,
    uint8_t *pInputMsg, uint32_t inputMsgLength, uint32_t count, uint8_t bearerId, uint8_t direction, uint8_t *macI);
};

void VLIB_DeriveOldKeyRrcIntegrity(callInfo_type *, uint8_t *);

int16_t VLIB_MakeOldShortMacI(callInfo_type *, uint64_t, uint16_t *);
int16_t VLIB_MakeResumeMacI(callInfo_type *const ptCi, const uint16_t phyCellId, const uint16_t crnti,
    const uint64_t targetNCI, uint16_t *outResumeMacI);
int16_t VLIB_MakeShortMacI(
    callInfo_type *ptCi, uint16_t phyCellId, uint16_t rnti, uint64_t targetNCI, uint16_t *outShortMacI);
int16_t VLIB_DeriveKeySN(callInfo_type *ptCi, uint8_t *outputKey, uint8_t *keyGnb, uint16_t scgCounter);
int16_t FnVCCB_VerifyMACI(
    callInfo_type *const ptCi, const uint64_t targetCellIdentity, const uint16_t requestedResumeMacI);
void FnVCCB_DeriveKeysForRRCResume(callInfo_type &call);
int16_t FnVCCB_DecideSourceSecurityCapabilities(callInfo_type *ptCi);
void VLIB_sendNia0Notification(callInfo_type *ptCi);
int16_t VLIB_Nia0Processing(callInfo_type *ptCi, bool flag);

int16_t VLIB_SecurityHandling(callInfo_type *ptCi, bool isSecCtxModProc);
int16_t VLIB_DeriveKeysForIntraCellHo(callInfo_type *ptCi);

#endif
