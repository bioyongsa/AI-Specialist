/****************************************************************
 * System      : 5G vNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatVoma.hpp
 * Description : This file contains functions related to VoNR 
 *               monitoring support for VoMA
 * Dept.       : 5G Call SW Lab.
 * Created     : 2025.07.29
 ****************************************************************/

#ifndef VCCB_FEAT_FeatVoma_HPP_
#define VCCB_FEAT_FeatVoma_HPP_

#include "VccbStruct.h"
#include "VccbDefine.h"
#include "ComMacro.h"
#include "ComAutoNtrace.hpp"
#include "MsgCommonUtility.hpp"

#define VOMA_MAX_UE_HISTORY 16
#define E1_CGI_BUF_SIZE 5

int16_t VLIB_VomaActivate(callInfo_type& rCi, vomaCallEvent_type event);
bool VLIB_VomaCheckDrb5QISupport(callInfo_type& rCi, uint8_t drbIdx);
void VLIB_VomaCollectMeasInfo(callInfo_type* const ptCi, const measResultNR_type* const ptMeas,
                              const nbrGnbCellInfo_type* const ptNbrGnbCell=nullptr);
void VLIB_VomaPrepareIntraGnb(callInfo_type& rCi, vomaCallEvent_type callEvent, bool isIntraCellRRE=false);


template <typename T>
void VLIB_Fill_VomaInitTime(T *pAsn, uint8_t *pInitTime)
{
    VALID_E_POINT_CHECK_VOID(pInitTime);
    VALID_E_POINT_CHECK_VOID(pAsn);

    union
    {
        T *toFill;
        struct
        {
            unsigned short length;
            uint8_t value[VOMA_INIT_TIME_LEN];
        } *initTime;
    } wrap;

    wrap.toFill = pAsn;

    for (uint8_t idx=0; idx<VOMA_INIT_TIME_LEN; ++idx)
    {
        wrap.initTime->value[idx] = pInitTime[idx];
    }
    wrap.initTime->length = VOMA_INIT_TIME_LEN;
}

#endif  // VCCB_FEAT_FeatVoma_HPP_
