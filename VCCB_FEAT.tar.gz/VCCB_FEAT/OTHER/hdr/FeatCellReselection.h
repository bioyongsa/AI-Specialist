#ifndef VCCB_FEAT_FeatCellReselection_H_
#define VCCB_FEAT_FeatCellReselection_H_

#include "VccbStruct.h"
#include "RscGnb.h"
#include <memory>
#include <vector>

class CellReselectionInfo
{
public:  // Member functions
    CellReselectionInfo() {}
    virtual ~CellReselectionInfo() {}
    virtual int8_t Fill_CellReselectionInfo(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) = 0;
protected:
    virtual int8_t Fill_CellReselectionPrioritiesNR(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) = 0;
    virtual int8_t Fill_CellReselectionPrioritiesEUTRA(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) = 0;
    virtual void Fill_T320(NRRRC_CellReselectionPriorities *ptIE, NRRRC__enum228 t320);
};

class CellReselectionInfoFallback : public CellReselectionInfo
{
public:  // Member functions
    CellReselectionInfoFallback() {}
    ~CellReselectionInfoFallback() {}
    int8_t Fill_CellReselectionInfo(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) override;
private:
    int8_t Fill_CellReselectionPrioritiesNR(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) override;
    int8_t Fill_CellReselectionPrioritiesEUTRA(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) override;
};

class CellReselectionInfoRFSP : public CellReselectionInfo
{
private:  // Member variables
    rfspBasedCtrl_type *_pSrc;
    int32_t _hasEutraFreqPriorityList;
    bool _isRedirTriggeredByFallbackOrSpecificSlice;
#ifdef IPC_TEST
    friend class MsgMakeNRRC3_test;
#endif

public:  // Member functions
    CellReselectionInfoRFSP() : _pSrc(NULL), _hasEutraFreqPriorityList(FALSE), _isRedirTriggeredByFallbackOrSpecificSlice(false) {}
    CellReselectionInfoRFSP(int32_t flag) : _pSrc(NULL), _hasEutraFreqPriorityList(flag), _isRedirTriggeredByFallbackOrSpecificSlice(false) {}
    ~CellReselectionInfoRFSP() {}
    int8_t Fill_CellReselectionInfo(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) override;
    int32_t getEutraFreqPriorityListFlag() { return _hasEutraFreqPriorityList; }
#ifdef IPC_TEST  //TODO: This function is only used in the test code. If needed, remove #ifdef.
    void setEutraFreqPriorityListFlag(int32_t hasEutraFreqPriorityList) { _hasEutraFreqPriorityList = hasEutraFreqPriorityList; }
    void setRfspBasedCtrl(rfspBasedCtrl_type *pSrc) { _pSrc = pSrc; }
#endif
private:
    int8_t Fill_CellReselectionPrioritiesNR(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) override;
    int8_t Fill_CellReselectionPrioritiesEUTRA(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) override;
};

class CellReselectionInfoSvcBasedIdleLB : public CellReselectionInfo
{
private:  // Member variables
    SvcBasedCrpCtrl_type *_pCellReselect;
    uint8_t _nrMinPriority;

public:  // Member functions
    CellReselectionInfoSvcBasedIdleLB() : _pCellReselect(NULL), _nrMinPriority(0xFF) {}
    ~CellReselectionInfoSvcBasedIdleLB() {}
    int8_t Fill_CellReselectionInfo(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) override;
private:
    int8_t Fill_CellReselectionPrioritiesNR(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) override;
    int8_t Fill_CellReselectionPrioritiesEUTRA(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) override;
    int16_t FnVCCB_Make_lbBasedCellResel_SvcBasedIdleLB(callInfo_type *ptCi, nrCellReselectInfo_type *pDst);
};

class CellReselectionInfoSvcBasedMobilityControl : public CellReselectionInfo
{
private:  // Member variables
    SvcBasedCrpCtrl_type *_pSrc;
    int32_t _fallbackEutraExistFlag;

public:  // Member functions
    CellReselectionInfoSvcBasedMobilityControl() : _pSrc(NULL), _fallbackEutraExistFlag(FALSE) {}
    ~CellReselectionInfoSvcBasedMobilityControl() {}
    int8_t Fill_CellReselectionInfo(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) override;
private:
    int8_t Fill_CellReselectionPrioritiesNR(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) override;
    int8_t Fill_CellReselectionPrioritiesEUTRA(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) override;
};

class CellReselectionInfoPlmnBasedMobilityControl : public CellReselectionInfo
{
private:  // Member variables
    plmnBasedDedicatedPriority_type *_pCellReselect;

public:  // Member functions
    CellReselectionInfoPlmnBasedMobilityControl() : _pCellReselect(NULL) {}
    ~CellReselectionInfoPlmnBasedMobilityControl() {}
    int8_t Fill_CellReselectionInfo(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) override;
private:
    int8_t Fill_CellReselectionPrioritiesNR(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) override;
    int8_t Fill_CellReselectionPrioritiesEUTRA(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) override;
};

class CellReselectionInfoIdleLB : public CellReselectionInfo
{
private:  // Member variables
    uint8_t _nrMinPriority;
    bool _isCaProfileBased;
    bool _isRedCapUeMode;

public:  // Member functions
    CellReselectionInfoIdleLB() : _nrMinPriority(0xFF), _isCaProfileBased(false), _isRedCapUeMode(false) {}
    ~CellReselectionInfoIdleLB() {}
    int8_t Fill_CellReselectionInfo(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) override;
private:
    int8_t Fill_CellReselectionPrioritiesNR(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) override;
    int8_t Fill_CellReselectionPrioritiesEUTRA(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE) override;
};

int16_t Fill_CRCandRCI_ByCACTriggeredRedirection(callInfo_type *ptCi, NRRRC_RRCRelease_IEs *ptIE);
int16_t Fill_CellReselectionInfo(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE, uint8_t isRedirectedCarrierPresent);
bool FnVCCB_IsValid_MeasObj_CellReselection(callInfo_type *ptCi, uint8_t measObjIndex, bool restrictedFrequencyCheckFlag = false);

#ifdef IPC_TEST
int16_t FnVCCB_Make_lbBasedCellResel(
    callInfo_type *ptCi, lbBasedCellResel_type *src, lbBasedCellResel_type *dst, const bool isCaProfileBased);
#endif
#endif
