/****************************************************************
 * System      : 3GPP 5G
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatTrace.h
 * Description : This file contains functions related to Trace features
 * Dept.       : Access SW Lab.
 * Created     : 2021.05.21
 ****************************************************************/

#ifndef VCCB_FEAT_FeatTrace_H_
#define VCCB_FEAT_FeatTrace_H_

#include "VccbStruct.h"

typedef struct TraceParam_s
{
    enumDirection direction;
    int32_t msgId;
    char *ptSourceMsg;
    uint32_t sourceLength;
    uint16_t endPointIdx;
} TraceParam;

bool VLIB_traceDisabledDueToOverload();
int16_t VLIB_stopManagementTraceRecordingSession(callInfo_type *ptCi, uint16_t cellNum);
void VLIB_collectTraceMessage(callInfo_type *ptCi, TraceParam data);
void VLIB_collectMdtM1Measurement(
    callInfo_type *ptCi, void *pMeasResult, reportConfigurationInstalledUe_type *pSelectRptCfg, uint8_t measObjIdx);
void VLIB_collectRlfReportFromFailureIndication(callInfo_type *ptCi, enumMdtRecordSource_type failureTypeSource);
void VLIB_startManagementMdtTrace(callInfo_type *ptCi, uint16_t cellNum);
void VLIB_startManagementUeThrRfTrace(callInfo_type *ptCi, uint16_t cellNum);
int16_t VLIB_stopLoggedMdtTrace(callInfo_type *ptCi, uint16_t cellNum);
int16_t VLIB_stopRlfAndRcefdMdtTrace(callInfo_type *ptCi, uint16_t cellNum);
void VLIB_initTraceAndMdtInfo(uint16_t cellNum);
void VLIB_recoverTraceAndMdtCount(callInfo_type *ptCi);
int16_t VLIB_handleUeInfoRequestTrigger(callInfo_type *ptCi, enqueuedAction);
int16_t VLIB_collectMdtUeInfoData(callInfo_type *ptCi, msgUnpack_type *ptUnpack);
void VLIB_startLoggedMdtTrace(callInfo_type *ptCi, uint16_t cellNum);
int16_t VLIB_getTceIp(uint8_t tceId, MdsIp_Type *const tceIp);
int16_t VLIB_handleSendTraceStart(callInfo_type *, enqueuedAction);
int16_t VLIB_handleSendDeactivateTrace(callInfo_type *, enqueuedAction);
int16_t VLIB_sendTraceDuStopStartNoti(callInfo_type *ptCi, enumTrace_type);
int16_t VLIB_sendDeactivateTrace(callInfo_type *ptCi, enumTrace_type traceType, uint16_t cellNum);
int16_t VLIB_handleSendMgtCellTrafficTrace(callInfo_type *ptCi, enqueuedAction);
int16_t VLIB_handleStartManagementMdtAndUeThr(callInfo_type *ptCi, enqueuedAction);
int16_t VLIB_handleSendTraceFailureIndication(callInfo_type *ptCi, enqueuedAction);
int16_t VLIB_sendCellTrafficTrace(callInfo_type *ptCi, LocalTraceConfig_type *localTraceInfo);
void VLIB_TraceAudit(callInfo_type *ptCi);

#endif
