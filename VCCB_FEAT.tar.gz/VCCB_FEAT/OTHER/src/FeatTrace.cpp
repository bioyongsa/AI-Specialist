/****************************************************************
 * System      : 5G vNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatTrace.cpp
 * Description : This file contains functions related to Trace features
 * Dept.       : 5G Call SW Lab.
 * Created     : 2021.05.21
 ****************************************************************/
/**
 * @file FeatAmf.c
 * @brief This file contains functions related to Trace features
 */

#include <mutex>
#include "FeatTrace.h"
#include "FeatTrace.hpp"
#include "FeatMro.h"
#include "FeatLtmHo.h"
#include "FeatCommon.h"

#include "ComInclude.h"
#include "ComLibUtility.h"
#include "ComTimeUtil.h"

#include "MsgTmbSend.h"
#include "MsgF1apSend.h"

#include "StateMeasurements.h"
#include "StateCommon.h"

#include "MsgE1apSend.h"
#include "MsgXnapSend.h"
#include "MsgX2apSend.h"
#include "MsgNgapSend.h"
#include "MsgNrRrcStore.h"
#include "MsgCommonStore.h"
#include "MsgCommonMake.hpp"

#include "PM_FAMILY_ID.h"
#include "PM_TYPE_ID.h"

static std::mutex gTrsrAllocMtx;
static std::mutex gSigUeCntMtx;

typedef struct callInfo_type::Trace_s::TraceRecordingSession_s TraceRecordingSession_type;

/**
 * @brief  [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Perform random selection with selectionRate (1:100%)
 * @return  true  : Random selectioion positive - accept
 *          false : Random selection negative - decline
 */
static inline bool VLIB_mdtRandomSelection(uint16_t gnbNum, uint8_t selectionRate)
{
    const unsigned int randomValue = FnVCCB_GetRandomValue(__func__, gnbNum, 100);

    if (randomValue < selectionRate)
    {
        return true;
    }
    return false;
}

const char* EnumJobTypeStr(enumJobType enumTraceJobType)
{
    switch(enumTraceJobType)
    {
        case mdt_immediate:
            return "[MDT][IMM]";
        case mdt_logged:
            return "[MDT][LOGG]";
        case mdt_rlf_rcef:
            return "[MDT][RLF/RCEF]";
        case trace_ctt:
            return "[TRACE][CELL]";
        case trace_uethr:
            return "[TRACE][UETHR]";
        case mdt_trace_all:
            return "[TRACE][ALL]";
        default:
            return "[UNKNOWN]";
    }
}

const char* EnumJobTypeStr(const char* strArg)
{
    return strArg;
}

int16_t TraceDepthLinkToUniversal(X2AP_TraceDepth inDepth, universalTraceDepth_type &outDepth)
{
    switch(inDepth)
    {
        case X2AP_minimum:
            outDepth = minimum;
            break;
        case X2AP_TraceDepth_medium:
            outDepth = medium;
            break;
        case X2AP_maximum:
            outDepth = maximum;
            break;
        case X2AP_minimumWithoutVendorSpecificExtension:
            outDepth = minimumWithoutVendorSpecificExtension;
            break;
        case X2AP_mediumWithoutVendorSpecificExtension:
            outDepth = mediumWithoutVendorSpecificExtension;
            break;
        case X2AP_maximumWithoutVendorSpecificExtension:
            outDepth = maximumWithoutVendorSpecificExtension;
            break;
        default:
            return ERROR;
    }
    return GOOD;
}

int16_t TraceDepthLinkToUniversal(NGAP_TraceDepth inDepth, universalTraceDepth_type &outDepth)
{
    switch(inDepth)
    {
        case NGAP_minimum:
            outDepth = minimum;
            break;
        case NGAP_TraceDepth_medium:
            outDepth = medium;
            break;
        case NGAP_maximum:
            outDepth = maximum;
            break;
        case NGAP_minimumWithoutVendorSpecificExtension:
            outDepth = minimumWithoutVendorSpecificExtension;
            break;
        case NGAP_mediumWithoutVendorSpecificExtension:
            outDepth = mediumWithoutVendorSpecificExtension;
            break;
        case NGAP_maximumWithoutVendorSpecificExtension:
            outDepth = maximumWithoutVendorSpecificExtension;
            break;
        default:
            return ERROR;
    }
    return GOOD;
}

int16_t TraceDepthLinkToUniversal(XNAP_Trace_Depth inDepth, universalTraceDepth_type &outDepth)
{
    switch(inDepth)
    {
        case XNAP_minimum:
            outDepth = minimum;
            break;
        case XNAP_medium:
            outDepth = medium;
            break;
        case XNAP_maximum:
            outDepth = maximum;
            break;
        case XNAP_minimumWithoutVendorSpecificExtension:
            outDepth = minimumWithoutVendorSpecificExtension;
            break;
        case XNAP_mediumWithoutVendorSpecificExtension:
            outDepth = mediumWithoutVendorSpecificExtension;
            break;
        case XNAP_maximumWithoutVendorSpecificExtension:
            outDepth = maximumWithoutVendorSpecificExtension;
            break;
        default:
            return ERROR;
    }
    return GOOD;
}

void TraceDepthUniversalToXnLink(universalTraceDepth_type inDepth, XNAP_Trace_Depth &outDepth)
{
    switch(inDepth)
    {
        case minimum:
            outDepth = XNAP_minimum;
            break;
        case medium:
            outDepth = XNAP_medium;
            break;
        case maximum:
            outDepth = XNAP_maximum;
            break;
        case minimumWithoutVendorSpecificExtension:
            outDepth = XNAP_minimumWithoutVendorSpecificExtension;
            break;
        case mediumWithoutVendorSpecificExtension:
            outDepth = XNAP_mediumWithoutVendorSpecificExtension;
            break;
        case maximumWithoutVendorSpecificExtension:
            outDepth = XNAP_maximumWithoutVendorSpecificExtension;
            break;
        default:
            return;
    }
}

bool FnVCCB_extractTacStrFromMaskedIMEISV(const VccbMaskedIMEISV_type *maskedIMEISV, char *outTac)
{
    VALID_E_POINT_CHECK_RET_VAL(maskedIMEISV, False);
    VALID_E_POINT_CHECK_RET_VAL(outTac, False);

    char localTac[IMEI_TAC_BUF_SIZE];
    localTac[0] = '\0';

    if (maskedIMEISV->length < 32U) // minimum length required to extract IMEI-TAC
    {
        return false;
    }

    int digitIdx = 0;

    for (int byteIdx = 0; byteIdx < 4; ++byteIdx)
    {
        const uint8_t currentByte = maskedIMEISV->value[byteIdx];
        const uint8_t lowNibble = currentByte & 0x0F;
        const uint8_t highNibble = (currentByte >> 4) & 0x0F;

        if (highNibble > 9 || lowNibble > 9)
        {
            return false; // invalid BCD digit
        }

        localTac[digitIdx++] = static_cast<char>('0' + highNibble);
        localTac[digitIdx++] = static_cast<char>('0' + lowNibble);
    }

    localTac[IMEI_TAC_BUF_SIZE - 1] = '\0';
    
    // Only copy to output buffer on success
    memcpy(outTac, localTac, IMEI_TAC_BUF_SIZE);
    return true;
}

TraceRecordingSession_type* getTraceSession(callInfo_type *ptCi, uint16_t cellNum, bool withCreate)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, nullptr);

    uint8_t freeId = MAX_TRACE_SESSION_ENTRY;
    TraceRecordingSession_type *pSession = nullptr;
    for (uint8_t i=0; i<MAX_TRACE_SESSION_ENTRY; ++i)
    {
        pSession = &ptCi->managementTraceInfo.session[i];
        if (CI_no_use == pSession->usage)
        {
            freeId = i;
        }
        else if (cellNum == pSession->traceCellNum)
        {
            VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_trace_all, "Session for cellNum(%u) obtained\n", cellNum);
            return pSession;
        }
    }

    if (withCreate && MAX_TRACE_SESSION_ENTRY > freeId)
    {
        pSession = &ptCi->managementTraceInfo.session[freeId];
        memset(pSession, 0x00, sizeof(TraceRecordingSession_type));
        pSession->usage = CI_use;
        pSession->cttForTraceDelivered = FALSE;
        pSession->traceCellNum = cellNum;
        pSession->trsrAllocIdx = MAX_UE_PER_CELL_TRACE_SESSION;
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_trace_all, "Session for cellNum(%u) created\n", cellNum);
        return pSession;
    }

    VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_trace_all, "No session for cellNum(%u) (withCreate=%u)\n", cellNum, withCreate);
    return nullptr;
}

void clearTraceSession(callInfo_type *ptCi, TraceRecordingSession_type *pRecordingSession)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pRecordingSession);
    pRecordingSession->usage = CI_no_use;
    memset(&(pRecordingSession->jobStatus), 0x00, sizeof(pRecordingSession->jobStatus));
    VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_trace_all, "Session of cellNum(%u) cleared\n", pRecordingSession->traceCellNum);
}

static void VLIB_collectManagementTraceMessage(callInfo_type *ptCi, LocalTraceConfig_type *pLocalTraceInfo);

/**
 * @brief  [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 *         [FGR-TA0103] Cell traffic trace
 *         [FGR-TA0104] UE Throughput and RF Trace
 * @details Allcate TRSR and increment its index, common for management based trace and mdt
 * @return  GOOD  : Successfully allocated new
 *          BREAK : TRSR already allocated - reusing
 *          ERROR : Error in case of allocation error
 */
int16_t VLIB_allocateTrsr(callInfo_type *ptCi, uint16_t cellNum, enumJobType job)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VccbCfgInfo_type *const pCfg = CFG;
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    ManagementTraceSessionPerCell_type *pSession = &pCell->traceSession;
    TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, cellNum, true);

    if (nullptr == pRecordingSession)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, job, "Error session allocation for cellNum(%u)\n", cellNum);
        return ERROR;
    }

    int16_t status = GOOD;
    uint16_t dummyCnt = 0;
    uint32_t dummyCnt2 = 0;

    uint16_t *pCellFeatureCounterCpc = &dummyCnt; // trace, immediate or logged
    uint32_t *pAcpfFeatureCounterCpc = &dummyCnt2; // acpf level - number of UE per logged/immediate/trace
    uint32_t *pAcpfTrsrCounter = &pCfg->globalTraceInfo.management.totalMgtUeCountCpc; // acpf level - total number of mgt TRSR session

    switch(job)
    {
        case mdt_immediate:
            pCellFeatureCounterCpc = &pSession->mdt.immediateMdtUeCountCpc;
            pAcpfFeatureCounterCpc = &dummyCnt2;
            break;

        case mdt_logged:
            pCellFeatureCounterCpc = &pSession->mdt.loggedMdtUeCountCpc;
            pAcpfFeatureCounterCpc = &dummyCnt2;
            break;

        case trace_ctt:
        case trace_uethr:
            if (VCCB_FLAG_ON == pRecordingSession->jobStatus.cellTraceFlag ||
                VCCB_FLAG_ON == pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag)
            {
                // one of them already activated so prevent doubled counter incrementation
                pCellFeatureCounterCpc = &dummyCnt;
                pAcpfFeatureCounterCpc = &dummyCnt2;
            }
            else
            {
                pCellFeatureCounterCpc = &pSession->trace.cellTraceUeCountCpc;
                pAcpfFeatureCounterCpc = &pCfg->globalTraceInfo.management.cellTraceUeCountCpc;
            }
            break;

        case mdt_rlf_rcef:
            break;

        default:
            VCCB_PRINT_TRACE_ERROR(ptCi, job, "TRSR cannot be allocated for cellNum(%u), invalid jobType(%u) - ERROR!\n", cellNum, job);
            return ERROR;
    }

    std::lock_guard<std::mutex> lock(gTrsrAllocMtx);

    // if one of trace job flag already enabled TRSR should already be allocated
    const bool isTrsrAllocated{ VCCB_FLAG_ON == pRecordingSession->jobStatus.cellTraceFlag ||
                                VCCB_FLAG_ON == pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag ||
                                VCCB_FLAG_ON == pRecordingSession->jobStatus.immediateMdtFlag ||
                                VCCB_FLAG_ON == pRecordingSession->jobStatus.loggedMdtFlag ||
                                VCCB_FLAG_ON == pRecordingSession->jobStatus.rlfOrRcefFlag };

    if (VCCB_FLAG_ON == isTrsrAllocated)
    {
        // TRSR session already exists, just increment feature counters
        (*pCellFeatureCounterCpc)++;
        (*pAcpfFeatureCounterCpc)++;

        VCCB_PRINT_TRACE_COMMENT(ptCi, job, "TRSR already allocated for cellNum(%u)\n", cellNum);
        return BREAK;
    }

    if (TRUE == pCfg->globalTraceInfo.pldLimitCheck)
    {
        if(VCCB_FLAG_OFF == pCfg->globalTraceInfo.acpfTraceAllowedFlag)
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, job, "Not started due to ACPF PLD limit reached!\n");
            status = ERROR;
        }
    }
    else
    {
        const uint32_t cpcUeNumTotal = { pCfg->globalTraceInfo.management.totalMgtUeCountCpc + 
            pCfg->globalTraceInfo.signaling.totalSigUeCountCpc };

        if (cpcUeNumTotal >= (pCfg->globalTraceInfo.maxAcpfTracesNum / pCfg->globalTraceInfo.acpfCpcCnt))
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, job, "Not started due to local ACPF limit reached!\n");
            status = ERROR;
        }
    }

    if (GOOD == status)
    {
        // Allocate Cell Trace Recording Session Reference
        uint16_t lookupCounter = MAX_UE_PER_CELL_TRACE_SESSION;
        status = ERROR;
        while (lookupCounter--)
        {
            pSession->cellTrsrAllocIdx++;
            pSession->cellTrsrAllocIdx %= MAX_UE_PER_CELL_TRACE_SESSION;

            if (MAX_CALL_NUM_VCCB > pSession->cellTRSR[pSession->cellTrsrAllocIdx])
            {
                continue;
            }

            pSession->cellTRSR[pSession->cellTrsrAllocIdx] = ptCi->callId;

            // Multi CPC Support
            pRecordingSession->traceRecordingSessionReference =
                static_cast<uint16_t>(GET_REDUNDANT_CPC_ID * MAX_UE_PER_CELL_TRACE_SESSION + pSession->cellTrsrAllocIdx);
            pSession->allocatedTRSRCount++;
            pRecordingSession->trsrAllocIdx = pSession->cellTrsrAllocIdx;
            status = GOOD;
            break;
        }
    }

    if (GOOD != status)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, job, "TRSR not allocated for cellNum(%u):job(%u) - ERROR!\n", cellNum, job);
        clearTraceSession(ptCi, pRecordingSession);
        return status;
    }
    
    VCCB_PRINT_TRACE_COMMENT(ptCi, job, "TRSR(%u) for cellNum(%u):job(%u) allocated\n", pRecordingSession->traceRecordingSessionReference, cellNum, job);

    // new TRSR session, increment feature and trsr session counters
    (*pCellFeatureCounterCpc)++;
    (*pAcpfFeatureCounterCpc)++;
    (*pAcpfTrsrCounter)++;

    return status;
}

/**
 * @brief  [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 *         [FGR-TA0103] Cell traffic trace
 *         [FGR-TA0104] UE Throughput and RF Trace
 * @details Deallcate TRSR and decrement its index, common for management based trace and mdt
 * @return  GOOD  : Successfully deallocated new
 *          BREAK : TRSR already deallocated or still needed - reusing
 *          ERROR : Error in case of deallocation error
 */
int16_t VLIB_deallocateTrsr(callInfo_type *ptCi, uint16_t cellNum, enumJobType job, bool force)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VccbCfgInfo_type *const pCfg = CFG;
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    ManagementTraceSessionPerCell_type *pSession = &pCell->traceSession;
    TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, cellNum, false);
    int16_t status = GOOD;

    if (nullptr == pRecordingSession)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, job, "Cannot get session for cellNum(%u)\n", cellNum);
        return ERROR;
    }

    uint16_t dummyCnt = 2;
    uint32_t dummyCnt2 = 2;

    uint16_t *pCellFeatureCounterCpc = &dummyCnt; // trace, immediate or logged
    uint32_t *pAcpfFeatureCounterCpc = &dummyCnt2; // acpf level - number of UE per logged/immediate/trace
    uint32_t *pAcpfTrsrCounter = &pCfg->globalTraceInfo.management.totalMgtUeCountCpc; // acpf level - total number of mgt TRSR session

    switch(job)
    {
        case mdt_immediate:
            pCellFeatureCounterCpc = &pSession->mdt.immediateMdtUeCountCpc;
            pAcpfFeatureCounterCpc = &dummyCnt2;
            break;

        case mdt_logged:
            pCellFeatureCounterCpc = &pSession->mdt.loggedMdtUeCountCpc;
            pAcpfFeatureCounterCpc = &dummyCnt2;
            break;

        case trace_ctt:
        case trace_uethr:
            if (!force && (VCCB_FLAG_ON == pRecordingSession->jobStatus.cellTraceFlag ||
                VCCB_FLAG_ON == pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag))
            {
                // one of feature is still working, prevent decrementation of shared counter
                pCellFeatureCounterCpc = &dummyCnt;
                pAcpfFeatureCounterCpc = &dummyCnt2;
            }
            else
            {
                pCellFeatureCounterCpc = &pSession->trace.cellTraceUeCountCpc;
                pAcpfFeatureCounterCpc = &pCfg->globalTraceInfo.management.cellTraceUeCountCpc;
            }
            break;

        case mdt_rlf_rcef:
            break;

        default:
            VCCB_PRINT_TRACE_ERROR(ptCi, job, "TRSR not cannot be dealocated for cellNum(%u), invalid jobType(%u) - ERROR!\n", cellNum, job);
            return ERROR;
    }

    // Multi CPC Support
    uint16_t trsrIndex = pRecordingSession->trsrAllocIdx;

    std::lock_guard<std::mutex> lock(gTrsrAllocMtx);

    if (trsrIndex < MAX_UE_PER_CELL_TRACE_SESSION)
    {
        if (*pCellFeatureCounterCpc > 0)
        {
            --(*pCellFeatureCounterCpc);
        }

        if (*pAcpfFeatureCounterCpc > 0)
        {
            --(*pAcpfFeatureCounterCpc);
        }
        
        // if other trace job already enabled TRSR should remain allocated
        bool const skipDealocateTRSR = VCCB_FLAG_ON == pRecordingSession->jobStatus.cellTraceFlag ||
                                       VCCB_FLAG_ON == pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag ||
                                       VCCB_FLAG_ON == pRecordingSession->jobStatus.immediateMdtFlag ||
                                       VCCB_FLAG_ON == pRecordingSession->jobStatus.loggedMdtFlag ||
                                       VCCB_FLAG_ON == pRecordingSession->jobStatus.rlfOrRcefFlag;

        if (true == skipDealocateTRSR && !force)
        {
            VCCB_PRINT_TRACE_COMMENT(ptCi, job, "Keep TRSR allocated, cellNum(%d)\n", cellNum);
            return BREAK;
        }

        if (MAX_CALL_NUM_VCCB <= pSession->cellTRSR[trsrIndex] && !force)
        {
            VCCB_PRINT_TRACE_COMMENT(ptCi, job, "TRSR already deallocated, TRSRidx(%d), cellNum(%d)\n", trsrIndex, cellNum);
            status = GOOD;
        }
        else
        {
            pSession->cellTRSR[trsrIndex] = UNKNOWN_VCCB_CALLID;
            if (pSession->allocatedTRSRCount > 0)
            {
                pSession->allocatedTRSRCount--;
            }

            if (*pAcpfTrsrCounter > 0)
            {
                --(*pAcpfTrsrCounter);
            }

            status = GOOD;
            pRecordingSession->trsrAllocIdx = MAX_UE_PER_CELL_TRACE_SESSION;
            VCCB_PRINT_TRACE_COMMENT(ptCi, job, "TRSR deallocated, TRSRidx(%d), cellNum(%d)\n", trsrIndex, cellNum);
        }
    }

    return status;
}

/**
 * @brief   [FGR-TA0103] Cell traffic trace.
 *          [FGR-TA0104] UE Throughput and RF Trace
 *          [FGR-TA0101] Subscriber And Equipment Trace
 *          [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Check CPC overload state and decide whether stop Trace processing based on configured thresholds
 * @return  true  : Trace processing shall stop due to CPC overload
 *          false : Trace processing can continue
 */
bool VLIB_traceDisabledDueToOverload(void)
{
    AUTO_TRACE_FUNC;
    const VccbCfgInfo_type *const pCfg = CFG;

    if (pCfg->globalTraceInfo.overloadOnOff)
    {
        VCCB_PRINT_COMMENT("[TRACE] Overload status: level:%d Threshold:%d TraceDisabledFlag: %d\n",
            pCfg->overloadStatus, pCfg->globalTraceInfo.stopThreshold,
            pCfg->globalTraceInfo.traceDisabledDueOverload);

        if (pCfg->overloadStatus != 0)
        {
            if (pCfg->overloadStatus - 1 <= pCfg->globalTraceInfo.stopThreshold)
            {
                VCCB_PRINT_COMMENT("[TRACE] CPC overload exceeded Trace STOP threshold\n");
                return true;
            }

            if (pCfg->overloadStatus - 1 < pCfg->globalTraceInfo.resumeThreshold &&
                pCfg->overloadStatus - 1 > pCfg->globalTraceInfo.stopThreshold &&
                pCfg->globalTraceInfo.traceDisabledDueOverload)
            {
                VCCB_PRINT_COMMENT("[TRACE] CPC overload above RESUME threshold\n");
                return true;
            }
        }
    }

    return false;
}
/**
 * @brief   [FGR-TA0103] Cell traffic trace.
 *          [FGR-TA0101] Subscriber And Equipment Trace
 *          [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Check servin PLMN exists at Trace PLMN list or list empty
 * @param   [in] ptCi     : pointer to Call Context
 * @param   [in] pSession : cell management trece session info
 * @return  true  : PLMN available on list or list empty
 *          false : PLMN not on trace list
 */
bool VLIB_checkPlmnOnTraceList(callInfo_type *ptCi, ManagementTraceSessionPerCell_type *pSession)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, False);
    VALID_E_POINT_CHECK_RET_VAL(pSession, False);
    // - target plmns     configured - collect UEs with related serving plmn
    // - target plmns not configured - ignore serving plmn
    if (pSession->targetPlmns.statuses != 0)  // at least one target plmn entry EQUIP - target plmns configured
    {
        if (ptCi->callType == E_CALLTYPE_SA &&  // only on SA servingPlmn may not be instantly known
            ptCi->managementTraceInfo.tracePLMNavailable == FALSE)
        {
            VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt, 
            "state:%d servingPlmn not yet known for target-plmns\n", ptCi->state);
            return false;
        }

        uint8_t plmnIdx = 0, shouldTraceThisPlmn = FALSE;

        for (plmnIdx = 0; plmnIdx < MAX_PLMN_INDEX; ++plmnIdx)
        {
            if (N_EQUIP == GETBIT(pSession->targetPlmns.statuses, plmnIdx))
            {
                continue;
            }

            if (pSession->targetPlmns.plmn[plmnIdx].longId == ptCi->ueInfo.servedPlmn.longId)
            {
                shouldTraceThisPlmn = TRUE;
            }
        }

        if (FALSE == shouldTraceThisPlmn)
        {
            VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt, "servingPlmn(mcc:%x,mnc:%x) not present on target-plmns list\n",
                ptCi->ueInfo.servedPlmn.s2.mcc, ptCi->ueInfo.servedPlmn.s2.mnc);
            return false;
        }
    }
    return true;
}

/**
 * @brief   [FGR-SO1101] NR Minimization of Drive Tests (NR MDT) - Check Allowed IMEI-TAC List
 * @details This function checks if the TAC (Type Allocation Code) of the UE's IMEISV (IMSI Supplementary Value) is present in the allowed IMEI-TAC list.
 *          It is used to filter devices based on their TAC for NR MDT purposes. The function returns true if the TAC is allowed or if filtering is disabled,
 *          and false otherwise.
 * @param   [in] ptCi               : Pointer to Call Context containing UE information.
 * @param   [in] allowedImeiTacList : Pointer to the list of allowed IMEI-TACs.
 * @param   [in] tacFilterOn        : Flag indicating whether TAC filtering is enabled.
 * @return  true  : TAC is allowed or filtering is disabled.
 *          false : TAC is not allowed or filtering is enabled but TAC is not in the list.
 */
bool VLIB_checkAllowedImsiTacList(callInfo_type *ptCi, const AllowedImeiTacList_type *allowedImeiTacList, uint8_t tacFilterOn)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, False);
    VALID_E_POINT_CHECK_RET_VAL(allowedImeiTacList, False);

    if (!tacFilterOn)
    {
        return true;
    }

    if (allowedImeiTacList->count == 0)
    {
        return false;
    }

    if (!VXIL_Check_MaskedIMEISVPresent(*ptCi))
    {
        return false;
    }

    const VccbMaskedIMEISV_type *maskedIMEISV = &ptCi->ueInfo.imeisvBuf.maskedIMEISV;
    char ueTac[IMEI_TAC_BUF_SIZE] = {0};

    if (!FnVCCB_extractTacStrFromMaskedIMEISV(maskedIMEISV, ueTac))
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt, "Masked IMEISV invalid or too short. TAC extraction failed.\n");
        return false;
    }

    for (uint8_t i = 0, cnt = 0; i < MAX_IMEI_TAC_INDEX && cnt < allowedImeiTacList->count; ++i)
    {
        if (!GETBIT_U32(allowedImeiTacList->statuses, i))
        {
            continue;
        }

        ++cnt;

        if (memcmp(allowedImeiTacList->tac[i], ueTac, IMEI_TAC_BUF_SIZE) == 0)
        {
            return true;
        }
    }

    VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt, "TAC not present on allowed-imei-tac-list.\n");
    return false;
}

static enumSigActFailResult checkTraceUethrCellLimitReached(TraceRecordingSession_type *pRecordingSession, uint16_t cellNum)
{
    const VccbCfgInfo_type *pCfg = CFG;
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    ManagementTraceSessionPerCell_type *pSessionCfg = &pCell->traceSession;

    // check if already started validated at feature activation level so OR can be used
    const bool isStarted { nullptr != pRecordingSession && 
                                (VCCB_FLAG_ON == pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag ||
                                 VCCB_FLAG_ON == pRecordingSession->jobStatus.cellTraceFlag) };

    // if UETHR (for Trace) or Trace (for UETHR) not yet started than limit flags have to be verified - UETHR and CTT share limit counter
    if (false == isStarted)
    {
        if (pSessionCfg->trace.cellTraceUeCountCpc >= pSessionCfg->trace.cellMaxUeNum)
        {
            return trace_cell_limit;
        }

        if(TRUE == pCfg->globalTraceInfo.pldLimitCheck && 
           VCCB_FLAG_OFF == pSessionCfg->trace.cellTraceAllowedFlag)
        {
            return acpf_limit;
        }
    }

    return no_error;
}


/**
 *
 * @brief   [FGR-TA0103] Cell traffic trace.
 *          Thread safe function to monitor Cell Trace UE Count per session.
 * @details Adds UE to Cell Trace group
 *          Before this function is called 'ptCi->managementTraceInfo.traceInfo.traceCellNum' nedds to be set to serving
 * cell or Intra gnb HO target cell
 * @param   [in] ptCi            : pointer to Call Context
 * @param   [in] pLocalTraceInfo : pointer to TraceInformation
 * @param  [out] pNeedSendCTTmsg : flag indicatig if cellTrafficTrace send is needed after delivering trace message to VTMB
 * @return  GOOD   : UE successfully added to Cell Trace group or has already been previously added
 *          BREAK  : Already started
 *          ERROR  : add error
 */
int16_t VLIB_startManagementTraceRecordingSession(callInfo_type *ptCi, LocalTraceConfig_type *pLocalTraceInfo, uint8_t *pNeedSendCTTmsg)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pLocalTraceInfo);
    VALID_E_POINT_CHECK_ERROR(pNeedSendCTTmsg);
    VCCB_CALL_CHECK_RANGE_AND_RETURN(ptCi, pLocalTraceInfo->cellNum, MAX_CELL_NUM_VCCB, "pLocalTraceInfo->cellNum");
    VccbCellInfo_type *const pCell = &CELLINFO[pLocalTraceInfo->cellNum];

    VCCB_CALL_CHECK_RANGE_AND_RETURN(ptCi, pCell->gnbNum, MAX_GNB_PER_SYS, "pCell->gnbNum");
    ManagementTraceSessionPerCell_type *pSessionCfg = &pCell->traceSession;

    // Check if Trace Session is enabled
    if (pSessionCfg->traceSessJobOnOff == 0 || pSessionCfg->managementJobType.trace == 0)
    {
        VCCB_PRINT_TRACE_COMMENT(
                ptCi, trace_ctt, "gNBId:cellId(%u:%u): is turn OFF\n", pLocalTraceInfo->gnbId, pLocalTraceInfo->cellId);
        return ERROR;
    }

    if(reporting_disabled ==  VLIB_checkConfiguredReportingType(ptCi))
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt, "Tracing for call type currently disabled\n"); 
        return ERROR;
    }

    if (ueTraceDisabled != ptCi->signalingTraceInfo.trace.traceStatus)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt, "Cannot activate session - signaling trace already running!\n"); 
        return ERROR;
    }

    // Check if Message and interface are enabled for trace
    if (!(pLocalTraceInfo->traceInterface & pSessionCfg->trace.interfaces))
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt,
                "gNBId:cellId(%u:%u): msgInterface(%s) tracing for current interface is "
                "turn OFF. interfaces: %d\n",
                pLocalTraceInfo->gnbId, pLocalTraceInfo->cellId, READABLE_TRACE_IF(pLocalTraceInfo->traceInterface),
                pSessionCfg->trace.interfaces);
        return ERROR;
    }

    TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, pLocalTraceInfo->cellNum, false);

    if (nullptr != pRecordingSession && VCCB_FLAG_ON == pRecordingSession->jobStatus.cellTraceFlag)
    {
        return BREAK;  // Cell Trace already started
    }

    // Check max UE count for Trace Session
    switch (checkTraceUethrCellLimitReached(pRecordingSession, pLocalTraceInfo->cellNum))
    {
        case no_error:
            break;

        case trace_cell_limit:
            VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt, "Not started due to cell(num:%u) limit reached!\n", pLocalTraceInfo->cellNum);
            return ERROR;

        case acpf_limit:
            VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt, "Not started due to PLD CTT/UETHR limit reached!\n");
            return ERROR;

        default:
            return ERROR;
    }

    // 4 Check target plmn
    if (false == VLIB_checkPlmnOnTraceList(ptCi, pSessionCfg))
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt,
                "gNBId:cellId(%u:%u) servingPlmn(mcc:%x,mnc:%x) not present on target-plmns list\n",
                pLocalTraceInfo->gnbId, pLocalTraceInfo->cellId, ptCi->ueInfo.servedPlmn.s2.mcc,
                ptCi->ueInfo.servedPlmn.s2.mnc);
        return ERROR;
    }

    // TRSR allocation (common for Cell Trace, MDT, UE Thr)
    int16_t trsrStatus = VLIB_allocateTrsr(ptCi, pLocalTraceInfo->cellNum, trace_ctt);
    if (ERROR == trsrStatus)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, trace_ctt, "TRSR allocation ERROR\n");
        return ERROR;
    }

    // TRSR allocation can create new traceSession so update pointer
    pRecordingSession = getTraceSession(ptCi, pLocalTraceInfo->cellNum, false);
    if (nullptr == pRecordingSession)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, trace_ctt, "Cannot get session for cellNum(%u)\n", pLocalTraceInfo->cellNum);
        return ERROR;
    }

    pRecordingSession->jobStatus.cellTraceFlag = VCCB_FLAG_ON;
    // Send CellTrafficTrace after trace message deliverd to VTMB
    //  not here in order to not impact vccb->vtmb flow
    *pNeedSendCTTmsg = VCCB_FLAG_ON;

    int16_t status = VIIL_sendTraceStatusVccbVtmb(ptCi, Trace_Management, pLocalTraceInfo->cellNum);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_sendTraceStatusVccbVtmb (cellNum: %d) ERROR!\n", pLocalTraceInfo->cellNum);
        return ERROR;
    }

    VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt,
            "gId:cId:trId:trsr(%u:%u:%u:%u) TrsrCnt:%u(trace:%u immediate:%u logged:%u), "
            "allocIdx:%u, trsrAllocStatus(%d)\n",
            pLocalTraceInfo->gnbId, pCell->cellIdentity, pSessionCfg->cellTraceReference.traceId,
            pRecordingSession->traceRecordingSessionReference, pSessionCfg->allocatedTRSRCount,
            pSessionCfg->trace.cellTraceUeCountCpc, pSessionCfg->mdt.immediateMdtUeCountCpc,
            pSessionCfg->mdt.loggedMdtUeCountCpc, pSessionCfg->cellTrsrAllocIdx, trsrStatus);

    return GOOD;
}

/**
 * @brief   FGR-TA0103 Cell traffic trace.
 *          FGR-TA0104 UE Throughput and RF Trace
 *          Thread safe function to stop Trace Recording Sessions (+ UE Throughput) on cell
 * @details Removes UE from Cell Trace group
 *          Before this function is called 'ptCi->managementTraceInfo.traceInfo.traceCellNum' needs to be set to serving
 * cell or Intra gnb HO target cell
 * @param [in] ptCi                             : pointer to Call Context
 * @param [in] CellNum                          : cell to be released
 * @return     GOOD                             : UE successfully deleted from Cell Trace group or nothing to release
 */
int16_t VLIB_stopManagementTraceRecordingSession(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    VCCB_CHECK_E_RANGE_AND_RETURN(pCell->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[pCell->gnbNum];
    uint32_t gnbId = pGnb->globalGnbId.gnbId.id;
    ManagementTraceSessionPerCell_type *pSession = &pCell->traceSession;
    TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, cellNum, false);

    if (nullptr == pRecordingSession)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, trace_ctt, "Cannot get session for cellNum(%u)\n", cellNum);
        return BREAK;
    }

    if (VCCB_FLAG_OFF == pRecordingSession->jobStatus.cellTraceFlag)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt, "Cell Traffic Trace already released\n");
        return GOOD;
    }

    bool isLtmCell = false;
    for (auto &rCell : ptCi->ltmUeInfo.cellList)
    {
        if (rCell.handle.usage == 0) { continue;}
        if (cellNum == rCell.data.cellSelection.cellNum)
        {
            isLtmCell = true;
            break;
        }
    }

    if (isLtmCell && STATE_Ltm_Prep_TgtDuRel != ptCi->state)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt, "Keep CTT job for LTM cellNum:%u\n", cellNum);
        return GOOD;
    }

    pRecordingSession->jobStatus.cellTraceFlag = VCCB_FLAG_OFF;

    // Remove UE from Cell Trace group
    if (GOOD == VLIB_deallocateTrsr(ptCi, cellNum, trace_ctt))
    {
        clearTraceSession(ptCi, pRecordingSession);
    }

    VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt,
        "[UE REL] gId:cId:trId:trsr(%u:%u:%u:%u) TrsrCnt:%u(trace:%u immediate:%u logged:%u), "
        "allocIdx:%u\n",
        gnbId, pCell->cellIdentity, pSession->cellTraceReference.traceId,
        pRecordingSession->traceRecordingSessionReference, pSession->allocatedTRSRCount,
        pSession->trace.cellTraceUeCountCpc, pSession->mdt.immediateMdtUeCountCpc,
        pSession->mdt.loggedMdtUeCountCpc, pSession->cellTrsrAllocIdx);

    int16_t status = VIIL_sendTraceStatusVccbVtmb(ptCi, Trace_Management, cellNum);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_sendTraceStatusVccbVtmb (cellNum: %d) ERROR!\n", cellNum);
        return ERROR;
    }

    return GOOD;
}

int VLIB_checkIfSendSignalingTrace(callInfo_type *ptCi, LocalTraceConfig_type *pLocalTraceInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(pLocalTraceInfo);
    const VccbCfgInfo_type *const pCfg = CFG;

    if (E_CALLTYPE_NSA == ptCi->callType)
    {
        if (!pCfg->globalTraceInfo.signaling.trace.nsaSignalingTraceOnOff)
        {
            VCCB_PRINT_TRACE_COMMENT(ptCi, "[TRACE][SIG]", "nsaSignalingTrace is off\n");
            return FALSE;
        }
        if ((pLocalTraceInfo->traceInterface == TRACE_BITMASK_X2C) &&
            !pCfg->globalTraceInfo.signaling.trace.endcX2TraceOnOff)
        {
            VCCB_PRINT_TRACE_COMMENT(ptCi, "[TRACE][SIG]", "x2Trace is off\n");
            return FALSE;
        }
    }

    if (IS_NRDC_SN(ptCi))
    {
        if (!pCfg->globalTraceInfo.signaling.trace.nrdcSignalingTraceOnOff)
        {
            VCCB_PRINT_TRACE_COMMENT(ptCi, "[TRACE][SIG]", "nrdcSignalingTraceOnOff is off\n");
            return FALSE;
        }
        if ((pLocalTraceInfo->traceInterface == TRACE_BITMASK_XNC) &&
            !pCfg->globalTraceInfo.signaling.trace.nrdcSnXnTraceOnOff)
        {
            VCCB_PRINT_TRACE_COMMENT(ptCi, "[TRACE][SIG]", "nrdcSnXnTrace is off\n");
            return FALSE;
        }
    }

    const int matched = pLocalTraceInfo->traceInterface & ptCi->signalingTraceInfo.trace.traceInterfaces;

    if (0 == matched)
    {
            VCCB_PRINT_TRACE_COMMENT(ptCi, "[TRACE][SIG]", "not tracing - interface %u is not in mask %u\n",
                    pLocalTraceInfo->traceInterface, ptCi->signalingTraceInfo.trace.traceInterfaces);
        return FALSE;
    }

    if (ptCi->signalingTraceInfo.trace.traceStatus == ueTraceEnabledAndActive)
    {
        return TRUE;
    }

    return FALSE;
}

int16_t FnVCCB_PrepareXNAP_CellTrafficTrace(callInfo_type *ptCi, LocalTraceConfig_type *pLocalTraceInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pLocalTraceInfo);

    int16_t status = 0;
    uint32_t tceLoopMax = (pLocalTraceInfo->configTraceType == mdt_only) ? 1 : TCE_NUM_PER_CELL_TRACE_SESSION;

    for (uint32_t tceIdx = 0; tceIdx < tceLoopMax; ++tceIdx)
    {
        status = FnVCCB_SendXNMessage(XN_CellTrafficTrace_id, ptCi, pLocalTraceInfo, &tceIdx);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage (XN_CellTrafficTrace_id) ERROR!\n");
    }

    return GOOD;
}

int16_t VLIB_sendCellTrafficTrace(callInfo_type *ptCi, LocalTraceConfig_type *localTraceInfo)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(localTraceInfo);

    int16_t status = GOOD;
    enumTrace_type restoreType = ptCi->traceType;
    ptCi->traceType = Trace_Management;

    if (E_CALLTYPE_NSA == ptCi->callType)
    {
        if (ERROR == VXIL_sendX2AP_CellTrafficTrace(ptCi, localTraceInfo))
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "VXIL_sendX2AP_CellTrafficTrace ERROR!\n");
            status = ERROR;
        }
    }
    else if (!IS_NRDC_SN(ptCi) &&
             GET_NGC_CONNECTION_FLAG(ptCi->flag.setupFlag))  // NR-DC SN cannot send this message over NG
    {
        if (ERROR == VNIL_SendNGAP_CellTrafficTrace(ptCi, localTraceInfo))
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "VNIL_SendNGAP_CellTrafficTrace ERROR!\n");
            status = ERROR;
        }
    }
    else if (IS_NRDC_SN(ptCi)) // NR-DC SN can only send this message over XN
    {
        if (ERROR == FnVCCB_PrepareXNAP_CellTrafficTrace(ptCi, localTraceInfo))
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "FnVCCB_SendXNAP_CellTrafficTrace ERROR!\n");
            status = ERROR;
        }
    }
    else
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_immediate, "CellTrafficTrace not sent due to insufficient configuration\n");
    }

    ptCi->traceType = restoreType;
    return status;
}

static int VLIB_prepareIntraGnbHoTraceInfo(callInfo_type *ptCi, LocalTraceConfig_type *pLocalTraceInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pLocalTraceInfo);

    // During Intra-gNB HO some of messages correspond to Target Cell.
    const bool isIntraGnbHo{IntraRatHO_cmd == ptCi->stateCmd && HO_TYPE_INTRA_NB == ptCi->hoInfo.hoType.nb};
    bool isTgtCellMsg = false;
    int status = ERROR;

    switch (pLocalTraceInfo->msgId)
    {
        case NG_CellTrafficTraceAllAmf_id:
            if (VCCB_FLAG_OFF == GET_RRC_CONNECTION_FLAG(ptCi->flag.setupFlag))
            {
                // RRE to other cell during Intra-gNB HO
                // NG_CellTrafficTrace shall be collected from ptCi->servCellNum
                break;
            }
            isTgtCellMsg = true;
            break;
        case E1_TraceStart_id:
        case F1_UEContextSetupRequest_id:
        case F1_UEContextSetupResponse_id:
        case F1_UEContextSetupFailure_id:
        case F1_ULRRCMessageTransfer_id:
        case F1_TraceStart_id:
        case X2_SgNBModificationConfirm_id:
        case X2_CellTrafficTrace_id:
        case X2_SgNBReconfigurationComplete_id:
        case NRRRC_RrcReconfigurationComplete_id:
        case XN_SNodeModificationConfirm_id:
        case XN_SNodeReconfigurationComplete_id:
        case F1_AccessSuccess_id:
        case F1_CUDUCellSwitchNotification_id:
            isTgtCellMsg = true;
            break;
        case E1_BearerContextModificationRequest_id:
        case E1_BearerContextModificationResponse_id:
        case E1_BearerContextModificationFailure_id:
        case F1_UEContextModificationRequest_id:
        case F1_UEContextModificationResponse_id:
        case F1_UEContextModificationFailure_id:
        case X2_SNStatusTransfer_id:
            // For Inter-DU case. Check F1 by endPointId
            if (HO_TYPE_INTER_DU == ptCi->hoInfo.hoType.du && TRACE_BITMASK_F1C == pLocalTraceInfo->traceInterface)
            {
                isTgtCellMsg = pLocalTraceInfo->endPointIdx != ptCi->endPointInfo.f1Idx ? true : false;
                break;
            }

            // After HO execution phase (UE delivered RRC Reconf Complete on tgt cell)
            if ((VCCB_FLAG_ON == ptCi->managementTraceInfo.isHoRrcReconfCmpleFlag) ||
                (STATE_Ltm_Complete == ptCi->state && true == ptCi->ltmUeInfo.cellSwitchFlag.f1AccessSuccessReceived)
               )
            {
                isTgtCellMsg = true;
            }
            break;

        default:
            break;
    }

    const bool isLtmCandidatePrepState = {STATE_Ltm_Prep_Cand == ptCi->state ||
                                          STATE_Ltm_Prep_Propagation == ptCi->state};
    const bool isLtmCompleteState = {STATE_Ltm_Complete_F1Mod == ptCi->state &&
                                    (F1_UEContextModificationRequest_id == pLocalTraceInfo->msgId ||
                                     F1_UEContextModificationResponse_id== pLocalTraceInfo->msgId)};
    const bool isLtmCandidateRel = { 
        // Relese Request from DU arrives in any state
        (F1_UEContextReleaseRequest_id == pLocalTraceInfo->msgId ||
         F1_UEContextReleaseCommand_id == pLocalTraceInfo->msgId ||
         F1_UEContextReleaseComplete_id == pLocalTraceInfo->msgId) 
        };

    // source cell
    if ((false == isLtmCandidateRel) &&
        (false == isIntraGnbHo || false == isTgtCellMsg || STATE_Ltm_Prep_RRC == ptCi->state))
    {
        pLocalTraceInfo->cellId = CELLINFO[ptCi->servCellNum].cellIdentity;
        pLocalTraceInfo->cellNum = ptCi->servCellNum;
        status = GOOD;
    }
    // LTM candidate cell add/rell
    else if ( (isLtmCandidatePrepState || isLtmCompleteState || isLtmCandidateRel) &&
              TRACE_BITMASK_F1C == pLocalTraceInfo->traceInterface)
    {
        const ltmCellInfo_type *pLtmCell = FnVCCB_GetLtmCellInfoForIndex(const_cast<callInfo_type*>(ptCi), ptCi->ltmUeInfo.currCandidateCellIdx);
        if (nullptr != pLtmCell)
        {
            pLocalTraceInfo->cellNum = pLtmCell->data.cellSelection.cellNum;
            pLocalTraceInfo->cellId = pLtmCell->data.cellIdentity;
        }
        // When LTM cell does not exist, use src cell as default

        status = GOOD;
    }
    // handover target cell
    else if (true == isIntraGnbHo && true == isTgtCellMsg)
    {
        pLocalTraceInfo->cellNum = ptCi->hoInfo.targetCellNum;
        pLocalTraceInfo->cellId = ptCi->hoInfo.cellIdentity;

        if (HO_TYPE_INTER_DU == ptCi->hoInfo.hoType.du &&
            CI_use == ptCi->hoInfo.targetcRNTIUsage)
        {
            pLocalTraceInfo->crnti = ptCi->hoInfo.targetcRNTI;
        }
        status = GOOD;
    }
    return status;
}


/**
 * @brief   [FGR-TA0103] Cell traffic trace. Check if message can be forwarded to VTMB for Cell Trace purpose.
 * @details Collect Cell Trace message
 * @param   [in] ptCi : pointer to Call Context
 * @param   [in] pLocalTraceInfo : temporary trace related information
 */
static void VLIB_collectManagementTraceMessage(callInfo_type *ptCi, LocalTraceConfig_type *pLocalTraceInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pLocalTraceInfo);
    VALID_E_POINT_CHECK_VOID(pLocalTraceInfo->ptSourceMsg);

    pLocalTraceInfo->traceType = Trace_Management;

    uint8_t needSendCellTrafficTrace = VCCB_FLAG_OFF;

    // start or check if already started
    int16_t status = VLIB_startManagementTraceRecordingSession(ptCi, pLocalTraceInfo, &needSendCellTrafficTrace);
    if (ERROR != status)
    {
        VCCB_CHECK_E_RANGE_AND_VOID(pLocalTraceInfo->cellNum, MAX_CELL_NUM_VCCB);
        VccbCellInfo_type *pCell = &CELLINFO[pLocalTraceInfo->cellNum];
        ManagementTraceSessionPerCell_type *traceSession = &pCell->traceSession;
        TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, pLocalTraceInfo->cellNum, false);

        if (nullptr == pRecordingSession)
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, trace_ctt, "Cannot get session for cellNum(%u)\n", pLocalTraceInfo->cellNum);
            return;
        }

        const plmnId_type plmn = traceSession->cellTraceReference.plmn;
        pLocalTraceInfo->traceRSR = pRecordingSession->traceRecordingSessionReference;
        pLocalTraceInfo->msgSeqNum = pRecordingSession->msgSeqNum;
        // Set Cell Trace parameters
        pLocalTraceInfo->pldCellIndex = traceSession->pldCellIndex;
        pLocalTraceInfo->traceDepth = traceSession->trace.traceDepth;
        pLocalTraceInfo->traceReference = traceSession->cellTraceReference;
        pLocalTraceInfo->tce1Id = traceSession->trace.tce1Id;
        pLocalTraceInfo->tce2Id = traceSession->trace.tce2Id;
        pLocalTraceInfo->traceRSNumCPC = traceSession->allocatedTRSRCount;
        pLocalTraceInfo->traceUeNumCPC = traceSession->trace.cellTraceUeCountCpc;
    
        VCCB_PRINT_TRACE_DATA(ptCi, trace_ctt,
                "gId:%u cId:%u mcc:%x mnc:%x "
                "trId:%u trsr:%hu msgId:%x IF:%s Dir:%u msgSize:%u "
                "TrsrCnt:%hu(tr:%d, imm:%d, logg:%d\n)",
                pLocalTraceInfo->gnbId, pLocalTraceInfo->cellId, plmn.s2.mcc, plmn.s2.mnc,
                pLocalTraceInfo->traceReference.traceId, pLocalTraceInfo->traceRSR, pLocalTraceInfo->msgId,
                READABLE_TRACE_IF(pLocalTraceInfo->traceInterface), pLocalTraceInfo->direction,
                pLocalTraceInfo->sourceLength, pLocalTraceInfo->traceRSNumCPC, traceSession->trace.cellTraceUeCountCpc,
                traceSession->mdt.immediateMdtUeCountCpc, traceSession->mdt.loggedMdtUeCountCpc);

        VCCB_PRINT_TRACE_DATA(ptCi, trace_ctt,
                "tce1Id:%u, tce2Id:%u crnti:%u\n",
                static_cast<uint32_t>(pLocalTraceInfo->tce1Id), static_cast<uint32_t>(pLocalTraceInfo->tce2Id), pLocalTraceInfo->crnti);


        status = VIIL_sendTraceDataNotiVccbVtmb(ptCi, pLocalTraceInfo);
        VCCB_PRINT_WITHOUT_RETURN_ON_CALL_ERROR(ptCi, status, "VIIL_sendTraceDataNotiVccbVtmb ERROR!\n");

        if (GOOD == status)
        {
            ++(pRecordingSession->msgSeqNum);
        }

        if (VCCB_FLAG_ON == needSendCellTrafficTrace)
        {
            if (GET_MENB_CONNECTION_FLAG(ptCi->flag.setupFlag) ||
                GET_NGC_CONNECTION_FLAG(ptCi->flag.setupFlag)  ||
                GET_MGNB_CONNECTION_FLAG(ptCi->flag.setupFlag))
            {
                // sending CellTrafficTrace base on servCellNum - in REE/Inactive temporary overwrite it to requested one
                uint16_t restoreCell = ptCi->servCellNum;
                ptCi->servCellNum = pLocalTraceInfo->cellNum;
                status = VLIB_handleSendMgtCellTrafficTrace(ptCi, ENQUEUE_NO_ACTION);
                ptCi->servCellNum = restoreCell;
                if (ERROR == status)
                {
                    VCCB_PRINT_TRACE_ERROR(ptCi, trace_ctt, "VLIB_handleSendMgtCellTrafficTrace ERROR!\n");
                }
            }
            else // Enqueue and send notification later for callSetup scenario
            {
                status = VCCM_enqueueActionWithForce(ptCi, ENQUEUE_ACTION_SEND_MGT_CELL_TRAFFIC_TRACE, true);
                if (ERROR == status)
                {
                    VCCB_PRINT_TRACE_ERROR(ptCi, trace_ctt, "VCCM_enqueueActionWithForce(ENQUEUE_ACTION_SEND_MGT_CELL_TRAFFIC_TRACE) ERROR\n");
                }
            }
        }
    }
}

enumTraceMdtReportingStatusType VLIB_checkConfiguredReportingType(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_COMMON_RET(ptCi, return reporting_disabled);
    const VccbCfgInfo_type *const pCfg = CFG;

    if (reporting_unknown != ptCi->traceReportingState)
    {
        return ptCi->traceReportingState;
    }

    ptCi->traceReportingState = reporting_enable;

    switch (pCfg->globalTraceInfo.reportingType)
    {
        case sa_only:
        {
            if(E_CALLTYPE_SA != ptCi->callType)
            {
                ptCi->traceReportingState = reporting_disabled;
            }
            break;
        }
        case nsa_only:
        {
            if(E_CALLTYPE_NSA != ptCi->callType)
            {
                ptCi->traceReportingState = reporting_disabled;
            }
            break; 
        }
        case sa_and_nsa:
        {
            break;
        }
        default:
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "Unknown reporting type %u. Allow tracing.\n", pCfg->globalTraceInfo.reportingType);
        }
    }

    return ptCi->traceReportingState;
}

/**
 * @brief   [FGR-TA0103] Cell traffic trace.
 *          [FGR-TA0104] UE Throughput And RF Trace
 *          [FGR-TA0101] Subscriber And Equipment Trace
 * @details Check the message and forward to VTMB for Trace purpose
 * @param   [in] ptCi : pointer to Call Context
 * @param   [in] data : contains direction, msgId, pointer to encoded message and other required information
 */
void VLIB_collectTraceMessage(callInfo_type *ptCi, TraceParam data)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(data.ptSourceMsg);
    const VccbCfgInfo_type *const pCfg = CFG;
    if (ptCi->servCellNum >= MAX_CELL_NUM_VCCB)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt,
            "ptCi->servCellNum is out of range (%u:%u)\n", ptCi->servCellNum, MAX_CELL_NUM_VCCB);
        return;
    }
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    // Quick Check for Cell Trace On/Off
    if (VCCB_FLAG_OFF == pCfg->globalTraceInfo.cellTraceOnOff &&
        ueTraceDisabled == ptCi->signalingTraceInfo.trace.traceStatus)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt, "Cell Trace is OFF and UE Trace NOT Requested\n");
        return;
    }

    // Cell Trace is on and UE Trace not requested so validate RFSP/SPID if configured
    if (VCCB_FLAG_ON == pCfg->globalTraceInfo.cellTraceOnOff &&
        ueTraceEnabledAndActive != ptCi->signalingTraceInfo.trace.traceStatus &&
        false == VLIB_checkTraceRfspSpidAllowed(ptCi, data.msgId))
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt, "RFSP/SPID condition not met - no tracing\n");
        return;
    }

    LocalTraceConfig_type localTraceInfo;
    localTraceInfo.cellNum = ptCi->servCellNum;
    localTraceInfo.cellId = pCell->cellIdentity;
    localTraceInfo.crnti = ptCi->ueInfo.ueId.cRNTI;
    localTraceInfo.gnbId = pGnb->globalGnbId.gnbId.id;
    localTraceInfo.msgId = data.msgId;
    localTraceInfo.traceInterface = 0;

    bool needCollection = true;
    // Check if Traceable Interface
    switch (localTraceInfo.msgId)
    {
        case MSGBASE_NRRRC ... NRRRC_MAX_id:
            localTraceInfo.traceInterface = TRACE_BITMASK_Uu;
            break;
#ifndef __NVGNB__
        case MSGBASE_F1AP ... F1_MAX_id:
            localTraceInfo.traceInterface = TRACE_BITMASK_F1C;
            break;
        case MSGBASE_E1AP_new ... E1_MAX_id_new:
            localTraceInfo.traceInterface = TRACE_BITMASK_E1C;
            break;
#endif
        case MSGBASE_NGAP ... NG_MAX_id:
            localTraceInfo.traceInterface = TRACE_BITMASK_NGC;
            break;
        case MSGBASE_XNAP ... XN_MAX_id:
            localTraceInfo.traceInterface = TRACE_BITMASK_XNC;
            break;
        case MSGBASE_X2AP ... X2_MAX_id:
            localTraceInfo.traceInterface = TRACE_BITMASK_X2C;
            break;
        default:
        {
            VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt,
                "gNBId:cellId(%u:%u): msg(id: %d) is not trace interface related message\n",
                localTraceInfo.gnbId, localTraceInfo.cellId, localTraceInfo.msgId);
            needCollection = false;
        }
    }

    //
    // Set Common parametrs
    //
    localTraceInfo.direction = data.direction;
    localTraceInfo.sourceLength = data.sourceLength;
    localTraceInfo.ptSourceMsg = data.ptSourceMsg;
    localTraceInfo.endPointIdx = data.endPointIdx;

    // Set Intra-gNB HO Trace parameters
    if (GOOD != VLIB_prepareIntraGnbHoTraceInfo(ptCi, &localTraceInfo))
    {
        return;
    }

    if (needCollection)
    {
        // Check Overload state
        if (true == VLIB_traceDisabledDueToOverload())
        {
            VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt, "Not sent due to overload\n");
            return;
        }

        // Set Signaling Trace parameters
        // [FGR-TA0101] Subscriber And Equipment Trace
        if (ptCi->signalingTraceInfo.trace.traceStatus != ueTraceDisabled &&
                GOOD == VLIB_checkIfSendSignalingTrace(ptCi, &localTraceInfo))  // Trace Requested for UE
        {
            localTraceInfo.traceType = Trace_Signaling;
            localTraceInfo.traceDepth = ptCi->signalingTraceInfo.trace.traceDepth;
            localTraceInfo.traceReference.plmn = ptCi->signalingTraceInfo.traceReference.plmn;
            localTraceInfo.traceRSR = static_cast<uint16_t>(ptCi->signalingTraceInfo.traceRSR.data[0] << 8);
            localTraceInfo.traceRSR = static_cast<uint16_t>(localTraceInfo.traceRSR | ptCi->signalingTraceInfo.traceRSR.data[1]);
            localTraceInfo.traceReference.traceId = static_cast<uint32_t>(ptCi->signalingTraceInfo.traceReference.traceId.data[0] << 16);
            localTraceInfo.traceReference.traceId |= static_cast<uint32_t>(ptCi->signalingTraceInfo.traceReference.traceId.data[1] << 8);
            localTraceInfo.traceReference.traceId |= ptCi->signalingTraceInfo.traceReference.traceId.data[2];
            localTraceInfo.tce1Id = ptCi->signalingTraceInfo.tceId;
            localTraceInfo.tce2Id = std::numeric_limits<uint8_t>::max();
            localTraceInfo.traceRSNumCPC = pCfg->globalTraceInfo.signaling.totalSigUeCountCpc;
            localTraceInfo.traceUeNumCPC = pCfg->globalTraceInfo.signaling.totalSigUeCountCpc;
            localTraceInfo.msgSeqNum = ptCi->signalingTraceInfo.trace.msgSeqNum;
            const uint32_t mcc = ptCi->signalingTraceInfo.traceReference.plmn.s2.mcc;
            const uint32_t mnc = ptCi->signalingTraceInfo.traceReference.plmn.s2.mnc;

            VCCB_PRINT_TRACE_DATA(ptCi, trace_ctt,
                    "[SIG][->VTMB] mcc:%x mnc:%x trId:%u trsr:%hu - "
                    "msgId:%x IF:%s Direction:%u "
                    "msgSize:%u TRSnum:%hu\n",
                    mcc, mnc, localTraceInfo.traceReference.traceId, localTraceInfo.traceRSR, localTraceInfo.msgId,
                    READABLE_TRACE_IF(localTraceInfo.traceInterface), localTraceInfo.direction, localTraceInfo.sourceLength,
                    localTraceInfo.traceRSNumCPC);

            if (ERROR == VIIL_sendTraceDataNotiVccbVtmb(ptCi, &localTraceInfo))
            {
                VCCB_PRINT_ERROR("VIIL_sendTraceDataNotiVccbVtmb ERROR!\n");
            }
            else
            {
                ++(ptCi->signalingTraceInfo.trace.msgSeqNum);
            }
        }

        // [FGR-TA0103] Cell traffic trace.
        VLIB_collectManagementTraceMessage(ptCi, &localTraceInfo);

    }
}

/**
 * @brief   [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Check and send X2/NG CellTrafficTrace msg
 * @param   [in] ptCi               : pointer to Call Context
 * @param   [in] pMdtLogMeasReport  : pointer to logged mdt measurement
 */
int16_t VLIB_sendLoggedMdtCellTrafficTrace(callInfo_type *ptCi, NRRRC_LogMeasReport_r16 *pMdtLogMeasReport)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMdtLogMeasReport);
    uint16_t cellNum = ptCi->servCellNum;
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    ManagementTraceSessionPerCell_type *pSession = &pCell->traceSession;

    // Check if UE data will be anonymized and if no send Cell traffic trace to eNB/AMF
    if (mdt_imei_tac != pSession->mdt.mdtSessionConfiguration.anonymizationLevel)
    {
        return BREAK;
    }

    LocalTraceConfig_type localTraceInfo;
    localTraceInfo.configTraceType = mdt_only;
    localTraceInfo.cellNum = cellNum;

    int16_t status = VRIL_StoreNRRRC_plmn_Identity(
            &localTraceInfo.traceReference.plmn, &pMdtLogMeasReport->traceReference_r16.plmn_Identity_r16);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VRIL_StoreNRRRC_plmn_Identity ERROR!\n");

    localTraceInfo.traceReference.traceId = static_cast<uint32_t>(pMdtLogMeasReport->traceReference_r16.traceId_r16.value[0] << 16);
    localTraceInfo.traceReference.traceId |= static_cast<uint32_t>(pMdtLogMeasReport->traceReference_r16.traceId_r16.value[1] << 8);
    localTraceInfo.traceReference.traceId |= pMdtLogMeasReport->traceReference_r16.traceId_r16.value[2];

    localTraceInfo.mdtType = mdt_logged;

    localTraceInfo.traceRSR = static_cast<uint16_t>(pMdtLogMeasReport->traceRecordingSessionRef_r16.value[0] << 8);
    localTraceInfo.traceRSR = static_cast<uint16_t>(localTraceInfo.traceRSR | pMdtLogMeasReport->traceRecordingSessionRef_r16.value[1]);

    localTraceInfo.mdtTceId = pMdtLogMeasReport->tce_Id_r16.value[0];

    if (ERROR == status)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_logged, "TCE Id not included in predefined TCE list\n");
        return BREAK;
    }

    enumTrace_type restoreType = ptCi->traceType;
    ptCi->traceType = Trace_Management;
    status = VLIB_sendCellTrafficTrace(ptCi, &localTraceInfo);
    ptCi->traceType = restoreType;
    if (GOOD != status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_sendCellTrafficTrace ERROR!\n");
        return ERROR;
    }

    return GOOD;
}

static bool checkMgtMdtUeConsent(callInfo_type& rCi, ManagementTraceSessionPerCell_type& rSession)
{
    bool mdtPlmnPresent = false;
    if (FALSE == rSession.mdt.mdtSessionConfiguration.ignoreUeConsent)
    {
        if (0 == rCi.managementTraceInfo.mdtInfo.mdtPlmnCount)
        {
            VCCB_PRINT_TRACE_ERROR(&rCi, mdt_immediate, "Mdt UE Consent required but not available!\n");
            return false;
        }

        // if NSA check managementMdtAllowed
        if (E_CALLTYPE_NSA == rCi.callType && FALSE == rCi.managementTraceInfo.mdtInfo.managementMdtAllowed)
        {
            VCCB_PRINT_TRACE_ERROR(&rCi, mdt_immediate, "NSA management MDT not allowed!\n");
            return false;
        }

        // check if serving PLMN appear on Management MDT PLMN list
        for (auto plmnIdx = 0; plmnIdx < MAX_NUM_MDT_PLMNS; ++plmnIdx)
        {
            if (rCi.managementTraceInfo.mdtInfo.managementMdtPlmnList[plmnIdx].longId ==
                rCi.ueInfo.servedPlmn.longId)
            {
                mdtPlmnPresent = true;
                break;
            }
        }

        if (false == mdtPlmnPresent)
        {
            VCCB_PRINT_TRACE_ERROR(&rCi, mdt_immediate, "Serving PLMN not available on MDT Management PLMN list!\n");
            return false;
        }
    }
    return true;
}

static void setMgtMdtMeasConfig(callInfo_type& rCi, const ManagementTraceSessionPerCell_type& rSession)
{
    // Check if measurements activation (M2/5/6/7DL) via F1UeContextSetupRequest to gNB-DU is needed
    if (TRUE == rSession.mdt.mdtSessionConfiguration.immediate.measurements.m2.activation ||
        TRUE == rSession.mdt.mdtSessionConfiguration.immediate.measurements.m5.activation ||
        TRUE == rSession.mdt.mdtSessionConfiguration.immediate.measurements.m6.activation ||
        (TRUE == rSession.mdt.mdtSessionConfiguration.immediate.measurements.m7.activation &&
            mdt_trace_uplink != rSession.mdt.mdtSessionConfiguration.immediate.measurements.m7.linksToLog))
    {
        rCi.managementTraceInfo.mdtInfo.mdtStatus.duActFlag = VCCB_FLAG_ON;
    }

    // Check if measurements activation (M4/6/7UL) via E1BearerContextSetupRequest to gNB-CU-UP is needed
    if (TRUE == rSession.mdt.mdtSessionConfiguration.immediate.measurements.m4.activation ||
        TRUE == rSession.mdt.mdtSessionConfiguration.immediate.measurements.m6.activation ||
        TRUE == rSession.mdt.mdtSessionConfiguration.immediate.measurements.m7.activation)
    {
        rCi.managementTraceInfo.mdtInfo.mdtStatus.upActFlag = VCCB_FLAG_ON;
    }

    if (TRUE == rSession.mdt.mdtSessionConfiguration.immediate.measurements.m1.specific.activation ||
        TRUE == rSession.mdt.mdtSessionConfiguration.immediate.measurements.m1.activationExistingRrm)
    {
        rCi.managementTraceInfo.mdtInfo.m1ReportingTrigger = static_cast<enumMdtReportingTrigger_type>(
            rSession.mdt.mdtSessionConfiguration.immediate.measurements.m1.specific.reportingTrigger);
        rCi.managementTraceInfo.mdtInfo.mdtStatus.ueActFlag = VCCB_FLAG_ON;
        rCi.specificM1InstallOngoing = VCCB_FLAG_OFF;
        rCi.mdtIsPeriodicByA2Active = FALSE;
    }
}

/**
 * @brief   [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Performs UE selection check and Management based MDT activation
 * serving
 * @param   [in] ptCi    : pointer to Call Context
 * @param   [in] cellNum : cellNum to activate feature
 */
void VLIB_startManagementMdtTrace(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    const VccbCfgInfo_type *pCfg = CFG;
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    VCCB_CHECK_E_RANGE_AND_VOID(pCell->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[pCell->gnbNum];
    uint32_t gnbId = pGnb->globalGnbId.gnbId.id;

    ManagementTraceSessionPerCell_type *pSession = &pCell->traceSession;
    int16_t status = GOOD;

    if (FALSE == pSession->traceSessJobOnOff || FALSE == pCfg->globalTraceInfo.cellTraceOnOff)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_immediate, "Immediate MDT Tracing disabled for selected cellNum(%u)\n", cellNum);
        return;
    }

    if (reporting_disabled == VLIB_checkConfiguredReportingType(ptCi))
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_immediate, "Tracing for call type currently disabled\n"); 
        return;
    }

    if (mdtDisabled != ptCi->signalingTraceInfo.mdt.mdtStatus)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_immediate, "Cannot activate session - signaling mdt already running!\n"); 
        return;
    }

    if (FALSE == pSession->mdt.mdtSessionConfiguration.immediate.functionOnOff ||
        FALSE == pSession->managementJobType.immediate)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_immediate, "Disabled for selected cellNum(%u)\n", cellNum);
        return;
    }

    TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, cellNum, false);

    if (nullptr != pRecordingSession && VCCB_FLAG_ON == pRecordingSession->jobStatus.immediateMdtFlag)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_immediate, "Already started for selected cellNum(%u)\n", cellNum);
        return;
    }

    // Condition 1) System overload check
    if (true == VLIB_traceDisabledDueToOverload())
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "Not started due to overload\n");
        return;
    }

    // Condition 2) Max number of MDT UEs check
    if (VCCB_FLAG_OFF == pSession->mdt.immediateMdtAllowedFlag)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "Not started due max number of MDT UEs exceeded\n");
        return;
    }

    // Condition 3) UE Consent check
    if (false == checkMgtMdtUeConsent(*ptCi, *pSession))
    {
        return;
    }

    // Condition 4) Target plmns check
    if (false == VLIB_checkPlmnOnTraceList(ptCi, pSession))
    {
        return;
    }

    // Condition 5) GNSS request and support check
    if (TRUE == pSession->mdt.mdtSessionConfiguration.immediate.measurements.m1.specific.activation ||
        TRUE == pSession->mdt.mdtSessionConfiguration.immediate.measurements.m1.activationExistingRrm)
    {
        if (TRUE == pSession->mdt.mdtSessionConfiguration.immediate.measurements.m1.gnssPositioning &&
            mdt_m1_gnss_capable ==
                pSession->mdt.mdtSessionConfiguration.immediate.measurements.m1.gnssTargetUeSelectionMethod)
        {
            if (FALSE == ptCi->ueInfo.ueCapa.nr.ueBasedPerfMeasParam.gnssLocation)
            {
                VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "UE Capa gnssLocation required but not supported!\n");
                return;
            }
        }
    }

    // Condition 6) Allowed IMEI-TAC list check
    const AllowedImeiTacList_type *allowedImeiTacList = &pCfg->globalTraceInfo.management.mdt.allowedImeiTacList;
    uint8_t imeiTacFilterOnOff = pCfg->globalTraceInfo.management.mdt.imeiTacFilterOnOff;

    if (false == VLIB_checkAllowedImsiTacList(ptCi, allowedImeiTacList, imeiTacFilterOnOff))
    {
        return;
    }

    // Condition 7) Random selection pass
    if (false == VLIB_mdtRandomSelection(ptCi->gnbNum, pCfg->globalTraceInfo.management.mdt.selectionRate))
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "Random selection algorithm does not select UE for mdt trace!\n");
        return;
    }

    // TRSR allocation (common with Cell Trace and UE Throughput)
    status = VLIB_allocateTrsr(ptCi, cellNum, mdt_immediate);
    VCCB_RETURN_ON_CALL_VOID(ptCi, status, "[MDT][MGT] TRSR allocation ERROR\n");

    // TRSR allocation can create new traceSession so update pointer
    pRecordingSession = getTraceSession(ptCi, cellNum, false);
    if (nullptr == pRecordingSession)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "Cannot get session for cellNum(%u)\n", cellNum);
        return;
    }

    if (GOOD == status)
    {
        // new TRSR allocated - allow to redistribute E1/F1 TraceStart messages
        pRecordingSession->traceStartE1DeliveryStatus = FALSE;
        pRecordingSession->traceStartF1DeliveryStatus = FALSE;
    }

    pRecordingSession->jobStatus.immediateMdtFlag = VCCB_FLAG_ON;
    // Check if and send Trace Status to VTMB
    if (ERROR == VIIL_sendTraceStatusVccbVtmb(ptCi, Trace_Management, cellNum))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_sendTraceStatusVccbVtmb (cellNum: %d) ERROR!\n", cellNum);
    }

    // Check if and send Cell traffic trace to eNB/AMF
    if (ERROR == VCCM_enqueueActionWithForce(ptCi, ENQUEUE_ACTION_SEND_MGT_CELL_TRAFFIC_TRACE, true))
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "VCCM_enqueueActionWithForce(ENQUEUE_ACTION_SEND_MGT_CELL_TRAFFIC_TRACE) ERROR!\n");
    }

    setMgtMdtMeasConfig(*ptCi, *pSession);

    bool isTargetCell {ptCi->servCellNum != cellNum};

    if (GOOD != VCCM_enqueueActionWithForce(ptCi, ENQUEUE_ACTION_SEND_MGT_TRACE_START, isTargetCell))
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "VCCM_enqueueAction(ENQUEUE_ACTION_SEND_MGT_TRACE_START) ERROR\n");
    }

    VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_immediate,
        "Started cellNum(%u) gId:cId:trId:trsr(%u:%u:%u:%u) TrsrCnt:%u(trace:%u immediate:%u logged:%u), "
        "allocIdx:%u\n",
        cellNum, gnbId, pCell->cellIdentity, pSession->cellTraceReference.traceId,
        pRecordingSession->traceRecordingSessionReference, pSession->allocatedTRSRCount,
        pSession->trace.cellTraceUeCountCpc, pSession->mdt.immediateMdtUeCountCpc, pSession->mdt.loggedMdtUeCountCpc,
        pSession->cellTrsrAllocIdx);
}

/**
 * @brief   [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Performs Management based MDT deactivation on given cell
 * @param   [in] ptCi : pointer to Call Context
 * @param   [in] cellNum : cellNum to activate feature
 * @param   [in] isHoCancel : true if called in HO cancel procedure 
 * @return  int16_t GOOD/ERROR
 */
int16_t VLIB_stopManagementMdtTrace(callInfo_type *ptCi, uint16_t cellNum, bool isHoCancel)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, cellNum, false);

    if (nullptr == pRecordingSession)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_immediate, "Cannot get session for cellNum(%u)\n", cellNum);
        return BREAK;
    }

    if (VCCB_FLAG_OFF == pRecordingSession->jobStatus.immediateMdtFlag)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_immediate, "Already released\n");
        return GOOD;
    }

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    VCCB_CHECK_E_RANGE_AND_RETURN(pCell->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[pCell->gnbNum];

    uint32_t gnbId = pGnb->globalGnbId.gnbId.id;

    ManagementTraceSessionPerCell_type *pSession = &pCell->traceSession;

    // skip in case of HO cancel
    if (false == isHoCancel)
    {
        VLIB_sendDeactivateTrace(ptCi, Trace_Management, cellNum);
    }

    pRecordingSession->jobStatus.immediateMdtFlag = VCCB_FLAG_OFF;

    // TRSR dallocation (common with cellTrace and ueThr) and decrement immediateMdtUeCountCpc counter
    int16_t status = VLIB_deallocateTrsr(ptCi, cellNum, mdt_immediate);

    if (GOOD == status)
    {
        clearTraceSession(ptCi, pRecordingSession);
    }

    VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_immediate,
        "Stopped cellNum(%u) gId:cId:trId:trsr(%u:%u:%u:%u) TrsrCnt:%u(trace:%u immediate:%u logged:%u), "
        "allocIdx:%u\n",
        cellNum, gnbId, pCell->cellIdentity, pSession->cellTraceReference.traceId,
        pRecordingSession->traceRecordingSessionReference, pSession->allocatedTRSRCount,
        pSession->trace.cellTraceUeCountCpc, pSession->mdt.immediateMdtUeCountCpc, pSession->mdt.loggedMdtUeCountCpc,
        pSession->cellTrsrAllocIdx);

    if (ERROR == VIIL_sendTraceStatusVccbVtmb(ptCi, Trace_Management, cellNum))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_sendTraceStatusVccbVtmb (cellNum: %d) ERROR!\n", cellNum);
    }

    ptCi->managementTraceInfo.mdtInfo.mdtStatus.ueActFlag = VCCB_FLAG_OFF;
    ptCi->managementTraceInfo.mdtInfo.mdtStatus.duActFlag = VCCB_FLAG_OFF;
    ptCi->managementTraceInfo.mdtInfo.mdtStatus.upActFlag = VCCB_FLAG_OFF;

    // Deinstall measurements by RrcReconfiguration on UE due MDT feature switch off
    if (FALSE == pSession->mdt.mdtSessionConfiguration.immediate.functionOnOff ||
            FALSE == pSession->managementJobType.immediate)
    {
        if (ERROR == VCCM_EnqueueActionMeasReconfig(ptCi, MeasReconfigPriorAction_Full))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_EnqueueActionMeasReconfig ERROR!\n");
        }
    }

    return GOOD;
}

int16_t VLIB_stopManagementUeThrRfTrace(callInfo_type *ptCi, uint16_t cellNum, bool isHoCancel)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, cellNum, false);

    if (nullptr == pRecordingSession)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_uethr, "Cannot get session for cellNum(%u)\n", cellNum);
        return BREAK;
    }

    if (VCCB_FLAG_OFF == pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_uethr, "Already released\n");
        return GOOD;
    }

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    VCCB_CHECK_E_RANGE_AND_RETURN(pCell->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[pCell->gnbNum];

    uint32_t gnbId = pGnb->globalGnbId.gnbId.id;

    ManagementTraceSessionPerCell_type *pSession = &pCell->traceSession;

    // skip in case of HO cancel
    if (false == isHoCancel)
    {
        VLIB_sendDeactivateTrace(ptCi, Trace_Management, cellNum);
    }

    pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag = VCCB_FLAG_OFF;
    // TRSR dallocation (common with cellTrace and mdt) and decrement trace counter
    int16_t status = VLIB_deallocateTrsr(ptCi, cellNum, trace_uethr);

    if (GOOD == status)
    {
        clearTraceSession(ptCi, pRecordingSession);
    }

    VCCB_PRINT_TRACE_COMMENT(ptCi, trace_uethr,
            "Stopped cellNum(%u) gId:cId:trId:trsr(%u:%u:%u:%u) TrsrCnt:%u(trace:%u immediate:%u logged:%u) "
            "allocIdx:%u\n",
            cellNum, gnbId, pCell->cellIdentity, pSession->cellTraceReference.traceId,
            pRecordingSession->traceRecordingSessionReference, pSession->allocatedTRSRCount,
            pSession->trace.cellTraceUeCountCpc, pSession->mdt.immediateMdtUeCountCpc, pSession->mdt.loggedMdtUeCountCpc,
            pSession->cellTrsrAllocIdx);

    if (ERROR == VIIL_sendTraceStatusVccbVtmb(ptCi, Trace_Management, cellNum))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_sendTraceStatusVccbVtmb (cellNum: %d) ERROR!\n", cellNum);
    }

    return GOOD;
}

bool VLIB_isMrPurposeSupported(uint8_t reportType, uint8_t mrPurpose)
{
    switch (reportType)
    {
        case measReport_A2:
            if (a2Purpose_mdt == mrPurpose || a2Purpose_triggerPeriodicMdt == mrPurpose)
            {
                return true;
            }
            break;

        case measReport_periodical:
            if (measReport_periodical == reportType && periodicalPurpose_mdt == mrPurpose)
            {
                return true;
            }
            break;

        case measReport_periodicalInterRat:
            if (periodicalInterRATPurpose_mdt == mrPurpose)
            {
                return true;
            }
            break;

        default:
            return false;
            break;
    }

    return false;
}
/**
 * @brief   [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Collects M1 MDT Measurement and forwards it to VTMB
 * @param   [in] ptCi : pointer to Call Context
 * @param   [in] pMeasResult : pointer of MeasResultListNR in MR
 * @param   [in] pSelectRptCfg : pointer of reportConfigurationInstalledUe_type
 */
void VLIB_collectMdtM1Measurement(
    callInfo_type *ptCi, void *pMeasResult_void, reportConfigurationInstalledUe_type *pSelectRptCfg, uint8_t measObjIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pMeasResult_void);
    VALID_E_POINT_CHECK_VOID(pSelectRptCfg);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    NRRRC_MeasResults *pMeasResult = reinterpret_cast<NRRRC_MeasResults*>(pMeasResult_void);

    uint8_t activationExistingRrm = FALSE;
    enumTrace_type traceType = Trace_Management;

    // Signaling MDT
    if (mdtImmediate == ptCi->signalingTraceInfo.mdt.mdtStatus &&
        VCCB_FLAG_ON == ptCi->signalingTraceInfo.mdt.config.immediate.measConfigFlags.m1Flag)
    {
        activationExistingRrm = ptCi->signalingTraceInfo.mdt.config.immediate.measConfigFlags.m1RrmFlag;
        traceType = Trace_Signaling;
    }
    else
    {
        // Management MDT
        TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, ptCi->servCellNum, false);
        if (nullptr == pRecordingSession)
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "Cannot get session for cellNum(%u)\n", ptCi->servCellNum);
            return;
        }

        if (VCCB_FLAG_OFF == pRecordingSession->jobStatus.immediateMdtFlag)
        {
            VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_immediate, "Not started - measurements will not be collected\n");
            return;
        }

        MdtSessionConfiguration_type *mdtConfig = &pCell->traceSession.mdt.mdtSessionConfiguration;
        activationExistingRrm = mdtConfig->immediate.measurements.m1.activationExistingRrm;
    }

    // Check overload and threshold
    if (true == VLIB_traceDisabledDueToOverload())
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_immediate, "M1 Measurement not sent to VTMB due to overload\n");
        return;
    }

    if (!(pMeasResult->bit_mask & NRRRC_MeasResults_locationInfo_r16_present &&
          pMeasResult->locationInfo_r16.bit_mask & NRRRC_commonLocationInfo_r16_present &&
          pMeasResult->locationInfo_r16.commonLocationInfo_r16.bit_mask & NRRRC_locationCoordinate_r16_present) &&
        CFG->globalTraceInfo.management.gnssBasedM1TransmissionOnOff == FLAG_ON)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_immediate, "M1 Measurement not sent to VTMB due to location based sending set to ON\n");
        return;
    }

    uint8_t reportType = pSelectRptCfg->conf.reportType;
    uint8_t mrPurpose = pSelectRptCfg->conf.reportPurpose;
    bool mrSupported = VLIB_isMrPurposeSupported(reportType, mrPurpose);

    // check if received MR purpose was MDT related
    // AND activationExistingRrm is ON - then collect all A1-A6/B1-B2
    if ((false == mrSupported) && (FALSE == activationExistingRrm))
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_immediate,
            "Measurement not collected traceType(%u),mrType(%d),mrPurpose(%d),activationExistingRrm(%d)\n",
            traceType, reportType, mrPurpose, activationExistingRrm);
        return;
    }

    if (ERROR == VIIL_sendMdtDataNotiVccbVtmb(ptCi, traceType, pMeasResult, pSelectRptCfg, measObjIdx))
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "VIIL_sendMdtDataNotiVccbVtmb ERROR!\n");
        return;
    }

    if (mrSupported)
    {
        // collect ImmediateMDTM1Delivery counter
        MACRO_STAT_PMCC_FLOAT(STAT_MDT_CONFIGURATION_DELIVERY_DU_ID, ImmediateMDTM1Delivery, ptCi, (float)1.0, 0, 0, 0, 0);
    }

    VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_immediate, "Measurement collected traceType(%u) mrType(%d),mrPurpose(%d)\n", traceType, reportType, mrPurpose);
}

/**
 * @brief    [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 *           [FGR-TA0103] Cell traffic trace
 * @details  Mdt, Trace and TRSR counters reset after switchover.
 *           TRSR resources clear.
 * @param    [in] cellNum    : cellNum
 */
void VLIB_initTraceAndMdtInfo(uint16_t cellNum)
{
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    VccbCfgInfo_type *const pCfg = CFG;
    ManagementTraceSessionPerCell_type *pSession = &pCell->traceSession;
    VALID_E_POINT_CHECK_VOID(pSession);

    uint32_t *pAcpfTrsrCounter = &pCfg->globalTraceInfo.management.totalMgtUeCountCpc; // acpf level - total number of mgt TRSR session
    std::lock_guard<std::mutex> lock(gTrsrAllocMtx);

    pSession->trace.cellTraceUeCountCpc = 0;
    pSession->mdt.immediateMdtUeCountCpc = 0;
    pSession->mdt.loggedMdtUeCountCpc = 0;
    pSession->allocatedTRSRCount = 0;

    for (int i = 0; i < MAX_UE_PER_CELL_TRACE_SESSION; i++)
    {
        if ( (*pAcpfTrsrCounter > 0) && 
             (pSession->cellTRSR[i] < MAX_CALL_NUM_VCCB) )
        {
            --(*pAcpfTrsrCounter);
        }
        pSession->cellTRSR[i] = UNKNOWN_VCCB_CALLID;
    }

    if (IS_TRACE_LOG_ACTIVE)
    {
        VCCB_PRINT_COMMENT("[TRACE/MDT][ALL] Cleanup TRSR list and counters cellunm(%u)\n", cellNum);
    }
}

/**
 * @brief    [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 *           [FGR-TA0103] Cell traffic trace
 * @details  Switchover Recovery of actual Trace and Mdt count.
 *           Allocation of proper TRSR basing on context information.
 * @param    [in] ptCi    : pointer to Call Context
 */
void VLIB_recoverTraceAndMdtCount(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    ManagementTraceSessionPerCell_type *pSession = &pCell->traceSession;
    VALID_E_POINT_CHECK_VOID(pSession);

    TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, ptCi->servCellNum, false);

    if (nullptr == pRecordingSession)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_trace_all, "[RECOVERY] Cannot get session for cellNum(%u)\n", ptCi->servCellNum);
        return;
    }

    const bool isMdtActive{VCCB_FLAG_ON == pRecordingSession->jobStatus.immediateMdtFlag ||
                           VCCB_FLAG_ON == pRecordingSession->jobStatus.loggedMdtFlag ||
                           VCCB_FLAG_ON == pRecordingSession->jobStatus.rlfOrRcefFlag};
    const bool isCellTraceActive{VCCB_FLAG_ON == pRecordingSession->jobStatus.cellTraceFlag ||
                                 VCCB_FLAG_ON == pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag};

    // Recovery Logged MDT UE capable count
    VRRM_addLoggedMdtCapableUeCount(ptCi, ptCi->servCellNum);

    // MDT and Trace not active
    if (!isMdtActive && !isCellTraceActive)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[RECOVERY][MGT] MDT and Trace not active\n");
        return;
    }

    uint8_t job = 0;
    // 1 . Mdt and Trace count recovery
    if (VCCB_FLAG_ON == pRecordingSession->jobStatus.immediateMdtFlag)
    {
        pSession->mdt.immediateMdtUeCountCpc++;
        job |= mdt_immediate; 
    }

    if (VCCB_FLAG_ON == pRecordingSession->jobStatus.loggedMdtFlag)
    {
        pSession->mdt.loggedMdtUeCountCpc++;
        job |= mdt_logged; 
    }

    if (isCellTraceActive)
    {
        pSession->trace.cellTraceUeCountCpc++;
        job |= (trace_ctt | trace_uethr); 
    }

    // 2. Allocated TRSR count recovery and same TRSR allocation
    pSession->cellTrsrAllocIdx =
        static_cast<uint16_t>(pRecordingSession->traceRecordingSessionReference - (GET_REDUNDANT_CPC_ID * MAX_UE_PER_CELL_TRACE_SESSION));
    VCCB_CHECK_E_RANGE_AND_VOID(pSession->cellTrsrAllocIdx, MAX_UE_PER_CELL_TRACE_SESSION);
    pSession->allocatedTRSRCount++;
    pSession->cellTRSR[pSession->cellTrsrAllocIdx] = ptCi->callId;

    // 3. Skipping Trace Status to VTMB send. VTMB after SO will re-read config and start with counters set to 0.
    //    Vtmb count will fix itself with first Trace Status.
}

/**
 * @brief   [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Performs Management based Logged MDT UE selection
 * @param   [in] ptCi : pointer to Call Context
 * @return  int16_t GOOD/BREAK/ERROR
 */
int16_t VLIB_selectUeForLoggedMdt(callInfo_type *ptCi, uint16_t cellNum)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    const VccbCfgInfo_type *const pCfg = CFG;
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    ManagementTraceSessionPerCell_type *pSession = &pCell->traceSession;
    VALID_E_POINT_CHECK_ERROR(pSession);
    uint8_t mdtPlmnPresent = FALSE;

    // 1. Validate UE capabilities support for Logged MDT enabled
    if (TRUE != ptCi->ueInfo.ueCapa.nr.ueBasedPerfMeasParam.loggedMeasurements)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_logged, "UE Capa does not support logged MDT\n");
        return BREAK;
    }

    // 2. Check if max logged MDT UE number per cell not reached
    if (VCCB_FLAG_OFF == pSession->mdt.loggedMdtAllowedFlag)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_logged, "Not started due max number of MDT UEs exceeded\n");
        return ERROR;
    }

    // 3. UE consent check. If set to false validate UE's RPLMN on MDT list
    if (FALSE == pSession->mdt.mdtSessionConfiguration.ignoreUeConsent)
    {
        if (0 == ptCi->managementTraceInfo.mdtInfo.mdtPlmnCount)
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, mdt_logged, "UE Consent required but not available!\n");
            return ERROR;
        }

        // check if serving PLMN appear on Management MDT PLMN list
        for (auto plmnIdx = 0; plmnIdx < MAX_NUM_MDT_PLMNS; ++plmnIdx)
        {
            if (ptCi->managementTraceInfo.mdtInfo.managementMdtPlmnList[plmnIdx].longId ==
                ptCi->ueInfo.servedPlmn.longId)
            {
                mdtPlmnPresent = TRUE;
                break;
            }
        }

        if (FALSE == mdtPlmnPresent)
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, mdt_logged, "Serving PLMN not available on MDT Management PLMN list!\n");
            return ERROR;
        }
    }

    // 4. (OPTIONAL) Check if PLMN in target PLMN List provided by EMS - accept UE if list empty or PLMN match entry in
    // list
    if (false == VLIB_checkPlmnOnTraceList(ptCi, pSession))
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_logged, "servingPlmn(mcc:%x,mnc:%x) not present on target-plmns list\n",
            ptCi->ueInfo.servedPlmn.s2.mcc, ptCi->ueInfo.servedPlmn.s2.mnc);
        return ERROR;
    }

    // 5. Allowed IMEI-TAC list check
    const AllowedImeiTacList_type *allowedImeiTacList = &pCfg->globalTraceInfo.management.mdt.allowedImeiTacList;
    uint8_t imeiTacFilterOnOff = pCfg->globalTraceInfo.management.mdt.imeiTacFilterOnOff;

    if (false == VLIB_checkAllowedImsiTacList(ptCi, allowedImeiTacList, imeiTacFilterOnOff))
    {
        return ERROR;
    }

    // 6. Random selection algorithm (like in Immediate MDT but based on logged-mdt-selection-rate parameter)
    if (false == VLIB_mdtRandomSelection(ptCi->gnbNum, pCfg->globalTraceInfo.management.mdt.loggedSelectionRate))
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_logged, "Random selection algorithm does not select UE for logged MDT!\n");
        return ERROR;
    }

    return TRUE;
}

/**
 * @brief   [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Request Management based MDT UE Info data retrieval if conditions met
 * @param   [in] ptCi : pointer to Call Context
 * @return  int16_t GOOD/BREAK/ERROR
 */
int16_t VLIB_mdtUeInfoDataRetrievalRequest(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    int16_t status = GOOD;

    // Check if system is not in overloaded state
    if (true == VLIB_traceDisabledDueToOverload())
    {
        // start timer to request data retrieval after configured period of a time due to overload
        VLIB_AttachTimer(&ptCi->traceTimer, ptCi, timInternalMdtDataRetrieval_id);
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_immediate, "Data retrieval not requested due to system overload\n");
        return BREAK;
    }

    status = VCOM_SendNRRRC_UEInformationRequest(ptCi);
    if (ERROR == status)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_immediate, "VCOM_SendNRRRC_UEInformationRequest ERROR!\n");
        return ERROR;
    }

    return GOOD;
}

bool checkAndRequestLoggedMdtDataCollection(callInfo_type *ptCi, VccbCellInfo_type *pCell)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pCell, false);

    // Check if cell has Logged MDT data collection enabled
    if (TRUE == pCell->cellCollectorTraceInfo.collectOnOff)
    {
        // check if UE inform that has data ready to received
        if (VCCB_FLAG_ON == ptCi->collectorTraceInfo.mdtLogMeasAvailableFlag)
        {
            // start timer to request data retrieval after configured period of a time
            VLIB_AttachTimer(&ptCi->traceTimer, ptCi, timInternalMdtDataRetrieval_id);
            return true;
        }
        else
        {
            VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_logged, "UE did not indicate logMeasAvailable to perform data retrieval\n");
        }
    }
    else
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_logged, "Data retrieval not requested due to collection data OFF\n");
    }

    return false; 
}

void requestLoggedMdtUeConfig(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    // if no data collection required, just queue configuration if needed 
    if (VCCB_FLAG_ON == ptCi->managementTraceInfo.mdtInfo.updateConfigFlag || 
        mdtLogged == ptCi->signalingTraceInfo.mdt.mdtStatus)
    {
        // queue VLIB_handleUeInfoRequestTrigger (no data collection) only for configuration
        if (ERROR == VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_HANDLE_UE_INFO_REQUEST))
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, mdt_logged, "VCCM_enqueueAction(ENQUEUE_ACTION_HANDLE_UE_INFO_REQUEST) ERROR\n");
        }
    }
}

/**
 * @brief   [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Start Management based Logged MDT
 * @notice  before call in all UE attach phase (Resume, HO, RRE, Attach)
 *          check if logMdtData available and
 *          set ptCi->collectorTraceInfo.mdtLogMeasAvailableFlag
 * @param   [in] ptCi : pointer to Call Context
 * @param   [in] cellNum : cellNum to activate feature
 */
void VLIB_startLoggedMdtTrace(callInfo_type *ptCi, uint16_t cellNum)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    const VccbCfgInfo_type *const pCfg = CFG;

    VRRM_addLoggedMdtCapableUeCount(ptCi, cellNum);

    // Logged MDT not supported in NSA and NRDC (SN) call
    if (IS_ENDC_SN(ptCi) || IS_NRDC_SN(ptCi))
    {
        return;
    }

    if (reporting_disabled == VLIB_checkConfiguredReportingType(ptCi))
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_logged, "Tracing for call type currently disabled\n"); 
        return;
    }
    
    if(mdtDisabled != ptCi->signalingTraceInfo.mdt.mdtStatus)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_logged, "Cannot activate session - signaling mdt already running!\n"); 
        return;
    }

    ManagementTraceSessionPerCell_type *pSession = &pCell->traceSession;
    VALID_E_POINT_CHECK_VOID(pSession);

    TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, cellNum, false);

    if (nullptr != pRecordingSession && VCCB_FLAG_ON == pRecordingSession->jobStatus.loggedMdtFlag)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_logged, "Logged MDT already activated for this UE. CellNum(%i)\n", cellNum);
        return;
    }

    // Check if VCCB is not in overload state
    if (true == VLIB_traceDisabledDueToOverload())
    {
        // due to UE enter cell in overload state, UE will be not considered for Logged MDT configuration procedure
        ptCi->managementTraceInfo.mdtInfo.updateConfigFlag = VCCB_FLAG_OFF;
        return;
    }

    // check if UE accepted for logged MDT configuration procedure
    if (FALSE == pSession->traceSessJobOnOff || FALSE == pCfg->globalTraceInfo.cellTraceOnOff)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_logged, "Trace session disabled for selected cellNum(%u)\n", cellNum);
        return;
    }

    if (FALSE == pSession->mdt.mdtSessionConfiguration.logged.functionOnOff ||
        FALSE == pSession->managementJobType.logged)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_logged, "Disabled for selected cellNum(%u)\n", cellNum);
    }
    else if (VCCB_FLAG_OFF == pSession->mdt.loggedMdtAllowedFlag)
    {
        VCCB_PRINT_TRACE_ERROR(
                ptCi, mdt_logged, "Not started due max number of MDT UEs exceeded. cellnum(%u)\n", cellNum);
    }
    else if (GOOD == VLIB_selectUeForLoggedMdt(ptCi, cellNum))
    {
        // TRSR allocation
        if (ERROR == VLIB_allocateTrsr(ptCi, cellNum, mdt_logged))
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, mdt_logged, "TRSR allocation ERROR. cellNum(%u)!\n", cellNum);
            ptCi->managementTraceInfo.mdtInfo.updateConfigFlag = VCCB_FLAG_OFF;
        }
        else
        {
            // TRSR allocation can create new traceSession so update pointer
            pRecordingSession = getTraceSession(ptCi, cellNum, false);
            if (nullptr == pRecordingSession)
            {
                VCCB_PRINT_TRACE_ERROR(ptCi, mdt_logged, "Cannot get session for cellNum(%u)\n", cellNum);
            }
            else
            {
                // VCCB provide logged MDT configuration to UE after reception all logging data (if available)
                VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_logged, "UE selected for Logged MDT. cellNum(%u)\n", cellNum);
                ptCi->managementTraceInfo.mdtInfo.updateConfigFlag = VCCB_FLAG_ON;
                pRecordingSession->jobStatus.loggedMdtFlag = VCCB_FLAG_ON;
                VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_logged, "Started for cellNum(%u)\n", cellNum);
                if (ERROR == VIIL_sendTraceStatusVccbVtmb(ptCi, Trace_Management, cellNum))
                {
                    VCCB_PRINT_TRACE_ERROR(ptCi, mdt_logged, "VIIL_sendTraceStatusVccbVtmb (cellNum: %d) ERROR!\n", cellNum);
                }
            }   
        }
    }
    else
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_logged, "UE not selected for Logged MDT. cellNum(%u)\n", cellNum);
    }

    // if no data retrieval required request UE configuration update
    if (false == checkAndRequestLoggedMdtDataCollection(ptCi, pCell))
    {
        requestLoggedMdtUeConfig(ptCi);
    }
}

/**
 * @brief   [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Handle Management based MDT UE Info (queued operation)
 * @param   [in] ptCi : pointer to Call Context
 * @return  int16_t GOOD/ERROR
 */
int16_t VLIB_handleUeInfoRequestTrigger(callInfo_type *ptCi, enqueuedAction)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    int16_t status;
    bool requestRetrieval = false;

    // if Logged MDT not supported in NSA call
    if (E_CALLTYPE_NSA == ptCi->callType)
    {
        return GOOD;
    }

    // if logged measurements available request it only if UE rPLMN match gNB primary PLMN otherwise skip collection
    // request
    if ((VCCB_FLAG_ON == ptCi->collectorTraceInfo.mdtLogMeasAvailableFlag) &&
        (TRUE == pCell->cellCollectorTraceInfo.collectOnOff))
    {
        requestRetrieval = true;
    }

    if ((VCCB_FLAG_ON == ptCi->collectorTraceInfo.mdtConnEstFailAvailableFlag) &&
        (TRUE == pCell->cellCollectorTraceInfo.rcefFunctionOnOff))
    {
        requestRetrieval = true;
    }

    if (true == requestRetrieval)
    {
        status = VLIB_mdtUeInfoDataRetrievalRequest(ptCi);
        // preserve mdtLogMeasAvailagleFlag and mdtConnEstFailAvailableFlag to request data retrieval after timeout if
        // vccb leave overload state
        VCCB_RETURN_ON_CALL_NBREAK(ptCi, status, "VLIB_mdtUeInfoDataRetrievalRequest overload BREAK\n");

        if (GOOD == status)
        {
            return GOOD;
        }

        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "VLIB_mdtUeInfoDataRetrievalRequest ERROR!\n");
    }

    // in case of retrieval request error or all pending data already collected just configure UE if required
    if (VCCB_FLAG_ON == ptCi->managementTraceInfo.mdtInfo.updateConfigFlag ||
        mdtLogged == ptCi->signalingTraceInfo.mdt.mdtStatus)
    {
        ptCi->managementTraceInfo.mdtInfo.updateConfigFlag = VCCB_FLAG_OFF;
        status = VCOM_SendNRRRC_LoggedMeasurementConfiguration(ptCi);
        if (ERROR == status)
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, mdt_logged, "VCOM_SendNRRRC_LoggedMeasurementConfiguration ERROR!\n");
            return ERROR;
        }
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_logged, "New configuration sent to UE\n");

        // collect LoggedMDTConfiguration counter
        MACRO_STAT_PMCC_FLOAT(STAT_MDT_CONFIGURATION_DELIVERY_DU_ID, LoggedMDTConfiguration, ptCi, (float)1.0, 0, 0, 0, 0);
    }

    return GOOD;
}

/**
 * @brief   [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Deallocates TRSR and decrements Logged MDT UE count.
 *          Function is called when Logged MDT active UE leaves from cell or goes to idle state.
 *          Before this function is called 'ptCi->managementTraceInfo.stopCellNum' needs to be set to serving
 * cell
 * @param   [in] ptCi : pointer to Call Context
 * @param   [in] cellNum : cell number pointing which cell should decrement counters and deallocate TRSR
 * @return  int16_t GOOD/ERROR
 */
int16_t VLIB_stopLoggedMdtTrace(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    ManagementTraceSessionPerCell_type *pSession = &pCell->traceSession;
    VALID_E_POINT_CHECK_ERROR(pSession);

    TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, cellNum, false);

    if (nullptr == pRecordingSession)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_logged, "Cannot get session for cellNum(%u)\n", cellNum);
        return BREAK;
    }

    if (VCCB_FLAG_OFF == pRecordingSession->jobStatus.loggedMdtFlag)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_logged, "Deactivation discarded - job not activated\n");
        return GOOD;
    }

    pRecordingSession->jobStatus.loggedMdtFlag = VCCB_FLAG_OFF;

    // TRSR deallocation (common with Cell Trace) and decrement loggedMdtUeCountCpc counter
    if (GOOD == VLIB_deallocateTrsr(ptCi, cellNum, mdt_logged))
    {
        clearTraceSession(ptCi, pRecordingSession);
    }

    if (ERROR == VIIL_sendTraceStatusVccbVtmb(ptCi, Trace_Management, cellNum))
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_logged, "VIIL_sendTraceStatusVccbVtmb (cellNum: %d) ERROR!\n", cellNum);
    }
    
    VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_logged, "Deactivated - UE left cell(%i)\n", cellNum);

    return GOOD;
}

/**
 * @brief   [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Check if report PLMN (portion of Trace Reference) match PLMN where TCE entity resides (gNB primary PLMN)
 * @param   [in] ptCi : pointer to Call Context
 * @param   [in] pLogMeasRep : pointer to Loged MDT measurement report
 * @return  int16_t GOOD/ERROR
 */
int16_t VLIB_checkLogMeasReportPlmnMatchGnbPlmn(callInfo_type *ptCi, NRRRC_LogMeasReport_r16 *pLogMeasRep)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pLogMeasRep);

    plmnId_type reportPlmn;
    uint8_t notUsed;
    int16_t status = VRIL_StoreNRRRC_plmn_Identity(&reportPlmn, &pLogMeasRep->traceReference_r16.plmn_Identity_r16);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "[Logged MDT] VRIL_StoreNRRRC_plmn_Identity ERROR!\n");

    if (GOOD != VLIB_getMultipleGnbPlmnIndexInfo(ptCi, &notUsed, reportPlmn.longId))
    {
        VCCB_RETURN_ON_CALL_ERROR(
            ptCi, ERROR, "[Logged MDT] Report PLMM(0x%X) does not match gNB PLMN\n", reportPlmn.longId);
    }
    return GOOD;
}

/**
 * @brief   [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Collect MDT RLF data from received NRRRC_UEInformationResponse_r16 message and forward it to VTMB
 * @param   [in] ptCi     : pointer to Call Context
 * @param   [in] pIE      : pointer to unpaced NRRRC_UEInformationResponse message
 * @return  int16_t GOOD/ERROR
 */
static void VLIB_collectMdtRlfUeInfoData(callInfo_type *ptCi, NRRRC_UEInformationResponse_r16_IEs *pIE)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pIE);

    uint16_t cellNum = ptCi->servCellNum;
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    const VccbCfgInfo_type *const pCfg = CFG;

    int16_t status = GOOD;
    ManagementTraceSessionPerCell_type *pSession = &pCell->traceSession;

    const bool isInterGnbRre{(RrcReestablish_cmd == ptCi->stateCmd) &&
                             (RRE_TYPE_INTER_GNB == ptCi->ueInfo.reestablishInfo.reestablishType)};

    // MDT RLF Collection
    const bool isMdtRlfColletion {(TRUE == pSession->traceSessJobOnOff) &&
                                  (TRUE == pCell->cellCollectorTraceInfo.rlfFunctionOnOff) &&
                                  (TRUE == pSession->managementJobType.rlf) &&
                                  (TRUE == pCfg->globalTraceInfo.cellTraceOnOff) &&
                                  (pIE->bit_mask & NRRRC_rlf_Report_r16_present)};
    if (false == isMdtRlfColletion)
    {
        return;
    }

    // Send RLF report via XnFailureIndicaion message to source gNB so that source gNB can collect it
    if (true == isInterGnbRre)
    {
        if (IS_MRO_ENABLED( MRO_TYPE_ANY, ptCi))
        {
            // Skip sending RLF report via XnFailureIndicaion message for InterGnb RRE. MRO will send it.
            return;
        }

#if __SEND_FAILUREIND__
        if (NR_RlfReport != ptCi->rlfReportInfo.choice)
        {
            // Skip not NR case
            return;
        }

        // Get Last Serving Cell from nr-RLF-Report
        if (!ptCi->rlfReportInfo.isLastServingCellValid)
        {
            VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_rlf_rcef, "Last Serving NR Cell is not available in nr-RLF-Report ERROR!\n");
        }
        else
        {
            // Last Serving Cell belongs to this gNB ?
            if (FALSE == VLIB_isCellBelongsToGnb(&ptCi->rlfReportInfo.LastServingCellId.plmn,
                             &ptCi->rlfReportInfo.LastServingCellId.ci, ptCi->gnbNum))
            {
                status = FnVCCB_PrepareXNAP_FailureIndication(ptCi);
                if (GOOD == status)
                {
                    return;
                }

                VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_rlf_rcef, "FnVCCB_SendFailureIndication stauts(%d)!\n", status);
            }
        }
#else
        /* 
            26A only temporary modification. For 26A, sending/receiving XN Failure Indication is 
            contolled by MRO parameter because of backward compatibility issue.
            This will be designed officially on 26B with FnVCCB_NonUeAsn1Proc_XN_FailureIndication() together
        */
        return;        
#endif        
    }

    // Collect MDT RLF from this gNB
    // Allocate TRSR if not yet allocated
    status = VLIB_allocateTrsr(ptCi, cellNum, mdt_rlf_rcef);
    if (ERROR == status)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_rlf_rcef, "TRSR allocation ERROR!\n");
        return;
    }

    if (GOOD == status)
    {
        // Send Trace status in case of newly allocate TRSR
        status = VIIL_sendTraceStatusVccbVtmb(ptCi, Trace_Management, cellNum);
        if (ERROR == status)
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, mdt_rlf_rcef, "VIIL_sendTraceStatusVccbVtmb (cellNum: %d) ERROR!\n", cellNum);
        }
    }

    TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, cellNum, false);

    if (nullptr == pRecordingSession)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_rlf_rcef, "Cannot get session for cellNum(%u)\n", cellNum);
        return;
    }

    pRecordingSession->jobStatus.rlfOrRcefFlag = VCCB_FLAG_ON;

    const bool isRLF{true};
    status = VIIL_sendRcefRlfMdtDataNotiVccbVtmb(ptCi, isRLF, MDT_UeInformationResponse);
    if (ERROR == status)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_rlf_rcef, "VIIL_sendRcefRlfMdtDataNotiVccbVtmb ERROR!\n");
        return;
    }
    VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_rlf_rcef, "Collected and transferred do VTMB\n");
}

/**
 * @brief   [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Collect received MDT measurement and forward it to VTMB
 * @param   [in] ptCi     : pointer to Call Context
 * @param   [in] ptUnpack : pointer to unpacked measurement message
 * @return  int16_t GOOD/ERROR
 */
int16_t VLIB_collectMdtUeInfoData(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);
    uint16_t cellNum = ptCi->servCellNum;
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    const VccbCfgInfo_type *const pCfg = CFG;
    int16_t status = GOOD;
    bool dropMeasurement = false;
    NRRRC_UEInformationResponse_r16 *ptRrcMsg = NULL;
    NRRRC_UEInformationResponse_r16_IEs *pIE = NULL;
    NRRRC_LogMeasReport_r16 *pLogMeasRep = NULL;
    ptRrcMsg = reinterpret_cast<NRRRC_UEInformationResponse_r16 *>(&ptUnpack->unpack[0] + ptUnpack->unpackMsgOffset);

    ManagementTraceSessionPerCell_type *pSession = &pCell->traceSession;

    if (ptRrcMsg->criticalExtensions.choice == NRRRC_criticalExtensions_ueInformationResponse_r16_chosen)
    {
        pIE = &ptRrcMsg->criticalExtensions.u.ueInformationResponse_r16;

        // MDT RLF Collection
        VLIB_collectMdtRlfUeInfoData(ptCi, pIE);

        // MDT RCEF Collection
        if ((TRUE == pSession->traceSessJobOnOff) &&
            (TRUE == pCell->cellCollectorTraceInfo.rcefFunctionOnOff) &&
            (TRUE == pSession->managementJobType.rcef) &&
            (TRUE == pCfg->globalTraceInfo.cellTraceOnOff) && (pIE->bit_mask & NRRRC_connEstFailReport_r16_present))
        {
            // allocate TRSR if not yet allocated
            status = VLIB_allocateTrsr(ptCi, cellNum, mdt_rlf_rcef);
            if (ERROR == status)
            {
                VCCB_PRINT_TRACE_ERROR(ptCi, mdt_rlf_rcef, "TRSR allocation ERROR!\n");
                return ERROR;
            }
            else if (GOOD == status)
            {
                // Send Trace status in case of newly allocate TRSR
                if (ERROR == VIIL_sendTraceStatusVccbVtmb(ptCi, Trace_Management, cellNum))
                {
                    VCCB_PRINT_TRACE_ERROR(ptCi, mdt_rlf_rcef, "VIIL_sendTraceStatusVccbVtmb (cellNum: %d) ERROR!\n", cellNum);
                }
            }

            TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, cellNum, false);
            if (nullptr == pRecordingSession)
            {
                VCCB_PRINT_TRACE_ERROR(ptCi, mdt_rlf_rcef, "Cannot get session for cellNum(%u)\n", cellNum);
                return ERROR;
            }
            pRecordingSession->jobStatus.rlfOrRcefFlag = VCCB_FLAG_ON;

            const bool isRLF{false};
            status = VIIL_sendRcefRlfMdtDataNotiVccbVtmb(ptCi, isRLF, MDT_UeInformationResponse);
            if (ERROR == status)
            {
                VCCB_PRINT_TRACE_ERROR(ptCi, mdt_rlf_rcef, "VIIL_sendRcefRlfMdtDataNotiVccbVtmb ERROR!\n");
                return ERROR;
            }
            VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_rlf_rcef, "Collected and transferred do VTMB\n");
        }

        // Logged MDT Collection
        if (TRUE == pCell->cellCollectorTraceInfo.collectOnOff)
        {
            if (pIE->bit_mask & NRRRC_logMeasReport_r16_present)
            {
                pLogMeasRep = &pIE->logMeasReport_r16;
                if (GOOD == VLIB_checkLogMeasReportPlmnMatchGnbPlmn(ptCi, pLogMeasRep))
                {
                    status = VIIL_sendLoggedMdtDataNotiVccbVtmb(ptCi, pLogMeasRep);
                    if (ERROR == status)
                    {
                        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_logged, "VIIL_sendLoggedMdtDataNotiVccbVtmb ERROR!\n");
                        return ERROR;
                    }

                    // collect LoggedMDTDelivery counter
                    MACRO_STAT_PMCC_FLOAT(
                        STAT_MDT_CONFIGURATION_DELIVERY_DU_ID, LoggedMDTDelivery, ptCi, (float)1.0, 0, 0, 0, 0);

                    status = VLIB_sendLoggedMdtCellTrafficTrace(ptCi, pLogMeasRep);
                    if (ERROR == status)
                    {
                        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_logged, "VLIB_checkAndSendMdtCellTrafficTrace ERROR!\n");
                        return ERROR;
                    }

                    if (BREAK == status)
                    {
                        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_logged, "CellTrafficTrace not sent\n");
                    }
                }
                else
                {
                    // drop received measurement and skip trying to receive it again
                    dropMeasurement = true;
                    ptCi->collectorTraceInfo.mdtLogMeasAvailableFlag = VCCB_FLAG_OFF;
                }

                if ((pLogMeasRep->bit_mask & NRRRC_LogMeasReport_r16_logMeasAvailable_r16_present) &&
                    (NRRRC_true == pLogMeasRep->logMeasAvailable_r16) && (false == dropMeasurement))
                {
                    // UE contain more logged MDT data ready to readout
                    ptCi->collectorTraceInfo.mdtLogMeasAvailableFlag = VCCB_FLAG_ON;
                    // start timer to request remaining data retrieval after configured period of a time
                    VLIB_AttachTimer(&ptCi->traceTimer, ptCi, timInternalMdtDataRetrieval_id);
                }
                // else if no more data need to be readout check if UE logged MDT configuration required
                else if (VCCB_FLAG_ON == ptCi->managementTraceInfo.mdtInfo.updateConfigFlag &&
                         TRUE == pSession->mdt.mdtSessionConfiguration.logged.functionOnOff)
                {
                    // queue VLIB_handleUeInfoRequestTrigger (no data collection) only for configuration
                    status = VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_HANDLE_UE_INFO_REQUEST);
                    if (ERROR == status)
                    {
                        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_logged, "VCCM_enqueueAction(ENQUEUE_ACTION_HANDLE_UE_INFO_REQUEST) ERROR!\n");
                        return ERROR;
                    }
                }
            }
        }
        // else if no logged MDT data collection enabled check if UE logged MDT configuration required
        else if (VCCB_FLAG_ON == ptCi->managementTraceInfo.mdtInfo.updateConfigFlag &&
                 TRUE == pSession->mdt.mdtSessionConfiguration.logged.functionOnOff)
        {
            // queue VLIB_handleUeInfoRequestTrigger (no data collection) only for configuration
            status = VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_HANDLE_UE_INFO_REQUEST);
            if (ERROR == status)
            {
                VCCB_PRINT_TRACE_ERROR(ptCi, mdt_logged, "VCCM_enqueueAction(ENQUEUE_ACTION_HANDLE_UE_INFO_REQUEST) ERROR!\n");
                return ERROR;
            }
        }
    }
    return GOOD;
}

/**
 * @brief  [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 *         [FGR-TA0103] Cell traffic trace
 * @details Get TCE IP address by its TCE_ID index
 * @return  GOOD  : Success
 *          ERROR : Error
 */
int16_t VLIB_getTceIp(uint8_t tceId, MdsIp_Type *const tceIp)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(tceIp);
    VCCB_CHECK_E_RANGE_AND_RETURN(tceId, TCE_MAX_NUMBER);
    VccbCfgInfo_type *const pCfg = CFG;

    PredefinedTceServers_type *servers = pCfg->globalTraceInfo.predefinedTceServers;

    if (EQUIP != servers[tceId].status)
    {
        return ERROR;
    }

    *tceIp = servers[tceId].server.ip.MdsIp;

    return GOOD;
}
/**
 * @brief   [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Collect received MDT RLF measurement and forward it to VTMB.
 *          Function usable for 2 interGNB RRE cases:
 *          1) Target VCCB sent XN_FailureIndication. Source VCCB shall handle RLF report sending.
 *          2) Target VCCB didn't sent XN_FailureIndication. Target VCCB shall handle RLF report sending.
 *          Function not applicable for RRC Setup cases. RLF report with RRC setup always sent by 'target' vccb.
 * @param   [in] ptCi               : pointer to Call Context
 * @param   [in] failureTypeSource  : failure information source
 */
void VLIB_collectRlfReportFromFailureIndication(callInfo_type *ptCi, enumMdtRecordSource_type failureTypeSource)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint16_t cellNum = ptCi->servCellNum;
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    const VccbCfgInfo_type *const pCfg = CFG;

    ManagementTraceSessionPerCell_type *pSession = &pCell->traceSession;
    VALID_E_POINT_CHECK_VOID(pSession);

    // Collect only for NR SA case.
    if (OPT_PRESENT != ptCi->rlfReportInfo.received || NR_RlfReport != ptCi->rlfReportInfo.choice)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_rlf_rcef, "[SA] RLF report not present (%i, %i) - skipped\n",
            ptCi->rlfReportInfo.received, ptCi->rlfReportInfo.choice);
        return;
    }

    const bool isInterGnbRre{
        (RrcReestablish_cmd == ptCi->stateCmd) && (RRE_TYPE_INTER_GNB == ptCi->ueInfo.reestablishInfo.reestablishType)};

    // Handle only RRE case here. RRC Setup case handled after receiving UeInformationResponse.
    if (false == isInterGnbRre && CI_no_use == ptCi->managementTraceInfo.mdtInfo.failure_ind.rre)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_rlf_rcef, "Not interGNB RRE case (%i, %i) - skip\n", isInterGnbRre,
            ptCi->managementTraceInfo.mdtInfo.failure_ind.rre);
        return;
    }

    // Get Last Serving Cell from nr-RLF-Report
    if (!ptCi->rlfReportInfo.isLastServingCellValid)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_rlf_rcef, "Last Serving NR Cell is not available in nr-RLF-Report ERROR!\n");
        return;
    }

    if (MDT_UeInformationResponse != failureTypeSource &&
        FALSE == VLIB_isCellBelongsToGnb(&ptCi->rlfReportInfo.LastServingCellId.plmn,
                     &ptCi->rlfReportInfo.LastServingCellId.ci, ptCi->gnbNum))
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_rlf_rcef, "Skip Rx XN_FailureIndication. LastServingCell from RLF does not belong to this gNB\n");
        return;
    }

    int16_t status = GOOD;

    if (FALSE == pSession->traceSessJobOnOff || FALSE == pSession->managementJobType.rlf ||
        FALSE == pCell->cellCollectorTraceInfo.rlfFunctionOnOff || FALSE == pCfg->globalTraceInfo.cellTraceOnOff)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_rlf_rcef, "RLF disabled (%i,%i,%i,%i). XN_FailureIndication RLF report skipped\n",
            pSession->traceSessJobOnOff, pSession->managementJobType.rlf,
            pCell->cellCollectorTraceInfo.rlfFunctionOnOff, pCfg->globalTraceInfo.cellTraceOnOff);
        return;
    }

    VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_rlf_rcef, "collecting RLF report from XN_FailureIndication\n");

    // allocate TRSR if not yet allocated
    status = VLIB_allocateTrsr(ptCi, cellNum, mdt_rlf_rcef);
    if (ERROR == status)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_rlf_rcef, "TRSR allocation ERROR!\n");
        return;
    }
    else if (GOOD == status)
    {
        // Send Trace status in case of newly allocate TRSR
        if (ERROR == VIIL_sendTraceStatusVccbVtmb(ptCi, Trace_Management, cellNum))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_sendTraceStatusVccbVtmb (cellNum: %d) ERROR!\n", cellNum);
        }
    }

    TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, cellNum, false);

    if (nullptr == pRecordingSession)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_rlf_rcef, "Cannot get session for cellNum(%u)\n", cellNum);
        return;
    }

    pRecordingSession->jobStatus.rlfOrRcefFlag = VCCB_FLAG_ON;

    const bool isRLF{true};
    status = VIIL_sendRcefRlfMdtDataNotiVccbVtmb(ptCi, isRLF, failureTypeSource);
    if (ERROR == status)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_rlf_rcef, "VIIL_sendRcefRlfMdtDataNotiVccbVtmb ERROR!\n");
        return;
    }
}

/**
 * @brief   [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Deallocates TRSR and turns off flag for RLF and RCEF MDT.
 * @param   [in] ptCi : pointer to Call Context
 * @param   [in] cellNum : cell number pointing which cell should decrement counters and deallocate TRSR
 * @return  int16_t GOOD/ERROR
 */
int16_t VLIB_stopRlfAndRcefdMdtTrace(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    ManagementTraceSessionPerCell_type *pSession = &pCell->traceSession;
    VALID_E_POINT_CHECK_ERROR(pSession);

    TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, cellNum, false);

    if (nullptr == pRecordingSession)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_rlf_rcef, "Cannot get session for cellNum(%u)\n", cellNum);
        return BREAK;
    }

    if (VCCB_FLAG_OFF == pRecordingSession->jobStatus.rlfOrRcefFlag)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_rlf_rcef, "UE leave handling not used\n");
        return GOOD;
    }

    VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_rlf_rcef, "UE is leaving cell(%i)\n", cellNum);

    pRecordingSession->jobStatus.rlfOrRcefFlag = VCCB_FLAG_OFF;

    // TRSR deallocation (common with Cell Trace)
    if (GOOD == VLIB_deallocateTrsr(ptCi, cellNum, mdt_rlf_rcef))
    {
        clearTraceSession(ptCi, pRecordingSession);
    }

    // Even tough RLF/RCEF doesn't have it's own counter, send in order to update TRSR count in vtmb.
    if (ERROR == VIIL_sendTraceStatusVccbVtmb(ptCi, Trace_Management, cellNum))
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_rlf_rcef, "VIIL_sendTraceStatusVccbVtmb (cellNum: %d) ERROR!\n", cellNum);
    }

    return GOOD;
}

/**
 * @brief   [FGR-TA0104] UE Throughput and RF Trace
 * @param   [in] ptCi    : pointer to Call Context
 */
void VLIB_startManagementUeThrRfTrace(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    VCCB_CHECK_E_RANGE_AND_VOID(pCell->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[pCell->gnbNum];
    ManagementTraceSessionPerCell_type *pSessionCfg = &pCell->traceSession;
        
    if (!VLIB_checkTraceRfspSpidAllowed(ptCi, MSGBASE_NR_PROTOCOL))
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_uethr, "RFSP/SPID condition not met - no UETHR\n");
        return;
    }

    TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, cellNum, false);

    if (nullptr != pRecordingSession)
    {
        if (VCCB_FLAG_ON == pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag)
        {
            VCCB_PRINT_TRACE_COMMENT(ptCi, trace_uethr, "Already activated for cellNum(%u)\n", cellNum);
            return;
        }

        if (TRUE == pRecordingSession->traceStartE1DeliveryStatus && 
            TRUE == pRecordingSession->traceStartF1DeliveryStatus)
        {
            VCCB_PRINT_TRACE_COMMENT(ptCi, trace_uethr, "E1/F1 TraceStart already delivered - activation skipped\n");
            return;
        }
    }

    if (FALSE == pSessionCfg->traceSessJobOnOff || pSessionCfg->managementJobType.trace == 0)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_uethr, "Tracing disabled for selected cellNum(%u)\n", cellNum);
        return;
    }

    if (reporting_disabled == VLIB_checkConfiguredReportingType(ptCi))
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_uethr, "Tracing for call type currently disabled\n"); 
        return;
    }

    if (VCCB_FLAG_OFF != ptCi->signalingTraceInfo.trace.ueThroughputAndRfTraceFlag)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_uethr, "Cannot activate session - signaling UETHR already running!\n"); 
        return;
    }

    // check cell local copy of flag throughputAndRfTraceOnOff
    // local value is overwritten by global throughputAndRfTraceOnOff (GlobalTraceInfo_type) only at (re)start of trace session
    if (VCCB_FLAG_ON != pSessionCfg->trace.throughputAndRfTraceOnOff)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_uethr, "Disabled for selected cellNum(%u)\n", cellNum);
        return;
    }

    if (Maximum != pSessionCfg->trace.traceDepth)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_uethr, "Not activated (traceDepth!=maximum)\n");
        return;
    }

    // Check max UE count for Trace Session
    switch (checkTraceUethrCellLimitReached(pRecordingSession, cellNum))
    {
        case no_error:
            break;

        case trace_cell_limit:
            VCCB_PRINT_TRACE_COMMENT(ptCi, trace_uethr, "Not started due to cell(num:%u) limit reached!\n", cellNum);
            return;

        case acpf_limit:
            VCCB_PRINT_TRACE_COMMENT(ptCi, trace_uethr, "Not started due to PLD CTT/UETHR limit reached!\n");
            return;

        default:
            return;
    }

    // System overload check
    if (true == VLIB_traceDisabledDueToOverload())
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, trace_uethr, "Not started due to overload\n");
        return;
    }

    // TRSR allocation (common for Cell Trace, MDT, UE Thr)
    int status = VLIB_allocateTrsr(ptCi, cellNum, trace_uethr);
    if (ERROR == status)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, trace_uethr, "TRSR allocation ERROR\n");
        return;
    }

    // TRSR allocation can create new traceSession so update pointer
    pRecordingSession = getTraceSession(ptCi, cellNum, false);
    if (nullptr == pRecordingSession)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, trace_uethr, "Cannot get session for cellNum(%u)\n", cellNum);
        return;
    }

    pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag = VCCB_FLAG_ON;

    if (GOOD == status)
    {
        // new TRSR allocated - allow to redistribute E1/F1 TraceStart messages
        pRecordingSession->traceStartE1DeliveryStatus = FALSE;
        pRecordingSession->traceStartF1DeliveryStatus = FALSE;

        int16_t result = VCCM_enqueueActionWithForce(ptCi, ENQUEUE_ACTION_SEND_MGT_CELL_TRAFFIC_TRACE, true);
        if (ERROR == result)
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, trace_uethr, "VCCM_enqueueActionWithForce(ENQUEUE_ACTION_SEND_MGT_CELL_TRAFFIC_TRACE) ERROR\n");
        }
    }

    VCCB_PRINT_TRACE_COMMENT(ptCi, trace_uethr,
        "Started gId:cId:trId:trsr(%u:%u:%u:%u) TrsrCnt:%u(trc:%u imm:%u logg:%u), "
        "allocIdx:%u, trsrAllocStatus(%d)\n",
        pGnb->globalGnbId.gnbId.id, pCell->cellIdentity, pSessionCfg->cellTraceReference.traceId,
        pRecordingSession->traceRecordingSessionReference, pSessionCfg->allocatedTRSRCount,
        pSessionCfg->trace.cellTraceUeCountCpc, pSessionCfg->mdt.immediateMdtUeCountCpc,
        pSessionCfg->mdt.loggedMdtUeCountCpc, pSessionCfg->cellTrsrAllocIdx, status);

    // Check if and send Trace Status to VTMB
    if (ERROR == VIIL_sendTraceStatusVccbVtmb(ptCi, Trace_Management, cellNum))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_sendTraceStatusVccbVtmb (cellNum: %d) ERROR!\n", cellNum);
    }

    bool isTargetCell {ptCi->servCellNum != cellNum};

    status = VCCM_enqueueActionWithForce(ptCi, ENQUEUE_ACTION_SEND_MGT_TRACE_START, isTargetCell);
    if (ERROR == status)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, trace_uethr, "VCCM_enqueueAction(ENQUEUE_ACTION_SEND_MGT_TRACE_START) ERROR\n");
    }
}

static void prepareSigTraceFailureIndication(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    enumSigActFailResult cause = ptCi->signalingTraceInfo.failureIndication.cause;

    if (no_error == cause)
    {
        return;
    }

    switch (cause)
    {
        case sa_off:
        case mdt_off:
        case already_activated:
        case not_activated:
        case invalid_tce:
        case invalid_depth:
        case invalid_mdt_config:
        case invalid_ue_consent:
        case invalid_trace_id:
        case acpf_limit:
        case trace_cell_limit:
        case logged_cell_limit:
        case immediate_cell_limit:
            ptCi->signalingTraceInfo.failureIndication.data.choice = NGAP_misc_chosen;
            ptCi->signalingTraceInfo.failureIndication.data.u.misc = NGAP_om_intervention;
            break;

        case overload:
            ptCi->signalingTraceInfo.failureIndication.data.choice = NGAP_misc_chosen;
            ptCi->signalingTraceInfo.failureIndication.data.u.misc = NGAP_control_processing_overload;
            break;

        case invalid_ue_ngap_id:
            ptCi->signalingTraceInfo.failureIndication.data.choice = NGAP_radioNetwork_chosen;
            ptCi->signalingTraceInfo.failureIndication.data.u.radioNetwork = NGAP_inconsistent_remote_UE_NGAP_ID;
            break;

        case pending_xn_ho:
            ptCi->signalingTraceInfo.failureIndication.data.choice = NGAP_radioNetwork_chosen;
            ptCi->signalingTraceInfo.failureIndication.data.u.radioNetwork = NGAP_xn_handover_triggered;
        break;

        case pending_ng_intra_sys_ho:
            ptCi->signalingTraceInfo.failureIndication.data.choice = NGAP_radioNetwork_chosen;
            ptCi->signalingTraceInfo.failureIndication.data.u.radioNetwork = NGAP_ng_intra_system_handover_triggered;
        break;

        case pending_ng_inter_sys_ho:
            ptCi->signalingTraceInfo.failureIndication.data.choice = NGAP_radioNetwork_chosen;
            ptCi->signalingTraceInfo.failureIndication.data.u.radioNetwork = NGAP_ng_inter_system_handover_triggered;
            break;

        default:
            return;
    }
}

void getSigMdtTraceActivatonStatus(callInfo_type *ptCi, traceMdtStatus_type &status)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    status.immediate = mdtImmediate == ptCi->signalingTraceInfo.mdt.mdtStatus ? true : false;
    status.logged = mdtLogged == ptCi->signalingTraceInfo.mdt.mdtStatus ? true : false;
    status.trace = ueTraceEnabledAndActive == ptCi->signalingTraceInfo.trace.traceStatus ? true : false;
    status.uethr = VCCB_FLAG_ON == ptCi->signalingTraceInfo.trace.ueThroughputAndRfTraceFlag ? true : false;
}

static int16_t checkSigAreaScope(callInfo_type *ptCi, SignalingTrace_type *preStoredConfig, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(preStoredConfig);
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);

    union SignalingTrace_type::mdt_s::area_u *areaScope = &preStoredConfig->mdt.areaScope;

    switch (preStoredConfig->mdt.areaScopeType)
    {
        case mdt_area_scope_cell_list:
            {
                cgi_type cellCgi = FnVCCB_GetNrcgiFromCellNum(cellNum);

                for (uint8_t idx=0; idx<areaScope->cell.numOfCell; ++idx)
                {
                    if (TRUE == FnVCCB_CheckCgiIdentical(&cellCgi, &areaScope->cell.nrCgi[idx]))
                    {
                        return GOOD;
                    }
                }
                VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "[SIG] Cell AreaScope not covered!\n");
                return ERROR;
            }
            break;
        
        case mdt_area_scope_tac_list:
            {
                if (N_EQUIP == CELLINFO[cellNum].tacStatus)
                {
                    VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "[SIG] TAC not configured in cell!\n");
                    return ERROR;
                }

                for (uint8_t idx=0; idx<areaScope->tac.numOfTac; ++idx)
                {
                    if (areaScope->tac.TAC[idx] == CELLINFO[cellNum].tac)
                    {
                        return GOOD;
                    }
                }
                VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "[SIG] TAC AreaScope not covered!\n");
                return ERROR;
            }
            break;
        
        case mdt_area_scope_plmn_wide:
                return GOOD; // accept all
            break;

        case mdt_area_scope_tai_list:
            {
                cgi_type cellCgi = FnVCCB_GetNrcgiFromCellNum(cellNum);

                if (N_EQUIP == CELLINFO[cellNum].tacStatus)
                {
                    VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "[SIG] TAC not configured in cell!\n");
                    return ERROR;
                }

                for (uint8_t idx=0; idx<areaScope->tai.numOfTai; ++idx)
                {
                    if (areaScope->tai.TAI[idx].tac == CELLINFO[cellNum].tac &&
                        TRUE == VCOM_CheckPlmnIdentical(&areaScope->tai.TAI[idx].plmn, &cellCgi.plmn))
                    {
                        return GOOD;
                    }
                }
                VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "[SIG] TAI AreaScope not covered!\n");
                return ERROR;
            }
            break;

        default:
            VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "[SIG] Unsupported areaScopeType (%u)\n", preStoredConfig->mdt.areaScopeType);
            return ERROR;
            break;
    }
    return ERROR;
}

static int16_t VLIB_validateStartSigMdtConditions(callInfo_type *ptCi, SignalingTrace_type *preStoredConfig, uint16_t cellNum) 
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(preStoredConfig);
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);

    bool mdtPlmnPresent = false;
    // Condition 1) UE Consent check
    if (FALSE == CELLINFO[cellNum].traceSession.mdt.mdtSessionConfiguration.ignoreUeConsent) 
    {
        if (0 == preStoredConfig->mdt.signallingBasedPlmnList.count)
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, "[MDT][SIG]", "Mdt UE Consent required but PLMN List not available!\n");
            return ERROR;
        }

        // check if serving PLMN appear on Management MDT PLMN list
        for (auto plmnIdx = 0; plmnIdx < MAX_NUM_MDT_PLMNS; ++plmnIdx)
        {
            if (preStoredConfig->mdt.signallingBasedPlmnList.plmnList[plmnIdx].longId ==
                ptCi->ueInfo.servedPlmn.longId)
            {
                mdtPlmnPresent = true;
                break;
            }
        }

        if (false == mdtPlmnPresent)
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, "[MDT][SIG]", "Serving PLMN not available on MDT PLMN list!\n");
            return ERROR;
        }
    }

    if (ERROR == checkSigAreaScope(ptCi, preStoredConfig, cellNum))
    {
        return BREAK;
    }
    return GOOD;
}

static int16_t VLIB_validateStartSigMdtTraceConditions(callInfo_type *ptCi, SignalingTrace_type *preStoredConfig,
    SignalingTrace_type *oldConfig, enumSigActFailResult &result)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(preStoredConfig);

    VccbCfgInfo_type *const pCfg = CFG;

    // MN will not provide TraceActivation IEs event if AMF request it twice (MN trigger TraceFailureIndication)
    if (!IS_NRDC_SN(ptCi))
    {
        VALID_E_POINT_CHECK_ERROR(oldConfig);
        if (ueTraceDisabled != oldConfig->trace.traceStatus ||
            mdtDisabled != oldConfig->mdt.mdtStatus)
        {
            result = already_activated;
            VCCB_PRINT_TRACE_ERROR(ptCi, "[TRACE/MDT]", "[SIG] Cannot start requested session - already activated!\n");
            return ERROR;
        }
    }
    else
    {
       if (!CFG->globalTraceInfo.signaling.trace.nrdcSignalingTraceOnOff)
       {
            result = mdt_off;
            VCCB_PRINT_TRACE_ERROR(ptCi, "[TRACE/MDT]", "[SIG][SN] Signaling disabled in SN!\n");
            return ERROR;
       }
    }

    if (E_CALLTYPE_NSA == ptCi->callType &&  // NSA not supported by signaling MDT
        (none != preStoredConfig->mdt.mdt_Activation &&
         mdtUnknown != preStoredConfig->mdt.mdt_Activation))
    {
        result = invalid_mdt_config;
        VCCB_PRINT_TRACE_ERROR(ptCi, "[MDT][SIG]", "Signaling MDT not supported in NSA call!\n");
        return ERROR;
    }

    // if MDT configuration provided but feature disabled - ERROR
    if ((none != preStoredConfig->mdt.mdt_Activation &&
         mdtUnknown != preStoredConfig->mdt.mdt_Activation) &&
        VCCB_FLAG_OFF == CFG->globalTraceInfo.signaling.mdt.mdtOnOff) // or MDT counter limit reached
    {
        result = mdt_off;
        VCCB_PRINT_TRACE_ERROR(ptCi, "[MDT][SIG]", "MDT configuration provided but feature disabled!\n");
        return ERROR;
    }

    // ACPF level UE allowed count validation
    if (VCCB_FLAG_OFF == pCfg->globalTraceInfo.signaling.sigTraceAllowedFlag ||
        VCCB_FLAG_OFF == pCfg->globalTraceInfo.acpfTraceAllowedFlag)
    {
        result = acpf_limit;
        VCCB_PRINT_TRACE_ERROR(ptCi, "[TRACE/MDT][SIG]", "ACPF UE count limit reached!\n");
        return ERROR;
    }
    return GOOD;
}

static int16_t VLIB_activateSigMdt(callInfo_type *ptCi, const bool isMdtImmedRequested, const bool isMdtLoggedRequested,
    SignalingTrace_type *preStoredConfig, const uint16_t cellNum, uint8_t &jobToRelease, enumSigActFailResult &result)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(preStoredConfig);
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    int16_t mdtActivationStatus = ERROR;
    mdtActivationStatus = VLIB_validateStartSigMdtConditions(ptCi, preStoredConfig, cellNum);
    if (ERROR == mdtActivationStatus)
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, "[MDT][SIG]", "Invalid startup condition!\n");
        result = invalid_ue_consent;
        return ERROR;
    }

    if (ERROR != mdtActivationStatus && isMdtImmedRequested)
    {
        if (BREAK == mdtActivationStatus)
        {
            VCCB_PRINT_TRACE_INFORMATIVE(ptCi, mdt_immediate, "[SIG] Not activated due to area scope configuration\n");
        }
        else
        {
            // CELL level UE allowed count validation for immediateMDT 
            if (VCCB_FLAG_OFF == pCell->traceSession.mdt.immediateMdtAllowedFlag)
            {
                VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "[SIG] Not started due max number of MDT UEs exceeded\n");
                result = immediate_cell_limit;
                return ERROR;
            }

            VCCB_PRINT_TRACE_INFORMATIVE(ptCi, mdt_immediate, "[SIG] Activated\n");
            preStoredConfig->mdt.mdtStatus = mdtImmediate;
            if (TRUE == ptCi->signalingTraceInfo.mdt.config.immediate.measConfigFlags.m1Flag)
            {
                ptCi->signalingTraceInfo.mdt.config.immediate.m1Config.needUeConfig = TRUE;
            }

            jobToRelease |= mdt_immediate;
        }
    }

    // [mdtActivationStatus == GOOD/BREAK] -> areaScope validated at UE side
    if (ERROR != mdtActivationStatus && isMdtLoggedRequested) 
    {
        // Logged MDT not supported in NSA and NRDC (SN) call
        // Trace cannot be activated with logged so return in case of error
        if (IS_ENDC_SN(ptCi) || IS_NRDC_SN(ptCi))
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, mdt_logged, "[SIG] SN not supported for logged MDT\n");
            return ERROR; 
        }

        // CELL level UE allowed count validation for loggedMDT 
        if (VCCB_FLAG_OFF == pCell->traceSession.mdt.loggedMdtAllowedFlag)
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, mdt_logged, "[SIG] Not started due max number of MDT UEs exceeded\n");
            result = logged_cell_limit;
            return ERROR;
        }

        // if no data retrieval required request UE configuration update
        preStoredConfig->mdt.mdtStatus = mdtLogged;
        if (false == checkAndRequestLoggedMdtDataCollection(ptCi, pCell))
        {
            requestLoggedMdtUeConfig(ptCi);
        }

        VCCB_PRINT_TRACE_INFORMATIVE(ptCi, mdt_logged, "[SIG] Activated\n");
        jobToRelease |= mdt_logged;
    }
    return GOOD;
}

static void VLIB_activateSigTrace(callInfo_type *ptCi, const bool isUeThrRequested, SignalingTrace_type *preStoredConfig,
    bool &traceAlreadyActivated, uint8_t &jobToRelease, enumSigActFailResult &result)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(preStoredConfig);

    result = no_error;

    // signaling trace is only deactivated by AMF or
    // during CallRelease otherwise flag is maintained
    if (ueTraceEnabledAndActive == preStoredConfig->trace.traceStatus)
    {
        traceAlreadyActivated = true;
        VCCB_PRINT_TRACE_INFORMATIVE(ptCi, "[TRACE][SIG]", "Session maintained\n");
    }
    else
    {
        VCCB_PRINT_TRACE_INFORMATIVE(ptCi, "[TRACE][SIG]", "Activated\n");
        preStoredConfig->trace.traceStatus = ueTraceEnabledAndActive;
    }
    
    // some interfaces tracing requested
    if (preStoredConfig->trace.traceInterfaces)
    {
        // uetrh is subfeature of ctt so uetrh need to be released too
        jobToRelease |= trace_ctt | trace_uethr;
    }

    if (isUeThrRequested)
    {
        VCCB_PRINT_TRACE_INFORMATIVE(ptCi, trace_uethr, "[SIG] Activated (traceDepth=maximum)\n");
        preStoredConfig->trace.ueThroughputAndRfTraceFlag = VCCB_FLAG_ON;
        jobToRelease |= trace_ctt | trace_uethr;
    }
}

static void VLIB_startSigMdtTrace(callInfo_type *ptCi, SignalingTrace_type *preStoredConfig, const uint16_t cellNum,
    uint8_t jobToRelease, int16_t &status)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(preStoredConfig);
    VCCB_CHECK_VALID_CELLNUM_VOID(cellNum);

    TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, cellNum, false);
    if (nullptr != pRecordingSession)
    {
        if ( ((jobToRelease & trace_uethr)   && VCCB_FLAG_ON == pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag ) || 
             ((jobToRelease & mdt_immediate) && VCCB_FLAG_ON == pRecordingSession->jobStatus.immediateMdtFlag))
        {
            if (ERROR == VLIB_stopManagementUeThrRfTrace(ptCi, cellNum))
            {
                VCCB_PRINT_TRACE_ERROR(ptCi, trace_uethr, "[SIG] VLIB_stopManagementUeThrRfTrace failed");
            }

            if (ERROR == VLIB_stopManagementMdtTrace(ptCi, cellNum))
            {
                VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "VLIB_stopManagementMdtTrace failed");
            }
        }

        if (jobToRelease & trace_ctt)
        {
            if (ERROR == VLIB_stopManagementTraceRecordingSession(ptCi, cellNum))
            {
                VCCB_PRINT_TRACE_ERROR(ptCi, trace_ctt, "VLIB_stopManagementTraceRecordingSession failed");
            }
        }

        if (jobToRelease & mdt_logged)
        {
            if (ERROR == VLIB_stopLoggedMdtTrace(ptCi, cellNum))
            {
                VCCB_PRINT_TRACE_ERROR(ptCi, mdt_logged, "VLIB_stopLoggedMdtTrace failed");
            }
        }
    }

    // queue Trace Start message
    if (VCCB_FLAG_ON == preStoredConfig->trace.ueThroughputAndRfTraceFlag ||
        mdtImmediate == preStoredConfig->mdt.mdtStatus)
    {
        status = VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_SEND_SIG_TRACE_START);
        if (ERROR == status)
        {
            VCCB_PRINT_TRACE_ERROR(
                ptCi, "[TRACE/MDT][SIG]", "VCCM_enqueueAction(ENQUEUE_ACTION_SEND_SIG_TRACE_START) ERROR\n");
        }
    }

    // Install MDT M1 measurement on UE by RrcReconfiguration
    if (mdtImmediate == preStoredConfig->mdt.mdtStatus &&
        TRUE == preStoredConfig->mdt.config.immediate.measConfigFlags.m1Flag &&
        TRUE == ptCi->signalingTraceInfo.mdt.config.immediate.m1Config.needUeConfig)
    {
        if (ERROR == VCCM_EnqueueActionMeasReconfig(ptCi, MeasReconfigPriorAction_Full))
        {
            status = ERROR;
            VCCB_PRINT_TRACE_ERROR(
                ptCi, "[TRACE/MDT][SIG]", "VCCM_EnqueueActionMeasReconfig(MeasReconfigPriorAction_Full) ERROR!\n");
        }
    }
}

int16_t VLIB_activateSigMdtTrace(callInfo_type *ptCi, enumSigActFailResult &result, SignalingTrace_type *oldConfig, bool actInSetup, uint16_t startCellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VccbCfgInfo_type *const pCfg = CFG;
    SignalingTrace_type *preStoredConfig = &ptCi->signalingTraceInfo;
    int16_t status = GOOD;
    uint16_t cellNum = (MAX_CELL_NUM_VCCB == startCellNum) ? ptCi->servCellNum : startCellNum;
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    if (reporting_disabled == VLIB_checkConfiguredReportingType(ptCi))
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_trace_all, " [SIG] Tracing for call type currently disabled\n"); 
        return GOOD;
    }

    if (ERROR == VLIB_validateStartSigMdtTraceConditions(ptCi, preStoredConfig, oldConfig, result))
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, "[TRACE/MDT]", "[SIG] Invalid startup condition!\n");
        return ERROR;
    }

    // FGR-TA0104 UE Throughput and RF information Trace
    const bool isUeThrRequested { maximum == preStoredConfig->trace.traceDepth &&
                                  CFG->globalTraceInfo.signaling.trace.throughputAndRfTraceOnOff };

    // FGR-SO1101 NR Minimization of Drive Tests (NR MDT)
    const bool isMdtImmedRequested { (immediate == preStoredConfig->mdt.mdt_Activation ||
                                      immediate_trace == preStoredConfig->mdt.mdt_Activation) &&
                                     VCCB_FLAG_ON == CFG->globalTraceInfo.signaling.mdt.mdtOnOff };
    
    // FGR-SO1101 NR Minimization of Drive Tests (NR MDT)
    const bool isMdtLoggedRequested { logged == preStoredConfig->mdt.mdt_Activation &&
                                      VCCB_FLAG_ON == CFG->globalTraceInfo.signaling.mdt.mdtOnOff };

    // MDT shall set some flag to inform in E1/F1 setup to configure feature
    uint8_t jobToRelease = 0;
    bool traceAlreadyActivated = false;

    if (isMdtImmedRequested || isMdtLoggedRequested)
    {
        if (ERROR == VLIB_activateSigMdt(ptCi, isMdtImmedRequested, isMdtLoggedRequested, preStoredConfig, cellNum,
                         jobToRelease, result))
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, "[MDT][SIG]", "VLIB_activateSigMdt ERROR!\n");
            return ERROR;
        }
    }

    // [FGR-TA0101] Subscriber and Equipment Trace
    if (none == preStoredConfig->mdt.mdt_Activation ||
        immediate_trace == preStoredConfig->mdt.mdt_Activation)
    {
        VLIB_activateSigTrace(ptCi, isUeThrRequested, preStoredConfig, traceAlreadyActivated, jobToRelease, result);
    }

    if (0 == jobToRelease)
    {
        VCCB_PRINT_TRACE_INFORMATIVE(ptCi, "[TRACE/MDT][SIG]", "No session activated!\n");
        return GOOD;
    }

    {
        std::lock_guard<std::mutex> lock(gSigUeCntMtx);

        if (!traceAlreadyActivated) // if trace is working than counter already updated
        {
            ++pCfg->globalTraceInfo.signaling.totalSigUeCountCpc;

            if (jobToRelease & (trace_ctt | trace_uethr))
            {
                ++pCfg->globalTraceInfo.signaling.trace.traceUeCountCpc;
            }
        }

        if (jobToRelease & mdt_immediate)
        {
            ++pCell->signalingMdtUeCounters.immediateMdtUeCountCpc;
            ptCi->mdtIsPeriodicByA2Active = FALSE;
            ptCi->specificM1InstallOngoing = VCCB_FLAG_OFF;
        }

        if (jobToRelease & mdt_logged)
        {
            ++pCell->signalingMdtUeCounters.loggedMdtUeCountCpc;
        }
    }

    if (jobToRelease & (trace_uethr | mdt_immediate))
    {
        preStoredConfig->traceActivationStatus.E1delivered = false;
        preStoredConfig->traceActivationStatus.F1delivered = false;
    }

    // if signaling requested during attach/addition than management based feature are not started yet so deactivation not required
    if (!actInSetup)
    {
        VLIB_startSigMdtTrace(ptCi, preStoredConfig, cellNum, jobToRelease, status);
    }

    if (ERROR != status)
    {
        status = VIIL_sendTraceStatusVccbVtmb(ptCi, Trace_Signaling, cellNum);
        if (ERROR != status)
        {
            uint16_t traceRSR = static_cast<uint16_t>(preStoredConfig->traceRSR.data[0] << 8);
            traceRSR = static_cast<uint16_t>(traceRSR | preStoredConfig->traceRSR.data[1]);

            uint32_t traceId = static_cast<uint32_t>(preStoredConfig->traceReference.traceId.data[0] << 16);
            traceId |= static_cast<uint32_t>(preStoredConfig->traceReference.traceId.data[1] << 8);
            traceId |= preStoredConfig->traceReference.traceId.data[2];

            uint32_t mcc = preStoredConfig->traceReference.plmn.s2.mcc;
            uint32_t mnc = preStoredConfig->traceReference.plmn.s2.mnc;

            VCCB_PRINT_TRACE_INFORMATIVE(ptCi, "[TRACE/MDT][SIG]",
                    "Session started (trace:%u, uethr:%u, immed:%u, logg:%u) mcc:%x mnc:%x trId:%u trsr:%hu TRSnum:%hu\n", 
                    (ueTraceEnabledAndActive == preStoredConfig->trace.traceStatus),
                    (VCCB_FLAG_ON == preStoredConfig->trace.ueThroughputAndRfTraceFlag),
                    (mdtImmediate == preStoredConfig->mdt.mdtStatus),
                    (mdtLogged == preStoredConfig->mdt.mdtStatus),
                    mcc, mnc, traceId, traceRSR, CFG->globalTraceInfo.signaling.totalSigUeCountCpc);
            return GOOD;
        }
        VCCB_PRINT_TRACE_ERROR(ptCi, "[TRACE/MDT][SIG]", "VIIL_sendTraceStatusVccbVtmb (cellNum: %d) ERROR!\n", cellNum);
    }
            
    // ERROR cleanup
    {
        std::lock_guard<std::mutex> lock(gSigUeCntMtx);

        if (jobToRelease) // at least one singaling job requested
        {
            --pCfg->globalTraceInfo.signaling.totalSigUeCountCpc;
        }

        if (jobToRelease & (trace_ctt | trace_uethr))
        {
            --pCfg->globalTraceInfo.signaling.trace.traceUeCountCpc;
        }

        if (jobToRelease & mdt_immediate)
        {
            --pCell->signalingMdtUeCounters.immediateMdtUeCountCpc;
        }

        if (jobToRelease & mdt_logged)
        {
            --pCell->signalingMdtUeCounters.loggedMdtUeCountCpc;
        }
    }

    VCCB_PRINT_TRACE_ERROR(ptCi, "[TRACE/MDT][SIG]", "Not started due to other reason!\n");
    result = other_error;
    return ERROR;
}

int16_t buildNGRANTraceId(callInfo_type *ptCi, NGAP_NGRANTraceID &traceIdOut)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);

    makePLMN_type(&ptCi->signalingTraceInfo.traceReference.plmn, &traceIdOut);
    traceIdOut.value[3] = ptCi->signalingTraceInfo.traceReference.traceId.data[0];
    traceIdOut.value[4] = ptCi->signalingTraceInfo.traceReference.traceId.data[1];
    traceIdOut.value[5] = ptCi->signalingTraceInfo.traceReference.traceId.data[2];
    traceIdOut.value[6] = ptCi->signalingTraceInfo.traceRSR.data[0];
    traceIdOut.value[7] = ptCi->signalingTraceInfo.traceRSR.data[1];
    traceIdOut.length = 8;
    return GOOD;
}

static bool updateSigMdtTraceCntOnDeactivate(callInfo_type& rCi, VccbCellInfo_type& rCell, traceMdtStatus_type &sessionToDeactivate)
{
    bool needUpdate = false;
    std::lock_guard<std::mutex> lock(gSigUeCntMtx);

    if (sessionToDeactivate.immediate)
    {
        rCi.signalingTraceInfo.mdt.mdtStatus = mdtDisabled;
        if (0 != rCell.signalingMdtUeCounters.immediateMdtUeCountCpc)
        {
            --rCell.signalingMdtUeCounters.immediateMdtUeCountCpc;
        }
       needUpdate = true; 
    }
    
    if (sessionToDeactivate.logged)
    {
        rCi.signalingTraceInfo.mdt.mdtStatus = mdtDisabled;
        if (0 != rCell.signalingMdtUeCounters.loggedMdtUeCountCpc)
        {
            --rCell.signalingMdtUeCounters.loggedMdtUeCountCpc;
        }
       needUpdate = true; 
    }
    
    if (sessionToDeactivate.trace)
    {
        if (0 != CFG->globalTraceInfo.signaling.trace.traceUeCountCpc)
        {
            --CFG->globalTraceInfo.signaling.trace.traceUeCountCpc;
        }
       needUpdate = true; 
    }

    if (needUpdate)
    {
        if (0 != CFG->globalTraceInfo.signaling.totalSigUeCountCpc)
        {
            --CFG->globalTraceInfo.signaling.totalSigUeCountCpc;
        }
    }

    return needUpdate;
}

void deactivateSigMdtTrace(callInfo_type *ptCi, traceMdtStatus_type &sessionToDeactivate, bool isPutCi, uint16_t cellNum)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    uint16_t stopCellNum = cellNum == 0xFFFF ? ptCi->servCellNum : cellNum;
    VRRM_VALID_CHECK_CELL_RET_VOID(stopCellNum);
    VccbCellInfo_type *const pCell = &CELLINFO[stopCellNum];

    if (!sessionToDeactivate.immediate && !sessionToDeactivate.logged && 
        !sessionToDeactivate.trace && !sessionToDeactivate.uethr)
    {
        // nothing to deactivate
        return;
    }

    // Don't send DeactivateTrace if function is executed from VLIB_PutCi
    if ((sessionToDeactivate.immediate || sessionToDeactivate.uethr) && !isPutCi)
    {
        // Send E1/F1 Deactivate Trace message if already running
        if (ERROR == VLIB_sendDeactivateTrace(ptCi, Trace_Signaling, MAX_CELL_NUM_VCCB))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_sendDeactivateTrace ERROR!\n");
            // do not return -> will cause no counter decrementation!
        }
    }

    // Delete MDT M1 measurement on UE by RrcReconfiguration, skip if executed from VLIB_PutCi
    const bool isIntraGnbHo{IntraRatHO_cmd == ptCi->stateCmd && HO_TYPE_INTRA_NB == ptCi->hoInfo.hoType.nb};
    if (sessionToDeactivate.immediate &&
        TRUE == ptCi->signalingTraceInfo.mdt.config.immediate.measConfigFlags.m1Flag &&
        !isPutCi && !isIntraGnbHo && ptCi->stateCmd != RRCSuspend_cmd)
    {
        ptCi->signalingTraceInfo.mdt.config.immediate.m1Config.needUeConfig = FALSE;
        if (ERROR == VCCM_EnqueueActionMeasReconfig(ptCi, MeasReconfigPriorAction_Full))
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, "[TRACE/MDT][SIG]", "VCCM_EnqueueActionMeasReconfig(MeasReconfigPriorAction_Full) ERROR!\n");
        }
    }

    if (sessionToDeactivate.uethr)
    {
        ptCi->signalingTraceInfo.trace.ueThroughputAndRfTraceFlag = VCCB_FLAG_OFF;
    }
    
    if (sessionToDeactivate.trace)
    {
        ptCi->signalingTraceInfo.trace.ueThroughputAndRfTraceFlag = VCCB_FLAG_OFF;
        ptCi->signalingTraceInfo.trace.traceStatus = ueTraceDisabled;
    }

    bool needUpdate = updateSigMdtTraceCntOnDeactivate(*ptCi, *pCell, sessionToDeactivate);

    auto getTraceRSR = [](TRSR_type &rTraceRSR)
    {
        uint32_t traceRSR = 0;
        traceRSR |= static_cast<uint32_t>(rTraceRSR.data[0]) << 8;
        traceRSR |= static_cast<uint32_t>(rTraceRSR.data[1]);
        return (uint16_t)traceRSR;
    };

    auto getTraceId = [](TraceId_type &rTraceId)
    {
        uint32_t traceId = 0;
        traceId |= static_cast<uint32_t>(rTraceId.data[0]) << 16;
        traceId |= static_cast<uint32_t>(rTraceId.data[1]) << 8;
        traceId |= static_cast<uint32_t>(rTraceId.data[2]);
        return traceId;
    };

    const uint32_t mcc = ptCi->signalingTraceInfo.traceReference.plmn.s2.mcc;
    const uint32_t mnc = ptCi->signalingTraceInfo.traceReference.plmn.s2.mnc;

    uint16_t traceRSR = getTraceRSR(ptCi->signalingTraceInfo.traceRSR);
    uint32_t traceId = getTraceId(ptCi->signalingTraceInfo.traceReference.traceId);

    if (needUpdate)
    {
        if (ERROR == VIIL_sendTraceStatusVccbVtmb(ptCi, Trace_Signaling, stopCellNum))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_sendTraceStatusVccbVtmb ERROR!\n");
        }
    }

    VCCB_PRINT_TRACE_INFORMATIVE(ptCi, "[TRACE][SIG]",
            "Trace Recording Session Stop: mcc:%x mnc:%x trId:%u trsr:%hu TRSnum:%hu\n", 
            mcc, mnc, traceId, traceRSR, CFG->globalTraceInfo.signaling.totalSigUeCountCpc);

    if (!IS_NRDC_SN(ptCi) && stopTrigger_none != ptCi->dbTriggeredTraceDeactType)
    {
        ptCi->signalingTraceInfo.failureIndication.cause = not_activated;
        if (ERROR != buildNGRANTraceId(ptCi, ptCi->signalingTraceInfo.failureIndication.traceId))
        {
            if (ERROR == VLIB_handleSendTraceFailureIndication(ptCi, ENQUEUE_NO_ACTION))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_handleSendTraceFailureIndication ERROR!\n");
            }
        }
        else
        {
            ptCi->signalingTraceInfo.failureIndication.cause = no_error;
            VCCB_PRINT_TRACE_ERROR(ptCi, "[TRACE][SIG]", "buildNGRANTraceId ERROR!\n");
        }
    }
}

static void sendDuUpTraceStart(callInfo_type& rCi, bool sendE1, bool sendF1, uint16_t cellNum, enqueuedAction act)
{
    // No cellNum validation needed

    // send E1_TraceStart
    if (sendE1)
    {
        VCCB_PRINT_TRACE_COMMENT(&rCi, mdt_trace_all, "Sending E1 TraceStart\n");
        // [Multi UP] Support
        for (uint16_t servingUpIdx = 0; servingUpIdx < MAX_CU_UP_PER_CALL; ++servingUpIdx)
        {
            if (CI_use == rCi.endPointInfo.aupf[servingUpIdx].usage)
            {
                if (ERROR == FnVCCB_SendE1MessageWithCellNum(E1_TraceStart_id, &rCi, servingUpIdx, cellNum))
                {
                    if (Trace_Management == rCi.traceType)
                    {
                        VCCB_PRINT_TRACE_ERROR(&rCi, mdt_trace_all, 
                            "FnVCCB_SendE1AP_TraceStart (cellNum: %d)(servUpIdx: %d) ERROR!\n", cellNum, servingUpIdx);
                    }
                    else
                    {
                        VCCB_PRINT_TRACE_ERROR(&rCi, trace_ctt, 
                            "FnVCCB_SendE1AP_TraceStart (servUpIdx: %d) ERROR!\n", servingUpIdx);
                    }
                }
            }
            // Update traceType (sending E1TraceStart may be triggered by other procedure which overwritte type)
            rCi.traceType = ENQUEUE_ACTION_SEND_MGT_TRACE_START == act ? Trace_Management : Trace_Signaling;
        }
    }

    // send F1_TraceStart
    if (sendF1)
    {
        VCCB_PRINT_TRACE_COMMENT(&rCi, mdt_trace_all, "Sending F1 TraceStart\n");
        if (ERROR == VFIL_sendF1_TraceStart(&rCi, cellNum))
        {
            if (Trace_Management == rCi.traceType)
            {
                VCCB_PRINT_TRACE_ERROR(&rCi, mdt_trace_all, "VFIL_sendF1_TraceStart (cellNum: %d) ERROR!\n", cellNum);
            }
            else
            {
                VCCB_PRINT_TRACE_ERROR(&rCi, trace_ctt, "[SIG] VFIL_sendF1_TraceStart ERROR!\n");
            }
        }
        // Update traceType (sending F1TraceStart may be triggered by other procedure which overwritte type)
        if (ENQUEUE_ACTION_SEND_MGT_TRACE_START == act || ENQUEUE_ACTION_SEND_MGT_TRACE_START_F1_ONLY == act)
        {
            rCi.traceType = Trace_Management;
        }
        else
        {
            rCi.traceType = Trace_Signaling;
        }
    }
}

/**
 * @brief   [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 *          [FGR-TA0101] Subscriber and Equipment Trace
 *          [FGR-TA0104] UE Throughput and RF information Trace
 * @details Send E1/F1/XN Trace Start message
 * @param   [in] ptCi : pointer to Call Context
 * @param   [in] act  : enqueued action name
 * @return  int16_t GOOD/ERROR
 */
int16_t VLIB_handleSendTraceStart(callInfo_type *ptCi, enqueuedAction act)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    uint16_t cellNum = MAX_CELL_NUM_VCCB; // cellNum not set yet
    const bool isF1ResourceFlagOn{GET_F1_RESOURCE_FLAG(ptCi->flag.setupFlag)};
    const bool isE1ResourceFlagOn{GET_E1_RESOURCE_FLAG(ptCi->flag.setupFlag)};
    bool sendE1 = false;
    bool sendF1 = false;

    switch(act)
    {
        case ENQUEUE_ACTION_SEND_MGT_TRACE_START:
        case ENQUEUE_ACTION_SEND_MGT_TRACE_START_F1_ONLY:
        {
            cellNum = ptCi->servCellNum;
            VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

            TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, cellNum, false);

            if (nullptr == pRecordingSession)
            {
                VCCB_PRINT_TRACE_COMMENT(ptCi, trace_ctt, "Cannot get session for cellNum(%u) - TraceStart not sent\n", cellNum);
                return BREAK;
            }

            if (VCCB_FLAG_ON != pRecordingSession->jobStatus.immediateMdtFlag &&
                VCCB_FLAG_ON != pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag)
            {
                VCCB_PRINT_TRACE_COMMENT(ptCi, trace_uethr, "Job disabled - TraceStart not sent\n");
                return GOOD;
            }

            VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
            ManagementTraceSessionPerCell_type *pSession = &pCell->traceSession;
            VALID_E_POINT_CHECK_ERROR(pSession);

            if (FALSE == pSession->traceSessJobOnOff)
            {
                VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_trace_all, "Job disabled - TraceStart not sent\n");
                return GOOD;
            }

            ptCi->traceType = Trace_Management;

            // if only MDT activated check if DU notification required but if UETHR activated
            // than MDT state negligible
            if (VCCB_FLAG_ON == ptCi->managementTraceInfo.mdtInfo.mdtStatus.duActFlag || 
                VCCB_FLAG_ON == pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag)
            {
                sendF1 = true;
            }

            if (ENQUEUE_ACTION_SEND_MGT_TRACE_START == act)
            {
                if (VCCB_FLAG_ON == ptCi->managementTraceInfo.mdtInfo.mdtStatus.upActFlag ||
                    VCCB_FLAG_ON == pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag)
                {
                    sendE1 = true;
                }

                pRecordingSession->traceStartE1DeliveryStatus = sendE1 ? TRUE : FALSE;
            }

            pRecordingSession->traceStartF1DeliveryStatus = sendF1 ? TRUE : FALSE;
        }
        break;

        case ENQUEUE_ACTION_SEND_XN_TRACE_START:
        {
            if ( (ueTraceEnabledAndActive == ptCi->signalingTraceInfo.trace.traceStatus && 
                  CFG->globalTraceInfo.signaling.trace.nrdcSignalingTraceOnOff) || 
                 mdtImmediate == ptCi->signalingTraceInfo.mdt.mdtStatus)
            {
                enumTrace_type restoreType = ptCi->traceType;
                ptCi->traceType = Trace_Signaling;
                if (GOOD != FnVCCB_SendXNMessage(XN_TraceStart_id, ptCi, nullptr, nullptr))
                {
                    VCCB_PRINT_TRACE_ERROR(ptCi, "[TRACE/MDT][SIG]", "FnVCCB_SendXNMessage(XN_TraceStart) ERROR!\n");
                }
                ptCi->traceType = restoreType;
            }
            else
            {
                VCCB_PRINT_TRACE_COMMENT(ptCi, "[TRACE/MDT][SIG]", "[NRDC] TraceStart not sent to SN\n");
            }
        }
        break;

        case ENQUEUE_ACTION_SEND_SIG_TRACE_START:
        case ENQUEUE_ACTION_SEND_SIG_TRACE_START_F1_ONLY:
        {
            if (VCCB_FLAG_ON == ptCi->signalingTraceInfo.trace.ueThroughputAndRfTraceFlag ||
                mdtImmediate == ptCi->signalingTraceInfo.mdt.mdtStatus)
            {
                ptCi->traceType = Trace_Signaling;
                if (ENQUEUE_ACTION_SEND_SIG_TRACE_START_F1_ONLY == act)
                {
                    sendE1 = false;
                }
                else
                {
                    sendE1 = !(ptCi->signalingTraceInfo.traceActivationStatus.E1delivered);
                }
                sendF1 = !(ptCi->signalingTraceInfo.traceActivationStatus.F1delivered);
            }       
        }
        break;

        default:
            return GOOD;
    }

    // Postpone sending Trace Start until DU/UP context is available
    const bool shallF1TraceStartBePostponed {true == sendF1 && false == isF1ResourceFlagOn};
    const bool shallE1TraceStartBePostponed {true == sendE1 && false == isE1ResourceFlagOn};
    if (ENQUEUE_ACTION_SEND_MGT_TRACE_START == act && (shallF1TraceStartBePostponed || shallE1TraceStartBePostponed))
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_trace_all, "Trace Start Postponed. F1(%i) E1(%i)\n", shallF1TraceStartBePostponed, shallE1TraceStartBePostponed);
        ptCi->managementTraceInfo.traceActPostponed = VCCB_FLAG_ON;
        return GOOD;
    }

    sendDuUpTraceStart(*ptCi, sendE1, sendF1, cellNum, act);

    return GOOD;
}

/**
 * @brief   [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Send XN DeactivateTrace msg
 * @param   [in] ptCi : pointer to Call Context
 * @param   [in] act  : (not used) enqueued action name
 * @return  int16_t GOOD/ERROR
 */
int16_t VLIB_handleSendDeactivateTrace(callInfo_type *ptCi, enqueuedAction act)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (ENQUEUE_ACTION_SEND_XN_DEACTIVATE_TRACE == act)
    {
        if (GOOD == FnVCCB_SendXNMessage(XN_DeactivateTrace_id, ptCi, nullptr, nullptr))
        {
            ptCi->signalingTraceInfo.nrdcSnActivationSentFlag = VCCB_FLAG_OFF;
        }
        else
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "[SIG] FnVCCB_SendXNMessage(XN_DeactivateTrace_id) ERROR!\n");
        }
    }

    return GOOD;
}

/**
 * @brief   [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 *          [FGR-TA0104] UE Throughput and RF information Trace
 * @details Send NG/X2/XN CellTrafficTrace msg
 * @param   [in] ptCi : pointer to Call Context
 * @param   [in] act  : (not used) enqueued action name
 * @return  int16_t GOOD/ERROR
 */
int16_t VLIB_handleSendMgtCellTrafficTrace(callInfo_type *ptCi, enqueuedAction act)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    ManagementTraceSessionPerCell_type *pSession = &pCell->traceSession;
    VALID_E_POINT_CHECK_ERROR(pSession);

    int16_t status = GOOD;
    if (FALSE == pSession->traceSessJobOnOff)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_trace_all, "Trace Session disable - CellTrafficTrace not sent\n");
        return GOOD;
    }

    TraceRecordingSession_type *const pRecordingSession = getTraceSession(ptCi, ptCi->servCellNum, false);

    if (nullptr == pRecordingSession)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_trace_all, "Cannot get session for cellNum(%u) - CellTrafficTrace not sent\n", ptCi->servCellNum);
        return BREAK;
    }

    const bool isMdt{(VCCB_FLAG_ON == pRecordingSession->jobStatus.immediateMdtFlag ||
                      VCCB_FLAG_ON == pRecordingSession->jobStatus.rlfOrRcefFlag) &&
                      mdt_imei_tac == pSession->mdt.mdtSessionConfiguration.anonymizationLevel
                    };
    const bool isCellTrace{VCCB_FLAG_ON == pRecordingSession->jobStatus.cellTraceFlag};
    const bool isUeThr{VCCB_FLAG_ON == pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag};

    LocalTraceConfig_type localTraceInfo;
    localTraceInfo.mdtType = mdt_immediate;
    localTraceInfo.cellNum = ptCi->servCellNum;
    localTraceInfo.traceRSR = pRecordingSession->traceRecordingSessionReference;
    localTraceInfo.traceDepth = pSession->trace.traceDepth;
    localTraceInfo.traceReference = pSession->cellTraceReference;

    enumTrace_type restoreType = ptCi->traceType;
    ptCi->traceType = Trace_Management;

    if (isMdt && (isCellTrace || isUeThr))
    {
        const bool sameAddr{pSession->mdt.mdtSessionConfiguration.tceAddress == pSession->trace.tce1Address};
        if (!sameAddr)
        {
            if (ENQUEUE_NO_ACTION != act) // if action forced by CTT feature - skip
            {
                localTraceInfo.configTraceType = mdt_only;
                status = VLIB_sendCellTrafficTrace(ptCi, &localTraceInfo); // send CellTrafficTrace for mdtIp
                if (GOOD != status)
                {
                    ptCi->traceType = restoreType;
                    VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "VLIB_sendCellTrafficTrace ERROR!\n");
                    return BREAK;
                }
            }
            // if cttDelivered than skip
            if (FALSE == pRecordingSession->cttForTraceDelivered)
            {
                localTraceInfo.configTraceType = trace_only;
                status = VLIB_sendCellTrafficTrace(ptCi, &localTraceInfo); // send up to 2xCellTrafficTrace for tceIp1 and tceIp2
                if (GOOD != status)
                {
                    ptCi->traceType = restoreType;
                    VCCB_PRINT_TRACE_ERROR(ptCi, trace_uethr, "VLIB_sendCellTrafficTrace ERROR!\n");
                    return BREAK;
                }
                pRecordingSession->cttForTraceDelivered = TRUE;
            }
        }
        else
        {
            // if cttDelivered than skip
            if (FALSE == pRecordingSession->cttForTraceDelivered)
            {
                localTraceInfo.configTraceType = mdt_and_trace;
                status = VLIB_sendCellTrafficTrace(ptCi, &localTraceInfo); // send up to 2xCellTrafficTrace for tceIp1 and tceIp2
                if (GOOD != status)
                {
                    ptCi->traceType = restoreType;
                    VCCB_PRINT_TRACE_ERROR(ptCi, mdt_trace_all, "VLIB_sendCellTrafficTrace ERROR!\n");
                    return BREAK;
                }
                pRecordingSession->cttForTraceDelivered = TRUE;
            }
        }
    }
    else if (isMdt)
    {
        localTraceInfo.configTraceType = mdt_only;
        status = VLIB_sendCellTrafficTrace(ptCi, &localTraceInfo); // send CellTrafficTrace for mdtIp
        if (GOOD != status)
        {
            ptCi->traceType = restoreType;
            VCCB_PRINT_TRACE_ERROR(ptCi, mdt_immediate, "VLIB_sendCellTrafficTrace ERROR!\n");
            return BREAK;
        }
    }
    else if ( (isCellTrace || isUeThr) && FALSE == pRecordingSession->cttForTraceDelivered) // CellTrace or UeThr
    {
        localTraceInfo.configTraceType = trace_only;
        status = VLIB_sendCellTrafficTrace(ptCi, &localTraceInfo); // send up to 2xCellTrafficTrace for tceIp1 and tceIp2
        if (GOOD != status)
        {
            ptCi->traceType = restoreType;
            VCCB_PRINT_TRACE_ERROR(ptCi, trace_uethr, "VLIB_sendCellTrafficTrace ERROR!\n");
            return BREAK;
        }
        pRecordingSession->cttForTraceDelivered = TRUE;
    }
    else
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_trace_all, "CellTrafficTrace not sent\n");
    }

    ptCi->traceType = restoreType;
    return GOOD;
}

/**
 * @brief   [FGR-TA0101] Subscriber And Equipment Trace
 * @details Send NG TraceFailureIndication msg
 * @param   [in] ptCi : pointer to Call Context
 * @param   [in] act  : (not used) enqueued action name
 * @return  int16_t GOOD/ERROR
 */
int16_t VLIB_handleSendTraceFailureIndication(callInfo_type *ptCi, enqueuedAction)
{
    prepareSigTraceFailureIndication(ptCi);
    auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_TraceFailureIndicationAllAmf_id);
    VALID_E_POINT_CHECK_ERROR(ngapSender);
    if(GOOD != ngapSender->sendMsg())
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "sendMsg(NG_TraceFailureIndicationAllAmf) ERROR !!\n");
    }
    return GOOD;
}

/**
 * @brief   [FGR-TA0104] UE Throughput and RF information Trace
 *          [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Obtain previous DuUeId for F1 TraceDeactivation message
 * @param   [in] ptCi    : pointer to Call Context
 * @param   [in] cellNum : cell number in case of management MDT/UETHR, 0xFFFF otherwise
 * @param   [out] duUeId : reference for obtained ID
 */
int16_t VLIB_getDeactivateTraceDuUeId(callInfo_type *ptCi, uint32_t &duUeId, uint16_t cellNum)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    // no range check for cellNum required - only Management use this field

    if (Trace_Management == ptCi->traceType)
    {
        VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);
        TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, cellNum, false);
        if (nullptr == pRecordingSession)
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, trace_ctt, "Cannot get session for cellNum(%u)\n", cellNum);
            return ERROR;
        }
        duUeId = pRecordingSession->duUEid;
    }
    else if (Trace_Signaling == ptCi->traceType)
    {
        duUeId = ptCi->signalingTraceInfo.duUEid;
    }
    else
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, mdt_trace_all, "Invalid traceType(%u)\n", ptCi->traceType);
        return ERROR;
    }
    return GOOD;
}

int16_t VLIB_sendDeactivateTrace(callInfo_type *ptCi, enumTrace_type traceType, uint16_t cellNum)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    // no range check for cellNum required - only Management use this field

    bool sendE1 = false;
    bool sendF1 = false;

    enumTrace_type restoreType = ptCi->traceType;

    if (Trace_Signaling == traceType)
    {
        sendE1 = ptCi->signalingTraceInfo.traceActivationStatus.E1delivered;
        sendF1 = ptCi->signalingTraceInfo.traceActivationStatus.F1delivered;
    }
    else if (Trace_Management == traceType)
    {
        TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, cellNum, false);

        if (nullptr == pRecordingSession)
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, trace_ctt, "Cannot get session for cellNum(%u)\n", cellNum);
            return ERROR;
        }

        // Not need to send F1_DeactivateTrace to gNB-DU when Ue Context is released on DU,
        const bool isF1ResourceFlagOn{GET_F1_RESOURCE_FLAG(ptCi->flag.setupFlag)};
        const bool isContextReleasedDueInactivity{RRCSuspend_cmd == ptCi->stateCmd};
        const bool isIntraGnbInterDuRre{
            RrcReestablish_cmd == ptCi->stateCmd && RRE_TYPE_INTER_DU == ptCi->ueInfo.reestablishInfo.reestablishType};

        if ( (VCCB_FLAG_ON == ptCi->managementTraceInfo.mdtInfo.mdtStatus.duActFlag ||
              VCCB_FLAG_ON == pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag) &&
              TRUE == pRecordingSession->traceStartF1DeliveryStatus &&
              true == isF1ResourceFlagOn && false == isContextReleasedDueInactivity &&
              false == isIntraGnbInterDuRre)
        {
            sendF1 = true;
        }

        // E1_DeactivateTrace for gNB-CU-UP, DeactivateTrace won't be send when call is released
        const bool isE1ResourceFlagOn{GET_E1_RESOURCE_FLAG(ptCi->flag.setupFlag)};
        if ( (VCCB_FLAG_ON == ptCi->managementTraceInfo.mdtInfo.mdtStatus.upActFlag ||
              VCCB_FLAG_ON == pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag) &&
              TRUE == pRecordingSession->traceStartE1DeliveryStatus &&
              true == isE1ResourceFlagOn)
        {
            sendE1 = true;
        }
        
        // if TraceStart msg not sent skip sending DeactivateTrace
        if (false == sendE1 && false == sendF1)
        {
            return GOOD;
        }

        pRecordingSession->traceStartE1DeliveryStatus = sendE1 ? FALSE : TRUE;
        pRecordingSession->traceStartF1DeliveryStatus = sendF1 ? FALSE : TRUE;
    }
    else
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_sendDeactivateTrace invalid trace type (%d) ERROR!\n", traceType);
        return ERROR;
    }

    // Update traceType according to pending procedure type
    ptCi->traceType = traceType;

    if(sendF1)
    {
        if (ERROR == VFIL_sendF1_DeactivateTrace(ptCi, cellNum))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_sendF1_DeactivateTrace (cellNum: %d) ERROR!\n", cellNum);
        }
    }

    if(sendE1)
    {
        // [Multi UP] Support
        for (uint16_t servingUpIdx = 0; servingUpIdx < MAX_CU_UP_PER_CALL; ++servingUpIdx)
        {
            if (CI_use == ptCi->endPointInfo.aupf[servingUpIdx].usage)
            {
                if (ERROR == FnVCCB_SendE1MessageWithCellNum(E1_DeactivateTrace_id, ptCi, servingUpIdx, cellNum))
                {
                    VCCB_PRINT_CALL_ERROR(ptCi,
                        "FnVCCB_SendE1AP_DeactivateTrace (cellNum: %d) (servUpIdx: %d) ERROR!\n", cellNum,
                        servingUpIdx);
                }
            }
        }
    }

    // Restore traceType according to pending procedure type
    ptCi->traceType = restoreType;

    return GOOD;
}

/**
 * @brief   [FGR-TA0104] UE Throughput and RF information Trace
 *          [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Send F1 Trace Start/Deactivate message - for 
 *          management trace only apply for Intra Cell RRE!
 * @param   [in] ptCi      : pointer to Call Context
 * @param   [in] notiType  : management or signaling
 * @return  int16_t GOOD/ERROR
 */
int16_t VLIB_sendTraceDuStopStartNoti(callInfo_type *ptCi, enumTrace_type notiType)
{
    ////////////////////////////////////////////////////////////////////////////
    // Only in this particular method do not manipulate any ON/OFF flags
    // DU need duplicated start/deactivate message in case on IntraDU mobility
    // so this method does not modify any flags
    ////////////////////////////////////////////////////////////////////////////

    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    int16_t status = GOOD;

    if ( Trace_Signaling == notiType &&
         (VCCB_FLAG_ON == ptCi->signalingTraceInfo.trace.ueThroughputAndRfTraceFlag ||
          mdtImmediate == ptCi->signalingTraceInfo.mdt.mdtStatus))
    {
        enumTrace_type restoreTraceType = ptCi->traceType;
        ptCi->traceType = Trace_Signaling;
        status = VFIL_sendF1_DeactivateTrace(ptCi, 0xFFFF);
        ptCi->traceType = restoreTraceType;
        if (ERROR == status)
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, trace_uethr, "[SIG] VFIL_sendF1_DeactivateTrace ERROR!\n");
            return ERROR;
        }
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_uethr, "[SIG] F1_DeactivateTrace sent\n");
        
        const bool isIntraGnbHo{IntraRatHO_cmd == ptCi->stateCmd && HO_TYPE_INTRA_NB == ptCi->hoInfo.hoType.nb};
        if (isIntraGnbHo && HO_TYPE_INTER_DU == ptCi->hoInfo.hoType.du)
        {
            return GOOD;
        }
        VCCB_PRINT_TRACE_COMMENT(ptCi, trace_uethr, "[SIG] F1_TraceStart queued\n");
        // queue Trace Start message
        status = VCCM_enqueueActionWithForce(ptCi, ENQUEUE_ACTION_SEND_SIG_TRACE_START_F1_ONLY, true);
        if (ERROR == status)
        {
            VCCB_PRINT_TRACE_ERROR(ptCi, trace_uethr, "[SIG] VCCM_enqueueActionWithForce(ENQUEUE_ACTION_SEND_SIG_TRACE_START_F1_ONLY) ERROR\n");
            return ERROR;
        }
        return GOOD;
    }


    if (Trace_Management == notiType)
    {
        TraceRecordingSession_type *pRecordingSession = getTraceSession(ptCi, ptCi->servCellNum, false);

        if (nullptr != pRecordingSession &&
            (VCCB_FLAG_ON == pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag ||
             VCCB_FLAG_ON == pRecordingSession->jobStatus.immediateMdtFlag))
        {
            enumTrace_type restoreTraceType = ptCi->traceType;
            ptCi->traceType = Trace_Management;
            status = VFIL_sendF1_DeactivateTrace(ptCi, ptCi->servCellNum);
            ptCi->traceType = restoreTraceType;
            if (ERROR == status)
            {
                VCCB_PRINT_TRACE_ERROR(ptCi, mdt_trace_all, "VFIL_sendF1_DeactivateTrace ERROR!\n");
                return ERROR;
            }
            VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_trace_all, "F1_DeactivateTrace sent\n");

            VCCB_PRINT_TRACE_COMMENT(ptCi, mdt_trace_all, "F1_TraceStart queued\n");
            // queue Trace Start message
            status = VCCM_enqueueActionWithForce(ptCi, ENQUEUE_ACTION_SEND_MGT_TRACE_START_F1_ONLY, false);
            if (ERROR == status)
            {
                VCCB_PRINT_TRACE_ERROR(ptCi, mdt_trace_all, "VCCM_enqueueAction(ENQUEUE_ACTION_SEND_MGT_TRACE_START_F1_ONLY) ERROR\n");
                return ERROR;
            }
            return GOOD;
        }
    }

    return GOOD;
}

void sigMdtUethrIntraGnbReactivation(callInfo_type *ptCi, uint16_t srcCellNum, uint16_t tgtCellNum)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    bool uethrState = (VCCB_FLAG_ON == ptCi->signalingTraceInfo.trace.ueThroughputAndRfTraceFlag);
    bool prevMdtState = (mdtImmediate == ptCi->signalingTraceInfo.mdt.mdtStatus);

   if (E_CALLTYPE_NSA != ptCi->callType)
   {
       // if not yet deactivated than proceed
       if (mdtLogged == ptCi->signalingTraceInfo.mdt.mdtStatus)
       {
           // during mobility without putCi just cleanup srcCell counter for logged
           traceMdtStatus_type sessionToDeactivate = {
               .immediate = false,
               .logged = true,
               .uethr = false, 
               .trace = false
           };
           deactivateSigMdtTrace(ptCi, sessionToDeactivate, false, srcCellNum);
           return;
       }
       // skip logged MDT reactivation if already deactivated
       if (logged == ptCi->signalingTraceInfo.mdt.mdt_Activation)
       {
           return;
       }
   }

    if (srcCellNum == tgtCellNum) // intraCell
    {
        // UETHR and MDT state did not change than if necessary send only DU stat/stop notification
        int16_t status = VLIB_sendTraceDuStopStartNoti(ptCi, Trace_Signaling);
        VCCB_PRINT_WITHOUT_RETURN_ON_CALL_ERROR(ptCi, status, "[UETHR/MDT][SIG] VLIB_sendTraceDuStopStartNoti error\n");
        return;
    }
    else  // interCell
    {
        if (STATE_RRE_RreCmpl == ptCi->state && 
            RRE_TYPE_INTER_DU == ptCi->ueInfo.reestablishInfo.reestablishType)
        {
            // suppress sending F1_DeactivateTrace 
            ptCi->signalingTraceInfo.traceActivationStatus.F1delivered = false;
        }

        // need full feature deactivation and activation 
        traceMdtStatus_type sessionToDeactivate = {
            .immediate = prevMdtState,
            .logged = false,
            .uethr = uethrState, 
            .trace = false
        };

        deactivateSigMdtTrace(ptCi, sessionToDeactivate, false, srcCellNum);

        enumSigActFailResult result;
        SignalingTrace_type oldConfig;
        oldConfig.mdt.mdtStatus = mdtDisabled;
        oldConfig.trace.traceStatus = ueTraceDisabled;
        if (ERROR == VLIB_activateSigMdtTrace(ptCi, result, &oldConfig, false, tgtCellNum))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_activateSigMdtTrace error\n");
        }
        return;
    }
}

void VLIB_updateGlobalMgtCounters(void)
{
    VccbCellInfo_type *pCell = nullptr; 
    ManagementTraceSessionPerCell_type *pSession = nullptr; 

    uint32_t totalTraceCnt = 0;
    uint32_t totalMgtSessionUeCnt = 0;
    VccbCfgInfo_type *const pCfg = CFG;

    for (uint16_t cellNum = 0; cellNum < MAX_CELL_NUM_VCCB; ++cellNum)
    {
        pCell = &CELLINFO[cellNum];

        if (EQUIP != pCell->status)
        {
            continue;
        }

        pSession = &pCell->traceSession;

        // Check if Trace Session is enabled
        if (pSession->traceSessJobOnOff == 0)
        {
            continue;
        }

        totalMgtSessionUeCnt += pSession->allocatedTRSRCount;

        if (pSession->managementJobType.trace != 0)
        {
            totalTraceCnt += pSession->trace.cellTraceUeCountCpc;
        }
    }

    pCfg->globalTraceInfo.management.cellTraceUeCountCpc = totalTraceCnt;
    pCfg->globalTraceInfo.management.totalMgtUeCountCpc = totalMgtSessionUeCnt;
}

/**
 * @brief   [FGR-TA0103] Cell Traffc Trace
 *          [FGR-TA0104] UE Throughput and RF information Trace
 *          [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
 * @details Perform audit on serving cell during call release
 *          (remove zombie trace entries - to be called in PutCi)
 * @param   [in] ptCi       : pointer to Call Context
 */
void VLIB_TraceAudit(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint16_t cellNum = ptCi->servCellNum;
    VRRM_VALID_CHECK_CELL_RET_VOID(cellNum);
    VccbCfgInfo_type *const pCfg = CFG;
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    ManagementTraceSessionPerCell_type *pSession = &pCell->traceSession;

    if (FALSE == pSession->traceSessJobOnOff)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, "[TRACE][AUDIT]", "Trace session disabled, no audit required\n");
        return;
    }

    long diffTime = VLIB_getTickDifference(pSession->lastAuditTime);
    long auditInterval = static_cast<long>(CFG->globalTraceInfo.management.auditTimer)*60*1000; // milisecs to secs
    uint16_t diffTimeMins = static_cast<uint16_t>(diffTime/60000);

    if (0 == auditInterval || diffTime < auditInterval)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, "[TRACE][AUDIT]", "Audit disabled (%u) or audit timeout not elapsed (last audit %u mins ago)\n",
                (auditInterval!=0), diffTimeMins);
        return;
    }

    // no thread safe, however not impacting
    pSession->lastAuditTime = tickGetMono();

    VCCB_PRINT_TRACE_COMMENT(ptCi, "[TRACE][AUDIT]", "Started for cellNum(%d), last audit %u mins ago\n", cellNum, diffTimeMins);

    uint16_t allocatedCount = pSession->allocatedTRSRCount;
    uint16_t preAuditTraceCnt = pSession->trace.cellTraceUeCountCpc;

    struct {
        uint16_t logged=0;
        uint16_t immediate=0;
        uint16_t trace=0;
        uint16_t total=0;
    } activeCnt{}, zombieCnt{};

    for (uint16_t idx=0; idx<MAX_UE_PER_CELL_TRACE_SESSION && allocatedCount; ++idx)
    {
        uint32_t callId = pSession->cellTRSR[idx];
        if (callId >= MAX_CALL_NUM_VCCB)
        {
            continue;
        }

        // prevent validation whole table if reached allocated count
        --allocatedCount;

        callInfo_type *ptAuditCi = FnVCCB_GetCallInUse(callId);

        // if call exists and is located in audited cell than check if TRSR matches - otherwise might be zombie
        if (NULL != ptAuditCi)

        {
            // if call exists and is located in audited cell than check if TRSR matches - otherwise might be zombie
            if (ptAuditCi->servCellNum == cellNum)

            {
                TraceRecordingSession_type *pRecordingSession = getTraceSession(ptAuditCi, cellNum, false);

                if (nullptr != pRecordingSession)

                {
                    // expected TRSR for call
                    uint16_t expectedTrsr =
                        static_cast<uint16_t>(GET_REDUNDANT_CPC_ID * MAX_UE_PER_CELL_TRACE_SESSION + idx);
                    if (expectedTrsr == pRecordingSession->traceRecordingSessionReference)
                    {
                        ++(activeCnt.total);

                        if (VCCB_FLAG_ON == pRecordingSession->jobStatus.immediateMdtFlag)
                        {
                            ++(activeCnt.immediate);
                        }

                        if (VCCB_FLAG_ON == pRecordingSession->jobStatus.loggedMdtFlag)
                        {
                            ++(activeCnt.logged);
                        }

                        if ((VCCB_FLAG_ON == pRecordingSession->jobStatus.cellTraceFlag) ||
                            (VCCB_FLAG_ON == pRecordingSession->jobStatus.ueThroughputAndRfTraceFlag))
                        {
                            ++(activeCnt.trace);
                        }
                        continue;
                    }
                }
            }
            else
            {
                // Potential TRSR leak
                FnVCCB_RequestLogFishing(ptAuditCi, LOG_FISHING_MANUAL_EVENT_ID_TRACE_TRSR_LEAK);
            }
        }

        // remove entry - audited entry cannot be used elsewhere so no mutex required
        pSession->cellTRSR[idx] = UNKNOWN_VCCB_CALLID;
    }

    {
        std::lock_guard<std::mutex> lock(gTrsrAllocMtx);

        zombieCnt.immediate = static_cast<uint16_t>(pSession->mdt.immediateMdtUeCountCpc - activeCnt.immediate);
        pSession->mdt.immediateMdtUeCountCpc = activeCnt.immediate;

        zombieCnt.logged = static_cast<uint16_t>(pSession->mdt.loggedMdtUeCountCpc - activeCnt.logged);
        pSession->mdt.loggedMdtUeCountCpc = activeCnt.logged;

        zombieCnt.trace = static_cast<uint16_t>(pSession->trace.cellTraceUeCountCpc - activeCnt.trace);
        if (preAuditTraceCnt != activeCnt.trace &&
        pSession->trace.cellTraceUeCountCpc != activeCnt.trace)
        {
            pSession->trace.cellTraceUeCountCpc = activeCnt.trace;
        }
        
        zombieCnt.total = static_cast<uint16_t>(pSession->allocatedTRSRCount - activeCnt.total);
        pSession->allocatedTRSRCount = activeCnt.total;

        // global ACPF counter update
        if (zombieCnt.trace || zombieCnt.total)
        {
            VLIB_updateGlobalMgtCounters();

            struct timespec ts;
            timespec_get(&ts, TIME_UTC);
            struct GlobalTraceInfo_type::management_s::traceAuditHist_s *histPtr = &pCfg->globalTraceInfo.management.traceAuditHist;
            if (histPtr->head >= TRACE_AUDIT_HIST_SIZE)
            {
                histPtr->head = 0;
            }
            histPtr->entry[histPtr->head++] = {.tv_sec=ts.tv_sec, .rmCnt=zombieCnt.trace, .cellNum=cellNum};
        }
    }

    VCCB_PRINT_TRACE_COMMENT(ptCi, "[TRACE][AUDIT]", "Zombie entries imm(%u):logg(%u):trace(%u):total(%u) for cellNum(%d) removed\n",
            zombieCnt.immediate, zombieCnt.logged, zombieCnt.trace, zombieCnt.total, cellNum);

    // send VTMB notification with new counters value
    if (ERROR == VIIL_sendTraceStatusVccbVtmb(ptCi, Trace_Management, cellNum))
    {
        VCCB_PRINT_TRACE_ERROR(ptCi, "[TRACE][AUDIT]", "VIIL_sendTraceStatusVccbVtmb (cellNum: %d) ERROR!\n", cellNum);
        return;
    }

    VCCB_PRINT_TRACE_COMMENT(ptCi, "[TRACE][AUDIT]", "Status cNum:cId:trId(%u:%u:%u) TrsrCnt:%u(trace:%u imm:%u logg:%u) allocIdx:%u\n",
            cellNum, pCell->cellIdentity, pSession->cellTraceReference.traceId, pSession->allocatedTRSRCount,
            pSession->trace.cellTraceUeCountCpc, pSession->mdt.immediateMdtUeCountCpc,
            pSession->mdt.loggedMdtUeCountCpc, pSession->cellTrsrAllocIdx);
}

int16_t VLIB_getTceIpFromFqdn(const char* fqdn, MdsIp_Type *const tceIpFromFqdn)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(fqdn);
    VALID_E_POINT_CHECK_ERROR(tceIpFromFqdn);

    VccbCfgInfo_type *const pCfg = CFG;
    PredefinedTceServers_type *servers = pCfg->globalTraceInfo.predefinedTceServers;

    for (int tceId = 0; tceId < TCE_MAX_NUMBER; ++tceId)
    {
        if (strncmp(fqdn, servers[tceId].server.fqdn, strlen(fqdn)) == 0)
        {
            *tceIpFromFqdn = servers[tceId].tceIpFromFqdn;
            return GOOD;
        }
    }

    return ERROR;
}

bool VLIB_checkTraceRfspSpidAllowed(callInfo_type *ptCi, int32_t msgId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // skip validation if filtering disabled
    if (FALSE == CFG->globalTraceInfo.management.rfspSpidFiltering.filteringOnOff)
    {
        // RFSP received but filtering off -> prevent toggling activation for pending call
        if (OPT_PRESENT == ptCi->ueInfo.rfsp.rfspPresent &&
            traceRfspSpidUnknown != ptCi->managementTraceInfo.traceRfspSpidAllowed)
        {
            ptCi->managementTraceInfo.traceRfspSpidAllowed = traceRfspSpidNotAllowed;
        }

        VCCB_PRINT_TRACE_COMMENT(ptCi, "[TRACE][RFSP]", "Filtering off\n");
        return true;
    }

    if (traceRfspSpidAllowed == ptCi->managementTraceInfo.traceRfspSpidAllowed)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, "[TRACE][RFSP]", "traceRfspSpidAllowed ALLOWED\n");
        return true;
    }
    
    if (traceRfspSpidNotAllowed == ptCi->managementTraceInfo.traceRfspSpidAllowed)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, "[TRACE][RFSP]", "traceRfspSpidAllowed NOT ALLOWED\n");
        return false;
    }

    bool beforeInitialCtx = (ptCi->stateCmd == RRCConnection_cmd) && (ptCi->state == STATE_Est);

    // if not yet allowed do not allow anymore (below messages represents pending call)
    if ((msgId == XN_SNodeModificationRequest_id) ||
        (msgId == NG_UEContextModificationRequestAmfAll_id) ||
        //start the Trace if rfsp is received before NG_InitialContextSetupRequestAmfAll
        (msgId == NG_DownlinkNASTransportAmfAll_id && beforeInitialCtx == false) ||
        (msgId == X2_SgNBModificationRequest_id))
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, "[TRACE][RFSP]", "Modification of rfsp, not allowed (msgId: %d)\n", msgId);
        ptCi->managementTraceInfo.traceRfspSpidAllowed = traceRfspSpidNotAllowed;
        return false;
    }

    if (OPT_PRESENT != ptCi->ueInfo.rfsp.rfspPresent)
    {
        VCCB_PRINT_TRACE_COMMENT(ptCi, "[TRACE][RFSP]", "Filtering on but no rfspPresent\n");
        return false;
    }

    RfspSpidIndex_type *container = CFG->globalTraceInfo.management.rfspSpidFiltering.rfsps;

    // rfsp/spid set so validate with list
    if (E_CALLTYPE_NSA == ptCi->callType)
    {
        container = CFG->globalTraceInfo.management.rfspSpidFiltering.spids;
    }

    for (uint8_t index = 0; index < TRACE_RFSP_SPID_FILTERING_SIZE; ++index)
    {
        if (N_EQUIP == container[index].usage) {continue;}

        VCCB_PRINT_TRACE_COMMENT(ptCi, "[TRACE][RFSP]", "RFSP(idx): %d(%d)\n", container[index].index, index);

        if (container[index].index == ptCi->ueInfo.rfsp.indexToRFSP)
        {
            ptCi->managementTraceInfo.traceRfspSpidAllowed = traceRfspSpidAllowed;
            return true;
        }
    }

    ptCi->managementTraceInfo.traceRfspSpidAllowed = traceRfspSpidNotAllowed;

    return false;
}

