/****************************************************************
 * System      : 5G vNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatVoma.cpp
 * Description : This file contains functions related to VoNR 
 *               monitoring support for VoMA
 * Dept.       : 5G Call SW Lab.
 * Created     : 2025.07.28
 ****************************************************************/

#include <iostream>
#include <chrono>
#include <iomanip>
#include <sstream>
#include <cstring>
#include <ctime>

#include "FeatCommon.h"
#include "FeatLtmHo.h"
#include "ComInclude.h"
#include "ComLibUtility.h"

static void makeInitTime(uint8_t *pTime)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pTime);

    auto now = std::chrono::system_clock::now();
    auto now_ms = std::chrono::time_point_cast<std::chrono::milliseconds>(now);
    auto epoch_ms = now_ms.time_since_epoch();
    auto millis = epoch_ms.count();
    std::time_t now_time = std::chrono::duration_cast<std::chrono::seconds>(epoch_ms).count();
    std::tm localTime = {};
    localtime_r(&now_time, &localTime); // Use localtime_r instead of localtime
    std::stringstream ss;

    ss << std::put_time(&localTime, "%Y%m%d%H%M%S");
    ss << std::setw(3) << std::setfill('0') << (millis % 1000);
    memcpy(pTime, ss.str().data(), MIN(ss.str().size(), VOMA_INIT_TIME_LEN));

    VCCB_PRINTF("[VOMA] makeInitTime: %.17s\n", pTime);
}

static bool VerifyStartupCondition(callInfo_type& rCi)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_VALID_GNBNUM_ERROR(rCi.gnbNum);
    VCCB_CHECK_VALID_CELLNUM_ERROR(rCi.servCellNum);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[rCi.gnbNum];
    const VccbCellInfo_type *const pCell = &CELLINFO[rCi.servCellNum];

    // check onOff
    if (VCCB_FLAG_ON != pGnb->vomaConfiguration.onOff)
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "[VoMA] Feature disabled\n");
        return false;
    }

    // check if LTM on gNB and indicated by UE capa
    if (0 != FnVCCB_GetMaxNumOfLtmCellFromYang(rCi) &&
        VCCB_FLAG_ON == pCell->mobilityConfig.ltmAllowance &&
        FnVCCB_CheckLtmUeCapability(rCi, rCi.servCellBand))
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "[VoMA] gNB and UE capa indicate support LTM - disabled\n");
        return false;
    }

    // check PLMN list
    if (pGnb->vomaConfiguration.plmnStatuses)
    {
        bool plmnValidated = false;
        for (uint16_t idx=0; idx<MAX_NUM_VOMA_PLMNS; ++idx)
        {
            if (!(pGnb->vomaConfiguration.plmnStatuses & 1UL<<idx))
            {
                continue;
            }

            if(pGnb->vomaConfiguration.allowedPlmnList[idx].longId == rCi.ueInfo.servedPlmn.longId)
            {
                plmnValidated = true;
                break;
            }
        }

        if (!plmnValidated)
        {
            VCCB_PRINT_CALL_COMMENT(&rCi, "[VoMA] PLMN not allowed\n");
            return false;
        }
    }

    // check 5qi
    if (FALSE == FnVCCB_IsVoNRCall(&rCi))
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "[VoMA] Not started - 5Qi!=1\n");
        return false;
    }

    return true;
}

int16_t VLIB_VomaActivate(callInfo_type& rCi, vomaCallEvent_type event)
{
    // 26A - no NSA support
    if (E_CALLTYPE_NSA == rCi.callType) 
    {
        return GOOD;
    }

    // already checked
    if (rCi.vomaInfo.vomaAllowed)
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "[VoMA] Already started\n");
        return GOOD;
    }

    if (!VerifyStartupCondition(rCi))
    {
        return ERROR;
    }

    rCi.vomaInfo.vomaAllowed = true;
    rCi.vomaInfo.includeCallInfo = false;
    rCi.vomaInfo.isHO = false;
    rCi.vomaInfo.vomaEvent = event;

    makeInitTime(rCi.vomaInfo.initTime);

    return GOOD;
}

bool VLIB_VomaCheckDrb5QISupport(callInfo_type& rCi, uint8_t drbIdx)
{
    VCCB_CHECK_E_RANGE_AND_VAL(drbIdx, MAX_DRB_PER_SA_CALL, false);

    callDRBInfo_type &drb = rCi.drb[drbIdx];
    if (CI_use != drb.usage) 
    {
        return false;
    }

    // Get selected 5Qi
    uint16_t qosIdxInCall = drb.drbQosIdxInCall;
    VCCB_CHECK_E_RANGE_AND_RETURN(qosIdxInCall, MAX_QOS_FLOW_PER_CALL);

    uint8_t selected5Qi = (uint8_t)MAX_5QI_VALUE;

    if (CI_use != rCi.qosFlow[qosIdxInCall].usage)
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "[VoMA] NO qosFlow (qosIdxInCall: %d)\n",qosIdxInCall);
        return false;
    }

    VLIB_getFiveQi(&rCi.qosFlow[qosIdxInCall], &selected5Qi);

    if (VONR_5QI == selected5Qi)
    {
        return true;
    }

    VCCB_PRINT_CALL_COMMENT(&rCi, "[VoMA] NO VONR_5QI (selected5qi:%d)\n",selected5Qi);
    return false;
}

void VLIB_VomaPrepareIntraGnb(callInfo_type& rCi, vomaCallEvent_type callEvent, bool isIntraCellRRE=false)
{
    rCi.vomaInfo.vomaEvent = callEvent;

    if (!isIntraCellRRE)
    {
        makeInitTime(rCi.vomaInfo.initTime);
    }

    callDRBInfo_type *ptDi = nullptr;
    for(uint8_t idx=0; idx<MAX_DRB_PER_SA_CALL; ++idx)
    {
        if (false == VLIB_VomaCheckDrb5QISupport(rCi, idx))
        {
            continue;
        }

        ptDi = &rCi.drb[idx];
        if (VOMA_STARTED == ptDi->vomaStatus.upStatus)
        {
            ptDi->vomaStatus.upStatus = isIntraCellRRE ? VOMA_STARTED : VOMA_PREPARATION; // PATLAS

            // in intraGnb HO/RRE E1 preparation phase is skipped by start phase, but in interDU HO 
            // start shall be delayed (send after HO processing phase)
            if (VOMA_interDuHo == callEvent)
            {
                rCi.vomaInfo.delayE1start = true;
            }
            ptDi->vomaStatus.duStatus = VOMA_UNKNOWN;
        }
    }
}
