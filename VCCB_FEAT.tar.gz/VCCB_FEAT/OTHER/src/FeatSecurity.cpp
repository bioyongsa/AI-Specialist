/**
 * @file        VlibSecurityUtil.c
 * @brief       functions for security utility
 */

#include "FeatSecurity.h"

#include "CdbDalNotification.h"

#include "ComGlobalData.h"
#include "ComLibIpcApi.h"
#include "ComAutoNtrace.hpp"
#include "StateCommon.h"

#include "compat_glibc.h"
#include "nrrrcPack.h"
#include "access_common_yang.h"
#include "cipher.h"

/**
 * @brief     Derive key for DRB encryption
 * @param     ptCi : call context
 * @param     outputKey : output key
 * @param     isSecCtxModProc : Security Context Modification Procedure is OnGoing
 * @return    void
 */
void VLIB_DeriveKeyUpEncryption(callInfo_type *ptCi, uint8_t *outputKey, uint8_t isSecCtxModProc)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(outputKey);

    // inputS[0] = 0x69; // FC (1 Byte)
    // inputS[1] = 0x05; // P0 (Algorithm Type Distinguisher : 1 Byte)
    // inputS[2] = 0x00; // L0 (2 Byte)
    // inputS[3] = 0x01; // L0 (2 Byte)
    // inputS[4] = TBD;  // P1 (Algorithm Identifier : 1 Byte)
    // inputS[5] = 0x00; // L1 (2 Byte)
    // inputS[6] = 0x01; // L1 (2 Byte)

    uint8_t dKey[KEY_ENB_LENGTH];
    uint8_t inputS[KEY_ENB_LENGTH] = {0x69, 0x05, 0x00, 0x01, 0x00, 0x00, 0x01};
    uint32_t iLen = 7;

    if (isSecCtxModProc)
    {
        inputS[4] = ptCi->security.newPdcpCtx.securityInfo.cipherAlgo & 0x0F;
    }
    else
    {
        inputS[4] = ptCi->security.pdcpCtx.securityInfo.cipherAlgo & 0x0F;
    }

    fnKDF_HMAC_SHA_256(ptCi->security.sKgNB, KEY_ENB_LENGTH, inputS, iLen, dKey, KEY_ENB_LENGTH);
    memcpy(outputKey, &dKey[KEY_INT_CIP_LENGTH], KEY_INT_CIP_LENGTH);

    return;
}

/**
 * @brief     Derive key for DRB integrity
 * @param     ptCi : call context
 * @param     outputKey : output key
 * @param     isSecCtxModProc : Security Context Modification Procedure is OnGoing
 * @return    void
 */
void VLIB_DeriveKeyUpIntegrity(callInfo_type *ptCi, uint8_t *outputKey, uint8_t isSecCtxModProc)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(outputKey);

    // inputS[0] = 0x69; // FC (1 Byte)
    // inputS[1] = 0x06; // P0 (Algorithm Type Distinguisher : 1 Byte)
    // inputS[2] = 0x00; // L0 (2 Byte)
    // inputS[3] = 0x01; // L0 (2 Byte)
    // inputS[4] = TBD;  // P1 (Algorithm Identifier : 1 Byte)
    // inputS[5] = 0x00; // L1 (2 Byte)
    // inputS[6] = 0x01; // L1 (2 Byte)

    uint8_t dKey[KEY_ENB_LENGTH];
    uint8_t inputS[KEY_ENB_LENGTH] = {0x69, 0x06, 0x00, 0x01, 0x00, 0x00, 0x01};
    uint32_t iLen = 7;

    if (isSecCtxModProc)
    {
        inputS[4] = ptCi->security.newPdcpCtx.securityInfo.integrityAlgo & 0x0F;
    }
    else
    {
        inputS[4] = ptCi->security.pdcpCtx.securityInfo.integrityAlgo & 0x0F;
    }

    fnKDF_HMAC_SHA_256(ptCi->security.sKgNB, KEY_ENB_LENGTH, inputS, iLen, dKey, KEY_ENB_LENGTH);
    memcpy(outputKey, &dKey[KEY_INT_CIP_LENGTH], KEY_INT_CIP_LENGTH);

    return;
}

/**
 * @brief     Derive key for SRB encryption
 * @param     ptCi : call context
 * @param     outputKey : output key
 * @param     isSecCtxModProc : Security Context Modification Procedure is OnGoing
 * @return    void
 */
void VLIB_DeriveKeyRrcEncryption(callInfo_type *ptCi, uint8_t *outputKey, uint8_t isSecCtxModProc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(outputKey);

    // inputS[0] = 0x69; // FC (1 Byte)
    // inputS[1] = 0x03; // P0 (Algorithm Type Distinguisher : 1 Byte)
    // inputS[2] = 0x00; // L0 (2 Byte)
    // inputS[3] = 0x01; // L0 (2 Byte)
    // inputS[4] = TBD;  // P1 (Algorithm Identifier : 1 Byte)
    // inputS[5] = 0x00; // L1 (2 Byte)
    // inputS[6] = 0x01; // L1 (2 Byte)

    uint8_t dKey[KEY_ENB_LENGTH];
    uint8_t inputS[KEY_ENB_LENGTH] = {0x69, 0x03, 0x00, 0x01, 0x00, 0x00, 0x01};
    uint32_t iLen = 7;

    PdcpCallContext_type &targetPdcpCtx = (isSecCtxModProc) ? ptCi->security.newPdcpCtx : ptCi->security.pdcpCtx;

    inputS[4] = targetPdcpCtx.securityInfo.cipherAlgo & 0x0F;
    memcpy(
        targetPdcpCtx.securityInfo.keyRrcEncOld, ptCi->security.pdcpCtx.securityInfo.keyRrcEncCurr, KEY_INT_CIP_LENGTH);

    fnKDF_HMAC_SHA_256(ptCi->security.sKgNB, KEY_ENB_LENGTH, inputS, iLen, dKey, KEY_ENB_LENGTH);
    memcpy(outputKey, &dKey[KEY_INT_CIP_LENGTH], KEY_INT_CIP_LENGTH);

    return;
}

/**
 * @brief     Derive key for SRB integrity
 * @param     ptCi : call context
 * @param     outputKey : output key
 * @param     isSecCtxModProc : Security Context Modification Procedure is OnGoing
 * @return    void
 */
void VLIB_DeriveKeyRrcIntegrity(callInfo_type *ptCi, uint8_t *outputKey, uint8_t isSecCtxModProc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(outputKey);

    // inputS[0] = 0x69; // FC (1 Byte)
    // inputS[1] = 0x04; // P0 (Algorithm Type Distinguisher : 1 Byte)
    // inputS[2] = 0x00; // L0 (2 Byte)
    // inputS[3] = 0x01; // L0 (2 Byte)
    // inputS[4] = TBD; // P1 (Algorithm Identifier : 1 Byte)
    // inputS[5] = 0x00; // L1 (2 Byte)
    // inputS[6] = 0x01; // L1 (2 Byte)

    uint8_t dKey[KEY_ENB_LENGTH];
    uint8_t inputS[KEY_ENB_LENGTH] = {0x69, 0x04, 0x00, 0x01, 0x00, 0x00, 0x01};
    uint32_t iLen = 7;

    PdcpCallContext_type &targetPdcpCtx = (isSecCtxModProc) ? ptCi->security.newPdcpCtx : ptCi->security.pdcpCtx;

    inputS[4] = targetPdcpCtx.securityInfo.integrityAlgo & 0x0F;
    memcpy(
        targetPdcpCtx.securityInfo.keyRrcIntOld, ptCi->security.pdcpCtx.securityInfo.keyRrcIntCurr, KEY_INT_CIP_LENGTH);

    fnKDF_HMAC_SHA_256(ptCi->security.sKgNB, KEY_ENB_LENGTH, inputS, iLen, dKey, KEY_ENB_LENGTH);
    memcpy(outputKey, &dKey[KEY_INT_CIP_LENGTH], KEY_INT_CIP_LENGTH);

    return;
}

/**
 * @brief     Decide security algorithm
 * @param     ptCi : call context
 * @param     isSecCtxModProc : Security Context Modification Procedure is OnGoing
 * @return    int16_t
 */
int16_t VLIB_DecideSecurityAlgorithm(callInfo_type *ptCi, uint8_t isSecCtxModProc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    ueSecurityCapability_type *ptUeSecCapa = NULL;
    PdcpCallContext_type *ptPdcpCtx = NULL;
    bool isSrcGnbIntegrityAlgoSelectedDuringHO = false;
    bool isSrcGnbCipheringAlgoSelectedDuringHO = false;
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    ptUeSecCapa = &(ptCi->ueInfo.ueSecurityCapa);

    if (isSecCtxModProc)
    {
        ptPdcpCtx = &(ptCi->security.newPdcpCtx);
    }
    else
    {
        ptPdcpCtx = &(ptCi->security.pdcpCtx);
    }

    if (RESUME_TYPE_INTER_GNB_TARGET == ptCi->ueInfo.rrcResumeInfo.resumeType)
    {
        switch (ptCi->ueInfo.rrcResumeInfo.srcIntegrityAlgo)
        {
            case EIA0:
            case EIA1:
            case EIA2:
                ptPdcpCtx->securityInfo.integrityAlgo = static_cast<enumIntegrityAlgo_type>(ptCi->ueInfo.rrcResumeInfo.srcIntegrityAlgo);
                break;

            default:
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "srcIntegrityAlgo(%d) is not supported\n", ptCi->ueInfo.rrcResumeInfo.srcIntegrityAlgo);
                break;
        }
        switch (ptCi->ueInfo.rrcResumeInfo.srcCipherAlgo)
        {
            case EEA0:
            case EEA1:
            case EEA2:
                ptPdcpCtx->securityInfo.cipherAlgo = static_cast<enumCipherAlgo_type>(ptCi->ueInfo.rrcResumeInfo.srcCipherAlgo);
                break;

            default:
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "srcCipherAlgo(%d) is not supported\n", ptCi->ueInfo.rrcResumeInfo.srcCipherAlgo);
                break;
        }
        return GOOD;
    }

    if (RRE_TYPE_INTER_GNB == ptCi->ueInfo.reestablishInfo.reestablishType)
    {
        switch (ptCi->ueInfo.reestablishInfo.srcIntegrityAlgo)
        {
            case EIA0:
            case EIA1:
            case EIA2:
                ptPdcpCtx->securityInfo.integrityAlgo = static_cast<enumIntegrityAlgo_type>(ptCi->ueInfo.reestablishInfo.srcIntegrityAlgo);
                break;

            default:
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "srcIntegrityAlgo(%d) is not supported\n", ptCi->ueInfo.reestablishInfo.srcIntegrityAlgo);
                break;
        }
        switch (ptCi->ueInfo.reestablishInfo.srcCipherAlgo)
        {
            case EEA0:
            case EEA1:
            case EEA2:
                ptPdcpCtx->securityInfo.cipherAlgo = static_cast<enumCipherAlgo_type>(ptCi->ueInfo.reestablishInfo.srcCipherAlgo);
                break;

            default:
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "srcCipherAlgo(%d) is not supported\n", ptCi->ueInfo.reestablishInfo.srcCipherAlgo);
                break;
        }
        return GOOD;
    }

    // Firstly, emergency call check in UE limited services mode
    if ((ptUeSecCapa->integrityCapa == BIT_MASK_EIA0) && (ptUeSecCapa->encryptionCapa == BIT_MASK_EEA0))
    {
        ptPdcpCtx->securityInfo.integrityAlgo = EIA0;
        ptPdcpCtx->securityInfo.cipherAlgo = EEA0;
        return GOOD;
    }

    if (ptCi->ueInfo.srcGnbSecurityAlgo.sourceSecurityAlgoFlag == VCCB_FLAG_ON)
    {
        switch (ptCi->ueInfo.srcGnbSecurityAlgo.srcIntegrityAlgo)
        {
            case EIA0:
            case EIA1:
            case EIA2:
                ptPdcpCtx->securityInfo.integrityAlgo = static_cast<enumIntegrityAlgo_type>(ptCi->ueInfo.srcGnbSecurityAlgo.srcIntegrityAlgo);
                isSrcGnbIntegrityAlgoSelectedDuringHO = true;
                break;
            default:
                break;
        }
        switch (ptCi->ueInfo.srcGnbSecurityAlgo.srcCipherAlgo)
        {
            case EEA0:
            case EEA1:
            case EEA2:
                ptPdcpCtx->securityInfo.cipherAlgo = static_cast<enumCipherAlgo_type>(ptCi->ueInfo.srcGnbSecurityAlgo.srcCipherAlgo);
                isSrcGnbCipheringAlgoSelectedDuringHO = true;
                break;
            default:
                break;
        }
        if (isSrcGnbIntegrityAlgoSelectedDuringHO &&
            isSrcGnbCipheringAlgoSelectedDuringHO)  // In case one is not selected, we will go for reselection of the
                                                    // not selected one
        {
            return GOOD;
        }
    }

    if (isSrcGnbIntegrityAlgoSelectedDuringHO)
    {
        goto ENCRYPTION_ALGORITHM_SELECTION;
    }

    // Integrity Algorithm
    if (pGnb->security.integrityEaPrior == EIA0)
    {
        if (ptCi->ueInfo.srcGnbSecurityAlgo.sourceSecurityAlgoFlag ==
            VCCB_FLAG_ON)  // In case of priority set as NULL in gNB, should we go for reject or reselect
        {
            return ERROR;
        }
        ptPdcpCtx->securityInfo.integrityAlgo = EIA0;
        ptPdcpCtx->securityInfo.cipherAlgo = EEA0;
        return GOOD;
    }
    else if (pGnb->security.integrityEaPrior == EIA1)
    {
        if (ptUeSecCapa->integrityCapa & BIT_MASK_128_EIA1)
        {
            ptPdcpCtx->securityInfo.integrityAlgo = EIA1;
        }
        else if (ptUeSecCapa->integrityCapa & BIT_MASK_128_EIA2)
        {
            ptPdcpCtx->securityInfo.integrityAlgo = EIA2;
        }
        else
        {
            if (ptCi->ueInfo.srcGnbSecurityAlgo.sourceSecurityAlgoFlag == VCCB_FLAG_ON)
            {
                return ERROR;
            }
            ptPdcpCtx->securityInfo.integrityAlgo = EIA0;
            ptPdcpCtx->securityInfo.cipherAlgo = EEA0;
            return GOOD;
        }
    }
    else if (pGnb->security.integrityEaPrior == EIA2)
    {
        if (ptUeSecCapa->integrityCapa & BIT_MASK_128_EIA2)
        {
            ptPdcpCtx->securityInfo.integrityAlgo = EIA2;
        }
        else if (ptUeSecCapa->integrityCapa & BIT_MASK_128_EIA1)
        {
            ptPdcpCtx->securityInfo.integrityAlgo = EIA1;
        }
        else
        {
            if (ptCi->ueInfo.srcGnbSecurityAlgo.sourceSecurityAlgoFlag == VCCB_FLAG_ON)
            {
                return ERROR;
            }
            ptPdcpCtx->securityInfo.integrityAlgo = EIA0;
            ptPdcpCtx->securityInfo.cipherAlgo = EEA0;
            return GOOD;
        }
    }
    else
    {
        if (ptCi->ueInfo.srcGnbSecurityAlgo.sourceSecurityAlgoFlag == VCCB_FLAG_ON)
        {
            return ERROR;
        }
        ptPdcpCtx->securityInfo.integrityAlgo = EIA0;
        ptPdcpCtx->securityInfo.cipherAlgo = EEA0;
        return GOOD;
    }
    isSrcGnbIntegrityAlgoSelectedDuringHO = true;

ENCRYPTION_ALGORITHM_SELECTION:

    if (isSrcGnbCipheringAlgoSelectedDuringHO)
    {
        return GOOD;
    }

    // Encryption Algorithm
    if (pGnb->security.cipherEaPrior == EEA0)
    {
        if (ptCi->ueInfo.srcGnbSecurityAlgo.sourceSecurityAlgoFlag ==
            VCCB_FLAG_ON)  // In case of priority set as NULL in gNB, should we go for reject or reselect
        {
            return ERROR;
        }
        ptPdcpCtx->securityInfo.cipherAlgo = EEA0;
    }
    else if (pGnb->security.cipherEaPrior == EEA1)
    {
        if (ptUeSecCapa->encryptionCapa & BIT_MASK_128_EEA1)
        {
            ptPdcpCtx->securityInfo.cipherAlgo = EEA1;
        }
        else if (ptUeSecCapa->encryptionCapa & BIT_MASK_128_EEA2)
        {
            ptPdcpCtx->securityInfo.cipherAlgo = EEA2;
        }
        else
        {
            if (ptCi->ueInfo.srcGnbSecurityAlgo.sourceSecurityAlgoFlag == VCCB_FLAG_ON)
            {
                return ERROR;
            }
            ptPdcpCtx->securityInfo.cipherAlgo = EEA0;
        }
    }
    else if (pGnb->security.cipherEaPrior == EEA2)
    {
        if (ptUeSecCapa->encryptionCapa & BIT_MASK_128_EEA2)
        {
            ptPdcpCtx->securityInfo.cipherAlgo = EEA2;
        }
        else if (ptUeSecCapa->encryptionCapa & BIT_MASK_128_EEA1)
        {
            ptPdcpCtx->securityInfo.cipherAlgo = EEA1;
        }
        else
        {
            if (ptCi->ueInfo.srcGnbSecurityAlgo.sourceSecurityAlgoFlag == VCCB_FLAG_ON)
            {
                return ERROR;
            }
            ptPdcpCtx->securityInfo.cipherAlgo = EEA0;
        }
    }
    else
    {
        if (ptCi->ueInfo.srcGnbSecurityAlgo.sourceSecurityAlgoFlag == VCCB_FLAG_ON)
        {
            return ERROR;
        }
        ptPdcpCtx->securityInfo.cipherAlgo = EEA0;
    }

    return GOOD;
}

/**
 * @brief     Apply security algorithm
 * @param     ptCi : call context
 * @param     isSecCtxModProc : Security Context Modification Procedure is OnGoing
 * @return    void
 */
void VLIB_ApplySecurityAlgorithm(callInfo_type *ptCi, uint8_t isSecCtxModProc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    int var = 0;
    PdcpCallContext_type *ptPdcpCtx = NULL;

    if (isSecCtxModProc)
    {
        ptPdcpCtx = &(ptCi->security.newPdcpCtx);
    }
    else
    {
        ptPdcpCtx = &(ptCi->security.pdcpCtx);
    }

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        ptPdcpCtx->securityInfo.mode = INTEGRITY_CIPHER_ACTIVATED;
        return;
    }

    if (ptCi->bitFlag.isNeedSecurityFlow == FALSE)
    {
        var = ((ptPdcpCtx->securityInfo.integrityAlgo == EIA0) << 1) | (ptPdcpCtx->securityInfo.cipherAlgo == EEA0);
        switch (var)
        {
            case 3:
                ptPdcpCtx->securityInfo.mode = SECURITY_IDLE;
                break;
            case 2:
                ptPdcpCtx->securityInfo.mode = CIPHERING_ACTIVATED;
                break;
            case 1:
                ptPdcpCtx->securityInfo.mode = INTEGRITY_ACTIVATED;
                break;
            case 0:
                if (GET_SECURITY_MODE_CMD_FLAG(ptCi->flag.respFlag) == FALSE)
                    ptPdcpCtx->securityInfo.mode = INTEGRITY_CIPHER_ACTIVATED;
                else
                    ptPdcpCtx->securityInfo.mode = INTANDDLCHIPHER_ACTIVATED;
                break;
            default:
                break;
        }
    }
    // just before sending SecurityModeCommand
    else if (GET_SECURITY_MODE_CMD_FLAG(ptCi->flag.setupFlag) == TRUE)
    {
        if (ptPdcpCtx->securityInfo.integrityAlgo == EIA0)
        {
            ptPdcpCtx->securityInfo.mode = SECURITY_IDLE;
        }
        else
        {
            ptPdcpCtx->securityInfo.mode = INTEGRITY_ACTIVATED;
        }
    }

    return;
}

/**
 * @brief     Derive old key for SRB integrity
 * @param     ptCi : call context
 * @return    void
 */
void VLIB_DeriveOldKeyRrcIntegrity(callInfo_type *ptCi, uint8_t *outputKey)
{
    AUTO_TRACE_FUNC;

    uint8_t dKey[KEY_ENB_LENGTH];
    uint8_t inputS[KEY_ENB_LENGTH];
    uint32_t iLen = 0;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(outputKey);

    inputS[0] = 0x69;
    iLen++;  // FC (1 Byte)
    inputS[1] = 0x04;
    iLen++;  // P0 (Algorithm Type Distinguisher : 1 Byte)
    inputS[2] = 0x00;
    iLen++;  // L0 (2 Byte)
    inputS[3] = 0x01;
    iLen++;  // L0 (2 Byte)
    inputS[4] = ptCi->ueInfo.reestablishInfo.srcIntegrityAlgo & 0x0F;
    iLen++;  // P1 (Algorithm Identifier : 1 Byte)
    inputS[5] = 0x00;
    iLen++;  // L1 (2 Byte)
    inputS[6] = 0x01;
    iLen++;  // L1 (2 Byte)

    fnKDF_HMAC_SHA_256(ptCi->security.sKgNB, KEY_ENB_LENGTH, inputS, iLen, dKey, KEY_ENB_LENGTH);
    memcpy(outputKey, &dKey[KEY_INT_CIP_LENGTH], KEY_INT_CIP_LENGTH);

    return;
}

/**
 * @brief     Make old short MAC-I
 * @param     ptCi : call context
 * @param     targetCi : target cell
 * @param     outShortMacI : derived short MAC-I
 * @return    GOOD : success
 */
int16_t VLIB_MakeOldShortMacI(callInfo_type *ptCi, uint64_t targetNCI, uint16_t *outShortMacI)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(outShortMacI);

    NRRRC_VarShortMAC_Input input;

    uint8_t keyRrcIntCurr[16];
    uint32_t algorithm;
    uint32_t countI;
    uint8_t bearerId;
    uint8_t direction;
    uint8_t pack[1024];
    long packLength = sizeof(pack);
    uint8_t outMacI[4];
    uint8_t octet5[5];

    // Make ShortMacI Input
    input.sourcePhysCellId = ptCi->ueInfo.reestablishInfo.srcPhyCellId;

    input.targetCellIdentity.length = NR_NCI_BITS_LEN;
    if (fnGlobalValueAlloc((uint8_t **)&input.targetCellIdentity.value, NR_NCI_BYTES_LEN) != 0)  // Check Init:OK
    {
        VCCB_PRINT_ERROR("ERROR: fnGlobalValueAlloc failed in FillNRRRC_LogicalChannelConfig_Full\n");
        return ERROR;
    }
    input.targetCellIdentity.value = octet5;
    input.targetCellIdentity.value[0] = (targetNCI >> 28) & 0x000000FF;
    input.targetCellIdentity.value[1] = (targetNCI >> 20) & 0x000000FF;
    input.targetCellIdentity.value[2] = (targetNCI >> 12) & 0x000000FF;
    input.targetCellIdentity.value[3] = (targetNCI >> 4) & 0x000000FF;
    input.targetCellIdentity.value[4] = (targetNCI << 4) & 0x000000F0;

    input.source_c_RNTI = ptCi->ueInfo.reestablishInfo.srcCRNTI;

    if (PackNGRRC_VarShortMAC_Input(&input, (unsigned char *)pack, (long *)&packLength) == ERROR)
    {
        VCCB_PRINT_ERROR("PackNGRRC_VarShortMAC_Input Error\n");
        return ERROR;
    }

    VLIB_DeriveOldKeyRrcIntegrity(ptCi, keyRrcIntCurr);
    algorithm = ptCi->ueInfo.reestablishInfo.srcIntegrityAlgo;
    direction = 0x1;      // 1 Bit
    countI = 0xFFFFFFFF;  // 32 Bits
    bearerId = 0x1F;      // 5 Bits

    // Call Integrity Function
    if (ptCi->ueInfo.reestablishInfo.srcIntegrityAlgo != EIA0)
    {
        fn_integrity_get_mac(keyRrcIntCurr, algorithm, pack, countI, bearerId, direction, outMacI, static_cast<uint8_t>(packLength));

        (*outShortMacI) = (uint16_t)((outMacI[2] << 8) + outMacI[3]);  // 16 least significant bits...
    }
    else
    {
        *outShortMacI = 0;
    }

    return GOOD;
}

int8_t VLIB_HandleRreCase_inDeriveKeyNGRANStar(callInfo_type *ptCi, uint8_t *inputS, uint32_t iLen, uint8_t *dKey)
{
    AUTO_TRACE_FUNC;
    int nCellIdx = 0;

    switch (ptCi->ueInfo.reestablishInfo.rreMatchType)
    {
        case RRE_CURRENT_KEY_MATCH:
        {
            if ((ptCi->security.newSecurityContextChangeInd == TRUE) || (ptCi->security.nCC == ptCi->security.newNCC))
            {
                fnKDF_HMAC_SHA_256(ptCi->security.sKgNB, 32, inputS, iLen, dKey, 32);
            }
            else
            {
                fnKDF_HMAC_SHA_256(ptCi->security.nextHop, 32, inputS, iLen, dKey, 32);
            }
            break;
        }
        case RRE_NG_HO_SRC_KEY_MATCH:
        {
            fnKDF_HMAC_SHA_256(ptCi->security.nextHop, 32, inputS, iLen, dKey, 32);
            break;
        }
        case RRE_XN_HO_SRC_KEY_MATCH:
        {
            const int maxReestabNcell = MIN(MAX_CELL_PREPARED_FOR_HO + 1, ptCi->ueInfo.reestablishInfo.numReestabNCell);
            for (nCellIdx = 0; nCellIdx < maxReestabNcell; nCellIdx++)
            {
                if (ptCi->nRCGI.ci == ptCi->ueInfo.reestablishInfo.reestabNCellInfo[nCellIdx].reestabCellIdentity)
                    break;
            }

            if (maxReestabNcell == nCellIdx)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "[RRE] DeriveKey: Can't find matched ReestabNCells(%d)\n", nCellIdx);
                return ERROR;
            }

            memcpy(dKey, ptCi->ueInfo.reestablishInfo.reestabNCellInfo[nCellIdx].keyGNB_Star, 32);
            break;
        }
        case RRE_OLD_KEY_MATCH:
        {
            fnKDF_HMAC_SHA_256(ptCi->ueInfo.reestablishInfo.oldKeyGNB, 32, inputS, iLen, dKey, 32);
            break;
        }
        default:
            VCCB_PRINT_CALL_ERROR(
                ptCi, "[RRE] DeriveKey: not supported rrcMatchType(%d)\n", ptCi->ueInfo.reestablishInfo.rreMatchType);
            return ERROR;
    }
    return GOOD;
}

/**
 * @brief     Derive Enb star key
 * @param     ptCi : call context
 * @param     targetPci : target PCI
 * @param     arfcnDl : DL frequency
 * @param     outputKey : output key
 * @return    GOOD : success
 * @return    ERROR : failure
 */
int16_t VLIB_DeriveKeyNGRANStar(callInfo_type *ptCi, uint16_t targetPci, uint32_t arfcnDl, uint8_t *outputKey)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(outputKey);

    uint8_t dKey[32];
    uint8_t inputS[32];
    uint32_t iLen = 0;

    VCCB_PRINT_DATA("arfcnDl = %u\n", arfcnDl);

    // Make Input String according to 33.501 (A.11 KNG-RAN* derivation function for target gNB)
    inputS[iLen] = 0x70;
    iLen++;  // FC (1 Byte)
    inputS[iLen] = static_cast<uint8_t>(targetPci >> 8) & 0xFF;
    iLen++;  // P0 (PCI : 2 Byte)
    inputS[iLen] = static_cast<uint8_t>(targetPci & 0x00FF);
    iLen++;  // P0 (PCI : 2 Byte)
    inputS[iLen] = 0x00;
    iLen++;  // L0 (2 Byte)
    inputS[iLen] = 0x02;
    iLen++;  // L0 (2 Byte)
    inputS[iLen] = (arfcnDl >> 16) & 0xFF;
    iLen++;  // P1 (ARFCN_DL : 3 Byte)
    inputS[iLen] = (arfcnDl >> 8) & 0xFF;
    iLen++;  // P1 (ARFCN_DL : 3 Byte)
    inputS[iLen] = (arfcnDl & 0xFF);
    iLen++;  // P1 (ARFCN_DL : 3 Byte)
    inputS[iLen] = 0x00;
    iLen++;  // L1 (2 Byte)
    inputS[iLen] = 0x03;
    iLen++;  // L1 (2 Byte)

    if (GET_RRC_STATE(ptCi) == RRC_INACTIVE)  // case Suspend/Resume
    {
        if ((ptCi->security.newSecurityContextChangeInd == TRUE) || (ptCi->security.nCC == ptCi->security.newNCC))
        {
            fnKDF_HMAC_SHA_256(ptCi->security.sKgNB, 32, inputS, iLen, dKey, 32);
        }
        else
        {
            fnKDF_HMAC_SHA_256(ptCi->security.nextHop, 32, inputS, iLen, dKey, 32);
        }
    }
    else if (ptCi->stateCmd == RrcReestablish_cmd)  // case RRE
    {
        VCCB_RETURN_ON_CALL_ERROR(ptCi, VLIB_HandleRreCase_inDeriveKeyNGRANStar(ptCi, inputS, iLen, dKey),
            "VLIB_HandleRreCase_inDeriveKeyNGRANStar ERROR!\n");
    }
    else  // case HO
    {
        if (ptCi->security.nCC == ptCi->security.newNCC)
        {
            fnKDF_HMAC_SHA_256(ptCi->security.sKgNB, 32, inputS, iLen, dKey, 32);
        }
        else
        {
            fnKDF_HMAC_SHA_256(ptCi->security.nextHop, 32, inputS, iLen, dKey, 32);
        }
    }

    memcpy(outputKey, dKey, 32);

    RESET_SN_COUNTER();

    return GOOD;
}

/**
 * @brief     Make source short MAC-I
 * @param     ptCi : call context
 * @param     targetCi : target cell
 * @param     outShortMacI : derived short MAC-I
 * @return    GOOD : success
 */
int16_t VLIB_MakeShortMacI(
    callInfo_type *ptCi, uint16_t phyCellId, uint16_t rnti, uint64_t targetNCI, uint16_t *outShortMacI)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(outShortMacI);

    NRRRC_VarShortMAC_Input input;

    uint8_t keyRrcIntCurr[16];
    uint32_t algorithm;
    uint32_t countI;
    uint8_t bearerId;
    uint8_t direction;
    uint8_t pack[1024];
    long packLength = sizeof(pack);
    uint8_t outMacI[4];
    uint8_t octet5[5];

    // Make ShortMacI Input
    input.sourcePhysCellId = phyCellId;

    input.targetCellIdentity.length = NR_NCI_BITS_LEN;
    if (fnGlobalValueAlloc((uint8_t **)&input.targetCellIdentity.value, NR_NCI_BYTES_LEN) != 0)  // Check Init:OK
    {
        VCCB_PRINT_ERROR("ERROR: fnGlobalValueAlloc failed in VLIB_MakeShortMacI\n");
        return ERROR;
    }
    input.targetCellIdentity.value = octet5;
    input.targetCellIdentity.value[0] = (targetNCI >> 28) & 0x000000FF;
    input.targetCellIdentity.value[1] = (targetNCI >> 20) & 0x000000FF;
    input.targetCellIdentity.value[2] = (targetNCI >> 12) & 0x000000FF;
    input.targetCellIdentity.value[3] = (targetNCI >> 4) & 0x000000FF;
    input.targetCellIdentity.value[4] = (targetNCI << 4) & 0x000000F0;

    input.source_c_RNTI = rnti;

    if (PackNGRRC_VarShortMAC_Input(&input, (unsigned char *)pack, (long *)&packLength) == ERROR)
    {
        VCCB_PRINT_ERROR("PackNGRRC_VarShortMAC_Input Error\n");
        return ERROR;
    }

    // TODO : need to check the function VLIB_DeriveSourceKeyRrcIntegrity(LTE uses this function but there is no
    // reestablishInfo DB now)
    VLIB_DeriveKeyRrcIntegrity(ptCi, keyRrcIntCurr, false);
    // TODO : need to check the algorithm. Old code uses the ptCi->ueInfo.reestablishInfo.srcIntegrityAlgo
    algorithm = ptCi->security.pdcpCtx.securityInfo.integrityAlgo;
    direction = 0x1;      // 1 Bit
    countI = 0xFFFFFFFF;  // 32 Bits
    bearerId = 0x1F;      // 5 Bits

    // Call Integrity Function
    // TODO : need to check the algorithm. Old code uses the ptCi->ueInfo.reestablishInfo.srcIntegrityAlgo
    if (ptCi->security.pdcpCtx.securityInfo.integrityAlgo != EIA0)
    {
        fn_integrity_get_mac(keyRrcIntCurr, algorithm, pack, countI, bearerId, direction, outMacI, static_cast<uint32_t>(packLength));

        (*outShortMacI) = (uint16_t)((outMacI[2] << 8) + outMacI[3]);  // 16 least significant bits...
    }
    else
    {
        *outShortMacI = 0;
    }

    return GOOD;
}

/**
 * @brief     Make the securityKey for Secondary-Node
 * @param     ptCi : call context
 * @param     targetCi : target cell
 * @param     outShortMacI : derived short MAC-I
 * @return    GOOD : success
 */

int16_t VLIB_DeriveKeySN(callInfo_type *ptCi, uint8_t *outputKey, uint8_t *keyGnb, uint16_t scgCounter)
{
    uint8_t dKey[KEY_ENB_LENGTH];
    uint8_t inputS[KEY_ENB_LENGTH];
    uint32_t iLen = 0;

    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(outputKey);
    VALID_E_POINT_CHECK_ERROR(keyGnb);

    INCREASE_SN_COUNTER();

    VCCB_PRINT_DATA("scgCounter = %u\n", scgCounter);

    // Make Input String according to 33.501
    inputS[0] = 0x79;
    iLen++;  // FC (1 Byte)
    inputS[1] = static_cast<uint8_t>(scgCounter >> 8) & 0x00FF;
    iLen++;  // P0 (SCG COUNTER : 2 Byte)
    inputS[2] = static_cast<uint8_t>(scgCounter & 0x00FF);
    iLen++;  // P0 (SCG COUNTER : 2 Byte)
    inputS[3] = 0x00;
    iLen++;  // L0 (2 Byte)
    inputS[4] = 0x02;
    iLen++;  // L0 (2 Byte)

    fnKDF_HMAC_SHA_256(keyGnb, KEY_ENB_LENGTH, inputS, iLen, dKey, KEY_ENB_LENGTH);

    memcpy(outputKey, dKey, KEY_ENB_LENGTH);

    return GOOD;
}

int16_t VLIB_MakeResumeMacI(callInfo_type *const ptCi, const uint16_t phyCellId, const uint16_t crnti,
    const uint64_t targetNCI, uint16_t *outResumeMacI)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(outResumeMacI);

    NRRRC_VarResumeMAC_Input input;
    uint32_t algorithm, countI;
    uint8_t bearerId, direction;
    uint8_t pack[1024], outMacI[4], octet5[5];
    long packLength = sizeof(pack);

    // Make ResumeMacI Input
    input.sourcePhysCellId = phyCellId;

    input.targetCellIdentity.length = NR_NCI_BITS_LEN;  // 36
    if (fnGlobalValueAlloc((uint8_t **)&input.targetCellIdentity.value, NR_NCI_BYTES_LEN) != 0)
    {
        VCCB_PRINT_ERROR("ERROR: fnGlobalValueAlloc failed in VLIB_MakeResumeMacI\n");
        return ERROR;
    }
    input.targetCellIdentity.value = octet5;
    input.targetCellIdentity.value[0] = (targetNCI >> 28) & 0x000000FF;
    input.targetCellIdentity.value[1] = (targetNCI >> 20) & 0x000000FF;
    input.targetCellIdentity.value[2] = (targetNCI >> 12) & 0x000000FF;
    input.targetCellIdentity.value[3] = (targetNCI >> 4) & 0x000000FF;
    input.targetCellIdentity.value[4] = (targetNCI << 4) & 0x000000F0;

    input.source_c_RNTI = crnti;

    if (PackNGRRC_VarResumeMAC_Input(&input, (unsigned char *)pack, (long *)&packLength) == ERROR)
    {
        VCCB_PRINT_ERROR("PackNGRRC_VarResumeMAC_Input Error\n");
        return ERROR;
    }

    algorithm = ptCi->security.pdcpCtx.securityInfo.integrityAlgo;
    direction = 0x1;      // 1 Bit
    countI = 0xFFFFFFFF;  // 32 Bits
    bearerId = 0x1F;      // 5 Bits

    if (ptCi->security.pdcpCtx.securityInfo.integrityAlgo != EIA0)
    {
        // Without new derivation of K_RRCint, use the original one as the first input.
        fn_integrity_get_mac(ptCi->security.pdcpCtx.securityInfo.keyRrcIntCurr, algorithm, pack, countI, bearerId,
            direction, outMacI, static_cast<uint32_t>(packLength));

        (*outResumeMacI) = (uint16_t)((outMacI[2] << 8) + outMacI[3]);
    }
    else
    {
        *outResumeMacI = 0;
    }

    return GOOD;
}

int16_t FnVCCB_VerifyMACI(
    callInfo_type *const ptCi, const uint64_t targetCellIdentity, const uint16_t requestedResumeMacI)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FLAG_ON == DBG->flag.isAlwaysFailVerificationOfResumeMacI)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[Debug] make always fail verification of ResumeMacI\n");
        return BREAK;
    }

    uint16_t resumeMacI = 0;
    const uint16_t sourcePCI = ptCi->ueInfo.ueId.suspendedPCI;
    const crnti_type sourceCRNTI = ptCi->ueInfo.ueId.suspendedCRNTI;
    VCCB_PRINT_CALL_DATA(
        ptCi, "sourcePCI(%u), sourceCRNTI(%u), targetCellIdentity(%lu)\n", sourcePCI, sourceCRNTI, targetCellIdentity);
    int16_t status = VLIB_MakeResumeMacI(ptCi, sourcePCI, sourceCRNTI, targetCellIdentity, &resumeMacI);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_MakeResumeMacI ERROR!\n");
        VCCB_PRINT_CALL_ERROR(ptCi, "sourcePCI(%u), sourceCRNTI(%u), targetCellIdentity(%lu)\n", sourcePCI, sourceCRNTI,
            targetCellIdentity);
        return BREAK;
    }

    if (requestedResumeMacI != resumeMacI)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ResumeMacI Verification Failed(UE resumeMacI(%d), CP resumeMacI(%d))\n",
            requestedResumeMacI, resumeMacI);
        VCCB_PRINT_CALL_ERROR(ptCi, "sourcePCI(%u), sourceCRNTI(%u), targetCellIdentity(%lu)\n", sourcePCI, sourceCRNTI,
            targetCellIdentity);
        return BREAK;
    }

    return GOOD;
}

void FnVCCB_DeriveKeysForRRCResume(callInfo_type &call)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(call.servCellNum, MAX_CELL_NUM_VCCB);

    const VccbCellInfo_type &cell = CELLINFO[call.servCellNum];

    // New Key Derivation in case of successful verification of resumeMAC-I.
    // 1. K_gNB*: always derived
    int16_t status = VLIB_DeriveKeyNGRANStar(&call, cell.phyCellId, cell.ssbArfcn, call.security.sKgNB);
    if (status == ERROR)
    {
        // In RRC Resume scenario, VLIB_DeriveKeyNGRANStar always succeeds.
        VCCB_PRINT_CALL_ERROR(&call, "VLIB_DeriveKeyNGRANStar ERROR(%d)! in %s\n", status, __func__);
    }

    // 2. K_RRCint: always derived
    VLIB_DeriveKeyRrcIntegrity(&call, call.security.pdcpCtx.securityInfo.keyRrcIntCurr, FALSE);

    // 3. K_RRCenc: always derived
    VLIB_DeriveKeyRrcEncryption(&call, call.security.pdcpCtx.securityInfo.keyRrcEncCurr, FALSE);

    // 4. K_UPenc: always derived even though it is unnecessary in RNAU, just in case
    VLIB_DeriveKeyUpEncryption(&call, call.security.pdcpCtx.securityInfo.keyUpEnc, FALSE);

    // 5. keyUpInt: always derived even though it is unnecessary in RNAU, just in case
    VLIB_DeriveKeyUpIntegrity(&call, call.security.pdcpCtx.securityInfo.keyUpInt, FALSE);

    if (call.security.newSecurityContextChangeInd == FALSE)
    {
        call.security.nCC = call.security.newNCC;
    }

    call.ueInfo.securityModFlag = VCCB_FLAG_ON;
    return;
}

int16_t FnVCCB_DecideSourceSecurityCapabilities(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (RESUME_TYPE_INTER_GNB_TARGET == ptCi->ueInfo.rrcResumeInfo.resumeType)
    {
        if (ptCi->ueInfo.rrcResumeInfo.srcIntegrityAlgo > EIA2)
        {
            return ERROR;
        }

        if (ptCi->ueInfo.rrcResumeInfo.srcCipherAlgo > EEA2)
        {
            return ERROR;
        }
    }

    return GOOD;
}

void VLIB_sendNia0Notification(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    ueSecurityCapability_type *ptUeSecCapa = &(ptCi->ueInfo.ueSecurityCapa);
    struct timespec tmpTimeSpec;
    long epochMicroSec;

    int index = 0;
#define MAX_INFO_STR_LEN_FOR_NOTI (100)
    char supportedIntegrityAlgorithm[MAX_INFO_STR_LEN_FOR_NOTI] = "NIA0";
    char supportedCipheringAlgorithm[MAX_INFO_STR_LEN_FOR_NOTI] = "NEA0";
    char establishmentCauseStr[MAX_INFO_STR_LEN_FOR_NOTI] = {
        0,
    };

    char strSourceName[MAX_INFO_STR_LEN_FOR_NOTI] = {
        0,
    };
    char strNfcNamingCode[MAX_INFO_STR_LEN_FOR_NOTI] = {
        0,
    };

    int result = VLIB_getSourceNameForNotification(strSourceName, MAX_INFO_STR_LEN_FOR_NOTI);
    if (result != GOOD)
    {
        VCCB_PRINT_ERROR(
            "[%s   %d] VLIB_sendNia0Notification >> get SourceName failed(%d)\n", __FILE__, __LINE__, result);
        return;
    }

    result = VLIB_getNfcNamingCode(strNfcNamingCode, MAX_INFO_STR_LEN_FOR_NOTI);
    if (result != GOOD)
    {
        VCCB_PRINT_ERROR(
            "[%s   %d] VLIB_sendNia0Notification >> get NfcNamingCode failed(%d)\n", __FILE__, __LINE__, result);
        return;
    }

    dal_tag_value_t tags[100];
    memset(tags, 0, sizeof(tags));

    epochMicroSec = clock_gettime(CLOCK_REALTIME, &tmpTimeSpec) == 0
                        ? (tmpTimeSpec.tv_nsec / 1000 + tmpTimeSpec.tv_sec * 1000000)
                        : 0;

#if defined(__ACPF__)
    {
        DAL_SET_TAG_XMLBEGIN(&tags[index++], YANG_NS_PREFIX(Notification_Acpf_Samsung_AttachWithNia0), VCCB_YANG_NS);
    }
#elif defined(__NVGNB__)
    {
        DAL_SET_TAG_XMLBEGIN(&tags[index++], YANG_NS_PREFIX(Notification_Nvgnb_Samsung_AttachWithNia0), VCCB_YANG_NS);
    }
#endif

    DAL_SET_TAG_ENUM_VALUE(&tags[index++], YANG_NS_PREFIX(domain), common_notification);

#if defined(NEW_HOST_SIM)
    DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(eventId), "0");
#endif

#if defined(__ACPF__)
    {
        DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(eventName), "Notification_Acpf-Samsung_AttachWithNia0");
    }
#elif defined(__NVGNB__)
    {
        DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(eventName), "Notification_Nvgnb-Samsung_AttachWithNia0");
    }
#endif

    DAL_SET_TAG_INT64(&tags[index++], YANG_NS_PREFIX(lastEpochMicrosec), epochMicroSec);
    DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(nfcNamingCode), strNfcNamingCode);

#if defined(NEW_HOST_SIM)
    DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(nfNamingCode), "acpf-hostsim");
    DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(nfVendorName), "SAMSUNG");
#endif

    DAL_SET_TAG_ENUM_VALUE(&tags[index++], YANG_NS_PREFIX(priority), common_Normal);

#if defined(NEW_HOST_SIM)
    DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(reportingEntityId), "123");
    DAL_SET_TAG_INT32(&tags[index++], YANG_NS_PREFIX(sequence), 0);
    DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(sourceId), "hostsim-vccb-id");
#endif

    DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(sourceName), strSourceName);
    DAL_SET_TAG_INT64(&tags[index++], YANG_NS_PREFIX(startEpochMicrosec), epochMicroSec);

#if defined(NEW_HOST_SIM)
    DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(timeZoneOffset), "UTC+00:00");
    DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(version), "4.0");
    DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(vesEventListenerVersion), "7.0");
#endif

    DAL_SET_TAG_INT32(&tags[index++], YANG_NS_PREFIX(statusCode), 1);
    DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(changeIdentifier), "NullAlgorithm");
    DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(changeType), "NullAlgorithmSelected");

    DAL_SET_TAG_UINT32(&tags[index++], YANG_NS_PREFIX(ueId), ptCi->callId);
    DAL_SET_TAG_UINT32(&tags[index++], YANG_NS_PREFIX(gnb_id), GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id);
    DAL_SET_TAG_UINT32(&tags[index++], YANG_NS_PREFIX(cellIdentity), CELLINFO[ptCi->servCellNum].cellIdentity);

    if (ci_emergency == ptCi->ueInfo.establishmentCause)
    {
        DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(cause), "Emergency (0)");
    }
    else
    {
        snprintf(
            establishmentCauseStr, MAX_INFO_STR_LEN_FOR_NOTI, "Non Emergency (%d)", ptCi->ueInfo.establishmentCause);
        DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(cause), establishmentCauseStr);
    }

    if (ptUeSecCapa->integrityCapa & BIT_MASK_128_EIA1)
    {
        strncat(supportedIntegrityAlgorithm, "/NIA1",
            sizeof(supportedIntegrityAlgorithm) - strlen(supportedIntegrityAlgorithm) - 1);
    }
    if (ptUeSecCapa->integrityCapa & BIT_MASK_128_EIA2)
    {
        strncat(supportedIntegrityAlgorithm, "/NIA2",
            sizeof(supportedIntegrityAlgorithm) - strlen(supportedIntegrityAlgorithm) - 1);
    }
    if (ptUeSecCapa->encryptionCapa & BIT_MASK_128_EEA1)
    {
        strncat(supportedCipheringAlgorithm, "/NEA1",
            sizeof(supportedCipheringAlgorithm) - strlen(supportedCipheringAlgorithm) - 1);
    }
    if (ptUeSecCapa->encryptionCapa & BIT_MASK_128_EEA2)
    {
        strncat(supportedCipheringAlgorithm, "/NEA2",
            sizeof(supportedCipheringAlgorithm) - strlen(supportedCipheringAlgorithm) - 1);
    }
    DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(ue_supported_integrity_algorithms), supportedIntegrityAlgorithm);
    DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(ue_supported_ciphering_algorithms), supportedCipheringAlgorithm);
    DAL_SET_TAG_ENUM_VALUE(&tags[index++], YANG_NS_PREFIX(selected_integrity_algorithm), 0);
    DAL_SET_TAG_ENUM_VALUE(&tags[index++], YANG_NS_PREFIX(selected_ciphering_algorithm), 0);

#if defined(__ACPF__)
    {
        DAL_SET_TAG_XMLEND(&tags[index++], YANG_NS_PREFIX(Notification_Acpf_Samsung_AttachWithNia0), VCCB_YANG_NS);
    }
#elif defined(__NVGNB__)
    {
        DAL_SET_TAG_XMLEND(&tags[index++], YANG_NS_PREFIX(Notification_Nvgnb_Samsung_AttachWithNia0), VCCB_YANG_NS);
    }
#endif

    result = VccbNotiHandler_sendNotification(tags, index);
    VCCB_PRINT_WITHOUT_RETURN_ON_CALL_ERROR(ptCi, result, "VccbNotiHandler_sendNotification Nia0Notification ERROR!\n");

#undef MAX_INFO_STR_LEN_FOR_NOTI
}

int16_t VLIB_Nia0Processing(callInfo_type *ptCi, bool flag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    enumIntegrityAlgo_type selectedIntegrityAlgo =
        flag ? ptCi->security.newPdcpCtx.securityInfo.integrityAlgo : ptCi->security.pdcpCtx.securityInfo.integrityAlgo;

    if (EIA0 != selectedIntegrityAlgo)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Integrity Algorithm not NULL\n");
        return GOOD;
    }

    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (TRUE == pGnb->security.isEventNia0Supported)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Send NIA0 event to VES\n");
        VLIB_sendNia0Notification(ptCi);
    }

    if (FALSE == pGnb->security.isNia0SupportedInGnb)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Null Integrity Algorithm not supported in Gnb\n");
        return ERROR;
    }

    return GOOD;
}

int16_t VLIB_SecurityHandling(callInfo_type *ptCi, bool isSecCtxModProc)
{

    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;
    PdcpCallContext_type *ptPdcpCtx = NULL;

    if (isSecCtxModProc)
    {
        ptPdcpCtx = &(ptCi->security.newPdcpCtx);
    }
    else
    {
        ptPdcpCtx = &(ptCi->security.pdcpCtx);
    }

    // Decision Security Algorithm
    status = VLIB_DecideSecurityAlgorithm(ptCi, isSecCtxModProc);
    ptCi->ueInfo.srcGnbSecurityAlgo.sourceSecurityAlgoFlag = VCCB_FLAG_OFF;
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_DecideSecurityAlgorithm ERROR!!\n");
        return ERROR;
    }
    status = VLIB_Nia0Processing(ptCi, isSecCtxModProc);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "NIA0 not supported in Gnb!!\n");
        return ERROR;
    }
    VLIB_ApplySecurityAlgorithm(ptCi, isSecCtxModProc);

#ifdef IPC_TEST
     VCCB_PRINT_CALL_INFORMATIVE(ptCi, "integrityAlgo(%d) cipheringAlgo(%d)\n", ptPdcpCtx->securityInfo.integrityAlgo, ptPdcpCtx->securityInfo.cipherAlgo);
#endif

    VLIB_DeriveKeyRrcIntegrity(ptCi, ptPdcpCtx->securityInfo.keyRrcIntCurr, isSecCtxModProc);
    VLIB_DeriveKeyRrcEncryption(ptCi, ptPdcpCtx->securityInfo.keyRrcEncCurr, isSecCtxModProc);
    VLIB_DeriveKeyUpEncryption(ptCi, ptPdcpCtx->securityInfo.keyUpEnc, isSecCtxModProc);
    VLIB_DeriveKeyUpIntegrity(ptCi, ptPdcpCtx->securityInfo.keyUpInt, isSecCtxModProc);

    return status;
}

int16_t VLIB_DeriveKeysForIntraCellHo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    const int16_t status = VLIB_DeriveKeyNGRANStar(ptCi, pCell->phyCellId, pCell->ssbArfcn, ptCi->security.sKgNB);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VLIB_DeriveKeyNGRANStar ERROR(%d)!\n", status);

    ptCi->security.newPdcpCtx = ptCi->security.pdcpCtx; // Currently no change in newPdcpCtx after Path Switch Request Ack

    // Update the new RRC keys after the sending the RRCReconfiguration for the Key change procedure
    VLIB_DeriveKeyUpEncryption(ptCi, ptCi->security.newPdcpCtx.securityInfo.keyUpEnc, TRUE);
    VLIB_DeriveKeyUpIntegrity(ptCi, ptCi->security.newPdcpCtx.securityInfo.keyUpInt, TRUE);
    VLIB_DeriveKeyRrcIntegrity(ptCi, ptCi->security.newPdcpCtx.securityInfo.keyRrcIntCurr, TRUE);
    VLIB_DeriveKeyRrcEncryption(ptCi, ptCi->security.newPdcpCtx.securityInfo.keyRrcEncCurr, TRUE);

    return GOOD;
}

/* EOF */
