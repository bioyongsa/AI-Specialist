#include "FeatCellReselection.h"

#include "FeatMeasurements.hpp"
#include "FeatMeasurementsNRRRCMake.hpp"
#include "FeatCommon.h"
#include "FeatCallInfo.h"
#include "FeatCallProc.h"
#include "FeatHo.h"

#include "ComInclude.h"
#include "ComLibUtility.h"

#include "StateCommon.h"

#include "compat_glibc.h"

#include "access_common_yang.h"
#include <sstream>
#include <string>

#define MAX_FALLBACK_EUTRA_RESEL_PRIORITY 7

bool FnVCCB_IsValid_MeasObj_CellReselection(callInfo_type *ptCi, uint8_t measObjIndex, bool restrictedFrequencyCheckFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_VAL(measObjIndex, MAX_NR_OF_OBJECT_ID_DB, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->servCellNum, MAX_CELL_NUM_VCCB, false);
    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];

    measurementObjectNRBaseDb_type *pMeasObj = &(pCell->measurementsData.measurementObjectsNRDb[measObjIndex].base);

    if (pMeasObj->ssbFrequency != pCell->ssbArfcn)
    {
        if (TRUE != pMeasObj->saCapable)
        {
            if (DBG->flag.logRrcReleaseInfo)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "(CRP) check saCapable (freq:%u)\n", pMeasObj->ssbFrequency);
            }
            return false;
        }   
    }

    if (0 == VCCB_GetMoNrBandForUe(ptCi, pMeasObj))
    {
        if (DBG->flag.logRrcReleaseInfo)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "(CRP) check VCCB_GetMoNrBandForUe (freq:%u)\n", pMeasObj->ssbFrequency);
        }
        // not supported by UE
        return false;
    }

    if (false == VCCB_IsCbrsValidatedMo(pMeasObj, measObjIndex))
    {
        if (DBG->flag.logRrcReleaseInfo)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "(CRP) check VCCB_IsCbrsValidatedMo (freq:%u)\n", pMeasObj->ssbFrequency);
        }
        return false;
    }

    if (IS_REDCAP_UE(ptCi))
    {
        if (pMeasObj->redcapAccessAllowed != TRUE)
        {
            if (DBG->flag.logRrcReleaseInfo)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "(CRP) check redcapAccessAllowed (freq:%u)\n", pMeasObj->ssbFrequency);
            }
            return false;
        }
    }

    if (false == FnVCCB_IsSsbAllowed(*ptCi, pMeasObj->ssbFrequency))
    {
        if (DBG->flag.logRrcReleaseInfo)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "(CRP) check FnVCCB_IsSsbAllowed (freq:%u)\n", pMeasObj->ssbFrequency);
        }
        return false;
    }

    // Scheduled to delete temporary code.
    if (DBG->flag.logRrcReleaseInfo)
    {
        VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "(CRP) FnVCCB_IsValid_MeasObj_CellReselection (freq:%u/restrictFlag:%u)\n", pMeasObj->ssbFrequency, restrictedFrequencyCheckFlag);
    }


#ifdef FGR_MC1015_26B
    if (restrictedFrequencyCheckFlag && FnVCCB_IsPingPongAvoidanceNrRestriction(*ptCi, *pMeasObj))
    {
        if (DBG->flag.logRrcReleaseInfo)
        {
            VCCB_PRINT_CALL_INFORMATIVE(
                ptCi, "(CRP) check FnVCCB_IsPingPongAvoidanceNrRestriction (freq:%u)\n", pMeasObj->ssbFrequency);
        }
        return false;
    }
#endif

    return true;
}

/**
 * @brief  Filling in NRRRC_FreqPriorityNR part of RRC Message IEs for CellReselectionInfo IEs to send it from CU to DU
 * @param  ptCi           : pointer to UE Context base on which message is filled in
 * @param  ptIE           : pointer to NRRRC_CellReselectionPriorities IE of RRCRelease structure to be filled in
 * @return int8_t         : Number of NR frequency priority items set in IE. Returns -1 on error.
 */
int8_t CellReselectionInfoRFSP::Fill_CellReselectionPrioritiesNR(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    int8_t numCandidateNrFreqItems = 0;
    int8_t numNrFreqItems = 0;
    uint8_t freqIdx = 0;
    rfspFreqItem_type candidatesNrFreqItems[MAX_NUM_RFSP_NR_FREQS];  // Sorting 8 SA capable frequencies with highest
                                                                     // cellreselectionPriority/subpriority from Max 20

    // 22B_CAC-Triggered Redirection
    uint8_t equippedNrFreqNum = 0;
    uint8_t numIntraFrequency = 0;
    uint8_t selectedPriority = 0;
    uint8_t selectedMaxSubPriority = 0;

    if (0 != fnGlobalValueAlloc(
                 (uint8_t **)&ptIE->freqPriorityListNR, sizeof(*ptIE->freqPriorityListNR) * MAX_NUM_RFSP_FREQS))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: fnGlobalValueAlloc failed in %s\n", __FUNCTION__);
        return ERROR;
    }

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    for (freqIdx = 0; freqIdx < MAX_NUM_RFSP_NR_FREQS; freqIdx++)
    {
        rfspFreqItem_type *pNrFreqItems = &(_pSrc->nrFreqItems[freqIdx]);

        if (CI_use != pNrFreqItems->usage)
        {
            continue;
        }

        uint8_t measObjIndex = pNrFreqItems->targetMeasObjectEntriesindex;
        VCCB_CHECK_E_RANGE_AND_RETURN(measObjIndex, MAX_NR_OF_OBJECT_ID_DB);

        if (!FnVCCB_IsValid_MeasObj_CellReselection(ptCi, measObjIndex))
        {
            continue;
        }

        rfspFreqItem_type *pCandidateNrFreqItem = &(candidatesNrFreqItems[numCandidateNrFreqItems]);
        memcpy(pCandidateNrFreqItem, pNrFreqItems, sizeof(rfspFreqItem_type));
        numCandidateNrFreqItems++;
    }

    VCCB_CANDIDATES_NR_FREQ_ITEMS_PRINT("STEP1-- -", candidatesNrFreqItems, numCandidateNrFreqItems);
    qsort(candidatesNrFreqItems, (size_t)numCandidateNrFreqItems, sizeof(rfspFreqItem_type),
        VLIB_QsortCandidateNrFreqItemsDescendingOrder);
    VCCB_CANDIDATES_NR_FREQ_ITEMS_PRINT("STEP2-- -", candidatesNrFreqItems, numCandidateNrFreqItems);

    for (freqIdx = 0; freqIdx < MIN(numCandidateNrFreqItems, MAX_NUM_RFSP_FREQS); freqIdx++)
    {
        rfspFreqItem_type *pCandidateNrFreqItems = &(candidatesNrFreqItems[freqIdx]);

        if (CI_use != pCandidateNrFreqItems->usage)
        {
            continue;
        }

        equippedNrFreqNum++;

        uint8_t measObjIndex = pCandidateNrFreqItems->targetMeasObjectEntriesindex;
        VCCB_CHECK_E_RANGE_AND_RETURN(measObjIndex, MAX_NR_OF_OBJECT_ID_DB);
        measurementObjectNRBaseDb_type *pMeasObj = &(pCell->measurementsData.measurementObjectsNRDb[measObjIndex].base);

        if (!FnVCCB_IsValid_MeasObj_CellReselection(ptCi, measObjIndex))
        {
            continue;
        }

        NRRRC_FreqPriorityNR *pDst = &(ptIE->freqPriorityListNR[numNrFreqItems].value);

        pDst->bit_mask = 0;
        pDst->carrierFreq = pMeasObj->ssbFrequency;

        if (_isRedirTriggeredByFallbackOrSpecificSlice &&
            (pCandidateNrFreqItems->cellReselectionPriority > 0))
        {
            // Using -1 value to make Eutra frequency high priority
            pDst->cellReselectionPriority =
                (NRRRC_CellReselectionPriority)(pCandidateNrFreqItems->cellReselectionPriority - 1);
        }
        else
        {
            pDst->cellReselectionPriority = pCandidateNrFreqItems->cellReselectionPriority;
        }

        if (CI_use == pCandidateNrFreqItems->cellReselectionSubpriorityUsage)
        {
            pDst->bit_mask |= NRRRC_FreqPriorityNR_cellReselectionSubPriority_present;
            pDst->cellReselectionSubPriority =
                (NRRRC_CellReselectionSubPriority)pCandidateNrFreqItems->cellReselectionSubpriority;
        }

        if (IS_CAC_TRIGGERED_REDIRECTION_CASE(ptCi))
        {
            if (pMeasObj->ssbFrequency == pCell->ssbArfcn)
            {
                numIntraFrequency++;
            }
            else
            {
                if ((CI_use != ptCi->cacTriggeredRedirInfo.usage) ||
                    (selectedPriority < pCandidateNrFreqItems->cellReselectionPriority) ||
                    ((selectedPriority == pCandidateNrFreqItems->cellReselectionPriority) &&
                        (CI_use == pCandidateNrFreqItems->cellReselectionSubpriorityUsage) &&
                        (selectedMaxSubPriority < pCandidateNrFreqItems->cellReselectionSubpriority)))
                {
                    ptCi->cacTriggeredRedirInfo.nr.ssbFrequency = pMeasObj->ssbFrequency;
                    ptCi->cacTriggeredRedirInfo.nr.ssbSubcarrierSpacing =
                        (enumSubcarrierSpacing)pMeasObj->ssbSubcarrierSpacing;
                    ptCi->cacTriggeredRedirInfo.nr.smtc1 = pMeasObj->smtc1;
                    ptCi->cacTriggeredRedirInfo.usage = CI_use;

                    selectedPriority = pCandidateNrFreqItems->cellReselectionPriority;
                    if (CI_use == pCandidateNrFreqItems->cellReselectionSubpriorityUsage)
                    {
                        selectedMaxSubPriority = pCandidateNrFreqItems->cellReselectionSubpriority;
                    }
                    else
                    {
                        selectedMaxSubPriority = 0;
                    }
                }
            }
        }

        numNrFreqItems++;
    }

    if (IS_CAC_TRIGGERED_REDIRECTION_CASE(ptCi))
    {
        if (equippedNrFreqNum == 0)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "no equipped nr frequency %s\n", __FUNCTION__);
            return 0;
        }

        if ((numNrFreqItems == 0) || (numNrFreqItems == numIntraFrequency))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "no frequency / no InterFrequency %s\n", __FUNCTION__);
            return ERROR;
        }
    }

    if (0 < numNrFreqItems)
    {
        short status = fnConnectLinkedList(ptIE->freqPriorityListNR, sizeof(*ptIE->freqPriorityListNR), numNrFreqItems);
        if (0 != status)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "ERROR fnConnectLinkedList(NRRRC_FreqPriorityListNR_) failed in %s\n", __FUNCTION__);
            return ERROR;
        }
        ptIE->bit_mask |= NRRRC_freqPriorityListNR_present;
    }

    return numNrFreqItems;
}

/**
 * @brief  Filling in NRRRC_FreqPriorityEUTRA part of RRC Message IEs for CellReselectionInfo IEs to send it from CU to
 * DU
 * @param  ptCi           : pointer to UE Context base on which message is filled in
 * @param  ptIE           : pointer to NRRRC_CellReselectionPriorities IE of RRCRelease structure to be filled in
 * @return int8_t         : Number of EUTRA frequency priority items set in IE. Returns -1 on error.
 */
int8_t CellReselectionInfoRFSP::Fill_CellReselectionPrioritiesEUTRA(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    int8_t numEutraFreqItems = 0;
    uint8_t freqIdx = 0;
    measurementObjectEUTRABaseDb_type *pMeasObj = NULL;
    NRRRC_FreqPriorityEUTRA *pDst = NULL;

    if (fnGlobalValueAlloc(
            (uint8_t **)&ptIE->freqPriorityListEUTRA, sizeof(*ptIE->freqPriorityListEUTRA) * MAX_NUM_RFSP_FREQS) != 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: fnGlobalValueAlloc failed in %s\n", __FUNCTION__);
        return ERROR;
    }

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    for (freqIdx = 0; freqIdx < MAX_NUM_RFSP_FREQS; freqIdx++)
    {
        rfspFreqItem_type *pEutraFreqItems = &(_pSrc->eutraFreqItems[freqIdx]);

        if (CI_use != pEutraFreqItems->usage)
        {
            continue;
        }

        uint8_t measObjIndex = pEutraFreqItems->targetMeasObjectEntriesindex;
        VCCB_CHECK_E_RANGE_AND_RETURN(measObjIndex, MAX_NR_OF_OBJECTEUTRA_ID_DB);
        pMeasObj = &(pCell->measurementsData.measurementObjectsEUTRADb[measObjIndex].base);
        uint32_t carrierFreq = pMeasObj->carrierFreq;

        if (BAND_NOT_FOUND == VCCB_GetMoEutraBandForUe(ptCi, pMeasObj, &carrierFreq))
        {
            // not supported by UE
            continue;
        }

        pDst = &(ptIE->freqPriorityListEUTRA[numEutraFreqItems].value);

        pDst->bit_mask = 0;
        pDst->carrierFreq = carrierFreq;
        pDst->cellReselectionPriority = pEutraFreqItems->cellReselectionPriority;
        if (CI_use == pEutraFreqItems->cellReselectionSubpriorityUsage)
        {
            pDst->bit_mask |= NRRRC_FreqPriorityEUTRA_cellReselectionSubPriority_present;
            pDst->cellReselectionSubPriority =
                (NRRRC_CellReselectionSubPriority)pEutraFreqItems->cellReselectionSubpriority;
        }
        numEutraFreqItems++;
    }

    if (0 < numEutraFreqItems)
    {
        short status =
            fnConnectLinkedList(ptIE->freqPriorityListEUTRA, sizeof(*ptIE->freqPriorityListEUTRA), numEutraFreqItems);
        if (0 != status)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "ERROR fnConnectLinkedList(NRRRC_FreqPriorityListEUTRA_) failed in %s\n", __FUNCTION__);
            return ERROR;
        }
        ptIE->bit_mask |= NRRRC_freqPriorityListEUTRA_present;
    }

    return numEutraFreqItems;
}

int16_t VCCB_GetRfspControlInfoForCellReselection(
    const callInfo_type &rCi, cellRfspBasedCtrl_type &rRfspInfo, rfspBasedCtrl_type **ppCellReselect)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ppCellReselect);

    const uint32_t ueServedPlmn = rCi.ueInfo.servedPlmn.longId;
    const uint16_t ueRFSP = rCi.ueInfo.rfsp.indexToRFSP;
    uint8_t plmnIndex = MAX_PLMN_INDEX, rfspIndex = MAX_RFSP_INDEX;
    rfspBasedCtrl_type *pRsrpBasedCtrl = nullptr;

    if ((0 == ueServedPlmn) || (NO_RFSP_VALUE == ueRFSP))
    {
        return BREAK;
    }

    // Search for PLMN and RFSP index
    for (plmnIndex = 0; plmnIndex < MAX_PLMN_INDEX; plmnIndex++)
    {
        if (CI_use != rRfspInfo.plmnRfspBasedCtrl[plmnIndex].usage ||
            rRfspInfo.plmnRfspBasedCtrl[plmnIndex].plmn.longId != ueServedPlmn)
        {
            continue;
        }
        if (VCCB_IsRedCapUeForSA(rCi))
        {
            for (rfspIndex = 0; rfspIndex < MAX_RFSP_INDEX; rfspIndex++)
            {
                pRsrpBasedCtrl = &rRfspInfo.plmnRfspBasedCtrl[plmnIndex].redcapRfspBasedCtrl[rfspIndex];
                if (CI_use == pRsrpBasedCtrl->usage && ueRFSP == pRsrpBasedCtrl->rfsp &&
                    (both == pRsrpBasedCtrl->controlOption || cell_reselection == pRsrpBasedCtrl->controlOption))
                {
                    *ppCellReselect = pRsrpBasedCtrl;
                    break;
                }
            }
        }
        if (NULL == *ppCellReselect)
        {
            for (rfspIndex = 0; rfspIndex < MAX_RFSP_INDEX; rfspIndex++)
            {
                pRsrpBasedCtrl = &rRfspInfo.plmnRfspBasedCtrl[plmnIndex].rfspBasedCtrl[rfspIndex];
                if (CI_use == pRsrpBasedCtrl->usage && ueRFSP == pRsrpBasedCtrl->rfsp &&
                    (both == pRsrpBasedCtrl->controlOption || cell_reselection == pRsrpBasedCtrl->controlOption))
                {
                    *ppCellReselect = pRsrpBasedCtrl;
                    break;
                }
            }
        }
        if (NULL != *ppCellReselect)
        {
            return GOOD;
        }
    }

    if (NULL == *ppCellReselect)
    {
        VCCB_PRINT_CALL_COMMENT(
            &rCi, "PLMN(0x%06X) and RFSP(%u) not found for cell reselection.\n", ueServedPlmn, ueRFSP);
        return BREAK;
    }

    return ERROR;
}

/**
 * @brief Filling in RRC Message IEs for CellReselectionInfoRFSP IEs to send it from CU to DU
 * @param  ptCi           : pointer to UE Context base on which message is filled in
 * @param  ptIE           : pointer to IE of RRCRelease structure to be filled in
 * @return int16_t        : result of operation
 */
int8_t CellReselectionInfoRFSP::Fill_CellReselectionInfo(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    cellRfspBasedCtrl_type *pRfspInfo = &pCell->cellRfspBasedCtrl;
    rfspBasedCtrl_type *pCellReselect = NULL;
    int8_t numNrFreqItems = 0, numEutraFreqItems = 0;

    if (_hasEutraFreqPriorityList == FALSE)
    {
        ptIE->bit_mask = 0;
    }

    if (GOOD != VCCB_GetRfspControlInfoForCellReselection(*ptCi, *pRfspInfo, &pCellReselect))
    {
        return BREAK;
    }

    _pSrc = pCellReselect;
    _isRedirTriggeredByFallbackOrSpecificSlice =
        ((IS_FALLBACK_CASE(ptCi) || IS_SPECIFIC_SLICE_REDIRECTION(ptCi)) && (_hasEutraFreqPriorityList == TRUE));
    numNrFreqItems = Fill_CellReselectionPrioritiesNR(ptCi, ptIE);
    if (ERROR == numNrFreqItems)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Fill_CellReselectionPrioritiesNR ERROR!!\n");
    }

    // Fallback also using RFSP Algorithm for NR
    if (_isRedirTriggeredByFallbackOrSpecificSlice)
    {
        if (numNrFreqItems > 0)
        {
            // No more progress. : EUTRA is already made for Fallback
            return GOOD;
        }
        else
        {
            return BREAK;
        }
    }
    else if (IS_CAC_TRIGGERED_REDIRECTION_CASE(ptCi))
    {
        if (numNrFreqItems == 0)
        {
            return BREAK;
        }
        else if (ERROR == numNrFreqItems)
        {
            return ERROR;
        }
    }

    numEutraFreqItems = Fill_CellReselectionPrioritiesEUTRA(ptCi, ptIE);
    if (ERROR == numEutraFreqItems)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Fill_CellReselectionPrioritiesEUTRA ERROR!!\n");
    }

    // If any items were set, set T320 timer
    if ((numEutraFreqItems > 0) || (numNrFreqItems > 0))
    {
        ptIE->bit_mask |= NRRRC_t320_present;
        ptIE->t320 = (NRRRC__enum228)pRfspInfo->t320;
    }

    if (0 == ptIE->bit_mask)
    {
        return BREAK;
    }

    return GOOD;
}

int16_t FnVCCB_GetServiceGroupIdByServedPlmn(
    uint8_t ueSvcGrpId, callInfo_type *ptCi, SvcBasedCrpCtrl_type **pCellReselect)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    uint8_t svcGrpIdx = MIN_SVC_GRP_CONFIG_ID;  // 1
    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];

    uint32_t ueServedPlmn = ptCi->ueInfo.servedPlmn.longId;
    if (0 == ueServedPlmn)
    {
        return BREAK;
    }

    if (0xFF == ueSvcGrpId)
    {
        // Get Service Group of UE for every PDU Session Information change
        uint8_t isReleaseProcedure = TRUE;  // TRUE : Count 'S_Release' PDU as a service group candidate.
        if (GOOD != FnVCCB_GetServiceGroupId(ptCi, &ueSvcGrpId, isReleaseProcedure))
        {
            VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] [%s]Service Group not exist\n", __FUNCTION__);
            return BREAK;
        }
    }

    VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] [%s]ServiceGroupId : (%d)\n", __FUNCTION__, ueSvcGrpId);
    // Search for 'service group id'
    uint8_t findFlag = FALSE;

    // valid svcGrpIdx : 1~32
    for (svcGrpIdx = MIN_SVC_GRP_CONFIG_ID; svcGrpIdx < MAX_SVC_GRP_DB_NUM; svcGrpIdx++)
    {
        SvcBasedCrpCtrl_type *pSvcBasedCrp = &pCell->SvcBasedCrpCtrl[svcGrpIdx];
        if (pSvcBasedCrp->usage != CI_use) continue;
        if (ueSvcGrpId == pSvcBasedCrp->svcGroupId)
        {
            *pCellReselect = pSvcBasedCrp;
            findFlag = TRUE;
            break;
        }
    }

    if (FALSE == findFlag)
    {
        VCCB_PRINT_CALL_MSG(
            ptCi, "PLMN(%d) and Service group(%d) not found for cell reselection.\n", ueServedPlmn, ueSvcGrpId);
        return BREAK;
    }

    return GOOD;
}

/**
 * @brief  Filling in NRRRC_FreqPriorityNR part of RRC Message IEs for CellReselectionInfo IEs to send it from CU to DU
 * @param  ptCi           : pointer to UE Context base on which message is filled in
 * @param  ptIE           : pointer to NRRRC_CellReselectionPriorities IE of RRCRelease structure to be filled in
 * @return int8_t         : Number of NR frequency priority items set in IE. Returns -1 on error.
 */
int8_t CellReselectionInfoSvcBasedMobilityControl::Fill_CellReselectionPrioritiesNR(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    uint8_t numNrFreqItems = 0, svcGrpIdx = 0;

    // 22B_CAC-Triggered Redirection
    uint8_t equippedNrFreqNum = 0;
    uint8_t numIntraFrequency = 0;
    uint8_t selectedPriority = 0;
    uint8_t selectedMaxSubPriority = 0;

    // NR Freq
    if (0 != fnGlobalValueAlloc(
                 (uint8_t **)&ptIE->freqPriorityListNR, sizeof(*ptIE->freqPriorityListNR) * MAX_NUM_SVC_FREQS))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: fnGlobalValueAlloc failed in %s\n", __FUNCTION__);
        return ERROR;
    }

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    for (svcGrpIdx = 0; svcGrpIdx < MAX_NUM_SVC_FREQS; svcGrpIdx++)
    {
        svcFreqNrItem_type *pNrFreqItems = &(_pSrc->nrFreqItems[svcGrpIdx]);
        if (CI_use != pNrFreqItems->usage) continue;

        equippedNrFreqNum++;

        uint8_t measObjIndex = pNrFreqItems->targetMeasObjectEntriesindex;
        VCCB_CHECK_E_RANGE_AND_RETURN(measObjIndex, MAX_NR_OF_OBJECT_ID_DB);
        measurementObjectNRBaseDb_type *pMeasObj = &(pCell->measurementsData.measurementObjectsNRDb[measObjIndex].base);

        if (!FnVCCB_IsValid_MeasObj_CellReselection(ptCi, measObjIndex))
        {
            continue;
        }

        NRRRC_FreqPriorityNR *pDst = &(ptIE->freqPriorityListNR[numNrFreqItems].value);

        pDst->bit_mask = 0;
        pDst->carrierFreq = pMeasObj->ssbFrequency;
        if (IS_FALLBACK_CASE(ptCi) && (_fallbackEutraExistFlag == TRUE) && (pNrFreqItems->dedicatedPriority > 0))
        {
            // Using -1 value to make Eutra frequency high priority
            pDst->cellReselectionPriority = (NRRRC_CellReselectionPriority)(pNrFreqItems->dedicatedPriority - 1);
        }
        else
        {
            pDst->cellReselectionPriority = pNrFreqItems->dedicatedPriority;
        }

        if (CI_use == pNrFreqItems->dedicatedSubpriorityUsage)
        {
            pDst->bit_mask |= NRRRC_FreqPriorityNR_cellReselectionSubPriority_present;
            pDst->cellReselectionSubPriority = (NRRRC_CellReselectionSubPriority)pNrFreqItems->dedicatedSubpriority;
        }

        if (IS_CAC_TRIGGERED_REDIRECTION_CASE(ptCi))
        {
            if (pMeasObj->ssbFrequency == pCell->ssbArfcn)
            {
                numIntraFrequency++;
            }
            else
            {
                if ((CI_use != ptCi->cacTriggeredRedirInfo.usage) ||
                    (selectedPriority < pNrFreqItems->dedicatedPriority) ||
                    ((selectedPriority == pNrFreqItems->dedicatedPriority) &&
                        (CI_use == pNrFreqItems->dedicatedSubpriorityUsage) &&
                        (selectedMaxSubPriority < pNrFreqItems->dedicatedSubpriority)))
                {
                    ptCi->cacTriggeredRedirInfo.nr.ssbFrequency = pMeasObj->ssbFrequency;
                    ptCi->cacTriggeredRedirInfo.nr.ssbSubcarrierSpacing =
                        (enumSubcarrierSpacing)pMeasObj->ssbSubcarrierSpacing;
                    ptCi->cacTriggeredRedirInfo.nr.smtc1 = pMeasObj->smtc1;
                    ptCi->cacTriggeredRedirInfo.usage = CI_use;

                    selectedPriority = pNrFreqItems->dedicatedPriority;
                    if (CI_use == pNrFreqItems->dedicatedSubpriorityUsage)
                    {
                        selectedMaxSubPriority = pNrFreqItems->dedicatedSubpriority;
                    }
                    else
                    {
                        selectedMaxSubPriority = 0;
                    }
                }
            }
        }

        numNrFreqItems++;
    }

    if (IS_CAC_TRIGGERED_REDIRECTION_CASE(ptCi))
    {
        if (equippedNrFreqNum == 0)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "no equipped nr frequency %s\n", __FUNCTION__);
            return 0;
        }

        if ((numNrFreqItems == 0) || (numNrFreqItems == numIntraFrequency))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "no frequency / no InterFrequency %s\n", __FUNCTION__);
            return ERROR;
        }
    }

    if (0 < numNrFreqItems)
    {
        short status = fnConnectLinkedList(ptIE->freqPriorityListNR, sizeof(*ptIE->freqPriorityListNR), numNrFreqItems);
        if (0 != status)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "ERROR fnConnectLinkedList(NRRRC_FreqPriorityListNR_) failed in %s\n", __FUNCTION__);
            return ERROR;
        }
        ptIE->bit_mask |= NRRRC_freqPriorityListNR_present;
    }

    return (int8_t)numNrFreqItems;
}

/**
 * @brief  Filling in NRRRC_FreqPriorityEUTRA part of RRC Message IEs for CellReselectionInfo IEs to send it from CU to
 * DU
 * @param  ptCi           : pointer to UE Context base on which message is filled in
 * @param  ptIE           : pointer to NRRRC_CellReselectionPriorities IE of RRCRelease structure to be filled in
 * @return int8_t         : Number of EUTRA frequency priority items set in IE. Returns -1 on error.
 */
int8_t CellReselectionInfoSvcBasedMobilityControl::Fill_CellReselectionPrioritiesEUTRA(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    int8_t numEutraFreqItems = 0;
    uint8_t freqIdx = 0;
    measurementObjectEUTRABaseDb_type *pMeasObj = NULL;
    NRRRC_FreqPriorityEUTRA *pDst = NULL;

    if (fnGlobalValueAlloc(
            (uint8_t **)&ptIE->freqPriorityListEUTRA, sizeof(*ptIE->freqPriorityListEUTRA) * MAX_NUM_SVC_FREQS) != 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: fnGlobalValueAlloc failed in %s\n", __FUNCTION__);
        return ERROR;
    }

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    for (freqIdx = 0; freqIdx < MAX_NUM_SVC_FREQS; freqIdx++)
    {
        svcFreqEutraItem_type *pEutraFreqItems = &(_pSrc->eutraFreqItems[freqIdx]);

        if (CI_use != pEutraFreqItems->usage)
        {
            continue;
        }

        uint8_t measObjIndex = pEutraFreqItems->targetMeasObjectEutraEntriesindex;
        VCCB_CHECK_E_RANGE_AND_RETURN(measObjIndex, MAX_NR_OF_OBJECTEUTRA_ID_DB);
        pMeasObj = &(pCell->measurementsData.measurementObjectsEUTRADb[measObjIndex].base);
        uint32_t carrierFreq = pMeasObj->carrierFreq;

        if (BAND_NOT_FOUND == VCCB_GetMoEutraBandForUe(ptCi, pMeasObj, &carrierFreq))
        {
            // not supported by UE
            continue;
        }

        pDst = &(ptIE->freqPriorityListEUTRA[numEutraFreqItems].value);

        pDst->bit_mask = 0;
        pDst->carrierFreq = carrierFreq;
        pDst->cellReselectionPriority = pEutraFreqItems->dedicatedPriority;
        if (CI_use == pEutraFreqItems->dedicatedSubpriorityUsage)
        {
            pDst->bit_mask |= NRRRC_FreqPriorityEUTRA_cellReselectionSubPriority_present;
            pDst->cellReselectionSubPriority = (NRRRC_CellReselectionSubPriority)pEutraFreqItems->dedicatedSubpriority;
        }
        numEutraFreqItems++;
    }

    if (0 < numEutraFreqItems)
    {
        short status =
            fnConnectLinkedList(ptIE->freqPriorityListEUTRA, sizeof(*ptIE->freqPriorityListEUTRA), numEutraFreqItems);
        if (0 != status)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "ERROR fnConnectLinkedList(NRRRC_FreqPriorityListEUTRA_) failed in %s\n", __FUNCTION__);
            return ERROR;
        }
        ptIE->bit_mask |= NRRRC_freqPriorityListEUTRA_present;
    }

    return numEutraFreqItems;
}

// SVR26A FGR-MC1019
uint8_t FnVCCB_GetNumofFreqBySAMMBasedCRP(
    int cellNum, nrSammCellSvcGrpData_type *pCellSvcGrpData, SvcBasedCrpCtrl_type *pSammCrp)
{
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, 0);
    VALID_E_POINT_CHECK_RET_VAL(pCellSvcGrpData, 0);
    VALID_E_POINT_CHECK_RET_VAL(pSammCrp, 0);

    uint8_t numSammNrFreqItems = 0;

    for (auto iter: pCellSvcGrpData->freqInfo)
    {
        if (iter.usage != CI_use) continue;

        uint8_t objIdx = INVALID_OBJECT_ID;     // 0xFF

        if (FnVCCB_FindMeasObjectUsingFrequency((CellNum_type)cellNum, iter.ssbFreq, &objIdx) != NULL)
        {
            pSammCrp->nrFreqItems[numSammNrFreqItems].targetMeasObjectType = 
                (objIdx == INTRAFREQ_OBJECT_IDX) ? 0 : 1;
            pSammCrp->nrFreqItems[numSammNrFreqItems].usage = CI_use;
            pSammCrp->nrFreqItems[numSammNrFreqItems].targetMeasObjectEntriesindex = objIdx;
            pSammCrp->nrFreqItems[numSammNrFreqItems].dedicatedPriority = iter.dedicatedPriority;
            pSammCrp->nrFreqItems[numSammNrFreqItems].dedicatedSubpriorityUsage = iter.dedicatedSubpriorityUsage;
            pSammCrp->nrFreqItems[numSammNrFreqItems].dedicatedSubpriority = iter.dedicatedSubpriority;
            pSammCrp->nrFreqItems[numSammNrFreqItems].serviceUeDistRatio = 100; // default value @YANG
            numSammNrFreqItems++;
        }
    }
    return numSammNrFreqItems;
}

// SVR26A FGR-MC1019
bool FnVCCB_IsSupportedSAMMBasedCRP(
    uint16_t gnbNum, uint16_t cellNum, uint16_t svcGrpIdx, SvcBasedCrpCtrl_type *pCellReselectSAMM)
{
    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, false);
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, 0);
    VCCB_CHECK_E_RANGE_AND_VAL(svcGrpIdx, MAX_SVC_GROUP_NUM, false);    // 32 + 1
    VALID_E_POINT_CHECK_ERROR(pCellReselectSAMM);

    VccbCellInfo_type &rCell = CELLINFO[cellNum];

    // cond' 1: support SAMM-based CRP?
    if (GNBINFO[gnbNum].sammConfig.idleMobilityForServiceSwitch == VCCB_FLAG_OFF) return false;

    // cond' 2: NR SAMM enabled?
    nrSammParameterSet_type sammParamSet = {};
    if (not FnVCCB_IsSammParaConfigSupported(rCell, &sammParamSet))
    {
        return false;
    }

    // cond' 3, 4
    // decision on whether UE supports the SAMM function
    if (sammParamSet.svcGrpData[svcGrpIdx].usage != CI_use)
    {
        return false;
    }

    uint8_t numSammFreqItems = FnVCCB_GetNumofFreqBySAMMBasedCRP(cellNum, &sammParamSet.svcGrpData[svcGrpIdx], pCellReselectSAMM);

    if (numSammFreqItems == 0)
    {
        return false;
    }

    return true;
}



/**
 * @brief Filling in RRC Message IEs for CellReselectionInfoBasedService IEs to send it from CU to DU
 * @param  ptCi           : pointer to UE Context base on which message is filled in
 * @param  ptIE           : pointer to IE of RRCRelease structure to be filled in
 * @return int8_t         : result of operation
 */
int8_t CellReselectionInfoSvcBasedMobilityControl::Fill_CellReselectionInfo(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);

    SvcBasedCrpCtrl_type *pCellReselect = NULL;
    SvcBasedCrpCtrl_type cellReselectSAMM;
    uint32_t ueServedPlmn = ptCi->ueInfo.servedPlmn.longId;
    int8_t numNrFreqItems = 0, numEutraFreqItems = 0;

    if (_fallbackEutraExistFlag == FALSE)
    {
        ptIE->bit_mask = 0;
    }

    uint8_t ueSvcGrpId = 0xFF;
    if (GOOD != FnVCCB_GetServiceGroupIdByServedPlmn(ueSvcGrpId, ptCi, &pCellReselect))
    {
        VCCB_PRINT_CALL_MSG(ptCi, "[%s]FnVCCB_GetServiceGroupIdByServedPlmn error\n", __FUNCTION__);
        return BREAK;
    }

    ueSvcGrpId = pCellReselect->svcGroupId;

    // SVR26A FGR-MC1019: Check if SAMM-based CRP is supported..
    if (FnVCCB_IsSupportedSAMMBasedCRP(ptCi->gnbNum, ptCi->servCellNum, ueSvcGrpId, &cellReselectSAMM) == true)
    {
        _pSrc = &cellReselectSAMM;

        // Populate idle mobility parameters from SvcBasedCrpCtrl_type, keyed by ssb-frequency.
        numNrFreqItems = Fill_CellReselectionPrioritiesNR(ptCi, ptIE);

        // However, if the ssb-frequency (used as a key in SAMM DB and SvcBasedCrpCtrl_type) is invalid in the measObject,
        // Fallback: Use RAN-based DB for SvcBasedCrpCtrl_type and reset NR frequency items.
        if (numNrFreqItems == 0 || numNrFreqItems == ERROR)
            numNrFreqItems = 0;
    }

    _pSrc = pCellReselect;

    if (numNrFreqItems == 0)
    {
        numNrFreqItems = Fill_CellReselectionPrioritiesNR(ptCi, ptIE);
        if (ERROR == numNrFreqItems)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Fill_CellReselectionPrioritiesNR ERROR!!\n");
        }
    }

    // Fallback also using Service Algorithm for NR
    if (IS_FALLBACK_CASE(ptCi) && (_fallbackEutraExistFlag == TRUE))
    {
        if (numNrFreqItems > 0)
        {
            // No more progress. : EUTRA is already made for Fallback
            return GOOD;
        }
        else
        {
            return BREAK;
        }
    }
    else if (IS_CAC_TRIGGERED_REDIRECTION_CASE(ptCi))
    {
        if (numNrFreqItems == 0)
        {
            return BREAK;
        }
        else if (ERROR == numNrFreqItems)
        {
            return ERROR;
        }
    }

    numEutraFreqItems = Fill_CellReselectionPrioritiesEUTRA(ptCi, ptIE);
    if (ERROR == numEutraFreqItems)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Fill_CellReselectionPrioritiesEUTRA ERROR!!\n");
    }

    // If any items were set, set T320 timer
    if ((numEutraFreqItems == 0) && (numNrFreqItems == 0))
    {
        VCCB_PRINT_CALL_MSG(ptCi, "FreqItems not Found. PLMN(%d)\n", ueServedPlmn);
        return BREAK;
    }

    Fill_T320(ptIE, static_cast<NRRRC__enum228>(pCellReselect->t320));

    return GOOD;
}

/**
 * @brief Fills the cell reselection information based on PLMN mobility control for a given call instance.
 * @param  ptCi           : pointer to UE Context base on which message is filled in
 * @param  ptIE           : pointer to IE of RRCRelease structure to be filled in
 * @retval GOOD: Indicates successful completion of the function.
 * @retval BREAK: Indicates an error occurred during processing.
 */
int8_t CellReselectionInfoPlmnBasedMobilityControl::Fill_CellReselectionInfo(
    callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    uint8_t servedPlmnIndex = VLIB_FindGnbPlmnIndexOfCall(ptCi);
    if (servedPlmnIndex >= MAX_PLMN_INDEX)
    {
        if (DBG->flag.logRrcReleaseInfo)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                "(CRP) check servedPlmnIndex (plmn:0x%0x) in "
                "CellReselectionInfoPlmnBasedMobilityControl::Fill_CellReselectionInfo\n",
                ptCi->ueInfo.servedPlmn.longId);
        }
        return BREAK;
    }

    int8_t numNrFreqItems = 0, numEutraFreqItems = 0, plmnIndex = 0;
    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    for (plmnIndex = 0; plmnIndex < MAX_PLMN_INDEX; plmnIndex++)
    {
        if (pCell->plmnBasedDedicatedPriority[plmnIndex].usage == CI_use &&
            pCell->plmnBasedDedicatedPriority[plmnIndex].plmnIndex == servedPlmnIndex)
        {
            _pCellReselect = &pCell->plmnBasedDedicatedPriority[plmnIndex];
            break;
        }
    }

    if (plmnIndex == MAX_PLMN_INDEX)
    {
        if (DBG->flag.logRrcReleaseInfo)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                "(CRP) There is no matching plmnIndex (servedPlmnIndex:%d) in "
                "CellReselectionInfoPlmnBasedMobilityControl::Fill_CellReselectionInfo\n",
                servedPlmnIndex);
        }
        return BREAK;
    }

    numNrFreqItems = Fill_CellReselectionPrioritiesNR(ptCi, ptIE);
    if (ERROR == numNrFreqItems)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "(CRP) CellReselectionInfoPlmnBasedMobilityControl::Fill_CellReselectionPrioritiesNR ERROR!!\n");
    }

    numEutraFreqItems = Fill_CellReselectionPrioritiesEUTRA(ptCi, ptIE);
    if (ERROR == numEutraFreqItems)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "(CRP) CellReselectionInfoPlmnBasedMobilityControl::Fill_CellReselectionPrioritiesEUTRA ERROR!!\n");
    }

    if (numEutraFreqItems > 0 || numNrFreqItems > 0)
    {
        Fill_T320(ptIE, static_cast<NRRRC__enum228>(pCell->cellRfspBasedCtrl.t320));

        return GOOD;
    }

    if (DBG->flag.logRrcReleaseInfo)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "(CRP) FreqItems not Found. PLMN(%d)\n", ptCi->ueInfo.servedPlmn.longId);
    }

    return BREAK;
}

/**
 * @brief Fills the NR cell reselection priorities structure based on PLMN-based mobility control.
 * @param  ptCi           : pointer to UE Context base on which message is filled in
 * @param  ptIE           : pointer to IE of RRCRelease structure to be filled in
 * @retval ERROR: An error occurred during the operation.
 * @retval numNrFreqItems: The number of valid frequency priority items added to ptIE.
 */
int8_t CellReselectionInfoPlmnBasedMobilityControl::Fill_CellReselectionPrioritiesNR(
    callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    int8_t numNrFreqItems = 0;

    if (0 != fnGlobalValueAlloc(
                 (uint8_t **)&ptIE->freqPriorityListNR, sizeof(*ptIE->freqPriorityListNR) * MAX_NUM_PLMN_BASED_FREQS))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "(CRP) ERROR: fnGlobalValueAlloc failed in %s\n", __FUNCTION__);
        return ERROR;
    }

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    for (uint8_t freqIdx = 0; freqIdx < MAX_NUM_PLMN_BASED_FREQS; freqIdx++)
    {
        plmnBasedFreqItem_type *pNrFreqItems = &(_pCellReselect->nrFreqItems[freqIdx]);
        if (CI_use != pNrFreqItems->usage) continue;

        uint8_t measObjIndex = pNrFreqItems->targetMeasObjectEntriesIndex;
        VCCB_CHECK_E_RANGE_AND_RETURN(measObjIndex, MAX_NR_OF_OBJECT_ID_DB);
        measurementObjectNRBaseDb_type *pMeasObj = &(pCell->measurementsData.measurementObjectsNRDb[measObjIndex].base);

        if (FnVCCB_IsValid_MeasObj_CellReselection(ptCi, measObjIndex, true) == false)
        {
            continue;
        }

        NRRRC_FreqPriorityNR *pDst = &(ptIE->freqPriorityListNR[numNrFreqItems].value);
        pDst->bit_mask = 0;
        pDst->carrierFreq = pMeasObj->ssbFrequency;
        pDst->cellReselectionPriority = pNrFreqItems->dedicatedPriority;
        if (CI_use == pNrFreqItems->dedicatedSubpriorityUsage)
        {
            pDst->bit_mask |= NRRRC_FreqPriorityNR_cellReselectionSubPriority_present;
            pDst->cellReselectionSubPriority = (NRRRC_CellReselectionSubPriority)pNrFreqItems->dedicatedSubpriority;
        }

        numNrFreqItems++;
    }

    if (0 < numNrFreqItems)
    {
        short status = fnConnectLinkedList(ptIE->freqPriorityListNR, sizeof(*ptIE->freqPriorityListNR), numNrFreqItems);
        if (0 != status)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "(CRP) ERROR fnConnectLinkedList(NRRRC_FreqPriorityListNR_) failed in %s\n", __FUNCTION__);
            return ERROR;
        }
        ptIE->bit_mask |= NRRRC_freqPriorityListNR_present;
    }

    return numNrFreqItems;
}

/**
 * @brief Fills the EUTRA cell reselection priorities structure based on PLMN-based mobility control.
 * @param  ptCi           : pointer to UE Context base on which message is filled in
 * @param  ptIE           : pointer to IE of RRCRelease structure to be filled in
 * @retval ERROR: An error occurred during the operation.
 * @retval numEutraFreqItems: The number of valid frequency priority items added to ptIE.
 */
int8_t CellReselectionInfoPlmnBasedMobilityControl::Fill_CellReselectionPrioritiesEUTRA(
    callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    int8_t numEutraFreqItems = 0;

    if (fnGlobalValueAlloc((uint8_t **)&ptIE->freqPriorityListEUTRA,
            sizeof(*ptIE->freqPriorityListEUTRA) * MAX_NUM_PLMN_BASED_FREQS) != 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "(CRP) ERROR: fnGlobalValueAlloc failed in %s\n", __FUNCTION__);
        return ERROR;
    }

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    for (uint8_t freqIdx = 0; freqIdx < MAX_NUM_PLMN_BASED_FREQS; freqIdx++)
    {
        plmnBasedFreqItem_type *pEutraFreqItems = &(_pCellReselect->eutraFreqItems[freqIdx]);

        if (CI_use != pEutraFreqItems->usage)
        {
            continue;
        }

        uint8_t measObjIndex = pEutraFreqItems->targetMeasObjectEntriesIndex;
        VCCB_CHECK_E_RANGE_AND_RETURN(measObjIndex, MAX_NR_OF_OBJECTEUTRA_ID_DB);
        measurementObjectEUTRABaseDb_type *pMeasObj = &(pCell->measurementsData.measurementObjectsEUTRADb[measObjIndex].base);
        uint32_t carrierFreq = pMeasObj->carrierFreq;

        if (BAND_NOT_FOUND == VCCB_GetMoEutraBandForUe(ptCi, pMeasObj, &carrierFreq))
        {
            if (DBG->flag.logRrcReleaseInfo) 
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "(CRP)(PLMN) check VCCB_GetMoEutraBandForUe (freq:%u)\n", carrierFreq);
            }

            continue;
        }

        NRRRC_FreqPriorityEUTRA *pDst = &(ptIE->freqPriorityListEUTRA[numEutraFreqItems].value);
        pDst->bit_mask = 0;
        pDst->carrierFreq = carrierFreq;
        pDst->cellReselectionPriority = pEutraFreqItems->dedicatedPriority;
        if (CI_use == pEutraFreqItems->dedicatedSubpriorityUsage)
        {
            pDst->bit_mask |= NRRRC_FreqPriorityEUTRA_cellReselectionSubPriority_present;
            pDst->cellReselectionSubPriority = (NRRRC_CellReselectionSubPriority)pEutraFreqItems->dedicatedSubpriority;
        }
        numEutraFreqItems++;
    }

    if (0 < numEutraFreqItems)
    {
        short status =
            fnConnectLinkedList(ptIE->freqPriorityListEUTRA, sizeof(*ptIE->freqPriorityListEUTRA), numEutraFreqItems);
        if (0 != status)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "(CRP) ERROR fnConnectLinkedList(NRRRC_FreqPriorityListEUTRA_) failed in %s\n", __FUNCTION__);
            return ERROR;
        }
        ptIE->bit_mask |= NRRRC_freqPriorityListEUTRA_present;
    }

    return numEutraFreqItems;
}

int VLIB_QsortCandidateCellAvailableUeDescendingOrder(const void *arg1, const void *arg2)
{
    AUTO_TRACE_FUNC;

    colocCellbasedCandidateCell_type a, b;

    VALID_E_POINT_CHECK_ERROR(arg1);
    VALID_E_POINT_CHECK_ERROR(arg2);

    a = *(colocCellbasedCandidateCell_type *)arg1;
    b = *(colocCellbasedCandidateCell_type *)arg2;

    if (a.numAvailUe > b.numAvailUe)
    {
        return -1;
    }
    else if (a.numAvailUe < b.numAvailUe)
    {
        return 1;
    }

    return 0;
}

typedef struct 
{
    uint16_t registeredColocCell;
    uint16_t statusIsNotNormal;
    uint16_t nbrNotExist;
    uint16_t bandNotSupport;
    uint16_t nbrPrbRscNotAvailable;
    uint16_t nbrIsNotSaEnable;
    uint16_t nbrIsSDLCell;
    uint16_t nbrSsbIsNotAllowed;
    uint16_t ssbArfcnDuplicated;
} detailReasonCount_type;

int16_t FnVCCB_GetCandidateCell_ForColocCellbasedCAC(
        callInfo_type *ptCi, VccbCellInfo_type *pCell, uint8_t *pNum, colocCellbasedCandidateCell_type *pCandidateCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pCell);
    VALID_E_POINT_CHECK_ERROR(pNum);
    VALID_E_POINT_CHECK_ERROR(pCandidateCell);

    nbrCellInfo_type *pNbr = NULL;
    nbrGnbCellInfo_type *pNbrGnbCell = NULL;
    sonNbrPrbRsc_type *pNbrPrbRsc = NULL;
    colocCellEntries_type *pColocCellEntries = NULL;

    uint8_t numOfCandidate = 0;
    uint16_t nbrIdx = 0, candidateIdx = 0;
    detailReasonCount_type count;

    memset(&count, 0, sizeof(count));

    for (uint16_t colocCellIdx = 0; colocCellIdx < MAX_COLOCCELL; colocCellIdx++)
    {
        pColocCellEntries = &(pCell->cuColocCellInfo.colocCellEntries[colocCellIdx]);

        if (CI_use == pColocCellEntries->usage)
        {
            count.registeredColocCell++;
        }
        else
        {
            continue;
        }

        if (CaColocCellStatus_Normal != pColocCellEntries->callCurrColocCellStatus)
        {
            count.statusIsNotNormal++;
            continue;
        }

        for (nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)
        {
            pNbr = &(pCell->Nbr[nbrIdx]);

            if (EQUIP != pNbr->status) continue;

            if (GOOD != getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &pNbrGnbCell) || !pNbrGnbCell)
            {
                // Cannot find neighbor Cell
                continue;
            }

            if ((pColocCellEntries->globalGnbId.plmn.longId != pNbrGnbCell->globalGnbId.plmn.longId) ||
                (pColocCellEntries->globalGnbId.gnbId.id != pNbrGnbCell->globalGnbId.gnbId.id) ||
                (pColocCellEntries->cellId != pNbrGnbCell->cellId))
            {
                // the neighbor cell is not colocated
                continue;
            }

            if (FALSE == VHCM_isSaEnabledNbr(ptCi, pNbrGnbCell))
            {
                count.nbrIsNotSaEnable++;
                break;
            }

            if (true == FnVCCB_IsNbrSDLCell(ptCi, pNbrGnbCell))
            {
                count.nbrIsSDLCell++;
                break;
            }

            if (false == FnVCCB_IsSsbAllowed(*ptCi, pNbrGnbCell->ssbArfcn))
            {
                count.nbrSsbIsNotAllowed++;
                break;
            }

            if (BAND_NOT_FOUND == VLIB_GetFreqBandIndForNeighborCell(ptCi, pNbrGnbCell))
            {
                // the bandwidth of the colocated cell is not supported by UE
                count.bandNotSupport++;
                break;
            }

            pNbrPrbRsc = &(pCell->cellRscInfo.nbrPrb[nbrIdx]);
            if ((EQUIP != pNbrPrbRsc->usage) || (ON != pNbrPrbRsc->isRsUpdate) || (0 == pNbrPrbRsc->numAvailUe))
            {
                // not available
                count.nbrPrbRscNotAvailable++;
                break;
            }

            for (candidateIdx = 0; candidateIdx < numOfCandidate; candidateIdx++)
            {
                if (pCandidateCell[candidateIdx].ssbArfcn == pNbrGnbCell->ssbArfcn)
                {
                    break;
                }
            }

            // add neighbor info to candidate array if its frequency is not duplcated
            if (candidateIdx >= numOfCandidate)
            {
                pCandidateCell[numOfCandidate].numAvailUe = pNbrPrbRsc->numAvailUe;
                pCandidateCell[numOfCandidate].ssbArfcn = pNbrGnbCell->ssbArfcn;
                pCandidateCell[numOfCandidate].nrScsDl = pNbrGnbCell->nrScsDl;
                pCandidateCell[numOfCandidate].smtc1 = pNbrGnbCell->smtc1;
                numOfCandidate++;
            }
            else
            {
                count.ssbArfcnDuplicated++;
            }
                
            break;
        }

        if (nbrIdx == MAX_NBR_PER_CELL)
        {
            count.nbrNotExist++;
        }
    }

    if (numOfCandidate == 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "%s ERROR: no candidate cell\n", __FUNCTION__);
        VCCB_PRINT_CALL_ERROR(ptCi,
                "Fail Reason: #coloc-cell-entries:%d (#statusIsNotNormal(%d),#nbrNotExist(%d),#bandNotSupport(%d),\n",
                count.registeredColocCell, count.statusIsNotNormal, count.nbrNotExist, count.bandNotSupport);
        VCCB_PRINT_CALL_ERROR(ptCi,
                "#nbrPrbRscNotAvailable(%d), #nbrIsNotSaEnable(%d),#nbrIsSDLCell(%d),#nbrSsbIsNotAllowed(%d))\n",
                count.nbrPrbRscNotAvailable, count.nbrIsNotSaEnable, count.nbrIsSDLCell, count.nbrSsbIsNotAllowed);
        return ERROR;
    }
    else if ((numOfCandidate == 1) && (pCandidateCell[0].ssbArfcn == pCell->ssbArfcn))
    {
        // the only candidate has intra-frequency, return error
        VCCB_PRINT_CALL_ERROR(ptCi, "%s ERROR: the only candidate cell is intra-frequency\n", __FUNCTION__);
        return ERROR;
    }

    *pNum = numOfCandidate;

    return GOOD;
}

void FnVCCB_Fill_ReselectionPriority_ForColocCellbasedCAC(const uint16_t candidateIdx,  NRRRC_FreqPriorityNR *pDst)
{
    VALID_E_POINT_CHECK_VOID(pDst);

    switch (candidateIdx)
    {
        case 0:  // 7.8
            pDst->cellReselectionPriority = 7;
            pDst->bit_mask |= NRRRC_FreqPriorityNR_cellReselectionSubPriority_present;
            pDst->cellReselectionSubPriority = NRRRC_oDot8;
            break;

        case 1:  // 7.6
            pDst->cellReselectionPriority = 7;
            pDst->bit_mask |= NRRRC_FreqPriorityNR_cellReselectionSubPriority_present;
            pDst->cellReselectionSubPriority = NRRRC_oDot6;
            break;

        case 2:  // 7.4
            pDst->cellReselectionPriority = 7;
            pDst->bit_mask |= NRRRC_FreqPriorityNR_cellReselectionSubPriority_present;
            pDst->cellReselectionSubPriority = NRRRC_oDot4;
            break;

        case 3:  // 7.2
            pDst->cellReselectionPriority = 7;
            pDst->bit_mask |= NRRRC_FreqPriorityNR_cellReselectionSubPriority_present;
            pDst->cellReselectionSubPriority = NRRRC_oDot2;
            break;

        case 4:  // 7.0
            pDst->cellReselectionPriority = 7;
            break;

        case 5:  // 6.8
            pDst->cellReselectionPriority = 6;
            pDst->bit_mask |= NRRRC_FreqPriorityNR_cellReselectionSubPriority_present;
            pDst->cellReselectionSubPriority = NRRRC_oDot8;
            break;

        case 6:  // 6.6
            pDst->cellReselectionPriority = 6;
            pDst->bit_mask |= NRRRC_FreqPriorityNR_cellReselectionSubPriority_present;
            pDst->cellReselectionSubPriority = NRRRC_oDot6;
            break;

        case 7:  // 6.4
            pDst->cellReselectionPriority = 6;
            pDst->bit_mask |= NRRRC_FreqPriorityNR_cellReselectionSubPriority_present;
            pDst->cellReselectionSubPriority = NRRRC_oDot4;
            break;

        default:
            break;
    }
}

int16_t Fill_CellReselectionInfoColocCell(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    uint8_t numOfFreq = 0;
    uint8_t numOfCandidateCell = 0;
    colocCellbasedCandidateCell_type candidateCell[MAX_COLOCCELL];
    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    ptIE->bit_mask = 0;

    if (CI_use != pCell->cuColocCellInfo.colocCellInfoUsage)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "ERROR: coloc cell is not used %s\n", __FUNCTION__);
        return ERROR;
    }

    if (GOOD != FnVCCB_GetCandidateCell_ForColocCellbasedCAC(ptCi, pCell, &numOfCandidateCell, candidateCell))
    {
        // Print is not required
        return ERROR;
    }

    qsort(candidateCell, numOfCandidateCell, sizeof(colocCellbasedCandidateCell_type),
        VLIB_QsortCandidateCellAvailableUeDescendingOrder);

    // if the first candidate is intar freq, swap with the second
    colocCellbasedCandidateCell_type temp;
    if (candidateCell[0].ssbArfcn == pCell->ssbArfcn)
    {
        temp = candidateCell[0];
        candidateCell[0] = candidateCell[1];
        candidateCell[1] = temp;
    }

    numOfFreq = MIN(numOfCandidateCell, MAX_NUM_FREQ);

    if (0 !=
        fnGlobalValueAlloc((uint8_t **)&(ptIE->freqPriorityListNR), (int)sizeof(*ptIE->freqPriorityListNR) * numOfFreq))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "%s ERROR: fnGlobalValueAlloc failed\n", __FUNCTION__);
        return ERROR;
    }

    for (uint16_t candidateIdx = 0; candidateIdx < numOfFreq; candidateIdx++)
    {
        NRRRC_FreqPriorityNR *pDst = &(ptIE->freqPriorityListNR[candidateIdx].value);

        pDst->bit_mask = 0;
        pDst->carrierFreq = candidateCell[candidateIdx].ssbArfcn;

        FnVCCB_Fill_ReselectionPriority_ForColocCellbasedCAC(candidateIdx, pDst);
    }

    if (0 != fnConnectLinkedList(ptIE->freqPriorityListNR, sizeof(*ptIE->freqPriorityListNR), numOfFreq))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "%s ERROR: fnConnectLinkedList(NRRRC_FreqPrioriytListNR_) failed\n", __FUNCTION__);
        return ERROR;
    }
    ptIE->bit_mask |= NRRRC_freqPriorityListNR_present;

    // if any items were set, set T320 timer
    ptIE->bit_mask |= NRRRC_t320_present;
    ptIE->t320 = (NRRRC__enum228)pCell->cellRfspBasedCtrl.t320;

    ptCi->cacTriggeredRedirInfo.nr.ssbFrequency = candidateCell[0].ssbArfcn;
    ptCi->cacTriggeredRedirInfo.nr.ssbSubcarrierSpacing = (enumSubcarrierSpacing)candidateCell[0].nrScsDl;
    ptCi->cacTriggeredRedirInfo.nr.smtc1 = candidateCell[0].smtc1;
    ptCi->cacTriggeredRedirInfo.usage = CI_use;

    return GOOD;
}

int16_t Fill_CellReselectionInfoBasedInterFreqInfoList(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    uint16_t freqIdx = 0;
    uint16_t index = 0;
    uint16_t numOfCandidateFreq = 0;
    uint16_t selectedIdx;
    uint8_t svcGrpId = 0;
    uint16_t callPlmnIndex = 0;
    uint16_t numOfRegisteredLbCellReselNrFreq = 0;
    uint16_t failNum_MeasObjectNotExist = 0;
    uint16_t failNum_MeasObjectInvalid = 0;
    uint16_t failNum_PlmnBasedControl = 0;

    tempCandidateFreqInfo_type candidateFreqIdx[MAX_NUM_FREQ];  // For random selection

    nrCellReselectInfo_type *pInterFreqItem = NULL;
    measurementObjectNRBaseDb_type *pMeasObjBase = NULL;
    measurementObjectNRExtensionDb_type *pMeasObjExt = NULL;

    ptIE->bit_mask = 0;

    if (GOOD != FnVCCB_GetServiceGroupId(ptCi, &svcGrpId, TRUE))
    {
        svcGrpId = 0;
    }
    callPlmnIndex = VLIB_FindGnbPlmnIndexOfCall(ptCi);

    for (freqIdx = 1; freqIdx < MAX_NUM_FREQ + 1; freqIdx++)  // 0: IntraFreq, 1~MAX_NUMFREQ: InterFreq
    {
        pInterFreqItem = &CELLINFO[ptCi->servCellNum].lbCellResel[freqIdx].nrFreqItem;

        if (pInterFreqItem->usage == CI_use)
        {
            numOfRegisteredLbCellReselNrFreq++;
        }
        else
        {
            continue;
        }

        if (pInterFreqItem->measObjIdx >= MAX_NR_OF_OBJECT_ID_DB) continue;

        pMeasObjBase =
            &CELLINFO[ptCi->servCellNum].measurementsData.measurementObjectsNRDb[pInterFreqItem->measObjIdx].base;
        pMeasObjExt =
            &CELLINFO[ptCi->servCellNum].measurementsData.measurementObjectsNRDb[pInterFreqItem->measObjIdx].extension;

        if (pMeasObjBase->usage != CI_use)
        {
            failNum_MeasObjectNotExist++;
            continue;
        }

        // 2_a.
        // 1) sa-capable
        // 2) if the UE supports the frequency configured in cell-reselect-inter-freq-info-list
        // 3) CBRS frequency validity
        if (!FnVCCB_IsValid_MeasObj_CellReselection(ptCi, pInterFreqItem->measObjIdx))
        {
            failNum_MeasObjectInvalid++;
            continue;
        }

        // 2_b. plmn-based-control/plmn-support-entries/option should not be plmn-is-not-allowed
        // 2_c. for a UE with a valid Service Group ID,
        //      plmn-based-control/plmn-support-entries/option should not be service-group-is-not-allowed

        if (GOOD != VLIB_CanPlmnBasedControlBeUsedWithCustomIds(
                        ptCi, pMeasObjExt->plmnBasedControl, (uint8_t)callPlmnIndex, svcGrpId))
        {
            failNum_PlmnBasedControl++;
            continue;
        }

        candidateFreqIdx[numOfCandidateFreq].measObjIdx = pInterFreqItem->measObjIdx;
        candidateFreqIdx[numOfCandidateFreq].priority = pInterFreqItem->priority;
        candidateFreqIdx[numOfCandidateFreq].subpriorityUsage = pInterFreqItem->subpriorityUsage;
        candidateFreqIdx[numOfCandidateFreq].subpriority = pInterFreqItem->subpriority;

        numOfCandidateFreq++;
    }

    if (numOfCandidateFreq == 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "%s ERROR: no candidate freq!\n", __FUNCTION__);
        VCCB_PRINT_CALL_ERROR(ptCi,
            "Fail Reason: #cell-reselect-inter-freq-info-list:%d "
            "(#MoNotExist(%d),#MoInvalid(%d),#PlmnBasedControl(%d))\n",
            numOfRegisteredLbCellReselNrFreq, failNum_MeasObjectNotExist, failNum_MeasObjectInvalid,
            failNum_PlmnBasedControl);

        return ERROR;
    }

    selectedIdx = (uint16_t)FnVCCB_GetRandomValue(__func__, ptCi->gnbNum, numOfCandidateFreq);
    VCCB_CHECK_E_RANGE_AND_RETURN(selectedIdx, numOfCandidateFreq);

    if (0 != fnGlobalValueAlloc(
                 (uint8_t **)&(ptIE->freqPriorityListNR), (int)sizeof(*ptIE->freqPriorityListNR) * numOfCandidateFreq))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "%s ERROR: fnGlobalValueAlloc failed\n", __FUNCTION__);
        return ERROR;
    }

    for (index = 0; index < numOfCandidateFreq; index++)
    {
        if (candidateFreqIdx[index].measObjIdx >= MAX_NR_OF_OBJECT_ID_DB)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "%s ERROR: fnGlobalValueAlloc failed\n", __FUNCTION__);
            return ERROR;
        }

        pMeasObjBase = &CELLINFO[ptCi->servCellNum]
                            .measurementsData.measurementObjectsNRDb[candidateFreqIdx[index].measObjIdx]
                            .base;
        NRRRC_FreqPriorityNR *pDst = &(ptIE->freqPriorityListNR[index].value);

        pDst->bit_mask = 0;
        pDst->carrierFreq = pMeasObjBase->ssbFrequency;

        if (selectedIdx == index)
        {
            // set priority 7.8 for the random selected frequency
            pDst->cellReselectionPriority = 7;
            pDst->bit_mask |= NRRRC_FreqPriorityNR_cellReselectionSubPriority_present;
            pDst->cellReselectionSubPriority = NRRRC_oDot8;

            // set the frequency with priority 7.8 to RedirectionCarrierInfo
            ptCi->cacTriggeredRedirInfo.nr.ssbFrequency = pMeasObjBase->ssbFrequency;
            ptCi->cacTriggeredRedirInfo.nr.ssbSubcarrierSpacing =
                (enumSubcarrierSpacing)pMeasObjBase->ssbSubcarrierSpacing;
            ptCi->cacTriggeredRedirInfo.nr.smtc1 = pMeasObjBase->smtc1;
            ptCi->cacTriggeredRedirInfo.usage = CI_use;
        }
        else
        {
            // decrease 0.2 for the other frequencies
            if (candidateFreqIdx[index].subpriorityUsage != CI_use)
            {
                if (0 == candidateFreqIdx[index].priority)
                {
                    pDst->cellReselectionPriority = 0;
                }
                else
                {
                    // ex) 1.0 -> 0.8, 2.0 -> 1.8, ...
                    pDst->cellReselectionPriority =
                        (NRRRC_CellReselectionPriority)(candidateFreqIdx[index].priority - 1);
                    pDst->bit_mask |= NRRRC_FreqPriorityNR_cellReselectionSubPriority_present;
                    pDst->cellReselectionSubPriority = NRRRC_oDot8;
                }
            }
            else  // candidateFreqIdx[index].subpriorityUsage == CI_use
            {
                pDst->cellReselectionPriority = (NRRRC_CellReselectionPriority)candidateFreqIdx[index].priority;
                switch (candidateFreqIdx[index].subpriority)
                {
                    case NRRRC_oDot2:
                        // Do nothing (bit_mask is not required)
                        break;
                    default:
                        pDst->bit_mask |= NRRRC_FreqPriorityNR_cellReselectionSubPriority_present;
                        pDst->cellReselectionSubPriority =
                            (NRRRC_CellReselectionSubPriority)(candidateFreqIdx[index].subpriority - 1);
                        break;
                }
            }
        }
    }

    if (0 != fnConnectLinkedList(ptIE->freqPriorityListNR, sizeof(*ptIE->freqPriorityListNR), numOfCandidateFreq))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "%s ERROR: fnConnectLinkedList(NRRRC_FreqPriorityListNR_) failed\n", __FUNCTION__);
        return ERROR;
    }
    ptIE->bit_mask |= NRRRC_freqPriorityListNR_present;

    // if any items were set, set T320 timer
    ptIE->bit_mask |= NRRRC_t320_present;
    ptIE->t320 = (NRRRC__enum228)CELLINFO[ptCi->servCellNum].cellRfspBasedCtrl.t320;

    return GOOD;
}

/**
 * @brief Filling in RRC Message IEs for RedirectedCarrierInfo
 * @param  ptCi           : pointer to UE Context base on which message is filled in
 * @param  ptIE           : pointer to IE of RedirectedCarrierInfo structure to be filled in
 */
int16_t Fill_RedirectedCarrierInfo_CACTriggered(callInfo_type *ptCi, NRRRC_RedirectedCarrierInfo *ptIE)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);

    if (CI_use != ptCi->cacTriggeredRedirInfo.usage)
    {
        return ERROR;
    }

    ptIE->choice = NRRRC_RedirectedCarrierInfo_nr_chosen;

    ptIE->u.nr.bit_mask = 0;
    ptIE->u.nr.carrierFreq = ptCi->cacTriggeredRedirInfo.nr.ssbFrequency;
    ptIE->u.nr.ssbSubcarrierSpacing = (NRRRC_SubcarrierSpacing)ptCi->cacTriggeredRedirInfo.nr.ssbSubcarrierSpacing;

    if (VCCB_Fill_SSB_MTC1(&(ptIE->u.nr.smtc), &(ptCi->cacTriggeredRedirInfo.nr.smtc1)) != GOOD)
    {
        VCCB_PRINT_ERROR("ERROR: VCCB_Fill_SSB_MTC1 failed in %s!\n", __func__);
        return ERROR;
    }
    ptIE->u.nr.bit_mask |= NRRRC_CarrierInfoNR_smtc_present;

    return GOOD;
}

/**
 * @brief Filling in RRC Message IEs for cellReselectionPriorities and RedirectedCarrierInfo
 * @param  ptCi           : pointer to UE Context base on which message is filled in
 * @param  ptIE           : pointer to IE of RRCRelease structure to be filled in
 */
int16_t Fill_CRCandRCI_ByCACTriggeredRedirection(callInfo_type *ptCi, NRRRC_RRCRelease_IEs *ptIE)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);

    int16_t status = BREAK;

    // TS38.311 NRRRC 5.3.8.3
    // if security is not done RRCRelease parameters are ignored except waitTime, return ERROR
    if (!FnVCCB_IsSecurityProcedureDone(ptCi))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Security Procedure is on going.\n");
        return ERROR;
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    // 1] cellReselectionPriorities
    // 1-1] fill cellReselectionPriorities based on RFSP
    std::unique_ptr<CellReselectionInfo> cellReselectionInfo;
    if (VCCB_FLAG_ON == pCell->cellRfspBasedCtrl.rfspBasedCellReselectUsage)
    {
        cellReselectionInfo = std::make_unique<CellReselectionInfoRFSP>();
        status = cellReselectionInfo->Fill_CellReselectionInfo(ptCi, &(ptIE->cellReselectionPriorities));
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Fill_CellReselectionInfoRFSP Error!!\n");
            return ERROR;
        }
    }

    if (BREAK == status)
    {
        // 1-2] fill cellReselectionPriorities based on Service(5QI/PLMN) based Mobility Control (Priority 4)
        //      - Handles both general and CAC-triggered redirection cases
        //      - CAC-specific processing is handled internally within Fill_CellReselectionInfo
        if (FOO.VF_StandAlone_BasicCallOperationForSa &&
            (VCCB_FLAG_ON == pCell->mobilityConfig.serviceBasedCellReselectSupport))
        {
            cellReselectionInfo = std::make_unique<CellReselectionInfoSvcBasedMobilityControl>();
            status = cellReselectionInfo->Fill_CellReselectionInfo(ptCi, &(ptIE->cellReselectionPriorities));
            if (ERROR == status)
            {
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "CellReselectionInfoSvcBasedMobilityControl::Fill_CellReselectionInfo Error!!\n");
                return ERROR;
            }
        }

    }

    if (BREAK == status)
    {
        if (!IS_REDCAP_UE(ptCi))
        {
            // 1-3] fill cellReselectionPriorities based on coloc cell
            status = Fill_CellReselectionInfoColocCell(ptCi, &(ptIE->cellReselectionPriorities));
        }
        if (GOOD != status)
        {
            // 1-4] fill cellReselectionPriorities based on cell-reselect-inter-freq-info-list
            status = Fill_CellReselectionInfoBasedInterFreqInfoList(ptCi, &(ptIE->cellReselectionPriorities));
            if (GOOD != status)
            {
                return status;
            }
        }
    }

    // 2] RedirectedCarrierInfo
    status = Fill_RedirectedCarrierInfo_CACTriggered(ptCi, &(ptIE->redirectedCarrierInfo));
    if (GOOD != status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Fill_RedirectedCarrierInfo_CACTriggered Error!! (%d)\n", status);
        return status;
    }

    return status;
}

int16_t Fill_CellReselectionPrioritiesEUTRA_RfspInterRatRedirect(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    uint8_t measObjIndex = 0;
    uint8_t freqIdx = 0;
    int16_t numEutraFreqItems = 0;
    uint32_t earfcn = 0;
    measurementObjectEUTRABaseDb_type *pMeasObj = NULL;
    NRRRC_FreqPriorityEUTRA *pDst = NULL;

    if (fnGlobalValueAlloc(
                (uint8_t **)&ptIE->freqPriorityListEUTRA, sizeof(*ptIE->freqPriorityListEUTRA) * MAX_NUM_FREQ) != 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: fnGlobalValueAlloc failed in %s\n", __func__);
        return ERROR;
    }

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    // Get EUTRA Freq from eutraCellReselect(cell-reselect-eutra/eutra-fa-information <= SIB5)
    // Checking Rule of EUTRA Freq in measurementObjectsEUTRADb
    //  1. should check to support UE Capa and Multiband.
    //  2. set priority/subpriority depending on eutra-fa-information Yang Value.
    for (freqIdx = 0; freqIdx < MAX_NUM_FREQ; freqIdx++)
    {
        // Get eutraCellReselect of Cell and Measurement Object
        eutraCellReselectInfo_type *pEutraCellReselect = &pCell->eutraCellReselect[freqIdx];
        if (CI_use != pEutraCellReselect->usage) continue;

        measObjIndex = pEutraCellReselect->measObjIdx;
        VCCB_CHECK_E_RANGE_AND_CONTINUE(measObjIndex, MAX_NR_OF_OBJECTEUTRA_ID_DB);

        pMeasObj = &(pCell->measurementsData.measurementObjectsEUTRADb[measObjIndex].base);
        if (CI_use != pMeasObj->usage) continue;

        // Check UE Support Band
        if (BAND_NOT_FOUND == VCCB_GetMoEutraBandForUe(ptCi, pMeasObj, &earfcn)) continue;

        pDst = &(ptIE->freqPriorityListEUTRA[numEutraFreqItems].value);

        pDst->bit_mask = 0;
        pDst->carrierFreq = earfcn;
        pDst->cellReselectionPriority = pEutraCellReselect->priority;
        if (CI_use == pEutraCellReselect->subpriorityUsage)
        {
            pDst->bit_mask |= NRRRC_FreqPriorityEUTRA_cellReselectionSubPriority_present;
            pDst->cellReselectionSubPriority = (NRRRC_CellReselectionSubPriority)pEutraCellReselect->subpriority;
        }

        numEutraFreqItems++;
    }

    if (0 < numEutraFreqItems)
    {
        short status =
            fnConnectLinkedList(ptIE->freqPriorityListEUTRA, sizeof(*ptIE->freqPriorityListEUTRA), numEutraFreqItems);
        if (0 != status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                    "ERROR fnConnectLinkedList(NRRRC_FreqPriorityListEUTRA_) failed in %s\n", __func__);
            return ERROR;
        }
        ptIE->bit_mask |= NRRRC_freqPriorityListEUTRA_present;
        return GOOD;
    }

    return BREAK;
}

int16_t FnVCCB_Fill_CellReselectionInfoRfspBlindInterRat(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    
    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    // 1. Make EUTRA frequency
    int16_t status = Fill_CellReselectionPrioritiesEUTRA_RfspInterRatRedirect(ptCi, ptIE);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Fill_CellReselectionPrioritiesEUTRA_RfspInterRatRedirect ERROR!!\n");
        return ERROR;
    }
    else if (BREAK == status)
    {
        return BREAK;
    }

    // 2. Set T320
    ptIE->bit_mask |= NRRRC_t320_present;
    ptIE->t320 = (NRRRC__enum228)pCell->cellRfspBasedCtrl.t320;

    // 3. Do Not Make NR frequency

    return GOOD;
}

/**
 * @brief Filling in RRC Message IEs for NRRRC_CellReselectionPriorities - EUTRA
 * @param  ptCi           : pointer to UE Context base on which message is filled in
 * @param  ptIE           : pointer to IE of NRRRC_CellReselectionPriorities to be filled in
 * @return int16_t        : result of operation
 */
int8_t CellReselectionInfoFallback::Fill_CellReselectionPrioritiesEUTRA(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    uint8_t measObjIndex = 0;
    uint8_t freqIdx = 0;
    int8_t numEutraFreqItems = 0;
    uint32_t earfcn = 0;
    measurementObjectEUTRABaseDb_type *pMeasObj = NULL;
    NRRRC_FreqPriorityEUTRA *pDst = NULL;

    if (fnGlobalValueAlloc(
            (uint8_t **)&ptIE->freqPriorityListEUTRA, sizeof(*ptIE->freqPriorityListEUTRA) * MAX_NUM_FREQ) != 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: fnGlobalValueAlloc failed in CellReselectionInfoFallback::Fill_CellReselectionPrioritiesEUTRA\n");
        return ERROR;
    }

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    // Get EUTRA Freq from eutraCellReselect(cell-reselect-eutra/eutra-fa-information <= SIB5)
    // Checking Rule of EUTRA Freq in measurementObjectsEUTRADb
    //  1. should check to support voice-support and set Priority as 7.
    //  2. should check to support UE Capa and Multiband.
    //  3. set Priority as 7. (maximum value)
    for (freqIdx = 0; freqIdx < MAX_NUM_FREQ; freqIdx++)
    {
        // Get eutraCellReselect of Cell and Measurement Object
        eutraCellReselectInfo_type *pEutraCellReselect = &pCell->eutraCellReselect[freqIdx];
        if (CI_use != pEutraCellReselect->usage) continue;

        measObjIndex = pEutraCellReselect->measObjIdx;
        VCCB_CHECK_E_RANGE_AND_CONTINUE(measObjIndex, MAX_NR_OF_OBJECTEUTRA_ID_DB);

        pMeasObj = &(pCell->measurementsData.measurementObjectsEUTRADb[measObjIndex].base);
        if (CI_use != pMeasObj->usage) continue;

        // Check Fallback Support
        if (IS_NOT_SUPPORT_FALLBACK_FLAG_IN_MEASOBJ(ptCi, pMeasObj)) continue;

        // Check UE Support Band
        if (BAND_NOT_FOUND == VCCB_GetMoEutraBandForUe(ptCi, pMeasObj, &earfcn)) continue;

        pDst = &(ptIE->freqPriorityListEUTRA[numEutraFreqItems].value);

        pDst->bit_mask = 0;
        pDst->carrierFreq = earfcn;
        pDst->cellReselectionPriority = MAX_FALLBACK_EUTRA_RESEL_PRIORITY;
        // No need to Set subpriority for EUTRA

        numEutraFreqItems++;
    }

    if (0 < numEutraFreqItems)
    {
        short status =
            fnConnectLinkedList(ptIE->freqPriorityListEUTRA, sizeof(*ptIE->freqPriorityListEUTRA), numEutraFreqItems);
        if (0 != status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "ERROR fnConnectLinkedList(NRRRC_FreqPriorityListEUTRA_) failed in "
                "CellReselectionInfoFallback::Fill_CellReselectionPrioritiesEUTRA\n");
            return ERROR;
        }
        ptIE->bit_mask |= NRRRC_freqPriorityListEUTRA_present;
    }

    return numEutraFreqItems;
}

/**
 * @brief Filling in RRC Message IEs for NRRRC_CellReselectionPriorities - NR
 * @param  ptCi           : pointer to UE Context base on which message is filled in
 * @param  ptIE           : pointer to IE of NRRRC_CellReselectionPriorities to be filled in
 * @return int16_t        : result of operation
 */
int8_t CellReselectionInfoFallback::Fill_CellReselectionPrioritiesNR(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    int8_t numNrFreqItems = 0;
    uint8_t freqIdx = 0;
    uint8_t measObjIndex;
    nrCellReselectInfo_type *ptNrFreqConfig = NULL;

    if (0 !=
        fnGlobalValueAlloc((uint8_t **)&ptIE->freqPriorityListNR, sizeof(*ptIE->freqPriorityListNR) * MAX_NUM_FREQ))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: fnGlobalValueAlloc failed in CellReselectionInfoFallback::Fill_CellReselectionPrioritiesNR\n");
        return ERROR;
    }

    // pCell->lbCellResel[MAX_NUM_FREQ + 1]; 0: Intra, 1~8: Inter
    // NR Frequency should
    //    1. support UE Capa and Multi-Band.
    //    2. support SA Capable
    //    3. Set Priority as (own value-1)
    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    for (freqIdx = 0; freqIdx < MAX_NUM_FREQ + 1; freqIdx++)
    {
        ptNrFreqConfig = &pCell->lbCellResel[freqIdx].nrFreqItem;
        if (ptNrFreqConfig->usage != CI_use) continue;

        // Get NR Measurement Object
        measObjIndex = ptNrFreqConfig->measObjIdx;
        VCCB_CHECK_E_RANGE_AND_CONTINUE(measObjIndex, MAX_NR_OF_OBJECT_ID_DB);
        measurementObjectNRBaseDb_type *pMeasObj = &(pCell->measurementsData.measurementObjectsNRDb[measObjIndex].base);

        // This function will check UE Support Band, SA Capable, Inter-Freq, CBRS
        if (!FnVCCB_IsValid_MeasObj_CellReselection(ptCi, measObjIndex))
        {
            continue;
        }

        NRRRC_FreqPriorityNR *pDst = &(ptIE->freqPriorityListNR[numNrFreqItems].value);

        // Set Priority and SubPriority
        pDst->bit_mask = 0;
        pDst->carrierFreq = pMeasObj->ssbFrequency;

        // Using -1 value to make Eutra frequency high priority
        if (ptNrFreqConfig->priority > 0)
        {
            pDst->cellReselectionPriority = (NRRRC_CellReselectionPriority)(ptNrFreqConfig->priority - 1);
        }
        else
        {
            pDst->cellReselectionPriority = 0;
        }

        if (CI_use == ptNrFreqConfig->subpriorityUsage)
        {
            pDst->bit_mask |= NRRRC_FreqPriorityNR_cellReselectionSubPriority_present;
            pDst->cellReselectionSubPriority = (NRRRC_CellReselectionSubPriority)ptNrFreqConfig->subpriority;
        }

        numNrFreqItems++;
        if (numNrFreqItems >= MAX_NUM_FREQ)  // 8
            break;
    }

    if (0 < numNrFreqItems)
    {
        short status = fnConnectLinkedList(ptIE->freqPriorityListNR, sizeof(*ptIE->freqPriorityListNR), numNrFreqItems);
        if (0 != status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "ERROR fnConnectLinkedList(NRRRC_FreqPriorityListNR_) failed in "
                "CellReselectionInfoFallback::Fill_CellReselectionPrioritiesNR\n");
            return ERROR;
        }
        ptIE->bit_mask |= NRRRC_freqPriorityListNR_present;
    }

    return numNrFreqItems;
}

void CellReselectionInfo::Fill_T320(NRRRC_CellReselectionPriorities *ptIE, NRRRC__enum228 t320)
{
    VALID_E_POINT_CHECK_VOID(ptIE);
    ptIE->bit_mask |= NRRRC_t320_present;
    ptIE->t320 = t320;
}

/**
 * @brief Filling in RRC Message IEs for CellReselectionInfoFallback
 * @param  ptCi           : pointer to UE Context base on which message is filled in
 * @param  ptIE           : pointer to IE of RRCRelease structure to be filled in
 * @return int16_t        : result of operation
 */
int8_t CellReselectionInfoFallback::Fill_CellReselectionInfo(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    int8_t numNrFreqItems = 0, numEutraFreqItems = 0;
    int16_t status = GOOD;
    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    // 1. Make EUTRA frequency
    numEutraFreqItems = Fill_CellReselectionPrioritiesEUTRA(ptCi, ptIE);
    if (ERROR == numEutraFreqItems)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "CellReselectionInfoFallback::Fill_CellReselectionPrioritiesEUTRA ERROR!!\n");
    }

    if (numEutraFreqItems <= 0)
    {
        return BREAK;
    }

    // 2. Set T320
    Fill_T320(ptIE, static_cast<NRRRC__enum228>(pCell->cellRfspBasedCtrl.t320));

    // 3. Make NR frequency
    // 3-1. Firstly, Using RFSP
    if (VCCB_FLAG_ON == pCell->cellRfspBasedCtrl.rfspBasedCellReselectUsage)
    {
        int32_t hasEutraFreqPriorityList = TRUE;
        CellReselectionInfoRFSP cellReselectionInfoRFSP = CellReselectionInfoRFSP(hasEutraFreqPriorityList);
        status = cellReselectionInfoRFSP.Fill_CellReselectionInfo(ptCi, ptIE);
        if (GOOD == status)
        {
            return GOOD;
        }
    }

    // 3-2. If no RFSP, then Using SIB Info(IDLE LB)
    numNrFreqItems = Fill_CellReselectionPrioritiesNR(ptCi, ptIE);
    if (ERROR == numNrFreqItems)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "CellReselectionInfoFallback::Fill_CellReselectionPrioritiesNR ERROR!!\n");
    }

    return GOOD;
}

int16_t CellReselectionInfoSvcBasedIdleLB::FnVCCB_Make_lbBasedCellResel_SvcBasedIdleLB(
    callInfo_type *ptCi, nrCellReselectInfo_type *pDst)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDst);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    svcFreqNrItem_type *pNrFreqItems = NULL;
    uint8_t equippedNrFreqNum = 0;

    // const uint8_t callPlmnIndex = VLIB_FindGnbPlmnIndexOfCall(ptCi);
    uint8_t svcGrpIdx = 0;

    for (svcGrpIdx = 0; svcGrpIdx < MAX_NUM_SVC_FREQS; svcGrpIdx++)
    {
        pNrFreqItems = &(_pCellReselect->nrFreqItems[svcGrpIdx]);
        if (CI_use != pNrFreqItems->usage) continue;

        if (!FnVCCB_IsValid_MeasObj_CellReselection(ptCi, pNrFreqItems->targetMeasObjectEntriesindex))
        {
            continue;
        }

        {
            pDst->usage = (enumUsage_type)pNrFreqItems->usage;
            pDst->index = equippedNrFreqNum;
            pDst->measObjIdx = pNrFreqItems->targetMeasObjectEntriesindex;
            pDst->priority = pNrFreqItems->dedicatedPriority;
            pDst->subpriorityUsage = pNrFreqItems->dedicatedSubpriorityUsage;
            pDst->subpriority = pNrFreqItems->dedicatedSubpriority;
            pDst->ueDistributionRatio = pNrFreqItems->serviceUeDistRatio;
            equippedNrFreqNum++;

            if (MAX_NUM_FREQ + 1 <= equippedNrFreqNum) break;
            ++pDst;
        }
    }

    VCCB_PRINT_CALL_IDLE_LB(ptCi, "[SVC-IMLB] %s to make cell reselction priority candidate(%u) in %s\n",
        0 == equippedNrFreqNum ? "Failed" : "Success", equippedNrFreqNum, __func__);

    if (0 == equippedNrFreqNum)
    {
        return ERROR;
    }
    return GOOD;
}

bool FnVCCB_IsValidCarrier_IdleLB(callInfo_type *ptCi, uint8_t measObjIndex)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->servCellNum, MAX_CELL_NUM_VCCB, false);
    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    VCCB_CHECK_E_RANGE_AND_VAL(measObjIndex, MAX_NR_OF_OBJECT_ID_DB, false);

    measurementObjectNRBaseDb_type *pMeasObj = &(pCell->measurementsData.measurementObjectsNRDb[measObjIndex].base);

    uint16_t NrBandRet = VCCB_GetMoNrBandForUe(ptCi, pMeasObj);
    int16_t EnabledNbrRet = VCCM_FindSaEnabledNbr(ptCi, RSType_SSB, pMeasObj->ssbFrequency);
    if ((NrBandRet == 0) || (EnabledNbrRet == ERROR))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[SVC-IMLB] Valid Carrier check measIdx(%u) NrBandRet:%d, EnabledNbrRet:%u %s:%d\n",
            measObjIndex, NrBandRet, EnabledNbrRet, __FILE__, __LINE__);

        return false;
    }
    return true;
}

int32_t VCCB_CrpToIntegerNr(nrCellReselectInfo_type *ptNrFreq)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptNrFreq);
    int ret = 0;
    if (CI_no_use == ptNrFreq->subpriorityUsage)
    {
        ret = (ptNrFreq->priority * 10);
    }
    else
    {
        ret = (ptNrFreq->priority * 10) + (1 + ptNrFreq->subpriority) * 2;
    }

    return ret;
}

int32_t VCCB_CrpToIntegerEutra(eutraCellReselectInfo_type *ptEutraFreq)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptEutraFreq);
    int ret = 0;
    if (CI_no_use == ptEutraFreq->subpriorityUsage)
    {
        ret = (ptEutraFreq->priority * 10);
    }
    else
    {
        ret = (ptEutraFreq->priority * 10) + (1 + ptEutraFreq->subpriority) * 2;
    }

    return ret;
}

void VCCB_IntegerToCrp(int16_t score, nrCellReselectInfo_type *ptNrFreq)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptNrFreq);

    if (score < 0)
    {
        score = 0;
    }

    if (score % 10)
    {
        ptNrFreq->priority = (uint8_t)score / 10;
        ptNrFreq->subpriority = (uint8_t)((score % 10) / 2 - 1);
        ptNrFreq->subpriorityUsage = CI_use;
    }
    else
    {
        ptNrFreq->priority = (uint8_t)score / 10;
        ptNrFreq->subpriority = 0;
        ptNrFreq->subpriorityUsage = CI_no_use;
    }
    return;
}

void VCCB_IntegerToCrpEutra(int16_t score, eutraCellReselectInfo_type *ptEutraFreq)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptEutraFreq);

    if (score < 0)
    {
        score = 0;
    }

    if (score % 10)
    {
        ptEutraFreq->priority = (uint8_t)score / 10;
        ptEutraFreq->subpriority = (uint8_t)((score % 10) / 2 - 1);
        ptEutraFreq->subpriorityUsage = CI_use;
    }
    else
    {
        ptEutraFreq->priority = (uint8_t)score / 10;
        ptEutraFreq->subpriority = 0;
        ptEutraFreq->subpriorityUsage = CI_no_use;
    }
    return;
}

// The maximum element number of Cell Reselection Priority is 8(MAX_NUM_FREQ).
// If element is over 8(MAX_NUM_FREQ), this function should return idx to remove, and highest frequency idx
int16_t VCCB_GetHighestPriorityFrequency(callInfo_type *ptCi, nrCellReselectInfo_type lbFreq[], uint8_t *removeIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    int index, freCnt = 0;
    int distRatioTotalCnt = 0;
    int distRatioCurCnt = 0;
    uint8_t measObjIndex = 0;
    uint8_t minInvalidPriority = 0xFF;
    int32_t tmpVal = 0;

    measurementObjectNRBaseDb_type *pMeasObj = NULL;
    nrCellReselectInfo_type highestPriorFreq;
    memset(&highestPriorFreq, 0x00, sizeof(highestPriorFreq));
    nrCellReselectInfo_type *ptNrFreq = NULL;
    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    float randDistRatio = -1;
    float sumOfDist_Inter = 0;  // max 90,000
    float sumOfDist = 0;        // max 90,000
    float accumulate_Dist = 0;
    float accumulate_EndDist = 0;

    if (DBG->flag.logIdleLB)
    {
        for (index = 0; index <= MAX_NUM_FREQ; index++)
        {
            if (lbFreq[index].usage == CI_use)
            {
                VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] candidate measObjIdx[%u] distRatio(%f)\n",
                    lbFreq[index].measObjIdx, (double)lbFreq[index].ueDistributionRatio);
            }
        }
    }
    // sum of inter frequency
    for (index = 0; index <= MAX_NUM_FREQ; index++)
    {
        ptNrFreq = &lbFreq[index];
        if (ptNrFreq->usage != CI_use) continue;

        if (index > 0)
        {
            if (false == FnVCCB_IsValidCarrier_IdleLB(ptCi, ptNrFreq->measObjIdx))
            {
                /*A frequency having the lowest priority among invalid frequencies is not included.*/
                tmpVal = VCCB_CrpToIntegerNr(ptNrFreq);
                if (tmpVal < minInvalidPriority)
                {
                    minInvalidPriority = (uint8_t)tmpVal;
                    *removeIdx = (uint8_t)index;
                }
                continue;
            }
        }

        sumOfDist += ptNrFreq->ueDistributionRatio;
        if (0 != ptNrFreq->ueDistributionRatio) distRatioTotalCnt++;
        if (index != 0) sumOfDist_Inter += ptNrFreq->ueDistributionRatio;
    }

    // using Random API
    unsigned int randomValue = FnVCCB_GetRandomValue(__func__, ptCi->gnbNum, 10000);
    randDistRatio = (float)randomValue / (float)10000;

    for (index = 0; index <= MAX_NUM_FREQ; index++)
    {
        ptNrFreq = &lbFreq[index];
        if (ptNrFreq->usage != CI_use) continue;
        // measObjIndex = ptNrFreq->measObjIdx;

        freCnt++;
        // for only inter frequency reselection list
        if (index > 0)
        {
            measObjIndex = ptNrFreq->measObjIdx;
            VCCB_CHECK_E_RANGE_AND_RETURN(measObjIndex, MAX_NR_OF_OBJECT_ID_DB);
            pMeasObj = &(pCell->measurementsData.measurementObjectsNRDb[measObjIndex].base);
            if ((VCCB_GetMoNrBandForUe(ptCi, pMeasObj) == 0) ||
                (VCCM_FindSaEnabledNbr(ptCi, RSType_SSB, pMeasObj->ssbFrequency) == ERROR))
            {
                /*A frequency having the lowest priority among invalid frequencies is not included.*/
                tmpVal = VCCB_CrpToIntegerNr(ptNrFreq);
                if (tmpVal < minInvalidPriority)
                {
                    minInvalidPriority = (uint8_t)tmpVal;
                    *removeIdx = (uint8_t)index;
                }
                continue;
            }
        }
        if (0 == ptNrFreq->ueDistributionRatio || 0 == sumOfDist) continue;
        distRatioCurCnt++;
        float accumulate_rangevalue = (ptNrFreq->ueDistributionRatio / sumOfDist);
        accumulate_EndDist = accumulate_Dist + accumulate_rangevalue;
        if ((accumulate_Dist <= randDistRatio) && (randDistRatio < (accumulate_EndDist)))
        {
            highestPriorFreq = lbFreq[index];
            VCCB_PRINT_CALL_IDLE_LB(ptCi,
                "[IMLB] start(%.8f) <= randDist(%.8f) < endDist(%.8f) in %s\n", (double)accumulate_Dist,
                (double)randDistRatio, (double)accumulate_EndDist, __FUNCTION__);
        }
        else
        {
            if (distRatioCurCnt == distRatioTotalCnt)
            {
                if (randDistRatio >= accumulate_EndDist)
                {
                    highestPriorFreq = lbFreq[index];
                    VCCB_PRINT_CALL_IDLE_LB(ptCi,
                        "[IMLB] start(%.8f) <= randDist(%.8f) < endDist(%.8f) in %s\n",
                        (double)accumulate_Dist, (double)randDistRatio, (double)accumulate_EndDist, __FUNCTION__);
                }
            }
        }
        accumulate_Dist = accumulate_EndDist;
    }

    if (freCnt <= MAX_NUM_FREQ)
    {
        *removeIdx = MAX_NUM_FREQ + 1;
    }

    if (highestPriorFreq.usage != CI_use)
    {
        return ERROR;
    }

    VCCB_PRINT_CALL_IDLE_LB(
        ptCi, "[IMLB] measObjectIdx %u is selected as highestPriorityFrequency!\n", highestPriorFreq.measObjIdx);

    return highestPriorFreq.index;
}

uint16_t VCCB_GetLowestPriorityAmongFullFreqList(nrCellReselectInfo_type lbCrp[], int16_t highIdx)
{
    AUTO_TRACE_FUNC;
    int index;
    nrCellReselectInfo_type *ptNrFreq = NULL;
    uint8_t minInvalidPriority = 0xFF;
    int32_t totalCrp = 0;
    uint8_t removeIdx = 0xFF;

    for (index = 0; index < MAX_NUM_FREQ + 1; index++)
    {
        ptNrFreq = &lbCrp[index];
        if (ptNrFreq->usage != CI_use) continue;
        if (index == highIdx) continue;

        totalCrp = VCCB_CrpToIntegerNr(ptNrFreq);
        if (totalCrp < minInvalidPriority)
        {
            minInvalidPriority = (uint8_t)totalCrp;
            removeIdx = ptNrFreq->index;
        }
    }

    return removeIdx;
}

uint16_t VCCB_SetNrFreqPriority(nrCellReselectInfo_type lbFreq[], int16_t highIdx)
{
    AUTO_TRACE_FUNC;
    int index;
    nrCellReselectInfo_type *ptNrFreq = NULL;
    int32_t minPriority = 0xFF;
    uint8_t combinedVal = 0;
    uint8_t baseVal = 0;

    for (index = 0; index < MAX_NUM_FREQ + 1; index++)
    {
        ptNrFreq = &lbFreq[index];
        if (CI_no_use == ptNrFreq->usage) continue;
        if (index == highIdx) continue;
        if (ptNrFreq->ueDistributionRatio == 0) continue;

        combinedVal = (uint8_t)VCCB_CrpToIntegerNr(ptNrFreq);
        VCCB_IntegerToCrp((int16_t)(combinedVal - 2), ptNrFreq);

        if (VCCB_CrpToIntegerNr(ptNrFreq) < minPriority)
        {
            minPriority = VCCB_CrpToIntegerNr(ptNrFreq);
        }
    }

    for (index = 0; index < MAX_NUM_FREQ + 1; index++)
    {
        ptNrFreq = &lbFreq[index];
        if (CI_no_use == ptNrFreq->usage) continue;
        if (index == highIdx) continue;
        if (ptNrFreq->ueDistributionRatio != 0) continue;

        // if minPriority is 0xFF, distribution rate are all zero
        baseVal = (minPriority == 0xFF) ? (uint8_t)VCCB_CrpToIntegerNr(ptNrFreq) : (uint8_t)minPriority;

        // VCCB_LowerCellReselectSubPriority(baseVal, ptNrFreq, 2);
        VCCB_IntegerToCrp((int16_t)(baseVal - 2), ptNrFreq);
    }

    return (uint16_t)minPriority;
}

int16_t VCCB_MakeLbBasedCellReselectionPrioritiesNR(
    callInfo_type *ptCi, nrCellReselectInfo_type lbFreq[], int16_t *highIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint8_t removeIdx = 0xFF;

    *highIdx = VCCB_GetHighestPriorityFrequency(ptCi, lbFreq, &removeIdx);
    if (ERROR == *highIdx)
    {
        return ERROR;
    }
    VCCB_CHECK_E_RANGE_AND_RETURN(*highIdx, MAX_NUM_FREQ + 1);

    VCCB_IntegerToCrp(78, &lbFreq[*highIdx]);  // set priority to highest (7.8)

    // If removeIdx is MAX_NUM_FREQ+1, then total frequency count is less than MAX_NUM_FREQ
    if (removeIdx <= MAX_NUM_FREQ)
    {
        lbFreq[removeIdx].usage = CI_no_use;
    }

    VCCB_SetNrFreqPriority(lbFreq, *highIdx);

    // There is no frequency that UE does not support or NBR cell is not existed && freCnt is MAX_NUM_FREQ + 1
    if (0xFF == removeIdx)
    {
        /*Get frequency index which have the lowest priority */
        removeIdx = (uint8_t)VCCB_GetLowestPriorityAmongFullFreqList(lbFreq, *highIdx);
        if (removeIdx <= MAX_NUM_FREQ) lbFreq[removeIdx].usage = CI_no_use;
    }

    return GOOD;
}

int8_t CellReselectionInfoSvcBasedIdleLB::Fill_CellReselectionPrioritiesNR(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    nrCellReselectInfo_type lbFreq[MAX_NUM_FREQ + 1];
    measurementObjectNRBaseDb_type *pMeasObj = NULL;
    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];

    int8_t numNrFreqItems = 0;
    uint8_t freqIdx = 0, measObjIndex = 0;
    int32_t tmpVal = 0;
    int16_t highIdx = 0;

    memset(lbFreq, 0, sizeof(lbFreq));

    if (ERROR == FnVCCB_Make_lbBasedCellResel_SvcBasedIdleLB(ptCi, lbFreq))
    {
        VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "ERROR: FnVCCB_Make_lbBasedCellResel_SvcBasedIdleLB failed in %s\n", __FUNCTION__);
        return ERROR;
    }

    if (GOOD != VCCB_MakeLbBasedCellReselectionPrioritiesNR(ptCi, lbFreq, &highIdx))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: VCCB_MakeLbBasedCellReselectionPrioritiesNR failed in %s\n", __FUNCTION__);
        return ERROR;
    }

    if (0 != fnGlobalValueAlloc(
                 (uint8_t **)&ptIE->freqPriorityListNR, sizeof(*ptIE->freqPriorityListNR) * MAX_NUM_SVC_FREQS))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR: fnGlobalValueAlloc failed in %s\n", __FUNCTION__);
        return ERROR;
    }

    for (freqIdx = 0; freqIdx < MAX_NUM_FREQ + 1; freqIdx++)
    {
        nrCellReselectInfo_type *ptNrFreq = &(lbFreq[freqIdx]);

        if (CI_use != ptNrFreq->usage) continue;

        measObjIndex = ptNrFreq->measObjIdx;
        VCCB_CHECK_E_RANGE_AND_RETURN(measObjIndex, MAX_NR_OF_OBJECT_ID_DB);
        pMeasObj = &pCell->measurementsData.measurementObjectsNRDb[measObjIndex].base;

        NRRRC_FreqPriorityNR *pDst = &(ptIE->freqPriorityListNR[numNrFreqItems].value);

        pDst->bit_mask = 0;
        pDst->carrierFreq = pMeasObj->ssbFrequency;
        pDst->cellReselectionPriority = ptNrFreq->priority;
        if (CI_use == ptNrFreq->subpriorityUsage)
        {
            pDst->bit_mask |= NRRRC_FreqPriorityNR_cellReselectionSubPriority_present;
            pDst->cellReselectionSubPriority = (NRRRC_CellReselectionSubPriority)ptNrFreq->subpriority;
        }

        /*Get minimum cell reselection priority value in NR*/
        tmpVal = VCCB_CrpToIntegerNr(ptNrFreq);
        if (tmpVal < _nrMinPriority)
        {
            _nrMinPriority = (uint8_t)tmpVal;
        }
        numNrFreqItems++;
    }

    if (0 < numNrFreqItems)
    {
        short status = fnConnectLinkedList(ptIE->freqPriorityListNR, sizeof(*ptIE->freqPriorityListNR), numNrFreqItems);
        if (0 != status)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "ERROR fnConnectLinkedList(NRRRC_FreqPriorityListNR_) failed in %s\n", __FUNCTION__);
            return ERROR;
        }
        ptIE->bit_mask |= NRRRC_freqPriorityListNR_present;
    }

    return numNrFreqItems;
}

int16_t FnVCCB_Make_eutraCellReselect_SvcBasedIdleLB(
    callInfo_type *ptCi, SvcBasedCrpCtrl_type *pSrc, eutraCellReselectInfo_type *pDst)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pSrc);
    VALID_E_POINT_CHECK_ERROR(pDst);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];

    measurementObjectEUTRABaseDb_type *pMeasObj = NULL;

    int freqIdx = 0, numEutraFreqItems = 0;
    uint8_t measObjIndex = 0;
    uint32_t carrierFreq = 0;

    for (freqIdx = 0; freqIdx < MAX_NUM_SVC_FREQS; freqIdx++)
    {
        svcFreqEutraItem_type *pEutraFreqItems = &(pSrc->eutraFreqItems[freqIdx]);

        if (CI_use != pEutraFreqItems->usage)
        {
            continue;
        }

        measObjIndex = pEutraFreqItems->targetMeasObjectEutraEntriesindex;
        VCCB_CHECK_E_RANGE_AND_RETURN(measObjIndex, MAX_NR_OF_OBJECTEUTRA_ID_DB);
        pMeasObj = &(pCell->measurementsData.measurementObjectsEUTRADb[measObjIndex].base);

        if (BAND_NOT_FOUND == VCCB_GetMoEutraBandForUe(ptCi, pMeasObj, &carrierFreq))
        {
            // not supported by UE
            continue;
        }

        {
            pDst->usage = (enumUsage_type)pEutraFreqItems->usage;
            pDst->index = (uint8_t)numEutraFreqItems;
            pDst->measObjIdx = pEutraFreqItems->targetMeasObjectEutraEntriesindex;
            pDst->priority = pEutraFreqItems->dedicatedPriority;
            pDst->subpriorityUsage = pEutraFreqItems->dedicatedSubpriorityUsage;
            pDst->subpriority = pEutraFreqItems->dedicatedSubpriority;
            numEutraFreqItems++;

            if (MAX_NUM_FREQ <= numEutraFreqItems) break;
            ++pDst;
        }
    }

    if (0 == numEutraFreqItems)
    {
        return ERROR;
    }
    return GOOD;
}

void VCCB_SetCellReselectEutraPriorityIdleLB(uint8_t nrMinPriority, eutraCellReselectInfo_type eutraFreqItem[])
{
    AUTO_TRACE_FUNC;

    uint8_t freqIdx = 0;
    int32_t combinedVal = 0;
    uint8_t eutraMaxPriority = 0;
    eutraCellReselectInfo_type *ptEutraFreq = NULL;

    for (freqIdx = 0; freqIdx < MAX_NUM_FREQ; freqIdx++)
    {
        ptEutraFreq = &eutraFreqItem[freqIdx];
        if (CI_no_use == ptEutraFreq->usage) continue;

        combinedVal = VCCB_CrpToIntegerEutra(ptEutraFreq);

        if (eutraMaxPriority < combinedVal)
        {
            eutraMaxPriority = (uint8_t)combinedVal;
        }
    }

    if (eutraMaxPriority >= nrMinPriority)
    {
        for (freqIdx = 0; freqIdx < MAX_NUM_FREQ; freqIdx++)
        {
            ptEutraFreq = &eutraFreqItem[freqIdx];
            if (CI_no_use == ptEutraFreq->usage) continue;
            VCCB_IntegerToCrpEutra((int16_t)(VCCB_CrpToIntegerEutra(ptEutraFreq) - 10), ptEutraFreq);
        }
    }

    return;
}

int8_t CellReselectionInfoSvcBasedIdleLB::Fill_CellReselectionPrioritiesEUTRA(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];
    eutraCellReselectInfo_type eutraFreqItem[MAX_NUM_FREQ];
    eutraCellReselectInfo_type *ptEutraFreq = NULL;
    uint8_t freqIdx = 0;
    uint8_t measObjIndex = 0;
    measurementObjectEUTRABaseDb_type *pMeasObj = NULL;
    NRRRC_FreqPriorityEUTRA *pDst = NULL;
    int8_t numEutraFreqItems = 0;
    uint32_t earfcn = 0;

    memset(eutraFreqItem, 0, sizeof(eutraFreqItem));

    if (ERROR == FnVCCB_Make_eutraCellReselect_SvcBasedIdleLB(ptCi, _pCellReselect, eutraFreqItem))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "ERROR: FnVCCB_Make_eutraCellReselect failed in %s\n", __FUNCTION__);
        return ERROR;
    }

    if (0 != fnGlobalValueAlloc(
                 (uint8_t **)&ptIE->freqPriorityListEUTRA, sizeof(*ptIE->freqPriorityListEUTRA) * MAX_NUM_FREQ))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: fnGlobalValueAlloc failed in "
            "CellReselectionInfoSvcBasedIdleLB::Fill_CellReselectionPrioritiesEUTRA\n");
        return ERROR;
    }

    /*Set EUTRA cell reselect Priority */
    VCCB_SetCellReselectEutraPriorityIdleLB(_nrMinPriority, eutraFreqItem);

    for (freqIdx = 0; freqIdx < MAX_NUM_FREQ; freqIdx++)
    {
        ptEutraFreq = &eutraFreqItem[freqIdx];

        if (CI_use != ptEutraFreq->usage) continue;

        measObjIndex = ptEutraFreq->measObjIdx;
        VCCB_CHECK_E_RANGE_AND_RETURN(measObjIndex, MAX_NR_OF_OBJECTEUTRA_ID_DB);

        pMeasObj = &(pCell->measurementsData.measurementObjectsEUTRADb[measObjIndex].base);
        if (CI_use != pMeasObj->usage) continue;

        // Check UE Support Band
        if (BAND_NOT_FOUND == VCCB_GetMoEutraBandForUe(ptCi, pMeasObj, &earfcn)) continue;

        pDst = &(ptIE->freqPriorityListEUTRA[numEutraFreqItems].value);

        pDst->bit_mask = 0;
        pDst->carrierFreq = earfcn;
        pDst->cellReselectionPriority = ptEutraFreq->priority;
        if (CI_use == ptEutraFreq->subpriorityUsage)
        {
            pDst->bit_mask |= NRRRC_FreqPriorityEUTRA_cellReselectionSubPriority_present;
            pDst->cellReselectionSubPriority = (NRRRC_CellReselectionSubPriority)ptEutraFreq->subpriority;
        }
        numEutraFreqItems++;
    }

    if (0 < numEutraFreqItems)
    {
        short status =
            fnConnectLinkedList(ptIE->freqPriorityListEUTRA, sizeof(*ptIE->freqPriorityListEUTRA), numEutraFreqItems);
        if (0 != status)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "ERROR fnConnectLinkedList(NRRRC_FreqPriorityListEUTRA_) failed in %s\n", __FUNCTION__);
            return ERROR;
        }
        ptIE->bit_mask |= NRRRC_freqPriorityListEUTRA_present;
    }

    return numEutraFreqItems;
}

int8_t CellReselectionInfoSvcBasedIdleLB::Fill_CellReselectionInfo(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    SvcBasedCrpCtrl_type *pCellReselect = NULL;

    int8_t numNrFreqItems = 0, numEutraFreqItems = 0;
    uint8_t ueSvcGrpId;
    ptIE->bit_mask = 0;

    // Get Service Group of UE for every PDU Session Information change
    uint8_t isReleaseProcedure = TRUE;  // TRUE : Count 'S_Release' PDU as a service group candidate.
    if (GOOD != FnVCCB_GetServiceGroupId(ptCi, &ueSvcGrpId, isReleaseProcedure))
    {
        VCCB_PRINT_CALL_IDLE_LB(ptCi, "[SVC-IMLB] [%s]Service Group not exist\n", __FUNCTION__);
        return BREAK;
    }

    if (0 == ueSvcGrpId)
    {
        VCCB_PRINT_CALL_IDLE_LB(ptCi, "[SVC-IMLB] [%s]Service Group id is 0\n", __FUNCTION__);
        return BREAK;
    }

    VCCB_PRINT_CALL_IDLE_LB(ptCi, "[SVC-IMLB] [%s]ServiceGroupId : (%d)\n", __FUNCTION__, ueSvcGrpId);
    VCCB_CHECK_E_RANGE_AND_RETURN(ueSvcGrpId, MAX_SVC_GRP_DB_NUM);

    if (GNBINFO[ptCi->gnbNum].cfg.svcGrpBasedCfg[ueSvcGrpId].usage != CI_use ||
        GNBINFO[ptCi->gnbNum].cfg.svcGrpBasedCfg[ueSvcGrpId].svcBasedIdleLbAllowed != TRUE)
    {
        VCCB_PRINT_CALL_IDLE_LB(ptCi, "[SVC-IMLB] [%s]Service Group not allowed by gnb YANG\n", __FUNCTION__);
        return BREAK;
    }

    if (GOOD != FnVCCB_GetServiceGroupIdByServedPlmn(ueSvcGrpId, ptCi, &pCellReselect))
    {
        VCCB_PRINT_CALL_IDLE_LB(ptCi, "[SVC-IMLB] [%s]FnVCCB_GetServiceGroupIdByServedPlmn error\n", __FUNCTION__);
        return BREAK;
    }

    this->_pCellReselect = pCellReselect;
    numNrFreqItems = Fill_CellReselectionPrioritiesNR(ptCi, ptIE);
    if (ERROR == numNrFreqItems)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[SVC-IMLB] CellReselectionInfoSvcBasedIdleLB::Fill_CellReselectionPrioritiesNR ERROR!!\n");
        return BREAK;
    }

    numEutraFreqItems = Fill_CellReselectionPrioritiesEUTRA(ptCi, ptIE);
    if (ERROR == numEutraFreqItems)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[SVC-IMLB] CellReselectionInfoSvcBasedIdleLB::Fill_CellReselectionPrioritiesEUTRA ERROR!!\n");
    }

    // If any items were set, set T320 timer
    if ((numEutraFreqItems > 0) || (numNrFreqItems > 0))
    {
        VALID_E_POINT_CHECK_ERROR(pCellReselect);
        Fill_T320(ptIE, static_cast<NRRRC__enum228>(pCellReselect->t320));
    }

    // if NR and EUTRA both are not set, return error
    if (0 == ptIE->bit_mask)
    {
        return ERROR;
    }

    return GOOD;
}

bool FnVCCB_IsValid_MeasObjControl(measurementObjectNRExtensionDb_type *pMeasObjControl, uint8_t callPlmnIndex)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(pMeasObjControl, false);
    if (callPlmnIndex >= MAX_PLMN_INDEX)
    {
        if (IS_NOT_ALLOWED_PLMN_BASED_CONTROL(pMeasObjControl))
        {
            return false;
        }
    }
    else
    {
        if (IS_NOT_ALLOWED_PLMN_SUPPORT(pMeasObjControl, callPlmnIndex))
        {
            return false;
        }
    }

    return true;
}

int16_t FnVCCB_IsPossible_Automode_Cond_Threshold(callInfo_type *ptCi, bool isCaProfileBased, const bool isRedCapUeMode)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    measurementObjectNRExtensionDb_type *pMeasObjControl = NULL;

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    const uint8_t callPlmnIndex = VLIB_FindGnbPlmnIndexOfCall(ptCi);
    float sumOfDist_Inter = 0;
    int freqIdx = 0;
    uint8_t measObjIndex = 0;

    if (isRedCapUeMode || isCaProfileBased || access_s5gtype_idle_lb_auto_mode != pCell->lbCfg.idleModeInfo.oprModeforLb)
    {
        return GOOD;
    }

    VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] Check Automode condition\n");

    // if (pCell->lbCfg.idleModeInfo.oprModeforLb == access_s5gtype_idle_lb_auto_mode)
    //  need to check measObjUeDistRatio is valid
    long diffTime = VLIB_getTickDifference(pCell->idleMobilityInfo.lastUpdatedTime) / 1000;
    if (diffTime > static_cast<long>(GNBINFO[ptCi->gnbNum].idleMobilityControl.periodForUeDistRatio * 60 * 2))
    {
        VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] Idle LB Info is Expired(%ld/%u)\n", diffTime,
            GNBINFO[ptCi->gnbNum].idleMobilityControl.periodForUeDistRatio * 60 * 2);
        return ERROR;
    }

    uint8_t autoModeUeNumThreshold = pCell->nrLbmConfigurationIndex != NR_LBM_DISABLE
                                         ? pCell->lbCfg.lbmConfiguration.idleLbInfo.cellConfig.ueNumThresholdForAutoMode
                                         : pCell->lbCfg.idleModeInfo.triggerThresholdforLb;
    uint8_t currUeNum = static_cast<uint8_t>(100 - pCell->cellRscInfo.numAvailUe);
    if (currUeNum < autoModeUeNumThreshold)
    {
        VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] Automode condition not met currUeNum(%u) < autoModeUeNumThreshold(%u)\n",
            pCell->cellRscInfo.numAvailUe, autoModeUeNumThreshold);
        return ERROR;
    }

    // sum of inter frequency
    for (freqIdx = 1; freqIdx < MAX_NUM_FREQ + 1; freqIdx++)
    {
        nrCellReselectInfo_type *pNrCR = &pCell->lbCellResel[freqIdx].nrFreqItem;
        measObjIndex = pCell->lbCellResel[freqIdx].nrFreqItem.measObjIdx;
        VCCB_CHECK_E_RANGE_AND_RETURN(measObjIndex, MAX_NR_OF_OBJECT_ID_DB);
        pMeasObjControl = &pCell->measurementsData.measurementObjectsNRDb[measObjIndex].extension;

        if (CI_no_use == pNrCR->usage) continue;

        // condition for candidate
        if (false == FnVCCB_IsValid_MeasObjControl(pMeasObjControl, callPlmnIndex))
        {
            continue;
        }

        if (false == FnVCCB_IsValidCarrier_IdleLB(ptCi, measObjIndex))
        {
            continue;
        }

        sumOfDist_Inter += pCell->idleMobilityInfo.measObjUeDistRatio[measObjIndex].ueDistRatioDl;
    }

    if (0 == sumOfDist_Inter)
    {
        VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] Automode condition not met (sumOfDist_Inter(%.3f))\n", (double)sumOfDist_Inter);
        return ERROR;
    }

    VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] Automode condition met (sumOfDist_Inter(%.3f))\n", (double)sumOfDist_Inter);
    return GOOD;
}

int16_t FnVCCB_Make_lbBasedCellResel(callInfo_type *ptCi, lbBasedCellResel_type *src,
    nrCellReselectInfo_type *candidateFreqList, const bool isCaProfileBased, const bool isRedCapUeMode)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(src);
    VALID_E_POINT_CHECK_ERROR(candidateFreqList);

    if (ERROR == FnVCCB_IsPossible_Automode_Cond_Threshold(ptCi, isCaProfileBased, isRedCapUeMode))
    {
        VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] It is set to automode but threshould is not met\n");
        return ERROR;
    }

    int numOfCandidateFreqList = 0;
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    auto lbmConfigIndex = pCell->nrLbmConfigurationIndex;
    int const lbmParameterSetIndex = lbmConfigIndex - 1;
    cellLbmConfiguration_type::idleLbInfoLbm_s::idleLbInfoLbmParameterSet_s *pLbmIdleLbInfo = nullptr;
    if(lbmParameterSetIndex >= 0 && lbmParameterSetIndex < MAX_NR_LBM_CONFIG_ENTRIES - 1)
    {
        auto const &rLbmIdleLbInfo = pCell->lbCfg.lbmConfiguration.idleLbInfo.parameterSet[lbmParameterSetIndex];
        if(rLbmIdleLbInfo.usage == CI_use)
        {
            VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] LBM Set Index: %d\n", lbmParameterSetIndex);
            pLbmIdleLbInfo = &pCell->lbCfg.lbmConfiguration.idleLbInfo.parameterSet[lbmParameterSetIndex];
        }
    }

    for (int freqIdx = 0; freqIdx < MAX_NUM_FREQ + 1; freqIdx++)
    {
        nrCellReselectInfo_type *pNrCR = &pCell->lbCellResel[freqIdx].nrFreqItem;
        uint8_t measObjIndex = pCell->lbCellResel[freqIdx].nrFreqItem.measObjIdx;
        VCCB_CHECK_E_RANGE_AND_RETURN(measObjIndex, MAX_NR_OF_OBJECT_ID_DB);
        measurementObjectNRExtensionDb_type *pMeasObjControl =
            &pCell->measurementsData.measurementObjectsNRDb[measObjIndex].extension;

        if (CI_no_use == pNrCR->usage) continue;

        const uint8_t callPlmnIndex = VLIB_FindGnbPlmnIndexOfCall(ptCi);
        if (false == FnVCCB_IsValid_MeasObjControl(pMeasObjControl, callPlmnIndex))
        {
            continue;
        }

        if (!FnVCCB_IsValid_MeasObj_CellReselection(ptCi, measObjIndex))
        {
            continue;
        }

        // update ueDistributionRatio to appropriate value
        nrCellReselectInfo_type &candidateFreq = candidateFreqList[numOfCandidateFreqList];
        memcpy(&candidateFreq, &(src[freqIdx].nrFreqItem), sizeof(candidateFreq));

        if(pLbmIdleLbInfo)
        {
            if(freqIdx == 0)
            {
                candidateFreq.plmnueDistributionRatio[0] = pLbmIdleLbInfo->intraFreq.ueDistributionRatioForPlmnMode[0];
                candidateFreq.plmnueDistributionRatio[1] = pLbmIdleLbInfo->intraFreq.ueDistributionRatioForPlmnMode[1];
                candidateFreq.ueDistributionRatio = pLbmIdleLbInfo->intraFreq.ueDistributionRatioForNonPlmnMode;
                candidateFreq.weightInAutoModeforLb = pLbmIdleLbInfo->intraFreq.weightFactorForAutoMode;
            }
            else
            {
                VCCB_CHECK_E_RANGE_AND_RETURN(freqIdx - 1, MAX_NUM_FREQ);
                candidateFreq.plmnueDistributionRatio[0] = pLbmIdleLbInfo->interFreq[freqIdx - 1].ueDistributionRatioForPlmnMode[0];
                candidateFreq.plmnueDistributionRatio[1] = pLbmIdleLbInfo->interFreq[freqIdx - 1].ueDistributionRatioForPlmnMode[1];
                candidateFreq.ueDistributionRatio = pLbmIdleLbInfo->interFreq[freqIdx - 1].ueDistributionRatioForNonPlmnMode;
                candidateFreq.weightInAutoModeforLb = pLbmIdleLbInfo->interFreq[freqIdx - 1].weightFactorForAutoMode;
            }
        }

        candidateFreq.index = (uint8_t)numOfCandidateFreqList;

        numOfCandidateFreqList++;

        if(isRedCapUeMode)
        {
            candidateFreq.ueDistributionRatio = candidateFreq.ueDistributionRatioForRedCapUE;
        }
        // CA profile based LB operation
        else if (isCaProfileBased)
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->caProfileIdx, MAX_CA_PROFILE_NUM);
            candidateFreq.ueDistributionRatio =
                pCell->lbCfg.idleModeInfo.ueDistributionRatio_caProfile[ptCi->caProfileIdx][freqIdx];
        }
        // Auto mode based LB operation
        else if ((access_s5gtype_idle_lb_auto_mode == pCell->lbCfg.idleModeInfo.oprModeforLb) &&
                 (candidateFreq.measObjIdx < MAX_MEAS_OBJECT_ENTRIES + 1))
        {
            // need to check measObjUeDistRatio is valid
            long diffTime = VLIB_getTickDifference(pCell->idleMobilityInfo.lastUpdatedTime) / 1000;
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
            if (diffTime > static_cast<long>(GNBINFO[ptCi->gnbNum].idleMobilityControl.periodForUeDistRatio * 60 * 2))
            {
                VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] Idle LB Info is Expired(%ld/%u)\n", diffTime,
                    GNBINFO[ptCi->gnbNum].idleMobilityControl.periodForUeDistRatio * 60 * 2);
                continue;
            }
            candidateFreq.ueDistributionRatio =
                candidateFreq.weightInAutoModeforLb *
                pCell->idleMobilityInfo.measObjUeDistRatio[candidateFreq.measObjIdx].ueDistRatioDl;
        }
        // PLMN based(Manual mode) LB operation
        else if (pCell->lbCfg.idleModeInfo.distributionRatioPerPlmnSwitch)
        {
            if (callPlmnIndex >= MAX_PLMN_INDEX)
            {
                candidateFreq.usage = CI_no_use;
                VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] invalid call plm index(%d) in %s\n", callPlmnIndex, __FUNCTION__);
                return ERROR;
            }
            candidateFreq.ueDistributionRatio = candidateFreq.plmnueDistributionRatio[callPlmnIndex];
        }
        // non-PLMN based(Manual mode) LB operation
        else
        {
            VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] non-PLMN based(Manual mode) LB operation\n");
        }
    }

    VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] %s to make cell reselction priority candidate(%u) in %s\n",
        0 == numOfCandidateFreqList ? "Failed" : "Success", numOfCandidateFreqList, __func__);

    return (numOfCandidateFreqList > 0) ? GOOD : ERROR;
}

void FnVCCB_frequencySelectionCnt(callInfo_type *ptCi, uint8_t measObjIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    lbBasedCellResel_type *highestLbCellResel = nullptr;
    for(auto &iter : pCell->lbCellResel)
    {
        if(iter.nrFreqItem.measObjIdx == measObjIdx) highestLbCellResel = &iter;
    }

    if (highestLbCellResel == nullptr)
    {
        VCCB_PRINT_CALL_IDLE_LB(
            ptCi, "[IMLB] measObjIdx(%u) is not found in lbCellResel in %s\n", measObjIdx, __func__);
        return;
    }

    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    if (UINT16_MAX == highestLbCellResel->nrFreqSelectCnt[ptCi->myThreadId])
    {
        highestLbCellResel->nrFreqSelectCnt[ptCi->myThreadId] = 0;
    }

    highestLbCellResel->nrFreqSelectCnt[ptCi->myThreadId]++;
}

int8_t CellReselectionInfoIdleLB::Fill_CellReselectionPrioritiesNR(
    callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    nrCellReselectInfo_type candidateFreqs[MAX_NUM_FREQ + 1];

    memset(candidateFreqs, 0, sizeof(candidateFreqs));
    if (ERROR == FnVCCB_Make_lbBasedCellResel(ptCi, pCell->lbCellResel, candidateFreqs, _isCaProfileBased, _isRedCapUeMode))
    {
        VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] ERROR: FnVCCB_Make_lbBasedCellResel failed in %s\n", __FUNCTION__);
        return ERROR;
    }

    int16_t highIdx = 0;
    if (GOOD != VCCB_MakeLbBasedCellReselectionPrioritiesNR(ptCi, candidateFreqs, &highIdx))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[IMLB] ERROR: VCCB_MakeLbBasedCellReselectionPrioritiesNR failed in %s\n", __FUNCTION__);
        return ERROR;
    }

    if (0 !=
        fnGlobalValueAlloc((uint8_t **)&ptIE->freqPriorityListNR, sizeof(*ptIE->freqPriorityListNR) * MAX_NUM_FREQ))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[IMLB] ERROR: fnGlobalValueAlloc failed in %s\n", __FUNCTION__);
        return ERROR;
    }

    _nrMinPriority = 0xFF;
    int8_t numOfFreqPriorityList = 0;
    for (auto &candidateFreq : candidateFreqs)
    {
        if (CI_use != candidateFreq.usage) continue;

        NRRRC_FreqPriorityNR &dst = ptIE->freqPriorityListNR[numOfFreqPriorityList].value;

        dst.bit_mask = 0;
        VCCB_CHECK_E_RANGE_AND_RETURN(candidateFreq.measObjIdx, MAX_NR_OF_OBJECT_ID_DB);
        dst.carrierFreq = pCell->measurementsData.measurementObjectsNRDb[candidateFreq.measObjIdx].base.ssbFrequency;
        dst.cellReselectionPriority = candidateFreq.priority;
        if (CI_use == candidateFreq.subpriorityUsage)
        {
            dst.bit_mask |= NRRRC_FreqPriorityNR_cellReselectionSubPriority_present;
            dst.cellReselectionSubPriority = (NRRRC_CellReselectionSubPriority)candidateFreq.subpriority;
        }

        /*Get minimum cell reselection priority value in NR*/
        int32_t priority = VCCB_CrpToIntegerNr(&candidateFreq);
        if (priority < _nrMinPriority)
        {
            _nrMinPriority = (uint8_t)priority;
        }
        numOfFreqPriorityList++;
    }

    if (0 < numOfFreqPriorityList)
    {
        short status = fnConnectLinkedList(ptIE->freqPriorityListNR, sizeof(*ptIE->freqPriorityListNR), numOfFreqPriorityList);
        if (0 != status)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "ERROR fnConnectLinkedList(NRRRC_FreqPriorityListNR_) failed in %s\n", __FUNCTION__);
            return ERROR;
        }
        ptIE->bit_mask |= NRRRC_freqPriorityListNR_present;

        VCCB_CHECK_E_RANGE_AND_RETURN(highIdx, (MAX_NUM_FREQ + 1));
        auto &highestPriorityFreq = candidateFreqs[highIdx];

        FnVCCB_frequencySelectionCnt(ptCi, highestPriorityFreq.measObjIdx);

        VCCB_CHECK_E_RANGE_AND_RETURN(highestPriorityFreq.measObjIdx, MAX_NR_OF_OBJECT_ID_DB);
        uint32_t selectedFreq =
            pCell->measurementsData.measurementObjectsNRDb[highestPriorityFreq.measObjIdx].base.ssbFrequency;
        MACRO_STAT_PMCC(STAT_INTRA_NR_IDLE_LB, UE_Count_IntraNrIdle, ptCi, selectedFreq, 0, 0, 0, 0);
        if (IS_REDCAP_UE(ptCi))
        {
            MACRO_STAT_PMCC(STAT_INTRA_NR_IDLE_LB, UE_Count_RedCap_IntraNrIdle, ptCi, selectedFreq, 0, 0, 0, 0);
        }
    }

    return numOfFreqPriorityList;
}

int16_t FnVCCB_Make_eutraCellReselect(
    callInfo_type *ptCi, eutraCellReselectInfo_type *pSrc, eutraCellReselectInfo_type *pDst)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pSrc);
    VALID_E_POINT_CHECK_ERROR(pDst);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    idleModeInfo_type *pIdleModeInfo = &pCell->lbCfg.idleModeInfo;
    measurementObjectEUTRAExtensionDb_type *pMeasObjControl = NULL;
    measurementObjectEUTRABaseDb_type *pMeasObj = NULL;

    const uint8_t distRatio_Plmn_Switch = pIdleModeInfo->distributionRatioPerPlmnSwitch;
    const uint8_t callPlmnIndex = VLIB_FindGnbPlmnIndexOfCall(ptCi);
    int freqIdx = 0, cnt = 0;
    uint8_t measObjIndex = 0;
    uint32_t carrierFreq = 0;

    for (freqIdx = 0; freqIdx < MAX_NUM_FREQ; freqIdx++)
    {
        eutraCellReselectInfo_type *pEutraCR = &pCell->eutraCellReselect[freqIdx];
        measObjIndex = pEutraCR->measObjIdx;
        VCCB_CHECK_E_RANGE_AND_RETURN(measObjIndex, MAX_NR_OF_OBJECTEUTRA_ID_DB);
        pMeasObjControl = &pCell->measurementsData.measurementObjectsEUTRADb[measObjIndex].extension;
        pMeasObj = &pCell->measurementsData.measurementObjectsEUTRADb[measObjIndex].base;

        if (CI_no_use == pEutraCR->usage) continue;
        if (callPlmnIndex >= MAX_PLMN_INDEX)
        {
            if (distRatio_Plmn_Switch)
            {
                VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] freqIdx(%u) is distRatio_Plmn_Switch on(%d) in %s\n", freqIdx,
                    distRatio_Plmn_Switch, __FUNCTION__);
                continue;
            }
        }
        if (BAND_NOT_FOUND == VCCB_GetMoEutraBandForUe(ptCi, pMeasObj, &carrierFreq))
        {
            // not supported by UE
            continue;
        }

        if (IS_NOT_ALLOWED_PLMN_SUPPORT(pMeasObjControl, callPlmnIndex))
        {
            VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] freqIdx(%u) is not-allowed-plmn in %s\n", freqIdx, __FUNCTION__);
            continue;
        }

        memcpy(&pDst[cnt], &(pSrc[freqIdx]), sizeof(pDst[cnt]));
        pDst[cnt].index = (uint8_t)cnt;
        cnt++;
    }

    if (0 == cnt)
    {
        return ERROR;
    }
    return GOOD;
}

int8_t CellReselectionInfoIdleLB::Fill_CellReselectionPrioritiesEUTRA(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];
    eutraCellReselectInfo_type eutraFreqItem[MAX_NUM_FREQ];
    eutraCellReselectInfo_type *ptEutraFreq = NULL;
    int8_t numEutraFreqItems = 0;
    uint8_t freqIdx = 0;
    uint8_t measObjIndex = 0;
    measurementObjectEUTRABaseDb_type *pMeasObj = NULL;
    NRRRC_FreqPriorityEUTRA *pDst = NULL;
    uint32_t earfcn = 0;

    memset(eutraFreqItem, 0, sizeof(eutraFreqItem));
    if (ERROR == FnVCCB_Make_eutraCellReselect(ptCi, pCell->eutraCellReselect, eutraFreqItem))
    {
        VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] ERROR: FnVCCB_Make_eutraCellReselect failed in %s\n", __FUNCTION__);
        return ERROR;
    }

    if (0 != fnGlobalValueAlloc(
                 (uint8_t **)&ptIE->freqPriorityListEUTRA, sizeof(*ptIE->freqPriorityListEUTRA) * MAX_NUM_FREQ))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ERROR: fnGlobalValueAlloc failed in CellReselectionInfoIdleLB::Fill_CellReselectionPrioritiesEUTRA\n");
        return ERROR;
    }

    /*Set EUTRA cell reselect Priority */
    VCCB_SetCellReselectEutraPriorityIdleLB(_nrMinPriority, eutraFreqItem);

    for (freqIdx = 0; freqIdx < MAX_NUM_FREQ; freqIdx++)
    {
        ptEutraFreq = &eutraFreqItem[freqIdx];

        if (CI_use != ptEutraFreq->usage) continue;

        measObjIndex = ptEutraFreq->measObjIdx;
        VCCB_CHECK_E_RANGE_AND_RETURN(measObjIndex, MAX_NR_OF_OBJECTEUTRA_ID_DB);
        pMeasObj = &(pCell->measurementsData.measurementObjectsEUTRADb[measObjIndex].base);
        if (CI_use != pMeasObj->usage) continue;

        // Check UE Support Band
        if (BAND_NOT_FOUND == VCCB_GetMoEutraBandForUe(ptCi, pMeasObj, &earfcn)) continue;

        pDst = &(ptIE->freqPriorityListEUTRA[numEutraFreqItems].value);

        pDst->bit_mask = 0;
        pDst->carrierFreq = earfcn;
        pDst->cellReselectionPriority = ptEutraFreq->priority;
        if (CI_use == ptEutraFreq->subpriorityUsage)
        {
            pDst->bit_mask |= NRRRC_FreqPriorityEUTRA_cellReselectionSubPriority_present;
            pDst->cellReselectionSubPriority = (NRRRC_CellReselectionSubPriority)ptEutraFreq->subpriority;
        }
        numEutraFreqItems++;
    }

    if (0 < numEutraFreqItems)
    {
        short status =
            fnConnectLinkedList(ptIE->freqPriorityListEUTRA, sizeof(*ptIE->freqPriorityListEUTRA), numEutraFreqItems);
        if (0 != status)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "ERROR fnConnectLinkedList(NRRRC_FreqPriorityListEUTRA_) failed in %s\n", __FUNCTION__);
            return ERROR;
        }
        ptIE->bit_mask |= NRRRC_freqPriorityListEUTRA_present;
    }

    return numEutraFreqItems;
}

int8_t CellReselectionInfoIdleLB::Fill_CellReselectionInfo(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    ptIE->bit_mask = 0;

    int8_t numNrFreqItems = ERROR;
    if (pCell->lbCfg.idleModeInfo.redCapFlag && IS_REDCAP_UE(ptCi))
    {
        _isRedCapUeMode = true;
        VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] Try RedCap Ue Based Mode\n");
        numNrFreqItems = Fill_CellReselectionPrioritiesNR(ptCi, ptIE);
        if (ERROR == numNrFreqItems)
        {
            VCCB_PRINT_CALL_IDLE_LB(
                ptCi, "[IMLB] RedCap based CellReselectionInfoIdleLB::Fill_CellReselectionPrioritiesNR ERROR!!\n");
            return ERROR;
        }
    }
    else
    {
        _isRedCapUeMode = false;
        if (VCCB_CA_PROFILE_SUPPORT(ptCi))
        {
            _isCaProfileBased = true;
            VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] Try Ca Profile Based Mode\n");
            numNrFreqItems = Fill_CellReselectionPrioritiesNR(ptCi, ptIE);
            if (ERROR == numNrFreqItems)
            {
                VCCB_PRINT_CALL_IDLE_LB(ptCi,
                    "[IMLB] CA profile based CellReselectionInfoIdleLB::Fill_CellReselectionPrioritiesNR ERROR!!\n");
            }
        }

        if ((ERROR == numNrFreqItems) && (VCCB_FLAG_ON == (pCell->nrLbmConfigurationIndex != NR_LBM_DISABLE)
                                                 ? pCell->lbCfg.lbmConfiguration.idleLbInfo.cellConfig.legacyModeFlag
                                                 : pCell->lbCfg.idleModeInfo.legacyIdleLbSwitch))
        {
            if (access_s5gtype_idle_lb_auto_mode == pCell->lbCfg.idleModeInfo.oprModeforLb)
            {
                VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] Try Auto Mode\n");
            }
            else if (pCell->lbCfg.idleModeInfo.distributionRatioPerPlmnSwitch)
            {
                VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] Try PLMN Mode\n");
            }
            else
            {
                VCCB_PRINT_CALL_IDLE_LB(ptCi, "[IMLB] Try non-PLMN Mode\n");
            }
            _isCaProfileBased = false;
            numNrFreqItems = Fill_CellReselectionPrioritiesNR(ptCi, ptIE);
            if (ERROR == numNrFreqItems)
            {
                VCCB_PRINT_CALL_IDLE_LB(
                    ptCi, "[IMLB] Legacy CellReselectionInfoIdleLB::Fill_CellReselectionPrioritiesNR ERROR!!\n");
                return ERROR;
            }
        }
    }

    int8_t numEutraFreqItems = 0;
    numEutraFreqItems = Fill_CellReselectionPrioritiesEUTRA(ptCi, ptIE);
    if (ERROR == numEutraFreqItems)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[IMLB] CellReselectionInfoIdleLB::Fill_CellReselectionPrioritiesEUTRA ERROR!!\n");
    }

    // If any items were set, set T320 timer
    if ((numEutraFreqItems > 0) || (numNrFreqItems > 0))
    {
        Fill_T320(ptIE, static_cast<NRRRC__enum228>(pCell->cellRfspBasedCtrl.t320));
    }

    // if NR and EUTRA both are not set, return error
    if (0 == ptIE->bit_mask)
    {
        return ERROR;
    }

    return GOOD;
}

enum enumReselectionType
{
    securityProcedureNotDone,
    isRfspBasedInterRatRedirection,
    isFallbackCase,
    rfspCRP,
    svcBasedIdleLB,
    svcBased5QIPLMN,
    plmnBasedMobilityControl,
    svcIdleMobilityControl,
    crpNotConfigured
};

std::string getReselectionTypeString(enumReselectionType type) {
    switch(type) {
        case securityProcedureNotDone:
            return "securityProcedureNotDone";
        case isRfspBasedInterRatRedirection:
            return "isRfspBasedInterRatRedirection";
        case isFallbackCase:
            return "isFallbackCase";
        case rfspCRP:
            return "rfspCRP";
        case svcBasedIdleLB:
            return "svcBasedIdleLB";
        case svcBased5QIPLMN:
            return "svcBased5QIPLMN";
        case plmnBasedMobilityControl:
            return "plmnBasedMobilityControl";
        case svcIdleMobilityControl:
            return "svcIdleMobilityControl";
        case crpNotConfigured:
            return "crpNotConfigured";
        default:
            return "Unknown Reselection Type";
    }
}

void FnVCCB_PRINT_NRRRC_CellReselectionPriorities(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE, const std::stringstream &crpCandidate, enumReselectionType crpType)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptIE);

    std::ostringstream nr, eutra;
    struct NRRRC_FreqPriorityListNR_* pNr = ptIE->freqPriorityListNR;
    if(ptIE->bit_mask & NRRRC_freqPriorityListNR_present)
    {
        while(pNr != NULL)
        {
            nr << pNr->value.cellReselectionPriority << " ";
            pNr = pNr->next;
        }
    }

    struct NRRRC_FreqPriorityListEUTRA_* pEutra = ptIE->freqPriorityListEUTRA;
    if(ptIE->bit_mask & NRRRC_freqPriorityListEUTRA_present)
    {
        while(pEutra != NULL)
        {
            eutra << pEutra->value.cellReselectionPriority << " ";
            pEutra = pEutra->next;
        }
    }        

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "(CRP) Candidated CRP methods: %s\n", crpCandidate.str().c_str());
    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "(CRP) CRP Information: crpMethod[%s] NR[%s] EUTRA[%s]\n", 
        getReselectionTypeString(crpType).c_str(), nr.str().c_str(), eutra.str().c_str());
}

/**
 * @brief Creates an instance of CellReselectionInfo based on the given reselection type.
 * @param  type           : The type of cell reselection to create.
 * @param  crpCandidate   : string stream that will be updated with a description of the chosen type.
 */
std::unique_ptr<CellReselectionInfo> CreateCellReselectionInfo(
    const enumReselectionType type, std::stringstream &crpCandidate)
{
    switch (type)
    {
        case isFallbackCase:
            crpCandidate << "isFallbackCase ";
            return std::make_unique<CellReselectionInfoFallback>();
        case rfspCRP:
            crpCandidate << "rfspCRP ";
            return std::make_unique<CellReselectionInfoRFSP>();
        case svcBasedIdleLB:
            crpCandidate << "svcBasedIdleLB ";
            return std::make_unique<CellReselectionInfoSvcBasedIdleLB>();
        case svcBased5QIPLMN:
            crpCandidate << "svcBased5QIPLMN ";
            return std::make_unique<CellReselectionInfoSvcBasedMobilityControl>();
        case plmnBasedMobilityControl:
            crpCandidate << "plmnBasedMobilityControl ";
            return std::make_unique<CellReselectionInfoPlmnBasedMobilityControl>();
        case svcIdleMobilityControl:
            crpCandidate << "svcIdleMobilityControl ";
            return std::make_unique<CellReselectionInfoIdleLB>();
        default:
            return nullptr;
    }
}

/**
 * @brief This function processes Cell Reselection Information based on the provided call information
 * @param  ptCi                : pointer to UE Context base on which message is filled in
 * @param  ptIE                : pointer to IE of RRCRelease structure to be filled in
 * @param  cellReselectionInfo : Unique pointer to the CellReselectionInfo object.
 * @param  type                : The type of cell reselection to create.
 * @param  crpCandidate        : string stream that will be updated with a description of the chosen type.
 */
int16_t HandleCellReselectionInfo(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE,
    std::unique_ptr<CellReselectionInfo> cellReselectionInfo, const enumReselectionType type,
    std::stringstream &crpCandidate)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);

    int status = cellReselectionInfo->Fill_CellReselectionInfo(ptCi, ptIE);
    if (status == GOOD)
    {
        if (DBG->flag.logRrcReleaseInfo)
        {
            FnVCCB_PRINT_NRRRC_CellReselectionPriorities(ptCi, ptIE, crpCandidate, type);
        }
        return GOOD;
    }

    return BREAK;
}

/**
 * @brief Processes Cell Reselection Information based on the given parameters.
 * @param  ptCi                : pointer to UE Context base on which message is filled in
 * @param  ptIE                : pointer to IE of RRCRelease structure to be filled in
 * @param  type                : The type of cell reselection to create.
 * @param  crpCandidate        : string stream that will be updated with a description of the chosen type.
 */
int16_t ProcessCellReselectionInfo(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE,
    const enumReselectionType type, std::stringstream &crpCandidate)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);

    std::unique_ptr<CellReselectionInfo> cellReselectionInfo = CreateCellReselectionInfo(type, crpCandidate);
    if (cellReselectionInfo != nullptr)
    {
        return HandleCellReselectionInfo(ptCi, ptIE, std::move(cellReselectionInfo), type, crpCandidate);
    }

    return BREAK;
}

/**
 * @brief Filling in RRC Message IEs for CellReselectionInfo IEs to send it from CU to DU
 * @param  ptCi           : pointer to UE Context base on which message is filled in
 * @param  ptIE           : pointer to IE of RRCRelease structure to be filled in
 * @return int16_t        : result of operation
 */
int16_t Fill_CellReselectionInfo(
    callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE, uint8_t isRedirectedCarrierPresent)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptIE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    int16_t status = GOOD;
    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    ptIE->bit_mask = 0;
    std::stringstream crpCandidate;
    std::unique_ptr<CellReselectionInfo> cellReselectionInfo;

    // gNB Can send Cell Reselection parameter after Security procedure done.
    if (!FnVCCB_IsSecurityProcedureDone(ptCi))
    {
        crpCandidate << "securityProcedureNotDone ";
        if(DBG->flag.logRrcReleaseInfo)
        {
            FnVCCB_PRINT_NRRRC_CellReselectionPriorities(ptCi, ptIE, crpCandidate, securityProcedureNotDone);
        }
        return BREAK;
    }

    /*
    Overview (Priority of CellReselectionPriorities)
    0. RFSP based Inter-Rat Redirection
    1. Fallback
    2. RFSP based dedicated priority
    3. Service based Idle load balancing
    4. Service(5QI/PLMN) based Mobility Control
    5. PLMN based Mobility Control
    6. Idle mobility control for NR
    */

    // Cond0. RFSP based Inter-Rat Redirection
    if (IS_RFSP_BLIND_INTER_RAT_REDIRECTION(ptCi))
    {
        crpCandidate << "isRfspBasedInterRatRedirection ";
        status = FnVCCB_Fill_CellReselectionInfoRfspBlindInterRat(ptCi, ptIE);
        if(DBG->flag.logRrcReleaseInfo)
        {
            FnVCCB_PRINT_NRRRC_CellReselectionPriorities(ptCi, ptIE, crpCandidate, isRfspBasedInterRatRedirection);
        }
        return status;
    }

    // Cond1. Fallback Using RFSP Algorithm for NRRRC_RedirectedCarrierInfo
    if (IS_FALLBACK_CASE(ptCi) || IS_SPECIFIC_SLICE_REDIRECTION(ptCi))
    {
        if (ProcessCellReselectionInfo(ptCi, ptIE, isFallbackCase, crpCandidate) == GOOD)
        {
            return GOOD;
        }
    }

    // Cond2. CellReselectionPriorities - RFSP
    if (VCCB_FLAG_ON == pCell->cellRfspBasedCtrl.rfspBasedCellReselectUsage)
    {
        if (ProcessCellReselectionInfo(ptCi, ptIE, rfspCRP, crpCandidate) == GOOD)
        {
            return GOOD;
        }
    }

    // Cond3. Service based Idle load balancing
    if ((VCCB_FLAG_ON == pCell->lbCfg.serviceBasedIdleLbSwitch) && (isRedirectedCarrierPresent == FALSE))
    {
        if (ProcessCellReselectionInfo(ptCi, ptIE, svcBasedIdleLB, crpCandidate) == GOOD)
        {
            return GOOD;
        }
    }

    // Cond4. Service(5QI/PLMN) Based
    if (FOO.VF_StandAlone_BasicCallOperationForSa)
    {
        if ((VCCB_FLAG_ON == pCell->mobilityConfig.serviceBasedCellReselectSupport) &&
            (isRedirectedCarrierPresent == FALSE))
        {
            if (ProcessCellReselectionInfo(ptCi, ptIE, svcBased5QIPLMN, crpCandidate) == GOOD)
            {
                return GOOD;
            }
        }
    }

    // Cond5. PLMN based Mobility Control (SVR25A FGR-MC1015 FR100)
    if (VCCB_FLAG_ON == pCell->mobilityConfig.plmnBasedDedicatedPrioritySupport && isRedirectedCarrierPresent == FALSE)
    {
        ptIE->bit_mask = 0;
        if (ProcessCellReselectionInfo(ptCi, ptIE, plmnBasedMobilityControl, crpCandidate) == GOOD)
        {
            return GOOD;
        }
    }

    // Cond6. Idle mobility control for NR
    if (VCCB_FLAG_ON == pCell->lbCfg.idleModeLbInfo.usage)
    {
        if (ProcessCellReselectionInfo(ptCi, ptIE, svcIdleMobilityControl, crpCandidate) == GOOD)
        {
            return GOOD;
        }
    }

    return BREAK;
}

/* EOF */
