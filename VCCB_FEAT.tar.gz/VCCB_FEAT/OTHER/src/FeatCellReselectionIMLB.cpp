// #include "FeatCellReselection.h"
// #include "ComInclude.h"
// #include "ComLibUtility.h"
// #include "FeatMeasurements.hpp"
// #include "FeatCallProc.h"
// #include "FeatCommon.h"
// #include "access_common_yang.h"
// #include <random>

// template<typename T>
// uint8_t IdleLBCellReselection::getCrpPriority(const T &crp)
// {
//     AUTO_TRACE_FUNC;
//     const uint8_t baseValue = static_cast<uint8_t>(crp.priority * 10);
    
//     return static_cast<uint8_t>((crp.subpriorityUsage == CI_no_use) 
//         ? baseValue
//         : baseValue + ((crp.subpriority + 1) * 2));
// }

// template<typename T>
// void IdleLBCellReselection::setCrpPriority(int score, T &crp)
// {
//     AUTO_TRACE_FUNC;
//     score = (score < 0) ? 0 : score;

//     const uint8_t quotient = static_cast<uint8_t>(score / 10);
//     const uint8_t remainder = static_cast<uint8_t>(score % 10);

//     crp.priority = quotient;

//     if (remainder != 0)
//     {
//         crp.subpriority = static_cast<uint8_t>(remainder / 2 - 1);
//         crp.subpriorityUsage = CI_use;
//     }
//     else
//     {
//         crp.subpriority = 0;
//         crp.subpriorityUsage = CI_no_use;
//     }
// }

// void IdleLBCellReselection::printNrCrpCandidate(std::string func)
// {
//     if (DBG->flag.logIdleLB)
//     {
//         VCCB_PRINT_CALL_ERROR(&call, "[IMLB] %s\n", func.c_str());
//         for (auto nrCrpCandidate : nrCrpCandidates)
//         {
//             VCCB_PRINT_CALL_ERROR(&call, "[IMLB] [%u] freq:%u, priority:%u, distRatio:%f\n", nrCrpCandidate.measObjIdx,
//                 nrCrpCandidate.frequency,
//                 (nrCrpCandidate.priority * 10 +
//                     ((nrCrpCandidate.subpriorityUsage == CI_use) ? (nrCrpCandidate.subpriority + 1) * 2 : 0)),
//                 static_cast<double>(nrCrpCandidate.ueDistributionRatio));
//         }
//     }
// }

// void IdleLBCellReselection::printEutraCrpCandidate(std::string func)
// {
//     if (DBG->flag.logIdleLB)
//     {
//         VCCB_PRINT_CALL_ERROR(&call, "[IMLB] %s\n", func.c_str());
//         for (auto eutraCrpCandidate : eutraCrpCandidates)
//         {
//             VCCB_PRINT_CALL_ERROR(&call, "[IMLB] [%u] freq:%u, priority:%u\n", eutraCrpCandidate.measObjIdx,
//                 eutraCrpCandidate.frequency,
//                 eutraCrpCandidate.priority * 10 +
//                     ((eutraCrpCandidate.subpriorityUsage == CI_use) ? (eutraCrpCandidate.subpriority + 1) * 2 : 0));
//         }
//     }
// }

// bool IdleLBCellReselection::checkHighestNrCrpCandidateCondition(const crpCandidate_type &nrCrp)
// {
//     AUTO_TRACE_FUNC;

//     if (nrCrp.ueDistributionRatio == 0)
//     {
//         return false;
//     }

//     VCCB_CHECK_E_RANGE_AND_VAL(nrCrp.measObjIdx, MAX_NR_OF_OBJECT_ID_DB, false);
//     VALID_E_POINT_CHECK_RET_VAL(pCell, false);
//     const auto &measObj = pCell->measurementsData.measurementObjectsNRDb[nrCrp.measObjIdx].base;
//     if (not VCCB_GetMoNrBandForUe(&call, &measObj))
//     {
//         return false;
//     }

//     if (ERROR == VCCM_FindSaEnabledNbr(&call, RSType_SSB, measObj.ssbFrequency))
//     {
//         return false;
//     }

//     return true;
// }

// IdleLBCellReselection::crpCandidate_type *IdleLBCellReselection::selectHighestNrCrp()
// {
//     AUTO_TRACE_FUNC;

//     std::vector<crpCandidate_type *> highestNrCrpCandidates;
//     for (auto &nrCrpCandidate : nrCrpCandidates)
//     {
//         if (nrCrpCandidate.measObjIdx == INTRAFREQ_OBJECT_IDX ||
//             checkHighestNrCrpCandidateCondition(nrCrpCandidate))
//         {
//             highestNrCrpCandidates.push_back(&nrCrpCandidate);
//         }
//     }

//     if (highestNrCrpCandidates.empty())
//     {
//         VCCB_PRINT_CALL_IDLE_LB(&call, "[IMLB] highestNrCrpCandidates is empty in %s!!\n", __func__);
//         return nullptr;
//     }

// #ifdef IPC_TEST
//     if (highestNrCrpCandidates.size() == 1)
//         return highestNrCrpCandidates[0];
//     else
//         return highestNrCrpCandidates[1];
// #else

//     auto randSelection = [&highestNrCrpCandidates]()
//     {
//         std::vector<double> weight;
//         for (auto iter : highestNrCrpCandidates)
//         {
//             VALID_E_POINT_CHECK_CONTINUE(iter);
//             weight.push_back(static_cast<double>(iter->ueDistributionRatio));
//         }

//         std::discrete_distribution<> d(weight.begin(), weight.end());

//         std::random_device rd;
//         std::mt19937 gen(rd());

//         return static_cast<uint32_t>(d(gen));
//     };

//     auto highestNrCrpidx = randSelection();
//     if (highestNrCrpidx >= highestNrCrpCandidates.size())
//     {
//         VCCB_PRINT_CALL_IDLE_LB(&call, "[IMLB] invalid highestNrCrpidx(%u/%lu) in %s!!\n", highestNrCrpidx,
//             highestNrCrpCandidates.size(), __func__);
//         return nullptr;
//     }

//     VCCB_PRINT_CALL_IDLE_LB(&call, "[IMLB] [%u] freq:%d is selected as the highest CRP\n",
//         highestNrCrpCandidates[highestNrCrpidx]->measObjIdx, highestNrCrpCandidates[highestNrCrpidx]->frequency);

//     return highestNrCrpCandidates[highestNrCrpidx];
// #endif
// }

// void IdleLBCellReselection::updateNrCrpCandidatePriorityForNonZeroDistRatio(
//     const crpCandidate_type &rhighestNrCrpCandidate, uint8_t &nonZeroCrpMinPriority)
// {
//     AUTO_TRACE_FUNC;
//     for (auto &nrCrpCandidate : nrCrpCandidates)
//     {
//         if (&nrCrpCandidate == &rhighestNrCrpCandidate || nrCrpCandidate.ueDistributionRatio == 0) continue;

//         int updatePriority = getCrpPriority(nrCrpCandidate) - 2;

//         setCrpPriority(updatePriority, nrCrpCandidate);

//         if (updatePriority < nonZeroCrpMinPriority)
//         {
//             nonZeroCrpMinPriority = static_cast<uint8_t>(updatePriority);
//         }
//     }
// }

// void IdleLBCellReselection::updateNrCrpCandidatePriorityForZeroDistRatio(
//     const crpCandidate_type &highestNrCrpCandidate, uint8_t nonZeroCrpMinPriority)
// {
//     AUTO_TRACE_FUNC;

//     for (auto &nrCrpCandidate : nrCrpCandidates)
//     {
//         if (&nrCrpCandidate == &highestNrCrpCandidate || nrCrpCandidate.ueDistributionRatio != 0) continue;

//         int updatePriority = MIN(getCrpPriority(nrCrpCandidate), nonZeroCrpMinPriority - 2);

//         setCrpPriority(updatePriority, nrCrpCandidate);
//     }
// }

// int16_t IdleLBCellReselection::adjustNrCrpCandidates()
// {
//     AUTO_TRACE_FUNC;

//     auto *highestNrCrp = selectHighestNrCrp();
//     VALID_E_POINT_CHECK_ERROR(highestNrCrp);

//     setCrpPriority(78, *highestNrCrp);

//     uint8_t nonZeroNrCrpMinPriority = 0xFF;
//     updateNrCrpCandidatePriorityForNonZeroDistRatio(*highestNrCrp, nonZeroNrCrpMinPriority);
//     updateNrCrpCandidatePriorityForZeroDistRatio(*highestNrCrp, nonZeroNrCrpMinPriority);

//     sort(nrCrpCandidates.begin(), nrCrpCandidates.end(),
//         [](const crpCandidate_type &a, const crpCandidate_type &b) { return getCrpPriority(a) > getCrpPriority(b); });

//     printNrCrpCandidate(__func__);

//     // Although it is different from the HLD content, it was discussed outside the design to exclude the lowest priority
//     // Crp from the candidates.
//     if (nrCrpCandidates.size() == MAX_NUM_FREQ + 1)
//     {
//         VCCB_PRINT_CALL_IDLE_LB(&call, "[IMLB] [%u] is deleted\n", nrCrpCandidates.back().measObjIdx);
//         nrCrpCandidates.pop_back();
//     }

//     return GOOD;
// }

// void IdleLBCellReselection::updateEutraCrpCandidatePriority()
// {
//     AUTO_TRACE_FUNC;

//     uint8_t eutraMaxPriority = 0;
//     for (const auto &eutraCrpCandidate : eutraCrpCandidates)
//     {
//         eutraMaxPriority = std::max(eutraMaxPriority, getCrpPriority(eutraCrpCandidate));
//     }

//     if (nrCrpCandidates.size() != 0 && eutraMaxPriority >= getCrpPriority(nrCrpCandidates.back()))
//     {
//         for (auto &eutraCrpCandidate : eutraCrpCandidates)
//         {
//             uint8_t currenCrptVal = getCrpPriority(eutraCrpCandidate);
//             setCrpPriority(currenCrptVal - 10, eutraCrpCandidate);
//         }
//     }

//     printEutraCrpCandidate(__func__);
// }

// int8_t IdleLBCellReselection::fillNrCrpIE()
// {
//     AUTO_TRACE_FUNC;
//     VALID_E_POINT_CHECK_ERROR(pCell);

//     if (0 != fnGlobalValueAlloc(
//                  (uint8_t **)&this->ie.freqPriorityListNR, sizeof(*this->ie.freqPriorityListNR) * MAX_NUM_SVC_FREQS))
//     {
//         VCCB_PRINT_CALL_IDLE_LB(&call, "ERROR: fnGlobalValueAlloc failed in %s\n", __FUNCTION__);
//         return ERROR;
//     }

//     int8_t numOfNrCrpList = 0;
//     for (const auto &nrCrpCandidate : nrCrpCandidates)
//     {
//         auto &dst = this->ie.freqPriorityListNR[numOfNrCrpList].value;
        
//         dst.bit_mask = 0;
//         dst.carrierFreq = nrCrpCandidate.frequency;
//         dst.cellReselectionPriority = nrCrpCandidate.priority;
//         if (nrCrpCandidate.subpriorityUsage == CI_use)
//         {
//             dst.bit_mask |= NRRRC_FreqPriorityNR_cellReselectionSubPriority_present;
//             dst.cellReselectionSubPriority = (NRRRC_CellReselectionSubPriority)nrCrpCandidate.subpriority;
//         }
//         numOfNrCrpList++;
//     }

//     if (0 < numOfNrCrpList)
//     {
//         if (fnConnectLinkedList(this->ie.freqPriorityListNR, sizeof(*this->ie.freqPriorityListNR), numOfNrCrpList) != 0)
//         {
//             VCCB_PRINT_CALL_IDLE_LB(
//                 &call, "ERROR fnConnectLinkedList(NRRRC_FreqPriorityListNR_) failed in %s\n", __FUNCTION__);
//             return ERROR;
//         }
//         this->ie.bit_mask |= NRRRC_freqPriorityListNR_present;
//         return GOOD;
//     }
//     return ERROR;
// }

// int8_t IdleLBCellReselection::fillEutraCrpIE()
// {
//     AUTO_TRACE_FUNC;
//     VALID_E_POINT_CHECK_ERROR(pCell);

//     int8_t numEutraFreqItems = 0;
//     for (const auto &eutraCrpCandidate : eutraCrpCandidates)
//     {
//         auto &dst = this->ie.freqPriorityListEUTRA[numEutraFreqItems].value;

//         dst.bit_mask = 0;
//         dst.carrierFreq = eutraCrpCandidate.frequency;
//         dst.cellReselectionPriority = eutraCrpCandidate.priority;
//         if (CI_use == eutraCrpCandidate.subpriorityUsage)
//         {
//             dst.bit_mask |= NRRRC_FreqPriorityEUTRA_cellReselectionSubPriority_present;
//             dst.cellReselectionSubPriority = (NRRRC_CellReselectionSubPriority)eutraCrpCandidate.subpriority;
//         }
//         numEutraFreqItems++;
//     }

//     if (0 < numEutraFreqItems)
//     {
//         if (fnConnectLinkedList(
//                 this->ie.freqPriorityListEUTRA, sizeof(*this->ie.freqPriorityListEUTRA), numEutraFreqItems) != 0)
//         {
//             VCCB_PRINT_CALL_ERROR(
//                 &call, "ERROR fnConnectLinkedList(NRRRC_FreqPriorityListEUTRA) failed in %s\n", __FUNCTION__);
//             return ERROR;
//         }
//         this->ie.bit_mask |= NRRRC_freqPriorityListEUTRA_present;
//         return GOOD;
//     }

//     return ERROR;
// }

// int8_t IdleLBCellReselection::Fill_CellReselectionPrioritiesEUTRA(
//     callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
// {
//     AUTO_TRACE_FUNC;
//     UNUSED2(ptCi, ptIE);

//     if (makeEutraCrpCandidates() == ERROR)
//     {
//         VCCB_PRINT_CALL_IDLE_LB(&call, "[IMLB] makeEutraCrpCandidates failed in %s\n", __FUNCTION__);
//         return ERROR;
//     }

//     if (fnGlobalValueAlloc(
//             (uint8_t **)&this->ie.freqPriorityListEUTRA, sizeof(*this->ie.freqPriorityListEUTRA) * MAX_NUM_FREQ) != 0)
//     {
//         VCCB_PRINT_CALL_IDLE_LB(&call, "[IMLB] fnGlobalValueAlloc failed in %s\n", __FUNCTION__);
//         return ERROR;
//     }

//     updateEutraCrpCandidatePriority();

//     if (fillEutraCrpIE() == ERROR)
//     {
//         VCCB_PRINT_CALL_IDLE_LB(&call, "[IMLB] fillEutraCrpIE failed in %s\n", __FUNCTION__);
//         return ERROR;
//     }

//     return GOOD;
// }

// int16_t SliceAwareIMLB::makeNrCrpCandidates()
// {
//     AUTO_TRACE_FUNC;
//     VALID_E_POINT_CHECK_ERROR(_pCellReselect);
//     VALID_E_POINT_CHECK_ERROR(pCell);
//     for (const auto &nrFreqItem : _pCellReselect->nrFreqItems)
//     {
//         if (nrFreqItem.usage != CI_use ||
//             not FnVCCB_IsValid_MeasObj_CellReselection(&call, nrFreqItem.targetMeasObjectEntriesindex))
//             continue;

//         crpCandidate_type nrCrpCandidate;

//         VCCB_CHECK_E_RANGE_AND_CONTINUE(nrFreqItem.targetMeasObjectEntriesindex, MAX_NR_OF_OBJECT_ID_DB);
//         nrCrpCandidate.measObjIdx = nrFreqItem.targetMeasObjectEntriesindex;
//         nrCrpCandidate.frequency =
//             pCell->measurementsData.measurementObjectsNRDb[nrCrpCandidate.measObjIdx].base.ssbFrequency;
//         nrCrpCandidate.priority = nrFreqItem.dedicatedPriority;
//         nrCrpCandidate.subpriorityUsage = nrFreqItem.dedicatedSubpriorityUsage;
//         nrCrpCandidate.subpriority = nrFreqItem.dedicatedSubpriority;
//         nrCrpCandidate.ueDistributionRatio = nrFreqItem.serviceUeDistRatio;

//         nrCrpCandidates.push_back(nrCrpCandidate);

//         if (MAX_NUM_FREQ + 1 <= nrCrpCandidates.size()) break;
//     }

//     printNrCrpCandidate(__func__);

//     return (nrCrpCandidates.size() > 0) ? GOOD : ERROR;
// }

// int8_t SliceAwareIMLB::Fill_CellReselectionPrioritiesNR(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
// {
//     AUTO_TRACE_FUNC;
//     UNUSED2(ptCi, ptIE);

//     if (makeNrCrpCandidates() != GOOD)
//     {
//         VCCB_PRINT_CALL_INFORMATIVE(
//             &call, "ERROR: makeNrCrpCandidates failed in %s\n", __FUNCTION__);
//         return ERROR;
//     }

//     if (adjustNrCrpCandidates() != GOOD)
//     {
//         VCCB_PRINT_CALL_ERROR(&call, "ERROR: adjustNrCrpCandidates failed in %s\n", __FUNCTION__);
//         return ERROR;
//     }

//     if(fillNrCrpIE() != GOOD)
//     {
//         VCCB_PRINT_CALL_ERROR(&call, "ERROR: fillNrCrpIE failed in %s\n", __FUNCTION__);
//         return ERROR;
//     }

//     return GOOD;
// }

// int16_t SliceAwareIMLB::makeEutraCrpCandidates()
// {
//     AUTO_TRACE_FUNC;
    
//     VALID_E_POINT_CHECK_ERROR(pCell);
//     VALID_E_POINT_CHECK_ERROR(_pCellReselect);
//     for (int itemIndex = 0; itemIndex < MAX_NUM_SVC_FREQS; itemIndex++)
//     {
//         const auto &eutraFreqItem = _pCellReselect->eutraFreqItems[itemIndex];
//         if (CI_use != eutraFreqItem.usage)
//         {
//             continue;
//         }

//         VCCB_CHECK_E_RANGE_AND_RETURN(eutraFreqItem.targetMeasObjectEutraEntriesindex, MAX_NR_OF_OBJECTEUTRA_ID_DB);
//         const auto &measObj =
//             pCell->measurementsData.measurementObjectsEUTRADb[eutraFreqItem.targetMeasObjectEutraEntriesindex].base;
//         if (CI_use != measObj.usage) continue;

//         uint32_t carrierFreq = 0;
//         if (BAND_NOT_FOUND == VCCB_GetMoEutraBandForUe(&call, &measObj, &carrierFreq))
//         {
//             // not supported by UE
//             continue;
//         }

//         crpCandidate_type eutraCrpCandidate;

//         eutraCrpCandidate.measObjIdx = eutraFreqItem.targetMeasObjectEutraEntriesindex;
//         eutraCrpCandidate.frequency =
//             pCell->measurementsData.measurementObjectsEUTRADb[eutraFreqItem.targetMeasObjectEutraEntriesindex]
//                 .base.carrierFreq;
//         eutraCrpCandidate.priority = eutraFreqItem.dedicatedPriority;
//         eutraCrpCandidate.subpriorityUsage = eutraFreqItem.dedicatedSubpriorityUsage;
//         eutraCrpCandidate.subpriority = eutraFreqItem.dedicatedSubpriority;

//         if (MAX_NUM_FREQ <= eutraCrpCandidates.size()) break;
//         eutraCrpCandidates.push_back(eutraCrpCandidate);
//     }

//     printEutraCrpCandidate(__func__);

//     if (0 == eutraCrpCandidates.size())
//     {
//         return ERROR;
//     }

//     return GOOD;
// }

// int8_t SliceAwareIMLB::getServiceGroupCrpInfo()
// {
//     AUTO_TRACE_FUNC;

//     if (GOOD != FnVCCB_GetServiceGroupIdByServedPlmn(0xFF, &call, &_pCellReselect))
//     {
//         VCCB_PRINT_CALL_MSG(&call, "[%s]FnVCCB_GetServiceGroupIdByServedPlmn error\n", __FUNCTION__);
//         return BREAK;
//     }

//     VALID_E_POINT_CHECK_ERROR(_pCellReselect);
//     VCCB_CHECK_E_RANGE_AND_RETURN(_pCellReselect->svcGroupId, MAX_SVC_GRP_DB_NUM);
//     VALID_E_POINT_CHECK_ERROR(pGnb);
//     if (!pGnb->cfg.svcGrpBasedCfg[_pCellReselect->svcGroupId].svcBasedIdleLbAllowed)
//     {
//         VCCB_PRINT_CALL_MSG(&call, "[%s]Service Group not allowed by gnb YANG\n", __FUNCTION__);
//         return BREAK;
//     }

//     return GOOD;
// }

// int8_t SliceAwareIMLB::Fill_CellReselectionInfo(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
// {
//     AUTO_TRACE_FUNC;
//     VALID_E_POINT_CHECK_ERROR(pCell);
//     UNUSED2(ptCi, ptIE);

//     this->ie.bit_mask = 0;

//     if(GOOD != getServiceGroupCrpInfo())
//     {
//         VCCB_PRINT_CALL_ERROR(&call, "SliceAwareIMLB::getServiceGroupCrpInfo ERROR!!\n");
//         return BREAK;
//     }

//     if (ERROR == Fill_CellReselectionPrioritiesNR(&call, &ie))
//     {
//         VCCB_PRINT_CALL_ERROR(&call, "SliceAwareIMLB::Fill_CellReselectionPrioritiesNR ERROR!!\n");
//         return BREAK;
//     }

//     if (ERROR == Fill_CellReselectionPrioritiesEUTRA(&call, &ie))
//     {
//         VCCB_PRINT_CALL_ERROR(&call, "SliceAwareIMLB::Fill_CellReselectionPrioritiesEUTRA ERROR!!\n");
//     }

//     Fill_T320(&ie, static_cast<NRRRC__enum228>(pCell->cellRfspBasedCtrl.t320));

//     return GOOD;
// }

// string IMLB::getOperModeString()
// {
//     switch (operMode)
//     {
//         case non_plmn_based:
//             return "non plmn based";
//         case plmn_based:
//             return "plmn based";
//         case auto_mode_based:
//             return "auto mode based";
//         case ca_profile_based:
//             return "ca profile based";
//         case red_cap_ue:
//             return "red cap ue";
//         default:
//             return "invalid val";
//     }
// }

// IMLB::operModeType IMLB::getLegacyOperMode()
// {
//     VALID_E_POINT_CHECK_RET_VAL(pCell, non_plmn_based);
//     if (pCell->lbCfg.idleModeLbInfo.autoModeFlag == access_s5gtype_idle_lb_auto_mode)
//     {
//         return auto_mode_based;
//     }
//     else if (pCell->lbCfg.idleModeLbInfo.plmnModeFlag)
//     {
//         return plmn_based;
//     }
//     else
//     {
//         return non_plmn_based;
//     }
// }

// bool IMLB::isNrMoAllowedForUePlmn(uint8_t measObjIndex)
// {
//     AUTO_TRACE_FUNC;
//     VALID_E_POINT_CHECK_ERROR(pCell);
//     VCCB_CHECK_E_RANGE_AND_VAL(measObjIndex, MAX_NR_OF_OBJECT_ID_DB, false);
//     const auto &measObjControl =
//         pCell->measurementsData.measurementObjectsNRDb[measObjIndex].extension;

//     if (this->callPlmnIndex >= MAX_PLMN_INDEX)
//     {
//         if (IS_NOT_ALLOWED_PLMN_BASED_CONTROL(&measObjControl))
//         {
//             return false;
//         }
//     }
//     else
//     {
//         if (IS_NOT_ALLOWED_PLMN_SUPPORT(&measObjControl, this->callPlmnIndex))
//         {
//             return false;
//         }
//     }

//     return true;
// }

// int16_t IMLB::checkAutoModeCondition()
// {
//     AUTO_TRACE_FUNC;
//     VALID_E_POINT_CHECK_ERROR(pCell);
//     VALID_E_POINT_CHECK_ERROR(pGnb);

//     auto lastUpdateDuration = VLIB_getTickDifference(pCell->lbCfg.idleModeLbInfo.sonInfo.lastUpdatedTime) / 1000;
//     auto allowedSonDuration = pGnb->idleMobilityControl.periodForUeDistRatio * 60 * 2;
//     if (lastUpdateDuration > static_cast<long>(allowedSonDuration))
//     {
//         VCCB_PRINT_CALL_IDLE_LB(
//             &call, "[IMLB] Idle LB Info is Expired(%ld/%u)\n", lastUpdateDuration, allowedSonDuration);
//         return ERROR;
//     }

//     auto currUeNum = 100 - pCell->cellRscInfo.numAvailUe;
//     if (currUeNum <= pCell->lbCfg.idleModeLbInfo.ueNumThresholdForAutoMode)
//     {
//         VCCB_PRINT_CALL_IDLE_LB(&call, "[IMLB] currUeNum(%u) <= ueNumThreshold(%u)\n", currUeNum,
//             pCell->lbCfg.idleModeLbInfo.ueNumThresholdForAutoMode);
//         return ERROR;
//     }

//     return GOOD;
// }

// int16_t IMLB::checkPreCondition()
// {
//     switch (getOperMode())
//     {
//         case ca_profile_based:
//         {
//             VCCB_CHECK_E_RANGE_AND_RETURN(call.caProfileIdx, MAX_CA_PROFILE_NUM);
//             break;
//         }
//         case auto_mode_based:
//         {
//             return checkAutoModeCondition();
//         }
//         case plmn_based:
//         {
//             this->callPlmnIndex = VLIB_FindGnbPlmnIndexOfCall(&call);
//             VCCB_CHECK_E_RANGE_AND_RETURN(this->callPlmnIndex, MAX_PLMN_INDEX);
//             break;
//         }
//         default:
//             break;
//     }
//     return GOOD;
// }

// uint16_t IMLB::getUeNrCrpDistRatio(nrCellReselectInfo_type &nrCrp)
// {
//     switch (getOperMode())
//     {
//         case red_cap_ue:
//         {
//             return nrCrp.ueDistributionRatioForRedCapUE;
//         }
//         case ca_profile_based:
//         {
//             VCCB_CHECK_E_RANGE_AND_VAL(call.caProfileIdx, MAX_CA_PROFILE_NUM, INVALID_PRIORITY);
//             return nrCrp.ueDistributionRatioForCaProfileMode[call.caProfileIdx];
//         }
//         case auto_mode_based:
//         {
//             VCCB_CHECK_E_RANGE_AND_VAL(nrCrp.measObjIdx, MAX_MEAS_OBJECT_ENTRIES + 1, INVALID_PRIORITY);
//             return static_cast<uint16_t>(nrCrp.weightFactorForAutoMode *
//                    this->idleModeLbInfo.sonInfo.measObjUeDistRatio[nrCrp.measObjIdx].ueDistRatio);
//         }
//         case plmn_based:
//         {
//             VCCB_CHECK_E_RANGE_AND_VAL(this->callPlmnIndex, MAX_PLMN_INDEX, INVALID_PRIORITY);
//             return nrCrp.ueDistributionRatioForPlmnMode[this->callPlmnIndex];
//         }
//         case non_plmn_based:
//         default:
//         {
//             return nrCrp.ueDistributionRatioForNonPlmnMode;
//         }
//     }
// }

// int16_t IMLB::makeNrCrpCandidates()
// {
//     AUTO_TRACE_FUNC;
//     VALID_E_POINT_CHECK_ERROR(pCell);

//     nrCrpCandidates.clear();

//     for (auto &nrFreqItem : this->idleModeLbInfo.nrFreqItem)
//     {
//         if (nrFreqItem.usage != CI_use ||
//             not isNrMoAllowedForUePlmn(nrFreqItem.measObjIdx) ||
//             not FnVCCB_IsValid_MeasObj_CellReselection(&call, nrFreqItem.measObjIdx))
//             continue;

//         crpCandidate_type nrCrpCandidate;

//         VCCB_CHECK_E_RANGE_AND_CONTINUE(nrFreqItem.measObjIdx, MAX_NR_OF_OBJECT_ID_DB);
//         nrCrpCandidate.measObjIdx = nrFreqItem.measObjIdx;
//         nrCrpCandidate.frequency =
//             pCell->measurementsData.measurementObjectsNRDb[nrFreqItem.measObjIdx].base.ssbFrequency;
//         nrCrpCandidate.priority = nrFreqItem.priority;
//         nrCrpCandidate.subpriorityUsage = nrFreqItem.subpriorityUsage;
//         nrCrpCandidate.subpriority = nrFreqItem.subpriority;
//         nrCrpCandidate.ueDistributionRatio = getUeNrCrpDistRatio(nrFreqItem);
//         if (nrCrpCandidate.ueDistributionRatio == INVALID_PRIORITY) continue;

//         nrCrpCandidates.push_back(nrCrpCandidate);
//     }

//     printNrCrpCandidate(__func__);

//     return (nrCrpCandidates.size() > 0) ? GOOD : ERROR;
// }

// // void IMLB::FnVCCB_frequencySelectionCnt(nrCellReselectInfo_type &highestPriorityFreq)
// // {
// //     AUTO_TRACE_FUNC;
// //     VCCB_CHECK_E_RANGE_AND_VOID(call.myThreadId, MAX_CALL_THREAD_NUM_VCCB);

// //     if (UINT16_MAX == highestPriorityFreq.nrFreqSelectCnt[call.myThreadId])

// //     {
// //         highestPriorityFreq.nrFreqSelectCnt[call.myThreadId] = 0;
// //     }
// //     highestPriorityFreq.nrFreqSelectCnt[call.myThreadId]++;
// // }

// void IMLB::collectStatistic()
// {
//     auto &highestPriorityFreq = nrCrpCandidates.front();
//     // FnVCCB_frequencySelectionCnt(highestPriorityFreq);

//     MACRO_STAT_PMCC(STAT_INTRA_NR_IDLE_LB, UE_Count_IntraNrIdle, &call, highestPriorityFreq.frequency, 0, 0, 0, 0);
//     if (IS_REDCAP_UE(&call))
//     {
//         MACRO_STAT_PMCC(
//             STAT_INTRA_NR_IDLE_LB, UE_Count_RedCap_IntraNrIdle, &call, highestPriorityFreq.frequency, 0, 0, 0, 0);
//     }
// }

// int8_t IMLB::Fill_CellReselectionPrioritiesNR(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
// {
//     AUTO_TRACE_FUNC;
//     UNUSED2(ptCi, ptIE);

//     VCCB_PRINT_CALL_IDLE_LB(&call, "[IMLB] mode : %s\n", getOperModeString().c_str());

//     if (checkPreCondition() != GOOD)
//     {
//         VCCB_PRINT_CALL_IDLE_LB(&call, "[IMLB] checkPreCondition failed in %s\n", __FUNCTION__);
//         return ERROR;
//     }

//     if (makeNrCrpCandidates() != GOOD)
//     {
//         VCCB_PRINT_CALL_IDLE_LB(&call, "[IMLB] makeNrCrpCandidates failed in %s\n", __FUNCTION__);
//         return ERROR;
//     }

//     if (adjustNrCrpCandidates() != GOOD)
//     {
//         VCCB_PRINT_CALL_IDLE_LB(&call, "[IMLB] adjustNrCrpCandidates failed in %s\n", __FUNCTION__);
//         return ERROR;
//     }

//     if(fillNrCrpIE() == ERROR)
//     {
//         VCCB_PRINT_CALL_IDLE_LB(&call, "[IMLB] fillNrCrpIE failed in %s\n", __FUNCTION__);
//         return ERROR;
//     }

//     collectStatistic();

//     return GOOD;
// }

// int16_t IMLB::makeEutraCrpCandidates()
// {
//     AUTO_TRACE_FUNC;

//     VALID_E_POINT_CHECK_ERROR(pCell);

//     for (int itemIndex = 0; itemIndex < MAX_NUM_FREQ; itemIndex++)
//     {
//         const auto &eutraFreqItem = pCell->eutraCellReselect[itemIndex];

//         if (CI_no_use == eutraFreqItem.usage) continue;
//         VCCB_CHECK_E_RANGE_AND_RETURN(eutraFreqItem.measObjIdx, MAX_NR_OF_OBJECTEUTRA_ID_DB);
//         const auto &measDb = pCell->measurementsData.measurementObjectsEUTRADb[eutraFreqItem.measObjIdx];
//         uint32_t carrierFreq = 0;
//         if (BAND_NOT_FOUND == VCCB_GetMoEutraBandForUe(&call, &measDb.base, &carrierFreq))
//         {
//             // not supported by UE
//             continue;
//         }

//         if (IS_NOT_ALLOWED_PLMN_SUPPORT(&measDb.extension, this->callPlmnIndex))
//         {
//             VCCB_PRINT_CALL_COMMENT(
//                 &call, "[IMLB] measObjId(%u) is not-allowed-plmn in %s\n", eutraFreqItem.measObjIdx, __FUNCTION__);
//             continue;
//         }

//         crpCandidate_type eutraCrpCandidate;
//         eutraCrpCandidate.measObjIdx = eutraFreqItem.measObjIdx;
//         eutraCrpCandidate.frequency = measDb.base.carrierFreq;
//         eutraCrpCandidate.priority = eutraFreqItem.priority;
//         eutraCrpCandidate.subpriorityUsage = eutraFreqItem.subpriorityUsage;
//         eutraCrpCandidate.subpriority = eutraFreqItem.subpriority;

//         eutraCrpCandidates.push_back(eutraCrpCandidate);
//     }

//     printEutraCrpCandidate(__func__);

//     if (0 == eutraCrpCandidates.size())
//     {
//         return ERROR;
//     }
//     return GOOD;
// }

// void IMLB::setIdleLBParameterForLBMCellConfig(
//     cellLbmConfiguration_type::idleLbInfoLbm_s::idleLbInfoLbmConfig_s const &rLbmCellConfig)
// {
//     AUTO_TRACE_FUNC;
//     this->idleModeLbInfo.usage = rLbmCellConfig.usage;
//     this->idleModeLbInfo.legacyModeFlag = rLbmCellConfig.legacyModeFlag;
//     this->idleModeLbInfo.ueNumThresholdForAutoMode = rLbmCellConfig.ueNumThresholdForAutoMode;
// }

// void IMLB::setIdleLBParameterForLBMParameterSet(
//     cellLbmConfiguration_type::idleLbInfoLbm_s::idleLbInfoLbmParameterSet_s const (
//         &rLbmParameterSet)[MAX_NR_LBM_CONFIG_ENTRIES - 1],
//     enumNrLbmConfigurationIndex_type lbmConfigIndex)
// {
//     AUTO_TRACE_FUNC;
//     auto setNrFreqDistratio = [](nrCellReselectInfo_type &dest, const idleModeLbLbmParameterNrFreqDistRatio_type &src)
//     {
//         dest.ueDistributionRatioForNonPlmnMode = src.ueDistributionRatioForNonPlmnMode;
//         dest.ueDistributionRatioForPlmnMode[0] = src.ueDistributionRatioForPlmnMode[0];
//         dest.ueDistributionRatioForPlmnMode[1] = src.ueDistributionRatioForPlmnMode[1];
//         dest.weightFactorForAutoMode = src.weightFactorForAutoMode;
//     };

//     uint8_t const INTRA_FREQ_INDEX = 0;
//     int const lbmParameterSetIndex = lbmConfigIndex - 1;  // -1 is because it does not include NR_LBM_DISABLE
//     if(lbmParameterSetIndex < 0 || lbmParameterSetIndex >= MAX_NR_LBM_CONFIG_ENTRIES - 1)
//     {
//         VCCB_PRINT_ERROR("lbmParameterSetIndex is out of range(%d)\n", lbmParameterSetIndex);
//         return;
//     }
//     auto &lbmParameterSetForIdleLB = rLbmParameterSet[lbmParameterSetIndex];
//     if(lbmParameterSetForIdleLB.usage != CI_use) return;

//     setNrFreqDistratio(this->idleModeLbInfo.nrFreqItem[INTRA_FREQ_INDEX], lbmParameterSetForIdleLB.intraFreq);

//     for (int interFreqIndex = 0; interFreqIndex < MAX_NUM_FREQ; interFreqIndex++)
//     {
//         if(lbmParameterSetForIdleLB.interFreq[interFreqIndex].usage != CI_use) continue;
//         setNrFreqDistratio(
//             this->idleModeLbInfo.nrFreqItem[interFreqIndex + 1], lbmParameterSetForIdleLB.interFreq[interFreqIndex]);
//     }
// }

// void IMLB::setIdleLBParameterForLBM()
// {
//     AUTO_TRACE_FUNC;
//     VALID_E_POINT_CHECK_VOID(pCell);
//     memcpy(&this->idleModeLbInfo, &pCell->lbCfg.idleModeLbInfo, sizeof(idleModeLBInfo_type));

//     auto lbmConfigIndex = pCell->nrLbmConfigurationIndex;
//     bool isLbmEnabled = lbmConfigIndex != NR_LBM_DISABLE;
//     if (isLbmEnabled)
//     {
//         cellLbmConfiguration_type::idleLbInfoLbm_s const &rLbmIdleLbInfo = pCell->lbCfg.lbmConfiguration.idleLbInfo;
//         setIdleLBParameterForLBMCellConfig(rLbmIdleLbInfo.cellConfig);
//         setIdleLBParameterForLBMParameterSet(rLbmIdleLbInfo.parameterSet, lbmConfigIndex);
//         return;
//     }
//     else
//     {
//         return;
//     }
// }

// int8_t IMLB::Fill_CellReselectionInfo(callInfo_type *ptCi, NRRRC_CellReselectionPriorities *ptIE)
// {
//     AUTO_TRACE_FUNC;
//     UNUSED2(ptCi, ptIE);
//     VALID_E_POINT_CHECK_ERROR(pCell);

//     this->ie.bit_mask = 0;

//     setIdleLBParameterForLBM();

//     if (IS_REDCAP_UE(&call) && isRedCapUeDistRatioConfigured(this->idleModeLbInfo))
//     {
//         setOperMode(red_cap_ue);
//         if (Fill_CellReselectionPrioritiesNR(&call, &ie) != GOOD)
//         {
//             VCCB_PRINT_CALL_IDLE_LB(&call, "redcap IMLB::Fill_CellReselectionPrioritiesNR Failed!!\n");
//             return ERROR;
//         }
//     }
//     else
//     {
//         do
//         {
//             if (VCCB_CA_PROFILE_SUPPORT(&call))
//             {
//                 setOperMode(ca_profile_based);
//                 if (Fill_CellReselectionPrioritiesNR(&call, &ie) == GOOD) break;
//                 VCCB_PRINT_CALL_IDLE_LB(&call, "ca_profile_based IMLB::Fill_CellReselectionPrioritiesNR Failed!!\n");
//             }

//             if (pCell->lbCfg.idleModeLbInfo.legacyModeFlag)
//             {
//                 setOperMode(getLegacyOperMode());
//                 if (Fill_CellReselectionPrioritiesNR(&call, &ie) == GOOD) break;
//                 VCCB_PRINT_CALL_IDLE_LB(&call, "legacy IMLB::Fill_CellReselectionPrioritiesNR Failed!!\n");
//             }

//             // If NR CRP is not configured, EUTRA CRP shall not be configured either.
//             return ERROR;
//         } while (0);
//     }

//     if (ERROR == Fill_CellReselectionPrioritiesEUTRA(&call, &ie))
//     {
//         VCCB_PRINT_CALL_IDLE_LB(&call, "IMLB::Fill_CellReselectionPrioritiesEUTRA ERROR!!\n");
//     }

//     Fill_T320(&ie, static_cast<NRRRC__enum228>(pCell->cellRfspBasedCtrl.t320));

//     return GOOD;
// }
