/**
 * @file        FeatCa.hpp
 * @brief       Utility functions for Carrier Aggregation
 */

#ifndef VCCB_FEAT_FeatCa_HPP_
#define VCCB_FEAT_FeatCa_HPP_

#include "ComInclude.min.h"
#include "ComContainers.hpp"
#include "FeatMcoStruct.hpp"

using bcIdxArray_type = simpleVector<uint32_t, MAX_BAND_COMBS>;
using scellList_type = scellInfo_type[MAX_SCELL_PER_CALL];

typedef std::multiset<std::pair<uint8_t, uint8_t>> bwcMultiSet_type;   // enum NrCaBandwidthClassDL, NrCaBandwidthClassUL
typedef std::map<uint16_t, bwcMultiSet_type> band2bwcMultisetMap_type;  // key: frequencyBand, value: bwcMultiSet_type
struct allowedFilteredBc_s
{
    allowedFilteredBc_s() : allowedBcIdx(0), bestBwDl(0), isIncludedAllScell(false) {}
    uint16_t        allowedBcIdx;     //index of allowedBC_ListMRDC.bandCombinationInfo[]
    uint32_t        bestBwDl;
    bool            isIncludedAllScell;
};
typedef std::map<band2bwcMultisetMap_type, allowedFilteredBc_s> allowedFilteredBcMap_type; // Filtered allowedBc_List
typedef std::vector<std::pair<uint16_t, uint32_t>> totalBwPerBc_type; // first: bcIdx, second: totalBw

uint16_t VLIB_GetAlternativeNrBand(callInfo_type *ptCi, const nbrGnbCellInfo_type *ptTgtNbrGnbCell, const uint16_t scellIdx, const uint8_t scellAltBandIdx);
void VLIB_FillNewScellInfo(callInfo_type *ptCi, scellInfo_type *ptScellInfo, cgi_type cgi, uint8_t gnbIdLength);
void VLIB_FillNewScellInfo(callInfo_type &rCall, scellInfo_type &rScellInfo, const cgi_type cgi, const uint8_t gnbIdLength, const uint16_t bandNr);
int16_t VLIB_IsCellEligibleForCA(callInfo_type *ptCi, const caCellInfo_type *ptPCell,
    const caCellInfo_type *ptSCell, const bcIdxArray_type & filteredBcIndexes);
int16_t VLIB_VerifyIfCellEligibleForCaWithSCellCandidate(callInfo_type *ptCi, nbrGnbCellInfo_type *ptNbrInfo,
    const bcIdxArray_type &filteredBcIndexes, caCellInfo_type *ptSCellCandidate);

int16_t VLIB_getBcIndexesUsingPrioBasedScellSelectCom(callInfo_type *ptCi, const uint16_t spCellNum,
    const uint16_t frequencyBand, bcIdxArray_type &filteredBcIndexes, const bandCombinationList_type *pBandCombinationList);
int16_t VLIB_getBcIndexesUsingPrioBasedScellSelect(callInfo_type *ptCi, const uint16_t spCellNum,
    const uint16_t frequencyBand, bcIdxArray_type &filteredBcIndexes);

template <typename CellInfoInT, typename CellInfoOutT>
void FnVCCB_McoFillBandwidth(const CellInfoInT &rCellInfoIn, CellInfoOutT &rCellInfoOut);
template <typename CellInfoT, typename IntegerType>
void FnVCCB_McoFillBandwidthByDuplex(uint16_t duplexMode, IntegerType &rMcoBwDl, IntegerType &rMcoBwUl, const CellInfoT &rCell);
void FnVCCB_McoPrepareColocContiguousNrCellGroups(callInfo_type *ptCi, uint16_t spCellNum, McoAlgoFlags &algoFlags,
    mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBandOut, uint16_t &rPCellBandOut);
void FnVCCB_McoPrepareNrCellGroupsForFinalFmPcc(callInfo_type *ptCi, uint16_t spCellNum, McoAlgoFlags &algoFlags,
    mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBandOut, uint16_t &rPCellBandOut);
uint16_t FnVCCB_McoMakeNrdcPscellCandidateList(callInfo_type *ptCi, hoRestrictInfo_type *ptHrl, const uint16_t spCellNum,
    mcoPscellCcInfo_s ccInfoTabOut[MAX_PCC_PSCELL_BANDS]);
uint16_t FnVCCB_McoMakeNrdcPscellCandidateListForRecalculation(
        callInfo_type *ptCi, hoRestrictInfo_type *ptHrl, const PccCandidateInfo_type * const ptCandidate,
        const uint16_t spCellNum, mcoPscellCcInfo_s ccInfoTabOut[MAX_PCC_PSCELL_BANDS]);
void FnVCCB_McoPrepareMcgContiguousEutraCellGroups(
    callInfo_type *ptCi, mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBandOut, uint16_t &rPCellBandOut);
void FnVCCB_McoPrepareContiguousNrCellGroupsForScc(
    callInfo_type *ptCi, const bool mfbiCheckFlag, mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBandOut);
void FnVCCB_McoPrepareContiguousNrCellGroupsForMaxBW(
    callInfo_type *ptCi, const bool mfbiCheckFlag, mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBandOut,
    const cellSelection_type &rCellSelection, const bandCombinationList_type &rUeSupBandCombList);
void FnVCCB_McoPrepareCurrentScellContiguousNrCellGroups(
    callInfo_type *ptCi, mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBandOut, uint16_t &rPCellBandOut);
int16_t VLIB_IsCarrierEligibleForCA(callInfo_type *ptCi, const caCellInfo_type *ptPCell, const caCellInfo_type *ptSCell,
    const bcIdxArray_type &filteredBcIndexes);
uint8_t VLIB_DecideAboutCaOperatingMode(callInfo_type *ptCi, VccbCellInfo_type *pCell, uint16_t spCellFrequencyBand);
double FnVCCB_GetTsmValueSE(callInfo_type *ptCi, uint16_t cellNum, uint8_t rsrp);
#ifdef NEW_HOST_SIM
double FnVCCB_GetTsmValueSEMock(const callInfo_type &rCall, const CellNum_type cellNum, uint8_t rsrp);
#endif
int16_t VLIB_FillCaCellInfoForMco(callInfo_type *ptCi, const uint16_t spCellNum, const cgi_type &cgi,
    const uint8_t gnbIdLength, const bool noPrbUsage, caCellInfo_type &rCellInfoOut);
bool FnVCCB_McoFillBcSelSCellInfoByNbr(callInfo_type *ptCi, const uint16_t spCellNum, const mcoBcSelCellInfo_s &pcell,
    const bcIdxArray_type &filteredBcIndexes, const nbrCellInfo_type *const ptCellNbr,
    const nbrGnbCellInfo_type *const ptNbrGnbInfo, McoAlgoFlags &algoFlags, const uint8_t rsrp,
    mcoBcSelCellInfo_s &rScellOut);
bool FnVCCB_McoFillBcSelSCellInfoByCgi(callInfo_type *ptCi, const uint16_t spCellNum, const mcoBcSelCellInfo_s &pcell,
    const bcIdxArray_type &filteredBcIndexes, const cgi_type &cgi, const uint8_t gnbIdLength, McoAlgoFlags &algoFlags,
    const uint8_t rsrp, mcoBcSelCellInfo_s &rScellOut);

void FnVCCB_CalculateTotalMaxBwForCa(callInfo_type *ptCi);
bool FnVCCB_CheckSkipCaA4MrWithMaxBw(callInfo_type *ptCi);
bool VLIB_IsHighPowerClassSelected(callInfo_type &rCi);
enumUeAllPowerClass_type VLIB_GetSelectedPowerClass(callInfo_type &rCi);

uint32_t VLIB_GetNominalChannelSpacingCa(const uint16_t band, const uint32_t bwMhz1, const uint32_t bwMhz2);

int VLIB_InitOMFailedScellsMutex(pthread_mutexattr_t *pAttr);
bool VLIB_IsCaColocCellStatusAbnormal(colocCellEntries_type *pColocCell);
uint8_t VLIB_DecideComponentCarriersLimit(callInfo_type *ptCi);
void VLIB_DecideAboutScellToRelease(callInfo_type *ptCi);
int16_t VLIB_IsCcLimitExceeded(callInfo_type *ptCi, bool isInitialCheck);

void VLIB_ReconfigureScellsIfVoNRReleased(callInfo_type *ptCi);
void VLIB_ConfigSecondaryCellList(callInfo_type *ptCi);
void VLIB_CommitSecondaryCellList(callInfo_type *ptCi, uint8_t succes);
int16_t VLIB_FillInfoForScellChange(
    callInfo_type *ptCi, const nbrGnbCellInfo_type *ptTgtNbrGnbCell, uint8_t sourceScellIdx, const uint16_t frequencyBand, const uint8_t rsrp);
int16_t VLIB_FillInfoForScellAddition(
    callInfo_type *ptCi, const nbrGnbCellInfo_type *ptTgtNbrGnbCell, uint8_t oldScellIdx, const uint16_t frequencyBand, const uint8_t rsrp);
int16_t VLIB_FillInfoForScellDuringSccGathering(callInfo_type *ptCi, const nbrGnbCellInfo_type *ptTgtNbrGnbCell,
    const measResultList2NR_type *ptMeasResults, const measurementObjectUe_type *pMeasObj,
    const reportConfigurationInstalledUe_type *pReportConfig);
void VLIB_SetScellColocStateToNormal(callInfo_type *ptCi, cgi_type sCellCgi);
int VLIB_McoLbSelectBestSpcell(callInfo_type *ptCi, const candidateCellListForSort_type *pListForSort);
int VLIB_McoLbSelectBestSpcell2(callInfo_type *ptCi, const candidateCellListForSort_type *pListForSort);
void VLIB_AssignScellIndexes(callInfo_type *ptCi);
void VLIB_RollbackCa(callInfo_type *ptCi);
void VLIB_SaveScells(callInfo_type *ptCi);
bool FnVCCB_CaControlCheckIfUeAndGnbShareAnySlice(const callInfo_type &rCall, const nrCaControlCondition_type &rCondition);
bool FnVCCB_CaControlCheckIfUeSupportPlmnOfGnb(const callInfo_type &rCall, const nrCaControlCondition_type &rCondition);
bool FnVCCB_IsNeedToCheckAllowedBand(const callInfo_type &rCall);
int16_t FnVCCB_CheckIfBandInAllowedBandList(const callInfo_type &rCall, const uint16_t scellBandNR);
bool FnVCCB_IsChangedAllowedBand(const callInfo_type &rCall, const VccbGnbInfo_type &rGnb, const uint8_t oldCaControlIdx, const uint8_t newCaControlIdx);
bool VLIB_CheckCellInService_Ca(callInfo_type *ptCi, uint16_t cellNum, bool skipMibBarredCheck);

scellList_type &FnVCCB_GetScellInfoList(callInfo_type &rCall);
const scellList_type &FnVCCB_GetConstScellInfoList(const callInfo_type &rCall);

bool VLIB_IsAllowedBcFilterMnBcRequired(callInfo_type &rCi);
void VLIB_makeFilteredAllowedBcList(callInfo_type *ptCi, allowedFilteredBcMap_type &bcMap);
uint8_t VRIL_getNumContiguousCcForBandClass(uint16_t bandNr, NrCaBandwidthClass bandClass);
bool FnVCCB_IsDrbAvailableForCA(callInfo_type *ptCi);
bool FnVCCB_IsScellExist(callInfo_type &rCi);
void FnVCCB_SetReleaseCaA4ForVoNROn(callInfo_type *ptCi);
bool FnVCCB_NeedToSendForSeValue(callInfo_type *ptCi);
uint32_t FnVCCB_GetSeValueInMrCellInfo(callInfo_type *ptCi, const cgi_type cgi);
void FnVCCB_ExcludeScellNotInFmPcc(callInfo_type *ptCi);
void FnVCCB_ClearScellsAfterLtmCellSwitch(callInfo_type &rCi);
duSelectionRelatedData_type &VLIB_GetDuSelectionRelatedData(callInfo_type &rCi);
bool FnVCCM_AnySCellIsDuringAdditionAfterA4(callInfo_type *ptCi);

#endif  // VCCB_FEAT_FeatCa_HPP_
