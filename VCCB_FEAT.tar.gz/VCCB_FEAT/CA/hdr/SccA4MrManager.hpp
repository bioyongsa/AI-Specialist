
#ifndef SCCA4MRMANAGER_HPP
#define SCCA4MRMANAGER_HPP

#include "VccbStruct.h"

class SccA4MrManager
{
private:
    cgi_type mTgtCgi;
    callInfo_type &mCallInfo;
    const nbrGnbCellInfo_type &mTgtNbrGnbCell;
    const measResultList2NR_type &mMeasResults;
    const measurementObjectUe_type &mMeasObj;
    const reportConfigurationInstalledUe_type &mReportConfig;

    uint16_t findScellIdxForSsbFrequencyOfReceivedMr();
    void changeOnlySccCellMeasured(uint16_t scellIdx);
    void changeToNewSccCell(uint16_t scellIdx);
    bool checkNotChangeScellInfo(uint16_t scellIdx);
    void updateSccInfo(uint16_t scellIdx);
    void changeSccState(scellInfo_type &scell);
    bool isGatheringState();

public :
    SccA4MrManager(callInfo_type &, const nbrGnbCellInfo_type &, const measResultList2NR_type &,
        const measurementObjectUe_type &, const reportConfigurationInstalledUe_type &);
    bool checkTriggerSccChange();
    int16_t sCellInfoUpdate();
};

#endif // SCCA4MRMANAGER_HPP