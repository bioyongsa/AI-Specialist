/**
 * @file        FeatMco.hpp
 * @brief       Functions for Multi Carrier Operations feature
 */

#ifndef VCCB_FEAT_HDR_FEATMCO_HPP_
#define VCCB_FEAT_HDR_FEATMCO_HPP_

#include "ComInclude.h"
#include "FeatMcoStruct.hpp"
#include "VccbTypes.h"
#include "FeatMfbi.h"

int16_t FnVCCB_McoSendSamsungBcInfoResponse(callInfo_type *ptCi);
bool FnVCCB_McoCheckIfPrivateMessageShouldBeDiscarded(const X2_PrivateMessage_type &msg);
bool FnVCCB_McoCheckIfAcceptMessage(callInfo_type *ptCi);
int16_t FnVCCB_McoSendBcInfoRespReject(callInfo_type *ptCi);
bool FnVCCB_McoCheckIfBcInfoReqStoreIsValid();
int16_t FnVCCB_McoGetEffectiveBwForPccChange(callInfo_type *ptCi, hoRestrictInfo_type *ptHrl,
        const EffectiveBwForPccFlags &flags, const McoAlgoFlags &algoFlags, const uint16_t cellNum,
        const uint16_t pcellBand, mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBand, PccCandidateResultList_type &resultListOut,
        McoFmPccArfcnList_type &chosenArfcnsOut, const PccCandidateInfo_type * const ptCandidate);
int16_t FnVCCB_McoGetCcInfoVecPerBandForPcc(callInfo_type &rCall, const CellNum_type cellNum,
        uint16_t &pcellBandInOut, const EffectiveBwForPccFlags &flags, McoAlgoFlags &algoFlagsInOut,
        mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBandInOut);
uint8_t FnVCCB_McoGetDlMimoLayerForBestBcSelection(callInfo_type *ptCi, uint32_t bcIndex, uint16_t bandNr,
    uint16_t fsPerBandIdx);
int16_t FnVCCB_McoSelectScellsForMaxBW(callInfo_type *ptCi, bool (&rBestSCellsMap)[MAX_SCELL_PER_CALL],
    uint16_t (&sCellAltBandOut)[MAX_MCO_MFBI_CELLS], uint32_t (&sCellIdxWithAltBandOut)[MAX_MCO_MFBI_CELLS],
    const cellSelection_type &rCellSelection, const bool noMfbiFlag);
void FnVCCB_UpdateMrsInfo(callInfo_type *ptCi, enumUpdateMrsInfo_type updateFlag);
int16_t FnVCCB_McoNeedToDlTrfStatusRptCfgForInterRatPccChange(callInfo_type *ptCi);
bool FnVCCB_CheckBCInfoResponse(const X2_PrivateMessage_type &msg);
bool FnVCCB_CheckMultiRatSelection(callInfo_type *ptCi, bool IsCapaCheck);
int16_t FnVCCB_MrsDecideInterRATHandoverToEutra(callInfo_type *ptCi);
int16_t FnVCCB_NeedToDlTrfStatusRptCfgforMrsAddPerDRB(callInfo_type *ptCi, callDRBInfo_type *pDi, bool isSend,
    uint16_t cellNum);
void FnVCCB_SetMultiRatSelectionInitState(callInfo_type *ptCi);
int16_t FnVCCB_TriggerMultiRatSelection(callInfo_type *ptCi);
void FnVCCB_McoLbCheckSpCellCandidatesAgainstAllBc(callInfo_type *ptCi, const bandCombinationList_type &ueSupBandCombList,
    const mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBand, const uint16_t bandNr,
    const candidateCellListForSort_type &ccListForSort, mcoLbResult_s &lbResultOut);

void FnVCCB_CalculateMaxBwForSccChange(callInfo_type *ptCi, const uint8_t newNrCapaReceiveFlag);
bool FnVCCB_CheckCurrentSCellMaxBwForSccChange(callInfo_type *ptCi);
void FnVCCB_FillSliceAvailableCapacityDl(callInfo_type *ptCi, CellNum_type spCellNum, const cgi_type &cgi,
    caCellInfo_type *ptCellInfo);

int16_t FnVCCB_McoCheckAllBcForMaxBw(callInfo_type *ptCi, 
    const bandCombinationList_type &ueSupBandCombList, const mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBand, 
    bool (&rBestSCellsMapOut)[MAX_SCELL_PER_CALL], uint32_t &rEffectiveBwOut, const uint16_t psCellBandNr);
bool FnVCCB_CheckIfNrDcCapaRequiredForPcc(const callInfo_type &rCall);

inline bool FnVCCB_McoVerifyMfbi(const VccbGnbInfo_type* pGnb, uint16_t cellNum) // inlined in order to speed up MCO functions
{
    VALID_E_POINT_CHECK_RET_VAL(pGnb, false);
    return pGnb->multiCarrierOperation.mfbiCheck && VLIB_CanEnforceBandSelectionOnDu(cellNum);
}

mcoLbUeBcKey_type FnVCCB_McoLbGetUeBcKey(const callInfo_type &rCall, const bandCombinationList_type &ueSupBandCombList,
    const uint16_t pcellBand);
bool FnVCCB_FindMcoLbCellCache(const CellNum_type cellNum, const uint8_t eligibleCcIdxBitmsk,
    const McoLbCacheUeBcKey_type ueBcKey, McoLbCacheResultEntry_type &rCachedResultOut);
void FnVCCB_SetMcoLbCellCache(const CellNum_type cellNum, const McoLbCacheResultEntry_type &rResultIn);

void FnVCCB_McoRetrieveBcData(callInfo_type *ptCi, const BandCombination_type &bc, const uint32_t bcIndex,
    const enumRAT_type ratType, const McoAlgoFlags &algoFlags, mcoBand2numContCcDq_type &mcoBand2numContCcDqOut,
    mcoBand2mcoNumContiguousCc_type &band2numContiguousCcULOut);

bool FnVCCB_McoCheckBcBandAgainstCcList(callInfo_type *ptCi, const mcoCcInfoVec_type &ccInfoVec,
    const mcoBcBandInfoDq_type &bcBandInfoDq, const bool checkPcell, char *pCcCauseCodesTab,
    mcoCheckBcBandResultsCache_s *pBcBandResultsCache, const bool checkUlBwFlag, const bool noMimoFlag,
    mcoCheckBcResult_s &result);

void FnVCCB_SortMcoConfigEntries(multiCarrierOperationProfileEntry_type &rProfile);

#endif /* VCCB_FEAT_HDR_FEATMCO_HPP_ */
