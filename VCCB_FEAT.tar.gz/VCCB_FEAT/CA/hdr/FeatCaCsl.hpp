#include <algorithm>
#include "VccbStruct.h"
#include "VccbMacro.h"
#include "ComGlobalData.h"
#include "ComMacro.h"
#include "ComEg.h"
#include "ComInline.h"
#include "ComTimeUtil.h"
#include "ComLibUtility.h"

void FnVCCB_RollbackSCellCslInfo(callInfo_type *ptCi);
void FnVCCB_SCellCslInfoUpdateBySCellToBeRemovedList(callInfo_type *ptCi, scellInfo_type &rSCell);
void FnVCCB_SCellCslInfoUpdateBySCellFailedList(callInfo_type *ptCi, scellInfo_type &rSCell, uint16_t f1Cause);
void FnVCCB_SCellCslInfoUpdateByCallRelease(callInfo_type *ptCi);
void FnVCCB_SetSCellCslRelCauseByCuTrigger(callInfo_type *ptCi, uint8_t cause);
void FnVCCB_CommitSCellCslAfterReconfiguration(callInfo_type *ptCi);
void FnVCCB_InitScellUlDlModeOfScellSetupOngoing(scellInfo_type &sCell);
void FnVCCB_ProcessScellCaCslUpdateForVonr(callInfo_type *ptCi);
void FnVCCB_UpdateScellUlDlMode(callInfo_type *ptCi);
