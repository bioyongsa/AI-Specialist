/**
 * @file        FeatMco.h
 * @brief       Functions for Multi Carrier Operations feature
 */

#ifndef VCCB_FEAT_HDR_FEATMCO_H_
#define VCCB_FEAT_HDR_FEATMCO_H_

#include "VccbStruct.h"

void FnVCCB_InitMrsInfo(callInfo_type *ptCi, enumMrsInfoInitIndicator_type flag);
void FnVCCB_InitPrevMrsInfo(callInfo_type *ptCi);
void FnVCCB_InitSccBwData(callInfo_type *ptCi);
bool FnVCCB_McoCheckIfCpuIsOverloaded();
void FnVCCB_InitSccData(callInfo_type *ptCi, enumSccDataInitIndicator_type flag);
void FnVCCB_UpdateSccData(callInfo_type *ptCi, bool rollBackFlag);
void FnVCCB_InitSccStateMrFlag(callInfo_type *ptCi);
void FnVCCB_InitSccFlagCellMeasured(callInfo_type *ptCi);

bool FnVCCB_CheckNotTriggerConditionForSCC(callInfo_type *ptCi);
bool FnVCCB_CheckAvailableForSccChange(callInfo_type *ptCi);
void FnVCCB_LibStatMRSEvent(callInfo_type *ptCi, int mType);

#endif /* VCCB_FEAT_HDR_FEATMCO_H_ */
