/**
 * @file        FeatNrdcMnBcReselection.h
 * @brief       Structure definitions for NR-DC Band Combination Selection
 */

#ifndef VCCB_FEAT_FeatNrdcMnBcReselection_HPP_
#define VCCB_FEAT_FeatNrdcMnBcReselection_HPP_

#include "VccbStruct.h"
#include "FeatMrdc.h"
#include "StateCommon.h"
#include "MsgNrRrcStore.h"
#include "ComMacro.h"
#include "ComInline.h"
#include "ComLibUtility.h"
#include "MsgNrRrcStore.h"

#include <vector>

void FnVCCB_ProcessMnBcReselection(callInfo_type *ptCi, bool isHoCancle);

class BcInfo
{
public:
    using bandParametersKeyValue_type = struct
    {
        union
        {
            struct
            {
                uint64_t bandIndicator : 16;
                uint64_t bandClassDl   : 8;
                uint64_t bandClassUl   : 8;
                uint64_t dlSetId       : 16;
                uint64_t ulSetId       : 16;
            };
            uint64_t keyValue;
        };
    };

    using bandCombinationValue_type = struct
    {
        uint16_t noOfBandParam;
        bandParametersKeyValue_type bandParamKeyValue[MAX_BANDS_PER_COMB];
    };

    bandCombinationValue_type keyWithFs;
    bandCombinationValue_type keyWithoutFs;
    BandCombination_type ueBc;
    MrdcFeatureSetCombination_type ueFsComb;

    BcInfo(callInfo_type *_ptCi);
    ~BcInfo();

    bool getUeBc(const uint32_t bcIdx, const bandCombinationList_type *ptUeBandCombList,
        const MrdcFeatureSetCombinationList_type *ptFeatureSetBcList);
    bool makeWithFsKey(uint32_t fsEntryIdx);
    bool makeWithoutFsKey();

    static bool compareKeyValueForFr2Band(callInfo_type *ptCi, const bandCombinationValue_type selectedBcKey, const bandCombinationValue_type targetBcKey);
    static bool compareUeBcForFr2Band(callInfo_type *ptCi, const BandCombination_type selectedUeBc, const BandCombination_type targetUeBc);

private:
    callInfo_type *ptCi = nullptr;
    bool keyMake(uint32_t featureSetEntryIdx, bandCombinationValue_type& targetKey);
    bool makeKeyInternal(uint32_t fsEntryIdx, bandCombinationValue_type& targetKey);
};

class MnBCReselectionConditionChecker 
{
public:
    static const bool BASIC_OPERATION = false;
    static const bool HO_CANCLE = true;
    
    MnBCReselectionConditionChecker(callInfo_type *_ptCi);
    ~MnBCReselectionConditionChecker();

    bool isSendAllowedBcToMnDu();
    bool isMnBcReselectionAvailable();
    bool isSendAllowedBcOnConfigRestrictInfo(uint32_t bit_mask);
    bool isSelectedBcReceived();
private:
    callInfo_type *ptCi = nullptr;
    
    bool isScellActionChanged();
};

class MnBCReselector
{
public:
    MnBCReselector(callInfo_type*_ptCi);
    ~MnBCReselector();

    void makeAllowedBcForMnBcReselection();
private:
    static const uint32_t MAX_FEATURE_SET_BIT_MASK = 16;
    callInfo_type *ptCi = nullptr;
    bandCombinationList_type *ptUeBandCombList = nullptr;
    MrdcFeatureSetCombinationList_type *ptFeatureSetBcList = nullptr;
    bandCombinationInfoList_type *ptAllowedBcList = nullptr;

    uint16_t noOfSameBc = 0;
    vector<bandCombinationInfo_type> resultBandCombinationList;

    bandCombinationList_type *getBandCombinationForNrDcAllowedBcFiltering();

    bool findAndProcessMatchingFeatureSets(const BcInfo& selectedBc, const bandCombinationInfo_type& targetAllowedBc);
    bool getUeCapa();
    bool isOnAllowedFeatureSetsBitmask(const bandCombinationInfo_type &targetAllowedBc, uint16_t fsIdx);
    void setResultBandCombinationList(const bandCombinationInfo_type targetAllowedBc, uint8_t targetFeatureSetsBitmask[MAX_FEATURE_SET_BIT_MASK]);
    void setBandCombinationInfoFilteredSelectedBc();
    void printBc(uint32_t bcIdx);
};

#endif
