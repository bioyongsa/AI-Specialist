/**
 * @file        FeatTsmDuInterworking.hpp
 * @brief       Functions for TSM DU interworking operations
 */

#ifndef VCCB_FEAT_FeatTsmDuInterworking_HPP_
#define VCCB_FEAT_FeatTsmDuInterworking_HPP_

#include "ComInclude.min.h"

namespace TsmDuInterworking
{
    void FnVCCB_ProcessMeasurementReport(callInfo_type &rCall, const enumMeasurementReportType type, const int reportPurpose, const measurementObjectUe_type &rMO);
}

#endif  // VCCB_FEAT_FeatTsmDuInterworking_HPP_
