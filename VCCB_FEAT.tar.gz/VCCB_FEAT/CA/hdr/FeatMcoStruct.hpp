/**
 * @file        FeatMcoStruct.h
 * @brief       Structure definitions for Call Control for Multi-Carrier Operation (MCO)
 */

#ifndef VCCB_FEAT_FeatMcoStruct_HPP_
#define VCCB_FEAT_FeatMcoStruct_HPP_

#include "VccbStruct.h"
#include "VccbDefine.h"
#include "ComContainers.hpp"
#include "ComGlobalData.h"
#include <atomic>
#include <optional>

class McoSlbOpCounts
{
    private:
        std::atomic<uint32_t> m_opCntMrs;
        std::atomic<uint32_t> m_opCntPccChange;
        std::atomic<uint32_t> m_opCntSccChange;
        std::atomic<uint32_t> m_opCntSlb;
        McoSlbOpCounts(): m_opCntMrs(0), m_opCntPccChange(0), m_opCntSccChange(0), m_opCntSlb(0) {};
        bool checkIfOpCountAboveThresholdAndIncrement(uint32_t maxCnt, std::atomic<uint32_t>& currentCnt);

    public:
        static McoSlbOpCounts &getOpCounts()
        {
            static McoSlbOpCounts opCounts;
            return opCounts;
        }

        void clearOpCounts();

        bool checkIfMrsOpCountAboveThresholdAndIncrement();
        bool checkIfPccOpCountAboveThresholdAndIncrement();
        bool checkIfSccOpCountAboveThresholdAndIncrement();
        bool checkIfSlbOpCountAboveThresholdAndIncrement();
#ifdef IPC_TEST
        uint32_t getCurMrsOpCount();
        uint32_t getCurPccOpCount();
        uint32_t getCurSccOpCount();
#endif

        // Delete copy/move construction and assignment
        McoSlbOpCounts(McoSlbOpCounts const&) = delete;
        McoSlbOpCounts(McoSlbOpCounts&&) = delete;
        McoSlbOpCounts& operator=(McoSlbOpCounts const&) = delete;
        McoSlbOpCounts& operator=(McoSlbOpCounts&&) = delete;
};

enum class enumAltBandCheckResult : uint8_t
{
    error = 0,
    noAltBandSwitch,
    pcellAltBandSwitch,
    scellAltBandSwitch
};

struct McoAlgoFlags
{
    bool noMimo;
    bool checkUlBw;
    bool ulOnlyMode;
    bool mfbiCheck;
    bool initialFmPcc;
    bool checkCarrierOnly;
    bool useSe;
    bool useMultiChBw;
};

struct EffectiveBwForPccFlags
{
    bool checkNrdc;
    bool isFinalFmPcc;
    bool checkCarrierOnly;
};

struct McoAltMeasuredCellInfo_s
{
    CellNum_type cellNum;
    uint16_t nbrIdx;
};

struct McoCellInformation_s
{
    const VccbCellInfo_type *const ptCell;
    const CellNum_type cellNum;

    McoCellInformation_s(const CellNum_type num) : ptCell(&CELLINFO[num]), cellNum(num) {};
};

struct mcoCcInfo_s
{
    mcoCcInfo_s() :
        mcoBwDl(0),
        grpId(0),
        pcellFlag(false),
        userValue(0),
        altBand(BAND_NOT_FOUND),
        altBandMcoBwDl(0),
        cellBwDl(0) {}

    uint32_t mcoBwDl;
    uint8_t grpId;
    bool pcellFlag;
    // additional parameters
    uint32_t userValue;  // for debug or callback
    uint16_t altBand;
    uint32_t altBandMcoBwDl; // valid only with altBand
    uint16_t cellBwDl;
};

typedef std::vector<mcoCcInfo_s> mcoCcInfoVec_type;

struct McoSeAdjustedBwPerCc_s
{
    uint32_t priBandBw = 0;
    uint32_t altBandBw = 0;
};
typedef std::vector<McoSeAdjustedBwPerCc_s> mcoSeAdjustedBwPerCcVec_type;

struct mcoCcInfoVecs_s
{
    mcoCcInfoVec_type ccInfoVec;
    mcoSeAdjustedBwPerCcVec_type seAdjustedBwVec;
};
typedef std::map<uint16_t, mcoCcInfoVecs_s> mcoBand2mcoCcInfoVecMap_type;  // key: frequencyBand

struct mcoUeCapaBcBandInfo_s
{
    mcoUeCapaBcBandInfo_s(uint8_t _numContiguousCcDL, uint8_t _numContiguousCcUL, uint8_t _dlMimoLayerNum) :
        numContiguousCcDL(_numContiguousCcDL), numContiguousCcUL(_numContiguousCcUL), dlMimoLayerNum(_dlMimoLayerNum), ulFlag(0 < _numContiguousCcUL)
    {
    }

    uint8_t numContiguousCcDL;
    uint8_t numContiguousCcUL;
    uint8_t dlMimoLayerNum;
    bool ulFlag;  // indicates that PCell can be assigned, UL BW class permutation enabled
};

typedef std::deque<mcoUeCapaBcBandInfo_s> mcoBcBandInfoDq_type;
typedef std::map<uint16_t, mcoBcBandInfoDq_type> mcoBand2numContCcDq_type;  // key: frequencyBand

typedef std::map<uint16_t, uint8_t> mcoBand2mcoNumContiguousCc_type;  // key: frequencyBand

struct mcoUCBcContigGrpChkInfo_s
{
    mcoUCBcContigGrpChkInfo_s(uint16_t _ccIdxHead = 0, uint16_t _ccIdxTail = 0) :
        ccIdxHead(_ccIdxHead),
        ccIdxTail(_ccIdxTail)
    {
    }

    void setHeadAndTail(uint16_t ccIdx)
    {
        ccIdxHead = ccIdx;
        ccIdxTail = ccIdx;
    }

    uint16_t ccIdxHead;
    uint16_t ccIdxTail;
};

struct mcoCheckBcResult_s
{
    mcoCheckBcResult_s() : ccCnt(0), mcoBwDl(0), mcoBwUl(0), pcellAdded(false), ccIdxBitmask(0), maxUlBwPcellIdxBitmask(0),
        ccMimo2Bitmask(0), ccMimo4Bitmask(0) {}

    void reset()
    {
        ccCnt = 0;
        mcoBwDl = 0;
        mcoBwUl = 0;
        pcellAdded = false;
        ccIdxBitmask = 0;
        maxUlBwPcellIdxBitmask = 0;
        ccMimo2Bitmask = 0;
        ccMimo4Bitmask = 0;
    }

    uint32_t ccCnt;
    uint32_t mcoBwDl;
    uint32_t mcoBwUl;
    bool pcellAdded;
    uint64_t ccIdxBitmask;  // idx is referencing to mcoCcInfoVec_type
    uint64_t maxUlBwPcellIdxBitmask;  // idx is referencing to mcoCcInfoVec_type
    uint64_t ccMimo2Bitmask;  // idx is referencing to mcoCcInfoVec_type
    uint64_t ccMimo4Bitmask;  // idx is referencing to mcoCcInfoVec_type
};

struct mcoEutraCellInfo_s
{
    uint16_t frequencyBand;
    uint32_t freqKhzDl;
    uint32_t bwKhzDl;
    bool isPcell;
    uint32_t earfcn;
};

struct mcoCacheBuffInfo_s
{
    uint8_t *buffer;
    void *currPtr;
    std::size_t size;
};

template <typename T>
class mcoLinearAllocator_s
{
public:
    /// interface
    typedef size_t size_type;
    typedef ptrdiff_t difference_type;
    typedef T *pointer;
    typedef const T *const_pointer;
    typedef T &reference;
    typedef const T &const_reference;
    typedef T value_type;

    mcoLinearAllocator_s(mcoCacheBuffInfo_s &rBufferInfo) noexcept : _rBufferInfo(rBufferInfo) {}

    mcoLinearAllocator_s(const mcoLinearAllocator_s &ref) noexcept : _rBufferInfo(ref._rBufferInfo) {}

    template <typename _Tp1>
    mcoLinearAllocator_s(const mcoLinearAllocator_s<_Tp1> &ref) noexcept : _rBufferInfo(ref._rBufferInfo)
    {
    }

    ~mcoLinearAllocator_s() {}

    template <typename _Tp1>
    struct rebind
    {
        typedef mcoLinearAllocator_s<_Tp1> other;
    };

    T *allocate(size_type __n, const void * = 0);

    void deallocate(pointer __p, size_type __n)
    {
        (void)__p;
        (void)__n;
    }

    void construct(pointer __p, const T &__val) { ::new ((void *)__p) value_type(__val); }

    void destroy(pointer __p) { __p->~T(); }

    /// internal
    mcoCacheBuffInfo_s &_rBufferInfo;
};

class mcoCheckBcBandResultsCache_s
{
public:
    typedef unsigned __int128 key_type;
    typedef mcoLinearAllocator_s<std::pair<const key_type, mcoCheckBcResult_s> > mcoCheckBcBandResultsCacheAlloc_type;
    typedef std::map<key_type, mcoCheckBcResult_s, std::less<key_type>, mcoCheckBcBandResultsCacheAlloc_type>
        storage_type;
    static const key_type INVALID_KEY = 0;

    mcoCheckBcBandResultsCache_s(mcoCacheBuffInfo_s &rBufferInfo);
    static key_type makeBcBandKey(const mcoBcBandInfoDq_type &bcBandInfoDq);
    static key_type makeBcBandKeyDlUl(const mcoBcBandInfoDq_type &bcBandInfoDq);
    bool getResult(const key_type &key, mcoCheckBcResult_s &resultOut) const;
    bool setResult(const key_type &key, const mcoCheckBcResult_s &result);

private:
    storage_type _storage;
};

class mcoBand2BcBandResultsCache_s
{
public:
    typedef mcoLinearAllocator_s<std::pair<const uint16_t, mcoCheckBcBandResultsCache_s> >
        mcoBand2BcBandResultsCacheAlloc_type;
    typedef std::map<uint16_t, mcoCheckBcBandResultsCache_s, std::less<uint16_t>, mcoBand2BcBandResultsCacheAlloc_type>
        mcoBand2BcBandResultsCacheInternal_type;  // key: frequencyBand

    mcoBand2BcBandResultsCache_s(const callInfo_type *ptCi);
    void init();
    mcoCheckBcBandResultsCache_s *getForBand(const enumRAT_type ratType, const uint16_t band);
    const mcoCheckBcBandResultsCache_s *getForBand(const enumRAT_type ratType, const uint16_t band) const;

protected:
    mcoBand2BcBandResultsCache_s(const mcoBand2BcBandResultsCache_s &) = delete;
    mcoBand2BcBandResultsCache_s &operator=(const mcoBand2BcBandResultsCache_s &) = delete;
    void initBuffer();

private:
    const uint8_t _threadId;
    mcoCacheBuffInfo_s &_rBufferInfo;
    mcoBand2BcBandResultsCacheInternal_type _storageNr;
    mcoBand2BcBandResultsCacheInternal_type _storageEutra;

    static mcoCacheBuffInfo_s _buffInfoMainTh;
    static mcoCacheBuffInfo_s _buffInfoCallThTab[VCCB_CALL_THREAD_NUM];
};

typedef mcoBand2BcBandResultsCache_s mcoBand2BcBandResultsCache_type;

typedef simpleVector<uint16_t, MAX_NUM_FREQ> MeasuredBands_type;
typedef simpleVector<uint32_t, MAX(MAX_NUM_BAND_COMB, MAX_BAND_COMBS)> McoBCIdxArray_type;

typedef struct mcoBcSelCellInfo_s : public caCellInfo_type
{
    uint16_t altBand = BAND_NOT_FOUND;
    uint32_t seAdjustedBw = 0;
    uint32_t seAdjustedAltBandBw = 0;
    uint16_t cellBwDl;
} mcoBcSelCellInfo_type;

typedef struct caScellCcInfo_s
{
    uint16_t frequencyBand;
    uint16_t mcoBwDl;
    uint16_t mcoBwUl;
} caScellCcInfo_type;

typedef struct mcoSccCcInfo_s
{
    uint16_t frequencyBand;
    uint16_t sCellIndex;    // ptCi->sCell[index], MAX_SCELL_PER_CALL -> PCell
    uint32_t nrArfcnDl;
    uint8_t nrScsDl;
    uint8_t nRbDl;
    uint16_t mcoBwDl;
    uint16_t mcoBwUl;
    uint16_t altBand;
} mcoSccCcInfo_type;

typedef struct mcoPscellCcInfo_s
{
    mcoCcInfo_s ccInfo;
    uint16_t band;
    uint16_t nbrIdx;
    uint16_t pci;
} mcoPscellCcInfo_type;

typedef simpleVector<PccCandidateResult_type, MAX_PCC_RESULTS_PER_CANDIDATE> PccCandidateResultList_type;
typedef simpleVector<caCellInfo_type, MAX(MAX_COLOCCELL+1, MAX_CELL_PER_DU)> caCellInfoListMcoLb_type;

typedef struct mcoGrpUlBwResult_s
{
    uint32_t woPcellBw{0};
    uint32_t incPcellBw{0};
    uint64_t ulBwPcellIdxBitmask{0};
} mcoGrpUlBwResult_type;

typedef struct mcoGrpUlBwResultFiller_s
{
    const mcoCcInfoVec_type &m_ccInfoVec;
    const uint16_t *m_pColocCcIdxTab;
    const unsigned long int m_maxCcPosIdx;
    const uint64_t m_eligCcIdxBitmask;

    unsigned long int m_grpFirstPosIdx; // first position in current contiguous group
    unsigned long int m_grpLastPosIdx; // last position in current contiguous group

    mcoGrpUlBwResultFiller_s(const mcoCcInfoVec_type &ccInfoVec, const uint16_t *pColocCcIdxTab,
            const unsigned long int maxCcPosIdx, const uint64_t eligCcIdxBitmask):
            m_ccInfoVec(ccInfoVec), m_pColocCcIdxTab(pColocCcIdxTab), m_maxCcPosIdx(maxCcPosIdx),
            m_eligCcIdxBitmask(eligCcIdxBitmask), m_grpFirstPosIdx(0), m_grpLastPosIdx(0)
        {};

    mcoGrpUlBwResult_s operator()(const mcoUeCapaBcBandInfo_s &rBcBandInfo);
    unsigned long int FnVCCB_GetGrpLastEligiblePosIdx() const;
} mcoGrpUlBwResultFiller_type;

typedef struct mcoLbResult_s
{
    uint32_t _bwDl;
    uint32_t _bwUl;
    uint8_t _candidateIdx;
    uint8_t _candidateBitmask;

    mcoLbResult_s(): _bwDl(0), _bwUl(0), _candidateIdx(MAX_NUM_CANDIDATE_CELL_FOR_PSCELL), _candidateBitmask(0) {}

    void reset()
    {
        _bwDl = 0;
        _bwUl = 0;
        _candidateIdx = MAX_NUM_CANDIDATE_CELL_FOR_PSCELL;
        _candidateBitmask = 0;
    }

    void setIfBetter(const uint32_t bwDlIn, const uint32_t bwUlIn, const uint8_t candidateIdxIn);
} mcoLbResult_type;

typedef struct iratPccTypeAndPurpose_s
{
    enumMeasurementReportType type;
    uint8_t purpose;
} iratPccTypeAndPurpose_type;

typedef struct FinalFmPccCandidateData_s
{
    cellSelection_type cellNumAndBand;
    mcoBand2mcoCcInfoVecMap_type ccInfoVecPerBand;
    McoAlgoFlags algorithmFlags; // mfbi and useSe are set per candidate
    PccCandidateInfo_type * ptrToCandidate;
} FinalFmPccCandidateData_type;

// set type for coloc cells frequencies'
typedef staticUnorderedSet<Arfcn_type, MAX_COLOCCELL> mcoColocCellsSsbArfcns_type;

// FM PCC related using directives
using McoFmPccArfcnList_type = staticUnorderedSet<Arfcn_type, MAX_MCO_FM_PCC_ARFCN>;
using McoFmPccChosenArfcnLists_type = simpleVector<std::optional<McoFmPccArfcnList_type>, MAX_PCC_RESULTS_PER_CANDIDATE>;

// LB Caching
using bcBandKeyVec_type = simpleVector<mcoCheckBcBandResultsCache_s::key_type, MAX_BAND_COMBS>;
using mcoLbUeBcKey_type = unsigned __int128;
typedef simpleVector<CellNum_type, MAX_MCO_LB_CC_PER_BAND> mcoLbCellNumTab_type;

// FR1030 Inter RAT PCC Change
struct mcoIratPccConfig_type : public multiCarrierOperationProfileEntry_type::MultiCarrierOperationConfigEntry_s::MultiCarrierOperationConfigEntryOperation_s
{
    bool ulThresholdSet = false;
    bool dlThresholdSet = false;
    bool operator==(const mcoIratPccConfig_type& rhs) const
    {
        return 
            (this->iratPccChgUsage == rhs.iratPccChgUsage) &&
            (this->ulAwareThresholdUsageForIratPccChg == rhs.ulAwareThresholdUsageForIratPccChg) &&
            (this->ulTrafficThresholdForIratPccChg == rhs.ulTrafficThresholdForIratPccChg) &&
            (this->ulBwThresholdForIratPccChg == rhs.ulBwThresholdForIratPccChg) &&
            (this->ulThresholdSet == rhs.ulThresholdSet) &&
            (this->dlAwareThresholdUsageForIratPccChg == rhs.dlAwareThresholdUsageForIratPccChg) &&
            (this->dlTrafficThresholdForIratPccChg == rhs.dlTrafficThresholdForIratPccChg) &&
            (this->dlBwThresholdForIratPccChg == rhs.dlBwThresholdForIratPccChg) &&
            (this->dlThresholdSet == rhs.dlThresholdSet);
    }
};

#endif
