

#include "FeatCaCsl.hpp"

void caCsllogPrint(callInfo_type &rCi, uint8_t cslIdx, void *reserved)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(cslIdx, MAX_SCELL_CA_CSL);

    const auto csl = rCi.sCellCsl[cslIdx];
    if (reserved == nullptr)
    {
        VCCB_PRINT_LOG_CA_CSL_FUNC(
            &rCi, "[CA_CSL] cslIdx[%d] state[%d] cgi[%lu] is updated !! \n", cslIdx, csl.state, csl.cslCgi.ci);
    }
    else
    {
        uint8_t sCellUlDlMode = *static_cast<uint8_t *>(reserved);
        VCCB_PRINT_LOG_CA_CSL_FUNC(&rCi, "[CA_CSL] cslIdx[%d] state[%d] cgi[%lu] sCellUlDlMode[%s] is updated !! \n",
            cslIdx, csl.state, csl.cslCgi.ci, (sCellUlDlMode == sCell_ulDlBoth ? "BOTH" : "DLONLY"));
    }

    VCCB_PRINT_LOG_CA_CSL_FUNC(&rCi, "[CA_CSL] ==> caDeConRes[%d] caDeConResTemp[%d] caConfigCnt[%d] caDeConCnt[%d]\n",
        csl.caDeConRes, csl.caDeConResTemp, csl.caConfigCnt, csl.caDeConCnt);
    VCCB_PRINT_LOG_CA_CSL_FUNC(&rCi,
        "[CA_CSL] ==> dlCaConfigVonrCnt[%d] dlCaDeConfigVonrCnt[%d] ulCaConfigVonrCnt[%d] "
        "ulCaDeConfigVonrCnt[%d]\n",
        csl.dlCaConfigVonrCnt, csl.dlCaDeConfigVonrCnt, csl.ulCaConfigVonrCnt,
        csl.ulCaDeConfigVonrCnt);
}

uint8_t FnVCCB_FindSCellCslIndex(callInfo_type &rCi, scellInfo_type &sCell)
{
    AUTO_TRACE_FUNC;

    uint8_t cslIdx = MAX_SCELL_CA_CSL;
    for (cslIdx = 0; cslIdx < MAX_SCELL_CA_CSL; ++cslIdx)
    {
        auto &cellCsl = rCi.sCellCsl[cslIdx];
        if (cellCsl.state != CSL_NOT_SET && cellCsl.cslCgi.ci == sCell.cgi.ci)
        {
            return cslIdx;
        }
    }

    for (cslIdx = 0; cslIdx < MAX_SCELL_CA_CSL; ++cslIdx)
    {
        auto &cellCsl = rCi.sCellCsl[cslIdx];
        if (cellCsl.state == CSL_NOT_SET)
        {
            return cslIdx;
        }
    }

    return MAX_SCELL_CA_CSL;
}


void FnVCCB_SortSCellCslInfo(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    std::sort(rCi.sCellCsl, rCi.sCellCsl + MAX_SCELL_CA_CSL,
        [](const sCellCslInfoInternal_type &lhs, const sCellCslInfoInternal_type &rhs)
        {
            if (lhs.lastDeconTime.tv_sec != rhs.lastDeconTime.tv_sec)
            {
                return lhs.lastDeconTime.tv_sec < rhs.lastDeconTime.tv_sec;
            }
            else if (lhs.lastDeconTime.tv_nsec != rhs.lastDeconTime.tv_nsec)
            {
                return lhs.lastDeconTime.tv_nsec < rhs.lastDeconTime.tv_nsec;
            }
            else
            {
                return lhs.sCellIdx > rhs.sCellIdx;
            }
        });
}

uint8_t FnVCCB_FindSCellCslIndexByMaxDeconfigTime(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    FnVCCB_SortSCellCslInfo(rCi);

    auto isCurrentAddScell = [](auto &sCellCsl, auto &scellList) -> bool
    {
        for(auto sCell : scellList)
        {
            if (sCell.cgi.ci == sCellCsl.cslCgi.ci)
            {
                 if (sCell.state == SCELL_STATE_ADDED)
                 {
                    return true;
                 }
                 else
                 {
                    return false;
                 }
            }
        }
        
        return false;
    };

    auto pCellChangeOngoing = [&]() -> bool
    {
        if (rCi.stateCmd == IntraRatHO_cmd && rCi.hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
            return true;
        if (rCi.stateCmd == RrcReestablish_cmd && rCi.ueInfo.reestablishInfo.reestablishType != RRE_TYPE_INTER_GNB)
            return true;
        return false;
    };

    uint8_t maxDeconfigTimeIdx = MAX_SCELL_CA_CSL;
    for (uint8_t cslIdx = 0; cslIdx < MAX_SCELL_CA_CSL; ++cslIdx)
    {
        bool addScell = false;

        if (pCellChangeOngoing())
        {
            addScell = isCurrentAddScell(rCi.sCellCsl[cslIdx], rCi.sCellDuConfig);
        }
        else
        {
            addScell = isCurrentAddScell(rCi.sCellCsl[cslIdx], rCi.sCell);
        }

        if (addScell)
        {
            continue;
        }

        if (rCi.sCellCsl[cslIdx].state ==  CSL_COLLECT_ONGOING)
        {
            continue;
        }

        maxDeconfigTimeIdx = cslIdx;
        break;
    }

    VCCB_CHECK_E_RANGE_AND_VAL(maxDeconfigTimeIdx, MAX_SCELL_CA_CSL, MAX_SCELL_CA_CSL);

    auto &cellCsl = rCi.sCellCsl[maxDeconfigTimeIdx];

    memset(&cellCsl.cslCgi, 0x00, sizeof(csl_cgi_type));
    cellCsl.state = CSL_NOT_SET;
    cellCsl.caConfigCnt = 0;
    cellCsl.caDeConCnt = 0;
    cellCsl.dlCaConfigVonrCnt = 0;
    cellCsl.dlCaDeConfigVonrCnt = 0;
    cellCsl.ulCaConfigVonrCnt = 0;
    cellCsl.ulCaDeConfigVonrCnt = 0;
    cellCsl.caDeConRes = 0;
    cellCsl.caDeConResTemp = 0;
    memset(&cellCsl.lastDeconTime, 0x00, sizeof(struct timespec));
    cellCsl.sCellIdx = 0;

    return maxDeconfigTimeIdx;
}

uint8_t FnVCCB_GetSCellCslIndex(callInfo_type &rCi, scellInfo_type &sCell)
{
    AUTO_TRACE_FUNC;

    uint8_t findSCellCslIdx = FnVCCB_FindSCellCslIndex(rCi, sCell);
    if (findSCellCslIdx >= MAX_SCELL_CA_CSL)
    {
        findSCellCslIdx = FnVCCB_FindSCellCslIndexByMaxDeconfigTime(rCi);
    }
    else // to ignore ongoing sCell
    {
        if (rCi.sCellCsl[findSCellCslIdx].state == CSL_COLLECT_ONGOING)
        {
            return MAX_SCELL_CA_CSL;
        }
    }

    return findSCellCslIdx;
}

uint8_t FnVCCB_ConvertF1apCauseToCaCsl(uint16_t f1Cause)
{
    AUTO_TRACE_FUNC;

    switch (f1Cause)
    {
        case CauseF1apMiscUnspecifiedFailure:
            return static_cast<uint8_t>(ca_csl_DU_MiscUnspecifiedFailure);
        case CauseF1apRadioCellNotAvailable:
            return static_cast<uint8_t>(ca_csl_DU_CellNotAvailable);
        case CauseF1apMiscOMIntervention:
            return static_cast<uint8_t>(ca_csl_DU_OnmIntervention);
        case CauseF1apRadioUeRejection:
            return static_cast<uint8_t>(ca_csl_DU_UE_Rejection);
        case CauseF1apRadioResourcesNotAvailableForTheSlice:
            return static_cast<uint8_t>(ca_csl_DU_SliceNotAvailable);
        case CauseF1apRadioUnavailableRadioReasons:
            return static_cast<uint8_t>(ca_csl_DU_NoRadioResourcesAvailable);
        case CauseF1apMiscControlProcessingOverload:
            return static_cast<uint8_t>(ca_csl_DU_ControlProcessingOverload);
        case CauseF1apMiscHardwareFailure:
            return static_cast<uint8_t>(ca_csl_DU_HW_Failure);
        case CauseF1apRadioInteraction:
            return static_cast<uint8_t>(ca_csl_DU_InteractionWithOtherProcedure);
        default:
            return static_cast<uint8_t>(ca_csl_DU_Others);
    }
}

void FnVCCB_UpdateSCellCsl(uint8_t state, callInfo_type *ptCi, scellInfo_type &sCell, uint8_t cslCause)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t sCellCsldx = FnVCCB_GetSCellCslIndex(*ptCi, sCell);

    VCCB_CHECK_RANGE_AND_RETURN_VOID(sCellCsldx, MAX_SCELL_CA_CSL, "sCellCsldx");

    auto &sCellCsl = ptCi->sCellCsl[sCellCsldx];

    sCellCsl.state = state;
    memcpy(&sCellCsl.cslCgi, &sCell.cgi, sizeof(csl_cgi_type));
    sCellCsl.caDeConResTemp = cslCause;
    sCellCsl.sCellIdx = sCell.sCellIndex;
}

void FnVCCB_SCellCslInfoUpdateBySCellToBeRemovedList(callInfo_type *ptCi, scellInfo_type &rSCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->sCellCslRelCauseByCuTrigger == UNDEFINED_CA_CSL_CAUSE)
    {
        FnVCCB_SetSCellCslRelCauseByCuTrigger(ptCi, ca_csl_CU_Others);
    }
    VCCB_PRINT_LOG_CA_CSL_FUNC(ptCi, "[CA_CSL] CU Release scell sCellIdx[%d] ci[%lu]\n", rSCell.sCellIndex, rSCell.cgi.ci);
    FnVCCB_UpdateSCellCsl(CSL_COLLECT_ONGOING, ptCi, rSCell, ptCi->sCellCslRelCauseByCuTrigger);
}

void FnVCCB_SCellCslInfoUpdateBySCellFailedList(callInfo_type *ptCi, scellInfo_type &rSCell, uint16_t f1Cause)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    
    VCCB_PRINT_LOG_CA_CSL_FUNC(ptCi, "[CA_CSL] DU Release scell sCellIdx[%d] ci[%lu]\n", rSCell.sCellIndex, rSCell.cgi.ci);
    FnVCCB_UpdateSCellCsl(CSL_COLLECT_ONGOING, ptCi, rSCell, FnVCCB_ConvertF1apCauseToCaCsl(f1Cause));
}

void FnVCCB_CopySCellCslInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    for (uint8_t cslIdx = 0; cslIdx < MAX_SCELL_CA_CSL; ++cslIdx)
    {
        auto &dest = ptCi->cslInfo.sCellConfigInfo[cslIdx];
        auto &src = ptCi->sCellCsl[cslIdx];

        memcpy(&dest.cslCgi, &src.cslCgi, sizeof(csl_cgi_type));
        dest.caConfigCnt = src.caConfigCnt;
        dest.caDeConCnt = src.caDeConCnt;
        dest.caDeConRes = src.caDeConRes;
        dest.dlCaConfigVonrCnt = src.dlCaConfigVonrCnt;
        dest.dlCaDeConfigVonrCnt = src.dlCaDeConfigVonrCnt;
        dest.ulCaConfigVonrCnt = src.ulCaConfigVonrCnt;
        dest.ulCaDeConfigVonrCnt = src.ulCaDeConfigVonrCnt;
    }
}

void FnVCCB_RollbackSCellCslInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    FnVCCB_InitCslInfo_CaScellFlag(ptCi);
    for (uint8_t idx = 0; idx < MAX_SCELL_CA_CSL; idx++)
    {
        auto &cellCsl = ptCi->sCellCsl[idx];

        if (cellCsl.state == CSL_COLLECT_ONGOING)
        {
            if (cellCsl.caDeConCnt == 0 && cellCsl.dlCaConfigVonrCnt == 0 && cellCsl.ulCaConfigVonrCnt == 0)
            {
                cellCsl.state = CSL_NOT_SET;
            }
            else
            {
                cellCsl.state = CSL_COLLECT_SUCCESS;
            }

            if (cellCsl.state == CSL_NOT_SET)
            {
                memset(&cellCsl.cslCgi, 0x00, sizeof(csl_cgi_type));
                cellCsl.caConfigCnt = 0;
                cellCsl.caDeConCnt = 0;
                cellCsl.caDeConRes = 0;
                cellCsl.caDeConResTemp = 0;
                cellCsl.dlCaConfigVonrCnt = 0;
                cellCsl.dlCaDeConfigVonrCnt = 0;
                cellCsl.ulCaConfigVonrCnt = 0;
                cellCsl.ulCaDeConfigVonrCnt = 0;
                memset(&cellCsl.lastDeconTime, 0x00, sizeof(struct timespec));
                cellCsl.sCellIdx = 0;
            }
        }
    }
}

void FnVCCB_SCellCslInfoUpdateByCallRelease(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->sCellCslRelCauseByCuTrigger == UNDEFINED_CA_CSL_CAUSE)
    {
        if (ptCi->stateCmd == IntraRatHO_cmd || ptCi->stateCmd == InterRatHO_cmd || ptCi->stateCmd == IntraCellHO_cmd)
        {
            FnVCCB_SetSCellCslRelCauseByCuTrigger(ptCi, ca_csl_CU_HO_out);
        }
        else if (ptCi->stateCmd == RRCSuspend_cmd)
        {
            FnVCCB_SetSCellCslRelCauseByCuTrigger(ptCi, ca_csl_CU_Others);
        }
        else if (ptCi->stateCmd == RrcReestablish_cmd)
        {
            FnVCCB_SetSCellCslRelCauseByCuTrigger(ptCi, ca_csl_CU_Others);
        }
        else
        {
            FnVCCB_SetSCellCslRelCauseByCuTrigger(ptCi, ca_csl_CU_UE_release);
        }
    }

    auto isOngoingCollectScell = [&](auto &rSCell) -> bool
    {
        for (sCellCslInfoInternal_type &sCsl : ptCi->sCellCsl)
        {
            if (rSCell.cgi.ci == sCsl.cslCgi.ci && sCsl.state == CSL_COLLECT_ONGOING)
            {
                return true;
            }
        }

        return false;
    };


    for (scellInfo_type &rSCell : ptCi->sCell)
    {
        if (rSCell.state == SCELL_STATE_ADDED && rSCell.action == SCELL_ACTION_KEEP)
        {
            if(isOngoingCollectScell(rSCell) || ptCi->bitFlag.skipCslCheckBeforeRrcReconfig)
            {
                continue;
            }

            FnVCCB_SCellCslInfoUpdateBySCellToBeRemovedList(ptCi, rSCell);
        }
    }

    if (ptCi->sCellCslRelCauseByCuTrigger == ca_csl_CU_UE_release)
    {
        for (sCellCslInfoInternal_type &sCsl : ptCi->sCellCsl)
        {
            if (sCsl.state == CSL_COLLECT_ONGOING)
            {
                sCsl.caDeConResTemp = ca_csl_CU_UE_release;
            }
        }

    }

    FnVCCB_CommitSCellCslAfterReconfiguration(ptCi);
}

void FnVCCB_CommitSCellCslAfterReconfiguration(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    struct timespec currentTime;
    if (ComTimeUtil::get_current_time(currentTime) < 0)
    {
        VCCB_PRINT_ERROR("ComTimeUtil::get_current_time ERROR in %s\n", __FUNCTION__);
        return;
    }

    for (uint8_t cslIdx = 0; cslIdx < MAX_SCELL_CA_CSL; cslIdx++)
    {
        auto &cellCsl = ptCi->sCellCsl[cslIdx];

        if (cellCsl.state == CSL_COLLECT_ONGOING)
        {
            cellCsl.caDeConCnt++;
            cellCsl.caConfigCnt = cellCsl.caDeConCnt;
            cellCsl.caDeConRes = cellCsl.caDeConResTemp;
            cellCsl.lastDeconTime = currentTime;
            cellCsl.state = CSL_COLLECT_SUCCESS;
            cellCsl.caDeConResTemp = 0;

            caCsllogPrint(*ptCi, cslIdx, nullptr);
        }
    }

    FnVCCB_CopySCellCslInfo(ptCi);
    FnVCCB_InitCslInfo_CaScellFlag(ptCi);
}

void FnVCCB_SetSCellCslRelCauseByCuTrigger(callInfo_type *ptCi, uint8_t cslCause)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    bool setFlag = false;
    if (cslCause == ca_csl_CU_UE_release)
    {
        // In case of abnormal Call Release during Inter gNB HO(SA, MN, SN) procedure, scell csl cause should be collected as below.
        if ((ptCi->stateCmd == IntraRatHO_cmd || ptCi->stateCmd == InterRatHO_cmd) && ptCi->hoInfo.hoType.nb == HO_TYPE_INTER_NB)
        {
            // Source gNB should collect scell csl as ca_csl_CU_UE_release before Source gNB sends RRCConnectionReconfigration
            // Target gNB should collect scell csl as ca_csl_CU_UE_release after Target gNB sends HandoverRequestAck
            if ((ptCi->state >= STATE_INTER_Pre_DU_S && ptCi->state < STATE_INTER_Exe_S) ||
                (ptCi->state >= STATE_INTER_Exe_T && ptCi->state <= STATE_INTER_Compl_T))
            {
                setFlag = true;
            }

            // MN gNB should collect cause as ca_csl_CU_UE_release during Inter SN HO procedure
            if (ptCi->state >= STATE_MN_INTER_SN_Pre_SN && ptCi->state <= STATE_MN_INTER_SN_Complete)
            {
                setFlag = true;
            }

            // Source SN should collect cause as ca_csl_CU_HO_out during Inter SN HO procedure (Source gNB first receives XNReleaseRequest)
            if (IS_NRDC_SN(ptCi) || ptCi->callType == E_CALLTYPE_NSA)
            {
                cslCause = ca_csl_CU_HO_out;
                setFlag = true;
            }
        }
        else if ((IS_NRDC_SN(ptCi) || ptCi->callType == E_CALLTYPE_NSA)  && ptCi->hoInfo.hoType.nb == HO_TYPE_INTER_NB)
        {
            // Source SN should collect cause as ca_csl_CU_HO_out during Inter SN HO procedure (Source gNB first receives XNodeReleaseRequest)
            cslCause = ca_csl_CU_HO_out;
            setFlag = true;
        }
        else if (ptCi->stateCmd == RrcReestablish_cmd && ptCi->ueInfo.reestablishInfo.reestablishType == RRE_TYPE_INTER_GNB)
        {
            // Source gNB should collect always scell csl as ca_csl_CU_Others
            // Source gNB cause will be set in FnVCCB_SCellCslInfoUpdateByCallRelease()
            // Target gNB should collect scell csl as ca_csl_CU_UE_release after Target gNB sends RRCReconfiguration
            if (ptCi->state == STATE_RRE_RRCRecCmpl || ptCi->state == STATE_RRE_Switch)
            {
                setFlag = true;
            }
        }
        else
        {
            setFlag = true;
        }
    }
    else if ((ptCi->sCellCslRelCauseByCuTrigger == ca_csl_CU_Others) && (ptCi->stateCmd != RrcReestablish_cmd) && (ptCi->stateCmd != RRCSuspend_cmd))
    {
        setFlag = true;
    }
    else if (cslCause == UNDEFINED_CA_CSL_CAUSE)
    {
        setFlag = true;
    }
    else if (ptCi->sCellCslRelCauseByCuTrigger == UNDEFINED_CA_CSL_CAUSE)
    {
        setFlag = true;
    }

    if (setFlag)
    {
        ptCi->sCellCslRelCauseByCuTrigger = cslCause;
        VCCB_PRINT_LOG_CA_CSL_FUNC(ptCi, "[CA_CSL] Set Csl Cause : cslCause(%d) callType (%d) stateCmd(%d) state(%d) \n", cslCause, ptCi->callType, ptCi->stateCmd, ptCi->state);
    }
}

class VonrSCellCslProcessor
{
public:
    VonrSCellCslProcessor(callInfo_type &_rCi) : rCi(_rCi) {}
    ~VonrSCellCslProcessor(){}
    
    static void InitScellUlDlMode(scellInfo_type &sCell);
    void UpdateScellUlDlMode();
    void SCellConfigCslInVoNRCount();
    void SCellDeConfigCslInVoNRCount();

private:
    callInfo_type &rCi;
    PHTypeListDU_type GetPhInfo();
    
    bool IsStableVonrInQosFlow(qosFlowInfo_type &qosFlow);
    bool SkipCollectScellCslInVoNR();
    bool ShouldCollectScellCSLInVoNR();
};

void VonrSCellCslProcessor::InitScellUlDlMode(scellInfo_type &sCell)
{
    AUTO_TRACE_FUNC;
    
    if (sCell.state == SCELL_STATE_ADDED && sCell.action == SCELL_ACTION_SETUP)
    {
        sCell.sCellUlDlMode = sCell_ul_dl_Unknown;
    }
}

bool VonrSCellCslProcessor::SkipCollectScellCslInVoNR()
{
    AUTO_TRACE_FUNC;

    switch (rCi.stateCmd)
    {
        case IntraCellHO_cmd:
        case IntraRatHO_cmd:
        case InterRatHO_cmd:
        case RrcReestablish_cmd:
        case RRCSuspend_cmd:
        case RRCResume_cmd:
            return true;
        default:
            return false;
    }
}

bool VonrSCellCslProcessor::IsStableVonrInQosFlow(qosFlowInfo_type &qosFlow)
{
    AUTO_TRACE_FUNC;

    if (qosFlow.usage != CI_use)
    {
        return false;
    }

    if (qosFlow.firstReqStatusInThisProcedure == S_Setup || qosFlow.firstReqStatusInThisProcedure == S_Release)
    {
        return false;
    }

    uint8_t fiveQi = 0;
    VLIB_getFiveQi(&qosFlow, &fiveQi);
    return (fiveQi == VONR_5QI);
}

bool VonrSCellCslProcessor::ShouldCollectScellCSLInVoNR()
{
    AUTO_TRACE_FUNC;

    if (SkipCollectScellCslInVoNR())
    {
        return false;
    }

    for (auto &qosFlow : rCi.qosFlow)
    {
        if (IsStableVonrInQosFlow(qosFlow))
        {
            return true;
        }
    }

    return false;
}

PHTypeListDU_type VonrSCellCslProcessor::GetPhInfo()
{
    AUTO_TRACE_FUNC;

    if (IS_NRDC_SN(&rCi) || rCi.callType == E_CALLTYPE_NSA)
    {
        return rCi.phInfoDuScgList;
    }
    else
    {
        return rCi.phInfoDuMcgList;
    }
}

void VonrSCellCslProcessor::UpdateScellUlDlMode()
{
    AUTO_TRACE_FUNC;
    
    const auto phInfo = GetPhInfo();
    VCCB_CHECK_E_RANGE_AND_VOID(phInfo.numItems, MAX_NR_OF_SERVING_CELLS);
    
    scellInfo_type *sCellMap[MAX_SCELL_INDEX] = {NULL, };

    for (auto &sCell : rCi.sCell)
    {
        if (sCell.state == SCELL_STATE_ADDED)
        {
            VCCB_CHECK_E_RANGE_AND_CONTINUE(sCell.sCellIndex, MAX_SCELL_INDEX);
            sCellMap[sCell.sCellIndex] = &sCell;
        }
    }

    uint32_t maxNumPhInfo = UMIN(phInfo.numItems, MAX_NR_OF_SERVING_CELLS);
    for (uint32_t phIdx = 0; phIdx < maxNumPhInfo; phIdx++)
    {
        uint16_t servCellIndex = phInfo.phInfoDU[phIdx].servCellIndex;
        VCCB_CHECK_E_RANGE_AND_CONTINUE(servCellIndex, MAX_SCELL_INDEX);
        if (sCellMap[servCellIndex] == NULL) continue;

        if (phInfo.phInfoDU[phIdx].ph_UL.ph_Type1or3 == NRRRC_ph_Type1or3_type1)
        {
            sCellMap[servCellIndex]->sCellUlDlMode = sCell_ulDlBoth;
        }
        else
        {
            sCellMap[servCellIndex]->sCellUlDlMode = sCell_dlOnly;
        }

        VCCB_PRINT_LOG_CA_CSL_FUNC(&rCi, "[CA_CSL] sCellIdx[%d] cgi[%lu] sCellUlDlMode[%s] updated !! \n",
            servCellIndex, sCellMap[servCellIndex]->cgi.ci,
            (sCellMap[servCellIndex]->sCellUlDlMode == sCell_ulDlBoth ? "BOTH" : "DLONLY"));
    }
}

void VonrSCellCslProcessor::SCellConfigCslInVoNRCount()
{
    AUTO_TRACE_FUNC;

    if (not ShouldCollectScellCSLInVoNR())
    {
        VCCB_PRINT_LOG_CA_CSL_FUNC(&rCi, "[CA_CSL] VoNR-related CSL count cannot be performed\n");
        return;
    }

    for (auto &sCell : rCi.sCell)
    {
        if (sCell.state == SCELL_STATE_ADDED && sCell.action == SCELL_ACTION_SETUP)
        {
            uint8_t idx = FnVCCB_GetSCellCslIndex(rCi, sCell);
            VCCB_CHECK_E_RANGE_AND_CONTINUE(idx, MAX_SCELL_CA_CSL);

            auto &sCellCsl = rCi.sCellCsl[idx];
            if (sCell.sCellUlDlMode == sCell_ulDlBoth)
            {
                sCellCsl.ulCaConfigVonrCnt++;
            }
            else
            {
                sCellCsl.dlCaConfigVonrCnt++;
            }

            sCellCsl.state = CSL_COLLECT_SUCCESS;
            memcpy(&sCellCsl.cslCgi, &sCell.cgi, sizeof(csl_cgi_type));
            sCellCsl.sCellIdx = sCell.sCellIndex;

            VCCB_PRINT_LOG_CA_CSL_FUNC(&rCi, "[CA_CSL] CSL Config Count Updated in VoNR !! \n");
            caCsllogPrint(rCi, idx, &sCell.sCellUlDlMode);
        }
    }
}

void VonrSCellCslProcessor::SCellDeConfigCslInVoNRCount()
{
    AUTO_TRACE_FUNC;

    if (not ShouldCollectScellCSLInVoNR())
    {
        VCCB_PRINT_LOG_CA_CSL_FUNC(&rCi, "[CA_CSL] VoNR-related CSL count cannot be performed \n");
        return;
    }

    auto GetRelScell = [&](auto sCellCsl) -> scellInfo_type *
    {
        for (auto &sCell : rCi.sCell)
        {
            if (sCell.state == SCELL_STATE_ADDED) continue;
            if (sCell.cgi.ci != sCellCsl.cslCgi.ci) continue;
            if (sCell.sCellIndex != sCellCsl.sCellIdx) continue;

            return &sCell;
        }
        return NULL;
    };

    
    for(uint8_t cslIdx = 0; cslIdx < MAX_SCELL_CA_CSL; cslIdx++)
    {
        auto &sCellCsl = rCi.sCellCsl[cslIdx];
        if (sCellCsl.state == CSL_COLLECT_ONGOING)
        {
            auto sCell = GetRelScell(sCellCsl);
            VALID_E_POINT_CHECK_CONTINUE(sCell);

            if (sCell->sCellUlDlMode == sCell_ulDlBoth)
            {
                sCellCsl.ulCaDeConfigVonrCnt++;
            }
            else
            {
                sCellCsl.dlCaDeConfigVonrCnt++;
            }

            VCCB_PRINT_LOG_CA_CSL_FUNC(&rCi, "[CA_CSL] CSL Deonfig Count Updated in VoNR !! \n");
            caCsllogPrint(rCi, cslIdx, &sCell->sCellUlDlMode);
        }
    }
}

void FnVCCB_InitScellUlDlModeOfScellSetupOngoing(scellInfo_type &sCell)
{
    AUTO_TRACE_FUNC;
    VonrSCellCslProcessor::InitScellUlDlMode(sCell);
}

void FnVCCB_ProcessScellCaCslUpdateForVonr(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    VonrSCellCslProcessor vonrCsl(*ptCi);
    vonrCsl.SCellDeConfigCslInVoNRCount();
    vonrCsl.UpdateScellUlDlMode();
    vonrCsl.SCellConfigCslInVoNRCount();
}

void FnVCCB_UpdateScellUlDlMode(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    VonrSCellCslProcessor vonrCsl(*ptCi);
    vonrCsl.UpdateScellUlDlMode();
}
