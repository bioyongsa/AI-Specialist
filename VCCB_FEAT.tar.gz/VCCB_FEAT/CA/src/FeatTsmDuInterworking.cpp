#include "FeatCa.hpp"
#include "FeatTsmDuInterworking.hpp"

#include "ComLibUtility.h"

#include <chrono>

namespace TsmDuInterworking
{
    using namespace std::chrono;

    typedef struct CandidateCellInfo_s
    {
        CellPci_type pci;
        uint16_t cellIdentity;

        bool operator==(const CandidateCellInfo_s& other) const
        {
            return ((this->pci == other.pci) &&
                    (this->cellIdentity == other.cellIdentity));
        }
    } CandidateCellInfo_type;

    inline constexpr uint8_t MAX_CELLNUMS_TO_CHECK = MAX_PCC_CANDIDATES + 1; // All PCC candidates + serving PCell
    inline constexpr uint16_t MAX_COLOCCELL_CELL_INFOS = MAX_CELLNUMS_TO_CHECK * MAX_COLOCCELL;

    using ColocCellInfoSet_type = staticUnorderedSet<CandidateCellInfo_type, MAX_COLOCCELL_CELL_INFOS>;
    using NbrCellInfoVec_type = simpleVector<CandidateCellInfo_type, MAX_NBR_PER_CELL * MAX_CELLNUMS_TO_CHECK>;
    using CellIdentityVec_type = simpleVector<uint16_t, MAX_PCC_CANDIDATES * MAX_NBR_PER_CELL>;
    using CellNumsToCheckVec_type = simpleVector<CellNum_type, MAX_PCC_CANDIDATES * MAX_NBR_PER_CELL>;
    using ServingAndPccCandidateCellNums_type = simpleVector<CellNum_type, MAX_CELLNUMS_TO_CHECK>;
    using AltCellNumsToCheckVec_type = std::vector<CellNum_type>;

    typedef struct AltCellNumData_s
    {
        AltCellNumsToCheckVec_type vec;
        bool alreadyBuilt = false;
        AltCellNumData_s()
        {
            vec.reserve(MAX_CELL_NUM_VCCB);
            alreadyBuilt = false;
        }
    } AltCellNumData_type;

    typedef struct NbrCellInfoData_s
    {
        NbrCellInfoVec_type infoVec;
        bool alreadyAttempted = false;
    } NbrCellInfoData_type;

    nanoseconds FnVCCB_TimespecToNanos(const timespec& rTimespec)
    {
        return nanoseconds(seconds(rTimespec.tv_sec)) + nanoseconds(rTimespec.tv_nsec);
    }

    timespec FnVCCB_GetCurrentTimestamp()
    {
        AUTO_TRACE_FUNC;

        // Assertion that the system_clock provided by std::chrono is in nanoseconds
        static_assert(system_clock::period::num == std::nano::num);
        static_assert(system_clock::period::den == std::nano::den);

        const time_point now = system_clock::now();
        const time_point nsecs = now - 
            duration_cast<nanoseconds>(duration_cast<seconds>(now.time_since_epoch()));
        return timespec {
            .tv_sec = system_clock::to_time_t(now),
            .tv_nsec = nsecs.time_since_epoch().count()
        };
    }

    inline bool FnVCCB_IsResultForServingCell(const measResult2NR_type& rResultForFrequency)
    {
        return (rResultForFrequency.measResultServingCell_Flag &&
                rResultForFrequency.measResultServingCell.physCellIdFlag &&
                rResultForFrequency.measResultServingCell.cellResults.resultsSSB_CellFlag &&
                rResultForFrequency.measResultServingCell.cellResults.resultsSSB_Cell.rsrpFlag);
    }

    void FnVCCB_InvalidateOldMrCellInfoEntries(callInfo_type& rCall, const timespec& rTimestamp, const int64_t timerLength)
    {
        AUTO_TRACE_FUNC;

        const milliseconds timerInMillis = milliseconds(timerLength);
        const milliseconds tsInMillis = duration_cast<milliseconds>(FnVCCB_TimespecToNanos(rTimestamp));
        for (mrCellInfo_type &rMrCellInfo: rCall.mrCellInfo)
        {
            if (rMrCellInfo.state != mrCellState_Enable)
            {
                continue;
            }

            const milliseconds rxInMillis = duration_cast<milliseconds>(FnVCCB_TimespecToNanos(rMrCellInfo.receivedTime));
            if ((tsInMillis - rxInMillis) > timerInMillis)
            {
                rMrCellInfo.cellIdentity = MAX_CELL_IDENTITY;
                rMrCellInfo.state = mrCellState_Disable;
            }
        }
    }

    std::size_t FnVCCB_GetIdx(const callInfo_type& rCall, const uint16_t cellIdentity)
    {
        AUTO_TRACE_FUNC;

        const auto beginIt = std::cbegin(rCall.mrCellInfo);
        const auto endIt = std::cend(rCall.mrCellInfo);

        auto disabledIt = endIt;
        auto oldestIt = endIt;
        nanoseconds oldestTimestamp = nanoseconds::max();

        for (auto it = beginIt; it < endIt; it++)
        {
            if ((mrCellState_Disable != it->state) && (cellIdentity == it->cellIdentity))
            {
                return static_cast<std::size_t>(std::distance(beginIt, it));
            }

            if (disabledIt != endIt)
            {
                continue;
            }

            if (mrCellState_Disable == it->state)
            {
                disabledIt = it;
                continue;
            }

            const nanoseconds tsInNanos = FnVCCB_TimespecToNanos(it->receivedTime);
            if (tsInNanos < oldestTimestamp)
            {
                oldestIt = it;
                oldestTimestamp = tsInNanos;
            }
        }
        
        if (disabledIt != endIt)
        {
            return static_cast<std::size_t>(std::distance(beginIt, disabledIt));
        }
        return static_cast<std::size_t>(std::distance(beginIt, oldestIt));
    }

    void FnVCCB_AssignMrCellInfo(
            callInfo_type& rCall,
            const VccbGnbInfo_type& rServingGnb,
            const uint16_t cellIdentity,
            const timespec& rTimestamp,
            const uint8_t rsrp)
    {
        AUTO_TRACE_FUNC;

        const std::size_t firstFreeIndex = FnVCCB_GetIdx(rCall, cellIdentity);
        if (MAX_TSM_MR_CELL <= firstFreeIndex)
        {
            VCCB_PRINT_CALL_ERROR(&rCall,
                    "[TSM DU IW] ERROR: MAX_TSM_MR_CELL(%d) <= firstFreeIndex(%lu)!\n", MAX_TSM_MR_CELL, firstFreeIndex);
            return;
        }

        VCCB_CHECK_E_RANGE_AND_VOID(cellIdentity, MAX_CELL_IDENTITY);
        const CellNum_type cellNum = rServingGnb.env.cellNum[cellIdentity];

        rCall.mrCellInfo[firstFreeIndex].cellIdentity = cellIdentity;
        rCall.mrCellInfo[firstFreeIndex].state = mrCellState_Enable;
        rCall.mrCellInfo[firstFreeIndex].receivedTime = rTimestamp;
        rCall.mrCellInfo[firstFreeIndex].rsrp = rsrp;
#if defined(NEW_HOST_SIM) && !defined(IPC_TEST)
        rCall.mrCellInfo[firstFreeIndex].seValue = static_cast<uint32_t>(FnVCCB_GetTsmValueSEMock(rCall, cellNum, rsrp) * 1000.00);
#else
        rCall.mrCellInfo[firstFreeIndex].seValue = static_cast<uint32_t>(FnVCCB_GetTsmValueSE(&rCall, cellNum, rsrp) * 1000.00);
#endif
    }

    ServingAndPccCandidateCellNums_type FnVCCB_GetCellNumsToCheck(const callInfo_type& rCall)
    {
        AUTO_TRACE_FUNC;

        ServingAndPccCandidateCellNums_type cellNumsToCheck {rCall.servCellNum};
        for (const PccCandidateInfo_type& rCandidate: rCall.pccData.candidate)
        {
            if (MAX_CELL_NUM_VCCB != rCandidate.cellNum)
            {
                cellNumsToCheck.push_back(rCandidate.cellNum);
            }
        }
        return cellNumsToCheck;
    }

    void FnVCCB_BuildColocCellInfoForServingAndPccCandidates(
            const callInfo_type& rCall,
            const VccbGnbInfo_type& rServingGnb,
            const Arfcn_type targetSsbArfcn,
            const ServingAndPccCandidateCellNums_type& rServingCellAndPccCandidateCellNums,
            ColocCellInfoSet_type& rColocCellInfosOut)
    {
        AUTO_TRACE_FUNC;

        for (const CellNum_type cellNum: rServingCellAndPccCandidateCellNums)
        {
            const VccbCellInfo_type& rCell = CELLINFO[cellNum];
            if (!rCell.cuColocCellInfo.colocCellInfoUsage)
            {
                VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "cellNum(%u) has colocCellInfoUsage(%u), skipping!\n",
                        cellNum, rCell.cuColocCellInfo.colocCellInfoUsage);
                continue;
            }

            // useForNrca is not checked intentionally, it is not known whether MR is for PCell or SCell
            // see PCC Change - PCell has no check, Scell has a check
            for (const colocCellEntries_type& rColocCell: rCell.cuColocCellInfo.colocCellEntries)
            {
                if (!rColocCell.usage)
                {
                    continue;
                }

                if (!VCCB_IS_SAME_GNB(rColocCell.globalGnbId.gnbId.id, rColocCell.globalGnbId.plmn.longId, rCall.gnbNum))
                {
                    VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "Coloc cell cellIdentity(%u) is inter-gNB coloc of cellNum(%u), skipping!\n",
                            rColocCell.cellId, cellNum);
                    continue;
                }

                VCCB_CHECK_E_RANGE_AND_CONTINUE(rColocCell.cellId, MAX_CELL_IDENTITY);
                const CellNum_type colocCellCellNum = rServingGnb.env.cellNum[rColocCell.cellId];
                VCCB_CHECK_E_RANGE_AND_CONTINUE(colocCellCellNum, MAX_CELL_NUM_VCCB);
                const VccbCellInfo_type& rColocCellCellInfo = CELLINFO[colocCellCellNum];
                if (rColocCellCellInfo.ssbArfcn != targetSsbArfcn)
                {
                    continue;
                }


                VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "Added PCI(%u) cellIdentity(%u) - coloc cell of cellNum(%u)!\n",
                        rColocCellCellInfo.phyCellId, rColocCellCellInfo.cellIdentity, cellNum);
                rColocCellInfosOut.insert(
                        {
                        .pci = rColocCellCellInfo.phyCellId,
                        .cellIdentity = rColocCellCellInfo.cellIdentity
                        });
            }
        }
    }

    std::optional<uint16_t> FnVCCB_TryToFindCellIdentityInServingCells(
            const callInfo_type& rCall,
            const VccbCellInfo_type& rServingCell,
            const uint8_t servingGnbIdLength,
            const measResult2NR_type& rResultForFrequency)
    {
        AUTO_TRACE_FUNC;

        std::optional<uint16_t> cellIdentity {std::nullopt};
        if ((rServingCell.phyCellId == rResultForFrequency.measResultServingCell.physCellId) &&
                (rServingCell.ssbArfcn == rResultForFrequency.ssbFrequency))
        {
            cellIdentity = VLIB_NrCellId2CellId(servingGnbIdLength, rCall.nRCGI.ci);
            VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "PCI(%u) ssbArfcn(%u) found as serving Pcell cellIdentity(%u)!\n",
                    rServingCell.phyCellId, rServingCell.ssbArfcn, cellIdentity.value());
        }
        else
        {
            for (const scellInfo_type& rScell: rCall.sCell)
            {
                if (SCELL_STATE_ADDED != rScell.state)
                {
                    continue;
                }

                if ((rScell.pci != rResultForFrequency.measResultServingCell.physCellId) ||
                        ((rScell.ssbArfcn != rResultForFrequency.ssbFrequency)))
                {
                    continue;
                }

                const uint32_t scellGnbId = VLIB_NrCellId2GnbId(rScell.gnbIdLength, rScell.cgi.ci);
                if (!VCCB_IS_SAME_GNB(scellGnbId, rScell.cgi.plmn.longId, rCall.gnbNum))
                {
                    VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "Scell PCI(%u) ssbArfcn(%u) is inter-gNB, skipping!\n",
                            rScell.pci, rScell.ssbArfcn);
                    continue;
                }
                cellIdentity = VLIB_NrCellId2CellId(servingGnbIdLength, rScell.cgi.ci);
                VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "PCI(%u) ssbArfcn(%u) found as serving Scell cellIdentity(%u)!\n",
                        rScell.pci, rScell.ssbArfcn, cellIdentity.value());
                break;
            }
        }
        return cellIdentity;
    }

    void FnVCCB_BuildNbrCellInfoVecForServingAndPccCandidates(
            const callInfo_type& rCall,
            const VccbGnbInfo_type& rServingGnb,
            const Arfcn_type targetSsbArfcn,
            const ServingAndPccCandidateCellNums_type& rServingCellAndPccCandidateCellNums,
            NbrCellInfoData_type& rNbrCellDataOut)
    {
        AUTO_TRACE_FUNC;

        NbrCellInfoVec_type& rNbrCellInfos = rNbrCellDataOut.infoVec;
        for (const CellNum_type cellNum: rServingCellAndPccCandidateCellNums)
        {
            const VccbCellInfo_type& rCell = CELLINFO[cellNum];
            for (uint16_t nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)
            {
                if (N_EQUIP == rCell.Nbr[nbrIdx].status)
                {
                    continue;
                }

                if (!VCCB_IS_INTRA_GNB_NEIGHBOR(cellNum, nbrIdx))
                {
                    VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "Nbr cell cellIdentity(%u) is inter-gNB nbr of cellNum(%u), skipping!\n",
                            rCell.Nbr[nbrIdx].targetCellId, cellNum);
                    continue;
                }

                VCCB_CHECK_E_RANGE_AND_CONTINUE(rCell.Nbr[nbrIdx].targetCellId, MAX_CELL_IDENTITY);
                const CellNum_type nbrCellNum = rServingGnb.env.cellNum[rCell.Nbr[nbrIdx].targetCellId];
                VCCB_CHECK_E_RANGE_AND_CONTINUE(nbrCellNum, MAX_CELL_NUM_VCCB); 
                const VccbCellInfo_type& rNbrCell = CELLINFO[nbrCellNum];
                if (rNbrCell.ssbArfcn != targetSsbArfcn)
                {
                    continue;
                }

                VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "Added nbrIdx(%u) PCI(%u) cellIdentity(%u) - nbr cell of cellNum(%u)!\n",
                        nbrIdx, rNbrCell.phyCellId, rNbrCell.intraGnbNbrInfo.cellId, cellNum);
                rNbrCellInfos.push_back(
                        {
                        .pci = rNbrCell.phyCellId,
                        .cellIdentity = rNbrCell.intraGnbNbrInfo.cellId
                        });
            }
        }
        rNbrCellDataOut.alreadyAttempted = true;
    }

    void FnVCCB_TryToFindCellIdentitiesInColocsAndNbrs(
            const callInfo_type& rCall,
            const VccbGnbInfo_type& rServingGnb,
            const ColocCellInfoSet_type& rColocCellInfos,
            const Arfcn_type ssbFrequency,
            const CellPci_type pci,
            const ServingAndPccCandidateCellNums_type& rServingCellAndPccCandidateCellNums,
            NbrCellInfoData_type& rNbrCellInfoData,
            CellIdentityVec_type& rCellIdentitiesOut)
    {
        AUTO_TRACE_FUNC;

        // Find the appropriate cell identity in colocs
        for (const CandidateCellInfo_type& rColocCellInfo: rColocCellInfos)
        {
            if (rColocCellInfo.pci == pci)
            {
                VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "Match - found PCI(%u) ssbFreq(%u) cellIdentity(%u) in aggregated coloc cells!\n",
                        pci, ssbFrequency, rColocCellInfo.cellIdentity);
                rCellIdentitiesOut.push_back(rColocCellInfo.cellIdentity);
            }
        }

        if (rCellIdentitiesOut.size() > 0)
        {
            return;
        }

        if (!rNbrCellInfoData.alreadyAttempted)
        {
            FnVCCB_BuildNbrCellInfoVecForServingAndPccCandidates(rCall,
                rServingGnb, ssbFrequency, rServingCellAndPccCandidateCellNums, rNbrCellInfoData);
        }

        for (const CandidateCellInfo_type& rNbr: rNbrCellInfoData.infoVec)
        {
            if (rNbr.pci == pci)
            {
                VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "Match - found PCI(%u) ssbFreq(%u) cellIdentity(%u) in aggregated nbr cells!\n",
                        pci, ssbFrequency, rNbr.cellIdentity);
                rCellIdentitiesOut.push_back(rNbr.cellIdentity);
            }
        }
    }

    void FnVCCB_GetAllIntraGnbCellNumsForFrequency(
            const callInfo_type& rCall,
            const VccbCellInfo_type& rServingCell,
            const Arfcn_type targetFrequency,
            AltCellNumData_type& rAltCellNumDataOut)
    {
        AUTO_TRACE_FUNC;

        for (CellNum_type cellNum = 0; cellNum < MAX_CELL_NUM_VCCB; cellNum++)
        {
            const VccbCellInfo_type& rIntraCell = CELLINFO[cellNum];
            if ((EQUIP != rIntraCell.status) ||
                    (targetFrequency != rIntraCell.ssbArfcn) ||
                    (rServingCell.gnbNum != rIntraCell.gnbNum)) // exclude inter gNB cells
            {
                continue;
            }
            VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "Added PCI(%u) ssbFreq(%u) cellIdentity(%u) to intra-gNB cells!\n",
                    rIntraCell.phyCellId, rIntraCell.ssbArfcn, rIntraCell.intraGnbNbrInfo.cellId);
            rAltCellNumDataOut.vec.push_back(cellNum); 
        }
        rAltCellNumDataOut.alreadyBuilt = true;
    }

    void FnVCCB_TryToFindCellIdentitiesForPotentialAltCells(
            const callInfo_type& rCall,
            const CellPci_type targetPci,
            const AltCellNumsToCheckVec_type& rAltCellNumList,
            CellIdentityVec_type& rCellIdentitiesOut)
    {
        AUTO_TRACE_FUNC;
        
        for (const CellNum_type cellNum: rAltCellNumList)
        {
            VCCB_CHECK_E_RANGE_AND_CONTINUE(cellNum, MAX_CELL_NUM_VCCB);
            const VccbCellInfo_type& candidateCell = CELLINFO[cellNum];
            if (candidateCell.phyCellId == targetPci)
            {
                VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "Match - found PCI(%u) ssbFreq(%u) cellIdentity(%u) in aggregated intra-gNB cells!\n",
                        targetPci, candidateCell.ssbArfcn, candidateCell.cellIdentity);
                rCellIdentitiesOut.push_back(candidateCell.cellIdentity);
            }
        }
    }

    void FnVCCB_ProcessMeasurementReport(
            callInfo_type& rCall,
            const enumMeasurementReportType reportType,
            const int reportPurpose,
            const measurementObjectUe_type& rMO)
    {
        AUTO_TRACE_FUNC;

        VCCB_CHECK_VALID_CELLNUM_VOID(rCall.servCellNum);
        VCCB_CHECK_VALID_GNBNUM_VOID(rCall.gnbNum);
        VCCB_CHECK_E_RANGE_AND_VOID(rCall.myThreadId, MAX_CALL_THREAD_NUM_VCCB);

        if (rMO.conf.ratType != measRatNr)
        {
            VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "Skipping MR processing - EUTRA MO!\n");
            return;
        }

        if ((reportType == measReport_B1Eutra) ||
                (reportType == measReport_B2Eutra) ||
                (reportType == measReport_periodicalInterRat) ||
                (reportType == measReport_reportCGIEutra))
        {
            VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "Skipping MR processing - EUTRA Measurement Report type!\n");
            return;
        }

        const VccbCellInfo_type& rServingCell = CELLINFO[rCall.servCellNum];
        const VccbGnbInfo_type& rServingGnb = GNBINFO[rCall.gnbNum];
        const bool isMrdcSn = IS_MRDC_SN(&rCall);
        
        if (!rServingGnb.carrierAggregationInfo.f1SeUsage ||
                (!rServingGnb.multiCarrierOperation.capabilityAwareCarrierChange && !rServingGnb.multiCarrierOperation.sccChange) ||
                (rServingCell.tsmConfig.state != tsmState_Enable) ||  // TO DO verify this condition, maybe should be tsmConfig.state == tsmState_Disable?
                isMrdcSn)
        {
            VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "Skipping MR processing - f1-se-usage-condition(%u), pcc(%u)/scc(%u), tsmState(%u), isMrdcSn(%u)!\n",
                    0U, rServingGnb.multiCarrierOperation.capabilityAwareCarrierChange, rServingGnb.multiCarrierOperation.sccChange,
                    rServingCell.tsmConfig.state, isMrdcSn);
            return;
        }

        const timespec currentTimestamp = FnVCCB_GetCurrentTimestamp();
        FnVCCB_InvalidateOldMrCellInfoEntries(
                rCall,
                currentTimestamp,
                std::max(rServingGnb.multiCarrierOperation.mrGatheringTimer, rServingGnb.multiCarrierOperation.sccMrGatheringTimer));

        const measResultList2NR_type& rMeasResults =
            THREAD_INFO->call[rCall.myThreadId].buf.measResultList2NRRx.candidateCellInfoListSN;

        NbrCellInfoData_type nbrCellInfos {};
        const uint8_t servingGnbIdLength = rServingGnb.globalGnbId.gnbId.idLength;
        for (uint8_t freqIndex = 0; freqIndex < rMeasResults.nrofFreq; freqIndex++)
        {
            const measResult2NR_type& rResultForFrequency = rMeasResults.measResult2NR[freqIndex];
            if (!rResultForFrequency.ssbFrequency_Flag)
            {
                VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "Skipping freqIndex(%u) - no ssbFrequency!\n", freqIndex);
                continue;
            }

            // Try to look the result up in serving cells
            if (FnVCCB_IsResultForServingCell(rResultForFrequency))
            {
                std::optional<uint16_t> cellIdentity = FnVCCB_TryToFindCellIdentityInServingCells(
                        rCall,
                        rServingCell,
                        servingGnbIdLength,
                        rResultForFrequency);

                if (cellIdentity)
                {
                    FnVCCB_AssignMrCellInfo(
                            rCall,
                            rServingGnb,
                            cellIdentity.value(),
                            currentTimestamp,
                            static_cast<uint8_t>(rResultForFrequency.measResultServingCell.cellResults.resultsSSB_Cell.rsrp));
                }
                else
                {
                    VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "Serving cell report for PCI(%u) ssbFreq(%u) NOT found in serving cells!\n",
                            rResultForFrequency.measResultServingCell.physCellId, rResultForFrequency.ssbFrequency);
                }
            }
            
            // If neither the serving cell nor the candidates have coloc cells, this will be empty
            const measResultListNR_type& rNbrResults = rResultForFrequency.measResultNeighCellListNR;
            if ((rNbrResults.nrofCellReport > 0) &&
                (rResultForFrequency.ssbFrequency == rMO.conf.rat.nr.minimal.ssbFrequency))
            {
                AltCellNumData_type altCellNumInfo {};
                ColocCellInfoSet_type colocCellInfos {};
                const ServingAndPccCandidateCellNums_type servingCellAndPccCandidateCellNums {FnVCCB_GetCellNumsToCheck(rCall)};
                FnVCCB_BuildColocCellInfoForServingAndPccCandidates(
                        rCall, rServingGnb, rResultForFrequency.ssbFrequency, servingCellAndPccCandidateCellNums, colocCellInfos);

                CellIdentityVec_type cellIdentities {};
                for (uint8_t resultIndex = 0; resultIndex < rNbrResults.nrofCellReport; resultIndex++)
                {
                    cellIdentities.clear();
                    const measResultNR_type& rResult = rNbrResults.measResultNR[resultIndex];
                    // There's no way for us to find a cell without PCI
                    if (!rResult.physCellIdFlag)
                    {
                        VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "Skipping nbr resultIndex(%u) - no PCI!\n", resultIndex);
                        continue;
                    }

                    // Skipped because PCC skips these
                    // See FnVCCB_getNbrIdxIfPccCandidateMeasured in StateMco.cpp
                    if (rResult.isBestNbrResultFlag)
                    {
                        VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "Skipping nbr resultIndex(%u) - bestNbrFlag!\n", resultIndex);
                        continue;
                    }

                    // No viable results, skip
                    if (!rResult.cellResults.resultsSSB_CellFlag)
                    {
                        VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "Skipping nbr resultIndex(%u) - no SSB results!\n", resultIndex);
                        continue;
                    }

                    // No RSRP, can't calculate SE value
                    if (!rResult.cellResults.resultsSSB_Cell.rsrpFlag)
                    {
                        VCCB_PRINT_LOG_TSM_DU_IW(&rCall, "Skipping nbr resultIndex(%u) - no RSRP!\n", resultIndex);
                        continue;
                    }

                    FnVCCB_TryToFindCellIdentitiesInColocsAndNbrs(
                            rCall,
                            rServingGnb,
                            colocCellInfos,
                            rResultForFrequency.ssbFrequency,
                            rResult.physCellId,
                            servingCellAndPccCandidateCellNums,
                            nbrCellInfos,
                            cellIdentities);

                    for (const uint16_t cellId: cellIdentities)
                    {
                        FnVCCB_AssignMrCellInfo(
                                rCall,
                                rServingGnb,
                                cellId,
                                currentTimestamp,
                                static_cast<uint8_t>(rResult.cellResults.resultsSSB_Cell.rsrp));
                    }

                    // Last attempt, try to find potential alt cells
                    if (cellIdentities.empty() &&
                        (reportType == measReport_A5) &&
                        (reportPurpose == a5Purpose_CapabilityAwareCarrierChange))
                    {
                        if (!altCellNumInfo.alreadyBuilt)
                        {
                            FnVCCB_GetAllIntraGnbCellNumsForFrequency(
                                    rCall,
                                    rServingCell,
                                    rResultForFrequency.ssbFrequency,
                                    altCellNumInfo);
                        }

                        FnVCCB_TryToFindCellIdentitiesForPotentialAltCells(
                                rCall,
                                rResult.physCellId,
                                altCellNumInfo.vec,
                                cellIdentities);

                        for (const uint16_t cellId: cellIdentities)
                        {
                            FnVCCB_AssignMrCellInfo(
                                    rCall,
                                    rServingGnb,
                                    cellId,
                                    currentTimestamp,
                                    static_cast<uint8_t>(rResult.cellResults.resultsSSB_Cell.rsrp));
                        }
                    }
                }
            }
        }
    }
} // namespace TsmDuInterworking
