#include "SccA4MrManager.hpp"
#include "ComInclude.h"
#include "ComLibUtility.h"
#include "FeatCa.hpp"
#include "FeatMeasurements.hpp"

SccA4MrManager:: SccA4MrManager( callInfo_type &_mCallInfo, const nbrGnbCellInfo_type &_mTgtNbrGnbCell,
    const measResultList2NR_type &_mMeasResults, const measurementObjectUe_type &_mMeasObj,
    const reportConfigurationInstalledUe_type &_mReportConfig ) : mCallInfo(_mCallInfo), mTgtNbrGnbCell(_mTgtNbrGnbCell), mMeasResults(_mMeasResults), mMeasObj(_mMeasObj), mReportConfig(_mReportConfig)
{
    memset(&mTgtCgi, 0x0, sizeof(cgi_type));
}

bool SccA4MrManager::checkTriggerSccChange()
{
    AUTO_TRACE_FUNC;
    return mCallInfo.sccData.a4MrSetAndReceived == 0 && mCallInfo.state == STATE_Conn;
}

int16_t SccA4MrManager::sCellInfoUpdate()
{
    AUTO_TRACE_FUNC;
    if (not this->isGatheringState())
    {
        VCCB_PRINT_LOG_MCO_SCC(&mCallInfo, "[SCC] state = %d, sccGatheringTimer.id = %d !! A4 MR skip \n",
            mCallInfo.sccData.state, mCallInfo.sccData.sccGatheringTimer.id);
        return BREAK;
    }

    uint16_t scellIdx = this->findScellIdxForSsbFrequencyOfReceivedMr();
    if (scellIdx < MAX_SCELL_PER_CALL)
    {
        this->updateSccInfo(scellIdx);
        this->changeSccState(mCallInfo.sCell[scellIdx]);
        return GOOD;
    }

    return BREAK;
}

uint16_t SccA4MrManager::findScellIdxForSsbFrequencyOfReceivedMr()
{
    AUTO_TRACE_FUNC;

    uint32_t ssbFrequency = VCCB_GetMeasObjectSsbFreq(mMeasObj);
    for (uint16_t idx = 0; idx < MAX_SCELL_PER_CALL; idx++)
    {
        if (mCallInfo.sCell[idx].state == SCELL_STATE_MRREL && mCallInfo.sCell[idx].action == SCELL_ACTION_KEEP)
        {
            if (mCallInfo.sCell[idx].ssbArfcn == ssbFrequency)
            {
                return idx;
            }
        }
    }

    VCCB_PRINT_LOG_MCO_SCC(&mCallInfo, "[SCC] Not Found pMeasObj (ssbFrequency : %u) !! A4 MR skip \n", ssbFrequency);
    return MAX_SCELL_PER_CALL;
}

void SccA4MrManager::changeOnlySccCellMeasured(uint16_t scellIdx)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(scellIdx, MAX_SCELL_PER_CALL);

    if (mCallInfo.sCell[scellIdx].sccFlag_cellMeasured == FALSE)
    {
        mCallInfo.sCell[scellIdx].sccFlag_cellMeasured = TRUE;
        OFFBIT_U32(mCallInfo.sccData.a4MrSetAndReceived, scellIdx);
    }

    VCCB_PRINT_LOG_MCO_SCC(&mCallInfo,
       "[SCC] A4 MR received (purpose(%d)/scellIdx(%d)/objIdx(%d)/ssbFrequency(%d)/pci(%d)) \n",
        mReportConfig.conf.reportPurpose, scellIdx, mMeasObj.objectId, mCallInfo.sCell[scellIdx].ssbArfcn,
        mCallInfo.sCell[scellIdx].pci);
}

void SccA4MrManager::changeToNewSccCell(uint16_t scellIdx)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(scellIdx, MAX_SCELL_PER_CALL);

    uint16_t scellAltBandNr = BAND_NOT_FOUND;
    for (uint8_t scellAltBandIdx = 0; scellAltBandIdx < MAX_MCO_MFBI_CELLS; ++scellAltBandIdx)
    {
        scellAltBandNr = VLIB_GetAlternativeNrBand(&mCallInfo, &mTgtNbrGnbCell, scellIdx, scellAltBandIdx);
        if (scellAltBandNr != BAND_NOT_FOUND) break;
    }

    VLIB_FillNewScellInfo(mCallInfo, mCallInfo.sCell[scellIdx], mTgtCgi, mTgtNbrGnbCell.globalGnbId.gnbId.idLength, scellAltBandNr);

    mCallInfo.sCell[scellIdx].sccFlag_cellMeasured = TRUE;
    OFFBIT_U32(mCallInfo.sccData.a4MrSetAndReceived, scellIdx);

    VCCB_PRINT_LOG_MCO_SCC(&mCallInfo,
        "[SCC] A4 MR received (purpose(%d)/scellIdx(%d)/objIdx(%d)/ssbFrequency(%d)/pci(%d)) \n",
        mReportConfig.conf.reportPurpose, scellIdx, mMeasObj.objectId, mCallInfo.sCell[scellIdx].ssbArfcn,
        mCallInfo.sCell[scellIdx].pci);
}

bool SccA4MrManager::checkNotChangeScellInfo(uint16_t scellIdx)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(scellIdx, MAX_SCELL_PER_CALL, false);

    mTgtCgi.ci = VLIB_GnbIdCellId2NrCellId(&mTgtNbrGnbCell.globalGnbId.gnbId, mTgtNbrGnbCell.cellId);
    mTgtCgi.plmn.longId = mTgtNbrGnbCell.globalGnbId.plmn.longId;
    return ((mTgtCgi.ci == mCallInfo.sCell[scellIdx].cgi.ci) &&
            (mTgtCgi.plmn.longId == mCallInfo.sCell[scellIdx].cgi.plmn.longId));
}

void SccA4MrManager::updateSccInfo(uint16_t scellIdx)
{
    AUTO_TRACE_FUNC;

    if (checkNotChangeScellInfo(scellIdx))
    {
        this->changeOnlySccCellMeasured(scellIdx);
    }
    else
    {
        this->changeToNewSccCell(scellIdx);
    }
}

void SccA4MrManager::changeSccState(scellInfo_type &scell)
{
    AUTO_TRACE_FUNC;

    scell.state = SCELL_STATE_MRREL;
    scell.action = SCELL_ACTION_KEEP;
}

bool SccA4MrManager::isGatheringState()
{
    AUTO_TRACE_FUNC;

    if (mCallInfo.sccData.state != SCC_Gathering || mCallInfo.sccData.sccGatheringTimer.id <= 0)
    {
        return false;
    }
    return true;
}
