#include "FeatNrdcMnBcReselection.hpp"

BcInfo::BcInfo(callInfo_type *_ptCi):ptCi(_ptCi)
{
    memset(&keyWithFs, 0, sizeof(bandCombinationValue_type));
    memset(&keyWithoutFs, 0, sizeof(bandCombinationValue_type));
    memset(&ueBc, 0, sizeof(BandCombination_type));
    memset(&ueFsComb, 0, sizeof(MrdcFeatureSetCombination_type));
}
BcInfo::~BcInfo(){}

bool BcInfo::getUeBc(const uint32_t bcIdx, const bandCombinationList_type *ptUeBandCombList,
    const MrdcFeatureSetCombinationList_type *ptFeatureSetBcList)
{
    VALID_E_POINT_CHECK_RET_VAL(ptUeBandCombList, false);
    VALID_E_POINT_CHECK_RET_VAL(ptFeatureSetBcList, false);
    VCCB_CHECK_E_RANGE_AND_VAL(bcIdx, MAX_BAND_COMBS, false);
    
    ueBc = ptUeBandCombList->bandCombination[bcIdx];
    
    VCCB_CHECK_E_RANGE_AND_VAL(ueBc.featureSetCombination, MAX_MRDC_FS_COMBS, false);
    ueFsComb = ptFeatureSetBcList->mrdcFeatureSetCombination[ueBc.featureSetCombination];

    return true;
}

bool BcInfo::keyMake(uint32_t featureSetEntryIdx, bandCombinationValue_type& targetKey)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false)
    
    if (ueBc.num != ueFsComb.num)
    {
        VCCB_PRINT_LOG_MN_BC_RESELECTION(
            ptCi, "[MN_BC_RESELCTION] numBand in BandCombination and numBand in FeatureSetCombination are not same.\n");
            return false;
    }

    memset(&targetKey, 0, sizeof(bandCombinationValue_type));
    uint32_t maxNumBand = UMIN(ueBc.num, MAX_BANDS_PER_COMB);
    uint16_t numFR2Band = 0;

    for (uint32_t bandIdx = 0; bandIdx < maxNumBand && numFR2Band < maxNumBand; bandIdx++)
    {
        auto &keyValue = targetKey.bandParamKeyValue[numFR2Band];
        auto &ueBand = ueBc.band[bandIdx];  
        
        if (ueBand.freqBandIndicator <= MAX_FR1_NR_BAND) continue;

        keyValue.bandIndicator = ueBand.freqBandIndicator;
        keyValue.bandClassDl = ueBand.nrCaBandwidthClassDL;
        keyValue.bandClassUl = ueBand.nrCaBandwidthClassUL;
        keyValue.dlSetId = 0;
        keyValue.ulSetId = 0;

        if (featureSetEntryIdx < MAX_NUM_FEATURESETSPERBAND)
        {
            const MrdcFeatureSetPerBand_type featureSetPerBand = ueFsComb.featureSetPerBand[bandIdx];
            keyValue.dlSetId = featureSetPerBand.featureSet[featureSetEntryIdx].dlSetId;
            keyValue.ulSetId = featureSetPerBand.featureSet[featureSetEntryIdx].ulSetId;
        }
        numFR2Band++;
    }

    targetKey.noOfBandParam = numFR2Band;
    std::sort(targetKey.bandParamKeyValue, targetKey.bandParamKeyValue + targetKey.noOfBandParam,
        [](const bandParametersKeyValue_type &lhs, const bandParametersKeyValue_type &rhs)
        { return (lhs.keyValue < rhs.keyValue); });

    return true;
}

bool BcInfo::makeKeyInternal(uint32_t fsEntryIdx, bandCombinationValue_type& targetKey)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    bool KeyMakeSuccess = keyMake(fsEntryIdx, targetKey);
    if (not KeyMakeSuccess)
    {
        VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi, "[MN_BC_RESELCTION] selectedBandCombination keyValue is wrong \n");
        return false;
    }
    return true;
}

bool BcInfo::makeWithFsKey(uint32_t fsEntryIdx)
{
    VCCB_CHECK_E_RANGE_AND_VAL(fsEntryIdx, MAX_NUM_FEATURESETSPERBAND, false);
    return makeKeyInternal(fsEntryIdx, keyWithFs);
}

bool BcInfo::makeWithoutFsKey()
{
    return makeKeyInternal(MAX_NUM_FEATURESETSPERBAND, keyWithoutFs);
}

bool BcInfo::compareKeyValueForFr2Band(
    callInfo_type *ptCi, const bandCombinationValue_type selectedBcKey, const bandCombinationValue_type targetBcKey)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    if (selectedBcKey.noOfBandParam != targetBcKey.noOfBandParam)
    {
        VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi,
            "[MN_BC_RESELCTION] selectedBc numFR2Band(%d) and targetBc numFR2Band(%d) are different.\n",
            selectedBcKey.noOfBandParam, targetBcKey.noOfBandParam);
        return false;
    }

    uint32_t maxBandNum = UMIN(targetBcKey.noOfBandParam, MAX_BANDS_PER_COMB);
    for (uint32_t bandIdx = 0; bandIdx < maxBandNum; bandIdx++)
    {
        if (selectedBcKey.bandParamKeyValue[bandIdx].keyValue != targetBcKey.bandParamKeyValue[bandIdx].keyValue)
        {
            VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi,
                "[MN_BC_RESELCTION] bandIdx(%d), selectedBcKey(%lu), targetBcKey(%lu) are different\n", bandIdx,
                selectedBcKey.bandParamKeyValue[bandIdx].keyValue, targetBcKey.bandParamKeyValue[bandIdx].keyValue);
            return false;
        }
    }

    return true;
}

bool BcInfo::compareUeBcForFr2Band(
    callInfo_type *ptCi, const BandCombination_type selectedUeBc, const BandCombination_type targetUeBc)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (selectedUeBc.caParametersNRDC_present == VCCB_FLAG_ON && targetUeBc.caParametersNRDC_present == VCCB_FLAG_ON)
    {
        if (memcmp(&selectedUeBc.caParametersNRDC, &targetUeBc.caParametersNRDC, sizeof(CA_ParametersNRDC)) != 0)
        {
            VCCB_PRINT_LOG_MN_BC_RESELECTION(
                ptCi, "[MN_BC_RESELCTION] caParametersNRDC IE of selectedBc and targetBc are different.\n");
            return false;
        }
    }
    else
    {
        VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi,
            "[MN_BC_RESELCTION] selectedUeBc.caParametersNRDC_present(%d), targetUeBc.caParametersNRDC_present(%d) "
            "different \n",
            selectedUeBc.caParametersNRDC_present, targetUeBc.caParametersNRDC_present);
        return false;
    }

    if (selectedUeBc.caParametersNRDC_v1630_present == targetUeBc.caParametersNRDC_v1630_present)
    {
        if (selectedUeBc.caParametersNRDC_v1630_present == VCCB_FLAG_ON &&
            targetUeBc.caParametersNRDC_v1630_present == VCCB_FLAG_ON)
        {
            if (memcmp(&selectedUeBc.caParametersNRDC_v1630, &targetUeBc.caParametersNRDC_v1630,
                    sizeof(CA_ParametersNRDC_v1630)) != 0)
            {
                VCCB_PRINT_LOG_MN_BC_RESELECTION(
                    ptCi, "[MN_BC_RESELCTION] caParametersNRDC_v1630 IE of selectedBc and targetBc are different.\n");
                return false;
            }
        }
    }
    else
    {
        VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi,
            "[MN_BC_RESELCTION] selectedUeBc.caParametersNRDC_v1630_present(%d), "
            "targetUeBc.caParametersNRDC_v1630_present(%d) different \n",
            selectedUeBc.caParametersNRDC_v1630_present, targetUeBc.caParametersNRDC_v1630_present);
        return false;
    }

    return true;
}

MnBCReselectionConditionChecker::~MnBCReselectionConditionChecker() {}
MnBCReselectionConditionChecker::MnBCReselectionConditionChecker(callInfo_type *_ptCi) : ptCi(_ptCi) {}

bool MnBCReselectionConditionChecker::isSelectedBcReceived()
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    return IS_ON_MRDC_XN_RCVINDICATOR_FLAG(selectedBC);
}

bool MnBCReselectionConditionChecker::isScellActionChanged()
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    for (auto &sCell : ptCi->sCell)
    {
        if (sCell.action != SCELL_ACTION_KEEP)
        {
            return true;
        }
    }

    return false;
}

bool MnBCReselectionConditionChecker::isMnBcReselectionAvailable()
{
    AUTO_TRACE_FUNC;
    
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);

    if (not IS_MRDC_MN(ptCi))
    {
        VCCB_PRINT_LOG_MN_BC_RESELECTION(
            ptCi, "[MN_BC_RESELCTION] mnBcReselection is not active because it is not NR-DC MN Call\n");
        return false;
    }

    if (ptCi->bitFlag.mnBcReselectionFeatureOn == FALSE)
    {
        VCCB_PRINT_LOG_MN_BC_RESELECTION(
            ptCi, "[MN_BC_RESELCTION] mnBcReselection is not active because of mnBcReselection is off.\n");
        return false;
    }

    if (not IS_NOT_MRDC_SCG_RELEASE_ONGOING(ptCi))
    {
        VCCB_PRINT_LOG_MN_BC_RESELECTION(
            ptCi, "[MN_BC_RESELCTION] mnBcReselection is not active because NR-DC SCG Release Ongoing.\n");
        return false;
    }

    return true;
}

bool MnBCReselectionConditionChecker::isSendAllowedBcToMnDu()
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (not isMnBcReselectionAvailable())
    {
        return false;
    }

    if (ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC.nrofBandCombFilteredSelectedBc == 0)
    {
        VCCB_PRINT_LOG_MN_BC_RESELECTION(
            ptCi, "[MN_BC_RESELCTION] mnBcReselection is not active because nrofBandCombFilteredSelectedBc is zero.\n");
        return false;
    }

    if (isSelectedBcReceived() || isScellActionChanged())
    {
        return true;
    }

    return false;
}

bool MnBCReselectionConditionChecker::isSendAllowedBcOnConfigRestrictInfo(uint32_t bit_mask)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (bit_mask == 0)
    {
        VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi, "[MN_BC_RESELCTION] NRRRC_ConfigRestrictInfoSCG :: bit_mask is zero \n");
        return false;
    }

    if (not isMnBcReselectionAvailable())
    {
        return false;
    }

    if (ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC.nrofBandCombFilteredSelectedBc == 0)
    {
        VCCB_PRINT_LOG_MN_BC_RESELECTION(
            ptCi, "[MN_BC_RESELCTION] mnBcReselection is not active because nrofBandCombFilteredSelectedBc is zero.\n");
        return false;
    }
    return true;
}

MnBCReselector::~MnBCReselector() {}
MnBCReselector::MnBCReselector(callInfo_type *_ptCi) : ptCi(_ptCi)
{
    resultBandCombinationList.clear();
    noOfSameBc = 0;
}

bool MnBCReselector::getUeCapa()
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    ptUeBandCombList = getBandCombinationForNrDcAllowedBcFiltering();
    if (ptUeBandCombList == nullptr) {
        VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi, "[MN_BC_RESELCTION] Failed to get BandCombinationForNrDcAllowedBcFiltering. \n");
        return false;
    }

    ptFeatureSetBcList = VRIL_GetFeatureSetCombinationList(ptCi);
    if (ptFeatureSetBcList == NULL) {
        VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi, "[MN_BC_RESELCTION] Failed to GetFeatureSetCombinationList.\n");
        return false;
    }

    ptAllowedBcList = &ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC;
    return true;
}

bool MnBCReselector::isOnAllowedFeatureSetsBitmask(const bandCombinationInfo_type &targetAllowedBc, uint16_t fsIdx) 
{ 
    return GETBIT_U8TABLE(targetAllowedBc.allowedFeatureSetsBitmask, fsIdx);
}

void MnBCReselector::setResultBandCombinationList(
    bandCombinationInfo_type targetAllowedBc, uint8_t targetFeatureSetsBitmask[MAX_FEATURE_SET_BIT_MASK])
{
    for (int fsIdx = 0; fsIdx < 16; fsIdx++)
    {
       targetAllowedBc.allowedFeatureSetsBitmask[fsIdx] = targetFeatureSetsBitmask[fsIdx];
    }
    resultBandCombinationList.push_back(targetAllowedBc);
    noOfSameBc++;
}

bandCombinationList_type *MnBCReselector::getBandCombinationForNrDcAllowedBcFiltering()
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_NULLPTR(ptCi);

    if(VRIL_StoreNRRRC_UE_NR_Capability_BufferBased_IfNeeded(ptCi) == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VRIL_StoreNRRRC_UE_NR_Capability_BufferBased_IfNeeded Error in %s!\n", __FUNCTION__);
        return nullptr;
    }

    bigmsgUnpack_type *ptUnpackUeCapa = &THREAD_INFO->call[ptCi->myThreadId].buf.unpack.ueCapa;
    NRRRC_UE_NR_Capability *ptMsg = (NRRRC_UE_NR_Capability *)(&ptUnpackUeCapa->unpack[0] + ptUnpackUeCapa->unpackMsgOffset);
    
    if (FnVCCB_StoreSBCList(ptCi, &ptMsg->rf_Parameters) == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_StoreSBCList Error in %s!\n", __FUNCTION__);
        return nullptr;
    }

    return &THREAD_INFO->call[ptCi->myThreadId].buf.nrBandCombList;
}


void MnBCReselector::setBandCombinationInfoFilteredSelectedBc()
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    
    if (noOfSameBc == 0)
    {
        VCCB_PRINT_LOG_MN_BC_RESELECTION(
            ptCi, "[MN_BC_RESELCTION] selectedBc(%d) is zero.\n", ptCi->mrdcInfo.selectedBC.bandCombinationIndex);
        return;
    }

    ptAllowedBcList->nrofBandCombFilteredSelectedBc = noOfSameBc;
    for (size_t i = 0; i < resultBandCombinationList.size(); ++i)
    {
        memcpy(&ptAllowedBcList->bandCombinationInfoFilteredSelectedBc[i], &resultBandCombinationList[i], sizeof(bandCombinationInfo_type));
    }
    VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi, "[MN_BC_RESELCTION] nrofBandCombFilteredSelectedBc::%d\n",
        ptAllowedBcList->nrofBandCombFilteredSelectedBc);
}

bool MnBCReselector::findAndProcessMatchingFeatureSets(const BcInfo& selectedBc, const bandCombinationInfo_type& targetAllowedBc)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    BcInfo targetUeBc(ptCi);
    
    uint32_t bamdCombIdx = targetAllowedBc.bandCombinationIndex;
    if (bamdCombIdx == 0) return false;
    uint32_t targetBcIdx = bamdCombIdx - 1;

    if (not targetUeBc.getUeBc(targetBcIdx, ptUeBandCombList, ptFeatureSetBcList)) return false;
    if (targetUeBc.ueBc.num != targetUeBc.ueFsComb.num) return false;
    if (not targetUeBc.makeWithoutFsKey()) return false;
    
    VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi, "[MN_BC_RESELCTION] - Step 1 compare keyWithoutFs !! \n");
    if (not BcInfo::compareKeyValueForFr2Band(ptCi, selectedBc.keyWithoutFs, targetUeBc.keyWithoutFs))
    {
        return false; 
    }

    VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi, "[MN_BC_RESELCTION] - Step 2 compare ue bc\n");
    if (not BcInfo::compareUeBcForFr2Band(ptCi, selectedBc.ueBc, targetUeBc.ueBc))
    {
        return false;
    }

    uint8_t targetFeatureSetsBitmask[MAX_FEATURE_SET_BIT_MASK] = {0, };
    uint16_t numTargetFeatureSet = 0;
    
    VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi, "[MN_BC_RESELCTION] - Step 3 compare keyWithFs !! \n");
    for (uint16_t fsIdx = 0; fsIdx < MAX_NUM_FEATURESETSPERBAND; fsIdx++)
    {
        if (isOnAllowedFeatureSetsBitmask(targetAllowedBc, fsIdx))
        {
            if (not targetUeBc.makeWithFsKey(fsIdx)) continue;
            
            VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi, "[MN_BC_RESELCTION] - keyWithFs fsIdx(%d) !! \n", fsIdx);
            if (BcInfo::compareKeyValueForFr2Band(ptCi, selectedBc.keyWithFs, targetUeBc.keyWithFs)) 
            {
                ONBIT_U8TABLE(targetFeatureSetsBitmask, fsIdx);
                numTargetFeatureSet++;
                VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi, "[MN_BC_RESELCTION] - matching fsIdx(%d) !! \n", fsIdx);
            }
        }
    }

    if (numTargetFeatureSet == 0)
    {
        VCCB_PRINT_LOG_MN_BC_RESELECTION(
            ptCi, "[MN_BC_RESELCTION] featureSetId of targetBc(%d) is not available after detailed comparison.\n", targetAllowedBc.bandCombinationIndex);
        return false; 
    }

    setResultBandCombinationList(targetAllowedBc, targetFeatureSetsBitmask);
    return true;
}

extern const char *getNrBandClass(uint8_t bandClass);

void MnBCReselector::printBc(uint32_t bcIdx)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(bcIdx, MAX_BAND_COMBS);
    
    std::string outputStr;
    std::string tmpStr;
    const BandCombination_type ueBc = ptUeBandCombList->bandCombination[bcIdx];

    uint32_t maxNumBand = UMIN(ueBc.num, MAX_BANDS_PER_COMB);
    for (uint32_t bandIdx = 0; bandIdx < maxNumBand; bandIdx++)
    {
        uint16_t band = ueBc.band[bandIdx].freqBandIndicator;

        uint8_t dlClass = ueBc.band[bandIdx].nrCaBandwidthClassDL;
        uint8_t ulClass = ueBc.band[bandIdx].nrCaBandwidthClassUL;
        tmpStr = "n" + std::to_string(band) + "("+ getNrBandClass(dlClass) + "/" + getNrBandClass(ulClass) +  ")";

        if (bandIdx + 1 < ueBc.num)
        {
            tmpStr.append("-");
        }
        outputStr += tmpStr;
    }

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[MN_BC_RESELCTION] %s\n", outputStr.c_str());
}

void MnBCReselector::makeAllowedBcForMnBcReselection()
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (not getUeCapa()) return;
    VALID_E_POINT_CHECK_VOID(ptAllowedBcList);

    ptAllowedBcList->nrofBandCombFilteredSelectedBc = 0;
    memset(ptAllowedBcList->bandCombinationInfoFilteredSelectedBc, 0, sizeof(ptAllowedBcList->bandCombinationInfoFilteredSelectedBc));

    BcInfo selectedBc(ptCi);

    uint32_t bamdCombIdx = ptCi->mrdcInfo.selectedBC.bandCombinationIndex;
    if (bamdCombIdx == 0) return;
    uint32_t selectedBcIdx = bamdCombIdx - 1;
    VCCB_CHECK_E_RANGE_AND_VOID(selectedBcIdx, MAX_BAND_COMBS);

    uint32_t bandComRequestedFsIdx = ptCi->mrdcInfo.selectedBC.requestedFeatureSets;
    if (bandComRequestedFsIdx == 0) return;
    uint32_t fsEntryIdx = bandComRequestedFsIdx - 1;
    VCCB_CHECK_E_RANGE_AND_VOID(fsEntryIdx, MAX_NUM_FEATURESETSPERBAND);

    if (not selectedBc.getUeBc(selectedBcIdx, ptUeBandCombList, ptFeatureSetBcList)) return;
    if (not selectedBc.makeWithFsKey(fsEntryIdx)) return;
    if (not selectedBc.makeWithoutFsKey()) return;
    VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi, "====================== [MN_BC_RESELCTION] start =====================\n");
    VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi, "[MN_BC_RESELCTION] UE Capa selectedBC(%d) fsEntryIdx(%d)\n", selectedBcIdx, fsEntryIdx);
    printBc(selectedBcIdx);
    VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi, "=====================================================================\n");

    uint32_t numNrOfBandcomb =
        UMIN(ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC.nrofBandComb, MAX_NUM_BAND_COMB);

    for (uint32_t bcIdx = 0; bcIdx < numNrOfBandcomb; bcIdx++)
    {
        VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi, "[MN_BC_RESELCTION] ====== CompareBc idx(%d) ======\n", bcIdx);
        printBc(bcIdx);
        const bandCombinationInfo_type targetAllowedBc = ptAllowedBcList->bandCombinationInfo[bcIdx];
        if (findAndProcessMatchingFeatureSets(selectedBc, targetAllowedBc))
        {
            VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi, "[MN_BC_RESELCTION] success add in result bcIdx(%d)\n", bcIdx);
        }
    }
    
    VCCB_PRINT_LOG_MN_BC_RESELECTION(ptCi, "=====================================================================\n");
    setBandCombinationInfoFilteredSelectedBc();
}

void FnVCCB_ProcessMnBcReselection(callInfo_type *ptCi, bool isHoCancle)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    MnBCReselectionConditionChecker mnBCReselectorChecker(ptCi);
    if (mnBCReselectorChecker.isMnBcReselectionAvailable())
    {
        if (isHoCancle || mnBCReselectorChecker.isSelectedBcReceived())
        {
            MnBCReselector mnBcReselector(ptCi);
            mnBcReselector.makeAllowedBcForMnBcReselection();
        }
    }
    else
    {
        ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC.nrofBandCombFilteredSelectedBc = 0;
    }
}
