/**
 * @file        FeatMco.cpp
 * @brief       Functions for Multi Carrier Operations feature
 */

#include "FeatMco.h"
#include "FeatMco.hpp"
#include "FeatMcoStruct.hpp"
#include "FeatCommon.h"
#include "FeatCallInfo.h"
#include "FeatCallProc.h"
#include "FeatCa.hpp"
#include "FeatMeasurements.hpp"
#include "FeatLb.hpp"

#include "StateCa.h"
#include "StateCommon.h"


#include "ComLibUtility.h"

#include "MsgCommonMake.hpp"
#include "MsgNrRrcStore.h"
#include "MsgX2apMake.h"
#include "MsgX2apSend.h"
#include "StateMco.h"
#include <openssl/md5.h>

// MCO: Global mcoLinearAllocator state for mcoBand2BcBandResultsCache.
mcoCacheBuffInfo_s mcoBand2BcBandResultsCache_s::_buffInfoMainTh;
mcoCacheBuffInfo_s mcoBand2BcBandResultsCache_s::_buffInfoCallThTab[VCCB_CALL_THREAD_NUM];

#define MCO_ARRAY_PUSH_BACK(mcoArray, value)                                          \
    {                                                                                 \
        VCCB_RETURN_ON_ERROR((mcoArray.full() ? ERROR : GOOD), "count out of range"); \
        mcoArray.push_back(value);                                                    \
    }                                                                                 \
    while (false)                                                                     \
        ;

#define MCO_ARRAY_PUSH_BACK_CONTINUE(mcoArray, value)          \
    {                                                          \
        if (mcoArray.full())                                   \
        {                                                      \
            VCCB_PRINT_CALL_ERROR(ptCi, "count out of range"); \
        }                                                      \
        else                                                   \
        {                                                      \
            mcoArray.push_back(value);                         \
        }                                                      \
    }

/**
 * @brief      Helper function to find cellNum of an intra gnb cell corresponding to PLMN IdentityInfo
 * @param      ptCi : temporary call context
 * @param      ptPLMN_IdentityInfo : pointer to PLMN IdentityInfo extracted from MeasResult
 * @return     cellNum, MAX_CELL_NUM_VCCB in case of ERROR
 */
static uint16_t FnVCCB_McoGetCellNumFromPlmnId(callInfo_type *ptCi, PLMN_IdentityInfo_type *ptPLMN_IdentityInfo)
{
    AUTO_TRACE_FUNC;

    const auto PCELL_NOT_FOUND = MAX_CELL_NUM_VCCB;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, PCELL_NOT_FOUND);
    VALID_E_POINT_CHECK_RET_VAL(ptPLMN_IdentityInfo, PCELL_NOT_FOUND);
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, PCELL_NOT_FOUND);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    cgi_type cgi;
    cgi.ci = ptPLMN_IdentityInfo->cellIdentity;
    cgi.plmn.longId = ptPLMN_IdentityInfo->plmn_IdentityList.plmn_Identity[0].longId;

    return VLIB_GetCellNumBasedOnCgi(ptCi, cgi, pGnb->globalGnbId.gnbId.idLength);
};

/**
 * @brief      Helper function to check if cell can be pcell candidate
 *             Beware: You cannot use function which assumes callInfo's callType as it is unknown in one call site
 * @param      ptCi : temporary call context
 * @param      ptPLMN_IdentityInfo : pointer to PLMN IdentityInfo extracted from MeasResult
 * @return     bool
 */
static bool FnVCCB_McoCheckIfPcellCandidate(callInfo_type *ptCi, const uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(cellNum, false);

    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    uint16_t frequencyBand =
        VLIB_GetFreqBandIndForNeighborCellWithCustomSpCell(ptCi, &pCell->intraGnbNbrInfo, cellNum, true);
    if (BAND_NOT_FOUND == frequencyBand)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] Cannot get common FreqBandInd for cellNum(%u)\n", cellNum);
        return false;
    }

    if (GOOD != VLIB_checkChannelBWs(ptCi, cellNum, frequencyBand))
    {
        return false;
    }

    return true;
};

/**
 * @brief      Search for PCC frequency basing on measResultList2NR, found frequency is returned as pCellFrequency
 *             Function also search for bands and collected bands are returned as ptMeasuredBands (unique and sorted)
 * @param      ptCi : temporary call context
 * @param      ptMeasResultList2NR : pointer to measResultList2NR
 * @param[out] pCellFrequency : when PCC freq is found it is saved in this pointer
 * @param[out] measuredBandsOut : array to measured bands (sorted and unique)
 * @return    GOOD when PCC was found, BREAK when PCC was not found, ERROR in case when some issue occurs
 */
int16_t FnVCCB_McoSelectPrimaryCarrierFreq(callInfo_type *ptCi, measResultList2NR_type *ptMeasResultList2NR,
    uint32_t *pCellFrequency, MeasuredBands_type &measuredBandsOut)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMeasResultList2NR);
    VALID_E_POINT_CHECK_ERROR(pCellFrequency);
    VCCB_CHECK_RANGE_AND_RETURN_ERROR(ptMeasResultList2NR->nrofFreq, MAX_NUM_FREQ, "nrofFreq out of range");
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    struct
    {
        uint32_t ssbFrequency;
        uint16_t bandwidthDL;
        uint16_t bandwidthUL;
    } bestFreqs[MAX_NUM_FREQ];
    uint8_t bestFreqsCount = 0;

    uint8_t numNrOfFreq = MIN(ptMeasResultList2NR->nrofFreq, MAX_NUM_FREQ);
    for (uint8_t idx = 0; idx < numNrOfFreq; ++idx)  // go through all frequencies
    {
        uint16_t frequencyBand = BAND_NOT_FOUND;
        uint16_t duplexMode = ci_DUPLEXTYPE_FDD;
        measResult2NR_type *ptMeasResult2NR = &ptMeasResultList2NR->measResult2NR[idx];

        if (!FnVCCB_IsSsbAllowed(*ptCi, ptMeasResult2NR->ssbFrequency))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO][Extended n77] Primary Carrier Frequency(%u) rejected!\n",
                                    ptMeasResult2NR->ssbFrequency);
            continue;
        }

        uint8_t numNrOfCellReport = MIN(ptMeasResult2NR->measResultNeighCellListNR.nrofCellReport, MAX_NUM_CELL_REPORT);
        for (uint8_t nbrCellIdx = 0; nbrCellIdx < numNrOfCellReport; ++nbrCellIdx)  // go through all cells
        {
            measResultNR_type *ptMeasResultNR = &ptMeasResult2NR->measResultNeighCellListNR.measResultNR[nbrCellIdx];

            if (TRUE != ptMeasResultNR->cgiInfoFlag || TRUE != ptMeasResultNR->cgiInfo.plmn_IdentityInfoList_Flag)
            {
                VCCB_PRINT_CALL_COMMENT(
                    ptCi, "[MCO] no cgi info for freq %u cellidx: %u\n", ptMeasResult2NR->ssbFrequency, nbrCellIdx);
                continue;
            }

            uint8_t numOfPlmn = MIN(ptMeasResultNR->cgiInfo.plmn_IdentityInfoList.nrofPLMN_IdentityInfo, MAX_NUM_PLMN);
            for (uint8_t plmn_IdentityInfoIdx = 0; plmn_IdentityInfoIdx < numOfPlmn; ++plmn_IdentityInfoIdx)  // go through all identity info
            {
                PLMN_IdentityInfo_type *ptPLMN_IdentityInfo =
                    &ptMeasResultNR->cgiInfo.plmn_IdentityInfoList.plmn_IdentityInfo[plmn_IdentityInfoIdx];
                uint8_t gnbIdLength = pGnb->globalGnbId.gnbId.idLength;
                cgi_type cgi;
                cgi.ci = ptPLMN_IdentityInfo->cellIdentity;
                cgi.plmn.longId = ptPLMN_IdentityInfo->plmn_IdentityList.plmn_Identity[0].longId;
                uint32_t gnbId = VLIB_NrCellId2GnbId(gnbIdLength, cgi.ci);

                nbrGnbCellInfo_type *ptNbrGnbCell = NULL;

                if (BAND_NOT_FOUND == frequencyBand)
                {
                    // part for band selection we do not care about INTRA/INTER GNB
                    // in case of Inter GNB searching could take long time, so it will be done only once
                    // (only for band selection, PCC frequency need to be Intra GNB)
                    ptNbrGnbCell = VLIB_GetNbrGnbCellInfoBasedOnCgi(ptCi, cgi, gnbIdLength);

                    VALID_E_POINT_CHECK_CONTINUE(ptNbrGnbCell);

                    if (ptNbrGnbCell->ssbArfcn != ptMeasResult2NR->ssbFrequency)
                    {
                        VCCB_PRINT_CALL_ERROR(ptCi,
                            "[MCO] measured frequency different than found cell has %u!=%u, cell id:%d, pci:%d\n",
                            ptMeasResult2NR->ssbFrequency, ptNbrGnbCell->ssbArfcn, ptNbrGnbCell->cellId,
                            ptNbrGnbCell->nrPci);
                        continue;
                    }

                    frequencyBand = VLIB_GetFreqBandIndForNeighborCell(ptCi, ptNbrGnbCell);
                    if (BAND_NOT_FOUND != frequencyBand)
                    {
                        duplexMode = FnVCCB_GetNrDuplexTypeByBandIndicator(frequencyBand);
                        MCO_ARRAY_PUSH_BACK(measuredBandsOut, frequencyBand);
                    }
                    else
                    {
                        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] band not found for cell id:%d, pci:%d, freq:%u\n",
                            ptNbrGnbCell->cellId, ptNbrGnbCell->nrPci, ptMeasResult2NR->ssbFrequency);
                        continue;
                    }
                }

                if (!VCCB_IS_SAME_GNB(
                        gnbId, ptPLMN_IdentityInfo->plmn_IdentityList.plmn_Identity[0].longId, ptCi->gnbNum))
                {
                    VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] Inter GNB, skipping cellIdx: %d, plmnIdx: %d, freq:%u\n",
                        nbrCellIdx, plmn_IdentityInfoIdx, ptMeasResult2NR->ssbFrequency);
                    continue;
                }

                if (!ptNbrGnbCell)
                {
                    ptNbrGnbCell = VLIB_GetNbrGnbCellInfoBasedOnCgi(ptCi, cgi, gnbIdLength);

                    VALID_E_POINT_CHECK_CONTINUE(ptNbrGnbCell);

                    if (ptNbrGnbCell->ssbArfcn != ptMeasResult2NR->ssbFrequency)
                    {
                        VCCB_PRINT_CALL_ERROR(ptCi,
                            "[MCO] measured frequency different than found cell has %d!=%d, cell id:%d, pci:%d\n",
                            ptMeasResult2NR->ssbFrequency, ptNbrGnbCell->ssbArfcn, ptNbrGnbCell->cellId,
                            ptNbrGnbCell->nrPci);
                        continue;
                    }
                }

                if (IS_NBR_SDLCELL(ptNbrGnbCell))
                {
                    VCCB_PRINT_CALL_COMMENT(ptCi,
                        "[MCO] measured freq_idx(%d) is for SDL cell (id:%d, pci:%d, freq: %u)!\n", idx,
                        ptNbrGnbCell->cellId, ptNbrGnbCell->nrPci, ptMeasResult2NR->ssbFrequency);
                    continue;
                }

                if (!FnVCCB_McoCheckIfPcellCandidate(ptCi, FnVCCB_McoGetCellNumFromPlmnId(ptCi, ptPLMN_IdentityInfo)))
                {
                    continue;
                }

                uint16_t mcoBwDl = 0;
                uint16_t mcoBwUl = 0;
                FnVCCB_McoFillBandwidthByDuplex(duplexMode, mcoBwDl, mcoBwUl, *ptNbrGnbCell);

                // for parent for loop, now next frequency need to be checked
                // no more cells for this frequency need to be checked
                nbrCellIdx = MAX_NUM_CELL_REPORT;

                if ((0 < bestFreqsCount) &&
                    ((mcoBwDl < bestFreqs[0].bandwidthDL) ||
                        ((mcoBwDl == bestFreqs[0].bandwidthDL) && (mcoBwUl < bestFreqs[0].bandwidthUL))))
                {
                    // skip frequency if cell has lower BW than already found
                    break;
                }
                if ((0 == bestFreqsCount) || (mcoBwDl > bestFreqs[0].bandwidthDL) ||
                    ((mcoBwDl == bestFreqs[0].bandwidthDL) && (mcoBwUl > bestFreqs[0].bandwidthUL)))
                {
                    bestFreqsCount = 0;
                }
                bestFreqs[bestFreqsCount].bandwidthDL = mcoBwDl;
                bestFreqs[bestFreqsCount].bandwidthUL = mcoBwUl;
                bestFreqs[bestFreqsCount].ssbFrequency = ptMeasResultList2NR->measResult2NR[idx].ssbFrequency;
                ++bestFreqsCount;

                break;
            }
        }
    }

    if (0 == bestFreqsCount)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] PCC not found!\n");
        return BREAK;
    }
    else if (1 == bestFreqsCount)
    {
        *pCellFrequency = bestFreqs[0].ssbFrequency;
    }
    else
    {
        unsigned int randomPCC = FnVCCB_GetRandomValue(__FUNCTION__, ptCi->gnbNum, bestFreqsCount);
        *pCellFrequency = bestFreqs[randomPCC].ssbFrequency;
    }

    std::sort(measuredBandsOut.begin(), measuredBandsOut.end());
    long int newBandsSize = std::unique(measuredBandsOut.begin(), measuredBandsOut.end()) - measuredBandsOut.begin();
    measuredBandsOut.erase(measuredBandsOut.begin() + newBandsSize, measuredBandsOut.end());

    return GOOD;
}

/**
 * @brief      Select best pCell based on number of coloc-cells with measured bands
 * @param      ptCi : call context
 * @param      ptMeasResultList2NR : pointer to measResultList2NR
 * @param      pCellFrequency : pcell frequency
 * @return     cellNum /uint16_t
 */
uint16_t FnVCCB_McoSelectBestPCell(callInfo_type *ptCi, measResultList2NR_type *ptMeasResultList2NR,
    uint32_t pCellFrequency, const MeasuredBands_type &measuredBands)
{
    AUTO_TRACE_FUNC;

    const auto PCELL_NOT_FOUND = MAX_CELL_NUM_VCCB;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, PCELL_NOT_FOUND);
    VALID_E_POINT_CHECK_RET_VAL(ptMeasResultList2NR, PCELL_NOT_FOUND);

    uint16_t bestPCellNum = PCELL_NOT_FOUND;
    uint16_t bestCellRSRP = MIN_RSRQ_RSRP_THRESHOLD;
    uint8_t bestPCellNoOfScells = 0;

    measResult2NR_type *ptMeasResult2NR = nullptr;

    // go through the measurement list and measurement of pCellFrequency
    uint8_t numNrOfFreq = MIN(ptMeasResultList2NR->nrofFreq, MAX_NUM_FREQ);
    for (uint8_t idx = 0; idx < numNrOfFreq; ++idx)
    {
        if ((TRUE == ptMeasResultList2NR->measResult2NR[idx].ssbFrequency_Flag) &&
            (pCellFrequency == ptMeasResultList2NR->measResult2NR[idx].ssbFrequency))
        {
            ptMeasResult2NR = &ptMeasResultList2NR->measResult2NR[idx];
            break;
        }
    }

    VALID_E_POINT_CHECK_RET_VAL(ptMeasResult2NR, PCELL_NOT_FOUND);

    uint8_t numNrOfCellReport =  MIN(ptMeasResult2NR->measResultNeighCellListNR.nrofCellReport, MAX_NUM_CELL_REPORT);
    for (uint8_t nbrCellIdx = 0; nbrCellIdx < numNrOfCellReport; ++nbrCellIdx)
    {
        measResultNR_type *ptMeasResultNR = &ptMeasResult2NR->measResultNeighCellListNR.measResultNR[nbrCellIdx];

        if (TRUE != ptMeasResultNR->cgiInfoFlag || TRUE != ptMeasResultNR->cgiInfo.plmn_IdentityInfoList_Flag)
        {
            continue;
        }

        uint16_t currPCellRSRP = MIN_RSRQ_RSRP_THRESHOLD;
        if ((TRUE == ptMeasResultNR->cellResults.resultsSSB_CellFlag) &&
            (TRUE == ptMeasResultNR->cellResults.resultsSSB_Cell.rsrpFlag))
        {
            currPCellRSRP = ptMeasResultNR->cellResults.resultsSSB_Cell.rsrp;
        }

        uint8_t numOfPlmn =  MIN(ptMeasResultNR->cgiInfo.plmn_IdentityInfoList.nrofPLMN_IdentityInfo, MAX_NUM_PLMN);
        for (uint8_t plmn_IdentityInfoIdx = 0; plmn_IdentityInfoIdx < numOfPlmn; ++plmn_IdentityInfoIdx)
        {
            PLMN_IdentityInfo_type *ptPLMN_IdentityInfo =
                &ptMeasResultNR->cgiInfo.plmn_IdentityInfoList.plmn_IdentityInfo[plmn_IdentityInfoIdx];
            const uint16_t currPCellNum = FnVCCB_McoGetCellNumFromPlmnId(ptCi, ptPLMN_IdentityInfo);
            VCCB_CHECK_E_RANGE_AND_CONTINUE(currPCellNum, MAX_CELL_NUM_VCCB);

            VccbCellInfo_type *const pCell = &CELLINFO[currPCellNum];

            if (GOOD != VCCM_CheckCellInService(ptCi, currPCellNum, TRUE, FALSE))
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] CellNum(%u) not in service\n", currPCellNum);
                continue;
            }

            if ((E_CALLTYPE_SA == ptCi->callType) && (N_EQUIP == pCell->tacStatus))
            {
                continue;
            }

            if (!FnVCCB_McoCheckIfPcellCandidate(ptCi, currPCellNum))
            {
                continue;
            }

            uint8_t currPCellNoOfScells = 0;

            if (IS_CA_AVAILABLE(ptCi, pCell->nrCarrierAggregationInfo.caAvailable) &&
                (CI_use == pCell->cuColocCellInfo.colocCellInfoUsage))
            {
                for (uint8_t colocCellIdx = 0; colocCellIdx < MAX_COLOCCELL; colocCellIdx++)
                {
                    if ((CI_no_use == pCell->cuColocCellInfo.colocCellEntries[colocCellIdx].usage) ||
                        (TRUE != pCell->cuColocCellInfo.colocCellEntries[colocCellIdx].useforNrca))
                    {
                        continue;
                    }

                    cgi_type cgi;
                    cgi.ci = VLIB_GnbIdCellId2NrCellId(
                        &pCell->cuColocCellInfo.colocCellEntries[colocCellIdx].globalGnbId.gnbId,
                        pCell->cuColocCellInfo.colocCellEntries[colocCellIdx].cellId);
                    cgi.plmn = pCell->cuColocCellInfo.colocCellEntries[colocCellIdx].globalGnbId.plmn;
                    uint8_t gnbIdLength =
                        pCell->cuColocCellInfo.colocCellEntries[colocCellIdx].globalGnbId.gnbId.idLength;

                    nbrGnbCellInfo_type *pColocCellNbrGnbCellInfo =
                        VLIB_GetNbrGnbCellInfoBasedOnCgi(ptCi, cgi, gnbIdLength);
                    VALID_E_POINT_CHECK_CONTINUE(pColocCellNbrGnbCellInfo);

                    uint16_t colocCellFrequencyBand =
                        VLIB_GetFreqBandIndForNeighborCell(ptCi, pColocCellNbrGnbCellInfo);

                    if ((BAND_NOT_FOUND != colocCellFrequencyBand) &&
                        (true ==
                            std::binary_search(measuredBands.begin(), measuredBands.end(), colocCellFrequencyBand)))
                    {
                        ++currPCellNoOfScells;
                    }
                }
            }

            if ((bestPCellNoOfScells < currPCellNoOfScells) ||
                ((currPCellNoOfScells == bestPCellNoOfScells) && (bestCellRSRP <= currPCellRSRP)))
            {
                bestPCellNum = currPCellNum;
                bestCellRSRP = currPCellRSRP;
                bestPCellNoOfScells = currPCellNoOfScells;
            }
        }
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] FnVCCB_McoSelectPCell: cellnum(%u) no of scells candidates(%u), RSRP(%u).\n",
        bestPCellNum, bestPCellNoOfScells, bestCellRSRP);

    return bestPCellNum;
}

/**
 * @brief   MCO: Debug print bandCombinationList_type
 */
void FnVCCB_McoDebugPrintUeCapaBcList(callInfo_type *ptCi, const bandCombinationList_type &ueSupBandCombList)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (false == DBG->flag.logMcoUeCapa)
    {
        return;
    }

    for (uint16_t bcIdx = 0; bcIdx < ueSupBandCombList.num; bcIdx++)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "====== [MCO] UE Capa BC idx(%u) ======\n", bcIdx);
        const BandCombination_type &bc = ueSupBandCombList.bandCombination[bcIdx];
        for (uint8_t bandIdx = 0; bandIdx < bc.num; bandIdx++)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "band(%s %u) numContCc: DL(%u)/UL(%u)\n",
                (ci_nr == bc.band[bandIdx].ratType) ? "NR" : "EUTRA", bc.band[bandIdx].freqBandIndicator,
                bc.band[bandIdx].numContiguousCcDL, bc.band[bandIdx].numContiguousCcUL);
        }
    }
}

namespace
{
enum
{
    McoCcStartPosGrpInfo_None = 0,
    McoCcStartPosGrpInfo_DlOnly = 1,
    McoCcStartPosGrpInfo_DlUl = 2,
};
}  // namespace

/**
 * @brief   MCO: Check one BC-Band against a CC permutation
 */
bool FnVCCB_McoCheckBcBandAgainstSingleCcPerm(callInfo_type *ptCi, const mcoCcInfoVec_type &ccInfoVec,
    const uint16_t *pColocCcIdxBegin, const uint16_t *pColocCcIdxEnd, const uint8_t *pCcPosStartGrpTab,
    const double *pCcPosDlMimoCoefficientTab, const uint8_t *pCcPosDlMimoBitTab, char *pCcCauseCodesTab,
    mcoCheckBcResult_s &result)
{
    AUTO_TRACE_FUNC;

    result.reset();

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pColocCcIdxBegin, false);
    VALID_E_POINT_CHECK_RET_VAL(pColocCcIdxEnd, false);
    VALID_E_POINT_CHECK_RET_VAL(pCcPosStartGrpTab, false);
    VALID_E_POINT_CHECK_RET_VAL(pCcPosDlMimoCoefficientTab, false);
    VALID_E_POINT_CHECK_RET_VAL(pCcPosDlMimoBitTab, false);
    VALID_E_POINT_CHECK_RET_VAL(pCcCauseCodesTab, false);

    uint16_t pos = 0;                           // position of CC index in pColocCcIdx / pCcPosStartGrpTab / pCcPosDlMimoCoefficientTab
    uint16_t ccIdx = 0;                         // real CC index
    char bcGrpIdCurr = '0' - 1;                 // group ID
    bool bcBandInfoUlFlag = false;              // true if current BC group supports PCell
    uint64_t bcGrpHeadCcIdxBitmask = 0;         // bit set to 1 indicates CC index of group head
    uint64_t bcGrpTailCcIdxBitmask = 0;         // bit set to 1 indicates CC index of group tail
    mcoUCBcContigGrpChkInfo_s bcGrpChkCurrent;  // current BC group data
    bool bcGrpChkCurrentSetFlag = false;        // flag indicating that bcGrpChkCurrent is valid
    bool skipAllCcInCurrBcGrp = false;

#define fnIsCcContiguousByIdx(_ccIdxLow, _ccIdxHigh) \
    (((_ccIdxLow) + 1UL == (_ccIdxHigh)) && (ccInfoVec[_ccIdxLow].grpId == ccInfoVec[_ccIdxHigh].grpId))

#define fnIsCcContiguousWithHeadGroup() \
    (((0x2ULL << ccIdx) & bcGrpHeadCcIdxBitmask) && (ccInfoVec[ccIdx].grpId == ccInfoVec[ccIdx + 1UL].grpId))

#define fnIsCcContiguousWithTailGroup()                                 \
    (ccIdx && ((0x1ULL << (ccIdx - 1UL)) & bcGrpTailCcIdxBitmask) &&    \
        (ccInfoVec[ccIdx].grpId == ccInfoVec[ccIdx - 1UL].grpId))

#define fnAddAckCc(_ccInfo)                                                                                                 \
    do                                                                                                                      \
    {                                                                                                                       \
        result.ccCnt++;                                                                                                     \
        result.mcoBwDl += static_cast<uint32_t>(((_ccInfo).mcoBwDl * pCcPosDlMimoCoefficientTab[pos]) + 0.5);               \
        result.pcellAdded = (result.pcellAdded || ((_ccInfo).pcellFlag && bcBandInfoUlFlag));                               \
        result.ccIdxBitmask |= (1ULL << ccIdx);                                                                             \
        result.ccMimo2Bitmask |= static_cast<uint64_t>((pCcPosDlMimoBitTab[pos] & 0x1) << ccIdx);                           \
        result.ccMimo4Bitmask |= static_cast<uint64_t>(((pCcPosDlMimoBitTab[pos] >> 1) & 0x1) << ccIdx);                    \
        pCcCauseCodesTab[pos] = bcGrpIdCurr;                                                                                \
    } while (false)

#define fnRejectCc(_causeCode)                \
    do                                        \
    {                                         \
        pCcCauseCodesTab[pos] = (_causeCode); \
    } while (false)

    for (; pColocCcIdxBegin != pColocCcIdxEnd; ++pos, ++pColocCcIdxBegin)
    {
        if (pCcPosStartGrpTab[pos])
        {
            // new group
            bcGrpIdCurr++;
            bcBandInfoUlFlag = (McoCcStartPosGrpInfo_DlUl == pCcPosStartGrpTab[pos]);
            skipAllCcInCurrBcGrp = false;
        }

        ccIdx = *pColocCcIdxBegin;
        if (ccInfoVec.size() <= ccIdx)
        {
            skipAllCcInCurrBcGrp = true;
            // reject - dummy CC
            fnRejectCc('X');
            VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi,
                "[MCO] Check CC: pos(%u) ccIdx(%u) grpId(-) bcGrpId(%c) - SKIP (dummy CC idx)\n", pos, ccIdx,
                bcGrpIdCurr);
            continue;
        }
        const mcoCcInfo_s &ccInfo = ccInfoVec[ccIdx];

        // check cell eligibility:
        // first cell of the first BC group - always allowed
        if (0 == pos)
        {
            // add new BC group
            bcGrpChkCurrent.setHeadAndTail(ccIdx);
            bcGrpChkCurrentSetFlag = true;

            fnAddAckCc(ccInfo);
            VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi,
                "[MCO] Check CC: pos(%u) ccIdx(%u) grpId(%u) bcGrpId(%c) - OK (1st CC of first BC group)\n", pos, ccIdx,
                ccInfo.grpId, bcGrpIdCurr);
            continue;
        }

        // first cell of next BC group
        if (pCcPosStartGrpTab[pos])
        {
            // Set CC index bit mask for finalized previous group
            if (bcGrpChkCurrentSetFlag)
            {
                bcGrpHeadCcIdxBitmask |= (1ULL << bcGrpChkCurrent.ccIdxHead);
                bcGrpTailCcIdxBitmask |= (1ULL << bcGrpChkCurrent.ccIdxTail);
                bcGrpChkCurrentSetFlag = false;
            }

            // check cell with tail and head of all prev groups.
            if (true == fnIsCcContiguousWithTailGroup())
            {
                // skip all next cells from this BC group
                skipAllCcInCurrBcGrp = true;
                // reject - first CC of next BC group is contiguous with tail of other group
                fnRejectCc('T');
                VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi,
                    "[MCO] Check CC: pos(%u) ccIdx(%u) grpId(%u) bcGrpId(%c) - SKIP (1st CC of BC group is contig. "
                    "with tail of other group)\n",
                    pos, ccIdx, ccInfo.grpId, bcGrpIdCurr);
                continue;
            }

            if (true == fnIsCcContiguousWithHeadGroup())
            {
                // skip all next cells from this BC group
                skipAllCcInCurrBcGrp = true;
                // reject - first CC of next BC group is contiguous with head of other group
                fnRejectCc('H');
                VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi,
                    "[MCO] Check CC: pos(%u) ccIdx(%u) grpId(%u) bcGrpId(%c) - SKIP (1st CC of BC group is contig. "
                    "with head of other group)\n",
                    pos, ccIdx, ccInfo.grpId, bcGrpIdCurr);
                continue;
            }

            // add new BC group
            bcGrpChkCurrent.setHeadAndTail(ccIdx);
            bcGrpChkCurrentSetFlag = true;

            fnAddAckCc(ccInfo);
            VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi,
                "[MCO] Check CC: pos(%u) ccIdx(%u) grpId(%u) bcGrpId(%c) - OK (1st CC of BC group)\n", pos, ccIdx,
                ccInfo.grpId, bcGrpIdCurr);
            continue;
        }

        // next cell of a BC group
        if (skipAllCcInCurrBcGrp)
        {
            // reject - skip all next cell in current BC group
            fnRejectCc('s');
            VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi,
                "[MCO] Check CC: pos(%u) ccIdx(%u) grpId(%u) bcGrpId(%c) - SKIP (skip next CC in current BC group)\n",
                pos, ccIdx, ccInfo.grpId, bcGrpIdCurr);
            continue;
        }

        if (false == fnIsCcContiguousByIdx(bcGrpChkCurrent.ccIdxTail, ccIdx))
        {
            // skip all next cells from this BC group
            skipAllCcInCurrBcGrp = true;
            // reject - CC is not contiguous with previous cell of current BC group
            fnRejectCc('n');
            VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi,
                "[MCO] Check CC: pos(%u) ccIdx(%u) grpId(%u) bcGrpId(%c) - SKIP (not contig. with prev CC of the "
                "current BC group)\n",
                pos, ccIdx, ccInfo.grpId, bcGrpIdCurr);
            continue;
        }

        // check cell with tail and head of all previous groups (skip current(last) group).
        if (true == fnIsCcContiguousWithTailGroup())
        {
            // skip all next cells from this BC group
            skipAllCcInCurrBcGrp = true;
            // reject - next CC of the BC group is contiguous with tail of other group
            fnRejectCc('t');
            VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi,
                "[MCO] Check CC: pos(%u) ccIdx(%u) grpId(%u) bcGrpId(%c) - SKIP (CC is contig. with tail of other "
                "group)\n",
                pos, ccIdx, ccInfo.grpId, bcGrpIdCurr);
            continue;
        }

        if (true == fnIsCcContiguousWithHeadGroup())
        {
            // skip all next cells from this BC group
            skipAllCcInCurrBcGrp = true;
            // reject - next CC of the BC group is contiguous with head of other group
            fnRejectCc('h');
            VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi,
                "[MCO] Check CC: pos(%u) ccIdx(%u) grpId(%u) bcGrpId(%c) - SKIP (CC is contig. with head of other "
                "group)\n",
                pos, ccIdx, ccInfo.grpId, bcGrpIdCurr);
            continue;
        }

        // Add CC to existing BC group
        bcGrpChkCurrent.ccIdxTail = ccIdx;

        fnAddAckCc(ccInfo);
        VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi,
            "[MCO] Check CC: pos(%u) ccIdx(%u) grpId(%u) bcGrpId(%c) - OK (next cell of BC group)\n", pos, ccIdx,
            ccInfo.grpId, bcGrpIdCurr);
    }

    pCcCauseCodesTab[pos] = '\0';

    return true;

#undef fnIsCcContiguousByIdx
#undef fnIsCcContiguousWithHeadGroup
#undef fnIsCcContiguousWithTailGroup
#undef fnAddAckCc
#undef fnRejectCc
}

/**
 * @brief   MCO: Check all variations of grpUlBwResultTab to find max UL BW.
 */
void FnVCCB_McoCheckBcGrpResultVarForMaxUlBw(const mcoGrpUlBwResult_s *grpUlBwResultTab, const std::size_t grpUlBwResultSize,
    uint32_t &maxUlBwOut, uint64_t &maxUlBwPcellIdxBitmaskOut)
{
    AUTO_TRACE_FUNC;

    maxUlBwOut = 0;
    maxUlBwPcellIdxBitmaskOut = 0;

    VALID_E_POINT_CHECK_VOID(grpUlBwResultTab);
    if (0 == grpUlBwResultSize)
    {
        return;
    }

    // Calculate global max UL BW
    uint32_t maxUlBw = 0;
    uint64_t maxUlBwPcellIdxBitmask = 0;
    unsigned int skipWoPcellBitmask = 0;
    for (std::size_t grpIdx = 0; grpIdx < grpUlBwResultSize; grpIdx++)
    {
        if (grpUlBwResultTab[grpIdx].incPcellBw < grpUlBwResultTab[grpIdx].woPcellBw)
        {
            maxUlBw += grpUlBwResultTab[grpIdx].woPcellBw;
        }
        else
        {
            maxUlBw += grpUlBwResultTab[grpIdx].incPcellBw;
            maxUlBwPcellIdxBitmask |= grpUlBwResultTab[grpIdx].ulBwPcellIdxBitmask;
            skipWoPcellBitmask |= (1U << grpIdx);
        }
    }

    if (maxUlBwPcellIdxBitmask)
    {
        // max UL BW including PCell candidates found no need to check other variations
        maxUlBwOut = maxUlBw;
        maxUlBwPcellIdxBitmaskOut = maxUlBwPcellIdxBitmask;
        return;
    }

    uint32_t varUlBw = 0;
    uint64_t varUlBwPcellIdxBitmask = 0;
    // Max value of grpUlBwResultSize is 10 => 2^10-1 = 0x3FF
    // -1 is to skip last variation with no PCell candidates (all ones)
    static const unsigned int variationNumMax = 0x3FF;
    const unsigned int variationNum = std::min(((1U << grpUlBwResultSize) - 1), variationNumMax);
    for (unsigned int variationIdx = 0; variationIdx < variationNum; variationIdx++)
    {
        if (skipWoPcellBitmask & variationIdx)
        {
            continue;
        }

        varUlBw = 0;
        varUlBwPcellIdxBitmask = 0;
        for (uint16_t grpIdx = 0; grpIdx < grpUlBwResultSize; grpIdx++)
        {
            if (variationIdx & (1U << grpIdx))
            {
                // without PCell result
                varUlBw += grpUlBwResultTab[grpIdx].woPcellBw;
            }
            else
            {
                // with PCell result
                varUlBw += grpUlBwResultTab[grpIdx].incPcellBw;
                varUlBwPcellIdxBitmask |= grpUlBwResultTab[grpIdx].ulBwPcellIdxBitmask;
            }
        }

        if (maxUlBwOut < varUlBw)
        {
            maxUlBwOut = varUlBw;
            maxUlBwPcellIdxBitmaskOut = varUlBwPcellIdxBitmask;
        }
        else if (maxUlBwOut == varUlBw)
        {
            maxUlBwPcellIdxBitmaskOut |= varUlBwPcellIdxBitmask;
        }
    }
}

/**
 * @brief    MCO: Return last eligible CC position index within current contiguous group.
 */
unsigned long int mcoGrpUlBwResultFiller_s::FnVCCB_GetGrpLastEligiblePosIdx() const
{
    AUTO_TRACE_FUNC;

    uint16_t ccIdx = 0;
    unsigned long int grpLastEligiblePosIdx = m_grpFirstPosIdx;
    if (nullptr == m_pColocCcIdxTab)
    {
        return grpLastEligiblePosIdx;
    }
    for (; (grpLastEligiblePosIdx < m_grpLastPosIdx) && (grpLastEligiblePosIdx < m_maxCcPosIdx); grpLastEligiblePosIdx++)
    {
        ccIdx = m_pColocCcIdxTab[grpLastEligiblePosIdx];
        if ((ccIdx >= m_ccInfoVec.size()) || (0 == (m_eligCcIdxBitmask & (1ULL << ccIdx))))
        {
            break;
        }
    }
    return grpLastEligiblePosIdx;
}

/**
 * @brief   MCO: Return mcoGrpUlBwResult_s object (max UL BW) based on mcoUeCapaBcBandInfo_s input object.
 */
mcoGrpUlBwResult_s mcoGrpUlBwResultFiller_s::operator()(const mcoUeCapaBcBandInfo_s &rBcBandInfo)
{
    mcoGrpUlBwResult_s mcoGrpUlBwResult;

    // Contiguous group is designated by DL
    m_grpLastPosIdx += rBcBandInfo.numContiguousCcDL;

    if ((0 == rBcBandInfo.numContiguousCcUL) || (nullptr == m_pColocCcIdxTab))
    {
        m_grpFirstPosIdx = m_grpLastPosIdx;
        return mcoGrpUlBwResult;
    }

    // Find last eligible CC within current contiguous group
    const unsigned long int grpLastEligiblePosIdx = FnVCCB_GetGrpLastEligiblePosIdx();

    // Create UL sub-window within eligible CCs and within current contiguous group
    unsigned long int subWdwFirstPosIdx = m_grpFirstPosIdx;
    unsigned long int subWdwLastPosIdx = std::min(subWdwFirstPosIdx + rBcBandInfo.numContiguousCcUL, grpLastEligiblePosIdx);

    // Find max BW for consecutive positions of sub-window
    uint32_t subWdwBwSum = 0;
    uint64_t subWdwPcellIdxBitmask = 0;
    uint16_t ccIdx = 0;

    // Calculate BW for the first position of sub-window
    for (unsigned long int posIdx = subWdwFirstPosIdx; posIdx < subWdwLastPosIdx; posIdx++)
    {
        ccIdx = m_pColocCcIdxTab[posIdx];
        // FGR-CC5500, FR90: For FR2 Cells use DL BW value for UL BW assuming they are in proportion.
        subWdwBwSum += m_ccInfoVec[ccIdx].mcoBwDl;
        if (m_ccInfoVec[ccIdx].pcellFlag)
        {
            subWdwPcellIdxBitmask |= (1ULL << ccIdx);
        }
    }

    while (true)
    {
        // Check if BW calculation contains any PCell
        if (subWdwPcellIdxBitmask)
        {
            // Check max BW
            if (subWdwBwSum > mcoGrpUlBwResult.incPcellBw)
            {
                mcoGrpUlBwResult.incPcellBw = subWdwBwSum;
                mcoGrpUlBwResult.ulBwPcellIdxBitmask = subWdwPcellIdxBitmask;
            }
            else if (subWdwBwSum == mcoGrpUlBwResult.incPcellBw)
            {
                // alternative max BW allocation
                mcoGrpUlBwResult.ulBwPcellIdxBitmask |= subWdwPcellIdxBitmask;
            }
        }
        else if (subWdwBwSum > mcoGrpUlBwResult.woPcellBw)
        {
            mcoGrpUlBwResult.woPcellBw = subWdwBwSum;
        }

        // Check next position of sub-window
        if (subWdwLastPosIdx >= grpLastEligiblePosIdx)
        {
            break;
        }
        ccIdx = m_pColocCcIdxTab[subWdwFirstPosIdx];
        // FGR-CC5500, FR90: For FR2 Cells use DL BW value for UL BW assuming they are in proportion.
        subWdwBwSum -= m_ccInfoVec[ccIdx].mcoBwDl;
        subWdwPcellIdxBitmask &= ~(1ULL << ccIdx);
        subWdwFirstPosIdx++;

        ccIdx = m_pColocCcIdxTab[subWdwLastPosIdx];
        // FGR-CC5500, FR90: For FR2 Cells use DL BW value for UL BW assuming they are in proportion.
        subWdwBwSum += m_ccInfoVec[ccIdx].mcoBwDl;
        if (m_ccInfoVec[ccIdx].pcellFlag)
        {
            subWdwPcellIdxBitmask |= (1ULL << ccIdx);
        }
        subWdwLastPosIdx++;
    }

    m_grpFirstPosIdx = m_grpLastPosIdx;
    return mcoGrpUlBwResult;
}

/**
 * @brief   MCO: Calculate max UL bandwidth for given CC permutation eligible for DL, and given UL BW class permutation.
 */
void FnVCCB_McoCheckMaxUlBwBcBandAgainstSingleCcPerm(const mcoCcInfoVec_type &ccInfoVec,
    const mcoBcBandInfoDq_type &bcBandInfoDq, const uint16_t *pColocCcIdxFirst, const uint16_t *pColocCcIdxLast,
    const uint64_t eligCcIdxBitmask, uint32_t &maxUlBwOut, uint64_t &maxUlBwPcellIdxBitmaskOut)
{
    AUTO_TRACE_FUNC;

    maxUlBwOut = 0;
    maxUlBwPcellIdxBitmaskOut = 0;

    VALID_E_POINT_CHECK_VOID(pColocCcIdxFirst);
    VALID_E_POINT_CHECK_VOID(pColocCcIdxLast);
    if (pColocCcIdxLast <= pColocCcIdxFirst)
    {
        return;
    }

    const std::size_t bcBandInfoDqSize = bcBandInfoDq.size();
    if (0 == bcBandInfoDqSize)
    {
        return;
    }

    // Iterate over contiguous groups and fill grpUlBwResultTab
    mcoGrpUlBwResult_s grpUlBwResultTab[bcBandInfoDqSize];
    const unsigned long int colocCcIdxSize = static_cast<unsigned long int>(pColocCcIdxLast - pColocCcIdxFirst);
    mcoGrpUlBwResultFiller_s mcoGrpUlBwResultFiller(ccInfoVec, pColocCcIdxFirst, colocCcIdxSize, eligCcIdxBitmask);
    std::transform(bcBandInfoDq.begin(), bcBandInfoDq.end(), grpUlBwResultTab, mcoGrpUlBwResultFiller);

    FnVCCB_McoCheckBcGrpResultVarForMaxUlBw(grpUlBwResultTab, bcBandInfoDqSize, maxUlBwOut, maxUlBwPcellIdxBitmaskOut);
}

/**
 * @brief   Get sum of mcoBwDl for the first k CC with the highest mcoBwDl
 */
uint32_t FnVCCB_McoGetMaxSumBwDlForFirstKCc(const mcoCcInfoVec_type &ccInfoVec, std::size_t kelem)
{
    AUTO_TRACE_FUNC;
    const std::size_t ccInfoVecSize = ccInfoVec.size();  // for Svace

    if (0 == ccInfoVecSize)
    {
        return 0;
    }

    uint32_t sumMaxBwK = 0;
    uint32_t mcoBwDlCcTab[ccInfoVecSize];

    if (kelem > ccInfoVecSize)
    {
        kelem = ccInfoVecSize;
    }

    std::transform(
        ccInfoVec.begin(), ccInfoVec.end(), mcoBwDlCcTab, [](const mcoCcInfo_s &rCcInfo) { return rCcInfo.mcoBwDl; });
    std::sort(mcoBwDlCcTab, mcoBwDlCcTab + ccInfoVecSize, std::greater<uint32_t>());
    std::for_each(mcoBwDlCcTab, mcoBwDlCcTab + kelem, [&sumMaxBwK](const uint32_t elem) { sumMaxBwK += elem; });

    return sumMaxBwK;
}

/**
 * @brief   Template function to execute 'func' on all generated k-permutations of n, where k = permutationSize,
 *          n = totalSize. The set over which it permutates is (0 1 2 .. totalSize-1).
 *          For permutation generation Heap's algorithm is used.
 *          Example for k = 2, n = 3:
 *          0 1
 *          1 0
 *          0 2
 *          2 0
 *          1 2
 *          2 1
 */
template <typename Functor>
void FnVCCB_ForEachPermutedCombination(std::size_t permutationSize, const std::size_t totalSize, Functor func)
{
    AUTO_TRACE_FUNC;

    if (totalSize < permutationSize)
    {
        permutationSize = totalSize;
    }

    uint16_t binaryTab[totalSize];
    uint16_t subsetTab[permutationSize];
    uint16_t permutationTab[permutationSize];
    bool continueCondition = true;

    for (std::size_t loop = 0; loop < totalSize; loop++)
    {
        if (loop < permutationSize)
        {
            binaryTab[loop] = 1;
        }
        else
        {
            binaryTab[loop] = 0;
        }
    }

    do
    {
        std::size_t count = 0;
        for (std::size_t loop = 0; loop < totalSize; loop++)
        {
            if (binaryTab[loop] == 1)
            {
                subsetTab[count] = (uint16_t) loop;
                count++;
            }
        }

        continueCondition = func(subsetTab, subsetTab + permutationSize);

        for (std::size_t loop = 0; loop < permutationSize; loop++)
        {
            permutationTab[loop] = 0;
        }

        std::size_t loop = 1;
        while ((loop < permutationSize) && continueCondition)
        {
            if (permutationTab[loop] < loop)
            {
                if (loop & 1)
                {
                    std::swap(subsetTab[permutationTab[loop]], subsetTab[loop]);
                }
                else
                {
                    std::swap(subsetTab[0], subsetTab[loop]);
                }

                continueCondition = func(subsetTab, subsetTab + permutationSize);
                permutationTab[loop]++;
                loop = 1;
            }
            else
            {
                permutationTab[loop] = 0;
                loop++;
            }
        }
    } while (continueCondition && std::prev_permutation(binaryTab, binaryTab + totalSize));
}

/**
 * @brief   MCO: Set non-zero values at the indices corresponding to the beginning of consecutive adjacent groups.
 *          pCcPosStartGrpTabOut - should be initialized with 0s.
 */
void FnVCCB_McoFillCcPosStartGrpInfoTab(const mcoBcBandInfoDq_type &bcBandInfoDq, uint8_t *pCcPosStartGrpTabOut)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pCcPosStartGrpTabOut);

    uint32_t ccPosStartGrpIdx = 0;
    for (const mcoUeCapaBcBandInfo_s &bcBandInfo : bcBandInfoDq)
    {
        pCcPosStartGrpTabOut[ccPosStartGrpIdx] =
            (bcBandInfo.ulFlag ? McoCcStartPosGrpInfo_DlUl : McoCcStartPosGrpInfo_DlOnly);
        ccPosStartGrpIdx += bcBandInfo.numContiguousCcDL;
    }
}

/**
 * @brief   MCO: Converts MIMO Layer number to MIMO Layer coefficient as specified by FR44
 */
double FnVCCB_McoConvertMimoNumToMimoCoefficient(const VccbGnbInfo_type &rGnb, uint8_t mimoLayerNum)
{
    // AUTO_TRACE_FUNC;

    switch (mimoLayerNum)
    {
        case MCO_MIMO_4_LAYERS:
            return rGnb.carrierAggregationInfo.dl4LayerWeightFactor;
        case MCO_MIMO_2_LAYERS:
            return rGnb.carrierAggregationInfo.dl2LayerWeightFactor;
        default:
            return rGnb.carrierAggregationInfo.dl1LayerWeightFactor;
    }
}

/**
 * @brief   MCO: For each element of pCcPosDlMimoBitOut set bits representing DL MIMO Layer number of corresponding BcBandInfo.
 *          0x1 - MIMO_2_LAYERS, 0x2 - MIMO_4_LAYERS
 */
void FnVCCB_McoFillCcPosDlMimoBit(const mcoBcBandInfoDq_type &bcBandInfoDq, uint8_t *pCcPosDlMimoBitOut)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pCcPosDlMimoBitOut);
    uint32_t pos = 0;
    for (const mcoUeCapaBcBandInfo_s &bcBandInfo : bcBandInfoDq)
    {
        for (uint32_t idxInContiguousGrp = 0; bcBandInfo.numContiguousCcDL > idxInContiguousGrp; idxInContiguousGrp++)
        {
            pCcPosDlMimoBitOut[pos] = static_cast<uint8_t>(bcBandInfo.dlMimoLayerNum >> 1);
            pos++;
        }
    }
}

/**
 * @brief   MCO: Check one BC-Band against CC list
 */
bool FnVCCB_McoCheckBcBandAgainstCcList(callInfo_type *ptCi, const mcoCcInfoVec_type &ccInfoVec,
    const mcoBcBandInfoDq_type &bcBandInfoDq, const bool checkPcell, char *pCcCauseCodesTab,
    mcoCheckBcBandResultsCache_s *pBcBandResultsCache, const bool checkUlBwFlag, const bool noMimoFlag,
    mcoCheckBcResult_s &result)
{
    AUTO_TRACE_FUNC;

    result.reset();

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pCcCauseCodesTab, false);

    uint32_t bcBandPermCnt = 0;
    unsigned int sumBcBandNumContiguousCcDL = 0;
    mcoCheckBcResult_s bcBandPermResult, bcBandMaxResult;
    const std::size_t ccInfoVecSize = ccInfoVec.size();

    if (0 == ccInfoVecSize)
    {
        VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi, "[MCO] No CC on list!\n");
        return false;
    }

    for (const mcoUeCapaBcBandInfo_s &bcBandInfo : bcBandInfoDq)
    {
        sumBcBandNumContiguousCcDL += bcBandInfo.numContiguousCcDL;
    }

    if (0 == sumBcBandNumContiguousCcDL)
    {
        VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi, "[MCO] sumBcBandNumContiguousCcDL is 0!\n");
        return false;
    }

    const mcoCheckBcBandResultsCache_s::key_type bcBandKey = (checkUlBwFlag ?
        mcoCheckBcBandResultsCache_s::makeBcBandKeyDlUl(bcBandInfoDq) :
        mcoCheckBcBandResultsCache_s::makeBcBandKey(bcBandInfoDq));
    if ((nullptr != pBcBandResultsCache) && (true == pBcBandResultsCache->getResult(bcBandKey, bcBandPermResult)))
    {
        VCCB_PRINT_CALL_MCO_BCBANDPERM(
            ptCi, "[MCO] Found cached key(0x%016lx%016lx) result BW(%u)\n",
            static_cast<uint64_t>(bcBandKey>>64), static_cast<uint64_t>(bcBandKey), bcBandPermResult.mcoBwDl);
        snprintf(pCcCauseCodesTab, MAX_MCO_CCNUM, "CACHED");
        result = bcBandPermResult;
        return true;
    }

    // temporary data structures
    char ccCauseCodesTab[MAX_MCO_CCNUM + 1];
    ccCauseCodesTab[MAX_MCO_CCNUM] = '\0';

    uint8_t ccPosStartGrpInfoTab[sumBcBandNumContiguousCcDL];
    memset(ccPosStartGrpInfoTab, 0, sizeof(ccPosStartGrpInfoTab));  // init to 0 = McoCcStartPosGrpInfo_None
    FnVCCB_McoFillCcPosStartGrpInfoTab(bcBandInfoDq, ccPosStartGrpInfoTab);

    uint8_t ccPosDlMimoBitTab[sumBcBandNumContiguousCcDL];
    double ccPosDlMimoCoefficientTab[sumBcBandNumContiguousCcDL];
    double maxDlMimoCoefficient = 1.0;

    // MIMO should not be taken into account in SLB mode as Slice Available Capacity is calculated instead of BW
    if (checkUlBwFlag || noMimoFlag)
    {
        std::fill(ccPosDlMimoBitTab, ccPosDlMimoBitTab + sumBcBandNumContiguousCcDL, 0); // 0 - 1 MIMO layer
        std::fill(ccPosDlMimoCoefficientTab, ccPosDlMimoCoefficientTab + sumBcBandNumContiguousCcDL, 1.0);
    }
    else
    {
        FnVCCB_McoFillCcPosDlMimoBit(bcBandInfoDq, ccPosDlMimoBitTab);

        VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, false);
        const VccbGnbInfo_type &rGnb = GNBINFO[ptCi->gnbNum];
        std::transform(ccPosDlMimoBitTab, ccPosDlMimoBitTab + sumBcBandNumContiguousCcDL, ccPosDlMimoCoefficientTab,
            [&rGnb](const uint8_t dlMimoLayerNum){
                return FnVCCB_McoConvertMimoNumToMimoCoefficient(rGnb, static_cast<uint8_t>(dlMimoLayerNum << 1)); });

        maxDlMimoCoefficient = *std::max_element(ccPosDlMimoCoefficientTab, ccPosDlMimoCoefficientTab + sumBcBandNumContiguousCcDL);
    }

    uint32_t maxUlBw = 0;
    uint64_t maxUlBwPcellIdxBitmask = 0;

    if (ccInfoVecSize > sumBcBandNumContiguousCcDL)
    {
        // Rough estimation of sum of mcoBwDl * DlMimoNum for the first k(=sumBcBandNumContiguousCcDL) CC with the highest mcoBwDl
        const uint32_t sumMaxBwK = static_cast<uint32_t>((FnVCCB_McoGetMaxSumBwDlForFirstKCc(ccInfoVec, sumBcBandNumContiguousCcDL) * maxDlMimoCoefficient) + 0.5);
        VCCB_PRINT_CALL_MCO_CHECKBC(ptCi, "[MCO] k(%u)-permutation of n(%lu) CC: sumMaxBwK(%u) maxDlMimoCoef(%f)\n",
            sumBcBandNumContiguousCcDL, ccInfoVecSize, sumMaxBwK, maxDlMimoCoefficient);

        FnVCCB_ForEachPermutedCombination(sumBcBandNumContiguousCcDL, ccInfoVecSize,
            [&](uint16_t *first, uint16_t *last)
            {
                bcBandPermCnt++;

                if (false == FnVCCB_McoCheckBcBandAgainstSingleCcPerm(
                                 ptCi, ccInfoVec, first, last, ccPosStartGrpInfoTab, ccPosDlMimoCoefficientTab,
                                 ccPosDlMimoBitTab, ccCauseCodesTab, bcBandPermResult))
                {
                    VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi,
                        "[MCO] CC k(%u)-permutation of n(%lu) permNum(%u): inadequate result!\n",
                        sumBcBandNumContiguousCcDL, ccInfoVecSize, bcBandPermCnt);
                    return true;
                }

                if ((true == checkPcell) && (false == bcBandPermResult.pcellAdded))
                {
                    VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi,
                        "[MCO] CC k(%u)-permutation of n(%lu) permNum(%u): no PCell, cause(%s) ccidx(0x%lx)!\n",
                        sumBcBandNumContiguousCcDL, ccInfoVecSize, bcBandPermCnt, ccCauseCodesTab,
                        bcBandPermResult.ccIdxBitmask);
                    return true;
                }

                bool checkBcBandPermUlBw = false;
                if (bcBandPermResult.mcoBwDl > bcBandMaxResult.mcoBwDl)
                {
                    bcBandMaxResult = bcBandPermResult;
                    strncpy(pCcCauseCodesTab, ccCauseCodesTab, MAX_MCO_CCNUM + 1);
                    checkBcBandPermUlBw = checkUlBwFlag;
                }
                else if (bcBandPermResult.mcoBwDl == bcBandMaxResult.mcoBwDl)
                {
                    checkBcBandPermUlBw = checkUlBwFlag;
                }

                VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi,
                    "[MCO] CC k(%u)-permutation of n(%lu) permNum(%u): res(%u), max(%u) cause(%s) ccidx(0x%lx)\n",
                    sumBcBandNumContiguousCcDL, ccInfoVecSize, bcBandPermCnt, bcBandPermResult.mcoBwDl,
                    bcBandMaxResult.mcoBwDl, ccCauseCodesTab, bcBandPermResult.ccIdxBitmask);

                if (checkBcBandPermUlBw)
                {
                    FnVCCB_McoCheckMaxUlBwBcBandAgainstSingleCcPerm(ccInfoVec, bcBandInfoDq, first, last,
                        bcBandPermResult.ccIdxBitmask, maxUlBw, maxUlBwPcellIdxBitmask);
                    if (bcBandMaxResult.mcoBwUl < maxUlBw)
                    {
                        bcBandMaxResult.mcoBwUl = maxUlBw;
                        bcBandMaxResult.maxUlBwPcellIdxBitmask = maxUlBwPcellIdxBitmask;
                    }
                    else if (bcBandMaxResult.mcoBwUl == maxUlBw)
                    {
                        bcBandMaxResult.maxUlBwPcellIdxBitmask |= maxUlBwPcellIdxBitmask;
                    }
                }

                // maximum BW found, stop checking
                if ((sumMaxBwK == bcBandPermResult.mcoBwDl) && (false == checkUlBwFlag))
                {
                    VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi, "[MCO] maximum BW(%u) found - BREAK\n", sumMaxBwK);
                    return false;
                }

                return true;
            });
    }
    else
    {
        uint16_t colocCcIdxTab[sumBcBandNumContiguousCcDL];
        std::iota(colocCcIdxTab, colocCcIdxTab + ccInfoVecSize, 0);

        VCCB_PRINT_CALL_MCO_CHECKBC(
            ptCi, "[MCO] permutation of n(%lu) CC into (%u) buckets\n", ccInfoVecSize, sumBcBandNumContiguousCcDL);

        if (ccInfoVecSize < sumBcBandNumContiguousCcDL)
        {
            // set dummy cell idx
            std::fill(colocCcIdxTab + ccInfoVecSize, colocCcIdxTab + sumBcBandNumContiguousCcDL, 255);
        }

        do
        {
            bcBandPermCnt++;

            if (false == FnVCCB_McoCheckBcBandAgainstSingleCcPerm(ptCi, ccInfoVec, colocCcIdxTab,
                             colocCcIdxTab + sumBcBandNumContiguousCcDL, ccPosStartGrpInfoTab,
                             ccPosDlMimoCoefficientTab, ccPosDlMimoBitTab, ccCauseCodesTab, bcBandPermResult))
            {
                VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi, "[MCO] CC permutation (%lu/%u) permNum(%u): inadequate result!\n",
                    ccInfoVecSize, sumBcBandNumContiguousCcDL, bcBandPermCnt);
                continue;
            }

            if ((true == checkPcell) && (false == bcBandPermResult.pcellAdded))
            {
                VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi,
                    "[MCO] CC permutation (%lu/%u) permNum(%u): no PCell, cause(%s) ccidx(0x%lx)!\n", ccInfoVecSize,
                    sumBcBandNumContiguousCcDL, bcBandPermCnt, ccCauseCodesTab, bcBandPermResult.ccIdxBitmask);
                continue;
            }

            bool checkBcBandPermUlBw = false;
            if (bcBandPermResult.mcoBwDl > bcBandMaxResult.mcoBwDl)
            {
                bcBandMaxResult = bcBandPermResult;
                strncpy(pCcCauseCodesTab, ccCauseCodesTab, MAX_MCO_CCNUM + 1);
                checkBcBandPermUlBw = checkUlBwFlag;
            }
            else if (bcBandPermResult.mcoBwDl == bcBandMaxResult.mcoBwDl)
            {
                checkBcBandPermUlBw = checkUlBwFlag;
            }

            VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi,
                "[MCO] CC permutation (%lu/%u) permNum(%u): res(%u), max(%u) cause(%s) ccidx(0x%lx)\n", ccInfoVecSize,
                sumBcBandNumContiguousCcDL, bcBandPermCnt, bcBandPermResult.mcoBwDl, bcBandMaxResult.mcoBwDl,
                ccCauseCodesTab, bcBandPermResult.ccIdxBitmask);

            if (checkBcBandPermUlBw)
            {
                FnVCCB_McoCheckMaxUlBwBcBandAgainstSingleCcPerm(ccInfoVec, bcBandInfoDq, colocCcIdxTab,
                    colocCcIdxTab + sumBcBandNumContiguousCcDL, bcBandPermResult.ccIdxBitmask, maxUlBw, maxUlBwPcellIdxBitmask);
                if (bcBandMaxResult.mcoBwUl < maxUlBw)
                {
                    bcBandMaxResult.mcoBwUl = maxUlBw;
                    bcBandMaxResult.maxUlBwPcellIdxBitmask = maxUlBwPcellIdxBitmask;
                }
                else if (bcBandMaxResult.mcoBwUl == maxUlBw)
                {
                    bcBandMaxResult.maxUlBwPcellIdxBitmask |= maxUlBwPcellIdxBitmask;
                }
            }

            // all CC was used -> maximum BW found, stop checking
            if (ccInfoVecSize == bcBandPermResult.ccCnt)
            {
                VCCB_PRINT_CALL_MCO_BCBANDPERM(ptCi, "[MCO] All CC accepted - BREAK\n");
                break;
            }
        } while (std::next_permutation(colocCcIdxTab, colocCcIdxTab + sumBcBandNumContiguousCcDL));
    }

    result = bcBandMaxResult;
    if ((nullptr != pBcBandResultsCache) && (false == pBcBandResultsCache->setResult(bcBandKey, bcBandMaxResult)))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[MCO] Set result to cache key(0x%016lx%016lx) failed!\n",
                static_cast<uint64_t>(bcBandKey>>64), static_cast<uint64_t>(bcBandKey));
    }

    return true;
}

/**
 * @brief   MCO: Set ulFlag considering uplink CA bandwidth class possible permutations. Refer to
 *          supportedBandCombinationList 3GPP TS 38.306.
 */
void FnVCCB_McoSetPcellUlFlagByUlCaBwPermutations(
    const mcoBand2mcoNumContiguousCc_type &band2numContiguousCcUL, mcoBand2numContCcDq_type &mcoBand2numContCcDq)
{
    AUTO_TRACE_FUNC;

    for (const mcoBand2mcoNumContiguousCc_type::value_type &kv : band2numContiguousCcUL)
    {
        mcoBcBandInfoDq_type &bcBandInfoDq = mcoBand2numContCcDq[kv.first];
        for (mcoUeCapaBcBandInfo_s &bcBandInfo : bcBandInfoDq)
        {
            // One band combination entry can also indicate support of any other possible permutations in the presence
            // of uplink CA bandwidth class where a paired downlink CA bandwidth class is the same or where the number
            // of UL CCs is smaller than the one of paired DL CCs expressed by the CA bandwidth class.
            if (kv.second <= bcBandInfo.numContiguousCcDL)
            {
                bcBandInfo.ulFlag = true;
            }
        }
    }
}

/**
 * @brief   MCO: Retrieve BC data from BandCombination_type for a given RAT type.
            Distinguish DL bandwidth class, UL availability, DL MIMO layer number.
            Use it in pair with mcoCheckBcBandResultsCache_s::makeBcBandKey function.
 */
void FnVCCB_McoRetrieveBcData(callInfo_type *ptCi, const BandCombination_type &bc, const uint32_t bcIndex,
    const enumRAT_type ratType, const McoAlgoFlags &algoFlags, mcoBand2numContCcDq_type &mcoBand2numContCcDqOut,
    mcoBand2mcoNumContiguousCc_type &band2numContiguousCcULOut)
{
    AUTO_TRACE_FUNC;

    mcoBand2numContCcDqOut.clear();
    band2numContiguousCcULOut.clear();

    VALID_E_POINT_CHECK_VOID(ptCi);

    const uint8_t bandNum = MIN(bc.num, MAX_BANDS_PER_COMB);
    for (uint8_t bandIdx = 0; bandIdx < bandNum; bandIdx++)
    {
        const BandParameters_type &bcBand = bc.band[bandIdx];

        // skip not related RAT type
        if (ratType != bcBand.ratType)
        {
            continue;
        }

        if (algoFlags.ulOnlyMode && (CA_BandwidthClassNR_NOT_SET == bcBand.nrCaBandwidthClassUL))
        {
            VCCB_PRINT_CALL_MCO_CHECKBC(ptCi, "[MCO][UL ONLY MODE] band-%s(%d) in BC idx(%u) skipped due to no UL BW Class!\n",
                    (ci_nr == bc.band[bandIdx].ratType) ? "NR" : "EUTRA",
                    bcBand.freqBandIndicator, bcIndex);
            continue;
        }

        const uint8_t dlMimoLayerNum = (((ci_nr == bcBand.ratType) && (false == algoFlags.noMimo)) ?
            FnVCCB_McoGetDlMimoLayerForBestBcSelection(ptCi, bcIndex, bcBand.freqBandIndicator, bandIdx) : 1);

        mcoBcBandInfoDq_type &bcBandInfoDq = mcoBand2numContCcDqOut[bcBand.freqBandIndicator];
        bcBandInfoDq.push_back(
            mcoUeCapaBcBandInfo_s(algoFlags.ulOnlyMode ? bcBand.numContiguousCcUL : bcBand.numContiguousCcDL,
                                  bcBand.numContiguousCcUL,
                                  dlMimoLayerNum));

        if (0 < bcBand.numContiguousCcUL)
        {
            // Get existing value or add new value(0) created by default ctor
            uint8_t &numContiguousCcULMin = band2numContiguousCcULOut[bcBand.freqBandIndicator];

            if ((0 == numContiguousCcULMin) || (bcBand.numContiguousCcUL < numContiguousCcULMin))
            {
                numContiguousCcULMin = bcBand.numContiguousCcUL;
            }
        }
    }

    FnVCCB_McoSetPcellUlFlagByUlCaBwPermutations(band2numContiguousCcULOut, mcoBand2numContCcDqOut);

    // Sort for cache key unification.
    for (mcoBand2numContCcDq_type::value_type &kv : mcoBand2numContCcDqOut)
    {
        std::sort(kv.second.begin(), kv.second.end(), [](const mcoUeCapaBcBandInfo_s &lhs, const mcoUeCapaBcBandInfo_s &rhs)
            {
                return ((lhs.numContiguousCcDL > rhs.numContiguousCcDL) ||
                        ((lhs.numContiguousCcDL == rhs.numContiguousCcDL) && (lhs.dlMimoLayerNum > rhs.dlMimoLayerNum)) ||
                        ((lhs.numContiguousCcDL == rhs.numContiguousCcDL) && (lhs.dlMimoLayerNum == rhs.dlMimoLayerNum) &&
                         (lhs.ulFlag > rhs.ulFlag)));
            });
    }
}

/**
 * @brief   MCO: Retrieve BC data from BandCombination_type for a given RAT type.
            Distinguish DL and UL bandwidth class.
            Use it in pair with mcoCheckBcBandResultsCache_s::makeBcBandKeyDlUl function.
 */
void FnVCCB_McoRetrieveBcDataDlUl(const BandCombination_type &bc, const enumRAT_type ratType, const uint16_t pcellBand,
    mcoBand2numContCcDq_type &mcoBand2numContCcDqOut, bool &ulPcellBandFlag)
{
    AUTO_TRACE_FUNC;

    mcoBand2numContCcDqOut.clear();
    ulPcellBandFlag = false;

    const uint8_t bandNum = MIN(bc.num, MAX_BANDS_PER_COMB);
    for (uint8_t bandIdx = 0; bandIdx < bandNum; bandIdx++)
    {
        const BandParameters_type &bcBand = bc.band[bandIdx];

        // skip not related RAT type
        if (ratType != bcBand.ratType)
        {
            continue;
        }

        mcoBcBandInfoDq_type &bcBandInfoDq = mcoBand2numContCcDqOut[bcBand.freqBandIndicator];
        bcBandInfoDq.push_back(mcoUeCapaBcBandInfo_s(bcBand.numContiguousCcDL, bcBand.numContiguousCcUL, 1));
        ulPcellBandFlag |= ((pcellBand == bcBand.freqBandIndicator) && (0 < bcBand.numContiguousCcUL));
    }

    // Sort for cache key unification.
    for (mcoBand2numContCcDq_type::value_type &kv : mcoBand2numContCcDqOut)
    {
        std::sort(kv.second.begin(), kv.second.end(), [](const mcoUeCapaBcBandInfo_s &lhs, const mcoUeCapaBcBandInfo_s &rhs)
            {
                return ((lhs.numContiguousCcDL > rhs.numContiguousCcDL) ||
                        ((lhs.numContiguousCcDL == rhs.numContiguousCcDL) && (lhs.numContiguousCcUL > rhs.numContiguousCcUL)));
            });
    }
}

/**
 * @brief   MCO: Check all BC against CC NR
 */
void FnVCCB_McoCheckAllBcAgainstCcNr(callInfo_type *ptCi, const bandCombinationList_type &ueSupBandCombList,
    const uint16_t pcellBand, const uint16_t pscellBand, const mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBand,
    const McoAlgoFlags &algoFlags, mcoBand2BcBandResultsCache_s &mcoBand2BcBandResultsCache,
    McoBCIdxArray_type &bcBwMaxIdxDqOut, uint32_t &bcBwMaxOut)
{
    AUTO_TRACE_FUNC;
    bcBwMaxIdxDqOut.clear();
    bcBwMaxOut = 0;

    VALID_E_POINT_CHECK_VOID(ptCi);

    uint32_t bcBw = 0, bcBwMax = 0;
    mcoCheckBcResult_s bcBandResult;
    char ccCauseCodesTab[MAX_MCO_CCNUM + 1];

    if ((DBG->flag.logMcoCheckBc) && (false == algoFlags.noMimo))
    {
        VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);
        const VccbGnbInfo_type &rGnb = GNBINFO[ptCi->gnbNum];
        VCCB_PRINT_CALL_MCO_CHECKBC(ptCi, "[MCO] DL MIMO Coefficients: 1_layer(%f) 2_layers(%f) 4_layers(%f)\n",
            rGnb.carrierAggregationInfo.dl1LayerWeightFactor, rGnb.carrierAggregationInfo.dl2LayerWeightFactor,
            rGnb.carrierAggregationInfo.dl4LayerWeightFactor);
    }

    auto fnCheckBcAgainstCcNr = [&](uint32_t bcIdx)
    {
        mcoBand2numContCcDq_type mcoBand2numContCcDq;

        if (algoFlags.checkUlBw)
        {
            bool ulPcellBandFlag = false;
            FnVCCB_McoRetrieveBcDataDlUl(ueSupBandCombList.bandCombination[bcIdx], ci_nr, pcellBand, mcoBand2numContCcDq,
                ulPcellBandFlag);

            if (DBG->flag.logMcoCheckBc)
            {
                for (const mcoBand2numContCcDq_type::value_type &kv : mcoBand2numContCcDq)
                {
                    VCCB_PRINT_CALL_MCO_CHECKBC(ptCi, "====== [MCO] UE Capa BC idx(%u) band-NR(%u) ======\n", bcIdx, kv.first);
                    for (const mcoUeCapaBcBandInfo_s &bcBandInfo : kv.second)
                    {
                        VCCB_PRINT_CALL_MCO_CHECKBC(
                                                    ptCi, "numContiguousCc DL(%u)/UL(%u)\n", bcBandInfo.numContiguousCcDL, bcBandInfo.numContiguousCcUL);
                    }
                }
            }

            if (false == ulPcellBandFlag)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi,
                    "[MCO][BCSel] BC idx(%u) NR check: not eligible for PCell's band-NR(%u) - skip\n", bcIdx, pcellBand);
                return;
            }
        }
        else
        {
            mcoBand2mcoNumContiguousCc_type band2numContiguousCcUL;

            FnVCCB_McoRetrieveBcData(
                ptCi, ueSupBandCombList.bandCombination[bcIdx], bcIdx, ci_nr, algoFlags, mcoBand2numContCcDq, band2numContiguousCcUL);

            if (DBG->flag.logMcoCheckBc)
            {
                for (const mcoBand2numContCcDq_type::value_type &kv : mcoBand2numContCcDq)
                {
                    VCCB_PRINT_CALL_MCO_CHECKBC(ptCi, "====== [MCO] UE Capa BC idx(%u) band-NR(%u) ======\n", bcIdx, kv.first);
                    for (const mcoUeCapaBcBandInfo_s &bcBandInfo : kv.second)
                    {
                        VCCB_PRINT_CALL_MCO_CHECKBC(ptCi, "numContiguousCc%s(%u) ulFlag(%u) DL_MIMO(%u)\n",
                                                    algoFlags.ulOnlyMode ? "UL" : "DL",
                                                    bcBandInfo.numContiguousCcDL,
                                                    bcBandInfo.ulFlag, bcBandInfo.dlMimoLayerNum);
                    }
                }
            }

            const bool pcellEligible = (band2numContiguousCcUL.end() != band2numContiguousCcUL.find(pcellBand));
            if (false == pcellEligible)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi,
                    "[MCO][BCSel] BC idx(%u) NR check: not eligible for PCell's band-NR(%u) - skip\n", bcIdx, pcellBand);
                return;
            }

            const bool pscellNotEligible = ((BAND_NOT_FOUND != pscellBand) &&
                (band2numContiguousCcUL.end() == band2numContiguousCcUL.find(pscellBand)));
            if (pscellNotEligible)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi,
                    "[MCO][BCSel] BC idx(%u) NR check: not eligible for PSCell's band-NR(%u) - skip\n", bcIdx, pscellBand);
                return;
            }
        }

        // check one BC-Band against NR CC
        bcBw = 0;
        for (mcoBand2numContCcDq_type::value_type &kv : mcoBand2numContCcDq)
        {
            const uint16_t band = kv.first;
            VCCB_PRINT_CALL_MCO_CHECKBC(
                ptCi, "====== [MCO] Check UE Capa BC idx(%u) band-NR(%u) ======\n", bcIdx, band);

            mcoBand2mcoCcInfoVecMap_type::const_iterator ccInfoVecPerBandIt = ccInfoVecPerBand.find(band);
            if (ccInfoVecPerBand.end() == ccInfoVecPerBandIt)
            {
                VCCB_PRINT_CALL_MCO_CHECKBC(ptCi, "[MCO] BC idx(%u) band-NR(%u) check: No CC\n", bcIdx, band);
                continue;
            }

            const mcoCcInfoVec_type &ccInfoVec = ccInfoVecPerBandIt->second.ccInfoVec;
            const bool checkPcell = (pcellBand == band);
            mcoCheckBcBandResultsCache_s *pBcBandCache = mcoBand2BcBandResultsCache.getForBand(ci_nr, band);

            if (false == FnVCCB_McoCheckBcBandAgainstCcList(
                ptCi, ccInfoVec, kv.second, checkPcell, ccCauseCodesTab, pBcBandCache, algoFlags.checkUlBw, algoFlags.noMimo, bcBandResult))
            {
                VCCB_PRINT_CALL_MCO_CHECKBC(
                    ptCi, "[MCO] BC idx(%u) band-NR(%u) check: inadequate result!\n", bcIdx, band);
                continue;
            }

            VCCB_PRINT_CALL_MCO_CHECKBC(ptCi, "[MCO] BC idx(%u) band-NR(%u) check: BW(%u) cause(%s) ccidx(0x%lx)\n",
                bcIdx, band, bcBandResult.mcoBwDl, ccCauseCodesTab, bcBandResult.ccIdxBitmask);

            bcBw += bcBandResult.mcoBwDl;
        }

        if (bcBw > bcBwMax)
        {
            bcBwMax = bcBw;
            bcBwMaxIdxDqOut.clear();
            MCO_ARRAY_PUSH_BACK_CONTINUE(bcBwMaxIdxDqOut, bcIdx);
        }
        else if (bcBw == bcBwMax)
        {
            MCO_ARRAY_PUSH_BACK_CONTINUE(bcBwMaxIdxDqOut, bcIdx);
        }
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO][BCSel] BC idx(%u) NR check: BW(%u) vs maxBW(%u)\n", bcIdx, bcBw, bcBwMax);
    };

    const uint32_t bcNum = MIN(ueSupBandCombList.num, MAX_BAND_COMBS);
    if (((E_CALLTYPE_NSA == ptCi->callType) || (IS_NRDC_SN(ptCi))) &&
        (VCCB_FLAG_ON == ptCi->cgConfigInfo.configRestrictInfoFlag) &&
        (VCCB_FLAG_ON == ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC_Flag))
    {
        const bandCombinationInfoList_type &allowedBC = ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC;
        const uint16_t allowedBcNum = MIN(allowedBC.nrofBandComb, MAX_NUM_BAND_COMB);

        for (uint32_t allowedBcIdx = 0; allowedBcIdx < allowedBcNum; allowedBcIdx++)
        {
            uint32_t bcIdx = allowedBC.bandCombinationInfo[allowedBcIdx].bandCombinationIndex - 1U;
            VCCB_CHECK_E_RANGE_AND_CONTINUE(bcIdx, bcNum);
            fnCheckBcAgainstCcNr(bcIdx);
        }
    }
    else if((E_CALLTYPE_SA == ptCi->callType) && (MRS_CHECK_INTER_RAT_HO == ptCi->mrsInfo.mrsState))
    {
        const uint32_t selecteBc = VLIB_GetDuSelectionRelatedData(*ptCi).selectedBC;
        if((0 < selecteBc) && (selecteBc <= bcNum))
        {
            fnCheckBcAgainstCcNr(selecteBc - 1);
        }
        else
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[MRS] Invalid selecteBc :%d\n", selecteBc);
            return;
        }
    }
    else if ((IS_NRDC_MN(ptCi)) &&
             (IS_NOT_MRDC_SCG_RELEASE_ONGOING(ptCi)) &&
             (0 != ptCi->mrdcInfo.selectedBC.bandCombinationIndex))
    {
        // NR-DC, MN Case
        if (0 == ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC.nrofBandCombFilteredSelectedBc)
        {
            const uint32_t bcIdx = ptCi->mrdcInfo.selectedBC.bandCombinationIndex - 1;
            VCCB_CHECK_E_RANGE_AND_VOID(bcIdx, MAX_BAND_COMBS);

            VCCB_PRINT_CALL_LOG_MRDC(ptCi, "[NRDC] NR-DC(MN), using selectedBCIdx(%u)\n", bcIdx);

            fnCheckBcAgainstCcNr(bcIdx);
        }
        else
        {
            const bandCombinationInfoList_type &allowedBC = ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC;
            const uint16_t filteredAllowedBcNum = MIN(allowedBC.nrofBandCombFilteredSelectedBc, MAX_NUM_BAND_COMB);

            for (uint32_t allowedBcIdx = 0; allowedBcIdx < filteredAllowedBcNum; allowedBcIdx++)
            {
                uint32_t bcIdx = allowedBC.bandCombinationInfoFilteredSelectedBc[allowedBcIdx].bandCombinationIndex - 1U;
                VCCB_CHECK_E_RANGE_AND_CONTINUE(bcIdx, bcNum);
                fnCheckBcAgainstCcNr(bcIdx);
            }
        }
    }
    else
    {
        for (uint32_t bcIdx = 0; bcIdx < bcNum; bcIdx++)
        {
            fnCheckBcAgainstCcNr(bcIdx);
        }
    }
    bcBwMaxOut = bcBwMax;
    VCCB_PRINT_CALL_MCO_CHECKBC(ptCi, "[MCO] Calculated Result Max BW (%u)\n", bcBwMaxOut);
}

/**
 * @brief   MCO: Check selected BC against CC EUTRA
 */
void FnVCCB_McoCheckSelectedBcAgainstCcEutra(callInfo_type *ptCi, const bandCombinationList_type &ueSupBandCombList,
    const uint16_t mcgPcellBand, const mcoBand2mcoCcInfoVecMap_type &mcoCcInfoVecPerBand,
    const McoBCIdxArray_type &selectedBcIdxDq, mcoBand2BcBandResultsCache_s &mcoBand2BcBandResultsCache,
    McoBCIdxArray_type &bcMaxCcCntIdxDqOut)
{
    AUTO_TRACE_FUNC;
    bcMaxCcCntIdxDqOut.clear();

    VALID_E_POINT_CHECK_VOID(ptCi);

    uint32_t ccCntMax = 0, ccCnt = 0;
    mcoCheckBcResult_s bcBandResult;
    char ccCauseCodesTab[MAX_MCO_CCNUM + 1];

    McoAlgoFlags algoFlags = { .noMimo = false,
                               .checkUlBw = false,
                               .ulOnlyMode = false,
                               .mfbiCheck = false,
                               .initialFmPcc = false,
                               .checkCarrierOnly = false,
                               .useSe = false,
                               .useMultiChBw = false };

    for (uint32_t bcIdx : selectedBcIdxDq)
    {
        VCCB_CHECK_E_RANGE_AND_CONTINUE(bcIdx, MAX_BAND_COMBS);

        mcoBand2numContCcDq_type mcoBand2numContCcDq;
        mcoBand2mcoNumContiguousCc_type band2numContiguousCcUL;

        FnVCCB_McoRetrieveBcData(
            ptCi, ueSupBandCombList.bandCombination[bcIdx], bcIdx, ci_eutra, algoFlags, mcoBand2numContCcDq, band2numContiguousCcUL);

        for (mcoBand2numContCcDq_type::value_type &kv : mcoBand2numContCcDq)
        {
            VCCB_PRINT_CALL_MCO_CHECKBC(
                ptCi, "====== [MCO] UE Capa BC idx(%u) band-EUTRA(%u) ======\n", bcIdx, kv.first);
            for (mcoUeCapaBcBandInfo_s &bcBandInfo : kv.second)
            {
                VCCB_PRINT_CALL_MCO_CHECKBC(
                    ptCi, "numContiguousCcDL(%u) ulFlag(%u) DL_MIMO(%u)\n", bcBandInfo.numContiguousCcDL, bcBandInfo.ulFlag, bcBandInfo.dlMimoLayerNum);
            }
        }

        const bool mcgPcellEligible = (band2numContiguousCcUL.end() != band2numContiguousCcUL.find(mcgPcellBand));
        if (false == mcgPcellEligible)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[MCO][BCSel] BC idx(%u) MCG check: not eligible for MCG PCell's band-EUTRA(%u) - skip\n", bcIdx,
                mcgPcellBand);
            continue;
        }

        // check one BC-Band against MCG CC
        ccCnt = 0;
        for (mcoBand2numContCcDq_type::value_type &kv : mcoBand2numContCcDq)
        {
            VCCB_PRINT_CALL_MCO_CHECKBC(
                ptCi, "====== [MCO] Check UE Capa BC idx(%u) band-EUTRA(%u) ======\n", bcIdx, kv.first);

            mcoBand2mcoCcInfoVecMap_type::const_iterator ccInfoVecPerBandIt = mcoCcInfoVecPerBand.find(kv.first);
            if (mcoCcInfoVecPerBand.end() == ccInfoVecPerBandIt)
            {
                VCCB_PRINT_CALL_MCO_CHECKBC(ptCi, "[MCO] BC idx(%u) band-EUTRA(%u) check: No CC\n", bcIdx, kv.first);
                continue;
            }

            const mcoCcInfoVec_type &ccInfoVec = ccInfoVecPerBandIt->second.ccInfoVec;
            const bool checkPcell = (mcgPcellBand == kv.first);
            mcoCheckBcBandResultsCache_s *pBcBandCache = mcoBand2BcBandResultsCache.getForBand(ci_eutra, kv.first);

            if (false == FnVCCB_McoCheckBcBandAgainstCcList(
                    ptCi, ccInfoVec, kv.second, checkPcell, ccCauseCodesTab, pBcBandCache, false, false, bcBandResult))
            {
                VCCB_PRINT_CALL_MCO_CHECKBC(
                    ptCi, "[MCO] BC idx(%u) band-EUTRA(%u) check: inadequate result!\n", bcIdx, kv.first);
                continue;
            }
            VCCB_PRINT_CALL_MCO_CHECKBC(ptCi,
                "[MCO] BC idx(%u) band-EUTRA(%u) check: ccCnt(%u) cause(%s) ccidx(0x%lx)\n", bcIdx, kv.first,
                bcBandResult.ccCnt, ccCauseCodesTab, bcBandResult.ccIdxBitmask);
            ccCnt += bcBandResult.ccCnt;
        }

        if (ccCnt > ccCntMax)
        {
            ccCntMax = ccCnt;
            bcMaxCcCntIdxDqOut.clear();
            MCO_ARRAY_PUSH_BACK_CONTINUE(bcMaxCcCntIdxDqOut, bcIdx);
        }
        else if (ccCnt == ccCntMax)
        {
            MCO_ARRAY_PUSH_BACK_CONTINUE(bcMaxCcCntIdxDqOut, bcIdx);
        }
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "[MCO][BCSel] BC idx(%u) MCG check: ccCnt(%u) vs ccCntMax(%u)\n", bcIdx, ccCnt, ccCntMax);
    }
}

/**
 * @brief     Get FeatureSetPerBand from FeatureSetCombination.
 */
const MrdcFeatureSetPerBand_type *FnVCCB_McoGetFeatureSetPerBand(
    const BandCombination_type &bc, const MrdcFeatureSetCombination_type &fsCombination, const uint16_t bandNr)
{
    AUTO_TRACE_FUNC;

    std::size_t fsPerBandIdx = 0;
    const std::size_t maxLoop = MIN(MIN(VCCB_ARRAY_COUNT(bc.band), bc.num),
        MIN(VCCB_ARRAY_COUNT(fsCombination.featureSetPerBand), fsCombination.num));
    for (fsPerBandIdx = 0; fsPerBandIdx < maxLoop; ++fsPerBandIdx)
    {
        if ((ci_nr != bc.band[fsPerBandIdx].ratType) || (bandNr != bc.band[fsPerBandIdx].freqBandIndicator))
        {
            continue;
        }

        const MrdcFeatureSetPerBand_type &fsPerBand = fsCombination.featureSetPerBand[fsPerBandIdx];
        if (ci_nr == fsPerBand.ratType)
        {
            return &fsPerBand;
        }
    }

    return nullptr;
}

/**
 * @brief     Read max supported MIMO layers from FeatureSets.
 */
int16_t FnVCCB_McoGetMaxNumberMIMOLayersFromFeatureSets(callInfo_type *ptCi, uint16_t dlSetId, NRRRC_MIMO_LayersDL *ptMaxMimoLayers)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMaxMimoLayers);

    --dlSetId;  // dlSetId is 1 based

    FeatureSets_type *ptFeatureSets = VRIL_GetFeatureSetList(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptFeatureSets);
    VCCB_CHECK_E_RANGE_AND_RETURN(
        dlSetId, MIN(VCCB_ARRAY_COUNT(ptFeatureSets->featureSetsDownlink), ptFeatureSets->nrOfFeatureSetsDownlink));
    VCCB_CHECK_E_RANGE_AND_RETURN(0, ptFeatureSets->featureSetsDownlink[dlSetId].nrOfFeatureSetPerCCIds);

    const unsigned int dlSetPerCCId =
        ptFeatureSets->featureSetsDownlink[dlSetId].featureSetDownlinkPerCCIds[0] - 1U;  // dlSetPerCCId is 1 based
    VCCB_CHECK_E_RANGE_AND_RETURN(dlSetPerCCId,
        MIN(VCCB_ARRAY_COUNT(ptFeatureSets->featureSetsDownlinkPerCC), ptFeatureSets->nrOfFeatureSetsDownlinkPerCC));
    if (TRUE != ptFeatureSets->featureSetsDownlinkPerCC[dlSetPerCCId].maxNumberMIMO_LayersPDSCH_present)
    {
        return ERROR;
    }

    *ptMaxMimoLayers =
        (NRRRC_MIMO_LayersDL)ptFeatureSets->featureSetsDownlinkPerCC[dlSetPerCCId].maxNumberMIMO_LayersPDSCH;
    return GOOD;
}

/**
 * @brief     Read maximal supported MIMO layers from UE capa (version for SA).
 * @param     ptCi : call context
 * @param     selectedBcIndex : band combination index
 * @param     bandNr : checked band
 * @param     fsPerBandIdx : index of Feature Set per band. Use MAX_BANDS_PER_COMB if unknown.
 * @param     [out] ptMaxMimoLayers : pointer to max UE supported MIMO layers - will be filled if function returns GOOD
 * @return    int16_t : ERROR(when unable to read) or GOOD
 */
int16_t FnVCCB_GetMaxNumberMIMOLayersForSa(callInfo_type *ptCi,
    uint32_t selectedBcIndex, uint16_t bandNr, uint16_t fsPerBandIdx, NRRRC_MIMO_LayersDL *ptMaxMimoLayers)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMaxMimoLayers);

    bandCombinationList_type *ptUeSupBandCombList = VRIL_GetBandCombinationList(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUeSupBandCombList);
    uint16_t ueSupBandCombListSize = VCCB_ARRAY_COUNT(ptUeSupBandCombList->bandCombination);

    MrdcFeatureSetCombinationList_type *ptFsCombinationList = VRIL_GetFeatureSetCombinationList(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptFsCombinationList);
    uint16_t fsCombinationListSize = VCCB_ARRAY_COUNT(ptFsCombinationList->mrdcFeatureSetCombination);

    VCCB_CHECK_E_RANGE_AND_RETURN(
        selectedBcIndex, MIN(ueSupBandCombListSize, ptUeSupBandCombList->num));

    const BandCombination_type &bc = ptUeSupBandCombList->bandCombination[selectedBcIndex];
    VCCB_CHECK_E_RANGE_AND_RETURN(bc.featureSetCombination,
        MIN(fsCombinationListSize, ptFsCombinationList->num));
    MrdcFeatureSetCombination_type &fsCombination =
        ptFsCombinationList->mrdcFeatureSetCombination[bc.featureSetCombination];

    const MrdcFeatureSetPerBand_type *ptFsPerBand = nullptr;
    if (MIN(VCCB_ARRAY_COUNT(fsCombination.featureSetPerBand), fsCombination.num) > fsPerBandIdx)
    {
        ptFsPerBand = &fsCombination.featureSetPerBand[fsPerBandIdx];
    }
    else
    {
        ptFsPerBand = FnVCCB_McoGetFeatureSetPerBand(bc, fsCombination, bandNr);
        VALID_E_POINT_CHECK_ERROR(ptFsPerBand);
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(0, ptFsPerBand->num);

    if (ERROR == FnVCCB_McoGetMaxNumberMIMOLayersFromFeatureSets(ptCi, ptFsPerBand->featureSet[0].dlSetId, ptMaxMimoLayers))
    {
        return ERROR;
    }

    return GOOD;
}

/**
 * @brief     Read maximal supported MIMO layers from UE capa (version for ENDC).
 * @param     ptCi : call context
 * @param     selectedBcIndex : band combination index
 * @param     bandNr : checked band
 * @param     fsPerBandIdx : index of Feature Set per band. Use MAX_BANDS_PER_COMB if unknown.
 * @param     [out] ptMaxMimoLayers : pointer to max UE supported MIMO layers - will be filled if function returns GOOD
 * @return    int16_t : ERROR(when unable to read) or GOOD
 */
int16_t FnVCCB_GetMaxNumberMIMOLayersForEndc(callInfo_type *ptCi, uint32_t selectedBcIndex, uint16_t bandNr,
    uint16_t fsPerBandIdx, NRRRC_MIMO_LayersDL *ptMaxMimoLayers)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMaxMimoLayers);

    configRestrictInfoSCG_type &configRestrictInfo = ptCi->cgConfigInfo.configRestrictInfo;

    bandCombinationList_type *ptBandCombList = VRIL_GetBandCombinationList(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptBandCombList);

    MrdcFeatureSetCombinationList_type *ptFsCombinationList = VRIL_GetFeatureSetCombinationList(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptFsCombinationList);

    VCCB_CHECK_E_RANGE_AND_RETURN(selectedBcIndex,
            MIN(VCCB_ARRAY_COUNT(ptBandCombList->bandCombination),ptBandCombList->num));

    BandCombination_type &bc = ptBandCombList->bandCombination[selectedBcIndex];
    VCCB_CHECK_E_RANGE_AND_RETURN(bc.featureSetCombination,
            MIN(VCCB_ARRAY_COUNT(ptFsCombinationList->mrdcFeatureSetCombination),ptFsCombinationList->num));
    MrdcFeatureSetCombination_type &fsCombination = ptFsCombinationList->mrdcFeatureSetCombination[bc.featureSetCombination];

    const MrdcFeatureSetPerBand_type *ptFsPerBand = nullptr;
    if (MIN(VCCB_ARRAY_COUNT(fsCombination.featureSetPerBand), fsCombination.num) > fsPerBandIdx)
    {
        ptFsPerBand = &fsCombination.featureSetPerBand[fsPerBandIdx];
    }
    else
    {
        ptFsPerBand = FnVCCB_McoGetFeatureSetPerBand(bc, fsCombination, bandNr);
        VALID_E_POINT_CHECK_ERROR(ptFsPerBand);
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(0, ptFsPerBand->num);

    uint16_t dlSetId = MAX_NUM_DL_FEATURESET;

    // when allowedBC list was received try to find FeatureSetIdx in allowedFeatureSets
    if (VCCB_FLAG_ON == configRestrictInfo.allowedBC_ListMRDC_Flag)
    {
        bandCombinationInfo_type *ptBcInfo = nullptr;
        for (uint16_t bcInfoIdx = 0;
             bcInfoIdx < MIN(VCCB_ARRAY_COUNT(configRestrictInfo.allowedBC_ListMRDC.bandCombinationInfo),
                             configRestrictInfo.allowedBC_ListMRDC.nrofBandComb);
             ++bcInfoIdx)
        {
            if (selectedBcIndex ==
                (uint32_t)(configRestrictInfo.allowedBC_ListMRDC.bandCombinationInfo[bcInfoIdx].bandCombinationIndex - 1))
            {
                ptBcInfo = &configRestrictInfo.allowedBC_ListMRDC.bandCombinationInfo[bcInfoIdx];
                break;
            }
        }

        if (nullptr != ptBcInfo)
        {
            for (uint16_t fsIdx = 0; fsIdx < MIN(VCCB_ARRAY_COUNT(ptFsPerBand->featureSet), ptFsPerBand->num); ++fsIdx)
            {
                if (GETBIT_U8TABLE(ptBcInfo->allowedFeatureSetsBitmask, fsIdx))
                {
                    dlSetId = ptFsPerBand->featureSet[fsIdx].dlSetId;
                    break;
                }
            }
        }
    }

    // dlSetId not available in allowedFeatureSets. Use feature set from under index 0
    if (MAX_NUM_DL_FEATURESET == dlSetId)
    {
        dlSetId = ptFsPerBand->featureSet[0].dlSetId;
    }

    if (ERROR == FnVCCB_McoGetMaxNumberMIMOLayersFromFeatureSets(ptCi, dlSetId, ptMaxMimoLayers))
    {
        return ERROR;
    }

    return GOOD;
}

/**
 * @brief     Get DL MIMO layer number for best BC selection.
 *            min (UE maxNumberMIMO-LayersPDSCH, 4(FR1) or 2(FR2))
 *            where maxNumberMIMO-LayersPDSCH MIMO-LayersDL
 *            MIMO-LayersDL ::=   ENUMERATED {twoLayers, fourLayers, eightLayers}
 * @param     ptCi : call context
 * @param     bcIndex : band combination index (0-based)
 * @param     bandNr : checked band
 * @param     fsPerBandIdx : index of Feature Set per band. Use MAX_BANDS_PER_COMB if unknown.
 * @return    uint8_t : 1(no MIMO), 2 or 4
 */
uint8_t FnVCCB_McoGetDlMimoLayerForBestBcSelection(callInfo_type *ptCi, uint32_t bcIndex, uint16_t bandNr, uint16_t fsPerBandIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, NO_MIMO_LAYERS);

    const uint8_t max_fr_dl_mimo_layers =
        ((MAX_FR1_NR_BAND < bandNr) ? MAX_FR2_DL_MIMO_LAYERS : MAX_FR1_DL_MIMO_LAYERS);
    NRRRC_MIMO_LayersDL maxUeDlMimoLayersEnum;
    int16_t status;

    if (E_CALLTYPE_SA == ptCi->callType)
    {
        status = FnVCCB_GetMaxNumberMIMOLayersForSa(ptCi, bcIndex, bandNr, fsPerBandIdx, &maxUeDlMimoLayersEnum);
    }
    else
    {
        status = FnVCCB_GetMaxNumberMIMOLayersForEndc(ptCi, bcIndex, bandNr, fsPerBandIdx, &maxUeDlMimoLayersEnum);
    }
    if (GOOD != status)
    {
        // The UE does not support MIMO on this carrier.
        return NO_MIMO_LAYERS;
    }

    uint8_t dlUeMimoLayerNum = NO_MIMO_LAYERS;
    switch (maxUeDlMimoLayersEnum)
    {
        case NRRRC_MIMO_LayersDL_twoLayers:
            dlUeMimoLayerNum = 2;
            break;

        case NRRRC_MIMO_LayersDL_fourLayers:
            dlUeMimoLayerNum = 4;
            break;

        case NRRRC_eightLayers:
            dlUeMimoLayerNum = 8;
            break;

        default:
            dlUeMimoLayerNum = NO_MIMO_LAYERS;
            break;
    }

    return std::min(max_fr_dl_mimo_layers, dlUeMimoLayerNum);
}

/**
 * @brief     Calculate effective bandwidth for single band
 * @param     ccInfoVecPerBand : reference to vector of cells
 * @param     ccIdxBitmask : bit mask of selected cells in ccInfoVecPerBand
 * @param     ccMimo4Bitmask : bit mask of selected cells indicating 4 layers DL
 * @return    uint32_t : calculated effective bandwidth for single band
 */
uint32_t FnVCCB_GetEffectiveBwOfSingleBand(const VccbGnbInfo_type &rGnb,
    const mcoCcInfoVec_type &ccInfoVec, const uint64_t ccIdxBitmask, const uint64_t ccMimo2Bitmask, const uint64_t ccMimo4Bitmask, const vector<uint32_t> &sCellFreqList)
{
    AUTO_TRACE_FUNC;

    uint32_t effectiveBw = 0;
    uint16_t loop = 0;

    const std::size_t ccInfoCount = ccInfoVec.size();
    const std::size_t sCellFreqCount = sCellFreqList.size();

    for (uint16_t ccIdx = 0; ccIdx < ccInfoCount; ++ccIdx)
    {
        if (ccIdxBitmask & (1ULL << ccIdx))
        {
            // If released Scell Freq, except expectedBW
            if( 0 < sCellFreqCount )
            {
                for(loop = 0; loop < sCellFreqCount; loop++ )
                {
                    if(sCellFreqList[loop] == ccInfoVec.at(ccIdx).userValue)
                    {
                        break;
                    }
                }
                if(loop < sCellFreqCount)
                {
                    continue;
                }
            }

            if (ccMimo4Bitmask & (1ULL << ccIdx))
            {
                effectiveBw += static_cast<uint16_t>(((double)ccInfoVec.at(ccIdx).mcoBwDl * rGnb.carrierAggregationInfo.dl4LayerWeightFactor) + 0.5);
            }
            else if (ccMimo2Bitmask & (1ULL << ccIdx))
            {
                effectiveBw += static_cast<uint16_t>(((double)ccInfoVec.at(ccIdx).mcoBwDl * rGnb.carrierAggregationInfo.dl2LayerWeightFactor) + 0.5);
            }
            else
            {
                effectiveBw += static_cast<uint16_t>(((double)ccInfoVec.at(ccIdx).mcoBwDl * rGnb.carrierAggregationInfo.dl1LayerWeightFactor) + 0.5);
            }
        }
    }

    return effectiveBw;
}

/**
 * @brief     Calculate effective bandwidth for single band combination
 * @param     ptCi : temporary call context
 * @param     selectedBcIndex : band combination index
 * @param     measuredBands : list of bands received in MR
 * @param     ccInfoVecPerBand : reference to map <freqband, vector of cells>
 * @param     mcoBand2BcBandResultsCache : reference to filled cache from BC selection
 * @return    uint16_t : calculated effective bandwidth
 */
uint32_t FnVCCB_GetEffectiveBw(callInfo_type *ptCi, uint32_t selectedBcIndex, const MeasuredBands_type &measuredBands,
    const mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBand,
    const mcoBand2BcBandResultsCache_s &mcoBand2BcBandResultsCache)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ZERO(ptCi);

    uint32_t effectiveBw = 0;

    bandCombinationList_type *ptBandCombList = VRIL_GetBandCombinationList(ptCi);
    VALID_E_POINT_CHECK_ZERO(ptBandCombList);

    VCCB_CHECK_E_RANGE_AND_VAL(selectedBcIndex, MIN(MAX_BAND_COMBS, ptBandCombList->num), 0);
    const BandCombination_type *ptBc = &ptBandCombList->bandCombination[selectedBcIndex];

    mcoBand2numContCcDq_type mcoBand2numContCcDq;
    mcoBand2mcoNumContiguousCc_type dummy;

    McoAlgoFlags algoFlags = { .noMimo = false,
                               .checkUlBw = false,
                               .ulOnlyMode = false,
                               .mfbiCheck = false,
                               .initialFmPcc = false,
                               .checkCarrierOnly = false,
                               .useSe = false,
                               .useMultiChBw = false };
    FnVCCB_McoRetrieveBcData(ptCi, *ptBc, selectedBcIndex, ci_nr, algoFlags, mcoBand2numContCcDq, dummy);

    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, 0);
    const VccbGnbInfo_type &rGnb = GNBINFO[ptCi->gnbNum];
    for (const mcoBand2numContCcDq_type::value_type &kv : mcoBand2numContCcDq)
    {
        const uint16_t bandNr = kv.first;

        if (false == std::binary_search(measuredBands.begin(), measuredBands.end(), bandNr))
        {
            continue;
        }

        mcoBand2mcoCcInfoVecMap_type::const_iterator ccInfoVecPerBandIt = ccInfoVecPerBand.find(bandNr);
        if (ccInfoVecPerBand.end() == ccInfoVecPerBandIt)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] band-NR(%u) check: No CC\n", bandNr);
            continue;
        }

        mcoCheckBcResult_s bcBandPermResult;
        const mcoCheckBcBandResultsCache_s *pBcBandCache = mcoBand2BcBandResultsCache.getForBand(ci_nr, bandNr);
        mcoCheckBcBandResultsCache_s::key_type bcBandKey = mcoCheckBcBandResultsCache_s::makeBcBandKey(kv.second);

        if ((nullptr == pBcBandCache) || (true != pBcBandCache->getResult(bcBandKey, bcBandPermResult)))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] band-NR(%u) check: No cache\n", bandNr);
            continue;
        }

        effectiveBw += FnVCCB_GetEffectiveBwOfSingleBand(rGnb,
            ccInfoVecPerBandIt->second.ccInfoVec, bcBandPermResult.ccIdxBitmask, bcBandPermResult.ccMimo2Bitmask, bcBandPermResult.ccMimo4Bitmask, vector<uint32_t>(0)); // not Use sCellFreqList
    }

    return effectiveBw;
}

/**
 * @brief   MCO: Interface function to find best BC index and bandwidth for LTE access.
 * @param[in]   ptCi : temporary call context
 * @param[in]   ptUeSupBandCombList : pointer  bandCombinationList
 * @param[in]   measuredBands : reference  to list of bands received in MR
 * @param[out]  ptEffectiveBw : pointer  calculated effective bandwidth
 * @param[out]  ptBcIndex : pointer to selected Band Combination index (0 based)
 * @return      GOOD(BC Index found), BREAK, ERROR /int16_t
 */
int16_t FnVCCB_McoFindBestBcForLteAccess(callInfo_type *ptCi, bandCombinationList_type *ptUeSupBandCombList,
    const MeasuredBands_type &measuredBands, uint32_t *ptEffectiveBw, uint32_t *ptBcIndex)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUeSupBandCombList);
    VALID_E_POINT_CHECK_ERROR(ptEffectiveBw);
    VALID_E_POINT_CHECK_ERROR(ptBcIndex);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);

    mcoBand2BcBandResultsCache_s mcoBand2BcBandResultsCache(ptCi);

    mcoBand2mcoCcInfoVecMap_type ccInfoVecPerBand;
    uint16_t pcellBand = BAND_NOT_FOUND;

    FnVCCB_McoDebugPrintUeCapaBcList(ptCi, *ptUeSupBandCombList);

    McoAlgoFlags algoFlags = {
        .noMimo = false,
        .checkUlBw = false,
        .ulOnlyMode = false,
        .mfbiCheck = false,
        .initialFmPcc = false,
        .checkCarrierOnly = false,
        .useSe = false,
        .useMultiChBw = false };
    FnVCCB_McoPrepareColocContiguousNrCellGroups(ptCi, ptCi->servCellNum, algoFlags, ccInfoVecPerBand, pcellBand);
    if ((0 == ccInfoVecPerBand.size()) || (BAND_NOT_FOUND == pcellBand))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] No valid NR colocated CC!\n");
        return BREAK;
    }

    // check each BC against NR CC
    McoBCIdxArray_type bcBwMaxIdxDq;
    uint32_t bcBwMax = 0;
    FnVCCB_McoCheckAllBcAgainstCcNr(ptCi, *ptUeSupBandCombList, pcellBand, BAND_NOT_FOUND, ccInfoVecPerBand, algoFlags,
            mcoBand2BcBandResultsCache, bcBwMaxIdxDq, bcBwMax);

    if (0 == bcBwMaxIdxDq.size())
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO][BCSel] No UE Capa BC selected!\n");
        return BREAK;
    }
    else if (1 == bcBwMaxIdxDq.size())
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "[MCO][BCSel] Found one best UE Capa BC idx(%u) BW(%u)\n", bcBwMaxIdxDq[0], bcBwMax);
        *ptBcIndex = bcBwMaxIdxDq[0];
    }
    else if ((E_CALLTYPE_NSA == ptCi->callType) && (0 < ptCi->cgConfigInfo.servCellInfoListMcgEutra.numItems))
    {
        // For EN-DC case check MCG cell count if servCellInfoListMcgEutra was received.
        mcoBand2mcoCcInfoVecMap_type mcoCcInfoVecPerBand;
        uint16_t mcgPCellBand = BAND_NOT_FOUND;

        FnVCCB_McoPrepareMcgContiguousEutraCellGroups(ptCi, mcoCcInfoVecPerBand, mcgPCellBand);
        if ((0 == mcoCcInfoVecPerBand.size()) || (BAND_NOT_FOUND == mcgPCellBand))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] No valid MCG CC!\n");
            return BREAK;
        }

        // check selected BC against EUTRA CC
        McoBCIdxArray_type bcMaxCcCntIdxDq;
        FnVCCB_McoCheckSelectedBcAgainstCcEutra(ptCi, *ptUeSupBandCombList, mcgPCellBand, mcoCcInfoVecPerBand,
            bcBwMaxIdxDq, mcoBand2BcBandResultsCache, bcMaxCcCntIdxDq);
        if (0 == bcMaxCcCntIdxDq.size())
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO][BCSel] No UE Capa BC selected with MCG CC!\n");
            return BREAK;
        }
        else if (1 == bcMaxCcCntIdxDq.size())
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO][BCSel] Found one best UE Capa BC idx(%u) BW(%u) with MCG CC\n",
                bcMaxCcCntIdxDq[0], bcBwMax);
            *ptBcIndex = bcMaxCcCntIdxDq[0];
        }
        else
        {
            unsigned int randVal = FnVCCB_GetRandomValue(__func__, ptCi->gnbNum, (int) bcMaxCcCntIdxDq.size());
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[MCO][BCSel] Found (%zu) UE Capa BC BW(%u) with MCG CC. Randomly(%u) selected idx(%u)\n",
                bcMaxCcCntIdxDq.size(), bcBwMax, randVal, bcMaxCcCntIdxDq[randVal]);
            *ptBcIndex = bcMaxCcCntIdxDq[randVal];
        }
    }
    else
    {
        unsigned int randVal = FnVCCB_GetRandomValue(__func__, ptCi->gnbNum, (int) bcBwMaxIdxDq.size());
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "[MCO][BCSel] Found (%zu) UE Capa BC with equal max BW(%u). Randomly(%u) selected idx(%u)\n",
            bcBwMaxIdxDq.size(), bcBwMax, randVal, bcBwMaxIdxDq[randVal]);
        *ptBcIndex = bcBwMaxIdxDq[randVal];
    }

    *ptEffectiveBw =
        FnVCCB_GetEffectiveBw(ptCi, *ptBcIndex, measuredBands, ccInfoVecPerBand, mcoBand2BcBandResultsCache);

    return GOOD;
}

/**
 * @brief   MCO FM PCC: prepares the list of ARFCNs to be skipped when extracting ARFCNs during calculation
 *                      list is based on current serving ARFCNs and target PCell's colocated cells
 * @param[in]       rCall          : reference to call context
 * @param[in/out]   rServingArfcns : reference to list of ARFCNs to be filled
 * @param[in]       rTargetPcell   : reference to target PCell data
 */
void FnVCCB_FmPccPrepareServingArfcnList(const callInfo_type &rCall, McoFmPccArfcnList_type &rServingArfcns, VccbCellInfo_type &rTargetPcell)
{

    VCCB_CHECK_VALID_CELLNUM_VOID(rCall.servCellNum);

    auto &rServingCell = CELLINFO[rCall.servCellNum];
    if (VLIB_IsColocCell(&rTargetPcell, &rServingCell.intraGnbNbrInfo))
    {
        rServingArfcns.insert(rServingCell.ssbArfcn);
    }

    const scellList_type &scells = FnVCCB_GetConstScellInfoList(rCall);
    for (const auto &scell: scells)
    {
        if (SCELL_STATE_ADDED != scell.state)
        {
            continue;
        }

        auto ptNbrGnbCell = VLIB_GetNbrGnbCellInfoBasedOnCgi(&rCall, scell.cgi, scell.gnbIdLength);
        if ((nullptr != ptNbrGnbCell) && VLIB_IsColocCell(&rTargetPcell, ptNbrGnbCell))
        {
            rServingArfcns.insert(scell.ssbArfcn);
        }

    }
}

/**
 * @brief   MCO FM PCC: retrieve ARFCNs of CCs chosen for a list of Band Combinations
 * @param[in]   rCall : reference to call context
 * @param[in]   pscellBand: to ignore PSCell ARFCNs
 * @param[in]   bandCombinationList: reference to list of band combinations supported by the UE
 * @param[in]   selectedBandCombinationIndices: reference to list of band combinations with top BW chosen for a PCell
 * @param[in]   algoFlags: reference to MCO Algorithm flags
 * @param[in]   ccInfoVecPerBand : reference to the list of CC
 * @param[in]   servingArfcns : reference to the list of ARFCNs of serving cells
 * @return      chosenArfcns : list of Arfcns chosen for a given PCell
 */
McoFmPccArfcnList_type FnVCCB_FmPccGetChosenArfcnForBandCombinations(
        callInfo_type &rCall,
        const uint16_t pscellBand,
        const bandCombinationList_type &bandCombinationList,
        const McoBCIdxArray_type &selectedBandCombinationIndices,
        const McoAlgoFlags &algoFlags,
        const mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBand,
        const McoFmPccArfcnList_type &servingArfcns)
{
    AUTO_TRACE_FUNC;

    mcoBand2numContCcDq_type mcoBand2numContCcDq;
    mcoBand2mcoNumContiguousCc_type dummy;

    McoFmPccArfcnList_type chosenArfcns = {};

    for (const mcoBand2mcoCcInfoVecMap_type::value_type &kv : ccInfoVecPerBand)
    {
        const uint16_t bandNr = kv.first;
        const mcoCcInfoVec_type &ccInfoVec = kv.second.ccInfoVec;

        // Ignore PSCell ARFCNs
        if (pscellBand == bandNr)
        {
            continue;
        }

        for (const auto &bcIdx: selectedBandCombinationIndices)
        {
            FnVCCB_McoRetrieveBcData(&rCall, bandCombinationList.bandCombination[bcIdx],
                bcIdx, ci_nr, algoFlags, mcoBand2numContCcDq, dummy);

            mcoBand2numContCcDq_type::const_iterator mcoBand2numContCcDqIt = mcoBand2numContCcDq.find(bandNr);
            if (mcoBand2numContCcDq.end() == mcoBand2numContCcDqIt)
            {
                // CCs' band not in selected band combination
                continue;
            }

            for (uint16_t ccIdx = 0; ccIdx < ccInfoVec.size(); ++ccIdx)
            {
                if (chosenArfcns.full())
                {
                    VCCB_PRINT_CALL_COMMENT(&rCall,
                        "[PCC][FM] More than %lu CCs selected, all above %lu will be discarded!\n", chosenArfcns.capacity(),
                        chosenArfcns.capacity());
                    return chosenArfcns;
                }

                // userValue is set to ssbArfcn of CC in PCC
                const Arfcn_type ssbArfcn = ccInfoVec[ccIdx].userValue;
                const bool pcellFlag = ccInfoVec[ccIdx].pcellFlag;

                if (!algoFlags.checkCarrierOnly && servingArfcns.contains(ssbArfcn))
                {
                    VCCB_PRINT_CALL_COMMENT(&rCall,
                        "[PCC][FM] Skipped ccIdx(%u) serving ssbArfcn(%u) band(%u) in CA Mode 1/2!\n", ccIdx,
                        ssbArfcn, bandNr);
                    continue;
                }

                if (chosenArfcns.insert(ssbArfcn))
                {
                    VCCB_PRINT_CALL_COMMENT(&rCall, "[PCC][FM] Included ccIdx(%u) ssbArfcn(%u) band(%u) %cCell\n", ccIdx,
                        ssbArfcn, bandNr, (pcellFlag ? 'P' : 'S'));
                }
                else
                {
                    VCCB_PRINT_CALL_COMMENT(&rCall,
                        "[PCC][FM] Included ccIdx(%u) but ssbArfcn(%u) band(%u) %cCell is already found!\n", ccIdx, ssbArfcn,
                        bandNr, (pcellFlag ? 'P' : 'S'));
                }
            }

            // band retrieved
            break;
        }
    }

    return chosenArfcns;
}

/**
 * @brief   MCO: Execute func for each alternate band combination on CC container.
 * @return  return type is the same as return of passed in Functor func (in case of void, no return)
 */
template <typename Functor>
decltype(auto) FnVCCB_McoForEachAltBand(
    callInfo_type &rCi, const mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBand, const uint16_t pcellBand,
    const uint16_t pscellBand, const Functor &func)
{
    AUTO_TRACE_FUNC;

    struct AltBandCcInfo_s
    {
        uint16_t priBand;
        uint16_t altBand;
        uint32_t altBandBw;
        std::size_t ccIdx;
    };

    uint16_t pCellBandLocal = pcellBand;
    uint16_t sCellAltBandTab[MAX_MCO_MFBI_CELLS];
    uint32_t sCellUserValTab[MAX_MCO_MFBI_CELLS] = {};

    AltBandCcInfo_s altBandCcInfoTab[MAX_MCO_MFBI_CELLS];
    AltBandCcInfo_s *pAltBandCcInfo = nullptr;
    uint32_t altBandCcInfoSize = 0;
    constexpr bool funcReturnsVoid = std::is_void_v<std::invoke_result_t<
        Functor,
        mcoBand2mcoCcInfoVecMap_type,
        uint16_t,
        uint16_t,
        decltype(sCellAltBandTab),
        decltype(sCellUserValTab)>>;

    std::optional<McoFmPccArfcnList_type> funcResult;
    for (const mcoBand2mcoCcInfoVecMap_type::value_type &kv : ccInfoVecPerBand)
    {
        const mcoCcInfoVec_type &ccInfoVec = kv.second.ccInfoVec;
        const uint16_t priBand = kv.first;

        for (std::size_t ccIdx = 0; ccIdx < ccInfoVec.size(); ccIdx++)
        {
            // 1. Check if replace CC's band
            const mcoCcInfo_s &ccInfo = ccInfoVec[ccIdx];
            const uint16_t altBand = ccInfo.altBand;
            const uint32_t altBandBw = ccInfo.altBandMcoBwDl;
            if ((BAND_NOT_FOUND == altBand) || (priBand == altBand))
            {
                continue;
            }

            if (((0 < ccIdx) && (ccInfo.grpId == ccInfoVec[ccIdx - 1].grpId)) ||
                 ((ccInfoVec.size() > (ccIdx + 1)) && (ccInfo.grpId == ccInfoVec[ccIdx + 1].grpId)))
            {
                VCCB_PRINT_CALL_COMMENT(&rCi, "[MCO] ccIdx(%lu) priBand(%u) altBand(%u) is contiguous with other CC!\n",
                    ccIdx, priBand, altBand);
                continue;
            }

            // If there are more than 3 MFBI cells, select the top 3 cells in order of higher BW.
            if (MIN(DBG->value.mcoMaxMfbiCc, MAX_MCO_MFBI_CELLS) <= altBandCcInfoSize)
            {
                // sort in ascending BW order - smallest BW element first
                std::sort(altBandCcInfoTab, altBandCcInfoTab + MIN(DBG->value.mcoMaxMfbiCc, MAX_MCO_MFBI_CELLS),
                    [](const AltBandCcInfo_s &lhs, const AltBandCcInfo_s &rhs) { return lhs.altBandBw < rhs.altBandBw; });

                // check if smallest BW element can be replaced
                pAltBandCcInfo = &altBandCcInfoTab[0];
                if (pAltBandCcInfo->altBandBw >= altBandBw)
                {
                    continue;
                }
            }
            else
            {
                pAltBandCcInfo = &altBandCcInfoTab[altBandCcInfoSize];
                altBandCcInfoSize++;
            }

            pAltBandCcInfo->priBand = priBand;
            pAltBandCcInfo->altBand = altBand;
            pAltBandCcInfo->ccIdx = ccIdx;
            pAltBandCcInfo->altBandBw = altBandBw;
        }
    }

    // sort in descending ccIdx order - largest ccIdx element first to preserve ccIdx validity when removing from vector.
    std::sort(altBandCcInfoTab, altBandCcInfoTab + altBandCcInfoSize,
        [](const AltBandCcInfo_s &lhs, const AltBandCcInfo_s &rhs) { return lhs.ccIdx > rhs.ccIdx; });

    for (uint32_t altBandCcInfoIdx = 0; altBandCcInfoIdx < altBandCcInfoSize; altBandCcInfoIdx++)
    {
        const AltBandCcInfo_s &rAltBandCcInfo = altBandCcInfoTab[altBandCcInfoIdx];
        VCCB_PRINT_CALL_COMMENT(&rCi, "[MCO] Alternation CC bitmask(0x%X): ccIdx(%lu) priBand(%u) altBand(%u) altBandBW(%u)\n",
            1u << altBandCcInfoIdx, rAltBandCcInfo.ccIdx, rAltBandCcInfo.priBand, rAltBandCcInfo.altBand,
            rAltBandCcInfo.altBandBw);
    }

    const uint32_t maxCombBitmask = 1u << altBandCcInfoSize;
    for (uint32_t combBitmask = 1u; maxCombBitmask > combBitmask; combBitmask++)
    {
        mcoBand2mcoCcInfoVecMap_type ccInfoVecPerBandWorkCopy = ccInfoVecPerBand;
        uint8_t uniqueGrpId = 0xFF;
        uint32_t sCellAltBandTabSize = 0;
        std::fill_n(sCellAltBandTab, MAX_MCO_MFBI_CELLS, BAND_NOT_FOUND);

        for (uint32_t altBandCcInfoIdx = 0; altBandCcInfoIdx < altBandCcInfoSize; altBandCcInfoIdx++)
        {
            if (combBitmask & (1u << altBandCcInfoIdx))
            {
                // 2. Replace: add to altBand, remove from priBand, set PCell band
                const AltBandCcInfo_s &rAltBandCcInfo = altBandCcInfoTab[altBandCcInfoIdx];

                auto &priBandVecs = ccInfoVecPerBandWorkCopy[rAltBandCcInfo.priBand];
                auto &altBandVecs = ccInfoVecPerBandWorkCopy[rAltBandCcInfo.altBand];

                mcoCcInfoVec_type &priBandCcVec = priBandVecs.ccInfoVec;
                mcoSeAdjustedBwPerCcVec_type &priBandSeVec = priBandVecs.seAdjustedBwVec;
                mcoCcInfoVec_type &altBandCcVec = altBandVecs.ccInfoVec;
                mcoSeAdjustedBwPerCcVec_type &altBandSeVec = altBandVecs.seAdjustedBwVec;

                const mcoCcInfo_s &ccInfoSrc = priBandCcVec[rAltBandCcInfo.ccIdx];
                const McoSeAdjustedBwPerCc_s seInfoSrc = priBandSeVec[rAltBandCcInfo.ccIdx];

                mcoCcInfo_s &ccInfoTgt = altBandCcVec.emplace_back(ccInfoSrc);
                altBandSeVec.emplace_back(seInfoSrc);

                ccInfoTgt.grpId = uniqueGrpId; // Assure no grpId collision.
                uniqueGrpId--;
                ccInfoTgt.mcoBwDl = rAltBandCcInfo.altBandBw;

                if (ccInfoSrc.pcellFlag)
                {
                    pCellBandLocal = rAltBandCcInfo.altBand;
                    // The SCC change specifies the alternative band value as BAND_NOT_FOUND in the PCell,
                    // so the PCell is not used as an alternative band.
                }
                else
                {
                    sCellAltBandTab[sCellAltBandTabSize] = rAltBandCcInfo.altBand;
                    sCellUserValTab[sCellAltBandTabSize] = ccInfoSrc.userValue;
                    sCellAltBandTabSize++;
                }

                if (1 == priBandCcVec.size())
                {
                    ccInfoVecPerBandWorkCopy.erase(rAltBandCcInfo.priBand);
                }
                else
                {
                    priBandCcVec.erase(priBandCcVec.begin() + static_cast<uint32_t>(rAltBandCcInfo.ccIdx));
                }
            }
        }

        // 3. Call a function
        VCCB_PRINT_CALL_COMMENT(&rCi, "== [MCO] Combination: bitmask(0x%X), altBand CC num(%u) ==\n",
            combBitmask, altBandCcInfoSize);
        if constexpr (funcReturnsVoid)
        {
            func(ccInfoVecPerBandWorkCopy, pCellBandLocal, pscellBand, sCellAltBandTab, sCellUserValTab);
        }
        else
        {
            auto tmpFuncResult = func(ccInfoVecPerBandWorkCopy, pCellBandLocal, pscellBand, sCellAltBandTab, sCellUserValTab);
            funcResult = tmpFuncResult.has_value() ? tmpFuncResult.value() : funcResult;
        }

        // 4. Revert replacement
        pCellBandLocal = pcellBand;
    }

    if constexpr (!funcReturnsVoid)
    {
        return funcResult;
    }
}

/**
 * @brief       Initialize PccCandidateResult_type structure.
 */
void FnVCCB_InitPccCandidateResult(PccCandidateResult_type &result)
{
    AUTO_TRACE_FUNC;

    result.pcellSelectedBand = BAND_NOT_FOUND;
    std::fill_n(result.scellAltBandTab, MAX_MCO_MFBI_CELLS, BAND_NOT_FOUND);
    std::fill_n(result.scellAltBandNrArfcnTab, MAX_MCO_MFBI_CELLS, UNKNOWN_ARFCN);
    result.effectiveBw = 0;
    result.pscell.nbrIdx = MAX_NBR_PER_CELL;
    result.pscell.pci = UNKNOWN_PCI;
    result.pscell.ssbArfcn = UNKNOWN_ARFCN;
}

/**
 * @brief       MCO: Check if NR CC's band is included in any of selected BC.
 */
bool FnVCCB_McoCheckCcNrBandIsIncludedInSelectedBcList(callInfo_type *ptCi,
    const bandCombinationList_type *ptUeSupBandCombList, const McoBCIdxArray_type &bcBwMaxIdxDq,
    const mcoBand2BcBandResultsCache_s &mcoBand2BcBandResultsCache, const uint16_t bandToBeChecked,
    const McoAlgoFlags &algoFlags)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptUeSupBandCombList, false);

    mcoBand2numContCcDq_type mcoBand2numContCcDq;
    mcoBand2mcoNumContiguousCc_type dummy;
    for (uint32_t selectedBcIndex : bcBwMaxIdxDq)
    {
        const BandCombination_type *ptBc = &ptUeSupBandCombList->bandCombination[selectedBcIndex];
        FnVCCB_McoRetrieveBcData(ptCi, *ptBc, selectedBcIndex, ci_nr, algoFlags, mcoBand2numContCcDq, dummy);

        mcoBand2numContCcDq_type::iterator it = mcoBand2numContCcDq.find(bandToBeChecked);
        if (it == mcoBand2numContCcDq.end())
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC] BC idx(%u) band-NR(%u) check: No band in this BC!\n",
                selectedBcIndex, bandToBeChecked);
            continue;
        }

        mcoCheckBcResult_s bcBandPermResult;
        const mcoCheckBcBandResultsCache_s *pBcBandCache = mcoBand2BcBandResultsCache.getForBand(ci_nr, bandToBeChecked);
        mcoCheckBcBandResultsCache_s::key_type bcBandKey = mcoCheckBcBandResultsCache_s::makeBcBandKey(it->second);

        if ((nullptr == pBcBandCache) || (true != pBcBandCache->getResult(bcBandKey, bcBandPermResult)))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC] BC idx(%u) band-NR(%u) check: No cache!\n", selectedBcIndex, bandToBeChecked);
            continue;
        }

        if (0 == bcBandPermResult.ccIdxBitmask)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC] BC idx(%u) band-NR(%u) check: No CC!\n", selectedBcIndex, bandToBeChecked);
            continue;
        }

        return true;
    }

    return false;
}

/**
 * @brief       Helper function to reduce ARFCN lists to a single list of unique ARFCNs.
 * @param[in]   rCall : reference to callInfo
 * @param[in]   arfcnLists : list of ARFCN lists to be reduced to unique ARFCNs
 * @param[out]  arfcnListOut : list of unique ARFCNs obtained by reducing input arfcnLists
 * @return      void
 */
void FnVCCB_McoFmPccReduceArfcnListsToUniqueArfcns(
        const callInfo_type &rCall,
        const McoFmPccChosenArfcnLists_type &arfcnLists,
        McoFmPccArfcnList_type &uniqueArfcnListOut)
{
    AUTO_TRACE_FUNC;

    auto reduceListToUnique =
        [&uniqueArfcnListOut, &rCall] (const auto &arfcnList)
        {
            if (!arfcnList.has_value())
            {
                return;
            }

            for (const auto &arfcn: arfcnList.value())
            {
                if (uniqueArfcnListOut.full())
                {
                    VCCB_PRINT_CALL_COMMENT(&rCall,
                        "[PCC][FM] More than max CC(%lu) selected for FM PCC candidate, any remaining will be discarded!\n",
                        uniqueArfcnListOut.capacity());
                    return;
                }
                uniqueArfcnListOut.insert(arfcn);
            }
        };

    std::for_each(
        arfcnLists.begin(),
        arfcnLists.end(),
        reduceListToUnique);
}

/**
 * @brief       Get CC info vec per band for PCC
 * @param[in]     rCall : call context.
 * @param[in]     cellNum : the PCell in the context of which the CC list will be built
 * @param[out]    pcellBandOut : PCell band selected for calculation
 * @param[in]     flags: flags used to determine effective BW calculation behaviour (finalFmPcc, NRDC, carrier only check)
 * @param[out]    algoFlagsOut: MCO algorithm flags for determining behavior during calculation
 * @param[out]    ccInfoVecPerBandOut : CC info built by FnVCCB_McoGetCcInfoVecPerBand
 * @return      GOOD, ERROR /int16_t
 */
int16_t FnVCCB_McoGetCcInfoVecPerBandForPcc(
        callInfo_type &rCall,
        const CellNum_type cellNum,
        uint16_t &pcellBandOut,
        const EffectiveBwForPccFlags &flags,
        McoAlgoFlags &algoFlagsOut,
        mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBandOut)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);
    const VccbCellInfo_type &rCell = CELLINFO[cellNum];
    VCCB_CHECK_VALID_GNBNUM_ERROR(rCall.gnbNum);
    const VccbGnbInfo_type &rGnb = GNBINFO[rCall.gnbNum];

    const bool isSlbMode = (PccMode_Slb == rCall.pccData.pccMode);
    bool ulOnlyMode = false;
    if (isSlbMode)
    {
        if (MAX_ACTIVE_SLICE_NUM <= rCall.sliceAwareLbInfo.tgtSliceIdx)
        {
            VCCB_PRINT_CALL_COMMENT(&rCall, "[PCC][SLB] Target slice index out of range!\n");
            return ERROR;
        }
        const sliceLoadControlInfo_type *pSlice = FnVCCB_GetSliceLoadControlInfo(rCall.gnbNum, rCall.sliceAwareLbInfo.tgtSliceIdx);
        if (pSlice == NULL)
        {
            VCCB_PRINT_CALL_COMMENT(&rCall, "[PCC][SLB] Target slice usage is off(sliceIdx:%d)!\n", rCall.sliceAwareLbInfo.tgtSliceIdx);
            return ERROR;
        }

        ulOnlyMode = (SLICE_TRANSMISSION_TYPE_UL == pSlice->sliceAwareLbConf.sliceTransmissionType);
    }

    algoFlagsOut = { .noMimo = isSlbMode,
                     .checkUlBw = false,
                     .ulOnlyMode = ulOnlyMode,
                     .mfbiCheck = FnVCCB_McoVerifyMfbi(&rGnb, cellNum),
                     .initialFmPcc = (false == flags.isFinalFmPcc) && static_cast<bool>(rGnb.multiCarrierOperation.fullMeasureBasedPccChange),
                     .checkCarrierOnly = flags.checkCarrierOnly,
                     .useSe = flags.isFinalFmPcc,
                     .useMultiChBw = true };
    if (flags.isFinalFmPcc)
    {
        FnVCCB_McoPrepareNrCellGroupsForFinalFmPcc(&rCall, cellNum, algoFlagsOut, ccInfoVecPerBandOut, pcellBandOut);
    }
    else
    {
        FnVCCB_McoPrepareColocContiguousNrCellGroups(&rCall, cellNum, algoFlagsOut, ccInfoVecPerBandOut, pcellBandOut);
    }
    if ((0 == ccInfoVecPerBandOut.size()) || (BAND_NOT_FOUND == pcellBandOut))
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "[PCC] Error preparing contiguous CC groups for PCell: num(%u) PCI(%u)!\n",
            cellNum, rCell.phyCellId);
        return ERROR;
    }

    return GOOD;
}

/**
 * @brief       Fill structures used in effective BW calculation for PCC Change with target PCell values only
 *              FR1050: LTM-enabled Target PCell is to be considered non-CA and non-NRDC
 * @param[in]   rCall : call context.
 * @param[in]   rGnb : reference to structure representing the gNB
 * @param[in]   ccInfoVecPerBandIn: map of bands to CC vectors for target PCell
 * @param[in]   pCellBandIn: band selected for calculation
 * @param[in]   rUeSupBandCombListIn : reference to the list of BCs supported by UE
 * @param[out]  effectiveBwOut : effective BW calculated by taking only PCell BW * MIMO
 * @param[out]  ltmUeCcInfoVerPerBandOut : new map of PCell's selected band to 1 CC vec with 1 CC
 * @param[out]  bcBwMaxIdxDqOut : list of BC indexes, only 1 index selected by this function
 * @return      void
 */
void FnVCCB_FillCalculationResultsForLtmEnabledTarget(
        callInfo_type& rCall, // non const due to called function signatures
        const VccbGnbInfo_type& rGnb,
        const mcoBand2mcoCcInfoVecMap_type& ccInfoVecPerBandIn,
        const uint16_t pCellBandIn,
        const bandCombinationList_type& rUeSupBandCombListIn,
        uint32_t& effectiveBwOut,
        mcoBand2mcoCcInfoVecMap_type& ltmUeCcInfoVecPerBandOut,
        McoBCIdxArray_type& bcBwMaxIdxDqOut)
{
    AUTO_TRACE_FUNC;

    effectiveBwOut = 0;
    ltmUeCcInfoVecPerBandOut.clear();
    bcBwMaxIdxDqOut.clear();

    // 1. Find the pcell's band in the CC vec map
    auto pcellBandCcVecIt = ccInfoVecPerBandIn.find(pCellBandIn);
    if (pcellBandCcVecIt == ccInfoVecPerBandIn.end())
    {
        return;
    }

    // 2. If found, construct the structures usually built by FnVCCB_McoCheckAllBcAgainstCcNr
    // 2.a Set effectiveBw and insert CC into vec per band
    const auto& ccInfoVecs = pcellBandCcVecIt->second;
    for (size_t ccIndex = 0; ccIndex < ccInfoVecs.ccInfoVec.size(); ccIndex++)
    {
        if (!ccInfoVecs.ccInfoVec[ccIndex].pcellFlag)
        {
            continue;
        }
        effectiveBwOut = ccInfoVecs.ccInfoVec[ccIndex].mcoBwDl;
        ltmUeCcInfoVecPerBandOut.emplace(
                pCellBandIn,
                mcoCcInfoVecs_s({ { ccInfoVecs.ccInfoVec[ccIndex] },
                                  { ccInfoVecs.seAdjustedBwVec[ccIndex] } })
        );
        break;
    }

    struct BestBc
    {
        uint32_t bcIdx;
        uint8_t mimoLayers;
    };
    // 2.b Find all BC indexes that support target band, select highest MIMO
    const uint8_t maxPossibleMimo =
        ((MAX_FR1_NR_BAND < pCellBandIn) ? MAX_FR2_DL_MIMO_LAYERS : MAX_FR1_DL_MIMO_LAYERS);
    BestBc bestBc { rUeSupBandCombListIn.num, 0 };
    for (uint32_t bcIdx = 0; bcIdx < rUeSupBandCombListIn.num; bcIdx++)
    {
        const auto &bc = rUeSupBandCombListIn.bandCombination[bcIdx];
        auto bandIt = std::find_if(bc.band, bc.band + bc.num,
            [&pCellBandIn] (const auto& band)
            {
                return (band.ratType == ci_nr) &&
                (band.freqBandIndicator == pCellBandIn) &&
                (CA_BandwidthClassNR_NOT_SET != band.nrCaBandwidthClassDL) &&
                (CA_BandwidthClassNR_NOT_SET != band.nrCaBandwidthClassUL);
            }
        );
        // Required band not found in BC
        if (bandIt == (bc.band + bc.num))
        {
            continue;
        }

        // Check if found BC has higher MIMO than current best
        uint8_t mimoLayers = FnVCCB_McoGetDlMimoLayerForBestBcSelection(&rCall, bcIdx, bandIt->freqBandIndicator, static_cast<uint16_t>(std::distance(bc.band, bandIt)));
        if (mimoLayers > bestBc.mimoLayers)
        {
            bestBc.bcIdx = bcIdx;
            bestBc.mimoLayers = mimoLayers;
        }

        // If found BC has highest possible MIMO then stop iteration
        if (mimoLayers >= maxPossibleMimo)
        {
            break;
        }
    }
    if (rUeSupBandCombListIn.num > bestBc.bcIdx)
    {
        bcBwMaxIdxDqOut.push_back(bestBc.bcIdx);
        effectiveBwOut = static_cast<uint32_t>(effectiveBwOut * FnVCCB_McoConvertMimoNumToMimoCoefficient(rGnb, bestBc.mimoLayers));
    }
    else
    {
        VCCB_PRINT_CALL_COMMENT(&rCall, "[PCC] No BC found for LTM-enabled band(%u)!\n", pCellBandIn);
    }
}

/**
 * @brief       Get Effective bandwidth for PCC Change.
 * @param[in]   ptCi : call context.
 * @param[in]   ptHrl : Handover Restriction List of a call context.
 * @param[in]   flags: flags used to determine effective BW calculation behaviour (finalFmPcc, NRDC, carrier only check)
 * @param[in]   algoFlags: MCO algorithm flags for determining behavior during calculation
 * @param[in]   cellNum : the PCell in the context of which the calculations will be performed.
 * @param[in]   pcellBand : PCell band selected for calculation
 * @param[in]   ccInfoVecPerBand : CC info built by FnVCCB_McoGetCcInfoVecPerBand
 * @param[out]  resultListOut : reference to candidate's calculated result list. First result is the best result.
 * @param[out]  chosenArfcnsOut : reference to list of ARFCNs of CCs chosen for the candidate PCell
 * @return      GOOD, ERROR /int16_t
 */
int16_t FnVCCB_McoGetEffectiveBwForPccChange(
        callInfo_type *ptCi,
        hoRestrictInfo_type *ptHrl,
        const EffectiveBwForPccFlags &flags,
        const McoAlgoFlags &algoFlags,
        const uint16_t cellNum,
        const uint16_t pcellBand,
        mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBand,
        PccCandidateResultList_type &resultListOut,
        McoFmPccArfcnList_type &chosenArfcnsOut,
        const PccCandidateInfo_type * const ptCandidate)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptHrl);

    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);
    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    resultListOut.clear();
    PccCandidateResult_type tmpResult;
    uint16_t requiredBand = BAND_NOT_FOUND;
    bool includeRequiredBand = false;

    const bandCombinationList_type *ptUeSupBandCombList = VRIL_GetBandCombinationList(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUeSupBandCombList);
    FnVCCB_McoDebugPrintUeCapaBcList(ptCi, *ptUeSupBandCombList);

    McoFmPccArfcnList_type servingArfcns = {};
    if (algoFlags.initialFmPcc && !flags.checkCarrierOnly)
    {
        FnVCCB_FmPccPrepareServingArfcnList(*ptCi, servingArfcns, const_cast<VccbCellInfo_type &>(*pCell));
    }

    const bool ltmEnabledCandPriBand = ((cellNum != ptCi->servCellNum) &&
        FnVCCB_IsNrdcProhibitedByLtmHO(*ptCi, pcellBand));
    if (ltmEnabledCandPriBand)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC] Target PCell cellNum(%u) pri bandNr(%u) detected as LTM-enabled!\n",
            cellNum, pcellBand);
    }

    auto fnIsLtmEnabledCandidate = [&](const uint16_t pCellBandLocal) -> bool
    {
        if (pCellBandLocal == pcellBand)
        {
            return ltmEnabledCandPriBand;
        }

        if ((cellNum != ptCi->servCellNum) &&
            (FnVCCB_IsNrdcProhibitedByLtmHO(*ptCi, pCellBandLocal)))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC] Target PCell cellNum(%u) alt bandNr(%u) detected as LTM-enabled!\n",
                cellNum, pCellBandLocal);
            return true;
        }

        return false;
    };

    auto fnCheckAllBcAgainstCcNr = [&](const mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBandLocal, const uint16_t pCellBandLocal,
         const uint16_t pscellBand, const uint16_t sCellAltBandTab[MAX_MCO_MFBI_CELLS], const uint32_t sCellNrArfcnTab[MAX_MCO_MFBI_CELLS]) -> std::optional<McoFmPccArfcnList_type>
    {
        // check each BC against NR CC
        McoBCIdxArray_type bcBwMaxIdxDq;
        uint32_t effectiveBw = 0;
        mcoBand2BcBandResultsCache_s mcoBand2BcBandResultsCache(ptCi);

        // When target cell is LTM enabled, treat the BW as PCell only
        // Serving cell is never LTM enabled in PCC
        const bool ltmEnabledCell = fnIsLtmEnabledCandidate(pCellBandLocal);
        mcoBand2mcoCcInfoVecMap_type ltmUeCcInfoVecPerBand;
        if (ltmEnabledCell)
        {
            FnVCCB_FillCalculationResultsForLtmEnabledTarget(
                    *ptCi,
                    *pGnb,
                    ccInfoVecPerBandLocal,
                    pCellBandLocal,
                    *ptUeSupBandCombList,
                    effectiveBw,
                    ltmUeCcInfoVecPerBand,
                    bcBwMaxIdxDq);
        }
        else
        {
            FnVCCB_McoCheckAllBcAgainstCcNr(ptCi, *ptUeSupBandCombList, pCellBandLocal, pscellBand, ccInfoVecPerBandLocal, algoFlags,
                    mcoBand2BcBandResultsCache, bcBwMaxIdxDq, effectiveBw);
        }

        if (0 == bcBwMaxIdxDq.size())
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC] Cannot select any BC for PCell band(%u)!\n", pCellBandLocal);
            return std::nullopt;
        }

        const bool acceptZeroBwBc = ((0 == effectiveBw) && (0 == tmpResult.effectiveBw));
        if ((effectiveBw > tmpResult.effectiveBw) || acceptZeroBwBc)
        {
            VCCB_PRINT_CALL_COMMENT(
                ptCi, "[PCC] All BC checked and eBW increased %u->%u.\n", tmpResult.effectiveBw, effectiveBw);
            for (uint32_t sCellAltBandIdx = 0; MAX_MCO_MFBI_CELLS > sCellAltBandIdx; sCellAltBandIdx++)
            {
                tmpResult.scellAltBandTab[sCellAltBandIdx] = sCellAltBandTab[sCellAltBandIdx];
                tmpResult.scellAltBandNrArfcnTab[sCellAltBandIdx] =
                    ((BAND_NOT_FOUND != sCellAltBandTab[sCellAltBandIdx]) ? sCellNrArfcnTab[sCellAltBandIdx] : UNKNOWN_ARFCN);
            }
            tmpResult.effectiveBw = effectiveBw;
            tmpResult.pcellSelectedBand = pCellBandLocal;

            if (BAND_NOT_FOUND != requiredBand)
            {
                includeRequiredBand = FnVCCB_McoCheckCcNrBandIsIncludedInSelectedBcList(ptCi, ptUeSupBandCombList,
                    bcBwMaxIdxDq, mcoBand2BcBandResultsCache, requiredBand, algoFlags);
                VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC] Required band(%u) %s\n", requiredBand, includeRequiredBand ? "included" : " not included");
            }

            // Do not retrieve ARFCNs when calculating for final FM-PCC or for serving cell's primary band or FM PCC is not on
            const bool calculatingForPrimaryBands =
                (cellNum == ptCi->servCellNum) &&
                (pCellBandLocal == ptCi->servCellBand) &&
                std::none_of(
                    sCellAltBandTab,
                    sCellAltBandTab + MAX_MCO_MFBI_CELLS,
                    [] (const uint16_t band) { return BAND_NOT_FOUND != band; });
            if (flags.isFinalFmPcc || calculatingForPrimaryBands || !pGnb->multiCarrierOperation.fullMeasureBasedPccChange)
            {
                return std::nullopt;
            }
            return std::make_optional<McoFmPccArfcnList_type>(FnVCCB_FmPccGetChosenArfcnForBandCombinations(
                    *ptCi,
                    pscellBand,
                    *ptUeSupBandCombList,
                    bcBwMaxIdxDq,
                    algoFlags,
                    ltmEnabledCell ? ltmUeCcInfoVecPerBand : ccInfoVecPerBandLocal,
                    servingArfcns));
        }
        return std::nullopt;
    };

    VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC] Check BW for PCell: num(%u) band(%u).\n", cellNum, pcellBand);

    FnVCCB_InitPccCandidateResult(tmpResult);
    const static uint16_t bandNotFoundTab[MAX_MCO_MFBI_CELLS] = {BAND_NOT_FOUND, BAND_NOT_FOUND, BAND_NOT_FOUND};
    const static uint32_t unknownArfcnTab[MAX_MCO_MFBI_CELLS] = {UNKNOWN_ARFCN, UNKNOWN_ARFCN, UNKNOWN_ARFCN};
    auto saChosenArfcns = fnCheckAllBcAgainstCcNr(ccInfoVecPerBand, pcellBand, BAND_NOT_FOUND, bandNotFoundTab, unknownArfcnTab);

    if (algoFlags.mfbiCheck || algoFlags.useMultiChBw)
    {
        auto saChosenArfcnsWithMfbi = FnVCCB_McoForEachAltBand(*ptCi, ccInfoVecPerBand, pcellBand, BAND_NOT_FOUND, fnCheckAllBcAgainstCcNr);
        saChosenArfcns = saChosenArfcnsWithMfbi.has_value() ? saChosenArfcnsWithMfbi : saChosenArfcns;
    }

    if (BAND_NOT_FOUND == tmpResult.pcellSelectedBand)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC] Cannot select any BC for PCell: num(%u) PCI(%u)!\n", cellNum, pCell->phyCellId);
        return ERROR;
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC] PCell: num(%u) PCI(%u) BW(%u) band(%u), SCells: band([%u,%u,%u]) arfcn([%u,%u,%u])\n",
        cellNum, pCell->phyCellId, tmpResult.effectiveBw, tmpResult.pcellSelectedBand, tmpResult.scellAltBandTab[0],
        tmpResult.scellAltBandTab[1], tmpResult.scellAltBandTab[2],
        ((BAND_NOT_FOUND != tmpResult.scellAltBandTab[0]) ? tmpResult.scellAltBandNrArfcnTab[0] : 0),
        ((BAND_NOT_FOUND != tmpResult.scellAltBandTab[1]) ? tmpResult.scellAltBandNrArfcnTab[1] : 0),
        ((BAND_NOT_FOUND != tmpResult.scellAltBandTab[2]) ? tmpResult.scellAltBandNrArfcnTab[2] : 0));
    resultListOut.push_back(tmpResult);
    McoFmPccChosenArfcnLists_type arfcnLists = { saChosenArfcns };

    mcoPscellCcInfo_s nrdcCcInfoTab[MAX_PCC_PSCELL_BANDS];
    auto findPscellCntAndFillNrdcCcInfo =
        [&ptCi, &ptHrl, &cellNum, &nrdcCcInfoTab, &ptCandidate, &flags, &algoFlags, &ltmEnabledCandPriBand] () -> uint16_t
    {
        if (false == flags.checkNrdc)
        {
            return 0;
        }

        if (ltmEnabledCandPriBand && !algoFlags.mfbiCheck && !algoFlags.useMultiChBw)
        {
            return 0;
        }

        // Consider only measured PSCells in recalculations
        return ((flags.isFinalFmPcc ||
                ((ptCi->pccData.pccMode == PccMode_Slb) && (ptCi->pccData.state == PCC_Gathering))) ?
                FnVCCB_McoMakeNrdcPscellCandidateListForRecalculation(ptCi, ptHrl, ptCandidate, cellNum, nrdcCcInfoTab) :
                FnVCCB_McoMakeNrdcPscellCandidateList(ptCi, ptHrl, cellNum, nrdcCcInfoTab));
    };
    // Compute results including PSCells one by one
    const uint16_t pscellCnt = findPscellCntAndFillNrdcCcInfo();

    std::optional<McoFmPccArfcnList_type> nrdcChosenArfcns;
    for (uint16_t pscellIdx = 0; pscellCnt > pscellIdx; ++pscellIdx)
    {
        const uint16_t nrdcBand = nrdcCcInfoTab[pscellIdx].band;
        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC] Check BW for PCell: num(%u) band(%u), PSCell: band(%u) nbrIdx(%u)\n",
            cellNum, pcellBand, nrdcBand, nrdcCcInfoTab[pscellIdx].nbrIdx);

        if (ccInfoVecPerBand.end() != ccInfoVecPerBand.find(nrdcBand))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC] Skip PSCell band(%u) - already used by SCell\n", nrdcBand);
            continue;
        }

        // add PSCell to container
        ccInfoVecPerBand.emplace(nrdcBand, mcoBand2mcoCcInfoVecMap_type::mapped_type {
                mcoCcInfoVec_type(1, nrdcCcInfoTab[pscellIdx].ccInfo), mcoSeAdjustedBwPerCcVec_type(1, McoSeAdjustedBwPerCc_s())
                });

        requiredBand = nrdcBand;
        FnVCCB_InitPccCandidateResult(tmpResult);
        nrdcChosenArfcns = fnCheckAllBcAgainstCcNr(ccInfoVecPerBand, pcellBand, nrdcBand, bandNotFoundTab, unknownArfcnTab);

        if (algoFlags.mfbiCheck || algoFlags.useMultiChBw)
        {
            auto nrdcChosenArfcnsWithMfbi = FnVCCB_McoForEachAltBand(*ptCi, ccInfoVecPerBand, pcellBand, nrdcBand, fnCheckAllBcAgainstCcNr);
            nrdcChosenArfcns = nrdcChosenArfcnsWithMfbi.has_value() ? nrdcChosenArfcnsWithMfbi : nrdcChosenArfcns;
        }

        // remove PSCell from container (the only CC on the band)
        ccInfoVecPerBand.erase(nrdcBand);

        if (((PccMode_Mco == ptCi->pccData.pccMode) && (0 == tmpResult.effectiveBw)) ||
                (BAND_NOT_FOUND == tmpResult.pcellSelectedBand))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC] Cannot select any BC for PCell: num(%u) PCI(%u), PSCell band(%u)!\n",
                cellNum, pCell->phyCellId, nrdcBand);
            continue;
        }

        if (false == includeRequiredBand)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC] None of selected BC for PCell: num(%u) PCI(%u) include PSCell band(%u)!\n",
                cellNum, pCell->phyCellId, nrdcBand);
            continue;
        }

        // fill PSCell data
        tmpResult.pscell.nbrIdx = nrdcCcInfoTab[pscellIdx].nbrIdx;
        tmpResult.pscell.pci = nrdcCcInfoTab[pscellIdx].pci;
        tmpResult.pscell.ssbArfcn = nrdcCcInfoTab[pscellIdx].ccInfo.userValue;

        VCCB_PRINT_CALL_COMMENT(ptCi,
            "[PCC] PCell: num(%u) PCI(%u) BW(%u) band(%u), SCells: band([%u,%u,%u]) arfcn([%u,%u,%u]), PSCell band(%u)\n",
            cellNum, pCell->phyCellId, tmpResult.effectiveBw, tmpResult.pcellSelectedBand, tmpResult.scellAltBandTab[0],
            tmpResult.scellAltBandTab[1], tmpResult.scellAltBandTab[2],
            ((BAND_NOT_FOUND != tmpResult.scellAltBandTab[0]) ? tmpResult.scellAltBandNrArfcnTab[0] : 0),
            ((BAND_NOT_FOUND != tmpResult.scellAltBandTab[1]) ? tmpResult.scellAltBandNrArfcnTab[1] : 0),
            ((BAND_NOT_FOUND != tmpResult.scellAltBandTab[2]) ? tmpResult.scellAltBandNrArfcnTab[2] : 0), nrdcBand);

        if (tmpResult.effectiveBw < resultListOut.front().effectiveBw)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC] PSCell BW(%u) is less than BW(%u) without PSCell - skip PSCell\n",
                tmpResult.effectiveBw, resultListOut.front().effectiveBw);
            continue;
        }

        resultListOut.push_back(tmpResult);
        arfcnLists.push_back(nrdcChosenArfcns);
    }

    std::sort(resultListOut.begin(), resultListOut.end(),
              [](const auto &lhs, const auto &rhs){ return lhs.effectiveBw > rhs.effectiveBw; });

    if (!flags.isFinalFmPcc && pGnb->multiCarrierOperation.fullMeasureBasedPccChange)
    {
        FnVCCB_McoFmPccReduceArfcnListsToUniqueArfcns(*ptCi, arfcnLists, chosenArfcnsOut);
    }

    return GOOD;
}

/**
 * @brief       MCO: Check all BCs and calculate max bandwidth for SCC Change and Calculation of the top of BandCombination
 */
int16_t FnVCCB_McoCheckAllBcForMaxBw(callInfo_type *ptCi, const bandCombinationList_type &ueSupBandCombList,
    const mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBand, bool (&rBestSCellsMapOut)[MAX_SCELL_PER_CALL],
    uint32_t &rEffectiveBwOut, const uint16_t psCellBandNr)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    mcoBand2BcBandResultsCache_s mcoBand2BcBandResultsCache(ptCi);
    McoBCIdxArray_type bcBwMaxIdxDq;

    const McoAlgoFlags algoFlags = { .noMimo = true,
                                     .checkUlBw = false,
                                     .ulOnlyMode = false,
                                     .mfbiCheck = false,
                                     .initialFmPcc = false,
                                     .checkCarrierOnly = false,
                                     .useSe = false,
                                     .useMultiChBw = false };
    // The MIMO layer value is not considered and is not applied when calculating (noMimoFlag = true)
    FnVCCB_McoCheckAllBcAgainstCcNr(ptCi, ueSupBandCombList, psCellBandNr, BAND_NOT_FOUND,
        ccInfoVecPerBand, algoFlags, mcoBand2BcBandResultsCache, bcBwMaxIdxDq, rEffectiveBwOut);

    if (0 == bcBwMaxIdxDq.size())
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[MCO] No UE Capa BC selected!\n");
        return ERROR;
    }

    const uint32_t selectedBcIdx = bcBwMaxIdxDq[0];
    VCCB_CHECK_E_RANGE_AND_RETURN(selectedBcIdx, MIN(ueSupBandCombList.num, MAX_BAND_COMBS));

    mcoBand2numContCcDq_type mcoBand2numContCcDq;
    mcoBand2mcoNumContiguousCc_type dummy;

    VCCB_PRINT_LOG_MCO_FUNC(ptCi, "[MCO] selectedBcIdx : [%2d]\n", selectedBcIdx);

    FnVCCB_McoRetrieveBcData(ptCi, ueSupBandCombList.bandCombination[selectedBcIdx],
        selectedBcIdx, ci_nr, algoFlags, mcoBand2numContCcDq, dummy);

    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    std::fill(rBestSCellsMapOut, rBestSCellsMapOut + MAX_SCELL_PER_CALL, false);
    for (mcoBand2numContCcDq_type::value_type &kv : mcoBand2numContCcDq)
    {
        const uint16_t bandNr = kv.first;

        mcoBand2mcoCcInfoVecMap_type::const_iterator ccInfoVecPerBandIt = ccInfoVecPerBand.find(bandNr);
        if (ccInfoVecPerBand.end() == ccInfoVecPerBandIt)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] band(%u) check: No CC\n", bandNr);
            continue;
        }

        mcoCheckBcResult_s bcBandPermResult;
        const mcoCheckBcBandResultsCache_s *pBcBandCache = mcoBand2BcBandResultsCache.getForBand(ci_nr, bandNr);
        const mcoCheckBcBandResultsCache_s::key_type bcBandKey = mcoCheckBcBandResultsCache_s::makeBcBandKey(kv.second);

        if ((nullptr == pBcBandCache) || (true != pBcBandCache->getResult(bcBandKey, bcBandPermResult)))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] band(%u) check: No cache\n", bandNr);
            continue;
        }

        for (uint16_t ccIdx = 0; ccIdx < ccInfoVecPerBandIt->second.ccInfoVec.size(); ++ccIdx)
        {
            // userValue is set to sCellIndex
            const uint32_t sCellIdx = ccInfoVecPerBandIt->second.ccInfoVec[ccIdx].userValue;

            if ((bcBandPermResult.ccIdxBitmask & (1ULL << ccIdx)) &&
                (MAX_SCELL_PER_CALL > sCellIdx))
            {
                rBestSCellsMapOut[sCellIdx] = true;

                const scellInfo_type &sCell = scells[sCellIdx];
                VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] band(%u) including SCell: idx(%d) PCI(%d) ssbArfcn(%u)\n",
                    bandNr, sCellIdx, sCell.pci, sCell.ssbArfcn);
            }
        }
    }

    return GOOD;
}

/**
 * @brief       Go through measured cells from sCell list marked as sccFlag_cellMeasured  and calculate its bandwidth
 * @param[in]   ptCi : call context
 * @param[out]  rBestSCellsMap  : reference to array where chosen elements will be marked as TRUE
 *                                when SCell at specific position was used, otherwise
 *                                there will be FALSE on corresponding position
 *                                REMARK its size should be at least as ptCi::sCell array size
 * @param[out]  sCellAltBandOut : reference to selected SCell's alternate band value. BAND_NOT_FOUND if not changed.
 * @param[out]  sCellIdxWithAltBandOut  : reference to selected SCell's alternate band index.
 * @param[in]   rCellSelection : bandNr and cellnum of SpCell PsCell to calculate Max BW
 * @param[in]   noMfbiFlag : When calculating MAX BW, whether to consider MFBI
 * @return      GOOD, ERROR /int16_t
 */
int16_t FnVCCB_McoSelectScellsForMaxBW(callInfo_type *ptCi, bool (&rBestSCellsMap)[MAX_SCELL_PER_CALL],
    uint16_t (&sCellAltBandOut)[MAX_MCO_MFBI_CELLS], uint32_t (&sCellIdxWithAltBandOut)[MAX_MCO_MFBI_CELLS],
    const cellSelection_type &rCellSelection, const bool noMfbiFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint16_t bandNr = rCellSelection.bandNr;
    uint16_t cellNum = rCellSelection.cellNum;

    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);
    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint32_t effectiveBwMax = 0;

    const bandCombinationList_type *ptUeSupBandCombList = VRIL_GetBandCombinationList(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUeSupBandCombList);
    FnVCCB_McoDebugPrintUeCapaBcList(ptCi, *ptUeSupBandCombList);

    const bool mfbiCheckFlag = (true == noMfbiFlag) ? false : FnVCCB_McoVerifyMfbi(pGnb, cellNum);

    mcoBand2mcoCcInfoVecMap_type ccInfoVecPerBand;
    FnVCCB_McoPrepareContiguousNrCellGroupsForMaxBW(ptCi, mfbiCheckFlag, ccInfoVecPerBand, rCellSelection, *ptUeSupBandCombList);
    if (0 == ccInfoVecPerBand.size())
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[MCO] No valid NR CC!\n");
        return ERROR;
    }

    if (ERROR == FnVCCB_McoCheckAllBcForMaxBw(ptCi, *ptUeSupBandCombList, ccInfoVecPerBand, rBestSCellsMap, effectiveBwMax, bandNr))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[MCO] Check all BC ERROR!\n");
        return ERROR;
    }

    if (true == mfbiCheckFlag)
    {
        std::fill_n(sCellAltBandOut, MAX_MCO_MFBI_CELLS, BAND_NOT_FOUND);
        std::fill_n(sCellIdxWithAltBandOut, MAX_MCO_MFBI_CELLS, MAX_SCELL_PER_CALL);

        auto fnCheckAllBcAgainstCcNr = [&](const mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBand_,
            const uint16_t /* PCell band is fixed */, const uint16_t, /* PSCell band is unused */
            const uint16_t sCellAltBandTab[MAX_MCO_MFBI_CELLS], const uint32_t sCellIdxTab[MAX_MCO_MFBI_CELLS])
        {
            bool bestSCellsMapLocal[MAX_SCELL_PER_CALL];
            uint32_t effectiveBw = 0;

            if ((GOOD == FnVCCB_McoCheckAllBcForMaxBw(ptCi, *ptUeSupBandCombList, ccInfoVecPerBand_, bestSCellsMapLocal, effectiveBw, bandNr)) &&
                (effectiveBw > effectiveBwMax))
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] Updating result with BW(%u->%u), alt SCells:band[sCellIdx]:(0:%u[%u]/1:%u[%u]/2:%u[%u])\n",
                    effectiveBwMax, effectiveBw,
                    (BAND_NOT_FOUND != sCellAltBandTab[0]) ? sCellAltBandTab[0] : 0, (BAND_NOT_FOUND != sCellAltBandTab[0]) ? sCellIdxTab[0] : MAX_SCELL_PER_CALL,
                    (BAND_NOT_FOUND != sCellAltBandTab[1]) ? sCellAltBandTab[1] : 0, (BAND_NOT_FOUND != sCellAltBandTab[1]) ? sCellIdxTab[1] : MAX_SCELL_PER_CALL,
                    (BAND_NOT_FOUND != sCellAltBandTab[2]) ? sCellAltBandTab[2] : 0, (BAND_NOT_FOUND != sCellAltBandTab[2]) ? sCellIdxTab[2] : MAX_SCELL_PER_CALL);

                effectiveBwMax = effectiveBw;
                std::copy(bestSCellsMapLocal, bestSCellsMapLocal + MAX_SCELL_PER_CALL, rBestSCellsMap);

                for (uint8_t idx = 0; idx < MAX_MCO_MFBI_CELLS; ++idx)
                {
                    sCellAltBandOut[idx] = sCellAltBandTab[idx];
                    sCellIdxWithAltBandOut[idx] = ((BAND_NOT_FOUND != sCellAltBandTab[idx]) ? sCellIdxTab[idx] : MAX_SCELL_PER_CALL);
                }
            }
        };

        FnVCCB_McoForEachAltBand(*ptCi, ccInfoVecPerBand, bandNr, BAND_NOT_FOUND, fnCheckAllBcAgainstCcNr);
    }

    if (noMfbiFlag)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] PCell: num(%u) PCI(%u) BW(%u)\n", cellNum, pCell->phyCellId, effectiveBwMax);
    }
    else
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] PCell: num(%u) PCI(%u) BW(%u), alt SCells: band[sCellIdx]:(0:%u[%u]/1:%u[%u]/2:%u[%u])\n",
            cellNum, pCell->phyCellId, effectiveBwMax,
            ((BAND_NOT_FOUND != sCellAltBandOut[0]) ? sCellAltBandOut[0] : 0), ((BAND_NOT_FOUND != sCellAltBandOut[0]) ? sCellIdxWithAltBandOut[0] : MAX_SCELL_PER_CALL),
            ((BAND_NOT_FOUND != sCellAltBandOut[1]) ? sCellAltBandOut[1] : 0), ((BAND_NOT_FOUND != sCellAltBandOut[1]) ? sCellIdxWithAltBandOut[1] : MAX_SCELL_PER_CALL),
            ((BAND_NOT_FOUND != sCellAltBandOut[2]) ? sCellAltBandOut[2] : 0), ((BAND_NOT_FOUND != sCellAltBandOut[2]) ? sCellIdxWithAltBandOut[2] : MAX_SCELL_PER_CALL));
    }

    return GOOD;
}

/**
 * @brief   MCO: Allocates memory for objects in preallocated buffer.
 */
template <typename T>
T *mcoLinearAllocator_s<T>::allocate(size_type __n, const void *)
{
    AUTO_TRACE_FUNC;

    if ((nullptr == _rBufferInfo.buffer) || (nullptr == _rBufferInfo.currPtr) || (0 == _rBufferInfo.size))
    {
        VCCB_PRINT_ERROR("[MCO] Allocate - invalid BufferInfo: buffer(%p) currPtr(%p) size(%lu)!\n",
            _rBufferInfo.buffer, _rBufferInfo.currPtr, _rBufferInfo.size);
        std::__throw_bad_alloc();
    }

    const std::size_t incrementSize = __n * sizeof(T);

    uint8_t *endPtr = _rBufferInfo.buffer + _rBufferInfo.size;
    void *alignedPtr = _rBufferInfo.currPtr;

    if (alignedPtr > endPtr)
    {
        VCCB_PRINT_ERROR("[MCO] Allocate - no free space, total size(%lu)!\n", _rBufferInfo.size);
        std::__throw_bad_alloc();
    }

#if !defined(IPC_TEST) || (__GNUC__ > 4)
    std::size_t freeSpace = static_cast<std::size_t>(endPtr - static_cast<uint8_t *>(alignedPtr));
    if (nullptr == std::align(alignof(T), sizeof(T), alignedPtr, freeSpace))
    {
        VCCB_PRINT_ERROR("[MCO] Failed to align pointer!\n");
        std::__throw_bad_alloc();
    }
#endif

    if (static_cast<uint8_t *>(alignedPtr) + incrementSize > endPtr)
    {
        VCCB_PRINT_ERROR("[MCO] Allocate - no free space, total size(%lu)!\n", _rBufferInfo.size);
        std::__throw_bad_alloc();
    }

    _rBufferInfo.currPtr = static_cast<uint8_t *>(alignedPtr) + incrementSize;

    return static_cast<T *>(alignedPtr);
}

/**
 * @brief   MCO: Construct BC-Band results cache.
 */
mcoCheckBcBandResultsCache_s::mcoCheckBcBandResultsCache_s(mcoCacheBuffInfo_s &rBufferInfo) :
    _storage(storage_type::allocator_type(rBufferInfo))
{
    AUTO_TRACE_FUNC;
}

/**
 * @brief   MCO: Make key for BC-Band result cache.
            Distinguish DL bandwidth class, UL availability, DL MIMO layer number.
 */
mcoCheckBcBandResultsCache_s::key_type mcoCheckBcBandResultsCache_s::makeBcBandKey(
    const mcoBcBandInfoDq_type &bcBandInfoDq)
{
    AUTO_TRACE_FUNC;
    constexpr std::size_t BAND_INFO_BIT_SIZE = 7;
    static_assert((MAX_BANDS_PER_COMB * BAND_INFO_BIT_SIZE) <= (sizeof(key_type) * 8),
                  "[MCO] (max BandInfo num) * (BandInfo bit size) exceeds key_type capacity!");

    key_type key = 0;

    if ((0 == bcBandInfoDq.size()) || (MAX_BANDS_PER_COMB < bcBandInfoDq.size()))
    {
        return mcoCheckBcBandResultsCache_s::INVALID_KEY;
    }

    for (const mcoUeCapaBcBandInfo_s &bcBandInfo : bcBandInfoDq)
    {
        if (15 < bcBandInfo.numContiguousCcDL)
        {
            return mcoCheckBcBandResultsCache_s::INVALID_KEY;
        }
        key <<= BAND_INFO_BIT_SIZE;
        key |= bcBandInfo.numContiguousCcDL;
        key |= static_cast<key_type>(bcBandInfo.ulFlag << 4);

        // convert dlMimoLayerNum to 2-bit value: 1 -> 0, 2 -> 1, 4 -> 2.
        key_type dlMimoLayerNum = 0x03 & (bcBandInfo.dlMimoLayerNum >> 1);
        key |= static_cast<key_type>(dlMimoLayerNum << 5);
    }

    return key;
}

/**
 * @brief   MCO: Make key for BC-Band result cache.
            Distinguish DL and UL bandwidth class.
 */
mcoCheckBcBandResultsCache_s::key_type mcoCheckBcBandResultsCache_s::makeBcBandKeyDlUl(
    const mcoBcBandInfoDq_type &bcBandInfoDq)
{
    AUTO_TRACE_FUNC;
    constexpr std::size_t MAX_NUM_CONTIGUOUS_CC = 12;
    constexpr std::size_t MAX_NUM_CONTIGUOUS_CC_PLUS_1 = MAX_NUM_CONTIGUOUS_CC + 1;
    constexpr std::size_t BAND_INFO_BIT_SIZE = (sizeof(std::size_t) * 8) - __builtin_clzl(
            MAX_NUM_CONTIGUOUS_CC_PLUS_1 * MAX_NUM_CONTIGUOUS_CC + MAX_NUM_CONTIGUOUS_CC); // 13*12+12=168->8bits
    static_assert((MAX_BANDS_PER_COMB * BAND_INFO_BIT_SIZE) <= (sizeof(key_type) * 8),
                  "[MCO] (max BandInfo num) * (BandInfo bit size) exceeds key_type capacity!");

    key_type key = 0;

    if ((0 == bcBandInfoDq.size()) || (MAX_BANDS_PER_COMB < bcBandInfoDq.size()))
    {
        return mcoCheckBcBandResultsCache_s::INVALID_KEY;
    }

    for (const mcoUeCapaBcBandInfo_s &bcBandInfo : bcBandInfoDq)
    {
        if ((MAX_NUM_CONTIGUOUS_CC < bcBandInfo.numContiguousCcDL) ||
            (MAX_NUM_CONTIGUOUS_CC < bcBandInfo.numContiguousCcUL))
        {
            return mcoCheckBcBandResultsCache_s::INVALID_KEY;
        }
        key <<= BAND_INFO_BIT_SIZE;
        key |= (bcBandInfo.numContiguousCcDL * MAX_NUM_CONTIGUOUS_CC_PLUS_1) + bcBandInfo.numContiguousCcUL;
    }

    return key;
}

/**
 * @brief   MCO: Get copy of cached BC-Band result. If not found return false.
 */
bool mcoCheckBcBandResultsCache_s::getResult(const key_type &key, mcoCheckBcResult_s &resultOut) const
{
    AUTO_TRACE_FUNC;

    storage_type::const_iterator it = _storage.find(key);
    if (_storage.end() == it)
    {
        return false;
    }

    resultOut = it->second;
    return true;
}

/**
 * @brief   MCO: Set result to cache if not already set. If already exists return false.
 */
bool mcoCheckBcBandResultsCache_s::setResult(const key_type &key, const mcoCheckBcResult_s &result)
{
    AUTO_TRACE_FUNC;

    if (mcoCheckBcBandResultsCache_s::INVALID_KEY == key)
    {
        return false;
    }

    try
    {
        return _storage.insert(storage_type::value_type(key, result)).second;
    }
    catch (const std::bad_alloc &)
    {
        VCCB_PRINT_ERROR("[MCO] Unable to insert result to cache!\n");
    }
    return false;
}

/**
 * @brief   MCO: Cache's constructor.
 */
mcoBand2BcBandResultsCache_s::mcoBand2BcBandResultsCache_s(const callInfo_type *ptCi) :
    _threadId(
        ((nullptr == ptCi) || (ptCi->bitFlag.isMcoLteAccessCase) || (MAX_CALL_THREAD_NUM_VCCB <= ptCi->myThreadId))
            ? VCCB_CALL_THREAD_NUM
            : ptCi->myThreadId),
    _rBufferInfo((VCCB_CALL_THREAD_NUM <= _threadId) ? _buffInfoMainTh : _buffInfoCallThTab[_threadId]),
    _storageNr(mcoBand2BcBandResultsCacheInternal_type::allocator_type(_rBufferInfo)),
    _storageEutra(mcoBand2BcBandResultsCacheInternal_type::allocator_type(_rBufferInfo))
{
    AUTO_TRACE_FUNC;

    initBuffer();
}

/**
 * @brief   MCO: Initialize cache's buffer.
 */
void mcoBand2BcBandResultsCache_s::initBuffer()
{
    AUTO_TRACE_FUNC;

    if (VCCB_CALL_THREAD_NUM <= _threadId)
    {
        _rBufferInfo.buffer = THREAD_INFO->nonUeAsn1.buf.mcoBcBandResultsCache;
        _rBufferInfo.currPtr = THREAD_INFO->nonUeAsn1.buf.mcoBcBandResultsCache;
        _rBufferInfo.size = sizeof(THREAD_INFO->nonUeAsn1.buf.mcoBcBandResultsCache);
    }
    else
    {
        _rBufferInfo.buffer = THREAD_INFO->call[_threadId].buf.mcoBcBandResultsCache;
        _rBufferInfo.currPtr = THREAD_INFO->call[_threadId].buf.mcoBcBandResultsCache;
        _rBufferInfo.size = sizeof(THREAD_INFO->call[_threadId].buf.mcoBcBandResultsCache);
    }
}

/**
 * @brief   MCO: Initialize cache. Call init() always before new computations.
 */
void mcoBand2BcBandResultsCache_s::init()
{
    AUTO_TRACE_FUNC;

    _storageNr.clear();
    _storageEutra.clear();
    initBuffer();
}

/**
 * @brief   MCO: Get cache storage for given band. Returns nullptr in case of allocation error.
 */
mcoCheckBcBandResultsCache_s *mcoBand2BcBandResultsCache_s::getForBand(const enumRAT_type ratType, const uint16_t band)
{
    AUTO_TRACE_FUNC;

    // Try to insert new mcoCheckBcBandResultsCache_s into a _storageNr/_storageEutra.
    // If there is already an element with the key(band) in the container then newly constructed
    // mcoCheckBcBandResultsCache_s will be destroyed. If there is allocation error then std::bad_alloc exception will
    // be thrown.

    try
    {
        if (ci_nr == ratType)
        {
            return &(
                _storageNr.emplace(std::make_pair(band, mcoCheckBcBandResultsCache_s(_rBufferInfo))).first->second);
        }
        else
        {
            return &(
                _storageEutra.emplace(std::make_pair(band, mcoCheckBcBandResultsCache_s(_rBufferInfo))).first->second);
        }
    }
    catch (const std::bad_alloc &)
    {
        VCCB_PRINT_ERROR("[MCO] Unable to allocate BC-Band(%u) result in cache!\n", band);
    }
    return nullptr;
}

/**
 * @brief   MCO: Get existing cache storage for given band. Returns nullptr if not found.
 */
const mcoCheckBcBandResultsCache_s *mcoBand2BcBandResultsCache_s::getForBand(
    const enumRAT_type ratType, const uint16_t band) const
{
    AUTO_TRACE_FUNC;

    const mcoBand2BcBandResultsCacheInternal_type &storage = (ci_nr == ratType) ? _storageNr : _storageEutra;
    mcoBand2BcBandResultsCacheInternal_type::const_iterator it = storage.find(band);
    if (storage.end() == it)
    {
        return nullptr;
    }
    return &it->second;
}

static X2_CellIdentity_type FnVCCB_makeX2NrCgi(const cgi_type &nrcgi)
{
    AUTO_TRACE_FUNC;

    X2_CellIdentity_type cellId{};
    cellId.choice = X2_nrcgi_chosen;
    cellId.u.nrcgi.nRcellIdentifier = nrcgi.ci;
    makePLMN_type(&nrcgi.plmn, &cellId.u.nrcgi.pLMN_Identity);
    return cellId;
}

// convert RB unit to Mhz unit for use in NR // SVR23B_MRS
#define CONVERT_RB_TO_MHZ_UNIT(__tp) \
do{                                  \
    __tp = (__tp) / 5;               \
}while(0)                            \

// Convert from Mhz unit to RB unit for use in LTE // SVR23B_MRS
#define CONVERT_MHZ_TO_RB_UNIT(__tp) \
do{                                  \
    __tp = (__tp) * 5;               \
}while(0)                            \

static X2_SamsungBandCombinationInfo_type FnVCCB_makeSamsungBandCombinationInfo(
    uint32_t zeroBasedBcIndex, uint32_t effectiveBw, const VccbCellInfo_type &cellInfo)
{
    AUTO_TRACE_FUNC;

    X2_SamsungBandCombinationInfo_type bcInfo{};

    bcInfo.bandCombinationIndex = zeroBasedBcIndex + 1;

    // not used
    bcInfo.m.featureSetsIndexpresent = VCCB_FLAG_OFF;

    bcInfo.expectedThroughput = effectiveBw;
    CONVERT_MHZ_TO_RB_UNIT(bcInfo.expectedThroughput);

    bcInfo.physCellId = cellInfo.phyCellId;

    bcInfo.cellIdentity = FnVCCB_makeX2NrCgi(FnVCCB_GetNrcgiFromCellInfo(&cellInfo));

    return bcInfo;
}

static void FnVCCB_addSelectedBandCombinationNr(
    X2_PrivateMessage_type &toFill, const X2_SamsungBandCombinationInfo_type &bc)
{
    AUTO_TRACE_FUNC;

    toFill.samsungPrivateMessageContent.u.bcInfoResponse.selectedBandCombinationNR = bc;
    toFill.samsungPrivateMessageContent.u.bcInfoResponse.m.selectedBandCombinationNRpresent = true;
}

static void FnVCCB_addSelectedBandCombinationMrdc(
    X2_PrivateMessage_type &toFill, const X2_SamsungBandCombinationInfo_type &bc)
{
    AUTO_TRACE_FUNC;

    toFill.samsungPrivateMessageContent.u.bcInfoResponse.selectedBandCombinationMRDC = bc;
    toFill.samsungPrivateMessageContent.u.bcInfoResponse.m.selectedBandCombinationMRDCpresent = true;
}

/**
 * @brief     Fill SamsungBcInfoResponse SA part
 * @param     ptCi : temporary call context
 * @param     msg : reference to X2_PrivateMessage_type
 * @param     pCellFrequency
 * @return    status: / int16_t
              GOOD if SamsungBcInfoResponse SA part is successfully filled
              BREAK if it can't be filled
              ERROR unrecoverable error
 */
static int16_t FnVCCB_McoFillSamsungBcInfoResponseSA(callInfo_type *ptCi, X2_PrivateMessage_type &toFill,
    uint32_t pCellFrequency, const MeasuredBands_type &measuredBands)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    bandCombinationList_type *pBcList = &THREAD_INFO->nonUeAsn1.buf.mcoBcInfoReqStore.nrBandCombListBuff;
    if (0 == pBcList->num)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] Empty NR bc list, cannot proceed!\n");
        return BREAK;
    }

    measResultList2NR_type *ptMeasResultList2NR = &THREAD_INFO->nonUeAsn1.buf.measResultList2NRRx.candidateCellInfoList;
    ptCi->callType = E_CALLTYPE_SA;

    uint16_t cellNum = FnVCCB_McoSelectBestPCell(ptCi, ptMeasResultList2NR, pCellFrequency, measuredBands);
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);
    ptCi->servCellNum = cellNum;
    ptCi->nRCGI = FnVCCB_GetNrcgiFromCellNum(cellNum);
    ptCi->servCellBand = BAND_NOT_FOUND;

    // best BC selection
    uint32_t selectedBcIndex = 0, effectiveBw = 0;
    if (GOOD != FnVCCB_McoFindBestBcForLteAccess(ptCi, pBcList, measuredBands, &effectiveBw, &selectedBcIndex))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] Cannot find Best BC for SA!\n");
        return ERROR;
    }

    FnVCCB_addSelectedBandCombinationNr(
        toFill, FnVCCB_makeSamsungBandCombinationInfo(selectedBcIndex, effectiveBw, CELLINFO[cellNum]));

    return GOOD;
}

/**
 * @brief     Fill SamsungBcInfoResponse ENDC part
 * @param     ptCi : temporary call context
 * @param     msg : reference to X2_PrivateMessage_type
 * @param     pCellFrequency
 * @return    status: / int16_t
              GOOD if SamsungBcInfoResponse ENDC part is successfully filled
              BREAK if it can't be filled
              ERROR unrecoverable error
 */
static int16_t FnVCCB_McoFillSamsungBcInfoResponseENDC(callInfo_type *ptCi, X2_PrivateMessage_type &toFill,
    uint32_t pCellFrequency, const MeasuredBands_type &measuredBands)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (!(enumSamsungBcInfoRequestStoreStatus_ueMrdcCapaStored &
                THREAD_INFO->nonUeAsn1.buf.mcoBcInfoReqStore.storeStatus))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] UE-MRDC-Capability not present, cannot proceed!\n");
        return BREAK;
    }

    bandCombinationList_type *pBcList = &THREAD_INFO->nonUeAsn1.buf.mcoBcInfoReqStore.mrdcBandCombListBuff;
    if (0 == pBcList->num)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] Empty MRDC bc list, cannot proceed!\n");
        return BREAK;
    }

    measResultList2NR_type *ptMeasResultList2NR = &THREAD_INFO->nonUeAsn1.buf.measResultList2NRRx.candidateCellInfoList;
    ptCi->callType = E_CALLTYPE_NSA;

    uint16_t cellNum = FnVCCB_McoSelectBestPCell(ptCi, ptMeasResultList2NR, pCellFrequency, measuredBands);
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);
    ptCi->servCellNum = cellNum;
    ptCi->nRCGI = FnVCCB_GetNrcgiFromCellNum(cellNum);
    ptCi->servCellBand = BAND_NOT_FOUND;

    // best BC selection
    uint32_t selectedBcIndex = 0, effectiveBw = 0;
    if (GOOD != FnVCCB_McoFindBestBcForLteAccess(ptCi, pBcList, measuredBands, &effectiveBw, &selectedBcIndex))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] Cannot find Best BC for ENDC!\n");
        return ERROR;
    }

    FnVCCB_addSelectedBandCombinationMrdc(
        toFill, FnVCCB_makeSamsungBandCombinationInfo(selectedBcIndex, effectiveBw, CELLINFO[cellNum]));

    return GOOD;
}

static X2_PrivateMessage_type *FnVCCB_getX2PrivateMessageBuffer()
{
    AUTO_TRACE_FUNC;

    return &THREAD_INFO->nonUeAsn1.buf.tx.x2ap.privateMessage;
}

/**
 * @brief     Fill and send SamsungBcInfoResponse
 * @param     ptCi : temporary call context
 * @return    status: / int16_t
              GOOD - sending completed successfully
              BREAK - sending didn't succeed
              ERROR - unrecoverable error
 */
int16_t FnVCCB_McoSendSamsungBcInfoResponse(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    ptCi->bitFlag.isMcoLteAccessCase = TRUE;

    X2_PrivateMessage_type *ptMsg = FnVCCB_getX2PrivateMessageBuffer();

    uint32_t pCellFrequency = 0;
    MeasuredBands_type measuredBands;
    measResultList2NR_type *ptMeasResultList2NR = &THREAD_INFO->nonUeAsn1.buf.measResultList2NRRx.candidateCellInfoList;
    int16_t status = FnVCCB_McoSelectPrimaryCarrierFreq(ptCi, ptMeasResultList2NR, &pCellFrequency, measuredBands);
    if (GOOD != status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[MCO] selecting PCC failed with status %d\n", status);
        return BREAK;
    }
    VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] selected PCC: %d (%d)\n", pCellFrequency, status);

    if (GOOD != VXIL_makeX2_PrivateMessage_BcInfoResp(ptCi, ptMsg))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VXIL_makeX2_PrivateMessage_BcInfoResp ERROR!\n");
        return BREAK;
    }

    int16_t saStatus = FnVCCB_McoFillSamsungBcInfoResponseSA(ptCi, *ptMsg, pCellFrequency, measuredBands);
    if (BREAK == saStatus)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "SA part of bcInfoResp is skipped.\n");
    }
    if (ERROR == saStatus)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "ERROR in FnVCCB_McoFillSamsungBcInfoResponseSA!\n");
    }

    int16_t endcStatus = FnVCCB_McoFillSamsungBcInfoResponseENDC(ptCi, *ptMsg, pCellFrequency, measuredBands);
    if (BREAK == endcStatus)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "ENDC part of bcInfoResp is skipped.\n");
    }
    if (ERROR == endcStatus)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "ERROR in FnVCCB_McoFillSamsungBcInfoResponseENDC!\n");
    }

    if ((GOOD != saStatus) && (GOOD != endcStatus))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Both SA and ENDC responses failed to be filled!\n");
        return BREAK;
    }

    if (GOOD != VXIL_sendX2_PrivateMessage(ptCi, ptMsg))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VXIL_sendX2_PrivateMessage ERROR!\n");
        return ERROR;
    }

    return GOOD;
}

/**
 * @brief     Checks if a private message should be discarded
 * @param     X2_PrivateMessage_type : private message
 * @return    true if message should be discarded, false otherwise
 */
bool FnVCCB_McoCheckIfPrivateMessageShouldBeDiscarded(const X2_PrivateMessage_type &msg)
{
    AUTO_TRACE_FUNC;

    if (!msg.m.meNB_UE_X2AP_IDPresent)
    {
        VCCB_PRINT_ERROR("Unsupported X2_PrivateMessage: eNB UE X2AP ID is not present!\n");
        return true;
    }
    if (msg.m.samsungVirtualUEIndicatorPresent)
    {
        VCCB_PRINT_ERROR("Unsupported X2_PrivateMessage: virtual UE indicator is present!\n");
        return true;
    }
    if (!msg.m.samsungPrivateMessageContentPresent)
    {
        VCCB_PRINT_ERROR("Unsupported X2_PrivateMessage: content is not present!\n");
        return true;
    }
    if (X2_bcInfoRequest_chosen != msg.samsungPrivateMessageContent.choice)
    {
        VCCB_PRINT_ERROR("Unsupported X2_PrivateMessage: content is not bcInfoRequest!\n");
        return true;
    }

    return false;
}

bool FnVCCB_McoCheckIfAcceptMessage(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, false);

    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];

    return pGnb->multiCarrierOperation.multiRatCarrierChange;
}

/**
 * @brief     Checks if Valid  BC Information Response  message
 * @param     ptMsg : X2 Private Message
 * @return    TRUE if X2 Private Message is BC Information Response, FALSE otherwise
 */
bool FnVCCB_CheckBCInfoResponse(const X2_PrivateMessage_type &msg)
{
    AUTO_TRACE_FUNC;

    if(!msg.m.samsungPrivateMessageContentPresent)
    {
        VCCB_PRINT_ERROR("Unsupported X2_PrivateMessage: samsungPrivateMessageContentPresent is not present!\n");
        return false;
    }

    if(X2_bcInfoResponse_chosen != msg.samsungPrivateMessageContent.choice)
    {
        VCCB_PRINT_ERROR("Unsupported X2_PrivateMessage: samsungPrivateMessageContent is not bcInfoResponse!\n");
        return false;
    }

    return true;
}

/**
 * @brief     Check if it is a valid target Eutra Cell.
 * @param     ptCi : temporary call context
 * @return    ERROR - invalid Target Eutra Cell
              GOOD - valid Target Eutra Cell
 */
int16_t FnVCCB_MrsCheckValidTargetEutraCell(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);

    nbrEutraCellInfo_type *pNbrEutraCell = NULL;
    nbrEnbCellInfo_type *pNbrEnbCell = NULL;
    McoBcInfoRespCallThreadStore_type *pBcInfoResp = &THREAD_INFO->call[ptCi->myThreadId].buf.mcoBcInfoResp;
    uint16_t nbrIdx = MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL;

    nbrIdx = FnVCCB_FindEutraNbrIdxByCgi(ptCi->servCellNum, pBcInfoResp->eutraCgi);
    if(nbrIdx >= MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL)
    {
        // Failed to find EUTRA NBR
        VCCB_PRINT_CALL_ERROR(ptCi, "Failed to Find Eutra NBR Index !!\n");
        return ERROR;
    }

    pNbrEutraCell = &CELLINFO[ptCi->servCellNum].eutraNbr[nbrIdx];
    if(FALSE == pNbrEutraCell->isHoAllowed)
    {
        // Target Cell is not available HO
        VCCB_PRINT_CALL_ERROR(ptCi, "Target Eutra Cell(%d) is not HO Allowed !!\n", nbrIdx);
        return ERROR;
    }

    if(GOOD != getNbrEnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &pNbrEnbCell) || (NULL == pNbrEnbCell) )
    {
        // Failed to find EUTRA NBR ENB Cell
        VCCB_PRINT_CALL_ERROR(ptCi, "getNbrEnbCellByCellNbrIdx[%d] ERROR !!\n", nbrIdx);
        return ERROR;
    }

    if(EQUIP != pNbrEnbCell->status)
    {
        // Invalid Status
        VCCB_PRINT_CALL_ERROR(ptCi, "NbrEnbCellIdx[%d] Invalid Status !!\n", nbrIdx);
        return ERROR;
    }

    if(pBcInfoResp->eutraPci != pNbrEnbCell->pci)
    {
        // Different PCI value
        VCCB_PRINT_CALL_ERROR(ptCi, "Target PCI is different.NBR[%d](%d/%d) ERROR !\n", nbrIdx, pBcInfoResp->eutraPci, pNbrEnbCell->pci);
        return ERROR;
    }

    // Find Valid Eutra Object
    const enumMeasurementReportType reportType = measReport_B1Eutra;
    const uint8_t reportPurpose = b1Purpose_multiRatSelection;

    uint16_t objIdx = 0;
    for(; objIdx < MAX_NR_OF_OBJECTEUTRA_ID_DB; ++objIdx)
    {
        measurementObjectEUTRADb_type *ptMO = &CELLINFO[ptCi->servCellNum].measurementsData.measurementObjectsEUTRADb[objIdx];
        measurementObjectEUTRABaseDb_type *ptMOBase = &ptMO->base;

        if(pNbrEnbCell->earfcnDl != ptMOBase->carrierFreq)
        {
            continue;
        }

        if (GOOD != VCCM_CheckSupportEutraMeasObject(ptCi, ptMO))
        {
            continue;
        }

        if (GOOD != VCCM_CheckSupportEutraMeasObject_ForIratHo( ptCi, ptMOBase, ptCi->servCellNum, reportType, reportPurpose))
        {
            continue;
        }

        break; // Find Valid Eutra OBJ
    }

    if(MAX_NR_OF_OBJECTEUTRA_ID_DB <= objIdx)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Failed to find Valid EUTRA FA for earfcnDL:%u !!\n", pNbrEnbCell->earfcnDl);
        return ERROR;
    }

    // Update Target EUTRA Info */
    ptCi->mrsInfo.targetEutraInfo.cgi = pBcInfoResp->eutraCgi;
    ptCi->mrsInfo.targetEutraInfo.pci = pBcInfoResp->eutraPci;
    ptCi->mrsInfo.targetEutraInfo.earfcnDl = pNbrEnbCell->earfcnDl;
    ptCi->mrsInfo.targetEutraInfo.nbrIdx = nbrIdx;

    VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] Update MrsInfo targetEutraInfo cgi.plmn(0x%x) cgi.ci(%lu) pci(%d) earfcnDl(%d) nbrIdx(%d)\n",
            ptCi->mrsInfo.targetEutraInfo.cgi.plmn.longId,
            ptCi->mrsInfo.targetEutraInfo.cgi.ci,
            ptCi->mrsInfo.targetEutraInfo.pci,
            ptCi->mrsInfo.targetEutraInfo.earfcnDl,
            ptCi->mrsInfo.targetEutraInfo.nbrIdx);

    return GOOD; // EUTRA HO Available
}

/**
 * @brief Getting Effective BandWidth from gNB Access Case
 *
 * @param ptCi : Call Information / callInfo_type
 * @param selectedBcIndex : selectedBcIndex
 * @param ccInfoVecPerBand : reference to map <freqband, vector of cells>
 * @param mcoBand2BcBandResultsCache : reference to filled cache from BC selection
 * @return uint32_t effectiveBw
 */
uint32_t FnVCCB_GetEffectiveBwGnbAccessCase(callInfo_type *ptCi,
        uint32_t selectedBcIndex,
        const mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBand,
        const mcoBand2BcBandResultsCache_s &mcoBand2BcBandResultsCache)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ZERO(ptCi);

    uint32_t effectiveBw = 0;
    BandCombination_type *ptBc;

    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB, effectiveBw);

    vector<uint32_t> sCellFreqList;

    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    if (E_CALLTYPE_SA == ptCi->callType)
    {
        VCCB_CHECK_E_RANGE_AND_VAL(selectedBcIndex, MIN(MAX_BAND_COMBS, THREAD_INFO->call[ptCi->myThreadId].buf.nrBandCombList.num), effectiveBw);
        ptBc = &THREAD_INFO->call[ptCi->myThreadId].buf.nrBandCombList.bandCombination[selectedBcIndex];
    }
    else
    {
        VCCB_CHECK_E_RANGE_AND_VAL(selectedBcIndex, MIN(MAX_BAND_COMBS, THREAD_INFO->call[ptCi->myThreadId].buf.mrdcBandCombList.num), effectiveBw);
        ptBc = &THREAD_INFO->call[ptCi->myThreadId].buf.mrdcBandCombList.bandCombination[selectedBcIndex];

        // Get Released SCell Frequency List
        switch(ptCi->caInfo.mode)
        {
            case CaOperation_Mode2:
            case CaOperation_Mode3:
            case CaOperation_Mode5:
                for(uint8_t scellIdx = 0; scellIdx < MAX_SCELL_PER_CALL; ++scellIdx)
                {
                    if((SCELL_STATE_MRREL == scells[scellIdx].state) && (SCELL_ACTION_KEEP == scells[scellIdx].action))
                    {
                        sCellFreqList.push_back( scells[scellIdx].ssbArfcn );
                    }
                }
                break;

            default:
                break;
        }
    }

    mcoBand2numContCcDq_type mcoBand2numContCcDq;
    mcoBand2mcoNumContiguousCc_type dummy;

    const McoAlgoFlags algoFlags = { .noMimo = false,
                                     .checkUlBw = false,
                                     .ulOnlyMode = false,
                                     .mfbiCheck = false,
                                     .initialFmPcc = false,
                                     .checkCarrierOnly = false,
                                     .useSe = false,
                                     .useMultiChBw = false };
    FnVCCB_McoRetrieveBcData(ptCi, *ptBc, selectedBcIndex, ci_nr, algoFlags, mcoBand2numContCcDq, dummy);

    VCCB_CHECK_VALID_GNBNUM_FALSE(ptCi->gnbNum);
    const VccbGnbInfo_type &rGnb = GNBINFO[ptCi->gnbNum];
    for(const mcoBand2numContCcDq_type::value_type &kv : mcoBand2numContCcDq)
    {
        const uint16_t bandNr = kv.first;

        mcoBand2mcoCcInfoVecMap_type::const_iterator ccInfoVecPerBandIt = ccInfoVecPerBand.find(bandNr);
        if (ccInfoVecPerBand.end() == ccInfoVecPerBandIt)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MRS] band-NR(%u) check: No CC\n", bandNr);
            continue;
        }

        mcoCheckBcResult_s bcBandPermResult;
        const mcoCheckBcBandResultsCache_s *pBcBandCache = mcoBand2BcBandResultsCache.getForBand(ci_nr, bandNr);
        mcoCheckBcBandResultsCache_s::key_type bcBandKey = mcoCheckBcBandResultsCache_s::makeBcBandKey(kv.second);

        if ((nullptr == pBcBandCache) || (true != pBcBandCache->getResult(bcBandKey, bcBandPermResult)))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MRS] band-NR(%u) check: No cache\n", bandNr);
            continue;
        }

        effectiveBw += FnVCCB_GetEffectiveBwOfSingleBand(rGnb,
            ccInfoVecPerBandIt->second.ccInfoVec, bcBandPermResult.ccIdxBitmask, bcBandPermResult.ccMimo2Bitmask, bcBandPermResult.ccMimo4Bitmask, sCellFreqList);
    }

    return effectiveBw;
}

/**
 * @brief Calculate SA Expected Throughput
 * @param [in] ptCi : Call Information / callInfo_type
 * @param [in] pSaExpectedTp : variable to calculate and SA Expected Throughput
 */
void FnVCCB_MrsCalculateSaExpectedTp(callInfo_type *ptCi, uint32_t *pSaExpectedTp)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pSaExpectedTp);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);

    mcoBand2BcBandResultsCache_s mcoBand2BcBandResultsCache(ptCi);
    MeasuredBands_type measuredBands;

    mcoBand2mcoCcInfoVecMap_type ccInfoVecPerBand;
    uint16_t pcellBand = BAND_NOT_FOUND;
    uint32_t bcIndex;

    *pSaExpectedTp = 0;

    /* 1. Get NR Band Combination List */
    bandCombinationList_type *ptUeSupBandCombList = VRIL_GetBandCombinationList(ptCi);
    VALID_E_POINT_CHECK_VOID(ptUeSupBandCombList);

    FnVCCB_McoDebugPrintUeCapaBcList(ptCi, *ptUeSupBandCombList);

    /* 2. set ccInfoVecPerBand registered SCell Information */
    FnVCCB_McoPrepareCurrentScellContiguousNrCellGroups(ptCi, ccInfoVecPerBand, pcellBand);
    if ((0 == ccInfoVecPerBand.size()) || (BAND_NOT_FOUND == pcellBand))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MRS] No valid NR Current SCell CC !!\n");
        return;
    }

    // check each BC against NR CC
    McoBCIdxArray_type bcBwMaxIdxDq;
    uint32_t bcBwMaxOut = 0;

    /* 3. Get MAX BandWidth based PCell and SCell (Existing Function) */
    const McoAlgoFlags algoFlags = { .noMimo = false,
                                     .checkUlBw = false,
                                     .ulOnlyMode = false,
                                     .mfbiCheck = false,
                                     .initialFmPcc = false,
                                     .checkCarrierOnly = false,
                                     .useSe = false,
                                     .useMultiChBw = false };
    FnVCCB_McoCheckAllBcAgainstCcNr(ptCi, *ptUeSupBandCombList, pcellBand, BAND_NOT_FOUND, ccInfoVecPerBand, algoFlags,
            mcoBand2BcBandResultsCache, bcBwMaxIdxDq, bcBwMaxOut);

    /* bcBw */
    if(0 == bcBwMaxIdxDq.size())
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[MRS][SA:BcSel] No UE Capa BC selected!\n");
        return;
    }
    else if(1 == bcBwMaxIdxDq.size())
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MRS][SA:BCSel] Found one best UE Capa BC idx(%u/%u) BW(%u)\n",
            bcBwMaxIdxDq[0], ptCi->duSelectionRelatedData.selectedBC, bcBwMaxOut);
        bcIndex = bcBwMaxIdxDq[0];
    }
    else
    {
        unsigned int randVal = FnVCCB_GetRandomValue(__func__, ptCi->gnbNum, (int)bcBwMaxIdxDq.size());
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MRS][SA:BCSel] Found (%zu) UE Capa BC with equal max BW. Randomly(%u) selected idx(%u)\n",
                                bcBwMaxIdxDq.size(), randVal, bcBwMaxIdxDq[randVal]);
        bcIndex = bcBwMaxIdxDq[randVal];
    }

    /* 4. Get Final SA Expected TP */
    *pSaExpectedTp = FnVCCB_GetEffectiveBwGnbAccessCase(ptCi, bcIndex, ccInfoVecPerBand, mcoBand2BcBandResultsCache);
}

/**
 * @brief Calculate EN-DC Expected Throughput
 * @param [in] ptCi : Call Information / callInfo_type
 * @param [in] pEndcExpectedTp : variable to calcuate and store EN-DC Expected Throughput
 * @param [in] ptBcIndex : Index of Band Combination with the MAX BW
 */
void FnVCCB_MrsCalculateEndcExpectedTp(callInfo_type *ptCi, uint32_t *pEndcExpectedTp, uint32_t *ptBcIndex)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pEndcExpectedTp);
    VALID_E_POINT_CHECK_VOID(ptBcIndex);
    VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);

    mcoBand2BcBandResultsCache_s mcoBand2BcBandResultsCache(ptCi);
    MeasuredBands_type measuredBands;
    enumCallType_type prevCallType;

    mcoBand2mcoCcInfoVecMap_type ccInfoVecPerBand;
    uint16_t pcellBand = BAND_NOT_FOUND;

    // Not Exist Allowed MRDC List
    if(VCCB_FLAG_ON != ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC_Flag)
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] allowedBC_ListMRDC_Flag Off[%d]\n", ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC_Flag);
        return;
    }

    *pEndcExpectedTp = 0; // Init

    prevCallType = ptCi->callType; // Back-up Call Type
    ptCi->callType = E_CALLTYPE_NSA; // NSA Set

    bandCombinationList_type *ptUeMrdcBandCombList = VRIL_GetBandCombinationList(ptCi);
    if(NULL == ptUeMrdcBandCombList)
    {
        ptCi->callType = prevCallType;
        VCCB_PRINT_ERROR("[MRS] ptUeMrdcBandCombList(EN-DC) is NULL !!\n");
        return;
    }

    FnVCCB_McoDebugPrintUeCapaBcList(ptCi, *ptUeMrdcBandCombList);

    McoAlgoFlags algoFlags = {
        .noMimo = false,
        .checkUlBw = false,
        .ulOnlyMode = false,
        .mfbiCheck = false,
        .initialFmPcc = false,
        .checkCarrierOnly = false,
        .useSe = false,
        .useMultiChBw = false };
    FnVCCB_McoPrepareColocContiguousNrCellGroups(ptCi, ptCi->servCellNum, algoFlags, ccInfoVecPerBand, pcellBand);

    if((0 == ccInfoVecPerBand.size()) || (BAND_NOT_FOUND == pcellBand))
    {
        ptCi->callType = prevCallType; // Re-store Call Type
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MRS] No valid NR colocated CC !!\n");
        return;
    }

    // check each BC against NR CC
    McoBCIdxArray_type bcBwMaxIdxDq;
    uint32_t bcBwMax = 0;
    FnVCCB_McoCheckAllBcAgainstCcNr(ptCi, *ptUeMrdcBandCombList, pcellBand, BAND_NOT_FOUND, ccInfoVecPerBand, algoFlags,
            mcoBand2BcBandResultsCache, bcBwMaxIdxDq, bcBwMax);

    if(0 == bcBwMaxIdxDq.size())
    {
        ptCi->callType = prevCallType; // Re-store Call Type
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MRS][ENDC:BCSel] No UE Capa BC selected !!\n");
        return;
    }
    else if(1 == bcBwMaxIdxDq.size())
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MRS][ENDC:BCSel] Found one best UE Capa BC idx(%u)\n", bcBwMaxIdxDq[0]);
        *ptBcIndex = bcBwMaxIdxDq[0];
    }
    else if(0 < ptCi->cgConfigInfo.servCellInfoListMcgEutra.numItems)
    {
        // For EN-DC case check MCG cell count if servCellInfoListMcgEutra was received.
        mcoBand2mcoCcInfoVecMap_type mcoCcInfoVecPerBand;
        uint16_t mcgPCellBand = BAND_NOT_FOUND;

        FnVCCB_McoPrepareMcgContiguousEutraCellGroups(ptCi, mcoCcInfoVecPerBand, mcgPCellBand);
        if((0 == mcoCcInfoVecPerBand.size()) || (BAND_NOT_FOUND == mcgPCellBand))
        {
            ptCi->callType = prevCallType; // Re-store Call Type
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MRS] No valid MCG CC !!\n");
            return;
        }

        // check selected BC against EUTRA CC
        McoBCIdxArray_type bcMaxCcCntIdxDq;
        FnVCCB_McoCheckSelectedBcAgainstCcEutra(ptCi, *ptUeMrdcBandCombList, mcgPCellBand, mcoCcInfoVecPerBand, bcBwMaxIdxDq,
                                                mcoBand2BcBandResultsCache, bcMaxCcCntIdxDq);
        if(0 == bcMaxCcCntIdxDq.size())
        {
            ptCi->callType = prevCallType; // Re-store Call Type
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MRS][ENDC:BCSel] No UE Capa BC selected with MCG CC !!\n");
            return;
        }
        else if(1 == bcMaxCcCntIdxDq.size())
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MRS][ENDC:BCSel] Found one best UE Capa BC idx(%u) with MCG CC\n", bcMaxCcCntIdxDq[0]);
            *ptBcIndex = bcMaxCcCntIdxDq[0];
        }
        else
        {
            unsigned int randVal = FnVCCB_GetRandomValue(__func__, ptCi->gnbNum, (int) bcMaxCcCntIdxDq.size());
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MRS][ENDC:BCSel] Found (%zu) UE Capa BC with MCG CC. Randomly(%u) selected idx(%u)\n",
                                    bcMaxCcCntIdxDq.size(), randVal, bcMaxCcCntIdxDq[randVal]);
            *ptBcIndex = bcMaxCcCntIdxDq[randVal];
        }
    }
    else
    {
        unsigned int randVal = FnVCCB_GetRandomValue(__func__, ptCi->gnbNum, (int) bcBwMaxIdxDq.size());
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MRS][ENDC:BCSel] Found (%zu) UE Capa BC with equal max BW. Randomly(%u) selected idx(%u)\n",
                                bcBwMaxIdxDq.size(), randVal, bcBwMaxIdxDq[randVal]);
        *ptBcIndex = bcBwMaxIdxDq[randVal];
    }

    *pEndcExpectedTp = FnVCCB_GetEffectiveBwGnbAccessCase(ptCi, *ptBcIndex, ccInfoVecPerBand, mcoBand2BcBandResultsCache);

    ptCi->callType = prevCallType; // Re-store Call Type

    return;
}



/**
 * @brief  Decide Inter RAT Handover to EUTRA
 * @param  [in] ptCi  : call Information / callInfo_type
 * @return ERROR : Stay NR / GOOD : Handover Trigger
 */
int16_t FnVCCB_MrsDecideInterRATHandoverToEutra(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);

    uint32_t saExpectedTp = 0, endcExpectedTp = 0;
    int32_t offsetLte = 0, offsetEndc = 0;
    uint32_t receivedEndcTp = 0;
    uint32_t endcBcIndex = 0;

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    McoBandCombinationExpectedThroughputList_type* ptExpectedTpList = &THREAD_INFO->call[ptCi->myThreadId].buf.mcoBcInfoResp.expectedThroughputList;

    // Check Inter-RAT Handover Condition(to EUTRA)
    if(ERROR == VCCM_IsIratHandoverCondition(ptCi))
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] IsIratHandoverCondition Error !!\n");
        return ERROR;
    }

    // Check EUTRA PCell Available and HO Available.
    if(ERROR == FnVCCB_MrsCheckValidTargetEutraCell(ptCi))
    {
        // EUTRA Target Cell is not available for Handover
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] MrsCheckValidTargetEutraCell Error !!\n");
        return ERROR;
    }

    /* 1. Calculate SA Expected TP */
    FnVCCB_MrsCalculateSaExpectedTp(ptCi, &saExpectedTp);

    VCCB_PRINT_LOG_MRS_FUNC(ptCi, "** [MRS][CalcResult] saExpectedTp(%u) \n", saExpectedTp);


    /* 2. Calculate EN-DC Expected TP */
    FnVCCB_MrsCalculateEndcExpectedTp(ptCi, &endcExpectedTp, &endcBcIndex);

    /* 3. LTE Expected TP */
    uint64_t lteExpectedTp = THREAD_INFO->call[ptCi->myThreadId].buf.mcoBcInfoResp.eutraExpectedThroughput;
    CONVERT_RB_TO_MHZ_UNIT(lteExpectedTp);

    if( (0 == endcExpectedTp) && (0 == lteExpectedTp) )
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] STOP MRS, ENDC and LTE Expected TPs are 0 !!\n");
        return ERROR;
    }
    VCCB_PRINT_LOG_MRS_FUNC(ptCi, "** [MRS][CalcResult] endcExpectedTp(%u)/lteExpectedTp(%lu) \n", endcExpectedTp, lteExpectedTp);

    if( 0 < endcExpectedTp )
    {
        // Find EN-DC expected TP sent by LTE to use EN-DC BC Index
        if( (VCCB_FLAG_ON == ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC_Flag) && (0 < ptExpectedTpList->count) )
        {
            const bandCombinationInfoList_type &allowedBC = ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC;
            const uint16_t allowedBcNum = MIN(allowedBC.nrofBandComb, MAX_NUM_BAND_COMB);

            VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] Check Equal Num(allowedBcList(%d)==(%d)ExpectedTpList)\n", allowedBC.nrofBandComb, ptExpectedTpList->count);

            for (uint32_t allowedBcIdx = 0; allowedBcIdx < allowedBcNum; allowedBcIdx++)
            {
                if( (endcBcIndex + 1) == allowedBC.bandCombinationInfo[allowedBcIdx].bandCombinationIndex )
                {
                    if( (allowedBcIdx < MAX_NUM_BAND_COMB) && (allowedBcIdx < ptExpectedTpList->count) )
                    {
                        receivedEndcTp = ptExpectedTpList->expectedThroughput[allowedBcIdx];
                        CONVERT_RB_TO_MHZ_UNIT(receivedEndcTp);
                        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] Find received Endc Tp[idx:%d] = %d (unit:MHz)\n",
                                allowedBC.bandCombinationInfo[allowedBcIdx].bandCombinationIndex, receivedEndcTp);
                    }

                    break;
                }
            }
        }
    }
    else
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] Invalid Calc EndcTp(0) !!\n");
    }

    // From SVR23B, NR is calculated as MHz unit
    offsetLte = pGnb->multiCarrierOperation.effectiveBandwidthOffsetLte;
    offsetEndc = pGnb->multiCarrierOperation.effectiveBandwidthOffsetEndc;

    /* Calculate LTE Expected TP with offset, EN-DC Expected TP with offset */
    if (0 != lteExpectedTp)
    {
        const uint64_t beforeLteExpectedTp = lteExpectedTp;

        if ((offsetLte + (int)lteExpectedTp) <= 0)
        {
            lteExpectedTp = 0;
        }
        else
        {
            lteExpectedTp = (uint64_t)(offsetLte + (int)lteExpectedTp);
        }
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "** [MRS][expectedTpResult] LTE(%lu)=offset(%d)+recv(%lu)\n", lteExpectedTp,
            offsetLte, beforeLteExpectedTp)
    }

    if (0 != endcExpectedTp)
    {
        uint32_t beforeCalEndcExpectedTp = endcExpectedTp;

        if ((offsetEndc + (int)beforeCalEndcExpectedTp + (int)receivedEndcTp) <= 0)
        {
            endcExpectedTp = 0;
        }
        else
        {
            endcExpectedTp = (uint32_t)(offsetEndc + (int)beforeCalEndcExpectedTp + (int)receivedEndcTp);
        }
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "** [MRS][expectedTpResult] ENDC(%u)=off(%d)+calc(%u)+recv(%u)\n", endcExpectedTp,
            offsetEndc, beforeCalEndcExpectedTp, receivedEndcTp);
    }

    if( (saExpectedTp >= endcExpectedTp) && (saExpectedTp >= lteExpectedTp) )
    {
        // Stay NR, Nothing to do
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] STAY NR, expectTp sa(%u) >= (%u/%lu)endc/lte\n", saExpectedTp, endcExpectedTp, lteExpectedTp);
        return ERROR;
    }
    else if(lteExpectedTp >= endcExpectedTp)
    {
        // Handover to EUTRA
        ptCi->mrsInfo.targetEutraInfo.ratType = MRS_RAT_EUTRA_TYPE;
        ptCi->mrsInfo.targetEutraInfo.bandCombinationIndex = static_cast<uint16_t>(THREAD_INFO->call[ptCi->myThreadId].buf.mcoBcInfoResp.eutraBandCombinationIndex);
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] HANDOVER to EUTRA, expectedTp lte[idx:%d](%lu) >= (%u/%u)endc/sa\n",
                ptCi->mrsInfo.targetEutraInfo.bandCombinationIndex, lteExpectedTp, endcExpectedTp, saExpectedTp);
    }
    else if(endcExpectedTp > lteExpectedTp)
    {
        // Handover to EN-DC
        ptCi->mrsInfo.targetEutraInfo.ratType = MRS_RAT_EUTRA_NR_TYPE;
        ptCi->mrsInfo.targetEutraInfo.bandCombinationIndex = static_cast<uint16_t>(endcBcIndex + 1);
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] HANDOVER to EN-DC, expectedTp endc[idx:%d](%u) > (%lu/%u)lte/sa\n",
               ptCi->mrsInfo.targetEutraInfo.bandCombinationIndex ,endcExpectedTp, lteExpectedTp, saExpectedTp);
    }
    else
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] When Comparing Expected TP, Unexpected Case !!\n");
        return ERROR;
    }

    return GOOD;  // LTE Handover Trigger
}

bool FnVCCB_McoCheckIfBcInfoReqStoreIsValid()
{
    AUTO_TRACE_FUNC;

    if (!(enumSamsungBcInfoRequestStoreStatus_ueNrCapaStored &
                THREAD_INFO->nonUeAsn1.buf.mcoBcInfoReqStore.storeStatus))
    {
        VCCB_PRINT_ERROR("UE-NR-Capability is expected to be stored but is not!\n");
        return true;
    }

    return false;
}

/**
 * @brief     Send SamsungBcInfoResponse with rejected
 * @param     ptCi : temporary call context
 * @return    GOOD or ERROR /int16_t
 */
int16_t FnVCCB_McoSendBcInfoRespReject(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    X2_PrivateMessage_type *ptMsg = FnVCCB_getX2PrivateMessageBuffer();

    if (GOOD != VXIL_makeX2_PrivateMessage_BcInfoResp_Rejected(ptCi, ptMsg))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VXIL_makeX2_PrivateMessage_BcInfoResp_Rejected ERROR!\n");
        return ERROR;
    }
    if (GOOD != VXIL_sendX2_PrivateMessage(ptCi, ptMsg))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VXIL_sendX2_PrivateMessage ERROR!\n");
        return ERROR;
    }

    return GOOD;
}

void FnVCCB_ClearMrsTimer(callInfo_type *ptCi, enumMrsInfoInitIndicator_type flag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    enumTimerType clearType = CANCEL_TIMER;
    if (flag == MRS_ALL_INIT_AND_TIMER_INIT)
    {
        clearType = INIT_TIMER;
    }
    VCCB_CLEAR_TIMER(&ptCi->mrsInfo.mrsMrGatheringTimer, clearType);
    VCCB_CLEAR_TIMER(&ptCi->mrsInfo.responseWaitTimer, clearType);
    VCCB_CLEAR_TIMER(&ptCi->mrsInfo.interRatMrWaitTimer, clearType);
}

static void FnVCCB_InitMrsInfoStatus(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    /* DO NOT Init rejectStatus */
    SET_MRS_STATE(ptCi, MRS_IDLE);
    ptCi->mrsInfo.mrsCheckFlag = 0;
}

static void FnVCCB_InitMrsInfoData(callInfo_type *ptCi, enumMrsInfoInitIndicator_type flag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    /* Init hoFlag */
    ptCi->mrsInfo.hoFlag = VCCB_FLAG_OFF;
    ptCi->mrsInfo.reserved = 0;

    /* Init Timer */
    FnVCCB_ClearMrsTimer(ptCi, flag);

    /* Init targetEutraInfo */
    ptCi->mrsInfo.targetEutraInfo.pci = MAX_EUTRA_PHYSICAL_CELL_ID + 1;
    ptCi->mrsInfo.targetEutraInfo.nbrIdx = MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL;
    ptCi->mrsInfo.targetEutraInfo.ratType = MRS_RAT_MAX;
    ptCi->mrsInfo.targetEutraInfo.earfcnDl = 0;
    ptCi->mrsInfo.targetEutraInfo.cgi.ci = 0;
    ptCi->mrsInfo.targetEutraInfo.cgi.plmn.longId = 0;
    ptCi->mrsInfo.targetEutraInfo.bandCombinationIndex = 0;

    memset(&ptCi->mrsInfo.eutraGatheringInfo, 0, sizeof(ptCi->mrsInfo.eutraGatheringInfo));
    FnVCCB_InitPrevMrsInfo(ptCi);
}

/**
 * @brief Initialize Multi RAT Selection Information of Call Information
 *
 * @param [in] ptCi : Call Information
 * @param [in] flag : Flag that determines how to do initialize
 */
void FnVCCB_InitMrsInfo(callInfo_type *ptCi, enumMrsInfoInitIndicator_type flag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    VCCB_PRINT_LOG_MRS_FUNC(ptCi, "FnVCCB_InitMrsInfo init flag : %d\n", flag);

    if (flag == MRS_SAME_PREV_PRARM_INIT || flag == MRS_ALL_INIT || flag == MRS_ALL_INIT_AND_TIMER_INIT)
    {
        FnVCCB_InitMrsInfoStatus(ptCi);
    }

    if (flag == MRS_DIFF_PREV_PRARM_INIT || flag == MRS_ALL_INIT || flag == MRS_ALL_INIT_AND_TIMER_INIT)
    {
        FnVCCB_InitMrsInfoData(ptCi, flag);
    }

}

void FnVCCB_InitPrevMrsInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    ptCi->prevMrsInfo.mrsState = MRS_IDLE;
    ptCi->prevMrsInfo.mrsCheckFlag = 0;
}

void FnVCCB_UpdateMrsInfo(callInfo_type *ptCi, enumUpdateMrsInfo_type updateFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (updateFlag == PREV_MRS_INFO_TO_MRS_INFO)
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] rollback MrsInfo\n");
        ptCi->mrsInfo.mrsState               = ptCi->prevMrsInfo.mrsState;
        ptCi->mrsInfo.mrsCheckFlag           = ptCi->prevMrsInfo.mrsCheckFlag;
    }
    else
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] update prevMrsInfo\n");
        ptCi->prevMrsInfo.mrsState               = ptCi->mrsInfo.mrsState;
        ptCi->prevMrsInfo.mrsCheckFlag           = ptCi->mrsInfo.mrsCheckFlag;
    }
}


/**
 * @brief     Check if the traffic measurement for IRAT PCC needs to be added
 * @param     ptCi : temporary call context
 * @return    GOOD or ERROR /int16_t
 */
int16_t FnVCCB_McoNeedToDlTrfStatusRptCfgForInterRatPccChange(
    callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    cellSelection_type cellSelection = FnVCCB_GetCellSelectionForConfig(ptCi);
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellSelection.cellNum);

    const auto &rGnb = GNBINFO[ptCi->gnbNum];
    const VccbCellInfo_type &rCell = CELLINFO[cellSelection.cellNum];
    mcoIratPccConfig_type config = FnVCCB_GetCurrentInterRatPccChangeConfig(*ptCi, rGnb, rCell);
    if ((IRatPCCState_TrafficCheckInProgress != ptCi->pccData.interRatState) || !config.dlAwareThresholdUsageForIratPccChg)
    {
        return BREAK;
    }
    else
    {
        return GOOD;
    }
}

bool FnVCCB_CheckMeasReportForMrs(const callInfo_type * const ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (VCCB_IsMeasIdInstalled(*ptCi, measReport_A4, a4Purpose_NrdcAddition, UNKNOWN_ARFCN))
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] rportType(A4), reportPurpose(NrdcAddition)\n");
        return false;
    }

    if (VCCB_IsMeasIdInstalled(*ptCi, measReport_A4, a4Purpose_NrDcResume, UNKNOWN_ARFCN))
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] rportType(A4), reportPurpose(NrDcResume) \n");
        return false;
    }
    if (VCCB_IsMeasIdInstalled(*ptCi, measReport_B1Eutra, b1Purpose_eutraHandover, UNKNOWN_ARFCN))
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] rportType(B1), reportPurpose(eutraHandover) \n");
        return false;
    }

    if (VCCB_IsMeasIdInstalled(*ptCi, measReport_B1Eutra, b1Purpose_eutraRfspHandover, UNKNOWN_ARFCN))
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] rportType(B1), reportPurpose(eutraRfspHandover) \n");
        return false;
    }

    if (VCCB_IsMeasIdInstalled(*ptCi, measReport_B2Eutra, b2Purpose_eutraHandover, UNKNOWN_ARFCN))
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] rportType(B2), reportPurpose(eutraHandover) \n");
        return false;
    }

    return true;
}

bool FnVCCB_CheckMultiRatSelection(callInfo_type *ptCi, bool IsCapaCheck)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, false);

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] NOT SA CALL \n");
        return false;
    }

    if (GNBINFO[ptCi->gnbNum].multiCarrierOperation.multiRatCarrierChange == VCCB_FLAG_OFF)
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] multiRatCarrierChange FALSE \n");
        return false;
    }

    if (ptCi->mrsInfo.rejectStatus == VCCB_FLAG_ON)
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] BcInfoRequest Rejected or T-out UE \n");
        return false;
    }

    if (ptCi->bitFlag.isInterRatHoIn)
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] InterRatHoIn UE !!!\n");
        return false;
    }

    // SVR24B FGR-CC5500_FR160
    /* Check caControlIdx */
    if (MAX_NR_CA_CONTROL_ENTRIES > ptCi->caInfo.caControlIdx)
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] ptCi->caInfo.caControlIdx(%d) match\n", ptCi->caInfo.caControlIdx);
        return false;
    }

    if (FnVCCB_McoCheckIfCpuIsOverloaded())
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] MRS not active because of CPU overload\n");
        return false;
    }

    if (FnVCCB_CheckAvailableLbSlice(ptCi))
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] MRS not active because of SliceAwareService UE\n");
        return false;
    }

    // SVR24A FGR-CC5500_FR160
    if (IS_REDCAP_UE(ptCi))
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] MRS not active because of Red Cap UE\n");
        return false;
    }

    if (IS_NRDC(ptCi))
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] NRDC call !!!\n");
        return false;
    }

    // SVR25B FGR-CC5500_FR160
    if (VLIB_IsHighPowerClassSelected(*ptCi))
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] MRS not active because is UE High Power\n");
        return false;
    }

    bool hoFlag = (IntraRatHO_cmd == ptCi->stateCmd) ? true : false;

    if (IsCapaCheck)
    {
        if (ptCi->ueContainerNR.rxFlag == FALSE || ptCi->ueContainerEUTRA.rxFlag == FALSE )
        {
            VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] ueContainerNR.rxFlag[%d]/ueContainerEUTRA.rxFlag[%d] !!!\n",
                                    ptCi->ueContainerNR.rxFlag, ptCi->ueContainerEUTRA.rxFlag);
            return false;
        }

        if (VCCM_IsIratHandoverCondition(ptCi) != GOOD)
        {
            VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] VCCM_IsIratHandoverCondition ERROR !! \n");
            return false;
        }
    }
    else
    {
        if (VCCM_CheckN26Support(ptCi) != GOOD)
        {
            VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] The UE doesn't support handover to EPC n26 interface doesn't Support!!\n");
            return false;
        }

        if (hoFlag == false)
        {
            if (VCCM_CheckUeCapaForHandoverToLTE(ptCi, ptCi->servCellNum) != GOOD)
            {
                VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] The UE doesn't support handover to EPC ueCapa doesn't Support!!\n");
                return false;
            }
        }
    }

    if (VCCM_CheckEmergencyCall(ptCi))
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] establishmentCause is emergency !!!\n");
        return false;
    }

    if (FnVCCB_IsVoNRCall(ptCi))
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] VONR In Service !!!\n");
        return false;
    }

    if (hoFlag == false)
    {
        if (FnVCCB_CheckMeasReportForMrs(ptCi) == false)
        {
            VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] FnVCCB_CheckMeasReportForMrs FALSE \n");
            return false;
        }
    }

    // SVR24A FGR-MC1023_FR21/FGR-CC5500_FR160
    cellSelection_type cellSelection = FnVCCB_GetCellSelectionForConfig(ptCi);
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(cellSelection.cellNum, false);

    if ((FnVCCB_isRfspSpecificUE(ptCi, cellSelection.cellNum) != nullptr) &&
        (CI_use != CELLINFO[cellSelection.cellNum].cellRfspSpecificMeasCtrl.supportLbFpHoUsage))
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] RfspSpecificMeasConfig is invalid !!\n");
        return false;
    }

    // SVR24B FGR-CC5500_FR160
    if (hoFlag == false)
    {
        /* Check RFSP */
        if( FnVCCB_CheckIfRfspBasedMobilityIsActiveForCall(ptCi) == GOOD )
        {
            VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] CheckIfRfspBasedMobilityIsActiveForCall GOOD\n");
            return false;
        }

        /* Check Priority based scell selection */
        if( FnVCCB_IsScellFreqPrioFlagOn(ptCi) == true )
        {
            VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] FnVCCB_IsScellFreqPrioFlagOn TRUE\n");
            return false;
        }
    }

    return true;
}

uint8_t FnVCCB_FoundEutraNbrCellForMrs(
    const callInfo_type * const ptCi, uint32_t earfcnDl, uint16_t pci, nbrEnbCellInfo_type *pNbrEnbCellInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(pNbrEnbCellInfo);
    VCCB_CHECK_VALID_CELLNUM_FALSE(ptCi->servCellNum);

    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];
    nbrEnbCellInfo_type *pNbrEnbCell;

    for (uint16_t nbrIdx = 0; nbrIdx < MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL; nbrIdx++)
    {
        if (pCell->eutraNbr[nbrIdx].status == EQUIP)
        {
            if (getNbrEnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &pNbrEnbCell) == GOOD)
            {
                if (pNbrEnbCell->earfcnDl == earfcnDl && pNbrEnbCell->pci == pci)
                {
                    *pNbrEnbCellInfo = *pNbrEnbCell;
                    return TRUE;
                }
            }
        }
    }

    return FALSE;
}

uint8_t FnVCCB_FoundNbrEnbForMrs(callInfo_type *ptCi, nbrEnbCellInfo_type *pNbrEnbCellInfo, uint16_t *foundEnbIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(pNbrEnbCellInfo);

    uint16_t gnbIdx = 0;
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if ((TRUE == FOO.VF_MultipleOperatorRanSupport) || (VCOM_getSystemType() == e_VCCB_NVGNB))
    {
        gnbIdx = ptCi->gnbNum;
    }

    for (uint16_t enbIdx = 0; enbIdx < MAX_ENB_PER_GNB_CU_CP; enbIdx++)
    {
        if (pGnb->x2Nbr[enbIdx].status == EQUIP &&
            pGnb->x2Nbr[enbIdx].x2apLinkState == CI_use &&
            pGnb->x2Nbr[enbIdx].enbId == pNbrEnbCellInfo->enbId &&
            VCOM_CheckPlmnIdentical(&pGnb->x2Nbr[enbIdx].enbPlmn, &pNbrEnbCellInfo->plmn) == TRUE)
        {
            if (VRRM_GetEutraCellInfoPldGnbIdxFromGnbId(pGnb->globalGnbId.gnbId.id, enbIdx, &gnbIdx) != ERROR)
            {
                VCCB_CHECK_E_RANGE_AND_CONTINUE(gnbIdx, MAX_GNB_PER_SYS);

                VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] gnbIdx: %d / enbIdx : %d / samsungMrsActivated : %d \n", gnbIdx,
                    enbIdx, CFG->pldEutraCellInfo[gnbIdx][enbIdx].samsungMrsActivated);

                if (CFG->pldEutraCellInfo[gnbIdx][enbIdx].samsungMrsActivated)
                {
                    *foundEnbIdx = enbIdx;
                    return TRUE;
                }
            }
        }
    }

    return FALSE;
}

void FnVCCB_CheckEutraGatheringCellForMrs(callInfo_type *ptCi, uint16_t eutraFaIdx, uint16_t *hitPerEnb,
    uint16_t *maxHittedEnbCount, uint16_t *maxHittedEnbIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(hitPerEnb);
    VALID_E_POINT_CHECK_VOID(maxHittedEnbCount);
    VALID_E_POINT_CHECK_VOID(maxHittedEnbIdx);

    VCCB_CHECK_E_RANGE_AND_VOID(eutraFaIdx, MAX_NR_OF_OBJECTEUTRA_ID_DB);

    uint16_t measPci = 0, enbIdx = 0;
    uint32_t earfcnDl = 0;
    nbrEnbCellInfo_type nbrEnbCellInfo;

    earfcnDl = ptCi->mrsInfo.eutraGatheringInfo.measureInfo[eutraFaIdx].earfcnDl;
    const uint32_t maxMeasCellCnt = UMIN(ptCi->mrsInfo.eutraGatheringInfo.measureInfo[eutraFaIdx].numTargetCell, MAX_NUM_CELL_REPORT);

    VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] faIdx : %d / earfcnDl : %d \n", eutraFaIdx, earfcnDl);

    for (uint32_t cellIdx = 0; cellIdx < maxMeasCellCnt; cellIdx++)
    {
        measPci = ptCi->mrsInfo.eutraGatheringInfo.measureInfo[eutraFaIdx].measResult[cellIdx].measuredPci;

        if (FnVCCB_FoundEutraNbrCellForMrs(ptCi, earfcnDl, measPci, &nbrEnbCellInfo))
        {
            VCCB_PRINT_LOG_MRS_FUNC(
                ptCi, "[MRS] Found Eutra Nbr Cell ( cellIdx : %d / pci : %d ) \n", cellIdx, measPci);

            ptCi->mrsInfo.eutraGatheringInfo.measureInfo[eutraFaIdx].measResult[cellIdx].cgiExist = TRUE;
            ptCi->mrsInfo.eutraGatheringInfo.measureInfo[eutraFaIdx].measResult[cellIdx].cgi.plmn = nbrEnbCellInfo.plmn;
            ptCi->mrsInfo.eutraGatheringInfo.measureInfo[eutraFaIdx].measResult[cellIdx].cgi.ci =
                VCCB_GET_ECGI(nbrEnbCellInfo.enbId, nbrEnbCellInfo.cellId);

            if (FnVCCB_FoundNbrEnbForMrs(ptCi, &nbrEnbCellInfo, &enbIdx) == TRUE)
            {
                VCCB_CHECK_E_RANGE_AND_CONTINUE(enbIdx, MAX_ENB_PER_GNB_CU_CP);
                VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] Found Eutra Nbr eNB (Idx : %d) \n", enbIdx);

                hitPerEnb[enbIdx]++;
                if (*maxHittedEnbCount < hitPerEnb[enbIdx])
                {
                    *maxHittedEnbCount = hitPerEnb[enbIdx];
                    *maxHittedEnbIdx = enbIdx;
                }
                else if ((enbIdx < *maxHittedEnbIdx) && (*maxHittedEnbCount == hitPerEnb[enbIdx]))
                {
                    *maxHittedEnbIdx = enbIdx;
                }
            }
            else
            {
                VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] Not Found Eutra Nbr eNB \n");
            }
        }
        else
        {
            VCCB_PRINT_LOG_MRS_FUNC(
                ptCi, "[MRS] Not Found Eutra Nbr Cell ( cellIdx : %d / pci : %d ) \n", cellIdx, measPci);
        }
    }
}

uint8_t FnVCCB_DecisionMeNBForMrs(callInfo_type *ptCi, uint16_t *targetEnbIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(targetEnbIdx);

    uint16_t hitPerEnb[MAX_ENB_PER_GNB_CU_CP] = { 0, };
    uint16_t maxHittedEnbCount = 0;
    uint16_t maxHittedEnbIdx = MAX_ENB_PER_GNB_CU_CP;

    for (uint16_t eutraFaIdx = 0; eutraFaIdx < MAX_NR_OF_OBJECTEUTRA_ID_DB; eutraFaIdx++)
    {
        if (ptCi->mrsInfo.eutraGatheringInfo.measureInfo[eutraFaIdx].usage)
        {
            FnVCCB_CheckEutraGatheringCellForMrs(ptCi, eutraFaIdx, hitPerEnb, &maxHittedEnbCount, &maxHittedEnbIdx);
        }
    }

    if (maxHittedEnbIdx == MAX_ENB_PER_GNB_CU_CP)
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] Not Found eNB \n");
        return FALSE;
    }

    *targetEnbIdx = maxHittedEnbIdx;
    VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] Decision eNB (targetEnbIdx : %d) \n", maxHittedEnbIdx);
    return TRUE;
}

X2_PrivateMessage_type *FnVCCB_GetX2PrivateMessageBufferPerThread(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_NULLPTR(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    return &THREAD_INFO->call[ptCi->myThreadId].buf.tx.x2ap.privateMessage;
}

int16_t FnVCCB_MrsSendSamsungBcInfoRequest(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    X2_PrivateMessage_type *ptMsg = FnVCCB_GetX2PrivateMessageBufferPerThread(ptCi);

    if (VXIL_makeX2_PrivateMessage_BcInfoRequest(ptCi, ptMsg) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[MRS] VXIL_makeX2_PrivateMessage_BcInfoRequest ERROR !!!\n");
        return ERROR;
    }

    if (VXIL_sendX2_PrivateMessage(ptCi, ptMsg) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[MRS] VXIL_sendX2_PrivateMessage ERROR !!!\n");
        return ERROR;
    }

    return GOOD;
}

int16_t FnVCCB_TriggerMultiRatSelection(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint16_t targetEnbIdx = 0, backPara = 0;

    if (FnVCCB_CheckMultiRatSelection(ptCi, true) == false)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[MRS] FnVCCB_checkMultiRatSelection FALSE !!!\n");
        return ERROR;
    }

    if (FnVCCB_DecisionMeNBForMrs(ptCi, &targetEnbIdx) == FALSE)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[MRS] FnVCCB_DecisionMeNBForMrs FALSE !!!\n");
        return ERROR;
    }

    backPara = ptCi->endPointInfo.x2Idx;
    ptCi->endPointInfo.x2Idx = targetEnbIdx;

    if (FnVCCB_MrsSendSamsungBcInfoRequest(ptCi) != GOOD)
    {
        ptCi->endPointInfo.x2Idx = backPara;
        VCCB_PRINT_CALL_ERROR(ptCi, "[MRS] FnVCCB_MrsSendSamsungBcInfoRequest ERROR !!!\n");
        return ERROR;
    }

    VLIB_AttachTimer(&ptCi->mrsInfo.responseWaitTimer, ptCi, timX2_BcInformationResponse_id);
    ptCi->endPointInfo.x2Idx = backPara;

    if (ptCi->mrsInfo.responseWaitTimer.id <= 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[MRS] Invalid Timer timX2_BcInformationResponse_id !!!\n");
        return ERROR;
    }

    SET_MRS_STATE(ptCi, MRS_WAIT_BCINFO_RSP);

    return GOOD;
}

int16_t FnVCCB_NeedToDlTrfStatusRptCfgforMrsAddPerDRB(callInfo_type *ptCi, callDRBInfo_type *pDi, bool isSend, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDi);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);

    if (isSend)
    {
        if (pDi->drbStatus != S_Setup && pDi->drbStatus != S_Modify)
        {
            VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] drbStatus is neither S_Setup nor S_Modify [ %s ] \n", __FUNCTION__);
            return BREAK;
        }
    }

    return GOOD;
}

void FnVCCB_SetMultiRatSelectionInitState(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (pGnb->multiCarrierOperation.multiRatCarrierChange == VCCB_FLAG_OFF)
    {
        SET_MRS_STATE(ptCi, MRS_IDLE);
        return;
    }

    if (ptCi->mrsInfo.mrsState != MRS_IDLE)
    {
        return;
    }

    if (pGnb->multiCarrierOperation.mrsTrafficCheckFlag == VCCB_FLAG_OFF)
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] Set mrsMrGatheringMeas State !!! %s\n", __FUNCTION__);
        SET_MRS_STATE(ptCi, MRS_GATHERING_MEAS);
    }
    else
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] Set mrsTrafficMeas State !!! %s\n", __FUNCTION__);
        SET_MRS_STATE(ptCi, MRS_TRAFFIC_MEAS);
    }
}

/**
 * @brief     Check if current overload status exceeds the MCO Overload threshold
 * @return    true or false // BOOL
 */
bool FnVCCB_McoCheckIfCpuIsOverloaded()
{
    AUTO_TRACE_FUNC;

    const VccbCfgInfo_type *const pCfg = CFG;

    return
        ((VCCB_FLAG_ON == static_cast<enumVccbFlag>(pCfg->overloadControl.ueSigCpuOverloadControl.ueSigCpuOverloadAction)) &&
         (CpuOverloadCtrl_noControl != static_cast<enumCpuOverloadCtrlLevel_type>(pCfg->overloadControl.ueSigCpuOverloadControl.mcoOverloadThreshold)) &&
         (indeterminate != static_cast<AlarmPerceivedSeverity>(pCfg->overloadStatus)) &&
         (pCfg->overloadStatus <= pCfg->overloadControl.ueSigCpuOverloadControl.mcoOverloadThreshold));
}

/**
 * @brief Check if SCC Change is not triggered by conditions
 *        In case Not Trigger, sccData Initialization is called in the called code
 * @param ptCi : the pointer variable of callInfo_type
 * @return true  Not Trigger Condition is met, SCC Change is not triggered
 * @return false Not Trigger Condition is not met
 */
bool FnVCCB_CheckNotTriggerConditionForSCC(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, true);

    if (FnVCCB_McoCheckIfCpuIsOverloaded())
    {
        VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] SCC not active because of CPU overload\n");
        return true;
    }

    // SVR24A FGR-CC5500_FR21
    if (IS_REDCAP_UE(ptCi))
    {
        VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] SCC not active because of Red Cap UE\n");
        return true;
    }

    if (FnVCCB_IsScellFreqPrioFlagOn(ptCi))
    {
        VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] SCC not active because of scell-frequency-priority-profile\n");
        return true;
    }

    if (MAX_NR_CA_CONTROL_ENTRIES > ptCi->caInfo.caControlIdx)
    {
        VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] SCC not active because CA Control(%d) is applied!\n", ptCi->caInfo.caControlIdx);
        return true;
    }

    return false;
}

/**
 * @brief Check several conditions to see if the SCC Change can be used
 *
 * @param ptCi      pointer variable of callInfo_type
 * @return true     Scc Change is available
 * @return false    Scc Change is not available
 */
bool FnVCCB_CheckAvailableForSccChange(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, false);

    const VccbGnbInfo_type &rGnb = GNBINFO[ptCi->gnbNum];

    if (!rGnb.multiCarrierOperation.sccChange)
    {
        VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] SCC Change feature off\n");
        return false;
    }

    if (CaOperation_Mode3 != ptCi->caInfo.mode)
    {
        VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] Invalid CA Mode(%d)\n", ptCi->caInfo.mode);
        return false;
    }

    if (E_CALLTYPE_SA != ptCi->callType)
    {
        VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] Not SA Call(%d)\n", ptCi->callType);
        return false;
    }

    if (IS_NRDC_SN(ptCi))
    {
        VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] NR-DC, SN Case\n");
        return false;
    }

    if ((IS_NRDC_MN(ptCi)) && (IS_NOT_MRDC_SCG_RELEASE_ONGOING(ptCi)))
    {
        VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] NR-DC, MN Case\n");
        return false;
    }

    // SVR25B FGR-CC5500_FR21
    if (VLIB_IsHighPowerClassSelected(*ptCi))
    {
        VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] UE High Power\n");
        return false;
    }

    if (ptCi->caInfo.releaseCaA4ForVoNROn == TRUE)
    {
        VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] VoNR Setup (releaseCaA4ForVoNR is TRUE)\n");
        return false;
    }

    return true;
}

/**
 * @brief   Calculate MAX Total SCell BandWidth for SCC Change
 */
void FnVCCB_CalculateMaxBwForSccChange(callInfo_type *ptCi, const uint8_t newNrCapaReceiveFlag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // 1. Load Cell and Band Information for Calculating Total MAX BandWidth, using FnVCCB_GetCellSelectionForConfig Function
    cellSelection_type cellSelection = FnVCCB_GetCellSelectionForConfig(ptCi);

    // 3. if sccData.totalMaxBw is not equal to UNKNOWN_BANDWIDTH,
    if (UNKNOWN_BANDWIDTH != ptCi->sccData.totalMaxBw)
    {
        //   3-1. Current Cell and Band Information to calculate MAX Total MAX BW
        if ((cellSelection.cellNum == ptCi->sccData.calculatedCellNum) &&
            (cellSelection.bandNr == ptCi->sccData.calculatedBandNr))
        {
            if (newNrCapaReceiveFlag == TRUE)
            {
                VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] Receive New NR Capa, so Re-Calculate Total MAX Bandwidth\n");
            }
            else
            {
                // Already Calculated Total MAX BW, No Need to calculate
                VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC][%u][%u] Already Calculated Total MAX BandWidth(%u) for SCC Change !\n",
                                       ptCi->sccData.calculatedCellNum, ptCi->sccData.calculatedBandNr, ptCi->sccData.totalMaxBw);
                return;
            }
        }
    }

    // 4. Set Variables below
    //     This indicates the Process that calculate MAX BandWidth for SCC Change
    {
        ptCi->sccData.totalMaxBw = 0;
        ptCi->sccData.calculatedBandNr = cellSelection.bandNr;
        ptCi->sccData.calculatedCellNum = cellSelection.cellNum;
        std::fill_n(ptCi->sccData.scellAltBandSsbArfcn, MAX_MCO_MFBI_CELLS, UNKNOWN_ARFCN);
        std::fill_n(ptCi->sccData.scellAltBand, MAX_MCO_MFBI_CELLS, BAND_NOT_FOUND);
    }

    // 5. FnVCCB_McoSelectScellsForMaxBW
    bool bestSCellsMap[MAX_SCELL_PER_CALL];
    uint16_t sCellAltBand[MAX_MCO_MFBI_CELLS] = {BAND_NOT_FOUND, BAND_NOT_FOUND, BAND_NOT_FOUND};
    uint32_t sCellIdxWithAltBand[MAX_MCO_MFBI_CELLS] = {MAX_SCELL_PER_CALL, MAX_SCELL_PER_CALL, MAX_SCELL_PER_CALL};
    int16_t status = FnVCCB_McoSelectScellsForMaxBW(ptCi, bestSCellsMap, sCellAltBand, sCellIdxWithAltBand, cellSelection, false);

    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[SCC] ERROR while calling FnVCCB_McoSelectScellsForMaxBW in %s !\n", __FUNCTION__);
        return;
    }

    // 6. Current SCell added or state SCELL_STATE_MRREL,
    //   - Calculate BW about SCell mapping bestSCellsMap[]
    //     Then, BW is BW about simply specific Cell. not considering PRB Usage, DL Mimo Layer, etc
    uint32_t totalMaxBw = 0;
    uint8_t numAddScells = 0;
    mcoSccCcInfo_s scellCcInfo;
    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (uint16_t sCellIdx = 0; sCellIdx < MAX_SCELL_PER_CALL; sCellIdx++)
    {
        if ((SCELL_STATE_ADDED == scells[sCellIdx].state) ||
            (SCELL_STATE_MRREL == scells[sCellIdx].state) ||
            (SCELL_STATE_CCLIMITREL == scells[sCellIdx].state))
        {
            if (bestSCellsMap[sCellIdx])
            {
                const scellInfo_type &rSCell = scells[sCellIdx];
                scellCcInfo.frequencyBand = rSCell.bandNr;
                scellCcInfo.sCellIndex = sCellIdx;
                scellCcInfo.nrArfcnDl = rSCell.nrArfcn;
                scellCcInfo.nrScsDl = rSCell.nrScsDl;
                scellCcInfo.nRbDl = rSCell.nrbDl;
                scellCcInfo.altBand = BAND_NOT_FOUND;

                FnVCCB_McoFillBandwidth(rSCell, scellCcInfo);

                totalMaxBw += scellCcInfo.mcoBwDl;

                VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC][%d] Calculate totalMaxBw(%u(+%u))\n",
                    ++numAddScells, totalMaxBw, scellCcInfo.mcoBwDl);
                VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC][%d]  +SCell band(%d)/nrArfcn(%d)/nrScsDl(%d)/nrbDl(%d)/mcoBwDl(%d)\n",
                    numAddScells, rSCell.bandNr, rSCell.nrArfcn, rSCell.nrScsDl, rSCell.nrbDl, scellCcInfo.mcoBwDl);
            }
            else
            {
                VCCB_PRINT_CALL_ERROR(ptCi,"[SCC] Scell marked by best BW combination but will not be used\n");
            }
        }
    }

    // 7. Best BC
    if ((MAX_SCELL_PER_CALL > sCellIdxWithAltBand[0]) && (BAND_NOT_FOUND != sCellAltBand[0]))
    {
        VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] Select Best BC, Change SCell\n");
        for (uint8_t scellAltBandIdx = 0; scellAltBandIdx < MAX_MCO_MFBI_CELLS; ++scellAltBandIdx)
        {
            if ((MAX_SCELL_PER_CALL > sCellIdxWithAltBand[scellAltBandIdx]) && (BAND_NOT_FOUND != sCellAltBand[scellAltBandIdx]))
            {
                VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] altBandIdx[%u]: scellIdx[%u]:pci(%u)/band(%u) to alternate band(%u)\n",
                    scellAltBandIdx,
                    sCellIdxWithAltBand[scellAltBandIdx],
                    scells[sCellIdxWithAltBand[scellAltBandIdx]].pci,
                    scells[sCellIdxWithAltBand[scellAltBandIdx]].bandNr,
                    sCellAltBand[scellAltBandIdx]);

                ptCi->sccData.scellAltBandSsbArfcn[scellAltBandIdx] = scells[sCellIdxWithAltBand[scellAltBandIdx]].ssbArfcn;
                ptCi->sccData.scellAltBand[scellAltBandIdx] = sCellAltBand[scellAltBandIdx];
            }
        }
    }

    // 8. set Total BW calculated SCells to sccData.totalMaxBw
    VCCB_PRINT_CALL_COMMENT(ptCi,"[SCC] Change sccData TotalMaxBw(%u->%u)\n", ptCi->sccData.totalMaxBw, totalMaxBw);
    ptCi->sccData.totalMaxBw = totalMaxBw;
}

/**
 * @brief Check if the SCC Change process is required
 *
 * @param ptCi : pointer to callInfo_type
 * @return true  Current BW is MAX BW, therefore MR Gathering procedure for SCC Change is not required
 * @return false Current BW is not MAX BW, need to proceed MR Gathering for SCC Change
 */
bool FnVCCB_CheckCurrentSCellMaxBwForSccChange(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, true);

    // 1. if sccData.totalMaxBw is UNKNOWN_BANDWIDTH or 0, the status is invalid
    if ((UNKNOWN_BANDWIDTH == ptCi->sccData.totalMaxBw) ||
        (0 == ptCi->sccData.totalMaxBw))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,"[SCC] totalMaxBw(%u) is invalid in %s\n", ptCi->sccData.totalMaxBw, __FUNCTION__);
        return true;
    }

    // 2. calculate the Total MAX BW for the scell in the Addition state
    caScellCcInfo_type scellCcInfo;
    uint32_t currentTotalMaxBw = 0;
    uint8_t numAddScells = 0;

    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (uint16_t sCellIdx = 0; sCellIdx < MAX_SCELL_PER_CALL; sCellIdx++)
    {
        const scellInfo_type &rSCell = scells[sCellIdx];

        if ( (SCELL_STATE_ADDED == rSCell.state) && (SCELL_ACTION_KEEP == rSCell.action) )
        {
            scellCcInfo.frequencyBand = rSCell.bandNr;

            FnVCCB_McoFillBandwidth(rSCell, scellCcInfo);

            currentTotalMaxBw += scellCcInfo.mcoBwDl;

            VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC][%u] Calculate totalMaxBw(%u(+%u))\n", ++numAddScells, currentTotalMaxBw, scellCcInfo.mcoBwDl);
            VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC][%u]  +SCell band(%u)/ssbArfcn(%u)/nrScsDl(%u)/nrbDl(%u)/mcoBwDl(%u)\n",
                numAddScells, rSCell.bandNr, rSCell.ssbArfcn, rSCell.nrScsDl, rSCell.nrbDl, scellCcInfo.mcoBwDl);
        }
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "[SCC] Calculated Result : numAddScell(%u)/currentTotalMaxBw(%u) !!\n", numAddScells, currentTotalMaxBw);

    // 2-1. if (current calculated Total MAX BW >= sccData.totalMaxBw), return true.
    // 2-2. if (current calculated Total MAX BW < sccData.totalMaxBw), return false.
    if (currentTotalMaxBw >= ptCi->sccData.totalMaxBw)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[SCC] No SCC Change is required ! AddSCells((%u)>=(%u))sccData\n", currentTotalMaxBw, ptCi->sccData.totalMaxBw);
        return true;
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "[SCC] SCC Change is required ! AddSCells((%u)<(%u))sccData\n", currentTotalMaxBw, ptCi->sccData.totalMaxBw);
    return false;
}

/**
 * @brief MCO LB FR90: Select best SpCell Candidate by checking CC list against all BCs.
 *
 * @param[in]   ptCi                : Pointer to call context.
 * @param[in]   ueSupBandCombList   : UE supported Band Combination List.
 * @param[in]   ccInfoVecPerBand    : Component carriers list eligible for CA, to be checked for max BW against all BCs.
 * @param[in]   bandNr              : SpCell's band.
 * @param[in]   ccListForSort       : Candidate SpCell list to be checked.
 * @param[out]  lbResultOut         : Result for best candidate.
 **/
void FnVCCB_McoLbCheckSpCellCandidatesAgainstAllBc(callInfo_type *ptCi, const bandCombinationList_type &ueSupBandCombList,
    const mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBand, const uint16_t bandNr,
    const candidateCellListForSort_type &ccListForSort, mcoLbResult_s &lbResultOut)
{
    AUTO_TRACE_FUNC;

    lbResultOut.reset();

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ccListForSort.nrofCells, MAX_NUM_CANDIDATE_CELL_FOR_PSCELL);

    mcoBand2mcoCcInfoVecMap_type::const_iterator ccInfoVecIt = ccInfoVecPerBand.find(bandNr);
    if (ccInfoVecPerBand.end() == ccInfoVecIt)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB][BCSel] No CC on band-NR(%u)\n", bandNr);
        return;
    }

    mcoBand2BcBandResultsCache_s mcoBand2BcBandResultsCache(ptCi);
    McoBCIdxArray_type bcBwMaxIdxDq;
    uint32_t bcBwDlMax = 0;

    const McoAlgoFlags algoFlags = { .noMimo = true,
                                     .checkUlBw = true,
                                     .ulOnlyMode = false,
                                     .mfbiCheck = false,
                                     .initialFmPcc = false,
                                     .checkCarrierOnly = false,
                                     .useSe = false,
                                     .useMultiChBw = false };
    FnVCCB_McoCheckAllBcAgainstCcNr(ptCi, ueSupBandCombList, bandNr, BAND_NOT_FOUND, ccInfoVecPerBand, algoFlags,
            mcoBand2BcBandResultsCache, bcBwMaxIdxDq, bcBwDlMax);

    mcoLbResult_s lbResult;
    const mcoCcInfoVec_type &ccInfoVec = ccInfoVecIt->second.ccInfoVec;
    for (const uint32_t selectedBcIdx : bcBwMaxIdxDq)
    {
        mcoBand2numContCcDq_type mcoBand2numContCcDq;
        bool ulPcellBand = false;

        FnVCCB_McoRetrieveBcDataDlUl(
            ueSupBandCombList.bandCombination[selectedBcIdx], ci_nr, bandNr, mcoBand2numContCcDq, ulPcellBand);
        if (false == ulPcellBand)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB][BCSel] band-NR(%u) BcIdx(%u): No UL!\n", bandNr, selectedBcIdx);
            continue;
        }

        const mcoBcBandInfoDq_type &bcBandInfoDq = mcoBand2numContCcDq[bandNr];
        const std::size_t bcBandInfoDqSize = bcBandInfoDq.size();
        mcoCheckBcResult_s bcBandPermResult;
        const mcoCheckBcBandResultsCache_s *pBcBandCache = mcoBand2BcBandResultsCache.getForBand(ci_nr, bandNr);
        mcoCheckBcBandResultsCache_s::key_type bcBandKey =
            mcoCheckBcBandResultsCache_s::makeBcBandKeyDlUl(bcBandInfoDq);
        if ((nullptr == pBcBandCache) || (true != pBcBandCache->getResult(bcBandKey, bcBandPermResult)))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB][BCSel] band-NR(%u) BcIdx(%u): No cache\n", bandNr, selectedBcIdx);
            continue;
        }

#define GET_TAB_ELEMENT_FIELD(__tab, __size, __idx, __field) (((__idx) >= (__size)) ? 0 : (__tab)[(__idx)].__field)

        VCCB_PRINT_CALL_COMMENT(ptCi,
            "[MCO LB][BCSel] band(%u) BcIdx(%u) ccBmsk(0x%lx) maxUlBmsk(0x%lx) ([%u/%u][%u/%u][%u/%u][%u/%u]%s)\n",
            bandNr, selectedBcIdx, bcBandPermResult.ccIdxBitmask, bcBandPermResult.maxUlBwPcellIdxBitmask,
            GET_TAB_ELEMENT_FIELD(bcBandInfoDq, bcBandInfoDqSize, 0, numContiguousCcDL),
            GET_TAB_ELEMENT_FIELD(bcBandInfoDq, bcBandInfoDqSize, 0, numContiguousCcUL),
            GET_TAB_ELEMENT_FIELD(bcBandInfoDq, bcBandInfoDqSize, 1, numContiguousCcDL),
            GET_TAB_ELEMENT_FIELD(bcBandInfoDq, bcBandInfoDqSize, 1, numContiguousCcUL),
            GET_TAB_ELEMENT_FIELD(bcBandInfoDq, bcBandInfoDqSize, 2, numContiguousCcDL),
            GET_TAB_ELEMENT_FIELD(bcBandInfoDq, bcBandInfoDqSize, 2, numContiguousCcUL),
            GET_TAB_ELEMENT_FIELD(bcBandInfoDq, bcBandInfoDqSize, 3, numContiguousCcDL),
            GET_TAB_ELEMENT_FIELD(bcBandInfoDq, bcBandInfoDqSize, 3, numContiguousCcUL),
            (3 < bcBandInfoDqSize) ? "++" : "");

#undef GET_TAB_ELEMENT_FIELD

        for (uint16_t ccIdx = 0; ccIdx < ccInfoVec.size(); ccIdx++)
        {
            const mcoCcInfo_s &rCCInfo = ccInfoVec[ccIdx];

            if (false == rCCInfo.pcellFlag)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB][BCSel] ccIdx(%u) - not a candidate!\n", ccIdx);
                continue;
            }

            VCCB_CHECK_E_RANGE_AND_CONTINUE(rCCInfo.userValue, ccListForSort.nrofCells);
            const candidateCellForSort_type &rCandidateCell = ccListForSort.candidateCell[rCCInfo.userValue];

            if (0 == (bcBandPermResult.maxUlBwPcellIdxBitmask & (1ULL << ccIdx)))
            {
                VCCB_PRINT_CALL_COMMENT(ptCi,
                    "[MCO LB][BCSel] ccIdx(%u) CandIdx(%u) PCI(%u) cellNum(%u) - NOT max UL BW in BcIdx(%u)!\n",
                    ccIdx, rCCInfo.userValue, rCandidateCell.physCellId, rCandidateCell.cellNum, selectedBcIdx);
                    continue;
            }

            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[MCO LB][BCSel] ccIdx(%u) CandIdx(%u) PCI(%u) cellNum(%u) - BW (%u/%u) ueCount(%u) in BcIdx(%u)\n",
                ccIdx, rCCInfo.userValue, rCandidateCell.physCellId, rCandidateCell.cellNum, bcBandPermResult.mcoBwDl,
                bcBandPermResult.mcoBwUl, rCandidateCell.ueCount, selectedBcIdx);

            lbResult.setIfBetter(bcBandPermResult.mcoBwDl, bcBandPermResult.mcoBwUl, static_cast<uint8_t>(rCCInfo.userValue));
        }
    }

    if (lbResult._candidateIdx >= ccListForSort.nrofCells)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB][BCSel] Could not find any common candidate for band-NR(%u)!\n", bandNr);
        return;
    }

    const candidateCellForSort_type &rCandidateCell = ccListForSort.candidateCell[lbResult._candidateIdx];
    VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB][BCSel] Proposed candidate: idx(%u) BW(%u/%u) ueCount(%u) cellNum(%u) PCI(%u)\n",
        lbResult._candidateIdx, lbResult._bwDl, lbResult._bwUl, rCandidateCell.ueCount, rCandidateCell.cellNum, rCandidateCell.physCellId);

    lbResultOut = lbResult;

    return;
}

/**
 * @brief MCO LB FR90: Set new result if it is better than current.
 **/
void mcoLbResult_s::setIfBetter(const uint32_t bwDlIn, const uint32_t bwUlIn, const uint8_t candidateIdxIn)
{
    AUTO_TRACE_FUNC;

    // check if BW is better
    if ((_bwDl < bwDlIn) || ((_bwDl == bwDlIn) && (_bwUl < bwUlIn)))
    {
        _bwDl = bwDlIn;
        _bwUl = bwUlIn;
        _candidateIdx = candidateIdxIn;
        _candidateBitmask = static_cast<uint8_t>(1u << candidateIdxIn);
    }
    // check if BW is equal
    else if ((_bwDl == bwDlIn) && (_bwUl == bwUlIn))
    {
        // lower candidate index indicates lower ueCount ==> better candidate
        if (_candidateIdx > candidateIdxIn)
        {
            _candidateIdx = candidateIdxIn;
        }
        _candidateBitmask |= static_cast<uint8_t>(1u << candidateIdxIn);
    }
}

/**
 * @brief Initialize Data for SCC Change
 *
 * @param ptCi Pointer to call information
 */
void FnVCCB_InitSccBwData(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    std::fill_n(ptCi->sccData.scellAltBandSsbArfcn, MAX_MCO_MFBI_CELLS, UNKNOWN_ARFCN);
    std::fill_n(ptCi->sccData.scellAltBand, MAX_MCO_MFBI_CELLS, BAND_NOT_FOUND);
    ptCi->sccData.totalMaxBw = UNKNOWN_BANDWIDTH;
    ptCi->sccData.calculatedBandNr = BAND_NOT_FOUND;
    ptCi->sccData.calculatedCellNum = MAX_CELL_NUM_VCCB;
}

void FnVCCB_InitSccTimer(callInfo_type *ptCi, enumTimerType clearType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    VCCB_CLEAR_TIMER(&ptCi->sccData.sccGatheringTimer, clearType);
    VCCB_CLEAR_TIMER(&ptCi->sccData.sccMeasReactTimer, clearType);
}

void FnVCCB_UpdateSccData(callInfo_type *ptCi, bool backup)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (backup)
    {
        VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] FnVCCB_InitPrevSccData backup success \n");
        ptCi->prevSccData.state = ptCi->sccData.state;
        ptCi->prevSccData.a4MrSetAndReceived = ptCi->sccData.a4MrSetAndReceived;
        ptCi->prevSccData.a2MrReceived = ptCi->sccData.a2MrReceived;
        ptCi->prevSccData.totalMaxBw = ptCi->sccData.totalMaxBw;
        
        for(uint8_t idx = 0; idx < MAX_MCO_MFBI_CELLS; idx++)
        {
            ptCi->prevSccData.scellAltBand[idx] = ptCi->sccData.scellAltBand[idx];
            ptCi->prevSccData.scellAltBandSsbArfcn[idx] = ptCi->sccData.scellAltBandSsbArfcn[idx];
        }
    }
    else
    {
        VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] FnVCCB_InitPrevSccData rollback success \n");
        ptCi->sccData.state = (ptCi->prevSccData.state & e_BitMask_4bit);
        ptCi->sccData.a4MrSetAndReceived = ptCi->prevSccData.a4MrSetAndReceived;
        ptCi->sccData.a2MrReceived = ptCi->prevSccData.a2MrReceived;
        ptCi->sccData.totalMaxBw = ptCi->prevSccData.totalMaxBw;
        
        for(uint8_t idx = 0; idx < MAX_MCO_MFBI_CELLS; idx++)
        {
            ptCi->sccData.scellAltBand[idx] = ptCi->prevSccData.scellAltBand[idx];
            ptCi->sccData.scellAltBandSsbArfcn[idx] = ptCi->prevSccData.scellAltBandSsbArfcn[idx];
        }
    }
}

void FnVCCB_InitPrevSccData(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    ptCi->prevSccData.state = SCC_NOT_SET;
    ptCi->prevSccData.a4MrSetAndReceived = 0;
    ptCi->prevSccData.a2MrReceived = 0;
}

void FnVCCB_InitSccStateMrFlag(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    ptCi->sccData.state = SCC_NOT_SET;
    ptCi->sccData.a4MrSetAndReceived = 0;
    ptCi->sccData.a2MrReceived = 0;
}

void FnVCCB_InitSccFlagCellMeasured(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for(uint16_t scellIdx = 0; scellIdx < MAX_SCELL_PER_CALL; scellIdx++)
    {
        scells[scellIdx].sccFlag_cellMeasured = FALSE;
    }

}

void FnVCCB_InitSccData(callInfo_type *ptCi, enumSccDataInitIndicator_type flag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    enumTimerType clearType = CANCEL_TIMER;

    VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] InitSccData flag(%d) \n", flag);

    if (flag == SCC_ALL_INIT || flag == SCC_ALL_INIT_AND_TIMER_INIT)
    {
        if (flag == SCC_ALL_INIT_AND_TIMER_INIT)
        {
            clearType = INIT_TIMER;
        }
        FnVCCB_InitSccStateMrFlag(ptCi);
        FnVCCB_InitSccBwData(ptCi);
        FnVCCB_InitSccTimer(ptCi, clearType);
        FnVCCB_InitPrevSccData(ptCi);
    }
    else if (flag == SCC_HO_PREP_INIT)
    {
        FnVCCB_UpdateSccData(ptCi, true);
        FnVCCB_InitSccStateMrFlag(ptCi);
    }
    else if (flag == SCC_HO_EXEC_INIT)
    {
        FnVCCB_InitSccTimer(ptCi, clearType);
    }
    else if (flag == SCC_MR_AND_TIMER_INIT)
    {
        FnVCCB_InitSccStateMrFlag(ptCi);
        FnVCCB_InitSccTimer(ptCi, clearType);
        FnVCCB_InitPrevSccData(ptCi);
    }
}

/**
 * @brief       Fill Slice Available Capacity Dl for PCC SLB
 * @param[in]   ptCi : callInfo
 * @param[in]   spCellNum : primary cell num
 * @param[in]   cgi  : cell cgi
 * @param[out]  ptCellInfo : mcoBwDl field filled with Slice Available Capacity Dl
 */
void FnVCCB_FillSliceAvailableCapacityDl(callInfo_type *ptCi, CellNum_type spCellNum, const cgi_type &cgi, caCellInfo_type *ptCellInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptCellInfo);
    VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);

    const VccbGnbInfo_type &pGnb = GNBINFO[ptCi->gnbNum];

    int32_t capacityDl {0};
    const uint16_t cellNum = VLIB_GetCellNumBasedOnCgi(ptCi, cgi, pGnb.globalGnbId.gnbId.idLength);
    if (MAX_CELL_NUM_VCCB > cellNum)
    {
        capacityDl = FnVCCB_GetSliceCapacityForIntraCell(ptCi, cellNum);
        if (-1 == capacityDl)
        {
            capacityDl = 0;
        }

        ptCellInfo->mcoBwDl = static_cast<uint16_t>(capacityDl);
        return;
    }

    // else inter gNB
    VCCB_CHECK_VALID_CELLNUM_VOID(spCellNum);
    VccbCellInfo_type *const pSpCell = &CELLINFO[spCellNum];
    const uint16_t nbrCellIdx = VLIB_GetNbrIdxBasedOnCgi(pSpCell, cgi);
    if (MAX_NBR_PER_CELL > nbrCellIdx)
    {
        // Inter-gNB FR1 SCells are treated as 0 capacity according to FR42
        if (!IS_FR2(ptCellInfo->ssbArfcn))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[SLB] SpCellNum(%d) nbrIdx(%d) ci(%lu) not-FR2, capacity treated as invalid (0)!\n",
                    spCellNum, nbrCellIdx, ptCellInfo->cgi.ci);
            capacityDl = 0;
        }
        else
        {
            capacityDl = FnVCCB_GetSliceCapacityForInterCell(ptCi, cgi, ptCellInfo->gnbIdLength, spCellNum);
            if (-1 == capacityDl)
            {
                capacityDl = 0;
            }
        }
        ptCellInfo->mcoBwDl = static_cast<uint16_t>(capacityDl);
    }
}

void FnVCCB_LibStatMRSEvent(callInfo_type *ptCi, int mType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VOID(mType, 0, STAT_MULTI_RAT_SELECTION_END - 1);

    MACRO_STAT_PMCC(STAT_MULTI_RAT_SELECTION, MRS_Att, ptCi, 0, 0, 0, 0, 0);
    MACRO_STAT_PMCC(STAT_MULTI_RAT_SELECTION, mType, ptCi, 0, 0, 0, 0, 0);

    return;
}

void McoSlbOpCounts::clearOpCounts()
{
    AUTO_TRACE_FUNC;
    m_opCntMrs = 0;
    m_opCntPccChange = 0;
    m_opCntSccChange = 0;
    m_opCntSlb = 0;
}

bool McoSlbOpCounts::checkIfOpCountAboveThresholdAndIncrement(uint32_t maxCnt, std::atomic<uint32_t>& currentCnt)
{
    AUTO_TRACE_FUNC;
    // If the max op count is set to 0, we don't need to check the threshold or increment
    if (0 == maxCnt)
    {
        return false;
    }

    // Store current op count and atomically increment
    // Comparison should be made to value before increment
    uint32_t currentValue = currentCnt.fetch_add(1, std::memory_order_relaxed);
    if (currentValue < maxCnt)
    {
        return false;
    }
    else
    {
        // Guard against overflow, because we're always incrementing
        if (currentValue > maxCnt * 2)
        {
            currentCnt = maxCnt;
        }
        return true;
    }
}

bool McoSlbOpCounts::checkIfMrsOpCountAboveThresholdAndIncrement()
{
    AUTO_TRACE_FUNC;
    uint32_t maxMrsOpCount = CFG->overloadControl.mcoSlbOpCountOverloadControl.maxCntMrs;
    return checkIfOpCountAboveThresholdAndIncrement(maxMrsOpCount, m_opCntMrs);
}

bool McoSlbOpCounts::checkIfPccOpCountAboveThresholdAndIncrement()
{
    AUTO_TRACE_FUNC;
    uint32_t maxPccOpCount = CFG->overloadControl.mcoSlbOpCountOverloadControl.maxCntPccChange;
    return checkIfOpCountAboveThresholdAndIncrement(maxPccOpCount, m_opCntPccChange);
}

bool McoSlbOpCounts::checkIfSccOpCountAboveThresholdAndIncrement()
{
    AUTO_TRACE_FUNC;
    uint32_t maxSccOpCount = CFG->overloadControl.mcoSlbOpCountOverloadControl.maxCntSccChange;
    return checkIfOpCountAboveThresholdAndIncrement(maxSccOpCount, m_opCntSccChange);
}

bool McoSlbOpCounts::checkIfSlbOpCountAboveThresholdAndIncrement()
{
    AUTO_TRACE_FUNC;
    uint32_t maxSlbOpCount = CFG->overloadControl.mcoSlbOpCountOverloadControl.maxCntSlb;
    return checkIfOpCountAboveThresholdAndIncrement(maxSlbOpCount, m_opCntSlb);
}

#ifdef IPC_TEST
uint32_t McoSlbOpCounts::getCurMrsOpCount()
{
    AUTO_TRACE_FUNC;
    return static_cast<uint32_t>(m_opCntMrs);
}

uint32_t McoSlbOpCounts::getCurPccOpCount()
{
    AUTO_TRACE_FUNC;
    return static_cast<uint32_t>(m_opCntPccChange);
}

uint32_t McoSlbOpCounts::getCurSccOpCount()
{
    AUTO_TRACE_FUNC;
    return static_cast<uint32_t>(m_opCntSccChange);
}
#endif

/**
 * @brief       Check if any of the current serving cell's collocated cells have NR-DC enabled
 *              This function can only check Intra gNB cells.
 * @param[in]   rCall : reference to call info
 * @return      bool : true if a collocated intra-gNB cell with NR-DC enabled was found, false otherwise
 */
bool FnVCCB_CheckIfNrDcCapaRequiredForPcc(const callInfo_type &rCall)
{
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(rCall.gnbNum, false);
    const VccbGnbInfo_type &rGnb = GNBINFO[rCall.gnbNum];
    if (!IS_SUPPORT_NRDC_FOO() ||
        IS_SUPPORT_NRDC_UECAPA(&rCall) ||
        (false == rGnb.multiCarrierOperation.capabilityAwareCarrierChange))
    {
        return false;
    }

    VCCB_CHECK_VALID_CELLNUM_RET_VAL(rCall.servCellNum, false);
    const VccbCellInfo_type &servingCell = CELLINFO[rCall.servCellNum];
    if (CI_use != servingCell.cuColocCellInfo.colocCellInfoUsage)
    {
        return false;
    }

    auto doesColocCellSupportNrDc =
    [&rCall, &rGnb] (const colocCellEntries_type &colocCell)
    {
        if ((CI_no_use == colocCell.usage) ||
            (colocCell.globalGnbId.plmn.longId != rGnb.globalGnbId.plmn.longId) ||
            (colocCell.globalGnbId.gnbId.id != rGnb.globalGnbId.gnbId.id))
        {
            return false;
        }

        return IS_SUPPORT_NRDC_Yang(FnVCCB_GetCellNum(rCall.gnbNum, colocCell.cellId));
    };

    return std::any_of(std::begin(servingCell.cuColocCellInfo.colocCellEntries),
                       std::end(servingCell.cuColocCellInfo.colocCellEntries),
                       doesColocCellSupportNrDc);
}

/**
 * @brief       Given a bcBandKeyVec_type, computes md5 hash of the vector and returns it as mcoLbUeBcKey_type
 * @param[in]   rBcBandKeyVec : const reference to the vector to be hashed
 * @return      mcoLbUeBcKey_type : hash of the input vector
 */
mcoLbUeBcKey_type FnVCCB_McoLbComputeUeBcKey(const bcBandKeyVec_type &rBcBandKeyVec)
{
    AUTO_TRACE_FUNC;
    static_assert(MD5_DIGEST_LENGTH == sizeof(mcoLbUeBcKey_type), "MD5 Digest Length size and mcoLbUeBcKey_type size mismatch!\n");

    union Key
    {
        unsigned char key_as_array[MD5_DIGEST_LENGTH];
        mcoLbUeBcKey_type key_as_uint128;
    };

    MD5_CTX ctx {};
    MD5_Init(&ctx);

    for (const auto &key: rBcBandKeyVec)
    {
        MD5_Update(&ctx, &key, sizeof(key));
    }

    Key hashed_key {};
    MD5_Final(hashed_key.key_as_array, &ctx);

    return hashed_key.key_as_uint128;
}

/**
 * @brief MCO LB FR90: Return md5 hash created from (allowed) UE BCs which includes given NR band.
 * @param[in]   rCall : reference to call context
 * @param[in]   ueSupBandCombList : reference to UE Band Combinations
 * @param[in]   nrBand : NR band that should be included in all BCs
 * @return      mcoLbUeBcKey_type : computed md5 hash
 **/
mcoLbUeBcKey_type FnVCCB_McoLbGetUeBcKey(const callInfo_type &rCall, const bandCombinationList_type &ueSupBandCombList,
    const uint16_t nrBand)
{
    AUTO_TRACE_FUNC;

    bcBandKeyVec_type bcBandKeyVec;
    const uint32_t bcNum = MIN(ueSupBandCombList.num, MAX_BAND_COMBS);

    auto fnRetrieveBcBandKey = [&ueSupBandCombList, &nrBand, &bcBandKeyVec](uint32_t bcIdx) -> void
    {
        mcoBand2numContCcDq_type mcoBand2numContCcDq;
        bool ulPcellBandFlag = false;
        FnVCCB_McoRetrieveBcDataDlUl(ueSupBandCombList.bandCombination[bcIdx], ci_nr, nrBand, mcoBand2numContCcDq,
            ulPcellBandFlag);
        if (false == ulPcellBandFlag)
        {
            return;
        }

        const mcoBcBandInfoDq_type &bcBandInfoDq = mcoBand2numContCcDq[nrBand];
        const mcoCheckBcBandResultsCache_s::key_type bcBandKey = mcoCheckBcBandResultsCache_s::makeBcBandKeyDlUl(bcBandInfoDq);
        bcBandKeyVec.push_back(bcBandKey);
    };

    if (((E_CALLTYPE_NSA == rCall.callType) || IS_NRDC_SN(&rCall)) &&
        (VCCB_FLAG_ON == rCall.cgConfigInfo.configRestrictInfoFlag) &&
        (VCCB_FLAG_ON == rCall.cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC_Flag))
    {
        const bandCombinationInfoList_type &allowedBC = rCall.cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC;
        const uint16_t allowedBcNum = MIN(allowedBC.nrofBandComb, MAX_NUM_BAND_COMB);

        for (uint32_t allowedBcIdx = 0; allowedBcIdx < allowedBcNum; allowedBcIdx++)
        {
            uint32_t bcIdx = allowedBC.bandCombinationInfo[allowedBcIdx].bandCombinationIndex - 1U;
            VCCB_CHECK_E_RANGE_AND_CONTINUE(bcIdx, bcNum);
            fnRetrieveBcBandKey(bcIdx);
        }
    }
    else
    {
        for (uint32_t bcIdx = 0; bcIdx < bcNum; bcIdx++)
        {
            fnRetrieveBcBandKey(bcIdx);
        }
    }

    std::sort(bcBandKeyVec.begin(), bcBandKeyVec.end());
    return FnVCCB_McoLbComputeUeBcKey(bcBandKeyVec);
}

/**
 * @brief MCO LB FR90: Find cached result for given cell and update hit time.
 * @param[in]   cellNum : given cell
 * @param[in]   eligibleCcIdxBitmsk : eligible CC bitmask
 * @param[in]   ueBcKey : md5 hash computed from (allowed) UE BCs
 * @return      bool: true if entry has been found
 **/
bool FnVCCB_FindMcoLbCellCache(const CellNum_type cellNum, const uint8_t eligibleCcIdxBitmsk,
    const McoLbCacheUeBcKey_type ueBcKey, McoLbCacheResultEntry_type &rCachedResultOut)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);

    VccbNonBackupCellInfo_type &rCellInfo = EXTERNAL_INFO.cell[cellNum];


    for (McoLbCacheResultEntry_type &rEntry : rCellInfo.mcoLbCacheEntries)
    {
        if ((eligibleCcIdxBitmsk != rEntry.eligibleCcIdxBitmsk) || (ueBcKey != rEntry.ueBcKey))
        {
            continue;
        }

        ///// MUTEX LOCK /////
        MUTEX_LOCK(&rCellInfo.mcoLbCacheMutex);
        /////////////////////

        if ((eligibleCcIdxBitmsk != rEntry.eligibleCcIdxBitmsk) || (ueBcKey != rEntry.ueBcKey))
        {
            ///// MUTEX UNLOCK /////
            MUTEX_UNLOCK(&rCellInfo.mcoLbCacheMutex);
            ////////////////////////

            return false;
        }

        rEntry.hitTime = time(NULL);
        rCachedResultOut = rEntry;

        ///// MUTEX UNLOCK /////
        MUTEX_UNLOCK(&rCellInfo.mcoLbCacheMutex);
        ////////////////////////

        return true;
    }

    return false;
}

/**
 * @brief MCO LB FR90: Set result to the cache for given cell.
 * @param[in]   cellNum     : given cell
 * @param[in]   rResultIn   : result to be stored
 **/
void FnVCCB_SetMcoLbCellCache(const CellNum_type cellNum, const McoLbCacheResultEntry_type &rResultIn)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    VccbNonBackupCellInfo_type &rCellInfo = EXTERNAL_INFO.cell[cellNum];

    ///// MUTEX LOCK /////
    MUTEX_LOCK(&rCellInfo.mcoLbCacheMutex);
    /////////////////////

    // find already stored entry then first empty entry then oldest hit entry
    McoLbCacheResultEntry_type *pEmpty = nullptr;
    McoLbCacheResultEntry_type *pOldest = rCellInfo.mcoLbCacheEntries;
    for (McoLbCacheResultEntry_type &rEntry : rCellInfo.mcoLbCacheEntries)
    {
        if ((rResultIn.eligibleCcIdxBitmsk == rEntry.eligibleCcIdxBitmsk) && (rResultIn.ueBcKey == rEntry.ueBcKey))
        {
            // entry already stored, update if newer
            if (rResultIn.hitTime > rEntry.hitTime)
            {
                rEntry.hitTime = rResultIn.hitTime;
            }

            ///// MUTEX UNLOCK /////
            MUTEX_UNLOCK(&rCellInfo.mcoLbCacheMutex);
            ////////////////////////

            return;
        }

        if (nullptr == pEmpty)
        {
            if (0 == rEntry.eligibleCcIdxBitmsk)
            {
                pEmpty = &rEntry;
            }

            if (pOldest->hitTime > rEntry.hitTime)
            {
                pOldest = &rEntry;
            }
        }
    }

    if (pEmpty)
    {
        *pEmpty = rResultIn;
    }
    else
    {
        *pOldest = rResultIn;
    }

    ///// MUTEX UNLOCK /////
    MUTEX_UNLOCK(&rCellInfo.mcoLbCacheMutex);
    ////////////////////////
}

void FnVCCB_SortMcoConfigEntries(multiCarrierOperationProfileEntry_type &rProfile)
{
    AUTO_TRACE_FUNC;

    struct ConfigEntrySort_type
    {
        uint8_t priority;
        uint8_t index;
    };

    ConfigEntrySort_type configEntrySortList[MAX_MCO_CONFIG_ENTRIES];

    for(uint8_t index = 0; index < MAX_MCO_CONFIG_ENTRIES; ++index)
    {
        const auto &rConfigEntry = rProfile.configEntry[index];
        configEntrySortList[index].priority = rConfigEntry.configPriority;
        configEntrySortList[index].index = index;
    }

    // 1. Priority: decending order
    // 2. Index: ascending order
    std::sort(configEntrySortList, configEntrySortList + MAX_MCO_CONFIG_ENTRIES,
            [](const ConfigEntrySort_type &lhs, const ConfigEntrySort_type &rhs)
            {
                if((lhs.priority > rhs.priority) || ((lhs.priority == rhs.priority) && (lhs.index < rhs.index)))
                {
                    return true;
                }

                return false;
            });

    for (uint8_t index = 0; index < MAX_MCO_CONFIG_ENTRIES; ++index)
    {
        rProfile.configEntrySortIdx[index] = configEntrySortList[index].index;
    }
}

