/**
 * @file        FeatCa.cpp
 * @brief       Utility functions for Carrier Aggregation
 */

#include <math.h>

#include "FeatCa.hpp"
#include "SccA4MrManager.hpp"

#include "ComInclude.h"
#include "ComLibUtility.h"
#include "ComTimeUtil.h"

#include "FeatCommon.h"
#include "FeatHo.h"
#include "FeatLtmHo.h"
#include "FeatCallInfo.h"
#include "FeatCallProc.h"
#include "FeatMeasurements.hpp"
#include "FeatMcoStruct.hpp"
#include "FeatMco.hpp"
#include "FeatMco.h"
#include "FeatInterference.h"
#include "FeatConditionalHo.h"
#include "FeatMrdc.h"
#include "FeatRrcSegment.h"
#include "FeatCaCsl.hpp"
#include "FeatLb.hpp"
#include "FeatNrdcMnBcReselection.hpp"
#include "FeatMrdcApi.h"

#include "MsgNrRrcStore.h"

#include "StateCa.h"
#include "StateCommon.h"
#include "StateMeasurements.h"
#include "StateMco.h"

#include "ref_table.h"

static const uint32_t scsEnum2Val[ci_Nr_scsMAX] = {15, 30, 60, 120, 240};
static const uint32_t nrbEnum2Val[ci_NrSystemBandwidth_MAX] = {11, 18, 24, 25, 31, 32, 38, 51, 52, 65, 66, 78, 79,
    93, 106, 107, 121, 132, 133, 135, 160, 162, 189, 216, 217, 245, 264, 270, 273};

static scellInfo_type dummyScells[MAX_SCELL_PER_CALL];

/**
 * @brief       Return minimum guard band in kHz*2 for channel bandwidth in MHz
 *              Refer to 3GPP 38.101-1/2 chapter 5.3.3
 */
uint32_t VLIB_GetMinGuardBand2kHz(enumNrSubCarrierSpacing_type scs, enumNrSystemBandwidth_type nrb, uint32_t bandwidth)
{
    AUTO_TRACE_FUNC;

    if ((ci_Nr_scsMAX <= scs) || (ci_NrSystemBandwidth_MAX <= nrb))
    {
        VCCB_PRINT_ERROR("Invalid parameters scs(%u) nrb(%u)\n", scs, nrb);
        return 0;
    }

    if (ci_Nr_scs240 == scs)
    {
        switch (bandwidth)
        {
            case 100:
                return 3800 * 2;
            case 200:
                return 7720 * 2;
            case 400:
                return 15560 * 2;
            default:
                VCCB_PRINT_ERROR("Invalid bandwidth(%u) for scs240\n", bandwidth);

                return 0;
        }
    }

    return ((bandwidth * 1000) - (nrbEnum2Val[nrb] * scsEnum2Val[scs] * 12)) - scsEnum2Val[scs];
}

/**
 * @brief       Returns absolute subtraction of two operands
 */
template <typename T>
T VLIB_AbsSub(const T &a, const T &b)
{
    return ((a > b) ? (a - b) : (b - a));
}

/**
 * @brief       Check if Band is Operating In 100 kHz Channel Raster
 *              Refer to 3GPP 38.101-1/2 table 5.4.2.3-1 V18.2.0
 */
bool VLIB_isBandOperatingIn100kHzChRaster(uint32_t band)
{
    AUTO_TRACE_FUNC;

    if (257 <= band)
    {
        // FR2
        return false;
    }

    switch (band)
    {
        case 41:
        case 46:
        case 47:
        case 48:
        case 77:
        case 78:
        case 79:
        case 96:
        case 102:
        case 104:
            return false;
        default:
            break;
    }

    return true;
}

/**
 * @brief   Get the largest SCS value among the subcarrier spacing configurations supported in the operating band of
 *          the channel bandwidth according to Table 5.3.5-1: "Channel bandwidths for each NR band" 3GPP TS38.101-1/2 V18.2.0
 */
enumNrSubCarrierSpacing_type VLIB_GetMaxScsForBandBw(const uint16_t band, const uint32_t bw)
{
    AUTO_TRACE_FUNC;

    if (MAX_FR1_NR_BAND < band)
    {
        // FR2
        return ci_Nr_scs120;
    }

    // FR1
    // 5MHz only bands: n51, n54, n76, n100
    if (ci_nr_bandwidth_5MHz == bw)
    {
        return ci_Nr_scs15;
    }

    switch (band)
    {
        case 91:
        case 93:
            return ci_Nr_scs15;

        case 5:
        case 8:
        case 12:
        case 13:
        case 14:
        case 18:
        case 20:
        case 26:
        case 28:
        case 29:
        case 30:
        case 67:
        case 71:
        case 81:
        case 82:
        case 83:
        case 85:
        case 92:
        case 94:
        case 101:
        case 105:
            return ci_Nr_scs30;

        case 89:
            if (ci_nr_bandwidth_50MHz == bw)
            {
                return ci_Nr_scs60;
            }
            return ci_Nr_scs30;

        default:
            break;
    }

    return ci_Nr_scs60;
}

/**
 * @brief   Get the smallest SCS value among the subcarrier spacing configurations supported in the operating band
 *          the channel bandwidth according to Table 5.3.5-1: "Channel bandwidths for each NR band" 3GPP TS38.101-1/2 V18.2.0
 */
enumNrSubCarrierSpacing_type VLIB_GetMinScsForBandBw(const uint16_t band, const uint32_t bw)
{
    AUTO_TRACE_FUNC;

    if (MAX_FR1_NR_BAND < band)
    {
        // FR2
        if (ci_nr_bandwidth_400MHz == bw)
        {
            return ci_Nr_scs120;
        }
        return ci_Nr_scs60;
    }

    // FR1
    if ((89 == band) && (ci_nr_bandwidth_50MHz == bw))
    {
        return ci_Nr_scs60;
    }

    if (ci_nr_bandwidth_50MHz >= bw)
    {
        return ci_Nr_scs15;
    }

    switch (band)
    {
        case 40:
        case 41:
        case 46:
        case 48:
        case 50:
        case 77:
        case 78:
        case 79:
        case 90:
        case 96:
        case 97:
        case 102:
        case 104:
            return ci_Nr_scs30;

        default:
            break;
    }

    return ci_Nr_scs15;
}

/**
 * @brief   This function coverts bandwidth (in MHz) and SCS to number of resource blocks.
 */
enumNrSystemBandwidth_type VLIB_BwScs2Nrb(const enumFrequencyRange_type frType, const uint32_t bandwidth,
    const enumNrSubCarrierSpacing_type subcarrierSpacing)
{
    AUTO_TRACE_FUNC;

    int bandIdx = 0;
    int maxScsIdx = 0;
    int scsIdx = 0;

    if (FrequencyRange_FR2 == frType)
    {
        maxScsIdx = MAX_A6_SCS_NUM;
        scsIdx = subcarrierSpacing - ci_Nr_scs60;
    }
    else
    {
        maxScsIdx = MAX_B6_SCS_NUM;
        scsIdx = subcarrierSpacing;
    }

    if (scsIdx >= maxScsIdx)
    {
        VCCB_PRINT_ERROR("SCS(%u) is invalid for FR(%u)!\n", subcarrierSpacing, frType);
        return ci_NrSystemBandwidth_MAX;
    }

    if (FrequencyRange_FR2 == frType)
    {
        for (bandIdx = 0; bandIdx < MAX_A6_BANDWIDTH_NUM; bandIdx++)
        {
            if (bandwidth != A6CarrierBandwidth[bandIdx].bandwidth)
            {
                continue;
            }

            return static_cast<enumNrSystemBandwidth_type>(A6CarrierBandwidth[bandIdx].rbInfo[scsIdx].nRB);
        }
    }
    else
    {
        for (bandIdx = 0; bandIdx < MAX_B6_BANDWIDTH_NUM; bandIdx++)
        {
            if (bandwidth != B6CarrierBandwidth[bandIdx].bandwidth)
            {
                continue;
            }

            return static_cast<enumNrSystemBandwidth_type>(B6CarrierBandwidth[bandIdx].rbInfo[scsIdx].nRB);
        }
    }

    VCCB_PRINT_ERROR("Bandwidth(%u) is invalid for FR(%u)!\n", bandwidth, frType);
    return ci_NrSystemBandwidth_MAX;
}

/**
 * @brief       Get SCS for nominal channel spacing according to chapter 5.4.1.2 of 3GPP TS38.101-1/2 V18.2.0
 */
enumNrSubCarrierSpacing_type VLIB_GetScsForNominalChannelSpacing(const uint16_t band, const uint32_t bwMhz1, const uint32_t bwMhz2)
{
    AUTO_TRACE_FUNC;

    const enumNrSubCarrierSpacing_type maxScs1 = VLIB_GetMaxScsForBandBw(band, bwMhz1);
    const enumNrSubCarrierSpacing_type maxScs2 = VLIB_GetMaxScsForBandBw(band, bwMhz2);
    const enumNrSubCarrierSpacing_type minScs1 = VLIB_GetMinScsForBandBw(band, bwMhz1);
    const enumNrSubCarrierSpacing_type minScs2 = VLIB_GetMinScsForBandBw(band, bwMhz2);

    enumNrSubCarrierSpacing_type commMaxScs = std::min(maxScs1, maxScs2);
    if (std::max(minScs1, minScs2) > commMaxScs)
    {
        // no common max SCS
        commMaxScs = ((MAX_FR1_NR_BAND >= band) ? ci_Nr_scs30 : ci_Nr_scs120);
    }

    return commMaxScs;
}

/**
 * @brief       Get nominal channel spacing in kHz for CA according to chapter 5.4.1.2 of 3GPP TS38.101-1/2 V18.2.0
 */
uint32_t VLIB_GetNominalChannelSpacingCa(const uint16_t band, const uint32_t bwMhz1, const uint32_t bwMhz2)
{
    AUTO_TRACE_FUNC;

    const enumNrSubCarrierSpacing_type commMaxScs = VLIB_GetScsForNominalChannelSpacing(band, bwMhz1, bwMhz2);

    const enumFrequencyRange_type frType = ((MAX_FR1_NR_BAND >= band) ? FrequencyRange_FR1 : FrequencyRange_FR2);
    const enumNrSystemBandwidth_type nrb1ForMaxScs = VLIB_BwScs2Nrb(frType, bwMhz1, commMaxScs);
    VCCB_CHECK_E_RANGE_AND_VAL(nrb1ForMaxScs, ci_NrSystemBandwidth_MAX, 0);
    const enumNrSystemBandwidth_type nrb2ForMaxScs = VLIB_BwScs2Nrb(frType, bwMhz2, commMaxScs);
    VCCB_CHECK_E_RANGE_AND_VAL(nrb2ForMaxScs, ci_NrSystemBandwidth_MAX, 0);

    const uint32_t GB1 = VLIB_GetMinGuardBand2kHz(commMaxScs, nrb1ForMaxScs, bwMhz1);
    const uint32_t GB2 = VLIB_GetMinGuardBand2kHz(commMaxScs, nrb2ForMaxScs, bwMhz2);

    VCCB_PRINT_COMMENT("CC1: BW(%u) GB(%u), CC2: BW(%u) GB(%u), maxScs(%u)\n", bwMhz1, GB1, bwMhz2, GB2, commMaxScs);

    // nominal channel spacing [kHz]:
    uint32_t ncsKhz = 1000 * (bwMhz1 + bwMhz2) - VLIB_AbsSub(GB1, GB2);
    if (VLIB_isBandOperatingIn100kHzChRaster(band))
    {
        ncsKhz = (ncsKhz / 600) * 300;  // intentionally fraction part is lost during division

        VCCB_PRINT_COMMENT("NCS(%u) band(%u) (100kHz ch. raster)\n", ncsKhz, band);
    }
    else
    {
        static const uint32_t scs2valKhz[] = {15, 30, 60, 120, 240, 480};

        if (ci_Nr_scs240 < commMaxScs)
        {
            VCCB_PRINT_ERROR("Invalid maxScs(%u)\n", commMaxScs);
            return 0;
        }
        ncsKhz = (ncsKhz / scs2valKhz[commMaxScs + 1]) *
                 scs2valKhz[commMaxScs];  // intentionally fraction part is lost during division

        VCCB_PRINT_COMMENT("NCS(%u) band(%u)\n", ncsKhz, band);
    }

    return ncsKhz;
}

/**
 * @brief       Calculate center frequency in kHz from Reference Point A
 */
uint32_t VLIB_GetCenterFreqFromRefPointA(const uint32_t arfcnRefPointA, const enumNrSubCarrierSpacing_type scs,
    const enumNrSystemBandwidth_type nrb)
{
    AUTO_TRACE_FUNC;
    static const uint32_t HALF_N_RB_SC = 6; // number of subcarriers per resource block divided by 2

    if ((ci_Nr_scsMAX <= scs) || (ci_NrSystemBandwidth_MAX <= nrb))
    {
        VCCB_PRINT_ERROR("Invalid parameters scs(%u) nrb(%u)\n", scs, nrb);
        return 0;
    }

    return VLIB_Arfcn2Freq(arfcnRefPointA) + (nrbEnum2Val[nrb] * scsEnum2Val[scs] * HALF_N_RB_SC);
}

/**
 * @brief       Check if 2 cells are contiguous
 */
template <typename SCellInfoT>
int16_t VLIB_CheckCaCellContiguous(const SCellInfoT &cell1, const SCellInfoT &cell2, const uint16_t band)
{
    AUTO_TRACE_FUNC;


    const enumNrSubCarrierSpacing_type cellScs1 = static_cast<enumNrSubCarrierSpacing_type>(cell1.nrScsDl);
    const enumNrSubCarrierSpacing_type cellScs2 = static_cast<enumNrSubCarrierSpacing_type>(cell2.nrScsDl);

    const enumNrSystemBandwidth_type cellNrb1 = static_cast<enumNrSystemBandwidth_type>(cell1.nRbDl);
    const enumNrSystemBandwidth_type cellNrb2 = static_cast<enumNrSystemBandwidth_type>(cell2.nRbDl);

    const uint32_t bwMhz1 = VLIB_NrbScs2Bw(cellNrb1, cellScs1);
    const uint32_t bwMhz2 = VLIB_NrbScs2Bw(cellNrb2, cellScs2);
    const uint32_t ncsKhz = VLIB_GetNominalChannelSpacingCa(band, bwMhz1, bwMhz2);

    const uint32_t freqKhz1 = VLIB_GetCenterFreqFromRefPointA(cell1.nrArfcnDl, cellScs1, cellNrb1);
    const uint32_t freqKhz2 = VLIB_GetCenterFreqFromRefPointA(cell2.nrArfcnDl, cellScs2, cellNrb2);

    VCCB_PRINT_COMMENT("CaContig Result: ncs(%u) diff(%u) band(%u)\n", ncsKhz, VLIB_AbsSub(freqKhz2, freqKhz1), band);

    if (VLIB_AbsSub(freqKhz2, freqKhz1) <= ncsKhz)
    {
        // Contiguous
        return GOOD;
    }

    // Non-Contiguous
    return BREAK;
}

/**
 * @brief   Check if EUTRA cells in band 46 are contiguous
 */
bool VLIB_IsEutraCellContiguous_b46(const uint32_t gapKHz, const uint32_t bwKHz1, const uint32_t bwKHz2)
{
    AUTO_TRACE_FUNC;

    bool result = false;

    if ((20000 == bwKHz1) && (20000 == bwKHz2))
    {
        if ((20100 == gapKHz) || (19800 == gapKHz))
        {
            result = true;
        }
    }
    else if (((10000 == bwKHz1) && (20000 == bwKHz2)) || ((20000 == bwKHz1) && (10000 == bwKHz2)))
    {
        if (15000 == gapKHz)
        {
            result = true;
        }
    }

    if (true == result)
    {
        VCCB_PRINT_COMMENT("%s: b46 Cells are contiguous!\n", __FUNCTION__);
    }

    return result;
}

/**
 * @brief   Check if EUTRA cells are contiguous
 */
int16_t VLIB_IsEutraCellContiguous(
    const uint16_t band, const uint32_t freqKHz1, const uint32_t bwKHz1, const uint32_t freqKHz2, const uint32_t bwKHz2)
{
    AUTO_TRACE_FUNC;

    VCCB_PRINT_COMMENT("%s: band(%d): freqKHz1(%d) bwKHz1(%d) - freqKHz2(%d) bwKHz2(%d)\n", __FUNCTION__, band,
        freqKHz1, bwKHz1, freqKHz2, bwKHz2);

    const uint32_t bwAbsSub = (uint32_t)((double)VLIB_AbsSub(bwKHz1, bwKHz2) * 0.1);

    const uint32_t ncsKHz = ((uint32_t)((bwKHz1 + bwKHz2 - bwAbsSub) / 600)) * 300;
    const uint32_t gapKHz = VLIB_AbsSub(freqKHz1, freqKHz2);

    VCCB_PRINT_COMMENT("%s: gapKHz(%d) == ncsKHz(%d) \n", __FUNCTION__, gapKHz, ncsKHz);

    if (ncsKHz == gapKHz)
    {
        return TRUE;
    }

    if (UNII5200_BAND46 == band)
    {
        return VLIB_IsEutraCellContiguous_b46(gapKHz, bwKHz1, bwKHz2);
    }

    return FALSE;
}

/**
 * @brief       Check if 2 EUTRA cells are contiguous
 */
template <>
int16_t VLIB_CheckCaCellContiguous(const mcoEutraCellInfo_s &cell1, const mcoEutraCellInfo_s &cell2, uint16_t band)
{
    AUTO_TRACE_FUNC;

    if (TRUE == VLIB_IsEutraCellContiguous(band, cell1.freqKhzDl, cell1.bwKhzDl, cell2.freqKhzDl, cell2.bwKhzDl))
    {
        return GOOD;
    }

    return BREAK;
}

/**
 * @brief     Check if scells CC exceed CC_LIMITATION_400MHZ.
 *            If function is called for initial check MRREL scells are also taken to calculation.
 * @param     ptCi : callInfo
 * @param     isInitialCheck : information if function is called for initial check
 * return     GOOD - exceeded, ERROR/BREAK - not exceeded
 */
int16_t VLIB_IsCcLimitExceeded(callInfo_type *ptCi, bool isInitialCheck)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    cellSelection_type spCellSelection = FnVCCB_GetCellSelectionForConfig(ptCi);
    VCCB_CHECK_VALID_CELLNUM_ERROR(spCellSelection.cellNum);
    VccbCellInfo_type *const pSpCell = &CELLINFO[spCellSelection.cellNum];

    uint32_t totalBWSum = pSpCell->intraGnbNbrInfo.bandwidthDl;
    if (ci_DUPLEXTYPE_TDD != FnVCCB_GetNrDuplexTypeByBandIndicator(spCellSelection.bandNr))
    {
        totalBWSum += pSpCell->intraGnbNbrInfo.bandwidthUl;
    }

    for (scellInfo_type &rSCell : ptCi->sCell)
    {
        if ((SCELL_STATE_ADDED == rSCell.state) ||
            ((true == isInitialCheck) && (SCELL_STATE_MRREL == rSCell.state)))
        {
            // DL
            totalBWSum += rSCell.bandwidthDl;

            // UL - skip for TDD cells
            if (ci_DUPLEXTYPE_TDD != FnVCCB_GetNrDuplexTypeByBandIndicator(rSCell.bandNr))
            {
                totalBWSum += rSCell.bandwidthUl;
            }
        }
    }

    if (CC_LIMITATION_400MHZ < totalBWSum)
    {
        return GOOD;
    }

    return BREAK;
}

/**
 * @brief     Decide about Component Carriers Limit state
 * @param     ptCi : callInfo
 * return     uint8_t - enumComponentCarriersLimit
 */
uint8_t VLIB_DecideComponentCarriersLimit(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, CcLimit_Off);
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, CcLimit_Off);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint16_t spCellNum = FnVCCB_GetCellSelectionForConfig(ptCi).cellNum;
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(spCellNum, CcLimit_Off);
    VccbCellInfo_type *const pSpCell = &CELLINFO[spCellNum];

    const uint32_t ssbArfcn = pSpCell->ssbArfcn;
    reportConfigurationConfUe_type a1reportConfigCandidate;
    minimalMeasObjectConfUe_type moCandidate;

    if (((ptCi->callType != E_CALLTYPE_NSA) && (!IS_NRDC_SN(ptCi))) ||
        (EQUIP != pGnb->carrierAggregationInfo.a6UeTxpowerEnhancement) || (MIN_A6_NR_ARFCN > ssbArfcn))
    {
        VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: CcLimit_Off, pscell doesn't meet requirements\n");
        return CcLimit_Off;
    }

    if ((!VCCB_CanMOAndRCBeAddedWithCandidates(*ptCi, spCellNum, measReport_A1,
                     a1Purpose_scellRecoveryInA6UeTxpowerEnh, ssbArfcn, &a1reportConfigCandidate, &moCandidate)) ||
        (GOOD !=
            VCCB_CanMOAndRCBeAdded(ptCi, spCellNum, measReport_A2, a2Purpose_scellReleaseInA6UeTxpowerEnh, ssbArfcn)))
    {
        VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: CcLimit_Off, report config cannot be found\n");
        return CcLimit_Off;
    }

    // Decide about new state only for addition. Otherwise return previous.
    if ((SgNBAddition_cmd != ptCi->stateCmd) && (MrdcXnSNAdd_cmd != ptCi->stateCmd))
    {
        VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: CcLimit(%u) - unchanged\n", ptCi->caInfo.componentCarriersLimit);
        return ptCi->caInfo.componentCarriersLimit;
    }

    if (GOOD != VLIB_IsCcLimitExceeded(ptCi, true))
    {
        VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: CcLimit_Off, Component carriers not exceed 400MHz.\n");
        return CcLimit_Off;
    }

    int8_t servingCellSignal = 0;

    if (choice_rsrp == a1reportConfigCandidate.reportConfiguration.eventBased.event.A1.a1_Threshold.quantity)
    {
        if (TRUE == ptCi->servingCellMeasInitialInfo.rsrpFlag)
        {
            servingCellSignal = ptCi->servingCellMeasInitialInfo.rsrp;
        }
        else
        {
            VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: CcLimit_Recovered, RSRP result not received in SN addition\n");
            return CcLimit_Recovered;
        }
    }
    else if (choice_rsrq == a1reportConfigCandidate.reportConfiguration.eventBased.event.A1.a1_Threshold.quantity)
    {
        if (TRUE == ptCi->servingCellMeasInitialInfo.rsrqFlag)
        {
            servingCellSignal = ptCi->servingCellMeasInitialInfo.rsrq;
        }
        else
        {
            VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: CcLimit_Recovered, RSRQ result not received in SN addition\n");
            return CcLimit_Recovered;
        }
    }
    else
    {
        VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: CcLimit_Off, SINR configured\n");
        return CcLimit_Off;
    }

    if (a1reportConfigCandidate.reportConfiguration.eventBased.event.A1.a1_Threshold.value <= servingCellSignal)
    {
        VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: CcLimit_Recovered\n");
        return CcLimit_Recovered;
    }
    else
    {
        VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: CcLimit_Released\n");
        return CcLimit_Released;
    }
}

/**
 * @brief     Decide about scells which will be released because of Component carriers limit
 * @param     ptCi : callInfo
 * return     uint8_t - enumComponentCarriersLimit
 */
void VLIB_DecideAboutScellToRelease(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    struct SCellBwInfo_type
    {
        uint32_t totalBW;  // FDD: sum UL + DL, TDD: BW
        uint32_t ssbArfcn;
        uint32_t sCellIdx;
    };

    SCellBwInfo_type cellList[MAX_SCELL_PER_CALL + 1];
    uint32_t totalBWSum = 0;
    uint8_t pscellPosition = 0, cellListCount = 0, idx = 0;

    cellSelection_type spCellSelection = FnVCCB_GetCellSelectionForConfig(ptCi);
    VCCB_CHECK_VALID_CELLNUM_VOID(spCellSelection.cellNum);
    VccbCellInfo_type *const pSpCell = &CELLINFO[spCellSelection.cellNum];

    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (idx = 0; idx < MAX_SCELL_PER_CALL; ++idx)
    {
        if (SCELL_STATE_ADDED != scells[idx].state)
        {
            continue;
        }

        cellList[cellListCount].ssbArfcn = scells[idx].ssbArfcn;
        cellList[cellListCount].sCellIdx = idx;
        cellList[cellListCount].totalBW = scells[idx].bandwidthDl;

        if (ci_DUPLEXTYPE_TDD != FnVCCB_GetNrDuplexTypeByBandIndicator(scells[idx].bandNr))
        {
            cellList[cellListCount].totalBW += scells[idx].bandwidthUl;
        }
        cellListCount++;
    }

    // Add PCell to the list
    cellList[cellListCount].ssbArfcn = pSpCell->ssbArfcn;
    cellList[cellListCount].sCellIdx = ptCi->servCellIndex;
    cellList[cellListCount].totalBW = pSpCell->intraGnbNbrInfo.bandwidthDl;

    if (ci_DUPLEXTYPE_TDD != FnVCCB_GetNrDuplexTypeByBandIndicator(spCellSelection.bandNr))
    {
        cellList[cellListCount].totalBW += pSpCell->intraGnbNbrInfo.bandwidthUl;
    }
    cellListCount++;

    // Sort cellList ascending by arfcn value
    std::sort(cellList, cellList + cellListCount,
        [](const SCellBwInfo_type &a, const SCellBwInfo_type &b) { return a.ssbArfcn < b.ssbArfcn; });

    for (idx = 0; idx < cellListCount; ++idx)
    {
        totalBWSum += cellList[idx].totalBW;

        if (cellList[idx].sCellIdx == ptCi->servCellIndex)
        {
            pscellPosition = idx;
        }
    }

    VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: %d SCELLS detected, totalBWsSum(%u)\n", cellListCount, totalBWSum);

    auto releaseScell = [&ptCi, &cellList, &totalBWSum, &scells](uint8_t idxOfScellToRelease)
    {
        totalBWSum -= cellList[idxOfScellToRelease].totalBW;

        scellInfo_type &rScell = scells[cellList[idxOfScellToRelease].sCellIdx];
        rScell.state = SCELL_STATE_CCLIMITREL;

        if (SCELL_ACTION_KEEP == rScell.action)
        {
            rScell.action = SCELL_ACTION_RELEASE;
            rScell.isActionQueued = TRUE;
        }
        else
        {
            rScell.action = SCELL_ACTION_KEEP;
            // reset cause as scell will be not added
            rScell.addRelCause = CaSCellAddAtt_Total;
        }

        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: sCell released scellIdx(%d)/sCellIndex(%d)/pci(%d)\n",
                cellList[idxOfScellToRelease].sCellIdx, rScell.sCellIndex, rScell.pci);
    };

    for (idx = static_cast<uint8_t>(cellListCount - 1); ((idx > pscellPosition) && (CC_LIMITATION_400MHZ < totalBWSum)); --idx)
    {
        releaseScell(idx);
    }

    for (idx = 0; ((idx < pscellPosition) && (CC_LIMITATION_400MHZ < totalBWSum)); ++idx)
    {
        releaseScell(idx);
    }
}

/**
 * @brief   initializes mutexes for OM failed scells managing
 */
int VLIB_InitOMFailedScellsMutex(pthread_mutexattr_t *pAttr)
{
    AUTO_TRACE_FUNC;

    int rCode = 0;

    if (!pAttr)
    {
        return EXIT_MUTEXATTR_INIT_FAIL;
    }

    for (unsigned int iCell = 0; iCell < MAX_CELL_NUM_VCCB; ++iCell)
    {
        pthread_mutex_t *pMutex = &EXTERNAL_INFO.cell[iCell].oMFailedScellsMutex;

        rCode = pthread_mutex_init(pMutex, pAttr);
        if (rCode)
        {
            return EXIT_MUTEXATTR_INIT_FAIL;
        }
    }

    return 0;
}

/**
 * @brief   Check if colocCellEntry status is Abnormal
 */
bool VLIB_IsCaColocCellStatusAbnormal(colocCellEntries_type *pColocCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(pColocCell, false)

    if (CaColocCellStatus_Abnormal == pColocCell->callCurrColocCellStatus)
    {
        return true;
    }

    return false;
}

/**
 * @brief       Re-calculate Effective Bandwidth considering cell's PRB capacity
 */
template <typename CellPrbT>
void FnVCCB_McoRecalculateBwWithPrbCapacity(const CellPrbT &rCellPrb, caCellInfo_type &rCellInfo)
{
    AUTO_TRACE_FUNC;

    rCellInfo.mcoBwDl = static_cast<uint16_t>(1.0 * rCellInfo.mcoBwDl * rCellPrb.dlCapacityValue / 100.0);
    rCellInfo.mcoBwUl = static_cast<uint16_t>(1.0 * rCellInfo.mcoBwUl * rCellPrb.ulCapacityValue / 100.0);

    if (BAND_NOT_FOUND != rCellInfo.mcoMChAltBand)
    {
        rCellInfo.mcoMChAltBandBwDl = static_cast<uint16_t>(1.0 * rCellInfo.mcoMChAltBandBwDl * rCellPrb.dlCapacityValue / 100.0);
    }
}

/**
 * @brief       Re-calculate Effective Bandwidth considering cell's PRB capacity if effectiveBandwidthOption enabled
 */
void FnVCCB_McoRecBwWithPrbCapacityIfEnabled(callInfo_type *ptCi, const uint16_t spCellNum, const cgi_type &rCgi,
    const uint8_t gnbIdLength, caCellInfo_type &rCellInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (true == ptCi->bitFlag.isMcoLteAccessCase) /* LTE Access Case */
    {
        if (THREAD_INFO->nonUeAsn1.buf.mcoBcInfoReqStore.mrsLoadConsideredFlag == VCCB_FLAG_OFF)
        {
            return;
        }
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] LTE Access Case, mrsLoadConsideredFlag(1). Apply PRB Capacity ! \n");
    }
    else
    {
        if (EffectiveBWOpt_PrbUsage != pGnb->multiCarrierOperation.effectiveBandwidthOption)
        {
            return;
        }
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] NR Access Case, effBwOpt(1), Apply PRB Capacity ! \n");
    }

    const uint16_t cellNum = VLIB_GetCellNumBasedOnCgi(ptCi, rCgi, gnbIdLength);
    if (MAX_CELL_NUM_VCCB > cellNum)
    {
        FnVCCB_McoRecalculateBwWithPrbCapacity(CELLINFO[cellNum].cellRscInfo, rCellInfo);
        return;
    }

    // else inter gNB
    VCCB_CHECK_VALID_CELLNUM_VOID(spCellNum);
    VccbCellInfo_type *const pSpCell = &CELLINFO[spCellNum];
    const uint16_t nbrCellIdx = VLIB_GetNbrIdxBasedOnCgi(pSpCell, rCgi);
    if ((MAX_NBR_PER_CELL <= nbrCellIdx) || (CI_use != pSpCell->cellRscInfo.nbrPrb[nbrCellIdx].usage))
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] nbrPrb is not available cellNum(%u) nbrCellIdx(%u) - use cell BW\n", spCellNum, nbrCellIdx);
        return;
    }
    FnVCCB_McoRecalculateBwWithPrbCapacity(pSpCell->cellRscInfo.nbrPrb[nbrCellIdx], rCellInfo);
}

/**
 * @brief         Fill cell's frequency parameters
 * @param[in]     ptCi : callInfo
 * @param[in]     spCellNum : primary cell num
 * @param[in]     cgi  : cell cgi
 * @param[in]     gnbIdLength  : length of gnb ID
 * @param[out]    rCellInfoOut : cell frequency parameters caCellInfo_type
 * @return        GOOD or ERROR /int16_t
 */
int16_t VLIB_FillCaCellInfo(callInfo_type *ptCi,
    const uint16_t spCellNum, const cgi_type cgi, const uint8_t gnbIdLength,
    caCellInfo_type &rCellInfoOut)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    const nbrGnbCellInfo_type *ptCell = VLIB_GetNbrGnbCellInfoBasedOnCgi(ptCi, cgi, gnbIdLength);
    VALID_E_POINT_CHECK_ERROR(ptCell);

    rCellInfoOut.cgi = cgi;
    rCellInfoOut.tacStatus = ptCell->fiveGsTacStatus;
    rCellInfoOut.ssbArfcn = ptCell->ssbArfcn;
    rCellInfoOut.gnbIdLength = gnbIdLength;
    rCellInfoOut.nrArfcnDl = ptCell->nrArfcnDl;
    rCellInfoOut.nrScsDl = ptCell->nrScsDl;
    rCellInfoOut.nRbDl = static_cast<uint8_t>(ptCell->nrbDl);

    rCellInfoOut.bandListNum = VLIB_GetFreqBandIndListForNeighborCellWithCustomSpCell(
        ptCi, ptCell, spCellNum, false, rCellInfoOut.bandList);
    if (0 == rCellInfoOut.bandListNum)
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: Cannot get common FreqBandInd for ci(%llu)!!\n", 1ULL * cgi.ci);
        return ERROR;
    }
    rCellInfoOut.frequencyBand = rCellInfoOut.bandList[0];

    uint16_t duplexMode = FnVCCB_GetNrDuplexTypeByBandIndicator(rCellInfoOut.frequencyBand);

    if (CI_DUPLEXTYPE_SDL == duplexMode)  // from CA perspective SDL should be treated as FDD
    {
        duplexMode = ci_DUPLEXTYPE_FDD;
    }
    else if ((ci_DUPLEXTYPE_FDD != duplexMode) && (ci_DUPLEXTYPE_TDD != duplexMode))
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: Unsupported duplex type(%u) for ci(%llu), band(%u)!!\n",
            duplexMode, 1ULL * cgi.ci, rCellInfoOut.frequencyBand);
        return ERROR;
    }

    rCellInfoOut.duplexMode = static_cast<enumDuplexMode_ForCall_type>(duplexMode);

    if (MIN_A6_NR_ARFCN <= rCellInfoOut.ssbArfcn)
    {
        rCellInfoOut.frequencyRange = FrequencyRangeCa_FR2;
    }
    else
    {
        rCellInfoOut.frequencyRange = FrequencyRangeCa_FR1;
    }

    rCellInfoOut.isSsbCell = (CI_use != ptCell->ssbMeasurementConfiguration.usage) ||
                            (0 != ptCell->ssbMeasurementConfiguration.ssbValue);

    FnVCCB_McoFillBandwidthByDuplex(rCellInfoOut.duplexMode, rCellInfoOut.mcoBwDl, rCellInfoOut.mcoBwUl, *ptCell);

    // MCO Multiple Channel BW
    // TODO: FGR-CC5500 & FGR-CC3301, p.bereski
    rCellInfoOut.mcoMChPresent = false;
    rCellInfoOut.mcoMChAltBand = BAND_NOT_FOUND;
    rCellInfoOut.mcoMChAltBandBwDl = 0;

    if (BAND_NOT_FOUND != rCellInfoOut.mcoMChAltBand)
    {
        uint16_t dummyBwUl = 0;
        FnVCCB_McoFillBandwidthByDuplex(rCellInfoOut.duplexMode, rCellInfoOut.mcoMChAltBandBwDl, dummyBwUl, *ptCell);
    }

    return GOOD;
}

/**
 * @brief        VLIB_FillCaCellInfo wrapper for spCells, which additionally sets used frequencyBand for spCell.
 * @param[in]    ptCi : callInfo
 * @param[in]    spCellNum : primary cell num
 * @param[out]   rCellInfoOut : cell frequency parameters caCellInfo_type
 * @return       GOOD or ERROR /int16_t
 */
int16_t VLIB_FillPcellCaCellInfo(callInfo_type *ptCi, const cellSelection_type cellSelection, caCellInfo_type &rCellInfoOut)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellSelection.cellNum);

    cgi_type cgi = FnVCCB_GetNrcgiFromCellNum(cellSelection.cellNum);
    uint8_t gnbIdLength = GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.idLength;
    rCellInfoOut.frequencyBand = BAND_NOT_FOUND;

    if (ERROR == VLIB_FillCaCellInfo(ptCi, cellSelection.cellNum, cgi, gnbIdLength, rCellInfoOut))
    {
        return ERROR;
    }

    // before use, make sure cellSelection.bandNr is supported by spcell
    for (uint8_t bandIdx = 0; bandIdx < MIN(VCCB_ARRAY_COUNT(rCellInfoOut.bandList), rCellInfoOut.bandListNum); ++bandIdx)
    {
        if (rCellInfoOut.bandList[bandIdx] == cellSelection.bandNr)
        {
            rCellInfoOut.frequencyBand = cellSelection.bandNr;
            break;
        }
    }

    return GOOD;
}

/**
 * @brief       Fill CA cell's parameters for MCO
 * @param[in]   ptCi : callInfo
 * @param[in]   spCellNum : primary cell num
 * @param[in]   cgi  : cell cgi
 * @param[in]   gnbIdLength  : length of gnb ID
 * @param[in]   noPrbUsage : if true do not re-calculate eBW considering cell's PRB capacity
 * @param[out]  rCellInfoOut : CA cell parameters caCellInfo_type
 * @return      GOOD or ERROR /int16_t
 */
int16_t VLIB_FillCaCellInfoForMco(callInfo_type *ptCi, const uint16_t spCellNum, const cgi_type &cgi,
    const uint8_t gnbIdLength, const bool noPrbUsage, caCellInfo_type &rCellInfoOut)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (ERROR == VLIB_FillCaCellInfo(ptCi, spCellNum, cgi, gnbIdLength, rCellInfoOut))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "VLIB_FillCaCellInfo ERROR for ci(%llu)!\n", 1ULL * cgi.ci);
        return ERROR;
    }

    if (PccMode_Slb == ptCi->pccData.pccMode)
    {
        FnVCCB_FillSliceAvailableCapacityDl(ptCi, spCellNum, cgi, &rCellInfoOut);
        return GOOD;
    }

    if (noPrbUsage)
    {
        return GOOD;
    }

    FnVCCB_McoRecBwWithPrbCapacityIfEnabled(ptCi, spCellNum, cgi, gnbIdLength, rCellInfoOut);
    return GOOD;
}

/**
 * @brief   MCO: Get number of CC per band. Input elements should be grouped per band. Returns number of bands.
 */
template <typename InputIterator, typename OutputIterator>
std::size_t FnVCCB_McoGetNumOfCcPerBand(InputIterator first, InputIterator last, OutputIterator result)
{
    AUTO_TRACE_FUNC;

    std::size_t perBandCnt = 0;
    if (first == last)
    {
        return perBandCnt;
    }

    uint16_t prevBand = first->frequencyBand;
    *result = 1;

    for (++first; first != last; ++first)
    {
        // Check if processing new band
        if (prevBand != first->frequencyBand)
        {
            prevBand = first->frequencyBand;
            ++perBandCnt;
            ++result;
            *result = 0;  // init
        }
        ++(*result);
    }
    ++perBandCnt;
    return perBandCnt;
}

/**
 * @brief   MCO: Iterate over bands and create contiguous CC groups
 */
template <typename CellInfoIterator, typename FnSetCcInfo>
void FnVCCB_McoCreateContigCcGroupsPerBand(CellInfoIterator cellInfoBegin, const CellInfoIterator cellInfoEnd,
    mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBandOut, FnSetCcInfo fnSetCcInfo)
{
    AUTO_TRACE_FUNC;

    // Get Number of Cells per band
    std::size_t cellNumPerBandTab[static_cast<uint32_t>(std::distance(cellInfoBegin, cellInfoEnd))];
    std::size_t *cellNumPerBandBegin = cellNumPerBandTab;
    const std::size_t *cellNumPerBandEnd =
        cellNumPerBandBegin + FnVCCB_McoGetNumOfCcPerBand(cellInfoBegin, cellInfoEnd, cellNumPerBandTab);

    for (; cellNumPerBandEnd != cellNumPerBandBegin; ++cellNumPerBandBegin)
    {
        uint8_t grpIdCurr = 0;
        CellInfoIterator cellInfoPrevIt = cellInfoBegin;

        // Allocate output vectors for a band
        mcoBand2mcoCcInfoVecMap_type::mapped_type &ccInfoVecs =
            ccInfoVecPerBandOut
                .insert(mcoBand2mcoCcInfoVecMap_type::value_type(
                    cellInfoBegin->frequencyBand, mcoBand2mcoCcInfoVecMap_type::mapped_type {
                        mcoCcInfoVec_type(*cellNumPerBandBegin),
                        mcoSeAdjustedBwPerCcVec_type(*cellNumPerBandBegin)
                        }
                    ))
                .first->second;

        // Insert first cellInfo to first group
        fnSetCcInfo(ccInfoVecs.ccInfoVec[0], *cellInfoBegin, grpIdCurr);
        ++cellInfoBegin;

        // Divide cells into contiguous groups
        for (std::size_t cellNum = 1; cellNum < *cellNumPerBandBegin; ++cellNum, ++cellInfoPrevIt, ++cellInfoBegin)
        {
            if (GOOD != VLIB_CheckCaCellContiguous(*cellInfoPrevIt, *cellInfoBegin, cellInfoBegin->frequencyBand))
            {
                // Make new group
                grpIdCurr++;
            }

            // Insert a cellInfo to a group
            fnSetCcInfo(ccInfoVecs.ccInfoVec[cellNum], *cellInfoBegin, grpIdCurr);
        }
    }
}

/**
 * @brief   MCO: Decides if carrier aggregation is available for spCell candidate
 *
 * @param   ptCi                       : call information / callInfo_type
 * @param   pSpCell                    : pointer to spCell candidate cellInfo
 * @param   spCellPrimaryFrequencyBand : selected spcell candidate primary band
 * @param   spCellAltFrequencyBand     : selected spcell candidate alt band
 * @return  GOOD/BREAK/ERROR
 */
int16_t FnVCCB_McoIsCaAvailableForSpcellCandidate(callInfo_type *ptCi, VccbCellInfo_type *pSpCell, uint16_t spCellPrimaryFrequencyBand, uint16_t spCellAltFrequencyBand)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pSpCell);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    VCCB_CHECK_E_RANGE_AND_RETURN(spCellPrimaryFrequencyBand - 1, MAX_NUM_NR_BAND);
    VCCB_CHECK_E_RANGE_AND_RETURN(spCellAltFrequencyBand, MAX_NUM_NR_BAND + 1);
    VCCB_CHECK_E_RANGE_AND_RETURN(pSpCell->endPointF1Index, MAX_GNB_DU_PER_GNB_CU_CP);

    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (CI_no_use == pSpCell->cuColocCellInfo.colocCellInfoUsage)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] colocCellInfoUsage is disabled\n");
        return BREAK;
    }

    if (!IS_CA_AVAILABLE(ptCi, pSpCell->nrCarrierAggregationInfo.caAvailable))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] caAvailable off\n");
        return BREAK;
    }

    if (CaOperation_Off == pGnb->carrierAggregationInfo.bandOperationMode[spCellPrimaryFrequencyBand - 1].caOperationMode)
    {
        if (BAND_NOT_FOUND == spCellAltFrequencyBand)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] CA is off for spCell primary band(%u)\n", spCellPrimaryFrequencyBand);
            return BREAK;
        }

        if (CaOperation_Off == pGnb->carrierAggregationInfo.bandOperationMode[spCellAltFrequencyBand - 1].caOperationMode)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] CA is off for spCell primary band(%u) and alt band(%u)\n",
                    spCellPrimaryFrequencyBand, spCellAltFrequencyBand);
            return BREAK;
        }
    }

    if (ci_overload == pGnb->gnbDu[pSpCell->endPointF1Index].overloadStatus)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] DU is overloaded\n");
        return BREAK;
    }

    const uint8_t caIndex = VCCM_GetMatchingCaIndex(ptCi, spCellPrimaryFrequencyBand);
    const int8_t caUsage = (MAX_NR_CA_CONTROL_ENTRIES > caIndex) ?
            pGnb->carrierAggregationInfo.nrCaControlEntries[caIndex].operation.caUsage :
            static_cast<int8_t>(caUsage_NoControl);

    if (caUsage_Off == caUsage)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] caIndex(%u) caUsage_Off \n", caIndex);
        return BREAK;
    }

    return GOOD;
}

double FnVCCB_GetTsmValueSE(callInfo_type *ptCi, uint16_t cellNum, uint8_t rsrp)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, INVALID_SE_VALUE);
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(cellNum, INVALID_SE_VALUE);
    VccbCellInfo_type *const ptCell = &CELLINFO[cellNum];
    const trafficSteeringConfig_type &config = ptCell->tsmConfig;

    if (config.state != tsmState_Enable || FOO.VF_TSM_TrafficSteeringConfiguration == FALSE || config.configuredIndex >= MAX_TSM_CONFIG_NUM)
    {
        VCCB_PRINT_LOG_CA_TSM(ptCi, "[TSM] SE not active - FOO:(%u), CellNum:(%u) - State:(%u), index:(%u)\n", FOO.VF_TSM_TrafficSteeringConfiguration, cellNum, config.state, config.configuredIndex);
        return INVALID_SE_VALUE;
    }

    const trafficSteeringConfigEntry_type *pTsmParam= &config.configEntry[config.configuredIndex];

    if (pTsmParam->usage == CI_no_use ||
        pTsmParam->min < 0 || pTsmParam->min > 100.000 ||
        pTsmParam->max < 0 || pTsmParam->max > 100.000 ||
        pTsmParam->variableA < 0 || pTsmParam->variableA > 100.000 ||
        pTsmParam->variableB < 0 || pTsmParam->variableB > 100.000 ||
        pTsmParam->variableC < 0 || pTsmParam->variableC > 100.000 ||
        pTsmParam->variableD < 0 || pTsmParam->variableD > 100.000)
    {
        VCCB_PRINT_LOG_CA_TSM(ptCi, "[TSM] Invalid SE wrong parameter - cellNum(%u), index(%u)\n", cellNum, config.configuredIndex);
        return INVALID_SE_VALUE;
    }

    struct Threshold
    {
        uint16_t rsrpRangeStart;
        uint16_t rsrpRangeEnd;
        double min;
        double max;
    };
    const Threshold thresholds[] = {
        {0, 36, pTsmParam->min, pTsmParam->min},
        {36, 46, pTsmParam->min, pTsmParam->variableA},
        {46, 56, pTsmParam->variableA, pTsmParam->variableB},
        {56, 66, pTsmParam->variableB, pTsmParam->variableC},
        {66, 76, pTsmParam->variableC, pTsmParam->variableD},
        {76, 86, pTsmParam->variableD, pTsmParam->max},
        {86, 128, pTsmParam->max, pTsmParam->max}           // 86 <= rsrp <= 127
    };
    auto roundTo3DecimalPlaces = [](double value) { return floor (value * 1000.0) / 1000.0; };
    for (const auto &threshold : thresholds)
    {
        if (threshold.rsrpRangeStart <= rsrp && rsrp < threshold.rsrpRangeEnd)
        {
            double fraction = static_cast<double>(rsrp - threshold.rsrpRangeStart) / 10.000;
            double value = threshold.min + fraction * (threshold.max - threshold.min);
            VCCB_PRINT_LOG_CA_TSM(ptCi, "[TSM] cellNum/rsrp/rsrpStart/rsrpEnd/min/max/fraction/value(%d/%d/%d/%d/%f/%f/%f/%f)\n", cellNum, rsrp, threshold.rsrpRangeStart, threshold.rsrpRangeEnd, threshold.min, threshold.max, fraction, value);
            return roundTo3DecimalPlaces(value);
        }
    }

    return INVALID_SE_VALUE;
}

#ifdef NEW_HOST_SIM
double FnVCCB_GetTsmValueSEMock(const callInfo_type &rCall, const CellNum_type cellNum, uint8_t rsrp)
{
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(cellNum, INVALID_SE_VALUE);

    constexpr uint16_t thresholds[] = { 36, 46, 56, 66, 76, 86, 128 };
    VccbCellInfo_type &rCell = CELLINFO[cellNum];
    if (!FOO.VF_TSM_TrafficSteeringConfiguration || !rCell.mockTrafficSteeringConfig.enabled)
    {
        VCCB_PRINT_CALL_COMMENT(&rCall, "SE not active - FOO:(%u), CellNum:(%u) - State:(%u)\n", 1, cellNum, rCell.mockTrafficSteeringConfig.enabled);
        return INVALID_SE_VALUE;
    }

    if (rCell.mockTrafficSteeringConfig.variableA == 0.0 &&
        rCell.mockTrafficSteeringConfig.variableB == 0.0 &&
        rCell.mockTrafficSteeringConfig.variableC == 0.0 &&
        rCell.mockTrafficSteeringConfig.variableD == 0.0)
    {
        return INVALID_SE_VALUE;
    }

    if (rsrp < thresholds[0])
    {
        return rCell.mockTrafficSteeringConfig.min;
    }
    else if (rsrp < thresholds[1])
    {
        return rCell.mockTrafficSteeringConfig.min +
                (static_cast<double>((rsrp - thresholds[0])) / 10) *
                (rCell.mockTrafficSteeringConfig.variableA - rCell.mockTrafficSteeringConfig.min);
    }
    else if (rsrp < thresholds[2])
    {
        return rCell.mockTrafficSteeringConfig.variableA +
                (static_cast<double>((rsrp - thresholds[1])) / 10) *
                (rCell.mockTrafficSteeringConfig.variableB - rCell.mockTrafficSteeringConfig.variableA);
    }
    else if (rsrp < thresholds[3])
    {
        return rCell.mockTrafficSteeringConfig.variableB +
                (static_cast<double>((rsrp - thresholds[2])) / 10) *
                (rCell.mockTrafficSteeringConfig.variableC - rCell.mockTrafficSteeringConfig.variableB);
    }
    else if (rsrp < thresholds[4])
    {
        return rCell.mockTrafficSteeringConfig.variableC +
                (static_cast<double>((rsrp - thresholds[3])) / 10) *
                (rCell.mockTrafficSteeringConfig.variableD - rCell.mockTrafficSteeringConfig.variableC);
    }
    else if (rsrp < thresholds[5])
    {
        return rCell.mockTrafficSteeringConfig.variableD +
                (static_cast<double>((rsrp - thresholds[4])) / 10) *
                (rCell.mockTrafficSteeringConfig.max - rCell.mockTrafficSteeringConfig.variableD);
    }
    else if (rsrp < thresholds[6])
    {
        return rCell.mockTrafficSteeringConfig.max;
    }
    else
    {
        return 1.0;
    }
}
#endif

/**
 * @brief   MCO: Recalculate Cell BW using cell signal quality.
 *          isValid() returns true if SE value was valid and conditions met, false otherwise.
            recalculate() if SE value is valid returns BW recalculated with acquired SE value else returns input BW.
 **/
class VCCB_TsmSeValueAcquirer
{
protected:
    callInfo_type &rCall;
    const cgi_type &cgi;
    double seValue;
public:
    VCCB_TsmSeValueAcquirer(callInfo_type &rCallIn, const uint16_t cellNum, const cgi_type &cgi, const uint8_t rsrp);
    bool isValid() const { return (INVALID_SE_VALUE != seValue); }
    uint32_t recalculate(const uint16_t bwIn) const;
};

VCCB_TsmSeValueAcquirer::VCCB_TsmSeValueAcquirer(callInfo_type &rCallIn, const uint16_t cellNum, const cgi_type &rCgiIn,
        const uint8_t rsrp):
        rCall(rCallIn),
        cgi(rCgiIn),
        seValue(INVALID_SE_VALUE)
{
    AUTO_TRACE_FUNC;

    if (PccMode_Slb == rCall.pccData.pccMode)
    {
        VCCB_PRINT_CALL_COMMENT(&rCall, "[PCC][FM] Compute SE for ci(%llu) - skip for SLB!\n", 1ULL * cgi.ci);
        return;
    }

    if (MAX_CELL_NUM_VCCB <= cellNum)
    {
        VCCB_PRINT_CALL_COMMENT(&rCall, "[PCC][FM] Compute SE for ci(%llu) - not intra-CU cell!\n", 1ULL * cgi.ci);
        return;
    }

    if (UNKNOWN_RSRP == rsrp)
    {
        VCCB_PRINT_CALL_COMMENT(&rCall, "[PCC][FM] Compute SE for ci(%llu) - RSRP not available!\n", 1ULL * cgi.ci);
        return;
    }

#if defined(NEW_HOST_SIM) && !defined(IPC_TEST)
    seValue = FnVCCB_GetTsmValueSEMock(rCall, cellNum, rsrp);
#else
    seValue = FnVCCB_GetTsmValueSE(&rCall, cellNum, rsrp);
#endif
    if (INVALID_SE_VALUE == seValue)
    {
        VCCB_PRINT_CALL_COMMENT(&rCall, "[PCC][FM] Compute SE for ci(%llu) - SE value invalid!\n", 1ULL * cgi.ci);
    }
}

uint32_t VCCB_TsmSeValueAcquirer::recalculate(const uint16_t bwIn) const
{
    AUTO_TRACE_FUNC;

    if (INVALID_SE_VALUE == seValue)
    {
        VCCB_PRINT_CALL_COMMENT(&rCall, "[PCC][FM] Recalculate for ci(%llu) SE(invalid): BW(%u) not adjusted!\n",
                                1ULL * cgi.ci, bwIn);
        return bwIn;
    }
    const uint32_t bwOut = bwIn * static_cast<uint32_t>(seValue * 1000);

    VCCB_PRINT_CALL_COMMENT(&rCall, "[PCC][FM] Recalculate for ci(%llu) using SE(%u): BW-in(%u) => BW-out(%u)\n",
                            1ULL * cgi.ci, static_cast<uint32_t>(seValue * 1000), bwIn, bwOut);
    return bwOut;
}

/**
 * @brief   MCO: Helper function for FnVCCB_McoPrepareContiguousNrCellGroups.
 **/
bool FnVCCB_McoFillBcSelSCellInfo(callInfo_type *ptCi, const uint16_t spCellNum, const mcoBcSelCellInfo_s &pcell,
    const bcIdxArray_type &filteredBcIndexes, const nbrGnbCellInfo_type *const ptNbrGnbInfo,
    const cgi_type &cgi, const uint8_t gnbIdLength, McoAlgoFlags &algoFlags, const uint8_t rsrp,
    mcoBcSelCellInfo_s &rScellOut)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptNbrGnbInfo, false);
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, false);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (algoFlags.ulOnlyMode && IS_NBR_SDLCELL(ptNbrGnbInfo))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO][UL ONLY MODE] SDL scell ci(%llu) rejected!\n", 1ULL * cgi.ci);
        return false;
    }

    if (GOOD != VLIB_FillCaCellInfoForMco(ptCi, spCellNum, cgi, gnbIdLength, algoFlags.initialFmPcc, rScellOut))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] Error when filling SCell ci(%llu) CA info!\n", 1ULL * cgi.ci);
        return false;
    }

    auto checkCellBasedOnPccMode =
        [&algoFlags] (callInfo_type &rCall, const mcoBcSelCellInfo_s &rPcell, const mcoBcSelCellInfo_s &rScell, const bcIdxArray_type &filteredBcIdxs)
        {
            if (algoFlags.initialFmPcc && algoFlags.checkCarrierOnly)
            {
                return VLIB_IsCarrierEligibleForCA(&rCall, &rPcell, &rScell, filteredBcIdxs);
            }
            return VLIB_IsCellEligibleForCA(&rCall, &rPcell, &rScell, filteredBcIdxs);
        };

    rScellOut.altBand = BAND_NOT_FOUND;

    const bool isPriBandEligible = (GOOD == checkCellBasedOnPccMode(*ptCi, pcell, rScellOut, filteredBcIndexes));
    if (false == isPriBandEligible)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] SCell ci(%llu) primary band(%u) not eligible!\n",
            1ULL * cgi.ci, rScellOut.frequencyBand);
    }

    auto checkMfbi = [&]() -> bool
    {
        if ((true == algoFlags.mfbiCheck) && (1 < rScellOut.bandListNum) && (rScellOut.bandList[0] != rScellOut.bandList[1]))
        {
            mcoBcSelCellInfo_s tmpCellInfo = rScellOut;
            tmpCellInfo.frequencyBand = rScellOut.bandList[1];
            if (GOOD != checkCellBasedOnPccMode(*ptCi, pcell, tmpCellInfo, filteredBcIndexes))
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] SCell ci(%llu) MFBI band(%u) not eligible!\n",
                    1ULL * cgi.ci, tmpCellInfo.frequencyBand);
                return isPriBandEligible;
            }

            if (isPriBandEligible)
            {
                rScellOut.altBand = rScellOut.bandList[1];
                return true;
            }

            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] SCell ci(%llu) MFBI band(%u) set as primary.\n",
                1ULL * cgi.ci, tmpCellInfo.frequencyBand);
            rScellOut.frequencyBand = rScellOut.bandList[1];
            return true;
        }

        return isPriBandEligible;
    };

    if (false == checkMfbi())
    {
        return false;
    }

    if ((false == algoFlags.initialFmPcc) && static_cast<bool>(pGnb->multiCarrierOperation.fullMeasureBasedPccChange))
    {
        const uint16_t cellNum = VLIB_GetCellNumBasedOnCgi(ptCi, cgi, pGnb->globalGnbId.gnbId.idLength);
        VCCB_TsmSeValueAcquirer cellTsmSeValue(*ptCi, cellNum, cgi, rsrp);
        if (!cellTsmSeValue.isValid())
        {
            algoFlags.useSe = false;
        }
        rScellOut.seAdjustedBw = cellTsmSeValue.recalculate(rScellOut.mcoBwDl);
        // Apply Multiple Channel BW info in advance
        rScellOut.seAdjustedAltBandBw =
            ((BAND_NOT_FOUND != rScellOut.mcoMChAltBand) ? cellTsmSeValue.recalculate(rScellOut.mcoMChAltBandBwDl) : 0);
    }

    return true;
}

/**
 * @brief   MCO: Helper function for FnVCCB_McoPrepareContiguousNrCellGroups.
 **/
bool FnVCCB_McoFillBcSelSCellInfoByCgi(callInfo_type *ptCi, const uint16_t spCellNum, const mcoBcSelCellInfo_s &pcell,
    const bcIdxArray_type &filteredBcIndexes, const cgi_type &cgi, const uint8_t gnbIdLength, McoAlgoFlags &algoFlags,
    const uint8_t rsrp, mcoBcSelCellInfo_s &rScellOut)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    uint16_t scellCellNum = MAX_CELL_NUM_VCCB;
    const nbrGnbCellInfo_type *ptNbrGnbInfo = nullptr;
    if (GOOD == VLIB_FindCellNumFromCGI(cgi, &scellCellNum))
    {
        if (VCCM_CheckCellOverloadStatus(ptCi, scellCellNum) == BREAK)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] SCell ci(%llu) is overloaded, skipping!\n", 1ULL * cgi.ci);
            return false;
        }
        ptNbrGnbInfo = &CELLINFO[scellCellNum].intraGnbNbrInfo;
    }
    else
    {
        ptNbrGnbInfo = VLIB_GetNbrGnbCellInfoBasedOnCgi(ptCi, cgi, gnbIdLength);
        if (nullptr == ptNbrGnbInfo)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] SCell ci(%llu): Fail to get nbrGnbCellInfo, skipping!\n", 1ULL * cgi.ci);
            return false;
        }
    }

    return FnVCCB_McoFillBcSelSCellInfo(ptCi, spCellNum, pcell, filteredBcIndexes, ptNbrGnbInfo, cgi, gnbIdLength, algoFlags,
        rsrp, rScellOut);
}

/**
 * @brief   MCO: Helper function for FnVCCB_McoPrepareContiguousNrCellGroups.
 **/
bool FnVCCB_McoFillBcSelSCellInfoByNbr(callInfo_type *ptCi, const uint16_t spCellNum, const mcoBcSelCellInfo_s &pcell,
    const bcIdxArray_type &filteredBcIndexes, const nbrCellInfo_type *const ptCellNbr,
    const nbrGnbCellInfo_type *const ptNbrGnbInfo, McoAlgoFlags &algoFlags, const uint8_t rsrp,
    mcoBcSelCellInfo_s &rScellOut)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptCellNbr, false);
    VALID_E_POINT_CHECK_RET_VAL(ptNbrGnbInfo, false);

    VCCB_CHECK_VALID_CELLNUM_RET_VAL(spCellNum, false);

    const VccbCellInfo_type *const pSpCell = &CELLINFO[spCellNum];

    if (N_EQUIP == ptCellNbr->status)
    {
        return false;
    }

    VCCB_CHECK_E_RANGE_AND_VAL(pSpCell->gnbNum, MAX_GNB_PER_SYS, false);
    VccbGnbInfo_type *const pGnb = &GNBINFO[pSpCell->gnbNum];

    cgi_type cgi;
    cgi.ci = VLIB_GnbIdCellId2NrCellId(&ptCellNbr->targetGnbId.gnbId, ptCellNbr->targetCellId);
    cgi.plmn = ptCellNbr->targetGnbId.plmn;

    if (VCCB_IS_INTRA_GNB_NEIGHBOR_FOR_CELL_NBR(pGnb, ptCellNbr))
    {
        uint16_t scellCellNum = MAX_CELL_NUM_VCCB;
        VCCB_GET_INTRA_GNB_NBR_CELLNUM_FROM_CELL_IDENTITY(pGnb, ptCellNbr->targetCellId, scellCellNum, MAX_CELL_NUM_VCCB);
        VCCB_CHECK_VALID_CELLNUM_RET_VAL(scellCellNum, false);

        if (VCCM_CheckCellOverloadStatus(ptCi, scellCellNum) == BREAK)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] SCell ci(%llu) is overloaded, skipping!\n", 1ULL * cgi.ci);
            return false;
        }
    }

    return FnVCCB_McoFillBcSelSCellInfo(ptCi, spCellNum, pcell, filteredBcIndexes, ptNbrGnbInfo, cgi,
        ptCellNbr->targetGnbId.gnbId.idLength, algoFlags, rsrp, rScellOut);
}

/**
 * @brief   MCO: Add colocated SCells to cellInfoTabOut.
 */
void FnVCCB_McoAddBcSelCellInfoColocated(callInfo_type *ptCi, const uint16_t spCellNum, const mcoBcSelCellInfo_s &pcell,
    McoAlgoFlags &algoFlags, const bcIdxArray_type &filteredBcIndexes,
    mcoBcSelCellInfo_s cellInfoTabOut[MAX_COLOCCELL + 1], std::size_t &rCellInfoCnt)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    VCCB_CHECK_VALID_CELLNUM_VOID(spCellNum);
    VccbCellInfo_type *const pSpCell = &CELLINFO[spCellNum];

    // iterate over cuColocCellInfo and fill SCell info
    for (colocCellEntries_type &rColocCell : pSpCell->cuColocCellInfo.colocCellEntries)
    {
        if (MAX_COLOCCELL < rCellInfoCnt)
        {
            return;
        }

        if ((CI_no_use == rColocCell.usage) || (TRUE != rColocCell.useforNrca))
        {
            continue;
        }

        cgi_type cgi;
        cgi.ci = VLIB_GnbIdCellId2NrCellId(&rColocCell.globalGnbId.gnbId, rColocCell.cellId);
        cgi.plmn = rColocCell.globalGnbId.plmn;
        const uint8_t gnbIdLength = rColocCell.globalGnbId.gnbId.idLength;

        if (false == FnVCCB_McoFillBcSelSCellInfoByCgi(ptCi, spCellNum, pcell, filteredBcIndexes, cgi, gnbIdLength,
                algoFlags, UNKNOWN_RSRP, cellInfoTabOut[rCellInfoCnt]))
        {
            continue;
        }

        rCellInfoCnt++;
    }
}

void FnVCCB_UpdateSeAdjustedBwForCc(mcoBcSelCellInfo_s * cellInfoBegin, const std::size_t cellInfoSize,
    const bool useMultiChBw, mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBandOut)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(cellInfoBegin);

    auto cellInfoEnd = cellInfoBegin + cellInfoSize;
    // Get Number of Cells per band
    std::size_t numOfCcsPerBandTab[cellInfoSize];
    std::size_t *numOfCcsPerBandTabIt = numOfCcsPerBandTab;
    const std::size_t *numOfCcsPerBandSize =
        numOfCcsPerBandTabIt + FnVCCB_McoGetNumOfCcPerBand(cellInfoBegin, cellInfoEnd, numOfCcsPerBandTab);

    for (; numOfCcsPerBandSize != numOfCcsPerBandTabIt; ++numOfCcsPerBandTabIt)
    {
        mcoSeAdjustedBwPerCcVec_type &seAdjustedBws = ccInfoVecPerBandOut[cellInfoBegin->frequencyBand].seAdjustedBwVec;

        for (std::size_t ccIndex = 0; ccIndex < *numOfCcsPerBandTabIt; ++ccIndex, ++cellInfoBegin)
        {
            seAdjustedBws[ccIndex].priBandBw = cellInfoBegin->seAdjustedBw;
            seAdjustedBws[ccIndex].altBandBw = (useMultiChBw ? cellInfoBegin->seAdjustedAltBandBw : cellInfoBegin->seAdjustedBw);
        }
    }
}

typedef void (*FnVCCB_McoScellAppender_type)(callInfo_type *ptCi, const uint16_t spCellNum, const mcoBcSelCellInfo_s &pcell,
    McoAlgoFlags &algoFlags, const bcIdxArray_type &filteredBcIndexes,
    mcoBcSelCellInfo_s cellInfoTabOut[MAX_COLOCCELL + 1], std::size_t &rCellInfoCnt);

/**
 * @brief   MCO: Prepares contiguous NR cell groups.
 *          SCells are added by given function ptFnScellAppender.
 */
void FnVCCB_McoPrepareContiguousNrCellGroups(
    callInfo_type *ptCi, uint16_t spCellNum, const uint8_t spCellRsrp, McoAlgoFlags &algoFlags,
    FnVCCB_McoScellAppender_type ptFnScellAppender, mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBandOut, uint16_t &rPCellBandOut)
{
    AUTO_TRACE_FUNC;

    ccInfoVecPerBandOut.clear();
    rPCellBandOut = BAND_NOT_FOUND;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptFnScellAppender);
    VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    VCCB_CHECK_VALID_CELLNUM_VOID(spCellNum);
    VccbCellInfo_type *const pSpCell = &CELLINFO[spCellNum];

    VCCB_CHECK_E_RANGE_AND_VOID(pSpCell->endPointF1Index, MAX_GNB_DU_PER_GNB_CU_CP);

    mcoBcSelCellInfo_s cellInfoTab[MAX_COLOCCELL + 1];
    std::size_t cellInfoCnt = 1;

    mcoBcSelCellInfo_s &pcell = cellInfoTab[0];
    cgi_type cgi = FnVCCB_GetNrcgiFromCellNum(spCellNum);
    uint8_t gnbIdLength = pGnb->globalGnbId.gnbId.idLength;

    if (GOOD != VLIB_FillCaCellInfoForMco(ptCi, spCellNum, cgi, gnbIdLength, algoFlags.initialFmPcc, pcell))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[MCO] Error when filling pcell ci(%llu) CA info!\n", 1ULL * cgi.ci);
        return;
    }
    pcell.altBand = BAND_NOT_FOUND;

    if (UNKNOWN_RSRP != spCellRsrp)
    // RSRP is valid only for final PCC FM
    {
        VCCB_TsmSeValueAcquirer cellTsmSeValue(*ptCi, spCellNum, cgi, spCellRsrp);
        if (!cellTsmSeValue.isValid())
        {
            algoFlags.useSe = false;
        }
        pcell.seAdjustedBw = cellTsmSeValue.recalculate(pcell.mcoBwDl);
        // Apply Multiple Channel BW info in advance
        pcell.seAdjustedAltBandBw =
            ((BAND_NOT_FOUND != pcell.mcoMChAltBand) ? cellTsmSeValue.recalculate(pcell.mcoMChAltBandBwDl) : 0);
    }
    else
    {
        // For simplicity of later operations
        pcell.seAdjustedBw = pcell.mcoBwDl;
        // Apply Multiple Channel BW info in advance
        pcell.seAdjustedAltBandBw = ((BAND_NOT_FOUND != pcell.mcoMChAltBand) ? pcell.mcoMChAltBandBwDl : 0);
    }

    bcIdxArray_type filteredBcIndexes;
    if (GOOD != VLIB_getBcIndexesUsingPrioBasedScellSelect(ptCi, spCellNum, pcell.frequencyBand, filteredBcIndexes))
    {
        filteredBcIndexes.clear();
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] No Valid BC indexes found for PCell band(%u).\n", pcell.frequencyBand);
    }
    else
    {
        std::sort(filteredBcIndexes.begin(), filteredBcIndexes.end());
    }

    rPCellBandOut = pcell.frequencyBand;
    const uint32_t pcellNrArfcnDl = pcell.nrArfcnDl;

    if ((true == algoFlags.mfbiCheck) && (1 < pcell.bandListNum) && (pcell.bandList[0] != pcell.bandList[1]))
    {
        pcell.altBand = pcell.bandList[1];

        bcIdxArray_type filteredBcIndexesAltBand;
        if (GOOD != VLIB_getBcIndexesUsingPrioBasedScellSelect(ptCi, spCellNum, pcell.bandList[1], filteredBcIndexesAltBand))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] No Valid BC indexes found for PCell alt band(%u).\n", pcell.bandList[1]);
        }
        else
        {
            std::sort(filteredBcIndexesAltBand.begin(), filteredBcIndexesAltBand.end());
            uint32_t filteredBcIndexesUnion[filteredBcIndexes.size() + filteredBcIndexesAltBand.size()];
            uint32_t *filteredBcIndexesUnionEndIt = std::set_union(filteredBcIndexes.begin(), filteredBcIndexes.end(),
                filteredBcIndexesAltBand.begin(), filteredBcIndexesAltBand.end(), filteredBcIndexesUnion);

            filteredBcIndexes.clear();
            for (uint32_t *it = filteredBcIndexesUnion; it != filteredBcIndexesUnionEndIt; ++it)
            {
                filteredBcIndexes.push_back(*it);
            }
        }
    }

    if (GOOD != FnVCCB_McoIsCaAvailableForSpcellCandidate(ptCi, pSpCell, pcell.frequencyBand, pcell.altBand))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] CA not available for spCellNum(%u)\n", spCellNum);
    }
    else if (filteredBcIndexes.empty())
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] No Valid BC indexes found for PCell.\n");
    }
    else
    {
        ptFnScellAppender(ptCi, spCellNum, pcell, algoFlags, filteredBcIndexes, cellInfoTab, cellInfoCnt);

        // Sort cell list ascending by freq value
        std::sort(cellInfoTab, &cellInfoTab[cellInfoCnt],
            [](const caCellInfo_type &lhs, const caCellInfo_type &rhs)
            {
                return (lhs.nrArfcnDl < rhs.nrArfcnDl);
            });

        // Remove duplicates freq value
        mcoBcSelCellInfo_s *pCellInfoShrunkEnd = std::unique(cellInfoTab, &cellInfoTab[cellInfoCnt],
            [](const mcoBcSelCellInfo_s &lhs, const mcoBcSelCellInfo_s &rhs)
            { return (lhs.nrArfcnDl == rhs.nrArfcnDl); });
        const std::size_t shrunkSize = static_cast<std::size_t>(std::distance(cellInfoTab, pCellInfoShrunkEnd));
        if (cellInfoCnt > shrunkSize)
        {
            VCCB_PRINT_CALL_COMMENT(
                ptCi, "[MCO] colocated NR: removed (%lu) duplicated freq CC!\n", cellInfoCnt - shrunkSize);
            cellInfoCnt = shrunkSize;
        }

        // Sort cell list ascending by band and freq value
        std::sort(cellInfoTab, &cellInfoTab[cellInfoCnt],
            [](const caCellInfo_type &lhs, const caCellInfo_type &rhs)
            {
                return ((lhs.frequencyBand < rhs.frequencyBand) ||
                        ((lhs.frequencyBand == rhs.frequencyBand) && (lhs.nrArfcnDl < rhs.nrArfcnDl)));
            });
    }

    // Check Multiple Channel BW if enabled and if all considered cells have related info
    if (algoFlags.useMultiChBw)
    {
        algoFlags.useMultiChBw = pGnb->multiCarrierOperation.multipleChannelBwUsage &&
            std::all_of(cellInfoTab, cellInfoTab + cellInfoCnt, [](const caCellInfo_type &cell){ return cell.mcoMChPresent; });
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] Multiple Channel BW usage(%u), all cells support(%u) for PCell ci(%llu)\n",
            pGnb->multiCarrierOperation.multipleChannelBwUsage, algoFlags.useMultiChBw, 1ULL * cgi.ci);
    }

    auto fnSetCcInfo = [&rPCellBandOut, &pcellNrArfcnDl, &algoFlags](
                           mcoCcInfo_s &ccInfoOut, const mcoBcSelCellInfo_s &caCellInfoIn, const uint8_t grpIdCurrIn)
    {
        ccInfoOut.mcoBwDl = caCellInfoIn.mcoBwDl;
        ccInfoOut.grpId = grpIdCurrIn;
        ccInfoOut.pcellFlag =
            ((rPCellBandOut == caCellInfoIn.frequencyBand) && (pcellNrArfcnDl == caCellInfoIn.nrArfcnDl));
        ccInfoOut.userValue = caCellInfoIn.ssbArfcn;
        if (algoFlags.useMultiChBw)
        {
            ccInfoOut.altBand = caCellInfoIn.mcoMChAltBand;
            ccInfoOut.altBandMcoBwDl = caCellInfoIn.mcoMChAltBandBwDl;
        }
        else
        {
            ccInfoOut.altBand = caCellInfoIn.altBand;
            ccInfoOut.altBandMcoBwDl = caCellInfoIn.mcoBwDl;
        }
    };

    // iterate over bands and create contiguous CC groups
    FnVCCB_McoCreateContigCcGroupsPerBand(cellInfoTab, cellInfoTab + cellInfoCnt, ccInfoVecPerBandOut, fnSetCcInfo);
    if (!algoFlags.initialFmPcc && pGnb->multiCarrierOperation.fullMeasureBasedPccChange)
    {
        FnVCCB_UpdateSeAdjustedBwForCc(cellInfoTab, cellInfoCnt, algoFlags.useMultiChBw, ccInfoVecPerBandOut);
    }

    // print output for debug
    for (mcoBand2mcoCcInfoVecMap_type::value_type &kv : ccInfoVecPerBandOut)
    {
        mcoCcInfoVec_type &ccInfoVec = kv.second.ccInfoVec;

        VCCB_PRINT_CALL_COMMENT(ptCi, "====== [MCO] colocated NR CC groups: band(%u) ======\n", kv.first);

        for (std::size_t ccIdx = 0; ccIdx < ccInfoVec.size(); ccIdx++)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "CC: ccIdx(%lu) contGrpId(%u) ssbArfcn(%u) BW_%s(%u) isPCell(%u) altBand(%u) altBW_DL(%u)\n",
                ccIdx, ccInfoVec[ccIdx].grpId, ccInfoVec[ccIdx].userValue, algoFlags.ulOnlyMode ? "UL" : "DL",
                ccInfoVec[ccIdx].mcoBwDl, ccInfoVec[ccIdx].pcellFlag, ccInfoVec[ccIdx].altBand,
                ccInfoVec[ccIdx].altBandMcoBwDl);
        }
    }
}

/**
 * @brief   MCO: Prepares contiguous NR cell groups for LTE access and PCC Change from coloc list.
 *
 * Assumptions:
 * - CA operation (foo, mode, etc.) for selected PCell is already verified
 */
void FnVCCB_McoPrepareColocContiguousNrCellGroups(
    callInfo_type *ptCi, uint16_t spCellNum, McoAlgoFlags &algoFlags,
    mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBandOut, uint16_t &rPCellBandOut)
{
    AUTO_TRACE_FUNC;
    FnVCCB_McoPrepareContiguousNrCellGroups(ptCi, spCellNum, UNKNOWN_RSRP, algoFlags, FnVCCB_McoAddBcSelCellInfoColocated,
        ccInfoVecPerBandOut, rPCellBandOut);
}

void FnVCCB_McoInitPscellCcInfoTab(mcoPscellCcInfo_s ccInfoTabOut[MAX_PCC_PSCELL_BANDS])
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ccInfoTabOut);

    for (uint16_t ccIdx = 0; MAX_PCC_PSCELL_BANDS > ccIdx; ccIdx++)
    {
        mcoPscellCcInfo_s &ccInfo = ccInfoTabOut[ccIdx];
        ccInfo.band = BAND_NOT_FOUND;
        ccInfo.nbrIdx = MAX_NBR_PER_CELL;
        ccInfo.ccInfo.mcoBwDl = 0;
    }
}

inline bool FnVCCB_McoIsPscellCcInfoValid(const mcoPscellCcInfo_s &ccInfo)
{
    AUTO_TRACE_FUNC;
    return ((BAND_NOT_FOUND != ccInfo.band) && (0 != ccInfo.ccInfo.mcoBwDl));
}

void FnVCCB_McoUpdatePscellCcInfoTab(mcoPscellCcInfo_s ccInfoTabOut[MAX_PCC_PSCELL_BANDS],
    const mcoPscellCcInfo_s &ccInfoCandidate)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ccInfoTabOut);

    if (false == FnVCCB_McoIsPscellCcInfoValid(ccInfoCandidate))
    {
        return;
    }

    uint16_t minBwDlIdx = 0;
    for (uint16_t ccIdx = 0; MAX_PCC_PSCELL_BANDS > ccIdx; ccIdx++)
    {
        mcoPscellCcInfo_s &ccInfo = ccInfoTabOut[ccIdx];

        // try to find entry with the same band
        if (ccInfoCandidate.band == ccInfo.band)
        {
            if (ccInfoCandidate.ccInfo.mcoBwDl > ccInfo.ccInfo.mcoBwDl)
            {
                // update with better candidate
                ccInfo = ccInfoCandidate;
            }
            return;
        }

        // store min value
        if (ccInfo.ccInfo.mcoBwDl < ccInfoTabOut[minBwDlIdx].ccInfo.mcoBwDl)
        {
            minBwDlIdx = ccIdx;
        }
    }

    // entry with the same band not found - update worst entry with better candidate
    if (ccInfoCandidate.ccInfo.mcoBwDl > ccInfoTabOut[minBwDlIdx].ccInfo.mcoBwDl)
    {
        ccInfoTabOut[minBwDlIdx] = ccInfoCandidate;
    }

    return;
}

/********************************************************************************************
 * @brief           Check Slice Aware
 *
 * @param[in]       ptCi        :        call information / callInfo_type
 * @param[in]       spCellNum   :        primary cell num
 * @param[in]       rCgi        :        CGI of a cell for slice checking.
 * @param[in]       neighbourIdx :       Neighbour index of a cell for slice checking (MAX_NBR_PER_CELL if unknown)
 * @return          status      :        GOOD - correct slice found, BREAK/ERROR - correct slice not found / int16_t
 ********************************************************************************************/
int16_t VCCM_CheckSliceAwareForCellByCgi(callInfo_type *ptCi, uint16_t spCellNum, const cgi_type &rCgi, uint16_t neighbourIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    VCCB_CHECK_VALID_CELLNUM_ERROR(spCellNum);
    const VccbCellInfo_type *const pCell = &CELLINFO[spCellNum];

    const uint16_t cellIdentity = VLIB_NrCellId2CellId(pGnb->globalGnbId.gnbId.idLength, rCgi.ci);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellIdentity, MAX_CELL_IDENTITY);

    const uint32_t gnbId = VLIB_NrCellId2GnbId(pGnb->globalGnbId.gnbId.idLength, rCgi.ci);
    if (VCCB_IS_SAME_GNB(gnbId, rCgi.plmn.longId, ptCi->gnbNum))
    {
        const uint16_t cellNum = pGnb->env.cellNum[cellIdentity];

        for (callPDUSessInfo_type &rPduSess : ptCi->pduSess)
        {
            if (CI_use != rPduSess.usage)
            {
                continue;
            }

            if (GOOD == VLIB_CheckifSupportedSNSSAIList(ptCi, rPduSess.sNssai, ptCi->ueInfo.servedPlmn.longId, cellNum))
            {
                return GOOD;
            }
        }
    }
    else
    {
        if (MAX_NBR_PER_CELL <= neighbourIdx)
        {
            for (neighbourIdx = 0; neighbourIdx < MAX_NBR_PER_CELL; ++neighbourIdx)
            {
                if ((pCell->Nbr[neighbourIdx].status == EQUIP) && (pCell->Nbr[neighbourIdx].targetCellId == cellIdentity))
                {
                    break;
                }
            }
        }
        VCCB_CHECK_E_RANGE_AND_RETURN(neighbourIdx, MAX_NBR_PER_CELL);

        candidateNbrInformation_type candidateCell;
        if (ERROR == VCCM_FillCandidateCellInfo_NR(ptCi, spCellNum, neighbourIdx, &candidateCell))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_FillCandidateCellInfo_NR ERROR!\n");
            return ERROR;
        }

        for (callPDUSessInfo_type &rPduSess : ptCi->pduSess)
        {
            if (CI_use != rPduSess.usage)
            {
                continue;
            }

            if (GOOD == VLIB_CheckifSupportedSNSSAIListForInterGnb(
                            ptCi, rPduSess.sNssai, &candidateCell, ptCi->ueInfo.servedPlmn.longId))
            {
                return GOOD;
            }
        }
    }

    return BREAK;
}


/********************************************************************************************
 * @brief           Fill PSCell CC Info
 *
 * @param[in]       ptCi        :        call information / callInfo_type
 * @param[in]       ptHrl       :        pointer to decompressed handover restriction list
 * @param[in]       spCellNum   :        primary cell num
 * @param[in]       nbrIdx      :        neighbor index of the cell to be checked
 * @param[out]      ccInfoOut   :        component carrier info to be filled
 * @return          status      :        GOOD - cell filled correctly,
 *                                       ERROR - cell was not filled correctly,
 *                                       BREAK - cell was skipped due to being 50 MHz or not equipped
 ********************************************************************************************/
int16_t FnVCCB_McoFillPscellCcInfo(callInfo_type *ptCi, hoRestrictInfo_type *ptHrl, const uint16_t spCellNum, const uint16_t nbrIdx, mcoPscellCcInfo_s &ccInfoOut)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptHrl);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    VCCB_CHECK_VALID_CELLNUM_ERROR(spCellNum);
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_NBR_PER_CELL);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    const VccbCellInfo_type *const pSpCell = &CELLINFO[spCellNum];
    nbrGnbCellInfo_type *pNbrGnbCell = NULL;

    if (N_EQUIP == pSpCell->Nbr[nbrIdx].status)
    {
        return BREAK;
    }

    if (GOOD != getNbrGnbCellByCellNbrIdx(spCellNum, nbrIdx, &pNbrGnbCell))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "[NBR:NRDC %s] servCellNum(%u)'s nbr(idx:%u) was Skipped due to getNbrGnbCellByCellNbrIdx Failure!\n",
            "PCC", spCellNum, nbrIdx);
        return ERROR;
    }

    // 50 MHz cells should be skipped as they are SSB-less
    if (ci_nr_bandwidth_50MHz == pNbrGnbCell->bandwidthDl)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC NRDC] Neighbor Cell BW is 50 MHz, Skipped!\n");
        return BREAK;
    }

    const uint32_t ssbFreq = pNbrGnbCell->ssbArfcn;
    // Check ssbArfcn
    if (MIN_A6_NR_ARFCN > ssbFreq)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC NRDC] gnbNbrCell(servCellNum:%u, nbrIdx:%u) was Skipped due to "
                "Not FR2(%u, expect equal or more than %u) !\n", spCellNum, nbrIdx, pNbrGnbCell->ssbArfcn, MIN_A6_NR_ARFCN);
        return ERROR;
    }

    // Check SSB
    if ((CI_use == pNbrGnbCell->ssbMeasurementConfiguration.usage) && (0 == pNbrGnbCell->ssbMeasurementConfiguration.ssbValue))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC NRDC] spCellNum(%u)'s nbrIdx(%u): No SSB!\n", spCellNum, nbrIdx);
        return ERROR;

    }

    // Same PLMN with current PCell
    if (FALSE == VLIB_CheckNeighborPlmn(ptCi->ueInfo.servedPlmn.longId, pNbrGnbCell))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC NRDC] spCellNum(%u)'s nbrIdx(%u): Served PLMN(%u) not supported!\n",
            spCellNum, nbrIdx, ptCi->ueInfo.servedPlmn.longId);
        return ERROR;
    }

    cgi_type cgi;
    cgi.ci = VLIB_GnbIdCellId2NrCellId(&pNbrGnbCell->globalGnbId.gnbId, pNbrGnbCell->cellId);
    cgi.plmn = pNbrGnbCell->globalGnbId.plmn;
    if (GOOD != VCCM_CheckSliceAwareForCellByCgi(ptCi, spCellNum, cgi, nbrIdx))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC NRDC] spCellNum(%u)'s nbrIdx(%u): Slice not supported!\n",
            spCellNum, nbrIdx);
        return ERROR;
    }

    if ((FnVCCB_Check_isSegmentedUciCall(ptCi)) &&
        (GOOD != FnVCCB_IsTargetRrcUlSegSupportable(ptCi, pNbrGnbCell->globalGnbId)))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC NRDC] spCellNum(%u)'s nbrIdx(%u): Not FnVCCB_IsTargetRrcUlSegSupportable!\n",
            spCellNum, nbrIdx);
        return ERROR;
    }

    XnIdx_type xnIdx = MAX_XN_NBR_PER_GNB;
    measResultNR_type* NO_MEAS_RESULTS = nullptr;
    if (GOOD != FnVCCB_validNrdcPSCellPerNeighborFromMeasResult(ptCi, spCellNum, nbrIdx, ssbFreq,
                    NO_MEAS_RESULTS, ptHrl, &xnIdx, CHECK_PSCELL_FOR_PCC))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC NRDC] spCellNum(%u)'s nbrIdx(%u): ERROR in FnVCCB_validNrdcPSCellPerNeighborFromMeasResult!\n",
            spCellNum, nbrIdx);
        return ERROR;
    }

    caCellInfo_type pscellInfo;
    const uint8_t gnbIdLength = pNbrGnbCell->globalGnbId.gnbId.idLength;
    constexpr bool noPrbUsage_true = true; // PRB will be checked outside the function.
    if (GOOD != VLIB_FillCaCellInfoForMco(ptCi, spCellNum, cgi, gnbIdLength, noPrbUsage_true, pscellInfo))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC NRDC] spCellNum(%u)'s nbrIdx(%u) ci(%llu): fill CA info ERROR!\n",
            spCellNum, nbrIdx, 1ULL * cgi.ci);
        return ERROR;
    }

    uint16_t mcoBwDl = pscellInfo.mcoBwDl;
    if (PccMode_Slb != ptCi->pccData.pccMode)
    {
        const sonNbrPrbRsc_type &sonNbrPrbRsc = pSpCell->cellRscInfo.nbrPrb[nbrIdx];
        if (CI_use == sonNbrPrbRsc.usage)
        {
            if (EffectiveBWOpt_PrbUsage == pGnb->multiCarrierOperation.effectiveBandwidthOption)
            {
                mcoBwDl = static_cast<uint16_t>(sonNbrPrbRsc.dlTotalBandwidth * sonNbrPrbRsc.dlCapacityValue / 100.0);
            }
            else
            {
                mcoBwDl = static_cast<uint16_t>(sonNbrPrbRsc.dlTotalBandwidth);
            }
        }
        else
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[PCC NRDC] spCellNum(%u)'s nbrIdx(%u): sonNbrPrbRsc not available - using cell's BW(%u)!\n",
                spCellNum, nbrIdx, mcoBwDl);
        }
    }

    // fill candidate PSCell CC Info
    ccInfoOut.band = pscellInfo.frequencyBand;
    ccInfoOut.nbrIdx = nbrIdx;
    ccInfoOut.pci = pNbrGnbCell->nrPci;
    ccInfoOut.ccInfo.mcoBwDl = mcoBwDl;
    ccInfoOut.ccInfo.grpId = 0;
    ccInfoOut.ccInfo.pcellFlag = false;
    ccInfoOut.ccInfo.userValue = pNbrGnbCell->ssbArfcn; // ssbArfcn for MO
    ccInfoOut.ccInfo.altBand = BAND_NOT_FOUND;

    return GOOD;
}

/**
 * @brief   MCO: Make NRDC PSCell(s) candidate list (one cell per band) for PCC PCell candidate.
 */
uint16_t FnVCCB_McoMakeNrdcPscellCandidateList(callInfo_type *ptCi, hoRestrictInfo_type *ptHrl, const uint16_t spCellNum,
    mcoPscellCcInfo_s ccInfoTabOut[MAX_PCC_PSCELL_BANDS])
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ZERO(ptCi);
    VALID_E_POINT_CHECK_ZERO(ptHrl);
    VALID_E_POINT_CHECK_ZERO(ccInfoTabOut);
    mcoPscellCcInfo_s ccCandidate;

    if ((false == IS_SUPPORT_NRDC_Yang(spCellNum)) || (false == IS_PCELL_FR1(spCellNum)))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC NRDC] Not supported NRDC spCellNum(%u): yang(%u) FR1(%u)!\n", spCellNum,
            IS_SUPPORT_NRDC_Yang(spCellNum), IS_PCELL_FR1(spCellNum));
        return 0;
    }
    if (IS_NRDC_DISABLED_BY_OVLD(ptCi))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC NRDC] NRDC disabled by overload!\n");
        return 0;
    }
    if (NOT_ALLOW_SN_ADDITION_UE_SIGNATURE(ptCi))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC NRDC] Not allowed by ue-signature. ueSignature(%d) allowSnAdditionFlag(%d)\n",
            ptCi->nrdcScgFailureInfo.ueSignatureFlag, ptCi->nrdcScgFailureInfo.allowSNAdditionUECustomSignature);
        return 0;
    }
    if (FALSE == FnVCCB_CheckAllowedConcurrentNRDCandVoNR(ptCi, spCellNum))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "[PCC NRDC] VoNR is in service but concurrent NRDC and VoNR is not possible spCellNum(%u)!\n", spCellNum);
        return 0;
    }

    FnVCCB_McoInitPscellCcInfoTab(ccInfoTabOut);

    for (uint16_t nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)  // go through all the neighbors
    {
        if (GOOD != FnVCCB_McoFillPscellCcInfo(ptCi, ptHrl, spCellNum, nbrIdx, ccCandidate))
        {
            continue;
        }

        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC NRDC] spCellNum(%u) check PSCell band(%u) ssbArfcn(%u) BW(%u) nbrIdx(%u)\n",
            spCellNum, ccCandidate.band, ccCandidate.ccInfo.userValue, ccCandidate.ccInfo.mcoBwDl, ccCandidate.nbrIdx);

        FnVCCB_McoUpdatePscellCcInfoTab(ccInfoTabOut, ccCandidate);
    }

    uint16_t ccInfoCnt = 0;
    for (; MAX_PCC_PSCELL_BANDS > ccInfoCnt; ccInfoCnt++)
    {
        mcoPscellCcInfo_s &ccInfo = ccInfoTabOut[ccInfoCnt];

        if (false == FnVCCB_McoIsPscellCcInfoValid(ccInfo))
        {
            break;
        }

        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC NRDC] spCellNum(%u) PSCell candidate(%u) band(%u) ssbArfcn(%u) BW(%u) nbrIdx(%u)\n",
            spCellNum, ccInfoCnt, ccInfo.band, ccInfo.ccInfo.userValue, ccInfo.ccInfo.mcoBwDl, ccInfo.nbrIdx);
    }

    return ccInfoCnt;
}

uint16_t FnVCCB_McoMakeNrdcPscellCandidateListForRecalculation(
        callInfo_type *ptCi, hoRestrictInfo_type *ptHrl, const PccCandidateInfo_type * const ptCandidate,
        const uint16_t spCellNum, mcoPscellCcInfo_s ccInfoTabOut[MAX_PCC_PSCELL_BANDS])
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ZERO(ptCi);
    VALID_E_POINT_CHECK_ZERO(ptHrl);
    VALID_E_POINT_CHECK_ZERO(ccInfoTabOut);
    VALID_E_POINT_CHECK_ZERO(ptCandidate);

    constexpr uint64_t NO_PSCELL_MRS_RECEIVED = 0;
    uint16_t psCellCount = 0;

    // No PSCell MRs received
    if (ptCandidate->mrRcvPscellMap == NO_PSCELL_MRS_RECEIVED)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC NRDC][Recalculation] No PSCell MRs received for candidate spCellNum(%d)\n", spCellNum);
        return psCellCount;
    }

    FnVCCB_McoInitPscellCcInfoTab(ccInfoTabOut);

    uint8_t maxResultIndex = MIN(ptCandidate->resultNum & 0x3U, MAX_PCC_RESULTS_PER_CANDIDATE);
    for (uint8_t resultIndex = 0; resultIndex < maxResultIndex; resultIndex++)
    {
        mcoPscellCcInfo_type ccInfo {};
        if (((0x1U << resultIndex) & ptCandidate->mrRcvPscellMap) == 0)
        {
            // MR not received
            continue;
        }

        auto [nbrIdx, pci, ssbArfcn] = ptCandidate->results[resultIndex].pscell;
        if (GOOD != FnVCCB_McoFillPscellCcInfo(ptCi, ptHrl, spCellNum, nbrIdx, ccInfo))
        {
            continue;
        }

        // Verify if the nbr is still the same cell as previously
        if (ccInfo.pci != pci || ccInfo.ccInfo.userValue != ssbArfcn)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                    "[PCC NRDC][Recalculation] Nbr(%d) for candidate spCellNum(%d) changed: before pci(%d), ssbArfcn(%d) vs after pci(%d), ssbArfcn(%d) - SKIP\n",
                    nbrIdx, spCellNum, pci, ssbArfcn, ccInfo.pci, ccInfo.ccInfo.userValue);
            continue;
        }
        FnVCCB_McoUpdatePscellCcInfoTab(ccInfoTabOut, ccInfo);
    }

    for (; MAX_PCC_PSCELL_BANDS > psCellCount; psCellCount++)
    {
        mcoPscellCcInfo_s &ccInfo = ccInfoTabOut[psCellCount];

        if (false == FnVCCB_McoIsPscellCcInfoValid(ccInfo))
        {
            break;
        }

        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC NRDC][Recalculation] spCellNum(%u) PSCell candidate(%u) band(%u) ssbArfcn(%u) BW(%u) nbrIdx(%u)\n",
            spCellNum, psCellCount, ccInfo.band, ccInfo.ccInfo.userValue, ccInfo.ccInfo.mcoBwDl, ccInfo.nbrIdx);
    }

    return psCellCount;
}

/**
 * @brief   MCO: Fill cell's bandwidth based on cell's parameters.
 */
template <typename CellInfoInT, typename CellInfoOutT>
void FnVCCB_McoFillBandwidth(const CellInfoInT &rCellInfoIn, CellInfoOutT &rCellInfoOut)
{
    AUTO_TRACE_FUNC;

    uint16_t duplexMode = FnVCCB_GetNrDuplexTypeByBandIndicator(rCellInfoOut.frequencyBand);
    if (CI_DUPLEXTYPE_SDL == duplexMode)  // from CA perspective SDL should be treated as FDD
    {
        duplexMode = ci_DUPLEXTYPE_FDD;
    }

    FnVCCB_McoFillBandwidthByDuplex(duplexMode, rCellInfoOut.mcoBwDl, rCellInfoOut.mcoBwUl, rCellInfoIn);
}
template void FnVCCB_McoFillBandwidth<scellInfo_type, mcoSccCcInfo_s>(scellInfo_type const&, mcoSccCcInfo_s&);
template void FnVCCB_McoFillBandwidth<scellInfo_type, caScellCcInfo_type>(scellInfo_type const&, caScellCcInfo_type&);

/**
 * @brief   MCO : Prepares contiguous NR cell groups for SCC Change or TOP BC from current serving cells.
 */
void FnVCCB_McoPrepareContiguousNrCellGroupsForMaxBW(
    callInfo_type *ptCi, const bool mfbiCheckFlag, mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBandOut,
    const cellSelection_type &rCellSelection, const bandCombinationList_type &rUeSupBandCombList)
{
    AUTO_TRACE_FUNC;

    ccInfoVecPerBandOut.clear();

    VALID_E_POINT_CHECK_VOID(ptCi);

    uint16_t bandNr = rCellSelection.bandNr;
    uint16_t cellNum = rCellSelection.cellNum;

    VCCB_CHECK_VALID_CELLNUM_VOID(cellNum);
    VccbCellInfo_type *const pSpCell = &CELLINFO[cellNum];

    mcoSccCcInfo_s cellList[MAX_SCELL_PER_CALL + 1];
    uint16_t cellListCount = 0;

    caCellInfo_type spCellInfo, tmpScellInfo;

    if(GOOD != VLIB_FillPcellCaCellInfo(ptCi, {cellNum, bandNr}, spCellInfo))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[SCC] Error when filling spCell cellNum(%u) CA info!!\n", cellNum);
        return;
    }

    // Get filteredBcIndex
    bcIdxArray_type filteredBcIndexes;

    if (mfbiCheckFlag)
    {
        if (GOOD != VLIB_getBcIndexesUsingPrioBasedScellSelectCom(ptCi, cellNum, bandNr, filteredBcIndexes, &rUeSupBandCombList))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[SCC] No Valid BC indexes found\n");
            return;
        }
    }

    mcoSccCcInfo_s &rPCellCcInfo = cellList[cellListCount];
    rPCellCcInfo.frequencyBand = bandNr;
    rPCellCcInfo.sCellIndex = MAX_SCELL_PER_CALL; // indicate PCell
    rPCellCcInfo.nrArfcnDl = pSpCell->nrArfcnDl;
    rPCellCcInfo.nrScsDl = static_cast<uint8_t>(pSpCell->nrScsDl);
    rPCellCcInfo.nRbDl = static_cast<uint8_t>(pSpCell->nRbDl);
    rPCellCcInfo.altBand = BAND_NOT_FOUND;

    FnVCCB_McoFillBandwidth(pSpCell->intraGnbNbrInfo, rPCellCcInfo);

    cellListCount++;

    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (uint8_t sCellIdx = 0; sCellIdx < MAX_SCELL_PER_CALL; ++sCellIdx)
    {
        const scellInfo_type &sCell = scells[sCellIdx];

        if ( (pSpCell->ssbArfcn == sCell.ssbArfcn) ||
           ((SCELL_STATE_ADDED != sCell.state) && (SCELL_STATE_MRREL != sCell.state) && (SCELL_STATE_CCLIMITREL != sCell.state)) )
        {
            continue;
        }

        mcoSccCcInfo_s &rSCellCcInfo = cellList[cellListCount];
        rSCellCcInfo.frequencyBand = sCell.bandNr;
        rSCellCcInfo.sCellIndex = sCellIdx;
        rSCellCcInfo.nrArfcnDl = sCell.nrArfcn;
        rSCellCcInfo.nrScsDl = sCell.nrScsDl;
        rSCellCcInfo.nRbDl = sCell.nrbDl;
        rSCellCcInfo.altBand = BAND_NOT_FOUND;

        FnVCCB_McoFillBandwidth(sCell, rSCellCcInfo);

        cellListCount++;

        // Try to find SCell's MFBI band
        if (false == mfbiCheckFlag)
        {
            continue;
        }

        // Get SCell Info
        if (GOOD != VLIB_FillCaCellInfo(ptCi, cellNum, sCell.cgi, sCell.gnbIdLength, tmpScellInfo))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[SCC] Error when filling SCell ci(%llu) CA info!\n", 1ULL * sCell.cgi.ci);
            continue;
        }

        // find first MFBI band that is different from currently used band.
        auto &rBandList = tmpScellInfo.bandList;
        auto &rBandListNum = tmpScellInfo.bandListNum;

        VCCB_CHECK_E_RANGE_AND_CONTINUE(rBandListNum, MAX_FREQBAND_PER_CELL+1); // Just to avoid detection error of svace

        // find first MFBI band that is different from currently used band.
        const uint16_t *pMfbiBand = std::find_if(rBandList, rBandList + rBandListNum, [&sCell](uint16_t band){ return band != sCell.bandNr; });
        if (pMfbiBand == rBandList + rBandListNum)
        {
            continue;
        }

        // Check MFBI(Alt Band) Available
        tmpScellInfo.frequencyBand = *pMfbiBand;

        if (GOOD != VLIB_IsCellEligibleForCA(ptCi, &spCellInfo, &tmpScellInfo, filteredBcIndexes))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[SCC] SCell ci(%llu) MFBI band(%u) not eligible!\n", 1ULL * sCell.cgi.ci, tmpScellInfo.frequencyBand);
            continue;
        }

        // Update Alt Band
        rSCellCcInfo.altBand = *pMfbiBand;
    }

    // Sort cell list ascending by band and freq value
    std::sort(cellList, &cellList[cellListCount],
        [](const mcoSccCcInfo_s &lhs, const mcoSccCcInfo_s &rhs)
        {
            if ((lhs.frequencyBand < rhs.frequencyBand) ||
                ((lhs.frequencyBand == rhs.frequencyBand) && (lhs.nrArfcnDl < rhs.nrArfcnDl)))
            {
                return true;
            }
            return false;
        });

    auto fnSetCcInfo = [](mcoCcInfo_s &ccInfoOut, const mcoSccCcInfo_s &caCellInfoIn, const uint8_t grpIdCurrIn)
    {
        ccInfoOut.mcoBwDl = caCellInfoIn.mcoBwDl;
        ccInfoOut.grpId = grpIdCurrIn;
        ccInfoOut.pcellFlag = (MAX_SCELL_PER_CALL == caCellInfoIn.sCellIndex);
        ccInfoOut.userValue = caCellInfoIn.sCellIndex;
        ccInfoOut.altBand = caCellInfoIn.altBand;
        ccInfoOut.altBandMcoBwDl = caCellInfoIn.mcoBwDl;
    };

    // iterate over bands and create contiguous CC groups
    FnVCCB_McoCreateContigCcGroupsPerBand(cellList, cellList + cellListCount, ccInfoVecPerBandOut, fnSetCcInfo);

    // print output for debug
    if (DBG->flag.logMco)
    {
        for (const mcoBand2mcoCcInfoVecMap_type::value_type &kv : ccInfoVecPerBandOut)
        {
            const mcoCcInfoVec_type &ccInfoVec = kv.second.ccInfoVec;

            VCCB_PRINT_CALL_COMMENT(ptCi, "====== [MCO] current NR CC groups: band(%u) ======\n", kv.first);

            for (std::size_t ccIdx = 0; ccIdx < ccInfoVec.size(); ccIdx++)
            {
                const mcoCcInfo_s &ccInfo = ccInfoVec[ccIdx];
                uint32_t nrArfcn =
                    ((MAX_SCELL_PER_CALL > ccInfo.userValue) ? scells[ccInfo.userValue].nrArfcn : pSpCell->nrArfcnDl);
                VCCB_PRINT_CALL_COMMENT(
                    ptCi, "CC: ccIdx(%lu) contGrpId(%u) nrArfcn(%u) SCellIdx(%u) BW_DL(%u) isPCell(%u) altBand(%u)\n",
                    ccIdx, ccInfo.grpId, nrArfcn, ccInfo.userValue, ccInfo.mcoBwDl, ccInfo.pcellFlag, ccInfo.altBand);
            }
        }
    }
}

/**
 * @brief   Convert EUTRA RB number to Bandwidth in kHz
 */
uint32_t FnVCCB_ConvertEutraNrbToBandwidthKhz(unsigned int nrb)
{
    AUTO_TRACE_FUNC;

    // rb6 = 0, rb15 = 1, rb25 = 2, rb50 = 3, rb75 = 4, rb100 = 5
    static const uint32_t nrb2bwKhz[NRRRC_rb100 + 1] = {1400, 3000, 5000, 10000, 15000, 20000};

    if (NRRRC_rb100 < nrb)
    {
        VCCB_PRINT_ERROR("Invalid EUTRA nrb(%u)\n", nrb);
        return 0;
    }

    return nrb2bwKhz[nrb];
}

/**
 * @brief   MCO: Prepares MCG EUTRA contiguous cell groups for LTE access.
 */
void FnVCCB_McoPrepareMcgContiguousEutraCellGroups(
    callInfo_type *ptCi, mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBandOut, uint16_t &rPCellBandOut)
{
    AUTO_TRACE_FUNC;

    ccInfoVecPerBandOut.clear();
    rPCellBandOut = BAND_NOT_FOUND;

    VALID_E_POINT_CHECK_VOID(ptCi);

    const static uint16_t ASSUMED_EUTRA_CELL_BW = 1;  // set 1 to imitate CC number
    mcoEutraCellInfo_s cellInfoTab[MAX_NR_OF_SERVING_CELLS_EUTRA];
    std::size_t cellInfoCnt = 0;

    const ServCellInfoListMcgEutra_type &servCellInfoListMcgEutra = ptCi->cgConfigInfo.servCellInfoListMcgEutra;
    const uint8_t numItems = MIN(servCellInfoListMcgEutra.numItems, MAX_NR_OF_SERVING_CELLS_EUTRA);
    if (0 == numItems)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] ServCellInfoListMcgEutra empty!\n");
        return;
    }

    uint16_t cellBand = BAND_NOT_FOUND;
    uint32_t freqKhzDl = 0;
    uint32_t bwkhz = 0;

    auto fnProcessCell = [&ptCi, &servCellInfoListMcgEutra, &cellBand, &freqKhzDl, &bwkhz](const uint8_t cellIdx)
    {
        const ServCellInfoXcgEutra_type &cell = servCellInfoListMcgEutra.items[cellIdx];

        if ((VCCB_FLAG_OFF == cell.earfcnDl_Flag) || (VCCB_FLAG_OFF == cell.trBWidth_Flag))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[MCO] ServCellInfoListMcgEutra[%u].earfcnDl_Flag(%u) or trBWidth_Flag(%u)!\n", cellIdx,
                cell.earfcnDl_Flag, cell.trBWidth_Flag);
            return false;
        }

        cellBand = ConvertDlEarfcnToBand(cell.earfcnDl);
        if (BAND_NOT_FOUND == cellBand)
        {
            VCCB_PRINT_CALL_COMMENT(
                ptCi, "[MCO] ServCellInfoListMcgEutra[%u].earfcnDl(%u) band not found!\n", cellIdx, cell.earfcnDl);
            return false;
        }

        freqKhzDl = ConvertDlEarfcnToFreqKhz(cell.earfcnDl);
        if (0 == freqKhzDl)
        {
            VCCB_PRINT_CALL_COMMENT(
                ptCi, "[MCO] ServCellInfoListMcgEutra[%u].earfcnDl(%u) freqKhzDl not found!\n", cellIdx, cell.earfcnDl);
            return false;
        }

        bwkhz = FnVCCB_ConvertEutraNrbToBandwidthKhz(cell.trBWidth);
        if (0 == bwkhz)
        {
            VCCB_PRINT_CALL_COMMENT(
                ptCi, "[MCO] ServCellInfoListMcgEutra[%u].trBWidth(%u) invalid BW!\n", cellIdx, cell.trBWidth);
            return false;
        }

        return true;
    };

    auto fnAddCellInfo = [&](const uint8_t cellIdx, bool isPcell)
    {
        cellInfoTab[cellInfoCnt].frequencyBand = cellBand;
        cellInfoTab[cellInfoCnt].freqKhzDl = freqKhzDl;
        cellInfoTab[cellInfoCnt].bwKhzDl = bwkhz;
        cellInfoTab[cellInfoCnt].isPcell = isPcell;
        cellInfoTab[cellInfoCnt].earfcn = servCellInfoListMcgEutra.items[cellIdx].earfcnDl;
        cellInfoCnt++;
    };

    // MCO PCell is first cell received in ServCellInfoListMCG-EUTRA-r16
    if (false == fnProcessCell(0))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] ServCellInfoListMcgEutra PCell ERROR!\n");
        return;
    }
    rPCellBandOut = cellBand;
    fnAddCellInfo(0, true);

    for (uint8_t cellIdx = 1; numItems > cellIdx; cellIdx++)
    {
        if (false == fnProcessCell(cellIdx))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO] ServCellInfoListMcgEutra cell(%u) ERROR!\n", cellIdx);
            continue;
        }
        fnAddCellInfo(cellIdx, false);
    }

    // Sort cell list ascending by band and freq value
    std::sort(cellInfoTab, &cellInfoTab[cellInfoCnt],
        [](const mcoEutraCellInfo_s &lhs, const mcoEutraCellInfo_s &rhs)
        {
            if ((lhs.frequencyBand < rhs.frequencyBand) ||
                ((lhs.frequencyBand == rhs.frequencyBand) && (lhs.freqKhzDl < rhs.freqKhzDl)))
            {
                return true;
            }

            return false;
        });

    // Remove duplicates by band and freq value
    mcoEutraCellInfo_s *pCellInfoShrunkEnd = std::unique(cellInfoTab, &cellInfoTab[cellInfoCnt],
        [](const mcoEutraCellInfo_s &lhs, const mcoEutraCellInfo_s &rhs)
        { return ((lhs.frequencyBand == rhs.frequencyBand) && (lhs.freqKhzDl == rhs.freqKhzDl)); });
    const std::size_t shrunkSize = static_cast<std::size_t>(std::distance(cellInfoTab, pCellInfoShrunkEnd));
    if (cellInfoCnt > shrunkSize)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "[MCO] ServCellInfoListMcgEutra: removed (%lu) duplicated freq CC!\n", cellInfoCnt - shrunkSize);
        cellInfoCnt = shrunkSize;
    }

    auto fnSetCcInfo = [](mcoCcInfo_s &ccInfoOut, const mcoEutraCellInfo_s &cellInfoIn, const uint8_t grpIdCurrIn)
    {
        ccInfoOut.mcoBwDl = ASSUMED_EUTRA_CELL_BW;
        ccInfoOut.grpId = grpIdCurrIn;
        ccInfoOut.pcellFlag = cellInfoIn.isPcell;
        ccInfoOut.userValue = cellInfoIn.earfcn;
    };

    // iterate over bands and create contiguous CC groups
    FnVCCB_McoCreateContigCcGroupsPerBand(cellInfoTab, cellInfoTab + cellInfoCnt, ccInfoVecPerBandOut, fnSetCcInfo);

    // print output for debug
    for (mcoBand2mcoCcInfoVecMap_type::value_type &kv : ccInfoVecPerBandOut)
    {
        mcoCcInfoVec_type &ccInfoVec = kv.second.ccInfoVec;

        VCCB_PRINT_CALL_COMMENT(ptCi, "====== [MCO] MCG CC groups: band(%u) ======\n", kv.first);

        for (std::size_t ccIdx = 0; ccIdx < ccInfoVec.size(); ccIdx++)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "CC: ccIdx(%lu) contGrpId(%u) earfcn(%u) isPCell(%u)\n", ccIdx,
                ccInfoVec[ccIdx].grpId, ccInfoVec[ccIdx].userValue, ccInfoVec[ccIdx].pcellFlag);
        }
    }
}

/**
 * @brief     Initialize sCell[]
 * @param     ptCi : call context
 * @param     nonCaFlag : indicate whether it is non-CA
 */
void VLIB_InitializeStateActionIndexesForSCellConfig(callInfo_type *ptCi, const bool nonCaFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if ((((IntraRatHO_cmd == ptCi->stateCmd) || (IntraCellHO_cmd == ptCi->stateCmd)) &&
            (ptCi->hoInfo.hoType.rat == HO_TYPE_INTRA_RAT) && (ptCi->hoInfo.hoType.nb == HO_TYPE_INTRA_NB)) ||
        ((RrcReestablish_cmd == ptCi->stateCmd) &&
            (RRE_TYPE_INTRA_DU == ptCi->ueInfo.reestablishInfo.reestablishType)) ||
        (CHECK_MOD_EVENT_WITH_STATECMD(ptCi, allowedBC) && !(IS_ENDC_SCG_TO_RELEASE(ptCi))) ||
        (TRUE == ptCi->bitFlag.isSCellReconfigRequired) || (IS_SN_ADDITION_ONGOING(ptCi)) ||
        (IS_NRDC_SNREL_INVOKED(ptCi)) || (IS_ON_MRDC_XN_RCVINDICATOR_FLAG(selectedBC)))
    {
        // intra-DU PSCell change / intra-DU RRE / AllowedBC change
        for (uint8_t scellIdx = 0; scellIdx < MAX_SCELL_PER_CALL; ++scellIdx)
        {
            scellInfo_type &rSCell = ptCi->sCell[scellIdx];
            if (((SCELL_STATE_ADDED == ptCi->sCellDuConfig[scellIdx].state) &&
                 (SCELL_ACTION_SETUP != ptCi->sCellDuConfig[scellIdx].action)) ||
                (SCELL_ACTION_RELEASE == ptCi->sCellDuConfig[scellIdx].action))
            {
                //mark existing scells as to be released
                rSCell.state = SCELL_STATE_RELEASED;
                rSCell.action = SCELL_ACTION_RELEASE;
                rSCell.addRelCause = CaSCellRel_OtherCause;
            }
            else if (SCELL_STATE_VONRREL == ptCi->sCellDuConfig[scellIdx].state && !nonCaFlag)
            {
                //do nothing, will be handled in VLIB_AddVoNRRellCellsIfEligible
            }
            else if ((SCELL_STATE_LTMREL == ptCi->sCellDuConfig[scellIdx].state) &&
                     (CaOperation_Mode3 == ptCi->caInfo.mode) &&
                     (!nonCaFlag))
            {
                //do nothing, information will be used in FnVCCB_CfgSCellListProc
            }
            else
            {
                //other sCell not used
                rSCell.state = SCELL_STATE_RELEASED;
                rSCell.action = SCELL_ACTION_KEEP;
                rSCell.sCellIndex = 0;
            }
            rSCell.isActionQueued = FALSE;
        }
    }
    else
    {
        for (scellInfo_type &rSCell : ptCi->sCell)
        {
            rSCell.state = SCELL_STATE_RELEASED;
            rSCell.action = SCELL_ACTION_KEEP;
            rSCell.isActionQueued = FALSE;
            rSCell.sCellIndex = 0;
        }
    }
}

/**
 * @brief   MCO: Fill cell's bandwidth based on cell's parameters.
 */
template <typename CellInfoT, typename IntegerType>
void FnVCCB_McoFillBandwidthByDuplex(uint16_t duplexMode, IntegerType &rMcoBwDl, IntegerType &rMcoBwUl, const CellInfoT &rCell)
{
    AUTO_TRACE_FUNC;

    rMcoBwDl = rCell.bandwidthDl;

    if (ci_DUPLEXTYPE_FDD == duplexMode)
    {
        rMcoBwUl = rCell.bandwidthUl;
    }
    else
    {
        // for TDD use Dl values
        rMcoBwUl = static_cast<IntegerType>((double)rMcoBwDl * 0.2 + 0.5);
        rMcoBwDl = static_cast<IntegerType>((double)rMcoBwDl * 0.8 + 0.5);
    }
}
template void FnVCCB_McoFillBandwidthByDuplex<nbrGnbCellInfo_type, uint32_t>(uint16_t duplexMode, uint32_t &rMcoBwDl, uint32_t &rMcoBwUl, const nbrGnbCellInfo_type &rCell);
template void FnVCCB_McoFillBandwidthByDuplex<nbrGnbCellInfo_type, uint16_t>(uint16_t duplexMode, uint16_t &rMcoBwDl, uint16_t &rMcoBwUl, const nbrGnbCellInfo_type &rCell);

/**
 * @brief Checks supported carrierAggregationVariant during sCells selection.
 * @param[in] ptCaVariant: supported carrierAggregationVariant
 * @param[in] ptPCell: PCell to synchronize with SCell.
 * @param[in] ptSCell: SCell to synchronize with PCell.
 * @return GOOD/ERROR  : Message handling status
 */
int16_t VLIB_CheckCarrierAggregationVariant(
    const carrierAggregationVariant_type *ptCaVariant, const caCellInfo_type *ptPCell, const caCellInfo_type *ptSCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCaVariant);
    CHECK_CA_CELL_VALIDITY_AND_RETURN(ptPCell);
    CHECK_CA_CELL_VALIDITY_AND_RETURN(ptSCell);

    if ((FALSE == ptCaVariant->usageSpCellPlacement) || (FrequencyRangeCa_FR2 == ptPCell->frequencyRange))
    {
        return GOOD;
    }

    if (FrequencyRangeCa_FR1 == ptSCell->frequencyRange)
    {
        if ((ci_DUPLEXTYPE_FDD == ptPCell->duplexMode) && (ci_DUPLEXTYPE_TDD == ptSCell->duplexMode) &&
            (FALSE == ptCaVariant->fr1fdd_FR1TDD_CA_SpCellOnFR1FDD_supported))
        {
            return BREAK;
        }

        if ((ci_DUPLEXTYPE_TDD == ptPCell->duplexMode) && (ci_DUPLEXTYPE_FDD == ptSCell->duplexMode) &&
            (FALSE == ptCaVariant->fr1fdd_FR1TDD_CA_SpCellOnFR1TDD_supported))
        {
            return BREAK;
        }
    }
    else  // FR2(TDD)
    {
        if ((ci_DUPLEXTYPE_FDD == ptPCell->duplexMode) &&
            (FALSE == ptCaVariant->fr1fdd_FR2TDD_CA_SpCellOnFR1FDD_supported))
        {
            return BREAK;
        }
    }

    return GOOD;
}

/**
 * @brief     Check if cell can be sCell candidate in NSA
 * @details   Check if cell fulfill all criteria to be selected to CA operation ENDC
 * @param     ptCi : call context
 * @param     ptPCell : pCell info caCellInfo_type
 * @param     ptSCell : sCell info caCellInfo_type
 * @return    GOOD: cell can be selected to CA operation, BREAK: cell cannot be selected to CA operation, ERROR
 */
int16_t VLIB_IsCellEligibleForCaENDC(callInfo_type *ptCi, const caCellInfo_type *ptPCell, const caCellInfo_type *ptSCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    CHECK_CA_CELL_VALIDITY_AND_RETURN(ptPCell);
    CHECK_CA_CELL_VALIDITY_AND_RETURN(ptSCell);

    nbrGnbCellInfo_type *ptScellNbrInfo = VLIB_GetNbrGnbCellInfoBasedOnCgi(ptCi, ptSCell->cgi, ptSCell->gnbIdLength);
    VALID_E_POINT_CHECK_ERROR(ptScellNbrInfo);
    nbrGnbCellInfo_type *ptPscellNbrInfo = VLIB_GetNbrGnbCellInfoBasedOnCgi(ptCi, ptPCell->cgi, ptPCell->gnbIdLength);
    VALID_E_POINT_CHECK_ERROR(ptPscellNbrInfo);

    if (GOOD != VLIB_IsSCellAvailableForUe(ptCi, ptSCell->ssbArfcn))
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(
            ptCi, "CA: SCell ci(%llu) ssbArfcn(%u) not available for UE\n", 1ULL * ptSCell->cgi.ci, ptSCell->ssbArfcn);
        return BREAK;
    }

    if (ptCi->bitFlag.isMcoLteAccessCase)  // skip LTE overlap check for MCO Lte Access Case (as there is no real call)
    {
        return GOOD;
    }

    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint16_t pCellIdentity = VLIB_NrCellId2CellId(pGnb->globalGnbId.gnbId.idLength, ptPCell->cgi.ci);
    VCCB_CHECK_E_RANGE_AND_RETURN(pCellIdentity, MAX_CELL_IDENTITY);
    uint16_t cellNum = pGnb->env.cellNum[pCellIdentity];
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    if (GOOD != VCCM_checkCellFrequencyOverlapWithLtePCell(ptCi, ptScellNbrInfo) ||
        (pCell->imdInterferenceDetection &&
            (GOOD != VCCM_checkImdInterferenceWithLtePCellAndNrCandidateCell(ptCi, ptPscellNbrInfo, ptScellNbrInfo))))
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi,
            "CA: SCell ci(%llu) freq overlap with LTE PCell allowDssFreqScell(%u) intraBandENDC_support(%u)\n",
            1ULL * ptSCell->cgi.ci, pGnb->carrierAggregationInfo.allowDssFreqScell, ptCi->intraBandENDC_support);
        if ((pGnb->carrierAggregationInfo.allowDssFreqScell) && (ptCi->intraBandENDC_support))  // FGR-CC5501
        {
            return GOOD;
        }
        else
        {
            return BREAK;
        }
    }

    return GOOD;
}

/********************************************************************************************
 * @brief           Check Slice Aware
 *
 * @param[in]       ptCi     :        call information / callInfo_type
 * @param[in]       pcellNum :        primary cell num
 * @param[in]       ptSCell  :        Pointer of caCellInfo_type for slice checking.
 * @return          status   :        GOOD - correct slice found, BREAK/ERROR - correct slice not found / int16_t
 ********************************************************************************************/
int16_t VCCM_CheckSliceAwareForSCell(callInfo_type *ptCi, const uint16_t pcellNum, const caCellInfo_type *ptSCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    CHECK_CA_CELL_VALIDITY_AND_RETURN(ptSCell);

    if (ptCi->bitFlag.isMcoLteAccessCase)  // skip slice check for MCO Lte Access Case (as there is no real call)
    {
        return GOOD;
    }

    return VCCM_CheckSliceAwareForCellByCgi(ptCi, pcellNum, ptSCell->cgi, MAX_NBR_PER_CELL);
}

/**
 * @brief     Check if cell can be sCell candidate in SA
 * @details   Check if cell fulfill all criteria to be selected to CA operation SA
 * @param     ptCi : call context
 * @param     pcellNum : primary cell num
 * @param     ptPCell : pCell info caCellInfo_type
 * @param     ptSCell : sCell info caCellInfo_type
 * @return    GOOD: cell can be selected to CA operation, BREAK: cell cannot be selected to CA operation, ERROR
 */
int16_t VLIB_IsCellEligibleForCaSA(callInfo_type *ptCi, uint16_t pcellNum,
        const caCellInfo_type *ptPCell, const caCellInfo_type *ptSCell, const nbrGnbCellInfo_type *ptScellNbrInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptScellNbrInfo);
    CHECK_CA_CELL_VALIDITY_AND_RETURN(ptPCell);
    CHECK_CA_CELL_VALIDITY_AND_RETURN(ptSCell);

    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if ((TRUE == pGnb->carrierAggregationInfo.plmnInfoCheck) &&
        (GOOD != VCCM_CheckSliceAwareForSCell(ptCi, pcellNum, ptSCell)))
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell's slice incorrect. ci(%llu)\n", 1ULL * ptSCell->cgi.ci);
        return BREAK;
    }

    if (IS_NRDC_SN(ptCi))
    {
        return GOOD; // Skip tac check for SN
    }

    if (((FrequencyRangeCa_FR1 != ptPCell->frequencyRange) || (FrequencyRangeCa_FR2 != ptSCell->frequencyRange)) &&
        (TRUE == pGnb->carrierAggregationInfo.saCellCheckFlag))
    {
        //check tac only if flag is true and it is not FR1-FR2 CA
        if (N_EQUIP == ptSCell->tacStatus)
        {
            VCCB_PRINT_LOG_CA_FUNC_TRACE(
                ptCi, "CA: SCell ci(%llu) is not SA cell and cannot be selected to CA SA\n", 1ULL * ptSCell->cgi.ci);
            return BREAK;
        }

        if ((CI_use == ptScellNbrInfo->configuredTacIndication) &&
            (N_EQUIP != ptScellNbrInfo->configuredTacStatus))
        {
            VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu) has turned on configured Tac Indication "
                    "and configured Tac is equipped so cannot be selected to CA SA\n", 1ULL * ptSCell->cgi.ci);
            return BREAK;
        }

    }

    return GOOD;
}

/**
 * @brief     Checks if desired object is stored
 * @details   Tries to find whereabouts of desired object and returns GOOD if element is found. ERROR is returned when
 *            at least one argument has value NULL. If element is not found BREAK is returned.
 * @param     failures : structure where objects are stored, among which function tries to find whereabouts of desired.
 * @param     failedCarrierToFind : value function looks for
 * @return    GOOD or BREAK or ERROR /int16_t
 */

int16_t VLIB_findCarrierCell(duFailedSCellInfo_type *failures, uint32_t failedCarrierToFind)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(failures);

    uint8_t i;
    for (i = 0; i < MIN(failures->numFailedCarrier, MAX_COLOCCELL); ++i)
    {
        if (failures->failedCarrier[i] == failedCarrierToFind)
        {
            return GOOD;
        }
    }

    return BREAK;
}

/**
 * @brief     Checks if desired object is stored
 * @details   Tries to find whereabouts of desired object and returns GOOD if element is found. ERROR is returned when
 *            at least one argument has value NULL. If element is not found BREAK is returned.
 * @param     failures : structure where objects are stored, among which function tries to find whereabouts of desired.
 * @param     failedCellToFind : value function looks for
 * @return    GOOD or BREAK or ERROR /int16_t
 */
int16_t VLIB_findFailedCell(const duFailedSCellInfo_type *failures, const cgi_type *failedCellToFind)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(failures);
    VALID_E_POINT_CHECK_ERROR(failedCellToFind);

    for (uint8_t i = 0; i < MIN(failures->numFailedCell, MAX_CELL_FAILED_IN_DU); ++i)
    {
        if (FnVCCB_CheckCgiIdentical(&failures->failedCell[i], failedCellToFind))
        {
            return GOOD;
        }
    }

    return BREAK;
}

/****************************************************************************
 * @brief  Check if scellBandNR can be found in Bc Indexes which was filtered
 * @param  ptCi          : pointer to UE Context
 * @param  pcellBandNR        : pcell band value
 * @param  scellBandNR        : scell candidate band value
 * @param  filteredBcIndexes  : Band combination indexes of scell candidates
 * @return GOOD/BREAK/ERROR /int16_t
 ****************************************************************************/
int16_t VCCB_checkIfBandNrFitsForFilteredBc(
    callInfo_type *ptCi, const uint16_t pCellBandNR, const uint16_t scellBandNR, const bcIdxArray_type &filteredBcIndexes)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    bandCombinationList_type *pBandCombinationList = VRIL_GetBandCombinationList(ptCi);
    VALID_E_POINT_CHECK_ERROR(pBandCombinationList);

    for (uint32_t bcIndex : filteredBcIndexes)
    {
        VCCB_CHECK_E_RANGE_AND_CONTINUE(bcIndex, MAX_BAND_COMBS);
        BandCombination_type *pUeSupportedBandCombination = &pBandCombinationList->bandCombination[bcIndex];
        bool isAClassBandOccurringOnlyOnceInSelectedBC = false;
        for (uint32_t bandIdx = 0; bandIdx < MIN(pUeSupportedBandCombination->num, MAX_BANDS_PER_COMB); bandIdx++)
        {
            if (pUeSupportedBandCombination->band[bandIdx].ratType != ci_nr)
            {
                continue;
            }
            if (scellBandNR != pUeSupportedBandCombination->band[bandIdx].freqBandIndicator)
            {
                continue;
            }

            if ((pCellBandNR == scellBandNR) &&
                (CA_BandwidthClassNR_a == pUeSupportedBandCombination->band[bandIdx].nrCaBandwidthClassDL))
            {
                if (true == isAClassBandOccurringOnlyOnceInSelectedBC)
                {
                    return GOOD;
                }

                isAClassBandOccurringOnlyOnceInSelectedBC = true;
                continue;
            }
            return GOOD;
        }
    }

    return BREAK;
}

/****************************************************************************
 * @brief  Check if scellBandNR is not blocked in bandOperationMode for pCellBandNR
 * @param  ptCi          : pointer to UE Context
 * @param  pcellBandNR   : pcell band value
 * @param  scellBandNR   : scell candidate band value
 * @return GOOD/BREAK/ERROR /int16_t
 ****************************************************************************/
int16_t VCCB_checkIfBandNotBlocked(callInfo_type *ptCi, uint16_t pCellBandNR, uint16_t scellBandNR)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    VCCB_CHECK_E_RANGE_AND_RETURN(pCellBandNR - 1, MAX_NUM_NR_BAND);
    VCCB_CHECK_E_RANGE_AND_RETURN(scellBandNR - 1, MAX_NUM_NR_BAND);

    operationMode_type &rOperationMode = GNBINFO[ptCi->gnbNum].carrierAggregationInfo.bandOperationMode[pCellBandNR - 1];
    uint16_t *blockedBands = nullptr;
    uint8_t noOfBlockedBands = 0;
    if (E_CALLTYPE_NSA == ptCi->callType)
    {
        blockedBands = rOperationMode.blockBandsNsa;
        noOfBlockedBands = MIN(rOperationMode.noOfBlockBandsNsa, MAX_CA_NUM_BLOCK_BANDS);
    }
    else
    {
        blockedBands = rOperationMode.blockBandsSa;
        noOfBlockedBands = MIN(rOperationMode.noOfBlockBandsSa, MAX_CA_NUM_BLOCK_BANDS);
    }

    for (uint8_t blockedBandIdx = 0; blockedBandIdx < noOfBlockedBands; ++blockedBandIdx)
    {
        if (blockedBands[blockedBandIdx] == scellBandNR)
        {
            return BREAK;
        }
    }

    return GOOD;
}

/**
 * @brief     Check if sCell candidate is on omFailedCells
 * @param     ptCi : call context pointer
 * @param     spCellNum : cell num which is pCell for sCell pointed by ptSCell  - it could be that
                          this function is used to examine scell in context of pcell different than actual call
                          for instance Multi Carrier Operation FGR-CC5500 for PCC uses this function
 * @param     ptSCell : sCell candidate pointer
 * @return    GOOD: sCell candidate is NOT on omFailedCells list
 * @return    BREAK: sCell candidate is present on omFailedCells list
 */
int16_t VLIB_CheckCandidateScellAgainstOMFailedCellList(
    callInfo_type *ptCi, uint16_t spCellNum, const caCellInfo_type *ptSCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    CHECK_CA_CELL_VALIDITY_AND_RETURN(ptSCell);
    VCCB_CHECK_VALID_CELLNUM_ERROR(spCellNum);

    for (omFailedCellInfo_type &rOMFailedCell : CELLINFO[spCellNum].omFailedCells)
    {
        if (CI_use != rOMFailedCell.usage)
        {
            continue;
        }

        if ((rOMFailedCell.cgi.ci == ptSCell->cgi.ci) &&
            (rOMFailedCell.cgi.plmn.longId == ptSCell->cgi.plmn.longId))
        {
            VCCB_PRINT_LOG_CA_FUNC(
                ptCi, "Candidate SCell (NRCI:%lu) for CA is on omFailedCells list!\n", ptSCell->cgi.ci);
            return BREAK;
        }
    }

    return GOOD;
}

/**
 * @brief     Check if carrier can be sCell carrier
 * @param     ptCi : call context
 * @param     ptPCell : pCell info caCellInfo_type
 * @param     ptSCell : sCell info caCellInfo_type
 * @return    GOOD: carrier can be scell carrier in future, BREAK: carrier cannot be scell carrier, ERROR
 */
int16_t VLIB_IsCarrierEligibleForCA(callInfo_type *ptCi, const caCellInfo_type *ptPCell, const caCellInfo_type *ptSCell,
    const bcIdxArray_type &filteredBcIndexes)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    CHECK_CA_CELL_VALIDITY_AND_RETURN(ptPCell);
    CHECK_CA_CELL_VALIDITY_AND_RETURN(ptSCell);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);

    if (ptPCell->ssbArfcn == ptSCell->ssbArfcn)  // ignore carrier if it has same frequency as Pcell
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi,
            "CA: SCell ci(%llu) ssbArfcn(%u) is same as spCell\n",
            1ULL * ptSCell->cgi.ci, ptSCell->ssbArfcn);
        return BREAK;
    }

    if (ptSCell->isSsbCell &&
        !FnVCCB_IsSsbAllowed(*ptCi, ptSCell->ssbArfcn))
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu) ssbArfcn(%u) extended n77 not supported\n",
            1ULL * ptSCell->cgi.ci, ptSCell->ssbArfcn);
        return BREAK;
    }

    if (GOOD !=
        VLIB_CheckCarrierAggregationVariant(&ptCi->ueInfo.ueCapa.nr.carrierAggregationVariant, ptPCell, ptSCell))
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi,
            "CA: SCell ci(%llu) cannot be selected - UE supported carrierAggregationVariant mismatch\n",
            1ULL * ptSCell->cgi.ci);
        return BREAK;
    }

    if (GOOD != VCCB_checkIfBandNrFitsForFilteredBc(ptCi, ptPCell->frequencyBand, ptSCell->frequencyBand, filteredBcIndexes))
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu) band(%u) not supported in BC\n",
            1ULL * ptSCell->cgi.ci, ptSCell->frequencyBand);
        return BREAK;
    }

    if (GOOD != VCCB_checkIfBandNotBlocked(ptCi, ptPCell->frequencyBand, ptSCell->frequencyBand))
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu) band(%u) blocked\n",
            1ULL * ptSCell->cgi.ci, ptSCell->frequencyBand);
        return BREAK;
    }

    if (GOOD != FnVCCB_CheckIfBandInAllowedBandList(*ptCi, ptSCell->frequencyBand))
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu) band(%u) not allowed\n",
            1ULL * ptSCell->cgi.ci, ptSCell->frequencyBand);
        return BREAK;
    }

    enumBandDependencyCa_type bandDependency =
        (ptSCell->frequencyBand == ptPCell->frequencyBand) ? BandDependencyCa_INTRA : BandDependencyCa_INTER;

    enumSupport_type isSupported = VCCB_UNKNOWN;

    if ((E_CALLTYPE_NSA == ptCi->callType) || (IS_NRDC_SN(ptCi)))
    {
        isSupported = CFG->allowedCaConfigNSA[ptPCell->frequencyRange][ptPCell->duplexMode][ptSCell->frequencyRange]
                                             [ptSCell->duplexMode][bandDependency];
    }
    else
    {
        isSupported = CFG->allowedCaConfigSA[ptPCell->frequencyRange][ptPCell->duplexMode][ptSCell->frequencyRange]
                                            [ptSCell->duplexMode][bandDependency];
    }

    if (VCCB_UNSUPPORTED == isSupported)
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi,
            "CA: SCell ci(%llu) %s %s is not allowed in CA configuration with pCell ci(%llu) %s %s\n",
            1ULL * ptSCell->cgi.ci, (FrequencyRangeCa_FR1 == ptSCell->frequencyRange) ? "FR1" : "FR2",
            (ci_DUPLEXTYPE_FDD == ptSCell->duplexMode) ? "FDD" : "TDD", 1ULL * ptPCell->cgi.ci,
            (FrequencyRangeCa_FR1 == ptPCell->frequencyRange) ? "FR1" : "FR2",
            (ci_DUPLEXTYPE_FDD == ptPCell->duplexMode) ? "FDD" : "TDD");
        return BREAK;
    }

    if ((FrequencyRangeCa_FR1 == ptPCell->frequencyRange) && (FrequencyRangeCa_FR2 == ptSCell->frequencyRange))
    {
        if (TRUE != ptCi->caInfo.isFR1FR2CaAvailable)
        {
            VCCB_PRINT_LOG_CA_FUNC_TRACE(
                ptCi, "CA: SCell ci(%llu) rejected - FR1-FR2 Ca not available\n", 1ULL * ptSCell->cgi.ci);
            return BREAK;
        }

        if ((TRUE == ptCi->ueInfo.ueCapa.nr.phyParameters.present.phyParametersCommonPresent) &&
            (TRUE != ptCi->ueInfo.ueCapa.nr.phyParameters.phyParametersCommon.dynamicHARQACKCodebookSupported))
        {
            VCCB_PRINT_LOG_CA_FUNC_TRACE(
                ptCi, "CA: SCell ci(%llu) rejected - dynamicHARQACKCodebook not supported\n", 1ULL * ptSCell->cgi.ci);
            return BREAK;
        }
    }

    return GOOD;
}

/**
 * @brief     This function check if cell is barred as scell or PCC tgt cell.
 *            It is CA/MCO adaptation of VLIB_IsCellBarred function.
 * @param     ptCi : call context
 * @param     cellNum : cellNum of cell to check
 * @param     skipMibBarredCheck : inform if mib.cellBarred check should be skipped
 * @return    true/false
 */
bool VLIB_IsCellBarred_Ca(callInfo_type *ptCi, uint16_t cellNum, uint16_t skipMibBarredCheck)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, true);

    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, true);
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    VCCB_CHECK_E_RANGE_AND_VAL(pCell->gnbNum, MAX_GNB_PER_SYS, true);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[pCell->gnbNum];

    if (TRUE == pGnb->pldGnbBarringInfo.shuttingDown)
    {
        return true;
    }
    if (TRUE == pGnb->pldGnbBarringInfo.overload)
    {
        return true;
    }
    if (TRUE == pCell->switchingOffOngoing)
    {
        return true;
    }

    if ((ptCi->callType == E_CALLTYPE_SA) &&
        (!IS_NRDC_SN(ptCi)))
    {
        if (TRUE == pGnb->pldGnbBarringInfo.amfNotAvailable)
        {
            return true;
        }
        if ((TRUE != skipMibBarredCheck) &&
            (NRRRC_barred == pCell->mib.cellBarred))
        {
            return true;
        }
        if ((TRUE == pCell->sib1.cellReservedForOtherUseFlag) &&
            (NRRRC_true == pCell->sib1.cellReservedForOtherUse))
        {
            return true;
        }
        if ((TRUE == pCell->sib1.cellReservedForFutureUseFlag) &&
            (NRRRC_true == pCell->sib1.cellReservedForFutureUse))
        {
            return true;
        }
    }

    return false;
}

/**
 * @brief     This function check if cell is in service and can be used as scell or PCC tgt cell.
 *            It is CA/MCO adaptation of VCCM_CheckCellInService function.
 * @param     ptCi : call context
 * @param     cellNum : cellNum of cell to check
 * @param     skipMibBarredCheck : inform if mib.cellBarred check should be skipped
 * @return    true/false
 */
bool VLIB_CheckCellInService_Ca(callInfo_type *ptCi, uint16_t cellNum, bool skipMibBarredCheck)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);

    if (EQUIP != CELLINFO[cellNum].status)
    {
        return false;
    }

    if (FALSE == VLIB_IsInServiceCell(ptCi, cellNum, FALSE))
    {
        return false;
    }

    if (VLIB_IsCellBarred_Ca(ptCi, cellNum, skipMibBarredCheck))
    {
        return false;
    }

    return true;
}

/**
 * @brief     Part of VLIB_IsCellEligibleForCA (only for inter gNB candidates)
 * @param     ptCi : call context
 * @param     ptSCell : sCell info caCellInfo_type
 * @param     ptScellNbrInfo : sCell nbr info (nbrGnbCellInfo_type)
 * @param     ptSpCell : current spCell info (VccbCellInfo_type)
 * @param     spCellNum : cellNum of current spCell
 * @return    true/false
 */
bool VLIB_IsCellEligibleForCA_interGnb(callInfo_type *ptCi, const caCellInfo_type *ptSCell,
        nbrGnbCellInfo_type *ptScellNbrInfo, const VccbCellInfo_type *ptSpCell, uint16_t spCellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptSCell, false);
    VALID_E_POINT_CHECK_RET_VAL(ptScellNbrInfo, false);
    VALID_E_POINT_CHECK_RET_VAL(ptSpCell, false);
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, false);
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(spCellNum, false);

    if (TRUE != GNBINFO[ptCi->gnbNum].carrierAggregationInfo.interGnbCaSupportFlag)
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu)- inter gNB CA not supported\n", 1ULL * ptSCell->cgi.ci);
        return false;
    }

    if (EQUIP != ptScellNbrInfo->status)
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu)- nbr status not equip\n", 1ULL * ptSCell->cgi.ci);
        return false;
    }

    if (FnVCCB_CheckIfOtherVendorGnbByGlobalGnbId(ptCi, ptCi->gnbNum, &ptScellNbrInfo->globalGnbId))
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu)- non-Samsung vendor\n", 1ULL * ptSCell->cgi.ci);
        return false;
    }

    const uint32_t gnbId = VLIB_NrCellId2GnbId(ptSCell->gnbIdLength, ptSCell->cgi.ci);
    const uint16_t sCellIdentity = VLIB_NrCellId2CellId(ptSCell->gnbIdLength, ptSCell->cgi.ci);
    uint16_t neighbourIdx;
    for (neighbourIdx = 0; neighbourIdx < MAX_NBR_PER_CELL; ++neighbourIdx)
    {
        if ((EQUIP == ptSpCell->Nbr[neighbourIdx].status) &&
            (ptSpCell->Nbr[neighbourIdx].targetCellId == sCellIdentity) &&
            (ptSpCell->Nbr[neighbourIdx].targetGnbId.gnbId.id == gnbId) &&
            (ptSpCell->Nbr[neighbourIdx].targetGnbId.plmn.longId == ptSCell->cgi.plmn.longId))
        {
            break;
        }
    }

    if (MAX_NBR_PER_CELL <= neighbourIdx)
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: NeighbourIdx for SCell ci(%llu) not found\n", 1ULL * ptSCell->cgi.ci);
        return false;
    }

    if (GOOD != VCCM_CheckValidDssCellCondition(ptCi, spCellNum, neighbourIdx, ptSCell->frequencyBand))
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: DSS Condition is not valid for SCell ci(%llu)\n", 1ULL * ptSCell->cgi.ci);
        return false;
    }

    return true;
}

/**
 * @brief     Check if cell can be sCell candidate
 * @details   Check if cell fulfills all criteria to be selected to CA operation.
 * @param     ptCi : call context
 * @param     ptPCell : pCell info caCellInfo_type
 * @param     ptSCell : sCell info caCellInfo_type
 * @param     filteredBcIndexes : Band combination indexes of scell candidates
 * @return    GOOD: cell can be selected to CA operation, BREAK: cell cannot be selected to CA operation, ERROR
 */
int16_t VLIB_IsCellEligibleForCA(callInfo_type *ptCi, const caCellInfo_type *ptPCell, const caCellInfo_type *ptSCell,
    const bcIdxArray_type &filteredBcIndexes)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    CHECK_CA_CELL_VALIDITY_AND_RETURN(ptPCell);
    CHECK_CA_CELL_VALIDITY_AND_RETURN(ptSCell);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);

    if (GOOD != VLIB_IsCarrierEligibleForCA(ptCi, ptPCell, ptSCell, filteredBcIndexes))
    {
        return BREAK;
    }

    int16_t status = GOOD;
    uint16_t cellNum;

    nbrGnbCellInfo_type *ptScellNbrInfo = VLIB_GetNbrGnbCellInfoBasedOnCgi(ptCi, ptSCell->cgi, ptSCell->gnbIdLength);
    VALID_E_POINT_CHECK_ERROR(ptScellNbrInfo);

    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    VccbCellInfo_type *const pCells = CELLINFO;

    uint16_t psCellIdentity = VLIB_NrCellId2CellId(ptPCell->gnbIdLength, ptPCell->cgi.ci);
    VCCB_CHECK_E_RANGE_AND_RETURN(psCellIdentity, MAX_CELL_IDENTITY);
    uint16_t spCellNum = pGnb->env.cellNum[psCellIdentity];
    VCCB_CHECK_E_RANGE_AND_RETURN(spCellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &pCells[spCellNum];

    uint32_t gnbId = VLIB_NrCellId2GnbId(ptSCell->gnbIdLength, ptSCell->cgi.ci);
    if (VCCB_IS_SAME_GNB(gnbId, ptSCell->cgi.plmn.longId, ptCi->gnbNum))
    {
        uint16_t sCellIdentity = VLIB_NrCellId2CellId(ptSCell->gnbIdLength, ptSCell->cgi.ci);
        VCCB_CHECK_E_RANGE_AND_RETURN(sCellIdentity, MAX_CELL_IDENTITY);
        cellNum = pGnb->env.cellNum[sCellIdentity];
        VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);
        VccbCellInfo_type *const pSCell = &pCells[cellNum];

        const bool skipMibBarredCheck = true;
        if (!VLIB_CheckCellInService_Ca(ptCi, cellNum, skipMibBarredCheck))
        {
            VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu) not in service\n", 1ULL * ptSCell->cgi.ci);
            return BREAK;
        }

        if ((TRUE != pSCell->nrCarrierAggregationInfo.allowCellBarredScell) &&
            (NRRRC_barred == pSCell->mib.cellBarred))
        {
            VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu) is barred and not allowed\n", 1ULL * ptSCell->cgi.ci);
            return BREAK;

        }
    }
    else
    {
        if (!VLIB_IsCellEligibleForCA_interGnb(ptCi, ptSCell, ptScellNbrInfo, pCell, spCellNum))
        {
            return BREAK;
        }

        cellNum = spCellNum; // to be used in VLIB_checkIntraNRChannelBWDl
    }

    if (0 != pCell->cuColocCellInfo.colocCellStateResetTimer)
    {
        colocCellEntries_type *pColocCell = VLIB_GetColocCellEntry(pCell, ptScellNbrInfo);
        if (nullptr != pColocCell)
        {
            if (VLIB_IsCaColocCellStatusAbnormal(pColocCell))
            {
                VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu) coloc cell status abnormal\n", 1ULL * ptSCell->cgi.ci);
                return BREAK;
            }
        }
        else if (GOOD != VLIB_CheckCandidateScellAgainstOMFailedCellList(ptCi, spCellNum, ptSCell))
        {
            VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu) on omFailedCells list\n", 1ULL * ptSCell->cgi.ci);
            return BREAK;
        }

    }

    if ((0 == ptSCell->frequencyBand) ||
        GOOD != VLIB_checkIntraNRChannelBWDl(ptCi, ptScellNbrInfo, ptSCell->frequencyBand, cellNum, FALSE))
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu), frequencyBand(%u) no BW match with UE\n",
            1ULL * ptSCell->cgi.ci, ptSCell->frequencyBand);
        return BREAK;
    }

    if ((TRUE == pGnb->carrierAggregationInfo.plmnInfoCheck) &&
        (FALSE == VLIB_CheckNeighborPlmn(ptCi->ueInfo.servedPlmn.longId, ptScellNbrInfo)))
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: Served PLMN(%u) doesn't exists in SCell ci(%llu) PLMNs\n",
            ptCi->ueInfo.servedPlmn.longId, 1ULL * ptSCell->cgi.ci);
        return BREAK;
    }

    status = VLIB_findFailedCell(&ptCi->caInfo.failures, &ptSCell->cgi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, " VLIB_findFailedCell ERROR!\n");
    if (GOOD == status)
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(
            ptCi, "CA: sCell ci(%llu) is on failedCell list, cannot be selected\n", 1ULL * ptSCell->cgi.ci);
        return BREAK;
    }

    if (E_CALLTYPE_NSA == ptCi->callType)
    {
        status = VLIB_IsCellEligibleForCaENDC(ptCi, ptPCell, ptSCell);
    }
    else
    {
        status = VLIB_IsCellEligibleForCaSA(ptCi, spCellNum, ptPCell, ptSCell, ptScellNbrInfo);
    }

    return status;
}

/**
 * @brief     From all UE supported Cell bands chose first which is supported by filtered Band Combinations and not blocked.
 *            Set it in ptSCell->frequencyBand.
 * @param[in]      ptCi : call context
 * @param[in]      pCellBand : pCell nr band
 * @param[in]      filteredBcIndexes : Band combination indexes
 * @param[in/out]  ptSCell :  sCell info caCellInfo_type
 * @return    GOOD/ERROR(none of bands supported in filtered band combinations) /int16_t
 */
int16_t VLIB_selectProperBand(callInfo_type *ptCi, const uint16_t pCellBand, const bcIdxArray_type &filteredBcIndexes, caCellInfo_type *ptSCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptSCell);

    uint8_t bandIdx = 0;

    for (bandIdx = 0; bandIdx < ptSCell->bandListNum; ++bandIdx)
    {
        if (GOOD != VCCB_checkIfBandNrFitsForFilteredBc(ptCi, pCellBand, ptSCell->bandList[bandIdx], filteredBcIndexes))
        {
            VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: SCell ci(%llu) Band(%u) doesn't fit to filtered BCs\n",
                    1ULL * ptSCell->cgi.ci, ptSCell->bandList[bandIdx]);
            continue;
        }

        if (GOOD != VCCB_checkIfBandNotBlocked(ptCi, pCellBand, ptSCell->bandList[bandIdx]))
        {
            VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: SCell ci(%llu) Band(%u) is blocked\n",
                    1ULL * ptSCell->cgi.ci, ptSCell->bandList[bandIdx]);
            continue;
        }

        if (GOOD != FnVCCB_CheckIfBandInAllowedBandList(*ptCi, ptSCell->bandList[bandIdx]))
        {
            FnVCCB_SetSCellCslRelCauseByCuTrigger(ptCi, ca_csl_CU_CA_control);
            VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: SCell ci(%llu) Band(%u) is not allowed\n",
                    1ULL * ptSCell->cgi.ci, ptSCell->bandList[bandIdx]);
            continue;
        }

        ptSCell->frequencyBand = ptSCell->bandList[bandIdx];
        break;
    }

    if (bandIdx >= ptSCell->bandListNum)
    {
        return ERROR;
    }

    return GOOD;
}

/**
 * @brief     Check if cell can be sCell candidate
 * @details   Check if cell fulfill all criteria to be selected to CA operation.
 * @param     ptCi : call context
 * @param     ptNbrInfo : pointer to sCell candidate neighbor info
 * @param     filteredBcIndexes : Band combination indexes of scell candidates
 * @param[out] ptSCellCandidate : pointer to caCellInfo_type structure which should be filled with eligible cell info
 * @return    GOOD: cell can be selected to CA operation, BREAK: cell cannot be selected to CA operation, ERROR
 */
int16_t VLIB_VerifyIfCellEligibleForCaWithSCellCandidate(callInfo_type *ptCi, nbrGnbCellInfo_type *ptNbrInfo,
    const bcIdxArray_type &filteredBcIndexes, caCellInfo_type *ptSCellCandidate)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptNbrInfo);
    VALID_E_POINT_CHECK_ERROR(ptSCellCandidate);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);

    cellSelection_type cellSelection = FnVCCB_GetCellSelectionForConfig(ptCi);
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellSelection.cellNum);

    caCellInfo_type pCell;
    int16_t status = VLIB_FillPcellCaCellInfo(ptCi, cellSelection, pCell);
    if (GOOD != status)
    {
        return BREAK;
    }

    cgi_type cgi;
    cgi.ci = VLIB_GnbIdCellId2NrCellId(&ptNbrInfo->globalGnbId.gnbId, ptNbrInfo->cellId);
    cgi.plmn.longId = ptNbrInfo->globalGnbId.plmn.longId;
    status = VLIB_FillCaCellInfo(ptCi, cellSelection.cellNum, cgi, ptNbrInfo->globalGnbId.gnbId.idLength, *ptSCellCandidate);
    if (GOOD != status)
    {
        return BREAK;
    }

    if (GOOD != VLIB_selectProperBand(ptCi, pCell.frequencyBand, filteredBcIndexes, ptSCellCandidate))
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu) none of cell bands supported in BC\n",
                1ULL * ptSCellCandidate->cgi.ci);
        return BREAK;
    }

    status = VLIB_IsCellEligibleForCA(ptCi, &pCell, ptSCellCandidate, filteredBcIndexes);
    if (GOOD != status)
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: Cell pci(%u) not eligible for CA\n", ptNbrInfo->nrPci);
    }

    return status;
}

/**
 * @brief     Fill information for newly added scell
 * @param     rCall : call context
 * @param     rScellInfo : pointer to scellInfo_type to be filled
 * @param     cgi : scell cgi
 * @param     gnbIdLength : length of gnb ID
 * @parma     bandNr : scell band
 */
void VLIB_FillNewScellInfo(callInfo_type &rCall, scellInfo_type &rScellInfo, const cgi_type cgi, const uint8_t gnbIdLength, const uint16_t bandNr)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_VALID_GNBNUM_VOID(rCall.gnbNum);

    uint16_t spCellNum = FnVCCB_GetCellSelectionForConfig(&rCall).cellNum;

    nbrGnbCellInfo_type *ptNbrGnbCell = VLIB_GetNbrGnbCellInfoBasedOnCgi(&rCall, cgi, gnbIdLength);
    VALID_E_POINT_CHECK_VOID(ptNbrGnbCell);
    const uint32_t gnbId = VLIB_NrCellId2GnbId(gnbIdLength, cgi.ci);
    if (VCCB_IS_SAME_GNB(gnbId, cgi.plmn.longId, rCall.gnbNum))
    {
        const uint16_t sCellIdentity = VLIB_NrCellId2CellId(gnbIdLength, cgi.ci);
        VCCB_CHECK_E_RANGE_AND_VOID(sCellIdentity, MAX_CELL_IDENTITY);
        const uint16_t sCellNum = GNBINFO[rCall.gnbNum].env.cellNum[sCellIdentity];
        VCCB_CHECK_VALID_CELLNUM_VOID(sCellNum);
        rScellInfo.ssbSubcarrierSpacing = CELLINFO[sCellNum].measurementsData.measurementObjectsNRDb[INTRAFREQ_OBJECT_IDX].
                                                base.ssbSubcarrierSpacing & e_BitMask_3bit;
    }
    else
    {
        rScellInfo.ssbSubcarrierSpacing = ptNbrGnbCell->nrScsDl & e_BitMask_3bit;
    }

    rScellInfo.state = SCELL_STATE_ADDED;
    rScellInfo.action = SCELL_ACTION_SETUP;
    rScellInfo.isActionQueued = FALSE;
    rScellInfo.cellMoId = 0;
    rScellInfo.newMoIdx = MAX_NR_OF_OBJECT_ID;
    rScellInfo.cgi = cgi;
    rScellInfo.pci = ptNbrGnbCell->nrPci & e_BitMask_10bit;
    rScellInfo.nrArfcn = ptNbrGnbCell->nrArfcnDl & e_BitMask_22bit;
    rScellInfo.ssbArfcn = ptNbrGnbCell->ssbArfcn & e_BitMask_22bit;

    if (!IS_VALID_NR_BAND(bandNr))
    {
        rScellInfo.bandNr = VLIB_GetFreqBandIndForNeighborServingCell(&rCall, ptNbrGnbCell) & e_BitMask_11bit;
    }
    else
    {
        rScellInfo.bandNr = bandNr & e_BitMask_11bit;
    }

    rScellInfo.nrScsDl = ptNbrGnbCell->nrScsDl & e_BitMask_3bit;
    rScellInfo.nrbDl = ptNbrGnbCell->nrbDl & e_BitMask_5bit;
    rScellInfo.gnbIdLength = gnbIdLength & e_BitMask_6bit;
    rScellInfo.servCellSsbRsrp = UNKNOWN_RSRP;
    rScellInfo.bandwidthDl = ptNbrGnbCell->bandwidthDl;
    rScellInfo.bandwidthUl = ptNbrGnbCell->bandwidthUl;
    rScellInfo.sCellIndex = 0;
    rScellInfo.shouldFollowA2Quantity = FALSE;
    if ((CI_use == ptNbrGnbCell->ssbMeasurementConfiguration.usage) &&
        (0 == ptNbrGnbCell->ssbMeasurementConfiguration.ssbValue))
    {
        rScellInfo.isCellSSB = FALSE;
    }
    else
    {
        rScellInfo.isCellSSB = TRUE;
    }
    rScellInfo.addRelCause = CaSCellAddAtt_Blind;  // during init it is always blind
    rScellInfo.blind = TRUE;
    rScellInfo.ignoreNextPeriodic = TRUE;
    rScellInfo.sccFlag_cellMeasured = FALSE;

    if ((MAX_NR_ARFCN != ptNbrGnbCell->nrArfcnUl) &&
        (GOOD == VLIB_checkIntraNRChannelBWUl(&rCall, ptNbrGnbCell, rScellInfo.bandNr, spCellNum, TRUE)))
    {
        rScellInfo.isUlBwSupported = TRUE;
    }
    else
    {
        rScellInfo.isUlBwSupported = FALSE;
    }
}

/**
 * @brief     Fill information for newly added scell
 * @param     ptCi : call context
 * @param     ptScellInfo : pointer to scellInfo_type to be filled
 * @param     ptSCell : sCell info caCellInfo_type
 */
void VLIB_FillNewScellInfo(callInfo_type *ptCi, scellInfo_type *ptScellInfo, caCellInfo_type *ptSCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptSCell);
    VALID_E_POINT_CHECK_VOID(ptScellInfo);

    VLIB_FillNewScellInfo(*ptCi, *ptScellInfo, ptSCell->cgi, ptSCell->gnbIdLength, ptSCell->frequencyBand);
}

/**
 * @brief Check if specific Scell of callInfo has the scellAltBand information in the sccData of callInfo
 *        and return the true if it needs to be updated with the AltBand information
 */
bool VLIB_needUpdateToAltBand(const callInfo_type &rCall, const scellInfo_type &rScell, const uint8_t scellAltBandIdx)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(scellAltBandIdx, MAX_MCO_MFBI_CELLS, false);

    if( UNKNOWN_ARFCN == rCall.sccData.scellAltBandSsbArfcn[scellAltBandIdx] )
        return false;

    if( BAND_NOT_FOUND == rCall.sccData.scellAltBand[scellAltBandIdx] )
        return false;

    if( rScell.ssbArfcn != rCall.sccData.scellAltBandSsbArfcn[scellAltBandIdx] )
        return false;

    if( rScell.bandNr == rCall.sccData.scellAltBand[scellAltBandIdx] )
        return false;

    return true;
}

/**
 * @brief Check if there is a match the band information of neighbor gnb cells and the specific scellAltBand of sccData
 */
bool VLIB_AltBandInNeighborCellsFreqBandIndList(callInfo_type *ptCi, const nbrGnbCellInfo_type *ptTgtNbrGnbCell, const uint8_t scellAltBandIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptTgtNbrGnbCell, false);
    VCCB_CHECK_E_RANGE_AND_VAL(scellAltBandIdx, MAX_MCO_MFBI_CELLS, false);

    uint16_t bandList[MAX_FREQBAND_PER_CELL];
    const uint8_t bandListNum = VLIB_GetFreqBandIndListForNeighborCellWithCustomSpCell(
        ptCi, ptTgtNbrGnbCell, ptCi->servCellNum, false, bandList);

    for(uint8_t bandIdx = 0; bandIdx < bandListNum; bandIdx++)
    {
        if(bandList[bandIdx] == ptCi->sccData.scellAltBand[scellAltBandIdx])
        {
            return true;
        }
    }

    return false;
}

/**
 * @brief Function to return bandNr after determining whether sCell altBand setting is valid in sccData
 */
uint16_t VLIB_GetAlternativeNrBand(callInfo_type *ptCi, const nbrGnbCellInfo_type *ptTgtNbrGnbCell, const uint16_t scellIdx, const uint8_t scellAltBandIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, BAND_NOT_FOUND);
    VALID_E_POINT_CHECK_RET_VAL(ptTgtNbrGnbCell, BAND_NOT_FOUND);
    VCCB_CHECK_E_RANGE_AND_VAL(scellIdx, MAX_SCELL_PER_CALL, BAND_NOT_FOUND);
    VCCB_CHECK_E_RANGE_AND_VAL(scellAltBandIdx, MAX_MCO_MFBI_CELLS, BAND_NOT_FOUND);

    if (VLIB_needUpdateToAltBand(*ptCi, ptCi->sCell[scellIdx], scellAltBandIdx))
    {
        if (VLIB_AltBandInNeighborCellsFreqBandIndList(ptCi, ptTgtNbrGnbCell, scellAltBandIdx))
        {
            VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] Scell[%d]:band(%d), Find sccData altBand[%d]:band(%d)\n",
                scellIdx, ptCi->sCell[scellIdx].bandNr, scellAltBandIdx, ptCi->sccData.scellAltBand[scellAltBandIdx]);
            return ptCi->sccData.scellAltBand[scellAltBandIdx];
        }
    }

    return BAND_NOT_FOUND;
}

/**
 * @brief     Fill information for scell info during SCC gathering (if needed).
 *            Scells will be proposed after timer expiration
 * @param     ptCi : call context
 * @param     ptTgtNbrGnbCell : pointer to target cell
 * @return    GOOD/BREAK/ERROR /int16_t
 */
int16_t VLIB_FillInfoForScellDuringSccGathering(callInfo_type *ptCi, const nbrGnbCellInfo_type *ptTgtNbrGnbCell,
    const measResultList2NR_type *ptMeasResults, const measurementObjectUe_type *pMeasObj,
    const reportConfigurationInstalledUe_type *pReportConfig)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptTgtNbrGnbCell);
    VALID_E_POINT_CHECK_ERROR(ptMeasResults);
    VALID_E_POINT_CHECK_ERROR(pMeasObj);
    VALID_E_POINT_CHECK_ERROR(pReportConfig);

    SccA4MrManager scc(*ptCi, *ptTgtNbrGnbCell, *ptMeasResults, *pMeasObj, *pReportConfig);

    if (scc.sCellInfoUpdate() == GOOD)
    {
        if (scc.checkTriggerSccChange())
        {
            VCCB_PRINT_LOG_MCO_SCC(ptCi, "[SCC] All A4 MR(Scell Addition) received!! sccGatheringTimer Cancel !!\n");
            VCCB_CLEAR_TIMER(&ptCi->sccData.sccGatheringTimer, CANCEL_TIMER);
            FnVCCB_SccGatheringTimerExpired(ptCi);
        }
        return GOOD;
    }
    return BREAK;
}

/**
 * @brief     Fill information after selecting target cell in ScellAddition procedure
 * @param     ptCi : call context
 * @param     ptTgtNbrGnbCell : pointer to target cell
 * @param     scellIdx : sCell index for which measurement was installed
 * @param     frequencyBand : sCell NR band
 * @param     rsrp : measured sCell SSB RSRP
 * @return    GOOD(scell setup) or BREAK(no action) or ERROR /int16_t
 */
int16_t VLIB_FillInfoForScellAddition(callInfo_type *ptCi, const nbrGnbCellInfo_type *ptTgtNbrGnbCell, uint8_t scellIdx,
    const uint16_t frequencyBand, const uint8_t rsrp)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptTgtNbrGnbCell);
    VCCB_CHECK_E_RANGE_AND_RETURN(scellIdx, MAX_SCELL_PER_CALL);

    cgi_type tgtCgi;
    tgtCgi.ci = VLIB_GnbIdCellId2NrCellId(&ptTgtNbrGnbCell->globalGnbId.gnbId, ptTgtNbrGnbCell->cellId);
    tgtCgi.plmn.longId = ptTgtNbrGnbCell->globalGnbId.plmn.longId;

    if ((tgtCgi.ci == ptCi->sCell[scellIdx].cgi.ci) &&
        (tgtCgi.plmn.longId == ptCi->sCell[scellIdx].cgi.plmn.longId))  // sCell[scellIdx] match to target cell data
    {
        ptCi->sCell[scellIdx].state = SCELL_STATE_ADDED;
        ptCi->sCell[scellIdx].action = SCELL_ACTION_SETUP;
    }
    else  // sCell[scellIdx] should be filled with target cell data
    {
        VLIB_FillNewScellInfo(*ptCi, ptCi->sCell[scellIdx], tgtCgi, ptTgtNbrGnbCell->globalGnbId.gnbId.idLength, frequencyBand);
    }

    if ((CcLimit_Released == ptCi->caInfo.componentCarriersLimit) && (GOOD == VLIB_IsCcLimitExceeded(ptCi, false)))
    {
        ptCi->sCell[scellIdx].state = SCELL_STATE_CCLIMITREL;
        ptCi->sCell[scellIdx].action = SCELL_ACTION_KEEP;
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: sCell not add idx(%u)/pci(%u)/(%llu) CcLimitation\n",
                scellIdx, ptCi->sCell[scellIdx].pci, 1ULL * ptCi->sCell[scellIdx].cgi.ci);
        return BREAK;
    }

    ptCi->sCell[scellIdx].isActionQueued = TRUE;

    VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell added idx(%u)/pci(%u)/ci(%llu)\n", scellIdx,
        ptCi->sCell[scellIdx].pci, 1ULL * ptCi->sCell[scellIdx].cgi.ci);

    ptCi->sCell[scellIdx].addRelCause = CaSCellAddAtt_EventA4;
    ptCi->sCell[scellIdx].blind = FALSE;
    ptCi->sCell[scellIdx].ignoreNextPeriodic = TRUE;
    ptCi->sCell[scellIdx].servCellSsbRsrp = rsrp;

    return GOOD;
}

/**
 * @brief     Fill information after selecting target cell in ScellChange procedure
 * @param[in]    ptCi : call context
 * @param[in]    ptTgtNbrGnbCell : pointer to target cell
 * @param[in]    sourceSCellIdx : sCell to be released index
 * @param[in]    frequencyBand : sCell NR band
 * @param[in]    rsrp : measured sCell SSB RSRP
 * @return    GOOD or BREAK or ERROR /int16_t
 */
int16_t VLIB_FillInfoForScellChange(callInfo_type *ptCi, const nbrGnbCellInfo_type *ptTgtNbrGnbCell, uint8_t sourceScellIdx,
    const uint16_t frequencyBand, const uint8_t rsrp)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptTgtNbrGnbCell);
    VCCB_CHECK_E_RANGE_AND_RETURN(sourceScellIdx, MAX_SCELL_PER_CALL);

    uint8_t cellIdx = 0;

    // find free cellIdx
    for (cellIdx = 0; cellIdx < MAX_SCELL_PER_CALL; ++cellIdx)
    {
        if ((ptCi->sCell[cellIdx].state == SCELL_STATE_RELEASED) && (ptCi->sCell[cellIdx].action == SCELL_ACTION_KEEP))
        {
            break;
        }
    }

    if (MAX_SCELL_PER_CALL <= cellIdx)
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(
            ptCi, "CA: no available sCell!! MAX_SCELL_PER_CALL(%d) ACTIVATED\n", MAX_SCELL_PER_CALL);
        return BREAK;
    }

    cgi_type tgtCgi;
    tgtCgi.ci = VLIB_GnbIdCellId2NrCellId(&ptTgtNbrGnbCell->globalGnbId.gnbId, ptTgtNbrGnbCell->cellId);
    tgtCgi.plmn.longId = ptTgtNbrGnbCell->globalGnbId.plmn.longId;

    VLIB_FillNewScellInfo(*ptCi, ptCi->sCell[cellIdx], tgtCgi, ptTgtNbrGnbCell->globalGnbId.gnbId.idLength, frequencyBand);

    // mark old to release
    ptCi->sCell[sourceScellIdx].state = SCELL_STATE_RELEASED;
    ptCi->sCell[sourceScellIdx].action = SCELL_ACTION_RELEASE;

    ptCi->sCell[sourceScellIdx].isActionQueued = TRUE;
    ptCi->sCell[cellIdx].isActionQueued = TRUE;

    ptCi->sCell[sourceScellIdx].addRelCause = CaSCellRel_EventA6;
    ptCi->sCell[cellIdx].addRelCause = CaSCellAddAtt_EventA6;
    ptCi->sCell[cellIdx].blind = FALSE;
    ptCi->sCell[cellIdx].servCellSsbRsrp = rsrp;

    FnVCCB_SetSCellCslRelCauseByCuTrigger(ptCi, ca_csl_CU_eventA6);

    VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi,
        "CA: SCell change from idx(%u,%u)/pci(%u)/ci(%llu) to idx(%u)/pci(%u)/ci(%llu)\n",
        sourceScellIdx, ptCi->sCell[sourceScellIdx].sCellIndex, ptCi->sCell[sourceScellIdx].pci, 1ULL * ptCi->sCell[sourceScellIdx].cgi.ci,
        cellIdx, ptCi->sCell[cellIdx].pci, 1ULL * ptCi->sCell[cellIdx].cgi.ci);
    return GOOD;
}

/**
 * @brief Decide if FR1-FR2 CA is available for current call
 * @param[in/out] ptCi  : call context
 * @param[in]     pCell : pointer to primary cell CellInfo
 */
void VLIB_SetIsFR1FR2CaAvailable(callInfo_type *ptCi, VccbCellInfo_type *const pCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pCell);

    ptCi->caInfo.isFR1FR2CaAvailable = FALSE;

    // FR1-FR2 CA supported only for pure SA cells which doesn't support NR-DC and uses coloc-cell-info
    if ((FALSE == FOO.VF_CallProcedureforCarrierAggregation_FR1FR2CaSupport) || (MIN_A6_NR_ARFCN <= pCell->ssbArfcn) ||
        (VCCB_FLAG_ON == pCell->nrdcCellInfo.nrdcSupport) || (E_CALLTYPE_SA != ptCi->callType) || (IS_NRDC_SN(ptCi)) ||
        (CI_no_use == pCell->cuColocCellInfo.colocCellInfoUsage))
    {
        return;
    }

    uint16_t colocCellIdx = 0;
    cgi_type cgi;
    uint8_t gnbIdLength;
    nbrGnbCellInfo_type *ptCell = NULL;

    for (colocCellIdx = 0; colocCellIdx < MAX_COLOCCELL; ++colocCellIdx)
    {
        if ((CI_no_use == pCell->cuColocCellInfo.colocCellEntries[colocCellIdx].usage) ||
            (TRUE != pCell->cuColocCellInfo.colocCellEntries[colocCellIdx].useforNrca))
        {
            continue;
        }

        cgi.ci = VLIB_GnbIdCellId2NrCellId(&pCell->cuColocCellInfo.colocCellEntries[colocCellIdx].globalGnbId.gnbId,
            pCell->cuColocCellInfo.colocCellEntries[colocCellIdx].cellId);
        cgi.plmn = pCell->cuColocCellInfo.colocCellEntries[colocCellIdx].globalGnbId.plmn;
        gnbIdLength = pCell->cuColocCellInfo.colocCellEntries[colocCellIdx].globalGnbId.gnbId.idLength;

        ptCell = VLIB_GetNbrGnbCellInfoBasedOnCgi(ptCi, cgi, gnbIdLength);
        VALID_E_POINT_CHECK_CONTINUE(ptCell);

        if (MIN_A6_NR_ARFCN <= ptCell->ssbArfcn)
        {
            ptCi->caInfo.isFR1FR2CaAvailable = TRUE;
            break;
        }
    }

}

void VLIB_BcIndexesPrint(callInfo_type *ptCi, const bcIdxArray_type &filteredBcIndexes)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    std::stringstream output;
    std::copy(filteredBcIndexes.begin(), filteredBcIndexes.end(), std::ostream_iterator<uint32_t>(output, ","));
    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "CA: bcIdx: [%s]\n", output.str().c_str());

    return;
}

void VLIB_BandsFromBcIndexesPrint(
    callInfo_type *ptCi, const bandCombinationList_type *pBandCombinationList, const bcIdxArray_type &filteredBcIndexes)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pBandCombinationList);

    staticUnorderedSet<uint32_t, MAX_BAND_COMBS> bandsSet;

    std::stringstream output;
    for (uint32_t bcIndex : filteredBcIndexes)
    {
        const BandCombination_type *pUeSupportedBandCombination = &pBandCombinationList->bandCombination[bcIndex];
        for (uint32_t bandIdx = 0; bandIdx < pUeSupportedBandCombination->num; bandIdx++)
        {
            bandsSet.insert(pUeSupportedBandCombination->band[bandIdx].freqBandIndicator);
        }
    }
    std::copy(bandsSet.begin(), bandsSet.end(), std::ostream_iterator<uint32_t>(output, ","));

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "CA: Band [%s]\n", output.str().c_str());

    return;
}

const char *getNrBandClass(uint8_t bandClass)
{
    switch (bandClass)
    {
        case CA_BandwidthClassNR_NOT_SET : return "*";
        case CA_BandwidthClassNR_a : return "A";
        case CA_BandwidthClassNR_b : return "B";
        case CA_BandwidthClassNR_c : return "C";
        case CA_BandwidthClassNR_d : return "D";
        case CA_BandwidthClassNR_e : return "E";
        case CA_BandwidthClassNR_f : return "F";
        case CA_BandwidthClassNR_g : return "G";
        case CA_BandwidthClassNR_h : return "H";
        case CA_BandwidthClassNR_i : return "I";
        case CA_BandwidthClassNR_j : return "J";
        case CA_BandwidthClassNR_k : return "K";
        case CA_BandwidthClassNR_l : return "L";
        case CA_BandwidthClassNR_m : return "M";
        case CA_BandwidthClassNR_n : return "N";
        case CA_BandwidthClassNR_o : return "O";
        case CA_BandwidthClassNR_p : return "P";
        case CA_BandwidthClassNR_q : return "Q";
        case CA_BandwidthClassNR_r2 : return "R2";
        case CA_BandwidthClassNR_r3 : return "R3";
        case CA_BandwidthClassNR_r4 : return "R4";
        case CA_BandwidthClassNR_r5 : return "R5";
        case CA_BandwidthClassNR_r6 : return "R6";
        case CA_BandwidthClassNR_r7 : return "R7";
        case CA_BandwidthClassNR_r8 : return "R8";
        case CA_BandwidthClassNR_r9 : return "R9";
        case CA_BandwidthClassNR_r10 : return "R10";
        case CA_BandwidthClassNR_r11 : return "R11";
        case CA_BandwidthClassNR_r12 : return "R12";
        default : break;
    }

    return "?";
}

void VLIB_BandCombFromBcIndexesPrint(
    callInfo_type *ptCi, const bandCombinationList_type *pBandCombinationList, const bcIdxArray_type &filteredBcIndexes)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pBandCombinationList);

    uint16_t band;
    uint8_t dlClass, ulClass, numContiguousCcDL, numContiguousCcUL;

    std::string outputStr;
    std::string tmpStr;

    for (uint32_t bcIndex : filteredBcIndexes)
    {
        if (MAX_BAND_COMBS <= bcIndex)
        {
            continue;
        }

        const BandCombination_type *pUeSupportedBandCombination = &pBandCombinationList->bandCombination[bcIndex];

        uint8_t bandCount = MIN(pUeSupportedBandCombination->num, MAX_BANDS_PER_COMB);

        for (uint8_t bandIdx = 0; bandIdx < bandCount; bandIdx++)
        {
            band = pUeSupportedBandCombination->band[bandIdx].freqBandIndicator;

            if (pUeSupportedBandCombination->band[bandIdx].ratType == ci_nr)
            {
                dlClass = pUeSupportedBandCombination->band[bandIdx].nrCaBandwidthClassDL;
                ulClass = pUeSupportedBandCombination->band[bandIdx].nrCaBandwidthClassUL;

                tmpStr = "n" + std::to_string(band) + "("+ getNrBandClass(dlClass) + "/" + getNrBandClass(ulClass) +  ")";
            }
            else if(pUeSupportedBandCombination->band[bandIdx].ratType == ci_eutra)
            {
                numContiguousCcDL = pUeSupportedBandCombination->band[bandIdx].numContiguousCcDL;
                numContiguousCcUL = pUeSupportedBandCombination->band[bandIdx].numContiguousCcUL;

                tmpStr = "e" + std::to_string(band) + "("+ std::to_string(numContiguousCcDL) + "/" + std::to_string(numContiguousCcUL) +  ")";
            }
            else
            {
                // Invalid Case
                continue;
            }

            if (bandIdx+1 < pUeSupportedBandCombination->num)
            {
                tmpStr.append("-");
            }

            outputStr += tmpStr;
        }

        VCCB_PRINT_CALL_INFORMATIVE(ptCi, " bcIdx[%2d] %s\n", bcIndex, outputStr.c_str());
        outputStr.clear();
    }

    return;
}

/**
 * @brief     Get BC indexes filtered by pCell Band. Function valid for non MRDC case or when allowedBC not received.
 * @param[in]   ptCi : call context
 * @param[in]   pBandCombinationList : pointer to UE supported band combinations
 * @param[in]   pcellBandNR : band of selected pCell
 * @param[out]  filteredBcIndexes : BC indexes filtered by pCell Band
 * @return    GOOD : success, at least 1 valid BC index found.
 * @return    ERROR : failure or no valid indexes found.
 */
int16_t VLIB_getBcIndexesFilteredByPcell(
    callInfo_type *ptCi, const bandCombinationList_type *pBandCombinationList, uint32_t pcellBandNR,
    bcIdxArray_type &filteredBcIndexes)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pBandCombinationList);

    filteredBcIndexes.clear();

    // 3. Filter by pCell band
    for (uint32_t bcIdx = 0; bcIdx < MIN(pBandCombinationList->num, MAX_BAND_COMBS); bcIdx++)
    {
        const BandCombination_type *pUeSupportedBandCombination = &pBandCombinationList->bandCombination[bcIdx];
        for (uint32_t bandIdx = 0; bandIdx < MIN(pUeSupportedBandCombination->num, MAX_BANDS_PER_COMB); bandIdx++)
        {
            if (pUeSupportedBandCombination->band[bandIdx].ratType != ci_nr)
            {
                continue;
            }

            if (pUeSupportedBandCombination->band[bandIdx].freqBandIndicator == pcellBandNR)
            {
                if ((CA_BandwidthClassNR_NOT_SET != pUeSupportedBandCombination->band[bandIdx].nrCaBandwidthClassDL) &&
                    (CA_BandwidthClassNR_NOT_SET != pUeSupportedBandCombination->band[bandIdx].nrCaBandwidthClassUL))
                {
                    filteredBcIndexes.push_back(bcIdx);
                    break;
                }
            }
        }
    }

    if(DBG->flag.logCaExtended)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "CA: bcIndexes filtered by pcell band(%u). \n", pcellBandNR);
        VLIB_BcIndexesPrint(ptCi, filteredBcIndexes);
        VLIB_BandCombFromBcIndexesPrint(ptCi, pBandCombinationList, filteredBcIndexes);
    }

    return GOOD;
}

/**
 * @brief     Get allowed BC indexes filtered by pCell Band. Function valid for SN case.
 * @param[in]   ptCi : call context
 * @param[in]   pBandCombinationList : pointer to UE supported band combinations
 * @param[in]   pcellBandNR : band of selected pCell
 * @param[out]  filteredBcIndexes : BC indexes filtered by pCell Band
 * @return    GOOD : success, at least 1 valid BC index found.
 * @return    ERROR : failure or no valid indexes found.
 */
int16_t VLIB_getAllowedBcIndexesFilteredByPcell(
    callInfo_type *ptCi, const bandCombinationList_type *pBandCombinationList, uint32_t pcellBandNR,
    bcIdxArray_type &filteredBcIndexes)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pBandCombinationList);

    filteredBcIndexes.clear();

    const bandCombinationInfoList_type &allowedBC = ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC;
    const uint16_t allowedBcNum = MIN(allowedBC.nrofBandComb, MAX_NUM_BAND_COMB);

    for (uint32_t allowedBcIdx = 0; allowedBcIdx < allowedBcNum; allowedBcIdx++)
    {
        uint32_t bcIdx = static_cast<uint32_t>(allowedBC.bandCombinationInfo[allowedBcIdx].bandCombinationIndex - 1);
        VCCB_CHECK_E_RANGE_AND_CONTINUE(bcIdx, MAX_BAND_COMBS);
        const BandCombination_type *pUeSupportedBandCombination = &pBandCombinationList->bandCombination[bcIdx];
        for (uint32_t bandIdx = 0; bandIdx < MIN(pUeSupportedBandCombination->num, MAX_BANDS_PER_COMB); bandIdx++)
        {
            if (pUeSupportedBandCombination->band[bandIdx].ratType != ci_nr)
            {
                continue;
            }
            if (pUeSupportedBandCombination->band[bandIdx].freqBandIndicator == pcellBandNR)
            {
                if ((CA_BandwidthClassNR_NOT_SET != pUeSupportedBandCombination->band[bandIdx].nrCaBandwidthClassDL) &&
                    (CA_BandwidthClassNR_NOT_SET != pUeSupportedBandCombination->band[bandIdx].nrCaBandwidthClassUL))
                {
                    filteredBcIndexes.push_back(bcIdx);
                    break;
                }
            }
        }
    }

    if(DBG->flag.logCaExtended)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "CA: Allowed bcIndexes filtered by pcell band. \n");
        VLIB_BcIndexesPrint(ptCi, filteredBcIndexes);
        VLIB_BandCombFromBcIndexesPrint(ptCi, pBandCombinationList, filteredBcIndexes);
    }

    return GOOD;
}

/**
 * @brief     filter BC indexes additionally by coloc cells confiuration depending on configured scell Frequency
 * profiles
 * @param[in]   ptCi : call context
 * @param[in]   spCellNum : serving primary cell num
 * @param[in]   pBandCombinationList : pointer to UE supported band combinations
 * @param[in]   filteredBcIndexesByPcell : BC indexes previously filtered by pCell Band
 * @param[out]  filteredBcIndexesByPcellAndColocCells : Filtered BC indexes by pCell Band and coloc cells (depending on
 * configured scell Frequency profiles) using priority based scell selection.
 * @return    GOOD : success, at least 1 valid BC index found.
 * @return    ERROR : failure or no valid indexes found.
 */
int16_t VLIB_filterBcIndexesByPcellAndColocCells(callInfo_type *ptCi, uint16_t spCellNum,
    const bandCombinationList_type *pBandCombinationList,
    const bcIdxArray_type &filteredBcIndexesByPcell,
    bcIdxArray_type &filteredBcIndexesByPcellAndColocCells)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pBandCombinationList);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    VCCB_CHECK_VALID_CELLNUM_ERROR(spCellNum);

    staticUnorderedSet<uint32_t, MAX_BAND_COMBS> bcIndexesToFilter;
    staticUnorderedSet<uint32_t, MAX_BAND_COMBS> bcIndexesToRemove;

    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    VccbCellInfo_type *const pCell = &CELLINFO[spCellNum];

    uint8_t scellFreqPrioProfileIdx = pCell->nrCarrierAggregationInfo.scellFreqPrioProfileIdx;
    VCCB_CHECK_E_RANGE_AND_RETURN(scellFreqPrioProfileIdx, MAX_SCELL_FREQ_PRIORITY_PROFILES);

    if (FnVCCB_IsNeedToCheckAllowedBand(*ptCi))
    {
        // allowed-band-list available, so don't filter based on scellFreq Priorities
        VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: allowed band is available. Skip sCellFreqPriorities(%u) \n", scellFreqPrioProfileIdx);
        return ERROR;
    }

    filteredBcIndexesByPcellAndColocCells.clear();

    for (uint32_t bcIndex : filteredBcIndexesByPcell)
    {
        bcIndexesToFilter.insert(bcIndex);
    }

    for (uint32_t scellFreqPrioIdx = 0; scellFreqPrioIdx < MAX_SCELL_FREQ_PRIORITIES; scellFreqPrioIdx++)
    {
        if (N_EQUIP == pGnb->carrierAggregationInfo.scellFreqPrioProfiles[scellFreqPrioProfileIdx]
                           .scellFreqPriorities[scellFreqPrioIdx]
                           .status)
        {
            continue;
        }
        for (uint32_t colocCellIdx = 0; colocCellIdx < MAX_COLOCCELL; colocCellIdx++)
        {
            if ((CI_no_use == pCell->cuColocCellInfo.colocCellEntries[colocCellIdx].usage) ||
                (TRUE != pCell->cuColocCellInfo.colocCellEntries[colocCellIdx].useforNrca))
            {
                continue;
            }

            cgi_type cgi;
            cgi.ci = VLIB_GnbIdCellId2NrCellId(&pCell->cuColocCellInfo.colocCellEntries[colocCellIdx].globalGnbId.gnbId,
                pCell->cuColocCellInfo.colocCellEntries[colocCellIdx].cellId);
            cgi.plmn = pCell->cuColocCellInfo.colocCellEntries[colocCellIdx].globalGnbId.plmn;
            uint8_t gnbIdLength = pCell->cuColocCellInfo.colocCellEntries[colocCellIdx].globalGnbId.gnbId.idLength;
            nbrGnbCellInfo_type *pColocCellNbrGnbCellInfo = VLIB_GetNbrGnbCellInfoBasedOnCgi(ptCi, cgi, gnbIdLength);
            VALID_E_POINT_CHECK_CONTINUE(pColocCellNbrGnbCellInfo);

            // A) Proper coloc-cell found basing on scellArfcn in scellFreqPriority
            if (pColocCellNbrGnbCellInfo->nrArfcnDl ==
                pGnb->carrierAggregationInfo.scellFreqPrioProfiles[scellFreqPrioProfileIdx]
                    .scellFreqPriorities[scellFreqPrioIdx]
                    .scellArfcn)
            {
                uint16_t colocCellFrequencyBand = VLIB_GetFreqBandIndForNeighborCell(ptCi, pColocCellNbrGnbCellInfo);
                if (BAND_NOT_FOUND == colocCellFrequencyBand)
                {
                    continue;
                }

                if(DBG->flag.logCaExtended)
                {
                    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "CA: found colocCell ssbArfcn(%u) band(%u) scellFreqPrioIdx(%u) \n",
                                                pColocCellNbrGnbCellInfo->ssbArfcn, colocCellFrequencyBand, scellFreqPrioIdx+1);
                }

                // B) Check if chosen coloc-cell does have available band combinations
                for (uint32_t bcIndex : bcIndexesToFilter)
                {
                    bool removeBcIndex = true;
                    const BandCombination_type *pUeSupportedBandCombination = &pBandCombinationList->bandCombination[bcIndex];
                    for (uint32_t bandIdx = 0; bandIdx < pUeSupportedBandCombination->num; bandIdx++)
                    {
                        // C) Keep all band combination indexes which does contain coloc-cell band
                        if (colocCellFrequencyBand == pUeSupportedBandCombination->band[bandIdx].freqBandIndicator)
                        {
                            removeBcIndex = false;
                            break;
                        }
                    }
                    if (removeBcIndex)
                    {
                        bcIndexesToRemove.insert(bcIndex);
                    }
                }
                // D) If no BC indexes were left, ignore last filtration iteration and proceed with next priority.
                if (bcIndexesToFilter.size() == bcIndexesToRemove.size())
                {
                    bcIndexesToRemove.clear();
                    break;
                }

                for (uint32_t bcIndex : bcIndexesToRemove)
                {
                    bcIndexesToFilter.erase(bcIndex);
                }
                bcIndexesToRemove.clear();

                // E) Return in case only 1 element left during filtration phases.
                if (1 == bcIndexesToFilter.size())
                {
                    for (uint32_t bcIndex : bcIndexesToFilter)
                    {
                        filteredBcIndexesByPcellAndColocCells.push_back(bcIndex);
                    }
                    return GOOD;
                }

                break;
            }
        }
    }

    for (uint32_t bcIndex : bcIndexesToFilter)
    {
        filteredBcIndexesByPcellAndColocCells.push_back(bcIndex);
    }

    return GOOD;
}

int16_t VLIB_getAllowedBcIndexesFilteredBySelectedBcIdx(
    callInfo_type *ptCi, const bandCombinationList_type *pBandCombinationList, bcIdxArray_type &filteredBcIndexes)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pBandCombinationList);

    filteredBcIndexes.clear();

    const bandCombinationInfoList_type &allowedBC = ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC;
    const uint16_t filteredAllowedBcNum = MIN(allowedBC.nrofBandCombFilteredSelectedBc, MAX_NUM_BAND_COMB);

    for (uint16_t allowedBcIdx = 0; allowedBcIdx < filteredAllowedBcNum; allowedBcIdx++)
    {
        uint32_t bcIdx = static_cast<uint32_t>(
            allowedBC.bandCombinationInfoFilteredSelectedBc[allowedBcIdx].bandCombinationIndex - 1);
        
        VCCB_CHECK_E_RANGE_AND_CONTINUE(bcIdx, MAX_BAND_COMBS);
        filteredBcIndexes.push_back(bcIdx);
    }

    if (DBG->flag.logCaExtended)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "CA: Allowed bcIndexes filtered by selectedBcIdx of SN. \n");
        VLIB_BcIndexesPrint(ptCi, filteredBcIndexes);
        VLIB_BandCombFromBcIndexesPrint(ptCi, pBandCombinationList, filteredBcIndexes);
    }

    return GOOD;
}

/**
 * @brief     Search, filter and get BC indexes using priority based scell selection feature.
 * @param[in]   ptCi : call context
 * @param[in]   spCellNum : serving primary cell num
 * @param[in]   pBandCombinationList : Stored Band Comibination List
 * @param[out]  filteredBcIndexes : Filtered BC indexes using priority based scell selection.
 *                                  Depending on yang configuration and call type returned indexes will be either:
 *                                    - Indexes filtered by Pcell Band
 *                                    - Indexes filtered by Pcell Band and coloc cells (depending on configured scell
 * Frequency profiles)
 *                                    - Single band combination index for NRDC_MN case
 * @return    GOOD : success, at least 1 valid BC index found.
 * @return    BREAK : success, but no valid indexes found.
 *
*/
int16_t VLIB_getBcIndexesUsingPrioBasedScellSelectCom(
    callInfo_type *ptCi, const uint16_t spCellNum, const uint16_t frequencyBand,
    bcIdxArray_type &filteredBcIndexes, const bandCombinationList_type *pBandCombinationList)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_VALID_CELLNUM_ERROR(spCellNum);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    VALID_E_POINT_CHECK_ERROR(pBandCombinationList);

    bcIdxArray_type bcIndexesByPcellBand;
    bcIdxArray_type bcIndexesByPcellBandAndColocCells;

    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    VccbCellInfo_type *const pCell = &CELLINFO[spCellNum];

    filteredBcIndexes.clear();
    bool isSCellFreqPrioProfAvailable = false;

    // 1. Get bands basing on call case and filter by pcell band
    if ((IS_MRDC_SN(ptCi)) &&
        (VCCB_FLAG_ON == ptCi->cgConfigInfo.configRestrictInfoFlag) &&
        (VCCB_FLAG_ON == ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC_Flag))
    {
        if (GOOD != VLIB_getAllowedBcIndexesFilteredByPcell(ptCi, pBandCombinationList, frequencyBand, bcIndexesByPcellBand))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Filtering bcIndexes By Pcell Failed.\n");
            return ERROR;
        }
    }
    else if ((IS_MRDC_MN(ptCi)) &&
             (IS_NOT_MRDC_SCG_RELEASE_ONGOING(ptCi)) &&
             (0 != ptCi->mrdcInfo.selectedBC.bandCombinationIndex))
    {
        if (0 == ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC.nrofBandCombFilteredSelectedBc)
        {
            uint32_t selectedBCIdx = ptCi->mrdcInfo.selectedBC.bandCombinationIndex-1;
            VCCB_CHECK_E_RANGE_AND_RETURN(selectedBCIdx, MAX_BAND_COMBS);
            filteredBcIndexes.push_back(selectedBCIdx);
    
            if(DBG->flag.logCaExtended)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "CA: NRDC selectedBCIdx(%u). \n", selectedBCIdx);
                VLIB_BandsFromBcIndexesPrint(ptCi, pBandCombinationList, filteredBcIndexes);
            }
            return GOOD;
        }
        else
        {
            if (GOOD != VLIB_getAllowedBcIndexesFilteredBySelectedBcIdx(ptCi, pBandCombinationList, bcIndexesByPcellBand))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "Filtering bcIndexes By selectedBcIdx of SN Failed.\n");
                return ERROR;
            }
        }
    }
    else
    {
        if (GOOD != VLIB_getBcIndexesFilteredByPcell(ptCi, pBandCombinationList, frequencyBand, bcIndexesByPcellBand))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Filtering bcIndexes By Pcell Failed.\n");
            return ERROR;
        }
    }

    if (bcIndexesByPcellBand.empty())
    {
        VCCB_PRINT_LOG_CA_FUNC(ptCi, "VLIB_getBcIndexesUsingPrioBasedScellSelectCom: No valid bcIndexes found.\n");
        return BREAK;
    }

    // 2. Check if there is scell frequency profile available for pcell
    uint8_t scellFreqPrioProfileIdx = pCell->nrCarrierAggregationInfo.scellFreqPrioProfileIdx;
    if (scellFreqPrioProfileIdx < MAX_SCELL_FREQ_PRIORITY_PROFILES)
    {
        if (EQUIP == pGnb->carrierAggregationInfo.scellFreqPrioProfiles[scellFreqPrioProfileIdx].status &&
            FLAG_ON == pGnb->carrierAggregationInfo.scellFreqPrioProfiles[scellFreqPrioProfileIdx].scellFreqPrioFlag)
        {
            for (int scellFreqPrioIdx = 0; scellFreqPrioIdx < MAX_SCELL_FREQ_PRIORITIES; scellFreqPrioIdx++)
            {
                if (EQUIP == pGnb->carrierAggregationInfo.scellFreqPrioProfiles[scellFreqPrioProfileIdx]
                                 .scellFreqPriorities[scellFreqPrioIdx]
                                 .status)
                {
                    isSCellFreqPrioProfAvailable = true;
                    VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: scell profile used, scellFreqPrioProfileIdx(%u) \n", scellFreqPrioProfileIdx);
                    break;
                }
            }
        }
    }

    // 3. Return bcIndexes filtered by pCell band in case where further filtering is impossible or unwanted.
    if ((!isSCellFreqPrioProfAvailable) ||
        (CI_no_use == pCell->cuColocCellInfo.colocCellInfoUsage) || (1 == bcIndexesByPcellBand.size()))
    {
        for (uint32_t bcIndex : bcIndexesByPcellBand)
        {
            filteredBcIndexes.push_back(bcIndex);
        }

        VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: Return non-filtered bcIndexes coloc(%i) bcSize(%zu)\n",
                                pCell->cuColocCellInfo.colocCellInfoUsage, bcIndexesByPcellBand.size());
        if(isSCellFreqPrioProfAvailable)
        {
            VLIB_BandsFromBcIndexesPrint(ptCi, pBandCombinationList, bcIndexesByPcellBand);
        }

        return GOOD;
    }

    // 4. Filtering based on scellFreq Priorities
    //    A) Find coloc-cells with scellFreqPriorities
    //    B) Check if coloc-cells does have available band combinations
    //    C) Keep all highest priority possible band combination indexes which does contain coloc-cell band
    if (GOOD != VLIB_filterBcIndexesByPcellAndColocCells(
                    ptCi, spCellNum, pBandCombinationList, bcIndexesByPcellBand, bcIndexesByPcellBandAndColocCells))
    {
        for (uint32_t bcIndex : bcIndexesByPcellBand)
        {
            filteredBcIndexes.push_back(bcIndex);
        }
    }
    else
    {
        for (uint32_t bcIndex : bcIndexesByPcellBandAndColocCells)
        {
            filteredBcIndexes.push_back(bcIndex);
        }
    }

    if(DBG->flag.logCaExtended)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "CA: Return filtered bcIndexes\n");
        VLIB_BcIndexesPrint(ptCi, filteredBcIndexes);
        VLIB_BandsFromBcIndexesPrint(ptCi, pBandCombinationList, filteredBcIndexes);
    }

    return GOOD;
}

/**
 * @brief     Search, filter and get BC indexes using priority based scell selection feature.
 * @param[in]   ptCi : call context
 * @param[in]   spCellNum : serving primary cell num
 * @param[out]  filteredBcIndexes : Filtered BC indexes using priority based scell selection.
 *                                  Depending on yang configuration and call type returned indexes will be either:
 *                                    - Indexes filtered by Pcell Band
 *                                    - Indexes filtered by Pcell Band and coloc cells (depending on configured scell
 * Frequency profiles)
 *                                    - Single band combination index for NRDC_MN case
 * @return    GOOD : success, at least 1 valid BC index found.
 * @return    BREAK : success, but no valid indexes found.
 * @return    ERROR : failure.
 */
int16_t VLIB_getBcIndexesUsingPrioBasedScellSelect(
     callInfo_type *ptCi, const uint16_t spCellNum, const uint16_t frequencyBand, bcIdxArray_type &filteredBcIndexes)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    // Get BandCombinationList
    bandCombinationList_type *pBandCombinationList = VRIL_GetBandCombinationList(ptCi);
    VALID_E_POINT_CHECK_ERROR(pBandCombinationList);

    return VLIB_getBcIndexesUsingPrioBasedScellSelectCom(ptCi, spCellNum, frequencyBand, filteredBcIndexes, pBandCombinationList);
}

/**
 * @brief     If needed modify single SCell band according PCC calculations
 * @param     ptCi : call context
 */
void VLIB_applyAlternativeBandIfNeeded(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if((PCC_HOQueued != ptCi->pccData.state) &&
       (PCC_BestBandCombinationFound != ptCi->pccData.state) &&
       (PCC_Reactivating != ptCi->pccData.state))
    {
        return;
    }

    for (uint32_t sCellAltBandIdx = 0; MAX_MCO_MFBI_CELLS > sCellAltBandIdx; sCellAltBandIdx++)
    {
        if((UNKNOWN_ARFCN == ptCi->pccData.scellAltBandNrArfcnTab[sCellAltBandIdx]) ||
           (BAND_NOT_FOUND == ptCi->pccData.scellAltBandTab[sCellAltBandIdx]))
        {
            continue;
        }

        uint8_t scellIdx = 0;
        for (scellIdx = 0; scellIdx < MAX_SCELL_PER_CALL; scellIdx++)
        {
            if ((SCELL_STATE_RELEASED != ptCi->sCell[scellIdx].state) &&
                (ptCi->pccData.scellAltBandNrArfcnTab[sCellAltBandIdx] == ptCi->sCell[scellIdx].nrArfcn))
            {
                break;
            }
        }

        if (MAX_SCELL_PER_CALL > scellIdx)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC] Change SCell scellIdx(%u)/pci(%u) band(%u) to alternative band(%u)\n",
                scellIdx, ptCi->sCell[scellIdx].pci, ptCi->sCell[scellIdx].bandNr,
                ptCi->pccData.scellAltBandTab[sCellAltBandIdx]);
            ptCi->sCell[scellIdx].bandNr = ptCi->pccData.scellAltBandTab[sCellAltBandIdx] & e_BitMask_11bit;

            if (SCELL_ACTION_RESETUP == ptCi->sCell[scellIdx].action)
            {
                // if there is band change scell must be released and setup again
                ptCi->sCell[scellIdx].action = SCELL_ACTION_SETUP_RELEASE;
            }
        }
        else
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[PCC] SCell with NrArfcn(%u) not found!\n",
                ptCi->pccData.scellAltBandNrArfcnTab[sCellAltBandIdx]);
        }

        ptCi->pccData.scellAltBandNrArfcnTab[sCellAltBandIdx] = UNKNOWN_ARFCN;
        ptCi->pccData.scellAltBandTab[sCellAltBandIdx] = BAND_NOT_FOUND;
    }
}

bool FnVCCB_CheckCpuOverloadStatusAboutCu(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    VccbCfgInfo_type::OverloadControl::UeSigCpuOverloadControl *pUeSigCpuOverloadControl =
        &CFG->overloadControl.ueSigCpuOverloadControl;

    VCCB_PRINT_LOG_CA_FUNC(ptCi,
        "CA: CU Overload Check ueSigCpuOverloadAction(%d),caOverloadThreshold(%d),overloadStatus(%d)\n",
        pUeSigCpuOverloadControl->ueSigCpuOverloadAction, pUeSigCpuOverloadControl->caOverloadThreshold,
        CFG->overloadStatus);

    if ( pUeSigCpuOverloadControl->ueSigCpuOverloadAction == VCCB_FLAG_ON &&
         pUeSigCpuOverloadControl->caOverloadThreshold != VCCB_FLAG_OFF &&
         indeterminate != CFG->overloadStatus &&
         CFG->overloadStatus <= pUeSigCpuOverloadControl->caOverloadThreshold )
    {
        return true;
    }

    return false;
}

bool FnVCCB_CheckCpuOverloadStatusAboutDu(callInfo_type *ptCi, const gnbDuInfo_type *pGnbDu)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pGnbDu, false);

    VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: DU Overload Check overloadStatus(%d)\n", pGnbDu->overloadStatus);

    if (pGnbDu->overloadStatus == ci_overload)
    {
        return true;
    }

    return false;
}

void FnVCCB_UpdateCaOverloadStatus(callInfo_type *ptCi, const gnbDuInfo_type *pGnbDu)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pGnbDu);

    const bool INTERDU_HO = (ptCi->stateCmd == IntraRatHO_cmd && ptCi->hoInfo.hoType.du == HO_TYPE_INTER_DU);
    const bool INTERDU_RRE = (ptCi->stateCmd == RrcReestablish_cmd && ptCi->ueInfo.reestablishInfo.reestablishType == RRE_TYPE_INTER_DU);
    const bool F1_UECONTEXT_SETUP_REQUEST = (!GET_F1_RESOURCE_FLAG(ptCi->flag.setupFlag));

    if ( F1_UECONTEXT_SETUP_REQUEST || INTERDU_HO || INTERDU_RRE )
    {
        ptCi->caOverloadedStatus = VCCB_FLAG_OFF;

        if (FnVCCB_CheckCpuOverloadStatusAboutCu(ptCi))
        {
            ptCi->caOverloadedStatus = VCCB_FLAG_ON;
            VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: FnVCCB_CheckCpuOverloadStatusAboutCu true !! \n");
        }

        if (FnVCCB_CheckCpuOverloadStatusAboutDu(ptCi, pGnbDu))
        {
            ptCi->caOverloadedStatus = VCCB_FLAG_ON;
            VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: FnVCCB_CheckuCpuOverloadStatusAboutDu true!! \n");
        }
    }
}

uint8_t VLIB_DecideAboutCaOperatingMode(callInfo_type *ptCi, VccbCellInfo_type *pCell, uint16_t spCellFrequencyBand)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, CaOperation_Off);
    VALID_E_POINT_CHECK_RET_VAL(pCell, CaOperation_Off);

    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, CaOperation_Off);
    VCCB_CHECK_E_RANGE_AND_VAL(pCell->endPointF1Index, MAX_GNB_DU_PER_GNB_CU_CP, CaOperation_Off);
    VCCB_CHECK_E_RANGE_AND_VAL(spCellFrequencyBand - 1, MAX_NUM_NR_BAND, CaOperation_Off);

    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    gnbDuInfo_type *const pGnbDu = &pGnb->gnbDu[pCell->endPointF1Index];

    if (IS_REDCAP_UE(ptCi))
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: RedCap UE. Non CA \n");
        return CaOperation_Off;
    }

    FnVCCB_UpdateCaOverloadStatus(ptCi, pGnbDu);
    if ( VCCB_FLAG_ON == ptCi->caOverloadedStatus )
    {
        FnVCCB_SetSCellCslRelCauseByCuTrigger(ptCi, ca_csl_CU_Overload);
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: caOverloadedStatus=ON CA mode-off\n");
        return CaOperation_Off;
    }

    if (!IS_CA_AVAILABLE(ptCi, pCell->nrCarrierAggregationInfo.caAvailable))
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: caAvailable off\n");
        return CaOperation_Off;
    }

    if (E_CALLTYPE_SA == ptCi->callType)
    {
        if (TRUE != FOO.VF_CallProcedureforCarrierAggregation_SA)
        {
            VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: CallProcedureforCarrierAggregation_SA is FALSE\n");
            return CaOperation_Off;
        }

        if ((CI_use != pGnb->carrierAggregationInfo.caOnLtmUsage) &&
            (FnVCCB_IsNrdcProhibitedByLtmHO(*ptCi, FnVCCB_GetCellSelectionForConfig(ptCi).bandNr)))
        {
            VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: Ltm UE, CA turned off for Ltm UEs\n");
            return CaOperation_Off;
        }
    }

    // temporary turn off CA if (FR356) CA during HO not supported (only non-MR-DC call) or if (FR358) it is Conditional handover
    if (((TRUE == pCell->mobilityConfig.hoWithNonCaSupport) &&
            ((IntraRatHO_cmd == ptCi->stateCmd) || (InterRatHO_cmd == ptCi->stateCmd)) && (!IS_MRDC(ptCi))) ||
        (true == FnVCCB_IsConditionalHandoverUE(ptCi)))
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: CA turned off during HO\n");
        // plan scell reconfiguration after HO finalization
        ptCi->bitFlag.isSCellReconfigRequired = TRUE;
        return CaOperation_Off;
    }

    if (IS_ENDC_SCG_TO_RELEASE(ptCi) || (RRCResume_cmd == ptCi->stateCmd))
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE( ptCi, "CA: CA turned off during RRCResume/ENDC release\n");
        return CaOperation_Off;
    }

    const int8_t caUsage = (ptCi->caInfo.caControlIdx < MAX_NR_CA_CONTROL_ENTRIES) ?
            pGnb->carrierAggregationInfo.nrCaControlEntries[ptCi->caInfo.caControlIdx].operation.caUsage :
            (int8_t)caUsage_NoControl;
    if (caUsage_Off == caUsage)
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: Control group Idx(%u) Ca off\n", ptCi->caInfo.caControlIdx);
        FnVCCB_SetSCellCslRelCauseByCuTrigger(ptCi, ca_csl_CU_CA_control);
        return CaOperation_Off;
    }

    const uint8_t caMode = pGnb->carrierAggregationInfo.bandOperationMode[spCellFrequencyBand - 1].caOperationMode;

    if (CaOperation_Off == caMode)
    {
        return CaOperation_Off;
    }

    if (FnVCCB_IsDrbAvailableForCA(ptCi) == false)
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA is not available. No DRB in %s\n", __FUNCTION__);
        return CaOperation_Off;
    }

    VLIB_SetIsFR1FR2CaAvailable(ptCi, pCell);
    if (TRUE == ptCi->caInfo.isFR1FR2CaAvailable)
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: FR1FR2 available. Use CA mode-1\n");
        return CaOperation_Mode1;
    }

    if ((CaOperation_Mode1 != caMode) &&
        (BoardType_GCA == pGnbDu->boardType))
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: operation mode-%u not supported, mode-1 selected!\n", caMode);
        return CaOperation_Mode1;
    }

    return caMode;
}

/**
 * @brief    Sets minimal and maximal scellIndex
 * @param    [in]  ptCi : pointer to call context
 * @param    [out] rMinIndex : minimal scellIndex
 * @param    [out] rMaxIndex : maximal scellIndex
 * @param    [out] rSecondMinIndex : minimal scellIndex in second range for NR-DC MN (upBound+1)
 */

void VLIB_GetScellIndexBounds(callInfo_type *ptCi, uint16_t &rMinIndex, uint16_t &rMaxIndex, uint16_t &rSecondMinIndex)
{
    AUTO_TRACE_FUNC;
    rMinIndex = 1;
    rMaxIndex = MAX_SCELL_INDEX;
    rSecondMinIndex = MAX_SCELL_INDEX + 1;

    VALID_E_POINT_CHECK_VOID(ptCi);

    rMinIndex = static_cast<uint16_t>(ptCi->servCellIndex + 1);

    if (VCCB_FLAG_ON != ptCi->cgConfigInfo.configRestrictInfo.servCellIndexRangeSCG_Flag)
    {
        return;
    }

    if (IS_MRDC_SN(ptCi))
    {
        rMaxIndex = ptCi->cgConfigInfo.configRestrictInfo.servCellIndexRangeSCG.upBound;
    }
    else if (IS_NRDC_MN(ptCi) && IS_NOT_MRDC_SCG_RELEASE_ONGOING(ptCi))
    {
        rMaxIndex = static_cast<uint16_t>(ptCi->cgConfigInfo.configRestrictInfo.servCellIndexRangeSCG.lowBound - 1);
        rSecondMinIndex = static_cast<uint16_t>(ptCi->cgConfigInfo.configRestrictInfo.servCellIndexRangeSCG.upBound + 1);

        if (rSecondMinIndex <= rMaxIndex) // shouldn't happen: upBound < lowBound
        {
            rSecondMinIndex = MAX_SCELL_INDEX + 1;
        }
    }
    else if (IS_NEDC_MN(ptCi) && IS_NOT_MRDC_SCG_RELEASE_ONGOING(ptCi)) //LTE SN: 1(lowBound)..7(upBound)
    {
        rMinIndex = static_cast<uint16_t>(ptCi->cgConfigInfo.configRestrictInfo.servCellIndexRangeSCG.upBound + 1);
    }

    rMaxIndex = MIN(rMaxIndex, MAX_SCELL_INDEX);
}

/**
 * @brief     Assign scell indexes to all new scells and existing scell if scellIndex out of range.
 *            If scell index not available mark scell to be released.
 * @param     ptCi : pointer to call context
 */
void VLIB_AssignScellIndexes(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint16_t minScellIndex = 1;
    uint16_t maxScellIndex = MAX_SCELL_INDEX;
    uint16_t secondMinScellIndex = MAX_SCELL_INDEX + 1; // minimal scellIndex in second range for NR-DC MN

    VLIB_GetScellIndexBounds(ptCi, minScellIndex, maxScellIndex, secondMinScellIndex);

    bool isScellIndexAvail[MAX_SCELL_INDEX + 1] = {false};  // 1 .. 31

    for (uint16_t sCellIndex = minScellIndex; sCellIndex <= maxScellIndex; ++sCellIndex)
    {
        isScellIndexAvail[sCellIndex] = true;
    }

    // second range
    for (uint16_t sCellIndex = secondMinScellIndex; sCellIndex <= MAX_SCELL_INDEX; ++sCellIndex)
    {
        isScellIndexAvail[sCellIndex] = true;
    }

    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);

    // mark indexes in use
    for (const scellInfo_type &rSCell : scells)
    {
        if ((SCELL_STATE_ADDED != rSCell.state) ||
            (SCELL_ACTION_SETUP == rSCell.action) ||
            (0 == rSCell.sCellIndex) ||
            (MAX_SCELL_INDEX < rSCell.sCellIndex))
        {
            continue;
        }

        isScellIndexAvail[rSCell.sCellIndex] = false;
    }

    for (scellInfo_type &rSCell : scells)
    {
        if (SCELL_STATE_ADDED != rSCell.state)
        {
            continue;
        }

        if (SCELL_ACTION_SETUP != rSCell.action)
        {
            if (((minScellIndex <= rSCell.sCellIndex) && (maxScellIndex >= rSCell.sCellIndex)) ||
                ((secondMinScellIndex <= rSCell.sCellIndex) && (MAX_SCELL_INDEX >= rSCell.sCellIndex)))
            {
                continue;
            }
            else // out of range, new index will be assigned
            {
                VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: Existing SCell ci(%llu) has wrong sCellIndex(%u), range(%u:%u), second range(%u:%u)\n"
                        ,1ULL * rSCell.cgi.ci, rSCell.sCellIndex, minScellIndex, maxScellIndex, secondMinScellIndex, MAX_SCELL_INDEX);
                rSCell.action = SCELL_ACTION_SETUP_RELEASE;
            }
        }

        rSCell.sCellIndex = 0;
        for (uint16_t sCellIndex = minScellIndex; sCellIndex <= MAX_SCELL_INDEX; ++sCellIndex)
        {
            if (isScellIndexAvail[sCellIndex])
            {
                isScellIndexAvail[sCellIndex] = false;
                rSCell.sCellIndex = sCellIndex & e_BitMask_5bit;
                break;
            }
        }

        if (0 == rSCell.sCellIndex)
        {
            VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu) released, no available sCellIndex\n",
                    1ULL * rSCell.cgi.ci);

            rSCell.state = SCELL_STATE_RELEASED;
            if (SCELL_ACTION_SETUP == rSCell.action)
            {
                rSCell.action = SCELL_ACTION_KEEP;
            }
            else
            {
                rSCell.action = SCELL_ACTION_RELEASE;
            }
        }
    }
}

/**
 * @brief The function to find the Scell index using the cell alternative band ssbArfcn in the scc data
 * @param [in] rCall                : reference variable of the call context
 * @param [in] scellAltBandSsbArfcn : cellAltBandSsbArfcn that should be found in sCell
 * @return If found, return scellIndex. if not found, return the MAX_SCELL_PER_CALL.
 */
uint8_t VLIB_FindScellIdxFromAltBandSsbArfcn(const callInfo_type &rCall, const uint32_t scellAltBandSsbArfcn)
{
    AUTO_TRACE_FUNC;

    for (uint8_t scellIdx = 0; scellIdx < MAX_SCELL_PER_CALL; scellIdx++)
    {
        if (rCall.sCell[scellIdx].state != SCELL_STATE_RELEASED)
        {
            if (scellAltBandSsbArfcn == rCall.sCell[scellIdx].ssbArfcn)
            {
                return scellIdx;
            }
        }
    }

    return MAX_SCELL_PER_CALL;
}

/**
 * @brief Check if there is an alternative band to apply
 */
bool VLIB_IsAlternativeBandApplicableForSccChange(const callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;

    for (uint8_t altBandIdx = 0; altBandIdx < MAX_MCO_MFBI_CELLS; ++altBandIdx)
    {
        if ((UNKNOWN_ARFCN != rCall.sccData.scellAltBandSsbArfcn[altBandIdx]) &&
            (BAND_NOT_FOUND != rCall.sccData.scellAltBand[altBandIdx]))
        {
            // if scell Alternative Band information is existed, the operation continue.
            return true;
        }
    }
    return false;
}

/**
 * @brief The function that applies the alternative band,
 *        when the band combination bandwidth to which the alt band is applied is the best.
 * @param ptCi : call context
 * @param oldNrBand : BandNR of the original cell that was SCELL_STATE_ADDED
 */
void VLIB_ApplyAlternativeBandSccChange(callInfo_type *ptCi, uint16_t *oldNrBand)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(oldNrBand);

    if (ptCi->sccData.state == SCC_NOT_SET)
    {
        return;
    }

    if (!VLIB_IsAlternativeBandApplicableForSccChange(*ptCi))
    {
        return;
    }

    for (uint8_t scellAltBandIdx = 0; scellAltBandIdx < MAX_MCO_MFBI_CELLS; ++scellAltBandIdx)
    {
        uint8_t scellIdx = VLIB_FindScellIdxFromAltBandSsbArfcn(*ptCi, ptCi->sccData.scellAltBandSsbArfcn[scellAltBandIdx]);
        if (scellIdx < MAX_SCELL_PER_CALL)
        {
            const nbrGnbCellInfo_type *ptNbrGnbCell = VLIB_GetNbrGnbCellInfoBasedOnCgi(ptCi, ptCi->sCell[scellIdx].cgi, ptCi->sCell[scellIdx].gnbIdLength);
            uint16_t altBandNr = VLIB_GetAlternativeNrBand(ptCi, ptNbrGnbCell, scellIdx, scellAltBandIdx);
            if (BAND_NOT_FOUND != altBandNr)
            {
                ptCi->sCell[scellIdx].bandNr = (altBandNr & e_BitMask_11bit);
            }

            if ( ptCi->sCell[scellIdx].action == SCELL_ACTION_RESETUP )
            {
                if (oldNrBand[scellIdx] != ptCi->sCell[scellIdx].bandNr)
                {
                    ptCi->sCell[scellIdx].action = SCELL_ACTION_SETUP_RELEASE;
                    ptCi->sCell[scellIdx].addRelCause = CaSCellRel_OtherCause;
                }
            }
        }
    }
}

/**
 * @brief     Tries to re-add all existing scells in case there was no spCell change and CA is working in mode3-5
 *
 * @param     ptCi[in/out]           : pointer to call context
 * @param     spCellNum[in]          : cellNum of cell for which CA configuration is prepared
 * @param     rSpCellCaInfo[in]      : reference to filled spCell caCellInfo_type
 * @param     rfilteredBcIndexes[in] : reference to filled vector of supported band combinations
 * @param     shouldRelAddScells[in] : inform if existing scells should be "released and setup" or "re-setup"
 */
void VLIB_ReAddExisitingCellsIfEligible(callInfo_type *ptCi, CellNum_type spCellNum, caCellInfo_type &rSpCellCaInfo,
        const bcIdxArray_type &rfilteredBcIndexes, bool shouldSetupRelScells)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if ((spCellNum != ptCi->servCellNum) ||
        ((CaOperation_Mode3 != ptCi->caInfo.mode) &&
         (CaOperation_Mode4 != ptCi->caInfo.mode) &&
         (CaOperation_Mode5 != ptCi->caInfo.mode)))
    {
        // step should be performed only if there was no spCell change and CA mode 3, 4, 5
        return;
    }

    if ((RrcReestablish_cmd == ptCi->stateCmd) &&
        (spCellNum != ptCi->ueInfo.reestablishInfo.oldCellNum))
    {
        // During RRE ptCi->servCellNum is used for current spCell so RRE is not covered by previous if statement
        return;
    }

    const bool checkAllowedBandFlag = FnVCCB_IsNeedToCheckAllowedBand(*ptCi);

    for (scellInfo_type &rSCell : ptCi->sCell)
    {
        if ((SCELL_STATE_RELEASED != rSCell.state) ||
            (SCELL_ACTION_RELEASE != rSCell.action))
        {
            // not existing scell
            continue;
        }

        caCellInfo_type scellCaInfo;
        if (GOOD != VLIB_FillCaCellInfo(ptCi, spCellNum, rSCell.cgi, rSCell.gnbIdLength, scellCaInfo))
        {
            continue;
        }

        if (checkAllowedBandFlag)
        {
            // Re-Select SCell Band
            if (GOOD != VLIB_selectProperBand(ptCi, rSpCellCaInfo.frequencyBand, rfilteredBcIndexes, &scellCaInfo))
            {
                VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu) none of cell bands supported in BC\n",
                        1ULL * scellCaInfo.cgi.ci);
                continue;
            }
        }
        else
        {
            // use current scell band
            scellCaInfo.frequencyBand = rSCell.bandNr;
        }

        if (GOOD != VLIB_IsCellEligibleForCA(ptCi, &rSpCellCaInfo, &scellCaInfo, rfilteredBcIndexes))
        {
            VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: Existing SCell ci(%llu) not eligible for CA\n", 1ULL * scellCaInfo.cgi.ci);
            continue;
        }

        rSCell.state = SCELL_STATE_ADDED;

        if (shouldSetupRelScells)
        {
            rSCell.action = SCELL_ACTION_SETUP_RELEASE;

        }
        else
        {
            rSCell.action = SCELL_ACTION_RESETUP;

        }

        if (checkAllowedBandFlag && (scellCaInfo.frequencyBand != rSCell.bandNr))
        {
            rSCell.bandNr = scellCaInfo.frequencyBand & e_BitMask_11bit; // Update SCell Band
            rSCell.action = SCELL_ACTION_SETUP_RELEASE; // Seutp and Release
        }

        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell re-added sCellIndex(%d)/pci(%d)/band(%u)\n",
                rSCell.sCellIndex, rSCell.pci, rSCell.bandNr);
    }
}

/**
 * @brief     Tries to add all scells released earlier because of VoNR in case CA is working in mode4-5
 *
 * @param     ptCi[in/out]           : pointer to call context
 * @param     spCellNum[in]          : cellNum of cell for which CA configuration is prepared
 * @param     rSpCellCaInfo[in]      : reference to filled spCell caCellInfo_type
 * @param     rfilteredBcIndexes[in] : reference to filled vector of supported band combinations
 */
void VLIB_AddVoNRRellCellsIfEligible(callInfo_type *ptCi, CellNum_type spCellNum, caCellInfo_type &rSpCellCaInfo,
        const bcIdxArray_type &rfilteredBcIndexes)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->bitFlag.isSCellChangedAllowedBand)
    {
        // Don't change SCELL_STATE_VONRREL
        return;
    }

    const bool ignoreVoNRRelScells = ((CaOperation_Mode4 != ptCi->caInfo.mode) && (CaOperation_Mode5 != ptCi->caInfo.mode)) ||           // modes support adding non-colo-cells
                                     (spCellNum != ptCi->servCellNum) ||                                                                 // spCell change during HO
                                     ((RrcReestablish_cmd == ptCi->stateCmd) && (spCellNum != ptCi->ueInfo.reestablishInfo.oldCellNum)); // spCell change during RRE

    for (scellInfo_type &rSCell : ptCi->sCell)
    {
        if (SCELL_STATE_VONRREL != rSCell.state)
        {
            continue;
        }

        rSCell.state = SCELL_STATE_RELEASED;
        rSCell.action = SCELL_ACTION_KEEP;
        if (ignoreVoNRRelScells)
        {
            continue;
        }

        caCellInfo_type scellCaInfo;
        if (GOOD != VLIB_FillCaCellInfo(ptCi, spCellNum, rSCell.cgi, rSCell.gnbIdLength, scellCaInfo))
        {
            continue;
        }

        // use earlier assigned scell band
        scellCaInfo.frequencyBand = rSCell.bandNr;

        if (GOOD != VLIB_IsCellEligibleForCA(ptCi, &rSpCellCaInfo, &scellCaInfo, rfilteredBcIndexes))
        {
            VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: VoNRRel SCell ci(%llu) not eligible for CA\n", 1ULL * scellCaInfo.cgi.ci);
            continue;
        }

        rSCell.state = SCELL_STATE_ADDED;
        rSCell.action = SCELL_ACTION_SETUP;
        rSCell.addRelCause = CaSCellAddAtt_Blind; // it is blind addition of earlier rejected scell
        rSCell.blind = TRUE;
        rSCell.ignoreNextPeriodic = TRUE;

        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell(VoNRRel) added pci(%d)/band(%u)\n",
                rSCell.pci, rSCell.bandNr);
    }
}

int16_t FnVCCB_GetColocatedCellInfo(VccbCellInfo_type &rCell, VccbGnbInfo_type &rGnb, cgi_type &rCgiOut,
        uint8_t &rGnbIdLengthOut, uint16_t cellIdx, uint8_t currColocCellInfoUsage)
{
    uint16_t duCellNum;
    uint16_t maxCellIdx = MAX_CELL_PER_DU;
    cuColocCellInfo_type &rCuColocCellInfo = rCell.cuColocCellInfo;

#ifdef __NVGNB__
    maxCellIdx = MAX_CELL_NUM_VCCB;
#endif
    if (CI_use == currColocCellInfoUsage)
    {
        maxCellIdx = MAX_COLOCCELL;
    }
    VCCB_CHECK_E_RANGE_AND_RETURN(cellIdx, maxCellIdx);

    if (CI_no_use == currColocCellInfoUsage)
    {
#ifdef __NVGNB__
        const VccbCellInfo_type *const pCellofNVGNB = &CELLINFO[cellIdx];

        if ((pCellofNVGNB->status != EQUIP) || (pCellofNVGNB->pldState != EQUIP))
        {
            return ERROR;
        }
        duCellNum = cellIdx;
#else
        gnbDuInfo_type &rGnbDu = rGnb.gnbDu[rCell.endPointF1Index];
        if (EQUIP != rGnbDu.cellInDu[cellIdx].status)
        {
            return ERROR;
        }
        duCellNum = rGnbDu.cellInDu[cellIdx].cellNum;
#endif
        VCCB_CHECK_E_RANGE_AND_RETURN(duCellNum, MAX_CELL_NUM_VCCB);
        rCgiOut = FnVCCB_GetNrcgiFromCellNum(duCellNum);
        rGnbIdLengthOut = rGnb.globalGnbId.gnbId.idLength;
    }
    else
    {
        if ((CI_no_use == rCuColocCellInfo.colocCellEntries[cellIdx].usage) ||
            (TRUE != rCuColocCellInfo.colocCellEntries[cellIdx].useforNrca))
        {
            return ERROR;
        }

        rCgiOut.ci = VLIB_GnbIdCellId2NrCellId(&rCuColocCellInfo.colocCellEntries[cellIdx].globalGnbId.gnbId,
            rCuColocCellInfo.colocCellEntries[cellIdx].cellId);
        rCgiOut.plmn = rCuColocCellInfo.colocCellEntries[cellIdx].globalGnbId.plmn;
        rGnbIdLengthOut = rCuColocCellInfo.colocCellEntries[cellIdx].globalGnbId.gnbId.idLength;
    }
    return GOOD;
}

int16_t FnVCCB_CheckCellCarrierEligibleForCA(callInfo_type *ptCi, caCellInfo_type *pSpCell, caCellInfo_type *pScell,
        bcIdxArray_type &rFilteredBcIndexes, uint64_t hoSrcCellCi, bool *pOnlyMeasurementInstallation)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pScell);
    VALID_E_POINT_CHECK_ERROR(pSpCell);
    VALID_E_POINT_CHECK_ERROR(pOnlyMeasurementInstallation);

    if (CaOperation_Mode3 == ptCi->caInfo.mode)
    {
        if (GOOD != VLIB_IsCarrierEligibleForCA(ptCi, pSpCell, pScell, rFilteredBcIndexes))
        {
            return ERROR;
        }
        *pOnlyMeasurementInstallation = true;

        if ((hoSrcCellCi == pScell->cgi.ci) &&
            (GOOD == VLIB_IsCellEligibleForCA(ptCi, pSpCell, pScell, rFilteredBcIndexes)))
        {
            // 24A FR174 : In mode-3 add HO src cell as scell instead installing A4
            *pOnlyMeasurementInstallation = false;
        }

    }
    else if(CaOperation_Mode5 == ptCi->caInfo.mode)
    {
        if (GOOD != VLIB_IsCellEligibleForCA(ptCi, pSpCell, pScell, rFilteredBcIndexes))
        {
            VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu) not eligible for CA\n", 1ULL * pScell->cgi.ci);

            if (GOOD != VLIB_IsCarrierEligibleForCA(ptCi, pSpCell, pScell, rFilteredBcIndexes))
            {
                return ERROR;
            }
            *pOnlyMeasurementInstallation = true;
        }
    }
    else
    {
        if (GOOD != VLIB_IsCellEligibleForCA(ptCi, pSpCell, pScell, rFilteredBcIndexes))
        {
            VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu) not eligible for CA\n", 1ULL * pScell->cgi.ci);
            return ERROR;
        }
    }
    return GOOD;
}

int16_t FnVCCB_CfgSCellListProc(callInfo_type *ptCi, uint16_t cellIdx, caCellInfo_type* pSpCell, caCellInfo_type* pScell,
        bcIdxArray_type &rFilteredBcIndexes, bool releaseSCell)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pScell);
    VALID_E_POINT_CHECK_ERROR(pSpCell);

    if ((SCELL_STATE_RELEASED == ptCi->sCell[cellIdx].state) &&
        (SCELL_ACTION_RELEASE == ptCi->sCell[cellIdx].action))
    {
        // in mode 3 only carrier was verified earlier
        if ((CaOperation_Mode3 == ptCi->caInfo.mode) &&
            (GOOD != VLIB_IsCellEligibleForCA(ptCi, pSpCell, pScell, rFilteredBcIndexes)))
        {
            return ERROR;
        }

        if (0 == ptCi->sCell[cellIdx].sCellIndex)
        {
            VCCB_PRINT_LOG_CA_FUNC(ptCi, "CA: Wrong sCellIndex of existing scell(%d)!!\n",cellIdx);
            return ERROR;
        }

        ptCi->sCell[cellIdx].state = SCELL_STATE_ADDED;

        if (((IntraRatHO_cmd == ptCi->stateCmd) && (HO_TYPE_INTER_DU == ptCi->hoInfo.hoType.du)) ||
            ((RrcReestablish_cmd == ptCi->stateCmd) && (RRE_TYPE_INTER_DU == ptCi->ueInfo.reestablishInfo.reestablishType)))
        {
            ptCi->sCell[cellIdx].action = SCELL_ACTION_SETUP;
            ptCi->sCell[cellIdx].addRelCause = CaSCellAddAtt_Blind;
        }
        else if (releaseSCell || (ptCi->sCell[cellIdx].bandNr != pScell->frequencyBand)) // if there is band change scell must be released and setup again
        {
            ptCi->sCell[cellIdx].action = SCELL_ACTION_SETUP_RELEASE;
        }
        else
        {
            ptCi->sCell[cellIdx].action = SCELL_ACTION_RESETUP;
        }
        ptCi->sCell[cellIdx].bandNr = pScell->frequencyBand & e_BitMask_11bit;
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell re-added cellIdx(%d)/sCellIndex(%d)/pci(%d)/band(%u)/action(%u)\n", cellIdx,
            ptCi->sCell[cellIdx].sCellIndex, ptCi->sCell[cellIdx].pci, ptCi->sCell[cellIdx].bandNr, ptCi->sCell[cellIdx].action);

        return BREAK;
    }
    else if ((CaOperation_Mode3 == ptCi->caInfo.mode) &&
             (SCELL_STATE_LTMREL == ptCi->sCell[cellIdx].state) &&
             (GOOD == VLIB_IsCellEligibleForCA(ptCi, pSpCell, pScell, rFilteredBcIndexes)))
    {
        ptCi->sCell[cellIdx].state = SCELL_STATE_ADDED;
        ptCi->sCell[cellIdx].action = SCELL_ACTION_SETUP;
        ptCi->sCell[cellIdx].addRelCause = CaSCellAddAtt_Blind;
        ptCi->sCell[cellIdx].bandNr = pScell->frequencyBand & e_BitMask_11bit;
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: LTM released SCell added cellIdx(%d)/sCellIndex(%d)/pci(%d)/band(%u)/action(%u)\n", cellIdx,
            ptCi->sCell[cellIdx].sCellIndex, ptCi->sCell[cellIdx].pci, ptCi->sCell[cellIdx].bandNr, ptCi->sCell[cellIdx].action);
        return BREAK;
    }

    return GOOD;
}

int16_t FnVCCB_CheckCellFreq(callInfo_type *ptCi, caCellInfo_type *pScell, caCellInfo_type *pSpCell,
        bcIdxArray_type &rfilteredBcIndexes, bool shouldSetupRelScells, bool onlyMeasurementInstallation)
{
    uint16_t cellIdx;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pScell);
    VALID_E_POINT_CHECK_ERROR(pSpCell);

    for (cellIdx = 0; cellIdx < MAX_SCELL_PER_CALL; cellIdx++)
    {
        // check if cell with same frequency already added
        if ((SCELL_STATE_RELEASED != ptCi->sCell[cellIdx].state) &&
            (SCELL_STATE_LTMREL != ptCi->sCell[cellIdx].state) &&
            (ptCi->sCell[cellIdx].ssbArfcn == pScell->ssbArfcn))
        {
            if ((SCELL_STATE_MRREL == ptCi->sCell[cellIdx].state) &&
                (!onlyMeasurementInstallation))
            {
                // if some cell might be added immediately (mode-3 or mode-5) it has higher priority
                // than cell with same frequency for which A4 measurement would be installed
                ptCi->sCell[cellIdx].state = SCELL_STATE_RELEASED;
                ptCi->sCell[cellIdx].action = SCELL_ACTION_KEEP;
                return GOOD;
            }
            VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu) not added, scell with same frequency(%u) already exists\n",
                    1ULL * pScell->cgi.ci, pScell->ssbArfcn);
            break;
        }

        if ((ptCi->sCell[cellIdx].cgi.ci != pScell->cgi.ci) || (ptCi->sCell[cellIdx].cgi.plmn.longId != pScell->cgi.plmn.longId))
        {
            continue;
        }

        // check if already added
        if (BREAK == FnVCCB_CfgSCellListProc(ptCi, cellIdx, pSpCell, pScell, rfilteredBcIndexes, shouldSetupRelScells))
        {
            break;
        }
    }

    if (MAX_SCELL_PER_CALL > cellIdx)
    {
        // Cell found
        return ERROR;
    }

    return GOOD;
}

void FnVCCB_CAConfigAddNewCell(callInfo_type *ptCi, caCellInfo_type *pScell, bool onlyMeasurementInstallation)
{
    uint16_t cellIdx;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pScell);

    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);

    for (cellIdx = 0; cellIdx < MAX_SCELL_PER_CALL; cellIdx++)
    {
        if ((scells[cellIdx].state == SCELL_STATE_RELEASED) &&
            (scells[cellIdx].action == SCELL_ACTION_KEEP))
        {
            break;
        }
    }

    if (MAX_SCELL_PER_CALL <= cellIdx)
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(
            ptCi, "CA: no available sCell!! MAX_SCELL_PER_CALL(%d) ACTIVATED\n", MAX_SCELL_PER_CALL);
            return;
    }

    VLIB_FillNewScellInfo(ptCi, &scells[cellIdx], pScell);

    if (onlyMeasurementInstallation) // mode 3(always) or mode 5(when carrier eligible, but cell does not)
    {
        scells[cellIdx].state = SCELL_STATE_MRREL;
        scells[cellIdx].action = SCELL_ACTION_KEEP;
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: A4 will be added cellIdx(%d)/ssbArfcn(%u)/band(%u)\n", cellIdx,
            scells[cellIdx].ssbArfcn, scells[cellIdx].bandNr);
    }
    else
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell added cellIdx(%d)/pci(%d)/band(%u)\n", cellIdx,
            scells[cellIdx].pci, scells[cellIdx].bandNr);
    }
}

/**
 * @brief     Reconfigure scells, if VoNR is released and earlier any scell was released by DU because of VoNR.
 *
 * @param     ptCi : call context
 */
void VLIB_ReconfigureScellsIfVoNRReleased(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (FnVCCB_IsVoNRCall(ptCi)) return;

    if (TRUE == ptCi->caInfo.scellsReleasedByVoNR)
    {
        VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: Scells will be reconfigured because of VoNR release\n");

        ptCi->bitFlag.isSCellReconfigRequired = TRUE;
        ptCi->bitFlag.doNotCalcTotalMaxBwForCa = VCCB_FLAG_ON;
        ptCi->bitFlag.isSCellChangedAllowedBand = FALSE;
        ptCi->caInfo.releaseCaA4ForVoNROn = FALSE;

        VLIB_ConfigSecondaryCellList(ptCi);
    }
    else if (ptCi->caInfo.releaseCaA4ForVoNROn == TRUE)
    {
        ptCi->caInfo.releaseCaA4ForVoNROn = FALSE;
        if (ptCi->sccData.state == SCC_NOT_SET) // SCC Restart due to VoNR Release
        {
            FnVCCB_InitiateCapabilityAwareCarrierChangeSCC(ptCi, false);

            if (ptCi->sccData.state == SCC_NOT_SET) // SCC Change OFF
            {
                FnVCCB_CalculateTotalMaxBwForCa(ptCi);
            }
            else        // SCC Change ON
            {
                ptCi->caInfo.totalMaxBw = UNKNOWN_BANDWIDTH;
                ptCi->caInfo.prevTotalMaxBw = UNKNOWN_BANDWIDTH;
            }
        }
    } 
}

/**
 * @brief     Display SCell information
 * @param     call : call context
 */
void VLIB_CaDebugPrintSCellStatus(const callInfo_type &call)
{
    if (!DBG->flag.logCa)
    {
        return;
    }

    auto cellSelection = FnVCCB_GetCellSelectionForConfig(&call);

    VCCB_PRINT_LOG_CA_FUNC(&call,"[CA Config] SpCell(%d)/band(%d)/mode(%d)/controlIdx(%d)\n",
                            cellSelection.cellNum, cellSelection.bandNr, call.caInfo.mode, call.caInfo.caControlIdx);

    for (uint8_t scellIdx = 0; scellIdx < MAX_SCELL_PER_CALL; ++scellIdx)
    {
        const auto &sCell = call.sCell[scellIdx];

        if ((SCELL_STATE_RELEASED == sCell.state) && (SCELL_ACTION_KEEP == sCell.action))
        {
            continue;
        }

        VCCB_PRINT_LOG_CA_FUNC(&call,"  SCell[%2d]:state(%d)/action(%d)/band(%3d)/bw(%3d)/ci(%lu)\n", scellIdx,
                               sCell.state, sCell.action, sCell.bandNr, sCell.bandwidthDl, sCell.cgi.ci);
    }
}

/**
 * @brief     Clear LTMREL scells state
 *
 * @param     rCi : call context
 */
void VLIB_ClearUnsuedScellsState(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    for (scellInfo_type &scell : rCi.sCell)
    {
        if (SCELL_STATE_LTMREL == scell.state)
        {
            scell.state = SCELL_STATE_RELEASED;
            scell.action = SCELL_ACTION_KEEP;
        }
    }
}

/**
 * @brief     Apply final changes in in CA configuration
 *
 * @param     ptCi : call context
 * @param     oldNrBand: tab with band of existing scells
 * @param     newNrCapaReceiveFlag: flag informs if new NR capa was receved
 * @param     doNotCalcTotalMaxBwFlag: flag informs Max Bw shouldn't be calculated again
 */
void VLIB_FinalizeConfigSecondaryCellList(callInfo_type *ptCi, uint16_t oldNrBand[MAX_SCELL_PER_CALL],
        uint8_t newNrCapaReceiveFlag, uint8_t doNotCalcTotalMaxBwFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    VLIB_applyAlternativeBandIfNeeded(ptCi);

    ptCi->caInfo.componentCarriersLimit = VLIB_DecideComponentCarriersLimit(ptCi) & e_BitMask_2bit;
    if (CcLimit_Released == ptCi->caInfo.componentCarriersLimit)
    {
        VLIB_DecideAboutScellToRelease(ptCi);
    }

    FnVCCB_InitiateCapabilityAwareCarrierChangeSCC(ptCi, newNrCapaReceiveFlag);
    VLIB_ApplyAlternativeBandSccChange(ptCi, oldNrBand);

    if ((VCCB_FLAG_ON != doNotCalcTotalMaxBwFlag) ||
        (UNKNOWN_BANDWIDTH == ptCi->caInfo.prevTotalMaxBw))
    {
        FnVCCB_CalculateTotalMaxBwForCa(ptCi);
    }
    else
    {
         // if not calculate TotalMaxBw, back-up prevTotalMaxBw is restored.
         ptCi->caInfo.totalMaxBw = ptCi->caInfo.prevTotalMaxBw;
    }

    VLIB_CaDebugPrintSCellStatus(*ptCi);
}

/**
 * @brief     Apply initial CA CSl cause sets in CA configuration
 *
 * @param     ptCi : call context
 */
void VLIB_InitializeCaCslCuCauseInCaConfiguration(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if ((IntraRatHO_cmd == ptCi->stateCmd || IntraCellHO_cmd == ptCi->stateCmd) &&
            (ptCi->hoInfo.hoType.rat == HO_TYPE_INTRA_RAT) && (ptCi->hoInfo.hoType.nb == HO_TYPE_INTRA_NB))
    {
        FnVCCB_SetSCellCslRelCauseByCuTrigger(ptCi, ca_csl_CU_HO_out);
        ptCi->bitFlag.skipCslCheckBeforeRrcReconfig = VCCB_FLAG_ON;
    }
    else if ( IS_ON_MRDC_XN_RCVINDICATOR_FLAG(selectedBC))
    {
        FnVCCB_SetSCellCslRelCauseByCuTrigger(ptCi, ca_csl_CU_NoSelectedBCinMRDC);
    }
    else
    {
        FnVCCB_SetSCellCslRelCauseByCuTrigger(ptCi, ca_csl_CU_Others);
        ptCi->bitFlag.skipCslCheckBeforeRrcReconfig = VCCB_FLAG_ON;
    }
}

/**
 * @brief     Check if there is at least one DRB currently available for CA.
 *
 * @param     ptCi : call context
 */
bool FnVCCB_IsDrbAvailableForCA(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (IS_NRDC_SN(ptCi) || ptCi->callType == E_CALLTYPE_NSA)
    {
        return true;
    }

    uint8_t drbIdx = 0;
    callDRBInfo_type* ptDi = NULL;

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; ++drbIdx)
    {
        ptDi = &ptCi->drb[drbIdx];
        if (ptDi->pduIdxInCall >= MAX_PDU_SESS_PER_CALL) continue;
        if (ptDi->usage != CI_use) continue;
        if (ptDi->reqBearerType.cellGroup == CellGroup_Scg) continue;
        if (VLIB_IsCommonValidStateOfPduQosDrb(ptDi->drbStatus) != GOOD) continue;

        return true;
    }

    return false;
}

/**
 * @brief     Check if there is VoNR in qosStatus. 
 * @param     ptCi : call context
 */
bool FnVCCB_CheckQosStateOfVoNR(callInfo_type *ptCi, enumSABearerStatus_type qosStatus)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    for (auto &qosFlow : ptCi->qosFlow)
    {
        if (qosFlow.usage != CI_use) continue;

        if (qosFlow.qosFlowStatus == qosStatus)
        {
            uint8_t fiveQi = 0;
            VLIB_getFiveQi(&qosFlow, &fiveQi);
            if (fiveQi == VONR_5QI)
            {
                return true;
            }
        }
    }

    return false;
}

/**
 * @brief     Set ptCi->caInfo.releaseCaA4ForVoNROn
 *            Exclude cases where VoNR is set up by bearer modification.
 *            Parameters are only set when VoNR is being set up...
 *            The values are maintained until VoNR is released...
 * @param     ptCi : call context
 */
void FnVCCB_SetReleaseCaA4ForVoNROn(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);

    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (ptCi->caInfo.releaseCaA4ForVoNROn == TRUE)
    {
        return;
    }

    if (pGnb->carrierAggregationInfo.releaseCaA4ForVoNR != TRUE)
    {
        return;
    }
    
    if (FnVCCB_CheckQosStateOfVoNR(ptCi, S_Setup))
    {
        ptCi->caInfo.releaseCaA4ForVoNROn = TRUE;
    }

    return;
}


/**
 * @brief     Make CA secondary cell list
 * @param     ptCi : call context
 *
 * ptCi->sCell description:
 * +-------+-----------+--------------
 * | state | action    |  description
 * +-------+-----------+--------------
 * | REL   | KEEP      | Unused / no action
 * | REL   | REL       | existing SCell to be Released
 * | ADD   | KEEP      | SCell Setup done / no action
 * | ADD   | SETUP     | SCell to be Setup
 * | ADD   | SETUP_REL | existing SCell to be Setup and Released simultaneously
 * | ADD   | RESETUP   | existing SCell to be Setup (without releasing)
 * | MRREL | KEEP      | SCell Removed by MR, data valid / no action
 * | MRREL | REL       | SCell to Be Removed by MR, keep data valid
 * +-------+-----------+--------------
 */
void VLIB_ConfigSecondaryCellList(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    uint16_t loop = 0;
    caCellInfo_type spCell;
    caCellInfo_type scell;
    cgi_type cgi;
    uint8_t gnbIdLength;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // Back up bitFlag for CA to local variable
    const uint8_t newNrCapaReceiveFlag = ptCi->bitFlag.isReceivedNrCapaFlag;
    uint8_t doNotCalcTotalMaxBwFlag = ptCi->bitFlag.doNotCalcTotalMaxBwForCa;

    // Back up caInfo to previous DB
    ptCi->caInfo.prevTotalMaxBw = ptCi->caInfo.totalMaxBw;
    ptCi->caInfo.prevSuspendA4Meas = ptCi->caInfo.suspendA4Meas;

    // Initialize caInfo
    ptCi->caInfo.prevMode = ptCi->caInfo.mode;
    ptCi->caInfo.shouldCaBeRestored = FLAG_ON;
    ptCi->caInfo.mode = CaOperation_Off;
    ptCi->caInfo.lateCaMeasurements = FLAG_OFF;
    ptCi->caInfo.componentCarriersLimit = CcLimit_Off;
    ptCi->caInfo.mode2AnyScellReleased = FALSE;
    ptCi->caInfo.scellsReleasedByVoNR = FALSE;
    ptCi->caInfo.totalMaxBw = UNKNOWN_BANDWIDTH;
    ptCi->caInfo.suspendA4Meas     = FALSE;
    ptCi->caInfo.isPeriodicalOngoing = FALSE;
    VCCB_CLEAR_TIMER(&ptCi->caInfo.caPeriodicMeasTimer, CANCEL_TIMER);

    // Initialize bitFlag for CA
    ptCi->bitFlag.isReceivedNrCapaFlag = FALSE;
    ptCi->bitFlag.doNotCalcTotalMaxBwForCa = VCCB_FLAG_OFF;

    uint16_t oldNrBand[MAX_SCELL_PER_CALL] = {0, };
    for (uint16_t idx = 0; idx < MAX_SCELL_PER_CALL; ++idx)
    {
        if (ptCi->sCell[idx].state == SCELL_STATE_ADDED)
        {
            oldNrBand[idx] = ptCi->sCell[idx].bandNr;
        }
    }

    cellSelection_type cellSelection = FnVCCB_GetCellSelectionForConfig(ptCi);
    uint16_t &spCellNum = cellSelection.cellNum;

    VCCB_CHECK_VALID_CELLNUM_VOID(spCellNum);
    VccbCellInfo_type *const pCell = &CELLINFO[spCellNum];

    bool nonCaFlag = false;
    bcIdxArray_type filteredBcIndexes;
    int8_t newUlCaUsage = ulCaUsage_NoControl;
    int8_t oldUlCaUsage = ulCaUsage_NoControl;
    const uint8_t oldCaControlIdx = ptCi->caInfo.caControlIdx;

    VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);
    VCCB_CHECK_E_RANGE_AND_VOID(pCell->endPointF1Index, MAX_GNB_DU_PER_GNB_CU_CP);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    VLIB_InitializeCaCslCuCauseInCaConfiguration(ptCi);
    FnVCCB_ProcessMnBcReselection(ptCi, MnBCReselectionConditionChecker::BASIC_OPERATION);

    if (GOOD != VLIB_FillPcellCaCellInfo(ptCi, cellSelection, spCell))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "CA: Error when filling spCell cellNum(%u) CA info!!\n", spCellNum);
        nonCaFlag = true;
    }
    else
    {
        if (MAX_NR_CA_CONTROL_ENTRIES > ptCi->caInfo.caControlIdx)
        {
            oldUlCaUsage = pGnb->carrierAggregationInfo.nrCaControlEntries[ptCi->caInfo.caControlIdx].operation.ulCaUsage;
        }

        ptCi->caInfo.caControlIdx = VCCM_GetMatchingCaIndex(ptCi, spCell.frequencyBand) & e_BitMask_6bit;
        if (MAX_NR_CA_CONTROL_ENTRIES > ptCi->caInfo.caControlIdx)
        {
            newUlCaUsage = pGnb->carrierAggregationInfo.nrCaControlEntries[ptCi->caInfo.caControlIdx].operation.ulCaUsage;
        }

        ptCi->caInfo.mode = VLIB_DecideAboutCaOperatingMode(ptCi, pCell, spCell.frequencyBand) & e_BitMask_3bit;

        if (CaOperation_Off == ptCi->caInfo.mode)
        {
            nonCaFlag = true;
        }
        else if (GOOD != VLIB_getBcIndexesUsingPrioBasedScellSelect(ptCi, spCellNum, spCell.frequencyBand, filteredBcIndexes))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "No Valid BC indexes found.\n");
            nonCaFlag = true;
        }
    }

    VLIB_InitializeStateActionIndexesForSCellConfig(ptCi, nonCaFlag);

    if (nonCaFlag)
    {
        // Non-CA Case
        if(spCell.frequencyBand == BAND_NOT_FOUND)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "CA: There is no valid band for spCellNum(%u)\n", spCellNum);
        }
        else
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "CA: Non-CA spCellNum(%u),spCellBand(%u),caMode(%u)\n",
                spCellNum, spCell.frequencyBand, ptCi->caInfo.mode);
        }
        return;
    }

    if (FnVCCB_IsChangedAllowedBand(*ptCi, *pGnb, oldCaControlIdx, ptCi->caInfo.caControlIdx))
    {
        VCCB_clearAllFailedCarrier(&ptCi->caInfo.failures);
    }

    uint64_t hoSrcCellCi = UNKNOWN_CELLIDENTITY;
    if (IntraRatHO_cmd == ptCi->stateCmd)
    {
        hoSrcCellCi = FnVCCB_GetNrcgiFromCellNum(ptCi->servCellNum).ci;
    }

    // FGR-RC0100 FR181: existing scell release is needed in case of HO, RRE or DL+UL <-> DL change
    const bool shouldSetupRelScells = (IntraRatHO_cmd == ptCi->stateCmd) || (IntraCellHO_cmd == ptCi->stateCmd) ||
                                      (RrcReestablish_cmd == ptCi->stateCmd) || (oldUlCaUsage != newUlCaUsage);

    const uint8_t currColocCellInfoUsage = pCell->cuColocCellInfo.colocCellInfoUsage;

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "CA: spCellNum(%u),spCellBand(%u),caMode(%u),colocCellUsage(%u)\n",
        spCellNum, spCell.frequencyBand, ptCi->caInfo.mode, currColocCellInfoUsage);

    // set lateCaMeasurements for all modes except non-Measurements mode-1
    if (CaOperation_Mode1 != ptCi->caInfo.mode)
    {
        ptCi->caInfo.lateCaMeasurements = FLAG_ON;
    }

    VLIB_ReAddExisitingCellsIfEligible(ptCi, spCellNum, spCell, filteredBcIndexes, shouldSetupRelScells);
    VLIB_AddVoNRRellCellsIfEligible(ptCi, spCellNum, spCell, filteredBcIndexes);

    uint16_t maxLoop = MAX_CELL_PER_DU;
#ifdef __NVGNB__

    maxLoop = MAX_CELL_NUM_VCCB;

#endif

    if (CI_use == currColocCellInfoUsage)
    {
        maxLoop = MAX_COLOCCELL;
    }

    for (loop = 0; loop < maxLoop; loop++)
    {
        if (GOOD != FnVCCB_GetColocatedCellInfo(*pCell, *pGnb, cgi, gnbIdLength, loop, currColocCellInfoUsage))
        {
            continue;
        }

        if (GOOD != VLIB_FillCaCellInfo(ptCi, spCellNum, cgi, gnbIdLength, scell))
        {
            continue;
        }

        if (GOOD != VLIB_selectProperBand(ptCi, spCell.frequencyBand, filteredBcIndexes, &scell))
        {
            VCCB_PRINT_LOG_CA_FUNC_TRACE(ptCi, "CA: SCell ci(%llu) none of cell bands supported in BC\n",
                    1ULL * scell.cgi.ci);
            continue;
        }

        bool onlyMeasurementInstallation = false;
        if (GOOD != FnVCCB_CheckCellCarrierEligibleForCA(ptCi, &spCell, &scell,
                filteredBcIndexes, hoSrcCellCi, &onlyMeasurementInstallation))
        {
            continue;
        }

        if (GOOD != FnVCCB_CheckCellFreq(ptCi, &scell, &spCell, filteredBcIndexes, shouldSetupRelScells, onlyMeasurementInstallation))
        {
            continue;
        }

        // add new cell
        FnVCCB_CAConfigAddNewCell(ptCi, &scell, onlyMeasurementInstallation);
    }

    FnVCCB_ExcludeScellNotInFmPcc(ptCi);
    VLIB_FinalizeConfigSecondaryCellList(ptCi, oldNrBand, newNrCapaReceiveFlag, doNotCalcTotalMaxBwFlag);
}

/**
 * @brief     set coloc state of scell in ColocCellEntries to normal
 * @param     ptCi : call information
 * @param     sCellCgi : SCell CGI received from DU
 */
void VLIB_SetScellColocStateToNormal(callInfo_type *ptCi, cgi_type sCellCgi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    uint8_t colocCellIdx = 0;
    colocCellEntries_type *pColocCellEntries = NULL;
    const uint16_t spCellNum = FnVCCB_GetCellSelectionForConfig(ptCi).cellNum;
    VCCB_CHECK_VALID_CELLNUM_VOID(spCellNum);
    VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint32_t gnbId = VLIB_NrCellId2GnbId(pGnb->globalGnbId.gnbId.idLength, sCellCgi.ci);
    uint16_t cellIdentity = VLIB_NrCellId2CellId(pGnb->globalGnbId.gnbId.idLength, sCellCgi.ci);

    if (CI_no_use == CELLINFO[spCellNum].cuColocCellInfo.colocCellInfoUsage)
    {
        VCCB_PRINT_LOG_CA_FUNC(
            ptCi, "coloc-cell-info-usage is off, coloc-cell-entries information is not allowed to use!\n");
        return;
    }

    for (colocCellIdx = 0; colocCellIdx < MAX_COLOCCELL; ++colocCellIdx)
    {
        pColocCellEntries = &CELLINFO[spCellNum].cuColocCellInfo.colocCellEntries[colocCellIdx];
        if (CI_no_use == pColocCellEntries->usage)
        {
            continue;
        }

        if ((pColocCellEntries->globalGnbId.plmn.longId != sCellCgi.plmn.longId) ||
            (pColocCellEntries->globalGnbId.gnbId.id != gnbId) || (pColocCellEntries->cellId != cellIdentity))
        {
            continue;
        }

        pthread_mutex_t *pMutex = &EXTERNAL_INFO.cell[spCellNum].oMFailedScellsMutex;

        ///// MUTEX LOCK /////
        MUTEX_LOCK(pMutex);
        pColocCellEntries->callCurrColocCellStatus = CaColocCellStatus_Normal;
        MUTEX_UNLOCK(pMutex);
        ///// MUTEX UNLOCK /////

        break;
    }

    return;
}

void FnVCCB_McoPrepareCurrentScellContiguousNrCellGroups(callInfo_type *ptCi,
        mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBandOut, uint16_t &rPCellBandOut)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);
    VCCB_CHECK_VALID_CELLNUM_VOID(ptCi->servCellNum);

    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    const uint16_t spCellNum = ptCi->servCellNum;

    ccInfoVecPerBandOut.clear();
    rPCellBandOut = BAND_NOT_FOUND;

    mcoBcSelCellInfo_s cellInfoTab[MAX_COLOCCELL + 1];

    std::size_t cellInfoCnt = 1;

    mcoBcSelCellInfo_s &pcell = cellInfoTab[0];
    cgi_type cgi = FnVCCB_GetNrcgiFromCellNum(spCellNum);
    uint8_t gnbIdLength = pGnb->globalGnbId.gnbId.idLength;

    uint8_t bandListNum = 0;
    constexpr bool noPrbUsage_false = false;
    if (GOOD != VLIB_FillCaCellInfoForMco(ptCi, spCellNum, cgi, gnbIdLength, noPrbUsage_false, pcell))
    {
        VCCB_PRINT_LOG_MRS_FUNC(ptCi, "[MRS] VLIB_FillCaCellInfoForMco ERROR !!\n");
        return;
    }

    if (pcell.frequencyBand != ptCi->servCellBand)
    {
        bandListNum = MIN(MAX_FREQBAND_PER_CELL, pcell.bandListNum);
        for (uint8_t bandIdx = 0; bandIdx < bandListNum; ++bandIdx)
        {
            if (pcell.bandList[bandIdx] == ptCi->servCellBand)
            {
                pcell.frequencyBand = ptCi->servCellBand;
                break;
            }
        }
    }
    pcell.altBand = BAND_NOT_FOUND;

    rPCellBandOut = pcell.frequencyBand;
    const uint32_t pcellNrArfcnDl = pcell.nrArfcnDl;

    // iterate Over sCell and fill scell info
    for(scellInfo_type &rSCell : ptCi->sCell)
    {
        if((SCELL_STATE_ADDED != rSCell.state) || (SCELL_ACTION_KEEP != rSCell.action))
        {
            continue;
        }

        mcoBcSelCellInfo_s &scell = cellInfoTab[cellInfoCnt];

        cgi = rSCell.cgi;
        gnbIdLength = rSCell.gnbIdLength;

        if (GOOD != VLIB_FillCaCellInfoForMco(ptCi, spCellNum, cgi, gnbIdLength, noPrbUsage_false, scell))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MRS] Error when filling scell ci(%llu) CA info!\n", 1ULL * cgi.ci);
            continue;
        }

        if (scell.frequencyBand != rSCell.bandNr)
        {
            bandListNum = MIN(MAX_FREQBAND_PER_CELL, scell.bandListNum);
            for (uint8_t bandIdx = 0; bandIdx < bandListNum; ++bandIdx)
            {
                if (scell.bandList[bandIdx] == rSCell.bandNr)
                {
                    scell.frequencyBand = rSCell.bandNr;
                    break;
                }
            }
        }
        scell.altBand = BAND_NOT_FOUND;

        cellInfoCnt++;
    }

    std::sort(cellInfoTab, &cellInfoTab[cellInfoCnt],
            [](const caCellInfo_type &lhs, const caCellInfo_type &rhs)
            {
                if((lhs.frequencyBand < rhs.frequencyBand) || ((lhs.frequencyBand == rhs.frequencyBand) && (lhs.nrArfcnDl < rhs.nrArfcnDl)))
                {
                    return true;
                }

                return false;
            });

    auto fnSetCcInfo = [&rPCellBandOut, &pcellNrArfcnDl](mcoCcInfo_s &ccInfoOut, const caCellInfo_type &caCellInfoIn, const uint8_t grpIdCurrIn)
    {
        ccInfoOut.mcoBwDl = caCellInfoIn.mcoBwDl;
        ccInfoOut.grpId = grpIdCurrIn;
        ccInfoOut.pcellFlag = ((rPCellBandOut == caCellInfoIn.frequencyBand) && (pcellNrArfcnDl == caCellInfoIn.nrArfcnDl));
        ccInfoOut.userValue = caCellInfoIn.ssbArfcn;
    };

    // iterate over bands and create contiguous CC groups
    FnVCCB_McoCreateContigCcGroupsPerBand(cellInfoTab, cellInfoTab + cellInfoCnt, ccInfoVecPerBandOut, fnSetCcInfo);

    // print output for debug
    if (DBG->flag.logMco)
    {
        for(mcoBand2mcoCcInfoVecMap_type::value_type &kv : ccInfoVecPerBandOut)
        {
            mcoCcInfoVec_type &ccInfoVec = kv.second.ccInfoVec;
            VCCB_PRINT_CALL_COMMENT(ptCi, "====== [MCO] Current NR CC groups: band(%u) ======\n", kv.first);

            for(std::size_t ccIdx = 0; ccIdx < ccInfoVec.size(); ccIdx++)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "CC: ccIdx(%lu) contGrpId(%u), nrArfcnDl(%u) BW_DL(%u) isPCell(%u)\n",
                                        ccIdx, ccInfoVec[ccIdx].grpId, ccInfoVec[ccIdx].userValue,
                                        ccInfoVec[ccIdx].mcoBwDl, ccInfoVec[ccIdx].pcellFlag);
            }
        }
    }
}

/**
 * @brief     Restores CA data
 * @param     ptCi : call context
 */
void VLIB_RollbackCa(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (UINT_MAX != ptCi->backupDuSelectionRelatedData.selectedBC)
    {
        ptCi->duSelectionRelatedData = ptCi->backupDuSelectionRelatedData;
        ptCi->backupDuSelectionRelatedData.selectedBC = UINT_MAX;
    }

    if (FLAG_OFF == ptCi->caInfo.shouldCaBeRestored)
    {
        return;
    }

    ptCi->caInfo.mode = ptCi->caInfo.prevMode;

    ptCi->caInfo.totalMaxBw = ptCi->caInfo.prevTotalMaxBw;
    ptCi->caInfo.suspendA4Meas = ptCi->caInfo.prevSuspendA4Meas;

    for (uint8_t scellIdx = 0; scellIdx < MAX_SCELL_PER_CALL; ++scellIdx)
    {
        ptCi->sCell[scellIdx] = ptCi->sCellDuConfig[scellIdx];

        if ((SCELL_STATE_MRREL == ptCi->sCell[scellIdx].state) &&
            (CaOperation_Mode2 == ptCi->caInfo.mode))
        {
            // if in mode-2 any scell was released by MR, flag needs to be restored to TRUE
            ptCi->caInfo.mode2AnyScellReleased = TRUE;
        }

    }

    ptCi->caInfo.shouldCaBeRestored = FLAG_OFF;
}

/**
 * @brief     Saves current scells data
 * @param     ptCi : call context
 */
void VLIB_SaveScells(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (FnVCCB_IsLtmCandPrepForMeas(*ptCi))
    {
        return;
    }

    for (uint8_t scellIdx = 0; scellIdx < MAX_SCELL_PER_CALL; ++scellIdx)
    {
        ptCi->sCellDuConfig[scellIdx] = ptCi->sCell[scellIdx];
    }

    ptCi->caInfo.shouldCaBeRestored = FLAG_OFF;
}

/**
 * @brief     Acknowledge Secondary Cell List after DU response
 * @param     ptCi : call context
 * @param     success : indicates if DU response (FALSE in case of Reject)
 */
void VLIB_CommitSecondaryCellList(callInfo_type *ptCi, uint8_t success)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t cellIdx = 0;
    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    measurementsProcedure_type &rMeasProc = FnVCCB_GetMeasurementsProcedure(*ptCi);

    // Check DRB Partial Fail for VoNR
    // If VoNR setup fail, CA A4 will be configured
    uint8_t allowA4  = FALSE;
    if (ptCi->caInfo.releaseCaA4ForVoNROn == TRUE)
    {
        // Check DRB Partial Fail for VoNR
        // Qos status is not changed from S_Setup to S_FailToSetup when F1_UeContextModificationFailure is received.
        // In E1 Rollback Procedure, NewMeasConfig will be deleted.
        if (TRUE == success)
        {
            if (FnVCCB_CheckQosStateOfVoNR(ptCi, S_FailToSetup))
            {
                ptCi->caInfo.releaseCaA4ForVoNROn = FALSE;
                allowA4 = TRUE;
            }
        }
        else
        {
            if (FnVCCB_CheckQosStateOfVoNR(ptCi, S_Setup))
            {
                ptCi->caInfo.releaseCaA4ForVoNROn = FALSE;
            }
        }

    }

    const bool canLateMeasurementsBeAdded = ((FLAG_ON == ptCi->caInfo.lateCaMeasurements) || (STATE_CaMod_F1UeCtxtModReq == ptCi->state) ||
                                             (FLAG_ON == rMeasProc.lateFreqPrioMeas) ||
                                             (FLAG_ON == rMeasProc.caAwareMeasNeeded) ||
                                             (FLAG_ON == allowA4) ||
                                             (FLAG_ON == rMeasProc.lateLbMeas));
    const bool shouldResetUlTrfChkReportForIratHoFlag = (canLateMeasurementsBeAdded &&
                                                        ((IRatPCCState_Idle == ptCi->pccData.interRatState) ||
                                                         (IRatPCCState_WaitingTimerRunning == ptCi->pccData.interRatState)));

    if (TRUE == success)
    {
        bool isAnySCellReleased = false;
        for (cellIdx = 0; cellIdx < MAX_SCELL_PER_CALL; cellIdx++)
        {
            if (FALSE == scells[cellIdx].isActionQueued)
            {
                if ((SCELL_ACTION_SETUP == scells[cellIdx].action) &&
                    (SCELL_STATE_ADDED == scells[cellIdx].state))
                {
                    VLIB_SetScellColocStateToNormal(ptCi, scells[cellIdx].cgi);
                    scells[cellIdx].shouldFollowA2Quantity = FALSE; // scell was successfully added, stop following A2 quantity
                }
                else if (SCELL_ACTION_RELEASE == scells[cellIdx].action)
                {
                    isAnySCellReleased = true;
                }

                if ((scells[cellIdx].action != SCELL_ACTION_KEEP) && shouldResetUlTrfChkReportForIratHoFlag)
                {
                    ptCi->bitFlag.isUlTrfChkReportForIratHoReceived = VCCB_FLAG_OFF;
                }
                scells[cellIdx].action = SCELL_ACTION_KEEP;
                scells[cellIdx].addRelCause = CaSCellAddAtt_Total;
            }
        }

        // Do not save scells during intra gNB inter DU HO as there can be HO rollback.
        // After successful HO, scells will be saved in VHCM_FinalizeHandover.
        if ((IntraRatHO_cmd != ptCi->stateCmd) ||
            (HO_TYPE_INTRA_NB != ptCi->hoInfo.hoType.nb) ||
            (HO_TYPE_INTER_DU != ptCi->hoInfo.hoType.du))
        {
            VLIB_SaveScells(ptCi);
        }

        // SCC stop procedure with VoNR is only done
        // when F1_UeContextSetupResponse or F1_UeContextModificationResponse is received.
        if (ptCi->sccData.state != SCC_NOT_SET && ptCi->caInfo.releaseCaA4ForVoNROn == TRUE)
        {
            FnVCCB_InitSccData(ptCi, SCC_MR_AND_TIMER_INIT);
        }

        if (canLateMeasurementsBeAdded)
        {
            ptCi->caInfo.suspendA4Meas = FALSE;
            if (FnVCCB_CheckSkipCaA4MrWithMaxBw(ptCi))
            {
                ptCi->caInfo.suspendA4Meas = TRUE;
            }

            if (!IS_MRDC(ptCi))
            {
                FnVCCB_InterRatPccChangeReactToScellModification(*ptCi, isAnySCellReleased);
            }

            if (ERROR == VCCB_PrepareAdditionalMeasConfig(ptCi))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_PrepareAdditionalMeasConfig ERROR!!\n");
            }
            else //GOOD
            {
                VCCB_RETURN_ON_CALL_VOID(ptCi, VCCM_EnqueueActionMeasReconfig(ptCi, MeasReconfigPriorAction_Full),
                    "VCCM_enqueueAction(ENQUEUE_ACTION_MEAS_RECONFIG) fail!\n");
            }
        }

        if ((MeasReconfigPriorAction_Full != ptCi->measurementsConfigShared.queuedMeasReconfigAction) &&
            (IS_MRDC_SN(ptCi)))
        {
            if (ERROR == VCCB_DecideMeasGap(ptCi))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_DecideMeasGap ERROR!!\n");
            }
        }
    }
    else if (!FnVCCB_IsLtmCandPrepForMeas(*ptCi)) // no backup for LTM
    {
        // backup previous DU configuration
        for (cellIdx = 0; cellIdx < MAX_SCELL_PER_CALL; cellIdx++)
        {
            ptCi->sCell[cellIdx] = ptCi->sCellDuConfig[cellIdx];
        }

        ptCi->caInfo.suspendA4Meas = FALSE;
        if (FnVCCB_CheckSkipCaA4MrWithMaxBw(ptCi))
        {
            ptCi->caInfo.suspendA4Meas = TRUE;
        }
    }

    ptCi->caInfo.lateCaMeasurements = FLAG_OFF;
    rMeasProc.lateFreqPrioMeas = FLAG_OFF;
    rMeasProc.caAwareMeasNeeded = FLAG_OFF;
    rMeasProc.lateLbMeas = FLAG_OFF;

    return;
}

/**
 * @brief MCO LB FR90: Fill LBCellInfo_type
 */
int16_t VLIB_McoLbFillLBCellInfo(callInfo_type *ptCi, cgi_type cgi, uint8_t gnbIdLength, LBCellInfo_type *ptLBCellInfo)
{

    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptLBCellInfo);

    const nbrGnbCellInfo_type *ptCell = VLIB_GetNbrGnbCellInfoBasedOnCgi(ptCi, cgi, gnbIdLength);
    VALID_E_POINT_CHECK_ERROR(ptCell);

    ptLBCellInfo->nrArfcnDl = ptCell->nrArfcnDl;
    ptLBCellInfo->nrScsDl = static_cast<enumNrSubCarrierSpacing_type>(ptCell->nrScsDl);
    ptLBCellInfo->nRbDl = static_cast<enumNrSystemBandwidth_type>(ptCell->nrbDl);
    ptLBCellInfo->bandwidthDl = ptCell->bandwidthDl;

    if (MAX_NR_ARFCN > ptCell->nrArfcnUl)
    {
        ptLBCellInfo->nrScsUl = static_cast<enumNrSubCarrierSpacing_type>(ptCell->nrScsUl);
        ptLBCellInfo->nRbUl = static_cast<enumNrSystemBandwidth_type>(ptCell->nrbUl);
        ptLBCellInfo->bandwidthUl = ptCell->bandwidthUl;
    }
    else // SDL cell
    {
        ptLBCellInfo->nrScsUl = ci_Nr_scsMAX;
        ptLBCellInfo->nRbUl = ci_NrSystemBandwidth_MAX;
        ptLBCellInfo->bandwidthUl = 0;
    }

    return GOOD;
}

/**
 * @brief MCO LB FR90: Get list containing potential SpCell and its possible SCells
 *
 * @param [in]  *ptCi               : call context
 * @param [in]  spCellNum           : potential SpCell number
 * @param [out] *ptLBCellInfoList   : tab with minimal size: MAX_COLOCCELL + 1. Filled if function returns GOOD
 * @param [out] *ptNoOfCells        : number of cells in ptLBCellInfoList
 * @return GOOD/BREAK/ERROR
 */
int16_t VLIB_McoLbGetAllServingCellsCandidates(callInfo_type *ptCi, uint16_t spCellNum, LBCellInfo_type *ptLBCellInfoList, std::size_t *ptNoOfCells)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptNoOfCells);
    VALID_E_POINT_CHECK_ERROR(ptLBCellInfoList);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    VCCB_CHECK_VALID_CELLNUM_ERROR(spCellNum);

    *ptNoOfCells = 0;

    caCellInfo_type pCellCaInfo, sCellCaInfo;

    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    VccbCellInfo_type *const pCell = &CELLINFO[spCellNum];
    uint8_t gnbIdLength = pGnb->globalGnbId.gnbId.idLength;
    cgi_type cgi = FnVCCB_GetNrcgiFromCellNum(spCellNum);

    if (GOOD != VLIB_FillCaCellInfo(ptCi, spCellNum, cgi, gnbIdLength, pCellCaInfo))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] Error when filling pcell ci(%llu) CA info!\n", 1ULL * cgi.ci);
        return ERROR;
    }

    if (GOOD != VLIB_McoLbFillLBCellInfo(ptCi, cgi, gnbIdLength, &ptLBCellInfoList[*ptNoOfCells]))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] Error when filling pcell ci(%llu) LB info!\n", 1ULL * cgi.ci);
        return ERROR;
    }
    ++(*ptNoOfCells);

    VCCB_CHECK_E_RANGE_AND_RETURN(pCellCaInfo.frequencyBand - 1, MAX_NUM_NR_BAND);

    if (!IS_CA_AVAILABLE(ptCi, pCell->nrCarrierAggregationInfo.caAvailable) ||
        (CaOperation_Off == pGnb->carrierAggregationInfo.bandOperationMode[pCellCaInfo.frequencyBand - 1].caOperationMode))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] Ca off for cellNum(%u)\n", spCellNum);
        return BREAK;
    }

    bcIdxArray_type filteredBcIndexes;
    if (GOOD != VLIB_getBcIndexesUsingPrioBasedScellSelect(ptCi, spCellNum, pCellCaInfo.frequencyBand, filteredBcIndexes))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] No Valid BC indexes found for PCell band(%u).\n", pCellCaInfo.frequencyBand);
        return BREAK;
    }

    uint16_t duCellNum;
    uint16_t maxLoop = MAX_CELL_PER_DU;
#ifdef __NVGNB__
    maxLoop = MAX_CELL_NUM_VCCB;
#endif

    const uint8_t currColocCellInfoUsage = pCell->cuColocCellInfo.colocCellInfoUsage;

    if (CI_use == currColocCellInfoUsage)
    {
        maxLoop = MAX_COLOCCELL;
    }

    for (uint16_t loop = 0; loop < maxLoop; loop++)
    {
        if (CI_no_use == currColocCellInfoUsage)
        {
#ifdef __NVGNB__
            const VccbCellInfo_type *const pCellofNVGNB = &CELLINFO[loop];

            if ((pCellofNVGNB->status != EQUIP) || (pCellofNVGNB->pldState != EQUIP))
            {
                continue;
            }
            duCellNum = loop;
#else
            gnbDuInfo_type *pGnbDu = &pGnb->gnbDu[pCell->endPointF1Index];
            if (EQUIP != pGnbDu->cellInDu[loop].status)
            {
                continue;
            }
            duCellNum = pGnbDu->cellInDu[loop].cellNum;
#endif
            VCCB_CHECK_E_RANGE_AND_CONTINUE(duCellNum, MAX_CELL_NUM_VCCB);
            cgi = FnVCCB_GetNrcgiFromCellNum(duCellNum);
            gnbIdLength = pGnb->globalGnbId.gnbId.idLength;
        }
        else
        {
            if ((CI_no_use == pCell->cuColocCellInfo.colocCellEntries[loop].usage) ||
                (TRUE != pCell->cuColocCellInfo.colocCellEntries[loop].useforNrca))
            {
                continue;
            }

            cgi.ci = VLIB_GnbIdCellId2NrCellId(&pCell->cuColocCellInfo.colocCellEntries[loop].globalGnbId.gnbId,
                pCell->cuColocCellInfo.colocCellEntries[loop].cellId);
            cgi.plmn = pCell->cuColocCellInfo.colocCellEntries[loop].globalGnbId.plmn;
            gnbIdLength = pCell->cuColocCellInfo.colocCellEntries[loop].globalGnbId.gnbId.idLength;
        }

        if (GOOD != VLIB_FillCaCellInfo(ptCi, spCellNum, cgi, gnbIdLength, sCellCaInfo))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] Error when filling scell ci(%llu) CA info!\n", 1ULL * cgi.ci);
            continue;
        }

        if (sCellCaInfo.frequencyBand != pCellCaInfo.frequencyBand)
        {
            continue;
        }

        if (GOOD != VLIB_IsCellEligibleForCA(ptCi, &pCellCaInfo, &sCellCaInfo, filteredBcIndexes))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] scell ci(%llu) not eligible!\n", 1ULL * cgi.ci);
            continue;
        }

        if (GOOD != VLIB_McoLbFillLBCellInfo(ptCi, cgi, gnbIdLength, &ptLBCellInfoList[*ptNoOfCells]))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] Error when filling ci(%llu) LB info!\n", 1ULL * cgi.ci);
            continue;
        }
        ++(*ptNoOfCells);
    }

    return GOOD;
}

/**
 * @brief MCO LB FR90: Get list containing SpCell and its possible SCells
 *
 * @param[in]   ptCi                : Pointer to call context.
 * @param[in]   spCellNum           : SpCell number.
 * @param[in]   bandNr              : SpCell band.
 * @param[out]  caCellInfoListOut   : Table to be filled in. Valid if function returns GOOD.
 * @param[out]  idx2CellNumTabOut   : Index to cellNum mapping table to be filled in. Valid if function returns GOOD.
 * @param[out]  eligibleCcIdxBitmskOut  : Eligible CC bitmask to be filled in. Valid if function returns GOOD.
 * @return GOOD/ERROR
 */
int16_t VLIB_McoLbGetAllServingCellsCandidates(callInfo_type *ptCi, const uint16_t spCellNum, const uint16_t bandNr,
    caCellInfoListMcoLb_type &caCellInfoListOut, mcoLbCellNumTab_type &idx2CellNumTabOut, uint8_t &eligibleCcIdxBitmskOut)
{
    AUTO_TRACE_FUNC;

    idx2CellNumTabOut.clear();
    eligibleCcIdxBitmskOut = 0u;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_VALID_CELLNUM_ERROR(spCellNum);
    VccbCellInfo_type *const pSpCell = &CELLINFO[spCellNum];

    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    caCellInfoListOut.clear();
    caCellInfo_type &rSpCellCaInfo = caCellInfoListOut.allocate();
    caCellInfo_type sCellCaInfo;

    uint8_t gnbIdLength = pGnb->globalGnbId.gnbId.idLength;
    cgi_type cgi = FnVCCB_GetNrcgiFromCellNum(spCellNum);

    if (GOOD != VLIB_FillCaCellInfo(ptCi, spCellNum, cgi, gnbIdLength, rSpCellCaInfo))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[MCO LB] Error when filling pcell ci(%llu) CA info!\n", 1ULL * cgi.ci);
        return ERROR;
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(bandNr - 1, MAX_NUM_NR_BAND);
    if (!IS_CA_AVAILABLE(ptCi, pSpCell->nrCarrierAggregationInfo.caAvailable) ||
        (CaOperation_Off == pGnb->carrierAggregationInfo.bandOperationMode[bandNr - 1].caOperationMode))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] CA off for cellNum(%u)\n", spCellNum);
        //  caCellInfoListOut includes SpCell only
        return GOOD;
    }

    bcIdxArray_type filteredBcIndexes;
    if (GOOD != VLIB_getBcIndexesUsingPrioBasedScellSelect(ptCi, spCellNum, bandNr, filteredBcIndexes))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[MCO LB] No Valid BC indexes found for PCell band(%u).\n", bandNr);
        return ERROR;
    }

    uint16_t duCellNum;
    uint16_t maxLoop = MAX_CELL_PER_DU;
#ifdef __NVGNB__
    maxLoop = MAX_CELL_NUM_VCCB;
#endif

    const bool colocCellInfoUsage = (CI_use == pSpCell->cuColocCellInfo.colocCellInfoUsage);
    uint32_t duBandCcIdx = 0u;

    if (colocCellInfoUsage)
    {
        maxLoop = MAX_COLOCCELL;
        eligibleCcIdxBitmskOut = 0x01;
        duBandCcIdx++;
        idx2CellNumTabOut.push_back(spCellNum);
    }

    for (uint16_t loop = 0; loop < maxLoop; loop++)
    {
        if (caCellInfoListOut.full())
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] Max num(%lu) of CC is reached!\n", caCellInfoListOut.capacity());
            break;
        }

        bool bCcAddedFlag = false;
        if (!colocCellInfoUsage)
        {
#ifdef __NVGNB__
            const VccbCellInfo_type *const pCellofNVGNB = &CELLINFO[loop];

            if ((pCellofNVGNB->status != EQUIP) || (pCellofNVGNB->pldState != EQUIP))
            {
                continue;
            }
            duCellNum = loop;
#else
            const gnbDuInfo_type *pGnbDu = &pGnb->gnbDu[pSpCell->endPointF1Index];
            if (EQUIP != pGnbDu->cellInDu[loop].status)
            {
                continue;
            }
            duCellNum = pGnbDu->cellInDu[loop].cellNum;
#endif
            VCCB_CHECK_E_RANGE_AND_CONTINUE(duCellNum, MAX_CELL_NUM_VCCB);

            duBandCcIdx++;
            if (!idx2CellNumTabOut.full())
            {
                idx2CellNumTabOut.push_back(duCellNum);
                bCcAddedFlag = true;
            }

            // check if not SpCell (already added)
            if (spCellNum == duCellNum)
            {
                eligibleCcIdxBitmskOut |= static_cast<uint8_t>(0x1u << (duBandCcIdx - 1));
                continue;
            }

            cgi = FnVCCB_GetNrcgiFromCellNum(duCellNum);
            gnbIdLength = pGnb->globalGnbId.gnbId.idLength;
        }
        else
        {
            colocCellEntries_type &rColocCellEntry = pSpCell->cuColocCellInfo.colocCellEntries[loop];
            if ((CI_no_use == rColocCellEntry.usage) || (TRUE != rColocCellEntry.useforNrca))
            {
                continue;
            }

            cgi.ci = VLIB_GnbIdCellId2NrCellId(&rColocCellEntry.globalGnbId.gnbId, rColocCellEntry.cellId);
            cgi.plmn = rColocCellEntry.globalGnbId.plmn;
            gnbIdLength = rColocCellEntry.globalGnbId.gnbId.idLength;

            duBandCcIdx++;
            if (!idx2CellNumTabOut.full())
            {
                // in case colocCellInfoUsage==true SCell num is unused and will not be checked as SpCell.
                idx2CellNumTabOut.push_back(MAX_CELL_NUM_VCCB);
                bCcAddedFlag = true;
            }
        }

        if (GOOD != VLIB_FillCaCellInfo(ptCi, spCellNum, cgi, gnbIdLength, sCellCaInfo))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] Error when filling scell ci(%llu) CA info!\n", 1ULL * cgi.ci);

            // Unsupported band case
            duBandCcIdx--;
            if (bCcAddedFlag)
            {
                idx2CellNumTabOut.pop_back();
            }
            continue;
        }

        if (sCellCaInfo.frequencyBand != bandNr)
        {
            duBandCcIdx--;
            if (bCcAddedFlag)
            {
                idx2CellNumTabOut.pop_back();
            }
            continue;
        }

        if (GOOD != VLIB_IsCellEligibleForCA(ptCi, &rSpCellCaInfo, &sCellCaInfo, filteredBcIndexes))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] scell ci(%llu) not eligible for CA!\n", 1ULL * cgi.ci);
            continue;
        }

        caCellInfoListOut.push_back(sCellCaInfo);
        eligibleCcIdxBitmskOut |= static_cast<uint8_t>(0x1u << (duBandCcIdx - 1));
    }

    // Sort cell list ascending by freq value
    std::stable_sort(caCellInfoListOut.begin(), caCellInfoListOut.end(),
        [](const caCellInfo_type &lhs, const caCellInfo_type &rhs)
            { return (lhs.nrArfcnDl < rhs.nrArfcnDl); });

    // Remove duplicates freq value
    caCellInfoListMcoLb_type::iterator caCellInfoListShrunkEnd =
        std::unique(caCellInfoListOut.begin(), caCellInfoListOut.end(),
            [](const caCellInfo_type &lhs, const caCellInfo_type &rhs)
                { return (lhs.nrArfcnDl == rhs.nrArfcnDl); });
    const std::size_t shrunkSize = static_cast<std::size_t>(std::distance(caCellInfoListOut.begin(), caCellInfoListShrunkEnd));
    if (caCellInfoListOut.size() > shrunkSize)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "[MCO LB] Removed (%lu) duplicated freq CC!\n", caCellInfoListOut.size() - shrunkSize);
        caCellInfoListOut.erase(caCellInfoListShrunkEnd, caCellInfoListOut.end());
    }

    return GOOD;
}

/**
 * @brief MCO LB FR90: Filter only SpCell contiguous cells from ptLBCellInfoList
 *
 * @param [in]  *ptCi                : call context
 * @param [in]  spCellNum            : potential SpCell number
 * @param [in]  spCellBand           : band of CELLINFO for which bandwidth will be calculated
 * @param [in/out] *ptLBCellInfoList : [in] tab of LB cell info. [out] list of sorted contiguous cells
 * @param [in/out] *ptNoOfCells      : number of cells in ptLBCellInfoList
 * @param [out] *ptPCellpos          : position of SpCell in ptLBCellInfoList
 * @return GOOD/BREAK/ERROR
 */
int16_t VLIB_McoLbFilterPCellContigousCells(callInfo_type *ptCi, uint16_t spCellNum, const uint16_t spCellBand, LBCellInfo_type *ptLBCellInfoList,
    std::size_t *ptNoOfCells, std::size_t *ptPCellpos)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptPCellpos);
    VALID_E_POINT_CHECK_ERROR(ptNoOfCells);
    VALID_E_POINT_CHECK_ERROR(ptLBCellInfoList);
    VCCB_CHECK_VALID_CELLNUM_ERROR(spCellNum);
    VCCB_CHECK_E_RANGE_AND_RETURN(*ptNoOfCells, MAX_COLOCCELL + 1);

    // Sort cell list ascending by freq value
    std::sort(ptLBCellInfoList, &ptLBCellInfoList[*ptNoOfCells],
        [](const LBCellInfo_type &lhs, const LBCellInfo_type &rhs)
        {
            return (lhs.nrArfcnDl < rhs.nrArfcnDl);
        });

    // Remove duplicates freq value
    LBCellInfo_type *pCellInfoShrunkEnd = std::unique(ptLBCellInfoList, &ptLBCellInfoList[*ptNoOfCells],
        [](const LBCellInfo_type &lhs, const LBCellInfo_type &rhs)
        { return (lhs.nrArfcnDl == rhs.nrArfcnDl); });
    const std::size_t shrunkSize = static_cast<std::size_t>(std::distance(ptLBCellInfoList, pCellInfoShrunkEnd));
    if (*ptNoOfCells > shrunkSize)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "[MCO LB] Cell removed (%lu) duplicated freq CC!\n", *ptNoOfCells - shrunkSize);
        *ptNoOfCells = shrunkSize;
    }

    //find pCell pos
    std::size_t pCellPos;
    for (pCellPos = 0; pCellPos < *ptNoOfCells; ++pCellPos)
    {
        if (ptLBCellInfoList[pCellPos].nrArfcnDl == CELLINFO[spCellNum].nrArfcnDl)
        {
            break;
        }
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(pCellPos, *ptNoOfCells);

    std::size_t leftPos = pCellPos;
    if (0 < pCellPos)
    {
        for (leftPos = pCellPos; 0 < leftPos; --leftPos)
        {
            if (GOOD != VLIB_CheckCaCellContiguous(ptLBCellInfoList[leftPos - 1], ptLBCellInfoList[leftPos], spCellBand))
            {
                break;
            }
        }
    }

    std::size_t rightPos = pCellPos;
    if (*ptNoOfCells - 1 > pCellPos)
    {
        for (rightPos = pCellPos; (*ptNoOfCells - 1) > rightPos; ++rightPos)
        {
            if (GOOD != VLIB_CheckCaCellContiguous(ptLBCellInfoList[rightPos], ptLBCellInfoList[rightPos + 1], spCellBand))
            {
                break;
            }
        }
    }

    if (0 < leftPos)
    {
        for (std::size_t i = 0; i <= (rightPos - leftPos); ++i)
        {
            ptLBCellInfoList[i] = ptLBCellInfoList[leftPos + i];
        }
    }

    *ptPCellpos = pCellPos - leftPos;
    *ptNoOfCells = (rightPos - leftPos + 1);

    return GOOD;
}

/**
 * @brief     MCO LB FR90: Function calculate max UL and DL BW in given contiguous cells group
 *            top priority is UL, so it is possible that DL will not be best at All
 * @param     maxDLcount: max number of contiguous DL cells - from DL band class
 * @param     maxULcount: max number of contiguous UL cells - from UL band class
 * @param     contCells: contiguous cells array
 * @param     psCellIdx: index of SpCell in contiguous group
 * @param     bestDlBW[out]: DL bw will be returned in this value
 * @param     bestUlBW[out]: UL bw will be returned in this value
 */
void VLIB_McoLbCalculateMaxUlBWforSpcellInCC(const int maxDLcount, const int maxULcount, const LBCellInfo_type *contCells,
    std::size_t noOfContCells, const int psCellIdx, uint16_t &bestDlBW, uint16_t &bestUlBW)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(contCells);
    VCCB_CHECK_E_RANGE_AND_VOID(psCellIdx, (int)noOfContCells);

    bestDlBW = 0;
    bestUlBW = 0;

    // determine boundaries of cells which need to be checked/calculated
    // cell with idx psCellIdx need to be in CC, and CC can not be bigger/longer
    // than maxDLcount
    const int DlStartIdx = std::max(0, psCellIdx - maxDLcount + 1);
    const int MaxDlIdx = std::min((int)noOfContCells, psCellIdx + maxDLcount);
    for (int dlIdx = DlStartIdx; dlIdx <= psCellIdx; ++dlIdx)
    {
        // only cells which fit in DL band class are checked (maxDLcount calculated from DL band class)
        // [psCellIdx - maxDLcount + 1; psCellIdx - maxDLcount - 1] - only cells in this subset are checked
        uint32_t curDlBW = 0;

        for (int idx = 0; (idx < maxDLcount) && (dlIdx + idx < MaxDlIdx); ++idx)
        {
            // subwindow for DL BW calculation - from dlIdx + idx only maxDLcount cells can be used
            curDlBW += contCells[dlIdx + idx].bandwidthDl;
        }

        // same as above - determining boundaries which need to be checked
        // because UL band is same or lower than DL band class UL is calculated inside DL loop
        // and UL need to fit in calculated DL frame - starting from dlIdx and maxDLcount cells
        const int UlStartIdx = std::max(dlIdx, psCellIdx - maxULcount + 1);
        const int MaxUlIdx = std::min(std::min(MaxDlIdx, (dlIdx + maxDLcount)),
                                      (psCellIdx + maxULcount));
        for (int ulIdx = UlStartIdx; (ulIdx <= psCellIdx) && ((ulIdx - UlStartIdx) < maxULcount); ++ulIdx)
        {
            // current window for DL: [dlIdx + idx; dlIdx + idx + maxDLcount - 1]
            // is narrowed by maxULcount and relation between starting index and psCellIdx
            // from that UL window is determined by [UlStartIdx, MaxUlIdx-1]
            uint32_t curUlBW = 0;
            int idx = 0;
            bool unsuppULFlag = false;
            bool pcellInclFlag = false;

            do
            {
                // special loop for UL BW calculation in case there will be a cell which do not support UL
                curUlBW = 0;
                unsuppULFlag = false;
                for (int ccCount = 0; (ccCount < maxULcount) && (ulIdx + idx < MaxUlIdx) && (ccCount < maxDLcount) && (ulIdx + idx < dlIdx + MaxDlIdx);
                     ++ccCount, ++idx)
                {
                    // subwindow for UL BW calculation - from ulIdx + idx only maxULcount cells can be used
                    if ((ci_NrSystemBandwidth_MAX == contCells[ulIdx + idx].nRbUl)
                        || (ci_Nr_scsMAX == contCells[ulIdx + idx].nrScsUl)
                        || (0 == contCells[ulIdx + idx].bandwidthUl))
                    {
                        unsuppULFlag = true;
                        ++idx;
                        break;
                    }
                    if (ulIdx + idx == psCellIdx)
                    {
                        pcellInclFlag = true;
                    }
                    curUlBW += contCells[ulIdx + idx].bandwidthUl;

                }
                if (pcellInclFlag &&
                    (((curUlBW > bestUlBW)) || ((curUlBW == bestUlBW) && (curDlBW > bestDlBW))))
                {
                    bestUlBW = static_cast<uint16_t>(curUlBW);
                    bestDlBW = static_cast<uint16_t>(curDlBW);
                }
            }
            // if pcell was included and cell without UL found there is no sense to check after - it will be not contiguous with pcell
            while (unsuppULFlag && !pcellInclFlag);
        }
    }
}

/**
 * @brief     MCO LB FR90: Helper function for VLIB_McoLbCalculateMaxUlBWforSpcell, in given Band Combination it looks for broadest
              band item for specified band (band param), and return its max possible number of CC for UL and DL
              (UL have highest priority)
 * @param     ueSupBandCombList: Band Combination list
 * @param     band: band for item which should be found
 * @param     maxCcDlCount[out]: max number of CC items on band for DL
 * @param     maxCcUlCount[out]: max number of CC items on band for UL
 */
void VLIB_McoLbGetMaxUlContiguousCcCountForBand(bandCombinationList_type *ueSupBandCombList, uint16_t band, int &maxCcDlCount, int &maxCcUlCount)
{
    AUTO_TRACE_FUNC;
    maxCcDlCount = 0;
    maxCcUlCount = 0;
    VALID_E_POINT_CHECK_VOID(ueSupBandCombList);

    // going through UE nr band combinations lists and find list with band for cur serving cell
    for (uint16_t ueBandListIdx = 0; ueBandListIdx < UMIN(ueSupBandCombList->num, MAX_BAND_COMBS); ++ueBandListIdx)
    {
        BandCombination_type *ueSupportedBandCombination = &ueSupBandCombList->bandCombination[ueBandListIdx];
        for (uint16_t idx = 0; idx < UMIN(ueSupportedBandCombination->num, MAX_BANDS_PER_COMB); ++idx)
        {
            if ((band == ueSupportedBandCombination->band[idx].freqBandIndicator) &&
                (ci_nr == ueSupportedBandCombination->band[idx].ratType) &&
                ((ueSupportedBandCombination->band[idx].numContiguousCcUL > maxCcUlCount) ||
                    ((ueSupportedBandCombination->band[idx].numContiguousCcUL == maxCcUlCount) &&
                        (ueSupportedBandCombination->band[idx].numContiguousCcDL > maxCcDlCount))))
            {
                maxCcDlCount = ueSupportedBandCombination->band[idx].numContiguousCcDL;
                maxCcUlCount = ueSupportedBandCombination->band[idx].numContiguousCcUL;
            }
        }
    }
}

/**
 * @brief     MCO LB FR90: Takes SpCell number (spCellNum) and prepare CC groups (from coloc cells list if it was configured or from
 *            cells on same DU as specified spCellNum with same band) and calculate bandwidth (UL is more important than DL)
 *            and returns the best found BW. The calculation is done for one CC group which has the highest UL band class.
 * @param     ptCi : call context
 * @param     spCellNum: cell num from CELLINFO for which bandwidth will be calculated
 * @param     spCellBand: band of CELLINFO for which bandwidth will be calculated
 * @param     pDlBW[out]: best DL bandwidth will be returned in this parameter (it is best DL for best UL - UL is more important)
 * @param     pUlBW[out]: best UL bandwidth will be returned in this parameter
 * @return    GOOD: success, otherwise ERROR
 */
int16_t VLIB_McoLbCalculateMaxUlBWforSpcell(callInfo_type *ptCi,
        const uint16_t spCellNum,
        const uint16_t spCellBand,
        int maxCcDlCount,
        int maxCcUlCount,
        LBCellInfo_type *intraDuLbCellInfoList,
        std::size_t *ptNoOfIntraDuLbCells,
        uint16_t *pDlBW,
        uint16_t *pUlBW)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(intraDuLbCellInfoList);
    VCCB_CHECK_VALID_CELLNUM_ERROR(spCellNum);
    VALID_E_POINT_CHECK_ERROR(pDlBW);
    VALID_E_POINT_CHECK_ERROR(pUlBW);

    *pUlBW = 0;
    *pDlBW = 0;

    LBCellInfo_type lbCellInfoList[MAX_COLOCCELL + 1];
    std::size_t noOfCells = 0;

    if (CI_use == CELLINFO[spCellNum].cuColocCellInfo.colocCellInfoUsage)
    {
        // for colocCell VLIB_McoLbGetAllServingCellsCandidates will be called always
        VCCB_RETURN_ON_CALL_ERROR(ptCi, VLIB_McoLbGetAllServingCellsCandidates(ptCi, spCellNum, lbCellInfoList, &noOfCells),
            "VLIB_McoLbGetAllServingCellsCandidates returns ERROR\n");
    }
    else
    {
        if (0 == *ptNoOfIntraDuLbCells)
        {
            // ensure function VLIB_McoLbGetAllServingCellsCandidates will be called only once for non-coloc
            VCCB_RETURN_ON_CALL_ERROR(ptCi, VLIB_McoLbGetAllServingCellsCandidates(ptCi, spCellNum, intraDuLbCellInfoList, ptNoOfIntraDuLbCells),
                "VLIB_McoLbGetAllServingCellsCandidates returns ERROR\n");
        }

        for (std::size_t i = 0; i <= *ptNoOfIntraDuLbCells; ++i)
        {
            lbCellInfoList[i] = intraDuLbCellInfoList[i];
        }
        noOfCells = *ptNoOfIntraDuLbCells;
    }

    std::size_t spCellIdx = 0;
    VCCB_RETURN_ON_CALL_ERROR(ptCi, VLIB_McoLbFilterPCellContigousCells(ptCi, spCellNum, spCellBand, lbCellInfoList, &noOfCells, &spCellIdx),
        "VLIB_McoLbFilterPCellContigousCells returns ERROR\n");

    VLIB_McoLbCalculateMaxUlBWforSpcellInCC(maxCcDlCount, maxCcUlCount, lbCellInfoList, noOfCells, static_cast<int>(spCellIdx), *pDlBW, *pUlBW);
    VCCB_PRINT_CALL_COMMENT(
        ptCi,"[MCO LB] band:%d maxCcDlCount:%d maxCcUlCount:%d noOfCells:%d psCellIdx:%d pDlBW:%d, pUlBW:%d\n",
        spCellBand, maxCcDlCount, maxCcUlCount, static_cast<int>(noOfCells), static_cast<int>(spCellIdx), *pDlBW, *pUlBW);

    return GOOD;
}

/**
 * @brief MCO LB FR90: Get cached result.
 */
bool FnVCCB_McoLbGetCachedResult(callInfo_type &rCall, const uint16_t spCellNum,
    const candidateCellListForSort_type &ccListForSort, const uint8_t eligibleCcIdxBitmsk,
    const McoLbCacheUeBcKey_type ueBcKey, const mcoLbCellNumTab_type &rIdx2CellNumTab,
    bool spCellCheckedTabOut[MAX_NUM_CANDIDATE_CELL_FOR_PSCELL], mcoLbResult_s &lbResultOut)
{
    AUTO_TRACE_FUNC;

    McoLbCacheResultEntry_type cacheResult;
    if (false == FnVCCB_FindMcoLbCellCache(spCellNum, eligibleCcIdxBitmsk, ueBcKey, cacheResult))
    {
        VCCB_PRINT_CALL_COMMENT(&rCall, "[MCO LB CACHE] spCellNum(%u) cache not found\n", spCellNum);
        return false;
    }

    uint32_t bestCandidateIdx = ccListForSort.nrofCells;
    uint32_t minUeCount = std::numeric_limits<uint32_t>::max();
    uint32_t idxBit = 0x01;
    for (uint32_t loop = 0; loop < rIdx2CellNumTab.size(); loop++, idxBit <<= 1)
    {
        if (0 == (idxBit & cacheResult.checkedSpCellsBitmask))
        {
            continue;
        }

        const CellNum_type tmpCellNum = rIdx2CellNumTab[loop];
        const candidateCellForSort_type *ccListForSortEndIt = ccListForSort.candidateCell + ccListForSort.nrofCells;
        const candidateCellForSort_type *candCellIt = std::find_if(ccListForSort.candidateCell, ccListForSortEndIt,
            [&tmpCellNum](const candidateCellForSort_type &rCCFS){ return tmpCellNum == rCCFS.cellNum; });

        if (ccListForSortEndIt == candCellIt)
        {
            VCCB_PRINT_CALL_ERROR(&rCall, "[MCO LB CACHE] Could not find candidate cellNum(%u) idx(%u) from cached result!\n",
                tmpCellNum, loop);
            continue;
        }

        const uint32_t candidateCellIdx = static_cast<uint32_t>(std::distance(ccListForSort.candidateCell, candCellIt));
        if (candidateCellIdx >= ccListForSort.nrofCells)
        {
            VCCB_PRINT_CALL_ERROR(&rCall, "[MCO LB CACHE] candidateCellIdx(%u) out of range(%u)!\n", candidateCellIdx,
                ccListForSort.nrofCells);
            continue;
        }

        spCellCheckedTabOut[candidateCellIdx] = true;

        if (0 == (idxBit & cacheResult.bestSpCellsBitmask))
        {
            continue;
        }

        const candidateCellForSort_type &rCandidateCell = *candCellIt;
        if (minUeCount > rCandidateCell.ueCount)
        {
            minUeCount = rCandidateCell.ueCount;
            bestCandidateIdx = candidateCellIdx;
        }
    }

    if (bestCandidateIdx >= ccListForSort.nrofCells)
    {
        VCCB_PRINT_CALL_ERROR(&rCall,
            "[MCO LB CACHE] spCellNum(%u) chkdMsk(0x%02X) bestMsk(0x%02X) - Cannot find any best candidate from cached result!\n",
            spCellNum, cacheResult.checkedSpCellsBitmask, cacheResult.bestSpCellsBitmask);
        return false;
    }

    const candidateCellForSort_type &rBestCandidateCell = ccListForSort.candidateCell[bestCandidateIdx];
    VCCB_PRINT_CALL_COMMENT(&rCall,
        "[MCO LB CACHE] spCellNum(%u) BW(%u/%u) chkdMsk(0x%02X) bestMsk(0x%02X) - candidate: idx(%u) ueCount(%u) cellNum(%u) PCI(%u)\n",
        spCellNum, cacheResult.bwDl, cacheResult.bwUl, cacheResult.checkedSpCellsBitmask,
        cacheResult.bestSpCellsBitmask, bestCandidateIdx, rBestCandidateCell.ueCount, rBestCandidateCell.cellNum,
        rBestCandidateCell.physCellId);

    lbResultOut._candidateIdx = static_cast<uint8_t>(bestCandidateIdx);
    lbResultOut._bwDl = cacheResult.bwDl;
    lbResultOut._bwUl = cacheResult.bwUl;
    return true;
}

/**
 * @brief MCO LB FR90: Set result to cache.
 */
void FnVCCB_McoLbSetResultToCache(callInfo_type &rCall, const candidateCellListForSort_type &ccListForSort,
    const uint8_t firstCandidateIdx, const uint8_t eligibleCcIdxBitmsk, const McoLbCacheUeBcKey_type ueBcKey,
    const mcoLbCellNumTab_type &rIdx2CellNumTab, const bool spCellCheckedTab[MAX_NUM_CANDIDATE_CELL_FOR_PSCELL],
    const mcoLbResult_s &lbResult)
{
    AUTO_TRACE_FUNC;

    uint32_t checkedSpCellsBitmask = 0;
    uint32_t bestSpCellsBitmask = 0;
    uint32_t idxBit = 1u << firstCandidateIdx;
    const uint32_t maxCandIdx = std::min(ccListForSort.nrofCells, static_cast<uint8_t>(MAX_MCO_LB_CC_PER_BAND));
    for (uint32_t candIdx = firstCandidateIdx; maxCandIdx > candIdx; candIdx++, idxBit <<= 1)
    {
        if (false == spCellCheckedTab[candIdx])
        {
            continue;
        }

        const candidateCellForSort_type &rCandidateCell = ccListForSort.candidateCell[candIdx];
        auto cellNumIdxTabIt = std::find(rIdx2CellNumTab.begin(), rIdx2CellNumTab.end(), rCandidateCell.cellNum);
        if (rIdx2CellNumTab.end() == cellNumIdxTabIt)
        {
            VCCB_PRINT_CALL_ERROR(&rCall, "[MCO LB CACHE] Could not find cell index of candidateIdx(%u) cellNum(%u)!\n",
                candIdx, rCandidateCell.cellNum);
            continue;
        }

        const auto spCellBit = (1u << std::distance(rIdx2CellNumTab.begin(), cellNumIdxTabIt));
        checkedSpCellsBitmask |= spCellBit;
        if (idxBit & lbResult._candidateBitmask)
        {
            bestSpCellsBitmask |= spCellBit;
        }
    }

    McoLbCacheResultEntry_type cacheResult;
    cacheResult.eligibleCcIdxBitmsk = eligibleCcIdxBitmsk;
    cacheResult.bestSpCellsBitmask = static_cast<uint8_t>(bestSpCellsBitmask);
    cacheResult.checkedSpCellsBitmask = static_cast<uint8_t>(checkedSpCellsBitmask);
    cacheResult.bwDl = lbResult._bwDl;
    cacheResult.bwUl = lbResult._bwUl;
    cacheResult.ueBcKey = ueBcKey;
    cacheResult.hitTime = time(NULL);

    for (uint32_t candIdx = firstCandidateIdx; maxCandIdx > candIdx; candIdx++)
    {
        if (false == spCellCheckedTab[candIdx])
        {
            continue;
        }

        const CellNum_type candCellNum = ccListForSort.candidateCell[candIdx].cellNum;
        VCCB_CHECK_E_RANGE_AND_CONTINUE(candCellNum, MAX_CELL_NUM_VCCB);

        VCCB_PRINT_CALL_COMMENT(&rCall, "[MCO LB CACHE] Store spCellNum(%u): BW(%u/%u) chkdMsk(0x%02X) bestMsk(0x%02X) candMsk(0x%02X)\n",
            candCellNum, lbResult._bwDl, lbResult._bwUl, bestSpCellsBitmask, checkedSpCellsBitmask, lbResult._candidateBitmask);

        FnVCCB_SetMcoLbCellCache(candCellNum, cacheResult);
    }
}

/**
 * @brief MCO LB FR90: Check candidate SpCell list with common CA configuration
 *
 * @param[in]  ptCi                 : Pointer to call context.
 * @param[in]  ueSupBandCombList    : UE supported Band Combination List.
 * @param[in]  ccListForSort        : Candidate SpCell list to be checked.
 * @param[in]  firstCandidateIdx    : Index of first candidate used as reference SpCell configuration.
 * @param[out] spCellCheckedTab     : Set to true for candidate's index that was checked for SpCell by this function.
 * @param[out] lbResultOut          : Result for best candidate.
 * @return GOOD/ERROR
 */
int16_t FnVCCB_McoLbCheckCommonCfgSpCellCandidates(callInfo_type *ptCi, const bandCombinationList_type &ueSupBandCombList,
    const candidateCellListForSort_type &ccListForSort, const uint8_t firstCandidateIdx,
    bool spCellCheckedTab[MAX_NUM_CANDIDATE_CELL_FOR_PSCELL], mcoLbResult_s &lbResultOut)
{
    AUTO_TRACE_FUNC;

    lbResultOut.reset();

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_LIST_COUNT_AND_RETURN(ccListForSort.nrofCells, MAX_NUM_CANDIDATE_CELL_FOR_PSCELL);

    if (firstCandidateIdx >= ccListForSort.nrofCells)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[MCO LB] 1stCI(%u) out of range(%u)!\n", firstCandidateIdx,
            ccListForSort.nrofCells);
        return ERROR;
    }

    // Use 1st candidateCell as reference SpCell
    const uint16_t spCellNum = ccListForSort.candidateCell[firstCandidateIdx].cellNum;
    const uint16_t bandNr = ccListForSort.candidateCell[firstCandidateIdx].bandNr;

    VCCB_CHECK_VALID_CELLNUM_ERROR(spCellNum);
    VccbCellInfo_type *const pSpCell = &CELLINFO[spCellNum];

    caCellInfoListMcoLb_type cellInfoList;
    mcoLbCellNumTab_type idx2CellNumTab;
    uint8_t eligibleCcIdxBitmsk = 0u;
    int16_t status = VLIB_McoLbGetAllServingCellsCandidates(ptCi, spCellNum, bandNr, cellInfoList, idx2CellNumTab,
        eligibleCcIdxBitmsk);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VLIB_McoLbGetAllServingCellsCandidates returns ERROR\n");

    if (1 == cellInfoList.size())
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] Only one CC: cellNum(%u) CandIdx(%u)\n", spCellNum, firstCandidateIdx);
        const caCellInfo_type &rSpCellCaInfo = cellInfoList[0];
        lbResultOut._bwDl = rSpCellCaInfo.mcoBwDl;
        // FGR-CC5500, FR90: For FR2 Cells use DL BW value for UL BW assuming they are in proportion.
        lbResultOut._bwUl = rSpCellCaInfo.mcoBwDl;
        lbResultOut._candidateIdx = firstCandidateIdx;
        spCellCheckedTab[firstCandidateIdx] = true;
        return GOOD;
    }

    const VccbDbgInfo_type *const pDbg = DBG;
    const mcoLbUeBcKey_type ueBcKey =
        ((pDbg->flag.mcoLbCacheEnable) ? FnVCCB_McoLbGetUeBcKey(*ptCi, ueSupBandCombList, bandNr) : 0);

    if (pDbg->flag.mcoLbCacheEnable)
    {
        for (size_t loop = 0; loop < idx2CellNumTab.size(); loop++)
        {
            const CellNum_type tmpCellNum = idx2CellNumTab[loop];
            const bool tmpCellNumValid = (tmpCellNum < MAX_CELL_NUM_VCCB);
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB CACHE] idx2CellNumTab[%lu](%u)%s%.0lu%s%s\n", loop, tmpCellNum,
                tmpCellNumValid ? " ci(" : "", tmpCellNumValid ? CELLINFO[tmpCellNum].cgi.ci : 0, tmpCellNumValid ? ")": "",
                (eligibleCcIdxBitmsk & (1u << loop)) ? " eligible" : "");
        }

        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB CACHE] spCellNum(%u) key(0x%02X/0x%016lX%016lX)\n", spCellNum,
            eligibleCcIdxBitmsk, static_cast<uint64_t>(ueBcKey >> 64), static_cast<uint64_t>(ueBcKey));

        if (true == FnVCCB_McoLbGetCachedResult(*ptCi, spCellNum, ccListForSort, eligibleCcIdxBitmsk, ueBcKey, idx2CellNumTab,
                spCellCheckedTab, lbResultOut))
        {
            return GOOD;
        }
    }

    // iterate over bands and create contiguous CC groups
    mcoBand2mcoCcInfoVecMap_type ccInfoVecPerBand;
    if (CI_use == pSpCell->cuColocCellInfo.colocCellInfoUsage)
    {
        auto fnSetCcInfoIndividual = [&pSpCell, &firstCandidateIdx, &spCellCheckedTab]
            (mcoCcInfo_s &ccInfoOut, const caCellInfo_type &caCellInfoIn, const uint8_t grpIdCurrIn)
        {
            ccInfoOut.mcoBwDl = caCellInfoIn.mcoBwDl;
            ccInfoOut.grpId = grpIdCurrIn;
            ccInfoOut.pcellFlag = false;
            ccInfoOut.userValue = 0;
            ccInfoOut.altBand = BAND_NOT_FOUND;

            if (pSpCell->nrArfcnDl == caCellInfoIn.nrArfcnDl)
            {
                ccInfoOut.pcellFlag = true;
                ccInfoOut.userValue = firstCandidateIdx;
                spCellCheckedTab[ccInfoOut.userValue] = true;
            }
        };

        FnVCCB_McoCreateContigCcGroupsPerBand(cellInfoList.begin(), cellInfoList.end(), ccInfoVecPerBand, fnSetCcInfoIndividual);
    }
    else
    {
        auto fnSetCcInfoCommon = [&ptCi, &ccListForSort, &spCellCheckedTab]
            (mcoCcInfo_s &ccInfoOut, const caCellInfo_type &caCellInfoIn, const uint8_t grpIdCurrIn)
        {
            ccInfoOut.mcoBwDl = caCellInfoIn.mcoBwDl;
            ccInfoOut.grpId = grpIdCurrIn;
            ccInfoOut.pcellFlag = false;
            ccInfoOut.userValue = 0;
            ccInfoOut.altBand = BAND_NOT_FOUND;
            const VccbCellInfo_type *const pCells = CELLINFO;

            const candidateCellForSort_type *pElemLast = &ccListForSort.candidateCell[ccListForSort.nrofCells];
            const candidateCellForSort_type *pElemIt = std::find_if(&ccListForSort.candidateCell[0], pElemLast,
                [&caCellInfoIn, &pCells](const candidateCellForSort_type &cell)
                {
                    return ((cell.cellNum < MAX_CELL_NUM_VCCB) && (pCells[cell.cellNum].cgi.ci == caCellInfoIn.cgi.ci));
                });

            if ((pElemLast == pElemIt) || (pElemIt->cellNum >= MAX_CELL_NUM_VCCB))
            {
                return;
            }

            const VccbCellInfo_type *const pCandidateCell = &pCells[pElemIt->cellNum];
            if ((CI_use == pCandidateCell->cuColocCellInfo.colocCellInfoUsage) ||
                !IS_CA_AVAILABLE(ptCi, pCandidateCell->nrCarrierAggregationInfo.caAvailable))
            {
                return;
            }

            ccInfoOut.pcellFlag = true;
            ccInfoOut.userValue = static_cast<uint32_t>(pElemIt - &ccListForSort.candidateCell[0]);
            spCellCheckedTab[ccInfoOut.userValue] = true;
        };

        FnVCCB_McoCreateContigCcGroupsPerBand(cellInfoList.begin(), cellInfoList.end(), ccInfoVecPerBand, fnSetCcInfoCommon);
    }

    // print output for debug
    for (mcoBand2mcoCcInfoVecMap_type::value_type &kv : ccInfoVecPerBand)
    {
        mcoCcInfoVec_type &ccInfoVec = kv.second.ccInfoVec;

        VCCB_PRINT_CALL_COMMENT(ptCi, "====== [MCO LB] CC groups: band(%u) 1stCI(%u) ======\n", kv.first, firstCandidateIdx);

        for (std::size_t ccIdx = 0; ccIdx < ccInfoVec.size(); ccIdx++)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] CC: ccIdx(%lu) contGrpId(%u) CandIdx(%u) isCandidate(%u) BW(%u)\n", ccIdx,
                ccInfoVec[ccIdx].grpId, ccInfoVec[ccIdx].userValue, ccInfoVec[ccIdx].pcellFlag, ccInfoVec[ccIdx].mcoBwDl);
        }
    }

    FnVCCB_McoLbCheckSpCellCandidatesAgainstAllBc(ptCi, ueSupBandCombList, ccInfoVecPerBand, bandNr, ccListForSort, lbResultOut);
    if (lbResultOut._candidateIdx >= ccListForSort.nrofCells)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] Could not select any candidate 1stCI(%u)!\n", firstCandidateIdx);
        return ERROR;
    }

    const candidateCellForSort_type &rCandidateCell = ccListForSort.candidateCell[lbResultOut._candidateIdx];
    VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] Proposed 1stCI(%u) candidate: idx(%u) BW(%u/%u) ueCount(%u) cellNum(%u) PCI(%u)\n",
        firstCandidateIdx, lbResultOut._candidateIdx, lbResultOut._bwDl, lbResultOut._bwUl, rCandidateCell.ueCount,
        rCandidateCell.cellNum, rCandidateCell.physCellId);

    if (pDbg->flag.mcoLbCacheEnable)
    {
        FnVCCB_McoLbSetResultToCache(*ptCi, ccListForSort, firstCandidateIdx, eligibleCcIdxBitmsk, ueBcKey, idx2CellNumTab,
            spCellCheckedTab, lbResultOut);
    }

    return GOOD;
}

/**
 * @brief     MCO LB FR90: Select best SpCell
 * @param     ptCi : call context
 * @param     pListForSort : list of cell candidates
 * @return    Index of selected SpCell in pListForSort, (-1) in case of ERROR
 */
int VLIB_McoLbSelectBestSpcell(callInfo_type *ptCi, const candidateCellListForSort_type *pListForSort)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, -1);
    VALID_E_POINT_CHECK_RET_VAL(pListForSort, -1);

    LBCellInfo_type intraDuLbCellInfoList[MAX_COLOCCELL + 1];
    std::size_t noOfIntraDuCells = 0;
    uint16_t maxBandwidthUl = 0;
    uint16_t maxBandwidthDl = 0;
    int bestIdx = -1;
    int maxCcDlCount = 0;
    int maxCcUlCount = 0;
    uint16_t spCellBandPrev = BAND_NOT_FOUND;

    bandCombinationList_type *pUeSupBandCombList = VRIL_GetBandCombinationList(ptCi);
    VALID_E_POINT_CHECK_RET_VAL(pUeSupBandCombList, -1);

    for (int idx = 0; idx < pListForSort->nrofCells; ++idx)
    {
        const candidateCellForSort_type *pCellCandidate = &pListForSort->candidateCell[idx];
        const uint16_t spCellNum = pCellCandidate->cellNum;
        VCCB_CHECK_E_RANGE_AND_CONTINUE(spCellNum, MAX_CELL_NUM_VCCB);
        VccbCellInfo_type *const pSpCell = &CELLINFO[spCellNum];
        const uint16_t spCellBand = pCellCandidate->bandNr;

        if (spCellBand != spCellBandPrev)
        {
            VLIB_McoLbGetMaxUlContiguousCcCountForBand(pUeSupBandCombList, spCellBand, maxCcDlCount, maxCcUlCount);
            noOfIntraDuCells = 0;
            spCellBandPrev = spCellBand;
        }

        uint16_t bandwidthDl = 0;
        uint16_t bandwidthUl = 0;
        if (GOOD !=
            VLIB_McoLbCalculateMaxUlBWforSpcell(ptCi, spCellNum, spCellBand, maxCcDlCount, maxCcUlCount,
                intraDuLbCellInfoList, &noOfIntraDuCells, &bandwidthDl, &bandwidthUl))
        {
            continue;
        }
        if (bandwidthUl > maxBandwidthUl)
        {
            bestIdx = idx;
            maxBandwidthUl = bandwidthUl;
            maxBandwidthDl = bandwidthDl;
        }
        else if ((bandwidthUl == maxBandwidthUl) && (bandwidthDl > maxBandwidthDl))
        {
            bestIdx = idx;
            maxBandwidthDl = bandwidthDl;
        }

        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] candidate: %d, ul bw: %d, UE count: %d\n",
            pSpCell->phyCellId, bandwidthUl, pCellCandidate->ueCount);
    }

    return bestIdx;
}

/**
 * @brief MCO LB FR90: Select best SpCell (SVR23B version)
 * @param[in]   ptCi                 : Pointer to call context.
 * @param[in]   pListForSort         : Candidate SpCell list to be checked.
 * @return      Index of selected SpCell in pListForSort, (-1) in case of ERROR
 */
int VLIB_McoLbSelectBestSpcell2(callInfo_type *ptCi, const candidateCellListForSort_type *pListForSort)
{
    AUTO_TRACE_FUNC;
    static const int INVALID_CANDIDATE_CELL_INDEX = -1;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, INVALID_CANDIDATE_CELL_INDEX);
    VALID_E_POINT_CHECK_RET_VAL(pListForSort, INVALID_CANDIDATE_CELL_INDEX);
    VCCB_CHECK_LIST_COUNT_AND_VAL(pListForSort->nrofCells, MAX_NUM_CANDIDATE_CELL_FOR_PSCELL, INVALID_CANDIDATE_CELL_INDEX);

    bandCombinationList_type *ptUeSupBandCombList = VRIL_GetBandCombinationList(ptCi);
    VALID_E_POINT_CHECK_RET_VAL(ptUeSupBandCombList, INVALID_CANDIDATE_CELL_INDEX);

    bool spCellCheckedTab[MAX_NUM_CANDIDATE_CELL_FOR_PSCELL] = {false};
    mcoLbResult_s tmpResult;
    mcoLbResult_s bestResult;

    for (uint8_t candidateIdx = 0; candidateIdx < pListForSort->nrofCells; candidateIdx++)
    {
        if (spCellCheckedTab[candidateIdx])
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] CandIdx(%u) already checked\n", candidateIdx);
            continue;
        }

        if ((GOOD != FnVCCB_McoLbCheckCommonCfgSpCellCandidates(ptCi, *ptUeSupBandCombList, *pListForSort, candidateIdx,
                spCellCheckedTab, tmpResult)) ||
            (tmpResult._candidateIdx >= pListForSort->nrofCells))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[MCO LB] CandIdx(%u) check fail!\n", candidateIdx);
            continue;
        }

        // Select the best candidate
        bestResult.setIfBetter(tmpResult._bwDl, tmpResult._bwUl, tmpResult._candidateIdx);
    }

    if (bestResult._candidateIdx >= pListForSort->nrofCells)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] Could not find any candidate!\n");
        return INVALID_CANDIDATE_CELL_INDEX;
    }

    const candidateCellForSort_type &rCandidateCell = pListForSort->candidateCell[bestResult._candidateIdx];
    VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] Best candidate: idx(%u) BW(%u/%u) ueCount(%u) cellNum(%u) PCI(%u)\n",
        bestResult._candidateIdx, bestResult._bwDl, bestResult._bwUl, rCandidateCell.ueCount, rCandidateCell.cellNum,
        rCandidateCell.physCellId);

    return bestResult._candidateIdx;
}

/**
 * @brief Select Top Band Combination to calculate the total Max Cell BandWidth for Top BC.
 *        Operates when caOperationMode is Mode2, Mode3, Mode5.
 *        In the case of Mode3, the SCC state must be SCC_NOT_SET.
 * @param ptCi
 */
void FnVCCB_CalculateTotalMaxBwForCa(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    bool triggerFlag = false;

    switch(ptCi->caInfo.mode)
    {
        case CaOperation_Mode3:
            if (ptCi->sccData.state == SCC_NOT_SET)
            {
                triggerFlag = true;
            }
            // this function doesn't work when sccChange is on
            break;

        case CaOperation_Mode2:
        case CaOperation_Mode5:
            triggerFlag = true;
            break;

        default:
            break;
    }

    if (false == triggerFlag)
    {
        ptCi->caInfo.totalMaxBw = UNKNOWN_BANDWIDTH;
        return;
    }

    // 1. Select SpCell
    const cellSelection_type cellSelection = FnVCCB_GetCellSelectionForConfig(ptCi);
    VCCB_PRINT_LOG_CA_FUNC(ptCi, "[CA] Calculation of the Top of BC based on (SpCell=cellNum:%u/bandNr:%u)\n", cellSelection.cellNum, cellSelection.bandNr);
    ptCi->caInfo.totalMaxBw = 0;

    // 2. Call the existing function (FnVCCB_McoSelectScellsForMaxBw) in SCC Change Feature
    //   - When calculate Total MAX BW in Call Procedure for CA, Unlike SCC Change
    //   - The difference is not consider MFBI. set true to noMfbiFlag
    bool bestSCellsMap[MAX_SCELL_PER_CALL];
    uint16_t sCellAltBand[MAX_MCO_MFBI_CELLS] = {BAND_NOT_FOUND, BAND_NOT_FOUND, BAND_NOT_FOUND};
    uint32_t sCellIdxWithAltBand[MAX_MCO_MFBI_CELLS] = {MAX_SCELL_PER_CALL, MAX_SCELL_PER_CALL, MAX_SCELL_PER_CALL};
    int16_t status = FnVCCB_McoSelectScellsForMaxBW(ptCi, bestSCellsMap, sCellAltBand, sCellIdxWithAltBand, cellSelection, true);

    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR while calling FnVCCB_McoSelectScellsForMaxBW\n");
        return;
    }

    // 3. Current Added Scell or SCELL_STATE of scells is SCELL_STATE_MRREL
    //   - Calculate BW for Scell mapped to bestSCellsMap[..]
    //   - then, the BW simply is BW(MHz) in the Cell.
    //   - PrbUsage, DlMimoLayer is not considered
    uint32_t calculatedTotalMaxBw = 0;
    uint8_t numAddScells = 0;
    caScellCcInfo_type sCellCcInfo;
    VCCB_PRINT_LOG_CA_FUNC(ptCi, "[CA][num] TotalMaxBw(+sCellBW(Idx/State/bandNr))\n");
    for (uint16_t sCellIdx = 0; sCellIdx < MAX_SCELL_PER_CALL; sCellIdx++)
    {
        if ((SCELL_STATE_ADDED == ptCi->sCell[sCellIdx].state) ||
            (SCELL_STATE_MRREL == ptCi->sCell[sCellIdx].state) ||
            (SCELL_STATE_CCLIMITREL == ptCi->sCell[sCellIdx].state))
        {
            if (bestSCellsMap[sCellIdx])
            {
                const scellInfo_type &rSCell = ptCi->sCell[sCellIdx];
                sCellCcInfo.frequencyBand = rSCell.bandNr;

                FnVCCB_McoFillBandwidth(rSCell, sCellCcInfo);

                calculatedTotalMaxBw += sCellCcInfo.mcoBwDl;

                VCCB_PRINT_LOG_CA_FUNC(ptCi, "[CA][%3u] %10u(+%7u(%3u/%5u/%6u))\n",
                    ++numAddScells, calculatedTotalMaxBw, sCellCcInfo.mcoBwDl, sCellIdx, rSCell.state, rSCell.bandNr);
            }
            // else bestScellsMap[sCellIdx] not marked
        }
    }

    // 4. set TotalBW to caInfo.totalMaxBw
    ptCi->caInfo.totalMaxBw = calculatedTotalMaxBw;
    VCCB_PRINT_LOG_CA_FUNC(ptCi, "[CA][Result] Top BC Total Max BandWidth = %u\n", calculatedTotalMaxBw);
    return;
}

/**
 * @brief Function to check whether to skip A4 MR setting for SCell Addition.
 * Compare total Max BandWidth and current total Max Bandwidth to decide whether to skip the setting
 *
 * @param ptCi
 * @return true    Skip, no need to set A4 MR for SCell Addition
 * @return false   A4 MR for SCell Addition needs to be set
 */
bool FnVCCB_CheckSkipCaA4MrWithMaxBw(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if ((UNKNOWN_BANDWIDTH == ptCi->caInfo.totalMaxBw) ||
        (0 == ptCi->caInfo.totalMaxBw))
    {
        VCCB_PRINT_LOG_CA_FUNC(ptCi, "[CA] Need to set A4 MR SCell Addition, totalMaxBw(%d)\n", ptCi->caInfo.totalMaxBw);
        return false;
    }

    caScellCcInfo_type sCellCcInfo;
    uint32_t currentTotalMaxBw = 0;

    for (uint16_t sCellIdx = 0; sCellIdx < MAX_SCELL_PER_CALL; sCellIdx++)
    {
        const scellInfo_type &rSCell = ptCi->sCell[sCellIdx];

        if (SCELL_STATE_ADDED == rSCell.state)
        {
            sCellCcInfo.frequencyBand = rSCell.bandNr;

            FnVCCB_McoFillBandwidth(rSCell, sCellCcInfo);

            VCCB_PRINT_LOG_CA_FUNC(ptCi, "[CA] sCellIdx[%2d]:mcoBwDl(%3d) totalMaxBw(%3d=%3d(+%3d))\n",
                sCellIdx, sCellCcInfo.mcoBwDl, currentTotalMaxBw + sCellCcInfo.mcoBwDl, currentTotalMaxBw, sCellCcInfo.mcoBwDl);
            currentTotalMaxBw += sCellCcInfo.mcoBwDl;
        }
    }

    if (currentTotalMaxBw >= ptCi->caInfo.totalMaxBw)
    {
        VCCB_PRINT_LOG_CA_FUNC(ptCi, "[CA] Skip A4 MR SCell Addition, currentMaxBw(%3d>=%3d)totalMaxBw\n",
            currentTotalMaxBw, ptCi->caInfo.totalMaxBw);
        return true;
    }

    VCCB_PRINT_LOG_CA_FUNC(ptCi, "[CA] Need to set A4 MR SCell Addition, currentMaxBw(%3d<%3d)totalMaxBw\n",
        currentTotalMaxBw, ptCi->caInfo.totalMaxBw);

    return false;
}

/**
 * @brief   MCO: Check if cell (ARFCN, PCI) has been included in measurement report.
 */
bool FnVCCB_McoIsCellMeasured(const callInfo_type &rCall, const Arfcn_type arfcn, const CellPci_type pci, uint8_t &rRsrpOut)
{
    AUTO_TRACE_FUNC;
    rRsrpOut = UNKNOWN_RSRP;

    for (const FmPccChosenCc_type &rChosenCC : rCall.pccData.fmPccChosenCcs)
    {
        if (UNKNOWN_ARFCN == rChosenCC.arfcn)
        {
            // no more valid entries
            break;
        }

        if (arfcn != rChosenCC.arfcn)
        {
            continue;
        }

        for (const CellPci_type &rMrPci: rChosenCC.measuredCellPcis)
        {
            if (UNKNOWN_PCI == rMrPci)
            {
                // no more measured PCIs
                break;
            }

            if (pci == rMrPci)
            {
                auto index = std::distance(rChosenCC.measuredCellPcis, &rMrPci);
                rRsrpOut = rChosenCC.measuredCellRsrps[index];
                return true;
            }
        }

        // arfcn entry has been found
        break;
    }

    return false;
}

/**
 * @brief   Check if cell (NR-CGI) is serving cell.
 */
bool FnVCCB_IsCgiServingCell(const callInfo_type &rCall, const cgi_type &rCgi, uint8_t &rRsrpOut)
{
    AUTO_TRACE_FUNC;

    if (MAX_CELL_NUM_VCCB > rCall.servCellNum)
    {
        const cgi_type cgi = FnVCCB_GetNrcgiFromCellNum(rCall.servCellNum);
        if (FnVCCB_CheckCgiIdentical(&cgi, &rCgi))
        {
            rRsrpOut = rCall.servCellSsbRsrp;
            return true;
        }
    }

    for (const scellInfo_type &rSCell : rCall.sCell)
    {
        if (SCELL_STATE_ADDED != rSCell.state)
        {
            continue;
        }

        if (FnVCCB_CheckCgiIdentical(&rSCell.cgi, &rCgi))
        {
            rRsrpOut = rSCell.servCellSsbRsrp;
            return true;
        }
    }

    return false;
}

/**
 * @brief   MCO: Add colocated SCells to cellInfoTabOut if serving or measured.
 */
void FnVCCB_McoAddSCellInfoColocatedIfServOrMr(callInfo_type *ptCi, const uint16_t spCellNum, const mcoBcSelCellInfo_s &pcell,
    McoAlgoFlags &algoFlags, const bcIdxArray_type &filteredBcIndexes,
    mcoBcSelCellInfo_s cellInfoTabOut[MAX_COLOCCELL + 1], std::size_t &rCellInfoCnt)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    VCCB_CHECK_VALID_CELLNUM_VOID(spCellNum);
    VccbCellInfo_type *const pSpCell = &CELLINFO[spCellNum];

    // iterate over cuColocCellInfo and fill SCell info
    for (colocCellEntries_type &rColocCell : pSpCell->cuColocCellInfo.colocCellEntries)
    {
        if (MAX_COLOCCELL < rCellInfoCnt)
        {
            return;
        }

        if ((CI_no_use == rColocCell.usage) || (TRUE != rColocCell.useforNrca))
        {
            continue;
        }

        cgi_type cgi;
        cgi.ci = VLIB_GnbIdCellId2NrCellId(&rColocCell.globalGnbId.gnbId, rColocCell.cellId);
        cgi.plmn = rColocCell.globalGnbId.plmn;
        const uint8_t gnbIdLength = rColocCell.globalGnbId.gnbId.idLength;
        uint8_t rsrp = UNKNOWN_RSRP;

        if (FnVCCB_IsCgiServingCell(*ptCi, cgi, rsrp))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[PCC][FM] Coloc SCell ci(%llu) of PCell num(%u): current serving cell RSRP(%u)\n",
                1ULL * cgi.ci, spCellNum, rsrp);
        }
        else
        {
            nbrGnbCellInfo_type * const ptNbrGnbCell = VLIB_GetNbrGnbCellInfoBasedOnCgi(ptCi, cgi, gnbIdLength);
            if (nullptr == ptNbrGnbCell)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "[PCC][FM] Coloc SCell ci(%llu) failed to get NbrGnbCellInfo of PCell num(%u)!\n",
                    1ULL * cgi.ci, spCellNum);
                continue;
            }

            if (false == FnVCCB_McoIsCellMeasured(*ptCi, ptNbrGnbCell->ssbArfcn, ptNbrGnbCell->nrPci, rsrp))
            {
                VCCB_PRINT_CALL_COMMENT(ptCi,
                    "[PCC][FM] Coloc SCell ci(%llu) ssbArfcn(%u) PCI(%u) of PCell num(%u): MR not received!\n",
                    1ULL * cgi.ci, ptNbrGnbCell->ssbArfcn, ptNbrGnbCell->nrPci, spCellNum);
                continue;
            }

            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[PCC][FM] Coloc SCell ci(%llu) ssbArfcn(%u) PCI(%u) of PCell num(%u): MR received RSRP(%u)\n",
                1ULL * cgi.ci, ptNbrGnbCell->ssbArfcn, ptNbrGnbCell->nrPci, spCellNum, rsrp);
        }

        if (false == FnVCCB_McoFillBcSelSCellInfoByCgi(ptCi, spCellNum, pcell, filteredBcIndexes, cgi, gnbIdLength,
                algoFlags, rsrp, cellInfoTabOut[rCellInfoCnt]))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[PCC][FM] Coloc SCell ci(%llu) failed to add as CA nbr of PCell num(%u)!\n",
                1ULL * cgi.ci, spCellNum);
            continue;
        }

        rCellInfoCnt++;
    }
}

/**
 * @brief   MCO: Add SCell to cellInfoTabOut if ARFCN, PCI pair is in NRT.
 */
bool FnVCCB_McoAddSCellInfoIfNbr(callInfo_type *ptCi, const uint16_t spCellNum, const mcoBcSelCellInfo_s &pcell,
    McoAlgoFlags &algoFlags, const bcIdxArray_type &filteredBcIndexes, const Arfcn_type arfcn, const CellPci_type pci,
    const uint8_t rsrp, mcoBcSelCellInfo_s cellInfoTabOut[MAX_COLOCCELL + 1], std::size_t &rCellInfoCnt)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(spCellNum, false);
    VccbCellInfo_type *const pSpCell = &CELLINFO[spCellNum];
    VCCB_CHECK_E_RANGE_AND_VAL(rCellInfoCnt, MAX_COLOCCELL + 1, false);

    for (uint16_t nbrIdx = 0; MAX_NBR_PER_CELL > nbrIdx; ++nbrIdx)
    {
        const nbrCellInfo_type &rCellNbr = pSpCell->Nbr[nbrIdx];
        if (N_EQUIP == rCellNbr.status)
        {
            continue;
        }

        nbrGnbCellInfo_type *ptNbrGnbCell = nullptr;
        if ((ERROR == getNbrGnbCellByCellNbrIdx(spCellNum, nbrIdx, &ptNbrGnbCell)) ||
            // pointer and status already checked by getNbrGnbCellByCellNbrIdx.
            (pci != ptNbrGnbCell->nrPci) || (arfcn != ptNbrGnbCell->ssbArfcn))
        {
            continue;
        }

        if (FnVCCB_McoFillBcSelSCellInfoByNbr(ptCi, spCellNum, pcell, filteredBcIndexes, &rCellNbr,
            ptNbrGnbCell, algoFlags, rsrp, cellInfoTabOut[rCellInfoCnt]))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[PCC][FM] Measured SCell ci(%llu) ssbArfcn(%u) PCI(%u) RSRP(%u) found as nbr of PCell num(%u)\n",
                1ULL * cellInfoTabOut[rCellInfoCnt].cgi.ci, arfcn, pci, rsrp, spCellNum);
            rCellInfoCnt++;
            return true;
        }
    }

    return false;
}

/**
 * @brief   MCO: Add current serving CCs and measured CCs as SCells to cellInfoTabOut.
 */
void FnVCCB_McoAddSCellInfoServingAndMeasuredCc(callInfo_type *ptCi, const uint16_t spCellNum, const mcoBcSelCellInfo_s &pcell,
    McoAlgoFlags &algoFlags, const bcIdxArray_type &filteredBcIndexes,
    mcoBcSelCellInfo_s cellInfoTabOut[MAX_COLOCCELL + 1], std::size_t &rCellInfoCnt)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_VALID_CELLNUM_VOID(spCellNum);
    VccbCellInfo_type *const pCells = CELLINFO;
    VccbCellInfo_type *const pSpCell = &pCells[spCellNum];
    const uint16_t maxCellNum = MAX_CELL_NUM_VCCB;

    staticUnorderedSet<uint32_t, MAX_SCELL_PER_CALL + 2> checkedSsbArfcns;
    checkedSsbArfcns.insert(pcell.ssbArfcn);

    mcoColocCellsSsbArfcns_type colocCellFreqs {};
    FnVCCB_buildColocCellsFreqs(ptCi, pSpCell->cuColocCellInfo, colocCellFreqs);

    // 1. Go through current serving cells
    // 1.1 Check PCell
    if (maxCellNum > ptCi->servCellNum)
    {
        const nbrGnbCellInfo_type &rNbrGnbCell = pCells[ptCi->servCellNum].intraGnbNbrInfo;
        const cgi_type cgi = FnVCCB_GetNrcgiFromCellNum(ptCi->servCellNum);

        if (MAX_COLOCCELL < rCellInfoCnt)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[PCC][FM] Current PCell ci(%llu) ssbArfcn(%u) failed to add: not enough space!\n",
                1ULL * cgi.ci, rNbrGnbCell.ssbArfcn);
            return;
        }

        if (colocCellFreqs.contains(rNbrGnbCell.ssbArfcn) &&
                FnVCCB_McoFillBcSelSCellInfoByCgi(ptCi, spCellNum, pcell, filteredBcIndexes, cgi,
                    rNbrGnbCell.globalGnbId.gnbId.idLength, algoFlags, ptCi->servCellSsbRsrp, cellInfoTabOut[rCellInfoCnt]))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[PCC][FM] Current PCell ci(%llu) ssbArfcn(%u) RSRP(%u) found as CA nbr of PCell num(%u)\n",
                1ULL * cgi.ci, rNbrGnbCell.ssbArfcn, ptCi->servCellSsbRsrp, spCellNum);
            rCellInfoCnt++;
            checkedSsbArfcns.insert(rNbrGnbCell.ssbArfcn);
        }
        else
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[PCC][FM] Current PCell ci(%llu) ssbArfcn(%u) failed to add as CA nbr of PCell num(%u)\n",
                1ULL * cgi.ci, rNbrGnbCell.ssbArfcn, spCellNum);
        }
    }

    // 1.2 Check SCells
    for (const scellInfo_type &rSCell : ptCi->sCell)
    {
        if (SCELL_STATE_ADDED != rSCell.state)
        {
            continue;
        }

        if (!colocCellFreqs.contains(rSCell.ssbArfcn))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[PCC][FM] Frequency of serving SCell(%u) is not present in PCell num(%u) coloc cells - SKIP!\n",
                rSCell.ssbArfcn, spCellNum);
            continue;
        }

        nbrGnbCellInfo_type *const ptNbrGnbCell = VLIB_GetNbrGnbCellInfoBasedOnCgi(ptCi, rSCell.cgi, rSCell.gnbIdLength);
        if (nullptr != ptNbrGnbCell)
        {
            if (MAX_COLOCCELL < rCellInfoCnt)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "[PCC][FM] Current SCell ci(%llu) ssbArfcn(%u) failed to add: not enough space!\n",
                    1ULL * rSCell.cgi.ci, rSCell.ssbArfcn);
                return;
            }

            if (FnVCCB_McoFillBcSelSCellInfoByCgi(ptCi, spCellNum, pcell, filteredBcIndexes, rSCell.cgi,
                    ptNbrGnbCell->globalGnbId.gnbId.idLength, algoFlags, rSCell.servCellSsbRsrp, cellInfoTabOut[rCellInfoCnt]))
            {
                VCCB_PRINT_CALL_COMMENT(ptCi,
                    "[PCC][FM] Current SCell ci(%llu) ssbArfcn(%u) RSRP(%u) found as CA nbr of PCell num(%u)\n",
                    1ULL * rSCell.cgi.ci, rSCell.ssbArfcn, rSCell.servCellSsbRsrp, spCellNum);
                rCellInfoCnt++;
                checkedSsbArfcns.insert(rSCell.ssbArfcn);
            }
            else
            {
                VCCB_PRINT_CALL_COMMENT(ptCi,
                    "[PCC][FM] Current SCell ci(%llu) ssbArfcn(%u) failed to add as CA nbr of PCell num(%u)\n",
                    1ULL * rSCell.cgi.ci, rSCell.ssbArfcn, spCellNum);
            }
        }
        else
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[PCC][FM] Current SCell ci(%llu) ssbArfcn(%u) failed to get NbrGnbCellInfo of PCell num(%u)\n",
                1ULL * rSCell.cgi.ci, rSCell.ssbArfcn, spCellNum);
        }
    }

    // 2. Go through measured cells
    for (const FmPccChosenCc_type &rChosenCC : ptCi->pccData.fmPccChosenCcs)
    {
        if (UNKNOWN_ARFCN == rChosenCC.arfcn)
        {
            // no more valid entries
            break;
        }

        if (checkedSsbArfcns.contains(rChosenCC.arfcn))
        {
            // serving cell is already added
            continue;
        }

        if (!colocCellFreqs.contains(rChosenCC.arfcn))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[PCC][FM] Frequency of measured CC(%u) is not present in PCell num(%u) coloc cells - SKIP!\n",
                rChosenCC.arfcn, spCellNum);
            continue;
        }

        for (const CellPci_type &rMrPci: rChosenCC.measuredCellPcis)
        {
            if (MAX_COLOCCELL < rCellInfoCnt)
            {
                return;
            }

            if (UNKNOWN_PCI == rMrPci)
            {
                // no more measured PCIs
                break;
            }

            const uint8_t rsrp = rChosenCC.measuredCellRsrps[std::distance(rChosenCC.measuredCellPcis, &rMrPci)];

            if (FnVCCB_McoAddSCellInfoIfNbr(ptCi, spCellNum, pcell, algoFlags, filteredBcIndexes, rChosenCC.arfcn, rMrPci,
                    rsrp, cellInfoTabOut, rCellInfoCnt))
            {
                // cell found in NRT - check another arfcn
                break;
            }

            // go through all intra gNB cells if no scell candidate found in NRT
            uint16_t cellNum = 0;
            for (; cellNum < maxCellNum; ++cellNum)
            {
                VccbCellInfo_type &rIntraCell = pCells[cellNum];
                if ((EQUIP != rIntraCell.status) ||
                    (rMrPci != rIntraCell.phyCellId) ||
                    (rChosenCC.arfcn != rIntraCell.ssbArfcn) ||
                    (pSpCell->gnbNum != rIntraCell.gnbNum)) // exclude inter gNB cells
                {
                    continue;
                }

                const cgi_type cgi = FnVCCB_GetNrcgiFromCellNum(cellNum);
                if (FnVCCB_McoFillBcSelSCellInfoByCgi(ptCi, spCellNum, pcell, filteredBcIndexes, cgi,
                        rIntraCell.intraGnbNbrInfo.globalGnbId.gnbId.idLength, algoFlags, rsrp,
                        cellInfoTabOut[rCellInfoCnt]))
                {
                    VCCB_PRINT_CALL_COMMENT(ptCi,
                        "[PCC][FM] Measured SCell ci(%llu) ssbArfcn(%u) PCI(%u) RSRP(%u) found as intra-gNB of PCell num(%u)\n",
                        1ULL * cellInfoTabOut[rCellInfoCnt].cgi.ci, rChosenCC.arfcn, rMrPci,
                        rsrp, spCellNum);
                    rCellInfoCnt++;
                    break;
                }
            }
            if (maxCellNum > cellNum)
            {
                // cell found - check another arfcn
                break;
            }
        }
    }
}

/**
 * @brief   MCO: Add measured SCells to cellInfoTabOut for final target selection in FM-PCC Change based on
 *          1) current serving cells and 2) received measurement reports.
 *          for CA mode=Off: no action
 *          for CA mode=1,2: colocated cell(s) of the target PCell.
 *          for CA mode=3,4,5: measured cell(s) which has strongest value for the trigger quantity of target PCell.
 */
void FnVCCB_FmPccAddBcSelCellInfoMrBased(callInfo_type *ptCi, const uint16_t spCellNum, const mcoBcSelCellInfo_s &pcell,
    McoAlgoFlags &algoFlags, const bcIdxArray_type &filteredBcIndexes,
    mcoBcSelCellInfo_s cellInfoTabOut[MAX_COLOCCELL + 1], std::size_t &rCellInfoCnt)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);

    VCCB_CHECK_VALID_CELLNUM_VOID(spCellNum);
    VccbCellInfo_type *const pSpCell = &CELLINFO[spCellNum];

    uint8_t caMode = VLIB_DecideAboutCaOperatingMode(ptCi, pSpCell, pcell.frequencyBand);
    if (BAND_NOT_FOUND != pcell.altBand)
    {
        uint8_t altBandCaMode = VLIB_DecideAboutCaOperatingMode(ptCi, pSpCell, pcell.altBand);
        caMode = MAX(caMode, altBandCaMode);
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC][FM] PCell num(%u) band(%u) alt band(%u) caMode(%u)\n", spCellNum,
        pcell.frequencyBand, pcell.altBand, caMode);

    if ((CaOperation_Mode1 == caMode) || (CaOperation_Mode2 == caMode))
    {
        FnVCCB_McoAddSCellInfoColocatedIfServOrMr(ptCi, spCellNum, pcell, algoFlags, filteredBcIndexes, cellInfoTabOut,
            rCellInfoCnt);
    }
    else if (CaOperation_Off != caMode)
    {
        FnVCCB_McoAddSCellInfoServingAndMeasuredCc(ptCi, spCellNum, pcell, algoFlags, filteredBcIndexes, cellInfoTabOut,
            rCellInfoCnt);
    }

    // In cases when useSe was already set to false by invalid SE value, skip this check
    algoFlags.useSe = algoFlags.useSe && std::all_of(cellInfoTabOut, &cellInfoTabOut[rCellInfoCnt],
            [&ptCi] (const caCellInfo_type &cell)
            {
                auto cellGnbId = VLIB_NrCellId2GnbId(cell.gnbIdLength, cell.cgi.ci);
                return (VCCB_IS_SAME_GNB(cellGnbId, cell.cgi.plmn.longId, ptCi->gnbNum));
            });

}

/**
 * @brief   MCO: Prepares contiguous NR cell groups for final target selection in FM-PCC Change based on received measurement
 *          reports.
 */
void FnVCCB_McoPrepareNrCellGroupsForFinalFmPcc(
    callInfo_type *ptCi, uint16_t spCellNum, McoAlgoFlags &algoFlags,
    mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBandOut, uint16_t &rPCellBandOut)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);
    VCCB_CHECK_VALID_CELLNUM_VOID(spCellNum);
    VccbCellInfo_type *const pSpCell = &CELLINFO[spCellNum];
    uint8_t spCellRsrp = UNKNOWN_RSRP;

    if (spCellNum == ptCi->servCellNum)
    {
        spCellRsrp = ptCi->servCellSsbRsrp;
    }
    else if (false == FnVCCB_McoIsCellMeasured(*ptCi, pSpCell->ssbArfcn, pSpCell->phyCellId, spCellRsrp))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "[PCC][FM] pcell cellNum(%u) ssbArfcn(%u) PCI(%u) A5 measurement not available!\n",
            spCellNum, pSpCell->ssbArfcn, pSpCell->phyCellId);
    }

    FnVCCB_McoPrepareContiguousNrCellGroups(ptCi, spCellNum, spCellRsrp, algoFlags, FnVCCB_FmPccAddBcSelCellInfoMrBased,
        ccInfoVecPerBandOut, rPCellBandOut);
}

/**
 * @brief   Check if there are any matching slices between the UE and the Slice Id entries list in NR CA Control Entries
 * @param   rCall : callInfo
 *          rCondition : nrCaControlEntries.condition
 * @return  true or false // BOOL
 */
bool FnVCCB_CaControlCheckIfUeAndGnbShareAnySlice(const callInfo_type &rCall, const nrCaControlCondition_type &rCondition)
{
    AUTO_TRACE_FUNC;

    size_t const maxPduSessions = VCCB_ARRAY_COUNT(rCall.pduSess);
    staticUnorderedSet<uint32_t, maxPduSessions> pduSessionSstSds;

    for (auto const &pduSess: rCall.pduSess)
    {
        if ((!pduSess.usage) || (0 >= pduSess.numDRBPerPDUSess))
        {
            continue;
        }
        pduSessionSstSds.insert(pduSess.sNssai.sstSd);
    }

    auto areSlicesMatching = [&pduSessionSstSds](SliceSupportedInfo_type const &slice)
    {
        if (CI_no_use == slice.status)
        {
            return false;
        }

        return pduSessionSstSds.contains(GET_SNSSAI_FROM_SST_AND_SD(slice.sst, slice.sd));
    };

    return std::any_of(std::begin(rCondition.sliceIdEntries), std::end(rCondition.sliceIdEntries), areSlicesMatching);
}

/**
 * @brief   Check if there are any matching plmn between the UE and the Plmn Indicator list in NR CA Control Entries
 * @param   rCall : callInfo
 *          rCondition : nrCaControlEntries.condition
 * @return  true or false // BOOL
 */
bool FnVCCB_CaControlCheckIfUeSupportPlmnOfGnb(const callInfo_type &rCall, const nrCaControlCondition_type &rCondition)
{
    AUTO_TRACE_FUNC;

    uint8_t plmnIdx = MAX_PLMN_INDEX;

    if (GOOD != VLIB_getMultipleGnbPlmnIndexInfo(&rCall, &plmnIdx, rCall.ueInfo.servedPlmn.longId))
    {
        return false;
    }

    VCCB_CHECK_E_RANGE_AND_VAL(plmnIdx, MAX_PLMN_INDEX, false);

    if (GETBIT_U8(rCondition.plmnIndicatorList, plmnIdx))
    {
        return true;
    }

    return false;
}

/**
 * @brief   Check if current NR CA Control Entry has to be checked
 * @param   rCall : callInfo
 * @return  true or false // BOOL
 */
bool FnVCCB_IsNeedToCheckAllowedBand(const callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_VALID_GNBNUM_RET_VAL(rCall.gnbNum, false);

    if (IS_NRDC_SN(&rCall))
    {
        return false;
    }

    if (rCall.caInfo.caControlIdx >= MAX_NR_CA_CONTROL_ENTRIES)
    {
        return false;
    }

    const nrCaControl_type &rNrCaControl = GNBINFO[rCall.gnbNum].carrierAggregationInfo.nrCaControlEntries[rCall.caInfo.caControlIdx];

    if (TRUE != rNrCaControl.caIndexUsage)
    {
        return false;
    }

    return ((rNrCaControl.operation.allowedScellBandListUsage) && (rNrCaControl.operation.noOfAllowedBandList));
}

/**
 * @brief   Check if scellBandNR is in allowedScellBandList
 * @param   rCall : callInfo
 *          scellBandNR : band indicator of current scell
 * @return  GOOD or ERROR
 */
int16_t FnVCCB_CheckIfBandInAllowedBandList(const callInfo_type &rCall, const uint16_t scellBandNR)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_VALID_GNBNUM_RET_VAL(rCall.gnbNum, GOOD);

    if (rCall.caInfo.caControlIdx >= MAX_NR_CA_CONTROL_ENTRIES)
    {
        // ca control group not selected - skip
        return GOOD;
    }

    if (!FnVCCB_IsNeedToCheckAllowedBand(rCall))
    {
        return GOOD; // Don't need to check allowed-band-list
    }

    const nrCaControl_type &rNrCaControl = GNBINFO[rCall.gnbNum].carrierAggregationInfo.nrCaControlEntries[rCall.caInfo.caControlIdx];
    const uint8_t noOfAllowedBands = MIN(rNrCaControl.operation.noOfAllowedBandList, MAX_CA_NUM_ALLOWED_BANDS);

    for (uint8_t allowedBandIdx = 0; allowedBandIdx < noOfAllowedBands; ++allowedBandIdx)
    {
        if (rNrCaControl.operation.allowedScellBandList[allowedBandIdx] == scellBandNR)
        {
            return GOOD;
        }
    }

    return ERROR; // Not Allowed Band
}

/**
 * @brief   Check whether allowedBandLists of oldCaControlEntry and newCaControlEntry are different
 * @param   rCall : callInfo
 *          rGnb : GNBINFO
 *          oldCaControlIdx : previous caControlIdx
 *          newCaControlIdx : new caControlIdx
 * @return  true : Changed Allowed Band
 *          false : Don't check to need Allowed Band or Not changed Allowed Band
 */
bool FnVCCB_IsChangedAllowedBand(const callInfo_type &rCall, const VccbGnbInfo_type &rGnb, const uint8_t oldCaControlIdx, const uint8_t newCaControlIdx)
{
    AUTO_TRACE_FUNC;

    int8_t newCaUsage = caUsage_NoControl;
    int8_t oldCaUsage = caUsage_NoControl;
    uint8_t newNoOfAllowedBandList = 0;
    uint8_t oldNoOfAllowedBandList = 0;
    bool newAllowedBandUsage = false;
    bool oldAllowedBandUsage = false;

    if (oldCaControlIdx == newCaControlIdx)
    {
        return false; // Don't change caControlIdx
    }

    if (IS_NRDC_SN(&rCall))
    {
        return false; // SN, Don't need to check Allowed Band List
    }

    if (MAX_NR_CA_CONTROL_ENTRIES > newCaControlIdx)
    {
        newCaUsage = rGnb.carrierAggregationInfo.nrCaControlEntries[newCaControlIdx].operation.caUsage;
        newNoOfAllowedBandList = MIN(rGnb.carrierAggregationInfo.nrCaControlEntries[newCaControlIdx].operation.noOfAllowedBandList, MAX_CA_NUM_ALLOWED_BANDS);
        newAllowedBandUsage = (rGnb.carrierAggregationInfo.nrCaControlEntries[newCaControlIdx].operation.allowedScellBandListUsage && newNoOfAllowedBandList);
    }

    if (newCaUsage == caUsage_Off)
    {
        return false; // Don't need to check Allowd Band List because of CA Off
    }

    if (MAX_NR_CA_CONTROL_ENTRIES > oldCaControlIdx)
    {
        oldCaUsage = rGnb.carrierAggregationInfo.nrCaControlEntries[oldCaControlIdx].operation.caUsage;
        oldNoOfAllowedBandList = MIN(rGnb.carrierAggregationInfo.nrCaControlEntries[oldCaControlIdx].operation.noOfAllowedBandList, MAX_CA_NUM_ALLOWED_BANDS);
        oldAllowedBandUsage = (rGnb.carrierAggregationInfo.nrCaControlEntries[oldCaControlIdx].operation.allowedScellBandListUsage && oldNoOfAllowedBandList);
    }

    if (newCaUsage != oldCaUsage)
    {
        return false;  // Don't need to check Allowd Band List because CA Usage is changed
    }

    if (!newAllowedBandUsage && !oldAllowedBandUsage)
    {
        return false; // Allowed Band Usage is off for both new and old
    }

    if (newAllowedBandUsage != oldAllowedBandUsage)
    {
        return true; // Different Allowed Band List Usage
    }

    if (newNoOfAllowedBandList != oldNoOfAllowedBandList)
    {
        return true; // Different Allowed Band List Count
    }

    if ((MAX_NR_CA_CONTROL_ENTRIES > newCaControlIdx) && (MAX_NR_CA_CONTROL_ENTRIES > oldCaControlIdx))
    {
        const nrCaControl_type &rNewNrCaControl = rGnb.carrierAggregationInfo.nrCaControlEntries[newCaControlIdx];
        const nrCaControl_type &rOldNrCaControl = rGnb.carrierAggregationInfo.nrCaControlEntries[oldCaControlIdx];

        for (uint16_t newBandIdx = 0; newBandIdx < MAX_NR_CA_CONTROL_ENTRIES; ++newBandIdx)
        {
            if (rNewNrCaControl.operation.allowedScellBandList[newBandIdx] != rOldNrCaControl.operation.allowedScellBandList[newBandIdx])
            {
                return true; // Find Unmatched Allow Band
            }
        }
    }

    return false;
}

/**
 * @brief   If available returns best band level supported power class.
 *          Otherwise returns PowerClass_Pc3.
 *
 * @param   rCall : callInfo
 * @param   nrBand : spCell band
 * @return  enumUeAllPowerClass_type
 */
enumUeAllPowerClass_type FnVCCB_GetBandLevelPcCapa(const callInfo_type &rCi, uint16_t nrBand)
{
    AUTO_TRACE_FUNC;

    uint16_t bandIdx = VLIB_GetNrBandIndex(rCi, nrBand);
    VCCB_CHECK_E_RANGE_AND_VAL(bandIdx, MAX_NUM_UECAPA_NR_BANDS, PowerClass_Pc3);
    const bandNrUeCapa_type &rBandNrUeCapa = rCi.ueInfo.ueCapa.nr.rf.supportedBandListNR[bandIdx];

    if (UePowerClass_Pc1 == rBandNrUeCapa.ue_PowerClass)
    {
        return PowerClass_Pc1;
    }
    else if (UePowerClass_Pc1dot5 == rBandNrUeCapa.ue_PowerClass_v1610)
    {
        return PowerClass_Pc1dot5;
    }
    else if (UePowerClass_Pc2 == rBandNrUeCapa.ue_PowerClass)
    {
        return PowerClass_Pc2;
    }

    return PowerClass_Pc3;
}

/**
 * @brief   Checks if band combination contains single NR band (NR intra-band CA or no NR CA).
 *
 * @param   rBandCombination : reference to band combination to be checked
 * @param   nrBand : band to be checked
 * @return  true/false
 */
bool FnVCCB_IsSingleNrBandBc(const BandCombination_type &rBandCombination, uint16_t nrBand)
{
    AUTO_TRACE_FUNC;

    const uint8_t numOfBandsInBc = MIN(rBandCombination.num, MAX_BANDS_PER_COMB);

    return std::none_of(rBandCombination.band,
        rBandCombination.band + numOfBandsInBc,
        [&nrBand] (const BandParameters_type &bandParameters)
        { return (ci_nr == bandParameters.ratType) && (bandParameters.freqBandIndicator != nrBand);});
}

/**
 * @brief   If available returns best band combination NRPart level supported power class.
 *          Otherwise returns PowerClass_None.
 *
 * @param   rCi : callInfo
 * @param   rBandCombination : reference to selected band combination
 * @param   nrBand : spCell band
 * @return  enumUeAllPowerClass_type
 */
enumUeAllPowerClass_type FnVCCB_GetBcLevelNRPartPcCapa(
        const callInfo_type &rCi, const BandCombination_type &rBandCombination, uint16_t nrBand)
{
    AUTO_TRACE_FUNC;

    if ((E_CALLTYPE_NSA == rCi.callType) &&
        (OPT_PRESENT == rBandCombination.powerClassNRPart_present) &&
        (FnVCCB_IsSingleNrBandBc(rBandCombination, nrBand)))
    {
        // 3GPP TS 38.306 V17 powerClassNRPart-r16 applies only for MR-DC BCs containing only single CC or intra-band CA in NR side
        if (NRRRC_powerClassNRPart_r16_pc1 == rBandCombination.powerClassNRPart)
        {
            return PowerClass_Pc1;
        }
        else if (NRRRC_powerClassNRPart_r16_pc2 == rBandCombination.powerClassNRPart)
        {
            return PowerClass_Pc2;
        } // else the worst PC3

        return PowerClass_Pc3;
    }

    return PowerClass_None;
}

/**
 * @brief   If available returns best band combination level supported power class.
 *          Otherwise returns PowerClass_Pc3.
 *
 * @param   rBandCombination : reference to selected band combination
 * @return  enumUeAllPowerClass_type
 */
enumUeAllPowerClass_type FnVCCB_GetBcLevelPcCapa(const BandCombination_type &rBandCombination)
{
    AUTO_TRACE_FUNC;

    if (OPT_PRESENT == rBandCombination.powerClassv1610)
    {
        return PowerClass_Pc1dot5;
    }
    else if (OPT_PRESENT == rBandCombination.powerClass_present)
    {
        return PowerClass_Pc2;
    }

    return PowerClass_Pc3;
}

/**
 * @brief   If available returns best feature set level supported power class.
 *          Otherwise returns PowerClass_None.
 *
 * @param   rCi : callInfo
 * @param   rBandCombination : reference to selected band combination
 * @param   featureSetsId : selected feature sets id (1 based)
 * @param   nrBand : spCell band
 * @return  enumUeAllPowerClass_type
 */
enumUeAllPowerClass_type FnVCCB_GetFsLevelPcCapa(callInfo_type &rCi,
    BandCombination_type &rBandCombination, uint16_t featureSetsId, uint16_t nrBand)
{
    AUTO_TRACE_FUNC;

    MrdcFeatureSetCombinationList_type *pFsCombinations = VRIL_GetFeatureSetCombinationList(&rCi);
    VALID_E_POINT_CHECK_RET_VAL(pFsCombinations, PowerClass_None);
    uint16_t noOfFsCombinations =
        MIN(pFsCombinations->num, VCCB_ARRAY_COUNT(pFsCombinations->mrdcFeatureSetCombination));
    VCCB_CHECK_E_RANGE_AND_VAL(rBandCombination.featureSetCombination, noOfFsCombinations, PowerClass_None);
    MrdcFeatureSetCombination_type &rFsCombination =
            pFsCombinations->mrdcFeatureSetCombination[rBandCombination.featureSetCombination];

    FeatureSets_type *pFeatureSets = VRIL_GetFeatureSetList(&rCi);
    VALID_E_POINT_CHECK_RET_VAL(pFeatureSets, PowerClass_None);
    const size_t noOfUlFeatureSets =
        MIN(pFeatureSets->nrOfFeatureSetsUplink, VCCB_ARRAY_COUNT(pFeatureSets->featureSetsUplink));

    --featureSetsId; // featureSets is 1 based, when MrdcFeatureSetPerBand_type::featureSet[] is 0 based

    const size_t numOfBandsInBc = MIN(rBandCombination.num, VCCB_ARRAY_COUNT(rBandCombination.band));
    const size_t numOfFsPerBand = MIN(rFsCombination.num, VCCB_ARRAY_COUNT(rFsCombination.featureSetPerBand));
    const size_t maxLoop = MIN(numOfBandsInBc, numOfFsPerBand);

    enumUeAllPowerClass_type bestPowerClass = PowerClass_None;

    // select best power class for spCell band in band combination
    for (uint16_t bandIdx = 0; bandIdx < maxLoop; ++bandIdx)
    {
        BandParameters_type &rBandParameters = rBandCombination.band[bandIdx];
        MrdcFeatureSetPerBand_type &rFsPerBand = rFsCombination.featureSetPerBand[bandIdx];
        if ((ci_nr != rFsPerBand.ratType) ||
            (ci_nr != rBandParameters.ratType) ||
            (nrBand != rBandParameters.freqBandIndicator) ||
            (CA_BandwidthClassNR_NOT_SET == rBandParameters.nrCaBandwidthClassDL) ||
            (CA_BandwidthClassNR_NOT_SET == rBandParameters.nrCaBandwidthClassUL))
        {
            // band cannot be selected for spCell
            continue;
        }

        const size_t noOfFeatureSets = MIN(rFsPerBand.num, VCCB_ARRAY_COUNT(rFsPerBand.featureSet));
        VCCB_CHECK_E_RANGE_AND_CONTINUE(featureSetsId, noOfFeatureSets);
        uint16_t ulSetId = rFsPerBand.featureSet[featureSetsId].ulSetId;
        if (0 == ulSetId)
        {
            continue;
        }

        --ulSetId; // ulSetId is 1 based, when featureSetsUplink[] is 0 based
        VCCB_CHECK_E_RANGE_AND_CONTINUE(ulSetId, noOfUlFeatureSets);
        featureSetUplink_type &rFeatureSetUplink = pFeatureSets->featureSetsUplink[ulSetId];

        if (OPT_PRESENT != rFeatureSetUplink.uePowerClassPerBandPerBCr17_present)
        {
            continue;
        }

        if (NRRRC_ue_PowerClassPerBandPerBC_r17_pc1dot5 == rFeatureSetUplink.uePowerClassPerBandPerBCr17)
        {
            return PowerClass_Pc1dot5; // the best
        }
        else if (NRRRC_pc2 == rFeatureSetUplink.uePowerClassPerBandPerBCr17)
        {
            bestPowerClass = PowerClass_Pc2;
            continue;
        } // else the worst PC3

        if (PowerClass_None == bestPowerClass)
        {
            bestPowerClass = PowerClass_Pc3;
        }
    }

    return bestPowerClass;
}

/**
 * @brief   Checks if band combination supports FR1 UL CA.
 *
 * @param   rBandCombination : reference to band combination to be checked
 * @return  true/false
 */
bool VLIB_IsFR1UlCaSupportedByBC(const BandCombination_type &rBandCombination)
{
    AUTO_TRACE_FUNC;

    int numCcUL = 0;
    for (uint8_t bandIdx = 0; bandIdx < MIN(rBandCombination.num, MAX_BANDS_PER_COMB); bandIdx++)
    {
        const BandParameters_type &rBandParameters = rBandCombination.band[bandIdx];
        if ((ci_nr != rBandParameters.ratType) ||
            (MAX_FR1_NR_BAND < rBandParameters.freqBandIndicator)) // ignore FR2 bands
        {
            continue;
        }
        numCcUL += rBandParameters.numContiguousCcUL;

        if (1 < numCcUL)
        {
            return true;
        }
    }

    return false;
}

/**
 * @brief   Checks if non-standard PC1 is supported
 *
 * @param   rCi : callInfo
 * @param   rBandCombination : reference to band combination to be checked
 * @return  true/false
 */
bool VLIB_IsNonStandardPC1Supported(const callInfo_type &rCi, const BandCombination_type &rBandCombination)
{
    AUTO_TRACE_FUNC;

    if ((E_CALLTYPE_SA != rCi.callType) ||
        (OPT_PRESENT != rBandCombination.higherPowerLimit_r17_present))
    {
        return false;
    }

    if (VLIB_IsFR1UlCaSupportedByBC(rBandCombination))
    {
        return false;
    }

    return true;
}

/**
 * @brief   Sets rDuSelectionRelatedData.selectedPowerClass equal to highest priority power class level:
 *          1. featureSetsUplink-v1710 > ue-PowerClassPerBandPerBC-r17
 *          2. supportedBandCombinationList > powerClassNRPart-r16 (only single carrier or intra-band NR CA in BC)
 *          3. non-standard PC1 (if Band PC is PC1, higherPowerLimit_r17 present, call is SA, no FR1 UL CA in BC)
 *          4. Worse from (supportedBandCombinationList > powerClass-v1530, powerClass-v1610) and
 *             (supportedBandListNR > ue-PowerClass, ue-PowerClass-v1610)
 *
 * @param   rCi : callInfo
 * @param   rDuSelectionRelatedData : reference to duSelectionRelatedData_type
 */
void VLIB_SetSelectedPowerClass(callInfo_type &rCi, duSelectionRelatedData_type &rDuSelectionRelatedData)
{
    AUTO_TRACE_FUNC;

    const uint16_t spCellBand = FnVCCB_GetCellSelectionForConfig(&rCi).bandNr;
    uint32_t bandCombIdx = rDuSelectionRelatedData.selectedBC - 1; // selectedBC is 1 based, when bandCombination[] is 0 based

    rDuSelectionRelatedData.selectedPowerClass = PowerClass_Pc3 & e_BitMask_3bit; // set in case of getting BC ERROR
    enumUeAllPowerClass_type bcLevelPcCapa = PowerClass_None;

    // band level
    const enumUeAllPowerClass_type bandLevelPcCapa = FnVCCB_GetBandLevelPcCapa(rCi, spCellBand);
    VCCB_PRINT_LOG_CA_FUNC(&rCi, "CA: Selected band level %s\n",
        VLIB_UeAllPowerClassToStr(bandLevelPcCapa));

    if (MAX_FR1_NR_BAND >= spCellBand) // FS and BC levels only for FR1
    {
        bandCombinationList_type *pBandCombinationList = VRIL_GetBandCombinationList(&rCi);
        VALID_E_POINT_CHECK_VOID(pBandCombinationList);
        const size_t noOfBandCombinations = MIN(pBandCombinationList->num, VCCB_ARRAY_COUNT(pBandCombinationList->bandCombination));
        VCCB_CHECK_E_RANGE_AND_VOID(bandCombIdx, noOfBandCombinations);
        BandCombination_type &rBandCombination = pBandCombinationList->bandCombination[bandCombIdx];

        // feature set level
        const enumUeAllPowerClass_type fsPowerClass =
            FnVCCB_GetFsLevelPcCapa(rCi, rBandCombination, rDuSelectionRelatedData.selectedFS, spCellBand);
        VCCB_PRINT_LOG_CA_FUNC(&rCi, "CA: Selected feature set level %s\n",
            VLIB_UeAllPowerClassToStr(fsPowerClass));
        if (PowerClass_None != fsPowerClass)
        {
            // Feature set level Power class field available, set it as selected PC
            rDuSelectionRelatedData.selectedPowerClass = static_cast<uint16_t>(fsPowerClass) & e_BitMask_3bit;
            return;
        }

        // band combination level
        const enumUeAllPowerClass_type bcNRPartLevelPcCapa = FnVCCB_GetBcLevelNRPartPcCapa(rCi, rBandCombination, spCellBand);
        VCCB_PRINT_LOG_CA_FUNC(&rCi, "CA: Selected band combination NR Part level %s\n",
            VLIB_UeAllPowerClassToStr(bcNRPartLevelPcCapa));
        if (PowerClass_None != bcNRPartLevelPcCapa)
        {
            // Band Combination NR Part level Power class field available, set it as selected PC
            rDuSelectionRelatedData.selectedPowerClass = static_cast<uint16_t>(bcNRPartLevelPcCapa) & e_BitMask_3bit;
            return;
        }

        if ((PowerClass_Pc1 == bandLevelPcCapa) &&
            VLIB_IsNonStandardPC1Supported(rCi, rBandCombination))
        {
            rDuSelectionRelatedData.selectedPowerClass = PowerClass_Pc1;
            return;
        }

        bcLevelPcCapa = FnVCCB_GetBcLevelPcCapa(rBandCombination);
        VCCB_PRINT_LOG_CA_FUNC(&rCi, "CA: Selected band combination level %s\n",
            VLIB_UeAllPowerClassToStr(bcLevelPcCapa));
    }

    rDuSelectionRelatedData.selectedPowerClass =
            static_cast<uint16_t>(MAX(bandLevelPcCapa, bcLevelPcCapa)) & e_BitMask_3bit;
}

/**
 * @brief   Get reference to proper duSelectionRelatedData_type (current call or LTM candidate)
 *
 * @param   rCi : callInfo
 */
duSelectionRelatedData_type &VLIB_GetDuSelectionRelatedData(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    if (FnVCCB_IsLtmCandPrepForMeas(rCi))
    {
        ltmCellInfo_type *pLtmCell = FnVCCB_GetLtmCellInfoForIndex(const_cast<callInfo_type*>(&rCi), rCi.ltmUeInfo.currCandidateCellIdx);
        if (nullptr == pLtmCell)
        {
            VCCB_PRINT_CALL_ERROR(&rCi, "FnVCCB_GetLtmCellInfoForIndex fail for currCandidateCellIdx(%u)!\n",
                rCi.ltmUeInfo.currCandidateCellIdx);
            static duSelectionRelatedData_type dummyDuSelectionRelatedData = {0, 0, 0, 0};
            return dummyDuSelectionRelatedData;
        }
        return pLtmCell->data.duSelectionRelatedData;
    }

    return rCi.duSelectionRelatedData;
}

/**
 * @brief   Updates selected power class (if needed) and returns its value
 *
 * @param   rCi : callInfo
 */
enumUeAllPowerClass_type VLIB_GetSelectedPowerClass(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    const uint16_t spCellBand = FnVCCB_GetCellSelectionForConfig(&rCi).bandNr;
    duSelectionRelatedData_type &rDuSelectionRelatedData = VLIB_GetDuSelectionRelatedData(rCi);
    if (spCellBand != rDuSelectionRelatedData.bandUsedForPCSelection)
    {
        VLIB_SetSelectedPowerClass(rCi, rDuSelectionRelatedData);
        VCCB_PRINT_LOG_CA_FUNC_TRACE(&rCi, "CA: Selected Power Class %s\n",
            VLIB_UeAllPowerClassToStr(rDuSelectionRelatedData.selectedPowerClass));
        rDuSelectionRelatedData.bandUsedForPCSelection = spCellBand;
    }

    return static_cast<enumUeAllPowerClass_type>(rDuSelectionRelatedData.selectedPowerClass);
}

/**
 * @brief   Returns true if selected power class is higher than PC3 (PC1, PC1dot5, PC2)
 *
 * @param   rCi : callInfo
 */
bool VLIB_IsHighPowerClassSelected(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    const enumUeAllPowerClass_type selectedPC = VLIB_GetSelectedPowerClass(rCi);

    return (PowerClass_None != selectedPC) &&
           (PowerClass_Pc3 > selectedPC);
}

/**
 * @brief     Function returns proper LTM candidate or current scell list.
 */
scellList_type &FnVCCB_GetScellInfoList(callInfo_type &rCall)
{
    if (FnVCCB_IsLtmCandPrepForMeas(rCall))
    {
        if ((MAX_NUM_LTM_CELLS <= rCall.ltmUeInfo.currCandidateCellIdx) || (nullptr == rCall.ltmUeInfo.ptProcRelatedData))
        {
            return dummyScells;
        }
        return rCall.ltmUeInfo.ptProcRelatedData->ltmCaInfo[rCall.ltmUeInfo.currCandidateCellIdx].ltmScells;
    }

    return rCall.sCell;
}

/**
 * @brief     Function returns proper LTM candidate or current const scell list.
 */
const scellList_type &FnVCCB_GetConstScellInfoList(const callInfo_type &rCall)
{
    if (FnVCCB_IsLtmCandPrepForMeas(rCall))
    {
        if ((MAX_NUM_LTM_CELLS <= rCall.ltmUeInfo.currCandidateCellIdx) || (nullptr == rCall.ltmUeInfo.ptProcRelatedData))
        {
            return dummyScells;
        }
        return rCall.ltmUeInfo.ptProcRelatedData->ltmCaInfo[rCall.ltmUeInfo.currCandidateCellIdx].ltmScells;
    }

    return rCall.sCell;
}

/**
 * @brief Check if there is at least one Added SCell.
 * @param rCi : callInfo
 * @return true  : SCell exists
 * @return false  : SCell does not exists
 */
bool FnVCCB_IsScellExist(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    for (auto const &rSCell : rCi.sCell)
    {
        if (rSCell.state == SCELL_STATE_ADDED)
        {
            return true;
        }
    }

    return false;
}

/**
 * @brief Check whether to use AllowedBcFilterMnBc
 * @param rCi : callInfo
 * @return true  : Use AllowedBcFilterMnBc
 * @return false  : Not use AllowedBcFilterMnBc
 */
bool VLIB_IsAllowedBcFilterMnBcRequired(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(rCi.gnbNum, MAX_GNB_PER_SYS, false);
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(rCi.servCellNum, false);

    // 1. Check allowedBcFilterMnBc (YANG)
    VccbGnbInfo_type *const pGnb = &GNBINFO[rCi.gnbNum];
    
    if (rCi.bitFlag.mnBcReselectionFeatureOn == TRUE)
    {
        VCCB_PRINT_LOG_ALLOWED_BC_MN_FILTER(&rCi, "[ALLOWEDFILTER] AlloewdBcMnFilter is not active, mnBcReselection On \n");
        return false;
    }
    
    if (pGnb->cfg.nrdc.allowedBcFilterMnBc == VCCB_FLAG_OFF)
    {
        VCCB_PRINT_LOG_ALLOWED_BC_MN_FILTER(&rCi, "[ALLOWEDFILTER] AlloewdBcMnFilter is not active because of allowedBcFilterMnBc Off\n");
        return false;
    }

    // 2. Check CA Mode3
    if(rCi.caInfo.mode == CaOperation_Mode3)
    {
        VCCB_PRINT_LOG_ALLOWED_BC_MN_FILTER(&rCi, "[ALLOWEDFILTER] AlloewdBcMnFilter is not active because of CA Mode3\n");
        return false;
    }

    if (not IS_MRDC_MN(&rCi))
    {
        VCCB_PRINT_LOG_ALLOWED_BC_MN_FILTER(&rCi, "[ALLOWEDFILTER] AlloewdBcMnFilter is not active because NR-DC SN Call\n");
        return false;
    }

    // 3. Check if HO and target cell condition
    if (rCi.stateCmd == IntraRatHO_cmd && rCi.state != STATE_MN_INTER_SN_Pre_SN)
    {
        // Compare source PCell Information and target PCell Information in allowedBC_ListMRDC
        bool pCellChangedFlag = FnVCCB_CheckPcellInfoChangedforAllowedBC(&rCi, rCi.servCellNum, rCi.servCellBand);
        if ((rCi.hoInfo.hoType.nb != HO_TYPE_INTRA_NB) ||
                (VCCB_IS_INTER_FREQ_SSB_FREQ(rCi.servCellNum, rCi.hoInfo.tgtSsbFreq)) ||
                pCellChangedFlag)
        {
            VCCB_PRINT_LOG_ALLOWED_BC_MN_FILTER(&rCi, "[ALLOWEDFILTER] AlloewdBcMnFilter is not active because HO Condition\n");
            return false;
        }
    }

    // 4. Check if the current sCell exists
    bool nonCaFlag = true;

    if (FnVCCB_IsScellExist(rCi))
    {
        nonCaFlag = false;
    }

    if (nonCaFlag)
    {
        VCCB_PRINT_LOG_ALLOWED_BC_MN_FILTER(&rCi, "[ALLOWEDFILTER] AlloewdBcMnFilter is not active because of non CA\n");
        return false;
    }

    return true;
}

void VLIB_MakeContiguousCellGroup(callInfo_type *ptCi, mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBandOut) // empty check is needed
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_VALID_CELLNUM_VOID(ptCi->servCellNum); // need to check HO target cell?

    uint8_t loop = 0;
    mcoBcSelCellInfo_type cellList[MAX_SCELL_PER_CALL + 1];
    uint8_t currentCellCnt = 0;

    auto fnSetCellListValue = [&](
            uint32_t nrArfcnDl, uint8_t nrScsDl, uint8_t nRbDl, uint16_t frequencyBand, uint16_t cellBwDl, uint16_t mcoBwDl)
    {
        cellList[currentCellCnt].nrArfcnDl = nrArfcnDl;
        cellList[currentCellCnt].nrScsDl = nrScsDl;
        cellList[currentCellCnt].nRbDl = nRbDl;
        cellList[currentCellCnt].frequencyBand = frequencyBand;
        cellList[currentCellCnt].cellBwDl = cellBwDl;
        cellList[currentCellCnt++].mcoBwDl = mcoBwDl;
    };

    std::fill(cellList, cellList + MAX_SCELL_PER_CALL + 1, mcoBcSelCellInfo_type());

    // 1. Make current CC List
    caCellInfo_type pCellInfo;
    cellSelection_type cellSelection = FnVCCB_GetCellSelectionForConfig(ptCi);
    if (VLIB_FillPcellCaCellInfo(ptCi, cellSelection, pCellInfo) != GOOD)
    {
        return;
    }

    enumNrSystemBandwidth_type pCellNRbDl = static_cast<enumNrSystemBandwidth_type>(pCellInfo.nRbDl);
    enumNrSubCarrierSpacing_type pCellNrScsDl = static_cast<enumNrSubCarrierSpacing_type>(pCellInfo.nrScsDl);
    uint16_t pCellBwDl  = static_cast<uint16_t>(VLIB_NrbScs2Bw(pCellNRbDl, pCellNrScsDl));

    fnSetCellListValue(pCellInfo.nrArfcnDl, pCellInfo.nrScsDl, pCellInfo.nRbDl, pCellInfo.frequencyBand, pCellBwDl, pCellInfo.mcoBwDl);

    for (loop = 0; loop < MAX_SCELL_PER_CALL; ++loop)
    {
        auto &sCell = ptCi->sCell[loop];

        if (sCell.state == SCELL_STATE_ADDED && sCell.bandNr < MAX_FR1_NR_BAND)
        {
            uint16_t duplexType = FnVCCB_GetNrDuplexTypeByBandIndicator(sCell.bandNr);
            uint16_t dlBw = 0, ulBw = 0;
            const nbrGnbCellInfo_type *ptCell = VLIB_GetNbrGnbCellInfoBasedOnCgi(ptCi, sCell.cgi, sCell.gnbIdLength);
            VALID_E_POINT_CHECK_VOID(ptCell);
            FnVCCB_McoFillBandwidthByDuplex(duplexType, dlBw, ulBw, *ptCell);

            fnSetCellListValue(sCell.nrArfcn, sCell.nrScsDl, sCell.nrbDl, sCell.bandNr, ptCell->bandwidthDl, dlBw);
            VCCB_CHECK_E_RANGE_AND_VOID(currentCellCnt, MAX_SCELL_PER_CALL + 1);
        }
    }

    // 2. ascending order by bandNr and nrArfcn
    std::sort(cellList, cellList + currentCellCnt,
        [](const mcoBcSelCellInfo_s &lhs, const mcoBcSelCellInfo_s &rhs)
        {
            return ((lhs.frequencyBand < rhs.frequencyBand) ||
                    (lhs.frequencyBand == rhs.frequencyBand && lhs.nrArfcnDl < rhs.nrArfcnDl));
        });

    auto fnSetCcInfo = [&pCellInfo](
            mcoCcInfo_s &ccInfoOut, const mcoBcSelCellInfo_s &caCellInfoIn, const uint8_t grpIdCurrIn)
    {
        ccInfoOut.mcoBwDl = caCellInfoIn.mcoBwDl;
        ccInfoOut.grpId = grpIdCurrIn;
        ccInfoOut.pcellFlag =
            ((pCellInfo.frequencyBand == caCellInfoIn.frequencyBand) && (pCellInfo.nrArfcnDl == caCellInfoIn.nrArfcnDl));
        ccInfoOut.userValue = caCellInfoIn.ssbArfcn;
        ccInfoOut.cellBwDl = caCellInfoIn.cellBwDl;
    };

    // 3. Make Contiguous Group per band indicator
    FnVCCB_McoCreateContigCcGroupsPerBand(cellList, cellList + currentCellCnt, ccInfoVecPerBandOut, fnSetCcInfo);
}

void VLIB_MakeBandCombinationOfCurrentScell(callInfo_type *ptCi, BandCombination_type &rScellBc, mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBandOut)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

#define Bandwidth_250MHz 250
#define Bandwidth_300MHz 300
#define Bandwidth_350MHz 350

    // 1. Make Contiguous Cell Group for Current Scell
    VLIB_MakeContiguousCellGroup(ptCi, ccInfoVecPerBandOut);

    if (ccInfoVecPerBandOut.size() == 0)
    {
        return;
    }

    memset(&rScellBc, 0, sizeof(BandCombination_type));

    // Decision BandWidthClass according to ccCnt and bw
    auto fnCheckBwcPerBand = [&rScellBc](uint8_t curCcCnt, uint16_t band, uint32_t totalBwDl, bool pCellFlag)
    {
        auto fnSetCcInfo = [](BandParameters_type &curBand, uint16_t key, NrCaBandwidthClass dlBwc, uint8_t dlCc, bool pCell)
        {
            curBand.ratType = ci_nr;
            curBand.freqBandIndicator = key;
            curBand.nrCaBandwidthClassDL = static_cast<uint8_t>(dlBwc) & e_BitMask_5bit;
            curBand.numContiguousCcDL = dlCc & e_BitMask_4bit;
            if (pCell)
            {
                curBand.nrCaBandwidthClassUL = CA_BandwidthClassNR_a;
            }
            else
            {
                curBand.nrCaBandwidthClassUL = CA_BandwidthClassNR_NOT_SET;
            }
        };

        if (rScellBc.num >= MAX_BANDS_PER_COMB)
        {
            return;
        }

        if (curCcCnt == 1)
        {
            uint8_t dlCc = VRIL_getNumContiguousCcForBandClass(band, CA_BandwidthClassNR_a);
            fnSetCcInfo(rScellBc.band[rScellBc.num], band, CA_BandwidthClassNR_a, dlCc, pCellFlag);
            rScellBc.num++;
        }
        else if (curCcCnt == 2)
        {
            if (totalBwDl <= ci_nr_bandwidth_100MHz)
            {
                uint8_t dlCc = VRIL_getNumContiguousCcForBandClass(band, CA_BandwidthClassNR_b);
                fnSetCcInfo(rScellBc.band[rScellBc.num], band, CA_BandwidthClassNR_b, dlCc, pCellFlag);
                rScellBc.num++;
            }
            else
            {
                uint8_t dlCc = VRIL_getNumContiguousCcForBandClass(band, CA_BandwidthClassNR_c);
                fnSetCcInfo(rScellBc.band[rScellBc.num], band, CA_BandwidthClassNR_c, dlCc, pCellFlag);
                rScellBc.num++;
            }
        }
        else if (curCcCnt == 3)
        {
            if (totalBwDl > ci_nr_bandwidth_200MHz)
            {
                uint8_t dlCc = VRIL_getNumContiguousCcForBandClass(band, CA_BandwidthClassNR_d);
                fnSetCcInfo(rScellBc.band[rScellBc.num], band, CA_BandwidthClassNR_d, dlCc, pCellFlag);
                rScellBc.num++;
            }
            else // G Class CA is not exist in 38.101-1 18.9 version
            {
                uint8_t dlCc = VRIL_getNumContiguousCcForBandClass(band, CA_BandwidthClassNR_m);
                fnSetCcInfo(rScellBc.band[rScellBc.num], band, CA_BandwidthClassNR_m, dlCc, pCellFlag);
                rScellBc.num++;
            }
        }
        else if (curCcCnt == 4)
        {
            if (totalBwDl > Bandwidth_300MHz)
            {
                uint8_t dlCc = VRIL_getNumContiguousCcForBandClass(band, CA_BandwidthClassNR_e);
                fnSetCcInfo(rScellBc.band[rScellBc.num], band, CA_BandwidthClassNR_e, dlCc, pCellFlag);
                rScellBc.num++;
            }
            else // H Class CA is not exist in 38.101-1 18.9 version
            {
                uint8_t dlCc = VRIL_getNumContiguousCcForBandClass(band, CA_BandwidthClassNR_n);
                fnSetCcInfo(rScellBc.band[rScellBc.num], band, CA_BandwidthClassNR_n, dlCc, pCellFlag);
                rScellBc.num++;
            }
        }
        else if (curCcCnt == 5)
        {
            // I Class CA is not exist in 38.101-1 18.9 version
            if (totalBwDl >= ci_nr_bandwidth_100MHz && totalBwDl <= ci_nr_bandwidth_400MHz)
            {
                uint8_t dlCc = VRIL_getNumContiguousCcForBandClass(band, CA_BandwidthClassNR_o);
                fnSetCcInfo(rScellBc.band[rScellBc.num], band, CA_BandwidthClassNR_o, dlCc, pCellFlag);
                rScellBc.num++;
            }
        }
        else if (curCcCnt == 6)
        {
            if (totalBwDl > Bandwidth_250MHz && totalBwDl <= Bandwidth_300MHz)
            {
                uint8_t dlCc = VRIL_getNumContiguousCcForBandClass(band, CA_BandwidthClassNR_j);
                fnSetCcInfo(rScellBc.band[rScellBc.num], band, CA_BandwidthClassNR_j, dlCc, pCellFlag);
                rScellBc.num++;
            }
        }
        else if (curCcCnt == 7)
        {
            if (totalBwDl > Bandwidth_300MHz && totalBwDl <= Bandwidth_350MHz)
            {
                uint8_t dlCc = VRIL_getNumContiguousCcForBandClass(band, CA_BandwidthClassNR_k);
                fnSetCcInfo(rScellBc.band[rScellBc.num], band, CA_BandwidthClassNR_k, dlCc, pCellFlag);
                rScellBc.num++;
            }
        }
        else if (curCcCnt == 8)
        {
            if (totalBwDl > Bandwidth_350MHz && totalBwDl <= ci_nr_bandwidth_400MHz)
            {
                uint8_t dlCc = VRIL_getNumContiguousCcForBandClass(band, CA_BandwidthClassNR_l);
                fnSetCcInfo(rScellBc.band[rScellBc.num], band, CA_BandwidthClassNR_l, dlCc, pCellFlag);
                rScellBc.num++;
            }
        }
        else
        {
            fnSetCcInfo(rScellBc.band[rScellBc.num], band, CA_BandwidthClassNR_NOT_SET, 0, false);
            rScellBc.num++;
        }
    };

    // 2. Make Superset of Current Scells
    for (auto &[band, ccInfoVecs] : ccInfoVecPerBandOut)
    {
        uint16_t curGrpId = 0;
        uint8_t curCcCnt = 0;
        uint16_t totalBwDl = 0;
        bool pCellFlag = false;

        // only 1CC case
        if (ccInfoVecs.ccInfoVec.size() == 1)
        {
            auto singleCcInfo = ccInfoVecs.ccInfoVec.front();
            pCellFlag = singleCcInfo.pcellFlag;
            fnCheckBwcPerBand(1, band, singleCcInfo.mcoBwDl, pCellFlag);
            continue;
        }

        // multi CC case
        for (auto &ccInfo : ccInfoVecs.ccInfoVec)
        {
            if (rScellBc.num > MAX_BANDS_PER_COMB)
            {
                break;
            }

            if (curGrpId != ccInfo.grpId)
            {
                fnCheckBwcPerBand(curCcCnt, band, totalBwDl, pCellFlag);
                curGrpId = ccInfo.grpId;
                curCcCnt = 0;
                totalBwDl = 0;
                pCellFlag = false;
            }

            curCcCnt++;
            totalBwDl = static_cast<uint16_t>(totalBwDl + ccInfo.cellBwDl);

            if (ccInfo.pcellFlag)
            {
                pCellFlag = true;
            }
        }

        fnCheckBwcPerBand(curCcCnt, band, totalBwDl, pCellFlag);

        if (rScellBc.num > MAX_BANDS_PER_COMB)
        {
            break;
        }
    }

#undef Bandwidth_250MHz
#undef Bandwidth_300MHz
#undef Bandwidth_350MHz
}

uint8_t VRIL_getNumContiguousCcForBandClass(uint16_t bandNr, NrCaBandwidthClass bandClass)
{
    AUTO_TRACE_FUNC;

    if (257 > bandNr)
    {
        switch (bandClass)  // FR1
        {
            case CA_BandwidthClassNR_NOT_SET:
                return 0;
            case CA_BandwidthClassNR_a:
                return 1;
            case CA_BandwidthClassNR_b:
            case CA_BandwidthClassNR_c:
                return 2;
            case CA_BandwidthClassNR_d:
            case CA_BandwidthClassNR_g:
            case CA_BandwidthClassNR_m:
                return 3;
            case CA_BandwidthClassNR_e:
            case CA_BandwidthClassNR_h:
            case CA_BandwidthClassNR_n:
                return 4;
            case CA_BandwidthClassNR_i:
            case CA_BandwidthClassNR_o:
                return 5;
            case CA_BandwidthClassNR_j:
                return 6;
            case CA_BandwidthClassNR_k:
                return 7;
            case CA_BandwidthClassNR_l:
                return 8;
                // not specified in 3GPP TS 38.101-1 v17.12
            default:
                break;
        }
    }
    else
    {
        switch (bandClass)  // FR2
        {
            case CA_BandwidthClassNR_NOT_SET:
                return 0;
            case CA_BandwidthClassNR_a:
                return 1;
            case CA_BandwidthClassNR_b:
            case CA_BandwidthClassNR_d:
            case CA_BandwidthClassNR_g:
            case CA_BandwidthClassNR_o:
            case CA_BandwidthClassNR_r2:
                return 2;
            case CA_BandwidthClassNR_c:
            case CA_BandwidthClassNR_e:
            case CA_BandwidthClassNR_h:
            case CA_BandwidthClassNR_p:
            case CA_BandwidthClassNR_r3:
                return 3;
            case CA_BandwidthClassNR_f:
            case CA_BandwidthClassNR_i:
            case CA_BandwidthClassNR_q:
            case CA_BandwidthClassNR_r4:
                return 4;
            case CA_BandwidthClassNR_j:
            case CA_BandwidthClassNR_r5:
                return 5;
            case CA_BandwidthClassNR_k:
            case CA_BandwidthClassNR_r6:
                return 6;
            case CA_BandwidthClassNR_l:
            case CA_BandwidthClassNR_r7:
                return 7;
            case CA_BandwidthClassNR_m:
            case CA_BandwidthClassNR_r8:
                return 8;
            case CA_BandwidthClassNR_r9:
                return 9;
            case CA_BandwidthClassNR_r10:
                return 10;
            case CA_BandwidthClassNR_r11:
                return 11;
            case CA_BandwidthClassNR_r12:
                return 12;
                // not specified in 3GPP TS 38.101-2 v17.12
            default:
                break;
        }
    }
    return 0;
}

NrCaBandwidthClass VRIL_getFallbackBandwidthClassFr1(uint16_t bandNr, NrCaBandwidthClass bandClass)
{
    AUTO_TRACE_FUNC;

    if (bandNr < MAX_FR1_NR_BAND)
    {
        switch (bandClass)  // FR1
        {
            case CA_BandwidthClassNR_a:
                return CA_BandwidthClassNR_NOT_SET;

            case CA_BandwidthClassNR_c:
                return CA_BandwidthClassNR_a;
            case CA_BandwidthClassNR_d:
                return CA_BandwidthClassNR_c;
            case CA_BandwidthClassNR_e:
                return CA_BandwidthClassNR_d;

            case CA_BandwidthClassNR_b:
                return CA_BandwidthClassNR_a;
            case CA_BandwidthClassNR_f:
                return CA_BandwidthClassNR_a;
            case CA_BandwidthClassNR_g:
                return CA_BandwidthClassNR_b;
            case CA_BandwidthClassNR_h:
                return CA_BandwidthClassNR_g;
            case CA_BandwidthClassNR_i:
                return CA_BandwidthClassNR_h;
            case CA_BandwidthClassNR_j:
                return CA_BandwidthClassNR_i;
            case CA_BandwidthClassNR_k:
                return CA_BandwidthClassNR_j;
            case CA_BandwidthClassNR_l:
                return CA_BandwidthClassNR_k;

            case CA_BandwidthClassNR_m: // M Class CA supports only B class Fallback in 38.101-1 18.9 version
                return CA_BandwidthClassNR_b;
            case CA_BandwidthClassNR_n:
                return CA_BandwidthClassNR_m;
            case CA_BandwidthClassNR_o:
                return CA_BandwidthClassNR_n;
            default:
                break;
        }
    }
    return CA_BandwidthClassNR_NOT_SET;
}

void VLIB_PermutateEachBcWithFallbackGroup(const BandCombination_type &rBc, bandCombinationList_type &rSubsetBc)
{
    AUTO_TRACE_FUNC;
#define MAX_FALLBACK_GRP_NUM_FR1 10
    uint16_t loop = 0, loop2 = 0;
    BandParameters_type bwSubset[MAX_BANDS_PER_COMB][MAX_FALLBACK_GRP_NUM_FR1];
    uint16_t subBcCnt[MAX_BANDS_PER_COMB] = {0, };
    uint16_t maxSubCnt = 1;

    memset(bwSubset, 0, sizeof(bwSubset));

    BandCombination_type tempBc = rBc;
    // 1. ascending order rBc by freqBandIndicator and nrCaBandwidthClassDL
    std::sort(tempBc.band, tempBc.band + tempBc.num,
        [](const BandParameters_type &lhs, const BandParameters_type &rhs)
        {
            return ((lhs.freqBandIndicator < rhs.freqBandIndicator) ||
                    (lhs.freqBandIndicator == rhs.freqBandIndicator && lhs.nrCaBandwidthClassDL < rhs.nrCaBandwidthClassDL));
        });

    // 2. Make each band's fallback group
    for (loop = 0; loop < MIN(tempBc.num, MAX_BANDS_PER_COMB); ++loop)
    {
        BandParameters_type curBandParam = tempBc.band[loop];
        uint16_t totalCnt = 0;
        uint8_t dlCC = VRIL_getNumContiguousCcForBandClass(curBandParam.freqBandIndicator, static_cast<NrCaBandwidthClass>(curBandParam.nrCaBandwidthClassDL));

        if (curBandParam.nrCaBandwidthClassUL != CA_BandwidthClassNR_NOT_SET)
        {
            curBandParam.nrCaBandwidthClassUL = CA_BandwidthClassNR_a & e_BitMask_5bit;
            curBandParam.numContiguousCcUL = 1 & e_BitMask_5bit;
        }

        for (loop2 = 0; loop2 < MIN(dlCC + 1, MAX_FALLBACK_GRP_NUM_FR1); ++loop2)
        {
            if (curBandParam.nrCaBandwidthClassDL == CA_BandwidthClassNR_NOT_SET)
            {
                bwSubset[loop][totalCnt].ratType = ci_nr;
                bwSubset[loop][totalCnt].freqBandIndicator = curBandParam.freqBandIndicator;
                bwSubset[loop][totalCnt].nrCaBandwidthClassDL = curBandParam.nrCaBandwidthClassDL;
                bwSubset[loop][totalCnt].nrCaBandwidthClassUL = curBandParam.nrCaBandwidthClassUL;
                bwSubset[loop][totalCnt].numContiguousCcDL = curBandParam.numContiguousCcDL;
                bwSubset[loop][totalCnt].numContiguousCcUL = curBandParam.numContiguousCcUL;
                totalCnt++;
                break;
            }

            bwSubset[loop][totalCnt].ratType = ci_nr;
            bwSubset[loop][totalCnt].freqBandIndicator = curBandParam.freqBandIndicator;
            bwSubset[loop][totalCnt].nrCaBandwidthClassDL = curBandParam.nrCaBandwidthClassDL;
            bwSubset[loop][totalCnt].nrCaBandwidthClassUL = curBandParam.nrCaBandwidthClassUL;
            bwSubset[loop][totalCnt].numContiguousCcDL = curBandParam.numContiguousCcDL;
            bwSubset[loop][totalCnt].numContiguousCcUL = curBandParam.numContiguousCcUL;
            totalCnt++;

            uint16_t bandNr = curBandParam.freqBandIndicator;
            NrCaBandwidthClass bwcDl = static_cast<NrCaBandwidthClass>(curBandParam.nrCaBandwidthClassDL);
            curBandParam.nrCaBandwidthClassDL = static_cast<uint8_t>((VRIL_getFallbackBandwidthClassFr1(bandNr, bwcDl))) & e_BitMask_5bit;
            curBandParam.numContiguousCcDL = VRIL_getNumContiguousCcForBandClass(bandNr, static_cast<NrCaBandwidthClass>(curBandParam.nrCaBandwidthClassDL)) & e_BitMask_4bit;
        }

        if (maxSubCnt * totalCnt > MAX_BAND_COMBS)
        {
            break;
        }

        subBcCnt[loop] = totalCnt;
        maxSubCnt = static_cast<uint16_t>(maxSubCnt * totalCnt);
    }

    // 3. Generate subsetCombination
    uint16_t tempVal = 1;
    for (loop = 0; loop < MIN(tempBc.num, MAX_BANDS_PER_COMB); ++loop)
    {
        uint16_t loop3 = 0;
        for (loop2 = 0; loop2 < MIN(maxSubCnt, MAX_BAND_COMBS); ++loop2)
        {
            if (tempVal == 1)
            {
                loop3 = static_cast<uint16_t>(loop2 % subBcCnt[loop]);
            }
            else
            {
                loop3 = static_cast<uint16_t>((loop2 % (subBcCnt[loop] * static_cast<unsigned int>(tempVal))) / tempVal);
            }

            if (loop3 < MAX_FALLBACK_GRP_NUM_FR1 && rSubsetBc.bandCombination[loop2].num < MAX_BANDS_PER_COMB)
            {
                if (bwSubset[loop][loop3].nrCaBandwidthClassDL != CA_BandwidthClassNR_NOT_SET)
                {
                    uint16_t curBandCnt = rSubsetBc.bandCombination[loop2].num;
                    rSubsetBc.bandCombination[loop2].band[curBandCnt].ratType = bwSubset[loop][loop3].ratType;
                    rSubsetBc.bandCombination[loop2].band[curBandCnt].freqBandIndicator = bwSubset[loop][loop3].freqBandIndicator;
                    rSubsetBc.bandCombination[loop2].band[curBandCnt].nrCaBandwidthClassDL = bwSubset[loop][loop3].nrCaBandwidthClassDL;
                    rSubsetBc.bandCombination[loop2].band[curBandCnt].nrCaBandwidthClassUL = bwSubset[loop][loop3].nrCaBandwidthClassUL;
                    rSubsetBc.bandCombination[loop2].band[curBandCnt].numContiguousCcDL = bwSubset[loop][loop3].numContiguousCcDL;
                    rSubsetBc.bandCombination[loop2].band[curBandCnt].numContiguousCcUL = bwSubset[loop][loop3].numContiguousCcUL;
                    rSubsetBc.bandCombination[loop2].num++;
                }
            }
        }
        tempVal = (uint16_t)(tempVal*subBcCnt[loop]);
    }

    rSubsetBc.num = maxSubCnt;
#undef MAX_FALLBACK_GRP_NUM_FR1
}

void FnVCCB_CalculateBwForEachBcAgainstCcNr(callInfo_type *ptCi, const bandCombinationList_type &ueSupBandCombList,
    const uint16_t pcellBand, const mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBand,
    const McoAlgoFlags &algoFlags, mcoBand2BcBandResultsCache_s &mcoBand2BcBandResultsCache, totalBwPerBc_type &bcBwMaxIdxDqOut)
{
    AUTO_TRACE_FUNC;
    bcBwMaxIdxDqOut.clear();

    VALID_E_POINT_CHECK_VOID(ptCi);

    uint32_t bcBw = 0;
    mcoCheckBcResult_s bcBandResult;
    char ccCauseCodesTab[MAX_MCO_CCNUM + 1];

    // UL, MIMO, MFBI, PCC FM is not considered
    auto fnCheckBcAgainstCcNr = [&](uint16_t bcIdx)
    {
        mcoBand2numContCcDq_type mcoBand2numContCcDq;
        mcoBand2mcoNumContiguousCc_type band2numContiguousCcUL;

        FnVCCB_McoRetrieveBcData(
                ptCi, ueSupBandCombList.bandCombination[bcIdx], bcIdx, ci_nr, algoFlags, mcoBand2numContCcDq, band2numContiguousCcUL);

        if (DBG->flag.logAllowedBcMnFilter)
        {
            for (const mcoBand2numContCcDq_type::value_type &kv : mcoBand2numContCcDq)
            {
                VCCB_PRINT_LOG_ALLOWED_BC_MN_FILTER(ptCi, "====== [ALLOWEDFILTER] UE Capa BC idx(%u) band-NR(%u) ======\n", bcIdx, kv.first);
                for (const mcoUeCapaBcBandInfo_s &bcBandInfo : kv.second)
                {
                    VCCB_PRINT_LOG_ALLOWED_BC_MN_FILTER(ptCi, "numContiguousCc%s(%u) ulFlag(%u) DL_MIMO(%u)\n",
                            algoFlags.ulOnlyMode ? "UL" : "DL",
                            bcBandInfo.numContiguousCcDL,
                            bcBandInfo.ulFlag, bcBandInfo.dlMimoLayerNum);
                }
            }
        }

        const bool pcellEligible = (band2numContiguousCcUL.end() != band2numContiguousCcUL.find(pcellBand));
        if (false == pcellEligible)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                    "[BCSel] BC idx(%u) NR check: not eligible for PCell's band-NR(%u) - skip\n", bcIdx, pcellBand);
            return;
        }

        // check one BC-Band against NR CC
        bcBw = 0;
        for (mcoBand2numContCcDq_type::value_type &kv : mcoBand2numContCcDq)
        {
            const uint16_t band = kv.first;
            VCCB_PRINT_LOG_ALLOWED_BC_MN_FILTER(
                    ptCi, "====== [ALLOWEDFILTER] Check UE Capa BC idx(%u) band-NR(%u) ======\n", bcIdx, band);

            mcoBand2mcoCcInfoVecMap_type::const_iterator ccInfoVecPerBandIt = ccInfoVecPerBand.find(band);
            if (ccInfoVecPerBand.end() == ccInfoVecPerBandIt)
            {
                VCCB_PRINT_LOG_ALLOWED_BC_MN_FILTER(ptCi, "[ALLOWEDFILTER] BC idx(%u) band-NR(%u) check: No CC\n", bcIdx, band);
                continue;
            }

            const mcoCcInfoVec_type &ccInfoVec = ccInfoVecPerBandIt->second.ccInfoVec;
            const bool checkPcell = (pcellBand == band);
            mcoCheckBcBandResultsCache_s *pBcBandCache = mcoBand2BcBandResultsCache.getForBand(ci_nr, band);

            if (false == FnVCCB_McoCheckBcBandAgainstCcList(
                        ptCi, ccInfoVec, kv.second, checkPcell, ccCauseCodesTab, pBcBandCache, algoFlags.checkUlBw, algoFlags.noMimo, bcBandResult))
            {
                VCCB_PRINT_LOG_ALLOWED_BC_MN_FILTER(
                        ptCi, "[ALLOWEDFILTER] BC idx(%u) band-NR(%u) check: inadequate result!\n", bcIdx, band);
                continue;
            }

            VCCB_PRINT_LOG_ALLOWED_BC_MN_FILTER(ptCi, "[ALLOWEDFILTER] BC idx(%u) band-NR(%u) check: BW(%u) cause(%s) ccidx(0x%lx)\n",
                    bcIdx, band, bcBandResult.mcoBwDl, ccCauseCodesTab, bcBandResult.ccIdxBitmask);

            bcBw += bcBandResult.mcoBwDl;
        }

        bcBwMaxIdxDqOut.push_back({bcIdx, bcBw});
        VCCB_PRINT_LOG_ALLOWED_BC_MN_FILTER(ptCi, "[ALLOWEDFILTER][BCSel] BC idx(%u) NR check: BW(%u)\n", bcIdx, bcBw);
    };

    for (uint16_t bcIdx = 0; bcIdx < ueSupBandCombList.num; bcIdx++)
    {
        fnCheckBcAgainstCcNr(bcIdx);
    }
}

void FnVCCB_CalculateBwForBcList(callInfo_type *ptCi, bandCombinationList_type &rBc, mcoBand2mcoCcInfoVecMap_type &ccInfoVecPerBand, totalBwPerBc_type &bcBwMaxIdxDq)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (rBc.num == 0 || ccInfoVecPerBand.size() == 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[ALLOWEDFILTER] No valid NR CC!\n");
        return;
    }

    cellSelection_type rCellSelection;
    rCellSelection.cellNum = ptCi->servCellNum;
    rCellSelection.bandNr = ptCi->servCellBand;

    mcoBand2BcBandResultsCache_s mcoBand2BcBandResultsCache(ptCi);
    const McoAlgoFlags algoFlags = { .noMimo = true,
        .checkUlBw = false,
        .ulOnlyMode = false,
        .mfbiCheck = false,
        .initialFmPcc = false,
        .checkCarrierOnly = false,
        .useSe = false,
        .useMultiChBw = false };

    // The MIMO layer value is not considered and is not applied when calculating (noMimoFlag = true)
    FnVCCB_CalculateBwForEachBcAgainstCcNr(ptCi, rBc, rCellSelection.bandNr,
            ccInfoVecPerBand, algoFlags, mcoBand2BcBandResultsCache, bcBwMaxIdxDq);

    if (bcBwMaxIdxDq.size() == 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[ALLOWEDFILTER] No UE Capa BC selected!\n");
        return;
    }

    // Descending order for bw
    std::sort(bcBwMaxIdxDq.begin(), bcBwMaxIdxDq.end(),
        [](const auto& lhs, const auto& rhs)
        {
            return lhs.second > rhs.second;
        });

    return;
}

uint32_t VLIB_GetCurrentScellBwDlEachAllowedBc(callInfo_type *ptCi, bandCombinationList_type &rSourceBcList, const BandCombination_type &rTargetBc, totalBwPerBc_type &bcBwMaxIdxDq, bool &isIncludedAllScell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, 0);

    // 1. Get rTargetBc has only FR1
    BandCombination_type mnBc;
    memset(&mnBc, 0, sizeof(mnBc));
    uint8_t mnBcBandCnt = 0;
    uint16_t loop = 0, loop2 = 0, loop3 = 0;

    if (bcBwMaxIdxDq.empty())
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[ALLOWEDFILTER] bcBwMaxIdxDq is invalid in %s\n", __FUNCTION__);
        return 0;
    }

    for (loop = 0; loop < MIN(rTargetBc.num, MAX_BANDS_PER_COMB); ++loop)
    {
        BandParameters_type curBand = rTargetBc.band[loop];
        if (curBand.freqBandIndicator <= MAX_FR1_NR_BAND)
        {
            memcpy(&mnBc.band[mnBcBandCnt], &rTargetBc.band[loop], sizeof(BandParameters_type));
            mnBcBandCnt++;
        }
    }

    if (mnBcBandCnt == 0 || mnBcBandCnt >= MAX_BANDS_PER_COMB)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[ALLOWEDFILTER] bc is invalid in %s\n", __FUNCTION__);
        return 0;
    }

    std::sort(mnBc.band, mnBc.band + mnBc.num,
        [](const BandParameters_type &lhs, const BandParameters_type &rhs)
        {
            return ((lhs.freqBandIndicator < rhs.freqBandIndicator) ||
                    (lhs.freqBandIndicator == rhs.freqBandIndicator && lhs.nrCaBandwidthClassDL < rhs.nrCaBandwidthClassDL));
        });

    mnBc.num = mnBcBandCnt;

    auto fnCheckSameBandCombination = [&](BandCombination_type bc1, BandCombination_type bc2) -> bool
    {
        if (bc1.num != bc2.num)
        {
            return false;
        }

        for (loop3 = 0; loop3 < UMIN(bc1.num, MAX_BANDS_PER_COMB); ++loop3)
        {
            if (bc1.band[loop3].ratType != bc2.band[loop3].ratType)
            {
                return false;
            }
            if (bc1.band[loop3].freqBandIndicator != bc2.band[loop3].freqBandIndicator)
            {
                return false;
            }
            if (bc1.band[loop3].nrCaBandwidthClassDL != bc2.band[loop3].nrCaBandwidthClassDL)
            {
                return false;
            }
        }

        return true;
    };

    auto fnCheckCaBandwidthClassUL = [&](BandCombination_type bc1, BandCombination_type bc2) -> bool
    {
        uint8_t bc1BandwidthClassDL = CA_BandwidthClassNR_NOT_SET;
        uint16_t bc1FreqBandInd = 0;

        for (loop3 = 0; loop3 < UMIN(bc1.num, MAX_BANDS_PER_COMB); ++loop3)
        {
            if (bc1.band[loop3].nrCaBandwidthClassUL != CA_BandwidthClassNR_NOT_SET)
            {
                bc1BandwidthClassDL = bc1.band[loop3].nrCaBandwidthClassDL;
                bc1FreqBandInd = bc1.band[loop3].freqBandIndicator;
            }
        }

        if (loop3 >= MAX_BANDS_PER_COMB)
        {
            return false;
        }

        for (loop3 = 0; loop3 < UMIN(bc2.num, MAX_BANDS_PER_COMB); ++loop3)
        {
            if (bc2.band[loop3].nrCaBandwidthClassDL == bc1BandwidthClassDL &&
                    bc2.band[loop3].freqBandIndicator == bc1FreqBandInd)
            {
                if (bc1.band[loop3].nrCaBandwidthClassUL != CA_BandwidthClassNR_NOT_SET)
                {
                    return true;
                }
            }
        }

        return false;
    };


    // 2. Compare rSourceBcList and rTargetBc
    uint32_t bestBw = 0;
    for (auto bcIdxBwSet : bcBwMaxIdxDq)
    {
        VCCB_CHECK_E_RANGE_AND_CONTINUE(bcIdxBwSet.first, MAX_BAND_COMBS);
        BandCombination_type sCellBc = rSourceBcList.bandCombination[bcIdxBwSet.first];

        if (sCellBc.num == mnBc.num)
        {
            if (fnCheckSameBandCombination(sCellBc, mnBc))
            {
                if (fnCheckCaBandwidthClassUL(sCellBc, mnBc))
                {
                    bestBw = bcIdxBwSet.second;
                    if (bestBw != 0)
                    {
                        if (bcIdxBwSet.first == 0)
                        {
                            isIncludedAllScell = true;
                        }
                        break;
                    }
                }
            }
        }
    }

    if (bestBw != 0)
    {
        return bestBw;
    }

    // 3. If rTargetBc is not mapping pSourceBcList, Make Subset of mnBc and Compare with rSourceBcList
    bandCombinationList_type subsetBc;
    memset(&subsetBc, 0, sizeof(subsetBc));
    VLIB_PermutateEachBcWithFallbackGroup(mnBc, subsetBc);

    if (subsetBc.num == 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[ALLOWEDFILTER] bc permutation Fail in %s\n", __FUNCTION__);
        return bestBw;
    }

    if (DBG->flag.logAllowedBcMnFilter)
    {
        bcIdxArray_type arrayIdx;
        for (loop = 0; loop < subsetBc.num; ++loop)
        {
            arrayIdx.push_back(static_cast<uint32_t>(loop));
        }

        const bandCombinationList_type tempSubset = subsetBc;
        VLIB_BandCombFromBcIndexesPrint(ptCi, &tempSubset, arrayIdx);
    }

    for (auto bcIdxBwSet : bcBwMaxIdxDq)
    {
        VCCB_CHECK_E_RANGE_AND_CONTINUE(bcIdxBwSet.first, MAX_BAND_COMBS);
        BandCombination_type sCellBc = rSourceBcList.bandCombination[bcIdxBwSet.first];

        for (loop2 = 0; loop2 < MIN(subsetBc.num, MAX_BAND_COMBS); ++loop2)
        {
            BandCombination_type allowedBc = subsetBc.bandCombination[loop2];

            if (fnCheckSameBandCombination(sCellBc, allowedBc))
            {
                if (fnCheckCaBandwidthClassUL(sCellBc, allowedBc))
                {
                    bestBw = bcIdxBwSet.second;
                    if (bestBw != 0)
                    {
                        if (bcIdxBwSet.first == 0)
                        {
                            isIncludedAllScell = true;
                        }
                    }

                    return bestBw;
                }
            }
        }
    }

    return bestBw;
}

void VLIB_makeFilteredAllowedBcList(callInfo_type *ptCi, allowedFilteredBcMap_type &bcMap)
{
    AUTO_TRACE_FUNC;
    bcMap.clear();
    VALID_E_POINT_CHECK_VOID(ptCi);

    // 1. Get all allowedBc_List and SupportedBandCombination of UE Capability
    bandCombinationInfoList_type *ptAllowedBc = &ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC;
    const bandCombinationList_type *ptUeBandCombList = VRIL_GetBandCombinationList(ptCi);
    VALID_E_POINT_CHECK_VOID(ptUeBandCombList);

    int loop = 0, loop2 = 0;
    BandCombination_type scellSupersetBc;
    mcoBand2mcoCcInfoVecMap_type ccInfoVecPerBand;

    // 2.  Make Contiguous Cell Group of current Scell
    VLIB_MakeBandCombinationOfCurrentScell(ptCi, scellSupersetBc, ccInfoVecPerBand);

    if (ccInfoVecPerBand.empty() || scellSupersetBc.num == 0)
    {
        if (ccInfoVecPerBand.empty())
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[ALLOWEDFILTER] ccInfoVecPerBand is empty in %s!!\n", __FUNCTION__);
        }
        else
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[ALLOWEDFILTER] scellSupersetBc.num is 0 in %s!!\n", __FUNCTION__);
        }

        bcMap.clear();
        return;
    }

    // 3. Make Subset of current Scells
    bandCombinationList_type scellSubsetBc;
    memset(&scellSubsetBc, 0, sizeof(scellSubsetBc));

    VLIB_PermutateEachBcWithFallbackGroup(scellSupersetBc, scellSubsetBc);

    if (scellSubsetBc.num == 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[ALLOWEDFILTER] scellSubsetBc.num is 0 in %s!!\n", __FUNCTION__);
        return;
    }

    // 4. Print subset of current Scell
    if (DBG->flag.logAllowedBcMnFilter)
    {
        bcIdxArray_type arrayIdx;
        for (loop = 0; loop < scellSubsetBc.num; ++loop)
        {
            arrayIdx.push_back(static_cast<uint32_t>(loop));
        }

        const bandCombinationList_type printSubset = scellSubsetBc;
        VLIB_BandCombFromBcIndexesPrint(ptCi, &printSubset, arrayIdx);
    }

    // 5. Calculate maxBw each subset of current Scell
    totalBwPerBc_type bcBwMaxIdxDq;
    bcBwMaxIdxDq.clear();

    FnVCCB_CalculateBwForBcList(ptCi, scellSubsetBc, ccInfoVecPerBand, bcBwMaxIdxDq);

    if (bcBwMaxIdxDq.empty())
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[ALLOWEDFILTER] bcBwMaxIdxDq is empty in %s!!\n", __FUNCTION__);
        return;
    }

    // 6. Make SN Group as same FR2 combination and Calculate Bw each allowedBc_List
    for (loop = 0; loop < MIN(ptAllowedBc->nrofBandComb, MAX_NUM_BAND_COMB); ++loop)
    {
        uint32_t bcIdx = ptAllowedBc->bandCombinationInfo[loop].bandCombinationIndex - 1U;
        VCCB_CHECK_E_RANGE_AND_CONTINUE(bcIdx, MAX_BAND_COMBS);

        band2bwcMultisetMap_type snBand2bwcMap; // key: band Indicator, value: all bwc's set of key

        // 6-1. Make key by SN band indicator & BWC
        for (loop2 = 0; loop2 < MIN(ptUeBandCombList->bandCombination[bcIdx].num, MAX_BANDS_PER_COMB); ++loop2)
        {
            const BandParameters_type *ptBandParam = &ptUeBandCombList->bandCombination[bcIdx].band[loop2];

            if (ptBandParam->freqBandIndicator > MAX_FR1_NR_BAND)   // FR2 band for SN
            {
                snBand2bwcMap[ptBandParam->freqBandIndicator].insert(std::make_pair(ptBandParam->nrCaBandwidthClassDL, ptBandParam->nrCaBandwidthClassUL));
            }
        }

        // 6-2. Check if SN group of current BC is exist in bcMap
        auto it = bcMap.find(snBand2bwcMap);

        if (it == bcMap.end()) // 3-3. If not exist, add new SN group
        {
            bcMap[snBand2bwcMap].allowedBcIdx   = static_cast<uint16_t>(loop);
            bcMap[snBand2bwcMap].bestBwDl       = VLIB_GetCurrentScellBwDlEachAllowedBc(ptCi, scellSubsetBc, ptUeBandCombList->bandCombination[bcIdx], bcBwMaxIdxDq, bcMap[snBand2bwcMap].isIncludedAllScell);
            VCCB_PRINT_LOG_ALLOWED_BC_MN_FILTER(ptCi, "[ALLOWEDFILTER] BcIdx::%d, bw::%d\n", bcIdx, bcMap[snBand2bwcMap].bestBwDl);
        }
        else // 6-3. If exist, compare BwDl of current BC and bestBwDl
        {
            if (bcMap[snBand2bwcMap].isIncludedAllScell == false)
            {
                bool isIncludedAllScellFlag = false;
                uint32_t currentBwDl = VLIB_GetCurrentScellBwDlEachAllowedBc(ptCi, scellSubsetBc, ptUeBandCombList->bandCombination[bcIdx], bcBwMaxIdxDq, isIncludedAllScellFlag);

                VCCB_PRINT_LOG_ALLOWED_BC_MN_FILTER(ptCi, "[ALLOWEDFILTER] BcIdx::%d, bw::%d\n", bcIdx, bcMap[snBand2bwcMap].bestBwDl);
                if(currentBwDl > bcMap[snBand2bwcMap].bestBwDl)
                {
                    bcMap[snBand2bwcMap].allowedBcIdx   = static_cast<uint16_t>(loop);
                    bcMap[snBand2bwcMap].bestBwDl       = currentBwDl;
                    bcMap[snBand2bwcMap].isIncludedAllScell = isIncludedAllScellFlag;
                }
            }
            else
            {
                VCCB_PRINT_LOG_ALLOWED_BC_MN_FILTER(ptCi, "[ALLOWEDFILTER] BcIdx::%d, skip\n", bcIdx);
            }
        }
    }
}

/**
 * @brief   Check if TSM information and receivedTime of mrCell are valid.
 * 
 * @param   ptCi : callInfo
 *          mrCell : mrCell to check if it is valid.
 */
bool FnVCCB_ValidateMrCellInfo(callInfo_type *ptCi, mrCellInfo_type mrCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, false);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (mrCell.state == mrCellState_Disable)
    {
        VCCB_PRINT_LOG_CA_TSM(ptCi, "[SE Value] Cell(%u)'s tsmState is not valid in %s\n", mrCell.cellIdentity, __FUNCTION__);
        return false;
    }

    if (mrCell.seValue > F1_MAX_SE_VALUE)
    {
        VCCB_PRINT_LOG_CA_TSM(ptCi, "[SE Value] Cell(%u)'s seValue(%u) is not valid in %s\n", mrCell.cellIdentity, mrCell.seValue, __FUNCTION__);
        return false;
    }

    long maxGathering_ms = static_cast<long>(MAX(pGnb->multiCarrierOperation.mrGatheringTimer, pGnb->multiCarrierOperation.sccMrGatheringTimer));

    struct timespec limitTime;
    limitTime.tv_sec = static_cast<time_t>(maxGathering_ms / 1000L);
    limitTime.tv_nsec = (maxGathering_ms % 1000L) * 1000000L;

    struct timespec currTime;
    if (ComTimeUtil::get_current_time(currTime) < 0)
    {
        VCCB_PRINT_ERROR("ComTimeUtil::get_current_time ERROR in %s\n", __FUNCTION__);
        return false;
    }
    struct timespec diffTime = ComTimeUtil::get_elapsed_time(currTime, mrCell.receivedTime);

    if (diffTime.tv_sec < limitTime.tv_sec)
    {
        return true;
    }
    else if (diffTime.tv_sec == limitTime.tv_sec)
    {
        if (diffTime.tv_nsec <= limitTime.tv_nsec)
        {
            return true;
        }
    }

    VCCB_PRINT_LOG_CA_TSM(ptCi, "[SE Value] Cell(%u)'s reveivedTime(maxTime::%lu) is not valid in %s\n", mrCell.cellIdentity, maxGathering_ms, __FUNCTION__);
    return false;
}

/**
 * @brief   Check if cgi is valid in mrCellInfo and get mrCellIdx of cgi.
 * 
 * @param   ptCi : callInfo
 *          cgi : cgi to get mrCellIdx
 */
uint8_t FnVCCB_GetMrCellInfoIdx(callInfo_type *ptCi, const cgi_type cgi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_TSM_MR_CELL);
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, MAX_TSM_MR_CELL);

    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    uint16_t cellIdentity = VLIB_NrCellId2CellId(pGnb->globalGnbId.gnbId.idLength, cgi.ci);
    uint8_t mIdx = 0;

    for (mIdx = 0; mIdx < MAX_TSM_MR_CELL; ++mIdx)
    {
        auto &mrCell = ptCi->mrCellInfo[mIdx];
        if (mrCell.state == mrCellState_Enable)
        {
            if (mrCell.cellIdentity == cellIdentity)
            {
                return mIdx;
            }
        }
    }

    return MAX_TSM_MR_CELL;
}

/**
 * @brief   Check if PCell is valid in mrCellInfo.
 * 
 * @param   ptCi : callInfo
 */
bool FnVCCB_ValidatePcellInMrCellInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    cellSelection_type cellSelection = FnVCCB_GetCellSelectionForConfig(ptCi);
    uint16_t spCellNum = cellSelection.cellNum;
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(spCellNum, false);

    VccbCellInfo_type *const ptCell = &CELLINFO[spCellNum];
    const trafficSteeringConfig_type &config = ptCell->tsmConfig;

    if (config.state != tsmState_Enable)
    {
        VCCB_PRINT_LOG_CA_TSM(ptCi, "[SE Value] PCell's tsmState is not valid.\n");
        return false;
    }

    uint8_t mIdx = FnVCCB_GetMrCellInfoIdx(ptCi, ptCi->nRCGI);
    if (mIdx >= MAX_TSM_MR_CELL)
    {
        VCCB_PRINT_LOG_CA_TSM(ptCi, "[SE Value] PCell is not registered in MrCellInfo.\n");
        return false;
    }

    if (not FnVCCB_ValidateMrCellInfo(ptCi, ptCi->mrCellInfo[mIdx]))
    {
        VCCB_PRINT_LOG_CA_TSM(ptCi, "[SE Value] PCell is not valid in MrCellInfo.\n");
        return false;
    }

    return true;
}

/**
 * @brief   Check if sCells are valid in mrCellInfo.
 * 
 * @param   ptCi : callInfo
 */
bool FnVCCB_ValidateScellInMrCellInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    auto scellSetupOngoing = [](const scellInfo_type &rSCell)
    {
        return (rSCell.state == SCELL_STATE_ADDED) &&
            ((rSCell.action == SCELL_ACTION_SETUP) ||
            (rSCell.action == SCELL_ACTION_RESETUP) ||
            (rSCell.action == SCELL_ACTION_SETUP_RELEASE));
    };

    uint8_t setupScellCount = 0;
    for (auto const &rSCell : ptCi->sCell)
    {
        if (scellSetupOngoing(rSCell))
        {
            uint32_t gnbId = VLIB_NrCellId2GnbId(rSCell.gnbIdLength, rSCell.cgi.ci);
            if (not VCCB_IS_SAME_GNB(gnbId, rSCell.cgi.plmn.longId, ptCi->gnbNum))
            {
                VCCB_PRINT_LOG_CA_TSM(ptCi, "[SE Value] SCell(%llu) is Inter gNB Cell.\n", 1ULL * rSCell.cgi.ci);
                return false;
            }

            uint8_t mIdx = FnVCCB_GetMrCellInfoIdx(ptCi, rSCell.cgi);
            if (mIdx >= MAX_TSM_MR_CELL)
            {
                VCCB_PRINT_LOG_CA_TSM(ptCi, "[SE Value] SCell(%llu) is not registered in MrCellInfo.\n", 1ULL * rSCell.cgi.ci);
                return false;
            }

            if (not FnVCCB_ValidateMrCellInfo(ptCi, ptCi->mrCellInfo[mIdx]))
            {
                VCCB_PRINT_LOG_CA_TSM(ptCi, "[SE Value] SCell(%llu) is not valid in MrCellInfo.\n", 1ULL * rSCell.cgi.ci);
                return false;
            }

            setupScellCount++;
        }
    }

    VCCB_PRINT_LOG_CA_TSM(ptCi, "[SE Value] Setup ongoing SCell is %d.\n", setupScellCount);
    return (setupScellCount == 0) ? false : true;
}

/**
 * @brief   Check if servingCells are valid in mrCellInfo.
 * 
 * @param   ptCi : callInfo
 */
bool FnVCCB_ValidateServingCellInMrCellInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (not FnVCCB_ValidatePcellInMrCellInfo(ptCi))
    {
        return false;
    }

    if (not FnVCCB_ValidateScellInMrCellInfo(ptCi))
    {
        return false;
    }

    return true;
}

/**
 * @brief   Check if seValue has to be transmitted through F1 Message.
 * 
 * @param   ptCi : callInfo
 */
bool FnVCCB_NeedToSendForSeValue(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, false);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    // FGR-RC0100 FR560

    if (not pGnb->carrierAggregationInfo.f1SeUsage)
    {
        VCCB_PRINT_LOG_CA_TSM(ptCi, "[SE Value] f1SeUsage is off in %s.\n", __FUNCTION__);
        return false;
    }

    if (not pGnb->multiCarrierOperation.capabilityAwareCarrierChange && not pGnb->multiCarrierOperation.sccChange)
    {
        VCCB_PRINT_LOG_CA_TSM(ptCi, "[SE Value] PCC(%d) or SCC(%d) is not set in %s.\n", pGnb->multiCarrierOperation.capabilityAwareCarrierChange, pGnb->multiCarrierOperation.sccChange, __FUNCTION__);
        return false;
    }

    if (ptCi->callType == E_CALLTYPE_NSA || IS_NRDC_SN(ptCi))
    {
        VCCB_PRINT_LOG_CA_TSM(ptCi, "[SE Value] NSA or SN Call in %s.\n", __FUNCTION__);
        return false;
    }

    if (not FnVCCB_ValidateServingCellInMrCellInfo(ptCi))
    {
        return false;
    }

    VCCB_PRINT_LOG_CA_TSM(ptCi, "[SE Value] needToSendForSeValue is set to true.\n");
    return true;
}

/**
 * @brief   Check if cgi is in mrCellInfo and get seValue.
 * 
 * @param   ptCi : callInfo
 *          cgi : cgi to check if it is in mrCellInfo.
 */
uint32_t FnVCCB_GetSeValueInMrCellInfo(callInfo_type *ptCi, const cgi_type cgi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, F1_EXCLUDE_SE_VALUE);

    if (ptCi->bitFlag.needToSendForSeValue)
    {
        uint8_t mIdx = FnVCCB_GetMrCellInfoIdx(ptCi, cgi);
        if (mIdx < MAX_TSM_MR_CELL)
        {
            if(ptCi->mrCellInfo[mIdx].seValue <= F1_MAX_SE_VALUE)
            {
                VCCB_PRINT_LOG_CA_TSM(ptCi, "[SE Value] Cell(%llu)'s seValue is %u.\n", 1ULL * cgi.ci, ptCi->mrCellInfo[mIdx].seValue);
                return ptCi->mrCellInfo[mIdx].seValue;
            }
            VCCB_PRINT_LOG_CA_TSM(ptCi, "[SE Value] Cell(%llu)'s seValue is not valid in MrCellInfo.\n", 1ULL * cgi.ci);
        }
        else
        {
            VCCB_PRINT_LOG_CA_TSM(ptCi, "[SE Value] Cell(%llu) is not registered in MrCellInfo.\n", 1ULL * cgi.ci);
        }
    }

    return F1_EXCLUDE_SE_VALUE;
}

/**
 * @brief   Check it current state is Intra gNB HO due to PCC Change.
 * 
 * @param   ptCi : callInfo
 *          targetrSsbArfcn : arfcn of the sCell to check if it is in fmPccChosenCcs.
 *          targetrPci : pci of the sCell to check if it is in fmPccChosenCcs.
 */
bool FnVCCB_IsPccHoOngoing(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    switch (ptCi->stateCmd)
    {
        case IntraRatHO_cmd:
        case IntraCellHO_cmd:
            {
                if (ptCi->hoInfo.hoType.rat == HO_TYPE_INTRA_RAT && ptCi->hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
                {
                    if (ptCi->hoInfo.pccChangeHoFlag)
                    {
                        return true;
                    }
                }
            }
        default:
            break;
    }

    return false;
}

/**
 * @brief   Check if sCell was serving cell before Pcell Change.
 * 
 * @param   ptCi : callInfo
 *          sourcePcellCgi : source Pcell cgi
 *          sCellCgi : sCell Cgi to check with serving cells of source Pcell
 */
bool FnVccb_IsServingCellBeforePcellChange(callInfo_type *ptCi, cgi_type sourcePcellCgi, cgi_type sCellCgi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (sourcePcellCgi.ci == sCellCgi.ci && sourcePcellCgi.plmn.longId == sCellCgi.plmn.longId)
    {
        return true;
    }

    for (auto &rSourceScell : ptCi->sCellDuConfig)
    {
        if (rSourceScell.state == SCELL_STATE_ADDED)
        {
            if (rSourceScell.cgi.ci == sCellCgi.ci && rSourceScell.cgi.plmn.longId == sCellCgi.plmn.longId)
            {
                return true;
            }
        }
    }

    return false;
}

/**
 * @brief   Check if sCell is in fmPccChosenCcs.
 * 
 * @param   ptCi : callInfo
 *          targetrSsbArfcn : arfcn of the sCell to check if it is in fmPccChosenCcs.
 *          targetrPci : pci of the sCell to check if it is in fmPccChosenCcs.
 */
bool FnVCCB_ValidateScellInFmInfo(callInfo_type *ptCi, uint32_t targetrSsbArfcn, uint16_t targetPci)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    for (auto &rFmPccCc : ptCi->pccData.fmPccChosenCcs)
    {
        if (rFmPccCc.arfcn == targetrSsbArfcn)
        {
            for (auto &rMrCellPci : rFmPccCc.measuredCellPcis)
            {
                if (rMrCellPci == targetPci)
                {
                    return true;
                }
            }

            VCCB_PRINT_LOG_CA_TSM(ptCi, "[PCC HO] SCell's arfcn/pci(%u/%d) is not in fmPccChosenCcs.\n", targetrSsbArfcn, targetPci);
            return false;
        }
    }

    VCCB_PRINT_LOG_CA_TSM(ptCi, "[PCC HO] SCell's arfcn(%u) is not in fmPccChosenCcs.\n", targetrSsbArfcn);
    return false;
}

/**
 * @brief   Exclude sCell according to FM PCC Change Function
 * 
 * @param   ptCi : callInfo
 */
void FnVCCB_ExcludeScellNotInFmPcc(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    // FGR-RC0100 FR560

    if(ptCi->caInfo.mode != CaOperation_Mode2 && ptCi->caInfo.mode != CaOperation_Mode5)
    {
        VCCB_PRINT_LOG_CA_TSM(ptCi, "[PCC HO] Stop excluding SCell. CA Operation Mode%d.\n", ptCi->caInfo.mode);
        return;
    }

    if (IS_MRDC(ptCi))
    {
        VCCB_PRINT_LOG_CA_TSM(ptCi, "[PCC HO] Stop excluding SCell. MRDC Call.\n");
        return;
    }

    if (not pGnb->multiCarrierOperation.fullMeasureBasedPccChange)
    {
        VCCB_PRINT_LOG_CA_TSM(ptCi, "[PCC HO] Stop excluding SCell. FullMeasPcc is off.\n");
        return;
    }

    if (not FnVCCB_IsPccHoOngoing(ptCi))
    {
        VCCB_PRINT_LOG_CA_TSM(ptCi, "[PCC HO] Stop excluding SCell. Not Intra gNB PCC HO.\n");
        return;
    }

    // get source Pcell cgi
    cgi_type sourcePcellCgi = FnVCCB_GetNrcgiFromCellNum(ptCi->servCellNum);

    uint8_t noOfExcludeScell = 0;
    for (auto &rScell : ptCi->sCell)
    {
        if (rScell.state == SCELL_STATE_ADDED)
        {
            if (FnVccb_IsServingCellBeforePcellChange(ptCi, sourcePcellCgi, rScell.cgi))
            {
                VCCB_PRINT_LOG_CA_TSM(ptCi, "[PCC HO] Not exclude SCell. This is serving cell of source cell. arfcn/pci(%u/%d).\n", rScell.ssbArfcn, rScell.pci);
                continue;
            }

            if (not FnVCCB_ValidateScellInFmInfo(ptCi, rScell.ssbArfcn, rScell.pci))
            {
                rScell.state = SCELL_STATE_MRREL;
                rScell.action = SCELL_ACTION_KEEP;

                VCCB_PRINT_LOG_CA_TSM(ptCi, "[PCC HO] Success exclude SCell. arfcn/pci/action(%u/%d/%d).\n", rScell.ssbArfcn, rScell.pci, rScell.action);
                noOfExcludeScell++;
            }
            else
            {
                VCCB_PRINT_LOG_CA_TSM(ptCi, "[PCC HO] Not exclude SCell. arfcn/pci(%u/%d).\n", rScell.ssbArfcn, rScell.pci);
            }
        }
    }

    if (ptCi->caInfo.mode == CaOperation_Mode2 && noOfExcludeScell)
    {
        // To Configure SCell Addition A4
        VCCB_PRINT_LOG_CA_TSM(ptCi, "[PCC HO] Success Exclude SCell(noOfCell%d). mode2AnyScellReleased set to TRUE in Mode2.\n", noOfExcludeScell);
        ptCi->caInfo.mode2AnyScellReleased = TRUE;
    }
    else
    {
        VCCB_PRINT_LOG_CA_TSM(ptCi, "[PCC HO] Success Exclude SCell(noOfCell::%d).\n", noOfExcludeScell);
    }
}

/**
 * @brief Function marks scells released after Ltm cell switch and increase counter.
 *
 * @param   rCi : callInfo
 */
void FnVCCB_ClearScellsAfterLtmCellSwitch(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    for (uint8_t scellIdx = 0; scellIdx < MAX_SCELL_PER_CALL; ++scellIdx)
    {
        if ((SCELL_STATE_ADDED == rCi.sCellDuConfig[scellIdx].state) &&
            (SCELL_ACTION_SETUP != rCi.sCellDuConfig[scellIdx].action))
        {
            // if was existing scell set state SCELL_STATE_LTMREL and increase counter
            rCi.sCell[scellIdx].state = SCELL_STATE_LTMREL;
            rCi.sCellDuConfig[scellIdx].state = SCELL_STATE_LTMREL;

            MACRO_STAT_PMCC(STAT_CA_SCELL_ADD_REL, CaSCellRelbyLtm_CellSwitch, &rCi, rCi.sCellDuConfig[scellIdx].cgi.ci, rCi.servCellNum, 0, 0, 0);
        }
        else
        {
            // otherwise set not used (SCELL_STATE_RELEASED, SCELL_ACTION_KEEP)
            rCi.sCell[scellIdx].state = SCELL_STATE_RELEASED;
            rCi.sCellDuConfig[scellIdx].state = SCELL_STATE_RELEASED;
        }
        rCi.sCell[scellIdx].action = SCELL_ACTION_KEEP;
        rCi.sCellDuConfig[scellIdx].action = SCELL_ACTION_KEEP;
    }
}

bool FnVCCM_AnySCellIsDuringAdditionAfterA4(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);

    return std::any_of(std::begin(scells), std::end(scells),
        [](const scellInfo_type &scell)
        { return (SCELL_ACTION_SETUP == scell.action) &&
                 (CaSCellAddAtt_EventA4 == scell.addRelCause) &&
                 (FALSE == scell.isActionQueued); });
}
