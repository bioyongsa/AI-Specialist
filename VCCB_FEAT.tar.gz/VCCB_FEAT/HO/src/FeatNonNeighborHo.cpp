/**
 * @file        FeatNonNeighborHo.cpp
 * @brief       This function provides a function for controlling the operation of the Mobility Feature for the SA UE.
 */

#include "FeatNonNeighborHo.h"
#include "FeatConditionalHo.h"
#include "FeatCommon.h"
#include "FeatCallInfo.h"
#include "FeatCallProc.h"
#include "FeatMeasurements.hpp"
#include "FeatMeasurementsNRRRCMake.hpp"
#include "FeatHo.h"
#include "FeatSon.h"
#include "FeatCallProc.h"
#include "FeatMrl.h"

#include "ComCppWrapper.h"
#include "ComInclude.h"
#include "ComLibUtility.h"
#include "ComTimeUtil.h"

#include "StateCommon.h"
#include "StateSaHo.h"
#include "VccbStruct.h"

// SM_CELL_HO_23B
void FnVCCB_InitSmallCellPciConfig(uint16_t gnbNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
    VccbEutraSmallCellPciList_type *pGnbPciList = NULL;

    for (uint8_t idx = 0; idx < MAX_EUTRA_SMALLCELL_PCI_ENTRIES; idx++)
    {
        pGnbPciList = &pGnb->eutraSmallCellPciList[idx];

        pGnbPciList->usage = CI_no_use;
        for (uint8_t index = 0; index < MAX_EUTRA_SMALLCELL_PCI_RANGE_ENTRIES; index++)
        {
            VccbEutraSmallCellPciRange_type *pRangeList = &pGnbPciList->pciRange[index];
            pRangeList->usage = CI_no_use;
        }
    }
}

// SM_CELL_HO_23B
int16_t FnVCCB_IsValidSmallCellConfigEutraMo(uint16_t gnbNum, int8_t smallCellPciListIndex)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);

    if (smallCellPciListIndex < 0 || smallCellPciListIndex >= MAX_EUTRA_SMALLCELL_PCI_ENTRIES) return ERROR;

    VccbGnbInfo_type *pGnb = &GNBINFO[gnbNum];
    VccbEutraSmallCellPciList_type *ptScPciList = &pGnb->eutraSmallCellPciList[smallCellPciListIndex];

    if (pGnb->cfg.gnbMobilityConfig.registerEutraSmallCellAsNeighbor == true) return ERROR;

    if (ptScPciList->usage != CI_use) return ERROR;

    for (uint16_t idx = 0; idx < MAX_EUTRA_SMALLCELL_PCI_RANGE_ENTRIES; idx++)
    {
        if (ptScPciList->pciRange[idx].usage == CI_use)
        {
            return GOOD;
        }
    }
    return ERROR;
}

// SM_CELL_HO_24A
int16_t FnVCCB_IsValidSmallCellConfigNrMo(uint16_t gnbNum, int8_t smallCellPciListIndex)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);

    if (smallCellPciListIndex < 0 || smallCellPciListIndex >= MAX_NR_SMALLCELL_PCI_ENTRIES) return ERROR;

    VccbGnbInfo_type *pGnb = &GNBINFO[gnbNum];
    VccbNrSmallCellPciList_type *ptScPciList = &pGnb->nrSmallCellPciList[smallCellPciListIndex];

    if (pGnb->cfg.gnbMobilityConfig.registerNrSmallCellAsNeighbor == true) return ERROR;

    if (ptScPciList->usage != CI_use) return ERROR;

    for (uint16_t idx = 0; idx < MAX_NR_SMALLCELL_PCI_RANGE_ENTRIES; idx++)
    {
        if (ptScPciList->pciRange[idx].usage == CI_use)
        {
            return GOOD;
        }
    }

    return ERROR;
}

// SM_CELL_HO_24A
bool FnVCCB_CheckPciInNrSmallCellList(uint16_t pci, uint8_t gnbNum, int16_t smallCellIdx)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, false);
    VccbGnbInfo_type *pGnb = &GNBINFO[gnbNum];

    if(smallCellIdx < 0 || smallCellIdx >= MAX_NR_SMALLCELL_PCI_ENTRIES) return false;

    VccbNrSmallCellPciList_type *smallCellPciList = &pGnb->nrSmallCellPciList[smallCellIdx];

    if (CI_no_use == smallCellPciList->usage)
    {
        return false;
    }

    for (uint16_t i = 0; i < MAX_NR_SMALLCELL_PCI_RANGE_ENTRIES; i++)
    {
        if (CI_no_use == smallCellPciList->pciRange[i].usage) continue;
        if (smallCellPciList->pciRange[i].pciStart <= pci && pci <= smallCellPciList->pciRange[i].pciEnd)
        {
            return true;
        }
    }

    return false;
}


/**
 * @brief     Check whether PCI is Eutra Small Cell PCI.
 * @param     ptCi : Call context
 * @param     pci : Physical cell identity
 * @param     SmallCellPciListIndex : Index of SmallCell Pci List
 * @return    true : smallcell PCI
 * @return    false : no smallcell PCI
 */
// SM_CELL_HO_23B
bool FnVCCB_IsEutraSmallCellPci(callInfo_type *ptCi, uint16_t pci, int8_t SmallCellPciListIndex)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);
    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];

    /* Check yang */
    if (pGnb->cfg.gnbMobilityConfig.registerEutraSmallCellAsNeighbor == true) return false;

    /* Range check about SmallCellPciListIndex. */
    if ((SmallCellPciListIndex < 0) || (MAX_EUTRA_SMALLCELL_PCI_ENTRIES <= SmallCellPciListIndex))
    {
        return false;
    }

    VccbEutraSmallCellPciList_type *smallCellPciList = &pGnb->eutraSmallCellPciList[SmallCellPciListIndex];
    if (CI_no_use == smallCellPciList->usage)
    {
        return false;
    }

    for (uint16_t i = 0; i < MAX_EUTRA_SMALLCELL_PCI_RANGE_ENTRIES; i++)
    {
        if (CI_no_use == smallCellPciList->pciRange[i].usage) continue;
        if (smallCellPciList->pciRange[i].pciStart <= pci && pci <= smallCellPciList->pciRange[i].pciEnd)
        {
            VCCB_PRINT_CALL_NON_NBR_HO(ptCi, "(NNBR) pci(%d) is Eutra Small Cell PCI. (index:%u) \n", pci, i);
            return true;
        }
    }

    return false;
}

// SM_CELL_HO_24A
bool FnVCCB_IsNrSmallCellPci(callInfo_type *ptCi, uint16_t pci, int8_t SmallCellPciListIndex)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);

    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];
    
    /* Check yang */
    if (pGnb->cfg.gnbMobilityConfig.registerNrSmallCellAsNeighbor == true) return false;

    /* Range check about SmallCellPciListIndex. */
    if ((SmallCellPciListIndex < 0) || (MAX_NR_SMALLCELL_PCI_ENTRIES <= SmallCellPciListIndex))
    {
        //VCCB_PRINT_CALL_NON_NBR_HO(
        //    ptCi, "(NNBR) pci(%d): SmallCellPciListIndex(%d) is out of range.\n", pci, SmallCellPciListIndex);
        return false;
    }

    return FnVCCB_CheckPciInNrSmallCellList(pci, (uint8_t)ptCi->gnbNum, SmallCellPciListIndex);
}

bool isValidGnbIdLength(uint16_t gnbIdLength)
{
    AUTO_TRACE_FUNC;

    if (22 <= gnbIdLength && 32 >= gnbIdLength) return true;

    return false;
}

// SM_CELL_HO_24A
int FnVCCB_UpdateNonNeighborGnbIdLength(uint16_t gnbNum, uint16_t &gnbIdLength)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);

    /*
    1) If the gNB-ID-Length-r17 IE is received from the ReportCGI, the received value is determined as the target gNB ID
    length.
    */
    if (true == isValidGnbIdLength(gnbIdLength)) return GOOD;

    /*
    2) If it is not received,
    A. small-cell-pci-config/small-cell-gnb-id-length is set, the target gNB ID length is determined.
    B. If not configured, determine the serving gNB ID length as the target gNB ID length.
    */
    const VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    if (pGnb->cfg.gnbMobilityConfig.smallCellGnbIdLength >= 22 &&
        pGnb->cfg.gnbMobilityConfig.smallCellGnbIdLength <= 32)
        gnbIdLength = pGnb->cfg.gnbMobilityConfig.smallCellGnbIdLength;
    else
        gnbIdLength = pGnb->globalGnbId.gnbId.idLength;

    /* Check invalid value about gnbIdLength. */
    if (false == isValidGnbIdLength(gnbIdLength)) return ERROR;

    return GOOD;
}

// SM_CELL_HO_24A
uint64_t FnVCCB_GetEcgiForNonNeighborHandover(const nbrEnbCellInfo_type &nbrEnbCell, enumSmallCellEnbIdLength_type enbIdType)
{
    AUTO_TRACE_FUNC;

    if (nbrEnbCell.nonNeighbor == VCCB_FLAG_ON)
    {
        if (enbIdType == sc_Home_Enb_Id_Length) return nbrEnbCell.enbId;
    }

    return VCCB_GET_ECGI(nbrEnbCell.enbId, nbrEnbCell.cellId);
}

void SetNbrEnbCellInfoForNonNeighborHandover(
    callInfo_type *ptCi, nbrEnbCellInfo_type *nbrEnbCellInfo, anrCgiInfo anrCgi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(nbrEnbCellInfo);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint8_t scHomeEnbIdLength = 28;
    uint8_t scMacroEnbIdLength = 20;
    bool isHomeEnbIdLength = (scHomeEnbIdLength == pGnb->cfg.gnbMobilityConfig.smallCellEnbIdLength) ? true : false;
    uint8_t enbIdlength = (isHomeEnbIdLength) ? scHomeEnbIdLength : scMacroEnbIdLength;

    // Fill nbrEnbCellinfo
    nbrEnbCellInfo->status = EQUIP;
    nbrEnbCellInfo->nonNeighbor = VCCB_FLAG_ON;

    nbrEnbCellInfo->enbId = (anrCgi.cgi.ci >> (28 - enbIdlength)) & e_BitMask64_28bit;
    nbrEnbCellInfo->cellId = (isHomeEnbIdLength) ? 0 : (anrCgi.cgi.ci & e_BitMask64_8bit);
    nbrEnbCellInfo->pci = ptCi->reportCgiHoInfo.pci;
    nbrEnbCellInfo->earfcnDl = ptCi->reportCgiHoInfo.freq;
    nbrEnbCellInfo->tac = (uint16_t)anrCgi.tac;
    nbrEnbCellInfo->plmn.longId = anrCgi.plmn[0].longId;

    uint16_t plmn_size = MIN(anrCgi.numPlmn, MAX_NUM_PLMN_LTE);
    for (uint32_t plmn_idx = 0; plmn_idx < plmn_size; plmn_idx++)
    {
        nbrEnbCellInfo->cellPlmnInfo[plmn_idx].shmStatus = EQUIP;
        nbrEnbCellInfo->cellPlmnInfo[plmn_idx].plmnIndex = plmn_idx;
        nbrEnbCellInfo->cellPlmnInfo[plmn_idx].longId = anrCgi.plmn[plmn_idx].longId;
    }

    return;
}

void SetNbrGnbCellInfoForNonNeighborHandover(
    callInfo_type *ptCi, nbrGnbCellInfo_type *nbrGnbCellInfo, ncgiNotifyNr_type &ncgiNotifyNr, uint16_t gnbIdLength)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(nbrGnbCellInfo);

    uint64_t bit_masks = 0;
    anrCgiInfo anrCgi = ncgiNotifyNr.ncgi[0];

    // Fill nbrGnbCellInfo For NonNeighborHandover
    nbrGnbCellInfo->status = EQUIP;
    nbrGnbCellInfo->globalGnbId.gnbId.id = (uint32_t)(anrCgi.cgi.ci >> (36 - gnbIdLength));
    nbrGnbCellInfo->globalGnbId.gnbId.idLength = (uint8_t)gnbIdLength;
    nbrGnbCellInfo->globalGnbId.plmn.longId = anrCgi.plmn[0].longId;

    bit_masks |= ((uint64_t)1 << (36 - gnbIdLength + 1)) - 1;

    nbrGnbCellInfo->cellId = (uint16_t)(anrCgi.cgi.ci & bit_masks);

    nbrGnbCellInfo->nonNeighbor = VCCB_FLAG_ON;
    nbrGnbCellInfo->ssbArfcn = ptCi->reportCgiHoInfo.freq;
    nbrGnbCellInfo->nrPci = ptCi->reportCgiHoInfo.pci;

    nbrGnbCellInfo->fiveGsTacStatus = EQUIP;
    nbrGnbCellInfo->fiveGsTac = (uint32_t)anrCgi.tac;

    uint16_t plmn_size = MIN(anrCgi.numPlmn, MAX_PLMN_INDEX);
    uint8_t dbIndex = 0;
    for (uint32_t plmn_idx = 0; plmn_idx < plmn_size; plmn_idx++)
    {
        if (not GETBIT_U16(ncgiNotifyNr.saAvailability, plmn_idx)) continue;

        nbrGnbCellInfo->cellPlmnInfo[dbIndex].shmStatus = EQUIP;
        nbrGnbCellInfo->cellPlmnInfo[dbIndex].plmnIndex = plmn_idx;
        nbrGnbCellInfo->cellPlmnInfo[dbIndex].longId = anrCgi.plmn[plmn_idx].longId; 
        dbIndex++;
    }

    return;
}

// SM_CELL_HO_23B
int16_t VHCM_StartSaHandover_InterRat_ToNonNeighborCell(callInfo_type *ptCi, anrCgiInfo anrCgi, uint16_t cause, StartSaHandoverDb& hoInputDb)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    // This operation is a class operation for controlling the Ho-related database.
    HoDbConroller hoDbConroller(ptCi);

    nbrEnbCellInfo_type nbrEnbCellInfo;
    SetNbrEnbCellInfoForInit(&nbrEnbCellInfo);
    SetNbrEnbCellInfoForNonNeighborHandover(ptCi, &nbrEnbCellInfo, anrCgi);

    // FGR-MC1015 FR10.CACP.SR1.HD2.DD1, FR20.CACP.SR1.HD2.DD1
    candidateNbrInformation_type candidateNbr;

    uint16_t num_plmn = 0;
    for (auto plmn_idx = 0; plmn_idx < MIN(anrCgi.numPlmn, MAX_NUM_PLMN); plmn_idx++)
    {
        candidateNbr.nbrTaiInfo.plmnList.plmn[num_plmn].longId = anrCgi.plmn[num_plmn].longId;
        num_plmn++;
    }

    if (0 == num_plmn) 
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "%s empty ANR CGI PLMN! \n", __func__);
        return ERROR;
    }

    candidateNbr.nbrTaiInfo.plmnList.num_plmn = num_plmn;
    candidateNbr.nbrTaiInfo.tac = (uint32_t)anrCgi.tac;

    hoRestrictInfo_type *ptHrl = &THREAD_INFO->call[ptCi->myThreadId].buf.hoRestrictInfo;

    int status = VLIB_DecompressHoRestrictInfo(ptCi, ptHrl);
    VCCB_RETURN_ERROR_ON_CALL_NOT_GOOD(ptCi, status, "VLIB_DecompressHoRestrictInfo NOT GOOD!\n");

    status = VCCM_CheckAndUpdate_NbrPlmnValidation_EUTRA(ptCi, ptHrl, &candidateNbr);
    VCCB_RETURN_ERROR_ON_CALL_NOT_GOOD(ptCi, status, "VCCM_CheckAndUpdate_NbrPlmnValidation_EUTRA NOT GOOD!\n");

    status = VCOM_GetSelectedPLMN_FromAllowedPLMN(ptCi, &candidateNbr, fivegs_to_eps, &ptCi->hoInfo.selectedTAI);
    VCCB_RETURN_ERROR_ON_CALL_NOT_GOOD(ptCi, status, "VCOM_GetSelectedPLMN_FromAllowedPLMN NOT GOOD!\n");

    ptCi->hoInfo.nonNbrCell = TRUE;
    
    return VHCM_StartSaHandover_InterRAT_with_DB(ptCi, &nbrEnbCellInfo, cause, hoDbConroller, hoInputDb);
}

// SM_CELL_HO_24A
int16_t FnVCCB_StartSaHandover_IntergNB_ToNonNeighborCell(
    callInfo_type *ptCi, ncgiNotifyNr_type &ncgiNotifyNr, uint16_t cause, uint16_t gnbIdLength, StartSaHandoverDb& hoInputDb)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    // This operation is a class operation for controlling the Ho-related database.
    HoDbConroller hoDbConroller(ptCi);

    // Update gnbIdLength and check range.
    if (GOOD != FnVCCB_UpdateNonNeighborGnbIdLength(ptCi->gnbNum, gnbIdLength))
    {
        VCCB_PRINT_CALL_NON_NBR_HO(ptCi, "%s gnbIdLength is wrong! \n", __func__);
        return ERROR; 
    }

    nbrGnbCellInfo_type nbrGnbCellInfo;
    SetNbrGnbCellInfoForInit(&nbrGnbCellInfo);
    SetNbrGnbCellInfoForNonNeighborHandover(ptCi, &nbrGnbCellInfo, ncgiNotifyNr, gnbIdLength);

    // FGR-MC1015 FR10.CACP.SR1.HD2.DD1, FR20.CACP.SR1.HD2.DD1
    // update CandidateNbr
    candidateNbrInformation_type candidateNbr;
    candidateNbr.globalGnbId = nbrGnbCellInfo.globalGnbId;
    candidateNbr.nbrIdx = MAX_NBR_PER_CELL;

    anrCgiInfo anrCgi = ncgiNotifyNr.ncgi[0];

    uint16_t plmn_size = MIN(anrCgi.numPlmn, MAX_NUM_PLMN);
    uint8_t dbIndex = 0;
    for (auto plmn_idx = 0; plmn_idx < plmn_size; plmn_idx++)
    {
        if (not GETBIT_U16(ncgiNotifyNr.saAvailability, plmn_idx)) continue;

        candidateNbr.nbrTaiInfo.plmnList.plmn[dbIndex++].longId = anrCgi.plmn[plmn_idx].longId;
    }

    if (0 == plmn_size)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "%s empty ANR CGI PLMN! \n", __func__);
        return ERROR;
    }

    candidateNbr.nbrTaiInfo.plmnList.num_plmn = dbIndex;

    if (anrCgi.tac < 0) // NSA cell
    {
        return BREAK;
    }
    candidateNbr.nbrTaiInfo.tac = (uint32_t)anrCgi.tac;
    hoRestrictInfo_type *ptHrl = &THREAD_INFO->call[ptCi->myThreadId].buf.hoRestrictInfo;

    int status = VLIB_DecompressHoRestrictInfo(ptCi, ptHrl);
    VCCB_RETURN_ERROR_ON_CALL_NOT_GOOD(ptCi, status, "VLIB_DecompressHoRestrictInfo NOT GOOD!\n");

    status = VCCM_CheckAndUpdate_NbrPlmnValidation_NR(ptCi, ptHrl, &candidateNbr, e_HoTrigger_ImmediateHandover);
    if (status == HO_BREAK_SPECIFIC_SLICE) 
    {
        ptCi->specificSliceForcedHoInfo.forcedMobilityCgiReport = TRUE;
    }
    VCCB_RETURN_ERROR_ON_CALL_NOT_GOOD(ptCi, status, "VCCM_CheckAndUpdate_NbrPlmnValidation_NR NOT GOOD!\n");

    status = VCOM_GetSelectedPLMN_FromAllowedPLMN(ptCi, &candidateNbr, intra5gs, &ptCi->hoInfo.selectedTAI);
    VCCB_RETURN_ERROR_ON_CALL_NOT_GOOD(ptCi, status, "VCOM_GetSelectedPLMN_FromAllowedPLMN NOT GOOD!\n");

    ptCi->hoInfo.tgtNbrGnbCell = 0xFFFF;
    ptCi->hoInfo.nonNbrCell = TRUE;

    return VHCM_StartSaHandover_IntergNB_with_DB(ptCi, &nbrGnbCellInfo, cause, e_HoTrigger_ImmediateHandover, hoDbConroller, hoInputDb);
}

// SM_CELL_HO
bool FnVCCB_IsNonNeighborHoAllowedList(const reportConfigurationInstalledUe_type *pReportConfig)
{
    VALID_E_POINT_CHECK_RET_VAL(pReportConfig, false);

    const enumMeasurementReportType reportType = static_cast<enumMeasurementReportType>(pReportConfig->conf.reportType);
    const uint8_t reportPurpose = pReportConfig->conf.reportPurpose;

    switch (reportType)
    {
        case measReport_A3:
        {
            switch (reportPurpose)
            {
                case a3Purpose_intraNrHandover:
                    return true;
                default:
                    return false;
            }
        }
        break;
        case measReport_A4:
        {
            switch (reportPurpose)
            {
                case a4Purpose_intraNrHandover:
                case a4Purpose_PcellPriorHandover:
                    return true;
                default:
                    return false;
            }
        }
        break;
        case measReport_A5:
        {
            switch (reportPurpose)
            {
                case a5Purpose_intraNrHandover:
                case a5Purpose_intraNrOnDemandHandover:
                case a5Purpose_PcellPriorHandover:
                case a5Purpose_intraNrRfspHandover:
                case a5Purpose_intraNrDuTriggeredForcedHandover:
                case a5Purpose_forcedHandoverDueToBadUlQuality:
                case a5Purpose_forcedHandoverDueToTddInterference:
                case a5Purpose_forcedHandoverDueToLongRtpGap:
                    return true;
                default:
                    return false;
            }
        }
        break;
        case measReport_B1Eutra:
        {
            switch (reportPurpose)
            {
                case b1Purpose_eutraHandover:
                case b1Purpose_eutraRfspHandover:
                case b1Purpose_saPriortizationHandover:
                case b1Purpose_saEpsFallbackHandover:
                case b1Purpose_saEmergencyFallbackHandover:
                case b1Purpose_eutraForcedHandoverDueToUlPrbBlanking:
                case b1Purpose_eutraForcedHandoverDueToBadUlQuality:
                case b1Purpose_eutraForcedHandoverDueToTddInterference:
                case b1Purpose_eutraForcedHandoverDueToLongRtpGap:
                    return true;
                default:
                    return false;
            }
        }
        break;
        case measReport_B2Eutra:
        {
            switch (reportPurpose)
            {
                case b2Purpose_eutraHandover:
                case b2Purpose_eutraOnDemandHandover:
                case b2Purpose_saEpsFallbackHandover:
                case b2Purpose_saEmergencyFallbackHandover:
                    return true;
                default:
                    return false;
            }
        }
        break;
        default:
            break;
    }

    return false;
}

// SM_CELL_HO_24A
bool FnVCCB_GetRegisterSmallCellNbrOption(uint16_t gnbNum, int8_t ratType)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, false);
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    if (measRatEutra == ratType)
    {
        return pGnb->cfg.gnbMobilityConfig.registerEutraSmallCellAsNeighbor;
    }

    return pGnb->cfg.gnbMobilityConfig.registerNrSmallCellAsNeighbor;
}

// SM_CELL_HO
bool FnVCCB_IsNonNeighborHoSupported(callInfo_type *ptCi, measurementObjectUe_type *pMeasObj,
    const reportConfigurationInstalledUe_type *pReportConfig, uint8_t ratType)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pMeasObj, false);
    VALID_E_POINT_CHECK_RET_VAL(pReportConfig, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);

    if (CI_use != pMeasObj->usage) return false;

    // Check yang
    if (true == FnVCCB_GetRegisterSmallCellNbrOption(ptCi->gnbNum, pMeasObj->conf.ratType)) return false;

    // Allowed Report Config
    if (false == FnVCCB_IsNonNeighborHoAllowedList(pReportConfig))
    {
        VCCB_PRINT_CALL_NON_NBR_HO(ptCi, "(NNBR) not IsNonNeighborHoAllowedList (type:%u/purpose:%u) \n",
            pReportConfig->conf.reportType, pReportConfig->conf.reportPurpose);
        return false;
    }

    // Check smallCellPciListIndex in MO
    switch (pMeasObj->conf.ratType)
    {
        case measRatEutra:
        {
            if (ERROR == FnVCCB_IsValidSmallCellConfigEutraMo(
                             ptCi->gnbNum, pMeasObj->conf.rat.eutra.minimal.smallCellPciListIndex))
            {
                //VCCB_PRINT_CALL_NON_NBR_HO(ptCi, "(NNBR) measRatEutra: Invalid smallCellPciListIndex(%d)  \n",
                //    pMeasObj->conf.rat.eutra.minimal.smallCellPciListIndex);
                return false;
            }
            break;
        }
        case measRatNr:
        {
            if (ERROR ==
                FnVCCB_IsValidSmallCellConfigNrMo(ptCi->gnbNum, pMeasObj->conf.rat.nr.minimal.smallCellPciListIndex))
            {
                //VCCB_PRINT_CALL_NON_NBR_HO(ptCi, "(NNBR) measRatNr: Invalid smallCellPciListIndex(%d)  \n",
                //    pMeasObj->conf.rat.nr.minimal.smallCellPciListIndex);
                return false;
            }
            break;
        }
        default:
            return false;
    }

    // Check reportCgi Capa
    if (false == FnVCCB_IsSupportUeBasedReportCgiForMobility(ptCi, ratType))
    {
        VCCB_PRINT_CALL_NON_NBR_HO(ptCi, "(NNBR) No UeReportCgi Capa or Not Enabled Config. \n");
        return false;
    }

    return true;
}

// SM_CELL_HO_24A
static inline bool FnVCCB_IsEutraReportCgiHandoverTriggerCondition(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (VCCM_IsUeIdleState(ptCi->callType, ptCi->state)) return true;

    // 24B Condition (Fallback & (DUPL_PCI or SMCELL))
    if (STATE_Fallback_MeasReport == ptCi->state) return true;

    return false;
}

int16_t FnVCCB_TriggerEutraHandoverByReportCGI(callInfo_type *ptCi, bool cgiAcquired, anrCgiInfo reportedCGI)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (not IS_REPORT_CGI_FOR_HANDOVER(ptCi)) return ERROR;

    if (true != FnVCCB_IsEutraReportCgiHandoverTriggerCondition(ptCi))
    {
        VCCB_PRINT_CALL_NON_NBR_HO(ptCi, "%s Not Idle state, so drop ReportCGI MR\n", __func__);
        return BREAK;
    }

    if (false == cgiAcquired)
    {
        if (GET_REPORT_CGI_DUPL_PCI(ptCi) == VCCB_FLAG_ON)
        {
            auto hoInputDb = StartSaHandoverDb(ptCi->anrInfo.reportType, ptCi->anrInfo.reportPurpose, ptCi->anrInfo.reportConfigQuantitySaHo);
            if (GOOD ==
                VHCM_StartSaHandover_InterRAT(ptCi, ptCi->reportCgiHoInfo.qTargetNbrIdx[0], HoPurpose_DLQuality, hoInputDb))
            {
                VCCB_PRINT_CALL_INFORMATIVE(
                    ptCi, "[DUPL_PCI] VHCM_StartSaHandover_InterRAT triggered by NoCgiAcquired\n");
                return GOOD;
            }
        }
        return ERROR;
    }

    if (GET_REPORT_CGI_NON_NEIGHBOR(ptCi) == VCCB_FLAG_ON)
    {
        auto hoInputDb = StartSaHandoverDb(ptCi->anrInfo.reportType, ptCi->anrInfo.reportPurpose, ptCi->anrInfo.reportConfigQuantitySaHo);
        return VHCM_StartSaHandover_InterRat_ToNonNeighborCell(ptCi, reportedCGI, HoPurpose_DLQuality, hoInputDb);
    }
    else
    {
        if (TRUE == DBG->flag.reportCgiHandoverNewAlgorithm)
        {
            // select TgtCell and start Handover
            return FnVCCB_SelectTgtCellFromEcgiInfoAndStartHandover_NewAlgorithm(
                ptCi, reportedCGI.cgi);
        }
        else
        {
            measResultNeighCellsEUTRA_type *ptMeasResultList2EUTRA =
                &THREAD_INFO->call[ptCi->myThreadId].buf.measResultListEutraRx;
            // select TgtCell and start Handover
            return FnVCCB_SelectTgtCellFromEcgiInfoAndStartHandover(ptCi, ptMeasResultList2EUTRA, reportedCGI.cgi);
        }
    }
}

// SM_CELL_HO_24A
void FnVCCB_SetMeasStateForFallback(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    FnVCCB_GetSaMeas(*ptCi).iratMeasState = IRAT_MEAS_STATE_ACTIVE;
    VIIL_InitReportCgi(ptCi);
    SET_REPORT_CGI_DUPL_PCI(ptCi, VCCB_FLAG_OFF);
    SET_REPORT_CGI_NON_NEIGHBOR(ptCi, VCCB_FLAG_OFF);
    if (not GET_REPORT_CGI_SN_FLAG(ptCi))
        VCCB_CLEAR_TIMER(&ptCi->anrInfo.reportCgiTimer, INIT_TIMER);
}

int16_t FnVCCB_GetSmallCellIdxFromMO(uint16_t cellNum, uint32_t ssbFreq)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, -1);

    measurementObjectNRDb_type *ptMO = FnVCCB_FindMeasObjectUsingFrequency(cellNum, ssbFreq, NULL);
    if (ptMO == NULL) return -1;

    return ptMO->base.smallCellPciListIndex;
}

bool FnVCCB_IsNrSmallCellPciWithSsbFreq(callInfo_type *ptCi, uint16_t cellNum, uint16_t pci, uint32_t ssbFreq)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    int16_t smallCellIdx = FnVCCB_GetSmallCellIdxFromMO(cellNum, ssbFreq);

    return FnVCCB_IsNrSmallCellPci(ptCi, pci, (int8_t)smallCellIdx);
}


// EOF



