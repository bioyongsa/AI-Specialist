/**
 * @file        FeatConditionalHo.cpp
 * @brief       This function provides a function for controlling the operation of the Mobility Feature for the SA UE.
 */

#include "FeatHoCommon.h"
#include "FeatCommon.h"
#include "FeatCallInfo.h"
#include "FeatCallProc.h"
#include "FeatMeasurements.hpp"
#include "FeatMeasurementsNRRRCMake.hpp"

#include "ComInclude.h"
#include "ComLibUtility.h"
#include "ComTimeUtil.h"

#include "StateCommon.h"
#include "StateMeasurements.h"
#include "StateSaHo.h"

#include "MsgXnapSend.h"

/****************************************************************************
                            Handover Trigger Function

 1. Conditional Handover          : FnVCCB_StartSaHandover_ConditionalHo
    1.1 Intra-GNB Handover        : FnVCCB_StartSaHandover_ConditionalHo_IntraGnb
    1.2 Inter-GNB Handover        : FnVCCB_StartSaHandover_ConditionalHo_InterGnb

****************************************************************************/

#ifdef IPC_TEST
static inline
void FnVCCB_TxStopAllDisable(callInfo_type *ptCi)
{
    for (uint32_t drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        callDRBInfo_type *ptDi = &ptCi->drb[drbIdx];

        if (ptDi->usage != CI_use) continue;

        if (ptDi->mCG_E1STOP == TRUE)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "DRB ID #%u, Not RESUME after TX STOP for MCG. But It is Forced Trigger\n", ptDi->dRBId);
            ptDi->mCG_E1STOP = FALSE;
        }

        if (ptDi->sCG_E1STOP == TRUE)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "DRB ID #%u, Not RESUME after TX STOP for SCG. But It is Forced Trigger\n", ptDi->dRBId);
            ptDi->sCG_E1STOP = FALSE;
        }
    }
}
#endif

/****************************************************************************
 2. Conditional Handover API
****************************************************************************/

/****************************************************
 * @brief      This function notifies whether CHO is supported for each band.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  bandNr : nr band / uint16_t
 * @return     NULL, Pointer
 ****************************************************/
bool FnVCCB_UeSupportCHOForBandInd(callInfo_type *ptCi, uint16_t bandNr)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    bandNrUeCapa_type *ptBand = FnVCCB_GetBandNrUeCapa(ptCi, bandNr);
    VALID_E_POINT_CHECK_RET_VAL(ptBand, false);

    return (ptBand->isCondHandoverCapable == FLAG_ON);
}

/****************************************************
 * @brief      This function notifies whether CHO Failure is supported for each band.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  bandNr : nr band / uint16_t
 * @return     NULL, Pointer
 ****************************************************/
bool FnVCCB_UeSupportCHOFailureForBandInd(callInfo_type *ptCi, uint16_t bandNr)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    bandNrUeCapa_type *ptBand = FnVCCB_GetBandNrUeCapa(ptCi, bandNr);
    VALID_E_POINT_CHECK_RET_VAL(ptBand, false);

    return (ptBand->isCondHandoverFailureCapable == FLAG_ON);
}

/****************************************************
 * @brief      This function notifies whether CHO Two Trigger Event is supported for each band.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  bandNr : nr band / uint16_t
 * @return     NULL, Pointer
 ****************************************************/
bool FnVCCB_UeSupportCHOTwoTriggerEventForBandInd(callInfo_type *ptCi, uint16_t bandNr)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    bandNrUeCapa_type *ptBand = FnVCCB_GetBandNrUeCapa(ptCi, bandNr);
    VALID_E_POINT_CHECK_RET_VAL(ptBand, false);

    return (ptBand->isCondHandoverTwoTriggerEventCapable == FLAG_ON);
}

/****************************************************
 * @brief      Get number of cho candidate cell for serviceGroup.
 * @param[in]  ptCi : call information / callInfo_type, svcGrpId : service-group-id
 * @return     0 ~ 8
 ****************************************************/
uint32_t FnVCCB_GetNumOfChoCondCellForSvcGrp(callInfo_type *ptCi, uint8_t svcGrpId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, 0);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, 0);
    VCCB_CHECK_E_RANGE_AND_VAL(svcGrpId, MAX_SVC_GRP_DB_NUM, 0);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint32_t numOfCondCell = 0;
    if (pGnb->cfg.svcGrpBasedCfg[svcGrpId].usage == CI_use)
    {
        numOfCondCell = pGnb->cfg.svcGrpBasedCfg[svcGrpId].numOfChoCandidateCell;
        VCCB_CHECK_E_RANGE_AND_VAL(numOfCondCell, MAX_CANDIDATE_CELL_DB, 0);
    }

    return numOfCondCell;
}

/****************************************************
 * @brief      This function notifies whether CHO is supported in MobilityConfig.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     true,false / bool
 ****************************************************/
bool FnVCCB_IsConditionalHandoverSupportedByMobilityConfig(uint16_t cellNum)
{
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);
    return CELLINFO[cellNum].mobilityConfig.conditionalHandoverConfig.allowance;
}

/****************************************************
 * @brief      Check if Conditional Handover is Supported.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     true,false / bool
 ****************************************************/
bool FnVCCB_IsConditionalHandoverSupported(
    callInfo_type *ptCi, uint16_t cellNum, measurementObjectNRBaseDb_type *ptMO, uint8_t svcGrpId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptMO, false);
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    uint16_t targetBandNr = VCCB_GetMoNrBandForUe(ptCi, ptMO);
    if (0 == targetBandNr)
    {
        VCCB_PRINT_CALL_SA_CHO(ptCi, "[CHO] ptMO->ssbArfcn(%u) Not Supported band \n", ptMO->ssbFrequency);
        return false;
    }

    // FR40, FR50
    // 1) the UE supports conditional handover for frequency
    if (FnVCCB_UeSupportCHOForBandInd(ptCi, targetBandNr) == false)
    {
        VCCB_PRINT_CALL_SA_CHO(ptCi, "[CHO] Target Band(%d) is not supported Band\n", targetBandNr);
        return false;
    }

    // 2) Maximum number of candidates for UE service-group is not zero
    {
        uint32_t numOfCondCell;
        numOfCondCell = FnVCCB_GetNumOfChoCondCellForSvcGrp(ptCi, svcGrpId);
        if (numOfCondCell == 0)
        {
            VCCB_PRINT_CALL_SA_CHO(
                ptCi, "[CHO] service-group-id(%d) number of CHO Cond Cell is 0 !!!\n", svcGrpId);
            return false;
        }
    }

    // 3) Serving cell CHO allowance is set to use
    if (FnVCCB_IsConditionalHandoverSupportedByMobilityConfig(cellNum) == false)
    {
        VCCB_PRINT_CALL_SA_CHO(ptCi, "[CHO] cellNum(%d) cho_allowance is not TRUE!!!\n", cellNum);
        return false;
    }

    // 4) CHO preparation condition for serving frequency is valid
    //    - The CHO Prep/ExeCond1 condition is checked in the
    //      'FnVCCB_AddChoPreparationMeasConfByObjIdx' function.

    const bool isInterFrequencyHo = VCCB_IS_INTER_FREQ_SSB_FREQ(cellNum, ptMO->ssbFrequency);

    if (isInterFrequencyHo)
    {
        // If the duplex mode (TDD/FDD) of the serving frequency and the target frequency is different,
        // check whether it is supported and exclude it from the target if it is not supported.
        uint16_t servBandNr = VLIB_GetFreqBandIndForCell(ptCi, pCell);
        uint16_t servDuplex = FnVCCB_GetNrDuplexTypeByBandIndicator(servBandNr);
        uint16_t targetDuplex = FnVCCB_GetNrDuplexTypeByBandIndicator(targetBandNr);

        if (targetDuplex != servDuplex)
        {
            if (FALSE == ptCi->ueInfo.ueCapa.nr.measAndMob.condHandoverFDD_TDD)
            {
                VCCB_PRINT_CALL_SA_CHO(ptCi,
                    "[CHO] condHandoverFDD_TDD is not TRUE! svr(band:%d, duplex:%d) != tgt(band:%d, duplex:%d)\n",
                    servBandNr, servDuplex, targetBandNr, targetDuplex);
                return false;
            }
        }

        // If the FR type of Serving and Target is different, it is necessary to check whether CAPA is supported.
        if (IS_FR1(pCell->ssbArfcn) == IS_FR1(ptMO->ssbFrequency) ||
            IS_FR2(pCell->ssbArfcn) == IS_FR2(ptMO->ssbFrequency))
        {
            // OK
        }
        else  // FR1 & FR2 Combination
        {
            if (FALSE == ptCi->ueInfo.ueCapa.nr.measAndMob.condHandoverFR1_FR2)
            {
                VCCB_PRINT_CALL_SA_CHO(ptCi, "[CHO] condHandoverFR1_FR2 is not TRUE! serving:FR%d != target:FR%d\n",
                    IS_FR1(pCell->ssbArfcn) ? 1 : 2, IS_FR1(ptMO->ssbFrequency) ? 1 : 2);
                return false;
            }
        }
    }

    return true;
}

/****************************************************
 * @brief      Initialize Conditional Handover DB.
 * @param[in]  ptCi : call information / callInfo_type
 ****************************************************/
void FnVCCB_InitCondHoInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    conditionalHandoverInfo_type *ptInfo = &ptCi->condHoInfo;

    ptInfo->currentCi = ptCi->nRCGI.ci;

    uint8_t condIdx = 0;

    ptInfo->numOfCellList = 0;

    // Fill Flag
    memset(&ptInfo->flag, 0x00, sizeof(ptInfo->flag));

    for (condIdx = 0; condIdx < MAX_NUM_COND_CELLS; condIdx++)
    {
        conditionalCellInfo_type *ptCondCell = &ptInfo->cellList[condIdx];

        FnVCCB_InitConditionalCellInfo(ptCondCell, condIdx);
    }
}

// Meas Configuration
void FnVCCB_ClearChoNewMeasConfig(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    for (uint8_t condCellIdx = 0; condCellIdx < MAX_NUM_COND_CELLS; condCellIdx++)
    {
        conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForIndex(ptCi, condCellIdx);

        if (ptCondCell == NULL) continue;

        for (uint32_t measIdx = 0; measIdx < MAX_NUM_OF_COND_EXECUTION_COND; measIdx++)
        {
            ptCondCell->measInfo.condEventMeasIdNew[measIdx] = INVALID_OBJECT_ID;
        }
    }
}

void FnVCCB_PostProcessApplyNewMeasConfigForCho(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    int16_t status = GOOD;
    uint8_t measId = INVALID_OBJECT_ID;

    cellSelection_type cellSelection = FnVCCB_GetCellSelectionForConfig(ptCi);
    uint16_t cellNum = cellSelection.cellNum;

    if (cellNum >= MAX_CELL_NUM_VCCB)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "(*CHO) ptCi->stateCmd(%u): cellNum(%u) is invalid!!\n", ptCi->stateCmd, cellNum);
        return;
    }

    if (VHCM_isSaHandoverUE(ptCi) == TRUE && ptCi->hoInfo.isTarget == TRUE)
    {
        VCCB_PRINT_CALL_SA_CHO(ptCi, "(*CHO) It is unnecessary on the target side during handover.\n");
        return;
    }

    for (uint8_t condCellIdx = 0; condCellIdx < MAX_NUM_COND_CELLS; condCellIdx++)
    {
        conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForIndex(ptCi, condCellIdx);

        if (ptCondCell == NULL) continue;

        auto ssbFrequency = ptCondCell->measInfo.ssbFrequency;
        uint8_t measObjectIdx = MAX_NR_OF_OBJECT_ID_DB;
        measurementObjectNRDb_type *ptMO = NULL;

        ptMO = FnVCCB_FindMeasObjectUsingFrequency(cellNum, ssbFrequency, &measObjectIdx);
        if (ptMO == NULL)
        {
            VCCB_PRINT_CALL_SA_CHO(ptCi, "(*CHO) The MeasObject(%u) has been deleted, so I can't keep the Conditional Cell.", ssbFrequency);
            continue;
        }

        for (uint8_t condEventIdx = e_CondEvent_1; condEventIdx < e_MaxNumOfCondExecutionCond; condEventIdx++)
        {
            enumMeasurementReportType reportType;
            uint8_t reportPurpose;

            status = FnVCCB_ChoExecutionCondEvent_getReportTypeAndPurpose(
                ptCi, (condEvent_type)condEventIdx, &ptMO->base, &reportType, &reportPurpose, measObjectIdx);
            if (ERROR == status)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "(*CHO) ChoExecutionCondEvent_getReportTypeAndPurpose Error(condEventIdx:%d)!\n", condEventIdx);
                break;
            }
            else if (BREAK == status)
            {
                VCCB_PRINT_CALL_SA_CHO(ptCi, "(*CHO) ChoExecutionCond2Event BREAK(condEventIdx:%d)!\n", condEventIdx);
                break;
            }

            measId = VCCB_FindMatchingMeasIdInMeasProcedure(*ptCi, ssbFrequency, reportType, reportPurpose);
            if (measId == INVALID_OBJECT_ID)
            {
                if (condEventIdx == e_CondEvent_2)  // normal : only cond event1 setting case
                    break;

                // normal : A situation in which measId is not assigned.
                if (FnVCCB_CheckNeedCondCellProcessing(ptCondCell) == false) break;

                VCCB_PRINT_CALL_ERROR(ptCi, "(*CHO) Not Found Meas Id : (condIdx:%u, condExec%u, status:%s) Error!\n",
                    ptCondCell->condCellIdx, COVERT_VALUE_FROM_DB_TO_SPEC(condEventIdx),
                    FnVCCB_GetStrCommonStatus((enumCommonStatus_type)ptCondCell->condStatus));
                break;
            }

            ptCondCell->measInfo.condEventMeasIdNew[condEventIdx] = measId;
        }
    }
}

/****************************************************************************
 * @brief           Execute UE Meas for SON timer trigger
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 ****************************************************************************/
void FnVCCB_CommitUeMeasForCho(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (FnVCCB_IsEmptyConditionalCell(ptCi)) return;

    for (uint8_t condCellIdx = 0; condCellIdx < MAX_NUM_COND_CELLS; condCellIdx++)
    {
        conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForIndex(ptCi, condCellIdx);

        if (ptCondCell == NULL) continue;

        for (uint32_t measIdx = 0; measIdx < MAX_NUM_OF_COND_EXECUTION_COND; measIdx++)
        {
            ptCondCell->measInfo.condEventMeasIdInstalled[measIdx] = ptCondCell->measInfo.condEventMeasIdNew[measIdx];
        }
    }
}

bool FnVCCB_CheckNeedCondCellProcessing(conditionalCellInfo_type *ptCondCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCondCell, false);

    switch (ptCondCell->condStatus)
    {
        // Since the status has already been confirmed, we do not proceed further.
        case Common_Release:
        case Common_FailToSetup:
            return false;

        // Go through the steps below to determine if a procedure change is necessary.
        default:
            return true;
    }
}

/****************************************************************************
 * @brief           Execute UE Meas for SON timer trigger
 * @param[in/out]   ptCi : Pointer to call configuration. / callInfo_type*
 ****************************************************************************/
void FnVCCB_CheckChangedUeMeasConfig(conditionalCellInfo_type *ptCondCell, uint8_t *ptCondStatus)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCondCell, ptCondStatus);

    // Check if processing is necessary. - Comment out this function as it is already checked at the time of calling it.
    // if (FnVCCB_CheckNeedCondCellProcessing(ptCondCell) == false)
    //     return;

    // 1. If the condition of Cond1 is changed
    // {{{

    // 1.1. If Execution Cond1 is not assigned, it cannot be maintained.
    if (ptCondCell->measInfo.condEventMeasIdNew[e_CondEvent_1] >= INVALID_OBJECT_ID)
    {
        switch (ptCondCell->condStatus)
        {
            case Common_Setup:  // Change Fail Case
                *ptCondStatus = Common_FailToSetup;
                break;

            case Common_FailToSetup:  // Ignore
                break;

            default:
                *ptCondStatus = Common_Release;
                break;
        }

        return;
    }

    // 1.1 If the value of CondEvent1 is changed, a change is required.
    // No SVR22C2 occurrence scenario.

    // }}}

    // -----------------------------------------------------------------------------------------------

    // 2. If the condition of Cond2 is changed
    // {{{

    // 2.1. During the setup procedure, the existing rules are followed.
    //      There is no need to change Setup Processing to Modify Proccing.
    if (ptCondCell->condStatus == S_Setup) return;

    // 2.2 Usage Not Chagned ( ON -> ON, OFF -> OFF )

    if (ptCondCell->measInfo.condEventMeasIdNew[e_CondEvent_2] ==
        ptCondCell->measInfo.condEventMeasIdInstalled[e_CondEvent_2])
    {
        // 2.2.1 OFF -> OFF Case, Discard
        if (ptCondCell->measInfo.condEventMeasIdInstalled[e_CondEvent_2] >= INVALID_OBJECT_ID)
        {
            return;
        }

        // 2.2.2 ON -> ON Case, and Not Change MeasId, Discard
        return;
    }

    // 2.2.2 ON -> ON Case, and Change MeasId
    // 2.3 Usage Change ( ON -> OFF, OFF -> ON ) : maybe, Cond2 condition changed
    *ptCondStatus = Common_Modify;
    return;

    // }}}
}

// Conditional Cell List Information
// {{{

/****************************************************
 * @brief      Init Conditional Cell Information
 * @param[in]  ptCondCell : cond cell information / conditionalCellInfo_type
 * @return     void
 ****************************************************/
void FnVCCB_InitConditionalCellInfo(conditionalCellInfo_type *ptCondCell, uint8_t condCellIndex)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCondCell);

    memset(ptCondCell, 0xFF, sizeof(*ptCondCell));

    ptCondCell->usage = CI_no_use;
    ptCondCell->condCellIdx = condCellIndex & e_BitMask_7bit;
    ptCondCell->condStatus = S_Setup;
    ptCondCell->statCause = CHO_TYPE_MAX;

    for (uint16_t endPointIdx = 0; endPointIdx < MAX_NUM_OF_ENDPOINTS_FOR_COND_CELL; endPointIdx++)
    {
        ptCondCell->endPointInfo[endPointIdx].usage = CI_no_use;
    }

    // Fill Flag
    memset(&ptCondCell->flag, 0x00, sizeof(ptCondCell->flag));

    // Fill Forward
    for (uint32_t qosFlowIdx = 0; qosFlowIdx < MAX_QOS_FLOW_PER_CALL; qosFlowIdx++)
    {
        FnVCCB_InitQosFlowDataFwdInfo(&ptCondCell->dataForward.qosFlow[qosFlowIdx].info);
    }

    for (uint32_t pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        FnVCCB_InitPduDataFwdTunnel(&ptCondCell->dataForward.pdu[pduIdx].tunnel);
    }

    for (uint32_t drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        FnVCCB_InitDrbDataFwdTunnel(&ptCondCell->dataForward.drb[drbIdx].tunnel);
    }

    // Fill MeasInfo
    for (uint32_t measIdx = 0; measIdx < MAX_NUM_OF_COND_EXECUTION_COND; measIdx++)
    {
        ptCondCell->measInfo.condEventMeasIdInstalled[measIdx] = INVALID_OBJECT_ID;
        ptCondCell->measInfo.condEventMeasIdNew[measIdx] = INVALID_OBJECT_ID;
    }

    // candidate-cell-release-timer-source
    // candidate-cell-release-timer-target
    FnVCCB_CancelConditionalCellTimer(ptCondCell, INIT_TIMER);

}  // }}}

/****************************************************
 * @brief      Get Conditional Cell Information For Index
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  condCellIdx : candidate index of array / uint16_t
 * @return     return address
 ****************************************************/
conditionalCellInfo_type *FnVCCB_GetConditionalCellInfoForIndex(callInfo_type *ptCi, uint8_t condCellIdx)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptCi);

    if (condCellIdx >= MAX_NUM_COND_CELLS) return NULL;

    conditionalCellInfo_type *ptCondCell = &ptCi->condHoInfo.cellList[condCellIdx];

    if (!IS_VALID_NODE(COND_CELL_NODE, ptCi, ptCondCell)) return NULL;

    return ptCondCell;
}  // }}}

/****************************************************
 * @brief      Get Conditional Cell Information For CGI
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  findCgi : find Cgi Information / cgi_type
 * @return     return address
 ****************************************************/
conditionalCellInfo_type *FnVCCB_GetConditionalCellInfoForCGI(callInfo_type *ptCi, cgi_type findCgi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptCi);

    for (uint8_t condCellIdx = 0; condCellIdx < MAX_NUM_COND_CELLS; condCellIdx++)
    {
        conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForIndex(ptCi, condCellIdx);

        if (ptCondCell == NULL) continue;

        if (FnVCCB_CheckCgiIdentical(&ptCondCell->nrcgi, &findCgi))
        {
            return ptCondCell;
        }
    }

    return NULL;
}  // }}}

/****************************************************
 * @brief      This function increases numOfCellList.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
VCCB_STATIC_INLINE void FnVCCB_NumOfCellList_Up(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->condHoInfo.numOfCellList < MAX_NUM_COND_CELLS) ptCi->condHoInfo.numOfCellList++;
}  // }}}

/****************************************************
 * @brief      This function deincreases numOfCellList.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
VCCB_STATIC_INLINE void FnVCCB_NumOfCellList_Down(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->condHoInfo.numOfCellList > 0) ptCi->condHoInfo.numOfCellList--;
}  // }}}

/****************************************************
 * @brief      Alloc Conditional Cell Information For CGI
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  findCgi : find Cgi Information / cgi_type
 * @return     return  index of arrary / uint8_t
 ****************************************************/
uint8_t FnVCCB_AllocConditionalCellInfoForCGI(callInfo_type *ptCi, cgi_type condCellCgi, uint32_t ssbFreq)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_NUM_COND_CELLS);

    if (FnVCCB_GetConditionalCellInfoForCGI(ptCi, condCellCgi) != NULL)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Double Allocation Request(CGI:%X/%llu)\n", condCellCgi.plmn.longId, condCellCgi.ci * 1ULL);
        return MAX_NUM_COND_CELLS;
    }

    for (uint8_t condCellIdx = 0; condCellIdx < MAX_NUM_COND_CELLS; condCellIdx++)
    {
        int cause = e_Valid_Ok;
        conditionalCellInfo_type *ptCondCell = &ptCi->condHoInfo.cellList[condCellIdx];

        if (IS_VALID_NODE_WITH_CAUSE(COND_CELL_NODE, ptCi, ptCondCell, &cause)) continue;

        // allow only no_use case
        if (cause != e_Invalid_no_use)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "COND_CELL_NODE[%d] is unknown cause, Need Check(%d)\n", condCellIdx, cause);
            continue;
        }

        FnVCCB_InitConditionalCellInfo(ptCondCell, condCellIdx);

        ptCondCell->measInfo.ssbFrequency = ssbFreq;

        ptCondCell->nrcgi = condCellCgi;

        FnVCCB_NumOfCellList_Up(ptCi);

        ptCondCell->usage = CI_use;

        // It should be located after usage due to validation check.
        SET_COND_CELL_STATUS(ptCi, condCellIdx, Common_Setup);

        return condCellIdx;
    }

    VCCB_PRINT_CALL_ERROR(
        ptCi, "Max Over Allocation Request(CGI:%X/%llu)\n", condCellCgi.plmn.longId, condCellCgi.ci * 1ULL);
    return MAX_NUM_COND_CELLS;
}  // }}}

/****************************************************
 * @brief      Free Conditional Cell Information For Index
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  condCellIdx : candidate index of array / uint16_t
 * @return     void
 ****************************************************/
void FnVCCB_FreeConditionalCellInfoForIndex(callInfo_type *ptCi, uint8_t condCellIdx)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForIndex(ptCi, condCellIdx);

    if (ptCondCell == NULL)
    {
        return;
    }

    FnVCCB_NumOfCellList_Down(ptCi);

    ptCondCell->usage = CI_no_use;

    // candidate-cell-release-timer-source
    // candidate-cell-release-timer-target
    FnVCCB_CancelConditionalCellTimer(ptCondCell, CANCEL_TIMER);

    return;
}  // }}}

/****************************************************
 * @brief      Free Conditional Cell Information For CGI
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  condCellCgi : find Cgi Information / cgi_type
 * @return     void
 ****************************************************/
void FnVCCB_FreeConditionalCellInfoForCGI(callInfo_type *ptCi, cgi_type condCellCgi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForCGI(ptCi, condCellCgi);

    if (ptCondCell == NULL)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Not Found CGI for Free Request(CGI:%X/%llu)\n", condCellCgi.plmn.longId, condCellCgi.ci * 1ULL);
        return;
    }

    FnVCCB_NumOfCellList_Down(ptCi);

    ptCondCell->usage = CI_no_use;

    // candidate-cell-release-timer-source
    // candidate-cell-release-timer-target
    FnVCCB_CancelConditionalCellTimer(ptCondCell, CANCEL_TIMER);

    return;
}  // }}}

/****************************************************
 * @brief      This is the action to process the Timer used for Conditional Handover.
 * @param[in]  ptCondCell : conditional cell information / conditionalCellInfo_type
 * @param[in]  option : timer for conditional cell / enumTimerType
 ****************************************************/
void FnVCCB_CancelConditionalCellTimer(conditionalCellInfo_type *ptCondCell, enumTimerType option)
{
    VALID_E_POINT_CHECK_VOID(ptCondCell);

    VCCB_CLEAR_TIMER(&ptCondCell->condCellReleaseTimer, option);
}

/****************************************************
 * @brief      Change the status of Conditional Cell Information.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  condCellCgi : find Cgi Information / cgi_type
 * @param[in]  condCellIdx : candidate index of array / uint16_t
 * @param[in]  newStatus   : Enter the status value to be updated. / enumCommonStatus_type
 * @return     void
 ****************************************************/
void FnVCCB_SetConditionalCellStatus(callInfo_type *ptCi, uint8_t condCellIdx, enumCommonStatus_type newStatus)
{  // {{{
    VALID_E_POINT_CHECK_VOID(ptCi);

    conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForIndex(ptCi, condCellIdx);
    VALID_E_POINT_CHECK_VOID(ptCondCell);

    // no action
    if (ptCondCell->condStatus == newStatus) return;

    if (DBG->flag.statusDebug)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "COND(idx:%d, cgi:%X/%llu) status is update (%d:%s -> %d:%s)!\n", condCellIdx,
            ptCondCell->nrcgi.plmn.longId, ptCondCell->nrcgi.ci * 1ULL, (enumCommonStatus_type)ptCondCell->condStatus,
            FnVCCB_GetStrCommonStatus((enumCommonStatus_type)ptCondCell->condStatus), newStatus,
            FnVCCB_GetStrCommonStatus(newStatus));
    }

    ptCondCell->condStatus = newStatus;
}  // }}}
// }}}

/****************************************************
 * @brief      This function performs the procedure of moving from Handover DB to Conditional HO DB.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ptCondCell : cond cell information / conditionalCellInfo_type
 * @return     void
 ****************************************************/
int16_t FnVCCB_StoreHandoverConfigToCondCellInfo(
    callInfo_type *ptCi, conditionalCellInfo_type *ptCondCell, uint8_t interface)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptCondCell);

    if (ptCondCell->endPointInfo[0].usage == CI_use)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Used EndPointInfo.. Need Clear DB\n");
        return ERROR;
    }

    // Fill End Point - always used index 0
    switch (interface)
    {
        case interface_xn:
            ptCondCell->endPointInfo[0].usage = CI_use;
            ptCondCell->endPointInfo[0].interface = interface_xn;
            ptCondCell->endPointInfo[0].endIdx = ptCi->endPointInfo.xnIdx;
            ptCondCell->endPointInfo[0].neId = ptCi->endPointInfo.xnGnbId;
            ptCondCell->endPointInfo[0].ueId = ptCi->xnCallId;
            break;

        case interface_f1:
            ptCondCell->endPointInfo[0].usage = CI_use;
            ptCondCell->endPointInfo[0].interface = interface_f1;
            ptCondCell->endPointInfo[0].endIdx = ptCi->endPointInfo.f1Idx;
            ptCondCell->endPointInfo[0].neId = ptCi->endPointInfo.gnbDuId;
            ptCondCell->endPointInfo[0].ueId = ptCi->auCallId;
            break;

        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "Unknown Interface(%u)\n", interface);
            return ERROR;
    }

    // Fill CGI
    // Already recorded.

    // Fill Flag
    // ptCondCell->flag.inter_gnb_s_connection_flag
    // Already recorded.

    // ptCondCell->flag.inter_gnb_t_connection_flag
    // Already recorded.

    // Fill pci
    ptCondCell->pci = ptCi->hoInfo.phyCellId;

    // Fill CRNTI
    if (ptCi->hoInfo.targetcRNTIUsage == CI_use)
    {
        ptCondCell->flag.crntiUsage = CI_use;
        ptCondCell->crnti = ptCi->hoInfo.targetcRNTI;
    }
    else
    {
        ptCondCell->flag.crntiUsage = CI_no_use;
        memset(&ptCondCell->crnti, 0xFF, sizeof(ptCondCell->crnti));
    }

    // Fill Forward
    for (uint32_t qosFlowIdx = 0; qosFlowIdx < MAX_QOS_FLOW_PER_CALL; qosFlowIdx++)
    {
        if (IS_VALID_NODE(QOSFLOW_NODE, ptCi, &ptCi->qosFlow[qosFlowIdx]))
        {
            ptCondCell->dataForward.qosFlow[qosFlowIdx].info = ptCi->qosFlow[qosFlowIdx].dataFwdInfo;
        }
    }

    for (uint32_t pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        if (IS_VALID_NODE(PDU_NODE, ptCi, &ptCi->pduSess[pduIdx]))
        {
            ptCondCell->dataForward.pdu[pduIdx].tunnel = ptCi->pduSess[pduIdx].nGuFwdTunnel;
        }
    }

    for (uint32_t drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        if (IS_VALID_NODE(DRB_NODE, ptCi, &ptCi->drb[drbIdx]))
        {
            ptCondCell->dataForward.drb[drbIdx].tunnel = ptCi->drb[drbIdx].dataFwdInfo.gtpTunnel;
        }
    }

    ptCondCell->selectedTAI = ptCi->hoInfo.selectedTAI;

    return GOOD;
}  // }}}

/****************************************************
 * @brief      This function performs the procedure of moving from Handover DB to Conditional HO DB.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ptCondCell : cond cell information / conditionalCellInfo_type
 * @return     void
 ****************************************************/
int16_t FnVCCB_FillHandoverConfigToCondCellInfo(callInfo_type *ptCi, cgi_type targetCgi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForCGI(ptCi, targetCgi);
    VALID_E_POINT_CHECK_ERROR(ptCondCell);

    if (ptCondCell->endPointInfo[0].usage == CI_no_use)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Un-used EndPointInfo.. Need Set DB\n");
        return ERROR;
    }

    // Fill End Point - always used index 0
    switch (ptCondCell->endPointInfo[0].interface)
    {
        case interface_xn:
            ptCi->endPointInfo.xnIdx = ptCondCell->endPointInfo[0].endIdx;
            ptCi->endPointInfo.xnGnbId = (uint32_t)ptCondCell->endPointInfo[0].neId;
            ptCi->xnCallId = ptCondCell->endPointInfo[0].ueId;
            break;

            // case interface_f1: // TBD : Intra GNB F1
            //     break;

        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "Unknown Interface(%u)\n", ptCondCell->endPointInfo[0].interface);
            return ERROR;
    }

    // Fill CGI
    // Already recorded.

    // Fill Flag
    if (ptCondCell->flag.inter_gnb_s_connection_flag)
        ptCi->hoInfo.interGnbSrcConnectionFlag = TRUE;
    else
        ptCi->hoInfo.interGnbSrcConnectionFlag = FALSE;

    if (ptCondCell->flag.inter_gnb_t_connection_flag)
        ptCi->hoInfo.interGnbTgtConnectionFlag = TRUE;
    else
        ptCi->hoInfo.interGnbTgtConnectionFlag = FALSE;

    // Fill pci
    ptCi->hoInfo.phyCellId = ptCondCell->pci;

    // Fill CRNTI
    ptCi->hoInfo.targetcRNTIUsage = ptCondCell->flag.crntiUsage;
    ptCi->hoInfo.targetcRNTI = ptCondCell->crnti;

    // Fill Forward
    for (uint32_t qosFlowIdx = 0; qosFlowIdx < MAX_QOS_FLOW_PER_CALL; qosFlowIdx++)
    {
        if (IS_VALID_NODE(QOSFLOW_NODE, ptCi, &ptCi->qosFlow[qosFlowIdx]))
        {
            ptCi->qosFlow[qosFlowIdx].dataFwdInfo = ptCondCell->dataForward.qosFlow[qosFlowIdx].info;
        }
    }

    for (uint32_t pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        if (IS_VALID_NODE(PDU_NODE, ptCi, &ptCi->pduSess[pduIdx]))
        {
            auto rPduTunnel = ptCondCell->dataForward.pdu[pduIdx].tunnel;

            FnVCCB_InitPduDataFwdTunnel(&ptCi->pduSess[pduIdx].nGuFwdTunnel);

            if (rPduTunnel.dl.numTLAbit + rPduTunnel.ul.numTLAbit)  // If any value exists
            {
                ptCi->pduSess[pduIdx].nGuFwdTunnel = rPduTunnel;
            }
        }
    }

    for (uint32_t drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        if (IS_VALID_NODE(DRB_NODE, ptCi, &ptCi->drb[drbIdx]))
        {
            auto rDrbTunnel = ptCondCell->dataForward.drb[drbIdx].tunnel;

            FnVCCB_InitDrbDataFwdTunnel(&ptCi->drb[drbIdx].dataFwdInfo.gtpTunnel);

            if (rDrbTunnel.dl.numTLAbit + rDrbTunnel.ul.numTLAbit)  // If any value exists
            {
                ptCi->drb[drbIdx].dataFwdInfo.gtpTunnel = rDrbTunnel;
            }
        }
    }

    ptCi->hoInfo.selectedTAI = ptCondCell->selectedTAI;

    return GOOD;
}  // }}}

/****************************************************
 * @brief      This function is responsible for the Release Process in the 'FnVCCB_ConditionalCellConfigCommit'
 *function.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  condCellIdx : index of conditional cell information / uint8_t
 * @return     void
 ****************************************************/
VCCB_STATIC_INLINE
void FnVCCB_ConditionalCellConfigCommit_ReleaseProcess(callInfo_type *ptCi, conditionalCellInfo_type *ptCondCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptCondCell);

    int16_t status = GOOD;

    // TODO : If the Candidate gNB has more than one Cell, the structure must be changed. Not a problem at the moment.

    // Send Handover Cancel.
    if (ptCondCell->flag.inter_gnb_s_connection_flag == TRUE)
    {
        uint8_t condCellIdx = ptCondCell->condCellIdx;
        status = FnVCCB_SendXNMessage(XN_HandoverCancel_id, ptCi, &condCellIdx, nullptr);
        if (status == ERROR)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "(*CHO) FnVCCB_SendXNMessage(XN_HandoverCancel) ERROR!!\n");
            // return;
        }

        FnVCCB_UpdateInterGnbConnectionState_Source(ptCi, ptCondCell->nrcgi, OFF);
    }

    // Send Conditional Handover Cancel.
    if (ptCondCell->flag.to_resp_cho_cancel == TRUE)
    {
        if (ptCondCell->flag.inter_gnb_t_connection_flag == TRUE)
        {
            {
                status = FnVCCB_SendXNMessage(XN_ConditionalHandoverCancel_id, ptCi, nullptr, nullptr);
                if (status == ERROR)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "(*CHO) FnVCCB_SendXNMessage(XN_ConditionalHandoverCancel) ERROR!!\n");
                    // return;
                }
            }

            FnVCCB_UpdateInterGnbConnectionState_Target(ptCi, ptCondCell->nrcgi, OFF);
        }

        ptCondCell->flag.to_resp_cho_cancel = FALSE;
    }

    // Stat
    if (ptCondCell->flag.collectableCandidateRelStat == TRUE)
    {
        CHO_STAT(ptCi, CHO_CandidateRel_gNBCancel, ptCondCell->nrcgi);
    }

    // Clear Conditional Cell DB.
    FnVCCB_FreeConditionalCellInfoForIndex(ptCi, ptCondCell->condCellIdx);
}

/****************************************************
 * @brief      This function is responsible for the Setup Process in the 'FnVCCB_ConditionalCellConfigCommit' function.
 * @param[in]  ptCi       : call information / callInfo_type
 * @param[in]  ptCondCell : pointer of conditional cell information / conditionalCellInfo_type
 * @return     void
 ****************************************************/
VCCB_STATIC_INLINE
void FnVCCB_ConditionalCellConfigCommit_AddModProcess(callInfo_type *ptCi, conditionalCellInfo_type *ptCondCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptCondCell);

    // Transition to Idle.
    SET_COND_CELL_STATUS(ptCi, ptCondCell->condCellIdx, Common_Idle);
}

/****************************************************
 * @brief      This function performs the final application of Cell Configuration used for Conditional Handover.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
void FnVCCB_ConditionalCellConfigCommit(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (FnVCCB_IsEmptyConditionalCell(ptCi)) return;

    for (uint8_t condCellIdx = 0; condCellIdx < MAX_NUM_COND_CELLS; condCellIdx++)
    {
        conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForIndex(ptCi, condCellIdx);

        if (ptCondCell == NULL) continue;

        switch (ptCondCell->condStatus)
        {
            case Common_FailToSetup:
            case Common_Release:
                FnVCCB_ConditionalCellConfigCommit_ReleaseProcess(ptCi, ptCondCell);
                continue;

            case Common_Setup:
            case Common_Modify:
                FnVCCB_ConditionalCellConfigCommit_AddModProcess(ptCi, ptCondCell);
                continue;
            default:
                continue;
        }
    }

    // All Conditional Cell Release Case
    if (FnVCCB_IsEmptyConditionalCell(ptCi))
    {
        FnVCCB_InitializationChoDbForExecution(ptCi);
        FnVCCB_InitCondHoInfo(ptCi);
    }
}

/****************************************************
 * @brief      This function determines whether it is necessary to transmit
 *             RRC Reconfiguration to change the configuration of Conditional Handover.
 * @return     bool { true / false }
 ****************************************************/
bool FnVCCB_ApplyConditionalCellConfig_NeedRRCReconfiguration(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (GET_RRC_CONNECTION_FLAG(ptCi->flag.setupFlag) == false) return false;

    uint8_t activeRrcCount = 0;

    for (uint8_t condCellIdx = 0; condCellIdx < MAX_NUM_COND_CELLS; condCellIdx++)
    {
        conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForIndex(ptCi, condCellIdx);

        if (ptCondCell == NULL) continue;

        if (ptCondCell->flag.rrc_activation_flag == FALSE) continue;

        activeRrcCount++;
    }

    if (activeRrcCount > 0) return true;

    return false;
}

/****************************************************
 * @brief      This function performs the necessary control operation for each scenario.
 * @return     int16_t { GOOD / ERROR }
 ****************************************************/
int16_t FnVCCB_ApplyConditionalCellConfig_ScenarioProcessing(
    callInfo_type *ptCi, enumConditionalHandoverApplyScenarioType scenario)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    switch (scenario)
    {
        /* Non-RACH - with RRC Reconfiguration Scenario */
        case e_ChoApplyByConditionalHandoverCancel:
        case e_ChoApplyByReleaseTimerExpiry:
        case e_ChoApplyByReconfigQueue:
            // Partial Release, It is selected and called before calling this function.
            break;

        /* RACH without RRC Reconfiguration Scenario */
        case e_HandoverComplete:
            FnVCCB_SetConditionalCellReleaseAllEvent(ptCi, false, CHO_CandidateRel_gNBCancel);
            FnVCCB_InitializationChoDbForExecution(ptCi);
            break;

        case e_ChoApplyByConditionalHandoverExecution:
            FnVCCB_SetConditionalCellReleaseAllEvent(ptCi, true, CHO_CandidateRel_gNBCancel);
            // FnVCCB_InitializationChoDbForExecution(ptCi);
            break;

        case e_ChoApplyByRRE:
            FnVCCB_SetConditionalCellReleaseAllEvent(ptCi, false, CHO_CandidateRel_gNBCancel);
            FnVCCB_InitializationChoDbForExecution(ptCi);
            break;

        /* UE doing RRC release */
        case e_ChoApplyByRRCSuspend:
        case e_ChoApplyByUeRelease:
            FnVCCB_SetConditionalCellReleaseAllEvent(ptCi, false, CHO_CandidateRel_gNBCancel);
            FnVCCB_InitializationChoDbForExecution(ptCi);
            break;

        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "Unknown CHO Commit Scenario(%u)!\n", (int)scenario);
            return ERROR;
    }

    return GOOD;
}

/****************************************************
 * @brief      This function is an operation to apply Conditional Cell Config of Conditional Handover.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  withRRC : Whether to send RRC Reconfiguration / bool
 * @return     void
 ****************************************************/
int16_t FnVCCB_ApplyConditionalCellConfig(callInfo_type *ptCi, enumConditionalHandoverApplyScenarioType scenario)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    // If numOfCellList zero, ignore.
    if (FnVCCB_IsEmptyConditionalCell(ptCi)) return GOOD;

    // Actions defined for each scenario are performed.
    status = FnVCCB_ApplyConditionalCellConfig_ScenarioProcessing(ptCi, scenario);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_ApplyConditionalCellConfig_ScenarioProcessing Error\n");

    // Debug Print
    if (e_ChoApplyByUeRelease != scenario) FnVCCB_PrintConditionalHandoverStatus(ptCi);

    // Determines whether the RRC Reconfiguration procedure is necessary and changes the state if necessary.
    if (FnVCCB_ApplyConditionalCellConfig_NeedRRCReconfiguration(ptCi) == true)
    {
        // A procedure for RRC Reconfiguration transmission and control is performed.
        return FnVCCB_NextStep_CondReconfig(ptCi);
    }

    // If RRC Reconfiguration is not required, the Commit operation is performed immediately.
    FnVCCB_ConditionalCellConfigCommit(ptCi);

    return GOOD;
}

/****************************************************
 * @brief      This function outputs the status of Conditional DB.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
void FnVCCB_PrintConditionalHandoverStatus(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    const uint32_t localStrSize = 300;

    char logBuf[localStrSize];
    int strLen = 0;

    uint8_t condCellCount[Common_STATUS_END];
    uint8_t condCellId[Common_STATUS_END][MAX_NUM_COND_CELLS];

    // Not Activation Conditional Handover
    if (FnVCCB_IsEmptyConditionalCell(ptCi)) return;

    memset(&condCellCount, 0x00, sizeof(condCellCount));
    memset(&condCellId, 0x00, sizeof(condCellId));

    for (uint8_t condCellIdx = 0; condCellIdx < MAX_NUM_COND_CELLS; condCellIdx++)
    {
        conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForIndex(ptCi, condCellIdx);

        if (ptCondCell == NULL) continue;

        if (ptCondCell->condStatus >= Common_STATUS_END) continue;

        const uint8_t writeIndex = condCellCount[ptCondCell->condStatus]++;

        condCellId[ptCondCell->condStatus][writeIndex] = condCellIdx;
    }

    LOGBUF(logBuf, localStrSize, &strLen, "(*CHO) Cell Cnt:%u ", ptCi->condHoInfo.numOfCellList);

    for (uint8_t condStatusIdx = 0; condStatusIdx < Common_STATUS_END; condStatusIdx++)
    {
        if (condCellCount[condStatusIdx] == 0) continue;

        if (condStatusIdx > 0)
        {
            LOGBUF(logBuf, localStrSize, &strLen, ", ");
        }

        LOGBUF(logBuf, localStrSize, &strLen, "%s:(", FnVCCB_GetStrCommonStatus((enumCommonStatus_type)condStatusIdx));

        const uint8_t maxLen = MIN(condCellCount[condStatusIdx], MAX_NUM_COND_CELLS);

        for (uint8_t condCellIdxInList = 0; condCellIdxInList < maxLen; condCellIdxInList++)
        {
            uint8_t condCellIdx = condCellId[condStatusIdx][condCellIdxInList];

            LOGBUF(logBuf, localStrSize, &strLen, "%u", condCellIdx);

            if (condStatusIdx != Common_Idle)
            {
                LOGBUF(logBuf, localStrSize, &strLen, ":%llu", ptCi->condHoInfo.cellList[condCellIdx].nrcgi.ci * 1ULL);
            }

            if (condCellIdxInList < (maxLen - 1))
            {
                LOGBUF(logBuf, localStrSize, &strLen, ",");
            }
        }

        LOGBUF(logBuf, localStrSize, &strLen, ")");
    }

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "%.*s\n", localStrSize, logBuf);
}

/****************************************************
 * @brief      This function provides the procedure to update the Conditional Cell Info DB based on FLAG.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
void FnVCCB_UpdateConditionalCellInfoFromFlag(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    for (uint8_t condCellIdx = 0; condCellIdx < MAX_NUM_COND_CELLS; condCellIdx++)
    {
        conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForIndex(ptCi, condCellIdx);

        if (ptCondCell == NULL) continue;

        if (ptCondCell->flag.to_be_release == TRUE)
        {
            FnVCCB_SetConditionalCellReleaseEvent(ptCi, ptCondCell, (enumChoStatType)ptCondCell->statCause);
        }
    }
}

/****************************************************
 * @brief      This function provides the action to be performed while changing to Common Release.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ptCondCell : conditional cell information / conditionalCellInfo_type
 * @return     void
 ****************************************************/
void FnVCCB_SetConditionalCellReleaseEvent(
    callInfo_type *ptCi, conditionalCellInfo_type *ptCondCell, enumChoStatType statCause)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptCondCell);

    // candidate-cell-release-timer-source
    // candidate-cell-release-timer-target
    FnVCCB_CancelConditionalCellTimer(ptCondCell, CANCEL_TIMER);

    SET_COND_CELL_STATUS(ptCi, ptCondCell->condCellIdx, Common_Release);

    if (ptCondCell->flag.collectableCandidateRelStat == TRUE)
    {
        CHO_STAT(ptCi, statCause, ptCondCell->nrcgi);
    }
}

/****************************************************
 * @brief      This function provides an action to be taken while all Conditional Cells change to Common Release.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
void FnVCCB_SetConditionalCellReleaseAllEvent(callInfo_type *ptCi, bool excludeExecution, enumChoStatType statCause)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (FnVCCB_IsEmptyConditionalCell(ptCi)) return;

    for (uint8_t condCellIdx = 0; condCellIdx < MAX_NUM_COND_CELLS; condCellIdx++)
    {
        conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForIndex(ptCi, condCellIdx);

        if (ptCondCell == NULL) continue;

        if (excludeExecution == true && ptCondCell->flag.run_execution == TRUE) continue;

        if (ptCondCell->condStatus == Common_Setup || ptCondCell->condStatus == Common_FailToSetup)
        {
            CHO_STAT(ptCi, CHO_PrepFail_gNBFail, ptCi->hoInfo.cgi);
        }

        FnVCCB_SetConditionalCellReleaseEvent(ptCi, ptCondCell, statCause);
    }
}

/****************************************************
 * @brief      This function provides the action to be performed while changing to Common Modify.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ptCondCell : conditional cell information / conditionalCellInfo_type
 * @return     void
 ****************************************************/
void FnVCCB_SetConditionalCellModifyEvent(callInfo_type *ptCi, conditionalCellInfo_type *ptCondCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptCondCell);

    SET_COND_CELL_STATUS(ptCi, ptCondCell->condCellIdx, Common_Modify);
}

/****************************************************
 * @brief      This function provides the action to be performed while changing to Common FailToSetup.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ptCondCell : conditional cell information / conditionalCellInfo_type
 * @return     void
 ****************************************************/
void FnVCCB_SetConditionalCellFailToSetupEvent(callInfo_type *ptCi, conditionalCellInfo_type *ptCondCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptCondCell);

    SET_COND_CELL_STATUS(ptCi, ptCondCell->condCellIdx, Common_FailToSetup);
}

/****************************************************
 * @brief      This function controls Conditional Handover queuing and behavior handled by AllState.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  scenario : conditional apply secnario / enumConditionalHandoverApplyScenarioType
 * @return     void
 ****************************************************/
void FnVCCB_HandlingConditionalHandoverEvent(callInfo_type *ptCi, enumConditionalHandoverApplyScenarioType scenario)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    int16_t status = GOOD;

    // Protection Code
    FnVCCB_UpdateConditionalCellInfoFromFlag(ptCi);

    status = FnVCCB_ApplyConditionalCellConfig(ptCi, scenario);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_ApplyConditionalCellConfig ERROR!!\n");
        return;
    }
}

/****************************************************
 * @brief      This function controls the handling of when a Conditional Handover Event is received from AllState.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  scenario : conditional apply secnario / enumConditionalHandoverApplyScenarioType
 * @return     void
 ****************************************************/
void FnVCCB_SetConditionalCellEventInAllState(
    callInfo_type *ptCi, conditionalCellInfo_type *ptCondCell, enumChoStatType statCause)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptCondCell);

    if (VCCM_IsUeIdleState(ptCi->callType, ptCi->state) == TRUE)
    {
        FnVCCB_SetConditionalCellReleaseEvent(ptCi, ptCondCell, statCause);
        return;
    }

    ptCondCell->flag.to_be_release = TRUE;

    if (ptCondCell->statCause >= CHO_TYPE_MAX) ptCondCell->statCause = statCause;
}

/****************************************************
 * @brief      This function controls the handling of when a Conditional Handover Event is received from AllState.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  scenario : conditional apply secnario / enumConditionalHandoverApplyScenarioType
 * @return     void
 ****************************************************/
void FnVCCB_ProcRecvConditionalCellEventInAllState(
    callInfo_type *ptCi, enumConditionalHandoverApplyScenarioType scenario)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (VCCM_IsUeIdleState(ptCi->callType, ptCi->state) == TRUE)
    {
        FnVCCB_HandlingConditionalHandoverEvent(ptCi, scenario);
        return;
    }

    // Not-Idle - Queueuing

    FnVCCB_StartConditionalHandoverQueuingProcedure(ptCi, "ProcRecvConditionalCellEventInAllState");
}

/****************************************************
 * @brief      This function adds to the queue for Conditional Handover Event queuing.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  scenario : conditional apply secnario / enumConditionalHandoverApplyScenarioType
 * @return     void
 ****************************************************/
void FnVCCB_StartConditionalHandoverQueuingProcedure(callInfo_type *ptCi, const char *ptStrEventName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    VCCB_PRINT_CALL_SA_CHO(ptCi, "(*CHO) Start CHO QueuingProcedure by %s\n", ptStrEventName);

    if (ERROR == VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_CONDITIONAL_CELL_RECONFIG))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "(*CHO) VCCM_enqueueAction(ENQUEUE_ACTION_CONDITIONAL_CELL_RECONFIG) in %s fail\n", __FUNCTION__);
        return;
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "ENQUEUE_ACTION_CONDITIONAL_CELL_RECONFIG: Enqueued\n");
}

/****************************************************
 * @brief      This function decides to perform Conditional Handover after completing the current procedure.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ptStrEventName : string of event / const char*
 * @return     void
 ****************************************************/
void FnVCCB_StartConditionalHandoverAfterCompletionOfCurrentProcedure(callInfo_type *ptCi, const char *ptStrEventName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, ptStrEventName);

    VCCB_PRINT_CALL_SA_CHO(ptCi, "(*CHO) Start CHO After Complete Of Current Procedure by %s\n", ptStrEventName);

    // If CHO Execution occurs during IM HO, statistics are not collected.
    VLIB_InitHoStat(ptCi);

    ptCi->condHoInfo.flag.stopAndConditionalHandoverTrigger = TRUE;
}

/****************************************************
 * @brief      This function forcibly suspends the current procedure and performs Conditional Handover.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ptStrEventName : string of event / const char*
 * @return     void
 ****************************************************/
int16_t FnVCCB_StartConditionalHandoverAfterForcedStopOfCurrentProcedure(
    callInfo_type *ptCi, const char *ptStrEventName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR_PARAM2(ptCi, ptStrEventName);

    int16_t status = GOOD;

    VCCB_PRINT_CALL_SA_CHO(ptCi, "(*CHO) Start CHO After Forced Stop Of Current Procedure by %s\n", ptStrEventName);

#ifdef IPC_TEST
    FnVCCB_TxStopAllDisable(ptCi);
#endif

    // If CHO Execution occurs during IM HO, statistics are not collected.
    VLIB_InitHoStat(ptCi);

    // Response initialization according to forced start
    VLIB_ClearAllRespFlags(ptCi);

    // Disable the timer used in the previous procedure.
    VCCB_CLEAR_TIMER(&ptCi->timer, CANCEL_TIMER);

    VCOM_SaHandoverCancel_ToConn_Core(ptCi, XN_HandoverSuccess_id);

    status = FnVCCB_StartConditionalHandoverExecutionProcedure(ptCi, HO_TYPE_INTER_NB_SOURCE);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_StartConditionalHandoverExecutionProcedure ERROR !!\n");

    return GOOD;
}

/****************************************************
 * @brief      This function is used to inform about the drop status.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ptStrEventName : string of event / const char*
 * @return     void
 ****************************************************/
void ConditionalHandoverExecutionHandler::FnVCCB_DropConditionalHandoverMessage(const char *ptStrEventName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, ptStrEventName);

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Drop Handover Success Message by %s\n", ptStrEventName);

    isChoExecution = false;
}

/****************************************************
 * @brief      This function provides the action of queuing the Conditional Handover procedure.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ptStrEventName : string of event / const char*
 * @return     void
 ****************************************************/
int16_t FnVCCB_QueueingConditionalHandoverAfterForcedStopOfCurrentProcedure(
    callInfo_type *ptCi, const char *ptStrEventName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR_PARAM2(ptCi, ptStrEventName);

    VCCB_PRINT_CALL_SA_CHO(ptCi, "(*CHO) Start CHO After Forced Stop Of Current Procedure by %s\n", ptStrEventName);

#ifdef IPC_TEST
    FnVCCB_TxStopAllDisable(ptCi);
#endif

    if (ERROR == VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_CONDITIONAL_HANDOVER_EXECUTION))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "(*CHO) VCCM_enqueueAction(ENQUEUE_ACTION_CONDITIONAL_HANDOVER_EXECUTION) fail !!\n");
    }

    return GOOD;
}

/****************************************************************************
 * @brief           This function defines the action when XN Handover Success is received during the CHO Preparation
 *procedure. FGR-MC1200 Conditional Handover, FR250 Cancel Immediate Handover Procedure by HANDOVER SUCCESS
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t ConditionalHandoverExecutionHandler::FnVCCB_ALL_XnapHandoverSuccessDuringChoPreparation()
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // 1) Receive Xn Handover Success during CHO Preparation
    CHO_STAT(ptCi, CHO_PrepCancel, ptCi->hoInfo.cgi);

    // A. If it is before sending the Xn Handover Request message, after the ongoing procedure is completed,
    //    the CHO Preparation procedure is finished and the CHO Execution procedure is performed.
    if (ptCi->state == STATE_INTER_Pre_DU_S)
    {
        FnVCCB_StartConditionalHandoverAfterCompletionOfCurrentProcedure(ptCi, "[1:A] CHO Preparation");
        return GOOD;
    }

    // B. After sending the Xn Handover Request message, immediately stop the ongoing procedure and
    //    perform the CHO execution procedure.
    return FnVCCB_StartConditionalHandoverAfterForcedStopOfCurrentProcedure(ptCi, "[1:B] Send Handover Request");
}

/****************************************************************************
 * @brief           This function defines the action when XN Handover Success is received during the CHO Candidate Cell
 *Release. FGR-MC1200 Conditional Handover, FR250 Cancel Immediate Handover Procedure by HANDOVER SUCCESS
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t ConditionalHandoverExecutionHandler::FnVCCB_ALL_XnapHandoverSuccessDuringChoAddModRel()
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    bool isOtherCellRelease = true;

    // 2) Receive Xn Handover Success during CHO Candidate Cell Release

    // A. If Xn Handover Success is received before RRCReconfigurationComplete is received,
    //    the release procedure is stopped and the CHO Execution procedure is performed.
    if (GET_RRC_RECONFIG_FLAG(ptCi->flag.respFlag))
    {
        conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForCGI(ptCi, ptCi->condHoInfo.targetCgi);
        VALID_E_POINT_CHECK_ERROR(ptCondCell);

        // Common_Idle/Common_Release -> Common_Idle
        ptCondCell->flag.to_be_release = FALSE;
        SET_COND_CELL_STATUS(ptCi, ptCondCell->condCellIdx, Common_Idle);

        return FnVCCB_StartConditionalHandoverAfterForcedStopOfCurrentProcedure(
            ptCi, "[2:A] Received before RRCReconfigurationComplete");
    }

    // B. If the release procedure for a Candidate Cell other than the CHO Target cell (which has transmitted Xn
    // Handover Success) is being performed,
    //    the CHO Execution procedure is performed after the Candidate Cell release procedure is completed.
    for (uint8_t condCellIdx = 0; condCellIdx < MAX_NUM_COND_CELLS; condCellIdx++)
    {
        conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForIndex(ptCi, condCellIdx);

        if (ptCondCell == NULL) continue;

        if (ptCondCell->condStatus != Common_Release) continue;

        if (FnVCCB_CheckCgiIdentical(&ptCi->condHoInfo.targetCgi, &ptCondCell->nrcgi) == FALSE) continue;

        VCCB_PRINT_CALL_ERROR(
            ptCi, "(*CHO) [2:B-1] Handover Success was received, but this Cell is in the process of releasing it.\n");
        isOtherCellRelease = false;
        break;
    }

    if (isOtherCellRelease == true)
    {
        FnVCCB_QueueingConditionalHandoverAfterForcedStopOfCurrentProcedure(
            ptCi, "[2-B] Other Conditional Cell Control");
        return GOOD;
    }

    FnVCCB_DropConditionalHandoverMessage("[2-B-2] Handover Success Ignore");

    return GOOD;
}

/****************************************************************************
 * @brief           This function defines the action when XN Handover Success is received during Intra-gNB, Intra-DU
 *Handover Procedure FGR-MC1200 Conditional Handover, FR250 Cancel Immediate Handover Procedure by HANDOVER SUCCESS
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t ConditionalHandoverExecutionHandler::FnVCCB_ALL_XnapHandoverSuccessDuringIntraGnbIntraDuHandover()
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // 3) Receive Xn Handover Success during Intra-gNB, Intra-DU Handover Procedure

    // A. NRDC Configured UE
    if (IS_MRDC_MN(ptCi))
    {
        // i.If the SCG Configuration Query procedure is in progress, perform the CHO Execution procedure after
        // completing the procedure.
        if (ptCi->state == STATE_INTRA_DU_SnQuery)
        {
            FnVCCB_StartConditionalHandoverAfterCompletionOfCurrentProcedure(ptCi, "[3:A:i] Intra-DU Handover, Query");
            return GOOD;
        }

        // ii. Other than that, the Handover Success message received after the SN Addition/Modification/Release message
        //     that can change the SN UE Context is transmitted to the S-NODE is ignored.
        FnVCCB_DropConditionalHandoverMessage("[3:A:ii] Handover Success Ignore");

        return GOOD;
    }

    // B. NRDC Not Configured UE

    // i. If the E1 Bearer Context Modification (DL Tx Stop) procedure is in progress,
    //    the CHO Execution procedure is performed after the ongoing procedure is completed.
    if (ptCi->state == STATE_INTRA_DU_E1Stop)
    {
        FnVCCB_StartConditionalHandoverAfterCompletionOfCurrentProcedure(ptCi, "[3:B:i] Intra-DU Handover, E1 TX Stop");
        return GOOD;
    }

    // ii. If the F1 UE Context Modification procedure for Target Cell Preparation is in progress,
    //     perform the CHO Execution procedure after completing the ongoing procedure.
    if (ptCi->state == STATE_INTRA_DU_Prepare)
    {
        FnVCCB_StartConditionalHandoverAfterCompletionOfCurrentProcedure(
            ptCi, "[3:B:ii] Intra-DU Handover, F1 TX Stop, HO CMD");
        return GOOD;
    }

    // iii. If Handover Success is received after RRCReconfiguration(HandoverCommand) is transmitted and
    //      before RRCReconfigurationComplete is received, the CHO execution procedure is performed immediately.
    if (ptCi->state == STATE_INTRA_DU_Execution && GET_RRC_RECONFIG_FLAG(ptCi->flag.respFlag))
    {
        return FnVCCB_StartConditionalHandoverAfterForcedStopOfCurrentProcedure(
            ptCi, "[3:B:iii] received after RRCReconfiguration");
    }

    // iv. After receiving the RRCReconfigurationComplete message, the Handover Success message cannot be received,
    //     and even if it is received, it is ignored.

    FnVCCB_DropConditionalHandoverMessage("[3:B:iv] Handover Success Ignore");
    return GOOD;
}

/****************************************************************************
 * @brief           This function defines the action when XN Handover Success is received during Intra-gNB, Inter-DU
 *Handover Procedure FGR-MC1200 Conditional Handover, FR250 Cancel Immediate Handover Procedure by HANDOVER SUCCESS
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t ConditionalHandoverExecutionHandler::FnVCCB_ALL_XnapHandoverSuccessDuringIntraGnbInterDuHandover()
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // 4) Receive Xn Handover Success during Intra-gNB, Inter-DU Handover Procedure

    // A.i.If the SCG Configuration Query procedure is in progress, perform the CHO Execution procedure after completing
    // the procedure. A.z Process the same in the DU Configuration Query procedure.
    if (ptCi->state == STATE_INTER_DU_DuQuery)
    {
        FnVCCB_StartConditionalHandoverAfterCompletionOfCurrentProcedure(ptCi, "[4:A:i/z] Inter-DU Handover, Du-Query");
        return GOOD;
    }

    // A. NRDC Configured UE
    if (IS_MRDC_MN(ptCi))
    {
        // ii. Other than that, the Handover Success message received after the SN Addition/Modification/Release message
        //     that can change the SN UE Context is transmitted to the S-NODE is ignored.

        FnVCCB_DropConditionalHandoverMessage("[4:A:ii] Handover Success Ignore");
        return GOOD;
    }

    // B. NRDC Not Configured UE

    // i. If the F1 UE Context Supt procedure (with Target DU) is in progress, the CHO Execution procedure is performed
    //    after the ongoing procedure is completed.
    // ii.If the E1 Bearer Context Modification (DL Tx Stop) procedure is in progress, the CHO Execution procedure is
    // performed
    //    after the ongoing procedure is completed.
    if (ptCi->state == STATE_INTER_DU_Prepare)
    {
        FnVCCB_StartConditionalHandoverAfterCompletionOfCurrentProcedure(
            ptCi, "[4:B:i/ii] Inter-DU Handover, TgtDu Setup/F1 TX Stop");
        return GOOD;
    }

    // iii. When the F1 UE Context Modification procedure for RRCReconfiguration (HandoverCommand) transmission is in
    // progress,
    //      the CHO Execution procedure is performed after the ongoing procedure is completed.
    if (ptCi->state == STATE_INTER_DU_Execution && GET_F1_CTXT_MODRSP_FLAG(ptCi->flag.respFlag))
    {
        // It is a situation in which the UE cannot upload a response to the Handover Command to the Target DU.
        OFF_RRC_RECONFIG_FLAG(ptCi->flag.respFlag);

        FnVCCB_StartConditionalHandoverAfterCompletionOfCurrentProcedure(
            ptCi, "[4:B:iii] Inter-DU Handover, received after F1 Mod Resp");
        return GOOD;
    }

    // iv. If Handover Success is received after RRCReconfiguration(HandoverCommand) is transmitted
    //     and before RRCReconfigurationComplete is received, the CHO execution procedure is performed immediately.
    if (ptCi->state == STATE_INTER_DU_Execution && GET_RRC_RECONFIG_FLAG(ptCi->flag.respFlag))
    {
        return FnVCCB_StartConditionalHandoverAfterForcedStopOfCurrentProcedure(
            ptCi, "[4:B:iv] received after RRCReconfiguration");
    }

    // v. After receiving the RRCReconfigurationComplete message, the Handover Success message cannot be received,
    //    and even if it is received, it is ignored.

    FnVCCB_DropConditionalHandoverMessage("[4:B:v] Handover Success Ignore");
    return GOOD;
}

/****************************************************************************
 * @brief           This function defines the action when XN Handover Success is received during Inter-gNB Handover
 *Procedure FGR-MC1200 Conditional Handover, FR250 Cancel Immediate Handover Procedure by HANDOVER SUCCESS
 *
 * @param[in/out]   ptCi : Call information / callInfo_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t ConditionalHandoverExecutionHandler::FnVCCB_ALL_XnapHandoverSuccessDuringInterGnbHandover()
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // 5) Receive Xn Handover Success during Inter-gNB Handover Procedure

    // A. If it is before the Handover Request message is transmitted, the CHO execution procedure is performed after
    // the ongoing procedure is completed.
    if (ptCi->state == STATE_INTER_Pre_DU_S)
    {
        FnVCCB_StartConditionalHandoverAfterCompletionOfCurrentProcedure(
            ptCi, "[5:A] Inter-gNB Handover, Not Send HandoverRequest");
        return GOOD;
    }

    // B. When a Handover Response message is received,
    // iv. If a Bearer Context Modification Request (STATE_INTER_SeqNum_S) for transmitting PDCP SN Status and Data
    // Forwarding information is transmitted,
    //     CHO Execution cannot be performed, and the received message is ignored and the existing procedure is
    //     performed.
    if (ptCi->state >= STATE_INTER_SeqNum_S)
    {
        FnVCCB_DropConditionalHandoverMessage("[5:B:iv] Handover Success Ignore");
        return GOOD;
    }

    // i. Sending a Handover Cancel message.
    // ii. If the F1 UE Context Modification procedure (Tx Stop, Transfer Handover Command) is in progress, wait until
    // the procedure is completed
    // iii. If E1 Bearer Context Modfication (DL Tx Stop) is in progress, wait until the procedure is completed.
    OFF_RRC_RECONFIG_FLAG(ptCi->flag.respFlag);
    FnVCCB_StartConditionalHandoverAfterCompletionOfCurrentProcedure(ptCi, "[5:B:i/ii/iii] Action after HO Ack");
    return GOOD;
}

/****************************************************
 * @brief      This function provides the settings to perform the Conditional Execution procedure.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ptStrEventName : string of event / const char*
 * @return     void
 ****************************************************/
int16_t FnVCCB_ProcConditionalExecutionCell(callInfo_type *ptCi, cgi_type execNrCgi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForCGI(ptCi, execNrCgi);
    if (ptCondCell == NULL)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Not Found Conditional Cell Information (%X/%lu)\n", execNrCgi.plmn.longId, execNrCgi.ci);
        return ERROR;
    }

    ptCondCell->flag.run_execution = TRUE;

    // Common_Idle/Common_Release -> Common_Idle
    ptCondCell->flag.to_be_release = FALSE;
    SET_COND_CELL_STATUS(ptCi, ptCondCell->condCellIdx, Common_Idle);

    // Change Cell State From Prepared To Execution.
    {
        // If Execution is triggered, it does not need to be collected anymore.
        ptCondCell->flag.collectableCandidateRelStat = FALSE;

        if (ptCi->hoInfo.isTarget == TRUE)
        {
            // No Response
            ptCondCell->flag.to_resp_cho_cancel = FALSE;
        }
    }

    // Not RRC Reconfiguration - UE has already moved.
    status = FnVCCB_ApplyConditionalCellConfig(ptCi, e_ChoApplyByConditionalHandoverExecution);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_ApplyConditionalCellConfig ERROR!\n");
        // return ERROR; // Ignore
    }

    FnVCCB_SetHandoverExecution(ptCi);

    return GOOD;
}

/****************************************************
 * @brief      This function provides the procedure to perform the Conditional Handover Execution procedure. For
 *Source-GNB
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ptStrEventName : string of event / const char*
 * @return     void
 ****************************************************/
int16_t FnVCCB_StartConditionalHandoverExecutionProcedure_SourceGNB(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    int16_t status = GOOD;
    uint16_t nbrIdx = MAX_NBR_PER_CELL;
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    for (nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)
    {
        if (pCell->Nbr[nbrIdx].status != EQUIP) continue;

        cgi_type nbrCgi;

        status = FnVCCB_Fill_CellNbr_NRCGI(ptCi->servCellNum, nbrIdx, &nbrCgi);
        if (status == ERROR) continue;

        if (FnVCCB_CheckCgiIdentical(&nbrCgi, &ptCi->condHoInfo.targetCgi) == FALSE) continue;

        break;
    }

    if (nbrIdx >= MAX_NBR_PER_CELL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Found Target Nbr Cell!\n");  // TODO :: Use Case?
        return ERROR;
    }

    auto hoInputDb = StartSaHandoverDb();
    status = VHCM_StartSaHandover_IntergNB(ptCi, nbrIdx, HoPurpose_DLQuality, e_HoTrigger_ConditionalHandoverExec, hoInputDb);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VHCM_StartSaHandover_IntergNB(CHO) ERROR !!\n");

    return GOOD;
}

/****************************************************
 * @brief      This function provides the procedure to perform the Conditional Handover Execution procedure. For
 *Target-GNB
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ptStrEventName : string of event / const char*
 * @return     void
 ****************************************************/
int16_t FnVCCB_StartConditionalHandoverExecutionProcedure_TargetGNB(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;
    cgi_type &cgi = ptCi->condHoInfo.targetCgi;

    status = FnVCCB_ProcConditionalExecutionCell(ptCi, cgi);
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, status, "FnVCCB_ProcConditionalExecutionCell(%X/%lu) ERROR !!\n", cgi.plmn.longId, cgi.ci);

    status = FnVCCB_SendXNMessage(XN_HandoverSuccess_id, ptCi, nullptr, nullptr);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_HandoverSuccess) ERROR!\n");

    return GOOD;
}

/****************************************************
 * @brief      This function provides the procedure to perform the Conditional Handover Execution procedure.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ptStrEventName : string of event / const char*
 * @return     void
 ****************************************************/
int16_t FnVCCB_StartConditionalHandoverExecutionProcedure(callInfo_type *ptCi, enumHoTypeInterNb interNbType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (interNbType == HO_TYPE_INTER_NB_SOURCE)
    {
        // XN Handover Success is received, the UE has already moved, so initialize RRC_CONNECTION_FLAG.
        OFF_RRC_CONNECTION_FLAG(ptCi->flag.setupFlag);  // RRC Connection Release

        FnVCCB_InitializationChoDbForExecution(ptCi);  // SA, Inter-GNB HO, XN/NG, Source

        return FnVCCB_StartConditionalHandoverExecutionProcedure_SourceGNB(ptCi);
    }

    return FnVCCB_StartConditionalHandoverExecutionProcedure_TargetGNB(ptCi);
}

/****************************************************
 * @brief      This is an operation for resource initialization and UE resource collective initialization by RACH.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
VCCB_STATIC_INLINE
void FnVCCB_ClearRrcActivationFlag(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    for (uint8_t condCellIdx = 0; condCellIdx < MAX_NUM_COND_CELLS; condCellIdx++)
    {
        conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForIndex(ptCi, condCellIdx);

        if (ptCondCell == NULL) continue;

        ptCondCell->flag.rrc_activation_flag = FALSE;
    }
}

/****************************************************
 * @brief      This function is the initialization content for the operation related to Conditional Handover when RACH
 *occurs.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
void FnVCCB_InitializationChoDbForExecution(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // Initializes whether the UE activates the Conditional Cell.
    FnVCCB_ClearRrcActivationFlag(ptCi);

    // Initialize Execution Meas related settings.
    VCCB_ClearCondTriggerConfigFromMeasConfiguration(ptCi);
}

/****************************************************
 * @brief      Defines the action when the Conditional Handover receives Complete from other than the specified state
 *machine.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
void FnVCCB_AppendConditionalReconfiguration_r16_ForReconfigurationComplete(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    for (uint8_t condCellIdx = 0; condCellIdx < MAX_NUM_COND_CELLS; condCellIdx++)
    {
        conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForIndex(ptCi, condCellIdx);

        if (ptCondCell == NULL) continue;

        switch (ptCondCell->condStatus)
        {
            case Common_Release:
                ptCondCell->flag.rrc_activation_flag = FALSE;
                break;

            case Common_Setup:
                ptCondCell->flag.rrc_activation_flag = TRUE;
                break;

            default:
                break;
        }
    }
}

/****************************************************
 * @brief      This function is called when RRC Reconfiguration is transmitted.
 *             Decide whether to append Reconfiguration data for Release in Conditional Handover.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ptStrEventName : string of event / const char*
 * @return     void
 ****************************************************/
bool FnVCCB_IsAppendConditionalReconfiguration_r16_ForReconfiguration(callInfo_type *ptCi)
{
    if (FnVCCB_IsEmptyConditionalCell(ptCi)) return false;

    // #1) If it is not the CHO Preparation procedure,
    // all set CHO ConditionalReconfiguration information is canceled and the release information is transmitted to the
    // terminal.
    if (FnVCCB_IsChoPreparationPhase(ptCi))
    {
        return false;
    }
    else if (FnVCCB_IsChoExecutionPhase(ptCi))
    {
        return true;
    }

    // #2) Other Conditional State
    switch (ptCi->state)
    {
        // case STATE_INTER_CondReconf_S: // include "Cond #1"
        case STATE_CondReconfig:
            return false;

        // CELL Change
        case STATE_INTRA_DU_Execution:  // by IntraGNB IntraDU
        case STATE_INTER_DU_Execution:  // by IntraGNB InterDU
        case STATE_INTER_Exe_S:         // by InterGNB Source
            return false;

        default:
            return true;
    }
}

template <typename currentIE, typename nonCriticalIE>
void FnVCCB_ActivationNonCriticalIE(currentIE &ptCurIE, unsigned char bitMask, nonCriticalIE &ptExtIE, bool &needClearFlag)
{
    AUTO_TRACE_FUNC;

    // If it was Extension IE that was not included, the BitMask field should be initialized afterwards.
    if (!(ptCurIE->bit_mask & bitMask)) needClearFlag = true;

    ptCurIE->bit_mask |= bitMask;
    ptExtIE = &ptCurIE->nonCriticalExtension;

    if (needClearFlag == true) ptExtIE->bit_mask = 0;
}

void FnVCCB_ActivationNonCriticalIE_ForV1610(callInfo_type *ptCi, void *ptIE_void)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, ptIE_void);

    bool isClearBitMask = false;

    NRRRC_RRCReconfiguration_IEs *ptIE = (NRRRC_RRCReconfiguration_IEs *)ptIE_void;
    NRRRC_RRCReconfiguration_v1530_IEs *ptIE_v1530 = NULL;
    NRRRC_RRCReconfiguration_v1540_IEs *ptIE_v1540 = NULL;
    NRRRC_RRCReconfiguration_v1560_IEs *ptIE_v1560 = NULL;
    NRRRC_RRCReconfiguration_v1610_IEs *ptIE_v1610 = NULL;

    FnVCCB_ActivationNonCriticalIE(
        ptIE, NRRRC_RRCReconfiguration_IEs_nonCriticalExtension_present, ptIE_v1530, isClearBitMask);
    FnVCCB_ActivationNonCriticalIE(
        ptIE_v1530, NRRRC_RRCReconfiguration_v1530_IEs_nonCriticalExtension_present, ptIE_v1540, isClearBitMask);
    FnVCCB_ActivationNonCriticalIE(
        ptIE_v1540, NRRRC_RRCReconfiguration_v1540_IEs_nonCriticalExtension_present, ptIE_v1560, isClearBitMask);
    FnVCCB_ActivationNonCriticalIE(
        ptIE_v1560, NRRRC_RRCReconfiguration_v1560_IEs_nonCriticalExtension_present, ptIE_v1610, isClearBitMask);
}

/****************************************************************
 * Function     : FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo
 *
 * ***************************************************************/
int16_t FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    ptCi->condHoInfo.flag.stopAndConditionalHandoverTrigger = FALSE;

#ifdef IPC_TEST
    FnVCCB_TxStopAllDisable(ptCi);
#endif

    VCOM_SaHandoverCancel_ToConn_Core(ptCi, XN_HandoverSuccess_id);

    if (VCCM_IsUeIdleState(ptCi->callType, ptCi->state) == FALSE)
    {
        status = FnVCCB_QueueingConditionalHandoverAfterForcedStopOfCurrentProcedure(
            ptCi, "Idle return delay, try next time.");
        VCCB_RETURN_ON_CALL_ERROR(
            ptCi, status, "FnVCCB_QueueingConditionalHandoverAfterForcedStopOfCurrentProcedure Error!\n");

        return GOOD;
    }

    status = FnVCCB_StartConditionalHandoverExecutionProcedure(ptCi, HO_TYPE_INTER_NB_SOURCE);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_StartConditionalHandoverExecutionProcedure Error!\n");

    return GOOD;
}  // }}}

/****************************************************************
 * Function     : FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo
 * Description  : Stop moving to the next step and trigger a Conditional Handover.
 * ***************************************************************/
bool FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(const callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    return (ptCi->condHoInfo.flag.stopAndConditionalHandoverTrigger == TRUE);
}

/****************************************************************
 * Function     : FnVCCB_UpdateInterGnbConnectionState_Common
 * Description  : This function controls the FLAG managed in the Handover Source/Target Node.
 * ***************************************************************/
VCCB_STATIC_INLINE
void FnVCCB_UpdateInterGnbConnectionState_Common(callInfo_type *ptCi, cgi_type cgi, FLAG_Type sw,
    void (*pFlagOnOffInCallInfo)(callInfo_type *, FLAG_Type),
    void (*pFlagOnOffInChoCellInfo)(conditionalCellInfo_type *, FLAG_Type))
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM3(ptCi, pFlagOnOffInCallInfo, pFlagOnOffInChoCellInfo);

    // Conditional Handover DB
    if (FnVCCB_IsSetupedConditionalCell(ptCi))
    {
        conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForCGI(ptCi, cgi);
        if (ptCondCell == NULL)
        {
            // no action
        }
        else
        {
            pFlagOnOffInChoCellInfo(ptCondCell, sw);
        }
    }

    // Handover Info DB
    if (VHCM_isSaHandoverUE(ptCi) == TRUE)
    {
        if (FnVCCB_CheckCgiIdentical(&ptCi->hoInfo.cgi, &cgi) == TRUE)
        {
            pFlagOnOffInCallInfo(ptCi, sw);
        }
    }
}

/****************************************************************
 * Function     : FnVCCB_UpdateInterGnbConnectionState_Source
 * Description  : This function controls the FLAG managed in the Handover Source Node.
 * ***************************************************************/
void FnVCCB_UpdateInterGnbConnectionState_Source(callInfo_type *ptCi, cgi_type cgi, FLAG_Type sw)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    auto flagOnOffInCallInfo = [](callInfo_type *_ptCi, FLAG_Type _sw)
    {
        switch (_sw)
        {
            case ON:
                _ptCi->hoInfo.interGnbSrcConnectionFlag = TRUE;
                break;

            default:  // OFF
                _ptCi->hoInfo.interGnbSrcConnectionFlag = FALSE;
                break;
        }
    };

    auto flagOnOffInChoCellInfo = [](conditionalCellInfo_type *_ptCondCell, FLAG_Type _sw)
    {
        switch (_sw)
        {
            case ON:
                _ptCondCell->flag.inter_gnb_s_connection_flag = TRUE;
                break;

            default:  // OFF
                _ptCondCell->flag.inter_gnb_s_connection_flag = FALSE;
                break;
        }
    };

    FnVCCB_UpdateInterGnbConnectionState_Common(ptCi, cgi, sw, flagOnOffInCallInfo, flagOnOffInChoCellInfo);
}

/****************************************************************
 * Function     : FnVCCB_UpdateInterGnbConnectionState_Target
 * Description  : This function controls the FLAG managed in the Handover Target Node.
 * ***************************************************************/
void FnVCCB_UpdateInterGnbConnectionState_Target(callInfo_type *ptCi, cgi_type cgi, FLAG_Type sw)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    auto flagOnOffInCallInfo = [](callInfo_type * _ptCi, FLAG_Type _sw)
    {
        switch (_sw)
        {
            case ON:
                _ptCi->hoInfo.interGnbTgtConnectionFlag = TRUE;
                break;

            default:  // OFF
                _ptCi->hoInfo.interGnbTgtConnectionFlag = FALSE;
                break;
        }
    };

    auto flagOnOffInChoCellInfo = [](conditionalCellInfo_type *_ptCondCell, FLAG_Type _sw)
    {
        switch (_sw)
        {
            case ON:
                _ptCondCell->flag.inter_gnb_t_connection_flag = TRUE;
                break;

            default:  // OFF
                _ptCondCell->flag.inter_gnb_t_connection_flag = FALSE;
                break;
        }
    };

    FnVCCB_UpdateInterGnbConnectionState_Common(ptCi, cgi, sw, flagOnOffInCallInfo, flagOnOffInChoCellInfo);
}

bool FnVCCB_IsChoPreparationPhase(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // Not Cho Handover
    if (FnVCCB_IsConditionalHandoverUE(ptCi) == FALSE) return false;

    // Not Cho Preparation Phase
    if (ptCi->hoInfo.handoverExecutionFlag == TRUE) return false;

    return true;
}

bool FnVCCB_IsChoExecutionPhase(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // Not Cho Handover
    if (FnVCCB_IsConditionalHandoverUE(ptCi) == FALSE) return false;

    // Not Cho Execution Phase
    if (ptCi->hoInfo.handoverExecutionFlag == FALSE) return false;

    return true;
}

int16_t ConditionalHandoverExecutionHandler::FnVCCB_ALL_XnapHandoverSuccessDuringRaceCondition()
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    // 1) Receive Xn Handover Success during CHO Preparation
    if (FnVCCB_IsChoPreparationPhase(ptCi))
    {
        status = FnVCCB_ALL_XnapHandoverSuccessDuringChoPreparation();
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "(*CHO) FnVCCB_ALL_XnapHandoverSuccessDuringChoPreparation ERROR!\n");
        return GOOD;
    }

    // 2) Receive Xn Handover Success during CHO Candidate Cell Release
    if (ptCi->state == STATE_CondReconfig)
    {
        status = FnVCCB_ALL_XnapHandoverSuccessDuringChoAddModRel();
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "(*CHO) FnVCCB_ALL_XnapHandoverSuccessDuringChoAddModRel ERROR!\n");
        return GOOD;
    }

    // Immediate Handover Only
    if (VHCM_isSaHandoverUE(ptCi) == TRUE && FnVCCB_IsConditionalHandoverUE(ptCi) == false)
    {
        // 3) Receive Xn Handover Success during Intra-gNB, Intra-DU Handover Procedure
        if (ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_INTRA_GNB_INTRA_DU_HANDOVER)
        {
            status = FnVCCB_ALL_XnapHandoverSuccessDuringIntraGnbIntraDuHandover();
            VCCB_RETURN_ON_CALL_ERROR(
                ptCi, status, "(*CHO) FnVCCB_ALL_XnapHandoverSuccessDuringIntraGnbIntraDuHandover ERROR!\n");
            return GOOD;
        }

        // 4) Receive Xn Handover Success during Intra-gNB, Inter-DU Handover Procedure
        if (ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_INTRA_GNB_INTER_DU_HANDOVER)
        {
            status = FnVCCB_ALL_XnapHandoverSuccessDuringIntraGnbInterDuHandover();
            VCCB_RETURN_ON_CALL_ERROR(
                ptCi, status, "(*CHO) FnVCCB_ALL_XnapHandoverSuccessDuringIntraGnbInterDuHandover ERROR!\n");
            return GOOD;
        }

        // 5) Receive Xn Handover Success during Inter-gNB Handover Procedure
        if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTER_NB)
        {
            status = FnVCCB_ALL_XnapHandoverSuccessDuringInterGnbHandover();
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "(*CHO) FnVCCB_ALL_XnapHandoverSuccessDuringInterGnbHandover ERROR!\n");
            return GOOD;
        }

        FnVCCB_DropConditionalHandoverMessage("[DuringHO] Handover Success Ignore");
        return GOOD;
    }

    FnVCCB_DropConditionalHandoverMessage("[DuringOther] Handover Success Ignore");
    return GOOD;

}

