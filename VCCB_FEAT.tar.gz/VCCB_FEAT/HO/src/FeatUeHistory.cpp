#include "FeatUeHistory.h"

#include "ComInclude.h"
#include "ComLibUtility.h"
#include "ComTimeUtil.h"

#include "StateCommon.h"

#include "MsgXnapStore.h"

#ifdef VCCB_IPC_TEST
bool isRunTxMsgApprovalTest();
bool isRunShmMsgApprovalTest();
#endif

/****************************************************************************
 1. COMMON Function
****************************************************************************/
// {{{

// 1.1. Common API

/**
 * @brief This function prints the visited PSCell information for the given callInfo_type and
 * VccbLastVisitedPSCellInformation_type.
 *
 * @param ptCi The pointer to the callInfo_type structure.
 * @param ptPendingVisitCell The pointer to the VccbLastVisitedPSCellInformation_type structure.
 * @param isRx Indicates whether the information is received (True) or transmitted (False).
 */
void FnVCCB_PrintVisitedPSCellInformation(
    callInfo_type *ptCi, VccbLastVisitedPSCellInformation_type *ptPendingVisitCell, bool isRx)
{
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, ptPendingVisitCell);

    auto getPsCellId = [&ptPendingVisitCell]() -> string
    {
        if (ptPendingVisitCell->pSCellID_Present == VCCB_FLAG_ON)
            return std::to_string(ptPendingVisitCell->pSCellID.ci);

        return "NA";
    };

    auto getRatType = [&ptPendingVisitCell]() -> string
    {
        if (ptPendingVisitCell->pSCellID_Present == VCCB_FLAG_ON)
        {
            if (ptPendingVisitCell->ratType == ci_nr) return "NR";
            if (ptPendingVisitCell->ratType == ci_eutra) return "EUTRA";
            return std::to_string(ptPendingVisitCell->ratType);
        }

        return "NA";
    };

    const char *direction = isRx ? "[RX]" : "[TX]";

    FnVCCB_UeHistoryHandlingPrint(ptCi, "%s RAT: %5s, CI : %10s, TIME : %u\n", direction, getRatType().c_str(),
        getPsCellId().c_str(), ptPendingVisitCell->timeStay);
}

/**
 * @brief Increments the lastIndex field of a VccbLastVisitedPSCellHandling struct in a circular buffer manner.
 *
 * @param ptTgt Pointer to a VccbLastVisitedPSCellHandling struct
 */
VCCB_STATIC_INLINE
void FnVCCB_increment_lastIndex(VccbLastVisitedPSCellHandling_type *ptScgUHI)
{
    VALID_E_POINT_CHECK_VOID(ptScgUHI);

    ptScgUHI->lastIndex++;

    if (ptScgUHI->lastIndex >= MAX_PSCELL_HISTORY_PER_CALL)
    {
        ptScgUHI->lastIndex = 0;
    }
}

/**
 * @brief Decrements the lastIndex field of a VccbLastVisitedPSCellHandling struct in a circular buffer manner.
 *
 * @param ptTgt Pointer to a VccbLastVisitedPSCellHandling struct
 */
VCCB_STATIC_INLINE
void FnVCCB_decrement_lastIndex(VccbLastVisitedPSCellHandling_type *ptScgUHI)
{
    VALID_E_POINT_CHECK_VOID(ptScgUHI);

    switch (ptScgUHI->lastIndex)
    {
        // if (ptTgt->lastIndex == 0)
        case 0:
            ptScgUHI->lastIndex = MAX_PSCELL_HISTORY_PER_CALL - 1;
            break;

        // else if (1 <= ptTgt->lastIndex && ptTgt->lastIndex <= (MAX_PSCELL_HISTORY_PER_CALL-1))
        case 1 ...(MAX_PSCELL_HISTORY_PER_CALL - 1):
            ptScgUHI->lastIndex--;
            break;

        // else if (MAX_PSCELL_HISTORY_PER_CALL >= ptTgt->lastIndex)
        default:
            VCCB_PRINT_ERROR("Invalid lastIndex(%d), maybe broken memory!\n", ptScgUHI->lastIndex);
            ptScgUHI->lastIndex = 0;
            break;
    }
}

/**
 * @brief This function is used to get the pointer to the last visited PSCell list database for a given call.
 *
 * @param ptCi: Pointer to call information
 * @return VccbLastVisitedPSCellHandling_type*: Pointer to the last visited PSCell list database
 */
VccbLastVisitedPSCellHandling_type *FnVCCB_GetLastVisitedPSCellListDB(callInfo_type *ptCi)
{
    // Check input parameters
    VALID_E_POINT_CHECK_NULL(ptCi);
    VALID_E_POINT_CHECK_NULL(EXTERNAL_INFO.call);

    // Extract the call ID from the call information
    const uint32_t callId = ptCi->callId;

    // Check if the call information is valid
    if (IS_VALID_PTCI(ptCi) == FALSE)  // CALL DB JOB
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Invalid Call Info!! (%p, %p~%p)\n", ptCi, &ENV->callInfo[0], &ENV->callInfo[MAX_CALL_NUM_VCCB]);
        return NULL;
    }

    // Check if the call ID is valid
    if (IS_VALID_CALLID_VCCB(callId) == false)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid Call Id(%u, 0~%u)!!\n", callId, VCCB_MAX_CALL_COUNT_PER_CPC);
        return NULL;
    }

    // Return a pointer to the last visited PSCell list database
    return &EXTERNAL_INFO.call[callId].uePscellHistory;
}

/**
 * @brief This function initializes the last visited PSCell list for the given call information.
 *
 * @param ptCi - Pointer to the call information
 */
void FnVCCB_InitLastVisitedPSCellList(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    // Check input parameters
    VALID_E_POINT_CHECK_VOID(ptCi);

    // Check if the call information is valid
    if (IS_VALID_PTCI(ptCi) == FALSE)  // CALL DB JOB
    {
        return;
    }

    // Get a pointer to the last visited PSCell list database
    VccbLastVisitedPSCellHandling_type *ptScgUHI = FnVCCB_GetLastVisitedPSCellListDB(ptCi);

    // Check if the pointer is valid
    if (ptScgUHI == NULL)
    {
        // Log the error and return
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetLastVisitedPSCellListDB Error in %s\n", __func__);
        return;
    }

    // If it is already initialized, ignore it.
    if (ptScgUHI->numOfLastVisitedPSCell == 0) return;

    // Clear the last visited PSCell list database
    memset(ptScgUHI, 0x00, sizeof(VccbLastVisitedPSCellHandling_type));
}

/**
 * @brief Processes the last visited PSCell list
 *
 * This function processes the last visited PSCell list by performing the specified action on all the entries in the
 * list.
 *
 * @param ptScgUHI Pointer to VccbLastVisitedPSCellHandling_type structure
 * @param action Action to be performed on the entries in the list
 */
void FnVCCB_ProcessLastVisitedPSCellList(VccbLastVisitedPSCellHandling_type *ptScgUHI,
    void (*action)(VccbLastVisitedPSCellHandling_type *, VccbLastVisitedPSCellInformation_type *))
{
    // Check input parameters
    VALID_E_POINT_CHECK_VOID(ptScgUHI);
    VALID_E_POINT_CHECK_VOID(action);

    const uint8_t numOfLastVisitedPSCell = MIN(ptScgUHI->numOfLastVisitedPSCell, MAX_PSCELL_HISTORY_PER_CALL);
    unsigned int localDbIndex = ptScgUHI->lastIndex;

    // Loop through the last visited PSCell list
    for (uint8_t i = 0; i < numOfLastVisitedPSCell; i++)
    {
        // Check if the entry is in use
        if (ptScgUHI->lastVisitedPSCellList[localDbIndex].usage == CI_no_use) break;

        // Perform the specified action on the entry
        action(ptScgUHI, &ptScgUHI->lastVisitedPSCellList[localDbIndex]);

        // Decrement the local DB index
        localDbIndex = (localDbIndex == 0) ? (MAX_PSCELL_HISTORY_PER_CALL - 1) : (localDbIndex - 1);
    }
}

/**
 * @brief This function clears a pending entry from the last visited PSCell list.
 *
 * @param ptScgUHI Pointer to the VccbLastVisitedPSCellHandling_type structure.
 * @param ptEntry Pointer to the VccbLastVisitedPSCellInformation_type structure.
 */
VCCB_STATIC
void FnVCCB_ClearPendingEntry(
    VccbLastVisitedPSCellHandling_type *ptScgUHI, VccbLastVisitedPSCellInformation_type *ptEntry)
{
    VALID_E_POINT_CHECK_VOID_PARAM2(ptScgUHI, ptEntry);

    if (ptEntry->usage == CI_no_use) return;
    if (ptEntry->isPendingEntry == VCCB_FLAG_OFF) return;

    ptEntry->usage = CI_no_use;

    // Decrement the last index
    FnVCCB_decrement_lastIndex(ptScgUHI);

    // Decrement the number of last visited PSCell entries
    if (ptScgUHI->numOfLastVisitedPSCell > 0)
    {
        ptScgUHI->numOfLastVisitedPSCell--;
    }
}

/**
 * @brief Clears all pending entries in the last visited PSCell list
 * This function clears all the entries in the last visited PSCell list that are marked as pending entries.
 *
 * @param ptTgt Pointer to the VccbLastVisitedPSCellHandling_type structure
 */
void FnVCCB_ClearAllPendingEntriesInLastVisistedPScellList(VccbLastVisitedPSCellHandling_type *ptScgUHI)
{
    // Check input parameters
    VALID_E_POINT_CHECK_VOID(ptScgUHI);

    // Process the last visited PSCell list
    FnVCCB_ProcessLastVisitedPSCellList(ptScgUHI, FnVCCB_ClearPendingEntry);
}

/**
 * @brief This function clears a all(normal/pending) entry from the last visited PSCell list.
 *
 * @param ptScgUHI Pointer to the VccbLastVisitedPSCellHandling_type structure.
 * @param ptEntry Pointer to the VccbLastVisitedPSCellInformation_type structure.
 */
VCCB_STATIC
void FnVCCB_ClearAllEntry(VccbLastVisitedPSCellHandling_type *ptScgUHI, VccbLastVisitedPSCellInformation_type *ptEntry)
{
    VALID_E_POINT_CHECK_VOID_PARAM2(ptScgUHI, ptEntry);

    if (ptEntry->usage == CI_no_use) return;

    ptEntry->usage = CI_no_use;

    // Decrement the last index
    FnVCCB_decrement_lastIndex(ptScgUHI);

    // Decrement the number of last visited PSCell entries
    if (ptScgUHI->numOfLastVisitedPSCell > 0)
    {
        ptScgUHI->numOfLastVisitedPSCell--;
    }
}

/**
 * @brief This function clears all entries in the last visited PSCell list.
 *
 * @param ptTgt Pointer to the VccbLastVisitedPSCellHandling_type structure.
 */
void FnVCCB_ClearAllEntriesInLastVisistedPScellList(VccbLastVisitedPSCellHandling_type *ptScgUHI)
{
    // Check input parameters
    VALID_E_POINT_CHECK_VOID(ptScgUHI);

    // Process the last visited PSCell list
    FnVCCB_ProcessLastVisitedPSCellList(ptScgUHI, FnVCCB_ClearAllEntry);
}

/**
 * @brief Applies a pending entry in the last visited PSCell list
 *
 * This function applies a pending entry in the last visited PSCell list by changing the `isPendingEntry` flag to
 * `VCCB_FLAG_OFF`.
 *
 * @param ptScgUHI Pointer to VccbLastVisitedPSCellHandling_type structure
 * @param ptEntry Pointer to VccbLastVisitedPSCellInformation_type structure
 */
VCCB_STATIC
void FnVCCB_ApplyPendingEntry(
    VccbLastVisitedPSCellHandling_type * /*ptScgUHI*/, VccbLastVisitedPSCellInformation_type *ptEntry)
{
    if (ptEntry->isPendingEntry == VCCB_FLAG_ON)
    {
        ptEntry->isPendingEntry = VCCB_FLAG_OFF;
    }
}

/**
 * @brief Apply all pending entries in the last visited PSCell list
 *
 * This function applies all pending entries in the last visited PSCell list by changing the `isPendingEntry` flag to
 * `VCCB_FLAG_OFF`.
 *
 * @param ptTgt Pointer to VccbLastVisitedPSCellHandling_type structure
 */
void FnVCCB_ApplyAllPendingEntryInLastVisitedPSCellList(VccbLastVisitedPSCellHandling_type *ptScgUHI)
{
    // Check input parameters
    VALID_E_POINT_CHECK_VOID(ptScgUHI);

    // Process the last visited PSCell list
    FnVCCB_ProcessLastVisitedPSCellList(ptScgUHI, FnVCCB_ApplyPendingEntry);
}

/**
 * @brief This function gets a pointer to the last visited PSCell list entry
 *
 * @param ptTgt Pointer to the target structure
 * @return VccbLastVisitedPSCellInformation_type* Pointer to the last visited PSCell list entry
 */
VCCB_STATIC_INLINE
VccbLastVisitedPSCellInformation_type *FnVCCB_GetLastVisitedPSCellListEntry(
    VccbLastVisitedPSCellHandling_type *ptScgUHI)
{
    // Check input parameters
    VALID_E_POINT_CHECK_NULL(ptScgUHI);

    // This variable is used to restore the original last index
    // if the new last index is not within the range of the last visited PSCell list
    auto backupLastIndex = ptScgUHI->lastIndex;

    // Increment the last index
    FnVCCB_increment_lastIndex(ptScgUHI);

    // If it is, return a pointer to the entry at the new last index
    if (ptScgUHI->lastIndex < MAX_PSCELL_HISTORY_PER_CALL)
    {
        return &ptScgUHI->lastVisitedPSCellList[ptScgUHI->lastIndex];
    }
    // If the new last index is not within the range, restore the original last index using the 'backupLastIndex'
    // variable
    else
    {
        ptScgUHI->lastIndex = backupLastIndex;
        return NULL;
    }
}

/**
 * @brief This function updates the last visited PSCell list entry with the given information
 *
 * @param ptTgt Pointer to the target structure
 * @param ptPendingVisitCell Pointer to the information to update the last visited PSCell list entry with
 * @return int Returns GOOD if successful, ERROR otherwise
 */
int FnVCCB_UpdateLastVisitedPSCellListEntry(
    VccbLastVisitedPSCellHandling_type *ptScgUHI, VccbLastVisitedPSCellInformation_type *ptPendingVisitCell)
{
    // Check input parameters
    VALID_E_POINT_CHECK_ERROR(ptScgUHI);
    VALID_E_POINT_CHECK_ERROR(ptPendingVisitCell);

    if (ptPendingVisitCell->usage == CI_no_use)
    {
        return ERROR;
    }

    // Get the pointer to the last visited PSCell list entry
    auto *ptVisitCell = FnVCCB_GetLastVisitedPSCellListEntry(ptScgUHI);
    VALID_E_POINT_CHECK_ERROR(ptVisitCell);

    *ptVisitCell = *ptPendingVisitCell;

    // Increment the numOfLastVisitedPSCell
    if (ptScgUHI->numOfLastVisitedPSCell < MAX_PSCELL_HISTORY_PER_CALL)
    {
        ptScgUHI->numOfLastVisitedPSCell++;
    }

    return GOOD;
}

/**
 * @brief This function checks if there is a pending entry in the last visited PSCell list.
 *
 * @param ptCi The call information data structure.
 * @param ptScgUHI The last visited PSCell handling data structure.
 * @return true If there is a pending entry, otherwise false.
 */
bool FnVCCB_IsExistLastVisitedPSCellListPendingEntry(callInfo_type *ptCi, VccbLastVisitedPSCellHandling_type *ptScgUHI)
{
    // Check input parameters
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptScgUHI, false);

    // Loop through the last visited PSCell list
    for (uint8_t i = 0; i < MAX_PSCELL_HISTORY_PER_CALL; i++)
    {
        // Check if the entry is in use
        if (ptScgUHI->lastVisitedPSCellList[i].usage == CI_no_use) continue;

        // Perform the specified action on the entry
        if (ptScgUHI->lastVisitedPSCellList[i].isPendingEntry == VCCB_FLAG_ON) return true;
    }

    return false;
}

// 1.2. Common Proc

/**
 * This function initializes the Last Visited PSCell List for a specific call when Yang OFF is set.
 *
 * @param ptCi - a pointer to the call information structure
 */
VCCB_STATIC_INLINE
void FnVCCB_InitLstVisitedPSCellListWhenYangOff(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    // Check input parameters
    VALID_E_POINT_CHECK_VOID(ptCi);

    // Reset the Last Visited PSCell List
    FnVCCB_InitLastVisitedPSCellList(ptCi);
}

/**
 * @brief This function processes the idle state for the last visited PSCell information in the MN.
 *
 * @param ptCi: Pointer to the call information structure.
 * @param ptScgUHI: Pointer to the last visited PSCell handling structure for SCG.
 * @param isDebugPrint: Flag to enable debug printing.
 */
void FnVCCB_ProcIdleStateForLastVisitedPSCellInformation_MN(
    callInfo_type *&ptCi, VccbLastVisitedPSCellHandling_type *&ptScgUHI, const bool isDebugPrint)
{
    // Check if the call is for NRDC-MN, NEDC-MN or Non-DC (SA)
    const bool isNedcMn = IS_NEDC_MN(ptCi);
    const bool isNrdcMn = IS_NRDC_MN(ptCi);
    // const bool isNonDc  = !(isNedcMn || isNrdcMn || isNrdcSn || isEndcSn);

    auto &mnDb = ptScgUHI->u.mn;

    // NRDC-MN, NRDC-MN case
    if (isNrdcMn || isNedcMn)
    {
        if (isDebugPrint == true)
        {
            FnVCCB_UeHistoryHandlingPrint(ptCi, "MRDC service has started; initializing the PSCell List\n");
        }

        // Perform pending entry initialization,
        // where pending entry refers to the last visited PSCell list connected to the current PCell.
        FnVCCB_ClearAllPendingEntriesInLastVisistedPScellList(ptScgUHI);

        // NRDC Active case
        mnDb.isNonDcStartTimeValid = VCCB_FLAG_OFF;

        return;
    }
    // Non-DC (SA) case
    else
    {
        if (FnVCCB_IsExistLastVisitedPSCellListPendingEntry(ptCi, ptScgUHI) == true)
        {
            // If the Non-DC timer is not valid and a Non-DC state is detected, update the start time
            if (mnDb.isNonDcStartTimeValid == VCCB_FLAG_OFF)
            {
                if (isDebugPrint == true)
                {
                    FnVCCB_UeHistoryHandlingPrint(ptCi, "Detected a change form MRDC to NonDC; Starting to measure NonDC duration.\n");
                }

                if (ComTimeUtil::get_current_time(mnDb.nonDcStartTime) < 0)
                {
                    VCCB_PRINT_CALL_ERROR(
                        ptCi, "ComTimeUtil::get_current_time(nonDcStartTime) ERROR in %s\n", __func__);
                    return;
                }

                mnDb.isNonDcStartTimeValid = VCCB_FLAG_ON & e_BitMask_1bit;
            }
            else
            {
                if (isDebugPrint == true)
                {
                    FnVCCB_UeHistoryHandlingPrint(ptCi, "No DC-Type change detection; no action required\n");
                }
            }
        }
        else
        {
            if (isDebugPrint == true)
            {
                FnVCCB_UeHistoryHandlingPrint(ptCi, "No managed Last Visited PSCell Information; no action required\n");
            }
        }

        return;
    }
}

/**
 * @brief This function processes the idle state for the last visited PSCell information in SN.
 *
 * @param ptCi: Pointer to callInfo_type structure.
 * @param ptScgUHI: Pointer to VccbLastVisitedPSCellHandling_type structure.
 * @param isNrdcSn: Boolean indicating whether the call is NRDC-SN or not.
 * @param isEndcSn: Boolean indicating whether the call is ENDC-SN or not.
 * @param isDebugPrint: Boolean indicating whether debug print should be enabled or not.
 */
void FnVCCB_ProcIdleStateForLastVisitedPSCellInformation_SN(callInfo_type *&ptCi,
    VccbLastVisitedPSCellHandling_type *&ptScgUHI, const bool /*isNrdcSn*/, const bool isEndcSn,
    const bool isDebugPrint)
{
    auto &snDb = ptScgUHI->u.sn;

    // ENDC-SN case is currently not supported
    if (isEndcSn)
    {
        // no action, not design
        return;
    }
    // NRDC-SN case
    else
    {
        // if PSCell clear flag is valid, clear old SCG UE History
        if (snDb.isPSCellListClearNeeded == VCCB_FLAG_ON)
        {
            if (isDebugPrint == true)
            {
                FnVCCB_UeHistoryHandlingPrint(ptCi,"Delete the Old PSCell List following the detection of PCell Change (%d)\n",
                    snDb.isPSCellListClearNeeded);
            }

            // Perform all entry initialization,
            // where all entry refers to the last visited PSCell list connected to the current PCell.
            FnVCCB_ClearAllEntriesInLastVisistedPScellList(ptScgUHI);

            snDb.isPSCellListClearNeeded = VCCB_FLAG_OFF;
        }

        // If the PScell start time is not valid or an update is needed, update it
        if (snDb.isPScellStartTimeValid == VCCB_FLAG_OFF || snDb.isPScellStartTimeUpdateNeeded == VCCB_FLAG_ON)
        {
            if (isDebugPrint == true)
            {
                if (snDb.isPScellStartTimeValid == VCCB_FLAG_OFF)
                {
                    FnVCCB_UeHistoryHandlingPrint(ptCi, "Detected PSCell initial event; Starting to measure PSCell duration.\n");
                }

                if (snDb.isPScellStartTimeUpdateNeeded == VCCB_FLAG_ON)
                {
                    FnVCCB_UeHistoryHandlingPrint(ptCi, "Detected PSCell change event; Restarting to measure PSCell duration.\n");
                }
            }

            if (ComTimeUtil::get_current_time(snDb.pScellStartTime) < 0)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "ComTimeUtil::get_current_time(pScellStartTime) ERROR in %s\n", __func__);
                return;
            }

            snDb.isPScellStartTimeUpdateNeeded = VCCB_FLAG_OFF;
            snDb.isPScellStartTimeValid = VCCB_FLAG_ON & e_BitMask_1bit;
        }
        else
        {
            if (isDebugPrint == true)
            {
                FnVCCB_UeHistoryHandlingPrint(ptCi, "No PSCell changes detection; action not required\n");
            }
        }

        return;
    }
}

/**
 * @brief This function the transition to the idle state for the Last Visited PSCell List Information.
 *
 * @param ptCi: Pointer to the call information
 */
void FnVCCB_ProcIdleStateForLastVisitedPSCellInformation(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    // Check input parameters
    VALID_E_POINT_CHECK_VOID(ptCi);

    // Check if the UE History Information handling is enabled for the gNB
    if (FnVCCB_IsActiveScgUeHistoryHandling(ptCi->gnbNum) == false)
    {
        FnVCCB_InitLstVisitedPSCellListWhenYangOff(ptCi);
        return;
    }

    // Check if the call is for NRDC-SN or ENDC-SN
    const bool isNrdcSn = IS_NRDC_SN(ptCi);
    const bool isEndcSn = IS_ENDC_SN(ptCi);
    const bool isDebugPrint = (DBG->flag.logScgUeHistory == VCCB_FLAG_ON);

    // Get a pointer to the last visited PSCell list database
    VccbLastVisitedPSCellHandling_type *ptScgUHI = FnVCCB_GetLastVisitedPSCellListDB(ptCi);

    // Check if the pointer to the last visited PSCell list database is valid
    if (ptScgUHI == NULL)
    {
        // Log the error and return
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetLastVisitedPSCellListDB Error in %s\n", __func__);
        return;
    }

    // MRDC-SN case
    if (isNrdcSn || isEndcSn)
    {
        FnVCCB_ProcIdleStateForLastVisitedPSCellInformation_SN(ptCi, ptScgUHI, isNrdcSn, isEndcSn, isDebugPrint);
        return;
    }
    // MRDC-MN or Non-DC (SA) case
    else
    {
        FnVCCB_ProcIdleStateForLastVisitedPSCellInformation_MN(ptCi, ptScgUHI, isDebugPrint);
    }
}

// }}}
/****************************************************************************
 2. MN API
****************************************************************************/
// {{{

// 2.1. MN API

/**
 * This function checks whether UE History Information should be sent or not.
 *
 * @param ptCi - a pointer to the call information structure
 * @return true if UE History Information should be sent, false otherwise
 */
bool FnVCCB_IsSendingUeHistoryInformationRequired(callInfo_type *ptCi)
{
    // Check input parameters
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // Get a pointer to the last visited PSCell list database
    VccbLastVisitedPSCellHandling_type *ptScgUHI = FnVCCB_GetLastVisitedPSCellListDB(ptCi);

    // Check if the pointer to the last visited PSCell list database is valid
    if (ptScgUHI == NULL)
    {
        // Log the error and return
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetLastVisitedPSCellListDB Error in %s\n", __func__);
        return false;
    }

    // Check if the Non-DC Timer has started
    if (ptCi->stateCmd == IntraRatHO_cmd && ptCi->hoInfo.sgnbAddTrigInd == SgnbAddTrigInd_SnChange)
    {
        // no action
    }
    else if (ptScgUHI->u.mn.isNonDcStartTimeValid == VCCB_FLAG_OFF)
    {
        // Log the error and return
        // VCCB_PRINT_CALL_COMMENT(ptCi, "UHI Condition Error : Non-DC Timer Not Start in %s\n", __func__);
        return false;
    }

    return FnVCCB_IsExistLastVisitedPSCellListPendingEntry(ptCi, ptScgUHI);
}

/**
 * @brief This function calculates the Non-DC stay time in minutes for the given callInfo_type and
 * VccbLastVisitedPSCellHandling_type.
 *
 * @param ptCi Pointer to the callInfo_type structure.
 * @param ptScgUHI Pointer to the VccbLastVisitedPSCellHandling_type structure.
 * @return uint16_t The calculated Non-DC stay time in minutes.
 */
uint16_t FnVCCB_CalculateNonDcStayTime_InMn(callInfo_type *ptCi, VccbLastVisitedPSCellHandling_type *ptScgUHI)
{
    // Check input parameters
    VALID_E_POINT_CHECK_RET_VAL(ptCi, 0);
    VALID_E_POINT_CHECK_RET_VAL(ptScgUHI, 0);

    // Check if the Non-DC start time is valid
    if (ptScgUHI->u.mn.isNonDcStartTimeValid == VCCB_FLAG_OFF) return 0;

#ifdef VCCB_IPC_TEST
    if (isRunShmMsgApprovalTest() == true)
    {
        // use the hard coding value to pass the tc
        return 2;
    }
    else
#endif
    {
        // Calculate the Non-DC stay time in nanoseconds
        const struct timespec timeElapsed = ComTimeUtil::get_elapsed_time(ptScgUHI->u.mn.nonDcStartTime);

        float stayTime = FnVCCB_GetTimeMilliSecond(&timeElapsed);
        if (stayTime < 0) return 0;

        stayTime = MIN(stayTime, MAX_CELL_STAY_TIME_MSEC);

        return static_cast<uint16_t>(stayTime / 100);
    }
}

/**
 * @brief This function checks the call Type allowed by the SCG UE History Information Control.
 * 
 * @param ptCi Pointer to the call information structure.
 * @return bool True call type is allow for SCG UE History Information Control, false otherwise.
 */
bool FnVCCB_CheckCallTypeAllowedByScgUHIInMn(const callInfo_type * ptCi)
{
    // Check input parameters
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // Declare a pointer variable to store the function to be called based on the SCG UE History Information Control state
    bool (*pFunc)(const callInfo_type *) = NULL;

    // Check the SCG UE History Information Control state and set the appropriate function pointer in pFunc
    switch(DBG->value.scgUeHistoryInformationControl)
    {
        default:
        case e_ScgUeHistoryInformationControl_Both:
            pFunc = FnVCCB_IsMrdcMn;
            break;

        case e_ScgUeHistoryInformationControl_NRDCOnly:
            pFunc = FnVCCB_IsNrdcMn;
            break;

        case e_ScgUeHistoryInformationControl_NEDCOnly:
            pFunc = FnVCCB_IsNedcMn;
            break;
    }
    
    // If pFunc is NULL, return false
    if (pFunc == NULL) return false;

    // Call the function stored in pFunc
    return pFunc(ptCi);
}

// 2.2. MN Proc

/**
 * @brief This function processes the SCG UE History Information received from the SN.
 *
 * @param ptCi Pointer to the call information structure
 * @param ptScgUHI Pointer to the structure to store the SCG UE History Information
 * @param ptIE Pointer to the OCTET type containing the SCG UE History Information
 */
VCCB_STATIC_INLINE
void FnVCCB_ProcSCGUEHistoryInformationHandling_InMn(
    callInfo_type *ptCi, VccbLastVisitedPSCellHandling_type *ptScgUHI, XNAP_SCGUEHistoryInformation_type *ptIE)
{
    // Check input parameters
    VALID_E_POINT_CHECK_VOID_PARAM3(ptCi, ptScgUHI, ptIE);

    if (ptIE->m.lastVisitedPSCellListPresent == OPT_NOT_PRESENT) return;

    const int maxOfUhiList = MIN(ptIE->lastVisitedPSCellList.n, XN_MaxnoofPSCellsPerSN);

    for (int uhiIdx = maxOfUhiList - 1; uhiIdx >= 0; uhiIdx--)
    {
        XNAP_LastVisitedPSCellList_Item_type *ptItem = &ptIE->lastVisitedPSCellList.lastVisitedPSCellList_Item[uhiIdx];

        // Store the SCG UE History Information From SN in the pending list
        if (FnVCCB_StoreXNAP_LastVisitedPSCellInformation(
                ptCi, &ptItem->lastVisitedPSCellInformation, ptScgUHI, true /*pending*/) == ERROR)
        {
            // Since the LastVisitedPSCellInformation has not been processed,
            // the operation is stopped due to exception processing.
            break;
        }
    }
}

/**
 * @brief This function processes the SCG UE History Information IE received from the SN when the call is an NR-DC MN
 * call.
 *
 * @param ptCi: Pointer to the call information
 * @param ptUnpack: Pointer to the unpacked message buffer
 *
 * @return void
 */
void FnVCCB_ProcSCGUEHistoryInformationFromSN_InMn(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    // Check input parameters
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, ptUnpack);

    VccbLastVisitedPSCellHandling_type *ptScgUHI = NULL;

    bool isActiveScgUeHistoryHandling = FnVCCB_IsActiveScgUeHistoryHandling(ptCi->gnbNum);

    if (DBG->flag.logScgUeHistory == VCCB_FLAG_ON)
    {
        FnVCCB_UeHistoryHandlingPrint(ptCi, "Received SCG UE History Information IE. (HandlingCtrl: %s)\n",
                isActiveScgUeHistoryHandling == true ? "ON" : "OFF");
    }

    // Check if the UE History Information handling is enabled for the gNB
    if (isActiveScgUeHistoryHandling == false)
    {
        FnVCCB_InitLstVisitedPSCellListWhenYangOff(ptCi);
        return;
    }

    // Check Valid MRDC Ue Type
    if (FnVCCB_CheckCallTypeAllowedByScgUHIInMn(ptCi) == false)
    {
        // Return without processing further
        return;
    }

    {
        // Get a pointer to the last visited PSCell list database
        ptScgUHI = FnVCCB_GetLastVisitedPSCellListDB(ptCi);

        // Check if the pointer to the last visited PSCell list database is valid
        if (ptScgUHI == NULL)
        {
            // Log the error and return
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetLastVisitedPSCellListDB Error in %s\n", __func__);
            return;
        }

        FnVCCB_ClearAllPendingEntriesInLastVisistedPScellList(ptScgUHI);
    }

    // Declare a pointer to the SCG UE History Information IE
    XNAP_SCGUEHistoryInformation_type *pScgUeHistoryIE = NULL;

    // Switch on the received message ID
    switch (ptUnpack->msgId)
    {
        // Handle Sn Init Inter-SN Mobility
        case XN_SNodeChangeRequired_id:
        {
            // Get the message pointer
            XN_SNodeChangeRequired_type *ptMsg = (XN_SNodeChangeRequired_type *)ptUnpack->unpack;

            // Check if the SCG UE History Information IE is present
            if (ptMsg->m.sCGUEHistoryInformationPresent == OPT_PRESENT)
            {
                // Set the SCG UE History Information IE pointer
                pScgUeHistoryIE = &ptMsg->sCGUEHistoryInformation;
            }
        }
        break;

        // Handle Sn Init Intra-SN Mobility
        case XN_SNodeModificationRequired_id:
        {
            // Get the message pointer
            XN_SNodeModificationRequired_type *ptMsg = (XN_SNodeModificationRequired_type *)ptUnpack->unpack;

            // Check if the SCG UE History Information IE is present
            if (ptMsg->m.sCGUEHistoryInformationPresent == OPT_PRESENT)
            {
                // Set the SCG UE History Information IE pointer
                pScgUeHistoryIE = &ptMsg->sCGUEHistoryInformation;
            }
        }
        break;

        // Handle Sn Init SN Release
        case XN_SNodeReleaseRequired_id:
        {
            // Get the message pointer
            XN_SNodeReleaseRequired_type *ptMsg = (XN_SNodeReleaseRequired_type *)ptUnpack->unpack;

            // Check if the SCG UE History Information IE is present
            if (ptMsg->m.sCGUEHistoryInformationPresent == OPT_PRESENT)
            {
                // Set the SCG UE History Information IE pointer
                pScgUeHistoryIE = &ptMsg->sCGUEHistoryInformation;
            }
        }
        break;

        // Handle Mn Init SN Release
        case XN_SNodeReleaseRequestAcknowledge_id:
        {
            // Get the message pointer
            XN_SNodeReleaseRequestAcknowledge_type *ptMsg = (XN_SNodeReleaseRequestAcknowledge_type *)ptUnpack->unpack;

            // Check if the SCG UE History Information IE is present
            if (ptMsg->m.sCGUEHistoryInformationPresent == OPT_PRESENT)
            {
                // Set the SCG UE History Information IE pointer
                pScgUeHistoryIE = &ptMsg->sCGUEHistoryInformation;
            }
        }
        break;

        // Handle Mn Query
        case XN_SNodeModificationRequestAcknowledge_id:
        {
            // Get the message pointer
            XN_SNodeModificationRequestAcknowledge_type *ptMsg =
                (XN_SNodeModificationRequestAcknowledge_type *)ptUnpack->unpack;

            // Check if the SCG UE History Information IE is present
            if (ptMsg->m.sCGUEHistoryInformationPresent == OPT_PRESENT)
            {
                // Set the SCG UE History Information IE pointer
                pScgUeHistoryIE = &ptMsg->sCGUEHistoryInformation;
            }
        }
        break;

        // If the message ID is not handled, return without processing further
        default:
            return;
    }

    // Check if the SCG UE History Information IE pointer is valid
    if (pScgUeHistoryIE == NULL)
    {
        // Return without processing further
        return;
    }

    // Process the SCG UE History Information IE
    FnVCCB_ProcSCGUEHistoryInformationHandling_InMn(ptCi, ptScgUHI, pScgUeHistoryIE);
}

/**
 * @brief This function processes the SCG UE History Information for PCell Change in Mn.
 *
 * @param ptCi: Pointer to callInfo_type structure
 */
void FnVCCB_ProcSCGUeHsitoryInformationForPCellChange_InMn(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    // Check input parameters
    VALID_E_POINT_CHECK_VOID(ptCi);

    // Check if the UE History Information handling is enabled for the gNB
    if (FnVCCB_IsActiveScgUeHistoryHandling(ptCi->gnbNum) == false)
    {
        FnVCCB_InitLstVisitedPSCellListWhenYangOff(ptCi);
        return;
    }

    // Get a pointer to the last visited PSCell list database
    VccbLastVisitedPSCellHandling_type *ptScgUHI = FnVCCB_GetLastVisitedPSCellListDB(ptCi);

    // Check if the pointer is valid
    if (ptScgUHI == NULL)
    {
        // Log the error and return
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetLastVisitedPSCellListDB Error in %s\n", __func__);
        return;
    }

    FnVCCB_ApplyAllPendingEntryInLastVisitedPSCellList(ptScgUHI);
}

// }}}
/****************************************************************************
 3. SN API
****************************************************************************/
// {{{

// 3.1. SN API

/**
 * @brief This function checks if sending SCG UE History Information is required in SN.
 *
 * @param ptCi Pointer to call information.
 * @param msgId Message ID of the received message.
 * @return bool Returns true if sending SCG UE History Information is required, otherwise returns false.
 */
bool FnVCCB_IsSendingScgUeHistoryInformationRequiredInSn(callInfo_type *ptCi, uint16_t msgId)
{
    // Check input parameters
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // Check if the UE History Information handling is enabled for the gNB
    if (FnVCCB_IsActiveScgUeHistoryHandling(ptCi->gnbNum) == false)
    {
        FnVCCB_InitLstVisitedPSCellListWhenYangOff(ptCi);
        return false;
    }

    // Get a pointer to the last visited PSCell list database
    VccbLastVisitedPSCellHandling_type *ptScgUHI = FnVCCB_GetLastVisitedPSCellListDB(ptCi);

    // Check if the pointer to the last visited PSCell list database is valid
    if (ptScgUHI == NULL)
    {
        // Log the error and return
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetLastVisitedPSCellListDB Error in %s\n", __func__);
        return false;
    }

    // Check if the PSCell Timer has started
    if (ptScgUHI->u.sn.isPScellStartTimeValid == VCCB_FLAG_OFF)
    {
        // Log the error and return
        VCCB_PRINT_CALL_ERROR(ptCi, "UHI Condition Error : PSCell Timer Not Start in %s\n", __func__);
        return false;
    }

    switch (msgId)
    {
        case XN_SNodeReleaseRequired_id:  // SN Init Release
        case XN_SNodeChangeRequired_id:   // SN Init Inter-SN Moblity
            return true;

        case XN_SNodeReleaseRequestAcknowledge_id:  // MN Init Release
            return true;

        case XN_SNodeModificationRequired_id:
            // SN Init Intra-SN Mobility
            if (ptCi->stateCmd == IntraRatHO_cmd && ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_SGNB_INITIATED)
            {
                // The NRDC-SN can always be transmitted based on the source MN.
                return (ptScgUHI->u.sn.mnInfo[SRC_MN].isPSCellChangeHistoryIE_Received == VCCB_FLAG_ON);
            }

            // other Scenario is not supported
            return false;

        case XN_SNodeModificationRequestAcknowledge_id:  // MN Init Intra-SN Mobility, MN Query
            if (ptScgUHI->u.sn.mnInfo[SRC_MN].isPSCellHistoryInformationRetrieveIE_Received == VCCB_FLAG_ON)
                return true;
            return false;

        default:
            return false;
    }
}

/**
 * @brief This function calculates the PSCell stay time in nanoseconds for a given call information.
 *
 * @param ptCi: Pointer to the call information
 * @param ptScgUHI: Pointer to the VccbLastVisitedPSCellHandling_type structure containing the PSCell start time
 * @return uint16_t: The function returns the PSCell Stay Time on success, but returns a negative value on failure.
 */
uint16_t FnVCCB_CalculatePSCellStayTime_InSn(callInfo_type *ptCi, VccbLastVisitedPSCellHandling_type *ptScgUHI)
{
    // Check input parameters
    VALID_E_POINT_CHECK_RET_VAL(ptCi, 0);
    VALID_E_POINT_CHECK_RET_VAL(ptScgUHI, 0);

    // Check if the Non-DC start time is valid
    if (ptScgUHI->u.sn.isPScellStartTimeValid == VCCB_FLAG_OFF) return 0;

#ifdef VCCB_IPC_TEST
    if (isRunShmMsgApprovalTest() == true)
    {
        // use the hard coding value to pass the tc
        return 2;
    }
    else
#endif
    {
        // Calculate the Non-DC stay time in nanoseconds
        const struct timespec timeElapsed = ComTimeUtil::get_elapsed_time(ptScgUHI->u.sn.pScellStartTime);

        float stayTime = FnVCCB_GetTimeMilliSecond(&timeElapsed);
        if (stayTime < 0) return 0;

        stayTime = MIN(stayTime, MAX_CELL_STAY_TIME_MSEC);

        return static_cast<uint16_t>(stayTime / 100);

    }
}

/**
 * @brief This function fills the VccbLastVisitedPSCellInformation_type structure with the information of the current
 * PSCell.
 *
 * @param ptCi The pointer to the call information.
 * @param ptScgUHI The pointer to the VccbLastVisitedPSCellHandling_type structure containing the SCG Ue History
 * Information.
 * @param ptOutVisited The pointer to the VccbLastVisitedPSCellInformation_type structure to be filled.
 * @return int16_t Returns GOOD if successful, ERROR otherwise.
 */
int16_t FnVCCB_FillLastVisitedPSCellInformation_CurrentPScell(callInfo_type *ptCi,
    VccbLastVisitedPSCellHandling_type *ptScgUHI, VccbLastVisitedPSCellInformation_type *ptOutVisited)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR_PARAM2(ptCi, ptOutVisited);

    ptOutVisited->clearFlags = 0;

    ptOutVisited->pSCellID_Present = OPT_PRESENT;
    ptOutVisited->pSCellID = FnVCCB_GetNrcgiFromCellNum(ptCi->servCellNum);
    ptOutVisited->ratType = ci_nr & e_BitMask_4bit;

    ptOutVisited->timeStay = FnVCCB_CalculatePSCellStayTime_InSn(ptCi, ptScgUHI);

    ptOutVisited->usage = CI_use;

    return GOOD;
}

/**
 * @brief This function checks if the PCell change is required for PSCell Information in SN.
 * 
 * @param ptCi Pointer to callInfo_type structure.
 * @return enumChangeState_type Returns Not_Changed if no change is required, Changed otherwise.
 */
enumChangeState_type FnVCCB_IsPCellChange_ForPSCellInformationInSN(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, Not_Changed);

    if (IS_MRDC_SN(ptCi) && ptCi->stateCmd == IntraRatHO_cmd)
    {
        switch(ptCi->hoInfo.hoType.initiated)
        {
            // Sn Init Mobility
            case HO_TYPE_SA_SGNB_INITIATED:
            case HO_TYPE_SA_SGNB_INITIATED_INTER_SN_CHANGE:
                return Not_Changed;

            // SCG Failure
            case HO_TYPE_SA_MN_INIT_SCG_RESUME:
                return Not_Changed;

            // Mn Init Mobility
            default:
                {
                    MNInfo_type *ptSrcMnInfo = &ptCi->mrdcInfo.MNInfo[SRC_MN];
                    MNInfo_type *ptTgtMnInfo = &ptCi->mrdcInfo.MNInfo[TGT_MN];

                    const bool isValidSrcMnInfo = (ptSrcMnInfo->m.usage == VCCB_FLAG_ON);
                    const bool isValidTgtMnInfo = (ptTgtMnInfo->m.usage == VCCB_FLAG_ON);

                    if (isValidSrcMnInfo == true && isValidTgtMnInfo == true)
                    {
                        const bool isValidSrcMnCGI = (ptSrcMnInfo->m.mnNRCGI == VCCB_FLAG_ON);
                        const bool isValidTgtMnCGI = (ptTgtMnInfo->m.mnNRCGI == VCCB_FLAG_ON);

                        if (isValidSrcMnCGI == true && isValidTgtMnCGI == true)
                        {
                            if (FnVCCB_CheckCgiIdentical(&ptSrcMnInfo->mnNRCGI, &ptTgtMnInfo->mnNRCGI) == TRUE)
                            {
                                return Not_Changed;
                            }
                            else
                            {
                                return Changed;
                            }
                        }
                    }
                }

                return Changed;
        }
    }

    return Not_Changed;
}


// 3.2. SN Porc

// }}}
