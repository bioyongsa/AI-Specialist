#include "UplinkStatusTriggeredMobility.hpp"

#include "ComInclude.h"
#include "ComLibUtility.h"
#include "ComMacro.h"
#include "ComAsnUtil.hpp"
#include "FeatCommon.h"
#include "FeatMeasurements.hpp"
#include "StateCommon.h"
#include "StateHandleAll.h"
#include "StateMeasurements.h"

#include "MsgF1apStore.h"
#include "MsgF1apSend.h"
#include "VccbDefine.h"
#include "cause_call_5g.h"

using asn::util::ptUnpackConvert;

/**
 * @brief Check if F1_UEContextModificationRequired contains valid IEs for feature FGR-MC1029
 *        Should contain: gNB-CU UE F1AP ID - MANDATORY
 *                        gNB-DU UE F1AP ID - MANDATORY
 *                        Cause - MANDATORY
 * @param[in] msg: F1_UEContextModificationRequired
 * @return true if msg contains ONLY mandatory IEs, false otherwise
 */
bool FnVCCB_USTM_CheckIfOnlyMandatoryIESPresent(callInfo_type &rCi, const F1_UEContextModificationRequired &msg)
{
    AUTO_TRACE_FUNC;

    const struct F1_ProtocolIE_Container_ *pContainer = msg.protocolIEs;

    // check if msg contains proper IEs to Uplink Status Triggered Mobility
    F1_ProtocolIE_ID mandatoryIEs[] = {F1_id_gNB_CU_UE_F1AP_ID, F1_id_gNB_DU_UE_F1AP_ID, F1_id_Cause};

    for (; NULL != pContainer; pContainer = pContainer->next)
    {
        auto pos = find_if(begin(mandatoryIEs), end(mandatoryIEs),
            [pContainer](const int element) { return element == pContainer->value.id; });

        if (pos == end(mandatoryIEs))
        {
            VCCB_PRINT_LOG_USTM(
                &rCi, "F1_UEContextModificationRequired not valid. Not valid IE (id:%u)\n", pContainer->value.id);
            return false;
        }
    }

    return true;
}

DuIndicationStatus FnVCCB_USTM_CheckF1UEContextModRequired_IsDuIndication(
    callInfo_type &rCi, const F1_UEContextModificationRequired &msgRequired, uint16_t &f1Cause)
{
    AUTO_TRACE_FUNC;

    F1_Cause *pCause = NULL;
    const struct F1_ProtocolIE_Container_ *pContainer = msgRequired.protocolIEs;

    // Check if F1Cause is set to 'CauseF1apRadioAmfInitiatedAbnormalRelease' or 'CauseF1apRadioUeRejection'
    if (ERROR == VFIL_GetF1IE(const_cast<const void **>(reinterpret_cast<void **>(&pCause)), pContainer, F1_id_Cause))
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "%s: VFIL_GetF1IE(F1_id_Cause) ERROR\n", __FUNCTION__);
        return DuIndicationStatus::error;
    }

    if (F1_radioNetwork_chosen == pCause->choice)
    {
        f1Cause = static_cast<uint16_t>(CAUSE_BASE_F1AP_RADIONETWORK + pCause->u.radioNetwork);
        if ((CauseF1apRadioAmfInitiatedAbnormalRelease == f1Cause) || (CauseF1apRadioUeRejection == f1Cause))
        {
            if (FnVCCB_USTM_CheckIfOnlyMandatoryIESPresent(rCi, msgRequired))
            {
                return DuIndicationStatus::ok;
            }
            else
            {
                return DuIndicationStatus::iesNotValid;
            }
        }
    }
    return DuIndicationStatus::unsupportedCause;
}

bool FnVCCB_USTM_IsProperCallType(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    if (IS_NRDC_SN((&rCi)))
    {
        VCCB_PRINT_LOG_USTM(&rCi, "NRDC SN UE case does not allow forced mobility procedure\n");
        return false;
    }

    return true;
}

/****************************************************************************
 * @brief           Check if any feature which can override USTM operates
 * @param[in]       rCi : reference to call configuration. / callInfo_type&
 ****************************************************************************/
bool FnVCCB_USTM_CheckIfOtherFeaturesBlock(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    if (IS_FALLBACK_CASE((&rCi)))
    {
        VCCB_PRINT_LOG_USTM(&rCi, "EPS/Emergency Fallback UE case canceled forced mobility procedure\n");
        return true;
    }
    if (rCi.onDemandInfo.targetUe)
    {
        VCCB_PRINT_LOG_USTM(&rCi, "On Demand Handover UE case canceled forced mobility procedure\n");
        return true;
    }

    return false;
}

bool FnVCCB_USTM_IsDuIntraNrRedirectionApplicable(callInfo_type &rCi, const measurementObjectNRBaseDb_type *pMeasObjNr)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(pMeasObjNr);
    VCCB_CHECK_VALID_CELLNUM_FALSE(rCi.servCellNum);

    if (CI_use != pMeasObjNr->usage)
    {
        return false;
    }

    // exclude freq which is same with serving cell's
    const VccbCellInfo_type *const pCell = &CELLINFO[rCi.servCellNum];

    if (pCell->ssbArfcn == pMeasObjNr->ssbFrequency)
    {
        VCCB_PRINT_LOG_USTM(&rCi, "pMeasObjNr->ssbArfcn(%u) same to serving cell freq \n", pMeasObjNr->ssbFrequency);
        return false;
    }

    if (!FnVCCB_IsSsbAllowed(rCi, pMeasObjNr->ssbFrequency))
    {
        VCCB_PRINT_LOG_USTM(&rCi,
            "Can't use measObj's freq(%u) for redirection because it is on restricted ssb frequency list!\n",
            pMeasObjNr->ssbFrequency);
        return false;
    }

    // Check UE Supported band(+MFBI)
    if (BAND_NOT_FOUND == VCCB_GetMoNrBandForUe(&rCi, pMeasObjNr))
    {
        VCCB_PRINT_LOG_USTM(&rCi, "pMeasObjNr->ssbArfcn(%u) Not Supported band \n", pMeasObjNr->ssbFrequency);
        return false;
    }

    // Check SaCapable and redcap-access-allowed
    if (TRUE != fnVCCB_IsSaCapableMO(&rCi, pMeasObjNr))
    {
        VCCB_PRINT_LOG_USTM(&rCi, "pMeasObjNr->ssbArfcn(%u) not SaCapable \n", pMeasObjNr->ssbFrequency);
        return false;
    }

    // Check if supportForcedMobilityByUplinkStatusIndication is allowed
    if (true != pMeasObjNr->supportForcedMobilityByUplinkStatusIndication)
    {
        VCCB_PRINT_LOG_USTM(&rCi, "pMeasObjNr->ssbArfcn(%u) not supporting Uplink Status Triggered Mobility\n",
            pMeasObjNr->ssbFrequency);
        return false;
    }
    VCCB_PRINT_LOG_USTM(&rCi, "pMeasObjNr->ssbArfcn(%u) is applicable to redirection\n", pMeasObjNr->ssbFrequency);
    return true;
}

ColocNbrs FnVCCB_CreateColocNbrsList(callInfo_type &rCi, const VccbCellInfo_type &rCell)
{
    AUTO_TRACE_FUNC;

    if (CI_no_use == rCell.cuColocCellInfo.colocCellInfoUsage)
    {
        VCCB_PRINT_LOG_USTM(&rCi, "Coloc cells are disabled\n");
        return ColocNbrs{};
    }

    ColocNbrs colocNbrs{};
    for (const auto &colocCell : rCell.cuColocCellInfo.colocCellEntries)
    {
        if (CI_no_use == colocCell.usage)
        {
            continue;
        }

        cgi_type colocCgi;
        colocCgi.ci = VLIB_GnbIdCellId2NrCellId(&colocCell.globalGnbId.gnbId, colocCell.cellId);
        colocCgi.plmn = colocCell.globalGnbId.plmn;

        // find gnb/gnbNRT/cellInfo by CGI
        const uint8_t colocGnbIdLength = colocCell.globalGnbId.gnbId.idLength;
        const nbrGnbCellInfo_type *ptCell = VLIB_GetNbrGnbCellInfoBasedOnCgi(&rCi, colocCgi, colocGnbIdLength);
        if (nullptr == ptCell)
        {
            VCCB_PRINT_LOG_USTM(&rCi, "Neighbor cannot be found\n");
            continue;
        }
        VCCB_PRINT_LOG_USTM(&rCi, "Found gnb NbrCell by CGI\n");

        // find gnb/cell/cellNRT by CGI
        const uint16_t cellNbrIdx = VLIB_GetNbrIdxBasedOnCgi(&rCell, colocCgi);
        if (MAX_NBR_PER_CELL <= cellNbrIdx)
        {
            VCCB_PRINT_LOG_USTM(&rCi, "Not found any cell neighbor\n");
            continue;
        }
        colocNbrs.push_back(colocCellNbrs_type{cellNbrIdx, ptCell->ssbArfcn});
    }
    return colocNbrs;
}

bool FnVCCB_CheckIfArfcnOverloaded(
    callInfo_type &rCi, const VccbCellInfo_type &rCell, const ColocNbrs &colocNbrs, const Arfcn_type &measObjSsbFreq)
{
    AUTO_TRACE_FUNC;

    for (const auto &colocNbr : colocNbrs)
    {
        if (colocNbr.ssbArfcn != measObjSsbFreq)
        {
            continue;
        }

        auto &cellLoadBasedTargetSel =
            rCell.mobilityConfig.forcedMobilityDueToUplinkStatusIndication.loadBasedTargetSelection;

        VCCB_CHECK_E_RANGE_AND_CONTINUE(colocNbr.cellNbrIdx, VCCB_ARRAY_COUNT(rCell.cellRscInfo.nbrPrb));
        auto &nbrPrbInfo = rCell.cellRscInfo.nbrPrb[colocNbr.cellNbrIdx];
        if (nbrPrbInfo.usage != EQUIP || nbrPrbInfo.isRsUpdate != ON)
        {
            VCCB_PRINT_LOG_USTM(&rCi, "NbrPrbInfo NOT EQUIPPED or rsUpdate OFF\n");
            continue;
        }

        if (nbrPrbInfo.dlCapacityValue < cellLoadBasedTargetSel.dlCapacityThreshold ||
            nbrPrbInfo.ulCapacityValue < cellLoadBasedTargetSel.ulCapacityThreshold)
        {
            VCCB_PRINT_LOG_USTM(&rCi, "Arfcn %u is overloaded \n", measObjSsbFreq);
            return true;  // end colocCell loop
        }
    }
    VCCB_PRINT_LOG_USTM(&rCi, "Arfcn %u is not overloaded\n", measObjSsbFreq);
    return false;
}

measObjIdxList FnVCCB_USTM_SelectTargetCarrierNrForRedirection(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(rCi.servCellNum, measObjIdxList{});

    const VccbCellInfo_type *const pCell = &CELLINFO[rCi.servCellNum];
    measObjIdxList candidateListIdx{};

    // Find allowed NR carrier from CELL MeasObjectNR DB, not call DB
    for (uint16_t idx = 0; idx < MAX_NR_OF_OBJECT_ID_DB; idx++)
    {
        const measurementObjectNRBaseDb_type *pMeasObjNr = &pCell->measurementsData.measurementObjectsNRDb[idx].base;

        if (!FnVCCB_USTM_IsDuIntraNrRedirectionApplicable(rCi, pMeasObjNr))
        {
            continue;
        }
        candidateListIdx.push_back(idx);
    }

    // check if loadBasedTargetSelection on
    if (CI_use == pCell->mobilityConfig.forcedMobilityDueToUplinkStatusIndication.loadBasedTargetSelection.usage)
    {
        measObjIdxList loadBasedcandidateListIdx{};
        const ColocNbrs colocNbrs = FnVCCB_CreateColocNbrsList(rCi, *pCell);
        for (const auto measObjIdx : candidateListIdx)
        {
            const measurementObjectNRBaseDb_type *pMeasObjNr =
                &pCell->measurementsData.measurementObjectsNRDb[measObjIdx].base;
            if (!FnVCCB_CheckIfArfcnOverloaded(rCi, *pCell, colocNbrs, pMeasObjNr->ssbFrequency))
            {
                loadBasedcandidateListIdx.push_back(measObjIdx);
            }
        }
        candidateListIdx = loadBasedcandidateListIdx;
    }

    return candidateListIdx;
}

redirectionInfoEutraList FnVCCB_USTM_SelectTargetCarrierEutraForRedirection(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(rCi.servCellNum, redirectionInfoEutraList{});

    const VccbCellInfo_type *const pCell = &CELLINFO[rCi.servCellNum];
    redirectionInfoEutraList candidateList{};

    // Find allowed EUTRA carrier from CELL MeasObjectEutra DB, not call DB
    for (const auto &moEutra : pCell->measurementsData.measurementObjectsEUTRADb)
    {
        if (CI_use != moEutra.base.usage)
        {
            continue;
        }

        // Check if supportForcedMobilityByUplinkStatusIndication is allowed
        if (true != moEutra.base.supportForcedMobilityByUplinkStatusIndication)
        {
            VCCB_PRINT_LOG_USTM(&rCi, "moEutra carrierFreq(%u) not supporting Uplink Status Triggered Mobility\n",
                moEutra.base.carrierFreq);
            continue;
        }

        // Check UE Supported band(+MFBI)
        uint32_t overlappedCarrierFreq{UNKNOWN_ARFCN};
        if (BAND_NOT_FOUND == VCCB_GetMoEutraBandForUe(&rCi, &moEutra.base, &overlappedCarrierFreq))
        {
            VCCB_PRINT_LOG_USTM(&rCi, "moEutra carrierFreq(%u) Not Supported band \n", moEutra.base.carrierFreq);
            continue;
        }

        VCCB_PRINT_LOG_USTM(&rCi, "moEutra carrierFreq(%u) is applicable to redirection\n", moEutra.base.carrierFreq);

        candidateList.push_back(
            {.carrierFreq = moEutra.base.carrierFreq, .overlappedCarrierFreq = overlappedCarrierFreq});
    }

    return candidateList;
}

bool FnVCCB_SaveFaultCauseAndTriggerRelease(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    callInfo_type *ptCi = &rCi;
    MACRO_CALL_FAULT_SAVE(
        rCi.ustmInfo.callFaultForForcedRelease.msgId, rCi.ustmInfo.callFaultForForcedRelease.releaseCause);

    // FGR-CC5001 FR154 - indicate ducting to MeNB.
    if (VCCB_IsEndcSn(rCi) && rCi.ustmInfo.statusReasonTable[ulStatusMobilityReason_tddInterference])
    {
        rCi.cause.x2Cause = CauseX2apRadioNetworkLayerHoTargetNotAllowed;
    }

    if (VCCB_CALL_RELEASE_TRIGGER(ptCi) != GOOD)
    {
        return false;
    }

    return true;
}

int16_t FnVCCB_USTM_ReleaseCallWithRedirectionToNr(callInfo_type &rCi, const uint32_t moIdx)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(rCi.servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(moIdx, MAX_NR_OF_OBJECT_ID_DB);

    const VccbCellInfo_type *const pCell = &CELLINFO[rCi.servCellNum];
    const measurementObjectNRBaseDb_type *pMeasObjNr = NULL;

    // Set Redirection Info by selected target carrier
    rCi.redirectionInfo.actualRedirectionMethod = BLIND_REDIR_ONLY;

    rCi.redirectionInfo.redirType = INTRA_RAT_REDIRECTION;
    pMeasObjNr = &pCell->measurementsData.measurementObjectsNRDb[moIdx].base;
    VLIB_CreateRedirectionInfoNrFromMeasObjectDb(&rCi.redirectionInfo.rat.nr, pMeasObjNr);

    VCCB_PRINT_CALL_INFORMATIVE(&rCi,
        "NR Redirection Triggered ssbFrequency:%u moIdx:%u by UplinkStatusTriggeredMobility HO \n",
        pMeasObjNr->ssbFrequency, moIdx);

    // Release with redirection info
    if (!FnVCCB_SaveFaultCauseAndTriggerRelease(rCi))
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "VCCB_CALL_RELEASE_TRIGGER ERROR!\n");
        return ERROR;
    }

    rCi.ustmInfo.redirectionTriggered = TRUE;
    return GOOD;
}

bool FnVCCB_USTM_ReleaseCallWithRedirectionToEutra(callInfo_type &rCi, const redirectionInfoEutra_type &redirectionInfo)
{
    AUTO_TRACE_FUNC;

    // Set Redirection Info by selected target carrier
    rCi.redirectionInfo.actualRedirectionMethod = BLIND_REDIR_ONLY;
    rCi.redirectionInfo.redirType = INTER_RAT_REDIRECTION;

    rCi.redirectionInfo.rat.eutra = redirectionInfo;

    VCCB_PRINT_CALL_INFORMATIVE(&rCi,
        "NR Redirection Triggered carrierFreq:%u overlappedCarrierFreq:%u by UplinkStatusTriggeredMobility HO \n",
        redirectionInfo.carrierFreq, redirectionInfo.overlappedCarrierFreq);

    // Release with redirection info
    if (!FnVCCB_SaveFaultCauseAndTriggerRelease(rCi))
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "VCCB_CALL_RELEASE_TRIGGER ERROR!\n");
        return false;
    }

    rCi.ustmInfo.redirectionTriggered = TRUE;
    return true;
}

template <typename Container>
std::optional<typename Container::value_type> getRandomItem(callInfo_type &rCi, const Container &container)
{
    AUTO_TRACE_FUNC;

    if (container.empty())
    {
        return std::nullopt;
    }

    uint32_t range = static_cast<uint32_t>(container.size());
    if (1 < range)
    {
        uint32_t selectedIdx = FnVCCB_GetRandomValue(__func__, rCi.gnbNum, static_cast<int>(range));
        if (selectedIdx < range)
        {
            return container[selectedIdx];
        }
    }

    return container[0];
}

/**
 * @brief Handle Forced Release Redirection
 * @param[in] rCi: callInfo
 * @return true/false  : Message handling status
 */
bool FnVCCB_USTM_TriggerRedirection(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_VALID_CELLNUM_FALSE(rCi.servCellNum);

    const measObjIdxList moIdxNrList = FnVCCB_USTM_SelectTargetCarrierNrForRedirection(rCi);
    if (0 == moIdxNrList.size())
    {
        VCCB_PRINT_LOG_USTM(&rCi, "No candidates for NR redirection found, fallback to EUTRA.\n");
        const redirectionInfoEutraList candidatesEutraList = FnVCCB_USTM_SelectTargetCarrierEutraForRedirection(rCi);
        if (0 == candidatesEutraList.size())
        {
            VCCB_PRINT_LOG_USTM(
                &rCi, "No candidates for EUTRA redirection found, fallback to Release without redirection.\n");

            if (!FnVCCB_SaveFaultCauseAndTriggerRelease(rCi))
            {
                VCCB_PRINT_CALL_ERROR(&rCi, "%s: VCCB_CALL_RELEASE_TRIGGER ERROR!\n", __FUNCTION__);
                return false;
            }

            rCi.ustmInfo.releaseTriggered = TRUE;
            return true;
        }
        else
        {
            const auto &selectedRedirectionInfo = getRandomItem(rCi, candidatesEutraList);
            if (!selectedRedirectionInfo.has_value())
            {
                VCCB_PRINT_CALL_ERROR(&rCi, "%s: getRandomItem() for candidatesEutraList ERROR!\n", __FUNCTION__);
                return false;
            }

            if (!FnVCCB_USTM_ReleaseCallWithRedirectionToEutra(rCi, selectedRedirectionInfo.value()))
            {
                VCCB_PRINT_CALL_ERROR(
                    &rCi, "%s: FnVCCB_USTM_ReleaseCallWithRedirectionToEutra() ERROR!\n", __FUNCTION__);
                return false;
            }
        }
    }
    else
    {
        const auto &selectedMoIdx = getRandomItem(rCi, moIdxNrList);
        if (!selectedMoIdx.has_value())
        {
            VCCB_PRINT_CALL_ERROR(&rCi, "%s: getRandomItem() for moIdxNrList ERROR!\n", __FUNCTION__);
            return false;
        }

        if (GOOD != FnVCCB_USTM_ReleaseCallWithRedirectionToNr(rCi, selectedMoIdx.value()))
        {
            VCCB_PRINT_CALL_ERROR(&rCi, "%s: FnVCCB_USTM_ReleaseCallWithRedirectionToNr() ERROR!\n", __FUNCTION__);
            return false;
        }
    }

    return true;
}

bool FnVCCB_CheckIfForcedProcAllowed(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    if (!FnVCCB_USTM_IsProperCallType(rCi) || FnVCCB_USTM_CheckIfOtherFeaturesBlock(rCi))
    {
        VCCB_PRINT_CALL_INFORMATIVE(&rCi, "[USTM] procedure ignored because of UE type/mode.\n");
        return false;
    }
    if ((RrcReestablish_cmd == rCi.stateCmd) || (RRCSuspend_cmd == rCi.stateCmd) || (RRCResume_cmd == rCi.stateCmd))
    {
        VCCB_PRINT_CALL_INFORMATIVE(
            &rCi, "[USTM] procedure aborted because of RRCSuspend/RRCResume or RrcReestablishment ongoing \n");
        return false;
    }
    return true;
}
namespace
{
bool FnVCCB_TryToEnqueueForcedRelease(
    callInfo_type &rCi, callFaultForForcedRelease_type callFaultCause, uint8_t ulStatusReason)
{
    AUTO_TRACE_FUNC;

    auto &q = rCi.ustmInfo.queuedForcedReleaseInfo;
    if (CI_use == q.usage)
    {
        VCCB_PRINT_CALL_INFORMATIVE(&rCi,
            "[USTM] This Forced Release (%u) will not be enqueued as the queuedForcedReleaseInfo is already filled\n",
            ulStatusReason);
        return true;
    }

    q.lockedServCellNum = rCi.servCellNum;
    q.callFaultForForcedRelease = callFaultCause;
    q.ulStatusReason = ulStatusReason;
    q.usage = CI_use;
    if (ERROR == VCCM_enqueueAction(&rCi, ENQUEUE_ACTION_USTM_FORCED_RELEASE))
    {
        q.usage = CI_no_use;
        VCCB_PRINT_CALL_ERROR(
            &rCi, "VCCM_enqueueAction(ENQUEUE_ACTION_USTM_FORCED_RELEASE) in %s fail\n", __FUNCTION__);
        return false;
    }
    return true;
}

constexpr callFaultForForcedRelease_type UNKNOWN_CALL_FAULT_FOR_FORCED_RELEASE{0, 0};

bool operator==(const callFaultForForcedRelease_type &lhs, const callFaultForForcedRelease_type &rhs)
{
    return ((lhs.msgId == rhs.msgId) && (lhs.releaseCause == rhs.releaseCause));
}

bool FnVCCB_TryToEnqueueForcedHandover(
    callInfo_type &rCi, callFaultForForcedRelease_type callFaultCause, uint8_t ulStatusReason)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_FALSE(ulStatusReason, MAX_REASON_FORCED_MOBILITY);

    if (true == rCi.ustmInfo.statusReasonTable[ulStatusReason])
    {
        VCCB_PRINT_CALL_INFORMATIVE(
            &rCi, "[USTM] Forced Handover enqueue for reason %u is already processed\n", ulStatusReason);
        return true;
    }
    rCi.ustmInfo.statusReasonTable[ulStatusReason] = true;
    rCi.ustmInfo.lockedServCellNum = rCi.servCellNum;
    if (rCi.ustmInfo.callFaultForForcedRelease == UNKNOWN_CALL_FAULT_FOR_FORCED_RELEASE)
    {
        rCi.ustmInfo.callFaultForForcedRelease = callFaultCause;
    }
    if (ERROR == VCCM_enqueueAction(&rCi, ENQUEUE_ACTION_USTM_FORCED_MOBILITY))
    {
        VCCB_PRINT_CALL_ERROR(
            &rCi, "VCCM_enqueueAction(ENQUEUE_ACTION_USTM_FORCED_MOBILITY) in %s fail\n", __FUNCTION__);
        return false;
    }
    return true;
}
}  // namespace

/**
 * @brief Main function of FGR-MC1029 Forced Mobility due to DU Indication
 * @param[in] rCi: callInfo
 * @param[in] ptUnpack : unpacked message
 * @param[in] ptSctp: Pointer of Sctp Buffer
 * @param[in] pGNB_DU_UE_F1AP_ID: Pointer to gnbDuUeId
 * @return GOOD : FGR-MC1029 executed properly
 * @return BREAK : Conditions for FGR-MC1029 not satisfied
 * @return ERROR : Function execution error
 */
int16_t FnVCCB_HandleForcedMobilityDueToDuIndication(callInfo_type &rCi, msgUnpack_type *ptUnpack,
    SctpDataTransfer_type *ptSctp, F1_GNB_DU_UE_F1AP_ID *pGNB_DU_UE_F1AP_ID)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptUnpack);
    VALID_E_POINT_CHECK_ERROR(ptSctp);

    uint16_t f1ModCause = CAUSE_NO_FAULT;
    const F1_UEContextModificationRequired *msgRequired = ptUnpackConvert<F1_UEContextModificationRequired>(ptUnpack);

    DuIndicationStatus status = FnVCCB_USTM_CheckF1UEContextModRequired_IsDuIndication(rCi, *msgRequired, f1ModCause);
    if (DuIndicationStatus::unsupportedCause == status)
    {
        return BREAK;
    }

    logShmExtMsg(&rCi, RX_MSG, F1_UEContextModificationRequired_id, reinterpret_cast<uint8_t *>(ptSctp),
        pGNB_DU_UE_F1AP_ID ? *pGNB_DU_UE_F1AP_ID : PEER_UE_ID_UNDEFINED);

    if (DuIndicationStatus::error == status)
    {
        return ERROR;
    }

    VCCB_RETURN_ON_CALL_ERROR(&rCi, VFIL_sendF1_UeContextModificationConfirm(&rCi, NULL, ptSctp->endPointIdx),
        "VFIL_sendF1_UeContextModificationConfirm ERROR!\n");

    if (DuIndicationStatus::iesNotValid == status)
    {
        VCCB_PRINT_CALL_INFORMATIVE(&rCi, "[USTM] aborted due to invalid Msg IEs!\n");
        return GOOD;
    }

    if (!FnVCCB_CheckIfForcedProcAllowed(rCi))
    {
        return GOOD;
    }

    callFaultForForcedRelease_type callFaultCause = {F1_UEContextModificationRequired_id, CauseF1apRadioNormalRelease};
    if (CauseF1apRadioAmfInitiatedAbnormalRelease == f1ModCause)
    {
        if (!FnVCCB_TryToEnqueueForcedRelease(rCi, callFaultCause, ulStatusMobilityReason_ulPrbBlanking))
        {
            VCCB_PRINT_CALL_ERROR(&rCi, "[F1 Ue Cxt Required] Error in enqueuing Forced Release \n");
            return ERROR;
        }
    }
    else if (CauseF1apRadioUeRejection == f1ModCause)
    {
        if (!FnVCCB_TryToEnqueueForcedHandover(rCi, callFaultCause, ulStatusMobilityReason_ulPrbBlanking))
        {
            VCCB_PRINT_CALL_ERROR(&rCi, "[F1 Ue Cxt Required] Error in enqueuing Forced Handover \n");
            return ERROR;
        }
    }

    return GOOD;
}

int16_t FnVCCB_HandleDequeuedForcedRelease(callInfo_type *ptCi, enqueuedAction)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    auto &q = ptCi->ustmInfo.queuedForcedReleaseInfo;
    if (CI_use == q.usage)
    {
        VCCB_CHECK_E_RANGE_AND_RETURN(q.ulStatusReason, MAX_REASON_FORCED_MOBILITY);

        ptCi->ustmInfo.lockedServCellNum = q.lockedServCellNum;
        ptCi->ustmInfo.callFaultForForcedRelease = q.callFaultForForcedRelease;
        memset(ptCi->ustmInfo.statusReasonTable, 0, sizeof(ptCi->ustmInfo.statusReasonTable));
        ptCi->ustmInfo.statusReasonTable[q.ulStatusReason] = true;
        q.usage = CI_no_use;
    }

    if (ptCi->ustmInfo.lockedServCellNum != ptCi->servCellNum)
    {
        FnVCCB_USTM_Cancel(*ptCi);
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[USTM] Forced Release dequeue cancelled due to Serving Cell change!\n");
        return GOOD;
    }

    if (IS_ENDC_SN(ptCi))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[ENDC] SgNB release due to DU indication.\n");

        if (not FnVCCB_SaveFaultCauseAndTriggerRelease(*ptCi))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "%s: failed to trigger SN release.\n", __FUNCTION__);
            return ERROR;
        }

        return GOOD;
    }

    if (!FnVCCB_USTM_TriggerRedirection(*ptCi))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "%s failed!\n", __FUNCTION__);
    }

    return GOOD;
}

/**
 * @brief Starts the timer defined by FR210 of FGR-MC1029.
 *
 * @param rCall info
 */
void VCCB_USTM_StartTimerIfPossible(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_VALID_GNBNUM_VOID(rCi.gnbNum);

    constexpr uint32_t TIMER_INACTIVE = 0;

    if (TIMER_INACTIVE != GNBINFO[rCi.gnbNum].cfg.gnbMobilityConfig.callReleaseTimerByUplinkStatusIndication)
    {
        VLIB_AttachTimer(&rCi.ustmInfo.timer, &rCi, timInternalForcedHoMobility_id);
    }
}

bool FnVCCB_AreForcedHandoverMeasurementAvailable(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_VALID_CELLNUM_FALSE(ptCi->servCellNum);

    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    for (auto reason : USTM::allUlStatusMobilityReasons)
    {
        if (false == ptCi->ustmInfo.statusReasonTable[reason])
        {
            continue;
        }

        // try NR measurement first
        for (uint16_t objIdx = 0; objIdx < VCCB_ARRAY_COUNT(pCell->measurementsData.measurementObjectsNRDb); ++objIdx)
        {
            measurementObjectNRBaseDb_type *ptMO = &pCell->measurementsData.measurementObjectsNRDb[objIdx].base;

            if (!FnVCCB_USTM_IsDuForcedMobilityApplicable(*ptCi, ptMO))
            {
                continue;
            }

            const uint8_t reportPurpose = FnVCCB_MapUlStatusReasonToA5ReportPurpose(*ptCi, reason);
            const Arfcn_type ssb = ptMO->ssbFrequency;
            if (GOOD != VCCB_CanMOAndRCBeAdded(ptCi, ptCi->servCellNum, measReport_A5, reportPurpose, ssb))
            {
                continue;
            }

            // FGR-CC5001 FR81: find PSCell-capable band for NSA.
            if (VCCB_IsEndcSn(*ptCi))
            {
                const auto freqBandIndicatorNR = VCCB_MRDC_SN_SelectPscellBandOfMo(*ptCi, *ptMO);
                if (BAND_NOT_FOUND == freqBandIndicatorNR)
                {
                    VCCB_PRINT_CALL_COMMENT(ptCi, "%s: (MO %u) no PSCell-capable band.\n", __FUNCTION__, objIdx);
                    continue;
                }
            }

            return true;  // for the first found MO.
        }

        if (IS_ENDC_SN(ptCi))
        {
            continue;
        }

        // fallback to EUTRA measurement
        for (uint16_t objIdx = 0; objIdx < VCCB_ARRAY_COUNT(pCell->measurementsData.measurementObjectsEUTRADb);
            ++objIdx)
        {
            measurementObjectEUTRADb_type *ptMO = &pCell->measurementsData.measurementObjectsEUTRADb[objIdx];
            if (CI_use != ptMO->base.usage)
            {
                continue;
            }
            if (FALSE == ptMO->base.supportForcedMobilityByUplinkStatusIndication)
            {
                continue;
            }
            if (GOOD != VCCM_CheckSupportEutraMeasObject(ptCi, ptMO))
            {
                continue;
            }
            const uint8_t reportPurpose = FnVCCB_MapUlStatusReasonToB1ReportPurpose(reason);
            if (GOOD != VCCM_CheckSupportEutraMeasObject_ForIratHo(
                            ptCi, &(ptMO->base), ptCi->servCellNum, measReport_B1Eutra, reportPurpose))
            {
                continue;
            }
            const Arfcn_type carrierFreq = ptMO->base.carrierFreq;
            if (GOOD == VCCB_CanMOAndRCBeAdded(ptCi, ptCi->servCellNum, measReport_B1Eutra, reportPurpose, carrierFreq))
            {
                return true;
            }
        }
    }
    return false;
}

int16_t FnVCCB_HandleDequeuedForcedMobility(callInfo_type *ptCi, enqueuedAction)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    VCCB_CHECK_VALID_CELLNUM_ERROR(ptCi->servCellNum);

    if (ptCi->ustmInfo.lockedServCellNum != ptCi->servCellNum)
    {
        FnVCCB_USTM_Cancel(*ptCi);
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[USTM] Forced Mobility dequeue cancelled due to Serving Cell change!\n");
        return GOOD;
    }

    constexpr uint32_t TIMER_INACTIVE = 0;
    const bool timerAvailable =
        (TIMER_INACTIVE != GNBINFO[ptCi->gnbNum].cfg.gnbMobilityConfig.callReleaseTimerByUplinkStatusIndication);

    if (timerAvailable && (E_CALLTYPE_NSA != ptCi->callType))
    {
        VLIB_AttachTimer(&ptCi->ustmInfo.timer, ptCi, timInternalForcedHoMobility_id);
    }

    const bool triggerReconfigWhenTimerIsSet = (timerAvailable && (false == IS_ENDC_SN(ptCi)));

    if (triggerReconfigWhenTimerIsSet || FnVCCB_AreForcedHandoverMeasurementAvailable(ptCi))
    {
        ptCi->ustmInfo.measConfFilteringActive = TRUE;
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[USTM] Measurement Configuration filtering activated\n");

        ptCi->ustmInfo.startTimer = TRUE;

        if (ERROR == VCCM_EnqueueActionMeasReconfig(ptCi, MeasReconfigPriorAction_Full))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_EnqueueActionMeasReconfig ERROR!\n");
            return ERROR;
        }
    }
    else
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[USTM] No measurement is applicable\n");
        // FGR-CC5001 FR152 - release call after timer if no measurement is applicable.
        if (E_CALLTYPE_NSA == ptCi->callType)
        {
            VCCB_USTM_StartTimerIfPossible(*ptCi);
        }
    }

    return GOOD;
}

bool FnVCCB_USTM_IsDuForcedMobilityApplicable(callInfo_type &rCi, measurementObjectNRBaseDb_type *const ptMO)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptMO, false);

    if (CI_use != ptMO->usage)
    {
        return false;
    }

    if (TRUE != ptMO->supportForcedMobilityByUplinkStatusIndication)
    {
        VCCB_PRINT_LOG_USTM(&rCi,
            "MeasObject discarded since not supporting Uplink Status Triggered Mobility (ssbFreq=%u)!\n",
            ptMO->ssbFrequency);
        return false;
    }

    // Check UE Supported band
    if (BAND_NOT_FOUND == VCCB_GetMoNrBandForUe(&rCi, ptMO))
    {
        return false;
    }

    // Check SaCapable and redcap-access-allowed
    if (TRUE != fnVCCB_IsSaCapableMO(&rCi, ptMO))
    {
        return false;
    }

    // FR260.CACP.SR1.HD1 condition
    if (GOOD != VCCM_CheckSupportMeasObject(&rCi, ptMO, rCi.servCellNum))
    {
        return false;
    }

    return true;
}

/****************************************************************************
 * @brief           Answers the question: is measurement configuration filtering
                    active for given call and for given cell
 * @param[in]       rCi : reference to call configuration. / callInfo_type&
 * @param[in]       cellNum : cellNum of a given cell / CellNum_type
 * @return          true or false / bool
 ****************************************************************************/
bool FnVCCB_USTM_IsMeasConfFilteringActive(callInfo_type &rCi, const CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;
    return rCi.ustmInfo.measConfFilteringActive && (rCi.ustmInfo.lockedServCellNum == cellNum) &&
           !IS_FALLBACK_CASE((&rCi));
}

static void FnVCCB_USTM_InitPrivate(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;
    rCi.ustmInfo.lockedServCellNum = MAX_CELL_NUM_VCCB;
    rCi.ustmInfo.measConfFilteringActive = FALSE;
    rCi.ustmInfo.intraNrHandoverTriggered = FALSE;
    rCi.ustmInfo.interRatHandoverTriggered = FALSE;
    rCi.ustmInfo.redirectionTriggered = FALSE;
    rCi.ustmInfo.releaseTriggered = FALSE;
    rCi.ustmInfo.mrProcessing = FALSE;
    rCi.ustmInfo.startTimer = FALSE;
    rCi.ustmInfo.callFaultForForcedRelease = UNKNOWN_CALL_FAULT_FOR_FORCED_RELEASE;
    memset(rCi.ustmInfo.statusReasonTable, 0, sizeof(rCi.ustmInfo.statusReasonTable));
    rCi.ustmInfo.queuedForcedReleaseInfo.usage = CI_no_use;
}

/****************************************************************************
 * @brief           Init data related to Uplink Status Triggered Mobility
 * @param[in]       rCi : reference to call configuration. / callInfo_type&
 ****************************************************************************/
void FnVCCB_USTM_Init(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;
    VCCB_CLEAR_TIMER(&rCi.ustmInfo.timer, INIT_TIMER);
    FnVCCB_USTM_InitPrivate(rCi);
}

/****************************************************************************
 * @brief           Clean data related to Uplink Status Triggered Mobility
 * @param[in]       rCi : reference to call configuration. / callInfo_type&
 ****************************************************************************/
void FnVCCB_USTM_Cancel(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;
    VCCB_CLEAR_TIMER(&rCi.ustmInfo.timer, CANCEL_TIMER);
    FnVCCB_USTM_InitPrivate(rCi);
}

int16_t FnVCCB_HandleForcedMobilityTriggeredByE1(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    if (IS_ENDC_SN((&rCi)))
    {
        VCCB_PRINT_CALL_INFORMATIVE(&rCi, "[E1 Private Message] Forced Mobility is not allowed for ENDC SN UE case.\n");
        return GOOD;
    }

    if (!FnVCCB_CheckIfForcedProcAllowed(rCi))
    {
        VCCB_PRINT_CALL_INFORMATIVE(&rCi, "[E1 Private Message] Forced Mobility is not allowed\n");
        return GOOD;
    }

    callFaultForForcedRelease_type callFaultCause = {E1_PrivateMessage_id, CauseE1apRadioNetworkLayerNormalRelease};
    if (!FnVCCB_TryToEnqueueForcedHandover(rCi, callFaultCause, ulStatusMobilityReason_longRtpGap))
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "[E1 Private Message] Error in enqueuing Forced Handover\n");
        return ERROR;
    }

    return GOOD;
}

bool FnVCCB_CheckUlStatusReasonForF1PrivateMessage(callInfo_type &rCi, uint8_t ulStatusReason)
{
    AUTO_TRACE_FUNC;

    if (IS_ENDC_SN((&rCi)))
    {
        return (ulStatusReason == F1_tddinterference) || (ulStatusReason == F1_badulquality);
    }
    else
    {
        return (ulStatusReason == F1_ulprbblanking) || (ulStatusReason == F1_tddinterference) ||
               (ulStatusReason == F1_badulquality);
    }
}

int16_t FnVCCB_HandleForcedMobilityTriggeredByF1PrivateMessage(
    callInfo_type &rCi, uint8_t forcedMobilityMode, uint8_t ulStatusReason)
{
    AUTO_TRACE_FUNC;

    if (!FnVCCB_CheckUlStatusReasonForF1PrivateMessage(rCi, ulStatusReason))
    {
        VCCB_PRINT_LOG_USTM(&rCi, "UL Status Reason(%u) not supported by F1 Private Message\n", ulStatusReason);
        return ERROR;
    }

    if (!FnVCCB_CheckIfForcedProcAllowed(rCi))
    {
        VCCB_PRINT_CALL_INFORMATIVE(&rCi, "[F1 Private Message] Forced Mobility is not allowed\n");
        return GOOD;
    }

    callFaultForForcedRelease_type callFaultCause = {F1_PrivateMessage_id, CauseF1apRadioNormalRelease};
    if (forcedMobilityMode_forcedRelease == forcedMobilityMode)
    {
        if (!FnVCCB_TryToEnqueueForcedRelease(rCi, callFaultCause, ulStatusReason))
        {
            VCCB_PRINT_CALL_ERROR(&rCi, "[F1 Private Message] Error in enqueuing Forced Release \n");
            return ERROR;
        }
    }
    else if (forcedMobilityMode_forcedHandover == forcedMobilityMode)
    {
        if (!FnVCCB_TryToEnqueueForcedHandover(rCi, callFaultCause, ulStatusReason))
        {
            VCCB_PRINT_CALL_ERROR(&rCi, "[F1 Private Message] Error in enqueuing Forced Handover \n");
            return ERROR;
        }
    }
    return GOOD;
}

bool VCCM_USTM_CheckIfCellIsOverloaded(const callInfo_type &rCi, const VccbCellInfo_type &rCell, uint16_t nbrIdx)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_FALSE(nbrIdx, MAX_NBR_RELATION_TABLE_PER_CELL);

    if (!rCi.ustmInfo.mrProcessing)
    {
        return false;
    }

    if (CI_no_use == rCell.mobilityConfig.forcedMobilityDueToUplinkStatusIndication.loadBasedTargetSelection.usage)
    {
        VCCB_PRINT_LOG_USTM(&rCi, "Load-based target selection disabled\n");
        return false;
    }

    const auto &nbrPrbInfo = rCell.cellRscInfo.nbrPrb[nbrIdx];
    if (nbrPrbInfo.usage == N_EQUIP)
    {
        VCCB_PRINT_LOG_USTM(&rCi, "Neighbor PRB resource information not available\n");
        return false;
    }

    if (nbrPrbInfo.isRsUpdate == OFF)
    {
        VCCB_PRINT_LOG_USTM(&rCi, "NbrPrbInfo rsUpdate OFF\n");
        return false;
    }

    const auto &cellLoadBasedTargetSel =
        rCell.mobilityConfig.forcedMobilityDueToUplinkStatusIndication.loadBasedTargetSelection;
    if (nbrPrbInfo.dlCapacityValue < cellLoadBasedTargetSel.dlCapacityThreshold)
    {
        VCCB_PRINT_LOG_USTM(&rCi, "Cell with nbrIdx %u is overloaded dlCapacityValue: %u, dlCapacityThreshold: %u\n",
            nbrIdx, nbrPrbInfo.dlCapacityValue, cellLoadBasedTargetSel.dlCapacityThreshold);
        return true;
    }

    if (nbrPrbInfo.ulCapacityValue < cellLoadBasedTargetSel.ulCapacityThreshold)
    {
        VCCB_PRINT_LOG_USTM(&rCi, "Cell with nbrIdx %u is overloaded ulCapacityValue: %u, ulCapacityThreshold: %u\n",
            nbrIdx, nbrPrbInfo.ulCapacityValue, cellLoadBasedTargetSel.ulCapacityThreshold);
        return true;
    }
    VCCB_PRINT_LOG_USTM(&rCi, "Cell with nbrIdx %u is not overloaded\n", nbrIdx);
    return false;
}

std::optional<enumUlStatusMobilityReason_type> FnVCCB_MapUlStatusReasonFromReportTypeAndPurpose(
    uint8_t reportType, uint8_t reportPurpose)
{
    AUTO_TRACE_FUNC;

    if (reportType == measReport_A5)
    {
        switch (reportPurpose)
        {
            case a5Purpose_intraNrDuTriggeredForcedHandover:
            {
                return ulStatusMobilityReason_ulPrbBlanking;
            }
            case a5Purpose_forcedHandoverDueToBadUlQuality:
            {
                return ulStatusMobilityReason_badUlQuality;
            }
            case a5Purpose_forcedHandoverDueToTddInterference:
            {
                return ulStatusMobilityReason_tddInterference;
            }
            case a5Purpose_forcedHandoverDueToLongRtpGap:
            {
                return ulStatusMobilityReason_longRtpGap;
            }
            default:
                break;
        }
    }
    else if (reportType == measReport_B1Eutra)
    {
        switch (reportPurpose)
        {
            case b1Purpose_eutraForcedHandoverDueToUlPrbBlanking:
            {
                return ulStatusMobilityReason_ulPrbBlanking;
            }
            case b1Purpose_eutraForcedHandoverDueToBadUlQuality:
            {
                return ulStatusMobilityReason_badUlQuality;
            }
            case b1Purpose_eutraForcedHandoverDueToTddInterference:
            {
                return ulStatusMobilityReason_tddInterference;
            }
            case b1Purpose_eutraForcedHandoverDueToLongRtpGap:
            {
                return ulStatusMobilityReason_longRtpGap;
            }
            default:
                break;
        }
    }
    return std::nullopt;
}

enumA5Purpose FnVCCB_MapUlStatusReasonToA5ReportPurpose(
    const callInfo_type &rCi, enumUlStatusMobilityReason_type statusReason)
{
    AUTO_TRACE_FUNC;

    if (IS_ENDC_SN((&rCi)))
    {
        switch (statusReason)
        {
            case ulStatusMobilityReason_ulPrbBlanking:
                return a5Purpose_EndcNrPscellChangeDuIndication;
            case ulStatusMobilityReason_tddInterference:
                return a5Purpose_EndcPscellChangeUlStatusIndTddInterference;
            case ulStatusMobilityReason_badUlQuality:
                return a5Purpose_EndcPscellChangeUlStatusIndBadUlQuality;
            case ulStatusMobilityReason_longRtpGap:
                return a5Purpose_EndcNrPscellChangeDuIndication;
            default:
                return a5Purpose_EndcNrPscellChangeDuIndication;
        }
    }
    else
    {
        switch (statusReason)
        {
            case ulStatusMobilityReason_ulPrbBlanking:
                return a5Purpose_intraNrDuTriggeredForcedHandover;
            case ulStatusMobilityReason_tddInterference:
                return a5Purpose_forcedHandoverDueToTddInterference;
            case ulStatusMobilityReason_badUlQuality:
                return a5Purpose_forcedHandoverDueToBadUlQuality;
            case ulStatusMobilityReason_longRtpGap:
                return a5Purpose_forcedHandoverDueToLongRtpGap;
            default:
                return a5Purpose_intraNrDuTriggeredForcedHandover;
        }
    }
}

enumB1Purpose FnVCCB_MapUlStatusReasonToB1ReportPurpose(enumUlStatusMobilityReason_type statusReason)
{
    AUTO_TRACE_FUNC;

    switch (statusReason)
    {
        case ulStatusMobilityReason_ulPrbBlanking:
            return b1Purpose_eutraForcedHandoverDueToUlPrbBlanking;
        case ulStatusMobilityReason_tddInterference:
            return b1Purpose_eutraForcedHandoverDueToTddInterference;
        case ulStatusMobilityReason_badUlQuality:
            return b1Purpose_eutraForcedHandoverDueToBadUlQuality;
        case ulStatusMobilityReason_longRtpGap:
            return b1Purpose_eutraForcedHandoverDueToLongRtpGap;
        default:
            return b1Purpose_eutraForcedHandoverDueToUlPrbBlanking;
    }
}

std::optional<int> FnVCCB_MapUlStatusReasonAndNrHandoverPhaseToCounterType(uint8_t statusReason, enumHoStatType type)
{
    AUTO_TRACE_FUNC;

    switch (statusReason)
    {
        case ulStatusMobilityReason_ulPrbBlanking:
            switch (type)
            {
                case HO_Att:
                    return HoOutByDuTriggeredForcedMobility_Att;
                case HO_PrepSucc:
                    return HoOutByDuTriggeredForcedMobility_PrepSucc;
                case HO_Succ:
                    return HoOutByDuTriggeredForcedMobility_Succ;
                case HO_HandoverCancel:
                    return HoOutByUlStatusTriggered_UlPrbBlanking_Cancel;
                case HO_RRE:
                    return HoOutByUlStatusTriggered_UlPrbBlanking_RRE;
                default:
                    return std::nullopt;
            }
        case ulStatusMobilityReason_tddInterference:
            switch (type)
            {
                case HO_Att:
                    return HoOutByUlStatusTriggeredForcedMobility_TddInterference_Att;
                case HO_PrepSucc:
                    return HoOutByUlStatusTriggeredForcedMobility_TddInterference_PrepSucc;
                case HO_Succ:
                    return HoOutByUlStatusTriggeredForcedMobility_TddInterference_Succ;
                case HO_HandoverCancel:
                    return HoOutByUlStatusTriggeredForcedMobility_TddInterference_Cancel;
                case HO_RRE:
                    return HoOutByUlStatusTriggeredForcedMobility_TddInterference_RRE;
                default:
                    return std::nullopt;
            }
        case ulStatusMobilityReason_badUlQuality:
            switch (type)
            {
                case HO_Att:
                    return HoOutByUlStatusTriggeredForcedMobility_BadUlQuality_Att;
                case HO_PrepSucc:
                    return HoOutByUlStatusTriggeredForcedMobility_BadUlQuality_PrepSucc;
                case HO_Succ:
                    return HoOutByUlStatusTriggeredForcedMobility_BadUlQuality_Succ;
                case HO_HandoverCancel:
                    return HoOutByUlStatusTriggeredForcedMobility_BadUlQuality_Cancel;
                case HO_RRE:
                    return HoOutByUlStatusTriggeredForcedMobility_BadUlQuality_RRE;
                default:
                    return std::nullopt;
            }
        case ulStatusMobilityReason_longRtpGap:
            switch (type)
            {
                case HO_Att:
                    return HoOutByUlStatusTriggeredForcedMobility_LongRtpGap_Att;
                case HO_PrepSucc:
                    return HoOutByUlStatusTriggeredForcedMobility_LongRtpGap_PrepSucc;
                case HO_Succ:
                    return HoOutByUlStatusTriggeredForcedMobility_LongRtpGap_Succ;
                case HO_HandoverCancel:
                    return HoOutByUlStatusTriggeredForcedMobility_LongRtpGap_Cancel;
                case HO_RRE:
                    return HoOutByUlStatusTriggeredForcedMobility_LongRtpGap_RRE;
                default:
                    return std::nullopt;
            }
        default:
            return std::nullopt;
    };
}

std::optional<int> FnVCCB_MapUlStatusReasonAndInterRatHandoverPhaseToCounterType(
    uint8_t statusReason, enumHoStatType type)
{
    AUTO_TRACE_FUNC;

    switch (statusReason)
    {
        case ulStatusMobilityReason_ulPrbBlanking:
            switch (type)
            {
                case HO_Att:
                    return HoLteOutByUlStatusTriggeredForcedMobility_UlPrbBlanking_Att;
                case HO_PrepSucc:
                    return HoLteOutByUlStatusTriggeredForcedMobility_UlPrbBlanking_PrepSucc;
                case HO_Succ:
                    return HoLteOutByUlStatusTriggeredForcedMobility_UlPrbBlanking_Succ;
                case HO_HandoverCancel:
                    return HoLteOutByUlStatusTriggeredForcedMobility_UlPrbBlanking_Cancel;
                case HO_RRE:
                    return HoLteOutByUlStatusTriggeredForcedMobility_UlPrbBlanking_RRE;
                default:
                    return std::nullopt;
            }
        case ulStatusMobilityReason_tddInterference:
            switch (type)
            {
                case HO_Att:
                    return HoLteOutByUlStatusTriggeredForcedMobility_TddInterference_Att;
                case HO_PrepSucc:
                    return HoLteOutByUlStatusTriggeredForcedMobility_TddInterference_PrepSucc;
                case HO_Succ:
                    return HoLteOutByUlStatusTriggeredForcedMobility_TddInterference_Succ;
                case HO_HandoverCancel:
                    return HoLteOutByUlStatusTriggeredForcedMobility_TddInterference_Cancel;
                case HO_RRE:
                    return HoLteOutByUlStatusTriggeredForcedMobility_TddInterference_RRE;
                default:
                    return std::nullopt;
            }
        case ulStatusMobilityReason_badUlQuality:
            switch (type)
            {
                case HO_Att:
                    return HoLteOutByUlStatusTriggeredForcedMobility_BadUlQuality_Att;
                case HO_PrepSucc:
                    return HoLteOutByUlStatusTriggeredForcedMobility_BadUlQuality_PrepSucc;
                case HO_Succ:
                    return HoLteOutByUlStatusTriggeredForcedMobility_BadUlQuality_Succ;
                case HO_HandoverCancel:
                    return HoLteOutByUlStatusTriggeredForcedMobility_BadUlQuality_Cancel;
                case HO_RRE:
                    return HoLteOutByUlStatusTriggeredForcedMobility_BadUlQuality_RRE;
                default:
                    return std::nullopt;
            }
        case ulStatusMobilityReason_longRtpGap:
            switch (type)
            {
                case HO_Att:
                    return HoLteOutByUlStatusTriggeredForcedMobility_LongRtpGap_Att;
                case HO_PrepSucc:
                    return HoLteOutByUlStatusTriggeredForcedMobility_LongRtpGap_PrepSucc;
                case HO_Succ:
                    return HoLteOutByUlStatusTriggeredForcedMobility_LongRtpGap_Succ;
                case HO_HandoverCancel:
                    return HoLteOutByUlStatusTriggeredForcedMobility_LongRtpGap_Cancel;
                case HO_RRE:
                    return HoLteOutByUlStatusTriggeredForcedMobility_LongRtpGap_RRE;
                default:
                    return std::nullopt;
            }
        default:
            return std::nullopt;
    };
}

std::optional<int> FnVCCB_MapUlStatusReasonToNRCounter(enumUlStatusMobilityReason_type statusReason)
{
    AUTO_TRACE_FUNC;

    switch (statusReason)
    {
        case ulStatusMobilityReason_ulPrbBlanking:
            return UeRelByDuTriggeredForcedMobility;
        case ulStatusMobilityReason_tddInterference:
            return UeRelByUlStatusTriggeredForcedMobility_TddInterference;
        case ulStatusMobilityReason_badUlQuality:
            return UeRelByUlStatusTriggeredForcedMobility_BadUlQuality;
        case ulStatusMobilityReason_longRtpGap:
            return UeRelByUlStatusTriggeredForcedMobility_LongRtpGap;
        default:
            return std::nullopt;
    }
}

std::optional<int> FnVCCB_MapUlStatusReasonToEUTRACounter(enumUlStatusMobilityReason_type statusReason)
{
    AUTO_TRACE_FUNC;

    switch (statusReason)
    {
        case ulStatusMobilityReason_ulPrbBlanking:
            return UeRelToLteByUlStatusTriggeredForcedMobility_UlPrbBlanking;
        case ulStatusMobilityReason_tddInterference:
            return UeRelToLteByUlStatusTriggeredForcedMobility_TddInterference;
        case ulStatusMobilityReason_badUlQuality:
            return UeRelToLteByUlStatusTriggeredForcedMobility_BadUlQuality;
        case ulStatusMobilityReason_longRtpGap:
            return UeRelToLteByUlStatusTriggeredForcedMobility_LongRtpGap;
        default:
            return std::nullopt;
    }
}

/****************************************************************************
 * @brief           If MR based redirection is triggered by Forced Handover then
 *                  USTM status reason table need to be reset so that correct
 *                  counters are updated.
 *
 * @param[in/out]   rCi : reference to call configuration. / callInfo_type&
 ****************************************************************************/
void FnVCCB_USTM_SetStateForMRBasedRedirection(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(rCi.ustmInfo.ulStatusReasonTriggeredHandover, MAX_REASON_FORCED_MOBILITY);

    rCi.ustmInfo.redirectionTriggered = TRUE;
    memset(rCi.ustmInfo.statusReasonTable, 0, sizeof(rCi.ustmInfo.statusReasonTable));
    rCi.ustmInfo.statusReasonTable[rCi.ustmInfo.ulStatusReasonTriggeredHandover] = true;
}

/***********************************************************************************
 * @brief           Check USTM NR purpose and report type
 * @param[in]       reportType : input Report Type
 * @param[in]       reportPurpose : input Report Purpose
 * @return          result        : true, false / bool
 ***********************************************************************************/
bool FnVCCB_USTM_IsUstmNrReportTypePurpose(uint8_t reportType, uint8_t reportPurpose)
{
    AUTO_TRACE_FUNC;

    if (reportType == measReport_A5)
    {
        switch (reportPurpose)
        {
            case a5Purpose_intraNrDuTriggeredForcedHandover:
            case a5Purpose_forcedHandoverDueToBadUlQuality:
            case a5Purpose_forcedHandoverDueToTddInterference:
            case a5Purpose_forcedHandoverDueToLongRtpGap:
                return true;
            default:
                return false;
        }
    }
    
    return false;
}

/***********************************************************************************
 * @brief           Check USTM EUTRA purpose and report type
 * @param[in]       reportType : input Report Type
 * @param[in]       reportPurpose : input Report Purpose
 * @return          result        : true, false / bool
 ***********************************************************************************/
bool FnVCCB_USTM_IsUstmEutraReportTypePurpose(uint8_t reportType, uint8_t reportPurpose)
{
    AUTO_TRACE_FUNC;

    if (reportType == measReport_B1Eutra)
    {
        switch (reportPurpose)
        {
            case b1Purpose_eutraForcedHandoverDueToUlPrbBlanking:
            case b1Purpose_eutraForcedHandoverDueToBadUlQuality:
            case b1Purpose_eutraForcedHandoverDueToTddInterference:
            case b1Purpose_eutraForcedHandoverDueToLongRtpGap:
                return true;
            default:
                return false;
        }
    }

    return false;
}
