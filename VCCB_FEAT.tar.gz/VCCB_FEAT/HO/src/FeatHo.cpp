/**
 * @file        FeatHo.cpp
 * @brief       This function provides a function for controlling the operation of the Mobility Feature for the SA UE.
 */

#include "FeatHoCommon.h"
#include "FeatCa.hpp"
#include "FeatMco.h"
#include "FeatMrl.h"
#include "FeatMro.h"
#include "FeatRrcInactive.h"
#include "FeatRre.h"
#include "FeatSon.h"
#include "FeatLb.hpp"
#include "FeatMrdc.h"
#include "FeatTrace.h"
#include "FeatTrace.hpp"
#include "FeatCommon.h"
#include "FeatCallInfo.h"
#include "FeatCallProc.h"
#include "FeatSecurity.h"
#include "FeatFullConfig.h"
#include "FeatRrcSegment.h"
#include "FeatMeasurements.hpp"
#include "FeatUlPathControlNRDC.h"
#include "FeatNonNeighborHo.h"
#include "UplinkStatusTriggeredMobility.hpp"
#include "FeatUeHistory.h"
#include "FeatVoma.hpp"

#include "ComInclude.h"
#include "ComLibUtility.h"
#include "ComTimeUtil.h"

#include "StateCommon.h"
#include "StateSaHo.h"
#include "StateSaHoSN.h"

#include "StateHandleAll.h"
#include "StateHandleSaMrdc.h"

#include "MsgNrRrcStore.h"
#include "MsgNrRrcSend.h"
#include "MsgNgapSend.h"
#include "MsgXnapSend.h"
#include "MsgOamStore.h"
#include "MsgXnapMake.h"

#include "nrrrcUnpack.h"
#include "xnapUnpackMsg.h"


// Mutex for overloaded target gnb list management
static pthread_mutex_t gOverloadHoTgtGnbMutex[MAX_GNB_CU_CP_FUNCTION_PER_SYS];
/****************************************************************************
                            Handover Trigger Function

 1. MN Mobility
    1.1 MN-Intra-GNB Intra-RAT Handover : VHCM_StartSaHandover_IntragNB
        1.1.1 Intra-DU Handover         : FnVCCB_ProcSaHandover_IntraDU
        1.1.2 Inter-DU Handover         : FnVCCB_ProcSaHandover_InterDU
    1.2 MN-Inter-GNB Intra-RAT Handover : VHCM_StartSaHandover_IntergNB
        1.2.1 Preparation               : FnVCCB_ProcSaHandover_IntergNB_Prepare
        1.2.2 Execution                 : FnVCCB_ProcSaHandover_IntergNB_Execution
    1.3 MN-Inter-GNB Inter-RAT Handover : VHCM_StartSaHandover_InterRAT

 2. SN Mobility
    2.1 SN-Intra-GNB Handover
        2.1.1 MN : FnVCCB_StartSaHandover_IntraSN (Modification Required)
        2.1.2 SN : FnVCCB_StartSaHandoverSN_IntragNB
              2.1.2.1 Intra-DU Handover : FnVCCB_ProcSaHandoverSN_IntraDU
              2.1.2.2 Inter-DU Handover : FnVCCB_ProcSaHandoverSN_InterDU
    2.2 SN-Inter-GNB Handover
        2.2.1 MN : FnVCCB_StartSaHandover_InterSN (Changed Required)
        2.2.2 SN : FnVCCB_StartSaHandoverSN_IntergNB

****************************************************************************/

//  1. MN Mobility
// {{{
// 1.1 MN-Intra-GNB Intra-RAT Handover : VHCM_StartSaHandover_IntragNB
/****************************************************************************
 * @brief           Start SA Intra gNB Handover
 * @details         Make preparation in callInfo for SA handover
 * @param[in,out]   ptCi : call information / callInfo_type
 * @param[in]       targetCellSelection : neighbour intra gNB cellNum with selected band/ cellSelection_type
 * @param[in]       cause : cause of GNB change / uint16_t
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VHCM_StartSaHandover_IntragNB(callInfo_type *ptCi, const cellSelection_type targetCellSelection, uint16_t cause, StartSaHandoverDb& hoInputDb)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = ERROR;
    enumHoTypeDu eHoTypeDu = HO_TYPE_INTRA_DU;
    uint8_t initiated = HO_TYPE_SA_INIT;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    VCCB_CHECK_E_RANGE_AND_RETURN(targetCellSelection.cellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pTgtCell = &CELLINFO[targetCellSelection.cellNum];
    VccbCellInfo_type *const pServCell = &CELLINFO[ptCi->servCellNum];
    VCCB_CHECK_E_RANGE_AND_RETURN(pTgtCell->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(pTgtCell->endPointF1Index, MAX_GNB_DU_PER_GNB_CU_CP);

    // This operation is a class operation for controlling the Ho-related database.
    HoDbConroller hoDbConroller(ptCi);

    if (targetCellSelection.cellNum == ptCi->servCellNum)
    {
        if (DBG->flag.notAllowedIntraCellHO_BasicHO == VCCB_FLAG_ON)
        {
            // HO does not support handover for intra cell. We need to review the procedure for this.
            VCCB_PRINT_CALL_INFORMATIVE(
                ptCi, "VHCM_StartSaHandover_IntragNB: HO does not support handover for intra cell.\n");
            return GOOD;
        }
    }

    if (0 == ptCi->numPDUSess)  // This code is a protection code. PDU Session existence must be checked before calling
                                // this function.
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "VHCM_StartSaHandover_IntragNB: Trigger Discarded because there are no PDU sessions\n");
        return GOOD;
    }

    // TODO: need to modify the input value
    switch (cause)
    {
        case e_HoTrigger_ConditionalHandoverPrep:
        case e_HoTrigger_ConditionalHandoverExec:
        case e_HoTrigger_LtmHandoverPrep:
        case e_HoTrigger_LtmHandoverExec:
            if (IS_MRDC_MN(ptCi))
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "discard event\n");
                return GOOD;
            }
            break;

        default:
            break;
    }

    switch (cause)
    {
        case e_HoTrigger_ConditionalHandoverExec:
            // response flag could be remained..
            break;

        case e_HoTrigger_ConditionalHandoverPrep:
        case e_HoTrigger_LtmHandoverPrep:
        case e_HoTrigger_LtmHandoverExec:
        default:
            if (VLIB_CheckAllConnected(ptCi) == ERROR)
            {
                FnVCCB_ControlResponseFlagInSaHo(ptCi, __func__);
            }
            break;
    }

    // CRR Reset
    MACRO_RESET_CALL_FAULT_CAUSES;

    // SVR22B FGR-CC5203
    // FR60 [Case D-1] @MN
    // When the call is in suspend state, MN VCCB shall trigger sending SN Release Request message if MN Mobility is
    // triggered.
    if (IS_SCG_SUSPENDED(ptCi) && DBG->flag.disabledSnReleaseWhenTriggeringHoWhileScgSuspend == VCCB_FLAG_OFF)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "HO Request in the SCG Suspend State! Discard HO and start SN Release procedure!\n");

        // MN-Init SN-Release
        status = VCCM_ProcSCGFailWithSnRelease(ptCi, MrdcRelCause_Handover);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_ProcSCGFailWithSnRelease ERROR!\n");

        return GOOD;
    }

    status = VHCM_DecisionIntraGnbSaHandoverType(ptCi, targetCellSelection.cellNum, &eHoTypeDu);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VHCM_DecisionIntraGnbSaHandoverType ERROR!\n");

    // Check UE's appliedFreqBandListFilter and System Configuration
    if (BAND_NOT_FOUND == targetCellSelection.bandNr)
    {
        if (HO_TYPE_INTRA_DU == eHoTypeDu)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "IntraDU HO - VLIB_GetFreqBandIndForCell - Not Allowed!\n");
        }
        else
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "InterDU HO - VLIB_GetFreqBandIndForCell - Not Allowed!\n");
        }
        return GOOD;
    }

    if (ERROR == VLIB_checkDssAllowed(ptCi, BAND_NOT_SET, false, pTgtCell))
    {
        if (HO_TYPE_INTRA_DU == eHoTypeDu)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "IntraDU HO - VLIB_checkDssAllowed - Not Allowed!\n");
        }
        else
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "InterDU HO - VLIB_checkDssAllowed - Not Allowed!\n");
        }
        return GOOD;
    }

    if (eHoTypeDu == HO_TYPE_INTRA_DU)
        initiated = HO_TYPE_SA_INTRA_GNB_INTRA_DU_HANDOVER;
    else
        initiated = HO_TYPE_SA_INTRA_GNB_INTER_DU_HANDOVER;
    SET_STATE_CMD(IntraRatHO_cmd);
    FnVCCB_SetIntraGnbCommonHoInfo(ptCi, targetCellSelection, cause, initiated, eHoTypeDu);

    // TODO: LB and MRO feature owner
    switch (cause)
    {
        case e_HoTrigger_ConditionalHandoverPrep:
        case e_HoTrigger_ConditionalHandoverExec:
        case e_HoTrigger_LtmHandoverPrep:
        case e_HoTrigger_LtmHandoverExec:
            break;

        default:
            /*Set true, only when HO is triggered by LB MR */
            FnVCCB_UpdateIsLbHoFlag(ptCi, hoInputDb);
            FnVCCB_UpdateForcedMobilityHoFlag(ptCi, hoInputDb);
            FnVCCB_UpdateMroHoInfoOnSourceGnb(ptCi, HO_TYPE_INTRA_RAT, HO_TYPE_INTRA_NB);
            break;
    }

    const auto quantity = hoInputDb.getQuantity();

    ptCi->hoInfo.reportType = hoInputDb.getReportType();
    ptCi->hoInfo.reportPurpose = hoInputDb.getReportPurpose();
    ptCi->hoInfo.reportConfigQuantitySaHo = quantity;
    ptCi->hoInfo.tgtSsbFreq = pTgtCell->ssbArfcn;
    ptCi->hoInfo.tgtPlmn.longId = ptCi->hoInfo.selectedTAI.plmn.longId;
    ptCi->hoInfo.isSnInitMobilityInMn = false; // Mn Init Inter-MN
    ptCi->cslInfo.cslRreInfo.rreCase = csl_Intra_gNB_HO;
    ptCi->hoInfo.ltmHandover =
        (cause == e_HoTrigger_LtmHandoverPrep ||
         cause == e_HoTrigger_LtmHandoverExec);

    // SVR22B FGR-CC5203: Deconfigure A4 for SCG resume and Update MeasConfig
    ptCi->nrdcScgFailureInfo.A4Configured = VCCB_FLAG_OFF;

    bool isLtmHo = (cause == e_HoTrigger_LtmHandoverPrep || cause == e_HoTrigger_LtmHandoverExec);
    /* check the intra cell handover condition */
    if (ptCi->servCellNum != ptCi->hoInfo.targetCellNum && not isLtmHo)
    {
        status = VHCM_UpdateUeHistoryInformation_Prepare(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VHCM_UpdateUeHistoryInformation_Prepare ERROR!\n");
    }

    VLIB_InitHoStat(ptCi);

    string ueType;
    switch (cause)
    {
        case e_HoTrigger_ConditionalHandoverPrep:
            ueType = "CHO-Prep";
            break;

        case e_HoTrigger_ConditionalHandoverExec:
            ueType = "CHO-Exec";
            break;

        case e_HoTrigger_LtmHandoverPrep:
            ueType = "LTM-Prep";
            break;

        case e_HoTrigger_LtmHandoverExec:
            ueType = "LTM-Exec";
            break;

        case e_HoTrigger_ImmediateHandover:
        default:
            ueType = "IM";
            break;
    }

    auto strQuantity = (quantity == choice_rsrp ? "P":(quantity == choice_rsrq ? "Q":(quantity == choice_sinr ? "S":"UNDEF")));

    VCCB_PRINT_CALL_INFORMATIVE(ptCi,
        "Start Intra-gNB HO(%s) : cellNum(%u->%u), f1Idx(%u->%u), secModFlag(%u) cgi(%llu->%llu), SsbFreq(%u), Q(%s),\n",
        ueType.c_str(), ptCi->servCellNum, ptCi->hoInfo.targetCellNum, ptCi->endPointInfo.f1Idx,
        ptCi->hoInfo.targetDu.f1Idx, ptCi->ueInfo.securityModFlag, 1ULL * pServCell->cgi.ci, 1ULL * pTgtCell->cgi.ci,
        ptCi->hoInfo.tgtSsbFreq, strQuantity);

    VCCM_SelectUlPath_NRDC(ptCi, true);

    FnVCCB_PrintMrdcDrbInformation(ptCi);

    // TODO: MDT feature owner
    switch (cause)
    {
        case e_HoTrigger_ConditionalHandoverPrep:
        case e_HoTrigger_LtmHandoverPrep:
            break;

        case e_HoTrigger_ConditionalHandoverExec:
        case e_HoTrigger_LtmHandoverExec:
        default:
            ptCi->managementTraceInfo.isHoRrcReconfCmpleFlag = VCCB_FLAG_OFF;

            if (ptCi->servCellNum != ptCi->hoInfo.targetCellNum)
            {
                status = VLIB_stopManagementMdtTrace(ptCi, ptCi->servCellNum);
                VCCB_PRINT_WITHOUT_RETURN_ON_CALL_ERROR(ptCi, status, "[MDT][MGT] VLIB_stopManagementMdtTrace cellNum(%i) error.\n",
                        ptCi->servCellNum);
                status = VLIB_stopManagementUeThrRfTrace(ptCi, ptCi->servCellNum);
                VCCB_PRINT_WITHOUT_RETURN_ON_CALL_ERROR(ptCi, status, "[UETHR][MGT] VLIB_stopManagementUeThrRfTrace cellNum(%i) error.\n",
                        ptCi->servCellNum);

                traceMdtStatus_type sessionToDeactivate = {
                    .immediate = (mdtImmediate == ptCi->signalingTraceInfo.mdt.mdtStatus),
                    .logged = (mdtLogged == ptCi->signalingTraceInfo.mdt.mdtStatus),
                    .uethr = (VCCB_FLAG_ON == ptCi->signalingTraceInfo.trace.ueThroughputAndRfTraceFlag),
                    .trace = false
                };
                deactivateSigMdtTrace(ptCi, sessionToDeactivate, false);

                // Trace/UETHR need to validate RFSP/SPID condition once again
                ptCi->managementTraceInfo.traceRfspSpidAllowed = traceRfspSpidUnknown;

                VLIB_startManagementMdtTrace(ptCi, ptCi->hoInfo.targetCellNum);
                VLIB_startManagementUeThrRfTrace(ptCi, ptCi->hoInfo.targetCellNum);
                VRRM_delCellNonDssUeCount(ptCi);
                VRRM_delLoggedMdtCapableUeCount(ptCi);
                VRRM_addCellNonDssUeCount(ptCi, ptCi->hoInfo.targetCellNum);
                status = VLIB_stopLoggedMdtTrace(ptCi, ptCi->servCellNum);
                VCCB_PRINT_WITHOUT_RETURN_ON_CALL_ERROR(ptCi, status, "[MDT][MGT] VLIB_stopLoggedMdtTrace cellNum(%i) error.\n",
                        ptCi->servCellNum);
                status = VLIB_stopRlfAndRcefdMdtTrace(ptCi, ptCi->servCellNum);
                VCCB_PRINT_WITHOUT_RETURN_ON_CALL_ERROR(ptCi, status, "[MDT][MGT] VLIB_stopRlfAndRcefdMdtTrace cellNum(%i) error.\n",
                        ptCi->servCellNum);

                // SVR26A FGR-TA0601 VoMA CallEvent
                vomaCallEvent_type eventType = VOMA_interDuHo;
                if (HO_TYPE_INTRA_DU == ptCi->hoInfo.hoType.du)
                {
                    eventType = VOMA_intraDuHo;
                }
                VLIB_VomaPrepareIntraGnb(*ptCi, eventType);
            }
            else // SVR26A FGR-TA0601 VoMA CallEvent - IntraCell
            {
                ptCi->vomaInfo.vomaEvent = VOMA_intraCellHo;
            }
            break;
    }

    // update the DB to prev DB
    FnVCCB_updateMrdcPrevInfo(ptCi);

    /* decision full configuration with checking function */
    status = VCCM_DecideCuInitFullConfigSA(ptCi, NULL, __func__);
    if (status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Accept By FullConfiguration (SA/NRDC-MN/NEDC-MN, Intra-gNB HO)!\n");

        VCOM_SaHandoverCancel_ToConn(ptCi, NRRRC_MeasurementReport_id);
        return GOOD;
    }

    /* MR DC mobility */
    status = FnVCCB_MrdcMobilityProc_Intra(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_MrdcMobilityProc_Intra ERROR!\n");
    if (status == BREAK)
    {
        // ho cancel processing
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "After releasing SN, HO proceeds to the next MR.\n");
        VCOM_SaHandoverCancel_ToConn(ptCi, NRRRC_MeasurementReport_id);
        return GOOD;
    }

    // Clear the Sn Status Flag
    FnVCCB_InitSnStatusFlag(ptCi);

    // Check VoNR Call (23B)
    if (TRUE == FnVCCB_IsVoNRCall(ptCi))
    {
        ptCi->hoInfo.isVonrCall = TRUE;
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "callId : %d, UE is VoNR Call.\n", ptCi->callId);
    }

    // Trigger Handover
    switch (cause)
    {
        case e_HoTrigger_ConditionalHandoverPrep:
        case e_HoTrigger_ConditionalHandoverExec:
            /* TBD: There is no function */
            VCCB_PRINT_CALL_ERROR(ptCi, "There is no event for CHO Prep/Exec\n");
            return ERROR;

        case e_HoTrigger_LtmHandoverExec:
            status = FnVCCB_triggerLtmExecution(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_triggerLtmExecution ERROR!\n");
            break;

        case e_HoTrigger_LtmHandoverPrep:
            status = FnVCCB_triggerLtmPrep(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_triggerLtmPrep ERROR!\n");
            break;

        default:
            // 25B FGR-MC1008:FR170
            FnVCCB_SetCurrentlyAllowPartialHO(*ptCi, true);
            if (ptCi->hoInfo.hoType.du == HO_TYPE_INTRA_DU)
            {
                status = FnVCCB_ProcSaHandover_IntraDU(ptCi);
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_ProcSaHandover_IntraDU ERROR!\n");
            }
            else
            {
                status = FnVCCB_ProcSaHandover_InterDU(ptCi);
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_ProcSaHandover_InterDU ERROR!\n");
            }
            break;
    }

    // Handover Trigger Completed
    hoDbConroller.setHandoverTriggerCompleted(true);

    return GOOD;
}  // }}}

//        1.1.1 Intra-DU Handover         : FnVCCB_ProcSaHandover_IntraDU
int16_t FnVCCB_ProcSaHandover_IntraDU(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    if (IS_MRDC_MN(ptCi))
    {
        // For Intra-MN Intra-DU with SN Change(Inter-SN)
        if (FnVCCB_IsInterSnMobilityInMn(ptCi))
        {
            status = FnVCCB_NextStep_INTRA_DU_SnQuery(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_SnQuery ERROR!\n");
            return GOOD;
        }
    }

    // For Intra-MN Intra-DU with SN Release
    // For Intra-MN Intra-DU without SN Change(Intra-SN)
    // For SA Mobility
    status = FnVCCB_NextStep_INTRA_DU_RunE1Stop_Or_RunAfterE1Stop(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTRA_DU_RunE1Stop_Or_RunAfterE1Stop ERROR!\n");

    return GOOD;
}

//        1.1.2 Inter-DU Handover         : FnVCCB_ProcSaHandover_InterDU
int16_t FnVCCB_ProcSaHandover_InterDU(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    status = FnVCCB_NextStep_INTER_DU_DuQuery(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_DU_DuQuery ERROR!\n");

    return GOOD;
}

// 1.2 MN-Inter-GNB Intra-RAT Handover : VHCM_StartSaHandover_IntergNB
/****************************************************************************
 * @brief           Start SA Inter gNB Handover (NR to NR)
 * @details         Make preparation in callInfo for SA handover
 * @param[in,out]   ptCi : call information / callInfo_type
 * @param[in]       tgtNbrGnbCell : neighbour gNbB cell/ uint16_t
 * @param[in]       cause : cause of GNB change / uint16_t
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VHCM_StartSaHandover_IntergNB(
    callInfo_type *ptCi, uint16_t nbrIdx, uint16_t cause, enumHandoverTriggerType hoTrigger, StartSaHandoverDb& hoInputDb)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = ERROR;
    nbrGnbCellInfo_type *ptNbrGnbCellInfo;

    // This operation is a class operation for controlling the Ho-related database.
    HoDbConroller hoDbConroller(ptCi);

    // get the target gnbNum
    status = getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &ptNbrGnbCellInfo);
    if (status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "VHCM_StartSaHandover_IntergNB: nbrIdx(%u) could not find Nbr information for Handover.\n", nbrIdx);
        return ERROR;
    }

    ptCi->hoInfo.tgtNbrGnbCell = nbrIdx;
    ptCi->hoInfo.tgtPlmn.longId = ptCi->hoInfo.selectedTAI.plmn.longId;
    ptCi->hoInfo.isSnInitMobilityInMn = false; // Mn Init Inter-MN Intra-NR SRC

    return VHCM_StartSaHandover_IntergNB_with_DB(ptCi, ptNbrGnbCellInfo, cause, hoTrigger, hoDbConroller, hoInputDb);
}

int16_t VHCM_StartSaHandover_IntergNB_with_DB(
    callInfo_type *ptCi, nbrGnbCellInfo_type *ptNbrGnbCellInfo, uint16_t cause, enumHandoverTriggerType hoTrigger, HoDbConroller &hoDbConroller, StartSaHandoverDb& hoInputDb)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = ERROR;
    enumNgHoSelectionCause ngHoSelectionCause = NG_HO_CAUSE_NONE; 
    
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptNbrGnbCellInfo);

#if defined(NEW_HOST_SIM) || defined(IPC_TEST)
    switch (hoTrigger)
    {
        case e_HoTrigger_ImmediateHandover:
            if (DBG->flag.forcedConditionalHandover)
            {
                hoTrigger = e_HoTrigger_ConditionalHandoverPrep;
                VCCB_PRINT_CALL_ERROR(ptCi, "Forced Conditional Handover Trigger!\n");
            }
            break;
        default:
            break;
    }
#endif

    if (0 == ptCi->numPDUSess)  // This code is a protection code. PDU Session existence must be checked before calling
                                // this function.
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "VHCM_StartSaHandover_IntergNB: Trigger Discarded because there are no PDU sessions\n");
        return GOOD;
    }

    switch (hoTrigger)
    {
        case e_HoTrigger_ImmediateHandover:
        case e_HoTrigger_ConditionalHandoverPrep:
            if (ptCi->hoInfo.selectedTAI.plmn.longId == 0 && DBG->flag.disabledCheckEmptySelectedTAI == VCCB_FLAG_OFF)
            {
                VCCB_PRINT_CALL_INFORMATIVE( ptCi, "%s hoInfo.selectedTAI.plmn.longId == 0 \n", __func__);
                return GOOD;
            }
            break;
        default:
            break;
    }

    // SVR22B FGR-CC5203
    // FR60 [Case D-1] @MN
    // When the call is in suspend state, MN VCCB shall trigger sending SN Release Request message if MN Mobility is
    // triggered.
    // Considering CHO, VCCB prevents MN Mobility from the preparation phase only (shall allow HO in Execution phase)
    if (IS_SCG_SUSPENDED(ptCi)  && DBG->flag.disabledSnReleaseWhenTriggeringHoWhileScgSuspend == VCCB_FLAG_OFF &&
        (hoTrigger == e_HoTrigger_ImmediateHandover || hoTrigger == e_HoTrigger_ConditionalHandoverPrep))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "HO Request in the SCG Suspend State! Discard HO and start SN Release procedure!\n");

        // MN-Init SN-Release
        status = VCCM_ProcSCGFailWithSnRelease(ptCi, MrdcRelCause_Handover);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_ProcSCGFailWithSnRelease ERROR!\n");

        return GOOD;
    }

    // Clear the Sn Status Flag
    FnVCCB_InitSnStatusFlag(ptCi);

    status = FnVCCB_ProcSaHandover_IntergNB_Common(ptCi, ptNbrGnbCellInfo, cause, hoTrigger, ngHoSelectionCause, hoInputDb);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_ProcSaHandover_IntergNB_Common Error!\n");

    // Check VoNR Call (23B)
    if (TRUE == FnVCCB_IsVoNRCall(ptCi))
    {
        ptCi->hoInfo.isVonrCall = TRUE;
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "callId : %d, Outgoing UE is VoNR Call.\n", ptCi->callId);
    }

    switch (hoTrigger)
    {
        default:
        case e_HoTrigger_ImmediateHandover:
            status = FnVCCB_ProcSaHandover_IntergNB_Prepare(ptCi, ngHoSelectionCause, hoInputDb);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_ProcSaHandover_IntergNB_Prepare(IM) ERROR\n");
            break;

        case e_HoTrigger_ConditionalHandoverPrep:
            status = FnVCCB_ProcSaHandover_IntergNB_Prepare(ptCi, ngHoSelectionCause, hoInputDb);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_ProcSaHandover_IntergNB_Prepare(CHO-Prep) ERROR\n");
            break;

        case e_HoTrigger_ConditionalHandoverExec:
            status = FnVCCB_ProcSaHandover_IntergNB_Execution(ptCi, hoTrigger);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_ProcSaHandover_IntergNB_Execution(CHO-Exec) ERROR\n");
            break;
    }

    // Handover Trigger Completed
    hoDbConroller.setHandoverTriggerCompleted(true);

    return GOOD;

}  // }}}

int16_t FnVCCB_ProcSaHandover_IntergNB_Common(
    callInfo_type *ptCi, nbrGnbCellInfo_type *ptNbrGnbCellInfo, uint16_t cause, enumHandoverTriggerType hoTrigger, enumNgHoSelectionCause& ngHoSelectionCause, StartSaHandoverDb& hoInputDb)
{
    AUTO_TRACE_FUNC;

    uint8_t xnLink = FALSE;
    int16_t status = ERROR;
    uint16_t hoGnbIdx = MAX_GNB_PER_CALL;  // VLIB_AllocCallGnbInfo will assign idx
    callGNBInfo_type *ptGi = NULL;

    enumHoTypeInterface eHoTypeInterface = HO_TYPE_NG;
    cgi_type targetCgi;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptNbrGnbCellInfo);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->endPointInfo.f1Idx, MAX_GNB_DU_PER_GNB_CU_CP);

    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (VLIB_CheckAllConnected(ptCi) == ERROR)
    {
        FnVCCB_ControlResponseFlagInSaHo(ptCi, __func__);
    }

    // CRR Reset
    MACRO_RESET_CALL_FAULT_CAUSES;

    memset(&targetCgi, 0x00, sizeof(targetCgi));
    targetCgi.ci = VLIB_GnbIdCellId2NrCellId(&ptNbrGnbCellInfo->globalGnbId.gnbId, ptNbrGnbCellInfo->cellId);
    targetCgi.plmn.longId = ptNbrGnbCellInfo->globalGnbId.plmn.longId;

    switch(hoTrigger)
    {
        case e_HoTrigger_ImmediateHandover:
            status = VHCM_DecisionInterGnbSaHandoverType(ptCi, &ptNbrGnbCellInfo->globalGnbId, &eHoTypeInterface, &xnLink, hoTrigger, ngHoSelectionCause);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VHCM_DecisionInterGnbSaHandoverType Error!\n");
            break;

        case e_HoTrigger_ConditionalHandoverPrep:
        {
            // Conditional Handover is only triggered by XN
            uint16_t xnIdx = fnVLIB_FindXnEndPointIndexByGnbId(ptCi->gnbNum, &ptNbrGnbCellInfo->globalGnbId);
            if (FnVCCB_CheckValidEndPointXn_ForSN(xnIdx) == false)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "(*CHO) Can not find XN index(%u) in %s.\n", xnIdx, __func__);
                return ERROR;
            }

            ptCi->endPointInfo.xnIdx = xnIdx;
            eHoTypeInterface = HO_TYPE_XN;
            xnLink = TRUE;

            ptCi->condHoInfo.currentCi = ptCi->nRCGI.ci;

            uint8_t condCellIdx =
                FnVCCB_AllocConditionalCellInfoForCGI(ptCi, targetCgi, ptNbrGnbCellInfo->ssbArfcn);
            VCCB_CHECK_E_RANGE_AND_RETURN(condCellIdx, MAX_NUM_COND_CELLS);

            conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForIndex(ptCi, condCellIdx);
            VALID_E_POINT_CHECK_ERROR(ptCondCell);

            // FGR-MC1400 FR90.CACP.SR1.HD1.VCCB.DD1 - Enhanced
            // Before changing to Handover state, try to configure Meas based on Source Cell.
            status = VCCB_PrepareNewMeasConfig(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "(*CHO) VCCB_PrepareNewMeasConfig ERROR!\n");

            auto cond1New = ptCondCell->measInfo.condEventMeasIdNew[e_CondEvent_1];
            auto cond2New = ptCondCell->measInfo.condEventMeasIdNew[e_CondEvent_2];

            VCCB_PRINT_CALL_SA_CHO(ptCi, "(*CHO) Reserved MeasId-Exec, BandNR(%u) Cond1(%s/%u), Cond2(%s/%u)\n",
                ptCondCell->measInfo.bandNr, (cond1New >= INVALID_OBJECT_ID ? "NotUsed" : "Used"),
                (cond1New >= INVALID_OBJECT_ID ? -1 : COVERT_VALUE_FROM_DB_TO_SPEC(cond1New)),
                (cond2New >= INVALID_OBJECT_ID ? "NotUsed" : "Used"),
                (cond2New >= INVALID_OBJECT_ID ? -1 : COVERT_VALUE_FROM_DB_TO_SPEC(cond2New)));

            break;
        }

        case e_HoTrigger_ConditionalHandoverExec:
        {
            // Conditional Handover is only triggered by XN
            uint16_t xnIdx = fnVLIB_FindXnEndPointIndexByGnbId(ptCi->gnbNum, &ptNbrGnbCellInfo->globalGnbId);
            if (FnVCCB_CheckValidEndPointXn_ForSN(xnIdx) == false)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "(*CHO) Can not find XN index(%u) in %s.\n", xnIdx, __func__);
                return ERROR;
            }

            ptCi->endPointInfo.xnIdx = xnIdx;
            eHoTypeInterface = HO_TYPE_XN;
            xnLink = TRUE;

            conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForCGI(ptCi, targetCgi);
            VALID_E_POINT_CHECK_ERROR(ptCondCell);

            ptCi->hoInfo.selectedTAI = ptCondCell->selectedTAI;

            break;
        }

        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid hoTrigger(%d) in %s.\n", hoTrigger, __func__);
            return ERROR;
    }

    status = VLIB_AllocCallGnbInfo(ptCi, &hoGnbIdx);
    if (GOOD != status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR in VLIB_AllocCallGnbInfo(%d, %d)\n", status, hoGnbIdx);
        return ERROR;
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(hoGnbIdx, MAX_GNB_PER_CALL);
    ptCi->hoInfo.hoGnbIdx = hoGnbIdx;

    ptGi = &ptCi->gnbInfo[hoGnbIdx];

    ptGi->globalGnbId = ptNbrGnbCellInfo->globalGnbId;
    ptGi->targetCellId = targetCgi;
    ptGi->targetPci = ptNbrGnbCellInfo->nrPci;
    ptGi->targetSsbFrequency = ptNbrGnbCellInfo->ssbArfcn;
    ptGi->targetNrArfcn = ptNbrGnbCellInfo->nrArfcnDl;  // check
    ptGi->targetExtendedTac = ptCi->hoInfo.selectedTAI.tac;

    SET_STATE_CMD(IntraRatHO_cmd);  // NR to NR HO
    ptCi->hoInfo.phyCellId = ptNbrGnbCellInfo->nrPci;
    ptCi->hoInfo.cause = cause;
    ptCi->hoInfo.hoType.rat = HO_TYPE_INTRA_RAT;
    ptCi->hoInfo.hoType.nb = HO_TYPE_INTER_NB;
    ptCi->hoInfo.hoType.du = HO_TYPE_INTER_DU;
    ptCi->hoInfo.hoType.system = HO_TYPE_INTRA_SYSTEM;
    ptCi->hoInfo.tgtSsbFreq = ptGi->targetSsbFrequency;

    ptCi->hoInfo.reportType = hoInputDb.getReportType();
    ptCi->hoInfo.reportPurpose = hoInputDb.getReportPurpose();
    ptCi->hoInfo.reportConfigQuantitySaHo = hoInputDb.getQuantity();
 
    ptCi->hoInfo.conditionalHandover = (hoTrigger == e_HoTrigger_ImmediateHandover) ? FALSE : TRUE;

    /*Set true, only when HO is triggered by LB MR */
     FnVCCB_UpdateIsLbHoFlag(ptCi, hoInputDb);
     FnVCCB_UpdateForcedMobilityHoFlag(ptCi, hoInputDb);
    // SVR22B FGR-CC5203: Deconfigure A4 for SCG resume and Update MeasConfig
    ptCi->nrdcScgFailureInfo.A4Configured = VCCB_FLAG_OFF;

    ptCi->hoInfo.isVoNRBorderMobility =
        //FnVCCB_IsVoNRBorderMR(*ptCi, hoInputDb.getReportType(), hoInputDb.getReportPurpose());
        FnVCCB_IsVoNRBorderMR(*ptCi, ptCi->saHoMrQueueInfo.reportType, ptCi->saHoMrQueueInfo.reportPurpose); // rollback to 25b

    ptCi->hoInfo.isSpecificSliceForcedMobilityTargetUe =
        FnVCCB_IsSpecificSliceForcedMR(*ptCi, hoInputDb.getReportType(), hoInputDb.getReportPurpose());

    if (eHoTypeInterface == HO_TYPE_XN)
    {
        ptCi->hoInfo.hoType.interface = HO_TYPE_XN;
        ptCi->hoInfo.hoType.initiated = HO_TYPE_SA_INTER_GNB_XN_HANDOVER;
        ptCi->cslInfo.cslRreInfo.rreCase = csl_Inter_gNB_HO_Xn;
        // SVR26A FGR-TA0601 VoMA CallEvent
        ptCi->vomaInfo.vomaEvent = VOMA_xnHo;

        // HO initialization before use
        ptCi->xnCallId = INVALID_CALL_ID;
    }
    else
    {
        ptCi->hoInfo.hoType.interface = HO_TYPE_NG;
        ptCi->hoInfo.hoType.initiated = HO_TYPE_SA_INTER_GNB_NG_HANDOVER;
        ptCi->cslInfo.cslRreInfo.rreCase = csl_Inter_gNB_HO_NG;
        // SVR26A FGR-TA0601 VoMA CallEvent
        ptCi->vomaInfo.vomaEvent = VOMA_ngHo;

        // 24A FGR-MC1009 FR30
        if ((TRUE == pGnb->cfg.intraNrSrcIndirectFwdPreference) && (e_HoTrigger_ImmediateHandover == hoTrigger))
        {
            ptCi->hoInfo.directFwdAvailable = FALSE;
        }
        else
        {
            ptCi->hoInfo.directFwdAvailable = (xnLink == TRUE) ? TRUE : FALSE;
        }
    }

    ptCi->hoInfo.isTarget = FALSE;

    ptCi->hoInfo.cgi = targetCgi;

    FnVCCB_UpdateMroHoInfoOnSourceGnb(ptCi, HO_TYPE_INTRA_RAT, HO_TYPE_INTER_NB);
    
    // Fill ptCi->hoInfo.cellIdentity
    ptCi->hoInfo.cellIdentity = VLIB_NrCellId2CellId(ptGi->globalGnbId.gnbId.idLength, ptGi->targetCellId.ci);

    // update the DB to prev DB
    FnVCCB_updateMrdcPrevInfo(ptCi);

    FnVCCB_PrintMrdcDrbInformation(ptCi);

    status = VHCM_UpdateUeHistoryInformation_Prepare(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VHCM_UpdateUeHistoryInformation_Prepare ERROR!\n");

    uint16_t xnCause{}, ngCause{};
    if (FnVCCB_GetPingPongAvoidanceCause(
            *ptCi, xnCause, ngCause, hoInputDb.getReportType(), hoInputDb.getReportPurpose()))
    {
        ptCi->cause.xnCause = xnCause;
        ptCi->cause.ngCause = ngCause;
    }
    else if (ptCi->hoInfo.isLbHo == TRUE || ptCi->hoInfo.isVoNrLbHo == TRUE)  // 21D LB_HO, 24B VoNR LB HO
    {
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerReduceLoadInServingCell;
        ptCi->cause.ngCause = CauseNgapRadioNetworkLayerReduceLoadInServingCell;
    }
    else if (FnVCCB_IsConditionalHandoverUE(ptCi) == true)
    {
        // FR420 :: gNB set Handover Request (& Last Visited NG-RAN Cell Info) cause as
        // 'Resource Optimisation handover' in CHO candidate preparation procedure
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerResourceOptimisationHandover;
        ptCi->cause.ngCause = CauseNgapRadioNetworkLayerResourceOptimisationHandover;
    }
    else
    {
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerHandoverDesirableForRadioReasons;
        ptCi->cause.ngCause = CauseNgapRadioNetworkLayerHandoverDesirableForRadioReasons;
    }

    VLIB_InitHoStat(ptCi);

    return GOOD;
}

// 1.2.1 Preparation               : FnVCCB_ProcSaHandover_IntergNB_Prepare
/****************************************************************************
 * @brief           Start SA Inter gNB Handover (NR to NR)
 * @details         Make preparation in callInfo for SA handover
 * @param[in,out]   ptCi : call information / callInfo_type
 * @param[in]       tgtNbrGnbCell : neighbour gNbB cell/ uint16_t
 * @param[in]       cause : cause of GNB change / uint16_t
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t FnVCCB_ProcSaHandover_IntergNB_Prepare(callInfo_type *ptCi, enumNgHoSelectionCause& ngHoSelectionCause, StartSaHandoverDb& hoInputDb)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;
    callGNBInfo_type *ptGi = NULL;

    const bool isChoHoUe = FnVCCB_IsConditionalHandoverUE(ptCi);
    const auto quantity = hoInputDb.getQuantity();

    // Setting ptGi
    {
        const uint16_t hoGnbIdx = ptCi->hoInfo.hoGnbIdx;

        VCCB_CHECK_E_RANGE_AND_RETURN(hoGnbIdx, MAX_GNB_PER_CALL);

        ptGi = &ptCi->gnbInfo[hoGnbIdx];
    }

    auto strQuantity = (quantity == choice_rsrp ? "P":(quantity == choice_rsrq ? "Q":(quantity == choice_sinr ? "S":"UNDEF")));

    VCCB_PRINT_CALL_INFORMATIVE(ptCi,
        "Start SA HO Inter gNB(%s): %sPci(%u), SsbFreq(%u), Q(%s), CGI(%03X-%03X-%lu), GnbId(%03X-%03X-%u), "
        "IF(%s/%d/%d)\n",
        (isChoHoUe ? "CHO-Prep" : "IM"), (TRUE == FnVCCB_IsVoNRCall(ptCi) ? "VoNR, " : ""), ptGi->targetPci,
        ptGi->targetSsbFrequency, strQuantity, ptGi->targetCellId.plmn.s2.mcc, ptGi->targetCellId.plmn.s2.mnc,
        ptGi->targetCellId.ci, ptGi->globalGnbId.plmn.s2.mcc, ptGi->globalGnbId.plmn.s2.mnc, ptGi->globalGnbId.gnbId.id,
        (ptCi->hoInfo.hoType.interface == HO_TYPE_XN ? "XN" : "NG"),
        (ptCi->hoInfo.hoType.interface == HO_TYPE_XN ? ptCi->endPointInfo.xnIdx : ptCi->endPointInfo.ngIdx),
        ngHoSelectionCause);

    FnVCCB_InitSccData(ptCi, SCC_HO_PREP_INIT);
    FnVCCB_PrintConditionalHandoverStatus(ptCi);

    if (ptCi->hoInfo.noCGConfigQuery == TRUE)  // Handover Process without MCG/SCG Query procedure.
    {
        status = FnVCCB_NextStep_INTER_Pre_CU_S(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_Pre_CU_S ERROR !!\n");
    }
    else  // Handover Process with F1 Query procedure.
    {
        status = FnVCCB_NextStep_INTER_Pre_DU_S(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_Pre_DU_S ERROR !!\n");
    }

    return GOOD;
}  // }}}

// 1.2.2 Execution                 : FnVCCB_ProcSaHandover_IntergNB_Execution
/****************************************************************************
 * @brief           Start SA Inter gNB Handover (NR to NR)
 * @details         Make preparation in callInfo for SA handover
 * @param[in,out]   ptCi : call information / callInfo_type
 * @param[in]       tgtNbrGnbCell : neighbour gNbB cell/ uint16_t
 * @param[in]       cause : cause of GNB change / uint16_t
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t FnVCCB_ProcSaHandover_IntergNB_Execution(callInfo_type *ptCi, enumHandoverTriggerType hoTrigger)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = ERROR;
    callGNBInfo_type *ptGi = NULL;
    cgi_type &cgi = ptCi->hoInfo.cgi;

    switch (hoTrigger)
    {
        case e_HoTrigger_ImmediateHandover:
            status = FnVCCB_NextStep_INTER_Exe_S(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_Exe_S(IM) ERROR !!\n");
            return GOOD;

        case e_HoTrigger_ConditionalHandoverPrep:
            VCCB_PRINT_CALL_ERROR(ptCi, "Not Support(Prep) in IntergNB_Execution\n");
            return ERROR;

        case e_HoTrigger_ConditionalHandoverExec:
            break;
        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid hoTriggerType(%d) in %s!!!\n", hoTrigger, __func__);
            return ERROR;
    }

    FnVCCB_InitCellGroupConfig(ptCi);

    // Setting ptGi
    {
        const uint16_t hoGnbIdx = ptCi->hoInfo.hoGnbIdx;

        VCCB_CHECK_E_RANGE_AND_RETURN(hoGnbIdx, MAX_GNB_PER_CALL);

        ptGi = &ptCi->gnbInfo[hoGnbIdx];
    }

    status = FnVCCB_ProcConditionalExecutionCell(ptCi, cgi);
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, status, "FnVCCB_ProcConditionalExecutionCell(%X/%lu) ERROR !!\n", cgi.plmn.longId, cgi.ci);

    status = FnVCCB_FillHandoverConfigToCondCellInfo(ptCi, cgi);
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, status, "FnVCCB_FillHandoverConfigToCondCellInfo(%X/%lu) ERROR !!\n", cgi.plmn.longId, cgi.ci);

    VCCB_PRINT_CALL_INFORMATIVE(ptCi,
        "Start SA HO Inter gNB(CHO-Exec): Pci(%u), SsbFreq(%u), CGI(%X-%lu), GnbId(%X-%u), IF(%s/%d)\n", ptGi->targetPci,
        ptGi->targetSsbFrequency, ptGi->targetCellId.plmn.longId, ptGi->targetCellId.ci, ptGi->globalGnbId.plmn.longId,
        ptGi->globalGnbId.gnbId.id, (ptCi->hoInfo.hoType.interface == HO_TYPE_XN ? "XN" : "NG"),
        (ptCi->hoInfo.hoType.interface == HO_TYPE_XN ? ptCi->endPointInfo.xnIdx : ptCi->endPointInfo.ngIdx));

    status = FnVCCB_NextStep_INTER_Exe_S(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_Exe_S(CHO) ERROR !!\n");

    return GOOD;
}  // }}}

// 1.3 MN-Inter-GNB Inter-RAT Handover : VHCM_StartSaHandover_InterRAT
/****************************************************************************
 * @brief           Start SA Inter RAT Handover (NR to LTE)
 * @details         Make preparation in callInfo for SA handover
 * @param[in,out]   ptCi : call information / callInfo_type
 * @param[in]       tgtNbrGnbCell : neighbour gNbB cell/ uint16_t
 * @param[in]       cause : cause of GNB change / uint16_t
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VHCM_StartSaHandover_InterRAT(callInfo_type *ptCi, uint16_t nbrIdx, uint16_t cause, StartSaHandoverDb& hoInputDb)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = ERROR;
    nbrEnbCellInfo_type *nbrEnbCellInfo = NULL;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // This operation is a class operation for controlling the Ho-related database.
    HoDbConroller hoDbConroller(ptCi);

    // get the target gnbNum
    status = getNbrEnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &nbrEnbCellInfo);
    if (status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "VHCM_StartSaHandover_InterRAT: nbrIdx(%u) could not find Nbr information for Handover.\n", nbrIdx);
        return ERROR;
    }

    return VHCM_StartSaHandover_InterRAT_with_DB(ptCi, nbrEnbCellInfo, cause, hoDbConroller, hoInputDb);
}  // }}}

int16_t VHCM_StartSaHandover_InterRAT_with_DB(callInfo_type *ptCi, nbrEnbCellInfo_type *nbrEnbCellInfo, uint16_t cause, HoDbConroller &hoDbConroller, StartSaHandoverDb& hoInputDb)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = ERROR;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(nbrEnbCellInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (0 == ptCi->numPDUSess)  // This code is a protection code. PDU Session existence must be checked before calling
                                // this function.
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "VHCM_StartSaHandover_InterRAT: Trigger Discarded because there are no PDU sessions\n");
        return GOOD;
    }

    if (ptCi->hoInfo.selectedTAI.plmn.longId == 0 && DBG->flag.disabledCheckEmptySelectedTAI == VCCB_FLAG_OFF)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "%s hoInfo.selectedTAI.plmn.longId == 0 \n", __func__);
        return GOOD;
    }

    if (VLIB_CheckAllConnected(ptCi) == ERROR)
    {
        FnVCCB_ControlResponseFlagInSaHo(ptCi, __func__);
    }

    // CRR Reset
    MACRO_RESET_CALL_FAULT_CAUSES;

    if (nbrEnbCellInfo->status != EQUIP)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "VHCM_StartSaHandover_InterRAT: Invalid eNB Nbr Cell Information(%d)\n", nbrEnbCellInfo->status);
        return ERROR;
    }

    const auto quantity = hoInputDb.getQuantity();

    SET_STATE_CMD(InterRatHO_cmd);  // NR to EUTRA HO
    ptCi->hoInfo.phyCellId = nbrEnbCellInfo->pci;
    ptCi->hoInfo.cause = cause;
    ptCi->hoInfo.hoType.rat = HO_TYPE_INTER_RAT;
    ptCi->hoInfo.hoType.nb = HO_TYPE_INTER_NB;
    ptCi->hoInfo.hoType.du = HO_TYPE_INTER_DU;
    ptCi->hoInfo.hoType.system = HO_TYPE_INTER_SYSTEM;
    ptCi->hoInfo.tArfcn =
        nbrEnbCellInfo->earfcnDl;  // will be used for E-UTRAN redirection with NGAP_n26_interface_not_available

    ptCi->hoInfo.hoType.interface = HO_TYPE_NG;
    ptCi->hoInfo.hoType.initiated =
        HO_TYPE_SA_INTER_SYSTEM_INTER_RAT_HANDOVER;  // TODO: how to check the inter/intra system ??

    if (pGnb->cfg.interSysDirectDataFwd)
    {
        ptCi->hoInfo.directFwdAvailable = TRUE;
    }
    else
    {
        ptCi->hoInfo.directFwdAvailable = FALSE;
    }

    ptCi->hoInfo.isTarget = FALSE;

    ptCi->hoInfo.cgi.plmn = nbrEnbCellInfo->plmn;
    ptCi->hoInfo.cgi.ci = FnVCCB_GetEcgiForNonNeighborHandover(
        *nbrEnbCellInfo, static_cast<enumSmallCellEnbIdLength_type>(pGnb->cfg.gnbMobilityConfig.smallCellEnbIdLength));
    ptCi->hoInfo.cellIdentity = nbrEnbCellInfo->cellId;
    ptCi->hoInfo.selectedTAI.tac = nbrEnbCellInfo->tac;
    ptCi->hoInfo.isSnInitMobilityInMn = false; // Mn Init Inter-MN Inter-RAT SRC

    ptCi->cslInfo.cslRreInfo.rreCase = csl_Inter_gNB_RRE_occ_IRAT_HO;

    ptCi->hoInfo.reportType = hoInputDb.getReportType();
    ptCi->hoInfo.reportPurpose = hoInputDb.getReportPurpose();
    ptCi->hoInfo.reportConfigQuantitySaHo = quantity;

    FnVCCB_UpdateMroHoInfoOnSourceGnb(ptCi, HO_TYPE_INTER_RAT, HO_TYPE_INTER_NB);
    FnVCCB_UpdateIsLbHoFlag(ptCi, hoInputDb);  // FGR-LC0711
    FnVCCB_UpdateForcedMobilityHoFlag(ptCi, hoInputDb);

    ptCi->hoInfo.serviceBorderFlag = (hoInputDb.getReportType() == measReport_B1Eutra &&
                                      hoInputDb.getReportPurpose() == b1Purpose_saToNsaBorderHandover);
    ptCi->hoInfo.specificSliceForcedMobilityFlag =
        (hoInputDb.getReportType() == measReport_B1Eutra &&
            hoInputDb.getReportPurpose() == b1Purpose_eutraForcedHandoverDueToSpecificSliceAware);

    ProcInterSystemMeasurementConfiguration procInterSysMeasConfig(ptCi); // 23A FGS-SF0510:FR50

    // Check VoNR Call (23B)
    if (TRUE == FnVCCB_IsVoNRCall(ptCi))
    {
        ptCi->hoInfo.isVonrCall = TRUE; // Triggering timing, Not finished timing
    }

    auto strQuantity = (quantity == choice_rsrp ? "P":(quantity == choice_rsrq ? "Q":(quantity == choice_sinr ? "S":"UNDEF")));

    VCCB_PRINT_CALL_INFORMATIVE(ptCi,
        "Start SA Handover Inter RAT%s: %scause(%u), tgtPci(%u), tgtArfcn(%u), Q(%s), tgtCGI(%03X-%03X-%lu), "
        "EnbId(%03X-%03X-%u), IF(%s/%d)\n",
        (TRUE == ptCi->hoInfo.nonNbrCell ? " SM Cell" : ""), (TRUE == ptCi->hoInfo.isVonrCall ? "VoNR, " : ""), cause,
        ptCi->hoInfo.phyCellId, nbrEnbCellInfo->earfcnDl, strQuantity, ptCi->hoInfo.cgi.plmn.s2.mcc,
        ptCi->hoInfo.cgi.plmn.s2.mnc, ptCi->hoInfo.cgi.ci, ptCi->hoInfo.cgi.plmn.s2.mcc, ptCi->hoInfo.cgi.plmn.s2.mnc,
        nbrEnbCellInfo->enbId, (ptCi->hoInfo.hoType.interface == HO_TYPE_XN ? "XN" : "NG"),
        (ptCi->hoInfo.hoType.interface == HO_TYPE_XN ? ptCi->endPointInfo.xnIdx : ptCi->endPointInfo.ngIdx));

    // SVR22B FGR-CC5203: Deconfigure A4 for SCG resume and Update MeasConfig
    ptCi->nrdcScgFailureInfo.A4Configured = VCCB_FLAG_OFF;

    // update the DB to prev DB
    FnVCCB_updateMrdcPrevInfo(ptCi);

    FnVCCB_PrintMrdcDrbInformation(ptCi);

    status = VHCM_UpdateUeHistoryInformation_Prepare(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VHCM_UpdateUeHistoryInformation_Prepare ERROR!\n");

    uint16_t xnCause, ngCause;
    if (FnVCCB_GetPingPongAvoidanceCause(*ptCi, xnCause, ngCause, ptCi->hoInfo.reportType, ptCi->hoInfo.reportPurpose))
    {
        ptCi->cause.ngCause = ngCause;
    }
    else
    {
        ptCi->cause.ngCause = CauseNgapRadioNetworkLayerHandoverDesirableForRadioReasons;
    }

    if (IS_FALLBACK_CASE(ptCi))
        ptCi->cause.ngCause =
            CauseNgapRadioNetworkLayerImsVoiceEpsFallbackOrRatFallbackTriggered;  // according to the FR of FGR-SV0201
                                                                                  // R2.15
    else if ((ptCi->hoInfo.isLbHo == TRUE) || (ptCi->hoInfo.isIratLbHo == TRUE))
        ptCi->cause.ngCause = CauseNgapRadioNetworkLayerReduceLoadInServingCell;

    VLIB_InitHoStat(ptCi);

    // Clear the Sn Status Flag
    FnVCCB_InitSnStatusFlag(ptCi);

    status = FnVCCB_NextStep_INTER_Pre_CU_S(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_INTER_Pre_CU_S ERROR !!\n");

    // Handover Trigger Completed
    hoDbConroller.setHandoverTriggerCompleted(true);

    return GOOD;
}  // }}}

// }}}

//  2. SN Mobility
// {{{
//     2.1 SN-Intra-GNB Handover
// {{{
//         2.1.1 MN : FnVCCB_StartSaHandover_IntraSN (Modification Required)
/****************************************************************************
 * @brief           Start SN Init SN Mobility (Intra-SN) In MN
 * @details         Make preparation in callInfo for SA handover
 * @param[in,out]   ptCi : call information / callInfo_type
 * @param[in]       tgtNbrGnbCell : neighbour gNbB cell/ uint16_t
 * @param[in]       cause : cause of GNB change / uint16_t
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t FnVCCB_StartSaHandover_IntraSN(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    if (0 == ptCi->numPDUSess)  // This code is a protection code. PDU Session existence must be checked before calling
                                // this function.
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "FnVCCB_StartSaHandover_IntraSN: Trigger Discarded because there are no PDU sessions\n");
        return GOOD;
    }

    if (VLIB_CheckAllConnected(ptCi) == ERROR)
    {
        FnVCCB_ControlResponseFlagInSaHo(ptCi, __func__);
    }

    // This operation is a class operation for controlling the Ho-related database.
    HoDbConroller hoDbConroller(ptCi);

    // SVR22B FGR-CC5203: Deconfigure A4 for SCG resume and Update MeasConfig
    ptCi->nrdcScgFailureInfo.A4Configured = VCCB_FLAG_OFF;

    // CRR Reset
    MACRO_RESET_CALL_FAULT_CAUSES;

    // Fill Cause
    ptCi->cause.xnCause = CauseXnapRadioNetworkLayerSnMobility;

    // After accepting the processing, there is a possibility to change the MN configuration, so when ToConn is called,
    // a release procedure is required.
    ptCi->hoInfo.cancelControl.needSnRelease = true;
    ptCi->hoInfo.isSnInitMobilityInMn = true; // Sn Init Intra-SN Mobility

    FnVCCB_PrintMrdcDrbInformation(ptCi);

    // Clear the Sn Status Flag
    FnVCCB_InitSnStatusFlag(ptCi);

    /* check the MN split or [TBD] SCG bearer */
    if (FnVCCB_IsAnyMnTermScgLegPerUE(ptCi, current_bearerType) == true)
    {
        status = FnVCCB_NextStep_MN_SNMob_TxStop(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_MN_SNMob_TxStop ERROR!\n");
    }
    else
    {
        status = FnVCCB_NextStep_MN_SNMob_F1Mod(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_MN_SNMob_F1Mod ERROR!\n");
    }

    // Handover Trigger Completed
    hoDbConroller.setHandoverTriggerCompleted();

    return GOOD;
}  // }}}

//         2.1.2 SN : FnVCCB_StartSaHandoverSN_IntragNB
/****************************************************************************
 * @brief           Start SN or MN Init SN Mobility (Intra-SN) In SN
 * @details         Make preparation in callInfo for SA handover
 * @param[in,out]   ptCi : call information / callInfo_type
 * @param[in]       tgtNbrGnbCell : neighbour gNbB cell/ uint16_t
 * @param[in]       cause : cause of GNB change / uint16_t
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t FnVCCB_StartSaHandoverSN_IntragNB(
    callInfo_type *ptCi, const cellSelection_type targetCellSelection, enumHoTypeInitiated initiated, uint16_t cause)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(targetCellSelection.cellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pTgtCell = &CELLINFO[targetCellSelection.cellNum];
    const VccbCellInfo_type *const pServCell = &CELLINFO[ptCi->servCellNum];
    int16_t status = ERROR;
    enumHoTypeDu eHoTypeDu = HO_TYPE_INTRA_DU;

    if (0 == ptCi->numPDUSess)  // This code is a protection code. PDU Session existence must be checked before calling
                                // this function.
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "FnVCCB_StartSaHandoverSN_IntragNB: Trigger Discarded because there are no PDU sessions\n");
        return GOOD;
    }

    if (VLIB_CheckAllConnected(ptCi) == ERROR)
    {
        FnVCCB_ControlResponseFlagInSaHo(ptCi, __func__);
    }

    switch (initiated)
    {
        case HO_TYPE_SA_MGNB_INTERMNHO:      // Inter-MN Mobility
        case HO_TYPE_SA_MGNB_INITIATED:      // Intra-MN Mobility
        case HO_TYPE_SA_SGNB_INITIATED:      // MN is Not Mobility(Idle), SN Mobility
        case HO_TYPE_SA_MN_INIT_SCG_RESUME:  // SCG Resume
            break;

        default:
            VCCB_PRINT_CALL_COMMENT(
                ptCi, "FnVCCB_StartSaHandoverSN_IntragNB: This is a Handover Trigger method that is not supported.\n");
            return GOOD;
    }

    // This operation is a class operation for controlling the Ho-related database.
    HoDbConroller hoDbConroller(ptCi);

    // TODO: NSA CODE... need to check
    if (VCCB_FLAG_ON == ptCi->finalizeInterMnHo.isFinalizeActive)
    {
        status = VHCM_ForceFinalizingSourceResurcesForInterMnHandover(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VHCM_ForceFinalizingSourceResurcesForInterMnHandover ERROR!\n");
    }

    status = VHCM_DecisionIntraGnbSaHandoverType(ptCi, targetCellSelection.cellNum, &eHoTypeDu);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VHCM_DecisionIntraGnbSaHandoverType ERROR!\n");

    SET_STATE_CMD(IntraRatHO_cmd);
    FnVCCB_SetIntraGnbCommonHoInfo(ptCi, targetCellSelection, cause, initiated, eHoTypeDu);

    // CRR Reset
    MACRO_RESET_CALL_FAULT_CAUSES;

    // Fill Cause
    if (initiated == HO_TYPE_SA_SGNB_INITIATED || initiated == HO_TYPE_SA_MN_INIT_SCG_RESUME)
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerSnMobility;
    else
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerMnMobility;

    ptCi->hoInfo.tgtSsbFreq = pTgtCell->ssbArfcn;
    ptCi->hoInfo.targetcRNTI = ptCi->ueInfo.ueId.cRNTI;
    ptCi->cslInfo.cslRreInfo.rreCase = csl_Intra_gNB_HO;

    if (initiated == HO_TYPE_SA_MN_INIT_SCG_RESUME)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi,
            "Start SCG Resume Procedure: cellNum(%u->%u), f1Idx(%u->%u), secModFlag(%u) cgi(%llu->%llu)\n",
            ptCi->servCellNum, ptCi->hoInfo.targetCellNum, ptCi->endPointInfo.f1Idx, ptCi->hoInfo.targetDu.f1Idx,
            ptCi->ueInfo.securityModFlag, 1ULL * pServCell->cgi.ci, 1ULL * pTgtCell->cgi.ci);
    }
    else
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi,
            "Start Intra-gNB SN HO (%s %s MN) : cellNum(%u->%u), f1Idx(%u->%u), secModFlag(%u) cgi(%llu->%llu)\n",
            (initiated == HO_TYPE_SA_SGNB_INITIATED ? "Sn Init" : "Mn Init"),
            (initiated == HO_TYPE_SA_MGNB_INTERMNHO ? "Inter" : "Intra"), ptCi->servCellNum, ptCi->hoInfo.targetCellNum,
            ptCi->endPointInfo.f1Idx, ptCi->hoInfo.targetDu.f1Idx, ptCi->ueInfo.securityModFlag,
            1ULL * pServCell->cgi.ci, 1ULL * pTgtCell->cgi.ci);
    }

    VCCM_SelectUlPath_NRDC(ptCi, true);

    FnVCCB_PrintMrdcDrbInformation(ptCi);

    status = VHCM_UpdateUeHistoryInformation_Prepare(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VHCM_UpdateUeHistoryInformation_Prepare ERROR!\n");

    ptCi->managementTraceInfo.isHoRrcReconfCmpleFlag = VCCB_FLAG_OFF;

    if (ptCi->servCellNum != ptCi->hoInfo.targetCellNum)
    {
        // UPM-PSCell (Mn/Sn Init Intra-SN Mobility, SCG Failure For NR-DC)
        if (VCOM_UpdateUPM_Prepare(ptCi) == ERROR)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Forced Disabled UPM (PSCell, Intra-SN) in %s!\n", __func__);
            VCOM_DisableUPM(ptCi);
        }

        // [FGR-SO1101] NR Minimization of Drive Tests (NR MDT)
        status = VLIB_stopManagementMdtTrace(ptCi, ptCi->servCellNum);
        VCCB_PRINT_WITHOUT_RETURN_ON_CALL_ERROR(ptCi, status, "[MDT] VLIB_stopManagementMdtTrace cellNum(%i) error.\n",
                ptCi->servCellNum);
        status = VLIB_stopManagementUeThrRfTrace(ptCi, ptCi->servCellNum);
        VCCB_PRINT_WITHOUT_RETURN_ON_CALL_ERROR(ptCi, status, "[UETHR] VLIB_stopManagementUeThrRfTrace cellNum(%i) error.\n",
            ptCi->servCellNum);
        
        traceMdtStatus_type sessionToDeactivate = {
            .immediate = (mdtImmediate == ptCi->signalingTraceInfo.mdt.mdtStatus),
            .logged = (mdtLogged == ptCi->signalingTraceInfo.mdt.mdtStatus),
            .uethr = (VCCB_FLAG_ON == ptCi->signalingTraceInfo.trace.ueThroughputAndRfTraceFlag),
            .trace = false
        };
        deactivateSigMdtTrace(ptCi, sessionToDeactivate, false);

        VLIB_startManagementMdtTrace(ptCi, ptCi->hoInfo.targetCellNum);
        VLIB_startManagementUeThrRfTrace(ptCi, ptCi->hoInfo.targetCellNum);
    }
    else
    {
        // UPM-PSCell (Mn/Sn Init Intra-SN Mobility, SCG Failure For NR-DC)
        VCCB_PRINT_CALL_LOG_UPM(ptCi, "[UPM] Detect Same Cell Handover Case. this case use current configuration\n");
    }

    // Update Req Bearer Type
    FnVCCB_ReUpdateBearerType(ptCi);

    // Clear the Sn Status Flag
    FnVCCB_InitSnStatusFlag(ptCi);

    // TODO: remove this algorithm if procedures is working.. (Add the on/off flag to check it)
    if (DBG->flag.mrdcHO_useSnModificationProcedure_duringMcgOnlyMobility == FALSE)
    {
        if (targetCellSelection.cellNum == ptCi->servCellNum)
        {
            if (FnVCCB_CheckIfIntraCellHOIsAllowedForPSCellChange(ptCi, initiated) == true)
            {
                // no action - Continue with the procedure below.
            }
            else
            {
                // In the case of IntraCell HO, the CG-ConfigInfo delivery procedure is omitted.
                // If this flag is not OFF, CG-ConfigInfo is included in SN_XXX_DU_Complete.
                OFF_CGCFINFO_NEED_FWD_FLAG(ptCi->flag.setupFlag);

                // send the Xn S-NODE Modification Request Ack
                status = FnVCCB_NextStep_SN_INTRA_DU_Execution_By_MnSnMobility(ptCi);
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_SN_INTRA_DU_Execution_By_MnSnMobility ERROR!\n");

                // Handover Trigger Completed
                hoDbConroller.setHandoverTriggerCompleted();

                return GOOD;
            }
        }
    }

    if (IS_NRDC_HO_SCG_RESUME(ptCi))
    {
        // FGR-CC5203 FR52: 
        //   If VCCB receives Handover Cancel during the SCG Resume process,
        //   it shall not start SCG-TX Resume and shall start release SN.
        SET_NEED_CALL_RELEASE_WO_HO_CANCEL(ptCi);
    }

    // Processing
    switch (eHoTypeDu)
    {
        case HO_TYPE_INTRA_DU:
            status = FnVCCB_ProcSaHandoverSN_IntraDU(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_ProcSaHandoverSN_IntraDU ERROR!\n");

            // Handover Trigger Completed
            hoDbConroller.setHandoverTriggerCompleted();
            break;

        // case HO_TYPE_INTER_DU:
        default:
            if (initiated == HO_TYPE_SA_MN_INIT_SCG_RESUME)
            {
                // error print: SCG resume is only allowed to intra-DU, intra-SN pscell change...
                break;
            }
            status = FnVCCB_ProcSaHandoverSN_InterDU(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_ProcSaHandoverSN_InterDU ERROR!\n");

            // Handover Trigger Completed
            hoDbConroller.setHandoverTriggerCompleted();
            break;
    }

    return GOOD;
}  // }}}

//              2.1.2.1 Intra-DU Handover : FnVCCB_ProcSaHandoverSN_IntraDU
/****************************************************************************
 * @brief           Start SN or MN Init SN Mobility (Intra-SN) In SN - Inter-DU Case
 * @details         Make preparation in callInfo for SA handover
 ****************************************************************************/
int16_t FnVCCB_ProcSaHandoverSN_IntraDU(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    if (FnVCCB_IsAnySnTermPerUE(ptCi, current_bearerType) == true)
    {
        status = FnVCCB_NextStep_SN_INTRA_DU_E1Stop(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_SN_INTRA_DU_E1Stop ERROR!\n");
    }
    else
    {
        status = FnVCCB_NextStep_SN_INTRA_DU_Prepare(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_SN_INTRA_DU_Prepare ERROR!\n");
    }

    return GOOD;
}  // }}}

//              2.1.2.2 Inter-DU Handover : FnVCCB_ProcSaHandoverSN_InterDU
/****************************************************************************
 * @brief           Start SN or MN Init SN Mobility (Intra-SN) In SN - Inter-DU Case
 * @details         Make preparation in callInfo for SA handover
 ****************************************************************************/
int16_t FnVCCB_ProcSaHandoverSN_InterDU(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    status = FnVCCB_NextStep_SN_INTER_DU_DuQuery(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_SN_INTER_DU_DuQuery ERROR!\n");

    return GOOD;
}  // }}}

// }}}
//     2.2 SN-Inter-GNB Handover :
// {{{
//         2.2.1 MN : FnVCCB_StartSaHandover_InterSN
/****************************************************************************
 * @brief           Start SN Init SN Mobility (Inter-SN) In MN
 * @details         Make preparation in callInfo for SA handover
 * @param[in,out]   ptCi : call information / callInfo_type
 * @param[in]       tgtNbrGnbCell : neighbour gNbB cell/ uint16_t
 * @param[in]       cause : cause of GNB change / uint16_t
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t FnVCCB_StartSaHandover_InterSN(callInfo_type *ptCi, uint16_t cause)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = ERROR;
    uint16_t hoGnbIdx = MAX_GNB_PER_CALL;  // VLIB_AllocCallGnbInfo will assign idx
    uint16_t xnIdx = MAX_XN_NBR_PER_GNB;
    callGNBInfo_type *ptGi = NULL;
    xnNbrInfo_type *pXnNbr = NULL;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    // find the xnIndex from target node Id
    // change the state ti send below message
    // send the XN SNode Additional Request

    if (0 == ptCi->numPDUSess)  // This code is a protection code. PDU Session existence must be checked before calling
                                // this function.
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "FnVCCB_StartSaHandover_InterSN: Trigger Discarded because there are no PDU sessions\n");
        return GOOD;
    }

    if (VLIB_CheckAllConnected(ptCi) == ERROR)
    {
        FnVCCB_ControlResponseFlagInSaHo(ptCi, __func__);
    }

    // This operation is a class operation for controlling the Ho-related database.
    HoDbConroller hoDbConroller(ptCi);

    // CRR Reset
    MACRO_RESET_CALL_FAULT_CAUSES;

    xnIdx = ptCi->mrdcInfo.SNInfo[TGT_SN].epIdx;

    pXnNbr = FnVCCB_GetXnNbrInfo(ptCi->gnbNum, xnIdx);
    if (pXnNbr == NULL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid xnEndPoint : Ignore Case (gnbNum:%u, epIdx:%u)\n", ptCi->gnbNum, xnIdx);
        return ERROR;
    }

    status = VLIB_AllocCallGnbInfo(ptCi, &hoGnbIdx);
    if (GOOD != status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR in VLIB_AllocCallGnbInfo(%d, %d)\n", status, hoGnbIdx);
        return ERROR;
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(hoGnbIdx, MAX_GNB_PER_CALL);

    ptGi = &ptCi->gnbInfo[hoGnbIdx];

    ptGi->globalGnbId.plmn.longId = pXnNbr->plmn.longId;
    ptGi->globalGnbId.gnbId = pXnNbr->gnbId;

    SET_STATE_CMD(IntraRatHO_cmd);  // NR to NR HO

    FnVCCB_SetIntraGnbCommonHoInfo(
        ptCi, {ptCi->servCellNum, ptCi->servCellBand}, cause, HO_TYPE_SA_SGNB_INITIATED_INTER_SN_CHANGE, HO_TYPE_INTRA_DU);

    // Overwrite after 'FnVCCB_SetIntraGnbCommonHoInfo'
    ptCi->hoInfo.hoType.nb = HO_TYPE_INTER_NB;
    ptCi->hoInfo.hoGnbIdx = hoGnbIdx;
    ptCi->hoInfo.sgnbAddTrigInd = SgnbAddTrigInd_SnChange;  // SA, NR/NEDC-MN
    ptCi->hoInfo.cgi = ptCi->nRCGI;                         // not move pcell
    ptCi->hoInfo.isSnInitMobilityInMn = true; // Sn Init Inter-SN Mobility

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Start SA HO Inter SN: cause(%u), GnbId(%03X-%03X-%u), IF(XN/%d)\n", cause,
        ptGi->globalGnbId.plmn.s2.mcc, ptGi->globalGnbId.plmn.s2.mnc, ptGi->globalGnbId.gnbId.id, xnIdx);

    FnVCCB_PrintMrdcDrbInformation(ptCi);

    // SVR22B FGR-CC5203: Deconfigure A4 for SCG resume and Update MeasConfig
    ptCi->nrdcScgFailureInfo.A4Configured = VCCB_FLAG_OFF;

    ptCi->cause.xnCause = CauseXnapRadioNetworkLayerSnMobility;

    VLIB_InitHoStat(ptCi);

    FnVCCB_MrdcMobilityProc_InterSN(ptCi);

    if (FnVCCB_ValidateGFBRComparedToUeSliceMBR(*ptCi) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Sum of GFBR values exceed UE-Slice-MBR! ERROR!\n");
        ptCi->cause.ngCause = CauseNgapRadioNetworkLayerRadioResourcesNotAvailable;
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerNoRadioResourcesAvailable;

        status = FnVCCB_SendXNMessage(XN_SNodeChangeRefuse_id, ptCi, nullptr, nullptr);
        if (status == ERROR)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "XN_SNodeChangeRefuse Send Fail, StartInerSN!!\n");
        }

        status = VCCB_CALL_RELEASE_TRIGGER(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_CALL_RELEASE_TRIGGER Error!\n");

        return GOOD;
    }

    // Clear the Sn Status Flag
    FnVCCB_InitSnStatusFlag(ptCi);

    status = FnVCCB_NextStep_MN_INTER_SN_Pre_SN(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_MN_INTER_SN_Pre_SN ERROR !!\n");

    // Handover Trigger Completed
    hoDbConroller.setHandoverTriggerCompleted();

    return GOOD;
}  // }}}

bool FnVCCB_checkSelectedTargetSNInMN(callInfo_type *ptCi, uint16_t xnIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    xnNbrInfo_type *pXnNbr = NULL;
    pXnNbr = FnVCCB_GetXnNbrInfo(ptCi->gnbNum, xnIdx);
    if (pXnNbr == NULL)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Not Allowed : Not Found Xn Nbr In Yang (gnbNum:%u, epIdx:%u)\n", ptCi->gnbNum, xnIdx);
        return false;
    }

    if(pXnNbr->ngRanNodeType == ngRanNode_ngEnbType)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Not Allowed : Not GNB, maybe ENB(xnIdx:%d, Type:%u)\n", xnIdx, pXnNbr->ngRanNodeType);
        return false;
    }
    
    // NRDC_MN
    {
        vccbGlobalGnbId_type targetGnb;

        targetGnb.gnbId = pXnNbr->gnbId;
        targetGnb.plmn.longId = pXnNbr->plmn.longId;

        // 1) SVR23A FGR-CC5203 SCG Failure Handling for NR-DC :: FR130 :: Blocklisted S-Node
        // 2) SVR23B FGR-CC5200 Basic Operation For NR-DC :: FR143 :: Restricted gNB by overload
        // 3) SVR23B FGR-CC5200 Basic operation for NR-DC :: FR840 :: gNB shall block NR-DC with other vendor's gNB
        if (FnVCCB_IsValidNrdcSnPerGnb_ForMN(ptCi, targetGnb, xnIdx) == false)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed : IsValidNrdcSnPerGnb (xnIdx:%d, %X, %u)\n", xnIdx,
                targetGnb.plmn.longId, targetGnb.gnbId.id);
            return false;
        }
    }

    return true;
}

//         2.2.2 SN : FnVCCB_StartSaHandoverSN_IntergNB
/****************************************************************************
 * @brief           Start SN or MN Init SN Mobility (Inter-SN) In SN
 * @details         Make preparation in callInfo for SA handover
 * @param[in,out]   ptCi : call information / callInfo_type
 * @param[in]       tgtNbrGnbCell : neighbour gNbB cell/ uint16_t
 * @param[in]       cause : cause of GNB change / uint16_t
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t FnVCCB_StartSaHandoverSN_IntergNB(callInfo_type *ptCi, uint16_t tgtNbrGnbCell, uint16_t cause)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int status;
    uint16_t hoGnbIdx = MAX_GNB_PER_CALL;  // VLIB_AllocCallGnbInfo will assign idx

    callGNBInfo_type *ptGi = NULL;
    nbrGnbCellInfo_type *nbrGnbCellInfo = NULL;
    if (0 == ptCi->numPDUSess)  // This code is a protection code. PDU Session existence must be checked before calling
                                // this function.
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "FnVCCB_StartSaHandoverSN_IntergNB: Trigger Discarded because there are no PDU sessions\n");
        return GOOD;
    }

    if (VLIB_CheckAllConnected(ptCi) == ERROR)
    {
        FnVCCB_ControlResponseFlagInSaHo(ptCi, __func__);
    }

    // This operation is a class operation for controlling the Ho-related database.
    HoDbConroller hoDbConroller(ptCi);

    // TODO : SNode Change, It describes the case that it needs to be moved to another SNode, and it is a scenario that
    // is excluded from 21C IODT.
    // get code from VHCM_StartSgNBChange
    //
    status = getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, tgtNbrGnbCell, &nbrGnbCellInfo);
    if (status == ERROR)
    {
        return BREAK;
    }

    if (GOOD != VCCM_CheckAgainstRefusedTargetGnb(ptCi, nbrGnbCellInfo))
    {
        return BREAK;
    }

    status = VLIB_AllocCallGnbInfo(ptCi, &hoGnbIdx);
    if ((GOOD != status) || (MAX_GNB_PER_CALL <= hoGnbIdx))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "ERROR in VLIB_AllocCallGnbInfo\n");

        return BREAK;
    }

    ptGi = &ptCi->gnbInfo[hoGnbIdx];

    ptGi->globalGnbId = nbrGnbCellInfo->globalGnbId;
    ptGi->targetCellId.ci = VLIB_GnbIdCellId2NrCellId(&nbrGnbCellInfo->globalGnbId.gnbId, nbrGnbCellInfo->cellId);
    ptGi->targetCellId.plmn = nbrGnbCellInfo->globalGnbId.plmn;
    ptGi->targetPci = nbrGnbCellInfo->nrPci;
    ptGi->targetSsbFrequency = nbrGnbCellInfo->ssbArfcn;
    ptGi->targetExtendedTac = nbrGnbCellInfo->fiveGsTac;

    VCCB_PRINT_CALL_INFORMATIVE(ptCi,
        "Start SgNB change: cause(%u), tgtPci(%u), tgtSsbFreq(%u), tgtCGI(%03X-%03X-%lu), GlobalGnbId(%03X-%03X-%u)\n",
        cause, ptGi->targetPci, ptGi->targetSsbFrequency, ptGi->targetCellId.plmn.s2.mcc, ptGi->targetCellId.plmn.s2.mnc,
        ptGi->targetCellId.ci, ptGi->globalGnbId.plmn.s2.mcc, ptGi->globalGnbId.plmn.s2.mnc,
        ptGi->globalGnbId.gnbId.id);

    FnVCCB_PrintMrdcDrbInformation(ptCi);

    SET_STATE_CMD(IntraRatHO_cmd);
    ptCi->hoInfo.cause = cause;
    ptCi->hoInfo.hoType.rat = HO_TYPE_INTRA_RAT;
    ptCi->hoInfo.hoType.nb = HO_TYPE_INTER_NB;
    ptCi->hoInfo.hoType.initiated = HO_TYPE_SA_SGNB_INITIATED_INTER_SN_CHANGE;  // SN Side
    ptCi->hoInfo.isTarget = FALSE;
    ptCi->hoInfo.hoGnbIdx = hoGnbIdx;
    ptCi->hoInfo.tgtNbrGnbCell = tgtNbrGnbCell;

    // Fill ptCi->hoInfo.cellIdentity
    ptCi->hoInfo.cgi.plmn = ptGi->targetCellId.plmn;
    ptCi->hoInfo.cgi.ci = ptGi->targetCellId.ci;
    ptCi->hoInfo.cellIdentity = VLIB_NrCellId2CellId(ptGi->globalGnbId.gnbId.idLength, ptGi->targetCellId.ci);

    // CRR Reset
    MACRO_RESET_CALL_FAULT_CAUSES;

    // Fill Cause
    ptCi->cause.xnCause = CauseXnapRadioNetworkLayerSnMobility;

    // Clear the Sn Status Flag
    FnVCCB_InitSnStatusFlag(ptCi);

    status = FnVCCB_NextStep_SN_INTER_SN_DUQuery(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_NextStep_SN_INTER_SN_DUQuery ERROR!\n");

    // Handover Trigger Completed
    hoDbConroller.setHandoverTriggerCompleted();

    return GOOD;
}  // }}}

// }}}
// }}}

// }}}
/****************************************************************************
                        Handover
****************************************************************************/
// {{{

bool FnVCCB_IsInterSnMobilityInMn(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);  // Case 0. Null Pointer

    if (!VHCM_isSaHandoverUE(ptCi)) return false;  // Case 0. Not HO UE.

    if (!IsAvailable_MrdcInfo()) return false;  // Case 1. Not MR-DC UE.

    if (!IS_MRDC_MN(ptCi)) return false;  // Case 2. MN Only

    if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue) return false;  // Case 3. It is SN Release Case.

    if (FnVCCB_CheckValidEndPointXn_ForSN(ptCi->mrdcInfo.SNInfo[SRC_SN].epIdx) == false)
    {
        if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTER_NB && ptCi->hoInfo.isTarget == TRUE)
        {
            if (ptCi->mrdcInfo.SNInfo[SRC_SN].epIdx == XNIDX_FOR_UNKNOWN_SN)
            {
                // Source SN is not known, but with SN Change should be possible.
                return true;
            }
        }

        return false; // Case 4. Not Found Source SNode.
    }

    if (FnVCCB_CheckValidEndPointXn_ForSN(ptCi->mrdcInfo.SNInfo[TGT_SN].epIdx) == false)
        return false;  // Case 5. Not Found Target SNode.

    if (ptCi->mrdcInfo.SNInfo[SRC_SN].epIdx == ptCi->mrdcInfo.SNInfo[TGT_SN].epIdx)
        return false;  // Case 6. It is Intra-SN Mobility Case.

    return true;
}

bool FnVCCB_IsIntraSnMobilityInMn(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);  // Case 0. Null Pointer

    if (!VHCM_isSaHandoverUE(ptCi)) return false;  // Case 0. Not HO UE.

    if (!IsAvailable_MrdcInfo()) return false;  // Case 1. Not MR-DC UE.

    if (!IS_MRDC_MN(ptCi)) return false;  // Case 2. MN Only

    if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue) return false;  // Case 3. It is SN Release Case.

    if (FnVCCB_CheckValidEndPointXn_ForSN(ptCi->mrdcInfo.SNInfo[SRC_SN].epIdx) == false) return false;  // Case 4. Not Found Source SNode.

    if (FnVCCB_CheckValidEndPointXn_ForSN(ptCi->mrdcInfo.SNInfo[TGT_SN].epIdx) == false)
        return false;  // Case 5. Not Found Target SNode.

    if (ptCi->mrdcInfo.SNInfo[SRC_SN].epIdx != ptCi->mrdcInfo.SNInfo[TGT_SN].epIdx)
        return false;  // Case 6. It is Inter-SN Mobility Case.

    return true;
}

VCCB_STATIC int16_t FnVCCB_ConvertRlcModeFromSpecToInternal(const uint8_t specValue, uint8_t *pInternalValue)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(pInternalValue);

    // Convert Spec Value to Internal Value
    //  SPEC     : 1: AM, 2: UM_Bi, 3: UM_Uni_UL, 4: UM_Uni_DL in NR-RRC.
    //  Internal : 0: AM, 1: UM_Bi, 2: UM_Uni_DL, 3: UM_Uni_UL in enumRlcMode_type.

    switch (specValue)
    {
        case NRRRC_am_chosen:  // 1->0
            *pInternalValue = AM_RLC;
            break;

        case NRRRC_um_Bi_Directional_chosen:  // 2->1
            *pInternalValue = UM_BI_RLC;
            break;

        case NRRRC_um_Uni_Directional_UL_chosen:  // 3->3
            *pInternalValue = UM_UNI_UL_RLC;
            break;

        case NRRRC_um_Uni_Directional_DL_chosen:  // 4->2
            *pInternalValue = UM_UNI_DL_RLC;
            break;

        default:
            VCCB_PRINT_ERROR("Invalid SpecValue(spec:%d, internal:%d)!\n", (int)specValue, (int)*pInternalValue);
            return ERROR;
    }

    return GOOD;
}

VCCB_STATIC void FnVCCB_UpdateRlcMode(callInfo_type *ptCi, CellGroupConfig_Full_type *p)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    rlcBearerConfig_Full_type *pRbCfg = NULL;

    uint8_t rbMap[MAX_NRRRC_DRBID_3GPP + 1] = {0};  // 0: Not Valid
    const uint8_t sizeOfMap = sizeof(rbMap) / sizeof(rbMap[0]);

    for (uint32_t lcId = 0; lcId < MAX_NUM_LC_ID; lcId++)
    {
        if (p->rlcBearerList.useFlag[lcId] != VCCB_FLAG_ON) continue;

        pRbCfg = &p->rlcBearerList.rlcBearerConfig[lcId];

        // Check DRB Identity (servedRadioBearer.rbIdentity)
        if (pRbCfg->servedRadioBearer_Flag != VCCB_FLAG_ON) continue;
        if (pRbCfg->servedRadioBearer.type != NRRRC_drb_Identity_chosen) continue;
        if (pRbCfg->servedRadioBearer.rbIdentity >= sizeOfMap) continue;

        // Check RLC Config (pRbCfg->rlcConfig, AM,UM,...)
        if (pRbCfg->rlcConfig_Flag != VCCB_FLAG_ON) continue;

        rbMap[pRbCfg->servedRadioBearer.rbIdentity] =
            pRbCfg->rlcConfig.type;  // 0: Not Valid, 1: AM, 2: UM_Bi, 3: UM_Uni_UL, 4: UM_Uni_DL
    }

    callDRBInfo_type *ptDi = NULL;
    uint8_t rlcMode = 0;

    for (uint32_t drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        ptDi = &ptCi->drb[drbIdx];

        if (ptDi->usage != CI_use) continue;

        // Check Range
        if (ptDi->dRBId >= sizeOfMap) continue;

        // Check Valid Data
        // * Not Valid                          0
        // * NRRRC_am_chosen                    1
        // * NRRRC_um_Bi_Directional_chosen     2
        // * NRRRC_um_Uni_Directional_UL_chosen 3
        // * NRRRC_um_Uni_Directional_DL_chosen 4
        // * ...
        if (rbMap[ptDi->dRBId] == 0) continue;

        // Convert Rlc Mode Value From Spec Enum To Internal Enum.
        if (FnVCCB_ConvertRlcModeFromSpecToInternal(rbMap[ptDi->dRBId], &rlcMode) == ERROR) continue;

        // Skip if same value
        if (ptDi->rbInfo.rlcModePresent == OPT_PRESENT) continue;

        VCCB_PRINT_CALL_COMMENT(
            ptCi, "+ DRB Mode Setup (Index:%d, From %d To %d)\n", ptDi->dRBId, ptDi->rbInfo.rlcMode, rlcMode);

        ptDi->rbInfo.rlcModePresent = OPT_PRESENT;
        ptDi->rbInfo.rlcMode = rlcMode;

        // update the bearer Type (split bearer is already updated)
        if (ptDi->bearerType.val == MN_Term_Undetermined)
        {
            if (p->cellGroupId == CellGroupId_MCG)
            {
                ptDi->bearerType.val = MN_Term_MCG_Bearer;
            }
            else
            {
                // TODO :: not support it... (SN release is required?)
                ptDi->bearerType.val = MN_Term_SCG_Bearer;
            }
        }
        else if (ptDi->bearerType.val == SN_Term_Undetermined)
        {
            // TODO :: not support it... (SN release is required?)
            if (p->cellGroupId == CellGroupId_SCG)
            {
                ptDi->bearerType.val = SN_Term_SCG_Bearer;
            }
            else
            {
                ptDi->bearerType.val = SN_Term_MCG_Bearer;
            }
        }
    }
}  // }}}

int16_t VCOM_ProcHandoverPreparationInformationForInterNode(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    // O - Acquire the RLC MODE of MCG.
    FnVCCB_UpdateRlcMode(ptCi, &ptCi->cellGroupConfig_Full);

    // O - Acquire the RLC MODE of SCG.
    if (IsAvailable_MrdcInfo())  // Silent Ignore
    {
        mrdcInfo_type *pMrdcInfo = &ptCi->mrdcInfo;

        if (VLIB_CheckValid_MrdcScgCellGrpConfig(pMrdcInfo) == TRUE)
        {
            NRRRC_RRCReconfiguration *ptMsg = NULL;
            NRRRC_RRCReconfiguration_IEs *ptIE = NULL;
            
            auto &rRrcReconf = pMrdcInfo->scgCellGrpConfig;
            ptMsg = FnVCCB_UnpackAndGetRRCReconfigurationPDU(ptCi, rRrcReconf.value, (unsigned int)rRrcReconf.length, CellGroupId_SCG);
            VALID_E_POINT_CHECK_ERROR(ptMsg);

            ptIE = &ptMsg->criticalExtensions.u.rrcReconfiguration;
            if (ptIE->bit_mask & NRRRC_secondaryCellGroup_present)
            {
                CellGroupConfig_Full_type scgCellGroup;

                status = VRIL_storeNRRRC_CellGroupConfig_Full(
                    ptCi, ptIE->secondaryCellGroup.decoded, VCCB_FLAG_ON, &scgCellGroup);
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VRIL_storeNRRRC_CellGroupConfig_Full(SCG CellGroup) ERROR!\n");

                FnVCCB_UpdateRlcMode(ptCi, &scgCellGroup);
            }
        }
    }

    // update the undetermined bearerType (MCG cell group config is mandatory)
    callDRBInfo_type *ptDi;
    for (uint32_t drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        ptDi = &ptCi->drb[drbIdx];

        if (ptDi->usage != CI_use) continue;

        switch (ptDi->bearerType.val)
        {
            case MN_Term_Undetermined:
                if (IsAvailable_MrdcInfo())
                {
                    ptDi->bearerType.val = MN_Term_SCG_Bearer;
                }
                else
                {
                    // If it is not in a DC state, it is determined as MN Term MCG.
                    ptDi->bearerType.val = MN_Term_MCG_Bearer;
                }
                break;
            case SN_Term_Undetermined:
                ptDi->bearerType.val = SN_Term_SCG_Bearer;
                break;
            default:
                break;
        }
    }

    FnVCCB_Check_DRB_RlcMode_For_FullConfig(ptCi);

    return GOOD;
}  // }}}

void FnVCCB_CheckStatForHO_NrdcSn(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // Check - Intra RAT
    if (ptCi->hoInfo.hoType.rat != HO_TYPE_INTRA_RAT) return;
    if (!IS_NRDC_SN(ptCi)) return;

    int arrCheckFamily[] = {STAT_NRDC_PSCELL_CHANGE_IN, STAT_NRDC_PSCELL_CHANGE_OUT};

    for (uint16_t idx = 0; idx < GET_ARR_SIZE(arrCheckFamily); idx++)
    {
        int key = GET_FAMIDX(arrCheckFamily[idx]);

        VCCB_CHECK_RANGE_MIN_MAX_AND_CONTINUE(key, 0, MAX_VCCB_FAMILY_TYPE - 1);

        // Check - Attempt and prepSuccess
        switch (GET_CALL_STAT_FLAG(ptCi, key))
        {
            case ATTEMPT_MADE:
            case PREP_SUCCESS_MADE:
                VCCB_MRDC_SN_HO_STAT(ptCi, NRDC_SN_HOFail_CpFail);
                break;
            default:
                break;
        }
    }
}  // }}}

void FnVCCB_CheckStat_NrdcSnAddition(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    int arrCheckFamily[] = {STAT_NRDC_SN_ADD_MN, STAT_NRDC_SN_ADD_SN_WITH_INVALID_CELL};

    for (uint16_t idx = 0; idx < GET_ARR_SIZE(arrCheckFamily); idx++)
    {
        int key = GET_FAMIDX(arrCheckFamily[idx]);

        VCCB_CHECK_RANGE_MIN_MAX_AND_CONTINUE(key, 0, MAX_VCCB_FAMILY_TYPE - 1);

        // Check - Attempt and prepSuccess
        switch (GET_CALL_STAT_FLAG(ptCi, key))
        {
            case ATTEMPT_MADE:
            case PREP_SUCCESS_MADE:
                VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_CpFail);
                break;
            default:
                break;
        }
    }
}  // }}}

void VHCM_CheckStatForIntraNrHO(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // This Family have to exist in arrCheckFamily of VLIB_InitHoStat
    int arrCheckFamily[] = {STAT_HO_OUT, STAT_HO_IN, STAT_HO_INTER_FREQ_OUT, STAT_HO_INTRA_FREQ_OUT,
        STAT_HO_INTER_FREQ_OUT_REDCAP, STAT_HO_INTRA_FREQ_OUT_REDCAP, STAT_HO_IN_REDCAP, STAT_HO_OUT_SERVICE_TYPE,
        STAT_HO_IN_SERVICE_TYPE, STAT_HO_INTER_FREQ_OUT_SERVICE_TYPE, STAT_HO_INTRA_FREQ_OUT_SERVICE_TYPE};

    for (uint16_t idx = 0; idx < GET_ARR_SIZE(arrCheckFamily); idx++)
    {
        int key = GET_FAMIDX(arrCheckFamily[idx]);

        VCCB_CHECK_RANGE_MIN_MAX_AND_CONTINUE(key, 0, MAX_VCCB_FAMILY_TYPE - 1);

        // Check - Attempt and prepSuccess
        switch (GET_CALL_STAT_FLAG(ptCi, key))
        {
            case ATTEMPT_MADE:
            case PREP_SUCCESS_MADE:
                VHCM_SA_HO_STAT(ptCi, HO_Fail_CpFail);
                break;
            default:
                break;
        }
    }

}  // }}}

void VHCM_CheckStatForInterRatHO(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // Check - Inter RAT
    if (ptCi->hoInfo.hoType.rat != HO_TYPE_INTER_RAT) return;

    // This Family have to exist in arrCheckFamily of VLIB_InitHoStat
    int arrCheckFamily[] = {STAT_HO_EUTRAN_OUT, STAT_HO_EUTRAN_OUT_FALLBACK, STAT_HO_EUTRAN_IN, STAT_HO_EUTRAN_FREQ_OUT,
        STAT_HO_EUTRAN_FREQ_OUT_REDCAP, STAT_HO_EUTRAN_IN_REDCAP, STAT_HO_EUTRAN_OUT_SERVICE_TYPE,
        STAT_HO_EUTRAN_OUT_FALLBACK_SERVICE_TYPE, STAT_HO_EUTRAN_IN_SERVICE_TYPE,
        STAT_HO_EUTRAN_FREQ_OUT_SERVICE_TYPE};  

    for (uint16_t idx = 0; idx < GET_ARR_SIZE(arrCheckFamily); idx++)
    {
        int key = GET_FAMIDX(arrCheckFamily[idx]);

        VCCB_CHECK_RANGE_MIN_MAX_AND_CONTINUE(key, 0, MAX_VCCB_FAMILY_TYPE - 1);

        // Check - Attempt and prepSuccess
        switch (GET_CALL_STAT_FLAG(ptCi, key))
        {
            case ATTEMPT_MADE:
            case PREP_SUCCESS_MADE:
                VHCM_SA_HO_STAT(ptCi, HO_Fail_CpFail);
                break;
            default:
                break;
        }
    }
}  // }}}

void VHCM_CheckStatForChoNrHO(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // This Family have to exist in arrCheckFamily of VLIB_InitHoStat
    int arrCheckFamily[] = {STAT_CHO_IN, STAT_CHO_OUT};

    for (uint16_t idx = 0; idx < GET_ARR_SIZE(arrCheckFamily); idx++)
    {
        int key = GET_FAMIDX(arrCheckFamily[idx]);

        VCCB_CHECK_RANGE_MIN_MAX_AND_CONTINUE(key, 0, MAX_VCCB_FAMILY_TYPE - 1);

        // Check - Attempt and prepSuccess
        switch (GET_CALL_STAT_FLAG(ptCi, key))
        {
            case ATTEMPT_MADE:
            case PREP_SUCCESS_MADE:
                if (ptCi->hoInfo.handoverExecutionFlag == FALSE)
                    CHO_STAT(ptCi, CHO_PrepFail_gNBFail, ptCi->hoInfo.cgi);
                else
                    CHO_STAT(ptCi, CHO_ExeFail_gNBFail, ptCi->hoInfo.cgi);
                break;
            default:
                break;
        }
    }

}  // }}}

void VHCM_ReleaseGnbNodeForInterGnbHO(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->hoInfo.hoGnbIdx >= MAX_GNB_PER_CALL) return;

    // Release GNB-NODE
    if (IS_VALID_NODE(GNB_NODE, ptCi, &(ptCi->gnbInfo[ptCi->hoInfo.hoGnbIdx])))
    {
        if (VLIB_FreeCallGnbInfo(ptCi, ptCi->hoInfo.hoGnbIdx) == ERROR)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_FreeCallGnbInfo ERROR!\n");
        }
    }

    ptCi->hoInfo.hoGnbIdx = MAX_GNB_PER_CALL;
}  // }}}

void VHCM_checkNStartForcedHOTimer(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    // check the forced ho timer is needed
    if (FnVCCB_GetSaMeas(*ptCi).forcedHoState == FORCED_HO_ACTIVE)
    {
        // Forced ho restriction operation was performed in the previous cell.
        if (ptCi->forcedHO.timer.id > 0)
        {
            VCCB_CLEAR_TIMER(&ptCi->forcedHO.timer, CANCEL_TIMER);
        }

        if (ptCi->forcedHO.timer.id <= 0)
        {
            // start forced ho restriction timer
            VLIB_AttachTimer(&ptCi->forcedHO.timer, ptCi, timInternalForcedHoRestriction_id);
            // save forcedHO cellNum when HO Restriction Timer attach
            ptCi->forcedHO.cellNum = ptCi->servCellNum;
        }
    }
}

void FnVCCB_MrdcSnMobility_Finalize(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // All Timer Cancel
    VCCB_DetachHoTimer(&ptCi->hoInfo);

    // Change the RB status to Idle.
    VLIB_setBearerStatusToIdle(ptCi);

    // Change the RB status to Idle.
    VLIB_InitHoInfo(ptCi);

    // Change Conn(DB) State
    SET_STATE_CMD(Idle_cmd);
    VLIB_SetCurStateAll(ptCi, STATE_Conn);

    // Trigger Location Report for Inta SN Mobility
    int16_t status = VCCM_HandleLocationReportForMRDC(ptCi);
    if (status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_HandleLocationReportForMRDC ERROR in %s\n", __FUNCTION__);
    }
 

}

void FnVCCB_CopyFromTgtInfoToSrcInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    mrdcInfo_type *pMrdc = &ptCi->mrdcInfo;

    SNInfo_type *pSrcInfo = &pMrdc->SNInfo[SRC_SN];
    SNInfo_type *pTgtInfo = &pMrdc->SNInfo[TGT_SN];

    // Update Neighbour and EndPointIndex
    FnVCCB_SetSnInfo_NbrIdxAndXnEndPoint(ptCi, pTgtInfo->nbrIdx, pTgtInfo->epIdx, pSrcInfo);

    // Update CallId
    if (pTgtInfo->m.ueXnAPID == OPT_PRESENT)
    {
        pSrcInfo->m.ueXnAPID = OPT_PRESENT;
        pSrcInfo->ueXnAPID = pTgtInfo->ueXnAPID;
    }

    // Update Location Information at S-NODE
    if (pTgtInfo->selectedPsCell.locationInfo.present == VCCB_FLAG_ON)
    {
        memcpy(&pSrcInfo->selectedPsCell, &pTgtInfo->selectedPsCell, sizeof(pSCellInfo_type));
    }
}

/**
 * @brief Copy the MN info from TGT_MN to SRC_MN and reset the TGT_MN MN info
 * 
 * @param ptCi: Pointer to call information
 */
VCCB_STATIC_INLINE
void FnVCCB_CopyMnInfoFromTgtToSrc(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    // Check input parameters
    VALID_E_POINT_CHECK_VOID(ptCi);

    // Check MRDC(NRDC/ENDC)-SN UE
    if (!IS_MRDC_SN(ptCi)) return;

    // Get a pointer to the last visited PSCell list database
    VccbLastVisitedPSCellHandling_type *ptScgUHI = FnVCCB_GetLastVisitedPSCellListDB(ptCi);

    // Check if the pointer to the last visited PSCell list database is valid
    if (ptScgUHI == NULL)
    {
        // Log the error and return
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetLastVisitedPSCellListDB Error in %s\n", __func__);
        return;
    }

    if (DBG->flag.logScgUeHistory == VCCB_FLAG_ON)
    {
        FnVCCB_UeHistoryHandlingPrint(ptCi, "MN DB Change (PSCellChangeHistory : %d->%d)\n",
            ptScgUHI->u.sn.mnInfo[SRC_MN].isPSCellChangeHistoryIE_Received,
            ptScgUHI->u.sn.mnInfo[TGT_MN].isPSCellChangeHistoryIE_Received);
    }

    // Copy the MN info from TGT_MN to SRC_MN
    ptScgUHI->u.sn.mnInfo[SRC_MN] = ptScgUHI->u.sn.mnInfo[TGT_MN];

    // Reset the TGT_MN MN info
    memset(&ptScgUHI->u.sn.mnInfo[TGT_MN], 0x00, sizeof(ptScgUHI->u.sn.mnInfo[TGT_MN]));
}

bool FnVCCB_IsNeedSNRleaseProcedureAfterMrdcMobilityCompletion(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (!IS_MRDC_MN(ptCi)) return false;

    if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue) return false;

    if (ptCi->hoInfo.MN_SnReleaseAfterHandover == TRUE)
    {
        ptCi->hoInfo.MN_SnReleaseAfterHandover = FALSE;

        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "SN Release by MN_SnReleaseAfterHandover\n");
        return true;
    }

    if (DBG->flag.snNGuTnlUpdate == VCCB_FLAG_OFF)  // Default is VCCB_FLAG_ON
    {
        for (uint16_t pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
        {
            callPDUSessInfo_type *ptPi = &ptCi->pduSess[pduIdx];

            if (ptPi->usage == CI_no_use) continue;

            if (ptPi->snNGuUlInfo.fNeedModify == VCCB_FLAG_ON)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "PDU#%u, snNGuUlInfo Update...\n", ptPi->pduSessId);
                return true;
            }
        }
    }

    return false;
}

void FnVCCB_SNReleaseProcedureAfterMrdcMobilityCompletion(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!IS_MRDC_MN(ptCi)) return;

    if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue) return;

    // QUEUE SN RELEASE
    if (ERROR == VLIB_EnqueueXnReleaseSNode(ptCi, MrdcRelCause_Handover))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_EnqueueXnReleaseSNode ERROR !!\n");

        if (VCCB_CALL_RELEASE_TRIGGER(ptCi) != GOOD)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_CALL_RELEASE_TRIGGER ERROR!\n");
        }
    }
}

void FnVCCB_SNModiProcedureAfterMrdcMobilityCompletion(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (!IS_MRDC_MN(ptCi)) return;

    if (ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue) return;

    // if true, SnNGuTNLUpdate will be processed in the pdu release procedure
    if (VHCM_CheckPduSessionReleaseInfo(ptCi, e_ReleaseTriggerForFindAllCause) == TRUE) return;

    if (DBG->flag.snNGuTnlUpdate == VCCB_FLAG_ON)  // Default is VCCB_FLAG_ON
    {
        if (FnVCCB_NeedNGuTnlTobeModified(ptCi, NGU_TNL_TYPE_SNUL) == true)
        {
            // QUEUE SN MODI
            if (ERROR == FnVCCB_EnqueueSnNGuTNLUpdate(ptCi))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_EnqueueXnSNodeModificationReq ERROR !!\n");

                FnVCCB_SNReleaseProcedureAfterMrdcMobilityCompletion(ptCi);
            }
        }
    }
}

/****************************************************************
 * Function     : VCOM_SaHandover_Finalize
 * Description  : This function is called when the handover is completed and the UE maintains the Conn state.
 * Scenario  :
 *    1) Intra-gNB Handover Completed successfully.
 *    2) Inter-gNB Target-gNB Handover Completed successfully.
 *       - In the case of Source-gNB, the UE does not maintain the Conn state,
 *         so it is not the scope of this function.
 *
 * ***************************************************************/
void VCOM_SaHandover_Finalize(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // All Timer Cancel
    VCCB_DetachHoTimer(&ptCi->hoInfo);

    // Change the RB status to Idle.
    VLIB_setBearerStatusToIdle(ptCi);

    // SVR24B FGR-MC1007 FR391
    FnVCCB_InitTimerBasedMrBasedRedirectionInfo(*ptCi);

    // FGR-MC1007 SVR24B FR381, SVR25A FR382
    FnVCCB_InitServiceBorderMobilityInfo(*ptCi);

    FnVCCB_InitSpecificSliceForcedMobilityInfo(*ptCi);

    // Conditional Handover - Execution Cell Release
    {
        int16_t status = GOOD;

        // When Handover is completed by Conditional Handover, Release Execution Cell
        if (FnVCCB_IsConditionalHandoverUE(ptCi))
        {
            FnVCCB_FreeConditionalCellInfoForCGI(ptCi, ptCi->hoInfo.cgi);
        }

        // Not RRC Reconfiguration - UE performs release procedure
        status = FnVCCB_ApplyConditionalCellConfig(ptCi, e_HandoverComplete);
        if (status == ERROR)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_ApplyConditionalCellConfig ERROR!\n");
        }

        FnVCCB_InitCHOBlockList(ptCi);

        FnVCCB_InitCondHoInfo(ptCi);
    }

    // In the case of Inter-GNB HO, it releases resources for GNB Node.
    VHCM_ReleaseGnbNodeForInterGnbHO(ptCi);

    // Confirm UPM information. First Release 20A
    VCOM_UpdateUPM_Finalize(ptCi);

    // For MR-DC
    if (IsAvailable_MrdcInfo())
    {
        // Update the Bearer status for MR-DC
        VLIB_FinalizeBearerTypeForMrDc(ptCi);

        mrdcInfo_type *pMrdc = &ptCi->mrdcInfo;

        // Buffer Free
        VLIB_FreeBuffAllMrdcInfo(ptCi, PL_COMMENT);

        // FGR-CC5201 FR661, FR662
        FnVCCB_NrdcSnConnInfoStatsCmd(ptCi, ptCi->servCellNum, ConnInfoStatsCmd_Decrease);

        if (pMrdc->mobilityCfg.ueState == ci_scg_released_ue)
        {
            // FGR-CC5201 FR661, FR662 Stop HoldingTime
            FnVCCB_NrdcSnConnInfoStatsCmd(ptCi, ptCi->servCellNum, ConnInfoStatsCmd_HoldingTimeStop);
            // If there is MRDC information, delete it.
            VLIB_InitMrdcProperty(ptCi);
        }
        else if (IS_MRDC_MN(ptCi))
        {
            SNInfo_type *pSrcInfo = &pMrdc->SNInfo[SRC_SN];
            SNInfo_type *pTgtInfo = &pMrdc->SNInfo[TGT_SN];

            if (IS_ON_MRDC_RSC_SETUP_FLAG(xn_tgtSnConn))
            {
#ifdef IPC_TEST
                if (IS_ON_MRDC_RSC_SETUP_FLAG(xn_snConn))
                {
                    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[IPC_TEST:BUG] need to release the src SN\n");
                }
#endif

                OFF_MRDC_RSC_SETUP_FLAG(xn_tgtSnConn);
                ON_MRDC_RSC_SETUP_FLAG(xn_snConn);
            }

            // Update From Target SN Information To Source SN Information.
            FnVCCB_CopyFromTgtInfoToSrcInfo(ptCi);

            // Since MRDC information is no longer used, it is initialized.
            FnVCCB_InitMrdcSnInfo(pTgtInfo);

            // Activate the SN status of SRC_SN. (For Inter-gNB)
            pSrcInfo->state = SN_STATE_ACTIVE;

            // It is set that the SCG of the terminal is set. (For Inter-gNB)
            ON_MRDC_RSC_SETUP_FLAG(uu_scgSetup);

            FnVCCB_UpdateNrdcMnCsl(*ptCi, NRDC_CSL_UPDATE_ADD_HO); //SVR26A:FGR-CC5200:FR1080,FR1081
        }
        else if (IS_NRDC_SN(ptCi))
        {
            if (ptCi->stateCmd == IntraRatHO_cmd && ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_MGNB_INTERMNHO)
            {
                // Update From Target MN Information To Source MN Information.
                FnVCCB_CopyMnInfoFromTgtToSrc(ptCi);
            }
            
            FnVCCB_UpdateNrdcSnCsl(*ptCi); //SVR26A:FGR-CC5200:FR1080,FR1081
        }
    }

    // Enqueue to trigger UCE(caution: this need to be placed after VLIB_InitMrdcProperty)
    FnVCCB_Finalize_UeCapaEnquiryIfNeeded_ForSA(ptCi, ptCi->servCellNum, VCCB_FLAG_ON);

    if (!IsAvailable_MrdcInfo())
    {
        FnVCCB_ReinstallMrdcBaseInfoAfterMobility(
            ptCi, ptCi->servCellNum, ptCi->servCellBand, 0xff & ~MRDCCTRL_RECFG_MEASCFG);
        if ((IS_SELECTED_MRDC(MRDC_NRDC)) && (MAX_NBR_PER_CELL > ptCi->pccData.pscellNbrIdx))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC NRDC] PSCell addition will be initiated after handover\n");
            SET_PCC_STATE(ptCi, PCC_NrDcSNAddition);
        }
    }

    if (FnVCCB_IsNeedSNRleaseProcedureAfterMrdcMobilityCompletion(ptCi) == true)
    {
        FnVCCB_SNReleaseProcedureAfterMrdcMobilityCompletion(ptCi);
    }
    else
    {
        FnVCCB_SNModiProcedureAfterMrdcMobilityCompletion(ptCi);
    }

    if (ptCi->hoInfo.isLtmCellSwitch != TRUE)
    {
        FnVCCB_ClearLtmUeInfo(ptCi);
    }

    // Describes items that require initialization.
    VLIB_InitHoInfo(ptCi);
    VLIB_InitHoStat(ptCi);

    FnVCCB_InitOnDemandHoInfo(ptCi); 
    
    FnVCCB_USTM_Cancel(*ptCi);

    // CRR, If CRR exists, Change Normal
    MACRO_RESET_CALL_FAULT_CAUSES;

    // Clear Handover Flag
    OFF_MGNB_CONNECTION_TGT_FLAG(ptCi->flag.setupFlag);

    if (!IS_NRDC_SN(ptCi))
    {
        // Initialize xnIdx used in HO
        ptCi->endPointInfo.xnIdx = MAX_XN_NBR_PER_GNB;

        // Initialize XnCallId used in HO
        ptCi->xnCallId = INVALID_CALL_ID;
    }

    ptCi->saLbHoExecuted = FALSE; // FGR-LC0703 (FR33)
    VCCB_PRINT_LOG_SA_LB(ptCi, "[SALB] Load balancing is prepared (by HANDOVER)\n");

    IRAT_LB_INIT_MEAS_STATE(ptCi); // FGR-LC0711
    VCCB_PRINT_LOG_IRAT_LB(ptCi, "[IRATLB] Load balancing is prepared (by HANDOVER)\n");

    MACRO_CHECK_AND_DETACH(ptCi->voNrLbMrWaitTimer); // FGR-LC0712

    VHCM_checkNStartForcedHOTimer(ptCi);

    if (ptCi->extDb.m.isUseAllocDB == FALSE)
    {
        FnVCCB_insertAllocCallDbForRRE(ptCi);
    }

    // SVR23B SCC Change 
    if (ptCi->sccData.totalMaxBw != UNKNOWN_BANDWIDTH)
    {
        if ((ptCi->servCellNum != ptCi->sccData.calculatedCellNum) || 
            (ptCi->servCellBand != ptCi->sccData.calculatedBandNr) )
        {            
            FnVCCB_InitSccBwData(ptCi);
        }
    }

    // Change Conn(DB) State
    SET_STATE_CMD(Idle_cmd);
    VLIB_SetCurStateAll(ptCi, STATE_Conn);
    VCCB_PRINT_CALL_COMMENT(ptCi,
        "IS_SUPPORT_UE_CAPA_INFO FOO.VF_NrRachParaOpt: %d, CallType: %d, ueCapa IS_NRDC_SN: %d DC: %d\n",
        FOO.VF_NrRachParaOpt, ptCi->callType, ptCi->ueInfo.ueCapa.nr.rachReportR16, IS_NRDC_SN(ptCi));
    // need to check that the following routine is only called in case that attachment, HO incoming, RRE and Resume are
    // completed
    if (IS_SUPPORT_UE_CAPA_INFO(ptCi) && (IS_NRDC_SN(ptCi) == FALSE))  // 21D: NR RACH Optimization
    {
        if (ERROR == VCOM_SendNRRRC_UEInformationRequest(ptCi))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_SendNRRRC_UEInformationRequest ERROR !!\n");
            return;
        }
    }

    // TODO:bchanee dead code? need to check
    if (GET_REPORT_CGI_DUPL_PCI(ptCi) == VCCB_FLAG_ON)
    {
        FnVCCB_DeactivateReportCgi(ptCi);
    }

}  // }}}

/****************************************************************
 * Function     : VCOM_SaHandoverCancel_ToConn
 * Description  : This function is used as a wrapper when it is changed to ToConn.
 * ***************************************************************/
int16_t VCOM_SaHandoverCancel_ToConn(callInfo_type *ptCi, uint16_t msgId)
{
    AUTO_TRACE_FUNC;

    if (FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(ptCi) == true)
    {
        int16_t status = FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo ERROR !!\n");
        return GOOD;
    }

    VCOM_SaHandoverCancel_ToConn_Core(ptCi, msgId);
    return GOOD;
}

void FnVCCB_ControlResponseFlagInSaHo(callInfo_type *ptCi, const char *ptFuncName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptFuncName);

    if (VLIB_CheckAllConnected(ptCi) == GOOD) return;

    if (ptCi->callType == E_CALLTYPE_NSA) return;

    VCCB_PRINT_CALL_ERROR(ptCi, "%s: [Warning] There is an waiting response message before Handover. (D:%hu)\n",
        ptFuncName, (uint8_t)DBG->flag.saHO_AlwaysRespFlagClearForStartHO);

    // Debug Print
    FnVCCB_PrintAllResponseFlag(ptCi, __func__, YES);

    // Forced Clear
    if (DBG->flag.saHO_AlwaysRespFlagClearForStartHO)
    {
        VLIB_ClearAllRespFlags(ptCi);
    }
}

int16_t FnVCCB_SaIntraDuHandover_Send_RRCReconfiguration(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int16_t status;

    /* full config - SA Intra-gNB Inter/Intra-DU Handover */
    VCCM_InitInstalledMeasConfig_ByFullConfiguration(ptCi);

    status = FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer(ptCi, FALSE, FALSE, ID_SRB1);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer ERROR !!\n");
    if (status == BREAK)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer BREAK!\n");
    }

    if (FnVCCB_IsImmediateHandoverUE(*ptCi))
    {
        FnVCCB_CancelRreWaitOperation(*ptCi, VCCB_FLAG_ON);
    }

    return status;
}  // }}}

int16_t FnVCCB_SaInterDuHandover_Send_RRCReconfiguration(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int16_t status;

    /* full config - SA Intra-gNB Inter/Intra-DU Handover */
    VCCM_InitInstalledMeasConfig_ByFullConfiguration(ptCi);

    status = FnVCCB_SendNRRRC_RRCReconfiguration_F1ModiReq(ptCi, FALSE, FALSE, &ptCi->hoInfo.timer.f1);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendNRRRC_RRCReconfiguration_F1ModiReq ERROR !!\n");
    if (status == BREAK)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SendNRRRC_RRCReconfiguration_F1ModiReq BREAK!\n");
    }

    if (FnVCCB_IsImmediateHandoverUE(*ptCi))
    {
        FnVCCB_CancelRreWaitOperation(*ptCi, VCCB_FLAG_ON);
    }

    return status;
}  // }}}

int16_t VCOM_SaIntraDuHandover_ToExecution(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int16_t status;

    status = FnVCCB_SaIntraDuHandover_Send_RRCReconfiguration(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, status, "FnVCCB_SaIntraDuHandover_Send_RRCReconfiguration ERROR !!\n");

    if (IsAvailable_MrdcInfo() && ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
    {
        OFF_MRDC_RSC_SETUP_FLAG(uu_scgSetup);
    }

    OFF_RRC_CONNECTION_FLAG(ptCi->flag.setupFlag);

    VLIB_AttachTimer(&ptCi->hoInfo.timer.spec, ptCi, timInternalIntraGnbHandoverComplete_id);

    VLIB_SAHandoverTime(ptCi, CAL_START);

    return GOOD;
}  // }}}

int16_t VCOM_SaInterDuHandover_ToExecution(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int16_t status;

    status = FnVCCB_SaInterDuHandover_Send_RRCReconfiguration(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, status, "FnVCCB_SaInterDuHandover_Send_RRCReconfiguration ERROR !!\n");

    if (IsAvailable_MrdcInfo() && ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
    {
        OFF_MRDC_RSC_SETUP_FLAG(uu_scgSetup);
    }

    OFF_RRC_CONNECTION_FLAG(ptCi->flag.setupFlag);

    VLIB_AttachTimer(&ptCi->hoInfo.timer.spec, ptCi, timInternalIntraGnbHandoverComplete_id);

    VLIB_SAHandoverTime(ptCi, CAL_START);

    return GOOD;
}  // }}}

int16_t FnVCCB_ProcULNasMsgDequeueForSaMobility(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // If the NAS does not exist, this function is terminated.
    if (!GET_NAS_STORED_FLAG(ptCi->flag.setupFlag)) return GOOD;

    OFF_NAS_STORED_FLAG(ptCi->flag.setupFlag);

    auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_UplinkNASTransportAllAmf_id);
    VALID_E_POINT_CHECK_ERROR(ngapSender);
    if (ngapSender->sendMsg() == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "sendMsg(NG_UplinkNASTransportAllAmf) ERROR!\n");
        return ERROR;
    }

    return GOOD;
}

int16_t FnVCCB_IsULNasMsgEnqueueRequiredForSaMobility(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    enumHoTypeInterface interfaceType = HO_TYPE_XN;

    // This function checks only when handover and rre is in progress. (FALSE Return)
    if (VHCM_isSaHandoverUE(ptCi) == TRUE)
    {
        // This function handles only INTER-GNB. (FALSE Return)
        if (ptCi->hoInfo.hoType.nb != HO_TYPE_INTER_NB)
        {
            return FALSE;
        }

        // This function is handled only by TargetGNB. (FALSE Return)
        if (ptCi->hoInfo.isTarget != TRUE)
        {
            return FALSE;
        }

        interfaceType = static_cast<enumHoTypeInterface>(ptCi->hoInfo.hoType.interface);  // XN or NG
    }
    else if (RrcReestablish_cmd == ptCi->stateCmd)
    {
        // In the RRE procedure,
        //     1) only NGC Link is checked.
        //     2) Always Use Xn Interface
    }
    else if ((RRCSuspend_cmd == ptCi->stateCmd) || (RRCResume_cmd == ptCi->stateCmd))
    {
        // RRC Resume
    }
    else
    {
        return FALSE;
    }

    // This function works only in certain situations. (TRUE Return)
    switch (interfaceType)
    {
        // In the case of NG Handover, queuing is required for the next section.
        // NG Handover :: Handover Request ~ Handover Notify
        case HO_TYPE_NG:
            // This flag is cleared when Ng Handover Notify is transmitted.
            if (ptCi->hoInfo.interGnbTgtConnectionFlag == TRUE)
            {
                return TRUE;
            }
            break;

        // In the case of XN Handover, queuing is required for the next section.
        // XN Handover :: Handover Request ~ PathSwitchRequest Acknoledge
        // RRE : Inter-GNB RRE(XN RTRV), Intra-gNB(Not Exist NG Link)
        // case HO_TYPE_XN:
        default:
            // This flag is turned on in PathSwithReq. (PathSwitchRequest ~)
            if (GET_NGC_CONNECTION_FLAG(ptCi->flag.setupFlag))
            {
                // PathSwitchRequest ~ PathSwitchRequestAcknoledge
                if (GET_NGC_CONNECTION_FLAG(
                        ptCi->flag.respFlag))  // This flag is turned off when a PathSwitchReqAck is received.
                {
                    return TRUE;
                }
            }
            // HandoverRequest ~ PathSwitchRequest
            else
            {
                return TRUE;
            }
            break;
    }

    return FALSE;
}  // }}}

/*********************** Inter-PLMN Mobility Control ***********************/
// {{{

void VCOM_InitSelectedTAI(selectedTAI_Type *p)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(p);

    p->plmn.longId = 0;
    p->tac = 0;

}  // }}}

int16_t VCOM_SetSelectedTAI(
    selectedTAI_Type *ptSelectedTai, candidateNbrInformation_type *ptCandidateNbrInfo, uint32_t allow_idx)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptSelectedTai);
    VALID_E_POINT_CHECK_ERROR(ptCandidateNbrInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(allow_idx, MAX_NUM_PLMN);
    VCCB_CHECK_E_RANGE_AND_RETURN(allow_idx, ptCandidateNbrInfo->nbrTaiInfo.plmnList.num_plmn);

    ptSelectedTai->plmn.longId = ptCandidateNbrInfo->nbrTaiInfo.plmnList.plmn[allow_idx].longId;
    ptSelectedTai->tac = ptCandidateNbrInfo->nbrTaiInfo.tac;

    return GOOD;
}  // }}}

int16_t VCOM_Decision_SelectedTAI_ByLastEutranPLMN(
    callInfo_type *ptCi, candidateNbrInformation_type *ptCandidateNbrInfo, selectedTAI_Type *ptSelectedTai)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(ptCandidateNbrInfo);
    VALID_E_POINT_CHECK_FALSE(ptSelectedTai);

    allowedPlmnList_Type *ptAllowList = &ptCandidateNbrInfo->nbrTaiInfo.plmnList;
    hoRestrictInfoCompressed_type *ptHrl = &ptCi->hoRestrict;
    int16_t status = GOOD;

    if (ptHrl->existFlag == FALSE) return FALSE;

    if (ptHrl->lastEutraPlmnPresent == OPT_NOT_PRESENT) return FALSE;

    // If LastEutraPlmn exists in AllowList, it is selected first.
    for (uint32_t allow_plmn_idx = 0; allow_plmn_idx < MIN((uint32_t)ptAllowList->num_plmn, MAX_NUM_PLMN);
         allow_plmn_idx++)
    {
        if (VCOM_CheckPlmnIdentical(&ptHrl->lastEutraPlmn, &ptAllowList->plmn[allow_plmn_idx]) == TRUE)
        {
            status = VCOM_SetSelectedTAI(ptSelectedTai, ptCandidateNbrInfo, allow_plmn_idx);
            if (status == ERROR)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_SetSelectedTAI Error!\n");
                return FALSE;
            }

            return TRUE;  // select the PLMN
        }
    }

    return FALSE;
}  // }}}

int16_t VCOM_Decision_SelectedTAI_ByServedPLMN(
    callInfo_type *ptCi, candidateNbrInformation_type *ptCandidateNbrInfo, selectedTAI_Type *ptSelectedTai)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(ptCandidateNbrInfo);
    VALID_E_POINT_CHECK_FALSE(ptSelectedTai);

    allowedPlmnList_Type *ptAllowList = &ptCandidateNbrInfo->nbrTaiInfo.plmnList;
    int16_t status = GOOD;

    // If the serving PLMN exists in the recommeded PLMN list, select the serving PLMN
    for (uint32_t allow_plmn_idx = 0; allow_plmn_idx < MIN((uint32_t)ptAllowList->num_plmn, MAX_NUM_PLMN);
         allow_plmn_idx++)
    {
        if (VCOM_CheckPlmnIdentical(&ptCi->ueInfo.servedPlmn, &ptAllowList->plmn[allow_plmn_idx]) == TRUE)
        {
            status = VCOM_SetSelectedTAI(ptSelectedTai, ptCandidateNbrInfo, allow_plmn_idx);
            if (status == ERROR)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_SetSelectedTAI Error!\n");
                return FALSE;
            }
            return TRUE;  // select the PLMN
        }
    }

    return FALSE;
}  // }}}

int16_t VCOM_Decision_SelectedTAI_ByServingAMF_ForIntraGnbNbr(callInfo_type *ptCi,
    candidateNbrInformation_type *ptCandidateNbrInfo, supportedAmfSetList_Type *ptServingAmfList,
    selectedTAI_Type *ptSelectedTai)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(ptCandidateNbrInfo);
    VALID_E_POINT_CHECK_FALSE(ptServingAmfList);
    VALID_E_POINT_CHECK_FALSE(ptSelectedTai);

    allowedPlmnList_Type *ptAllowList = &ptCandidateNbrInfo->nbrTaiInfo.plmnList;

    for (unsigned int allow_plmn_idx = 0; allow_plmn_idx < MIN(ptAllowList->num_plmn, MAX_NUM_PLMN); allow_plmn_idx++)
    {
        // Compare the PLMN List supported by the Serving AMF to the Allowed PLMN List.
        for (unsigned int amf_plmn_idx = 0;
             amf_plmn_idx < MIN(ptServingAmfList->num_plmn, MAX_AMF_PLMN_PER_SUPPORTED_LIST);
             amf_plmn_idx++)  // supported by Serving AMF
        {
            if (VCOM_CheckPlmnIdentical(
                    &ptAllowList->plmn[allow_plmn_idx], &ptServingAmfList->amf_plmn[amf_plmn_idx].plmn) == FALSE)
                continue;

            // select the lowest index PLMN
            ptSelectedTai->plmn = ptAllowList->plmn[allow_plmn_idx];
            return TRUE;
        }
    }

    return FALSE;
}  // }}}

int16_t VCOM_Decision_SelectedTAI_ByServingAMF_ForInterGnbNbr(callInfo_type *ptCi,
    candidateNbrInformation_type *ptCandidateNbrInfo, supportedAmfSetList_Type *ptServingAmfList,
    selectedTAI_Type *ptSelectedTai)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(ptCandidateNbrInfo);
    VALID_E_POINT_CHECK_FALSE(ptServingAmfList);
    VALID_E_POINT_CHECK_FALSE(ptSelectedTai);

    allowedPlmnList_Type *ptAllowList = &ptCandidateNbrInfo->nbrTaiInfo.plmnList;
    int16_t status = GOOD;

    // Search NbrCell In EndPointXn
    VCCB_CHECK_E_RANGE_AND_FALSE(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_FALSE(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    uint16_t xnIdx =
        fnVLIB_FindXnEndPointIndexByGnbId(ptCi->gnbNum, &ptCandidateNbrInfo->globalGnbId);
    if (xnIdx >= MAX_XN_NBR_PER_GNB)
    {
        VCCB_PRINT_CALL_LOG_PLMN(ptCi, "Cannot find XnEndPointIndexByGnbId!\n");

        return FALSE;
    }

    // In case of Inter gNB Neighbour, get the PLMN list which is AMF Region information at target gNB and supported by
    // the Serving AMF, select the lowest index PLMN (first detect index)
    for (uint32_t allow_plmn_idx = 0; allow_plmn_idx < MIN((uint32_t)ptAllowList->num_plmn, MAX_NUM_PLMN);
         allow_plmn_idx++)
    {
        // Compare the PLMN List supported by the Serving AMF SET to the Allowed PLMN List.
        for (uint32_t amf_set_idx = 0;
             amf_set_idx < MIN((uint32_t)ptServingAmfList->num_set, MAX_AMF_SET_PER_SUPPORTED_LIST);
             amf_set_idx++)  // AMF Region information at target gNB(SET)
        {
            if (VCOM_CheckPlmnIdentical(
                    &ptAllowList->plmn[allow_plmn_idx], &ptServingAmfList->amf_set_info[amf_set_idx].plmn) == FALSE)
                continue;

            // Compare the PLMN List and AMF REGION supported by the Serving AMF SET to the Allowed PLMN List.
            for (uint32_t amf_idx = 0; amf_idx < MAX_AMF_SET_INFO;
                 amf_idx++)  // AMF Region information at target gNB(SET + REGION)
            {
                amfSetInformation_type *pAmf = &pGnb->xnNbr[xnIdx].extension.amfSetInfo[amf_idx];

                if (pAmf->status == N_EQUIP) continue;
                if (pAmf->present.amfPlmnMcc == OPT_NOT_PRESENT) continue;
                if (pAmf->present.amfPlmnMnc == OPT_NOT_PRESENT) continue;
                if (pAmf->present.amfRegionId == OPT_NOT_PRESENT) continue;

                if (VCOM_CheckPlmnIdentical(&ptServingAmfList->amf_set_info[amf_set_idx].plmn, &pAmf->amfPlmn) == FALSE)
                    continue;

                if (ptServingAmfList->amf_set_info[amf_set_idx].region !=
                    pAmf->amfRegionId)  // Satisfies XN HO minimum conditions
                    continue;

                // select the lowest index PLMN
                status = VCOM_SetSelectedTAI(ptSelectedTai, ptCandidateNbrInfo, allow_plmn_idx);
                if (status == ERROR)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_SetSelectedTAI Error!\n");
                    return FALSE;
                }
                VCCB_PRINT_CALL_LOG_PLMN(ptCi, "Selected PLMN : AMF Region information and supported by the Serving AMF "
                        "(num_plmn:%d, selectedPLMN:%02X/%02X).\n",
                        ptAllowList->num_plmn, ptSelectedTai->plmn.s2.mcc, ptSelectedTai->plmn.s2.mnc);

                return TRUE;
            }
        }
    }

    // In case of Inter gNB Neighbour, get the PLMN list which is AMF Region information at target gNB, select the
    // lowest index PLMN
    for (uint32_t allow_plmn_idx = 0; allow_plmn_idx < MIN((uint32_t)ptAllowList->num_plmn, MAX_NUM_PLMN);
         allow_plmn_idx++)
    {
        // Compare the PLMN List supported by the Serving AMF SET to the Allowed PLMN List.
        for (uint32_t amf_idx = 0; amf_idx < MAX_AMF_SET_INFO;
             amf_idx++)  // AMF Region information at target gNB(Only PLMN)
        {
            amfSetInformation_type *pAmf = &pGnb->xnNbr[xnIdx].extension.amfSetInfo[amf_idx];

            if (pAmf->status == N_EQUIP) continue;
            if (pAmf->present.amfPlmnMcc == OPT_NOT_PRESENT) continue;
            if (pAmf->present.amfPlmnMnc == OPT_NOT_PRESENT) continue;

            if (VCOM_CheckPlmnIdentical(&ptAllowList->plmn[allow_plmn_idx], &pAmf->amfPlmn) == FALSE) continue;

            // select the lowest index PLMN
            status = VCOM_SetSelectedTAI(ptSelectedTai, ptCandidateNbrInfo, allow_plmn_idx);
            if (status == ERROR)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_SetSelectedTAI Error!\n");
                return FALSE;
            }

            VCCB_PRINT_CALL_LOG_PLMN(ptCi, "Selected PLMN : AMF Region information and supported by the Serving AMF "
                    "(num_plmn:%d, selectedPLMN:%02X/%02X).\n",
                    ptAllowList->num_plmn, ptSelectedTai->plmn.s2.mcc, ptSelectedTai->plmn.s2.mnc);

            return TRUE;
        }
    }

    return FALSE;
}  // }}}

int16_t VCOM_Decision_SelectedTAI_ByServingAMF(
    callInfo_type *ptCi, candidateNbrInformation_type *ptCandidateNbrInfo, selectedTAI_Type *ptSelectedTai)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(ptCandidateNbrInfo);
    VALID_E_POINT_CHECK_FALSE(ptSelectedTai);

    int16_t status = GOOD;

    supportedAmfSetList_Type servingAmfList;

    VCCB_CHECK_E_RANGE_AND_FALSE(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    // get PLMN list which is supported at Serving AMF
    status = VRRM_GetAmfSetList(ptCi, ptCi->endPointInfo.ngIdx, ptCi->servedGuami, &servingAmfList);
    if (status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed PLMN Selection. (Cause:No Match PLMN in Served Guami)\n");
        return FALSE;
    }

    if (ptCandidateNbrInfo->globalGnbId == pGnb->globalGnbId)
    {
        // 1-1) In case of Intra gNB Neighbour, get the PLMN list which is supported by Serving AMF, select the lowest
        // index PLMN
        if (VCOM_Decision_SelectedTAI_ByServingAMF_ForIntraGnbNbr(
                ptCi, ptCandidateNbrInfo, &servingAmfList, ptSelectedTai) == TRUE)
            return TRUE;
    }
    else  // VCCB_IS_INTER_GNB_NEIGHBOR
    {
        // 2-1) In case of Inter gNB Neighbour, get the PLMN list which is AMF Region information at target gNB and
        // supported by the Serving AMF,
        //      select the lowest index PLMN (first detect index)
        // 2-2) In case of Inter gNB Neighbour, get the PLMN list which is AMF Region information at target gNB, select
        // the lowest index PLMN
        if (VCOM_Decision_SelectedTAI_ByServingAMF_ForInterGnbNbr(
                ptCi, ptCandidateNbrInfo, &servingAmfList, ptSelectedTai) == TRUE)
            return TRUE;
    }

    return FALSE;
}  // }}}

// FGR-MC1015 FR10.CACP.SR1.HD2.DD1, FR20.CACP.SR1.HD2.DD1
int16_t VCOM_GetSelectedPLMN_FromAllowedPLMN(callInfo_type *ptCi,
    candidateNbrInformation_type *ptCandidateNbrInfo,            /* plmn list + tac from NR Connected Mobility */
    handover_Type handoverType, selectedTAI_Type *ptSelectedTai) /* output */
{                                                                // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptCandidateNbrInfo);
    VALID_E_POINT_CHECK_ERROR(ptSelectedTai);

    allowedPlmnList_Type *ptAllowList = &ptCandidateNbrInfo->nbrTaiInfo.plmnList;
    int16_t status = GOOD;

    // init value
    VCOM_InitSelectedTAI(ptSelectedTai);

    // error case - empty list
    if (ptAllowList->num_plmn == 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Selected PLMN : Allowed List Empty(%d).\n", ptAllowList->num_plmn);
        return BREAK;
    }

    // error case - invalid handover type
    if (handoverType != fivegs_to_eps && handoverType != intra5gs)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Selected PLMN : Invalid Handover Type(%d).\n", handoverType);
        return BREAK;
    }

    // If there is one target PLMN, select the PLMN.
    if (ptAllowList->num_plmn == 1)
    {
        status = VCOM_SetSelectedTAI(ptSelectedTai, ptCandidateNbrInfo, 0);
        if (status == ERROR)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_SetSelectedTAI Error!\n");
            return BREAK;
        }

        VCCB_PRINT_CALL_LOG_PLMN(ptCi, "Selected PLMN : one target PLMN (num_plmn:%d, selectedPLMN:%02X/%02X).\n",
                ptAllowList->num_plmn, ptSelectedTai->plmn.s2.mcc, ptSelectedTai->plmn.s2.mnc);

        return GOOD;
    }

    // If the Last E-UTRAN PLMN Identity exists in the recommeded PLMN list, select the Last E-UTRAN PLMN Identity.
    if (handoverType == fivegs_to_eps)  // INTER-SYSTEM HANDOVER (gNB to eNB)
    {
        if (VCOM_Decision_SelectedTAI_ByLastEutranPLMN(ptCi, ptCandidateNbrInfo, ptSelectedTai) == TRUE)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "Selected PLMN : Last E-UTRAN PLMN Identity (num_plmn:%d, selectedPLMN:%02X/%02X).\n",
                ptAllowList->num_plmn, ptSelectedTai->plmn.s2.mcc, ptSelectedTai->plmn.s2.mnc);

            return GOOD;  // select the PLMN
        }
    }

    // If the serving PLMN exists in the recommended PLMN list, select the serving PLMN
    if (VCOM_Decision_SelectedTAI_ByServedPLMN(ptCi, ptCandidateNbrInfo, ptSelectedTai) == TRUE)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Selected PLMN : serving PLMN (num_plmn:%d, selectedPLMN:%02X/%02X).\n",
            ptAllowList->num_plmn, ptSelectedTai->plmn.s2.mcc, ptSelectedTai->plmn.s2.mnc);

        return GOOD;  // select the PLMN
    }

    if (handoverType == intra5gs)  // INTRA-SYSTEM HANDOVER (gNB to gNB, gNB to ng-eNB)
    {
        if (VCOM_Decision_SelectedTAI_ByServingAMF(ptCi, ptCandidateNbrInfo, ptSelectedTai) == TRUE)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "Selected PLMN : there is one target PLMN(num_plmn:%d, selectedPLMN:%02X/%02X).\n",
                ptAllowList->num_plmn, ptSelectedTai->plmn.s2.mcc, ptSelectedTai->plmn.s2.mnc);

            return GOOD;  // select the PLMN
        }
    }

    // select the lowest index PLMN
    status = VCOM_SetSelectedTAI(ptSelectedTai, ptCandidateNbrInfo, 0);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_SetSelectedTAI Error!\n");
        return BREAK;
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "Selected PLMN : lowest index PLMN (num_plmn:%d, selectedPLMN:%02X/%02X).\n",
        ptAllowList->num_plmn, ptSelectedTai->plmn.s2.mcc, ptSelectedTai->plmn.s2.mnc);

    return GOOD;
}  // }}}

int16_t VCOM_GetServedPLMNbasedSelectedPLMN(callInfo_type *ptCi, const plmnId_type *ptSourcePlmn,
    const allowedPlmnList_Type *pt_b_plmn_list, plmnId_type *ptPlmn) /* output */
{                                                                    // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptSourcePlmn);
    VALID_E_POINT_CHECK_ERROR(pt_b_plmn_list);
    VALID_E_POINT_CHECK_ERROR(ptPlmn);

    // check validation
    if (pt_b_plmn_list->num_plmn == 0)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "BPLMN List Empty(%d)\n", pt_b_plmn_list->num_plmn);
        return ERROR;  // Reject procedure
    }

    // check the available of Serving PLMN
    for (uint32_t b_plmn_idx = 0; b_plmn_idx < MIN((uint32_t)pt_b_plmn_list->num_plmn, MAX_NUM_PLMN); b_plmn_idx++)
    {
        if (pt_b_plmn_list->plmn[b_plmn_idx].longId != ptSourcePlmn->longId) continue;

        // Select PLMN
        ptPlmn->longId = ptSourcePlmn->longId;
        return GOOD;
    }

    VCCB_PRINT_CALL_LOG_PLMN(ptCi, "ServicePLMN(0x%02X/0x%02X) was not found in BPLMN(num_plmn:%u)\n",
            ptSourcePlmn->s2.mcc, ptSourcePlmn->s2.mnc, pt_b_plmn_list->num_plmn);

    return ERROR;  // Reject procedure
}  // }}}

int16_t VCOM_getMRLbasedSelectedPLMN(
    callInfo_type *ptCi, const allowedPlmnList_Type *pt_b_plmn_list, plmnId_type *ptPlmn) /* output */
{                                                                                         // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pt_b_plmn_list);
    VALID_E_POINT_CHECK_ERROR(ptPlmn);

    hoRestrictInfoCompressed_type *ptHrl = &ptCi->hoRestrict;

    if (ptHrl->existFlag == TRUE)
    {

        VCCB_PRINT_CALL_LOG_PLMN(ptCi, "UE Served MRL in MRL (PLMN:0x%02X/0x%02X)\n", ptHrl->servedPlmn.s2.mcc,
                ptHrl->servedPlmn.s2.mnc);

        // check the available of Serving PLMN
        int16_t status = VCOM_GetServedPLMNbasedSelectedPLMN(ptCi, &ptHrl->servedPlmn, pt_b_plmn_list, ptPlmn);
        if (status == ERROR)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed MRL Based PLMN Selection. (Cause:%d)\n", status);
            return ERROR;  // Reject procedure
        }

        VCCB_PRINT_CALL_LOG_PLMN(ptCi, "Allowed MRL Based PLMN Selection. (PLMN:0x%02X/0x%02X)\n",
                ptHrl->servedPlmn.s2.mcc, ptHrl->servedPlmn.s2.mnc);

        return GOOD;
    }

    // Not Exists MRL
    VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed MRL Based PLMN Selection. (Cause:Not Exists HRL(%d))\n", ptHrl->existFlag);
    return ERROR;  // Reject procedure
}  // }}}

int16_t VCOM_GetAMFbasedSelectedPLMN(callInfo_type *ptCi, const allowedPlmnList_Type *pt_b_plmn_list,
    const supportedAmfSetList_Type *pt_servingAmfList, plmnId_type *ptPlmn, /* output */
    causeInfo_type *ptCause)                                                /* output */
{                                                                           // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pt_b_plmn_list);
    VALID_E_POINT_CHECK_ERROR(pt_servingAmfList);
    VALID_E_POINT_CHECK_ERROR(ptPlmn);
    VALID_E_POINT_CHECK_ERROR(ptCause);

    int count = 0;
    uint32_t longId = 0;

    for (unsigned int b_plmn_idx = 0; b_plmn_idx < MIN(pt_b_plmn_list->num_plmn, MAX_NUM_PLMN); b_plmn_idx++)
    {
        for (unsigned int amf_plmn_idx = 0;
             amf_plmn_idx < MIN(pt_servingAmfList->num_plmn, MAX_AMF_PLMN_PER_SUPPORTED_LIST); amf_plmn_idx++)
        {
            if (pt_b_plmn_list->plmn[b_plmn_idx].longId != pt_servingAmfList->amf_plmn[amf_plmn_idx].plmn.longId)
                continue;

            // not determined case -- This is the case when two or more PLMNs are selected.
            if (count >= 1)
            {
                // reject the procedure w/ cause
                ptCause->xnCause = CauseXnapRadioNetworkLayerHandoverTargetNotAllowed;
                ptCause->ngCause = CauseNgapRadioNetworkLayerHandoverFailureInTarget5gcNgranNodeOrTargetSystem;
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "Not Allowed AMF Based PLMN Selection. (Cause:Detect Multiple Match PLMN in AMF "
                    "PLMN(b:%d, n:%d))\n",
                    pt_b_plmn_list->num_plmn, pt_servingAmfList->num_plmn);
                return ERROR;
            }

            longId = pt_b_plmn_list->plmn[b_plmn_idx].longId;
            count++;
        }
    }

    if (count == 0)
    {
        // reject the procedure w/ cause - It is filled with a common cause from the VCOM_GetSelectedPLMN_For_SaHandIn
        // function.
        VCCB_PRINT_CALL_ERROR(ptCi,
            "Not Allowed AMF Based PLMN Selection. (Cause:No Match PLMN in AMF PLMN(b:%d, n:%d))\n",
            pt_b_plmn_list->num_plmn, pt_servingAmfList->num_set);
        return ERROR;
    }

    // update the PLMN
    ptPlmn->longId = longId;

    VCCB_PRINT_CALL_LOG_PLMN(ptCi, "Allowed AMF Based PLMN Selection. (PLMN:0x%02X/0x%02X)\n", ptPlmn->s2.mnc, ptPlmn->s2.mcc);

    return GOOD;
}  // }}}

int16_t VCOM_GetNotMRLbasedSelectedPLMN(callInfo_type *ptCi, const allowedPlmnList_Type *pt_b_plmn_list,
    plmnId_type *ptPlmn,     /* output */
    causeInfo_type *ptCause) /* output */
{                            // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pt_b_plmn_list);
    VALID_E_POINT_CHECK_ERROR(ptPlmn);
    VALID_E_POINT_CHECK_ERROR(ptCause);

    int16_t status;
    supportedAmfSetList_Type servingAmfList;

    // 2.A) when gNB doesn't receive the MRL ( If only one BPLMN can be supported by Cell, select it. )
    if (pt_b_plmn_list->num_plmn == 1)
    {
        ptPlmn->longId = pt_b_plmn_list->plmn[0].longId;

        VCCB_PRINT_CALL_LOG_PLMN(ptCi, "Allowed Non-MRL Based PLMN Selection. (PLMN:0x%02X/0x%02X)\n", ptPlmn->s2.mcc, ptPlmn->s2.mnc);

        return GOOD;
    }

    // 2.B.0) get the supported PLMN list of AMF
    {
        // 1. get PLMN list which is supported at Serving AMF
        status = VRRM_GetAmfSetList(ptCi, ptCi->endPointInfo.ngIdx, ptCi->servedGuami,
            &servingAmfList);  // tag : ngIdx or guami, info : ngIdx or guami
        if (status != GOOD)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Not Allowed Non-MRL Based PLMN Selection. (Cause:No Match PLMN in Served Guami)\n");
            return ERROR;  // Reject procedure - It is filled with a common cause from the
                           // VCOM_GetSelectedPLMN_For_SaHandIn function.
        }
    }

    // 2.B.1) Find the intersection of PLMN between AMF and Target cell
    status = VCOM_GetAMFbasedSelectedPLMN(ptCi, pt_b_plmn_list, &servingAmfList, ptPlmn, ptCause);
    if (status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "Not Allowed Non-MRL Based PLMN Selection. (Cause:BPLMN(num:%d) AMF(plmn:%d set:%d))\n",
            pt_b_plmn_list->num_plmn, servingAmfList.num_plmn, servingAmfList.num_set);
        return ERROR;  // Reject procedure - It is filled with a common cause from the VCOM_GetSelectedPLMN_For_SaHandIn
                       // function.
    }
    
    VCCB_PRINT_CALL_LOG_PLMN(ptCi, "Allowed Non-MRL Based PLMN Selection. (PLMN:0x%02X/0x%02X, BPLMN(num:%d) AMF(plmn:%d set:%d))\n",
            ptPlmn->s2.mnc, ptPlmn->s2.mcc, pt_b_plmn_list->num_plmn, servingAmfList.num_plmn, servingAmfList.num_set);

    return GOOD;
}  // }}}

// FGR-MC1015 FR60.CACP.SR1.HD1.DD1, FR60.CACP.SR1.HD2.DD1
int16_t VCOM_GetSelectedPLMN_For_SaHandIn(callInfo_type *ptCi, uint32_t cellNum, plmnId_type *ptPlmn, /* output */
    causeInfo_type *ptCause)                                                                          /* output */
{                                                                                                     // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptPlmn);
    VALID_E_POINT_CHECK_ERROR(ptCause);

    int16_t status;
    allowedPlmnList_Type b_plmn_list;
    plmnId_type selectedPlmn = ptCi->ueInfo.servedPlmn;

    *ptPlmn = ptCi->ueInfo.servedPlmn;

    // get PLMN list which is supported at target cell
    status = VLIB_getBPLMN(ptCi, cellNum, &b_plmn_list);
    if (status != GOOD)
    {
        ptCause->xnCause = CauseXnapRadioNetworkLayerCellNotAvailable;
        ptCause->ngCause = CauseNgapMiscUnknownPlmn;

        VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed PLMN Selection In SA Hand-In. (Cause:Invalid BPLMN List)\n");
        return ERROR;  // Reject procedure
    }

    // 1) when gNB received the MRL ( If Service Plmn of MRL can be supported by Cell BPLM, select it. )
    if (ptCi->hoRestrict.existFlag == TRUE)
    {
        status = VCOM_getMRLbasedSelectedPLMN(ptCi, &b_plmn_list, &selectedPlmn);
        if (status != GOOD)
        {
            ptCause->xnCause = CauseXnapRadioNetworkLayerCellNotAvailable;
            ptCause->ngCause = CauseNgapMiscUnknownPlmn;

            VCCB_PRINT_CALL_ERROR(
                ptCi, "Not Allowed PLMN Selection In SA Hand-In. (Cause:Not Allowed MRL Based PLMN Selection)\n");
            return ERROR;  // Reject procedure
        }
    }
    else  // Not MRL
    {
        status = VCOM_GetNotMRLbasedSelectedPLMN(ptCi, &b_plmn_list, &selectedPlmn, ptCause);
        if (status != GOOD)
        {
            if (ptCause->xnCause == CAUSE_NO_FAULT) ptCause->xnCause = CauseXnapRadioNetworkLayerCellNotAvailable;
            if (ptCause->ngCause == CAUSE_NO_FAULT) ptCause->ngCause = CauseNgapMiscUnknownPlmn;

            VCCB_PRINT_CALL_ERROR(
                ptCi, "Not Allowed PLMN Selection In SA Hand-In. (Cause:Not Allowed Not-MRL Based PLMN Selection)\n");
            return ERROR;  // Reject procedure
        }
    }

    VCCB_PRINT_CALL_DATA(
        ptCi, "Allowed PLMN Selection In SA Hand-In. (PLMN:0x%02X/0x%02X)\n", selectedPlmn.s2.mcc, selectedPlmn.s2.mnc);

    *ptPlmn = selectedPlmn;

    return GOOD;
}  // }}}

// }}}
/****************************************************************************
                MEAS ( SA Meas Info )
****************************************************************************/
// {{{
void VCCM_InitSaMeas(saMeasStateInfo_type *saMeas)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(saMeas);

    saMeas->iratMeasState = IRAT_MEAS_STATE_INIT;
    saMeas->saIfMeasState = SA_IFMEASSTATE_INIT;
    saMeas->lbIFMeasState = LB_MEAS_STATE_NOT_SELECTED;
    saMeas->needToMeasForSaPriorHo = VCCB_FLAG_OFF;
    saMeas->rfspHoSupport = VCCB_FLAG_OFF;
    saMeas->forcedHoState = FORCED_HO_INIT;
    saMeas->fpHoA1BasedState = A1_BASED_FP_HO_INIT;
    saMeas->iratLbHoTriggered = VCCB_FLAG_OFF; // SVR23B FGR-LC0711
    saMeas->iratFollowA2Quantity = 0;
    saMeas->intraNrFollowA2Quantity = 0;    // SVR24B FGR-MC1007 FR33
    saMeas->voNrLbState = VONR_LB_NOT_SUPPORT; // FGR-LC0712
    saMeas->saToNsaBorderHoMeas = FALSE; //SVR24B FGR-MC1007 FR380, FR381
    saMeas->specificSliceForcedHoMeas = specificSliceMeasState_disable; //25B FGR-MC1021
}

void VCCM_InitAnrMeas(reportCgiInfo_type *reportCgi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(reportCgi);

    reportCgi->clearFlag = VCCB_FLAG_OFF;

    /* 24B refactoring
    reportCgi->reportCgiFlag = VCCB_FLAG_OFF;
    reportCgi->reportCgiSnFlag = VCCB_FLAG_OFF;
    reportCgi->reportCgiDuplPci = VCCB_FLAG_OFF;
    reportCgi->reportCgiNonNeighbor = VCCB_FLAG_OFF;
    reportCgi->autonomousGapsFlag = VCCB_FLAG_OFF;
    reportCgi->rcvModRefuseFlag = VCCB_FLAG_OFF;
    reportCgi->longDrxStatus = VCCB_FLAG_OFF;
    */
}

void VCCM_InitSaMeasData(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    VCCM_InitSaMeas(&(ptCi->saMeas));
    VCCM_InitAnrMeas(&(ptCi->anrInfo.reportCgi));
}

void VCCM_InitPrevSaMeasData(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    VCCM_InitSaMeas(&(ptCi->saPrevInfo.saMeas));
    VCCM_InitAnrMeas(&(ptCi->saPrevInfo.reportCgi));
}

void VCCB_NSA_InitMeasState(nsaMeasStateInfo_type &nsaMeas)
{
    AUTO_TRACE_FUNC;

    nsaMeas.a1ForFpPScellChgReceived  = FALSE;
    nsaMeas.nsaLbMeasState            = NSA_LB_MEAS_STATE_UNKNOWN;
    nsaMeas.bearerChangeToMcgMeasFlag = VCCB_FLAG_OFF;
    nsaMeas.endcFr2MeasFlag           = FLAG_OFF;
    nsaMeas.ifMeasState               = NO_IFMEASSTATE;
}

void VCCM_InitNsaMeasData(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    VCCB_NSA_InitMeasState(ptCi->nsaMeas);
    VCCM_InitAnrMeas(&(ptCi->anrInfo.reportCgi));
}

void VCCM_InitPrevNsaMeasData(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    ptCi->nsaPrevInfo.ifMeasState = NO_IFMEASSTATE;
    VCCM_InitAnrMeas(&(ptCi->nsaPrevInfo.reportCgi));
}

int16_t FnVCCB_CheckBandwidthCondition_NR_MN(callInfo_type *ptCi, nbrGnbCellInfo_type *ptNbrGnbCell, uint16_t nbrIdx, uint16_t band)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptNbrGnbCell);

    // check the bandwidth
    if (GOOD != VLIB_checkIntraNRChannelBWs(ptCi, ptNbrGnbCell, band, ptCi->servCellNum, FALSE))
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi, "call(%d) cell(%d) nbr(gnbId:%d, cellId:%d) is not a ValidBandwidth (band:%u)\n",
            ptCi->callId, ptCi->servCellNum, ptNbrGnbCell->globalGnbId.gnbId.id, ptNbrGnbCell->cellId, band);
        return ERROR;
    }

    if (GOOD != VCCM_CheckValidDssCellCondition(ptCi, ptCi->servCellNum, nbrIdx, band))
    {
        VCCB_PRINT_CALL_TGT_SEL(
            ptCi, "call(%d) cell(%d) nbr(gnbId:%d, cellId:%d) is not a ValidDss\n", ptCi->callId, ptCi->servCellNum, ptNbrGnbCell->globalGnbId.gnbId.id, ptNbrGnbCell->cellId);

        return ERROR;
    }

    return GOOD;
}

/***************************************************************************
 * @brief           Check Intra NR Nbr bandwidth
 *
 * @param[in]       ptCi              : call information / callInfo_type
 * @param[in]       cellNum           : cell Number / uint16_t
 * @param[in]       nbrIdx            : cell neighbor index / uint16_t
 * @return          status            : GOOD, ERROR / int16_t
 ***************************************************************************/
int16_t VCCM_CheckValidBandwidthForIntraNR(
    callInfo_type *ptCi, measurementObjectNRUe_type *pMeasObj, nbrGnbCellInfo_type *ptNbrGnbCell, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptNbrGnbCell);
    VALID_E_POINT_CHECK_ERROR(pMeasObj);

    // get service band (acquisition for the band information of measurement object.
    uint16_t band = pMeasObj->minimal.freqBandIndicatorNR;

    // bandwidth list (TS 38.104 5.3.2 Transmission bandwidth configuration)
    // FR1: 5, 10, 15, 20, 25, 30, 40, 50, 60, 70, 80, 90, 100
    // FR2: 50, 100, 200, 400

    // check the bandwidth
    if (GOOD != VLIB_checkIntraNRChannelBWs(ptCi, ptNbrGnbCell, band, cellNum, FALSE))
    {
        return ERROR;
    }

    // inter gnb Nbr return GOOD
    return GOOD;
}

int16_t VCCM_CheckValidDssCellCondition(callInfo_type *ptCi, uint16_t cellNum, uint16_t nbrIdx, uint16_t band)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_NBR_PER_CELL);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    uint8_t dssEnabled;

    if (VCCB_IS_INTRA_GNB_NEIGHBOR(cellNum, nbrIdx))
    {
        uint16_t targetCellNum;
        VCCB_GET_INTRA_GNB_NBR_CELLNUM(cellNum, nbrIdx, targetCellNum);
        VCCB_CHECK_E_RANGE_AND_RETURN(targetCellNum, MAX_CELL_NUM_VCCB);
        const VccbCellInfo_type *const pTgtCell = &CELLINFO[targetCellNum];

        dssEnabled = pTgtCell->dssEnabled;
    }
    else
    {
        // source gNB does not support DSS do not validate DSS functionality for target gNB
        if (CI_no_use == pGnb->dssConfiguration.dssUESupportControl)
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi, "nbrIdx(%d) is interGnbNbr, DSS feature disabled\n", nbrIdx);
            return GOOD;
        }

        const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
        dssEnabled = pCell->Nbr[nbrIdx].dssEnabled;
    }
    if (FALSE == dssEnabled)
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi, "Target NbrCell(%d) does not indicate to support DSS - HO allowed\n", nbrIdx);
        return GOOD;
    }

    for (uint16_t bandNRidx = 0; bandNRidx < UMIN(ptCi->ueInfo.ueCapa.nr.rf.nrOfBands, MAX_NUM_UECAPA_NR_BANDS);
         bandNRidx++)
    {
        if (ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR[bandNRidx].bandNR == band)
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi, "UE and nbrCell[nbrIdx(%u)] has common band(%u)\n", nbrIdx, band);
            if (FLAG_ON == ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR[bandNRidx].rateMatchingLTE_CRS)
            {
                VCCB_PRINT_CALL_TGT_SEL(ptCi, "UE and nbrCell[nbrIdx(%u)] both support DSS\n", nbrIdx);
                return GOOD;
            }
            break;
        }
    }
    // inter gnb Nbr return GOOD
    return ERROR;
}

uint8_t VHCM_isSaEnabledNbr(callInfo_type *ptCi, nbrGnbCellInfo_type *pNbr)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(pNbr);

    if (EQUIP != pNbr->fiveGsTacStatus)
    {
        return FALSE;
    }

    // SA service is not allowed. The NR cell only supports PSCell/SCell functionality - CONFIG_TAC_IND_21C
    if (CI_use == pNbr->configuredTacIndication)
    {
        return FALSE;
    }

    // SVR23B FGR-MC1027 Connected mobility control for RedCap UE
    if (IS_REDCAP_UE(ptCi))
    {
        if (pNbr->redcapBroadcastInfo < 0)
            return FALSE;
    }

    return TRUE;
}
// }}}

/***************************************************************************
 * @brief           Check if 2 cells have neighbor relation configured
 *
 * @param[in]       cellNum           : source cell Number / uint16_t
 * @param[in]       cellNum           : target cell Number / uint16_t
 * @return          status            : true, false / bool
 ***************************************************************************/
bool VCCB_IsIntraGnbNbrCell(uint16_t cellNum, uint16_t targetCellNum)
{
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);
    VCCB_CHECK_E_RANGE_AND_VAL(targetCellNum, MAX_CELL_NUM_VCCB, false);

    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    uint16_t nbrIdx = 0;
    uint16_t intraGnbNbrCellNum = 0;

    for (nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)  // go through all the neighbors
    {
        if (N_EQUIP == pCell->Nbr[nbrIdx].status)
        {
            continue;
        }

        if (FALSE == pCell->Nbr[nbrIdx].isHoAllowed)
        {
            continue;
        }

        if (VCCB_IS_INTER_GNB_NEIGHBOR(cellNum, nbrIdx))  // only allowed intra-gnb nbr cell
        {
            continue;
        }

        VCCB_GET_INTRA_GNB_NBR_CELLNUM(cellNum, nbrIdx, intraGnbNbrCellNum);
        VCCB_CHECK_E_RANGE_AND_CONTINUE(intraGnbNbrCellNum, MAX_CELL_NUM_VCCB);

        if (intraGnbNbrCellNum == targetCellNum)
        {
            return true;
        }
    }

    return false;
}

void FnVCCB_UpdateRefusedTargetGnbIdForHandover(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // update the refused target gNB
    auto getTargetGnb = [ptCi]()
    {
        if (ptCi->hoInfo.hoGnbIdx < MAX_GNB_PER_CALL)
        {
            return ptCi->gnbInfo[ptCi->hoInfo.hoGnbIdx].globalGnbId;
        }

        vccbGlobalGnbId_type defaultGnb;
        defaultGnb.gnbId.idLength = 0;
        return defaultGnb;
    };

    for (int loop = 0; loop < MAX_REFUSED_TARGET_GNB_PER_CALL; loop++)
    {
        if (ptCi->refusedTargetGnbId[loop].gnbId.idLength == 0)  // null gnb id length
        {
            const vccbGlobalGnbId_type targetGnb = getTargetGnb();
            if (targetGnb.gnbId.idLength > 0)
            {
                ptCi->refusedTargetGnbId[loop] = targetGnb;
            }
            break;
        }
    }  // if refused target gNB is not stored in refusedTargetGnbId, SN Change could be triggered to that target gNB.
}

bool FnVCCB_isIntraMnInitMobility(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    switch (ptCi->hoInfo.sgnbAddTrigInd)
    {
        case SgnbAddTrigInd_IntraMnHo:  // Intra MN Inter SN change
            return true;

        default:
            break;
    }

    // TODO: Add the condition
    return false;
}

bool FnVCCB_isInterMnInitMobility(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    switch (ptCi->hoInfo.sgnbAddTrigInd)
    {
        case SgnbAddTrigInd_InterMnHo:  // Inter MN Inter SN change
            return true;

        default:
            break;
    }

    // TODO: Add the condition
    return false;
}

bool FnVCCB_isMnInitMobility(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (IS_NRDC_SN(ptCi))
    {
        switch (ptCi->hoInfo.sgnbAddTrigInd)
        {
            case SgnbAddTrigInd_InterMnHo:  // Inter MN Inter SN change
            case SgnbAddTrigInd_IntraMnHo:  // Intra MN Inter SN change
                return true;

            default:
                break;
        }

        switch (ptCi->hoInfo.hoType.initiated)
        {
            case HO_TYPE_SA_MGNB_INITIATED:  // (SN) MN Init Mobility, Intra-MN with Intra-SN
            case HO_TYPE_SA_MGNB_INTERMNHO:  // (SN) MN Init Mobility, Inter-MN with Intra-SN
                return true;
            default:
                break;
        }
    }
    else  // MN
    {
        switch (ptCi->stateCmd)
        {
            case IntraRatHO_cmd:
            case InterRatHO_cmd:
                switch (ptCi->hoInfo.hoType.initiated)
                {
                    case HO_TYPE_SA_INTRA_GNB_INTRA_DU_HANDOVER:      // (SA, MN) Mobility
                    case HO_TYPE_SA_INTRA_GNB_INTER_DU_HANDOVER:      // (SA, MN) Mobility
                    case HO_TYPE_SA_INTER_GNB_NG_HANDOVER:            // (SA, MN) Mobility
                    case HO_TYPE_SA_INTER_GNB_XN_HANDOVER:            // (SA, MN) Mobility
                    case HO_TYPE_SA_INTER_SYSTEM_INTER_RAT_HANDOVER:  // (SA, MN) Mobility - IRAT_HO
                    case HO_TYPE_SA_INTRA_SYSTEM_INTER_RAT_HANDOVER:  // (SA, MN) Mobility - TBD
                        if (IS_MRDC_MN(ptCi))
                        {
                            return true;
                        }
                        break;

                    default:
                        break;
                }
                break;
            default:
                break;
        }
    }

    // TODO: Add the condition
    return false;
}

bool FnVCCB_isSnInitMobility(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (IS_NRDC_SN(ptCi))
    {
        switch (ptCi->hoInfo.hoType.initiated)
        {
            case HO_TYPE_SA_SGNB_INITIATED:
            case HO_TYPE_SA_SGNB_INITIATED_INTER_SN_CHANGE:
                return true;
            default:
                break;
        }

        switch (ptCi->hoInfo.sgnbAddTrigInd)
        {
            case SgnbAddTrigInd_SnChange:
                return true;
            default:
                break;
        }
    }
    else
    {
        switch (ptCi->stateCmd)
        {
            case MrdcSNModSnMobility_cmd:
                return true;  // (MN) SN Init Mobility, Intra-SN

            case IntraRatHO_cmd:
                switch (ptCi->hoInfo.hoType.initiated)
                {
                    case HO_TYPE_SA_SGNB_INITIATED_INTER_SN_CHANGE:  // (MN, SN) SN Init Mobility, Inter-SN
                        return true;
                    default:
                        break;
                }
                break;

            default:
                break;
        }
    }

    // TODO: Add the condition
    return false;
}

bool FnVCCB_isIntraSnMobility(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (IS_NRDC_SN(ptCi))
    {
        if (VHCM_isSaHandoverUE(ptCi))
        {
            switch (ptCi->hoInfo.hoType.initiated)
            {
                // Intra Sn Change
                case HO_TYPE_SA_SGNB_INITIATED:  // (SN) SN Init Mobility, Intra-SN
                case HO_TYPE_SA_MGNB_INITIATED:  // (SN) MN Init Mobility, Intra-MN with Intra-SN
                case HO_TYPE_SA_MGNB_INTERMNHO:  // (SN) MN Init Mobility, Inter-MN with Intra-SN
                    return true;

                default:
                    break;
            }
        }
    }
    else
    {
        if (FnVCCB_IsIntraSnMobilityInMn(ptCi) == true) return true;
    }

    // TODO: Add the condition
    return false;
}

bool FnVCCB_isIntraSnIntraCellMobility(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
    {
        if (ptCi->hoInfo.targetCellNum == ptCi->servCellNum)
        {
            return true;
        }
    }

    // TODO: Add the condition
    return false;
}

// NR_CONN_MC_22A
int16_t VCCM_CheckValidSegmentedUeForIntraNrHO(callInfo_type *ptCi, nbrGnbCellInfo_type *ptNbrGnbCell, uint16_t nbrIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptNbrGnbCell);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_NBR_PER_CELL);

    // Inter-gnb nbr only, skip validation
    if (VCCB_IS_INTRA_GNB_NEIGHBOR(ptCi->servCellNum, nbrIdx))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Intra-gnb neighbor nbrIdx:%d\n", nbrIdx);
        return GOOD;
    }

    if (TRUE == FnVCCB_Check_isSegmentedUciCall(ptCi))  // Segmented UE
    {
        // check target gNB is supporting UL segmentation function
        // check end-point-xn/ul-rrc-segmentation-support-xn-neighbor-entries values
        vccbGlobalGnbId_type gnbId = ptNbrGnbCell->globalGnbId;

        if (TRUE == FnVCCB_CheckTgtNodeSupportUlSegmentCapability(ptCi->gnbNum, gnbId.gnbId.id, gnbId.plmn, NODE_XN))
        {  // send all received UE Capability container to the tgt
            VCCB_PRINT_CALL_COMMENT(ptCi, "Tgt gNB support UL Segmentation, gnbId:%u \n", gnbId.gnbId.id);
            return GOOD;
        }
        else  // Tgt Not Support Segmentation - NR only
        {
            if (TRUE == FnVCCB_isBigCapabilityRatContainer(ptCi, NRRRC_RAT_Type_nr))
            {
                VCCB_PRINT_CALL_TGT_SEL(ptCi,
                    "Tgt gNB:%d Not support UL Segmentation, So not selected nbrIdx:%u \n", gnbId.gnbId.id, nbrIdx);
                return ERROR;
            }
            else
            {  // send tgt RAT(UE NR Capability) container only to the Tgt
                VCCB_PRINT_CALL_COMMENT(ptCi,
                    "Tgt gNB:%d Not support UL Segmentation, nbrIdx:%u NR capaLength:%d (Ext:%d)OK\n", gnbId.gnbId.id,
                    nbrIdx, ptCi->ueContainerNR.numocts, ptCi->ueContainerNR_Ext.capaLength);
                return GOOD;
            }
        }
    }

    return GOOD;  // General Case - Not Segmented UE
}

// NR_CONN_MC_22A
int16_t VCCM_CheckValidSegmentedUeForIratHO(callInfo_type *ptCi, nbrEnbCellInfo_type *ptNbrEnbCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptNbrEnbCell);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);

    // check target eNB is supporting UL segmentation function
    // check end-point-x2/ul-rrc-segmentation-support-x2-neighbor-entries values
    // check end-point-xn/ul-rrc-segmentation-support-xn-neighbor-entries values
    if (TRUE == FnVCCB_Check_isSegmentedUciCall(ptCi))  // Segmented UE
    {
        uint32_t enbId = ptNbrEnbCell->enbId;
        plmnId_type plmn = ptNbrEnbCell->plmn;

        // Tgt supports Segment UE in X2
        if (TRUE == FnVCCB_CheckTgtNodeSupportUlSegmentCapability(ptCi->gnbNum, enbId, plmn, NODE_X2))
        {  // send all received UE Capability container to the tgt
            VCCB_PRINT_CALL_COMMENT(ptCi, "Tgt X2 eNB:%u support UL Segmentation \n", enbId);
            return GOOD;
        }

        // Tgt supports Segment UE in XN
        if (TRUE == FnVCCB_CheckTgtNodeSupportUlSegmentCapability(ptCi->gnbNum, enbId, plmn, NODE_XN))
        {  // send all received UE Capability container to the tgt
            VCCB_PRINT_CALL_COMMENT(ptCi, "Tgt XN eNB:%u support UL Segmentation \n", enbId);
            return GOOD;
        }

        // Not supported in X2 and XN
        if (TRUE == FnVCCB_isBigCapabilityRatContainer(ptCi, NRRRC_RAT_Type_eutra))
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi,
                "Tgt eNB:%d Not support UL Segmentation, Not selected NBR(cellId=%d)(%d)\n", enbId,
                ptNbrEnbCell->cellId, ptNbrEnbCell->pci);
            return ERROR;
        }
        else
        {  // send tgt RAT(UE EUTRA  Capability) container only to the Tgt
            VCCB_PRINT_CALL_COMMENT(ptCi, "Tgt eNB:%u Not support UL Segmentation, EUTRA capaLength:%d (Ext:%d)OK\n",
                enbId, ptCi->ueContainerEUTRA.numocts, ptCi->ueContainerEUTRA_Ext.capaLength);
            return GOOD;
        }
    }

    return GOOD;  // General Case - Not Segmented UE
}

// The below API will be used before FillNRRRC_UE_CapabilityRAT_ContainerList at Handover Preparation
void VCCM_GetUeCapaRatTypeForIntraNrHO(callInfo_type *ptCi, uint8_t *ratTypeFilter)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VALID_E_POINT_CHECK_VOID(ratTypeFilter);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    *ratTypeFilter = UE_CAPA_REQ_RAT_TYPE_ALL;  // by default

    if (IS_INTRA_GNB_HO()) return;

    if (TRUE == FnVCCB_Check_isSegmentedUciCall(ptCi))  // Segmented UE
    {
        // check target gNB is supporting UL segmentation function
        // check end-point-xn/ul-rrc-segmentation-support-xn-neighbor-entries values
        uint8_t gnbId_len = pGnb->globalGnbId.gnbId.idLength;
        uint32_t gnbId = VLIB_NrCellId2GnbId(gnbId_len, ptCi->hoInfo.cgi.ci);
        plmnId_type plmn = ptCi->hoInfo.cgi.plmn;

        // Not support Segmentation
        if (TRUE != FnVCCB_CheckTgtNodeSupportUlSegmentCapability(ptCi->gnbNum, gnbId, plmn, NODE_XN))
        {
            if (TRUE == FnVCCB_isBigCapabilityRatContainer(ptCi, NRRRC_RAT_Type_nr))
            {  // will not happen, It was filtered during NBR selection.
                VCCB_PRINT_CALL_INFORMATIVE(
                    ptCi, "%s Tgt gNB:%d Error !!! Segmented UE, Not support GNB \n", __func__, gnbId);
            }
            else
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "Tgt:%d UE_CAPA_REQ_RAT_TYPE_NR only NR capaLength:%d OK\n", gnbId,
                    ptCi->ueContainerNR_Ext.capaLength);
                *ratTypeFilter = UE_CAPA_REQ_RAT_TYPE_NR;  // NR only
            }
        }
    }
}

void VCCM_GetUeCapaRatTypeForIratHO(callInfo_type *ptCi, uint8_t *ratTypeFilter)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);
    VALID_E_POINT_CHECK_VOID(ratTypeFilter);

    *ratTypeFilter = UE_CAPA_REQ_RAT_TYPE_ALL;  // by default

    if (TRUE == FnVCCB_Check_isSegmentedUciCall(ptCi))  // Segmented UE
    {
        uint32_t enbId = (ptCi->hoInfo.cgi.ci >> 8) & e_BitMask64_20bit;
        plmnId_type plmn = ptCi->hoInfo.cgi.plmn;

        // Tgt supports Segment UE in X2
        if (TRUE != FnVCCB_CheckTgtNodeSupportUlSegmentCapability(ptCi->gnbNum, enbId, plmn, NODE_X2) &&
            TRUE != FnVCCB_CheckTgtNodeSupportUlSegmentCapability(ptCi->gnbNum, enbId, plmn, NODE_XN))

        {
            if (TRUE == FnVCCB_isBigCapabilityRatContainer(ptCi, NRRRC_RAT_Type_eutra))
            {  // will not happen, It was filtered during NBR selection.
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Tgt eNB:%u Error Segmented UE !!! \n", enbId);
            }
            else
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "Tgt eNB:%u UE_CAPA_REQ_RAT_TYPE_EUTRA only EUTRA capaLength:%d OK\n",
                    enbId, ptCi->ueContainerNR_Ext.capaLength);  // EUTRA only
                *ratTypeFilter = UE_CAPA_REQ_RAT_TYPE_EUTRA;
            }
        }
    }
}

int16_t VCOM_SaIntraCellHandover_ToExecution(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int16_t status;

    VLIB_SetCurStateAll(ptCi, STATE_Intra_Cell_Execution);

    status = FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer(ptCi, FALSE, FALSE, ID_SRB1);
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, status, "FnVCCB_SendNRRRC_RRCReconfiguration_F1DLRRCMsgTransfer(Intra-Cell) ERROR !!\n");

    // SVR26A FGR-BC0323
    // FR490: When gNB sends Handover Command to UE and if RRE wait timer is running, gNB should stop the timer.
    FnVCCB_CancelRreWaitOperation(*ptCi, VCCB_FLAG_OFF);

    if (IsAvailable_MrdcInfo() && ptCi->mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
    {
        OFF_MRDC_RSC_SETUP_FLAG(uu_scgSetup);
    }

    VLIB_AttachTimer(&ptCi->hoInfo.timer.spec, ptCi, timInternalIntraGnbHandoverComplete_id);

    return GOOD;
}  // }}}

/****************************************************************************
 * @brief           Notifies the Intra-MN with SN Change situation in the Mobility scenario.
 * @param[in]   ptCi : call information / callInfo_type
 * @return      true, false / bool
 ****************************************************************************/
bool FnVCCB_IsMrdcIntraMnHOWithSnAddition(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // Allowed MRDC UE
    if (!IsAvailable_MrdcInfo()) return false;

    // Allowed Handover UE
    if (VHCM_isSaHandoverUE(ptCi) == FALSE) return false;

    // Allowed Inter-MN HO UE
    if (FnVCCB_isIntraMnInitMobility(ptCi) == false) return false;

    // Allowed Inter-SN For MN
    if (IS_MRDC_MN(ptCi))
    {
        // Inter-MN with SN Change Case
        return FnVCCB_IsInterSnMobilityInMn(ptCi);
    }

    return false;
}

/****************************************************************************
 * @brief           Notifies the Inter-MN with SN Change situation in the Mobility scenario.
 * @details         The Mobility Case of MRDC-UE is reviewed as follows.
 *                  1) MN Side
 *                     1-1) Source MN : always false (TBD)
 *                     1-2) Target MN : if Inter-MN with SN Change is true, other is false
 *                  2) SN Side : always false (No Mobility Scenario, it is basic scenario)
 * @param[in]   ptCi : call information / callInfo_type
 * @return      true, false / bool
 ****************************************************************************/
bool FnVCCB_IsMrdcInterMnHOWithSnAddition(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // Allowed MRDC UE
    if (!IsAvailable_MrdcInfo()) return false;

    // Allowed Handover UE
    if (VHCM_isSaHandoverUE(ptCi) == FALSE) return false;

    // Allowed Inter-MN HO UE
    if (FnVCCB_isInterMnInitMobility(ptCi) == false) return false;

    // Allowed Inter-SN For MN
    if (IS_MRDC_MN(ptCi))
    {
        // Allowed Target MN(GNB)
        if (ptCi->hoInfo.isTarget == FALSE) return false;

        // Inter-MN with SN Change Case
        return FnVCCB_IsInterSnMobilityInMn(ptCi);
    }

    return false;
}

/****************************************************************************
 * @brief           Notifies the Inter-MN without SN Change situation in the Mobility scenario.
 * @details         The Mobility Case of MRDC-UE is reviewed as follows.
 *                  1) MN Side
 *                     1-1) Source MN : always false (TBD)
 *                     1-2) Target MN : if Inter-MN without SN Change is true, other is false
 *                  2) SN Side
 *                      if Inter-MN without SN Change is true, other is false
 * @param[in]   ptCi : call information / callInfo_type
 * @return      true, false / bool
 ****************************************************************************/
bool FnVCCB_IsMrdcInterMnHOWithoutSnAddition(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // Allowed MRDC UE
    if (!IsAvailable_MrdcInfo()) return false;

    // Allowed Handover UE
    if (VHCM_isSaHandoverUE(ptCi) == FALSE) return false;

    // Allowed Inter-MN HO UE
    if (FnVCCB_isInterMnInitMobility(ptCi) == false) return false;

    // Allowed Inter-SN For MN
    if (IS_MRDC_MN(ptCi))
    {
        // Allowed Target MN(GNB)
        if (ptCi->hoInfo.isTarget == FALSE) return false;

        // Inter-MN without SN Change Case
        return FnVCCB_IsIntraSnMobilityInMn(ptCi);
    }

    // Allowed Inter-SN For SN
    if (ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_MGNB_INTERMNHO) return true;

    return false;
}

void *FnVCCB_GetHandoverPreparationIEs(void *ptMsg_void)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptMsg_void);

    NRRRC_HandoverPreparationInformation *ptMsg = static_cast<NRRRC_HandoverPreparationInformation *>(ptMsg_void);

    if (ptMsg->criticalExtensions.choice != NRRRC_HandoverPreparationInformation_criticalExtensions_c1_chosen)
        return NULL;

    if (ptMsg->criticalExtensions.u.c1.choice != NRRRC_handoverPreparationInformation_chosen) return NULL;

    return &ptMsg->criticalExtensions.u.c1.u.handoverPreparationInformation;
}

/****************************************************************************
 * @brief    Mobility Control Considering Traffic status
 ****************************************************************************/
// {{{
/**
 * @brief Check gNB, DRB traffic based handover supportness
 * @param [in] ptCi : Call information / callInfo_type
 * @param [out] GOOD : gNB and DRB can support traffic based handover
 * @param [out] ERROR : gNB and DRB cannot support traffic based handover
 */
int16_t FnVCCB_IsTrafficBasedHoSupport(callInfo_type *ptCi, callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];

    uint8_t svcGrpId;
    gnbConfig_type *pGnbCfg = &pGnb->cfg;

    // 1. check traffic-based-handover per gNB
    if (VCCB_FLAG_OFF == pGnbCfg->trafficBasedHoSupport)
    {
        VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi, "[TRF_HO] Not support mobility-config-gnb/traffic-based-ho-support\n");
        return ERROR;
    }

    // 2. [24A] FGR-MC1024 Mobility control considering Traffic status (NR) FR11
    if (IS_REDCAP_UE(ptCi))
    {
        VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi, "[TRF_HO] Not supported traffic based HO for RedCap UE !!\n");
        return ERROR;
    }

    // 3. check traffic-based-handover per DRB
    uint8_t isReleaseProcedure = FALSE;  // FALSE : Do not count 'S_Release' PDU as a service group candidate.
    if (ERROR == FnVCCB_GetServiceGroupIdByDrb(ptCi, &svcGrpId, ptDi, isReleaseProcedure))
    {
        svcGrpId = 0;
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(svcGrpId, MAX_SVC_GRP_DB_NUM);  // 0 + 1...8
    SvcGrpBasedCfg_type *pSvcGrp = &pGnbCfg->svcGrpBasedCfg[svcGrpId];
    if ((CI_no_use == pSvcGrp->usage) || (VCCB_FLAG_OFF == pSvcGrp->trafficBasedNrToEutraHOSupport))
    {
        VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi,
                "[TRF_HO] %s ERROR!! (dRBId:%u svcGrpId:%d usage:%d support:%d\n", __func__,
                ptDi->dRBId, svcGrpId, pSvcGrp->usage, pSvcGrp->trafficBasedNrToEutraHOSupport); 
        return ERROR;
    }

    VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi,
            "[TRF_HO] %s GOOD (dRBId:%u svcGrpId:%d usage:%d support:%d\n", __func__,
            ptDi->dRBId, svcGrpId, pSvcGrp->usage, pSvcGrp->trafficBasedNrToEutraHOSupport); 

    return GOOD;
}

int16_t FnVCCB_CheckCommonDlTrfStatusRptCfgforNrToEutraHo(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    gnbConfig_type *pGnbCfg = &pGnb->cfg;

    // check traffic-based-handover per gNB
    if (VCCB_FLAG_OFF == pGnbCfg->trafficBasedHoSupport)
    {
        VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi, "[TRF_HO] Not support mobility-config-gnb/traffic-based-ho-support\n");
        return ERROR;
    }

    // MCO enabled condition checked
    if (TRUE == pGnb->multiCarrierOperation.multiRatCarrierChange)
    {
        VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi, "[TRF_HO] MCO is enabled\n");
        return ERROR;
    }

    // [24A] FGR-MC1024 Mobility control considering Traffic status (NR) FR11
    if (IS_REDCAP_UE(ptCi))
    {
        VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi, "[TRF_HO] Not supported traffic based HO for RedCap UE !!\n");
        return ERROR;
    }

    // NR SCG is not configured
    if (IS_NRDC(ptCi))
    {
        VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi, "[TRF_HO] Already NRDC Connected or in Progress\n");
        return ERROR;
    }

    // Check Restrict NR To EUTRA HO per UE
    if (TRUE == FnVCCB_IsRestrictedTrafficBasedNrToEutraHoFromSvcGrp(*ptCi))
    {
        VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi, "restrict-traffic-based-nr-to-eutra-handover-per-ue restricted!!\n");
        return ERROR;
    }

    // UE supports handoverLTE-EPC
    if (GOOD != VCCM_CheckUeCapaForHandoverToLTE(ptCi, cellNum))
    {
        VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi, "[TRF_HO] Doesn't support handover to EPC, ueCapa Not Supported!!\n");
        return ERROR;
    }

    // Serving AMF supports N26 Interface
    if (GOOD != VCCM_CheckN26Support(ptCi))
    {
        VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(
                ptCi, "[TRF_HO] Doesn't support handover to EPC n26 doesn't Supported (%u/%u)!!\n",
                (unsigned)ptCi->gnbNum, (unsigned)ptCi->endPointInfo.ngIdx);
        return ERROR;
    }

    // UE Capa
    if (TRUE != ptCi->ueInfo.ueCapa.nr.measAndMob.eventB_MeasAndReport)
    {
        VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi, "[TRF_HO] UE doesn't support eventB measurement and Report (%d) !!\n",
                ptCi->ueInfo.ueCapa.nr.measAndMob.eventB_MeasAndReport);
        return ERROR;
    }

    // Support eutra-measure-base-mobility
    if (TRUE != pCell->mobilityConfig.eutraMeasureBasedMobility)
    {
        VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi, "[TRF_HO] cellNum(%d) doesn't support eutra measur based mobility !!\n",
                cellNum);
        return ERROR;
    }

    uint16_t objIdx;
    enumMeasurementReportType reportType;
    uint8_t reportPurpose;
    reportConfigurationConfUe_type reportConfigCandidate;
    minimalMeasObjectConfUe_type measObjectCandidate;
    int16_t eutraMeasCheckFlag = VCCB_FLAG_OFF;

    for (objIdx = 0; objIdx < MAX_NR_OF_OBJECTEUTRA_ID_DB; ++objIdx)
    {
        measurementObjectEUTRADb_type *ptMO = &pCell->measurementsData.measurementObjectsEUTRADb[objIdx];
        measurementObjectEUTRABaseDb_type *ptMOBase = &ptMO->base;

        if (GOOD != VCCM_CheckSupportEutraMeasObject(ptCi, ptMO))
        {
            continue;
        }

        if (VCCB_IS_NOT_VALID_SA_HO_TRAFFIC_BASED_HANDOVER_EVENT(ptMOBase->trafficBasedHandoverEvent))
        {
            continue;
        }

        VCCB_GET_TRAFFIC_BASED_HO_REPORT_TYPE_AND_PURPOSE(
                ptCi, ptMOBase->trafficBasedHandoverEvent, reportType, reportPurpose);

        if (GOOD != VCCM_CheckSupportEutraMeasObject_ForIratHo(ptCi, ptMOBase, cellNum, reportType, reportPurpose))
        {
            continue;
        }

        if (!VCCB_CanMOAndRCBeAddedWithCandidates(*ptCi, cellNum, reportType, reportPurpose,
                    ptMOBase->carrierFreq, &reportConfigCandidate, &measObjectCandidate))
        {
            continue;
        }

        eutraMeasCheckFlag = VCCB_FLAG_ON;
        break;
    }

    if (VCCB_FLAG_ON != eutraMeasCheckFlag)
    {
        VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi, "[TRF_HO] Measurement Bx cannot be installed \n");
        return ERROR;
    }

    return GOOD;
}

int16_t FnVCCB_NeedToDlTrfStatusRptCfgforNrToEutraHoAddPerDRB(callInfo_type *ptCi, callDRBInfo_type *pDi, bool isSend)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pDi);

    if (isSend)
    {
        if (pDi->drbStatus != S_Setup && pDi->drbStatus != S_Modify)
        {
            VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(ptCi, "[TRF_HO] drb Status is neither S_Setup nor S_Modify\n");
            return BREAK;
        }
    }

    // Check enabled per GNB and Service Group per DRB
    if (GOOD != FnVCCB_IsTrafficBasedHoSupport(ptCi, pDi))
    {
        return BREAK;
    }

    return GOOD;
}

// }}}


void FnVCCB_SaHandoverErrorHandlingForStateMachine(
    callInfo_type *ptCi, msgUnpack_type *ptUnpack, const char *ptFuncName)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptUnpack);
    VALID_E_POINT_CHECK_VOID(ptFuncName);

    VCCB_PRINT_CALL_ERROR(
        ptCi, "status is ERROR with msgId(%d:%s) in %s\n", ptUnpack->msgId, strMsgId(ptUnpack->msgId), ptFuncName);
    VLIB_ClearAllRespFlags(ptCi);
    VCCB_DetachHoTimer(&ptCi->hoInfo);
}

/**
 * @brief This function unpacks and retrieves the RRCReconfiguration PDU from the given packed data.
 * 
 * @param ptCi Pointer to the call information structure.
 * @param ptPackData Pointer to the packed data.
 * @param length Length of the packed data.
 * @param cellGroupId Cell group identifier.
 * @return NRRRC_RRCReconfiguration* Pointer to the unpacked RRCReconfiguration PDU.
 */
NRRRC_RRCReconfiguration *FnVCCB_UnpackAndGetRRCReconfigurationPDU(
    callInfo_type *ptCi, unsigned char *ptPackData, unsigned int length, enumCellGroupId cellGroupId)
{
    AUTO_TRACE_FUNC;

    // Check if the input parameters are valid
    VALID_E_POINT_CHECK_NULL(ptCi);
    VALID_E_POINT_CHECK_NULL(ptPackData);
    VCCB_CHECK_E_RANGE_AND_NULL(cellGroupId, MAX_CELL_GROUP);

    // Get the thread ID of the current thread
    const uint8_t myThreadId = ptCi->myThreadId;

    // Check if the thread ID is within the valid range
    VCCB_CHECK_E_RANGE_AND_NULL(myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    // Retrieve a pointer to the msgUnpack_type structure
    msgUnpack_type *ptUnpack = &THREAD_INFO->call[myThreadId].buf.containing.rx.rrcReconfiguration[cellGroupId];

    // Unpack the RRCReconfiguration PDU
    int16_t status = UnpackNRRRC_RRCReconfigurationPdu(ptUnpack, ptPackData, length);

    // Check if the unpacking operation is unsuccessful
    if (status != GOOD)
    {
        // Print an error message and return NULL
        VCCB_PRINT_CALL_ERROR(ptCi, "UnpackNRRRC_RRCReconfigurationPdu Error(%d)!\n", status);
        return NULL;
    }

    // Return a pointer to the unpacked RRCReconfiguration PDU
    return reinterpret_cast<NRRRC_RRCReconfiguration *>(&ptUnpack->unpack[0]  + ptUnpack->unpackMsgOffset);
}

bool FnVCCB_IsMnTermNguUlTnlChangedFromHoPathSwitchAck(callInfo_type *ptCi)  // INTER_GNB_XN_HO_22C2
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (FnVCCB_NeedNGuUlTnlUpdate(ptCi))
    {
        return true;
    }

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[NGU-UL-TNL] NOT Changed from PathSwitchReqAck. \n");
    return false;
}

uint8_t FnVCCB_IsNrToEutraHoNotAllowedFromSvcGrp(callInfo_type *ptCi)  // NR_CONN_MC_22C2
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint8_t svcGrpId = 0, isReleaseProcedure = FALSE;

    // svcGrpId
    if (ERROR == FnVCCB_GetServiceGroupId(ptCi, &svcGrpId, isReleaseProcedure))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "UE's service group is not assigned. \n");
        svcGrpId = 0;
    }

    VCCB_CHECK_E_RANGE_AND_FALSE(svcGrpId, MAX_SVC_GRP_DB_NUM);
    SvcGrpBasedCfg_type *pSvcGrp = &pGnb->cfg.svcGrpBasedCfg[svcGrpId];
    if ((CI_use == pSvcGrp->usage) && (TRUE == pSvcGrp->nrToEutraHandoverNotAllowed))
    {
        VCCB_PRINT_CALL_CRITICAL(
            ptCi, "NrToEutraHoNotAllowed svcGrpBasedCfg: svcGrpId(%d) !!\n", svcGrpId);
        return TRUE;
    }

    return FALSE;
}
void FnVCCB_SetHandoverExecution(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    ptCi->hoInfo.handoverExecutionFlag = TRUE;
}

bool FnVCCB_IsFlagBasedE1ControlForHO(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // Current Only Support XXDC Mode 
    if (IS_MRDC(ptCi)) return true;

    return false;
}

void FnVCCB_InitOverloadedTgtGnbList(uint16_t gnbNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
    overloadedHoTgtGnbList_type *pList = &pGnb->overloadedTgtGnb;

    MUTEX_LOCK(&gOverloadHoTgtGnbMutex[gnbNum]); ///// MUTEX LOCK /////

    pList->start = pList->end = 0;

    MUTEX_UNLOCK(&gOverloadHoTgtGnbMutex[gnbNum]); ///// MUTEX UNLOCK /////
}

void FnVCCB_CleanUpOverloadedTgtGnbList(uint16_t gnbNum)
{   
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);

    struct timespec now;

    /* Get timestamp */
    if (clock_gettime(CLOCK_MONOTONIC, &now) != 0)  return; // fail to get time

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
    overloadedHoTgtGnbList_type *pList = &pGnb->overloadedTgtGnb;

    VCCB_CHECK_E_RANGE_AND_VOID(pList->start, MAX_OVERLOADED_TGT_GNB);
    VCCB_CHECK_E_RANGE_AND_VOID(pList->end, MAX_OVERLOADED_TGT_GNB);

    while (pList->start != pList->end)
    {
        if (now.tv_sec < pList->tgtGnbInfo[pList->start].endTime)
        {
            break;
        }

        pList->start++;
        if (pList->start >= MAX_OVERLOADED_TGT_GNB)
        {
            pList->start %= MAX_OVERLOADED_TGT_GNB;
        }
    }
}

uint8_t FnVCCB_IsOverloadedTgtGnb(callInfo_type *ptCi, uint16_t gnbNum, vccbGlobalGnbId_type tgtGnbId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(gnbNum, MAX_GNB_PER_SYS);

    struct timespec now = { 0, 0 };

    /* Get timestamp */
    if (clock_gettime(CLOCK_MONOTONIC, &now) != 0) // fail to get time
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "%s clock_gettime Error!! \n", __func__);
    }

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
    overloadedHoTgtGnbList_type *pList = &pGnb->overloadedTgtGnb;

    VCCB_CHECK_E_RANGE_AND_FALSE(pList->start, MAX_OVERLOADED_TGT_GNB);
    VCCB_CHECK_E_RANGE_AND_FALSE(pList->end, MAX_OVERLOADED_TGT_GNB);

    MUTEX_LOCK(&gOverloadHoTgtGnbMutex[gnbNum]); ///// MUTEX LOCK /////

    uint16_t loop = pList->start;
    while (loop != pList->end)
    {
        if (tgtGnbId.gnbId.id == pList->tgtGnbInfo[loop].tgtGnbId.gnbId.id &&
                tgtGnbId.plmn.longId == pList->tgtGnbInfo[loop].tgtGnbId.plmn.longId)
        {
            if (now.tv_sec < pList->tgtGnbInfo[loop].endTime) // including 'fail to get time' case as well 
            {
                MUTEX_UNLOCK(&gOverloadHoTgtGnbMutex[gnbNum]); ///// MUTEX UNLOCK /////

                VCCB_PRINT_CALL_HO_OVERLOADED_TGT_GNB(
                        ptCi, "gnbNum(%u) found tgtGnbId(%X/%u) endTime(%ld) > now.tv_sec(%ld)\n", gnbNum, 
                        tgtGnbId.plmn.longId, tgtGnbId.gnbId.id, pList->tgtGnbInfo[loop].endTime, now.tv_sec);

                return TRUE;
            }
            else
            {
                MUTEX_UNLOCK(&gOverloadHoTgtGnbMutex[gnbNum]); ///// MUTEX UNLOCK /////

                VCCB_PRINT_CALL_HO_OVERLOADED_TGT_GNB(
                        ptCi, "gnbNum(%u) found tgtGnbId(%X/%u) endTime(%ld) <= now.tv_sec(%ld)\n", gnbNum, 
                        tgtGnbId.plmn.longId, tgtGnbId.gnbId.id, pList->tgtGnbInfo[loop].endTime, now.tv_sec);

                return FALSE;
            }
        }

        loop++;
        if (loop >= MAX_OVERLOADED_TGT_GNB)
        {
            loop %= MAX_OVERLOADED_TGT_GNB;
        }

    }

    MUTEX_UNLOCK(&gOverloadHoTgtGnbMutex[gnbNum]); ///// MUTEX UNLOCK /////

    return FALSE;
}

void FnVCCB_AddOverloadedTgtGnb(uint16_t gnbNum, vccbGlobalGnbId_type tgtGnbId)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);

    struct timespec now;
    /* Get timestamp */
    if (clock_gettime(CLOCK_MONOTONIC, &now) != 0)  return; // fail to get time

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
    overloadedHoTgtGnbList_type *pList = &pGnb->overloadedTgtGnb;

    VCCB_CHECK_E_RANGE_AND_VOID(pList->start, MAX_OVERLOADED_TGT_GNB);
    VCCB_CHECK_E_RANGE_AND_VOID(pList->end, MAX_OVERLOADED_TGT_GNB);

    if (pList->start == ((pList->end + 1) % MAX_OVERLOADED_TGT_GNB)) // full
    {
        pList->start++;
        if (pList->start >= MAX_OVERLOADED_TGT_GNB)
        {
            pList->start %= MAX_OVERLOADED_TGT_GNB;
        }
    }

    pList->tgtGnbInfo[pList->end].tgtGnbId = tgtGnbId;
    pList->tgtGnbInfo[pList->end].endTime = static_cast<time_t>(now.tv_sec + pGnb->cfg.restrictHoToOverloadedGnb.timer);

    pList->end++;
    if (pList->end >= MAX_OVERLOADED_TGT_GNB)
        pList->end %= MAX_OVERLOADED_TGT_GNB;
}

uint8_t FnVCCB_FindOverloadedTgtGnb(uint16_t gnbNum, vccbGlobalGnbId_type tgtGnbId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_FALSE(gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
    overloadedHoTgtGnbList_type *pList = &pGnb->overloadedTgtGnb;

    VCCB_CHECK_E_RANGE_AND_FALSE(pList->start, MAX_OVERLOADED_TGT_GNB);
    VCCB_CHECK_E_RANGE_AND_FALSE(pList->end, MAX_OVERLOADED_TGT_GNB);

    // find existing entry
    uint16_t loop = pList->start;
    while (loop != pList->end)
    {   
        if (tgtGnbId.gnbId.id == pList->tgtGnbInfo[loop].tgtGnbId.gnbId.id &&
                tgtGnbId.plmn.longId == pList->tgtGnbInfo[loop].tgtGnbId.plmn.longId)
        {
            return TRUE;
        }

        loop++;
        if (loop >= MAX_OVERLOADED_TGT_GNB)
        {
            loop %= MAX_OVERLOADED_TGT_GNB;
        }
    }

    return FALSE;
}

void FnVCCB_UpdateOverloadedHoTgtGnbInfo(callInfo_type *ptCi)
{  
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->hoInfo.hoGnbIdx, MAX_GNB_PER_CALL);
    
    uint16_t gnbNum = ptCi->gnbNum;
    callGNBInfo_type *ptGi = &ptCi->gnbInfo[ptCi->hoInfo.hoGnbIdx];

    vccbGlobalGnbId_type tgtGnbId = ptGi->globalGnbId;
    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    VCCB_PRINT_CALL_HO_OVERLOADED_TGT_GNB(ptCi,"gnbInfo(%u:%X/%u): tgtGnbId(%X/%u) is overloaded !!\n",
            gnbNum, pGnb->globalGnbId.plmn.longId, pGnb->globalGnbId.gnbId.id, tgtGnbId.plmn.longId, tgtGnbId.gnbId.id);

    // Enabled or not
    if (!IS_OVERLOADED_TGT_GNB_CONTROL_ENABLED(gnbNum)) 
    {
        VCCB_PRINT_CALL_HO_OVERLOADED_TGT_GNB(ptCi,"gnbNum(%u): !IS_OVERLOADED_TGT_GNB_CONTROL_ENABLED \n", gnbNum);
        return; 
    }

    // Check target and source gNB is same 
    if ((tgtGnbId.plmn.longId == pGnb->globalGnbId.plmn.longId) && (tgtGnbId.gnbId.id == pGnb->globalGnbId.gnbId.id))
    {
        VCCB_PRINT_CALL_HO_OVERLOADED_TGT_GNB(ptCi,"gnbNum(%u): target and source gNB is same(%u)\n", 
                gnbNum, tgtGnbId.gnbId.id);
        return; 
    }

    // Check DB Mgmt
    overloadedHoTgtGnbList_type *pList = &pGnb->overloadedTgtGnb;
    VCCB_CHECK_E_RANGE_AND_VOID(pList->start, MAX_OVERLOADED_TGT_GNB);
    VCCB_CHECK_E_RANGE_AND_VOID(pList->end, MAX_OVERLOADED_TGT_GNB);

    VCCB_PRINT_CALL_HO_OVERLOADED_TGT_GNB(ptCi, "gnbNum(%u): overloaded list(%u:%u) !! \n", 
            gnbNum, pList->start, pList->end);

    MUTEX_LOCK(&gOverloadHoTgtGnbMutex[gnbNum]); ///// MUTEX LOCK /////

    // Remove outdated entry 
    FnVCCB_CleanUpOverloadedTgtGnbList(gnbNum);

    // Find  
    if (TRUE == FnVCCB_FindOverloadedTgtGnb(gnbNum, tgtGnbId))
    {
        MUTEX_UNLOCK(&gOverloadHoTgtGnbMutex[gnbNum]); ///// MUTEX UNLOCK /////

        VCCB_PRINT_CALL_HO_OVERLOADED_TGT_GNB(ptCi, "gnbNum(%u): tgtGnbId(%X/%u) in overloaded list(%u:%u) !! \n", 
                gnbNum, tgtGnbId.plmn.longId, tgtGnbId.gnbId.id, pList->start, pList->end);
        return;
    }

    // Add new entry
    FnVCCB_AddOverloadedTgtGnb(gnbNum, tgtGnbId);

    MUTEX_UNLOCK(&gOverloadHoTgtGnbMutex[gnbNum]); ///// MUTEX UNLOCK /////

    VCCB_PRINT_CALL_HO_OVERLOADED_TGT_GNB(ptCi, "gnbNum(%u): tgtGnbId(%X/%u) added in overloaded list(%u:%u) !!\n", 
            gnbNum, tgtGnbId.plmn.longId, tgtGnbId.gnbId.id, pList->start, pList->end);
}

uint8_t FnVCCB_IsOverloadedGnbNbr(callInfo_type *ptCi, nbrGnbCellInfo_type *pNbr)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(pNbr);
    VCCB_CHECK_E_RANGE_AND_FALSE(ptCi->gnbNum, MAX_GNB_PER_SYS);

    uint16_t gnbNum = ptCi->gnbNum;
    vccbGlobalGnbId_type tgtGnbId = pNbr->globalGnbId;

    // Enabled or not
    if (!IS_OVERLOADED_TGT_GNB_CONTROL_ENABLED(gnbNum)) 
    {
        VCCB_PRINT_CALL_HO_OVERLOADED_TGT_GNB(ptCi,"gnbNum(%u) !IS_OVERLOADED_TGT_GNB_CONTROL_ENABLED \n", gnbNum);
        return FALSE; 
    }

    // Is there?
    if (TRUE == FnVCCB_IsOverloadedTgtGnb(ptCi, gnbNum, tgtGnbId))
    {
        VCCB_PRINT_CALL_HO_OVERLOADED_TGT_GNB(ptCi,"gnbNum(%u) NBR overloaded tgtGnbId(%X/%u) NBR !!\n", 
                gnbNum, tgtGnbId.plmn.longId, tgtGnbId.gnbId.id);
        return TRUE;
    }

    return FALSE;
}


// MUTEX
// MUTEX_LOCK(&gOverloadHoTgtGnbMutex[gnbNum]);
// MUTEX_UNLOCK(&gOverloadHoTgtGnbMutex[gnbNum]);
int FnVCCB_InitOverloadedHoTgtGnbListMutex(pthread_mutexattr_t *pAttr)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(pAttr, EXIT_MUTEXATTR_INIT_FAIL);

    for (uint16_t loop = 0; loop < MAX_GNB_PER_SYS; loop++)
    {
        if (pthread_mutex_init(&gOverloadHoTgtGnbMutex[loop], pAttr))
        {
            return EXIT_MUTEXATTR_INIT_FAIL;
        }
    }

    return 0; // OK
}

void FnVCCB_InitOnDemandMeasConfig(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    ptCi->onDemandInfo.targetUe = FALSE; 

    VCCB_PRINT_CALL_SA_ON_DEMAND_HO(ptCi, "%s prevTargetUe:%s targetUe:FALSE \n", __func__,
            (ptCi->onDemandInfo.prevTargetUe ? "TRUE" : "FALSE"));
}

void FnVCCB_InitOnDemandHoInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    memset(&ptCi->onDemandInfo, 0x00, sizeof(ptCi->onDemandInfo));
}

void FnVCCB_SaHandoverCollectAbnormalStat(callInfo_type *ptCi)
{
    // Proceed CHO CALL Release
    if (FnVCCB_IsConditionalHandoverUE(ptCi))
    {
        VHCM_CheckStatForChoNrHO(ptCi);  // For CHO
    }

    //  Proceed HO CALL Release
    if (VHCM_isSaHandoverUE(ptCi) == TRUE)
    {
        // Check statistics normality. If statistics are not complete(Fail or Success), collect them with CpFail.
        FnVCCB_CheckStatForHO(ptCi);
    }
}

bool FnVCCB_IsNr2EndcHandoverSupported(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->servCellNum, MAX_CELL_NUM_VCCB, false);

    VccbCellInfo_type *const pServCell = &CELLINFO[ptCi->servCellNum];

    // /gutran-cu-cell/gutran-cu-cell-entries/mobility-config/nr-to-endc-handover-support
    if (TRUE != pServCell->mobilityConfig.nrToEndcHoSupport)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "%s nrToEndcHoSupport disabled on cell(%d) \n", __func__, ptCi->servCellNum);
        return false;
    }

    // NRRRC_nr_HO_ToEN_DC_r16_present
    if (TRUE != ptCi->ueInfo.ueCapa.nr.eutraParam.nrHOToENDCr16)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "%s No nrHOToENDCr16 Capa \n", __func__);
        return false;
    }

    // ptCi->ueContainerMRDC.rxFlag == VCCB_FLAG_ON && containerLen is OK
    // It is used to check whether ueContainerMRDC received can be transmitted to the target eNB on a buffer size basis.
    if (TRUE != ptCi->hoInfo.sendableUeCapaMRDC) // ptCi->ueContainerMRDC.rxFlag == VCCB_FLAG_ON
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "%s Not sendableUeCapaMRDC  \n", __func__);
        return false;
    }

    // SCG Configured UE 
    if (IS_NRDC_MN(ptCi) || IS_NEDC_MN(ptCi))
    {
        VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);
        VccbGnbInfo_type *const ptGnb = &GNBINFO[ptCi->gnbNum];

        // /mobility-config-gnb/support-nr-dc-to-en-dc-handover
        if (VCCB_FLAG_ON != ptGnb->cfg.nrdcToEndcHoSupport)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "%s MRDC nrdcToEndcHoSupport disabled  \n", __func__);
            return false;
        }
    }

    return true;
}


void FnVCCB_ForcedMobilityNr_CollectStat_PutCi(callInfo_type *ptCi) // ODF_HO_24A
{ 
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (IS_ONDEMAND_REDIRECT())
    {
        if (INTRA_RAT_REDIRECTION == ptCi->redirectionInfo.redirType) // 24A NR only, Exclude INTER_RAT_REDIRECTION 
        {
            VCCB_PRINT_CALL_SA_ON_DEMAND_HO(ptCi,"Call Release : OnDemand Redirection freq(%u)\n", 
                    ptCi->redirectionInfo.rat.nr.ssbFrequency);  // Redirected Carrier

            MACRO_STAT_PMCC_NAME(STAT_FORCED_MOBILITY_NR, UeRelByOndemandForcedMobility, ptCi, ptCi->redirectionInfo.rat.nr.ssbFrequency, 0, 0, 0, 0, __func__);
        }
        else if (INTER_RAT_REDIRECTION == ptCi->redirectionInfo.redirType) // 25B EUTRA added
        {
            VCCB_PRINT_CALL_SA_ON_DEMAND_HO(ptCi,"Call Release : OnDemand Inter Rat Redirection freq(%u)\n", 
                    ptCi->redirectionInfo.rat.eutra.carrierFreq);  // Redirected Carrier
            MACRO_STAT_PMCC_NAME(STAT_FORCED_MOBILITY_EUTRAN, UeRelToLteByOndemandForcedMobility, ptCi, ptCi->redirectionInfo.rat.eutra.carrierFreq, 0, 0, 0, 0, __func__);
        }
    }
    else if (IS_ONDEMAND_RELEASE())
    {
        VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
        const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

        VCCB_PRINT_CALL_SA_ON_DEMAND_HO(ptCi,"Call Release : OnDemand Release freq(%u)\n", 
                pCell->ssbArfcn);  // Serving PCell freuqency

        MACRO_STAT_PMCC_NAME(STAT_FORCED_MOBILITY_NR, UeRelByOndemandForcedMobility, ptCi, pCell->ssbArfcn, 0, 0, 0, 0, __func__);
    }
}

void FnVCCB_USTM_CollectStat_PutCi(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    struct FamilyTypeAndArfcn
    {
        int family;
        int type;
        Arfcn_type arfcn;
    };

    for (auto reason : USTM::allUlStatusMobilityReasons)
    {
        if (false == ptCi->ustmInfo.statusReasonTable[reason])
        {
            continue;
        }

        std::optional<FamilyTypeAndArfcn> counterInfo{};

        if (IS_USTM_REDIRECT(ptCi))
        {
            if (IS_INTRA_RAT_REDIRECTION())
            {
                const auto typeOpt = FnVCCB_MapUlStatusReasonToNRCounter(reason);
                if (typeOpt.has_value())
                {
                    counterInfo = FamilyTypeAndArfcn{.family = STAT_FORCED_MOBILITY_NR,
                        .type = *typeOpt,
                        .arfcn = ptCi->redirectionInfo.rat.nr.ssbFrequency};
                }
            }
            else if (IS_INTER_RAT_REDIRECTION())
            {
                const auto typeOpt = FnVCCB_MapUlStatusReasonToEUTRACounter(reason);
                if (typeOpt.has_value())
                {
                    counterInfo = FamilyTypeAndArfcn{.family = STAT_FORCED_MOBILITY_EUTRAN,
                        .type = *typeOpt,
                        .arfcn = ptCi->redirectionInfo.rat.eutra.carrierFreq};
                }
            }
        }
        else if (IS_USTM_RELEASE(ptCi))
        {
            VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
            const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
            const auto typeOpt = FnVCCB_MapUlStatusReasonToNRCounter(reason);
            if (typeOpt.has_value())
            {
                counterInfo = FamilyTypeAndArfcn{.family = STAT_FORCED_MOBILITY_NR,
                    .type = *typeOpt, 
                    .arfcn = pCell->ssbArfcn};
            }
        }

        if (false == counterInfo.has_value())
        {
            continue;
        }

        MACRO_STAT_PMCC_NAME(counterInfo->family, counterInfo->type, ptCi, counterInfo->arfcn, 0, 0, 0, 0, __func__);
    }
}

/****************************************************************
 *  Function             : FnVCCB_CollectingSaHandoverStatistics_E1Fail
 *  Description          : The SA Handover performs common functionalization for E1 Fail.
 *  Input                : callInfo_type*
 ***************************************************************/
void FnVCCB_CollectingSaHandoverStatistics_E1Fail(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    bool isHandoverUE = VHCM_isSaHandoverUE(ptCi);
    auto isUncolltedCase = [&]()
    {
        if (isHandoverUE == true)
        {
            // SCG Failure For NR-DC
            if (IS_NRDC_HO_SCG_RESUME(ptCi))
            {
                // The SCG failure does not require the statistics collection.
                return true;
            }
        }

        return false;
    };

    // 0) Uncollected Case
    if (isUncolltedCase() == true)
        return;

    // 1) Additional Event Statistics
    if (isHandoverUE == true || ptCi->stateCmd == MrdcSNModSnMobility_cmd)
    {
        if (IS_NRDC(ptCi))
        {
            // (MN) NRDC_SN_ADD_MN
            // (SN) NRDC_SN_ADD_SN_WITH_INVALID_CELL
            VCCB_MRDC_SN_ADD_STAT(ptCi, MRDC_SnAdd_Fail_UpFail);
        }
    }

    // 2) PCell, PSCell Change Event Statistics
    if (isHandoverUE == true)
    {
        auto isCellChangeCaseByMobility = [&]() -> bool
        {
            if (ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_SGNB_INITIATED_INTER_SN_CHANGE)
            {
                // PCell Not Change Case
                return false;
            }

            // PCell/PSCell Change Case
            return true;
        };

        if (isCellChangeCaseByMobility() == true)
        {
            const bool isNrdcSn = IS_NRDC_SN(ptCi);
            const bool isCho = (isNrdcSn == false && FnVCCB_IsConditionalHandoverUE(ptCi));
            const bool isHoPrep = (ptCi->hoInfo.handoverExecutionFlag == FALSE);

            if (isCho == true)
            {
                // For CHO (Conditional Handover)
                if (isHoPrep == true)
                {
                    // CHO_IN, CHO_OUT, ...
                    CHO_STAT(ptCi, CHO_PrepFail_E1Fail, ptCi->hoInfo.cgi);
                }
                else
                {
                    // CHO_IN, CHO_OUT, ...
                    CHO_STAT(ptCi, CHO_ExeFail_E1Fail, ptCi->hoInfo.cgi);
                }
            }
            else
            {
                // For IM HO (Immediate Handover)
                if (isNrdcSn == true)
                {
                    // For PSCell, NRDC_PSCELL_CHANGE_IN, NRDC_PSCELL_CHANGE_OUT, ...
                    VCCB_MRDC_SN_HO_STAT(ptCi, NRDC_SN_HOFail_UpFail);
                }
                else
                {
                    // For PCell, HO_OUT, HO_IN, HO_EUTRAN_OUT, HO_EUTRAN_IN, ...
                    VHCM_SA_HO_STAT(ptCi, HO_Fail_E1Fail);
                }
            }
        }
    }
}

//void FnVCCB_CollectingSaHandoverStatistics_E1Timeout(callInfo_type *ptCi)
//{
//  TODO
//}
//
//void FnVCCB_CollectingSaHandoverStatistics_F1Fail(callInfo_type *ptCi)
//{
//  TODO
//}
//
//void FnVCCB_CollectingSaHandoverStatistics_F1Timeout(callInfo_type *ptCi)
//{
//  TODO
//}
//
//void FnVCCB_CollectingSaHandoverStatistics_XnFail(callInfo_type *ptCi)
//{
//  TODO
//}
//
//void FnVCCB_CollectingSaHandoverStatistics_XnTimeout(callInfo_type *ptCi)
//{
//  TODO
//}
//
//void FnVCCB_CollectingSaHandoverStatistics_NgFail(callInfo_type *ptCi)
//{
//  TODO
//}
//
//void FnVCCB_CollectingSaHandoverStatistics_NgTimeout(callInfo_type *ptCi)
//{
//  TODO
//}
//
//void FnVCCB_CollectingSaHandoverStatistics_CpFail(callInfo_type *ptCi)
//{
//  TODO
//}

/**
 * @brief This function checks if the SN UP key change is required in the given call information.
 * 
 * @param ptCi Pointer to the call information.
 * @return true If the SN up key change is required, otherwise false.
 */
bool FnVCCB_IsSnUpKeyChangeRequired_InSn(callInfo_type *ptCi)
{
    // Validate the input pointer.
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // Check if there is any SN termination procedure ongoing for the UE.
    if (FnVCCB_IsAnySnTermPerUE(ptCi, current_bearerType) == true)
    {
        // If the security modification flag is ON, it means that the SN up key change is required.
        if (VCCB_FLAG_ON == ptCi->ueInfo.securityModFlag)
        {
            return true;
        }
    }

    // If no SN termination procedure is ongoing and the security modification flag is OFF,
    // it means that the SN up key change is not required.
    return false;
}

bool FnVCCB_CheckIfIntraCellHOIsAllowedForPSCellChange(callInfo_type *ptCi, enumHoTypeInitiated initiated)
{
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

#ifndef IPC_TEST
    // Allowed BC List
    if (ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC_Flag == VCCB_FLAG_ON)
    {
        if (GET_ALLOWED_BAND_COMB_CHG_FLAG(ptCi->flag.setupFlag))
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Info: There is no 'Selected BC Index' in the 'Allowed BC List'.\n");
            return true;
        }
    }
    else
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Warning: Allowed BC List - Not Include\n");
        return true;
    }
#endif

    // Security Key Change
    if (ptCi->ueInfo.securityModFlag == VCCB_FLAG_ON)
    {
        return true;
    }

    // SVR23A FGR-CC5203: FR51
    // [23A] SN VCCB shall choose 'Intra SN & intra DU Cell with existing PSCell' only as target PSCell for Resume
    // MR.
    if (initiated == HO_TYPE_SA_MN_INIT_SCG_RESUME)
    {
        return true;
    }

    return false;
}

/**
 * @brief HoDbController class constructor
 * 
 * @param _ptCi Pointer to callInfo_type object
 */
HoDbConroller::HoDbConroller(callInfo_type *_ptCi) : isHandoverTriggerCompleted(false), ptCi(_ptCi) {}

/**
 * @brief Destructor of HoInfoController class.
 * 
 * This destructor clears the handover information for the call if the handover trigger procedure has not been completed.
 */
HoDbConroller::~HoDbConroller()
{
    if (isHandoverTriggerCompleted == true) return;

    if (ptCi != NULL) VLIB_InitHoInfo(ptCi);
}

/**
 * @brief Sets the flag indicating whether the handover trigger procedure has been completed.
 * 
 * @param sw Flag value (default: true)
 */
void HoDbConroller::setHandoverTriggerCompleted(bool sw) { isHandoverTriggerCompleted = sw; }


/**
 * If PDU Session Management procedure is requested from AMF during Handover Preparation,
 * source gNB should operate as follows;
 * 
 * i) Source gNB should continue the ongoing handover and reject the newly requested PDU Session Management procedure with an appropriate cause:
 *    - if the ongoing handover is EPS/Emergency FB or VoNR handover; or
 *    - if the new request is not for Voice (5QI1) service; or
 *    - if the new request is for Voice (5QI1) service but the ongoing handover is prioritized. (This case represents ‘Handover first’ option.)
 * ii) Source gNB should cancel the ongoing handover and will process the newly requested PDU Session Management procedure:
 *    - if the new request is for Voice (5QI1) service and the ongoing handover is not prioritized. (This case represents ‘Voice first’ option.)
 */
bool FnVCCB_IsHoCancelReqdForVoNR(callInfo_type *ptCi)
{   
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // STATE
    if (ptCi->state != STATE_INTER_Pre_DU_S && ptCi->state != STATE_INTER_Pre_CU_S) return false;

    /* VoNR or EPS/Emergency FB HO */
    if (TRUE == ptCi->hoInfo.isVonrCall || IS_FALLBACK_CASE(ptCi)) return false;

    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, false);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (pGnb->cfg.hoVoicePriority != PRI_VOICE_FIRST) return false;

    return true;  // HO Cancel condition
}  

/**
 * @brief Sets the flag indicating whether partial handovers are currently allowed.
 * 
 * This function updates the `rCall.hoInfo.currentlyAllowPartial` flag based on the current call type,
 * state command, and other conditions. If the `allow` parameter is false, it sets the flag to false.
 * Otherwise, it determines whether partial handovers are allowed based on the handover type and
 * whether the call is part of a specific scenario.
 * 
 * @param rCall Reference to the call information structure.
 * @param allow Boolean indicating whether to allow partial handovers.
 */
void FnVCCB_SetCurrentlyAllowPartialHO(callInfo_type &rCall, bool allow)
{
    AUTO_TRACE_FUNC;

    if (rCall.callType != E_CALLTYPE_SA) return;

    if (rCall.stateCmd != IntraRatHO_cmd && rCall.stateCmd != InterRatHO_cmd) return;

    if (IS_CHO(&rCall)) return;
    
    bool current = rCall.hoInfo.currentlyAllowPartial;
    if (not allow)
    {
        /* 
            In SVR25B, allow can be false in below case
            - during Inter-MN w/ SN change, when SN addition fails
            - HO cancel?
        */
        
        rCall.hoInfo.currentlyAllowPartial = FALSE;
        VCCB_PRINT_CALL_INFORMATIVE(&rCall, "AllowPartialHO (%s)->(false)\n", (current)? "true":"false");
        return;
    }
    bool determined = false;

    /*
        Partial accept allow scenario:
            - Inter-gNB HO (Non-DC to Non-DC only) : 25A~
            - Intra-gNB HO (Non-DC to Non-DC only) : 25B~
            - Inter-gNB HO (NR-DC to Non-DC w/o trying SN Add) : 25B~
              Inter-gNB HO (NR-DC to Non-DC by failing SN Add) : not supported
            - Inter-MN HO w/ SN Change : 25B~
            - Other NR-DC HO cases : not supported
    */

    if (rCall.hoInfo.hoType.nb == HO_TYPE_INTER_NB)
    {
        if (rCall.hoInfo.isTarget == TRUE)
        {
            if (!IS_MRDC(&rCall))
            {
                determined = true;
            }
            else if (IS_NRDC_MN(&rCall))
            {
                if (rCall.mrdcInfo.mobilityCfg.ueState == ci_scg_released_ue)
                {
                    determined = TRUE;
                }
                else
                {
                    determined = FnVCCB_IsInterSnMobilityInMn(&rCall);
                }
            }
        }
    }
    else if (rCall.hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
    {
        if (!IS_MRDC(&rCall))
        {
            determined = true;
        }
    }
    
    rCall.hoInfo.currentlyAllowPartial = determined;

    VCCB_PRINT_CALL_INFORMATIVE(&rCall, "AllowPartialHO (%s)->(%s)\n", (current)? "true":"false", (determined)? "true":"false");
}

/**
 * @brief Sets partial flags by F1 failure for intra-GNB handover.
 * @param rCall Reference to the call information structure.
 * @param ptDi Pointer to the DRB information structure.
 *
 * @note This function should only be called when the call state is IntraRatHO_cmd and the handover type is intra-NB.
 */
void FnVCCB_SetPartialFlagsByF1Fail_ForIntraGnbHo(callInfo_type *ptCi, callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptDi);

    if (ptCi->stateCmd != IntraRatHO_cmd) return;
    if (ptCi->hoInfo.hoType.nb != HO_TYPE_INTRA_NB) return;
    if (ptCi->drbPartialInfo.e1f1Info[PARTIAL_INTERFACE_F1].requestedOption == PARTIAL_OPT_NONE) return;

    SET_NEED_SEND_TX_STOP_BY_FORCE(ptDi, TRUE);
    SET_NEED_RELEASE_FAIL_DRB_FROM_AMF(ptDi, TRUE);
    ONBIT_U32(ptCi->drbIdsToRelease, ptDi->dRBId - 1);
}

/**
 * @brief Check if DRB is released to UE based on specified conditions
 * @param[in] rDrb Reference to callDRBInfo_type object containing DRB information
 * @return bool True if DRB is released to UE, false otherwise
 */
bool FnVCCB_IsDrbReleasedToUe(callDRBInfo_type *ptDi)
{   
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    if (ptDi->usage != CI_use) return false;
    if (ptDi->drbStatus != S_Modify && ptDi->drbStatus != S_Release) return false;
    
    /*
        [25B FRG-MC1008:FR210] 
        At this point, F1 failed DRB has been released from UE during intra-gNB HO already.
        By the way, after HO finalized, CU proceeds the procedure sending NG PDU Session Resource Notify and others, too.
        In this case, F1 Mod Req or RRC Reconfiguration shouldn't include released DRB in drb-ToReleaseList IE.
    */
    return (ptDi->alreadyReleasedByF1Partial_intraGnbOnlyUsed);
}

/**
 * @brief Determines if a transmission stop signal (TxStop) needs to be sent for a failed DRB.
 * @param[in] rDrb Reference to the DRB information structure containing the DRB's state and usage details.
 * @return bool Returns true if TxStop should be sent, false otherwise.
 * @note Implements 25B FRG-MC1008:FR186 requirements for DRB failure handling.
 */
bool FnVCCB_NeedToSendTxStopForFailedDrb(callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    if (ptDi->usage != CI_use) return false;
    if (ptDi->drbStatus != S_Modify) return false;
    
    /*
        [25B FRG-MC1008:FR186]
        In general intra-gNB HO, CU doesn't include F1 failed DRB in dRB-To-Modify-List-NG-RAN nor set dl-TX-Stop to stop
        But by the request from UP-side, CU includes F1 failed DRB in dRB-To-Modify-List-NG-RAN and set dl-TX-Stop to stop
    */
    return (ptDi->needToSendTxStopByF1Partial_intraGnbOnlyUsed);
}

bool FnVCCB_NeedToReleaseFailedDrbFromAmf(callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    if (ptDi->usage != CI_use) return false;
    
    /*
        [25B FRG-MC1008:FR186]
        In general intra-gNB HO, CU doesn't include F1 failed DRB in dRB-To-Modify-List-NG-RAN nor set dl-TX-Stop to stop
        But by the request from UP-side, CU includes F1 failed DRB in dRB-To-Modify-List-NG-RAN and set dl-TX-Stop to stop
    */
    return (ptDi->needToReleaseAmfByF1Partial_intraGnbOnlyUsed);
}

uint8_t FnVCCB_IsRestrictedTrafficBasedNrToEutraHoFromSvcGrp(callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_FALSE(rCall.gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *const pGnb = &GNBINFO[rCall.gnbNum];

    uint8_t svcGrpId = 0, isReleaseProcedure = FALSE;

    // svcGrpId
    if (ERROR == FnVCCB_GetServiceGroupId(&rCall, &svcGrpId, isReleaseProcedure))
    {
        VCCB_PRINT_CALL_COMMENT(&rCall, "UE's service group is not assigned. \n");
        svcGrpId = 0;
    }

    VCCB_CHECK_E_RANGE_AND_FALSE(svcGrpId, MAX_SVC_GRP_DB_NUM);

    SvcGrpBasedCfg_type *pSvcGrp = &pGnb->cfg.svcGrpBasedCfg[svcGrpId];
    if ((CI_use == pSvcGrp->usage) && (TRUE == pSvcGrp->restrictTrafficBasedNrToEutraHOPerUe)) // [25B] FGR-MC1024 FR20 
    {
        VCCB_PRINT_CALL_TRF_HO_QUE_ACTION(&rCall, 
                "[TRF_HO] %s Restricted!! svcGrpId:%d usage:%d restrict:%d\n", __func__,
                svcGrpId, pSvcGrp->usage, pSvcGrp->trafficBasedNrToEutraHOSupport);
        return TRUE;
    }

    return FALSE;
}

void FnVCCB_SetBitToReleaseDRB(callInfo_type &rCi, DRB_IsCheckFunc isCheckFunc)
{
    for (auto drbIdx = 0; drbIdx < MAX_DRB_PER_UE; drbIdx++)
    {
        callDRBInfo_type &rDrb = rCi.drb[drbIdx];

        if (!IS_VALID_NODE(DRB_NODE, &rCi, &rDrb)) continue;

        if (isCheckFunc(rDrb) == true)
        {
            ONBIT_U32(rCi.drbIdsToRelease, rDrb.dRBId - 1);
        }
    }
}

/**
 * @brief Determines if a UE is serving specific slice.
 * @param rCall Reference to call information structure containing gNB number and PD session details.
 * @return true If the UE is associated with the specific slice; false otherwise.
 */
bool FnVCCB_IsSpecificSliceUE(callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(rCall.gnbNum, MAX_GNB_PER_SYS, false);

    VccbGnbInfo_type *const pGnb = &GNBINFO[rCall.gnbNum];
    specificSliceConfig_type &rSpecificSliceCfg = pGnb->cfg.gnbMobilityConfig.sliceAware.specificSliceConfig;

    if (rSpecificSliceCfg.usage != TRUE) return false;

    for (uint8_t sliceIdx = 0; sliceIdx < MAX_SPECIFIC_SLICE_INFO_ENTRIES; sliceIdx++)
    {
        auto rSlice = rSpecificSliceCfg.sliceInfo[sliceIdx];

        if (rSlice.usage != CI_use) continue;

        for (uint8_t pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
        {
            if (rCall.pduSess[pduIdx].usage == CI_no_use) continue;

            if (rCall.pduSess[pduIdx].sNssai.sstSd == rSlice.sstSd) return true;
        }
    }

    return false;
}
