#include "FeatHoCommon.h"
#include "FeatCallProc.h"
#include "ComInclude.h"
#include "ComLibUtility.h"
#include "ComPrint.h"
#include "ComTimeUtil.h"
#include "FeatNonNeighborHo.h"

long timevalToMicroseconds(const struct timeval& tv);

HoFailedCellManager::HoFailedCellManager(callInfo_type& rCall, enumFailedCellListType failedCellListType) : 
    m_rCall(rCall),
    m_failedCellListType(failedCellListType),
    m_cgi({})
{
}

HoFailedCellManager::HoFailedCellManager(callInfo_type& rCall, enumFailedCellListType failedCellListType, const cgi_type &cgi) : 
    m_rCall(rCall),
    m_failedCellListType(failedCellListType),
    m_cgi(cgi)
{}


/**
 * @brief Initialize failed cell list using getList()
 */
void HoFailedCellManager::InitList()
{
    failedCellInfo_type* ptFailedCellList = getList();
    const int maxIndex = getMaxCellNum();
    
    if (ptFailedCellList == nullptr) return;

    for (int i = 0; i < maxIndex; i++)
    {
        ptFailedCellList[i].usage = CI_no_use;
    }
}

/**
 * @brief Set failed cell information
 * @param ptFailedCell Pointer to failed cell information
 * @param currentTime Current time
 * @param cgi Cell CGI information
 */
void HoFailedCellManager::setFailedCellInfo(failedCellInfo_type* ptFailedCell, const struct timeval& currentTime, 
                                           const cgi_type& cgi)
{
    VALID_E_POINT_CHECK_VOID(ptFailedCell);

    ptFailedCell->usage = CI_use;
    ptFailedCell->cgi = cgi;
    // store current sec value after 1970/01/01, The bigger the value, the more up-to-date.
    ptFailedCell->failTime = currentTime;
}

/**
 * @brief Update fail time of existing CGI in failed cell list
 * @param ptFailedCell Pointer to failed cell information
 * @param currentTime Current time
 */
void HoFailedCellManager::updateFailTime(failedCellInfo_type* ptFailedCell, const struct timeval& currentTime)
{
    VALID_E_POINT_CHECK_VOID(ptFailedCell);
    
    ptFailedCell->failTime = currentTime;
    VCCB_PRINT_CALL_COMMENT(&m_rCall, "the cell(ci:%llu,plmn:%x) is already registered in %s\n",
        1ULL * m_cgi.ci, m_cgi.plmn.longId, getListName());
}

/**
 * @brief Find cell indices for failed cell management
 * @param ptFailedCellList Pointer to failed cell list
 * @param maxIndex Maximum index
 * @param currentTime Current time
 * @return CellSearchResult containing search results
 */
HoFailedCellManager::CellSearchResult HoFailedCellManager::findCellIndices(
    const failedCellInfo_type* ptFailedCellList, 
    int maxIndex, const struct timeval& currentTime)
{
    CellSearchResult result;
    result.cellAlreadyExists = false;
    result.firstNoUseIndex = maxIndex;  // Initialize to maxIndex (invalid)
    result.oldestUseIndex = maxIndex;   // Initialize to maxIndex (invalid)
    result.oldestFailTime = currentTime;

    for (int cellIdx = 0; cellIdx < maxIndex; cellIdx++)
    {
        if (ptFailedCellList[cellIdx].usage == CI_use)
        {
            // Goal 1: Check if cell already exists
            if (FnVCCB_CheckCgiIdentical(&ptFailedCellList[cellIdx].cgi, &m_cgi))
            {
                updateFailTime(const_cast<failedCellInfo_type*>(&ptFailedCellList[cellIdx]), currentTime);
                result.cellAlreadyExists = true;
                return result;
            }

            // Goal 3: Find oldest used item
            if (VHCM_DiffTimeVal(ptFailedCellList[cellIdx].failTime, result.oldestFailTime) == -1)
            {
                result.oldestUseIndex = cellIdx;
                result.oldestFailTime = ptFailedCellList[cellIdx].failTime;
            }
        }
        else
        {
            // Goal 2: Find first no-use item (only set once)
            if (result.firstNoUseIndex == maxIndex)
            {
                result.firstNoUseIndex = cellIdx;
            }
        }
    }

    return result;
}

/**
 * @brief Store failed cell information
 * @param currentTime Current time
 * @return GOOD for success, ERROR/BREAK for failure
 */
void HoFailedCellManager::storeFailedCellInfo(const struct timeval& currentTime)
{
    failedCellInfo_type* ptFailedCellList = getList();
    const int maxIndex = getMaxCellNum();
    
    if (ptFailedCellList == nullptr) return;

    // Search failed cell list
    CellSearchResult result = findCellIndices(ptFailedCellList, maxIndex, currentTime);
    
    // If cell already exists, updateFailTime was called inside findCellIndices
    if (result.cellAlreadyExists) return;

    // Determine which index to use
    int newIndex = maxIndex;
    if (result.firstNoUseIndex < maxIndex)
    {
        newIndex = result.firstNoUseIndex;  // Use empty slot
    }
    else if (result.oldestUseIndex < maxIndex)
    {
        newIndex = result.oldestUseIndex;   // Use oldest slot
    }
    
    if (newIndex == maxIndex)
    {
        VCCB_PRINT_CALL_HANDOVER_FAILURE(&m_rCall, "newIndex(%d) == maxIndex(%d) %s!!", 
            newIndex, maxIndex, getListName());
        return ;
    }

    setFailedCellInfo(&ptFailedCellList[newIndex], currentTime, m_cgi);

    VCCB_PRINT_CALL_HANDOVER_FAILURE(&m_rCall, "new failed cell added(idex:%d, cgi:%X/%llu) to %s\n",
        newIndex, ptFailedCellList[newIndex].cgi.plmn.longId, 1ULL * ptFailedCellList[newIndex].cgi.ci, getListName());
}

/**
 * @brief Handles common logic for updating failed cell information.
 * @return true if the update was successful, false otherwise.
 */
void HoFailedCellManager::updateFailedCell()
{
    struct timeval currentTime;
    if (ComTimeUtil::get_current_time(currentTime) < 0)
    {
        VCCB_PRINT_ERROR("ComTimeUtil::get_current_time ERROR in %s\n", getListName());
        return ;
    }

    storeFailedCellInfo(currentTime);
}


/**
 * @brief Validate current time and prevent timer value
 * @param currentTime Reference to store current time
 * @param preventTimerValue Reference to store prevent timer value
 * @return true if validation successful, false otherwise
 */
bool HoFailedCellManager::validateTimerAndTime(struct timeval& currentTime, uint16_t& preventTimerValue)
{
    if (ComTimeUtil::get_current_time(currentTime) < 0)
    {
        VCCB_PRINT_CALL_ERROR(&m_rCall, "ComTimeUtil::get_current_time ERROR in %s\n", __FUNCTION__);
        return false;
    }

    preventTimerValue = getPreventTimerValue();
    if (preventTimerValue == 0)
    {
        VCCB_PRINT_CALL_ERROR(&m_rCall, "getPreventTimerValue returned 0 in %s\n", __FUNCTION__);
        return false;
    }

    return true;
}

/**
 * @brief Check elapsed time and log information
 * @param ptFailedCell Pointer to failed cell information
 * @param currentTime Current time
 * @param preventTimerValue Prevent timer value in milliseconds
 * @param cgi CGI information for logging
 * @return true if cell is still within prevent timer, false otherwise
 */
bool HoFailedCellManager::checkElapsedTimeAndLog(const failedCellInfo_type* ptFailedCell, const struct timeval& currentTime, 
                                                uint16_t preventTimerValue, const cgi_type& cgi)
{
    failedCellInfo_type* ptFailedCellList = getList();
    if (ptFailedCellList == nullptr) return false;

    auto idx = ptFailedCell - ptFailedCellList;

    if (DBG->flag.logHoFailedCellList)
    {
        VCCB_PRINT_CALL_INFORMATIVE(&m_rCall, "%s[idx:%ld](ncgi:%x,%llu/cTime:%ld,%ld/fTime:%ld.%ld/tThr:%d)\n",
             getListName(), idx, cgi.plmn.longId, 1ULL * cgi.ci, currentTime.tv_sec, currentTime.tv_usec, 
             ptFailedCell->failTime.tv_sec, ptFailedCell->failTime.tv_usec, preventTimerValue);
    }

    long currentMicroTime = timevalToMicroseconds(currentTime);
    long failMicroTime = timevalToMicroseconds(ptFailedCell->failTime);

    if (currentMicroTime > failMicroTime) 
    {
        long elapsedMicroTime = currentMicroTime - failMicroTime;

        if (elapsedMicroTime < (preventTimerValue * 1000L)) 
        {
            return true;
        } 
        else 
        {
            const_cast<failedCellInfo_type*>(ptFailedCell)->usage = CI_no_use;
            return false;
        }
    } 
    else 
    {
        const_cast<failedCellInfo_type*>(ptFailedCell)->usage = CI_no_use;
        return false;
    }
}

/**
 * @brief Check if the specified cell is a failed cell
 * @return true if failed cell, false if normal cell
 */
bool HoFailedCellManager::isFailedCell()
{
    failedCellInfo_type *ptFailedCellList = getList();
    if (ptFailedCellList == nullptr) return false;

    const int maxIndex = getMaxCellNum();

    auto it = std::find_if(ptFailedCellList, ptFailedCellList + maxIndex,
        [this](const failedCellInfo_type& failedCell) {
            return failedCell.usage == CI_use && 
                   FnVCCB_CheckCgiIdentical(&failedCell.cgi, &m_cgi) == TRUE;
        });

    if (it == (ptFailedCellList + maxIndex))
    {
        return false;
    }

    struct timeval currentTime;
    uint16_t preventTimerValue;
    
    if (!validateTimerAndTime(currentTime, preventTimerValue))
    {
        return false;
    }

    return checkElapsedTimeAndLog(it, currentTime, preventTimerValue, m_cgi);
}

/**
 * @brief Get the failed cell list based on the manager's type
 * @return Pointer to the first element of the failed cell info array
 */
failedCellInfo_type* HoFailedCellManager::getList()
{
    switch (m_failedCellListType)
    {
        case FAILED_CELL_LIST_TYPE_LTM:
            return &m_rCall.ltmBlockList.blockedCell[0];
        
        /* For near future
        case FAILED_CELL_LIST_TYPE_CHO:
            return &m_rCall.CHOBlockList.blockedCell[0];
        
        case FAILED_CELL_LIST_TYPE_HO:
            if (HO_TYPE_INTER_RAT == m_rCall.hoInfo.hoType.rat)
            {
                return &m_rCall.hoFailCellList.eutraCell[0];
            }
            else // HO_TYPE_INTRA_RAT == m_rCall.hoInfo.hoType.rat
            {
                return &m_rCall.hoFailCellList.nrCell[0];
            }
        */
        default:
            VCCB_PRINT_CALL_ERROR(&m_rCall, "Invalid failed cell list type: %d\n", m_failedCellListType);
            return nullptr;
    }
}

/**
 * @brief Get the maximum cell count for the manager's failed cell list type
 * @return Maximum cell count for the manager's list type
 */
int HoFailedCellManager::getMaxCellNum()
{
    switch (m_failedCellListType)
    {
        case FAILED_CELL_LIST_TYPE_LTM:
            return MAX_LTM_BLOCKED_CELL_COUNT;
        
        /* For near future
        case FAILED_CELL_LIST_TYPE_CHO:
            return MAX_CHO_BLOCKED_CELL_COUNT;
        
        case FAILED_CELL_LIST_TYPE_HO:
            return MAX_HO_FAILED_CALL_COUNT;
        */
        default:
            VCCB_PRINT_CALL_ERROR(&m_rCall, "Invalid failed cell list type: %d\n", m_failedCellListType);
            return 0;
    }
}

/**
 * @brief Get the list name based on the manager's failed cell list type
 * @return List name string
 */
const char* HoFailedCellManager::getListName()
{
    switch (m_failedCellListType)
    {
        case FAILED_CELL_LIST_TYPE_LTM:
            return "LtmBlockList";
        /* For near future
        case FAILED_CELL_LIST_TYPE_CHO:
            return "ChoBlockCell";
        
        case FAILED_CELL_LIST_TYPE_HO:
            return "HoFailedHO";
        */
        default:
            VCCB_PRINT_CALL_ERROR(&m_rCall, "Invalid failed cell list type: %d\n", m_failedCellListType);
            return "Unknown";
    }
}

/**
 * @brief Get LTM blocked timer value from GNBINFO configuration
 * @return LTM blocked timer value
 */
uint16_t HoFailedCellManager::getPreventTimerValue()
{
    switch (m_failedCellListType)
    {
        case FAILED_CELL_LIST_TYPE_LTM:
            return GNBINFO[m_rCall.gnbNum].cfg.gnbMobilityConfig.ltmConfig.ltmBlockedTimer;
        /* For near future
        case FAILED_CELL_LIST_TYPE_CHO:
            return ; //ref: fnVCCB_GetHoPrepFailedTimer(*ptCi, ptCi->servCellNum);
        
        case FAILED_CELL_LIST_TYPE_HO:
            return ; //ref: fnVCCB_GetHoPrepFailedTimer(*ptCi, ptCi->servCellNum);
        */
        default:
            VCCB_PRINT_CALL_ERROR(&m_rCall, "Invalid failed cell list type: %d\n", m_failedCellListType);
            return 0;
    }
}

/****************************************************************************
 * handle HO failed Cell
****************************************************************************/
  //{{{
void VLIB_InitHoFailedCellList(callInfo_type *ptCi)
{  //{{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    int i;

    for (i = 0; i < MAX_HO_FAILED_CALL_COUNT; i++)
    {
        ptCi->hoFailCellList.nrCell[i].usage = CI_no_use;
        ptCi->hoFailCellList.eutraCell[i].usage = CI_no_use;
    }

    return;
}  // }}}

bool FnVCCB_needStoreFailList(
    callInfo_type *ptCi, const int maxIndex, struct timeval currentTime, failedCellInfo_type *ptFailedCell)
{  //{{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptFailedCell, false);

    int cellIdx;

    // if already registered cell, skip
    for (cellIdx = 0; cellIdx < maxIndex; cellIdx++)
    {
        if (CI_no_use == ptFailedCell[cellIdx].usage) continue;

        if (FnVCCB_CheckCgiIdentical(&ptFailedCell[cellIdx].cgi, &ptCi->hoInfo.cgi))
        {
            ptFailedCell[cellIdx].failTime = currentTime;
            VCCB_PRINT_CALL_COMMENT(ptCi, "the cell(ci:%llu,plmn:%x) is already registered in Ue FailedCellList\n",
                1ULL * ptCi->hoInfo.cgi.ci, ptCi->hoInfo.cgi.plmn.longId);
            return false;
        }
    }
    return true;
}  // }}}

int FnVCCB_findNewIndex(
    callInfo_type *ptCi, const int maxIndex, struct timeval currentTime, failedCellInfo_type *ptFailedCell)
{  //{{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(ptFailedCell);

    int cellIdx;

    struct timeval oldestFailTime = currentTime;

    // find empty cellIdx
    for (cellIdx = 0; cellIdx < maxIndex; cellIdx++)
    {
        if (CI_no_use == ptFailedCell[cellIdx].usage)
        {
            return cellIdx;
        }
    }

    // get the oldest Cell index
    int newIndex = maxIndex;
    for (cellIdx = 0; cellIdx < maxIndex; cellIdx++)
    {
        if (VHCM_DiffTimeVal(ptFailedCell[cellIdx].failTime, oldestFailTime) == -1)
        {
            newIndex = cellIdx;
            oldestFailTime = ptFailedCell[cellIdx].failTime;
        }
    }
    return newIndex;
}  // }}}

void FnVCCB_SetFailedCellInfo(callInfo_type *ptCi, struct timeval currentTime, failedCellInfo_type *ptFailedCell)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptFailedCell);

    ptFailedCell->usage = CI_use;
    ptFailedCell->cgi = ptCi->hoInfo.cgi;
    // store current sec value after 1970/01/01, The bigger the value, the more up-to-date.
    ptFailedCell->failTime = currentTime;

    return;
}  // }}}

int16_t FnVCCB_storeFailedCellInfo(
    callInfo_type *ptCi, const int maxIndex, struct timeval currentTime, failedCellInfo_type *ptFailedCell)
{  //{{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptFailedCell);

    if (FnVCCB_needStoreFailList(ptCi, maxIndex, currentTime, ptFailedCell) == false)
    {
        return BREAK;
    }

    int newIndex = FnVCCB_findNewIndex(ptCi, maxIndex, currentTime, ptFailedCell);
    if (newIndex >= maxIndex)
    {
        return ERROR;
    }

    FnVCCB_SetFailedCellInfo(ptCi, currentTime, &ptFailedCell[newIndex]);

    return GOOD;
}  // }}}

bool FnVCCB_IsFailedCellByCgi(
    const callInfo_type *ptCi, const int maxIndex, cgi_type *pCgi, failedCellInfo_type *pFailedCell)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pCgi, false);
    VALID_E_POINT_CHECK_RET_VAL(pFailedCell, false);

    int32_t failedCellIdx;

    for (failedCellIdx = 0; failedCellIdx < maxIndex; failedCellIdx++)
    {
        if (pFailedCell[failedCellIdx].usage == CI_no_use) continue;

        if (TRUE == FnVCCB_CheckCgiIdentical(&pFailedCell[failedCellIdx].cgi, pCgi))
        {
            return true;
        }
    }

    return false;
}  // }}}

void VHCM_UpdateHandoverPreparationFailureCellInfo(callInfo_type *ptCi)
{  //{{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    failedCellInfo_type *ptFailedCell;

    if(ptCi->hoInfo.nonNbrCell == TRUE)
    {
        VCCB_PRINT_CALL_NON_NBR_HO(ptCi, "%s HO to nonNbrCell, so return!! \n", __func__);
        return;
    }

    if (HO_TYPE_INTRA_RAT == ptCi->hoInfo.hoType.rat)
    {
        ptFailedCell = &ptCi->hoFailCellList.nrCell[0];
    }
    else if (HO_TYPE_INTER_RAT == ptCi->hoInfo.hoType.rat)
    {
        ptFailedCell = &ptCi->hoFailCellList.eutraCell[0];
    }
    else
    {
        return;
    }

    struct timeval currentTime;
    if (ComTimeUtil::get_current_time(currentTime) < 0)
    {
        VCCB_PRINT_ERROR("ComTimeUtil::get_current_time ERROR in %s\n", __FUNCTION__);
        return;
    }

    if (ERROR == FnVCCB_storeFailedCellInfo(ptCi, MAX_HO_FAILED_CALL_COUNT, currentTime, ptFailedCell))
    {
        VCCB_PRINT_CALL_HANDOVER_FAILURE(ptCi, "FnVCCB_storeFailedCellInfo Fail in %s!!", __FUNCTION__);
        return;
    }

    VCCB_PRINT_CALL_HANDOVER_FAILURE(ptCi, "Register cell(cgi:%X/%llu) in Handover Failed Cell List\n",
        ptFailedCell->cgi.plmn.longId, 1ULL * ptFailedCell->cgi.ci);
    return;
}  //}}}

long timevalToMicroseconds(const struct timeval& tv)
{
    return tv.tv_sec * 1000000L + tv.tv_usec;
}

bool VCCM_IsHandoverPrepFailedCellByCgi(callInfo_type &rCall, cgi_type cgi, uint8_t ratType)
{
    AUTO_TRACE_FUNC;

    failedCellInfo_type *pFailedCell = (ratType == ci_eutra) ? rCall.hoFailCellList.eutraCell : rCall.hoFailCellList.nrCell;

    struct timeval currentTime;
    if (ComTimeUtil::get_current_time(currentTime) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "(TSEL) check ComTimeUtil::get_current_time ERROR\n");
        return false;
    }

    uint16_t timeVal = fnVCCB_GetHoPrepFailedTimer(rCall, rCall.servCellNum);
    if (not timeVal)
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "(TSEL) check fnVCCB_GetHoPrepFailedTimer (timeVal=0)\n");
        return false;
    }

    for (uint8_t idx = 0; idx < MAX_HO_FAILED_CALL_COUNT; idx++)
    {
        failedCellInfo_type *pCell = &pFailedCell[idx];
        if (pCell->usage != CI_use) continue;

        if (FnVCCB_CheckCgiIdentical(&pCell->cgi, &cgi))
        {
            long currentMicroTime = timevalToMicroseconds(currentTime);
            long failMicroTime = timevalToMicroseconds(pCell->failTime);

            if (DBG->flag.logHoFailedCellList)
            {
                VCCB_PRINT_CALL_INFORMATIVE(&rCall, "(TSEL) %s failedCell condition (idx:%d)(ncgi:%x,%llu/cTime:%ld,%ld/fTime:%ld.%ld/tThr:%d)\n",
                     ratType == ci_eutra ? "EUTRA" : "NR", idx, cgi.plmn.longId, 1ULL * cgi.ci, currentTime.tv_sec, currentTime.tv_usec,
                     pCell->failTime.tv_sec, pCell->failTime.tv_usec, timeVal);
            }

            if (currentMicroTime > failMicroTime)
            {
                long elapsedMicroTime = currentMicroTime - failMicroTime;

                if (elapsedMicroTime < (timeVal * 1000L))
                {
                    return true;
                }
                else
                {
                    pCell->usage = CI_no_use;
                    return false;
                }
            }
            else
            {
                pCell->usage = CI_no_use;
                return false;
            }
        }
    }

    return false;
}

bool VCCM_InterRatHandoverPrepFailedCell(callInfo_type &rCall, const nbrEnbCellInfo_type &rNbrEnbCell)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VAL(rCall.gnbNum, MAX_GNB_PER_SYS, false);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[rCall.gnbNum];

    cgi_type ecgi = {};
    ecgi.ci = FnVCCB_GetEcgiForNonNeighborHandover(
            rNbrEnbCell, static_cast<enumSmallCellEnbIdLength_type>(pGnb->cfg.gnbMobilityConfig.smallCellEnbIdLength));
    ecgi.plmn.longId = rNbrEnbCell.plmn.longId;

    return VCCM_IsHandoverPrepFailedCellByCgi(rCall, ecgi, ci_eutra);
}

bool VCCM_IntraNrHandoverPrepFailedCell(callInfo_type &rCall, const nbrGnbCellInfo_type &rNbrGnbCell)
{
    AUTO_TRACE_FUNC;

    cgi_type ncgi = {};
    ncgi.ci = VLIB_GnbIdCellId2NrCellId(&rNbrGnbCell.globalGnbId.gnbId, rNbrGnbCell.cellId);
    ncgi.plmn.longId = rNbrGnbCell.globalGnbId.plmn.longId;

    return VCCM_IsHandoverPrepFailedCellByCgi(rCall, ncgi, ci_nr);
}

// }}}

/****************************************************************************
 * handle CHO failed Cell
****************************************************************************/
// {{{
/****************************************************
 * @brief      Initialize Conditional HO BlockList
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
void FnVCCB_InitCHOBlockList(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    int cellIdx;

    if (ptCi->condHoInfo.currentCi == ptCi->nRCGI.ci) return;

    for (cellIdx = 0; cellIdx < MAX_CHO_BLOCKED_CELL_COUNT; cellIdx++)
    {
        ptCi->CHOBlockList.blockedCell[cellIdx].usage = CI_no_use;
    }

    VCCB_PRINT_CALL_HANDOVER_FAILURE(ptCi, "(*CHO) BlockList is cleared!!\n");

    return;
}  // }}}

/****************************************************
 * @brief      Store Conditional Handover Blocked Cell Info
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
void FnVCCB_UpdateCHOBlockedCellInfo(callInfo_type *ptCi)
{  // {{{

    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    failedCellInfo_type *pFailedCell = &ptCi->CHOBlockList.blockedCell[0];

    struct timeval currentTime;
    if (ComTimeUtil::get_current_time(currentTime) < 0)
    {
        VCCB_PRINT_ERROR("(*CHO) ComTimeUtil::get_current_time ERROR in %s\n", __FUNCTION__);
        return;
    }

    if (ERROR == FnVCCB_storeFailedCellInfo(ptCi, MAX_CHO_BLOCKED_CELL_COUNT, currentTime, pFailedCell))
    {
        VCCB_PRINT_CALL_HANDOVER_FAILURE(ptCi, "(*CHO) FnVCCB_storeFailedCellInfo Fail in %s!!", __FUNCTION__);
        return;
    }

    VCCB_PRINT_CALL_HANDOVER_FAILURE(ptCi, "(*CHO) Register cell(cgi:%X/%llu) in CHO Blocklist\n",
        pFailedCell->cgi.plmn.longId, 1ULL * pFailedCell->cgi.ci);
    return;
}  // }}}

/****************************************************
 * @brief      Check Conditional Handover Blocked Cell For cgi
 * @param[in]  ptCi : call information / pCgi : nbrGnbCell nrcgi
 * @return     bool
 ****************************************************/
bool FnVCCB_IsCHOBlockedCellByCgi(callInfo_type *ptCi, cgi_type *pCgi)
{  // {{{

    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pCgi, false);

    failedCellInfo_type *pBlockedCell = NULL;
    pBlockedCell = &ptCi->CHOBlockList.blockedCell[0];

    if (true == FnVCCB_IsFailedCellByCgi(ptCi, MAX_CHO_BLOCKED_CELL_COUNT, pCgi, pBlockedCell))
    {
        VCCB_PRINT_CALL_HANDOVER_FAILURE(
            ptCi, "(*CHO) targetCellId(%llu,%X) is CHO Blocked Cell\n", 1ULL * pCgi->ci, pCgi->plmn.longId);
        return true;
    }

    return false;
}  // }}}

/****************************************************
 * @brief      Check Conditional Handover Blocked Cell For Cell
 * @param[in]  ptCi : call information / nbrGnbCellInfo_type
 * @return     bool
 ****************************************************/
bool FnVCCB_IsCHOBlockedCell(callInfo_type *ptCi, nbrGnbCellInfo_type *pNbrGnbCell)
{  // {{{

    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pNbrGnbCell, false);

    uint32_t cellIdx;

    cgi_type cgi;
    cgi.ci = VLIB_GnbIdCellId2NrCellId(&pNbrGnbCell->globalGnbId.gnbId, pNbrGnbCell->cellId);
    plmnId_type *pPlmnId = &cgi.plmn;

    for (cellIdx = 0; cellIdx < MAX_PLMN_INDEX; cellIdx++)
    {
        if (N_EQUIP == pNbrGnbCell->cellPlmnInfo[cellIdx].shmStatus) continue;

        pPlmnId->longId = pNbrGnbCell->cellPlmnInfo[cellIdx].longId;
        if (true == FnVCCB_IsCHOBlockedCellByCgi(ptCi, &cgi))
        {
            return true;
        }
    }

    return false;
}  // }}}
// }}}

/****************************************************************************
 * handle LTM block cell
****************************************************************************/
void FnVCCB_InitLtmBlockList(callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;
    
    HoFailedCellManager manager(rCall, FAILED_CELL_LIST_TYPE_LTM);
    manager.InitList();
}

void FnVCCB_AddLtmBlockedCell(callInfo_type &rCall, const cgi_type& tgtCellCgi)
{
    AUTO_TRACE_FUNC;
    
    HoFailedCellManager manager(rCall, FAILED_CELL_LIST_TYPE_LTM, tgtCellCgi);
    manager.updateFailedCell();
}

bool FnVCCB_IsLtmBlockedCell(callInfo_type &rCall, const cgi_type& tgtCellCgi)
{
    AUTO_TRACE_FUNC;
    
    HoFailedCellManager manager(rCall, FAILED_CELL_LIST_TYPE_LTM, tgtCellCgi);
    return manager.isFailedCell();
}
