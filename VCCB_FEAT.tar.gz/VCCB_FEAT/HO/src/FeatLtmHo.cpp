/**
 * @file        FeatLtmHo.cpp
 * @brief       This function provides a function for controlling the operation of the Mobility Feature for the SA UE.
 */

#include "FeatLtmHo.h"
#include "LtmBufferManager.h"

#include "FeatCommon.h"
#include "FeatCallInfo.h"
#include "FeatCallProc.h"
#include "FeatMeasurements.hpp"
#include "FeatMeasurementsNRRRCMake.hpp"
#include "FeatHo.h"
#include "FeatCa.hpp"

#include "ComInclude.h"
#include "ComLibUtility.h"
#include "ComTimeUtil.h"

#include "StateCommon.h"
#include "StateMeasurements.h"
#include "StateSaHo.h"

#include "MsgE1apSend.h"
#include "MsgXnapSend.h"
#include "MsgF1apSend.h"

#include "MsgF1apStore.h"
#include "MsgNmbSend.h"

#include "nrrrcUnpack.h"

#include "ComAsnUtil.hpp"  // for asn::util

// wrapper API
void FnVCCB_initLtmPrepProcTempDb(callInfo_type &rCall)
{
    LtmBufferManager::getInstance().initLtmPrepProcTempDb(rCall);
}

int16_t FnVCCB_StoreLtmCellGroupConfigAndResetCall(callInfo_type &rCall, uint16_t ltmCellIdx, msgContainer_type &rCellGroup)
{
    LtmBufferManager::getInstance().storeCellGroupConfig(rCall, ltmCellIdx, rCellGroup);
    
    //save the ltm cell group and initialize ptCi->cellGroup DB;
    rCellGroup.numocts = 0;

    return GOOD;
}

int16_t FnVCCB_StoreLtmSourceCellGroupConfig(callInfo_type &rCall, msgContainer_type &rCellGroup)
{
    return LtmBufferManager::getInstance().storeCellGroupConfig(rCall, MAX_NUM_LTM_CELLS, rCellGroup);
}

int16_t FnVCCB_GetStoredCellGroupConfig(callInfo_type &rCall, uint16_t ltmCellIdx, msgContainer_type &rCellGroup)
{
    return LtmBufferManager::getInstance().getStoredCellGroupConfig(rCall, ltmCellIdx, rCellGroup);
}

int16_t FnVCCB_GetStoredSourceCellGroupConfig(callInfo_type &rCall, msgContainer_type &rCellGroup)
{
    return LtmBufferManager::getInstance().getStoredCellGroupConfig(rCall, MAX_NUM_LTM_CELLS, rCellGroup);
}

void FnVCCB_ShowStoredLtmCellGroupConfig(callInfo_type &rCall)
{
    LtmBufferManager::getInstance().showStoredCellGroupConfig(rCall);
}

int16_t FnVCCB_StoreLtmReconfig(callInfo_type &rCall, uint16_t ltmCellIdx, msgContainer_type &rReconfig)
{
    return LtmBufferManager::getInstance().storeLtmReconfig(rCall, ltmCellIdx, rReconfig);
}

int16_t FnVCCB_GetStoredLtmReconfig(callInfo_type &rCall, uint16_t ltmCellIdx, NRRRC__octet1_10 &rNrrrcOctct)
{
    return LtmBufferManager::getInstance().getStoredLtmReconfig(rCall, ltmCellIdx, rNrrrcOctct);
}

uint16_t FnVCCB_GetLtmNumDu(callInfo_type &rCall, uint16_t ltmCellIdx)
{
    return LtmBufferManager::getInstance().get_num_du(rCall, ltmCellIdx);
}

int16_t FnVCCB_InitLtmMaintainDb(callInfo_type &rCall, uint16_t ltmCellIdx)
{
    return LtmBufferManager::getInstance().init_ltmMaintainDb(rCall, ltmCellIdx);
}

int16_t FnVCCB_StoreF1_EarlySyncInformation(
    callInfo_type &rCall, uint16_t ltmCellIdx, F1_EarlySyncInformation *ptEarlySyncInfo)
{
    return LtmBufferManager::getInstance().store_F1_EarlySyncInformation(rCall, ltmCellIdx, ptEarlySyncInfo);
}

int16_t FnVCCB_StoreF1_LTMConfiguration(
    callInfo_type &rCall, uint16_t ltmCellIdx, F1_LTMConfiguration *ptLtmConfiguration)
{
    return LtmBufferManager::getInstance().store_F1_LTMConfiguration(rCall, ltmCellIdx, ptLtmConfiguration);
}

int16_t FnVCCB_GetStored_F1_LTMCFRAResourceConfig(
    callInfo_type &rCall, uint16_t ltmCellIdx, F1_LTMCFRAResourceConfig &rConfig)
{
    return LtmBufferManager::getInstance().getStored_F1_LTMCFRAResourceConfig(rCall, ltmCellIdx, rConfig);
}

int16_t FnVCCB_GetStored_F1_TCIStatesConfigurationsList(
    callInfo_type &rCall, uint16_t ltmCellIdx, F1_TCIStatesConfigurationsList &rConfig)
{
    return LtmBufferManager::getInstance().getStored_F1_TCIStatesConfigurationsList(rCall, ltmCellIdx, rConfig);
}

int16_t FnVCCB_GetStored_F1_EarlyULSyncConfig__RachConfiguration(
    callInfo_type &rCall, uint16_t ltmCellIdx, F1_RACHConfiguration &rConfig)
{
    return LtmBufferManager::getInstance().getStored_F1_EarlyULSyncConfig__RachConfiguration(
        rCall, ltmCellIdx, rConfig.length, rConfig.value);
}

int16_t FnVCCB_GetStored_NRRRC_EarlyUL_SyncConfig_r18(
    callInfo_type &rCall, uint16_t ltmCellIdx, NRRRC__octet1_10 &rConfig)
{
    return LtmBufferManager::getInstance().getStored_F1_EarlyULSyncConfig__RachConfiguration(
        rCall, ltmCellIdx, rConfig.length, rConfig.value);
}

int16_t FnVCCB_GetStored_NRRRC_LTM_SSB_Config_r18(
    callInfo_type &rCall, uint16_t ltmCellIdx, NRRRC_LTM_SSB_Config_r18 &rConfig)
{
    return LtmBufferManager::getInstance().getStored_NRRRC_LTM_SSB_Config_r18(rCall, ltmCellIdx, rConfig);
}

int16_t FnVCCB_GetStored_NRRRC_LTM_TCI_Info_r18(
    callInfo_type &rCall, uint16_t ltmCellIdx, NRRRC_LTM_TCI_Info_r18 &rConfig)
{
    return LtmBufferManager::getInstance().getStored_NRRRC_LTM_TCI_Info_r18(rCall, ltmCellIdx, rConfig);
}

int16_t FnVCCB_GetStored_F1_EarlyULSyncConfig__LtmGnbDusList(callInfo_type &rCall, uint16_t ltmCellIdx,
    struct F1_LTMgNB_DU_IDs_PreambleIndexList_ (&rDuList)[MAX_NUM_LTM_DUS],
    struct F1_PreambleIndexList_ (&rPreambleIndexListPerDu)[MAX_NUM_LTM_DUS][MAX_NUM_LTM_CELLS])
{
    return LtmBufferManager::getInstance().getStored_F1_EarlyULSyncConfig__LtmGnbDusList(
        rCall, ltmCellIdx, rDuList, rPreambleIndexListPerDu);
}

LtmProcRelatedData_type *FnVCCB_GetLtmProcRelatedDataForCall(const callInfo_type &rCall)
{
    return LtmBufferManager::getInstance().getLtmProcRelatedDataForCall(rCall);
}

void FnVCCB_InitLtmBufferMapAll()
{
    LtmBufferManager::getInstance().cleanupAll();
}

void FnVCCB_InitLtmBufferMapOfCall(callInfo_type &rCall)
{
    LtmBufferManager::getInstance().cleanupCall(rCall);
    // LtmBufferManager::getInstance().initLtmBufferMapOfCall(rCall);
}

void FnVCCB_LtmSwitchover(callInfo_type &rCall)
{
    if (FnVCCB_IsSetupedLtmCell(&rCall))
    {
        rCall.ltmUeInfo.flag.switchOver = TRUE;
        for (auto ltmCell : rCall.ltmUeInfo.cellList)
        {
            VCCB_CLEAR_TIMER(&ltmCell.handle.ltmCellReleaseTimer, INIT_TIMER);
        }
    }
}

void FnVCCB_PrintLtmBufferAllThreadInfo(void)
{
    LtmBufferManager::getInstance().printAllThreadInfoForDsh();
}

void FnVCCB_PrintLtmBufferPoolStatus(void)
{
    LtmBufferManager::getInstance().printPoolStatusForDsh();
}

// }}}
// temp DB handler end   ---------

/****************************************************
 * @brief      Get Ltm Cell Information For Index
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ltmCellIdx : candidate index of array / uint8_t
 * @return     return address
 ****************************************************/
ltmCellInfo_type *FnVCCB_GetLtmCellInfoForIndex(callInfo_type *ptCi, uint8_t ltmCellIdx)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptCi);

    if (MAX_NUM_LTM_CELLS <= ltmCellIdx)
    {
        return nullptr;
    }

    ltmCellInfo_type *ptLtmCell = &ptCi->ltmUeInfo.cellList[ltmCellIdx];

    if (!IS_VALID_NODE(LTM_CELL_NODE, ptCi, ptLtmCell))
    {
        return nullptr;
    }

    return ptLtmCell;
}  // }}}

/****************************************************
 * @brief      Get Ltm Cell Information For Index
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ltmCellIdx : candidate index of array / uint8_t
 * @return     return address
 ****************************************************/
const ltmCellInfo_type *FnVCCB_GetLtmCellInfoForIndex(const callInfo_type *ptCi, uint8_t ltmCellIdx)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptCi);

    if (MAX_NUM_LTM_CELLS <= ltmCellIdx)
    {
        return nullptr;
    }

    const ltmCellInfo_type *ptLtmCell = &ptCi->ltmUeInfo.cellList[ltmCellIdx];

    if (!IS_VALID_NODE(LTM_CELL_NODE, ptCi, ptLtmCell))
    {
        return nullptr;
    }

    return ptLtmCell;
}  // }}}

ltmCellInfo_type *FnVCCB_GetLtmCellInfoForPci(callInfo_type &rCall, uint16_t pci)
{  // {{{
    AUTO_TRACE_FUNC;

    for (uint8_t ltmIdx = 0; ltmIdx < MAX_NUM_LTM_CELLS; ltmIdx++)
    {
        ltmCellInfo_type *pLtmCellInfo = FnVCCB_GetLtmCellInfoForIndex(&rCall, ltmIdx);
        if (pLtmCellInfo == nullptr) continue;
        if (pLtmCellInfo->data.pci == pci) return pLtmCellInfo;
    }
    return nullptr;
}  // }}}

const char *FnVCCB_GetStrLtmCellAction(ltmCellAction_type Action)
{ // {{{
    switch (Action)
    {
        case ltm_init:
            return "init";
        case ltm_selectAsTargetCell:
            return "selectAsTargetCell";
        case ltm_DuIsOngoing:
            return "DuIsOngoing";
        case ltm_DuIsDone:
            return "DuIsDone";
        case ltm_PropIsOnging:
            return "PropIsOnging";
        case ltm_PropIsDone:
            return "PropIsDone";
        case ltm_RrcIsOngoing:
            return "RrcIsOngoing";
        case ltm_RrcIsDone:
            return "RrcIsDone";
        case ltm_installed:
            return "installed";
        case ltm_selectAsExecCell:
            return "selectAsExecCell";
        default:
            return "not defined";
    }
} // }}}

/****************************************************
 * @brief      Change the status of Ltm Cell Information.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ltmCellIdx : candidate index of array / uint16_t
 * @param[in]  newStatus   : Enter the Action value to be updated. / enumCommonStatus_type
 * @return     void
 ****************************************************/
void FnVCCB_SetLtmCellStatus(callInfo_type *ptCi, uint8_t ltmCellIdx, enumCommonStatus_type newStatus)
{  // {{{
    VALID_E_POINT_CHECK_VOID(ptCi);

    ltmCellInfo_type *ptLtmCell = FnVCCB_GetLtmCellInfoForIndex(ptCi, ltmCellIdx);
    VALID_E_POINT_CHECK_VOID(ptLtmCell);

    // no action
    if (ptLtmCell->handle.ltmStatus == newStatus) return;

    // Use same debug flag with status
    if (DBG->flag.statusDebug)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "LTM(idx:%d, cgi:%X/%llu) Status is update (%d:%s -> %d:%s)!\n", ltmCellIdx,
            ptLtmCell->data.nrcgi.plmn.longId, ptLtmCell->data.nrcgi.ci * 1ULL,
            (enumCommonStatus_type)ptLtmCell->handle.ltmStatus,
            FnVCCB_GetStrCommonStatus((enumCommonStatus_type)ptLtmCell->handle.ltmStatus), newStatus,
            FnVCCB_GetStrCommonStatus(newStatus));
    }

    ptLtmCell->handle.ltmStatus = newStatus;
}  // }}}

/****************************************************
 * @brief      Change the action of Ltm Cell Information.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ltmCellIdx : candidate index of array / uint16_t
 * @param[in]  newAction   : Enter the Action value to be updated. / ltmCellAction_type
 * @return     void
 ****************************************************/
void FnVCCB_SetLtmCellAction(callInfo_type *ptCi, uint8_t ltmCellIdx, ltmCellAction_type newAction)
{  // {{{
    VALID_E_POINT_CHECK_VOID(ptCi);

    ltmCellInfo_type *ptLtmCell = FnVCCB_GetLtmCellInfoForIndex(ptCi, ltmCellIdx);
    VALID_E_POINT_CHECK_VOID(ptLtmCell);

    // no action
    if (ptLtmCell->handle.ltmAction == newAction) return;

    // Use same debug flag with status
    if (DBG->flag.logLtm)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "LTM(idx:%d, cgi:%X/%llu) Action is update (%d:%s -> %d:%s)!\n", ltmCellIdx,
            ptLtmCell->data.nrcgi.plmn.longId, ptLtmCell->data.nrcgi.ci * 1ULL,
            (ltmCellAction_type)ptLtmCell->handle.ltmAction,
            FnVCCB_GetStrLtmCellAction((ltmCellAction_type)ptLtmCell->handle.ltmAction), newAction,
            FnVCCB_GetStrLtmCellAction(newAction));
    }

    ptLtmCell->handle.ltmAction = newAction;
}  // }}}

/****************************************************
 * @brief      This is an operation for resource initialization and send Ltm release to UE.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
VCCB_STATIC_INLINE
void FnVCCB_ClearLtmRrcActivationFlag(callInfo_type *ptCi)
{ // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    for (uint8_t ltmCellIdx = 0; ltmCellIdx < MAX_NUM_LTM_CELLS; ltmCellIdx++)
    {
        ltmCellInfo_type *ptLtmCell = FnVCCB_GetLtmCellInfoForIndex(ptCi, ltmCellIdx);

        if (ptLtmCell == NULL) continue;

        ptLtmCell->handle.flag.rrc_activation_flag = FALSE;
    }
} // }}}

/****************************************************
 * @brief      Defines the action when the Ltm Handover receives Complete from other than the specified state
 *machine.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
void FnVCCB_AppendLtmConfig_r18_ForReconfigurationComplete(callInfo_type *ptCi)
{ // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    for (uint8_t ltmCellIdx = 0; ltmCellIdx < MAX_NUM_LTM_CELLS; ltmCellIdx++)
    {
        ltmCellInfo_type *ptLtmCell = FnVCCB_GetLtmCellInfoForIndex(ptCi, ltmCellIdx);

        if (ptLtmCell == NULL) continue;

        switch (ptLtmCell->handle.ltmStatus)
        {
            case Common_Release:
                ptLtmCell->handle.flag.rrc_activation_flag = FALSE;
                break;

            case Common_Setup:
                ptLtmCell->handle.flag.rrc_activation_flag = TRUE;
                break;

            default:
                break;
        }
    }
} // }}}

/****************************************************
 * @brief      This function deincreases numOfCellList.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
VCCB_STATIC_INLINE void FnVCCB_NumOfLtmCellList_Up(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->ltmUeInfo.numOfCellList < MAX_NUM_LTM_CELLS) ptCi->ltmUeInfo.numOfCellList++;
}  // }}}

/****************************************************
 * @brief      This function deincreases numOfCellList.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
VCCB_STATIC_INLINE void FnVCCB_NumOfLtmCellList_Down(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->ltmUeInfo.numOfCellList > 0) ptCi->ltmUeInfo.numOfCellList--;
}  // }}}

/****************************************************
 * @brief      This is the action to process the Timer used for Ltm Handover.
 * @param[in]  ptLtmCell : Ltm cell information / ltmCellInfo_type
 * @param[in]  option : timer for Ltm cell / enumTimerType
 ****************************************************/
void FnVCCB_CancelLtmCellTimer(ltmCellInfo_type *ptLtmCell, enumTimerType option)
{ // {{{
    VALID_E_POINT_CHECK_VOID(ptLtmCell);

    VCCB_CLEAR_TIMER(&ptLtmCell->handle.ltmCellReleaseTimer, option);
} // }}}

/****************************************************
 * @brief      Free Ltm Cell Information For Index
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ltmCellIdx : candidate index of array / uint16_t
 * @return     void
 ****************************************************/
void FnVCCB_FreeLtmCellInfoForIndex(callInfo_type *ptCi, uint8_t ltmCellIdx)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    ltmCellInfo_type *ptLtmCell = FnVCCB_GetLtmCellInfoForIndex(ptCi, ltmCellIdx);

    if (ptLtmCell == NULL)
    {
        return;
    }

    FnVCCB_NumOfLtmCellList_Down(ptCi);

    // Initialize cell info as defensive coding (memory initialization)
    // Note: This is not strictly necessary since FnVCCB_InitLtmCellInfo is always called
    // when allocating a new cell, but it ensures memory safety and prevents stale data.
    // This also cancels the timer (INIT_TIMER) and sets usage to CI_no_use.
    FnVCCB_InitLtmCellInfo(ptLtmCell, ltmCellIdx);

    // Remove from buffer manager
    LtmBufferManager::getInstance().removeCandidateCell(*ptCi, ltmCellIdx);

    return;
}  // }}}

/****************************************************
 * @brief      This function is responsible for the Release Process in the 'FnVCCB_LtmCellConfigCommit'
 *function.
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  ltmCellIdx : index of Ltm cell information / uint8_t
 * @return     void
 ****************************************************/
VCCB_STATIC_INLINE
void FnVCCB_LtmCellConfigCommit_ReleaseProcess(callInfo_type *ptCi, ltmCellInfo_type *ptLtmCell)
{ // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptLtmCell);

    // TBD:Stat

    // Clear Ltm Cell DB.
    FnVCCB_FreeLtmCellInfoForIndex(ptCi, ptLtmCell->handle.ltmCellIdx);
} // }}}

/****************************************************
 * @brief      This function is responsible for the Setup Process in the 'FnVCCB_LtmCellConfigCommit' function.
 * @param[in]  ptCi       : call information / callInfo_type
 * @param[in]  ptLtmCell : pointer of Ltm cell information / ltmCellInfo_type
 * @return     void
 ****************************************************/
VCCB_STATIC_INLINE
void FnVCCB_LtmCellConfigCommit_AddModProcess(callInfo_type *ptCi, ltmCellInfo_type *ptLtmCell)
{ // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptLtmCell);

    // Transition to Idle.
    FnVCCB_SetLtmCellStatus(ptCi, ptLtmCell->handle.ltmCellIdx, Common_Idle);
} // }}}

/****************************************************
 * @brief      This function performs the final application of Cell Configuration used for Ltm Handover.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
void FnVCCB_LtmCellConfigCommit(callInfo_type *ptCi)
{ // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (FnVCCB_IsEmptyLtmCell(ptCi)) return;

    for (uint8_t ltmCellIdx = 0; ltmCellIdx < MAX_NUM_LTM_CELLS; ltmCellIdx++)
    {
        ltmCellInfo_type *ptLtmCell = FnVCCB_GetLtmCellInfoForIndex(ptCi, ltmCellIdx);

        if (ptLtmCell == NULL) continue;

        switch (ptLtmCell->handle.ltmStatus)
        {
            case Common_FailToSetup:
            case Common_Release:
                FnVCCB_LtmCellConfigCommit_ReleaseProcess(ptCi, ptLtmCell);
                continue;

            case Common_Setup:
            case Common_Modify:
                FnVCCB_LtmCellConfigCommit_AddModProcess(ptCi, ptLtmCell);
                continue;
            default:
                continue;
        }
    }

    // All Ltm Cell Release Case
    // if (FnVCCB_IsEmptyLtmCell(ptCi))
    //{
    //    FnVCCB_InitializationChoDbForExecution(ptCi);
    //    FnVCCB_InitCondHoInfo(ptCi);
    //}
} // }}}

//------------------------------------------

/****************************************************
 * @brief      This function is the initialization content for the operation related to Ltm Handover when RACH
 *occurs.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
void FnVCCB_InitializationMultiTargetDbForExecution(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // TODO: need to review init item...

}  // }}}

/****************************************************
 * @brief      Init Ltm Cell Information
 * @param[in]  ptLtmCell : Ltm cell information / ltmCellInfo_type
 * @return     void
 ****************************************************/
void FnVCCB_InitLtmCellInfo(ltmCellInfo_type *ptLtmCell, uint8_t ltmCellIdx, enumTimerType option)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptLtmCell);

    // candidate-cell-release-timer-source
    // candidate-cell-release-timer-target
    FnVCCB_CancelLtmCellTimer(ptLtmCell, option);

    memset(ptLtmCell, 0xFF, sizeof(*ptLtmCell));

    ptLtmCell->handle.usage = CI_no_use;
    ptLtmCell->handle.ltmCellIdx = ltmCellIdx & e_BitMask_7bit;
    ptLtmCell->handle.ltmStatus = Common_Setup;
    ptLtmCell->handle.ltmAction = ltm_init;
    ptLtmCell->handle.statCause = CHO_TYPE_MAX;  // TODO: not yet

    // Fill tnl
    for (auto &rDrb : ptLtmCell->data.tnlAddr.drb)
    {
        rDrb.f1uDlInfo.fNeedModify = 0;
        rDrb.f1uDlInfo.numTLAbit = 0;
    }

    // Fill Flag
    memset(&ptLtmCell->handle.flag, 0x00, sizeof(ptLtmCell->handle.flag));

}  // }}}

/****************************************************
 *
 * @brief      Initialize Ltm UE Info DB for Cell Switch phase.
 * @param[in]  ptCi : call information / callInfo_type
 ****************************************************/
void FnVCCB_InitLtmUeInfoForCellSwitch(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    auto *ptInfo = &ptCi->ltmUeInfo;

    memset(&ptInfo->targetCgi, 0, sizeof(ptInfo->targetCgi));
    ptInfo->cellSwitchFlag.clearFlag = 0;
}  // }}}

/****************************************************
 *
 * @brief      Initialize Ltm Handover DB.
 * @param[in]  ptCi : call information / callInfo_type
 ****************************************************/
void FnVCCB_ClearLtmUeInfo(callInfo_type *ptCi, enumTimerType option)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    auto *ptInfo = &ptCi->ltmUeInfo;

    uint8_t ltmCellIdx = 0;

    ptInfo->numOfCellList = 0;

    // Fill Flag
    memset(&ptInfo->flag, 0x00, sizeof(ptInfo->flag));
    memset(&ptInfo->targetCgi, 0, sizeof(ptInfo->targetCgi));
    ptInfo->cellSwitchFlag.clearFlag = 0;
    ptInfo->respFlag = 0;
    ptInfo->currCandidateCellIdx = 0xFF;
    ptInfo->ptProcRelatedData = nullptr;
    ptInfo->svcGrpId = MAX_SVC_GROUP_NUM;

    for (ltmCellIdx = 0; ltmCellIdx < MAX_NUM_LTM_CELLS; ltmCellIdx++)
    {
        ltmCellInfo_type *ptTargetCell = &ptInfo->cellList[ltmCellIdx];

        FnVCCB_InitLtmCellInfo(ptTargetCell, ltmCellIdx, option);
    }
    FnVCCB_InitLtmBufferMapOfCall(*ptCi);
}  // }}}

void FnVCCB_InitLtmUeInfo(callInfo_type *ptCi)
{
    FnVCCB_ClearLtmUeInfo(ptCi, INIT_TIMER);
}

/****************************************************
 * @brief      Get Ltm Cell Information For CGI
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  findCgi : find Cgi Information / cgi_type
 * @return     return address
 ****************************************************/
ltmCellInfo_type *FnVCCB_GetLtmCellInfoFromCGI(callInfo_type *ptCi, cgi_type findCgi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptCi);

    for (uint8_t ltmCellIdx = 0; ltmCellIdx < MAX_NUM_LTM_CELLS; ltmCellIdx++)
    {
        auto *ptTargetCell = FnVCCB_GetLtmCellInfoForIndex(ptCi, ltmCellIdx);

        if (ptTargetCell == NULL) continue;

        if (FnVCCB_CheckCgiIdentical(&ptTargetCell->data.nrcgi, &findCgi))
        {
            return ptTargetCell;
        }
    }

    return NULL;
}  // }}}


/****************************************************
 * @brief      Get Ltm Cell Information For cellNum
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  cellNum : cell number
 * @return     return address
 ****************************************************/
ltmCellInfo_type *FnVCCB_GetLtmCellInfoFromCellNum(callInfo_type *ptCi, CellNum_type cellNum)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptCi);

    for (uint8_t ltmCellIdx = 0; ltmCellIdx < MAX_NUM_LTM_CELLS; ltmCellIdx++)
    {
        auto *ptTargetCell = FnVCCB_GetLtmCellInfoForIndex(ptCi, ltmCellIdx);

        if (ptTargetCell == NULL) continue;

        if (ptTargetCell->data.cellSelection.cellNum == cellNum)
        {
            return ptTargetCell;
        }
    }

    return NULL;
}  // }}}

/****************************************************
 * @brief      Get Ltm Cell Information For CGI
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  findCgi : find Cgi Information / cgi_type
 * @return     return address
 ****************************************************/
ltmCellInfo_type *FnVCCB_GetLtmCellInfoFromLtmAction(callInfo_type *ptCi, ltmCellAction_type ltmAction)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptCi);

    for (uint8_t ltmCellIdx = 0; ltmCellIdx < MAX_NUM_LTM_CELLS; ltmCellIdx++)
    {
        auto *ptTargetCell = FnVCCB_GetLtmCellInfoForIndex(ptCi, ltmCellIdx);

        if (ptTargetCell == NULL) continue;

        if (ptTargetCell->handle.ltmAction == ltmAction)
        {
            return ptTargetCell;
        }
    }

    return NULL;
}  // }}}

/****************************************************
 * @brief      Get Ltm Cell Information For flag
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  findCgi : find Cgi Information / cgi_type
 * @return     return address
 ****************************************************/
ltmCellInfo_type *FnVCCB_GetLtmCellInfoFromFlag(callInfo_type *ptCi, uint8_t flag)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptCi);

    for (uint8_t ltmCellIdx = 0; ltmCellIdx < MAX_NUM_LTM_CELLS; ltmCellIdx++)
    {
        auto *ptTargetCell = FnVCCB_GetLtmCellInfoForIndex(ptCi, ltmCellIdx);

        if (ptTargetCell == NULL) continue;

        if (ptTargetCell->handle.flag_uValue & flag)
        {
            return ptTargetCell;
        }
    }

    return NULL;
}  // }}}

/****************************************************
 * @brief      Alloc Ltm Cell Information For CGI
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  cgi : Cgi Information / cgi_type
 * @return     return  index of arrary / uint8_t
 ****************************************************/
uint8_t FnVCCB_AllocLtmCellInfoForCGI(callInfo_type *ptCi, cgi_type cgi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_NUM_LTM_CELLS);

    if (FnVCCB_GetLtmCellInfoFromCGI(ptCi, cgi) != NULL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Double Allocation Request(CGI:%X/%llu)\n", cgi.plmn.longId, cgi.ci * 1ULL);
        return MAX_NUM_LTM_CELLS;
    }

    for (uint8_t ltmCellIdx = 0; ltmCellIdx < MAX_NUM_LTM_CELLS; ltmCellIdx++)
    {
        int cause = e_Valid_Ok;
        auto *ptTargetCell = &ptCi->ltmUeInfo.cellList[ltmCellIdx];

        if (IS_VALID_NODE_WITH_CAUSE(LTM_CELL_NODE, ptCi, ptTargetCell, &cause)) continue;

        // allow only no_use case
        if (cause != e_Invalid_no_use)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "LTM_CELL_NODE[%d] is unknown cause, Need Check(%d)\n", ltmCellIdx, cause);
            continue;
        }

        FnVCCB_InitLtmCellInfo(ptTargetCell, ltmCellIdx);

        ptTargetCell->data.nrcgi = cgi;

        FnVCCB_NumOfLtmCellList_Up(ptCi);

        ptTargetCell->handle.usage = CI_use;

        // TODO: need to make it as function
        // It should be located after usage due to validation check.
        FnVCCB_SetLtmCellAction(ptCi, ltmCellIdx, ltm_selectAsTargetCell);

        if (FnVCCB_InitLtmMaintainDb(*ptCi, ltmCellIdx) == ERROR) return MAX_NUM_LTM_CELLS;

        return ltmCellIdx;
    }

    VCCB_PRINT_CALL_ERROR(ptCi, "Max Over Allocation Request(CGI:%X/%llu)\n", cgi.plmn.longId, cgi.ci * 1ULL);
    return MAX_NUM_LTM_CELLS;
}  // }}}

/****************************************************
 * @brief      Alloc Ltm Cell Information For CGI
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  cgi : Cgi Information / cgi_type
 * @return     return  index of arrary / uint8_t
 ****************************************************/
void FnVCCB_FreeLtmCellInfoForCGI(callInfo_type &rCall, cgi_type cgi)
{  // {{{
    AUTO_TRACE_FUNC;

    ltmCellInfo_type *pLtmCandidate = FnVCCB_GetLtmCellInfoFromCGI(&rCall, cgi);
    if (pLtmCandidate == nullptr)
    {
        VCCB_PRINT_CALL_ERROR((&rCall), "There is no candidate with(CGI:%X/%llu)\n", cgi.plmn.longId, cgi.ci * 1ULL);
        return;
    }

    uint8_t ltmCellIdx = pLtmCandidate->handle.ltmCellIdx;
    FnVCCB_FreeLtmCellInfoForIndex(&rCall, ltmCellIdx);
}  // }}}

/****************************************************
 * @brief      This function performs the final application of Cell Configuration used for Ltm Handover.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
void FnVCCB_LtmPrepConfigCommit(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // not yet
    if (FnVCCB_IsEmptyLtmCell(ptCi)) return;

    for (uint8_t ltmCellIdx = 0; ltmCellIdx < MAX_NUM_LTM_CELLS; ltmCellIdx++)
    {
        auto *ptTargetInfo = FnVCCB_GetLtmCellInfoForIndex(ptCi, ltmCellIdx);

        if (ptTargetInfo == NULL) continue;

        switch (ptTargetInfo->handle.ltmAction)
        {
            // case ltm_PropIsDone: // need to remove
            case ltm_RrcIsDone:
                FnVCCB_SetLtmCellAction(ptCi, ptTargetInfo->handle.ltmCellIdx, ltm_installed);
                continue;
            default:
                continue;
        }
    }

    // All Ltm Cell Release Case
    // if (FnVCCB_IsEmptyLtmCell(ptCi))
    //{
    //    FnVCCB_InitializationChoDbForExecution(ptCi);
    //    FnVCCB_InitCondHoInfo(ptCi);
    //}
}  // }}}

/****************************************************
 * @brief      This function executes LTM cell switch on RRC level
 * @param[in]       rCall:        call information / callInfo_type
 * @param[in]       rLtmCellInfo: cell switch target / ltmCellInfo_type
 * @return     void
 ****************************************************/
int16_t FnVCCB_procLtm_NRRRC_RrcReconfigurationComplete(callInfo_type &rCall, const ltmCellInfo_type &rLtmCellInfo)
{
    AUTO_TRACE_FUNC;

    const uint8_t candidateCellIdx = rLtmCellInfo.handle.ltmCellIdx;
    VCCB_CHECK_E_RANGE_AND_RETURN(candidateCellIdx, MAX_NUM_LTM_CELLS);
    VALID_E_POINT_CHECK_ERROR(rCall.ltmUeInfo.ptProcRelatedData);

    // measurements part of LTM cell switch execution
    if (!VCCB_CommitNrRrcMeasConfigUsingAltStructures(rCall,
            rCall.ltmUeInfo.ptProcRelatedData->measConf[candidateCellIdx],
            rCall.ltmUeInfo.ptProcRelatedData->measProc[candidateCellIdx],
            rCall.ltmUeInfo.ptProcRelatedData->mGapDuData[candidateCellIdx],
            rCall.ltmUeInfo.ptProcRelatedData->saMeas[candidateCellIdx]))
    {
        return ERROR;
    }

    rCall.ulGapFr2ConfigUe = rCall.ltmUeInfo.ptProcRelatedData->ulGapFr2ConfigDu[candidateCellIdx];

    return GOOD;
}

/****************************************************
 * @brief      This function provides the procedure to perform the Ltm Handover Execution procedure.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
int16_t FnVCCB_StartLtmHandoverExecutionProcedure(callInfo_type *ptCi)
{ // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // TODO: temp function
    FnVCCB_InitializationMultiTargetDbForExecution(ptCi);

    // Find the target from cgi
    ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromCGI(ptCi, ptCi->ltmUeInfo.targetCgi);
    if (ptTarget == NULL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "There is no CGI(%X/%llu)\n", ptCi->ltmUeInfo.targetCgi.plmn.longId,
            ptCi->ltmUeInfo.targetCgi.ci * 1ULL);
        return BREAK;
    }

    // trigger the execution
    const uint16_t targetCellNum = ptTarget->data.cellSelection.cellNum;
    const uint16_t targetCellBand = ptTarget->data.cellSelection.bandNr;
    auto hoInputDb = StartSaHandoverDb();
    
    return VHCM_StartSaHandover_IntragNB(ptCi, {targetCellNum, targetCellBand}, e_HoTrigger_LtmHandoverExec, hoInputDb);
} // }}}

bool FnVCCB_IsLtmReleaseCase(const callInfo_type &rCall)
{
    if (DBG->flag.ltm_replaceChoMrAsLtm == TRUE && rCall.stateCmd == IntraCellHO_cmd)
        return true;

    if (rCall.state == STATE_Ltm_Prep_RRC || rCall.state == STATE_Ltm_Prep_Cand)
    {
        // SVR26A FGR-BC0323
        // FR500: gNB-CU shall perform LTM release procedure when executing Intra-cell HO w/ key change for LTM configured UE
        if (rCall.stateCmd == IntraCellHO_cmd)
        {
            return true;
        }

        uint8_t numOfLtmActiveCandidates{};
        for (uint8_t idx = 0; idx < MAX_NUM_LTM_CELLS; idx++)
        {
            auto *ltmCell = FnVCCB_GetLtmCellInfoForIndex(&rCall, idx);
            if (ltmCell == nullptr) continue;
            if (ltmCell->handle.usage == CI_no_use) continue;
            if (ltmCell->handle.ltmStatus == Common_Release) continue;

            numOfLtmActiveCandidates++;
        }
        return (numOfLtmActiveCandidates == 1);  // it means that there is no ltm candidate cell without servingCell
    }
    else
    {
        // inter gnb handover hand in case.
        if (rCall.hoInfo.ltmReleaseRequired)
        {
            return true;
        }

        //intra gnb handover case or {intra-cell handover case @26A}
        return (rCall.ltmUeInfo.numOfCellList > 1 && (rCall.state == STATE_INTRA_DU_Execution || rCall.state == STATE_INTER_DU_Execution || rCall.stateCmd == IntraCellHO_cmd));
    }
}

bool FnVCCB_IsValidLtmDuUeId(callInfo_type &rCall, uint16_t endPointIdx, uint16_t duUeId)
{
    return (FnVCCB_GetLtmCellWithEndPointIdxAndDuUeId(rCall, endPointIdx, duUeId) != nullptr);
}

ltmCellInfo_type *FnVCCB_GetLtmCellWithEndPointIdxAndDuUeId(callInfo_type &rCall, uint16_t endPointIdx, uint16_t duUeId)
{  // {{{
    for (uint8_t ltmIdx = 0; ltmIdx < MAX_NUM_LTM_CELLS; ltmIdx++)
    {
        ltmCellInfo_type *ltmCell = FnVCCB_GetLtmCellInfoForIndex(&rCall, ltmIdx);
        if (ltmCell == nullptr) continue;
        if (ltmCell->data.cellSelection.cellNum == rCall.servCellNum) continue;
        if (ltmCell->handle.du.duUEid == duUeId && ltmCell->handle.du.f1Idx == endPointIdx)
        {
            return ltmCell;
        }
    }
    return nullptr;
}  // }}}

/****************************************************
 * @brief      Get Ltm Cell Information For CGI
 * @param[in]  ptCi : call information / callInfo_type
 * @param[in]  findCgi : find Cgi Information / cgi_type
 * @return     return address
 ****************************************************/
ltmCellInfo_type *FnVCCB_GetLtmCellInfoFromLtmActionAndF1Id(
    callInfo_type &rCall, ltmCellAction_type ltmAction, uint32_t f1apId)
{  // {{{
    AUTO_TRACE_FUNC;

    for (uint8_t ltmCellIdx = 0; ltmCellIdx < MAX_NUM_LTM_CELLS; ltmCellIdx++)
    {
        auto *ptTargetCell = FnVCCB_GetLtmCellInfoForIndex(&rCall, ltmCellIdx);

        if (ptTargetCell == NULL) continue;

        if (ptTargetCell->handle.ltmAction == ltmAction && ptTargetCell->handle.du.duUEid == f1apId)
        {
            return ptTargetCell;
        }
    }

    return nullptr;
}  // }}}

ltmCellInfo_type *FnVCCB_GetLtmCellInfoFromDuInfo(callInfo_type &rCall, uint16_t endPointIdx, uint32_t duId)
{  // {{{
    AUTO_TRACE_FUNC;

    for (uint8_t ltmCellIdx = 0; ltmCellIdx < MAX_NUM_LTM_CELLS; ltmCellIdx++)
    {
        auto *ptTargetCell = FnVCCB_GetLtmCellInfoForIndex(&rCall, ltmCellIdx);

        if (ptTargetCell == NULL) continue;

        if (ptTargetCell->handle.du.duUEid == duId && ptTargetCell->handle.du.f1Idx == endPointIdx)
        {
            return ptTargetCell;
        }
    }

    return nullptr;
}  // }}}

void FnVCCB_ClearLtmCellResponseFlag(callInfo_type &rCall, uint16_t endPointIdx, uint32_t duId)
{ // {{{
    for (uint8_t ltmIdx = 0; ltmIdx < MAX_NUM_LTM_CELLS; ltmIdx++)
    {
        ltmCellInfo_type *ltmCell = FnVCCB_GetLtmCellInfoForIndex(&rCall, ltmIdx);
        if (ltmCell == nullptr) continue;

        if (ltmCell->handle.du.duUEid == duId && ltmCell->handle.du.f1Idx == endPointIdx)
        {
            VCCB_PRINT_CALL_LTM(&rCall,
                "callLtmUe RespFlag(%u) for ltmTarget(idx:%u) is cleared DuId(%u) endPointIdx(%u) \n",
                rCall.ltmUeInfo.respFlag, ltmCell->handle.ltmCellIdx, duId, endPointIdx);
            OFFBIT_U8(rCall.ltmUeInfo.respFlag, ltmCell->handle.ltmCellIdx);
            break;
        }
    }
} // }}}

// it should be called when candidate cell setup.
void FnVCCB_UpdateRsIndexInmeasResultNR_type(callInfo_type &rCall, measResultNR_type &measResult, uint16_t targetCellNum)
{
    if (measResult.physCellIdFlag != TRUE) return;
    // get ltm CellInfo
    VCCB_CHECK_E_RANGE_AND_VOID(targetCellNum, MAX_CELL_NUM_VCCB);
    cgi_type cellCgi = FnVCCB_GetNrcgiFromCellNum(targetCellNum);
    auto &rTgtCell = CELLINFO[targetCellNum];
    ltmCellInfo_type *pLtmCell = FnVCCB_GetLtmCellInfoFromCGI(&rCall, cellCgi);
    if (pLtmCell == nullptr) return;
    if (pLtmCell->data.pci != rTgtCell.phyCellId) return;

    if (measResult.rsIndexResultsFlag != TRUE) return;

    if (measResult.rsIndexResults.resultsSSB_IndexesFlag != TRUE) return;

    auto nrofSSB = measResult.rsIndexResults.resultsSSB_Indexes.nrofSSB;

    for (auto idx = 0; idx < MAX_BEAM_FOR_LTM; idx++) pLtmCell->data.ssbIndexes[idx].usage = FALSE;

    uint16_t cnt = 0;
    for (auto ssbIndex = 0; ssbIndex < nrofSSB && ssbIndex < MAX_NUM_SSB; ssbIndex++)
    {
        if (cnt >= MAX_BEAM_FOR_LTM) break;
        pLtmCell->data.ssbIndexes[cnt].usage = TRUE;
        pLtmCell->data.ssbIndexes[cnt].ssbIndex =
            measResult.rsIndexResults.resultsSSB_Indexes.resultsPerSSB_Index[ssbIndex].ssbIndex & e_BitMask64_7bit;
        // if (measResult.rsIndexResults.resultsSSB_Indexes.resultsPerSSB_Index[ssbIndex].ssbResultsFlag != TRUE)
        // return; if (measResult.rsIndexResults.resultsSSB_Indexes.resultsPerSSB_Index[ssbIndex].ssbResults.rsrpFlag)
        // {
        //     pLtmCell->data.ssbIndexes[cnt].measQuantityResults.rsrp =
        //         measResult.rsIndexResults.resultsSSB_Indexes.resultsPerSSB_Index[ssbIndex].ssbResults.rsrp;
        //     pLtmCell->data.ssbIndexes[cnt].measQuantityResults.rsrpFlag = TRUE;
        // }
        // if (measResult.rsIndexResults.resultsSSB_Indexes.resultsPerSSB_Index[ssbIndex].ssbResults.rsrqFlag)
        // {
        //     pLtmCell->data.ssbIndexes[cnt].measQuantityResults.rsrq =
        //         measResult.rsIndexResults.resultsSSB_Indexes.resultsPerSSB_Index[ssbIndex].ssbResults.rsrq;
        //     pLtmCell->data.ssbIndexes[cnt].measQuantityResults.rsrqFlag = TRUE;
        // }
        // if (measResult.rsIndexResults.resultsSSB_Indexes.resultsPerSSB_Index[ssbIndex].ssbResults.sinrFlag)
        // {
        //     pLtmCell->data.ssbIndexes[cnt].measQuantityResults.sinr =
        //         measResult.rsIndexResults.resultsSSB_Indexes.resultsPerSSB_Index[ssbIndex].ssbResults.sinr;
        //     pLtmCell->data.ssbIndexes[cnt].measQuantityResults.sinrFlag = TRUE;
        // }
        cnt++;
    }
}

void FnVCCB_UpdateRsIndexListForLTM(callInfo_type &rCall, uint16_t targetCellNum)
{ // {{{
    // ltm cell exist then update
    if (rCall.ltmUeInfo.numOfCellList == 0) return;

    VCCB_CHECK_E_RANGE_AND_VOID(rCall.myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    measResultList2NR_type *ptMeasResultList2NR =
        &THREAD_INFO->call[rCall.myThreadId].buf.measResultList2NRRx.candidateCellInfoListSN;

    if (ptMeasResultList2NR->nrofFreq == 0) return;

    // get servingFreq
    VCCB_CHECK_E_RANGE_AND_VOID(rCall.servCellNum, MAX_CELL_NUM_VCCB);
    auto servingCellSsbArfcn = CELLINFO[rCall.servCellNum].ssbArfcn;

    for (auto idx = 0; idx < MAX_NUM_FREQ && idx < ptMeasResultList2NR->nrofFreq; idx++)
    {
        measResult2NR_type *pMeasResult2NR = &ptMeasResultList2NR->measResult2NR[idx];
        if (pMeasResult2NR->ssbFrequency_Flag != TRUE) continue;

        // check intra freq
        if (pMeasResult2NR->ssbFrequency != servingCellSsbArfcn) continue;

        // check servingCell Info
        if (pMeasResult2NR->measResultServingCell_Flag == TRUE)
        {
            FnVCCB_UpdateRsIndexInmeasResultNR_type(rCall, pMeasResult2NR->measResultServingCell, targetCellNum);
        }

        for (auto mrNbrIdx = 0;
            mrNbrIdx < MAX_NUM_CELL_REPORT && mrNbrIdx < pMeasResult2NR->measResultNeighCellListNR.nrofCellReport;
            mrNbrIdx++)
        {
            FnVCCB_UpdateRsIndexInmeasResultNR_type(
                rCall, pMeasResult2NR->measResultNeighCellListNR.measResultNR[mrNbrIdx], targetCellNum);
        }
    }
} // }}}

void FnVCCB_UpdateCandidateCellInfoForLtmHoExec(callInfo_type &rCall)
{ // {{{
    AUTO_TRACE_FUNC;

    ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromCGI(&rCall, rCall.ltmUeInfo.targetCgi);
    if (ptTarget != NULL)
    {
        // for VHCM_FinalizeHandover_UpdateIntraGnbConfiguration
        rCall.hoInfo.targetCellNum = ptTarget->data.cellSelection.cellNum;
        rCall.hoInfo.targetCellBand = ptTarget->data.cellSelection.bandNr;

        rCall.hoInfo.cgi = ptTarget->data.nrcgi;

        rCall.hoInfo.targetDu.duUEid = ptTarget->handle.du.duUEid;
        rCall.hoInfo.targetDu.f1Idx = ptTarget->handle.du.f1Idx;

        // for VHCM_FinalizeHandover_UpdateCommonConfiguration
        rCall.hoInfo.targetcRNTI = ptTarget->data.crnti;
        rCall.hoInfo.isLtmCellSwitch = TRUE;
    }

} // }}}

void FnVCCB_UpdateLtmSvcGrp(callInfo_type &rCall)
{
    auto oldVal = rCall.ltmUeInfo.svcGrpId;
    rCall.ltmUeInfo.svcGrpId = FnVCCB_GetSvcGrpId(rCall, FALSE, true);

        VCCB_PRINT_CALL_LTM(&rCall, "[LTM] ltm svc Grp changed (%d -> %d)\n", oldVal, rCall.ltmUeInfo.svcGrpId);
}

void FnVCCB_HandleLtmReleaseBySvcGrpChanged(callInfo_type &rCall)
{
    if (rCall.ltmUeInfo.numOfCellList == 0) return;

    // invalid case
    if (rCall.ltmUeInfo.svcGrpId == FnVCCB_GetSvcGrpId(rCall, FALSE, true)) return;

    // update svcGrpId
    FnVCCB_UpdateLtmSvcGrp(rCall);

    if (FnVCCB_GetMaxNumOfLtmCellFromYang(rCall) == 0)
    {
        // need to release
        VCCB_PRINT_CALL_LTM(&rCall, "[LTM] ltm svc Grp changed, ltm Release condition. max numOfLtmCell = 0 \n");
        FnVCCB_LtmRelease(rCall);
    }
}

int16_t FnVCCB_FinalizeLtmHoPrep(callInfo_type *ptCi)
{ // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // Init Ltm PrepProcTempDb
    FnVCCB_initLtmPrepProcTempDb(*ptCi);

    // update the LtmCellConfig
    FnVCCB_LtmCellConfigCommit(ptCi);

    // Change the RB status to Idle.
    VLIB_setBearerStatusToIdle(ptCi);

    // Describes items that require initialization.
    VLIB_InitHoInfo(ptCi);
    VLIB_InitHoStat(ptCi);

    // CRR, If CRR exists, Change Normal
    MACRO_RESET_CALL_FAULT_CAUSES;

    // update svc grp when first ltm candidate cell added. 
    FnVCCB_UpdateLtmSvcGrp(*ptCi);

    if (FnVCCB_IsLtmReleaseCase(*ptCi))
    {
        FnVCCB_ClearLtmUeInfo(ptCi);
    }

    // Change Conn(DB) State
    SET_STATE_CMD(Idle_cmd);
    VLIB_SetCurStateAll(ptCi, STATE_Conn);

    return GOOD;
} // }}}

int16_t FnVCCB_LtmTimerUpdateAfterLtmSwitch(callInfo_type &rCall, ltmCellInfo_type &rLtmTarget)
{
    auto tgtCellNum = rLtmTarget.data.cellSelection.cellNum;

    // cancel timer handover target cell
    VCCB_CLEAR_TIMER(&rLtmTarget.handle.ltmCellReleaseTimer, CANCEL_TIMER);
    VCCB_PRINT_CALL_LTM(&rCall, "[LTM] Cancel tgt Cell timer(ltmIdx:%d/%llu)\n", rLtmTarget.handle.ltmCellIdx,
        rLtmTarget.data.nrcgi.ci * 1ULL);

    // prev cell
    auto *ptSrcCell = FnVCCB_GetLtmCellInfoFromCellNum(&rCall, rCall.servCellNum);
    if (ptSrcCell == nullptr)
    {
        VCCB_PRINT_ERROR("FnVCCB_GetLtmCellInfoFromCellNum get ERROR!! (servCellNum:%u)\n", rCall.servCellNum);
        return ERROR;
    }

    return FnVCCB_AttachLtmCandidateCellRelTimer(rCall, ptSrcCell, tgtCellNum);
}

int16_t FnVCCB_FinalizeLtmHoCellSwitch(callInfo_type &rCall)
{
    ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromCGI(&rCall, rCall.ltmUeInfo.targetCgi);
    if (ptTarget == nullptr)
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "[LTM] There is no CGI(%X/%llu)\n", rCall.ltmUeInfo.targetCgi.plmn.longId,
            rCall.ltmUeInfo.targetCgi.ci * 1ULL);
        return ERROR;
    }

    // du information update for ho finalize
    rCall.hoInfo.targetDu = ptTarget->handle.du;
    if ((ptTarget->handle.ltmCellIdx < MAX_NUM_LTM_CELLS) && (nullptr != rCall.ltmUeInfo.ptProcRelatedData))
    {
        rCall.saMeas = rCall.ltmUeInfo.ptProcRelatedData->saMeas[ptTarget->handle.ltmCellIdx];
        rCall.anrInfo.reportCgi = rCall.ltmUeInfo.ptProcRelatedData->reportCgi[ptTarget->handle.ltmCellIdx];
    }

    int16_t status = VHCM_UpdateUeHistoryInformation_Prepare(&rCall);
    VCCB_RETURN_ON_CALL_ERROR(&rCall, status, "[LTM] VHCM_UpdateUeHistoryInformation_Prepare ERROR!\n");

    status = (ComTimeUtil::get_current_time(rCall.ueHistory.startTime) == GOOD)? GOOD : ERROR; // 26A FGR-MC1034:FR760 start stay time
    VCCB_RETURN_ON_CALL_ERROR(&rCall, status, "[LTM] ComTimeUtil::get_current_time ERROR in %s!\n", __func__);

    status = FnVCCB_LtmTimerUpdateAfterLtmSwitch(rCall, *ptTarget);
    VCCB_RETURN_ON_CALL_ERROR(&rCall, status, "[LTM] FnVCCB_LtmTimerUpdateAfterLtmSwitch ERROR!\n");

    // copy duSelectionRelatedData (selected BC, FS, PC)
    rCall.duSelectionRelatedData = ptTarget->data.duSelectionRelatedData;

    FnVCCB_ClearScellsAfterLtmCellSwitch(rCall);
    rCall.bitFlag.isSCellReconfigRequired = TRUE;
    VCCB_RETURN_ON_CALL_ERROR(&rCall,
        VCCM_enqueueAction(&rCall, ENQUEUE_ACTION_CA_MOD), "Queuing CA modification fail !!\n");

    // Send CallSetupRsp to VNMB
    status = VIIL_sendCallResourceChangeInd(&rCall);
    VCCB_RETURN_ON_CALL_ERROR(&rCall, status, "[LTM] VIIL_sendCallResourceChangeInd ERROR!\n");

    status = VHCM_FinalizeHandover(&rCall);
    VCCB_RETURN_ON_CALL_ERROR(&rCall, status, "[LTM] VHCM_FinalizeHandover ERROR!\n");

    FnVCCB_InitLtmUeInfoForCellSwitch(&rCall);

    return GOOD;
}

int16_t FnVCCB_FinalizeLtmHo(callInfo_type &rCall, enumHandoverTriggerType cause)
{
    if (cause == e_HoTrigger_LtmHandoverPrep)
    {
        return FnVCCB_FinalizeLtmHoPrep(&rCall);
    }
    else if (cause == e_HoTrigger_LtmHandoverExec)
    {
        return FnVCCB_FinalizeLtmHoCellSwitch(rCall);
    }
    else 
    {
        return ERROR;
    }
}

int16_t FnVCCB_Send_Ltm_ReconfigCompleteIndicator(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;
    
    // Send F1 Mod Req w/ RRC Reconfiguration Complete Indicator
    // 1. Target Cell -> Send the complete indication
    {
        auto *pLtmTgtCell = FnVCCB_GetLtmCellInfoFromCGI(ptCi, ptCi->hoInfo.cgi);
        if (pLtmTgtCell == nullptr)
        {
            VCCB_PRINT_ERROR("FnVCCB_GetLtmCellInfoFromCGI get ERROR!!\n");
            return ERROR;
        }

        HandleCurrentCandidateCellIndex currCandiCellIdxHandler(*ptCi, pLtmTgtCell->handle.ltmCellIdx);
        status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextModificationRequest ERROR !!\n");
    }

    // 2. Serving Cell -> Send the complete indication
    {
        auto *pLtmSrcCell = FnVCCB_GetLtmCellInfoFromCellNum(ptCi, ptCi->servCellNum);
        if (pLtmSrcCell == nullptr)
        {
            VCCB_PRINT_ERROR("FnVCCB_GetLtmCellInfoFromCellNum get ERROR!!\n");
            return ERROR;
        }
        HandleCurrentCandidateCellIndex currCandiCellIdxHandler(*ptCi, pLtmSrcCell->handle.ltmCellIdx);
        status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextModificationRequest ERROR !!\n");
    }

    VLIB_AttachTimer(&ptCi->hoInfo.timer.f1, ptCi, timF1_UeContextModification_id);

    return GOOD;
}

/****************************************************
 * @brief      This function performs the final application of Cell Configuration used for Ltm Handover.
 * @param[in]  ptCi : call information / callInfo_type
 * @return     void
 ****************************************************/
int16_t FnVCCB_LtmExecUpHandler(callInfo_type *ptCi, uint16_t msgId)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status;

    if (ptCi->ltmUeInfo.cellSwitchFlag.e1StopIsRequired)
    {
        // TP resume with target cell tunnel
        status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");
        
        VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextModification_id);
        
        ptCi->ltmUeInfo.cellSwitchFlag.e1StopIsRequired = false;
        ptCi->ltmUeInfo.cellSwitchFlag.e1StopWaiting = true;
        
        return GOOD;
    }

    // Wait E1 response state
    if (ptCi->ltmUeInfo.cellSwitchFlag.e1StopWaiting)
    {
        switch (msgId)
        {
            case E1_BearerContextModificationResponse_id:
                ptCi->ltmUeInfo.cellSwitchFlag.e1StopWaiting = false;
                ptCi->ltmUeInfo.cellSwitchFlag.e1ResumeIsRequired = true;
                break;

            default:
                /* Do nothing, wait the e1 response */
                return GOOD;
        }
    }

    if (DBG->flag.ltmCellSwitchExeResumeAnyMsg == VCCB_FLAG_OFF)
    {
        if (ptCi->ltmUeInfo.cellSwitchFlag.f1AccessSuccessReceived)
        {
            /* Send DL tx resume with flag (e1ResumeIsRequired) */
        }
        else
        {
            /* Do nothing, wait the f1 Access Success */
            return GOOD;
        }
    }

    if (ptCi->ltmUeInfo.cellSwitchFlag.e1ResumeIsRequired)
    {
        // get DU tnl address (Make it as function)
        {
            ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoFromCGI(ptCi, ptCi->ltmUeInfo.targetCgi);
            if (ptTarget != NULL)
            {
                // TODO: update the tnl addr..
                int drbIdx = 0;
                for (auto &rCallDrb : ptCi->drb)
                {
                    if (rCallDrb.usage != CI_use)
                    {
                        drbIdx++;
                        continue;
                    }

                    if (ptTarget->data.tnlAddr.drb[drbIdx].f1uDlInfo.numTLAbit != 0)
                    {
                        // TODO: need to add more condition or update valid drb...
                        rCallDrb.f1uDlInfo = ptTarget->data.tnlAddr.drb[drbIdx].f1uDlInfo;
                        rCallDrb.f1uDlInfo.fNeedModify = 1;
                    }
                    drbIdx++;
                }
            }
        }

        status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

        VLIB_AttachTimer(&ptCi->hoInfo.timer.e1, ptCi, timE1_BearerContextModification_id);

        ptCi->ltmUeInfo.cellSwitchFlag.e1ResumeIsRequired = false; // e1ResumeIsRequired is used to make E1 msg

        return GOOD; //need to wait E1 Resp
    }

    return GOOD;
}  // }}}

uint8_t FnVCCB_GetMaxNumOfLtmCellFromYang(callInfo_type &rCall)
{
    uint8_t svcGrpId;
    uint8_t isReleaseProcedure = FALSE; /* FALSE : Do not count 'S_Release' PDU as a service group candidate. */

    if (ERROR == FnVCCB_GetServiceGroupId(&rCall, &svcGrpId, isReleaseProcedure)){
        svcGrpId = 0;
    }
    
    return (FnVCCB_GetMaxNumOfLtmCellPerSvgGrp(rCall.gnbNum, svcGrpId));
}

bool FnVCCB_IsLtmCandidateCellFull(callInfo_type &rCall)
{
    const auto maxNumYang = FnVCCB_GetMaxNumOfLtmCellFromYang(rCall) + 1; 

    bandNrUeCapa_type *ptBand = FnVCCB_GetBandNrUeCapa(&rCall, FnVCCB_GetCellSelectionForConfig(&rCall).bandNr);
    VALID_E_POINT_CHECK_RET_VAL(ptBand, true);  // true : candidate cell list is full
    const auto maxNumUeCapa = ptBand->rachEarlyTAMeasurement_r18;

    const uint8_t maxNumOfLtmCell =
        (maxNumUeCapa == 0 ? static_cast<uint8_t>(maxNumYang) : static_cast<uint8_t>(MIN(maxNumYang, maxNumUeCapa)));

    if (maxNumOfLtmCell <= rCall.ltmUeInfo.numOfCellList)
    {
        VCCB_PRINT_CALL_LTM(&rCall,
            "[LTM] maxNumOfLtmCandidateCell(%d) <= ltmUeInfo.numOfCellList(%d) !!\n",
            maxNumOfLtmCell, rCall.ltmUeInfo.numOfCellList);
        return true;
    }

    return false;
}

bool FnVCCB_IsHoTargetCellLtmCandidate(callInfo_type &rCall, saMobilityMrInfo_type &hoMrInfo)
{
    AUTO_TRACE_FUNC;

    if (not VCCB_IS_VALID_INTRA_NR_HANDOVER_PURPOSE(hoMrInfo.reportType, hoMrInfo.reportPurpose)) return false;

    if (hoMrInfo.isDuplicatedPciTarget == true) return false;

    if (hoMrInfo.qRelType[0] != INTRA_NB) return false;

    const CellNum_type targetCellNum = hoMrInfo.qTargetCellNum[0];
    VCCB_CHECK_E_RANGE_AND_FALSE(targetCellNum, MAX_CELL_NUM_VCCB);

    ltmCellInfo_type *pLtmCell = FnVCCB_GetLtmCellInfoFromCellNum(&rCall, targetCellNum);
    if (pLtmCell != NULL) return true;

    return false;
}

int16_t FnVCCB_TriggerLtmCellSwitch(
    callInfo_type &rCall, saMobilityMrInfo_type &hoMrInfo, measResultList2NR_type *ptMeasResultList2NR)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptMeasResultList2NR);

    ltmCellInfo_type *pLtmCell = FnVCCB_GetLtmCellInfoFromCellNum(&rCall, hoMrInfo.qTargetCellNum[0]);
    if (pLtmCell == NULL) return GOOD;

    const int16_t msgSendResult = VFIL_sendF1_L3MrTransfer(&rCall, pLtmCell->data.nrcgi, ptMeasResultList2NR);
    if (msgSendResult != GOOD)
    {
        VCCB_PRINT_CALL_LTM(&rCall, "[LTM] VFIL_sendF1_L3MrTransfer fail(result:%d)\n", msgSendResult);
        return ERROR;
    }
    
    VCCB_PRINT_CALL_LTM(&rCall, "[LTM] L3MrTransfer success(cgi:%X-%llu)\n", 
        pLtmCell->data.nrcgi.plmn.longId, 1LL * pLtmCell->data.nrcgi.ci);
    
    VLIB_AttachTimer(&rCall.hoInfo.timer.spec, &rCall, timInternalLtmCellSwitchPreparation_id);
    FnVCCB_triggerLtmCellSwitchPreparation(&rCall);
    
    return BREAK;
}

int16_t FnVCCB_UpdateMeasResultForLtmTargetCell(
    callInfo_type *ptCi, uint16_t nbrIdx, measurementObjectUe_type *pMeasObj, measResultList2NR_type *ptMeasNew)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR_PARAM3(ptCi, pMeasObj, ptMeasNew);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    nbrGnbCellInfo_type *ptNbrGnbCell = NULL;
    if (GOOD != getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &ptNbrGnbCell)) return ERROR;
    const uint16_t targetCellPci = ptNbrGnbCell->nrPci;
    const uint32_t targetFreq = ptNbrGnbCell->ssbArfcn;

    measResultList2NR_type *ptMeas = &THREAD_INFO->call[ptCi->myThreadId].buf.measResultList2NRRx.candidateCellInfoListSN;

    ptMeasNew->nrofFreq = 0;
    uint16_t idx;
    for (idx = 0; idx < ptMeas->nrofFreq; idx++)
    {
        const measResult2NR_type *ptMeasResult2NR = &ptMeas->measResult2NR[idx];

        // Check used frequency is the same as selected target cell
        const uint32_t usedFreq = (ptMeasResult2NR->ssbFrequency_Flag)? ptMeasResult2NR->ssbFrequency : ptMeasResult2NR->refFreqCSI_RS;

        if (usedFreq != targetFreq) continue;

        // Check if PCI is the same as selected target cell
        const uint8_t nrOfCellReport = ptMeasResult2NR->measResultNeighCellListNR.nrofCellReport;
        for (auto neighCellIdx = 0; neighCellIdx < nrOfCellReport; neighCellIdx++)
        {
            const measResultNR_type *measResult 
                = &ptMeasResult2NR->measResultNeighCellListNR.measResultNR[neighCellIdx];

            if (measResult->physCellIdFlag != TRUE) continue;

            if (measResult->physCellId == targetCellPci)
            {
                // 25B IoDT. Transmit only one ssbFreq and one neighMeasResult by force
                ptMeasNew->nrofFreq = 1;
                ptMeasNew->measResult2NR[0] = *ptMeasResult2NR;
                ptMeasNew->measResult2NR[0].measResultNeighCellListNR.nrofCellReport = 1;
                ptMeasNew->measResult2NR[0].measResultNeighCellListNR.measResultNR[0] = *measResult;

                VCCB_PRINT_CALL_LTM(ptCi, "[LTM] selected neighMeasResult(freq:%d/pci:%d)\n", usedFreq, measResult->physCellId);
                return GOOD;
            }
        }
    }

    return ERROR;
}

bool FnVCCB_IsBeamMeasConfigNeed(callInfo_type &rCall, CellNum_type cellNum)
{
    if (GET_LTM_MEAS_CONFIG_NEEDED(&rCall)) return true;

    if (FnVCCB_GetLtmCellInfoFromCellNum(&rCall, cellNum) != NULL) return true;

    return false;
}
int16_t FnVCCB_LtmRelease(callInfo_type &rCall)
{
    for (auto &rLtmCell : rCall.ltmUeInfo.cellList)
    {
        if (rLtmCell.handle.usage == CI_no_use) continue;
        // if (rLtmCell.handle.ltmStatus == Common_Release) continue; // TODO: which condition is right??

        if (rLtmCell.data.cellSelection.cellNum == rCall.servCellNum) continue;

        rLtmCell.handle.flag.release_pending = true;
    }

    rCall.ltmUeInfo.flag.switchOver = FALSE;

    // queueing the event
    if (ERROR == VCCM_enqueueAction(&rCall, ENQUEUE_ACTION_LTM_CANDIDATE_CELL_RELEASE))
    {
        VCCB_PRINT_CALL_INFORMATIVE(&rCall, "VCCM_enqueueAction(ENQUEUE_ACTION_REPORTCGI) fail\n");
    }

    return GOOD;
}

int16_t FnVCCB_AttachLtmCandidateCellRelTimer(callInfo_type &rCall, ltmCellInfo_type *ptTarget, uint16_t cellNum)
{
    VALID_E_POINT_CHECK_ERROR(ptTarget);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    auto ltmCandidateReleaseTimerVal = CELLINFO[cellNum].mobilityConfig.ltmCandidateReleaseTimerValue;
#ifdef IPC_TEST
    ltmCandidateReleaseTimerVal = 100;
#endif
    VLIB_AttachTimerCore(&ptTarget->handle.ltmCellReleaseTimer, rCall.gnbCuUeId, timInternalLtmCandidateCellRelease_id,
        0, (uint16_t)ptTarget->handle.ltmCellIdx, (int)ltmCandidateReleaseTimerVal,
        VCCB_CALL_ADDR[rCall.myThreadId].MdsPort, VCCB_TIMER_TEMPORARY, (uint8_t)(rCall.myThreadId + 1));

    VCCB_PRINT_CALL_LTM(&rCall, "[LTM] Attach Ltm Candidate Cell Rel Timer (ltmIdx:%d/%llu)\n", ptTarget->handle.ltmCellIdx,
        ptTarget->data.nrcgi.ci * 1ULL);

    return GOOD;
}

void FnVCCB_LtmCandidateCellRelease(callInfo_type &rCall, uint16_t candidateCellIdx)
{
    ltmCellInfo_type *ptTarget = FnVCCB_GetLtmCellInfoForIndex(&rCall, static_cast<uint8_t>(candidateCellIdx));
    if (ptTarget == nullptr) return;
    if (ptTarget->data.cellSelection.cellNum == rCall.servCellNum) 
    {
        VCCB_PRINT_CALL_INFORMATIVE(&rCall, "invalid ltm Release target ltmIdx(%d) servCellNum(%d/%d)\n", 
            candidateCellIdx, ptTarget->data.cellSelection.cellNum, rCall.servCellNum);
        return;
    }

    ptTarget->handle.flag.release_pending = true;

    // queueing the event
    if (ERROR == VCCM_enqueueAction(&rCall, ENQUEUE_ACTION_LTM_CANDIDATE_CELL_RELEASE))
    {
        VCCB_PRINT_CALL_INFORMATIVE(&rCall, "VCCM_enqueueAction(ENQUEUE_ACTION_REPORTCGI) fail\n");
    }
}

/**
 *  @brief This function releases reportCgi Measment config when the t321 timer expires.
 *  @param callInfo_type* ptCi
 *  @return int16_t GOOD/BREAK/ERROR (1/0/-1)
 */
int16_t FnVCCB_LtmCandidateReleaseTimerAction(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, BREAK);
    VALID_E_POINT_CHECK_RET_VAL(ptAll, BREAK);
    VALID_E_POINT_CHECK_RET_VAL(ptUnpack, BREAK);

    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, ptUnpack->msgId, sizeof(messageHdr_type), reinterpret_cast<uint8_t *>(ptAll));
    FnVCCB_LtmCandidateCellRelease(*ptCi, FnVCCB_GetSpecificValueInExpiredTimer((messageHdr_type *)ptAll));
    return BREAK;
}  // }}}

bool FnVCCB_NeedToTriggerLtmRelease(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    for (auto &rLtmCell : ptCi->ltmUeInfo.cellList)
    {
        if (rLtmCell.handle.usage == CI_no_use) continue;

        if (rLtmCell.handle.flag.release_in_progress == true) return true;
    }
    
    return false;
}  // }}}

bool FnVCCB_ExecuteLTMReleaseBySwitchOver(callInfo_type &rCall)
{
    if (FnVCCB_IsEmptyLtmCell(&rCall))
    {
        return false;
    }

    if (rCall.ltmUeInfo.flag.switchOver == FALSE)
    {
        return false;
    }

    VCCB_PRINT_CALL_CRITICAL(&rCall, "[LTM] Release All LTM candidate Cells by SwitchOver\n");
    if (!FnVCCB_LtmRelease(rCall))
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "LTM release failed during SwitchOver\n");
        return false;
    }

    rCall.ltmUeInfo.flag.switchOver = FALSE;
    return true;
}

void FnVCCB_LtmReleaseAllCandidateImmediately(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    for (auto &rLtmCell : ptCi->ltmUeInfo.cellList)
    {
        if (rLtmCell.handle.usage != CI_use) continue;

        if (rLtmCell.data.cellSelection.cellNum == ptCi->servCellNum) continue;
            
        rLtmCell.handle.flag.release_in_progress = true;
    }
    
    VCCB_PRINT_CALL_CRITICAL(ptCi, "[LTM] Release All LTM candidate Cells Immeditately\n");
    FnVCCB_triggerLtmCellRelease(ptCi);
}  // }}}

int16_t FnVCCB_triggerLtmCellRelease(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status;

    SET_STATE_CMD(IntraRatHO_cmd); 
    //set hoInfo for delete
    ptCi->hoInfo.cause = e_HoTrigger_LtmHandoverPrep;

    for (auto &rLtmCell : ptCi->ltmUeInfo.cellList)
    {
        if (rLtmCell.handle.usage == CI_no_use) continue;
        // if (rLtmCell.handle.ltmStatus == Common_Release) continue; // TODO: which condition is right??

        if (rLtmCell.handle.flag.release_in_progress == false)
        {
            FnVCCB_SetLtmCellAction(ptCi, rLtmCell.handle.ltmCellIdx, ltm_selectAsTargetCell);
        }
    }
    
    status = FnVCCB_NextStep_Ltm_Prep_TgtDuRel(*ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextReleaseCommand ERROR !!\n");

    return GOOD;
}  // }}}

int16_t VCCM_HandleDequeuedLtmCandidateCellRelease(callInfo_type *ptCi, enqueuedAction)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    bool hasReleasePending = false;
    for (auto &rLtmCell : ptCi->ltmUeInfo.cellList)
    {
        if (rLtmCell.handle.usage == CI_no_use) continue;

        if (rLtmCell.handle.flag.release_pending == true)
        {
            rLtmCell.handle.flag.release_pending = false;
            
            if (rLtmCell.data.cellSelection.cellNum != ptCi->servCellNum)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[LTM] Release LTM candidate Cell will be released (ltmIdx:%d/cellNum:%d)\n", 
                    rLtmCell.handle.ltmCellIdx, rLtmCell.data.cellSelection.cellNum);
                rLtmCell.handle.flag.release_in_progress = true;
                hasReleasePending = true;
            }
            else 
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[LTM] Release LTM candidate Cell is Pcell, skip release (ltmIdx:%d/cellNum:%d/%d)\n", 
                    rLtmCell.handle.ltmCellIdx, rLtmCell.data.cellSelection.cellNum, ptCi->servCellNum);
            }
        }
    }

    if (hasReleasePending == true)
    {
        FnVCCB_triggerLtmCellRelease(ptCi);
    }

    return GOOD;
}

int16_t FnVCCB_SendF1UeContextRelease_LtmCandidateCell(callInfo_type *ptCi, ltmCellInfo_type *ptTarget)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptTarget);

    HandleCurrentCandidateCellIndex currCandiCellIdxHandler(*ptCi, ptTarget->handle.ltmCellIdx);
    FnVCCB_SetLtmCellStatus(ptCi, ptTarget->handle.ltmCellIdx, Common_Release);
    ptTarget->handle.flag.release_in_progress = false;

    if (FnVCCB_IsExistLtmTargetDU(ptCi, ptTarget))
    {
        int16_t status = VFIL_sendF1_UeContextReleaseCommand(ptCi, nullptr, 0, ID_SRB0, DU_HO_LTM);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VFIL_sendF1_UeContextReleaseCommand ERROR !!\n");
        ptTarget->handle.flag.setup = FALSE;
    }

    return GOOD;
}

int16_t FnVCCB_LtmStoreF1_UeContextSetupResponse(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    LtmF1apStoreDbHandler ltmDbHandler(*ptCi, F1_UEContextSetupResponse_id);
    ltmDbHandler.preF1apMsgStore();
    int16_t status = VFIL_storeF1_UeContextSetupResponse(ptCi, ptAll, ptUnpack);
    ltmDbHandler.postF1apMsgStore();
    return status;
}

int16_t FnVCCB_LtmStoreF1_UeContextModificationResponse(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);

    LtmF1apStoreDbHandler ltmDbHandler(*ptCi, F1_UEContextModificationResponse_id);
    ltmDbHandler.preF1apMsgStore();
    int16_t status = VFIL_storeF1_UeContextModificationResponse(ptCi, ptAll, ptUnpack);
    ltmDbHandler.postF1apMsgStore();
    return status;
}

void LtmF1apStoreDbHandler::updateCrnti()
{
    if (pLtmCell == nullptr) return;

    if (isSetupResponse)
    {
        pLtmCell->handle.flag.receivedDuUeId = 1;
        pLtmCell->data.crnti = rCall.hoInfo.targetcRNTI;
        pLtmCell->handle.du.duUEid = rCall.hoInfo.targetDu.duUEid;
    }
    else
    {  // for Candidate cell setup PCell using ue context modification
        if (pLtmCell->data.cellSelection.cellNum != rCall.servCellNum) return;
        if (pLtmCell->handle.flag.rrc_activation_flag == TRUE) return;
        if (rCall.hoInfo.targetcRNTIUsage == CI_use)
        {
            pLtmCell->data.crnti = rCall.hoInfo.targetcRNTI;
        }
    }
}

void LtmF1apStoreDbHandler::updateLtmCandidateCellF1uDlInfo(uint16_t drbIdx)
{
    // tnl address
    if (isSetupResponse == false) return;

    if (drbIdx >= MAX_DRB_PER_SA_CALL) return;

    if (pLtmCell == nullptr) return;

    if (rCall.drb[drbIdx].f1uDlInfo.fNeedModify)
    {
        // update db with cleared flag
        rCall.drb[drbIdx].f1uDlInfo.fNeedModify = 0;
        pLtmCell->data.tnlAddr.drb[drbIdx].f1uDlInfo = rCall.drb[drbIdx].f1uDlInfo;
    }
}

void LtmF1apStoreDbHandler::rollbackCallDBAndUpdateLtmDrbDB()
{
    for (uint16_t drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        if (rCall.drb[drbIdx].usage != CI_use) continue;

        if (rCall.drb[drbIdx].f1uDlInfo.fNeedModify)
        {
            VCCB_PRINT_CALL_LTM(&rCall, "[LTM] DlTnl information Received when LTM cell updates ltmIdx : %d \n",
                rCall.ltmUeInfo.currCandidateCellIdx);
        }

        updateLtmCandidateCellF1uDlInfo(drbIdx);

        // rollback original DB.
        rCall.drb[drbIdx].f1uDlInfo = f1uDlInfo[drbIdx];
    }
}

void LtmF1apStoreDbHandler::preF1apMsgStore()
{
    // backup drbF1uDlInfo
    for (auto drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        f1uDlInfo[drbIdx] = rCall.drb[drbIdx].f1uDlInfo;
    }

    // init targetcRNTIUsage flag
    rCall.hoInfo.targetcRNTIUsage = CI_no_use;
}

void LtmF1apStoreDbHandler::postF1apMsgStore()
{
    // update Crnti
    updateCrnti();

    rollbackCallDBAndUpdateLtmDrbDB();
}
