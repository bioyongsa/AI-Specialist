/**
 * @file        FeatFullConfig.cpp
 * @brief       Utility functions for Full Configuration
 */

#include "ComInclude.h"
#include "ComLibUtility.h"

#include "FeatFullConfig.h"
#include "FeatMeasurements.hpp"
#include "FeatHo.h"
#include "FeatCallProc.h"
#include "FeatRrcInactive.h"

#include "MsgF1apMake.h"
#include "MsgF1apStore.h"
#include "MsgXnapStore.h"

#define CHECK_N_SET_FULLCONFIGURATION(__bit_mask, __bit_name, __prefix)                 \
    do                                                                                  \
    {                                                                                   \
        if (__bit_mask & __bit_name)                                                    \
        {                                                                               \
            VCCB_SET_FULLCONFIGURATION(ptCi, ci_fc_trigger, __prefix "::" #__bit_name); \
        }                                                                               \
    } while (0)

VCCB_STATIC void VCCM_trigger_FullConfiguration_Forced_Scenario(callInfo_type *ptCi);
VCCB_STATIC void VCCM_trigger_FullConfiguration_Forced_Scenario_DuInit(callInfo_type *ptCi);
VCCB_STATIC int VCCM_check_FullConfiguration_Forced_Scenario(callInfo_type *ptCi, enumFullConfigTrigger_type eType, const cellSelection_type *pTargetCellSelection);
VCCB_STATIC int VCCM_check_FullConfiguration_Supported_Scenario(callInfo_type *ptCi, enumFullConfigTrigger_type eType, const cellSelection_type *pTargetCellSelection);

VCCB_STATIC bool FnVCCB_IsEndcUeSupportFullConfigScenario(
    const callInfo_type &callInfo, VccbFullConfigScenario_type &scenario);
VCCB_STATIC bool FnVCCB_IsNrdcSnUeSupportFullConfigScenario(
    const callInfo_type &callInfo, VccbFullConfigScenario_type &scenario, enumFullConfigTrigger_type eType, const cellSelection_type *pTargetCellSelection);
VCCB_STATIC bool FnVCCB_IsRreUESupportFullConfigScenario(
    const callInfo_type &callInfo, VccbFullConfigScenario_type &scenario, enumFullConfigTrigger_type eType);
VCCB_STATIC bool FnVCCB_IsSaHandoverUeSupportFullConfigScenario(
    const callInfo_type &callInfo, VccbFullConfigScenario_type &scenario, enumFullConfigTrigger_type eType);
VCCB_STATIC bool FnVCCB_IsRrcResumeUESupportFullConfigScenario(
    const callInfo_type &callInfo, VccbFullConfigScenario_type &scenario, enumFullConfigTrigger_type eType);

VCCB_STATIC int16_t FnVCCB_IsSupportDuInitFullConfigurationUE(callInfo_type *ptCi);
VCCB_STATIC int16_t FnVCCB_SetDuInitFullConfig(callInfo_type *ptCi);

int16_t FnVCCB_IsSupportSnInitFullConfigurationUE(callInfo_type *ptCi);
int16_t FnVCCB_SetSnInitFullConfig(callInfo_type *ptCi);

/********************************************************************************
 * @brief This area is the section for initializing the Full Configuration DB.
 ********************************************************************************/
// {{{

/**
 * @brief      This function is used to initialize fullconfiguration DB for UE.
 * @param      ptCi : call context
 * @return     void
 */
void VLIB_InitFullConfigurationInfo(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    memset(&ptCi->fullConfiguration, 0x00, sizeof(ptCi->fullConfiguration));
}  // }}}

/**
 * @brief      This function is used to initialize fullconfiguration DB for VCCB_CFG.
 * @param      ptCi : call context
 * @return     void
 */
void FnVCCB_InitFullConfiguration_InBlockLoading(void)
{  // {{{
    AUTO_TRACE_FUNC;

    memset(&CFG->fullConfig, 0x00, sizeof(CFG->fullConfig));

    // When the test is completed, it needs to be changed to Allowed.
    CFG->fullConfig.support.scenario.EventScenario_SA_InterGnbHandover = Allowed;
    CFG->fullConfig.support.scenario.EventScenario_SA_InterGnbHandover_DuInit = Allowed;
    CFG->fullConfig.support.scenario.EventScenario_SA_IntraGnbIntraDuHandover = Allowed;
    CFG->fullConfig.support.scenario.EventScenario_SA_IntraGnbIntraDuHandover_DuInit = Not_Allowed;
    CFG->fullConfig.support.scenario.EventScenario_SA_IntraGnbInterDuHandover = Allowed;
    CFG->fullConfig.support.scenario.EventScenario_SA_IntraGnbInterDuHandover_DuInit = Allowed;
    CFG->fullConfig.support.scenario.EventScenario_SA_InterGnbRRE = Not_Allowed;
    CFG->fullConfig.support.scenario.EventScenario_SA_IntraGnbRRE = Not_Allowed;

    CFG->fullConfig.support.scenario.EventScenario_SA_InterGnbResume_CuInit = Not_Allowed;  // SVR25A FGR-MC1020
    CFG->fullConfig.support.scenario.EventScenario_SA_IntraGnbResume_CuInit = Not_Allowed;  // SVR25A FGR-MC1020
    CFG->fullConfig.support.scenario.EventScenario_SA_InterGnbResume_DuInit = Not_Allowed;  // SVR25A FGR-MC1020
    CFG->fullConfig.support.scenario.EventScenario_SA_IntraGnbResume_DuInit = Not_Allowed;  // SVR25A FGR-MC1020

    CFG->fullConfig.support.scenario.EventScenario_NSA_SgNBAddition = Allowed;
    CFG->fullConfig.support.scenario.EventScenario_NSA_IntraDuPSCellChange = Allowed;
    CFG->fullConfig.support.scenario.EventScenario_NSA_InterDuPSCellChange = Allowed;

    // When the test is completed, it needs to be changed to Allowed.

    // From 21B, PDCP SN 12BIT is allowed.
    CFG->fullConfig.support.flag.F_21B_PDCP_SN_12BIT = Allowed;

    // From 21C, MR-DC UE is allowed.
    CFG->fullConfig.support.flag.F_21C_MRDC_UE = Allowed;

    // From 22A, It is used for NSA FullConfig test.
    CFG->fullConfig.support.flag.F_22A_NSA_PROCEEDHO = Not_Allowed;
    CFG->fullConfig.support.flag.F_22A_NSA_NRADDITION = Allowed;

    // From 22A, It is used for NRDC-SN FullConfig test.
    CFG->fullConfig.support.flag.F_22A_NRDC_PROCEEDHO = Not_Allowed;
    CFG->fullConfig.support.flag.F_22A_NRDC_NRADDITION = Allowed;

    CFG->fullConfig.dbg.drb_remapping = 0;
    CFG->fullConfig.dbg.drb_disable_datafwd = 0;

}  // }}}

/**
 * @brief      This function is used to initialize Install DB by Fullconfiguration.
 * @param      ptCi : call context
 * @return     void
 */

void VCCM_InitInstalledMeasConfig_ByFullConfiguration(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi))
    {
        // It always descends regardless of InstalledDB by'VCCM_BreakInternalIdxInNewItems', but is called for DB
        // initialization.
        status = VCCM_ClearInstalledMeasConfig(ptCi);
        VCCB_RETURN_ON_CALL_VOID(ptCi, status, "VCCM_ClearInstalledMeasConfig ERROR!\n");

        // Break the relationship between Installed and newItem. Therefore, all information of newItems is included in
        // RRC Reconfiguration.
        status = VCCM_BreakInternalIdxInNewItems(ptCi);
        VCCB_RETURN_ON_CALL_VOID(ptCi, status, "VCCM_BreakInternalIdxInNewItems ERROR!\n");

        VCCB_PRINT_CALL_COMMENT(ptCi, "The installed DB of the UE has been initialized by Full Configuration.\n");
    }
}  // }}}

// TODO: what is more good solution to solve it.
void VCCM_Init_SA_PDCP_C_SN_ByFullConfiguration(
    callInfo_type *ptCi, enumDuHoRole duHoRole, const F1_RRCContainer *pRRCContainer)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pRRCContainer);

    uint16_t srbIdx;
    uint32_t pdcp_sn;
    callSRBInfo_type *ptSi;

    /* use this fuction for SA call */
    if (ptCi->callType != E_CALLTYPE_SA)
    {
        return;
    }

    /* SRB init operation is handled only target DU, Intra DU handover is handled at other position */
    if (duHoRole != DU_HO_TARGET)
    {
        return;
    }

    /* use it for full configuration case */
    if (IS_FULLCONFIGURATION_NOT_IN_PROCESS(ptCi))
    {
        return;
    }

    switch (ptCi->stateCmd)
    {
        case IntraRatHO_cmd:
            /* handle it for pdcp sn 0 case */
            if (pRRCContainer->length < 2)
            {
                return;
            }

            pdcp_sn = (((uint32_t)pRRCContainer->value[0]) << 8) | ((uint32_t)pRRCContainer->value[1]);
            if (pdcp_sn > 0)
            {
                return;
            }
            break;
        default:
            /* don't use below condition */
            return;
    }

    // idx is ID - 1
    for (srbIdx = (ID_SRB1-1); srbIdx <= ID_SRB2 - 1; srbIdx++)
    {
        ptSi = &(ptCi->srbInfo[srbIdx]);

        if (!IS_VALID_NODE(SRB_NODE, ptCi, (ptSi))) continue;

        if (0 != FnPDCP_C_Init(&ptSi->pdcpRbContext, ptSi->rbInfo.rbId))
        {
            continue;
        }
    }
}  // }}}

// }}}
/********************************************************************************
 * @brief This area is the section for Getter and Setter operation of Full Configuration DB.
 ********************************************************************************/
// {{{

/**
 * @brief      This function is used to set full configuration for UE.
 * @param      ptCi : call context
 * @param      tag : full configuration type
 * @return     void
 */
VCCB_STATIC
void VCCM_set_FullConfiguration_Proc(callInfo_type *ptCi, enumFullConfigurationTag_type tag)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    switch (tag)
    {
        case ci_fc_trigger:
            ONBIT(ptCi->fullConfiguration.action, VCCB_FULL_CONFIG_ACTION);
            break;

        case ci_fc_du_init_trigger:
            ONBIT(ptCi->fullConfiguration.action, VCCB_FULL_CONFIG_ACTION);
            ONBIT(ptCi->fullConfiguration.action, VCCB_FULL_CONFIG_ACTION_DU_INIT);
            break;

        case ci_fc_sn_init_trigger:
            ONBIT(ptCi->fullConfiguration.action, VCCB_FULL_CONFIG_ACTION);
            ONBIT(ptCi->fullConfiguration.action, VCCB_FULL_CONFIG_ACTION_SN_INIT);
            break;

        default:
            /* no action */
            break;
    }
}  // }}}

void VCCM_set_FullConfiguration(const char *pFuncName, int lineNum, callInfo_type *ptCi,
    enumFullConfigurationTag_type tag, const char *ptStrCause, ...)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pFuncName);
    VALID_E_POINT_CHECK_VOID(ptStrCause);

    int isFcFilterSkipMode = VCCM_check_FullConfiguration_Filter(pFuncName, lineNum);

    if (DBG->flag.logFullConfig)
    {
        va_list argPtr;
        char msgBuff[100];
        const int msgSize = (int)sizeof(msgBuff);
        int msgLen = 0;

        va_start(argPtr, ptStrCause);
        msgLen = vsnprintf(msgBuff, msgSize, ptStrCause, argPtr);
        if (msgLen < msgSize)
            msgBuff[msgLen] = 0;
        else
            msgBuff[msgSize - 1] = 0;
        va_end(argPtr);

        VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "[CALL][%d,%u] FullConfig Action: %.*s\n", isFcFilterSkipMode, tag, (int)msgSize, msgBuff);
    }

    /* set drb full configuration when there is no filter */
    if (isFcFilterSkipMode == FALSE)
    {
        if (CFG->fullConfig.print.set_filter == TRUE)
        {
            VCCB_PRINT_ERROR("FullConfig Set is called for tag(%d). %s %lld\n", tag, pFuncName, 1LL * lineNum);
        }

        VCCM_set_FullConfiguration_Proc(ptCi, tag);
    }
    else
    {
        if (CFG->fullConfig.print.set_filter == TRUE)
        {
            VCCB_PRINT_ERROR(
                "VCCM_set_FullConfiguration is skipped for tag(%d). %s %lld\n", tag, pFuncName, 1LL * lineNum);
        }
    }

}  // }}}

/**
 * @brief      This function is used to get full configuration for UE.
 * @param      ptCi : call context
 * @param      tag : full configuration type
 * @return     void
 */
int VCCM_get_FullConfiguration_Proc(const callInfo_type *ptCi, enumFullConfigurationTag_type tag)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    switch (tag)
    {
        case ci_fc_trigger:
            if (GETBIT(ptCi->fullConfiguration.action, VCCB_FULL_CONFIG_ACTION))
            {
                return TRUE;
            }
            break;

        case ci_fc_du_init_trigger:
            if (GETBIT(ptCi->fullConfiguration.action, VCCB_FULL_CONFIG_ACTION_DU_INIT))
            {
                return TRUE;
            }
            break;

        case ci_fc_sn_init_trigger:
            if (GETBIT(ptCi->fullConfiguration.action, VCCB_FULL_CONFIG_ACTION_SN_INIT))
            {
                return TRUE;
            }
            break;

        default:
            break;
    }

    return FALSE;
}  // }}}

int VCCM_get_FullConfiguration(
    const char *pFuncName, int lineNum, const callInfo_type *ptCi, enumFullConfigurationTag_type tag)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(pFuncName);

    int status = FALSE;
    /* get drb full configuration when there is no filter */
    if (VCCM_check_FullConfiguration_Filter(pFuncName, lineNum) == FALSE)
    {
        if (CFG->fullConfig.print.get_filter == TRUE)
        {
            VCCB_PRINT_ERROR(
                "VCCM_get_FullConfiguration is called for tag(%d). %s %lld\n", tag, pFuncName, 1LL * lineNum);
        }
        status = VCCM_get_FullConfiguration_Proc(ptCi, tag);
    }
    else
    {
        if (CFG->fullConfig.print.get_filter == TRUE)
        {
            VCCB_PRINT_ERROR(
                "VCCM_get_FullConfiguration is skipped for tag(%d). %s %lld\n", tag, pFuncName, 1LL * lineNum);
        }
    }

    return status;
}  // }}}

/**
 * @brief      This function is used to set full configuration for DRB.
 * @param      ptCi : call context
 * @param      tag : full configuration type
 * @param      dRBId : full config target drb id information
 * @return     void
 */
VCCB_STATIC
void VCCM_set_FullConfiguration_Drb_Proc(callInfo_type *ptCi, enumFullConfigurationTag_type tag, int dRBId)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    switch (tag)
    {
        case ci_fc_trigger:
            ONBIT_U32(ptCi->fullConfiguration.action, VCCB_FULL_CONFIG_ACTION);
            break;

        case ci_fc_drb_remapping:
            /* TODO : There is no design from 20A (need to confirm from system design team) */
            break;

        case ci_fc_drb_disable_datafwd:
            ONBIT_U32(ptCi->fullConfiguration.action, VCCB_FULL_CONFIG_ACTION);
            ONBIT_U32(ptCi->fullConfiguration.drbId_disableFwd, (uint32_t)dRBId - 1);
            break;

        case ci_fc_drb_reuse:
            /* TODO : There is no design from 20A (need to confirm from system design team) */
            break;

        default:
            /* no action */
            break;
    }
}  // }}}

void VCCM_set_FullConfiguration_Drb(const char *pFuncName, int lineNum, callInfo_type *ptCi,
    enumFullConfigurationTag_type tag, int dRBId, const char *ptStrCause, ...)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pFuncName);
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptStrCause);

    int isFcFilterSkipMode = VCCM_check_FullConfiguration_Filter(pFuncName, lineNum);

    if (DBG->flag.logFullConfig)
    {
        va_list argPtr;
        char msgBuff[100];
        const int msgSize = (int)sizeof(msgBuff);
        int msgLen = 0;

        va_start(argPtr, ptStrCause);
        msgLen = vsnprintf(msgBuff, msgSize, ptStrCause, argPtr);
        if (msgLen < msgSize)
            msgBuff[msgLen] = 0;
        else
            msgBuff[msgSize - 1] = 0;
        va_end(argPtr);

        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[ DRB][%u,%u] - DRB(%d) FullConfig Action: %.*s\n", isFcFilterSkipMode, tag,
            dRBId, (int)msgSize, msgBuff);
    }

    /* set drb full configuration when there is no filter */
    if (isFcFilterSkipMode == FALSE)
    {
        if (CFG->fullConfig.print.set_filter == TRUE)
        {
            VCCB_PRINT_ERROR(
                "FullConfig DRB Set is called for tag(%d) drbId(%d). %s %lld\n", tag, dRBId, pFuncName, 1LL * lineNum);
        }
        VCCM_set_FullConfiguration_Drb_Proc(ptCi, tag, dRBId);
    }
    else
    {
        if (CFG->fullConfig.print.set_filter == TRUE)
        {
            VCCB_PRINT_ERROR(
                "FullConfig DRB Set is skipped for tag(%d) drbId(%d). %s %lld\n", tag, dRBId, pFuncName, 1LL * lineNum);
        }
    }
}  // }}}

/**
 * @brief      This function is used to get full configuration for DRB.
 * @param      ptCi : call context
 * @param      tag : full configuration type
 * @param      dRBId : full config target drb id information
 * @return     void
 */
int VCCM_get_FullConfiguration_Drb_Proc(callInfo_type *ptCi, enumFullConfigurationTag_type tag, int dRBId)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    switch (tag)
    {
        case ci_fc_trigger:
            if (GETBIT(ptCi->fullConfiguration.action, VCCB_FULL_CONFIG_ACTION))
            {
                return TRUE;
            }
            break;

        case ci_fc_drb_remapping:
            /* TODO : There is no design from 20A (need to confirm from system design team) */
            break;

        case ci_fc_drb_disable_datafwd:
            if (ptCi->fullConfiguration.action)
            {
                // check the disable fwd flag
                if (GETBIT(ptCi->fullConfiguration.drbId_disableFwd, dRBId - 1))
                {
                    return TRUE;
                }
            }
            break;

        case ci_fc_drb_reuse:
            /* TODO : There is no design from 20A (need to confirm from system design team) */
            break;

        default:
            /* no action */
            break;
    }

    return FALSE;
}  // }}}

/**
 * @brief      This function is used to get full configuration for DRB.
 * @param      ptCi : call context
 * @param      tag : full configuration type
 * @param      dRBId : full config target drb id information
 * @return     void
 */
int VCCM_get_FullConfiguration_Drb(
    const char *pFuncName, int lineNum, callInfo_type *ptCi, enumFullConfigurationTag_type tag, int dRBId)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(pFuncName);

    int status = FALSE;

    /* get drb full configuration when there is no filter */
    if (VCCM_check_FullConfiguration_Filter(pFuncName, lineNum) == FALSE)
    {
        if (CFG->fullConfig.print.get_filter == TRUE)
        {
            VCCB_PRINT_ERROR("VCCM_get_FullConfiguration_Drb is called for tag(%d) drbId(%d). %s %lld\n", tag, dRBId,
                pFuncName, 1LL * lineNum);
        }
        status = VCCM_get_FullConfiguration_Drb_Proc(ptCi, tag, dRBId);
    }
    else
    {
        if (CFG->fullConfig.print.get_filter == TRUE)
        {
            VCCB_PRINT_ERROR("VCCM_get_FullConfiguration_Drb is skipped for tag(%d) drbId(%d). %s %lld\n", tag, dRBId,
                pFuncName, 1LL * lineNum);
        }
    }

    return status;
}  // }}}

/**
 * @brief      This function determines whether to allow the CU Init Full Configuration UE.
 * @param      func_name : The name of the calling function
 * @param      line : The line of the calling file
 * @return     TRUE on force selction trigger, otherwise not trigger.
 */
int16_t VCCM_DecisionCuInitFullConfigurationUE(callInfo_type *ptCi, const cellSelection_type *pTargetCellSelection)
{  /// {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // 1) It means when Full Configuration needs to be triggered forcibly. Set all the necessary information for the
    // overall configuration within the function. (Forced Trigger)
    if (VCCM_check_FullConfiguration_Forced_Scenario(ptCi, e_CuInitFullConfig, pTargetCellSelection) == TRUE)
    {
        VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "FullConfiguration scenario detected. CU Init FullConfiguration operates. (Cause: Forced Trigger)\n");
        VCCM_trigger_FullConfiguration_Forced_Scenario(ptCi);
        //return GOOD;  // Allowed : Forced Trigger UE.
    }

    // 2) Full Configuration means a situation where a trigger is required. (Message Based Trigger)
    if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi))
    {
        // 2-1) Full configuration is supported. After that, proceed to Full Configuration operation. Detailed scenarios
        // are defined by each scenario manager.
        if (VCCM_check_FullConfiguration_Supported_Scenario(ptCi, e_CuInitFullConfig, pTargetCellSelection) == TRUE)
        {
            // SVR25A FGR-MC1020
            FnVCCB_SetAndDecideFullConfig_for_RRCInactive(ptCi);    // set 'full config' config for RRC_Inactive

            VCCB_PRINT_CALL_INFORMATIVE(
                    ptCi, "FullConfiguration scenario detected. CU Init FullConfiguration operates. (Cause: Supported)\n");

            return GOOD;  // Allowed :: Supported UE.
        }
        // 2-2) Full configuration is not supported. Perform the reject procedure. Detailed procedures accordingly are
        // defined by the scenario manager.
        //     Handover Preparation Failure(HO Case), RRC Setup(RRE Case)
        else
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                "FullConfiguration scenario detected. But Not Allowd CU Init FullConfiguration. (Cause: Not Supported)\n");

            return BREAK;  // Not Allowed :: Not Supported UE.
        }
    }
    // 3) This means that full configuration is not required.
    else
    {
        return GOOD;  // Normal UE, Not Full Configuration UE.
    }
}  // }}}

/**
 * @brief      This function determines whether to allow the DU Init Full Configuration UE.
 */
int16_t FnVCCB_IsSupportDuInitFullConfigurationUE(callInfo_type *ptCi)
{  /// {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // 2) Full Configuration means a situation where a trigger is required. (Message Based Trigger)
    if (VCCB_GET_FULLCONFIGURATION(ptCi, ci_fc_du_init_trigger) == TRUE)
    {
        // 2-1) Full configuration is supported. After that, proceed to Full Configuration operation. Detailed scenarios
        // are defined by each scenario manager.
        if (VCCM_check_FullConfiguration_Supported_Scenario(ptCi, e_DuInitFullConfig, NULL) == TRUE)
        {
            VCCB_PRINT_CALL_INFORMATIVE(
                ptCi, "FullConfiguration scenario detected. DU Init FullConfiguration operates. (Cause: Supported)\n");
            return GOOD;  // Allowed :: Supported UE.
        }
        // 2-2) Full configuration is not supported. Perform the reject procedure. Detailed procedures accordingly are
        // defined by the scenario manager.
        //     Handover Preparation Failure(HO Case), RRC Setup(RRE Case)
        else
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                "FullConfiguration scenario detected. But Not Allowd DU Init FullConfiguration. (Cause: Not Supported)\n");
            return BREAK;  // Not Allowed :: Not Supported UE.
        }
    }
    // 3) This means that full configuration is not required.
    else
    {
        return GOOD;  // Normal UE, Not Full Configuration UE.
    }
}  // }}}

int16_t FnVCCB_ProcDuInitFullConfiguration(
    callInfo_type *ptCi,
    const message_type *ptAll,
    const msgUnpack_type *ptUnpack,
    const bool withLoggingFlag)
{
    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR_PARAM3(ptCi, ptAll, ptUnpack);

    // Check if there is a full configuration IE.
    auto isExistF1FullConfiguration = [](const struct F1_ProtocolIE_Container_ *_pContainer) -> bool
    {
        if (_pContainer == NULL) return false;

        const F1_FullConfiguration *pFullConfig = NULL;

        if (GOOD == VFIL_GetF1IE((const void **)&pFullConfig, _pContainer, F1_id_FullConfiguration))
        {
            if (pFullConfig != NULL)
            {
                return true;
            }
        }

        return false;
    };

    const uint16_t msgId = ptUnpack->msgId;
    const struct F1_ProtocolIE_Container_ *pContainer = NULL;

    switch(msgId)
    {
        case F1_UEContextSetupResponse_id:
            {
                const F1_UEContextSetupResponse *pResp = (F1_UEContextSetupResponse *)(&ptUnpack->unpack[0] + ptUnpack->unpackMsgOffset);
                pContainer = pResp->protocolIEs;
                break;
            }

        case F1_UEContextModificationResponse_id:
            {
                const F1_UEContextModificationResponse *pResp = (F1_UEContextModificationResponse *)(&ptUnpack->unpack[0] + ptUnpack->unpackMsgOffset);
                pContainer = pResp->protocolIEs;
                break;
            }

        default:
            return GOOD;
    }

    // If there is no full configuration IE, there is no need to proceed with the operation in this function.
    if (isExistF1FullConfiguration(pContainer) == false)
    {
        return GOOD;
    }

    // If it is CU or SN Init FullConfiguration, no more operation is required.
    if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi))
    {
        return GOOD;
    }

    // This parameter is detected as DU Init Full Configuration. Therefore, the UE configures the corresponding information.
    status = FnVCCB_SetDuInitFullConfig(ptCi);
    switch(status)
    {
        case GOOD:
            break;

        case BREAK:
            if (DBG->flag.logFullConfig)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "DU Init Full Configuration by not registered scenario (state:%d, stateCmd:%u)\n", ptCi->state, ptCi->stateCmd);
            }
            return BREAK;

        default:
        case ERROR:
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SetDuInitFullConfig Error! (status:%d)\n", status);
            return ERROR;
    }

    // Check if the current scenario supports FullConfiguration.
    status = FnVCCB_IsSupportDuInitFullConfigurationUE(ptCi);
    switch(status)
    {
        case GOOD: // Support
            // SVR25A FGR-MC1020
            if (ptCi->stateCmd == RRCResume_cmd &&
                ptCi->ueInfo.RrcInactiveInfo.resumeCause != NRRRC_rna_Update)
            {
                ptCi->ueInfo.rrcResumeInfo.fullConfigRequiredFlag = TRUE;   // intra-gnb and inter-gnb, du-init full config
            }

            return GOOD;

        case BREAK: // Not Support

            // if Determines whether to call the logging function.
            // This is necessary when the store function is not called and it is restricted in advance.

            if (withLoggingFlag == true)
            {
                FnVCCB_SaveAndUpdateF1MessageWithLogging(ptCi, ptAll, msgId, pContainer);
            }

            VCCB_PRINT_CALL_ERROR(ptCi, "DU Init Full Configuration by Not supported (state:%d, stateCmd:%u)\n", ptCi->state, ptCi->stateCmd);
            return BREAK;

        default:
        case ERROR:
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_IsSupportDuInitFullConfigurationUE Error! (status:%d)\n", status);
            return ERROR;
    }
}

/**
 * @brief      This function determines whether to allow the SN Init Full Configuration UE.
 */
int16_t FnVCCB_IsSupportSnInitFullConfigurationUE(callInfo_type *ptCi)
{  /// {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // 2) Full Configuration means a situation where a trigger is required. (Message Based Trigger)
    if (VCCB_GET_FULLCONFIGURATION(ptCi, ci_fc_sn_init_trigger) == TRUE)
    {
        // 2-1) Full configuration is supported. After that, proceed to Full Configuration operation. Detailed scenarios
        // are defined by each scenario manager.
        if (VCCM_check_FullConfiguration_Supported_Scenario(ptCi, e_SnInitFullConfig, NULL) == TRUE)
        {
            VCCB_PRINT_CALL_INFORMATIVE(
                ptCi, "FullConfiguration scenario detected. SN Init FullConfiguration operates. (Cause: Supported)\n");
            return GOOD;  // Allowed :: Supported UE.
        }
        // 2-2) Full configuration is not supported. Perform the reject procedure. Detailed procedures accordingly are
        // defined by the scenario manager.
        //     Handover Preparation Failure(HO Case), RRC Setup(RRE Case)
        else
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                "FullConfiguration scenario detected. But Not Allowd SN Init FullConfiguration. (Cause: Not Supported)\n");
            return BREAK;  // Not Allowed :: Not Supported UE.
        }
    }
    // 3) This means that full configuration is not required.
    else
    {
        return GOOD;  // Normal UE, Not Full Configuration UE.
    }
}  // }}}

int16_t FnVCCB_ProcSnInitFullConfiguration(
    callInfo_type *ptCi,
    const message_type *ptAll,
    const msgUnpack_type *ptUnpack,
    const bool withLoggingFlag)
{
    //int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR_PARAM3(ptCi, ptAll, ptUnpack);

    // Check if there is a full configuration IE.
    auto isExistXNFullConfiguration = [&ptUnpack]() -> bool
    {
        switch(ptUnpack->msgId)
        {
            case XN_SNodeAdditionRequestAcknowledge_id:
                {
                    auto *ptMsg = (XN_SNodeAdditionRequestAcknowledge_type *)ptUnpack->unpack;

                    if (ptMsg->m.rRCConfigIndicationPresent == OPT_PRESENT)
                    {
                        if (ptMsg->rRCConfigIndication == XNAP_full_config)
                        {
                            return true;
                        }
                    }

                    return false;
                }

            case XN_SNodeModificationRequestAcknowledge_id:
                {
                    auto *ptMsg = (XN_SNodeModificationRequestAcknowledge_type *)ptUnpack->unpack;

                    if (ptMsg->m.rRCConfigIndicationPresent == OPT_PRESENT)
                    {
                        if (ptMsg->rRCConfigIndication == XNAP_full_config)
                        {
                            return true;
                        }
                    }

                    return false;
                }

            case XN_SNodeModificationRequired_id:
                {
                    auto *ptMsg = (XN_SNodeModificationRequired_type *)ptUnpack->unpack;

                    if (ptMsg->m.rRCConfigIndicationPresent == OPT_PRESENT)
                    {
                        if (ptMsg->rRCConfigIndication == XNAP_full_config)
                        {
                            return true;
                        }
                    }

                    return false;
                }

            default:
                return false;
        }
    };

    // If there is no full configuration IE, there is no need to proceed with the operation in this function.
    if (isExistXNFullConfiguration() == false)
    {
        if (VCCM_ForceFullConfigOverXn(ptCi, __func__, false))
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[Full Config TEST] force SN-init full config\n");
        }
        else
        {
            return GOOD;
        }
    }

    // If it is CU or DU Init FullConfiguration, no more operation is required.
    if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi))
    {
        return GOOD;
    }

#if 0        
    // If support is needed by distinguishing scenarios, this code activation is required.
    status = FnVCCB_SetSnInitFullConfig(ptCi);
    switch(status)
    {
        case GOOD:
            break;

        case BREAK:
            if (DBG->flag.logFullConfig)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "SN Init Full Configuration by not registered scenario (state:%d, stateCmd:%u)\n", ptCi->state, ptCi->stateCmd);
            }
            return BREAK;

        default:
        case ERROR:
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_SetSnInitFullConfig Error! (status:%d)\n", status);
            return ERROR;
    }

    // Check if the current scenario supports FullConfiguration.
    status = FnVCCB_IsSupportSnInitFullConfigurationUE(ptCi);
    switch(status)
    {
        case GOOD: // Support
            return GOOD;

        case BREAK: // Not Support

            // if Determines whether to call the logging function.
            // This is necessary when the store function is not called and it is restricted in advance.
            if (withLoggingFlag == true)
            {
                FnVCCB_SaveAndUpdateXnMessageWithLogging(ptCi, ptAll, ptUnpack);
            }

            VCCB_PRINT_CALL_ERROR(ptCi, "SN Init Full Configuration by Not supported (state:%d, stateCmd:%u)\n", ptCi->state, ptCi->stateCmd);
            return BREAK;

        default:
        case ERROR:
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_IsSupportSnInitFullConfigurationUE Error! (status:%d)\n", status);
            return ERROR;
    }
#else
    // if Determines whether to call the logging function.
    // This is necessary when the store function is not called and it is restricted in advance.
    if (withLoggingFlag == true)
    {
        FnVCCB_SaveAndUpdateXnMessageWithLogging(ptCi, ptAll, ptUnpack);
    }

    VCCB_PRINT_CALL_ERROR(ptCi, "SN Init Full Configuration by Not supported (state:%d, stateCmd:%u)\n", ptCi->state, ptCi->stateCmd);
    return BREAK;
#endif

    return GOOD;
}

bool FnVCCM_get_deltaConfig_NRRRC_OtherConfig_v1800(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // idc-AssistanceConfig-v1800                       Need M
    if (ptCi->fullConfiguration.interwork.idc_AssistanceConfig_v1800)
    {
        return true;
    }

    // multiRx-PreferenceReportingConfigFR2-r18         Need M
    if (ptCi->fullConfiguration.interwork.multiRx_PreferenceReportingConfigFR2_r18)
    {
        return true;
    }

    // aerial-FlightPathAvailabilityConfig-r18          Need R

    // ul-TrafficInfoReportingConfig-r18                Need M
    if (ptCi->fullConfiguration.interwork.ul_TrafficInfoReportingConfig_r18)
    {
        return true;
    }

    // n3c-RelayUE-InfoReportConfig-r18                 Need R

    // successPSCell-Config-r18                         Need M
    if (ptCi->fullConfiguration.interwork.successPSCell_Config_r18)
    {
        return true;
    }

    // sn-InitiatedPSCellChange-r18                     Need R
    
    // musim-GapPriorityAssistanceConfig-r18            Cond musimGapConfig (if musim-GapAssistanceConfig-r17 is configured)

    // musim-CapabilityRestrictionConfig-r18            Need M
    if (ptCi->fullConfiguration.interwork.musim_CapabilityRestrictionConfig_r18)
    {
        return true;
    }

    return false;
}  // }}}

bool FnVCCM_get_deltaConfig_NRRRC_RRCReconfiguration_v1800(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // needForInterruptionConfigNR-r18              Need M
    if (ptCi->fullConfiguration.interwork.needForInterruptionConfigNR_r18)
    {
        return true;
    }

    // aerial-Config-r18                            Need M
    if (ptCi->fullConfiguration.interwork.aerial_Config_r18)
    {
        return true;
    }

    // sl-IndirectPathAddChange-r18                 Need M
    if (ptCi->fullConfiguration.interwork.sl_IndirectPathAddChange_r18)
    {
        return true;
    }

    // n3c-IndirectPathAddChange-r18                Need M
    if (ptCi->fullConfiguration.interwork.n3c_IndirectPathAddChange_r18)
    {
        return true;
    }

    // n3c-IndirectPathConfigRelay-r18              Need M
    if (ptCi->fullConfiguration.interwork.n3c_IndirectPathConfigRelay_r18)
    {
        return true;
    }

    // otherConfig-v1800                            Need M
    if (FnVCCM_get_deltaConfig_NRRRC_OtherConfig_v1800(ptCi))
    {
        return true;
    }

    // srs-PosResourceSetAggBW-CombinationList-r18  Need M
    if (ptCi->fullConfiguration.interwork.srs_PosResourceSetAggBW_CombinationList_r18)
    {
        return true;
    }

    // ltm-Config-r18                               Need M
    if (ptCi->fullConfiguration.interwork.ltm_Config_r18)
    {
        return true;
    }

#if F_StandardConformance_AsnNRRRC >= 183000
    // nonCriticalExtension (v1830)
    if (FnVCCM_get_deltaConfig_NRRRC_RRCReconfiguration_v1830(ptCi))
    {
        return true;
    }
#endif

    return false;
}

#if F_StandardConformance_AsnNRRRC >= 183000
bool FnVCCM_get_deltaConfig_NRRRC_OtherConfig_v1830(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // sl-PRS-AssistanceConfigNR-r18                Need R (not checked)

    return false;
}  // }}}

bool FnVCCM_get_deltaConfig_NRRRC_RRCReconfiguration_v1830(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // otherConfig-v1830                            Need M
    if (FnVCCM_get_deltaConfig_NRRRC_OtherConfig_v1830(ptCi))
    {
        return true;
    }

    return false;
}
#endif

bool FnVCCM_get_deltaConfig_NRRRC_OtherConfig_v1700(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (ptCi->fullConfiguration.interwork.musim_GapAssistanceConfig_r17)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.musim_LeaveAssistanceConfig_r17)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.successHO_Config_r17)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.rlm_RelaxationReportingConfig_r17)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.bfd_RelaxationReportingConfig_r17)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.rrm_MeasRelaxationReportingConfig_r17)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.propDelayDiffReportConfig_r17)
    {
        return true;
    }

    return false;
}  // }}}

bool FnVCCM_get_deltaConfig_NRRRC_RRCReconfiguration_v1700(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (FnVCCM_get_deltaConfig_NRRRC_OtherConfig_v1700(ptCi))
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.sl_L2RelayUE_Config_r17)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.sl_L2RemoteUE_Config_r17)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.needForGapNCSG_ConfigNR_r17)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.needForGapNCSG_ConfigEUTRA_r17)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.musim_GapConfig_r17)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.ueTxTEG_RequestUL_TDOA_Config_r17)
    {
        return true;
    }
    if (FnVCCM_get_deltaConfig_NRRRC_RRCReconfiguration_v1800(ptCi))
    {
        return true;
    }

    return false;
}

bool FnVCCM_get_deltaConfig_NRRRC_OtherConfig_v1610(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (ptCi->fullConfiguration.interwork.idc_AssistanceConfig_r16)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.drx_PreferenceConfig_r16)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.minSchedulingOffsetPreferenceConfig_r16)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.btNameList_r16)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.wlanNameList_r16)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.sensorNameList_r16)
    {
        return true;
    }

    return false;
}  // }}}

bool FnVCCM_get_deltaConfig_NRRRC_RRCReconfiguration_v1610(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    if (FnVCCM_get_deltaConfig_NRRRC_OtherConfig_v1610(ptCi))
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.bap_Config_r16)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.t316_r16)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.onDemandSIB_Request_r16)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.sl_ConfigDedicatedNR_r16)
    {
        return true;
    }
    if (ptCi->fullConfiguration.interwork.sl_ConfigDedicatedEUTRA_Info_r16)
    {
        return true;
    }

    if (FnVCCM_get_deltaConfig_NRRRC_RRCReconfiguration_v1700(ptCi))
    {
        return true;
    }

    return false;
}  // }}}

// }}}
/********************************************************************************
 * @brief This area is the section for Force Selection operation of Full Configuration DB.
 ********************************************************************************/
// {{{

/**
 * @brief      This function is used for the operation to forcefully set the Full Configuration in a specific
 * case(Function Name + Line).
 * @param      func_name : The name of the calling function
 * @param      line : The line of the calling file
 * @return     TRUE on force selction trigger, otherwise not trigger.
 */
int VCCM_check_FullConfiguration_Filter(const char *func_name, int line)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(func_name);

    for (int i = 0; i < MIN(CFG->fullConfig.filter.num, VCCB_MAX_NUM_FC_FILTER); i++)
    {
        if (CFG->fullConfig.filter.info[i].line == line)
        {
            if (!strcasecmp(CFG->fullConfig.filter.info[i].func_name, func_name))
            {
                return TRUE;
            }
        }
    }

    return FALSE;
}  // }}}

VCCB_STATIC
int VCCM_check_FullConfiguration_Common(callInfo_type *ptCi, VccbFullConfigScenario_type *pTarget, enumFullConfigTrigger_type eType, const cellSelection_type *pTargetCellSelection)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(pTarget);

    if (pTarget->SecnarioEvent_Usage == 0) return FALSE;

    // ENDC-SN, NSA
    if (IS_ENDC_SN(ptCi))
    {
        return FnVCCB_IsEndcUeSupportFullConfigScenario(*ptCi, *pTarget);
    }

    // NRDC-SN, SA
    if (IS_NRDC_SN(ptCi))
    {
        return FnVCCB_IsNrdcSnUeSupportFullConfigScenario(*ptCi, *pTarget, eType, pTargetCellSelection);
    }

    // SA, NRDC-MN, NEDC-MN
    {
        // SN Init Full Configuration Not Support
        if (eType == e_SnInitFullConfig)
        {
            return FALSE;
        }

        if (VHCM_isSaHandoverUE(ptCi) == TRUE)
        {
            return FnVCCB_IsSaHandoverUeSupportFullConfigScenario(*ptCi, *pTarget, eType);
        }

        if (ptCi->stateCmd == RrcReestablish_cmd)
        {
            return FnVCCB_IsRreUESupportFullConfigScenario(*ptCi, *pTarget, eType);
        }

        // SVR25A FGR-MC1020: for RRC Inactive
        // Using ptCi->stateCmd with RRCResume_cmd is impossible in the inter-gNB case.
        // Because, while deciding full config, it is still saved as Idle_cmd.
        if (ptCi->ueInfo.rrcResumeInfo.resumeType == RESUME_TYPE_INTRA_GNB ||
            ptCi->ueInfo.rrcResumeInfo.resumeType == RESUME_TYPE_INTER_GNB_TARGET)
        {
            return FnVCCB_IsRrcResumeUESupportFullConfigScenario(*ptCi, *pTarget, eType);
        }
    }

    return FALSE;
}

VCCB_STATIC
bool FnVCCB_IsEndcUeSupportFullConfigScenario(const callInfo_type &callInfo, VccbFullConfigScenario_type &scenario)
{
    if (IntraRatHO_cmd == callInfo.stateCmd)
    {
        if (HO_TYPE_INTRA_NB == callInfo.hoInfo.hoType.nb)
        {
            if (callInfo.hoInfo.hoType.du == HO_TYPE_INTER_DU)
            {
                return (scenario.EventScenario_NSA_InterDuPSCellChange) ? true : false;
            }

            if (callInfo.hoInfo.hoType.du == HO_TYPE_INTRA_DU)
            {
                return (scenario.EventScenario_NSA_IntraDuPSCellChange) ? true : false;
            }
        }
    }

    if (SgNBAddition_cmd == callInfo.stateCmd)
    {
        return (scenario.EventScenario_NSA_SgNBAddition) ? true : false;
    }

    return false;
}

VCCB_STATIC
bool FnVCCB_IsNrdcSnUeSupportFullConfigScenario(const callInfo_type &callInfo, VccbFullConfigScenario_type &scenario, enumFullConfigTrigger_type eType, const cellSelection_type *pTargetCellSelection)
{
    // NRDC-SN -> Mn/SnInit Intra-SN Mobility (CU Init)
    // if (IntraRatHO_cmd == callInfo.stateCmd)
    if (pTargetCellSelection)
    {
        //if (callInfo.hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
        if (pTargetCellSelection->cellNum < MAX_CELL_NUM_VCCB)
        {
            //if (callInfo.hoInfo.hoType.du == HO_TYPE_INTRA_DU)
            if (CELLINFO[pTargetCellSelection->cellNum].endPointF1Index == callInfo.endPointInfo.f1Idx)
            {
                return (scenario.EventScenario_NRDC_SN_IntraDuPSCellChange) ? true : false;
            }

            return (scenario.EventScenario_NRDC_SN_InterDuPSCellChange) ? true : false;
        }
    }

    // NRDC-SN -> Mn/SnInit Intra-SN Mobility (DU Init)
    if (IntraRatHO_cmd == callInfo.stateCmd)
    {
        if (callInfo.hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
        {
            switch (callInfo.state)
            {
                case STATE_SN_INTRA_DU_Prepare:
                    return (scenario.EventScenario_NRDC_SN_IntraDuPSCellChange_DuInit) ? true : false;

                case STATE_SN_INTER_DU_Prepare:
                    return (scenario.EventScenario_NRDC_SN_InterDuPSCellChange_DuInit) ? true : false;

                default:
                    break;
            }
        }
    }

    // NRDC-SN -> Inter-SN Basic
    if (MrdcXnSNAdd_cmd == callInfo.stateCmd)
    {
        if (callInfo.hoInfo.sgnbAddTrigInd != SgnbAddTrigInd_Unknown)
        {
            if (eType == e_DuInitFullConfig)
            {
                switch (callInfo.state)
                {
                    case STATE_II:                      // Send F1_UEContextSetupRequest (SN Term Not Exist)
                    case STATE_SN_SNAddPrepare_E1Setup: // Send F1_UEContextSetupRequest (SN Term Exist)
                    case STATE_SN_SNAddPrepare_F1Setup: // Recived F1_UEContextSetupResponse
                        return (scenario.EventScenario_NRDC_SN_SNodeAddition_DuInit) ? true : false;

                    default:
                        break;
                }
            }
            else
            {
                return (scenario.EventScenario_NRDC_SN_SNodeAddition) ? true : false;
            }
        }
    }

    return false;
}

VCCB_STATIC
bool FnVCCB_IsRreUESupportFullConfigScenario(const callInfo_type &callInfo, VccbFullConfigScenario_type &scenario, enumFullConfigTrigger_type /*eType*/)
{
    if (callInfo.ueInfo.reestablishInfo.reestablishType == RRE_TYPE_INTER_GNB)
    {
        return (scenario.EventScenario_SA_InterGnbRRE) ? true : false;
    }

    if (callInfo.ueInfo.reestablishInfo.reestablishType == RRE_TYPE_INTRA_DU)
    {
        return (scenario.EventScenario_SA_IntraGnbRRE) ? true : false;
    }

    if (callInfo.ueInfo.reestablishInfo.reestablishType == RRE_TYPE_INTER_DU)
    {
        return (scenario.EventScenario_SA_IntraGnbRRE) ? true : false;
    }

    return false;
}

// SVR25A FGR-MC1020
VCCB_STATIC
bool FnVCCB_IsRrcResumeUESupportFullConfigScenario(
    const callInfo_type &callInfo, VccbFullConfigScenario_type &scenario, enumFullConfigTrigger_type /*eType*/)
{
    switch (callInfo.state)
    {
        case STATE_Inact_T_XnUeContextReq:
            return (scenario.EventScenario_SA_InterGnbResume_CuInit) ? true : false;
            break;

        case STATE_Inact_Suspend:
        case STATE_Inact_ResumeReq:
            if (callInfo.ueInfo.rrcResumeInfo.resumeType == RESUME_TYPE_INTRA_GNB)
            {
                return (scenario.EventScenario_SA_IntraGnbResume_CuInit) ? true : false;
            }
            break;

        case STATE_Inact_F1Setup:
            if (callInfo.ueInfo.rrcResumeInfo.resumeType == RESUME_TYPE_INTRA_GNB)
            {
                return (scenario.EventScenario_SA_IntraGnbResume_DuInit) ? true : false;
            }
            else if (callInfo.ueInfo.rrcResumeInfo.resumeType == RESUME_TYPE_INTER_GNB_TARGET)
            {
                return (scenario.EventScenario_SA_InterGnbResume_DuInit) ? true : false;
            }
            break;

        default:
            break;
    }

    return false;
}

VCCB_STATIC
bool FnVCCB_IsSaHandoverUeSupportFullConfigScenario(
    const callInfo_type &callInfo, VccbFullConfigScenario_type &scenario, enumFullConfigTrigger_type /*eType*/)
{
    bool isMrdcMn = IS_MRDC_MN(&callInfo);

    // SA -> Inter-gNB Handover
    // NRDC-MN, NEDC-MN -> Inter-MN Init Mobility
    if (callInfo.hoInfo.hoType.nb == HO_TYPE_INTER_NB)
    {
        switch(callInfo.state)
        {
            case STATE_MN_INTER_SN_Pre_SN:
            case STATE_INTER_Pre_SN_T: 
                if (isMrdcMn == true) return (scenario.EventScenario_MRDC_MN_MnInit)? true : false;
                break;

            case STATE_INTER_Pre_DU_T:
                if (isMrdcMn == true) return (scenario.EventScenario_MRDC_MN_InterGnbHandover_DuInit) ? true : false;

                return (scenario.EventScenario_SA_InterGnbHandover_DuInit) ? true : false;

            default:
                if (isMrdcMn == true) return (scenario.EventScenario_MRDC_MN_InterGnbHandover) ? true : false;

                return (scenario.EventScenario_SA_InterGnbHandover) ? true : false;
        }
    }

    // SA -> Intra-gNB Handover
    // NRDC-MN, NEDC-MN -> Intra-MN Init Mobility
    if (callInfo.hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
    {
        switch (callInfo.state)
        {
            case STATE_INTRA_DU_SnAdd:
            case STATE_INTER_DU_SnAdd:
                if (isMrdcMn == true)
                {
                    return (scenario.EventScenario_MRDC_MN_MnInit)? true : false;
                }
                break;

            case STATE_INTRA_DU_Prepare:
                if (isMrdcMn == true)
                {
                    return (scenario.EventScenario_MRDC_MN_IntraGnbIntraDuHandover_DuInit) ? true : false;
                }

                return (scenario.EventScenario_SA_IntraGnbIntraDuHandover_DuInit) ? true : false;

            case STATE_INTER_DU_Prepare:
                if (isMrdcMn == true)
                {
                    return (scenario.EventScenario_MRDC_MN_IntraGnbInterDuHandover_DuInit) ? true : false;
                }

                return (scenario.EventScenario_SA_IntraGnbInterDuHandover_DuInit) ? true : false;

            default:
                if (callInfo.hoInfo.hoType.du == HO_TYPE_INTRA_DU)
                {
                    if (isMrdcMn == true)
                    {
                        return (scenario.EventScenario_MRDC_MN_IntraGnbIntraDuHandover) ? true : false;
                    }

                    return (scenario.EventScenario_SA_IntraGnbIntraDuHandover) ? true : false;
                }
                else
                {
                    if (isMrdcMn == true)
                    {
                        return (scenario.EventScenario_MRDC_MN_IntraGnbInterDuHandover) ? true : false;
                    }

                    return (scenario.EventScenario_SA_IntraGnbInterDuHandover) ? true : false;
                }
        }
    }
    return false;
}

VCCB_STATIC
int VCCM_check_FullConfiguration_Forced_Scenario(callInfo_type *ptCi, enumFullConfigTrigger_type eType, const cellSelection_type *pTargetCellSelection)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    return VCCM_check_FullConfiguration_Common(ptCi, &CFG->fullConfig.dbg.forcedTriggerScenario, eType, pTargetCellSelection);
}

VCCB_STATIC
int VCCM_check_FullConfiguration_Supported_Scenario(callInfo_type *ptCi, enumFullConfigTrigger_type eType, const cellSelection_type *pTargetCellSelection)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    return VCCM_check_FullConfiguration_Common(ptCi, &CFG->fullConfig.support.scenario, eType, pTargetCellSelection);
}

/**
 * @brief      This function is used for the operation to forcefully set the Full Configuration in a specific
 * case(Scenario).
 * @param      ptCi : call context
 * @return     TRUE on force selction trigger, otherwise not trigger.
 */

VCCB_STATIC
void VCCM_trigger_FullConfiguration_Forced_Scenario(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    int drbId;

    // store prev
    fullConfiguration_type prevFullCfg = ptCi->fullConfiguration;

    // init current value
    VLIB_InitFullConfigurationInfo(ptCi);

    // Record with Full Configuration UE.
    VCCB_SET_FULLCONFIGURATION(ptCi, ci_fc_trigger, "All, Scenario::Forced Mode (CU Init)");

    for (drbId = 1; drbId <= 32; drbId++)
    {
        // Record that it is Full Configuration by Rammapping by DRB. TODO: Not currently in use.
        if (GETBIT(CFG->fullConfig.dbg.drb_remapping, drbId - 1))
        {
            VCCB_SET_FULLCONFIGURATION_DRB(
                ptCi, ci_fc_drb_remapping, drbId, "All, Scenario::Forced Mode(DRB, ramapping)");
        }

        // Record that it is Full Configuration by Disabled Forward by DRB.
        if (GETBIT(CFG->fullConfig.dbg.drb_disable_datafwd, drbId - 1))
        {
            VCCB_SET_FULLCONFIGURATION_DRB(
                ptCi, ci_fc_drb_disable_datafwd, drbId, "All, Scenario::Forced Mode(DRB, disable datafwd)");
        }
    }

    // If the existing information is changed, the changed information is displayed.
    if (memcmp(&prevFullCfg, &ptCi->fullConfiguration, sizeof(fullConfiguration_type)) != 0)
    {
        VCCB_PRINT_CALL_MSG(ptCi, "Full Configuration Forced Update!!(%d,0x%X) -> (%d,0x%X)\n", prevFullCfg.action,
            prevFullCfg.drbId_disableFwd, ptCi->fullConfiguration.action, ptCi->fullConfiguration.drbId_disableFwd);
    }
}  // }}}

VCCB_STATIC
void VCCM_trigger_FullConfiguration_Forced_Scenario_DuInit(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    int drbId;

    // store prev
    fullConfiguration_type prevFullCfg = ptCi->fullConfiguration;

    // init current value
    VLIB_InitFullConfigurationInfo(ptCi);

    // Record with Full Configuration UE.
    VCCB_SET_FULLCONFIGURATION(ptCi, ci_fc_du_init_trigger, "All, Scenario::Forced Mode (DU Init)");

    for (drbId = 1; drbId <= 32; drbId++)
    {
        // Record that it is Full Configuration by Rammapping by DRB. TODO: Not currently in use.
        if (GETBIT(CFG->fullConfig.dbg.drb_remapping, drbId - 1))
        {
            VCCB_SET_FULLCONFIGURATION_DRB(
                ptCi, ci_fc_drb_remapping, drbId, "All, Scenario::Forced Mode(DRB, ramapping)");
        }

        // Record that it is Full Configuration by Disabled Forward by DRB.
        if (GETBIT(CFG->fullConfig.dbg.drb_disable_datafwd, drbId - 1))
        {
            VCCB_SET_FULLCONFIGURATION_DRB(
                ptCi, ci_fc_drb_disable_datafwd, drbId, "All, Scenario::Forced Mode(DRB, disable datafwd)");
        }
    }

    // If the existing information is changed, the changed information is displayed.
    if (memcmp(&prevFullCfg, &ptCi->fullConfiguration, sizeof(fullConfiguration_type)) != 0)
    {
        VCCB_PRINT_CALL_MSG(ptCi, "Full Configuration Forced Update!!(%d,0x%X) -> (%d,0x%X)\n", prevFullCfg.action,
            prevFullCfg.drbId_disableFwd, ptCi->fullConfiguration.action, ptCi->fullConfiguration.drbId_disableFwd);
    }
}  // }}}

// }}}
/********************************************************************************
 * @brief This section describes the operation to control DU Init Full Configuration.
 ********************************************************************************/
// {{{

int16_t FnVCCB_SetDuInitFullConfig(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    /* check the state to handle it */
    switch (ptCi->stateCmd)
    {
        case IntraRatHO_cmd:
        case RrcReestablish_cmd:
        case SgNBAddition_cmd:
        case MrdcXnSNAdd_cmd:
        case RRCResume_cmd:             // SVR25A FGR-MC1020
            /* need to check the capability of du init full config */
            break;

        default:
            /* no action : need to check the Resume procedures */
            return GOOD;
    }

    // get full config status
    if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi))
    {
        /* gNB already triggers the CU or SN init full configuration. */
        return GOOD;
    }
    else
    {
        /* gNB doesn't support the DU init full configuration */
        /* TODO : You need to check the SA or NSA case to allow it */
        if (E_CALLTYPE_NSA == ptCi->callType || IS_NRDC_SN(ptCi))
        {
            if (IntraRatHO_cmd == ptCi->stateCmd)
            {
                if (VCCB_NSA_IsInterDuNoScgHo(*ptCi))
                {
                    VCCB_PRINT_CALL_INFORMATIVE(
                        ptCi, "%s: ignore full config IE during inter-DU HO w/o source DU.\n", __FUNCTION__);
                    return GOOD;
                }

                switch(ptCi->state)
                {
                    case STATE_DCInterDuHo_F1UeCtxSetReq:
                        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "DU initiatied FullConfig Inter-DU PSCell Change!\n");
                        VCCB_SET_FULLCONFIGURATION(ptCi, ci_fc_du_init_trigger, "NSA, F1AP::FullConfiguration(DuInit)");
                        break;

                    case STATE_SN_INTER_DU_Prepare:
                        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "DU initiatied FullConfig Inter-DU PSCell Change!\n");
                        VCCB_SET_FULLCONFIGURATION(ptCi, ci_fc_du_init_trigger, "SA(NRDC-SN), F1AP::FullConfiguration(DuInit)");
                        break;

                    case STATE_SN_INTRA_DU_Prepare:
                        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "DU initiatied FullConfig Intra-DU PSCell Change!\n");
                        VCCB_SET_FULLCONFIGURATION(ptCi, ci_fc_du_init_trigger, "SA(NRDC-SN), F1AP::FullConfiguration(DuInit)");
                        break;

                    default:
                        break;
                }

                return GOOD;
            }
            else if (SgNBAddition_cmd == ptCi->stateCmd)
            {
                if ((STATE_DCF1Setup_S == ptCi->state) && (IS_CELLGROUPCONFIG_FULL(ptCi)))
                // Only when sourceConfigSCG is transmitted
                {
                    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "DU initiatied FullConfig during SgNBAddition!\n");
                    VCCB_SET_FULLCONFIGURATION(ptCi, ci_fc_du_init_trigger, "NSA, F1AP::FullConfiguration(DuInit)");
                }
                
                return GOOD;
            }
            else if (MrdcXnSNAdd_cmd == ptCi->stateCmd)
            {
                if ((STATE_SN_SNAddPrepare_F1Setup == ptCi->state) && (IS_CELLGROUPCONFIG_FULL(ptCi)))
                // Only when sourceConfigSCG is transmitted
                {
                    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "DU initiatied FullConfig during SnodeAddition!\n");
                    VCCB_SET_FULLCONFIGURATION(ptCi, ci_fc_du_init_trigger, "SA(NRDC-SN), F1AP::FullConfiguration(DuInit)");
                }
                
                return GOOD;
            }
        }
        else
        {
            // IF SA Handover UE
            if (VHCM_isSaHandoverUE(ptCi) == TRUE)
            {
                if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTER_NB)
                {
                    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "DU initiatied FullConfig Inter-GNB Change!!\n");
                    VCCB_SET_FULLCONFIGURATION(ptCi, ci_fc_du_init_trigger, "SA, F1AP::Inter-GNB::FullConfiguration(DuInit)");
                }
                else
                {
                    if (HO_TYPE_INTER_DU == ptCi->hoInfo.hoType.du)
                    {
                        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "DU initiatied FullConfig Intra-GNB Inter-DU Change!!\n");
                        VCCB_SET_FULLCONFIGURATION(ptCi, ci_fc_du_init_trigger, "SA, F1AP::Intra-GNB::Inter-DU::FullConfiguration(DuInit)");
                    }
                    else
                    {
                        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "DU initiatied FullConfig Intra-GNB Intra-DU Change!!\n");
                        VCCB_SET_FULLCONFIGURATION(ptCi, ci_fc_du_init_trigger, "SA, F1AP::Intra-GNB::Intra-DU::FullConfiguration(DuInit)");
                    }
                }

                return GOOD;
            }
            // SVR25A FGR-MC1020
            else if (ptCi->stateCmd == RRCResume_cmd)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "DU initiatied FullConfig in RRC Resume!!\n");
                VCCB_SET_FULLCONFIGURATION(ptCi, ci_fc_du_init_trigger, "SA(RRCResume), F1AP::FullConfiguration(DuInit)");

                return GOOD;
            }
        }

        return BREAK;
    }
}  // }}}

// }}}
/********************************************************************************
 * @brief This section describes the operation to control SN Init Full Configuration.
 ********************************************************************************/
// {{{

int16_t FnVCCB_SetSnInitFullConfig(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // FGR-MC1020, FR81.CACP.SR1.HD1.DD1
    VCCB_SET_FULLCONFIGURATION(ptCi, ci_fc_sn_init_trigger, "SN, XN::RrcConfigIndication = fullconfig");

    return GOOD;
}  // }}}

// }}}
/********************************************************************************
 * @brief In this section, it checks whether an IE/MSG that requires full configuration is received.
 ********************************************************************************/
// {{{

VCCB_STATIC
void VCCM_Check_NRRRC_PDCP_Config_ForDRB(callInfo_type *ptCi, int drbId, NRRRC_PDCP_Config *p)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    // drb
    if (NRRRC_drb_present & p->bit_mask)
    {
        // discardTimer

        if (CFG->fullConfig.support.flag.F_21B_PDCP_SN_12BIT == Not_Allowed)
        {
            // pdcp-SN-SizeUL
            if (NRRRC_pdcp_SN_SizeUL_present & p->drb.bit_mask)
            {
                if (p->drb.pdcp_SN_SizeUL == NRRRC_len12bits)
                {
                    // full configration
                    VCCB_SET_FULLCONFIGURATION_DRB(
                        ptCi, ci_fc_trigger, drbId, "SA, RRC::PDCP-Config::pdcp_SN_SizeUL(12)");
                }
            }

            // pdcp-SN-SizeDL
            if (NRRRC_pdcp_SN_SizeDL_present & p->drb.bit_mask)
            {
                if (p->drb.pdcp_SN_SizeDL == NRRRC_len12bits)
                {
                    // full configration
                    VCCB_SET_FULLCONFIGURATION_DRB(
                        ptCi, ci_fc_trigger, drbId, "SA, RRC::PDCP-Config::pdcp_SN_SizeDL(12)");
                }
            }
        }

        // headerCompression {
        //     notUsed
        //     rohc {
        //         maxCID
        //         profiles {
        //             profile0x0001
        //             profile0x0002
        //             profile0x0003
        //             profile0x0004
        //             profile0x0006
        //             profile0x0101
        //             profile0x0102
        //             profile0x0103
        //             profile0x0104
        //         },
        //         drb-ContinueROHC
        //     },
        //     uplinkOnlyROHC {
        //         maxCID
        //         profiles {
        //             profile0x0006
        //         },
        //         drb-ContinueROHC
        //     },
        //     ...
        // },
        // integrityProtection
        // statusReportRequired
        // outOfOrderDelivery
        //}
    }

    // moreThanOneRLC {
    //     primaryPath {
    //         cellGroup
    //         logicalChannel
    //    },
    //    ul-DataSplitThreshold
    //    pdcp-Duplication
    //}

    // t-Reordering
    // [[
    // cipheringDisabled
    // ]]

}  // }}}

VCCB_STATIC
void VCCM_Check_NRRRC_DRB_ToAddMod(callInfo_type *ptCi, NRRRC_DRB_ToAddMod *p)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    // 1. cnAssociation                           CHOICE {
    //    eps-BearerIdentity                      INTEGER (0..15),
    //    sdap-Config                             SDAP-Config
    // }
    // 2. drb-Identity : no action
    // 3. reestablishPDCP 
    // 4. recoverPDCP : no action
    // 5. pdcp-Config
    if (NRRRC_DRB_ToAddMod_pdcp_Config_present & p->bit_mask)
    {
        VCCM_Check_NRRRC_PDCP_Config_ForDRB(ptCi, p->drb_Identity, &p->pdcp_Config);
    }

}  // }}}

VCCB_STATIC
void VCCM_Check_NRRRC_RadioBearerConfig(callInfo_type *ptCi, NRRRC_RadioBearerConfig *p)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    // srb-ToAddModList : no action
    // srb3-ToRelease : no action

    // drb-ToAddModList
    if (NRRRC_drb_ToAddModList_present & p->bit_mask)
    {
        struct NRRRC_DRB_ToAddModList_ *drb_ToAddModList = p->drb_ToAddModList;
        for (; NULL != drb_ToAddModList; drb_ToAddModList = drb_ToAddModList->next)
        {
            VCCM_Check_NRRRC_DRB_ToAddMod(ptCi, &drb_ToAddModList->value);
        }
    }

    // drb-ToReleaseList : no action
    // securityConfig : no action

}  // }}}

/* TODO: If you need to use this function, unannotate it and use it.
VCCB_STATIC
void VCCM_Check_NRRRC_OtherConfig_v1800(callInfo_type *ptCi, NRRRC_OtherConfig_v1800 *p)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    // idc-AssistanceConfig-v1800                   Need M
    CHECK_N_SET_FULLCONFIGURATION(
        p->bit_mask, NRRRC_idc_AssistanceConfig_v1800_present, "SA, RRC::OtherConfig_v1800");
    
    // multiRx-PreferenceReportingConfigFR2-r18     Need M
    CHECK_N_SET_FULLCONFIGURATION(
        p->bit_mask, NRRRC_multiRx_PreferenceReportingConfigFR2_r18_present, "SA, RRC::OtherConfig_v1800");
    
    // aerial-FlightPathAvailabilityConfig-r18      Need R
    CHECK_N_SET_FULLCONFIGURATION(
        p->bit_mask, NRRRC_aerial_FlightPathAvailabilityConfig_r18_present, "SA, RRC::OtherConfig_v1800");
    
    // ul-TrafficInfoReportingConfig-r18            Need M
    CHECK_N_SET_FULLCONFIGURATION(
        p->bit_mask, NRRRC_ul_TrafficInfoReportingConfig_r18_present, "SA, RRC::OtherConfig_v1800");
    
    // n3c-RelayUE-InfoReportConfig-r18             Need R
    CHECK_N_SET_FULLCONFIGURATION(
        p->bit_mask, NRRRC_n3c_RelayUE_InfoReportConfig_r18_present, "SA, RRC::OtherConfig_v1800");
    
    // successPSCell-Config-r18                     Need M
    CHECK_N_SET_FULLCONFIGURATION(
        p->bit_mask, NRRRC_OtherConfig_v1800_successPSCell_Config_r18_present, "SA, RRC::OtherConfig_v1800");
    
    // sn-InitiatedPSCellChange-r18                 Need R
    CHECK_N_SET_FULLCONFIGURATION(
        p->bit_mask, NRRRC_OtherConfig_v1800_sn_InitiatedPSCellChange_r18_present, "SA, RRC::OtherConfig_v1800");
    
    // musim-GapPriorityAssistanceConfig-r18        Cond musimGapConfig (if musim-GapAssistanceConfig-r17 is configured)
    CHECK_N_SET_FULLCONFIGURATION(
        p->bit_mask, NRRRC_musim_GapPriorityAssistanceConfig_r18_present, "SA, RRC::OtherConfig_v1800");
    
    // musim-CapabilityRestrictionConfig-r18        Need M
    CHECK_N_SET_FULLCONFIGURATION(
        p->bit_mask, NRRRC_musim_CapabilityRestrictionConfig_r18_present, "SA, RRC::OtherConfig_v1800");
}*/

#if F_StandardConformance_AsnNRRRC >= 183000
VCCB_STATIC
void VCCM_Check_NRRRC_OtherConfig_v1830(callInfo_type *ptCi, NRRRC_OtherConfig_v1830 *p)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    // sl-PRS-AssistanceConfigNR-r18    Need R
}

VCCB_STATIC
void VCCM_Check_NRRRC_RRCReconfigurationv1830IEs(callInfo_type *ptCi, NRRRC_RRCReconfiguration_v1830_IEs *p)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    // otherConfig-v1830    Need M
    if (p->bit_mask & NRRRC_otherConfig_v1830_present)
    {
        VCCM_Check_NRRRC_OtherConfig_v1830(ptCi, &p->otherConfig_v1830);
    }

    // nonCriticalExtension (placeholder only; empty or next version)
    if (p->bit_mask & NRRRC_RRCReconfiguration_v1830_IEs_nonCriticalExtension_present)
    {
        CHECK_N_SET_FULLCONFIGURATION(p->bit_mask,
            NRRRC_RRCReconfiguration_v1830_IEs_nonCriticalExtension_present, "SA, RRC::Reconfig_v1830");
    }
}
#endif

VCCB_STATIC
void VCCM_Check_NRRRC_RRCReconfigurationv1800IEs(callInfo_type *ptCi, NRRRC_RRCReconfiguration_v1800_IEs *p)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    //    needForInterruptionConfigNR-r18               Need M
    //CHECK_N_SET_FULLCONFIGURATION(p->bit_mask,
    //    NRRRC_RRCReconfiguration_v1800_IEs_needForInterruptionConfigNR_r18_present, "SA, RRC::Reconfig_v1800");

    //    aerial-Config-r18                             Need M
    //CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_aerial_Config_r18_present, "SA, RRC::Reconfig_v1800");

    //    sl-IndirectPathAddChange-r18                  Need M
    //CHECK_N_SET_FULLCONFIGURATION(
    //    p->bit_mask, NRRRC_sl_IndirectPathAddChange_r18_present, "SA, RRC::Reconfig_v1800");

    //    n3c-IndirectPathAddChange-r18                 Need M
    //CHECK_N_SET_FULLCONFIGURATION(
    //    p->bit_mask, NRRRC_n3c_IndirectPathAddChange_r18_present, "SA, RRC::Reconfig_v1800");

    //    n3c-IndirectPathConfigRelay-r18               Need M
    //CHECK_N_SET_FULLCONFIGURATION(
    //    p->bit_mask, NRRRC_n3c_IndirectPathConfigRelay_r18_present, "SA, RRC::Reconfig_v1800");

    //    otherConfig-v1800                             Need M
    //if (p->bit_mask & NRRRC_otherConfig_v1800_present)
    //{
    //    VCCM_Check_NRRRC_OtherConfig_v1800(ptCi, &p->otherConfig_v1800);
    //}

    //    srs-PosResourceSetAggBW-CombinationList-r18   Need M
    //CHECK_N_SET_FULLCONFIGURATION(
    //    p->bit_mask, NRRRC_srs_PosResourceSetAggBW_CombinationList_r18_present, "SA, RRC::Reconfig_v1800");

    //    ltm-Config-r18                                Need M
    //CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_ltm_Config_r18_present, "SA, RRC::Reconfig_v1800");

    //    nonCriticalExtension
#if F_StandardConformance_AsnNRRRC >= 183000
    if (p->bit_mask & NRRRC_RRCReconfiguration_v1800_IEs_nonCriticalExtension_present)
    {
        VCCM_Check_NRRRC_RRCReconfigurationv1830IEs(ptCi, &p->nonCriticalExtension);
    }
#endif
}

/* TODO: If you need to use this function, unannotate it and use it.
VCCB_STATIC
void VCCM_Check_NRRRC_OtherConfig_v1700(callInfo_type *ptCi, NRRRC_OtherConfig_v1700 *p)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    // CHECK_N_SET_FULLCONFIGURATION(
    //     p->bit_mask, NRRRC_ul_GapFR2_PreferenceConfig_r17_present, "SA, RRC::HoPrep::OtherConfig_v1700");
    // CHECK_N_SET_FULLCONFIGURATION(
    //     p->bit_mask, NRRRC_musim_GapAssistanceConfig_r17_present, "SA, RRC::HoPrep::OtherConfig_v1700");
    // CHECK_N_SET_FULLCONFIGURATION(
    //     p->bit_mask, NRRRC_musim_LeaveAssistanceConfig_r17_present, "SA, RRC::HoPrep::OtherConfig_v1700");
    // CHECK_N_SET_FULLCONFIGURATION(
    //     p->bit_mask, NRRRC_successHO_Config_r17_present, "SA, RRC::HoPrep::OtherConfig_v1700");
    // CHECK_N_SET_FULLCONFIGURATION(
    //     p->bit_mask, NRRRC_maxBW_PreferenceConfigFR2_2_r17_present, "SA, RRC::HoPrep::OtherConfig_v1700");
    // CHECK_N_SET_FULLCONFIGURATION(
    //     p->bit_mask, NRRRC_maxMIMO_LayerPreferenceConfigFR2_2_r17_present, "SA, RRC::HoPrep::OtherConfig_v1700");
    // CHECK_N_SET_FULLCONFIGURATION(
    //     p->bit_mask, NRRRC_minSchedulingOffsetPreferenceConfigExt_r17_present, "SA, RRC::HoPrep::OtherConfig_v1700");
    // CHECK_N_SET_FULLCONFIGURATION(
    //     p->bit_mask, NRRRC_rlm_RelaxationReportingConfig_r17_present, "SA, RRC::HoPrep::OtherConfig_v1700");
    // CHECK_N_SET_FULLCONFIGURATION(
    //     p->bit_mask, NRRRC_bfd_RelaxationReportingConfig_r17_present, "SA, RRC::HoPrep::OtherConfig_v1700");
    // CHECK_N_SET_FULLCONFIGURATION(
    //     p->bit_mask, NRRRC_scg_DeactivationPreferenceConfig_r17_present, "SA, RRC::HoPrep::OtherConfig_v1700");
    // CHECK_N_SET_FULLCONFIGURATION(
    //     p->bit_mask, NRRRC_rrm_MeasRelaxationReportingConfig_r17_present, "SA, RRC::HoPrep::OtherConfig_v1700");
    // CHECK_N_SET_FULLCONFIGURATION(
    //     p->bit_mask, NRRRC_propDelayDiffReportConfig_r17_present, "SA, RRC::HoPrep::OtherConfig_v1700");
}
*/
VCCB_STATIC
void VCCM_Check_NRRRC_RRCReconfigurationv1700IEs(callInfo_type *ptCi, NRRRC_RRCReconfiguration_v1700_IEs *p)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    /* TODO: If you need to use this function, unannotate it and use it.
    if (p->bit_mask & NRRRC_otherConfig_v1700_present)
    {
        VCCM_Check_NRRRC_OtherConfig_v1700(ptCi, &p->otherConfig_v1700);
    }
    */

    //    otherConfig-v1700                       Need M
    // CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_otherConfig_v1700_present,
    //         "SA, RRC::HoPrep::Reconfig_v1700");

    //    sl-L2RelayUE-Config-r17                 Need M
    //CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_sl_L2RelayUE_Config_r17_present,
    //        "SA, RRC::HoPrep::Reconfig_v1700");
    //    sl-L2RemoteUE-Config-r17                Need M
    //CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_RRCReconfiguration_v1700_IEs_sl_L2RemoteUE_Config_r17_present,
    //        "SA, RRC::HoPrep::Reconfig_v1700");
    //    dedicatedPagingDelivery-r17             Cond PagingRelay
    //CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_dedicatedPagingDelivery_r17_present,
    //        "SA, RRC::HoPrep::Reconfig_v1700");
    //    needForGapNCSG-ConfigNR-r17             Need M
    //CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_RRCReconfiguration_v1700_IEs_needForGapNCSG_ConfigNR_r17_present,
    //        "SA, RRC::HoPrep::Reconfig_v1700");
    //    needForGapNCSG-ConfigEUTRA-r17          Need M
    //CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_RRCReconfiguration_v1700_IEs_needForGapNCSG_ConfigEUTRA_r17_present,
    //        "SA, RRC::HoPrep::Reconfig_v1700");
    //    scg-State-r17                           Need N
    //CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_musim_GapConfig_r17_present,
    //        "SA, RRC::HoPrep::Reconfig_v1700");
    //    musim-GapConfig-r17                     Need M
    //CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_ul_GapFR2_Config_r17_present,
    //        "SA, RRC::HoPrep::Reconfig_v1700");
    //    ul-GapFR2-Config-r17                    Need M
    //CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_RRCReconfiguration_v1700_IEs_scg_State_r17_present,
    //        "SA, RRC::HoPrep::Reconfig_v1700");
    //    appLayerMeasConfig-r17                  Need M
    CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_RRCReconfiguration_v1700_IEs_appLayerMeasConfig_r17_present,
            "SA, RRC::HoPrep::Reconfig_v1700");
    //    ue-TxTEG-RequestUL-TDOA-Config-r17      Need M
    //CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_ue_TxTEG_RequestUL_TDOA_Config_r17_present,
    //        "SA, RRC::HoPrep::Reconfig_v1700");

    //    nonCriticalExtension
    if (p->bit_mask & NRRRC_RRCReconfiguration_v1700_IEs_nonCriticalExtension_present)
    {
        VCCM_Check_NRRRC_RRCReconfigurationv1800IEs(ptCi, &p->nonCriticalExtension);
    }
}

/* TODO: If you need to use this function, unannotate it and use it.
VCCB_STATIC
void VCCM_Check_NRRRC_OtherConfig_v1610(callInfo_type *ptCi, NRRRC_OtherConfig_v1610 *p)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    // CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_idc_AssistanceConfig_r16_present, "SA,
    // RRC::HoPrep::OtherConfig_v1610"); CHECK_N_SET_FULLCONFIGURATION(p->bit_mask,
    // NRRRC_drx_PreferenceConfig_r16_present, "SA, RRC::HoPrep::OtherConfig_v1610");
    // CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_maxBW_PreferenceConfig_r16_present, "SA,
    // RRC::HoPrep::OtherConfig_v1610"); // From 22A CHECK_N_SET_FULLCONFIGURATION(p->bit_mask,
    // NRRRC_maxCC_PreferenceConfig_r16_present, "SA, RRC::HoPrep::OtherConfig_v1610"); // From 22A
    // CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_maxMIMO_LayerPreferenceConfig_r16_present, "SA,
    // RRC::HoPrep::OtherConfig_v1610"); CHECK_N_SET_FULLCONFIGURATION(p->bit_mask,
    // NRRRC_minSchedulingOffsetPreferenceConfig_r16_present, "SA, RRC::HoPrep::OtherConfig_v1610");
    // CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_releasePreferenceConfig_r16_present, "SA,
    // RRC::HoPrep::OtherConfig_v1610"); // From 22A CHECK_N_SET_FULLCONFIGURATION(p->bit_mask,
    // NRRRC_referenceTimePreferenceReporting_r16_present, "SA, RRC::HoPrep::OtherConfig_v1610"); (Need R)
    // CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_btNameList_r16_present, "SA, RRC::HoPrep::OtherConfig_v1610");
    // CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_wlanNameList_r16_present, "SA, RRC::HoPrep::OtherConfig_v1610");
    // CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_sensorNameList_r16_present, "SA,
    // RRC::HoPrep::OtherConfig_v1610"); CHECK_N_SET_FULLCONFIGURATION(p->bit_mask,
    // NRRRC_obtainCommonLocation_r16_present, "SA, RRC::HoPrep::OtherConfig_v1610"); (Need R)
    // CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_sl_AssistanceConfigNR_r16_present, "SA,
    // RRC::HoPrep::OtherConfig_v1610"); (Need R)
}
*/

VCCB_STATIC
void VCCM_Check_NRRRC_RRCReconfigurationv1610IEs(callInfo_type *ptCi, NRRRC_RRCReconfiguration_v1610_IEs *p)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    /* TODO: If you need to use this function, unannotate it and use it.
    if (p->bit_mask & NRRRC_otherConfig_v1610_present)
    {
        VCCM_Check_NRRRC_OtherConfig_v1610(ptCi, &p->otherConfig_v1610);
    }
    */

    // CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_bap_Config_r16_present, "SA, RRC::HoPrep::Reconfig_v1610");
    CHECK_N_SET_FULLCONFIGURATION(
        p->bit_mask, NRRRC_iab_IP_AddressConfigurationList_r16_present, "SA, RRC::HoPrep::Reconfig_v1610");
    // CHECK_N_SET_FULLCONFIGURATION(
    //     p->bit_mask, NRRRC_conditionalReconfiguration_r16_present, "SA, RRC::HoPrep::Reconfig_v1610");
    CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_daps_SourceRelease_r16_present, "SA, RRC::HoPrep::Reconfig_v1610");
    // CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_t316_r16_present, "SA, RRC::HoPrep::Reconfig_v1610");
    // CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_RRCReconfiguration_v1610_IEs_needForGapsConfigNR_r16_present,
    // "SA, RRC::HoPrep::Reconfig_v1610"); CHECK_N_SET_FULLCONFIGURATION(p->bit_mask,
    // NRRRC_onDemandSIB_Request_r16_present, "SA, RRC::HoPrep::Reconfig_v1610");
    CHECK_N_SET_FULLCONFIGURATION(
        p->bit_mask, NRRRC_dedicatedPosSysInfoDelivery_r16_present, "SA, RRC::HoPrep::Reconfig_v1610");
    // CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_sl_ConfigDedicatedNR_r16_present, "SA,
    // RRC::HoPrep::Reconfig_v1610"); CHECK_N_SET_FULLCONFIGURATION(p->bit_mask,
    // NRRRC_sl_ConfigDedicatedEUTRA_Info_r16_present, "SA, RRC::HoPrep::Reconfig_v1610");
    // CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_targetCellSMTC_SCG_r16_present, "SA,
    // RRC::HoPrep::Reconfig_v1610"); (Need S)
    if (p->bit_mask & NRRRC_RRCReconfiguration_v1610_IEs_nonCriticalExtension_present)
    {
        VCCM_Check_NRRRC_RRCReconfigurationv1700IEs(ptCi, &p->nonCriticalExtension);
    }
}  // }}}

VCCB_STATIC
void VCCM_Check_NRRRC_RRCReconfigurationv1560IEs(callInfo_type *ptCi, NRRRC_RRCReconfiguration_v1560_IEs *p)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    // 1. mrdc-SecondaryCellGroupConfig
    // 2. radioBearerConfig2 : (TODO: MR-DC SN)
    // 3. sk-Counter
    // 4. nonCriticalExtension : {} // RRCReconfiguration-v1610-IEs is added (TODO: gNB or MN is needed to check to
    // re-use this function for SN)
    if (p->bit_mask & NRRRC_RRCReconfiguration_v1560_IEs_nonCriticalExtension_present)
    {
        VCCM_Check_NRRRC_RRCReconfigurationv1610IEs(ptCi, &p->nonCriticalExtension);
    }
}  // }}}

VCCB_STATIC
void VCCM_Check_NRRRC_RRCReconfigurationv1540IEs(callInfo_type *ptCi, NRRRC_RRCReconfiguration_v1540_IEs *p)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    // 1. otherConfig-v1540
    // 2. nonCriticalExtension : RRCReconfiguration-v1560-IEs
    if (p->bit_mask & NRRRC_RRCReconfiguration_v1540_IEs_nonCriticalExtension_present)
    {
        VCCM_Check_NRRRC_RRCReconfigurationv1560IEs(ptCi, &p->nonCriticalExtension);
    }

}  // }}}

VCCB_STATIC
void VCCM_Check_NRRRC_RRCReconfigurationv1530IEs(callInfo_type *ptCi, NRRRC_RRCReconfiguration_v1530_IEs *p)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    // 1. masterCellGroup
    // 2. fullConfig 
    // 3. dedicatedNAS-MessageList
    // 4. masterKeyUpdate
    // 5. dedicatedSIB1-Delivery
    // 6. dedicatedSystemInformationDelivery
    // 7. otherConfig
    // 8. nonCriticalExtension : RRCReconfiguration-v1540-IEs
    if (p->bit_mask & NRRRC_RRCReconfiguration_v1530_IEs_nonCriticalExtension_present)
    {
        VCCM_Check_NRRRC_RRCReconfigurationv1540IEs(ptCi, &p->nonCriticalExtension);
    }

}  // }}}

VCCB_STATIC
void VCCM_Check_NRRRC_RRCReconfiguration_IEs(callInfo_type *ptCi, NRRRC_RRCReconfiguration_IEs *p)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    // 1. RadioBearerConfig
    if (p->bit_mask & NRRRC_RRCReconfiguration_IEs_radioBearerConfig_present)
    {
        VCCM_Check_NRRRC_RadioBearerConfig(ptCi, &p->radioBearerConfig);
    }

    // 2. secondaryCellGroup : (TODO: Does MR-DC SN need to check it?)
    // 3. measConfig : no action
    // 4. lateNonCriticalExtension : no action
    // 5. nonCriticalExtension: RRCReconfiguration-v1530-IEs (TODO: gNB or MN condition is needed to check to re-use
    // this function for SN)
    if (p->bit_mask & NRRRC_RRCReconfiguration_IEs_nonCriticalExtension_present)
    {
        VCCM_Check_NRRRC_RRCReconfigurationv1530IEs(ptCi, &p->nonCriticalExtension);
    }

}  // }}}

VCCB_STATIC
void VCCM_Check_NRRRC_AS_Config(callInfo_type *ptCi, NRRRC_AS_Config *p)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    NRRRC_RRCReconfiguration *ptMsg;

    // 1. rrcReconfiguration (gNB or MR-DC MN)
    auto &rRrcReconf = p->rrcReconfiguration;
    ptMsg = FnVCCB_UnpackAndGetRRCReconfigurationPDU(ptCi, rRrcReconf.value, rRrcReconf.length, CellGroupId_MCG);
    if (ptMsg != NULL)
    {
        if (ptMsg->criticalExtensions.choice == NRRRC_criticalExtensions_rrcReconfiguration_chosen)
        {
            VCCM_Check_NRRRC_RRCReconfiguration_IEs(ptCi, &ptMsg->criticalExtensions.u.rrcReconfiguration);
        }
    }

    if (CFG->fullConfig.support.flag.F_21C_MRDC_UE == Not_Allowed)
    {
        // 2. sourceRB-SN-Config  (relay it to SN and check at MR-DC SN)
        // TODO: 21C (If NRDC foo is enable, store and save the sourceRB-SN-Config)
        //       21D (store and save the sourceRB-SN-Config wo checking foo - It means that test is done)
        CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_sourceRB_SN_Config_present, "SA, RRC::HoPrep::AS-Config");

        // 3. sourceSCG-NR-Config (relay it to SN and check at MR-DC SN)
        CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_sourceSCG_NR_Config_present, "SA, RRC::HoPrep::AS-Config");

        // 4. sourceSCG-EUTRA-Config : no action
        CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_sourceSCG_EUTRA_Config_present, "SA, RRC::HoPrep::AS-Config");

        /* 5. sourceSCG_Configured */
        CHECK_N_SET_FULLCONFIGURATION(p->bit_mask, NRRRC_sourceSCG_Configured_present, "SA, RRC::HoPrep::AS-Config");
    }

}  // }}}

VCCB_STATIC
void VCCM_Check_NRRRC_HandoverPreparationInformation_IEs(
    callInfo_type *ptCi, NRRRC_HandoverPreparationInformation_IEs *p)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    // 1. UE-CapabilityRAT-ContainerList

    // 2. AS-Config
    if (NRRRC_sourceConfig_present & p->bit_mask)
    {
        VCCM_Check_NRRRC_AS_Config(ptCi, &p->sourceConfig);
    }

    // 3. RRM-Config : No action
    // 4. AS-Context : No action
    // 5. nonCriticalExtension : {}

}  // }}}

int16_t VCCM_check_HandoverPreparationInformation_For_FullConfiguration(
    callInfo_type *ptCi, void *p_void)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(p_void);

    int16_t status = GOOD;
    NRRRC_HandoverPreparationInformation *p = (NRRRC_HandoverPreparationInformation *)p_void;

    /* set no action. action is bitmap */
    VLIB_InitFullConfigurationInfo(ptCi);

    /* check the state to handle it */
    switch (ptCi->stateCmd)
    {
        case IntraRatHO_cmd:
        case RrcReestablish_cmd:
            break;

        default:
            /* don't check the full configuration */
#ifdef IPC_TEST
            if (ptCi->stateCmd != InterRatHO_cmd)  // IRAT_HO - no need to check, always fullconfig On in IRAT HO case
                VCCB_PRINT_CALL_ERROR(ptCi, "Not allowed stateCmd(%d)\n", ptCi->stateCmd);
#endif

            // SVR25A FGR-MC1020
            if (ptCi->ueInfo.rrcResumeInfo.resumeType == RESUME_TYPE_INTER_GNB_TARGET &&
                CFG->fullConfig.support.scenario.EventScenario_SA_InterGnbResume_CuInit == Allowed)
            {
                break;
            }

            return GOOD;
    }

    /* check the choice to get the IE */
    if (p->criticalExtensions.choice == NRRRC_HandoverPreparationInformation_criticalExtensions_c1_chosen)
    {
        if (p->criticalExtensions.u.c1.choice == NRRRC_handoverPreparationInformation_chosen)
        {
            VCCM_Check_NRRRC_HandoverPreparationInformation_IEs(
                ptCi, &p->criticalExtensions.u.c1.u.handoverPreparationInformation);
        }
    }

    /* decision full configuration with checking function */
    status = VCCM_DecideCuInitFullConfigSA(ptCi, NULL, __func__);
    if (status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Accept By FullConfiguration (SA/NRDC-MN/NEDC-MN, Handover Preparation, 1)!\n");
        return status;
    }

    return GOOD;
}  // }}}

/**
 * @brief Check and set full configuration by sourceConfigSCG IE in CG_ConfigInfo message
 * 
 *        + Feature/FR : FGR-MC1020, FR80.CACP.SR1.HD1.DD1
 *        + FR Description
 *          -[24B] MN initiated NR-DC full configuration (MN HO with SN change procedure)
 *          -if Xn S-NODE Addition Request with SgNB Addition Trigger Indication is received from MN
 *           and if there are no sourceConfigSCG in the message.
 * 
 * @param ptCi: Pointer to call information structure
 * @param p: Pointer to CG_ConfigInfo IEs structure
 */
VCCB_STATIC_INLINE
void FnVCCB_CheckAndSetFullConfiguration_BySourceConfigSCG(callInfo_type *ptCi, NRRRC_CG_ConfigInfo_IEs *p)
{
    // Check input parameters
    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, p);

    // Define a lambda function to check if the call state is with SN change
    auto isWithSnChange = [](enumVccbCallState_type state) -> bool
    {
        switch(state)
        {
            case STATE_II: // with SN Change
                return true;

            default: // without SN Change
                return false;
        }
    };

    // Check if the call state is with SN change
    if (isWithSnChange(ptCi->state) == true)
    {
        // Check if the sourceConfigSCG IE is present in the message
        if (p->bit_mask & NRRRC_sourceConfigSCG_present)
        {
            // If the sourceConfigSCG IE is present, do nothing             
            // except for TEST PURPOSE forced scenario
            FORCE_FULLCONFIGURATION_OVER_XN(ptCi, false);            
        }
        else
        {
            // If the sourceConfigSCG IE is not present, set the full configuration
            VCCB_SET_FULLCONFIGURATION(ptCi, ci_fc_trigger, "SN, RRC::CG_ConfigInfo::sourceConfigSCG NotExist (with SN Change)");
        }
    }
}

VCCB_STATIC
void VCCM_Check_CG_ConfigInfo_IEs(callInfo_type *ptCi, NRRRC_CG_ConfigInfo_IEs *p)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p);

    // 1. NRRRC_ue_CapabilityInfo_present
    // 2. NRRRC_candidateCellInfoListMN_present
    // 3. NRRRC_CG_ConfigInfo_IEs_candidateCellInfoListSN_present
    // 4. NRRRC_CG_ConfigInfo_IEs_measResultCellListSFTD_NR_present
    // 5. NRRRC_scgFailureInfo_present
    // 6. NRRRC_CG_ConfigInfo_IEs_configRestrictInfo_present
    // 7. NRRRC_drx_InfoMCG_present
    // 8. NRRRC_measConfigMN_present
    // 9. NRRRC_sourceConfigSCG_present
    FnVCCB_CheckAndSetFullConfiguration_BySourceConfigSCG(ptCi, p);

    // 10. NRRRC_CG_ConfigInfo_IEs_scg_RB_Config_present
    // 11. NRRRC_mcg_RB_Config_present
    // 12. NRRRC_mrdc_AssistanceInfo_present
    // 13. NRRRC_CG_ConfigInfo_IEs_nonCriticalExtension_present

}  // }}}

void VCCM_check_CG_ConfigInfo_For_FullConfiguration(callInfo_type *ptCi, void *p_void)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(p_void);

    NRRRC_CG_ConfigInfo *p = (NRRRC_CG_ConfigInfo *)p_void;

    /* Only Support Addition Request For Handover. Addition Request For Basic is not target */
    if (ptCi->hoInfo.sgnbAddTrigInd == SgnbAddTrigInd_Unknown) return;

    switch (ptCi->state)
    {
        case STATE_II:
            if (CFG->fullConfig.support.flag.F_22A_NRDC_NRADDITION == Not_Allowed)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Excluded from Inter-SN Fullconfig condition %s\n", __func__);
                return;
            }
            break;
        default:
            if (CFG->fullConfig.support.flag.F_22A_NRDC_PROCEEDHO == Not_Allowed)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Excluded from Intra-SN Fullconfig condition in %s\n", __func__);
                return;
            }
            break;
    }

    /* set no action. action is bitmap */
    VLIB_InitFullConfigurationInfo(ptCi);

    /* check the choice to get the IE */
    if (p->criticalExtensions.choice == NRRRC_CG_ConfigInfo_criticalExtensions_c1_chosen)
    {
        if (p->criticalExtensions.u.c1.choice == NRRRC_cg_ConfigInfo_chosen)
        {
            VCCM_Check_CG_ConfigInfo_IEs(ptCi, &p->criticalExtensions.u.c1.u.cg_ConfigInfo);
        }
    }
}  // }}}

int16_t VCCM_checkAndDecide_CG_ConfigInfo_For_FullConfiguration(callInfo_type *ptCi, void *p_void)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(p_void);

    VCCM_check_CG_ConfigInfo_For_FullConfiguration(ptCi, p_void);

    /* decision full configuration with checking function */
    int16_t status = VCCM_DecideCuInitFullConfigSA(ptCi, NULL, __func__);
    if (status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Accept By FullConfiguration (NRDC-SN, CG-ConfigInfo)!\n");
        return status;
    }

    return GOOD;

}  // }}}

// }}}

/********************************************************************************
 * @brief In this section, it checks whether an Scenario that requires full configuration
 ********************************************************************************/
// {{{
void VHCM_ApplyRadioBearer_For_FullConfiguration(callInfo_type *ptCi)
{  // {{{

    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    uint32_t drbIdx = 0;
    callDRBInfo_type *ptDi = NULL;

    // each DRB
    for (drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        ptDi = &ptCi->drb[drbIdx];

        if (ptDi->usage != CI_use) continue;

        if (ptDi->drbStatus != S_Setup) continue;

        if (GETBIT(ptCi->drbIdsReuse, ptDi->dRBId - 1))
        {
            // Mapping of this DRB was done normally.
            // no action
        }
        else
        {
            // This DRB could not be mapped. This is a newly added DRB.

            if (IsAvailable_MrdcInfo())  // MRDC only occurs in IntraNr Handover.
            {
                // DRB allocation in the target gNB is excluded from the data forwarding.
                VCCB_SET_FULLCONFIGURATION_DRB(ptCi, ci_fc_drb_disable_datafwd, ptDi->dRBId,
                    "SA, Scenario::MR-DC, New Alloc DRB(DRB, disable datafwd)");  // Data Forwardning Disabled
            }
            else
            {
                // no action :: VLIB_checkRadioBearerStatusForMobility
            }
        }
    }

}  // }}}

void FnVCCB_Check_DRB_RlcMode_For_FullConfig(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    callDRBInfo_type *ptDi = NULL;

    for (uint32_t drbIdx = 0; drbIdx < MAX_DRB_PER_SA_CALL; drbIdx++)
    {
        ptDi = &ptCi->drb[drbIdx];

        if (ptDi->usage != CI_use) continue;

        if (ptDi->rbInfo.rlcModePresent == OPT_PRESENT) continue;

        // If the RLC Mode is not known(rlcModePresent == OPT_NOT_PRESENT), it is subject to Full Configuration.
        VCCB_SET_FULLCONFIGURATION(ptCi, ci_fc_trigger, "SA, DRB doesn't have a rlcMode. DrbId(%d) bearerType(%d)",
            ptDi->dRBId, ptDi->bearerType);

        break;
    }

    return;
}  // }}}

void FnVCCB_ExcludingCellGroup_For_FullConfig(callInfo_type *ptCi, void *ptCellGroup)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, ptCellGroup);

    NRRRC_RRCReconfiguration *pRRCReconfig = (NRRRC_RRCReconfiguration *)ptCellGroup;

    if (pRRCReconfig->criticalExtensions.choice != NRRRC_criticalExtensions_rrcReconfiguration_chosen) return;

    auto &rrcReconfig = pRRCReconfig->criticalExtensions.u.rrcReconfiguration;

    // NSA (ENDC-SN, NRDC-SN) - Secondary Cell Group
    if (IS_MRDC_SN(ptCi))
    {
        // Remove Secondary Cell Group
        if (rrcReconfig.bit_mask & NRRRC_secondaryCellGroup_present)
        {
            OFF_PRESENT_BIT(rrcReconfig.bit_mask, NRRRC_secondaryCellGroup_present);
        }

        return;
    }

    // SA (NonDC, NRDC-MN, NEDC-MN) - Master Cell Group
    if (rrcReconfig.bit_mask & NRRRC_RRCReconfiguration_IEs_nonCriticalExtension_present)
    {
        auto &rrcReconfig_v1530 = rrcReconfig.nonCriticalExtension;

        // Remove Master Cell Group
        if (rrcReconfig_v1530.bit_mask & NRRRC_RRCReconfiguration_v1530_IEs_masterCellGroup_present)
        {
            OFF_PRESENT_BIT(rrcReconfig_v1530.bit_mask, NRRRC_RRCReconfiguration_v1530_IEs_masterCellGroup_present);
        }
    }

    return;
}  // }}}

/********************************************************************************
 * @brief This section defines Class for Full Configuration.
 ********************************************************************************/

ForcedDuInitFullConfigForF1SetupModReqMake::ForcedDuInitFullConfigForF1SetupModReqMake(callInfo_type *_ptCi, fullConfiguration_type *_ptBackupDB)
{
    // Whether the current operation is required
    needProcessing = false;

    // Data required for operation
    ptCi = _ptCi;
    needRecovery = false;
    ptBackupDB = _ptBackupDB;
}

ForcedDuInitFullConfigForF1SetupModReqMake::~ForcedDuInitFullConfigForF1SetupModReqMake()
{
    if (needRecovery == true)
    {
        postOperation();
    }
}

void ForcedDuInitFullConfigForF1SetupModReqMake::procF1Setup()
{
    // Duplicate call prevention
    if (needProcessing == true) return;

    auto fnCheckFullConfigFunctionCalled = [&]()
    {
        if (ptCi == NULL || ptBackupDB == NULL) return false;

        // If the SpCell information does not go down, it is not a target.
        // - F1 Setup always has this information.

        // CU or SN Init FullConfiguration is not a target.
        if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi)) return false;

        // Check if the DU Init FullConfiguration (Forced Trigger) condition is satisfied.
        if (VCCM_check_FullConfiguration_Forced_Scenario(ptCi, e_DuInitFullConfig, NULL) == FALSE) return false;

        return true;
    };

    if (fnCheckFullConfigFunctionCalled()) preOperation();
}

void ForcedDuInitFullConfigForF1SetupModReqMake::procF1Mod()
{
    // Duplicate call prevention
    if (needProcessing == true) return;

    auto fnCheckFullConfigFunctionCalled = [&]()
    {
        if (ptCi == NULL || ptBackupDB == NULL) return false;

        // If the SpCell information does not go down, it is not a target.
        if (VFIL_checkF1_UEContextMod_SpCellId(ptCi) == FALSE) return false;

        // CU or SN Init FullConfiguration is not a target.
        if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi)) return false;

        // Check if the DU Init FullConfiguration (Forced Trigger) condition is satisfied.
        if (VCCM_check_FullConfiguration_Forced_Scenario(ptCi, e_DuInitFullConfig, NULL) == FALSE) return false;

        return true;
    };

    if (fnCheckFullConfigFunctionCalled()) preOperation();
}

void ForcedDuInitFullConfigForF1SetupModReqMake::preOperation()
{
    if (ptCi == NULL || ptBackupDB == NULL) return;

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "FullConfiguration scenario detected. DU Init FullConfiguration operates. (Cause: Forced Trigger)\n");

    // Back up the existing DB to perform the force trigger.
    *ptBackupDB = ptCi->fullConfiguration;
    needRecovery = true;

    // Performs DU Init Full Configuration (Forced Trigger).
    VCCM_trigger_FullConfiguration_Forced_Scenario_DuInit(ptCi);
}

void ForcedDuInitFullConfigForF1SetupModReqMake::postOperation()
{
    if (ptCi == NULL || ptBackupDB == NULL) return;

    // If DU Init FullConfiguration is triggered, restore it.
    ptCi->fullConfiguration = *ptBackupDB;
    needRecovery = false;
}

ForcedCuInitFullConfigForXnSnAddReqMake::ForcedCuInitFullConfigForXnSnAddReqMake(callInfo_type *_ptCi, fullConfiguration_type *_ptBackupDB)
{
    // Whether the current operation is required
    needProcessing = false;

    // Data required for operation
    ptCi = _ptCi;
    needRecovery = false;
    ptBackupDB = _ptBackupDB;
}

ForcedCuInitFullConfigForXnSnAddReqMake::~ForcedCuInitFullConfigForXnSnAddReqMake()
{
    if (needRecovery == true)
    {
        postOperation();
    }
}

void ForcedCuInitFullConfigForXnSnAddReqMake::procXnSnAddReq()
{
    // Duplicate call prevention
    if (needProcessing == true) return;

    auto fnCheckFullConfigFunctionCalled = [&]()
    {
        if (ptCi == NULL || ptBackupDB == NULL) return false;

        // If the SpCell information does not go down, it is not a target.
        // - F1 Setup always has this information.

        // CU or SN Init FullConfiguration is not a target.
        if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi)) return false;

        // Check if the CU Init FullConfiguration (Forced Trigger) condition is satisfied.
        if (VCCM_check_FullConfiguration_Forced_Scenario(ptCi, e_CuInitFullConfig, NULL) == FALSE) return false;

        return true;
    };

    if (fnCheckFullConfigFunctionCalled()) preOperation();
}

void ForcedCuInitFullConfigForXnSnAddReqMake::preOperation()
{
    if (ptCi == NULL || ptBackupDB == NULL) return;

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "FullConfiguration scenario detected. CU Init FullConfiguration operates. (Cause: Forced Trigger)\n");

    // Back up the existing DB to perform the force trigger.
    *ptBackupDB = ptCi->fullConfiguration;
    needRecovery = true;

    // Performs CU Init Full Configuration (Forced Trigger).
    VCCM_trigger_FullConfiguration_Forced_Scenario(ptCi);
}

void ForcedCuInitFullConfigForXnSnAddReqMake::postOperation()
{
    if (ptCi == NULL || ptBackupDB == NULL) return;

    // If CU Init FullConfiguration is triggered, restore it.
    ptCi->fullConfiguration = *ptBackupDB;
    needRecovery = false;
}

// }}}
