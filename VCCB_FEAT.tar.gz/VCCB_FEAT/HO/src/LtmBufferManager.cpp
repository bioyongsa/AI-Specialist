/**
 * @file        LtmBufferManager.cpp
 * @brief       Implementation of LTM Buffer Manager class
 */

#include "LtmBufferManager.h"

#include "ComInclude.h"
#include "ComAsnUtil.hpp"  // for VCCB_ConnectLinkedList
#include "nrrrcUnpack.h"

using asn::util::VCCB_ConnectLinkedList;

/**
 * @brief Initialize LTM preparation process temporary database for a call
 * @note This function uses iterateCallCandidateCells to iterate through all candidate cells
 *       instead of using a traditional for loop. This is more efficient as it only processes
 *       cells that actually exist.
 * 
 * @example Usage of iterateCallCandidateCells:
 *   // Example 1: Initialize all candidate cells
 *   LtmBufferManager::getInstance().initLtmPrepProcTempDb(call);
 * 
 *   // Example 2: Custom iteration with iterateCallCandidateCells (read-only)
 *   LtmBufferManager::getInstance().iterateCallCandidateCells(call,
 *       [](uint16_t cellIndex, std::shared_ptr<ltmCandidateCellInfo_type>& cellData) {
 *           VCCB_PRINTF("Processing cell index: %u\n", cellIndex);
 *           // Access cellData->cellGroupConfig, cellData->rrcReconfiguration, etc.
 *           // Note: cellData is non-const reference, so modifications are allowed
 *       });
 * 
 *   // Example 3: Count valid candidate cells
 *   size_t count = LtmBufferManager::getInstance().iterateCallCandidateCells(call,
 *       [](uint16_t cellIndex, std::shared_ptr<ltmCandidateCellInfo_type>& cellData) {
 *           // Just count, no processing needed
 *       });
 *   VCCB_PRINTF("Total candidate cells: %zu\n", count);
*/
void LtmBufferManager::initLtmPrepProcTempDb(callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(rCall.myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(rCall.callId, MAX_CALL_NUM_VCCB);

    uint8_t myThreadId = rCall.myThreadId;
    uint32_t callId = rCall.callId;

    // Get call buffer (does not create if not exists)
    CallBufferInfo* bufferInfo = getCallBuffer(myThreadId, callId);
    if (bufferInfo == nullptr) {
        return;  // Buffer not found
    }

    // Initialize source cell group config
    bufferInfo->sourceCellGroupConfig.numocts = 0;

    // Use iterateCallCandidateCells to iterate through all candidate cells
    // This replaces the previous for loop (ltmIdx = 0; ltmIdx < MAX_NUM_LTM_CELLS; ltmIdx++)
    // and only processes cells that actually exist, making it more efficient
    iterateCallCandidateCells(rCall,
        [](uint16_t /* cellIndex */, std::shared_ptr<ltmCandidateCellInfo_type>& cellData) {
            if (cellData) {
                // Initialize each candidate cell's data
                cellData->cellGroupConfig.numocts = 0;
                cellData->rrcReconfiguration.numocts = 0;
                cellData->ltmResourceConfig.ltm_SSB_Config_r18.bit_mask = 0;
                cellData->ltmResourceConfig.ltm_SSB_Config_r18.ssb_Frequency_r18 =
                    MAX_A6_NR_ARFCN + 1;  // NRRRC_maxNARFCN + 1
            }
        });
}

int16_t LtmBufferManager::storeCellGroupConfig(callInfo_type &rCall, uint16_t ltmCellIdx, msgContainer_type &rCellGroup)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(rCall.myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(rCall.callId, MAX_CALL_NUM_VCCB);

    uint8_t myThreadId = rCall.myThreadId;
    uint32_t callId = rCall.callId;

    // Get call buffer (does not create if not exists)
    CallBufferInfo* bufferInfo = getCallBuffer(myThreadId, callId);
    if (bufferInfo == nullptr) {
        return ERROR;  // Buffer not found
    }

    bufferInfo->state = CI_use;

    msgContainer_type *ptCellGroupConfigDb = nullptr;
    if (ltmCellIdx >= MAX_NUM_LTM_CELLS)
    {
        ptCellGroupConfigDb = &bufferInfo->sourceCellGroupConfig;
    }
    else
    {
        ptCellGroupConfigDb = &(getCandidateCell(rCall, ltmCellIdx)->cellGroupConfig);
    }

    ptCellGroupConfigDb->numocts = rCellGroup.numocts < MAX_DAT_LEN ? rCellGroup.numocts : MAX_DAT_LEN;

    if (ptCellGroupConfigDb->numocts > 0)
    {
        memcpy(&ptCellGroupConfigDb->data, &rCellGroup.data, ptCellGroupConfigDb->numocts);

        if (DBG->flag.logLtm)
        {
            VCCB_PRINT_CALL_COMMENT(&rCall, "[LTM:DB] store the cell group config ltmBufferMap[%d][%d] ltmCellIdx(%u) length(%d)\n",
            myThreadId, callId, ltmCellIdx, ptCellGroupConfigDb->numocts);
        }
    }
    else
    {
        if (DBG->flag.logLtm)
        {
            VCCB_PRINT_CALL_COMMENT(&rCall, "[LTM:DB] doesn't store numocts is 0 ltmBufferMap[%d][%d] ltmCellIdx(%u) length(%d)\n",
            myThreadId, callId, ltmCellIdx, ptCellGroupConfigDb->numocts);
        }
    }

    

    return GOOD;
}

int16_t LtmBufferManager::getStoredCellGroupConfig(
    callInfo_type &rCall, uint16_t ltmCellIdx, msgContainer_type &rCellGroup)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(rCall.myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(rCall.callId, MAX_CALL_NUM_VCCB);

    uint8_t myThreadId = rCall.myThreadId;
    uint32_t callId = rCall.callId;

    // Get call buffer (does not create if not exists)
    CallBufferInfo* bufferInfo = getCallBuffer(myThreadId, callId);
    if (bufferInfo == nullptr) {
        return ERROR;  // Buffer not found
    }

    msgContainer_type *ptCellGroupConfigDb = NULL;
    if (ltmCellIdx >= MAX_NUM_LTM_CELLS)
    {
        ptCellGroupConfigDb = &bufferInfo->sourceCellGroupConfig;
    }
    else
    {
        ptCellGroupConfigDb = &(getCandidateCell(rCall, ltmCellIdx)->cellGroupConfig);
    }

    rCellGroup.numocts = ptCellGroupConfigDb->numocts;

    if (rCellGroup.numocts > 0)
    {
        memcpy(&rCellGroup.data, &ptCellGroupConfigDb->data, rCellGroup.numocts);

        if (DBG->flag.logLtm)
        {
            VCCB_PRINT_CALL_COMMENT(&rCall, "[LTM:DB] get stored cell group Config ltmBufferMap[%d][%d] ltmCellIdx(%u) length(%d)\n",
            myThreadId, callId, ltmCellIdx, rCellGroup.numocts);
        }
    }
    else
    {
        if (DBG->flag.logLtm)
        {
            VCCB_PRINT_CALL_COMMENT(&rCall, "[LTM:DB] doens't stored cell group Config numoct is 0 ltmBufferMap[%d][%d] ltmCellIdx(%u) length(%d)\n",
                myThreadId, callId, ltmCellIdx, rCellGroup.numocts);
        }
    }

    return GOOD;
}


void LtmBufferManager::showStoredCellGroupConfig(callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(rCall.myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(rCall.callId, MAX_CALL_NUM_VCCB);

    uint8_t myThreadId = rCall.myThreadId;
    uint32_t callId = rCall.callId;

    // Get call buffer (does not create if not exists)
    CallBufferInfo* bufferInfo = getCallBuffer(myThreadId, callId);
    if (bufferInfo == nullptr) {
        return;  // Buffer not found
    }

    VCCB_PRINT_CALL_INFORMATIVE(&rCall, "[LTM] state(%d)\n", bufferInfo->state);

    if (bufferInfo->sourceCellGroupConfig.numocts > 0)
    {
        VCCB_PRINT_CALL_INFORMATIVE(&rCall, "[LTM] length(%d)\n", bufferInfo->sourceCellGroupConfig.numocts);
    }

    iterateCallCandidateCells(rCall,
        [&rCall](uint16_t /* cellIndex */, std::shared_ptr<ltmCandidateCellInfo_type>& cellData) {
            if (cellData) {
                if (cellData->cellGroupConfig.numocts > 0)
                {
                    VCCB_PRINT_CALL_INFORMATIVE(&rCall, "[LTM] cellIdx(%d) length(%d)\n", cellData->cellIdx, cellData->cellGroupConfig.numocts);
                }
            }
        });
}

int16_t LtmBufferManager::storeLtmReconfig(callInfo_type &rCall, uint16_t ltmCellIdx, msgContainer_type &rReconfig)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(ltmCellIdx, MAX_NUM_LTM_CELLS);

    auto pLtmCell = getCandidateCell(rCall, ltmCellIdx);
    if (pLtmCell == nullptr) return ERROR;

    msgContainer_type &rReconfigDb = pLtmCell->rrcReconfiguration;

    rReconfigDb.numocts = rReconfig.numocts < MAX_DAT_LEN ? rReconfig.numocts : MAX_DAT_LEN;

    if (rReconfigDb.numocts > 0)
    {
        memcpy(&rReconfigDb.data, &rReconfig.data, rReconfigDb.numocts);

        if (DBG->flag.logLtm)
        {
            VCCB_PRINT_CALL_COMMENT(&rCall, "[LTM:DB] store the Reconfig ltmBufferMap[%d][%d] ltmCellIdx(%u) length(%d)\n",
            rCall.myThreadId, rCall.callId, ltmCellIdx, rReconfigDb.numocts);
        }
    }
    else
    {
        if (DBG->flag.logLtm)
        {
            VCCB_PRINT_CALL_COMMENT(&rCall, "[LTM:DB] doesn't store the Reconfig numoct is 0 ltmBufferMap[%d][%d] ltmCellIdx(%u) length(%d)\n",
                rCall.myThreadId, rCall.callId, ltmCellIdx, rReconfigDb.numocts);
        }
    }

    return GOOD;
}

int16_t LtmBufferManager::getStoredLtmReconfig(callInfo_type &rCall, uint16_t ltmCellIdx, NRRRC__octet1_10 &rNrrrcOctct)
{
    AUTO_TRACE_FUNC;

    auto pLtmCell = getCandidateCell(rCall, ltmCellIdx);
    if (pLtmCell == nullptr) return ERROR;

    msgContainer_type &rReconfigDb = pLtmCell->rrcReconfiguration;

    rNrrrcOctct.length = rReconfigDb.numocts;
    rNrrrcOctct.value = (unsigned char *)rReconfigDb.data;

    if (DBG->flag.logLtm)
    {
        VCCB_PRINT_CALL_COMMENT(&rCall, "[LTM:DB] get stored Reconfig ltmBufferMap[%d][%d] ltmCellIdx(%u) length(%d)\n",
            rCall.myThreadId, rCall.callId, ltmCellIdx, rNrrrcOctct.length);
    }

    return GOOD;
}

uint16_t LtmBufferManager::get_num_du(
    callInfo_type &rCall, uint16_t ltmCellIdx)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(ltmCellIdx, MAX_NUM_LTM_CELLS, 0);

    auto pLtmCell = getCandidateCell(rCall, ltmCellIdx);
    return (pLtmCell?pLtmCell->earlySyncInfo.num_du:0);
}

int16_t LtmBufferManager::init_ltmMaintainDb(
    callInfo_type &rCall, uint16_t ltmCellIdx)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(ltmCellIdx, MAX_NUM_LTM_CELLS);

    if (addCandidateCell(rCall, static_cast<int16_t>(ltmCellIdx)) == ERROR) return ERROR; 

    auto pLtmCell = getCandidateCell(rCall, ltmCellIdx);
    if (pLtmCell == nullptr) return ERROR;

    pLtmCell->earlySyncInfo.num_du = 0;
    pLtmCell->earlySyncInfo.num_octets_tci = 0;
    pLtmCell->earlySyncInfo.num_octets_rach = 0;

    pLtmCell->ltmResourceConfig.num_octets_cfra = 0;

    return GOOD;
}

int16_t LtmBufferManager::store_F1_EarlySyncInformation(
    callInfo_type &rCall, uint16_t ltmCellIdx, F1_EarlySyncInformation *ptEarlySyncInfo)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(ltmCellIdx, MAX_NUM_LTM_CELLS);

    auto pLtmCell = getCandidateCell(rCall, ltmCellIdx);
    if (pLtmCell == nullptr) return ERROR;

    auto &rLtmCellEarlySyncInfo = pLtmCell->earlySyncInfo;
    // set init value

    if (ptEarlySyncInfo == NULL)
    {
        return GOOD;
    }

    // TCI States Configurations List
    rLtmCellEarlySyncInfo.num_octets_tci = (uint16_t)ptEarlySyncInfo->tCIStatesConfigurationsList.length;
    if (ptEarlySyncInfo->tCIStatesConfigurationsList.length > 0)
    {
        memcpy(&rLtmCellEarlySyncInfo.tCIStatesConfigurationsList[0], ptEarlySyncInfo->tCIStatesConfigurationsList.value,
            ptEarlySyncInfo->tCIStatesConfigurationsList.length);
    }

    // Early UL Sync Configuration
    if (ptEarlySyncInfo->bit_mask & F1_EarlySyncInformation_earlyULSyncConfig_present)
    {
        rLtmCellEarlySyncInfo.num_octets_rach = static_cast<uint16_t>(ptEarlySyncInfo->earlyULSyncConfig.rACH.length);
        if (ptEarlySyncInfo->earlyULSyncConfig.rACH.length > 0)
        {
            memcpy(&rLtmCellEarlySyncInfo.rACH[0], ptEarlySyncInfo->earlyULSyncConfig.rACH.value,
                ptEarlySyncInfo->earlyULSyncConfig.rACH.length);
        }

        if (ptEarlySyncInfo->earlyULSyncConfig.bit_mask & F1_lTMgNB_DU_IDs_PreambleIndexList_present)
        {
            int cnt = 0;
            auto *pList = ptEarlySyncInfo->earlyULSyncConfig.lTMgNB_DU_IDs_PreambleIndexList;
            while (pList)
            {
                auto &rItem = pList->value;

                rLtmCellEarlySyncInfo.du[cnt].duid = static_cast<int>(rItem.lTMgNB_DU_ID);

                int preambleCnt = 0;
                auto *pPreambleList = rItem.preambleIndexList;
                while (pPreambleList)
                {
                    rLtmCellEarlySyncInfo.du[cnt].preambleIndex[preambleCnt] = pPreambleList->value.preambleIndex;
                    preambleCnt++;
                    pPreambleList = pPreambleList->next;
                }

                rLtmCellEarlySyncInfo.du[cnt].num_index = static_cast<uint16_t>(preambleCnt);

                cnt++;
                pList = pList->next;
            }

            rLtmCellEarlySyncInfo.num_du = static_cast<uint16_t>(cnt);
        }
    }

    if (DBG->flag.logLtm)
    {
        VCCB_PRINT_CALL_COMMENT(&rCall, "[LTM:DB] store the EarlySyncInformation ltmBufferMap[%d][%d] ltmCellIdx(%u))\n",
            rCall.myThreadId, rCall.callId, ltmCellIdx);
    }

    return GOOD;
}

int16_t LtmBufferManager::store_F1_LTMConfiguration(
    callInfo_type &rCall, uint16_t ltmCellIdx, F1_LTMConfiguration *ptLtmConfiguration)
{
    AUTO_TRACE_FUNC;

    auto pLtmCell = getCandidateCell(rCall, ltmCellIdx);
    if (pLtmCell == nullptr) return ERROR;

    // TODO: range check..
    auto &rLtmResourceConfig = pLtmCell->ltmResourceConfig;

    if (ptLtmConfiguration == NULL)
    {
        return GOOD;
    }

    // SSB Information
    auto *pSsbList = ptLtmConfiguration->sSBInformation.sSBInformationList;
    while (pSsbList != NULL)
    {
        auto &rItem = pSsbList->value;

        // NRRRC spec
        rLtmResourceConfig.ltm_SSB_Config_r18.bit_mask = 0;

        // ssb-Frequency-r18                              ARFCN-ValueNR,
        rLtmResourceConfig.ltm_SSB_Config_r18.ssb_Frequency_r18 = rItem.sSB_Configuration.sSB_frequency;

        // TODO: need to check the enum mapping
        // subcarrierSpacing-r18                          SubcarrierSpacing,
        switch (rItem.sSB_Configuration.sSB_subcarrier_spacing)
        {
            case F1_sSB_subcarrier_spacing_kHz15:
                rLtmResourceConfig.ltm_SSB_Config_r18.subcarrierSpacing_r18 = NRRRC_SubcarrierSpacing_kHz15;
                break;
            case F1_sSB_subcarrier_spacing_kHz30:
                rLtmResourceConfig.ltm_SSB_Config_r18.subcarrierSpacing_r18 = NRRRC_SubcarrierSpacing_kHz30;
                break;
            case F1_sSB_subcarrier_spacing_kHz60:
                rLtmResourceConfig.ltm_SSB_Config_r18.subcarrierSpacing_r18 = NRRRC_kHz60;
                break;
            case F1_sSB_subcarrier_spacing_kHz120:
                rLtmResourceConfig.ltm_SSB_Config_r18.subcarrierSpacing_r18 = NRRRC_kHz120;
                break;
            case F1_sSB_subcarrier_spacing_kHz240:
                rLtmResourceConfig.ltm_SSB_Config_r18.subcarrierSpacing_r18 = NRRRC_kHz240;
                break;
            case F1_F1__enum32_kHz480:
                rLtmResourceConfig.ltm_SSB_Config_r18.subcarrierSpacing_r18 = NRRRC_kHz480_v1700;
                break;
            case F1_F1__enum32_kHz960:
                rLtmResourceConfig.ltm_SSB_Config_r18.subcarrierSpacing_r18 = NRRRC_kHz960_v1700;
                break;
            default:
                rLtmResourceConfig.ltm_SSB_Config_r18.subcarrierSpacing_r18 = NRRRC_SubcarrierSpacing_spare1;
                break;
        }

        // ssb-Periodicity-r18                            ENUMERATED {ms5, ms10, ms20, ms40, ms80, ms160, spare2,
        // spare1} OPTIONAL,   -- Need R
        switch (rItem.sSB_Configuration.sSB_periodicity)
        {
            case F1_sSB_periodicity_ms5:
                rLtmResourceConfig.ltm_SSB_Config_r18.ssb_Periodicity_r18 = NRRRC_ssb_Periodicity_r18_ms5;
                break;
            case F1_sSB_periodicity_ms10:
                rLtmResourceConfig.ltm_SSB_Config_r18.ssb_Periodicity_r18 = NRRRC_ssb_Periodicity_r18_ms10;
                break;
            case F1_sSB_periodicity_ms20:
                rLtmResourceConfig.ltm_SSB_Config_r18.ssb_Periodicity_r18 = NRRRC_ssb_Periodicity_r18_ms20;
                break;
            case F1_sSB_periodicity_ms40:
                rLtmResourceConfig.ltm_SSB_Config_r18.ssb_Periodicity_r18 = NRRRC_ssb_Periodicity_r18_ms40;
                break;
            case F1_sSB_periodicity_ms80:
                rLtmResourceConfig.ltm_SSB_Config_r18.ssb_Periodicity_r18 = NRRRC_ssb_Periodicity_r18_ms80;
                break;
            case F1_sSB_periodicity_ms160:
                rLtmResourceConfig.ltm_SSB_Config_r18.ssb_Periodicity_r18 = NRRRC_ssb_Periodicity_r18_ms160;
                break;
            default:
                rLtmResourceConfig.ltm_SSB_Config_r18.ssb_Periodicity_r18 = NRRRC_ssb_Periodicity_r18_spare1;
                break;
        }

        // ssb-PositionsInBurst-r18                       CHOICE {
        //     shortBitmap                                    BIT STRING (SIZE (4)),
        //     mediumBitmap                                   BIT STRING (SIZE (8)),
        //     longBitmap                                     BIT STRING (SIZE (64))
        // }    OPTIONAL,   -- Need R
        //
        //
        auto &rSsb_PositionsInBurst_r18 = rLtmResourceConfig.ltm_SSB_Config_r18.ssb_PositionsInBurst_r18;

        rSsb_PositionsInBurst_r18.choice = 0;
        if (rItem.sSB_Configuration.bit_mask & F1_sSB_position_in_burst_present)
        {
            switch (rItem.sSB_Configuration.sSB_position_in_burst.choice)
            {
                case F1_SSB_PositionsInBurst_shortBitmap_chosen:
                    rSsb_PositionsInBurst_r18.choice = NRRRC_ssb_PositionsInBurst_r18_shortBitmap_chosen;

                    rSsb_PositionsInBurst_r18.u.shortBitmap.length = rItem.sSB_Configuration.sSB_position_in_burst.u.shortBitmap.length;
                    rSsb_PositionsInBurst_r18.u.shortBitmap.value = &rLtmResourceConfig.ssbBitMap[0];
                    rLtmResourceConfig.ssbBitMap[0] = rItem.sSB_Configuration.sSB_position_in_burst.u.shortBitmap.value[0];
                    break;
                case F1_SSB_PositionsInBurst_mediumBitmap_chosen:
                    rSsb_PositionsInBurst_r18.choice = NRRRC_ssb_PositionsInBurst_r18_mediumBitmap_chosen;

                    rSsb_PositionsInBurst_r18.u.mediumBitmap.length = rItem.sSB_Configuration.sSB_position_in_burst.u.mediumBitmap.length;
                    rSsb_PositionsInBurst_r18.u.mediumBitmap.value = &rLtmResourceConfig.ssbBitMap[0];
                    rLtmResourceConfig.ssbBitMap[0] = rItem.sSB_Configuration.sSB_position_in_burst.u.mediumBitmap.value[0];
                    break;
                case F1_SSB_PositionsInBurst_longBitmap_chosen:
                    rSsb_PositionsInBurst_r18.choice = NRRRC_ssb_PositionsInBurst_r18_longBitmap_chosen;

                    rSsb_PositionsInBurst_r18.u.longBitmap.length = rItem.sSB_Configuration.sSB_position_in_burst.u.longBitmap.length;
                    rSsb_PositionsInBurst_r18.u.longBitmap.value = &rLtmResourceConfig.ssbBitMap[0];
                    for (int i = 0; i < 8; i++)
                    {
                        rLtmResourceConfig.ssbBitMap[i] = rItem.sSB_Configuration.sSB_position_in_burst.u.longBitmap.value[i];
                    }
                    break;
                default:
                    break;
            }
        }

        if (rSsb_PositionsInBurst_r18.choice > 0)
        {
            rLtmResourceConfig.ltm_SSB_Config_r18.bit_mask |= NRRRC_ssb_PositionsInBurst_r18_present;
        }

        // ss-PBCH-BlockPower-r18                         INTEGER (-60..50) OPTIONAL,   -- Need R
        rLtmResourceConfig.ltm_SSB_Config_r18.bit_mask |= NRRRC_ss_PBCH_BlockPower_r18_present;
        rLtmResourceConfig.ltm_SSB_Config_r18.ss_PBCH_BlockPower_r18 = rItem.sSB_Configuration.sSB_Transmit_power;

        // F1AP spec
        // SSBInformationItem ::= SEQUENCE {
        // sSB-Configuration    SSB-TF-Configuration,
        // pCI-NR                              NRPCI,
        // iE-Extensions                ProtocolExtensionContainer { { SSBInformationItem-ExtIEs } }    OPTIONAL

        // SSB-TF-Configuration
        // sSB-frequency                        INTEGER (0..3279165),
        // sSB-subcarrier-spacing               ENUMERATED {kHz15, kHz30, kHz60, kHz120, kHz240, ..., kHz480, kHz960},
        // -- The value kHz60 is not supported in this version of the specification.
        // sSB-Transmit-power                   INTEGER (-60..50),
        // sSB-periodicity                      ENUMERATED {ms5, ms10, ms20, ms40, ms80, ms160, ...},
        // sSB-half-frame-offset                INTEGER(0..1),
        // sSB-SFN-offset                       INTEGER(0..15),
        // sSB-position-in-burst                SSB-PositionsInBurst            OPTIONAL,
        // sFNInitialisationTime                RelativeTime1900                OPTIONAL,
        // iE-Extensions                        ProtocolExtensionContainer { { SSB-TF-Configuration-ExtIEs} } OPTIONAL

        // SSB-TF-Configuration-ExtIEs  F1AP-PROTOCOL-EXTENSION ::= {
        //     ...
        // }

        // rItem.sSB_Configuration
        // rItem.pCI_NR

        pSsbList = pSsbList->next;

        // TBD: support 1 ssb
        break;
    }

    // Reference Configuration Information

    // Complete Configuration Indicator

    // LTM CFRA Resource Configuration
    if (ptLtmConfiguration->bit_mask & F1_LTMConfiguration_lTMCFRAResourceConfig_present)
    {
        rLtmResourceConfig.num_octets_cfra = static_cast<uint16_t>(ptLtmConfiguration->lTMCFRAResourceConfig.length);
        if (ptLtmConfiguration->lTMCFRAResourceConfig.length > 0)
        {
            memcpy(rLtmResourceConfig.cfra, ptLtmConfiguration->lTMCFRAResourceConfig.value,
                ptLtmConfiguration->lTMCFRAResourceConfig.length);
        }
    }

    // LTM CFRA Resource Configuration for SUL

    if (DBG->flag.logLtm)
    {
        VCCB_PRINT_CALL_COMMENT(
            &rCall, "[LTM:DB] store the LTMConfiguration ltmBufferMap[%d][%d] ltmCellIdx(%u))\n", rCall.myThreadId, rCall.callId, ltmCellIdx);
    }

    return GOOD;
}

int16_t LtmBufferManager::getStored_F1_LTMCFRAResourceConfig(
    callInfo_type &rCall, uint16_t ltmCellIdx, F1_LTMCFRAResourceConfig &rConfig)
{
    AUTO_TRACE_FUNC;

    auto pLtmCell = getCandidateCell(rCall, ltmCellIdx);
    if (pLtmCell == nullptr) return ERROR;

    // TODO: range check..
    auto &rLtmResourceConfig = pLtmCell->ltmResourceConfig;

    rConfig.length = rLtmResourceConfig.num_octets_cfra;
    rConfig.value = rLtmResourceConfig.cfra;

    if (DBG->flag.logLtm)
    {
        VCCB_PRINT_CALL_COMMENT(&rCall,
            "[LTM:DB] get stored F1_LTMCFRAResourceConfig ltmBufferMap[%d][%d] ltmCellIdx(%u) length(%d)\n",
            rCall.myThreadId, rCall.callId, ltmCellIdx, rConfig.length);
    }

    return GOOD;
}

int16_t LtmBufferManager::getStored_F1_TCIStatesConfigurationsList(
    callInfo_type &rCall, uint16_t ltmCellIdx, F1_TCIStatesConfigurationsList &rConfig)
{
    AUTO_TRACE_FUNC;
    
    auto pLtmCell = getCandidateCell(rCall, ltmCellIdx);
    if (pLtmCell == nullptr) return ERROR;

    // TODO: range check..
    auto &rEarlySyncInfo = pLtmCell->earlySyncInfo;

    rConfig.length = rEarlySyncInfo.num_octets_tci;
    rConfig.value = rEarlySyncInfo.tCIStatesConfigurationsList;

    if (DBG->flag.logLtm)
    {
        VCCB_PRINT_CALL_COMMENT(&rCall,
            "[LTM:DB] get stored F1_TCIStatesConfigurationsList ltmBufferMap[%d][%d] ltmCellIdx(%u) length(%d)\n",
            rCall.myThreadId, rCall.callId, ltmCellIdx, rConfig.length);
    }

    return GOOD;
}

int16_t LtmBufferManager::getStored_F1_EarlyULSyncConfig__RachConfiguration(
    callInfo_type &rCall, uint16_t ltmCellIdx, unsigned int &rLen, unsigned char *&rpValue)
{
    AUTO_TRACE_FUNC;
    
    auto pLtmCell = getCandidateCell(rCall, ltmCellIdx);
    if (pLtmCell == nullptr) return ERROR;

    // TODO: range check..
    auto &rEarlySyncInfo = pLtmCell->earlySyncInfo;

    rLen = rEarlySyncInfo.num_octets_rach;
    rpValue = rEarlySyncInfo.rACH;

    if (DBG->flag.logLtm)
    {
        VCCB_PRINT_CALL_COMMENT(&rCall,
            "[LTM:DB] get stored F1_EarlyULSyncConfig Rach ltmBufferMap[%d][%d] ltmCellIdx(%u) length(%d)\n",
            rCall.myThreadId, rCall.callId, ltmCellIdx, rLen);
    }

    return GOOD;
}

int16_t LtmBufferManager::getStored_NRRRC_LTM_SSB_Config_r18(
    callInfo_type &rCall, uint16_t ltmCellIdx, NRRRC_LTM_SSB_Config_r18 &rConfig)
{
    AUTO_TRACE_FUNC;
    
    auto pLtmCell = getCandidateCell(rCall, ltmCellIdx);
    if (pLtmCell == nullptr) return ERROR;

    // TODO: range check..
    auto &rLtmResourceConfig = pLtmCell->ltmResourceConfig;

    rConfig = rLtmResourceConfig.ltm_SSB_Config_r18;

    if (DBG->flag.logLtm)
    {
        VCCB_PRINT_CALL_COMMENT(&rCall,
            "[LTM:DB] get stored NRRRC_LTM_SSB_Config_r18 Rach ltmBufferMap[%d][%d] ltmCellIdx(%u)\n", rCall.myThreadId,
            rCall.callId, ltmCellIdx);
    }

    return GOOD;
}

int16_t LtmBufferManager::getStored_NRRRC_LTM_TCI_Info_r18(
    callInfo_type &rCall, uint16_t ltmCellIdx, NRRRC_LTM_TCI_Info_r18 &rConfig)
{
    AUTO_TRACE_FUNC;
    auto pLtmCell = getCandidateCell(rCall, ltmCellIdx);
    if (pLtmCell == nullptr) return ERROR;

    auto &rLtmCellEarlySyncInfo = pLtmCell->earlySyncInfo;

    // if (0)  // copy decoded struct option
    // {
    //     rConfig = rLtmCellEarlySyncInfo.ltm_TCI_Info_r18;
    // }
    // else if (0)  // copy docoded hex option
    // {
    //     rConfig = *(NRRRC_LTM_TCI_Info_r18 *)rLtmCellEarlySyncInfo.hexDecoded;
    // }
    // else  // store encoded hex
    {
        if (0 == rLtmCellEarlySyncInfo.num_octets_tci)
        {
            return BREAK;
        }

        void *msgPtr = rLtmCellEarlySyncInfo.hexDecoded;
        int16_t status = UnpackNRRRC_AllMsg(&msgPtr, sizeof(rLtmCellEarlySyncInfo.hexDecoded),
            NRRRC_LTM_TCI_Info_r18_PDU, rLtmCellEarlySyncInfo.tCIStatesConfigurationsList,
            rLtmCellEarlySyncInfo.num_octets_tci);
        VCCB_RETURN_ON_CALL_ERROR(&rCall, status, "UnpackNRRRC_AllMsg(NRRRC_LTM_TCI_Info_r18_PDU) ERROR!\n");

        // copy the NRRRC_LTM_TCI_Info_r18 struct. pointer value of buffer is also copied.
        rConfig = *reinterpret_cast<NRRRC_LTM_TCI_Info_r18 *>(msgPtr);
    }

    if (DBG->flag.logLtm)
    {
        VCCB_PRINT_CALL_COMMENT(&rCall,
            "[LTM:DB] get stored NRRRC_LTM_TCI_Info_r18 size(%d) ltmBufferMap[%d][%d] ltmCellIdx(%u)\n",
            rLtmCellEarlySyncInfo.num_octets_tci, rCall.myThreadId, rCall.callId, ltmCellIdx);
    }

    return GOOD;
}

int16_t LtmBufferManager::getStored_F1_EarlyULSyncConfig__LtmGnbDusList(callInfo_type &rCall, uint16_t ltmCellIdx,
    struct F1_LTMgNB_DU_IDs_PreambleIndexList_ (&rDuList)[MAX_NUM_LTM_DUS],
    struct F1_PreambleIndexList_ (&rPreambleIndexListPerDu)[MAX_NUM_LTM_DUS][MAX_NUM_LTM_CELLS])
{
    AUTO_TRACE_FUNC;
    
    auto pLtmCell = getCandidateCell(rCall, ltmCellIdx);
    if (pLtmCell == nullptr) return ERROR;

    // TODO: range check..
    auto &rEarlySyncInfo = pLtmCell->earlySyncInfo;

    int duIdx;
    for (duIdx = 0; duIdx < rEarlySyncInfo.num_du; duIdx++)
    {
        rDuList[duIdx].value.bit_mask = 0;
        rDuList[duIdx].value.iE_Extensions = NULL;

        rDuList[duIdx].value.lTMgNB_DU_ID = static_cast<unsigned long>(rEarlySyncInfo.du[duIdx].duid);
        rDuList[duIdx].value.preambleIndexList = NULL;

        {
            int num_idx;
            for (num_idx = 0; num_idx < rEarlySyncInfo.du[duIdx].num_index; num_idx++)
            {
                rPreambleIndexListPerDu[duIdx][num_idx].value.bit_mask = 0;
                rPreambleIndexListPerDu[duIdx][num_idx].value.iE_Extensions = NULL;

                rPreambleIndexListPerDu[duIdx][num_idx].value.preambleIndex =
                    rEarlySyncInfo.du[duIdx].preambleIndex[num_idx];
            }

            if (num_idx > 0)
            {
                if (ERROR == VCCB_ConnectLinkedList(rPreambleIndexListPerDu[duIdx], num_idx))
                {
                    VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in F1_PreambleIndexList_!\n");
                    return ERROR;
                }
                rDuList[duIdx].value.preambleIndexList = rPreambleIndexListPerDu[duIdx];
                rDuList[duIdx].value.bit_mask |= F1_preambleIndexList_present;
            }
        }
    }

    if (duIdx > 0)
    {
        if (ERROR == VCCB_ConnectLinkedList(rDuList, duIdx))
        {
            VCCB_PRINT_ERROR("ERROR: VCCB_ConnectLinkedList failed in F1_LTMgNB_DU_IDs_PreambleIndexList_!\n");
            return ERROR;
        }
    }

    if (DBG->flag.logLtm)
    {
        VCCB_PRINT_CALL_COMMENT(&rCall,
            "[LTM:DB] get stored F1_EarlyULSyncConfig LtmGnbDusList ltmBufferMap[%d][%d] ltmCellIdx(%u) num DUs(%d)\n", rCall.myThreadId,
            rCall.callId, ltmCellIdx, rEarlySyncInfo.num_du);
    }

    return GOOD;
}

LtmProcRelatedData_type *LtmBufferManager::getLtmProcRelatedDataForCall(const callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_NULLPTR(rCall.myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_NULLPTR(rCall.callId, MAX_CALL_NUM_VCCB);

    // Get or create call buffer
    CallBufferInfo* bufferInfo = getOrCreateCallBuffer(rCall.myThreadId, rCall.callId);
    if (bufferInfo == nullptr) {
        return nullptr;  // Failed to get or create buffer
    }

    bufferInfo->state = CI_use;
    return &bufferInfo->procRelatedData;
}

 // Safe allocation when adding Candidate Cell
// Note: This function is thread-safe only when called from the same thread.
// No internal locking is performed for performance reasons.
int16_t LtmBufferManager::addCandidateCell(callInfo_type &rCall, int16_t cellIndex) {
    uint32_t threadId = rCall.myThreadId;
    uint32_t callId = rCall.callId;

    // Validate Thread ID range (before array access)
    if (threadId >= VCCB_CALL_THREAD_NUM) {
        VCCB_PRINT_CALL_LTM(&rCall, "Invalid threadId: %u (must be < %u)\n", threadId, VCCB_CALL_THREAD_NUM);
        return ERROR;
    }

    // Get or create call buffer
    CallBufferInfo* callBuffer = getOrCreateCallBuffer(threadId, callId);
    if (callBuffer == nullptr) {
        return ERROR;  // Failed to get or create buffer
    }

    callBuffer->state = CI_use;

    // Determine cellIndex (limited to range 0-7)
    const int16_t MAX_CELL_INDEX = 7;
    const int16_t MIN_CELL_INDEX = 0;
    
    if (cellIndex == -1)
    {
        for (uint16_t index = MIN_CELL_INDEX; index < MAX_CELL_INDEX + 1; index++)
        {
            if (callBuffer->candCellsMap.find(index) == callBuffer->candCellsMap.end())
            {
                cellIndex = static_cast<int16_t>(index);
                break;
            }
        }

        if (cellIndex == -1) {
            VCCB_PRINT_CALL_ERROR(&rCall, "Cannot allocate cell index\n");
            return ERROR;
        }
    }
    else
    {
        // Explicit index: validate range
        if (cellIndex < MIN_CELL_INDEX || cellIndex > MAX_CELL_INDEX) {
            VCCB_PRINT_CALL_ERROR(&rCall, "Invalid cellIndex: %d (must be between %d and %d)\n", 
                cellIndex, MIN_CELL_INDEX, MAX_CELL_INDEX);
            return ERROR;
        }
        
        if (callBuffer->candCellsMap.find(static_cast<uint16_t>(cellIndex)) != callBuffer->candCellsMap.end())
        {
            return ERROR;  // Already exists
        }
    }

    // Allocate new buffer with shared_ptr (thread-specific pool, no mutex)
    std::shared_ptr<ltmCandidateCellInfo_type> newCellBuffer;
    {
        // Thread-specific pool, no mutex needed
        newCellBuffer = CandidateCellPool::acquireBuffer(threadId);
    }

    if (!newCellBuffer)
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "Failed to allocate buffer for candidate cell (threadId: %u, callId: %u, cellIndex: %d)\n",
            threadId, callId, cellIndex);
        return ERROR;
    }

    // Add to map
    callBuffer->candCellsMap.insert(
        std::make_pair(cellIndex, CandidateCellInfo(newCellBuffer)));

    // Output only in debug mode (performance optimization)
    // Added DBG pointer safety check
    if (DBG->flag.logLtm && DBG->log.logStoreDebugLevel >= PL_COMMENT) 
    {
        printCallBufferInfo(rCall, *callBuffer);
    }
    
    return cellIndex;
}

/**
    * @brief Remove Candidate Cell (explicit memory cleanup)
    * @note This function is thread-safe only when called from the same thread.
    *       No internal locking is performed for performance reasons.
*/
void LtmBufferManager::removeCandidateCell(callInfo_type &rCall, uint16_t cellIndex) {
    uint32_t threadId = rCall.myThreadId;
    uint32_t callId = rCall.callId;
    
    // Validate Thread ID range
    if (threadId >= VCCB_CALL_THREAD_NUM) {
        VCCB_PRINT_CALL_ERROR(&rCall, "Invalid threadId: %u (must be < %u)\n", threadId, VCCB_CALL_THREAD_NUM);
        return;
    }
    
    // Get call buffer (does not create if not exists)
    CallBufferInfo* callBuffer = getCallBuffer(threadId, callId);
    if (callBuffer == nullptr) {
        return; // Already removed
    }
    auto mapIt = callBuffer->candCellsMap.find(cellIndex);
    if (mapIt == callBuffer->candCellsMap.end()) {
        return; // Already removed
    }
    
    // Explicit shared_ptr release
    mapIt->second.data.reset();  // Explicit release
    mapIt->second.isValid = false;
    
    // Remove from map
    callBuffer->candCellsMap.erase(mapIt);
    
    // Output only in debug mode (performance optimization)
    // Added DBG pointer safety check
    if (DBG->flag.logLtm && DBG->log.logStoreDebugLevel >= PL_COMMENT)
    {
        printCallInfo(rCall);
    }
    
    // Clean up callBuffer if vector is empty
    if (callBuffer->candCellsMap.empty()) {
        ltmBufferMap[threadId].erase(callId);
    }
    
    return; // Success
}

/**
    * @brief Get Candidate Cell information
    * @note This function is thread-safe only when called from the same thread.
    *       No internal locking is performed for performance reasons.
*/
std::shared_ptr<ltmCandidateCellInfo_type> LtmBufferManager::getCandidateCell(callInfo_type &rCall, uint16_t cellIndex) {
    uint32_t threadId = rCall.myThreadId;
    uint32_t callId = rCall.callId;
    
    // Validate Thread ID range
    if (threadId >= VCCB_CALL_THREAD_NUM ) {
        VCCB_PRINT_CALL_ERROR(&rCall, "Invalid threadId: %u (must be < %u)\n", threadId, VCCB_CALL_THREAD_NUM );
        return nullptr;
    }
    
    // Get call buffer (does not create if not exists)
    CallBufferInfo* callBuffer = getCallBuffer(threadId, callId);
    if (callBuffer == nullptr) {
        return nullptr;
    }
    auto mapIt = callBuffer->candCellsMap.find(cellIndex);
    if (mapIt == callBuffer->candCellsMap.end()) {
        return nullptr;
    }
    
    auto &cellInfo = mapIt->second;
    return cellInfo.isValid ? cellInfo.data : nullptr;
}

 /**
    * @brief Cleanup Call (explicit memory cleanup)
    * @note This function is thread-safe only when called from the same thread.
    *       No internal locking is performed for performance reasons.
*/
void LtmBufferManager::cleanupCall(callInfo_type &rCall) 
{

    uint32_t threadId = rCall.myThreadId;
    uint32_t callId = rCall.callId;

    // Validate Thread ID range
    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);

    // To avoid invalid memory access, check if rCall is temp call or not.
    if (callId >= VCCB_MAX_CALL_COUNT_PER_CPC || (&rCall != &ENV->callInfo[callId]))
    {
        VCCB_PRINT_CALL_LTM(&rCall, "Invalid CallId: %u (must be < %u) or tempCall\n", callId, VCCB_MAX_CALL_COUNT_PER_CPC);
        // If temp call, skip LtmBufferMap initialization.
        return;
    }
    
    VCCB_PRINT_CALL_LTM(&rCall, "=== Cleanup Call (Thread: %u, Call: %u) ===\n", threadId, callId);
    
    // Get call buffer (does not create if not exists)
    CallBufferInfo* callBuffer = getCallBuffer(threadId, callId);
    
    if (callBuffer != nullptr) {
        VCCB_PRINT_CALL_LTM(&rCall, "Cleaning up call with %zu candidate cells\n", callBuffer->candCellsMap.size());
        
        // Explicit shared_ptr release
        for (auto &candPair : callBuffer->candCellsMap) {
            candPair.second.data.reset();  // Explicit release
            candPair.second.isValid = false;
        }
    }
    
    ltmBufferMap[threadId].erase(callId);
    
    VCCB_PRINT_CALL_LTM(&rCall, "Call cleanup completed\n");
    VCCB_PRINT_CALL_LTM(&rCall, "=====================================\n");
}
/**
* @brief Cleanup entire Thread (explicit memory cleanup)
*/
void LtmBufferManager::cleanupThread(uint32_t threadId) 
{
    // Validate Thread ID range (before acquiring lock)
    if (threadId >= VCCB_CALL_THREAD_NUM) {
        VCCB_PRINTF("Invalid threadId: %u (must be < %u)\n", threadId, VCCB_CALL_THREAD_NUM);
        return;
    }
    
    // No mutex needed - each thread accesses only its own map
    VCCB_PRINTF("=== Cleanup Thread %u ===\n", threadId);
    
    auto &threadMap = ltmBufferMap[threadId];
    size_t callCount = threadMap.size();
    size_t totalCells = 0;
    
    // Explicit shared_ptr release
    for (auto &callPair : threadMap) {
        for (auto &candPair : callPair.second.candCellsMap) {
            candPair.second.data.reset();  // Explicit release
            candPair.second.isValid = false;
        }
        totalCells += callPair.second.candCellsMap.size();
    }
    
    VCCB_PRINTF("Cleaning up %zu calls with %zu total candidate cells\n", callCount, totalCells);
    
    ltmBufferMap[threadId].clear();
    
    VCCB_PRINTF("Thread cleanup completed\n");
    VCCB_PRINTF("========================\n");
}

 /**
* @brief Cleanup all (explicit memory cleanup)
*/
void LtmBufferManager::cleanupAll() {
    // No mutex needed - each thread's map is independent
    VCCB_PRINTF("=== Cleanup All Threads ===\n");
    
    size_t totalCalls = 0;
    size_t totalCells = 0;
    
    // Explicit shared_ptr release
    for (uint32_t threadId = 0; threadId < VCCB_CALL_THREAD_NUM; threadId++) {
        auto &threadMap = ltmBufferMap[threadId];
        totalCalls += threadMap.size();
        
        for (auto &callPair : threadMap) {
            for (auto &candPair : callPair.second.candCellsMap) {
                candPair.second.data.reset();  // Explicit release
                candPair.second.isValid = false;
            }
            totalCells += callPair.second.candCellsMap.size();
        }
    }
    
    VCCB_PRINTF("Cleaning up all threads: %zu total calls with %zu total candidate cells\n", totalCalls, totalCells);
    
    for (uint32_t threadId = 0; threadId < VCCB_CALL_THREAD_NUM; threadId++) {
        ltmBufferMap[threadId].clear();
    }
    
    // Clear memory pools for all threads
    for (uint32_t threadId = 0; threadId < VCCB_CALL_THREAD_NUM; threadId++) {
        cellPool[threadId].clear();
    }
    
    VCCB_PRINTF("All threads cleanup completed\n");
    VCCB_PRINTF("==========================\n");
}

/**
     * @brief Example: Iterate through all candidate cells for a specific call
     * @param rCall Call information
     * @param callback Function to process each candidate cell (cellIndex, cellData)
     * @return Number of candidate cells processed
     * @note This function is thread-safe only when called from the same thread.
     *       No internal locking is performed for performance reasons.
     * 
     * @example
     *   callInfo_type call;
     *   // ... initialize call ...
     *   LtmBufferManager::getInstance().iterateCallCandidateCells(call,
     *       [](uint16_t cellIndex, std::shared_ptr<ltmCandidateCellInfo_type>& cellData) {
     *           VCCB_PRINTF("Processing cell index: %u\n", cellIndex);
     *           // Process cellData... (can modify cellData)
     *       });
     */
size_t LtmBufferManager::iterateCallCandidateCells(callInfo_type &rCall, 
                                    std::function<void(uint16_t cellIndex, 
                                                        std::shared_ptr<ltmCandidateCellInfo_type>& cellData)> callback) {
    uint32_t threadId = rCall.myThreadId;
    uint32_t callId = rCall.callId;
    
    // Validate Thread ID range
    if (threadId >= VCCB_CALL_THREAD_NUM) {
        VCCB_PRINT_CALL_LTM(&rCall, "Invalid threadId: %u (must be < %u)\n", threadId, VCCB_CALL_THREAD_NUM);
        return 0;
    }
    
    // Get call buffer (does not create if not exists)
    CallBufferInfo* callBuffer = getCallBuffer(threadId, callId);
    if (callBuffer == nullptr) {
        return 0; // Call not found
    }
    size_t count = 0;
    
    // Iterate through all candidate cells using candidate cells map
    for (const auto &candPair : callBuffer->candCellsMap) {
        uint16_t cellIndex = candPair.first;
        auto &cellInfo = candPair.second;
        
        if (cellInfo.isValid && cellInfo.data) {
            callback(cellIndex, const_cast<std::shared_ptr<ltmCandidateCellInfo_type>&>(cellInfo.data));
            count++;
        }
    }
    
    return count;
}

void LtmBufferManager::printAllThreadInfoForDsh() {
    // No mutex needed - read-only operation on independent thread maps
    LOGCMD("=== All Threads Info ===\n");
    
    size_t totalCalls = 0;
    size_t totalCandidateCells = 0;
    
    for (uint32_t threadId = 0; threadId < VCCB_CALL_THREAD_NUM; threadId++) {
        auto &threadMap = ltmBufferMap[threadId];
        
        if (threadMap.empty()) {
            continue; // Skip empty Thread
        }
        
        LOGCMD("Thread %u: %zu calls\n", threadId, threadMap.size());
        totalCalls += threadMap.size();
        
        for (const auto &callPair : threadMap) {
            uint32_t callId = callPair.first;
            const auto &callBuffer = callPair.second;
            
            LOGCMD("  Call %u: %zu candidate cells\n", callId, callBuffer.candCellsMap.size());
            totalCandidateCells += callBuffer.candCellsMap.size();
        }
    }
    
    LOGCMD("Total Summary:\n");
    LOGCMD("  Total Calls: %zu\n", totalCalls);
    LOGCMD("  Total Candidate Cells: %zu\n", totalCandidateCells);
    LOGCMD("========================\n");
}

void LtmBufferManager::printCallBufferInfo(const callInfo_type &rCall, const CallBufferInfo &rBuffer)
{
    // Perform output operations outside lock
    VCCB_PRINT_CALL_LTM(&rCall, "=== Call Info (Thread: %u, Call: %u) ===\n", rCall.myThreadId, rCall.callId);
    
    VCCB_PRINT_CALL_LTM(&rCall, "State: %d\n", rBuffer.state);
    VCCB_PRINT_CALL_LTM(&rCall, "Candidate Cells Map Size: %zu\n", rBuffer.candCellsMap.size());
    
    // Candidate Cell detailed information
    VCCB_PRINT_CALL_LTM(&rCall, "Candidate Cell Details:\n");
    for (auto mapIt = rBuffer.candCellsMap.begin(); mapIt != rBuffer.candCellsMap.end(); ++mapIt)
    {
        VCCB_PRINT_CALL_LTM(&rCall, "  Map[%u]: Valid=%s, Data=%p\n", 
               mapIt->first, mapIt->second.isValid ? "true" : "false", mapIt->second.data.get());        
    }
    
    VCCB_PRINT_CALL_LTM(&rCall, "=====================================\n");
}

/**
 * @brief Print Call information (extract threadId and callId from callInfo_type)
 * @param rCall Reference to Call information
 */
void LtmBufferManager::printCallInfo(const callInfo_type &rCall) {
    // Minimize lock scope: copy only necessary data then release lock
    uint32_t threadId = rCall.myThreadId;
    uint32_t callId = rCall.callId;
    
    // Validate Thread ID range
    if (threadId >= VCCB_CALL_THREAD_NUM) {
        VCCB_PRINT_CALL_LTM(&rCall, "Invalid threadId: %u (must be < %u)\n", threadId, VCCB_CALL_THREAD_NUM);
        return;
    }
    
    CallBufferInfo localBuffer;
    bool found = false;
    
    {
        // No mutex needed - each thread accesses only its own map
        CallBufferInfo* callBuffer = getCallBuffer(threadId, callId);
        
        if (callBuffer != nullptr) {
            localBuffer = *callBuffer;  // Copy data
            found = true;
        }
    }
    
    // Perform output operations outside lock
    VCCB_PRINT_CALL_LTM(&rCall, "=== Call Info (Thread: %u, Call: %u) ===\n", threadId, callId);
    
    if (!found) {
        VCCB_PRINT_CALL_LTM(&rCall, "Call not found\n");
        return;
    }
    if (DBG->flag.logLtm && DBG->log.logStoreDebugLevel >= PL_COMMENT)
    {
        printCallBufferInfo(rCall, localBuffer);
    }
}

void LtmBufferManager::printPoolStatusForDsh() {
    // No mutex needed - read-only operation on independent thread pools
    LOGCMD("=== Memory Pool Status (Per Thread) ===\n");
    size_t totalPoolSize = 0;
    for (uint32_t threadId = 0; threadId < VCCB_CALL_THREAD_NUM; threadId++) {
        size_t poolSize = cellPool[threadId].getPoolSize();
        totalPoolSize += poolSize;
        LOGCMD("Thread %u: %zu buffers (max: %zu)\n", threadId, poolSize, MAX_POOL_SIZE_PER_THREAD);
    }
    LOGCMD("Total Pool Size: %zu buffers\n", totalPoolSize);
    LOGCMD("Max Pool Size Per Thread: %zu buffers\n", MAX_POOL_SIZE_PER_THREAD);
    LOGCMD("Total Max Pool Size: %zu buffers\n", MAX_POOL_SIZE_PER_THREAD * VCCB_CALL_THREAD_NUM);
    LOGCMD("========================================\n");
}

LtmBufferManager::MemoryStats LtmBufferManager::getMemoryStats() {
    // No mutex needed - read-only operation on independent thread maps and pools
    MemoryStats stats{};
    // Calculate total pool size across all threads
    stats.poolSize = 0;
    for (uint32_t threadId = 0; threadId < VCCB_CALL_THREAD_NUM; threadId++) {
        stats.poolSize += cellPool[threadId].getPoolSize();
    }
    
    size_t maxMapSize = 0;
    size_t totalMapSize = 0;
    size_t mapCount = 0;
    
    for (uint32_t threadId = 0; threadId < VCCB_CALL_THREAD_NUM; threadId++) {
        const auto &threadMap = ltmBufferMap[threadId];
        stats.totalCalls += threadMap.size();
        
        for (const auto &callPair : threadMap) {
            size_t mapSize = callPair.second.candCellsMap.size();
            stats.totalCandidateCells += mapSize;
            totalMapSize += mapSize;
            mapCount++;
            maxMapSize = std::max(maxMapSize, mapSize);
        }
    }
    
    stats.averageMapSize = mapCount > 0 ? totalMapSize / mapCount : 0;
    stats.maxMapSize = maxMapSize;
    
    // Estimate memory usage (including shared_ptr overhead)
    stats.estimatedMemoryMB = 
        static_cast<double>(stats.totalCalls * sizeof(CallBufferInfo) + 
         stats.totalCandidateCells * (sizeof(CandidateCellInfo) + sizeof(ltmCandidateCellInfo_type) + 16)) / (1024.0 * 1024.0); // +16 for control block
    
    return stats;
}

