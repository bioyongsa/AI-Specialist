/**
 * @file        FeatFullConfig.h
 * @brief       Utility functions for Full Configuration
 */

#ifndef VCCB_FEAT_FeatFullConfig_H_
#define VCCB_FEAT_FeatFullConfig_H_

#include "VccbStruct.h"

typedef enum
{
    e_CuInitFullConfig,
    e_DuInitFullConfig,
    e_SnInitFullConfig
} enumFullConfigTrigger_type;

/********************************************************************************
 * @brief This area is the section for initializing the Full Configuration DB.
 ********************************************************************************/
void VLIB_InitFullConfigurationInfo(callInfo_type *ptCi);
void FnVCCB_InitFullConfiguration_InBlockLoading(void);
void VCCM_InitInstalledMeasConfig_ByFullConfiguration(callInfo_type *ptCi);
void VCCM_Init_SA_PDCP_C_SN_ByFullConfiguration(
    callInfo_type *ptCi, enumDuHoRole duHoRole, const F1_RRCContainer *pRRCContainer);

/********************************************************************************
 * @brief This area is the section for Getter and Setter operation of Full Configuration DB.
 ********************************************************************************/
void VCCM_set_FullConfiguration(const char *pFuncName, int lineNum, callInfo_type *ptCi,
    enumFullConfigurationTag_type tag, const char *ptStrCause, ...);
int VCCM_get_FullConfiguration(
    const char *pFuncName, int lineNum, const callInfo_type *ptCi, enumFullConfigurationTag_type tag);

void VCCM_set_FullConfiguration_Drb(const char *pFuncName, int lineNum, callInfo_type *ptCi,
    enumFullConfigurationTag_type tag, int dRBId, const char *ptStrCause, ...);
int VCCM_get_FullConfiguration_Drb(
    const char *pFuncName, int lineNum, callInfo_type *ptCi, enumFullConfigurationTag_type tag, int dRBId);

// CU Init FullConfig
int16_t VCCM_DecisionCuInitFullConfigurationUE(callInfo_type *ptCi, const cellSelection_type *pTargetCellSelection = NULL);

// DU Init FullConfig
int16_t FnVCCB_ProcDuInitFullConfiguration(callInfo_type *, const message_type *, const msgUnpack_type *, const bool withLoggingFlag);

// SN Init FullConfig
int16_t FnVCCB_ProcSnInitFullConfiguration(callInfo_type *, const message_type *, const msgUnpack_type *,const bool withLoggingFlag);

bool FnVCCM_get_deltaConfig_NRRRC_RRCReconfiguration_v1610(callInfo_type *ptCi);
#if F_StandardConformance_AsnNRRRC >= 183000
bool FnVCCM_get_deltaConfig_NRRRC_RRCReconfiguration_v1830(callInfo_type *ptCi);
#endif

/********************************************************************************
 * @brief This area is the section for Force Selection operation of Full Configuration DB.
 ********************************************************************************/
int VCCM_check_FullConfiguration_Filter(const char *func_name, int line);

/********************************************************************************
 * @brief In this section, it checks whether an IE/MSG that requires full configuration is received.
 ********************************************************************************/
int16_t VCCM_check_HandoverPreparationInformation_For_FullConfiguration(
    callInfo_type *ptCi, void *p);

void VCCM_check_CG_ConfigInfo_For_FullConfiguration(callInfo_type *ptCi, void *p);
int16_t VCCM_checkAndDecide_CG_ConfigInfo_For_FullConfiguration(callInfo_type *ptCi, void *p_void);

/********************************************************************************
 * @brief In this section, it checks whether an Scenario that requires full configuration
 ********************************************************************************/
void VHCM_ApplyRadioBearer_For_FullConfiguration(callInfo_type *ptCi);
void FnVCCB_Check_DRB_RlcMode_For_FullConfig(callInfo_type *ptCi);
void FnVCCB_ExcludingCellGroup_For_FullConfig(callInfo_type *ptCi, void *ptCellGroup);

/********************************************************************************
 * @brief This section defines MACRO for Full Configuration.
 ********************************************************************************/
#define VCCB_SET_FULLCONFIGURATION_DRB(__ptCi, __tag, __drbId, __strCause, __args...) \
    VCCM_set_FullConfiguration_Drb(__func__, __LINE__, __ptCi, __tag, __drbId, __strCause, ##__args)
#define VCCB_GET_FULLCONFIGURATION_DRB(__ptCi, __tag, __drbId) \
    VCCM_get_FullConfiguration_Drb(__func__, __LINE__, __ptCi, __tag, __drbId)

#define VCCB_SET_FULLCONFIGURATION(__ptCi, __tag, __strCause, __args...) \
    VCCM_set_FullConfiguration(__func__, __LINE__, __ptCi, __tag, __strCause, ##__args)
#define VCCB_GET_FULLCONFIGURATION(__ptCi, __tag) VCCM_get_FullConfiguration(__func__, __LINE__, __ptCi, __tag)

#define IS_FULLCONFIGURATION_IN_PROCESS(__ptCi)     (TRUE == VCCB_GET_FULLCONFIGURATION(__ptCi, ci_fc_trigger))
#define IS_FULLCONFIGURATION_NOT_IN_PROCESS(__ptCi) (TRUE != VCCB_GET_FULLCONFIGURATION(__ptCi, ci_fc_trigger))

#define FORCE_FULLCONFIGURATION_OVER_XN(__ptCi, __isSender)                                             \
do {                                                                                                    \
    if (VCCM_ForceFullConfigOverXn(__ptCi, __func__, __isSender))                                       \
    {                                                                                                   \
        VCCB_PRINT_CALL_INFORMATIVE(__ptCi, "[Full Config TEST] force MN/SN init full config\n"); \
    }                                                                                                   \
} while(0);

// }}}

/********************************************************************************
 * @brief This section defines Class for Full Configuration.
 ********************************************************************************/
class ForcedDuInitFullConfigForF1SetupModReqMake
{
private:
    bool needProcessing;

    callInfo_type *ptCi = NULL;
    bool needRecovery;
    fullConfiguration_type *ptBackupDB;

    ForcedDuInitFullConfigForF1SetupModReqMake() {}; // Not Allowed
public:
    ForcedDuInitFullConfigForF1SetupModReqMake(callInfo_type *ptCi, fullConfiguration_type *ptBackupDB);
    ~ForcedDuInitFullConfigForF1SetupModReqMake();

    void procF1Setup();
    void procF1Mod();

private:
    void preOperation();
    void postOperation();
};

class ForcedCuInitFullConfigForXnSnAddReqMake
{
private:
    bool needProcessing;

    callInfo_type *ptCi = NULL;
    bool needRecovery;
    fullConfiguration_type *ptBackupDB;

    ForcedCuInitFullConfigForXnSnAddReqMake() {}; // Not Allowed
public:
    ForcedCuInitFullConfigForXnSnAddReqMake(callInfo_type *ptCi, fullConfiguration_type *ptBackupDB);
    ~ForcedCuInitFullConfigForXnSnAddReqMake();

    void procXnSnAddReq();

private:
    void preOperation();
    void postOperation();
};

#endif  // VCCB_FEAT_FeatFullConfig_H_
