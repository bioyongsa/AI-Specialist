/**
 * @file     : UplinkStatusTriggeredMobility.hpp
 * @brief    : Header of Forced Mobility and Forced Release due to Uplink Status indication functions
 *
 * @author   : m.ptak2@samsung.com
 * @date     : 2023-09-11
 *
 * Copyright 2023 by Samsung Electronics Inc.
 *
 * This software is the confidential and proprietary information
 * of Samsung Electronics Inc. (Confidential Information).  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Samsung.
 */

/**
 * USTM - Uplink Status Triggered Mobility
 * 24A - Initial name was Du Triggered Mobility (DTM)
 * 24B - Added new trigger: E1 private msg, so feature name changed to Uplink Status Triggered Mobility
 */
#pragma once

#include "VccbStruct.h"
#include "ComContainers.hpp"
#include <optional>

enum class DuIndicationStatus
{
    ok = 0,
    unsupportedCause,
    iesNotValid,
    error
};

typedef struct
{
    uint16_t cellNbrIdx;
    uint32_t ssbArfcn;
} colocCellNbrs_type;

struct USTM
{
    static constexpr enumUlStatusMobilityReason_type allUlStatusMobilityReasons[MAX_REASON_FORCED_MOBILITY] = {
        ulStatusMobilityReason_ulPrbBlanking, ulStatusMobilityReason_tddInterference,
        ulStatusMobilityReason_badUlQuality, ulStatusMobilityReason_longRtpGap};
};

DuIndicationStatus FnVCCB_USTM_CheckF1UEContextModRequired_IsDuIndication(
    callInfo_type &rCi, const F1_UEContextModificationRequired &msgRequired, uint16_t &f1Cause);

bool FnVCCB_USTM_IsProperCallType(callInfo_type &rCi);
bool FnVCCB_USTM_CheckIfOtherFeaturesBlock(callInfo_type &rCi);

int16_t FnVCCB_HandleForcedMobilityDueToDuIndication(callInfo_type &rCi, msgUnpack_type *ptUnpack,
    SctpDataTransfer_type *ptSctp, F1_GNB_DU_UE_F1AP_ID *pGNB_DU_UE_F1AP_ID);
int16_t FnVCCB_HandleForcedMobilityTriggeredByE1(callInfo_type &rCi);
int16_t FnVCCB_HandleForcedMobilityTriggeredByF1PrivateMessage(
    callInfo_type &rCi, uint8_t forcedMobilityMode, uint8_t ulStatusReason);

int16_t FnVCCB_HandleDequeuedForcedRelease(callInfo_type *ptCi, enqueuedAction);
int16_t FnVCCB_HandleDequeuedForcedMobility(callInfo_type *ptCi, enqueuedAction);

bool FnVCCB_USTM_IsDuForcedMobilityApplicable(callInfo_type &rCi, measurementObjectNRBaseDb_type *const ptMO);
bool FnVCCB_USTM_IsMeasConfFilteringActive(callInfo_type &rCi, const CellNum_type cellNum);
void FnVCCB_USTM_Init(callInfo_type &rCi);
void FnVCCB_USTM_Cancel(callInfo_type &rCi);

using measObjIdxList = simpleVector<uint32_t, VCCB_ARRAY_COUNT(measurementsData_type::measurementObjectsNRDb)>;
using redirectionInfoEutraList =
    simpleVector<redirectionInfoEutra_type, VCCB_ARRAY_COUNT(measurementsData_type::measurementObjectsEUTRADb)>;
measObjIdxList FnVCCB_USTM_SelectTargetCarrierNrForRedirection(callInfo_type &rCi);
redirectionInfoEutraList FnVCCB_USTM_SelectTargetCarrierEutraForRedirection(callInfo_type &rCi);
using ColocNbrs = simpleVector<colocCellNbrs_type, VCCB_ARRAY_COUNT(cuColocCellInfo_type::colocCellEntries)>;
bool FnVCCB_CheckIfArfcnOverloaded(
    callInfo_type &rCi, const VccbCellInfo_type &rCell, const ColocNbrs &colocNbrs, const uint32_t &measObjSsbFreq);
bool VCCM_USTM_CheckIfCellIsOverloaded(const callInfo_type &rCi, const VccbCellInfo_type &rCell, uint16_t nbrIdx);

void VCCB_USTM_StartTimerIfPossible(callInfo_type &rCi);
uint8_t VCCB_StatusReasonToPurpose(const enumUlStatusMobilityReason_type statusReason);

/**
 * @brief Returns PSCell Change MR callback based on the call type.
 *
 * @param rCi info
 * @return enumMeasReportCallbackId_type
 */
inline enumMeasReportCallbackId_type VCCB_USTM_GetProcMrCallbackId(const callInfo_type &rCi)
{
    return ((E_CALLTYPE_NSA != rCi.callType) ? FUN_2_MEASREPORTCALLBACKID(VCCM_ProcMrIntraNrUstmTriggeredForcedHandover)
                                             : FUN_2_MEASREPORTCALLBACKID(VCCM_ProcMrPScellChange));
}

std::optional<enumUlStatusMobilityReason_type> FnVCCB_MapUlStatusReasonFromReportTypeAndPurpose(
    uint8_t reportType, uint8_t reportPurpose);
std::optional<int> FnVCCB_MapUlStatusReasonAndNrHandoverPhaseToCounterType(uint8_t statusReason, enumHoStatType type);
std::optional<int> FnVCCB_MapUlStatusReasonAndInterRatHandoverPhaseToCounterType(uint8_t statusReason, enumHoStatType type);
std::optional<int> FnVCCB_MapUlStatusReasonToNRCounter(enumUlStatusMobilityReason_type statusReason);
std::optional<int> FnVCCB_MapUlStatusReasonToEUTRACounter(enumUlStatusMobilityReason_type statusReason);
enumA5Purpose FnVCCB_MapUlStatusReasonToA5ReportPurpose(
    const callInfo_type &rCi, enumUlStatusMobilityReason_type statusReason);
enumB1Purpose FnVCCB_MapUlStatusReasonToB1ReportPurpose(enumUlStatusMobilityReason_type statusReason);
void FnVCCB_USTM_SetStateForMRBasedRedirection(callInfo_type &rCi);
bool FnVCCB_USTM_IsUstmNrReportTypePurpose(uint8_t reportType, uint8_t reportPurpose);
bool FnVCCB_USTM_IsUstmEutraReportTypePurpose(uint8_t reportType, uint8_t reportPurpose);
