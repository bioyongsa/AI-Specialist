/**
 * @file        FeatConditionalHo.h
 * @brief       Utility functions for Conditional Handover
 */

#ifndef VCCB_FEAT_FeatConditionalHo_H_
#define VCCB_FEAT_FeatConditionalHo_H_

#include "VccbStruct.h"

class ConditionalHandoverExecutionHandler
{
public:
    ConditionalHandoverExecutionHandler() : isChoExecution(true), ptCi(NULL) {};
    ConditionalHandoverExecutionHandler(callInfo_type *ptCallInfo) : isChoExecution(true), ptCi(ptCallInfo) {};
    ~ConditionalHandoverExecutionHandler() {};

    int16_t FnVCCB_ALL_XnapHandoverSuccessDuringRaceCondition();
    int16_t FnVCCB_ALL_XnapHandoverSuccessDuringChoPreparation();
    int16_t FnVCCB_ALL_XnapHandoverSuccessDuringChoAddModRel();
    int16_t FnVCCB_ALL_XnapHandoverSuccessDuringIntraGnbIntraDuHandover();
    int16_t FnVCCB_ALL_XnapHandoverSuccessDuringIntraGnbInterDuHandover();
    int16_t FnVCCB_ALL_XnapHandoverSuccessDuringInterGnbHandover();
    void FnVCCB_DropConditionalHandoverMessage(const char *ptStrEventName);

    bool getIsChoExecution() { return isChoExecution; }

private:
    bool isChoExecution;
    callInfo_type *ptCi;
};

/****************************************************************************
 1. Conditional Handover (Handover Trigger Function)
****************************************************************************/
// int16_t FnVCCB_StartSaHandover_ConditionalHo(callInfo_type *ptCi, uint16_t nbrIdx, uint16_t cause);
// void FnVCCB_ConditionalHandoverAllCancel(callInfo_type *ptCi);

/****************************************************************************
 2. Conditional Handover API
****************************************************************************/
// Conditional Handover Preparation
bool FnVCCB_UeSupportCHOForBandInd(callInfo_type *ptCi, uint16_t bandNr);
bool FnVCCB_UeSupportCHOFailureForBandInd(callInfo_type *ptCi, uint16_t bandNr);
bool FnVCCB_UeSupportCHOTwoTriggerEventForBandInd(callInfo_type *ptCi, uint16_t bandNr);
uint32_t FnVCCB_GetNumOfChoCondCellForSvcGrp(callInfo_type *ptCi, uint8_t svcGrpId);
bool FnVCCB_IsConditionalHandoverSupportedByMobilityConfig(uint16_t cellNum);
bool FnVCCB_IsConditionalHandoverSupported(
    callInfo_type *ptCi, uint16_t cellNum, measurementObjectNRBaseDb_type *ptMO, uint8_t svcGrpId);

void FnVCCB_InitCondHoInfo(callInfo_type *ptCi);

// Meas Configuration
void FnVCCB_ClearChoNewMeasConfig(callInfo_type *ptCi);
void FnVCCB_PostProcessApplyNewMeasConfigForCho(callInfo_type *ptCi);
void FnVCCB_CommitUeMeasForCho(callInfo_type *ptCi);
bool FnVCCB_CheckNeedCondCellProcessing(conditionalCellInfo_type *ptCondCell);
void FnVCCB_CheckChangedUeMeasConfig(conditionalCellInfo_type *ptCondCell, uint8_t *ptCondStatus);

// Conditional Cell List Information
void FnVCCB_InitConditionalCellInfo(conditionalCellInfo_type *ptCondCell, uint8_t condCellIndex);
conditionalCellInfo_type *FnVCCB_GetConditionalCellInfoForIndex(callInfo_type *ptCi, uint8_t condCellIdx);
conditionalCellInfo_type *FnVCCB_GetConditionalCellInfoForCGI(callInfo_type *ptCi, cgi_type findCgi);
uint8_t FnVCCB_AllocConditionalCellInfoForCGI(callInfo_type *ptCi, cgi_type condCellCgi, uint32_t ssbFreq);
void FnVCCB_FreeConditionalCellInfoForIndex(callInfo_type *ptCi, uint8_t condCellIdx);
void FnVCCB_FreeConditionalCellInfoForCGI(callInfo_type *ptCi, cgi_type condCellCgi);
void FnVCCB_CancelConditionalCellTimer(conditionalCellInfo_type *ptCondCell, enumTimerType option);
void FnVCCB_SetConditionalCellStatus(callInfo_type *ptCi, uint8_t condCellIdx, enumCommonStatus_type newStatus);

int16_t FnVCCB_StoreHandoverConfigToCondCellInfo(callInfo_type *, conditionalCellInfo_type *, uint8_t);
int16_t FnVCCB_FillHandoverConfigToCondCellInfo(callInfo_type *, cgi_type);

void FnVCCB_ConditionalCellConfigCommit(callInfo_type *ptCi);
int16_t FnVCCB_ApplyConditionalCellConfig(callInfo_type *ptCi, const enumConditionalHandoverApplyScenarioType scenario);

void FnVCCB_UpdateConditionalCellInfoFromFlag(callInfo_type *ptCi);
void FnVCCB_PrintConditionalHandoverStatus(callInfo_type *ptCi);
void FnVCCB_SetConditionalCellReleaseEvent(
    callInfo_type *ptCi, conditionalCellInfo_type *ptCondCell, enumChoStatType statCause);
void FnVCCB_SetConditionalCellReleaseAllEvent(callInfo_type *ptCi, bool excludeExecution, enumChoStatType statCause);
void FnVCCB_SetConditionalCellModifyEvent(callInfo_type *ptCi, conditionalCellInfo_type *ptCondCell);
void FnVCCB_SetConditionalCellFailToSetupEvent(callInfo_type *ptCi, conditionalCellInfo_type *ptCondCell);
void FnVCCB_HandlingConditionalHandoverEvent(callInfo_type *ptCi, enumConditionalHandoverApplyScenarioType scenario);
void FnVCCB_SetConditionalCellEventInAllState(
    callInfo_type *ptCi, conditionalCellInfo_type *ptCondCell, enumChoStatType statCause);
void FnVCCB_ProcRecvConditionalCellEventInAllState(
    callInfo_type *ptCi, enumConditionalHandoverApplyScenarioType scenario);

void FnVCCB_StartConditionalHandoverQueuingProcedure(callInfo_type *ptCi, const char *ptStrEventName);
void FnVCCB_StartConditionalHandoverAfterCompletionOfCurrentProcedure(callInfo_type *ptCi, const char *ptStrEventName);
int16_t FnVCCB_StartConditionalHandoverAfterForcedStopOfCurrentProcedure(
    callInfo_type *ptCi, const char *ptStrEventName);
void FnVCCB_DropConditionalHandoverMessage(callInfo_type *ptCi, const char *ptStrEventName);
int16_t FnVCCB_QueueingConditionalHandoverAfterForcedStopOfCurrentProcedure(
    callInfo_type *ptCi, const char *ptStrEventName);

int16_t FnVCCB_ALL_XnapHandoverSuccessDuringChoPreparation(callInfo_type *ptCi);
int16_t FnVCCB_ALL_XnapHandoverSuccessDuringChoAddModRel(callInfo_type *ptCi);
int16_t FnVCCB_ALL_XnapHandoverSuccessDuringIntraGnbIntraDuHandover(callInfo_type *ptCi);
int16_t FnVCCB_ALL_XnapHandoverSuccessDuringIntraGnbInterDuHandover(callInfo_type *ptCi);
int16_t FnVCCB_ALL_XnapHandoverSuccessDuringInterGnbHandover(callInfo_type *ptCi);

int16_t FnVCCB_ProcConditionalExecutionCell(callInfo_type *ptCi, cgi_type execNrCgi);
int16_t FnVCCB_StartConditionalHandoverExecutionProcedure(callInfo_type *ptCi, enumHoTypeInterNb interNbType);

void FnVCCB_InitializationChoDbForExecution(callInfo_type *ptCi);
bool FnVCCB_IsAppendConditionalReconfiguration_r16_ForReconfiguration(callInfo_type *ptCi);
void FnVCCB_AppendConditionalReconfiguration_r16_ForReconfigurationComplete(callInfo_type *ptCi);
void FnVCCB_ActivationNonCriticalIE_ForV1610(callInfo_type *ptCi, void *ptIE);

bool FnVCCB_CheckCurrentProcStopAndTriggerConditionalExecHo(const callInfo_type *ptCi);
int16_t FnVCCB_RunCurrentProcStopAndTriggerConditionalExecHo(callInfo_type *ptCi);

void FnVCCB_UpdateInterGnbConnectionState_Source(callInfo_type *ptCi, cgi_type cgi, FLAG_Type sw);
void FnVCCB_UpdateInterGnbConnectionState_Target(callInfo_type *ptCi, cgi_type cgi, FLAG_Type sw);

bool FnVCCB_IsChoPreparationPhase(callInfo_type *ptCi);
bool FnVCCB_IsChoExecutionPhase(callInfo_type *ptCi);

#endif  // VCCB_FEAT_FeatConditionalHo_H_
