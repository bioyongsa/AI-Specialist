/**
 * @file        FeatNonNeighborHo.h
 * @brief       Utility functions for Conditional Handover
 */

#ifndef VCCB_FEAT_FeatNonNeighborHo_H_
#define VCCB_FEAT_FeatNonNeighborHo_H_

#include "VccbStruct.h"
#include "StateMeasurements.h"

int16_t FnVCCB_IsValidSmallCellConfigEutraMo(uint16_t gnbNum, int8_t smallCellPciListIndex);
int16_t FnVCCB_IsValidSmallCellConfigNrMo(uint16_t gnbNum, int8_t smallCellPciListIndex);
bool FnVCCB_CheckPciInNrSmallCellList(uint16_t pci, uint8_t gnbNum, int16_t smallCellIdx);
bool FnVCCB_IsEutraSmallCellPci(callInfo_type *ptCi, uint16_t pci, int8_t SmallCellPciListIndex);
bool FnVCCB_IsNrSmallCellPci(callInfo_type *ptCi, uint16_t pci, int8_t SmallCellPciListIndex);
int FnVCCB_UpdateNonNeighborGnbIdLength(uint16_t gnbNum, uint16_t &gnbIdLength);
uint64_t FnVCCB_GetEcgiForNonNeighborHandover(const nbrEnbCellInfo_type &nbrEnbCell, enumSmallCellEnbIdLength_type enbIdType);
int16_t VHCM_StartSaHandover_InterRat_ToNonNeighborCell(callInfo_type *ptCi, anrCgiInfo anrCgi, uint16_t cause, StartSaHandoverDb& hoInputDb);
int16_t FnVCCB_StartSaHandover_IntergNB_ToNonNeighborCell(
    callInfo_type *ptCi, ncgiNotifyNr_type &ncgiNotifyNr, uint16_t cause, uint16_t gnbIdLength, StartSaHandoverDb& hoInputDb);
void FnVCCB_InitSmallCellPciConfig(uint16_t gnbNum);
bool FnVCCB_IsNonNeighborHoAllowedList(const reportConfigurationInstalledUe_type *pReportConfig);
bool FnVCCB_GetRegisterSmallCellNbrOption(uint16_t gnbNum, int8_t ratType);
bool FnVCCB_IsNonNeighborHoSupported(callInfo_type *ptCi, measurementObjectUe_type *pMeasObj,
    const reportConfigurationInstalledUe_type *pReportConfig, uint8_t ratType);

int16_t FnVCCB_TriggerEutraHandoverByReportCGI(callInfo_type *ptCi, bool cgiAcquired, anrCgiInfo reportedCGI);
void FnVCCB_SetMeasStateForFallback(callInfo_type *ptCi);
bool FnVCCB_IsNrSmallCellPciWithSsbFreq(callInfo_type *ptCi, uint16_t cellNum, uint16_t pci, uint32_t ssbFreq);

#endif  // VCCB_FEAT_FeatNonNeighborHo_H_
