/**
 * @file        FeatUeHistory.h
 * @brief       UE History Information
 */

#ifndef VCCB_FEAT_FeatUeHistory_H_
#define VCCB_FEAT_FeatUeHistory_H_

#include "VccbStruct.h"

// ------------------------------------------------------

// Common API
VccbLastVisitedPSCellHandling_type *FnVCCB_GetLastVisitedPSCellListDB(callInfo_type *ptCi);

void FnVCCB_PrintVisitedPSCellInformation(
    callInfo_type *ptCi,
    VccbLastVisitedPSCellInformation_type *ptPendingVisitCell,
    bool isRx);

void FnVCCB_InitLastVisitedPSCellList(callInfo_type *ptCi);
bool FnVCCB_IsExistLastVisitedPSCellListPendingEntry(callInfo_type *ptCi, VccbLastVisitedPSCellHandling_type *ptScgUHI);

int16_t FnVCCB_StoreNGAP_LastVisitedPSCellInformation(callInfo_type *ptCi,
    NGAP_LastVisitedPSCellInformation_type *ptSrc, VccbLastVisitedPSCellHandling_type *ptScgUHI, bool isPendingEntry);

int FnVCCB_UpdateLastVisitedPSCellListEntry(
    VccbLastVisitedPSCellHandling_type *ptScgUHI, VccbLastVisitedPSCellInformation_type *ptPendingVisitCell);

// Common Proc
void FnVCCB_ProcIdleStateForLastVisitedPSCellInformation(callInfo_type *ptCi);

// ------------------------------------------------------

// MN API
bool FnVCCB_IsSendingUeHistoryInformationRequired(callInfo_type *ptCi);
uint16_t FnVCCB_CalculateNonDcStayTime_InMn(callInfo_type *ptCi, VccbLastVisitedPSCellHandling_type *ptScgUHI);

int16_t FnVCCB_FillNGAP_LastVisitedPSCellInformationIE(callInfo_type *ptCi,
    VccbLastVisitedPSCellInformation_type *ptPendingVisitCell, NGAP_LastVisitedPSCellInformation_type *ptTgt);
bool FnVCCB_CheckCallTypeAllowedByScgUHIInMn(const callInfo_type * ptCi);

// MN Proc
void FnVCCB_ProcSCGUEHistoryInformationFromSN_InMn(callInfo_type *ptCi, msgUnpack_type *ptUnpack);
void FnVCCB_ProcSCGUeHsitoryInformationForPCellChange_InMn(callInfo_type *ptCi);

// ------------------------------------------------------

// SN API
bool FnVCCB_IsSendingScgUeHistoryInformationRequiredInSn(callInfo_type *ptCi, uint16_t msgId);
uint16_t FnVCCB_CalculatePSCellStayTime_InSn(callInfo_type *ptCi, VccbLastVisitedPSCellHandling_type *ptScgUHI);
int16_t FnVCCB_FillLastVisitedPSCellInformation_CurrentPScell(
    callInfo_type *ptCi, VccbLastVisitedPSCellHandling_type *ptScgUHI, VccbLastVisitedPSCellInformation_type *ptOutVisited);
enumChangeState_type FnVCCB_IsPCellChange_ForPSCellInformationInSN(callInfo_type *ptCi);

// SN Porc

// ------------------------------------------------------

#endif
