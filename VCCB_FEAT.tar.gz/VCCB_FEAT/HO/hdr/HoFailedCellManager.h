#ifndef HO_FAILED_CELL_MANAGER_HPP
#define HO_FAILED_CELL_MANAGER_HPP

/**
* @enum enumFailedCellListType
* @brief Definition of failed cell list types
*/
enum enumFailedCellListType
{
    FAILED_CELL_LIST_TYPE_HO,
    FAILED_CELL_LIST_TYPE_CHO,
    FAILED_CELL_LIST_TYPE_LTM,
    FAILED_CELL_LIST_TYPE_MAX
};

/**
 * @class HoFailedCellManager
 * @brief Class for managing HO failed cell 
 */
class HoFailedCellManager
{
private:
    callInfo_type& m_rCall;
    enumFailedCellListType m_failedCellListType;
    cgi_type m_cgi;

    void setFailedCellInfo(failedCellInfo_type* ptFailedCell, const struct timeval& currentTime, 
                          const cgi_type& cgi);

    void storeFailedCellInfo(const struct timeval& currentTime);
    
    void updateFailTime(failedCellInfo_type* ptFailedCell, const struct timeval& currentTime);

    uint16_t getPreventTimerValue();
    
    struct CellSearchResult
    {
        bool cellAlreadyExists;
        int firstNoUseIndex;
        int oldestUseIndex;
        struct timeval oldestFailTime;
    };
    
    CellSearchResult findCellIndices(const failedCellInfo_type* ptFailedCell, int maxIndex, 
                                   const struct timeval& currentTime);

    bool checkFailedCellTimer(const failedCellInfo_type* failedCell);
    
    bool validateTimerAndTime(struct timeval& currentTime, uint16_t& preventTimerValue);
    
    bool checkElapsedTimeAndLog(const failedCellInfo_type* failedCell, const struct timeval& currentTime, 
                               uint16_t preventTimerValue, const cgi_type& cgi);

    failedCellInfo_type* getList();
    int getMaxCellNum();
    const char* getListName();
    
public:
    HoFailedCellManager(callInfo_type& rCall, enumFailedCellListType failedCellListType);
    HoFailedCellManager(callInfo_type& rCall, enumFailedCellListType failedCellListType, const cgi_type &rCgi);  
  
    void InitList();
    void updateFailedCell();
    bool isFailedCell();
};

void VLIB_InitHoFailedCellList(callInfo_type *ptCi);

void FnVCCB_InitCHOBlockList(callInfo_type *ptCi);
void FnVCCB_UpdateCHOBlockedCellInfo(callInfo_type *ptCi);
bool FnVCCB_IsCHOBlockedCell(callInfo_type *ptCi, nbrGnbCellInfo_type *pNbrGnbCell);

bool VCCM_IsHandoverPrepFailedCellByCgi(callInfo_type &rCall, cgi_type cgi, uint8_t ratType);
bool VCCM_IntraNrHandoverPrepFailedCell(callInfo_type &rCall, const nbrGnbCellInfo_type &rNbrGnbCellInfo);
bool VCCM_InterRatHandoverPrepFailedCell(callInfo_type &rCall, const nbrEnbCellInfo_type &rNbrEnbCellInfo);
void VHCM_UpdateHandoverPreparationFailureCellInfo(callInfo_type *ptCi);

void FnVCCB_InitLtmBlockList(callInfo_type &ptCi);
void FnVCCB_AddLtmBlockedCell(callInfo_type &rCall, const cgi_type& tgtCellCgi);
bool FnVCCB_IsLtmBlockedCell(callInfo_type &rCall, const cgi_type& tgtCellCgi);

#endif // HO_FAILED_CELL_MANAGER_HPP
