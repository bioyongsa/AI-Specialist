/**
 * @file        LtmBufferManager.h
 * @brief       LTM Buffer Manager class for managing candidate cell buffers
 */

#ifndef VCCB_FEAT_LtmBufferManager_H_
#define VCCB_FEAT_LtmBufferManager_H_

#include "VccbStruct.h"
#include "ComInclude.h"

#include <memory>
#include <vector>
#include <unordered_map>
#include <functional>
#include <cstring>

// Constant definitions
#define MAX_TCI_STATES_CONFIGURATIONS_LIST 300  // what is the max value?...
#define MAX_RACH                           100  // what is the max value?...
#define MAX_PREAMBLE_INDEX                 16   // what is the max value?...
#define MAX_LTM_CFRA_RESOURCE_CONFIG       100  // what is the max value?...

typedef struct {
    uint8_t cellIdx;
    msgContainer_type cellGroupConfig;
    msgContainer_type rrcReconfiguration;
    
    struct {
        uint16_t num_octets_tci;
        uint16_t num_octets_rach;
        uint8_t tCIStatesConfigurationsList[MAX_TCI_STATES_CONFIGURATIONS_LIST];
        uint8_t rACH[MAX_RACH];
        uint16_t num_du;
        struct {
            int duid;
            uint16_t num_index;
            uint16_t preambleIndex[MAX_PREAMBLE_INDEX];
        } du[MAX_NUM_LTM_DUS];
        char hexDecoded[90000];
    } earlySyncInfo;
    
    struct {
        uint16_t num_octets_cfra;
        uint8_t cfra[MAX_LTM_CFRA_RESOURCE_CONFIG];
        NRRRC_LTM_SSB_Config_r18 ltm_SSB_Config_r18;
        uint8_t ssbBitMap[8];
    } ltmResourceConfig;
    
} ltmCandidateCellInfo_type;

class LtmBufferManager {
private:
    // Constant definitions
    // MAX_POOL_SIZE_PER_THREAD: Maximum size of memory pool per thread
    // Each thread has its own pool with 1000 items to avoid mutex contention
    // Total: 10 threads * 1000 items = 10,000 items
    static constexpr size_t MAX_POOL_SIZE_PER_THREAD = 1000;
    
    struct CandidateCellInfo {
        std::shared_ptr<ltmCandidateCellInfo_type> data;  // Using shared_ptr
        bool isValid;
        
        CandidateCellInfo(std::shared_ptr<ltmCandidateCellInfo_type> cellData) 
            : data(cellData), isValid(true) {}
    };
    
    /**
     * @brief Buffer information per Call
     */
    struct CallBufferInfo {
        int16_t state;
        msgContainer_type sourceCellGroupConfig;  // For serving cell

        std::unordered_map<uint16_t, CandidateCellInfo> candCellsMap;
        LtmProcRelatedData_type procRelatedData;
        
        CallBufferInfo() 
            : state(0)
            , sourceCellGroupConfig{}
            , procRelatedData{} {}
    };
    
    // Call management per Thread (using VCCB_CALL_THREAD_NUM)
    std::unordered_map<uint32_t, CallBufferInfo> ltmBufferMap[VCCB_CALL_THREAD_NUM];

    /**
     * @brief Get CallBufferInfo for a given threadId and callId (does not create if not exists)
     * @param threadId Thread ID
     * @param callId Call ID
     * @return Pointer to CallBufferInfo if found, nullptr if not found or on failure
     * @note This function is thread-safe only when called from the same thread.
     *       No internal locking is performed for performance reasons.
     */
    CallBufferInfo* getCallBuffer(uint32_t threadId, uint32_t callId) {
        // Debug: Log callId 0 specifically
        if (callId == 0) {
            VCCB_PRINTF("[DEBUG] getCallBuffer: callId=0, threadId=%u\n", threadId);
            // Debug: Before accessing threadMap, check Thread 0 map state
            // Use count() and at() instead of find() to avoid iterator invalidation
            auto &threadMap0_before = ltmBufferMap[0];
            if (threadMap0_before.count(0) > 0) {
                VCCB_PRINTF("[DEBUG] getCallBuffer: Before access, Thread 0 has callId 0 with %zu cells (map size=%zu)\n", 
                            threadMap0_before.at(0).candCellsMap.size(), threadMap0_before.size());
            } else {
                VCCB_PRINTF("[DEBUG] getCallBuffer: Before access, Thread 0 does NOT have callId 0 (map size=%zu)\n", 
                            threadMap0_before.size());
            }
        }

        // Validate Thread ID range (before array access)
        // CRITICAL: Check against array size, not MAX_CALL_THREAD_NUM_VCCB
        if (threadId >= VCCB_CALL_THREAD_NUM) {
            if (callId == 0) {
                VCCB_PRINTF("[DEBUG] getCallBuffer: callId=0 FAILED: threadId %u >= VCCB_CALL_THREAD_NUM %u\n", 
                            threadId, VCCB_CALL_THREAD_NUM);
            }
            return nullptr;
        }

        // Safe map access: check existence first
        if (callId == 0) {
            VCCB_PRINTF("[DEBUG] getCallBuffer: About to access ltmBufferMap[%u], Thread 0 address=%p, size=%zu\n", 
                        threadId, static_cast<void*>(&ltmBufferMap[0]), ltmBufferMap[0].size());
        }
        auto &threadMap = ltmBufferMap[threadId];
        if (callId == 0) {
            VCCB_PRINTF("[DEBUG] getCallBuffer: Got reference to ltmBufferMap[%u], Thread 0 address=%p, size=%zu\n", 
                        threadId, static_cast<void*>(&ltmBufferMap[0]), ltmBufferMap[0].size());
        }
        
        // Debug: After getting reference, check Thread 0 map state (for callId 0)
        // Use count() and at() instead of find() to avoid iterator invalidation
        if (callId == 0) {
            auto &threadMap0_after_ref = ltmBufferMap[0];
            if (threadMap0_after_ref.count(0) > 0) {
                VCCB_PRINTF("[DEBUG] getCallBuffer: After getting ref, Thread 0 still has callId 0 with %zu cells (map size=%zu)\n", 
                            threadMap0_after_ref.at(0).candCellsMap.size(), threadMap0_after_ref.size());
            } else {
                VCCB_PRINTF("[DEBUG] getCallBuffer: After getting ref, Thread 0 callId 0 DISAPPEARED! (map size=%zu)\n", 
                            threadMap0_after_ref.size());
            }
        }
        
        // Use count() to check existence first, then use at() to get reference
        // This avoids iterator invalidation issues if rehashing occurs
        if (threadMap.count(callId) == 0) {
            if (callId == 0) {
                VCCB_PRINTF("[DEBUG] getCallBuffer: callId=0 NOT FOUND in Thread %u map (map size=%zu)\n", 
                            threadId, threadMap.size());
                if (threadId == 0) {
                    VCCB_PRINTF("[DEBUG] getCallBuffer: Thread 0 callIds: ");
                    for (const auto &pair : threadMap) {
                        VCCB_PRINTF("%u ", pair.first);
                    }
                    VCCB_PRINTF("\n");
                }
            }
            return nullptr;  // Not found
        }

        // Use at() to get reference - this is safe even if rehashing occurs
        // The reference remains valid as long as the element exists in the map
        CallBufferInfo& bufferInfo = threadMap.at(callId);
        
        if (callId == 0) {
            VCCB_PRINTF("[DEBUG] getCallBuffer: callId=0 FOUND in Thread %u map with %zu cells\n", 
                        threadId, bufferInfo.candCellsMap.size());
        }

        return &bufferInfo;
    }

    /**
     * @brief Get or create CallBufferInfo for a given threadId and callId
     * @param threadId Thread ID
     * @param callId Call ID
     * @return Pointer to CallBufferInfo if successful, nullptr on failure
     * @note This function is thread-safe only when called from the same thread.
     *       No internal locking is performed for performance reasons.
     */
    CallBufferInfo* getOrCreateCallBuffer(uint32_t threadId, uint32_t callId) {
        // Debug: Log callId 0 specifically
        if (callId == 0) {
            VCCB_PRINTF("[DEBUG] getOrCreateCallBuffer: callId=0, threadId=%u\n", threadId);
        }

        // Validate Thread ID range (before array access)
        // CRITICAL: Check against array size, not MAX_CALL_THREAD_NUM_VCCB
        if (threadId >= VCCB_CALL_THREAD_NUM) {
            if (callId == 0) {
                VCCB_PRINTF("[DEBUG] getOrCreateCallBuffer: callId=0 FAILED: threadId %u >= VCCB_CALL_THREAD_NUM %u\n", 
                            threadId, VCCB_CALL_THREAD_NUM);
            }
            return nullptr;
        }

        // Safe map access: check existence first
        auto &threadMap = ltmBufferMap[threadId];
        
        // Debug: Before emplace, check if callId 0 exists (when adding other callIds to Thread 0)
        // Use count() and at() instead of find() to avoid iterator invalidation
        if (threadId == 0 && callId != 0) {
            if (threadMap.count(0) > 0) {
                VCCB_PRINTF("[DEBUG] getOrCreateCallBuffer: Before adding callId %u, callId 0 exists with %zu cells\n", 
                            callId, threadMap.at(0).candCellsMap.size());
            } else {
                VCCB_PRINTF("[DEBUG] getOrCreateCallBuffer: Before adding callId %u, callId 0 does NOT exist\n", callId);
            }
        }
        
        // Check if key exists first to avoid iterator invalidation
        if (threadMap.count(callId) == 0)
        {
            if (callId == 0) {
                VCCB_PRINTF("[DEBUG] getOrCreateCallBuffer: callId=0 not found, creating new buffer\n");
            }
            // Exception handling with explicit creation
            try
            {
                // Debug: Before emplace, check Thread 0 map state (when adding other callIds)
                if (threadId != 0 && callId != 0) {
                    auto &threadMap0_check = ltmBufferMap[0];
                    if (threadMap0_check.count(0) > 0) {
                        VCCB_PRINTF("[DEBUG] getOrCreateCallBuffer: Before emplace callId %u (threadId=%u), Thread 0 has callId 0 with %zu cells\n", 
                                    callId, threadId, threadMap0_check.at(0).candCellsMap.size());
                    }
                }
                
                // Use try_emplace instead of emplace to avoid unnecessary move/copy
                // try_emplace constructs the value in-place only if the key doesn't exist
                auto result = threadMap.try_emplace(callId);
                if (!result.second)
                {
                    if (callId == 0) {
                        VCCB_PRINTF("[DEBUG] getOrCreateCallBuffer: callId=0 FAILED: try_emplace returned false\n");
                    }
                    return nullptr;  // Insertion failed (key already exists)
                }
                // CallBufferInfo is default-constructed by try_emplace, no need to move
                if (callId == 0) {
                    VCCB_PRINTF("[DEBUG] getOrCreateCallBuffer: callId=0 SUCCESS: buffer created\n");
                }
                
                // Debug: After emplace, check if callId 0 still exists (when adding other callIds)
                if (threadId != 0 && callId != 0) {
                    auto &threadMap0_check = ltmBufferMap[0];
                    if (threadMap0_check.count(0) > 0) {
                        VCCB_PRINTF("[DEBUG] getOrCreateCallBuffer: After emplace callId %u (threadId=%u), Thread 0 still has callId 0 with %zu cells\n", 
                                    callId, threadId, threadMap0_check.at(0).candCellsMap.size());
                    } else {
                        VCCB_PRINTF("[DEBUG] getOrCreateCallBuffer: After emplace callId %u (threadId=%u), Thread 0 callId 0 DISAPPEARED! (map size=%zu)\n", 
                                    callId, threadId, threadMap0_check.size());
                    }
                }
                
                // Debug: After emplace, check if callId 0 still exists (when adding other callIds to Thread 0)
                if (threadId == 0 && callId != 0) {
                    if (threadMap.count(0) > 0) {
                        VCCB_PRINTF("[DEBUG] getOrCreateCallBuffer: After adding callId %u, callId 0 still exists with %zu cells\n", 
                                    callId, threadMap.at(0).candCellsMap.size());
                    } else {
                        VCCB_PRINTF("[DEBUG] getOrCreateCallBuffer: After adding callId %u, callId 0 DISAPPEARED!\n", callId);
                    }
                }
            }
            catch (const std::bad_alloc &)
            {
                if (callId == 0) {
                    VCCB_PRINTF("[DEBUG] getOrCreateCallBuffer: callId=0 FAILED: bad_alloc exception\n");
                }
                return nullptr;  // Memory allocation failed
            }
            catch (const std::exception &)
            {
                if (callId == 0) {
                    VCCB_PRINTF("[DEBUG] getOrCreateCallBuffer: callId=0 FAILED: exception\n");
                }
                return nullptr;  // Other exceptions
            }
        }
        else
        {
            if (callId == 0) {
                VCCB_PRINTF("[DEBUG] getOrCreateCallBuffer: callId=0 found existing buffer\n");
            }
        }

        // Use at() instead of iterator to avoid invalidation issues
        return &(threadMap.at(callId));
    }

    /**
     * @brief Memory Pool using Custom Deleter (thread-specific, no mutex)
     */
    class CandidateCellPool {
        private:
        std::vector<std::unique_ptr<ltmCandidateCellInfo_type>> availableBuffers;
        
        /**
         * @brief Thread-specific deleter function - automatically returns memory to thread's pool
         * @param ptr Pointer to return
         * @param threadId Thread ID that owns this buffer
         */
        static void returnToPool(ltmCandidateCellInfo_type* ptr, uint32_t threadId) {
            if (!ptr) {
                return;  // nullptr check
            }
            
            // Validate thread ID
            if (threadId >= VCCB_CALL_THREAD_NUM) {
                // Invalid thread ID, just delete
                delete ptr;
                return;
            }
            
            // Check if singleton is being destroyed
            // If so, just delete the pointer instead of returning to pool
            // Note: Don't call VCCB_PRINT_ERROR here as logging infrastructure
            //       may already be destroyed during program shutdown
            if (LtmBufferManager::isDestroying()) {
                delete ptr;
                return;
            }
            
            try {
                // Get singleton instance
                LtmBufferManager& manager = LtmBufferManager::getInstance();
                CandidateCellPool& pool = manager.cellPool[threadId];
                
                // No mutex needed - each thread has its own pool
                if (pool.availableBuffers.size() < MAX_POOL_SIZE_PER_THREAD) {
                    // Return to pool: convert raw pointer to unique_ptr
                    pool.availableBuffers.push_back(std::unique_ptr<ltmCandidateCellInfo_type>(ptr));
                } else {
                    // Directly deallocate if pool is full
                    delete ptr;
                }
            } catch (const std::exception&) {
                // Safely deallocate on exception (e.g., singleton already destroyed)
                delete ptr;
            } catch (...) {
                // Safely deallocate on unknown exception
                delete ptr;
            }
        }
        
    public:
        /**
         * @brief Create custom deleter for a specific thread
         * @param threadId Thread ID that will own this buffer
         * @return Deleter function
         */
        static auto getDeleter(uint32_t threadId) {
            return [threadId](ltmCandidateCellInfo_type* ptr) {
                returnToPool(ptr, threadId);
            };
        }
        
        /**
         * @brief Allocate buffer with shared_ptr (thread-specific, no mutex)
         * @param threadId Thread ID that will own this buffer
         */
        static std::shared_ptr<ltmCandidateCellInfo_type> acquireBuffer(uint32_t threadId) {
            // Validate thread ID
            if (threadId >= VCCB_CALL_THREAD_NUM) {
                return nullptr;
            }
            
            // Get singleton instance first (must exist before checking destruction)
            // If singleton is being destroyed, getInstance() may throw or return invalid reference
            try {
                LtmBufferManager& manager = LtmBufferManager::getInstance();
                
                // Check if singleton is being destroyed after getting instance
                // This ensures singleton exists before checking destruction state
                if (LtmBufferManager::isDestroying()) {
                    VCCB_PRINTF("LtmBufferManager is being destroyed, cannot allocate buffer\n");
                    return nullptr;
                }
                
                CandidateCellPool& pool = manager.cellPool[threadId];
                
                // No mutex needed - each thread has its own pool
                ltmCandidateCellInfo_type* rawPtr = nullptr;
                
                if (!pool.availableBuffers.empty()) {
                    // Take ownership from unique_ptr
                    rawPtr = pool.availableBuffers.back().release();
                    pool.availableBuffers.pop_back();
                    // Pointer must be valid after release()
                    if (rawPtr) {
                        memset(rawPtr, 0, sizeof(ltmCandidateCellInfo_type));
                    }
                } else {
                    // Allocate new
                    rawPtr = new (std::nothrow) ltmCandidateCellInfo_type();
                    if (rawPtr) {
                        memset(rawPtr, 0, sizeof(ltmCandidateCellInfo_type));
                    }
                }
                
                if (!rawPtr) {
                    return nullptr;  // Memory allocation failed
                }
                
                // Create shared_ptr with thread-specific custom deleter
                auto deleter = getDeleter(threadId);
                return std::shared_ptr<ltmCandidateCellInfo_type>(rawPtr, deleter);
            } catch (const std::exception&) {
                // Singleton is being destroyed or already destroyed
                return nullptr;
            } catch (...) {
                // Unknown exception - singleton may be destroyed
                return nullptr;
            }
        }
        
        // Check pool size (no mutex needed)
        size_t getPoolSize() const {
            return availableBuffers.size();
        }
        
        // Clear pool (release all buffers)
        void clear() {
            availableBuffers.clear();
        }
    };

    // Thread-specific pools (one per thread, no mutex needed)
    CandidateCellPool cellPool[VCCB_CALL_THREAD_NUM];
    
    // Track singleton instance address and destruction flag
    static LtmBufferManager*& getSingletonInstance() {
        static LtmBufferManager* singletonInstance = nullptr;
        return singletonInstance;
    }
    
    static bool& getDestroyingFlag() {
        static bool destroying = false;
        return destroying;
    }
    
    // Check if singleton is being destroyed
    // Only returns true if the actual singleton instance is being destroyed
    static bool isDestroying() {
        return getDestroyingFlag();
    }
    
public:
    static LtmBufferManager& getInstance() {
        static LtmBufferManager instance;
        // Store singleton instance address on first access
        LtmBufferManager*& singletonInstance = getSingletonInstance();
        if (singletonInstance == nullptr) {
            singletonInstance = &instance;
            // Reset destroying flag when singleton is (re)created
            getDestroyingFlag() = false;
        }
        return instance;
    }
    
    ~LtmBufferManager() {
        // Only mark as destroying if this is the actual singleton instance
        LtmBufferManager*& singletonInstance = getSingletonInstance();
        if (singletonInstance == this) {
            // This is the singleton being destroyed
            getDestroyingFlag() = true;
            
            // Clear all pools before destruction
            for (size_t i = 0; i < VCCB_CALL_THREAD_NUM; ++i) {
                cellPool[i].clear();
            }
            // Clear singleton instance pointer
            singletonInstance = nullptr;
        }
        // If this is not the singleton (temporary object), do nothing
    }
    
    // Safe allocation when adding Candidate Cell
    // Note: This function is thread-safe only when called from the same thread.
    // No internal locking is performed for performance reasons.
    int16_t addCandidateCell(callInfo_type &rCall, int16_t cellIndex = -1);
    
    /**
     * @brief Remove Candidate Cell (explicit memory cleanup)
     * @note This function is thread-safe only when called from the same thread.
     *       No internal locking is performed for performance reasons.
     */
    void removeCandidateCell(callInfo_type &rCall, uint16_t cellIndex);
    
    /**
     * @brief Get Candidate Cell information
     * @note This function is thread-safe only when called from the same thread.
     *       No internal locking is performed for performance reasons.
     */
    std::shared_ptr<ltmCandidateCellInfo_type> getCandidateCell(callInfo_type &rCall, uint16_t cellIndex);

    /**
     * @brief Cleanup Call (explicit memory cleanup)
     * @note This function is thread-safe only when called from the same thread.
     *       No internal locking is performed for performance reasons.
     */
    void cleanupCall(callInfo_type &rCall);
    
    /**
     * @brief Cleanup entire Thread (explicit memory cleanup)
     */
    void cleanupThread(uint32_t threadId);
    
    /**
     * @brief Cleanup all (explicit memory cleanup)
     */
    void cleanupAll();

    void printCallBufferInfo(const callInfo_type &rCall, const CallBufferInfo &rBuffer);
    
    /**
     * @brief Print Call information (extract threadId and callId from callInfo_type)
     * @param rCall Reference to Call information
     */
    void printCallInfo(const callInfo_type &rCall);
    
    /**
     * @brief Print all Call information for all Threads
     */
    void printAllThreadInfoForDsh();
    
    /**
     * @brief Print memory pool status
     */
    void printPoolStatusForDsh();
    
    /**
     * @brief Memory usage statistics
     */
    struct MemoryStats {
        size_t totalCalls;
        size_t totalCandidateCells;
        size_t poolSize;
        double estimatedMemoryMB;
        size_t averageMapSize;
        size_t maxMapSize;
    };
    
    MemoryStats getMemoryStats();

    /**
     * @brief Example: Iterate through all candidate cells for a specific call
     * @param rCall Call information
     * @param callback Function to process each candidate cell (cellIndex, cellData)
     * @return Number of candidate cells processed
     * @note This function is thread-safe only when called from the same thread.
     *       No internal locking is performed for performance reasons.
     */
    size_t iterateCallCandidateCells(callInfo_type &rCall, 
                                      std::function<void(uint16_t cellIndex, 
                                                         std::shared_ptr<ltmCandidateCellInfo_type>& cellData)> callback);

    void initLtmPrepProcTempDb(callInfo_type &rCall);
    int16_t storeCellGroupConfig(callInfo_type &rCall, uint16_t ltmCellIdx, msgContainer_type &rCellGroup);
    int16_t getStoredCellGroupConfig(callInfo_type &rCall, uint16_t ltmCellIdx, msgContainer_type &rCellGroup);
    void showStoredCellGroupConfig(callInfo_type &rCall);
    int16_t storeLtmReconfig(callInfo_type &rCall, uint16_t ltmCellIdx, msgContainer_type &rReconfig);

    int16_t getStoredLtmReconfig(callInfo_type &rCall, uint16_t ltmCellIdx, NRRRC__octet1_10 &rNrrrcOctct);

    int16_t init_ltmMaintainDb(callInfo_type &rCall, uint16_t ltmCellIdx);
    uint16_t get_num_du(callInfo_type &rCall, uint16_t ltmCellIdx);
    int16_t store_F1_EarlySyncInformation(
        callInfo_type &rCall, uint16_t ltmCellIdx, F1_EarlySyncInformation *ptEarlySyncInfo);
    int16_t store_F1_LTMConfiguration(
        callInfo_type &rCall, uint16_t ltmCellIdx, F1_LTMConfiguration *ptLtmConfiguration);
    int16_t getStored_F1_LTMCFRAResourceConfig(
        callInfo_type &rCall, uint16_t ltmCellIdx, F1_LTMCFRAResourceConfig &rConfig);
    int16_t getStored_F1_TCIStatesConfigurationsList(
        callInfo_type &rCall, uint16_t ltmCellIdx, F1_TCIStatesConfigurationsList &rConfig);
    // get EarlyUL-SyncConfig IE (TS 38.331) from DU
    int16_t getStored_F1_EarlyULSyncConfig__RachConfiguration(
        callInfo_type &rCall, uint16_t ltmCellIdx, unsigned int &rLen, unsigned char *&rpValue);
    int16_t getStored_F1_EarlyULSyncConfig__LtmGnbDusList(callInfo_type &rCall, uint16_t ltmCellIdx,
        struct F1_LTMgNB_DU_IDs_PreambleIndexList_ (&rDuList)[MAX_NUM_LTM_DUS],
        struct F1_PreambleIndexList_ (&rPreambleIndexListPerDu)[MAX_NUM_LTM_DUS][MAX_NUM_LTM_CELLS]);
    int16_t getStored_NRRRC_LTM_SSB_Config_r18(
        callInfo_type &rCall, uint16_t ltmCellIdx, NRRRC_LTM_SSB_Config_r18 &rConfig);
    int16_t getStored_NRRRC_LTM_TCI_Info_r18(
        callInfo_type &rCall, uint16_t ltmCellIdx, NRRRC_LTM_TCI_Info_r18 &rConfig);
    LtmProcRelatedData_type *getLtmProcRelatedDataForCall(const callInfo_type &rCall);
};

#endif  // VCCB_FEAT_LtmBufferManager_H_



