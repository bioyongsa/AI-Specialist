/**
 * @file        FeatLtmHo.h
 * @brief       Utility functions for Ltm Handover
 */
#ifndef VCCB_FEAT_FeatLtmHo_H_
#define VCCB_FEAT_FeatLtmHo_H_
#include "VccbStruct.h"
#include <map>
////////////////////////////////////////
//
// LTM temp DB handler wrapper
//
////////////////////////////////////////
int16_t FnVCCB_StoreLtmCellGroupConfigAndResetCall(callInfo_type &rCall, uint16_t ltmCellIdx, msgContainer_type &rCellGroup);
int16_t FnVCCB_StoreLtmSourceCellGroupConfig(callInfo_type &rCall, msgContainer_type &rCellGroup);
int16_t FnVCCB_GetStoredCellGroupConfig(callInfo_type &rCall, uint16_t ltmCellIdx, msgContainer_type &rCellGroup);
int16_t FnVCCB_GetStoredSourceCellGroupConfig(callInfo_type &rCall, msgContainer_type &rCellGroup);
void FnVCCB_ShowStoredLtmCellGroupConfig(callInfo_type &rCall);
int16_t FnVCCB_StoreLtmReconfig(callInfo_type &rCall, uint16_t ltmCellIdx, msgContainer_type &rReconfig);
int16_t FnVCCB_GetStoredLtmReconfig(callInfo_type &rCall, uint16_t ltmCellIdx, NRRRC__octet1_10 &rNrrrcOctct);
uint16_t FnVCCB_GetLtmNumDu(callInfo_type &rCall, uint16_t ltmCellIdx);
int16_t FnVCCB_StoreF1_EarlySyncInformation(
    callInfo_type &rCall, uint16_t ltmCellIdx, F1_EarlySyncInformation *ptEarlySyncInfo);
int16_t FnVCCB_StoreF1_LTMConfiguration(
    callInfo_type &rCall, uint16_t ltmCellIdx, F1_LTMConfiguration *ptLtmConfiguration);
int16_t FnVCCB_GetStored_F1_LTMCFRAResourceConfig(
    callInfo_type &rCall, uint16_t ltmCellIdx, F1_LTMCFRAResourceConfig &rConfig);
int16_t FnVCCB_GetStored_F1_TCIStatesConfigurationsList(
    callInfo_type &rCall, uint16_t ltmCellIdx, F1_TCIStatesConfigurationsList &rConfig);
int16_t FnVCCB_GetStored_F1_EarlyULSyncConfig__RachConfiguration(
    callInfo_type &rCall, uint16_t ltmCellIdx, F1_RACHConfiguration &rConfig);
int16_t FnVCCB_GetStored_F1_EarlyULSyncConfig__LtmGnbDusList(callInfo_type &rCall, uint16_t ltmCellIdx,
    struct F1_LTMgNB_DU_IDs_PreambleIndexList_ (&rDuList)[MAX_NUM_LTM_DUS],
    struct F1_PreambleIndexList_ (&rPreambleIndexListPerDu)[MAX_NUM_LTM_DUS][MAX_NUM_LTM_CELLS]);
int16_t FnVCCB_GetStored_NRRRC_EarlyUL_SyncConfig_r18(
    callInfo_type &rCall, uint16_t ltmCellIdx, NRRRC__octet1_10 &rConfig);
int16_t FnVCCB_GetStored_NRRRC_LTM_SSB_Config_r18(
    callInfo_type &rCall, uint16_t ltmCellIdx, NRRRC_LTM_SSB_Config_r18 &rConfig);
int16_t FnVCCB_GetStored_NRRRC_LTM_TCI_Info_r18(
    callInfo_type &rCall, uint16_t ltmCellIdx, NRRRC_LTM_TCI_Info_r18 &rConfig);
LtmProcRelatedData_type *FnVCCB_GetLtmProcRelatedDataForCall(const callInfo_type &rCall);
int16_t FnVCCB_LtmStoreF1_UeContextModificationResponse(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack);
int16_t FnVCCB_LtmStoreF1_UeContextSetupResponse(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack);
void FnVCCB_InitLtmBufferMapOfCall(callInfo_type &rCall);
void FnVCCB_InitLtmBufferMapAll();
void FnVCCB_LtmSwitchover(callInfo_type &rCall);
void FnVCCB_PrintLtmBufferAllThreadInfo(void);
void FnVCCB_PrintLtmBufferPoolStatus(void);

////////////////////////////////////////
//
// LTM Intra gNB DB handler
//
////////////////////////////////////////
void FnVCCB_InitLtmCellInfo(ltmCellInfo_type *ptLtmCell, uint8_t ltmCellIdx, enumTimerType option = CANCEL_TIMER);
ltmCellInfo_type *FnVCCB_GetLtmCellInfoForIndex(callInfo_type *ptCi, uint8_t ltmCellIdx);
const ltmCellInfo_type *FnVCCB_GetLtmCellInfoForIndex(const callInfo_type *ptCi, uint8_t ltmCellIdx);
ltmCellInfo_type *FnVCCB_GetLtmCellInfoFromCGI(callInfo_type *ptCi, cgi_type findCgi);
ltmCellInfo_type *FnVCCB_GetLtmCellInfoFromCellNum(callInfo_type *ptCi, CellNum_type cellNum);
ltmCellInfo_type *FnVCCB_GetLtmCellInfoFromLtmAction(callInfo_type *ptCi, ltmCellAction_type ltmAction);
ltmCellInfo_type *FnVCCB_GetLtmCellInfoFromFlag(callInfo_type *ptCi, uint8_t flag);
void FnVCCB_SetLtmCellStatus(callInfo_type *ptCi, uint8_t ltmCellIdx, enumCommonStatus_type newStatus);
void FnVCCB_SetLtmCellAction(callInfo_type *ptCi, uint8_t ltmCellIdx, ltmCellAction_type newAction);
void FnVCCB_ClearLtmUeInfo(callInfo_type *ptCi, enumTimerType option = CANCEL_TIMER);
void FnVCCB_InitLtmUeInfoForCellSwitch(callInfo_type *ptCi);
void FnVCCB_InitLtmUeInfo(callInfo_type *ptCi);
uint8_t FnVCCB_AllocLtmCellInfoForCGI(callInfo_type *ptCi, cgi_type cgi);
void FnVCCB_LtmPrepConfigCommit(callInfo_type *ptCi);
int16_t FnVCCB_procLtm_NRRRC_RrcReconfigurationComplete(callInfo_type &rCall, const ltmCellInfo_type &rLtmCellInfo);
void FnVCCB_AppendLtmConfig_r18_ForReconfigurationComplete(callInfo_type *ptCi);
int16_t FnVCCB_StartLtmHandoverExecutionProcedure(callInfo_type *ptCi);

bool FnVCCB_IsValidLtmDuUeId(callInfo_type &rCall, uint16_t endPointIdx, uint16_t duUeId);
ltmCellInfo_type *FnVCCB_GetLtmCellWithEndPointIdxAndDuUeId(callInfo_type &rCall, uint16_t endPointIdx, uint16_t duUeId);
ltmCellInfo_type *FnVCCB_GetLtmCellInfoFromLtmStatusAndF1Id(
    callInfo_type &rCall, ltmCellAction_type ltmAction, uint32_t f1apId);
void FnVCCB_ClearLtmCellResponseFlag(callInfo_type &rCall, uint16_t endPointIdx, uint32_t duId);
ltmCellInfo_type *FnVCCB_GetLtmCellInfoFromDuInfo(callInfo_type &rCall, uint16_t endPointIdx, uint32_t duId);
void FnVCCB_FreeLtmCellInfoForCGI(callInfo_type &rCall, cgi_type cgi);
void FnVCCB_UpdateRsIndexListForLTM(callInfo_type &rCall, uint16_t targetCellNum);
void FnVCCB_UpdateCandidateCellInfoForLtmHoExec(callInfo_type &rCall);
int16_t FnVCCB_FinalizeLtmHo(callInfo_type &rCall, enumHandoverTriggerType cause);
int16_t FnVCCB_LtmExecUpHandler(callInfo_type *ptCi, uint16_t msgId);
int16_t FnVCCB_LtmRelease(callInfo_type &rCall);
void FnVCCB_LtmCandidateCellRelease(callInfo_type &rCall, uint16_t candidateCellIdx);
int16_t FnVCCB_LtmCandidateReleaseTimerAction(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack);
bool FnVCCB_NeedToTriggerLtmRelease(callInfo_type *ptCi);
void FnVCCB_LtmReleaseAllCandidateImmediately(callInfo_type *ptCi);
int16_t FnVCCB_triggerLtmCellRelease(callInfo_type *ptCi);
int16_t VCCM_HandleDequeuedLtmCandidateCellRelease(callInfo_type *ptCi, enqueuedAction);
void FnVCCB_FreeLtmCellInfoForIndex(callInfo_type *ptCi, uint8_t ltmCellIdx);
bool FnVCCB_IsLtmReleaseCase(const callInfo_type &rCall);
int16_t FnVCCB_SendF1UeContextRelease_LtmCandidateCell(callInfo_type *ptCi, ltmCellInfo_type *ptTarget);
int16_t FnVCCB_Send_Ltm_ReconfigCompleteIndicator(callInfo_type *ptCi);

uint8_t FnVCCB_GetMaxNumOfLtmCellFromYang(callInfo_type &rCall);
bool FnVCCB_IsLtmCandidateCellFull(callInfo_type &rCall);
bool FnVCCB_IsBeamMeasConfigNeed(callInfo_type &rCall, CellNum_type cellNum);
int16_t FnVCCB_AttachLtmCandidateCellRelTimer(callInfo_type &rCall, ltmCellInfo_type *ptTarget, uint16_t cellNum);
bool FnVCCB_IsHoTargetCellLtmCandidate(callInfo_type &rCall, saMobilityMrInfo_type &hoMrInfo);
int16_t FnVCCB_TriggerLtmCellSwitch(callInfo_type &rCall, saMobilityMrInfo_type &hoMrInfo, measResultList2NR_type *ptMeasResultList2NR);
int16_t FnVCCB_UpdateMeasResultForLtmTargetCell(callInfo_type *ptCi, uint16_t nbrIdx, measurementObjectUe_type *pMeasObj, measResultList2NR_type *ptMeasNew);
void FnVCCB_HandleLtmReleaseBySvcGrpChanged(callInfo_type &rCall);
void FnVCCB_UpdateLtmSvcGrp(callInfo_type &rCall);
void FnVCCB_UpdateCandidateCellCrntiForPCell(callInfo_type &rCall, const struct F1_ProtocolIE_Container_ *pContainer);
bool FnVCCB_ExecuteLTMReleaseBySwitchOver(callInfo_type &rCall);

class HandleCurrentCandidateCellIndex
{
public:
    HandleCurrentCandidateCellIndex(callInfo_type &rCi, uint8_t targetCellIndex) :
        _rCall(rCi),
        _targetCandidateCellIndex(targetCellIndex)
    {
        _rCall.ltmUeInfo.currCandidateCellIdx = (_targetCandidateCellIndex >= MAX_NUM_LTM_CELLS)? MAX_NUM_LTM_CELLS : _targetCandidateCellIndex;
    }

    ~HandleCurrentCandidateCellIndex() { _rCall.ltmUeInfo.currCandidateCellIdx = MAX_NUM_LTM_CELLS; }

    void setCurrCandidateCellIdx(uint8_t candidateCellIdx)
    {
        _rCall.ltmUeInfo.currCandidateCellIdx = (candidateCellIdx >= MAX_NUM_LTM_CELLS)? MAX_NUM_LTM_CELLS : candidateCellIdx;
    }
private:
    callInfo_type& _rCall;
    uint8_t _targetCandidateCellIndex;
};

class LtmF1apStoreDbHandler
{
public:
    LtmF1apStoreDbHandler(callInfo_type &call, uint16_t id) :
        rCall(call),
        isSetupResponse((id == F1_UEContextSetupResponse_id)),
        pLtmCell(nullptr)
    {
        pLtmCell = FnVCCB_GetLtmCellInfoForIndex(&rCall, rCall.ltmUeInfo.currCandidateCellIdx);
    }
    void preF1apMsgStore();
    void postF1apMsgStore();
    ~LtmF1apStoreDbHandler() {};

private:
    callInfo_type &rCall;
    transportLayerInfo_type f1uDlInfo[MAX_DRB_PER_SA_CALL];

    bool isSetupResponse;
    void updateCrnti();
    void rollbackCallDBAndUpdateLtmDrbDB();
    void updateLtmCandidateCellF1uDlInfo(uint16_t drbIdx);

    ltmCellInfo_type *pLtmCell;
};

#endif  // VCCB_FEAT_FeatLtmHo_H_
