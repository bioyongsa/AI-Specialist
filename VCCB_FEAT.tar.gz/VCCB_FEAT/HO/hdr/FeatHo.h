/**
 * @file        FeatHo.h
 * @brief       Utility functions for Handover
 */

#ifndef VCCB_FEAT_FeatHo_H_
#define VCCB_FEAT_FeatHo_H_

#include "VccbStruct.h"
#include "StateMeasurements.h"

class HoDbConroller
{
private:
    // Indicates whether the handover has been triggered.
    bool isHandoverTriggerCompleted = false;

    // Stores the information of the callInfo_type structure required for control.
    callInfo_type *ptCi = NULL;

    // Since ptCi must always be included as an argument, the default constructor is not used.
    HoDbConroller() = default;

public:
    /**
     * @brief Constructor of HoDbConroller class.
     * 
     * @param _ptCi Pointer to callInfo_type structure.
     */
    HoDbConroller(callInfo_type *_ptCi);

    /**
     * @brief Destructor of HoDbConroller class.
     */
    ~HoDbConroller();

    /**
     * @brief Sets the handover trigger completion flag.
     * 
     * @param sw Flag value (default: true)
     */
    void setHandoverTriggerCompleted(bool sw = true);
};

/****************************************************************************
 1. MN Mobility (Handover Trigger Function)
    1.1 MN-Intra-GNB Intra-RAT Handover : VHCM_StartSaHandover_IntragNB
        1.1.1 Intra-DU Handover         : FnVCCB_ProcSaHandover_IntraDU
        1.1.2 Inter-DU Handover         : FnVCCB_ProcSaHandover_InterDU
    1.2 MN-Inter-GNB Intra-RAT Handover : VHCM_StartSaHandover_IntergNB
    1.3 MN-Inter-GNB Inter-RAT Handover : VHCM_StartSaHandover_InterRAT
****************************************************************************/
int16_t VHCM_StartSaHandover_IntragNB(
    callInfo_type *ptCi, const cellSelection_type targetCellSelection, uint16_t cause, StartSaHandoverDb& hoInputDb);
int16_t VHCM_StartSaHandover_IntergNB(
    callInfo_type *ptCi, uint16_t nbrIdx, uint16_t cause, enumHandoverTriggerType hoTrigger, StartSaHandoverDb& hoInputDb);
int16_t VHCM_StartSaHandover_IntergNB_with_DB(
    callInfo_type *ptCi, nbrGnbCellInfo_type *ptNbrGnbCellInfo, uint16_t cause, enumHandoverTriggerType hoTrigger, HoDbConroller &hoDbConroller, StartSaHandoverDb& hoInputDb);
int16_t FnVCCB_ProcSaHandover_IntergNB_Common(
    callInfo_type *ptCi, nbrGnbCellInfo_type *ptNbrGnbCellInfo, uint16_t cause, enumHandoverTriggerType hoTrigger, enumNgHoSelectionCause& ngHoSelectionCause, StartSaHandoverDb& hoInputDb);
int16_t FnVCCB_ProcSaHandover_IntergNB_Prepare(callInfo_type *ptCi, enumNgHoSelectionCause& ngHoSelectionCause, StartSaHandoverDb& hoInputDb);
int16_t FnVCCB_ProcSaHandover_IntergNB_Execution(callInfo_type *ptCi, enumHandoverTriggerType hoTrigger);
int16_t VHCM_StartSaHandover_InterRAT(callInfo_type *ptCi, uint16_t nbrIdx, uint16_t cause, StartSaHandoverDb& hoInputDb);
int16_t VHCM_StartSaHandover_InterRAT_with_DB(callInfo_type *ptCi, nbrEnbCellInfo_type *nbrEnbCellInfo, uint16_t cause, HoDbConroller &hoDbConroller, StartSaHandoverDb& hoInputDb);

int16_t FnVCCB_ProcSaHandover_IntraDU(callInfo_type *ptCi);
int16_t FnVCCB_ProcSaHandover_InterDU(callInfo_type *ptCi);
/****************************************************************************
 2. SN Mobility (Handover Trigger Function)
    2.1 SN-Intra-GNB Handover
        2.1.1 MN : FnVCCB_StartSaHandover_IntraSN (Modification Required)
        2.1.2 SN : FnVCCB_StartSaHandoverSN_IntragNB
              2.1.2.1 Intra-DU Handover : FnVCCB_ProcSaHandoverSN_IntraDU
              2.1.2.2 Inter-DU Handover : FnVCCB_ProcSaHandoverSN_InterDU
    2.2 SN-Inter-GNB Handover :
        2.2.1 MN : FnVCCB_StartSaHandover_InterSN (Changed Required)
        2.2.2 SN : FnVCCB_StartSaHandoverSN_IntergNB
****************************************************************************/
int16_t FnVCCB_StartSaHandover_IntraSN(callInfo_type *ptCi);
int16_t FnVCCB_StartSaHandoverSN_IntragNB(
    callInfo_type *ptCi, const cellSelection_type targetCellSelection, enumHoTypeInitiated initiated, uint16_t cause);
int16_t FnVCCB_StartSaHandover_InterSN(callInfo_type *ptCi, uint16_t cause);
int16_t FnVCCB_StartSaHandoverSN_IntergNB(callInfo_type *ptCi, uint16_t tgtNbrGnbCell, uint16_t cause);

int16_t FnVCCB_ProcSaHandoverSN_IntraDU(callInfo_type *ptCi);
int16_t FnVCCB_ProcSaHandoverSN_InterDU(callInfo_type *ptCi);
/***************************************************************************/

void FnVCCB_ControlResponseFlagInSaHo(callInfo_type *ptCi, const char *ptFuncName);

int16_t VCOM_ProcHandoverPreparationInformationForInterNode(callInfo_type *ptCi);
bool FnVCCB_IsInterSnMobilityInMn(callInfo_type *ptCi);
bool FnVCCB_IsIntraSnMobilityInMn(callInfo_type *ptCi);

/* Inter-Plmn Hand-Out */
int16_t VCOM_GetSelectedPLMN_FromAllowedPLMN(callInfo_type *ptCi, candidateNbrInformation_type *ptCandidateNbrInfo,
    handover_Type handoverType, selectedTAI_Type *ptSelectedTai);
/* Inter-Plmn Hand-In */
int16_t VCOM_GetSelectedPLMN_For_SaHandIn(
    callInfo_type *ptCi, uint32_t cellNum, plmnId_type *ptPlmn, causeInfo_type *ptCause);
int16_t VCOM_GetServedPLMNbasedSelectedPLMN(callInfo_type *ptCi, const plmnId_type *ptSourcePlmn,
    const allowedPlmnList_Type *pt_b_plmn_list, plmnId_type *ptPlmn);

bool FnVCCB_checkSelectedTargetSNInMN(callInfo_type *ptCi, uint16_t xnIdx);
void VHCM_CheckStatForIntraNrHO(callInfo_type *ptCi);
void VHCM_CheckStatForChoNrHO(callInfo_type *ptCi);
void FnVCCB_CheckStat_NrdcSnAddition(callInfo_type *ptCi);
void FnVCCB_CheckStatForHO_NrdcSn(callInfo_type *ptCi);
void VHCM_CheckStatForInterRatHO(callInfo_type *ptCi);
void VHCM_ReleaseGnbNodeForInterGnbHO(callInfo_type *ptCi);
int16_t VCOM_SaIntraDuHandover_ToExecution(callInfo_type *ptCi);
int16_t VCOM_SaInterDuHandover_ToExecution(callInfo_type *ptCi);

int16_t FnVCCB_ProcULNasMsgDequeueForSaMobility(callInfo_type *ptCi);
int16_t FnVCCB_IsULNasMsgEnqueueRequiredForSaMobility(callInfo_type *ptCi);

void VCOM_InitSelectedTAI(selectedTAI_Type *p);
int16_t VCOM_SetSelectedTAI(
    selectedTAI_Type *ptSelectedTai, candidateNbrInformation_type *ptCandidateNbrInfo, uint32_t allow_idx);
int16_t VCOM_Decision_SelectedTAI_ByLastEutranPLMN(
    callInfo_type *ptCi, candidateNbrInformation_type *ptCandidateNbrInfo, selectedTAI_Type *ptSelectedTai);
int16_t VCOM_Decision_SelectedTAI_ByServedPLMN(
    callInfo_type *ptCi, candidateNbrInformation_type *ptCandidateNbrInfo, selectedTAI_Type *ptSelectedTai);
int16_t VCOM_Decision_SelectedTAI_ByServingAMF_ForIntraGnbNbr(callInfo_type *ptCi,
    candidateNbrInformation_type *ptCandidateNbrInfo, supportedAmfSetList_Type *ptServingAmfList,
    selectedTAI_Type *ptSelectedTai);
int16_t VCOM_Decision_SelectedTAI_ByServingAMF_ForInterGnbNbr(callInfo_type *ptCi,
    candidateNbrInformation_type *ptCandidateNbrInfo, supportedAmfSetList_Type *ptServingAmfList,
    selectedTAI_Type *ptSelectedTai);

void VCOM_SaHandover_Finalize(callInfo_type *ptCi);
int16_t VCOM_SaHandoverCancel_ToConn(callInfo_type *ptCi, uint16_t msgId);

void VCCM_InitSaMeasData(callInfo_type *ptCi);
void VCCM_InitPrevSaMeasData(callInfo_type *ptCi);
void VCCM_InitNsaMeasData(callInfo_type *ptCi);
void VCCM_InitPrevNsaMeasData(callInfo_type *ptCi);
void VCCM_InitSaMeas(saMeasStateInfo_type *saMeas);
void VCCM_InitAnrMeas(reportCgiInfo_type *reportCgi);


int16_t VCOM_checkSupportFreqPriorityBaseMobility(callInfo_type *ptCi, uint16_t cellNum);
int16_t getPlmnIdxFromUeServdPlmn(
    callInfo_type *ptCi, uint16_t cellNum, uint8_t *serv_plmn_index, uint8_t *serv_priority);
int16_t VCCM_CheckValidDssCellCondition(callInfo_type *ptCi, uint16_t cellNum, uint16_t nbrIdx, uint16_t band);
int16_t VHCM_CheckVoNR(callInfo_type *ptCi);

bool VCCB_IsIntraGnbNbrCell(uint16_t cellNum, uint16_t targetCellNum);

void FnVCCB_MrdcSnMobility_Finalize(callInfo_type *ptCi);

int16_t FnVCCB_CheckBandwidthCondition_NR_MN(callInfo_type *ptCi, nbrGnbCellInfo_type *ptNbrGnbCell, uint16_t nbrIdx, uint16_t band);
void FnVCCB_UpdateRefusedTargetGnbIdForHandover(callInfo_type *ptCi);

bool FnVCCB_isInterMnInitMobility(callInfo_type *ptCi);
bool FnVCCB_isMnInitMobility(callInfo_type *ptCi);
bool FnVCCB_isSnInitMobility(callInfo_type *ptCi);
bool FnVCCB_isIntraSnMobility(callInfo_type *ptCi);
bool FnVCCB_isIntraSnIntraCellMobility(callInfo_type *ptCi);

void FnVCCB_CopyFromSrcInfoToTgtInfo(callInfo_type *ptCi);
void FnVCCB_CopyFromTgtInfoToSrcInfo(callInfo_type *ptCi);
// NR_CONN_MC_22A
void VCCM_GetUeCapaRatTypeForIntraNrHO(callInfo_type *ptCi, uint8_t *ratTypeFilter);
void VCCM_GetUeCapaRatTypeForIratHO(callInfo_type *ptCi, uint8_t *ratTypeFilter);
int16_t VCCM_CheckValidSegmentedUeForIntraNrHO(callInfo_type *ptCi, nbrGnbCellInfo_type *ptNbrGnbCell, uint16_t nbrIdx);
int16_t VCCM_CheckValidSegmentedUeForIratHO(callInfo_type *ptCi, nbrEnbCellInfo_type *ptNbrEnbCell);

int16_t VCOM_SaIntraCellHandover_ToExecution(callInfo_type *ptCi);

bool FnVCCB_IsMrdcIntraMnHOWithSnAddition(callInfo_type *ptCi);
bool FnVCCB_IsMrdcInterMnHOWithSnAddition(callInfo_type *ptCi);
bool FnVCCB_IsMrdcInterMnHOWithoutSnAddition(callInfo_type *ptCi);

void *FnVCCB_GetHandoverPreparationIEs(void *ptMsg);
int16_t FnVCCB_NeedToDlTrfStatusRptCfgforNrToEutraHoAddPerDRB(
    callInfo_type *ptCi, callDRBInfo_type *pDi, bool isSend);
int16_t FnVCCB_CheckCommonDlTrfStatusRptCfgforNrToEutraHo(callInfo_type *ptCi, uint16_t cellNum);

void FnVCCB_SaHandoverErrorHandlingForStateMachine(
    callInfo_type *ptCi, msgUnpack_type *ptUnpack, const char *ptFuncName);
bool FnVCCB_IsMnTermNguUlTnlChangedFromHoPathSwitchAck(callInfo_type *ptCi);  // INTER_GNB_XN_HO_22C2

NRRRC_RRCReconfiguration *FnVCCB_UnpackAndGetRRCReconfigurationPDU(
    callInfo_type *ptCi, unsigned char *ptPackData, unsigned int length, enumCellGroupId cellGroupId);

uint8_t FnVCCB_IsNrToEutraHoNotAllowedFromSvcGrp(callInfo_type *ptCi);  // NR_CONN_MC_22C2

void FnVCCB_SetHandoverExecution(callInfo_type *ptCi);
bool FnVCCB_IsFlagBasedE1ControlForHO(callInfo_type *ptCi);

// NR_CONN_MC_23B 
void FnVCCB_InitOverloadedTgtGnbList(uint16_t gnbNum); 
void FnVCCB_CleanUpOverloadedTgtGnbList(uint16_t gnbNum); 
uint8_t FnVCCB_IsOverloadedTgtGnb(callInfo_type *ptCi, uint16_t gnbNum, vccbGlobalGnbId_type tgtGnbId);
void FnVCCB_FillOverloadedTgtGnbList(uint16_t gnbNum, uint16_t idx, vccbGlobalGnbId_type tgtGnbId);
//int16_t FnVCCB_AssignOverloadedTgtGnbListEntry(uint16_t gnbNum, uint16_t *idx);
void FnVCCB_AddOverloadedTgtGnb(uint16_t gnbNum, vccbGlobalGnbId_type tgtGnbId);
void FnVCCB_UpdateOverloadedHoTgtGnbInfo(callInfo_type *ptCi);
uint8_t FnVCCB_IsOverloadedGnbNbr(callInfo_type *ptCi, nbrGnbCellInfo_type *pNbr);
uint8_t VHCM_isSaEnabledNbr(callInfo_type *ptCi, nbrGnbCellInfo_type *pNbr);
int FnVCCB_InitOverloadedHoTgtGnbListMutex(pthread_mutexattr_t *pAttr); 

void FnVCCB_InitOnDemandMeasConfig(callInfo_type *ptCi);
void FnVCCB_InitOnDemandHoInfo(callInfo_type *ptCi);
bool FnVCCB_IsNr2EndcHandoverSupported(callInfo_type *ptCi); //IRAT_HO_CTRL_CONSID_24A

void FnVCCB_SaHandoverCollectAbnormalStat(callInfo_type *ptCi);
void FnVCCB_ForcedMobilityNr_CollectStat_PutCi(callInfo_type *ptCi); // ODF_HO_24A
void FnVCCB_USTM_CollectStat_PutCi(callInfo_type *ptCi);

void FnVCCB_CollectingSaHandoverStatistics_E1Fail(callInfo_type *ptCi);
void FnVCCB_CollectingSaHandoverStatistics_E1Timeout(callInfo_type *ptCi);
void FnVCCB_CollectingSaHandoverStatistics_F1Fail(callInfo_type *ptCi);
void FnVCCB_CollectingSaHandoverStatistics_F1Timeout(callInfo_type *ptCi);
void FnVCCB_CollectingSaHandoverStatistics_XnFail(callInfo_type *ptCi);
void FnVCCB_CollectingSaHandoverStatistics_XnTimeout(callInfo_type *ptCi);
void FnVCCB_CollectingSaHandoverStatistics_NgFail(callInfo_type *ptCi);
void FnVCCB_CollectingSaHandoverStatistics_NgTimeout(callInfo_type *ptCi);
void FnVCCB_CollectingSaHandoverStatistics_CpFail(callInfo_type *ptCi);

bool FnVCCB_IsSnUpKeyChangeRequired_InSn(callInfo_type *ptCi);
bool FnVCCB_CheckIfIntraCellHOIsAllowedForPSCellChange(callInfo_type *ptCi, enumHoTypeInitiated initiated);
bool FnVCCB_IsHoCancelReqdForVoNR(callInfo_type *ptCi); // FGR-MC1010 FR220

/* Partial HO */
void FnVCCB_SetCurrentlyAllowPartialHO(callInfo_type &rCall, bool allow);
typedef bool (*DRB_IsCheckFunc)(callDRBInfo_type &);
void FnVCCB_SetBitToReleaseDRB(callInfo_type &rCi, DRB_IsCheckFunc isCheckFunc);
bool FnVCCB_IsDrbReleasedToUe(callDRBInfo_type *ptDi);
bool FnVCCB_NeedToSendTxStopForFailedDrb(callDRBInfo_type *ptDi);
bool FnVCCB_NeedToReleaseFailedDrbFromAmf(callDRBInfo_type *ptDi);
void FnVCCB_SetPartialFlagsByF1Fail_ForIntraGnbHo(callInfo_type *ptCi, callDRBInfo_type *ptDi);

uint8_t FnVCCB_IsRestrictedTrafficBasedNrToEutraHoFromSvcGrp(callInfo_type &rCall);

bool FnVCCB_IsSpecificSliceUE(callInfo_type &rCall);

#endif  // VCCB_FEAT_FeatHo_H_
