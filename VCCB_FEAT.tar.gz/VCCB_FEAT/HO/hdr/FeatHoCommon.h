/**
 * @file        FeatHoCommon.h
 * @brief       Integrated HO(Handover) related header file
 * 
 * This file provides the functionality to integrally include
 * FeatHo.h, FeatConditionalHo.h, and FeatLtmHo.h.
 */

#ifndef VCCB_FEAT_FeatHoCommon_H_
#define VCCB_FEAT_FeatHoCommon_H_

#pragma once

#include "FeatHo.h"
#include "FeatConditionalHo.h"
#include "FeatLtmHo.h"
#include "HoFailedCellManager.h"

#endif // VCCB_FEAT_FeatHoCommon_H_
