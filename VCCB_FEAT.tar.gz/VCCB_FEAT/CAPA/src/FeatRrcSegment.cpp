/****************************************************************
 * System      : 5G vNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatRrcSegment.c
 * Description :
 * Author      :
 * Dept.       : Call S/W Lab.
 * Created     : 2022.08.17
 * Procedures defined :
 * Procedures called  :
 * Version     :
 * Revision history   :
 *          date      :
 *       revised by   :
 * revised information:
 ****************************************************************/

#include "FeatRrcSegment.h"

#include "ComInline.h"
#include "ComGlobalData.h"
#include "ComAutoNtrace.hpp"
#include <sstream>
#include <iomanip>

#include "shmem.h"

#include "NRRRC.h"

int16_t FnVCCB_InitRrcSegmentPoolBuf()
{
    AUTO_TRACE_FUNC;

    size_t size = 0;

    // Shm Create : VCCB_CAPA_SEGMENT_POOL_BUFFER
    // nodeCnt : based on supported UE count.
    VccbSegmentPoolInfo_type *pCapaInfo = GetgSegmentPoolInfo_();

    if (pCapaInfo == NULL)
    {
        VCCB_PRINTF("pCapaInfo is null!. in FnVCCB_InitRrcSegmentPoolBuf\n");
        return ERROR;
    }

    if (pCapaInfo->rrcSegmentPoolRatio == 0)
    {
        pCapaInfo->rrcSegmentPoolRatio = INIT_RRC_SEGBUF_POOL_RATIO;
    }

    double cnt = MAX_CALL_NUM_VCCB * AVG_NUM_CAPA_SEGMENT * ((double)pCapaInfo->rrcSegmentPoolRatio / 100);
    uint32_t nodeCnt = (uint32_t)cnt;
    if ((nodeCnt % MAX_CALL_THREAD_NUM_VCCB) != 0)
    {
        // Each thread shall have the same number of nodes.
        nodeCnt = nodeCnt - (nodeCnt % MAX_CALL_THREAD_NUM_VCCB);
    }

#if !defined(__NVGNB__)
    int shm_ret = SHM_OK;
    size = sizeof(segmentPoolBuffer_type) * nodeCnt;

    callShmInfoSysV_type rrcCapaSegbuf;
    snprintf(rrcCapaSegbuf.shmName, MAX_SHM_NAME, "VCCB_CAPA_SEGMENT_POOL_BUFFER");
    rrcCapaSegbuf.shmKey = CALL_SHM_SYSV_KEY_VCCB_CAPA_SEGBUF;
    rrcCapaSegbuf.shmAddr = (void **)&(pCapaInfo->segmentPoolBuffer);
    rrcCapaSegbuf.shmSize = size;
    rrcCapaSegbuf.shmId = 0;

    *(rrcCapaSegbuf.shmAddr) = callShmCreateSysV(&rrcCapaSegbuf);
    if (*(rrcCapaSegbuf.shmAddr) == NULL)
    {
        VCCB_PRINTF(" Try shm remove\n");
        shm_ret = callShmDestroySysV(rrcCapaSegbuf.shmKey);
        if (shm_ret != SHM_OK)
        {
            VCCB_PRINTF("Please check and kill itscp_vccb process.");
            return ERROR;
        }

        *(rrcCapaSegbuf.shmAddr) = callShmCreateSysV(&rrcCapaSegbuf);
        if (*(rrcCapaSegbuf.shmAddr) == NULL)
        {
            return ERROR;
        }
    }

    VCCB_PRINTF(
        "* VccbCapaInfo->segmentPoolBuffer(SysV) = sizeof(segmentPoolBuffer_type:%ld) * (MAX_CALL_NUM_VCCB(%d) * "
        "(AVG_NUM_CAPA_SEGMENT(%d) * rrcSegmentPoolRatio(%d)) = %ld bytes\n",
        (long)sizeof(segmentPoolBuffer_type), VCCB_MAX_CALL_COUNT_PER_CPC, AVG_NUM_CAPA_SEGMENT, pCapaInfo->rrcSegmentPoolRatio,
        (long)size);

#else
    // Malloc Global variable
    size = sizeof(segmentPoolBuffer_type) * nodeCnt;
    VCCB_CAPA_SEGMENT_POOL_BUFFER = (segmentPoolBuffer_type *)callShmCreate64("VCCB_CAPA_SEGMENT_POOL_BUFFER", size);
    if (VCCB_CAPA_SEGMENT_POOL_BUFFER == NULL)
    {
        VCCB_PRINTF("fail to callShmCreate64 gRrcSegMsg(size=%ld)\n", sizeof(segmentPoolBuffer_type) * nodeCnt);
        perror("callShmCreate64(VCCB_CAPA_SEGMENT_POOL_BUFFER): ");
        return ERROR;
    }
#endif

    if(GOOD !=  FnVCCB_ClearRrcSegmentPoolBuf(nodeCnt))
    {
        return ERROR;
    }

    return GOOD;
}

void FnVCCB_FreeRrcSegmentPoolBuf(uint16_t threadId, uint32_t bufIdx)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);
    segmentPoolBuffer_type *pSegmentPoolBuf = GetgSegmentPoolBuffer_();
    segmentPoolManager_type *segmentPoolManager = GetgSegmentPoolManager_();
    if ((pSegmentPoolBuf == NULL) || (segmentPoolManager == NULL))
    {
        return;
    }

    if (bufIdx == UNKNOWN_SEGMENT_POOL_IDX)  // 0xFFFFFFFF
    {
        return;
    }

    uint32_t offset = 0;

    offset = bufIdx * MAX_CALL_THREAD_NUM_VCCB + threadId;
    if (offset >= segmentPoolManager->maxPoolSize)
    {
        return;
    }

    // SEG_SHM
    pSegmentPoolBuf[offset].usage = FLAG_OFF;
    pSegmentPoolBuf[offset].numocts = 0;
    pSegmentPoolBuf[offset].callId = UNKNOWN_CP_CALLID;
    pSegmentPoolBuf[offset].segmentPduType = UNKNOWN_SEGMENT_PDU_TYPE;
    segmentPoolManager->availCnt[threadId]++;

    return;
}

void FnVCCB_GetRrcSegmentOffset(callInfo_type *ptCi, uint32_t bufIdx, uint32_t *offset)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(offset);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    *offset = ptCi->myThreadId + (bufIdx * MAX_CALL_THREAD_NUM_VCCB);

    return;
}

void FnVCCB_CopyDataToSegmentPoolBuffer(
    callInfo_type *ptCi, uint8_t *pSrcBuf, uint32_t srcLength, enumSegmentPdu_type pduType, uint32_t bufIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pSrcBuf);

    segmentPoolBuffer_type *pSegmentPoolBuf = GetgSegmentPoolBuffer_();
    segmentPoolManager_type *pSegmentPoolManager = GetgSegmentPoolManager_();
    if (pSegmentPoolBuf == NULL || pSegmentPoolManager == NULL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Fail To Alloc pSegmentPoolBuf/pSegmentPoolManager\n");
        return;
    }

    uint32_t offset = pSegmentPoolManager->maxPoolSize;

    FnVCCB_GetRrcSegmentOffset(ptCi, bufIdx, &offset);

    if (offset >= pSegmentPoolManager->maxPoolSize)
    {
        return;
    }

    segmentPoolBuffer_type *pTgtBuf = &pSegmentPoolBuf[offset];

    pTgtBuf->segmentPduType = pduType;
    pTgtBuf->numocts = static_cast<uint16_t>(srcLength);
    memcpy(pTgtBuf->data, pSrcBuf, srcLength);
}

/**
 *  @brief Split one large UCI to NR/MRDC/EUTRA capa according to its rat-type
 */

int16_t FnVCCB_StoreBigUECapabilityToRrcSegmentPool(
    callInfo_type *ptCi, enumSegmentPdu_type pduType, extUeCapaInfo_type *tgtSegInfo, uint8_t *srcBuf, uint32_t length)
{
    AUTO_TRACE_FUNC;

    uint8_t segCnt = static_cast<uint8_t>((length + MAX_RRC_PDU_LENGTH - 1) / (MAX_RRC_PDU_LENGTH));
    uint32_t remainLen = length, dataLen = 0;
    uint8_t loop = 0;
    uint32_t bufIdx = UNKNOWN_SEGMENT_POOL_IDX;

    // Initialization
    FnVCCB_FreeUeCapabilityInfoPerRatType(ptCi, pduType);

    for (loop = 0; loop < segCnt; loop++)
    {
        // 1. Allocated RRC Seg Buffer
        bufIdx = FnVCCB_AllocSegmentPoolBuffer(*ptCi);
        if (bufIdx == UNKNOWN_SEGMENT_POOL_IDX)
        {
            // In the NG Store procedure, it is assumed that all segments have already been received.
            ptCi->ueInfo.ueCapa.savedInfo.isFailedToStoreSegment = VCCB_FLAG_ON;

            // Fail Case : Free All Bufs allocated so far.
            FnVCCB_FreeExtUeCapaInfo(ptCi, tgtSegInfo);
            return ERROR;
        }
        // 2. Save Buffer Index to CallInfo
        tgtSegInfo->segIndex[loop] = bufIdx;
        dataLen = (remainLen > MAX_RRC_PDU_LENGTH) ? MAX_RRC_PDU_LENGTH : remainLen;
        tgtSegInfo->capaLength += dataLen;
        tgtSegInfo->segCnt++;

        // 3. Trim the 'big capa' up to 'MAX_RRC_PDU_LENGTH'(9000) and store.
        FnVCCB_CopyDataToSegmentPoolBuffer(ptCi, srcBuf, dataLen, pduType, bufIdx);
        remainLen -= dataLen;
        srcBuf += dataLen;
    }

    if(DBG->flag.logRrcSegmentation)
    {
        std::ostringstream oss;
        for (loop = 0; loop < segCnt; loop++)
        {
            // DBG
            oss << tgtSegInfo->segIndex[loop] << " ";
        }
        VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "[Segment Pool Alloc][PduType:%d] Length(%d) OffsetList(%s)\n", pduType, tgtSegInfo->capaLength, oss.str().c_str());
    }

    return GOOD;
}

/**
 *  @brief Assemble multiple segment buffer to one large UCI
 */

int16_t FnVCCB_StoreUlRrcDedicateSegmentToRrcSegmentPool(callInfo_type *ptCi, enumSegmentPdu_type pduType,
    extUeCapaInfo_type *tgtSegInfo, void *srcIE_void)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(tgtSegInfo);
    VALID_E_POINT_CHECK_ERROR(srcIE_void);

    uint32_t bufIdx = UNKNOWN_SEGMENT_POOL_IDX;
    NRRRC_ULDedicatedMessageSegment_r16_IEs *srcIE = (NRRRC_ULDedicatedMessageSegment_r16_IEs *)srcIE_void;

    if (srcIE->segmentNumber_r16 >= MAX_RRC_SEGMENT)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[%s] segmentNumber_r16(%d) is invalid!\n", __FUNCTION__, srcIE->segmentNumber_r16);
        return ERROR;
    }

    if (srcIE->rrc_MessageSegmentContainer_r16.length > MAX_RRC_PDU_LENGTH)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "[%s]length(%d) is invalid\n", __FUNCTION__, srcIE->rrc_MessageSegmentContainer_r16.length);
        return ERROR;
    }

    if (srcIE->rrc_MessageSegmentType_r16 == (NRRRC__enum15)NRRRC_lastSegment)
    {
        ptCi->ulRrcSegment.lastSegIdx = static_cast<uint8_t>(srcIE->segmentNumber_r16);
    }

    uint8_t segNum = static_cast<uint8_t>(srcIE->segmentNumber_r16);  // segmentNumber-r16  INTEGER (0..15),

    if (tgtSegInfo->segIndex[segNum] != UNKNOWN_SEGMENT_POOL_IDX)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "srcIE->segmentNumber_r16(%d) and tgtSegInfo->segIndex[%d](%d) is mismatched.\n",
            srcIE->segmentNumber_r16, segNum, tgtSegInfo->segIndex[segNum]);
        return ERROR;
    }

    // 1. Allocated RRC Seg Buffer
    bufIdx = FnVCCB_AllocSegmentPoolBuffer(*ptCi);
    if (bufIdx == UNKNOWN_SEGMENT_POOL_IDX)
    {
        // Save lastSegIdx and segCnt for error handling
        ptCi->ueInfo.ueCapa.savedInfo.isFailedToStoreSegment = VCCB_FLAG_ON;
        ptCi->ulRrcSegment.segCnt++;        
        return BREAK;
    }
    // 2. Save Buffer Index to CallInfo
    tgtSegInfo->segIndex[segNum] = bufIdx;
    tgtSegInfo->segCnt++;
    tgtSegInfo->capaLength += srcIE->rrc_MessageSegmentContainer_r16.length;

    // 3. Store
    FnVCCB_CopyDataToSegmentPoolBuffer(ptCi, srcIE->rrc_MessageSegmentContainer_r16.value,
        srcIE->rrc_MessageSegmentContainer_r16.length, pduType, bufIdx);

    if(DBG->flag.logRrcSegmentation)
    {
        uint32_t offset = 0;
        std::ostringstream oss;

        FnVCCB_GetRrcSegmentOffset(ptCi, bufIdx, &offset);
        segmentPoolBuffer_type *pSegmentPoolBuf = GetgSegmentPoolBuffer_();
        segmentPoolBuffer_type *ptgtBuf = &pSegmentPoolBuf[offset];

        if (pSegmentPoolBuf == NULL || ptgtBuf == NULL)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid Segment Pool Buf\n");
            return ERROR;
        }

        for (unsigned int i = 0; i < MIN(3, srcIE->rrc_MessageSegmentContainer_r16.length); i++)
        {
            oss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(ptgtBuf->data[i]) << " ";
        }
        oss << "...";
        for (unsigned int i = 0; i < MIN(3, srcIE->rrc_MessageSegmentContainer_r16.length); i++)
        {
            oss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(ptgtBuf->data[srcIE->rrc_MessageSegmentContainer_r16.length - i - 1]) << " ";
        }

        if (srcIE->rrc_MessageSegmentType_r16 == (NRRRC__enum15)NRRRC_lastSegment)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[Store]UlDedicatedMessageSegment #[%d/%d] pduType:%d length:%d data: [%s]\n",
                srcIE->segmentNumber_r16, srcIE->segmentNumber_r16, ptgtBuf->segmentPduType,
                srcIE->rrc_MessageSegmentContainer_r16.length, oss.str().c_str());

            VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                "[Large UE Capa] TOTAL RX NRRRC_ULDedicatedMessageSegment(UL-DCCH-Message) LENGTH: [%d]\n",
                tgtSegInfo->capaLength);
        }
        else
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[Store]UlDedicatedMessageSegment #[%d/-] pduType:%d length:%d data: [%s]\n",
                srcIE->segmentNumber_r16, ptgtBuf->segmentPduType, srcIE->rrc_MessageSegmentContainer_r16.length, oss.str().c_str());
        }
    }

    return GOOD;
}

uint32_t FnVCCB_AllocSegmentPoolBuffer(callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;
    if(rCall.myThreadId > MAX_CALL_THREAD_NUM_VCCB)
    {
        return UNKNOWN_SEGMENT_POOL_IDX;
    }

    uint32_t idx = 0, currentIdx = 0, allocBufIdx = 0, offset = 0;
    uint8_t threadId = rCall.myThreadId;

    // Get the segment node and buffer for the current thread
    const auto &threadPoolIndexManager = GetgSegmentPoolManager_(); // Per Thread
    auto poolBuffer = GetgSegmentPoolBuffer_(); // 9000B size buf

    // Check if pointers are valid
    if ((poolBuffer == NULL) || (threadPoolIndexManager == NULL))
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "FnVCCB_AllocSegmentPoolBuffer GetgRrcSegNode/Buf Invalid\n");
        return UNKNOWN_SEGMENT_POOL_IDX;
    }

    // Pool Full
    if(threadPoolIndexManager->availCnt[threadId] == 0) 
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "UE Capa Segment Buffer Pool is not enough - thread[%d] available/total(%u/%u)\n", threadId, threadPoolIndexManager->availCnt[threadId], threadPoolIndexManager->sizePerThread);
        return UNKNOWN_SEGMENT_POOL_IDX;
    }

    // Get the next index to check for availability
    currentIdx = threadPoolIndexManager->nextIndex[threadId];
    // If the next index is out of bounds, reset it to zero
    if (currentIdx >= threadPoolIndexManager->sizePerThread) currentIdx = 0;

    // Pool Buffer Indexing Rule (n thread, k' th element)
    //                  [0]   [1]    [2]   [3]   [4]    [k]
    // Thread 0:  0    0+n   2n+0  3n+0   ...    kn
    // Thread 1:  1    1+n   2n+1  3n+1   ...   kn+1
    // ....
    // Thread n:  n-1  2n-1  3n-1  4n-1   ...   kn+n

    // Search for an available buffer starting from the next index
    // currentIdx ~ sizePerThread
    for (idx = currentIdx; idx < threadPoolIndexManager->sizePerThread; idx++)
    {
        // Calculate the offset in the buffer array
        FnVCCB_GetRrcSegmentOffset(&rCall, idx, &offset);
        if(offset > threadPoolIndexManager->maxPoolSize)
        {
            VCCB_PRINT_CALL_ERROR(&rCall, "FnVCCB_AllocSegmentPoolBuffer offset(%u) exceeds maxPoolSize(%u)\n", offset, threadPoolIndexManager->maxPoolSize);
            return UNKNOWN_SEGMENT_POOL_IDX;
        }

        if (poolBuffer[offset].usage == FLAG_OFF) 
        {
            // Mark the buffer as in use and assign the call ID
            poolBuffer[offset].usage = FLAG_ON;
            poolBuffer[offset].callId = rCall.callId;

            // Update the buffer index and next index for the thread
            allocBufIdx = idx;
            threadPoolIndexManager->nextIndex[threadId] = idx + 1;
            if (threadPoolIndexManager->availCnt[threadId] > 0)
            {
                threadPoolIndexManager->availCnt[threadId]--;
            }

            // Return the allocated buffer index
            return allocBufIdx;
        }
    }

    // If no buffer was found in the first loop, search from the beginning up to the next index.
    // 0 ~ currentIdx
    for (idx = 0; idx < currentIdx; idx++)
    {
        // Calculate the offset in the buffer array
        FnVCCB_GetRrcSegmentOffset(&rCall, idx, &offset);
        if(offset > threadPoolIndexManager->maxPoolSize)
        {
            VCCB_PRINT_CALL_ERROR(&rCall, "FnVCCB_AllocSegmentPoolBuffer offset(%u) exceeds maxPoolSize(%u)\n", offset, threadPoolIndexManager->maxPoolSize);
            return UNKNOWN_SEGMENT_POOL_IDX;
        }

        if (poolBuffer[offset].usage == FLAG_OFF) 
        {
            // Mark the buffer as in use and assign the call ID
            poolBuffer[offset].usage = FLAG_ON;
            poolBuffer[offset].callId = rCall.callId;

            // Update the buffer index and next index for the thread
            allocBufIdx = idx;
            threadPoolIndexManager->nextIndex[threadId] = idx + 1;
            if (threadPoolIndexManager->availCnt[threadId] > 0)
            {
                threadPoolIndexManager->availCnt[threadId]--;
            }

            // Return the allocated buffer index
            return allocBufIdx;
        }
        
    }

    VCCB_PRINT_CALL_ERROR(&rCall, "FnVCCB_AllocSegmentPoolBuffer Fail to alloc\n");
    return UNKNOWN_SEGMENT_POOL_IDX;    
}

/**
 *  @brief Store single UL Dedicate Segment Message to a segment buffer pool
 */

int16_t FnVCCB_GetCapabilityDataFromRrcSegment(
    callInfo_type *ptCi, extUeCapaInfo_type *segInfo, bigMsgContainer_type *tgtBuf)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(segInfo);
    VALID_E_POINT_CHECK_ERROR(tgtBuf);

    uint8_t loop = 0;
    uint32_t length = 0, offset = 0;
    segmentPoolBuffer_type *pSegmentBuf = GetgSegmentPoolBuffer_();
    segmentPoolManager_type *segmentPoolManager = GetgSegmentPoolManager_();

    VALID_E_POINT_CHECK_ERROR(pSegmentBuf);
    VALID_E_POINT_CHECK_ERROR(segmentPoolManager);

    length = tgtBuf->numocts;

    for (loop = 0; loop < MIN(segInfo->segCnt, MAX_RRC_SEGMENT); loop++)
    {
        FnVCCB_GetRrcSegmentOffset(ptCi, segInfo->segIndex[loop], &offset);
        if(offset >= segmentPoolManager->maxPoolSize)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "offset(%u) maxPoolSize(%u)\n", offset, segmentPoolManager->maxPoolSize);
            return ERROR;
        }

        if(length >= MAX_BIG_UE_CAPA_ALL_RAT_LENGTH + 1)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "length(%u) max_length(%u)\n", length, MAX_BIG_UE_CAPA_ALL_RAT_LENGTH + 1);                     
            return ERROR;
        }

        memcpy(&tgtBuf->data[length], pSegmentBuf[offset].data, pSegmentBuf[offset].numocts);
        length += pSegmentBuf[offset].numocts;
    }
    tgtBuf->numocts = length;

    return GOOD;
}

int8_t FnVCCB_Check_isSegmentedUciCall(const callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if ((ptCi->ueContainerNR.isBigCapaFlag == VCCB_FLAG_ON)
        || (ptCi->ueContainerMRDC.isBigCapaFlag == VCCB_FLAG_ON) 
        || (ptCi->ueContainerEUTRA.isBigCapaFlag == VCCB_FLAG_ON))
    {
        return TRUE;
    }

    return FALSE;
}

int8_t FnVCCB_CheckTgtNodeSupportUlSegmentCapability(
    uint32_t gnbNum, uint32_t nodeId, plmnId_type plmn, enumUlSegCapaNode_type nodeType)
{
    (void)gnbNum;
    (void)nodeId;
    (void)plmn;
    (void)nodeType;
    return TRUE;
}

ueCapabilitiesRATcontainer_type* FnVCCB_GetUeCapabilityRatContainer(callInfo_type &rCall, const uint8_t ratType)
{
    AUTO_TRACE_FUNC;

    switch (ratType)
    {
        case NRRRC_RAT_Type_nr:
            return &rCall.ueContainerNR;

        case NRRRC_RAT_Type_eutra_nr:
            return &rCall.ueContainerMRDC;

        case NRRRC_RAT_Type_eutra:
            return &rCall.ueContainerEUTRA;

        default:
            VCCB_PRINT_CALL_ERROR(&rCall, "FnVCCB_GetUeCapabilityRatContainer ratType Error(ratType : %d)!\n", ratType);
    }

    return nullptr;
}

extUeCapaInfo_type* FnVCCB_GetUeCapabilityBigRatContainer(callInfo_type &rCall, const uint8_t ratType)
{
    AUTO_TRACE_FUNC;

    switch (ratType)
    {
        case NRRRC_RAT_Type_nr:
            return &rCall.ueContainerNR_Ext;

        case NRRRC_RAT_Type_eutra_nr:
            return &rCall.ueContainerMRDC_Ext;

        case NRRRC_RAT_Type_eutra:
            return &rCall.ueContainerEUTRA_Ext;

        default:
            VCCB_PRINT_CALL_ERROR(&rCall, "FnVCCB_GetUeCapabilityBigRatContainer ratType Error(ratType : %d)!\n", ratType);
    }

    return nullptr;
}

int FnVCCB_isBigCapabilityRatContainer(callInfo_type *ptCi, uint8_t ratType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    // typedef enum NRRRC_RAT_Type {
    //     NRRRC_RAT_Type_nr = 0,
    //     NRRRC_RAT_Type_eutra_nr = 1,
    //     NRRRC_RAT_Type_eutra = 2,
    //     NRRRC_RAT_Type_utra_fdd_v1610 = 3
    // } NRRRC_RAT_Type;

    ueCapabilitiesRATcontainer_type *pContainer = FnVCCB_GetUeCapabilityRatContainer(*ptCi, ratType);

    // Handle both of packed/unpacked ueContainerXX_Ext buffer (nr, eutra_nr, eutra)
    if (nullptr == pContainer)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetUeCapabilityRatContainer (ratType : %d) ERROR!\n", ratType);
        return FALSE;
    }

    if(pContainer->isBigCapaFlag == VCCB_FLAG_ON)
    {
        return TRUE;
    }
    
    return FALSE;
}

void FnVCCB_FreeExtUeCapaInfo(callInfo_type *ptCi, extUeCapaInfo_type *pContainerExt)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pContainerExt);

    uint32_t length = pContainerExt->capaLength;
    uint8_t segCnt = pContainerExt->segCnt;

    if (length == 0) return;

    for (int loop = 0; loop < MAX_RRC_SEGMENT; ++loop)
    {
        if (pContainerExt->segIndex[loop] != UNKNOWN_SEGMENT_POOL_IDX)
        {
            FnVCCB_FreeRrcSegmentPoolBuf(ptCi->myThreadId, pContainerExt->segIndex[loop]);
        }
    }

    if(DBG->flag.logRrcSegmentation)
    {
        std::ostringstream oss;
        for (int loop = 0; loop < MAX_RRC_SEGMENT; ++loop)
        {
            if (pContainerExt->segIndex[loop] != UNKNOWN_SEGMENT_POOL_IDX)
            {        
                oss << pContainerExt->segIndex[loop] << ' ';
            }
        }
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[Segment Pool Free] Length(%u) SegCnt(%hhu) OffsetList(%s)\n",
                                    length, segCnt, oss.str().c_str());
    }

    FnVCCB_InitExtUeCapaInfo(ptCi, pContainerExt);
}

void FnVCCB_InitExtUeCapaInfo(callInfo_type *ptCi, extUeCapaInfo_type *pContainerExt)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pContainerExt);

    int loop = 0;

    pContainerExt->segCnt = 0;
    pContainerExt->capaLength = 0;
    pContainerExt->lastSegIdx = 0xFF;

    for (loop = 0; loop < MAX_RRC_SEGMENT; loop++)
    {
        pContainerExt->segIndex[loop] = UNKNOWN_SEGMENT_POOL_IDX;  // 0xFFFFFFFF
    }

}

bool FnVCCB_IsAvailableRrcSegmentPool(callInfo_type* ptCi)
{
    AUTO_TRACE_FUNC;    
    VALID_E_POINT_CHECK_RET_VAL(ptCi,false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB,false);


    segmentPoolManager_type *segmentPoolManager = GetgSegmentPoolManager_();

    if (segmentPoolManager == NULL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "segmentPoolManager == NULL\n");
        return false;
    }

    if (segmentPoolManager->availCnt[ptCi->myThreadId] < MAX_RRC_SEGMENT)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "UE Capa Segment Buffer Pool is not enough. Disable rrc_segAllowed_r16.\n");
        return false;
    }
    return true;
}

int FnVCCB_CanGnbStoreUlRrcSegmentationCapa()
{
    return FOO.VF_SegmentationOfRrcMessages;
}

int FnVCCB_CanGnbEnquiryUlRrcSegmentationCapa(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    // Cond1. Feature Foo
    if(FALSE == FOO.VF_SegmentationOfRrcMessages)
    {
        if(DBG->flag.logUeCapaEnquiry)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Not support UL RRC Segmentation(FOO.VF_SegmentationOfRrcMessages : %d)\n", FOO.VF_SegmentationOfRrcMessages);
        }
        return FALSE;
    }

    // Cond2. YANG under overload condition
    if((TRUE != IS_AVAILABLE_UNDER_CPC_OVERLOAD(CFG->overloadControl.ueSigCpuOverloadControl.ulRrcSegmentOverloadThreshold)))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Not support UL RRC Segmentation(CPC overload state: %d, ulRrcSeg OverloadThreshold: %d)!\n", GET_CPC_OVERLOAD_STATE(), CFG->overloadControl.ueSigCpuOverloadControl.ulRrcSegmentOverloadThreshold);
        return FALSE;
    }
    
    // Cond3. gNB can enquiry UE Capa with UL RRC Segmentation allowed(rrc-segAllowed-r16)
    if(GNBINFO[ptCi->gnbNum].cfg.ulRrcSegmentAllowed != TRUE)
    {
        if(DBG->flag.logUeCapaEnquiry)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "gNB does not support UL RRC Segmentation(GNBINFO[%d].cfg.ulRrcSegmentAllowed : %d)!\n", ptCi->gnbNum, GNBINFO[ptCi->gnbNum].cfg.ulRrcSegmentAllowed);
        }        
        return FALSE;
    }

#if defined(HOST_SIM) || defined(NEW_HOST_SIM)
    // dbg only
    if(DBG->flag.skipCheckUeRrcSegmentation)
    {
        return TRUE;
    }
#endif

    // Cond4. gNB Supports UE based UL Segmentation (IE in RRC Setup Complete)
    if((ptCi->stateCmd == RRCConnection_cmd)  || (ptCi->stateCmd == Idle_cmd))
    {
        if((GNBINFO[ptCi->gnbNum].cfg.ulSegmentWithRrcComplete == VCCB_FLAG_ON) && (ptCi->ueInfo.ueSupportUlRrcSegment != VCCB_FLAG_ON))
        {
            if(DBG->flag.logUeCapaEnquiry)
            {
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "gNB doesn't support UL RRC Segmentation(ulSegmentWithRrcComplete: %d)\n", GNBINFO[ptCi->gnbNum].cfg.ulSegmentWithRrcComplete);
            }        
            return FALSE;
        }
    }

    // Cond5. Segmentation Pool is Available. 
    if((ptCi->ueInfo.ueCapa.savedInfo.isFailedToStoreSegment == VCCB_FLAG_ON) || (true != FnVCCB_IsAvailableRrcSegmentPool(ptCi)))
    {
        auto poolManager = GetgSegmentPoolManager_();
        if(poolManager == NULL)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid GetgSegmentPoolManager_  ERROR\n");
            return FALSE;
        }
        VCCB_PRINT_CALL_ERROR(ptCi,
            "Segment Pool usage: - thread[%d] available/total (%u/%u) isFailedToStoreSegment(%d)\n", ptCi->myThreadId,
            poolManager->sizePerThread - poolManager->availCnt[ptCi->myThreadId], poolManager->sizePerThread, ptCi->ueInfo.ueCapa.savedInfo.isFailedToStoreSegment);
        return FALSE;
    }

    // Cond6. Current UE sent over 45K capa (Not supported)



    return TRUE;
}

int16_t FnVCCB_ClearRrcSegmentPoolBuf(uint32_t nodeCnt)
{
    segmentPoolBuffer_type *pSegmentBuf = GetgSegmentPoolBuffer_();
    segmentPoolManager_type *segmentPoolManager = GetgSegmentPoolManager_();
    if ((pSegmentBuf == NULL) || (segmentPoolManager == NULL))
    {
        return ERROR;
    }
    // Init Buff
    for (uint32_t loop = 0; loop < nodeCnt; loop++)
    {
        pSegmentBuf[loop].usage = 0;
        pSegmentBuf[loop].numocts = 0;
        pSegmentBuf[loop].callId = UNKNOWN_CP_CALLID;
        pSegmentBuf[loop].segmentPduType = UNKNOWN_SEGMENT_PDU_TYPE;
    }
    // Init Node
    segmentPoolManager->maxPoolSize = nodeCnt;
    segmentPoolManager->sizePerThread = nodeCnt / MAX_CALL_THREAD_NUM_VCCB;

    for (int loop = 0; loop < MAX_CALL_THREAD_NUM_VCCB; loop++)
    {
        segmentPoolManager->nextIndex[loop] = 0;
        segmentPoolManager->availCnt[loop] = segmentPoolManager->sizePerThread;
    }

    VCCB_PRINTF("segmentPoolManager->maxPoolSize(Total):%u, segmentPoolManager->sizePerThread(each thread):%u\n", segmentPoolManager->maxPoolSize, segmentPoolManager->sizePerThread);

    return GOOD;
}
