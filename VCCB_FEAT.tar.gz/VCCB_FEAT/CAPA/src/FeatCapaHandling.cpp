/****************************************************************
 * System      : 5G vNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatCapaHandling.c
 * Description :
 * Author      :
 * Dept.       : Call S/W Lab.
 * Created     : 2022.08.17
 * Procedures defined :
 * Procedures called  :
 * Version     :
 * Revision history   :
 *          date      :
 *       revised by   :
 * revised information:
 ****************************************************************/

#include "FeatCapaHandling.h"
#include "FeatRrcSegment.h"
#include "FeatCommon.h"
#include "FeatCallInfo.h"
#include "FeatMco.hpp"

#include "ComGlobalData.h"
#include "ComLibUtility.h"
#include "ComInline.h"
#include "ComAutoNtrace.hpp"

#include "StateCommon.h"

#include "MsgNgapSend.h"

#include "nrrrcUnpack.h"
#include "VpmInterface.h"
#include "ComLibStatistic.h"

#include <string>

extern "C" {
    #include "RRC.h"
    #include "errcUnpack.h"
}

int16_t FnVCCB_NeedUeCapaEnquiry(callInfo_type *ptCi, uint16_t cellNum, uint8_t *needEnquiryBitFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);

    /* ========================================================
     * Summary : Conditions to invoke 'Capability Enquiry'
     *
     * gNB retries the UE Capa Enquiry when the sum of the received UE Capa is greater than the limit. (Limit - General: 27K, Supporting Ul Segmentation: 45K)
     * If it is impossible for gNB to trigger UE Capa Enquiry (e.g., if gNB is SN), gNB processes store failure for the received UE capa.
     * 
     * CASE A. NR Capa Validation
     * - If at least one of the following conditions is satisfied, request NR/MR-DC/Eutra Capa again.
     *     A-1) No NR Capa received
     *     A-2) The UE's NR-Capability::supportedBandListNR does not have one Serving PCell Band. (New)
     *     A-3) gNB does not have an appliedFreqBandList.
     *     A-4) AppliedFreqBandList Validation
     *       - Describe in 'FnVCCB_NeedUeCapaEnquiryByAppliedFreqBandList'
     *     A-5) Cell that clears NR-DC, if there is no includeNR_DC information. (New)
     *
     * CASE B. MR-DC Capa Validation
     *    - If the appliedFreqBandList of the received NR and MR-DC is different, request MR-DC/EutraCapa again.
     *       At this time, delete the MR-DC Capa receiving flag immediately.
     *
     * CASE C. Eutra Capa Validation.
     *      - If there is no Eutra Capa received, request Eutra Capa again.
     *
     ======================================================== */

    // DBG Only
    if (VCCB_FLAG_ON == DBG->flag.forcelyUeNrCapaEnquiry)
    {
        *needEnquiryBitFlag = UE_CAPA_REQ_RAT_TYPE_ALL;
        return TRUE;
    }

    // 0. MRDC Exist Check Flag.
    if (IS_NEDC(ptCi))
    {
        return FALSE;
    }

    // 0. Remove RX UE Capa depending on Support RAT(YANG Configuration)
    uint8_t removeUeCapaFlag = 0x00;
    if(TRUE == FnVCCB_IsOnlyNrCapaSupported(ptCi))
    {
        removeUeCapaFlag = UE_CAPA_REQ_RAT_TYPE_MRDC + UE_CAPA_REQ_RAT_TYPE_EUTRA;

    }
    else if(TRUE == FnVCCB_IsOnlyNrEutraCapaSupported(ptCi))
    {
        // In NR_AND_EUTRA Mode.
        // cond 1. Cell or Ue Capa is supported, then do not remove MR-DC Capa.
        // cond 2. UE had sent MR-DC before, then do not remove MR-DC Capa.
        if(ptCi->ueInfo.ueCapa.savedInfo.sendMrdcCapaInNrEutraMode || FnVCCB_IsCellAndUeSupportNrHoToEndcR16(ptCi, cellNum))
        {
            // Keep MR-DC Capa In NR-Eutra Mode.
        }
        else
        {
            removeUeCapaFlag = UE_CAPA_REQ_RAT_TYPE_MRDC;
        }
    }

    if(removeUeCapaFlag)
    {
        if((removeUeCapaFlag & UE_CAPA_REQ_RAT_TYPE_MRDC) && (ptCi->ueContainerMRDC.rxFlag == VCCB_FLAG_ON))
        {
            ptCi->ueContainerMRDC.rxFlag = VCCB_FLAG_OFF;
            FnVCCB_FreeUeCapabilityInfoPerRatType(ptCi, UE_MRDC_Capability);
            ptCi->ueInfo.ueCapa.mrdc.appliedFreqBandList.num = 0;
            ptCi->ueInfo.ueCapa.savedInfo.sendMrdcCapaInNrEutraMode = FALSE;
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "MRDC Capa is removed In FnVCCB_NeedUeCapaEnquiry\n");
        }

        if((removeUeCapaFlag & UE_CAPA_REQ_RAT_TYPE_EUTRA) && (ptCi->ueContainerEUTRA.rxFlag == VCCB_FLAG_ON))
        {
            ptCi->ueContainerEUTRA.rxFlag = VCCB_FLAG_OFF;
            FnVCCB_FreeUeCapabilityInfoPerRatType(ptCi, UE_EUTRA_Capability);
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "EUTRA Capa is removed In FnVCCB_NeedUeCapaEnquiry\n");
        }        
    }

    if (IS_NRDC(ptCi))
    {
        return FALSE;
    }

    // CASE A. NR Capa Condition.
    if (TRUE == FnVCCB_NeedUeCapaEnquiryByNrCapa(ptCi, cellNum))
    {
        // Now Set All. But After receiving NR Capa, then decide NR Capa Only using FnVCCB_IsOnlyNrCapaSupported()        
        *needEnquiryBitFlag = UE_CAPA_REQ_RAT_TYPE_ALL;
        if (ptCi->stateCmd == RRCConnection_cmd)
        {
            // Directly Set for Basic Call.
            ptCi->ueCapaEnquiry.needEnquiryBitFlag = *needEnquiryBitFlag;
        }
        return TRUE;  // Trigger Now
    }

    if (DBG->flag.isSkipFilterAppliedFreqBandList == TRUE)
    {
        // Beware : DBG Only. Skip to Check BandFilter / Eutra Capa Check.
        return FALSE;
    }

    // CASE B. Compare appliedFreqBandListFilter ( NR vs MR-DC )
    if(VCCB_FLAG_ON == ptCi->ueContainerMRDC.rxFlag)
    {
        VCCM_DiffandArrangeAppliedFilter(ptCi);  // if diff, set ueContainerMRDC.rxFlag as 0.
    }

    if (TRUE == FnVCCB_NeedUeCapaEnquiryByMrDcCapa(ptCi, cellNum))
    {
        // In NR_AND_EUTRA Mode.
        // Cell or Ue Cpaa is not supported, then Remove MR-DC Capa and go to check eutra.
        if((TRUE == FnVCCB_IsOnlyNrEutraCapaSupported(ptCi)) && (FALSE == FnVCCB_IsCellAndUeSupportNrHoToEndcR16(ptCi, cellNum)))
        {
            if(ptCi->ueContainerMRDC.rxFlag == VCCB_FLAG_ON)
            {
                ptCi->ueContainerMRDC.rxFlag = VCCB_FLAG_OFF;
                FnVCCB_FreeUeCapabilityInfoPerRatType(ptCi, UE_MRDC_Capability);
                ptCi->ueInfo.ueCapa.mrdc.appliedFreqBandList.num = 0;
                ptCi->ueInfo.ueCapa.savedInfo.sendMrdcCapaInNrEutraMode = FALSE;
VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Remove MR-DC Capa by Not Supporting NrHoToEndcR16\n");
            }
            // Check Next Step(Eutra) // Not Return.
        }
        else
        {
            *needEnquiryBitFlag = (UE_CAPA_REQ_RAT_TYPE_MRDC + UE_CAPA_REQ_RAT_TYPE_EUTRA);
            if (ptCi->stateCmd == RRCConnection_cmd)
            {
                ptCi->ueCapaEnquiry.needEnquiryBitFlag = *needEnquiryBitFlag;
                return FALSE;  // Trigger After Processing is done.
            }
            else
            {
                return TRUE;  // Trigger now
            }
        }
    }

    // CASE C. Check Eutra Capa
    if (TRUE == FnVCCB_NeedUeCapaEnquiryByEutraCapa(ptCi))
    {
        *needEnquiryBitFlag = UE_CAPA_REQ_RAT_TYPE_EUTRA;
        if (ptCi->stateCmd == RRCConnection_cmd)
        {
            ptCi->ueCapaEnquiry.needEnquiryBitFlag = UE_CAPA_REQ_RAT_TYPE_EUTRA;
            return FALSE;  // Trigger After Processing is done.
        }
        else
        {
            return TRUE;  // Trigger now
        }
    }

    return FALSE;
}

int16_t FnVCCB_NeedUeCapaEnquiryByNrCapa(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_FALSE(ptCi->gnbNum, MAX_GNB_PER_SYS);

    /* ========================================================
     * CASE A. NR Capa Validation
     * - If at least one of the following conditions is satisfied, request NR/MR-DC/Eutra Capa again.
     *     A-1) No NR Capa received
     *     A-2) The UE's NR-Capability::supportedBandListNR does not have one Serving PCell Band. (New)
     *     A-3) You do not have an appliedFreqBandList.
     *     A-4) AppliedFreqBandList Validation
     *       - Describe in 'FnVCCB_NeedUeCapaEnquiryByAppliedFreqBandList'
     *     A-5) 'includeNR_DC_present' is missing where the cell that NRDC supported.
     *     A-6) 'includeNE_DC_present' is missing where the cell that NEDC supported.
     *     A-7) 'srsSwitchingTimeRequest_present' is missing where the gNB that srsSwitchingTimeRequest supported.
     *     A-8) 'uplinkTxSwitchRequest_present' is missing where the cell that uplinkTxSwitchRequest supported.
     *     A-9) 'fallbackGroupFiveRequest_r17_present' is missing and FR2 when YANG:fallbackGropuFiveRequest_r17 is ON
    ======================================================== */

    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];
    VccbCellInfo_type *ptCell = &CELLINFO[cellNum];

    // CASE A-1. Check if UE-NR-Capability exist
    if (VCCB_FLAG_OFF == ptCi->ueContainerNR.rxFlag)
    {
        if(ptCi->state == STATE_Est)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE(nr): No NR Capa received\n");
        }
        return TRUE;
    }

    // CASE A-2. Check if NR-Capability::supportedBandListNR include Serving Pcell's Band
    // if there's no matching Serving Pcell's Band in the list, Enquiry again.
    if (BAND_NOT_FOUND == VLIB_GetFreqBandIndForCell(ptCi, ptCell))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE(nr): Not found Serving PCell Band\n");
        return TRUE;
    }

    // BEWARE : DBG only.
    if (DBG->flag.isSkipFilterAppliedFreqBandList != TRUE)
    {
        // CASE A-3. Check if UE-NR-Capability::appliedFreqBandListFilter exist
        // CASE A-4. Compare UE-NR-Capability::appliedFreqBandListFilter to Yang(capability-request-filter)
        if (TRUE == FnVCCB_NeedUeCapaEnquiryByAppliedFreqBandList(ptCi, cellNum, UE_CAPA_REQ_RAT_TYPE_NR))
        {
            return TRUE;
        }
    }

    // CASE A-5. Check if includeNR-DC condition.
    if (TRUE == FnVCCB_NeedNrDcIncludeInUce(ptCi, cellNum))
    {
        if (ptCi->ueInfo.ueCapa.nr.requestFilterCommon.includeNR_DC_present == 0)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE(nr): Not Found 'includeNR_DC'\n");
            return TRUE;
        }
    }

    // CASE A-6. Check if includeNE-DC condition.
    if (IsSupport_NEDC_Foo() && IsSupport_NEDC_Yang(cellNum))
    {
        if (ptCi->ueInfo.ueCapa.nr.requestFilterCommon.includeNE_DC_present == 0)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE(nr): Not Found 'includeNE_DC'\n");
            return TRUE;
        }
    }

    // CASE A-7. Check if srsSwitchingTimeRequest condition per gNB
    if(pGnb->capabilityRequestFilter.uceOptionInfo.srsSwitchingTimeRequest == TRUE)
    {
        if (ptCi->ueInfo.ueCapa.nr.rf.srsSwitchingTimeRequested_present == 0)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE(nr): Not Found 'srsSwitchingTimeRequest'\n");
            return TRUE;
        }
    }

    // CASE A-8. Check if uplinkTxSwitchRequest condition per Cell
    if(ptCell->uceCellOptionInfo.uplinkTxSwitchRequest == TRUE)
    {
        if ((ptCi->ueInfo.ueCapa.nr.requestFilterCommon.uplinkTxSwitchRequest_r16_present == 0) && // No Filter.
            (ptCi->ueInfo.ueCapa.nr.accessStratumRelease >= NRRRC_AccessStratumRelease_rel16  ) && // Rel 16 or higher
            (ptCi->ueInfo.ueCapa.savedInfo.sendUplinkTxSwitchRequest_r16 == 0))   // Not Send        
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE(nr): Not Found 'uplinkTxSwitchRequest'\n");
            return TRUE;
        }
    }

    // CASE A-9. Check if fallbackGroupFiveRequest condition
    if (pGnb->capabilityRequestFilter.uceOptionInfo.fallbackGroupFiveRequest_r17 == VCCB_FLAG_ON)
    {
        // Check: FR2 NR Band (It doesn't need to check UE Version)
        if ((FnVCCB_IsIncludeFr2BandInAppliedFilterOfUeCapa(ptCi, UE_CAPA_REQ_RAT_TYPE_NR) == TRUE) &&
            (ptCi->ueInfo.ueCapa.nr.requestFilterCommon.fallbackGroupFiveRequest_r17_present == VCCB_FLAG_OFF))
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE(nr): Not Found 'fallbackGroupFiveRequest_r17'\n");
            return TRUE;
        }
    }

    return FALSE;
}

int16_t FnVCCB_NeedUeCapaEnquiryByAppliedFreqBandList(callInfo_type *ptCi, uint16_t cellNum, uint8_t ueCapaReqRatType)
{
    AUTO_TRACE_FUNC;

    /* ========================================================
     * A-4) AppliedFreqBandList Validation
     * - If Capa have an appliedFreqBandList and it satisfied with at least one of the following
     *
     *   Cond 1. AppliedFreqBandList does not include all Serving PCell Band. (new)
     *
     *   Cond 2. (NR) YANG 'CapabilityRequestFilter' includes NR Band information.
     *   - No NR Band information is included.
     *
     *   Cond 3. (NR) YANG 'CapabilityRequestFilter' does not have NR Band information. (new)
     *   - No NR Band information in 'gNBINFO.supportFreqBandInfo' is included
     *
     *   Cond 4. (EUTRA) capabilityRequestFilter Yang has Eutra Band Information,
     *   - No CapabilityRequestFilter Yang Eutra Band information is included.
     ======================================================== */

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];

    capabilityRequestFilter_type *pGnbYang = &pGnb->capabilityRequestFilter;
    gnbSupportedBandInfo_type *pGnbLocal = NULL;

    freqBandListFilter_type *pUeApplied = NULL;
    freqBandInfo_type *pCellBand = NULL;

    uint16_t nrIdx, maxNrIdx;
    uint16_t eutraIdx;
    uint16_t appIdx, maxAppIdx, freqIdx;
    uint16_t findFlag = 0;

    ueCapaNrBandReqLimitInfo_type defaultNrBandeqInfo;
    uint16_t nrBandNumInGnbYang = 0;
    uint16_t eutraBandNumInGnbYang = 0;

    // Get UE appliedFreqBandList depending on RAT-TYPE.
    if (ueCapaReqRatType == UE_CAPA_REQ_RAT_TYPE_NR)
    {
        pUeApplied = &ptCi->ueInfo.ueCapa.nr.appliedFreqBandList;
    }
    else
    {
        pUeApplied = &ptCi->ueInfo.ueCapa.mrdc.appliedFreqBandList;
    }
    maxAppIdx = MIN(pUeApplied->num, MAX_FREQBAND_FILTER);

    // CASE A-3. If No appliedFreqBandListFilter of UE, then try new UECapaEnquiry.
    if (pUeApplied->num == 0)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE: No AppliedBandFilterList found \n");
        return TRUE;  // Need New UECapaEnquiry
    }

    // Cond 1. Check if UE-NR-Capability::appliedFreqBandListFilter include Serving Pcell's Band.
    //   => That means All Service Pcell's band should be in appliedFreqBandListFilter.
    for (freqIdx = 0; freqIdx < MAX_FREQBAND_PER_CELL; freqIdx++)
    {
        pCellBand = &pCell->freqBandInfoList[freqIdx];

        if (pCellBand->status != EQUIP) continue;

        // nRFrequencyBand: 1..1024
        if (!pCellBand->nRFrequencyBand || (pCellBand->nRFrequencyBand > MAX_NUM_NR_BAND)) continue;

        findFlag = 0;
        for (appIdx = 0; appIdx < maxAppIdx; appIdx++)
        {
            if ((pUeApplied->band[appIdx].ratType == ci_nr) &&
                (pUeApplied->band[appIdx].band == pCellBand->nRFrequencyBand))
            {
                findFlag++;
                break;
            }
        }
        if (findFlag == 0)  // If Not found, then try new UECapaEnquiry.
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE: [AppliedBandFilterList] Pcell band(%d) mismatch\n", pCellBand->nRFrequencyBand);
            return TRUE;  // Need New UECapaEnquiry
        }
    }

    // Compare UE's appliedFreqBandList with System Configuration
    // Cond 2. (NR) YANG 'CapabilityRequestFilter' includes NR Band information ==>  yang path :
    // capability-request-filter
    for (nrIdx = 0; nrIdx < MAX_REQUEST_FILTER_NR_BAND; nrIdx++)
    {
        if (pGnbYang->bandNR[nrIdx].usage != CI_use) continue;
        nrBandNumInGnbYang++;

        findFlag = 0;
        for (appIdx = 0; appIdx < maxAppIdx; appIdx++)
        {
            if ((pUeApplied->band[appIdx].ratType == ci_nr) &&
                (pUeApplied->band[appIdx].band == pGnbYang->bandNR[nrIdx].band))
            {
                /* Compare nrBandReqLimitInfo */
                if(COMPARE_NRBAND_REQ_LIMIT_INFO(ptCi, pUeApplied->band[appIdx].nrBandReqLimitInfo, pGnbYang->bandNR[nrIdx].nrBandReqLimitInfo))
                {
                    findFlag++;
                    break;
                }
            }
        }
        if (findFlag == 0)  // If Not found, then try new UECapaEnquiry.
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE: [AppliedBandFilterList] bandNR(%d) mismatch\n", pGnbYang->bandNR[nrIdx].band);
            return TRUE;
        }
    }

    // Cond 3. (NR) YANG 'CapabilityRequestFilter' do not includes NR Band information
    // ==>  Using gNB's All Cell band Configuration
    if (nrBandNumInGnbYang == 0)
    {
        // Check the NR Band with internal gNB's supported band.
        // All NR Config should be in appliedFreqBandListFilter.
        FnVCCB_InitUeNrCapaReqAsDefault(defaultNrBandeqInfo);

        pGnbLocal = &pGnb->supportedFreqBandInfo;
        maxNrIdx = MIN(pGnbLocal->num, MAX_FREQBAND_FILTER);
        for (nrIdx = 0; nrIdx < maxNrIdx; nrIdx++)
        {
            // nrFreqBand: 1..1024
            if (!pGnbLocal->nrFreqBand[nrIdx] || (pGnbLocal->nrFreqBand[nrIdx] > MAX_NUM_NR_BAND)) continue;

            findFlag = 0;
            for (appIdx = 0; appIdx < maxAppIdx; appIdx++)
            {
                if ((pUeApplied->band[appIdx].ratType == ci_nr) &&
                    (pUeApplied->band[appIdx].band == pGnbLocal->nrFreqBand[nrIdx]))
                {
                    /* Compare nrBandReqLimitInfo : Bandwidth / Carrier Information*/
                    if(COMPARE_NRBAND_REQ_LIMIT_INFO(ptCi, pUeApplied->band[appIdx].nrBandReqLimitInfo, defaultNrBandeqInfo))
                    {
                        findFlag++;
                        break;
                    }
                }
            }
            if (findFlag == 0)  // If Not found, then try new UECapaEnquiry.
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE: [AppliedBandFilterList] gNB Serving Band(%d) mismatch\n", pGnbLocal->nrFreqBand[nrIdx]);
                return TRUE;
            }
        }
    }

    // Cond 4. (EUTRA-Band) Compare UE's appliedFreqBandList with System Configuration
    for (eutraIdx = 0; eutraIdx < MAX_REQUEST_FILTER_EUTRA_BAND; eutraIdx++)  // 64
    {
        if (pGnbYang->bandEUTRA[eutraIdx].usage != CI_use) continue;
        eutraBandNumInGnbYang++;

        findFlag = 0;
        for (appIdx = 0; appIdx < maxAppIdx; appIdx++)
        {
            if ((pUeApplied->band[appIdx].ratType == ci_eutra) &&
                (pUeApplied->band[appIdx].band == pGnbYang->bandEUTRA[eutraIdx].band))
            {
                if (pGnbYang->bandEUTRA[eutraIdx].bandBlockFlag == VCCB_FLAG_ON)
                {
                    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE: [AppliedBandFilterList] bandEUTRA(idx:%d band:%d) blocked\n",
                        appIdx, pGnbYang->bandEUTRA[eutraIdx].band);
                    return TRUE;
                }

                /* Compare eutraBandReqLimitInfo */
                if(COMPARE_EUTRABAND_REQ_LIMIT_INFO(ptCi, pUeApplied->band[appIdx].eutraBandReqLimitInfo, pGnbYang->bandEUTRA[eutraIdx].eutraBandReqLimitInfo))
                {
                    findFlag++;
                    break;
                }
            }
        }
        if (findFlag == 0)  // If Not found, then try new UECapaEnquiry.
        {
            if (pGnbYang->bandEUTRA[eutraIdx].bandBlockFlag == VCCB_FLAG_OFF)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE: [AppliedBandFilterList] bandEUTRA(%d) mismatch\n", pGnbYang->bandEUTRA[eutraIdx].band);
                return TRUE;
            }
        }
    }

    //  If There is no Yang Configuration of EUTRA, then no Action.
    if (eutraBandNumInGnbYang == 0)
    {
        // No Action
    }

    // Check Device Identification for QC UE
    if ((ueCapaReqRatType == UE_CAPA_REQ_RAT_TYPE_NR) && 
        (TRUE == FnVCCB_NeedNrCapaEnquiryByDeviceIdentification(ptCi)))
    {
        return TRUE;
    }

    return FALSE;
}

int16_t FnVCCB_CheckAndSendUeCapaMessage(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    uint8_t checkSendAmfFlag = VCCB_FLAG_OFF;
    int status;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    // 1. Check if there are more UE Capa which need to enquiry (MRDC / EUTRA)
    if (ptCi->ueCapaEnquiry.needEnquiryBitFlag == UE_CAPA_REQ_RAT_TYPE_NONE)
    {
        checkSendAmfFlag = VCCB_FLAG_ON;
    }
    else  // Send remain Ue Capa.
    {
        status = VCOM_SendNRRRC_UECapabilityEnquiry(ptCi);
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_SendNRRRC_UECapabilityEnquiry ERROR!\n");
            INIT_UE_CAPA_ENQUIRY_NEED_FLAG(ptCi);
            checkSendAmfFlag = VCCB_FLAG_ON;

            // Call Release when segment pool full case.
            if ((ptCi->stateCmd == RRCConnection_cmd) && (ptCi->ueCapaEnquiry.needEnquiryBitFlag & UE_CAPA_REQ_RAT_TYPE_NR))
            {
                MACRO_CALL_FAULT_SAVE(NRRRC_ULDedicatedMessageSegment_id, CauseCpInternalSendF1MessageError);
                return ERROR;
            }
        }
    }

    // 2. If not, send UE Radio Capa Info Indication.
    if (checkSendAmfFlag == VCCB_FLAG_ON)
    {
        // If UE Capa sent,
        if (ptCi->ueCapaEnquiry.sendToAmfFlag == VCCB_FLAG_ON)
        {
            auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_UECapabilityInfoIndicationAllAmf_id);
            VALID_E_POINT_CHECK_RET_VAL(ngapSender, BREAK);
            if (ngapSender->sendMsg() == ERROR)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "sendMsg(NG_UECapabilityInfoIndicationAllAmf) ERROR !!\n");
                return BREAK;
            }
            else
            {
                ptCi->ueCapaEnquiry.sendToAmfFlag = VCCB_FLAG_OFF;
            }

            if ((!IS_FALLBACK_CASE(ptCi)) && (ptCi->numPDUSess != 0) &&
                (TRUE == ptCi->bitFlag.isReceivedNrCapaFlag))
            {
                ptCi->bitFlag.isSCellReconfigRequired = TRUE;
                status = VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_CA_MOD);
                if (ERROR == status)
                {
                    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "VCCM_enqueueAction(ENQUEUE_ACTION_CA_MOD ERROR!\n");
                }
            }
        }
    }

    // Check State Change.
    if (ptCi->ueCapaEnquiry.needEnquiryBitFlag & UE_CAPA_REQ_RAT_TYPE_NR)
    {
        if (ptCi->stateCmd != RRCConnection_cmd)  // For Cell Change.
        {
            VLIB_SetCurStateAll(ptCi, STATE_Conn_UeNrCapa);
        }
    }
    else  // No Need NR
    {
        if (ptCi->state == STATE_Conn_UeNrCapa)
        {
            SET_STATE_CMD(Idle_cmd);
            VLIB_SetCurStateAll(ptCi, STATE_Conn);
            ptCi->needBackupAfterStateAll = VCCB_FLAG_ON; // Need Backup All
        }
    }

    return GOOD;
}

int16_t FnVCCB_UpdateNextUeCapaOperation(callInfo_type *ptCi, uint8_t allStateTimeOutCaseFlag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (allStateTimeOutCaseFlag == VCCB_FLAG_ON)
    {
        // if timeout case, set forcely.
        ptCi->ueCapaEnquiry.rxUeCapaInfoBitFlag = UE_CAPA_REQ_RAT_TYPE_NONE;
    }

    if (ptCi->ueCapaEnquiry.needEnquiryBitFlag == UE_CAPA_REQ_RAT_TYPE_NONE)
    {
        return GOOD;
    }

    if (ptCi->ueCapaEnquiry.needEnquiryBitFlag & UE_CAPA_REQ_RAT_TYPE_NR)
    {
        if (ptCi->ueCapaEnquiry.rxUeCapaInfoBitFlag & UE_CAPA_REQ_RAT_TYPE_NR)
        {
            ptCi->ueCapaEnquiry.sendToAmfFlag = VCCB_FLAG_ON;
            // set next need Flag
            if(TRUE == FnVCCB_IsOnlyNrCapaSupported(ptCi))
            {
                INIT_UE_CAPA_ENQUIRY_NEED_FLAG(ptCi);

                // Check again in case of ptCi->ueInfo.ueCapa.nr.eutraBand.numSupportedBand == 0
                if(ptCi->ueContainerMRDC.rxFlag == VCCB_FLAG_ON)
                {
                    ptCi->ueContainerMRDC.rxFlag  = VCCB_FLAG_OFF;
                    FnVCCB_FreeUeCapabilityInfoPerRatType(ptCi, UE_MRDC_Capability);
                    ptCi->ueInfo.ueCapa.mrdc.appliedFreqBandList.num = 0;
                    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "MRDC Capa is removed by Only NR Capa\n");
                }
                if(ptCi->ueContainerEUTRA.rxFlag == VCCB_FLAG_ON)
                {
                    ptCi->ueContainerEUTRA.rxFlag = VCCB_FLAG_OFF;
                    FnVCCB_FreeUeCapabilityInfoPerRatType(ptCi, UE_EUTRA_Capability);
                    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Eutra Capa is removed by Only NR Capa\n");
                }                
            }
            else if(IS_REDCAP_UE(ptCi))
            {
                ptCi->ueCapaEnquiry.needEnquiryBitFlag = UE_CAPA_REQ_RAT_TYPE_EUTRA;
            }
            else if(TRUE == FnVCCB_IsOnlyNrEutraCapaSupported(ptCi))
            {
                if(FnVCCB_IsCellAndUeSupportNrHoToEndcR16(ptCi, ptCi->servCellNum))
                {
                    ptCi->ueCapaEnquiry.needEnquiryBitFlag = (UE_CAPA_REQ_RAT_TYPE_MRDC + UE_CAPA_REQ_RAT_TYPE_EUTRA);
                }
                else
                {
                    ptCi->ueCapaEnquiry.needEnquiryBitFlag = UE_CAPA_REQ_RAT_TYPE_EUTRA;
                }
            }            
            else
            {
                ptCi->ueCapaEnquiry.needEnquiryBitFlag = (UE_CAPA_REQ_RAT_TYPE_MRDC + UE_CAPA_REQ_RAT_TYPE_EUTRA);
            }

            if (STATE_E2C_capa != ptCi->state)
            {
                ON_UECAPA_NEED_FWD_FLAG(ptCi->flag.setupFlag);  // For forwarding "NR UE Capa" to DU.
            }
            // Don't need to update ptCi->ueCapaEnquiry.needEnqurity3Step. FillNRRRC_UE_CapabilityRAT_RequestList() will
            // do.

            // Check UeCapaCheckResponse.
            if(ptCi->bitFlag.needToSendUeCapaCheckResponse)
            {
                auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_UERadioCapabilityCheckResponseAllAmf_id);
                if (ngapSender == nullptr || ERROR == ngapSender->sendMsg())
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "sendMsg(NG_UERadioCapabilityCheckResponseAllAmf) ERROR!\n");
                }
            }
        }
        else  // Time out or Not RX UE_CAPA_REQ_RAT_TYPE_NR ==> Stop UCE.
        {
            // For NR-CAPA, If not RX in InitialUeContextRequest  -> release Call
            //              If timeout in InitialUeContextRequest -> release Call (It's handdled in STATE_E2C_capa, not
            //              here) If not RX in all state              -> Stop UCE. If timeout in all state -> Stop UCE
            INIT_UE_CAPA_ENQUIRY_NEED_FLAG(ptCi);
            if (allStateTimeOutCaseFlag)
            {
                return GOOD;
            }
            else  // RX CAPA but Not Matched UE Capa.
            {
                if (STATE_E2C_capa == ptCi->state)  // InitialContextRequest
                {
                    return ERROR;
                }
                else
                {
                    return GOOD;
                }
            }
        }
    }
    else if (ptCi->ueCapaEnquiry.needEnquiryBitFlag & UE_CAPA_REQ_RAT_TYPE_MRDC)
    {
        if (ptCi->ueCapaEnquiry.needEnqurity3Step == VCCB_FLAG_OFF)  // 2 Step
        {
            if ((ptCi->ueCapaEnquiry.rxUeCapaInfoBitFlag & UE_CAPA_REQ_RAT_TYPE_MRDC) ||
                (ptCi->ueCapaEnquiry.rxUeCapaInfoBitFlag & UE_CAPA_REQ_RAT_TYPE_EUTRA))
            {
                ptCi->ueCapaEnquiry.sendToAmfFlag = VCCB_FLAG_ON;
                INIT_UE_CAPA_ENQUIRY_NEED_FLAG(ptCi);
                if(ptCi->ueCapaEnquiry.rxUeCapaInfoBitFlag & UE_CAPA_REQ_RAT_TYPE_MRDC)
                {
                    ON_UECAPA_NEED_FWD_FLAG(ptCi->flag.setupFlag); // For forwarding 'NR UE Capa'
                }
            }
            else
            {
                if (allStateTimeOutCaseFlag)
                {
                    ptCi->ueCapaEnquiry.needEnquiryBitFlag = UE_CAPA_REQ_RAT_TYPE_NONE;
                    return GOOD;
                }
                else  // RX CAPA but Not Matched UE Capa.
                {
                    // Keep ueCapaEnquiry.needEnquiryBitFlag.
                    // It maybe wrong response..  // Waiting Timeout or another UE Capa.
                    return BREAK;
                }
            }
        }
        else  // 3 Step
        {
            if (ptCi->ueCapaEnquiry.rxUeCapaInfoBitFlag & UE_CAPA_REQ_RAT_TYPE_MRDC)
            {
                ptCi->ueCapaEnquiry.sendToAmfFlag = VCCB_FLAG_ON;
                ptCi->ueCapaEnquiry.needEnquiryBitFlag = UE_CAPA_REQ_RAT_TYPE_EUTRA;
                ON_UECAPA_NEED_FWD_FLAG(ptCi->flag.setupFlag);
            }
            else
            {
                if (allStateTimeOutCaseFlag)
                {
                    // Do Next Step.
                    ptCi->ueCapaEnquiry.needEnquiryBitFlag = UE_CAPA_REQ_RAT_TYPE_EUTRA;
                    return GOOD;
                }
                else  // RX CAPA but Not Matched RX Capa.
                {
                    // Keep ueCapaEnquiry.needEnquiryBitFlag.
                    // It maybe wrong response..  // Waiting Timeout or another UE Capa.
                    return BREAK;
                }
            }
        }
    }
    else if (ptCi->ueCapaEnquiry.needEnquiryBitFlag & UE_CAPA_REQ_RAT_TYPE_EUTRA)  // 2 Setp or 3 Step.
    {
        if (ptCi->ueContainerEUTRA.rxFlag == VCCB_FLAG_ON)
        {
            ptCi->ueCapaEnquiry.sendToAmfFlag = VCCB_FLAG_ON;
        }
        INIT_UE_CAPA_ENQUIRY_NEED_FLAG(ptCi);
    }

    return GOOD;
}

int16_t FnVCCB_BackupCapabilityInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    if (NULL == ptCi)
    {
        VCCB_PRINT_ERROR("%s: NULL pointer \n", __FUNCTION__);
        return ERROR;
    }

    unsigned long syncSize = 0;
    uint32_t dataSize = 0;

    // SRB Info
    syncSize = sizeof(callSRBInfo_type) * (MAX_SRB_PER_CALL);
    HAS_BACKUP_DATA_CALL_PARTIAL(ptCi, &ptCi->srbInfo[0], syncSize);

    // UE Capa Info
    if ((ptCi->ueCapaEnquiry.rxUeCapaInfoBitFlag & UE_CAPA_REQ_RAT_TYPE_NR) ||
        (ptCi->ueCapaEnquiry.rxUeCapaInfoBitFlag & UE_CAPA_REQ_RAT_TYPE_MRDC))
    {
        syncSize = sizeof(ptCi->ueInfo);
        HAS_BACKUP_DATA_CALL_PARTIAL(ptCi, &ptCi->ueInfo, syncSize);
    }

    // Packed Data
    if (ptCi->ueCapaEnquiry.rxUeCapaInfoBitFlag & UE_CAPA_REQ_RAT_TYPE_NR)
    {
        syncSize = (char *)(&ptCi->ueContainerNR.data[0]) - (char *)&ptCi->ueContainerNR;
        dataSize = UMIN((ptCi->ueContainerNR.numocts * sizeof(uint8_t)), MAX_UE_CAPA_ONE_RAT_LENGTH);
        syncSize += dataSize;

        HAS_BACKUP_DATA_CALL_PARTIAL(ptCi, &ptCi->ueContainerNR, syncSize);
    }
    if (ptCi->ueCapaEnquiry.rxUeCapaInfoBitFlag & UE_CAPA_REQ_RAT_TYPE_MRDC)
    {
        syncSize = (char *)(&ptCi->ueContainerMRDC.data[0]) - (char *)&ptCi->ueContainerMRDC;
        dataSize = UMIN((ptCi->ueContainerMRDC.numocts * sizeof(uint8_t)), MAX_UE_CAPA_ONE_RAT_LENGTH);
        syncSize += dataSize;

        HAS_BACKUP_DATA_CALL_PARTIAL(ptCi, &ptCi->ueContainerMRDC, syncSize);
    }
    if (ptCi->ueCapaEnquiry.rxUeCapaInfoBitFlag & UE_CAPA_REQ_RAT_TYPE_EUTRA)
    {
        syncSize = (char *)(&ptCi->ueContainerEUTRA.data[0]) - (char *)&ptCi->ueContainerEUTRA;
        dataSize = UMIN((ptCi->ueContainerEUTRA.numocts * sizeof(uint8_t)), MAX_UE_CAPA_ONE_RAT_LENGTH);
        syncSize += dataSize;

        HAS_BACKUP_DATA_CALL_PARTIAL(ptCi, &ptCi->ueContainerEUTRA, syncSize);
    }

    return GOOD;
}

void FnVCCB_FreeUeCapabilityInfoPerRatType(callInfo_type *ptCi, enumSegmentPdu_type ratType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    ueCapabilitiesRATcontainer_type *pContainer = NULL;
    extUeCapaInfo_type *pContainerExt = NULL;

    // typedef enum
    // {
    //     UL_DCCH_Message = 0,
    //     UE_NR_Capability,
    //     UE_MRDC_Capability,
    //     UE_EUTRA_Capability,
    //     UNKNOWN_SEGMENT_PDU_TYPE
    // } enumSegmentPdu_type;

    // Handle both of packed/unpacked ueContainerXX_Ext buffer (nr, eutra_nr, eutra)
    switch (ratType)
    {
        case UE_NR_Capability:
            pContainer = &ptCi->ueContainerNR;
            pContainerExt = &ptCi->ueContainerNR_Ext;
            break;

        case UE_MRDC_Capability:
            pContainer = &ptCi->ueContainerMRDC;
            pContainerExt = &ptCi->ueContainerMRDC_Ext;
            break;

        case UE_EUTRA_Capability:
            pContainer = &ptCi->ueContainerEUTRA;
            pContainerExt = &ptCi->ueContainerEUTRA_Ext;
            break;

        case UL_DCCH_Message:
            pContainer = NULL;
            pContainerExt = &ptCi->ulRrcSegment;
            break;

        default:
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_StoreUeCapabilityContainer ratType Error(ratType : %d)!\n", ratType);
            return;
    }

    // 1. Normal Capa
    if (pContainer != NULL)
    {
        pContainer->numocts = 0;
        pContainer->isBigCapaFlag = VCCB_FLAG_OFF;
    }

    // 2. Big Capa
    FnVCCB_FreeExtUeCapaInfo(ptCi, pContainerExt);
    return;
}

int16_t FnVCCB_NeedUeCapaEnquiryByMrDcCapa(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_FALSE(ptCi->gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];
    VccbCellInfo_type *ptCell = &CELLINFO[cellNum];

    // CASE A-1. Check if Only NR Capa Supported.
    if (TRUE == FnVCCB_IsOnlyNrCapaSupported(ptCi))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Skip MRDC/Eutra Capa Enquiry(nr only mode)\n");
        return FALSE;
    }

    // CASE A-1-2. Check if RedCapa UE.
    if(IS_REDCAP_UE(ptCi))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Skip MRDC Capa Enquiry(RedCap UE)\n");
        return FALSE;
    }

    // CASE A-1-1. Check if only NR Eutra Capa Supported.
    if (TRUE == FnVCCB_IsOnlyNrEutraCapaSupported(ptCi))
    {
        // In NR_AND_EUTRA Mode.
        // If Cell and UeCapa is supported, then keep going to check MR-DC Capa
        // If Ue has the history for sending MR-DC, then keep going to check MR-DC Capa
        if(ptCi->ueInfo.ueCapa.savedInfo.sendMrdcCapaInNrEutraMode || FnVCCB_IsCellAndUeSupportNrHoToEndcR16(ptCi, cellNum))
        {
            // Not Return, Keep Going to check Validation
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Continue to check MR-DC Capa by Config or SendHistory\n");
        }
        else
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Skip MRDC Capa Enquiry(nr eutra only mode)\n");
            return FALSE;
        }
    }

    // CASE A-2. Check if UE-MR-Capability exist
    if (VCCB_FLAG_OFF == ptCi->ueContainerMRDC.rxFlag)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE(mrdc): No MRDC Capa received\n");
        return TRUE;
    }

    // CASE A-3. Check if includeNE-DC condition.
    if (IsSupport_NEDC_Foo() && IsSupport_NEDC_Yang(cellNum))
    {
        if (ptCi->ueInfo.ueCapa.mrdc.requestFilterCommon.includeNE_DC_present == 0)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE(mrdc): 'includeNE_DC' is not present\n");
            return TRUE;
        }
    }

    // CASE A-4. Check if srsSwitchingTimeRequest condition per gNB
    if(pGnb->capabilityRequestFilter.uceOptionInfo.srsSwitchingTimeRequest == TRUE)
    {
        if (ptCi->ueInfo.ueCapa.mrdc.rf.srsSwitchingTimeRequested_present == 0)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE(mrdc): 'srsSwitchingTimeRequest' is not present\n");
            return TRUE;
        }
    }

    // CASE A-5. Check if uplinkTxSwitchRequest condition per Cell
    if(ptCell->uceCellOptionInfo.uplinkTxSwitchRequest == TRUE)
    {
        if ((ptCi->ueInfo.ueCapa.mrdc.requestFilterCommon.uplinkTxSwitchRequest_r16_present == 0) && // No Filter
            (ptCi->ueInfo.ueCapa.nr.accessStratumRelease >= NRRRC_AccessStratumRelease_rel16    ) && // Rel 16 or higher
            (ptCi->ueInfo.ueCapa.savedInfo.sendUplinkTxSwitchRequest_r16 == 0))   // Not Send
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE(mrdc): 'uplinkTxSwitchRequest_r16' is not present\n");
            return TRUE;
        }
    }

    // CASE A-6. Check if fallbackGroupFiveRequest condition
    if (pGnb->capabilityRequestFilter.uceOptionInfo.fallbackGroupFiveRequest_r17 == VCCB_FLAG_ON)
    {
        // Check: FR2 NR Band (It doesn't need to check UE Version)
        if ((FnVCCB_IsIncludeFr2BandInAppliedFilterOfUeCapa(ptCi, UE_CAPA_REQ_RAT_TYPE_MRDC) == TRUE) &&
            (ptCi->ueInfo.ueCapa.mrdc.requestFilterCommon.fallbackGroupFiveRequest_r17_present == VCCB_FLAG_OFF))
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE(mrdc): Not Found 'fallbackGroupFiveRequest_r17'\n");
            return TRUE;
        }
    }

    return FALSE;
}

int16_t FnVCCB_NeedUeCapaEnquiryByEutraCapa(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    // CASE A-1. Check if Only NR Capa Supported.
    if (TRUE == FnVCCB_IsOnlyNrCapaSupported(ptCi))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Skip EUTRA Capa Enquiry(nr only mode)\n");
        return FALSE;
    }

    // CASE A-2. Check if Eutra-Capability exist
    if (VCCB_FLAG_OFF == ptCi->ueContainerEUTRA.rxFlag)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE(eutra): No EUTRA Capa received\n");        
        return TRUE;
    }

    return FALSE;
}

int16_t FnVCCB_IsOnlyNrCapaSupported(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    // CASE A-1. Check if Only NR Capa Need.
    if(ptCi->ueInfo.ueCapa.savedInfo.uceRatSupportType == YANG_UE_CAPA_REQ_ONLY_NR)
    {
        return TRUE;
    }

    if((ptCi->ueContainerNR.rxFlag) && (ptCi->ueInfo.ueCapa.nr.eutraBand.numSupportedBand == 0))
    {
        return TRUE;
    }

    return FALSE;
}

void FnVCCB_CheckAndClearUeCapaByEnquiryBit(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // If need NR capa, then clear MR-DC capa for consistency
    if (ptCi->ueCapaEnquiry.needEnquiryBitFlag & UE_CAPA_REQ_RAT_TYPE_NR)
    {
        if(ptCi->ueContainerMRDC.rxFlag == ON)
        {
            ptCi->ueContainerMRDC.rxFlag = VCCB_FLAG_OFF;
            FnVCCB_FreeUeCapabilityInfoPerRatType(ptCi, UE_MRDC_Capability);
        }
    }

    // If NE-DC is ON, If need NR or MR-DC Capa, clear Eutra Capa for consistency
    if (ptCi->ueCapaEnquiry.needEnquiryBitFlag)
    {
        if (IsSupport_NEDC_Foo() && IsSupport_NEDC_Yang(ptCi->servCellNum))
        {
            if(ptCi->ueContainerEUTRA.rxFlag == ON)
            {
                ptCi->ueContainerEUTRA.rxFlag = VCCB_FLAG_OFF;
                FnVCCB_FreeUeCapabilityInfoPerRatType(ptCi, UE_EUTRA_Capability);
            }
        }
    }

    return;
}

void FnVCCB_PrintAppliedFreqBandList(callInfo_type* ptCi, NRRRC_RAT_Type ratType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    std::string strRat, strBandNR, strBandEUTRA;
    freqBandListFilter_type* pBandList = NULL;

    switch(ratType)
    {
        case NRRRC_RAT_Type_nr:
            pBandList = &ptCi->ueInfo.ueCapa.nr.appliedFreqBandList;
            strRat.append("NR");
            break;
        case NRRRC_RAT_Type_eutra_nr:
            pBandList = &ptCi->ueInfo.ueCapa.mrdc.appliedFreqBandList;
            strRat.append("MRDC");
            break;
        default : // ETC
            return;
    }    

    for(int loop = 0; loop < pBandList->num; loop++)
    {
        if(pBandList->band[loop].ratType == ci_eutra)
        {
            std::string bandNum = "[" + std::to_string(pBandList->band[loop].band) + "]";
            strBandEUTRA.append(bandNum);
        }
        else
        {
            std::string bandNum = "[" + std::to_string(pBandList->band[loop].band) + "]";
            strBandNR.append(bandNum);
        }
    }

    if(strBandNR.empty())
    {
        strBandNR.append("[-]");
    }

    if(strBandEUTRA.empty())
    {
        strBandEUTRA.append("[-]");
    }    
    
    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[%s] Capa | BandFilterInfo: NR%s, EUTRA%s\n", strRat.c_str(), strBandNR.c_str(), strBandEUTRA.c_str());    
}


/**
 * @brief Check appliedFreqBandList and clear ueContainerMRDC_Flag if required
 * @param [in] pointer of callInfo_type
 * @return GOOD/BREAK/ERROR
 */
void VCCM_DiffandArrangeAppliedFilter(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    freqBandListFilter_type *pNr = &ptCi->ueInfo.ueCapa.nr.appliedFreqBandList;
    freqBandListFilter_type *pMrdc = &ptCi->ueInfo.ueCapa.mrdc.appliedFreqBandList;

    uint16_t appIdx, maxAppIdx;
    uint16_t diffFlag = 0;

    std::string cause;

    // 1. Check number
    if (pNr->num != pMrdc->num)
    {
        diffFlag++;
    }
    // 2. Check NR and EUTRA Band
    else
    {
        maxAppIdx = MIN(pNr->num, MAX_FREQBAND_FILTER);
        for (appIdx = 0; appIdx < maxAppIdx; appIdx++)
        {
            // 2.1. diff ratType
            if ((pNr->band[appIdx].ratType != pMrdc->band[appIdx].ratType) ||
                (pNr->band[appIdx].band != pMrdc->band[appIdx].band))
            {
                diffFlag++;
                break;
            }
            // 2.2. diff BandReqLimitInfo
            if (pNr->band[appIdx].ratType == ci_nr)
            {
                if ((pNr->band[appIdx].nrBandReqLimitInfo.maxBandwidthRequestedDl !=
                        pMrdc->band[appIdx].nrBandReqLimitInfo.maxBandwidthRequestedDl) ||
                    (pNr->band[appIdx].nrBandReqLimitInfo.maxBandwidthRequestedUl !=
                        pMrdc->band[appIdx].nrBandReqLimitInfo.maxBandwidthRequestedUl) ||
                    (pNr->band[appIdx].nrBandReqLimitInfo.maxCarriersRequestedDl !=
                        pMrdc->band[appIdx].nrBandReqLimitInfo.maxCarriersRequestedDl) ||
                    (pNr->band[appIdx].nrBandReqLimitInfo.maxCarriersRequestedUl !=
                        pMrdc->band[appIdx].nrBandReqLimitInfo.maxCarriersRequestedUl))
                {
                    diffFlag++;
                    break;
                }
            }
            else if (pNr->band[appIdx].ratType == ci_eutra)
            {
                if ((pNr->band[appIdx].eutraBandReqLimitInfo.caBandwidthClassDlEutra !=
                        pMrdc->band[appIdx].eutraBandReqLimitInfo.caBandwidthClassDlEutra) ||
                    (pNr->band[appIdx].eutraBandReqLimitInfo.caBandwidthClassUlEutra !=
                        pMrdc->band[appIdx].eutraBandReqLimitInfo.caBandwidthClassUlEutra))
                {
                    diffFlag++;
                    break;
                }
            }
        }
    }

    // 3. If different, clear MRDC Capa.
    if (diffFlag)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "'AppliedBandlistFilter' in NR and MRDC are not matched. Enquiry new MRDC Capa again with NR 'appliedBandFilter'\n");
        FnVCCB_PrintAppliedFreqBandList(ptCi, NRRRC_RAT_Type_nr);
        FnVCCB_PrintAppliedFreqBandList(ptCi, NRRRC_RAT_Type_eutra_nr);        

        ptCi->ueContainerMRDC.rxFlag = VCCB_FLAG_OFF;
        FnVCCB_FreeUeCapabilityInfoPerRatType(ptCi, UE_MRDC_Capability);
        pMrdc->num = 0;
    }
    return;
}

// this operation will be handled as best effort
void FnVCCB_Finalize_UeCapaEnquiryIfNeeded_ForSA(callInfo_type *ptCi, uint16_t cellNum, uint8_t queueingOption)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t needEnquiryBitFlag = 0;

    if (ptCi->callType == E_CALLTYPE_NSA || IS_NRDC_SN(ptCi))
    {
        return;
    }

    if (FnVCCB_NeedUeCapaEnquiry(ptCi, cellNum, &needEnquiryBitFlag) == TRUE)
    {
        if ((queueingOption == VCCB_FLAG_ON) && (needEnquiryBitFlag & UE_CAPA_REQ_RAT_TYPE_NR))
        {
            // Enqueueing.
            if (VLIB_EnqueueUeCapaEnquiry(ptCi) != GOOD)
            {
                // if Queueing Failure happens, Keep going current state (No Action)
            }
        }
        else
        {
            ptCi->ueCapaEnquiry.needEnquiryBitFlag = needEnquiryBitFlag;
            // Clear RX UE Capa(MR-DC, Eutra) depending on the condition before UCE
            FnVCCB_CheckAndClearUeCapaByEnquiryBit(ptCi);

            if (GOOD == FnVCCB_CheckAndSendUeCapaMessage(ptCi))
            {
                if (needEnquiryBitFlag & UE_CAPA_REQ_RAT_TYPE_NR)
                {
                    SET_SUPPORT_NRDC_UECAPA(ptCi, VCCB_FLAG_OFF);
                    VCCB_PRINT_CALL_DATA(ptCi, "reset SUPPORT_NRDC_UECAPA !\n");
                }
                VCCB_PRINT_CALL_DATA(ptCi, "triggered UECapabilityEnquiry newly!\n");
            }
        }
    }
}

void FnVCCB_ParseUECapabilityEnquiry_RAT_Type_NR_MRDC(msgUnpack_type *pUnpack, NRRRC_UE_CapabilityRAT_RequestList_* pRatItem, NRRRC_UECapabilityEnquiry_IEs *p, CapaEnquiryInfo_type* pParseInfo)
{
    VALID_E_POINT_CHECK_VOID(p);
    VALID_E_POINT_CHECK_VOID(pParseInfo);

    int16_t status = GOOD;
    RatRequestList_type* ratInfo = &pParseInfo->CapaRatRequestList[pParseInfo->numRat];
    ratInfo->usage = EQUIP;
    ratInfo->ratType = (int)pRatItem->value.rat_Type;    

    status = UnpackNRRRC_UE_CapabilityRequestFilter_NR_PDU(pUnpack, pRatItem->value.capabilityRequestFilter.value, pRatItem->value.capabilityRequestFilter.length);
    if(status != GOOD) return;
    
    NRRRC_UE_CapabilityRequestFilterNR *ptCapaFilter = (NRRRC_UE_CapabilityRequestFilterNR*)(&pUnpack->unpack[0] + pUnpack->unpackMsgOffset);

    // srs_switchingTimeRequest (O)
    if(ptCapaFilter->nonCriticalExtension.bit_mask & NRRRC_srs_SwitchingTimeRequest_present)
    {
        ratInfo->srsSwitchingTimeRequest_present = TRUE;
    }                

    // NRRRC_FreqBandList (O)
    if(ptCapaFilter->bit_mask & NRRRC_frequencyBandListFilter_present)
    {
        struct NRRRC_FreqBandList_ * pFreqBandInfo = ptCapaFilter->frequencyBandListFilter;
        while(pFreqBandInfo != NULL)
        {
            //ratInfo->srsSwitchingTimeRequest_present = pFreqBandInfo->value
            if(pFreqBandInfo->value.choice == NRRRC_bandInformationNR_chosen)
            {
                ratInfo->bandList.bandNR[ratInfo->bandList.numNR++] = pFreqBandInfo->value.u.bandInformationNR.bandNR;
                // TBA : 
                // pFreqBandInfo->value.u.bandInformationNR.maxBandwidthRequestedDL
                // pFreqBandInfo->value.u.bandInformationNR.maxBandwidthRequestedUL
                // pFreqBandInfo->value.u.bandInformationNR.maxCarriersRequestedDL
                // pFreqBandInfo->value.u.bandInformationNR.maxCarriersRequestedUL
            }
            else // NRRRC_bandInformationEUTRA_chosen
            {
                ratInfo->bandList.bandEUTRA[ratInfo->bandList.numEUTRA++] = pFreqBandInfo->value.u.bandInformationEUTRA.bandEUTRA;
                // TBA :
                // pFreqBandInfo->value.u.bandInformationEUTRA.ca_BandwidthClassDL_EUTRA
                // pFreqBandInfo->value.u.bandInformationEUTRA.ca_BandwidthClassUL_EUTRA
            }
            pFreqBandInfo = pFreqBandInfo->next;
        }
    }
}

void FnVCCB_ParseUECapabilityEnquiry_RAT_Type_EUTRA(msgUnpack_type *pUnpack, NRRRC_UE_CapabilityRAT_RequestList_* pRatItem, NRRRC_UECapabilityEnquiry_IEs *p, CapaEnquiryInfo_type* pParseInfo)
{
    VALID_E_POINT_CHECK_VOID(p);
    VALID_E_POINT_CHECK_VOID(pParseInfo);

    int16_t status = GOOD;
    RatRequestList_type* ratInfo = &pParseInfo->CapaRatRequestList[pParseInfo->numRat];
    ratInfo->usage = EQUIP;
    ratInfo->ratType = (int)pRatItem->value.rat_Type;    

    // eutra capa filter
    status =  fnRRC_Unpack_UECapabilityEnquiry_PDU(pUnpack, (char*)pRatItem->value.capabilityRequestFilter.value, (int)pRatItem->value.capabilityRequestFilter.length);
    if(status != GOOD) return;

    RRC_UECapabilityEnquiry *ptRrcCapaFilter = (RRC_UECapabilityEnquiry*)(&pUnpack->unpack[0] + pUnpack->unpackMsgOffset);
    // requestedFrequencyBands-r11
    if(ptRrcCapaFilter->criticalExtensions.choice == RRC_UECapabilityEnquiry_criticalExtensions_c1_chosen)
    {
        if(ptRrcCapaFilter->criticalExtensions.u.c1.choice == RRC_ueCapabilityEnquiry_r8_chosen)
        {
            if(ptRrcCapaFilter->criticalExtensions.u.c1.u.ueCapabilityEnquiry_r8.bit_mask & RRC_UECapabilityEnquiry_r8_IEs_nonCriticalExtension_present)
            {
                RRC_UECapabilityEnquiry_v8a0_IEs* rrc_v8a0 = &ptRrcCapaFilter->criticalExtensions.u.c1.u.ueCapabilityEnquiry_r8.nonCriticalExtension;
                if(rrc_v8a0->bit_mask & RRC_UECapabilityEnquiry_v8a0_IEs_nonCriticalExtension_present)
                {
                    RRC_UECapabilityEnquiry_v1180_IEs* rrc_v1180 = &rrc_v8a0->nonCriticalExtension;
                    if(rrc_v1180->bit_mask & RRC_UECapabilityEnquiry_v1180_IEs_nonCriticalExtension_present)
                    {
                        RRC_UECapabilityEnquiry_v1310_IEs* rrc_v1310 = &rrc_v1180->nonCriticalExtension;
                        if(rrc_v1310->bit_mask & RRC_UECapabilityEnquiry_v1310_IEs_nonCriticalExtension_present)
                        {
                            RRC_UECapabilityEnquiry_v1430_IEs* rrc_v1430 = &rrc_v1310->nonCriticalExtension;
                            if(rrc_v1430->bit_mask & RRC_UECapabilityEnquiry_v1430_IEs_nonCriticalExtension_present)
                            {
                                RRC_UECapabilityEnquiry_v1510_IEs* rrc_v1510 = &rrc_v1430->nonCriticalExtension;
                                if(rrc_v1510->bit_mask & RRC_requestedFreqBandsNR_MRDC_r15_present)
                                {
                                    UnpackNRRRC_FreqBandList(pUnpack, rrc_v1510->requestedFreqBandsNR_MRDC_r15.value, rrc_v1510->requestedFreqBandsNR_MRDC_r15.length);
                                    //struct NRRRC_FreqBandList_ *pBandList = (struct NRRRC_FreqBandList_*)(&pUnpack->unpack[0] + pUnpack->unpackMsgOffset);
                                    NRRRC_FreqBandList* pBandList = (NRRRC_FreqBandList *)((unsigned char *) pUnpack->unpack + pUnpack->unpackMsgOffset);

                                    while(*pBandList != NULL)
                                    {
                                        if((*pBandList)->value.choice == NRRRC_bandInformationNR_chosen)
                                        {
                                            ratInfo->bandList.bandNR[ratInfo->bandList.numNR++] = (*pBandList)->value.u.bandInformationNR.bandNR;
                                        }
                                        else
                                        {
                                            ratInfo->bandList.bandEUTRA[ratInfo->bandList.numEUTRA++] = (*pBandList)->value.u.bandInformationEUTRA.bandEUTRA;
                                        }
                                        *pBandList = (*pBandList)->next;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }    
}

void FnVCCB_ParseUECapabilityEnquiry_Extensions_v1560(NRRRC_UECapabilityEnquiry_IEs *p, CapaEnquiryInfo_type* pParseInfo)
{
    VALID_E_POINT_CHECK_VOID(p);
    VALID_E_POINT_CHECK_VOID(pParseInfo);

    pParseInfo->capaEnquiryExt_present = TRUE;
    NRRRC_UECapabilityEnquiry_v1560_IEs* pUceExt = p->ue_CapabilityEnquiryExt.decoded;
    // UnpackNRRRC_UE_CapabilityEnquiry_v1560_PDU(pUnpack, p->ue_CapabilityEnquiryExt.encoded.value, p->ue_CapabilityEnquiryExt.encoded.length);
    // NRRRC_UECapabilityEnquiry_v1560_IEs *pUceExt = (NRRRC_UECapabilityEnquiry_v1560_IEs*)(&pUnpack->unpack[0] + pUnpack->unpackMsgOffset);

    if(pUceExt->bit_mask & NRRRC_capabilityRequestFilterCommon_present)
    {
        // NRRRC_UE_CapabilityRequestFilterCommon
        if(pUceExt->capabilityRequestFilterCommon.bit_mask & NRRRC_mrdc_Request_present)
        {
            pParseInfo->CapaEnquiryExt.mrdcRequest_present = TRUE;
        }
        if(pUceExt->capabilityRequestFilterCommon.bit_mask & NRRRC_codebookTypeRequest_r16_present)
        {
            pParseInfo->CapaEnquiryExt.codebookTypeRequest_present = TRUE;
        }
        if(pUceExt->capabilityRequestFilterCommon.bit_mask & NRRRC_uplinkTxSwitchRequest_r16_present)
        {
            pParseInfo->CapaEnquiryExt.uplinkTxSwitchRequest_present = TRUE;
        }
        if(pUceExt->capabilityRequestFilterCommon.bit_mask & NRRRC_requestedCellGrouping_r16_present)
        {
            pParseInfo->CapaEnquiryExt.requestCellGrouping_present = TRUE;
        }           
    }             

    if(pUceExt->bit_mask & NRRRC_UECapabilityEnquiry_v1610_IEs_nonCriticalExtension_present)
    {
        // NRRRC_UECapabilityEnquiry_v1610_IEs
        if(pUceExt->nonCriticalExtension.bit_mask & NRRRC_rrc_SegAllowed_r16_present)
        {
            pParseInfo->CapaEnquiryExt.rrcSegAllowedR16_present = TRUE;
        }
    }    
}

void FnVCCB_ParseUECapabilityEnquiry_ForDebug(callInfo_type* ptCi, NRRRC_UECapabilityEnquiry* ptIE, CapaEnquiryInfo_type* pParseInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptIE);
    VALID_E_POINT_CHECK_VOID(pParseInfo);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    msgUnpack_type *pUnpackBuf = &THREAD_INFO->call[ptCi->myThreadId].buf.unpack.debug;

    NRRRC_UECapabilityEnquiry_IEs *p = &ptIE->criticalExtensions.u.ueCapabilityEnquiry;
    NRRRC_UE_CapabilityRAT_RequestList_* pRatItem = p->ue_CapabilityRAT_RequestList;

    for( ;pRatItem != NULL; pRatItem = pRatItem->next, pParseInfo->numRat++)
    {
        if(pRatItem->value.capabilityRequestFilter.value== NULL) continue;
        if (!(pRatItem->value.bit_mask & NRRRC_capabilityRequestFilter_present)) continue;

        if((pRatItem->value.rat_Type == NRRRC_RAT_Type_nr) || (pRatItem->value.rat_Type == NRRRC_RAT_Type_eutra_nr)) // RAT type: NR or EUTRA-NR
        {
            FnVCCB_ParseUECapabilityEnquiry_RAT_Type_NR_MRDC(pUnpackBuf, pRatItem, p, pParseInfo);
        }
        else // RAT type: EUTRA
        {
             FnVCCB_ParseUECapabilityEnquiry_RAT_Type_EUTRA(pUnpackBuf, pRatItem, p,  pParseInfo);
        }
    }
        
    // Extension (UECapabilityEnquiry-v1560-IEs)
    if(p->bit_mask & NRRRC_ue_CapabilityEnquiryExt_present)
    {
        FnVCCB_ParseUECapabilityEnquiry_Extensions_v1560(p,  pParseInfo);
    }       
}

void FnVCCB_PrintUECapabilityEnquiry_ForDebug(callInfo_type* ptCi, CapaEnquiryInfo_type* pDbgInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pDbgInfo);

    // ue-CapabilityRAT-RequestList
    for(int loop = 0; loop < pDbgInfo->numRat; loop++)
    {
        std::string strRat, strBandNR, strBandEUTRA;
        RatRequestList_type* pRatItem = &pDbgInfo->CapaRatRequestList[loop];
        if(pRatItem->usage == N_EQUIP) continue;

        switch(pRatItem->ratType)
        {
            case NRRRC_RAT_Type_nr:
                strRat.append("NR");
                break;
            case NRRRC_RAT_Type_eutra_nr:
                strRat.append("MRDC");
                break;
            case NRRRC_RAT_Type_eutra:
                strRat.append("EUTRA");
                break;
            default :
                strRat.append("---");
                break;
        }

        for(int loop2 = 0;loop2 < pRatItem->bandList.numNR; loop2++)
        {
            std::string bandNum = "[" + std::to_string(pRatItem->bandList.bandNR[loop2]) + "]";
            strBandNR.append(bandNum);
        }
        if(pRatItem->bandList.numNR == 0)
        {
            strBandNR.append("[-]");
        }

        for(int loop2 = 0;loop2 < pRatItem->bandList.numEUTRA; loop2++)
        {
            std::string bandNum = "[" + std::to_string(pRatItem->bandList.bandEUTRA[loop2]) + "]";
            strBandEUTRA.append(bandNum);
        }
        if(pRatItem->bandList.numEUTRA == 0)
        {
            strBandEUTRA.append("[-]");
        }         

        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "ratType [%s] | srs-SwitchingTimeRequest[%s] | frequencyBandListFilter : NR%s, EUTRA%s\n", strRat.c_str(), pRatItem->srsSwitchingTimeRequest_present? "*":"-",strBandNR.c_str(), strBandEUTRA.c_str());
    }
    // ue-CapabilityEnquiryExt
    if(pDbgInfo->capaEnquiryExt_present)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi,
            "Ext : mrdc-request[%s] codebookTypeRequest[%s] uplinkTxSwitchRequest[%s] requestCellGrouping[%s] rrc-SegAllowed-r16[%s]\n",
            pDbgInfo->CapaEnquiryExt.mrdcRequest_present ? "*" : "-",
            pDbgInfo->CapaEnquiryExt.codebookTypeRequest_present ? "*" : "-",
            pDbgInfo->CapaEnquiryExt.uplinkTxSwitchRequest_present ? "*" : "-",
            pDbgInfo->CapaEnquiryExt.requestCellGrouping_present ? "*" : "-",
            pDbgInfo->CapaEnquiryExt.rrcSegAllowedR16_present ? "*" : "-");
    }
}

int16_t FnVCCB_IsOnlyNrEutraCapaSupported(callInfo_type* ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    if(ptCi->ueInfo.ueCapa.savedInfo.uceRatSupportType == YANG_UE_CAPA_REQ_NR_AND_EUTRA)
    {
        return TRUE;
    }
    return FALSE;
}

int16_t FnVCCB_NeedNrDcIncludeInUce(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
 
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);
    
    // 0. Check RedCap : If UE is RedCap, no need to check 'includeNR-DC' as RedCap UEs do not support NR-DC
    if (IS_REDCAP_UE(ptCi))
    {
        return FALSE;
    }
 
    // 1. Check Overload
    // 1-1. UE has already experienced overload.
    if (ptCi->ueInfo.ueCapa.savedInfo.isAlreadyNrdcOverload)
    {
        return FALSE;
    }
 
    // 1-2. CPC is overload and NR-DC Condition is meet.
    // NOTE : Unblock below when 'overloaded-level-nrdc' parameter is added (FGR-CC5200)
    int16_t nrdcControl = CFG->overloadControl.ueSigCpuOverloadControl.overloadedLevelNrdc; 
    if(TRUE != IS_AVAILABLE_UNDER_CPC_OVERLOAD(nrdcControl)) 
    {
        ptCi->ueInfo.ueCapa.savedInfo.isAlreadyNrdcOverload = TRUE;
        return FALSE;
    }
 
    // 2. Check Yang and Configuration
    if (IS_SUPPORT_NRDC_FOO() && IS_SUPPORT_NRDC_Yang(cellNum))
    {
        return TRUE;
    }
    else if (FnVCCB_CheckIfNrDcCapaRequiredForPcc(*ptCi))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[PCC] PCC requires UE Capa Enquiry for NR-DC!\n");
        return TRUE;
    }
    return FALSE;
}

#define  VCCB_PM_UE_CAPA_UNIT_SIZE        500
#define  VCCB_PM_UE_CAPA_MAX_SIZE       10001
#define  VCCB_PM_ITEM_SIZE_PER_UE_CAPA     21
 
#define  VCCB_PM_NR_UE_CAPA_SIZE_BASE       0
#define  VCCB_PM_EUTRA_UE_CAPA_SIZE_BASE    (VCCB_PM_NR_UE_CAPA_SIZE_BASE+VCCB_PM_ITEM_SIZE_PER_UE_CAPA)    // 21
#define  VCCB_PM_MRDC_UE_CAPA_SIZE_BASE     (VCCB_PM_EUTRA_UE_CAPA_SIZE_BASE+VCCB_PM_ITEM_SIZE_PER_UE_CAPA) // 42

void FnVCCB_SA_CollectUeCapaSize(callInfo_type *ptCi, uint8_t ratType)
{
    AUTO_TRACE_FUNC;


    uint32_t rxUeCapaSize = 0;
    int itemBase = 0, itemOffset = 0;
 
    VALID_E_POINT_CHECK_VOID(ptCi);
    if(ptCi->callType != E_CALLTYPE_SA) return;
    if(IS_NRDC_SN(ptCi)) return; // Do not collect.
 
    // 1. Calculate size and itemBase.
    if(ratType == NRRRC_RAT_Type_nr) // NR
    {
        if (TRUE == FnVCCB_isBigCapabilityRatContainer(ptCi, ratType))
            rxUeCapaSize = ptCi->ueContainerNR_Ext.capaLength;
        else
            rxUeCapaSize = ptCi->ueContainerNR.numocts;
 
        itemBase = VCCB_PM_NR_UE_CAPA_SIZE_BASE; // 0
    }
    else if (ratType == NRRRC_RAT_Type_eutra_nr) // MR-DC
    {
        if (TRUE == FnVCCB_isBigCapabilityRatContainer(ptCi, ratType))
            rxUeCapaSize = ptCi->ueContainerMRDC_Ext.capaLength;
        else
            rxUeCapaSize = ptCi->ueContainerMRDC.numocts;
 
        itemBase = VCCB_PM_MRDC_UE_CAPA_SIZE_BASE; // 42
    }
    else // EUTRA
    {
        if (TRUE == FnVCCB_isBigCapabilityRatContainer(ptCi, NRRRC_RAT_Type_eutra))
            rxUeCapaSize = ptCi->ueContainerEUTRA_Ext.capaLength;
        else
            rxUeCapaSize = ptCi->ueContainerEUTRA.numocts;
 
        itemBase = VCCB_PM_EUTRA_UE_CAPA_SIZE_BASE; // 21
    }
 
    // 2. Calculate itemOffset.
    if(rxUeCapaSize <= VCCB_PM_UE_CAPA_UNIT_SIZE) // 500
    {
        itemOffset = 0;
    }
    else if(rxUeCapaSize >= VCCB_PM_UE_CAPA_MAX_SIZE) // 10,001
    {
        itemOffset = VCCB_PM_ITEM_SIZE_PER_UE_CAPA-1; // 20
    }
    else
    {
        itemOffset = static_cast<int>((rxUeCapaSize-1) / VCCB_PM_UE_CAPA_UNIT_SIZE );
    }
 
    // 3. Collect UE Capa Size
    MACRO_STAT_PMCC(STAT_UE_CAPA_SIZE_DIST_DU_ID, (itemBase+itemOffset), ptCi, 0, 0, 0, 0, 0);
 
    return;
}

/**
 * @brief Copies relevant NR capability information
 * @param[in/out] ptCi             : callInfo
 * @param[in] ueContainerNR      : NR structure for normal capa
 * @param[in] ueContainerNR_Ext  : NR structure for big capa
 * @return GOOD/ERROR              : Message handling status
 */
int16_t FnVCCB_CopyNRCapaForCallInfo(callInfo_type *ptCi, const ueCapabilitiesRATcontainer_type *ueContainerNR, const extUeCapaInfo_type *ueContainerNR_Ext)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ueContainerNR);
    VALID_E_POINT_CHECK_ERROR(ueContainerNR_Ext);

    if (ueContainerNR->isBigCapaFlag == VCCB_FLAG_ON) // Big capa
    {
        memcpy(&ptCi->ueContainerNR_Ext, ueContainerNR_Ext, sizeof(*ueContainerNR_Ext));
        ptCi->bitFlag.doNotReleaseExtNrUeCapa = VCCB_FLAG_ON;        
        ptCi->ueContainerNR.rxFlag = VCCB_FLAG_ON;
        ptCi->ueContainerNR.isBigCapaFlag = VCCB_FLAG_ON;
    }
    else  // normal capa
    {
        ptCi->ueContainerNR.numocts = ueContainerNR->numocts;
        ptCi->ueContainerNR.rxFlag = ueContainerNR->rxFlag;
        memcpy(&ptCi->ueContainerNR.data, &ueContainerNR->data, ueContainerNR->numocts);
    }
    
    if(DBG->flag.logUeCapaEnquiry)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_CopyNRCapaForCallInfo ueContainerNR_Ext->capaLength(%d), ueContainerNR->numocts(%d)\n",
            ueContainerNR_Ext->capaLength, ueContainerNR->numocts);
    }

    return GOOD;
}

/**
 * @brief Copies relevant MRDC capability information
 * @param[in/out] ptCi             : callInfo
 * @param[in] ueContainerMRDC      : MRDC structure for normal capa
 * @param[in] ueContainerMRDC_Ext  : MRDC structure for big capa
 * @return GOOD/ERROR              : Message handling status
 */
int16_t FnVCCB_CopyMRDCCapaForCallInfo(callInfo_type *ptCi, const ueCapabilitiesRATcontainer_type *ueContainerMRDC, const extUeCapaInfo_type *ueContainerMRDC_Ext)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ueContainerMRDC);
    VALID_E_POINT_CHECK_ERROR(ueContainerMRDC_Ext);

    if ((ueContainerMRDC->isBigCapaFlag)) // Big capa
    {
        memcpy(&ptCi->ueContainerMRDC_Ext, ueContainerMRDC_Ext, sizeof(*ueContainerMRDC_Ext));
        ptCi->bitFlag.doNotReleaseExtMrdcUeCapa = VCCB_FLAG_ON;
        ptCi->ueContainerMRDC.rxFlag = VCCB_FLAG_ON;
        ptCi->ueContainerMRDC.isBigCapaFlag = VCCB_FLAG_ON;
    }
    else  // normal capa
    {
        ptCi->ueContainerMRDC.numocts = ueContainerMRDC->numocts;
        ptCi->ueContainerMRDC.rxFlag = ueContainerMRDC->rxFlag;
        memcpy(&ptCi->ueContainerMRDC.data, &ueContainerMRDC->data, ueContainerMRDC->numocts);
    }

    if(DBG->flag.logUeCapaEnquiry)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_CopyMRDCCapaForCallInfo ueContainerMRDC_Ext->capaLength(%d), ueContainerMRDC->numocts(%d)\n",
            ueContainerMRDC_Ext->capaLength, ueContainerMRDC->numocts);
    }

    return GOOD;
}

uint32_t FnVCCB_GetTotalCapaLengthForCallInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;    
    VALID_E_POINT_CHECK_ZERO(ptCi);

    uint32_t totalLength = static_cast<uint32_t>(        
        (ptCi->ueContainerNR.isBigCapaFlag? ptCi->ueContainerNR_Ext.capaLength:ptCi->ueContainerNR.numocts) 
        + (ptCi->ueContainerMRDC.isBigCapaFlag? ptCi->ueContainerMRDC_Ext.capaLength:ptCi->ueContainerMRDC.numocts)
        + (ptCi->ueContainerEUTRA.isBigCapaFlag? ptCi->ueContainerEUTRA_Ext.capaLength:ptCi->ueContainerEUTRA.numocts));

    return totalLength;
}

uint16_t FnVCCB_IsCellAndUeSupportNrHoToEndcR16(callInfo_type *ptCi, uint16_t cellNum)
{
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *ptCell = &CELLINFO[cellNum];

    if( (ptCell->mobilityConfig.nrToEndcHoSupport) && (ptCi->ueInfo.ueCapa.nr.eutraParam.nrHOToENDCr16))
        return TRUE;

    return FALSE;
}

int16_t FnVCCB_NeedNrCapaEnquiryByDeviceIdentification(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_FALSE(ptCi);
    uint16_t findFlag = 0;

    VCCB_CHECK_E_RANGE_AND_FALSE(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *pGnb = &GNBINFO[ptCi->gnbNum];

    DeviceIdentifyFilter_type *pDiConfig = &pGnb->capabilityRequestFilter.deviceIdentifyFilter;
    freqBandListFilter_type *pUeApplied = &ptCi->ueInfo.ueCapa.nr.appliedFreqBandList;
    uint16_t minFreqbandFilter = MIN(pUeApplied->num, MAX_FREQBAND_FILTER);
    
    if((pDiConfig->usage == CI_use) && (ptCi->ueInfo.ueCapa.nr.macCommon.dummyPresent))
    {
        for (auto idx = 0; idx < minFreqbandFilter; idx++)
        {
            if ((pUeApplied->band[idx].ratType == ci_eutra) &&(pUeApplied->band[idx].band == pDiConfig->band))
            {
                /* Compare eutraBandReqLimitInfo */
                if(COMPARE_EUTRABAND_REQ_LIMIT_INFO(ptCi, pUeApplied->band[idx].eutraBandReqLimitInfo, pDiConfig->eutraBandReqLimitInfo))
                {
                    findFlag++;
                    break;
                }
            }
        }
        if (findFlag == 0)  // If Not found, then try new UECapaEnquiry.
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Trigger UCE: [Device Identification] bandEUTRA(%d) is required\n", pDiConfig->band);
            return TRUE;
        }
    }

    return FALSE;
}

int16_t FnVCCB_IsIncludeFr2BandInAppliedFilterOfUeCapa(callInfo_type *ptCi, uint8_t ueCapaReqRatType)
{
    VALID_E_POINT_CHECK_FALSE(ptCi);
    freqBandListFilter_type *pUeApplied = nullptr;

    if (ueCapaReqRatType == UE_CAPA_REQ_RAT_TYPE_NR)
    {
        pUeApplied = &ptCi->ueInfo.ueCapa.nr.appliedFreqBandList;
    }
    else
    {
        pUeApplied = &ptCi->ueInfo.ueCapa.mrdc.appliedFreqBandList;
    }

    uint16_t maxBandCnt = MIN(pUeApplied->num, MAX_FREQBAND_FILTER);

    for (uint16_t bandIdx = 0; bandIdx < maxBandCnt; bandIdx++)
    {
        if (pUeApplied->band[bandIdx].ratType == ci_nr)
        {
            // FR2 is bigger than n257
            if ((pUeApplied->band[bandIdx].band >= START_BAND_NUM_OF_FR2_NR) &&  // 257
                (pUeApplied->band[bandIdx].band <= MAX_NUM_NR_BAND))             // 1024
            {
                return TRUE;
            }
        }
    }

    return FALSE;
}
