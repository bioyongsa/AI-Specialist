#ifndef VCCB_FEAT_FeatCapaHandling_H_
#define VCCB_FEAT_FeatCapaHandling_H_

#include "VccbStruct.h"

int16_t FnVCCB_NeedUeCapaEnquiry(callInfo_type *ptCi, uint16_t cellNum, uint8_t *needEnquiryBitFlag);
int16_t FnVCCB_NeedUeCapaEnquiryByNrCapa(callInfo_type *ptCi, uint16_t cellNum);
int16_t FnVCCB_NeedUeCapaEnquiryByAppliedFreqBandList(callInfo_type *ptCi, uint16_t cellNum, uint8_t ueCapaReqRatType);
int16_t FnVCCB_CheckAndSendUeCapaMessage(callInfo_type *ptCi);
int16_t FnVCCB_UpdateNextUeCapaOperation(callInfo_type *ptCi, uint8_t allStateTimeOutCaseFlag);
int16_t FnVCCB_BackupCapabilityInfo(callInfo_type *ptCi);
static inline void FnVCCB_InitUeNrCapaReqAsDefault(ueCapaNrBandReqLimitInfo_type &reqLimitInfo)
{
    reqLimitInfo.maxBandwidthRequestedDl = -1;
    reqLimitInfo.maxBandwidthRequestedUl = -1;
    reqLimitInfo.maxCarriersRequestedDl = 0;
    reqLimitInfo.maxCarriersRequestedUl = 0;
}
static inline void FnVCCB_InitUeEutraCapaReqAsDefault(ueCapaEutraBandReqLimitInfo_type &reqLimitInfo)
{
    reqLimitInfo.caBandwidthClassDlEutra = -1;
    reqLimitInfo.caBandwidthClassUlEutra = -1;
}
int16_t FnVCCB_IsOnlyNrCapaSupported(callInfo_type *ptCi);
int16_t FnVCCB_NeedUeCapaEnquiryByMrDcCapa(callInfo_type *ptCi, uint16_t cellNum);
int16_t FnVCCB_NeedUeCapaEnquiryByEutraCapa(callInfo_type *ptCi);
void FnVCCB_CheckAndClearUeCapaByEnquiryBit(callInfo_type *ptCi);
void FnVCCB_ParseUECapabilityEnquiry_ForDebug(callInfo_type* ptCi, NRRRC_UECapabilityEnquiry* pIE, CapaEnquiryInfo_type* enquiryInfo);
void FnVCCB_PrintUECapabilityEnquiry_ForDebug(callInfo_type* ptCi, CapaEnquiryInfo_type* pInfo);
void FnVCCB_Finalize_UeCapaEnquiryIfNeeded_ForSA(callInfo_type *ptCi, uint16_t cellNum, uint8_t queueingOption);
void VCCM_DiffandArrangeAppliedFilter(callInfo_type *ptCi);
int16_t FnVCCB_IsOnlyNrEutraCapaSupported(callInfo_type* ptCi);
int16_t FnVCCB_NeedNrDcIncludeInUce(callInfo_type *ptCi, uint16_t cellNum);
void FnVCCB_SA_CollectUeCapaSize(callInfo_type *ptCi, uint8_t ratType);
int16_t FnVCCB_CopyNRCapaForCallInfo(callInfo_type *ptCi, const ueCapabilitiesRATcontainer_type *ueContainerNR, const extUeCapaInfo_type *ueContainerNR_Ext);
int16_t FnVCCB_CopyMRDCCapaForCallInfo(callInfo_type *ptCi, const ueCapabilitiesRATcontainer_type *ueContainerMRDC, const extUeCapaInfo_type *ueContainerMRDC_Ext);
uint32_t FnVCCB_GetTotalCapaLengthForCallInfo(callInfo_type *ptCi);
uint16_t FnVCCB_IsCellAndUeSupportNrHoToEndcR16(callInfo_type *ptCi, uint16_t cellNum);
int16_t FnVCCB_NeedNrCapaEnquiryByDeviceIdentification(callInfo_type *ptCi);
void FnVCCB_FreeUeCapabilityInfoPerRatType(callInfo_type *ptCi, enumSegmentPdu_type ratType);
int16_t FnVCCB_IsIncludeFr2BandInAppliedFilterOfUeCapa(callInfo_type *ptCi, uint8_t ueCapaReqRatType);

#endif
