#ifndef VCCB_FEAT_FeatRrcSegment_H_
#define VCCB_FEAT_FeatRrcSegment_H_

#include "VccbStruct.h"
#include "FeatCapaHandling.h"

int16_t FnVCCB_InitRrcSegmentPoolBuf(void);
uint32_t FnVCCB_AllocSegmentPoolBuffer(callInfo_type &rCall);
void FnVCCB_FreeRrcSegmentPoolBuf(uint16_t threadId, uint32_t buffIdx);

int16_t FnVCCB_GetCapabilityDataFromRrcSegment(callInfo_type *ptCi, extUeCapaInfo_type *segInfo,
    bigMsgContainer_type *tgtBuf);  // Store single UL Dedicate Segment Message to a segment buffer pool
int16_t FnVCCB_StoreUlRrcDedicateSegmentToRrcSegmentPool(callInfo_type *ptCi, enumSegmentPdu_type pduType,
    extUeCapaInfo_type *tgtSegInfo,
    void *srcIE);  // Assemble multiple segment buffer to one large UCI
int16_t FnVCCB_StoreBigUECapabilityToRrcSegmentPool(callInfo_type *ptCi, enumSegmentPdu_type pduType,
    extUeCapaInfo_type *tgtSegInfo, uint8_t *srcBuf,
    uint32_t length);  // Split one large UCI to NR/MRDC/EUTRA capa according to its rat-type

int8_t FnVCCB_Check_isSegmentedUciCall(const callInfo_type *ptCi);

ueCapabilitiesRATcontainer_type* FnVCCB_GetUeCapabilityRatContainer(callInfo_type &rCall, const uint8_t ratType);
extUeCapaInfo_type* FnVCCB_GetUeCapabilityBigRatContainer(callInfo_type &rCall, const uint8_t ratType);
int FnVCCB_isBigCapabilityRatContainer(callInfo_type *ptCi, uint8_t ratType);
int8_t FnVCCB_CheckTgtNodeSupportUlSegmentCapability(
    uint32_t gnbNum, uint32_t nodeId, plmnId_type plmn, enumUlSegCapaNode_type nodeType);
void FnVCCB_InitExtUeCapaInfo(callInfo_type *ptCi, extUeCapaInfo_type *pContainerExt);
void FnVCCB_FreeExtUeCapaInfo(callInfo_type *ptCi, extUeCapaInfo_type *pContainerExt);
int FnVCCB_CanGnbStoreUlRrcSegmentationCapa();
int FnVCCB_CanGnbEnquiryUlRrcSegmentationCapa(callInfo_type *ptCi);
int16_t FnVCCB_ClearRrcSegmentPoolBuf(uint32_t nodeCnt);
void FnVCCB_PrintUlDedicatedMessageSegment(callInfo_type *ptCi, NRRRC_ULDedicatedMessageSegment_r16_IEs *srcIE, extUeCapaInfo_type *tgtSegInfo);

#endif