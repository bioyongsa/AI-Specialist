#ifndef VCCB_FEAT_FeatRbInfo_H_
#define VCCB_FEAT_FeatRbInfo_H_

#include "VccbStruct.h"


void FnVCCB_InitPdcpInfo(uint16_t gnbNum);
pdcpProfile_type *FnVCCB_GetPdcpProfile(uint16_t cellNum, uint16_t gnbNum);
pdcpInfoQci_type *FnVCCB_GetPdcpInfoQci(uint16_t cellNum, uint16_t gnbNum, uint16_t qci);
pdcpInfo5qi_type *FnVCCB_GetPdcpInfo5qi(uint16_t cellNum, uint16_t gnbNum, uint16_t fiveQi);

int16_t FnVCCB_FillCallRbInfoPerQci(callInfo_type *ptCi, callERABInfo_type *ptRi, uint16_t qci);
int16_t FnVCCB_FillPdcpConfiguration_QciBased(callInfo_type *ptCi, callERABInfo_type *ptRi, uint16_t qci, uint16_t spCellNum);
void FnVCCB_FillPdcpConfiguration_QciBased_Changeable(callInfo_type *ptCi, callERABInfo_type *ptRi, pdcpInfoQci_type *pPdcpInfo);
void FnVCCB_FillPdcpConfiguration_QciBased_NonChangeable(callInfo_type *ptCi, callERABInfo_type *ptRi, pdcpInfoQci_type *pPdcpInfo);
uint8_t FnVCCB_GetUlDataSplitThreshold(callInfo_type *ptCi, callERABInfo_type *ptRi);
bool FnVCCB_IsUlDataSplitThresholdFr1Fr2Infinite(const callDRBInfo_type *const ptDi);
void FnVCCB_FillRohcParameters_QciBased(callInfo_type *ptCi, callERABInfo_type *ptRi, pdcpInfoQci_type *pPdcpInfo);

int16_t FnVCCB_FillCallRbInfoPer5qi(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t updateOption);
int16_t FnVCCB_FillPdcpConfiguration_5qiBased(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t updateOption,uint16_t spCellNum);
void FnVCCB_FillPdcpConfiguration_5qiBased_Changeable(callInfo_type *ptCi, callDRBInfo_type *ptDi, pdcpInfo5qi_type *pPdcpInfo);
int16_t FnVCCB_FillPdcpConfiguration_5qiBased_NonChangeable(callInfo_type *ptCi, callDRBInfo_type *ptDi, int16_t spCellNum, uint8_t updateOption, pdcpInfo5qi_type *pPdcpInfo);
int16_t FnVCCB_FillRohcParameters_5qiBased(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint16_t spCellNum, uint8_t updateOption, pdcpInfo5qi_type *pPdcpInfo);

int8_t FnVCCB_DecideRlcMode(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t fiveQi);
int8_t FnVCCB_DecidePdcpSnSize(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t fiveQi, uint8_t updateOption);
int16_t FnVCCB_DecideEhc(callInfo_type *ptCi, callDRBInfo_type *ptDi);
void FnVCCB_InitEhcContext(callDRBInfo_type *ptDi);
int16_t FnVCCB_EhcPossible(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t fiveQi ,uint16_t spCellNum);
int16_t FnVCCB_EhcCidAvailable(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t fiveQi ,uint16_t spCellNum);
int16_t FnVCCB_EvaluateUlDlMaxEHCSession(callInfo_type *ptCi, pdcpInfo5qi_type *pPdcpInfo, uint16_t *reqCidSession_dl, uint16_t *reqCidSession_ul);
void FnVCCB_FillEhcParameters_5qiBased(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint16_t spCellNum, uint8_t updateOption, pdcpInfo5qi_type *pPdcpInfo);
void FnVCCB_DecideHeaderCompressionParametersFill(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t *decideRohcParametersFill, uint8_t *decideEhcParametersFill);
void FnVCCB_SetMaxRohcSessionPerProfile(pdcpProfile_type *pProfile);

#endif