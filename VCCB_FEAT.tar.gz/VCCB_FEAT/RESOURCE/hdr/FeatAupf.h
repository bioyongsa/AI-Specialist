#ifndef VCCB_FEAT_FeatAupf_H_
#define VCCB_FEAT_FeatAupf_H_

#include "RscCall.h"
#include "VccbStruct.h"

namespace FeatAupf
{
static inline void initCallAupf(CallAupf_type &callAupf)
{
    callAupf.usage = CI_no_use;
    callAupf.resetEventType = e_ReleaseTriggerNotRelease;  // 23A_NRRetainability
    callAupf.ueActivityStatus = ActivityStatus_INACTIVE;
}

static inline void setCallAupf(
    callInfo_type &call, const uint16_t upIndexInCall, const uint16_t endPointIndex, const uint64_t aupfId)
{
    if (upIndexInCall >= MAX_CU_UP_PER_CALL) return;

    auto &callAupf = call.endPointInfo.aupf[upIndexInCall];
    if (callAupf.usage == CI_no_use)
    {
        callAupf.usage = CI_use;
        callAupf.resetEventType = e_ReleaseTriggerNotRelease;  // For Multi-UP. 23A_NRRetainability
        callAupf.e1Idx = endPointIndex;
        callAupf.aupfId = aupfId;
        callAupf.e1Cause = CauseE1apMiscUnspecified;
        RscCall::setUeActivityStatusPerUP(call, upIndexInCall, ActivityStatus_ACTIVE);
    }
}
}  // namespace FeatAupf

#endif
