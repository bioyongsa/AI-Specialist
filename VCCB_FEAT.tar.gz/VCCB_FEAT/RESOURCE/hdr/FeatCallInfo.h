/****************************************************************
 * System      : 5G vNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : VlibCallInfo.h
 * Description :
 * Author      :
 * Dept.       : NG Access Lab.
 * Created     : 2016.08.01
 * Procedures defined :
 * Procedures called  :
 * Version     :
 * Revision history   :
 *          date      :
 *       revised by   :
 * revised information:
 ****************************************************************/

#ifndef VCCB_FEAT_FeatCallInfo_H_
#define VCCB_FEAT_FeatCallInfo_H_

#include "VccbStruct.h"
#include <vector>

enumEstablishmentCause_type FnVCCB_GetEstablishmentCause(const callInfo_type &callInfo);
enumResumeCause_type FnVCCB_GetResumeCause(const callInfo_type &callInfo);

void VLIB_InitCallInfo(callInfo_type *ptCi, uint8_t threadId, uint16_t gnbNum, enumCallType_type callType);
void VLIB_InitCallGnbInfo(callGNBInfo_type *ptGi, uint16_t gnbIdx);
void VLIB_InitPathInfo(callInfo_type *ptCi, pathInfo_type *ptPi, uint16_t enbIdx, uint16_t erabIdx, uint16_t pathType);
void VLIB_InitHoStat(callInfo_type *ptCi);
void VLIB_InitHoInfo(callInfo_type *ptCi, bool initQInfo = true);
void VLIB_InitMroInfo(callInfo_type *ptCi);
void VLIB_InitRlfReportInfo(callInfo_type *ptCi);
void VLIB_InitRreInfo(callInfo_type *ptCi);
void FnVCCB_InitRRCInactiveInfo(callInfo_type *ptCi);
void FnVCCB_InitRRCResumeInfo(callInfo_type *ptCi);
void FnVCCB_InitQciAttemptSuccessInfo(callInfo_type *ptCi);
void FnVCCB_InitLatestReleasedQci(callInfo_type *ptCi);
void FnVCCB_ClearDRBPreemption(callInfo_type *ptCi);
void FnVCCB_InitUeAssistanceInformation(callInfo_type &rCall);
void FnVCCB_InitSACallInfo(callInfo_type *ptCi);
void VLIB_InitRefusedTargetFR1CellsForFR2FR1HO(callInfo_type *ptCi);
void VLIB_InitMeasConfigPeriodicMeasurement(measurementsConfigShared_type::s_PeriodicMeasurement_type *ptPm);
void VLIB_InitMeasConfigAltgap(measurementsConfigShared_type::s_AlternateMeasGap_type *pAltGap);
void VLIB_InitMeasurementsConfiguration(measurementsConfiguration_type &rMeasConf);
void VLIB_InitMeasurementsProcedure(measurementsProcedure_type &rMeasProc);
void VLIB_InitMeasurementsStructs(callInfo_type *ptCi);
void VLIB_InitMGapDuData(mGapDuData_type &rmGapDu);

void VLIB_CollectStat_PutCi(callInfo_type *ptCi);
void VLIB_IncrementReleaseAllStats(callInfo_type *ptCi, uint8_t erabIncrement, callERABInfo_type *ptErabInfo);
void VLIB_IncrementReleaseErabStatsByENB(callInfo_type *ptCi, callERABInfo_type *ptErabInfo);
void VLIB_IncrementReleaseCtxtStatsByENB(callInfo_type *ptCi);
void VLIB_IncrementReleaseErabStatsByGNB(callInfo_type *ptCi, callERABInfo_type *ptErabInfo);
void VLIB_IncrementReleaseCtxtStatsByGNB(callInfo_type *ptCi);
void VLIB_CollectStat_RRC_Release(callInfo_type *ptCi);
void VLIB_CollectStat_NSA_UeCapaSizeDist(callInfo_type *ptCi);
void VLIB_CollectStatPerCapaType_NSA_UeCapaSizeDist(callInfo_type *ptCi, uint8_t base, uint32_t length);

int16_t VLIB_FillCslScgFailure(callInfo_type *ptCi, measResultList2NR_type *ptMeasResultList2NR, uint8_t failureType);
int16_t VLIB_FillCslMeasReport(
    callInfo_type *ptCi, measResultList2NR_type *ptMeasResultList2NR, uint16_t reportType, uint8_t reportPurpose);
int16_t VLIB_FillCslMeasReportLast(
    callInfo_type *ptCi, measResultList2NR_type *ptMeasResultList2NR, uint16_t reportType, uint8_t reportPurpose);
int16_t VLIB_FillCslMeasReportAdditionRequest(
    callInfo_type *ptCi, measResultList2NR_type *ptMeasResultList2NR, uint16_t reportType, uint8_t reportPurpose);
void VLIB_FillRecoveryTimeCsl(callInfo_type *ptCi);
void VLIB_ClearCslMeasReport(cslMeasInfo_type *ptCslMeasInfo);

void VLIB_ConfigDrxCuInfo(callInfo_type *ptCi);

void FnVCCB_InitActiveUeBitmap(void);
int16_t FnVCCB_SetActiveUeBitmap(const uint32_t cuCpUeId, const uint8_t bitSet);

void VLIB_CommitRadioBearerConfigUE(callInfo_type *ptCi);
uint16_t VLIB_GetFreqBandIndForCell(callInfo_type *ptCi, VccbCellInfo_type *ptCell);
uint16_t VLIB_GetFreqBandIndForCellNum(callInfo_type *ptCi, uint16_t cellNum);
int16_t FnVCCB_GetFreqAndBandListFromInstalledMeasIdForSCGBandSel(
    callInfo_type *ptCi, enumMeasurementReportType reportType, uint8_t reportPurpose, std::vector<frequencyAndBandIndiNR_type> &vFreqBand);
uint16_t VLIB_GetFreqBandIndForNeighborCellWithCustomSpCell(
    callInfo_type *ptCi, const nbrGnbCellInfo_type *ptCell, uint16_t spCellNum, bool isForSpCell);
int16_t VLIB_IsAnyNrFreqBandConfiguredInCell(const nbrGnbCellInfo_type *ptCell);
uint16_t VLIB_GetFreqBandIndForNeighborCell(callInfo_type *ptCi, const nbrGnbCellInfo_type *ptCell);
uint16_t VLIB_GetFreqBandIndForNeighborServingCell(callInfo_type *ptCi, const nbrGnbCellInfo_type *ptCell);
uint16_t VLIB_GetNrBandIndex(const callInfo_type &rCi, uint16_t bandNR);
uint8_t VLIB_GetFreqBandIndListForNeighborCellWithCustomSpCell(callInfo_type *ptCi,
    const nbrGnbCellInfo_type *ptCell, uint16_t spCellNum, bool isForSpCell,
    uint16_t bandList[MAX_FREQBAND_PER_CELL]);

void VLIB_InitCallPDUInfo(callInfo_type *ptCi, callPDUSessInfo_type *ptPi);
int16_t VLIB_AllocCallPDUInfo(callInfo_type *ptCi, uint8_t *ptAllocatedPduIdx);
int16_t VLIB_AllocCallDrbInfo(callInfo_type *ptCi, callPDUSessInfo_type *ptPi, uint8_t *ptAllocatedIdx);
int16_t VLIB_SelectRepresentativeQoSFlowInDRB(callInfo_type *ptCi, callDRBInfo_type *ptDi);
int FnVCCB_UpdateRepresentativeQosFlowForAddModDrb_ForSN(callInfo_type &rCall);
void FnVCCB_Decide_QosMonitoringInfoForAllDrbs(callInfo_type *ptCi);

int16_t VLIB_AllocNewCallDrbInfo(
    callInfo_type *ptCi, uint8_t pduIdx, uint16_t qosFlowIdxInPdu, uint16_t *ptAllocatedIdx);
void FnVCCB_InitDrbInfo(callDRBInfo_type *ptDi);

void VLIB_InitCallQosFlowInfo(qosFlowInfo_type *ptQi);
int16_t VLIB_AllocCallQosFlowInfo(callInfo_type *ptCi, callPDUSessInfo_type *ptPi, uint8_t *ptAllocatedIdx);
int16_t VLIB_FindqosFlowGroupIdxForSlice(
    callInfo_type *ptCi, callPDUSessInfo_type *ptPi, uint16_t qosFlowGroupIdx, uint8_t isDedicated);
int16_t VLIB_FindqosFlowGroupIdxForPlmn(callInfo_type *ptCi, uint16_t qosFlowGroupIdx, uint8_t isDedicated);
int16_t VLIB_AllocDrbByDedicatedQosFlowGroup(
    callInfo_type *ptCi, uint8_t pduIdx, uint16_t qosFlowIdxInPdu, uint8_t *isDedicatedAndMappingRuleListEmpty);
int16_t VLIB_AllocDrbByMappingRule(
    callInfo_type *ptCi, uint8_t pduIdx, uint16_t qosFlowIdxInPdu, uint8_t *isDedicatedAndMappingRuleListEmpty);
int16_t VLIB_AllocDrbByDefault(callInfo_type *ptCi, uint8_t pduIdx, uint16_t qosFlowIdxInPdu);
int16_t VLIB_AllocDrbByDedicatedQosFlowGroup_NoConfiguration_Available(
    callInfo_type *ptCi, uint8_t pduIdx, uint16_t qosFlowIdxInPdu);
int16_t VCCB_FindInstalledMeasId_ByFreqReportPurpose(
    callInfo_type *ptCi, uint32_t freq, enumMeasurementReportType reportType, uint8_t reportPurpose);
uint8_t FnVCCB_CheckMeasInstalledByCallbackId(callInfo_type *ptCi, enumMeasReportCallbackId_type callbackId);

int16_t VLIB_checkChannelBWs(callInfo_type *ptCi, uint16_t cellNum, uint16_t bandNR);
int16_t VLIB_checkIntraNRChannelBWs(const callInfo_type *ptCi, const nbrGnbCellInfo_type *pNbrGnbCell, uint16_t bandNR,
    uint16_t cellNum, uint16_t ignoreMisMatchBWAllowed);
int16_t VLIB_checkIntraNRChannelBWDl(const callInfo_type *ptCi, const nbrGnbCellInfo_type *pNbrGnbCell, uint16_t bandNR,
    uint16_t cellNum, uint16_t ignoreMisMatchBWAllowed);
int16_t VLIB_checkIntraNRChannelBWUl(const callInfo_type *ptCi, const nbrGnbCellInfo_type *pNbrGnbCell, uint16_t bandNR,
    uint16_t cellNum, uint16_t ignoreMisMatchBWAllowed);
int16_t VLIB_CheckDrbTypeModInvolvingSplitOngoing(callInfo_type *ptCi);
int16_t VLIB_CheckDrbTypeSN_MCG_AddModReleaseOnly(callInfo_type *ptCi);
int16_t VXIL_Check_F1UeContextToSetup(callInfo_type *ptCi);

int16_t VLIB_checkDssAllowed(callInfo_type *ptCi, uint16_t bandNbr, bool checkGnbBandList, VccbCellInfo_type *ptCell);
uint16_t VLIB_getBandWidthFilter(enumFrequencyRange_type frequencyType, uint16_t bandwidth);
uint16_t VLIB_getCombinedChannelBWsBits(uint16_t channelBWsBits, uint16_t channelBWsBits_v1590, const bool support90MHz);

int16_t VLIB_findCarrierCell(duFailedSCellInfo_type *failures, uint32_t failedCarrierToFind);

uint8_t VLIB_SCellPlmnMatchesSpCell(uint32_t servingPLMN, uint16_t sCellNum);

void VLIB_PduSessionResourceSetup_CollectStat_PutCi(callInfo_type *ptCi);
void VLIB_PduSessionResourceSetup_CollectStat_FailedPduItem(
    callInfo_type *ptCi, uint16_t cause, uint8_t callPduIdx, int32_t mFamily);
void VLIB_DrbSetup_CollectStat_PutCi(callInfo_type *ptCi);
void VLIB_DrbSetup_CollectStat_FailedDrbItem(callInfo_type *ptCi, uint16_t cause, uint8_t callDrbIdx, int32_t mFamily);
void VLIB_DrbRelErase_CollectStat_PutCi(callInfo_type *ptCi);
void VLIB_DrbRelErase_CollectStat_FailedDrbItem(callInfo_type *ptCi, uint16_t cause, uint8_t callDrbIdx);
void VLIB_QosFlowSetup_CollectStat_PutCi(callInfo_type *ptCi);
void VLIB_NeDcDrb_CollectStat_FailedDrbItem(callInfo_type *ptCi, uint16_t mFamily, uint16_t mType, uint8_t callDrbIdx);
void VLIB_NeDcDrb_CollectStat_UpFail(callInfo_type *ptCi);
void VLIB_NeDcDrb_CollectStat_UpTimeout(callInfo_type *ptCi);
void VLIB_NeDcDrb_CollectStat_SenbFail(callInfo_type *ptCi);
void VLIB_NeDcDrb_CollectStat_CpFail(callInfo_type *ptCi);
void VLIB_CollectRetainIntraGnbRREStat_PutCi(callInfo_type *ptCi);

void VLIB_CollectRetainStat_IntraGnbHO(callInfo_type *ptCi);  // RETAIN_STAT_HO_21C

int8_t FnVCCB_DecideRlcPdcpConfig(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t updateOption);

int16_t VCCM_CheckNonGbrQosFlowInPduSession(callInfo_type *ptCi, callPDUSessInfo_type *pPDUSessInfo);

int16_t VCCB_InitializePdcpAllSRBs(callInfo_type *ptCi);

uint8_t FnVCCB_GetUeCapaSplitDRB_withUL_Both_MCG_SCG_NRDC(const callInfo_type *ptCi);

int16_t FnVCCB_DecideRohc(callInfo_type *ptCi, callDRBInfo_type *ptDi);
int16_t FnVCCB_InitRohcContext(callDRBInfo_type *ptDi);
void VLIB_InitUeRoHCInfo(ueNrRohcCapability_type *pUeRoHCCapability);
void VLIB_InitUeEHCInfo(ueNrEhcCapability_type *pUeEhcCapability);

int16_t FnVCCB_SymmetricRohcPossible(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t fiveQi ,uint16_t spCellNum);
int16_t FnVCCB_UplinkRohcPossible(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t fiveQi ,uint16_t spCellNum);
int16_t FnVCCB_UplinkRohcCidAvailable(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t fiveQi, uint16_t spCellNum);
int16_t FnVCCB_SymmetricRohcCidAvailable(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t fiveQi, uint16_t spCellNum);
int16_t VLIB_PdcpReestabReqForRohcChange(callInfo_type *ptCi, callDRBInfo_type *ptDi);


void VLIB_InitUeReleasePreference(callInfo_type *ptCi);
void FnVCCB_InitUeNrRrcOtherConfig(callInfo_type *ptCi);
void VLIB_InitFacMeasConfig(void);

int16_t isUe90MHzSupportDl(const callInfo_type *ptCi);
int16_t isUe90MHzSupportUl(const callInfo_type *ptCi);

void VLIB_ResetScgFailAttSuccStats(callInfo_type *ptCi);

void FnVCCB_StoreSdapInfoPrev(callDRBInfo_type *ptDi);

int16_t FnVCCB_FillSdapConfiguration(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t updateOption);
int8_t FnVCCB_IsDrbEstablishedScenario(callInfo_type *ptCi, callDRBInfo_type *ptDi);

void VLIB_GetUeTypeMaxDrbCount(callInfo_type *ptCi, uint8_t *maxDrbCount);
bool FnVCCB_IsActiveUeContextStat(callInfo_type *ptCi);
void VLIB_InitSecurityInfo(callInfo_type *ptCi);

int16_t VLIB_FindSCellWithPciArfcn(callInfo_type *ptCi, uint16_t pci, uint32_t arfcn, enumRSType rsType, uint8_t *foundSCellIdx, uint8_t isCslPurpose);

void FnVCCB_InitTimerBasedMrBasedRedirectionInfo(callInfo_type &rCall, enumTimerType option=CANCEL_TIMER);
void FnVCCB_InitNrConnectedMobilityControlInfo(callInfo_type &rCall);
void FnVCCB_InitServiceBorderMobilityInfo(callInfo_type &rCall, enumTimerType option=CANCEL_TIMER);
void FnVCCB_InitSpecificSliceForcedMobilityInfo(callInfo_type &rCall, enumTimerType option=CANCEL_TIMER);
void VLIB_RrcConnEstab_CollectStat_PutCi(callInfo_type *ptCi);
void FnVCCB_InitCslInfo_RetainStat(callInfo_type *ptCi);
void FnVCCB_InitCslInfo_BasicCallStat(callInfo_type *ptCi);
void FnVCCB_InitCslInfo_ConnectInfo(callInfo_type *ptCi);
void FnVCCB_InitCslInfo_CaInfo(callInfo_type *ptCi);
void FnVCCB_InitCslInfo_RreInfo(callInfo_type *ptCi);
void FnVCCB_InitCslInfo_MobilityStat(callInfo_type &rCall);
void FnVCCB_InitCslInfo_HoStat(callInfo_type &rCall);
void FnVCCB_InitCslInfo_MobilityNsaStat(callInfo_type &rCall);
void FnVCCB_InitCslInfo_CaScellFlag(callInfo_type *ptCi);
void FnVCCB_InitCslInfo_CaScellInfo(callInfo_type *ptCi);
void FnVCCB_PrintUeSecurityKeyLog(callInfo_type *ptCi);

void VCCB_NSA_SetCauseForX2SgnbModificationRequired(callInfo_type &call);
qosFlowInfo_type* GetQosFlowFromPduByQfi(callInfo_type &call, callPDUSessInfo_type &rPdu, XNAP_QoSFlowIdentifier qfi);

void FnVCCB_InitSavedRequestedFlagForPduQosFlowVonr(callInfo_type *ptCi);
#endif
