
/****************************************************************
 * System      : 5G vNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatAmf.c
 * Description :
 * Author      :
 * Dept.       : 5G Call SW Lab.
 * Created     : 2019.08.01
 * Procedures defined :
 * Procedures called  :
 * Version     :
 * Revision history   :
 *          date      :
 *       revised by   :
 * revised information:
 ****************************************************************/
/*
 * @file FeatAmf.c
 * @brief This file contains functions related AMF resource.
 */

#include "RscProto.h"

#include "ComInclude.h"
#include "ComLibUtility.h"

#include "CdbUtil.h"

#include "FeatCommon.h"
#include "MsgNmbSend.h"

#include "NRRRC.h"

#define CHECK_AND_SET_NG_AND_TNL_IDX(_selectedAmf, _selectedTnl)            \
    {                                                                       \
        VCCB_CHECK_E_RANGE_AND_RETURN(_selectedAmf, MAX_AMF_PER_GNB_CU_CP); \
        VCCB_CHECK_E_RANGE_AND_RETURN(_selectedTnl, MAX_TNL_PER_AMF);       \
        ptCi->endPointInfo.ngIdx = _selectedAmf;                            \
        ptCi->endPointInfo.ngTnlIdx = _selectedTnl;                         \
    }

#define VCCB_PRINT_CALL_AMF_SELECTION(__ptCi, __fmt, __args...) \
    VCCB_PRINT_CALL_WITH_DEBUG_TRACE_COMMON(DBG->flag.logAmfSelection, __ptCi, __fmt, ##__args)

typedef enum
{
    AMONG_ALL_AMF = 0,                  // 19A Cpapcitiy based AMF selection
    AMONG_MAX_SUPP_UE_S_NSSAI_AMF,      // 20A S-NSSAI from UE based AMF selection
    AMONG_SAME_UE_AMF_SET_ID_AMF,       // 20A AMF Set ID from UE based AMF Relocation
    AMONG_SAME_REROUTE_AMF_SET_ID_AMF,  // 20A AMF Set ID from Initial AMF for AMF Reroute
    AMONG_SAME_AMF_SAME_AMF_SET_ID,     // 21B Same AMF having SAME AMF Set Id
    AMONG_DIFF_AMF_SAME_AMF_SET_ID,     // 21B Other AMF having SAME AMF Set Id

    MAX_CANDI_AMF_TYPE
} enumCandiateAmf_type;

typedef struct
{
    uint16_t amfIdx;
    uint16_t capa;
} CandidateAmf_type;

typedef struct
{
    uint16_t tnlIdx;
    uint16_t weightFactor;
} CandidateTnl_type;

/**
 *  @brief   Get candidate AMF selection type string name
 **/
const char *getCandiAmfTypeStr(int type)
{
    switch (type)
    {
        case AMONG_ALL_AMF:
            return "among_ALL";
        case AMONG_MAX_SUPP_UE_S_NSSAI_AMF:
            return "among_MAX_SUPP_S_NSSAI";
        case AMONG_SAME_UE_AMF_SET_ID_AMF:
            return "among_SAME_UE_AMF_SET";
        case AMONG_SAME_REROUTE_AMF_SET_ID_AMF:
            return "among_SAME_REROUTE_AMF_SET";
        case AMONG_SAME_AMF_SAME_AMF_SET_ID:
            return "among_SAME_AMF_SAME_AMF_SET_ID";
        case AMONG_DIFF_AMF_SAME_AMF_SET_ID:
            return "among_DIFF_AMF_SAME_AMF_SET_ID";
        default:
            return "Unknown";
    }

    return "Unknown";
}

/**
 *  @brief   Print PLDAmfStatus and PLDAmfTnlStatus
 **/
static void VRRM_PrintPLDAmfAndTnlData(callInfo_type *ptCi, uint16_t pldGnbIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(pldGnbIdx, MAX_GNB_PER_SYS);
    VccbCfgInfo_type *const pCfg = CFG;

    int loop1, loop2;
    for (loop1 = 0; loop1 < MAX_AMF_PER_GNB_CU_CP; loop1++)
    {
        PLDAmfStatus *pPldAmfStatus = &pCfg->amf.pldAmfStatus[pldGnbIdx][loop1];
        PLDAmfPlmnInfo *pPldAmfPlmnInfo = &pCfg->amf.pldAmfPlmnInfo[pldGnbIdx][loop1];
        if (pPldAmfStatus->status != EQUIP || pPldAmfPlmnInfo->status != EQUIP) continue;

        VCCB_PRINT_CALL_AMF_SELECTION(ptCi,
            " pldAmfStatus[%d][%d].gNBIdx:%d endPointIdx:%d status:%d (serviceState:%s)\n", pldGnbIdx, loop1,
            pPldAmfStatus->gNBIdx, pPldAmfStatus->endPointIdx, pPldAmfStatus->status,
            (pPldAmfStatus->serviceState == OpState_enabled) ? "enabled" : "disabled!!");
        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "                   .gNBId:%u .relativeAmfCapacity:%d .servedGuamiCnt:%d\n",
            pPldAmfStatus->gNBId, pPldAmfStatus->relativeAmfCapacity, pPldAmfStatus->servedGuamiCnt);

        for (loop2 = 0; (loop2 < pPldAmfStatus->servedGuamiCnt) && (loop2 < MAX_SERVED_GUAMI_PER_AMF); loop2++)
        {
            VCCB_PRINT_CALL_AMF_SELECTION(ptCi,
                "                       .plmn[%d]:x%x(%u) amfInfo[%d](R+S+P):x%x(%u) (S+P):x%x(%u) (S):x%x(%u)\n",
                loop2, pPldAmfStatus->plmn[loop2], pPldAmfStatus->plmn[loop2], loop2, pPldAmfStatus->amfInfo[loop2],
                pPldAmfStatus->amfInfo[loop2], GET_AMF_SET_POINTER_FROM_AMFI(pPldAmfStatus->amfInfo[loop2]),
                GET_AMF_SET_POINTER_FROM_AMFI(pPldAmfStatus->amfInfo[loop2]),
                GET_AMF_SET_FROM_AMFI(pPldAmfStatus->amfInfo[loop2]),
                GET_AMF_SET_FROM_AMFI(pPldAmfStatus->amfInfo[loop2]));
        }

        VCCB_PRINT_CALL_AMF_SELECTION(ptCi,
            "                   .overloadStatus:%u .overloadResponsePresent:%u .overloadAction:%u\n",
            pPldAmfStatus->overloadStatus, pPldAmfStatus->overloadResponsePresent, pPldAmfStatus->overloadAction);

        for (loop2 = 0; (loop2 < pPldAmfPlmnInfo->supportedPlmnCnt) && (loop2 < MAX_PLMN_PER_AMF); loop2++)
        {
            VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "                       .suppPlmn[%d]:0x%x(%u)\n", loop2,
                pPldAmfPlmnInfo->supportedPlmn[loop2], pPldAmfPlmnInfo->supportedPlmn[loop2]);

            uint16_t loop3;
            for (loop3 = 0;
                 (loop3 < pPldAmfPlmnInfo->supportedSnssaiCntPerPlmn[loop2]) && (loop3 < MAX_SNSSAI_PER_PLMN_AMF);
                 loop3++)
            {
                uint32_t supportedSnssai = pPldAmfPlmnInfo->supportedSnssai[loop2][loop3];
                VCCB_PRINT_CALL_AMF_SELECTION(ptCi,
                    "                           .suppSnssai[%d]:0x%x(%u) sst:x%02x(%u) sd:x%06x(%u)\n", loop3,
                    supportedSnssai, supportedSnssai, (supportedSnssai & 0xFF000000) >> 24,
                    (supportedSnssai & 0xFF000000) >> 24, supportedSnssai & 0xFFFFFF, supportedSnssai & 0xFFFFFF);
            }
        }

        for (loop2 = 0; loop2 < MAX_TNL_PER_AMF; loop2++)
        {
            PLDAmfTnlStatus *pPldAmfTnlStatus = &pCfg->amf.pldAmfTnlStatus[pldGnbIdx][loop1][loop2];
            PLDAmfTnlSctpState *pPldAmfTnlSctpState = &pCfg->amf.pldAmfTnlSctpState[pldGnbIdx][loop1][loop2];
            if (pPldAmfTnlStatus->status != EQUIP) continue;

            VCCB_PRINT_CALL_AMF_SELECTION(ptCi,
                " pldAmfTnlStatus[%d][%d][%d].gNBIdx:%d endPointIdx:%d tnlIdx:%d status:%d\n", pldGnbIdx, loop1, loop2,
                pPldAmfTnlStatus->gNBIdx, pPldAmfTnlStatus->endPointIdx, pPldAmfTnlStatus->tnlIdx,
                pPldAmfTnlStatus->status);
            VCCB_PRINT_CALL_AMF_SELECTION(ptCi,
                "                         .gNBId:%u weightFactor:%d tnlUsage:%d (sctpState:%s)\n",
                pPldAmfTnlStatus->gNBId, (uint8_t)pPldAmfTnlStatus->weightFactor, pPldAmfTnlStatus->tnlUsage,
                (pPldAmfTnlSctpState->sctpState == OpState_enabled) ? "enabled" : "disabled!!");
        }
    }
}

/**
 *  @brief   Get PLD gnbIdx form gnbId
 **/
int VRRM_GetAmfStatusPldGnbIdxFromGnbId(uint32_t gnbId, uint16_t *ptGnbIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptGnbIdx);
    VccbCfgInfo_type *const pCfg = CFG;

    uint16_t gnbIdx, amfIdx;

    for (gnbIdx = 0; gnbIdx < MAX_GNB_PER_SYS; gnbIdx++)
    {
        for (amfIdx = 0; amfIdx < MAX_AMF_PER_GNB_CU_CP; amfIdx++)
        {
            PLDAmfStatus *pPldAmfStatus = &pCfg->amf.pldAmfStatus[gnbIdx][amfIdx];
            if ((pPldAmfStatus->status != EQUIP) || (pPldAmfStatus->serviceState != OpState_enabled)) continue;

            if (pPldAmfStatus->gNBId == gnbId)
            {
                *ptGnbIdx = gnbIdx;

                VCCB_PRINT_MSG("%s [%d:%d] found gnbIdx:%d from gnbId:%d\n", __func__, gnbIdx, amfIdx, gnbIdx, gnbId);
                return GOOD;
            }
        }
    }

    VCCB_PRINT_ERROR("%s [%d:%d] not found gnbIdx from gnbId:%d\n", __func__, gnbIdx, amfIdx, gnbId);
    VCCB_PRINT_ERROR("Check (itscp_vccb get cfg gnb amf) and PLDAmfStatus(0x%08X)\n", REL_AMF_STATUS_ID);
    return ERROR;
}

/**
 *  @brief   Get supported s-nssai num of AMF that sent by the UE s-nssai
 **/
static int VRRM_GetAmfSupportedSnssaiCnt(
    callInfo_type *ptCi, uint32_t plmnLongId, uint16_t amfIdx, PLDAmfPlmnInfo *pPldAmfSPlmnInfo, uint16_t *pSuppSnssaiCnt)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pPldAmfSPlmnInfo);
    VALID_E_POINT_CHECK_ERROR(pSuppSnssaiCnt);

    int suppPlmnIdx, suppSnssaiIdx, ueSnssaiIdx;

    for (suppPlmnIdx = 0; (suppPlmnIdx < pPldAmfSPlmnInfo->supportedPlmnCnt) && (suppPlmnIdx < MAX_PLMN_PER_AMF);
         suppPlmnIdx++)
    {
        if (plmnLongId != pPldAmfSPlmnInfo->supportedPlmn[suppPlmnIdx]) continue;

        uint16_t matchedSnssaiCnt = 0;
        for (suppSnssaiIdx = 0; (suppSnssaiIdx < pPldAmfSPlmnInfo->supportedSnssaiCntPerPlmn[suppPlmnIdx]) &&
                                (suppSnssaiIdx < MAX_SNSSAI_PER_PLMN_AMF);
             suppSnssaiIdx++)
        {
            for (ueSnssaiIdx = 0;
                 (ueSnssaiIdx < ptCi->ueInfo.networkSlice.numSnssai) && (ueSnssaiIdx < MAX_NUM_S_NSSAI_PER_CALL);
                 ueSnssaiIdx++)
            {
                if (ptCi->ueInfo.networkSlice.snssai[ueSnssaiIdx].sstSd ==
                    pPldAmfSPlmnInfo->supportedSnssai[suppPlmnIdx][suppSnssaiIdx])
                {
                    matchedSnssaiCnt++;
                    break;
                }
            }
        }

        if (*pSuppSnssaiCnt < matchedSnssaiCnt) *pSuppSnssaiCnt = matchedSnssaiCnt;

        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "%s amf:%d suppPlmnIdx:%d has plmn:0x%x(%u)(sel:%d) matchedSnssaiCnt:%d\n", __func__,
            amfIdx, suppPlmnIdx, plmnLongId, plmnLongId, ptCi->ueInfo.selectedPlmnIdentity, matchedSnssaiCnt);
    }

    VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "%s amf:%d maxSuppSnssaiCnt:%d\n", __func__, amfIdx, *pSuppSnssaiCnt);
    return TRUE;
}

#ifdef IPC_TEST
int VRRM_WrapGetAmfSupportedSnssaiCnt(
   callInfo_type *ptCi, uint32_t plmnLongId, uint16_t amfIdx, PLDAmfPlmnInfo *pPldAmfSPlmnInfo, uint16_t *pSuppSnssaiCnt)
{
    return VRRM_GetAmfSupportedSnssaiCnt(ptCi, plmnLongId, amfIdx, pPldAmfSPlmnInfo, pSuppSnssaiCnt);
}
#endif

/**
 *  @brief   Check if AMF corresponding to amfIdx is available and there is an available TNL.
 **/
VCCB_STATIC int VRRM_CheckAmfOverloadAction(callInfo_type *ptCi, uint16_t pldGnbIdx, uint16_t amfIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(pldGnbIdx, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(amfIdx, MAX_AMF_PER_GNB_CU_CP);
    VccbCfgInfo_type *const pCfg = CFG;

    PLDAmfStatus *pPldAmfStatus = &pCfg->amf.pldAmfStatus[pldGnbIdx][amfIdx];
    const uint8_t establishmentCause = ptCi->ueInfo.establishmentCause;

    if (pPldAmfStatus->overloadStatus == FALSE)
    {
        return TRUE;
    }

    if (pPldAmfStatus->overloadResponsePresent == FALSE)
    {
        return FALSE;
    }

    if (establishmentCause >= ci_spare6)
    {
        return TRUE;
    }

    switch (pPldAmfStatus->overloadAction)
    {
        case rejectNonEmergencyMoDt:
            if ((establishmentCause == ci_emergency) || (establishmentCause == ci_highPriorityAccess) ||
                (establishmentCause == ci_mt_Access) || (establishmentCause == ci_mo_Signalling) ||
                (establishmentCause == ci_mps_PriorityAccess) || (establishmentCause == ci_mcs_PriorityAccess))
            {
                return TRUE;
            }
            break;

        case rejectRrcCrSignalling:
            if ((establishmentCause == ci_emergency) || (establishmentCause == ci_highPriorityAccess) ||
                (establishmentCause == ci_mt_Access) || (establishmentCause == ci_mps_PriorityAccess) ||
                (establishmentCause == ci_mcs_PriorityAccess))
            {
                return TRUE;
            }
            break;

        case permitEmergencySessionsAndMobileTerminatedServicesOnly:
            if ((establishmentCause == ci_emergency) || (establishmentCause == ci_mt_Access))
            {
                return TRUE;
            }
            break;

        case permitHighPrioritySessionsAndMobileTerminatedServicesOnly:
            if ((establishmentCause == ci_highPriorityAccess) || (establishmentCause == ci_mt_Access) ||
                (establishmentCause == ci_mps_PriorityAccess) || (establishmentCause == ci_mcs_PriorityAccess))
            {
                return TRUE;
            }
            break;

        default:
            break;
    }
    return FALSE;
}

/**
 *  @brief   Check if AMF corresponding to amfIdx is available and there is an available TNL.
 **/
static int VRRM_IsAvailableAmf(callInfo_type *ptCi, uint16_t pldGnbIdx, uint32_t plmnLongId, uint16_t amfIdx,
    uint16_t amfSuppSnssaiCnt, uint16_t maxSuppSnssaiCnt, uint8_t candiAmfType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(pldGnbIdx, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(amfIdx, MAX_AMF_PER_GNB_CU_CP);
    VCCB_CHECK_E_RANGE_AND_RETURN(candiAmfType, MAX_CANDI_AMF_TYPE);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    int guamiIdx, tnlIdx;
    uint8_t availAmf = FALSE, availTnl = FALSE;
    VccbCfgInfo_type *const pCfg = CFG;

    PLDAmfStatus *pPldAmfStatus = &pCfg->amf.pldAmfStatus[pldGnbIdx][amfIdx];

    // Check AMF state
    if ((pPldAmfStatus->status != EQUIP) || (pPldAmfStatus->serviceState != OpState_enabled))
    {
        return ERROR;
    }

    // match AMF plmn with plmn of selectedPlmnIdentity
    for (guamiIdx = 0; (guamiIdx < pPldAmfStatus->servedGuamiCnt) && (guamiIdx < MAX_SERVED_GUAMI_PER_AMF); guamiIdx++)
    {
        // Check AMF has selectedPlmn
        if (plmnLongId != pPldAmfStatus->plmn[guamiIdx]) continue;

        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "%s %s: amf:%d guamiIdx:%d has plmn:0x%x(%u)(sel:%d)\n", __func__,
            getCandiAmfTypeStr(candiAmfType), amfIdx, guamiIdx, plmnLongId, plmnLongId,
            ptCi->ueInfo.selectedPlmnIdentity);
        switch (candiAmfType)
        {
            // Case 1,2 (UE Based) or Case 4 (Capa Based)
            case AMONG_ALL_AMF:
            {
                availAmf = TRUE;
                break;
            }
            // Case 3 S-NSSAI
            case AMONG_MAX_SUPP_UE_S_NSSAI_AMF:
            {
                if (amfSuppSnssaiCnt == maxSuppSnssaiCnt)
                {
                    VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "%s %s: amf:%d guamiIdx:%d supports maxSuppSnssaiCnt:%d\n", __func__,
                        getCandiAmfTypeStr(candiAmfType), amfIdx, guamiIdx, maxSuppSnssaiCnt);
                    availAmf = TRUE;
                }
                break;
            }
            // AMF Set ID from UE based AMF Relocation
            case AMONG_SAME_UE_AMF_SET_ID_AMF:
            {
                if ((ptCi->ueInfo.ueId.ueIdType == ciSTMSI) &&
                    (GET_AMF_SET_FROM_AMFI(ptCi->ueInfo.ueId.sTmsi.amfSetPointer) ==
                        GET_AMF_SET_FROM_AMFI(pPldAmfStatus->amfInfo[guamiIdx])))
                {
                    VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "%s %s: amf:%d guamiIdx:%d has amfSetId:x%x of S-TMSI\n", __func__,
                        getCandiAmfTypeStr(candiAmfType), amfIdx, guamiIdx,
                        GET_AMF_SET_FROM_AMFI(ptCi->ueInfo.ueId.sTmsi.amfSetPointer));
                    availAmf = TRUE;
                }
                else if ((ptCi->ueInfo.registeredAmf.amfIdentifierFlag == VCCB_FLAG_ON) &&
                         (GET_AMF_SET_FROM_AMFI(ptCi->ueInfo.registeredAmf.amfIdentifier) ==
                             GET_AMF_SET_FROM_AMFI(pPldAmfStatus->amfInfo[guamiIdx])))
                {
                    VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "%s %s: amf:%d guamiIdx:%d has amfSetId:x%x of registeredAmf\n", __func__,
                        getCandiAmfTypeStr(candiAmfType), amfIdx, guamiIdx,
                        GET_AMF_SET_FROM_AMFI(ptCi->ueInfo.registeredAmf.amfIdentifier));
                    availAmf = TRUE;
                }
                else
                {
                    if (ptCi->ueInfo.ueId.ueIdType == ciSTMSI)
                        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "%s %s: UE AMF SET ID : %d , GUAMI AMF SET ID : %d\n", __func__,
                            getCandiAmfTypeStr(candiAmfType),
                            GET_AMF_SET_FROM_AMFI(ptCi->ueInfo.ueId.sTmsi.amfSetPointer),
                            GET_AMF_SET_FROM_AMFI(pPldAmfStatus->amfInfo[guamiIdx]));
                    else
                        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "%s %s: UE AMF SET ID : %d , GUAMI AMF SET ID : %d\n", __func__,
                            getCandiAmfTypeStr(candiAmfType),
                            GET_AMF_SET_FROM_AMFI(ptCi->ueInfo.registeredAmf.amfIdentifier),
                            GET_AMF_SET_FROM_AMFI(pPldAmfStatus->amfInfo[guamiIdx]));
                }
                break;
            }
            // AMF Set ID from Initial AMF for AMF Reroute
            case AMONG_SAME_REROUTE_AMF_SET_ID_AMF:
            {
                if ((amfIdx != ptCi->endPointInfo.ngIdx) &&  // initialAMF is excluded from targetAMF CandidateAmf
                    (ptCi->amf.reroute.amfSetId == GET_AMF_SET_FROM_AMFI(pPldAmfStatus->amfInfo[guamiIdx])))
                {
                    VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "%s %s: amf:%d guamiIdx:%d has reroute.amfSetId:x%x\n", __func__,
                        getCandiAmfTypeStr(candiAmfType), amfIdx, guamiIdx, ptCi->amf.reroute.amfSetId);
                    availAmf = TRUE;
                }
                break;
            }
            case AMONG_SAME_AMF_SAME_AMF_SET_ID:
            case AMONG_DIFF_AMF_SAME_AMF_SET_ID:
            {
                if (ptCi->servedGuami.amf.setId == GET_AMF_SET_FROM_AMFI(pPldAmfStatus->amfInfo[guamiIdx]))
                {
                    VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "%s %s: amf:%d guamiIdx:%d has same amfSetId:x%x\n", __func__,
                        getCandiAmfTypeStr(candiAmfType), amfIdx, guamiIdx, ptCi->amf.reroute.amfSetId);
                    availAmf = TRUE;

                    //25A AMF selection
                    ptCi->gNBSelectedGuami.amf.regionId = GET_AMF_REGION_FROM_AMFI(pPldAmfStatus->amfInfo[guamiIdx]);
                    ptCi->gNBSelectedGuami.amf.setId    = GET_AMF_SET_FROM_AMFI(pPldAmfStatus->amfInfo[guamiIdx]);
                    ptCi->gNBSelectedGuami.amf.pointer  = GET_AMF_POINTER_FROM_AMFI(pPldAmfStatus->amfInfo[guamiIdx]);

                    VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "gNB Selected GUAMI(idx:%d) plmn.longId:%d, regionId:%d, setId:%d, pointer%d \n",
                        guamiIdx, ptCi->gNBSelectedGuami.plmn.longId, ptCi->gNBSelectedGuami.amf.regionId,
                        ptCi->gNBSelectedGuami.amf.setId, ptCi->gNBSelectedGuami.amf.pointer);
                }
                break;
            }
            default:
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "%s Invalid candiAmfType:%d\n", __func__, candiAmfType);
                break;
            }
        }
        if (availAmf == TRUE) break;
    }

    if (availAmf == FALSE)
    {
        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "%s %s: (AMF:%d NOT AVAIL) plmn:0x%x(%u)(sel:%d)\n", __func__,
            getCandiAmfTypeStr(candiAmfType), amfIdx, plmnLongId, plmnLongId, ptCi->ueInfo.selectedPlmnIdentity);
        return ERROR;
    }

    for (tnlIdx = 0; tnlIdx < MAX_TNL_PER_AMF; tnlIdx++)
    {
        PLDAmfTnlStatus *pPldAmfTnlStatus = &pCfg->amf.pldAmfTnlStatus[pldGnbIdx][amfIdx][tnlIdx];
        PLDAmfTnlSctpState *pPldAmfTnlSctpState = &pCfg->amf.pldAmfTnlSctpState[pldGnbIdx][amfIdx][tnlIdx];

#if F_StandardConformance_AsnNgap >= 1803
        // Check AMF has available TNL 
        if ((pPldAmfTnlStatus->status == EQUIP) && (pPldAmfTnlSctpState->sctpState == OpState_enabled) &&
            (pPldAmfTnlStatus->weightFactor != 0) &&
            ((pPldAmfTnlStatus->tnlUsage == NGAP_ue) || (pPldAmfTnlStatus->tnlUsage == NGAP_TNLAssociationUsage_both)))
#else
        if ((pPldAmfTnlStatus->status == EQUIP) && (pPldAmfTnlSctpState->sctpState == OpState_enabled) &&
            (pPldAmfTnlStatus->weightFactor != 0) &&
            ((pPldAmfTnlStatus->tnlUsage == NGAP_ue) || (pPldAmfTnlStatus->tnlUsage == NGAP_both)))
        // Check AMF has available TNL
#endif
        {
            availTnl = TRUE;
            break;
        }
    }
    if (availTnl == FALSE)
    {
        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "%s %s: (AMF:%d NOT AVAIL) no available tnl in amf:%d\n", __func__,
            getCandiAmfTypeStr(candiAmfType), amfIdx, amfIdx);
        return ERROR;
    }

    if (GOOD != VRRM_CheckAmfOverloadAction(ptCi, pldGnbIdx, amfIdx))
    {
        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "%s %s: (AMF:%d NOT AVAIL) amf:%d is overloaded\n", __func__,
            getCandiAmfTypeStr(candiAmfType), amfIdx, amfIdx);
        return ERROR;
    }

    VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "%s %s: (AMF:%d AVAIL) amf:%d tnl is available\n", __func__,
        getCandiAmfTypeStr(candiAmfType), amfIdx, amfIdx);

    return GOOD;
}

/**
 *  @brief   Select AMF with S-TMSI or registered AMF information received from UE
 **/
static int VRRM_SelectUeBasedAmf(
    callInfo_type *ptCi, uint16_t pldGnbIdx, uint32_t plmnLongId, uint16_t *pSelectedAmf, uint8_t candiAmfType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(pldGnbIdx, MAX_GNB_PER_SYS);
    VALID_E_POINT_CHECK_ERROR(pSelectedAmf);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(candiAmfType, MAX_CANDI_AMF_TYPE);
    VccbCfgInfo_type *const pCfg = CFG;
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    int amfIdx, guamiIdx;

    VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "ueIdType:%d, amfSetPointer(S+P):x%x, amfIdentifierFlag:%d, amfIdentifier(R+S+P):x%x guamiT:(%d,x%x)\n",
        ptCi->ueInfo.ueId.ueIdType, ptCi->ueInfo.ueId.sTmsi.amfSetPointer, ptCi->ueInfo.registeredAmf.amfIdentifierFlag,
        ptCi->ueInfo.registeredAmf.amfIdentifier, ptCi->ueInfo.guamiTypePresent, ptCi->ueInfo.guamiType);

    // 5G-S-TMSI based selection
    if (ptCi->ueInfo.ueId.ueIdType == ciSTMSI)
    {
        for (amfIdx = 0; amfIdx < MAX_AMF_PER_GNB_CU_CP; amfIdx++)
        {
            if (GOOD != VRRM_IsAvailableAmf(ptCi, pldGnbIdx, plmnLongId, static_cast<uint16_t>(amfIdx), 0, 0, candiAmfType)) continue;

            PLDAmfStatus *pPldAmfStatus = &pCfg->amf.pldAmfStatus[pldGnbIdx][amfIdx];

            for (guamiIdx = 0; (guamiIdx < pPldAmfStatus->servedGuamiCnt) && (guamiIdx < MAX_SERVED_GUAMI_PER_AMF);
                 guamiIdx++)
            {
                // sTmsi is ng-5G-S-TMSI in RRCSetupComplete or
                // combination of ng-5G-S-TMSI-Part1 in RRCSetupRequest and ng-5G-S-TMSI-Part2 in RRCSetupComplete
                if (ptCi->ueInfo.ueId.sTmsi.amfSetPointer ==
                    GET_AMF_SET_POINTER_FROM_AMFI(pPldAmfStatus->amfInfo[guamiIdx]))
                {
                    // AMF selected
                    *pSelectedAmf = static_cast<uint16_t>(amfIdx);

                    VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "[AMF:%d SELECTED] guamiIdx:%d amfSetPointer(S+P):x%x\n", amfIdx,
                        guamiIdx, ptCi->ueInfo.ueId.sTmsi.amfSetPointer);
                    return GOOD;
                }
            }
        }

        VCCB_PRINT_CALL_ERROR(ptCi, "%s no sTmsi matched amf (ueIdType:%d amfSetPointer(S+P):x%x)\n", __func__,
            ptCi->ueInfo.ueId.ueIdType, ptCi->ueInfo.ueId.sTmsi.amfSetPointer);
    }
    // registeredAMF based selection
    else if (ptCi->ueInfo.registeredAmf.amfIdentifierFlag == VCCB_FLAG_ON)
    {
        if (pGnb->cfg.guamiTypeAmfSelectionOnOff == VCCB_FLAG_ON && ptCi->ueInfo.guamiTypePresent == VCCB_FLAG_ON) 
        {
            for (amfIdx = 0; amfIdx < MAX_AMF_PER_GNB_CU_CP; amfIdx++)
            {
                if (GOOD != VRRM_IsAvailableAmf(ptCi, pldGnbIdx, plmnLongId, static_cast<uint16_t>(amfIdx), 0, 0, candiAmfType)) continue;

                PLDAmfStatus *pPldAmfStatus = &pCfg->amf.pldAmfStatus[pldGnbIdx][amfIdx];

                /* GUAMI Type based AMF selection
                   1.If there is a GUAMI that matches both the registeredAMF and
                   the guami-type sent by the UE in the served GUAMI list of gNB, select the GUAMI.*/
                for (guamiIdx = 0; (guamiIdx < pPldAmfStatus->servedGuamiCnt) && (guamiIdx < MAX_SERVED_GUAMI_PER_AMF); guamiIdx++)
                {
                    if ( ((ptCi->ueInfo.registeredAmf.amfIdentifier == pPldAmfStatus->amfInfo[guamiIdx]) &&
                         ((ptCi->ueInfo.guamiType == NRRRC_native && pPldAmfStatus->guamiType[guamiIdx] == AMFGuamiType_NATIVE) ||   //0x80
                          (ptCi->ueInfo.guamiType == NRRRC_mapped && pPldAmfStatus->guamiType[guamiIdx] == AMFGuamiType_MAPPED) )) ) //0x81
                    {
                        *pSelectedAmf = static_cast<uint16_t>(amfIdx);

                        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "[AMF:%d SELECTED] guamiType Present guamiIdx:%d amfIdentifier(R+S+P):x%x guamiType:x%x\n", amfIdx,
                            guamiIdx, ptCi->ueInfo.registeredAmf.amfIdentifier, pPldAmfStatus->guamiType[guamiIdx]);
                        return GOOD;
                    }
                }
            }

            for (amfIdx = 0; amfIdx < MAX_AMF_PER_GNB_CU_CP; amfIdx++)
            {
                if (GOOD != VRRM_IsAvailableAmf(ptCi, pldGnbIdx, plmnLongId, static_cast<uint16_t>(amfIdx), 0, 0, candiAmfType)) continue;

                PLDAmfStatus *pPldAmfStatus = &pCfg->amf.pldAmfStatus[pldGnbIdx][amfIdx];

                /* 2.If there is no GUAMI that matches both the registeredAMF and
                    the guami-type sent by the UE in the served GUAMI list of gNB,
                    select the GUAMI if there is a GUAMI (GUAMI Type = not present) that is the same as
                    the registeredAMF sent by the UE and does not have the guami-type. */
                for (guamiIdx = 0; (guamiIdx < pPldAmfStatus->servedGuamiCnt) && (guamiIdx < MAX_SERVED_GUAMI_PER_AMF); guamiIdx++)
                {
                    if ( ((ptCi->ueInfo.registeredAmf.amfIdentifier == pPldAmfStatus->amfInfo[guamiIdx]) &&
                          (pPldAmfStatus->guamiType[guamiIdx] == AMFGuamiType_NOT_PRESENT)) ) //0x00
                    {
                        *pSelectedAmf = static_cast<uint16_t>(amfIdx);

                        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "[AMF:%d SELECTED] guamiType Not Present guamiIdx:%d amfIdentifier(R+S+P):x%x guamiType:x%x\n", amfIdx,
                            guamiIdx, ptCi->ueInfo.registeredAmf.amfIdentifier, pPldAmfStatus->guamiType[guamiIdx]);
                        return GOOD;
                    }
                }
                /*3.If there is no GUAMI that matches both the registeredAMF and the guami-type sent by the UE in the served GUAMI list of gNB,
                    and there is no GUAMI (GUAMI Type = not present) that is the same as the registeredAMF sent by the UE and does not have the guami-type,
                    return ERROR and then RAC-based AMF selection is performed.*/
            }
        }
        else
        {
            for (amfIdx = 0; amfIdx < MAX_AMF_PER_GNB_CU_CP; amfIdx++)
            {
                if (GOOD != VRRM_IsAvailableAmf(ptCi, pldGnbIdx, plmnLongId, static_cast<uint16_t>(amfIdx), 0, 0, candiAmfType)) continue;

                PLDAmfStatus *pPldAmfStatus = &pCfg->amf.pldAmfStatus[pldGnbIdx][amfIdx];

                for (guamiIdx = 0; (guamiIdx < pPldAmfStatus->servedGuamiCnt) && (guamiIdx < MAX_SERVED_GUAMI_PER_AMF); guamiIdx++)
                {
                    // AMF-Identifier (AMFI) comprises of an AMF Region ID, an AMF Set ID and an AMF Pointer
                    if (ptCi->ueInfo.registeredAmf.amfIdentifier == pPldAmfStatus->amfInfo[guamiIdx])
                    {
                        // AMF selected
                        *pSelectedAmf = static_cast<uint16_t>(amfIdx);

                        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "[AMF:%d SELECTED] guamiIdx:%d amfIdentifier(R+S+P):x%x\n", amfIdx,
                            guamiIdx, ptCi->ueInfo.registeredAmf.amfIdentifier);
                        return GOOD;
                    }
                }
            }
        }

        VCCB_PRINT_CALL_ERROR(ptCi, "%s no registeredAMF matched amf (amfIdentifierFlag:%d amfIdentifier(R+S+P):x%x) guamiT:(%d,x%x)\n",
            __func__, ptCi->ueInfo.registeredAmf.amfIdentifierFlag, ptCi->ueInfo.registeredAmf.amfIdentifier, 
            ptCi->ueInfo.guamiTypePresent, ptCi->ueInfo.guamiType);
    }

    return ERROR;
}

/**
 *  @brief   Select AMF with AMF's capacity based
 **/
static int VRRM_SelectCapacityBasedAmf(
    callInfo_type *ptCi, uint16_t pldGnbIdx, uint32_t plmnLongId, uint8_t candiAmfType, uint16_t *pSelectedAmf)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(pldGnbIdx, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(candiAmfType, MAX_CANDI_AMF_TYPE);
    VALID_E_POINT_CHECK_ERROR(pSelectedAmf);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VccbCfgInfo_type *const pCfg = CFG;

    unsigned int selectedLoopIdx = 0;
    uint16_t candiCnt = 0, totalCapa = 0;
    uint16_t maxSuppSnssaiCnt = 0;
    uint16_t amfSuppSnssaiCnt[MAX_AMF_PER_GNB_CU_CP] = {
        0,
    };
    CandidateAmf_type candidateAmf[MAX_AMF_PER_GNB_CU_CP];
    int amfIdx;

    memset(candidateAmf, 0, sizeof(candidateAmf));

    if (candiAmfType == AMONG_MAX_SUPP_UE_S_NSSAI_AMF)
    {
        for (amfIdx = 0; amfIdx < MAX_AMF_PER_GNB_CU_CP; amfIdx++)
        {
            PLDAmfPlmnInfo *pPldAmfPlmnInfo = &pCfg->amf.pldAmfPlmnInfo[pldGnbIdx][amfIdx];

            uint16_t suppSnssaiCnt = 0;
            if (GOOD != VRRM_GetAmfSupportedSnssaiCnt(ptCi, plmnLongId, static_cast<uint16_t>(amfIdx), pPldAmfPlmnInfo, &suppSnssaiCnt))
                continue;

            amfSuppSnssaiCnt[amfIdx] = suppSnssaiCnt;
            if (maxSuppSnssaiCnt < amfSuppSnssaiCnt[amfIdx]) maxSuppSnssaiCnt = amfSuppSnssaiCnt[amfIdx];
        }
    }

    for (amfIdx = 0; amfIdx < MAX_AMF_PER_GNB_CU_CP; amfIdx++)
    {
        if ((candiAmfType == AMONG_DIFF_AMF_SAME_AMF_SET_ID) && (amfIdx == ptCi->endPointInfo.ngIdx))
        {
            VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "%s %s continue amfIdx(%d), it is same with ptCi->endPointInfo.ngIdx(%d)\n",
                __func__, getCandiAmfTypeStr(candiAmfType), amfIdx, ptCi->endPointInfo.ngIdx);
            continue;
        }
        if ((candiAmfType == AMONG_SAME_AMF_SAME_AMF_SET_ID) && (amfIdx != ptCi->endPointInfo.ngIdx))
        {
            VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "%s %s continue amfIdx(%d), it is diff with ptCi->endPointInfo.ngIdx(%d)\n",
                __func__, getCandiAmfTypeStr(candiAmfType), amfIdx, ptCi->endPointInfo.ngIdx);
            continue;
        }

        if (GOOD != VRRM_IsAvailableAmf(
                        ptCi, pldGnbIdx, plmnLongId, static_cast<uint16_t>(amfIdx), amfSuppSnssaiCnt[amfIdx], maxSuppSnssaiCnt, candiAmfType))
            continue;

        PLDAmfStatus *pPldAmfStatus = &pCfg->amf.pldAmfStatus[pldGnbIdx][amfIdx];

        candidateAmf[candiCnt].amfIdx = static_cast<uint16_t>(amfIdx);
        candidateAmf[candiCnt].capa = static_cast<uint16_t>(pPldAmfStatus->relativeAmfCapacity);
        totalCapa = static_cast<uint16_t>(totalCapa + pPldAmfStatus->relativeAmfCapacity);
        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "%s %s: [%d] candidate amf:%d plmn:0x%x(%u)(sel:%d) capa:%d guamiCnt:%d\n", __func__,
            getCandiAmfTypeStr(candiAmfType), candiCnt, amfIdx, plmnLongId, plmnLongId,
            ptCi->ueInfo.selectedPlmnIdentity, pPldAmfStatus->relativeAmfCapacity, pPldAmfStatus->servedGuamiCnt);

        candiCnt++;
    }

    if (candiCnt == 0)  // no candidate AMF
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "%s no capa based candidate amf (plmn:0x%x(%u)(sel:%d))\n", __func__, plmnLongId,
            plmnLongId, ptCi->ueInfo.selectedPlmnIdentity);
        if (candiAmfType == AMONG_SAME_UE_AMF_SET_ID_AMF)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "%s ueIdType:%d amfSetP:x%x set:x%x/amfIdFlag:%d amfId:x%x set:x%x\n", __func__,
                ptCi->ueInfo.ueId.ueIdType, ptCi->ueInfo.ueId.sTmsi.amfSetPointer,
                GET_AMF_SET_FROM_AMFI(ptCi->ueInfo.ueId.sTmsi.amfSetPointer),
                ptCi->ueInfo.registeredAmf.amfIdentifierFlag, ptCi->ueInfo.registeredAmf.amfIdentifier,
                GET_AMF_SET_FROM_AMFI(ptCi->ueInfo.registeredAmf.amfIdentifier));
        }
        else if (candiAmfType == AMONG_SAME_REROUTE_AMF_SET_ID_AMF)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "%s reroute.amfSetId:x%x endPointInfo.ngIdx:%d\n", __func__,
                ptCi->amf.reroute.amfSetId, ptCi->endPointInfo.ngIdx);
        }
        return ERROR;
    }

    if (totalCapa == 0)  // every candidate AMF's capa is 0
    {
        candiCnt = MIN(candiCnt, MAX_AMF_PER_GNB_CU_CP);

        // random selection
        selectedLoopIdx = FnVCCB_GetRandomValue(__func__, ptCi->gnbNum, candiCnt);
        VCCB_CHECK_E_RANGE_AND_RETURN(selectedLoopIdx, MAX_AMF_PER_GNB_CU_CP);

        // AMF selected
        *pSelectedAmf = candidateAmf[selectedLoopIdx].amfIdx;

        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "[AMF:%d SELECTED] rand totalCapa:%d candiCnt:%d loopIdx:%d\n", *pSelectedAmf,
            totalCapa, candiCnt, selectedLoopIdx);
        return GOOD;
    }
    else
    {
        // capacity based random selection
        const unsigned int randCapaIdx = FnVCCB_GetRandomValue(__func__, ptCi->gnbNum, totalCapa);
        uint16_t sumOfCapa = 0;

        VCCB_CHECK_E_RANGE_AND_RETURN(randCapaIdx, UINT_MAX);

        for (selectedLoopIdx = 0; selectedLoopIdx < candiCnt && selectedLoopIdx < MAX_AMF_PER_GNB_CU_CP;
             selectedLoopIdx++)
        {
            sumOfCapa = static_cast<uint16_t>(sumOfCapa + candidateAmf[selectedLoopIdx].capa);
            if (randCapaIdx < sumOfCapa)
            {
                // AMF selected
                *pSelectedAmf = candidateAmf[selectedLoopIdx].amfIdx;

                VCCB_PRINT_CALL_AMF_SELECTION(ptCi,
                    "[AMF:%d SELECTED] capa rand totalCapa:%d randCapaIdx:%d sumOfCapa:%d loopIdx:%d\n", *pSelectedAmf,
                    totalCapa, randCapaIdx, sumOfCapa, selectedLoopIdx);
                return GOOD;
            }
        }
    }

    return ERROR;
}

/**
 *  @brief   Select TNL with TNL's weightFactor
 **/
static int VRRM_SelectTnl(
    callInfo_type *ptCi, uint16_t pldGnbIdx, uint16_t selectedAmf, uint16_t *pSelectedTnl, uint8_t isIgnoredCurrentTNL)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(pldGnbIdx, MAX_GNB_PER_SYS);
    VALID_E_POINT_CHECK_ERROR(pSelectedTnl);
    VCCB_CHECK_E_RANGE_AND_RETURN(selectedAmf, MAX_AMF_PER_GNB_CU_CP);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VccbCfgInfo_type *const pCfg = CFG;

    uint16_t candiCnt = 0, selectedLoopIdx = 0, totalCapa = 0;
    CandidateTnl_type candidateTnl[MAX_TNL_PER_AMF];
    CandidateTnl_type maxWfTnl[MAX_TNL_PER_AMF];
    int tnlIdx;
    MdsIp_Type xnReceivedTnlAddr;

    memset(candidateTnl, 0, sizeof(candidateTnl));
    memset(maxWfTnl, 0, sizeof(maxWfTnl));

    if (VCCB_FLAG_ON == GET_XN_RECEIVED_AMF_EXIST_FLAG(ptCi))
    {
        xnReceivedTnlAddr = GET_XN_RECEIVED_TNL_ADDR(ptCi);
    }

    for (tnlIdx = 0; tnlIdx < MAX_TNL_PER_AMF; tnlIdx++)
    {
        if ((isIgnoredCurrentTNL == TRUE) && (tnlIdx == ptCi->endPointInfo.ngTnlIdx))
        {
            VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "In case of TNL Binding, Ignore the existing TNL.\n");
            continue;
        }

        PLDAmfTnlStatus *pPldAmfTnlStatus = &pCfg->amf.pldAmfTnlStatus[pldGnbIdx][selectedAmf][tnlIdx];
        PLDAmfTnlSctpState *pPldAmfTnlSctpState = &pCfg->amf.pldAmfTnlSctpState[pldGnbIdx][selectedAmf][tnlIdx];

#if F_StandardConformance_AsnNgap >= 1803
        if ((pPldAmfTnlStatus->status == EQUIP) && (pPldAmfTnlSctpState->sctpState == OpState_enabled) &&
            (pPldAmfTnlStatus->weightFactor != 0) &&
            ((pPldAmfTnlStatus->tnlUsage == NGAP_ue) || (pPldAmfTnlStatus->tnlUsage == NGAP_TNLAssociationUsage_both)))
        {
            if (VCCB_FLAG_ON == GET_XN_RECEIVED_AMF_EXIST_FLAG(ptCi))
            {
                if (MDS_IPV4 == xnReceivedTnlAddr.IpVer && pPldAmfTnlStatus->tnlIPv4 == xnReceivedTnlAddr.Ip.V4)
                {
                    *pSelectedTnl = static_cast<uint16_t>(tnlIdx);
                    VCCB_PRINT_CALL_COMMENT(ptCi, "[AMF:%d TNL:%d SELECTED] by XN Received Tnl Addr Information \n",
                        selectedAmf, *pSelectedTnl);

                    INIT_XN_RECEIVED_TNL_ADDR_INFO(ptCi);
                    return GOOD;
                }
                else if ((MDS_IPV6 == xnReceivedTnlAddr.IpVer) &&
                         !memcmp(xnReceivedTnlAddr.Ip.V6, pPldAmfTnlStatus->tnlIPv6, ADDRLEN_IPV6))
                {
                    *pSelectedTnl = static_cast<uint16_t>(tnlIdx);
                    VCCB_PRINT_CALL_COMMENT(ptCi, "[AMF:%d TNL:%d SELECTED] by XN Received Tnl Addr Information \n",
                        selectedAmf, *pSelectedTnl);

                    INIT_XN_RECEIVED_TNL_ADDR_INFO(ptCi);
                    return GOOD;
                }
            }

            candidateTnl[candiCnt].tnlIdx = static_cast<uint16_t>(tnlIdx);
            candidateTnl[candiCnt].weightFactor = static_cast<uint16_t>(pPldAmfTnlStatus->weightFactor);
            totalCapa = static_cast<uint16_t>(totalCapa + pPldAmfTnlStatus->weightFactor);
            VCCB_PRINT_CALL_AMF_SELECTION(
                ptCi, "%s [%d] candidate tnl:%d Wf:%d\n", __func__, candiCnt, tnlIdx, pPldAmfTnlStatus->weightFactor);

            candiCnt++;
        }
#else 
        if ((pPldAmfTnlStatus->status == EQUIP) && (pPldAmfTnlSctpState->sctpState == OpState_enabled) &&
            (pPldAmfTnlStatus->weightFactor != 0) &&
            ((pPldAmfTnlStatus->tnlUsage == NGAP_ue) || (pPldAmfTnlStatus->tnlUsage == NGAP_both)))
        {
            if (VCCB_FLAG_ON == GET_XN_RECEIVED_AMF_EXIST_FLAG(ptCi))
            {
                if (MDS_IPV4 == xnReceivedTnlAddr.IpVer && pPldAmfTnlStatus->tnlIPv4 == xnReceivedTnlAddr.Ip.V4)
                {
                    *pSelectedTnl = static_cast<uint16_t>(tnlIdx);
                    VCCB_PRINT_CALL_COMMENT(ptCi, "[AMF:%d TNL:%d SELECTED] by XN Received Tnl Addr Information \n",
                        selectedAmf, *pSelectedTnl);

                    INIT_XN_RECEIVED_TNL_ADDR_INFO(ptCi);
                    return GOOD;
                }
                else if ((MDS_IPV6 == xnReceivedTnlAddr.IpVer) &&
                         !memcmp(xnReceivedTnlAddr.Ip.V6, pPldAmfTnlStatus->tnlIPv6, ADDRLEN_IPV6))
                {
                    *pSelectedTnl = static_cast<uint16_t>(tnlIdx);
                    VCCB_PRINT_CALL_COMMENT(ptCi, "[AMF:%d TNL:%d SELECTED] by XN Received Tnl Addr Information \n",
                        selectedAmf, *pSelectedTnl);

                    INIT_XN_RECEIVED_TNL_ADDR_INFO(ptCi);
                    return GOOD;
                }
            }

            candidateTnl[candiCnt].tnlIdx = static_cast<uint16_t>(tnlIdx);
            candidateTnl[candiCnt].weightFactor = static_cast<uint16_t>(pPldAmfTnlStatus->weightFactor);
            totalCapa = static_cast<uint16_t>(totalCapa + pPldAmfTnlStatus->weightFactor);
            VCCB_PRINT_CALL_AMF_SELECTION(
                ptCi, "%s [%d] candidate tnl:%d Wf:%d\n", __func__, candiCnt, tnlIdx, pPldAmfTnlStatus->weightFactor);

            candiCnt++;
        }
#endif
    }

    if (candiCnt == 0)  // no candidate TNL
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "%s no candidate tnl (selectedAmf:%d)\n", __func__, selectedAmf);
        return ERROR;
    }

    // Weight factor based random selection
    const unsigned int randCapaIdx = FnVCCB_GetRandomValue(__func__, ptCi->gnbNum, totalCapa);
    uint16_t sumOfCapa = 0;

    VCCB_CHECK_E_RANGE_AND_RETURN(randCapaIdx, UINT_MAX);

    for (selectedLoopIdx = 0; selectedLoopIdx < candiCnt && selectedLoopIdx < MAX_TNL_PER_AMF; selectedLoopIdx++)
    {
        sumOfCapa = static_cast<uint16_t>(sumOfCapa + candidateTnl[selectedLoopIdx].weightFactor);
        if (randCapaIdx < sumOfCapa)
        {
            // TNL selected
            *pSelectedTnl = candidateTnl[selectedLoopIdx].tnlIdx;

            VCCB_PRINT_CALL_AMF_SELECTION(ptCi,
                "[AMF:%d TNL:%d SELECTED] capa rand totalCapa:%d randCapaIdx:%d sumOfCapa:%d loopIdx:%d\n", selectedAmf,
                *pSelectedTnl, totalCapa, randCapaIdx, sumOfCapa, selectedLoopIdx);

            return GOOD;
        }
    }

    return ERROR;
}

/**
 *  @brief   Select AMF and TNL based on UE message
 **/
static int VRRM_SelectUeBasedAmfAndTnl(callInfo_type *ptCi, uint16_t pldGnbIdx, uint32_t plmnLongId,
    uint16_t *pSelectedAmf, uint16_t *pSelectedTnl, uint8_t candiAmfType)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(pldGnbIdx, MAX_GNB_PER_SYS);
    VALID_E_POINT_CHECK_ERROR(pSelectedAmf);
    VALID_E_POINT_CHECK_ERROR(pSelectedTnl);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(candiAmfType, MAX_CANDI_AMF_TYPE);

    int ret;

    ret = VRRM_SelectUeBasedAmf(ptCi, pldGnbIdx, plmnLongId, pSelectedAmf, candiAmfType);
    if (ret == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Fail to VRRM_SelectUeBasedAmf\n");
        return ERROR;
    }

    ret = VRRM_SelectTnl(ptCi, pldGnbIdx, *pSelectedAmf, pSelectedTnl, FALSE);
    if (ret == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Fail to VRRM_SelectTnl(Amf:%d)\n", *pSelectedAmf);
        return ERROR;
    }

    return GOOD;
}

/**
 *  @brief   Select AMF and TNL based on AMF's capacity
 **/
static int VRRM_SelectCapaBasedAmfAndTnl(callInfo_type *ptCi, uint16_t pldGnbIdx, uint32_t plmnLongId,
    uint8_t candiAmfType, uint16_t *pSelectedAmf, uint16_t *pSelectedTnl)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(pldGnbIdx, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(candiAmfType, MAX_CANDI_AMF_TYPE);
    VALID_E_POINT_CHECK_ERROR(pSelectedAmf);
    VALID_E_POINT_CHECK_ERROR(pSelectedTnl);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    int ret;

    ret = VRRM_SelectCapacityBasedAmf(ptCi, pldGnbIdx, plmnLongId, candiAmfType, pSelectedAmf);
    if (ret == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Fail to VRRM_SelectCapacityBasedAmf (%s(%d))\n", getCandiAmfTypeStr(candiAmfType), candiAmfType);
        return ERROR;
    }

    ret = VRRM_SelectTnl(ptCi, pldGnbIdx, *pSelectedAmf, pSelectedTnl, FALSE);
    if (ret == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Fail to VRRM_SelectTnl(Amf:%d)\n", *pSelectedAmf);
        return ERROR;
    }

    return GOOD;
}

/**
 *  @brief   Find Amf Index by the guami
 **/
int16_t VRRM_getAmfIdxByGuamiInfo(callInfo_type *ptCi, uint16_t pldGnbIdx, ho_guami_type guami, uint16_t *amfIdx)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(amfIdx);
    VCCB_CHECK_E_RANGE_AND_RETURN(pldGnbIdx, MAX_GNB_PER_SYS);
    VccbCfgInfo_type *const pCfg = CFG;

    uint16_t amf_idx, guami_idx;
    PLDAmfStatus *pPldAmfStatus = NULL;

    *amfIdx = MAX_AMF_PER_GNB_CU_CP;

    // find the guami from DB
    for (amf_idx = 0; amf_idx < MAX_AMF_PER_GNB_CU_CP; amf_idx++)
    {
        pPldAmfStatus = &pCfg->amf.pldAmfStatus[pldGnbIdx][amf_idx];

        if ((pPldAmfStatus->status != EQUIP) || (pPldAmfStatus->serviceState != OpState_enabled)) continue;

        for (guami_idx = 0; guami_idx < MIN(pPldAmfStatus->servedGuamiCnt, MAX_SERVED_GUAMI_PER_AMF); guami_idx++)
        {
            if (guami.plmn.longId != pPldAmfStatus->plmn[guami_idx]) continue;

            if (VCCB_FLAG_ON == GET_XN_RECEIVED_AMF_EXIST_FLAG(ptCi))
            {
                if ((guami.amf.setId == GET_AMF_SET_FROM_AMFI(pPldAmfStatus->amfInfo[guami_idx])) &&
                    (guami.amf.regionId == GET_AMF_REGION_FROM_AMFI(pPldAmfStatus->amfInfo[guami_idx])))
                {
                    // compare regionId, if cell exist same regionId Amf, then set fail cause Unknown GUAMI ID,
                    // else, doesn't exist same regionId Amf, then set fail cause Invalid AMF Set ID
                    SET_XN_AMF_CALL_FAULT_CAUSE(ptCi, AMF_ASSIGN_FAIL_UNKNOWN_GUAMI_ID);
                }
            }

            if ((uint32_t)GET_AMFI_FROM_REGION_SET_POINTER(guami.amf.regionId, guami.amf.setId, guami.amf.pointer) !=
                (pPldAmfStatus->amfInfo[guami_idx]))
                continue;

            // If GUAMI is found in the Served GUAMI List, the loop is ended. ( for guami_idx )
            break;
        }

        // If GUAMI is found in the Served GUAMI List, the loop is ended. ( for amf_idx )
        if (guami_idx < MIN(pPldAmfStatus->servedGuamiCnt, MAX_SERVED_GUAMI_PER_AMF)) break;
    }
    if (amf_idx >= MAX_AMF_PER_GNB_CU_CP)
    {
        return ERROR;
    }

    *amfIdx = amf_idx;

    return GOOD;

}  // }}}

/**
 *  @brief   Select AMF and TNL by Guami
 **/
int VRRM_AMFSelectionByGuami(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint16_t pldGnbIdx;
    uint16_t selectedAmf = MAX_AMF_PER_GNB_CU_CP;
    uint16_t selectedTnl = MAX_TNL_PER_AMF;
    int ret;

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
#ifdef __NVGNB__
    pldGnbIdx = ptCi->gnbNum;
#else
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    if (TRUE == FOO.VF_MultipleOperatorRanSupport)
    {
        pldGnbIdx = ptCi->gnbNum;
    }
    else
    {
        pldGnbIdx = MAX_GNB_PER_SYS;

        if (ERROR == VRRM_GetAmfStatusPldGnbIdxFromGnbId(pGnb->globalGnbId.gnbId.id, &pldGnbIdx))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Fail to GetAmfStatusPldGnbIdxFromGnbId(gnbId:%u)\n", pGnb->globalGnbId.gnbId.id);

            return ERROR;
        }
    }
#endif

    ret = VRRM_getAmfIdxByGuamiInfo(ptCi, pldGnbIdx, ptCi->servedGuami, &selectedAmf);
    if (ret == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Fail to VRRM_getAmfIdxByGuamiInfo\n");
        return ERROR;
    }

    ret = VRRM_SelectTnl(ptCi, pldGnbIdx, selectedAmf, &selectedTnl, FALSE);
    if (ret == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Fail to VRRM_SelectTnl(Amf:%d)\n", selectedTnl);
        return ERROR;
    }

    CHECK_AND_SET_NG_AND_TNL_IDX(selectedAmf, selectedTnl);
    VCCB_PRINT_CALL_AMF_SELECTION(
        ptCi, "VRRM_AMFSelectionByGuami(Amf:%d,Tnl:%d)\n", ptCi->endPointInfo.ngIdx, ptCi->endPointInfo.ngTnlIdx);

    return GOOD;
}

/**
 *  @brief   Select AMF and TNL
 **/
int VRRM_AMFSelection(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    const VccbCfgInfo_type *const pCfg = CFG;
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    int ret;
    uint16_t selectedAmf = MAX_AMF_PER_GNB_CU_CP;
    uint16_t selectedTnl = MAX_TNL_PER_AMF;
    uint8_t candiAmfType;
    uint16_t pldGnbIdx;
    uint32_t plmnLongId;

    // for debugging purpose
    if (pCfg->amf.amfSelectionMode == AMFSelectionMode_Debug)
    {
        CHECK_AND_SET_NG_AND_TNL_IDX(pCfg->amf.dbgAmfIdx, pCfg->amf.dbgTnlIdx);
        VCCB_PRINT_CALL_ERROR(ptCi, "[DEBUG TEST] SelectCapaBasedAmfAndTnl(Amf:%d,Tnl:%d,reloc:%d)\n",
            ptCi->endPointInfo.ngIdx, ptCi->endPointInfo.ngTnlIdx, pGnb->cfg.amfRelocationOption);
        return GOOD;
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    // get gnbIdx from gnbId
#ifdef __NVGNB__
    pldGnbIdx = ptCi->gnbNum;
#else
    if (TRUE == FOO.VF_MultipleOperatorRanSupport)
    {
        pldGnbIdx = ptCi->gnbNum;
    }
    else
    {
        pldGnbIdx = MAX_GNB_PER_SYS;

        if (ERROR == VRRM_GetAmfStatusPldGnbIdxFromGnbId(pGnb->globalGnbId.gnbId.id, &pldGnbIdx))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Fail to GetAmfStatusPldGnbIdxFromGnbId(gnbId:%u)\n", pGnb->globalGnbId.gnbId.id);
            // amfSetPointer or registredAmf exist
            if ((ptCi->ueInfo.ueId.ueIdType == ciSTMSI) ||
                (ptCi->ueInfo.registeredAmf.amfIdentifierFlag == VCCB_FLAG_ON))
            {
                // CALL FAULT
                MACRO_CALL_FAULT_SAVE(NRRRC_RrcSetupComplete_id, CauseCpInternalSaNotExistAmf);
            }
            else
            {
                // CALL FAULT
                MACRO_CALL_FAULT_SAVE(NRRRC_RrcSetupComplete_id, CauseCpInternalSaAvailableAmfNotExist);
            }
            goto AMF_SELECTION_FAIL;
        }
    }
#endif

    plmnLongId = ptCi->ueInfo.servedPlmn.longId;
    // amfSetPointer or registredAmf exist
    if ((ptCi->ueInfo.ueId.ueIdType == ciSTMSI) || (ptCi->ueInfo.registeredAmf.amfIdentifierFlag == VCCB_FLAG_ON))
    {
        candiAmfType = AMONG_ALL_AMF;
        ret = VRRM_SelectUeBasedAmfAndTnl(ptCi, pldGnbIdx, plmnLongId, &selectedAmf, &selectedTnl, candiAmfType);
        if (ret == GOOD)
        {
            CHECK_AND_SET_NG_AND_TNL_IDX(selectedAmf, selectedTnl);
            VCCB_PRINT_CALL_AMF_SELECTION(
                ptCi, "SelectUeBasedAmfAndTnl(Amf:%d,Tnl:%d)\n", ptCi->endPointInfo.ngIdx, ptCi->endPointInfo.ngTnlIdx);
            return GOOD;
        }

        // support direct amf relocation
        if (FnVCCB_IsSupportDirectAmfRelocation(ptCi->gnbNum))
        {
            // [20A] capa based selection among AMFs have same AMF Set ID in case of AMF relocation
            candiAmfType = AMONG_SAME_UE_AMF_SET_ID_AMF;
            ret = VRRM_SelectCapaBasedAmfAndTnl(ptCi, pldGnbIdx, plmnLongId, candiAmfType, &selectedAmf, &selectedTnl);
            if (ret == GOOD)

            {
                CHECK_AND_SET_NG_AND_TNL_IDX(selectedAmf, selectedTnl);
                VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "SelectCapaBasedAmfAndTnl (%s/Amf:%d,Tnl:%d/reloc:%d)\n",
                    getCandiAmfTypeStr(candiAmfType), ptCi->endPointInfo.ngIdx, ptCi->endPointInfo.ngTnlIdx,
                    pGnb->cfg.amfRelocationOption);
                return GOOD;
            }
        }
        else  // not support direct amf relocation
        {
            // CALL FAULT
            MACRO_CALL_FAULT_SAVE(NRRRC_RrcSetupComplete_id, CauseCpInternalSaNotExistAmf);
            goto AMF_SELECTION_FAIL;
        }
    }
    else if (ptCi->ueInfo.networkSlice.numSnssai > 0)  // S-NSSAI exist
    {
        // [20A] capa based selection among AMFs support the largest number of S-NSSAIs
        candiAmfType = AMONG_MAX_SUPP_UE_S_NSSAI_AMF;
        ret = VRRM_SelectCapaBasedAmfAndTnl(ptCi, pldGnbIdx, plmnLongId, candiAmfType, &selectedAmf, &selectedTnl);
        if (ret == GOOD)
        {
            CHECK_AND_SET_NG_AND_TNL_IDX(selectedAmf, selectedTnl);
            VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "SelectCapaBasedAmfAndTnl (%s/Amf:%d,Tnl:%d)\n", getCandiAmfTypeStr(candiAmfType),
                ptCi->endPointInfo.ngIdx, ptCi->endPointInfo.ngTnlIdx);
            return GOOD;
        }
        else
        {
            // CALL FAULT
            MACRO_CALL_FAULT_SAVE(NRRRC_RrcSetupComplete_id, CauseCpInternalSaAvailableAmfNotExist);
            goto AMF_SELECTION_FAIL;
        }
    }

    candiAmfType = AMONG_ALL_AMF;
    ret = VRRM_SelectCapaBasedAmfAndTnl(ptCi, pldGnbIdx, plmnLongId, candiAmfType, &selectedAmf, &selectedTnl);
    if (ret == GOOD)
    {
        CHECK_AND_SET_NG_AND_TNL_IDX(selectedAmf, selectedTnl);
        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "SelectCapaBasedAmfAndTnl (%s/Amf:%d,Tnl:%d/reloc:%d)\n",
            getCandiAmfTypeStr(candiAmfType), ptCi->endPointInfo.ngIdx, ptCi->endPointInfo.ngTnlIdx,
            pGnb->cfg.amfRelocationOption);
        return GOOD;
    }

    // CALL FAULT
    MACRO_CALL_FAULT_SAVE(NRRRC_RrcSetupComplete_id, CauseCpInternalSaAvailableAmfNotExist);

AMF_SELECTION_FAIL:
    VCCB_PRINT_CALL_ERROR(ptCi, "Fail to SelectAmfAndTnl(reloc:%d)\n", pGnb->cfg.amfRelocationOption);
    VRRM_PrintPLDAmfAndTnlData(ptCi, pldGnbIdx);
    return ERROR;
}

int VRRM_CheckGuamiAvailCurrentAMF(callInfo_type *ptCi, uint8_t isHO, uint16_t *pldGnbIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

#ifdef VCCB_IPC_TEST
    if (DBG->testAmfSelection == FALSE)
    {
        VCCB_PRINT_MSG("Test AmfSelection FALSE\n");
        return GOOD;
    }
    else
        VCCB_PRINT_MSG("Test AmfSelection TRUE\n");
#endif

    //If gNB have not received the GUAMI from the AMF, do not check it.
    if (ptCi->servedGuami.amf.setId == INVALID_AMF_SET_ID)
    {
        VCCB_PRINT_CALL_AMF_SELECTION(
            ptCi, "servedGuami invalid setId:%x do not check it\n", ptCi->servedGuami.amf.setId);
        return GOOD;
    }

    VccbCfgInfo_type *const pCfg = CFG;
    PLDAmfStatus *pPldAmfStatus;
    int guami_idx;

    // get gnbIdx from gnbId
#ifdef __NVGNB__
    *pldGnbIdx = ptCi->gnbNum;
#else
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    if (TRUE == FOO.VF_MultipleOperatorRanSupport)
    {
        *pldGnbIdx = ptCi->gnbNum;
    }
    else
    {
        *pldGnbIdx = MAX_GNB_PER_SYS;

        if (ERROR == VRRM_GetAmfStatusPldGnbIdxFromGnbId(pGnb->globalGnbId.gnbId.id, pldGnbIdx))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Fail to GetAmfStatusPldGnbIdxFromGnbId(gnbId:%u)\n", pGnb->globalGnbId.gnbId.id);
            VCCB_PRINT_CALL_ERROR(
                ptCi, "%s : Fail to VRRM_CheckGuamiAvailCurrentAMF(Amf:%d)\n", __func__, ptCi->endPointInfo.ngIdx);
            return ERROR;
        }
        VCCB_CHECK_E_RANGE_AND_RETURN(*pldGnbIdx, MAX_GNB_PER_SYS);
    }
#endif

    pPldAmfStatus = &pCfg->amf.pldAmfStatus[*pldGnbIdx][ptCi->endPointInfo.ngIdx];

    if ((isHO == TRUE) || (ptCi->gNBSelectedGumaiFlag == FALSE))
    {
        for (guami_idx = 0; guami_idx < MIN(pPldAmfStatus->servedGuamiCnt, MAX_SERVED_GUAMI_PER_AMF); guami_idx++)
        {
            if (ptCi->servedGuami.plmn.longId != pPldAmfStatus->plmn[guami_idx])
            {
                continue;
            }

            if ((uint32_t)GET_AMFI_FROM_REGION_SET_POINTER(ptCi->servedGuami.amf.regionId, ptCi->servedGuami.amf.setId,
                ptCi->servedGuami.amf.pointer) == (pPldAmfStatus->amfInfo[guami_idx]))
            {
                VCCB_PRINT_CALL_AMF_SELECTION(
                    ptCi, "Find available Guami isHO:%d gNBSelectedGumaiFlag:%d (pldGnbIdx:%u, ngIdx:%u, amf(%X/%u/%u/%u)!!!\n",
                    isHO, ptCi->gNBSelectedGumaiFlag, *pldGnbIdx, ptCi->endPointInfo.ngIdx, ptCi->servedGuami.plmn.longId, 
                    (unsigned)ptCi->servedGuami.amf.regionId, (unsigned)ptCi->servedGuami.amf.setId, (unsigned)ptCi->servedGuami.amf.pointer); 
                return GOOD;
            }
        }

        VCCB_PRINT_CALL_ERROR(
            ptCi, "There is no available Guami isHO:%d gNBSelectedGumaiFlag:%d (pldGnbIdx:%u, ngIdx:%u, amf(%X/%u/%u/%u)) Reselect Amf!!!\n",
            isHO, ptCi->gNBSelectedGumaiFlag, *pldGnbIdx, ptCi->endPointInfo.ngIdx, ptCi->servedGuami.plmn.longId, 
            (unsigned)ptCi->servedGuami.amf.regionId, (unsigned)ptCi->servedGuami.amf.setId, (unsigned)ptCi->servedGuami.amf.pointer); 
        return ERROR;
    }
    else
    {
        for (guami_idx = 0; guami_idx < MIN(pPldAmfStatus->servedGuamiCnt, MAX_SERVED_GUAMI_PER_AMF); guami_idx++)
        {
            if (ptCi->gNBSelectedGuami.plmn.longId != pPldAmfStatus->plmn[guami_idx])
            {
                continue;
            }

            if ((uint32_t)GET_AMFI_FROM_REGION_SET_POINTER(ptCi->gNBSelectedGuami.amf.regionId, ptCi->gNBSelectedGuami.amf.setId,
                ptCi->gNBSelectedGuami.amf.pointer) == (pPldAmfStatus->amfInfo[guami_idx]))
            {
                VCCB_PRINT_CALL_AMF_SELECTION(
                    ptCi, "Find available Guami isHO:%d gNBSelectedGumaiFlag:%d (pldGnbIdx:%u, ngIdx:%u, amf(%X/%u/%u/%u)!!!\n",
                    isHO, ptCi->gNBSelectedGumaiFlag, *pldGnbIdx, ptCi->endPointInfo.ngIdx, ptCi->gNBSelectedGuami.plmn.longId, 
                    (unsigned)ptCi->gNBSelectedGuami.amf.regionId, (unsigned)ptCi->gNBSelectedGuami.amf.setId, (unsigned)ptCi->gNBSelectedGuami.amf.pointer);
                return GOOD;
            }
        }

        VCCB_PRINT_CALL_ERROR(
            ptCi, "There is no available Guami isHO:%d gNBSelectedGumaiFlag:%d (pldGnbIdx:%u, ngIdx:%u, amf(%X/%u/%u/%u)) Reselect Amf!!!\n",
            isHO, ptCi->gNBSelectedGumaiFlag, *pldGnbIdx, ptCi->endPointInfo.ngIdx, ptCi->gNBSelectedGuami.plmn.longId, 
            (unsigned)ptCi->gNBSelectedGuami.amf.regionId, (unsigned)ptCi->gNBSelectedGuami.amf.setId, (unsigned)ptCi->gNBSelectedGuami.amf.pointer); 
        return ERROR;
    }
}

int VRRM_AMFSelectionForULNgapMessage(callInfo_type *ptCi, uint16_t pldGnbIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    int ret;
    uint16_t selectedAmf = MAX_AMF_PER_GNB_CU_CP;
    uint16_t selectedTnl = MAX_TNL_PER_AMF;
    int status;
    uint32_t plmnLongId = ptCi->ueInfo.servedPlmn.longId;

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    //Other GUAMI(s) with the same AMF Set ID in the current AMF are available
    uint8_t candiAmfType = AMONG_SAME_AMF_SAME_AMF_SET_ID;
    VCCB_PRINT_CALL_AMF_SELECTION(
        ptCi, "Start ReSelectCapaBaseAMF(%s)\n", getCandiAmfTypeStr(candiAmfType));

    ret = VRRM_SelectCapaBasedAmfAndTnl(ptCi, pldGnbIdx, plmnLongId, candiAmfType, &selectedAmf, &selectedTnl);
    if (ret == GOOD)
    {
        CHECK_AND_SET_NG_AND_TNL_IDX(selectedAmf, selectedTnl);
        ptCi->gNBSelectedGumaiFlag = TRUE;
        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "SelectCApabasedAmfAndTnl candiAmfType:%s : Amf:%d, Tnl:%d)\n",
            getCandiAmfTypeStr(candiAmfType), ptCi->endPointInfo.ngIdx, ptCi->endPointInfo.ngTnlIdx);
        return GOOD;
    }
    else //Reselect AMF within the same AMF Set
    {
        candiAmfType = AMONG_DIFF_AMF_SAME_AMF_SET_ID;
        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "There is no available Amf and Tnl! ReSelectCapaBaseAMF(%s)\n",
            getCandiAmfTypeStr(candiAmfType));
        ret = VRRM_SelectCapaBasedAmfAndTnl(ptCi, pldGnbIdx, plmnLongId, candiAmfType, &selectedAmf, &selectedTnl);
        if (ret == GOOD)
        {
            CHECK_AND_SET_NG_AND_TNL_IDX(selectedAmf, selectedTnl);
            // send notification to VNMB
            status = VIIL_sendCallResourceChangeInd(ptCi);
            if (status == ERROR)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_sendCallResourceChangeInd ERROR!\n");
            }
            ptCi->gNBSelectedGumaiFlag = TRUE;
            VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "SelectCapaBasedAmfAndTnl (candiAmfType:%s : Amf:%d, Tnl:%d)\n",
                getCandiAmfTypeStr(candiAmfType), ptCi->endPointInfo.ngIdx, ptCi->endPointInfo.ngTnlIdx);
                return GOOD;
        }
        VCCB_PRINT_CALL_ERROR(ptCi, "%s %s : Fail to VRRM_AMFSelectionForULNgapMessage(Amf:%d)\n", __func__,
            getCandiAmfTypeStr(candiAmfType), ptCi->endPointInfo.ngIdx);
        return ERROR;
    }

    return GOOD;
}

int VRRM_AMFSelectionForDLNgapMessage(callInfo_type *ptCi, message_type *ptAll)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptAll);

    PLDAmfStatus *pPldAmfStatus;
    uint16_t pldGnbIdx;
    int guami_idx;
    VccbCfgInfo_type *const pCfg = CFG;
    uint8_t availGUAMI = FALSE;
    SctpDataType *ptSctpDataInd = (SctpDataType *)ptAll;

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

#ifdef VCCB_IPC_TEST
    if (DBG->testAmfSelection == FALSE)
    {
        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "Test AmfSelection FALSE\n");
        return GOOD;
    }
    else
        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "Test AmfSelection TRUE\n");
#endif

    // get gnbIdx from gnbId
#ifdef __NVGNB__
    pldGnbIdx = ptCi->gnbNum;
#else
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    if (TRUE == FOO.VF_MultipleOperatorRanSupport)
    {
        pldGnbIdx = ptCi->gnbNum;
    }
    else
    {
        pldGnbIdx = MAX_GNB_PER_SYS;

        if (ERROR == VRRM_GetAmfStatusPldGnbIdxFromGnbId(pGnb->globalGnbId.gnbId.id, &pldGnbIdx))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Fail to GetAmfStatusPldGnbIdxFromGnbId(gnbId:%u)\n", pGnb->globalGnbId.gnbId.id);
            VCCB_PRINT_CALL_ERROR(
                ptCi, "%s : Fail to VRRM_AMFSelectionForDLNgapMessage(Amf:%d)\n", __func__, ptCi->endPointInfo.ngIdx);
            return ERROR;
        }
        VCCB_CHECK_E_RANGE_AND_RETURN(pldGnbIdx, MAX_GNB_PER_SYS);
    }
#endif

    if (ptSctpDataInd->endPointIdx != ptCi->endPointInfo.ngIdx)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ptSctpDataInd->endPointIdx(%d) != ptCi->endPointInfo.ngIdx(%d) in VRRM_AMFSelectionForDLNgapMessage\n",
            ptSctpDataInd->endPointIdx, ptCi->endPointInfo.ngIdx);

        //Update endPointInfo.ngIdxc and  gnbSelectedGuami
        ptCi->endPointInfo.ngIdx = ptSctpDataInd->endPointIdx;

        //select gNB GUAMI from same AMF SET ID
        pPldAmfStatus = &pCfg->amf.pldAmfStatus[pldGnbIdx][ptCi->endPointInfo.ngIdx];

        for (guami_idx = 0; guami_idx < MIN(pPldAmfStatus->servedGuamiCnt, MAX_SERVED_GUAMI_PER_AMF); guami_idx++)
        {
            if (ptCi->servedGuami.amf.setId == GET_AMF_SET_FROM_AMFI(pPldAmfStatus->amfInfo[guami_idx]))
            {
                ptCi->gNBSelectedGuami.amf.regionId = GET_AMF_REGION_FROM_AMFI(pPldAmfStatus->amfInfo[guami_idx]);
                ptCi->gNBSelectedGuami.amf.setId    = GET_AMF_SET_FROM_AMFI(pPldAmfStatus->amfInfo[guami_idx]);
                ptCi->gNBSelectedGuami.amf.pointer  = GET_AMF_POINTER_FROM_AMFI(pPldAmfStatus->amfInfo[guami_idx]);

                VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "gNB Selected GUAMI(idx:%d) plmn.longId:%d, regionId:%d, setId:%d, pointer%d \n",
                    guami_idx, ptCi->gNBSelectedGuami.plmn.longId, ptCi->gNBSelectedGuami.amf.regionId,
                    ptCi->gNBSelectedGuami.amf.setId, ptCi->gNBSelectedGuami.amf.pointer);

                availGUAMI = TRUE;
                break;
            }
        }

        if (availGUAMI == FALSE)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "There is no Available GUAMI with SAME AMF Set ID:%d\n", ptCi->gNBSelectedGuami.amf.setId);
            return ERROR;
        }
        ptCi->gNBSelectedGumaiFlag = TRUE;
    }

    if (ptSctpDataInd->tnlIdx != ptCi->endPointInfo.ngTnlIdx)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "ptSctpDataInd->tnlIdx(%d) != ptCi->endPointInfo.ngTnlIdx(%d) in VRRM_AMFSelectionForDLNgapMessage\n",
            ptSctpDataInd->endPointIdx, ptCi->endPointInfo.ngIdx);
        //Update ngTnlIdx
        ptCi->endPointInfo.ngTnlIdx = ptSctpDataInd->tnlIdx;
    }

    return GOOD;
}

/**
 *  @brief   Find Amf Index by the PLMN
 **/
int16_t VRRM_GetAmfIdxByPlmn(callInfo_type *ptCi, uint16_t pldGnbIdx, plmnId_type plmnId, uint32_t *pSelectedAmf)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pSelectedAmf);
    VCCB_CHECK_E_RANGE_AND_RETURN(pldGnbIdx, MAX_GNB_PER_SYS);

    VccbCfgInfo_type *const pCfg = CFG;
    uint16_t amfIdx = 0, plmnIdx = 0, suppPlmnCnt = 0;
    PLDAmfStatus *pPldAmfStatus = NULL;
    PLDAmfPlmnInfo *pPldAmfPlmnInfo = NULL;

    // find the plmnId from DB
    for (amfIdx = 0; amfIdx < MAX_AMF_PER_GNB_CU_CP; amfIdx++)
    {
        pPldAmfStatus = &pCfg->amf.pldAmfStatus[pldGnbIdx][amfIdx];
        pPldAmfPlmnInfo = &pCfg->amf.pldAmfPlmnInfo[pldGnbIdx][amfIdx];

        if ((pPldAmfStatus->status != EQUIP || pPldAmfPlmnInfo->status != EQUIP) || (pPldAmfStatus->serviceState != OpState_enabled)) continue;

        suppPlmnCnt = MIN(pPldAmfPlmnInfo->supportedPlmnCnt, MAX_PLMN_PER_AMF);

        for (plmnIdx = 0; plmnIdx < suppPlmnCnt; plmnIdx++)
        {
            if (plmnId.longId == pPldAmfPlmnInfo->supportedPlmn[plmnIdx]) break;
        }

        if (plmnIdx < suppPlmnCnt)
        {
            *pSelectedAmf = pPldAmfStatus->endPointIdx;
            break;
        }
    }

    if (*pSelectedAmf >= MAX_AMF_PER_GNB_CU_CP)
    {
        return ERROR;
    }

    return GOOD;
}

/**
 *  @brief   Select AMF with SIB1 PLMN list
 **/
int VRRM_AMFSelectionForRanConfigTransfer(callInfo_type *ptCi, uint32_t *pSelectedAmf)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pSelectedAmf);

    uint16_t pldGnbIdx;
    *pSelectedAmf = MAX_AMF_PER_GNB_CU_CP;

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

#ifdef __NVGNB__
    pldGnbIdx = ptCi->gnbNum;
#else
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (TRUE == FOO.VF_MultipleOperatorRanSupport)
    {
        pldGnbIdx = ptCi->gnbNum;
    }
    else
    {
        pldGnbIdx = MAX_GNB_PER_SYS;

        if (ERROR == VRRM_GetAmfStatusPldGnbIdxFromGnbId(pGnb->globalGnbId.gnbId.id, &pldGnbIdx))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Fail to GetAmfStatusPldGnbIdxFromGnbId(gnbId:%u)\n", pGnb->globalGnbId.gnbId.id);

            return ERROR;
        }
    }
#endif

    // Check if AMF is exist based on SIB1 PLMN (FSG-SF0509(FR21)/FSG-SF0510(FR41))
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    uint32_t infoIdx = 0, idIdx = 0;
    uint32_t numPlmnInfo = 0, numPlmnId = 0;

    numPlmnInfo = MIN(pCell->sib1.plmn_IdentityInfoList.nrofPLMN_IdentityInfo, MAX_NUM_PLMN);

    for (infoIdx = 0; infoIdx < numPlmnInfo; infoIdx++)
    {
        PLMN_IdentityInfo_type *pPlmnInfo = &pCell->sib1.plmn_IdentityInfoList.plmn_IdentityInfo[infoIdx];
        numPlmnId = MIN(pPlmnInfo->plmn_IdentityList.nrofPLMN_Identity, MAX_NUM_PLMN);

        for (idIdx = 0; idIdx < numPlmnId; idIdx++)
        {
            plmnId_type *pPlmn = &pPlmnInfo->plmn_IdentityList.plmn_Identity[idIdx];

            if (GOOD == VRRM_GetAmfIdxByPlmn(ptCi, pldGnbIdx, *pPlmn, pSelectedAmf))
            {
                memcpy(&ptCi->mroInfo.plmnForNgSelectedTai, pPlmn, sizeof(plmnId_type));

                VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "AMF selection in VRRM_AMFSelectionForRanConfigTransfer (sib-plmn:%X) \n", pPlmn->longId);

                return GOOD;
            }
        }
    }

    VCCB_PRINT_CALL_ERROR(ptCi, "No AMF selected in VRRM_AMFSelectionForRanConfigTransfer \n");
    
    return ERROR;
}

/**
 *  @brief   Select AMF and TNL for reroute
 **/
int VRRM_AMFSelectionForReroute(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    const VccbCfgInfo_type *const pCfg = CFG;

    int ret;
    uint16_t pldGnbIdx;
    uint16_t selectedAmf = MAX_AMF_PER_GNB_CU_CP;
    uint16_t selectedTnl = MAX_TNL_PER_AMF;
    uint8_t candiAmfType = AMONG_SAME_REROUTE_AMF_SET_ID_AMF;
    uint32_t plmnLongId;

    // for debugging purpose
    if (pCfg->amf.amfSelectionMode == AMFSelectionMode_Debug)
    {
        CHECK_AND_SET_NG_AND_TNL_IDX(pCfg->amf.dbgAmfIdx, pCfg->amf.dbgTnlIdx);
        VCCB_PRINT_CALL_ERROR(ptCi, "[DEBUG TEST] SelectCapaBasedAmfAndTnl(Amf:%d,Tnl:%d)\n", ptCi->endPointInfo.ngIdx,
            ptCi->endPointInfo.ngTnlIdx);
        return GOOD;
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    // get gnbIdx from gnbId
#ifdef __NVGNB__
    pldGnbIdx = ptCi->gnbNum;
#else
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    if (TRUE == FOO.VF_MultipleOperatorRanSupport)
    {
        pldGnbIdx = ptCi->gnbNum;
    }
    else
    {
        pldGnbIdx = MAX_GNB_PER_SYS;

        if (ERROR == VRRM_GetAmfStatusPldGnbIdxFromGnbId(pGnb->globalGnbId.gnbId.id, &pldGnbIdx))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Fail to GetAmfStatusPldGnbIdxFromGnbId(gnbId:%u)\n", pGnb->globalGnbId.gnbId.id);
            goto REROUTE_AMF_SELECTION_FAIL;
        }
    }
#endif

    plmnLongId = ptCi->ueInfo.servedPlmn.longId;
    ret = VRRM_SelectCapaBasedAmfAndTnl(ptCi, pldGnbIdx, plmnLongId, candiAmfType, &selectedAmf, &selectedTnl);
    if (ret == GOOD)
    {
        CHECK_AND_SET_NG_AND_TNL_IDX(selectedAmf, selectedTnl);
        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "SelectCapaBasedAmfAndTnl (%s/Amf:%d,Tnl:%d)\n", getCandiAmfTypeStr(candiAmfType),
            ptCi->endPointInfo.ngIdx, ptCi->endPointInfo.ngTnlIdx);
        return GOOD;
    }

#ifndef __NVGNB__
REROUTE_AMF_SELECTION_FAIL:
#endif
    VCCB_PRINT_CALL_ERROR(ptCi, "Fail to SelectAmfAndTnl for reroute (initAMF:%d/reroute.amfSetId:x%x(%d))\n",
        ptCi->endPointInfo.ngIdx, ptCi->amf.reroute.amfSetId, ptCi->amf.reroute.amfSetId);
    VRRM_PrintPLDAmfAndTnlData(ptCi, pldGnbIdx);
    return ERROR;
}

int16_t VRRM_getAmfTnlAddr(callInfo_type *ptCi, uint16_t amfIdx, uint16_t tnlIdx, MdsIp_Type *pMdsIp)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMdsIp);
    VCCB_CHECK_E_RANGE_AND_RETURN(amfIdx, MAX_AMF_PER_GNB_CU_CP);
    VCCB_CHECK_E_RANGE_AND_RETURN(tnlIdx, MAX_TNL_PER_AMF);
    VccbCfgInfo_type *const pCfg = CFG;

    uint16_t pldGnbIdx;
    PLDAmfTnlStatus *pPldAmfTnlStatus;
    PLDAmfTnlSctpState *pPldAmfTnlSctpState;

    // get gnbIdx from gnbId
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
#ifdef __NVGNB__
    pldGnbIdx = ptCi->gnbNum;
#else
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    if (TRUE == FOO.VF_MultipleOperatorRanSupport)
    {
        pldGnbIdx = ptCi->gnbNum;
    }
    else
    {
        pldGnbIdx = MAX_GNB_PER_SYS;

        if (ERROR == VRRM_GetAmfStatusPldGnbIdxFromGnbId(pGnb->globalGnbId.gnbId.id, &pldGnbIdx))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Fail to VRRM_GetAmfStatusPldGnbIdxFromGnbId(gnbId:%u)\n", pGnb->globalGnbId.gnbId.id);

            VRRM_PrintPLDAmfAndTnlData(ptCi, pldGnbIdx);

            return ERROR;
        }
        VCCB_CHECK_E_RANGE_AND_RETURN(pldGnbIdx, MAX_GNB_PER_SYS);
    }
#endif

    pPldAmfTnlStatus = &pCfg->amf.pldAmfTnlStatus[pldGnbIdx][amfIdx][tnlIdx];
    pPldAmfTnlSctpState = &pCfg->amf.pldAmfTnlSctpState[pldGnbIdx][amfIdx][tnlIdx];
#if F_StandardConformance_AsnNgap >= 1803
    if ((pPldAmfTnlStatus->status == EQUIP) && (pPldAmfTnlSctpState->sctpState == OpState_enabled) &&
        (pPldAmfTnlStatus->weightFactor != 0) &&
        ((pPldAmfTnlStatus->tnlUsage == NGAP_ue) || (pPldAmfTnlStatus->tnlUsage == NGAP_TNLAssociationUsage_both)))
    {
        pMdsIp->IpVer = pPldAmfTnlStatus->ipVer;
        if (pMdsIp->IpVer == MDS_IPV4)
        {
            pMdsIp->Ip.V4 = pPldAmfTnlStatus->tnlIPv4;
        }
        else
        {
            memcpy(&pMdsIp->Ip.V6[0], &pPldAmfTnlStatus->tnlIPv6[0], sizeof(pPldAmfTnlStatus->tnlIPv6));
        }

        return GOOD;
    }
#else 
    if ((pPldAmfTnlStatus->status == EQUIP) && (pPldAmfTnlSctpState->sctpState == OpState_enabled) &&
        (pPldAmfTnlStatus->weightFactor != 0) &&
        ((pPldAmfTnlStatus->tnlUsage == NGAP_ue) || (pPldAmfTnlStatus->tnlUsage == NGAP_both)))
    {
        pMdsIp->IpVer = pPldAmfTnlStatus->ipVer;
        if (pMdsIp->IpVer == MDS_IPV4)
        {
            pMdsIp->Ip.V4 = pPldAmfTnlStatus->tnlIPv4;
        }
        else
        {
            memcpy(&pMdsIp->Ip.V6[0], &pPldAmfTnlStatus->tnlIPv6[0], sizeof(pPldAmfTnlStatus->tnlIPv6));
        }

        return GOOD;
    }
#endif

    return ERROR;
}

/**
 *  @brief   Get PLDAmfStatus Pointer using GnbId and NgIdx
 *           - PLMN is obtained using the GUAMI of the UE. After that, it searches the Served GUAMI List of AMF to
 *obtain supportable PLDAmfStatus information.
 **/
int16_t VRRM_getPldAmfStatusFromGnbIdAndNgIdx(
    callInfo_type *ptCi, int ngIdx, ho_guami_type guami, PLDAmfStatus **ppOutPldAmfStatus)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ppOutPldAmfStatus);
    VccbCfgInfo_type *const pCfg = CFG;

    uint16_t amfIdx;
    PLDAmfStatus *pPldAmfStatus = NULL;

    // set init value
    *ppOutPldAmfStatus = NULL;

    // find the amf
    // get gnbIdx from gnbId
    uint16_t pldGnbIdx = MAX_GNB_PER_SYS;
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
#ifdef __NVGNB__
    pldGnbIdx = ptCi->gnbNum;
#else
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    if (TRUE == FOO.VF_MultipleOperatorRanSupport)
    {
        pldGnbIdx = ptCi->gnbNum;
    }
    else
    {
        if (ERROR == VRRM_GetAmfStatusPldGnbIdxFromGnbId(pGnb->globalGnbId.gnbId.id, &pldGnbIdx))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Fail to GetAmfStatusPldGnbIdxFromGnbId(gnbId:%u)\n", pGnb->globalGnbId.gnbId.id);

            return ERROR;
        }
    }
#endif
    // protection code
    VCCB_CHECK_E_RANGE_AND_RETURN(pldGnbIdx, MAX_GNB_PER_SYS);

    // get pldAmfStatus
    if (0 <= ngIdx && ngIdx < MAX_AMF_PER_GNB_CU_CP)  // If valid ngIdx
    {
        // use the ngIdx as AMF
        pPldAmfStatus = &pCfg->amf.pldAmfStatus[pldGnbIdx][ngIdx];
    }
    else
    {
        if (VRRM_getAmfIdxByGuamiInfo(ptCi, pldGnbIdx, guami, &amfIdx) == GOOD)
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(amfIdx, MAX_AMF_PER_GNB_CU_CP);
            // update the pointer of PldAmdStatus
            pPldAmfStatus = &pCfg->amf.pldAmfStatus[pldGnbIdx][amfIdx];
        }
        else
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Fail to find the guami(%llu)\n", 1ULL * guami.plmn.longId);

            return ERROR;
        }
    }

    // update the pointer of PldAmdStatus
    *ppOutPldAmfStatus = pPldAmfStatus;

    return GOOD;
}  // }}}

/**
 *  @brief This function provides the operation to initialize the AMF SET LIST.
 **/
void VRRM_InitSupportedAmfSetList(supportedAmfSetList_Type *p)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(p);

    p->num_plmn = 0;
    p->num_set = 0;
}  // }}}

/**
 *  @brief   Get AMF Supported PLMN by GUAMI
 *           - This is a function for obtaining PLMN List and REGION w/PLMN List supported by AMF.
 **/
int16_t VRRM_GetAmfSetList(callInfo_type *ptCi, int ngIdx, ho_guami_type guami, supportedAmfSetList_Type *p)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(p);

    uint16_t guami_idx;
    PLDAmfStatus *pPldAmfStatus = NULL;

    // init value
    VRRM_InitSupportedAmfSetList(p);

    if (ERROR == VRRM_getPldAmfStatusFromGnbIdAndNgIdx(ptCi, ngIdx, guami, &pPldAmfStatus))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Fail to VRRM_getPldAmfStatusFromGnbIdAndNgIdx(ngIdx:%u, amf:%X/%u/%u/%u)\n", ngIdx,
            guami.plmn.longId, (unsigned)guami.amf.regionId, (unsigned)guami.amf.setId, (unsigned)guami.amf.pointer);

        return ERROR;
    }

    // protection code
    VALID_E_POINT_CHECK_ERROR(pPldAmfStatus);

    if (pPldAmfStatus->status != EQUIP)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "pPldAmfStatus->status is N_EQUIP(%d) (ngIdx:%u, amf:%X/%u/%u/%u)\n",
            pPldAmfStatus->status, ngIdx, guami.plmn.longId, (unsigned)guami.amf.regionId, (unsigned)guami.amf.setId,
            (unsigned)guami.amf.pointer);

        return ERROR;
    }

    if (pPldAmfStatus->serviceState != OpState_enabled)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "pPldAmfStatus->serviceState is not OpState_enabled(%d) (ngIdx:%u, amf:%X/%u/%u/%u)\n",
            pPldAmfStatus->serviceState, ngIdx, guami.plmn.longId, (unsigned)guami.amf.regionId,
            (unsigned)guami.amf.setId, (unsigned)guami.amf.pointer);

        return ERROR;
    }

    // update the plmn and set information
    unsigned int num_plmn = 0;
    unsigned int num_set = 0;

    for (guami_idx = 0; guami_idx < MIN(pPldAmfStatus->servedGuamiCnt, MAX_SERVED_GUAMI_PER_AMF); guami_idx++)
    {
        // 1. plmn
        if (p->num_plmn < MAX_AMF_PLMN_PER_SUPPORTED_LIST)
        {
            // check the duplicated plmn
            for (num_plmn = 0; num_plmn < p->num_plmn; num_plmn++)
            {
                if (pPldAmfStatus->plmn[guami_idx] == p->amf_plmn[num_plmn].plmn.longId)
                {
                    VCCB_PRINT_CALL_LOG_PLMN(ptCi,
                        "Detect Duplicated PLMN (PLMN: %X, guami_idx:%d, num_plmn:%d, p->num_plmn:%d)\n",
                        p->amf_plmn[num_plmn].plmn.longId, guami_idx, num_plmn, p->num_plmn);
                    break;
                }
            }

            // update the plmn
            if (num_plmn >= p->num_plmn)
            {
                p->amf_plmn[p->num_plmn].plmn.longId = pPldAmfStatus->plmn[guami_idx];

                VCCB_PRINT_CALL_LOG_PLMN(ptCi,
                    "Update PLMN (PLMN: %X, guami_idx:%d, num_plmn:%d, p->num_plmn:%d)\n",
                        p->amf_plmn[num_plmn].plmn.longId, guami_idx, num_plmn, p->num_plmn);

                p->num_plmn++;
            }
        }

        // 2. set
        if (p->num_set < MAX_AMF_SET_PER_SUPPORTED_LIST)
        {
            // check the duplicated set info
            for (num_set = 0; num_set < p->num_set; num_set++)
            {
                if (pPldAmfStatus->plmn[guami_idx] == p->amf_set_info[num_set].plmn.longId &&
                    GET_AMF_REGION_FROM_AMFI(pPldAmfStatus->amfInfo[guami_idx]) == p->amf_set_info[num_set].region)
                {
                    VCCB_PRINT_CALL_LOG_PLMN(ptCi,
                        "Detect Duplicated AMF SET (PLMN: %X, REGION:%d, guami_idx:%d, "
                            "num_set:%d, p->num_set:%d)\n",
                            p->amf_set_info[num_set].plmn.longId, p->amf_set_info[num_set].region, guami_idx, num_set,
                            p->num_set);
                    break;
                }
            }

            // update the set information - not duple
            if (num_set >= p->num_set)
            {
                p->amf_set_info[p->num_set].plmn.longId = pPldAmfStatus->plmn[guami_idx];
                p->amf_set_info[p->num_set].region = GET_AMF_REGION_FROM_AMFI(pPldAmfStatus->amfInfo[guami_idx]);

                VCCB_PRINT_CALL_LOG_PLMN(ptCi,
                    "Update AMF SET (PLMN: %X, REGION:%d(in %u), guami_idx:%d, num_set:%d, p->num_set:%d)\n",
                    p->amf_set_info[num_set].plmn.longId,
                    GET_AMF_REGION_FROM_AMFI(pPldAmfStatus->amfInfo[guami_idx]), pPldAmfStatus->amfInfo[guami_idx],
                    guami_idx, num_set, p->num_set);

                p->num_set++;
            }
        }

        // 3. loop check - If plmn and set DB are Full, end loop.
        if (!(p->num_plmn < MAX_AMF_PLMN_PER_SUPPORTED_LIST && p->num_set < MAX_AMF_SET_PER_SUPPORTED_LIST))
        {
            VCCB_PRINT_CALL_LOG_PLMN(ptCi,
                "plmn and set DB are Full, end loop (guami:%d, p->num_plmn:%d, p->num_set:%d)\n", guami_idx,
                p->num_plmn, p->num_set);
            break;
        }
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "AMF Set and PLMN Information (num_plmn:%d, num_set:%d, servedGuamiCnt:%d)\n",
        p->num_plmn, p->num_set, pPldAmfStatus->servedGuamiCnt);

    return GOOD;
}  // }}}

int VRRM_AMFSelectionForTNLARelease(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VccbCfgInfo_type *const pCfg = CFG;

    int ret;
    uint16_t pldGnbIdx;
    uint16_t selectedAmf = MAX_AMF_PER_GNB_CU_CP;
    uint16_t selectedTnl = MAX_TNL_PER_AMF;
    uint8_t availGuami = FALSE;
    PLDAmfStatus *pPldAmfStatus;
    int guami_idx;
    int status;
    uint32_t plmnLongId = ptCi->ueInfo.servedPlmn.longId;

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    // get gnbIdx from gnbId
#ifdef __NVGNB__
    pldGnbIdx = ptCi->gnbNum;
#else
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    if (TRUE == FOO.VF_MultipleOperatorRanSupport)
    {
        pldGnbIdx = ptCi->gnbNum;
    }
    else
    {
        pldGnbIdx = MAX_GNB_PER_SYS;

        if (ERROR == VRRM_GetAmfStatusPldGnbIdxFromGnbId(pGnb->globalGnbId.gnbId.id, &pldGnbIdx))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Fail to GetAmfStatusPldGnbIdxFromGnbId(gnbId:%u)\n", pGnb->globalGnbId.gnbId.id);
            VCCB_PRINT_CALL_ERROR(
                ptCi, "%s : Fail to VRRM_AMFSelectionForTNLARelease(Amf:%d)\n", __func__, ptCi->endPointInfo.ngIdx);
            return ERROR;
        }
        VCCB_CHECK_E_RANGE_AND_RETURN(pldGnbIdx, MAX_GNB_PER_SYS);
    }
#endif

    VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "Start VRRM_AMFSelectionForTNLARelease!\n");

    ret = VRRM_SelectTnl(ptCi, pldGnbIdx, ptCi->endPointInfo.ngIdx, &selectedTnl, TRUE);
    // if the TNL is not available, select another amf with the same AMF_SET_ID and select TNL
    if (ret == ERROR)  // no TNL
    {
        uint8_t candiAmfType = AMONG_DIFF_AMF_SAME_AMF_SET_ID;
        VCCB_PRINT_CALL_AMF_SELECTION(
            ptCi, "VRRM_SelectTnl is Failed!\nStart SelectCapaBaseAMF(%s)\n", getCandiAmfTypeStr(candiAmfType));

        ret = VRRM_SelectCapaBasedAmfAndTnl(ptCi, pldGnbIdx, plmnLongId, candiAmfType, &selectedAmf, &selectedTnl);
        if (ret == GOOD)  // If selected the same AMF_SET_ID and TNL from other AMF, should send NOTI to VNMB
        {
            CHECK_AND_SET_NG_AND_TNL_IDX(selectedAmf, selectedTnl);
            // send notification to VNMB
            status = VIIL_sendCallResourceChangeInd(ptCi);
            if (status == ERROR)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_sendCallReasourceChangedInd ERROR!\n");
            }
            VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "SelectCApabasedAmfAndTnl candiAmfType:%s : Amf:%d, Tnl:%d)\n",
                getCandiAmfTypeStr(candiAmfType), ptCi->endPointInfo.ngIdx, ptCi->endPointInfo.ngTnlIdx);
            return GOOD;
        }
        VCCB_PRINT_CALL_ERROR(ptCi, "%s %s : Fail to VRRM_AMFSelectionForTNLARelease(Amf:%d)\n", __func__,
            getCandiAmfTypeStr(candiAmfType), ptCi->endPointInfo.ngIdx);
        return ERROR;
    }
    else  // available TNL
    {
        VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "selectedTnl(%d) is available\n", selectedTnl);

        pPldAmfStatus = &pCfg->amf.pldAmfStatus[pldGnbIdx][ptCi->endPointInfo.ngIdx];

        for (guami_idx = 0; guami_idx < MIN(pPldAmfStatus->servedGuamiCnt, MAX_SERVED_GUAMI_PER_AMF); guami_idx++)
        {
            VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "guami_idx : %d\n", guami_idx);
            if (ptCi->servedGuami.plmn.longId != pPldAmfStatus->plmn[guami_idx])
            {
                VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "ptCi->servedGuami.plmn.longId : %d, pPldAmfStatus->plmn[%d] : %d\n",
                    ptCi->servedGuami.plmn.longId, guami_idx, pPldAmfStatus->plmn[guami_idx]);
                continue;
            }
            if ((uint32_t)GET_AMFI_FROM_REGION_SET_POINTER(ptCi->servedGuami.amf.regionId, ptCi->servedGuami.amf.setId,
                    ptCi->servedGuami.amf.pointer) == (pPldAmfStatus->amfInfo[guami_idx]))
            {
                availGuami = TRUE;
                VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "Guami %d is available\n", guami_idx);
                break;
            }
        }
        if (availGuami == TRUE)
        {
            CHECK_AND_SET_NG_AND_TNL_IDX(ptCi->endPointInfo.ngIdx, selectedTnl);
            VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "SelectCapaBasedAmfAndTnl (Select Current AMf and another TNL Amf:%d, Tnl:%d)\n",
                ptCi->endPointInfo.ngIdx, ptCi->endPointInfo.ngTnlIdx);
            return GOOD;
        }
        else
        {
            uint8_t candiAmfType = AMONG_SAME_AMF_SAME_AMF_SET_ID;
            VCCB_PRINT_CALL_AMF_SELECTION(
                ptCi, "There is no available Guami!\nStart SelectCapaBaseAMF(%s)\n", getCandiAmfTypeStr(candiAmfType));
            ret = VRRM_SelectCapaBasedAmfAndTnl(ptCi, pldGnbIdx, plmnLongId, candiAmfType, &selectedAmf, &selectedTnl);

            if (ret == GOOD)
            {
                CHECK_AND_SET_NG_AND_TNL_IDX(selectedAmf, selectedTnl);
                VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "SelectCApabasedAmfAndTnl candiAmfType:%s : Amf:%d, Tnl:%d)\n",
                    getCandiAmfTypeStr(candiAmfType), ptCi->endPointInfo.ngIdx, ptCi->endPointInfo.ngTnlIdx);
                return GOOD;
            }
            else
            {
                candiAmfType = AMONG_DIFF_AMF_SAME_AMF_SET_ID;
                VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "There is no available Amf and Tnl!\nStart SelectCapaBaseAMF(%s)\n",
                    getCandiAmfTypeStr(candiAmfType));
                ret = VRRM_SelectCapaBasedAmfAndTnl(
                    ptCi, pldGnbIdx, plmnLongId, candiAmfType, &selectedAmf, &selectedTnl);
                if (ret == GOOD)
                {
                    CHECK_AND_SET_NG_AND_TNL_IDX(selectedAmf, selectedTnl);
                    // send notification to VNMB
                    status = VIIL_sendCallResourceChangeInd(ptCi);
                    if (status == ERROR)
                    {
                        VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_sendCallResourceChangeInd ERROR!\n");
                    }
                    VCCB_PRINT_CALL_AMF_SELECTION(ptCi, "SelectCapaBasedAmfAndTnl (candiAmfType:%s : Amf:%d, Tnl:%d)\n",
                        getCandiAmfTypeStr(candiAmfType), ptCi->endPointInfo.ngIdx, ptCi->endPointInfo.ngTnlIdx);
                    return GOOD;
                }
                VCCB_PRINT_CALL_ERROR(ptCi, "%s %s : Fail to VRRM_AMFSelectionForTNLARelease(Amf:%d)\n", __func__,
                    getCandiAmfTypeStr(candiAmfType), ptCi->endPointInfo.ngIdx);
                return ERROR;
            }
        }
    }
}

int FnVCCB_IsPLMNSupportedByAMF(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_E_RANGE_AND_FALSE(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_FALSE(ptCi->endPointInfo.ngIdx, MAX_AMF_PER_GNB_CU_CP);

    uint16_t pldGnbIndex;
    if (VCOM_getSystemType() == e_VCCB_NVGNB || (TRUE == FOO.VF_MultipleOperatorRanSupport))
    {
        pldGnbIndex = ptCi->gnbNum;
    }
    else
    {
        if (VRRM_GetAmfStatusPldGnbIdxFromGnbId(ptCi->gnbId, &pldGnbIndex) == ERROR)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Fail to GetAmfStatusPldGnbIdxFromGnbId(gnbId:%u)\n", ptCi->gnbId);
            return FALSE;
        }
    }

    const PLDAmfPlmnInfo *const pPldAmfPlmnInfo = &CFG->amf.pldAmfPlmnInfo[pldGnbIndex][ptCi->endPointInfo.ngIdx];
    for (uint32_t plmnIndex = 0; plmnIndex < UMIN(pPldAmfPlmnInfo->supportedPlmnCnt, MAX_PLMN_PER_AMF); ++plmnIndex)
    {
        if (pPldAmfPlmnInfo->supportedPlmn[plmnIndex] == ptCi->ueInfo.servedPlmn.longId)
        {
            return TRUE;
        }
    }
    return FALSE;
}
