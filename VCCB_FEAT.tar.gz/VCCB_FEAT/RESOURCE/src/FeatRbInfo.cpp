/****************************************************************
 * System      : 5G vNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatRbInfo.c
 * Description :
 * Author      :
 * Dept.       : 5G Call SW Lab.
 * Created     : 2023.02.24
 * Procedures defined :
 * Procedures called  :
 * Version     :
 * Revision history   :
 *          date      :
 *       revised by   :
 * revised information:
 ****************************************************************/
/*
 * @file FeatRbInfo.c
 * @brief This file contains functions related PDCP Configuration under RbInfo.
 */

#include "FeatRbInfo.h"

#include "ComInclude.h"
#include "ComLibUtility.h"
#include "FeatCallInfo.h"
#include "FeatUlPathControlENDC.h"
#include "FeatCommon.h"
#include "NRRRC.h"
#include "access_common_yang.h"

void FnVCCB_InitPdcpInfo(uint16_t gnbNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    uint16_t loop, loop1;

    // set clear profile data
    pdcpProfile_type *pPdcpProf = NULL;
    for (loop = 0; loop < MAX_PDCP_INFO_PROFILE_PER_GNB; loop++)
    {
        pPdcpProf = &pGnb->pdcpProfile[loop];
        pPdcpProf->status = N_EQUIP;
        pPdcpProf->maxSessionMnRatio = 50;      // Percentage 0 ~ 100% 
        pPdcpProf->maxSessionRohc = ci_maxROHC_Sessions_cs16;         // YANG Default
        pPdcpProf->maxSessionUlOnlyRohc = ci_maxROHC_Sessions_cs16;   // YANG Default

        for (loop1 = 0; loop1 < MAX_QCI_VALUE; loop1++)
        {
            pPdcpProf->pdcpInfoQci[loop1].shmStatus = N_EQUIP;
        }

        for (loop1 = 0; loop1 < MAX_5QI_VALUE; loop1++)
        {
            pPdcpProf->pdcpInfo5qi[loop1].shmStatus = N_EQUIP;
            pPdcpProf->pdcpInfo5qi[loop1].srcDlFwd = TRUE;
            pPdcpProf->pdcpInfo5qi[loop1].tgtDlFwd = TRUE;
            pPdcpProf->pdcpInfo5qi[loop1].tgtUlFwd = TRUE;
            pPdcpProf->pdcpInfo5qi[loop1].redCapSnSizeUl = pdcp_len12bits; // pdcp_len12bits(0) / pdcp_len18bits(1)
            pPdcpProf->pdcpInfo5qi[loop1].redCapSnSizeDl = pdcp_len12bits;
        }

        for (loop1 = 0; loop1 < MAX_SVC_GRP_CONFIG_ID; loop1++)
        {
            pPdcpProf->serviceBasedPdcpInfo[loop1].status = N_EQUIP;
            pPdcpProf->serviceBasedPdcpInfo[loop1].serviceGroupId = 0;
            pPdcpProf->serviceBasedPdcpInfo[loop1].pdcpInfo.shmStatus = N_EQUIP;
        }
    }

    return;
}


pdcpProfile_type *FnVCCB_GetPdcpProfile(uint16_t cellNum, uint16_t gnbNum)
{
    AUTO_TRACE_FUNC;
    pdcpProfile_type *pPdcpProfile = NULL;
    if (cellNum < MAX_CELL_NUM_VCCB)
    {
        VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

        uint8_t pdcpProfIdx = pCell->profileDBInfo.pdcpProfileIdx;
        if (gnbNum < MAX_GNB_PER_SYS && pdcpProfIdx < MAX_PDCP_INFO_PROFILE_PER_GNB)
        {
            VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

            if (pGnb->pdcpProfile[pdcpProfIdx].status == EQUIP)
            {
                pPdcpProfile = &pGnb->pdcpProfile[pdcpProfIdx];
            }
        }
    }

    return pPdcpProfile;
}

pdcpInfoQci_type *FnVCCB_GetPdcpInfoQci(uint16_t cellNum, uint16_t gnbNum, uint16_t qci)
{
    AUTO_TRACE_FUNC;
    pdcpInfoQci_type *pPdcpInfo = NULL;
    if (cellNum < MAX_CELL_NUM_VCCB)
    {
        VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

        uint8_t pdcpProfIdx = pCell->profileDBInfo.pdcpProfileIdx;
        if (gnbNum < MAX_GNB_PER_SYS && pdcpProfIdx < MAX_PDCP_INFO_PROFILE_PER_GNB)
        {
            VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

            if (pGnb->pdcpProfile[pdcpProfIdx].status == EQUIP)
            {
                if (qci < MAX_QCI_VALUE)
                {
                    pPdcpInfo = &pGnb->pdcpProfile[pdcpProfIdx].pdcpInfoQci[qci];
                }
            }
        }
    }

    return pPdcpInfo;
}

pdcpInfo5qi_type *FnVCCB_GetPdcpInfo5qi(uint16_t cellNum, uint16_t gnbNum, uint16_t fiveQi)
{
    AUTO_TRACE_FUNC;
    pdcpInfo5qi_type *pPdcpInfo = NULL;
    if (cellNum < MAX_CELL_NUM_VCCB)
    {
        VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

        uint8_t pdcpProfIdx = pCell->profileDBInfo.pdcpProfileIdx;
        if (gnbNum < MAX_GNB_PER_SYS && pdcpProfIdx < MAX_PDCP_INFO_PROFILE_PER_GNB)
        {
            VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

            if (pGnb->pdcpProfile[pdcpProfIdx].status == EQUIP)
            {
                if (fiveQi < MAX_5QI_VALUE)
                {
                    pPdcpInfo = &pGnb->pdcpProfile[pdcpProfIdx].pdcpInfo5qi[fiveQi];
                }
            }
        }
    }

    return pPdcpInfo;
}

pdcpInfo5qi_type *FnVCCB_GetPdcpInfoUsingServiceGroup(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint16_t cellNum, uint16_t gnbNum, uint16_t fiveQi)
{
    AUTO_TRACE_FUNC;
    VccbGnbInfo_type *pGnb = NULL;
    VccbCellInfo_type *pCell = NULL;
    pdcpProfile_type *pPdcpProfile = NULL;
    pdcpInfo5qi_type *pPdcpInfo = NULL;  // return variable

    if (ptCi != NULL && ptDi != NULL && (TRUE == FOO.VF_ServiceBasedPdcpInfo))
    {
        if (gnbNum < MAX_GNB_PER_SYS && cellNum < MAX_CELL_NUM_VCCB && ptCi->myThreadId < MAX_CALL_THREAD_NUM_VCCB)
        {
            pGnb = &GNBINFO[gnbNum];
            pCell = &CELLINFO[cellNum];

            uint8_t pdcpProfileIdx = pCell->profileDBInfo.pdcpProfileIdx;

            if (pGnb->serviceBasedPdcpOnOff == VCCB_FLAG_ON && pdcpProfileIdx < MAX_PDCP_INFO_PROFILE_PER_GNB)
            {
                pPdcpProfile = &pGnb->pdcpProfile[pdcpProfileIdx];

                if (pPdcpProfile->status == EQUIP)
                {
                    uint8_t svcGrpId = 0;
                    int16_t status = GOOD;
                    status = FnVCCB_GetServiceGroupIdByDrb(ptCi, &svcGrpId, ptDi, FALSE);
                    if (status == GOOD && svcGrpId != 0)   // if valid service group id is found, serviceGroupId can't be zero, valie range is (1 ~ 32)
                    {
                        for (uint8_t loop = 0; loop < MAX_SVC_GRP_CONFIG_ID; loop++)
                        {
                            if (pPdcpProfile->serviceBasedPdcpInfo[loop].status == EQUIP &&
                                pPdcpProfile->serviceBasedPdcpInfo[loop].serviceGroupId == svcGrpId)
                            {
                                pPdcpInfo = &THREAD_INFO->call[ptCi->myThreadId].buf.serviceBasedPdcpInfo;
                                memcpy(pPdcpInfo, &pPdcpProfile->serviceBasedPdcpInfo[loop].pdcpInfo, sizeof(pdcpInfo5qi_type));

                                if (fiveQi < MAX_5QI_VALUE)
                                {
                                    pPdcpInfo->redCapSnSizeDl = pPdcpProfile->pdcpInfo5qi[fiveQi].redCapSnSizeDl;
                                    pPdcpInfo->redCapSnSizeUl = pPdcpProfile->pdcpInfo5qi[fiveQi].redCapSnSizeUl;
                                }
                                else
                                {
                                    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Invalid fiveQi(%d) for service group id(%d)", fiveQi, svcGrpId);
                                    pPdcpInfo->redCapSnSizeDl = pdcp_len12bits;
                                    pPdcpInfo->redCapSnSizeUl = pdcp_len12bits;
                                }
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    if (pPdcpInfo == NULL)
    {
        pPdcpInfo = FnVCCB_GetPdcpInfo5qi(cellNum, gnbNum, fiveQi);
    }

    return pPdcpInfo;
}

int16_t FnVCCB_DecideRohc(callInfo_type *ptCi, callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);

    int16_t status = ERROR;

    if ((FALSE == ptDi->rbInfo.pdcpInfo.outOfOrderDelivery) &&
        (FALSE == ptCi->ueInfo.roHCCapability.isRetryDueToUPFailure))
    {
        ptDi->rbInfo.pdcpInfo.m.headerCompression = OPT_PRESENT;
        status = GOOD;
    }

    return status;
}

int16_t FnVCCB_DecideEhc(callInfo_type *ptCi, callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);
    int16_t status = ERROR;

    if (FALSE == ptCi->ueInfo.ehcCapability.isEHCRetryDueToUPFailure
        // add UDC(UplinkDataCompression-r17) check as well in future:
        // TS 38.331: ethernetHeaderCompression - Network only configures this field when uplinkDataCompression is not configured.
        )
    {
        ptDi->rbInfo.pdcpInfo.m.ethernet_headerCompression = OPT_PRESENT;
        status = GOOD;
    }

    return status;
}

int16_t FnVCCB_InitRohcContext(callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptDi);

    ptDi->rbInfo.pdcpInfo.headerCompression.ulRohcEnabled = FALSE;
    ptDi->rbInfo.pdcpInfo.headerCompression.symmetricRohcEnabled = FALSE;
    ptDi->rbInfo.pdcpInfo.headerCompression.drbContinueRohcEnabled = FALSE;
    ptDi->rbInfo.pdcpInfo.outOfOrderDelivery = FALSE;
    ptDi->rbInfo.pdcpInfo.headerCompression.useProfile001 = FALSE;
    ptDi->rbInfo.pdcpInfo.headerCompression.useProfile002 = FALSE;
    ptDi->rbInfo.pdcpInfo.headerCompression.useProfile003 = FALSE;
    ptDi->rbInfo.pdcpInfo.headerCompression.useProfile004 = FALSE;
    ptDi->rbInfo.pdcpInfo.headerCompression.useProfile006 = FALSE;
    ptDi->rbInfo.pdcpInfo.headerCompression.useProfile101 = FALSE;
    ptDi->rbInfo.pdcpInfo.headerCompression.useProfile102 = FALSE;
    ptDi->rbInfo.pdcpInfo.headerCompression.useProfile103 = FALSE;
    ptDi->rbInfo.pdcpInfo.headerCompression.useProfile104 = FALSE;

    ptDi->rbInfo.pdcpInfo.headerCompression.rohc_m.ulRohcEnabled = OPT_NOT_PRESENT;
    ptDi->rbInfo.pdcpInfo.headerCompression.rohc_m.symmetricRohcEnabled = OPT_NOT_PRESENT;

    return GOOD;
}

void FnVCCB_InitEhcContext(callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptDi);

    memset(&ptDi->rbInfo.pdcpInfo.ethernetCompression, 0x00, sizeof(ptDi->rbInfo.pdcpInfo.ethernetCompression));
}

int16_t FnVCCB_EhcPossible(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t fiveQi ,uint16_t spCellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(spCellNum, MAX_CELL_NUM_VCCB);

    int16_t status = ERROR;

    pdcpInfo5qi_type *pPdcpInfo = FnVCCB_GetPdcpInfoUsingServiceGroup(ptCi, ptDi, spCellNum, ptCi->gnbNum, fiveQi);
    VALID_E_POINT_CHECK_ERROR(pPdcpInfo);

    if ((TRUE == ptCi->ueInfo.ehcCapability.ehcCapable) &&
        (TRUE == pPdcpInfo->ethernetCompression.ehcSupportEnabled))
    {
        ptDi->rbInfo.pdcpInfo.ethernetCompression.ehc_m.ehcSetupPossible = OPT_PRESENT;
        status = GOOD;
    }

    return status;
}

int16_t FnVCCB_EhcCidAvailable(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t fiveQi ,uint16_t spCellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(spCellNum, MAX_CELL_NUM_VCCB);

    int16_t status = ERROR;

    uint16_t ueMaxCidCapability;  // UE capa maxNumberEHC-Contexts
    uint16_t curAllocatedEhcCid;  // EHC contexts already allocated to UE
    uint16_t newAllocEhcCid;      // temp EHC context allocations 
    uint16_t gNBConfCidPer5Qi;    // gNB capa ehcMaxSession(ul+dl)
    uint16_t currentReqMinCid;    // currently required min EHC contexts
    uint16_t estAllocatedEhcCid;  // estimated EHC allocations

    pdcpInfo5qi_type *pPdcpInfo = FnVCCB_GetPdcpInfoUsingServiceGroup(ptCi, ptDi, spCellNum, ptCi->gnbNum, fiveQi);
    VALID_E_POINT_CHECK_ERROR(pPdcpInfo);

    if (ptCi->ueInfo.ehcCapability.maxEHCsessions <= ci_maxEHC_Sessions_cs256)
    {
        //validate whether context-length configured at gNB is correct to proceed
#ifndef __NVGNB__
        if(pPdcpInfo->ethernetCompression.ehcConfig.ehc_CIDlength == access_s5gtype_b15)
        {
            VCCB_PRINT_LOG_EHC(ptCi,"EHC context length incorrectly configured in gNB ERROR!!\n");
            return status;
        }
#endif
    }

    ueMaxCidCapability = GetMaxEhcCIDAsSession(ptCi->ueInfo.ehcCapability.maxEHCsessions);
    curAllocatedEhcCid = ptCi->ueInfo.ehcCapability.curAllocatedEhcCid;
    newAllocEhcCid = ptCi->ueInfo.ehcCapability.tempAllocatedEhcCid;
    gNBConfCidPer5Qi = (uint16_t)(pPdcpInfo->ethernetCompression.ehcConfig.ehcMaxSession_dl +
                        pPdcpInfo->ethernetCompression.ehcConfig.ehcMaxSession_ul);

    currentReqMinCid = MIN(ueMaxCidCapability, gNBConfCidPer5Qi);
    estAllocatedEhcCid = (uint16_t)(curAllocatedEhcCid + newAllocEhcCid + currentReqMinCid);
    if (ueMaxCidCapability >= estAllocatedEhcCid)
    {
        ptCi->ueInfo.ehcCapability.tempAllocatedEhcCid = (uint16_t)(ptCi->ueInfo.ehcCapability.tempAllocatedEhcCid + currentReqMinCid);
        status = GOOD;
    }
    return status;
}

int16_t FnVCCB_EvaluateUlDlMaxEHCSession(callInfo_type *ptCi, pdcpInfo5qi_type *pPdcpInfo, uint16_t *reqCidSession_dl, uint16_t *reqCidSession_ul)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pPdcpInfo);

    uint16_t maxEhcCtxt_dl = pPdcpInfo->ethernetCompression.ehcConfig.ehcMaxSession_dl;
    uint16_t maxEhcCtxt_ul = pPdcpInfo->ethernetCompression.ehcConfig.ehcMaxSession_ul;

    uint16_t maxEHCSessionsUE = GetMaxEhcCIDAsSession(ptCi->ueInfo.ehcCapability.maxEHCsessions);

    if ((maxEhcCtxt_ul + maxEhcCtxt_dl) <= maxEHCSessionsUE)
    {
        *reqCidSession_ul = maxEhcCtxt_ul;
        *reqCidSession_dl = maxEhcCtxt_dl;
    }
    else
    {
        VCCB_PRINT_LOG_EHC(ptCi,"MaxEhcCtxtUl(%d) & MaxEhcCtxtDl(%d) greater than maxEHCsessionAtUE(%d) ERROR!!\n",maxEhcCtxt_ul, maxEhcCtxt_dl, maxEHCSessionsUE);
        return ERROR;
    }

    VCCB_PRINT_LOG_EHC(ptCi,"MaxEhcCtxtUl(%d) & MaxEhcCtxtDl(%d)!!\n", *reqCidSession_ul, *reqCidSession_dl);

    return GOOD;
}

int16_t FnVCCB_FillRohcParameters_5qiBased(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint16_t spCellNum, uint8_t updateOption, pdcpInfo5qi_type *pPdcpInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);
    VALID_E_POINT_CHECK_ERROR(pPdcpInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(spCellNum, MAX_CELL_NUM_VCCB);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptDi->drbQosIdxInCall, MAX_QOS_FLOW_PER_CALL);
    qosFlowInfo_type *ptQi = &ptCi->qosFlow[ptDi->drbQosIdxInCall];
    uint8_t fiveQi;
    if (ptQi->usage != CI_use)
    {
        return GOOD;
    }
    VLIB_getFiveQi(ptQi, &fiveQi);

    // ROHC Parameters
    uint8_t isSymmetricRohcEnabled = FALSE;
    uint16_t reqCidSession;

    // Check whether Symmetric Or ULOnlyRohc is enabled and OutOfDelivery is not configured
    if ((NR_PDCP_UPDATE_FINAL == updateOption) && (GOOD == FnVCCB_DecideRohc(ptCi, ptDi)))
    {
        FnVCCB_InitRohcContext(ptDi);

        // If both ulRohc & Symmetric Rohc is enabled , and 5QI to establish is 1 or 2 , then preference is give
        // to Symmetric over Ul Only RoHC

        if (1 == fiveQi || 2 == fiveQi)
        {

            if ((GOOD == FnVCCB_SymmetricRohcPossible(ptCi, ptDi, fiveQi, spCellNum)) &&
                (GOOD == FnVCCB_UplinkRohcPossible(ptCi, ptDi, fiveQi, spCellNum)))
            {
                isSymmetricRohcEnabled = TRUE;
                ptDi->rbInfo.pdcpInfo.headerCompression.rohc_m.ulRohcEnabled = OPT_NOT_PRESENT;
                
                VCCB_PRINT_LOG_ROHC(ptCi,
                    "Both ULOnlyRoHC & symmetric RoHC is possible , preference  to symmetric rohc.\n");
            }
        }

        if ((GOOD == FnVCCB_UplinkRohcPossible(ptCi, ptDi, fiveQi, spCellNum)) && (FALSE == isSymmetricRohcEnabled))
        {
            if (GOOD == FnVCCB_UplinkRohcCidAvailable(ptCi, ptDi, fiveQi, spCellNum))
            {
                ptDi->rbInfo.pdcpInfo.headerCompression.ulRohcEnabled = TRUE;
                ptDi->rbInfo.pdcpInfo.headerCompression.useProfile006 = TRUE;
                if (TRUE == pPdcpInfo->roHCConfig.ulRohcConfig.drbContinueRohc)
                {
                    ptDi->rbInfo.pdcpInfo.headerCompression.drbContinueRohcEnabled = TRUE;
                }

                // Update the lowest value among the UE and Cconfigured value.
                if (pPdcpInfo->roHCConfig.ulRohcConfig.ulRohcMaxSession < ptCi->ueInfo.roHCCapability.maxROHCsessions)
                {
                    reqCidSession = pPdcpInfo->roHCConfig.ulRohcConfig.ulRohcMaxSession;
                }
                else
                {
                    reqCidSession = ptCi->ueInfo.roHCCapability.maxROHCsessions;
                }

                ptDi->rbInfo.pdcpInfo.headerCompression.ulRohcMaxSession = GetMaxCIDAsSession(reqCidSession);

                VCCB_PRINT_LOG_ROHC(ptCi, "UL Only RoHC is enabled for the 5QI[%d] !\n", fiveQi);
            }
            else
            {
                VCCB_PRINT_LOG_ROHC(ptCi,
                    "CID Not Avail for RoHC Bearer [%d] ![Cur Alloc MN-CID[%d]/SN-CID[%d]"
                    ",Req [%d],Total Avail[%d] \n",
                    fiveQi,
                    (ptCi->ueInfo.roHCCapability.curAllocatedRohcCid +
                        ptCi->ueInfo.roHCCapability.tempAllocatedRohcCid),
                    ptCi->ueInfo.roHCCapability.curAllocatedSNRohcCid,
                    GetMaxCIDAsSession(pPdcpInfo->roHCConfig.ulRohcConfig.ulRohcMaxSession),
                    GetMaxCIDAsSession(ptCi->ueInfo.roHCCapability.maxROHCsessions));

                FnVCCB_InitRohcContext(ptDi);
                ptDi->rbInfo.pdcpInfo.m.headerCompression = OPT_NOT_PRESENT;
            }
        }
        else if (GOOD == FnVCCB_SymmetricRohcPossible(ptCi, ptDi, fiveQi, spCellNum))
        {
            if (GOOD == FnVCCB_SymmetricRohcCidAvailable(ptCi, ptDi, fiveQi, spCellNum))
            {
                ptDi->rbInfo.pdcpInfo.headerCompression.symmetricRohcEnabled = TRUE;

                ptDi->rbInfo.pdcpInfo.headerCompression.useProfile001 = (pPdcpInfo->roHCConfig.symmetricRohcConfig.useProfile001 &&
                                                       ptCi->ueInfo.roHCCapability.supportedROHCprofiles.profile0001);
                ptDi->rbInfo.pdcpInfo.headerCompression.useProfile002 = (pPdcpInfo->roHCConfig.symmetricRohcConfig.useProfile002 &&
                                                       ptCi->ueInfo.roHCCapability.supportedROHCprofiles.profile0002);
                ptDi->rbInfo.pdcpInfo.headerCompression.useProfile004 = (pPdcpInfo->roHCConfig.symmetricRohcConfig.useProfile004 &&
                                                       ptCi->ueInfo.roHCCapability.supportedROHCprofiles.profile0004);

                if (TRUE == pPdcpInfo->roHCConfig.symmetricRohcConfig.contRohcContextSupport)
                {
                    ptDi->rbInfo.pdcpInfo.headerCompression.drbContinueRohcEnabled = TRUE;
                }

                if (pPdcpInfo->roHCConfig.symmetricRohcConfig.symmetricRohcMaxSession <
                    ptCi->ueInfo.roHCCapability.maxROHCsessions)
                {
                    reqCidSession = pPdcpInfo->roHCConfig.symmetricRohcConfig.symmetricRohcMaxSession;
                }
                else
                {
                    reqCidSession = ptCi->ueInfo.roHCCapability.maxROHCsessions;
                }

                ptDi->rbInfo.pdcpInfo.headerCompression.symmetricRohcMaxSession = GetMaxCIDAsSession(reqCidSession);

                VCCB_PRINT_LOG_ROHC(ptCi, "Symmetric RoHC is enabled for the 5QI[%d] !\n", fiveQi);
            }
            else
            {
                VCCB_PRINT_LOG_ROHC(ptCi,
                    "CID Not Avail for RoHC Bearer [%u] ![Current Alloc MN-CID [%u]/SN-CID[%u]"
                    ",Req [%u],Total Avail[%u] \n",
                    fiveQi,
                    (ptCi->ueInfo.roHCCapability.curAllocatedRohcCid +
                        ptCi->ueInfo.roHCCapability.tempAllocatedRohcCid),
                    ptCi->ueInfo.roHCCapability.curAllocatedSNRohcCid,
                    GetMaxCIDAsSession(pPdcpInfo->roHCConfig.symmetricRohcConfig.symmetricRohcMaxSession),
                    GetMaxCIDAsSession(ptCi->ueInfo.roHCCapability.maxROHCsessions));

                FnVCCB_InitRohcContext(ptDi);
                ptDi->rbInfo.pdcpInfo.m.headerCompression = OPT_NOT_PRESENT;
            }
        }
        else
        {
            VCCB_PRINT_LOG_ROHC(ptCi,
                "Not Configured 5QI[%d]/GNBID[%d]/UeCap-ulROhc[%d]/UeCap-Symmetric "
                "[%d]/GNBConf-ulRohc[%d]/GNBConf-RoHC[%d]  \n",
                fiveQi, ptCi->gnbNum, ptCi->ueInfo.roHCCapability.ulOnlyRohcCapable,
                ptCi->ueInfo.roHCCapability.symmetricRohcCapable, pPdcpInfo->roHCConfig.ulRohcEnabled,
                pPdcpInfo->roHCConfig.symmetricRohcEnabled);

            ptDi->rbInfo.pdcpInfo.m.headerCompression = OPT_NOT_PRESENT;
        }
    }

        return GOOD;
}

void FnVCCB_FillEhcParameters_5qiBased(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint16_t spCellNum, uint8_t updateOption, pdcpInfo5qi_type *pPdcpInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptDi);
    VALID_E_POINT_CHECK_VOID(pPdcpInfo);
    VCCB_CHECK_E_RANGE_AND_VOID(spCellNum, MAX_CELL_NUM_VCCB);

    VCCB_CHECK_E_RANGE_AND_VOID(ptDi->drbQosIdxInCall, MAX_QOS_FLOW_PER_CALL);
    qosFlowInfo_type *ptQi = &ptCi->qosFlow[ptDi->drbQosIdxInCall];
    if (ptQi->usage != CI_use)
    {
       return;
    }

    uint8_t fiveQi;
    uint16_t reqCidSession_dl = 0, reqCidSession_ul = 0;

    VLIB_getFiveQi(ptQi, &fiveQi);

    if ((NR_PDCP_UPDATE_FINAL == updateOption) && (GOOD == FnVCCB_DecideEhc(ptCi, ptDi)))
    {
        FnVCCB_InitEhcContext(ptDi);
        if (GOOD == FnVCCB_EhcPossible(ptCi, ptDi, fiveQi, spCellNum))
        {
            if (GOOD == FnVCCB_EhcCidAvailable(ptCi, ptDi, fiveQi, spCellNum))
            {
                ptDi->rbInfo.pdcpInfo.ethernetCompression.ehcEnabled = TRUE;
                ptDi->rbInfo.pdcpInfo.ethernetCompression.ehc_CIDlength = pPdcpInfo->ethernetCompression.ehcConfig.ehc_CIDlength;

                if (TRUE == pPdcpInfo->ethernetCompression.ehcConfig.ehcContextContinue_dl)
                {
                    ptDi->rbInfo.pdcpInfo.ethernetCompression.ehc_m.isEhcDrbCtxtContinue_dl = OPT_PRESENT;
                    ptDi->rbInfo.pdcpInfo.ethernetCompression.ehcDrbContextContinue_dl = TRUE;
                }

                if (TRUE == pPdcpInfo->ethernetCompression.ehcConfig.ehcContextContinue_ul)
                {
                    ptDi->rbInfo.pdcpInfo.ethernetCompression.ehc_m.isEhcDrbCtxtContinue_ul = OPT_PRESENT;
                    ptDi->rbInfo.pdcpInfo.ethernetCompression.ehcDrbContextContinue_ul = TRUE;
                }

                if (GOOD == FnVCCB_EvaluateUlDlMaxEHCSession(ptCi, pPdcpInfo, &reqCidSession_dl, &reqCidSession_ul))
                {
                    ptDi->rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl = reqCidSession_dl;
                    ptDi->rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_ul = reqCidSession_ul;
                    VCCB_PRINT_LOG_EHC(ptCi,"EHC Cid Allocated for DRB[%d], 5QI[%d], ehcMaxSession_dl[%d], ehcMaxSession_ul[%d]\n",
                                        ptDi->dRBId, fiveQi, ptDi->rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_dl,
                                        ptDi->rbInfo.pdcpInfo.ethernetCompression.ehcMaxSession_ul);
                }
                else
                {
                    VCCB_PRINT_LOG_EHC(ptCi,"FnVCCB_EvaluateUlDlMaxEHCSession() ERROR!! for DRB[%d], 5QI[%d]\n", ptDi->dRBId, fiveQi);
                    FnVCCB_InitEhcContext(ptDi);
                    ptDi->rbInfo.pdcpInfo.m.ethernet_headerCompression = OPT_NOT_PRESENT;
                }
            }
            else
            {
                VCCB_PRINT_LOG_EHC(ptCi,"FnVCCB_EhcCidAvailable() ERROR!! for DRB[%d], 5QI[%d]\n", ptDi->dRBId, fiveQi);
                FnVCCB_InitEhcContext(ptDi);
                ptDi->rbInfo.pdcpInfo.m.ethernet_headerCompression = OPT_NOT_PRESENT;
            }
        }
        else
        {
            VCCB_PRINT_LOG_EHC(ptCi,"FnVCCB_EhcPossible() ERROR!! for DRB[%d], 5QI[%d]\n", ptDi->dRBId, fiveQi);
            ptDi->rbInfo.pdcpInfo.m.ethernet_headerCompression = OPT_NOT_PRESENT;
        }
    }
}

int16_t FnVCCB_FillPdcpConfiguration_5qiBased_NonChangeable(callInfo_type *ptCi, callDRBInfo_type *ptDi, int16_t spCellNum, uint8_t updateOption, pdcpInfo5qi_type *pPdcpInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);
    VALID_E_POINT_CHECK_ERROR(pPdcpInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(spCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptDi->drbQosIdxInCall, MAX_QOS_FLOW_PER_CALL);

    int8_t status = GOOD;
    uint8_t fiveQi = 0;  // Default is Zero 5QI Value.
    qosFlowInfo_type *ptQi = &ptCi->qosFlow[ptDi->drbQosIdxInCall];

    uint8_t decideRohcParametersFill = FALSE;
    uint8_t decideEhcParametersFill = FALSE;

    if (ptQi->usage == CI_use)  // If 5QI is present, 5QI is obtained
    {
        VLIB_getFiveQi(ptQi, &fiveQi);
    }

    // RLC Mode
    if (updateOption != NR_PDCP_UPDATE_SEMI_FINAL)
    {
        status = FnVCCB_DecideRlcMode(ptCi, ptDi, fiveQi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_DecideRlcMode(FlowId:%u, 5QI:%u) Error!\n", ptQi->flowId, fiveQi);
    }

    // PDCP SN SIZE UL/DL
    status = FnVCCB_DecidePdcpSnSize(ptCi, ptDi, fiveQi, updateOption);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_DecidePdcpSnSize(FlowId:%u, 5QI:%u) Error!\n", ptQi->flowId, fiveQi);

    // PDCP Status Report Indication
    ptDi->rbInfo.pdcpInfo.statusReportRequired = pPdcpInfo->statusReportRequired;

    FnVCCB_DecideHeaderCompressionParametersFill(ptCi, ptDi, &decideRohcParametersFill, &decideEhcParametersFill);

    // ROHC Parameters
    if(decideRohcParametersFill == TRUE)
    {
        FnVCCB_FillRohcParameters_5qiBased(ptCi, ptDi, static_cast<uint16_t>(spCellNum), updateOption, pPdcpInfo);
    }

    // EHC Parameters
    if(decideEhcParametersFill == TRUE)
    {
        FnVCCB_FillEhcParameters_5qiBased(ptCi, ptDi, static_cast<uint16_t>(spCellNum), updateOption, pPdcpInfo);
    }

    if (updateOption == NR_PDCP_UPDATE_FINAL)
    {
        ptDi->rbInfo.pdcpInfo.isPdcpConfigured = VCCB_FLAG_ON;
    }

    return GOOD;
}

void FnVCCB_FillPdcpConfiguration_5qiBased_Changeable(callInfo_type *ptCi, callDRBInfo_type *ptDi, pdcpInfo5qi_type *pPdcpInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptDi);
    VALID_E_POINT_CHECK_VOID(pPdcpInfo);

    rbPdcpSdapConfig_type *pDrb = &(ptDi->rbInfo);

    // UL Data Split Threshold
    pDrb->pdcpInfo.ulDataSplitThreshold = pPdcpInfo->ulDataSplitThreshold;
    pDrb->pdcpInfo.ulDataSplitThresholdFr1Fr2 = pPdcpInfo->ulDataSplitThresholdFr1Fr2;

    // Discard Timer UL/DL
    pDrb->pdcpInfo.discardTimerUl = (enumPdcpDiscardTimer_type)pPdcpInfo->discardTimerUl;
    pDrb->pdcpInfo.discardTimerDl = (enumPdcpDiscardTimerDl_type)pPdcpInfo->discardTimerDl;

    // T-Reordering Timer UL/DL
    pDrb->pdcpInfo.tReorderingUl = pPdcpInfo->tReorderingUl;
    pDrb->pdcpInfo.tReorderingDl = pPdcpInfo->tReorderingDl;
    pDrb->pdcpInfo.tReorderingUlSplitFr1Fr2 = pPdcpInfo->tReorderingUlSplitFr1Fr2;
    pDrb->pdcpInfo.tReorderingDlSplitFr1Fr2 = pPdcpInfo->tReorderingDlSplitFr1Fr2;

    // Out of Order Delivery
    pDrb->pdcpInfo.outOfOrderDelivery = FALSE;
    if ((TRUE == ptCi->ueInfo.ueCapa.nr.pdcp.outOfOrderDelivery) && (TRUE == pPdcpInfo->outOfOrderDelivery))
    {
        pDrb->pdcpInfo.outOfOrderDelivery = TRUE;
    }

    return;
}

int16_t FnVCCB_FillPdcpConfiguration_5qiBased(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t updateOption,uint16_t spCellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptDi->drbQosIdxInCall, MAX_QOS_FLOW_PER_CALL);
    qosFlowInfo_type *ptQi = &ptCi->qosFlow[ptDi->drbQosIdxInCall];
    uint8_t fiveQi;
    if (ptQi->usage != CI_use)
    {
        return GOOD;
    }
    VLIB_getFiveQi(ptQi, &fiveQi);

    pdcpInfo5qi_type *pPdcpInfo = FnVCCB_GetPdcpInfoUsingServiceGroup(ptCi, ptDi, spCellNum, ptCi->gnbNum, fiveQi);
    VALID_E_POINT_CHECK_ERROR(pPdcpInfo);

    if (ptDi->rbInfo.pdcpInfo.isPdcpConfigured == VCCB_FLAG_OFF)
    {
        FnVCCB_FillPdcpConfiguration_5qiBased_NonChangeable(ptCi, ptDi, static_cast<int16_t>(spCellNum), updateOption, pPdcpInfo);
    }
    FnVCCB_FillPdcpConfiguration_5qiBased_Changeable(ptCi, ptDi, pPdcpInfo);

        return GOOD;
}

int16_t FnVCCB_FillCallRbInfoPer5qi(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t updateOption)
{
    // mapping fiveQi to YANG
    // managed-element/gnb-cu-cp-function/gnb-cu-cp-function-entries/pdcp-info//pdcp-info/pdcp-info-entries-5qi/,
    // index(5qi)
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);
    uint16_t spCellNum;
    cellSelection_type cellSelection;
    switch (ptCi->stateCmd)
    {
        // HO, NRDC
        case IntraRatHO_cmd:
            cellSelection = FnVCCB_GetCellSelectionForConfig(ptCi);
            spCellNum = cellSelection.cellNum;
            break;
        case MrdcScgFailResume_cmd:
            if (IS_MRDC_MN(ptCi))
            {
                spCellNum = ptCi->servCellNum;
            }
            else
            {
                spCellNum = ptCi->nrdcScgFailureInfo.targetPsCellNum;
            }
            break;
        default:
            spCellNum = ptCi->servCellNum;
            break;
    }
    VCCB_CHECK_E_RANGE_AND_RETURN(spCellNum, MAX_CELL_NUM_VCCB);

    // If the state is Intra/Inter DU Cancel, recover PCDP Info
    if (ptCi->state == STATE_INTRA_DU_Cancel || ptCi->state == STATE_INTER_DU_Cancel ||
        ptCi->state == STATE_SN_INTRA_DU_Cancel)
    {
        ptDi->rbInfo.pdcpInfo = ptDi->rbInfo.pdcpInfoPrev;
        ptDi->rbInfo.pdcpInfoPrevFlagInfo.present.value = NR_PDCP_PREV_FLAG_SET_ALL;
        return GOOD;
    }
    // SDAP Configuration
    FnVCCB_FillSdapConfiguration(ptCi, ptDi, updateOption);

    // PDCP Configuration
    FnVCCB_FillPdcpConfiguration_5qiBased(ptCi, ptDi, updateOption, spCellNum);
    return GOOD;
}

int8_t FnVCCB_DecideRlcMode(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t fiveQi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    if (ptDi->rbInfo.rlcModePresent == OPT_NOT_PRESENT)  // This condition works when the DRB is eastablished.
    {
        pdcpInfo5qi_type *pPdcpInfo = FnVCCB_GetPdcpInfoUsingServiceGroup(ptCi, ptDi, ptCi->servCellNum, ptCi->gnbNum, fiveQi);
        VALID_E_POINT_CHECK_ERROR(pPdcpInfo);

        ptDi->rbInfo.rlcModePresent = OPT_PRESENT;
        ptDi->rbInfo.rlcMode = pPdcpInfo->rlcMode;
    }

        return GOOD;
}

int8_t FnVCCB_DecidePdcpSnSize(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t fiveQi, uint8_t updateOption)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    pdcpInfo5qi_type *pPdcpInfo = FnVCCB_GetPdcpInfoUsingServiceGroup(ptCi, ptDi, ptCi->servCellNum, ptCi->gnbNum, fiveQi);
    VALID_E_POINT_CHECK_ERROR(pPdcpInfo);

    if (updateOption == NR_PDCP_UPDATE_SEMI_FINAL)
    {
        // Update Only by Yang DB.
        ptDi->rbInfo.pdcpInfo.pdcpSnSizeDl = (enumPdcpSnSize_type)pPdcpInfo->snSizeUl;
        ptDi->rbInfo.pdcpInfo.pdcpSnSizeUl = (enumPdcpSnSize_type)pPdcpInfo->snSizeDl;
    }
    else  // NR_PDCP_UPDATE_FINAL
    {
        uint8_t useNewPdcpSnLengthFlag = 0;

        // pdcpSnSizeDl/pdcpSnSizeUl cannot be changed after a DRB is established
        if (FnVCCB_IsDrbEstablishedScenario(ptCi, ptDi) == TRUE)
        {
            useNewPdcpSnLengthFlag++;
        }

        if (ptDi->rbInfo.pdcpInfoPrevFlagInfo.present.prev == NR_PDCP_PREV_FLAG_NOT_PRESENT)  // No info from Source
        {
            useNewPdcpSnLengthFlag++;
        }

        if (useNewPdcpSnLengthFlag)
        {
            if (IS_REDCAP_UE(ptCi) && ptCi->callType == E_CALLTYPE_SA)
            {
                // +-------------------+------------+---------+---------+---------+
                // | shortSN           |      O     |    O    |    X    |    X    |
                // +-------------------+------------+---------+---------+---------+
                // | longSN-RedCap-r17 |      O     |    X    |    O    |    X    |
                // +-------------------+------------+---------+---------+---------+
                // | Decision PDCP SN  | Yang Value | 12 bits | 18 bits | 12 bits |
                // |                   |            |         | Abnormal  UE capa |
                // +-------------------+------------+---------+---------+---------+

                if (ptCi->redCapUeInfo.supportOf18bitPdcpSN == FALSE) // 12bits
                {
                    ptDi->rbInfo.pdcpInfo.pdcpSnSizeDl = pdcp_len12bits;
                    ptDi->rbInfo.pdcpInfo.pdcpSnSizeUl = pdcp_len12bits;
                }
                else
                {
                    if (ptCi->ueInfo.ueCapa.nr.pdcp.shortSN == FALSE) // 18bits
                    {
                        ptDi->rbInfo.pdcpInfo.pdcpSnSizeDl = pdcp_len18bits;
                        ptDi->rbInfo.pdcpInfo.pdcpSnSizeUl = pdcp_len18bits;
                    }
                    else // Yang DB
                    {
                        ptDi->rbInfo.pdcpInfo.pdcpSnSizeDl = (enumPdcpSnSize_type)pPdcpInfo->redCapSnSizeDl;
                        ptDi->rbInfo.pdcpInfo.pdcpSnSizeUl = (enumPdcpSnSize_type)pPdcpInfo->redCapSnSizeUl;
                    }
                }
            }
            else
            {
                // pdcpSnSizeDl
                if ((pPdcpInfo->snSizeDl == pdcp_len12bits) && (ptCi->ueInfo.ueCapa.nr.pdcp.shortSN == TRUE))
                {
                    ptDi->rbInfo.pdcpInfo.pdcpSnSizeDl = pdcp_len12bits;
                }
                else
                {
                    ptDi->rbInfo.pdcpInfo.pdcpSnSizeDl = pdcp_len18bits;
                }
                // pdcpSnSizeUl
                if ((pPdcpInfo->snSizeUl == pdcp_len12bits) && (ptCi->ueInfo.ueCapa.nr.pdcp.shortSN == TRUE))
                {
                    ptDi->rbInfo.pdcpInfo.pdcpSnSizeUl = pdcp_len12bits;
                }
                else
                {
                    ptDi->rbInfo.pdcpInfo.pdcpSnSizeUl = pdcp_len18bits;
                }
            }
        }
        else  // Using Prev Value.
        {
            if ((ptDi->rbInfo.pdcpInfoPrevFlagInfo.present.prev != NR_PDCP_PREV_FLAG_NOT_PRESENT) &&
                (ptDi->rbInfo.pdcpInfoPrevFlagInfo.present.pdcpSnSizeDl != NR_PDCP_PREV_FLAG_NOT_PRESENT) &&
                (ptDi->rbInfo.pdcpInfoPrevFlagInfo.present.pdcpSnSizeUl != NR_PDCP_PREV_FLAG_NOT_PRESENT))
            {
                ptDi->rbInfo.pdcpInfo.pdcpSnSizeDl = ptDi->rbInfo.pdcpInfoPrev.pdcpSnSizeDl;
                ptDi->rbInfo.pdcpInfo.pdcpSnSizeUl = ptDi->rbInfo.pdcpInfoPrev.pdcpSnSizeUl;
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "pdcpSnSize was succeeded with prev(dl:<D'%d, %s>, ul:<D'%d, %s>)!\n",
                    ptDi->rbInfo.pdcpInfoPrev.pdcpSnSizeDl,
                    ptDi->rbInfo.pdcpInfoPrev.pdcpSnSizeDl == pdcp_len12bits ? "pdcp_len12bits" : "pdcp_len18bits",
                    ptDi->rbInfo.pdcpInfoPrev.pdcpSnSizeUl,
                    ptDi->rbInfo.pdcpInfoPrev.pdcpSnSizeUl == pdcp_len12bits ? "pdcp_len12bits" : "pdcp_len18bits");
            }
            else
            {
                // if RRE and No Prev Value
                if ((ptDi->drbStatus == S_Setup) && (ptCi->stateCmd == RrcReestablish_cmd))
                {
                    // No Action. Use ptDi->rbInfo.pdcpInfo.pdcpSnSizeDl/Ul.
                }
                else
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_FillCallRbInfoPer5qi Error! Invalid prevPresent\n");
                                        return ERROR;
                }
            }
        }
    }

        return GOOD;
}

void FnVCCB_DecideHeaderCompressionParametersFill(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t *decideRohcParametersFill, uint8_t *decideEhcParametersFill)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptDi);
    VALID_E_POINT_CHECK_VOID(decideRohcParametersFill);
    VALID_E_POINT_CHECK_VOID(decideEhcParametersFill);


    if (ptCi->pduSess[ptDi->pduIdxInCall].pduSessType == NGAP_ipv4 ||
        ptCi->pduSess[ptDi->pduIdxInCall].pduSessType == NGAP_ipv6 ||
        ptCi->pduSess[ptDi->pduIdxInCall].pduSessType == NGAP_ipv4v6)
    {
        *decideRohcParametersFill = TRUE;
    }
    else if ((TRUE == FOO.VF_EHC) && 
             ((ptCi->pduSess[ptDi->pduIdxInCall].pduSessType == NGAP_ethernet) && IS_NON_DC(ptCi)))
    {
        if (TRUE == ptCi->ueInfo.ehcCapability.jointEhcRoHcCapable) //RoHC and EHC both can be configured
        {
            *decideRohcParametersFill = TRUE;
            *decideEhcParametersFill = TRUE;
        }
        else // Only EHC
        {
            *decideEhcParametersFill = TRUE;
        }
    }
    else
    {
        *decideRohcParametersFill = FALSE;
        *decideEhcParametersFill = FALSE;
    }

    return;
}

int16_t FnVCCB_SymmetricRohcPossible(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t fiveQi ,uint16_t spCellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(spCellNum, MAX_CELL_NUM_VCCB);

    int16_t status = ERROR;

    pdcpInfo5qi_type *pPdcpInfo = FnVCCB_GetPdcpInfoUsingServiceGroup(ptCi, ptDi, spCellNum, ptCi->gnbNum, fiveQi);
    VALID_E_POINT_CHECK_ERROR(pPdcpInfo);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptDi->pduIdxInCall, MAX_PDU_SESS_PER_CALL);

    if ((TRUE == ptCi->ueInfo.roHCCapability.symmetricRohcCapable) &&
        (TRUE == pPdcpInfo->roHCConfig.symmetricRohcEnabled) &&
        ((TRUE == pPdcpInfo->roHCConfig.symmetricRohcConfig.useProfile001) ||
            (TRUE == pPdcpInfo->roHCConfig.symmetricRohcConfig.useProfile002) ||
            (TRUE == pPdcpInfo->roHCConfig.symmetricRohcConfig.useProfile004)))
    {
        ptDi->rbInfo.pdcpInfo.headerCompression.rohc_m.symmetricRohcEnabled = OPT_PRESENT;
        status = GOOD;
    }

    return status;
}


int16_t FnVCCB_UplinkRohcPossible(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t fiveQi ,uint16_t spCellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(spCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptDi->pduIdxInCall, MAX_PDU_SESS_PER_CALL);

    int16_t status = ERROR;

    pdcpInfo5qi_type *pPdcpInfo = FnVCCB_GetPdcpInfoUsingServiceGroup(ptCi, ptDi, spCellNum, ptCi->gnbNum, fiveQi);
    VALID_E_POINT_CHECK_ERROR(pPdcpInfo);


    if ((TRUE == ptCi->ueInfo.roHCCapability.ulOnlyRohcCapable) && (TRUE == pPdcpInfo->roHCConfig.ulRohcEnabled) &&
        (TRUE == pPdcpInfo->roHCConfig.ulRohcConfig.useProfile006))
    {
        ptDi->rbInfo.pdcpInfo.headerCompression.rohc_m.ulRohcEnabled = OPT_PRESENT;
        status = GOOD;
    }

    return status;
}

int16_t FnVCCB_UplinkRohcCidAvailable(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t fiveQi, uint16_t spCellNum)
{

    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(spCellNum, MAX_CELL_NUM_VCCB);

    int16_t status = ERROR;

    int16_t ueMaxCidCapability;
    int16_t curAllocatedRohcCid;
    int16_t newAllocRohcCid;
    int16_t gNBConfCidPer5Qi;
    int16_t currentReqMinCid;
    int16_t estAllocatedRohcCid;

    pdcpInfo5qi_type *pPdcpInfo = FnVCCB_GetPdcpInfoUsingServiceGroup(ptCi, ptDi, spCellNum, ptCi->gnbNum, fiveQi);
    VALID_E_POINT_CHECK_ERROR(pPdcpInfo);

    ueMaxCidCapability = static_cast<int16_t>(GetMaxCIDAsSession(ptCi->ueInfo.roHCCapability.maxROHCsessions));
    curAllocatedRohcCid = static_cast<int16_t>(ptCi->ueInfo.roHCCapability.curAllocatedRohcCid);
    newAllocRohcCid = static_cast<int16_t>(ptCi->ueInfo.roHCCapability.tempAllocatedRohcCid);
    gNBConfCidPer5Qi = static_cast<int16_t>(GetMaxCIDAsSession(pPdcpInfo->roHCConfig.ulRohcConfig.ulRohcMaxSession));

    currentReqMinCid = MIN(ueMaxCidCapability, gNBConfCidPer5Qi);

    if ((ptCi->cgConfigInfo.configRestrictInfo.maxROHCsessionsSN_NR_Flag == VCCB_FLAG_ON) &&
        (ptCi->stateCmd == IntraRatHO_cmd) && (ptCi->hoInfo.isTarget == TRUE))
    {
        curAllocatedRohcCid = static_cast<int16_t>(curAllocatedRohcCid + ptCi->cgConfigInfo.configRestrictInfo.maxROHCsessionsSN);

        VCCB_PRINT_LOG_ROHC(ptCi,
            "MN gNB - Adding MaxSNCidCapability [%d] with existing allocation[%d] and Total Usage [%d] \n",
            ptCi->cgConfigInfo.configRestrictInfo.maxROHCsessionsSN, ptCi->ueInfo.roHCCapability.curAllocatedRohcCid,
            curAllocatedRohcCid);
    }

    else if (IS_NRDC_MN(ptCi))
    {
        curAllocatedRohcCid = static_cast<int16_t>(curAllocatedRohcCid + ptCi->ueInfo.roHCCapability.curAllocatedSNRohcCid);

        VCCB_PRINT_LOG_ROHC(ptCi,
            "MN gNB - Adding SN CID [%d] with existing allocation[%d] and Total Usage [%d] \n",
            ptCi->ueInfo.roHCCapability.curAllocatedSNRohcCid, ptCi->ueInfo.roHCCapability.curAllocatedRohcCid,
            curAllocatedRohcCid);
    }

    else if ((IS_NRDC_SN(ptCi) == TRUE) &&
             (ptCi->cgConfigInfo.configRestrictInfo.maxROHCsessionsSN_NR_Flag == VCCB_FLAG_ON))
    {
        VCCB_PRINT_LOG_ROHC(ptCi, "Overiding ueCidCapbility[%d] with MaxSNCidCapability[%d]\n",
            ueMaxCidCapability, ptCi->cgConfigInfo.configRestrictInfo.maxROHCsessionsSN);
        ueMaxCidCapability = static_cast<int16_t>(ptCi->cgConfigInfo.configRestrictInfo.maxROHCsessionsSN);
    }

    estAllocatedRohcCid = static_cast<int16_t>(curAllocatedRohcCid + newAllocRohcCid + currentReqMinCid);

    if (ueMaxCidCapability >= estAllocatedRohcCid)
    {
        ptCi->ueInfo.roHCCapability.tempAllocatedRohcCid =
            static_cast<uint16_t>(ptCi->ueInfo.roHCCapability.tempAllocatedRohcCid + currentReqMinCid);

        VCCB_PRINT_LOG_ROHC(ptCi,
            "Cid Allocation Success, ueCidCapbility[%d]/CurrentCidAllocation[%d]/NewAllocatedRohcCid[%d]\n",
            ueMaxCidCapability, curAllocatedRohcCid, ptCi->ueInfo.roHCCapability.tempAllocatedRohcCid);
        status = GOOD;
    }

        return status;
}

int16_t FnVCCB_SymmetricRohcCidAvailable(callInfo_type *ptCi, callDRBInfo_type *ptDi, uint8_t fiveQi ,uint16_t spCellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(spCellNum, MAX_CELL_NUM_VCCB);


    int16_t status = ERROR;

    int16_t ueMaxCidCapability;
    int16_t curAllocatedRohcCid;
    int16_t newAllocRohcCid;
    int16_t gNBConfCidPer5Qi;
    int16_t currentReqMinCid;
    int16_t estAllocatedRohcCid;

    pdcpInfo5qi_type *pPdcpInfo = FnVCCB_GetPdcpInfoUsingServiceGroup(ptCi, ptDi, spCellNum, ptCi->gnbNum, fiveQi);
    VALID_E_POINT_CHECK_ERROR(pPdcpInfo);

    ueMaxCidCapability = static_cast<int16_t>(GetMaxCIDAsSession(ptCi->ueInfo.roHCCapability.maxROHCsessions));
    curAllocatedRohcCid = static_cast<int16_t>(ptCi->ueInfo.roHCCapability.curAllocatedRohcCid);
    newAllocRohcCid = static_cast<int16_t>(ptCi->ueInfo.roHCCapability.tempAllocatedRohcCid);
    gNBConfCidPer5Qi = static_cast<int16_t>(GetMaxCIDAsSession(pPdcpInfo->roHCConfig.symmetricRohcConfig.symmetricRohcMaxSession));

    currentReqMinCid = MIN(ueMaxCidCapability, gNBConfCidPer5Qi);

    if ((ptCi->cgConfigInfo.configRestrictInfo.maxROHCsessionsSN_NR_Flag == VCCB_FLAG_ON) &&
        (ptCi->stateCmd == IntraRatHO_cmd) && (ptCi->hoInfo.isTarget == TRUE))
    {
        curAllocatedRohcCid = static_cast<int16_t>(curAllocatedRohcCid + ptCi->cgConfigInfo.configRestrictInfo.maxROHCsessionsSN);

        VCCB_PRINT_LOG_ROHC(ptCi,
            "MN gNB - Adding MaxSNCidCapability [%d] with existing allocation[%d] and Total Usage [%d] \n",
            ptCi->cgConfigInfo.configRestrictInfo.maxROHCsessionsSN, ptCi->ueInfo.roHCCapability.curAllocatedRohcCid,
            curAllocatedRohcCid);
    }
    else if (IS_NRDC_MN(ptCi))
    {
        curAllocatedRohcCid = static_cast<int16_t>(curAllocatedRohcCid + ptCi->ueInfo.roHCCapability.curAllocatedSNRohcCid);

        VCCB_PRINT_LOG_ROHC(ptCi,
            "MN gNB - Adding SN CID [%d] with existing allocation[%d] and Total Usage [%d] \n",
            ptCi->ueInfo.roHCCapability.curAllocatedSNRohcCid, ptCi->ueInfo.roHCCapability.curAllocatedRohcCid,
            curAllocatedRohcCid);
    }

    else if ((IS_NRDC_SN(ptCi) == TRUE) &&
             (ptCi->cgConfigInfo.configRestrictInfo.maxROHCsessionsSN_NR_Flag == VCCB_FLAG_ON))
    {
        ueMaxCidCapability = static_cast<int16_t>(ptCi->cgConfigInfo.configRestrictInfo.maxROHCsessionsSN);

        VCCB_PRINT_LOG_ROHC(ptCi, "Overiding ueCidCapbility[%d] with MaxSNCidCapability[%d]\n",
            GetMaxCIDAsSession(ptCi->ueInfo.roHCCapability.maxROHCsessions), ueMaxCidCapability);
    }

    estAllocatedRohcCid = static_cast<int16_t>(curAllocatedRohcCid + newAllocRohcCid + currentReqMinCid);

    if (ueMaxCidCapability >= estAllocatedRohcCid)
    {
        ptCi->ueInfo.roHCCapability.tempAllocatedRohcCid = static_cast<uint16_t>(ptCi->ueInfo.roHCCapability.tempAllocatedRohcCid + currentReqMinCid);

        VCCB_PRINT_LOG_ROHC(ptCi,
            "ueCidCapbility[%d]/CurrentCidAllocation[%d]/gNBConfCidPer5Qi[%d]/NewAllocatedRohcCid[%d]\n",
            ueMaxCidCapability, curAllocatedRohcCid, gNBConfCidPer5Qi,
            ptCi->ueInfo.roHCCapability.tempAllocatedRohcCid);
        status = GOOD;
    }

        return status;
}

int16_t VLIB_PdcpReestabReqForRohcChange(callInfo_type* ptCi, callDRBInfo_type* ptDi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);

    uint8_t fiveQi;
    uint16_t curSevCellNum;
    uint16_t tarSevCellNum;

    qosFlowInfo_type* ptQi = NULL;

    if (ERROR == VLIB_SelectRepresentativeQoSFlowInDRB(ptCi, ptDi) || (ptDi->drbQosIdxInCall >= MAX_QOS_FLOW_PER_CALL))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_FillCallRbInfoPer5qi Error! Invalid 5QI\n");
                return ERROR;
    }

    ptQi = &ptCi->qosFlow[ptDi->drbQosIdxInCall];

    if (ptQi->usage != CI_use)
    {
                return GOOD;
    }

    VLIB_getFiveQi(ptQi, &fiveQi);

    if (ptCi->stateCmd != IntraRatHO_cmd)
    {
                return FALSE;
    }

    curSevCellNum = ptCi->servCellNum;
    tarSevCellNum = ptCi->hoInfo.targetCellNum;

    VCCB_CHECK_E_RANGE_AND_RETURN(curSevCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(tarSevCellNum, MAX_CELL_NUM_VCCB);

    if ((FnVCCB_UplinkRohcPossible(ptCi, ptDi, fiveQi, curSevCellNum) != 
         FnVCCB_UplinkRohcPossible(ptCi, ptDi, fiveQi, tarSevCellNum)))
    {
        VCCB_PRINT_LOG_ROHC(ptCi, "Parameter is changed, PDCP Re-esblishment required \n");
                return TRUE;

    }
    if ((FnVCCB_SymmetricRohcPossible(ptCi, ptDi, fiveQi, curSevCellNum) != 
         FnVCCB_SymmetricRohcPossible(ptCi, ptDi, fiveQi, tarSevCellNum)))
    {

        VCCB_PRINT_LOG_ROHC(ptCi, "Parameter is changed, PDCP Re-esblishment required \n");
        return TRUE;
    }

     // Check ROHC parameter of the modified DRB is changed
    if ((ptDi->rbInfo.pdcpInfo.headerCompression.symmetricRohcEnabled != ptDi->rbInfo.pdcpInfoPrev.headerCompression.symmetricRohcEnabled))
    {
        VCCB_PRINT_LOG_ROHC(ptCi, "Configuration of DRB [%d]  is changed, PDCP Re-esblishment required \n",ptDi->dRBId);
        return TRUE;
    }

    if ((ptDi->rbInfo.pdcpInfo.headerCompression.ulRohcEnabled !=  ptDi->rbInfo.pdcpInfoPrev.headerCompression.ulRohcEnabled))
    {
        VCCB_PRINT_LOG_ROHC(ptCi, "Configuration of DRB [%d]  is changed, PDCP Re-esblishment required \n",ptDi->dRBId);
        return TRUE;
    }

    return FALSE;
}

uint8_t FnVCCB_GetUlDataSplitThreshold(callInfo_type *ptCi, callERABInfo_type *ptRi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, NRRRC_UL_DataSplitThreshold_infinity);
    VALID_E_POINT_CHECK_RET_VAL(ptRi, NRRRC_UL_DataSplitThreshold_infinity);

    uint16_t cellNum;
    pdcpInfoQci_type *pPdcpInfo = NULL;

    if (ptCi->ulPathControl.revertUlPathChange)
    {
        ptRi->dataSplitThreshold = ptRi->prevDataSplitThreshold;
        if (VCCB_FLAG_ON == DBG->flag.logUlPathControl)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[UlPath] : dataSplitThreshold(%u)\n", 
                            ptRi->dataSplitThreshold);
        }
        return ptRi->dataSplitThreshold;
    }

    if ((IntraRatHO_cmd == ptCi->stateCmd) && (HO_TYPE_INTER_NB != ptCi->hoInfo.hoType.nb))
    {
        cellNum = ptCi->hoInfo.targetCellNum;
    }
    else
    {
        cellNum = ptCi->servCellNum;
    }

    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, NRRRC_UL_DataSplitThreshold_infinity);

    pPdcpInfo = FnVCCB_GetPdcpInfoQci(cellNum, ptCi->gnbNum, QCI_FOR_UIT_ARP2);

    if (VCCB_FLAG_ON == GNBINFO[ptCi->gnbNum].cfg.qciBasedUlSplitThSwitch && NULL != pPdcpInfo &&
        (VCCB_FLAG_ON == ptCi->ulPathControl.curr.qci128SwitchFlag || TRUE == ptCi->isEndcVipUe))
    {
        ptRi->dataSplitThreshold  = pPdcpInfo->ulDataSplitThreshold;
    }
    else
    {
        if (High_Latency == ptCi->HighLatencyIndication && (IntraRatHO_cmd != ptCi->stateCmd) &&
            (InterRatHO_cmd != ptCi->stateCmd))
        {
            ptRi->dataSplitThreshold = NRRRC_UL_DataSplitThreshold_infinity;
        }
        else
        {
            if (FnVCCB_IsCongestionStateActive(ptCi))
            {
                ptRi->dataSplitThreshold = CELLINFO[cellNum].ulPathCongestionBased.ulDataSplitThresholdForCongestion;
            }
            else
            {
                ptRi->dataSplitThreshold = ptRi->rbInfo.pdcpInfo.ulDataSplitThreshold;
            }
        }
    }

    if (VCCB_FLAG_ON == DBG->flag.logUlPathControl)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[UlPath] : dataSplitThreshold(%u), cellNum (%u), ueCongestionState (%u), qciBasedUlSplitThSwitch(%u) \n", 
                            ptRi->dataSplitThreshold, cellNum, ptCi->ulPathControl.ueCongestionState,
                            GNBINFO[ptCi->gnbNum].cfg.qciBasedUlSplitThSwitch);
    }

    return ptRi->dataSplitThreshold;
}

bool FnVCCB_IsUlDataSplitThresholdFr1Fr2Infinite(const callDRBInfo_type *const ptDi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptDi);

        return (NRRRC_UL_DataSplitThreshold_infinity == ptDi->rbInfo.pdcpInfo.ulDataSplitThresholdFr1Fr2);
}

void FnVCCB_FillRohcParameters_QciBased(callInfo_type *ptCi, callERABInfo_type *ptRi, pdcpInfoQci_type *pPdcpInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptRi);
    VALID_E_POINT_CHECK_VOID(pPdcpInfo);

    rbPdcpSdapConfig_type *pDrb = &(ptRi->rbInfo);

    if ((ptCi->ueInfo.roHCCapability.isRetryDueToUPFailure == FALSE))
    {
        enumMaxROHCsessions_type choiceSession;
        uint16_t maxCID = 0xFF;

        if ((TRUE == ptCi->ueInfo.roHCCapability.ulOnlyRohcCapable) &&
            (GetMaxCIDAsSession(ptCi->ueInfo.roHCCapability.maxROHCsessions) >=
                (ptCi->ueInfo.roHCCapability.curAllocatedRohcCid +
                    GetMaxCIDAsSession(MIN(pPdcpInfo->roHCConfig.ulRohcConfig.ulRohcMaxSession,
                        ptCi->ueInfo.roHCCapability.maxROHCsessions)))))
        {
            if(TRUE == pPdcpInfo->roHCConfig.ulRohcEnabled &&
               TRUE == pPdcpInfo->roHCConfig.ulRohcConfig.useProfile006)
            {
                pDrb->pdcpInfo.m.headerCompression = OPT_PRESENT;
                pDrb->pdcpInfo.headerCompression.rohc_m.ulRohcEnabled = OPT_PRESENT;
            }

            pDrb->pdcpInfo.headerCompression.ulRohcEnabled = pPdcpInfo->roHCConfig.ulRohcEnabled;
            pDrb->pdcpInfo.headerCompression.useProfile006 = pPdcpInfo->roHCConfig.ulRohcConfig.useProfile006;
            pDrb->pdcpInfo.headerCompression.drbContinueRohcEnabled = pPdcpInfo->roHCConfig.ulRohcConfig.drbContinueRohc;

            // Update the lowest value among the UE and Cconfigured value.
            if (pPdcpInfo->roHCConfig.ulRohcConfig.ulRohcMaxSession < ptCi->ueInfo.roHCCapability.maxROHCsessions)
            {
                choiceSession = (enumMaxROHCsessions_type)pPdcpInfo->roHCConfig.ulRohcConfig.ulRohcMaxSession;
            }
            else
            {
                choiceSession = (enumMaxROHCsessions_type)ptCi->ueInfo.roHCCapability.maxROHCsessions;
            }

            // Convert Enum to Integer
            maxCID = GetMaxCIDAsSession(choiceSession);

            if (ptCi->cgConfigInfo.configRestrictInfo.maxROHCsessionsSN_NR_Flag == VCCB_FLAG_ON)
            {
                if (ptCi->cgConfigInfo.configRestrictInfo.maxROHCsessionsSN < maxCID)
                {
                    maxCID = ptCi->cgConfigInfo.configRestrictInfo.maxROHCsessionsSN;
                }
            }
            pDrb->pdcpInfo.headerCompression.ulRohcMaxSession = maxCID;
        }
        else
        {
            VCCB_PRINT_LOG_ROHC(ptCi,
                "not configured, Allocated Context sessions %d\t, requested %d\t,  Total Sessions %d\n",
                ptCi->ueInfo.roHCCapability.curAllocatedRohcCid,
                GetMaxCIDAsSession(MIN(
                    pPdcpInfo->roHCConfig.ulRohcConfig.ulRohcMaxSession, ptCi->ueInfo.roHCCapability.maxROHCsessions)),
                GetMaxCIDAsSession(ptCi->ueInfo.roHCCapability.maxROHCsessions));
            pDrb->pdcpInfo.headerCompression.ulRohcEnabled = FALSE;
            pDrb->pdcpInfo.headerCompression.useProfile006 = FALSE;
            pDrb->pdcpInfo.headerCompression.drbContinueRohcEnabled = FALSE;

            pDrb->pdcpInfo.headerCompression.rohc_m.ulRohcEnabled = OPT_NOT_PRESENT;
            pDrb->pdcpInfo.m.headerCompression = OPT_NOT_PRESENT;
        }
    }
}

void FnVCCB_FillPdcpConfiguration_QciBased_NonChangeable(callInfo_type *ptCi, callERABInfo_type *ptRi, pdcpInfoQci_type *pPdcpInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptRi);
    VALID_E_POINT_CHECK_VOID(pPdcpInfo);
    rbPdcpSdapConfig_type *pDrb = &(ptRi->rbInfo);

    // RLC Mode
    pDrb->rlcMode = pPdcpInfo->rlcMode;

    // PDCP SN SIZE UL/DL
    if (GET_DRB_SRC_CFG_FLAG(ptRi->flag.setupFlag))
    {
        // SN Size should be maintained.
        pDrb->pdcpInfo.pdcpSnSizeUl = pDrb->pdcpInfoPrev.pdcpSnSizeUl;
        pDrb->pdcpInfo.pdcpSnSizeDl = pDrb->pdcpInfoPrev.pdcpSnSizeDl;
    }
    else
    {
        if (ptCi->ueInfo.ueCapa.nr.pdcp.shortSN == TRUE)
        {
            pDrb->pdcpInfo.pdcpSnSizeUl = (enumPdcpSnSize_type)pPdcpInfo->snSizeUl;
            pDrb->pdcpInfo.pdcpSnSizeDl = (enumPdcpSnSize_type)pPdcpInfo->snSizeDl;
        }
        else
        {
            pDrb->pdcpInfo.pdcpSnSizeUl = pdcp_len18bits;
            pDrb->pdcpInfo.pdcpSnSizeDl = pdcp_len18bits;
        }
    }

    VCCB_PRINT_CALL_DATA(ptCi, "pDrb->pdcpInfo.pdcpSnSizeUl(%d)\n", pDrb->pdcpInfo.pdcpSnSizeUl);

    // PDCP Status Report Indication
    pDrb->pdcpInfo.statusReportRequired = pPdcpInfo->statusReportRequired;

    // ROHC Parameters
    FnVCCB_FillRohcParameters_QciBased(ptCi, ptRi, pPdcpInfo);

    pDrb->pdcpInfo.isPdcpConfigured = VCCB_FLAG_ON;

    return;
}

void FnVCCB_FillPdcpConfiguration_QciBased_Changeable(callInfo_type *ptCi, callERABInfo_type *ptRi, pdcpInfoQci_type *pPdcpInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptRi);
    VALID_E_POINT_CHECK_VOID(pPdcpInfo);

    rbPdcpSdapConfig_type *pDrb = &(ptRi->rbInfo);

    // UL Data Split Threshold
    pDrb->pdcpInfo.ulDataSplitThreshold = pPdcpInfo->ulDataSplitThreshold;

    // Discard Timer UL/DL
    pDrb->pdcpInfo.discardTimerUl = (enumPdcpDiscardTimer_type)pPdcpInfo->discardTimerUl;
    pDrb->pdcpInfo.discardTimerDl = (enumPdcpDiscardTimerDl_type)pPdcpInfo->discardTimerDl;

    // T-Reordering Timer UL/DL
    pDrb->pdcpInfo.tReorderingUl = pPdcpInfo->tReorderingUl;
    pDrb->pdcpInfo.tReorderingDl = pPdcpInfo->tReorderingDl;

    // Out of Order Delivery
    pDrb->pdcpInfo.outOfOrderDelivery = FALSE;
    if (ptCi->ueInfo.ueCapa.nr.pdcp.outOfOrderDelivery == TRUE)
    {
        pDrb->pdcpInfo.outOfOrderDelivery = pPdcpInfo->outOfOrderDelivery;
    }
    return;
}

int16_t FnVCCB_FillPdcpConfiguration_QciBased(callInfo_type *ptCi, callERABInfo_type *ptRi, uint16_t qci, uint16_t spCellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptRi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(qci, MAX_QCI_VALUE);

    pdcpInfoQci_type *pPdcpInfo = NULL;
    pPdcpInfo = FnVCCB_GetPdcpInfoQci(spCellNum, ptCi->gnbNum, qci);
    VALID_E_POINT_CHECK_ERROR(pPdcpInfo);

    if (pPdcpInfo->shmStatus != EQUIP)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "CFG->PdcpInfo[%d].shmStatus is not EQUIP.\n", qci);
        return ERROR;
    }

    FnVCCB_FillPdcpConfiguration_QciBased_Changeable(ptCi, ptRi, pPdcpInfo);
    if (ptRi->rbInfo.pdcpInfo.isPdcpConfigured == VCCB_FLAG_OFF)
    {
            FnVCCB_FillPdcpConfiguration_QciBased_NonChangeable(ptCi, ptRi, pPdcpInfo);
    }

    return GOOD;
}

/**
 * @brief     Fill DRB configuration in call context
 * @param     ptCi : call context
 * @param     pDrb : DRB context
 * @param     qci : QCI value / uint16_t
 * @return    GOOD : success
 * @return    ERROR : failure, QCI value is out-of-range
 */
int16_t FnVCCB_FillCallRbInfoPerQci(callInfo_type *ptCi, callERABInfo_type *ptRi, uint16_t qci)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptRi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(qci, MAX_QCI_VALUE);
    uint16_t spCellNum;
    int status = GOOD;
    ptCi->reserved = 0;  // for warning removal

    switch (ptCi->stateCmd)
    {
        // ENDC
        case IntraRatHO_cmd:
            spCellNum = ptCi->hoInfo.targetCellNum;
            break;
        default:
            spCellNum = ptCi->servCellNum;
            break;
    }
    VCCB_CHECK_E_RANGE_AND_RETURN(spCellNum, MAX_CELL_NUM_VCCB);

    status = FnVCCB_FillPdcpConfiguration_QciBased(ptCi, ptRi, qci, spCellNum);
    if(status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_FillPdcpConfiguration_QciBased is ERROR(qci : %d)\n", qci);
        return ERROR;
    }
    return GOOD;
}
void FnVCCB_SetMaxRohcSessionPerProfile(pdcpProfile_type *pPdcpProfile)
{
    VALID_E_POINT_CHECK_VOID(pPdcpProfile);

    if (pPdcpProfile->status != EQUIP) return;

    uint8_t maxRohc = ci_maxROHC_Sessions_cs16;         // YANG Default
    uint8_t maxUlOnlyRohc = ci_maxROHC_Sessions_cs16;   // YANG Default

    for (int fiveQi = 0; fiveQi < MAX_5QI_VALUE; fiveQi++)
    {
        if (pPdcpProfile->pdcpInfo5qi[fiveQi].shmStatus != EQUIP) continue;

        if (pPdcpProfile->pdcpInfo5qi[fiveQi].roHCConfig.ulRohcEnabled)
        {
            if (maxUlOnlyRohc < pPdcpProfile->pdcpInfo5qi[fiveQi].roHCConfig.ulRohcConfig.ulRohcMaxSession)
            {
                maxUlOnlyRohc = pPdcpProfile->pdcpInfo5qi[fiveQi].roHCConfig.ulRohcConfig.ulRohcMaxSession;
            }
        }

        if (pPdcpProfile->pdcpInfo5qi[fiveQi].roHCConfig.symmetricRohcEnabled)
        {
            if (maxRohc < pPdcpProfile->pdcpInfo5qi[fiveQi].roHCConfig.symmetricRohcConfig.symmetricRohcMaxSession)
            {
                maxRohc = pPdcpProfile->pdcpInfo5qi[fiveQi].roHCConfig.symmetricRohcConfig.symmetricRohcMaxSession;
            }
        }
    }

    pPdcpProfile->maxSessionRohc = maxRohc;
    pPdcpProfile->maxSessionUlOnlyRohc = maxUlOnlyRohc;
}
