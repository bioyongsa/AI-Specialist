/****************************************************************
 * System      : 5G gNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatAupf.cpp
 * Description : This file contains functions related AUPF (gNB-CU-UP) resource.
 * Dept.       : 5G Call SW Lab.
 * Created     : 2020.04.30 (Changed from FeatAmf.c)
 ****************************************************************/
#include "FeatAupf.h"
#include "RscProto.h"
#include "ComInclude.h"
#include "FeatCommon.h"
#include "FeatCallProc.h"
#include "StateCommon.h"
#include "MsgE1apSend.h"
#include "FeatMrdc.h"

using ErabListPerQCI_type = std::array<std::vector<callERABInfo_type *>, MAX_QCI_VALUE>;
using PduSessListPerNssai_type = std::unordered_map<uint32_t, std::vector<callPDUSessInfo_type *>>;

AupfStatusInfo_type *VRRM_AUPFSelectionWeightFactorsAndCapacity(
    const callInfo_type &rCi, std::vector<AupfStatusInfo_type *> &candidateAUPFs);

static const uint8_t IPV4V6_BIT_DIFF = (MAX_IPV6_BIT - MAX_IPV4_BIT);

/**
 * @brief       This function is dedicated for: [FGR-SV1201] NSA/SA agnostic supplementary gNB function
 * @description It shall be called in Conn/DB state. Sends BearerContextModification messages with only mandatory IEs to
 * all serving UPs
 * @param       ptCi  : call info DB
 * @return      ERROR : can't send E1 BearerContextModificationRequest message
 * @return      GOOD  : send E1 BearerContextModificationRequest message
 */
int16_t FnVCCB_TriggerAupfAuditMessage(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    // 1) This function is dedicated for: [FGR-SV1201] NSA/SA agnostic supplementary gNB function
    // -- It shall be called in Conn/DB state

    if (FALSE == VCCM_IsUeIdleState(ptCi->callType, ptCi->state))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Cannot send Aupf Audit Message. Call is not in Idle State\n");
        return ERROR;
    }

    // Set STATE_AupfAudit_E1Mod which will be verified when building BearerContextModificationRequest
    // in order to include only mandatory IEs

    VLIB_SetCurStateAll(ptCi, STATE_AupfAudit_E1Mod);

    int16_t status = VEIL_sendE1SetupModRelRequest(ptCi, E1Procedure_BearerContextModification);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");

    VLIB_AttachTimer(&ptCi->timer, ptCi, timE1_BearerContextModification_id);

    return GOOD;
}

/**
 * @brief This function returns serving UP index based on E1Idx
 * @param [in] ptCi                 : The pointer for the call context.
 * @param [in] messageEndPointIndex : Endpoint index of handled message
 * @return serving UP index
 */
uint16_t VRRM_FindServingUpIndex(callInfo_type *ptCi, uint16_t messageEndPointIndex)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_CU_UP_PER_CALL);
    uint16_t servingUpIdx = MAX_CU_UP_PER_CALL;

    for (uint16_t loop = 0; loop < MAX_CU_UP_PER_CALL; ++loop)
    {
        // Find Related UP
        if (CI_use == ptCi->endPointInfo.aupf[loop].usage &&
            messageEndPointIndex == ptCi->endPointInfo.aupf[loop].e1Idx)
        {
            servingUpIdx = loop;
            break;
        }
    }
    return servingUpIdx;
}

/**
 * @breif Release Serving AUPF index
 * @param [in] ptCi     : The pointer for the call context.
 * @param [in] srvUpIdx : Serving UP index to release
 */
void VRRM_ReleaseServingUpIndex(callInfo_type *ptCi, uint16_t srvUpIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(srvUpIdx, MAX_CU_UP_PER_CALL);

    auto &callAupf = ptCi->endPointInfo.aupf[srvUpIdx];
    if (callAupf.usage == CI_use && ptCi->endPointInfo.srvAupfNum > 0)
    {
        ptCi->endPointInfo.srvAupfNum--;
    }

    VCCB_PRINT_CALL_MSG(ptCi, "[AUPF(id:%lu E1Idx:%u) RELEASED] Remaining Serving AUPFs num:%u\n", callAupf.aupfId,
        callAupf.e1Idx, ptCi->endPointInfo.srvAupfNum);

    RscCall::setUeActivityStatusPerUP(*ptCi, srvUpIdx, ActivityStatus_INACTIVE);
    FeatAupf::initCallAupf(callAupf);

    if (0 == ptCi->endPointInfo.srvAupfNum)
    {
        OFF_E1_RESOURCE_FLAG(ptCi->flag.setupFlag);
    }
}

/**
 * @breif Check if At lease one of Resposne Messages was Successful
 * @param [in] ptCi     : The pointer for the call context.
 * return true  : Partial Success
 * return false : Full Failure
 */
bool VRRM_isE1PartialSuccess(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // If there is at least one Successful Response
    for (uint16_t srvUpIdx = 0; srvUpIdx < MAX_CU_UP_PER_CALL; ++srvUpIdx)
    {
        if (CI_use == ptCi->endPointInfo.aupf[srvUpIdx].usage &&
            VCCB_FLAG_ON == ptCi->flag.e1Flag[srvUpIdx].isRequestSend &&
            VCCB_FLAG_ON == ptCi->flag.e1Flag[srvUpIdx].isSuccessResponseReceived)
        {
            return true;
        }
    }
    return false;
}

/**
 * @brief Mark related bearers as to be released for Failed Up
 * @param [in] ptCi     : The pointer for the call context.
 * @param [in] srvUpIdx : The index of impacted serving UP
 */
void VRRM_MarkBearersToReleaseForFailedUP(callInfo_type *ptCi, uint16_t srvUpIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(srvUpIdx, MAX_CU_UP_PER_CALL);

    // Mark related ERABs/PDUSess as to be Released
    if (E_CALLTYPE_NSA == ptCi->callType)
    {
        for (callERABInfo_type &erabInfo : ptCi->erabInfo)
        {
            if (CI_use != erabInfo.usage || erabInfo.e1Idx != ptCi->endPointInfo.aupf[srvUpIdx].e1Idx)
            {
                continue;
            }
            erabInfo.sgnbInitRelFlag = VCCB_FLAG_ON;
        }
    }
    else  // SA
    {
        for (callPDUSessInfo_type &pduSessInfo : ptCi->pduSess)
        {
            if (CI_use != pduSessInfo.usage || pduSessInfo.e1Idx != ptCi->endPointInfo.aupf[srvUpIdx].e1Idx)
            {
                continue;
            }

            // 23A_NRRetainability
            if((VCCB_FLAG_ON == ptCi->flag.e1Flag[srvUpIdx].isE1Reset) &&
               (e_ReleaseTriggerNotRelease != ptCi->endPointInfo.aupf[srvUpIdx].resetEventType))
            {
                pduSessInfo.releaseInfo.triggerEvent = ptCi->endPointInfo.aupf[srvUpIdx].resetEventType;
                pduSessInfo.releaseInfo.releaseCause = ptCi->endPointInfo.aupf[srvUpIdx].e1Cause;

                // Clear resetEventType
                ptCi->endPointInfo.aupf[srvUpIdx].resetEventType = e_ReleaseTriggerNotRelease;
            }
            else
            {
                pduSessInfo.releaseInfo.triggerEvent = e_ReleaseTriggerByUpFailureInMultiUP;
                pduSessInfo.releaseInfo.releaseCause = ptCi->endPointInfo.aupf[srvUpIdx].e1Cause;
                if (STATE_INTER_Exe_T == ptCi->state)
                {
                    // Multi UP partial success for SN Status Transfer in STATE_INTER_Exe_T (tgt side for Inter-gnb HO)
                    OFFBIT(pduSessInfo.flag.respFlag, PDU_SESS_E1_MODIFY_FLAG);
                }
            }
        }
    }
}

/**
 * @brief FR 112 : VCCB shall maintain a UE and UP(s) even if it does not receive successful outcome from UP in cases
           [21D] SN Status Transfer (PDCP SN Status Information)
           VCCB shall release all bearers on failed UP
 * @param [in] ptCi     : The pointer for the call context.
 * @param [out] isPartialSuccess  : true if there is partial success,
 *                                  false for full failure
 */
bool CheckifPartialSuccesAndEnueueBearersRelease(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    bool isPartialSuccess = false;
    bool needBearerRelease = false;

    for (uint16_t srvUpIdx = 0; srvUpIdx < MAX_CU_UP_PER_CALL; ++srvUpIdx)
    {
        if (CI_no_use == ptCi->endPointInfo.aupf[srvUpIdx].usage ||
            VCCB_FLAG_OFF == ptCi->flag.e1Flag[srvUpIdx].isRequestSend)
        {
            if (VCCB_FLAG_ON != ptCi->flag.e1Flag[srvUpIdx].isE1ErrorIndReceived)
            {
                continue;
            }
        }

        if (VCCB_FLAG_ON == ptCi->flag.e1Flag[srvUpIdx].isSuccessResponseReceived)
        {
            // Accept Partial Success
            isPartialSuccess = true;
        }
        else
        {
            needBearerRelease = true;
            VRRM_MarkBearersToReleaseForFailedUP(ptCi, srvUpIdx);
        }
    }
    if (isPartialSuccess && needBearerRelease && ptCi->state != STATE_INTER_Exe_T)
    {
        // VCCM_HandleDequeuedReleaseBearerByUpFail in idle state
        if (ERROR == VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_BEARER_RELEASE))
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "VCCM_enqueueAction(ENQUEUE_ACTION_BEARER_RELEASE) fail !!\n");
        }
    }
    return isPartialSuccess;
}

/**
 * @brief   Prepare container with ERAB lists mapped to QCI
 * @param [in] rCi : reference to callInfo_type
 * @return     ErabListPerQCI_type : list of erabs lists
 */
ErabListPerQCI_type VRRM_PrepareErabListPerQci(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;
    ErabListPerQCI_type result;

    for (callERABInfo_type &erab : rCi.erabInfo)
    {
        if (CI_use != erab.usage)
        {
            continue;
        }
        else if (ERAB_Setup == erab.erabStatus)
        {
            result[erab.erabQos.qciValue.QCI].push_back(&erab);
        }
    }
    if (result.empty())
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "Creating requested erab list: list is empty!\n");
    }
    return result;
}

/**
 * @brief   Prepare container with PDU Session lists mapped to NSSAI
 * @param [in] rCi : reference to callInfo_type
 * @return     PduSessListPerNssai_type : list of erabs lists
 */
PduSessListPerNssai_type VRRM_PreparePduSessListPerNssai(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;
    PduSessListPerNssai_type result;

    for (callPDUSessInfo_type &pduSession : rCi.pduSess)
    {
        if (CI_use != pduSession.usage)
        {
            continue;
        }
        else if (S_Setup == pduSession.pduSessStatus)
        {
            result[pduSession.sNssai.sstSd].push_back(&pduSession);
        }
    }
    if (result.empty())
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "Creating requested pduSession list: list is empty!\n");
    }
    return result;
}

/**
 * @brief Assign given GNB CU UP idx to given ERAB list
 * @param [in] erabs : container with pointers to ERABs
 * @param [in] aupf  : given GNB CU UP
 */
void VRRM_UpdateErabVecWithGivenAupf(std::vector<callERABInfo_type *> &erabs, const AupfStatusInfo_type &aupf)
{
    AUTO_TRACE_FUNC;
    for (callERABInfo_type *pErab : erabs)
    {
        pErab->e1Idx = aupf.endPointIdx;
        VCCB_PRINT_MSG("[AUPF:(id:%lu E1Idx:%u) SELECTED for ERAB-id:%d QCI:%d]\n", aupf.aupfId, aupf.endPointIdx,
            pErab->eRABId, pErab->erabQos.qciValue.QCI);
    }
    erabs.clear();
}

/**
 * @brief Assign given GNB CU UP idx to given ERAB list
 * @param [in] erabs : container with pointers to ERABs
 * @param [in] aupf  : given GNB CU UP
 */
void VRRM_UpdatePduSessVecWithGivenAupf(std::vector<callPDUSessInfo_type *> &pduSessions, const AupfStatusInfo_type &aupf)
{
    AUTO_TRACE_FUNC;
    for (callPDUSessInfo_type *pSession : pduSessions)
    {
        pSession->e1Idx = aupf.endPointIdx;
        VCCB_PRINT_MSG("[AUPF:(id:%lu E1Idx:%u) SELECTED for PDU Session SST(%u)/SD(%u) hex:%d]\n", aupf.aupfId,
            aupf.endPointIdx, pSession->sNssai.sst, pSession->sNssai.sd, pSession->sNssai.sstSd);
    }
    pduSessions.clear();
}

/**
 * @brief      Search for supported PLMN index within AupfStatusInfo_type
 * @details    FGR-CC1105 Bearer Context Management via E1
 * @param [in] rCi           : reference to Ue Context
 * @param [in] candidateAUPF  : AupfStatusInfo_type being searched
 * @return     index of supported PLMN or MAX_E1_SUPPORTED_PLMN if not found
 */
static uint8_t VRRM_AUPFSelectionGetSupportedPLMNIndex(const callInfo_type &rCi, const AupfStatusInfo_type *candidateAUPF)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(candidateAUPF, MAX_E1_SUPPORTED_PLMN);
    uint8_t loop;
    if (candidateAUPF->plmnCnt > MAX_E1_SUPPORTED_PLMN)
    {
        VCCB_PRINT_CALL_ERROR(&rCi,
            "AupfStatusInfo_type supports invalid number of PLMNs, gNBIdx:%d endPointIdx:%d aupfId:%lud plmnCnt:%d\n",
            candidateAUPF->gNBIdx, candidateAUPF->endPointIdx, candidateAUPF->aupfId, candidateAUPF->plmnCnt);
        return MAX_E1_SUPPORTED_PLMN;
    }
    for (loop = 0; loop < candidateAUPF->plmnCnt; loop++)
    {
        if (rCi.ueInfo.servedPlmn.longId == candidateAUPF->plmn[loop])
        {
            return loop;
        }
    }
    return MAX_E1_SUPPORTED_PLMN;
}

/**
 * @brief Assign index of matched CU UP to ERABs
 * @param [in] aupf : Selected GNB CU UP
 * @return     Number of Erabs where GNB CU UP was assigned
 */
uint8_t VRRM_AssignAupfToErabs(const callInfo_type &rCi, const AupfStatusInfo_type &aupf, ErabListPerQCI_type &erabContainer)
{
    AUTO_TRACE_FUNC;

    uint8_t erabAssignedCount = 0;
    const uint8_t plmnIndex = VRRM_AUPFSelectionGetSupportedPLMNIndex(rCi, &aupf);
    VCCB_CHECK_E_RANGE_AND_VAL(plmnIndex, MAX_PLMN_INDEX, 0);
    if (0 == aupf.eutranQciPerPlmnCnt[plmnIndex])  // AUPF do not support any qci; we can assign every erab here
    {
        for (auto &erabVec : erabContainer)
        {
            erabAssignedCount = static_cast<uint8_t>(erabAssignedCount + erabVec.size());
            VRRM_UpdateErabVecWithGivenAupf(erabVec, aupf);
        }
    }
    else
    {
        for (int aupfQciIdx = 0; aupfQciIdx < aupf.eutranQciPerPlmnCnt[plmnIndex]; ++aupfQciIdx)
        {
            auto &erabVec = erabContainer[aupf.eutranQci[plmnIndex][aupfQciIdx]];
            erabAssignedCount = static_cast<uint8_t>(erabAssignedCount + erabVec.size());
            VRRM_UpdateErabVecWithGivenAupf(erabVec, aupf);
        }
    }
    return erabAssignedCount;
}

/**
 * @brief Assign index of matched CU UP to ERABs
 * @param [in] aupf : Selected GNB CU UP
 * @return     Number of Erabs where GNB CU UP was assigned
 */
uint8_t VRRM_AssignAupfToPduSess(
    const callInfo_type &rCi, const AupfStatusInfo_type &aupf, PduSessListPerNssai_type &pduSessList)
{
    AUTO_TRACE_FUNC;
    UNUSED1(pduSessList);

    uint8_t assignedSessionCount = 0;
    const uint8_t plmnIndex = VRRM_AUPFSelectionGetSupportedPLMNIndex(rCi, &aupf);
    VCCB_CHECK_E_RANGE_AND_VAL(plmnIndex, MAX_PLMN_INDEX, 0);
    if (0 == aupf.supportedSnssaiGrpCntPerPlmn[plmnIndex])  // AUPF do not support any S-NSSAI; we can assign every erab here
    {
        for (auto &pduSessPair : pduSessList)
        {
            assignedSessionCount = static_cast<uint8_t>(assignedSessionCount + pduSessPair.second.size());
            VRRM_UpdatePduSessVecWithGivenAupf(pduSessPair.second, aupf);
        }
    }
    else
    {
        for (auto iter = pduSessList.begin(); iter != pduSessList.end(); iter++)
        {
            uint32_t sstSd = iter->first;        

            for (uint32_t grpIdx = 0; grpIdx < aupf.supportedSnssaiGrpCntPerPlmn[plmnIndex]; grpIdx++)
            {
                if ( (aupf.supportedSnssaiGrp[plmnIndex][grpIdx] <= sstSd) &&
                     (sstSd < (aupf.supportedSnssaiGrp[plmnIndex][grpIdx] + aupf.supportedSnssaiGrpLength[plmnIndex][grpIdx])) )
                {
                    auto &pduSessVec = iter->second;
                    assignedSessionCount = static_cast<uint8_t>(assignedSessionCount + pduSessVec.size());
                    VRRM_UpdatePduSessVecWithGivenAupf(pduSessVec, aupf);

                    break;
                }
            }
        }
    }
    return assignedSessionCount;
}

/**
 * @brief      Get weight factor which DU ID range matched AUPF DU ID
 *             FGR-CC1105 Bearer Context Management via E1
 * @param [in] rCi : reference to Ue Context
 * @param [in/out] candidateAupfVec : candidates of AUPFs
 */
uint16_t VRRM_GetDuWeightFactor(const callInfo_type &rCi, uint64_t aupfId)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(rCi.gnbNum, MAX_GNB_PER_SYS, DEFAULT_WEIGHT_FACTOR);
    VCCB_CHECK_E_RANGE_AND_VAL(rCi.endPointInfo.f1Idx, MAX_GNB_DU_PER_GNB_CU_CP, DEFAULT_WEIGHT_FACTOR);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[rCi.gnbNum];

    duWeightFactor_type *duWeightFactorEnd =
        CFG->duWeightFactor + sizeof(CFG->duWeightFactor) / sizeof(CFG->duWeightFactor[0]);
    const uint64_t duId = pGnb->gnbDu[rCi.endPointInfo.f1Idx].gnbDuId;

    auto duWeightFactorIt = std::find_if(&CFG->duWeightFactor[0], duWeightFactorEnd,
        [&](const duWeightFactor_type &duWeightFactor)
        {
            return duWeightFactor.usage == CI_use && duWeightFactor.cuUpId == aupfId &&
                   duWeightFactor.duIdRange.start <= duId && duWeightFactor.duIdRange.end >= duId;
        });
    if (duWeightFactorIt < duWeightFactorEnd)
    {
        return duWeightFactorIt->value;
    }
    return DEFAULT_WEIGHT_FACTOR;
}

/**
 * @brief      Compare IP addresses.
 * @param maxBitCount   : maximum number of bits to compare (submask length)
 * @return              : true if IPs matches
 */
bool compareIPv6Prefix(const coreWeightFactor_type::ipv6_s &coreIp, const MdsIp_Type &rabIp, uint8_t maxBitCount)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(maxBitCount, MAX_IPV6_BIT + 1, false);

    if (0 >= maxBitCount) return false;
    int8_t tabIdx = 0;
    // compare first bytes by whole value. Only last byte may need comparison by bits
    while (tabIdx < maxBitCount / 8)
    {
        if (coreIp.ip[tabIdx] != rabIp.Ip.V6[tabIdx]) return false;
        ++tabIdx;
    }
    for (uint8_t bitIdx = 7; bitIdx > 7 - (maxBitCount - (tabIdx * 8)); --bitIdx)
    {
        if (GETBIT(coreIp.ip[tabIdx], bitIdx) != GETBIT(rabIp.Ip.V6[tabIdx], bitIdx))
        {
            return false;
        }
    }
    return true;
}

/**
 * @brief      Compare IP addresses.
 * @param maxBitCount   : maximum number of bits to compare (submask length)
 * @return              : true if IPs matches
 */
bool compareIPv4Prefix(const coreWeightFactor_type::ipv4_s &coreIp, const MdsIp_Type &rabIp, uint8_t maxBitCount)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(maxBitCount, MAX_IPV4_BIT + 1, false);

    if (0 >= maxBitCount) return false;
    for (int i = MAX_IPV4_BIT - 1; i >= MAX_IPV4_BIT - maxBitCount; --i)
    {
        if (GETBIT(coreIp.ip, i) != GETBIT(rabIp.Ip.V4, i))
        {
            return false;
        }
    }
    return true;
}

uint8_t compareIpsForWeightFactors(const coreWeightFactor_type &coreWeightFactor, const transportLayerInfo_type &rabIp)
{
    AUTO_TRACE_FUNC;
    uint8_t lengthScore = 0;

    if (rabIp.numTLAbit == MAX_IPV4_BIT || rabIp.numTLAbit == MAX_IPV4V6_BIT)
    {
        auto mdsRabIp = VLIB_ConvertTLA2MdsIp_Type(rabIp.TLAddr, rabIp.numTLAbit);
        lengthScore = static_cast<uint8_t>(compareIPv4Prefix(coreWeightFactor.ipv4, mdsRabIp, coreWeightFactor.ipv4.prefixBitLen)
                          ? coreWeightFactor.ipv4.prefixBitLen + IPV4V6_BIT_DIFF
                          : 0);
    }
    if (rabIp.numTLAbit == MAX_IPV6_BIT || rabIp.numTLAbit == MAX_IPV4V6_BIT)
    {
        auto mdsRabIpv6 = VLIB_ConvertTLA2MdsIp_Type(
            rabIp.TLAddr + (rabIp.numTLAbit == MAX_IPV4V6_BIT ? ADDRLEN_IPV4 : 0), MAX_IPV6_BIT);
        if (compareIPv6Prefix(coreWeightFactor.ipv6, mdsRabIpv6, coreWeightFactor.ipv6.prefixBitLen))
        {
            lengthScore = std::max(lengthScore, coreWeightFactor.ipv6.prefixBitLen);
        }
    }

    return lengthScore;
}

/**
 * @brief      Get weight factor from entry with longest
 *             IP prefix that matches to requested IP of DRB
 *             FGR-CC1105 Bearer Context Management via E1
 * @param [in] ipAddr : address received for Bearer
 */
uint16_t getWeightFactorBestMatchingIp(const transportLayerInfo_type &rabIp, uint64_t aupfId)
{
    AUTO_TRACE_FUNC;
    uint8_t bestIpLen = 0;
    uint16_t bestWeightFactor = DEFAULT_WEIGHT_FACTOR;

    for (const auto &weightFactor : CFG->coreWeightFactor)
    {
        if (weightFactor.usage != CI_use || weightFactor.cuUpId != aupfId) continue;

        uint8_t lengthScore = compareIpsForWeightFactors(weightFactor, rabIp);
        if (lengthScore > bestIpLen)
        {
            bestIpLen = lengthScore;
            bestWeightFactor = weightFactor.value;
        }
    }
    return bestWeightFactor;
}

/**
 * @brief      Choose AUPF with smallest sum of weight factors
 *             FGR-CC1105 Bearer Context Management via E1
 * @param [in] rCi : reference to Ue Context
 * @param [in/out] candidateAupfVec : candidates of AUPFs
 */
void VRRM_LimitAupfCandidatesWeightFactors(const callInfo_type &rCi, std::vector<AupfStatusInfo_type *> &candidateAupfVec)
{
    AUTO_TRACE_FUNC;
    if (candidateAupfVec.size() <= 1)
    {
        return;
    }

    int bestScore = MAX_WEIGHT_FACTOR * std::max(MAX_PDU_SESS_PER_CALL, MAX_ERAB_PER_CALL);
    std::set<AupfStatusInfo_type *> newCandidateAupfSet;
    for (AupfStatusInfo_type *pAupf : candidateAupfVec)
    {
        const uint16_t duWeightFactor = VRRM_GetDuWeightFactor(rCi, pAupf->aupfId);
        if (rCi.callType == E_CALLTYPE_NSA)
        {
            for (const auto &erab : rCi.erabInfo)
            {
                if (erab.usage != CI_use || erab.e1Idx != UNKNOWN_UPIDX || erab.erabStatus != ERAB_Setup)
                {
                    continue;
                }
                const int score = duWeightFactor + getWeightFactorBestMatchingIp(erab.s1uUlInfo, pAupf->aupfId);
                if (score > bestScore) continue;
                if (score < bestScore)
                {
                    bestScore = score;
                    newCandidateAupfSet.clear();
                }
                newCandidateAupfSet.insert(pAupf);
            }
        }
        else
        {
            for (const auto &pduSession : rCi.pduSess)
            {
                int score = MAX_WEIGHT_FACTOR * 2;
                if (pduSession.usage != CI_use || pduSession.pduSessStatus != S_Setup) continue;

                VCCB_CHECK_E_RANGE_AND_CONTINUE(pduSession.drbIndex[0], MAX_DRB_PER_SA_CALL);
                const auto &drb = rCi.drb[pduSession.drbIndex[0]];
                if (drb.usage != CI_use || drb.drbStatus != S_Setup) continue;

                if (!IS_NRDC(&rCi) || (IS_NRDC_MN(&rCi) && drb.bearerType.termPoint == TermPoint_Mn))
                {
                    score = duWeightFactor + getWeightFactorBestMatchingIp(pduSession.nGuUlInfo, pAupf->aupfId);
                }
                else if (IS_NRDC_SN(&rCi) && drb.bearerType.termPoint == TermPoint_Sn)
                {
                    score = duWeightFactor + getWeightFactorBestMatchingIp(pduSession.snNGuUlInfo, pAupf->aupfId);
                }
                else
                    continue;

                if (score > bestScore) continue;
                if (score < bestScore)
                {
                    bestScore = score;
                    newCandidateAupfSet.clear();
                }
                newCandidateAupfSet.insert(pAupf);
            }
        }
    }
    if (!newCandidateAupfSet.empty())
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "[AUPF selection] %lu candidates limited to %lu considering weight factors.\n",
            candidateAupfVec.size(), newCandidateAupfSet.size());
        candidateAupfVec.assign(newCandidateAupfSet.begin(), newCandidateAupfSet.end());
    }
}

/**
 * @brief      Select handling AUPF for Bearer Context Setup procedure
 *             Capacity based : All Bearers to same UP
 * @details    FGR-CC1105 Bearer Context Management via E1
 * @param [in] rCi           : reference to Ue Context
 * @param [in] candidateAUPFs : collected candidates
 * @return     pointer to selected AUPF
 */
static AupfStatusInfo_type *VRRM_AUPFSelectionCapacityBased(
    const callInfo_type &rCi, std::vector<AupfStatusInfo_type *> &candidateAUPFs)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_VAL(candidateAUPFs.size(), 1, MAX_GNB_CU_UP_PER_GNB_CU_CP, nullptr);

    uint16_t totalCapacity = 0, capacitySum = 0;
    unsigned int randomCapacity = 0;

    // Compute total capacity
    for (AupfStatusInfo_type *pAupf : candidateAUPFs)
    {
        totalCapacity = static_cast<uint16_t>(totalCapacity + pAupf->capacity);
    }
    // FR501 gNB-CU-CP shall select gNB-CU-UP of a higher capacity with a higher probability among available gNB-CU-UPs
    if (totalCapacity > 0)
    {
        randomCapacity = FnVCCB_GetRandomValue(__func__, static_cast<uint16_t>(rCi.gnbNum % MAX_GNB_PER_SYS), totalCapacity);

        VCCB_CHECK_E_RANGE_AND_VAL(randomCapacity, UINT_MAX, nullptr);

        for (AupfStatusInfo_type *pAupf : candidateAUPFs)
        {
            capacitySum = static_cast<uint16_t>(capacitySum + pAupf->capacity);
            if (randomCapacity < capacitySum)
            {
                VCCB_PRINT_CALL_COMMENT(&rCi,
                    "[AUPF:%d CAPA SEL] totalCapa:%d randCapa:%d sumOfCapa:%d candidateNum:%zu\n", pAupf->endPointIdx,
                    totalCapacity, randomCapacity, capacitySum, candidateAUPFs.size());
                return pAupf;
            }
        }
    }
    // Abnormal CASE AUPF not slected
    VCCB_PRINT_CALL_ERROR(&rCi,
        "Unexpected ERROR Capcity AUPF Selecteion totalCapa:%d randCapaIdx:%d sumOfCapa:%d candidateNum:%zu\n",
        totalCapacity, randomCapacity, capacitySum, candidateAUPFs.size());
    return nullptr;
}

/**
 * @brief      Make set of QCIs requested in callInfo
 * @details    FGR-CC1105 Bearer Context Management via E1
 * @param [in] rCi           : reference to Ue Context
 * @return     set of QCIs
 */
std::set<uint8_t> VRRM_GetQCIsFromRequestedWaitingERABs(const callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;
    std::set<uint8_t> requestedQciSet;

    for (const callERABInfo_type &erab : rCi.erabInfo)
    {
        if ((CI_use != erab.usage) || (UNKNOWN_UPIDX != erab.e1Idx))
        {
            continue;
        }
        else if (ERAB_Setup == erab.erabStatus)
        {
            requestedQciSet.insert(static_cast<uint8_t>(erab.erabQos.qciValue.QCI));
        }
    }
    return requestedQciSet;
}
 
/**
 * @brief      Make set of PDU sessions requested in callInfo
 * @details    FGR-CC1109 Multi UP per Single UE
 * @param [in] rCi           : reference to Ue Context
 * @return     set of QCIs
 */
std::set<uint32_t> VRRM_GetNssaiFromRequestedWaitingPDUSessions(const callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;
    std::set<uint32_t> requestedNssaiSet;

    for (const auto &pduSession : rCi.pduSess)
    {
        if ((CI_use != pduSession.usage) || (UNKNOWN_UPIDX != pduSession.e1Idx))
        {
            continue;
        }
        else if (S_Setup == pduSession.pduSessStatus ||
                (S_Modify == pduSession.pduSessStatus && FnVCCB_IsPDUSessTobeSetupToUP(&rCi, pduSession)))
        {
            requestedNssaiSet.insert(pduSession.sNssai.sstSd);
        }
    }
    return requestedNssaiSet;
}

/**
 * @brief      Make set of QCIs supported by given GNB CU UP
 * @details    FGR-CC1105 Bearer Context Management via E1
 * @param [in] rCi           : reference to Ue Context
 * @param [in] aupf           : selected GNB CU UP
 * @return     set of QCIs supported by GNB CU UP
 */
std::set<uint8_t> VRRM_GetAupfSupportedQCIs(const callInfo_type &rCi, const AupfStatusInfo_type &aupf)
{
    AUTO_TRACE_FUNC;

    std::set<uint8_t> supportedQciSet;
    const uint8_t plmnIndex = VRRM_AUPFSelectionGetSupportedPLMNIndex(rCi, &aupf);
    VCCB_CHECK_E_RANGE_AND_VAL(plmnIndex, MAX_PLMN_INDEX, supportedQciSet);
    VCCB_CHECK_E_RANGE_AND_VAL(aupf.eutranQciPerPlmnCnt[plmnIndex], MAX_EUTRAN_QCI_PER_PLMN + 1, supportedQciSet);

    for (uint8_t qciIdx = 0; qciIdx < aupf.eutranQciPerPlmnCnt[plmnIndex]; qciIdx++)
    {
        supportedQciSet.insert(static_cast<uint8_t>(aupf.eutranQci[plmnIndex][qciIdx]));
    }
    return supportedQciSet;
}

/**
 * @brief      Make set of NSSAIs supported by given GNB CU UP
 * @details    FGR-CC1109 Multi UP per Single UE
 * @param [in] rCi           : reference to Ue Context
 * @param [in] aupf           : selected GNB CU UP
 * @return     set of QCIs supported by GNB CU UP
 */
std::set<uint32_t> VRRM_GetAupfSupportedNssais(const callInfo_type &rCi, const AupfStatusInfo_type &aupf)
{
    AUTO_TRACE_FUNC;

    std::set<uint32_t> supportedNssaiSet;
    const uint8_t plmnIndex = VRRM_AUPFSelectionGetSupportedPLMNIndex(rCi, &aupf);
    VCCB_CHECK_E_RANGE_AND_VAL(plmnIndex, MAX_PLMN_INDEX, supportedNssaiSet);

    for (uint32_t grpIdx = 0; grpIdx < aupf.supportedSnssaiGrpCntPerPlmn[plmnIndex]; grpIdx++)
    {
        for (uint32_t sliceIdx = 0; sliceIdx < aupf.supportedSnssaiGrpLength[plmnIndex][grpIdx]; sliceIdx++)
        {
            supportedNssaiSet.insert(aupf.supportedSnssaiGrp[plmnIndex][grpIdx] + sliceIdx);
        }
    }

    return supportedNssaiSet;
}

/**
 * @brief      Select handling AUPF with best QCI score
 *             In case of equal QCIs in AUPFs selection is capacity based
 * @details    FGR-CC1105 Bearer Context Management via E1
 * @param [in] rCi           : reference to Ue Context
 * @param [in] candidateAUPFs : collected candidates
 * @return     GOOD : AUPF selection successfully done
 *            ERROR : No available AUPF
 */
AupfStatusInfo_type *VRRM_SelectBestQciAupf(
    const callInfo_type &rCi, std::vector<AupfStatusInfo_type *> &candidateAupfVec, bool considerEmptyQciAupf = false)
{
    AUTO_TRACE_FUNC;

    uint16_t maxScore = considerEmptyQciAupf ? 0 : 1;
    std::vector<AupfStatusInfo_type *> newCandidateAupfVec;
    const std::set<uint8_t> requestedQciSet = VRRM_GetQCIsFromRequestedWaitingERABs(rCi);

    // FR610  gNB-CU-CP shall, for Bearer Context Setup procedure,
    // select gNB-CU-UP of the largest number of common QCIs between requested E-RABs and UP's supported list
    // - If two or more UPs have the largest number of common QCIs, CP shall select one of them according to Capacity
    // based UP selection

    for (AupfStatusInfo_type *pAupf : candidateAupfVec)
    {
        const std::set<uint8_t> aupfSupportedQCIs = VRRM_GetAupfSupportedQCIs(rCi, *pAupf);
        std::vector<uint8_t> commonQciVec;
        std::set_intersection(requestedQciSet.begin(), requestedQciSet.end(), aupfSupportedQCIs.begin(),
            aupfSupportedQCIs.end(), std::back_inserter(commonQciVec));

        if (commonQciVec.size() < maxScore)
        {
            continue;
        }
        if (commonQciVec.size() > maxScore)
        {
            maxScore = static_cast<uint16_t>(commonQciVec.size());
            newCandidateAupfVec.clear();
        }
        newCandidateAupfVec.push_back(pAupf);
    }

    VCCB_PRINT_CALL_COMMENT(&rCi, "[AUPF selection] %lu candidates limited to %lu due to QCI score\n",
        candidateAupfVec.size(), newCandidateAupfVec.size());
    return VRRM_AUPFSelectionWeightFactorsAndCapacity(rCi, newCandidateAupfVec);
}

/**
 * @brief      Select handling AUPF with best NSSAI score
 *             In case of equal NSSAIs in AUPFs selection is capacity based
 * @details    FGR-CC1109 Multi UP per Single UE
 * @param [in] rCi           : reference to Ue Context
 * @param [in] candidateAUPFs : collected candidates
 * @return     GOOD : AUPF selection successfully done
 *            ERROR : No available AUPF
 */
AupfStatusInfo_type *VRRM_SelectBestNssaiAupf(const callInfo_type &rCi, std::vector<AupfStatusInfo_type *> &candidateAupfVec)
{
    AUTO_TRACE_FUNC;

    uint16_t maxScore = 1;
    std::vector<AupfStatusInfo_type *> newCandidateAupfVec;
    const std::set<uint32_t> requestedNssaiSet = VRRM_GetNssaiFromRequestedWaitingPDUSessions(rCi);

    // select gNB-CU-UP of the largest number of common NSSAI between requested PDU sesss and UP's supported list
    // - If two or more UPs have the largest number of common NSSAIs, CP shall select one of them according to Capacity
    // based UP selection

    for (AupfStatusInfo_type *pAupf : candidateAupfVec)
    {
        const std::set<uint32_t> aupfSupportedNssais = VRRM_GetAupfSupportedNssais(rCi, *pAupf);
        std::vector<uint32_t> commonNssaiVec;
        std::set_intersection(requestedNssaiSet.begin(), requestedNssaiSet.end(), aupfSupportedNssais.begin(),
            aupfSupportedNssais.end(), std::back_inserter(commonNssaiVec));

        if (commonNssaiVec.size() < maxScore)
        {
            continue;
        }
        if (commonNssaiVec.size() > maxScore)
        {
            maxScore = static_cast<uint16_t>(commonNssaiVec.size());
            newCandidateAupfVec.clear();
        }
        newCandidateAupfVec.push_back(pAupf);
    }

    VCCB_PRINT_CALL_COMMENT(&rCi, "[AUPF selection] %lu candidates limited to %lu due to S-NSSAI score\n",
        candidateAupfVec.size(), newCandidateAupfVec.size());
    return VRRM_AUPFSelectionWeightFactorsAndCapacity(rCi, newCandidateAupfVec);
}

/**
 * @brief      Select handling AUPF for Bearer Context Setup procedure
 *             QCI based : All bearers to same UP
 * @details    FGR-CC1105 Bearer Context Management via E1
 * @param [in] rCi           : reference to Ue Context
 * @param [in] candidateAUPFs : collected candidates
 * @return     GOOD : AUPF selection successfully done
 *            ERROR : No available AUPF
 */
int32_t VRRM_AUPFSelectionQciAware(callInfo_type &rCi, std::vector<AupfStatusInfo_type *> &candidateAupfVec)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(candidateAupfVec.size(), 1, MAX_GNB_CU_UP_PER_GNB_CU_CP);

    const AupfStatusInfo_type *const pGnbCuUp = VRRM_SelectBestQciAupf(rCi, candidateAupfVec, true);

    if (nullptr != pGnbCuUp)
    {
        FeatAupf::setCallAupf(rCi, 0, pGnbCuUp->endPointIdx, pGnbCuUp->aupfId);
        rCi.endPointInfo.srvAupfNum = 1;
        VCCB_PRINT_CALL_MSG(&rCi, "[AUPF:(id:%lu E1Idx:%u) SELECTED] QCI based Candidate Num:%zu\n", pGnbCuUp->aupfId,
            pGnbCuUp->endPointIdx, candidateAupfVec.size());
        return GOOD;
    }
    VCCB_PRINT_CALL_ERROR(
        &rCi, "Unexpected ERROR QCI based Selecteion QCI based Candidate Num:%zu\n", candidateAupfVec.size());

    return ERROR;
}

/**
 * @brief      Select handling AUPF for Bearer Context Setup procedure
 *             NSSAI based : All bearers to same UP
 * @details    FGR-CC1105 Bearer Context Management via E1
 * @param [in] rCi           : reference to Ue Context
 * @param [in] candidateAUPFs : collected candidates
 * @return     GOOD : AUPF selection successfully done
 *            ERROR : No available AUPF
 */
int32_t VRRM_AUPFSelectionNSSAIAware(callInfo_type &rCi, std::vector<AupfStatusInfo_type *> &candidateAupfVec)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(candidateAupfVec.size(), 1, MAX_GNB_CU_UP_PER_GNB_CU_CP);

    const AupfStatusInfo_type *const pGnbCuUp = VRRM_SelectBestNssaiAupf(rCi, candidateAupfVec);

    if (nullptr != pGnbCuUp)
    {
        FeatAupf::setCallAupf(rCi, 0, pGnbCuUp->endPointIdx, pGnbCuUp->aupfId);
        rCi.endPointInfo.srvAupfNum = 1;
        VCCB_PRINT_CALL_MSG(&rCi, "[AUPF:(id:%lu E1Idx:%u) SELECTED] NSSAI based Candidate Num:%zu\n",
            pGnbCuUp->aupfId, pGnbCuUp->endPointIdx, candidateAupfVec.size());
        return GOOD;
    }
    // Abnormal CASE AUPF not slected
    VCCB_PRINT_CALL_ERROR(
        &rCi, "Unexpected ERROR NSSAI based Selecteion NSSAI based. Candidate Num:%zu\n", candidateAupfVec.size());

    return ERROR;
}

/**
 * @brief      Util function to set same E1Idx for all
 *             E-RABs (for NSA) or PDU sessions (for SA)
 * @details    FGR-CC1109 Multi UP per Single UE
 * @param [in] rCi           : reference to Ue Context
 */
static void VRRM_AUPFSelectionFillOnBearerLevel(callInfo_type &rCi, enumAUPFSelectionMode_type aupfSelectionMode)
{
    AUTO_TRACE_FUNC;

    if (E_CALLTYPE_NSA == rCi.callType && AUPFSelectionMode_QciMultiUP != aupfSelectionMode)
    {
        for (callERABInfo_type &erabInfo : rCi.erabInfo)
        {
            if (CI_use == erabInfo.usage && ERAB_Setup == erabInfo.erabStatus)
            {
                erabInfo.e1Idx = rCi.endPointInfo.aupf[0].e1Idx;
            }
        }
    }
    else if (E_CALLTYPE_SA == rCi.callType && AUPFSelectionMode_SliceMultiUP != aupfSelectionMode)
    {
        for (callPDUSessInfo_type &pduSession : rCi.pduSess)
        {
            if (CI_use == pduSession.usage &&
                (S_Setup == pduSession.pduSessStatus || S_Modify == pduSession.pduSessStatus))
            {
                pduSession.e1Idx = rCi.endPointInfo.aupf[0].e1Idx;
            }
        }
    }
}

/**
 * @brief Choose already set up AUPFs from list of candidates
 * @param [in] rCi           : reference to Ue Context
 * @param [in] candidateAUPFs : collected candidates
 * @return     vector of already set up cadidates
 */
std::vector<AupfStatusInfo_type *> VRRM_GetOnlyAlreadySelectedAupfs(
    const callInfo_type &rCi, std::vector<AupfStatusInfo_type *> &candidateAupfVec)
{
    AUTO_TRACE_FUNC;
    std::vector<AupfStatusInfo_type *> result;
    for (const auto &au : rCi.endPointInfo.aupf)
    {
        auto candidateAupfIt = std::find_if(std::begin(candidateAupfVec), std::end(candidateAupfVec),
            [&](const AupfStatusInfo_type *pAupf) { return au.e1Idx == pAupf->endPointIdx; });
        if (std::end(candidateAupfVec) != candidateAupfIt)
        {
            result.push_back(*candidateAupfIt);
        }
    }
    return result;
}

/**
 * @brief Adds chosen AUPF to callInfo
 * @param [in] rCi           : reference to callInfo
 * @param [in] aupf : AUPF chosen by algorithm
 * @return     Number of Erabs where GNB CU UP was assigned
 */
int8_t VRRM_AssignChosenAupfIndex(callInfo_type &rCi, const AupfStatusInfo_type &aupf, ErabListPerQCI_type &erabContainer)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(rCi.endPointInfo.srvAupfNum, MAX_CU_UP_PER_CALL + 1);

    for (uint16_t i = 0; i < MAX_CU_UP_PER_CALL; ++i)
    {
        if ((CI_use == rCi.endPointInfo.aupf[i].usage) && (aupf.endPointIdx == rCi.endPointInfo.aupf[i].e1Idx))
        {
            VRRM_AssignAupfToErabs(rCi, aupf, erabContainer);
            return GOOD;
        }
        if (CI_no_use == rCi.endPointInfo.aupf[i].usage)
        {
            if (0 == VRRM_AssignAupfToErabs(rCi, aupf, erabContainer))
            {
                return BREAK;
            }  // dont assign if this AUPF doesn't support any matching QCI

            FeatAupf::setCallAupf(rCi, i, aupf.endPointIdx, aupf.aupfId);
            rCi.endPointInfo.srvAupfNum++;
            return GOOD;
        }
    }
    return ERROR;
}

/**
 * @brief Adds chosen AUPF to callInfo
 * @param [in] rCi           : reference to callInfo
 * @param [in] aupf : AUPF chosen by algorithm
 * @return     Number of Erabs where GNB CU UP was assigned
 */
int8_t VRRM_AssignChosenAupfIndex(
    callInfo_type &rCi, const AupfStatusInfo_type &aupf, PduSessListPerNssai_type &pduSessContainer)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(rCi.endPointInfo.srvAupfNum, MAX_CU_UP_PER_CALL + 1);

    for (uint16_t i = 0; i < MAX_CU_UP_PER_CALL; ++i)
    {
        if ((CI_use == rCi.endPointInfo.aupf[i].usage) && (aupf.endPointIdx == rCi.endPointInfo.aupf[i].e1Idx))
        {
            VRRM_AssignAupfToPduSess(rCi, aupf, pduSessContainer);
            return GOOD;
        }
        if (CI_no_use == rCi.endPointInfo.aupf[i].usage)
        {
            if (0 == VRRM_AssignAupfToPduSess(rCi, aupf, pduSessContainer))
            {
                return BREAK;
            }  // dont assign if this AUPF doesn't support any matching NSSAI

            FeatAupf::setCallAupf(rCi, i, aupf.endPointIdx, aupf.aupfId);
            rCi.endPointInfo.srvAupfNum++;
            return GOOD;
        }
    }
    return ERROR;
}

/**
 * @brief Remove  pointer to AUPF from list of candidates
 * @param [in] rCi           : reference to Ue Context
 * @param [in] candidateAUPFs : collected candidates
 */
void VRRM_RemoveSelectedAupfFromCadidates(std::vector<AupfStatusInfo_type *> &candidateAupfVec, AupfStatusInfo_type *pSelectedAupf)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pSelectedAupf);
    candidateAupfVec.erase(std::remove(std::begin(candidateAupfVec), std::end(candidateAupfVec), pSelectedAupf),
        std::end(candidateAupfVec));
}

/**
 * @brief      Checks if there is any ERAB waiting to be setup
 * @param [in] erabList : list of  ERABs mapped to QCI
 * @return     true : There is ERAB not assigned to GNB CU UP
 *            false : Every ERAB has been assigned
 */
bool VRRM_RemainingErabsExist(const ErabListPerQCI_type &erabList)
{
    AUTO_TRACE_FUNC;
    return std::find_if(std::begin(erabList), std::end(erabList),
               [&](const std::vector<callERABInfo_type *> &vec) { return !vec.empty(); }) != std::end(erabList);
}

/**
 * @brief      Checks if there is any PDU Session waiting to be setup
 * @param [in] erabList : list of  ERABs mapped to QCI
 * @return     true : There is ERAB not assigned to GNB CU UP
 *            false : Every ERAB has been assigned
 */
bool VRRM_RemainingPduSessExist(const PduSessListPerNssai_type &pduSessList)
{
    AUTO_TRACE_FUNC;
    return std::find_if(std::begin(pduSessList), std::end(pduSessList),
               [&](const std::pair<uint16_t, std::vector<callPDUSessInfo_type *>> &p)
               { return !p.second.empty(); }) != std::end(pduSessList);
}

/**
 * @brief      Count ERABs waiting to be setup
 * @param [in] erabList : list of  ERABs mapped to QCI
 * @return     true : There is ERAB not assigned to GNB CU UP
 *            false : Every ERAB has been assigned
 */
uint8_t VRRM_CountWaitingErabs(const ErabListPerQCI_type &erabList)
{
    AUTO_TRACE_FUNC;
    uint8_t waitingErabs = 0;
    for (const auto &erabVec : erabList)
    {
        waitingErabs = static_cast<uint8_t>(waitingErabs + erabVec.size());
        if (waitingErabs >= MAX_ERAB_PER_CALL)
        {
            break;
        }  // avoid iterating to the end
    }
    return waitingErabs;
}

/**
 * @brief      Count PDU sessions waiting to be setup
 * @param [in] erabList : list of  PDU Sess mapped to NSSAI
 * @return     true : There is PDU Session not assigned to GNB CU UP
 *            false : Every PDU Session has been assigned
 */
uint8_t VRRM_CountWaitingPduSessions(const PduSessListPerNssai_type &pduSessList)
{
    AUTO_TRACE_FUNC;
    uint8_t waitingSessions = 0;
    for (const auto &sessionVec : pduSessList)
    {
        waitingSessions = static_cast<uint8_t>(waitingSessions + sessionVec.second.size());
        if (waitingSessions >= MAX_PDU_SESS_PER_CALL)
        {
            break;
        }  // avoid iterating to the end
    }
    return waitingSessions;
}

/**
 * @brief      Select handling AUPFs, QCI basedd
 *             ERABs with the same QCI are assigned to matching AUPF
 * @param [in] rCi           : reference to Ue Context
 * @param [in] candidateAUPFs : collected candidates
 * @return     GOOD : AUPF selection successfully done
 *            ERROR : No available AUPF
 */
int32_t VRRM_AUPFSelectionQciMultiUP(callInfo_type &rCi, std::vector<AupfStatusInfo_type *> &candidateAupfVec)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(candidateAupfVec.size(), 1, MAX_GNB_CU_UP_PER_GNB_CU_CP);

    VCCB_PRINT_CALL_MSG(&rCi, "CandidateAUPsNum:%zu\n", candidateAupfVec.size());
    ErabListPerQCI_type erabsPerQciContainer = VRRM_PrepareErabListPerQci(rCi);
    bool considerEmptyQciListAupf = false;

    // Assign by QCI newly requested ERABs to already selected AUPFs
    while (VRRM_RemainingErabsExist(erabsPerQciContainer))
    {
        if (candidateAupfVec.empty())
        {
            VCCB_PRINT_CALL_ERROR(&rCi, "There are %u ERABs to set up, but no available AUPF!\n",
                VRRM_CountWaitingErabs(erabsPerQciContainer));
            return ERROR;
        }

        std::vector<AupfStatusInfo_type *> alreadyWorkingAupfs = VRRM_GetOnlyAlreadySelectedAupfs(rCi, candidateAupfVec);
        AupfStatusInfo_type *pGnbCuUp = VRRM_SelectBestQciAupf(rCi, alreadyWorkingAupfs, considerEmptyQciListAupf);
        if (nullptr == pGnbCuUp)
        {
            auto copyCandidates = candidateAupfVec;  // copying vector to avoid removing candidates for next iteration
            pGnbCuUp = VRRM_SelectBestQciAupf(rCi, copyCandidates, considerEmptyQciListAupf);
        }
        if ((nullptr == pGnbCuUp) && (considerEmptyQciListAupf == false))
        {
            considerEmptyQciListAupf = true;
            continue;
        }
        VALID_E_POINT_CHECK_ERROR(pGnbCuUp);

        VCCB_RETURN_ON_CALL_ERROR(&rCi, VRRM_AssignChosenAupfIndex(rCi, *pGnbCuUp, erabsPerQciContainer),
            "Cannot assign AUPF in VRRM_AssignAupfToErabs!\n");
        VRRM_RemoveSelectedAupfFromCadidates(candidateAupfVec, pGnbCuUp);
    }
    return GOOD;
}

/**
 * @brief      Select handling AUPFs, NSSAI basedd
 *             ERABs with the same S-NSSAI are assigned to matching AUPF
 * @param [in] rCi           : reference to Ue Context
 * @param [in] candidateAUPFs : collected candidates
 * @return     GOOD : AUPF selection successfully done
 *            ERROR : No available AUPF
 */
int32_t VRRM_AUPFSelectionNssaiMultiUP(callInfo_type &rCi, std::vector<AupfStatusInfo_type *> &candidateAupfVec)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(candidateAupfVec.size(), 1, MAX_GNB_CU_UP_PER_GNB_CU_CP);

    VCCB_PRINT_CALL_MSG(&rCi, "CandidateAUPsNum:%zu\n", candidateAupfVec.size());
    PduSessListPerNssai_type pduSessPerNssai = VRRM_PreparePduSessListPerNssai(rCi);
    bool anyAupfFound = false;

    // Assign by NSSSAI newly requested PDU sessions to already selected AUPFs
    while (VRRM_RemainingPduSessExist(pduSessPerNssai))
    {
        if (candidateAupfVec.empty())
        {
            VCCB_PRINT_CALL_ERROR(&rCi, "There are %u PDU sess to set up, but no available AUPF!\n",
                VRRM_CountWaitingPduSessions(pduSessPerNssai));
            return ERROR;
        }

        std::vector<AupfStatusInfo_type *> alreadyWorkingAupfs = VRRM_GetOnlyAlreadySelectedAupfs(rCi, candidateAupfVec);
        AupfStatusInfo_type *pGnbCuUp = VRRM_SelectBestNssaiAupf(rCi, alreadyWorkingAupfs);
        if (nullptr == pGnbCuUp)
        {
            auto copyCandidates = candidateAupfVec;  // copying vector to avoid removing candidates for next iteration
            pGnbCuUp = VRRM_SelectBestNssaiAupf(rCi, copyCandidates);
        }
        if ((nullptr == pGnbCuUp) && (anyAupfFound))
        {
            break;
        }
        VALID_E_POINT_CHECK_ERROR(pGnbCuUp);

        VCCB_RETURN_ON_CALL_ERROR(&rCi, VRRM_AssignChosenAupfIndex(rCi, *pGnbCuUp, pduSessPerNssai),
            "Cannot assign AUPF in VRRM_AssignAupfToErabs!\n");
        VRRM_RemoveSelectedAupfFromCadidates(candidateAupfVec, pGnbCuUp);
        anyAupfFound = true;
    }
    return GOOD;
}

/**
 * @brief      Select handling AUPF for Bearer Context Setup procedure
 *             Round Robin manner : All bearers to same UP
 * @details    No Feature Request in SVR19.A - Currently this function is used for debug Only
 * @param [in] rCi           : reference to Ue Context
 * @param [in] candidateAUPFs : collected candidates
 * @return     GOOD : AUPF selection successfully done
 *            ERROR : No available AUPF
 */
static int32_t VRRM_AUPFSelectionRoundRobin(callInfo_type &rCi, std::vector<AupfStatusInfo_type *> &candidateAUPFs)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(rCi.gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(candidateAUPFs.size(), 1, MAX_GNB_CU_UP_PER_GNB_CU_CP);

    VccbGnbInfo_type *const pGnb = &GNBINFO[rCi.gnbNum];

    uint16_t roundRobinIdx = 0;

    // [DBUG mode] gNB-CU-CP shall select gNB-CU-UP in Round Robin manner

    VRRM_MUTEX_LOCK(&gVrrmGnbCfgMtx);
    roundRobinIdx = pGnb->aupf.aupfSelectionRoundRobinIdx =
        static_cast<uint16_t>((pGnb->aupf.aupfSelectionRoundRobinIdx + 1) % static_cast<int>(candidateAUPFs.size()));
    VRRM_MUTEX_UNLOCK(&gVrrmGnbCfgMtx);

    const auto &pldAupf = *candidateAUPFs[roundRobinIdx];
    FeatAupf::setCallAupf(rCi, 0, pldAupf.endPointIdx, pldAupf.aupfId);
    rCi.endPointInfo.srvAupfNum = 1;

    VCCB_PRINT_CALL_MSG(&rCi, "[AUPF:(id:%lu E1Idx:%u) SELECTED] Round Robin aupfSelectionRoundRobinIdx:%d\n",
        pldAupf.aupfId, pldAupf.endPointIdx, roundRobinIdx);
    return GOOD;
}

/**
 * @brief       Collect available gNB-CU-UP candidates and their capacity sum for further AUPF selection
 *              FGR-CC1105 Bearer Context Management via E1
 * @param [in]  rCi           : reference to Ue Context
 * @param [out] candidateAUPFs : collected candidates
 * @return      GOOD  : At least one candidate exists
 *              ERROR : None AUPF is available
 */
static int32_t VRRM_AUPFSelectionCollectCandidates(callInfo_type &rCi, std::vector<AupfStatusInfo_type *> &candidateAUPFs)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(rCi.gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *const pGnb = &GNBINFO[rCi.gnbNum];

    uint16_t endPointIdx = 0, plmnIndex = 0, notSupportedCnNum = 0;
    uint16_t totalAUPFNum = 0, disabledNum = 0, overloadedNum = 0, notSupportedPlmnNum = 0;
    uint16_t capacityZeroNum = 0;
    std::vector<AupfStatusInfo_type *> candidateOverloadAUPFs;
    int16_t emergencyCall = (E_CALLTYPE_NSA == rCi.callType) ? FALSE : VCCM_CheckEmergencyBearer(&rCi);
    AupfStatusInfo_type *pGnbCuUp = nullptr;
    rCi.selectableUpsOverloadFlag = FALSE;

    // Collect AUPF candidates scheme
    // 1) FR502         gNB-CU-CP shall not select overloaded gNB-CU-UP
    // 2) FR503 [EN-DC] gNB-CU-CP shall not select gNB-CU-UP with CN support = 5GC
    // 3) FR505 [SA]    gNb-CU-CP shall not select gNB-CU-UP with CN support = EPC
    // 4) FR501         gNB-CU-UP is available only if the selected PLMN is supported
    // 5) FR504         gNB-CU-CP shall reject new call if no gNB-CU-UP is available

    for (endPointIdx = 0; endPointIdx < MAX_GNB_CU_UP_PER_GNB_CU_CP; endPointIdx++)
    {
        pGnbCuUp = &pGnb->aupf.gnbCuUp[endPointIdx];
        // if (EQUIP != pGnbCuUp->status || EQUIP != pGnbCuUp->statusPlmn)
        if (EQUIP != pGnbCuUp->status)
        {
            continue;
        }
        ++totalAUPFNum;

        if (OpState_enabled != pGnbCuUp->serviceState)
        {
            ++disabledNum;
            continue;
        }
        if (pGnbCuUp->capacity == 0)
        {
            ++capacityZeroNum;
            continue;
        }
        if (E_CALLTYPE_NSA == rCi.callType)
        {
            // TODO: change to correct enum type once it is implemented
            if (pGnbCuUp->cnSupport != 0 && pGnbCuUp->cnSupport != 2)  // cEpc or cBoth
            {
                ++notSupportedCnNum;
                continue;
            }
        }
        if (E_CALLTYPE_SA == rCi.callType)
        {
            if (pGnbCuUp->cnSupport != 1 && pGnbCuUp->cnSupport != 2)  // c5gc or cBoth//
            {
                ++notSupportedCnNum;
                continue;
            }
        }
        plmnIndex = VRRM_AUPFSelectionGetSupportedPLMNIndex(rCi, pGnbCuUp);
        if (plmnIndex == MAX_E1_SUPPORTED_PLMN)
        {
            ++notSupportedPlmnNum;
            continue;
        }
        if (ci_overload == pGnbCuUp->overloadStatus)
        {
            ++overloadedNum;
            candidateOverloadAUPFs.push_back(pGnbCuUp);
            continue;
        }
        candidateAUPFs.push_back(pGnbCuUp);
    }

    if (true == candidateAUPFs.empty())
    {
        // Accept overloaded UP
        if (false == candidateOverloadAUPFs.empty())
        {
            const bool isHpaMpsCall {E_CALLTYPE_SA == rCi.callType &&
                                     TRUE == pGnb->aupf.allowOverloadedUpForHpaMpsBearers &&
                                     (TRUE == VCCM_CheckMpsCall(&rCi)
                                     #ifdef LC0302_26B  // TODO: need to activate this code after adding HPA function
                                      || TRUE == VCCM_CheckHpaCall(&rCi)
                                     #endif
                                     )};

            if (TRUE == emergencyCall || 
                true == isHpaMpsCall)
            {
                candidateAUPFs = candidateOverloadAUPFs;
                VCCB_PRINT_CALL_MSG(&rCi, "AUPF Selection for emergency/HPA/MPS call allow overloaded UPs (%lu)\n", candidateAUPFs.size());
                return GOOD;
            }
        }
            
        VCCB_PRINT_CALL_ERROR(&rCi,
            "None of(%d) AUPFs is available. Num of Disabled(%d), Ovld(%d), NotSuppPLMN(%d) mcc:%x "
            "mnc:%x, CapaZero(%d) NotSuppCNType(%d)\n",
            totalAUPFNum, disabledNum, overloadedNum, notSupportedPlmnNum, rCi.ueInfo.servedPlmn.s2.mcc,
            rCi.ueInfo.servedPlmn.s2.mnc, capacityZeroNum, notSupportedCnNum);
        rCi.cause.x2Cause = CauseX2apMiscNotEnoughUserPlaneProcessingResources;

        if (overloadedNum > 0)
        {
            // FR179: [FGR-CC5200] Basic Operation for NR-DC
            // When serving UP selection for NR-DC SN call fails and some candidates were excluded due to overload state,
            // Then UP selection function shall indicate failure with cause='selectable UPs are overloaded'.
            rCi.selectableUpsOverloadFlag = TRUE;
        }
        return ERROR;
    }

    return GOOD;
}

/**
 * @brief    Get mode for AUPF selection
 *           in NRDC/NEDC Multi UP is not available
 * @param [in] ptCi : pointer to Ue Context
 */
enumAUPFSelectionMode_type VRRM_SetAupfSelectionModeConstraintMRDC(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, AUPFSelectionMode_Fixed);

    if (IsAvailable_MrdcInfo())
    {
        if (ptCi->aupfSelectionMode == AUPFSelectionMode_SliceMultiUP)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "UE operates in NRDC, changing AUPF selection: SliceMultiUP -> SliceBased\n");
            return AUPFSelectionMode_SliceBased;
        }
    }
    return ptCi->aupfSelectionMode;
}

/**
 * @brief      Limit candidate AUPFs for UP anchoring in Inter-RAT EN-DC to/from SA Ho with same gNB
 *             FGR-CC1105 Bearer Context Management via E1
 * @param [in] rCi : reference to Ue Context
 * @param [in/out] candidateAupfVec : candidates of AUPFs
 */
void VRRM_LimitAupfCandidatesAfterInterRatHo(const callInfo_type &rCi, std::vector<AupfStatusInfo_type *> &candidateAupfVec)
{
    AUTO_TRACE_FUNC;

    // Only for initial selection (X2AdditionRequest / NGHandoverRequest)
    if (STATE_II != rCi.state)
    {
        return;
    }

    std::vector<AupfStatusInfo_type *> newCandidateAupfVec;
    const callInfo_type *const pSrcCallInfo = FnVCCB_GetCallInUseByCuCpUeId(rCi.srcCuCpUeIdInterRATHo);
    if (pSrcCallInfo == NULL) return;

    for (AupfStatusInfo_type *pGnbCuUp : candidateAupfVec)
    {
        for (int aupfIdx = 0; aupfIdx < MAX_CU_UP_PER_CALL; ++aupfIdx)
        {
            if ((CI_use == pSrcCallInfo->endPointInfo.aupf[aupfIdx].usage) &&
                (pGnbCuUp->aupfId == pSrcCallInfo->endPointInfo.aupf[aupfIdx].aupfId))
            {
                newCandidateAupfVec.push_back(pGnbCuUp);
                break;
            }
        }
    }

    if (!newCandidateAupfVec.empty())
    {
        VCCB_PRINT_CALL_COMMENT(&rCi,
            "Candidate AUPFs(%lu) Limited to %lu according to src callId:%u in Inter-RAT EN-DC to/from SA Ho\n",
            candidateAupfVec.size(), newCandidateAupfVec.size(), rCi.srcCuCpUeIdInterRATHo);
        candidateAupfVec = std::move(newCandidateAupfVec);
    }
}

/**
 * @brief      Select handling AUPF for Bearer Context Setup procedure
 *             1) Select best matching by weight facotrs from confD
               2) Limit candidate AUPFs for UP anchoring in Inter-RAT EN-DC to/from SA Ho with same gNB
 *             3) Random selection considering capacity
 * @details    FGR-CC1105 Bearer Context Management via E1
 * @param [in] rCi           : reference to Ue Context
 * @param [in] candidateAUPFs : collected candidates
 * @return     pointer to selected AUPF
 */
AupfStatusInfo_type *VRRM_AUPFSelectionWeightFactorsAndCapacity(
    const callInfo_type &rCi, std::vector<AupfStatusInfo_type *> &candidateAUPFs)
{
    VRRM_LimitAupfCandidatesWeightFactors(rCi, candidateAUPFs);
    VRRM_LimitAupfCandidatesAfterInterRatHo(rCi, candidateAUPFs);

    return candidateAUPFs.size() < 1 ? nullptr :  // abnormal
               candidateAUPFs.size() == 1 ? candidateAUPFs[0]
                                          :  // One  candidate
               VRRM_AUPFSelectionCapacityBased(
                   rCi, candidateAUPFs);  // More candidates - Capacity based random selection
}

/**
 * @brief  Select handling AUPF for Bearer Context Setup procedure
 *         FGR-CC1105 Bearer Context Management via E1
 *         gNB-CU-CP shall support UP selection operation in the following order:
 *  - Exclude not-selectable UPs (PLMN, capacity, overlead, CN support etc.)
 *  - Select UPs supporting the largest number of QCI/S-NSSAI, if applicable
 *  - Select UPs where the sum of weight factors of (Core, UP) and (UP, DU) of each DRB is the smallest
 *  - Select UP with consideration of reference ID as the source gNB (e.g. SA ↔ EN-DC HO)
 *  - Select UP randomly with probability proportional to gNB-CU-UP Capacity
 * @param [in] ptCi : pointer to Ue Context
 * @return     GOOD : AUPF selection successfully done
 *            ERROR : No available AUPF
 */
int32_t VRRM_AUPFSelection(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    // Select handling gNB-CU-UP if PDU Session Resource Setup List IE is present
    if (E_CALLTYPE_SA == ptCi->callType && ptCi->numPDUSess <= 0)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[AUPF NOT SELECTED, NUMPDUSESS: %d]\n", ptCi->numPDUSess);
        return GOOD;
    }

    const enumAUPFSelectionMode_type aupfSelectionMode = VRRM_SetAupfSelectionModeConstraintMRDC(ptCi);
    if (VCOM_getSystemType() == e_VCCB_NVGNB)
    {
        // There is only 1 AUPF available in Non VRAN Configuration
        FeatAupf::setCallAupf(*ptCi, 0, 0, std::numeric_limits<uint64_t>::max());
        ptCi->endPointInfo.srvAupfNum = 1;
        VRRM_AUPFSelectionFillOnBearerLevel(*ptCi, aupfSelectionMode);
        return GOOD;
    }
    int32_t retVal = GOOD;
    AupfStatusInfo_type *pGnbCuUp = nullptr;
    std::vector<AupfStatusInfo_type *> candidateAupfVec;

    // Check if AUPF is already selected
    if (ptCi->endPointInfo.aupf[0].usage == CI_use && ptCi->endPointInfo.aupf[0].e1Idx < MAX_GNB_CU_UP_PER_GNB_CU_CP &&
        AUPFSelectionMode_QciMultiUP != aupfSelectionMode && AUPFSelectionMode_SliceMultiUP != aupfSelectionMode)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[AUPF:(id:%lu E1Idx:%u) ALREADY SELECTED]\n", ptCi->endPointInfo.aupf[0].aupfId,
            ptCi->endPointInfo.aupf[0].e1Idx);
        VRRM_AUPFSelectionFillOnBearerLevel(*ptCi, aupfSelectionMode);
        return GOOD;
    }

    if (GOOD != VRRM_AUPFSelectionCollectCandidates(*ptCi, candidateAupfVec) &&
        aupfSelectionMode != AUPFSelectionMode_Fixed)
    {
        // No Candidates found. Error Log printed in VRRM_AUPFSelectionCollectCandidates
        return ERROR;
    }

    switch (aupfSelectionMode)
    {
        case AUPFSelectionMode_ENDCCapacityBased:  // [NSA EN-DC] only
        case AUPFSelectionMode_CapacityBased:      // [SA or NRDC-SN]
            pGnbCuUp = VRRM_AUPFSelectionWeightFactorsAndCapacity(*ptCi, candidateAupfVec);
            if (nullptr != pGnbCuUp)
            {
                VCCB_PRINT_CALL_MSG(ptCi, "[AUPF:(id:%lu E1Idx:%u) SELECTED] Capacity based CandidateNum:%zu\n",
                    pGnbCuUp->aupfId, pGnbCuUp->endPointIdx, candidateAupfVec.size());
                FeatAupf::setCallAupf(*ptCi, 0, pGnbCuUp->endPointIdx, pGnbCuUp->aupfId);
                ptCi->endPointInfo.srvAupfNum = 1;
            }
            break;

        case AUPFSelectionMode_SliceBased:  // [SA or NRDC SN]
            retVal = VRRM_AUPFSelectionNSSAIAware(*ptCi, candidateAupfVec);
            break;

        case AUPFSelectionMode_SliceMultiUP:  // [SA] only
            retVal = VRRM_AUPFSelectionNssaiMultiUP(*ptCi, candidateAupfVec);
            break;

        case AUPFSelectionMode_QciAware:  // [NSA EN-DC] only
            retVal = VRRM_AUPFSelectionQciAware(*ptCi, candidateAupfVec);
            break;

        case AUPFSelectionMode_QciMultiUP:  // [NSA EN-DC] only
            retVal = VRRM_AUPFSelectionQciMultiUP(*ptCi, candidateAupfVec);
            break;

        case AUPFSelectionMode_RoundRobin:  // Debug mode
            retVal = VRRM_AUPFSelectionRoundRobin(*ptCi, candidateAupfVec);
            break;

        case AUPFSelectionMode_Fixed:  // Debug mode
        {
            const auto &aupfId =
                pGnb->aupf.gnbCuUp[ptCi->endPointInfo.aupf[0].e1Idx % MAX_GNB_CU_UP_PER_GNB_CU_CP].aupfId;
            FeatAupf::setCallAupf(*ptCi, 0, pGnb->aupf.aupfSelectionRoundRobinIdx, aupfId);
            ptCi->endPointInfo.srvAupfNum = 1;
            VCCB_PRINT_CALL_MSG(ptCi, "[AUPF:(id:%lu E1Idx:%u) SELECTED] Fixed Selection with no Checking!!\n", aupfId,
                pGnb->aupf.aupfSelectionRoundRobinIdx);
            break;
        }

        // default: All cases handled - default not needed
        default:
            break;
    }

    VRRM_AUPFSelectionFillOnBearerLevel(*ptCi, aupfSelectionMode);

    return retVal;
}
