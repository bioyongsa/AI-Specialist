#ifndef VCCB_FEAT_FeatMrl_H_
#define VCCB_FEAT_FeatMrl_H_

#include "VccbStruct.h"

int16_t VLIB_CompressHoRestrictInfo(callInfo_type *ptCi, const hoRestrictInfo_type *pSrc);
int16_t VLIB_DecompressHoRestrictInfo(const callInfo_type *ptCi, hoRestrictInfo_type *pTgt);

void VLIB_UpdateAllowedPlmn(const callInfo_type *ptCi, hoRestrictInfo_type *pMrl, BOOL cnTypeRestrictEutra);

#endif /* VCCB_FEAT_FeatMrl_H_ */
