/****************************************************************
 * System      : 5G NR
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatPreemption.h
 * Description :
 * Author      :
 * Dept.       : Call S/W Lab
 * Created     : 2024.11.20
 * Procedures defined :
 * Procedures called  :
 * Version     :
 * Revision history   :
 *          date      :
 *       revised by   :
 * revised information:
 ****************************************************************/

#ifndef VCCB_FEAT_FeatPreemption_H_
#define VCCB_FEAT_FeatPreemption_H_

#include "VccbStruct.h"

int16_t FnVCCB_IsDrbPreemptionRequestByE1(callInfo_type *ptCi, const msgUnpack_type *ptUnpack);
int16_t FnVCCB_Execute_DRBPreemptionByE1(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack, uint16_t srvUpIdx);
int16_t FnVCCB_Release_MarkedToBeReleasedDrbByE1(callInfo_type *ptCi, uint16_t msgId, uint8_t noWaitActionFlag);

#endif