/****************************************************************
 * System      : 5G vNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatCommon.h
 * Description :
 * Author      :
 * Dept.       : NG Access Lab.
 * Created     : 2016.08.01
 * Procedures defined :
 * Procedures called  :
 * Version     :
 * Revision history   :
 *          date      :
 *       revised by   :
 * revised information:
 ****************************************************************/

#ifndef VCCB_FEAT_FeatCommon_H_
#define VCCB_FEAT_FeatCommon_H_

#include "VccbStruct.h"

// int16_t VLIB_IncTimTransactionId (int16_t transactionId);
// int16_t VLIB_IncRRCTransactionId (uint8_t *transactionId);

void VLIB_SetCurStateAll(callInfo_type *ptCi, enumVccbCallState_type state);

uint64_t VLIB_calculateAmbrValue(callInfo_type *ptCi, enumLinkDirection direction);
// extern struct timespec tickGetMono(void);
uint8_t VLIB_checkCaCellHasFragmentedBW(uint16_t caCellNum);
uint8_t VLIB_GetMsgPeerInfo(uint32_t blockType);

int8_t VLIB_GetAuIndex(uint16_t caCellNum, uint32_t auId);
// void VLIB_MapCauseToInterfaceCause(callInfo_type *ptCi, uint16_t cause);
// void VLIB_MapCauseToInterfaceCauseSa(callInfo_type *ptCi, uint16_t cause);
int32_t VLIB_GetX2AssocIdxListByPci_Arfcn(
    uint16_t pci, uint16_t arfcn, uint16_t *assocIdxTab, uint32_t assocIdxTabSize);
int isOnAnrFunc(void);
// int16_t VLIB_AddNeighborCell(uint16_t srcCaCellNum, uint8_t srcCellNum, uint16_t dstCaCellNum, uint8_t dstCellNum);
// void VLIB_CallFaultSave (callInfo_type *ptCi, uint32_t msgId, uint16_t cause, const char *fnName);

void VLIB_CheckMultiCPC();
int16_t VLIB_CheckAllReleased(callInfo_type *ptCi);
void VLIB_setBearerStatusToIdle(callInfo_type *ptCi);
void VCCM_StoreSuccess_PreviousResource(callInfo_type *ptCi);
int16_t VLIB_CheckAllConnected(callInfo_type *ptCi);
void FnVCCB_PrintAllResponseFlag(callInfo_type *ptCi, const char *ptFunc, uint8_t isForcedPrintDetail);
// int16_t VLIB_CheckPingPongHandover(callInfo_type *ptCi);
int16_t VLIB_ClearAllRespFlags(callInfo_type *ptCi);
int16_t VLIB_ClearAllReleaseFlags(callInfo_type *ptCi);
void VLIB_ClearRefusedTargetFR1CellsList(callInfo_type *ptCi);
void VLIB_ConvertMdsIp_Type2TLA(uint8_t *TLAddr, uint16_t *numTLAbit, MdsIp_Type addr);
MdsIp_Type VLIB_ConvertTLA2MdsIp_Type(const uint8_t *TLAddr, uint16_t numTLAbit);
int16_t FnVCCB_ConvertCharMccToS2Type(uint8_t *ptMcc, uint8_t mccLen, s2_type *ptS2Type);
int16_t FnVCCB_ConvertCharMncToS2Type(uint8_t *ptMnc, uint8_t mncLen, s2_type *ptS2Type);
int16_t FnVCCB_GetS2TypeMccMnc(const dal_value_t *p_value, s2_type *ptS2Type, enumMccMnc_type type);
void VLIB_GetNbrEnbCellMccMnc(
    dal_value_t *p_value, nbrEnbCellInfo_type *nbrEnbCellInfo, uint8_t plmn_Index, enumMccMnc_type type);
void VLIB_GetNbrGnbCellMccMnc(
    dal_value_t *p_value, nbrGnbCellInfo_type *nbrGnbCellInfo, uint8_t plmn_Index, enumMccMnc_type type);
void VLIB_GetNbrGnbCellFreqBand(dal_value_t *p_value, nbrGnbCellInfo_type *nbrGnbCellInfo, uint8_t idx);
// long VLIB_getTickDifference (struct timespec prevTime);
// int16_t VLIB_FindReestInfoIndex(callInfo_type *ptCi, uint16_t caCellNum);
// int16_t VLIB_FillCallEnbInfoByCGI(callInfo_type *ptCi, cgi_type cgi);
// int16_t VLIB_isHoAllowedByCGI(cgi_type cgi);
int16_t VLIB_getBPLMN(const callInfo_type *ptCi, uint32_t cellNum, allowedPlmnList_Type *pt_b_plmn_list);
int16_t VLIB_getMultipleGnbPlmnIndexInfo(const callInfo_type *ptCi, uint8_t *serv_plmn_index, uint32_t plmnLongId);
int16_t VLIB_getMultipleGnbPlmnIndexInfo(uint16_t gnbNum, uint8_t *serv_plmn_index, uint32_t plmnLongId);

uint8_t VLIB_CheckCellPlmn(uint32_t servingPlmn, uint16_t sCellNum);
uint8_t VLIB_CheckNeighborPlmn(uint32_t servingPlmn, nbrGnbCellInfo_type *ptNbrGnbCellInfo);
uint8_t VLIB_GetCellPlmnIdx(uint32_t servingPlmn, uint16_t sCellNum, uint8_t *retIdx);
int16_t VLIB_isCellBelongsToGnb(plmnId_type *plmnId, uint64_t *cellIdentity, uint16_t gnbNum);
int16_t VLIB_FindCellNumFromCGI(cgi_type cgi, CellNum_type *ptCellNum);
bool isOutGoingHo(callInfo_type *ptCi);
// int16_t VLIB_FindSubCellNumFromCGI(cgi_type cgi, uint16_t *pCaCellNum, uint16_t *pSubCellNum);
int16_t VLIB_GetCellNumFromPhysCellId(
    callInfo_type *ptCi, uint16_t gnbNum, uint16_t physCellId, uint32_t ssbFrequency, uint16_t *cellNum);
int VLIB_QsortCandidateCellRsrpDescendingOrder(const void *arg1, const void *arg2);
int VLIB_QsortCandidateCellPriorityDescendingOrder(const void *arg1, const void *arg2);
int VLIB_QsortCandidateNrFreqItemsDescendingOrder(const void *arg1, const void *arg2);
int VLIB_QsortCandidateNrFreqItemsNrdcDescendingOrder(const void *arg1, const void *arg2);
int VLIB_QsortCandidateCellUeCountAscendingOrder(const void *arg1, const void *arg2);
void VLIB_UpdateCellListOfAllDu(uint16_t gnbNum);
void VLIB_UpdateCellListOfDu(uint16_t gnbNum, uint16_t endPointF1Idx);
void VLIB_AddCellToCellListOfDu(uint16_t gnbNum, uint16_t cellNum, uint16_t endPointF1Idx);
void VLIB_DelCellFromCellListOfDu(uint16_t gnbNum, uint16_t cellNum, uint16_t endPointF1Idx, uint16_t cause);
int VLIB_QsortUint16AscendingOrder(const void *arg1, const void *arg2);
int VLIB_QsortUint32AscendingOrder(const void *arg1, const void *arg2);
void VLIB_UpdatePcidUsedCellCount(uint16_t gnbNum, uint16_t cellNum, uint8_t prevServiceState);
int VLIB_IsAmDrbPresent(const callInfo_type *ptCi);
// int VLIB_HexstrToInt(uint32_t numByte, unsigned char* value, uint32_t len, uint32_t *intValue);
// uint64_t VLIB_GnbIdCellId2NrCellId(const gnbId_type *pGnbId, uint16_t cellId);
nasMessage_type *FnVCCB_GetNasMeassInfo(uint16_t nasIdx);
int16_t VLIB_AllocNasInfo(nasInfo_type *ptNas, uint8_t idx, uint32_t len, uint8_t *ptVal);

uint32_t VLIB_NrbScs2Bw(enumNrSystemBandwidth_type nrSysBw, enumNrSubCarrierSpacing_type nrSCS);
uint32_t VLIB_Arfcn2Freq(uint32_t arfcn);
uint32_t VLIB_Freq2Arfcn(uint32_t freqKhz);

int FnVCCB_FindXnEndPointIndexListByGnbIdPartial(
    callInfo_type *ptCi, uint16_t gnbNum, uint32_t gnbIdPartial, uint16_t xnIndexList[]);
uint16_t fnVLIB_FindXnEndPointIndexByGnbId(uint16_t gnbNum, vccbGlobalGnbId_type *pTgtGnbId);
uint16_t fnVLIB_FindXnEndPointIndexByEnbId(uint16_t gnbNum, enbId_type *pEnbId, plmnId_type *pPlmn);
xnNbrInfo_type *FnVCCB_GetXnNbrInfo(uint16_t gnbNum, uint16_t nbrIdx);
void fnVLIB_check_support_data_forwarding_per_5QI(callInfo_type *ptCi, qosFlowInfo_type *ptQi, uint8_t isTarget);
enumDataForwardingState_type FnVCCB_GetDataForwardingState(callInfo_type *ptCi);
void VLIB_checkQosFlowForwardedOnTunnels(callInfo_type *ptCi, callPDUSessInfo_type *pPDUSessInfo,
    qosFlowInfo_type *ptQi, uint8_t *dl, uint8_t *ul, enumDataForwardingState_type targetGnb);
int16_t VLIB_IsHoBlackListXn(uint16_t gnbNum, vccbGlobalGnbId_type *pTgtGnbId);

int16_t VLIB_IsPCellAvailableForUe(callInfo_type *ptCi, uint32_t ssbArfcn, hoRestrictInfo_type *ptHrl);
int16_t VLIB_IsPCellAndPlmnAvailableForUe(const callInfo_type *ptCi, uint8_t plmnIdx, uint32_t ssbArfcn);
int16_t VLIB_IsSCellAvailableForUe(callInfo_type *ptCi, uint32_t ssbArfcn);

int16_t VLIB_IsAllServingCellsFr2Only(callInfo_type *ptCi);
enumServFreqRange_type VLIB_GetDuCellsFreqRange(callInfo_type *ptCi);
int16_t VLIB_IsNeedTnlUpdate(callInfo_type *ptCi);
void FnVCCB_ClearDrbTnlNeedModifyFlag(callInfo_type &rCall);
int16_t VLIB_UpdateEnbCellInfo(callInfo_type *ptCi, uint8_t interMnHoFlag);

int16_t VLIB_SetRedirectionInfoObjectByArfcn(callInfo_type *ptCi, uint32_t arfcn);
int16_t VLIB_SetRedirectionInfoObjectByMO(callInfo_type *ptCi, measurementObjectUe_type *pMeasObj);
int16_t VCCM_CheckCellInService(
    callInfo_type *ptCi, uint16_t cellNum, uint16_t isEquippedCell, uint16_t printErrorLog);
int16_t VCCM_CheckInterGnbRRETarget(callInfo_type *ptCi);
const sliceLoadControlInfo_type* FnVCCB_GetSliceLoadControlInfo(uint16_t gnbNum, uint8_t sliceIdx);
int16_t VLIB_CheckifSupportedSNSSAIList(
    callInfo_type *ptCi, callSNSSAI_type &rTgtSnssai, uint32_t plmnLongId, uint16_t cellNum);
int16_t VLIB_CheckifSupportedSNSSAIListForInterGnb(callInfo_type *ptCi, callSNSSAI_type &rTgtSnssai,
    candidateNbrInformation_type *pNbrInfo, uint32_t candidatePlmnLongId);
int16_t VLIB_CheckNssaiWithCellInfo(
    callInfo_type *ptCi, callSNSSAI_type &rTgtSnssai, uint16_t reqCellNum, uint32_t reqPlmnLongId);
int16_t VLIB_CheckNssaiWithE1Info(callInfo_type *ptCi, callSNSSAI_type &rTgtSnssai, uint32_t reqPlmnLongId);
bool FnVCCB_CheckIfAllPduSessSuppSNSSAIList(callInfo_type *ptCi, const uint16_t cellNum);

int16_t VLIB_FindPlmnInSIB1Plmn(callInfo_type *ptCi, uint32_t reqPlmnLongId);
void VLIB_ChangeBitOfIntraFreqInMeasObjectSelection(uint32_t *pMeasObjectSelection, int32_t isIntraFreqPresent);
uint8_t VLIB_ConvertEnumEutraBandwidthMbwToNrb(uint8_t enumEutraBandwidth);
uint8_t VLIB_ConvertEnumNrSubCarrierSpacingToKHz(uint8_t enumNrSubCarrierSpacing);
uint16_t VLIB_ConvertEnumNrSystemBandwidthToNrb(uint16_t enumNrSystemBandwidth);
uint32_t VLIB_PositiveDiffOrZero(uint32_t first, uint32_t second);
bool VHCM_isForcedHoRestriction(callInfo_type const *ptCi);

uint8_t VLIB_FindGnbPlmnIndexOfCall(const callInfo_type *ptCi);
int16_t VLIB_CanPlmnBasedControlBeUsedWithCustomIds(
    const callInfo_type *ptCi, const PlmnBasedControl &plmnBasedControl, uint8_t callPlmnIndex, uint8_t callSvcGrpId);
int16_t VLIB_CanPlmnBasedControlBeUsed(const callInfo_type *ptCi, const PlmnBasedControl &plmnBasedControl);

// ODF_HO_21B START
void FnVCCB_MainInitOnDemandMobilityControl(void);
int16_t FnVCCB_MainUpdateOnDemandMobilityControl(struct timespec specTime);
bool FnVCCB_CheckNeedToCallRelease(uint8_t opMode, bool timerExpired);
bool FnVCCB_CheckNeedToMeasConfForOndemandHO(callInfo_type *ptCi, uint8_t opMode, bool timerExpired);
void FnVCCB_MainSelectUeForOnDemandMobility(void);
void FnVCCB_MainHandleOnDemandMobility(void);
enumRatForOnDemandMobility_type FnVCCB_GetPreferRatTypeForOnDemandMobility(callInfo_type *ptCi);
int16_t FnVCCB_TriggerRedirectionForOnDemandMobility(callInfo_type *ptCi);
void FnVCCB_HandleOnDemandMobility(message_type *ptAll, uint8_t threadId);
bool FnVCCB_MainCheckValidationForLdTimer(struct timespec currTime);
void FnVCCB_InitOnDemandMobilityControlOnCell(VccbCellInfo_type *pCell);
void FnVCCB_InitOnDemandHoLoadParam(void);
// ODF_HO_21B END

void FnVCCB_InitNrdcRfspBasedOprMode(NrdcCellInfo_type *pNrdcCellInfo);
void FnVCCB_InitDlTrfStatusRptCfg(VccbCellInfo_type *pCell);
void FnVCCB_InitTrafficMonitoringCfgRfsp(VccbCellInfo_type *pCell);

void FnVCCB_InitIdleModeInfoUeDistributionRatio(VccbCellInfo_type *pCell);

int16_t VCCM_CheckInterGnbHandoverTarget(callInfo_type *ptCi);
bool VCCM_Is_DrbStatusAddCondition(callInfo_type *ptCi, callDRBInfo_type *ptDi);
uint16_t fnVLIB_FindXnEndPointIndexByNbrIdx(
    callInfo_type *ptCi, uint16_t cellNum, uint16_t nbrIdx, nbrGnbCellInfo_type **ptGnbCellInfo);

bool FnVCCB_IsPartialHoAllowEnabled(callInfo_type &rCall);
bool FnVCCB_NeedToSetPartialOptionBeforeSendingE1F1_ForHandover(callInfo_type &rCall, uint8_t interfaceType);

unsigned int FnVCCB_GetRandomValue(const char *ptFunc, const uint16_t gnbNum, const int maxRangeCount);

int16_t FnVCCB_FindActionQueueIndex(callInfo_type *ptCi, uint64_t actionBitFlag);
int16_t FnVCCB_InterGnbRanPaging_HandleMessageQueue(callInfo_type *ptCi);
int16_t FnVCCB_NeedSgNBAddBlock_ByOverheating(callInfo_type *ptCi);
int FnVCCB_get_nrArfcn(callInfo_type *ptCi, uint32_t *nrArfcn);

uint16_t VLIB_GetCellNumBasedOnCgi(const callInfo_type *ptCi, cgi_type cgi, uint8_t gnbIdLength);
uint16_t VLIB_GetCellNumBasedOnNbrGnbCellInfo(const callInfo_type &rCi, const nbrGnbCellInfo_type &rCell);
uint16_t VLIB_GetNbrIdxBasedOnCgi(const VccbCellInfo_type *pCell, cgi_type cgi);
nbrGnbCellInfo_type *VLIB_GetNbrGnbCellInfoBasedOnCgi(const callInfo_type *ptCi, cgi_type cgi, uint8_t gnbIdLength);

void FnVCCB_UlSrbIntegrityFail_PrintLog(const callInfo_type *ptCi, const F1_RRCContainer *pRRCContainer,
    const callSRBInfo_type *ptSi, const F1_SRBID sRBID);
uint8_t FnVCCB_NrdcCellInfo_RfspBasedEntries_FindEntry(
    uint8_t usage, uint16_t rfsp, nrdcRfspBasedUlPathSwitchCtrl_type entries[]);

int16_t FnVCCB_CheckAndMarkForChangeOfUeReleasePreference(callInfo_type *ptCi, uint8_t onlyCheckFlag);
int16_t FnVCCB_CheckAndMarkForChangeOfUeNrRrcOtherConfig(callInfo_type *ptCi, uint8_t onlyCheckFlag);
void FnVCCB_GetNewUeReleasePreferenceInfo(callInfo_type *ptCi);
void FnVCCB_GetNewUeOverheatingAssistanceInfo(callInfo_type *ptCi);
void FnVCCB_GetNewUeMaxBW_PreferenceInfo(callInfo_type *ptCi);
void FnVCCB_GetNewUeMaxCC_PreferenceInfo(callInfo_type *ptCi);
void FnVCCB_GetNewUeMaxMIMOLayer_PreferenceInfo(callInfo_type *ptCi);
void FnVCCB_CommitUeNrRrcOtherConfig(callInfo_type *ptCi);
int16_t FnVCCB_CheckNeedActionForUePreferredRrcState(callInfo_type *ptCi);

void FnVCCB_Proc_RRCInactiveTransitionReport(callInfo_type *ptCi);
bool FnVCCB_CheckValid_octetString(const octetStringType *ptOct);

int FnVCCB_QsortAvailableResourceDescendingOrder(const void *arg1, const void *arg2);

void FnVCCB_CheckBearerAndUpdateSignalingUserInactivity(callInfo_type *ptCi);
void FnVCCB_CheckBearerAndUpdateDataUserInactivity(callInfo_type *ptCi);

bool FnVCCB_IsMultiUpHandlingCase(unsigned short msgId);
int16_t FnVCCB_MultiUpProcessing(
    callInfo_type *, msgUnpack_type *, const int16_t, const multiUpFunctionParameter_type *, const char *);

bool FnVCCB_IsNbrSDLCell(const callInfo_type *ptCi, const nbrGnbCellInfo_type* pObtained);
bool FnVCCB_IsPeerGnbOtherVendor(
    callInfo_type *ptCi, uint16_t gnbNum, uint8_t isEndPointKeyFlag, uint16_t xnEpIdx, vccbGlobalGnbId_type *pTgtGnbId);
bool FnVCCB_CheckIfOtherVendorGnbByEpIdx(callInfo_type *ptCi, uint16_t gnbNum, uint16_t xnEpIdx);
bool FnVCCB_CheckIfOtherVendorGnbByGlobalGnbId(callInfo_type *, uint16_t gnbNum, vccbGlobalGnbId_type *pTgtGnbId);

bool FnVCCB_IsAllowedUeForOnDemandHo(callInfo_type *ptCi);

void FnVCCB_getServingCellMeasInitialInfo(callInfo_type *ptCi, servingCellMeasInitialInfo_type *measResult);
int VRRM_GetEutraCellInfoPldGnbIdxFromGnbId(uint32_t gnbId, uint16_t endPointX2Idx, uint16_t *ptGnbIdx);

void VLIB_UpdateCellStatusHistory(uint16_t cellNum, uint16_t cause);

int16_t FnVCCB_IsHighPriorityCall(callInfo_type *ptCi);

cellSelection_type FnVCCB_GetCellSelectionForConfig(const callInfo_type *const ptCi);

void FnVCCB_PrintAllResponseFlag_Detail(callInfo_type *ptCi, const char *ptFunc);
void FnVCCB_UlSrbIntegrityFail_PrintLog_PdcpCtx(
    const callInfo_type *ptCi, const PdcpCallContext_type *pPdcpCtx, enumPdcpCtx_type pdcpCtxType);

int16_t FnVCCB_CheckUeCapa_RedCapSupport (callInfo_type *ptCi);
bool FnVCCB_IsSupportDrbPartial_PreCondition(callInfo_type *ptCi);
void FnVCCB_SetPartialOptionBeforeSendingE1F1(callInfo_type *ptCi, VccbE1F1PartialInterface_type interfaceType);
bool FnVCCB_IsModifyOrReleaseInAllDrb(callInfo_type *ptCi);
int16_t FnVCCB_RecalculateResourceByE1F1PartialAccept(callInfo_type *ptCi, VccbE1F1PartialInterface_type interfaceType);
void FnVCCB_FinalizeAfterDrbPartial(callInfo_type *ptCi);
void FnVCCB_FindModifyOrRelDrbInPduAndSetFlag(callInfo_type *ptCi, callPDUSessInfo_type *ptPi, VccbE1F1PartialInterface_type interfaceType);
void FnVCCB_InitE1f1InfoAndSetDrbPartialReqOption(callInfo_type *ptCi, VccbE1F1PartialInterface_type interfaceType);
int16_t VLIB_SgNBInitiatedSnReleaseDueToSwitchOff(callInfo_type *ptCi, const uint32_t msgId);
void FnVCCB_BackupPduInfoForRollback(callInfo_type *ptCi);
int16_t FnVCCB_DecideRollbackAndRearrangeDbForDrbPartial(callInfo_type *ptCi, VccbE1F1PartialInterface_type interfaceType);
int16_t FnVCCB_DecideRollbackAndRearrangeDbForDrbPartialForNrdcSn(callInfo_type *ptCi, VccbE1F1PartialInterface_type interfaceType);

bool FnVCCB_IsRfspBasedBlindInterRatRedirection(callInfo_type *ptCi, uint16_t cellNum, enumInterRatRedirectionForcedOption_type &redirectionMethod);
bool FnVCCB_IsNeedToReconfigE1ByF1Partial(callInfo_type *ptCi);
VccbExtBackup_type *FnVCCB_GetPtrOfBackupFromExtCallDB(callInfo_type *ptCi);
void FnVCCB_SortNrCaControlIndex(VccbGnbInfo_type &rGnb);

bool FnVCCB_IsTheCellConditionForOnDemandHo(uint16_t cellNum); // 24B_PMB

// SVR25A FGR-MC1009 FR200
int16_t FnVCCB_RearrangePduQosDrbStatusByPartialResponse(callInfo_type *ptCi, VccbE1F1PartialInterface_type interfaceType);
bool FnVCCB_IsVoNRFailedByPartialDRB(callInfo_type &rCall); 

// Decision Monitoring val
int16_t FnVCCB_Decide_QosMonitoringInfo_ForDrbQos(callInfo_type *ptCi, callDRBInfo_type *ptDi, enumQosMonitoringRequest_type* output);
enumQosMonitoringRequest_type FnVCCB_Determine_QosMonitoringRequest_For_DRB(
    const callInfo_type &rCall, const callDRBInfo_type &rDrb);
enumQosMonitoringRequest_type FnVCCB_Determine_QosMonitoringRequest_For_QosFlow(
    const callInfo_type &rCall, const qosFlowLevelQoSParam_type &rQos);
enumQosMonitoringRequest_type FnVCCB_Determine_QosMonitoringRequest_For_TermPointBasedDRB(
    const callInfo_type &rCall, const callDRBInfo_type &rDrb);
bool FnVCCB_IsDrbQosMonitoringActivated(const callInfo_type *ptCi, const callDRBInfo_type *ptDi);
int16_t FnVCCB_HasVoiceRequestInMsg(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack);

bool FnVCCB_IsSecurityProcedureDone(callInfo_type *ptCi);

enumSpecificSliceAwareOption_type FnVCCB_GetSpecificSliceAwareOption(uint16_t gnbNum);
bool FnVCCB_IsSpecificSlice(callInfo_type &rCall, uint32_t sstSd);
int16_t FnVCCB_SpecificSliceForcedMobilityBlindRedirection(callInfo_type *ptCi, uint16_t msgId);

void FnVCCB_SetRxNotSupportSliceForAllSetupPDU(callInfo_type *ptCi);
void FnVCCB_SetRxNotSupportSlicePerPDU(callInfo_type *ptCi, uint16_t pduIdx);
void FnVCCB_SetQosFlowAsNotSupportSliceByDrb(callInfo_type *ptCi, callDRBInfo_type *ptDi);
void FnVCCB_SetPduAsNotSupportSliceByDrb(callInfo_type *ptCi, callDRBInfo_type *ptDi);

struct StartSaHandoverDb;
void FnVCCB_UpdateForcedMobilityHoFlag(callInfo_type *ptCi, StartSaHandoverDb& hoInputDb); 

bool FnVCCB_CheckLtmUeCapability(const callInfo_type &rCall, const uint16_t bandNr);
uint8_t FnVCCB_GetMaxNumOfLtmCellPerSvgGrp(uint16_t gnbNum, uint8_t svcGrpId);

void FnVCCB_SetRxDuNotSupportVonr5qiForAllSetupDrb(callInfo_type *ptCi);

void FnVCCB_GetSliceValWithReqVal(callPDUSessInfo_type *ptPi, callSNSSAI_type *ptSnssai);
#endif
