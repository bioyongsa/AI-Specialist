#ifndef VCCB_FEAT_FeatMfbi_H_
#define VCCB_FEAT_FeatMfbi_H_

#include "VccbStruct.h"

void FnVCCB_SetServCellBand(callInfo_type *ptCi);
bool VLIB_CanEnforceBandSelectionOnDu(uint16_t cellNum);
void FnVCCB_EnqueueIntraCellHoForBandChangeIfNeeded(callInfo_type &rCi);

#endif /* VCCB_FEAT_FeatMfbi_H_ */
