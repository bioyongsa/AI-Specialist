#pragma once

#include "VccbStruct.h"
namespace UeSpeedState
{
void VCCB_SetCallSpeedStateBasedOnCellSpeedState(callInfo_type &rCi, CellNum_type cellNum);
enumUeSpeed_type VCCB_GetUeSpeedState(const callInfo_type &call, CellNum_type cellNum);
void VCCB_SetCallSpeedStateBasedOnTargetCellSpeedState(callInfo_type &rCi, CellNum_type targetCellNum);
void VCCB_SetCallSpeedStateBasedOnDuIndication(callInfo_type &rCi, enumUeSpeed_type speedState);
void VCCB_SaveF1SamsungUESpeedIndication(callInfo_type &rCi, const F1_SamsungUESpeedIndication &ueSpeedInd);
int16_t VCCB_ProcessUeSpeedIndication(callInfo_type &rCi, const enumUeSpeed_type ueSpeedInd);
}  // namespace UeSpeedState