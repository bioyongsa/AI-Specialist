#ifndef VCCB_FEAT_FeatSwVersion_H_
#define VCCB_FEAT_FeatSwVersion_H_

#include "VccbStruct.h"
#include "ComMacro.h"

VCCB_STATIC_INLINE void VLIB_InitSwVersion(swVersion_type &swVer)
{
    swVer.raw.text[0] = '\0';
    swVer.xyz = 0;
}

// If wider range is needed please correct those number below
#define SW_VERSION_XYZ(x, y, z)                    \
    (({                                               \
        MACRO_STATIC_ASSERT((x) >= 0, "Not supported!");   \
        MACRO_STATIC_ASSERT((x) <= 100, "Not supported!"); \
        MACRO_STATIC_ASSERT((y) >= 'A', "Not supported!"); \
        MACRO_STATIC_ASSERT((y) <= 'D', "Not supported!"); \
        MACRO_STATIC_ASSERT((z) >= 0, "Not supported!");   \
        MACRO_STATIC_ASSERT((z) <= 100, "Not supported!"); \
    }),                                               \
        (uint32_t)(((x) << 16) + (((y) - 'A') << 8) + (z)))
void VLIB_CreateSwVersionFromPld(const char *ptPldSwVersion, swVersion_type *ptSwVersion);
bool VLIB_IsCellDuRequiredVersion(uint16_t cellNum, uint32_t requiredDuSwVersion);
bool FnVCCB_IsPartialDrbRequiredVersion(
    callInfo_type* ptCi, VccbE1F1PartialInterface_type interfaceType, uint16_t endPointIndex);
bool FnVCCB_IsSupportMSG4TaskOnF1SwVer(callInfo_type *ptCi, uint16_t endPointF1Index);

#endif  // VCCB_FEAT_FeatSwVersion_H_
