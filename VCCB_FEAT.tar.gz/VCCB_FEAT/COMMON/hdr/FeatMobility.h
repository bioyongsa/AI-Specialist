#ifndef VCCB_FEAT_FeatMobility_H_
#define VCCB_FEAT_FeatMobility_H_

#include "VccbStruct.h"

enum class MobilityType : uint8_t
{
    HO,
    RRE,
    RRC_RESUME_INTRA_GNB,
    RRC_RESUME_INTER_GNB,
    UNKNOWN
};

int16_t FnVCCB_CheckFallbackCondition(callInfo_type *ptCi, const MobilityType mobilityType);
int16_t FnVCCB_CheckFallbackConditionInterGnb(callInfo_type &call, const MobilityType mobilityType);
int16_t FnVCCB_ConfigureUeContextForRREandRRCResume(callInfo_type *ptCi, const MobilityType mobilityType);
int16_t FnVCCB_CheckSpecificSliceAndDoRrcRedirection_ForRREAndRRCResume(callInfo_type *ptCi, uint16_t msgId);
void FnVCCB_CheckAndUpdate_VoNREmergencyIndicator_CSL(callInfo_type *ptCi);

#endif /* VCCB_FEAT_FeatMobility_H_ */
