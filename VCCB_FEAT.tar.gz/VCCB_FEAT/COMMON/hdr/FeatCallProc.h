#ifndef VCCB_FEAT_FeatCallProc_H_
#define VCCB_FEAT_FeatCallProc_H_

#include "FeatMobility.h"
#include "VccbStruct.h"

enumSupport_type VCCM_CheckVoiceOverNRCapa(const callInfo_type &callInfo, uint16_t cellNum, bool isErrorPrintRequired);

void VCCM_UpdateNrMsgStat(
    uint8_t threadId, uint8_t dstThreadId, uint16_t msgId, uint32_t gnbIdOrNum, uint16_t endPointIdx, enumDirection direction);
void VCCM_UpdateNRRRCMsgStat(callInfo_type *ptCi, uint16_t msgId, uint32_t gnbIdOrNum);
void VCCM_UpdateInternalMsgStat(uint8_t threadId, uint16_t msgId, uint8_t dstThreadId);
void VHCM_StopSgNBChange(callInfo_type *ptCi);
int16_t VCCM_SelectSpCell(callInfo_type *ptCi, uint16_t *ptCellNum, uint16_t *ptBandNr);

int16_t VCCM_CheckAgainstHRL(
    uint16_t cellNum, hoRestrictInfo_type *ptHrl, uint8_t relationType, uint16_t targetCellNum);
int16_t VCCM_CheckAgainstRefusedTargetFR1Cells(callInfo_type *ptCi, nbrGnbCellInfo_type *ptNbrGnbCell);
uint16_t VCCM_DetermineUePlmnBasedOnHRL(const callInfo_type *ptCi);
uint16_t VCCM_DetermineUePlmnBasedOnHRLForCell(const callInfo_type &rCall, uint16_t cellNum);
int16_t VCCM_CheckAgainstRefusedTargetGnb(callInfo_type *ptCi, nbrGnbCellInfo_type *ptNbrGnbCell);
void FnVCCB_ClearUeHistoryInformation(callInfo_type *ptCi);
void FnVCCB_InitVisitedCellInfo(callInfo_type *ptCi, visitedCellInfo_type *pVisited);
int16_t VHCM_UpdateUeHistoryInformation_Prepare(callInfo_type *ptCi);
int16_t FnVCCB_FillUeHistory_ServingCellInfo_ForSNodeAddition(callInfo_type *ptCi,visitedCellInfo_type *pVisited);
void FnVCCB_UpdateUserInactStateAndDoActionIfExpiry(callInfo_type *ptCi, enumUserInactivityEvent_type event);
void FnVCCB_CheckAndRestartSignalingTimerForNRPPa(callInfo_type *ptCi);
int16_t FnVCCB_DoInactivityActionInIdleState(callInfo_type *ptCi);
void VCCM_SetStableState_CallSetup(callInfo_type *ptCi);
void VLIB_MarkImsiTrace(ZIMSI_type *Z_IMSI, callInfo_type *ptCi);
uint64_t VLIB_IMSItol(IMSI_type *imsi);
uint16_t GetEutraBandIndicatorByEARFCN(uint32_t earfn);
enumVccbFlag VLIB_IsEutraBandSupported(callInfo_type *ptCi, uint16_t eutraBand);
uint16_t FnVCCB_GetNrDuplexTypeByBandIndicator(uint16_t bandIndi);
int16_t SelectNRARFCN_ForIntraRATRedirection(callInfo_type *ptCi);
int16_t SelectEARFCN_ForInterRATRedirection(callInfo_type *ptCi, enumInterRatRedirectionForcedOption_type forcedOption);
int16_t FnVCCB_SelectEARFCN_ForRfspBlindInterRATRedirection(callInfo_type *ptCi);
int16_t VCCM_SDAP_AllocationAndUpdate_QosFlow_S_FailToSetup(callInfo_type *ptCi, qosFlowInfo_type *ptQi, numRelQosInfoInDRB_type relDrbInfo[]);
int16_t VCCM_SDAP_AllocationAndUpdate_QosFlow_S_Release(callInfo_type *ptCi, qosFlowInfo_type *ptQi, numRelQosInfoInDRB_type relDrbInfo[]);
int16_t VCCM_SDAP_AllocationAndUpdate_QosFlow_S_Modify(callInfo_type *ptCi, qosFlowInfo_type *ptQi, uint8_t pduIdx, uint16_t qosFlowIdxInPdu);
int16_t VCCM_SDAP_AllocationAndUpdate_QosFlow_S_Setup_nonGBRQosFlow(callInfo_type *ptCi, qosFlowInfo_type *ptQi, uint8_t pduIdx, uint16_t qosFlowIdxInPdu);
int16_t VCCM_SDAP_AllocationAndUpdate_QosFlow_S_Setup(callInfo_type *ptCi, qosFlowInfo_type *ptQi, uint8_t pduIdx, uint16_t qosFlowIdxInPdu);
int16_t VCCM_SDAP_AllocationAndUpdate_QosFlowStatus(callInfo_type *ptCi, uint8_t pduIdx, uint16_t qosFlowIdxInPdu, numRelQosInfoInDRB_type relDrbInfo[]);
int16_t VCCM_SDAP_AllocationAndUpdate_DRBStatus(callInfo_type *ptCi);

int16_t VCCM_SetServCellNum(callInfo_type *ptCi, cgi_type *pNRCGI);
int16_t FnVCCB_CheckMpsBearerForAllPlmn(callInfo_type &rCall, const uint8_t priorityLevel, const uint8_t fiveQi);


void VCCM_WarningPrint_SA_UE_AMBR(callInfo_type *ptCi, enumNrInterface_type interface, uint64_t dl, uint64_t ul);
void VCCM_DetermineSA_UE_AMBR(callInfo_type *ptCi);
void VCCM_RecalculateUeAmbrValueForMultiUp(callInfo_type *ptCi, uint16_t endPointIdx, uint64_t *pAmbr);
int16_t VCCM_GetUeAmbrValue(callInfo_type *ptCi, uint64_t *pUl, uint64_t *pDl);
uint16_t VHCM_FindSameRegionAmfByServedGuami(xnNbrInfo_type *pNbr, ho_guami_type *pServedGuami);
uint16_t VHCM_FindSameRegionAmfByServedGuamiForInterPlmn(callInfo_type *ptCi, xnNbrInfo_type *pNbr);
int16_t VLIB_getAmfFromGuami(callInfo_type *ptCi);

int16_t VCCM_StatStrongestPciMrPScellChange(callInfo_type *ptCi, enumRSType rsType, int8_t smallCellListIndex);
void VLIB_setMemoryUsageInfo(interface_memoryUsage interface, uint16_t messageType, uint32_t size, uint32_t threadId);
void VLIB_setMemoryUsageCallInfo(callInfo_type *ptCi);

visitedCellInfo_type *VHCM_getUeHistory_ServingCellInfo(callInfo_type *ptCi);
visitedCellInfo_type *VHCM_getUeHistory_VisitedCellInfo(callInfo_type *ptCi, uint8_t index, uint8_t ratType);
int16_t VHCM_updateUEHistory(callInfo_type *ptCi, visitedCellInfo_type *pVisited);
int VHCM_DiffTimeVal(struct timeval a, struct timeval b);

int VCCM_CheckN26Support(callInfo_type *ptCi);
int VCCM_IsIratHandoverCondition(callInfo_type *ptCi);
int VCCM_CheckUeCapaForHandoverToLTE(callInfo_type *ptCi, uint16_t cellNum);

int16_t VCCM_IsTAIInAoI(
    callInfo_type *ptCi, plmnId_type plmn, uint32_t tac, NGAP_UEPresence uEPres, uint8_t *uEAoIChange);
int16_t VCCM_IsNRCGIInAoI(callInfo_type *ptCi, cgi_type cellCGI, NGAP_UEPresence uEPres, uint8_t *uEAoIChange);
int16_t VCCM_IsNGRANNODEInAoI(
    callInfo_type *ptCi, vccbGlobalGnbId_type cellRANNodeID, NGAP_UEPresence uEPres, uint8_t *uEAoIChange);
int16_t VCCM_ProcessVisitedCellForAoI(callInfo_type *ptCi, uint8_t *uEAoIChange);
int16_t VCCM_ProcLocationReportForAoI(callInfo_type *ptCi, uint8_t *uEAoIChange);
int16_t VCCM_HandleIntragNBHO_LocationReportAoI_OnRRCReconfComplete(callInfo_type *ptCi, uint8_t *uEAoIChange);
uint64_t VCCB_GetAmfUeNgapId(msgUnpack_type *ptUnpack);
int16_t VCCM_CheckAcceptDownlinkNASTransport(
    callInfo_type *ptCi, NG_DownlinkNASTransportAmfAll_type *ptDlNas, uint16_t *ptCause);
int16_t VCCM_CheckAcceptRRE(callInfo_type *ptCi, enumReestablishType_type rreType);
int16_t VCCM_RestoreDbForRreFailure(callInfo_type *ptCi);
int16_t VCCM_BackupDbForRreFailure(callInfo_type *ptCi);
int16_t VCCM_CheckUeMeasForSonSchedule(callInfo_type *ptCi, uint32_t cellNum);
int16_t VCCM_ComparePcisAndFreqsOfNbrCell(
    const measResultNR_type *ptMeasResultNR, uint32_t usedFreq, enumRSType rsType, nbrGnbCellInfo_type *ptNbrGnbCell);

int VCCM_IsUeIdleState(enumCallType_type callType, enumVccbCallState_type callState);

uint8_t VCCM_getUeLongDrxCycleCapa(callInfo_type *ptCi, uint16_t cellNum);
int VCCM_IsDrbSetupOnly(callInfo_type *ptCi);
void VLIB_DrbStatusToReleasePerPDU(callInfo_type *ptCi, callPDUSessInfo_type *ptPi);

ConfStatus VCCM_CheckSupport5QI(callInfo_type *ptCi, uint16_t gnbNum, uint8_t fiveQi, bool isErrorPrintRequired);
int16_t VCCM_CheckVoiceOverNR(callInfo_type *ptCi, uint16_t cellNum);

int16_t VCCM_CheckFR1FR2HO(callInfo_type *ptCi);
uint16_t VCCM_GetNrCellDuplexType(callInfo_type *ptCi, uint16_t cellNum);
int16_t VCCM_CheckUeCapaForNrInterFrequencySaHandover(
    callInfo_type *ptCi, uint16_t cellNum, uint32_t tgtSsbFrequency, uint16_t tgtFreqBandIndicatorNR);
int16_t VCCM_FindSaEnabledNbr(callInfo_type *ptCi, enumRSType rsType, uint32_t ssbFreq);
int VCCM_checkSaIFAvailableNbr(callInfo_type *ptCi, uint16_t cellNum, measurementObjectNRBaseDb_type *ptMO);
int FnVCCB_checkNrdcSnIFAvailableNbr(callInfo_type *ptCi, uint16_t cellNum, measurementObjectNRBaseDb_type *ptMO);
int VCCM_checkSaIRATAvailableNbr(callInfo_type *ptCi, uint16_t cellNum, measurementObjectEUTRABaseDb_type *ptMO);
int16_t VCCM_CheckSliceAwareForTarget(callInfo_type *ptCi);
int16_t FnVCCB_CheckSliceAwareForRREAndRRCResume(callInfo_type *ptCi, uint8_t statusChange);
int16_t FnVCCB_CheckValidSegmentedUeForInterGnbRREandResume(callInfo_type *ptCi);
int16_t VCCM_CheckSliceAwareForSn(callInfo_type *ptCi, allowedPlmnList_Type *ptAllowedPlmnList, uint32_t targetCellNum);
void FnVCCB_CheckSliceAwareRREAndRRCResume_AfterFinalize(callInfo_type *ptCi, uint8_t *ptSendPduNotiFlag, uint8_t *ptForcedMobilityFlag);
int16_t VCCM_CompareNbrSmtc1Condition(const smtc1_type *ptSmtc, nbrGnbCellInfo_type *pNbrGnbCell);
void VCCM_InitBlacklistCell(callInfo_type *ptCi, int idx);                                       // NEDC_SCG_FAILURE_20C
uint16_t VCCM_CleanupBlacklistTblForNewPscell(callInfo_type *ptCi);                              // NEDC_SCG_FAILURE_20C
uint16_t VCCM_CleanupBlacklistedCells(callInfo_type *ptCi);                                      // NEDC_SCG_FAILURE_20C
void VCCM_FillInPscellInfo(callInfo_type *ptCi, int idx);                                        // NEDC_SCG_FAILURE_20C
int16_t VCCM_RegisterNewEutraPscellInfo2BL(callInfo_type *ptCi);                                 // NEDC_SCG_FAILURE_20C
void VCCM_MakeEutraPscellBlacklisted(callInfo_type *ptCi);                                       // NEDC_SCG_FAILURE_20C
int16_t VCCM_IsThisEutraCellBlacklisted(callInfo_type *ptCi, nbrEnbCellInfo_type *pNbrEnbCell);  // NEDC_SCG_FAILURE_20C
void VCCM_UpdateEutraPSCellId(callInfo_type *ptCi);                                              // NEDC_SCG_FAILURE_20C
void VCCM_MissingLocaInfoSN(callInfo_type *ptCi);                                                // NEDC_SCG_FAILURE_20C
void VCCM_ScgFailureActionOnSnReleaseRequired(callInfo_type *ptCi);                              // NEDC_SCG_FAILURE_20C
const char *VCCM_strNedcScgFailure(uint16_t failType);                                                 // NEDC_SCG_FAILURE_20C
int16_t VCCM_checkForSplitBearerSnNodeRelease(callInfo_type *ptCi);
uint8_t VLIB_setDrbsToIdleInPdu(callInfo_type *ptCi, callPDUSessInfo_type *ptPi, uint8_t callPduIdx);
void VLIB_setQosFlowsToIdleInPdu(
    callInfo_type *ptCi, callPDUSessInfo_type *ptPi, uint8_t callPduIdx, uint8_t collectSuccStatFlag);
int16_t VCCB_checkAllowedBCListMRDC(callInfo_type *ptCi, uint16_t bandNR);
int16_t VCCB_isBandSupportedAsPcellBand(const callInfo_type *ptCi, uint16_t bandNR);
int16_t VCCB_isBandNrCaCapable(const callInfo_type *ptCi, uint16_t bandNR);
int16_t VCCM_CheckSaNrHoAgainstHrl(callInfo_type *ptCi, hoRestrictInfo_type *ptHrl, candidateNbrInformation_type *pNbrInfo);
int16_t VCCM_CheckSaHandoverCondition_NR(callInfo_type *ptCi, uint16_t nbrIdx,
        measurementObjectNRUe_type *pMeasObj, nbrGnbCellInfo_type *ptNbrGnbCell);
int16_t FnVCCB_SaveShm_For_SctpDataTransfer(const message_type *ptAll, const uint8_t threadId);
int16_t VCCB_ProcMsgSctpDataInd(message_type *, msgUnpack_type *, uint8_t);

void VLIB_StatResumePerFailCauseSCGFailure(callInfo_type *ptCi);

int16_t VCCB_GetMsgUnpack_checkMsgId(message_type *ptAll, msgUnpack_type *ptUnpack, uint8_t threadId);

void VCCB_DetachHoTimer(handoverInfo_type *ptHo);
void VCCB_DetachAllTimer_sendReleaseAll(callInfo_type *ptCi);
int16_t VIIL_storeSctpDataInd(message_type *ptAll, uint8_t threadId);

void VCCM_checkForBestIntraCellScg(tgtCellSelectionContextInfo_type *ptTgtCellCxt,
    const cellSelection_type tempIntraTgtCellSelection, uint16_t nbrCellIdx);
void VCCM_InitializeDefaultCellSelectionCtx(tgtCellSelectionContextInfo_type *ptTgtCellNbrForHo);
int16_t VCCM_SelectPCellAsTgtScgMob(callInfo_type *ptCi, uint16_t *ptRelationType, cellSelection_type *ptCellSelection,
    enumRSType rsType, measResultList2NR_type *ptMeasResultList2NR);
void VCCM_checkForBestInterCellScg(callInfo_type *ptCi, tgtCellSelectionContextInfo_type *ptTgtCellCxt,
    uint16_t nbrGnbCellNrPci, uint16_t nbrCellIdx, uint16_t nbrIdx);
int16_t VCCM_CheckEmergencyBearer(callInfo_type *ptCi);
int16_t VCCM_CheckEmergencyCall(callInfo_type *ptCi);
int16_t FnVCCB_CheckEmergencyVoNR(callInfo_type *ptCi, uint8_t priorityLevel);
int16_t FnVCCB_CheckIsVoNRInService(callInfo_type *ptCi);
uint16_t FnVCCB_GetVoNRQoSFlowIndex(callInfo_type *ptCi);
uint16_t FnVCCB_GetVoNRQosFlowIndexOfDRB(callInfo_type *ptCi, callDRBInfo_type *ptDi);
int16_t FnVCCB_CheckAllowedConcurrentNRDCandVoNR(callInfo_type *ptCi, uint16_t cellNum);

int16_t VCCM_CheckPciCellForHo(callInfo_type *ptCi, uint16_t pci, uint32_t usedFreq, enumRSType rsType,
    cellSelection_type *ptCellSelection);
int16_t FnVCCB_CompareRankOfHoNbrCell(callInfo_type *ptCi, candidateNbrList_type *candidateCellList);
int16_t VCCM_ConditionallyUpdateIdxsOfBestCells_NR(callInfo_type *ptCi,
        uint32_t usedFreq, uint16_t nbrIdx, hoRestrictInfo_type *ptHrl, candidateNbrList_type *candidateCellList,
        measurementObjectNRUe_type *pMeasObj, enumHandoverTriggerType hoTrigger, nbrGnbCellInfo_type *ptNbrGnbCell);

int16_t VCCM_ConditionallyUpdateIdxsOfBestCells_EUTRA(callInfo_type *ptCi, uint16_t nbrIdx,
        hoRestrictInfo_type *ptHrl, candidateNbrList_type *candidateCellList, nbrEnbCellInfo_type *ptNbrEnbCell);
int16_t VCCB_findTargetCellNumDuringIntraGnbSaHO(callInfo_type *ptCi);

int16_t VCCM_SetCallInfoForFullConfig(callInfo_type *ptCi);
int16_t VCCM_DecideFullConfigNSA(callInfo_type *ptCi);
int16_t VCCM_DecideCuInitFullConfigSA(callInfo_type *ptCi, const cellSelection_type *ptTgtCellSelection, const char *ptFuncName);
bool VCCM_ForceFullConfigOverXn(callInfo_type *ptCi, const char *ptFuncName, bool isSender);
void VCOM_ChangeStatus_DRBStatus_To_FailToSetup_ForHandover(callInfo_type *ptCi);

int16_t VCCM_NeedToSendX2SgNBActivityNotification(callInfo_type *ptCi);
int16_t VCCM_IsPossibleFreqBaseControl_InUserInact(callInfo_type *ptCi);
int16_t VCCM_GetFreqBasedControl_InUserInact(callInfo_type *ptCi, uint8_t *getX2Reporting);

void FnVCCB_CheckErabAndUpdateDataUserInactivity(callInfo_type *ptCi);  // 22C2

int16_t VCCM_Check_UP_DRB_Integrity_Supported(callInfo_type *ptCi);
void VCOM_ChangeStatus_PduSessionAndQosFlow_FailToSetup_ForUPIntegrityProtection(callInfo_type *ptCi, uint8_t pduIdx);

bool FnVCCB_isNRDC_allowedCell(const callInfo_type *ptCi, const nbrGnbCellInfo_type *pNbr);
int16_t FnVCCB_NRDC_checkTAI(callInfo_type *ptCi, uint16_t cellNum, hoRestrictInfo_type *ptHrl,
    candidateNbrInformation_type *pCand, enumProcedureTypeforSlice_type procType, nbrGnbCellInfo_type *pNbr);
int16_t FnVCCB_NRDC_checkTAI_SN(
    callInfo_type *ptCi, hoRestrictInfo_type *ptMrl, uint32_t targetCellNum, uint8_t *pSelectedCellPlmnIndex);
int16_t VCCM_FillCandidateCellInfo_NR(callInfo_type *ptCi, uint16_t cellNum, uint16_t nbrIdx,
    candidateNbrInformation_type *candidateCell, bool checkSaAvailablePlmn = false);
int16_t FnVCCB_ConditionallyUpdateIdxsOfBestCells_NrdcSN(callInfo_type *ptCi,
    enumRSType rsType,
    const measResultNR_type *ptMeasResultNR, uint32_t usedFreq, uint16_t nbrIdx, hoRestrictInfo_type *ptHrl,
    uint16_t freqIdx, int pciIdx, SN_PscellSelectionCandidateNbrList_type *pCand, measurementObjectNRUe_type *pMeasObj,
    uint8_t reportCgiSupport);
int16_t VCCM_CheckSliceAwareForServing(callInfo_type *ptCi, uint16_t cellNum, candidateNbrInformation_type *pNbrInfo,
    allowedPlmnList_Type *ptAllowedPlmnList, bool isPartialAllowed, enumProcedureTypeforSlice_type procType);
// NR_CONN_MC_21D
int VCCM_CheckCellServiceState_EUTRA(const callInfo_type *ptCi, const nbrEnbCellInfo_type *pNbrEnbCell);

int16_t VCCM_CheckNRSDLCell(VccbCellInfo_type *ptCell);

int16_t FnVCCB_Check_OnlyRrcInactiveTransitionReportRequestIncluded(
    callInfo_type *ptCi, NG_UEContextModificationRequestAmfAll_type *ptMsg);

measResult2NR_type *FnVCCB_GetMeasResult2NRforNeighbor(callInfo_type *ptCi, measResultList2NR_type *pMeasResultList2NR);
int16_t FnVCCB_ReCompositeMeasResult2NRwithOnlyNeighCellListNR(callInfo_type *ptCi);
int16_t FnVCCB_RestoreMeasResultList2NRforSelectedFr2Band(
    callInfo_type *ptCi, measResultList2NR_type *ptMeasResultList2NR);
int16_t FnVCCB_GetFr2BandMinimalResource(callInfo_type *ptCi, measResultList2NR_type *pMeasResultList2NR,
    uint16_t fr2Band, bool &rIsUL, uint32_t &rResource);
int16_t FnVCCB_GetFr2BandAvailableResource(callInfo_type *ptCi, measResultList2NR_type *pMeasResultList2NR,
    uint16_t fr2Band, availResourcePerMeasResultCellReport_type *pAvailRscTuple);
int16_t FnVCCB_GetScgBandSelFR2BandofNbrGnbCellInfo(callInfo_type *ptCi, nbrGnbCellInfo_type *pNbrGnbCell);
void FnVCCB_ClearScgBandSelectionInfo(callInfo_type *ptCi);
uint16_t FnVCCB_GetFR2BandofColocCell(callInfo_type *ptCi, colocCellEntries_type *pColocCell, uint16_t cellNum);

int16_t FnVCCB_NextStep_NRDC_RRE_Ready_RRE_E1ModTxStop(callInfo_type *ptCi);
int16_t FnVCCB_NextStep_RRE_RreCmpl_SNRel_E1SetupMod(callInfo_type *ptCi);

int16_t FnVCCB_UpdatePSCellSCGResume_NrdcSN(callInfo_type *ptCi, enumRSType rsType,
    const measResultNR_type *ptMeasResultNR, uint32_t usedFreq, uint16_t nbrIdx, uint16_t freqIdx, int pciIdx,
    SN_PscellSelectionCandidateNbrList_type *pCand);
uint16_t FnVCCB_FindEutraNbrIdxByCgi(uint16_t cellNum, const cgi_type eutraCgi);
void VCCM_SetSpCellIndex(callInfo_type *ptCi);
void VLIB_SendVipUeNotification(callInfo_type *ptCi, uint16_t cellNum);
void VLIB_CheckEndcVipUe(callInfo_type *ptCi);
emergencyArpInfo_type *FnVCCB_FindEmergencyArpInfo(
    const char *pFunc, callInfo_type *ptCi, plmnId_type *ptTargetPlmn, bool isPrint);
int16_t FnVCCB_CheckEmergencyBearerItem(const char *pFunc, callInfo_type *ptCi, emergencyArpInfo_type *pEmerArp,
    uint8_t priorityLevel, uint8_t fiveQi, bool isPrint);
emergencyArpInfo_type *FnVCCB_FindEmergencyArpInfoByPlmnIdx(
    const char *pFunc, callInfo_type *ptCi, uint8_t plmnIndex, bool isPrint);
void VCCM_SetCurrentSaCallDbFromPrevInfoDb(callInfo_type *ptCi, uint32_t  filter);
void VCCM_SetPrevSaCallDb(callInfo_type *ptCi, uint32_t  filter);
void VCCM_SetPrevNsaCallDb(callInfo_type *ptCi, uint32_t  filter);
void VCCM_SetCurrentNsaCallDbFromPrevInfoDb(callInfo_type *ptCi, uint32_t  filter);

bool VCCM_CheckAnrMnsSchedule(callInfo_type *ptCi);
int16_t VCCB_AnrSgNBModificationRefuseTimerAction(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack);
void VLIB_SaveCauseOfRejectCandidateCell(callInfo_type *ptCi, uint16_t cellId, uint32_t arfcn, enumStatSpCellSelectionFailCause_type cause);

int16_t VCCM_UpdateCellForSort(callInfo_type *ptCi, candidateCellForSort_type *pCellForSort,
    measResultNR_type *pMeasResultNR, hoRestrictInfo_type *pHoRestrictInfo, uint32_t ssbFrequency,
    uint8_t *pUnavailableCellIdentityFlag, enumNRCGICellPrior_type eNRCGICellPrior);
void FnVCCB_HandleSigDataInactivityExpiredBothForSA(callInfo_type *ptCi);
int16_t VCCM_CheckIntraGnbCellServiceState(callInfo_type *ptCi, uint16_t cellNum, uint16_t nbrIdx);

int16_t VCCM_CheckPlmnAndTacInMrlAllowedList(const callInfo_type *ptCi, hoRestrictInfo_type *ptHrl, uint32_t tac, uint32_t longId);
int16_t VCCM_CheckAndUpdate_NbrPlmnValidation_NR(
    callInfo_type *ptCi, hoRestrictInfo_type *ptHrl, candidateNbrInformation_type *pNbrInfo, enumHandoverTriggerType hoTrigger = e_HoTrigger_InitValue);

int16_t VCCM_CheckAndUpdate_NbrPlmnValidation_EUTRA( 
    callInfo_type *ptCi, hoRestrictInfo_type *ptHrl, candidateNbrInformation_type *pNbrInfo);
bool FnVCCB_IsReportCGIConfigured(callInfo_type *ptCi);
bool FnVCCB_IsIntraGnbCellHasInvalidSib1SizeForTddType(uint16_t targetCellNum, uint16_t duplexType);

void VCOM_ChangeStatus_PduSessionAndQosFlow_FailToSetup_ForPartialDRB(callInfo_type *ptCi);
bool FnVCCB_IsInterGnbNbrDeactivated(const nbrGnbCellInfo_type &nbrGnbCell);
int16_t VCCM_CheckMpsCall(callInfo_type *ptCi);
int16_t FnVCCB_CheckMpsBearerItem(const char *pFunc, callInfo_type *ptCi, mpsCallInfo_type *pMpsCall,
    uint8_t priorityLevel, uint8_t fiveQi, bool isPrint);
int16_t FnVCCB_CheckIfBearerChangeToMcgMeasUpdateNeeded(callInfo_type &rCi);
int16_t FnVCCB_InitiateSplitToMcgChange(callInfo_type &rCi);
int16_t FnVCCB_GetNbrSaAvailablePlmnList_IntraGnbCell(callInfo_type &rCall, allowedPlmnList_Type &rAllowedPlmnList);
int16_t FnVCCB_GetNbrSaAvailablePlmnList_InterGnbCell(callInfo_type &rCall, uint16_t cellNum, uint16_t nbrIdx, allowedPlmnList_Type &rAllowedPlmnList);
int16_t FnVCCB_GetNbrSaAvailablePlmnList(
    callInfo_type &rCall, uint16_t cellNum, uint16_t nbrIdx, allowedPlmnList_Type &rAllowedPlmnList);
void FnVCCB_DetermineSA_UE_SliceMBR(callInfo_type &rCi);
void FnVCCB_StoreExistedGFBRValuesForSlice(callInfo_type &rCi);
void FnVCCB_UpdateSliceGFBRDuringPDUSessModQoSRel(callInfo_type &rCi, callPDUSessInfo_type &rPi, qosFlowInfo_type &rQi);
int16_t FnVCCB_ValidateGFBRComparedToUeSliceMBR(callInfo_type &rCi, bool isNrdcSNAddPrep = false, bool isHoRre = false);
void FnVCCB_CheckQoSSupportForEcnMarking(callInfo_type &rCi);
uint16_t fnVCCB_GetHoPrepFailedTimer(callInfo_type &rCall, CellNum_type cellNum);
bool FnVCCB_GetPingPongAvoidanceCause(callInfo_type &rCall, uint16_t &rXnCause, uint16_t &rNgCause, uint8_t reportType, uint8_t reportPurpose);
bool FnVCCB_GetConfigPingPongAvoidanceCause(callInfo_type &rCall, uint16_t &rXnCause, uint16_t &rNgCause);
void FnVCCB_InitPpaRestrictInfo(ppaRestrictInfo_type &rPpa);
uint32_t FnVCCB_GetPingPongRestrictionWindowSeconds(callInfo_type &rCall);
bool VCCB_isUlInterferedCellAllowedBasedOnThresholds(const callInfo_type &rCall, const cellResults_type &cellResults);
bool FnVCCB_ExistIdleVoNRQoSFlow(callInfo_type &rCall);
enumSupport_type FnVCCB_CheckVoiceOverNRCapaByFrequencyRange(
    const callInfo_type &callInfo, enumFrequencyRange_type currFrequencyServCell, bool isErrorPrintRequired);
void FnVCCB_PrintCandidatesInfo(callInfo_type *ptCi, measResultList2NR_type *ptCandidateCellInfoList);
void FnVCCB_PrintSelectedCandidateInfo(callInfo_type *ptCi, bool nrcgiCell);

#endif
