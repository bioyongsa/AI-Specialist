#include "FeatMfbi.h"
#include "FeatCallInfo.h"
#include "FeatSwVersion.h"
#include "StateCommon.h"

#include "ComAutoNtrace.hpp"
#include "ComGlobalData.h"
#include "ComLibIpcApi.h"

/****************************************************************************
 * @brief           Set servCellBand with default MFBI function
 * @param[in/out]   ptCi : Pointer to call info. / callInfo_type*
 ****************************************************************************/
void FnVCCB_SetServCellBand(callInfo_type* ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    ptCi->servCellBand = VLIB_GetFreqBandIndForCellNum(ptCi, ptCi->servCellNum);
}

/****************************************************************************
 * @brief       Check if VCCB can enforce band selection on DU which contains
                the cell corresponding to cellNum

 * @param[in]   cellNum: index to CELLINFO's cell which belongs to DU for
                         which query is run
 * @return      bool:   returns true if DU has swVersion which enables
                        enforcing band selection
                        returns false otherwise
 ****************************************************************************/
bool VLIB_CanEnforceBandSelectionOnDu(uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    const uint32_t requiredDuSwVersion = SW_VERSION_XYZ(23, 'A', 0);
    return VLIB_IsCellDuRequiredVersion(cellNum, requiredDuSwVersion);
}

/****************************************************************************
 * @brief   Enqueue intra cell HO to prioritize N77 after PDU setup is completed
 *
 * @param[in/out]   rCi: call information / callInfo_type
 ****************************************************************************/
void FnVCCB_EnqueueIntraCellHoForBandChangeIfNeeded(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    if ((TRUE == rCi.bitFlag.changeBandAfterPduSetup) &&
        (TRUE != rCi.bitFlag.changeBandDuringIntraCellHo))
    {
        rCi.bitFlag.changeBandAfterPduSetup = FALSE;
        int16_t status = VCCM_enqueueActionWithForce(&rCi, ENQUEUE_ACTION_INTRA_CELL_HO, true);
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_ERROR(&rCi, "[MFBI] VCCM_enqueueAction(ENQUEUE_ACTION_INTRA_CELL_HO) ERROR\n");
        }
        else if (GOOD == status)
        {
            rCi.bitFlag.changeBandDuringIntraCellHo = TRUE;
        }
    }
}
