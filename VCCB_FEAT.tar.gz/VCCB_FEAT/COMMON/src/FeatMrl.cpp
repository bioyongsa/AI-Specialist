#include "FeatMrl.h"
#include "FeatCommon.h"

#include "ComInclude.h"
#include "ComLibUtility.h"

#define MRL_FILTER_EMPTY_PLMN 0xFFFFFFFF

/*
    Common - VLIB_CompressHoRestrictInfo
             VLIB_DecompressHoRestrictInfo

    SA  UE - VLIB_Compress5gForbiddenTA
             VLIB_Decompress5gForbiddenTA

    NSA UE - VLIB_CompressForbiddenTA
             VLIB_DecompressForbiddenTA

    PROC   - VLIB_UpdateAllowedPlmn
*/

/*
 * @brief           Compress forbiddenTA
 *
 * @param[out]      pTgt :          output structure
 * @param[in]       pSrc :          input structure
 * @return          status :        GOOD, ERROR / int16_t
 */
VCCB_STATIC_INLINE
int16_t VLIB_CompressForbiddenTA(forbiddenTACompressed_type *pTgt, const forbiddenTA_type *pSrc)
{
    AUTO_TRACE_FUNC;

    uint16_t tacIdx = 0;
    uint16_t diffIdx = 0;
    uint16_t diff = 0;
    uint8_t bitmap[0x10000];
    uint32_t bitIdx = 0;
    uint16_t prevTac = 0;

    VALID_E_POINT_CHECK_ERROR(pTgt);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    if ((0 == pSrc->numTac) || (X2_maxnoofForbTACs < pSrc->numTac))
    {
        VCCB_PRINT_ERROR("pSrc->numTac is out of range (%d:%d:%d>\n", 0, pSrc->numTac, X2_maxnoofForbTACs);
        return ERROR;
    }

    pTgt->plmn = pSrc->plmn;
    pTgt->numTac = 0;

    // sort by count and eliminate duplicates
    memset(bitmap, 0, sizeof(bitmap));
    for (tacIdx = 0; tacIdx < pSrc->numTac; tacIdx++)
    {
        bitmap[pSrc->tac[tacIdx]] = 1;
    }

    for (bitIdx = 0; bitIdx < 0x10000; bitIdx++)
    {
        if (bitmap[bitIdx])
        {
            pTgt->numTac++;
            prevTac = static_cast<uint16_t>(bitIdx);
            pTgt->firstValue = prevTac;
            break;
        }
    }

    for (bitIdx++; bitIdx < 0x10000; bitIdx++)
    {
        if (0 == bitmap[bitIdx])
        {
            continue;
        }

        diff = static_cast<uint16_t>(bitIdx - prevTac);
        prevTac = static_cast<uint16_t>(bitIdx);
        pTgt->numTac++;

        while ((diff > 255) && (diffIdx < MAX_NUM_FORB_TA_COMPR_VAL))
        {
            pTgt->diff[diffIdx] = 0;  // 0 means 255 + next
            diff = static_cast<uint16_t>(diff - 255);
            diffIdx++;
        }

        if (diffIdx >= MAX_NUM_FORB_TA_COMPR_VAL)
        {
            VCCB_PRINT_ERROR("diffIdx reach max(%d)\n", MAX_NUM_FORB_TA_COMPR_VAL);
            return ERROR;
        }

        pTgt->diff[diffIdx] = static_cast<uint8_t>(diff);
        diffIdx++;
    }

    return GOOD;
}

/*
 * @brief           Compress forbiddenTA for SA call (contained fiveGTac)
 *
 * @param[out]      pTgt :          output structure
 * @param[in]       pSrc :          input structure
 * @return          status :        GOOD, ERROR / int16_t
 */
VCCB_STATIC_INLINE
int16_t VLIB_Compress5gForbiddenTA(forbidden5gTACompressed_type *pTgt, const forbiddenTA_type *pSrc)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pTgt);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    uint16_t tacIdx = 0;
    uint16_t diffIdx = 0;
    uint32_t diff = 0;
    uint32_t prevTac = 0;

    if ((0 == pSrc->numTac) || (NG_MaxnoofForbTACs < pSrc->numTac))
    {
        VCCB_PRINT_ERROR("pSrc->numTac is out of range (%d:%d:%d>\n", 0, pSrc->numTac, NG_MaxnoofForbTACs);
        return ERROR;
    }

    uint32_t tmp5gTacsFromSrc[pSrc->numTac];
    memset(pTgt->diff, 0, sizeof(pTgt->diff));
    memcpy(tmp5gTacsFromSrc, pSrc->fiveGTac, pSrc->numTac * sizeof(uint32_t));

    qsort(tmp5gTacsFromSrc, pSrc->numTac, sizeof(uint32_t), VLIB_QsortUint32AscendingOrder);

    pTgt->plmn = pSrc->plmn;
    pTgt->numTac = pSrc->numTac;
    pTgt->firstValue = tmp5gTacsFromSrc[0];
    prevTac = pTgt->firstValue;

    for (tacIdx = 1; tacIdx < pSrc->numTac; tacIdx++)
    {
        if (tmp5gTacsFromSrc[tacIdx] == tmp5gTacsFromSrc[tacIdx - 1])
        {
            pTgt->numTac--;
            continue;
        }

        diff = tmp5gTacsFromSrc[tacIdx] - prevTac;
        prevTac = tmp5gTacsFromSrc[tacIdx];

        while ((diff > 65535) && (diffIdx < MAX_NUM_FORB_TA_COMPR_VAL_SA))
        {
            pTgt->diff[diffIdx] = 0;  // 0 means 65535 + next
            diff -= 65535;
            diffIdx++;
        }

        if (diffIdx >= MAX_NUM_FORB_TA_COMPR_VAL_SA)
        {
            VCCB_PRINT_ERROR("diffIdx reach max(%d)\n", MAX_NUM_FORB_TA_COMPR_VAL_SA);
            return ERROR;
        }
        pTgt->diff[diffIdx] = static_cast<uint16_t>(diff);
        diffIdx++;
    }

    return GOOD;
}

/*
 * @brief           Decompress forbiddenTA
 *
 * @param[out]      pTgt :          output structure
 * @param[in]       pSrc :          input structure
 * @return          status :        GOOD, ERROR / int16_t
 */
VCCB_STATIC_INLINE
int16_t VLIB_DecompressForbiddenTA(forbiddenTA_type *pTgt, const forbiddenTACompressed_type *pSrc)
{
    AUTO_TRACE_FUNC;

    uint16_t diffIdx = 0;
    uint16_t tacIdx = 1;

    VALID_E_POINT_CHECK_ERROR(pTgt);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    if ((0 == pSrc->numTac) || (X2_maxnoofForbTACs < pSrc->numTac))
    {
        VCCB_PRINT_ERROR("pSrc->numTac is out of range (%d:%d:%d>\n", 0, pSrc->numTac, X2_maxnoofForbTACs);
        return ERROR;
    }

    pTgt->plmn = pSrc->plmn;
    pTgt->numTac = pSrc->numTac;

    // initialize instead of memset
    pTgt->tac[0] = pSrc->firstValue;
    for (tacIdx = 1; tacIdx < pSrc->numTac; tacIdx++)
    {
        pTgt->tac[tacIdx] = 0;
    }

    for (diffIdx = 0, tacIdx = 1; ((tacIdx < pSrc->numTac) && (diffIdx < MAX_NUM_FORB_TA_COMPR_VAL)); diffIdx++)
    {
        if (0 == pSrc->diff[diffIdx])
        {
            pTgt->tac[tacIdx] = static_cast<uint16_t>(pTgt->tac[tacIdx] + 255);
        }
        else
        {
            pTgt->tac[tacIdx] = static_cast<uint16_t>(pTgt->tac[tacIdx] + pSrc->diff[diffIdx]);
            pTgt->tac[tacIdx] = static_cast<uint16_t>(pTgt->tac[tacIdx] + pTgt->tac[tacIdx - 1]);
            tacIdx++;
        }
    }

    return GOOD;
}

/*
 * @brief           Decompress forbiddenTA for SA call (contained fiveGTac)
 *
 * @param[out]      pTgt :          output structure
 * @param[in]       pSrc :          input structure
 * @return          status :        GOOD, ERROR / int16_t
 */
VCCB_STATIC_INLINE
int16_t VLIB_Decompress5gForbiddenTA(forbiddenTA_type *pTgt, const forbidden5gTACompressed_type *pSrc)
{
    AUTO_TRACE_FUNC;

    uint16_t diffIdx = 0;
    uint16_t tacIdx = 1;

    VALID_E_POINT_CHECK_ERROR(pTgt);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    if ((0 == pSrc->numTac) || (NG_MaxnoofForbTACs < pSrc->numTac))
    {
        VCCB_PRINT_ERROR("pSrc->numTac is out of range (%d:%d:%d>\n", 0, pSrc->numTac, NG_MaxnoofForbTACs);
        return ERROR;
    }

    pTgt->plmn = pSrc->plmn;
    pTgt->numTac = pSrc->numTac;

    // initialize instead of memset
    pTgt->fiveGTac[0] = pSrc->firstValue;
    for (tacIdx = 1; tacIdx < pSrc->numTac; tacIdx++)
    {
        pTgt->fiveGTac[tacIdx] = 0;
    }

    for (diffIdx = 0, tacIdx = 1; ((tacIdx < pSrc->numTac) && (diffIdx < MAX_NUM_FORB_TA_COMPR_VAL_SA)); diffIdx++)
    {
        if (0 == pSrc->diff[diffIdx])
        {
            pTgt->fiveGTac[tacIdx] += 65535;
        }
        else
        {
            pTgt->fiveGTac[tacIdx] += pSrc->diff[diffIdx];
            pTgt->fiveGTac[tacIdx] += pTgt->fiveGTac[tacIdx - 1];
            tacIdx++;
        }
    }

    return GOOD;
}

/*
 * @brief           Compress hoRestrictInfo
 *
 * @param[out]      pTgt :          output structure
 * @param[in]       pSrc :          input structure
 * @return          status :        GOOD, ERROR / int16_t
 */
int16_t VLIB_CompressHoRestrictInfo(callInfo_type *ptCi, const hoRestrictInfo_type *pSrc)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;
    uint16_t loop = 0;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pSrc);

    hoRestrictInfoCompressed_type *pTgt = &ptCi->hoRestrict;

    pTgt->existFlag = pSrc->existFlag;
    pTgt->nrRestrictionType = pSrc->nrRestrictionType;
    pTgt->servedPlmn = pSrc->servedPlmn;
    pTgt->numEplmn = pSrc->numEplmn;
    pTgt->numForbidTaPlmn = pSrc->numForbidTaPlmn;
    pTgt->forbiddenRat = pSrc->forbiddenRat;
    pTgt->cnTypeRestrictForServingPlmn = pSrc->cnTypeRestrictForServingPlmn;
    pTgt->cnTypeRestrictForEplmn = pSrc->cnTypeRestrictForEplmn;

    for (loop = 0; loop < MIN(pSrc->numEplmn, X2_maxnoofEPLMNs); loop++)
    {
        pTgt->ePlmn[loop] = pSrc->ePlmn[loop];
    }
    for (loop = 0; loop < MIN(pSrc->numForbidTaPlmn, X2_maxnoofEPLMNsPlusOne); loop++)
    {
        if (ptCi->callType == E_CALLTYPE_SA)
        {
            status = VLIB_Compress5gForbiddenTA(&pTgt->forbidden5gTA[loop], &pSrc->forbiddenTA[loop]);
        }
        else
        {
            status = VLIB_CompressForbiddenTA(&pTgt->forbiddenTA[loop], &pSrc->forbiddenTA[loop]);
        }
        if (ERROR == status)
        {
            VCCB_PRINT_ERROR("VLIB_CompressForbiddenTA ERROR!\n");
            return ERROR;
        }
    }

    pTgt->numRatRestriction = pSrc->numRatRestriction;
    for (loop = 0; loop < MIN(pSrc->numRatRestriction, NG_MaxnoofEPLMNsPlusOne); loop++)
    {
        pTgt->ratRestriction[loop] = pSrc->ratRestriction[loop];
    }

    pTgt->numServiceArea = pSrc->numServiceArea;
    for (loop = 0; loop < MIN(pSrc->numServiceArea, NG_MaxnoofEPLMNsPlusOne); loop++)
    {
        pTgt->serviceArea[loop] = pSrc->serviceArea[loop];
    }
    pTgt->lastEutraPlmnPresent = pSrc->lastEutraPlmnPresent;
    pTgt->lastEutraPlmn = pSrc->lastEutraPlmn;

    return GOOD;
}

/*
 * @brief           Decompress hoRestrictInfo
 *
 * @param[out]      pTgt :          output structure
 * @param[in]       pSrc :          input structure
 * @param[in]       callType : NSA / SA
 * @return          status :        GOOD, ERROR / int16_t
 */
int16_t VLIB_DecompressHoRestrictInfo(const callInfo_type *ptCi, hoRestrictInfo_type *pTgt)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;
    uint16_t loop = 0;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pTgt);

    const hoRestrictInfoCompressed_type *pSrc = &ptCi->hoRestrict;

    pTgt->existFlag = pSrc->existFlag;
    if (FALSE == pSrc->existFlag)
    {
        return GOOD;
    }

    pTgt->nrRestrictionType = pSrc->nrRestrictionType;
    pTgt->servedPlmn = pSrc->servedPlmn;
    pTgt->numEplmn = pSrc->numEplmn;
    pTgt->numForbidTaPlmn = pSrc->numForbidTaPlmn;
    pTgt->forbiddenRat = pSrc->forbiddenRat;
    pTgt->lastEutraPlmnPresent = pSrc->lastEutraPlmnPresent;
    pTgt->lastEutraPlmn = pSrc->lastEutraPlmn;
    pTgt->cnTypeRestrictForServingPlmn = pSrc->cnTypeRestrictForServingPlmn;
    pTgt->cnTypeRestrictForEplmn = pSrc->cnTypeRestrictForEplmn;

    pTgt->allowedPlmnList[PrimaryRATRestriction].numNrAllowedPlmn = 0;
    pTgt->allowedPlmnList[PrimaryRATRestriction].numEutraAllowedPlmn = 0;
    pTgt->allowedPlmnList[SecondaryRATRestriction].numNrAllowedPlmn = 0;
    pTgt->allowedPlmnList[SecondaryRATRestriction].numEutraAllowedPlmn = 0;

    for (loop = 0; loop < MIN(pSrc->numEplmn, X2_maxnoofEPLMNs); loop++)
    {
        pTgt->ePlmn[loop] = pSrc->ePlmn[loop];
    }
    for (loop = 0; loop < MIN(pSrc->numForbidTaPlmn, X2_maxnoofEPLMNsPlusOne); loop++)
    {
        if (ptCi->callType == E_CALLTYPE_SA)
        {
            status = VLIB_Decompress5gForbiddenTA(&pTgt->forbiddenTA[loop], &pSrc->forbidden5gTA[loop]);
        }
        else
        {
            status = VLIB_DecompressForbiddenTA(&pTgt->forbiddenTA[loop], &pSrc->forbiddenTA[loop]);
        }
        if (ERROR == status)
        {
            VCCB_PRINT_ERROR("VLIB_DecompressForbiddenTA ERROR!\n");
            return ERROR;
        }
    }

    pTgt->numRatRestriction = pSrc->numRatRestriction;
    for (loop = 0; loop < MIN(pSrc->numRatRestriction, NG_MaxnoofEPLMNsPlusOne); loop++)
    {
        pTgt->ratRestriction[loop] = pSrc->ratRestriction[loop];
    }

    pTgt->numServiceArea = pSrc->numServiceArea;
    for (loop = 0; loop < MIN(pSrc->numServiceArea, NG_MaxnoofEPLMNsPlusOne); loop++)
    {
        pTgt->serviceArea[loop] = pSrc->serviceArea[loop];
    }

    if (pTgt->existFlag)
    {
        VLIB_UpdateAllowedPlmn(ptCi, pTgt, True);
    }

    return GOOD;
}

VCCB_STATIC_INLINE
void VLIB_UpdateAllowedPlmn_LastEutraPlmn(hoRestrictInfo_type *pMrl, CandidateAllowedPlmnList_type *pOut)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pMrl);
    VALID_E_POINT_CHECK_VOID(pOut);

    if (pOut->numEutra >= NG_MaxnoofEPLMNsPlusOne)
    {
        return;
    }

    if (pMrl->lastEutraPlmnPresent == OPT_NOT_PRESENT)
    {
        return;
    }

    uint16_t idx, isFoundFlag = FALSE;
    for (idx = 0; idx < MIN(pOut->numEutra, NG_MaxnoofEPLMNsPlusOne); idx++)
    {
        if (pOut->eutraAllowed[idx].longId == pMrl->lastEutraPlmn.longId)
        {
            isFoundFlag = TRUE;
            break;
        }
    }

    if (isFoundFlag == FALSE)
    {
        pOut->eutraAllowed[pOut->numEutra++] = pMrl->lastEutraPlmn;
    }
}

VCCB_STATIC_INLINE
void VLIB_UpdateAllowedPlmn_RATRestriction(hoRestrictInfo_type *pMrl, CandidateAllowedPlmnList_type *pOut, enumSpecRatRestriction_type ratRestrictType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pMrl);
    VALID_E_POINT_CHECK_VOID(pOut);

    auto getRatRestrictInfo = [pMrl, ratRestrictType](const uint8_t ratRestrictIndex) -> uint8_t
    {
        auto &ratRestrictItem = pMrl->ratRestriction[ratRestrictIndex];

        switch(ratRestrictType)
        {
            default:
            case PrimaryRATRestriction:
                if (ratRestrictItem.m.RATRestrictionsExt_Present == OPT_PRESENT)
                    return ratRestrictItem.extension.primaryRatRestrictInfo;

                return ratRestrictItem.base.ratRestrictInfo;

            case SecondaryRATRestriction:
                if (ratRestrictItem.m.RATRestrictionsExt_Present == OPT_PRESENT)
                    return ratRestrictItem.extension.secondaryRatRestrictInfo;

                return ratRestrictItem.base.ratRestrictInfo;
        }
    };

    uint16_t idx, idx2;
    /* Exclude RAT Restriction PLMN */
    for (idx = 0; idx < MIN(pMrl->numRatRestriction, NG_MaxnoofEPLMNsPlusOne); idx++)
    {
        const uint8_t ratRestriction = getRatRestrictInfo(static_cast<uint8_t>(idx));

        if (ratRestriction & MRL_RAT_RESTRICT_NR)
        {
            for (idx2 = 0; idx2 < MIN(pOut->numNr, NG_MaxnoofEPLMNsPlusOne); idx2++)
            {
                if (pOut->nrAllowed[idx2].longId == pMrl->ratRestriction[idx].plmn.longId)
                {
                    /* Remove from Allowed PLMN list */
                    pOut->nrAllowed[idx2].longId = MRL_FILTER_EMPTY_PLMN;
                    break;
                }
            }
        }

        if (ratRestriction & MRL_RAT_RESTRICT_EUTRA)
        {
            for (idx2 = 0; idx2 < MIN(pOut->numEutra, NG_MaxnoofEPLMNsPlusOne); idx2++)
            {
                if (pOut->eutraAllowed[idx2].longId == pMrl->ratRestriction[idx].plmn.longId)
                {
                    /* Remove from Allowed PLMN list */
                    pOut->eutraAllowed[idx2].longId = MRL_FILTER_EMPTY_PLMN;
                    break;
                }
            }
        }
    }
}

VCCB_STATIC_INLINE
void VLIB_UpdateAllowedPlmn_MakeAllowedList(
    uint8_t *numTgt, plmnId_type *tgtAllowedList, plmnId_type *srcAllowedList, uint16_t numSrc)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(numTgt);
    VALID_E_POINT_CHECK_VOID(tgtAllowedList);
    VALID_E_POINT_CHECK_VOID(srcAllowedList);

    uint16_t idx;

    /* Make Allowed PLMN list */
    *numTgt = 0;
    for (idx = 0; idx < numSrc && idx < NG_MaxnoofEPLMNsPlusOne; idx++)
    {
        if (srcAllowedList[idx].longId != MRL_FILTER_EMPTY_PLMN)
        {
            tgtAllowedList[(*numTgt)++] = srcAllowedList[idx];
        }
    }
}

/****************************************************************************
 * @brief           Update Allowed Plmn List for UE
 *
 * @param[in]       pMrl                : Pointer of Mobility Restriction List Information / hoRestrictInfo_type
 * @param[in]       cnTypeRestrictEutra : Indicates whether to include Eutra cnTypeRestriction. / BOOL
 * @return          void
 ****************************************************************************/
void VLIB_UpdateAllowedPlmn(const callInfo_type *ptCi, hoRestrictInfo_type *pMrl, BOOL cnTypeRestrictEutra)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pMrl);

    allwedPlmnList_type *pPrimaryAllowedPlmn = &pMrl->allowedPlmnList[PrimaryRATRestriction];
    allwedPlmnList_type *pSecondaryAllowedPlmn = &pMrl->allowedPlmnList[SecondaryRATRestriction];

    // Init DB for PLMN Count (Output DB)
    pPrimaryAllowedPlmn->numNrAllowedPlmn = 0;
    pPrimaryAllowedPlmn->numEutraAllowedPlmn = 0;
    pSecondaryAllowedPlmn->numNrAllowedPlmn = 0;
    pSecondaryAllowedPlmn->numEutraAllowedPlmn = 0;

    // If MRL does not exist, only DB initialization is performed.
    // This DB is only valid if an MRL exists.
    if (FALSE == pMrl->existFlag)
    {
        return;
    }

    // ---------------------------------------------------------------------------------------------------

    const uint16_t maxIdx = static_cast<uint16_t>(UMIN(pMrl->numEplmn, NG_MaxnoofEPLMNsPlusOne));
    CandidateAllowedPlmnList_type candidateListWoRatRestriction;
    uint16_t idx;

    auto decisionAllowedPLMN = [&candidateListWoRatRestriction, &pMrl](allwedPlmnList_type *pAllowedPlmn, enumSpecRatRestriction_type ratRestrictType)
    {
        // Copy Source Data
        CandidateAllowedPlmnList_type candidateList = candidateListWoRatRestriction;

        /* Exclude RAT Restriction PLMN */
        VLIB_UpdateAllowedPlmn_RATRestriction(pMrl, &candidateList, ratRestrictType);

        VLIB_UpdateAllowedPlmn_MakeAllowedList(&pAllowedPlmn->numNrAllowedPlmn, pAllowedPlmn->nrAllowedPlmn,
            candidateList.nrAllowed, candidateList.numNr);

        VLIB_UpdateAllowedPlmn_MakeAllowedList(&pAllowedPlmn->numEutraAllowedPlmn,
            pAllowedPlmn->eutraAllowedPlmn, candidateList.eutraAllowed, candidateList.numEutra);
    };

    // Init DB for Candidate (Input DB)
    candidateListWoRatRestriction.numNr = candidateListWoRatRestriction.numEutra = 0;
    for (idx = 0; idx < NG_MaxnoofEPLMNsPlusOne; idx++)
    {
        candidateListWoRatRestriction.nrAllowed[idx].longId = MRL_FILTER_EMPTY_PLMN;
        candidateListWoRatRestriction.eutraAllowed[idx].longId = MRL_FILTER_EMPTY_PLMN;
    }


    /* Build allowed plmn list */
    /* Serving PLMN */
    /* NR, EUTRA : Serving PLMN is always allowed, index of serving Plmn is always ??0??*/
    candidateListWoRatRestriction.nrAllowed[candidateListWoRatRestriction.numNr++] = pMrl->servedPlmn;

    if (TRUE == cnTypeRestrictEutra && TRUE == pMrl->cnTypeRestrictForServingPlmn)
    {
        // no action - In the case of a line to be erased, do not add the PLMN to the first.
        // if (TRUE == cnTypeRestrictEutra)
        // {
        //     if (TRUE == pMrl->cnTypeRestrictForServingPlmn)
        //     {
        //         candidateList.eutraAllowed[0].longId = MRL_FILTER_EMPTY_PLMN;
        //     }
        // }
    }
    else
    {
        candidateListWoRatRestriction.eutraAllowed[candidateListWoRatRestriction.numEutra++] = pMrl->servedPlmn;
    }

    /* Add EPLMN to Allowed PLMN list */
    for (idx = 0; idx < maxIdx; idx++)
    {
        if (candidateListWoRatRestriction.numNr >= NG_MaxnoofEPLMNsPlusOne) break;
        if (candidateListWoRatRestriction.numEutra >= NG_MaxnoofEPLMNsPlusOne) break;

        candidateListWoRatRestriction.nrAllowed[candidateListWoRatRestriction.numNr++] = pMrl->ePlmn[idx];
        candidateListWoRatRestriction.eutraAllowed[candidateListWoRatRestriction.numEutra++] = pMrl->ePlmn[idx];
    }

    VLIB_UpdateAllowedPlmn_LastEutraPlmn(pMrl, &candidateListWoRatRestriction);

    /* Exclude CN Type Restriction */
    for (idx = 0; idx < MIN(pMrl->cnTypeRestrictForEplmn.numRestrictPlmn, NG_MaxnoofEPLMNs); idx++)
    {
        int16_t idxAllowedPlmn;

        if (pMrl->cnTypeRestrictForEplmn.cnTypeRestriction[idx] == NGAP_fiveGC_forbidden)
        {
            for (idxAllowedPlmn = 0; idxAllowedPlmn < MIN(candidateListWoRatRestriction.numNr, NG_MaxnoofEPLMNsPlusOne);
                 idxAllowedPlmn++)
            {
                if (candidateListWoRatRestriction.nrAllowed[idxAllowedPlmn].longId ==
                    pMrl->cnTypeRestrictForEplmn.restrictPlmn[idx].longId)
                {
                    candidateListWoRatRestriction.nrAllowed[idxAllowedPlmn].longId = MRL_FILTER_EMPTY_PLMN;
                }
            }
        }
        else if (pMrl->cnTypeRestrictForEplmn.cnTypeRestriction[idx] == NGAP_cn_Type_epc_forbidden)
        {
            for (idxAllowedPlmn = 0; idxAllowedPlmn < MIN(candidateListWoRatRestriction.numEutra, NG_MaxnoofEPLMNsPlusOne);
                 idxAllowedPlmn++)
            {
                if (candidateListWoRatRestriction.eutraAllowed[idxAllowedPlmn].longId ==
                    pMrl->cnTypeRestrictForEplmn.restrictPlmn[idx].longId)
                {
                    candidateListWoRatRestriction.eutraAllowed[idxAllowedPlmn].longId = MRL_FILTER_EMPTY_PLMN;
                }
            }
        }
    }

    // Generate Primary Allowed PLMN
    decisionAllowedPLMN(pPrimaryAllowedPlmn, PrimaryRATRestriction);

    // Generate Secondary Allowed PLMN
    decisionAllowedPLMN(pSecondaryAllowedPlmn, SecondaryRATRestriction);
}
