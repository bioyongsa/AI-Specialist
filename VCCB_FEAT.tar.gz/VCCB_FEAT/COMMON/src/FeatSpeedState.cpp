/**
 * @file        FeatSpeedState.cpp
 * @brief       collections of functions to manage call speed state,
 *              Feature ID: FGR-MC1026
 *              Feature Name: Mobility control based on UE speed level detection
 */

#include "FeatSpeedState.hpp"
#include "ComInclude.h"

namespace
{
void FnVCCB_ChangeCallSpeedState(callInfo_type &rCi, enumUeSpeed_type newSpeedState)
{
    AUTO_TRACE_FUNC;

    if (rCi.bitFlag.ueSpeedState == static_cast<uint32_t>(newSpeedState))
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "[UeSpeedState] call speed state maintained (%d)\n", newSpeedState);
        return;
    }
    VCCB_PRINT_CALL_INFORMATIVE(&rCi, "[UeSpeedState] call speed state changed (%d->%d)\n",
        static_cast<int>(rCi.bitFlag.ueSpeedState), newSpeedState);
    rCi.bitFlag.ueSpeedState = static_cast<uint32_t>(newSpeedState) & e_BitMask_2bit;
}
}  // namespace

/****************************************************************************
 * @brief           Function for setting speed state based on cell speed state.
                    Use it for initial access (RRC Setup, RRE, Resume)
 * @param[in]       rCi : reference to call configuration. / callInfo_type&
 * @param[in]       cellNum : cellNum of a cell for initial access. / CellNum_type
 ****************************************************************************/
void UeSpeedState::VCCB_SetCallSpeedStateBasedOnCellSpeedState(callInfo_type &rCi, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    VCCB_PRINT_CALL_COMMENT(&rCi, "[UeSpeedState] call speed state change based on cell\n");
    enumUeSpeed_type newUeSpeedState = ueSpeedState_Normal;
    if (CELLINFO[cellNum].isCellHighSpeed)
    {
        newUeSpeedState = ueSpeedState_High;
    }
    FnVCCB_ChangeCallSpeedState(rCi, newUeSpeedState);
}

/****************************************************************************
 * @brief           Function for simulating UE speed state on target cell
 * @param[in]       rCi : reference to call configuration. / callInfo_type&
 * @param[in]       targetCellNum : target cellNum in intra gNB HO. / CellNum_type
 *
 * @return          UE speed state / enumUeSpeed_type
 ****************************************************************************/
enumUeSpeed_type VCCB_GetSpeedStateOnTargetCell(const callInfo_type &rCi, CellNum_type targetCellNum)
{
    VCCB_CHECK_E_RANGE_AND_VAL(targetCellNum, MAX_CELL_NUM_VCCB, ueSpeedState_Normal);

    // only SA and NR-DC MN supported
    if (FnVCCB_IsMrdcSn(&rCi))
    {
        return ueSpeedState_Normal;
    }

    // if target cell is high UE will change to high speed
    if (CELLINFO[targetCellNum].isCellHighSpeed)
    {
        return ueSpeedState_High;
    }

    return static_cast<enumUeSpeed_type>(rCi.bitFlag.ueSpeedState);
}

/****************************************************************************
 * @brief           Function for setting speed state based on target cell speed state.
                    Use it for intra gNB handover.
 * @param[in]       rCi : reference to call configuration. / callInfo_type&
 * @param[in]       targetCellNum : target cellNum in intra gNB HO. / CellNum_type
 ****************************************************************************/
void UeSpeedState::VCCB_SetCallSpeedStateBasedOnTargetCellSpeedState(callInfo_type &rCi, CellNum_type targetCellNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VOID(targetCellNum, MAX_CELL_NUM_VCCB);

    VCCB_PRINT_CALL_COMMENT(&rCi, "[UeSpeedState] set call speed state based on target cell\n");
    FnVCCB_ChangeCallSpeedState(rCi, VCCB_GetSpeedStateOnTargetCell(rCi, targetCellNum));
}

/****************************************************************************
 * @brief           Function for setting speed state based on DU indication.
 * @param[in]       rCi : reference to call configuration. / callInfo_type&
 * @param[in]       ueSpeedInd : value ueSpeedIndication from F1_PrivateMessage. / enumUeSpeed_type
 ****************************************************************************/
void UeSpeedState::VCCB_SetCallSpeedStateBasedOnDuIndication(callInfo_type &rCi, enumUeSpeed_type speedState)
{
    AUTO_TRACE_FUNC;

    VCCB_PRINT_CALL_COMMENT(&rCi, "[UeSpeedState] call speed state change based on du indication\n");

    FnVCCB_ChangeCallSpeedState(rCi, speedState);
}

/****************************************************************************
 * @brief           Function for saving F1 PrivateMessage with samsungUESpeedIndication
 * @param[in]       rCi : reference to call configuration. / callInfo_type&
 * @param[in]       ueSpeedInd : value ueSpeedIndication from F1_PrivateMessage. / F1_SamsungUESpeedIndication
 ****************************************************************************/
void UeSpeedState::VCCB_SaveF1SamsungUESpeedIndication(
    callInfo_type &rCi, const F1_SamsungUESpeedIndication &ueSpeedInd)
{
    AUTO_TRACE_FUNC;

    const F1__enum1_10 ueSpeedLevelInd = ueSpeedInd.ueSpeedlevelIndication;
    if (!(ueSpeedInd.bit_mask & F1_ueSpeedlevelIndication_present))
    {
        VCCB_PRINT_CALL_COMMENT(&rCi,
            "[UeSpeedState] ignore SamsungUESpeedIndication because ueSpeedlevelIndication bit mask is not set!\n");
        return;
    }

    switch (ueSpeedLevelInd)
    {
        case F1_high:
            rCi.f1SamsungPrivateMessageInfo.ueSpeedIndicationReceived = true;
            rCi.f1SamsungPrivateMessageInfo.ueSpeedIndication = ueSpeedState_High;
            break;
        case F1_ueSpeedlevelIndication_normal:
            rCi.f1SamsungPrivateMessageInfo.ueSpeedIndicationReceived = true;
            rCi.f1SamsungPrivateMessageInfo.ueSpeedIndication = ueSpeedState_Normal;
            break;
        case F1_stationary:
            rCi.f1SamsungPrivateMessageInfo.ueSpeedIndicationReceived = true;
            rCi.f1SamsungPrivateMessageInfo.ueSpeedIndication = ueSpeedState_Stationary;
            break;
        default:
            VCCB_PRINT_CALL_ERROR(
                &rCi, "[UeSpeedState] Received ueSpeedlevelIndication (%d) is out of range!\n", ueSpeedLevelInd);
            break;
    }
}

/****************************************************************************
 * @brief           Function for saving F1 PrivateMessage with samsungUESpeedIndication
 * @param[in]       rCi : reference to call configuration. / callInfo_type&
 * @param[in]       ueSpeedInd : value ueSpeedIndication from F1_PrivateMessage. / enumUeSpeed_type
 *
 * @return          status (GOOD/ERROR) / int16_t
 ****************************************************************************/
int16_t UeSpeedState::VCCB_ProcessUeSpeedIndication(callInfo_type &rCi, const enumUeSpeed_type ueSpeedInd)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(rCi.servCellNum, MAX_CELL_NUM_VCCB);

    const VccbCellInfo_type &rCell = CELLINFO[rCi.servCellNum];
    if (rCell.isCellHighSpeed)
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "[UeSpeedState] Ignore UE speed indication for High speed cell.\n");
        return GOOD;
    }

    if (FnVCCB_IsMrdcSn(&rCi))
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "[UeSpeedState] Ignore UE speed indication for MR-DC SN call.\n");
        return GOOD;
    }

    UeSpeedState::VCCB_SetCallSpeedStateBasedOnDuIndication(rCi, ueSpeedInd);

    const bool featureEnabled = rCell.highSpeedUeMobility.featureEnabled;
    const bool duContext = GET_F1_RESOURCE_FLAG(rCi.flag.setupFlag);
    if (featureEnabled && duContext)
    {
        VCCB_RETURN_ON_CALL_ERROR(&rCi, VCCM_EnqueueActionMeasReconfig(&rCi, MeasReconfigPriorAction_Full),
            "[UeSpeedState] VCCM_EnqueueActionMeasReconfig ERROR!\n");
    }
    else
    {
        VCCB_PRINT_CALL_COMMENT(&rCi, "[UeSpeedState] measReconf not executed. Feature enabled: %d, DU context: %d.\n",
            featureEnabled, duContext);
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Function for getting speed state
 * @param[in]       rCi : reference to call configuration. / callInfo_type&
 * @param[in]       cellNum : cellNum of a cell for initial access. / CellNum_type
 ****************************************************************************/
enumUeSpeed_type UeSpeedState::VCCB_GetUeSpeedState(const callInfo_type &call, CellNum_type cellNum)
{
    // Theoretically cell can change its speed status. It can be achieved *without* lock-unlock sequence which releases
    // all UEs. Problematic case: UE in Normal speed state and cell speed status change from Normal to High. This should
    // not affect this UE speed state. Because of the above the condition below is needed to prevent the UE to get High
    // speed measurement modifications.
    if (cellNum != call.servCellNum)
    {
        return VCCB_GetSpeedStateOnTargetCell(call, cellNum);
    }
    else
    {
        return static_cast<enumUeSpeed_type>(call.bitFlag.ueSpeedState);
    }
}
