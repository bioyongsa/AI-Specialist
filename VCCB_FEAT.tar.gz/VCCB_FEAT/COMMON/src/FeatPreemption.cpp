/****************************************************************
 * System      : 5G NR
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : FeatPreemption.c
 * Description :
 * Author      :
 * Dept.       : Call S/W Lab
 * Created     : 2024.11.20
 * Procedures defined :
 * Procedures called  :
 * Version     :
 * Revision history   :
 *          date      :
 *       revised by   :
 * revised information:
 ****************************************************************/
#include "FeatPreemption.h"

#include "FeatCommon.h"
#include "FeatCallInfo.h"
#include "ComGlobalData.h"
#include "ComLibUtility.h"
#include "ComInline.h"
#include "ComAutoNtrace.hpp"

#include "StateCommon.h"
#include "StateHandleAll.h"

#include "nrrrcUnpack.h"
#include "ComLibStatistic.h"
#include "FeatPreemption.h"
#include "MsgE1apStore.hpp"

#include "ComInclude.h"
#include "FeatMrdc.h"

#include "FeatCallProc.h"
#include "FeatSwVersion.h"

#include "MsgNmbSend.h"
#include "MsgE1apSend.h"
#include "MsgX2apSend.h"
#include "MsgNgapSend.h"
#include "MsgXnapSend.h"

#include "log_util.h"
#include <string>

extern "C" {
    #include "RRC.h"
    #include "errcUnpack.h"
}

/**
 * @brief     Check whether to proceed E1 DRB Preemption.
 * @param     ptCi : call context
 * @param     ptUnpack : E1 Modification Required Message
 * @return    GOOD : success
 * @return    ERROR : failure
 */

int16_t FnVCCB_IsDrbPreemptionRequestByE1(callInfo_type *ptCi, const msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    // 1. Check SA Call
    if (ptCi->callType != E_CALLTYPE_SA) return BREAK;

    // 2. Find DRB Remove List
    auto &required =
        *reinterpret_cast<const E1_BearerContextModificationRequired *>(ptUnpack->unpack + ptUnpack->unpackMsgOffset);
    ContainerIterator iter(*required.protocolIEs);

    ++iter;  // skip E1_id_gNB_CU_CP_UE_E1AP_ID
    ++iter;  // skip E1_id_gNB_CU_UP_UE_E1AP_ID

    auto *modiRequired = iter.get_data_ptr<E1_System_BearerContextModificationRequired>(
        E1_id_System_BearerContextModificationRequired);

    if (!modiRequired)
    {
        if(DBG->flag.logE1Preemption)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "%s: no E1_System_BearerContextModificationRequired received \n", __func__);
        }
        return BREAK;
    }

    if (E1_nG_RAN_BearerContextModificationRequired_chosen != modiRequired->choice)
    {
        if(DBG->flag.logE1Preemption)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "%s: Unsupported message choice: (%d)\n", __func__, modiRequired->choice);
        }        
        return BREAK;
    }
    
    // Condition to find E1 Preemption DRB
    // E1_BearerContextModificationRequired
    // - E1_PDU_Session_Resource_Required_To_Modify_List
    // -- E1_DRB_Required_To_Remove_List_NG_RAN
    // --- cause: CauseE1apRadioNetworkLayerResourcesNotAvailableForTheSlice
    ContainerIterator iterForNr(*modiRequired->u.nG_RAN_BearerContextModificationRequired);
    while (iterForNr.is_valid())
    {
        auto **pPduSessList = iterForNr.get_data_ptr<E1_PDU_Session_Resource_Required_To_Modify_List>(
                    E1_id_PDU_Session_Resource_Required_To_Modify_List);

        if (!pPduSessList)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "%s: no E1_System_BearerContextModificationRequired received \n", __func__);
            return ERROR;
        }

        // Find preemption ie (E1_DRB_Required_To_Remove_List_NG_RAN)
        if (iterForNr.get_data_id() == E1_id_PDU_Session_Resource_Required_To_Modify_List)
        {
            const E1_PDU_Session_Resource_Required_To_Modify_List_ *listItem = *pPduSessList;

            for (; listItem; listItem = listItem->next)
            {
                auto &pduSessModify = listItem->value;
                if (pduSessModify.bit_mask & E1_dRB_Required_To_Remove_List_NG_RAN_present)
                {
                    const E1_DRB_Required_To_Remove_List_NG_RAN_ *ListItemDRB = pduSessModify.dRB_Required_To_Remove_List_NG_RAN;
                    for (; ListItemDRB; ListItemDRB = ListItemDRB->next)
                    {
                        auto &drbRemoveReqItem = ListItemDRB->value;  // E1_DRB_Required_To_Remove_Item_NG_RAN
                        uint16_t e1Cause = CauseE1apMax;
                        if (GOOD == SaveE1Cause(*ptCi, drbRemoveReqItem.cause, e1Cause))
                        {
                            if(e1Cause == CauseE1apRadioNetworkLayerResourcesNotAvailableForTheSlice)
                            {
                                return GOOD;
                            }
                        }
                    }
                }
            }
            ++iterForNr;
        }
    }

    return BREAK;
}


/**
 * @brief     Released markedDRB.
 * @param     ptCi : call context
 * @param     ptAll : msgbuf
 * @param     ptUnpack : E1 Modification Required Message
 * @param     srvUpIdx : indicate UP which sent the DRB preemption msg
 * @return    GOOD : success
 * @return    ERROR : failure
 */

int16_t FnVCCB_Release_MarkedToBeReleasedDrbByE1(callInfo_type *ptCi, uint16_t msgId, uint8_t noWaitActionFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int status = GOOD;

    // Set Temp DB by Rel DRB Info
    FnVCCB_Init_ToBeReleasedPduQosFlowInfo(ptCi);

    // callReleaseFlag - VCCB_FLAG_ON : All PDUs will be released due to Preemption
    uint8_t numQosFlowToBeReleased = 0;
    uint8_t numPduToBeReleased = 0;
    uint8_t callReleaseFlag = VCCB_FLAG_OFF;

    // setDbFlag - VCCB_FLAG_OFF : judge to release or not.
    uint8_t setDbFlag = VCCB_FLAG_OFF;
    status = FnVCCB_Mark_ToBeReleasedPduQosFlow_usingMarkedDrb(
        ptCi, &numQosFlowToBeReleased, &numPduToBeReleased, setDbFlag, e_preemption_e1);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_Mark_ToBeReleasedPduQosFlow_usingMarkedDrb ERROR!\n");

    if (numQosFlowToBeReleased == 0)
    {
        // If No Action then return GOOD.
        return GOOD;
    }

    if (numPduToBeReleased == ptCi->numPDUSess)
    {
        callReleaseFlag = VCCB_FLAG_ON;
    }

    if (IS_NRDC_SN(ptCi))
    {
        //FGR-CC5200 : SVR25A FR1020
        MACRO_CALL_FAULT_SAVE(msgId, CauseE1apRadioNetworkLayerResourcesNotAvailableForTheSlice);
        VCCB_CALL_RELEASE_TRIGGER(ptCi);
        return GOOD;
    }
    else  // MN Side.
    {
        // CASE : All PDU Session are released. So Triggering UeContextReleaseRequest.
        if (callReleaseFlag == VCCB_FLAG_ON)
        {
            MACRO_CALL_FAULT_SAVE(msgId, CauseE1apRadioNetworkLayerResourcesNotAvailableForTheSlice);
            // Using DU Preemption Retain Cause.
            VLIB_SaveEventForCallRetainStat(ptCi, RetainCategory_UeCtxtRelRequestByGNB, CauseF1apRadioReleaseDueToPreEmption);
            VCCB_CALL_RELEASE_TRIGGER(ptCi);  // Call Job Release
            return GOOD;
        }
        else
        {
            // Send Noti to AMF using tempInfo. (E1/F1 Preemption use same option: INCLUDE_ONLY_REL_DRB_REQ_INFO)
            enumResourceNotifyOption_type itemOption = INCLUDE_ONLY_REL_DRB_REQ_INFO;
            auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_PDUSessionResourceNotify_id, &itemOption);
            VALID_E_POINT_CHECK_ERROR(ngapSender);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, ngapSender->sendMsg(), "sendMsg(NG_PDUSessionResourceNotify) ERROR!\n");

            if (noWaitActionFlag == VCCB_FLAG_ON)
            {
                // setDbFlag - VCCB_FLAG_ON : mark actual DRBs DB to release
                setDbFlag = VCCB_FLAG_ON;
                status = FnVCCB_Mark_ToBeReleasedPduQosFlow_usingMarkedDrb(
                    ptCi, &numQosFlowToBeReleased, &numPduToBeReleased, setDbFlag, e_preemption_e1);
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_Mark_ToBeReleasedPduQosFlow_usingMarkedDrb ERROR!\n");

                // Set Common Flow
                SET_STATE_CMD(PDURelease_cmd);
                INIT_NAS_INFORMATION(ptCi->nasTransportInfo);
                VCCM_ProcBeforePduSessionChange(ptCi);

                // Set No Response to AMF . It's not AMF's Request.
                ON_PDU_SESSION_PROC_NO_RESP(ptCi->flag.setupFlag);

                // FGR-CC5200 : FR1020 : SVR25A
                ptCi->cause.xnCause = CauseXnapRadioNetworkLayerResourcesNotAvailableForTheSlice;

                // Do Pdu Change Flow.
                status = VHCM_TriggerPduSessionChange(ptCi, msgId, FALSE);
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VHCM_TriggerPduSessionChange(Setup) ERROR!\n");
            }
        }
    }

    return GOOD;
}

/**
 * @brief     Check whether to proceed E1 DRB Preemption.
 * @param     ptCi : call context
 * @param     ptAll : msgbuf
 * @param     ptUnpack : E1 Modification Required Message
 * @param     srvUpIdx : indicate UP which sent the DRB preemption msg
 * @return    GOOD : success
 * @return    ERROR : failure
 */

int16_t FnVCCB_Execute_DRBPreemptionByE1(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack, uint16_t srvUpIdx)
{
    AUTO_TRACE_FUNC;    
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptAll);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);
    // range check srvUpIdx

    int16_t status = GOOD;
    uint8_t isNeedQueueingOrNoAction = VCCB_FLAG_OFF;

    ptCi->bitFlag.isNewE1DrbPreemptionRequest = VCCB_FLAG_OFF;

    // 1. Store Request Info
    status = FnVCCB_StoreE1Message(E1_BearerContextModificationRequired_id, ptCi, ptAll, ptUnpack);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL::StoreBearerContextModificationRequired ERROR !!\n");

    // 2. If New Valid Request is nothing, then send Confirm and Stop.
    if(ptCi->bitFlag.isNewE1DrbPreemptionRequest == VCCB_FLAG_OFF)
    {
        isNeedQueueingOrNoAction = VCCB_FLAG_ON;
                VCCB_PRINT_CALL_COMMENT(ptCi, "E1_DRB_PREEMPTION: No New Action\n");
    }
    else // 3. New Action Exist.
    {
        ptCi->bitFlag.isNewE1DrbPreemptionRequest = VCCB_FLAG_OFF;

        // Check State
        if (!VCCM_IsUeIdleState(ptCi->callType, ptCi->state))
        {
            isNeedQueueingOrNoAction = VCCB_FLAG_ON;
            // Enqueuing.
            if(ERROR == VLIB_EnqueueDrbPreemption(ptCi, ENQUEUE_ACTION_DRB_PREEMPTION_BY_E1))
            {
                VCCB_PRINT_CALL_INFORMATIVE(
                    ptCi, "VCCM_enqueueAction(ENQUEUE_ACTION_DRB_PREEMPTION_BY_E1) in %s fail\n", __FUNCTION__);
                // No Action. UP Will trigger Call Release.
            }
            else
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "E1_DRB_PREEMPTION: Enqueued\n");
            }
        }
    }

    // 4. Send E1 Confirm to UP.
    status = FnVCCB_SendE1Message(E1_BearerContextModificationConfirm_id, ptCi, srvUpIdx);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VEIL_sendBearerContextModificationConfirm ERROR !!\n");

    if(isNeedQueueingOrNoAction == VCCB_FLAG_ON)
    {
        return GOOD;
    }

    // 5. Send DrbRel to(AMF) and Do Relase Processing
    status = FnVCCB_Release_MarkedToBeReleasedDrbByE1(ptCi, ptUnpack->msgId, VCCB_FLAG_ON);
    if (status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_Release_MarkedToBeReleasedDrbByE1 ERROR(%d)\n", status);
        return ERROR;
}

    return GOOD;
}

// EOF